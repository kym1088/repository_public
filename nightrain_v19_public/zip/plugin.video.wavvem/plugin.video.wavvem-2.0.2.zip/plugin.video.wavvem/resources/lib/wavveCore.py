__author__="NightRain"
bGcRpVuNUhOvxzlIrWPwdkjBsYHtmF=object
bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX=None
bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL=False
bGcRpVuNUhOvxzlIrWPwdkjBsYHtme=range
bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE=str
bGcRpVuNUhOvxzlIrWPwdkjBsYHtmK=True
bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg=Exception
bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi=print
bGcRpVuNUhOvxzlIrWPwdkjBsYHtmn=len
bGcRpVuNUhOvxzlIrWPwdkjBsYHtmq=dict
bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf=int
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
bGcRpVuNUhOvxzlIrWPwdkjBsYHtCJ='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
class bGcRpVuNUhOvxzlIrWPwdkjBsYHtCD(bGcRpVuNUhOvxzlIrWPwdkjBsYHtmF):
 def __init__(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN='https://apis.pooq.co.kr'
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.APIKEY='E5F3E0D30947AA5440556471321BB6D9'
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.CREDENTIAL='none'
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.DEVICE='pc'
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.DRM='wm'
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.PARTNER='pooq'
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.POOQZONE='none'
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.REGION='kor'
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.TARGETAGE ='all'
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.HTTPTAG='https://'
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.LIST_LIMIT=30 
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.EP_LIMIT=30 
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.MV_LIMIT=24 
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.guid='none' 
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.guidtimestamp='none' 
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.DEFAULT_HEADER={'user-agent':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCJ}
 def callRequestCookies(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,jobtype,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,redirects=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCm=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.DEFAULT_HEADER
  if headers:bGcRpVuNUhOvxzlIrWPwdkjBsYHtCm.update(headers)
  if jobtype=='Get':
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCX=requests.get(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,params=params,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCm,cookies=cookies,allow_redirects=redirects)
  else:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCX=requests.post(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,data=payload,params=params,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCm,cookies=cookies,allow_redirects=redirects)
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtCX
 def SaveCredential(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCL):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.CREDENTIAL=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCL
 def LoadCredential(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF):
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.CREDENTIAL
 def GetDefaultParams(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe={'apikey':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.APIKEY,'credential':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.CREDENTIAL,'device':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.DEVICE,'drm':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.DRM,'partner':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.PARTNER,'pooqzone':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.POOQZONE,'region':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.REGION,'targetage':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.TARGETAGE}
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe
 def makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,domain,path,query1=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,query2=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=domain+path
  if query1:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE+='&%s'%urllib.parse.urlencode(query2)
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE
 def GetGUID(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCi=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCn=GenerateRandomString(5)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCq=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCn+media+bGcRpVuNUhOvxzlIrWPwdkjBsYHtCi
   return bGcRpVuNUhOvxzlIrWPwdkjBsYHtCq
  def GenerateRandomString(num):
   from random import randint
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCf=""
   for i in bGcRpVuNUhOvxzlIrWPwdkjBsYHtme(0,num):
    s=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE(randint(1,5))
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCf+=s
   return bGcRpVuNUhOvxzlIrWPwdkjBsYHtCf
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCq=GenerateID(guid_str)
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCT=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetHash(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCq)
  if guidType==2:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCT='%s-%s-%s-%s-%s'%(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCT[:8],bGcRpVuNUhOvxzlIrWPwdkjBsYHtCT[8:12],bGcRpVuNUhOvxzlIrWPwdkjBsYHtCT[12:16],bGcRpVuNUhOvxzlIrWPwdkjBsYHtCT[16:20],bGcRpVuNUhOvxzlIrWPwdkjBsYHtCT[20:])
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtCT
 def GetHash(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE(m.hexdigest())
 def CheckQuality(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,sel_qt,qt_list):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCo=0
  for bGcRpVuNUhOvxzlIrWPwdkjBsYHtCM in qt_list:
   if sel_qt>=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCM:return bGcRpVuNUhOvxzlIrWPwdkjBsYHtCM
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCo=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCM
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtCo
 def GetCredential(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,user_id,user_pw,user_pf):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCa=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/login'
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCA={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Post',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCA,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCL=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['credential']
   if user_pf!=0:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCA={'id':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCL,'password':'','profile':bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE(user_pf),'pushid':'','type':'credential'}
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe['credential']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCL 
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Post',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCA,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCL=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['credential']
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtCL:bGcRpVuNUhOvxzlIrWPwdkjBsYHtCa=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmK
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCL='none' 
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.SaveCredential(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCL)
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtCa
 def GetIssue(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDC=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/guid/issue'
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDJ=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['guid']
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDF=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['guidtimestamp']
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtDJ:bGcRpVuNUhOvxzlIrWPwdkjBsYHtDC=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmK
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDJ='none'
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDF='none' 
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.guid=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDJ
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.guidtimestamp=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDF
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtDC
 def GetGnList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,gn_str):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDm=[]
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/cf/supermultisections/'+gn_str
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   if not('multisectionlist' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy):return bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX 
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDX=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['multisectionlist']
   for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDX:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL['title']
    if bGcRpVuNUhOvxzlIrWPwdkjBsYHtmn(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDe)==0:continue
    if bGcRpVuNUhOvxzlIrWPwdkjBsYHtDe=='minor':continue 
    if re.search(u'베너',bGcRpVuNUhOvxzlIrWPwdkjBsYHtDe):continue
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDe=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',bGcRpVuNUhOvxzlIrWPwdkjBsYHtDe)
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDe.lstrip('#')
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDE in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL['eventlist'][0]['bodylist']:
     if re.search(r'uicode:',bGcRpVuNUhOvxzlIrWPwdkjBsYHtDE):
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtDK={'title':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDe,'uicode':re.sub(r'uicode:','',bGcRpVuNUhOvxzlIrWPwdkjBsYHtDE)}
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtDm.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDK)
      break
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtDm
 def GetDeeplinkList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,gn_str,came_str,page_int,addinfoyn=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDg=[]
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL=1
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn='quick'
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJF=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJm=''
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDT={}
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/cf/deeplink/'+gn_str
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   if not('url' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy):return bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX 
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDo=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['url']
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ=urllib.parse.urlsplit(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDo).path
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmq(urllib.parse.parse_qsl(urllib.parse.urlsplit(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDo).query))
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['came']=came_str 
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['limit']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.LIST_LIMIT)
   if 'contenttype' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM:bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['contenttype']
   if came_str=='movie':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['mtype']='svod'
   if page_int!=1:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['offset']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE((page_int-1)*bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.LIST_LIMIT)
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['page'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE(page_int)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.HTTPTAG+bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM.update(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   if not('celllist' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']):return bGcRpVuNUhOvxzlIrWPwdkjBsYHtDg,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf 
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDa=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['celllist']
   if(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn=='channel' and came_str=='live'):
    if('genre' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM):
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDQ=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['genre']
    else:
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDQ='all'
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi("*epgcall*")
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDT=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetEPGList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDQ)
   for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDa:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDA=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDy=thumbnail=''
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDA=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('title_list')[0].get('text')
    if(bGcRpVuNUhOvxzlIrWPwdkjBsYHtmn(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('title_list'))>1):
     if(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('title_list')[1].get('text').startswith('@')):
      for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDS in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('bottom_taglist'):
       if bGcRpVuNUhOvxzlIrWPwdkjBsYHtDS=='playy' or bGcRpVuNUhOvxzlIrWPwdkjBsYHtDS=='won':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDy=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDS
     else:
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtDy=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('title_list')[1].get('text')
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtDy=re.sub(r'(\$O\$)|(\&[a-z]{2}\;)','',bGcRpVuNUhOvxzlIrWPwdkjBsYHtDy)
    if(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('thumbnail')!=''):thumbnail='https://%s'%bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('thumbnail')
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJC=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL['event_list'][1].get('url')
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmq(urllib.parse.parse_qsl(urllib.parse.urlsplit(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJC).query))
    if re.search(u'programid=\&',bGcRpVuNUhOvxzlIrWPwdkjBsYHtJC)and('contentid' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD):
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD['contentid']
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJF='direct'
    elif('contentid' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD):
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD['contentid']
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJF='contentid'
    elif('programid' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD):
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD['programid']
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJF='programid'
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn ='program' 
    elif('channelid' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD):
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD['channelid']
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJF='channelid'
     if bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDT:
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJm=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDT[bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq]
     else:
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJm=''
    elif('movieid' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD):
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD['movieid']
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJF='movieid'
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn='movie' 
    else:
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq ='-'
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJF='-'
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX={}
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mpaa'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('age')
    try:
     if('channelid' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD):
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mediatype'] ='video'
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['title'] ='%s < %s >'%(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDA,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDy)
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['tvshowtitle']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDy
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['studio'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDA
     elif('movieid' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJD):
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mediatype'] ='movie'
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['title'] =title_list
     else:
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mediatype'] ='episode'
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['title'] =title_list
    except:
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDK={'title':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDA,'subtitle':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDy,'thumbnail':thumbnail,'uicode':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn,'contentid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq,'contentidType':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJF,'viewage':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('age'),'channelepg':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJm,'info':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX}
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDg.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDK)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['pagecount'])
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['count']:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL =bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['count'])
   else:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.LIST_LIMIT
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi>bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
  try:
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtDg[0].get('contentidType')=='movieid' and addinfoyn==bGcRpVuNUhOvxzlIrWPwdkjBsYHtmK:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe=[]
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE={}
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtJK in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDg:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJK.get('contentid'))
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetMovieInfoList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe)
    for i in bGcRpVuNUhOvxzlIrWPwdkjBsYHtme(bGcRpVuNUhOvxzlIrWPwdkjBsYHtmn(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDg)):
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDg[i]['info']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE.get(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDg[i]['contentid'])
  except:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX
  return(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDg,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf)
 def GetEpisodeList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn,bGcRpVuNUhOvxzlIrWPwdkjBsYHtJF,page_int,orderby='desc'):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtJg=[]
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL=1
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtJF=='contentid':
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/cf/vod/contents/'+bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
    if not('programid' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy):return bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX 
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJn=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['programid']
   else:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJn=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/vod/programs-contents/'+bGcRpVuNUhOvxzlIrWPwdkjBsYHtJn
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM={'limit':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.EP_LIMIT,'offset':bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE((page_int-1)*bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.EP_LIMIT),'orderby':orderby}
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM.update(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   if not('list' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy):return bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX 
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtJq=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['list']
   for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJq:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('programtitle')
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJT ='%s회, %s(%s)'%(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('episodenumber'),bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('releasedate'),bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('releaseweekday'))
    if(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('image')!=''):tmp_thumbnail='https://%s'%bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('image')
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJo=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('synopsis')
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJo=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',bGcRpVuNUhOvxzlIrWPwdkjBsYHtJo)
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX={}
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['title'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mediatype']='episode' 
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mpaa'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('targetage')
    try:
     if 'episodenumber' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['episode'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('episodenumber')
     if 'releasedate' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['year'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('releasedate')[:4])
     if 'releasedate' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['aired'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('releasedate')
     if 'playtime' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['duration']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('playtime')
     if 'episodeactors' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL:
      if bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('episodeactors')!='':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['cast']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('episodeactors').split(',')
    except:
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJM={'title':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf,'subtitle':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJT,'thumbnail':tmp_thumbnail,'uicode':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn,'contentid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('contentid'),'programid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('programid'),'synopsis':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJo,'viewage':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('targetage'),'info':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX}
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJg.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJM)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['pagecount'])
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['count']:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL =bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['count'])
   else:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.EP_LIMIT
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi>bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
  return(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJg,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf)
 def GetMyviewList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn,page_int,addinfoyn=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtJa=[]
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL=1
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/myview/contents'
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM={'contenttype':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn,'limit':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.MV_LIMIT,'offset':bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE((page_int-1)*bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.MV_LIMIT),'orderby':'new'}
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM.update(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   if not('list' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy[0]):return bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX 
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtJQ=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy[0]['list']
   for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJQ:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX={}
    if bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn=='vod':
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('programtitle')
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJT='%s회, %s'%(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('episodenumber'),bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('releasedate'))
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('contentid')
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJn=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('programid')
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['title'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mediatype']='episode' 
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mpaa'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('targetage')
     try:
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['studio'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('channelname')
     except:
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX
     try:
      if 'releasedate' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['year'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('releasedate')[:4])
      if 'releasedate' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['aired'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('releasedate')
     except:
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX
    else:
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('title')
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJT='' 
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJn=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('movieid')
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['title'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mediatype']='movie' 
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mpaa'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('targetage')
     try:
      if 'releasedate' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['year'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('releasedate')[:4])
      if 'releasedate' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['aired'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('releasedate')
     except:
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX
    if(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('image')!=''):tmp_thumbnail='https://%s'%bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('image')
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA={'title':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf,'subtitle':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJT,'thumbnail':tmp_thumbnail,'uicode':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn,'contentid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq,'programid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJn,'viewage':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('targetage'),'info':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX}
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJa.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy[0]['pagecount'])
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy[0]['count']:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL =bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy[0]['count'])
   else:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.MV_LIMIT
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi>bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
  try:
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn=='movie' and addinfoyn==bGcRpVuNUhOvxzlIrWPwdkjBsYHtmK:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe=[]
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE={}
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtJK in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJa:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJK.get('contentid'))
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetMovieInfoList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe)
    for i in bGcRpVuNUhOvxzlIrWPwdkjBsYHtme(bGcRpVuNUhOvxzlIrWPwdkjBsYHtmn(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJa)):
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJa[i]['info']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE.get(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJa[i]['contentid'])
  except:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtJa,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf
 def GetSearchList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,search_key,genre,page_int,exclusion21=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL,addinfoyn=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtJS=[]
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL=1
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/cf/search/list.js'
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM={'type':'program' if genre=='vod' else 'movie','keyword':search_key,'offset':bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE((page_int-1)*bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.LIST_LIMIT),'limit':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.LIST_LIMIT,'orderby':'score','isplayymovie':'y'}
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM.update(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   if not('celllist' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']):return bGcRpVuNUhOvxzlIrWPwdkjBsYHtJS,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtJy=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['celllist']
   for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJy:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX={}
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL['title_list'][0]['text']
    if(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('thumbnail')!=''):tmp_thumbnail='https://%s'%bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('thumbnail')
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDE in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL['event_list'][0]['bodylist']:
     if re.search(r'uicode:',bGcRpVuNUhOvxzlIrWPwdkjBsYHtDE):
      if genre=='vod':
       bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq=''
       bGcRpVuNUhOvxzlIrWPwdkjBsYHtJn=re.sub(r'uicode:','',bGcRpVuNUhOvxzlIrWPwdkjBsYHtDE)
       bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mediatype']='episode' 
      else:
       bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq=re.sub(r'uicode:','',bGcRpVuNUhOvxzlIrWPwdkjBsYHtDE)
       bGcRpVuNUhOvxzlIrWPwdkjBsYHtJn=''
       if bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('bottom_taglist')[0]=='playy':
        bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf+=' [playy]'
       bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mediatype']='movie' 
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['title'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL['title_list'][0]['text']
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mpaa'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('age')
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA={'title':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf,'thumbnail':tmp_thumbnail,'uicode':genre,'contentid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq,'programid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJn,'viewage':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('age'),'info':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX}
    if exclusion21==bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL or bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('age')!='21':
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJS.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['pagecount'])
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['count']:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL =bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['count'])
   else:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.LIST_LIMIT
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi>bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
  try:
   if genre=='movie' and addinfoyn==bGcRpVuNUhOvxzlIrWPwdkjBsYHtmK:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe=[]
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE={}
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtJK in bGcRpVuNUhOvxzlIrWPwdkjBsYHtJS:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJK.get('contentid'))
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetMovieInfoList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe)
    for i in bGcRpVuNUhOvxzlIrWPwdkjBsYHtme(bGcRpVuNUhOvxzlIrWPwdkjBsYHtmn(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJS)):
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJS[i]['info']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE.get(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJS[i]['contentid'])
  except:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtJS,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf 
 def GetGenreGroup(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,maintype,subtype,bGcRpVuNUhOvxzlIrWPwdkjBsYHtJi,ordernm,exclusion21=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC=[]
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/cf/filters'
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM={'type':maintype}
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM.update(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   if not(maintype in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy):return bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX 
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtFD=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy[maintype]
   if subtype=='-':
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL in bGcRpVuNUhOvxzlIrWPwdkjBsYHtFD:
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmq(urllib.parse.parse_qsl(urllib.parse.urlsplit(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('url')).query))
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA={'title':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('text'),'genre':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('id'),'subgenre':'-','adult':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('adult'),'broadcastid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ.get('broadcastid'),'contenttype':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ.get('contenttype'),'uiparent':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ.get('uiparent'),'uirank':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ.get('uirank'),'uitype':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ.get('uitype'),'orderby':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJi,'ordernm':ordernm}
     if exclusion21==bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL or bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA.get('adult')=='n':
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA)
   else:
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL in bGcRpVuNUhOvxzlIrWPwdkjBsYHtFD:
     if bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('id')==subtype:
      for tt in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL['sublist']:
       bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmq(urlparse.parse_qsl(urlparse.urlsplit(tt.get('url')).query))
       bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA={'title':tt.get('text'),'genre':subtype,'subgenre':tt.get('id'),'adult':tt.get('adult'),'broadcastid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ.get('broadcastid'),'contenttype':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ.get('contenttype'),'uiparent':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ.get('uiparent'),'uirank':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ.get('uirank'),'uitype':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFJ.get('uitype'),'orderby':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJi,'ordernm':ordernm}
       bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA)
      break
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC
 def GetGenreGroup_sub(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,in_params):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC=[]
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/cf/vod/newcontents'
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM={'WeekDay':'all','limit':'20','offset':'0','orderby':in_params.get('orderby'),'adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM.update(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   if not('filter_item_list' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['filter']['filterlist'][1]):return bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX 
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtFD=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['filter']['filterlist'][1]['filter_item_list']
   for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL in bGcRpVuNUhOvxzlIrWPwdkjBsYHtFD:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA={'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype'),'adult':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('adult'),'title':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('title'),'subgenre':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('api_parameters')[bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('api_parameters').find('=')+1:],'orderby':in_params.get('orderby')}
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA)
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC
 def GetGenreList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,genre,in_params,page_int,addinfoyn=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC=[]
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL=1
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmL
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM={'WeekDay':'all','adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'orderby':in_params.get('orderby'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   if genre=='vodgenre':
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/cf/vod/newcontents'
    if in_params.get('subgenre')!='-':
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['subgenre']=in_params.get('subgenre')
   else:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/cf/movie/contents'
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['price'] ='all'
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['sptheme']='svod' 
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['limit']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.LIST_LIMIT
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['offset']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE((page_int-1)*bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.LIST_LIMIT)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM['page'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE(page_int)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM.update(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   if not('celllist' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']):return bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX 
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtFD=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['celllist']
   for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL in bGcRpVuNUhOvxzlIrWPwdkjBsYHtFD:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX={}
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf=tmp_thumbnail=''
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL['title_list'][0]['text']
    if(bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('thumbnail')!=''):tmp_thumbnail='https://%s'%bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('thumbnail')
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDE in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL['event_list'][0]['bodylist']:
     if re.search(r'uicode:',bGcRpVuNUhOvxzlIrWPwdkjBsYHtDE):
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['title'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mpaa'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('age')
      if genre=='moviegenre_svod':
       bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mediatype']='movie' 
      else:
       bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mediatype']='episode' 
      bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA={'title':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJf,'uicode':re.sub(r'uicode:','',bGcRpVuNUhOvxzlIrWPwdkjBsYHtDE),'thumbnail':tmp_thumbnail,'viewage':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL.get('age'),'info':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX}
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJA)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['pagecount'])
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['count']:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL =bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['cell_toplist']['count'])
   else:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.LIST_LIMIT
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDi>bGcRpVuNUhOvxzlIrWPwdkjBsYHtJL
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
  try:
   if genre=='moviegenre_svod' and addinfoyn==bGcRpVuNUhOvxzlIrWPwdkjBsYHtmK:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe=[]
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE={}
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtJK in bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC:bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJK.get('uicode'))
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetMovieInfoList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtJe)
    for i in bGcRpVuNUhOvxzlIrWPwdkjBsYHtme(bGcRpVuNUhOvxzlIrWPwdkjBsYHtmn(bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC)):
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC[i]['info']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJE.get(bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC[i]['uicode'])
  except:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDf
 def Get_Now_Datetime(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetEPGList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,genre):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtFX={}
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtFL=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.Get_Now_Datetime()
   if genre=='all':
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFe =bGcRpVuNUhOvxzlIrWPwdkjBsYHtFL+datetime.timedelta(hours=2)
   else:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFe =bGcRpVuNUhOvxzlIrWPwdkjBsYHtFL+datetime.timedelta(hours=3)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM={'limit':'100','offset':'0','genre':genre,'startdatetime':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFL.strftime('%Y-%m-%d %H:%M'),'enddatetime':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFe.strftime('%Y-%m-%d %H:%M')}
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/live/epgs'
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM.update(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtFE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['list']
   for bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL in bGcRpVuNUhOvxzlIrWPwdkjBsYHtFE:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFK=''
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtFg in bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL['list']:
     if bGcRpVuNUhOvxzlIrWPwdkjBsYHtFK:bGcRpVuNUhOvxzlIrWPwdkjBsYHtFK+='\n'
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtFK+=bGcRpVuNUhOvxzlIrWPwdkjBsYHtFg['title'].replace('&lt;','<').replace('&gt;','>')+'\n'
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtFK+=' [%s ~ %s]'%(bGcRpVuNUhOvxzlIrWPwdkjBsYHtFg['starttime'][-5:],bGcRpVuNUhOvxzlIrWPwdkjBsYHtFg['endtime'][-5:])+'\n'
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFX[bGcRpVuNUhOvxzlIrWPwdkjBsYHtDL['channelid']]=bGcRpVuNUhOvxzlIrWPwdkjBsYHtFK
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtFX
 def GetMovieInfoList(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,movie_list):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtFi={}
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe =bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN+'/movie/contents/'
   for bGcRpVuNUhOvxzlIrWPwdkjBsYHtJK in movie_list:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ+bGcRpVuNUhOvxzlIrWPwdkjBsYHtJK
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX={}
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mediatype']='movie'
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFn=[]
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtFq in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['actors']['list']:bGcRpVuNUhOvxzlIrWPwdkjBsYHtFn.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtFq.get('text'))
    if bGcRpVuNUhOvxzlIrWPwdkjBsYHtFn[0]!='':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['cast']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtFn
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFf=[]
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtFT in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['directors']['list']:bGcRpVuNUhOvxzlIrWPwdkjBsYHtFf.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtFT.get('text'))
    if bGcRpVuNUhOvxzlIrWPwdkjBsYHtFf[0]!='':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['director']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtFf
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC=[]
    for bGcRpVuNUhOvxzlIrWPwdkjBsYHtFo in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['genre']['list']:bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtFo.get('text'))
    if bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC[0]!='':bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['genre']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtFC
    if bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy.get('releasedate')!='':
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['year'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['releasedate'][:4]
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['aired'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['releasedate']
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['country']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['country']
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['duration']=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['playtime']
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['title'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['title']
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['mpaa'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['targetage']
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX['plot'] =bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['synopsis']
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFi[bGcRpVuNUhOvxzlIrWPwdkjBsYHtJK]=bGcRpVuNUhOvxzlIrWPwdkjBsYHtJX
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   return{}
  return bGcRpVuNUhOvxzlIrWPwdkjBsYHtFi
 def GetStreamingURL(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq,bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn,quality_int):
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtFM=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmD=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmJ=streaming_preview=''
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtFa=[]
  try:
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn=='channel':
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/live/channels/'+bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFQ='live'
   elif bGcRpVuNUhOvxzlIrWPwdkjBsYHtDn=='movie':
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/cf/movie/contents/'+bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFQ='movie'
   else: 
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/cf/vod/contents/'+bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFQ='vod'
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetDefaultParams()
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtFA=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['qualities']['list']
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtFA==bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX:return(bGcRpVuNUhOvxzlIrWPwdkjBsYHtFM,bGcRpVuNUhOvxzlIrWPwdkjBsYHtmD,bGcRpVuNUhOvxzlIrWPwdkjBsYHtmJ,streaming_preview)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtFS='hls'
   if 'drms' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy:
    if bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['drms']:
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtFS='dash'
   if 'type' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy:
    if bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['type']=='onair':
     bGcRpVuNUhOvxzlIrWPwdkjBsYHtFQ='onairvod'
   for bGcRpVuNUhOvxzlIrWPwdkjBsYHtFy in bGcRpVuNUhOvxzlIrWPwdkjBsYHtFA:
    bGcRpVuNUhOvxzlIrWPwdkjBsYHtFa.append(bGcRpVuNUhOvxzlIrWPwdkjBsYHtmf(bGcRpVuNUhOvxzlIrWPwdkjBsYHtFy.get('id').rstrip('p')))
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   return(bGcRpVuNUhOvxzlIrWPwdkjBsYHtFM,bGcRpVuNUhOvxzlIrWPwdkjBsYHtmD,bGcRpVuNUhOvxzlIrWPwdkjBsYHtmJ,streaming_preview)
  try:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmC=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.CheckQuality(quality_int,bGcRpVuNUhOvxzlIrWPwdkjBsYHtFa)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ='/streaming'
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM={'contentid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtDq,'contenttype':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFQ,'action':bGcRpVuNUhOvxzlIrWPwdkjBsYHtFS,'quality':bGcRpVuNUhOvxzlIrWPwdkjBsYHtmE(bGcRpVuNUhOvxzlIrWPwdkjBsYHtmC)+'p','deviceModelId':'Windows 10','guid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.GetGUID(guidType=2),'lastplayid':bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.guid,'authtype':'cookie','isabr':'y','ishevc':'n'}
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.makeurl(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.API_DOMAIN,bGcRpVuNUhOvxzlIrWPwdkjBsYHtCQ)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM.update(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCe)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCF.callRequestCookies('Get',bGcRpVuNUhOvxzlIrWPwdkjBsYHtCE,payload=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,params=bGcRpVuNUhOvxzlIrWPwdkjBsYHtDM,headers=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX,cookies=bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy=json.loads(bGcRpVuNUhOvxzlIrWPwdkjBsYHtCS.text)
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtFM=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['playurl']
   if bGcRpVuNUhOvxzlIrWPwdkjBsYHtFM==bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX:return bGcRpVuNUhOvxzlIrWPwdkjBsYHtmX
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmD=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['awscookie']
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmJ =bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['drm']
   if 'previewmsg' in bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['preview']:streaming_preview=bGcRpVuNUhOvxzlIrWPwdkjBsYHtCy['preview']['previewmsg']
  except bGcRpVuNUhOvxzlIrWPwdkjBsYHtmg as exception:
   bGcRpVuNUhOvxzlIrWPwdkjBsYHtmi(exception)
  bGcRpVuNUhOvxzlIrWPwdkjBsYHtFM=bGcRpVuNUhOvxzlIrWPwdkjBsYHtFM.replace('pooq.co.kr','wavve.com')
  return(bGcRpVuNUhOvxzlIrWPwdkjBsYHtFM,bGcRpVuNUhOvxzlIrWPwdkjBsYHtmD,bGcRpVuNUhOvxzlIrWPwdkjBsYHtmJ,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
