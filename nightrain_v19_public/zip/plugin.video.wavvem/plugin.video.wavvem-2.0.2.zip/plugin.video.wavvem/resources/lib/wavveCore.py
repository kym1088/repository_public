__author__="NightRain"
mMQnSdiXKFNwHVuPhpTGYUWDgIsxBR=object
mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf=None
mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq=False
mMQnSdiXKFNwHVuPhpTGYUWDgIsxBa=range
mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO=str
mMQnSdiXKFNwHVuPhpTGYUWDgIsxBc=True
mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe=Exception
mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC=print
mMQnSdiXKFNwHVuPhpTGYUWDgIsxBy=len
mMQnSdiXKFNwHVuPhpTGYUWDgIsxBE=dict
mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk=int
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
mMQnSdiXKFNwHVuPhpTGYUWDgIsxlL='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
class mMQnSdiXKFNwHVuPhpTGYUWDgIsxlJ(mMQnSdiXKFNwHVuPhpTGYUWDgIsxBR):
 def __init__(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN='https://apis.pooq.co.kr'
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.APIKEY='E5F3E0D30947AA5440556471321BB6D9'
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.CREDENTIAL='none'
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.DEVICE='pc'
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.DRM='wm'
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.PARTNER='pooq'
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.POOQZONE='none'
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.REGION='kor'
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.TARGETAGE ='all'
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.HTTPTAG='https://'
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.LIST_LIMIT=30 
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.EP_LIMIT=30 
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.MV_LIMIT=24 
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.guid='none' 
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.guidtimestamp='none' 
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.DEFAULT_HEADER={'user-agent':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlL}
 def callRequestCookies(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,jobtype,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,redirects=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlB=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.DEFAULT_HEADER
  if headers:mMQnSdiXKFNwHVuPhpTGYUWDgIsxlB.update(headers)
  if jobtype=='Get':
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlf=requests.get(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,params=params,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlB,cookies=cookies,allow_redirects=redirects)
  else:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlf=requests.post(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,data=payload,params=params,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlB,cookies=cookies,allow_redirects=redirects)
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxlf
 def SaveCredential(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlq):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.CREDENTIAL=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlq
 def LoadCredential(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR):
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.CREDENTIAL
 def GetDefaultParams(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxla={'apikey':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.APIKEY,'credential':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.CREDENTIAL,'device':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.DEVICE,'drm':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.DRM,'partner':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.PARTNER,'pooqzone':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.POOQZONE,'region':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.REGION,'targetage':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.TARGETAGE}
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxla
 def makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,domain,path,query1=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,query2=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=domain+path
  if query1:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO+='&%s'%urllib.parse.urlencode(query2)
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO
 def GetGUID(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlC=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxly=GenerateRandomString(5)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlE=mMQnSdiXKFNwHVuPhpTGYUWDgIsxly+media+mMQnSdiXKFNwHVuPhpTGYUWDgIsxlC
   return mMQnSdiXKFNwHVuPhpTGYUWDgIsxlE
  def GenerateRandomString(num):
   from random import randint
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlk=""
   for i in mMQnSdiXKFNwHVuPhpTGYUWDgIsxBa(0,num):
    s=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO(randint(1,5))
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlk+=s
   return mMQnSdiXKFNwHVuPhpTGYUWDgIsxlk
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlE=GenerateID(guid_str)
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlj=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetHash(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlE)
  if guidType==2:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlj='%s-%s-%s-%s-%s'%(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlj[:8],mMQnSdiXKFNwHVuPhpTGYUWDgIsxlj[8:12],mMQnSdiXKFNwHVuPhpTGYUWDgIsxlj[12:16],mMQnSdiXKFNwHVuPhpTGYUWDgIsxlj[16:20],mMQnSdiXKFNwHVuPhpTGYUWDgIsxlj[20:])
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxlj
 def GetHash(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO(m.hexdigest())
 def CheckQuality(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,sel_qt,qt_list):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlz=0
  for mMQnSdiXKFNwHVuPhpTGYUWDgIsxlt in qt_list:
   if sel_qt>=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlt:return mMQnSdiXKFNwHVuPhpTGYUWDgIsxlt
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlz=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlt
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxlz
 def GetCredential(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,user_id,user_pw,user_pf):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlr=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/login'
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlv={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Post',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlv,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxla,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlq=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['credential']
   if user_pf!=0:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlv={'id':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlq,'password':'','profile':mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO(user_pf),'pushid':'','type':'credential'}
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxla['credential']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlq 
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Post',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlv,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxla,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlq=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['credential']
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxlq:mMQnSdiXKFNwHVuPhpTGYUWDgIsxlr=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBc
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlq='none' 
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.SaveCredential(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlq)
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxlr
 def GetIssue(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJl=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/guid/issue'
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxla,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJL=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['guid']
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJR=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['guidtimestamp']
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxJL:mMQnSdiXKFNwHVuPhpTGYUWDgIsxJl=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBc
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJL='none'
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJR='none' 
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.guid=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJL
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.guidtimestamp=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJR
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxJl
 def GetGnList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,gn_str):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJB=[]
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/cf/supermultisections/'+gn_str
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxla,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   if not('multisectionlist' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA):return mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf 
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJf=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['multisectionlist']
   for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJf:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJa=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq['title']
    if mMQnSdiXKFNwHVuPhpTGYUWDgIsxBy(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJa)==0:continue
    if mMQnSdiXKFNwHVuPhpTGYUWDgIsxJa=='minor':continue 
    if re.search(u'베너',mMQnSdiXKFNwHVuPhpTGYUWDgIsxJa):continue
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJa=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',mMQnSdiXKFNwHVuPhpTGYUWDgIsxJa)
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJa=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJa.lstrip('#')
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJO in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq['eventlist'][0]['bodylist']:
     if re.search(r'uicode:',mMQnSdiXKFNwHVuPhpTGYUWDgIsxJO):
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxJc={'title':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJa,'uicode':re.sub(r'uicode:','',mMQnSdiXKFNwHVuPhpTGYUWDgIsxJO)}
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxJB.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJc)
      break
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxJB
 def GetDeeplinkList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,gn_str,came_str,page_int,addinfoyn=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJe=[]
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq=1
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy='quick'
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLR=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLB=''
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJj={}
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/cf/deeplink/'+gn_str
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxla,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   if not('url' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA):return mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf 
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJz=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['url']
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb=urllib.parse.urlsplit(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJz).path
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBE(urllib.parse.parse_qsl(urllib.parse.urlsplit(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJz).query))
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['came']=came_str 
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['limit']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.LIST_LIMIT)
   if 'contenttype' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt:mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['contenttype']
   if came_str=='movie':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['mtype']='svod'
   if page_int!=1:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['offset']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO((page_int-1)*mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.LIST_LIMIT)
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['page'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO(page_int)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.HTTPTAG+mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt.update(mMQnSdiXKFNwHVuPhpTGYUWDgIsxla)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   if not('celllist' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']):return mMQnSdiXKFNwHVuPhpTGYUWDgIsxJe,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk 
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJr=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['celllist']
   if(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy=='channel' and came_str=='live'):
    if('genre' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt):
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJb=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['genre']
    else:
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJb='all'
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC("*epgcall*")
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJj=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetEPGList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJb)
   for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJr:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJv=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJA=thumbnail=''
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJv=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('title_list')[0].get('text')
    if(mMQnSdiXKFNwHVuPhpTGYUWDgIsxBy(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('title_list'))>1):
     if(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('title_list')[1].get('text').startswith('@')):
      for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJo in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('bottom_taglist'):
       if mMQnSdiXKFNwHVuPhpTGYUWDgIsxJo=='playy' or mMQnSdiXKFNwHVuPhpTGYUWDgIsxJo=='won':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJA=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJo
     else:
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxJA=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('title_list')[1].get('text')
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxJA=re.sub(r'(\$O\$)|(\&[a-z]{2}\;)','',mMQnSdiXKFNwHVuPhpTGYUWDgIsxJA)
    if(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('thumbnail')!=''):thumbnail='https://%s'%mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('thumbnail')
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLl=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq['event_list'][1].get('url')
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBE(urllib.parse.parse_qsl(urllib.parse.urlsplit(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLl).query))
    if re.search(u'programid=\&',mMQnSdiXKFNwHVuPhpTGYUWDgIsxLl)and('contentid' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ):
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ['contentid']
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLR='direct'
    elif('contentid' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ):
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ['contentid']
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLR='contentid'
    elif('programid' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ):
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ['programid']
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLR='programid'
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy ='program' 
    elif('channelid' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ):
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ['channelid']
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLR='channelid'
     if mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJj:
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLB=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJj[mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE]
     else:
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLB=''
    elif('movieid' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ):
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ['movieid']
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLR='movieid'
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy='movie' 
    else:
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE ='-'
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLR='-'
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf={}
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mpaa'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('age')
    try:
     if('channelid' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ):
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mediatype'] ='video'
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['title'] ='%s < %s >'%(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJv,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJA)
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['tvshowtitle']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJA
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['studio'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJv
     elif('movieid' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLJ):
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mediatype'] ='movie'
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['title'] =title_list
     else:
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mediatype'] ='episode'
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['title'] =title_list
    except:
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJc={'title':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJv,'subtitle':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJA,'thumbnail':thumbnail,'uicode':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy,'contentid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE,'contentidType':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLR,'viewage':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('age'),'channelepg':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLB,'info':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf}
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJe.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJc)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['pagecount'])
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['count']:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq =mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['count'])
   else:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.LIST_LIMIT
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC>mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
  try:
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxJe[0].get('contentidType')=='movieid' and addinfoyn==mMQnSdiXKFNwHVuPhpTGYUWDgIsxBc:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa=[]
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO={}
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxLc in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJe:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLc.get('contentid'))
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetMovieInfoList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa)
    for i in mMQnSdiXKFNwHVuPhpTGYUWDgIsxBa(mMQnSdiXKFNwHVuPhpTGYUWDgIsxBy(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJe)):
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJe[i]['info']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO.get(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJe[i]['contentid'])
  except:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf
  return(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJe,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk)
 def GetEpisodeList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy,mMQnSdiXKFNwHVuPhpTGYUWDgIsxLR,page_int,orderby='desc'):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxLe=[]
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq=1
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxLR=='contentid':
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/cf/vod/contents/'+mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxla,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
    if not('programid' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA):return mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf 
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLy=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['programid']
   else:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLy=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/vod/programs-contents/'+mMQnSdiXKFNwHVuPhpTGYUWDgIsxLy
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt={'limit':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.EP_LIMIT,'offset':mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO((page_int-1)*mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.EP_LIMIT),'orderby':orderby}
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt.update(mMQnSdiXKFNwHVuPhpTGYUWDgIsxla)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   if not('list' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA):return mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf 
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxLE=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['list']
   for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLE:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('programtitle')
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLj ='%s회, %s(%s)'%(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('episodenumber'),mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('releasedate'),mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('releaseweekday'))
    if(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('image')!=''):tmp_thumbnail='https://%s'%mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('image')
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLz=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('synopsis')
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLz=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',mMQnSdiXKFNwHVuPhpTGYUWDgIsxLz)
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf={}
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['title'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mediatype']='episode' 
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mpaa'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('targetage')
    try:
     if 'episodenumber' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['episode'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('episodenumber')
     if 'releasedate' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['year'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('releasedate')[:4])
     if 'releasedate' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['aired'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('releasedate')
     if 'playtime' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['duration']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('playtime')
     if 'episodeactors' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq:
      if mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('episodeactors')!='':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['cast']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('episodeactors').split(',')
    except:
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLt={'title':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk,'subtitle':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLj,'thumbnail':tmp_thumbnail,'uicode':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy,'contentid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('contentid'),'programid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('programid'),'synopsis':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLz,'viewage':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('targetage'),'info':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf}
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLe.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLt)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['pagecount'])
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['count']:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq =mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['count'])
   else:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.EP_LIMIT
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC>mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
  return(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLe,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk)
 def GetMyviewList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy,page_int,addinfoyn=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxLr=[]
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq=1
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/myview/contents'
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt={'contenttype':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy,'limit':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.MV_LIMIT,'offset':mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO((page_int-1)*mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.MV_LIMIT),'orderby':'new'}
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt.update(mMQnSdiXKFNwHVuPhpTGYUWDgIsxla)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   if not('list' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA[0]):return mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf 
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxLb=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA[0]['list']
   for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLb:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf={}
    if mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy=='vod':
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('programtitle')
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLj='%s회, %s'%(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('episodenumber'),mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('releasedate'))
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('contentid')
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLy=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('programid')
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['title'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mediatype']='episode' 
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mpaa'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('targetage')
     try:
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['studio'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('channelname')
     except:
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf
     try:
      if 'releasedate' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['year'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('releasedate')[:4])
      if 'releasedate' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['aired'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('releasedate')
     except:
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf
    else:
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('title')
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLj='' 
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLy=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('movieid')
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['title'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mediatype']='movie' 
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mpaa'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('targetage')
     try:
      if 'releasedate' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['year'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('releasedate')[:4])
      if 'releasedate' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['aired'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('releasedate')
     except:
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf
    if(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('image')!=''):tmp_thumbnail='https://%s'%mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('image')
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv={'title':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk,'subtitle':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLj,'thumbnail':tmp_thumbnail,'uicode':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy,'contentid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE,'programid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLy,'viewage':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('targetage'),'info':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf}
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLr.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA[0]['pagecount'])
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA[0]['count']:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq =mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA[0]['count'])
   else:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.MV_LIMIT
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC>mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
  try:
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy=='movie' and addinfoyn==mMQnSdiXKFNwHVuPhpTGYUWDgIsxBc:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa=[]
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO={}
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxLc in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLr:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLc.get('contentid'))
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetMovieInfoList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa)
    for i in mMQnSdiXKFNwHVuPhpTGYUWDgIsxBa(mMQnSdiXKFNwHVuPhpTGYUWDgIsxBy(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLr)):
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLr[i]['info']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO.get(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLr[i]['contentid'])
  except:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxLr,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk
 def GetSearchList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,search_key,genre,page_int,exclusion21=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq,addinfoyn=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxLo=[]
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq=1
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/cf/search/list.js'
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt={'type':'program' if genre=='vod' else 'movie','keyword':search_key,'offset':mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO((page_int-1)*mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.LIST_LIMIT),'limit':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.LIST_LIMIT,'orderby':'score','isplayymovie':'y'}
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt.update(mMQnSdiXKFNwHVuPhpTGYUWDgIsxla)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   if not('celllist' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']):return mMQnSdiXKFNwHVuPhpTGYUWDgIsxLo,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxLA=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['celllist']
   for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLA:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf={}
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq['title_list'][0]['text']
    if(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('thumbnail')!=''):tmp_thumbnail='https://%s'%mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('thumbnail')
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJO in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq['event_list'][0]['bodylist']:
     if re.search(r'uicode:',mMQnSdiXKFNwHVuPhpTGYUWDgIsxJO):
      if genre=='vod':
       mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE=''
       mMQnSdiXKFNwHVuPhpTGYUWDgIsxLy=re.sub(r'uicode:','',mMQnSdiXKFNwHVuPhpTGYUWDgIsxJO)
       mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mediatype']='episode' 
      else:
       mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE=re.sub(r'uicode:','',mMQnSdiXKFNwHVuPhpTGYUWDgIsxJO)
       mMQnSdiXKFNwHVuPhpTGYUWDgIsxLy=''
       if mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('bottom_taglist')[0]=='playy':
        mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk+=' [playy]'
       mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mediatype']='movie' 
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['title'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq['title_list'][0]['text']
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mpaa'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('age')
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv={'title':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk,'thumbnail':tmp_thumbnail,'uicode':genre,'contentid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE,'programid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLy,'viewage':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('age'),'info':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf}
    if exclusion21==mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq or mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('age')!='21':
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLo.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['pagecount'])
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['count']:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq =mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['count'])
   else:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.LIST_LIMIT
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC>mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
  try:
   if genre=='movie' and addinfoyn==mMQnSdiXKFNwHVuPhpTGYUWDgIsxBc:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa=[]
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO={}
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxLc in mMQnSdiXKFNwHVuPhpTGYUWDgIsxLo:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLc.get('contentid'))
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetMovieInfoList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa)
    for i in mMQnSdiXKFNwHVuPhpTGYUWDgIsxBa(mMQnSdiXKFNwHVuPhpTGYUWDgIsxBy(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLo)):
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLo[i]['info']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO.get(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLo[i]['contentid'])
  except:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxLo,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk 
 def GetGenreGroup(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,maintype,subtype,mMQnSdiXKFNwHVuPhpTGYUWDgIsxLC,ordernm,exclusion21=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl=[]
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/cf/filters'
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt={'type':maintype}
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt.update(mMQnSdiXKFNwHVuPhpTGYUWDgIsxla)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   if not(maintype in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA):return mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf 
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxRJ=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA[maintype]
   if subtype=='-':
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq in mMQnSdiXKFNwHVuPhpTGYUWDgIsxRJ:
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBE(urllib.parse.parse_qsl(urllib.parse.urlsplit(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('url')).query))
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv={'title':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('text'),'genre':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('id'),'subgenre':'-','adult':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('adult'),'broadcastid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL.get('broadcastid'),'contenttype':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL.get('contenttype'),'uiparent':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL.get('uiparent'),'uirank':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL.get('uirank'),'uitype':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL.get('uitype'),'orderby':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLC,'ordernm':ordernm}
     if exclusion21==mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq or mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv.get('adult')=='n':
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv)
   else:
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq in mMQnSdiXKFNwHVuPhpTGYUWDgIsxRJ:
     if mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('id')==subtype:
      for tt in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq['sublist']:
       mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBE(urlparse.parse_qsl(urlparse.urlsplit(tt.get('url')).query))
       mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv={'title':tt.get('text'),'genre':subtype,'subgenre':tt.get('id'),'adult':tt.get('adult'),'broadcastid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL.get('broadcastid'),'contenttype':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL.get('contenttype'),'uiparent':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL.get('uiparent'),'uirank':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL.get('uirank'),'uitype':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRL.get('uitype'),'orderby':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLC,'ordernm':ordernm}
       mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv)
      break
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl
 def GetGenreGroup_sub(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,in_params):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl=[]
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/cf/vod/newcontents'
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt={'WeekDay':'all','limit':'20','offset':'0','orderby':in_params.get('orderby'),'adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt.update(mMQnSdiXKFNwHVuPhpTGYUWDgIsxla)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   if not('filter_item_list' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['filter']['filterlist'][1]):return mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf 
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxRJ=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['filter']['filterlist'][1]['filter_item_list']
   for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq in mMQnSdiXKFNwHVuPhpTGYUWDgIsxRJ:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv={'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype'),'adult':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('adult'),'title':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('title'),'subgenre':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('api_parameters')[mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('api_parameters').find('=')+1:],'orderby':in_params.get('orderby')}
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv)
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl
 def GetGenreList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,genre,in_params,page_int,addinfoyn=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl=[]
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq=1
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBq
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt={'WeekDay':'all','adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'orderby':in_params.get('orderby'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   if genre=='vodgenre':
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/cf/vod/newcontents'
    if in_params.get('subgenre')!='-':
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['subgenre']=in_params.get('subgenre')
   else:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/cf/movie/contents'
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['price'] ='all'
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['sptheme']='svod' 
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['limit']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.LIST_LIMIT
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['offset']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO((page_int-1)*mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.LIST_LIMIT)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt['page'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO(page_int)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt.update(mMQnSdiXKFNwHVuPhpTGYUWDgIsxla)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   if not('celllist' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']):return mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf 
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxRJ=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['celllist']
   for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq in mMQnSdiXKFNwHVuPhpTGYUWDgIsxRJ:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf={}
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk=tmp_thumbnail=''
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq['title_list'][0]['text']
    if(mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('thumbnail')!=''):tmp_thumbnail='https://%s'%mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('thumbnail')
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJO in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq['event_list'][0]['bodylist']:
     if re.search(r'uicode:',mMQnSdiXKFNwHVuPhpTGYUWDgIsxJO):
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['title'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mpaa'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('age')
      if genre=='moviegenre_svod':
       mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mediatype']='movie' 
      else:
       mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mediatype']='episode' 
      mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv={'title':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLk,'uicode':re.sub(r'uicode:','',mMQnSdiXKFNwHVuPhpTGYUWDgIsxJO),'thumbnail':tmp_thumbnail,'viewage':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq.get('age'),'info':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf}
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLv)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['pagecount'])
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['count']:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq =mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['cell_toplist']['count'])
   else:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.LIST_LIMIT
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJC>mMQnSdiXKFNwHVuPhpTGYUWDgIsxLq
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
  try:
   if genre=='moviegenre_svod' and addinfoyn==mMQnSdiXKFNwHVuPhpTGYUWDgIsxBc:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa=[]
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO={}
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxLc in mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl:mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLc.get('uicode'))
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetMovieInfoList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxLa)
    for i in mMQnSdiXKFNwHVuPhpTGYUWDgIsxBa(mMQnSdiXKFNwHVuPhpTGYUWDgIsxBy(mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl)):
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl[i]['info']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLO.get(mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl[i]['uicode'])
  except:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJk
 def Get_Now_Datetime(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetEPGList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,genre):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxRf={}
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxRq=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.Get_Now_Datetime()
   if genre=='all':
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRa =mMQnSdiXKFNwHVuPhpTGYUWDgIsxRq+datetime.timedelta(hours=2)
   else:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRa =mMQnSdiXKFNwHVuPhpTGYUWDgIsxRq+datetime.timedelta(hours=3)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt={'limit':'100','offset':'0','genre':genre,'startdatetime':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRq.strftime('%Y-%m-%d %H:%M'),'enddatetime':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRa.strftime('%Y-%m-%d %H:%M')}
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/live/epgs'
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt.update(mMQnSdiXKFNwHVuPhpTGYUWDgIsxla)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxRO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['list']
   for mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq in mMQnSdiXKFNwHVuPhpTGYUWDgIsxRO:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRc=''
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxRe in mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq['list']:
     if mMQnSdiXKFNwHVuPhpTGYUWDgIsxRc:mMQnSdiXKFNwHVuPhpTGYUWDgIsxRc+='\n'
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxRc+=mMQnSdiXKFNwHVuPhpTGYUWDgIsxRe['title']+'\n'
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxRc+=' [%s ~ %s]'%(mMQnSdiXKFNwHVuPhpTGYUWDgIsxRe['starttime'][-5:],mMQnSdiXKFNwHVuPhpTGYUWDgIsxRe['endtime'][-5:])+'\n'
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRf[mMQnSdiXKFNwHVuPhpTGYUWDgIsxJq['channelid']]=mMQnSdiXKFNwHVuPhpTGYUWDgIsxRc
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxRf
 def GetMovieInfoList(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,movie_list):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxRC={}
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla =mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN+'/movie/contents/'
   for mMQnSdiXKFNwHVuPhpTGYUWDgIsxLc in movie_list:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb+mMQnSdiXKFNwHVuPhpTGYUWDgIsxLc
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxla,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf={}
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mediatype']='movie'
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRy=[]
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxRE in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['actors']['list']:mMQnSdiXKFNwHVuPhpTGYUWDgIsxRy.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxRE.get('text'))
    if mMQnSdiXKFNwHVuPhpTGYUWDgIsxRy[0]!='':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['cast']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxRy
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRk=[]
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxRj in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['directors']['list']:mMQnSdiXKFNwHVuPhpTGYUWDgIsxRk.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxRj.get('text'))
    if mMQnSdiXKFNwHVuPhpTGYUWDgIsxRk[0]!='':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['director']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxRk
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl=[]
    for mMQnSdiXKFNwHVuPhpTGYUWDgIsxRz in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['genre']['list']:mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxRz.get('text'))
    if mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl[0]!='':mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['genre']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxRl
    if mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA.get('releasedate')!='':
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['year'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['releasedate'][:4]
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['aired'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['releasedate']
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['country']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['country']
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['duration']=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['playtime']
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['title'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['title']
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['mpaa'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['targetage']
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf['plot'] =mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['synopsis']
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRC[mMQnSdiXKFNwHVuPhpTGYUWDgIsxLc]=mMQnSdiXKFNwHVuPhpTGYUWDgIsxLf
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   return{}
  return mMQnSdiXKFNwHVuPhpTGYUWDgIsxRC
 def GetStreamingURL(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE,mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy,quality_int):
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxRt=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBJ=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBL=streaming_preview=''
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxRr=[]
  try:
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy=='channel':
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/live/channels/'+mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRb='live'
   elif mMQnSdiXKFNwHVuPhpTGYUWDgIsxJy=='movie':
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/cf/movie/contents/'+mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRb='movie'
   else: 
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/cf/vod/contents/'+mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRb='vod'
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxla=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetDefaultParams()
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxla,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxRv=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['qualities']['list']
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxRv==mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf:return(mMQnSdiXKFNwHVuPhpTGYUWDgIsxRt,mMQnSdiXKFNwHVuPhpTGYUWDgIsxBJ,mMQnSdiXKFNwHVuPhpTGYUWDgIsxBL,streaming_preview)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxRo='hls'
   if 'drms' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA:
    if mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['drms']:
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxRo='dash'
   if 'type' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA:
    if mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['type']=='onair':
     mMQnSdiXKFNwHVuPhpTGYUWDgIsxRb='onairvod'
   for mMQnSdiXKFNwHVuPhpTGYUWDgIsxRA in mMQnSdiXKFNwHVuPhpTGYUWDgIsxRv:
    mMQnSdiXKFNwHVuPhpTGYUWDgIsxRr.append(mMQnSdiXKFNwHVuPhpTGYUWDgIsxBk(mMQnSdiXKFNwHVuPhpTGYUWDgIsxRA.get('id').rstrip('p')))
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   return(mMQnSdiXKFNwHVuPhpTGYUWDgIsxRt,mMQnSdiXKFNwHVuPhpTGYUWDgIsxBJ,mMQnSdiXKFNwHVuPhpTGYUWDgIsxBL,streaming_preview)
  try:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBl=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.CheckQuality(quality_int,mMQnSdiXKFNwHVuPhpTGYUWDgIsxRr)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb='/streaming'
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt={'contentid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxJE,'contenttype':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRb,'action':mMQnSdiXKFNwHVuPhpTGYUWDgIsxRo,'quality':mMQnSdiXKFNwHVuPhpTGYUWDgIsxBO(mMQnSdiXKFNwHVuPhpTGYUWDgIsxBl)+'p','deviceModelId':'Windows 10','guid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.GetGUID(guidType=2),'lastplayid':mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.guid,'authtype':'cookie','isabr':'y','ishevc':'n'}
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.makeurl(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.API_DOMAIN,mMQnSdiXKFNwHVuPhpTGYUWDgIsxlb)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt.update(mMQnSdiXKFNwHVuPhpTGYUWDgIsxla)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlR.callRequestCookies('Get',mMQnSdiXKFNwHVuPhpTGYUWDgIsxlO,payload=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,params=mMQnSdiXKFNwHVuPhpTGYUWDgIsxJt,headers=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf,cookies=mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA=json.loads(mMQnSdiXKFNwHVuPhpTGYUWDgIsxlo.text)
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxRt=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['playurl']
   if mMQnSdiXKFNwHVuPhpTGYUWDgIsxRt==mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf:return mMQnSdiXKFNwHVuPhpTGYUWDgIsxBf
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBJ=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['awscookie']
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBL =mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['drm']
   if 'previewmsg' in mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['preview']:streaming_preview=mMQnSdiXKFNwHVuPhpTGYUWDgIsxlA['preview']['previewmsg']
  except mMQnSdiXKFNwHVuPhpTGYUWDgIsxBe as exception:
   mMQnSdiXKFNwHVuPhpTGYUWDgIsxBC(exception)
  mMQnSdiXKFNwHVuPhpTGYUWDgIsxRt=mMQnSdiXKFNwHVuPhpTGYUWDgIsxRt.replace('pooq.co.kr','wavve.com')
  return(mMQnSdiXKFNwHVuPhpTGYUWDgIsxRt,mMQnSdiXKFNwHVuPhpTGYUWDgIsxBJ,mMQnSdiXKFNwHVuPhpTGYUWDgIsxBL,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
