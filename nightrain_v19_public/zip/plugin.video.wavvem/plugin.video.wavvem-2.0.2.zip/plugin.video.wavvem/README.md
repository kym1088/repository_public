# wavveM-v19
웨이브 애드온 for Kodi19


## Version 2.0.2 (2020.09.09)
- timezone

## Version 2.0.1 (2020.09.08)
- 특정스킨 오류 수정

## Version 2.0.0 (2020.08.29)
- python3(kodi 19) 전환



