__author__="NightRain"
RkXHYeUlVscTSwJAdbNEBzxGyOiPpu=object
RkXHYeUlVscTSwJAdbNEBzxGyOiPpq=None
RkXHYeUlVscTSwJAdbNEBzxGyOiPpM=False
RkXHYeUlVscTSwJAdbNEBzxGyOiPpo=open
RkXHYeUlVscTSwJAdbNEBzxGyOiPnj=True
RkXHYeUlVscTSwJAdbNEBzxGyOiPnt=range
RkXHYeUlVscTSwJAdbNEBzxGyOiPnv=str
RkXHYeUlVscTSwJAdbNEBzxGyOiPnD=len
RkXHYeUlVscTSwJAdbNEBzxGyOiPnf=Exception
RkXHYeUlVscTSwJAdbNEBzxGyOiPnL=print
RkXHYeUlVscTSwJAdbNEBzxGyOiPnp=dict
RkXHYeUlVscTSwJAdbNEBzxGyOiPnm=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
RkXHYeUlVscTSwJAdbNEBzxGyOiPjv =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class RkXHYeUlVscTSwJAdbNEBzxGyOiPjt(RkXHYeUlVscTSwJAdbNEBzxGyOiPpu):
 def __init__(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN='https://apis.wavve.com'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV ={}
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Init_WV_Total()
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.DEVICE ='pc'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.DRM ='wm'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.PARTNER ='pooq'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.POOQZONE ='none'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.REGION ='kor'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.TARGETAGE ='all'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.HTTPTAG ='https://'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.LIST_LIMIT=30 
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.EP_LIMIT =30 
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.MV_LIMIT =24 
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.SEARCH_LIMIT=20 
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.DEFAULT_HEADER={'user-agent':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.USER_AGENT}
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.KodiVersion=20
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV_SESSION_COOKIES1=''
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV_SESSION_COOKIES2=''
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.COOKIE_FILE_NAME =''
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV_STREAM_FILENAME =''
 def Init_WV_Total(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV={'account':{},'cookies':{},}
 def callRequestCookies(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,jobtype,RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,redirects=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjf=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.DEFAULT_HEADER
  if headers:RkXHYeUlVscTSwJAdbNEBzxGyOiPjf.update(headers)
  if jobtype=='Get':
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjL=requests.get(RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,params=params,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPjf,cookies=cookies,allow_redirects=redirects)
  else:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjL=requests.post(RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,json=payload,params=params,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPjf,cookies=cookies,allow_redirects=redirects)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPjL
 def JsonFile_Save(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,filename,RkXHYeUlVscTSwJAdbNEBzxGyOiPjp):
  if filename=='':return RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  try:
   fp=RkXHYeUlVscTSwJAdbNEBzxGyOiPpo(filename,'w',-1,'utf-8')
   json.dump(RkXHYeUlVscTSwJAdbNEBzxGyOiPjp,fp,indent=4,ensure_ascii=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM)
   fp.close()
  except:
   return RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPnj
 def JsonFile_Load(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,filename):
  if filename=='':return{}
  try:
   fp=RkXHYeUlVscTSwJAdbNEBzxGyOiPpo(filename,'r',-1,'utf-8')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjm=json.load(fp)
   fp.close()
  except:
   return{}
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPjm
 def TextFile_Save(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,filename,resText):
  if filename=='':return RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  try:
   fp=RkXHYeUlVscTSwJAdbNEBzxGyOiPpo(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPnj
 def Save_session_acount(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPjC,RkXHYeUlVscTSwJAdbNEBzxGyOiPjK,RkXHYeUlVscTSwJAdbNEBzxGyOiPja):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['account']['wvid']=base64.standard_b64encode(RkXHYeUlVscTSwJAdbNEBzxGyOiPjC.encode()).decode('utf-8')
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['account']['wvpw']=base64.standard_b64encode(RkXHYeUlVscTSwJAdbNEBzxGyOiPjK.encode()).decode('utf-8')
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['account']['wvpf']=RkXHYeUlVscTSwJAdbNEBzxGyOiPja 
 def Load_session_acount(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD):
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjC=base64.standard_b64decode(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['account']['wvid']).decode('utf-8')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjK=base64.standard_b64decode(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['account']['wvpw']).decode('utf-8')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPja=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['account']['wvpf']
  except:
   return '','',0
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPjC,RkXHYeUlVscTSwJAdbNEBzxGyOiPjK,RkXHYeUlVscTSwJAdbNEBzxGyOiPja
 def GetDefaultParams(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,login=RkXHYeUlVscTSwJAdbNEBzxGyOiPnj):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'apikey':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.APIKEY,'credential':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['cookies']['credential']if login else 'none','device':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.DEVICE,'drm':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.DRM,'partner':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.PARTNER,'pooqzone':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.POOQZONE,'region':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.REGION,'targetage':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.TARGETAGE,}
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPjh
 def GetDefaultParams_AND(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['cookies']['credential'],'device':'ott','drm':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.DRM,'partner':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.PARTNER,'pooqzone':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.POOQZONE,'region':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.REGION,'targetage':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.TARGETAGE,}
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPjh
 def GetGUID(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjQ=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjW=GenerateRandomString(5)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjr=RkXHYeUlVscTSwJAdbNEBzxGyOiPjW+media+RkXHYeUlVscTSwJAdbNEBzxGyOiPjQ
   return RkXHYeUlVscTSwJAdbNEBzxGyOiPjr
  def GenerateRandomString(num):
   from random import randint
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjg=""
   for i in RkXHYeUlVscTSwJAdbNEBzxGyOiPnt(0,num):
    s=RkXHYeUlVscTSwJAdbNEBzxGyOiPnv(randint(1,5))
    RkXHYeUlVscTSwJAdbNEBzxGyOiPjg+=s
   return RkXHYeUlVscTSwJAdbNEBzxGyOiPjg
  if guidType==3:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjr=guid_str
  else:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjr=GenerateID(guid_str)
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjI=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetHash(RkXHYeUlVscTSwJAdbNEBzxGyOiPjr)
  if guidType in[2,3]:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjI='%s-%s-%s-%s-%s'%(RkXHYeUlVscTSwJAdbNEBzxGyOiPjI[:8],RkXHYeUlVscTSwJAdbNEBzxGyOiPjI[8:12],RkXHYeUlVscTSwJAdbNEBzxGyOiPjI[12:16],RkXHYeUlVscTSwJAdbNEBzxGyOiPjI[16:20],RkXHYeUlVscTSwJAdbNEBzxGyOiPjI[20:])
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPjI
 def GetHash(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPnv(m.hexdigest())
 def CheckQuality(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,sel_qt,qt_list):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjF=0
  for RkXHYeUlVscTSwJAdbNEBzxGyOiPju in qt_list:
   if sel_qt>=RkXHYeUlVscTSwJAdbNEBzxGyOiPju:return RkXHYeUlVscTSwJAdbNEBzxGyOiPju
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjF=RkXHYeUlVscTSwJAdbNEBzxGyOiPju
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPjF
 def Get_Now_Datetime(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,in_text):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjM=in_text.replace('&lt;','<').replace('&gt;','>')
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjM=RkXHYeUlVscTSwJAdbNEBzxGyOiPjM.replace('$O$','')
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjM=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',RkXHYeUlVscTSwJAdbNEBzxGyOiPjM)
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjM=RkXHYeUlVscTSwJAdbNEBzxGyOiPjM.lstrip('#')
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPjM
 def make_str_ToCookie(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,cookieStr):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjo={}
  for RkXHYeUlVscTSwJAdbNEBzxGyOiPtj in cookieStr.split(';'):
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtv=RkXHYeUlVscTSwJAdbNEBzxGyOiPtj.split('=')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjo[RkXHYeUlVscTSwJAdbNEBzxGyOiPtv[0]]=RkXHYeUlVscTSwJAdbNEBzxGyOiPtv[1]
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPjo 
 def make_stream_header(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPtn,RkXHYeUlVscTSwJAdbNEBzxGyOiPjo):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtD=''
  if RkXHYeUlVscTSwJAdbNEBzxGyOiPjo not in[{},RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,'']:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtf=RkXHYeUlVscTSwJAdbNEBzxGyOiPnD(RkXHYeUlVscTSwJAdbNEBzxGyOiPjo)
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPtL,RkXHYeUlVscTSwJAdbNEBzxGyOiPtp in RkXHYeUlVscTSwJAdbNEBzxGyOiPjo.items():
    RkXHYeUlVscTSwJAdbNEBzxGyOiPtD+='{}={}'.format(RkXHYeUlVscTSwJAdbNEBzxGyOiPtL,RkXHYeUlVscTSwJAdbNEBzxGyOiPtp)
    RkXHYeUlVscTSwJAdbNEBzxGyOiPtf+=-1
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPtf>0:RkXHYeUlVscTSwJAdbNEBzxGyOiPtD+='; '
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtn['cookie']=RkXHYeUlVscTSwJAdbNEBzxGyOiPtD
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtm=''
  i=0
  for RkXHYeUlVscTSwJAdbNEBzxGyOiPtL,RkXHYeUlVscTSwJAdbNEBzxGyOiPtp in RkXHYeUlVscTSwJAdbNEBzxGyOiPtn.items():
   i=i+1
   if i>1:RkXHYeUlVscTSwJAdbNEBzxGyOiPtm+='&'
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtm+='{}={}'.format(RkXHYeUlVscTSwJAdbNEBzxGyOiPtL,urllib.parse.quote(RkXHYeUlVscTSwJAdbNEBzxGyOiPtp))
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPtm
 def GetCredential(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,user_id,user_pw,user_pf):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtC=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+ '/login'
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPta={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Post',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPta,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['cookies']['credential']=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['credential']
   if user_pf!=0:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPta={'id':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['cookies']['credential'],'password':'','profile':RkXHYeUlVscTSwJAdbNEBzxGyOiPnv(user_pf),'pushid':'','type':'credential'}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPjh =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPnj) 
    RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Post',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPta,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
    RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
    RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['cookies']['credential']=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['credential']
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtW=user_id+RkXHYeUlVscTSwJAdbNEBzxGyOiPnv(user_pf) 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['cookies']['uuid']=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetGUID(guid_str=RkXHYeUlVscTSwJAdbNEBzxGyOiPtW,guidType=3)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtC=RkXHYeUlVscTSwJAdbNEBzxGyOiPnj
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Init_WV_Total()
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPtC
 def GetIssue(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtr=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/guid/issue'
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams()
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtg=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['guid']
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtI=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['guidtimestamp']
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPtg:RkXHYeUlVscTSwJAdbNEBzxGyOiPtr=RkXHYeUlVscTSwJAdbNEBzxGyOiPnj
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtg='none'
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtI='none' 
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.guid=RkXHYeUlVscTSwJAdbNEBzxGyOiPtg
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.guidtimestamp=RkXHYeUlVscTSwJAdbNEBzxGyOiPtI
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPtr
 def Baseapi_Parse(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPtM):
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtF =urllib.parse.urlsplit(RkXHYeUlVscTSwJAdbNEBzxGyOiPtM)
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPtF.netloc=='':
    RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.HTTPTAG+RkXHYeUlVscTSwJAdbNEBzxGyOiPtF.netloc+RkXHYeUlVscTSwJAdbNEBzxGyOiPtF.path
   else:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPtF.scheme+'://'+RkXHYeUlVscTSwJAdbNEBzxGyOiPtF.netloc+RkXHYeUlVscTSwJAdbNEBzxGyOiPtF.path
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh=RkXHYeUlVscTSwJAdbNEBzxGyOiPnp(urllib.parse.parse_qsl(RkXHYeUlVscTSwJAdbNEBzxGyOiPtF.query))
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return '',{}
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,RkXHYeUlVscTSwJAdbNEBzxGyOiPjh
 def GetSupermultiUrl(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,sCode,sIndex='0'):
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/cf/supermultisections/'+sCode
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtu=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['multisectionlist'][RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(sIndex)]['eventlist'][1]['url']
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return ''
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPtu
 def Get_LiveCatagory_List(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,sCode,sIndex='0'):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtq=[]
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtM =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetSupermultiUrl(sCode,sIndex)
  (RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,RkXHYeUlVscTSwJAdbNEBzxGyOiPjh)=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Baseapi_Parse(RkXHYeUlVscTSwJAdbNEBzxGyOiPtM)
  if RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=='':return RkXHYeUlVscTSwJAdbNEBzxGyOiPtq,''
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if not('filter_item_list' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['filter']['filterlist'][0]):return[],''
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['filter']['filterlist'][0]['filter_item_list']
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPvj:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'title':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title'],'genre':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['api_parameters'][RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['api_parameters'].index('=')+1:]}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPtq.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[],''
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPtq,RkXHYeUlVscTSwJAdbNEBzxGyOiPtM
 def Get_MainCatagory_List(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,sCode,sIndex,sType):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtq=[]
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtK='https://apis.wavve.com/es/category/launcher-band'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if not('celllist' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['band']):return[]
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['band']['celllist']
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPvj:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvf =RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['event_list'][1]['url']
    (RkXHYeUlVscTSwJAdbNEBzxGyOiPvL,RkXHYeUlVscTSwJAdbNEBzxGyOiPvp)=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Baseapi_Parse(RkXHYeUlVscTSwJAdbNEBzxGyOiPvf)
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'title':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title_list'][0]['text'],'suburl':RkXHYeUlVscTSwJAdbNEBzxGyOiPvL,'subapi':RkXHYeUlVscTSwJAdbNEBzxGyOiPvp.get('api'),'subtype':'catagory' if RkXHYeUlVscTSwJAdbNEBzxGyOiPvp else 'supersection'}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPtq.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[]
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPtq
 def Get_SuperMultiSection_List(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,subapi_text):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtq=[]
  if '/multiband/' in subapi_text: 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=subapi_text 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'client':'40'}
  else:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=subapi_text 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPtK.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={}
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if not('multisectionlist' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ):return[]
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['multisectionlist']
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPvj:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvn=RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title']
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPnD(RkXHYeUlVscTSwJAdbNEBzxGyOiPvn)==0:continue
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPvn=='minor':continue
    if re.search(u'베너',RkXHYeUlVscTSwJAdbNEBzxGyOiPvn):continue
    if re.search(u'배너',RkXHYeUlVscTSwJAdbNEBzxGyOiPvn):continue 
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['force_refresh']=='y':continue
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPnD(RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['eventlist'])>=3:
     RkXHYeUlVscTSwJAdbNEBzxGyOiPvp =RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['eventlist'][2]['url']
    else:
     RkXHYeUlVscTSwJAdbNEBzxGyOiPvp =RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['eventlist'][1]['url']
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvm=RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['cell_type']
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPvm=='band_2':
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPvp.find('channellist=')>=0:
      RkXHYeUlVscTSwJAdbNEBzxGyOiPvm='band_live'
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'title':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Get_ChangeText(RkXHYeUlVscTSwJAdbNEBzxGyOiPvn),'subapi':RkXHYeUlVscTSwJAdbNEBzxGyOiPvp,'cell_type':RkXHYeUlVscTSwJAdbNEBzxGyOiPvm}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPtq.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[]
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPtq
 def Get_BandLiveSection_List(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPtM,page_int=1):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvC=[]
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=1
  RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  try:
   (RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,RkXHYeUlVscTSwJAdbNEBzxGyOiPjh)=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Baseapi_Parse(RkXHYeUlVscTSwJAdbNEBzxGyOiPtM)
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[],RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['limit']=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.LIST_LIMIT
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['offset']=RkXHYeUlVscTSwJAdbNEBzxGyOiPnv((page_int-1)*RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.LIST_LIMIT)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if not('celllist' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']):return[],RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['celllist']
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPvj:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvh =RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['event_list'][1]['url']
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ=urllib.parse.urlsplit(RkXHYeUlVscTSwJAdbNEBzxGyOiPvh).query
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ=RkXHYeUlVscTSwJAdbNEBzxGyOiPnp(urllib.parse.parse_qsl(RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ))
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvW='channelid'
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvr=RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ[RkXHYeUlVscTSwJAdbNEBzxGyOiPvW]
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'studio':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title_list'][0]['text'],'tvshowtitle':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Get_ChangeText(RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title_list'][1]['text']),'channelid':RkXHYeUlVscTSwJAdbNEBzxGyOiPvr,'age':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('age'),'thumbnail':'https://%s'%RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('thumbnail')}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvC.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['pagecount'])
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['count']:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg =RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['count'])
   else:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.LIST_LIMIT*page_int
   RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPvK>RkXHYeUlVscTSwJAdbNEBzxGyOiPvg
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[],RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPvC,RkXHYeUlVscTSwJAdbNEBzxGyOiPva
 def Get_Band2Section_List(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPtM,page_int=1):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvI=[]
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=1
  RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  try:
   (RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,RkXHYeUlVscTSwJAdbNEBzxGyOiPjh)=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Baseapi_Parse(RkXHYeUlVscTSwJAdbNEBzxGyOiPtM)
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[],RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['came'] ='BandView'
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['limit']=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.LIST_LIMIT
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['offset']=RkXHYeUlVscTSwJAdbNEBzxGyOiPnv((page_int-1)*RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.LIST_LIMIT)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if not('celllist' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']):return[],RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['celllist']
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPvj:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvh =RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['event_list'][1]['url']
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ=urllib.parse.urlsplit(RkXHYeUlVscTSwJAdbNEBzxGyOiPvh).query
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ=RkXHYeUlVscTSwJAdbNEBzxGyOiPnp(urllib.parse.parse_qsl(RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ))
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvW='contentid'
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvr=RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ[RkXHYeUlVscTSwJAdbNEBzxGyOiPvW]
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'programtitle':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title_list'][0]['text'],'episodetitle':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Get_ChangeText(RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title_list'][1]['text']),'age':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('age'),'thumbnail':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.HTTPTAG+RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('thumbnail'),'vidtype':RkXHYeUlVscTSwJAdbNEBzxGyOiPvW,'videoid':RkXHYeUlVscTSwJAdbNEBzxGyOiPvr}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvI.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['pagecount'])
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['count']:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg =RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['count'])
   else:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.LIST_LIMIT*page_int
   RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPvK>RkXHYeUlVscTSwJAdbNEBzxGyOiPvg
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[],RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPvI,RkXHYeUlVscTSwJAdbNEBzxGyOiPva
 def Get_Program_List(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPtM,page_int=1,orderby='-'):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvF=[]
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=1
  RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  (RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,RkXHYeUlVscTSwJAdbNEBzxGyOiPjh)=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Baseapi_Parse(RkXHYeUlVscTSwJAdbNEBzxGyOiPtM)
  if RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=='':return RkXHYeUlVscTSwJAdbNEBzxGyOiPvF,RkXHYeUlVscTSwJAdbNEBzxGyOiPva
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['limit'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.LIST_LIMIT
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['offset']=RkXHYeUlVscTSwJAdbNEBzxGyOiPnv((page_int-1)*RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.LIST_LIMIT)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['page'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPnv(page_int)
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.get('orderby')!='' and RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.get('orderby')!='regdatefirst' and orderby!='-':
    RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['orderby']=orderby 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ.get('cell_toplist')not in[{},RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,'']:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['celllist']
   elif RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ.get('band')not in[{},RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,'']:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['band']['celllist']
   else:
    return RkXHYeUlVscTSwJAdbNEBzxGyOiPvF,RkXHYeUlVscTSwJAdbNEBzxGyOiPva
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPvj:
    for RkXHYeUlVscTSwJAdbNEBzxGyOiPvu in RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['event_list']:
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPvu.get('type')=='on-navigation':
      RkXHYeUlVscTSwJAdbNEBzxGyOiPvh =RkXHYeUlVscTSwJAdbNEBzxGyOiPvu['url']
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ=urllib.parse.urlsplit(RkXHYeUlVscTSwJAdbNEBzxGyOiPvh).query
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvW=RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ[0:RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ.find('=')]
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvq=RkXHYeUlVscTSwJAdbNEBzxGyOiPnp(urllib.parse.parse_qsl(RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ))
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvr=RkXHYeUlVscTSwJAdbNEBzxGyOiPvq.get(RkXHYeUlVscTSwJAdbNEBzxGyOiPvW)
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'title':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('alt')or RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('title_list')[0].get('text'),'age':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('age'),'thumbnail':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('thumbnail'),'videoid':RkXHYeUlVscTSwJAdbNEBzxGyOiPvr,'vidtype':RkXHYeUlVscTSwJAdbNEBzxGyOiPvW,}
    if not RkXHYeUlVscTSwJAdbNEBzxGyOiPvD.get('thumbnail').startswith('http'):
     RkXHYeUlVscTSwJAdbNEBzxGyOiPvD['thumbnail']='https://%s'%RkXHYeUlVscTSwJAdbNEBzxGyOiPvD['thumbnail']
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvF.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ.get('cell_toplist')not in[{},RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,'']:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['pagecount'])
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['count']:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg =RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['count'])
    else:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.LIST_LIMIT*page_int
    RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPvK>RkXHYeUlVscTSwJAdbNEBzxGyOiPvg
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[],RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPvF,RkXHYeUlVscTSwJAdbNEBzxGyOiPva
 def Get_Movie_List(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPtM,page_int=1,orderby='-'):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvM=[]
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=1
  RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  (RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,RkXHYeUlVscTSwJAdbNEBzxGyOiPjh)=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Baseapi_Parse(RkXHYeUlVscTSwJAdbNEBzxGyOiPtM)
  if RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=='':return RkXHYeUlVscTSwJAdbNEBzxGyOiPvM,RkXHYeUlVscTSwJAdbNEBzxGyOiPva
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['limit']=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.MV_LIMIT
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['offset']=RkXHYeUlVscTSwJAdbNEBzxGyOiPnv((page_int-1)*RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.MV_LIMIT)
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.get('orderby')!='' and RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.get('orderby')!='regdatefirst' and orderby!='-':
    RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['orderby']=orderby 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ.get('cell_toplist')not in[{},RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,'']:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['celllist']
   elif RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ.get('band')not in[{},RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,'']:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['band']['celllist']
   else:
    return RkXHYeUlVscTSwJAdbNEBzxGyOiPvM,RkXHYeUlVscTSwJAdbNEBzxGyOiPva
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPvj:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvh =RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['event_list'][1]['url']
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ=urllib.parse.urlsplit(RkXHYeUlVscTSwJAdbNEBzxGyOiPvh).query
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvW=RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ[0:RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ.find('=')]
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvq=RkXHYeUlVscTSwJAdbNEBzxGyOiPnp(urllib.parse.parse_qsl(RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ))
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvr=RkXHYeUlVscTSwJAdbNEBzxGyOiPvq.get(RkXHYeUlVscTSwJAdbNEBzxGyOiPvW)
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'title':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('alt')or RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('title_list')[0].get('text'),'age':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('age'),'thumbnail':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('thumbnail'),'videoid':RkXHYeUlVscTSwJAdbNEBzxGyOiPvr,'vidtype':RkXHYeUlVscTSwJAdbNEBzxGyOiPvW,}
    if not RkXHYeUlVscTSwJAdbNEBzxGyOiPvD.get('thumbnail').startswith('http'):
     RkXHYeUlVscTSwJAdbNEBzxGyOiPvD['thumbnail']='https://%s'%RkXHYeUlVscTSwJAdbNEBzxGyOiPvD['thumbnail']
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvM.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ.get('cell_toplist')not in[{},RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,'']:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['pagecount'])
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['count']:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg =RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['count'])
    else:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.MV_LIMIT*page_int
    RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPvK>RkXHYeUlVscTSwJAdbNEBzxGyOiPvg
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[],RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPvM,RkXHYeUlVscTSwJAdbNEBzxGyOiPva
 def ProgramidToContentid(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPDt):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvo=''
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/vod/programs-contentid/'+RkXHYeUlVscTSwJAdbNEBzxGyOiPDt
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDj=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if not('contentid' in RkXHYeUlVscTSwJAdbNEBzxGyOiPDj):return RkXHYeUlVscTSwJAdbNEBzxGyOiPvo 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvo=RkXHYeUlVscTSwJAdbNEBzxGyOiPDj['contentid']
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPvo
 def ContentidToSeasonid(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPvo):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPDt=''
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/fz/vod/contents/'+RkXHYeUlVscTSwJAdbNEBzxGyOiPvo
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDj=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if not('programid' in RkXHYeUlVscTSwJAdbNEBzxGyOiPDj):return RkXHYeUlVscTSwJAdbNEBzxGyOiPDt 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDt=RkXHYeUlVscTSwJAdbNEBzxGyOiPDj['programid']
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPDt
 def GetProgramInfo(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPvo):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPDv={}
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/fz/vod/contents/'+RkXHYeUlVscTSwJAdbNEBzxGyOiPvo
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDj=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDf=img_fanart=RkXHYeUlVscTSwJAdbNEBzxGyOiPDL=''
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPDj.get('programposterimage')!='':RkXHYeUlVscTSwJAdbNEBzxGyOiPDf =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.HTTPTAG+RkXHYeUlVscTSwJAdbNEBzxGyOiPDj.get('programposterimage')
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPDj.get('programimage') !='':img_fanart =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.HTTPTAG+RkXHYeUlVscTSwJAdbNEBzxGyOiPDj.get('programimage')
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPDj.get('programcircleimage')!='':RkXHYeUlVscTSwJAdbNEBzxGyOiPDL=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.HTTPTAG+RkXHYeUlVscTSwJAdbNEBzxGyOiPDj.get('programcircleimage')
   if 'poster_default' in RkXHYeUlVscTSwJAdbNEBzxGyOiPDf:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDf =img_fanart
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDL=''
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDv={'imgPoster':RkXHYeUlVscTSwJAdbNEBzxGyOiPDf,'imgFanart':img_fanart,'imgClearlogo':RkXHYeUlVscTSwJAdbNEBzxGyOiPDL,'programtitle':RkXHYeUlVscTSwJAdbNEBzxGyOiPDj.get('programtitle'),'programid':RkXHYeUlVscTSwJAdbNEBzxGyOiPDj.get('programid'),'synopsis':RkXHYeUlVscTSwJAdbNEBzxGyOiPDj.get('programsynopsis').replace('<br>','\n'),}
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPDv
 def Get_Season_List(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,seasonid):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPDp=[]
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvo=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.ProgramidToContentid(seasonid)
  RkXHYeUlVscTSwJAdbNEBzxGyOiPDn=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetProgramInfo(RkXHYeUlVscTSwJAdbNEBzxGyOiPvo)
  RkXHYeUlVscTSwJAdbNEBzxGyOiPDm={'poster':RkXHYeUlVscTSwJAdbNEBzxGyOiPDn.get('imgPoster'),'fanart':RkXHYeUlVscTSwJAdbNEBzxGyOiPDn.get('imgFanart'),'clearlogo':RkXHYeUlVscTSwJAdbNEBzxGyOiPDn.get('imgClearlogo'),}
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'limit':'10','offset':'0','orderby':'new',}
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPDC in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['filter']['filterlist'][0]['filter_item_list']:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'season_Nm':RkXHYeUlVscTSwJAdbNEBzxGyOiPDC.get('title'),'season_Id':RkXHYeUlVscTSwJAdbNEBzxGyOiPDC.get('api_path'),'thumbnail':RkXHYeUlVscTSwJAdbNEBzxGyOiPDm,'programNm':RkXHYeUlVscTSwJAdbNEBzxGyOiPDn.get('programtitle'),'synopsis':RkXHYeUlVscTSwJAdbNEBzxGyOiPDn.get('synopsis'),}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDp.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[]
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPDp
 def Get_Episode_List(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,seasionid,page_int=1,orderby='desc'):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPDK=[]
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=1
  RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  RkXHYeUlVscTSwJAdbNEBzxGyOiPDn={}
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvo=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.ProgramidToContentid(seasionid)
  RkXHYeUlVscTSwJAdbNEBzxGyOiPDn=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetProgramInfo(RkXHYeUlVscTSwJAdbNEBzxGyOiPvo)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'limit':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.EP_LIMIT,'offset':RkXHYeUlVscTSwJAdbNEBzxGyOiPnv((page_int-1)*RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.EP_LIMIT),'orderby':orderby,}
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['celllist']
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPvj:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDh=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('synopsis'))
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDQ=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.HTTPTAG+RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('thumbnail')
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDW=RkXHYeUlVscTSwJAdbNEBzxGyOiPDr=RkXHYeUlVscTSwJAdbNEBzxGyOiPDg=''
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDW =RkXHYeUlVscTSwJAdbNEBzxGyOiPDn.get('imgPoster')
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDr =RkXHYeUlVscTSwJAdbNEBzxGyOiPDn.get('imgFanart')
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDg =RkXHYeUlVscTSwJAdbNEBzxGyOiPDn.get('imgClearlogo')
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDI=RkXHYeUlVscTSwJAdbNEBzxGyOiPDn.get('programtitle')
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDm={'thumb':RkXHYeUlVscTSwJAdbNEBzxGyOiPDQ,'poster':RkXHYeUlVscTSwJAdbNEBzxGyOiPDW,'fanart':RkXHYeUlVscTSwJAdbNEBzxGyOiPDr,'clearlogo':RkXHYeUlVscTSwJAdbNEBzxGyOiPDg}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'programtitle':RkXHYeUlVscTSwJAdbNEBzxGyOiPDI,'episodetitle':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title_list'][0]['text'],'episodenumber':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title_list'][1]['text'].replace('$O$',''),'contentid':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['contentid'],'synopsis':RkXHYeUlVscTSwJAdbNEBzxGyOiPDh,'episodeactors':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('actors').split(',')if RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('actors')!='' else[],'thumbnail':RkXHYeUlVscTSwJAdbNEBzxGyOiPDm,}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDK.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['pagecount'])
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['count']:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg =RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['count'])
   else:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.EP_LIMIT*page_int
   RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPvK>RkXHYeUlVscTSwJAdbNEBzxGyOiPvg
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[],RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPDK,RkXHYeUlVscTSwJAdbNEBzxGyOiPva
 def GetEPGList(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,genre):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPDF={}
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDu=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Get_Now_Datetime()
   if genre=='all':
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDq =RkXHYeUlVscTSwJAdbNEBzxGyOiPDu+datetime.timedelta(hours=3)
   else:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDq =RkXHYeUlVscTSwJAdbNEBzxGyOiPDu+datetime.timedelta(hours=3)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/live/epgs'
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'limit':'100','offset':'0','genre':genre,'startdatetime':RkXHYeUlVscTSwJAdbNEBzxGyOiPDu.strftime('%Y-%m-%d %H:00'),'enddatetime':RkXHYeUlVscTSwJAdbNEBzxGyOiPDq.strftime('%Y-%m-%d %H:00')}
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDM=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['list']
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPDM:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDo=''
    for RkXHYeUlVscTSwJAdbNEBzxGyOiPfj in RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['list']:
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPDo:RkXHYeUlVscTSwJAdbNEBzxGyOiPDo+='\n'
     RkXHYeUlVscTSwJAdbNEBzxGyOiPDo+=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Get_ChangeText(RkXHYeUlVscTSwJAdbNEBzxGyOiPfj['title'])+'\n'
     RkXHYeUlVscTSwJAdbNEBzxGyOiPDo+=' [%s ~ %s]'%(RkXHYeUlVscTSwJAdbNEBzxGyOiPfj['starttime'][-5:],RkXHYeUlVscTSwJAdbNEBzxGyOiPfj['endtime'][-5:])+'\n'
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDF[RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['channelid']]=RkXHYeUlVscTSwJAdbNEBzxGyOiPDo
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPDF
 def Get_LiveChannel_List(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,genre,RkXHYeUlVscTSwJAdbNEBzxGyOiPtM):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvC=[]
  (RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,RkXHYeUlVscTSwJAdbNEBzxGyOiPjh)=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Baseapi_Parse(RkXHYeUlVscTSwJAdbNEBzxGyOiPtM)
  if RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=='':return RkXHYeUlVscTSwJAdbNEBzxGyOiPvC
  RkXHYeUlVscTSwJAdbNEBzxGyOiPft=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetEPGList(genre)
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['genre']=genre
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if not('celllist' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']):return[]
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['celllist']
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPvj:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvo=RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['contentid']
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPvo in RkXHYeUlVscTSwJAdbNEBzxGyOiPft:
     RkXHYeUlVscTSwJAdbNEBzxGyOiPfv=RkXHYeUlVscTSwJAdbNEBzxGyOiPft[RkXHYeUlVscTSwJAdbNEBzxGyOiPvo]
    else:
     RkXHYeUlVscTSwJAdbNEBzxGyOiPfv=''
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'studio':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title_list'][0]['text'],'tvshowtitle':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Get_ChangeText(RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title_list'][1]['text']),'channelid':RkXHYeUlVscTSwJAdbNEBzxGyOiPvo,'age':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['age'],'thumbnail':'https://%s'%RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('thumbnail'),'epg':RkXHYeUlVscTSwJAdbNEBzxGyOiPfv}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvC.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[]
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPvC
 def Get_Search_List(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,search_key,sType,page_int,exclusion21=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPfD=[]
  RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=1
  RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/fz/search/band.js'
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':RkXHYeUlVscTSwJAdbNEBzxGyOiPnv((page_int-1)*RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.SEARCH_LIMIT),'limit':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDj=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if not('celllist' in RkXHYeUlVscTSwJAdbNEBzxGyOiPDj['band']):return RkXHYeUlVscTSwJAdbNEBzxGyOiPfD,RkXHYeUlVscTSwJAdbNEBzxGyOiPva
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPDj['band']['celllist']
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPvj:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvh =RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['event_list'][1]['url']
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ=urllib.parse.urlsplit(RkXHYeUlVscTSwJAdbNEBzxGyOiPvh).query
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvW=RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ[0:RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ.find('=')]
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvq=RkXHYeUlVscTSwJAdbNEBzxGyOiPnp(urllib.parse.parse_qsl(RkXHYeUlVscTSwJAdbNEBzxGyOiPvQ))
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvr=RkXHYeUlVscTSwJAdbNEBzxGyOiPvq.get(RkXHYeUlVscTSwJAdbNEBzxGyOiPvW)
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'title':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['title_list'][0]['text'],'age':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['age'],'thumbnail':'https://%s'%RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('thumbnail'),'videoid':RkXHYeUlVscTSwJAdbNEBzxGyOiPvr,'vidtype':RkXHYeUlVscTSwJAdbNEBzxGyOiPvW,}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPfL=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
    for RkXHYeUlVscTSwJAdbNEBzxGyOiPfp in RkXHYeUlVscTSwJAdbNEBzxGyOiPvt['bottom_taglist']:
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPfp=='won':
      RkXHYeUlVscTSwJAdbNEBzxGyOiPfL=RkXHYeUlVscTSwJAdbNEBzxGyOiPnj
      break
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPfL==RkXHYeUlVscTSwJAdbNEBzxGyOiPnj: 
     RkXHYeUlVscTSwJAdbNEBzxGyOiPvD['title']=RkXHYeUlVscTSwJAdbNEBzxGyOiPvD['title']+' [개별구매]'
    if exclusion21==RkXHYeUlVscTSwJAdbNEBzxGyOiPpM or RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('age')!='21':
     RkXHYeUlVscTSwJAdbNEBzxGyOiPfD.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvK=RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPDj['band']['pagecount'])
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPDj['band']['count']:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg =RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPDj['band']['count'])
   else:RkXHYeUlVscTSwJAdbNEBzxGyOiPvg=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.LIST_LIMIT
   RkXHYeUlVscTSwJAdbNEBzxGyOiPva=RkXHYeUlVscTSwJAdbNEBzxGyOiPvK>RkXHYeUlVscTSwJAdbNEBzxGyOiPvg
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPfD,RkXHYeUlVscTSwJAdbNEBzxGyOiPva 
 def GetSecureToken(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/ip'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjh=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM)
  RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['securetoken']
 def Wavve_Parse_m3u8(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPLn):
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtn={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=requests.get(url=RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_url'],headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPtn,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_cookie'])
   RkXHYeUlVscTSwJAdbNEBzxGyOiPfn=RkXHYeUlVscTSwJAdbNEBzxGyOiPth.content.decode('utf-8')
   if '#EXTM3U' not in RkXHYeUlVscTSwJAdbNEBzxGyOiPfn:
    return RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
   if '#EXT-X-STREAM-INF' not in RkXHYeUlVscTSwJAdbNEBzxGyOiPfn: 
    return RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
   RkXHYeUlVscTSwJAdbNEBzxGyOiPfm=0
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPfC in RkXHYeUlVscTSwJAdbNEBzxGyOiPfn.splitlines():
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPfC.startswith('#EXT-X-STREAM-INF'):
     RkXHYeUlVscTSwJAdbNEBzxGyOiPfK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.MediaLine_Parse(RkXHYeUlVscTSwJAdbNEBzxGyOiPfC,'#EXT-X-STREAM-INF')
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPfm<RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPfK.get('BANDWIDTH')):
      RkXHYeUlVscTSwJAdbNEBzxGyOiPfm=RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPfK.get('BANDWIDTH'))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPfa=[]
   RkXHYeUlVscTSwJAdbNEBzxGyOiPfh=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPfC in RkXHYeUlVscTSwJAdbNEBzxGyOiPfn.splitlines():
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPfh==RkXHYeUlVscTSwJAdbNEBzxGyOiPnj:
     RkXHYeUlVscTSwJAdbNEBzxGyOiPfh=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
     continue
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPfC.startswith('#EXT-X-STREAM-INF'):
     RkXHYeUlVscTSwJAdbNEBzxGyOiPfK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.MediaLine_Parse(RkXHYeUlVscTSwJAdbNEBzxGyOiPfC,'#EXT-X-STREAM-INF')
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPfm!=RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPfK.get('BANDWIDTH')):
      RkXHYeUlVscTSwJAdbNEBzxGyOiPfh=RkXHYeUlVscTSwJAdbNEBzxGyOiPnj
      continue
    RkXHYeUlVscTSwJAdbNEBzxGyOiPfa.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPfC)
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return RkXHYeUlVscTSwJAdbNEBzxGyOiPpM
  RkXHYeUlVscTSwJAdbNEBzxGyOiPfQ='\n'.join(RkXHYeUlVscTSwJAdbNEBzxGyOiPfa)
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.TextFile_Save(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV_STREAM_FILENAME,RkXHYeUlVscTSwJAdbNEBzxGyOiPfQ)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPnj
 def Wavve_Parse_mpd(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPLn):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPtn={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  RkXHYeUlVscTSwJAdbNEBzxGyOiPth=requests.get(url=RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_url'],headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPtn,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_cookie'])
  RkXHYeUlVscTSwJAdbNEBzxGyOiPfW=RkXHYeUlVscTSwJAdbNEBzxGyOiPth.content.decode('utf-8')
  RkXHYeUlVscTSwJAdbNEBzxGyOiPfr =ET.ElementTree(ET.fromstring(RkXHYeUlVscTSwJAdbNEBzxGyOiPfW))
  RkXHYeUlVscTSwJAdbNEBzxGyOiPfg =RkXHYeUlVscTSwJAdbNEBzxGyOiPfr.getroot()
  RkXHYeUlVscTSwJAdbNEBzxGyOiPfI=re.match(r'\{.*\}',RkXHYeUlVscTSwJAdbNEBzxGyOiPfg.tag)[0] 
  RkXHYeUlVscTSwJAdbNEBzxGyOiPfF=RkXHYeUlVscTSwJAdbNEBzxGyOiPnp([node for _,node in ET.iterparse(io.StringIO(RkXHYeUlVscTSwJAdbNEBzxGyOiPfW),events=['start-ns'])])
  for RkXHYeUlVscTSwJAdbNEBzxGyOiPtL,RkXHYeUlVscTSwJAdbNEBzxGyOiPLp in RkXHYeUlVscTSwJAdbNEBzxGyOiPfF.items():
   ET.register_namespace(RkXHYeUlVscTSwJAdbNEBzxGyOiPtL,RkXHYeUlVscTSwJAdbNEBzxGyOiPLp)
  RkXHYeUlVscTSwJAdbNEBzxGyOiPfu=RkXHYeUlVscTSwJAdbNEBzxGyOiPfg.find(RkXHYeUlVscTSwJAdbNEBzxGyOiPfI+'Period')
  for RkXHYeUlVscTSwJAdbNEBzxGyOiPfq in RkXHYeUlVscTSwJAdbNEBzxGyOiPfu.findall(RkXHYeUlVscTSwJAdbNEBzxGyOiPfI+'AdaptationSet'):
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPfq.attrib.get('mimeType')=='video/mp4':
    RkXHYeUlVscTSwJAdbNEBzxGyOiPfM=0
    for RkXHYeUlVscTSwJAdbNEBzxGyOiPfo in RkXHYeUlVscTSwJAdbNEBzxGyOiPfq.findall(RkXHYeUlVscTSwJAdbNEBzxGyOiPfI+'Representation'):
     RkXHYeUlVscTSwJAdbNEBzxGyOiPLj=RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPfo.attrib.get('bandwidth'))
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPfM<RkXHYeUlVscTSwJAdbNEBzxGyOiPLj:RkXHYeUlVscTSwJAdbNEBzxGyOiPfM=RkXHYeUlVscTSwJAdbNEBzxGyOiPLj
    for RkXHYeUlVscTSwJAdbNEBzxGyOiPfo in RkXHYeUlVscTSwJAdbNEBzxGyOiPfq.findall(RkXHYeUlVscTSwJAdbNEBzxGyOiPfI+'Representation'):
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPfM>RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPfo.attrib.get('bandwidth')):
      RkXHYeUlVscTSwJAdbNEBzxGyOiPfq.remove(RkXHYeUlVscTSwJAdbNEBzxGyOiPfo)
   elif RkXHYeUlVscTSwJAdbNEBzxGyOiPfq.attrib.get('mimeType')=='audio/mp4':
    RkXHYeUlVscTSwJAdbNEBzxGyOiPfM=0
    for RkXHYeUlVscTSwJAdbNEBzxGyOiPfo in RkXHYeUlVscTSwJAdbNEBzxGyOiPfq.findall(RkXHYeUlVscTSwJAdbNEBzxGyOiPfI+'Representation'):
     RkXHYeUlVscTSwJAdbNEBzxGyOiPLj=RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPfo.attrib.get('bandwidth'))
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPfM<RkXHYeUlVscTSwJAdbNEBzxGyOiPLj:RkXHYeUlVscTSwJAdbNEBzxGyOiPfM=RkXHYeUlVscTSwJAdbNEBzxGyOiPLj
    for RkXHYeUlVscTSwJAdbNEBzxGyOiPfo in RkXHYeUlVscTSwJAdbNEBzxGyOiPfq.findall(RkXHYeUlVscTSwJAdbNEBzxGyOiPfI+'Representation'):
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPfM>RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPfo.attrib.get('bandwidth')):
      RkXHYeUlVscTSwJAdbNEBzxGyOiPfq.remove(RkXHYeUlVscTSwJAdbNEBzxGyOiPfo)
   else:
    continue
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLt=ET.tostring(RkXHYeUlVscTSwJAdbNEBzxGyOiPfg).decode('utf-8')
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLv='<?xml version="1.0" encoding="UTF-8"?>\n'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.TextFile_Save(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV_STREAM_FILENAME,RkXHYeUlVscTSwJAdbNEBzxGyOiPLv+RkXHYeUlVscTSwJAdbNEBzxGyOiPLt)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPnj
 def MediaLine_Parse(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPfC,prefix):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPfK={}
  for RkXHYeUlVscTSwJAdbNEBzxGyOiPLD in RkXHYeUlVscTSwJAdbNEBzxGyOiPjv.split(RkXHYeUlVscTSwJAdbNEBzxGyOiPfC.replace(prefix+':',''))[1::2]:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLf,RkXHYeUlVscTSwJAdbNEBzxGyOiPLp=RkXHYeUlVscTSwJAdbNEBzxGyOiPLD.split('=',1)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPfK[RkXHYeUlVscTSwJAdbNEBzxGyOiPLf.upper()]=RkXHYeUlVscTSwJAdbNEBzxGyOiPLp.replace('"','').strip()
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPfK
 def GetStreamingURL(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,mode,RkXHYeUlVscTSwJAdbNEBzxGyOiPvo,quality_int,pvrmode='-',playOption={}):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLn ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLm=[]
  if mode=='LIVE':
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/live/channels/'+RkXHYeUlVscTSwJAdbNEBzxGyOiPvo
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLC='live'
  elif mode=='VOD':
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/fz/vod/contents-detail/'+RkXHYeUlVscTSwJAdbNEBzxGyOiPvo 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLC='vod'
  elif mode=='MOVIE':
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/fz/movie/contents/'+RkXHYeUlVscTSwJAdbNEBzxGyOiPvo
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLC='movie'
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLK={'hdr':'sdr','uhd':'-',}
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLa=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['qualities']['list']
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPLa==RkXHYeUlVscTSwJAdbNEBzxGyOiPpq:return RkXHYeUlVscTSwJAdbNEBzxGyOiPLn
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPLh in RkXHYeUlVscTSwJAdbNEBzxGyOiPLa:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPLm.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPnm(RkXHYeUlVscTSwJAdbNEBzxGyOiPLh.get('id').rstrip('p')))
   if 'type' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ:
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['type']=='onair':
     RkXHYeUlVscTSwJAdbNEBzxGyOiPLC='onairvod'
   if 'drms' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ:
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['drms']:
     RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ.get('qualities'):
     for RkXHYeUlVscTSwJAdbNEBzxGyOiPLQ in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ.get('qualities').get('mediatypes'):
      if RkXHYeUlVscTSwJAdbNEBzxGyOiPLQ=='HDR10':
       RkXHYeUlVscTSwJAdbNEBzxGyOiPLK['hdr']='hdr'
       RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for RkXHYeUlVscTSwJAdbNEBzxGyOiPLQ in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ.get('qualities').get('list'):
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPLQ.get('name')=='UHD':
      RkXHYeUlVscTSwJAdbNEBzxGyOiPLK['uhd']='uhd'
      break
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return RkXHYeUlVscTSwJAdbNEBzxGyOiPLn
  RkXHYeUlVscTSwJAdbNEBzxGyOiPnL('stream_action : '+RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_action'])
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLW=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.CheckQuality(quality_int,RkXHYeUlVscTSwJAdbNEBzxGyOiPLm)
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPLK['uhd']=='uhd':RkXHYeUlVscTSwJAdbNEBzxGyOiPLW=2160 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLr=RkXHYeUlVscTSwJAdbNEBzxGyOiPnv(RkXHYeUlVscTSwJAdbNEBzxGyOiPLW)+'p'
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(RkXHYeUlVscTSwJAdbNEBzxGyOiPLr)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/fz/streaming'
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPLK['hdr']=='hdr' or RkXHYeUlVscTSwJAdbNEBzxGyOiPLK['uhd']=='uhd':
    RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'contentid':RkXHYeUlVscTSwJAdbNEBzxGyOiPvo,'contenttype':RkXHYeUlVscTSwJAdbNEBzxGyOiPLC,'quality':RkXHYeUlVscTSwJAdbNEBzxGyOiPLr,'modelid':'SHIELD Android TV','guid':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams_AND())
   else:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'contentid':RkXHYeUlVscTSwJAdbNEBzxGyOiPvo,'contenttype':RkXHYeUlVscTSwJAdbNEBzxGyOiPLC,'quality':RkXHYeUlVscTSwJAdbNEBzxGyOiPLr,'deviceModelId':'Windows 10','guid':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_action'],'protocol':RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPnj))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_url']=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['playurl']
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_url']==RkXHYeUlVscTSwJAdbNEBzxGyOiPpq:return RkXHYeUlVscTSwJAdbNEBzxGyOiPLn
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_cookie']=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.make_str_ToCookie(RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['awscookie'])
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_drm'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['drm']
   if 'previewmsg' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['preview']:RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_preview']=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['preview']['previewmsg']
   if 'subtitles' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ:
    for RkXHYeUlVscTSwJAdbNEBzxGyOiPLg in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['subtitles']:
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPLg.get('languagecode')=='ko':
      RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_vtt']=RkXHYeUlVscTSwJAdbNEBzxGyOiPLg.get('url')
      break
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_vtt']=='':
     for RkXHYeUlVscTSwJAdbNEBzxGyOiPLg in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['subtitles']:
      if RkXHYeUlVscTSwJAdbNEBzxGyOiPLg.get('languagecode')=='ko_cc':
       RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_vtt']=RkXHYeUlVscTSwJAdbNEBzxGyOiPLg.get('url')
       break
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['playParam']=RkXHYeUlVscTSwJAdbNEBzxGyOiPLK 
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPLn 
 def GetSportsURL(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPvo,quality_int):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLn ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLm=[]
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/streaming/other'
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'contentid':RkXHYeUlVscTSwJAdbNEBzxGyOiPvo,'contenttype':'live','action':RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_action'],'quality':RkXHYeUlVscTSwJAdbNEBzxGyOiPnv(quality_int)+'p','deviceModelId':'Windows 10','guid':RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPnj))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_url']=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['playurl']
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_url']==RkXHYeUlVscTSwJAdbNEBzxGyOiPpq:return RkXHYeUlVscTSwJAdbNEBzxGyOiPLn
   RkXHYeUlVscTSwJAdbNEBzxGyOiPLn['stream_cookie']=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['awscookie']
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPLn
 def make_viewdate(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLI =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.Get_Now_Datetime()
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLF =RkXHYeUlVscTSwJAdbNEBzxGyOiPLI+datetime.timedelta(days=-1)
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLu =RkXHYeUlVscTSwJAdbNEBzxGyOiPLI+datetime.timedelta(days=1)
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLq=[RkXHYeUlVscTSwJAdbNEBzxGyOiPLI.strftime('%Y%m%d'),RkXHYeUlVscTSwJAdbNEBzxGyOiPLu.strftime('%Y%m%d'),]
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPLq
 def Get_Sports_Gamelist(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD):
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLM =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.make_viewdate()
  RkXHYeUlVscTSwJAdbNEBzxGyOiPLo=[]
  RkXHYeUlVscTSwJAdbNEBzxGyOiPpj =[]
  for RkXHYeUlVscTSwJAdbNEBzxGyOiPpt in RkXHYeUlVscTSwJAdbNEBzxGyOiPLM:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpv=RkXHYeUlVscTSwJAdbNEBzxGyOiPpt[:6]
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPpv not in RkXHYeUlVscTSwJAdbNEBzxGyOiPLo:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPLo.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPpv)
  try:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh.update(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM))
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPpD in RkXHYeUlVscTSwJAdbNEBzxGyOiPLo:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPjh['date']=RkXHYeUlVscTSwJAdbNEBzxGyOiPpD
    RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
    RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvj=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ['cell_toplist']['celllist']
    for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPvj:
     RkXHYeUlVscTSwJAdbNEBzxGyOiPpf=RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('game_date')
     RkXHYeUlVscTSwJAdbNEBzxGyOiPpL =RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('svc_id')
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPpL=='':continue
     if RkXHYeUlVscTSwJAdbNEBzxGyOiPpf in RkXHYeUlVscTSwJAdbNEBzxGyOiPLM:
      RkXHYeUlVscTSwJAdbNEBzxGyOiPpn=RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('game_status') 
      RkXHYeUlVscTSwJAdbNEBzxGyOiPpm =RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('title_list')[0].get('text')
      RkXHYeUlVscTSwJAdbNEBzxGyOiPpf =RkXHYeUlVscTSwJAdbNEBzxGyOiPpf[:4]+'-'+RkXHYeUlVscTSwJAdbNEBzxGyOiPpf[4:6]+'-'+RkXHYeUlVscTSwJAdbNEBzxGyOiPpf[-2:]
      RkXHYeUlVscTSwJAdbNEBzxGyOiPpC =RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('game_time')
      RkXHYeUlVscTSwJAdbNEBzxGyOiPpC =RkXHYeUlVscTSwJAdbNEBzxGyOiPpC[:2]+':'+RkXHYeUlVscTSwJAdbNEBzxGyOiPpC[-2:]
      RkXHYeUlVscTSwJAdbNEBzxGyOiPvD={'game_date':RkXHYeUlVscTSwJAdbNEBzxGyOiPpf,'game_time':RkXHYeUlVscTSwJAdbNEBzxGyOiPpC,'svc_id':RkXHYeUlVscTSwJAdbNEBzxGyOiPpL,'away_team':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('away_team').get('team_name'),'home_team':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('home_team').get('team_name'),'game_status':RkXHYeUlVscTSwJAdbNEBzxGyOiPpn,'game_place':RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('game_place'),}
      RkXHYeUlVscTSwJAdbNEBzxGyOiPpj.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvD)
  except RkXHYeUlVscTSwJAdbNEBzxGyOiPnf as exception:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPnL(exception)
   return[]
  RkXHYeUlVscTSwJAdbNEBzxGyOiPpK=[]
  for i in RkXHYeUlVscTSwJAdbNEBzxGyOiPnt(2):
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPvt in RkXHYeUlVscTSwJAdbNEBzxGyOiPpj:
    if i==0 and RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('game_status')=='LIVE':
     RkXHYeUlVscTSwJAdbNEBzxGyOiPpK.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvt)
    elif i==1 and RkXHYeUlVscTSwJAdbNEBzxGyOiPvt.get('game_status')!='LIVE':
     RkXHYeUlVscTSwJAdbNEBzxGyOiPpK.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPvt)
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPpK
 def GetBookmarkInfo(RkXHYeUlVscTSwJAdbNEBzxGyOiPjD,RkXHYeUlVscTSwJAdbNEBzxGyOiPvr,RkXHYeUlVscTSwJAdbNEBzxGyOiPvW,RkXHYeUlVscTSwJAdbNEBzxGyOiPLC):
  if RkXHYeUlVscTSwJAdbNEBzxGyOiPvW=='tvshow':
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPLC=='contentid':
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvo=RkXHYeUlVscTSwJAdbNEBzxGyOiPvr
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvr =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.ContentidToSeasonid(RkXHYeUlVscTSwJAdbNEBzxGyOiPvo)
   else:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPvo=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.ProgramidToContentid(RkXHYeUlVscTSwJAdbNEBzxGyOiPvr)
  else:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPvo=''
  RkXHYeUlVscTSwJAdbNEBzxGyOiPpa={'indexinfo':{'ott':'wavve','videoid':RkXHYeUlVscTSwJAdbNEBzxGyOiPvr,'vidtype':RkXHYeUlVscTSwJAdbNEBzxGyOiPvW,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':RkXHYeUlVscTSwJAdbNEBzxGyOiPvW,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if RkXHYeUlVscTSwJAdbNEBzxGyOiPvW=='tvshow':
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/fz/vod/contents/'+RkXHYeUlVscTSwJAdbNEBzxGyOiPvo 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if not('programtitle' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ):return{}
   RkXHYeUlVscTSwJAdbNEBzxGyOiPph=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpQ=RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('programtitle')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['title']=RkXHYeUlVscTSwJAdbNEBzxGyOiPpQ
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('targetage')=='18' or RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('targetage')=='19' or RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('targetage')=='21':
    RkXHYeUlVscTSwJAdbNEBzxGyOiPpQ +=u' (%s)'%(RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('targetage'))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['title'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPpQ
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['mpaa'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('targetage')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['plot'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('programsynopsis').replace('<br>','\n')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['studio'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('channelname')
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('firstreleaseyear')!='':RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['year'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('firstreleaseyear')
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('firstreleasedate')!='':RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['premiered']=RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('firstreleasedate')
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('genretext') !='':RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['genre'] =[RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('genretext')]
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpW=[]
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPpr in RkXHYeUlVscTSwJAdbNEBzxGyOiPph['actors']['list']:RkXHYeUlVscTSwJAdbNEBzxGyOiPpW.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPpr.get('text'))
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPnD(RkXHYeUlVscTSwJAdbNEBzxGyOiPpW)>0:
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPpW[0]!='':RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['cast']=RkXHYeUlVscTSwJAdbNEBzxGyOiPpW
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDW =''
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDr =''
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDg=''
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('programposterimage')!='':RkXHYeUlVscTSwJAdbNEBzxGyOiPDW =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.HTTPTAG+RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('programposterimage')
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('programimage') !='':RkXHYeUlVscTSwJAdbNEBzxGyOiPDr =RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.HTTPTAG+RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('programimage')
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('programcircleimage')!='':RkXHYeUlVscTSwJAdbNEBzxGyOiPDg=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.HTTPTAG+RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('programcircleimage')
   if 'poster_default' in RkXHYeUlVscTSwJAdbNEBzxGyOiPDW:
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDW =RkXHYeUlVscTSwJAdbNEBzxGyOiPDr
    RkXHYeUlVscTSwJAdbNEBzxGyOiPDg=''
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['thumbnail']['poster']=RkXHYeUlVscTSwJAdbNEBzxGyOiPDW
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['thumbnail']['thumb']=RkXHYeUlVscTSwJAdbNEBzxGyOiPDr
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['thumbnail']['clearlogo']=RkXHYeUlVscTSwJAdbNEBzxGyOiPDg
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['thumbnail']['fanart']=RkXHYeUlVscTSwJAdbNEBzxGyOiPDr
  else:
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtK=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.API_DOMAIN+'/movie/contents/'+RkXHYeUlVscTSwJAdbNEBzxGyOiPvr 
   RkXHYeUlVscTSwJAdbNEBzxGyOiPjh=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.GetDefaultParams(login=RkXHYeUlVscTSwJAdbNEBzxGyOiPpM)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPth=RkXHYeUlVscTSwJAdbNEBzxGyOiPjD.callRequestCookies('Get',RkXHYeUlVscTSwJAdbNEBzxGyOiPtK,payload=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,params=RkXHYeUlVscTSwJAdbNEBzxGyOiPjh,headers=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq,cookies=RkXHYeUlVscTSwJAdbNEBzxGyOiPpq)
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ=json.loads(RkXHYeUlVscTSwJAdbNEBzxGyOiPth.text)
   if not('title' in RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ):return{}
   RkXHYeUlVscTSwJAdbNEBzxGyOiPph=RkXHYeUlVscTSwJAdbNEBzxGyOiPtQ
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpQ=RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('title')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['title']=RkXHYeUlVscTSwJAdbNEBzxGyOiPpQ
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('targetage')=='18' or RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('targetage')=='19' or RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('targetage')=='21':
    RkXHYeUlVscTSwJAdbNEBzxGyOiPpQ +=u' (%s)'%(RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('targetage'))
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['title'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPpQ
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['mpaa'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('targetage')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['plot'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('synopsis').replace('<br>','\n')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['duration']=RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('playtime')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['country']=RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('country')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['studio'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('cpname')
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('releasedate')!='':
    RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['year'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('releasedate')[:4]
    RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['premiered']=RkXHYeUlVscTSwJAdbNEBzxGyOiPph.get('releasedate')
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpW=[]
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPpr in RkXHYeUlVscTSwJAdbNEBzxGyOiPph['actors']['list']:RkXHYeUlVscTSwJAdbNEBzxGyOiPpW.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPpr.get('text'))
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPnD(RkXHYeUlVscTSwJAdbNEBzxGyOiPpW)>0:
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPpW[0]!='':RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['cast']=RkXHYeUlVscTSwJAdbNEBzxGyOiPpW
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpg=[]
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPpI in RkXHYeUlVscTSwJAdbNEBzxGyOiPph['directors']['list']:RkXHYeUlVscTSwJAdbNEBzxGyOiPpg.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPpI.get('text'))
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPnD(RkXHYeUlVscTSwJAdbNEBzxGyOiPpg)>0:
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPpg[0]!='':RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['director']=RkXHYeUlVscTSwJAdbNEBzxGyOiPpg
   RkXHYeUlVscTSwJAdbNEBzxGyOiPtq=[]
   for RkXHYeUlVscTSwJAdbNEBzxGyOiPpF in RkXHYeUlVscTSwJAdbNEBzxGyOiPph['genre']['list']:RkXHYeUlVscTSwJAdbNEBzxGyOiPtq.append(RkXHYeUlVscTSwJAdbNEBzxGyOiPpF.get('text'))
   if RkXHYeUlVscTSwJAdbNEBzxGyOiPnD(RkXHYeUlVscTSwJAdbNEBzxGyOiPtq)>0:
    if RkXHYeUlVscTSwJAdbNEBzxGyOiPtq[0]!='':RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['infoLabels']['genre']=RkXHYeUlVscTSwJAdbNEBzxGyOiPtq
   RkXHYeUlVscTSwJAdbNEBzxGyOiPDW ='https://%s'%RkXHYeUlVscTSwJAdbNEBzxGyOiPph['image']
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['thumbnail']['poster'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPDW
   RkXHYeUlVscTSwJAdbNEBzxGyOiPpa['saveinfo']['thumbnail']['thumb'] =RkXHYeUlVscTSwJAdbNEBzxGyOiPDW
  return RkXHYeUlVscTSwJAdbNEBzxGyOiPpa
# Created by pyminifier (https://github.com/liftoff/pyminifier)
