__author__="NightRain"
jhwctebYzkQAasmBlFfKWdGMgpTErR=object
jhwctebYzkQAasmBlFfKWdGMgpTErI=None
jhwctebYzkQAasmBlFfKWdGMgpTEro=int
jhwctebYzkQAasmBlFfKWdGMgpTErH=True
jhwctebYzkQAasmBlFfKWdGMgpTErq=False
jhwctebYzkQAasmBlFfKWdGMgpTErL=type
jhwctebYzkQAasmBlFfKWdGMgpTEri=dict
jhwctebYzkQAasmBlFfKWdGMgpTErX=getattr
jhwctebYzkQAasmBlFfKWdGMgpTErU=list
jhwctebYzkQAasmBlFfKWdGMgpTEru=len
jhwctebYzkQAasmBlFfKWdGMgpTErO=range
jhwctebYzkQAasmBlFfKWdGMgpTEry=str
jhwctebYzkQAasmBlFfKWdGMgpTErV=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
jhwctebYzkQAasmBlFfKWdGMgpTENv=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
jhwctebYzkQAasmBlFfKWdGMgpTENJ=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
jhwctebYzkQAasmBlFfKWdGMgpTEND=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
jhwctebYzkQAasmBlFfKWdGMgpTENx={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
jhwctebYzkQAasmBlFfKWdGMgpTENn =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
jhwctebYzkQAasmBlFfKWdGMgpTENr=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class jhwctebYzkQAasmBlFfKWdGMgpTENC(jhwctebYzkQAasmBlFfKWdGMgpTErR):
 def __init__(jhwctebYzkQAasmBlFfKWdGMgpTENS,jhwctebYzkQAasmBlFfKWdGMgpTENR,jhwctebYzkQAasmBlFfKWdGMgpTENI,jhwctebYzkQAasmBlFfKWdGMgpTENo):
  jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_url =jhwctebYzkQAasmBlFfKWdGMgpTENR
  jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle=jhwctebYzkQAasmBlFfKWdGMgpTENI
  jhwctebYzkQAasmBlFfKWdGMgpTENS.main_params =jhwctebYzkQAasmBlFfKWdGMgpTENo
  jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj =RkXHYeUlVscTSwJAdbNEBzxGyOiPjt() 
  jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(jhwctebYzkQAasmBlFfKWdGMgpTENS,sting):
  try:
   jhwctebYzkQAasmBlFfKWdGMgpTENq=xbmcgui.Dialog()
   jhwctebYzkQAasmBlFfKWdGMgpTENq.notification(__addonname__,sting)
  except:
   jhwctebYzkQAasmBlFfKWdGMgpTErI
 def addon_log(jhwctebYzkQAasmBlFfKWdGMgpTENS,string):
  try:
   jhwctebYzkQAasmBlFfKWdGMgpTENL=string.encode('utf-8','ignore')
  except:
   jhwctebYzkQAasmBlFfKWdGMgpTENL='addonException: addon_log'
  jhwctebYzkQAasmBlFfKWdGMgpTENi=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,jhwctebYzkQAasmBlFfKWdGMgpTENL),level=jhwctebYzkQAasmBlFfKWdGMgpTENi)
 def get_keyboard_input(jhwctebYzkQAasmBlFfKWdGMgpTENS,jhwctebYzkQAasmBlFfKWdGMgpTECH):
  jhwctebYzkQAasmBlFfKWdGMgpTENX=jhwctebYzkQAasmBlFfKWdGMgpTErI
  kb=xbmc.Keyboard()
  kb.setHeading(jhwctebYzkQAasmBlFfKWdGMgpTECH)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   jhwctebYzkQAasmBlFfKWdGMgpTENX=kb.getText()
  return jhwctebYzkQAasmBlFfKWdGMgpTENX
 def get_settings_account(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  jhwctebYzkQAasmBlFfKWdGMgpTENU =__addon__.getSetting('id')
  jhwctebYzkQAasmBlFfKWdGMgpTENu =__addon__.getSetting('pw')
  jhwctebYzkQAasmBlFfKWdGMgpTENO=jhwctebYzkQAasmBlFfKWdGMgpTEro(__addon__.getSetting('selected_profile'))
  return(jhwctebYzkQAasmBlFfKWdGMgpTENU,jhwctebYzkQAasmBlFfKWdGMgpTENu,jhwctebYzkQAasmBlFfKWdGMgpTENO)
 def get_settings_totalsearch(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  jhwctebYzkQAasmBlFfKWdGMgpTENy =jhwctebYzkQAasmBlFfKWdGMgpTErH if __addon__.getSetting('local_search')=='true' else jhwctebYzkQAasmBlFfKWdGMgpTErq
  jhwctebYzkQAasmBlFfKWdGMgpTENV=jhwctebYzkQAasmBlFfKWdGMgpTErH if __addon__.getSetting('local_history')=='true' else jhwctebYzkQAasmBlFfKWdGMgpTErq
  jhwctebYzkQAasmBlFfKWdGMgpTENP =jhwctebYzkQAasmBlFfKWdGMgpTErH if __addon__.getSetting('total_search')=='true' else jhwctebYzkQAasmBlFfKWdGMgpTErq
  jhwctebYzkQAasmBlFfKWdGMgpTECN=jhwctebYzkQAasmBlFfKWdGMgpTErH if __addon__.getSetting('total_history')=='true' else jhwctebYzkQAasmBlFfKWdGMgpTErq
  jhwctebYzkQAasmBlFfKWdGMgpTECv=jhwctebYzkQAasmBlFfKWdGMgpTErH if __addon__.getSetting('menu_bookmark')=='true' else jhwctebYzkQAasmBlFfKWdGMgpTErq
  return(jhwctebYzkQAasmBlFfKWdGMgpTENy,jhwctebYzkQAasmBlFfKWdGMgpTENV,jhwctebYzkQAasmBlFfKWdGMgpTENP,jhwctebYzkQAasmBlFfKWdGMgpTECN,jhwctebYzkQAasmBlFfKWdGMgpTECv)
 def get_settings_makebookmark(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  return jhwctebYzkQAasmBlFfKWdGMgpTErH if __addon__.getSetting('make_bookmark')=='true' else jhwctebYzkQAasmBlFfKWdGMgpTErq
 def get_settings_play(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  jhwctebYzkQAasmBlFfKWdGMgpTECJ={'enable_hdr':jhwctebYzkQAasmBlFfKWdGMgpTErH if __addon__.getSetting('enable_hdr')=='true' else jhwctebYzkQAasmBlFfKWdGMgpTErq,'enable_uhd':jhwctebYzkQAasmBlFfKWdGMgpTErH if __addon__.getSetting('enable_uhd')=='true' else jhwctebYzkQAasmBlFfKWdGMgpTErq,'streamFilename':jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.WV_STREAM_FILENAME,}
  if jhwctebYzkQAasmBlFfKWdGMgpTENS.get_selQuality()<1080:
   jhwctebYzkQAasmBlFfKWdGMgpTECJ['enable_hdr']=jhwctebYzkQAasmBlFfKWdGMgpTErq
   jhwctebYzkQAasmBlFfKWdGMgpTECJ['enable_uhd']=jhwctebYzkQAasmBlFfKWdGMgpTErq
  return(jhwctebYzkQAasmBlFfKWdGMgpTECJ)
 def get_settings_proxyport(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  jhwctebYzkQAasmBlFfKWdGMgpTECD =jhwctebYzkQAasmBlFfKWdGMgpTErH if __addon__.getSetting('proxyYn')=='true' else jhwctebYzkQAasmBlFfKWdGMgpTErq
  jhwctebYzkQAasmBlFfKWdGMgpTECx=jhwctebYzkQAasmBlFfKWdGMgpTEro(__addon__.getSetting('proxyPort'))
  return jhwctebYzkQAasmBlFfKWdGMgpTECD,jhwctebYzkQAasmBlFfKWdGMgpTECx
 def get_selQuality(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  try:
   jhwctebYzkQAasmBlFfKWdGMgpTECn=[1080,720,480,360]
   jhwctebYzkQAasmBlFfKWdGMgpTECr=jhwctebYzkQAasmBlFfKWdGMgpTEro(__addon__.getSetting('selected_quality'))
   return jhwctebYzkQAasmBlFfKWdGMgpTECn[jhwctebYzkQAasmBlFfKWdGMgpTECr]
  except:
   jhwctebYzkQAasmBlFfKWdGMgpTErI
  return 1080 
 def get_settings_exclusion21(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  jhwctebYzkQAasmBlFfKWdGMgpTECS =__addon__.getSetting('exclusion21')
  if jhwctebYzkQAasmBlFfKWdGMgpTECS=='false':
   return jhwctebYzkQAasmBlFfKWdGMgpTErq
  else:
   return jhwctebYzkQAasmBlFfKWdGMgpTErH
 def get_settings_direct_replay(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  jhwctebYzkQAasmBlFfKWdGMgpTECR=jhwctebYzkQAasmBlFfKWdGMgpTEro(__addon__.getSetting('direct_replay'))
  if jhwctebYzkQAasmBlFfKWdGMgpTECR==0:
   return jhwctebYzkQAasmBlFfKWdGMgpTErq
  else:
   return jhwctebYzkQAasmBlFfKWdGMgpTErH
 def set_winEpisodeOrderby(jhwctebYzkQAasmBlFfKWdGMgpTENS,jhwctebYzkQAasmBlFfKWdGMgpTECI):
  __addon__.setSetting('wavve_orderby',jhwctebYzkQAasmBlFfKWdGMgpTECI)
 def get_winEpisodeOrderby(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  jhwctebYzkQAasmBlFfKWdGMgpTECI=__addon__.getSetting('wavve_orderby')
  if jhwctebYzkQAasmBlFfKWdGMgpTECI in['',jhwctebYzkQAasmBlFfKWdGMgpTErI]:jhwctebYzkQAasmBlFfKWdGMgpTECI='desc'
  return jhwctebYzkQAasmBlFfKWdGMgpTECI
 def add_dir(jhwctebYzkQAasmBlFfKWdGMgpTENS,label,sublabel='',img='',infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTErI,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params='',isLink=jhwctebYzkQAasmBlFfKWdGMgpTErq,ContextMenu=jhwctebYzkQAasmBlFfKWdGMgpTErI):
  jhwctebYzkQAasmBlFfKWdGMgpTECo='%s?%s'%(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_url,urllib.parse.urlencode(params))
  if sublabel:jhwctebYzkQAasmBlFfKWdGMgpTECH='%s < %s >'%(label,sublabel)
  else: jhwctebYzkQAasmBlFfKWdGMgpTECH=label
  if not img:img='DefaultFolder.png'
  jhwctebYzkQAasmBlFfKWdGMgpTECq=xbmcgui.ListItem(jhwctebYzkQAasmBlFfKWdGMgpTECH)
  if jhwctebYzkQAasmBlFfKWdGMgpTErL(img)==jhwctebYzkQAasmBlFfKWdGMgpTEri:
   jhwctebYzkQAasmBlFfKWdGMgpTECq.setArt(img)
  else:
   jhwctebYzkQAasmBlFfKWdGMgpTECq.setArt({'thumb':img,'poster':img})
  if jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.KodiVersion>=20:
   if infoLabels:jhwctebYzkQAasmBlFfKWdGMgpTENS.Set_InfoTag(jhwctebYzkQAasmBlFfKWdGMgpTECq.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:jhwctebYzkQAasmBlFfKWdGMgpTECq.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   jhwctebYzkQAasmBlFfKWdGMgpTECq.setProperty('IsPlayable','true')
  if ContextMenu:jhwctebYzkQAasmBlFfKWdGMgpTECq.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,jhwctebYzkQAasmBlFfKWdGMgpTECo,jhwctebYzkQAasmBlFfKWdGMgpTECq,isFolder)
 def Set_InfoTag(jhwctebYzkQAasmBlFfKWdGMgpTENS,video_InfoTag:xbmc.InfoTagVideo,jhwctebYzkQAasmBlFfKWdGMgpTECV):
  for jhwctebYzkQAasmBlFfKWdGMgpTECL,value in jhwctebYzkQAasmBlFfKWdGMgpTECV.items():
   if jhwctebYzkQAasmBlFfKWdGMgpTENx[jhwctebYzkQAasmBlFfKWdGMgpTECL]['type']=='string':
    jhwctebYzkQAasmBlFfKWdGMgpTErX(video_InfoTag,jhwctebYzkQAasmBlFfKWdGMgpTENx[jhwctebYzkQAasmBlFfKWdGMgpTECL]['func'])(value)
   elif jhwctebYzkQAasmBlFfKWdGMgpTENx[jhwctebYzkQAasmBlFfKWdGMgpTECL]['type']=='int':
    if jhwctebYzkQAasmBlFfKWdGMgpTErL(value)==jhwctebYzkQAasmBlFfKWdGMgpTEro:
     jhwctebYzkQAasmBlFfKWdGMgpTECi=jhwctebYzkQAasmBlFfKWdGMgpTEro(value)
    else:
     jhwctebYzkQAasmBlFfKWdGMgpTECi=0
    jhwctebYzkQAasmBlFfKWdGMgpTErX(video_InfoTag,jhwctebYzkQAasmBlFfKWdGMgpTENx[jhwctebYzkQAasmBlFfKWdGMgpTECL]['func'])(jhwctebYzkQAasmBlFfKWdGMgpTECi)
   elif jhwctebYzkQAasmBlFfKWdGMgpTENx[jhwctebYzkQAasmBlFfKWdGMgpTECL]['type']=='actor':
    if value!=[]:
     jhwctebYzkQAasmBlFfKWdGMgpTErX(video_InfoTag,jhwctebYzkQAasmBlFfKWdGMgpTENx[jhwctebYzkQAasmBlFfKWdGMgpTECL]['func'])([xbmc.Actor(name)for name in value])
   elif jhwctebYzkQAasmBlFfKWdGMgpTENx[jhwctebYzkQAasmBlFfKWdGMgpTECL]['type']=='list':
    if jhwctebYzkQAasmBlFfKWdGMgpTErL(value)==jhwctebYzkQAasmBlFfKWdGMgpTErU:
     jhwctebYzkQAasmBlFfKWdGMgpTErX(video_InfoTag,jhwctebYzkQAasmBlFfKWdGMgpTENx[jhwctebYzkQAasmBlFfKWdGMgpTECL]['func'])(value)
    else:
     jhwctebYzkQAasmBlFfKWdGMgpTErX(video_InfoTag,jhwctebYzkQAasmBlFfKWdGMgpTENx[jhwctebYzkQAasmBlFfKWdGMgpTECL]['func'])([value])
 def dp_Main_List(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  (jhwctebYzkQAasmBlFfKWdGMgpTENy,jhwctebYzkQAasmBlFfKWdGMgpTENV,jhwctebYzkQAasmBlFfKWdGMgpTENP,jhwctebYzkQAasmBlFfKWdGMgpTECN,jhwctebYzkQAasmBlFfKWdGMgpTECv)=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_totalsearch()
  for jhwctebYzkQAasmBlFfKWdGMgpTECX in jhwctebYzkQAasmBlFfKWdGMgpTENv:
   jhwctebYzkQAasmBlFfKWdGMgpTECH=jhwctebYzkQAasmBlFfKWdGMgpTECX.get('title')
   jhwctebYzkQAasmBlFfKWdGMgpTECU=''
   if jhwctebYzkQAasmBlFfKWdGMgpTECX.get('mode')=='SEARCH_GROUP' and jhwctebYzkQAasmBlFfKWdGMgpTENy ==jhwctebYzkQAasmBlFfKWdGMgpTErq:continue
   elif jhwctebYzkQAasmBlFfKWdGMgpTECX.get('mode')=='SEARCH_HISTORY' and jhwctebYzkQAasmBlFfKWdGMgpTENV==jhwctebYzkQAasmBlFfKWdGMgpTErq:continue
   elif jhwctebYzkQAasmBlFfKWdGMgpTECX.get('mode')=='TOTAL_SEARCH' and jhwctebYzkQAasmBlFfKWdGMgpTENP ==jhwctebYzkQAasmBlFfKWdGMgpTErq:continue
   elif jhwctebYzkQAasmBlFfKWdGMgpTECX.get('mode')=='TOTAL_HISTORY' and jhwctebYzkQAasmBlFfKWdGMgpTECN==jhwctebYzkQAasmBlFfKWdGMgpTErq:continue
   elif jhwctebYzkQAasmBlFfKWdGMgpTECX.get('mode')=='MENU_BOOKMARK' and jhwctebYzkQAasmBlFfKWdGMgpTECv==jhwctebYzkQAasmBlFfKWdGMgpTErq:continue
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':jhwctebYzkQAasmBlFfKWdGMgpTECX.get('mode'),'sCode':jhwctebYzkQAasmBlFfKWdGMgpTECX.get('sCode'),'sIndex':jhwctebYzkQAasmBlFfKWdGMgpTECX.get('sIndex'),'sType':jhwctebYzkQAasmBlFfKWdGMgpTECX.get('sType'),'suburl':jhwctebYzkQAasmBlFfKWdGMgpTECX.get('suburl'),'subapi':jhwctebYzkQAasmBlFfKWdGMgpTECX.get('subapi'),'page':jhwctebYzkQAasmBlFfKWdGMgpTECX.get('page'),'orderby':jhwctebYzkQAasmBlFfKWdGMgpTECX.get('orderby'),'ordernm':jhwctebYzkQAasmBlFfKWdGMgpTECX.get('ordernm')}
   if jhwctebYzkQAasmBlFfKWdGMgpTECX.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    jhwctebYzkQAasmBlFfKWdGMgpTECO=jhwctebYzkQAasmBlFfKWdGMgpTErq
    jhwctebYzkQAasmBlFfKWdGMgpTECy =jhwctebYzkQAasmBlFfKWdGMgpTErH
   else:
    jhwctebYzkQAasmBlFfKWdGMgpTECO=jhwctebYzkQAasmBlFfKWdGMgpTErH
    jhwctebYzkQAasmBlFfKWdGMgpTECy =jhwctebYzkQAasmBlFfKWdGMgpTErq
   jhwctebYzkQAasmBlFfKWdGMgpTECV={'title':jhwctebYzkQAasmBlFfKWdGMgpTECH,'plot':jhwctebYzkQAasmBlFfKWdGMgpTECH}
   if jhwctebYzkQAasmBlFfKWdGMgpTECX.get('mode')=='XXX':jhwctebYzkQAasmBlFfKWdGMgpTECV=jhwctebYzkQAasmBlFfKWdGMgpTErI
   if 'icon' in jhwctebYzkQAasmBlFfKWdGMgpTECX:jhwctebYzkQAasmBlFfKWdGMgpTECU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',jhwctebYzkQAasmBlFfKWdGMgpTECX.get('icon')) 
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img=jhwctebYzkQAasmBlFfKWdGMgpTECU,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTECV,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTECO,params=jhwctebYzkQAasmBlFfKWdGMgpTECu,isLink=jhwctebYzkQAasmBlFfKWdGMgpTECy)
  xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErH)
 def dp_Search_Group(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  if 'search_key' in args:
   jhwctebYzkQAasmBlFfKWdGMgpTEvC=args.get('search_key')
  else:
   jhwctebYzkQAasmBlFfKWdGMgpTEvC=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not jhwctebYzkQAasmBlFfKWdGMgpTEvC:
    return
  for jhwctebYzkQAasmBlFfKWdGMgpTEvJ in jhwctebYzkQAasmBlFfKWdGMgpTENJ:
   jhwctebYzkQAasmBlFfKWdGMgpTEvD =jhwctebYzkQAasmBlFfKWdGMgpTEvJ.get('mode')
   jhwctebYzkQAasmBlFfKWdGMgpTEvx=jhwctebYzkQAasmBlFfKWdGMgpTEvJ.get('sType')
   jhwctebYzkQAasmBlFfKWdGMgpTECH=jhwctebYzkQAasmBlFfKWdGMgpTEvJ.get('title')
   (jhwctebYzkQAasmBlFfKWdGMgpTEvn,jhwctebYzkQAasmBlFfKWdGMgpTEvr)=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_Search_List(jhwctebYzkQAasmBlFfKWdGMgpTEvC,jhwctebYzkQAasmBlFfKWdGMgpTEvx,1,exclusion21=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_exclusion21())
   jhwctebYzkQAasmBlFfKWdGMgpTECV={'plot':'검색어 : '+jhwctebYzkQAasmBlFfKWdGMgpTEvC+'\n\n'+jhwctebYzkQAasmBlFfKWdGMgpTENS.Search_FreeList(jhwctebYzkQAasmBlFfKWdGMgpTEvn)}
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':jhwctebYzkQAasmBlFfKWdGMgpTEvD,'sType':jhwctebYzkQAasmBlFfKWdGMgpTEvx,'search_key':jhwctebYzkQAasmBlFfKWdGMgpTEvC,'page':'1',}
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img='',infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTECV,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTENJ)>0:xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErH)
  jhwctebYzkQAasmBlFfKWdGMgpTENS.Save_Searched_List(jhwctebYzkQAasmBlFfKWdGMgpTEvC)
 def Search_FreeList(jhwctebYzkQAasmBlFfKWdGMgpTENS,search_list):
  jhwctebYzkQAasmBlFfKWdGMgpTEvS=''
  jhwctebYzkQAasmBlFfKWdGMgpTEvR=7
  try:
   if jhwctebYzkQAasmBlFfKWdGMgpTEru(search_list)==0:return '검색결과 없음'
   for i in jhwctebYzkQAasmBlFfKWdGMgpTErO(jhwctebYzkQAasmBlFfKWdGMgpTEru(search_list)):
    if i>=jhwctebYzkQAasmBlFfKWdGMgpTEvR:
     jhwctebYzkQAasmBlFfKWdGMgpTEvS=jhwctebYzkQAasmBlFfKWdGMgpTEvS+'...'
     break
    jhwctebYzkQAasmBlFfKWdGMgpTEvS=jhwctebYzkQAasmBlFfKWdGMgpTEvS+search_list[i]['title']+'\n'
  except:
   return ''
  return jhwctebYzkQAasmBlFfKWdGMgpTEvS
 def dp_Watch_Group(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  for jhwctebYzkQAasmBlFfKWdGMgpTEvI in jhwctebYzkQAasmBlFfKWdGMgpTEND:
   jhwctebYzkQAasmBlFfKWdGMgpTECH=jhwctebYzkQAasmBlFfKWdGMgpTEvI.get('title')
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':jhwctebYzkQAasmBlFfKWdGMgpTEvI.get('mode'),'sType':jhwctebYzkQAasmBlFfKWdGMgpTEvI.get('sType')}
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img='',infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTErI,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTEND)>0:xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErH)
 def dp_Search_History(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEvo=jhwctebYzkQAasmBlFfKWdGMgpTENS.Load_List_File('search')
  for jhwctebYzkQAasmBlFfKWdGMgpTEvH in jhwctebYzkQAasmBlFfKWdGMgpTEvo:
   jhwctebYzkQAasmBlFfKWdGMgpTEvq=jhwctebYzkQAasmBlFfKWdGMgpTEri(urllib.parse.parse_qsl(jhwctebYzkQAasmBlFfKWdGMgpTEvH))
   jhwctebYzkQAasmBlFfKWdGMgpTEvL=jhwctebYzkQAasmBlFfKWdGMgpTEvq.get('skey').strip()
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'SEARCH_GROUP','search_key':jhwctebYzkQAasmBlFfKWdGMgpTEvL,}
   jhwctebYzkQAasmBlFfKWdGMgpTEvi={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':jhwctebYzkQAasmBlFfKWdGMgpTEvL,'vType':'-',}
   jhwctebYzkQAasmBlFfKWdGMgpTEvX=urllib.parse.urlencode(jhwctebYzkQAasmBlFfKWdGMgpTEvi)
   jhwctebYzkQAasmBlFfKWdGMgpTEvU=[('선택된 검색어 ( %s ) 삭제'%(jhwctebYzkQAasmBlFfKWdGMgpTEvL),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEvX))]
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTEvL,sublabel='',img=jhwctebYzkQAasmBlFfKWdGMgpTErI,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTErI,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu,ContextMenu=jhwctebYzkQAasmBlFfKWdGMgpTEvU)
  jhwctebYzkQAasmBlFfKWdGMgpTEvu={'plot':'검색목록 전체를 삭제합니다.'}
  jhwctebYzkQAasmBlFfKWdGMgpTECH='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  jhwctebYzkQAasmBlFfKWdGMgpTECU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img=jhwctebYzkQAasmBlFfKWdGMgpTECU,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErq,params=jhwctebYzkQAasmBlFfKWdGMgpTECu,isLink=jhwctebYzkQAasmBlFfKWdGMgpTErH)
  xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_Search_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEvx =args.get('sType')
  jhwctebYzkQAasmBlFfKWdGMgpTEvO =jhwctebYzkQAasmBlFfKWdGMgpTEro(args.get('page'))
  if 'search_key' in args:
   jhwctebYzkQAasmBlFfKWdGMgpTEvC=args.get('search_key')
  else:
   jhwctebYzkQAasmBlFfKWdGMgpTEvC=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not jhwctebYzkQAasmBlFfKWdGMgpTEvC:
    xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle)
    return
  jhwctebYzkQAasmBlFfKWdGMgpTEvy,jhwctebYzkQAasmBlFfKWdGMgpTEvr=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_Search_List(jhwctebYzkQAasmBlFfKWdGMgpTEvC,jhwctebYzkQAasmBlFfKWdGMgpTEvx,jhwctebYzkQAasmBlFfKWdGMgpTEvO,exclusion21=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_exclusion21())
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   jhwctebYzkQAasmBlFfKWdGMgpTEvP =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('videoid')
   jhwctebYzkQAasmBlFfKWdGMgpTEJN =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('vidtype')
   jhwctebYzkQAasmBlFfKWdGMgpTECH =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('title')
   jhwctebYzkQAasmBlFfKWdGMgpTEJC=jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('thumbnail')
   jhwctebYzkQAasmBlFfKWdGMgpTEJv =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('age')
   if jhwctebYzkQAasmBlFfKWdGMgpTEJv=='18' or jhwctebYzkQAasmBlFfKWdGMgpTEJv=='19' or jhwctebYzkQAasmBlFfKWdGMgpTEJv=='21':jhwctebYzkQAasmBlFfKWdGMgpTECH+=' (%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEJv)
   jhwctebYzkQAasmBlFfKWdGMgpTEvu={'mediatype':'tvshow' if jhwctebYzkQAasmBlFfKWdGMgpTEvx=='vod' else 'movie','mpaa':jhwctebYzkQAasmBlFfKWdGMgpTEJv,'title':jhwctebYzkQAasmBlFfKWdGMgpTECH,'plot':jhwctebYzkQAasmBlFfKWdGMgpTECH}
   if jhwctebYzkQAasmBlFfKWdGMgpTEvx=='vod':
    jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'EPISODE_LIST','seasonid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'page':'1',}
    jhwctebYzkQAasmBlFfKWdGMgpTECO=jhwctebYzkQAasmBlFfKWdGMgpTErH
   else:
    jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'MOVIE','contentid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'title':jhwctebYzkQAasmBlFfKWdGMgpTECH,'thumbnail':jhwctebYzkQAasmBlFfKWdGMgpTEJC,'age':jhwctebYzkQAasmBlFfKWdGMgpTEJv,}
    jhwctebYzkQAasmBlFfKWdGMgpTECO=jhwctebYzkQAasmBlFfKWdGMgpTErq
   jhwctebYzkQAasmBlFfKWdGMgpTEvU=[]
   jhwctebYzkQAasmBlFfKWdGMgpTEJD={'mode':'VIEW_DETAIL','values':{'videoid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'vidtype':'tvshow' if jhwctebYzkQAasmBlFfKWdGMgpTEvx=='vod' else 'movie','contenttype':jhwctebYzkQAasmBlFfKWdGMgpTEJN,}}
   jhwctebYzkQAasmBlFfKWdGMgpTEJx=json.dumps(jhwctebYzkQAasmBlFfKWdGMgpTEJD,separators=(',',':'))
   jhwctebYzkQAasmBlFfKWdGMgpTEJx=base64.standard_b64encode(jhwctebYzkQAasmBlFfKWdGMgpTEJx.encode()).decode('utf-8')
   jhwctebYzkQAasmBlFfKWdGMgpTEJx=jhwctebYzkQAasmBlFfKWdGMgpTEJx.replace('+','%2B')
   jhwctebYzkQAasmBlFfKWdGMgpTEJn='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEJx)
   jhwctebYzkQAasmBlFfKWdGMgpTEvU.append(('상세정보 조회',jhwctebYzkQAasmBlFfKWdGMgpTEJn))
   if jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_makebookmark():
    jhwctebYzkQAasmBlFfKWdGMgpTEJD={'videoid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'vidtype':'tvshow' if jhwctebYzkQAasmBlFfKWdGMgpTEvx=='vod' else 'movie','vtitle':jhwctebYzkQAasmBlFfKWdGMgpTECH,'vsubtitle':'','contenttype':jhwctebYzkQAasmBlFfKWdGMgpTEJN,}
    jhwctebYzkQAasmBlFfKWdGMgpTEJr=json.dumps(jhwctebYzkQAasmBlFfKWdGMgpTEJD)
    jhwctebYzkQAasmBlFfKWdGMgpTEJr=urllib.parse.quote(jhwctebYzkQAasmBlFfKWdGMgpTEJr)
    jhwctebYzkQAasmBlFfKWdGMgpTEJn='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEJr)
    jhwctebYzkQAasmBlFfKWdGMgpTEvU.append(('(통합) 찜 영상에 추가',jhwctebYzkQAasmBlFfKWdGMgpTEJn))
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img=jhwctebYzkQAasmBlFfKWdGMgpTEJC,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTECO,params=jhwctebYzkQAasmBlFfKWdGMgpTECu,ContextMenu=jhwctebYzkQAasmBlFfKWdGMgpTEvU)
  if jhwctebYzkQAasmBlFfKWdGMgpTEvr:
   jhwctebYzkQAasmBlFfKWdGMgpTECu['mode'] ='SEARCH_LIST' 
   jhwctebYzkQAasmBlFfKWdGMgpTECu['sType']=jhwctebYzkQAasmBlFfKWdGMgpTEvx 
   jhwctebYzkQAasmBlFfKWdGMgpTECu['page'] =jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECu['search_key']=jhwctebYzkQAasmBlFfKWdGMgpTEvC
   jhwctebYzkQAasmBlFfKWdGMgpTECH='[B]%s >>[/B]'%'다음 페이지'
   jhwctebYzkQAasmBlFfKWdGMgpTEJS=jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEJS,img=jhwctebYzkQAasmBlFfKWdGMgpTECU,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTErI,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEvx=='movie':xbmcplugin.setContent(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,'movies')
  else:xbmcplugin.setContent(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_Watch_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEvx =args.get('sType')
  jhwctebYzkQAasmBlFfKWdGMgpTECR=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_direct_replay()
  jhwctebYzkQAasmBlFfKWdGMgpTEvy=jhwctebYzkQAasmBlFfKWdGMgpTENS.Load_List_File(jhwctebYzkQAasmBlFfKWdGMgpTEvx)
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   jhwctebYzkQAasmBlFfKWdGMgpTEvq=jhwctebYzkQAasmBlFfKWdGMgpTEri(urllib.parse.parse_qsl(jhwctebYzkQAasmBlFfKWdGMgpTEvV))
   jhwctebYzkQAasmBlFfKWdGMgpTEJR =jhwctebYzkQAasmBlFfKWdGMgpTEvq.get('code').strip()
   jhwctebYzkQAasmBlFfKWdGMgpTECH =jhwctebYzkQAasmBlFfKWdGMgpTEvq.get('title').strip()
   jhwctebYzkQAasmBlFfKWdGMgpTEJS =jhwctebYzkQAasmBlFfKWdGMgpTEvq.get('subtitle').strip()
   if jhwctebYzkQAasmBlFfKWdGMgpTEJS=='None':jhwctebYzkQAasmBlFfKWdGMgpTEJS=''
   jhwctebYzkQAasmBlFfKWdGMgpTEJC=jhwctebYzkQAasmBlFfKWdGMgpTEvq.get('img').strip()
   jhwctebYzkQAasmBlFfKWdGMgpTEvP =jhwctebYzkQAasmBlFfKWdGMgpTEvq.get('videoid').strip()
   try:
    jhwctebYzkQAasmBlFfKWdGMgpTEJC=jhwctebYzkQAasmBlFfKWdGMgpTEJC.replace('\'','\"')
    jhwctebYzkQAasmBlFfKWdGMgpTEJC=json.loads(jhwctebYzkQAasmBlFfKWdGMgpTEJC)
   except:
    jhwctebYzkQAasmBlFfKWdGMgpTErI
   jhwctebYzkQAasmBlFfKWdGMgpTEvu={'plot':'%s\n%s'%(jhwctebYzkQAasmBlFfKWdGMgpTECH,jhwctebYzkQAasmBlFfKWdGMgpTEJS)}
   if jhwctebYzkQAasmBlFfKWdGMgpTEvx=='vod':
    if jhwctebYzkQAasmBlFfKWdGMgpTECR==jhwctebYzkQAasmBlFfKWdGMgpTErq or jhwctebYzkQAasmBlFfKWdGMgpTEvP==jhwctebYzkQAasmBlFfKWdGMgpTErI:
     jhwctebYzkQAasmBlFfKWdGMgpTEvu['mediatype']='tvshow'
     jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'SEASON_LIST','videoid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'vidtype':'contentid',}
     jhwctebYzkQAasmBlFfKWdGMgpTECO=jhwctebYzkQAasmBlFfKWdGMgpTErH
    else:
     jhwctebYzkQAasmBlFfKWdGMgpTEvu['mediatype']='episode'
     jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'VOD','programid':jhwctebYzkQAasmBlFfKWdGMgpTEJR,'contentid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'title':jhwctebYzkQAasmBlFfKWdGMgpTECH,'subtitle':jhwctebYzkQAasmBlFfKWdGMgpTEJS,'thumbnail':jhwctebYzkQAasmBlFfKWdGMgpTEJC}
     jhwctebYzkQAasmBlFfKWdGMgpTECO=jhwctebYzkQAasmBlFfKWdGMgpTErq
   else:
    jhwctebYzkQAasmBlFfKWdGMgpTEvu['mediatype']='movie'
    jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'MOVIE','contentid':jhwctebYzkQAasmBlFfKWdGMgpTEJR,'title':jhwctebYzkQAasmBlFfKWdGMgpTECH,'subtitle':jhwctebYzkQAasmBlFfKWdGMgpTEJS,'thumbnail':jhwctebYzkQAasmBlFfKWdGMgpTEJC}
    jhwctebYzkQAasmBlFfKWdGMgpTECO=jhwctebYzkQAasmBlFfKWdGMgpTErq
   jhwctebYzkQAasmBlFfKWdGMgpTEvi={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':jhwctebYzkQAasmBlFfKWdGMgpTEJR,'vType':jhwctebYzkQAasmBlFfKWdGMgpTEvx,}
   jhwctebYzkQAasmBlFfKWdGMgpTEvX=urllib.parse.urlencode(jhwctebYzkQAasmBlFfKWdGMgpTEvi)
   jhwctebYzkQAasmBlFfKWdGMgpTEvU=[('선택된 시청이력 ( %s ) 삭제'%(jhwctebYzkQAasmBlFfKWdGMgpTECH),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEvX))]
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEJS,img=jhwctebYzkQAasmBlFfKWdGMgpTEJC,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTECO,params=jhwctebYzkQAasmBlFfKWdGMgpTECu,ContextMenu=jhwctebYzkQAasmBlFfKWdGMgpTEvU)
  jhwctebYzkQAasmBlFfKWdGMgpTEvu={'plot':'시청목록을 삭제합니다.'}
  jhwctebYzkQAasmBlFfKWdGMgpTECH='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':jhwctebYzkQAasmBlFfKWdGMgpTEvx,}
  jhwctebYzkQAasmBlFfKWdGMgpTECU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img=jhwctebYzkQAasmBlFfKWdGMgpTECU,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErq,params=jhwctebYzkQAasmBlFfKWdGMgpTECu,isLink=jhwctebYzkQAasmBlFfKWdGMgpTErH)
  if jhwctebYzkQAasmBlFfKWdGMgpTEvx=='movie':xbmcplugin.setContent(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,'movies')
  else:xbmcplugin.setContent(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def Load_List_File(jhwctebYzkQAasmBlFfKWdGMgpTENS,stype): 
  try:
   if stype=='search':
    jhwctebYzkQAasmBlFfKWdGMgpTEJI=jhwctebYzkQAasmBlFfKWdGMgpTENr
   elif stype in['vod','movie']:
    jhwctebYzkQAasmBlFfKWdGMgpTEJI=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=jhwctebYzkQAasmBlFfKWdGMgpTErV(jhwctebYzkQAasmBlFfKWdGMgpTEJI,'r',-1,'utf-8')
   jhwctebYzkQAasmBlFfKWdGMgpTEJo=fp.readlines()
   fp.close()
  except:
   jhwctebYzkQAasmBlFfKWdGMgpTEJo=[]
  return jhwctebYzkQAasmBlFfKWdGMgpTEJo
 def Save_Watched_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,jhwctebYzkQAasmBlFfKWdGMgpTEnU,jhwctebYzkQAasmBlFfKWdGMgpTENo):
  try:
   jhwctebYzkQAasmBlFfKWdGMgpTEJH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%jhwctebYzkQAasmBlFfKWdGMgpTEnU))
   jhwctebYzkQAasmBlFfKWdGMgpTEJq=jhwctebYzkQAasmBlFfKWdGMgpTENS.Load_List_File(jhwctebYzkQAasmBlFfKWdGMgpTEnU) 
   fp=jhwctebYzkQAasmBlFfKWdGMgpTErV(jhwctebYzkQAasmBlFfKWdGMgpTEJH,'w',-1,'utf-8')
   jhwctebYzkQAasmBlFfKWdGMgpTEJL=urllib.parse.urlencode(jhwctebYzkQAasmBlFfKWdGMgpTENo)
   jhwctebYzkQAasmBlFfKWdGMgpTEJL=jhwctebYzkQAasmBlFfKWdGMgpTEJL+'\n'
   fp.write(jhwctebYzkQAasmBlFfKWdGMgpTEJL)
   jhwctebYzkQAasmBlFfKWdGMgpTEJi=0
   for jhwctebYzkQAasmBlFfKWdGMgpTEJX in jhwctebYzkQAasmBlFfKWdGMgpTEJq:
    jhwctebYzkQAasmBlFfKWdGMgpTEJU=jhwctebYzkQAasmBlFfKWdGMgpTEri(urllib.parse.parse_qsl(jhwctebYzkQAasmBlFfKWdGMgpTEJX))
    jhwctebYzkQAasmBlFfKWdGMgpTEJu=jhwctebYzkQAasmBlFfKWdGMgpTENo.get('code').strip()
    jhwctebYzkQAasmBlFfKWdGMgpTEJO=jhwctebYzkQAasmBlFfKWdGMgpTEJU.get('code').strip()
    if jhwctebYzkQAasmBlFfKWdGMgpTEnU=='vod' and jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_direct_replay()==jhwctebYzkQAasmBlFfKWdGMgpTErH:
     jhwctebYzkQAasmBlFfKWdGMgpTEJu=jhwctebYzkQAasmBlFfKWdGMgpTENo.get('videoid').strip()
     jhwctebYzkQAasmBlFfKWdGMgpTEJO=jhwctebYzkQAasmBlFfKWdGMgpTEJU.get('videoid').strip()if jhwctebYzkQAasmBlFfKWdGMgpTEJO!=jhwctebYzkQAasmBlFfKWdGMgpTErI else '-'
    if jhwctebYzkQAasmBlFfKWdGMgpTEJu!=jhwctebYzkQAasmBlFfKWdGMgpTEJO:
     fp.write(jhwctebYzkQAasmBlFfKWdGMgpTEJX)
     jhwctebYzkQAasmBlFfKWdGMgpTEJi+=1
     if jhwctebYzkQAasmBlFfKWdGMgpTEJi>=50:break
   fp.close()
  except:
   jhwctebYzkQAasmBlFfKWdGMgpTErI
 def dp_History_Remove(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEJy=args.get('delType')
  jhwctebYzkQAasmBlFfKWdGMgpTEJV =args.get('sKey')
  jhwctebYzkQAasmBlFfKWdGMgpTEJP =args.get('vType')
  jhwctebYzkQAasmBlFfKWdGMgpTENq=xbmcgui.Dialog()
  if jhwctebYzkQAasmBlFfKWdGMgpTEJy=='SEARCH_ALL':
   jhwctebYzkQAasmBlFfKWdGMgpTEDN=jhwctebYzkQAasmBlFfKWdGMgpTENq.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif jhwctebYzkQAasmBlFfKWdGMgpTEJy=='SEARCH_ONE':
   jhwctebYzkQAasmBlFfKWdGMgpTEDN=jhwctebYzkQAasmBlFfKWdGMgpTENq.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif jhwctebYzkQAasmBlFfKWdGMgpTEJy=='WATCH_ALL':
   jhwctebYzkQAasmBlFfKWdGMgpTEDN=jhwctebYzkQAasmBlFfKWdGMgpTENq.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif jhwctebYzkQAasmBlFfKWdGMgpTEJy=='WATCH_ONE':
   jhwctebYzkQAasmBlFfKWdGMgpTEDN=jhwctebYzkQAasmBlFfKWdGMgpTENq.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if jhwctebYzkQAasmBlFfKWdGMgpTEDN==jhwctebYzkQAasmBlFfKWdGMgpTErq:sys.exit()
  if jhwctebYzkQAasmBlFfKWdGMgpTEJy=='SEARCH_ALL':
   if os.path.isfile(jhwctebYzkQAasmBlFfKWdGMgpTENr):os.remove(jhwctebYzkQAasmBlFfKWdGMgpTENr)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEJy=='SEARCH_ONE':
   try:
    jhwctebYzkQAasmBlFfKWdGMgpTEJI=jhwctebYzkQAasmBlFfKWdGMgpTENr
    jhwctebYzkQAasmBlFfKWdGMgpTEJq=jhwctebYzkQAasmBlFfKWdGMgpTENS.Load_List_File('search') 
    fp=jhwctebYzkQAasmBlFfKWdGMgpTErV(jhwctebYzkQAasmBlFfKWdGMgpTEJI,'w',-1,'utf-8')
    for jhwctebYzkQAasmBlFfKWdGMgpTEJX in jhwctebYzkQAasmBlFfKWdGMgpTEJq:
     jhwctebYzkQAasmBlFfKWdGMgpTEJU=jhwctebYzkQAasmBlFfKWdGMgpTEri(urllib.parse.parse_qsl(jhwctebYzkQAasmBlFfKWdGMgpTEJX))
     jhwctebYzkQAasmBlFfKWdGMgpTEDC=jhwctebYzkQAasmBlFfKWdGMgpTEJU.get('skey').strip()
     if jhwctebYzkQAasmBlFfKWdGMgpTEJV!=jhwctebYzkQAasmBlFfKWdGMgpTEDC:
      fp.write(jhwctebYzkQAasmBlFfKWdGMgpTEJX)
    fp.close()
   except:
    jhwctebYzkQAasmBlFfKWdGMgpTErI
  elif jhwctebYzkQAasmBlFfKWdGMgpTEJy=='WATCH_ALL':
   jhwctebYzkQAasmBlFfKWdGMgpTEJI=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%jhwctebYzkQAasmBlFfKWdGMgpTEJP))
   if os.path.isfile(jhwctebYzkQAasmBlFfKWdGMgpTEJI):os.remove(jhwctebYzkQAasmBlFfKWdGMgpTEJI)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEJy=='WATCH_ONE':
   jhwctebYzkQAasmBlFfKWdGMgpTEJI=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%jhwctebYzkQAasmBlFfKWdGMgpTEJP))
   try:
    jhwctebYzkQAasmBlFfKWdGMgpTEJq=jhwctebYzkQAasmBlFfKWdGMgpTENS.Load_List_File(jhwctebYzkQAasmBlFfKWdGMgpTEJP) 
    fp=jhwctebYzkQAasmBlFfKWdGMgpTErV(jhwctebYzkQAasmBlFfKWdGMgpTEJI,'w',-1,'utf-8')
    for jhwctebYzkQAasmBlFfKWdGMgpTEJX in jhwctebYzkQAasmBlFfKWdGMgpTEJq:
     jhwctebYzkQAasmBlFfKWdGMgpTEJU=jhwctebYzkQAasmBlFfKWdGMgpTEri(urllib.parse.parse_qsl(jhwctebYzkQAasmBlFfKWdGMgpTEJX))
     jhwctebYzkQAasmBlFfKWdGMgpTEDC=jhwctebYzkQAasmBlFfKWdGMgpTEJU.get('code').strip()
     if jhwctebYzkQAasmBlFfKWdGMgpTEJV!=jhwctebYzkQAasmBlFfKWdGMgpTEDC:
      fp.write(jhwctebYzkQAasmBlFfKWdGMgpTEJX)
    fp.close()
   except:
    jhwctebYzkQAasmBlFfKWdGMgpTErI
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,jhwctebYzkQAasmBlFfKWdGMgpTEvC):
  try:
   jhwctebYzkQAasmBlFfKWdGMgpTEDv=jhwctebYzkQAasmBlFfKWdGMgpTENr
   jhwctebYzkQAasmBlFfKWdGMgpTEJq=jhwctebYzkQAasmBlFfKWdGMgpTENS.Load_List_File('search') 
   jhwctebYzkQAasmBlFfKWdGMgpTEDJ={'skey':jhwctebYzkQAasmBlFfKWdGMgpTEvC.strip()}
   fp=jhwctebYzkQAasmBlFfKWdGMgpTErV(jhwctebYzkQAasmBlFfKWdGMgpTEDv,'w',-1,'utf-8')
   jhwctebYzkQAasmBlFfKWdGMgpTEJL=urllib.parse.urlencode(jhwctebYzkQAasmBlFfKWdGMgpTEDJ)
   jhwctebYzkQAasmBlFfKWdGMgpTEJL=jhwctebYzkQAasmBlFfKWdGMgpTEJL+'\n'
   fp.write(jhwctebYzkQAasmBlFfKWdGMgpTEJL)
   jhwctebYzkQAasmBlFfKWdGMgpTEJi=0
   for jhwctebYzkQAasmBlFfKWdGMgpTEJX in jhwctebYzkQAasmBlFfKWdGMgpTEJq:
    jhwctebYzkQAasmBlFfKWdGMgpTEJU=jhwctebYzkQAasmBlFfKWdGMgpTEri(urllib.parse.parse_qsl(jhwctebYzkQAasmBlFfKWdGMgpTEJX))
    jhwctebYzkQAasmBlFfKWdGMgpTEJu=jhwctebYzkQAasmBlFfKWdGMgpTEDJ.get('skey').strip()
    jhwctebYzkQAasmBlFfKWdGMgpTEJO=jhwctebYzkQAasmBlFfKWdGMgpTEJU.get('skey').strip()
    if jhwctebYzkQAasmBlFfKWdGMgpTEJu!=jhwctebYzkQAasmBlFfKWdGMgpTEJO:
     fp.write(jhwctebYzkQAasmBlFfKWdGMgpTEJX)
     jhwctebYzkQAasmBlFfKWdGMgpTEJi+=1
     if jhwctebYzkQAasmBlFfKWdGMgpTEJi>=50:break
   fp.close()
  except:
   jhwctebYzkQAasmBlFfKWdGMgpTErI
 def dp_Global_Search(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEvD=args.get('mode')
  if jhwctebYzkQAasmBlFfKWdGMgpTEvD=='TOTAL_SEARCH':
   jhwctebYzkQAasmBlFfKWdGMgpTEDx='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   jhwctebYzkQAasmBlFfKWdGMgpTEDx='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(jhwctebYzkQAasmBlFfKWdGMgpTEDx)
 def dp_Bookmark_Menu(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEDx='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(jhwctebYzkQAasmBlFfKWdGMgpTEDx)
 def login_main(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  (jhwctebYzkQAasmBlFfKWdGMgpTEDn,jhwctebYzkQAasmBlFfKWdGMgpTEDr,jhwctebYzkQAasmBlFfKWdGMgpTEDS)=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_account()
  if not(jhwctebYzkQAasmBlFfKWdGMgpTEDn and jhwctebYzkQAasmBlFfKWdGMgpTEDr):
   jhwctebYzkQAasmBlFfKWdGMgpTENq=xbmcgui.Dialog()
   jhwctebYzkQAasmBlFfKWdGMgpTEDN=jhwctebYzkQAasmBlFfKWdGMgpTENq.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if jhwctebYzkQAasmBlFfKWdGMgpTEDN==jhwctebYzkQAasmBlFfKWdGMgpTErH:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if jhwctebYzkQAasmBlFfKWdGMgpTENS.cookiefile_check()==jhwctebYzkQAasmBlFfKWdGMgpTErH:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   jhwctebYzkQAasmBlFfKWdGMgpTEDR=0
   while jhwctebYzkQAasmBlFfKWdGMgpTErH:
    jhwctebYzkQAasmBlFfKWdGMgpTEDR+=1
    time.sleep(0.05)
    if jhwctebYzkQAasmBlFfKWdGMgpTEDR>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  jhwctebYzkQAasmBlFfKWdGMgpTEDI=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.GetCredential(jhwctebYzkQAasmBlFfKWdGMgpTEDn,jhwctebYzkQAasmBlFfKWdGMgpTEDr,jhwctebYzkQAasmBlFfKWdGMgpTEDS)
  if jhwctebYzkQAasmBlFfKWdGMgpTEDI:jhwctebYzkQAasmBlFfKWdGMgpTENS.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if jhwctebYzkQAasmBlFfKWdGMgpTEDI==jhwctebYzkQAasmBlFfKWdGMgpTErq:
   jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTECI =args.get('orderby')
  jhwctebYzkQAasmBlFfKWdGMgpTENS.set_winEpisodeOrderby(jhwctebYzkQAasmBlFfKWdGMgpTECI)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEvD =args.get('mode')
  jhwctebYzkQAasmBlFfKWdGMgpTEDo =args.get('contentid')
  jhwctebYzkQAasmBlFfKWdGMgpTEDH =args.get('pvrmode')
  jhwctebYzkQAasmBlFfKWdGMgpTEDq=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_selQuality()
  jhwctebYzkQAasmBlFfKWdGMgpTECJ =jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_play()
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log(jhwctebYzkQAasmBlFfKWdGMgpTEDo+' - '+jhwctebYzkQAasmBlFfKWdGMgpTEvD)
  if jhwctebYzkQAasmBlFfKWdGMgpTEvD=='SPORTS':
   jhwctebYzkQAasmBlFfKWdGMgpTEDL=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.GetSportsURL(jhwctebYzkQAasmBlFfKWdGMgpTEDo,jhwctebYzkQAasmBlFfKWdGMgpTEDq)
  else:
   jhwctebYzkQAasmBlFfKWdGMgpTEDL=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.GetStreamingURL(jhwctebYzkQAasmBlFfKWdGMgpTEvD,jhwctebYzkQAasmBlFfKWdGMgpTEDo,jhwctebYzkQAasmBlFfKWdGMgpTEDq,jhwctebYzkQAasmBlFfKWdGMgpTEDH,playOption=jhwctebYzkQAasmBlFfKWdGMgpTECJ)
  jhwctebYzkQAasmBlFfKWdGMgpTEDi={'user-agent':jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.USER_AGENT}
  jhwctebYzkQAasmBlFfKWdGMgpTEDX=jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_cookie'] 
  jhwctebYzkQAasmBlFfKWdGMgpTEDU='{}|{}'.format(jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_url'],jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.make_stream_header(jhwctebYzkQAasmBlFfKWdGMgpTEDi,jhwctebYzkQAasmBlFfKWdGMgpTEDX))
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log('surl : '+jhwctebYzkQAasmBlFfKWdGMgpTEDU)
  if jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_url']=='':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_noti(__language__(30907).encode('utf8'))
   return
  jhwctebYzkQAasmBlFfKWdGMgpTECD,jhwctebYzkQAasmBlFfKWdGMgpTECx=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_proxyport()
  jhwctebYzkQAasmBlFfKWdGMgpTEDu=urllib.parse.urlparse(jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_url'])
  jhwctebYzkQAasmBlFfKWdGMgpTEDu=jhwctebYzkQAasmBlFfKWdGMgpTEDu.path.strip('/').split('/')
  jhwctebYzkQAasmBlFfKWdGMgpTEDu=jhwctebYzkQAasmBlFfKWdGMgpTEDu[jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTEDu)-1] 
  if (jhwctebYzkQAasmBlFfKWdGMgpTECD==jhwctebYzkQAasmBlFfKWdGMgpTErH and args.get('mode')in['VOD','MOVIE']and(jhwctebYzkQAasmBlFfKWdGMgpTEDL['playParam']['hdr']=='hdr' or jhwctebYzkQAasmBlFfKWdGMgpTEDL['playParam']['uhd']=='uhd')):
   if jhwctebYzkQAasmBlFfKWdGMgpTEDu.split('.')[1]=='mpd':
    jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Wavve_Parse_mpd(jhwctebYzkQAasmBlFfKWdGMgpTEDL)
   else:
    jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Wavve_Parse_m3u8(jhwctebYzkQAasmBlFfKWdGMgpTEDL)
   jhwctebYzkQAasmBlFfKWdGMgpTEDO={'addon':'wavvem','playOption':jhwctebYzkQAasmBlFfKWdGMgpTECJ,}
   jhwctebYzkQAasmBlFfKWdGMgpTEDO=json.dumps(jhwctebYzkQAasmBlFfKWdGMgpTEDO,separators=(',',':'))
   jhwctebYzkQAasmBlFfKWdGMgpTEDO=base64.standard_b64encode(jhwctebYzkQAasmBlFfKWdGMgpTEDO.encode()).decode('utf-8')
   jhwctebYzkQAasmBlFfKWdGMgpTEDU ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(jhwctebYzkQAasmBlFfKWdGMgpTECx,jhwctebYzkQAasmBlFfKWdGMgpTEDU,jhwctebYzkQAasmBlFfKWdGMgpTEDO)
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log('surl : '+jhwctebYzkQAasmBlFfKWdGMgpTEDU)
  jhwctebYzkQAasmBlFfKWdGMgpTEDy=xbmcgui.ListItem(path=jhwctebYzkQAasmBlFfKWdGMgpTEDU)
  if jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_drm']:
   jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log('!!streaming_drm!!')
   jhwctebYzkQAasmBlFfKWdGMgpTEDV =inputstreamhelper.Helper('mpd',drm='widevine')
   if 'licensetoken' in jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_drm']:
    jhwctebYzkQAasmBlFfKWdGMgpTEDP=jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_drm']['licensetoken']
    jhwctebYzkQAasmBlFfKWdGMgpTExN =jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_drm']['licenseurl']
    if jhwctebYzkQAasmBlFfKWdGMgpTEvD=='MOVIE':
     jhwctebYzkQAasmBlFfKWdGMgpTExC='https://www.wavve.com/player/movie?movieid=%s'%jhwctebYzkQAasmBlFfKWdGMgpTEDo
    else:
     jhwctebYzkQAasmBlFfKWdGMgpTExC='https://www.wavve.com/player/vod?programid=%s&page=1'%jhwctebYzkQAasmBlFfKWdGMgpTEDo
    jhwctebYzkQAasmBlFfKWdGMgpTExv={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':jhwctebYzkQAasmBlFfKWdGMgpTEDP,'referer':jhwctebYzkQAasmBlFfKWdGMgpTExC,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.USER_AGENT,}
   else:
    jhwctebYzkQAasmBlFfKWdGMgpTEDP=jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_drm']['customdata']
    jhwctebYzkQAasmBlFfKWdGMgpTExN =jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_drm']['drmhost']
    if jhwctebYzkQAasmBlFfKWdGMgpTEvD=='MOVIE':
     jhwctebYzkQAasmBlFfKWdGMgpTExC='https://www.wavve.com/player/movie?movieid=%s'%jhwctebYzkQAasmBlFfKWdGMgpTEDo
    else:
     jhwctebYzkQAasmBlFfKWdGMgpTExC='https://www.wavve.com/player/vod?programid=%s&page=1'%jhwctebYzkQAasmBlFfKWdGMgpTEDo
    jhwctebYzkQAasmBlFfKWdGMgpTExv={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':jhwctebYzkQAasmBlFfKWdGMgpTEDP,'referer':jhwctebYzkQAasmBlFfKWdGMgpTExC,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.USER_AGENT,}
   jhwctebYzkQAasmBlFfKWdGMgpTExJ=jhwctebYzkQAasmBlFfKWdGMgpTExN+'|'+urllib.parse.urlencode(jhwctebYzkQAasmBlFfKWdGMgpTExv)+'|R{SSM}|'
   jhwctebYzkQAasmBlFfKWdGMgpTEDy.setProperty('inputstream',jhwctebYzkQAasmBlFfKWdGMgpTEDV.inputstream_addon)
   jhwctebYzkQAasmBlFfKWdGMgpTEDy.setProperty('inputstream.adaptive.manifest_type','mpd')
   jhwctebYzkQAasmBlFfKWdGMgpTEDy.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   jhwctebYzkQAasmBlFfKWdGMgpTEDy.setProperty('inputstream.adaptive.license_key',jhwctebYzkQAasmBlFfKWdGMgpTExJ)
   jhwctebYzkQAasmBlFfKWdGMgpTEDy.setProperty('inputstream.adaptive.stream_headers','{}'.format(jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.make_stream_header(jhwctebYzkQAasmBlFfKWdGMgpTEDi,jhwctebYzkQAasmBlFfKWdGMgpTEDX)))
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD in['VOD','MOVIE']:
   jhwctebYzkQAasmBlFfKWdGMgpTEDy.setContentLookup(jhwctebYzkQAasmBlFfKWdGMgpTErq)
   jhwctebYzkQAasmBlFfKWdGMgpTEDy.setMimeType('application/x-mpegURL')
   jhwctebYzkQAasmBlFfKWdGMgpTEDy.setProperty('inputstream','inputstream.adaptive')
   if jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_action']=='hls':
    jhwctebYzkQAasmBlFfKWdGMgpTEDy.setProperty('inputstream.adaptive.manifest_type','hls')
   else:
    jhwctebYzkQAasmBlFfKWdGMgpTEDy.setProperty('inputstream.adaptive.manifest_type','mpd')
   jhwctebYzkQAasmBlFfKWdGMgpTEDy.setProperty('inputstream.adaptive.stream_headers','{}'.format(jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.make_stream_header(jhwctebYzkQAasmBlFfKWdGMgpTEDi,jhwctebYzkQAasmBlFfKWdGMgpTEDX)))
  if jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_vtt']:
   jhwctebYzkQAasmBlFfKWdGMgpTEDy.setSubtitles([jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_vtt']])
  xbmcplugin.setResolvedUrl(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,jhwctebYzkQAasmBlFfKWdGMgpTErH,jhwctebYzkQAasmBlFfKWdGMgpTEDy)
  jhwctebYzkQAasmBlFfKWdGMgpTExD=jhwctebYzkQAasmBlFfKWdGMgpTErq
  if jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_preview']:
   jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_noti(jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_preview'].encode('utf-8'))
   jhwctebYzkQAasmBlFfKWdGMgpTExD=jhwctebYzkQAasmBlFfKWdGMgpTErH
  else:
   if '/preview.' in urllib.parse.urlsplit(jhwctebYzkQAasmBlFfKWdGMgpTEDL['stream_url']).path:
    jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_noti(__language__(30908).encode('utf8'))
    jhwctebYzkQAasmBlFfKWdGMgpTExD=jhwctebYzkQAasmBlFfKWdGMgpTErH
  try:
   jhwctebYzkQAasmBlFfKWdGMgpTExn=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and jhwctebYzkQAasmBlFfKWdGMgpTExD==jhwctebYzkQAasmBlFfKWdGMgpTErq and jhwctebYzkQAasmBlFfKWdGMgpTExn!='-':
    jhwctebYzkQAasmBlFfKWdGMgpTECu={'code':jhwctebYzkQAasmBlFfKWdGMgpTExn,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    jhwctebYzkQAasmBlFfKWdGMgpTENS.Save_Watched_List(args.get('mode').lower(),jhwctebYzkQAasmBlFfKWdGMgpTECu)
  except:
   jhwctebYzkQAasmBlFfKWdGMgpTErI
 def logout(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  jhwctebYzkQAasmBlFfKWdGMgpTENq=xbmcgui.Dialog()
  jhwctebYzkQAasmBlFfKWdGMgpTEDN=jhwctebYzkQAasmBlFfKWdGMgpTENq.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if jhwctebYzkQAasmBlFfKWdGMgpTEDN==jhwctebYzkQAasmBlFfKWdGMgpTErq:sys.exit()
  jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Init_WV_Total()
  if os.path.isfile(jhwctebYzkQAasmBlFfKWdGMgpTENn):os.remove(jhwctebYzkQAasmBlFfKWdGMgpTENn)
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  jhwctebYzkQAasmBlFfKWdGMgpTExr =jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_Now_Datetime()
  jhwctebYzkQAasmBlFfKWdGMgpTExS=jhwctebYzkQAasmBlFfKWdGMgpTExr+datetime.timedelta(days=jhwctebYzkQAasmBlFfKWdGMgpTEro(__addon__.getSetting('cache_ttl')))
  (jhwctebYzkQAasmBlFfKWdGMgpTEDn,jhwctebYzkQAasmBlFfKWdGMgpTEDr,jhwctebYzkQAasmBlFfKWdGMgpTEDS)=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_account()
  jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Save_session_acount(jhwctebYzkQAasmBlFfKWdGMgpTEDn,jhwctebYzkQAasmBlFfKWdGMgpTEDr,jhwctebYzkQAasmBlFfKWdGMgpTEDS)
  jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.WV['account']['token_limit']=jhwctebYzkQAasmBlFfKWdGMgpTExS.strftime('%Y%m%d')
  jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.JsonFile_Save(jhwctebYzkQAasmBlFfKWdGMgpTENn,jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.WV)
 def cookiefile_check(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.WV=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.JsonFile_Load(jhwctebYzkQAasmBlFfKWdGMgpTENn)
  if 'account' not in jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.WV:
   jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Init_WV_Total()
   return jhwctebYzkQAasmBlFfKWdGMgpTErq
  if 'uuid' not in jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.WV.get('cookies'):
   jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Init_WV_Total()
   return jhwctebYzkQAasmBlFfKWdGMgpTErq
  (jhwctebYzkQAasmBlFfKWdGMgpTExR,jhwctebYzkQAasmBlFfKWdGMgpTExI,jhwctebYzkQAasmBlFfKWdGMgpTExo)=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_account()
  (jhwctebYzkQAasmBlFfKWdGMgpTExH,jhwctebYzkQAasmBlFfKWdGMgpTExq,jhwctebYzkQAasmBlFfKWdGMgpTExL)=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Load_session_acount()
  if jhwctebYzkQAasmBlFfKWdGMgpTExR!=jhwctebYzkQAasmBlFfKWdGMgpTExH or jhwctebYzkQAasmBlFfKWdGMgpTExI!=jhwctebYzkQAasmBlFfKWdGMgpTExq or jhwctebYzkQAasmBlFfKWdGMgpTExo!=jhwctebYzkQAasmBlFfKWdGMgpTExL:
   jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Init_WV_Total()
   return jhwctebYzkQAasmBlFfKWdGMgpTErq
  if jhwctebYzkQAasmBlFfKWdGMgpTEro(jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>jhwctebYzkQAasmBlFfKWdGMgpTEro(jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.WV['account']['token_limit']):
   jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Init_WV_Total()
   return jhwctebYzkQAasmBlFfKWdGMgpTErq
  return jhwctebYzkQAasmBlFfKWdGMgpTErH
 def dp_LiveCatagory_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTExi =args.get('sCode')
  jhwctebYzkQAasmBlFfKWdGMgpTExX=args.get('sIndex')
  jhwctebYzkQAasmBlFfKWdGMgpTEvy,jhwctebYzkQAasmBlFfKWdGMgpTExU=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_LiveCatagory_List(jhwctebYzkQAasmBlFfKWdGMgpTExi,jhwctebYzkQAasmBlFfKWdGMgpTExX)
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   jhwctebYzkQAasmBlFfKWdGMgpTECH =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('title')
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'LIVE_LIST','genre':jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('genre'),'baseapi':jhwctebYzkQAasmBlFfKWdGMgpTExU}
   jhwctebYzkQAasmBlFfKWdGMgpTECV={'title':jhwctebYzkQAasmBlFfKWdGMgpTECH,'plot':jhwctebYzkQAasmBlFfKWdGMgpTECH}
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img='',infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTECV,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTEvy)>0:xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_MainCatagory_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTExi =args.get('sCode')
  jhwctebYzkQAasmBlFfKWdGMgpTExX=args.get('sIndex')
  jhwctebYzkQAasmBlFfKWdGMgpTEvx =args.get('sType')
  jhwctebYzkQAasmBlFfKWdGMgpTEvy=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_MainCatagory_List(jhwctebYzkQAasmBlFfKWdGMgpTExi,jhwctebYzkQAasmBlFfKWdGMgpTExX,jhwctebYzkQAasmBlFfKWdGMgpTEvx)
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   if jhwctebYzkQAasmBlFfKWdGMgpTEvx in['vod','vod09']:
    if jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('subtype')=='catagory':
     jhwctebYzkQAasmBlFfKWdGMgpTEvD='PROGRAM_LIST'
    else:
     jhwctebYzkQAasmBlFfKWdGMgpTEvD='SUPERSECTION_LIST'
   elif jhwctebYzkQAasmBlFfKWdGMgpTEvx=='movie':
    jhwctebYzkQAasmBlFfKWdGMgpTEvD='MOVIE_LIST'
   else:
    jhwctebYzkQAasmBlFfKWdGMgpTEvD=''
   jhwctebYzkQAasmBlFfKWdGMgpTECH='%s (%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('title'),args.get('ordernm'))
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':jhwctebYzkQAasmBlFfKWdGMgpTEvD,'suburl':jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('suburl'),'subapi':jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_exclusion21():
    if jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('title')=='성인' or jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('title')=='성인+' or jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('title')=='에로티시즘' or jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('title')=='19':continue
   jhwctebYzkQAasmBlFfKWdGMgpTECV={'title':jhwctebYzkQAasmBlFfKWdGMgpTECH,'plot':jhwctebYzkQAasmBlFfKWdGMgpTECH}
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img='',infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTECV,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTEvy)>0:xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_Program_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTExu =args.get('subapi')
  jhwctebYzkQAasmBlFfKWdGMgpTEvO=jhwctebYzkQAasmBlFfKWdGMgpTEro(args.get('page'))
  jhwctebYzkQAasmBlFfKWdGMgpTECI =args.get('orderby')
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log('dp_Program_List')
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log(jhwctebYzkQAasmBlFfKWdGMgpTExu)
  jhwctebYzkQAasmBlFfKWdGMgpTEvy,jhwctebYzkQAasmBlFfKWdGMgpTEvr=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_Program_List(jhwctebYzkQAasmBlFfKWdGMgpTExu,jhwctebYzkQAasmBlFfKWdGMgpTEvO,jhwctebYzkQAasmBlFfKWdGMgpTECI)
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   jhwctebYzkQAasmBlFfKWdGMgpTEvP =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('videoid')
   jhwctebYzkQAasmBlFfKWdGMgpTEJN =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('vidtype')
   jhwctebYzkQAasmBlFfKWdGMgpTECH =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('title')
   jhwctebYzkQAasmBlFfKWdGMgpTEJC=jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('thumbnail')
   jhwctebYzkQAasmBlFfKWdGMgpTEJv =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('age')
   if jhwctebYzkQAasmBlFfKWdGMgpTEJv=='18' or jhwctebYzkQAasmBlFfKWdGMgpTEJv=='19' or jhwctebYzkQAasmBlFfKWdGMgpTEJv=='21':jhwctebYzkQAasmBlFfKWdGMgpTECH+=' (%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEJv)
   jhwctebYzkQAasmBlFfKWdGMgpTECV={'plot':jhwctebYzkQAasmBlFfKWdGMgpTECH,'mpaa':jhwctebYzkQAasmBlFfKWdGMgpTEJv,'mediatype':'tvshow','title':jhwctebYzkQAasmBlFfKWdGMgpTECH,}
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'SEASON_LIST','videoid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'vidtype':jhwctebYzkQAasmBlFfKWdGMgpTEJN,}
   jhwctebYzkQAasmBlFfKWdGMgpTEvU=[]
   jhwctebYzkQAasmBlFfKWdGMgpTEJD={'mode':'VIEW_DETAIL','values':{'videoid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'vidtype':'tvshow','contenttype':jhwctebYzkQAasmBlFfKWdGMgpTEJN,}}
   jhwctebYzkQAasmBlFfKWdGMgpTEJx=json.dumps(jhwctebYzkQAasmBlFfKWdGMgpTEJD,separators=(',',':'))
   jhwctebYzkQAasmBlFfKWdGMgpTEJx=base64.standard_b64encode(jhwctebYzkQAasmBlFfKWdGMgpTEJx.encode()).decode('utf-8')
   jhwctebYzkQAasmBlFfKWdGMgpTEJx=jhwctebYzkQAasmBlFfKWdGMgpTEJx.replace('+','%2B')
   jhwctebYzkQAasmBlFfKWdGMgpTEJn='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEJx)
   jhwctebYzkQAasmBlFfKWdGMgpTEvU.append(('상세정보 조회',jhwctebYzkQAasmBlFfKWdGMgpTEJn))
   if jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_makebookmark():
    jhwctebYzkQAasmBlFfKWdGMgpTEJD={'videoid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'vidtype':'tvshow','vtitle':jhwctebYzkQAasmBlFfKWdGMgpTECH,'vsubtitle':'','contenttype':jhwctebYzkQAasmBlFfKWdGMgpTEJN,}
    jhwctebYzkQAasmBlFfKWdGMgpTEJr=json.dumps(jhwctebYzkQAasmBlFfKWdGMgpTEJD)
    jhwctebYzkQAasmBlFfKWdGMgpTEJr=urllib.parse.quote(jhwctebYzkQAasmBlFfKWdGMgpTEJr)
    jhwctebYzkQAasmBlFfKWdGMgpTEJn='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEJr)
    jhwctebYzkQAasmBlFfKWdGMgpTEvU.append(('(통합) 찜 영상에 추가',jhwctebYzkQAasmBlFfKWdGMgpTEJn))
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img=jhwctebYzkQAasmBlFfKWdGMgpTEJC,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTECV,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu,ContextMenu=jhwctebYzkQAasmBlFfKWdGMgpTEvU)
  if jhwctebYzkQAasmBlFfKWdGMgpTEvr:
   jhwctebYzkQAasmBlFfKWdGMgpTECu={}
   jhwctebYzkQAasmBlFfKWdGMgpTECu['mode'] ='PROGRAM_LIST' 
   jhwctebYzkQAasmBlFfKWdGMgpTECu['subapi']=jhwctebYzkQAasmBlFfKWdGMgpTExu 
   jhwctebYzkQAasmBlFfKWdGMgpTECu['page'] =jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECH='[B]%s >>[/B]'%'다음 페이지'
   jhwctebYzkQAasmBlFfKWdGMgpTEJS=jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEJS,img=jhwctebYzkQAasmBlFfKWdGMgpTECU,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTErI,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  xbmcplugin.setContent(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,'tvshows')
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTEvy)>0:xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_Season_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEvP=args.get('videoid')
  jhwctebYzkQAasmBlFfKWdGMgpTEJN=args.get('vidtype')
  if jhwctebYzkQAasmBlFfKWdGMgpTEJN=='contentid':
   jhwctebYzkQAasmBlFfKWdGMgpTEDo=jhwctebYzkQAasmBlFfKWdGMgpTEvP
   jhwctebYzkQAasmBlFfKWdGMgpTExO =jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.ContentidToSeasonid(jhwctebYzkQAasmBlFfKWdGMgpTEvP)
  else:
   jhwctebYzkQAasmBlFfKWdGMgpTEDo=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.ProgramidToContentid(jhwctebYzkQAasmBlFfKWdGMgpTEvP)
   jhwctebYzkQAasmBlFfKWdGMgpTExO =jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.ContentidToSeasonid(jhwctebYzkQAasmBlFfKWdGMgpTEDo)
  jhwctebYzkQAasmBlFfKWdGMgpTExy=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_Season_List(jhwctebYzkQAasmBlFfKWdGMgpTExO)
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTExy)>1:
   for jhwctebYzkQAasmBlFfKWdGMgpTExV in jhwctebYzkQAasmBlFfKWdGMgpTExy:
    jhwctebYzkQAasmBlFfKWdGMgpTExP=jhwctebYzkQAasmBlFfKWdGMgpTExV.get('season_Id')
    jhwctebYzkQAasmBlFfKWdGMgpTEnN=jhwctebYzkQAasmBlFfKWdGMgpTExV.get('season_Nm')
    jhwctebYzkQAasmBlFfKWdGMgpTEnC=jhwctebYzkQAasmBlFfKWdGMgpTExV.get('programNm')
    jhwctebYzkQAasmBlFfKWdGMgpTEJC=jhwctebYzkQAasmBlFfKWdGMgpTExV.get('thumbnail')
    jhwctebYzkQAasmBlFfKWdGMgpTEnv =jhwctebYzkQAasmBlFfKWdGMgpTExV.get('synopsis')
    jhwctebYzkQAasmBlFfKWdGMgpTEvu={'mediatype':'tvshow','title':jhwctebYzkQAasmBlFfKWdGMgpTEnN,'plot':jhwctebYzkQAasmBlFfKWdGMgpTEnv,}
    jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'EPISODE_LIST','seasonid':jhwctebYzkQAasmBlFfKWdGMgpTExP,'page':'1',}
    jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTEnN,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEnC,img=jhwctebYzkQAasmBlFfKWdGMgpTEJC,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu,ContextMenu=jhwctebYzkQAasmBlFfKWdGMgpTErI)
   xbmcplugin.setContent(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
  else:
   jhwctebYzkQAasmBlFfKWdGMgpTEnJ={'seasonid':jhwctebYzkQAasmBlFfKWdGMgpTExO,'page':'1',}
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Episode_List(jhwctebYzkQAasmBlFfKWdGMgpTEnJ)
 def dp_Episode_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTExO =args.get('seasonid')
  jhwctebYzkQAasmBlFfKWdGMgpTEvO =jhwctebYzkQAasmBlFfKWdGMgpTEro(args.get('page'))
  jhwctebYzkQAasmBlFfKWdGMgpTEvy,jhwctebYzkQAasmBlFfKWdGMgpTEvr=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_Episode_List(jhwctebYzkQAasmBlFfKWdGMgpTExO,jhwctebYzkQAasmBlFfKWdGMgpTEvO,orderby=jhwctebYzkQAasmBlFfKWdGMgpTENS.get_winEpisodeOrderby())
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   jhwctebYzkQAasmBlFfKWdGMgpTEJS=jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('episodenumber')
   jhwctebYzkQAasmBlFfKWdGMgpTEnD ='[%s]\n\n%s'%(jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('episodetitle'),jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('synopsis'))
   jhwctebYzkQAasmBlFfKWdGMgpTEvu={'mediatype':'episode','title':jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('programtitle'),'plot':jhwctebYzkQAasmBlFfKWdGMgpTEnD,'cast':jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('episodeactors'),}
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'VOD','programid':jhwctebYzkQAasmBlFfKWdGMgpTExO,'contentid':jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('contentid'),'thumbnail':jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('thumbnail'),'title':jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('programtitle'),'subtitle':jhwctebYzkQAasmBlFfKWdGMgpTEJS,}
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('programtitle'),sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEJS,img=jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('thumbnail'),infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErq,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEvO==1:
   jhwctebYzkQAasmBlFfKWdGMgpTEvu={'plot':'정렬순서를 변경합니다.'}
   jhwctebYzkQAasmBlFfKWdGMgpTECu={}
   jhwctebYzkQAasmBlFfKWdGMgpTECu['mode'] ='ORDER_BY' 
   if jhwctebYzkQAasmBlFfKWdGMgpTENS.get_winEpisodeOrderby()=='desc':
    jhwctebYzkQAasmBlFfKWdGMgpTECH='정렬순서변경 : 최신화부터 -> 1회부터'
    jhwctebYzkQAasmBlFfKWdGMgpTECu['orderby']='asc'
   else:
    jhwctebYzkQAasmBlFfKWdGMgpTECH='정렬순서변경 : 1회부터 -> 최신화부터'
    jhwctebYzkQAasmBlFfKWdGMgpTECu['orderby']='desc'
   jhwctebYzkQAasmBlFfKWdGMgpTECU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img=jhwctebYzkQAasmBlFfKWdGMgpTECU,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErq,params=jhwctebYzkQAasmBlFfKWdGMgpTECu,isLink=jhwctebYzkQAasmBlFfKWdGMgpTErH)
  if jhwctebYzkQAasmBlFfKWdGMgpTEvr:
   jhwctebYzkQAasmBlFfKWdGMgpTECu={}
   jhwctebYzkQAasmBlFfKWdGMgpTECu['mode'] ='EPISODE_LIST' 
   jhwctebYzkQAasmBlFfKWdGMgpTECu['seasonid']=jhwctebYzkQAasmBlFfKWdGMgpTExO
   jhwctebYzkQAasmBlFfKWdGMgpTECu['page'] =jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECH='[B]%s >>[/B]'%'다음 페이지'
   jhwctebYzkQAasmBlFfKWdGMgpTEJS=jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEJS,img=jhwctebYzkQAasmBlFfKWdGMgpTECU,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTErI,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  xbmcplugin.setContent(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,'episodes')
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTEvy)>0:xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_SuperSection_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEnx =args.get('suburl')
  jhwctebYzkQAasmBlFfKWdGMgpTExu =args.get('subapi')
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log('dp_SuperSection_List')
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log('suburl : '+jhwctebYzkQAasmBlFfKWdGMgpTEnx)
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log('subapi : '+jhwctebYzkQAasmBlFfKWdGMgpTExu)
  jhwctebYzkQAasmBlFfKWdGMgpTEvy=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_SuperMultiSection_List(jhwctebYzkQAasmBlFfKWdGMgpTEnx)
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   jhwctebYzkQAasmBlFfKWdGMgpTECH =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('title')
   jhwctebYzkQAasmBlFfKWdGMgpTExu =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('subapi')
   jhwctebYzkQAasmBlFfKWdGMgpTEnr=jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('cell_type')
   if jhwctebYzkQAasmBlFfKWdGMgpTExu.find('contenttype=movie')>=0 or jhwctebYzkQAasmBlFfKWdGMgpTExu.find('mtype=svod')>=0:
    jhwctebYzkQAasmBlFfKWdGMgpTEvD='MOVIE_LIST'
   elif re.search('themes/2\d{4}',jhwctebYzkQAasmBlFfKWdGMgpTExu)or re.search('themes-band/9\d{4}',jhwctebYzkQAasmBlFfKWdGMgpTExu):
    jhwctebYzkQAasmBlFfKWdGMgpTEvD='MOVIE_LIST'
   else:
    jhwctebYzkQAasmBlFfKWdGMgpTEvD='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   jhwctebYzkQAasmBlFfKWdGMgpTEvu={'plot':jhwctebYzkQAasmBlFfKWdGMgpTECH,'mediatype':'tvshow',}
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':jhwctebYzkQAasmBlFfKWdGMgpTEvD,'suburl':jhwctebYzkQAasmBlFfKWdGMgpTEnx,'subapi':jhwctebYzkQAasmBlFfKWdGMgpTExu,'page':'1',}
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img=jhwctebYzkQAasmBlFfKWdGMgpTErI,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTEvy)>0:xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_BandLiveSection_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTExu =args.get('subapi')
  jhwctebYzkQAasmBlFfKWdGMgpTEvO=jhwctebYzkQAasmBlFfKWdGMgpTEro(args.get('page'))
  jhwctebYzkQAasmBlFfKWdGMgpTEvy,jhwctebYzkQAasmBlFfKWdGMgpTEvr=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_BandLiveSection_List(jhwctebYzkQAasmBlFfKWdGMgpTExu,jhwctebYzkQAasmBlFfKWdGMgpTEvO)
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   jhwctebYzkQAasmBlFfKWdGMgpTEnS =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('channelid')
   jhwctebYzkQAasmBlFfKWdGMgpTEnR =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('studio')
   jhwctebYzkQAasmBlFfKWdGMgpTEnI=jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('tvshowtitle')
   jhwctebYzkQAasmBlFfKWdGMgpTEJC =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('thumbnail')
   jhwctebYzkQAasmBlFfKWdGMgpTEJv =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('age')
   jhwctebYzkQAasmBlFfKWdGMgpTEvu={'mediatype':'tvshow','mpaa':jhwctebYzkQAasmBlFfKWdGMgpTEJv,'title':'%s < %s >'%(jhwctebYzkQAasmBlFfKWdGMgpTEnR,jhwctebYzkQAasmBlFfKWdGMgpTEnI),'tvshowtitle':jhwctebYzkQAasmBlFfKWdGMgpTEnI,'studio':jhwctebYzkQAasmBlFfKWdGMgpTEnR,'plot':jhwctebYzkQAasmBlFfKWdGMgpTEnR}
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'LIVE','contentid':jhwctebYzkQAasmBlFfKWdGMgpTEnS}
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTEnR,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEnI,img=jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('thumbnail'),infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErq,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEvr:
   jhwctebYzkQAasmBlFfKWdGMgpTECu={}
   jhwctebYzkQAasmBlFfKWdGMgpTECu['mode'] ='BANDLIVESECTION_LIST' 
   jhwctebYzkQAasmBlFfKWdGMgpTECu['subapi']=jhwctebYzkQAasmBlFfKWdGMgpTExu
   jhwctebYzkQAasmBlFfKWdGMgpTECu['page'] =jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECH='[B]%s >>[/B]'%'다음 페이지'
   jhwctebYzkQAasmBlFfKWdGMgpTEJS=jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEJS,img=jhwctebYzkQAasmBlFfKWdGMgpTECU,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTErI,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTEvy)>0:xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_Band2Section_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTExu =args.get('subapi')
  jhwctebYzkQAasmBlFfKWdGMgpTEvO=jhwctebYzkQAasmBlFfKWdGMgpTEro(args.get('page'))
  jhwctebYzkQAasmBlFfKWdGMgpTEvy,jhwctebYzkQAasmBlFfKWdGMgpTEvr=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_Band2Section_List(jhwctebYzkQAasmBlFfKWdGMgpTExu,jhwctebYzkQAasmBlFfKWdGMgpTEvO)
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   jhwctebYzkQAasmBlFfKWdGMgpTECH =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('programtitle')
   jhwctebYzkQAasmBlFfKWdGMgpTEJS =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('episodetitle')
   jhwctebYzkQAasmBlFfKWdGMgpTEvu={'plot':jhwctebYzkQAasmBlFfKWdGMgpTECH+'\n\n'+jhwctebYzkQAasmBlFfKWdGMgpTEJS,'mpaa':jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('age'),'mediatype':'episode'}
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'VOD','programid':'-','contentid':jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('videoid'),'thumbnail':jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('thumbnail'),'title':jhwctebYzkQAasmBlFfKWdGMgpTECH,'subtitle':jhwctebYzkQAasmBlFfKWdGMgpTEJS}
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEJS,img=jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('thumbnail'),infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErq,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEvr:
   jhwctebYzkQAasmBlFfKWdGMgpTECu={}
   jhwctebYzkQAasmBlFfKWdGMgpTECu['mode'] ='BAND2SECTION_LIST' 
   jhwctebYzkQAasmBlFfKWdGMgpTECu['subapi']=jhwctebYzkQAasmBlFfKWdGMgpTExu
   jhwctebYzkQAasmBlFfKWdGMgpTECu['page'] =jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECH='[B]%s >>[/B]'%'다음 페이지'
   jhwctebYzkQAasmBlFfKWdGMgpTEJS=jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEJS,img=jhwctebYzkQAasmBlFfKWdGMgpTECU,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTErI,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTEvy)>0:xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_Movie_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTExu =args.get('subapi')
  jhwctebYzkQAasmBlFfKWdGMgpTEvO=jhwctebYzkQAasmBlFfKWdGMgpTEro(args.get('page'))
  jhwctebYzkQAasmBlFfKWdGMgpTECI =args.get('orderby')or '-'
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log('dp_Movie_List')
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log(jhwctebYzkQAasmBlFfKWdGMgpTExu)
  jhwctebYzkQAasmBlFfKWdGMgpTEvy,jhwctebYzkQAasmBlFfKWdGMgpTEvr=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_Movie_List(jhwctebYzkQAasmBlFfKWdGMgpTExu,jhwctebYzkQAasmBlFfKWdGMgpTEvO,jhwctebYzkQAasmBlFfKWdGMgpTECI)
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   jhwctebYzkQAasmBlFfKWdGMgpTEvP =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('videoid')
   jhwctebYzkQAasmBlFfKWdGMgpTEJN =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('vidtype')
   jhwctebYzkQAasmBlFfKWdGMgpTECH =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('title')
   jhwctebYzkQAasmBlFfKWdGMgpTEJC=jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('thumbnail')
   jhwctebYzkQAasmBlFfKWdGMgpTEJv =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('age')
   if jhwctebYzkQAasmBlFfKWdGMgpTEJv=='18' or jhwctebYzkQAasmBlFfKWdGMgpTEJv=='19' or jhwctebYzkQAasmBlFfKWdGMgpTEJv=='21':jhwctebYzkQAasmBlFfKWdGMgpTECH+=' (%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEJv)
   jhwctebYzkQAasmBlFfKWdGMgpTEvu={'plot':jhwctebYzkQAasmBlFfKWdGMgpTECH,'mpaa':jhwctebYzkQAasmBlFfKWdGMgpTEJv,'mediatype':'movie'}
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'MOVIE','contentid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'title':jhwctebYzkQAasmBlFfKWdGMgpTECH,'thumbnail':jhwctebYzkQAasmBlFfKWdGMgpTEJC,'age':jhwctebYzkQAasmBlFfKWdGMgpTEJv,}
   jhwctebYzkQAasmBlFfKWdGMgpTEvU=[]
   jhwctebYzkQAasmBlFfKWdGMgpTEJD={'mode':'VIEW_DETAIL','values':{'videoid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'vidtype':'movie','contenttype':jhwctebYzkQAasmBlFfKWdGMgpTEJN,}}
   jhwctebYzkQAasmBlFfKWdGMgpTEJx=json.dumps(jhwctebYzkQAasmBlFfKWdGMgpTEJD,separators=(',',':'))
   jhwctebYzkQAasmBlFfKWdGMgpTEJx=base64.standard_b64encode(jhwctebYzkQAasmBlFfKWdGMgpTEJx.encode()).decode('utf-8')
   jhwctebYzkQAasmBlFfKWdGMgpTEJx=jhwctebYzkQAasmBlFfKWdGMgpTEJx.replace('+','%2B')
   jhwctebYzkQAasmBlFfKWdGMgpTEJn='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEJx)
   jhwctebYzkQAasmBlFfKWdGMgpTEvU.append(('상세정보 조회',jhwctebYzkQAasmBlFfKWdGMgpTEJn))
   if jhwctebYzkQAasmBlFfKWdGMgpTENS.get_settings_makebookmark():
    jhwctebYzkQAasmBlFfKWdGMgpTEJD={'videoid':jhwctebYzkQAasmBlFfKWdGMgpTEvP,'vidtype':'movie','vtitle':jhwctebYzkQAasmBlFfKWdGMgpTECH,'vsubtitle':'','contenttype':'programid',}
    jhwctebYzkQAasmBlFfKWdGMgpTEJr=json.dumps(jhwctebYzkQAasmBlFfKWdGMgpTEJD)
    jhwctebYzkQAasmBlFfKWdGMgpTEJr=urllib.parse.quote(jhwctebYzkQAasmBlFfKWdGMgpTEJr)
    jhwctebYzkQAasmBlFfKWdGMgpTEJn='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEJr)
    jhwctebYzkQAasmBlFfKWdGMgpTEvU.append(('(통합) 찜 영상에 추가',jhwctebYzkQAasmBlFfKWdGMgpTEJn))
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel='',img=jhwctebYzkQAasmBlFfKWdGMgpTEJC,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErq,params=jhwctebYzkQAasmBlFfKWdGMgpTECu,ContextMenu=jhwctebYzkQAasmBlFfKWdGMgpTEvU)
  if jhwctebYzkQAasmBlFfKWdGMgpTEvr:
   jhwctebYzkQAasmBlFfKWdGMgpTECu={}
   jhwctebYzkQAasmBlFfKWdGMgpTECu['mode'] ='MOVIE_LIST' 
   jhwctebYzkQAasmBlFfKWdGMgpTECu['subapi']=jhwctebYzkQAasmBlFfKWdGMgpTExu 
   jhwctebYzkQAasmBlFfKWdGMgpTECu['page'] =jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECu['orderby']=jhwctebYzkQAasmBlFfKWdGMgpTECI
   jhwctebYzkQAasmBlFfKWdGMgpTECH='[B]%s >>[/B]'%'다음 페이지'
   jhwctebYzkQAasmBlFfKWdGMgpTEJS=jhwctebYzkQAasmBlFfKWdGMgpTEry(jhwctebYzkQAasmBlFfKWdGMgpTEvO+1)
   jhwctebYzkQAasmBlFfKWdGMgpTECU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTECH,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEJS,img=jhwctebYzkQAasmBlFfKWdGMgpTECU,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTErI,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErH,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  xbmcplugin.setContent(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,'movies')
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTEvy)>0:xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_Set_Bookmark(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEno=urllib.parse.unquote(args.get('bm_param'))
  jhwctebYzkQAasmBlFfKWdGMgpTEno=json.loads(jhwctebYzkQAasmBlFfKWdGMgpTEno)
  jhwctebYzkQAasmBlFfKWdGMgpTEvP =jhwctebYzkQAasmBlFfKWdGMgpTEno.get('videoid')
  jhwctebYzkQAasmBlFfKWdGMgpTEJN =jhwctebYzkQAasmBlFfKWdGMgpTEno.get('vidtype')
  jhwctebYzkQAasmBlFfKWdGMgpTEnH =jhwctebYzkQAasmBlFfKWdGMgpTEno.get('vtitle')
  jhwctebYzkQAasmBlFfKWdGMgpTEnq =jhwctebYzkQAasmBlFfKWdGMgpTEno.get('vsubtitle')
  jhwctebYzkQAasmBlFfKWdGMgpTEnL=jhwctebYzkQAasmBlFfKWdGMgpTEno.get('contenttype')
  jhwctebYzkQAasmBlFfKWdGMgpTENq=xbmcgui.Dialog()
  jhwctebYzkQAasmBlFfKWdGMgpTEDN=jhwctebYzkQAasmBlFfKWdGMgpTENq.yesno(__language__(30913).encode('utf8'),jhwctebYzkQAasmBlFfKWdGMgpTEnH+' \n\n'+__language__(30914))
  if jhwctebYzkQAasmBlFfKWdGMgpTEDN==jhwctebYzkQAasmBlFfKWdGMgpTErq:return
  jhwctebYzkQAasmBlFfKWdGMgpTEni=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.GetBookmarkInfo(jhwctebYzkQAasmBlFfKWdGMgpTEvP,jhwctebYzkQAasmBlFfKWdGMgpTEJN,jhwctebYzkQAasmBlFfKWdGMgpTEnL)
  jhwctebYzkQAasmBlFfKWdGMgpTEnX=json.dumps(jhwctebYzkQAasmBlFfKWdGMgpTEni)
  jhwctebYzkQAasmBlFfKWdGMgpTEnX=urllib.parse.quote(jhwctebYzkQAasmBlFfKWdGMgpTEnX)
  jhwctebYzkQAasmBlFfKWdGMgpTEJn ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEnX)
  xbmc.executebuiltin(jhwctebYzkQAasmBlFfKWdGMgpTEJn)
 def dp_LiveChannel_List(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEnU =args.get('genre')
  jhwctebYzkQAasmBlFfKWdGMgpTExU=args.get('baseapi')
  jhwctebYzkQAasmBlFfKWdGMgpTEvy=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_LiveChannel_List(jhwctebYzkQAasmBlFfKWdGMgpTEnU,jhwctebYzkQAasmBlFfKWdGMgpTExU)
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   jhwctebYzkQAasmBlFfKWdGMgpTEnS =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('channelid')
   jhwctebYzkQAasmBlFfKWdGMgpTEnR =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('studio')
   jhwctebYzkQAasmBlFfKWdGMgpTEnI=jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('tvshowtitle')
   jhwctebYzkQAasmBlFfKWdGMgpTEJC =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('thumbnail')
   jhwctebYzkQAasmBlFfKWdGMgpTEJv =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('age')
   jhwctebYzkQAasmBlFfKWdGMgpTEnu =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('epg')
   jhwctebYzkQAasmBlFfKWdGMgpTEvu={'mediatype':'episode','mpaa':jhwctebYzkQAasmBlFfKWdGMgpTEJv,'title':'%s < %s >'%(jhwctebYzkQAasmBlFfKWdGMgpTEnR,jhwctebYzkQAasmBlFfKWdGMgpTEnI),'tvshowtitle':jhwctebYzkQAasmBlFfKWdGMgpTEnI,'studio':jhwctebYzkQAasmBlFfKWdGMgpTEnR,'plot':'%s\n\n%s'%(jhwctebYzkQAasmBlFfKWdGMgpTEnR,jhwctebYzkQAasmBlFfKWdGMgpTEnu)}
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'LIVE','contentid':jhwctebYzkQAasmBlFfKWdGMgpTEnS}
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTEnR,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEnI,img=jhwctebYzkQAasmBlFfKWdGMgpTEJC,infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErq,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  if jhwctebYzkQAasmBlFfKWdGMgpTEru(jhwctebYzkQAasmBlFfKWdGMgpTEvy)>0:xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_Sports_GameList(jhwctebYzkQAasmBlFfKWdGMgpTENS,args):
  jhwctebYzkQAasmBlFfKWdGMgpTEvy=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.Get_Sports_Gamelist()
  for jhwctebYzkQAasmBlFfKWdGMgpTEvV in jhwctebYzkQAasmBlFfKWdGMgpTEvy:
   jhwctebYzkQAasmBlFfKWdGMgpTEnO =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('game_date')
   jhwctebYzkQAasmBlFfKWdGMgpTEny =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('game_time')
   jhwctebYzkQAasmBlFfKWdGMgpTEnV =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('svc_id')
   jhwctebYzkQAasmBlFfKWdGMgpTEnP =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('away_team')
   jhwctebYzkQAasmBlFfKWdGMgpTErN =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('home_team')
   jhwctebYzkQAasmBlFfKWdGMgpTErC=jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('game_status')
   jhwctebYzkQAasmBlFfKWdGMgpTErv =jhwctebYzkQAasmBlFfKWdGMgpTEvV.get('game_place')
   jhwctebYzkQAasmBlFfKWdGMgpTErJ ='%s vs %s (%s)'%(jhwctebYzkQAasmBlFfKWdGMgpTEnP,jhwctebYzkQAasmBlFfKWdGMgpTErN,jhwctebYzkQAasmBlFfKWdGMgpTErv)
   jhwctebYzkQAasmBlFfKWdGMgpTErD =jhwctebYzkQAasmBlFfKWdGMgpTEnO+' '+jhwctebYzkQAasmBlFfKWdGMgpTEny
   if jhwctebYzkQAasmBlFfKWdGMgpTErC=='LIVE':
    jhwctebYzkQAasmBlFfKWdGMgpTErC='~경기중~'
   elif jhwctebYzkQAasmBlFfKWdGMgpTErC=='END':
    jhwctebYzkQAasmBlFfKWdGMgpTErC='경기종료'
   elif jhwctebYzkQAasmBlFfKWdGMgpTErC=='CANCEL':
    jhwctebYzkQAasmBlFfKWdGMgpTErC='취소'
   else:
    jhwctebYzkQAasmBlFfKWdGMgpTErC=''
   if jhwctebYzkQAasmBlFfKWdGMgpTErC=='':
    jhwctebYzkQAasmBlFfKWdGMgpTEJS=jhwctebYzkQAasmBlFfKWdGMgpTErJ
   else:
    jhwctebYzkQAasmBlFfKWdGMgpTEJS=jhwctebYzkQAasmBlFfKWdGMgpTErJ+'  '+jhwctebYzkQAasmBlFfKWdGMgpTErC
   jhwctebYzkQAasmBlFfKWdGMgpTEvu={'mediatype':'episode','title':jhwctebYzkQAasmBlFfKWdGMgpTErJ,'plot':'%s\n\n%s\n\n%s'%(jhwctebYzkQAasmBlFfKWdGMgpTErD,jhwctebYzkQAasmBlFfKWdGMgpTErJ,jhwctebYzkQAasmBlFfKWdGMgpTErC)}
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'SPORTS','contentid':jhwctebYzkQAasmBlFfKWdGMgpTEnV}
   jhwctebYzkQAasmBlFfKWdGMgpTENS.add_dir(jhwctebYzkQAasmBlFfKWdGMgpTErD,sublabel=jhwctebYzkQAasmBlFfKWdGMgpTEJS,img='',infoLabels=jhwctebYzkQAasmBlFfKWdGMgpTEvu,isFolder=jhwctebYzkQAasmBlFfKWdGMgpTErq,params=jhwctebYzkQAasmBlFfKWdGMgpTECu)
  xbmcplugin.endOfDirectory(jhwctebYzkQAasmBlFfKWdGMgpTENS._addon_handle,cacheToDisc=jhwctebYzkQAasmBlFfKWdGMgpTErq)
 def dp_View_Detail(jhwctebYzkQAasmBlFfKWdGMgpTENS,jhwctebYzkQAasmBlFfKWdGMgpTErS):
  jhwctebYzkQAasmBlFfKWdGMgpTEvP =jhwctebYzkQAasmBlFfKWdGMgpTErS.get('videoid')
  jhwctebYzkQAasmBlFfKWdGMgpTEJN =jhwctebYzkQAasmBlFfKWdGMgpTErS.get('vidtype') 
  jhwctebYzkQAasmBlFfKWdGMgpTEnL=jhwctebYzkQAasmBlFfKWdGMgpTErS.get('contenttype')
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log(jhwctebYzkQAasmBlFfKWdGMgpTEvP)
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log(jhwctebYzkQAasmBlFfKWdGMgpTEJN)
  jhwctebYzkQAasmBlFfKWdGMgpTENS.addon_log(jhwctebYzkQAasmBlFfKWdGMgpTEnL)
  jhwctebYzkQAasmBlFfKWdGMgpTEni=jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.GetBookmarkInfo(jhwctebYzkQAasmBlFfKWdGMgpTEvP,jhwctebYzkQAasmBlFfKWdGMgpTEJN,jhwctebYzkQAasmBlFfKWdGMgpTEnL)
  if jhwctebYzkQAasmBlFfKWdGMgpTEJN=='tvshow':
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'SEASON_LIST','videoid':jhwctebYzkQAasmBlFfKWdGMgpTEni['indexinfo']['videoid'],'vidtype':jhwctebYzkQAasmBlFfKWdGMgpTEni['indexinfo']['vidtype'],}
   jhwctebYzkQAasmBlFfKWdGMgpTEDx='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(jhwctebYzkQAasmBlFfKWdGMgpTECu))
  else:
   jhwctebYzkQAasmBlFfKWdGMgpTECu={'mode':'MOVIE','contentid':jhwctebYzkQAasmBlFfKWdGMgpTEni['indexinfo']['videoid'],'title':jhwctebYzkQAasmBlFfKWdGMgpTEni['saveinfo']['infoLabels']['title'],'thumbnail':jhwctebYzkQAasmBlFfKWdGMgpTEni['saveinfo']['thumbnail'],'age':jhwctebYzkQAasmBlFfKWdGMgpTEni['saveinfo']['infoLabels']['mpaa'],}
   jhwctebYzkQAasmBlFfKWdGMgpTEDx='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(jhwctebYzkQAasmBlFfKWdGMgpTECu))
  jhwctebYzkQAasmBlFfKWdGMgpTECq=xbmcgui.ListItem(label=jhwctebYzkQAasmBlFfKWdGMgpTEni['saveinfo']['title'],path=jhwctebYzkQAasmBlFfKWdGMgpTEDx)
  jhwctebYzkQAasmBlFfKWdGMgpTECq.setArt(jhwctebYzkQAasmBlFfKWdGMgpTEni['saveinfo']['thumbnail'])
  jhwctebYzkQAasmBlFfKWdGMgpTENS.Set_InfoTag(jhwctebYzkQAasmBlFfKWdGMgpTECq.getVideoInfoTag(),jhwctebYzkQAasmBlFfKWdGMgpTEni['saveinfo']['infoLabels'])
  if jhwctebYzkQAasmBlFfKWdGMgpTEJN=='movie':
   jhwctebYzkQAasmBlFfKWdGMgpTECq.setIsFolder(jhwctebYzkQAasmBlFfKWdGMgpTErq)
   jhwctebYzkQAasmBlFfKWdGMgpTECq.setProperty('IsPlayable','true')
  else:
   jhwctebYzkQAasmBlFfKWdGMgpTECq.setIsFolder(jhwctebYzkQAasmBlFfKWdGMgpTErH)
   jhwctebYzkQAasmBlFfKWdGMgpTECq.setProperty('IsPlayable','false')
  jhwctebYzkQAasmBlFfKWdGMgpTENq=xbmcgui.Dialog()
  jhwctebYzkQAasmBlFfKWdGMgpTENq.info(jhwctebYzkQAasmBlFfKWdGMgpTECq)
 def wavve_main(jhwctebYzkQAasmBlFfKWdGMgpTENS):
  jhwctebYzkQAasmBlFfKWdGMgpTENS.WavveObj.KodiVersion=jhwctebYzkQAasmBlFfKWdGMgpTEro(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  jhwctebYzkQAasmBlFfKWdGMgpTErx=jhwctebYzkQAasmBlFfKWdGMgpTENS.main_params.get('params')
  if jhwctebYzkQAasmBlFfKWdGMgpTErx:
   jhwctebYzkQAasmBlFfKWdGMgpTErn =base64.standard_b64decode(jhwctebYzkQAasmBlFfKWdGMgpTErx).decode('utf-8')
   jhwctebYzkQAasmBlFfKWdGMgpTErn =json.loads(jhwctebYzkQAasmBlFfKWdGMgpTErn)
   jhwctebYzkQAasmBlFfKWdGMgpTEvD =jhwctebYzkQAasmBlFfKWdGMgpTErn.get('mode')
   jhwctebYzkQAasmBlFfKWdGMgpTErS =jhwctebYzkQAasmBlFfKWdGMgpTErn.get('values')
  else:
   jhwctebYzkQAasmBlFfKWdGMgpTEvD=jhwctebYzkQAasmBlFfKWdGMgpTENS.main_params.get('mode',jhwctebYzkQAasmBlFfKWdGMgpTErI)
   jhwctebYzkQAasmBlFfKWdGMgpTErS=jhwctebYzkQAasmBlFfKWdGMgpTENS.main_params
  if jhwctebYzkQAasmBlFfKWdGMgpTEvD=='LOGOUT':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.logout()
   return
  jhwctebYzkQAasmBlFfKWdGMgpTENS.login_main()
  if jhwctebYzkQAasmBlFfKWdGMgpTEvD is jhwctebYzkQAasmBlFfKWdGMgpTErI:
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Main_List()
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD in['LIVE','VOD','MOVIE','SPORTS']:
   jhwctebYzkQAasmBlFfKWdGMgpTENS.play_VIDEO(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='LIVE_CATAGORY':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_LiveCatagory_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='MAIN_CATAGORY':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_MainCatagory_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='SUPERSECTION_LIST':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_SuperSection_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='BANDLIVESECTION_LIST':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_BandLiveSection_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='BAND2SECTION_LIST':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Band2Section_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='PROGRAM_LIST':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Program_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='SEASON_LIST':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Season_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='EPISODE_LIST':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Episode_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='MOVIE_LIST':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Movie_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='LIVE_LIST':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_LiveChannel_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='ORDER_BY':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_setEpOrderby(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='SEARCH_GROUP':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Search_Group(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD in['SEARCH_LIST','LOCAL_SEARCH']:
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Search_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='WATCH_GROUP':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Watch_Group(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='WATCH_LIST':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Watch_List(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='SET_BOOKMARK':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Set_Bookmark(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_History_Remove(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD in['TOTAL_SEARCH','TOTAL_HISTORY']:
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Global_Search(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='SEARCH_HISTORY':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Search_History(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='MENU_BOOKMARK':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Bookmark_Menu(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='GAME_LIST':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_Sports_GameList(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  elif jhwctebYzkQAasmBlFfKWdGMgpTEvD=='VIEW_DETAIL':
   jhwctebYzkQAasmBlFfKWdGMgpTENS.dp_View_Detail(jhwctebYzkQAasmBlFfKWdGMgpTErS)
  else:
   jhwctebYzkQAasmBlFfKWdGMgpTErI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
