__author__="NightRain"
BKrEzkAYvhUpNwOmtQDqsgVjWRXILc=object
BKrEzkAYvhUpNwOmtQDqsgVjWRXILu=None
BKrEzkAYvhUpNwOmtQDqsgVjWRXILd=int
BKrEzkAYvhUpNwOmtQDqsgVjWRXILC=True
BKrEzkAYvhUpNwOmtQDqsgVjWRXILF=False
BKrEzkAYvhUpNwOmtQDqsgVjWRXILx=type
BKrEzkAYvhUpNwOmtQDqsgVjWRXILP=dict
BKrEzkAYvhUpNwOmtQDqsgVjWRXILa=getattr
BKrEzkAYvhUpNwOmtQDqsgVjWRXILy=list
BKrEzkAYvhUpNwOmtQDqsgVjWRXILl=len
BKrEzkAYvhUpNwOmtQDqsgVjWRXILf=range
BKrEzkAYvhUpNwOmtQDqsgVjWRXILo=str
BKrEzkAYvhUpNwOmtQDqsgVjWRXILb=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
BKrEzkAYvhUpNwOmtQDqsgVjWRXIeJ=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
BKrEzkAYvhUpNwOmtQDqsgVjWRXIen=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
BKrEzkAYvhUpNwOmtQDqsgVjWRXIeG=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
BKrEzkAYvhUpNwOmtQDqsgVjWRXIeT={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
BKrEzkAYvhUpNwOmtQDqsgVjWRXIeH =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
BKrEzkAYvhUpNwOmtQDqsgVjWRXIeL=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class BKrEzkAYvhUpNwOmtQDqsgVjWRXIei(BKrEzkAYvhUpNwOmtQDqsgVjWRXILc):
 def __init__(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,BKrEzkAYvhUpNwOmtQDqsgVjWRXIec,BKrEzkAYvhUpNwOmtQDqsgVjWRXIeu,BKrEzkAYvhUpNwOmtQDqsgVjWRXIed):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_url =BKrEzkAYvhUpNwOmtQDqsgVjWRXIec
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeu
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.main_params =BKrEzkAYvhUpNwOmtQDqsgVjWRXIed
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj =gRxlBNGPjKnafHqIMbpCVOScAkYLvs() 
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,sting):
  try:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF=xbmcgui.Dialog()
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF.notification(__addonname__,sting)
  except:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILu
 def addon_log(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,string):
  try:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIex=string.encode('utf-8','ignore')
  except:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIex='addonException: addon_log'
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeP=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,BKrEzkAYvhUpNwOmtQDqsgVjWRXIex),level=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeP)
 def get_keyboard_input(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIea=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu
  kb=xbmc.Keyboard()
  kb.setHeading(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIea=kb.getText()
  return BKrEzkAYvhUpNwOmtQDqsgVjWRXIea
 def get_settings_account(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIey =__addon__.getSetting('id')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIel =__addon__.getSetting('pw')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIef=BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(__addon__.getSetting('selected_profile'))
  return(BKrEzkAYvhUpNwOmtQDqsgVjWRXIey,BKrEzkAYvhUpNwOmtQDqsgVjWRXIel,BKrEzkAYvhUpNwOmtQDqsgVjWRXIef)
 def get_settings_totalsearch(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeo =BKrEzkAYvhUpNwOmtQDqsgVjWRXILC if __addon__.getSetting('local_search')=='true' else BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeb=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC if __addon__.getSetting('local_history')=='true' else BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeS =BKrEzkAYvhUpNwOmtQDqsgVjWRXILC if __addon__.getSetting('total_search')=='true' else BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIie=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC if __addon__.getSetting('total_history')=='true' else BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiJ=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC if __addon__.getSetting('menu_bookmark')=='true' else BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  return(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeo,BKrEzkAYvhUpNwOmtQDqsgVjWRXIeb,BKrEzkAYvhUpNwOmtQDqsgVjWRXIeS,BKrEzkAYvhUpNwOmtQDqsgVjWRXIie,BKrEzkAYvhUpNwOmtQDqsgVjWRXIiJ)
 def get_settings_makebookmark(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  return BKrEzkAYvhUpNwOmtQDqsgVjWRXILC if __addon__.getSetting('make_bookmark')=='true' else BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
 def get_settings_play(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIin={'enable_hdr':BKrEzkAYvhUpNwOmtQDqsgVjWRXILC if __addon__.getSetting('enable_hdr')=='true' else BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,'enable_uhd':BKrEzkAYvhUpNwOmtQDqsgVjWRXILC if __addon__.getSetting('enable_uhd')=='true' else BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,'streamFilename':BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.WV_STREAM_FILENAME,}
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_selQuality()<1080:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIin['enable_hdr']=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIin['enable_uhd']=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  return(BKrEzkAYvhUpNwOmtQDqsgVjWRXIin)
 def get_settings_proxyport(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiG =BKrEzkAYvhUpNwOmtQDqsgVjWRXILC if __addon__.getSetting('proxyYn')=='true' else BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiT=BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(__addon__.getSetting('proxyPort'))
  return BKrEzkAYvhUpNwOmtQDqsgVjWRXIiG,BKrEzkAYvhUpNwOmtQDqsgVjWRXIiT
 def get_selQuality(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  try:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiH=[1080,720,480,360]
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiL=BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(__addon__.getSetting('selected_quality'))
   return BKrEzkAYvhUpNwOmtQDqsgVjWRXIiH[BKrEzkAYvhUpNwOmtQDqsgVjWRXIiL]
  except:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILu
  return 1080 
 def get_settings_exclusion21(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiM =__addon__.getSetting('exclusion21')
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIiM=='false':
   return BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  else:
   return BKrEzkAYvhUpNwOmtQDqsgVjWRXILC
 def get_settings_direct_replay(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIic=BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(__addon__.getSetting('direct_replay'))
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIic==0:
   return BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  else:
   return BKrEzkAYvhUpNwOmtQDqsgVjWRXILC
 def set_winEpisodeOrderby(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu):
  __addon__.setSetting('wavve_orderby',BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu)
 def get_winEpisodeOrderby(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu=__addon__.getSetting('wavve_orderby')
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu in['',BKrEzkAYvhUpNwOmtQDqsgVjWRXILu]:BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu='desc'
  return BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu
 def add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,label,sublabel='',img='',infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params='',isLink=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,ContextMenu=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIid='%s?%s'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_url,urllib.parse.urlencode(params))
  if sublabel:BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='%s < %s >'%(label,sublabel)
  else: BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC=label
  if not img:img='DefaultFolder.png'
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF=xbmcgui.ListItem(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILx(img)==BKrEzkAYvhUpNwOmtQDqsgVjWRXILP:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.setArt(img)
  else:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.setArt({'thumb':img,'poster':img})
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.KodiVersion>=20:
   if infoLabels:BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.Set_InfoTag(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.setProperty('IsPlayable','true')
  if ContextMenu:BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,BKrEzkAYvhUpNwOmtQDqsgVjWRXIid,BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF,isFolder)
 def Set_InfoTag(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,video_InfoTag:xbmc.InfoTagVideo,BKrEzkAYvhUpNwOmtQDqsgVjWRXIib):
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIix,value in BKrEzkAYvhUpNwOmtQDqsgVjWRXIib.items():
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIeT[BKrEzkAYvhUpNwOmtQDqsgVjWRXIix]['type']=='string':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXILa(video_InfoTag,BKrEzkAYvhUpNwOmtQDqsgVjWRXIeT[BKrEzkAYvhUpNwOmtQDqsgVjWRXIix]['func'])(value)
   elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIeT[BKrEzkAYvhUpNwOmtQDqsgVjWRXIix]['type']=='int':
    if BKrEzkAYvhUpNwOmtQDqsgVjWRXILx(value)==BKrEzkAYvhUpNwOmtQDqsgVjWRXILd:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIiP=BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(value)
    else:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIiP=0
    BKrEzkAYvhUpNwOmtQDqsgVjWRXILa(video_InfoTag,BKrEzkAYvhUpNwOmtQDqsgVjWRXIeT[BKrEzkAYvhUpNwOmtQDqsgVjWRXIix]['func'])(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiP)
   elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIeT[BKrEzkAYvhUpNwOmtQDqsgVjWRXIix]['type']=='actor':
    if value!=[]:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXILa(video_InfoTag,BKrEzkAYvhUpNwOmtQDqsgVjWRXIeT[BKrEzkAYvhUpNwOmtQDqsgVjWRXIix]['func'])([xbmc.Actor(name)for name in value])
   elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIeT[BKrEzkAYvhUpNwOmtQDqsgVjWRXIix]['type']=='list':
    if BKrEzkAYvhUpNwOmtQDqsgVjWRXILx(value)==BKrEzkAYvhUpNwOmtQDqsgVjWRXILy:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXILa(video_InfoTag,BKrEzkAYvhUpNwOmtQDqsgVjWRXIeT[BKrEzkAYvhUpNwOmtQDqsgVjWRXIix]['func'])(value)
    else:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXILa(video_InfoTag,BKrEzkAYvhUpNwOmtQDqsgVjWRXIeT[BKrEzkAYvhUpNwOmtQDqsgVjWRXIix]['func'])([value])
 def dp_Main_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  (BKrEzkAYvhUpNwOmtQDqsgVjWRXIeo,BKrEzkAYvhUpNwOmtQDqsgVjWRXIeb,BKrEzkAYvhUpNwOmtQDqsgVjWRXIeS,BKrEzkAYvhUpNwOmtQDqsgVjWRXIie,BKrEzkAYvhUpNwOmtQDqsgVjWRXIiJ)=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_totalsearch()
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIia in BKrEzkAYvhUpNwOmtQDqsgVjWRXIeJ:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC=BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('title')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy=''
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('mode')=='SEARCH_GROUP' and BKrEzkAYvhUpNwOmtQDqsgVjWRXIeo ==BKrEzkAYvhUpNwOmtQDqsgVjWRXILF:continue
   elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('mode')=='SEARCH_HISTORY' and BKrEzkAYvhUpNwOmtQDqsgVjWRXIeb==BKrEzkAYvhUpNwOmtQDqsgVjWRXILF:continue
   elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('mode')=='TOTAL_SEARCH' and BKrEzkAYvhUpNwOmtQDqsgVjWRXIeS ==BKrEzkAYvhUpNwOmtQDqsgVjWRXILF:continue
   elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('mode')=='TOTAL_HISTORY' and BKrEzkAYvhUpNwOmtQDqsgVjWRXIie==BKrEzkAYvhUpNwOmtQDqsgVjWRXILF:continue
   elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('mode')=='MENU_BOOKMARK' and BKrEzkAYvhUpNwOmtQDqsgVjWRXIiJ==BKrEzkAYvhUpNwOmtQDqsgVjWRXILF:continue
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('mode'),'sCode':BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('sCode'),'sIndex':BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('sIndex'),'sType':BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('sType'),'suburl':BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('suburl'),'subapi':BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('subapi'),'page':BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('page'),'orderby':BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('orderby'),'ordernm':BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('ordernm')}
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIif=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIio =BKrEzkAYvhUpNwOmtQDqsgVjWRXILC
   else:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIif=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIio =BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIib={'title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'plot':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC}
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('mode')=='XXX':BKrEzkAYvhUpNwOmtQDqsgVjWRXIib=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu
   if 'icon' in BKrEzkAYvhUpNwOmtQDqsgVjWRXIia:BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',BKrEzkAYvhUpNwOmtQDqsgVjWRXIia.get('icon')) 
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIib,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXIif,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil,isLink=BKrEzkAYvhUpNwOmtQDqsgVjWRXIio)
  xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC)
 def dp_Search_Group(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  if 'search_key' in args:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi=args.get('search_key')
  else:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi:
    return
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJn in BKrEzkAYvhUpNwOmtQDqsgVjWRXIen:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJn.get('mode')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJn.get('sType')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJn.get('title')
   (BKrEzkAYvhUpNwOmtQDqsgVjWRXIJH,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL)=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_Search_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT,1,exclusion21=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_exclusion21())
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIib={'plot':'검색어 : '+BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi+'\n\n'+BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.Search_FreeList(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJH)}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG,'sType':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT,'search_key':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi,'page':'1',}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img='',infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIib,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIen)>0:xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.Save_Searched_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi)
 def Search_FreeList(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,search_list):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJM=''
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJc=7
  try:
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(search_list)==0:return '검색결과 없음'
   for i in BKrEzkAYvhUpNwOmtQDqsgVjWRXILf(BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(search_list)):
    if i>=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJc:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIJM=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJM+'...'
     break
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIJM=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJM+search_list[i]['title']+'\n'
  except:
   return ''
  return BKrEzkAYvhUpNwOmtQDqsgVjWRXIJM
 def dp_Watch_Group(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJu in BKrEzkAYvhUpNwOmtQDqsgVjWRXIeG:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJu.get('title')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJu.get('mode'),'sType':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJu.get('sType')}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img='',infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeG)>0:xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC)
 def dp_Search_History(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJd=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.Load_List_File('search')
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJC in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJd:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJF=BKrEzkAYvhUpNwOmtQDqsgVjWRXILP(urllib.parse.parse_qsl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJC))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJx=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJF.get('skey').strip()
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'SEARCH_GROUP','search_key':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJx,}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJP={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJx,'vType':'-',}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJa=urllib.parse.urlencode(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJP)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy=[('선택된 검색어 ( %s ) 삭제'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJx),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJa))]
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJx,sublabel='',img=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil,ContextMenu=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'plot':'검색목록 전체를 삭제합니다.'}
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil,isLink=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC)
  xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_Search_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT =args.get('sType')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf =BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(args.get('page'))
  if 'search_key' in args:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi=args.get('search_key')
  else:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi:
    xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle)
    return
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_Search_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf,exclusion21=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_exclusion21())
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('videoid')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIne =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('vidtype')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('title')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIni=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('thumbnail')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('age')
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ=='18' or BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ=='19' or BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ=='21':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC+=' (%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'mediatype':'tvshow' if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT=='vod' else 'movie','mpaa':BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ,'title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'plot':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC}
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT=='vod':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'EPISODE_LIST','seasonid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'page':'1',}
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIif=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC
   else:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'MOVIE','contentid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'thumbnail':BKrEzkAYvhUpNwOmtQDqsgVjWRXIni,'age':BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ,}
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIif=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy=[]
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInG={'mode':'VIEW_DETAIL','values':{'videoid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'vidtype':'tvshow' if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT=='vod' else 'movie','contenttype':BKrEzkAYvhUpNwOmtQDqsgVjWRXIne,}}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInT=json.dumps(BKrEzkAYvhUpNwOmtQDqsgVjWRXInG,separators=(',',':'))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInT=base64.standard_b64encode(BKrEzkAYvhUpNwOmtQDqsgVjWRXInT.encode()).decode('utf-8')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInT=BKrEzkAYvhUpNwOmtQDqsgVjWRXInT.replace('+','%2B')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInH='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXInT)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy.append(('상세정보 조회',BKrEzkAYvhUpNwOmtQDqsgVjWRXInH))
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_makebookmark():
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInG={'videoid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'vidtype':'tvshow' if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT=='vod' else 'movie','vtitle':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'vsubtitle':'','contenttype':BKrEzkAYvhUpNwOmtQDqsgVjWRXIne,}
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInL=json.dumps(BKrEzkAYvhUpNwOmtQDqsgVjWRXInG)
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInL=urllib.parse.quote(BKrEzkAYvhUpNwOmtQDqsgVjWRXInL)
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInH='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXInL)
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy.append(('(통합) 찜 영상에 추가',BKrEzkAYvhUpNwOmtQDqsgVjWRXInH))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIni,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXIif,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil,ContextMenu=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['mode'] ='SEARCH_LIST' 
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['sType']=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT 
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['page'] =BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['search_key']=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='[B]%s >>[/B]'%'다음 페이지'
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInM=BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT=='movie':xbmcplugin.setContent(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,'movies')
  else:xbmcplugin.setContent(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_Watch_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT =args.get('sType')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIic=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_direct_replay()
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.Load_List_File(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT)
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJF=BKrEzkAYvhUpNwOmtQDqsgVjWRXILP(urllib.parse.parse_qsl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInc =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJF.get('code').strip()
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJF.get('title').strip()
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInM =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJF.get('subtitle').strip()
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXInM=='None':BKrEzkAYvhUpNwOmtQDqsgVjWRXInM=''
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIni=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJF.get('img').strip()
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJF.get('videoid').strip()
   try:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIni=BKrEzkAYvhUpNwOmtQDqsgVjWRXIni.replace('\'','\"')
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIni=json.loads(BKrEzkAYvhUpNwOmtQDqsgVjWRXIni)
   except:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXILu
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'plot':'%s\n%s'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,BKrEzkAYvhUpNwOmtQDqsgVjWRXInM)}
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT=='vod':
    if BKrEzkAYvhUpNwOmtQDqsgVjWRXIic==BKrEzkAYvhUpNwOmtQDqsgVjWRXILF or BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS==BKrEzkAYvhUpNwOmtQDqsgVjWRXILu:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl['mediatype']='tvshow'
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'SEASON_LIST','videoid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'vidtype':'contentid',}
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIif=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC
    else:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl['mediatype']='episode'
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'VOD','programid':BKrEzkAYvhUpNwOmtQDqsgVjWRXInc,'contentid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'subtitle':BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,'thumbnail':BKrEzkAYvhUpNwOmtQDqsgVjWRXIni}
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIif=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
   else:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl['mediatype']='movie'
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'MOVIE','contentid':BKrEzkAYvhUpNwOmtQDqsgVjWRXInc,'title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'subtitle':BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,'thumbnail':BKrEzkAYvhUpNwOmtQDqsgVjWRXIni}
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIif=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJP={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':BKrEzkAYvhUpNwOmtQDqsgVjWRXInc,'vType':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT,}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJa=urllib.parse.urlencode(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJP)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy=[('선택된 시청이력 ( %s ) 삭제'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJa))]
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIni,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXIif,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil,ContextMenu=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'plot':'시청목록을 삭제합니다.'}
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT,}
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil,isLink=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT=='movie':xbmcplugin.setContent(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,'movies')
  else:xbmcplugin.setContent(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def Load_List_File(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,stype): 
  try:
   if stype=='search':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInu=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeL
   elif stype in['vod','movie']:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=BKrEzkAYvhUpNwOmtQDqsgVjWRXILb(BKrEzkAYvhUpNwOmtQDqsgVjWRXInu,'r',-1,'utf-8')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInd=fp.readlines()
   fp.close()
  except:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInd=[]
  return BKrEzkAYvhUpNwOmtQDqsgVjWRXInd
 def Save_Watched_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,BKrEzkAYvhUpNwOmtQDqsgVjWRXIHy,BKrEzkAYvhUpNwOmtQDqsgVjWRXIed):
  try:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BKrEzkAYvhUpNwOmtQDqsgVjWRXIHy))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInF=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.Load_List_File(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHy) 
   fp=BKrEzkAYvhUpNwOmtQDqsgVjWRXILb(BKrEzkAYvhUpNwOmtQDqsgVjWRXInC,'w',-1,'utf-8')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInx=urllib.parse.urlencode(BKrEzkAYvhUpNwOmtQDqsgVjWRXIed)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInx=BKrEzkAYvhUpNwOmtQDqsgVjWRXInx+'\n'
   fp.write(BKrEzkAYvhUpNwOmtQDqsgVjWRXInx)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInP=0
   for BKrEzkAYvhUpNwOmtQDqsgVjWRXIna in BKrEzkAYvhUpNwOmtQDqsgVjWRXInF:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIny=BKrEzkAYvhUpNwOmtQDqsgVjWRXILP(urllib.parse.parse_qsl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIna))
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInl=BKrEzkAYvhUpNwOmtQDqsgVjWRXIed.get('code').strip()
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInf=BKrEzkAYvhUpNwOmtQDqsgVjWRXIny.get('code').strip()
    if BKrEzkAYvhUpNwOmtQDqsgVjWRXIHy=='vod' and BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_direct_replay()==BKrEzkAYvhUpNwOmtQDqsgVjWRXILC:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXInl=BKrEzkAYvhUpNwOmtQDqsgVjWRXIed.get('videoid').strip()
     BKrEzkAYvhUpNwOmtQDqsgVjWRXInf=BKrEzkAYvhUpNwOmtQDqsgVjWRXIny.get('videoid').strip()if BKrEzkAYvhUpNwOmtQDqsgVjWRXInf!=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu else '-'
    if BKrEzkAYvhUpNwOmtQDqsgVjWRXInl!=BKrEzkAYvhUpNwOmtQDqsgVjWRXInf:
     fp.write(BKrEzkAYvhUpNwOmtQDqsgVjWRXIna)
     BKrEzkAYvhUpNwOmtQDqsgVjWRXInP+=1
     if BKrEzkAYvhUpNwOmtQDqsgVjWRXInP>=50:break
   fp.close()
  except:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILu
 def dp_History_Remove(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIno=args.get('delType')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXInb =args.get('sKey')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXInS =args.get('vType')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF=xbmcgui.Dialog()
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIno=='SEARCH_ALL':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGe=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIno=='SEARCH_ONE':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGe=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIno=='WATCH_ALL':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGe=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIno=='WATCH_ONE':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGe=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGe==BKrEzkAYvhUpNwOmtQDqsgVjWRXILF:sys.exit()
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIno=='SEARCH_ALL':
   if os.path.isfile(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeL):os.remove(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeL)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIno=='SEARCH_ONE':
   try:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInu=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeL
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInF=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.Load_List_File('search') 
    fp=BKrEzkAYvhUpNwOmtQDqsgVjWRXILb(BKrEzkAYvhUpNwOmtQDqsgVjWRXInu,'w',-1,'utf-8')
    for BKrEzkAYvhUpNwOmtQDqsgVjWRXIna in BKrEzkAYvhUpNwOmtQDqsgVjWRXInF:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIny=BKrEzkAYvhUpNwOmtQDqsgVjWRXILP(urllib.parse.parse_qsl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIna))
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIGi=BKrEzkAYvhUpNwOmtQDqsgVjWRXIny.get('skey').strip()
     if BKrEzkAYvhUpNwOmtQDqsgVjWRXInb!=BKrEzkAYvhUpNwOmtQDqsgVjWRXIGi:
      fp.write(BKrEzkAYvhUpNwOmtQDqsgVjWRXIna)
    fp.close()
   except:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXILu
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIno=='WATCH_ALL':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BKrEzkAYvhUpNwOmtQDqsgVjWRXInS))
   if os.path.isfile(BKrEzkAYvhUpNwOmtQDqsgVjWRXInu):os.remove(BKrEzkAYvhUpNwOmtQDqsgVjWRXInu)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIno=='WATCH_ONE':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BKrEzkAYvhUpNwOmtQDqsgVjWRXInS))
   try:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInF=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.Load_List_File(BKrEzkAYvhUpNwOmtQDqsgVjWRXInS) 
    fp=BKrEzkAYvhUpNwOmtQDqsgVjWRXILb(BKrEzkAYvhUpNwOmtQDqsgVjWRXInu,'w',-1,'utf-8')
    for BKrEzkAYvhUpNwOmtQDqsgVjWRXIna in BKrEzkAYvhUpNwOmtQDqsgVjWRXInF:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIny=BKrEzkAYvhUpNwOmtQDqsgVjWRXILP(urllib.parse.parse_qsl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIna))
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIGi=BKrEzkAYvhUpNwOmtQDqsgVjWRXIny.get('code').strip()
     if BKrEzkAYvhUpNwOmtQDqsgVjWRXInb!=BKrEzkAYvhUpNwOmtQDqsgVjWRXIGi:
      fp.write(BKrEzkAYvhUpNwOmtQDqsgVjWRXIna)
    fp.close()
   except:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXILu
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi):
  try:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGJ=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeL
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInF=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.Load_List_File('search') 
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGn={'skey':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJi.strip()}
   fp=BKrEzkAYvhUpNwOmtQDqsgVjWRXILb(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGJ,'w',-1,'utf-8')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInx=urllib.parse.urlencode(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGn)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInx=BKrEzkAYvhUpNwOmtQDqsgVjWRXInx+'\n'
   fp.write(BKrEzkAYvhUpNwOmtQDqsgVjWRXInx)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInP=0
   for BKrEzkAYvhUpNwOmtQDqsgVjWRXIna in BKrEzkAYvhUpNwOmtQDqsgVjWRXInF:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIny=BKrEzkAYvhUpNwOmtQDqsgVjWRXILP(urllib.parse.parse_qsl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIna))
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInl=BKrEzkAYvhUpNwOmtQDqsgVjWRXIGn.get('skey').strip()
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInf=BKrEzkAYvhUpNwOmtQDqsgVjWRXIny.get('skey').strip()
    if BKrEzkAYvhUpNwOmtQDqsgVjWRXInl!=BKrEzkAYvhUpNwOmtQDqsgVjWRXInf:
     fp.write(BKrEzkAYvhUpNwOmtQDqsgVjWRXIna)
     BKrEzkAYvhUpNwOmtQDqsgVjWRXInP+=1
     if BKrEzkAYvhUpNwOmtQDqsgVjWRXInP>=50:break
   fp.close()
  except:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILu
 def dp_Global_Search(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=args.get('mode')
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='TOTAL_SEARCH':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGT='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGT='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGT)
 def dp_Bookmark_Menu(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGT='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGT)
 def login_main(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  (BKrEzkAYvhUpNwOmtQDqsgVjWRXIGH,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGL,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGM)=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_account()
  if not(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGH and BKrEzkAYvhUpNwOmtQDqsgVjWRXIGL):
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF=xbmcgui.Dialog()
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGe=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGe==BKrEzkAYvhUpNwOmtQDqsgVjWRXILC:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.cookiefile_check()==BKrEzkAYvhUpNwOmtQDqsgVjWRXILC:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGc=0
   while BKrEzkAYvhUpNwOmtQDqsgVjWRXILC:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIGc+=1
    time.sleep(0.05)
    if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGc>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGu=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.GetCredential(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGH,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGL,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGM)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGu:BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGu==BKrEzkAYvhUpNwOmtQDqsgVjWRXILF:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu =args.get('orderby')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.set_winEpisodeOrderby(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG =args.get('mode')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGd =args.get('contentid')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGC =args.get('pvrmode')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGF=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_selQuality()
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIin =BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_play()
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGd+' - '+BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='SPORTS':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.GetSportsURL(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGd,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGF)
  else:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.GetStreamingURL(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGd,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGF,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGC,playOption=BKrEzkAYvhUpNwOmtQDqsgVjWRXIin)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGP={'user-agent':BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.USER_AGENT}
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGa=BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_cookie'] 
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGy='{}|{}'.format(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_url'],BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.make_stream_header(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGP,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGa))
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log('surl : '+BKrEzkAYvhUpNwOmtQDqsgVjWRXIGy)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_url']=='':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_noti(__language__(30907).encode('utf8'))
   return
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiG,BKrEzkAYvhUpNwOmtQDqsgVjWRXIiT=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_proxyport()
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGl=urllib.parse.urlparse(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_url'])
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGl=BKrEzkAYvhUpNwOmtQDqsgVjWRXIGl.path.strip('/').split('/')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGl=BKrEzkAYvhUpNwOmtQDqsgVjWRXIGl[BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGl)-1] 
  if (BKrEzkAYvhUpNwOmtQDqsgVjWRXIiG==BKrEzkAYvhUpNwOmtQDqsgVjWRXILC and args.get('mode')in['VOD','MOVIE']and(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['playParam']['hdr']=='hdr' or BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['playParam']['uhd']=='uhd')):
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGl.split('.')[1]=='mpd':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Wavve_Parse_mpd(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx)
   else:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Wavve_Parse_m3u8(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGf={'addon':'wavvem','playOption':BKrEzkAYvhUpNwOmtQDqsgVjWRXIin,}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGf=json.dumps(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGf,separators=(',',':'))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGf=base64.standard_b64encode(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGf.encode()).decode('utf-8')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGy ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiT,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGy,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGf)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log('surl : '+BKrEzkAYvhUpNwOmtQDqsgVjWRXIGy)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo=xbmcgui.ListItem(path=BKrEzkAYvhUpNwOmtQDqsgVjWRXIGy)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_drm']:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log('!!streaming_drm!!')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGb =inputstreamhelper.Helper('mpd',drm='widevine')
   if 'licensetoken' in BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_drm']:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIGS=BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_drm']['licensetoken']
    BKrEzkAYvhUpNwOmtQDqsgVjWRXITe =BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_drm']['licenseurl']
    if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='MOVIE':
     BKrEzkAYvhUpNwOmtQDqsgVjWRXITi='https://www.wavve.com/player/movie?movieid=%s'%BKrEzkAYvhUpNwOmtQDqsgVjWRXIGd
    else:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXITi='https://www.wavve.com/player/vod?programid=%s&page=1'%BKrEzkAYvhUpNwOmtQDqsgVjWRXIGd
    BKrEzkAYvhUpNwOmtQDqsgVjWRXITJ={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':BKrEzkAYvhUpNwOmtQDqsgVjWRXIGS,'referer':BKrEzkAYvhUpNwOmtQDqsgVjWRXITi,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.USER_AGENT,}
   else:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIGS=BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_drm']['customdata']
    BKrEzkAYvhUpNwOmtQDqsgVjWRXITe =BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_drm']['drmhost']
    if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='MOVIE':
     BKrEzkAYvhUpNwOmtQDqsgVjWRXITi='https://www.wavve.com/player/movie?movieid=%s'%BKrEzkAYvhUpNwOmtQDqsgVjWRXIGd
    else:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXITi='https://www.wavve.com/player/vod?programid=%s&page=1'%BKrEzkAYvhUpNwOmtQDqsgVjWRXIGd
    BKrEzkAYvhUpNwOmtQDqsgVjWRXITJ={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':BKrEzkAYvhUpNwOmtQDqsgVjWRXIGS,'referer':BKrEzkAYvhUpNwOmtQDqsgVjWRXITi,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.USER_AGENT,}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXITn=BKrEzkAYvhUpNwOmtQDqsgVjWRXITe+'|'+urllib.parse.urlencode(BKrEzkAYvhUpNwOmtQDqsgVjWRXITJ)+'|R{SSM}|'
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setProperty('inputstream',BKrEzkAYvhUpNwOmtQDqsgVjWRXIGb.inputstream_addon)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setProperty('inputstream.adaptive.manifest_type','mpd')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setProperty('inputstream.adaptive.license_key',BKrEzkAYvhUpNwOmtQDqsgVjWRXITn)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setProperty('inputstream.adaptive.stream_headers','{}'.format(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.make_stream_header(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGP,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGa)))
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG in['VOD','MOVIE']:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setContentLookup(BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setMimeType('application/x-mpegURL')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setProperty('inputstream','inputstream.adaptive')
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_action']=='hls':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setProperty('inputstream.adaptive.manifest_type','hls')
   else:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setProperty('inputstream.adaptive.manifest_type','mpd')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setProperty('inputstream.adaptive.stream_headers','{}'.format(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.make_stream_header(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGP,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGa)))
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_vtt']:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo.setSubtitles([BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_vtt']])
  xbmcplugin.setResolvedUrl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGo)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITG=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_preview']:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_noti(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_preview'].encode('utf-8'))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXITG=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC
  else:
   if '/preview.' in urllib.parse.urlsplit(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGx['stream_url']).path:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_noti(__language__(30908).encode('utf8'))
    BKrEzkAYvhUpNwOmtQDqsgVjWRXITG=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC
  try:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXITH=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and BKrEzkAYvhUpNwOmtQDqsgVjWRXITG==BKrEzkAYvhUpNwOmtQDqsgVjWRXILF and BKrEzkAYvhUpNwOmtQDqsgVjWRXITH!='-':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'code':BKrEzkAYvhUpNwOmtQDqsgVjWRXITH,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.Save_Watched_List(args.get('mode').lower(),BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  except:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILu
 def logout(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF=xbmcgui.Dialog()
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGe=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGe==BKrEzkAYvhUpNwOmtQDqsgVjWRXILF:sys.exit()
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Init_WV_Total()
  if os.path.isfile(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeH):os.remove(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeH)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITL =BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_Now_Datetime()
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITM=BKrEzkAYvhUpNwOmtQDqsgVjWRXITL+datetime.timedelta(days=BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(__addon__.getSetting('cache_ttl')))
  (BKrEzkAYvhUpNwOmtQDqsgVjWRXIGH,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGL,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGM)=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_account()
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Save_session_acount(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGH,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGL,BKrEzkAYvhUpNwOmtQDqsgVjWRXIGM)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.WV['account']['token_limit']=BKrEzkAYvhUpNwOmtQDqsgVjWRXITM.strftime('%Y%m%d')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.JsonFile_Save(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeH,BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.WV)
 def cookiefile_check(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.WV=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.JsonFile_Load(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeH)
  if 'account' not in BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.WV:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Init_WV_Total()
   return BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  if 'uuid' not in BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.WV.get('cookies'):
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Init_WV_Total()
   return BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  (BKrEzkAYvhUpNwOmtQDqsgVjWRXITc,BKrEzkAYvhUpNwOmtQDqsgVjWRXITu,BKrEzkAYvhUpNwOmtQDqsgVjWRXITd)=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_account()
  (BKrEzkAYvhUpNwOmtQDqsgVjWRXITC,BKrEzkAYvhUpNwOmtQDqsgVjWRXITF,BKrEzkAYvhUpNwOmtQDqsgVjWRXITx)=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Load_session_acount()
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXITc!=BKrEzkAYvhUpNwOmtQDqsgVjWRXITC or BKrEzkAYvhUpNwOmtQDqsgVjWRXITu!=BKrEzkAYvhUpNwOmtQDqsgVjWRXITF or BKrEzkAYvhUpNwOmtQDqsgVjWRXITd!=BKrEzkAYvhUpNwOmtQDqsgVjWRXITx:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Init_WV_Total()
   return BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.WV['account']['token_limit']):
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Init_WV_Total()
   return BKrEzkAYvhUpNwOmtQDqsgVjWRXILF
  return BKrEzkAYvhUpNwOmtQDqsgVjWRXILC
 def dp_LiveCatagory_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITP =args.get('sCode')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITa=args.get('sIndex')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo,BKrEzkAYvhUpNwOmtQDqsgVjWRXITy=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_LiveCatagory_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXITP,BKrEzkAYvhUpNwOmtQDqsgVjWRXITa)
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('title')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'LIVE_LIST','genre':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('genre'),'baseapi':BKrEzkAYvhUpNwOmtQDqsgVjWRXITy}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIib={'title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'plot':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img='',infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIib,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo)>0:xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_MainCatagory_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITP =args.get('sCode')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITa=args.get('sIndex')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT =args.get('sType')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_MainCatagory_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXITP,BKrEzkAYvhUpNwOmtQDqsgVjWRXITa,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT)
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT in['vod','vod09']:
    if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('subtype')=='catagory':
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG='PROGRAM_LIST'
    else:
     BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG='SUPERSECTION_LIST'
   elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJT=='movie':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG='MOVIE_LIST'
   else:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=''
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='%s (%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('title'),args.get('ordernm'))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG,'suburl':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('suburl'),'subapi':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_exclusion21():
    if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('title')=='성인' or BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('title')=='성인+' or BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('title')=='에로티시즘' or BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('title')=='19':continue
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIib={'title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'plot':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img='',infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIib,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo)>0:xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_Program_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITl =args.get('subapi')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf=BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(args.get('page'))
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu =args.get('orderby')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log('dp_Program_List')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log(BKrEzkAYvhUpNwOmtQDqsgVjWRXITl)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_Program_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXITl,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf,BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu)
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('videoid')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIne =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('vidtype')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('title')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIni=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('thumbnail')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('age')
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ=='18' or BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ=='19' or BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ=='21':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC+=' (%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIib={'plot':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'mpaa':BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ,'mediatype':'tvshow','title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'SEASON_LIST','videoid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'vidtype':BKrEzkAYvhUpNwOmtQDqsgVjWRXIne,}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy=[]
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInG={'mode':'VIEW_DETAIL','values':{'videoid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'vidtype':'tvshow','contenttype':BKrEzkAYvhUpNwOmtQDqsgVjWRXIne,}}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInT=json.dumps(BKrEzkAYvhUpNwOmtQDqsgVjWRXInG,separators=(',',':'))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInT=base64.standard_b64encode(BKrEzkAYvhUpNwOmtQDqsgVjWRXInT.encode()).decode('utf-8')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInT=BKrEzkAYvhUpNwOmtQDqsgVjWRXInT.replace('+','%2B')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInH='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXInT)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy.append(('상세정보 조회',BKrEzkAYvhUpNwOmtQDqsgVjWRXInH))
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_makebookmark():
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInG={'videoid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'vidtype':'tvshow','vtitle':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'vsubtitle':'','contenttype':BKrEzkAYvhUpNwOmtQDqsgVjWRXIne,}
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInL=json.dumps(BKrEzkAYvhUpNwOmtQDqsgVjWRXInG)
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInL=urllib.parse.quote(BKrEzkAYvhUpNwOmtQDqsgVjWRXInL)
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInH='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXInL)
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy.append(('(통합) 찜 영상에 추가',BKrEzkAYvhUpNwOmtQDqsgVjWRXInH))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIni,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIib,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil,ContextMenu=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['mode'] ='PROGRAM_LIST' 
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['subapi']=BKrEzkAYvhUpNwOmtQDqsgVjWRXITl 
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['page'] =BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='[B]%s >>[/B]'%'다음 페이지'
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInM=BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  xbmcplugin.setContent(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,'tvshows')
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo)>0:xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_Season_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS=args.get('videoid')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIne=args.get('vidtype')
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIne=='contentid':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGd=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS
   BKrEzkAYvhUpNwOmtQDqsgVjWRXITf =BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.ContentidToSeasonid(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS)
  else:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGd=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.ProgramidToContentid(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXITf =BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.ContentidToSeasonid(BKrEzkAYvhUpNwOmtQDqsgVjWRXIGd)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITo=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_Season_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXITf)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXITo)>1:
   for BKrEzkAYvhUpNwOmtQDqsgVjWRXITb in BKrEzkAYvhUpNwOmtQDqsgVjWRXITo:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXITS=BKrEzkAYvhUpNwOmtQDqsgVjWRXITb.get('season_Id')
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIHe=BKrEzkAYvhUpNwOmtQDqsgVjWRXITb.get('season_Nm')
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIHi=BKrEzkAYvhUpNwOmtQDqsgVjWRXITb.get('programNm')
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIni=BKrEzkAYvhUpNwOmtQDqsgVjWRXITb.get('thumbnail')
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIHJ =BKrEzkAYvhUpNwOmtQDqsgVjWRXITb.get('synopsis')
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'mediatype':'tvshow','title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHe,'plot':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHJ,}
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'EPISODE_LIST','seasonid':BKrEzkAYvhUpNwOmtQDqsgVjWRXITS,'page':'1',}
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHe,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXIHi,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIni,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil,ContextMenu=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu)
   xbmcplugin.setContent(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
  else:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHn={'seasonid':BKrEzkAYvhUpNwOmtQDqsgVjWRXITf,'page':'1',}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Episode_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHn)
 def dp_Episode_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITf =args.get('seasonid')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf =BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(args.get('page'))
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_Episode_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXITf,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf,orderby=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_winEpisodeOrderby())
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInM=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('episodenumber')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHG ='[%s]\n\n%s'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('episodetitle'),BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('synopsis'))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'mediatype':'episode','title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('programtitle'),'plot':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHG,'cast':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('episodeactors'),}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'VOD','programid':BKrEzkAYvhUpNwOmtQDqsgVjWRXITf,'contentid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('contentid'),'thumbnail':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('thumbnail'),'title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('programtitle'),'subtitle':BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('programtitle'),sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('thumbnail'),infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf==1:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'plot':'정렬순서를 변경합니다.'}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['mode'] ='ORDER_BY' 
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_winEpisodeOrderby()=='desc':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='정렬순서변경 : 최신화부터 -> 1회부터'
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['orderby']='asc'
   else:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='정렬순서변경 : 1회부터 -> 최신화부터'
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['orderby']='desc'
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil,isLink=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['mode'] ='EPISODE_LIST' 
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['seasonid']=BKrEzkAYvhUpNwOmtQDqsgVjWRXITf
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['page'] =BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='[B]%s >>[/B]'%'다음 페이지'
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInM=BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  xbmcplugin.setContent(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,'episodes')
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo)>0:xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_SuperSection_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHT =args.get('suburl')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITl =args.get('subapi')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log('dp_SuperSection_List')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log('suburl : '+BKrEzkAYvhUpNwOmtQDqsgVjWRXIHT)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log('subapi : '+BKrEzkAYvhUpNwOmtQDqsgVjWRXITl)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_SuperMultiSection_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHT)
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('title')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXITl =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('subapi')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHL=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('cell_type')
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXITl.find('contenttype=movie')>=0 or BKrEzkAYvhUpNwOmtQDqsgVjWRXITl.find('mtype=svod')>=0:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG='MOVIE_LIST'
   elif re.search('themes/2\d{4}',BKrEzkAYvhUpNwOmtQDqsgVjWRXITl)or re.search('themes-band/9\d{4}',BKrEzkAYvhUpNwOmtQDqsgVjWRXITl):
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG='MOVIE_LIST'
   else:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'plot':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'mediatype':'tvshow',}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG,'suburl':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHT,'subapi':BKrEzkAYvhUpNwOmtQDqsgVjWRXITl,'page':'1',}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo)>0:xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_BandLiveSection_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITl =args.get('subapi')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf=BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(args.get('page'))
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_BandLiveSection_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXITl,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf)
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHM =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('channelid')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHc =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('studio')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHu=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('tvshowtitle')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIni =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('thumbnail')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('age')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'mediatype':'tvshow','mpaa':BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ,'title':'%s < %s >'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHc,BKrEzkAYvhUpNwOmtQDqsgVjWRXIHu),'tvshowtitle':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHu,'studio':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHc,'plot':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHc}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'LIVE','contentid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHM}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHc,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXIHu,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('thumbnail'),infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['mode'] ='BANDLIVESECTION_LIST' 
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['subapi']=BKrEzkAYvhUpNwOmtQDqsgVjWRXITl
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['page'] =BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='[B]%s >>[/B]'%'다음 페이지'
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInM=BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo)>0:xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_Band2Section_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITl =args.get('subapi')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf=BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(args.get('page'))
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_Band2Section_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXITl,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf)
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('programtitle')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInM =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('episodetitle')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'plot':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC+'\n\n'+BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,'mpaa':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('age'),'mediatype':'episode'}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'VOD','programid':'-','contentid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('videoid'),'thumbnail':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('thumbnail'),'title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'subtitle':BKrEzkAYvhUpNwOmtQDqsgVjWRXInM}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('thumbnail'),infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['mode'] ='BAND2SECTION_LIST' 
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['subapi']=BKrEzkAYvhUpNwOmtQDqsgVjWRXITl
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['page'] =BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='[B]%s >>[/B]'%'다음 페이지'
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInM=BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo)>0:xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_Movie_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITl =args.get('subapi')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf=BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(args.get('page'))
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu =args.get('orderby')or '-'
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log('dp_Movie_List')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log(BKrEzkAYvhUpNwOmtQDqsgVjWRXITl)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_Movie_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXITl,BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf,BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu)
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('videoid')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIne =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('vidtype')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('title')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIni=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('thumbnail')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('age')
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ=='18' or BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ=='19' or BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ=='21':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC+=' (%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'plot':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'mpaa':BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ,'mediatype':'movie'}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'MOVIE','contentid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'thumbnail':BKrEzkAYvhUpNwOmtQDqsgVjWRXIni,'age':BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ,}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy=[]
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInG={'mode':'VIEW_DETAIL','values':{'videoid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'vidtype':'movie','contenttype':BKrEzkAYvhUpNwOmtQDqsgVjWRXIne,}}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInT=json.dumps(BKrEzkAYvhUpNwOmtQDqsgVjWRXInG,separators=(',',':'))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInT=base64.standard_b64encode(BKrEzkAYvhUpNwOmtQDqsgVjWRXInT.encode()).decode('utf-8')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInT=BKrEzkAYvhUpNwOmtQDqsgVjWRXInT.replace('+','%2B')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInH='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXInT)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy.append(('상세정보 조회',BKrEzkAYvhUpNwOmtQDqsgVjWRXInH))
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.get_settings_makebookmark():
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInG={'videoid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,'vidtype':'movie','vtitle':BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,'vsubtitle':'','contenttype':'programid',}
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInL=json.dumps(BKrEzkAYvhUpNwOmtQDqsgVjWRXInG)
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInL=urllib.parse.quote(BKrEzkAYvhUpNwOmtQDqsgVjWRXInL)
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInH='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXInL)
    BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy.append(('(통합) 찜 영상에 추가',BKrEzkAYvhUpNwOmtQDqsgVjWRXInH))
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel='',img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIni,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil,ContextMenu=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJy)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJL:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['mode'] ='MOVIE_LIST' 
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['subapi']=BKrEzkAYvhUpNwOmtQDqsgVjWRXITl 
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['page'] =BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil['orderby']=BKrEzkAYvhUpNwOmtQDqsgVjWRXIiu
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC='[B]%s >>[/B]'%'다음 페이지'
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInM=BKrEzkAYvhUpNwOmtQDqsgVjWRXILo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJf+1)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiC,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIiy,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXILu,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILC,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  xbmcplugin.setContent(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,'movies')
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo)>0:xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_Set_Bookmark(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHd=urllib.parse.unquote(args.get('bm_param'))
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHd=json.loads(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHd)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS =BKrEzkAYvhUpNwOmtQDqsgVjWRXIHd.get('videoid')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIne =BKrEzkAYvhUpNwOmtQDqsgVjWRXIHd.get('vidtype')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHC =BKrEzkAYvhUpNwOmtQDqsgVjWRXIHd.get('vtitle')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHF =BKrEzkAYvhUpNwOmtQDqsgVjWRXIHd.get('vsubtitle')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHx=BKrEzkAYvhUpNwOmtQDqsgVjWRXIHd.get('contenttype')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF=xbmcgui.Dialog()
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIGe=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF.yesno(__language__(30913).encode('utf8'),BKrEzkAYvhUpNwOmtQDqsgVjWRXIHC+' \n\n'+__language__(30914))
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIGe==BKrEzkAYvhUpNwOmtQDqsgVjWRXILF:return
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.GetBookmarkInfo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,BKrEzkAYvhUpNwOmtQDqsgVjWRXIne,BKrEzkAYvhUpNwOmtQDqsgVjWRXIHx)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHa=json.dumps(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHa=urllib.parse.quote(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHa)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXInH ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHa)
  xbmc.executebuiltin(BKrEzkAYvhUpNwOmtQDqsgVjWRXInH)
 def dp_LiveChannel_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHy =args.get('genre')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXITy=args.get('baseapi')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_LiveChannel_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHy,BKrEzkAYvhUpNwOmtQDqsgVjWRXITy)
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHM =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('channelid')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHc =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('studio')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHu=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('tvshowtitle')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIni =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('thumbnail')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('age')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHl =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('epg')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'mediatype':'episode','mpaa':BKrEzkAYvhUpNwOmtQDqsgVjWRXInJ,'title':'%s < %s >'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHc,BKrEzkAYvhUpNwOmtQDqsgVjWRXIHu),'tvshowtitle':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHu,'studio':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHc,'plot':'%s\n\n%s'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHc,BKrEzkAYvhUpNwOmtQDqsgVjWRXIHl)}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'LIVE','contentid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHM}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHc,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXIHu,img=BKrEzkAYvhUpNwOmtQDqsgVjWRXIni,infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILl(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo)>0:xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_Sports_GameList(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,args):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.Get_Sports_Gamelist()
  for BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb in BKrEzkAYvhUpNwOmtQDqsgVjWRXIJo:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHf =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('game_date')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHo =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('game_time')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHb =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('svc_id')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIHS =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('away_team')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILe =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('home_team')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILi=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('game_status')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILJ =BKrEzkAYvhUpNwOmtQDqsgVjWRXIJb.get('game_place')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILn ='%s vs %s (%s)'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHS,BKrEzkAYvhUpNwOmtQDqsgVjWRXILe,BKrEzkAYvhUpNwOmtQDqsgVjWRXILJ)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILG =BKrEzkAYvhUpNwOmtQDqsgVjWRXIHf+' '+BKrEzkAYvhUpNwOmtQDqsgVjWRXIHo
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXILi=='LIVE':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXILi='~경기중~'
   elif BKrEzkAYvhUpNwOmtQDqsgVjWRXILi=='END':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXILi='경기종료'
   elif BKrEzkAYvhUpNwOmtQDqsgVjWRXILi=='CANCEL':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXILi='취소'
   else:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXILi=''
   if BKrEzkAYvhUpNwOmtQDqsgVjWRXILi=='':
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInM=BKrEzkAYvhUpNwOmtQDqsgVjWRXILn
   else:
    BKrEzkAYvhUpNwOmtQDqsgVjWRXInM=BKrEzkAYvhUpNwOmtQDqsgVjWRXILn+'  '+BKrEzkAYvhUpNwOmtQDqsgVjWRXILi
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl={'mediatype':'episode','title':BKrEzkAYvhUpNwOmtQDqsgVjWRXILn,'plot':'%s\n\n%s\n\n%s'%(BKrEzkAYvhUpNwOmtQDqsgVjWRXILG,BKrEzkAYvhUpNwOmtQDqsgVjWRXILn,BKrEzkAYvhUpNwOmtQDqsgVjWRXILi)}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'SPORTS','contentid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHb}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.add_dir(BKrEzkAYvhUpNwOmtQDqsgVjWRXILG,sublabel=BKrEzkAYvhUpNwOmtQDqsgVjWRXInM,img='',infoLabels=BKrEzkAYvhUpNwOmtQDqsgVjWRXIJl,isFolder=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF,params=BKrEzkAYvhUpNwOmtQDqsgVjWRXIil)
  xbmcplugin.endOfDirectory(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM._addon_handle,cacheToDisc=BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
 def dp_View_Detail(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM,BKrEzkAYvhUpNwOmtQDqsgVjWRXILM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS =BKrEzkAYvhUpNwOmtQDqsgVjWRXILM.get('videoid')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIne =BKrEzkAYvhUpNwOmtQDqsgVjWRXILM.get('vidtype') 
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHx=BKrEzkAYvhUpNwOmtQDqsgVjWRXILM.get('contenttype')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log(BKrEzkAYvhUpNwOmtQDqsgVjWRXIne)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.addon_log(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHx)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.GetBookmarkInfo(BKrEzkAYvhUpNwOmtQDqsgVjWRXIJS,BKrEzkAYvhUpNwOmtQDqsgVjWRXIne,BKrEzkAYvhUpNwOmtQDqsgVjWRXIHx)
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIne=='tvshow':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'SEASON_LIST','videoid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP['indexinfo']['videoid'],'vidtype':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP['indexinfo']['vidtype'],}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGT='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(BKrEzkAYvhUpNwOmtQDqsgVjWRXIil))
  else:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIil={'mode':'MOVIE','contentid':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP['indexinfo']['videoid'],'title':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP['saveinfo']['infoLabels']['title'],'thumbnail':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP['saveinfo']['thumbnail'],'age':BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP['saveinfo']['infoLabels']['mpaa'],}
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIGT='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(BKrEzkAYvhUpNwOmtQDqsgVjWRXIil))
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF=xbmcgui.ListItem(label=BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP['saveinfo']['title'],path=BKrEzkAYvhUpNwOmtQDqsgVjWRXIGT)
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.setArt(BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP['saveinfo']['thumbnail'])
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.Set_InfoTag(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.getVideoInfoTag(),BKrEzkAYvhUpNwOmtQDqsgVjWRXIHP['saveinfo']['infoLabels'])
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIne=='movie':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.setIsFolder(BKrEzkAYvhUpNwOmtQDqsgVjWRXILF)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.setProperty('IsPlayable','true')
  else:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.setIsFolder(BKrEzkAYvhUpNwOmtQDqsgVjWRXILC)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF.setProperty('IsPlayable','false')
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF=xbmcgui.Dialog()
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeF.info(BKrEzkAYvhUpNwOmtQDqsgVjWRXIiF)
 def wavve_main(BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM):
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.WavveObj.KodiVersion=BKrEzkAYvhUpNwOmtQDqsgVjWRXILd(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  BKrEzkAYvhUpNwOmtQDqsgVjWRXILT=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.main_params.get('params')
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXILT:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILH =base64.standard_b64decode(BKrEzkAYvhUpNwOmtQDqsgVjWRXILT).decode('utf-8')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILH =json.loads(BKrEzkAYvhUpNwOmtQDqsgVjWRXILH)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG =BKrEzkAYvhUpNwOmtQDqsgVjWRXILH.get('mode')
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILM =BKrEzkAYvhUpNwOmtQDqsgVjWRXILH.get('values')
  else:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.main_params.get('mode',BKrEzkAYvhUpNwOmtQDqsgVjWRXILu)
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILM=BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.main_params
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='LOGOUT':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.logout()
   return
  BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.login_main()
  if BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG is BKrEzkAYvhUpNwOmtQDqsgVjWRXILu:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Main_List()
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG in['LIVE','VOD','MOVIE','SPORTS']:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.play_VIDEO(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='LIVE_CATAGORY':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_LiveCatagory_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='MAIN_CATAGORY':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_MainCatagory_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='SUPERSECTION_LIST':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_SuperSection_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='BANDLIVESECTION_LIST':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_BandLiveSection_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='BAND2SECTION_LIST':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Band2Section_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='PROGRAM_LIST':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Program_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='SEASON_LIST':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Season_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='EPISODE_LIST':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Episode_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='MOVIE_LIST':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Movie_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='LIVE_LIST':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_LiveChannel_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='ORDER_BY':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_setEpOrderby(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='SEARCH_GROUP':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Search_Group(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG in['SEARCH_LIST','LOCAL_SEARCH']:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Search_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='WATCH_GROUP':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Watch_Group(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='WATCH_LIST':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Watch_List(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='SET_BOOKMARK':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Set_Bookmark(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_History_Remove(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG in['TOTAL_SEARCH','TOTAL_HISTORY']:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Global_Search(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='SEARCH_HISTORY':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Search_History(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='MENU_BOOKMARK':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Bookmark_Menu(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='GAME_LIST':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_Sports_GameList(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  elif BKrEzkAYvhUpNwOmtQDqsgVjWRXIJG=='VIEW_DETAIL':
   BKrEzkAYvhUpNwOmtQDqsgVjWRXIeM.dp_View_Detail(BKrEzkAYvhUpNwOmtQDqsgVjWRXILM)
  else:
   BKrEzkAYvhUpNwOmtQDqsgVjWRXILu
# Created by pyminifier (https://github.com/liftoff/pyminifier)
