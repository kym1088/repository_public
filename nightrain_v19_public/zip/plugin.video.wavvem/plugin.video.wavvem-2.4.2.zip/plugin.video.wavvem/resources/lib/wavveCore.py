__author__="NightRain"
gRxlBNGPjKnafHqIMbpCVOScAkYLdy=object
gRxlBNGPjKnafHqIMbpCVOScAkYLdD=None
gRxlBNGPjKnafHqIMbpCVOScAkYLdm=False
gRxlBNGPjKnafHqIMbpCVOScAkYLdw=open
gRxlBNGPjKnafHqIMbpCVOScAkYLJv=True
gRxlBNGPjKnafHqIMbpCVOScAkYLJs=range
gRxlBNGPjKnafHqIMbpCVOScAkYLJt=str
gRxlBNGPjKnafHqIMbpCVOScAkYLJu=len
gRxlBNGPjKnafHqIMbpCVOScAkYLJQ=Exception
gRxlBNGPjKnafHqIMbpCVOScAkYLJo=print
gRxlBNGPjKnafHqIMbpCVOScAkYLJd=dict
gRxlBNGPjKnafHqIMbpCVOScAkYLJe=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
gRxlBNGPjKnafHqIMbpCVOScAkYLvt =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class gRxlBNGPjKnafHqIMbpCVOScAkYLvs(gRxlBNGPjKnafHqIMbpCVOScAkYLdy):
 def __init__(gRxlBNGPjKnafHqIMbpCVOScAkYLvu):
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN='https://apis.wavve.com'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV ={}
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Init_WV_Total()
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.DEVICE ='pc'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.DRM ='wm'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.PARTNER ='pooq'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.POOQZONE ='none'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.REGION ='kor'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.TARGETAGE ='all'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.HTTPTAG ='https://'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.LIST_LIMIT=30 
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.EP_LIMIT =30 
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.MV_LIMIT =24 
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.SEARCH_LIMIT=20 
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.DEFAULT_HEADER={'user-agent':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.USER_AGENT}
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.KodiVersion=20
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV_SESSION_COOKIES1=''
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV_SESSION_COOKIES2=''
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.COOKIE_FILE_NAME =''
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV_STREAM_FILENAME =''
 def Init_WV_Total(gRxlBNGPjKnafHqIMbpCVOScAkYLvu):
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV={'account':{},'cookies':{},}
 def callRequestCookies(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,jobtype,gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,redirects=gRxlBNGPjKnafHqIMbpCVOScAkYLdm):
  gRxlBNGPjKnafHqIMbpCVOScAkYLvQ=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.DEFAULT_HEADER
  if headers:gRxlBNGPjKnafHqIMbpCVOScAkYLvQ.update(headers)
  if jobtype=='Get':
   gRxlBNGPjKnafHqIMbpCVOScAkYLvo=requests.get(gRxlBNGPjKnafHqIMbpCVOScAkYLsT,params=params,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLvQ,cookies=cookies,allow_redirects=redirects)
  else:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvo=requests.post(gRxlBNGPjKnafHqIMbpCVOScAkYLsT,json=payload,params=params,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLvQ,cookies=cookies,allow_redirects=redirects)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLvo
 def JsonFile_Save(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,filename,gRxlBNGPjKnafHqIMbpCVOScAkYLvd):
  if filename=='':return gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  try:
   fp=gRxlBNGPjKnafHqIMbpCVOScAkYLdw(filename,'w',-1,'utf-8')
   json.dump(gRxlBNGPjKnafHqIMbpCVOScAkYLvd,fp,indent=4,ensure_ascii=gRxlBNGPjKnafHqIMbpCVOScAkYLdm)
   fp.close()
  except:
   return gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  return gRxlBNGPjKnafHqIMbpCVOScAkYLJv
 def JsonFile_Load(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,filename):
  if filename=='':return{}
  try:
   fp=gRxlBNGPjKnafHqIMbpCVOScAkYLdw(filename,'r',-1,'utf-8')
   gRxlBNGPjKnafHqIMbpCVOScAkYLve=json.load(fp)
   fp.close()
  except:
   return{}
  return gRxlBNGPjKnafHqIMbpCVOScAkYLve
 def TextFile_Save(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,filename,resText):
  if filename=='':return gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  try:
   fp=gRxlBNGPjKnafHqIMbpCVOScAkYLdw(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  return gRxlBNGPjKnafHqIMbpCVOScAkYLJv
 def Save_session_acount(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLvU,gRxlBNGPjKnafHqIMbpCVOScAkYLvT,gRxlBNGPjKnafHqIMbpCVOScAkYLvz):
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['account']['wvid']=base64.standard_b64encode(gRxlBNGPjKnafHqIMbpCVOScAkYLvU.encode()).decode('utf-8')
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['account']['wvpw']=base64.standard_b64encode(gRxlBNGPjKnafHqIMbpCVOScAkYLvT.encode()).decode('utf-8')
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['account']['wvpf']=gRxlBNGPjKnafHqIMbpCVOScAkYLvz 
 def Load_session_acount(gRxlBNGPjKnafHqIMbpCVOScAkYLvu):
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvU=base64.standard_b64decode(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['account']['wvid']).decode('utf-8')
   gRxlBNGPjKnafHqIMbpCVOScAkYLvT=base64.standard_b64decode(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['account']['wvpw']).decode('utf-8')
   gRxlBNGPjKnafHqIMbpCVOScAkYLvz=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['account']['wvpf']
  except:
   return '','',0
  return gRxlBNGPjKnafHqIMbpCVOScAkYLvU,gRxlBNGPjKnafHqIMbpCVOScAkYLvT,gRxlBNGPjKnafHqIMbpCVOScAkYLvz
 def GetDefaultParams(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,login=gRxlBNGPjKnafHqIMbpCVOScAkYLJv):
  gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'apikey':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.APIKEY,'credential':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['cookies']['credential']if login else 'none','device':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.DEVICE,'drm':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.DRM,'partner':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.PARTNER,'pooqzone':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.POOQZONE,'region':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.REGION,'targetage':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.TARGETAGE,}
  return gRxlBNGPjKnafHqIMbpCVOScAkYLvW
 def GetDefaultParams_AND(gRxlBNGPjKnafHqIMbpCVOScAkYLvu):
  gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['cookies']['credential'],'device':'ott','drm':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.DRM,'partner':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.PARTNER,'pooqzone':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.POOQZONE,'region':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.REGION,'targetage':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.TARGETAGE,}
  return gRxlBNGPjKnafHqIMbpCVOScAkYLvW
 def GetGUID(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   gRxlBNGPjKnafHqIMbpCVOScAkYLvh=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   gRxlBNGPjKnafHqIMbpCVOScAkYLvX=GenerateRandomString(5)
   gRxlBNGPjKnafHqIMbpCVOScAkYLvF=gRxlBNGPjKnafHqIMbpCVOScAkYLvX+media+gRxlBNGPjKnafHqIMbpCVOScAkYLvh
   return gRxlBNGPjKnafHqIMbpCVOScAkYLvF
  def GenerateRandomString(num):
   from random import randint
   gRxlBNGPjKnafHqIMbpCVOScAkYLvr=""
   for i in gRxlBNGPjKnafHqIMbpCVOScAkYLJs(0,num):
    s=gRxlBNGPjKnafHqIMbpCVOScAkYLJt(randint(1,5))
    gRxlBNGPjKnafHqIMbpCVOScAkYLvr+=s
   return gRxlBNGPjKnafHqIMbpCVOScAkYLvr
  if guidType==3:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvF=guid_str
  else:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvF=GenerateID(guid_str)
  gRxlBNGPjKnafHqIMbpCVOScAkYLvE=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetHash(gRxlBNGPjKnafHqIMbpCVOScAkYLvF)
  if guidType in[2,3]:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvE='%s-%s-%s-%s-%s'%(gRxlBNGPjKnafHqIMbpCVOScAkYLvE[:8],gRxlBNGPjKnafHqIMbpCVOScAkYLvE[8:12],gRxlBNGPjKnafHqIMbpCVOScAkYLvE[12:16],gRxlBNGPjKnafHqIMbpCVOScAkYLvE[16:20],gRxlBNGPjKnafHqIMbpCVOScAkYLvE[20:])
  return gRxlBNGPjKnafHqIMbpCVOScAkYLvE
 def GetHash(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return gRxlBNGPjKnafHqIMbpCVOScAkYLJt(m.hexdigest())
 def CheckQuality(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,sel_qt,qt_list):
  gRxlBNGPjKnafHqIMbpCVOScAkYLvi=0
  for gRxlBNGPjKnafHqIMbpCVOScAkYLvy in qt_list:
   if sel_qt>=gRxlBNGPjKnafHqIMbpCVOScAkYLvy:return gRxlBNGPjKnafHqIMbpCVOScAkYLvy
   gRxlBNGPjKnafHqIMbpCVOScAkYLvi=gRxlBNGPjKnafHqIMbpCVOScAkYLvy
  return gRxlBNGPjKnafHqIMbpCVOScAkYLvi
 def Get_Now_Datetime(gRxlBNGPjKnafHqIMbpCVOScAkYLvu):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,in_text):
  gRxlBNGPjKnafHqIMbpCVOScAkYLvm=in_text.replace('&lt;','<').replace('&gt;','>')
  gRxlBNGPjKnafHqIMbpCVOScAkYLvm=gRxlBNGPjKnafHqIMbpCVOScAkYLvm.replace('<br>','\n')
  gRxlBNGPjKnafHqIMbpCVOScAkYLvm=gRxlBNGPjKnafHqIMbpCVOScAkYLvm.replace('$O$','')
  gRxlBNGPjKnafHqIMbpCVOScAkYLvm=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',gRxlBNGPjKnafHqIMbpCVOScAkYLvm)
  gRxlBNGPjKnafHqIMbpCVOScAkYLvm=gRxlBNGPjKnafHqIMbpCVOScAkYLvm.lstrip('#')
  return gRxlBNGPjKnafHqIMbpCVOScAkYLvm
 def make_str_ToCookie(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,cookieStr):
  gRxlBNGPjKnafHqIMbpCVOScAkYLvw={}
  for gRxlBNGPjKnafHqIMbpCVOScAkYLsv in cookieStr.split(';'):
   gRxlBNGPjKnafHqIMbpCVOScAkYLst=gRxlBNGPjKnafHqIMbpCVOScAkYLsv.split('=')
   gRxlBNGPjKnafHqIMbpCVOScAkYLvw[gRxlBNGPjKnafHqIMbpCVOScAkYLst[0]]=gRxlBNGPjKnafHqIMbpCVOScAkYLst[1]
  return gRxlBNGPjKnafHqIMbpCVOScAkYLvw 
 def make_stream_header(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLsJ,gRxlBNGPjKnafHqIMbpCVOScAkYLvw):
  gRxlBNGPjKnafHqIMbpCVOScAkYLsu=''
  if gRxlBNGPjKnafHqIMbpCVOScAkYLvw not in[{},gRxlBNGPjKnafHqIMbpCVOScAkYLdD,'']:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsQ=gRxlBNGPjKnafHqIMbpCVOScAkYLJu(gRxlBNGPjKnafHqIMbpCVOScAkYLvw)
   for gRxlBNGPjKnafHqIMbpCVOScAkYLso,gRxlBNGPjKnafHqIMbpCVOScAkYLsd in gRxlBNGPjKnafHqIMbpCVOScAkYLvw.items():
    gRxlBNGPjKnafHqIMbpCVOScAkYLsu+='{}={}'.format(gRxlBNGPjKnafHqIMbpCVOScAkYLso,gRxlBNGPjKnafHqIMbpCVOScAkYLsd)
    gRxlBNGPjKnafHqIMbpCVOScAkYLsQ+=-1
    if gRxlBNGPjKnafHqIMbpCVOScAkYLsQ>0:gRxlBNGPjKnafHqIMbpCVOScAkYLsu+='; '
   gRxlBNGPjKnafHqIMbpCVOScAkYLsJ['cookie']=gRxlBNGPjKnafHqIMbpCVOScAkYLsu
  gRxlBNGPjKnafHqIMbpCVOScAkYLse=''
  i=0
  for gRxlBNGPjKnafHqIMbpCVOScAkYLso,gRxlBNGPjKnafHqIMbpCVOScAkYLsd in gRxlBNGPjKnafHqIMbpCVOScAkYLsJ.items():
   i=i+1
   if i>1:gRxlBNGPjKnafHqIMbpCVOScAkYLse+='&'
   gRxlBNGPjKnafHqIMbpCVOScAkYLse+='{}={}'.format(gRxlBNGPjKnafHqIMbpCVOScAkYLso,urllib.parse.quote(gRxlBNGPjKnafHqIMbpCVOScAkYLsd))
  return gRxlBNGPjKnafHqIMbpCVOScAkYLse
 def GetCredential(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,user_id,user_pw,user_pf):
  gRxlBNGPjKnafHqIMbpCVOScAkYLsU=gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+ '/login'
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsz={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Post',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLsz,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['cookies']['credential']=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['credential']
   if user_pf!=0:
    gRxlBNGPjKnafHqIMbpCVOScAkYLsz={'id':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['cookies']['credential'],'password':'','profile':gRxlBNGPjKnafHqIMbpCVOScAkYLJt(user_pf),'pushid':'','type':'credential'}
    gRxlBNGPjKnafHqIMbpCVOScAkYLvW =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLJv) 
    gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Post',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLsz,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
    gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
    gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['cookies']['credential']=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['credential']
   gRxlBNGPjKnafHqIMbpCVOScAkYLsX=user_id+gRxlBNGPjKnafHqIMbpCVOScAkYLJt(user_pf) 
   gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['cookies']['uuid']=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetGUID(guid_str=gRxlBNGPjKnafHqIMbpCVOScAkYLsX,guidType=3)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsU=gRxlBNGPjKnafHqIMbpCVOScAkYLJv
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Init_WV_Total()
  return gRxlBNGPjKnafHqIMbpCVOScAkYLsU
 def GetIssue(gRxlBNGPjKnafHqIMbpCVOScAkYLvu):
  gRxlBNGPjKnafHqIMbpCVOScAkYLsF=gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/guid/issue'
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams()
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsr=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['guid']
   gRxlBNGPjKnafHqIMbpCVOScAkYLsE=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['guidtimestamp']
   if gRxlBNGPjKnafHqIMbpCVOScAkYLsr:gRxlBNGPjKnafHqIMbpCVOScAkYLsF=gRxlBNGPjKnafHqIMbpCVOScAkYLJv
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsr='none'
   gRxlBNGPjKnafHqIMbpCVOScAkYLsE='none' 
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.guid=gRxlBNGPjKnafHqIMbpCVOScAkYLsr
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.guidtimestamp=gRxlBNGPjKnafHqIMbpCVOScAkYLsE
  return gRxlBNGPjKnafHqIMbpCVOScAkYLsF
 def Baseapi_Parse(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLsm):
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsi =urllib.parse.urlsplit(gRxlBNGPjKnafHqIMbpCVOScAkYLsm)
   if gRxlBNGPjKnafHqIMbpCVOScAkYLsi.netloc=='':
    gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.HTTPTAG+gRxlBNGPjKnafHqIMbpCVOScAkYLsi.netloc+gRxlBNGPjKnafHqIMbpCVOScAkYLsi.path
   else:
    gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLsi.scheme+'://'+gRxlBNGPjKnafHqIMbpCVOScAkYLsi.netloc+gRxlBNGPjKnafHqIMbpCVOScAkYLsi.path
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW=gRxlBNGPjKnafHqIMbpCVOScAkYLJd(urllib.parse.parse_qsl(gRxlBNGPjKnafHqIMbpCVOScAkYLsi.query))
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return '',{}
  return gRxlBNGPjKnafHqIMbpCVOScAkYLsT,gRxlBNGPjKnafHqIMbpCVOScAkYLvW
 def GetSupermultiUrl(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,sCode,sIndex='0'):
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/cf/supermultisections/'+sCode
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsy=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['multisectionlist'][gRxlBNGPjKnafHqIMbpCVOScAkYLJe(sIndex)]['eventlist'][1]['url']
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return ''
  return gRxlBNGPjKnafHqIMbpCVOScAkYLsy
 def Get_LiveCatagory_List(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,sCode,sIndex='0'):
  gRxlBNGPjKnafHqIMbpCVOScAkYLsD=[]
  gRxlBNGPjKnafHqIMbpCVOScAkYLsm =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetSupermultiUrl(sCode,sIndex)
  (gRxlBNGPjKnafHqIMbpCVOScAkYLsT,gRxlBNGPjKnafHqIMbpCVOScAkYLvW)=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Baseapi_Parse(gRxlBNGPjKnafHqIMbpCVOScAkYLsm)
  if gRxlBNGPjKnafHqIMbpCVOScAkYLsT=='':return gRxlBNGPjKnafHqIMbpCVOScAkYLsD,''
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if not('filter_item_list' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh['filter']['filterlist'][0]):return[],''
   gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['filter']['filterlist'][0]['filter_item_list']
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLtv:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'title':gRxlBNGPjKnafHqIMbpCVOScAkYLts['title'],'genre':gRxlBNGPjKnafHqIMbpCVOScAkYLts['api_parameters'][gRxlBNGPjKnafHqIMbpCVOScAkYLts['api_parameters'].index('=')+1:]}
    gRxlBNGPjKnafHqIMbpCVOScAkYLsD.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[],''
  return gRxlBNGPjKnafHqIMbpCVOScAkYLsD,gRxlBNGPjKnafHqIMbpCVOScAkYLsm
 def Get_MainCatagory_List(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,sCode,sIndex,sType):
  gRxlBNGPjKnafHqIMbpCVOScAkYLsD=[]
  gRxlBNGPjKnafHqIMbpCVOScAkYLsT='https://apis.wavve.com/es/category/launcher-band'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if not('celllist' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh['band']):return[]
   gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['band']['celllist']
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLtv:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtQ =gRxlBNGPjKnafHqIMbpCVOScAkYLts['event_list'][1]['url']
    (gRxlBNGPjKnafHqIMbpCVOScAkYLto,gRxlBNGPjKnafHqIMbpCVOScAkYLtd)=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Baseapi_Parse(gRxlBNGPjKnafHqIMbpCVOScAkYLtQ)
    gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'title':gRxlBNGPjKnafHqIMbpCVOScAkYLts['title_list'][0]['text'],'suburl':gRxlBNGPjKnafHqIMbpCVOScAkYLto,'subapi':gRxlBNGPjKnafHqIMbpCVOScAkYLtd.get('api'),'subtype':'catagory' if gRxlBNGPjKnafHqIMbpCVOScAkYLtd else 'supersection'}
    gRxlBNGPjKnafHqIMbpCVOScAkYLsD.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[]
  return gRxlBNGPjKnafHqIMbpCVOScAkYLsD
 def Get_SuperMultiSection_List(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,subapi_text):
  gRxlBNGPjKnafHqIMbpCVOScAkYLsD=[]
  if '/multiband/' in subapi_text: 
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=subapi_text 
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'client':'40'}
  else:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=subapi_text 
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLsT.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW={}
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if not('multisectionlist' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh):return[]
   gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['multisectionlist']
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLtv:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtJ=gRxlBNGPjKnafHqIMbpCVOScAkYLts['title']
    if gRxlBNGPjKnafHqIMbpCVOScAkYLJu(gRxlBNGPjKnafHqIMbpCVOScAkYLtJ)==0:continue
    if gRxlBNGPjKnafHqIMbpCVOScAkYLtJ=='minor':continue
    if re.search(u'베너',gRxlBNGPjKnafHqIMbpCVOScAkYLtJ):continue
    if re.search(u'배너',gRxlBNGPjKnafHqIMbpCVOScAkYLtJ):continue 
    if gRxlBNGPjKnafHqIMbpCVOScAkYLts['force_refresh']=='y':continue
    if gRxlBNGPjKnafHqIMbpCVOScAkYLJu(gRxlBNGPjKnafHqIMbpCVOScAkYLts['eventlist'])>=3:
     gRxlBNGPjKnafHqIMbpCVOScAkYLtd =gRxlBNGPjKnafHqIMbpCVOScAkYLts['eventlist'][2]['url']
    else:
     gRxlBNGPjKnafHqIMbpCVOScAkYLtd =gRxlBNGPjKnafHqIMbpCVOScAkYLts['eventlist'][1]['url']
    gRxlBNGPjKnafHqIMbpCVOScAkYLte=gRxlBNGPjKnafHqIMbpCVOScAkYLts['cell_type']
    if gRxlBNGPjKnafHqIMbpCVOScAkYLte=='band_2':
     if gRxlBNGPjKnafHqIMbpCVOScAkYLtd.find('channellist=')>=0:
      gRxlBNGPjKnafHqIMbpCVOScAkYLte='band_live'
    gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'title':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_ChangeText(gRxlBNGPjKnafHqIMbpCVOScAkYLtJ),'subapi':gRxlBNGPjKnafHqIMbpCVOScAkYLtd,'cell_type':gRxlBNGPjKnafHqIMbpCVOScAkYLte}
    gRxlBNGPjKnafHqIMbpCVOScAkYLsD.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[]
  return gRxlBNGPjKnafHqIMbpCVOScAkYLsD
 def Get_BandLiveSection_List(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLsm,page_int=1):
  gRxlBNGPjKnafHqIMbpCVOScAkYLtU=[]
  gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLtr=1
  gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  try:
   (gRxlBNGPjKnafHqIMbpCVOScAkYLsT,gRxlBNGPjKnafHqIMbpCVOScAkYLvW)=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Baseapi_Parse(gRxlBNGPjKnafHqIMbpCVOScAkYLsm)
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[],gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW['limit']=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.LIST_LIMIT
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW['offset']=gRxlBNGPjKnafHqIMbpCVOScAkYLJt((page_int-1)*gRxlBNGPjKnafHqIMbpCVOScAkYLvu.LIST_LIMIT)
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if not('celllist' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']):return[],gRxlBNGPjKnafHqIMbpCVOScAkYLdm
   gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['celllist']
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLtv:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtW =gRxlBNGPjKnafHqIMbpCVOScAkYLts['event_list'][1]['url']
    gRxlBNGPjKnafHqIMbpCVOScAkYLth=urllib.parse.urlsplit(gRxlBNGPjKnafHqIMbpCVOScAkYLtW).query
    gRxlBNGPjKnafHqIMbpCVOScAkYLth=gRxlBNGPjKnafHqIMbpCVOScAkYLJd(urllib.parse.parse_qsl(gRxlBNGPjKnafHqIMbpCVOScAkYLth))
    gRxlBNGPjKnafHqIMbpCVOScAkYLtX='channelid'
    gRxlBNGPjKnafHqIMbpCVOScAkYLtF=gRxlBNGPjKnafHqIMbpCVOScAkYLth[gRxlBNGPjKnafHqIMbpCVOScAkYLtX]
    gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'studio':gRxlBNGPjKnafHqIMbpCVOScAkYLts['title_list'][0]['text'],'tvshowtitle':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_ChangeText(gRxlBNGPjKnafHqIMbpCVOScAkYLts['title_list'][1]['text']),'channelid':gRxlBNGPjKnafHqIMbpCVOScAkYLtF,'age':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('age'),'thumbnail':'https://%s'%gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('thumbnail')}
    gRxlBNGPjKnafHqIMbpCVOScAkYLtU.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
   gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['pagecount'])
   if gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['count']:gRxlBNGPjKnafHqIMbpCVOScAkYLtr =gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['count'])
   else:gRxlBNGPjKnafHqIMbpCVOScAkYLtr=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.LIST_LIMIT*page_int
   gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLtT>gRxlBNGPjKnafHqIMbpCVOScAkYLtr
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[],gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  return gRxlBNGPjKnafHqIMbpCVOScAkYLtU,gRxlBNGPjKnafHqIMbpCVOScAkYLtz
 def Get_Band2Section_List(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLsm,page_int=1):
  gRxlBNGPjKnafHqIMbpCVOScAkYLtE=[]
  gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLtr=1
  gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  try:
   (gRxlBNGPjKnafHqIMbpCVOScAkYLsT,gRxlBNGPjKnafHqIMbpCVOScAkYLvW)=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Baseapi_Parse(gRxlBNGPjKnafHqIMbpCVOScAkYLsm)
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[],gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW['came'] ='BandView'
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW['limit']=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.LIST_LIMIT
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW['offset']=gRxlBNGPjKnafHqIMbpCVOScAkYLJt((page_int-1)*gRxlBNGPjKnafHqIMbpCVOScAkYLvu.LIST_LIMIT)
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if not('celllist' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']):return[],gRxlBNGPjKnafHqIMbpCVOScAkYLdm
   gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['celllist']
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLtv:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtW =gRxlBNGPjKnafHqIMbpCVOScAkYLts['event_list'][1]['url']
    gRxlBNGPjKnafHqIMbpCVOScAkYLth=urllib.parse.urlsplit(gRxlBNGPjKnafHqIMbpCVOScAkYLtW).query
    gRxlBNGPjKnafHqIMbpCVOScAkYLth=gRxlBNGPjKnafHqIMbpCVOScAkYLJd(urllib.parse.parse_qsl(gRxlBNGPjKnafHqIMbpCVOScAkYLth))
    gRxlBNGPjKnafHqIMbpCVOScAkYLtX='contentid'
    gRxlBNGPjKnafHqIMbpCVOScAkYLtF=gRxlBNGPjKnafHqIMbpCVOScAkYLth[gRxlBNGPjKnafHqIMbpCVOScAkYLtX]
    gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'programtitle':gRxlBNGPjKnafHqIMbpCVOScAkYLts['title_list'][0]['text'],'episodetitle':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_ChangeText(gRxlBNGPjKnafHqIMbpCVOScAkYLts['title_list'][1]['text']),'age':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('age'),'thumbnail':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.HTTPTAG+gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('thumbnail'),'vidtype':gRxlBNGPjKnafHqIMbpCVOScAkYLtX,'videoid':gRxlBNGPjKnafHqIMbpCVOScAkYLtF}
    gRxlBNGPjKnafHqIMbpCVOScAkYLtE.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
   gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['pagecount'])
   if gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['count']:gRxlBNGPjKnafHqIMbpCVOScAkYLtr =gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['count'])
   else:gRxlBNGPjKnafHqIMbpCVOScAkYLtr=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.LIST_LIMIT*page_int
   gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLtT>gRxlBNGPjKnafHqIMbpCVOScAkYLtr
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[],gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  return gRxlBNGPjKnafHqIMbpCVOScAkYLtE,gRxlBNGPjKnafHqIMbpCVOScAkYLtz
 def Get_Program_List(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLsm,page_int=1,orderby='-'):
  gRxlBNGPjKnafHqIMbpCVOScAkYLti=[]
  gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLtr=1
  gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  (gRxlBNGPjKnafHqIMbpCVOScAkYLsT,gRxlBNGPjKnafHqIMbpCVOScAkYLvW)=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Baseapi_Parse(gRxlBNGPjKnafHqIMbpCVOScAkYLsm)
  if gRxlBNGPjKnafHqIMbpCVOScAkYLsT=='':return gRxlBNGPjKnafHqIMbpCVOScAkYLti,gRxlBNGPjKnafHqIMbpCVOScAkYLtz
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW['limit'] =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.LIST_LIMIT
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW['offset']=gRxlBNGPjKnafHqIMbpCVOScAkYLJt((page_int-1)*gRxlBNGPjKnafHqIMbpCVOScAkYLvu.LIST_LIMIT)
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW['page'] =gRxlBNGPjKnafHqIMbpCVOScAkYLJt(page_int)
   if gRxlBNGPjKnafHqIMbpCVOScAkYLvW.get('orderby')!='' and gRxlBNGPjKnafHqIMbpCVOScAkYLvW.get('orderby')!='regdatefirst' and orderby!='-':
    gRxlBNGPjKnafHqIMbpCVOScAkYLvW['orderby']=orderby 
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if gRxlBNGPjKnafHqIMbpCVOScAkYLsh.get('cell_toplist')not in[{},gRxlBNGPjKnafHqIMbpCVOScAkYLdD,'']:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['celllist']
   elif gRxlBNGPjKnafHqIMbpCVOScAkYLsh.get('band')not in[{},gRxlBNGPjKnafHqIMbpCVOScAkYLdD,'']:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['band']['celllist']
   else:
    return gRxlBNGPjKnafHqIMbpCVOScAkYLti,gRxlBNGPjKnafHqIMbpCVOScAkYLtz
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLtv:
    for gRxlBNGPjKnafHqIMbpCVOScAkYLty in gRxlBNGPjKnafHqIMbpCVOScAkYLts['event_list']:
     if gRxlBNGPjKnafHqIMbpCVOScAkYLty.get('type')=='on-navigation':
      gRxlBNGPjKnafHqIMbpCVOScAkYLtW =gRxlBNGPjKnafHqIMbpCVOScAkYLty['url']
    gRxlBNGPjKnafHqIMbpCVOScAkYLth=urllib.parse.urlsplit(gRxlBNGPjKnafHqIMbpCVOScAkYLtW).query
    gRxlBNGPjKnafHqIMbpCVOScAkYLtX=gRxlBNGPjKnafHqIMbpCVOScAkYLth[0:gRxlBNGPjKnafHqIMbpCVOScAkYLth.find('=')]
    gRxlBNGPjKnafHqIMbpCVOScAkYLtD=gRxlBNGPjKnafHqIMbpCVOScAkYLJd(urllib.parse.parse_qsl(gRxlBNGPjKnafHqIMbpCVOScAkYLth))
    gRxlBNGPjKnafHqIMbpCVOScAkYLtF=gRxlBNGPjKnafHqIMbpCVOScAkYLtD.get(gRxlBNGPjKnafHqIMbpCVOScAkYLtX)
    gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'title':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('alt')or gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('title_list')[0].get('text'),'age':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('age'),'thumbnail':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('thumbnail'),'videoid':gRxlBNGPjKnafHqIMbpCVOScAkYLtF,'vidtype':gRxlBNGPjKnafHqIMbpCVOScAkYLtX,}
    if not gRxlBNGPjKnafHqIMbpCVOScAkYLtu.get('thumbnail').startswith('http'):
     gRxlBNGPjKnafHqIMbpCVOScAkYLtu['thumbnail']='https://%s'%gRxlBNGPjKnafHqIMbpCVOScAkYLtu['thumbnail']
    gRxlBNGPjKnafHqIMbpCVOScAkYLti.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
   if gRxlBNGPjKnafHqIMbpCVOScAkYLsh.get('cell_toplist')not in[{},gRxlBNGPjKnafHqIMbpCVOScAkYLdD,'']:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['pagecount'])
    if gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['count']:gRxlBNGPjKnafHqIMbpCVOScAkYLtr =gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['count'])
    else:gRxlBNGPjKnafHqIMbpCVOScAkYLtr=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.LIST_LIMIT*page_int
    gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLtT>gRxlBNGPjKnafHqIMbpCVOScAkYLtr
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[],gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  return gRxlBNGPjKnafHqIMbpCVOScAkYLti,gRxlBNGPjKnafHqIMbpCVOScAkYLtz
 def Get_Movie_List(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLsm,page_int=1,orderby='-'):
  gRxlBNGPjKnafHqIMbpCVOScAkYLtm=[]
  gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLtr=1
  gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  (gRxlBNGPjKnafHqIMbpCVOScAkYLsT,gRxlBNGPjKnafHqIMbpCVOScAkYLvW)=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Baseapi_Parse(gRxlBNGPjKnafHqIMbpCVOScAkYLsm)
  if gRxlBNGPjKnafHqIMbpCVOScAkYLsT=='':return gRxlBNGPjKnafHqIMbpCVOScAkYLtm,gRxlBNGPjKnafHqIMbpCVOScAkYLtz
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW['limit']=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.MV_LIMIT
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW['offset']=gRxlBNGPjKnafHqIMbpCVOScAkYLJt((page_int-1)*gRxlBNGPjKnafHqIMbpCVOScAkYLvu.MV_LIMIT)
   if gRxlBNGPjKnafHqIMbpCVOScAkYLvW.get('orderby')!='' and gRxlBNGPjKnafHqIMbpCVOScAkYLvW.get('orderby')!='regdatefirst' and orderby!='-':
    gRxlBNGPjKnafHqIMbpCVOScAkYLvW['orderby']=orderby 
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if gRxlBNGPjKnafHqIMbpCVOScAkYLsh.get('cell_toplist')not in[{},gRxlBNGPjKnafHqIMbpCVOScAkYLdD,'']:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['celllist']
   elif gRxlBNGPjKnafHqIMbpCVOScAkYLsh.get('band')not in[{},gRxlBNGPjKnafHqIMbpCVOScAkYLdD,'']:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['band']['celllist']
   else:
    return gRxlBNGPjKnafHqIMbpCVOScAkYLtm,gRxlBNGPjKnafHqIMbpCVOScAkYLtz
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLtv:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtW =gRxlBNGPjKnafHqIMbpCVOScAkYLts['event_list'][1]['url']
    gRxlBNGPjKnafHqIMbpCVOScAkYLth=urllib.parse.urlsplit(gRxlBNGPjKnafHqIMbpCVOScAkYLtW).query
    gRxlBNGPjKnafHqIMbpCVOScAkYLtX=gRxlBNGPjKnafHqIMbpCVOScAkYLth[0:gRxlBNGPjKnafHqIMbpCVOScAkYLth.find('=')]
    gRxlBNGPjKnafHqIMbpCVOScAkYLtD=gRxlBNGPjKnafHqIMbpCVOScAkYLJd(urllib.parse.parse_qsl(gRxlBNGPjKnafHqIMbpCVOScAkYLth))
    gRxlBNGPjKnafHqIMbpCVOScAkYLtF=gRxlBNGPjKnafHqIMbpCVOScAkYLtD.get(gRxlBNGPjKnafHqIMbpCVOScAkYLtX)
    gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'title':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('alt')or gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('title_list')[0].get('text'),'age':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('age'),'thumbnail':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('thumbnail'),'videoid':gRxlBNGPjKnafHqIMbpCVOScAkYLtF,'vidtype':gRxlBNGPjKnafHqIMbpCVOScAkYLtX,}
    if not gRxlBNGPjKnafHqIMbpCVOScAkYLtu.get('thumbnail').startswith('http'):
     gRxlBNGPjKnafHqIMbpCVOScAkYLtu['thumbnail']='https://%s'%gRxlBNGPjKnafHqIMbpCVOScAkYLtu['thumbnail']
    gRxlBNGPjKnafHqIMbpCVOScAkYLtm.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
   if gRxlBNGPjKnafHqIMbpCVOScAkYLsh.get('cell_toplist')not in[{},gRxlBNGPjKnafHqIMbpCVOScAkYLdD,'']:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['pagecount'])
    if gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['count']:gRxlBNGPjKnafHqIMbpCVOScAkYLtr =gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['count'])
    else:gRxlBNGPjKnafHqIMbpCVOScAkYLtr=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.MV_LIMIT*page_int
    gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLtT>gRxlBNGPjKnafHqIMbpCVOScAkYLtr
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[],gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  return gRxlBNGPjKnafHqIMbpCVOScAkYLtm,gRxlBNGPjKnafHqIMbpCVOScAkYLtz
 def ProgramidToContentid(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLus):
  gRxlBNGPjKnafHqIMbpCVOScAkYLtw=''
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/vod/programs-contentid/'+gRxlBNGPjKnafHqIMbpCVOScAkYLus
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLuv=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if not('contentid' in gRxlBNGPjKnafHqIMbpCVOScAkYLuv):return gRxlBNGPjKnafHqIMbpCVOScAkYLtw 
   gRxlBNGPjKnafHqIMbpCVOScAkYLtw=gRxlBNGPjKnafHqIMbpCVOScAkYLuv['contentid']
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLtw
 def ContentidToSeasonid(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLtw):
  gRxlBNGPjKnafHqIMbpCVOScAkYLus=''
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/fz/vod/contents/'+gRxlBNGPjKnafHqIMbpCVOScAkYLtw
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLuv=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if not('programid' in gRxlBNGPjKnafHqIMbpCVOScAkYLuv):return gRxlBNGPjKnafHqIMbpCVOScAkYLus 
   gRxlBNGPjKnafHqIMbpCVOScAkYLus=gRxlBNGPjKnafHqIMbpCVOScAkYLuv['programid']
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLus
 def GetProgramInfo(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLtw):
  gRxlBNGPjKnafHqIMbpCVOScAkYLut={}
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/fz/vod/contents/'+gRxlBNGPjKnafHqIMbpCVOScAkYLtw
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLuv=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   gRxlBNGPjKnafHqIMbpCVOScAkYLuQ=img_fanart=gRxlBNGPjKnafHqIMbpCVOScAkYLuo=''
   if gRxlBNGPjKnafHqIMbpCVOScAkYLuv.get('programposterimage')!='':gRxlBNGPjKnafHqIMbpCVOScAkYLuQ =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.HTTPTAG+gRxlBNGPjKnafHqIMbpCVOScAkYLuv.get('programposterimage')
   if gRxlBNGPjKnafHqIMbpCVOScAkYLuv.get('programimage') !='':img_fanart =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.HTTPTAG+gRxlBNGPjKnafHqIMbpCVOScAkYLuv.get('programimage')
   if gRxlBNGPjKnafHqIMbpCVOScAkYLuv.get('programcircleimage')!='':gRxlBNGPjKnafHqIMbpCVOScAkYLuo=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.HTTPTAG+gRxlBNGPjKnafHqIMbpCVOScAkYLuv.get('programcircleimage')
   if 'poster_default' in gRxlBNGPjKnafHqIMbpCVOScAkYLuQ:
    gRxlBNGPjKnafHqIMbpCVOScAkYLuQ =img_fanart
    gRxlBNGPjKnafHqIMbpCVOScAkYLuo=''
   gRxlBNGPjKnafHqIMbpCVOScAkYLut={'imgPoster':gRxlBNGPjKnafHqIMbpCVOScAkYLuQ,'imgFanart':img_fanart,'imgClearlogo':gRxlBNGPjKnafHqIMbpCVOScAkYLuo,'programtitle':gRxlBNGPjKnafHqIMbpCVOScAkYLuv.get('programtitle'),'programid':gRxlBNGPjKnafHqIMbpCVOScAkYLuv.get('programid'),'synopsis':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_ChangeText(gRxlBNGPjKnafHqIMbpCVOScAkYLuv.get('programsynopsis')),}
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLut
 def Get_Season_List(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,seasonid):
  gRxlBNGPjKnafHqIMbpCVOScAkYLud=[]
  gRxlBNGPjKnafHqIMbpCVOScAkYLtw=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.ProgramidToContentid(seasonid)
  gRxlBNGPjKnafHqIMbpCVOScAkYLuJ=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetProgramInfo(gRxlBNGPjKnafHqIMbpCVOScAkYLtw)
  gRxlBNGPjKnafHqIMbpCVOScAkYLue={'poster':gRxlBNGPjKnafHqIMbpCVOScAkYLuJ.get('imgPoster'),'fanart':gRxlBNGPjKnafHqIMbpCVOScAkYLuJ.get('imgFanart'),'clearlogo':gRxlBNGPjKnafHqIMbpCVOScAkYLuJ.get('imgClearlogo'),}
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'limit':'10','offset':'0','orderby':'new',}
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   for gRxlBNGPjKnafHqIMbpCVOScAkYLuU in gRxlBNGPjKnafHqIMbpCVOScAkYLsh['filter']['filterlist'][0]['filter_item_list']:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'season_Nm':gRxlBNGPjKnafHqIMbpCVOScAkYLuU.get('title'),'season_Id':gRxlBNGPjKnafHqIMbpCVOScAkYLuU.get('api_path'),'thumbnail':gRxlBNGPjKnafHqIMbpCVOScAkYLue,'programNm':gRxlBNGPjKnafHqIMbpCVOScAkYLuJ.get('programtitle'),'synopsis':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_ChangeText(gRxlBNGPjKnafHqIMbpCVOScAkYLuJ.get('synopsis')),}
    gRxlBNGPjKnafHqIMbpCVOScAkYLud.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[]
  return gRxlBNGPjKnafHqIMbpCVOScAkYLud
 def Get_Episode_List(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,seasionid,page_int=1,orderby='desc'):
  gRxlBNGPjKnafHqIMbpCVOScAkYLuT=[]
  gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLtr=1
  gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  gRxlBNGPjKnafHqIMbpCVOScAkYLuJ={}
  gRxlBNGPjKnafHqIMbpCVOScAkYLtw=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.ProgramidToContentid(seasionid)
  gRxlBNGPjKnafHqIMbpCVOScAkYLuJ=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetProgramInfo(gRxlBNGPjKnafHqIMbpCVOScAkYLtw)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'limit':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.EP_LIMIT,'offset':gRxlBNGPjKnafHqIMbpCVOScAkYLJt((page_int-1)*gRxlBNGPjKnafHqIMbpCVOScAkYLvu.EP_LIMIT),'orderby':orderby,}
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['celllist']
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLtv:
    gRxlBNGPjKnafHqIMbpCVOScAkYLuW=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('synopsis'))
    gRxlBNGPjKnafHqIMbpCVOScAkYLuh=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.HTTPTAG+gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('thumbnail')
    gRxlBNGPjKnafHqIMbpCVOScAkYLuX=gRxlBNGPjKnafHqIMbpCVOScAkYLuF=gRxlBNGPjKnafHqIMbpCVOScAkYLur=''
    gRxlBNGPjKnafHqIMbpCVOScAkYLuX =gRxlBNGPjKnafHqIMbpCVOScAkYLuJ.get('imgPoster')
    gRxlBNGPjKnafHqIMbpCVOScAkYLuF =gRxlBNGPjKnafHqIMbpCVOScAkYLuJ.get('imgFanart')
    gRxlBNGPjKnafHqIMbpCVOScAkYLur =gRxlBNGPjKnafHqIMbpCVOScAkYLuJ.get('imgClearlogo')
    gRxlBNGPjKnafHqIMbpCVOScAkYLuE=gRxlBNGPjKnafHqIMbpCVOScAkYLuJ.get('programtitle')
    gRxlBNGPjKnafHqIMbpCVOScAkYLue={'thumb':gRxlBNGPjKnafHqIMbpCVOScAkYLuh,'poster':gRxlBNGPjKnafHqIMbpCVOScAkYLuX,'fanart':gRxlBNGPjKnafHqIMbpCVOScAkYLuF,'clearlogo':gRxlBNGPjKnafHqIMbpCVOScAkYLur}
    gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'programtitle':gRxlBNGPjKnafHqIMbpCVOScAkYLuE,'episodetitle':gRxlBNGPjKnafHqIMbpCVOScAkYLts['title_list'][0]['text'],'episodenumber':gRxlBNGPjKnafHqIMbpCVOScAkYLts['title_list'][1]['text'].replace('$O$',''),'contentid':gRxlBNGPjKnafHqIMbpCVOScAkYLts['contentid'],'synopsis':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_ChangeText(gRxlBNGPjKnafHqIMbpCVOScAkYLuW),'episodeactors':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('actors').split(',')if gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('actors')!='' else[],'thumbnail':gRxlBNGPjKnafHqIMbpCVOScAkYLue,}
    gRxlBNGPjKnafHqIMbpCVOScAkYLuT.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
   gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['pagecount'])
   if gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['count']:gRxlBNGPjKnafHqIMbpCVOScAkYLtr =gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['count'])
   else:gRxlBNGPjKnafHqIMbpCVOScAkYLtr=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.EP_LIMIT*page_int
   gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLtT>gRxlBNGPjKnafHqIMbpCVOScAkYLtr
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[],gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  return gRxlBNGPjKnafHqIMbpCVOScAkYLuT,gRxlBNGPjKnafHqIMbpCVOScAkYLtz
 def GetEPGList(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,genre):
  gRxlBNGPjKnafHqIMbpCVOScAkYLui={}
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLuy=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_Now_Datetime()
   if genre=='all':
    gRxlBNGPjKnafHqIMbpCVOScAkYLuD =gRxlBNGPjKnafHqIMbpCVOScAkYLuy+datetime.timedelta(hours=3)
   else:
    gRxlBNGPjKnafHqIMbpCVOScAkYLuD =gRxlBNGPjKnafHqIMbpCVOScAkYLuy+datetime.timedelta(hours=3)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/live/epgs'
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'limit':'100','offset':'0','genre':genre,'startdatetime':gRxlBNGPjKnafHqIMbpCVOScAkYLuy.strftime('%Y-%m-%d %H:00'),'enddatetime':gRxlBNGPjKnafHqIMbpCVOScAkYLuD.strftime('%Y-%m-%d %H:00')}
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   gRxlBNGPjKnafHqIMbpCVOScAkYLum=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['list']
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLum:
    gRxlBNGPjKnafHqIMbpCVOScAkYLuw=''
    for gRxlBNGPjKnafHqIMbpCVOScAkYLQv in gRxlBNGPjKnafHqIMbpCVOScAkYLts['list']:
     if gRxlBNGPjKnafHqIMbpCVOScAkYLuw:gRxlBNGPjKnafHqIMbpCVOScAkYLuw+='\n'
     gRxlBNGPjKnafHqIMbpCVOScAkYLuw+=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_ChangeText(gRxlBNGPjKnafHqIMbpCVOScAkYLQv['title'])+'\n'
     gRxlBNGPjKnafHqIMbpCVOScAkYLuw+=' [%s ~ %s]'%(gRxlBNGPjKnafHqIMbpCVOScAkYLQv['starttime'][-5:],gRxlBNGPjKnafHqIMbpCVOScAkYLQv['endtime'][-5:])+'\n'
    gRxlBNGPjKnafHqIMbpCVOScAkYLui[gRxlBNGPjKnafHqIMbpCVOScAkYLts['channelid']]=gRxlBNGPjKnafHqIMbpCVOScAkYLuw
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLui
 def Get_LiveChannel_List(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,genre,gRxlBNGPjKnafHqIMbpCVOScAkYLsm):
  gRxlBNGPjKnafHqIMbpCVOScAkYLtU=[]
  (gRxlBNGPjKnafHqIMbpCVOScAkYLsT,gRxlBNGPjKnafHqIMbpCVOScAkYLvW)=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Baseapi_Parse(gRxlBNGPjKnafHqIMbpCVOScAkYLsm)
  if gRxlBNGPjKnafHqIMbpCVOScAkYLsT=='':return gRxlBNGPjKnafHqIMbpCVOScAkYLtU
  gRxlBNGPjKnafHqIMbpCVOScAkYLQs=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetEPGList(genre)
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW['genre']=genre
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if not('celllist' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']):return[]
   gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['celllist']
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLtv:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtw=gRxlBNGPjKnafHqIMbpCVOScAkYLts['contentid']
    if gRxlBNGPjKnafHqIMbpCVOScAkYLtw in gRxlBNGPjKnafHqIMbpCVOScAkYLQs:
     gRxlBNGPjKnafHqIMbpCVOScAkYLQt=gRxlBNGPjKnafHqIMbpCVOScAkYLQs[gRxlBNGPjKnafHqIMbpCVOScAkYLtw]
    else:
     gRxlBNGPjKnafHqIMbpCVOScAkYLQt=''
    gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'studio':gRxlBNGPjKnafHqIMbpCVOScAkYLts['title_list'][0]['text'],'tvshowtitle':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_ChangeText(gRxlBNGPjKnafHqIMbpCVOScAkYLts['title_list'][1]['text']),'channelid':gRxlBNGPjKnafHqIMbpCVOScAkYLtw,'age':gRxlBNGPjKnafHqIMbpCVOScAkYLts['age'],'thumbnail':'https://%s'%gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('thumbnail'),'epg':gRxlBNGPjKnafHqIMbpCVOScAkYLQt}
    gRxlBNGPjKnafHqIMbpCVOScAkYLtU.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[]
  return gRxlBNGPjKnafHqIMbpCVOScAkYLtU
 def Get_Search_List(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,search_key,sType,page_int,exclusion21=gRxlBNGPjKnafHqIMbpCVOScAkYLdm):
  gRxlBNGPjKnafHqIMbpCVOScAkYLQu=[]
  gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLtr=1
  gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/fz/search/band.js'
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':gRxlBNGPjKnafHqIMbpCVOScAkYLJt((page_int-1)*gRxlBNGPjKnafHqIMbpCVOScAkYLvu.SEARCH_LIMIT),'limit':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLuv=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if not('celllist' in gRxlBNGPjKnafHqIMbpCVOScAkYLuv['band']):return gRxlBNGPjKnafHqIMbpCVOScAkYLQu,gRxlBNGPjKnafHqIMbpCVOScAkYLtz
   gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLuv['band']['celllist']
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLtv:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtW =gRxlBNGPjKnafHqIMbpCVOScAkYLts['event_list'][1]['url']
    gRxlBNGPjKnafHqIMbpCVOScAkYLth=urllib.parse.urlsplit(gRxlBNGPjKnafHqIMbpCVOScAkYLtW).query
    gRxlBNGPjKnafHqIMbpCVOScAkYLtX=gRxlBNGPjKnafHqIMbpCVOScAkYLth[0:gRxlBNGPjKnafHqIMbpCVOScAkYLth.find('=')]
    gRxlBNGPjKnafHqIMbpCVOScAkYLtD=gRxlBNGPjKnafHqIMbpCVOScAkYLJd(urllib.parse.parse_qsl(gRxlBNGPjKnafHqIMbpCVOScAkYLth))
    gRxlBNGPjKnafHqIMbpCVOScAkYLtF=gRxlBNGPjKnafHqIMbpCVOScAkYLtD.get(gRxlBNGPjKnafHqIMbpCVOScAkYLtX)
    gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'title':gRxlBNGPjKnafHqIMbpCVOScAkYLts['title_list'][0]['text'],'age':gRxlBNGPjKnafHqIMbpCVOScAkYLts['age'],'thumbnail':'https://%s'%gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('thumbnail'),'videoid':gRxlBNGPjKnafHqIMbpCVOScAkYLtF,'vidtype':gRxlBNGPjKnafHqIMbpCVOScAkYLtX,}
    gRxlBNGPjKnafHqIMbpCVOScAkYLQo=gRxlBNGPjKnafHqIMbpCVOScAkYLdm
    for gRxlBNGPjKnafHqIMbpCVOScAkYLQd in gRxlBNGPjKnafHqIMbpCVOScAkYLts['bottom_taglist']:
     if gRxlBNGPjKnafHqIMbpCVOScAkYLQd=='won':
      gRxlBNGPjKnafHqIMbpCVOScAkYLQo=gRxlBNGPjKnafHqIMbpCVOScAkYLJv
      break
    if gRxlBNGPjKnafHqIMbpCVOScAkYLQo==gRxlBNGPjKnafHqIMbpCVOScAkYLJv: 
     gRxlBNGPjKnafHqIMbpCVOScAkYLtu['title']=gRxlBNGPjKnafHqIMbpCVOScAkYLtu['title']+' [개별구매]'
    if exclusion21==gRxlBNGPjKnafHqIMbpCVOScAkYLdm or gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('age')!='21':
     gRxlBNGPjKnafHqIMbpCVOScAkYLQu.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
   gRxlBNGPjKnafHqIMbpCVOScAkYLtT=gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLuv['band']['pagecount'])
   if gRxlBNGPjKnafHqIMbpCVOScAkYLuv['band']['count']:gRxlBNGPjKnafHqIMbpCVOScAkYLtr =gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLuv['band']['count'])
   else:gRxlBNGPjKnafHqIMbpCVOScAkYLtr=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.LIST_LIMIT
   gRxlBNGPjKnafHqIMbpCVOScAkYLtz=gRxlBNGPjKnafHqIMbpCVOScAkYLtT>gRxlBNGPjKnafHqIMbpCVOScAkYLtr
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLQu,gRxlBNGPjKnafHqIMbpCVOScAkYLtz 
 def GetSecureToken(gRxlBNGPjKnafHqIMbpCVOScAkYLvu):
  gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/ip'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm)
  gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
  gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLsh['securetoken']
 def Wavve_Parse_m3u8(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLoJ):
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsJ={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=requests.get(url=gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_url'],headers=gRxlBNGPjKnafHqIMbpCVOScAkYLsJ,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_cookie'])
   gRxlBNGPjKnafHqIMbpCVOScAkYLQJ=gRxlBNGPjKnafHqIMbpCVOScAkYLsW.content.decode('utf-8')
   if '#EXTM3U' not in gRxlBNGPjKnafHqIMbpCVOScAkYLQJ:
    return gRxlBNGPjKnafHqIMbpCVOScAkYLdm
   if '#EXT-X-STREAM-INF' not in gRxlBNGPjKnafHqIMbpCVOScAkYLQJ: 
    return gRxlBNGPjKnafHqIMbpCVOScAkYLdm
   gRxlBNGPjKnafHqIMbpCVOScAkYLQe=0
   for gRxlBNGPjKnafHqIMbpCVOScAkYLQU in gRxlBNGPjKnafHqIMbpCVOScAkYLQJ.splitlines():
    if gRxlBNGPjKnafHqIMbpCVOScAkYLQU.startswith('#EXT-X-STREAM-INF'):
     gRxlBNGPjKnafHqIMbpCVOScAkYLQT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.MediaLine_Parse(gRxlBNGPjKnafHqIMbpCVOScAkYLQU,'#EXT-X-STREAM-INF')
     if gRxlBNGPjKnafHqIMbpCVOScAkYLQe<gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLQT.get('BANDWIDTH')):
      gRxlBNGPjKnafHqIMbpCVOScAkYLQe=gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLQT.get('BANDWIDTH'))
   gRxlBNGPjKnafHqIMbpCVOScAkYLQz=[]
   gRxlBNGPjKnafHqIMbpCVOScAkYLQW=gRxlBNGPjKnafHqIMbpCVOScAkYLdm
   for gRxlBNGPjKnafHqIMbpCVOScAkYLQU in gRxlBNGPjKnafHqIMbpCVOScAkYLQJ.splitlines():
    if gRxlBNGPjKnafHqIMbpCVOScAkYLQW==gRxlBNGPjKnafHqIMbpCVOScAkYLJv:
     gRxlBNGPjKnafHqIMbpCVOScAkYLQW=gRxlBNGPjKnafHqIMbpCVOScAkYLdm
     continue
    if gRxlBNGPjKnafHqIMbpCVOScAkYLQU.startswith('#EXT-X-STREAM-INF'):
     gRxlBNGPjKnafHqIMbpCVOScAkYLQT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.MediaLine_Parse(gRxlBNGPjKnafHqIMbpCVOScAkYLQU,'#EXT-X-STREAM-INF')
     if gRxlBNGPjKnafHqIMbpCVOScAkYLQe!=gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLQT.get('BANDWIDTH')):
      gRxlBNGPjKnafHqIMbpCVOScAkYLQW=gRxlBNGPjKnafHqIMbpCVOScAkYLJv
      continue
    gRxlBNGPjKnafHqIMbpCVOScAkYLQz.append(gRxlBNGPjKnafHqIMbpCVOScAkYLQU)
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return gRxlBNGPjKnafHqIMbpCVOScAkYLdm
  gRxlBNGPjKnafHqIMbpCVOScAkYLQh='\n'.join(gRxlBNGPjKnafHqIMbpCVOScAkYLQz)
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.TextFile_Save(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV_STREAM_FILENAME,gRxlBNGPjKnafHqIMbpCVOScAkYLQh)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLJv
 def Wavve_Parse_mpd(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLoJ):
  gRxlBNGPjKnafHqIMbpCVOScAkYLsJ={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  gRxlBNGPjKnafHqIMbpCVOScAkYLsW=requests.get(url=gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_url'],headers=gRxlBNGPjKnafHqIMbpCVOScAkYLsJ,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_cookie'])
  gRxlBNGPjKnafHqIMbpCVOScAkYLQX=gRxlBNGPjKnafHqIMbpCVOScAkYLsW.content.decode('utf-8')
  gRxlBNGPjKnafHqIMbpCVOScAkYLQF =ET.ElementTree(ET.fromstring(gRxlBNGPjKnafHqIMbpCVOScAkYLQX))
  gRxlBNGPjKnafHqIMbpCVOScAkYLQr =gRxlBNGPjKnafHqIMbpCVOScAkYLQF.getroot()
  gRxlBNGPjKnafHqIMbpCVOScAkYLQE=re.match(r'\{.*\}',gRxlBNGPjKnafHqIMbpCVOScAkYLQr.tag)[0] 
  gRxlBNGPjKnafHqIMbpCVOScAkYLQi=gRxlBNGPjKnafHqIMbpCVOScAkYLJd([node for _,node in ET.iterparse(io.StringIO(gRxlBNGPjKnafHqIMbpCVOScAkYLQX),events=['start-ns'])])
  for gRxlBNGPjKnafHqIMbpCVOScAkYLso,gRxlBNGPjKnafHqIMbpCVOScAkYLod in gRxlBNGPjKnafHqIMbpCVOScAkYLQi.items():
   ET.register_namespace(gRxlBNGPjKnafHqIMbpCVOScAkYLso,gRxlBNGPjKnafHqIMbpCVOScAkYLod)
  gRxlBNGPjKnafHqIMbpCVOScAkYLQy=gRxlBNGPjKnafHqIMbpCVOScAkYLQr.find(gRxlBNGPjKnafHqIMbpCVOScAkYLQE+'Period')
  for gRxlBNGPjKnafHqIMbpCVOScAkYLQD in gRxlBNGPjKnafHqIMbpCVOScAkYLQy.findall(gRxlBNGPjKnafHqIMbpCVOScAkYLQE+'AdaptationSet'):
   if gRxlBNGPjKnafHqIMbpCVOScAkYLQD.attrib.get('mimeType')=='video/mp4':
    gRxlBNGPjKnafHqIMbpCVOScAkYLQm=0
    for gRxlBNGPjKnafHqIMbpCVOScAkYLQw in gRxlBNGPjKnafHqIMbpCVOScAkYLQD.findall(gRxlBNGPjKnafHqIMbpCVOScAkYLQE+'Representation'):
     gRxlBNGPjKnafHqIMbpCVOScAkYLov=gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLQw.attrib.get('bandwidth'))
     if gRxlBNGPjKnafHqIMbpCVOScAkYLQm<gRxlBNGPjKnafHqIMbpCVOScAkYLov:gRxlBNGPjKnafHqIMbpCVOScAkYLQm=gRxlBNGPjKnafHqIMbpCVOScAkYLov
    for gRxlBNGPjKnafHqIMbpCVOScAkYLQw in gRxlBNGPjKnafHqIMbpCVOScAkYLQD.findall(gRxlBNGPjKnafHqIMbpCVOScAkYLQE+'Representation'):
     if gRxlBNGPjKnafHqIMbpCVOScAkYLQm>gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLQw.attrib.get('bandwidth')):
      gRxlBNGPjKnafHqIMbpCVOScAkYLQD.remove(gRxlBNGPjKnafHqIMbpCVOScAkYLQw)
   elif gRxlBNGPjKnafHqIMbpCVOScAkYLQD.attrib.get('mimeType')=='audio/mp4':
    gRxlBNGPjKnafHqIMbpCVOScAkYLQm=0
    for gRxlBNGPjKnafHqIMbpCVOScAkYLQw in gRxlBNGPjKnafHqIMbpCVOScAkYLQD.findall(gRxlBNGPjKnafHqIMbpCVOScAkYLQE+'Representation'):
     gRxlBNGPjKnafHqIMbpCVOScAkYLov=gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLQw.attrib.get('bandwidth'))
     if gRxlBNGPjKnafHqIMbpCVOScAkYLQm<gRxlBNGPjKnafHqIMbpCVOScAkYLov:gRxlBNGPjKnafHqIMbpCVOScAkYLQm=gRxlBNGPjKnafHqIMbpCVOScAkYLov
    for gRxlBNGPjKnafHqIMbpCVOScAkYLQw in gRxlBNGPjKnafHqIMbpCVOScAkYLQD.findall(gRxlBNGPjKnafHqIMbpCVOScAkYLQE+'Representation'):
     if gRxlBNGPjKnafHqIMbpCVOScAkYLQm>gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLQw.attrib.get('bandwidth')):
      gRxlBNGPjKnafHqIMbpCVOScAkYLQD.remove(gRxlBNGPjKnafHqIMbpCVOScAkYLQw)
   else:
    continue
  gRxlBNGPjKnafHqIMbpCVOScAkYLos=ET.tostring(gRxlBNGPjKnafHqIMbpCVOScAkYLQr).decode('utf-8')
  gRxlBNGPjKnafHqIMbpCVOScAkYLot='<?xml version="1.0" encoding="UTF-8"?>\n'
  gRxlBNGPjKnafHqIMbpCVOScAkYLvu.TextFile_Save(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV_STREAM_FILENAME,gRxlBNGPjKnafHqIMbpCVOScAkYLot+gRxlBNGPjKnafHqIMbpCVOScAkYLos)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLJv
 def MediaLine_Parse(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLQU,prefix):
  gRxlBNGPjKnafHqIMbpCVOScAkYLQT={}
  for gRxlBNGPjKnafHqIMbpCVOScAkYLou in gRxlBNGPjKnafHqIMbpCVOScAkYLvt.split(gRxlBNGPjKnafHqIMbpCVOScAkYLQU.replace(prefix+':',''))[1::2]:
   gRxlBNGPjKnafHqIMbpCVOScAkYLoQ,gRxlBNGPjKnafHqIMbpCVOScAkYLod=gRxlBNGPjKnafHqIMbpCVOScAkYLou.split('=',1)
   gRxlBNGPjKnafHqIMbpCVOScAkYLQT[gRxlBNGPjKnafHqIMbpCVOScAkYLoQ.upper()]=gRxlBNGPjKnafHqIMbpCVOScAkYLod.replace('"','').strip()
  return gRxlBNGPjKnafHqIMbpCVOScAkYLQT
 def GetStreamingURL(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,mode,gRxlBNGPjKnafHqIMbpCVOScAkYLtw,quality_int,pvrmode='-',playOption={}):
  gRxlBNGPjKnafHqIMbpCVOScAkYLoJ ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  gRxlBNGPjKnafHqIMbpCVOScAkYLoe=[]
  if mode=='LIVE':
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/live/channels/'+gRxlBNGPjKnafHqIMbpCVOScAkYLtw
   gRxlBNGPjKnafHqIMbpCVOScAkYLoU='live'
  elif mode=='VOD':
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/fz/vod/contents-detail/'+gRxlBNGPjKnafHqIMbpCVOScAkYLtw 
   gRxlBNGPjKnafHqIMbpCVOScAkYLoU='vod'
  elif mode=='MOVIE':
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/fz/movie/contents/'+gRxlBNGPjKnafHqIMbpCVOScAkYLtw
   gRxlBNGPjKnafHqIMbpCVOScAkYLoU='movie'
  gRxlBNGPjKnafHqIMbpCVOScAkYLoT={'hdr':'sdr','uhd':'-',}
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   gRxlBNGPjKnafHqIMbpCVOScAkYLoz=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['qualities']['list']
   if gRxlBNGPjKnafHqIMbpCVOScAkYLoz==gRxlBNGPjKnafHqIMbpCVOScAkYLdD:return gRxlBNGPjKnafHqIMbpCVOScAkYLoJ
   for gRxlBNGPjKnafHqIMbpCVOScAkYLoW in gRxlBNGPjKnafHqIMbpCVOScAkYLoz:
    gRxlBNGPjKnafHqIMbpCVOScAkYLoe.append(gRxlBNGPjKnafHqIMbpCVOScAkYLJe(gRxlBNGPjKnafHqIMbpCVOScAkYLoW.get('id').rstrip('p')))
   if 'type' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh:
    if gRxlBNGPjKnafHqIMbpCVOScAkYLsh['type']=='onair':
     gRxlBNGPjKnafHqIMbpCVOScAkYLoU='onairvod'
   if 'drms' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh:
    if gRxlBNGPjKnafHqIMbpCVOScAkYLsh['drms']:
     gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh.get('qualities'):
     for gRxlBNGPjKnafHqIMbpCVOScAkYLoh in gRxlBNGPjKnafHqIMbpCVOScAkYLsh.get('qualities').get('mediatypes'):
      if gRxlBNGPjKnafHqIMbpCVOScAkYLoh=='HDR10':
       gRxlBNGPjKnafHqIMbpCVOScAkYLoT['hdr']='hdr'
       gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for gRxlBNGPjKnafHqIMbpCVOScAkYLoh in gRxlBNGPjKnafHqIMbpCVOScAkYLsh.get('qualities').get('list'):
     if gRxlBNGPjKnafHqIMbpCVOScAkYLoh.get('name')=='UHD':
      gRxlBNGPjKnafHqIMbpCVOScAkYLoT['uhd']='uhd'
      break
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return gRxlBNGPjKnafHqIMbpCVOScAkYLoJ
  gRxlBNGPjKnafHqIMbpCVOScAkYLJo('stream_action : '+gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_action'])
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLoX=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.CheckQuality(quality_int,gRxlBNGPjKnafHqIMbpCVOScAkYLoe)
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(gRxlBNGPjKnafHqIMbpCVOScAkYLoX)
   if gRxlBNGPjKnafHqIMbpCVOScAkYLoX<1080:
    gRxlBNGPjKnafHqIMbpCVOScAkYLoT['uhd']='-'
    gRxlBNGPjKnafHqIMbpCVOScAkYLoT['hdr']='sdr'
   if gRxlBNGPjKnafHqIMbpCVOScAkYLoT['uhd']=='uhd':gRxlBNGPjKnafHqIMbpCVOScAkYLoX=2160 
   gRxlBNGPjKnafHqIMbpCVOScAkYLoF=gRxlBNGPjKnafHqIMbpCVOScAkYLJt(gRxlBNGPjKnafHqIMbpCVOScAkYLoX)+'p'
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(gRxlBNGPjKnafHqIMbpCVOScAkYLoF)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/fz/streaming'
   if gRxlBNGPjKnafHqIMbpCVOScAkYLoT['hdr']=='hdr' or gRxlBNGPjKnafHqIMbpCVOScAkYLoT['uhd']=='uhd':
    gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'contentid':gRxlBNGPjKnafHqIMbpCVOScAkYLtw,'contenttype':gRxlBNGPjKnafHqIMbpCVOScAkYLoU,'quality':gRxlBNGPjKnafHqIMbpCVOScAkYLoF,'modelid':'SHIELD Android TV','guid':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams_AND())
   else:
    gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'contentid':gRxlBNGPjKnafHqIMbpCVOScAkYLtw,'contenttype':gRxlBNGPjKnafHqIMbpCVOScAkYLoU,'quality':gRxlBNGPjKnafHqIMbpCVOScAkYLoF,'deviceModelId':'Windows 10','guid':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_action'],'protocol':gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLJv))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_url']=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['playurl']
   if gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_url']==gRxlBNGPjKnafHqIMbpCVOScAkYLdD:return gRxlBNGPjKnafHqIMbpCVOScAkYLoJ
   gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_cookie']=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.make_str_ToCookie(gRxlBNGPjKnafHqIMbpCVOScAkYLsh['awscookie'])
   gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_drm'] =gRxlBNGPjKnafHqIMbpCVOScAkYLsh['drm']
   if 'previewmsg' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh['preview']:gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_preview']=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['preview']['previewmsg']
   if 'subtitles' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh:
    for gRxlBNGPjKnafHqIMbpCVOScAkYLor in gRxlBNGPjKnafHqIMbpCVOScAkYLsh['subtitles']:
     if gRxlBNGPjKnafHqIMbpCVOScAkYLor.get('languagecode')=='ko':
      gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_vtt']=gRxlBNGPjKnafHqIMbpCVOScAkYLor.get('url')
      break
    if gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_vtt']=='':
     for gRxlBNGPjKnafHqIMbpCVOScAkYLor in gRxlBNGPjKnafHqIMbpCVOScAkYLsh['subtitles']:
      if gRxlBNGPjKnafHqIMbpCVOScAkYLor.get('languagecode')=='ko_cc':
       gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_vtt']=gRxlBNGPjKnafHqIMbpCVOScAkYLor.get('url')
       break
   gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['playParam']=gRxlBNGPjKnafHqIMbpCVOScAkYLoT 
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLoJ 
 def GetSportsURL(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLtw,quality_int):
  gRxlBNGPjKnafHqIMbpCVOScAkYLoJ ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  gRxlBNGPjKnafHqIMbpCVOScAkYLoe=[]
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/streaming/other'
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'contentid':gRxlBNGPjKnafHqIMbpCVOScAkYLtw,'contenttype':'live','action':gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_action'],'quality':gRxlBNGPjKnafHqIMbpCVOScAkYLJt(quality_int)+'p','deviceModelId':'Windows 10','guid':gRxlBNGPjKnafHqIMbpCVOScAkYLvu.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLJv))
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_url']=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['playurl']
   if gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_url']==gRxlBNGPjKnafHqIMbpCVOScAkYLdD:return gRxlBNGPjKnafHqIMbpCVOScAkYLoJ
   gRxlBNGPjKnafHqIMbpCVOScAkYLoJ['stream_cookie']=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['awscookie']
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLoJ
 def make_viewdate(gRxlBNGPjKnafHqIMbpCVOScAkYLvu):
  gRxlBNGPjKnafHqIMbpCVOScAkYLoE =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_Now_Datetime()
  gRxlBNGPjKnafHqIMbpCVOScAkYLoi =gRxlBNGPjKnafHqIMbpCVOScAkYLoE+datetime.timedelta(days=-1)
  gRxlBNGPjKnafHqIMbpCVOScAkYLoy =gRxlBNGPjKnafHqIMbpCVOScAkYLoE+datetime.timedelta(days=1)
  gRxlBNGPjKnafHqIMbpCVOScAkYLoD=[gRxlBNGPjKnafHqIMbpCVOScAkYLoE.strftime('%Y%m%d'),gRxlBNGPjKnafHqIMbpCVOScAkYLoy.strftime('%Y%m%d'),]
  return gRxlBNGPjKnafHqIMbpCVOScAkYLoD
 def Get_Sports_Gamelist(gRxlBNGPjKnafHqIMbpCVOScAkYLvu):
  gRxlBNGPjKnafHqIMbpCVOScAkYLom =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.make_viewdate()
  gRxlBNGPjKnafHqIMbpCVOScAkYLow=[]
  gRxlBNGPjKnafHqIMbpCVOScAkYLdv =[]
  for gRxlBNGPjKnafHqIMbpCVOScAkYLds in gRxlBNGPjKnafHqIMbpCVOScAkYLom:
   gRxlBNGPjKnafHqIMbpCVOScAkYLdt=gRxlBNGPjKnafHqIMbpCVOScAkYLds[:6]
   if gRxlBNGPjKnafHqIMbpCVOScAkYLdt not in gRxlBNGPjKnafHqIMbpCVOScAkYLow:
    gRxlBNGPjKnafHqIMbpCVOScAkYLow.append(gRxlBNGPjKnafHqIMbpCVOScAkYLdt)
  try:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW.update(gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm))
   for gRxlBNGPjKnafHqIMbpCVOScAkYLdu in gRxlBNGPjKnafHqIMbpCVOScAkYLow:
    gRxlBNGPjKnafHqIMbpCVOScAkYLvW['date']=gRxlBNGPjKnafHqIMbpCVOScAkYLdu
    gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
    gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
    gRxlBNGPjKnafHqIMbpCVOScAkYLtv=gRxlBNGPjKnafHqIMbpCVOScAkYLsh['cell_toplist']['celllist']
    for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLtv:
     gRxlBNGPjKnafHqIMbpCVOScAkYLdQ=gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('game_date')
     gRxlBNGPjKnafHqIMbpCVOScAkYLdo =gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('svc_id')
     if gRxlBNGPjKnafHqIMbpCVOScAkYLdo=='':continue
     if gRxlBNGPjKnafHqIMbpCVOScAkYLdQ in gRxlBNGPjKnafHqIMbpCVOScAkYLom:
      gRxlBNGPjKnafHqIMbpCVOScAkYLdJ=gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('game_status') 
      gRxlBNGPjKnafHqIMbpCVOScAkYLde =gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('title_list')[0].get('text')
      gRxlBNGPjKnafHqIMbpCVOScAkYLdQ =gRxlBNGPjKnafHqIMbpCVOScAkYLdQ[:4]+'-'+gRxlBNGPjKnafHqIMbpCVOScAkYLdQ[4:6]+'-'+gRxlBNGPjKnafHqIMbpCVOScAkYLdQ[-2:]
      gRxlBNGPjKnafHqIMbpCVOScAkYLdU =gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('game_time')
      gRxlBNGPjKnafHqIMbpCVOScAkYLdU =gRxlBNGPjKnafHqIMbpCVOScAkYLdU[:2]+':'+gRxlBNGPjKnafHqIMbpCVOScAkYLdU[-2:]
      gRxlBNGPjKnafHqIMbpCVOScAkYLtu={'game_date':gRxlBNGPjKnafHqIMbpCVOScAkYLdQ,'game_time':gRxlBNGPjKnafHqIMbpCVOScAkYLdU,'svc_id':gRxlBNGPjKnafHqIMbpCVOScAkYLdo,'away_team':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('away_team').get('team_name'),'home_team':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('home_team').get('team_name'),'game_status':gRxlBNGPjKnafHqIMbpCVOScAkYLdJ,'game_place':gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('game_place'),}
      gRxlBNGPjKnafHqIMbpCVOScAkYLdv.append(gRxlBNGPjKnafHqIMbpCVOScAkYLtu)
  except gRxlBNGPjKnafHqIMbpCVOScAkYLJQ as exception:
   gRxlBNGPjKnafHqIMbpCVOScAkYLJo(exception)
   return[]
  gRxlBNGPjKnafHqIMbpCVOScAkYLdT=[]
  for i in gRxlBNGPjKnafHqIMbpCVOScAkYLJs(2):
   for gRxlBNGPjKnafHqIMbpCVOScAkYLts in gRxlBNGPjKnafHqIMbpCVOScAkYLdv:
    if i==0 and gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('game_status')=='LIVE':
     gRxlBNGPjKnafHqIMbpCVOScAkYLdT.append(gRxlBNGPjKnafHqIMbpCVOScAkYLts)
    elif i==1 and gRxlBNGPjKnafHqIMbpCVOScAkYLts.get('game_status')!='LIVE':
     gRxlBNGPjKnafHqIMbpCVOScAkYLdT.append(gRxlBNGPjKnafHqIMbpCVOScAkYLts)
  return gRxlBNGPjKnafHqIMbpCVOScAkYLdT
 def GetBookmarkInfo(gRxlBNGPjKnafHqIMbpCVOScAkYLvu,gRxlBNGPjKnafHqIMbpCVOScAkYLtF,gRxlBNGPjKnafHqIMbpCVOScAkYLtX,gRxlBNGPjKnafHqIMbpCVOScAkYLoU):
  if gRxlBNGPjKnafHqIMbpCVOScAkYLtX=='tvshow':
   if gRxlBNGPjKnafHqIMbpCVOScAkYLoU=='contentid':
    gRxlBNGPjKnafHqIMbpCVOScAkYLtw=gRxlBNGPjKnafHqIMbpCVOScAkYLtF
    gRxlBNGPjKnafHqIMbpCVOScAkYLtF =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.ContentidToSeasonid(gRxlBNGPjKnafHqIMbpCVOScAkYLtw)
   else:
    gRxlBNGPjKnafHqIMbpCVOScAkYLtw=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.ProgramidToContentid(gRxlBNGPjKnafHqIMbpCVOScAkYLtF)
  else:
   gRxlBNGPjKnafHqIMbpCVOScAkYLtw=''
  gRxlBNGPjKnafHqIMbpCVOScAkYLdz={'indexinfo':{'ott':'wavve','videoid':gRxlBNGPjKnafHqIMbpCVOScAkYLtF,'vidtype':gRxlBNGPjKnafHqIMbpCVOScAkYLtX,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':gRxlBNGPjKnafHqIMbpCVOScAkYLtX,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if gRxlBNGPjKnafHqIMbpCVOScAkYLtX=='tvshow':
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/fz/vod/contents/'+gRxlBNGPjKnafHqIMbpCVOScAkYLtw 
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if not('programtitle' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh):return{}
   gRxlBNGPjKnafHqIMbpCVOScAkYLdW=gRxlBNGPjKnafHqIMbpCVOScAkYLsh
   gRxlBNGPjKnafHqIMbpCVOScAkYLdh=gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('programtitle')
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['title']=gRxlBNGPjKnafHqIMbpCVOScAkYLdh
   if gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('targetage')=='18' or gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('targetage')=='19' or gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('targetage')=='21':
    gRxlBNGPjKnafHqIMbpCVOScAkYLdh +=u' (%s)'%(gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('targetage'))
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['title'] =gRxlBNGPjKnafHqIMbpCVOScAkYLdh
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['mpaa'] =gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('targetage')
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['plot'] =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_ChangeText(gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('programsynopsis'))
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['studio'] =gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('channelname')
   if gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('firstreleaseyear')!='':gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['year'] =gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('firstreleaseyear')
   if gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('firstreleasedate')!='':gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['premiered']=gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('firstreleasedate')
   if gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('genretext') !='':gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['genre'] =[gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('genretext')]
   gRxlBNGPjKnafHqIMbpCVOScAkYLdX=[]
   for gRxlBNGPjKnafHqIMbpCVOScAkYLdF in gRxlBNGPjKnafHqIMbpCVOScAkYLdW['actors']['list']:gRxlBNGPjKnafHqIMbpCVOScAkYLdX.append(gRxlBNGPjKnafHqIMbpCVOScAkYLdF.get('text'))
   if gRxlBNGPjKnafHqIMbpCVOScAkYLJu(gRxlBNGPjKnafHqIMbpCVOScAkYLdX)>0:
    if gRxlBNGPjKnafHqIMbpCVOScAkYLdX[0]!='':gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['cast']=gRxlBNGPjKnafHqIMbpCVOScAkYLdX
   gRxlBNGPjKnafHqIMbpCVOScAkYLuX =''
   gRxlBNGPjKnafHqIMbpCVOScAkYLuF =''
   gRxlBNGPjKnafHqIMbpCVOScAkYLur=''
   if gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('programposterimage')!='':gRxlBNGPjKnafHqIMbpCVOScAkYLuX =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.HTTPTAG+gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('programposterimage')
   if gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('programimage') !='':gRxlBNGPjKnafHqIMbpCVOScAkYLuF =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.HTTPTAG+gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('programimage')
   if gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('programcircleimage')!='':gRxlBNGPjKnafHqIMbpCVOScAkYLur=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.HTTPTAG+gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('programcircleimage')
   if 'poster_default' in gRxlBNGPjKnafHqIMbpCVOScAkYLuX:
    gRxlBNGPjKnafHqIMbpCVOScAkYLuX =gRxlBNGPjKnafHqIMbpCVOScAkYLuF
    gRxlBNGPjKnafHqIMbpCVOScAkYLur=''
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['thumbnail']['poster']=gRxlBNGPjKnafHqIMbpCVOScAkYLuX
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['thumbnail']['thumb']=gRxlBNGPjKnafHqIMbpCVOScAkYLuF
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['thumbnail']['clearlogo']=gRxlBNGPjKnafHqIMbpCVOScAkYLur
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['thumbnail']['fanart']=gRxlBNGPjKnafHqIMbpCVOScAkYLuF
  else:
   gRxlBNGPjKnafHqIMbpCVOScAkYLsT=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.API_DOMAIN+'/movie/contents/'+gRxlBNGPjKnafHqIMbpCVOScAkYLtF 
   gRxlBNGPjKnafHqIMbpCVOScAkYLvW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.GetDefaultParams(login=gRxlBNGPjKnafHqIMbpCVOScAkYLdm)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsW=gRxlBNGPjKnafHqIMbpCVOScAkYLvu.callRequestCookies('Get',gRxlBNGPjKnafHqIMbpCVOScAkYLsT,payload=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,params=gRxlBNGPjKnafHqIMbpCVOScAkYLvW,headers=gRxlBNGPjKnafHqIMbpCVOScAkYLdD,cookies=gRxlBNGPjKnafHqIMbpCVOScAkYLdD)
   gRxlBNGPjKnafHqIMbpCVOScAkYLsh=json.loads(gRxlBNGPjKnafHqIMbpCVOScAkYLsW.text)
   if not('title' in gRxlBNGPjKnafHqIMbpCVOScAkYLsh):return{}
   gRxlBNGPjKnafHqIMbpCVOScAkYLdW=gRxlBNGPjKnafHqIMbpCVOScAkYLsh
   gRxlBNGPjKnafHqIMbpCVOScAkYLdh=gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('title')
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['title']=gRxlBNGPjKnafHqIMbpCVOScAkYLdh
   if gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('targetage')=='18' or gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('targetage')=='19' or gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('targetage')=='21':
    gRxlBNGPjKnafHqIMbpCVOScAkYLdh +=u' (%s)'%(gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('targetage'))
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['title'] =gRxlBNGPjKnafHqIMbpCVOScAkYLdh
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['mpaa'] =gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('targetage')
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['plot'] =gRxlBNGPjKnafHqIMbpCVOScAkYLvu.Get_ChangeText(gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('synopsis'))
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['duration']=gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('playtime')
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['country']=gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('country')
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['studio'] =gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('cpname')
   if gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('releasedate')!='':
    gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['year'] =gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('releasedate')[:4]
    gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['premiered']=gRxlBNGPjKnafHqIMbpCVOScAkYLdW.get('releasedate')
   gRxlBNGPjKnafHqIMbpCVOScAkYLdX=[]
   for gRxlBNGPjKnafHqIMbpCVOScAkYLdF in gRxlBNGPjKnafHqIMbpCVOScAkYLdW['actors']['list']:gRxlBNGPjKnafHqIMbpCVOScAkYLdX.append(gRxlBNGPjKnafHqIMbpCVOScAkYLdF.get('text'))
   if gRxlBNGPjKnafHqIMbpCVOScAkYLJu(gRxlBNGPjKnafHqIMbpCVOScAkYLdX)>0:
    if gRxlBNGPjKnafHqIMbpCVOScAkYLdX[0]!='':gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['cast']=gRxlBNGPjKnafHqIMbpCVOScAkYLdX
   gRxlBNGPjKnafHqIMbpCVOScAkYLdr=[]
   for gRxlBNGPjKnafHqIMbpCVOScAkYLdE in gRxlBNGPjKnafHqIMbpCVOScAkYLdW['directors']['list']:gRxlBNGPjKnafHqIMbpCVOScAkYLdr.append(gRxlBNGPjKnafHqIMbpCVOScAkYLdE.get('text'))
   if gRxlBNGPjKnafHqIMbpCVOScAkYLJu(gRxlBNGPjKnafHqIMbpCVOScAkYLdr)>0:
    if gRxlBNGPjKnafHqIMbpCVOScAkYLdr[0]!='':gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['director']=gRxlBNGPjKnafHqIMbpCVOScAkYLdr
   gRxlBNGPjKnafHqIMbpCVOScAkYLsD=[]
   for gRxlBNGPjKnafHqIMbpCVOScAkYLdi in gRxlBNGPjKnafHqIMbpCVOScAkYLdW['genre']['list']:gRxlBNGPjKnafHqIMbpCVOScAkYLsD.append(gRxlBNGPjKnafHqIMbpCVOScAkYLdi.get('text'))
   if gRxlBNGPjKnafHqIMbpCVOScAkYLJu(gRxlBNGPjKnafHqIMbpCVOScAkYLsD)>0:
    if gRxlBNGPjKnafHqIMbpCVOScAkYLsD[0]!='':gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['infoLabels']['genre']=gRxlBNGPjKnafHqIMbpCVOScAkYLsD
   gRxlBNGPjKnafHqIMbpCVOScAkYLuX ='https://%s'%gRxlBNGPjKnafHqIMbpCVOScAkYLdW['image']
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['thumbnail']['poster'] =gRxlBNGPjKnafHqIMbpCVOScAkYLuX
   gRxlBNGPjKnafHqIMbpCVOScAkYLdz['saveinfo']['thumbnail']['thumb'] =gRxlBNGPjKnafHqIMbpCVOScAkYLuX
  return gRxlBNGPjKnafHqIMbpCVOScAkYLdz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
