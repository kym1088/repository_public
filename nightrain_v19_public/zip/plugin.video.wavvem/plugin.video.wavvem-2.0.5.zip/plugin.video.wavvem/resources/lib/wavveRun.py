__author__="NightRain"
fYqsgtSwBmRyzuKiNPdWolbInQpHOF=object
fYqsgtSwBmRyzuKiNPdWolbInQpHOD=None
fYqsgtSwBmRyzuKiNPdWolbInQpHOU=int
fYqsgtSwBmRyzuKiNPdWolbInQpHOe=False
fYqsgtSwBmRyzuKiNPdWolbInQpHOG=True
fYqsgtSwBmRyzuKiNPdWolbInQpHOa=len
fYqsgtSwBmRyzuKiNPdWolbInQpHLE=str
fYqsgtSwBmRyzuKiNPdWolbInQpHLJ=dict
fYqsgtSwBmRyzuKiNPdWolbInQpHLC=open
fYqsgtSwBmRyzuKiNPdWolbInQpHLX=Exception
fYqsgtSwBmRyzuKiNPdWolbInQpHLO=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
fYqsgtSwBmRyzuKiNPdWolbInQpHEC=[{'title':'홈','uicode':'GN1','came':'home'},{'title':'LIVE 채널','uicode':'GN3','came':'live'},{'title':'VOD 방송','uicode':'GN2','came':'broadcast'},{'title':'영화(Movie)','uicode':'GN17','came':'movie'},{'title':'해외시리즈','uicode':'GN12','came':'global'},{'title':'분류별 - 방송(VOD) - 인기순','uicode':'GENRE','came':'vodgenre','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 방송(VOD) - 최신순','uicode':'GENRE','came':'vodgenre','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','uicode':'GENRE','came':'moviegenre_svod','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','uicode':'GENRE','came':'moviegenre_svod','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색','uicode':'SEARCH','came':'-'},{'title':'Watched(시청목록)','uicode':'WATCH','came':'-'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
fYqsgtSwBmRyzuKiNPdWolbInQpHEX='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
fYqsgtSwBmRyzuKiNPdWolbInQpHEO=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class fYqsgtSwBmRyzuKiNPdWolbInQpHEJ(fYqsgtSwBmRyzuKiNPdWolbInQpHOF):
 def __init__(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,fYqsgtSwBmRyzuKiNPdWolbInQpHEh,fYqsgtSwBmRyzuKiNPdWolbInQpHEV,fYqsgtSwBmRyzuKiNPdWolbInQpHEc):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_url =fYqsgtSwBmRyzuKiNPdWolbInQpHEh
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle=fYqsgtSwBmRyzuKiNPdWolbInQpHEV
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params =fYqsgtSwBmRyzuKiNPdWolbInQpHEc
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj =eObkMTvrKtwHAnGUEYgmLpixydCzNs() 
 def addon_noti(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,sting):
  try:
   fYqsgtSwBmRyzuKiNPdWolbInQpHEr=xbmcgui.Dialog()
   fYqsgtSwBmRyzuKiNPdWolbInQpHEr.notification(__addonname__,sting)
  except:
   fYqsgtSwBmRyzuKiNPdWolbInQpHOD
 def addon_log(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,string):
  try:
   fYqsgtSwBmRyzuKiNPdWolbInQpHEv=string.encode('utf-8','ignore')
  except:
   fYqsgtSwBmRyzuKiNPdWolbInQpHEv='addonException: addon_log'
  fYqsgtSwBmRyzuKiNPdWolbInQpHEA=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,fYqsgtSwBmRyzuKiNPdWolbInQpHEv),level=fYqsgtSwBmRyzuKiNPdWolbInQpHEA)
 def get_keyboard_input(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,fYqsgtSwBmRyzuKiNPdWolbInQpHJX):
  fYqsgtSwBmRyzuKiNPdWolbInQpHET=fYqsgtSwBmRyzuKiNPdWolbInQpHOD
  kb=xbmc.Keyboard()
  kb.setHeading(fYqsgtSwBmRyzuKiNPdWolbInQpHJX)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   fYqsgtSwBmRyzuKiNPdWolbInQpHET=kb.getText()
  return fYqsgtSwBmRyzuKiNPdWolbInQpHET
 def get_settings_login_info(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEk =__addon__.getSetting('id')
  fYqsgtSwBmRyzuKiNPdWolbInQpHEx =__addon__.getSetting('pw')
  fYqsgtSwBmRyzuKiNPdWolbInQpHEj=__addon__.getSetting('selected_profile')
  return(fYqsgtSwBmRyzuKiNPdWolbInQpHEk,fYqsgtSwBmRyzuKiNPdWolbInQpHEx,fYqsgtSwBmRyzuKiNPdWolbInQpHEj)
 def get_selQuality(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  try:
   fYqsgtSwBmRyzuKiNPdWolbInQpHEF=[1080,720,480,360]
   fYqsgtSwBmRyzuKiNPdWolbInQpHED=fYqsgtSwBmRyzuKiNPdWolbInQpHOU(__addon__.getSetting('selected_quality'))
   return fYqsgtSwBmRyzuKiNPdWolbInQpHEF[fYqsgtSwBmRyzuKiNPdWolbInQpHED]
  except:
   fYqsgtSwBmRyzuKiNPdWolbInQpHOD
  return 1080 
 def get_settings_exclusion21(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEU =__addon__.getSetting('exclusion21')
  if fYqsgtSwBmRyzuKiNPdWolbInQpHEU=='false':
   return fYqsgtSwBmRyzuKiNPdWolbInQpHOe
  else:
   return fYqsgtSwBmRyzuKiNPdWolbInQpHOG
 def get_settings_direct_replay(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEe=fYqsgtSwBmRyzuKiNPdWolbInQpHOU(__addon__.getSetting('direct_replay'))
  if fYqsgtSwBmRyzuKiNPdWolbInQpHEe==0:
   return fYqsgtSwBmRyzuKiNPdWolbInQpHOe
  else:
   return fYqsgtSwBmRyzuKiNPdWolbInQpHOG
 def get_settings_addinfo(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEG =__addon__.getSetting('add_infoyn')
  if fYqsgtSwBmRyzuKiNPdWolbInQpHEG=='false':
   return fYqsgtSwBmRyzuKiNPdWolbInQpHOe
  else:
   return fYqsgtSwBmRyzuKiNPdWolbInQpHOG
 def get_settings_thumbnail_landyn(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEa =fYqsgtSwBmRyzuKiNPdWolbInQpHOU(__addon__.getSetting('thumbnail_way'))
  if fYqsgtSwBmRyzuKiNPdWolbInQpHEa==0:
   return fYqsgtSwBmRyzuKiNPdWolbInQpHOG
  else:
   return fYqsgtSwBmRyzuKiNPdWolbInQpHOe
 def set_winCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,credential):
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE=xbmcgui.Window(10000)
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE.setProperty('WAVVE_M_CREDENTIAL',credential)
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE.setProperty('WAVVE_M_LOGINTIME',fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE=xbmcgui.Window(10000)
  return fYqsgtSwBmRyzuKiNPdWolbInQpHJE.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,fYqsgtSwBmRyzuKiNPdWolbInQpHJj):
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE=xbmcgui.Window(10000)
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE.setProperty('WAVVE_M_ORDERBY',fYqsgtSwBmRyzuKiNPdWolbInQpHJj)
 def get_winEpisodeOrderby(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE=xbmcgui.Window(10000)
  return fYqsgtSwBmRyzuKiNPdWolbInQpHJE.getProperty('WAVVE_M_ORDERBY')
 def add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,label,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=''):
  fYqsgtSwBmRyzuKiNPdWolbInQpHJC='%s?%s'%(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_url,urllib.parse.urlencode(params))
  if sublabel:fYqsgtSwBmRyzuKiNPdWolbInQpHJX='%s < %s >'%(label,sublabel)
  else: fYqsgtSwBmRyzuKiNPdWolbInQpHJX=label
  if not img:img='DefaultFolder.png'
  fYqsgtSwBmRyzuKiNPdWolbInQpHJO=xbmcgui.ListItem(fYqsgtSwBmRyzuKiNPdWolbInQpHJX)
  fYqsgtSwBmRyzuKiNPdWolbInQpHJO.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:fYqsgtSwBmRyzuKiNPdWolbInQpHJO.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:fYqsgtSwBmRyzuKiNPdWolbInQpHJO.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle,fYqsgtSwBmRyzuKiNPdWolbInQpHJC,fYqsgtSwBmRyzuKiNPdWolbInQpHJO,isFolder)
 def dp_Main_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  for fYqsgtSwBmRyzuKiNPdWolbInQpHJL in fYqsgtSwBmRyzuKiNPdWolbInQpHEC:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX=fYqsgtSwBmRyzuKiNPdWolbInQpHJL.get('title')
   if fYqsgtSwBmRyzuKiNPdWolbInQpHJL.get('uicode')=='GENRE':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'GENRE','uicode':fYqsgtSwBmRyzuKiNPdWolbInQpHJL.get('came'),'genre':'-','subgenre':'-','orderby':fYqsgtSwBmRyzuKiNPdWolbInQpHJL.get('orderby'),'ordernm':fYqsgtSwBmRyzuKiNPdWolbInQpHJL.get('ordernm')}
   elif fYqsgtSwBmRyzuKiNPdWolbInQpHJL.get('uicode')=='WATCH':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'WATCH','genre':'-'}
   elif fYqsgtSwBmRyzuKiNPdWolbInQpHJL.get('uicode')=='SEARCH':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'SEARCH','genre':'-'}
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'GNB_LIST','uicode':fYqsgtSwBmRyzuKiNPdWolbInQpHJL.get('uicode'),'came':fYqsgtSwBmRyzuKiNPdWolbInQpHJL.get('came')}
   fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOG
   if fYqsgtSwBmRyzuKiNPdWolbInQpHJL.get('uicode')=='XXX':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode']='XXX'
    fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOe
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHJV,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHOa(fYqsgtSwBmRyzuKiNPdWolbInQpHEC)>0:xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle)
 def login_main(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  (fYqsgtSwBmRyzuKiNPdWolbInQpHJM,fYqsgtSwBmRyzuKiNPdWolbInQpHJr,fYqsgtSwBmRyzuKiNPdWolbInQpHJv)=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_settings_login_info()
  if not(fYqsgtSwBmRyzuKiNPdWolbInQpHJM and fYqsgtSwBmRyzuKiNPdWolbInQpHJr):
   fYqsgtSwBmRyzuKiNPdWolbInQpHEr=xbmcgui.Dialog()
   fYqsgtSwBmRyzuKiNPdWolbInQpHJA=fYqsgtSwBmRyzuKiNPdWolbInQpHEr.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if fYqsgtSwBmRyzuKiNPdWolbInQpHJA==fYqsgtSwBmRyzuKiNPdWolbInQpHOG:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_winEpisodeOrderby()=='':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.set_winEpisodeOrderby('desc')
  if fYqsgtSwBmRyzuKiNPdWolbInQpHEL.cookiefile_check():return
  fYqsgtSwBmRyzuKiNPdWolbInQpHJT =fYqsgtSwBmRyzuKiNPdWolbInQpHOU(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  fYqsgtSwBmRyzuKiNPdWolbInQpHJk=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if fYqsgtSwBmRyzuKiNPdWolbInQpHJk==fYqsgtSwBmRyzuKiNPdWolbInQpHOD or fYqsgtSwBmRyzuKiNPdWolbInQpHJk=='':
   fYqsgtSwBmRyzuKiNPdWolbInQpHJk=fYqsgtSwBmRyzuKiNPdWolbInQpHOU('19000101')
  else:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJk=fYqsgtSwBmRyzuKiNPdWolbInQpHOU(re.sub('-','',fYqsgtSwBmRyzuKiNPdWolbInQpHJk))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   fYqsgtSwBmRyzuKiNPdWolbInQpHJx=0
   while fYqsgtSwBmRyzuKiNPdWolbInQpHOG:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJx+=1
    time.sleep(0.05)
    if fYqsgtSwBmRyzuKiNPdWolbInQpHJk>=fYqsgtSwBmRyzuKiNPdWolbInQpHJT:return
    if fYqsgtSwBmRyzuKiNPdWolbInQpHJx>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if fYqsgtSwBmRyzuKiNPdWolbInQpHJk>=fYqsgtSwBmRyzuKiNPdWolbInQpHJT:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.GetCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHJM,fYqsgtSwBmRyzuKiNPdWolbInQpHJr,fYqsgtSwBmRyzuKiNPdWolbInQpHJv):
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.set_winCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.LoadCredential())
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHJj =args.get('orderby')
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.set_winEpisodeOrderby(fYqsgtSwBmRyzuKiNPdWolbInQpHJj)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Gnb_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.SaveCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_winCredential())
  fYqsgtSwBmRyzuKiNPdWolbInQpHJF=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.GetGnList(args.get('uicode'))
  for fYqsgtSwBmRyzuKiNPdWolbInQpHJD in fYqsgtSwBmRyzuKiNPdWolbInQpHJF:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX=fYqsgtSwBmRyzuKiNPdWolbInQpHJD.get('title')
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'GN_LIST' if fYqsgtSwBmRyzuKiNPdWolbInQpHJD.get('uicode')!='CY1' else 'GN_MYVIEW','uicode':fYqsgtSwBmRyzuKiNPdWolbInQpHJD.get('uicode'),'came':args.get('came'),'page':'1'}
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHOa(fYqsgtSwBmRyzuKiNPdWolbInQpHJF)>0:xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle,cacheToDisc=fYqsgtSwBmRyzuKiNPdWolbInQpHOe)
 def dp_Myview_Group(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHJX='VOD 시청내역'
  fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'MYVIEW_LIST','uicode':'vod','page':'1'}
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  fYqsgtSwBmRyzuKiNPdWolbInQpHJX='영화 시청내역'
  fYqsgtSwBmRyzuKiNPdWolbInQpHJh['uicode']='movie'
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle)
 def dp_Myview_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.SaveCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_winCredential())
  fYqsgtSwBmRyzuKiNPdWolbInQpHJU =fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_settings_addinfo()
  fYqsgtSwBmRyzuKiNPdWolbInQpHJe=args.get('uicode')
  fYqsgtSwBmRyzuKiNPdWolbInQpHJG =fYqsgtSwBmRyzuKiNPdWolbInQpHOU(args.get('page'))
  fYqsgtSwBmRyzuKiNPdWolbInQpHJa,fYqsgtSwBmRyzuKiNPdWolbInQpHCE=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.GetMyviewList(fYqsgtSwBmRyzuKiNPdWolbInQpHJe,fYqsgtSwBmRyzuKiNPdWolbInQpHJG,addinfoyn=fYqsgtSwBmRyzuKiNPdWolbInQpHJU)
  for fYqsgtSwBmRyzuKiNPdWolbInQpHCJ in fYqsgtSwBmRyzuKiNPdWolbInQpHJa:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX =fYqsgtSwBmRyzuKiNPdWolbInQpHCJ.get('title')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCX =fYqsgtSwBmRyzuKiNPdWolbInQpHCJ.get('subtitle')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCO=fYqsgtSwBmRyzuKiNPdWolbInQpHCJ.get('thumbnail')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCL=fYqsgtSwBmRyzuKiNPdWolbInQpHCJ.get('info')
   if fYqsgtSwBmRyzuKiNPdWolbInQpHJe=='movie' and fYqsgtSwBmRyzuKiNPdWolbInQpHJU==fYqsgtSwBmRyzuKiNPdWolbInQpHOG:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJX='%s (%s)'%(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHCL.get('year')))
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHCL['plot']=fYqsgtSwBmRyzuKiNPdWolbInQpHJX
   if fYqsgtSwBmRyzuKiNPdWolbInQpHJe=='vod':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'DEEP_LIST','contentid':fYqsgtSwBmRyzuKiNPdWolbInQpHCJ.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':fYqsgtSwBmRyzuKiNPdWolbInQpHJX,'subtitle':fYqsgtSwBmRyzuKiNPdWolbInQpHCX,'thumbnail':fYqsgtSwBmRyzuKiNPdWolbInQpHCO,'viewage':fYqsgtSwBmRyzuKiNPdWolbInQpHCJ.get('viewage')}
    fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOG
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'MOVIE','contentid':fYqsgtSwBmRyzuKiNPdWolbInQpHCJ.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':fYqsgtSwBmRyzuKiNPdWolbInQpHJX,'subtitle':fYqsgtSwBmRyzuKiNPdWolbInQpHCX,'thumbnail':fYqsgtSwBmRyzuKiNPdWolbInQpHCO,'viewage':fYqsgtSwBmRyzuKiNPdWolbInQpHCJ.get('viewage')}
    fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOe
   if fYqsgtSwBmRyzuKiNPdWolbInQpHCJ.get('viewage')=='21':fYqsgtSwBmRyzuKiNPdWolbInQpHCX+=' (%s)'%(fYqsgtSwBmRyzuKiNPdWolbInQpHCJ.get('viewage'))
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel=fYqsgtSwBmRyzuKiNPdWolbInQpHCX,img=fYqsgtSwBmRyzuKiNPdWolbInQpHCO,infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHCL,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHJV,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHCE:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode'] ='MYVIEW_LIST' 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['uicode']=fYqsgtSwBmRyzuKiNPdWolbInQpHJe 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['page'] =fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHJG+1)
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX='[B]%s >>[/B]'%'다음 페이지'
   fYqsgtSwBmRyzuKiNPdWolbInQpHCX=fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHJG+1)
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel=fYqsgtSwBmRyzuKiNPdWolbInQpHCX,img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHOa(fYqsgtSwBmRyzuKiNPdWolbInQpHJa)>0:xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle,cacheToDisc=fYqsgtSwBmRyzuKiNPdWolbInQpHOe)
 def dp_Genre_Group(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.SaveCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_winCredential())
  fYqsgtSwBmRyzuKiNPdWolbInQpHCh =args.get('mode') 
  fYqsgtSwBmRyzuKiNPdWolbInQpHCV =args.get('uicode')
  fYqsgtSwBmRyzuKiNPdWolbInQpHCc =args.get('genre') 
  fYqsgtSwBmRyzuKiNPdWolbInQpHCM=args.get('subgenre')
  fYqsgtSwBmRyzuKiNPdWolbInQpHJj =args.get('orderby')
  fYqsgtSwBmRyzuKiNPdWolbInQpHCr =args.get('ordernm')
  if fYqsgtSwBmRyzuKiNPdWolbInQpHCc=='-':
   fYqsgtSwBmRyzuKiNPdWolbInQpHCv=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.GetGenreGroup(fYqsgtSwBmRyzuKiNPdWolbInQpHCV,fYqsgtSwBmRyzuKiNPdWolbInQpHCc,fYqsgtSwBmRyzuKiNPdWolbInQpHJj,fYqsgtSwBmRyzuKiNPdWolbInQpHCr,exclusion21=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_settings_exclusion21())
  else:
   fYqsgtSwBmRyzuKiNPdWolbInQpHCA={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':fYqsgtSwBmRyzuKiNPdWolbInQpHJj,'ordernm':fYqsgtSwBmRyzuKiNPdWolbInQpHCr}
   fYqsgtSwBmRyzuKiNPdWolbInQpHCv=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.GetGenreGroup_sub(fYqsgtSwBmRyzuKiNPdWolbInQpHCA)
  for fYqsgtSwBmRyzuKiNPdWolbInQpHCT in fYqsgtSwBmRyzuKiNPdWolbInQpHCv:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX =fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('title')+'  ('+fYqsgtSwBmRyzuKiNPdWolbInQpHCr+')'
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':fYqsgtSwBmRyzuKiNPdWolbInQpHCh,'uicode':fYqsgtSwBmRyzuKiNPdWolbInQpHCV,'genre':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('genre'),'subgenre':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('subgenre'),'adult':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('adult'),'page':'1','broadcastid':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('broadcastid'),'contenttype':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('contenttype'),'uiparent':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('uiparent'),'uirank':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('uirank'),'uitype':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('uitype'),'orderby':fYqsgtSwBmRyzuKiNPdWolbInQpHJj,'ordernm':fYqsgtSwBmRyzuKiNPdWolbInQpHCr}
   if fYqsgtSwBmRyzuKiNPdWolbInQpHCV=='moviegenre' or fYqsgtSwBmRyzuKiNPdWolbInQpHCV=='moviegenre_svod' or fYqsgtSwBmRyzuKiNPdWolbInQpHCV=='moviegenre_ppv' or fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('subgenre')!='-':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode'] ='GENRE_LIST'
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHOD
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHOa(fYqsgtSwBmRyzuKiNPdWolbInQpHCv)>0:xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle,cacheToDisc=fYqsgtSwBmRyzuKiNPdWolbInQpHOe)
 def dp_Genre_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.SaveCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_winCredential())
  fYqsgtSwBmRyzuKiNPdWolbInQpHJU=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_settings_addinfo()
  fYqsgtSwBmRyzuKiNPdWolbInQpHCV =args.get('uicode')
  fYqsgtSwBmRyzuKiNPdWolbInQpHJG=fYqsgtSwBmRyzuKiNPdWolbInQpHOU(args.get('page'))
  fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'subgenre':args.get('subgenre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':args.get('orderby')}
  if args.get('genre')==args.get('subgenre'):
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['subgenre']='all'
  fYqsgtSwBmRyzuKiNPdWolbInQpHCv,fYqsgtSwBmRyzuKiNPdWolbInQpHCE=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.GetGenreList(fYqsgtSwBmRyzuKiNPdWolbInQpHCV,fYqsgtSwBmRyzuKiNPdWolbInQpHJh,fYqsgtSwBmRyzuKiNPdWolbInQpHJG,addinfoyn=fYqsgtSwBmRyzuKiNPdWolbInQpHJU)
  for fYqsgtSwBmRyzuKiNPdWolbInQpHCT in fYqsgtSwBmRyzuKiNPdWolbInQpHCv:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX =fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('title')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCO=fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('thumbnail')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCL=fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('info')
   if fYqsgtSwBmRyzuKiNPdWolbInQpHCV=='moviegenre_svod' and fYqsgtSwBmRyzuKiNPdWolbInQpHJU==fYqsgtSwBmRyzuKiNPdWolbInQpHOG:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJX='%s (%s)'%(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHCL.get('year')))
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHCL['plot']=fYqsgtSwBmRyzuKiNPdWolbInQpHJX
   if fYqsgtSwBmRyzuKiNPdWolbInQpHCV=='vodgenre':
    fYqsgtSwBmRyzuKiNPdWolbInQpHCk={'mode':'DEEP_LIST','contentid':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('uicode'),'contentidType':'contentid','uicode':'vod','page':'1','title':fYqsgtSwBmRyzuKiNPdWolbInQpHJX,'subtitle':'','thumbnail':fYqsgtSwBmRyzuKiNPdWolbInQpHCO,'viewage':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('viewage')}
    fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOG
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHCk={'mode':'MOVIE','contentid':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('uicode'),'contentidType':'contentid','uicode':'movie','page':'1','title':fYqsgtSwBmRyzuKiNPdWolbInQpHJX,'subtitle':'','thumbnail':fYqsgtSwBmRyzuKiNPdWolbInQpHCO,'viewage':fYqsgtSwBmRyzuKiNPdWolbInQpHCT.get('viewage')}
    fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOe
   if fYqsgtSwBmRyzuKiNPdWolbInQpHCk.get('viewage')=='21':fYqsgtSwBmRyzuKiNPdWolbInQpHJX+=' (%s)'%(fYqsgtSwBmRyzuKiNPdWolbInQpHCk.get('viewage'))
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img=fYqsgtSwBmRyzuKiNPdWolbInQpHCO,infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHCL,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHJV,params=fYqsgtSwBmRyzuKiNPdWolbInQpHCk)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHCE:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode'] ='GENRE_LIST' 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['uicode']=fYqsgtSwBmRyzuKiNPdWolbInQpHCV 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['page'] =fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHJG+1)
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX='[B]%s >>[/B]'%'다음 페이지'
   fYqsgtSwBmRyzuKiNPdWolbInQpHCX=fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHJG+1)
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel=fYqsgtSwBmRyzuKiNPdWolbInQpHCX,img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHOa(fYqsgtSwBmRyzuKiNPdWolbInQpHCv)>0:xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle,cacheToDisc=fYqsgtSwBmRyzuKiNPdWolbInQpHOe)
 def dp_Deeplink_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.SaveCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_winCredential())
  fYqsgtSwBmRyzuKiNPdWolbInQpHJU=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_settings_addinfo()
  fYqsgtSwBmRyzuKiNPdWolbInQpHCV =args.get('uicode')
  fYqsgtSwBmRyzuKiNPdWolbInQpHCx =args.get('came')
  fYqsgtSwBmRyzuKiNPdWolbInQpHJG=fYqsgtSwBmRyzuKiNPdWolbInQpHOU(args.get('page'))
  fYqsgtSwBmRyzuKiNPdWolbInQpHCj,fYqsgtSwBmRyzuKiNPdWolbInQpHCE=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.GetDeeplinkList(fYqsgtSwBmRyzuKiNPdWolbInQpHCV,fYqsgtSwBmRyzuKiNPdWolbInQpHCx,fYqsgtSwBmRyzuKiNPdWolbInQpHJG,addinfoyn=fYqsgtSwBmRyzuKiNPdWolbInQpHJU)
  for fYqsgtSwBmRyzuKiNPdWolbInQpHCF in fYqsgtSwBmRyzuKiNPdWolbInQpHCj:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX =fYqsgtSwBmRyzuKiNPdWolbInQpHCF.get('title')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCX =fYqsgtSwBmRyzuKiNPdWolbInQpHCF.get('subtitle')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCO=fYqsgtSwBmRyzuKiNPdWolbInQpHCF.get('thumbnail')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCD=fYqsgtSwBmRyzuKiNPdWolbInQpHCF.get('uicode')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCU=fYqsgtSwBmRyzuKiNPdWolbInQpHCF.get('channelepg')
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'uicode':fYqsgtSwBmRyzuKiNPdWolbInQpHCD,'came':fYqsgtSwBmRyzuKiNPdWolbInQpHCx,'contentid':fYqsgtSwBmRyzuKiNPdWolbInQpHCF.get('contentid'),'contentidType':fYqsgtSwBmRyzuKiNPdWolbInQpHCF.get('contentidType'),'page':'1','title':fYqsgtSwBmRyzuKiNPdWolbInQpHJX,'subtitle':fYqsgtSwBmRyzuKiNPdWolbInQpHCX,'thumbnail':fYqsgtSwBmRyzuKiNPdWolbInQpHCO,'viewage':fYqsgtSwBmRyzuKiNPdWolbInQpHCF.get('viewage')}
   if fYqsgtSwBmRyzuKiNPdWolbInQpHCD=='channel':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode'] ='LIVE'
   elif fYqsgtSwBmRyzuKiNPdWolbInQpHCD=='movie':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode'] ='MOVIE'
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode'] ='DEEP_LIST'
   fYqsgtSwBmRyzuKiNPdWolbInQpHCL=fYqsgtSwBmRyzuKiNPdWolbInQpHCF.get('info')
   if fYqsgtSwBmRyzuKiNPdWolbInQpHCU:
    fYqsgtSwBmRyzuKiNPdWolbInQpHCL['plot']='%s\n\n%s'%(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,fYqsgtSwBmRyzuKiNPdWolbInQpHCU)
   elif fYqsgtSwBmRyzuKiNPdWolbInQpHCD=='movie' and fYqsgtSwBmRyzuKiNPdWolbInQpHJU==fYqsgtSwBmRyzuKiNPdWolbInQpHOG:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJX='%s (%s)'%(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHCL.get('year')))
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHCL['plot']='%s\n\n%s'%(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,fYqsgtSwBmRyzuKiNPdWolbInQpHCX)
   if fYqsgtSwBmRyzuKiNPdWolbInQpHCF.get('viewage')=='21':fYqsgtSwBmRyzuKiNPdWolbInQpHCX+=' (%s)'%(fYqsgtSwBmRyzuKiNPdWolbInQpHCF.get('viewage'))
   if fYqsgtSwBmRyzuKiNPdWolbInQpHCD in['channel','movie']:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOe
   elif fYqsgtSwBmRyzuKiNPdWolbInQpHJh['contentidType']=='direct':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOe
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode']='VOD'
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOG
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel=fYqsgtSwBmRyzuKiNPdWolbInQpHCX,img=fYqsgtSwBmRyzuKiNPdWolbInQpHCO,infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHCL,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHJV,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHCE:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode'] ='GN_LIST' 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['uicode']=fYqsgtSwBmRyzuKiNPdWolbInQpHCV 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['page'] =fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHJG+1)
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX='[B]%s >>[/B]'%'다음 페이지'
   fYqsgtSwBmRyzuKiNPdWolbInQpHCX=fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHJG+1)
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel=fYqsgtSwBmRyzuKiNPdWolbInQpHCX,img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHOa(fYqsgtSwBmRyzuKiNPdWolbInQpHCj)>0:xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle,cacheToDisc=fYqsgtSwBmRyzuKiNPdWolbInQpHOe)
 def dp_Episodelink_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.SaveCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_winCredential())
  fYqsgtSwBmRyzuKiNPdWolbInQpHCe =args.get('contentid')
  fYqsgtSwBmRyzuKiNPdWolbInQpHCG=args.get('contentidType')
  fYqsgtSwBmRyzuKiNPdWolbInQpHJe =args.get('uicode')
  fYqsgtSwBmRyzuKiNPdWolbInQpHJG =fYqsgtSwBmRyzuKiNPdWolbInQpHOU(args.get('page'))
  fYqsgtSwBmRyzuKiNPdWolbInQpHCa,fYqsgtSwBmRyzuKiNPdWolbInQpHCE=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.GetEpisodeList(fYqsgtSwBmRyzuKiNPdWolbInQpHCe,fYqsgtSwBmRyzuKiNPdWolbInQpHJe,fYqsgtSwBmRyzuKiNPdWolbInQpHCG,fYqsgtSwBmRyzuKiNPdWolbInQpHJG,orderby=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_winEpisodeOrderby())
  for fYqsgtSwBmRyzuKiNPdWolbInQpHXE in fYqsgtSwBmRyzuKiNPdWolbInQpHCa:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX =fYqsgtSwBmRyzuKiNPdWolbInQpHXE.get('title')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCX =fYqsgtSwBmRyzuKiNPdWolbInQpHXE.get('subtitle')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCO=fYqsgtSwBmRyzuKiNPdWolbInQpHXE.get('thumbnail')
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'VOD','uicode':fYqsgtSwBmRyzuKiNPdWolbInQpHXE.get('uicode'),'contentid':fYqsgtSwBmRyzuKiNPdWolbInQpHXE.get('contentid'),'programid':fYqsgtSwBmRyzuKiNPdWolbInQpHXE.get('programid'),'title':fYqsgtSwBmRyzuKiNPdWolbInQpHJX,'subtitle':fYqsgtSwBmRyzuKiNPdWolbInQpHCX,'thumbnail':fYqsgtSwBmRyzuKiNPdWolbInQpHCO,'viewage':fYqsgtSwBmRyzuKiNPdWolbInQpHXE.get('viewage')}
   if fYqsgtSwBmRyzuKiNPdWolbInQpHXE.get('viewage')=='21':fYqsgtSwBmRyzuKiNPdWolbInQpHCX+=' (%s)'%(fYqsgtSwBmRyzuKiNPdWolbInQpHXE.get('viewage'))
   fYqsgtSwBmRyzuKiNPdWolbInQpHXJ=fYqsgtSwBmRyzuKiNPdWolbInQpHXE.get('info')
   fYqsgtSwBmRyzuKiNPdWolbInQpHXJ['plot']=fYqsgtSwBmRyzuKiNPdWolbInQpHXE.get('synopsis')
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel=fYqsgtSwBmRyzuKiNPdWolbInQpHCX,img=fYqsgtSwBmRyzuKiNPdWolbInQpHCO,infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHXJ,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOe,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHJG==1:
   fYqsgtSwBmRyzuKiNPdWolbInQpHCL={'plot':'정렬순서를 변경합니다.'}
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh={}
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode'] ='ORDER_BY' 
   if fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_winEpisodeOrderby()=='desc':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJX='정렬순서변경 : 최신화부터 -> 1회부터'
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh['orderby']='asc'
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJX='정렬순서변경 : 1회부터 -> 최신화부터'
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh['orderby']='desc'
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHCL,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOe,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHCE:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode'] ='DEEP_LIST' 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['uicode'] =fYqsgtSwBmRyzuKiNPdWolbInQpHJe 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['contentid'] =fYqsgtSwBmRyzuKiNPdWolbInQpHCe 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['contentidType']=fYqsgtSwBmRyzuKiNPdWolbInQpHCG 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['page'] =fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHJG+1)
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX='[B]%s >>[/B]'%'다음 페이지'
   fYqsgtSwBmRyzuKiNPdWolbInQpHCX=fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHJG+1)
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel=fYqsgtSwBmRyzuKiNPdWolbInQpHCX,img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHOa(fYqsgtSwBmRyzuKiNPdWolbInQpHCa)>0:xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle,cacheToDisc=fYqsgtSwBmRyzuKiNPdWolbInQpHOG)
 def play_VIDEO(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.SaveCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_winCredential())
  fYqsgtSwBmRyzuKiNPdWolbInQpHCe =args.get('contentid')
  fYqsgtSwBmRyzuKiNPdWolbInQpHJe=args.get('uicode')
  fYqsgtSwBmRyzuKiNPdWolbInQpHXC=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_selQuality()
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.addon_log(fYqsgtSwBmRyzuKiNPdWolbInQpHCe+' - '+fYqsgtSwBmRyzuKiNPdWolbInQpHJe)
  fYqsgtSwBmRyzuKiNPdWolbInQpHXO,fYqsgtSwBmRyzuKiNPdWolbInQpHXL,fYqsgtSwBmRyzuKiNPdWolbInQpHXh,fYqsgtSwBmRyzuKiNPdWolbInQpHXV=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.GetStreamingURL(fYqsgtSwBmRyzuKiNPdWolbInQpHCe,fYqsgtSwBmRyzuKiNPdWolbInQpHJe,fYqsgtSwBmRyzuKiNPdWolbInQpHXC)
  fYqsgtSwBmRyzuKiNPdWolbInQpHXc='%s|Cookie=%s'%(fYqsgtSwBmRyzuKiNPdWolbInQpHXO,fYqsgtSwBmRyzuKiNPdWolbInQpHXL)
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.addon_log(fYqsgtSwBmRyzuKiNPdWolbInQpHXc)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHXO=='':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.addon_noti(__language__(30907).encode('utf8'))
   return
  fYqsgtSwBmRyzuKiNPdWolbInQpHXM=xbmcgui.ListItem(path=fYqsgtSwBmRyzuKiNPdWolbInQpHXc)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHXh:
   fYqsgtSwBmRyzuKiNPdWolbInQpHXr=fYqsgtSwBmRyzuKiNPdWolbInQpHXh['customdata']
   fYqsgtSwBmRyzuKiNPdWolbInQpHXv =fYqsgtSwBmRyzuKiNPdWolbInQpHXh['drmhost']
   fYqsgtSwBmRyzuKiNPdWolbInQpHXA =inputstreamhelper.Helper('mpd',drm='widevine')
   if fYqsgtSwBmRyzuKiNPdWolbInQpHXA.check_inputstream():
    if fYqsgtSwBmRyzuKiNPdWolbInQpHJe=='movie':
     fYqsgtSwBmRyzuKiNPdWolbInQpHXT='https://www.wavve.com/player/movie?movieid=%s'%fYqsgtSwBmRyzuKiNPdWolbInQpHCe
    else:
     fYqsgtSwBmRyzuKiNPdWolbInQpHXT='https://www.wavve.com/player/vod?programid=%s&page=1'%fYqsgtSwBmRyzuKiNPdWolbInQpHCe
    fYqsgtSwBmRyzuKiNPdWolbInQpHXk={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':fYqsgtSwBmRyzuKiNPdWolbInQpHXr,'referer':fYqsgtSwBmRyzuKiNPdWolbInQpHXT,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':fYqsgtSwBmRyzuKiNPdWolbInQpHEX}
    fYqsgtSwBmRyzuKiNPdWolbInQpHXx=fYqsgtSwBmRyzuKiNPdWolbInQpHXv+'|'+urllib.parse.urlencode(fYqsgtSwBmRyzuKiNPdWolbInQpHXk)+'|R{SSM}|'
    fYqsgtSwBmRyzuKiNPdWolbInQpHXM.setProperty('inputstream',fYqsgtSwBmRyzuKiNPdWolbInQpHXA.inputstream_addon)
    fYqsgtSwBmRyzuKiNPdWolbInQpHXM.setProperty('inputstream.adaptive.manifest_type','mpd')
    fYqsgtSwBmRyzuKiNPdWolbInQpHXM.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    fYqsgtSwBmRyzuKiNPdWolbInQpHXM.setProperty('inputstream.adaptive.license_key',fYqsgtSwBmRyzuKiNPdWolbInQpHXx)
    fYqsgtSwBmRyzuKiNPdWolbInQpHXM.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(fYqsgtSwBmRyzuKiNPdWolbInQpHEX,fYqsgtSwBmRyzuKiNPdWolbInQpHXL))
  xbmcplugin.setResolvedUrl(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle,fYqsgtSwBmRyzuKiNPdWolbInQpHOG,fYqsgtSwBmRyzuKiNPdWolbInQpHXM)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHXV:
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.addon_noti(fYqsgtSwBmRyzuKiNPdWolbInQpHXV.encode('utf-8'))
  else:
   if '/preview.' in urllib.parse.urlsplit(fYqsgtSwBmRyzuKiNPdWolbInQpHXO).path:fYqsgtSwBmRyzuKiNPdWolbInQpHEL.addon_noti(__language__(30908).encode('utf8'))
  try:
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('viewage')!='21':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'code':args.get('programid')if args.get('mode')=='VOD' else args.get('contentid'),'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    fYqsgtSwBmRyzuKiNPdWolbInQpHEL.Save_Watched_List(args.get('mode').lower(),fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  except:
   fYqsgtSwBmRyzuKiNPdWolbInQpHOD
 def dp_Watch_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHCc =args.get('genre')
  fYqsgtSwBmRyzuKiNPdWolbInQpHEe=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_settings_direct_replay()
  if fYqsgtSwBmRyzuKiNPdWolbInQpHCc=='-':
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX='VOD 시청내역'
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'WATCH','genre':'vod'}
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX='영화 시청내역'
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['genre']='movie'
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
   xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle)
  else:
   fYqsgtSwBmRyzuKiNPdWolbInQpHXj=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.Load_Watched_List(fYqsgtSwBmRyzuKiNPdWolbInQpHCc)
   for fYqsgtSwBmRyzuKiNPdWolbInQpHXF in fYqsgtSwBmRyzuKiNPdWolbInQpHXj:
    fYqsgtSwBmRyzuKiNPdWolbInQpHXD=fYqsgtSwBmRyzuKiNPdWolbInQpHLJ(urllib.parse.parse_qsl(fYqsgtSwBmRyzuKiNPdWolbInQpHXF))
    fYqsgtSwBmRyzuKiNPdWolbInQpHJX =fYqsgtSwBmRyzuKiNPdWolbInQpHXD.get('title').strip()
    fYqsgtSwBmRyzuKiNPdWolbInQpHCX =fYqsgtSwBmRyzuKiNPdWolbInQpHXD.get('subtitle').strip()
    if fYqsgtSwBmRyzuKiNPdWolbInQpHCX=='None':fYqsgtSwBmRyzuKiNPdWolbInQpHCX=''
    fYqsgtSwBmRyzuKiNPdWolbInQpHCO=fYqsgtSwBmRyzuKiNPdWolbInQpHXD.get('img')
    fYqsgtSwBmRyzuKiNPdWolbInQpHXU =fYqsgtSwBmRyzuKiNPdWolbInQpHXD.get('videoid')
    fYqsgtSwBmRyzuKiNPdWolbInQpHCL={}
    if fYqsgtSwBmRyzuKiNPdWolbInQpHCc=='movie' and fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_settings_addinfo()==fYqsgtSwBmRyzuKiNPdWolbInQpHOG:
     fYqsgtSwBmRyzuKiNPdWolbInQpHXe=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.GetMovieInfoList([fYqsgtSwBmRyzuKiNPdWolbInQpHXD.get('code')])
     fYqsgtSwBmRyzuKiNPdWolbInQpHCL=fYqsgtSwBmRyzuKiNPdWolbInQpHXe.get(fYqsgtSwBmRyzuKiNPdWolbInQpHXD.get('code'))
    else:
     fYqsgtSwBmRyzuKiNPdWolbInQpHCL['plot']='%s\n%s'%(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,fYqsgtSwBmRyzuKiNPdWolbInQpHCX)
    if fYqsgtSwBmRyzuKiNPdWolbInQpHCc=='vod':
     if fYqsgtSwBmRyzuKiNPdWolbInQpHEe==fYqsgtSwBmRyzuKiNPdWolbInQpHOe or fYqsgtSwBmRyzuKiNPdWolbInQpHXU==fYqsgtSwBmRyzuKiNPdWolbInQpHOD:
      fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'DEEP_LIST','contentid':fYqsgtSwBmRyzuKiNPdWolbInQpHXD.get('code'),'contentidType':'programid','uicode':'vod','page':'1'}
      fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOG
     else:
      fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'VOD','contentid':fYqsgtSwBmRyzuKiNPdWolbInQpHXU,'contentidType':'contentid','programid':fYqsgtSwBmRyzuKiNPdWolbInQpHXD.get('code'),'uicode':'vod','title':fYqsgtSwBmRyzuKiNPdWolbInQpHJX,'subtitle':fYqsgtSwBmRyzuKiNPdWolbInQpHCX,'thumbnail':fYqsgtSwBmRyzuKiNPdWolbInQpHCO}
      fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOe
    else:
     fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'MOVIE','contentid':fYqsgtSwBmRyzuKiNPdWolbInQpHXD.get('code'),'contentidType':'contentid','uicode':'movie','title':fYqsgtSwBmRyzuKiNPdWolbInQpHJX,'thumbnail':fYqsgtSwBmRyzuKiNPdWolbInQpHCO}
     fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOe
    fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel=fYqsgtSwBmRyzuKiNPdWolbInQpHCX,img=fYqsgtSwBmRyzuKiNPdWolbInQpHCO,infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHCL,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHJV,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
   fYqsgtSwBmRyzuKiNPdWolbInQpHCL={'plot':'시청목록을 삭제합니다.'}
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX='*** 시청목록 삭제 ***'
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'MYVIEW_REMOVE','genre':fYqsgtSwBmRyzuKiNPdWolbInQpHCc}
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHCL,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOe,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
   xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle,cacheToDisc=fYqsgtSwBmRyzuKiNPdWolbInQpHOe)
 def dp_Search_Group(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHJX='VOD 검색'
  fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'SEARCH_LIST','genre':'vod','page':'1'}
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  fYqsgtSwBmRyzuKiNPdWolbInQpHJX='영화 검색'
  fYqsgtSwBmRyzuKiNPdWolbInQpHJh['genre']='movie'
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle)
 def dp_Search_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.SaveCredential(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_winCredential())
  fYqsgtSwBmRyzuKiNPdWolbInQpHJU=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_settings_addinfo()
  fYqsgtSwBmRyzuKiNPdWolbInQpHJe=args.get('genre')
  fYqsgtSwBmRyzuKiNPdWolbInQpHJG =fYqsgtSwBmRyzuKiNPdWolbInQpHOU(args.get('page'))
  if 'search_key' in args:
   fYqsgtSwBmRyzuKiNPdWolbInQpHXa=args.get('search_key')
  else:
   fYqsgtSwBmRyzuKiNPdWolbInQpHXa=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not fYqsgtSwBmRyzuKiNPdWolbInQpHXa:return
  fYqsgtSwBmRyzuKiNPdWolbInQpHOE,fYqsgtSwBmRyzuKiNPdWolbInQpHCE=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.GetSearchList(fYqsgtSwBmRyzuKiNPdWolbInQpHXa,fYqsgtSwBmRyzuKiNPdWolbInQpHJe,fYqsgtSwBmRyzuKiNPdWolbInQpHJG,exclusion21=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_settings_exclusion21(),addinfoyn=fYqsgtSwBmRyzuKiNPdWolbInQpHJU)
  for fYqsgtSwBmRyzuKiNPdWolbInQpHOJ in fYqsgtSwBmRyzuKiNPdWolbInQpHOE:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX =fYqsgtSwBmRyzuKiNPdWolbInQpHOJ.get('title')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCO=fYqsgtSwBmRyzuKiNPdWolbInQpHOJ.get('thumbnail')
   fYqsgtSwBmRyzuKiNPdWolbInQpHCL=fYqsgtSwBmRyzuKiNPdWolbInQpHOJ.get('info')
   if fYqsgtSwBmRyzuKiNPdWolbInQpHJe=='movie' and fYqsgtSwBmRyzuKiNPdWolbInQpHJU==fYqsgtSwBmRyzuKiNPdWolbInQpHOG:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJX='%s (%s)'%(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHCL.get('year')))
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHCL['plot']=fYqsgtSwBmRyzuKiNPdWolbInQpHJX
   if fYqsgtSwBmRyzuKiNPdWolbInQpHJe=='vod':
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'DEEP_LIST','contentid':fYqsgtSwBmRyzuKiNPdWolbInQpHOJ.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':fYqsgtSwBmRyzuKiNPdWolbInQpHJX,'subtitle':'','thumbnail':fYqsgtSwBmRyzuKiNPdWolbInQpHCO,'viewage':fYqsgtSwBmRyzuKiNPdWolbInQpHOJ.get('viewage')}
    fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOG
   else:
    fYqsgtSwBmRyzuKiNPdWolbInQpHJh={'mode':'MOVIE','contentid':fYqsgtSwBmRyzuKiNPdWolbInQpHOJ.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':fYqsgtSwBmRyzuKiNPdWolbInQpHJX,'subtitle':'','thumbnail':fYqsgtSwBmRyzuKiNPdWolbInQpHCO,'viewage':fYqsgtSwBmRyzuKiNPdWolbInQpHOJ.get('viewage')}
    fYqsgtSwBmRyzuKiNPdWolbInQpHJV=fYqsgtSwBmRyzuKiNPdWolbInQpHOe
   if fYqsgtSwBmRyzuKiNPdWolbInQpHJh.get('viewage')=='21':fYqsgtSwBmRyzuKiNPdWolbInQpHJX+=' (%s)'%(fYqsgtSwBmRyzuKiNPdWolbInQpHJh.get('viewage'))
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel='',img=fYqsgtSwBmRyzuKiNPdWolbInQpHCO,infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHCL,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHJV,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHCE:
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['mode'] ='SEARCH_LIST' 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['genre']=fYqsgtSwBmRyzuKiNPdWolbInQpHJe 
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['page'] =fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHJG+1)
   fYqsgtSwBmRyzuKiNPdWolbInQpHJh['search_key']=fYqsgtSwBmRyzuKiNPdWolbInQpHXa
   fYqsgtSwBmRyzuKiNPdWolbInQpHJX='[B]%s >>[/B]'%'다음 페이지'
   fYqsgtSwBmRyzuKiNPdWolbInQpHCX=fYqsgtSwBmRyzuKiNPdWolbInQpHLE(fYqsgtSwBmRyzuKiNPdWolbInQpHJG+1)
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.add_dir(fYqsgtSwBmRyzuKiNPdWolbInQpHJX,sublabel=fYqsgtSwBmRyzuKiNPdWolbInQpHCX,img='',infoLabels=fYqsgtSwBmRyzuKiNPdWolbInQpHOD,isFolder=fYqsgtSwBmRyzuKiNPdWolbInQpHOG,params=fYqsgtSwBmRyzuKiNPdWolbInQpHJh)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHOa(fYqsgtSwBmRyzuKiNPdWolbInQpHOE)>0:xbmcplugin.endOfDirectory(fYqsgtSwBmRyzuKiNPdWolbInQpHEL._addon_handle)
 def Load_Watched_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,fYqsgtSwBmRyzuKiNPdWolbInQpHCc):
  try:
   fYqsgtSwBmRyzuKiNPdWolbInQpHOC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fYqsgtSwBmRyzuKiNPdWolbInQpHCc))
   fp=fYqsgtSwBmRyzuKiNPdWolbInQpHLC(fYqsgtSwBmRyzuKiNPdWolbInQpHOC,'r',-1,'utf-8')
   fYqsgtSwBmRyzuKiNPdWolbInQpHOX=fp.readlines()
   fp.close()
  except:
   fYqsgtSwBmRyzuKiNPdWolbInQpHOX=[]
  return fYqsgtSwBmRyzuKiNPdWolbInQpHOX
 def Save_Watched_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,fYqsgtSwBmRyzuKiNPdWolbInQpHCc,fYqsgtSwBmRyzuKiNPdWolbInQpHEc):
  try:
   fYqsgtSwBmRyzuKiNPdWolbInQpHOC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fYqsgtSwBmRyzuKiNPdWolbInQpHCc))
   fYqsgtSwBmRyzuKiNPdWolbInQpHOL=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.Load_Watched_List(fYqsgtSwBmRyzuKiNPdWolbInQpHCc) 
   fp=fYqsgtSwBmRyzuKiNPdWolbInQpHLC(fYqsgtSwBmRyzuKiNPdWolbInQpHOC,'w',-1,'utf-8')
   fYqsgtSwBmRyzuKiNPdWolbInQpHOh=urllib.parse.urlencode(fYqsgtSwBmRyzuKiNPdWolbInQpHEc)
   fYqsgtSwBmRyzuKiNPdWolbInQpHOh=fYqsgtSwBmRyzuKiNPdWolbInQpHOh+'\n'
   fp.write(fYqsgtSwBmRyzuKiNPdWolbInQpHOh)
   fYqsgtSwBmRyzuKiNPdWolbInQpHOV=0
   for fYqsgtSwBmRyzuKiNPdWolbInQpHOc in fYqsgtSwBmRyzuKiNPdWolbInQpHOL:
    fYqsgtSwBmRyzuKiNPdWolbInQpHOM=fYqsgtSwBmRyzuKiNPdWolbInQpHLJ(urllib.parse.parse_qsl(fYqsgtSwBmRyzuKiNPdWolbInQpHOc))
    fYqsgtSwBmRyzuKiNPdWolbInQpHOr=fYqsgtSwBmRyzuKiNPdWolbInQpHEc.get('code')
    fYqsgtSwBmRyzuKiNPdWolbInQpHOv=fYqsgtSwBmRyzuKiNPdWolbInQpHOM.get('code')
    if fYqsgtSwBmRyzuKiNPdWolbInQpHCc=='vod' and fYqsgtSwBmRyzuKiNPdWolbInQpHEL.get_settings_direct_replay()==fYqsgtSwBmRyzuKiNPdWolbInQpHOG:
     fYqsgtSwBmRyzuKiNPdWolbInQpHOr=fYqsgtSwBmRyzuKiNPdWolbInQpHEc.get('videoid')
     fYqsgtSwBmRyzuKiNPdWolbInQpHOv=fYqsgtSwBmRyzuKiNPdWolbInQpHOM.get('videoid')if fYqsgtSwBmRyzuKiNPdWolbInQpHOv!=fYqsgtSwBmRyzuKiNPdWolbInQpHOD else '-'
    if fYqsgtSwBmRyzuKiNPdWolbInQpHOr!=fYqsgtSwBmRyzuKiNPdWolbInQpHOv:
     fp.write(fYqsgtSwBmRyzuKiNPdWolbInQpHOc)
     fYqsgtSwBmRyzuKiNPdWolbInQpHOV+=1
     if fYqsgtSwBmRyzuKiNPdWolbInQpHOV>=50:break
   fp.close()
  except:
   fYqsgtSwBmRyzuKiNPdWolbInQpHOD
 def Delete_Watched_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,fYqsgtSwBmRyzuKiNPdWolbInQpHCc):
  try:
   fYqsgtSwBmRyzuKiNPdWolbInQpHOC=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fYqsgtSwBmRyzuKiNPdWolbInQpHCc))
   fp=fYqsgtSwBmRyzuKiNPdWolbInQpHLC(fYqsgtSwBmRyzuKiNPdWolbInQpHOC,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   fYqsgtSwBmRyzuKiNPdWolbInQpHOD
 def dp_WatchList_Delete(fYqsgtSwBmRyzuKiNPdWolbInQpHEL,args):
  fYqsgtSwBmRyzuKiNPdWolbInQpHCc=args.get('genre')
  fYqsgtSwBmRyzuKiNPdWolbInQpHEr=xbmcgui.Dialog()
  fYqsgtSwBmRyzuKiNPdWolbInQpHJA=fYqsgtSwBmRyzuKiNPdWolbInQpHEr.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if fYqsgtSwBmRyzuKiNPdWolbInQpHJA==fYqsgtSwBmRyzuKiNPdWolbInQpHOe:sys.exit()
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.Delete_Watched_List(fYqsgtSwBmRyzuKiNPdWolbInQpHCc)
  xbmc.executebuiltin("Container.Refresh")
 def logout(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHEr=xbmcgui.Dialog()
  fYqsgtSwBmRyzuKiNPdWolbInQpHJA=fYqsgtSwBmRyzuKiNPdWolbInQpHEr.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if fYqsgtSwBmRyzuKiNPdWolbInQpHJA==fYqsgtSwBmRyzuKiNPdWolbInQpHOe:sys.exit()
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.wininfo_clear()
  if os.path.isfile(fYqsgtSwBmRyzuKiNPdWolbInQpHEO):os.remove(fYqsgtSwBmRyzuKiNPdWolbInQpHEO)
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE=xbmcgui.Window(10000)
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE.setProperty('WAVVE_M_CREDENTIAL','')
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHOA =fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.Get_Now_Datetime()
  fYqsgtSwBmRyzuKiNPdWolbInQpHOT=fYqsgtSwBmRyzuKiNPdWolbInQpHOA+datetime.timedelta(days=fYqsgtSwBmRyzuKiNPdWolbInQpHOU(__addon__.getSetting('cache_ttl')))
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE=xbmcgui.Window(10000)
  fYqsgtSwBmRyzuKiNPdWolbInQpHOk={'wavve_token':fYqsgtSwBmRyzuKiNPdWolbInQpHJE.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':fYqsgtSwBmRyzuKiNPdWolbInQpHOT.strftime('%Y-%m-%d')}
  try: 
   fp=fYqsgtSwBmRyzuKiNPdWolbInQpHLC(fYqsgtSwBmRyzuKiNPdWolbInQpHEO,'w',-1,'utf-8')
   json.dump(fYqsgtSwBmRyzuKiNPdWolbInQpHOk,fp)
   fp.close()
  except fYqsgtSwBmRyzuKiNPdWolbInQpHLX as exception:
   fYqsgtSwBmRyzuKiNPdWolbInQpHLO(exception)
 def cookiefile_check(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHOk={}
  try: 
   fp=fYqsgtSwBmRyzuKiNPdWolbInQpHLC(fYqsgtSwBmRyzuKiNPdWolbInQpHEO,'r',-1,'utf-8')
   fYqsgtSwBmRyzuKiNPdWolbInQpHOk= json.load(fp)
   fp.close()
  except fYqsgtSwBmRyzuKiNPdWolbInQpHLX as exception:
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.wininfo_clear()
   return fYqsgtSwBmRyzuKiNPdWolbInQpHOe
  fYqsgtSwBmRyzuKiNPdWolbInQpHJM =__addon__.getSetting('id')
  fYqsgtSwBmRyzuKiNPdWolbInQpHJr =__addon__.getSetting('pw')
  fYqsgtSwBmRyzuKiNPdWolbInQpHOx =__addon__.getSetting('selected_profile')
  fYqsgtSwBmRyzuKiNPdWolbInQpHOk['wavve_id']=base64.standard_b64decode(fYqsgtSwBmRyzuKiNPdWolbInQpHOk['wavve_id']).decode('utf-8')
  fYqsgtSwBmRyzuKiNPdWolbInQpHOk['wavve_pw']=base64.standard_b64decode(fYqsgtSwBmRyzuKiNPdWolbInQpHOk['wavve_pw']).decode('utf-8')
  if fYqsgtSwBmRyzuKiNPdWolbInQpHJM!=fYqsgtSwBmRyzuKiNPdWolbInQpHOk['wavve_id']or fYqsgtSwBmRyzuKiNPdWolbInQpHJr!=fYqsgtSwBmRyzuKiNPdWolbInQpHOk['wavve_pw']or fYqsgtSwBmRyzuKiNPdWolbInQpHOx!=fYqsgtSwBmRyzuKiNPdWolbInQpHOk['wavve_profile']:
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.wininfo_clear()
   return fYqsgtSwBmRyzuKiNPdWolbInQpHOe
  fYqsgtSwBmRyzuKiNPdWolbInQpHJT =fYqsgtSwBmRyzuKiNPdWolbInQpHOU(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  fYqsgtSwBmRyzuKiNPdWolbInQpHOj=fYqsgtSwBmRyzuKiNPdWolbInQpHOk['wavve_limitdate']
  fYqsgtSwBmRyzuKiNPdWolbInQpHJk =fYqsgtSwBmRyzuKiNPdWolbInQpHOU(re.sub('-','',fYqsgtSwBmRyzuKiNPdWolbInQpHOj))
  if fYqsgtSwBmRyzuKiNPdWolbInQpHJk<fYqsgtSwBmRyzuKiNPdWolbInQpHJT:
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.wininfo_clear()
   return fYqsgtSwBmRyzuKiNPdWolbInQpHOe
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE=xbmcgui.Window(10000)
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE.setProperty('WAVVE_M_CREDENTIAL',fYqsgtSwBmRyzuKiNPdWolbInQpHOk['wavve_token'])
  fYqsgtSwBmRyzuKiNPdWolbInQpHJE.setProperty('WAVVE_M_LOGINTIME',fYqsgtSwBmRyzuKiNPdWolbInQpHOj)
  return fYqsgtSwBmRyzuKiNPdWolbInQpHOG
 def wavve_main(fYqsgtSwBmRyzuKiNPdWolbInQpHEL):
  fYqsgtSwBmRyzuKiNPdWolbInQpHCh=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params.get('mode',fYqsgtSwBmRyzuKiNPdWolbInQpHOD)
  if fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='LOGOUT':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.logout()
   return
  fYqsgtSwBmRyzuKiNPdWolbInQpHEL.login_main()
  if fYqsgtSwBmRyzuKiNPdWolbInQpHCh is fYqsgtSwBmRyzuKiNPdWolbInQpHOD:
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_Main_List()
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='GNB_LIST':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_Gnb_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='GN_LIST':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_Deeplink_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='DEEP_LIST':
   fYqsgtSwBmRyzuKiNPdWolbInQpHJe=fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params.get('uicode',fYqsgtSwBmRyzuKiNPdWolbInQpHOD)
   if fYqsgtSwBmRyzuKiNPdWolbInQpHJe in['quick','vod','program','x']:
    fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_Episodelink_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
   else:fYqsgtSwBmRyzuKiNPdWolbInQpHOD
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh in['LIVE','VOD','MOVIE']:
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.play_VIDEO(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='GN_MYVIEW':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_Myview_Group(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='MYVIEW_LIST':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_Myview_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='GENRE':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_Genre_Group(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='GENRE_LIST':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_Genre_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='WATCH':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_Watch_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='MYVIEW_REMOVE':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_WatchList_Delete(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='SEARCH':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_Search_Group(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='SEARCH_LIST':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_Search_List(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  elif fYqsgtSwBmRyzuKiNPdWolbInQpHCh=='ORDER_BY':
   fYqsgtSwBmRyzuKiNPdWolbInQpHEL.dp_setEpOrderby(fYqsgtSwBmRyzuKiNPdWolbInQpHEL.main_params)
  else:
   fYqsgtSwBmRyzuKiNPdWolbInQpHOD
# Created by pyminifier (https://github.com/liftoff/pyminifier)
