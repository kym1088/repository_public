__author__="NightRain"
eObkMTvrKtwHAnGUEYgmLpixydCzju=object
eObkMTvrKtwHAnGUEYgmLpixydCzjo=None
eObkMTvrKtwHAnGUEYgmLpixydCzjh=False
eObkMTvrKtwHAnGUEYgmLpixydCzjP=range
eObkMTvrKtwHAnGUEYgmLpixydCzjV=str
eObkMTvrKtwHAnGUEYgmLpixydCzjR=True
eObkMTvrKtwHAnGUEYgmLpixydCzjl=Exception
eObkMTvrKtwHAnGUEYgmLpixydCzjq=print
eObkMTvrKtwHAnGUEYgmLpixydCzjB=len
eObkMTvrKtwHAnGUEYgmLpixydCzjS=dict
eObkMTvrKtwHAnGUEYgmLpixydCzjD=int
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
eObkMTvrKtwHAnGUEYgmLpixydCzNQ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
class eObkMTvrKtwHAnGUEYgmLpixydCzNs(eObkMTvrKtwHAnGUEYgmLpixydCzju):
 def __init__(eObkMTvrKtwHAnGUEYgmLpixydCzNu):
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN='https://apis.pooq.co.kr'
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.APIKEY='E5F3E0D30947AA5440556471321BB6D9'
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.CREDENTIAL='none'
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.DEVICE='pc'
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.DRM='wm'
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.PARTNER='pooq'
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.POOQZONE='none'
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.REGION='kor'
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.TARGETAGE ='all'
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.HTTPTAG='https://'
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.LIST_LIMIT=30 
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.EP_LIMIT=30 
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.MV_LIMIT=24 
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.guid='none' 
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.guidtimestamp='none' 
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.DEFAULT_HEADER={'user-agent':eObkMTvrKtwHAnGUEYgmLpixydCzNQ}
 def callRequestCookies(eObkMTvrKtwHAnGUEYgmLpixydCzNu,jobtype,eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzjo,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo,redirects=eObkMTvrKtwHAnGUEYgmLpixydCzjh):
  eObkMTvrKtwHAnGUEYgmLpixydCzNj=eObkMTvrKtwHAnGUEYgmLpixydCzNu.DEFAULT_HEADER
  if headers:eObkMTvrKtwHAnGUEYgmLpixydCzNj.update(headers)
  if jobtype=='Get':
   eObkMTvrKtwHAnGUEYgmLpixydCzNo=requests.get(eObkMTvrKtwHAnGUEYgmLpixydCzNV,params=params,headers=eObkMTvrKtwHAnGUEYgmLpixydCzNj,cookies=cookies,allow_redirects=redirects)
  else:
   eObkMTvrKtwHAnGUEYgmLpixydCzNo=requests.post(eObkMTvrKtwHAnGUEYgmLpixydCzNV,data=payload,params=params,headers=eObkMTvrKtwHAnGUEYgmLpixydCzNj,cookies=cookies,allow_redirects=redirects)
  return eObkMTvrKtwHAnGUEYgmLpixydCzNo
 def SaveCredential(eObkMTvrKtwHAnGUEYgmLpixydCzNu,eObkMTvrKtwHAnGUEYgmLpixydCzNh):
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.CREDENTIAL=eObkMTvrKtwHAnGUEYgmLpixydCzNh
 def LoadCredential(eObkMTvrKtwHAnGUEYgmLpixydCzNu):
  return eObkMTvrKtwHAnGUEYgmLpixydCzNu.CREDENTIAL
 def GetDefaultParams(eObkMTvrKtwHAnGUEYgmLpixydCzNu):
  eObkMTvrKtwHAnGUEYgmLpixydCzNP={'apikey':eObkMTvrKtwHAnGUEYgmLpixydCzNu.APIKEY,'credential':eObkMTvrKtwHAnGUEYgmLpixydCzNu.CREDENTIAL,'device':eObkMTvrKtwHAnGUEYgmLpixydCzNu.DEVICE,'drm':eObkMTvrKtwHAnGUEYgmLpixydCzNu.DRM,'partner':eObkMTvrKtwHAnGUEYgmLpixydCzNu.PARTNER,'pooqzone':eObkMTvrKtwHAnGUEYgmLpixydCzNu.POOQZONE,'region':eObkMTvrKtwHAnGUEYgmLpixydCzNu.REGION,'targetage':eObkMTvrKtwHAnGUEYgmLpixydCzNu.TARGETAGE}
  return eObkMTvrKtwHAnGUEYgmLpixydCzNP
 def makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu,domain,path,query1=eObkMTvrKtwHAnGUEYgmLpixydCzjo,query2=eObkMTvrKtwHAnGUEYgmLpixydCzjo):
  eObkMTvrKtwHAnGUEYgmLpixydCzNV=domain+path
  if query1:
   eObkMTvrKtwHAnGUEYgmLpixydCzNV+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   eObkMTvrKtwHAnGUEYgmLpixydCzNV+='&%s'%urllib.parse.urlencode(query2)
  return eObkMTvrKtwHAnGUEYgmLpixydCzNV
 def GetGUID(eObkMTvrKtwHAnGUEYgmLpixydCzNu,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   eObkMTvrKtwHAnGUEYgmLpixydCzNq=eObkMTvrKtwHAnGUEYgmLpixydCzNu.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   eObkMTvrKtwHAnGUEYgmLpixydCzNB=GenerateRandomString(5)
   eObkMTvrKtwHAnGUEYgmLpixydCzNS=eObkMTvrKtwHAnGUEYgmLpixydCzNB+media+eObkMTvrKtwHAnGUEYgmLpixydCzNq
   return eObkMTvrKtwHAnGUEYgmLpixydCzNS
  def GenerateRandomString(num):
   from random import randint
   eObkMTvrKtwHAnGUEYgmLpixydCzND=""
   for i in eObkMTvrKtwHAnGUEYgmLpixydCzjP(0,num):
    s=eObkMTvrKtwHAnGUEYgmLpixydCzjV(randint(1,5))
    eObkMTvrKtwHAnGUEYgmLpixydCzND+=s
   return eObkMTvrKtwHAnGUEYgmLpixydCzND
  eObkMTvrKtwHAnGUEYgmLpixydCzNS=GenerateID(guid_str)
  eObkMTvrKtwHAnGUEYgmLpixydCzNW=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetHash(eObkMTvrKtwHAnGUEYgmLpixydCzNS)
  if guidType==2:
   eObkMTvrKtwHAnGUEYgmLpixydCzNW='%s-%s-%s-%s-%s'%(eObkMTvrKtwHAnGUEYgmLpixydCzNW[:8],eObkMTvrKtwHAnGUEYgmLpixydCzNW[8:12],eObkMTvrKtwHAnGUEYgmLpixydCzNW[12:16],eObkMTvrKtwHAnGUEYgmLpixydCzNW[16:20],eObkMTvrKtwHAnGUEYgmLpixydCzNW[20:])
  return eObkMTvrKtwHAnGUEYgmLpixydCzNW
 def GetHash(eObkMTvrKtwHAnGUEYgmLpixydCzNu,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return eObkMTvrKtwHAnGUEYgmLpixydCzjV(m.hexdigest())
 def CheckQuality(eObkMTvrKtwHAnGUEYgmLpixydCzNu,sel_qt,qt_list):
  eObkMTvrKtwHAnGUEYgmLpixydCzNX=0
  for eObkMTvrKtwHAnGUEYgmLpixydCzNf in qt_list:
   if sel_qt>=eObkMTvrKtwHAnGUEYgmLpixydCzNf:return eObkMTvrKtwHAnGUEYgmLpixydCzNf
   eObkMTvrKtwHAnGUEYgmLpixydCzNX=eObkMTvrKtwHAnGUEYgmLpixydCzNf
  return eObkMTvrKtwHAnGUEYgmLpixydCzNX
 def GetCredential(eObkMTvrKtwHAnGUEYgmLpixydCzNu,user_id,user_pw,user_pf):
  eObkMTvrKtwHAnGUEYgmLpixydCzNa=eObkMTvrKtwHAnGUEYgmLpixydCzjh
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzNI='/login'
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzNc={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Post',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzNc,params=eObkMTvrKtwHAnGUEYgmLpixydCzNP,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   eObkMTvrKtwHAnGUEYgmLpixydCzNh=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['credential']
   if user_pf!=0:
    eObkMTvrKtwHAnGUEYgmLpixydCzNc={'id':eObkMTvrKtwHAnGUEYgmLpixydCzNh,'password':'','profile':eObkMTvrKtwHAnGUEYgmLpixydCzjV(user_pf),'pushid':'','type':'credential'}
    eObkMTvrKtwHAnGUEYgmLpixydCzNP['credential']=eObkMTvrKtwHAnGUEYgmLpixydCzNh 
    eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Post',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzNc,params=eObkMTvrKtwHAnGUEYgmLpixydCzNP,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
    eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
    eObkMTvrKtwHAnGUEYgmLpixydCzNh=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['credential']
   if eObkMTvrKtwHAnGUEYgmLpixydCzNh:eObkMTvrKtwHAnGUEYgmLpixydCzNa=eObkMTvrKtwHAnGUEYgmLpixydCzjR
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
   eObkMTvrKtwHAnGUEYgmLpixydCzNh='none' 
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.SaveCredential(eObkMTvrKtwHAnGUEYgmLpixydCzNh)
  return eObkMTvrKtwHAnGUEYgmLpixydCzNa
 def GetIssue(eObkMTvrKtwHAnGUEYgmLpixydCzNu):
  eObkMTvrKtwHAnGUEYgmLpixydCzsN=eObkMTvrKtwHAnGUEYgmLpixydCzjh
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzNI='/guid/issue'
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzNP,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   eObkMTvrKtwHAnGUEYgmLpixydCzsQ=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['guid']
   eObkMTvrKtwHAnGUEYgmLpixydCzsu=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['guidtimestamp']
   if eObkMTvrKtwHAnGUEYgmLpixydCzsQ:eObkMTvrKtwHAnGUEYgmLpixydCzsN=eObkMTvrKtwHAnGUEYgmLpixydCzjR
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
   eObkMTvrKtwHAnGUEYgmLpixydCzsQ='none'
   eObkMTvrKtwHAnGUEYgmLpixydCzsu='none' 
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.guid=eObkMTvrKtwHAnGUEYgmLpixydCzsQ
  eObkMTvrKtwHAnGUEYgmLpixydCzNu.guidtimestamp=eObkMTvrKtwHAnGUEYgmLpixydCzsu
  return eObkMTvrKtwHAnGUEYgmLpixydCzsN
 def GetGnList(eObkMTvrKtwHAnGUEYgmLpixydCzNu,gn_str):
  eObkMTvrKtwHAnGUEYgmLpixydCzsj=[]
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzNI='/cf/supermultisections/'+gn_str
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzNP,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   if not('multisectionlist' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ):return eObkMTvrKtwHAnGUEYgmLpixydCzjo 
   eObkMTvrKtwHAnGUEYgmLpixydCzso=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['multisectionlist']
   for eObkMTvrKtwHAnGUEYgmLpixydCzsh in eObkMTvrKtwHAnGUEYgmLpixydCzso:
    eObkMTvrKtwHAnGUEYgmLpixydCzsP=eObkMTvrKtwHAnGUEYgmLpixydCzsh['title']
    if eObkMTvrKtwHAnGUEYgmLpixydCzjB(eObkMTvrKtwHAnGUEYgmLpixydCzsP)==0:continue
    if eObkMTvrKtwHAnGUEYgmLpixydCzsP=='minor':continue 
    if re.search(u'베너',eObkMTvrKtwHAnGUEYgmLpixydCzsP):continue
    eObkMTvrKtwHAnGUEYgmLpixydCzsP=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',eObkMTvrKtwHAnGUEYgmLpixydCzsP)
    eObkMTvrKtwHAnGUEYgmLpixydCzsP=eObkMTvrKtwHAnGUEYgmLpixydCzsP.lstrip('#')
    for eObkMTvrKtwHAnGUEYgmLpixydCzsV in eObkMTvrKtwHAnGUEYgmLpixydCzsh['eventlist'][0]['bodylist']:
     if re.search(r'uicode:',eObkMTvrKtwHAnGUEYgmLpixydCzsV):
      eObkMTvrKtwHAnGUEYgmLpixydCzsR={'title':eObkMTvrKtwHAnGUEYgmLpixydCzsP,'uicode':re.sub(r'uicode:','',eObkMTvrKtwHAnGUEYgmLpixydCzsV)}
      eObkMTvrKtwHAnGUEYgmLpixydCzsj.append(eObkMTvrKtwHAnGUEYgmLpixydCzsR)
      break
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
  return eObkMTvrKtwHAnGUEYgmLpixydCzsj
 def GetDeeplinkList(eObkMTvrKtwHAnGUEYgmLpixydCzNu,gn_str,came_str,page_int,addinfoyn=eObkMTvrKtwHAnGUEYgmLpixydCzjh):
  eObkMTvrKtwHAnGUEYgmLpixydCzsl=[]
  eObkMTvrKtwHAnGUEYgmLpixydCzsq=eObkMTvrKtwHAnGUEYgmLpixydCzQh=1
  eObkMTvrKtwHAnGUEYgmLpixydCzsB='quick'
  eObkMTvrKtwHAnGUEYgmLpixydCzsS=eObkMTvrKtwHAnGUEYgmLpixydCzQu=eObkMTvrKtwHAnGUEYgmLpixydCzQj=''
  eObkMTvrKtwHAnGUEYgmLpixydCzsD=eObkMTvrKtwHAnGUEYgmLpixydCzjh
  eObkMTvrKtwHAnGUEYgmLpixydCzsW={}
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzNI='/cf/deeplink/'+gn_str
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzNP,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   if not('url' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ):return eObkMTvrKtwHAnGUEYgmLpixydCzjo 
   eObkMTvrKtwHAnGUEYgmLpixydCzsX=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['url']
   eObkMTvrKtwHAnGUEYgmLpixydCzNI=urllib.parse.urlsplit(eObkMTvrKtwHAnGUEYgmLpixydCzsX).path
   eObkMTvrKtwHAnGUEYgmLpixydCzsf=eObkMTvrKtwHAnGUEYgmLpixydCzjS(urllib.parse.parse_qsl(urllib.parse.urlsplit(eObkMTvrKtwHAnGUEYgmLpixydCzsX).query))
   eObkMTvrKtwHAnGUEYgmLpixydCzsf['came']=came_str 
   eObkMTvrKtwHAnGUEYgmLpixydCzsf['limit']=eObkMTvrKtwHAnGUEYgmLpixydCzjV(eObkMTvrKtwHAnGUEYgmLpixydCzNu.LIST_LIMIT)
   if 'contenttype' in eObkMTvrKtwHAnGUEYgmLpixydCzsf:eObkMTvrKtwHAnGUEYgmLpixydCzsB=eObkMTvrKtwHAnGUEYgmLpixydCzsf['contenttype']
   if came_str=='movie':eObkMTvrKtwHAnGUEYgmLpixydCzsf['mtype']='svod'
   if page_int!=1:
    eObkMTvrKtwHAnGUEYgmLpixydCzsf['offset']=eObkMTvrKtwHAnGUEYgmLpixydCzjV((page_int-1)*eObkMTvrKtwHAnGUEYgmLpixydCzNu.LIST_LIMIT)
    eObkMTvrKtwHAnGUEYgmLpixydCzsf['page'] =eObkMTvrKtwHAnGUEYgmLpixydCzjV(page_int)
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.HTTPTAG+eObkMTvrKtwHAnGUEYgmLpixydCzNI
   eObkMTvrKtwHAnGUEYgmLpixydCzsf.update(eObkMTvrKtwHAnGUEYgmLpixydCzNP)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzsf,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   if not('celllist' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']):return eObkMTvrKtwHAnGUEYgmLpixydCzsl,eObkMTvrKtwHAnGUEYgmLpixydCzsD 
   eObkMTvrKtwHAnGUEYgmLpixydCzsa=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['celllist']
   if(eObkMTvrKtwHAnGUEYgmLpixydCzsB=='channel' and came_str=='live'):
    if('genre' in eObkMTvrKtwHAnGUEYgmLpixydCzsf):
     eObkMTvrKtwHAnGUEYgmLpixydCzsI=eObkMTvrKtwHAnGUEYgmLpixydCzsf['genre']
    else:
     eObkMTvrKtwHAnGUEYgmLpixydCzsI='all'
    eObkMTvrKtwHAnGUEYgmLpixydCzjq("*epgcall*")
    eObkMTvrKtwHAnGUEYgmLpixydCzsW=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetEPGList(eObkMTvrKtwHAnGUEYgmLpixydCzsI)
   for eObkMTvrKtwHAnGUEYgmLpixydCzsh in eObkMTvrKtwHAnGUEYgmLpixydCzsa:
    eObkMTvrKtwHAnGUEYgmLpixydCzsc=eObkMTvrKtwHAnGUEYgmLpixydCzsJ=thumbnail=''
    eObkMTvrKtwHAnGUEYgmLpixydCzsc=eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('title_list')[0].get('text')
    if(eObkMTvrKtwHAnGUEYgmLpixydCzjB(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('title_list'))>1):
     if(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('title_list')[1].get('text').startswith('@')):
      for eObkMTvrKtwHAnGUEYgmLpixydCzsF in eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('bottom_taglist'):
       if eObkMTvrKtwHAnGUEYgmLpixydCzsF=='playy' or eObkMTvrKtwHAnGUEYgmLpixydCzsF=='won':eObkMTvrKtwHAnGUEYgmLpixydCzsJ=eObkMTvrKtwHAnGUEYgmLpixydCzsF
     else:
      eObkMTvrKtwHAnGUEYgmLpixydCzsJ=eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('title_list')[1].get('text')
      eObkMTvrKtwHAnGUEYgmLpixydCzsJ=re.sub(r'(\$O\$)|(\&[a-z]{2}\;)','',eObkMTvrKtwHAnGUEYgmLpixydCzsJ)
    if(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('thumbnail')!=''):thumbnail='https://%s'%eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('thumbnail')
    eObkMTvrKtwHAnGUEYgmLpixydCzQN=eObkMTvrKtwHAnGUEYgmLpixydCzsh['event_list'][1].get('url')
    eObkMTvrKtwHAnGUEYgmLpixydCzQs=eObkMTvrKtwHAnGUEYgmLpixydCzjS(urllib.parse.parse_qsl(urllib.parse.urlsplit(eObkMTvrKtwHAnGUEYgmLpixydCzQN).query))
    if re.search(u'programid=\&',eObkMTvrKtwHAnGUEYgmLpixydCzQN)and('contentid' in eObkMTvrKtwHAnGUEYgmLpixydCzQs):
     eObkMTvrKtwHAnGUEYgmLpixydCzsS=eObkMTvrKtwHAnGUEYgmLpixydCzQs['contentid']
     eObkMTvrKtwHAnGUEYgmLpixydCzQu='direct'
    elif('contentid' in eObkMTvrKtwHAnGUEYgmLpixydCzQs):
     eObkMTvrKtwHAnGUEYgmLpixydCzsS=eObkMTvrKtwHAnGUEYgmLpixydCzQs['contentid']
     eObkMTvrKtwHAnGUEYgmLpixydCzQu='contentid'
    elif('programid' in eObkMTvrKtwHAnGUEYgmLpixydCzQs):
     eObkMTvrKtwHAnGUEYgmLpixydCzsS=eObkMTvrKtwHAnGUEYgmLpixydCzQs['programid']
     eObkMTvrKtwHAnGUEYgmLpixydCzQu='programid'
     eObkMTvrKtwHAnGUEYgmLpixydCzsB ='program' 
    elif('channelid' in eObkMTvrKtwHAnGUEYgmLpixydCzQs):
     eObkMTvrKtwHAnGUEYgmLpixydCzsS=eObkMTvrKtwHAnGUEYgmLpixydCzQs['channelid']
     eObkMTvrKtwHAnGUEYgmLpixydCzQu='channelid'
     if eObkMTvrKtwHAnGUEYgmLpixydCzsS in eObkMTvrKtwHAnGUEYgmLpixydCzsW:
      eObkMTvrKtwHAnGUEYgmLpixydCzQj=eObkMTvrKtwHAnGUEYgmLpixydCzsW[eObkMTvrKtwHAnGUEYgmLpixydCzsS]
     else:
      eObkMTvrKtwHAnGUEYgmLpixydCzQj=''
    elif('movieid' in eObkMTvrKtwHAnGUEYgmLpixydCzQs):
     eObkMTvrKtwHAnGUEYgmLpixydCzsS=eObkMTvrKtwHAnGUEYgmLpixydCzQs['movieid']
     eObkMTvrKtwHAnGUEYgmLpixydCzQu='movieid'
     eObkMTvrKtwHAnGUEYgmLpixydCzsB='movie' 
    else:
     eObkMTvrKtwHAnGUEYgmLpixydCzsS ='-'
     eObkMTvrKtwHAnGUEYgmLpixydCzQu='-'
    eObkMTvrKtwHAnGUEYgmLpixydCzQo={}
    eObkMTvrKtwHAnGUEYgmLpixydCzQo['mpaa'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('age')
    try:
     if('channelid' in eObkMTvrKtwHAnGUEYgmLpixydCzQs):
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['mediatype'] ='video'
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['title'] ='%s < %s >'%(eObkMTvrKtwHAnGUEYgmLpixydCzsc,eObkMTvrKtwHAnGUEYgmLpixydCzsJ)
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['tvshowtitle']=eObkMTvrKtwHAnGUEYgmLpixydCzsJ
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['studio'] =eObkMTvrKtwHAnGUEYgmLpixydCzsc
     elif('movieid' in eObkMTvrKtwHAnGUEYgmLpixydCzQs):
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['mediatype'] ='movie'
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['title'] =title_list
     else:
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['mediatype'] ='episode'
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['title'] =title_list
    except:
     eObkMTvrKtwHAnGUEYgmLpixydCzjo
    eObkMTvrKtwHAnGUEYgmLpixydCzsR={'title':eObkMTvrKtwHAnGUEYgmLpixydCzsc,'subtitle':eObkMTvrKtwHAnGUEYgmLpixydCzsJ,'thumbnail':thumbnail,'uicode':eObkMTvrKtwHAnGUEYgmLpixydCzsB,'contentid':eObkMTvrKtwHAnGUEYgmLpixydCzsS,'contentidType':eObkMTvrKtwHAnGUEYgmLpixydCzQu,'viewage':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('age'),'channelepg':eObkMTvrKtwHAnGUEYgmLpixydCzQj,'info':eObkMTvrKtwHAnGUEYgmLpixydCzQo}
    eObkMTvrKtwHAnGUEYgmLpixydCzsl.append(eObkMTvrKtwHAnGUEYgmLpixydCzsR)
   eObkMTvrKtwHAnGUEYgmLpixydCzsq=eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['pagecount'])
   if eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['count']:eObkMTvrKtwHAnGUEYgmLpixydCzQh =eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['count'])
   else:eObkMTvrKtwHAnGUEYgmLpixydCzQh=eObkMTvrKtwHAnGUEYgmLpixydCzNu.LIST_LIMIT
   eObkMTvrKtwHAnGUEYgmLpixydCzsD=eObkMTvrKtwHAnGUEYgmLpixydCzsq>eObkMTvrKtwHAnGUEYgmLpixydCzQh
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
  try:
   if eObkMTvrKtwHAnGUEYgmLpixydCzsl[0].get('contentidType')=='movieid' and addinfoyn==eObkMTvrKtwHAnGUEYgmLpixydCzjR:
    eObkMTvrKtwHAnGUEYgmLpixydCzQP=[]
    eObkMTvrKtwHAnGUEYgmLpixydCzQV={}
    for eObkMTvrKtwHAnGUEYgmLpixydCzQR in eObkMTvrKtwHAnGUEYgmLpixydCzsl:eObkMTvrKtwHAnGUEYgmLpixydCzQP.append(eObkMTvrKtwHAnGUEYgmLpixydCzQR.get('contentid'))
    eObkMTvrKtwHAnGUEYgmLpixydCzQV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetMovieInfoList(eObkMTvrKtwHAnGUEYgmLpixydCzQP)
    for i in eObkMTvrKtwHAnGUEYgmLpixydCzjP(eObkMTvrKtwHAnGUEYgmLpixydCzjB(eObkMTvrKtwHAnGUEYgmLpixydCzsl)):
     eObkMTvrKtwHAnGUEYgmLpixydCzsl[i]['info']=eObkMTvrKtwHAnGUEYgmLpixydCzQV.get(eObkMTvrKtwHAnGUEYgmLpixydCzsl[i]['contentid'])
  except:
   eObkMTvrKtwHAnGUEYgmLpixydCzjo
  return(eObkMTvrKtwHAnGUEYgmLpixydCzsl,eObkMTvrKtwHAnGUEYgmLpixydCzsD)
 def GetEpisodeList(eObkMTvrKtwHAnGUEYgmLpixydCzNu,eObkMTvrKtwHAnGUEYgmLpixydCzsS,eObkMTvrKtwHAnGUEYgmLpixydCzsB,eObkMTvrKtwHAnGUEYgmLpixydCzQu,page_int,orderby='desc'):
  eObkMTvrKtwHAnGUEYgmLpixydCzQl=[]
  eObkMTvrKtwHAnGUEYgmLpixydCzsq=eObkMTvrKtwHAnGUEYgmLpixydCzQh=1
  eObkMTvrKtwHAnGUEYgmLpixydCzsD=eObkMTvrKtwHAnGUEYgmLpixydCzjh
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   if eObkMTvrKtwHAnGUEYgmLpixydCzQu=='contentid':
    eObkMTvrKtwHAnGUEYgmLpixydCzNI='/cf/vod/contents/'+eObkMTvrKtwHAnGUEYgmLpixydCzsS
    eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
    eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzNP,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
    eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
    if not('programid' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ):return eObkMTvrKtwHAnGUEYgmLpixydCzjo 
    eObkMTvrKtwHAnGUEYgmLpixydCzQB=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['programid']
   else:
    eObkMTvrKtwHAnGUEYgmLpixydCzQB=eObkMTvrKtwHAnGUEYgmLpixydCzsS
   eObkMTvrKtwHAnGUEYgmLpixydCzNI='/vod/programs-contents/'+eObkMTvrKtwHAnGUEYgmLpixydCzQB
   eObkMTvrKtwHAnGUEYgmLpixydCzsf={'limit':eObkMTvrKtwHAnGUEYgmLpixydCzNu.EP_LIMIT,'offset':eObkMTvrKtwHAnGUEYgmLpixydCzjV((page_int-1)*eObkMTvrKtwHAnGUEYgmLpixydCzNu.EP_LIMIT),'orderby':orderby}
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzsf.update(eObkMTvrKtwHAnGUEYgmLpixydCzNP)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzsf,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   if not('list' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ):return eObkMTvrKtwHAnGUEYgmLpixydCzjo 
   eObkMTvrKtwHAnGUEYgmLpixydCzQS=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['list']
   for eObkMTvrKtwHAnGUEYgmLpixydCzsh in eObkMTvrKtwHAnGUEYgmLpixydCzQS:
    eObkMTvrKtwHAnGUEYgmLpixydCzQD =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('programtitle')
    eObkMTvrKtwHAnGUEYgmLpixydCzQW ='%s회, %s(%s)'%(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('episodenumber'),eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('releasedate'),eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('releaseweekday'))
    if(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('image')!=''):tmp_thumbnail='https://%s'%eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('image')
    eObkMTvrKtwHAnGUEYgmLpixydCzQX=eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('synopsis')
    eObkMTvrKtwHAnGUEYgmLpixydCzQX=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',eObkMTvrKtwHAnGUEYgmLpixydCzQX)
    eObkMTvrKtwHAnGUEYgmLpixydCzQo={}
    eObkMTvrKtwHAnGUEYgmLpixydCzQo['title'] =eObkMTvrKtwHAnGUEYgmLpixydCzQD
    eObkMTvrKtwHAnGUEYgmLpixydCzQo['mediatype']='episode' 
    eObkMTvrKtwHAnGUEYgmLpixydCzQo['mpaa'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('targetage')
    try:
     if 'episodenumber' in eObkMTvrKtwHAnGUEYgmLpixydCzsh:eObkMTvrKtwHAnGUEYgmLpixydCzQo['episode'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('episodenumber')
     if 'releasedate' in eObkMTvrKtwHAnGUEYgmLpixydCzsh:eObkMTvrKtwHAnGUEYgmLpixydCzQo['year'] =eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('releasedate')[:4])
     if 'releasedate' in eObkMTvrKtwHAnGUEYgmLpixydCzsh:eObkMTvrKtwHAnGUEYgmLpixydCzQo['aired'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('releasedate')
     if 'playtime' in eObkMTvrKtwHAnGUEYgmLpixydCzsh:eObkMTvrKtwHAnGUEYgmLpixydCzQo['duration']=eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('playtime')
     if 'episodeactors' in eObkMTvrKtwHAnGUEYgmLpixydCzsh:
      if eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('episodeactors')!='':eObkMTvrKtwHAnGUEYgmLpixydCzQo['cast']=eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('episodeactors').split(',')
    except:
     eObkMTvrKtwHAnGUEYgmLpixydCzjo
    eObkMTvrKtwHAnGUEYgmLpixydCzQf={'title':eObkMTvrKtwHAnGUEYgmLpixydCzQD,'subtitle':eObkMTvrKtwHAnGUEYgmLpixydCzQW,'thumbnail':tmp_thumbnail,'uicode':eObkMTvrKtwHAnGUEYgmLpixydCzsB,'contentid':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('contentid'),'programid':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('programid'),'synopsis':eObkMTvrKtwHAnGUEYgmLpixydCzQX,'viewage':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('targetage'),'info':eObkMTvrKtwHAnGUEYgmLpixydCzQo}
    eObkMTvrKtwHAnGUEYgmLpixydCzQl.append(eObkMTvrKtwHAnGUEYgmLpixydCzQf)
   eObkMTvrKtwHAnGUEYgmLpixydCzsq=eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzNJ['pagecount'])
   if eObkMTvrKtwHAnGUEYgmLpixydCzNJ['count']:eObkMTvrKtwHAnGUEYgmLpixydCzQh =eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzNJ['count'])
   else:eObkMTvrKtwHAnGUEYgmLpixydCzQh=eObkMTvrKtwHAnGUEYgmLpixydCzNu.EP_LIMIT
   eObkMTvrKtwHAnGUEYgmLpixydCzsD=eObkMTvrKtwHAnGUEYgmLpixydCzsq>eObkMTvrKtwHAnGUEYgmLpixydCzQh
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
  return(eObkMTvrKtwHAnGUEYgmLpixydCzQl,eObkMTvrKtwHAnGUEYgmLpixydCzsD)
 def GetMyviewList(eObkMTvrKtwHAnGUEYgmLpixydCzNu,eObkMTvrKtwHAnGUEYgmLpixydCzsB,page_int,addinfoyn=eObkMTvrKtwHAnGUEYgmLpixydCzjh):
  eObkMTvrKtwHAnGUEYgmLpixydCzQa=[]
  eObkMTvrKtwHAnGUEYgmLpixydCzsq=eObkMTvrKtwHAnGUEYgmLpixydCzQh=1
  eObkMTvrKtwHAnGUEYgmLpixydCzsD=eObkMTvrKtwHAnGUEYgmLpixydCzjh
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzNI='/myview/contents'
   eObkMTvrKtwHAnGUEYgmLpixydCzsf={'contenttype':eObkMTvrKtwHAnGUEYgmLpixydCzsB,'limit':eObkMTvrKtwHAnGUEYgmLpixydCzNu.MV_LIMIT,'offset':eObkMTvrKtwHAnGUEYgmLpixydCzjV((page_int-1)*eObkMTvrKtwHAnGUEYgmLpixydCzNu.MV_LIMIT),'orderby':'new'}
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzsf.update(eObkMTvrKtwHAnGUEYgmLpixydCzNP)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzsf,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   if not('list' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ[0]):return eObkMTvrKtwHAnGUEYgmLpixydCzjo 
   eObkMTvrKtwHAnGUEYgmLpixydCzQI=eObkMTvrKtwHAnGUEYgmLpixydCzNJ[0]['list']
   for eObkMTvrKtwHAnGUEYgmLpixydCzsh in eObkMTvrKtwHAnGUEYgmLpixydCzQI:
    eObkMTvrKtwHAnGUEYgmLpixydCzQo={}
    if eObkMTvrKtwHAnGUEYgmLpixydCzsB=='vod':
     eObkMTvrKtwHAnGUEYgmLpixydCzQD =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('programtitle')
     eObkMTvrKtwHAnGUEYgmLpixydCzQW='%s회, %s'%(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('episodenumber'),eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('releasedate'))
     eObkMTvrKtwHAnGUEYgmLpixydCzsS=eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('contentid')
     eObkMTvrKtwHAnGUEYgmLpixydCzQB=eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('programid')
     eObkMTvrKtwHAnGUEYgmLpixydCzQo['title'] =eObkMTvrKtwHAnGUEYgmLpixydCzQD
     eObkMTvrKtwHAnGUEYgmLpixydCzQo['mediatype']='episode' 
     eObkMTvrKtwHAnGUEYgmLpixydCzQo['mpaa'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('targetage')
     try:
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['studio'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('channelname')
     except:
      eObkMTvrKtwHAnGUEYgmLpixydCzjo
     try:
      if 'releasedate' in eObkMTvrKtwHAnGUEYgmLpixydCzsh:eObkMTvrKtwHAnGUEYgmLpixydCzQo['year'] =eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('releasedate')[:4])
      if 'releasedate' in eObkMTvrKtwHAnGUEYgmLpixydCzsh:eObkMTvrKtwHAnGUEYgmLpixydCzQo['aired'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('releasedate')
     except:
      eObkMTvrKtwHAnGUEYgmLpixydCzjo
    else:
     eObkMTvrKtwHAnGUEYgmLpixydCzQD =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('title')
     eObkMTvrKtwHAnGUEYgmLpixydCzQW='' 
     eObkMTvrKtwHAnGUEYgmLpixydCzsS=eObkMTvrKtwHAnGUEYgmLpixydCzQB=eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('movieid')
     eObkMTvrKtwHAnGUEYgmLpixydCzQo['title'] =eObkMTvrKtwHAnGUEYgmLpixydCzQD
     eObkMTvrKtwHAnGUEYgmLpixydCzQo['mediatype']='movie' 
     eObkMTvrKtwHAnGUEYgmLpixydCzQo['mpaa'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('targetage')
     try:
      if 'releasedate' in eObkMTvrKtwHAnGUEYgmLpixydCzsh:eObkMTvrKtwHAnGUEYgmLpixydCzQo['year'] =eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('releasedate')[:4])
      if 'releasedate' in eObkMTvrKtwHAnGUEYgmLpixydCzsh:eObkMTvrKtwHAnGUEYgmLpixydCzQo['aired'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('releasedate')
     except:
      eObkMTvrKtwHAnGUEYgmLpixydCzjo
    if(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('image')!=''):tmp_thumbnail='https://%s'%eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('image')
    eObkMTvrKtwHAnGUEYgmLpixydCzQc={'title':eObkMTvrKtwHAnGUEYgmLpixydCzQD,'subtitle':eObkMTvrKtwHAnGUEYgmLpixydCzQW,'thumbnail':tmp_thumbnail,'uicode':eObkMTvrKtwHAnGUEYgmLpixydCzsB,'contentid':eObkMTvrKtwHAnGUEYgmLpixydCzsS,'programid':eObkMTvrKtwHAnGUEYgmLpixydCzQB,'viewage':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('targetage'),'info':eObkMTvrKtwHAnGUEYgmLpixydCzQo}
    eObkMTvrKtwHAnGUEYgmLpixydCzQa.append(eObkMTvrKtwHAnGUEYgmLpixydCzQc)
   eObkMTvrKtwHAnGUEYgmLpixydCzsq=eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzNJ[0]['pagecount'])
   if eObkMTvrKtwHAnGUEYgmLpixydCzNJ[0]['count']:eObkMTvrKtwHAnGUEYgmLpixydCzQh =eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzNJ[0]['count'])
   else:eObkMTvrKtwHAnGUEYgmLpixydCzQh=eObkMTvrKtwHAnGUEYgmLpixydCzNu.MV_LIMIT
   eObkMTvrKtwHAnGUEYgmLpixydCzsD=eObkMTvrKtwHAnGUEYgmLpixydCzsq>eObkMTvrKtwHAnGUEYgmLpixydCzQh
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
  try:
   if eObkMTvrKtwHAnGUEYgmLpixydCzsB=='movie' and addinfoyn==eObkMTvrKtwHAnGUEYgmLpixydCzjR:
    eObkMTvrKtwHAnGUEYgmLpixydCzQP=[]
    eObkMTvrKtwHAnGUEYgmLpixydCzQV={}
    for eObkMTvrKtwHAnGUEYgmLpixydCzQR in eObkMTvrKtwHAnGUEYgmLpixydCzQa:eObkMTvrKtwHAnGUEYgmLpixydCzQP.append(eObkMTvrKtwHAnGUEYgmLpixydCzQR.get('contentid'))
    eObkMTvrKtwHAnGUEYgmLpixydCzQV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetMovieInfoList(eObkMTvrKtwHAnGUEYgmLpixydCzQP)
    for i in eObkMTvrKtwHAnGUEYgmLpixydCzjP(eObkMTvrKtwHAnGUEYgmLpixydCzjB(eObkMTvrKtwHAnGUEYgmLpixydCzQa)):
     eObkMTvrKtwHAnGUEYgmLpixydCzQa[i]['info']=eObkMTvrKtwHAnGUEYgmLpixydCzQV.get(eObkMTvrKtwHAnGUEYgmLpixydCzQa[i]['contentid'])
  except:
   eObkMTvrKtwHAnGUEYgmLpixydCzjo
  return eObkMTvrKtwHAnGUEYgmLpixydCzQa,eObkMTvrKtwHAnGUEYgmLpixydCzsD
 def GetSearchList(eObkMTvrKtwHAnGUEYgmLpixydCzNu,search_key,genre,page_int,exclusion21=eObkMTvrKtwHAnGUEYgmLpixydCzjh,addinfoyn=eObkMTvrKtwHAnGUEYgmLpixydCzjh):
  eObkMTvrKtwHAnGUEYgmLpixydCzQF=[]
  eObkMTvrKtwHAnGUEYgmLpixydCzsq=eObkMTvrKtwHAnGUEYgmLpixydCzQh=1
  eObkMTvrKtwHAnGUEYgmLpixydCzsD=eObkMTvrKtwHAnGUEYgmLpixydCzjh
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzNI='/cf/search/list.js'
   eObkMTvrKtwHAnGUEYgmLpixydCzsf={'type':'program' if genre=='vod' else 'movie','keyword':search_key,'offset':eObkMTvrKtwHAnGUEYgmLpixydCzjV((page_int-1)*eObkMTvrKtwHAnGUEYgmLpixydCzNu.LIST_LIMIT),'limit':eObkMTvrKtwHAnGUEYgmLpixydCzNu.LIST_LIMIT,'orderby':'score','isplayymovie':'y'}
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzsf.update(eObkMTvrKtwHAnGUEYgmLpixydCzNP)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzsf,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   if not('celllist' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']):return eObkMTvrKtwHAnGUEYgmLpixydCzQF,eObkMTvrKtwHAnGUEYgmLpixydCzsD
   eObkMTvrKtwHAnGUEYgmLpixydCzQJ=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['celllist']
   for eObkMTvrKtwHAnGUEYgmLpixydCzsh in eObkMTvrKtwHAnGUEYgmLpixydCzQJ:
    eObkMTvrKtwHAnGUEYgmLpixydCzQo={}
    eObkMTvrKtwHAnGUEYgmLpixydCzQD =eObkMTvrKtwHAnGUEYgmLpixydCzsh['title_list'][0]['text']
    if(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('thumbnail')!=''):tmp_thumbnail='https://%s'%eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('thumbnail')
    for eObkMTvrKtwHAnGUEYgmLpixydCzsV in eObkMTvrKtwHAnGUEYgmLpixydCzsh['event_list'][0]['bodylist']:
     if re.search(r'uicode:',eObkMTvrKtwHAnGUEYgmLpixydCzsV):
      if genre=='vod':
       eObkMTvrKtwHAnGUEYgmLpixydCzsS=''
       eObkMTvrKtwHAnGUEYgmLpixydCzQB=re.sub(r'uicode:','',eObkMTvrKtwHAnGUEYgmLpixydCzsV)
       eObkMTvrKtwHAnGUEYgmLpixydCzQo['mediatype']='episode' 
      else:
       eObkMTvrKtwHAnGUEYgmLpixydCzsS=re.sub(r'uicode:','',eObkMTvrKtwHAnGUEYgmLpixydCzsV)
       eObkMTvrKtwHAnGUEYgmLpixydCzQB=''
       if eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('bottom_taglist')[0]=='playy':
        eObkMTvrKtwHAnGUEYgmLpixydCzQD+=' [playy]'
       eObkMTvrKtwHAnGUEYgmLpixydCzQo['mediatype']='movie' 
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['title'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh['title_list'][0]['text']
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['mpaa'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('age')
      eObkMTvrKtwHAnGUEYgmLpixydCzQc={'title':eObkMTvrKtwHAnGUEYgmLpixydCzQD,'thumbnail':tmp_thumbnail,'uicode':genre,'contentid':eObkMTvrKtwHAnGUEYgmLpixydCzsS,'programid':eObkMTvrKtwHAnGUEYgmLpixydCzQB,'viewage':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('age'),'info':eObkMTvrKtwHAnGUEYgmLpixydCzQo}
    if exclusion21==eObkMTvrKtwHAnGUEYgmLpixydCzjh or eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('age')!='21':
     eObkMTvrKtwHAnGUEYgmLpixydCzQF.append(eObkMTvrKtwHAnGUEYgmLpixydCzQc)
   eObkMTvrKtwHAnGUEYgmLpixydCzsq=eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['pagecount'])
   if eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['count']:eObkMTvrKtwHAnGUEYgmLpixydCzQh =eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['count'])
   else:eObkMTvrKtwHAnGUEYgmLpixydCzQh=eObkMTvrKtwHAnGUEYgmLpixydCzNu.LIST_LIMIT
   eObkMTvrKtwHAnGUEYgmLpixydCzsD=eObkMTvrKtwHAnGUEYgmLpixydCzsq>eObkMTvrKtwHAnGUEYgmLpixydCzQh
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
  try:
   if genre=='movie' and addinfoyn==eObkMTvrKtwHAnGUEYgmLpixydCzjR:
    eObkMTvrKtwHAnGUEYgmLpixydCzQP=[]
    eObkMTvrKtwHAnGUEYgmLpixydCzQV={}
    for eObkMTvrKtwHAnGUEYgmLpixydCzQR in eObkMTvrKtwHAnGUEYgmLpixydCzQF:eObkMTvrKtwHAnGUEYgmLpixydCzQP.append(eObkMTvrKtwHAnGUEYgmLpixydCzQR.get('contentid'))
    eObkMTvrKtwHAnGUEYgmLpixydCzQV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetMovieInfoList(eObkMTvrKtwHAnGUEYgmLpixydCzQP)
    for i in eObkMTvrKtwHAnGUEYgmLpixydCzjP(eObkMTvrKtwHAnGUEYgmLpixydCzjB(eObkMTvrKtwHAnGUEYgmLpixydCzQF)):
     eObkMTvrKtwHAnGUEYgmLpixydCzQF[i]['info']=eObkMTvrKtwHAnGUEYgmLpixydCzQV.get(eObkMTvrKtwHAnGUEYgmLpixydCzQF[i]['contentid'])
  except:
   eObkMTvrKtwHAnGUEYgmLpixydCzjo
  return eObkMTvrKtwHAnGUEYgmLpixydCzQF,eObkMTvrKtwHAnGUEYgmLpixydCzsD 
 def GetGenreGroup(eObkMTvrKtwHAnGUEYgmLpixydCzNu,maintype,subtype,eObkMTvrKtwHAnGUEYgmLpixydCzQq,ordernm,exclusion21=eObkMTvrKtwHAnGUEYgmLpixydCzjh):
  eObkMTvrKtwHAnGUEYgmLpixydCzuN=[]
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzNI='/cf/filters'
   eObkMTvrKtwHAnGUEYgmLpixydCzsf={'type':maintype}
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzsf.update(eObkMTvrKtwHAnGUEYgmLpixydCzNP)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzsf,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   if not(maintype in eObkMTvrKtwHAnGUEYgmLpixydCzNJ):return eObkMTvrKtwHAnGUEYgmLpixydCzjo 
   eObkMTvrKtwHAnGUEYgmLpixydCzus=eObkMTvrKtwHAnGUEYgmLpixydCzNJ[maintype]
   if subtype=='-':
    for eObkMTvrKtwHAnGUEYgmLpixydCzsh in eObkMTvrKtwHAnGUEYgmLpixydCzus:
     eObkMTvrKtwHAnGUEYgmLpixydCzuQ=eObkMTvrKtwHAnGUEYgmLpixydCzjS(urllib.parse.parse_qsl(urllib.parse.urlsplit(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('url')).query))
     eObkMTvrKtwHAnGUEYgmLpixydCzQc={'title':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('text'),'genre':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('id'),'subgenre':'-','adult':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('adult'),'broadcastid':eObkMTvrKtwHAnGUEYgmLpixydCzuQ.get('broadcastid'),'contenttype':eObkMTvrKtwHAnGUEYgmLpixydCzuQ.get('contenttype'),'uiparent':eObkMTvrKtwHAnGUEYgmLpixydCzuQ.get('uiparent'),'uirank':eObkMTvrKtwHAnGUEYgmLpixydCzuQ.get('uirank'),'uitype':eObkMTvrKtwHAnGUEYgmLpixydCzuQ.get('uitype'),'orderby':eObkMTvrKtwHAnGUEYgmLpixydCzQq,'ordernm':ordernm}
     if exclusion21==eObkMTvrKtwHAnGUEYgmLpixydCzjh or eObkMTvrKtwHAnGUEYgmLpixydCzQc.get('adult')=='n':
      eObkMTvrKtwHAnGUEYgmLpixydCzuN.append(eObkMTvrKtwHAnGUEYgmLpixydCzQc)
   else:
    for eObkMTvrKtwHAnGUEYgmLpixydCzsh in eObkMTvrKtwHAnGUEYgmLpixydCzus:
     if eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('id')==subtype:
      for tt in eObkMTvrKtwHAnGUEYgmLpixydCzsh['sublist']:
       eObkMTvrKtwHAnGUEYgmLpixydCzuQ=eObkMTvrKtwHAnGUEYgmLpixydCzjS(urlparse.parse_qsl(urlparse.urlsplit(tt.get('url')).query))
       eObkMTvrKtwHAnGUEYgmLpixydCzQc={'title':tt.get('text'),'genre':subtype,'subgenre':tt.get('id'),'adult':tt.get('adult'),'broadcastid':eObkMTvrKtwHAnGUEYgmLpixydCzuQ.get('broadcastid'),'contenttype':eObkMTvrKtwHAnGUEYgmLpixydCzuQ.get('contenttype'),'uiparent':eObkMTvrKtwHAnGUEYgmLpixydCzuQ.get('uiparent'),'uirank':eObkMTvrKtwHAnGUEYgmLpixydCzuQ.get('uirank'),'uitype':eObkMTvrKtwHAnGUEYgmLpixydCzuQ.get('uitype'),'orderby':eObkMTvrKtwHAnGUEYgmLpixydCzQq,'ordernm':ordernm}
       eObkMTvrKtwHAnGUEYgmLpixydCzuN.append(eObkMTvrKtwHAnGUEYgmLpixydCzQc)
      break
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
  return eObkMTvrKtwHAnGUEYgmLpixydCzuN
 def GetGenreGroup_sub(eObkMTvrKtwHAnGUEYgmLpixydCzNu,in_params):
  eObkMTvrKtwHAnGUEYgmLpixydCzuN=[]
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzNI='/cf/vod/newcontents'
   eObkMTvrKtwHAnGUEYgmLpixydCzsf={'WeekDay':'all','limit':'20','offset':'0','orderby':in_params.get('orderby'),'adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzsf.update(eObkMTvrKtwHAnGUEYgmLpixydCzNP)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzsf,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   if not('filter_item_list' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ['filter']['filterlist'][1]):return eObkMTvrKtwHAnGUEYgmLpixydCzjo 
   eObkMTvrKtwHAnGUEYgmLpixydCzus=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['filter']['filterlist'][1]['filter_item_list']
   for eObkMTvrKtwHAnGUEYgmLpixydCzsh in eObkMTvrKtwHAnGUEYgmLpixydCzus:
    eObkMTvrKtwHAnGUEYgmLpixydCzQc={'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype'),'adult':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('adult'),'title':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('title'),'subgenre':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('api_parameters')[eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('api_parameters').find('=')+1:],'orderby':in_params.get('orderby')}
    eObkMTvrKtwHAnGUEYgmLpixydCzuN.append(eObkMTvrKtwHAnGUEYgmLpixydCzQc)
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
  return eObkMTvrKtwHAnGUEYgmLpixydCzuN
 def GetGenreList(eObkMTvrKtwHAnGUEYgmLpixydCzNu,genre,in_params,page_int,addinfoyn=eObkMTvrKtwHAnGUEYgmLpixydCzjh):
  eObkMTvrKtwHAnGUEYgmLpixydCzuN=[]
  eObkMTvrKtwHAnGUEYgmLpixydCzsq=eObkMTvrKtwHAnGUEYgmLpixydCzQh=1
  eObkMTvrKtwHAnGUEYgmLpixydCzsD=eObkMTvrKtwHAnGUEYgmLpixydCzjh
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzsf={'WeekDay':'all','adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'orderby':in_params.get('orderby'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   if genre=='vodgenre':
    eObkMTvrKtwHAnGUEYgmLpixydCzNI='/cf/vod/newcontents'
    if in_params.get('subgenre')!='-':
     eObkMTvrKtwHAnGUEYgmLpixydCzsf['subgenre']=in_params.get('subgenre')
   else:
    eObkMTvrKtwHAnGUEYgmLpixydCzNI='/cf/movie/contents'
    eObkMTvrKtwHAnGUEYgmLpixydCzsf['price'] ='all'
    eObkMTvrKtwHAnGUEYgmLpixydCzsf['sptheme']='svod' 
   eObkMTvrKtwHAnGUEYgmLpixydCzsf['limit']=eObkMTvrKtwHAnGUEYgmLpixydCzNu.LIST_LIMIT
   eObkMTvrKtwHAnGUEYgmLpixydCzsf['offset']=eObkMTvrKtwHAnGUEYgmLpixydCzjV((page_int-1)*eObkMTvrKtwHAnGUEYgmLpixydCzNu.LIST_LIMIT)
   eObkMTvrKtwHAnGUEYgmLpixydCzsf['page'] =eObkMTvrKtwHAnGUEYgmLpixydCzjV(page_int)
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzsf.update(eObkMTvrKtwHAnGUEYgmLpixydCzNP)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzsf,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   if not('celllist' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']):return eObkMTvrKtwHAnGUEYgmLpixydCzjo 
   eObkMTvrKtwHAnGUEYgmLpixydCzus=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['celllist']
   for eObkMTvrKtwHAnGUEYgmLpixydCzsh in eObkMTvrKtwHAnGUEYgmLpixydCzus:
    eObkMTvrKtwHAnGUEYgmLpixydCzQo={}
    eObkMTvrKtwHAnGUEYgmLpixydCzQD=tmp_thumbnail=''
    eObkMTvrKtwHAnGUEYgmLpixydCzQD =eObkMTvrKtwHAnGUEYgmLpixydCzsh['title_list'][0]['text']
    if(eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('thumbnail')!=''):tmp_thumbnail='https://%s'%eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('thumbnail')
    for eObkMTvrKtwHAnGUEYgmLpixydCzsV in eObkMTvrKtwHAnGUEYgmLpixydCzsh['event_list'][0]['bodylist']:
     if re.search(r'uicode:',eObkMTvrKtwHAnGUEYgmLpixydCzsV):
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['title'] =eObkMTvrKtwHAnGUEYgmLpixydCzQD
      eObkMTvrKtwHAnGUEYgmLpixydCzQo['mpaa'] =eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('age')
      if genre=='moviegenre_svod':
       eObkMTvrKtwHAnGUEYgmLpixydCzQo['mediatype']='movie' 
      else:
       eObkMTvrKtwHAnGUEYgmLpixydCzQo['mediatype']='episode' 
      eObkMTvrKtwHAnGUEYgmLpixydCzQc={'title':eObkMTvrKtwHAnGUEYgmLpixydCzQD,'uicode':re.sub(r'uicode:','',eObkMTvrKtwHAnGUEYgmLpixydCzsV),'thumbnail':tmp_thumbnail,'viewage':eObkMTvrKtwHAnGUEYgmLpixydCzsh.get('age'),'info':eObkMTvrKtwHAnGUEYgmLpixydCzQo}
    eObkMTvrKtwHAnGUEYgmLpixydCzuN.append(eObkMTvrKtwHAnGUEYgmLpixydCzQc)
   eObkMTvrKtwHAnGUEYgmLpixydCzsq=eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['pagecount'])
   if eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['count']:eObkMTvrKtwHAnGUEYgmLpixydCzQh =eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzNJ['cell_toplist']['count'])
   else:eObkMTvrKtwHAnGUEYgmLpixydCzQh=eObkMTvrKtwHAnGUEYgmLpixydCzNu.LIST_LIMIT
   eObkMTvrKtwHAnGUEYgmLpixydCzsD=eObkMTvrKtwHAnGUEYgmLpixydCzsq>eObkMTvrKtwHAnGUEYgmLpixydCzQh
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
  try:
   if genre=='moviegenre_svod' and addinfoyn==eObkMTvrKtwHAnGUEYgmLpixydCzjR:
    eObkMTvrKtwHAnGUEYgmLpixydCzQP=[]
    eObkMTvrKtwHAnGUEYgmLpixydCzQV={}
    for eObkMTvrKtwHAnGUEYgmLpixydCzQR in eObkMTvrKtwHAnGUEYgmLpixydCzuN:eObkMTvrKtwHAnGUEYgmLpixydCzQP.append(eObkMTvrKtwHAnGUEYgmLpixydCzQR.get('uicode'))
    eObkMTvrKtwHAnGUEYgmLpixydCzQV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetMovieInfoList(eObkMTvrKtwHAnGUEYgmLpixydCzQP)
    for i in eObkMTvrKtwHAnGUEYgmLpixydCzjP(eObkMTvrKtwHAnGUEYgmLpixydCzjB(eObkMTvrKtwHAnGUEYgmLpixydCzuN)):
     eObkMTvrKtwHAnGUEYgmLpixydCzuN[i]['info']=eObkMTvrKtwHAnGUEYgmLpixydCzQV.get(eObkMTvrKtwHAnGUEYgmLpixydCzuN[i]['uicode'])
  except:
   eObkMTvrKtwHAnGUEYgmLpixydCzjo
  return eObkMTvrKtwHAnGUEYgmLpixydCzuN,eObkMTvrKtwHAnGUEYgmLpixydCzsD
 def Get_Now_Datetime(eObkMTvrKtwHAnGUEYgmLpixydCzNu):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetEPGList(eObkMTvrKtwHAnGUEYgmLpixydCzNu,genre):
  eObkMTvrKtwHAnGUEYgmLpixydCzuo={}
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzuh=eObkMTvrKtwHAnGUEYgmLpixydCzNu.Get_Now_Datetime()
   if genre=='all':
    eObkMTvrKtwHAnGUEYgmLpixydCzuP =eObkMTvrKtwHAnGUEYgmLpixydCzuh+datetime.timedelta(hours=2)
   else:
    eObkMTvrKtwHAnGUEYgmLpixydCzuP =eObkMTvrKtwHAnGUEYgmLpixydCzuh+datetime.timedelta(hours=3)
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzsf={'limit':'100','offset':'0','genre':genre,'startdatetime':eObkMTvrKtwHAnGUEYgmLpixydCzuh.strftime('%Y-%m-%d %H:%M'),'enddatetime':eObkMTvrKtwHAnGUEYgmLpixydCzuP.strftime('%Y-%m-%d %H:%M')}
   eObkMTvrKtwHAnGUEYgmLpixydCzNI='/live/epgs'
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzsf.update(eObkMTvrKtwHAnGUEYgmLpixydCzNP)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzsf,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   eObkMTvrKtwHAnGUEYgmLpixydCzuV=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['list']
   for eObkMTvrKtwHAnGUEYgmLpixydCzsh in eObkMTvrKtwHAnGUEYgmLpixydCzuV:
    eObkMTvrKtwHAnGUEYgmLpixydCzuR=''
    for eObkMTvrKtwHAnGUEYgmLpixydCzul in eObkMTvrKtwHAnGUEYgmLpixydCzsh['list']:
     if eObkMTvrKtwHAnGUEYgmLpixydCzuR:eObkMTvrKtwHAnGUEYgmLpixydCzuR+='\n'
     eObkMTvrKtwHAnGUEYgmLpixydCzuR+=eObkMTvrKtwHAnGUEYgmLpixydCzul['title'].replace('&lt;','<').replace('&gt;','>')+'\n'
     eObkMTvrKtwHAnGUEYgmLpixydCzuR+=' [%s ~ %s]'%(eObkMTvrKtwHAnGUEYgmLpixydCzul['starttime'][-5:],eObkMTvrKtwHAnGUEYgmLpixydCzul['endtime'][-5:])+'\n'
    eObkMTvrKtwHAnGUEYgmLpixydCzuo[eObkMTvrKtwHAnGUEYgmLpixydCzsh['channelid']]=eObkMTvrKtwHAnGUEYgmLpixydCzuR
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
  return eObkMTvrKtwHAnGUEYgmLpixydCzuo
 def GetMovieInfoList(eObkMTvrKtwHAnGUEYgmLpixydCzNu,movie_list):
  eObkMTvrKtwHAnGUEYgmLpixydCzuq={}
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzNP =eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzNI=eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN+'/movie/contents/'
   for eObkMTvrKtwHAnGUEYgmLpixydCzQR in movie_list:
    eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNI+eObkMTvrKtwHAnGUEYgmLpixydCzQR
    eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzNP,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
    eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
    eObkMTvrKtwHAnGUEYgmLpixydCzQo={}
    eObkMTvrKtwHAnGUEYgmLpixydCzQo['mediatype']='movie'
    eObkMTvrKtwHAnGUEYgmLpixydCzuB=[]
    for eObkMTvrKtwHAnGUEYgmLpixydCzuS in eObkMTvrKtwHAnGUEYgmLpixydCzNJ['actors']['list']:eObkMTvrKtwHAnGUEYgmLpixydCzuB.append(eObkMTvrKtwHAnGUEYgmLpixydCzuS.get('text'))
    if eObkMTvrKtwHAnGUEYgmLpixydCzuB[0]!='':eObkMTvrKtwHAnGUEYgmLpixydCzQo['cast']=eObkMTvrKtwHAnGUEYgmLpixydCzuB
    eObkMTvrKtwHAnGUEYgmLpixydCzuD=[]
    for eObkMTvrKtwHAnGUEYgmLpixydCzuW in eObkMTvrKtwHAnGUEYgmLpixydCzNJ['directors']['list']:eObkMTvrKtwHAnGUEYgmLpixydCzuD.append(eObkMTvrKtwHAnGUEYgmLpixydCzuW.get('text'))
    if eObkMTvrKtwHAnGUEYgmLpixydCzuD[0]!='':eObkMTvrKtwHAnGUEYgmLpixydCzQo['director']=eObkMTvrKtwHAnGUEYgmLpixydCzuD
    eObkMTvrKtwHAnGUEYgmLpixydCzuN=[]
    for eObkMTvrKtwHAnGUEYgmLpixydCzuX in eObkMTvrKtwHAnGUEYgmLpixydCzNJ['genre']['list']:eObkMTvrKtwHAnGUEYgmLpixydCzuN.append(eObkMTvrKtwHAnGUEYgmLpixydCzuX.get('text'))
    if eObkMTvrKtwHAnGUEYgmLpixydCzuN[0]!='':eObkMTvrKtwHAnGUEYgmLpixydCzQo['genre']=eObkMTvrKtwHAnGUEYgmLpixydCzuN
    if eObkMTvrKtwHAnGUEYgmLpixydCzNJ.get('releasedate')!='':
     eObkMTvrKtwHAnGUEYgmLpixydCzQo['year'] =eObkMTvrKtwHAnGUEYgmLpixydCzNJ['releasedate'][:4]
     eObkMTvrKtwHAnGUEYgmLpixydCzQo['aired'] =eObkMTvrKtwHAnGUEYgmLpixydCzNJ['releasedate']
    eObkMTvrKtwHAnGUEYgmLpixydCzQo['country']=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['country']
    eObkMTvrKtwHAnGUEYgmLpixydCzQo['duration']=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['playtime']
    eObkMTvrKtwHAnGUEYgmLpixydCzQo['title'] =eObkMTvrKtwHAnGUEYgmLpixydCzNJ['title']
    eObkMTvrKtwHAnGUEYgmLpixydCzQo['mpaa'] =eObkMTvrKtwHAnGUEYgmLpixydCzNJ['targetage']
    eObkMTvrKtwHAnGUEYgmLpixydCzQo['plot'] =eObkMTvrKtwHAnGUEYgmLpixydCzNJ['synopsis']
    eObkMTvrKtwHAnGUEYgmLpixydCzuq[eObkMTvrKtwHAnGUEYgmLpixydCzQR]=eObkMTvrKtwHAnGUEYgmLpixydCzQo
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   return{}
  return eObkMTvrKtwHAnGUEYgmLpixydCzuq
 def GetStreamingURL(eObkMTvrKtwHAnGUEYgmLpixydCzNu,eObkMTvrKtwHAnGUEYgmLpixydCzsS,eObkMTvrKtwHAnGUEYgmLpixydCzsB,quality_int):
  eObkMTvrKtwHAnGUEYgmLpixydCzuf=eObkMTvrKtwHAnGUEYgmLpixydCzjs=eObkMTvrKtwHAnGUEYgmLpixydCzjQ=streaming_preview=''
  eObkMTvrKtwHAnGUEYgmLpixydCzua=[]
  try:
   if eObkMTvrKtwHAnGUEYgmLpixydCzsB=='channel':
    eObkMTvrKtwHAnGUEYgmLpixydCzNI='/live/channels/'+eObkMTvrKtwHAnGUEYgmLpixydCzsS
    eObkMTvrKtwHAnGUEYgmLpixydCzuI='live'
   elif eObkMTvrKtwHAnGUEYgmLpixydCzsB=='movie':
    eObkMTvrKtwHAnGUEYgmLpixydCzNI='/cf/movie/contents/'+eObkMTvrKtwHAnGUEYgmLpixydCzsS
    eObkMTvrKtwHAnGUEYgmLpixydCzuI='movie'
   else: 
    eObkMTvrKtwHAnGUEYgmLpixydCzNI='/cf/vod/contents/'+eObkMTvrKtwHAnGUEYgmLpixydCzsS
    eObkMTvrKtwHAnGUEYgmLpixydCzuI='vod'
   eObkMTvrKtwHAnGUEYgmLpixydCzNP=eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetDefaultParams()
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzNP,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   eObkMTvrKtwHAnGUEYgmLpixydCzuc=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['qualities']['list']
   if eObkMTvrKtwHAnGUEYgmLpixydCzuc==eObkMTvrKtwHAnGUEYgmLpixydCzjo:return(eObkMTvrKtwHAnGUEYgmLpixydCzuf,eObkMTvrKtwHAnGUEYgmLpixydCzjs,eObkMTvrKtwHAnGUEYgmLpixydCzjQ,streaming_preview)
   eObkMTvrKtwHAnGUEYgmLpixydCzuF='hls'
   if 'drms' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ:
    if eObkMTvrKtwHAnGUEYgmLpixydCzNJ['drms']:
     eObkMTvrKtwHAnGUEYgmLpixydCzuF='dash'
   if 'type' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ:
    if eObkMTvrKtwHAnGUEYgmLpixydCzNJ['type']=='onair':
     eObkMTvrKtwHAnGUEYgmLpixydCzuI='onairvod'
   for eObkMTvrKtwHAnGUEYgmLpixydCzuJ in eObkMTvrKtwHAnGUEYgmLpixydCzuc:
    eObkMTvrKtwHAnGUEYgmLpixydCzua.append(eObkMTvrKtwHAnGUEYgmLpixydCzjD(eObkMTvrKtwHAnGUEYgmLpixydCzuJ.get('id').rstrip('p')))
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   return(eObkMTvrKtwHAnGUEYgmLpixydCzuf,eObkMTvrKtwHAnGUEYgmLpixydCzjs,eObkMTvrKtwHAnGUEYgmLpixydCzjQ,streaming_preview)
  try:
   eObkMTvrKtwHAnGUEYgmLpixydCzjN=eObkMTvrKtwHAnGUEYgmLpixydCzNu.CheckQuality(quality_int,eObkMTvrKtwHAnGUEYgmLpixydCzua)
   eObkMTvrKtwHAnGUEYgmLpixydCzNI='/streaming'
   eObkMTvrKtwHAnGUEYgmLpixydCzsf={'contentid':eObkMTvrKtwHAnGUEYgmLpixydCzsS,'contenttype':eObkMTvrKtwHAnGUEYgmLpixydCzuI,'action':eObkMTvrKtwHAnGUEYgmLpixydCzuF,'quality':eObkMTvrKtwHAnGUEYgmLpixydCzjV(eObkMTvrKtwHAnGUEYgmLpixydCzjN)+'p','deviceModelId':'Windows 10','guid':eObkMTvrKtwHAnGUEYgmLpixydCzNu.GetGUID(guidType=2),'lastplayid':eObkMTvrKtwHAnGUEYgmLpixydCzNu.guid,'authtype':'cookie','isabr':'y','ishevc':'n'}
   eObkMTvrKtwHAnGUEYgmLpixydCzNV=eObkMTvrKtwHAnGUEYgmLpixydCzNu.makeurl(eObkMTvrKtwHAnGUEYgmLpixydCzNu.API_DOMAIN,eObkMTvrKtwHAnGUEYgmLpixydCzNI)
   eObkMTvrKtwHAnGUEYgmLpixydCzsf.update(eObkMTvrKtwHAnGUEYgmLpixydCzNP)
   eObkMTvrKtwHAnGUEYgmLpixydCzNF=eObkMTvrKtwHAnGUEYgmLpixydCzNu.callRequestCookies('Get',eObkMTvrKtwHAnGUEYgmLpixydCzNV,payload=eObkMTvrKtwHAnGUEYgmLpixydCzjo,params=eObkMTvrKtwHAnGUEYgmLpixydCzsf,headers=eObkMTvrKtwHAnGUEYgmLpixydCzjo,cookies=eObkMTvrKtwHAnGUEYgmLpixydCzjo)
   eObkMTvrKtwHAnGUEYgmLpixydCzNJ=json.loads(eObkMTvrKtwHAnGUEYgmLpixydCzNF.text)
   eObkMTvrKtwHAnGUEYgmLpixydCzuf=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['playurl']
   if eObkMTvrKtwHAnGUEYgmLpixydCzuf==eObkMTvrKtwHAnGUEYgmLpixydCzjo:return eObkMTvrKtwHAnGUEYgmLpixydCzjo
   eObkMTvrKtwHAnGUEYgmLpixydCzjs=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['awscookie']
   eObkMTvrKtwHAnGUEYgmLpixydCzjQ =eObkMTvrKtwHAnGUEYgmLpixydCzNJ['drm']
   if 'previewmsg' in eObkMTvrKtwHAnGUEYgmLpixydCzNJ['preview']:streaming_preview=eObkMTvrKtwHAnGUEYgmLpixydCzNJ['preview']['previewmsg']
  except eObkMTvrKtwHAnGUEYgmLpixydCzjl as exception:
   eObkMTvrKtwHAnGUEYgmLpixydCzjq(exception)
  eObkMTvrKtwHAnGUEYgmLpixydCzuf=eObkMTvrKtwHAnGUEYgmLpixydCzuf.replace('pooq.co.kr','wavve.com')
  return(eObkMTvrKtwHAnGUEYgmLpixydCzuf,eObkMTvrKtwHAnGUEYgmLpixydCzjs,eObkMTvrKtwHAnGUEYgmLpixydCzjQ,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
