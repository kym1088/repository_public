__author__="NightRain"
rEemSLGfpTAJYOxzRjHsNPbnVClgBK=object
rEemSLGfpTAJYOxzRjHsNPbnVClgBI=None
rEemSLGfpTAJYOxzRjHsNPbnVClgBX=int
rEemSLGfpTAJYOxzRjHsNPbnVClgBt=True
rEemSLGfpTAJYOxzRjHsNPbnVClgBh=False
rEemSLGfpTAJYOxzRjHsNPbnVClgBD=type
rEemSLGfpTAJYOxzRjHsNPbnVClgBd=dict
rEemSLGfpTAJYOxzRjHsNPbnVClgBo=len
rEemSLGfpTAJYOxzRjHsNPbnVClgBU=range
rEemSLGfpTAJYOxzRjHsNPbnVClgBi=str
rEemSLGfpTAJYOxzRjHsNPbnVClgBF=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
rEemSLGfpTAJYOxzRjHsNPbnVClgwu=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
rEemSLGfpTAJYOxzRjHsNPbnVClgwK=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
rEemSLGfpTAJYOxzRjHsNPbnVClgwI=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
rEemSLGfpTAJYOxzRjHsNPbnVClgwX =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
rEemSLGfpTAJYOxzRjHsNPbnVClgwt=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class rEemSLGfpTAJYOxzRjHsNPbnVClgwc(rEemSLGfpTAJYOxzRjHsNPbnVClgBK):
 def __init__(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,rEemSLGfpTAJYOxzRjHsNPbnVClgwh,rEemSLGfpTAJYOxzRjHsNPbnVClgwD,rEemSLGfpTAJYOxzRjHsNPbnVClgwd):
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_url =rEemSLGfpTAJYOxzRjHsNPbnVClgwh
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle=rEemSLGfpTAJYOxzRjHsNPbnVClgwD
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.main_params =rEemSLGfpTAJYOxzRjHsNPbnVClgwd
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj =rDfdqNkMKAevTjWXsSLUYwzHhigCbI() 
 def addon_noti(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,sting):
  try:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwU=xbmcgui.Dialog()
   rEemSLGfpTAJYOxzRjHsNPbnVClgwU.notification(__addonname__,sting)
  except:
   rEemSLGfpTAJYOxzRjHsNPbnVClgBI
 def addon_log(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,string):
  try:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwi=string.encode('utf-8','ignore')
  except:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwi='addonException: addon_log'
  rEemSLGfpTAJYOxzRjHsNPbnVClgwF=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,rEemSLGfpTAJYOxzRjHsNPbnVClgwi),level=rEemSLGfpTAJYOxzRjHsNPbnVClgwF)
 def get_keyboard_input(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,rEemSLGfpTAJYOxzRjHsNPbnVClgcD):
  rEemSLGfpTAJYOxzRjHsNPbnVClgwa=rEemSLGfpTAJYOxzRjHsNPbnVClgBI
  kb=xbmc.Keyboard()
  kb.setHeading(rEemSLGfpTAJYOxzRjHsNPbnVClgcD)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   rEemSLGfpTAJYOxzRjHsNPbnVClgwa=kb.getText()
  return rEemSLGfpTAJYOxzRjHsNPbnVClgwa
 def get_settings_account(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  rEemSLGfpTAJYOxzRjHsNPbnVClgwW =__addon__.getSetting('id')
  rEemSLGfpTAJYOxzRjHsNPbnVClgwq =__addon__.getSetting('pw')
  rEemSLGfpTAJYOxzRjHsNPbnVClgwM=rEemSLGfpTAJYOxzRjHsNPbnVClgBX(__addon__.getSetting('selected_profile'))
  return(rEemSLGfpTAJYOxzRjHsNPbnVClgwW,rEemSLGfpTAJYOxzRjHsNPbnVClgwq,rEemSLGfpTAJYOxzRjHsNPbnVClgwM)
 def get_settings_totalsearch(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  rEemSLGfpTAJYOxzRjHsNPbnVClgwk =rEemSLGfpTAJYOxzRjHsNPbnVClgBt if __addon__.getSetting('local_search')=='true' else rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  rEemSLGfpTAJYOxzRjHsNPbnVClgwv=rEemSLGfpTAJYOxzRjHsNPbnVClgBt if __addon__.getSetting('local_history')=='true' else rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  rEemSLGfpTAJYOxzRjHsNPbnVClgwQ =rEemSLGfpTAJYOxzRjHsNPbnVClgBt if __addon__.getSetting('total_search')=='true' else rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  rEemSLGfpTAJYOxzRjHsNPbnVClgwy=rEemSLGfpTAJYOxzRjHsNPbnVClgBt if __addon__.getSetting('total_history')=='true' else rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  rEemSLGfpTAJYOxzRjHsNPbnVClgcw=rEemSLGfpTAJYOxzRjHsNPbnVClgBt if __addon__.getSetting('menu_bookmark')=='true' else rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  return(rEemSLGfpTAJYOxzRjHsNPbnVClgwk,rEemSLGfpTAJYOxzRjHsNPbnVClgwv,rEemSLGfpTAJYOxzRjHsNPbnVClgwQ,rEemSLGfpTAJYOxzRjHsNPbnVClgwy,rEemSLGfpTAJYOxzRjHsNPbnVClgcw)
 def get_settings_makebookmark(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  return rEemSLGfpTAJYOxzRjHsNPbnVClgBt if __addon__.getSetting('make_bookmark')=='true' else rEemSLGfpTAJYOxzRjHsNPbnVClgBh
 def get_settings_play(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  rEemSLGfpTAJYOxzRjHsNPbnVClgcu={'enable_hdr':rEemSLGfpTAJYOxzRjHsNPbnVClgBt if __addon__.getSetting('enable_hdr')=='true' else rEemSLGfpTAJYOxzRjHsNPbnVClgBh,}
  if rEemSLGfpTAJYOxzRjHsNPbnVClgcu['enable_hdr']==rEemSLGfpTAJYOxzRjHsNPbnVClgBt:
   if rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_selQuality()<1080:rEemSLGfpTAJYOxzRjHsNPbnVClgcu['enable_hdr']=rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  return(rEemSLGfpTAJYOxzRjHsNPbnVClgcu)
 def get_selQuality(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  try:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcK=[1080,720,480,360]
   rEemSLGfpTAJYOxzRjHsNPbnVClgcI=rEemSLGfpTAJYOxzRjHsNPbnVClgBX(__addon__.getSetting('selected_quality'))
   return rEemSLGfpTAJYOxzRjHsNPbnVClgcK[rEemSLGfpTAJYOxzRjHsNPbnVClgcI]
  except:
   rEemSLGfpTAJYOxzRjHsNPbnVClgBI
  return 1080 
 def get_settings_exclusion21(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  rEemSLGfpTAJYOxzRjHsNPbnVClgcX =__addon__.getSetting('exclusion21')
  if rEemSLGfpTAJYOxzRjHsNPbnVClgcX=='false':
   return rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  else:
   return rEemSLGfpTAJYOxzRjHsNPbnVClgBt
 def get_settings_direct_replay(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  rEemSLGfpTAJYOxzRjHsNPbnVClgct=rEemSLGfpTAJYOxzRjHsNPbnVClgBX(__addon__.getSetting('direct_replay'))
  if rEemSLGfpTAJYOxzRjHsNPbnVClgct==0:
   return rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  else:
   return rEemSLGfpTAJYOxzRjHsNPbnVClgBt
 def set_winEpisodeOrderby(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,rEemSLGfpTAJYOxzRjHsNPbnVClgcB):
  __addon__.setSetting('wavve_orderby',rEemSLGfpTAJYOxzRjHsNPbnVClgcB)
 def get_winEpisodeOrderby(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  rEemSLGfpTAJYOxzRjHsNPbnVClgcB=__addon__.getSetting('wavve_orderby')
  if rEemSLGfpTAJYOxzRjHsNPbnVClgcB in['',rEemSLGfpTAJYOxzRjHsNPbnVClgBI]:rEemSLGfpTAJYOxzRjHsNPbnVClgcB='desc'
  return rEemSLGfpTAJYOxzRjHsNPbnVClgcB
 def add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,label,sublabel='',img='',infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params='',isLink=rEemSLGfpTAJYOxzRjHsNPbnVClgBh,ContextMenu=rEemSLGfpTAJYOxzRjHsNPbnVClgBI):
  rEemSLGfpTAJYOxzRjHsNPbnVClgch='%s?%s'%(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_url,urllib.parse.urlencode(params))
  if sublabel:rEemSLGfpTAJYOxzRjHsNPbnVClgcD='%s < %s >'%(label,sublabel)
  else: rEemSLGfpTAJYOxzRjHsNPbnVClgcD=label
  if not img:img='DefaultFolder.png'
  rEemSLGfpTAJYOxzRjHsNPbnVClgcd=xbmcgui.ListItem(rEemSLGfpTAJYOxzRjHsNPbnVClgcD)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBD(img)==rEemSLGfpTAJYOxzRjHsNPbnVClgBd:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcd.setArt(img)
  else:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcd.setArt({'thumb':img,'poster':img})
  if infoLabels:rEemSLGfpTAJYOxzRjHsNPbnVClgcd.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcd.setProperty('IsPlayable','true')
  if ContextMenu:rEemSLGfpTAJYOxzRjHsNPbnVClgcd.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,rEemSLGfpTAJYOxzRjHsNPbnVClgch,rEemSLGfpTAJYOxzRjHsNPbnVClgcd,isFolder)
 def dp_Main_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  (rEemSLGfpTAJYOxzRjHsNPbnVClgwk,rEemSLGfpTAJYOxzRjHsNPbnVClgwv,rEemSLGfpTAJYOxzRjHsNPbnVClgwQ,rEemSLGfpTAJYOxzRjHsNPbnVClgwy,rEemSLGfpTAJYOxzRjHsNPbnVClgcw)=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_totalsearch()
  for rEemSLGfpTAJYOxzRjHsNPbnVClgco in rEemSLGfpTAJYOxzRjHsNPbnVClgwu:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD=rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('title')
   rEemSLGfpTAJYOxzRjHsNPbnVClgcU=''
   if rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('mode')=='SEARCH_GROUP' and rEemSLGfpTAJYOxzRjHsNPbnVClgwk ==rEemSLGfpTAJYOxzRjHsNPbnVClgBh:continue
   elif rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('mode')=='SEARCH_HISTORY' and rEemSLGfpTAJYOxzRjHsNPbnVClgwv==rEemSLGfpTAJYOxzRjHsNPbnVClgBh:continue
   elif rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('mode')=='TOTAL_SEARCH' and rEemSLGfpTAJYOxzRjHsNPbnVClgwQ ==rEemSLGfpTAJYOxzRjHsNPbnVClgBh:continue
   elif rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('mode')=='TOTAL_HISTORY' and rEemSLGfpTAJYOxzRjHsNPbnVClgwy==rEemSLGfpTAJYOxzRjHsNPbnVClgBh:continue
   elif rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('mode')=='MENU_BOOKMARK' and rEemSLGfpTAJYOxzRjHsNPbnVClgcw==rEemSLGfpTAJYOxzRjHsNPbnVClgBh:continue
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('mode'),'sCode':rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('sCode'),'sIndex':rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('sIndex'),'sType':rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('sType'),'suburl':rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('suburl'),'subapi':rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('subapi'),'page':rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('page'),'orderby':rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('orderby'),'ordernm':rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('ordernm')}
   if rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    rEemSLGfpTAJYOxzRjHsNPbnVClgcF=rEemSLGfpTAJYOxzRjHsNPbnVClgBh
    rEemSLGfpTAJYOxzRjHsNPbnVClgca =rEemSLGfpTAJYOxzRjHsNPbnVClgBt
   else:
    rEemSLGfpTAJYOxzRjHsNPbnVClgcF=rEemSLGfpTAJYOxzRjHsNPbnVClgBt
    rEemSLGfpTAJYOxzRjHsNPbnVClgca =rEemSLGfpTAJYOxzRjHsNPbnVClgBh
   if 'icon' in rEemSLGfpTAJYOxzRjHsNPbnVClgco:rEemSLGfpTAJYOxzRjHsNPbnVClgcU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',rEemSLGfpTAJYOxzRjHsNPbnVClgco.get('icon')) 
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img=rEemSLGfpTAJYOxzRjHsNPbnVClgcU,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgcF,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci,isLink=rEemSLGfpTAJYOxzRjHsNPbnVClgca)
  xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBt)
 def dp_Search_Group(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  if 'search_key' in args:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcM=args.get('search_key')
  else:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcM=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not rEemSLGfpTAJYOxzRjHsNPbnVClgcM:
    return
  for rEemSLGfpTAJYOxzRjHsNPbnVClgck in rEemSLGfpTAJYOxzRjHsNPbnVClgwK:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcv =rEemSLGfpTAJYOxzRjHsNPbnVClgck.get('mode')
   rEemSLGfpTAJYOxzRjHsNPbnVClgcQ=rEemSLGfpTAJYOxzRjHsNPbnVClgck.get('sType')
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD=rEemSLGfpTAJYOxzRjHsNPbnVClgck.get('title')
   (rEemSLGfpTAJYOxzRjHsNPbnVClgcy,rEemSLGfpTAJYOxzRjHsNPbnVClguw)=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_Search_List(rEemSLGfpTAJYOxzRjHsNPbnVClgcM,rEemSLGfpTAJYOxzRjHsNPbnVClgcQ,1,exclusion21=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_exclusion21())
   rEemSLGfpTAJYOxzRjHsNPbnVClguc={'plot':'검색어 : '+rEemSLGfpTAJYOxzRjHsNPbnVClgcM+'\n\n'+rEemSLGfpTAJYOxzRjHsNPbnVClgwB.Search_FreeList(rEemSLGfpTAJYOxzRjHsNPbnVClgcy)}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':rEemSLGfpTAJYOxzRjHsNPbnVClgcv,'sType':rEemSLGfpTAJYOxzRjHsNPbnVClgcQ,'search_key':rEemSLGfpTAJYOxzRjHsNPbnVClgcM,'page':'1',}
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img='',infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClguc,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgwK)>0:xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBt)
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.Save_Searched_List(rEemSLGfpTAJYOxzRjHsNPbnVClgcM)
 def Search_FreeList(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,search_list):
  rEemSLGfpTAJYOxzRjHsNPbnVClguK=''
  rEemSLGfpTAJYOxzRjHsNPbnVClguI=7
  try:
   if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(search_list)==0:return '검색결과 없음'
   for i in rEemSLGfpTAJYOxzRjHsNPbnVClgBU(rEemSLGfpTAJYOxzRjHsNPbnVClgBo(search_list)):
    if i>=rEemSLGfpTAJYOxzRjHsNPbnVClguI:
     rEemSLGfpTAJYOxzRjHsNPbnVClguK=rEemSLGfpTAJYOxzRjHsNPbnVClguK+'...'
     break
    rEemSLGfpTAJYOxzRjHsNPbnVClguK=rEemSLGfpTAJYOxzRjHsNPbnVClguK+search_list[i]['title']+'\n'
  except:
   return ''
  return rEemSLGfpTAJYOxzRjHsNPbnVClguK
 def dp_Watch_Group(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  for rEemSLGfpTAJYOxzRjHsNPbnVClguX in rEemSLGfpTAJYOxzRjHsNPbnVClgwI:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD=rEemSLGfpTAJYOxzRjHsNPbnVClguX.get('title')
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':rEemSLGfpTAJYOxzRjHsNPbnVClguX.get('mode'),'sType':rEemSLGfpTAJYOxzRjHsNPbnVClguX.get('sType')}
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img='',infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgwI)>0:xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBt)
 def dp_Search_History(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgut=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.Load_List_File('search')
  for rEemSLGfpTAJYOxzRjHsNPbnVClguB in rEemSLGfpTAJYOxzRjHsNPbnVClgut:
   rEemSLGfpTAJYOxzRjHsNPbnVClguh=rEemSLGfpTAJYOxzRjHsNPbnVClgBd(urllib.parse.parse_qsl(rEemSLGfpTAJYOxzRjHsNPbnVClguB))
   rEemSLGfpTAJYOxzRjHsNPbnVClguD=rEemSLGfpTAJYOxzRjHsNPbnVClguh.get('skey').strip()
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'SEARCH_GROUP','search_key':rEemSLGfpTAJYOxzRjHsNPbnVClguD,}
   rEemSLGfpTAJYOxzRjHsNPbnVClgud={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':rEemSLGfpTAJYOxzRjHsNPbnVClguD,'vType':'-',}
   rEemSLGfpTAJYOxzRjHsNPbnVClguo=urllib.parse.urlencode(rEemSLGfpTAJYOxzRjHsNPbnVClgud)
   rEemSLGfpTAJYOxzRjHsNPbnVClguU=[('선택된 검색어 ( %s ) 삭제'%(rEemSLGfpTAJYOxzRjHsNPbnVClguD),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClguo))]
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClguD,sublabel='',img=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci,ContextMenu=rEemSLGfpTAJYOxzRjHsNPbnVClguU)
  rEemSLGfpTAJYOxzRjHsNPbnVClgui={'plot':'검색목록 전체를 삭제합니다.'}
  rEemSLGfpTAJYOxzRjHsNPbnVClgcD='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  rEemSLGfpTAJYOxzRjHsNPbnVClgcU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img=rEemSLGfpTAJYOxzRjHsNPbnVClgcU,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBh,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci,isLink=rEemSLGfpTAJYOxzRjHsNPbnVClgBt)
  xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_Search_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgcQ =args.get('sType')
  rEemSLGfpTAJYOxzRjHsNPbnVClguF =rEemSLGfpTAJYOxzRjHsNPbnVClgBX(args.get('page'))
  if 'search_key' in args:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcM=args.get('search_key')
  else:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcM=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not rEemSLGfpTAJYOxzRjHsNPbnVClgcM:
    xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle)
    return
  rEemSLGfpTAJYOxzRjHsNPbnVClgua,rEemSLGfpTAJYOxzRjHsNPbnVClguw=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_Search_List(rEemSLGfpTAJYOxzRjHsNPbnVClgcM,rEemSLGfpTAJYOxzRjHsNPbnVClgcQ,rEemSLGfpTAJYOxzRjHsNPbnVClguF,exclusion21=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_exclusion21())
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   rEemSLGfpTAJYOxzRjHsNPbnVClguq =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('videoid')
   rEemSLGfpTAJYOxzRjHsNPbnVClguM =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('vidtype')
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('title')
   rEemSLGfpTAJYOxzRjHsNPbnVClguk=rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('thumbnail')
   rEemSLGfpTAJYOxzRjHsNPbnVClguv =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('age')
   if rEemSLGfpTAJYOxzRjHsNPbnVClguv=='18' or rEemSLGfpTAJYOxzRjHsNPbnVClguv=='19' or rEemSLGfpTAJYOxzRjHsNPbnVClguv=='21':rEemSLGfpTAJYOxzRjHsNPbnVClgcD+=' (%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClguv)
   rEemSLGfpTAJYOxzRjHsNPbnVClgui={'mediatype':'tvshow' if rEemSLGfpTAJYOxzRjHsNPbnVClgcQ=='vod' else 'movie','mpaa':rEemSLGfpTAJYOxzRjHsNPbnVClguv,'title':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'plot':rEemSLGfpTAJYOxzRjHsNPbnVClgcD}
   if rEemSLGfpTAJYOxzRjHsNPbnVClgcQ=='vod':
    rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'EPISODE_LIST','seasonid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'page':'1',}
    rEemSLGfpTAJYOxzRjHsNPbnVClgcF=rEemSLGfpTAJYOxzRjHsNPbnVClgBt
   else:
    rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'MOVIE','contentid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'title':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'thumbnail':rEemSLGfpTAJYOxzRjHsNPbnVClguk,'age':rEemSLGfpTAJYOxzRjHsNPbnVClguv,}
    rEemSLGfpTAJYOxzRjHsNPbnVClgcF=rEemSLGfpTAJYOxzRjHsNPbnVClgBh
   rEemSLGfpTAJYOxzRjHsNPbnVClguU=[]
   rEemSLGfpTAJYOxzRjHsNPbnVClguQ={'mode':'VIEW_DETAIL','values':{'videoid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'vidtype':'tvshow' if rEemSLGfpTAJYOxzRjHsNPbnVClgcQ=='vod' else 'movie','contenttype':rEemSLGfpTAJYOxzRjHsNPbnVClguM,}}
   rEemSLGfpTAJYOxzRjHsNPbnVClguy=json.dumps(rEemSLGfpTAJYOxzRjHsNPbnVClguQ,separators=(',',':'))
   rEemSLGfpTAJYOxzRjHsNPbnVClguy=base64.standard_b64encode(rEemSLGfpTAJYOxzRjHsNPbnVClguy.encode()).decode('utf-8')
   rEemSLGfpTAJYOxzRjHsNPbnVClguy=rEemSLGfpTAJYOxzRjHsNPbnVClguy.replace('+','%2B')
   rEemSLGfpTAJYOxzRjHsNPbnVClgKw='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClguy)
   rEemSLGfpTAJYOxzRjHsNPbnVClguU.append(('상세정보 조회',rEemSLGfpTAJYOxzRjHsNPbnVClgKw))
   if rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_makebookmark():
    rEemSLGfpTAJYOxzRjHsNPbnVClguQ={'videoid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'vidtype':'tvshow' if rEemSLGfpTAJYOxzRjHsNPbnVClgcQ=='vod' else 'movie','vtitle':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'vsubtitle':'','contenttype':rEemSLGfpTAJYOxzRjHsNPbnVClguM,}
    rEemSLGfpTAJYOxzRjHsNPbnVClgKc=json.dumps(rEemSLGfpTAJYOxzRjHsNPbnVClguQ)
    rEemSLGfpTAJYOxzRjHsNPbnVClgKc=urllib.parse.quote(rEemSLGfpTAJYOxzRjHsNPbnVClgKc)
    rEemSLGfpTAJYOxzRjHsNPbnVClgKw='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClgKc)
    rEemSLGfpTAJYOxzRjHsNPbnVClguU.append(('(통합) 찜 영상에 추가',rEemSLGfpTAJYOxzRjHsNPbnVClgKw))
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img=rEemSLGfpTAJYOxzRjHsNPbnVClguk,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgcF,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci,ContextMenu=rEemSLGfpTAJYOxzRjHsNPbnVClguU)
  if rEemSLGfpTAJYOxzRjHsNPbnVClguw:
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['mode'] ='SEARCH_LIST' 
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['sType']=rEemSLGfpTAJYOxzRjHsNPbnVClgcQ 
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['page'] =rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['search_key']=rEemSLGfpTAJYOxzRjHsNPbnVClgcM
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD='[B]%s >>[/B]'%'다음 페이지'
   rEemSLGfpTAJYOxzRjHsNPbnVClgKu=rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgKu,img=rEemSLGfpTAJYOxzRjHsNPbnVClgcU,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgcQ=='movie':xbmcplugin.setContent(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,'movies')
  else:xbmcplugin.setContent(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_Watch_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgcQ =args.get('sType')
  rEemSLGfpTAJYOxzRjHsNPbnVClgct=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_direct_replay()
  rEemSLGfpTAJYOxzRjHsNPbnVClgua=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.Load_List_File(rEemSLGfpTAJYOxzRjHsNPbnVClgcQ)
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   rEemSLGfpTAJYOxzRjHsNPbnVClguh=rEemSLGfpTAJYOxzRjHsNPbnVClgBd(urllib.parse.parse_qsl(rEemSLGfpTAJYOxzRjHsNPbnVClguW))
   rEemSLGfpTAJYOxzRjHsNPbnVClgKI =rEemSLGfpTAJYOxzRjHsNPbnVClguh.get('code').strip()
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD =rEemSLGfpTAJYOxzRjHsNPbnVClguh.get('title').strip()
   rEemSLGfpTAJYOxzRjHsNPbnVClgKu =rEemSLGfpTAJYOxzRjHsNPbnVClguh.get('subtitle').strip()
   if rEemSLGfpTAJYOxzRjHsNPbnVClgKu=='None':rEemSLGfpTAJYOxzRjHsNPbnVClgKu=''
   rEemSLGfpTAJYOxzRjHsNPbnVClguk=rEemSLGfpTAJYOxzRjHsNPbnVClguh.get('img').strip()
   rEemSLGfpTAJYOxzRjHsNPbnVClguq =rEemSLGfpTAJYOxzRjHsNPbnVClguh.get('videoid').strip()
   try:
    rEemSLGfpTAJYOxzRjHsNPbnVClguk=rEemSLGfpTAJYOxzRjHsNPbnVClguk.replace('\'','\"')
    rEemSLGfpTAJYOxzRjHsNPbnVClguk=json.loads(rEemSLGfpTAJYOxzRjHsNPbnVClguk)
   except:
    rEemSLGfpTAJYOxzRjHsNPbnVClgBI
   rEemSLGfpTAJYOxzRjHsNPbnVClgui={'plot':'%s\n%s'%(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,rEemSLGfpTAJYOxzRjHsNPbnVClgKu)}
   if rEemSLGfpTAJYOxzRjHsNPbnVClgcQ=='vod':
    if rEemSLGfpTAJYOxzRjHsNPbnVClgct==rEemSLGfpTAJYOxzRjHsNPbnVClgBh or rEemSLGfpTAJYOxzRjHsNPbnVClguq==rEemSLGfpTAJYOxzRjHsNPbnVClgBI:
     rEemSLGfpTAJYOxzRjHsNPbnVClgui['mediatype']='tvshow'
     rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'SEASON_LIST','videoid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'vidtype':'contentid',}
     rEemSLGfpTAJYOxzRjHsNPbnVClgcF=rEemSLGfpTAJYOxzRjHsNPbnVClgBt
    else:
     rEemSLGfpTAJYOxzRjHsNPbnVClgui['mediatype']='episode'
     rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'VOD','programid':rEemSLGfpTAJYOxzRjHsNPbnVClgKI,'contentid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'title':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'subtitle':rEemSLGfpTAJYOxzRjHsNPbnVClgKu,'thumbnail':rEemSLGfpTAJYOxzRjHsNPbnVClguk}
     rEemSLGfpTAJYOxzRjHsNPbnVClgcF=rEemSLGfpTAJYOxzRjHsNPbnVClgBh
   else:
    rEemSLGfpTAJYOxzRjHsNPbnVClgui['mediatype']='movie'
    rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'MOVIE','contentid':rEemSLGfpTAJYOxzRjHsNPbnVClgKI,'title':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'subtitle':rEemSLGfpTAJYOxzRjHsNPbnVClgKu,'thumbnail':rEemSLGfpTAJYOxzRjHsNPbnVClguk}
    rEemSLGfpTAJYOxzRjHsNPbnVClgcF=rEemSLGfpTAJYOxzRjHsNPbnVClgBh
   rEemSLGfpTAJYOxzRjHsNPbnVClgud={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':rEemSLGfpTAJYOxzRjHsNPbnVClgKI,'vType':rEemSLGfpTAJYOxzRjHsNPbnVClgcQ,}
   rEemSLGfpTAJYOxzRjHsNPbnVClguo=urllib.parse.urlencode(rEemSLGfpTAJYOxzRjHsNPbnVClgud)
   rEemSLGfpTAJYOxzRjHsNPbnVClguU=[('선택된 시청이력 ( %s ) 삭제'%(rEemSLGfpTAJYOxzRjHsNPbnVClgcD),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClguo))]
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgKu,img=rEemSLGfpTAJYOxzRjHsNPbnVClguk,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgcF,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci,ContextMenu=rEemSLGfpTAJYOxzRjHsNPbnVClguU)
  rEemSLGfpTAJYOxzRjHsNPbnVClgui={'plot':'시청목록을 삭제합니다.'}
  rEemSLGfpTAJYOxzRjHsNPbnVClgcD='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':rEemSLGfpTAJYOxzRjHsNPbnVClgcQ,}
  rEemSLGfpTAJYOxzRjHsNPbnVClgcU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img=rEemSLGfpTAJYOxzRjHsNPbnVClgcU,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBh,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci,isLink=rEemSLGfpTAJYOxzRjHsNPbnVClgBt)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgcQ=='movie':xbmcplugin.setContent(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,'movies')
  else:xbmcplugin.setContent(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def Load_List_File(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,stype): 
  try:
   if stype=='search':
    rEemSLGfpTAJYOxzRjHsNPbnVClgKX=rEemSLGfpTAJYOxzRjHsNPbnVClgwt
   elif stype in['vod','movie']:
    rEemSLGfpTAJYOxzRjHsNPbnVClgKX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=rEemSLGfpTAJYOxzRjHsNPbnVClgBF(rEemSLGfpTAJYOxzRjHsNPbnVClgKX,'r',-1,'utf-8')
   rEemSLGfpTAJYOxzRjHsNPbnVClgKt=fp.readlines()
   fp.close()
  except:
   rEemSLGfpTAJYOxzRjHsNPbnVClgKt=[]
  return rEemSLGfpTAJYOxzRjHsNPbnVClgKt
 def Save_Watched_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,rEemSLGfpTAJYOxzRjHsNPbnVClgtU,rEemSLGfpTAJYOxzRjHsNPbnVClgwd):
  try:
   rEemSLGfpTAJYOxzRjHsNPbnVClgKB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rEemSLGfpTAJYOxzRjHsNPbnVClgtU))
   rEemSLGfpTAJYOxzRjHsNPbnVClgKh=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.Load_List_File(rEemSLGfpTAJYOxzRjHsNPbnVClgtU) 
   fp=rEemSLGfpTAJYOxzRjHsNPbnVClgBF(rEemSLGfpTAJYOxzRjHsNPbnVClgKB,'w',-1,'utf-8')
   rEemSLGfpTAJYOxzRjHsNPbnVClgKD=urllib.parse.urlencode(rEemSLGfpTAJYOxzRjHsNPbnVClgwd)
   rEemSLGfpTAJYOxzRjHsNPbnVClgKD=rEemSLGfpTAJYOxzRjHsNPbnVClgKD+'\n'
   fp.write(rEemSLGfpTAJYOxzRjHsNPbnVClgKD)
   rEemSLGfpTAJYOxzRjHsNPbnVClgKd=0
   for rEemSLGfpTAJYOxzRjHsNPbnVClgKo in rEemSLGfpTAJYOxzRjHsNPbnVClgKh:
    rEemSLGfpTAJYOxzRjHsNPbnVClgKU=rEemSLGfpTAJYOxzRjHsNPbnVClgBd(urllib.parse.parse_qsl(rEemSLGfpTAJYOxzRjHsNPbnVClgKo))
    rEemSLGfpTAJYOxzRjHsNPbnVClgKi=rEemSLGfpTAJYOxzRjHsNPbnVClgwd.get('code').strip()
    rEemSLGfpTAJYOxzRjHsNPbnVClgKF=rEemSLGfpTAJYOxzRjHsNPbnVClgKU.get('code').strip()
    if rEemSLGfpTAJYOxzRjHsNPbnVClgtU=='vod' and rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_direct_replay()==rEemSLGfpTAJYOxzRjHsNPbnVClgBt:
     rEemSLGfpTAJYOxzRjHsNPbnVClgKi=rEemSLGfpTAJYOxzRjHsNPbnVClgwd.get('videoid').strip()
     rEemSLGfpTAJYOxzRjHsNPbnVClgKF=rEemSLGfpTAJYOxzRjHsNPbnVClgKU.get('videoid').strip()if rEemSLGfpTAJYOxzRjHsNPbnVClgKF!=rEemSLGfpTAJYOxzRjHsNPbnVClgBI else '-'
    if rEemSLGfpTAJYOxzRjHsNPbnVClgKi!=rEemSLGfpTAJYOxzRjHsNPbnVClgKF:
     fp.write(rEemSLGfpTAJYOxzRjHsNPbnVClgKo)
     rEemSLGfpTAJYOxzRjHsNPbnVClgKd+=1
     if rEemSLGfpTAJYOxzRjHsNPbnVClgKd>=50:break
   fp.close()
  except:
   rEemSLGfpTAJYOxzRjHsNPbnVClgBI
 def dp_History_Remove(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgKa=args.get('delType')
  rEemSLGfpTAJYOxzRjHsNPbnVClgKW =args.get('sKey')
  rEemSLGfpTAJYOxzRjHsNPbnVClgKq =args.get('vType')
  rEemSLGfpTAJYOxzRjHsNPbnVClgwU=xbmcgui.Dialog()
  if rEemSLGfpTAJYOxzRjHsNPbnVClgKa=='SEARCH_ALL':
   rEemSLGfpTAJYOxzRjHsNPbnVClgKM=rEemSLGfpTAJYOxzRjHsNPbnVClgwU.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgKa=='SEARCH_ONE':
   rEemSLGfpTAJYOxzRjHsNPbnVClgKM=rEemSLGfpTAJYOxzRjHsNPbnVClgwU.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgKa=='WATCH_ALL':
   rEemSLGfpTAJYOxzRjHsNPbnVClgKM=rEemSLGfpTAJYOxzRjHsNPbnVClgwU.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgKa=='WATCH_ONE':
   rEemSLGfpTAJYOxzRjHsNPbnVClgKM=rEemSLGfpTAJYOxzRjHsNPbnVClgwU.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if rEemSLGfpTAJYOxzRjHsNPbnVClgKM==rEemSLGfpTAJYOxzRjHsNPbnVClgBh:sys.exit()
  if rEemSLGfpTAJYOxzRjHsNPbnVClgKa=='SEARCH_ALL':
   if os.path.isfile(rEemSLGfpTAJYOxzRjHsNPbnVClgwt):os.remove(rEemSLGfpTAJYOxzRjHsNPbnVClgwt)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgKa=='SEARCH_ONE':
   try:
    rEemSLGfpTAJYOxzRjHsNPbnVClgKX=rEemSLGfpTAJYOxzRjHsNPbnVClgwt
    rEemSLGfpTAJYOxzRjHsNPbnVClgKh=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.Load_List_File('search') 
    fp=rEemSLGfpTAJYOxzRjHsNPbnVClgBF(rEemSLGfpTAJYOxzRjHsNPbnVClgKX,'w',-1,'utf-8')
    for rEemSLGfpTAJYOxzRjHsNPbnVClgKo in rEemSLGfpTAJYOxzRjHsNPbnVClgKh:
     rEemSLGfpTAJYOxzRjHsNPbnVClgKU=rEemSLGfpTAJYOxzRjHsNPbnVClgBd(urllib.parse.parse_qsl(rEemSLGfpTAJYOxzRjHsNPbnVClgKo))
     rEemSLGfpTAJYOxzRjHsNPbnVClgKk=rEemSLGfpTAJYOxzRjHsNPbnVClgKU.get('skey').strip()
     if rEemSLGfpTAJYOxzRjHsNPbnVClgKW!=rEemSLGfpTAJYOxzRjHsNPbnVClgKk:
      fp.write(rEemSLGfpTAJYOxzRjHsNPbnVClgKo)
    fp.close()
   except:
    rEemSLGfpTAJYOxzRjHsNPbnVClgBI
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgKa=='WATCH_ALL':
   rEemSLGfpTAJYOxzRjHsNPbnVClgKX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rEemSLGfpTAJYOxzRjHsNPbnVClgKq))
   if os.path.isfile(rEemSLGfpTAJYOxzRjHsNPbnVClgKX):os.remove(rEemSLGfpTAJYOxzRjHsNPbnVClgKX)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgKa=='WATCH_ONE':
   rEemSLGfpTAJYOxzRjHsNPbnVClgKX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rEemSLGfpTAJYOxzRjHsNPbnVClgKq))
   try:
    rEemSLGfpTAJYOxzRjHsNPbnVClgKh=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.Load_List_File(rEemSLGfpTAJYOxzRjHsNPbnVClgKq) 
    fp=rEemSLGfpTAJYOxzRjHsNPbnVClgBF(rEemSLGfpTAJYOxzRjHsNPbnVClgKX,'w',-1,'utf-8')
    for rEemSLGfpTAJYOxzRjHsNPbnVClgKo in rEemSLGfpTAJYOxzRjHsNPbnVClgKh:
     rEemSLGfpTAJYOxzRjHsNPbnVClgKU=rEemSLGfpTAJYOxzRjHsNPbnVClgBd(urllib.parse.parse_qsl(rEemSLGfpTAJYOxzRjHsNPbnVClgKo))
     rEemSLGfpTAJYOxzRjHsNPbnVClgKk=rEemSLGfpTAJYOxzRjHsNPbnVClgKU.get('code').strip()
     if rEemSLGfpTAJYOxzRjHsNPbnVClgKW!=rEemSLGfpTAJYOxzRjHsNPbnVClgKk:
      fp.write(rEemSLGfpTAJYOxzRjHsNPbnVClgKo)
    fp.close()
   except:
    rEemSLGfpTAJYOxzRjHsNPbnVClgBI
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,rEemSLGfpTAJYOxzRjHsNPbnVClgcM):
  try:
   rEemSLGfpTAJYOxzRjHsNPbnVClgKv=rEemSLGfpTAJYOxzRjHsNPbnVClgwt
   rEemSLGfpTAJYOxzRjHsNPbnVClgKh=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.Load_List_File('search') 
   rEemSLGfpTAJYOxzRjHsNPbnVClgKQ={'skey':rEemSLGfpTAJYOxzRjHsNPbnVClgcM.strip()}
   fp=rEemSLGfpTAJYOxzRjHsNPbnVClgBF(rEemSLGfpTAJYOxzRjHsNPbnVClgKv,'w',-1,'utf-8')
   rEemSLGfpTAJYOxzRjHsNPbnVClgKD=urllib.parse.urlencode(rEemSLGfpTAJYOxzRjHsNPbnVClgKQ)
   rEemSLGfpTAJYOxzRjHsNPbnVClgKD=rEemSLGfpTAJYOxzRjHsNPbnVClgKD+'\n'
   fp.write(rEemSLGfpTAJYOxzRjHsNPbnVClgKD)
   rEemSLGfpTAJYOxzRjHsNPbnVClgKd=0
   for rEemSLGfpTAJYOxzRjHsNPbnVClgKo in rEemSLGfpTAJYOxzRjHsNPbnVClgKh:
    rEemSLGfpTAJYOxzRjHsNPbnVClgKU=rEemSLGfpTAJYOxzRjHsNPbnVClgBd(urllib.parse.parse_qsl(rEemSLGfpTAJYOxzRjHsNPbnVClgKo))
    rEemSLGfpTAJYOxzRjHsNPbnVClgKi=rEemSLGfpTAJYOxzRjHsNPbnVClgKQ.get('skey').strip()
    rEemSLGfpTAJYOxzRjHsNPbnVClgKF=rEemSLGfpTAJYOxzRjHsNPbnVClgKU.get('skey').strip()
    if rEemSLGfpTAJYOxzRjHsNPbnVClgKi!=rEemSLGfpTAJYOxzRjHsNPbnVClgKF:
     fp.write(rEemSLGfpTAJYOxzRjHsNPbnVClgKo)
     rEemSLGfpTAJYOxzRjHsNPbnVClgKd+=1
     if rEemSLGfpTAJYOxzRjHsNPbnVClgKd>=50:break
   fp.close()
  except:
   rEemSLGfpTAJYOxzRjHsNPbnVClgBI
 def dp_Global_Search(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgcv=args.get('mode')
  if rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='TOTAL_SEARCH':
   rEemSLGfpTAJYOxzRjHsNPbnVClgKy='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   rEemSLGfpTAJYOxzRjHsNPbnVClgKy='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(rEemSLGfpTAJYOxzRjHsNPbnVClgKy)
 def dp_Bookmark_Menu(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgKy='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(rEemSLGfpTAJYOxzRjHsNPbnVClgKy)
 def login_main(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  (rEemSLGfpTAJYOxzRjHsNPbnVClgIw,rEemSLGfpTAJYOxzRjHsNPbnVClgIc,rEemSLGfpTAJYOxzRjHsNPbnVClgIu)=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_account()
  if not(rEemSLGfpTAJYOxzRjHsNPbnVClgIw and rEemSLGfpTAJYOxzRjHsNPbnVClgIc):
   rEemSLGfpTAJYOxzRjHsNPbnVClgwU=xbmcgui.Dialog()
   rEemSLGfpTAJYOxzRjHsNPbnVClgKM=rEemSLGfpTAJYOxzRjHsNPbnVClgwU.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if rEemSLGfpTAJYOxzRjHsNPbnVClgKM==rEemSLGfpTAJYOxzRjHsNPbnVClgBt:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if rEemSLGfpTAJYOxzRjHsNPbnVClgwB.cookiefile_check()==rEemSLGfpTAJYOxzRjHsNPbnVClgBt:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   rEemSLGfpTAJYOxzRjHsNPbnVClgIK=0
   while rEemSLGfpTAJYOxzRjHsNPbnVClgBt:
    rEemSLGfpTAJYOxzRjHsNPbnVClgIK+=1
    time.sleep(0.05)
    if rEemSLGfpTAJYOxzRjHsNPbnVClgIK>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  rEemSLGfpTAJYOxzRjHsNPbnVClgIX=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.GetCredential(rEemSLGfpTAJYOxzRjHsNPbnVClgIw,rEemSLGfpTAJYOxzRjHsNPbnVClgIc,rEemSLGfpTAJYOxzRjHsNPbnVClgIu)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgIX:rEemSLGfpTAJYOxzRjHsNPbnVClgwB.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if rEemSLGfpTAJYOxzRjHsNPbnVClgIX==rEemSLGfpTAJYOxzRjHsNPbnVClgBh:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgcB =args.get('orderby')
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.set_winEpisodeOrderby(rEemSLGfpTAJYOxzRjHsNPbnVClgcB)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgcv =args.get('mode')
  rEemSLGfpTAJYOxzRjHsNPbnVClgIt =args.get('contentid')
  rEemSLGfpTAJYOxzRjHsNPbnVClgIB =args.get('pvrmode')
  rEemSLGfpTAJYOxzRjHsNPbnVClgIh=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_selQuality()
  rEemSLGfpTAJYOxzRjHsNPbnVClgcu =rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_play()
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.addon_log(rEemSLGfpTAJYOxzRjHsNPbnVClgIt+' - '+rEemSLGfpTAJYOxzRjHsNPbnVClgcv)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='SPORTS':
   rEemSLGfpTAJYOxzRjHsNPbnVClgID=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.GetSportsURL(rEemSLGfpTAJYOxzRjHsNPbnVClgIt,rEemSLGfpTAJYOxzRjHsNPbnVClgIh)
  else:
   rEemSLGfpTAJYOxzRjHsNPbnVClgID=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.GetStreamingURL(rEemSLGfpTAJYOxzRjHsNPbnVClgcv,rEemSLGfpTAJYOxzRjHsNPbnVClgIt,rEemSLGfpTAJYOxzRjHsNPbnVClgIh,rEemSLGfpTAJYOxzRjHsNPbnVClgIB,playOption=rEemSLGfpTAJYOxzRjHsNPbnVClgcu)
  rEemSLGfpTAJYOxzRjHsNPbnVClgId=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.WV['cookies']['credential']
  rEemSLGfpTAJYOxzRjHsNPbnVClgIo=rEemSLGfpTAJYOxzRjHsNPbnVClgID['stream_cookie']
  rEemSLGfpTAJYOxzRjHsNPbnVClgIU='{}|Cookie={}'.format(rEemSLGfpTAJYOxzRjHsNPbnVClgID['stream_url'],rEemSLGfpTAJYOxzRjHsNPbnVClgIo)
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.addon_log(rEemSLGfpTAJYOxzRjHsNPbnVClgIU)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgID['stream_url']=='':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.addon_noti(__language__(30907).encode('utf8'))
   return
  rEemSLGfpTAJYOxzRjHsNPbnVClgIi=xbmcgui.ListItem(path=rEemSLGfpTAJYOxzRjHsNPbnVClgIU)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgID['stream_drm']:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.addon_log('!!streaming_drm!!')
   rEemSLGfpTAJYOxzRjHsNPbnVClgIF=rEemSLGfpTAJYOxzRjHsNPbnVClgID['stream_drm']['customdata']
   rEemSLGfpTAJYOxzRjHsNPbnVClgIa =rEemSLGfpTAJYOxzRjHsNPbnVClgID['stream_drm']['drmhost']
   rEemSLGfpTAJYOxzRjHsNPbnVClgIW =inputstreamhelper.Helper('mpd',drm='widevine')
   if rEemSLGfpTAJYOxzRjHsNPbnVClgIW.check_inputstream():
    if rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='MOVIE':
     rEemSLGfpTAJYOxzRjHsNPbnVClgIq='https://www.wavve.com/player/movie?movieid=%s'%rEemSLGfpTAJYOxzRjHsNPbnVClgIt
    else:
     rEemSLGfpTAJYOxzRjHsNPbnVClgIq='https://www.wavve.com/player/vod?programid=%s&page=1'%rEemSLGfpTAJYOxzRjHsNPbnVClgIt
    rEemSLGfpTAJYOxzRjHsNPbnVClgIM={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':rEemSLGfpTAJYOxzRjHsNPbnVClgIF,'referer':rEemSLGfpTAJYOxzRjHsNPbnVClgIq,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.USER_AGENT,}
    rEemSLGfpTAJYOxzRjHsNPbnVClgIk=rEemSLGfpTAJYOxzRjHsNPbnVClgIa+'|'+urllib.parse.urlencode(rEemSLGfpTAJYOxzRjHsNPbnVClgIM)+'|R{SSM}|'
    rEemSLGfpTAJYOxzRjHsNPbnVClgIi.setProperty('inputstream',rEemSLGfpTAJYOxzRjHsNPbnVClgIW.inputstream_addon)
    rEemSLGfpTAJYOxzRjHsNPbnVClgIi.setProperty('inputstream.adaptive.manifest_type','mpd')
    rEemSLGfpTAJYOxzRjHsNPbnVClgIi.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    rEemSLGfpTAJYOxzRjHsNPbnVClgIi.setProperty('inputstream.adaptive.license_key',rEemSLGfpTAJYOxzRjHsNPbnVClgIk)
    rEemSLGfpTAJYOxzRjHsNPbnVClgIi.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.USER_AGENT,rEemSLGfpTAJYOxzRjHsNPbnVClgIo))
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv in['VOD','MOVIE']:
   rEemSLGfpTAJYOxzRjHsNPbnVClgIi.setContentLookup(rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
   rEemSLGfpTAJYOxzRjHsNPbnVClgIi.setMimeType('application/x-mpegURL')
   rEemSLGfpTAJYOxzRjHsNPbnVClgIi.setProperty('inputstream','inputstream.adaptive')
   rEemSLGfpTAJYOxzRjHsNPbnVClgIi.setProperty('inputstream.adaptive.manifest_type','hls')
   rEemSLGfpTAJYOxzRjHsNPbnVClgIi.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.USER_AGENT,rEemSLGfpTAJYOxzRjHsNPbnVClgIo))
  if rEemSLGfpTAJYOxzRjHsNPbnVClgID['stream_vtt']:
   rEemSLGfpTAJYOxzRjHsNPbnVClgIi.setSubtitles([rEemSLGfpTAJYOxzRjHsNPbnVClgID['stream_vtt']])
  xbmcplugin.setResolvedUrl(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,rEemSLGfpTAJYOxzRjHsNPbnVClgBt,rEemSLGfpTAJYOxzRjHsNPbnVClgIi)
  rEemSLGfpTAJYOxzRjHsNPbnVClgIv=rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  if rEemSLGfpTAJYOxzRjHsNPbnVClgID['stream_preview']:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.addon_noti(rEemSLGfpTAJYOxzRjHsNPbnVClgID['stream_preview'].encode('utf-8'))
   rEemSLGfpTAJYOxzRjHsNPbnVClgIv=rEemSLGfpTAJYOxzRjHsNPbnVClgBt
  else:
   if '/preview.' in urllib.parse.urlsplit(rEemSLGfpTAJYOxzRjHsNPbnVClgID['stream_url']).path:
    rEemSLGfpTAJYOxzRjHsNPbnVClgwB.addon_noti(__language__(30908).encode('utf8'))
    rEemSLGfpTAJYOxzRjHsNPbnVClgIv=rEemSLGfpTAJYOxzRjHsNPbnVClgBt
  try:
   rEemSLGfpTAJYOxzRjHsNPbnVClgIQ=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and rEemSLGfpTAJYOxzRjHsNPbnVClgIv==rEemSLGfpTAJYOxzRjHsNPbnVClgBh and rEemSLGfpTAJYOxzRjHsNPbnVClgIQ!='-':
    rEemSLGfpTAJYOxzRjHsNPbnVClgci={'code':rEemSLGfpTAJYOxzRjHsNPbnVClgIQ,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    rEemSLGfpTAJYOxzRjHsNPbnVClgwB.Save_Watched_List(args.get('mode').lower(),rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  except:
   rEemSLGfpTAJYOxzRjHsNPbnVClgBI
 def logout(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  rEemSLGfpTAJYOxzRjHsNPbnVClgwU=xbmcgui.Dialog()
  rEemSLGfpTAJYOxzRjHsNPbnVClgKM=rEemSLGfpTAJYOxzRjHsNPbnVClgwU.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if rEemSLGfpTAJYOxzRjHsNPbnVClgKM==rEemSLGfpTAJYOxzRjHsNPbnVClgBh:sys.exit()
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Init_WV_Total()
  if os.path.isfile(rEemSLGfpTAJYOxzRjHsNPbnVClgwX):os.remove(rEemSLGfpTAJYOxzRjHsNPbnVClgwX)
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  rEemSLGfpTAJYOxzRjHsNPbnVClgIy =rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_Now_Datetime()
  rEemSLGfpTAJYOxzRjHsNPbnVClgXw=rEemSLGfpTAJYOxzRjHsNPbnVClgIy+datetime.timedelta(days=rEemSLGfpTAJYOxzRjHsNPbnVClgBX(__addon__.getSetting('cache_ttl')))
  (rEemSLGfpTAJYOxzRjHsNPbnVClgIw,rEemSLGfpTAJYOxzRjHsNPbnVClgIc,rEemSLGfpTAJYOxzRjHsNPbnVClgIu)=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_account()
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Save_session_acount(rEemSLGfpTAJYOxzRjHsNPbnVClgIw,rEemSLGfpTAJYOxzRjHsNPbnVClgIc,rEemSLGfpTAJYOxzRjHsNPbnVClgIu)
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.WV['account']['token_limit']=rEemSLGfpTAJYOxzRjHsNPbnVClgXw.strftime('%Y%m%d')
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.JsonFile_Save(rEemSLGfpTAJYOxzRjHsNPbnVClgwX,rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.WV)
 def cookiefile_check(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.WV=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.JsonFile_Load(rEemSLGfpTAJYOxzRjHsNPbnVClgwX)
  if 'account' not in rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.WV:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Init_WV_Total()
   return rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  if 'uuid' not in rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.WV.get('cookies'):
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Init_WV_Total()
   return rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  (rEemSLGfpTAJYOxzRjHsNPbnVClgXc,rEemSLGfpTAJYOxzRjHsNPbnVClgXu,rEemSLGfpTAJYOxzRjHsNPbnVClgXK)=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_account()
  (rEemSLGfpTAJYOxzRjHsNPbnVClgXI,rEemSLGfpTAJYOxzRjHsNPbnVClgXt,rEemSLGfpTAJYOxzRjHsNPbnVClgXB)=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Load_session_acount()
  if rEemSLGfpTAJYOxzRjHsNPbnVClgXc!=rEemSLGfpTAJYOxzRjHsNPbnVClgXI or rEemSLGfpTAJYOxzRjHsNPbnVClgXu!=rEemSLGfpTAJYOxzRjHsNPbnVClgXt or rEemSLGfpTAJYOxzRjHsNPbnVClgXK!=rEemSLGfpTAJYOxzRjHsNPbnVClgXB:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Init_WV_Total()
   return rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBX(rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>rEemSLGfpTAJYOxzRjHsNPbnVClgBX(rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.WV['account']['token_limit']):
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Init_WV_Total()
   return rEemSLGfpTAJYOxzRjHsNPbnVClgBh
  return rEemSLGfpTAJYOxzRjHsNPbnVClgBt
 def dp_LiveCatagory_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgXh =args.get('sCode')
  rEemSLGfpTAJYOxzRjHsNPbnVClgXD=args.get('sIndex')
  rEemSLGfpTAJYOxzRjHsNPbnVClgua,rEemSLGfpTAJYOxzRjHsNPbnVClgXd=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_LiveCatagory_List(rEemSLGfpTAJYOxzRjHsNPbnVClgXh,rEemSLGfpTAJYOxzRjHsNPbnVClgXD)
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('title')
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'LIVE_LIST','genre':rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('genre'),'baseapi':rEemSLGfpTAJYOxzRjHsNPbnVClgXd}
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img='',infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgua)>0:xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_MainCatagory_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgXh =args.get('sCode')
  rEemSLGfpTAJYOxzRjHsNPbnVClgXD=args.get('sIndex')
  rEemSLGfpTAJYOxzRjHsNPbnVClgcQ =args.get('sType')
  rEemSLGfpTAJYOxzRjHsNPbnVClgua=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_MainCatagory_List(rEemSLGfpTAJYOxzRjHsNPbnVClgXh,rEemSLGfpTAJYOxzRjHsNPbnVClgXD)
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   if rEemSLGfpTAJYOxzRjHsNPbnVClgcQ=='vod':
    if rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('subtype')=='catagory':
     rEemSLGfpTAJYOxzRjHsNPbnVClgcv='PROGRAM_LIST'
    else:
     rEemSLGfpTAJYOxzRjHsNPbnVClgcv='SUPERSECTION_LIST'
   elif rEemSLGfpTAJYOxzRjHsNPbnVClgcQ=='movie':
    rEemSLGfpTAJYOxzRjHsNPbnVClgcv='MOVIE_LIST'
   else:
    rEemSLGfpTAJYOxzRjHsNPbnVClgcv=''
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD='%s (%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('title'),args.get('ordernm'))
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':rEemSLGfpTAJYOxzRjHsNPbnVClgcv,'suburl':rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('suburl'),'subapi':rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_exclusion21():
    if rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('title')=='성인' or rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('title')=='성인+' or rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('title')=='에로티시즘' or rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('title')=='19':continue
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img='',infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgua)>0:xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_Program_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgXo =args.get('subapi')
  rEemSLGfpTAJYOxzRjHsNPbnVClguF=rEemSLGfpTAJYOxzRjHsNPbnVClgBX(args.get('page'))
  rEemSLGfpTAJYOxzRjHsNPbnVClgcB =args.get('orderby')
  rEemSLGfpTAJYOxzRjHsNPbnVClgua,rEemSLGfpTAJYOxzRjHsNPbnVClguw=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_Program_List(rEemSLGfpTAJYOxzRjHsNPbnVClgXo,rEemSLGfpTAJYOxzRjHsNPbnVClguF,rEemSLGfpTAJYOxzRjHsNPbnVClgcB)
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   rEemSLGfpTAJYOxzRjHsNPbnVClguq =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('videoid')
   rEemSLGfpTAJYOxzRjHsNPbnVClguM =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('vidtype')
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('title')
   rEemSLGfpTAJYOxzRjHsNPbnVClguk=rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('thumbnail')
   rEemSLGfpTAJYOxzRjHsNPbnVClguv =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('age')
   if rEemSLGfpTAJYOxzRjHsNPbnVClguv=='18' or rEemSLGfpTAJYOxzRjHsNPbnVClguv=='19' or rEemSLGfpTAJYOxzRjHsNPbnVClguv=='21':rEemSLGfpTAJYOxzRjHsNPbnVClgcD+=' (%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClguv)
   rEemSLGfpTAJYOxzRjHsNPbnVClgui={'plot':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'mpaa':rEemSLGfpTAJYOxzRjHsNPbnVClguv,'mediatype':'tvshow',}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'SEASON_LIST','videoid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'vidtype':rEemSLGfpTAJYOxzRjHsNPbnVClguM,}
   rEemSLGfpTAJYOxzRjHsNPbnVClguU=[]
   rEemSLGfpTAJYOxzRjHsNPbnVClguQ={'mode':'VIEW_DETAIL','values':{'videoid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'vidtype':'tvshow','contenttype':rEemSLGfpTAJYOxzRjHsNPbnVClguM,}}
   rEemSLGfpTAJYOxzRjHsNPbnVClguy=json.dumps(rEemSLGfpTAJYOxzRjHsNPbnVClguQ,separators=(',',':'))
   rEemSLGfpTAJYOxzRjHsNPbnVClguy=base64.standard_b64encode(rEemSLGfpTAJYOxzRjHsNPbnVClguy.encode()).decode('utf-8')
   rEemSLGfpTAJYOxzRjHsNPbnVClguy=rEemSLGfpTAJYOxzRjHsNPbnVClguy.replace('+','%2B')
   rEemSLGfpTAJYOxzRjHsNPbnVClgKw='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClguy)
   rEemSLGfpTAJYOxzRjHsNPbnVClguU.append(('상세정보 조회',rEemSLGfpTAJYOxzRjHsNPbnVClgKw))
   if rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_makebookmark():
    rEemSLGfpTAJYOxzRjHsNPbnVClguQ={'videoid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'vidtype':'tvshow','vtitle':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'vsubtitle':'','contenttype':rEemSLGfpTAJYOxzRjHsNPbnVClguM,}
    rEemSLGfpTAJYOxzRjHsNPbnVClgKc=json.dumps(rEemSLGfpTAJYOxzRjHsNPbnVClguQ)
    rEemSLGfpTAJYOxzRjHsNPbnVClgKc=urllib.parse.quote(rEemSLGfpTAJYOxzRjHsNPbnVClgKc)
    rEemSLGfpTAJYOxzRjHsNPbnVClgKw='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClgKc)
    rEemSLGfpTAJYOxzRjHsNPbnVClguU.append(('(통합) 찜 영상에 추가',rEemSLGfpTAJYOxzRjHsNPbnVClgKw))
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img=rEemSLGfpTAJYOxzRjHsNPbnVClguk,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci,ContextMenu=rEemSLGfpTAJYOxzRjHsNPbnVClguU)
  if rEemSLGfpTAJYOxzRjHsNPbnVClguw:
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['mode'] ='PROGRAM_LIST' 
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['subapi']=rEemSLGfpTAJYOxzRjHsNPbnVClgXo 
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['page'] =rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD='[B]%s >>[/B]'%'다음 페이지'
   rEemSLGfpTAJYOxzRjHsNPbnVClgKu=rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgKu,img=rEemSLGfpTAJYOxzRjHsNPbnVClgcU,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  xbmcplugin.setContent(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,'tvshows')
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgua)>0:xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_Season_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClguq=args.get('videoid')
  rEemSLGfpTAJYOxzRjHsNPbnVClguM=args.get('vidtype')
  if rEemSLGfpTAJYOxzRjHsNPbnVClguM=='contentid':
   rEemSLGfpTAJYOxzRjHsNPbnVClgIt=rEemSLGfpTAJYOxzRjHsNPbnVClguq
   rEemSLGfpTAJYOxzRjHsNPbnVClgXU =rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.ContentidToSeasonid(rEemSLGfpTAJYOxzRjHsNPbnVClguq)
  else:
   rEemSLGfpTAJYOxzRjHsNPbnVClgIt=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.ProgramidToContentid(rEemSLGfpTAJYOxzRjHsNPbnVClguq)
   rEemSLGfpTAJYOxzRjHsNPbnVClgXU =rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.ContentidToSeasonid(rEemSLGfpTAJYOxzRjHsNPbnVClgIt)
  rEemSLGfpTAJYOxzRjHsNPbnVClgXi=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_Season_List(rEemSLGfpTAJYOxzRjHsNPbnVClgXU)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgXi)>1:
   for rEemSLGfpTAJYOxzRjHsNPbnVClgXF in rEemSLGfpTAJYOxzRjHsNPbnVClgXi:
    rEemSLGfpTAJYOxzRjHsNPbnVClgXa=rEemSLGfpTAJYOxzRjHsNPbnVClgXF.get('season_Id')
    rEemSLGfpTAJYOxzRjHsNPbnVClgXW=rEemSLGfpTAJYOxzRjHsNPbnVClgXF.get('season_Nm')
    rEemSLGfpTAJYOxzRjHsNPbnVClgXq=rEemSLGfpTAJYOxzRjHsNPbnVClgXF.get('programNm')
    rEemSLGfpTAJYOxzRjHsNPbnVClguk=rEemSLGfpTAJYOxzRjHsNPbnVClgXF.get('thumbnail')
    rEemSLGfpTAJYOxzRjHsNPbnVClgXM =rEemSLGfpTAJYOxzRjHsNPbnVClgXF.get('synopsis')
    rEemSLGfpTAJYOxzRjHsNPbnVClgui={'mediatype':'tvshow','title':rEemSLGfpTAJYOxzRjHsNPbnVClgXW,'plot':rEemSLGfpTAJYOxzRjHsNPbnVClgXM,}
    rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'EPISODE_LIST','seasonid':rEemSLGfpTAJYOxzRjHsNPbnVClgXa,'page':'1',}
    rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgXW,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgXq,img=rEemSLGfpTAJYOxzRjHsNPbnVClguk,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci,ContextMenu=rEemSLGfpTAJYOxzRjHsNPbnVClgBI)
   xbmcplugin.setContent(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
  else:
   rEemSLGfpTAJYOxzRjHsNPbnVClgXk={'seasonid':rEemSLGfpTAJYOxzRjHsNPbnVClgXU,'page':'1',}
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Episode_List(rEemSLGfpTAJYOxzRjHsNPbnVClgXk)
 def dp_Episode_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgXU =args.get('seasonid')
  rEemSLGfpTAJYOxzRjHsNPbnVClguF =rEemSLGfpTAJYOxzRjHsNPbnVClgBX(args.get('page'))
  rEemSLGfpTAJYOxzRjHsNPbnVClgua,rEemSLGfpTAJYOxzRjHsNPbnVClguw=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_Episode_List(rEemSLGfpTAJYOxzRjHsNPbnVClgXU,rEemSLGfpTAJYOxzRjHsNPbnVClguF,orderby=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_winEpisodeOrderby())
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   rEemSLGfpTAJYOxzRjHsNPbnVClgKu=rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('episodenumber')
   rEemSLGfpTAJYOxzRjHsNPbnVClgXv ='[%s]\n\n%s'%(rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('episodetitle'),rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('synopsis'))
   rEemSLGfpTAJYOxzRjHsNPbnVClgui={'mediatype':'episode','title':rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('programtitle'),'plot':rEemSLGfpTAJYOxzRjHsNPbnVClgXv,'cast':rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('episodeactors'),}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'VOD','programid':rEemSLGfpTAJYOxzRjHsNPbnVClgXU,'contentid':rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('contentid'),'thumbnail':rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('thumbnail'),'title':rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('programtitle'),'subtitle':rEemSLGfpTAJYOxzRjHsNPbnVClgKu,}
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('programtitle'),sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgKu,img=rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('thumbnail'),infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBh,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClguF==1:
   rEemSLGfpTAJYOxzRjHsNPbnVClgui={'plot':'정렬순서를 변경합니다.'}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['mode'] ='ORDER_BY' 
   if rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_winEpisodeOrderby()=='desc':
    rEemSLGfpTAJYOxzRjHsNPbnVClgcD='정렬순서변경 : 최신화부터 -> 1회부터'
    rEemSLGfpTAJYOxzRjHsNPbnVClgci['orderby']='asc'
   else:
    rEemSLGfpTAJYOxzRjHsNPbnVClgcD='정렬순서변경 : 1회부터 -> 최신화부터'
    rEemSLGfpTAJYOxzRjHsNPbnVClgci['orderby']='desc'
   rEemSLGfpTAJYOxzRjHsNPbnVClgcU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img=rEemSLGfpTAJYOxzRjHsNPbnVClgcU,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBh,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci,isLink=rEemSLGfpTAJYOxzRjHsNPbnVClgBt)
  if rEemSLGfpTAJYOxzRjHsNPbnVClguw:
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['mode'] ='EPISODE_LIST' 
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['seasonid']=rEemSLGfpTAJYOxzRjHsNPbnVClgXU
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['page'] =rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD='[B]%s >>[/B]'%'다음 페이지'
   rEemSLGfpTAJYOxzRjHsNPbnVClgKu=rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgKu,img=rEemSLGfpTAJYOxzRjHsNPbnVClgcU,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  xbmcplugin.setContent(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,'episodes')
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgua)>0:xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_SuperSection_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgXQ =args.get('suburl')
  rEemSLGfpTAJYOxzRjHsNPbnVClgua=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_SuperMultiSection_List(rEemSLGfpTAJYOxzRjHsNPbnVClgXQ)
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('title')
   rEemSLGfpTAJYOxzRjHsNPbnVClgXo =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('subapi')
   rEemSLGfpTAJYOxzRjHsNPbnVClgXy=rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('cell_type')
   if rEemSLGfpTAJYOxzRjHsNPbnVClgXo.find('mtype=svod')>=0 or rEemSLGfpTAJYOxzRjHsNPbnVClgXo.find('mtype=ppv')>=0 or rEemSLGfpTAJYOxzRjHsNPbnVClgXo.find('contenttype=movie')>=0:
    rEemSLGfpTAJYOxzRjHsNPbnVClgcv='MOVIE_LIST'
   elif rEemSLGfpTAJYOxzRjHsNPbnVClgXo.find('contenttype=program')>=0:
    rEemSLGfpTAJYOxzRjHsNPbnVClgcv='PROGRAM_LIST'
   elif rEemSLGfpTAJYOxzRjHsNPbnVClgXy=='band_71':
    rEemSLGfpTAJYOxzRjHsNPbnVClgcv ='SUPERSECTION_LIST'
    (rEemSLGfpTAJYOxzRjHsNPbnVClgtw,rEemSLGfpTAJYOxzRjHsNPbnVClgtc)=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Baseapi_Parse(rEemSLGfpTAJYOxzRjHsNPbnVClgXo)
    rEemSLGfpTAJYOxzRjHsNPbnVClgXQ=rEemSLGfpTAJYOxzRjHsNPbnVClgtc.get('api')
    rEemSLGfpTAJYOxzRjHsNPbnVClgXo=''
   elif rEemSLGfpTAJYOxzRjHsNPbnVClgXy=='band_2':
    rEemSLGfpTAJYOxzRjHsNPbnVClgcv='BAND2SECTION_LIST'
   elif rEemSLGfpTAJYOxzRjHsNPbnVClgXy=='band_live':
    rEemSLGfpTAJYOxzRjHsNPbnVClgcv='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',rEemSLGfpTAJYOxzRjHsNPbnVClgXo):
    rEemSLGfpTAJYOxzRjHsNPbnVClgcv='MOVIE_LIST'
   else:
    rEemSLGfpTAJYOxzRjHsNPbnVClgcv='PROGRAM_LIST'
   rEemSLGfpTAJYOxzRjHsNPbnVClgui={'plot':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'mediatype':'tvshow'}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':rEemSLGfpTAJYOxzRjHsNPbnVClgcv,'suburl':rEemSLGfpTAJYOxzRjHsNPbnVClgXQ,'subapi':rEemSLGfpTAJYOxzRjHsNPbnVClgXo,'page':'1'}
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgua)>0:xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_BandLiveSection_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgXo =args.get('subapi')
  rEemSLGfpTAJYOxzRjHsNPbnVClguF=rEemSLGfpTAJYOxzRjHsNPbnVClgBX(args.get('page'))
  rEemSLGfpTAJYOxzRjHsNPbnVClgua,rEemSLGfpTAJYOxzRjHsNPbnVClguw=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_BandLiveSection_List(rEemSLGfpTAJYOxzRjHsNPbnVClgXo,rEemSLGfpTAJYOxzRjHsNPbnVClguF)
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   rEemSLGfpTAJYOxzRjHsNPbnVClgtu =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('channelid')
   rEemSLGfpTAJYOxzRjHsNPbnVClgtK =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('studio')
   rEemSLGfpTAJYOxzRjHsNPbnVClgtI=rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('tvshowtitle')
   rEemSLGfpTAJYOxzRjHsNPbnVClguk =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('thumbnail')
   rEemSLGfpTAJYOxzRjHsNPbnVClguv =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('age')
   rEemSLGfpTAJYOxzRjHsNPbnVClgui={'mediatype':'tvshow','mpaa':rEemSLGfpTAJYOxzRjHsNPbnVClguv,'title':'%s < %s >'%(rEemSLGfpTAJYOxzRjHsNPbnVClgtK,rEemSLGfpTAJYOxzRjHsNPbnVClgtI),'tvshowtitle':rEemSLGfpTAJYOxzRjHsNPbnVClgtI,'studio':rEemSLGfpTAJYOxzRjHsNPbnVClgtK,'plot':rEemSLGfpTAJYOxzRjHsNPbnVClgtK}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'LIVE','contentid':rEemSLGfpTAJYOxzRjHsNPbnVClgtu}
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgtK,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgtI,img=rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('thumbnail'),infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBh,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClguw:
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['mode'] ='BANDLIVESECTION_LIST' 
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['subapi']=rEemSLGfpTAJYOxzRjHsNPbnVClgXo
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['page'] =rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD='[B]%s >>[/B]'%'다음 페이지'
   rEemSLGfpTAJYOxzRjHsNPbnVClgKu=rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgKu,img=rEemSLGfpTAJYOxzRjHsNPbnVClgcU,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgua)>0:xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_Band2Section_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgXo =args.get('subapi')
  rEemSLGfpTAJYOxzRjHsNPbnVClguF=rEemSLGfpTAJYOxzRjHsNPbnVClgBX(args.get('page'))
  rEemSLGfpTAJYOxzRjHsNPbnVClgua,rEemSLGfpTAJYOxzRjHsNPbnVClguw=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_Band2Section_List(rEemSLGfpTAJYOxzRjHsNPbnVClgXo,rEemSLGfpTAJYOxzRjHsNPbnVClguF)
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('programtitle')
   rEemSLGfpTAJYOxzRjHsNPbnVClgKu =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('episodetitle')
   rEemSLGfpTAJYOxzRjHsNPbnVClgui={'plot':rEemSLGfpTAJYOxzRjHsNPbnVClgcD+'\n\n'+rEemSLGfpTAJYOxzRjHsNPbnVClgKu,'mpaa':rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('age'),'mediatype':'episode'}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'VOD','programid':'-','contentid':rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('videoid'),'thumbnail':rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('thumbnail'),'title':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'subtitle':rEemSLGfpTAJYOxzRjHsNPbnVClgKu}
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgKu,img=rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('thumbnail'),infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBh,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClguw:
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['mode'] ='BAND2SECTION_LIST' 
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['subapi']=rEemSLGfpTAJYOxzRjHsNPbnVClgXo
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['page'] =rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD='[B]%s >>[/B]'%'다음 페이지'
   rEemSLGfpTAJYOxzRjHsNPbnVClgKu=rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgKu,img=rEemSLGfpTAJYOxzRjHsNPbnVClgcU,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgua)>0:xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_Movie_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgXo =args.get('subapi')
  rEemSLGfpTAJYOxzRjHsNPbnVClguF=rEemSLGfpTAJYOxzRjHsNPbnVClgBX(args.get('page'))
  rEemSLGfpTAJYOxzRjHsNPbnVClgcB =args.get('orderby')or '-'
  rEemSLGfpTAJYOxzRjHsNPbnVClgua,rEemSLGfpTAJYOxzRjHsNPbnVClguw=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_Movie_List(rEemSLGfpTAJYOxzRjHsNPbnVClgXo,rEemSLGfpTAJYOxzRjHsNPbnVClguF,rEemSLGfpTAJYOxzRjHsNPbnVClgcB)
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   rEemSLGfpTAJYOxzRjHsNPbnVClguq =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('videoid')
   rEemSLGfpTAJYOxzRjHsNPbnVClguM =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('vidtype')
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('title')
   rEemSLGfpTAJYOxzRjHsNPbnVClguk=rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('thumbnail')
   rEemSLGfpTAJYOxzRjHsNPbnVClguv =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('age')
   if rEemSLGfpTAJYOxzRjHsNPbnVClguv=='18' or rEemSLGfpTAJYOxzRjHsNPbnVClguv=='19' or rEemSLGfpTAJYOxzRjHsNPbnVClguv=='21':rEemSLGfpTAJYOxzRjHsNPbnVClgcD+=' (%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClguv)
   rEemSLGfpTAJYOxzRjHsNPbnVClgui={'plot':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'mpaa':rEemSLGfpTAJYOxzRjHsNPbnVClguv,'mediatype':'movie'}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'MOVIE','contentid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'title':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'thumbnail':rEemSLGfpTAJYOxzRjHsNPbnVClguk,'age':rEemSLGfpTAJYOxzRjHsNPbnVClguv,}
   rEemSLGfpTAJYOxzRjHsNPbnVClguU=[]
   rEemSLGfpTAJYOxzRjHsNPbnVClguQ={'mode':'VIEW_DETAIL','values':{'videoid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'vidtype':'movie','contenttype':rEemSLGfpTAJYOxzRjHsNPbnVClguM,}}
   rEemSLGfpTAJYOxzRjHsNPbnVClguy=json.dumps(rEemSLGfpTAJYOxzRjHsNPbnVClguQ,separators=(',',':'))
   rEemSLGfpTAJYOxzRjHsNPbnVClguy=base64.standard_b64encode(rEemSLGfpTAJYOxzRjHsNPbnVClguy.encode()).decode('utf-8')
   rEemSLGfpTAJYOxzRjHsNPbnVClguy=rEemSLGfpTAJYOxzRjHsNPbnVClguy.replace('+','%2B')
   rEemSLGfpTAJYOxzRjHsNPbnVClgKw='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClguy)
   rEemSLGfpTAJYOxzRjHsNPbnVClguU.append(('상세정보 조회',rEemSLGfpTAJYOxzRjHsNPbnVClgKw))
   if rEemSLGfpTAJYOxzRjHsNPbnVClgwB.get_settings_makebookmark():
    rEemSLGfpTAJYOxzRjHsNPbnVClguQ={'videoid':rEemSLGfpTAJYOxzRjHsNPbnVClguq,'vidtype':'movie','vtitle':rEemSLGfpTAJYOxzRjHsNPbnVClgcD,'vsubtitle':'','contenttype':'programid',}
    rEemSLGfpTAJYOxzRjHsNPbnVClgKc=json.dumps(rEemSLGfpTAJYOxzRjHsNPbnVClguQ)
    rEemSLGfpTAJYOxzRjHsNPbnVClgKc=urllib.parse.quote(rEemSLGfpTAJYOxzRjHsNPbnVClgKc)
    rEemSLGfpTAJYOxzRjHsNPbnVClgKw='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClgKc)
    rEemSLGfpTAJYOxzRjHsNPbnVClguU.append(('(통합) 찜 영상에 추가',rEemSLGfpTAJYOxzRjHsNPbnVClgKw))
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel='',img=rEemSLGfpTAJYOxzRjHsNPbnVClguk,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBh,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci,ContextMenu=rEemSLGfpTAJYOxzRjHsNPbnVClguU)
  if rEemSLGfpTAJYOxzRjHsNPbnVClguw:
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['mode'] ='MOVIE_LIST' 
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['subapi']=rEemSLGfpTAJYOxzRjHsNPbnVClgXo 
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['page'] =rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgci['orderby']=rEemSLGfpTAJYOxzRjHsNPbnVClgcB
   rEemSLGfpTAJYOxzRjHsNPbnVClgcD='[B]%s >>[/B]'%'다음 페이지'
   rEemSLGfpTAJYOxzRjHsNPbnVClgKu=rEemSLGfpTAJYOxzRjHsNPbnVClgBi(rEemSLGfpTAJYOxzRjHsNPbnVClguF+1)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcU=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgcD,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgKu,img=rEemSLGfpTAJYOxzRjHsNPbnVClgcU,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgBI,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBt,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  xbmcplugin.setContent(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,'movies')
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgua)>0:xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_Set_Bookmark(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgtX=urllib.parse.unquote(args.get('bm_param'))
  rEemSLGfpTAJYOxzRjHsNPbnVClgtX=json.loads(rEemSLGfpTAJYOxzRjHsNPbnVClgtX)
  rEemSLGfpTAJYOxzRjHsNPbnVClguq =rEemSLGfpTAJYOxzRjHsNPbnVClgtX.get('videoid')
  rEemSLGfpTAJYOxzRjHsNPbnVClguM =rEemSLGfpTAJYOxzRjHsNPbnVClgtX.get('vidtype')
  rEemSLGfpTAJYOxzRjHsNPbnVClgtB =rEemSLGfpTAJYOxzRjHsNPbnVClgtX.get('vtitle')
  rEemSLGfpTAJYOxzRjHsNPbnVClgth =rEemSLGfpTAJYOxzRjHsNPbnVClgtX.get('vsubtitle')
  rEemSLGfpTAJYOxzRjHsNPbnVClgtD=rEemSLGfpTAJYOxzRjHsNPbnVClgtX.get('contenttype')
  rEemSLGfpTAJYOxzRjHsNPbnVClgwU=xbmcgui.Dialog()
  rEemSLGfpTAJYOxzRjHsNPbnVClgKM=rEemSLGfpTAJYOxzRjHsNPbnVClgwU.yesno(__language__(30913).encode('utf8'),rEemSLGfpTAJYOxzRjHsNPbnVClgtB+' \n\n'+__language__(30914))
  if rEemSLGfpTAJYOxzRjHsNPbnVClgKM==rEemSLGfpTAJYOxzRjHsNPbnVClgBh:return
  rEemSLGfpTAJYOxzRjHsNPbnVClgtd=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.GetBookmarkInfo(rEemSLGfpTAJYOxzRjHsNPbnVClguq,rEemSLGfpTAJYOxzRjHsNPbnVClguM,rEemSLGfpTAJYOxzRjHsNPbnVClgtD)
  rEemSLGfpTAJYOxzRjHsNPbnVClgto=json.dumps(rEemSLGfpTAJYOxzRjHsNPbnVClgtd)
  rEemSLGfpTAJYOxzRjHsNPbnVClgto=urllib.parse.quote(rEemSLGfpTAJYOxzRjHsNPbnVClgto)
  rEemSLGfpTAJYOxzRjHsNPbnVClgKw ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClgto)
  xbmc.executebuiltin(rEemSLGfpTAJYOxzRjHsNPbnVClgKw)
 def dp_LiveChannel_List(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgtU =args.get('genre')
  rEemSLGfpTAJYOxzRjHsNPbnVClgXd=args.get('baseapi')
  rEemSLGfpTAJYOxzRjHsNPbnVClgua=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_LiveChannel_List(rEemSLGfpTAJYOxzRjHsNPbnVClgtU,rEemSLGfpTAJYOxzRjHsNPbnVClgXd)
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   rEemSLGfpTAJYOxzRjHsNPbnVClgtu =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('channelid')
   rEemSLGfpTAJYOxzRjHsNPbnVClgtK =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('studio')
   rEemSLGfpTAJYOxzRjHsNPbnVClgtI=rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('tvshowtitle')
   rEemSLGfpTAJYOxzRjHsNPbnVClguk =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('thumbnail')
   rEemSLGfpTAJYOxzRjHsNPbnVClguv =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('age')
   rEemSLGfpTAJYOxzRjHsNPbnVClgti =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('epg')
   rEemSLGfpTAJYOxzRjHsNPbnVClgui={'mediatype':'episode','mpaa':rEemSLGfpTAJYOxzRjHsNPbnVClguv,'title':'%s < %s >'%(rEemSLGfpTAJYOxzRjHsNPbnVClgtK,rEemSLGfpTAJYOxzRjHsNPbnVClgtI),'tvshowtitle':rEemSLGfpTAJYOxzRjHsNPbnVClgtI,'studio':rEemSLGfpTAJYOxzRjHsNPbnVClgtK,'plot':'%s\n\n%s'%(rEemSLGfpTAJYOxzRjHsNPbnVClgtK,rEemSLGfpTAJYOxzRjHsNPbnVClgti)}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'LIVE','contentid':rEemSLGfpTAJYOxzRjHsNPbnVClgtu}
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgtK,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgtI,img=rEemSLGfpTAJYOxzRjHsNPbnVClguk,infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBh,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBo(rEemSLGfpTAJYOxzRjHsNPbnVClgua)>0:xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_Sports_GameList(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,args):
  rEemSLGfpTAJYOxzRjHsNPbnVClgua=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.Get_Sports_Gamelist()
  for rEemSLGfpTAJYOxzRjHsNPbnVClguW in rEemSLGfpTAJYOxzRjHsNPbnVClgua:
   rEemSLGfpTAJYOxzRjHsNPbnVClgtF =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('game_date')
   rEemSLGfpTAJYOxzRjHsNPbnVClgta =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('game_time')
   rEemSLGfpTAJYOxzRjHsNPbnVClgtW =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('svc_id')
   rEemSLGfpTAJYOxzRjHsNPbnVClgtq =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('away_team')
   rEemSLGfpTAJYOxzRjHsNPbnVClgtM =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('home_team')
   rEemSLGfpTAJYOxzRjHsNPbnVClgtk=rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('game_status')
   rEemSLGfpTAJYOxzRjHsNPbnVClgtv =rEemSLGfpTAJYOxzRjHsNPbnVClguW.get('game_place')
   rEemSLGfpTAJYOxzRjHsNPbnVClgtQ ='%s vs %s (%s)'%(rEemSLGfpTAJYOxzRjHsNPbnVClgtq,rEemSLGfpTAJYOxzRjHsNPbnVClgtM,rEemSLGfpTAJYOxzRjHsNPbnVClgtv)
   rEemSLGfpTAJYOxzRjHsNPbnVClgty =rEemSLGfpTAJYOxzRjHsNPbnVClgtF+' '+rEemSLGfpTAJYOxzRjHsNPbnVClgta
   if rEemSLGfpTAJYOxzRjHsNPbnVClgtk=='LIVE':
    rEemSLGfpTAJYOxzRjHsNPbnVClgtk='~경기중~'
   elif rEemSLGfpTAJYOxzRjHsNPbnVClgtk=='END':
    rEemSLGfpTAJYOxzRjHsNPbnVClgtk='경기종료'
   elif rEemSLGfpTAJYOxzRjHsNPbnVClgtk=='CANCEL':
    rEemSLGfpTAJYOxzRjHsNPbnVClgtk='취소'
   else:
    rEemSLGfpTAJYOxzRjHsNPbnVClgtk=''
   if rEemSLGfpTAJYOxzRjHsNPbnVClgtk=='':
    rEemSLGfpTAJYOxzRjHsNPbnVClgKu=rEemSLGfpTAJYOxzRjHsNPbnVClgtQ
   else:
    rEemSLGfpTAJYOxzRjHsNPbnVClgKu=rEemSLGfpTAJYOxzRjHsNPbnVClgtQ+'  '+rEemSLGfpTAJYOxzRjHsNPbnVClgtk
   rEemSLGfpTAJYOxzRjHsNPbnVClgui={'mediatype':'episode','title':rEemSLGfpTAJYOxzRjHsNPbnVClgtQ,'plot':'%s\n\n%s\n\n%s'%(rEemSLGfpTAJYOxzRjHsNPbnVClgty,rEemSLGfpTAJYOxzRjHsNPbnVClgtQ,rEemSLGfpTAJYOxzRjHsNPbnVClgtk)}
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'SPORTS','contentid':rEemSLGfpTAJYOxzRjHsNPbnVClgtW}
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.add_dir(rEemSLGfpTAJYOxzRjHsNPbnVClgty,sublabel=rEemSLGfpTAJYOxzRjHsNPbnVClgKu,img='',infoLabels=rEemSLGfpTAJYOxzRjHsNPbnVClgui,isFolder=rEemSLGfpTAJYOxzRjHsNPbnVClgBh,params=rEemSLGfpTAJYOxzRjHsNPbnVClgci)
  xbmcplugin.endOfDirectory(rEemSLGfpTAJYOxzRjHsNPbnVClgwB._addon_handle,cacheToDisc=rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
 def dp_View_Detail(rEemSLGfpTAJYOxzRjHsNPbnVClgwB,rEemSLGfpTAJYOxzRjHsNPbnVClgBu):
  rEemSLGfpTAJYOxzRjHsNPbnVClguq =rEemSLGfpTAJYOxzRjHsNPbnVClgBu.get('videoid')
  rEemSLGfpTAJYOxzRjHsNPbnVClguM =rEemSLGfpTAJYOxzRjHsNPbnVClgBu.get('vidtype') 
  rEemSLGfpTAJYOxzRjHsNPbnVClgtD=rEemSLGfpTAJYOxzRjHsNPbnVClgBu.get('contenttype')
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.addon_log(rEemSLGfpTAJYOxzRjHsNPbnVClguq)
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.addon_log(rEemSLGfpTAJYOxzRjHsNPbnVClguM)
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.addon_log(rEemSLGfpTAJYOxzRjHsNPbnVClgtD)
  rEemSLGfpTAJYOxzRjHsNPbnVClgtd=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.WavveObj.GetBookmarkInfo(rEemSLGfpTAJYOxzRjHsNPbnVClguq,rEemSLGfpTAJYOxzRjHsNPbnVClguM,rEemSLGfpTAJYOxzRjHsNPbnVClgtD)
  if rEemSLGfpTAJYOxzRjHsNPbnVClguM=='tvshow':
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'SEASON_LIST','videoid':rEemSLGfpTAJYOxzRjHsNPbnVClgtd['indexinfo']['videoid'],'vidtype':rEemSLGfpTAJYOxzRjHsNPbnVClgtd['indexinfo']['vidtype'],}
   rEemSLGfpTAJYOxzRjHsNPbnVClgKy='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(rEemSLGfpTAJYOxzRjHsNPbnVClgci))
  else:
   rEemSLGfpTAJYOxzRjHsNPbnVClgci={'mode':'MOVIE','contentid':rEemSLGfpTAJYOxzRjHsNPbnVClgtd['indexinfo']['videoid'],'title':rEemSLGfpTAJYOxzRjHsNPbnVClgtd['saveinfo']['infoLabels']['title'],'thumbnail':rEemSLGfpTAJYOxzRjHsNPbnVClgtd['saveinfo']['thumbnail'],'age':rEemSLGfpTAJYOxzRjHsNPbnVClgtd['saveinfo']['infoLabels']['mpaa'],}
   rEemSLGfpTAJYOxzRjHsNPbnVClgKy='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(rEemSLGfpTAJYOxzRjHsNPbnVClgci))
  rEemSLGfpTAJYOxzRjHsNPbnVClgcd=xbmcgui.ListItem(label=rEemSLGfpTAJYOxzRjHsNPbnVClgtd['saveinfo']['title'],path=rEemSLGfpTAJYOxzRjHsNPbnVClgKy)
  rEemSLGfpTAJYOxzRjHsNPbnVClgcd.setArt(rEemSLGfpTAJYOxzRjHsNPbnVClgtd['saveinfo']['thumbnail'])
  rEemSLGfpTAJYOxzRjHsNPbnVClgcd.setInfo('Video',rEemSLGfpTAJYOxzRjHsNPbnVClgtd['saveinfo']['infoLabels'])
  if rEemSLGfpTAJYOxzRjHsNPbnVClguM=='movie':
   rEemSLGfpTAJYOxzRjHsNPbnVClgcd.setIsFolder(rEemSLGfpTAJYOxzRjHsNPbnVClgBh)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcd.setProperty('IsPlayable','true')
  else:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcd.setIsFolder(rEemSLGfpTAJYOxzRjHsNPbnVClgBt)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcd.setProperty('IsPlayable','false')
  rEemSLGfpTAJYOxzRjHsNPbnVClgwU=xbmcgui.Dialog()
  rEemSLGfpTAJYOxzRjHsNPbnVClgwU.info(rEemSLGfpTAJYOxzRjHsNPbnVClgcd)
 def wavve_main(rEemSLGfpTAJYOxzRjHsNPbnVClgwB):
  rEemSLGfpTAJYOxzRjHsNPbnVClgBw=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.main_params.get('params')
  if rEemSLGfpTAJYOxzRjHsNPbnVClgBw:
   rEemSLGfpTAJYOxzRjHsNPbnVClgBc =base64.standard_b64decode(rEemSLGfpTAJYOxzRjHsNPbnVClgBw).decode('utf-8')
   rEemSLGfpTAJYOxzRjHsNPbnVClgBc =json.loads(rEemSLGfpTAJYOxzRjHsNPbnVClgBc)
   rEemSLGfpTAJYOxzRjHsNPbnVClgcv =rEemSLGfpTAJYOxzRjHsNPbnVClgBc.get('mode')
   rEemSLGfpTAJYOxzRjHsNPbnVClgBu =rEemSLGfpTAJYOxzRjHsNPbnVClgBc.get('values')
  else:
   rEemSLGfpTAJYOxzRjHsNPbnVClgcv=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.main_params.get('mode',rEemSLGfpTAJYOxzRjHsNPbnVClgBI)
   rEemSLGfpTAJYOxzRjHsNPbnVClgBu=rEemSLGfpTAJYOxzRjHsNPbnVClgwB.main_params
  if rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='LOGOUT':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.logout()
   return
  rEemSLGfpTAJYOxzRjHsNPbnVClgwB.login_main()
  if rEemSLGfpTAJYOxzRjHsNPbnVClgcv is rEemSLGfpTAJYOxzRjHsNPbnVClgBI:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Main_List()
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv in['LIVE','VOD','MOVIE','SPORTS']:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.play_VIDEO(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='LIVE_CATAGORY':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_LiveCatagory_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='MAIN_CATAGORY':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_MainCatagory_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='SUPERSECTION_LIST':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_SuperSection_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='BANDLIVESECTION_LIST':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_BandLiveSection_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='BAND2SECTION_LIST':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Band2Section_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='PROGRAM_LIST':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Program_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='SEASON_LIST':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Season_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='EPISODE_LIST':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Episode_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='MOVIE_LIST':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Movie_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='LIVE_LIST':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_LiveChannel_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='ORDER_BY':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_setEpOrderby(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='SEARCH_GROUP':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Search_Group(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv in['SEARCH_LIST','LOCAL_SEARCH']:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Search_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='WATCH_GROUP':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Watch_Group(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='WATCH_LIST':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Watch_List(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='SET_BOOKMARK':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Set_Bookmark(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_History_Remove(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv in['TOTAL_SEARCH','TOTAL_HISTORY']:
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Global_Search(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='SEARCH_HISTORY':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Search_History(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='MENU_BOOKMARK':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Bookmark_Menu(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='GAME_LIST':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_Sports_GameList(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  elif rEemSLGfpTAJYOxzRjHsNPbnVClgcv=='VIEW_DETAIL':
   rEemSLGfpTAJYOxzRjHsNPbnVClgwB.dp_View_Detail(rEemSLGfpTAJYOxzRjHsNPbnVClgBu)
  else:
   rEemSLGfpTAJYOxzRjHsNPbnVClgBI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
