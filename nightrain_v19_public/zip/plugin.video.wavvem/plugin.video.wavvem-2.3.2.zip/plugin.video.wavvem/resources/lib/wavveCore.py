__author__="NightRain"
rDfdqNkMKAevTjWXsSLUYwzHhigCcJ=object
rDfdqNkMKAevTjWXsSLUYwzHhigCcu=None
rDfdqNkMKAevTjWXsSLUYwzHhigCcO=False
rDfdqNkMKAevTjWXsSLUYwzHhigCcV=open
rDfdqNkMKAevTjWXsSLUYwzHhigCcF=True
rDfdqNkMKAevTjWXsSLUYwzHhigCcG=range
rDfdqNkMKAevTjWXsSLUYwzHhigCcn=str
rDfdqNkMKAevTjWXsSLUYwzHhigCcB=Exception
rDfdqNkMKAevTjWXsSLUYwzHhigCct=print
rDfdqNkMKAevTjWXsSLUYwzHhigCcR=dict
rDfdqNkMKAevTjWXsSLUYwzHhigCcQ=int
rDfdqNkMKAevTjWXsSLUYwzHhigCco=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class rDfdqNkMKAevTjWXsSLUYwzHhigCbI(rDfdqNkMKAevTjWXsSLUYwzHhigCcJ):
 def __init__(rDfdqNkMKAevTjWXsSLUYwzHhigCba):
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN='https://apis.wavve.com'
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV ={}
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.Init_WV_Total()
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.DEVICE ='pc'
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.DRM ='wm'
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.PARTNER ='pooq'
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.POOQZONE ='none'
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.REGION ='kor'
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.TARGETAGE ='all'
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.HTTPTAG ='https://'
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.LIST_LIMIT=30 
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.EP_LIMIT =30 
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.MV_LIMIT =24 
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.SEARCH_LIMIT=20 
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36'
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.DEFAULT_HEADER={'user-agent':rDfdqNkMKAevTjWXsSLUYwzHhigCba.USER_AGENT}
 def Init_WV_Total(rDfdqNkMKAevTjWXsSLUYwzHhigCba):
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV={'account':{},'cookies':{},}
 def callRequestCookies(rDfdqNkMKAevTjWXsSLUYwzHhigCba,jobtype,rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,redirects=rDfdqNkMKAevTjWXsSLUYwzHhigCcO):
  rDfdqNkMKAevTjWXsSLUYwzHhigCbp=rDfdqNkMKAevTjWXsSLUYwzHhigCba.DEFAULT_HEADER
  if headers:rDfdqNkMKAevTjWXsSLUYwzHhigCbp.update(headers)
  if jobtype=='Get':
   rDfdqNkMKAevTjWXsSLUYwzHhigCbE=requests.get(rDfdqNkMKAevTjWXsSLUYwzHhigCbm,params=params,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCbp,cookies=cookies,allow_redirects=redirects)
  else:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbE=requests.post(rDfdqNkMKAevTjWXsSLUYwzHhigCbm,data=payload,params=params,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCbp,cookies=cookies,allow_redirects=redirects)
  return rDfdqNkMKAevTjWXsSLUYwzHhigCbE
 def JsonFile_Save(rDfdqNkMKAevTjWXsSLUYwzHhigCba,filename,rDfdqNkMKAevTjWXsSLUYwzHhigCbc):
  if filename=='':return rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  try:
   fp=rDfdqNkMKAevTjWXsSLUYwzHhigCcV(filename,'w',-1,'utf-8')
   json.dump(rDfdqNkMKAevTjWXsSLUYwzHhigCbc,fp,indent=4,ensure_ascii=rDfdqNkMKAevTjWXsSLUYwzHhigCcO)
   fp.close()
  except:
   return rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  return rDfdqNkMKAevTjWXsSLUYwzHhigCcF
 def JsonFile_Load(rDfdqNkMKAevTjWXsSLUYwzHhigCba,filename):
  if filename=='':return{}
  try:
   fp=rDfdqNkMKAevTjWXsSLUYwzHhigCcV(filename,'r',-1,'utf-8')
   rDfdqNkMKAevTjWXsSLUYwzHhigCby=json.load(fp)
   fp.close()
  except:
   return{}
  return rDfdqNkMKAevTjWXsSLUYwzHhigCby
 def Save_session_acount(rDfdqNkMKAevTjWXsSLUYwzHhigCba,rDfdqNkMKAevTjWXsSLUYwzHhigCbx,rDfdqNkMKAevTjWXsSLUYwzHhigCbJ,rDfdqNkMKAevTjWXsSLUYwzHhigCbu):
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['account']['wvid']=base64.standard_b64encode(rDfdqNkMKAevTjWXsSLUYwzHhigCbx.encode()).decode('utf-8')
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['account']['wvpw']=base64.standard_b64encode(rDfdqNkMKAevTjWXsSLUYwzHhigCbJ.encode()).decode('utf-8')
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['account']['wvpf']=rDfdqNkMKAevTjWXsSLUYwzHhigCbu 
 def Load_session_acount(rDfdqNkMKAevTjWXsSLUYwzHhigCba):
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbx=base64.standard_b64decode(rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['account']['wvid']).decode('utf-8')
   rDfdqNkMKAevTjWXsSLUYwzHhigCbJ=base64.standard_b64decode(rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['account']['wvpw']).decode('utf-8')
   rDfdqNkMKAevTjWXsSLUYwzHhigCbu=rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['account']['wvpf']
  except:
   return '','',0
  return rDfdqNkMKAevTjWXsSLUYwzHhigCbx,rDfdqNkMKAevTjWXsSLUYwzHhigCbJ,rDfdqNkMKAevTjWXsSLUYwzHhigCbu
 def GetDefaultParams(rDfdqNkMKAevTjWXsSLUYwzHhigCba,login=rDfdqNkMKAevTjWXsSLUYwzHhigCcF):
  rDfdqNkMKAevTjWXsSLUYwzHhigCbO={'apikey':rDfdqNkMKAevTjWXsSLUYwzHhigCba.APIKEY,'credential':rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['cookies']['credential']if login else 'none','device':rDfdqNkMKAevTjWXsSLUYwzHhigCba.DEVICE,'drm':rDfdqNkMKAevTjWXsSLUYwzHhigCba.DRM,'partner':rDfdqNkMKAevTjWXsSLUYwzHhigCba.PARTNER,'pooqzone':rDfdqNkMKAevTjWXsSLUYwzHhigCba.POOQZONE,'region':rDfdqNkMKAevTjWXsSLUYwzHhigCba.REGION,'targetage':rDfdqNkMKAevTjWXsSLUYwzHhigCba.TARGETAGE,}
  return rDfdqNkMKAevTjWXsSLUYwzHhigCbO
 def GetDefaultParams_AND(rDfdqNkMKAevTjWXsSLUYwzHhigCba):
  rDfdqNkMKAevTjWXsSLUYwzHhigCbO={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['cookies']['credential'],'device':'ott','drm':rDfdqNkMKAevTjWXsSLUYwzHhigCba.DRM,'partner':rDfdqNkMKAevTjWXsSLUYwzHhigCba.PARTNER,'pooqzone':rDfdqNkMKAevTjWXsSLUYwzHhigCba.POOQZONE,'region':rDfdqNkMKAevTjWXsSLUYwzHhigCba.REGION,'targetage':rDfdqNkMKAevTjWXsSLUYwzHhigCba.TARGETAGE,}
  return rDfdqNkMKAevTjWXsSLUYwzHhigCbO
 def GetGUID(rDfdqNkMKAevTjWXsSLUYwzHhigCba,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   rDfdqNkMKAevTjWXsSLUYwzHhigCbV=rDfdqNkMKAevTjWXsSLUYwzHhigCba.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   rDfdqNkMKAevTjWXsSLUYwzHhigCbF=GenerateRandomString(5)
   rDfdqNkMKAevTjWXsSLUYwzHhigCbG=rDfdqNkMKAevTjWXsSLUYwzHhigCbF+media+rDfdqNkMKAevTjWXsSLUYwzHhigCbV
   return rDfdqNkMKAevTjWXsSLUYwzHhigCbG
  def GenerateRandomString(num):
   from random import randint
   rDfdqNkMKAevTjWXsSLUYwzHhigCbn=""
   for i in rDfdqNkMKAevTjWXsSLUYwzHhigCcG(0,num):
    s=rDfdqNkMKAevTjWXsSLUYwzHhigCcn(randint(1,5))
    rDfdqNkMKAevTjWXsSLUYwzHhigCbn+=s
   return rDfdqNkMKAevTjWXsSLUYwzHhigCbn
  if guidType==3:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbG=rDfdqNkMKAevTjWXsSLUYwzHhigCIE
  else:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbG=GenerateID(rDfdqNkMKAevTjWXsSLUYwzHhigCIE)
  rDfdqNkMKAevTjWXsSLUYwzHhigCbB=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetHash(rDfdqNkMKAevTjWXsSLUYwzHhigCbG)
  if guidType in[2,3]:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbB='%s-%s-%s-%s-%s'%(rDfdqNkMKAevTjWXsSLUYwzHhigCbB[:8],rDfdqNkMKAevTjWXsSLUYwzHhigCbB[8:12],rDfdqNkMKAevTjWXsSLUYwzHhigCbB[12:16],rDfdqNkMKAevTjWXsSLUYwzHhigCbB[16:20],rDfdqNkMKAevTjWXsSLUYwzHhigCbB[20:])
  return rDfdqNkMKAevTjWXsSLUYwzHhigCbB
 def GetHash(rDfdqNkMKAevTjWXsSLUYwzHhigCba,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return rDfdqNkMKAevTjWXsSLUYwzHhigCcn(m.hexdigest())
 def CheckQuality(rDfdqNkMKAevTjWXsSLUYwzHhigCba,sel_qt,qt_list):
  rDfdqNkMKAevTjWXsSLUYwzHhigCbt=0
  for rDfdqNkMKAevTjWXsSLUYwzHhigCbR in qt_list:
   if sel_qt>=rDfdqNkMKAevTjWXsSLUYwzHhigCbR:return rDfdqNkMKAevTjWXsSLUYwzHhigCbR
   rDfdqNkMKAevTjWXsSLUYwzHhigCbt=rDfdqNkMKAevTjWXsSLUYwzHhigCbR
  return rDfdqNkMKAevTjWXsSLUYwzHhigCbt
 def Get_Now_Datetime(rDfdqNkMKAevTjWXsSLUYwzHhigCba):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(rDfdqNkMKAevTjWXsSLUYwzHhigCba,in_text):
  rDfdqNkMKAevTjWXsSLUYwzHhigCbo=in_text.replace('&lt;','<').replace('&gt;','>')
  rDfdqNkMKAevTjWXsSLUYwzHhigCbo=rDfdqNkMKAevTjWXsSLUYwzHhigCbo.replace('$O$','')
  rDfdqNkMKAevTjWXsSLUYwzHhigCbo=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',rDfdqNkMKAevTjWXsSLUYwzHhigCbo)
  rDfdqNkMKAevTjWXsSLUYwzHhigCbo=rDfdqNkMKAevTjWXsSLUYwzHhigCbo.lstrip('#')
  return rDfdqNkMKAevTjWXsSLUYwzHhigCbo
 def GetCredential(rDfdqNkMKAevTjWXsSLUYwzHhigCba,user_id,user_pw,user_pf):
  rDfdqNkMKAevTjWXsSLUYwzHhigCbP=rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+ '/login'
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIb={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Post',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCIb,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['cookies']['credential']=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['credential']
   if user_pf!=0:
    rDfdqNkMKAevTjWXsSLUYwzHhigCIb={'id':rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['cookies']['credential'],'password':'','profile':rDfdqNkMKAevTjWXsSLUYwzHhigCcn(user_pf),'pushid':'','type':'credential'}
    rDfdqNkMKAevTjWXsSLUYwzHhigCbO =rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcF) 
    rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Post',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCIb,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
    rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
    rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['cookies']['credential']=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['credential']
   rDfdqNkMKAevTjWXsSLUYwzHhigCIE=user_id+rDfdqNkMKAevTjWXsSLUYwzHhigCcn(user_pf) 
   rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['cookies']['uuid']=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetGUID(guid_str=rDfdqNkMKAevTjWXsSLUYwzHhigCIE,guidType=3)
   rDfdqNkMKAevTjWXsSLUYwzHhigCbP=rDfdqNkMKAevTjWXsSLUYwzHhigCcF
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   rDfdqNkMKAevTjWXsSLUYwzHhigCba.Init_WV_Total()
  return rDfdqNkMKAevTjWXsSLUYwzHhigCbP
 def GetIssue(rDfdqNkMKAevTjWXsSLUYwzHhigCba):
  rDfdqNkMKAevTjWXsSLUYwzHhigCIc=rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/guid/issue'
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams()
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIl=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['guid']
   rDfdqNkMKAevTjWXsSLUYwzHhigCIy=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['guidtimestamp']
   if rDfdqNkMKAevTjWXsSLUYwzHhigCIl:rDfdqNkMKAevTjWXsSLUYwzHhigCIc=rDfdqNkMKAevTjWXsSLUYwzHhigCcF
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIl='none'
   rDfdqNkMKAevTjWXsSLUYwzHhigCIy='none' 
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.guid=rDfdqNkMKAevTjWXsSLUYwzHhigCIl
  rDfdqNkMKAevTjWXsSLUYwzHhigCba.guidtimestamp=rDfdqNkMKAevTjWXsSLUYwzHhigCIy
  return rDfdqNkMKAevTjWXsSLUYwzHhigCIc
 def Baseapi_Parse(rDfdqNkMKAevTjWXsSLUYwzHhigCba,rDfdqNkMKAevTjWXsSLUYwzHhigCIO):
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCIx =urllib.parse.urlsplit(rDfdqNkMKAevTjWXsSLUYwzHhigCIO)
   if rDfdqNkMKAevTjWXsSLUYwzHhigCIx.netloc=='':
    rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.HTTPTAG+rDfdqNkMKAevTjWXsSLUYwzHhigCIx.netloc+rDfdqNkMKAevTjWXsSLUYwzHhigCIx.path
   else:
    rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCIx.scheme+'://'+rDfdqNkMKAevTjWXsSLUYwzHhigCIx.netloc+rDfdqNkMKAevTjWXsSLUYwzHhigCIx.path
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO=rDfdqNkMKAevTjWXsSLUYwzHhigCcR(urllib.parse.parse_qsl(rDfdqNkMKAevTjWXsSLUYwzHhigCIx.query))
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return '',{}
  return rDfdqNkMKAevTjWXsSLUYwzHhigCbm,rDfdqNkMKAevTjWXsSLUYwzHhigCbO
 def GetSupermultiUrl(rDfdqNkMKAevTjWXsSLUYwzHhigCba,sCode,sIndex='0'):
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/cf/supermultisections/'+sCode
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIJ=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['multisectionlist'][rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(sIndex)]['eventlist'][1]['url']
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return ''
  return rDfdqNkMKAevTjWXsSLUYwzHhigCIJ
 def Get_LiveCatagory_List(rDfdqNkMKAevTjWXsSLUYwzHhigCba,sCode,sIndex='0'):
  rDfdqNkMKAevTjWXsSLUYwzHhigCIu=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCIO =rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetSupermultiUrl(sCode,sIndex)
  (rDfdqNkMKAevTjWXsSLUYwzHhigCbm,rDfdqNkMKAevTjWXsSLUYwzHhigCbO)=rDfdqNkMKAevTjWXsSLUYwzHhigCba.Baseapi_Parse(rDfdqNkMKAevTjWXsSLUYwzHhigCIO)
  if rDfdqNkMKAevTjWXsSLUYwzHhigCbm=='':return rDfdqNkMKAevTjWXsSLUYwzHhigCIu,''
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('filter_item_list' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp['filter']['filterlist'][0]):return[],''
   rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['filter']['filterlist'][0]['filter_item_list']
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCIF:
    rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'title':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title'],'genre':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['api_parameters'][rDfdqNkMKAevTjWXsSLUYwzHhigCIG['api_parameters'].index('=')+1:]}
    rDfdqNkMKAevTjWXsSLUYwzHhigCIu.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[],''
  return rDfdqNkMKAevTjWXsSLUYwzHhigCIu,rDfdqNkMKAevTjWXsSLUYwzHhigCIO
 def Get_MainCatagory_List(rDfdqNkMKAevTjWXsSLUYwzHhigCba,sCode,sIndex='0'):
  rDfdqNkMKAevTjWXsSLUYwzHhigCIu=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCIO =rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetSupermultiUrl(sCode,sIndex)
  (rDfdqNkMKAevTjWXsSLUYwzHhigCbm,rDfdqNkMKAevTjWXsSLUYwzHhigCbO)=rDfdqNkMKAevTjWXsSLUYwzHhigCba.Baseapi_Parse(rDfdqNkMKAevTjWXsSLUYwzHhigCIO)
  if rDfdqNkMKAevTjWXsSLUYwzHhigCbm=='':return rDfdqNkMKAevTjWXsSLUYwzHhigCIu
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('celllist' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp['band']):return[]
   rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['band']['celllist']
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCIF:
    rDfdqNkMKAevTjWXsSLUYwzHhigCIB =rDfdqNkMKAevTjWXsSLUYwzHhigCIG['event_list'][1]['url']
    (rDfdqNkMKAevTjWXsSLUYwzHhigCIt,rDfdqNkMKAevTjWXsSLUYwzHhigCIR)=rDfdqNkMKAevTjWXsSLUYwzHhigCba.Baseapi_Parse(rDfdqNkMKAevTjWXsSLUYwzHhigCIB)
    rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'title':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][0]['text'],'suburl':rDfdqNkMKAevTjWXsSLUYwzHhigCIt,'subapi':rDfdqNkMKAevTjWXsSLUYwzHhigCIR.get('api'),'subtype':'catagory' if rDfdqNkMKAevTjWXsSLUYwzHhigCIR else 'supersection'}
    rDfdqNkMKAevTjWXsSLUYwzHhigCIu.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[]
  return rDfdqNkMKAevTjWXsSLUYwzHhigCIu
 def Get_SuperMultiSection_List(rDfdqNkMKAevTjWXsSLUYwzHhigCba,subapi_text):
  rDfdqNkMKAevTjWXsSLUYwzHhigCIu=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCbO={}
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCIx =urllib.parse.urlsplit(subapi_text)
   if rDfdqNkMKAevTjWXsSLUYwzHhigCIx.path.find('apis.wavve.com')>=0: 
    rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.HTTPTAG+rDfdqNkMKAevTjWXsSLUYwzHhigCIx.path 
    rDfdqNkMKAevTjWXsSLUYwzHhigCbO=rDfdqNkMKAevTjWXsSLUYwzHhigCcR(urllib.parse.parse_qsl(rDfdqNkMKAevTjWXsSLUYwzHhigCIx.query))
   else:
    rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/cf'+rDfdqNkMKAevTjWXsSLUYwzHhigCIx.path 
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCbm.replace('supermultisection/','supermultisections/')
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[]
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('multisectionlist' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp):return[]
   rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['multisectionlist']
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCIF:
    rDfdqNkMKAevTjWXsSLUYwzHhigCIQ=rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title']
    if rDfdqNkMKAevTjWXsSLUYwzHhigCco(rDfdqNkMKAevTjWXsSLUYwzHhigCIQ)==0:continue
    if rDfdqNkMKAevTjWXsSLUYwzHhigCIQ=='minor':continue
    if re.search(u'베너',rDfdqNkMKAevTjWXsSLUYwzHhigCIQ):continue
    if re.search(u'배너',rDfdqNkMKAevTjWXsSLUYwzHhigCIQ):continue 
    if rDfdqNkMKAevTjWXsSLUYwzHhigCIG['force_refresh']=='y':continue
    if rDfdqNkMKAevTjWXsSLUYwzHhigCco(rDfdqNkMKAevTjWXsSLUYwzHhigCIG['eventlist'])>=3:
     rDfdqNkMKAevTjWXsSLUYwzHhigCIR =rDfdqNkMKAevTjWXsSLUYwzHhigCIG['eventlist'][2]['url']
    else:
     rDfdqNkMKAevTjWXsSLUYwzHhigCIR =rDfdqNkMKAevTjWXsSLUYwzHhigCIG['eventlist'][1]['url']
    rDfdqNkMKAevTjWXsSLUYwzHhigCIo=rDfdqNkMKAevTjWXsSLUYwzHhigCIG['cell_type']
    if rDfdqNkMKAevTjWXsSLUYwzHhigCIo=='band_2':
     if rDfdqNkMKAevTjWXsSLUYwzHhigCIR.find('channellist=')>=0:
      rDfdqNkMKAevTjWXsSLUYwzHhigCIo='band_live'
    rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'title':rDfdqNkMKAevTjWXsSLUYwzHhigCba.Get_ChangeText(rDfdqNkMKAevTjWXsSLUYwzHhigCIQ),'subapi':rDfdqNkMKAevTjWXsSLUYwzHhigCIR,'cell_type':rDfdqNkMKAevTjWXsSLUYwzHhigCIo}
    rDfdqNkMKAevTjWXsSLUYwzHhigCIu.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[]
  return rDfdqNkMKAevTjWXsSLUYwzHhigCIu
 def Get_BandLiveSection_List(rDfdqNkMKAevTjWXsSLUYwzHhigCba,rDfdqNkMKAevTjWXsSLUYwzHhigCIO,page_int=1):
  rDfdqNkMKAevTjWXsSLUYwzHhigCIP=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCal=1
  rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  try:
   (rDfdqNkMKAevTjWXsSLUYwzHhigCbm,rDfdqNkMKAevTjWXsSLUYwzHhigCbO)=rDfdqNkMKAevTjWXsSLUYwzHhigCba.Baseapi_Parse(rDfdqNkMKAevTjWXsSLUYwzHhigCIO)
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[],rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO['limit']=rDfdqNkMKAevTjWXsSLUYwzHhigCba.LIST_LIMIT
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO['offset']=rDfdqNkMKAevTjWXsSLUYwzHhigCcn((page_int-1)*rDfdqNkMKAevTjWXsSLUYwzHhigCba.LIST_LIMIT)
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('celllist' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']):return[],rDfdqNkMKAevTjWXsSLUYwzHhigCcO
   rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['celllist']
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCIF:
    rDfdqNkMKAevTjWXsSLUYwzHhigCaI =rDfdqNkMKAevTjWXsSLUYwzHhigCIG['event_list'][1]['url']
    rDfdqNkMKAevTjWXsSLUYwzHhigCap=urllib.parse.urlsplit(rDfdqNkMKAevTjWXsSLUYwzHhigCaI).query
    rDfdqNkMKAevTjWXsSLUYwzHhigCap=rDfdqNkMKAevTjWXsSLUYwzHhigCcR(urllib.parse.parse_qsl(rDfdqNkMKAevTjWXsSLUYwzHhigCap))
    rDfdqNkMKAevTjWXsSLUYwzHhigCaE='channelid'
    rDfdqNkMKAevTjWXsSLUYwzHhigCac=rDfdqNkMKAevTjWXsSLUYwzHhigCap[rDfdqNkMKAevTjWXsSLUYwzHhigCaE]
    rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'studio':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][0]['text'],'tvshowtitle':rDfdqNkMKAevTjWXsSLUYwzHhigCba.Get_ChangeText(rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][1]['text']),'channelid':rDfdqNkMKAevTjWXsSLUYwzHhigCac,'age':rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('age'),'thumbnail':'https://%s'%rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('thumbnail')}
    rDfdqNkMKAevTjWXsSLUYwzHhigCIP.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['pagecount'])
   if rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['count']:rDfdqNkMKAevTjWXsSLUYwzHhigCal =rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['count'])
   else:rDfdqNkMKAevTjWXsSLUYwzHhigCal=rDfdqNkMKAevTjWXsSLUYwzHhigCba.LIST_LIMIT*page_int
   rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCIm>rDfdqNkMKAevTjWXsSLUYwzHhigCal
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[],rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  return rDfdqNkMKAevTjWXsSLUYwzHhigCIP,rDfdqNkMKAevTjWXsSLUYwzHhigCab
 def Get_Band2Section_List(rDfdqNkMKAevTjWXsSLUYwzHhigCba,rDfdqNkMKAevTjWXsSLUYwzHhigCIO,page_int=1):
  rDfdqNkMKAevTjWXsSLUYwzHhigCay=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCal=1
  rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  try:
   (rDfdqNkMKAevTjWXsSLUYwzHhigCbm,rDfdqNkMKAevTjWXsSLUYwzHhigCbO)=rDfdqNkMKAevTjWXsSLUYwzHhigCba.Baseapi_Parse(rDfdqNkMKAevTjWXsSLUYwzHhigCIO)
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[],rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO['came'] ='BandView'
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO['limit']=rDfdqNkMKAevTjWXsSLUYwzHhigCba.LIST_LIMIT
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO['offset']=rDfdqNkMKAevTjWXsSLUYwzHhigCcn((page_int-1)*rDfdqNkMKAevTjWXsSLUYwzHhigCba.LIST_LIMIT)
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('celllist' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']):return[],rDfdqNkMKAevTjWXsSLUYwzHhigCcO
   rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['celllist']
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCIF:
    rDfdqNkMKAevTjWXsSLUYwzHhigCaI =rDfdqNkMKAevTjWXsSLUYwzHhigCIG['event_list'][1]['url']
    rDfdqNkMKAevTjWXsSLUYwzHhigCap=urllib.parse.urlsplit(rDfdqNkMKAevTjWXsSLUYwzHhigCaI).query
    rDfdqNkMKAevTjWXsSLUYwzHhigCap=rDfdqNkMKAevTjWXsSLUYwzHhigCcR(urllib.parse.parse_qsl(rDfdqNkMKAevTjWXsSLUYwzHhigCap))
    rDfdqNkMKAevTjWXsSLUYwzHhigCaE='contentid'
    rDfdqNkMKAevTjWXsSLUYwzHhigCac=rDfdqNkMKAevTjWXsSLUYwzHhigCap[rDfdqNkMKAevTjWXsSLUYwzHhigCaE]
    rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'programtitle':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][0]['text'],'episodetitle':rDfdqNkMKAevTjWXsSLUYwzHhigCba.Get_ChangeText(rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][1]['text']),'age':rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('age'),'thumbnail':rDfdqNkMKAevTjWXsSLUYwzHhigCba.HTTPTAG+rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('thumbnail'),'vidtype':rDfdqNkMKAevTjWXsSLUYwzHhigCaE,'videoid':rDfdqNkMKAevTjWXsSLUYwzHhigCac}
    rDfdqNkMKAevTjWXsSLUYwzHhigCay.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['pagecount'])
   if rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['count']:rDfdqNkMKAevTjWXsSLUYwzHhigCal =rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['count'])
   else:rDfdqNkMKAevTjWXsSLUYwzHhigCal=rDfdqNkMKAevTjWXsSLUYwzHhigCba.LIST_LIMIT*page_int
   rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCIm>rDfdqNkMKAevTjWXsSLUYwzHhigCal
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[],rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  return rDfdqNkMKAevTjWXsSLUYwzHhigCay,rDfdqNkMKAevTjWXsSLUYwzHhigCab
 def Get_Program_List(rDfdqNkMKAevTjWXsSLUYwzHhigCba,rDfdqNkMKAevTjWXsSLUYwzHhigCIO,page_int=1,orderby='-'):
  rDfdqNkMKAevTjWXsSLUYwzHhigCax=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCal=1
  rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  (rDfdqNkMKAevTjWXsSLUYwzHhigCbm,rDfdqNkMKAevTjWXsSLUYwzHhigCbO)=rDfdqNkMKAevTjWXsSLUYwzHhigCba.Baseapi_Parse(rDfdqNkMKAevTjWXsSLUYwzHhigCIO)
  if rDfdqNkMKAevTjWXsSLUYwzHhigCbm=='':return rDfdqNkMKAevTjWXsSLUYwzHhigCax,rDfdqNkMKAevTjWXsSLUYwzHhigCab
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO['limit'] =rDfdqNkMKAevTjWXsSLUYwzHhigCba.LIST_LIMIT
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO['offset']=rDfdqNkMKAevTjWXsSLUYwzHhigCcn((page_int-1)*rDfdqNkMKAevTjWXsSLUYwzHhigCba.LIST_LIMIT)
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO['page'] =rDfdqNkMKAevTjWXsSLUYwzHhigCcn(page_int)
   if rDfdqNkMKAevTjWXsSLUYwzHhigCbO.get('orderby')!='' and rDfdqNkMKAevTjWXsSLUYwzHhigCbO.get('orderby')!='regdatefirst' and orderby!='-':
    rDfdqNkMKAevTjWXsSLUYwzHhigCbO['orderby']=orderby 
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if rDfdqNkMKAevTjWXsSLUYwzHhigCIO.find('instantplay')>=0:
    if not('celllist' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp['band']):return rDfdqNkMKAevTjWXsSLUYwzHhigCax,rDfdqNkMKAevTjWXsSLUYwzHhigCab
    rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['band']['celllist']
   else:
    if not('celllist' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']):return rDfdqNkMKAevTjWXsSLUYwzHhigCax,rDfdqNkMKAevTjWXsSLUYwzHhigCab
    rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['celllist']
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCIF:
    for rDfdqNkMKAevTjWXsSLUYwzHhigCaJ in rDfdqNkMKAevTjWXsSLUYwzHhigCIG['event_list']:
     if rDfdqNkMKAevTjWXsSLUYwzHhigCaJ.get('type')=='on-navigation':
      rDfdqNkMKAevTjWXsSLUYwzHhigCaI =rDfdqNkMKAevTjWXsSLUYwzHhigCaJ['url']
    rDfdqNkMKAevTjWXsSLUYwzHhigCap=urllib.parse.urlsplit(rDfdqNkMKAevTjWXsSLUYwzHhigCaI).query
    rDfdqNkMKAevTjWXsSLUYwzHhigCaE=rDfdqNkMKAevTjWXsSLUYwzHhigCap[0:rDfdqNkMKAevTjWXsSLUYwzHhigCap.find('=')]
    rDfdqNkMKAevTjWXsSLUYwzHhigCac=rDfdqNkMKAevTjWXsSLUYwzHhigCap[rDfdqNkMKAevTjWXsSLUYwzHhigCap.find('=')+1:]
    rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'title':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][0]['text'],'age':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['age'],'thumbnail':'https://%s'%rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('thumbnail'),'videoid':rDfdqNkMKAevTjWXsSLUYwzHhigCac,'vidtype':rDfdqNkMKAevTjWXsSLUYwzHhigCaE}
    rDfdqNkMKAevTjWXsSLUYwzHhigCax.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
   if rDfdqNkMKAevTjWXsSLUYwzHhigCIO.find('instantplay')<0:
    rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['pagecount'])
    if rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['count']:rDfdqNkMKAevTjWXsSLUYwzHhigCal =rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['count'])
    else:rDfdqNkMKAevTjWXsSLUYwzHhigCal=rDfdqNkMKAevTjWXsSLUYwzHhigCba.LIST_LIMIT*page_int
    rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCIm>rDfdqNkMKAevTjWXsSLUYwzHhigCal
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[],rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  return rDfdqNkMKAevTjWXsSLUYwzHhigCax,rDfdqNkMKAevTjWXsSLUYwzHhigCab
 def Get_Movie_List(rDfdqNkMKAevTjWXsSLUYwzHhigCba,rDfdqNkMKAevTjWXsSLUYwzHhigCIO,page_int=1,orderby='-'):
  rDfdqNkMKAevTjWXsSLUYwzHhigCau=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCal=1
  rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  (rDfdqNkMKAevTjWXsSLUYwzHhigCbm,rDfdqNkMKAevTjWXsSLUYwzHhigCbO)=rDfdqNkMKAevTjWXsSLUYwzHhigCba.Baseapi_Parse(rDfdqNkMKAevTjWXsSLUYwzHhigCIO)
  if rDfdqNkMKAevTjWXsSLUYwzHhigCbm=='':return rDfdqNkMKAevTjWXsSLUYwzHhigCau,rDfdqNkMKAevTjWXsSLUYwzHhigCab
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO['limit']=rDfdqNkMKAevTjWXsSLUYwzHhigCba.MV_LIMIT
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO['offset']=rDfdqNkMKAevTjWXsSLUYwzHhigCcn((page_int-1)*rDfdqNkMKAevTjWXsSLUYwzHhigCba.MV_LIMIT)
   if rDfdqNkMKAevTjWXsSLUYwzHhigCbO.get('orderby')!='' and rDfdqNkMKAevTjWXsSLUYwzHhigCbO.get('orderby')!='regdatefirst' and orderby!='-':
    rDfdqNkMKAevTjWXsSLUYwzHhigCbO['orderby']=orderby 
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('celllist' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']):return rDfdqNkMKAevTjWXsSLUYwzHhigCau,rDfdqNkMKAevTjWXsSLUYwzHhigCab
   rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['celllist']
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCIF:
    rDfdqNkMKAevTjWXsSLUYwzHhigCaI =rDfdqNkMKAevTjWXsSLUYwzHhigCIG['event_list'][1]['url']
    rDfdqNkMKAevTjWXsSLUYwzHhigCap=urllib.parse.urlsplit(rDfdqNkMKAevTjWXsSLUYwzHhigCaI).query
    rDfdqNkMKAevTjWXsSLUYwzHhigCaE=rDfdqNkMKAevTjWXsSLUYwzHhigCap[0:rDfdqNkMKAevTjWXsSLUYwzHhigCap.find('=')]
    rDfdqNkMKAevTjWXsSLUYwzHhigCac=rDfdqNkMKAevTjWXsSLUYwzHhigCap[rDfdqNkMKAevTjWXsSLUYwzHhigCap.find('=')+1:]
    rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'title':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][0]['text'],'age':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['age'],'thumbnail':'https://%s'%rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('thumbnail'),'videoid':rDfdqNkMKAevTjWXsSLUYwzHhigCac,'vidtype':rDfdqNkMKAevTjWXsSLUYwzHhigCaE}
    rDfdqNkMKAevTjWXsSLUYwzHhigCau.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['pagecount'])
   if rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['count']:rDfdqNkMKAevTjWXsSLUYwzHhigCal =rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['count'])
   else:rDfdqNkMKAevTjWXsSLUYwzHhigCal=rDfdqNkMKAevTjWXsSLUYwzHhigCba.MV_LIMIT*page_int
   rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCIm>rDfdqNkMKAevTjWXsSLUYwzHhigCal
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[],rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  return rDfdqNkMKAevTjWXsSLUYwzHhigCau,rDfdqNkMKAevTjWXsSLUYwzHhigCab
 def ProgramidToContentid(rDfdqNkMKAevTjWXsSLUYwzHhigCba,rDfdqNkMKAevTjWXsSLUYwzHhigCaF):
  rDfdqNkMKAevTjWXsSLUYwzHhigCaO=''
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm =rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/vod/programs-contentid/'+rDfdqNkMKAevTjWXsSLUYwzHhigCaF
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCaV=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('contentid' in rDfdqNkMKAevTjWXsSLUYwzHhigCaV):return rDfdqNkMKAevTjWXsSLUYwzHhigCaO 
   rDfdqNkMKAevTjWXsSLUYwzHhigCaO=rDfdqNkMKAevTjWXsSLUYwzHhigCaV['contentid']
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
  return rDfdqNkMKAevTjWXsSLUYwzHhigCaO
 def ContentidToSeasonid(rDfdqNkMKAevTjWXsSLUYwzHhigCba,rDfdqNkMKAevTjWXsSLUYwzHhigCaO):
  rDfdqNkMKAevTjWXsSLUYwzHhigCaF=''
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm =rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/fz/vod/contents/'+rDfdqNkMKAevTjWXsSLUYwzHhigCaO
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCaV=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('programid' in rDfdqNkMKAevTjWXsSLUYwzHhigCaV):return rDfdqNkMKAevTjWXsSLUYwzHhigCaF 
   rDfdqNkMKAevTjWXsSLUYwzHhigCaF=rDfdqNkMKAevTjWXsSLUYwzHhigCaV['programid']
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
  return rDfdqNkMKAevTjWXsSLUYwzHhigCaF
 def GetProgramInfo(rDfdqNkMKAevTjWXsSLUYwzHhigCba,rDfdqNkMKAevTjWXsSLUYwzHhigCaO):
  rDfdqNkMKAevTjWXsSLUYwzHhigCaG={}
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/fz/vod/contents/'+rDfdqNkMKAevTjWXsSLUYwzHhigCaO
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCaV=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   rDfdqNkMKAevTjWXsSLUYwzHhigCan=img_fanart=rDfdqNkMKAevTjWXsSLUYwzHhigCaB=''
   if rDfdqNkMKAevTjWXsSLUYwzHhigCaV.get('programposterimage')!='':rDfdqNkMKAevTjWXsSLUYwzHhigCan =rDfdqNkMKAevTjWXsSLUYwzHhigCba.HTTPTAG+rDfdqNkMKAevTjWXsSLUYwzHhigCaV.get('programposterimage')
   if rDfdqNkMKAevTjWXsSLUYwzHhigCaV.get('programimage') !='':img_fanart =rDfdqNkMKAevTjWXsSLUYwzHhigCba.HTTPTAG+rDfdqNkMKAevTjWXsSLUYwzHhigCaV.get('programimage')
   if rDfdqNkMKAevTjWXsSLUYwzHhigCaV.get('programcircleimage')!='':rDfdqNkMKAevTjWXsSLUYwzHhigCaB=rDfdqNkMKAevTjWXsSLUYwzHhigCba.HTTPTAG+rDfdqNkMKAevTjWXsSLUYwzHhigCaV.get('programcircleimage')
   if 'poster_default' in rDfdqNkMKAevTjWXsSLUYwzHhigCan:
    rDfdqNkMKAevTjWXsSLUYwzHhigCan =img_fanart
    rDfdqNkMKAevTjWXsSLUYwzHhigCaB=''
   rDfdqNkMKAevTjWXsSLUYwzHhigCaG={'imgPoster':rDfdqNkMKAevTjWXsSLUYwzHhigCan,'imgFanart':img_fanart,'imgClearlogo':rDfdqNkMKAevTjWXsSLUYwzHhigCaB,'programtitle':rDfdqNkMKAevTjWXsSLUYwzHhigCaV.get('programtitle'),'programid':rDfdqNkMKAevTjWXsSLUYwzHhigCaV.get('programid'),'synopsis':rDfdqNkMKAevTjWXsSLUYwzHhigCaV.get('programsynopsis').replace('<br>','\n'),}
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
  return rDfdqNkMKAevTjWXsSLUYwzHhigCaG
 def Get_Season_List(rDfdqNkMKAevTjWXsSLUYwzHhigCba,seasonid):
  rDfdqNkMKAevTjWXsSLUYwzHhigCat=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCaO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.ProgramidToContentid(seasonid)
  rDfdqNkMKAevTjWXsSLUYwzHhigCaR=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetProgramInfo(rDfdqNkMKAevTjWXsSLUYwzHhigCaO)
  rDfdqNkMKAevTjWXsSLUYwzHhigCaQ={'poster':rDfdqNkMKAevTjWXsSLUYwzHhigCaR.get('imgPoster'),'fanart':rDfdqNkMKAevTjWXsSLUYwzHhigCaR.get('imgFanart'),'clearlogo':rDfdqNkMKAevTjWXsSLUYwzHhigCaR.get('imgClearlogo'),}
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO={'limit':'10','offset':'0','orderby':'new',}
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   for rDfdqNkMKAevTjWXsSLUYwzHhigCao in rDfdqNkMKAevTjWXsSLUYwzHhigCIp['filter']['filterlist'][0]['filter_item_list']:
    rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'season_Nm':rDfdqNkMKAevTjWXsSLUYwzHhigCao.get('title'),'season_Id':rDfdqNkMKAevTjWXsSLUYwzHhigCao.get('api_path'),'thumbnail':rDfdqNkMKAevTjWXsSLUYwzHhigCaQ,'programNm':rDfdqNkMKAevTjWXsSLUYwzHhigCaR.get('programtitle'),'synopsis':rDfdqNkMKAevTjWXsSLUYwzHhigCaR.get('synopsis'),}
    rDfdqNkMKAevTjWXsSLUYwzHhigCat.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[]
  return rDfdqNkMKAevTjWXsSLUYwzHhigCat
 def Get_Episode_List(rDfdqNkMKAevTjWXsSLUYwzHhigCba,seasionid,page_int=1,orderby='desc'):
  rDfdqNkMKAevTjWXsSLUYwzHhigCaP=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCal=1
  rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  rDfdqNkMKAevTjWXsSLUYwzHhigCaR={}
  rDfdqNkMKAevTjWXsSLUYwzHhigCaO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.ProgramidToContentid(seasionid)
  rDfdqNkMKAevTjWXsSLUYwzHhigCaR=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetProgramInfo(rDfdqNkMKAevTjWXsSLUYwzHhigCaO)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO={'limit':rDfdqNkMKAevTjWXsSLUYwzHhigCba.EP_LIMIT,'offset':rDfdqNkMKAevTjWXsSLUYwzHhigCcn((page_int-1)*rDfdqNkMKAevTjWXsSLUYwzHhigCba.EP_LIMIT),'orderby':orderby,}
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['celllist']
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCIF:
    rDfdqNkMKAevTjWXsSLUYwzHhigCpb=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('synopsis'))
    rDfdqNkMKAevTjWXsSLUYwzHhigCpI=rDfdqNkMKAevTjWXsSLUYwzHhigCba.HTTPTAG+rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('thumbnail')
    rDfdqNkMKAevTjWXsSLUYwzHhigCpa=rDfdqNkMKAevTjWXsSLUYwzHhigCpE=rDfdqNkMKAevTjWXsSLUYwzHhigCpc=''
    rDfdqNkMKAevTjWXsSLUYwzHhigCpa =rDfdqNkMKAevTjWXsSLUYwzHhigCaR.get('imgPoster')
    rDfdqNkMKAevTjWXsSLUYwzHhigCpE =rDfdqNkMKAevTjWXsSLUYwzHhigCaR.get('imgFanart')
    rDfdqNkMKAevTjWXsSLUYwzHhigCpc =rDfdqNkMKAevTjWXsSLUYwzHhigCaR.get('imgClearlogo')
    rDfdqNkMKAevTjWXsSLUYwzHhigCpl=rDfdqNkMKAevTjWXsSLUYwzHhigCaR.get('programtitle')
    rDfdqNkMKAevTjWXsSLUYwzHhigCaQ={'thumb':rDfdqNkMKAevTjWXsSLUYwzHhigCpI,'poster':rDfdqNkMKAevTjWXsSLUYwzHhigCpa,'fanart':rDfdqNkMKAevTjWXsSLUYwzHhigCpE,'clearlogo':rDfdqNkMKAevTjWXsSLUYwzHhigCpc}
    rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'programtitle':rDfdqNkMKAevTjWXsSLUYwzHhigCpl,'episodetitle':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][0]['text'],'episodenumber':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][1]['text'].replace('$O$',''),'contentid':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['contentid'],'synopsis':rDfdqNkMKAevTjWXsSLUYwzHhigCpb,'episodeactors':rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('actors').split(',')if rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('actors')!='' else[],'thumbnail':rDfdqNkMKAevTjWXsSLUYwzHhigCaQ,}
    rDfdqNkMKAevTjWXsSLUYwzHhigCaP.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['pagecount'])
   if rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['count']:rDfdqNkMKAevTjWXsSLUYwzHhigCal =rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['count'])
   else:rDfdqNkMKAevTjWXsSLUYwzHhigCal=rDfdqNkMKAevTjWXsSLUYwzHhigCba.EP_LIMIT*page_int
   rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCIm>rDfdqNkMKAevTjWXsSLUYwzHhigCal
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[],rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  return rDfdqNkMKAevTjWXsSLUYwzHhigCaP,rDfdqNkMKAevTjWXsSLUYwzHhigCab
 def GetEPGList(rDfdqNkMKAevTjWXsSLUYwzHhigCba,genre):
  rDfdqNkMKAevTjWXsSLUYwzHhigCpy={}
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCpx=rDfdqNkMKAevTjWXsSLUYwzHhigCba.Get_Now_Datetime()
   if genre=='all':
    rDfdqNkMKAevTjWXsSLUYwzHhigCpJ =rDfdqNkMKAevTjWXsSLUYwzHhigCpx+datetime.timedelta(hours=3)
   else:
    rDfdqNkMKAevTjWXsSLUYwzHhigCpJ =rDfdqNkMKAevTjWXsSLUYwzHhigCpx+datetime.timedelta(hours=3)
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/live/epgs'
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO={'limit':'100','offset':'0','genre':genre,'startdatetime':rDfdqNkMKAevTjWXsSLUYwzHhigCpx.strftime('%Y-%m-%d %H:00'),'enddatetime':rDfdqNkMKAevTjWXsSLUYwzHhigCpJ.strftime('%Y-%m-%d %H:00')}
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   rDfdqNkMKAevTjWXsSLUYwzHhigCpu=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['list']
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCpu:
    rDfdqNkMKAevTjWXsSLUYwzHhigCpO=''
    for rDfdqNkMKAevTjWXsSLUYwzHhigCpV in rDfdqNkMKAevTjWXsSLUYwzHhigCIG['list']:
     if rDfdqNkMKAevTjWXsSLUYwzHhigCpO:rDfdqNkMKAevTjWXsSLUYwzHhigCpO+='\n'
     rDfdqNkMKAevTjWXsSLUYwzHhigCpO+=rDfdqNkMKAevTjWXsSLUYwzHhigCba.Get_ChangeText(rDfdqNkMKAevTjWXsSLUYwzHhigCpV['title'])+'\n'
     rDfdqNkMKAevTjWXsSLUYwzHhigCpO+=' [%s ~ %s]'%(rDfdqNkMKAevTjWXsSLUYwzHhigCpV['starttime'][-5:],rDfdqNkMKAevTjWXsSLUYwzHhigCpV['endtime'][-5:])+'\n'
    rDfdqNkMKAevTjWXsSLUYwzHhigCpy[rDfdqNkMKAevTjWXsSLUYwzHhigCIG['channelid']]=rDfdqNkMKAevTjWXsSLUYwzHhigCpO
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
  return rDfdqNkMKAevTjWXsSLUYwzHhigCpy
 def Get_LiveChannel_List(rDfdqNkMKAevTjWXsSLUYwzHhigCba,genre,rDfdqNkMKAevTjWXsSLUYwzHhigCIO):
  rDfdqNkMKAevTjWXsSLUYwzHhigCIP=[]
  (rDfdqNkMKAevTjWXsSLUYwzHhigCbm,rDfdqNkMKAevTjWXsSLUYwzHhigCbO)=rDfdqNkMKAevTjWXsSLUYwzHhigCba.Baseapi_Parse(rDfdqNkMKAevTjWXsSLUYwzHhigCIO)
  if rDfdqNkMKAevTjWXsSLUYwzHhigCbm=='':return rDfdqNkMKAevTjWXsSLUYwzHhigCIP
  rDfdqNkMKAevTjWXsSLUYwzHhigCpF=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetEPGList(genre)
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO['genre']=genre
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('celllist' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']):return[]
   rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['celllist']
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCIF:
    rDfdqNkMKAevTjWXsSLUYwzHhigCaO=rDfdqNkMKAevTjWXsSLUYwzHhigCIG['contentid']
    if rDfdqNkMKAevTjWXsSLUYwzHhigCaO in rDfdqNkMKAevTjWXsSLUYwzHhigCpF:
     rDfdqNkMKAevTjWXsSLUYwzHhigCpG=rDfdqNkMKAevTjWXsSLUYwzHhigCpF[rDfdqNkMKAevTjWXsSLUYwzHhigCaO]
    else:
     rDfdqNkMKAevTjWXsSLUYwzHhigCpG=''
    rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'studio':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][0]['text'],'tvshowtitle':rDfdqNkMKAevTjWXsSLUYwzHhigCba.Get_ChangeText(rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][1]['text']),'channelid':rDfdqNkMKAevTjWXsSLUYwzHhigCaO,'age':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['age'],'thumbnail':'https://%s'%rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('thumbnail'),'epg':rDfdqNkMKAevTjWXsSLUYwzHhigCpG}
    rDfdqNkMKAevTjWXsSLUYwzHhigCIP.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[]
  return rDfdqNkMKAevTjWXsSLUYwzHhigCIP
 def Get_Search_List(rDfdqNkMKAevTjWXsSLUYwzHhigCba,search_key,sType,page_int,exclusion21=rDfdqNkMKAevTjWXsSLUYwzHhigCcO):
  rDfdqNkMKAevTjWXsSLUYwzHhigCpn=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCal=1
  rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCcO
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/fz/search/band.js'
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':rDfdqNkMKAevTjWXsSLUYwzHhigCcn((page_int-1)*rDfdqNkMKAevTjWXsSLUYwzHhigCba.SEARCH_LIMIT),'limit':rDfdqNkMKAevTjWXsSLUYwzHhigCba.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCaV=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('celllist' in rDfdqNkMKAevTjWXsSLUYwzHhigCaV['band']):return rDfdqNkMKAevTjWXsSLUYwzHhigCpn,rDfdqNkMKAevTjWXsSLUYwzHhigCab
   rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCaV['band']['celllist']
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCIF:
    rDfdqNkMKAevTjWXsSLUYwzHhigCaI =rDfdqNkMKAevTjWXsSLUYwzHhigCIG['event_list'][1]['url']
    rDfdqNkMKAevTjWXsSLUYwzHhigCap=urllib.parse.urlsplit(rDfdqNkMKAevTjWXsSLUYwzHhigCaI).query
    rDfdqNkMKAevTjWXsSLUYwzHhigCaE=rDfdqNkMKAevTjWXsSLUYwzHhigCap[0:rDfdqNkMKAevTjWXsSLUYwzHhigCap.find('=')]
    rDfdqNkMKAevTjWXsSLUYwzHhigCac=rDfdqNkMKAevTjWXsSLUYwzHhigCap[rDfdqNkMKAevTjWXsSLUYwzHhigCap.find('=')+1:]
    rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'title':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['title_list'][0]['text'],'age':rDfdqNkMKAevTjWXsSLUYwzHhigCIG['age'],'thumbnail':'https://%s'%rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('thumbnail'),'videoid':rDfdqNkMKAevTjWXsSLUYwzHhigCac,'vidtype':rDfdqNkMKAevTjWXsSLUYwzHhigCaE,}
    rDfdqNkMKAevTjWXsSLUYwzHhigCpB=rDfdqNkMKAevTjWXsSLUYwzHhigCcO
    for rDfdqNkMKAevTjWXsSLUYwzHhigCpt in rDfdqNkMKAevTjWXsSLUYwzHhigCIG['bottom_taglist']:
     if rDfdqNkMKAevTjWXsSLUYwzHhigCpt=='won':
      rDfdqNkMKAevTjWXsSLUYwzHhigCpB=rDfdqNkMKAevTjWXsSLUYwzHhigCcF
      break
    if rDfdqNkMKAevTjWXsSLUYwzHhigCpB==rDfdqNkMKAevTjWXsSLUYwzHhigCcF: 
     rDfdqNkMKAevTjWXsSLUYwzHhigCIn['title']=rDfdqNkMKAevTjWXsSLUYwzHhigCIn['title']+' [개별구매]'
    if exclusion21==rDfdqNkMKAevTjWXsSLUYwzHhigCcO or rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('age')!='21':
     rDfdqNkMKAevTjWXsSLUYwzHhigCpn.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIm=rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCaV['band']['pagecount'])
   if rDfdqNkMKAevTjWXsSLUYwzHhigCaV['band']['count']:rDfdqNkMKAevTjWXsSLUYwzHhigCal =rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCaV['band']['count'])
   else:rDfdqNkMKAevTjWXsSLUYwzHhigCal=rDfdqNkMKAevTjWXsSLUYwzHhigCba.LIST_LIMIT
   rDfdqNkMKAevTjWXsSLUYwzHhigCab=rDfdqNkMKAevTjWXsSLUYwzHhigCIm>rDfdqNkMKAevTjWXsSLUYwzHhigCal
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
  return rDfdqNkMKAevTjWXsSLUYwzHhigCpn,rDfdqNkMKAevTjWXsSLUYwzHhigCab 
 def GetStreamingURL(rDfdqNkMKAevTjWXsSLUYwzHhigCba,mode,rDfdqNkMKAevTjWXsSLUYwzHhigCaO,quality_int,pvrmode='-',playOption={}):
  rDfdqNkMKAevTjWXsSLUYwzHhigCpR ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'',}
  rDfdqNkMKAevTjWXsSLUYwzHhigCpQ=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCpo='hls'
  if mode=='LIVE':
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm =rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/live/channels/'+rDfdqNkMKAevTjWXsSLUYwzHhigCaO
   rDfdqNkMKAevTjWXsSLUYwzHhigCpP='live'
  elif mode=='VOD':
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm =rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/fz/vod/contents/'+rDfdqNkMKAevTjWXsSLUYwzHhigCaO
   rDfdqNkMKAevTjWXsSLUYwzHhigCpP='vod'
  elif mode=='MOVIE':
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm =rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/fz/movie/contents/'+rDfdqNkMKAevTjWXsSLUYwzHhigCaO
   rDfdqNkMKAevTjWXsSLUYwzHhigCpP='movie'
  rDfdqNkMKAevTjWXsSLUYwzHhigCpm={'hdr':'sdr',}
  try:
   if mode!='LIVE' or pvrmode=='-':
    rDfdqNkMKAevTjWXsSLUYwzHhigCbO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO)
    rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
    rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
    rDfdqNkMKAevTjWXsSLUYwzHhigCEb=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['qualities']['list']
    if rDfdqNkMKAevTjWXsSLUYwzHhigCEb==rDfdqNkMKAevTjWXsSLUYwzHhigCcu:return rDfdqNkMKAevTjWXsSLUYwzHhigCpR
    for rDfdqNkMKAevTjWXsSLUYwzHhigCEI in rDfdqNkMKAevTjWXsSLUYwzHhigCEb:
     rDfdqNkMKAevTjWXsSLUYwzHhigCpQ.append(rDfdqNkMKAevTjWXsSLUYwzHhigCcQ(rDfdqNkMKAevTjWXsSLUYwzHhigCEI.get('id').rstrip('p')))
    if 'type' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp:
     if rDfdqNkMKAevTjWXsSLUYwzHhigCIp['type']=='onair':
      rDfdqNkMKAevTjWXsSLUYwzHhigCpP='onairvod'
    if 'drms' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp:
     if rDfdqNkMKAevTjWXsSLUYwzHhigCIp['drms']:
      rDfdqNkMKAevTjWXsSLUYwzHhigCpo='dash'
    if playOption.get('enable_hdr'):
     for rDfdqNkMKAevTjWXsSLUYwzHhigCEa in rDfdqNkMKAevTjWXsSLUYwzHhigCIp.get('qualities').get('mediatypes'):
      if rDfdqNkMKAevTjWXsSLUYwzHhigCEa=='HDR10':
       rDfdqNkMKAevTjWXsSLUYwzHhigCpm['hdr']='hdr'
       break
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return rDfdqNkMKAevTjWXsSLUYwzHhigCpR
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCEp=rDfdqNkMKAevTjWXsSLUYwzHhigCba.CheckQuality(quality_int,rDfdqNkMKAevTjWXsSLUYwzHhigCpQ)
   if mode=='LIVE' and pvrmode!='-':
    rDfdqNkMKAevTjWXsSLUYwzHhigCEc='auto'
   else:
    rDfdqNkMKAevTjWXsSLUYwzHhigCEc=rDfdqNkMKAevTjWXsSLUYwzHhigCcn(rDfdqNkMKAevTjWXsSLUYwzHhigCEp)+'p'
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/fz/streaming'
   if rDfdqNkMKAevTjWXsSLUYwzHhigCpm['hdr']=='hdr':
    rDfdqNkMKAevTjWXsSLUYwzHhigCbO={'contentid':rDfdqNkMKAevTjWXsSLUYwzHhigCaO,'contenttype':rDfdqNkMKAevTjWXsSLUYwzHhigCpP,'quality':rDfdqNkMKAevTjWXsSLUYwzHhigCEc,'modelid':'SHIELD Android TV','guid':rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':rDfdqNkMKAevTjWXsSLUYwzHhigCpo,'protocol':rDfdqNkMKAevTjWXsSLUYwzHhigCpo,'hdr':'HDR10','videocodec':'AVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams_AND())
   else:
    rDfdqNkMKAevTjWXsSLUYwzHhigCbO={'contentid':rDfdqNkMKAevTjWXsSLUYwzHhigCaO,'contenttype':rDfdqNkMKAevTjWXsSLUYwzHhigCpP,'quality':rDfdqNkMKAevTjWXsSLUYwzHhigCEc,'deviceModelId':'Windows 10','guid':rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':rDfdqNkMKAevTjWXsSLUYwzHhigCpo,'protocol':rDfdqNkMKAevTjWXsSLUYwzHhigCpo,'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcF))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   rDfdqNkMKAevTjWXsSLUYwzHhigCpR['stream_url']=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['playurl']
   if rDfdqNkMKAevTjWXsSLUYwzHhigCpR['stream_url']==rDfdqNkMKAevTjWXsSLUYwzHhigCcu:return rDfdqNkMKAevTjWXsSLUYwzHhigCpR
   rDfdqNkMKAevTjWXsSLUYwzHhigCpR['stream_cookie']=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['awscookie']
   rDfdqNkMKAevTjWXsSLUYwzHhigCpR['stream_drm'] =rDfdqNkMKAevTjWXsSLUYwzHhigCIp['drm']
   if 'previewmsg' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp['preview']:rDfdqNkMKAevTjWXsSLUYwzHhigCpR['stream_preview']=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['preview']['previewmsg']
   if 'subtitles' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp:
    for rDfdqNkMKAevTjWXsSLUYwzHhigCEl in rDfdqNkMKAevTjWXsSLUYwzHhigCIp['subtitles']:
     if rDfdqNkMKAevTjWXsSLUYwzHhigCEl.get('languagecode')=='ko':
      rDfdqNkMKAevTjWXsSLUYwzHhigCpR['stream_vtt']=rDfdqNkMKAevTjWXsSLUYwzHhigCEl.get('url')
      break
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
  return rDfdqNkMKAevTjWXsSLUYwzHhigCpR 
 def GetSportsURL(rDfdqNkMKAevTjWXsSLUYwzHhigCba,rDfdqNkMKAevTjWXsSLUYwzHhigCaO,quality_int):
  rDfdqNkMKAevTjWXsSLUYwzHhigCpR ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'',}
  rDfdqNkMKAevTjWXsSLUYwzHhigCpQ=[]
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/streaming/other'
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO={'contentid':rDfdqNkMKAevTjWXsSLUYwzHhigCaO,'contenttype':'live','action':'hls','quality':rDfdqNkMKAevTjWXsSLUYwzHhigCcn(quality_int)+'p','deviceModelId':'Windows 10','guid':rDfdqNkMKAevTjWXsSLUYwzHhigCba.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcF))
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   rDfdqNkMKAevTjWXsSLUYwzHhigCpR['stream_url']=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['playurl']
   if rDfdqNkMKAevTjWXsSLUYwzHhigCpR['stream_url']==rDfdqNkMKAevTjWXsSLUYwzHhigCcu:return rDfdqNkMKAevTjWXsSLUYwzHhigCpR
   rDfdqNkMKAevTjWXsSLUYwzHhigCpR['stream_cookie']=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['awscookie']
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
  return rDfdqNkMKAevTjWXsSLUYwzHhigCpR
 def make_viewdate(rDfdqNkMKAevTjWXsSLUYwzHhigCba):
  rDfdqNkMKAevTjWXsSLUYwzHhigCEy =rDfdqNkMKAevTjWXsSLUYwzHhigCba.Get_Now_Datetime()
  rDfdqNkMKAevTjWXsSLUYwzHhigCEx =rDfdqNkMKAevTjWXsSLUYwzHhigCEy+datetime.timedelta(days=-1)
  rDfdqNkMKAevTjWXsSLUYwzHhigCEJ =rDfdqNkMKAevTjWXsSLUYwzHhigCEy+datetime.timedelta(days=1)
  rDfdqNkMKAevTjWXsSLUYwzHhigCEu=[rDfdqNkMKAevTjWXsSLUYwzHhigCEy.strftime('%Y%m%d'),rDfdqNkMKAevTjWXsSLUYwzHhigCEJ.strftime('%Y%m%d'),]
  return rDfdqNkMKAevTjWXsSLUYwzHhigCEu
 def Get_Sports_Gamelist(rDfdqNkMKAevTjWXsSLUYwzHhigCba):
  rDfdqNkMKAevTjWXsSLUYwzHhigCEO =rDfdqNkMKAevTjWXsSLUYwzHhigCba.make_viewdate()
  rDfdqNkMKAevTjWXsSLUYwzHhigCEV=[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCEF =[]
  for rDfdqNkMKAevTjWXsSLUYwzHhigCEG in rDfdqNkMKAevTjWXsSLUYwzHhigCEO:
   rDfdqNkMKAevTjWXsSLUYwzHhigCEn=rDfdqNkMKAevTjWXsSLUYwzHhigCEG[:6]
   if rDfdqNkMKAevTjWXsSLUYwzHhigCEn not in rDfdqNkMKAevTjWXsSLUYwzHhigCEV:
    rDfdqNkMKAevTjWXsSLUYwzHhigCEV.append(rDfdqNkMKAevTjWXsSLUYwzHhigCEn)
  try:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO.update(rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO))
   for rDfdqNkMKAevTjWXsSLUYwzHhigCEB in rDfdqNkMKAevTjWXsSLUYwzHhigCEV:
    rDfdqNkMKAevTjWXsSLUYwzHhigCbO['date']=rDfdqNkMKAevTjWXsSLUYwzHhigCEB
    rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
    rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
    rDfdqNkMKAevTjWXsSLUYwzHhigCIF=rDfdqNkMKAevTjWXsSLUYwzHhigCIp['cell_toplist']['celllist']
    for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCIF:
     rDfdqNkMKAevTjWXsSLUYwzHhigCEt=rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('game_date')
     rDfdqNkMKAevTjWXsSLUYwzHhigCER =rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('svc_id')
     if rDfdqNkMKAevTjWXsSLUYwzHhigCER=='':continue
     if rDfdqNkMKAevTjWXsSLUYwzHhigCEt in rDfdqNkMKAevTjWXsSLUYwzHhigCEO:
      rDfdqNkMKAevTjWXsSLUYwzHhigCEQ=rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('game_status') 
      rDfdqNkMKAevTjWXsSLUYwzHhigCEo =rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('title_list')[0].get('text')
      rDfdqNkMKAevTjWXsSLUYwzHhigCEt =rDfdqNkMKAevTjWXsSLUYwzHhigCEt[:4]+'-'+rDfdqNkMKAevTjWXsSLUYwzHhigCEt[4:6]+'-'+rDfdqNkMKAevTjWXsSLUYwzHhigCEt[-2:]
      rDfdqNkMKAevTjWXsSLUYwzHhigCEP =rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('game_time')
      rDfdqNkMKAevTjWXsSLUYwzHhigCEP =rDfdqNkMKAevTjWXsSLUYwzHhigCEP[:2]+':'+rDfdqNkMKAevTjWXsSLUYwzHhigCEP[-2:]
      rDfdqNkMKAevTjWXsSLUYwzHhigCIn={'game_date':rDfdqNkMKAevTjWXsSLUYwzHhigCEt,'game_time':rDfdqNkMKAevTjWXsSLUYwzHhigCEP,'svc_id':rDfdqNkMKAevTjWXsSLUYwzHhigCER,'away_team':rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('away_team').get('team_name'),'home_team':rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('home_team').get('team_name'),'game_status':rDfdqNkMKAevTjWXsSLUYwzHhigCEQ,'game_place':rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('game_place'),}
      rDfdqNkMKAevTjWXsSLUYwzHhigCEF.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIn)
  except rDfdqNkMKAevTjWXsSLUYwzHhigCcB as exception:
   rDfdqNkMKAevTjWXsSLUYwzHhigCct(exception)
   return[]
  rDfdqNkMKAevTjWXsSLUYwzHhigCEm=[]
  for i in rDfdqNkMKAevTjWXsSLUYwzHhigCcG(2):
   for rDfdqNkMKAevTjWXsSLUYwzHhigCIG in rDfdqNkMKAevTjWXsSLUYwzHhigCEF:
    if i==0 and rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('game_status')=='LIVE':
     rDfdqNkMKAevTjWXsSLUYwzHhigCEm.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIG)
    elif i==1 and rDfdqNkMKAevTjWXsSLUYwzHhigCIG.get('game_status')!='LIVE':
     rDfdqNkMKAevTjWXsSLUYwzHhigCEm.append(rDfdqNkMKAevTjWXsSLUYwzHhigCIG)
  return rDfdqNkMKAevTjWXsSLUYwzHhigCEm
 def GetBookmarkInfo(rDfdqNkMKAevTjWXsSLUYwzHhigCba,rDfdqNkMKAevTjWXsSLUYwzHhigCac,rDfdqNkMKAevTjWXsSLUYwzHhigCaE,rDfdqNkMKAevTjWXsSLUYwzHhigCpP):
  if rDfdqNkMKAevTjWXsSLUYwzHhigCaE=='tvshow':
   if rDfdqNkMKAevTjWXsSLUYwzHhigCpP=='contentid':
    rDfdqNkMKAevTjWXsSLUYwzHhigCaO=rDfdqNkMKAevTjWXsSLUYwzHhigCac
    rDfdqNkMKAevTjWXsSLUYwzHhigCac =rDfdqNkMKAevTjWXsSLUYwzHhigCba.ContentidToSeasonid(rDfdqNkMKAevTjWXsSLUYwzHhigCaO)
   else:
    rDfdqNkMKAevTjWXsSLUYwzHhigCaO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.ProgramidToContentid(rDfdqNkMKAevTjWXsSLUYwzHhigCac)
  else:
   rDfdqNkMKAevTjWXsSLUYwzHhigCaO=''
  rDfdqNkMKAevTjWXsSLUYwzHhigCcb={'indexinfo':{'ott':'wavve','videoid':rDfdqNkMKAevTjWXsSLUYwzHhigCac,'vidtype':rDfdqNkMKAevTjWXsSLUYwzHhigCaE,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':rDfdqNkMKAevTjWXsSLUYwzHhigCaE,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if rDfdqNkMKAevTjWXsSLUYwzHhigCaE=='tvshow':
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/fz/vod/contents/'+rDfdqNkMKAevTjWXsSLUYwzHhigCaO 
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('programtitle' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp):return{}
   rDfdqNkMKAevTjWXsSLUYwzHhigCcI=rDfdqNkMKAevTjWXsSLUYwzHhigCIp
   rDfdqNkMKAevTjWXsSLUYwzHhigCca=rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('programtitle')
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['title']=rDfdqNkMKAevTjWXsSLUYwzHhigCca
   if rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('targetage')=='18' or rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('targetage')=='19' or rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('targetage')=='21':
    rDfdqNkMKAevTjWXsSLUYwzHhigCca +=u' (%s)'%(rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('targetage'))
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['title'] =rDfdqNkMKAevTjWXsSLUYwzHhigCca
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['mpaa'] =rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('targetage')
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['plot'] =rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('programsynopsis').replace('<br>','\n')
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['studio'] =rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('channelname')
   if rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('firstreleaseyear')!='':rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['year'] =rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('firstreleaseyear')
   if rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('firstreleasedate')!='':rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['premiered']=rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('firstreleasedate')
   if rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('genretext') !='':rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['genre'] =[rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('genretext')]
   rDfdqNkMKAevTjWXsSLUYwzHhigCcp=[]
   for rDfdqNkMKAevTjWXsSLUYwzHhigCcE in rDfdqNkMKAevTjWXsSLUYwzHhigCcI['actors']['list']:rDfdqNkMKAevTjWXsSLUYwzHhigCcp.append(rDfdqNkMKAevTjWXsSLUYwzHhigCcE.get('text'))
   if rDfdqNkMKAevTjWXsSLUYwzHhigCco(rDfdqNkMKAevTjWXsSLUYwzHhigCcp)>0:
    if rDfdqNkMKAevTjWXsSLUYwzHhigCcp[0]!='':rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['cast']=rDfdqNkMKAevTjWXsSLUYwzHhigCcp
   rDfdqNkMKAevTjWXsSLUYwzHhigCpa =''
   rDfdqNkMKAevTjWXsSLUYwzHhigCpE =''
   rDfdqNkMKAevTjWXsSLUYwzHhigCpc=''
   if rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('programposterimage')!='':rDfdqNkMKAevTjWXsSLUYwzHhigCpa =rDfdqNkMKAevTjWXsSLUYwzHhigCba.HTTPTAG+rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('programposterimage')
   if rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('programimage') !='':rDfdqNkMKAevTjWXsSLUYwzHhigCpE =rDfdqNkMKAevTjWXsSLUYwzHhigCba.HTTPTAG+rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('programimage')
   if rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('programcircleimage')!='':rDfdqNkMKAevTjWXsSLUYwzHhigCpc=rDfdqNkMKAevTjWXsSLUYwzHhigCba.HTTPTAG+rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('programcircleimage')
   if 'poster_default' in rDfdqNkMKAevTjWXsSLUYwzHhigCpa:
    rDfdqNkMKAevTjWXsSLUYwzHhigCpa =rDfdqNkMKAevTjWXsSLUYwzHhigCpE
    rDfdqNkMKAevTjWXsSLUYwzHhigCpc=''
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['thumbnail']['poster']=rDfdqNkMKAevTjWXsSLUYwzHhigCpa
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['thumbnail']['thumb']=rDfdqNkMKAevTjWXsSLUYwzHhigCpE
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['thumbnail']['clearlogo']=rDfdqNkMKAevTjWXsSLUYwzHhigCpc
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['thumbnail']['fanart']=rDfdqNkMKAevTjWXsSLUYwzHhigCpE
  else:
   rDfdqNkMKAevTjWXsSLUYwzHhigCbm=rDfdqNkMKAevTjWXsSLUYwzHhigCba.API_DOMAIN+'/movie/contents/'+rDfdqNkMKAevTjWXsSLUYwzHhigCac 
   rDfdqNkMKAevTjWXsSLUYwzHhigCbO=rDfdqNkMKAevTjWXsSLUYwzHhigCba.GetDefaultParams(login=rDfdqNkMKAevTjWXsSLUYwzHhigCcO)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIa=rDfdqNkMKAevTjWXsSLUYwzHhigCba.callRequestCookies('Get',rDfdqNkMKAevTjWXsSLUYwzHhigCbm,payload=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,params=rDfdqNkMKAevTjWXsSLUYwzHhigCbO,headers=rDfdqNkMKAevTjWXsSLUYwzHhigCcu,cookies=rDfdqNkMKAevTjWXsSLUYwzHhigCcu)
   rDfdqNkMKAevTjWXsSLUYwzHhigCIp=json.loads(rDfdqNkMKAevTjWXsSLUYwzHhigCIa.text)
   if not('title' in rDfdqNkMKAevTjWXsSLUYwzHhigCIp):return{}
   rDfdqNkMKAevTjWXsSLUYwzHhigCcI=rDfdqNkMKAevTjWXsSLUYwzHhigCIp
   rDfdqNkMKAevTjWXsSLUYwzHhigCca=rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('title')
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['title']=rDfdqNkMKAevTjWXsSLUYwzHhigCca
   if rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('targetage')=='18' or rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('targetage')=='19' or rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('targetage')=='21':
    rDfdqNkMKAevTjWXsSLUYwzHhigCca +=u' (%s)'%(rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('targetage'))
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['title'] =rDfdqNkMKAevTjWXsSLUYwzHhigCca
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['mpaa'] =rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('targetage')
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['plot'] =rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('synopsis').replace('<br>','\n')
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['duration']=rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('playtime')
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['country']=rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('country')
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['studio'] =rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('cpname')
   if rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('releasedate')!='':
    rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['year'] =rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('releasedate')[:4]
    rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['premiered']=rDfdqNkMKAevTjWXsSLUYwzHhigCcI.get('releasedate')
   rDfdqNkMKAevTjWXsSLUYwzHhigCcp=[]
   for rDfdqNkMKAevTjWXsSLUYwzHhigCcE in rDfdqNkMKAevTjWXsSLUYwzHhigCcI['actors']['list']:rDfdqNkMKAevTjWXsSLUYwzHhigCcp.append(rDfdqNkMKAevTjWXsSLUYwzHhigCcE.get('text'))
   if rDfdqNkMKAevTjWXsSLUYwzHhigCco(rDfdqNkMKAevTjWXsSLUYwzHhigCcp)>0:
    if rDfdqNkMKAevTjWXsSLUYwzHhigCcp[0]!='':rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['cast']=rDfdqNkMKAevTjWXsSLUYwzHhigCcp
   rDfdqNkMKAevTjWXsSLUYwzHhigCcl=[]
   for rDfdqNkMKAevTjWXsSLUYwzHhigCcy in rDfdqNkMKAevTjWXsSLUYwzHhigCcI['directors']['list']:rDfdqNkMKAevTjWXsSLUYwzHhigCcl.append(rDfdqNkMKAevTjWXsSLUYwzHhigCcy.get('text'))
   if rDfdqNkMKAevTjWXsSLUYwzHhigCco(rDfdqNkMKAevTjWXsSLUYwzHhigCcl)>0:
    if rDfdqNkMKAevTjWXsSLUYwzHhigCcl[0]!='':rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['director']=rDfdqNkMKAevTjWXsSLUYwzHhigCcl
   rDfdqNkMKAevTjWXsSLUYwzHhigCIu=[]
   for rDfdqNkMKAevTjWXsSLUYwzHhigCcx in rDfdqNkMKAevTjWXsSLUYwzHhigCcI['genre']['list']:rDfdqNkMKAevTjWXsSLUYwzHhigCIu.append(rDfdqNkMKAevTjWXsSLUYwzHhigCcx.get('text'))
   if rDfdqNkMKAevTjWXsSLUYwzHhigCco(rDfdqNkMKAevTjWXsSLUYwzHhigCIu)>0:
    if rDfdqNkMKAevTjWXsSLUYwzHhigCIu[0]!='':rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['infoLabels']['genre']=rDfdqNkMKAevTjWXsSLUYwzHhigCIu
   rDfdqNkMKAevTjWXsSLUYwzHhigCpa ='https://%s'%rDfdqNkMKAevTjWXsSLUYwzHhigCcI['image']
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['thumbnail']['poster'] =rDfdqNkMKAevTjWXsSLUYwzHhigCpa
   rDfdqNkMKAevTjWXsSLUYwzHhigCcb['saveinfo']['thumbnail']['thumb'] =rDfdqNkMKAevTjWXsSLUYwzHhigCpa
  return rDfdqNkMKAevTjWXsSLUYwzHhigCcb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
