__author__="NightRain"
aGifcrMSUgRVwtnLYqoQECNpWFeKTj=object
aGifcrMSUgRVwtnLYqoQECNpWFeKTD=None
aGifcrMSUgRVwtnLYqoQECNpWFeKTA=True
aGifcrMSUgRVwtnLYqoQECNpWFeKTm=False
aGifcrMSUgRVwtnLYqoQECNpWFeKTy=int
aGifcrMSUgRVwtnLYqoQECNpWFeKTH=type
aGifcrMSUgRVwtnLYqoQECNpWFeKTB=dict
aGifcrMSUgRVwtnLYqoQECNpWFeKTl=len
aGifcrMSUgRVwtnLYqoQECNpWFeKTd=range
aGifcrMSUgRVwtnLYqoQECNpWFeKTh=str
aGifcrMSUgRVwtnLYqoQECNpWFeKTz=open
aGifcrMSUgRVwtnLYqoQECNpWFeKTx=Exception
aGifcrMSUgRVwtnLYqoQECNpWFeKTP=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
aGifcrMSUgRVwtnLYqoQECNpWFeKvD=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
aGifcrMSUgRVwtnLYqoQECNpWFeKvA=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
aGifcrMSUgRVwtnLYqoQECNpWFeKvm=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
aGifcrMSUgRVwtnLYqoQECNpWFeKvy =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
aGifcrMSUgRVwtnLYqoQECNpWFeKvT=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class aGifcrMSUgRVwtnLYqoQECNpWFeKvj(aGifcrMSUgRVwtnLYqoQECNpWFeKTj):
 def __init__(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,aGifcrMSUgRVwtnLYqoQECNpWFeKvB,aGifcrMSUgRVwtnLYqoQECNpWFeKvl,aGifcrMSUgRVwtnLYqoQECNpWFeKvd):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_url =aGifcrMSUgRVwtnLYqoQECNpWFeKvB
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle=aGifcrMSUgRVwtnLYqoQECNpWFeKvl
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params =aGifcrMSUgRVwtnLYqoQECNpWFeKvd
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj =WCHfdmKqzGAYFxglIohSniBcPaTEwe() 
 def addon_noti(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,sting):
  try:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvz=xbmcgui.Dialog()
   aGifcrMSUgRVwtnLYqoQECNpWFeKvz.notification(__addonname__,sting)
  except:
   aGifcrMSUgRVwtnLYqoQECNpWFeKTD
 def addon_log(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,string):
  try:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvx=string.encode('utf-8','ignore')
  except:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvx='addonException: addon_log'
  aGifcrMSUgRVwtnLYqoQECNpWFeKvP=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,aGifcrMSUgRVwtnLYqoQECNpWFeKvx),level=aGifcrMSUgRVwtnLYqoQECNpWFeKvP)
 def get_keyboard_input(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,aGifcrMSUgRVwtnLYqoQECNpWFeKjB):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvJ=aGifcrMSUgRVwtnLYqoQECNpWFeKTD
  kb=xbmc.Keyboard()
  kb.setHeading(aGifcrMSUgRVwtnLYqoQECNpWFeKjB)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   aGifcrMSUgRVwtnLYqoQECNpWFeKvJ=kb.getText()
  return aGifcrMSUgRVwtnLYqoQECNpWFeKvJ
 def get_settings_login_info(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvI =__addon__.getSetting('id')
  aGifcrMSUgRVwtnLYqoQECNpWFeKvO =__addon__.getSetting('pw')
  aGifcrMSUgRVwtnLYqoQECNpWFeKvs=__addon__.getSetting('selected_profile')
  return(aGifcrMSUgRVwtnLYqoQECNpWFeKvI,aGifcrMSUgRVwtnLYqoQECNpWFeKvO,aGifcrMSUgRVwtnLYqoQECNpWFeKvs)
 def get_settings_totalsearch(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvk =aGifcrMSUgRVwtnLYqoQECNpWFeKTA if __addon__.getSetting('local_search')=='true' else aGifcrMSUgRVwtnLYqoQECNpWFeKTm
  aGifcrMSUgRVwtnLYqoQECNpWFeKvb=aGifcrMSUgRVwtnLYqoQECNpWFeKTA if __addon__.getSetting('local_history')=='true' else aGifcrMSUgRVwtnLYqoQECNpWFeKTm
  aGifcrMSUgRVwtnLYqoQECNpWFeKvu =aGifcrMSUgRVwtnLYqoQECNpWFeKTA if __addon__.getSetting('total_search')=='true' else aGifcrMSUgRVwtnLYqoQECNpWFeKTm
  aGifcrMSUgRVwtnLYqoQECNpWFeKvX=aGifcrMSUgRVwtnLYqoQECNpWFeKTA if __addon__.getSetting('total_history')=='true' else aGifcrMSUgRVwtnLYqoQECNpWFeKTm
  aGifcrMSUgRVwtnLYqoQECNpWFeKjv=aGifcrMSUgRVwtnLYqoQECNpWFeKTA if __addon__.getSetting('menu_bookmark')=='true' else aGifcrMSUgRVwtnLYqoQECNpWFeKTm
  return(aGifcrMSUgRVwtnLYqoQECNpWFeKvk,aGifcrMSUgRVwtnLYqoQECNpWFeKvb,aGifcrMSUgRVwtnLYqoQECNpWFeKvu,aGifcrMSUgRVwtnLYqoQECNpWFeKvX,aGifcrMSUgRVwtnLYqoQECNpWFeKjv)
 def get_settings_makebookmark(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  return aGifcrMSUgRVwtnLYqoQECNpWFeKTA if __addon__.getSetting('make_bookmark')=='true' else aGifcrMSUgRVwtnLYqoQECNpWFeKTm
 def get_selQuality(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  try:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjD=[1080,720,480,360]
   aGifcrMSUgRVwtnLYqoQECNpWFeKjA=aGifcrMSUgRVwtnLYqoQECNpWFeKTy(__addon__.getSetting('selected_quality'))
   return aGifcrMSUgRVwtnLYqoQECNpWFeKjD[aGifcrMSUgRVwtnLYqoQECNpWFeKjA]
  except:
   aGifcrMSUgRVwtnLYqoQECNpWFeKTD
  return 1080 
 def get_settings_exclusion21(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  aGifcrMSUgRVwtnLYqoQECNpWFeKjm =__addon__.getSetting('exclusion21')
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjm=='false':
   return aGifcrMSUgRVwtnLYqoQECNpWFeKTm
  else:
   return aGifcrMSUgRVwtnLYqoQECNpWFeKTA
 def get_settings_direct_replay(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  aGifcrMSUgRVwtnLYqoQECNpWFeKjy=aGifcrMSUgRVwtnLYqoQECNpWFeKTy(__addon__.getSetting('direct_replay'))
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjy==0:
   return aGifcrMSUgRVwtnLYqoQECNpWFeKTm
  else:
   return aGifcrMSUgRVwtnLYqoQECNpWFeKTA
 def set_winCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,credential):
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT=xbmcgui.Window(10000)
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT.setProperty('WAVVE_M_CREDENTIAL',credential)
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT.setProperty('WAVVE_M_LOGINTIME',aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT=xbmcgui.Window(10000)
  return aGifcrMSUgRVwtnLYqoQECNpWFeKjT.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,aGifcrMSUgRVwtnLYqoQECNpWFeKmj):
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT=xbmcgui.Window(10000)
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT.setProperty('WAVVE_M_ORDERBY',aGifcrMSUgRVwtnLYqoQECNpWFeKmj)
 def get_winEpisodeOrderby(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT=xbmcgui.Window(10000)
  return aGifcrMSUgRVwtnLYqoQECNpWFeKjT.getProperty('WAVVE_M_ORDERBY')
 def add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,label,sublabel='',img='',infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params='',isLink=aGifcrMSUgRVwtnLYqoQECNpWFeKTm,ContextMenu=aGifcrMSUgRVwtnLYqoQECNpWFeKTD):
  aGifcrMSUgRVwtnLYqoQECNpWFeKjH='%s?%s'%(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_url,urllib.parse.urlencode(params))
  if sublabel:aGifcrMSUgRVwtnLYqoQECNpWFeKjB='%s < %s >'%(label,sublabel)
  else: aGifcrMSUgRVwtnLYqoQECNpWFeKjB=label
  if not img:img='DefaultFolder.png'
  aGifcrMSUgRVwtnLYqoQECNpWFeKjl=xbmcgui.ListItem(aGifcrMSUgRVwtnLYqoQECNpWFeKjB)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTH(img)==aGifcrMSUgRVwtnLYqoQECNpWFeKTB:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjl.setArt(img)
  else:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjl.setArt({'thumb':img,'poster':img})
  if infoLabels:aGifcrMSUgRVwtnLYqoQECNpWFeKjl.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjl.setProperty('IsPlayable','true')
  if ContextMenu:aGifcrMSUgRVwtnLYqoQECNpWFeKjl.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,aGifcrMSUgRVwtnLYqoQECNpWFeKjH,aGifcrMSUgRVwtnLYqoQECNpWFeKjl,isFolder)
 def dp_Main_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  (aGifcrMSUgRVwtnLYqoQECNpWFeKvk,aGifcrMSUgRVwtnLYqoQECNpWFeKvb,aGifcrMSUgRVwtnLYqoQECNpWFeKvu,aGifcrMSUgRVwtnLYqoQECNpWFeKvX,aGifcrMSUgRVwtnLYqoQECNpWFeKjv)=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_settings_totalsearch()
  for aGifcrMSUgRVwtnLYqoQECNpWFeKjd in aGifcrMSUgRVwtnLYqoQECNpWFeKvD:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB=aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('title')
   aGifcrMSUgRVwtnLYqoQECNpWFeKjh=''
   if aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('mode')=='SEARCH_GROUP' and aGifcrMSUgRVwtnLYqoQECNpWFeKvk ==aGifcrMSUgRVwtnLYqoQECNpWFeKTm:continue
   elif aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('mode')=='SEARCH_HISTORY' and aGifcrMSUgRVwtnLYqoQECNpWFeKvb==aGifcrMSUgRVwtnLYqoQECNpWFeKTm:continue
   elif aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('mode')=='TOTAL_SEARCH' and aGifcrMSUgRVwtnLYqoQECNpWFeKvu ==aGifcrMSUgRVwtnLYqoQECNpWFeKTm:continue
   elif aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('mode')=='TOTAL_HISTORY' and aGifcrMSUgRVwtnLYqoQECNpWFeKvX==aGifcrMSUgRVwtnLYqoQECNpWFeKTm:continue
   elif aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('mode')=='MENU_BOOKMARK' and aGifcrMSUgRVwtnLYqoQECNpWFeKjv==aGifcrMSUgRVwtnLYqoQECNpWFeKTm:continue
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('mode'),'sCode':aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('sCode'),'sIndex':aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('sIndex'),'sType':aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('sType'),'suburl':aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('suburl'),'subapi':aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('subapi'),'page':aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('page'),'orderby':aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('orderby'),'ordernm':aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('ordernm')}
   if aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    aGifcrMSUgRVwtnLYqoQECNpWFeKjx=aGifcrMSUgRVwtnLYqoQECNpWFeKTm
    aGifcrMSUgRVwtnLYqoQECNpWFeKjP =aGifcrMSUgRVwtnLYqoQECNpWFeKTA
   else:
    aGifcrMSUgRVwtnLYqoQECNpWFeKjx=aGifcrMSUgRVwtnLYqoQECNpWFeKTA
    aGifcrMSUgRVwtnLYqoQECNpWFeKjP =aGifcrMSUgRVwtnLYqoQECNpWFeKTm
   if 'icon' in aGifcrMSUgRVwtnLYqoQECNpWFeKjd:aGifcrMSUgRVwtnLYqoQECNpWFeKjh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',aGifcrMSUgRVwtnLYqoQECNpWFeKjd.get('icon')) 
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img=aGifcrMSUgRVwtnLYqoQECNpWFeKjh,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKjx,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz,isLink=aGifcrMSUgRVwtnLYqoQECNpWFeKjP)
  xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTA)
 def dp_Search_Group(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  if 'search_key' in args:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjO=args.get('search_key')
  else:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjO=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not aGifcrMSUgRVwtnLYqoQECNpWFeKjO:
    return
  for aGifcrMSUgRVwtnLYqoQECNpWFeKjs in aGifcrMSUgRVwtnLYqoQECNpWFeKvA:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjk =aGifcrMSUgRVwtnLYqoQECNpWFeKjs.get('mode')
   aGifcrMSUgRVwtnLYqoQECNpWFeKjb=aGifcrMSUgRVwtnLYqoQECNpWFeKjs.get('sType')
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB=aGifcrMSUgRVwtnLYqoQECNpWFeKjs.get('title')
   (aGifcrMSUgRVwtnLYqoQECNpWFeKju,aGifcrMSUgRVwtnLYqoQECNpWFeKjX)=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_Search_List(aGifcrMSUgRVwtnLYqoQECNpWFeKjO,aGifcrMSUgRVwtnLYqoQECNpWFeKjb,1,exclusion21=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_settings_exclusion21())
   aGifcrMSUgRVwtnLYqoQECNpWFeKDv={'plot':'검색어 : '+aGifcrMSUgRVwtnLYqoQECNpWFeKjO+'\n\n'+aGifcrMSUgRVwtnLYqoQECNpWFeKvH.Search_FreeList(aGifcrMSUgRVwtnLYqoQECNpWFeKju)}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':aGifcrMSUgRVwtnLYqoQECNpWFeKjk,'sType':aGifcrMSUgRVwtnLYqoQECNpWFeKjb,'search_key':aGifcrMSUgRVwtnLYqoQECNpWFeKjO,'page':'1',}
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img='',infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDv,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(aGifcrMSUgRVwtnLYqoQECNpWFeKvA)>0:xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTA)
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.Save_Searched_List(aGifcrMSUgRVwtnLYqoQECNpWFeKjO)
 def Search_FreeList(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,search_list):
  aGifcrMSUgRVwtnLYqoQECNpWFeKDj=''
  aGifcrMSUgRVwtnLYqoQECNpWFeKDA=7
  try:
   if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(search_list)==0:return '검색결과 없음'
   for i in aGifcrMSUgRVwtnLYqoQECNpWFeKTd(aGifcrMSUgRVwtnLYqoQECNpWFeKTl(search_list)):
    if i>=aGifcrMSUgRVwtnLYqoQECNpWFeKDA:
     aGifcrMSUgRVwtnLYqoQECNpWFeKDj=aGifcrMSUgRVwtnLYqoQECNpWFeKDj+'...'
     break
    aGifcrMSUgRVwtnLYqoQECNpWFeKDj=aGifcrMSUgRVwtnLYqoQECNpWFeKDj+search_list[i]['title']+'\n'
  except:
   return ''
  return aGifcrMSUgRVwtnLYqoQECNpWFeKDj
 def dp_Watch_Group(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDm in aGifcrMSUgRVwtnLYqoQECNpWFeKvm:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB=aGifcrMSUgRVwtnLYqoQECNpWFeKDm.get('title')
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':aGifcrMSUgRVwtnLYqoQECNpWFeKDm.get('mode'),'sType':aGifcrMSUgRVwtnLYqoQECNpWFeKDm.get('sType')}
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img='',infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(aGifcrMSUgRVwtnLYqoQECNpWFeKvm)>0:xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTA)
 def dp_Search_History(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKDy=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.Load_List_File('search')
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDT in aGifcrMSUgRVwtnLYqoQECNpWFeKDy:
   aGifcrMSUgRVwtnLYqoQECNpWFeKDH=aGifcrMSUgRVwtnLYqoQECNpWFeKTB(urllib.parse.parse_qsl(aGifcrMSUgRVwtnLYqoQECNpWFeKDT))
   aGifcrMSUgRVwtnLYqoQECNpWFeKDB=aGifcrMSUgRVwtnLYqoQECNpWFeKDH.get('skey').strip()
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'SEARCH_GROUP','search_key':aGifcrMSUgRVwtnLYqoQECNpWFeKDB,}
   aGifcrMSUgRVwtnLYqoQECNpWFeKDl={'mode':'SEARCH_REMOVE','sType':'ONE','skey':aGifcrMSUgRVwtnLYqoQECNpWFeKDB,}
   aGifcrMSUgRVwtnLYqoQECNpWFeKDd=urllib.parse.urlencode(aGifcrMSUgRVwtnLYqoQECNpWFeKDl)
   aGifcrMSUgRVwtnLYqoQECNpWFeKDh=[('선택된 검색어 ( %s ) 삭제'%(aGifcrMSUgRVwtnLYqoQECNpWFeKDB),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(aGifcrMSUgRVwtnLYqoQECNpWFeKDd))]
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKDB,sublabel='',img=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz,ContextMenu=aGifcrMSUgRVwtnLYqoQECNpWFeKDh)
  aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'plot':'검색목록 전체를 삭제합니다.'}
  aGifcrMSUgRVwtnLYqoQECNpWFeKjB='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'SEARCH_REMOVE','sType':'ALL','skey':'-',}
  aGifcrMSUgRVwtnLYqoQECNpWFeKjh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img=aGifcrMSUgRVwtnLYqoQECNpWFeKjh,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTm,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz,isLink=aGifcrMSUgRVwtnLYqoQECNpWFeKTA)
  xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def dp_Search_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.SaveCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKjb =args.get('sType')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDx =aGifcrMSUgRVwtnLYqoQECNpWFeKTy(args.get('page'))
  if 'search_key' in args:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjO=args.get('search_key')
  else:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjO=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not aGifcrMSUgRVwtnLYqoQECNpWFeKjO:
    xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle)
    return
  aGifcrMSUgRVwtnLYqoQECNpWFeKDP,aGifcrMSUgRVwtnLYqoQECNpWFeKjX=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_Search_List(aGifcrMSUgRVwtnLYqoQECNpWFeKjO,aGifcrMSUgRVwtnLYqoQECNpWFeKjb,aGifcrMSUgRVwtnLYqoQECNpWFeKDx,exclusion21=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_settings_exclusion21())
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDJ in aGifcrMSUgRVwtnLYqoQECNpWFeKDP:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('title')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDI=aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('thumbnail')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDO =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('age')
   if aGifcrMSUgRVwtnLYqoQECNpWFeKDO=='18' or aGifcrMSUgRVwtnLYqoQECNpWFeKDO=='19' or aGifcrMSUgRVwtnLYqoQECNpWFeKDO=='21':aGifcrMSUgRVwtnLYqoQECNpWFeKjB+=' (%s)'%(aGifcrMSUgRVwtnLYqoQECNpWFeKDO)
   aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'mediatype':'tvshow' if aGifcrMSUgRVwtnLYqoQECNpWFeKjb=='vod' else 'movie','mpaa':aGifcrMSUgRVwtnLYqoQECNpWFeKDO,'title':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'plot':aGifcrMSUgRVwtnLYqoQECNpWFeKjB}
   if aGifcrMSUgRVwtnLYqoQECNpWFeKjb=='vod':
    aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'EPISODE_LIST','videoid':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('videoid'),'vidtype':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('vidtype'),'page':'1'}
    aGifcrMSUgRVwtnLYqoQECNpWFeKjx=aGifcrMSUgRVwtnLYqoQECNpWFeKTA
   else:
    aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'MOVIE','contentid':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('videoid'),'title':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'thumbnail':aGifcrMSUgRVwtnLYqoQECNpWFeKDI,'age':aGifcrMSUgRVwtnLYqoQECNpWFeKDO}
    aGifcrMSUgRVwtnLYqoQECNpWFeKjx=aGifcrMSUgRVwtnLYqoQECNpWFeKTm
   if aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_settings_makebookmark():
    aGifcrMSUgRVwtnLYqoQECNpWFeKDs={'videoid':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('videoid'),'vidtype':'tvshow' if aGifcrMSUgRVwtnLYqoQECNpWFeKjb=='vod' else 'movie','vtitle':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'vsubtitle':'','contenttype':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('vidtype'),}
    aGifcrMSUgRVwtnLYqoQECNpWFeKDk=json.dumps(aGifcrMSUgRVwtnLYqoQECNpWFeKDs)
    aGifcrMSUgRVwtnLYqoQECNpWFeKDk=urllib.parse.quote(aGifcrMSUgRVwtnLYqoQECNpWFeKDk)
    aGifcrMSUgRVwtnLYqoQECNpWFeKDb='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(aGifcrMSUgRVwtnLYqoQECNpWFeKDk)
    aGifcrMSUgRVwtnLYqoQECNpWFeKDh=[('찜한 영상에 추가 (통합 bookmark mini)',aGifcrMSUgRVwtnLYqoQECNpWFeKDb)]
   else:
    aGifcrMSUgRVwtnLYqoQECNpWFeKDh=aGifcrMSUgRVwtnLYqoQECNpWFeKTD
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img=aGifcrMSUgRVwtnLYqoQECNpWFeKDI,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKjx,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz,ContextMenu=aGifcrMSUgRVwtnLYqoQECNpWFeKDh)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjX:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['mode'] ='SEARCH_LIST' 
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['sType']=aGifcrMSUgRVwtnLYqoQECNpWFeKjb 
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['page'] =aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['search_key']=aGifcrMSUgRVwtnLYqoQECNpWFeKjO
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB='[B]%s >>[/B]'%'다음 페이지'
   aGifcrMSUgRVwtnLYqoQECNpWFeKDu=aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel=aGifcrMSUgRVwtnLYqoQECNpWFeKDu,img=aGifcrMSUgRVwtnLYqoQECNpWFeKjh,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjb=='movie':xbmcplugin.setContent(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,'movies')
  else:xbmcplugin.setContent(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def dp_Watch_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKjb =args.get('sType')
  aGifcrMSUgRVwtnLYqoQECNpWFeKjy=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_settings_direct_replay()
  aGifcrMSUgRVwtnLYqoQECNpWFeKDP=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.Load_List_File(aGifcrMSUgRVwtnLYqoQECNpWFeKjb)
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDJ in aGifcrMSUgRVwtnLYqoQECNpWFeKDP:
   aGifcrMSUgRVwtnLYqoQECNpWFeKDH=aGifcrMSUgRVwtnLYqoQECNpWFeKTB(urllib.parse.parse_qsl(aGifcrMSUgRVwtnLYqoQECNpWFeKDJ))
   aGifcrMSUgRVwtnLYqoQECNpWFeKDX =aGifcrMSUgRVwtnLYqoQECNpWFeKDH.get('code').strip()
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB =aGifcrMSUgRVwtnLYqoQECNpWFeKDH.get('title').strip()
   aGifcrMSUgRVwtnLYqoQECNpWFeKDu =aGifcrMSUgRVwtnLYqoQECNpWFeKDH.get('subtitle').strip()
   if aGifcrMSUgRVwtnLYqoQECNpWFeKDu=='None':aGifcrMSUgRVwtnLYqoQECNpWFeKDu=''
   aGifcrMSUgRVwtnLYqoQECNpWFeKDI=aGifcrMSUgRVwtnLYqoQECNpWFeKDH.get('img').strip()
   aGifcrMSUgRVwtnLYqoQECNpWFeKAv =aGifcrMSUgRVwtnLYqoQECNpWFeKDH.get('videoid').strip()
   try:
    aGifcrMSUgRVwtnLYqoQECNpWFeKDI=aGifcrMSUgRVwtnLYqoQECNpWFeKDI.replace('\'','\"')
    aGifcrMSUgRVwtnLYqoQECNpWFeKDI=json.loads(aGifcrMSUgRVwtnLYqoQECNpWFeKDI)
   except:
    aGifcrMSUgRVwtnLYqoQECNpWFeKTD
   aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'plot':'%s\n%s'%(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,aGifcrMSUgRVwtnLYqoQECNpWFeKDu)}
   if aGifcrMSUgRVwtnLYqoQECNpWFeKjb=='vod':
    if aGifcrMSUgRVwtnLYqoQECNpWFeKjy==aGifcrMSUgRVwtnLYqoQECNpWFeKTm or aGifcrMSUgRVwtnLYqoQECNpWFeKAv==aGifcrMSUgRVwtnLYqoQECNpWFeKTD:
     aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'EPISODE_LIST','videoid':aGifcrMSUgRVwtnLYqoQECNpWFeKDX,'vidtype':'programid','page':'1'}
     aGifcrMSUgRVwtnLYqoQECNpWFeKjx=aGifcrMSUgRVwtnLYqoQECNpWFeKTA
    else:
     aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'VOD','programid':aGifcrMSUgRVwtnLYqoQECNpWFeKDX,'contentid':aGifcrMSUgRVwtnLYqoQECNpWFeKAv,'title':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'subtitle':aGifcrMSUgRVwtnLYqoQECNpWFeKDu,'thumbnail':aGifcrMSUgRVwtnLYqoQECNpWFeKDI}
     aGifcrMSUgRVwtnLYqoQECNpWFeKjx=aGifcrMSUgRVwtnLYqoQECNpWFeKTm
   else:
    aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'MOVIE','contentid':aGifcrMSUgRVwtnLYqoQECNpWFeKDX,'title':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'subtitle':aGifcrMSUgRVwtnLYqoQECNpWFeKDu,'thumbnail':aGifcrMSUgRVwtnLYqoQECNpWFeKDI}
    aGifcrMSUgRVwtnLYqoQECNpWFeKjx=aGifcrMSUgRVwtnLYqoQECNpWFeKTm
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel=aGifcrMSUgRVwtnLYqoQECNpWFeKDu,img=aGifcrMSUgRVwtnLYqoQECNpWFeKDI,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKjx,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'plot':'시청목록을 삭제합니다.'}
  aGifcrMSUgRVwtnLYqoQECNpWFeKjB='*** 시청목록 삭제 ***'
  aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'MYVIEW_REMOVE','sType':aGifcrMSUgRVwtnLYqoQECNpWFeKjb,'skey':'-',}
  aGifcrMSUgRVwtnLYqoQECNpWFeKjh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img=aGifcrMSUgRVwtnLYqoQECNpWFeKjh,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTm,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz,isLink=aGifcrMSUgRVwtnLYqoQECNpWFeKTA)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjb=='movie':xbmcplugin.setContent(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,'movies')
  else:xbmcplugin.setContent(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def Load_List_File(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,aGifcrMSUgRVwtnLYqoQECNpWFeKAx): 
  try:
   if aGifcrMSUgRVwtnLYqoQECNpWFeKAx=='search':
    aGifcrMSUgRVwtnLYqoQECNpWFeKAj=aGifcrMSUgRVwtnLYqoQECNpWFeKvT
   elif aGifcrMSUgRVwtnLYqoQECNpWFeKAx in['vod','movie']:
    aGifcrMSUgRVwtnLYqoQECNpWFeKAj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%aGifcrMSUgRVwtnLYqoQECNpWFeKAx))
   else:
    return[]
   fp=aGifcrMSUgRVwtnLYqoQECNpWFeKTz(aGifcrMSUgRVwtnLYqoQECNpWFeKAj,'r',-1,'utf-8')
   aGifcrMSUgRVwtnLYqoQECNpWFeKAD=fp.readlines()
   fp.close()
  except:
   aGifcrMSUgRVwtnLYqoQECNpWFeKAD=[]
  return aGifcrMSUgRVwtnLYqoQECNpWFeKAD
 def Save_Watched_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,aGifcrMSUgRVwtnLYqoQECNpWFeKyX,aGifcrMSUgRVwtnLYqoQECNpWFeKvd):
  try:
   aGifcrMSUgRVwtnLYqoQECNpWFeKAm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%aGifcrMSUgRVwtnLYqoQECNpWFeKyX))
   aGifcrMSUgRVwtnLYqoQECNpWFeKAy=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.Load_List_File(aGifcrMSUgRVwtnLYqoQECNpWFeKyX) 
   fp=aGifcrMSUgRVwtnLYqoQECNpWFeKTz(aGifcrMSUgRVwtnLYqoQECNpWFeKAm,'w',-1,'utf-8')
   aGifcrMSUgRVwtnLYqoQECNpWFeKAT=urllib.parse.urlencode(aGifcrMSUgRVwtnLYqoQECNpWFeKvd)
   aGifcrMSUgRVwtnLYqoQECNpWFeKAT=aGifcrMSUgRVwtnLYqoQECNpWFeKAT+'\n'
   fp.write(aGifcrMSUgRVwtnLYqoQECNpWFeKAT)
   aGifcrMSUgRVwtnLYqoQECNpWFeKAH=0
   for aGifcrMSUgRVwtnLYqoQECNpWFeKAB in aGifcrMSUgRVwtnLYqoQECNpWFeKAy:
    aGifcrMSUgRVwtnLYqoQECNpWFeKAl=aGifcrMSUgRVwtnLYqoQECNpWFeKTB(urllib.parse.parse_qsl(aGifcrMSUgRVwtnLYqoQECNpWFeKAB))
    aGifcrMSUgRVwtnLYqoQECNpWFeKAd=aGifcrMSUgRVwtnLYqoQECNpWFeKvd.get('code').strip()
    aGifcrMSUgRVwtnLYqoQECNpWFeKAh=aGifcrMSUgRVwtnLYqoQECNpWFeKAl.get('code').strip()
    if aGifcrMSUgRVwtnLYqoQECNpWFeKyX=='vod' and aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_settings_direct_replay()==aGifcrMSUgRVwtnLYqoQECNpWFeKTA:
     aGifcrMSUgRVwtnLYqoQECNpWFeKAd=aGifcrMSUgRVwtnLYqoQECNpWFeKvd.get('videoid').strip()
     aGifcrMSUgRVwtnLYqoQECNpWFeKAh=aGifcrMSUgRVwtnLYqoQECNpWFeKAl.get('videoid').strip()if aGifcrMSUgRVwtnLYqoQECNpWFeKAh!=aGifcrMSUgRVwtnLYqoQECNpWFeKTD else '-'
    if aGifcrMSUgRVwtnLYqoQECNpWFeKAd!=aGifcrMSUgRVwtnLYqoQECNpWFeKAh:
     fp.write(aGifcrMSUgRVwtnLYqoQECNpWFeKAB)
     aGifcrMSUgRVwtnLYqoQECNpWFeKAH+=1
     if aGifcrMSUgRVwtnLYqoQECNpWFeKAH>=50:break
   fp.close()
  except:
   aGifcrMSUgRVwtnLYqoQECNpWFeKTD
 def Delete_List_File(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,aGifcrMSUgRVwtnLYqoQECNpWFeKAx,skey='-'):
  if aGifcrMSUgRVwtnLYqoQECNpWFeKAx=='ALL':
   try:
    aGifcrMSUgRVwtnLYqoQECNpWFeKAj=aGifcrMSUgRVwtnLYqoQECNpWFeKvT
    fp=aGifcrMSUgRVwtnLYqoQECNpWFeKTz(aGifcrMSUgRVwtnLYqoQECNpWFeKAj,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    aGifcrMSUgRVwtnLYqoQECNpWFeKTD
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKAx=='ONE':
   try:
    aGifcrMSUgRVwtnLYqoQECNpWFeKAj=aGifcrMSUgRVwtnLYqoQECNpWFeKvT
    aGifcrMSUgRVwtnLYqoQECNpWFeKAy=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.Load_List_File('search') 
    fp=aGifcrMSUgRVwtnLYqoQECNpWFeKTz(aGifcrMSUgRVwtnLYqoQECNpWFeKAj,'w',-1,'utf-8')
    for aGifcrMSUgRVwtnLYqoQECNpWFeKAB in aGifcrMSUgRVwtnLYqoQECNpWFeKAy:
     aGifcrMSUgRVwtnLYqoQECNpWFeKAl=aGifcrMSUgRVwtnLYqoQECNpWFeKTB(urllib.parse.parse_qsl(aGifcrMSUgRVwtnLYqoQECNpWFeKAB))
     aGifcrMSUgRVwtnLYqoQECNpWFeKAz=aGifcrMSUgRVwtnLYqoQECNpWFeKAl.get('skey').strip()
     if skey!=aGifcrMSUgRVwtnLYqoQECNpWFeKAz:
      fp.write(aGifcrMSUgRVwtnLYqoQECNpWFeKAB)
    fp.close()
   except:
    aGifcrMSUgRVwtnLYqoQECNpWFeKTD
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKAx in['vod','movie']:
   try:
    aGifcrMSUgRVwtnLYqoQECNpWFeKAj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%aGifcrMSUgRVwtnLYqoQECNpWFeKAx))
    fp=aGifcrMSUgRVwtnLYqoQECNpWFeKTz(aGifcrMSUgRVwtnLYqoQECNpWFeKAj,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    aGifcrMSUgRVwtnLYqoQECNpWFeKTD
 def dp_Listfile_Delete(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKAx=args.get('sType')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDB =args.get('skey')
  aGifcrMSUgRVwtnLYqoQECNpWFeKvz=xbmcgui.Dialog()
  if aGifcrMSUgRVwtnLYqoQECNpWFeKAx=='ALL':
   aGifcrMSUgRVwtnLYqoQECNpWFeKAP=aGifcrMSUgRVwtnLYqoQECNpWFeKvz.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKAx=='ONE':
   aGifcrMSUgRVwtnLYqoQECNpWFeKAP=aGifcrMSUgRVwtnLYqoQECNpWFeKvz.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKAx in['vod','movie']:
   aGifcrMSUgRVwtnLYqoQECNpWFeKAP=aGifcrMSUgRVwtnLYqoQECNpWFeKvz.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if aGifcrMSUgRVwtnLYqoQECNpWFeKAP==aGifcrMSUgRVwtnLYqoQECNpWFeKTm:sys.exit()
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.Delete_List_File(aGifcrMSUgRVwtnLYqoQECNpWFeKAx,skey=aGifcrMSUgRVwtnLYqoQECNpWFeKDB)
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,aGifcrMSUgRVwtnLYqoQECNpWFeKjO):
  try:
   aGifcrMSUgRVwtnLYqoQECNpWFeKAJ=aGifcrMSUgRVwtnLYqoQECNpWFeKvT
   aGifcrMSUgRVwtnLYqoQECNpWFeKAy=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.Load_List_File('search') 
   aGifcrMSUgRVwtnLYqoQECNpWFeKAI={'skey':aGifcrMSUgRVwtnLYqoQECNpWFeKjO.strip()}
   fp=aGifcrMSUgRVwtnLYqoQECNpWFeKTz(aGifcrMSUgRVwtnLYqoQECNpWFeKAJ,'w',-1,'utf-8')
   aGifcrMSUgRVwtnLYqoQECNpWFeKAT=urllib.parse.urlencode(aGifcrMSUgRVwtnLYqoQECNpWFeKAI)
   aGifcrMSUgRVwtnLYqoQECNpWFeKAT=aGifcrMSUgRVwtnLYqoQECNpWFeKAT+'\n'
   fp.write(aGifcrMSUgRVwtnLYqoQECNpWFeKAT)
   aGifcrMSUgRVwtnLYqoQECNpWFeKAH=0
   for aGifcrMSUgRVwtnLYqoQECNpWFeKAB in aGifcrMSUgRVwtnLYqoQECNpWFeKAy:
    aGifcrMSUgRVwtnLYqoQECNpWFeKAl=aGifcrMSUgRVwtnLYqoQECNpWFeKTB(urllib.parse.parse_qsl(aGifcrMSUgRVwtnLYqoQECNpWFeKAB))
    aGifcrMSUgRVwtnLYqoQECNpWFeKAd=aGifcrMSUgRVwtnLYqoQECNpWFeKAI.get('skey').strip()
    aGifcrMSUgRVwtnLYqoQECNpWFeKAh=aGifcrMSUgRVwtnLYqoQECNpWFeKAl.get('skey').strip()
    if aGifcrMSUgRVwtnLYqoQECNpWFeKAd!=aGifcrMSUgRVwtnLYqoQECNpWFeKAh:
     fp.write(aGifcrMSUgRVwtnLYqoQECNpWFeKAB)
     aGifcrMSUgRVwtnLYqoQECNpWFeKAH+=1
     if aGifcrMSUgRVwtnLYqoQECNpWFeKAH>=50:break
   fp.close()
  except:
   aGifcrMSUgRVwtnLYqoQECNpWFeKTD
 def dp_Global_Search(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKjk=args.get('mode')
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='TOTAL_SEARCH':
   aGifcrMSUgRVwtnLYqoQECNpWFeKAO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   aGifcrMSUgRVwtnLYqoQECNpWFeKAO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(aGifcrMSUgRVwtnLYqoQECNpWFeKAO)
 def dp_Bookmark_Menu(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKAO='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(aGifcrMSUgRVwtnLYqoQECNpWFeKAO)
 def login_main(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  (aGifcrMSUgRVwtnLYqoQECNpWFeKAs,aGifcrMSUgRVwtnLYqoQECNpWFeKAk,aGifcrMSUgRVwtnLYqoQECNpWFeKAb)=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_settings_login_info()
  if not(aGifcrMSUgRVwtnLYqoQECNpWFeKAs and aGifcrMSUgRVwtnLYqoQECNpWFeKAk):
   aGifcrMSUgRVwtnLYqoQECNpWFeKvz=xbmcgui.Dialog()
   aGifcrMSUgRVwtnLYqoQECNpWFeKAP=aGifcrMSUgRVwtnLYqoQECNpWFeKvz.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if aGifcrMSUgRVwtnLYqoQECNpWFeKAP==aGifcrMSUgRVwtnLYqoQECNpWFeKTA:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winEpisodeOrderby()=='':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.set_winEpisodeOrderby('desc')
  if aGifcrMSUgRVwtnLYqoQECNpWFeKvH.cookiefile_check():return
  aGifcrMSUgRVwtnLYqoQECNpWFeKAu =aGifcrMSUgRVwtnLYqoQECNpWFeKTy(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  aGifcrMSUgRVwtnLYqoQECNpWFeKAX=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if aGifcrMSUgRVwtnLYqoQECNpWFeKAX==aGifcrMSUgRVwtnLYqoQECNpWFeKTD or aGifcrMSUgRVwtnLYqoQECNpWFeKAX=='':
   aGifcrMSUgRVwtnLYqoQECNpWFeKAX=aGifcrMSUgRVwtnLYqoQECNpWFeKTy('19000101')
  else:
   aGifcrMSUgRVwtnLYqoQECNpWFeKAX=aGifcrMSUgRVwtnLYqoQECNpWFeKTy(re.sub('-','',aGifcrMSUgRVwtnLYqoQECNpWFeKAX))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   aGifcrMSUgRVwtnLYqoQECNpWFeKmv=0
   while aGifcrMSUgRVwtnLYqoQECNpWFeKTA:
    aGifcrMSUgRVwtnLYqoQECNpWFeKmv+=1
    time.sleep(0.05)
    if aGifcrMSUgRVwtnLYqoQECNpWFeKAX>=aGifcrMSUgRVwtnLYqoQECNpWFeKAu:return
    if aGifcrMSUgRVwtnLYqoQECNpWFeKmv>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if aGifcrMSUgRVwtnLYqoQECNpWFeKAX>=aGifcrMSUgRVwtnLYqoQECNpWFeKAu:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.GetCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKAs,aGifcrMSUgRVwtnLYqoQECNpWFeKAk,aGifcrMSUgRVwtnLYqoQECNpWFeKAb):
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.set_winCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.LoadCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKmj =args.get('orderby')
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.set_winEpisodeOrderby(aGifcrMSUgRVwtnLYqoQECNpWFeKmj)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.SaveCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKjk =args.get('mode')
  aGifcrMSUgRVwtnLYqoQECNpWFeKmD =args.get('contentid')
  aGifcrMSUgRVwtnLYqoQECNpWFeKmA =args.get('pvrmode')
  aGifcrMSUgRVwtnLYqoQECNpWFeKmy=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_selQuality()
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.addon_log(aGifcrMSUgRVwtnLYqoQECNpWFeKmD+' - '+aGifcrMSUgRVwtnLYqoQECNpWFeKjk)
  aGifcrMSUgRVwtnLYqoQECNpWFeKmT,aGifcrMSUgRVwtnLYqoQECNpWFeKmH,aGifcrMSUgRVwtnLYqoQECNpWFeKmB,aGifcrMSUgRVwtnLYqoQECNpWFeKml=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.GetStreamingURL(aGifcrMSUgRVwtnLYqoQECNpWFeKjk,aGifcrMSUgRVwtnLYqoQECNpWFeKmD,aGifcrMSUgRVwtnLYqoQECNpWFeKmy,aGifcrMSUgRVwtnLYqoQECNpWFeKmA)
  aGifcrMSUgRVwtnLYqoQECNpWFeKmd='%s|Cookie=%s'%(aGifcrMSUgRVwtnLYqoQECNpWFeKmT,aGifcrMSUgRVwtnLYqoQECNpWFeKmH)
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.addon_log(aGifcrMSUgRVwtnLYqoQECNpWFeKmd)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKmT=='':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.addon_noti(__language__(30907).encode('utf8'))
   return
  aGifcrMSUgRVwtnLYqoQECNpWFeKmh=xbmcgui.ListItem(path=aGifcrMSUgRVwtnLYqoQECNpWFeKmd)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKmB:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.addon_log('!!streaming_drm!!')
   aGifcrMSUgRVwtnLYqoQECNpWFeKmz=aGifcrMSUgRVwtnLYqoQECNpWFeKmB['customdata']
   aGifcrMSUgRVwtnLYqoQECNpWFeKmx =aGifcrMSUgRVwtnLYqoQECNpWFeKmB['drmhost']
   aGifcrMSUgRVwtnLYqoQECNpWFeKmP =inputstreamhelper.Helper('mpd',drm='widevine')
   if aGifcrMSUgRVwtnLYqoQECNpWFeKmP.check_inputstream():
    if aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='MOVIE':
     aGifcrMSUgRVwtnLYqoQECNpWFeKmJ='https://www.wavve.com/player/movie?movieid=%s'%aGifcrMSUgRVwtnLYqoQECNpWFeKmD
    else:
     aGifcrMSUgRVwtnLYqoQECNpWFeKmJ='https://www.wavve.com/player/vod?programid=%s&page=1'%aGifcrMSUgRVwtnLYqoQECNpWFeKmD
    aGifcrMSUgRVwtnLYqoQECNpWFeKmI={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':aGifcrMSUgRVwtnLYqoQECNpWFeKmz,'referer':aGifcrMSUgRVwtnLYqoQECNpWFeKmJ,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.USER_AGENT}
    aGifcrMSUgRVwtnLYqoQECNpWFeKmO=aGifcrMSUgRVwtnLYqoQECNpWFeKmx+'|'+urllib.parse.urlencode(aGifcrMSUgRVwtnLYqoQECNpWFeKmI)+'|R{SSM}|'
    aGifcrMSUgRVwtnLYqoQECNpWFeKmh.setProperty('inputstream',aGifcrMSUgRVwtnLYqoQECNpWFeKmP.inputstream_addon)
    aGifcrMSUgRVwtnLYqoQECNpWFeKmh.setProperty('inputstream.adaptive.manifest_type','mpd')
    aGifcrMSUgRVwtnLYqoQECNpWFeKmh.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    aGifcrMSUgRVwtnLYqoQECNpWFeKmh.setProperty('inputstream.adaptive.license_key',aGifcrMSUgRVwtnLYqoQECNpWFeKmO)
    aGifcrMSUgRVwtnLYqoQECNpWFeKmh.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.USER_AGENT,aGifcrMSUgRVwtnLYqoQECNpWFeKmH))
  xbmcplugin.setResolvedUrl(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,aGifcrMSUgRVwtnLYqoQECNpWFeKTA,aGifcrMSUgRVwtnLYqoQECNpWFeKmh)
  aGifcrMSUgRVwtnLYqoQECNpWFeKms=aGifcrMSUgRVwtnLYqoQECNpWFeKTm
  if aGifcrMSUgRVwtnLYqoQECNpWFeKml:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.addon_noti(aGifcrMSUgRVwtnLYqoQECNpWFeKml.encode('utf-8'))
   aGifcrMSUgRVwtnLYqoQECNpWFeKms=aGifcrMSUgRVwtnLYqoQECNpWFeKTA
  else:
   if '/preview.' in urllib.parse.urlsplit(aGifcrMSUgRVwtnLYqoQECNpWFeKmT).path:
    aGifcrMSUgRVwtnLYqoQECNpWFeKvH.addon_noti(__language__(30908).encode('utf8'))
    aGifcrMSUgRVwtnLYqoQECNpWFeKms=aGifcrMSUgRVwtnLYqoQECNpWFeKTA
  try:
   aGifcrMSUgRVwtnLYqoQECNpWFeKmk=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and aGifcrMSUgRVwtnLYqoQECNpWFeKms==aGifcrMSUgRVwtnLYqoQECNpWFeKTm and aGifcrMSUgRVwtnLYqoQECNpWFeKmk!='-':
    aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'code':aGifcrMSUgRVwtnLYqoQECNpWFeKmk,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    aGifcrMSUgRVwtnLYqoQECNpWFeKvH.Save_Watched_List(args.get('mode').lower(),aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  except:
   aGifcrMSUgRVwtnLYqoQECNpWFeKTD
 def logout(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvz=xbmcgui.Dialog()
  aGifcrMSUgRVwtnLYqoQECNpWFeKAP=aGifcrMSUgRVwtnLYqoQECNpWFeKvz.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if aGifcrMSUgRVwtnLYqoQECNpWFeKAP==aGifcrMSUgRVwtnLYqoQECNpWFeKTm:sys.exit()
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.wininfo_clear()
  if os.path.isfile(aGifcrMSUgRVwtnLYqoQECNpWFeKvy):os.remove(aGifcrMSUgRVwtnLYqoQECNpWFeKvy)
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT=xbmcgui.Window(10000)
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT.setProperty('WAVVE_M_CREDENTIAL','')
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  aGifcrMSUgRVwtnLYqoQECNpWFeKmb =aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_Now_Datetime()
  aGifcrMSUgRVwtnLYqoQECNpWFeKmu=aGifcrMSUgRVwtnLYqoQECNpWFeKmb+datetime.timedelta(days=aGifcrMSUgRVwtnLYqoQECNpWFeKTy(__addon__.getSetting('cache_ttl')))
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT=xbmcgui.Window(10000)
  aGifcrMSUgRVwtnLYqoQECNpWFeKmX={'wavve_token':aGifcrMSUgRVwtnLYqoQECNpWFeKjT.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':aGifcrMSUgRVwtnLYqoQECNpWFeKmu.strftime('%Y-%m-%d')}
  try: 
   fp=aGifcrMSUgRVwtnLYqoQECNpWFeKTz(aGifcrMSUgRVwtnLYqoQECNpWFeKvy,'w',-1,'utf-8')
   json.dump(aGifcrMSUgRVwtnLYqoQECNpWFeKmX,fp)
   fp.close()
  except aGifcrMSUgRVwtnLYqoQECNpWFeKTx as exception:
   aGifcrMSUgRVwtnLYqoQECNpWFeKTP(exception)
 def cookiefile_check(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  aGifcrMSUgRVwtnLYqoQECNpWFeKmX={}
  try: 
   fp=aGifcrMSUgRVwtnLYqoQECNpWFeKTz(aGifcrMSUgRVwtnLYqoQECNpWFeKvy,'r',-1,'utf-8')
   aGifcrMSUgRVwtnLYqoQECNpWFeKmX= json.load(fp)
   fp.close()
  except aGifcrMSUgRVwtnLYqoQECNpWFeKTx as exception:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.wininfo_clear()
   return aGifcrMSUgRVwtnLYqoQECNpWFeKTm
  aGifcrMSUgRVwtnLYqoQECNpWFeKAs =__addon__.getSetting('id')
  aGifcrMSUgRVwtnLYqoQECNpWFeKAk =__addon__.getSetting('pw')
  aGifcrMSUgRVwtnLYqoQECNpWFeKyv =__addon__.getSetting('selected_profile')
  aGifcrMSUgRVwtnLYqoQECNpWFeKmX['wavve_id']=base64.standard_b64decode(aGifcrMSUgRVwtnLYqoQECNpWFeKmX['wavve_id']).decode('utf-8')
  aGifcrMSUgRVwtnLYqoQECNpWFeKmX['wavve_pw']=base64.standard_b64decode(aGifcrMSUgRVwtnLYqoQECNpWFeKmX['wavve_pw']).decode('utf-8')
  if aGifcrMSUgRVwtnLYqoQECNpWFeKAs!=aGifcrMSUgRVwtnLYqoQECNpWFeKmX['wavve_id']or aGifcrMSUgRVwtnLYqoQECNpWFeKAk!=aGifcrMSUgRVwtnLYqoQECNpWFeKmX['wavve_pw']or aGifcrMSUgRVwtnLYqoQECNpWFeKyv!=aGifcrMSUgRVwtnLYqoQECNpWFeKmX['wavve_profile']:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.wininfo_clear()
   return aGifcrMSUgRVwtnLYqoQECNpWFeKTm
  aGifcrMSUgRVwtnLYqoQECNpWFeKAu =aGifcrMSUgRVwtnLYqoQECNpWFeKTy(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  aGifcrMSUgRVwtnLYqoQECNpWFeKyj=aGifcrMSUgRVwtnLYqoQECNpWFeKmX['wavve_limitdate']
  aGifcrMSUgRVwtnLYqoQECNpWFeKAX =aGifcrMSUgRVwtnLYqoQECNpWFeKTy(re.sub('-','',aGifcrMSUgRVwtnLYqoQECNpWFeKyj))
  if aGifcrMSUgRVwtnLYqoQECNpWFeKAX<aGifcrMSUgRVwtnLYqoQECNpWFeKAu:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.wininfo_clear()
   return aGifcrMSUgRVwtnLYqoQECNpWFeKTm
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT=xbmcgui.Window(10000)
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT.setProperty('WAVVE_M_CREDENTIAL',aGifcrMSUgRVwtnLYqoQECNpWFeKmX['wavve_token'])
  aGifcrMSUgRVwtnLYqoQECNpWFeKjT.setProperty('WAVVE_M_LOGINTIME',aGifcrMSUgRVwtnLYqoQECNpWFeKyj)
  return aGifcrMSUgRVwtnLYqoQECNpWFeKTA
 def dp_LiveCatagory_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.SaveCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKyD =args.get('sCode')
  aGifcrMSUgRVwtnLYqoQECNpWFeKyA=args.get('sIndex')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDP,aGifcrMSUgRVwtnLYqoQECNpWFeKym=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_LiveCatagory_List(aGifcrMSUgRVwtnLYqoQECNpWFeKyD,aGifcrMSUgRVwtnLYqoQECNpWFeKyA)
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDJ in aGifcrMSUgRVwtnLYqoQECNpWFeKDP:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('title')
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'LIVE_LIST','genre':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('genre'),'baseapi':aGifcrMSUgRVwtnLYqoQECNpWFeKym}
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img='',infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(aGifcrMSUgRVwtnLYqoQECNpWFeKDP)>0:xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def dp_MainCatagory_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.SaveCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKyD =args.get('sCode')
  aGifcrMSUgRVwtnLYqoQECNpWFeKyA=args.get('sIndex')
  aGifcrMSUgRVwtnLYqoQECNpWFeKjb =args.get('sType')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDP=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_MainCatagory_List(aGifcrMSUgRVwtnLYqoQECNpWFeKyD,aGifcrMSUgRVwtnLYqoQECNpWFeKyA)
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDJ in aGifcrMSUgRVwtnLYqoQECNpWFeKDP:
   if aGifcrMSUgRVwtnLYqoQECNpWFeKjb=='vod':
    if aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('subtype')=='catagory':
     aGifcrMSUgRVwtnLYqoQECNpWFeKjk='PROGRAM_LIST'
    else:
     aGifcrMSUgRVwtnLYqoQECNpWFeKjk='SUPERSECTION_LIST'
   elif aGifcrMSUgRVwtnLYqoQECNpWFeKjb=='movie':
    aGifcrMSUgRVwtnLYqoQECNpWFeKjk='MOVIE_LIST'
   else:
    aGifcrMSUgRVwtnLYqoQECNpWFeKjk=''
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB='%s (%s)'%(aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('title'),args.get('ordernm'))
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':aGifcrMSUgRVwtnLYqoQECNpWFeKjk,'suburl':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('suburl'),'subapi':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_settings_exclusion21():
    if aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('title')=='성인' or aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('title')=='성인+':continue
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img='',infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(aGifcrMSUgRVwtnLYqoQECNpWFeKDP)>0:xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def dp_Program_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.SaveCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKyT =args.get('subapi')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDx=aGifcrMSUgRVwtnLYqoQECNpWFeKTy(args.get('page'))
  aGifcrMSUgRVwtnLYqoQECNpWFeKmj =args.get('orderby')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDP,aGifcrMSUgRVwtnLYqoQECNpWFeKjX=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_Program_List(aGifcrMSUgRVwtnLYqoQECNpWFeKyT,aGifcrMSUgRVwtnLYqoQECNpWFeKDx,aGifcrMSUgRVwtnLYqoQECNpWFeKmj)
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDJ in aGifcrMSUgRVwtnLYqoQECNpWFeKDP:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('title')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDI=aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('thumbnail')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDO =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('age')
   if aGifcrMSUgRVwtnLYqoQECNpWFeKDO=='18' or aGifcrMSUgRVwtnLYqoQECNpWFeKDO=='19' or aGifcrMSUgRVwtnLYqoQECNpWFeKDO=='21':aGifcrMSUgRVwtnLYqoQECNpWFeKjB+=' (%s)'%(aGifcrMSUgRVwtnLYqoQECNpWFeKDO)
   aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'plot':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'mpaa':aGifcrMSUgRVwtnLYqoQECNpWFeKDO,'mediatype':'tvshow'}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'EPISODE_LIST','videoid':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('videoid'),'vidtype':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('vidtype'),'page':'1'}
   if aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_settings_makebookmark():
    aGifcrMSUgRVwtnLYqoQECNpWFeKDs={'videoid':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('videoid'),'vidtype':'tvshow','vtitle':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'vsubtitle':'','contenttype':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('vidtype'),}
    aGifcrMSUgRVwtnLYqoQECNpWFeKDk=json.dumps(aGifcrMSUgRVwtnLYqoQECNpWFeKDs)
    aGifcrMSUgRVwtnLYqoQECNpWFeKDk=urllib.parse.quote(aGifcrMSUgRVwtnLYqoQECNpWFeKDk)
    aGifcrMSUgRVwtnLYqoQECNpWFeKDb='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(aGifcrMSUgRVwtnLYqoQECNpWFeKDk)
    aGifcrMSUgRVwtnLYqoQECNpWFeKDh=[('찜한 영상에 추가 (통합 bookmark mini)',aGifcrMSUgRVwtnLYqoQECNpWFeKDb)]
   else:
    aGifcrMSUgRVwtnLYqoQECNpWFeKDh=aGifcrMSUgRVwtnLYqoQECNpWFeKTD
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img=aGifcrMSUgRVwtnLYqoQECNpWFeKDI,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz,ContextMenu=aGifcrMSUgRVwtnLYqoQECNpWFeKDh)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjX:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['mode'] ='PROGRAM_LIST' 
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['subapi']=aGifcrMSUgRVwtnLYqoQECNpWFeKyT 
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['page'] =aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB='[B]%s >>[/B]'%'다음 페이지'
   aGifcrMSUgRVwtnLYqoQECNpWFeKDu=aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel=aGifcrMSUgRVwtnLYqoQECNpWFeKDu,img=aGifcrMSUgRVwtnLYqoQECNpWFeKjh,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  xbmcplugin.setContent(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,'tvshows')
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(aGifcrMSUgRVwtnLYqoQECNpWFeKDP)>0:xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def dp_SuperSection_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.SaveCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKyH =args.get('suburl')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDP=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_SuperMultiSection_List(aGifcrMSUgRVwtnLYqoQECNpWFeKyH)
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDJ in aGifcrMSUgRVwtnLYqoQECNpWFeKDP:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('title')
   aGifcrMSUgRVwtnLYqoQECNpWFeKyT =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('subapi')
   aGifcrMSUgRVwtnLYqoQECNpWFeKyB=aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('cell_type')
   if aGifcrMSUgRVwtnLYqoQECNpWFeKyT.find('mtype=svod')>=0 or aGifcrMSUgRVwtnLYqoQECNpWFeKyT.find('mtype=ppv')>=0:
    aGifcrMSUgRVwtnLYqoQECNpWFeKjk='MOVIE_LIST'
   elif aGifcrMSUgRVwtnLYqoQECNpWFeKyB=='band_71':
    aGifcrMSUgRVwtnLYqoQECNpWFeKjk ='SUPERSECTION_LIST'
    (aGifcrMSUgRVwtnLYqoQECNpWFeKyl,aGifcrMSUgRVwtnLYqoQECNpWFeKyd)=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Baseapi_Parse(aGifcrMSUgRVwtnLYqoQECNpWFeKyT)
    aGifcrMSUgRVwtnLYqoQECNpWFeKyH=aGifcrMSUgRVwtnLYqoQECNpWFeKyd.get('api')
    aGifcrMSUgRVwtnLYqoQECNpWFeKyT=''
   elif aGifcrMSUgRVwtnLYqoQECNpWFeKyB=='band_2':
    aGifcrMSUgRVwtnLYqoQECNpWFeKjk='BAND2SECTION_LIST'
   elif aGifcrMSUgRVwtnLYqoQECNpWFeKyB=='band_live':
    aGifcrMSUgRVwtnLYqoQECNpWFeKjk='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',aGifcrMSUgRVwtnLYqoQECNpWFeKyT):
    aGifcrMSUgRVwtnLYqoQECNpWFeKjk='MOVIE_LIST'
   else:
    aGifcrMSUgRVwtnLYqoQECNpWFeKjk='PROGRAM_LIST'
   aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'plot':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'mediatype':'tvshow'}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':aGifcrMSUgRVwtnLYqoQECNpWFeKjk,'suburl':aGifcrMSUgRVwtnLYqoQECNpWFeKyH,'subapi':aGifcrMSUgRVwtnLYqoQECNpWFeKyT,'page':'1'}
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(aGifcrMSUgRVwtnLYqoQECNpWFeKDP)>0:xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def dp_BandLiveSection_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.SaveCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKyT =args.get('subapi')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDx=aGifcrMSUgRVwtnLYqoQECNpWFeKTy(args.get('page'))
  aGifcrMSUgRVwtnLYqoQECNpWFeKDP,aGifcrMSUgRVwtnLYqoQECNpWFeKjX=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_BandLiveSection_List(aGifcrMSUgRVwtnLYqoQECNpWFeKyT,aGifcrMSUgRVwtnLYqoQECNpWFeKDx)
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDJ in aGifcrMSUgRVwtnLYqoQECNpWFeKDP:
   aGifcrMSUgRVwtnLYqoQECNpWFeKyh =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('channelid')
   aGifcrMSUgRVwtnLYqoQECNpWFeKyz =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('studio')
   aGifcrMSUgRVwtnLYqoQECNpWFeKyx=aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('tvshowtitle')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDI =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('thumbnail')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDO =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('age')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'mediatype':'tvshow','mpaa':aGifcrMSUgRVwtnLYqoQECNpWFeKDO,'title':'%s < %s >'%(aGifcrMSUgRVwtnLYqoQECNpWFeKyz,aGifcrMSUgRVwtnLYqoQECNpWFeKyx),'tvshowtitle':aGifcrMSUgRVwtnLYqoQECNpWFeKyx,'studio':aGifcrMSUgRVwtnLYqoQECNpWFeKyz,'plot':aGifcrMSUgRVwtnLYqoQECNpWFeKyz}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'LIVE','contentid':aGifcrMSUgRVwtnLYqoQECNpWFeKyh}
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKyz,sublabel=aGifcrMSUgRVwtnLYqoQECNpWFeKyx,img=aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('thumbnail'),infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTm,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjX:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['mode'] ='BANDLIVESECTION_LIST' 
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['subapi']=aGifcrMSUgRVwtnLYqoQECNpWFeKyT
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['page'] =aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB='[B]%s >>[/B]'%'다음 페이지'
   aGifcrMSUgRVwtnLYqoQECNpWFeKDu=aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel=aGifcrMSUgRVwtnLYqoQECNpWFeKDu,img=aGifcrMSUgRVwtnLYqoQECNpWFeKjh,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(aGifcrMSUgRVwtnLYqoQECNpWFeKDP)>0:xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def dp_Band2Section_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.SaveCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKyT =args.get('subapi')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDx=aGifcrMSUgRVwtnLYqoQECNpWFeKTy(args.get('page'))
  aGifcrMSUgRVwtnLYqoQECNpWFeKDP,aGifcrMSUgRVwtnLYqoQECNpWFeKjX=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_Band2Section_List(aGifcrMSUgRVwtnLYqoQECNpWFeKyT,aGifcrMSUgRVwtnLYqoQECNpWFeKDx)
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDJ in aGifcrMSUgRVwtnLYqoQECNpWFeKDP:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('programtitle')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDu =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('episodetitle')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'plot':aGifcrMSUgRVwtnLYqoQECNpWFeKjB+'\n\n'+aGifcrMSUgRVwtnLYqoQECNpWFeKDu,'mpaa':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('age'),'mediatype':'episode'}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'VOD','programid':'-','contentid':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('videoid'),'thumbnail':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('thumbnail'),'title':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'subtitle':aGifcrMSUgRVwtnLYqoQECNpWFeKDu}
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel=aGifcrMSUgRVwtnLYqoQECNpWFeKDu,img=aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('thumbnail'),infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTm,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjX:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['mode'] ='BAND2SECTION_LIST' 
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['subapi']=aGifcrMSUgRVwtnLYqoQECNpWFeKyT
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['page'] =aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB='[B]%s >>[/B]'%'다음 페이지'
   aGifcrMSUgRVwtnLYqoQECNpWFeKDu=aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel=aGifcrMSUgRVwtnLYqoQECNpWFeKDu,img=aGifcrMSUgRVwtnLYqoQECNpWFeKjh,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(aGifcrMSUgRVwtnLYqoQECNpWFeKDP)>0:xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def dp_Movie_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.SaveCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKyT =args.get('subapi')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDx=aGifcrMSUgRVwtnLYqoQECNpWFeKTy(args.get('page'))
  aGifcrMSUgRVwtnLYqoQECNpWFeKDP,aGifcrMSUgRVwtnLYqoQECNpWFeKjX=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_Movie_List(aGifcrMSUgRVwtnLYqoQECNpWFeKyT,aGifcrMSUgRVwtnLYqoQECNpWFeKDx)
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDJ in aGifcrMSUgRVwtnLYqoQECNpWFeKDP:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('title')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDI=aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('thumbnail')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDO =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('age')
   if aGifcrMSUgRVwtnLYqoQECNpWFeKDO=='18' or aGifcrMSUgRVwtnLYqoQECNpWFeKDO=='19' or aGifcrMSUgRVwtnLYqoQECNpWFeKDO=='21':aGifcrMSUgRVwtnLYqoQECNpWFeKjB+=' (%s)'%(aGifcrMSUgRVwtnLYqoQECNpWFeKDO)
   aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'plot':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'mpaa':aGifcrMSUgRVwtnLYqoQECNpWFeKDO,'mediatype':'movie'}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'MOVIE','contentid':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('videoid'),'title':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'thumbnail':aGifcrMSUgRVwtnLYqoQECNpWFeKDI,'age':aGifcrMSUgRVwtnLYqoQECNpWFeKDO}
   if aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_settings_makebookmark():
    aGifcrMSUgRVwtnLYqoQECNpWFeKDs={'videoid':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('videoid'),'vidtype':'movie','vtitle':aGifcrMSUgRVwtnLYqoQECNpWFeKjB,'vsubtitle':'','contenttype':'programid',}
    aGifcrMSUgRVwtnLYqoQECNpWFeKDk=json.dumps(aGifcrMSUgRVwtnLYqoQECNpWFeKDs)
    aGifcrMSUgRVwtnLYqoQECNpWFeKDk=urllib.parse.quote(aGifcrMSUgRVwtnLYqoQECNpWFeKDk)
    aGifcrMSUgRVwtnLYqoQECNpWFeKDb='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(aGifcrMSUgRVwtnLYqoQECNpWFeKDk)
    aGifcrMSUgRVwtnLYqoQECNpWFeKDh=[('찜한 영상에 추가 (통합 bookmark mini)',aGifcrMSUgRVwtnLYqoQECNpWFeKDb)]
   else:
    aGifcrMSUgRVwtnLYqoQECNpWFeKDh=aGifcrMSUgRVwtnLYqoQECNpWFeKTD
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img=aGifcrMSUgRVwtnLYqoQECNpWFeKDI,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTm,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz,ContextMenu=aGifcrMSUgRVwtnLYqoQECNpWFeKDh)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjX:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['mode'] ='MOVIE_LIST' 
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['subapi']=aGifcrMSUgRVwtnLYqoQECNpWFeKyT 
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['page'] =aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB='[B]%s >>[/B]'%'다음 페이지'
   aGifcrMSUgRVwtnLYqoQECNpWFeKDu=aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel=aGifcrMSUgRVwtnLYqoQECNpWFeKDu,img=aGifcrMSUgRVwtnLYqoQECNpWFeKjh,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  xbmcplugin.setContent(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,'movies')
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(aGifcrMSUgRVwtnLYqoQECNpWFeKDP)>0:xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def dp_Set_Bookmark(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKyP=urllib.parse.unquote(args.get('bm_param'))
  aGifcrMSUgRVwtnLYqoQECNpWFeKyP=json.loads(aGifcrMSUgRVwtnLYqoQECNpWFeKyP)
  aGifcrMSUgRVwtnLYqoQECNpWFeKAv =aGifcrMSUgRVwtnLYqoQECNpWFeKyP.get('videoid')
  aGifcrMSUgRVwtnLYqoQECNpWFeKyJ =aGifcrMSUgRVwtnLYqoQECNpWFeKyP.get('vidtype')
  aGifcrMSUgRVwtnLYqoQECNpWFeKyI =aGifcrMSUgRVwtnLYqoQECNpWFeKyP.get('vtitle')
  aGifcrMSUgRVwtnLYqoQECNpWFeKyO =aGifcrMSUgRVwtnLYqoQECNpWFeKyP.get('vsubtitle')
  aGifcrMSUgRVwtnLYqoQECNpWFeKys=aGifcrMSUgRVwtnLYqoQECNpWFeKyP.get('contenttype')
  aGifcrMSUgRVwtnLYqoQECNpWFeKvz=xbmcgui.Dialog()
  aGifcrMSUgRVwtnLYqoQECNpWFeKAP=aGifcrMSUgRVwtnLYqoQECNpWFeKvz.yesno(__language__(30913).encode('utf8'),aGifcrMSUgRVwtnLYqoQECNpWFeKyI+' \n\n'+__language__(30914))
  if aGifcrMSUgRVwtnLYqoQECNpWFeKAP==aGifcrMSUgRVwtnLYqoQECNpWFeKTm:return
  aGifcrMSUgRVwtnLYqoQECNpWFeKyk=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.GetBookmarkInfo(aGifcrMSUgRVwtnLYqoQECNpWFeKAv,aGifcrMSUgRVwtnLYqoQECNpWFeKyJ,aGifcrMSUgRVwtnLYqoQECNpWFeKys)
  aGifcrMSUgRVwtnLYqoQECNpWFeKyb=json.dumps(aGifcrMSUgRVwtnLYqoQECNpWFeKyk)
  aGifcrMSUgRVwtnLYqoQECNpWFeKyb=urllib.parse.quote(aGifcrMSUgRVwtnLYqoQECNpWFeKyb)
  aGifcrMSUgRVwtnLYqoQECNpWFeKDb ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(aGifcrMSUgRVwtnLYqoQECNpWFeKyb)
  xbmc.executebuiltin(aGifcrMSUgRVwtnLYqoQECNpWFeKDb)
 def dp_Episode_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.SaveCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKAv =args.get('videoid')
  aGifcrMSUgRVwtnLYqoQECNpWFeKyJ =args.get('vidtype')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDx=aGifcrMSUgRVwtnLYqoQECNpWFeKTy(args.get('page'))
  aGifcrMSUgRVwtnLYqoQECNpWFeKDP,aGifcrMSUgRVwtnLYqoQECNpWFeKjX=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_Episode_List(aGifcrMSUgRVwtnLYqoQECNpWFeKAv,aGifcrMSUgRVwtnLYqoQECNpWFeKyJ,aGifcrMSUgRVwtnLYqoQECNpWFeKDx,orderby=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winEpisodeOrderby())
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDJ in aGifcrMSUgRVwtnLYqoQECNpWFeKDP:
   aGifcrMSUgRVwtnLYqoQECNpWFeKDu='%s회, %s(%s)'%(aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('episodenumber'),aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('releasedate'),aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('releaseweekday'))
   aGifcrMSUgRVwtnLYqoQECNpWFeKyu ='[%s]\n\n%s'%(aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('episodetitle'),aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('synopsis'))
   aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'mediatype':'episode','title':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('programtitle'),'year':aGifcrMSUgRVwtnLYqoQECNpWFeKTy(aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('releasedate')[:4]),'aired':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('releasedate'),'mpaa':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('age'),'episode':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('episodenumber'),'duration':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('playtime'),'plot':aGifcrMSUgRVwtnLYqoQECNpWFeKyu,'cast':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('episodeactors')}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'VOD','programid':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('programid'),'contentid':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('contentid'),'thumbnail':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('thumbnail'),'title':aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('programtitle'),'subtitle':aGifcrMSUgRVwtnLYqoQECNpWFeKDu}
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('programtitle'),sublabel=aGifcrMSUgRVwtnLYqoQECNpWFeKDu,img=aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('thumbnail'),infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTm,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKDx==1:
   aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'plot':'정렬순서를 변경합니다.'}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['mode'] ='ORDER_BY' 
   if aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winEpisodeOrderby()=='desc':
    aGifcrMSUgRVwtnLYqoQECNpWFeKjB='정렬순서변경 : 최신화부터 -> 1회부터'
    aGifcrMSUgRVwtnLYqoQECNpWFeKjz['orderby']='asc'
   else:
    aGifcrMSUgRVwtnLYqoQECNpWFeKjB='정렬순서변경 : 1회부터 -> 최신화부터'
    aGifcrMSUgRVwtnLYqoQECNpWFeKjz['orderby']='desc'
   aGifcrMSUgRVwtnLYqoQECNpWFeKjh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel='',img=aGifcrMSUgRVwtnLYqoQECNpWFeKjh,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTm,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz,isLink=aGifcrMSUgRVwtnLYqoQECNpWFeKTA)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjX:
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['mode'] ='EPISODE_LIST' 
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['videoid']=aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('programid')
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['vidtype']='programid'
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz['page'] =aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjB='[B]%s >>[/B]'%'다음 페이지'
   aGifcrMSUgRVwtnLYqoQECNpWFeKDu=aGifcrMSUgRVwtnLYqoQECNpWFeKTh(aGifcrMSUgRVwtnLYqoQECNpWFeKDx+1)
   aGifcrMSUgRVwtnLYqoQECNpWFeKjh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKjB,sublabel=aGifcrMSUgRVwtnLYqoQECNpWFeKDu,img=aGifcrMSUgRVwtnLYqoQECNpWFeKjh,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKTD,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTA,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  xbmcplugin.setContent(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,'episodes')
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(aGifcrMSUgRVwtnLYqoQECNpWFeKDP)>0:xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def dp_LiveChannel_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH,args):
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.SaveCredential(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.get_winCredential())
  aGifcrMSUgRVwtnLYqoQECNpWFeKyX =args.get('genre')
  aGifcrMSUgRVwtnLYqoQECNpWFeKym=args.get('baseapi')
  aGifcrMSUgRVwtnLYqoQECNpWFeKDP=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.WavveObj.Get_LiveChannel_List(aGifcrMSUgRVwtnLYqoQECNpWFeKyX,aGifcrMSUgRVwtnLYqoQECNpWFeKym)
  for aGifcrMSUgRVwtnLYqoQECNpWFeKDJ in aGifcrMSUgRVwtnLYqoQECNpWFeKDP:
   aGifcrMSUgRVwtnLYqoQECNpWFeKyh =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('channelid')
   aGifcrMSUgRVwtnLYqoQECNpWFeKyz =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('studio')
   aGifcrMSUgRVwtnLYqoQECNpWFeKyx=aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('tvshowtitle')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDI =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('thumbnail')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDO =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('age')
   aGifcrMSUgRVwtnLYqoQECNpWFeKTv =aGifcrMSUgRVwtnLYqoQECNpWFeKDJ.get('epg')
   aGifcrMSUgRVwtnLYqoQECNpWFeKDz={'mediatype':'episode','mpaa':aGifcrMSUgRVwtnLYqoQECNpWFeKDO,'title':'%s < %s >'%(aGifcrMSUgRVwtnLYqoQECNpWFeKyz,aGifcrMSUgRVwtnLYqoQECNpWFeKyx),'tvshowtitle':aGifcrMSUgRVwtnLYqoQECNpWFeKyx,'studio':aGifcrMSUgRVwtnLYqoQECNpWFeKyz,'plot':'%s\n\n%s'%(aGifcrMSUgRVwtnLYqoQECNpWFeKyz,aGifcrMSUgRVwtnLYqoQECNpWFeKTv)}
   aGifcrMSUgRVwtnLYqoQECNpWFeKjz={'mode':'LIVE','contentid':aGifcrMSUgRVwtnLYqoQECNpWFeKyh}
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.add_dir(aGifcrMSUgRVwtnLYqoQECNpWFeKyz,sublabel=aGifcrMSUgRVwtnLYqoQECNpWFeKyx,img=aGifcrMSUgRVwtnLYqoQECNpWFeKDI,infoLabels=aGifcrMSUgRVwtnLYqoQECNpWFeKDz,isFolder=aGifcrMSUgRVwtnLYqoQECNpWFeKTm,params=aGifcrMSUgRVwtnLYqoQECNpWFeKjz)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKTl(aGifcrMSUgRVwtnLYqoQECNpWFeKDP)>0:xbmcplugin.endOfDirectory(aGifcrMSUgRVwtnLYqoQECNpWFeKvH._addon_handle,cacheToDisc=aGifcrMSUgRVwtnLYqoQECNpWFeKTm)
 def wavve_main(aGifcrMSUgRVwtnLYqoQECNpWFeKvH):
  aGifcrMSUgRVwtnLYqoQECNpWFeKjk=aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params.get('mode',aGifcrMSUgRVwtnLYqoQECNpWFeKTD)
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='LOGOUT':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.logout()
   return
  aGifcrMSUgRVwtnLYqoQECNpWFeKvH.login_main()
  if aGifcrMSUgRVwtnLYqoQECNpWFeKjk is aGifcrMSUgRVwtnLYqoQECNpWFeKTD:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Main_List()
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk in['LIVE','VOD','MOVIE']:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.play_VIDEO(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='LIVE_CATAGORY':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_LiveCatagory_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='MAIN_CATAGORY':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_MainCatagory_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='SUPERSECTION_LIST':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_SuperSection_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='BANDLIVESECTION_LIST':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_BandLiveSection_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='BAND2SECTION_LIST':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Band2Section_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='PROGRAM_LIST':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Program_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='EPISODE_LIST':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Episode_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='MOVIE_LIST':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Movie_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='LIVE_LIST':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_LiveChannel_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='ORDER_BY':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_setEpOrderby(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='SEARCH_GROUP':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Search_Group(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk in['SEARCH_LIST','LOCAL_SEARCH']:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Search_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='WATCH_GROUP':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Watch_Group(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='WATCH_LIST':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Watch_List(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='SET_BOOKMARK':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Set_Bookmark(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Listfile_Delete(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk in['TOTAL_SEARCH','TOTAL_HISTORY']:
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Global_Search(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='SEARCH_HISTORY':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Search_History(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  elif aGifcrMSUgRVwtnLYqoQECNpWFeKjk=='MENU_BOOKMARK':
   aGifcrMSUgRVwtnLYqoQECNpWFeKvH.dp_Bookmark_Menu(aGifcrMSUgRVwtnLYqoQECNpWFeKvH.main_params)
  else:
   aGifcrMSUgRVwtnLYqoQECNpWFeKTD
# Created by pyminifier (https://github.com/liftoff/pyminifier)
