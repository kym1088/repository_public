__author__="NightRain"
WCHfdmKqzGAYFxglIohSniBcPaTEkt=object
WCHfdmKqzGAYFxglIohSniBcPaTEkr=None
WCHfdmKqzGAYFxglIohSniBcPaTEkV=False
WCHfdmKqzGAYFxglIohSniBcPaTEkJ=True
WCHfdmKqzGAYFxglIohSniBcPaTEku=range
WCHfdmKqzGAYFxglIohSniBcPaTEkX=str
WCHfdmKqzGAYFxglIohSniBcPaTEks=Exception
WCHfdmKqzGAYFxglIohSniBcPaTEkL=print
WCHfdmKqzGAYFxglIohSniBcPaTEkp=dict
WCHfdmKqzGAYFxglIohSniBcPaTEkj=int
WCHfdmKqzGAYFxglIohSniBcPaTEkR=len
import urllib
import re
import json
import sys
import requests
import datetime
class WCHfdmKqzGAYFxglIohSniBcPaTEwe(WCHfdmKqzGAYFxglIohSniBcPaTEkt):
 def __init__(WCHfdmKqzGAYFxglIohSniBcPaTEwt):
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN='https://apis.wavve.com'
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.CREDENTIAL='none'
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.DEVICE ='pc'
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.DRM ='wm'
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.PARTNER ='pooq'
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.POOQZONE ='none'
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.REGION ='kor'
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.TARGETAGE ='all'
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.HTTPTAG ='https://'
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.LIST_LIMIT=30 
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.EP_LIMIT =30 
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.MV_LIMIT =24 
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.SEARCH_LIMIT=20 
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.guid ='none' 
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.guidtimestamp='none' 
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.DEFAULT_HEADER={'user-agent':WCHfdmKqzGAYFxglIohSniBcPaTEwt.USER_AGENT}
 def callRequestCookies(WCHfdmKqzGAYFxglIohSniBcPaTEwt,jobtype,WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEkr,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr,redirects=WCHfdmKqzGAYFxglIohSniBcPaTEkV):
  WCHfdmKqzGAYFxglIohSniBcPaTEwr=WCHfdmKqzGAYFxglIohSniBcPaTEwt.DEFAULT_HEADER
  if headers:WCHfdmKqzGAYFxglIohSniBcPaTEwr.update(headers)
  if jobtype=='Get':
   WCHfdmKqzGAYFxglIohSniBcPaTEwk=requests.get(WCHfdmKqzGAYFxglIohSniBcPaTEwQ,params=params,headers=WCHfdmKqzGAYFxglIohSniBcPaTEwr,cookies=cookies,allow_redirects=redirects)
  else:
   WCHfdmKqzGAYFxglIohSniBcPaTEwk=requests.post(WCHfdmKqzGAYFxglIohSniBcPaTEwQ,data=payload,params=params,headers=WCHfdmKqzGAYFxglIohSniBcPaTEwr,cookies=cookies,allow_redirects=redirects)
  return WCHfdmKqzGAYFxglIohSniBcPaTEwk
 def SaveCredential(WCHfdmKqzGAYFxglIohSniBcPaTEwt,WCHfdmKqzGAYFxglIohSniBcPaTEwV):
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.CREDENTIAL=WCHfdmKqzGAYFxglIohSniBcPaTEwV
 def LoadCredential(WCHfdmKqzGAYFxglIohSniBcPaTEwt):
  return WCHfdmKqzGAYFxglIohSniBcPaTEwt.CREDENTIAL
 def GetDefaultParams(WCHfdmKqzGAYFxglIohSniBcPaTEwt,login=WCHfdmKqzGAYFxglIohSniBcPaTEkJ):
  WCHfdmKqzGAYFxglIohSniBcPaTEwJ={'apikey':WCHfdmKqzGAYFxglIohSniBcPaTEwt.APIKEY,'credential':WCHfdmKqzGAYFxglIohSniBcPaTEwt.CREDENTIAL if login else 'none','device':WCHfdmKqzGAYFxglIohSniBcPaTEwt.DEVICE,'drm':WCHfdmKqzGAYFxglIohSniBcPaTEwt.DRM,'partner':WCHfdmKqzGAYFxglIohSniBcPaTEwt.PARTNER,'pooqzone':WCHfdmKqzGAYFxglIohSniBcPaTEwt.POOQZONE,'region':WCHfdmKqzGAYFxglIohSniBcPaTEwt.REGION,'targetage':WCHfdmKqzGAYFxglIohSniBcPaTEwt.TARGETAGE}
  return WCHfdmKqzGAYFxglIohSniBcPaTEwJ
 def GetGUID(WCHfdmKqzGAYFxglIohSniBcPaTEwt,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   WCHfdmKqzGAYFxglIohSniBcPaTEwu=WCHfdmKqzGAYFxglIohSniBcPaTEwt.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   WCHfdmKqzGAYFxglIohSniBcPaTEwX=GenerateRandomString(5)
   WCHfdmKqzGAYFxglIohSniBcPaTEws=WCHfdmKqzGAYFxglIohSniBcPaTEwX+media+WCHfdmKqzGAYFxglIohSniBcPaTEwu
   return WCHfdmKqzGAYFxglIohSniBcPaTEws
  def GenerateRandomString(num):
   from random import randint
   WCHfdmKqzGAYFxglIohSniBcPaTEwL=""
   for i in WCHfdmKqzGAYFxglIohSniBcPaTEku(0,num):
    s=WCHfdmKqzGAYFxglIohSniBcPaTEkX(randint(1,5))
    WCHfdmKqzGAYFxglIohSniBcPaTEwL+=s
   return WCHfdmKqzGAYFxglIohSniBcPaTEwL
  WCHfdmKqzGAYFxglIohSniBcPaTEws=GenerateID(guid_str)
  WCHfdmKqzGAYFxglIohSniBcPaTEwp=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetHash(WCHfdmKqzGAYFxglIohSniBcPaTEws)
  if guidType==2:
   WCHfdmKqzGAYFxglIohSniBcPaTEwp='%s-%s-%s-%s-%s'%(WCHfdmKqzGAYFxglIohSniBcPaTEwp[:8],WCHfdmKqzGAYFxglIohSniBcPaTEwp[8:12],WCHfdmKqzGAYFxglIohSniBcPaTEwp[12:16],WCHfdmKqzGAYFxglIohSniBcPaTEwp[16:20],WCHfdmKqzGAYFxglIohSniBcPaTEwp[20:])
  return WCHfdmKqzGAYFxglIohSniBcPaTEwp
 def GetHash(WCHfdmKqzGAYFxglIohSniBcPaTEwt,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return WCHfdmKqzGAYFxglIohSniBcPaTEkX(m.hexdigest())
 def CheckQuality(WCHfdmKqzGAYFxglIohSniBcPaTEwt,sel_qt,qt_list):
  WCHfdmKqzGAYFxglIohSniBcPaTEwj=0
  for WCHfdmKqzGAYFxglIohSniBcPaTEwR in qt_list:
   if sel_qt>=WCHfdmKqzGAYFxglIohSniBcPaTEwR:return WCHfdmKqzGAYFxglIohSniBcPaTEwR
   WCHfdmKqzGAYFxglIohSniBcPaTEwj=WCHfdmKqzGAYFxglIohSniBcPaTEwR
  return WCHfdmKqzGAYFxglIohSniBcPaTEwj
 def Get_Now_Datetime(WCHfdmKqzGAYFxglIohSniBcPaTEwt):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(WCHfdmKqzGAYFxglIohSniBcPaTEwt,in_text):
  WCHfdmKqzGAYFxglIohSniBcPaTEwM=in_text.replace('&lt;','<').replace('&gt;','>')
  WCHfdmKqzGAYFxglIohSniBcPaTEwM=WCHfdmKqzGAYFxglIohSniBcPaTEwM.replace('$O$','')
  WCHfdmKqzGAYFxglIohSniBcPaTEwM=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',WCHfdmKqzGAYFxglIohSniBcPaTEwM)
  WCHfdmKqzGAYFxglIohSniBcPaTEwM=WCHfdmKqzGAYFxglIohSniBcPaTEwM.lstrip('#')
  return WCHfdmKqzGAYFxglIohSniBcPaTEwM
 def GetCredential(WCHfdmKqzGAYFxglIohSniBcPaTEwt,user_id,user_pw,user_pf):
  WCHfdmKqzGAYFxglIohSniBcPaTEwU=WCHfdmKqzGAYFxglIohSniBcPaTEkV
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+ '/login'
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams()
   WCHfdmKqzGAYFxglIohSniBcPaTEwN={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Post',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEwN,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   WCHfdmKqzGAYFxglIohSniBcPaTEwV=WCHfdmKqzGAYFxglIohSniBcPaTEwb['credential']
   if user_pf!=0:
    WCHfdmKqzGAYFxglIohSniBcPaTEwN={'id':WCHfdmKqzGAYFxglIohSniBcPaTEwV,'password':'','profile':WCHfdmKqzGAYFxglIohSniBcPaTEkX(user_pf),'pushid':'','type':'credential'}
    WCHfdmKqzGAYFxglIohSniBcPaTEwJ['credential']=WCHfdmKqzGAYFxglIohSniBcPaTEwV 
    WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Post',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEwN,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
    WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
    WCHfdmKqzGAYFxglIohSniBcPaTEwV=WCHfdmKqzGAYFxglIohSniBcPaTEwb['credential']
   if WCHfdmKqzGAYFxglIohSniBcPaTEwV:WCHfdmKqzGAYFxglIohSniBcPaTEwU=WCHfdmKqzGAYFxglIohSniBcPaTEkJ
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   WCHfdmKqzGAYFxglIohSniBcPaTEwV='none' 
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.SaveCredential(WCHfdmKqzGAYFxglIohSniBcPaTEwV)
  return WCHfdmKqzGAYFxglIohSniBcPaTEwU
 def GetIssue(WCHfdmKqzGAYFxglIohSniBcPaTEwt):
  WCHfdmKqzGAYFxglIohSniBcPaTEwv=WCHfdmKqzGAYFxglIohSniBcPaTEkV
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/guid/issue'
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams()
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   WCHfdmKqzGAYFxglIohSniBcPaTEwO=WCHfdmKqzGAYFxglIohSniBcPaTEwb['guid']
   WCHfdmKqzGAYFxglIohSniBcPaTEew=WCHfdmKqzGAYFxglIohSniBcPaTEwb['guidtimestamp']
   if WCHfdmKqzGAYFxglIohSniBcPaTEwO:WCHfdmKqzGAYFxglIohSniBcPaTEwv=WCHfdmKqzGAYFxglIohSniBcPaTEkJ
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   WCHfdmKqzGAYFxglIohSniBcPaTEwO='none'
   WCHfdmKqzGAYFxglIohSniBcPaTEew='none' 
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.guid=WCHfdmKqzGAYFxglIohSniBcPaTEwO
  WCHfdmKqzGAYFxglIohSniBcPaTEwt.guidtimestamp=WCHfdmKqzGAYFxglIohSniBcPaTEew
  return WCHfdmKqzGAYFxglIohSniBcPaTEwv
 def Baseapi_Parse(WCHfdmKqzGAYFxglIohSniBcPaTEwt,WCHfdmKqzGAYFxglIohSniBcPaTEeV):
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEet =urllib.parse.urlsplit(WCHfdmKqzGAYFxglIohSniBcPaTEeV)
   if WCHfdmKqzGAYFxglIohSniBcPaTEet.netloc=='':
    WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.HTTPTAG+WCHfdmKqzGAYFxglIohSniBcPaTEet.netloc+WCHfdmKqzGAYFxglIohSniBcPaTEet.path
   else:
    WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEet.scheme+'://'+WCHfdmKqzGAYFxglIohSniBcPaTEet.netloc+WCHfdmKqzGAYFxglIohSniBcPaTEet.path
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ=WCHfdmKqzGAYFxglIohSniBcPaTEkp(urllib.parse.parse_qsl(WCHfdmKqzGAYFxglIohSniBcPaTEet.query))
  except:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return '',{}
  return WCHfdmKqzGAYFxglIohSniBcPaTEwQ,WCHfdmKqzGAYFxglIohSniBcPaTEwJ
 def GetSupermultiUrl(WCHfdmKqzGAYFxglIohSniBcPaTEwt,sCode,sIndex='0'):
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/cf/supermultisections/'+sCode
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV)
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   WCHfdmKqzGAYFxglIohSniBcPaTEer=WCHfdmKqzGAYFxglIohSniBcPaTEwb['multisectionlist'][WCHfdmKqzGAYFxglIohSniBcPaTEkj(sIndex)]['eventlist'][1]['url']
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return ''
  return WCHfdmKqzGAYFxglIohSniBcPaTEer
 def Get_LiveCatagory_List(WCHfdmKqzGAYFxglIohSniBcPaTEwt,sCode,sIndex='0'):
  WCHfdmKqzGAYFxglIohSniBcPaTEek=[]
  WCHfdmKqzGAYFxglIohSniBcPaTEeV =WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetSupermultiUrl(sCode,sIndex)
  (WCHfdmKqzGAYFxglIohSniBcPaTEwQ,WCHfdmKqzGAYFxglIohSniBcPaTEwJ)=WCHfdmKqzGAYFxglIohSniBcPaTEwt.Baseapi_Parse(WCHfdmKqzGAYFxglIohSniBcPaTEeV)
  if WCHfdmKqzGAYFxglIohSniBcPaTEwQ=='':return WCHfdmKqzGAYFxglIohSniBcPaTEek,''
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV))
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('filter_item_list' in WCHfdmKqzGAYFxglIohSniBcPaTEwb['filter']['filterlist'][0]):return[],''
   WCHfdmKqzGAYFxglIohSniBcPaTEeu=WCHfdmKqzGAYFxglIohSniBcPaTEwb['filter']['filterlist'][0]['filter_item_list']
   for WCHfdmKqzGAYFxglIohSniBcPaTEeX in WCHfdmKqzGAYFxglIohSniBcPaTEeu:
    WCHfdmKqzGAYFxglIohSniBcPaTEes={'title':WCHfdmKqzGAYFxglIohSniBcPaTEeX['title'],'genre':WCHfdmKqzGAYFxglIohSniBcPaTEeX['api_parameters'][WCHfdmKqzGAYFxglIohSniBcPaTEeX['api_parameters'].index('=')+1:]}
    WCHfdmKqzGAYFxglIohSniBcPaTEek.append(WCHfdmKqzGAYFxglIohSniBcPaTEes)
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[],''
  return WCHfdmKqzGAYFxglIohSniBcPaTEek,WCHfdmKqzGAYFxglIohSniBcPaTEeV
 def Get_MainCatagory_List(WCHfdmKqzGAYFxglIohSniBcPaTEwt,sCode,sIndex='0'):
  WCHfdmKqzGAYFxglIohSniBcPaTEek=[]
  WCHfdmKqzGAYFxglIohSniBcPaTEeV =WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetSupermultiUrl(sCode,sIndex)
  (WCHfdmKqzGAYFxglIohSniBcPaTEwQ,WCHfdmKqzGAYFxglIohSniBcPaTEwJ)=WCHfdmKqzGAYFxglIohSniBcPaTEwt.Baseapi_Parse(WCHfdmKqzGAYFxglIohSniBcPaTEeV)
  if WCHfdmKqzGAYFxglIohSniBcPaTEwQ=='':return WCHfdmKqzGAYFxglIohSniBcPaTEek
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV))
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('celllist' in WCHfdmKqzGAYFxglIohSniBcPaTEwb['band']):return[]
   WCHfdmKqzGAYFxglIohSniBcPaTEeu=WCHfdmKqzGAYFxglIohSniBcPaTEwb['band']['celllist']
   for WCHfdmKqzGAYFxglIohSniBcPaTEeX in WCHfdmKqzGAYFxglIohSniBcPaTEeu:
    WCHfdmKqzGAYFxglIohSniBcPaTEeL =WCHfdmKqzGAYFxglIohSniBcPaTEeX['event_list'][1]['url']
    (WCHfdmKqzGAYFxglIohSniBcPaTEep,WCHfdmKqzGAYFxglIohSniBcPaTEej)=WCHfdmKqzGAYFxglIohSniBcPaTEwt.Baseapi_Parse(WCHfdmKqzGAYFxglIohSniBcPaTEeL)
    WCHfdmKqzGAYFxglIohSniBcPaTEes={'title':WCHfdmKqzGAYFxglIohSniBcPaTEeX['title_list'][0]['text'],'suburl':WCHfdmKqzGAYFxglIohSniBcPaTEep,'subapi':WCHfdmKqzGAYFxglIohSniBcPaTEej.get('api'),'subtype':'catagory' if WCHfdmKqzGAYFxglIohSniBcPaTEej else 'supersection'}
    WCHfdmKqzGAYFxglIohSniBcPaTEek.append(WCHfdmKqzGAYFxglIohSniBcPaTEes)
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[]
  return WCHfdmKqzGAYFxglIohSniBcPaTEek
 def Get_SuperMultiSection_List(WCHfdmKqzGAYFxglIohSniBcPaTEwt,subapi_text):
  WCHfdmKqzGAYFxglIohSniBcPaTEek=[]
  WCHfdmKqzGAYFxglIohSniBcPaTEwJ={}
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEet =urllib.parse.urlsplit(subapi_text)
   if WCHfdmKqzGAYFxglIohSniBcPaTEet.path.find('apis.wavve.com')>=0: 
    WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.HTTPTAG+WCHfdmKqzGAYFxglIohSniBcPaTEet.path 
    WCHfdmKqzGAYFxglIohSniBcPaTEwJ=WCHfdmKqzGAYFxglIohSniBcPaTEkp(urllib.parse.parse_qsl(WCHfdmKqzGAYFxglIohSniBcPaTEet.query))
   else:
    WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/cf'+WCHfdmKqzGAYFxglIohSniBcPaTEet.path 
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwQ.replace('supermultisection/','supermultisections/')
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[]
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV))
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEkr,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('multisectionlist' in WCHfdmKqzGAYFxglIohSniBcPaTEwb):return[]
   WCHfdmKqzGAYFxglIohSniBcPaTEeu=WCHfdmKqzGAYFxglIohSniBcPaTEwb['multisectionlist']
   for WCHfdmKqzGAYFxglIohSniBcPaTEeX in WCHfdmKqzGAYFxglIohSniBcPaTEeu:
    WCHfdmKqzGAYFxglIohSniBcPaTEeR=WCHfdmKqzGAYFxglIohSniBcPaTEeX['title']
    if WCHfdmKqzGAYFxglIohSniBcPaTEkR(WCHfdmKqzGAYFxglIohSniBcPaTEeR)==0:continue
    if WCHfdmKqzGAYFxglIohSniBcPaTEeR=='minor':continue
    if re.search(u'베너',WCHfdmKqzGAYFxglIohSniBcPaTEeR):continue
    if re.search(u'배너',WCHfdmKqzGAYFxglIohSniBcPaTEeR):continue 
    if WCHfdmKqzGAYFxglIohSniBcPaTEkR(WCHfdmKqzGAYFxglIohSniBcPaTEeX['eventlist'])>=3:
     WCHfdmKqzGAYFxglIohSniBcPaTEej =WCHfdmKqzGAYFxglIohSniBcPaTEeX['eventlist'][2]['url']
    else:
     WCHfdmKqzGAYFxglIohSniBcPaTEej =WCHfdmKqzGAYFxglIohSniBcPaTEeX['eventlist'][1]['url']
    WCHfdmKqzGAYFxglIohSniBcPaTEeD=WCHfdmKqzGAYFxglIohSniBcPaTEeX['cell_type']
    if WCHfdmKqzGAYFxglIohSniBcPaTEeD=='band_2':
     if WCHfdmKqzGAYFxglIohSniBcPaTEej.find('channellist=')>=0:
      WCHfdmKqzGAYFxglIohSniBcPaTEeD='band_live'
    WCHfdmKqzGAYFxglIohSniBcPaTEes={'title':WCHfdmKqzGAYFxglIohSniBcPaTEwt.Get_ChangeText(WCHfdmKqzGAYFxglIohSniBcPaTEeR),'subapi':WCHfdmKqzGAYFxglIohSniBcPaTEej,'cell_type':WCHfdmKqzGAYFxglIohSniBcPaTEeD}
    WCHfdmKqzGAYFxglIohSniBcPaTEek.append(WCHfdmKqzGAYFxglIohSniBcPaTEes)
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[]
  return WCHfdmKqzGAYFxglIohSniBcPaTEek
 def Get_BandLiveSection_List(WCHfdmKqzGAYFxglIohSniBcPaTEwt,WCHfdmKqzGAYFxglIohSniBcPaTEeV,page_int=1):
  WCHfdmKqzGAYFxglIohSniBcPaTEeM=[]
  WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEeO=1
  WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEkV
  try:
   (WCHfdmKqzGAYFxglIohSniBcPaTEwQ,WCHfdmKqzGAYFxglIohSniBcPaTEwJ)=WCHfdmKqzGAYFxglIohSniBcPaTEwt.Baseapi_Parse(WCHfdmKqzGAYFxglIohSniBcPaTEeV)
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[],WCHfdmKqzGAYFxglIohSniBcPaTEkV
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['limit']=WCHfdmKqzGAYFxglIohSniBcPaTEwt.LIST_LIMIT
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['offset']=WCHfdmKqzGAYFxglIohSniBcPaTEkX((page_int-1)*WCHfdmKqzGAYFxglIohSniBcPaTEwt.LIST_LIMIT)
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV))
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('celllist' in WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']):return[],WCHfdmKqzGAYFxglIohSniBcPaTEkV
   WCHfdmKqzGAYFxglIohSniBcPaTEeu=WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['celllist']
   for WCHfdmKqzGAYFxglIohSniBcPaTEeX in WCHfdmKqzGAYFxglIohSniBcPaTEeu:
    WCHfdmKqzGAYFxglIohSniBcPaTEeN =WCHfdmKqzGAYFxglIohSniBcPaTEeX['event_list'][1]['url']
    WCHfdmKqzGAYFxglIohSniBcPaTEey=urllib.parse.urlsplit(WCHfdmKqzGAYFxglIohSniBcPaTEeN).query
    WCHfdmKqzGAYFxglIohSniBcPaTEey=WCHfdmKqzGAYFxglIohSniBcPaTEkp(urllib.parse.parse_qsl(WCHfdmKqzGAYFxglIohSniBcPaTEey))
    WCHfdmKqzGAYFxglIohSniBcPaTEeb='channelid'
    WCHfdmKqzGAYFxglIohSniBcPaTEev=WCHfdmKqzGAYFxglIohSniBcPaTEey[WCHfdmKqzGAYFxglIohSniBcPaTEeb]
    WCHfdmKqzGAYFxglIohSniBcPaTEes={'studio':WCHfdmKqzGAYFxglIohSniBcPaTEeX['title_list'][0]['text'],'tvshowtitle':WCHfdmKqzGAYFxglIohSniBcPaTEwt.Get_ChangeText(WCHfdmKqzGAYFxglIohSniBcPaTEeX['title_list'][1]['text']),'channelid':WCHfdmKqzGAYFxglIohSniBcPaTEev,'age':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('age'),'thumbnail':'https://%s'%WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('thumbnail')}
    WCHfdmKqzGAYFxglIohSniBcPaTEeM.append(WCHfdmKqzGAYFxglIohSniBcPaTEes)
   WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['pagecount'])
   if WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['count']:WCHfdmKqzGAYFxglIohSniBcPaTEeO =WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['count'])
   else:WCHfdmKqzGAYFxglIohSniBcPaTEeO=WCHfdmKqzGAYFxglIohSniBcPaTEwt.LIST_LIMIT*page_int
   WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEeU>WCHfdmKqzGAYFxglIohSniBcPaTEeO
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[],WCHfdmKqzGAYFxglIohSniBcPaTEkV
  return WCHfdmKqzGAYFxglIohSniBcPaTEeM,WCHfdmKqzGAYFxglIohSniBcPaTEeQ
 def Get_Band2Section_List(WCHfdmKqzGAYFxglIohSniBcPaTEwt,WCHfdmKqzGAYFxglIohSniBcPaTEeV,page_int=1):
  WCHfdmKqzGAYFxglIohSniBcPaTEtw=[]
  WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEeO=1
  WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEkV
  try:
   (WCHfdmKqzGAYFxglIohSniBcPaTEwQ,WCHfdmKqzGAYFxglIohSniBcPaTEwJ)=WCHfdmKqzGAYFxglIohSniBcPaTEwt.Baseapi_Parse(WCHfdmKqzGAYFxglIohSniBcPaTEeV)
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[],WCHfdmKqzGAYFxglIohSniBcPaTEkV
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['came'] ='BandView'
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['limit']=WCHfdmKqzGAYFxglIohSniBcPaTEwt.LIST_LIMIT
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['offset']=WCHfdmKqzGAYFxglIohSniBcPaTEkX((page_int-1)*WCHfdmKqzGAYFxglIohSniBcPaTEwt.LIST_LIMIT)
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV))
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('celllist' in WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']):return[],WCHfdmKqzGAYFxglIohSniBcPaTEkV
   WCHfdmKqzGAYFxglIohSniBcPaTEeu=WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['celllist']
   for WCHfdmKqzGAYFxglIohSniBcPaTEeX in WCHfdmKqzGAYFxglIohSniBcPaTEeu:
    WCHfdmKqzGAYFxglIohSniBcPaTEeN =WCHfdmKqzGAYFxglIohSniBcPaTEeX['event_list'][1]['url']
    WCHfdmKqzGAYFxglIohSniBcPaTEey=urllib.parse.urlsplit(WCHfdmKqzGAYFxglIohSniBcPaTEeN).query
    WCHfdmKqzGAYFxglIohSniBcPaTEey=WCHfdmKqzGAYFxglIohSniBcPaTEkp(urllib.parse.parse_qsl(WCHfdmKqzGAYFxglIohSniBcPaTEey))
    WCHfdmKqzGAYFxglIohSniBcPaTEeb='contentid'
    WCHfdmKqzGAYFxglIohSniBcPaTEev=WCHfdmKqzGAYFxglIohSniBcPaTEey[WCHfdmKqzGAYFxglIohSniBcPaTEeb]
    WCHfdmKqzGAYFxglIohSniBcPaTEes={'programtitle':WCHfdmKqzGAYFxglIohSniBcPaTEeX['title_list'][0]['text'],'episodetitle':WCHfdmKqzGAYFxglIohSniBcPaTEwt.Get_ChangeText(WCHfdmKqzGAYFxglIohSniBcPaTEeX['title_list'][1]['text']),'age':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('age'),'thumbnail':WCHfdmKqzGAYFxglIohSniBcPaTEwt.HTTPTAG+WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('thumbnail'),'vidtype':WCHfdmKqzGAYFxglIohSniBcPaTEeb,'videoid':WCHfdmKqzGAYFxglIohSniBcPaTEev}
    WCHfdmKqzGAYFxglIohSniBcPaTEtw.append(WCHfdmKqzGAYFxglIohSniBcPaTEes)
   WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['pagecount'])
   if WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['count']:WCHfdmKqzGAYFxglIohSniBcPaTEeO =WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['count'])
   else:WCHfdmKqzGAYFxglIohSniBcPaTEeO=WCHfdmKqzGAYFxglIohSniBcPaTEwt.LIST_LIMIT*page_int
   WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEeU>WCHfdmKqzGAYFxglIohSniBcPaTEeO
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[],WCHfdmKqzGAYFxglIohSniBcPaTEkV
  return WCHfdmKqzGAYFxglIohSniBcPaTEtw,WCHfdmKqzGAYFxglIohSniBcPaTEeQ
 def Get_Program_List(WCHfdmKqzGAYFxglIohSniBcPaTEwt,WCHfdmKqzGAYFxglIohSniBcPaTEeV,page_int=1,orderby='-'):
  WCHfdmKqzGAYFxglIohSniBcPaTEte=[]
  WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEeO=1
  WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEkV
  (WCHfdmKqzGAYFxglIohSniBcPaTEwQ,WCHfdmKqzGAYFxglIohSniBcPaTEwJ)=WCHfdmKqzGAYFxglIohSniBcPaTEwt.Baseapi_Parse(WCHfdmKqzGAYFxglIohSniBcPaTEeV)
  if WCHfdmKqzGAYFxglIohSniBcPaTEwQ=='':return WCHfdmKqzGAYFxglIohSniBcPaTEte,WCHfdmKqzGAYFxglIohSniBcPaTEeQ
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['limit'] =WCHfdmKqzGAYFxglIohSniBcPaTEwt.LIST_LIMIT
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['offset']=WCHfdmKqzGAYFxglIohSniBcPaTEkX((page_int-1)*WCHfdmKqzGAYFxglIohSniBcPaTEwt.LIST_LIMIT)
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['page'] =WCHfdmKqzGAYFxglIohSniBcPaTEkX(page_int)
   if WCHfdmKqzGAYFxglIohSniBcPaTEwJ.get('orderby')!='' and WCHfdmKqzGAYFxglIohSniBcPaTEwJ.get('orderby')!='regdatefirst' and orderby!='-':
    WCHfdmKqzGAYFxglIohSniBcPaTEwJ['orderby']=orderby 
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV))
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if WCHfdmKqzGAYFxglIohSniBcPaTEeV.find('instantplay')>=0:
    if not('celllist' in WCHfdmKqzGAYFxglIohSniBcPaTEwb['band']):return WCHfdmKqzGAYFxglIohSniBcPaTEte,WCHfdmKqzGAYFxglIohSniBcPaTEeQ
    WCHfdmKqzGAYFxglIohSniBcPaTEeu=WCHfdmKqzGAYFxglIohSniBcPaTEwb['band']['celllist']
   else:
    if not('celllist' in WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']):return WCHfdmKqzGAYFxglIohSniBcPaTEte,WCHfdmKqzGAYFxglIohSniBcPaTEeQ
    WCHfdmKqzGAYFxglIohSniBcPaTEeu=WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['celllist']
   for WCHfdmKqzGAYFxglIohSniBcPaTEeX in WCHfdmKqzGAYFxglIohSniBcPaTEeu:
    for WCHfdmKqzGAYFxglIohSniBcPaTEtr in WCHfdmKqzGAYFxglIohSniBcPaTEeX['event_list']:
     if WCHfdmKqzGAYFxglIohSniBcPaTEtr.get('type')=='on-navigation':
      WCHfdmKqzGAYFxglIohSniBcPaTEeN =WCHfdmKqzGAYFxglIohSniBcPaTEtr['url']
    WCHfdmKqzGAYFxglIohSniBcPaTEey=urllib.parse.urlsplit(WCHfdmKqzGAYFxglIohSniBcPaTEeN).query
    WCHfdmKqzGAYFxglIohSniBcPaTEeb=WCHfdmKqzGAYFxglIohSniBcPaTEey[0:WCHfdmKqzGAYFxglIohSniBcPaTEey.find('=')]
    WCHfdmKqzGAYFxglIohSniBcPaTEev=WCHfdmKqzGAYFxglIohSniBcPaTEey[WCHfdmKqzGAYFxglIohSniBcPaTEey.find('=')+1:]
    WCHfdmKqzGAYFxglIohSniBcPaTEes={'title':WCHfdmKqzGAYFxglIohSniBcPaTEeX['title_list'][0]['text'],'age':WCHfdmKqzGAYFxglIohSniBcPaTEeX['age'],'thumbnail':'https://%s'%WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('thumbnail'),'videoid':WCHfdmKqzGAYFxglIohSniBcPaTEev,'vidtype':WCHfdmKqzGAYFxglIohSniBcPaTEeb}
    WCHfdmKqzGAYFxglIohSniBcPaTEte.append(WCHfdmKqzGAYFxglIohSniBcPaTEes)
   if WCHfdmKqzGAYFxglIohSniBcPaTEeV.find('instantplay')<0:
    WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['pagecount'])
    if WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['count']:WCHfdmKqzGAYFxglIohSniBcPaTEeO =WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['count'])
    else:WCHfdmKqzGAYFxglIohSniBcPaTEeO=WCHfdmKqzGAYFxglIohSniBcPaTEwt.LIST_LIMIT*page_int
    WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEeU>WCHfdmKqzGAYFxglIohSniBcPaTEeO
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[],WCHfdmKqzGAYFxglIohSniBcPaTEkV
  return WCHfdmKqzGAYFxglIohSniBcPaTEte,WCHfdmKqzGAYFxglIohSniBcPaTEeQ
 def Get_Movie_List(WCHfdmKqzGAYFxglIohSniBcPaTEwt,WCHfdmKqzGAYFxglIohSniBcPaTEeV,page_int=1):
  WCHfdmKqzGAYFxglIohSniBcPaTEtk=[]
  WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEeO=1
  WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEkV
  (WCHfdmKqzGAYFxglIohSniBcPaTEwQ,WCHfdmKqzGAYFxglIohSniBcPaTEwJ)=WCHfdmKqzGAYFxglIohSniBcPaTEwt.Baseapi_Parse(WCHfdmKqzGAYFxglIohSniBcPaTEeV)
  if WCHfdmKqzGAYFxglIohSniBcPaTEwQ=='':return WCHfdmKqzGAYFxglIohSniBcPaTEtk,WCHfdmKqzGAYFxglIohSniBcPaTEeQ
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['limit']=WCHfdmKqzGAYFxglIohSniBcPaTEwt.MV_LIMIT
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['offset']=WCHfdmKqzGAYFxglIohSniBcPaTEkX((page_int-1)*WCHfdmKqzGAYFxglIohSniBcPaTEwt.MV_LIMIT)
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV))
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('celllist' in WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']):return WCHfdmKqzGAYFxglIohSniBcPaTEtk,WCHfdmKqzGAYFxglIohSniBcPaTEeQ
   WCHfdmKqzGAYFxglIohSniBcPaTEeu=WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['celllist']
   for WCHfdmKqzGAYFxglIohSniBcPaTEeX in WCHfdmKqzGAYFxglIohSniBcPaTEeu:
    WCHfdmKqzGAYFxglIohSniBcPaTEeN =WCHfdmKqzGAYFxglIohSniBcPaTEeX['event_list'][1]['url']
    WCHfdmKqzGAYFxglIohSniBcPaTEey=urllib.parse.urlsplit(WCHfdmKqzGAYFxglIohSniBcPaTEeN).query
    WCHfdmKqzGAYFxglIohSniBcPaTEeb=WCHfdmKqzGAYFxglIohSniBcPaTEey[0:WCHfdmKqzGAYFxglIohSniBcPaTEey.find('=')]
    WCHfdmKqzGAYFxglIohSniBcPaTEev=WCHfdmKqzGAYFxglIohSniBcPaTEey[WCHfdmKqzGAYFxglIohSniBcPaTEey.find('=')+1:]
    WCHfdmKqzGAYFxglIohSniBcPaTEes={'title':WCHfdmKqzGAYFxglIohSniBcPaTEeX['title_list'][0]['text'],'age':WCHfdmKqzGAYFxglIohSniBcPaTEeX['age'],'thumbnail':'https://%s'%WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('thumbnail'),'videoid':WCHfdmKqzGAYFxglIohSniBcPaTEev,'vidtype':WCHfdmKqzGAYFxglIohSniBcPaTEeb}
    WCHfdmKqzGAYFxglIohSniBcPaTEtk.append(WCHfdmKqzGAYFxglIohSniBcPaTEes)
   WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['pagecount'])
   if WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['count']:WCHfdmKqzGAYFxglIohSniBcPaTEeO =WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['count'])
   else:WCHfdmKqzGAYFxglIohSniBcPaTEeO=WCHfdmKqzGAYFxglIohSniBcPaTEwt.MV_LIMIT*page_int
   WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEeU>WCHfdmKqzGAYFxglIohSniBcPaTEeO
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[],WCHfdmKqzGAYFxglIohSniBcPaTEkV
  return WCHfdmKqzGAYFxglIohSniBcPaTEtk,WCHfdmKqzGAYFxglIohSniBcPaTEeQ
 def ProgramidToContentid(WCHfdmKqzGAYFxglIohSniBcPaTEwt,WCHfdmKqzGAYFxglIohSniBcPaTEtu):
  WCHfdmKqzGAYFxglIohSniBcPaTEtV=''
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ =WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/vod/programs-contentid/'+WCHfdmKqzGAYFxglIohSniBcPaTEtu
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV)
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEtJ=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('contentid' in WCHfdmKqzGAYFxglIohSniBcPaTEtJ):return WCHfdmKqzGAYFxglIohSniBcPaTEtV 
   WCHfdmKqzGAYFxglIohSniBcPaTEtV=WCHfdmKqzGAYFxglIohSniBcPaTEtJ['contentid']
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
  return WCHfdmKqzGAYFxglIohSniBcPaTEtV
 def ContentidToProgramid(WCHfdmKqzGAYFxglIohSniBcPaTEwt,WCHfdmKqzGAYFxglIohSniBcPaTEtV):
  WCHfdmKqzGAYFxglIohSniBcPaTEtu=''
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ =WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/cf/vod/contents/'+WCHfdmKqzGAYFxglIohSniBcPaTEtV
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV)
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEtJ=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('programid' in WCHfdmKqzGAYFxglIohSniBcPaTEtJ):return WCHfdmKqzGAYFxglIohSniBcPaTEtu 
   WCHfdmKqzGAYFxglIohSniBcPaTEtu=WCHfdmKqzGAYFxglIohSniBcPaTEtJ['programid']
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
  return WCHfdmKqzGAYFxglIohSniBcPaTEtu
 def GetProgramInfo(WCHfdmKqzGAYFxglIohSniBcPaTEwt,program_code):
  WCHfdmKqzGAYFxglIohSniBcPaTEtX={}
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/cf/vod/contents/'+program_code
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV)
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEtJ=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(WCHfdmKqzGAYFxglIohSniBcPaTEtJ)
   WCHfdmKqzGAYFxglIohSniBcPaTEts=img_fanart=WCHfdmKqzGAYFxglIohSniBcPaTEtL=''
   if WCHfdmKqzGAYFxglIohSniBcPaTEtJ.get('programposterimage')!='':WCHfdmKqzGAYFxglIohSniBcPaTEts =WCHfdmKqzGAYFxglIohSniBcPaTEwt.HTTPTAG+WCHfdmKqzGAYFxglIohSniBcPaTEtJ.get('programposterimage')
   if WCHfdmKqzGAYFxglIohSniBcPaTEtJ.get('programimage') !='':img_fanart =WCHfdmKqzGAYFxglIohSniBcPaTEwt.HTTPTAG+WCHfdmKqzGAYFxglIohSniBcPaTEtJ.get('programimage')
   if WCHfdmKqzGAYFxglIohSniBcPaTEtJ.get('programcirlceimage')!='':WCHfdmKqzGAYFxglIohSniBcPaTEtL=WCHfdmKqzGAYFxglIohSniBcPaTEwt.HTTPTAG+WCHfdmKqzGAYFxglIohSniBcPaTEtJ.get('programcirlceimage')
   if 'poster_default' in WCHfdmKqzGAYFxglIohSniBcPaTEts:
    WCHfdmKqzGAYFxglIohSniBcPaTEts =img_fanart
    WCHfdmKqzGAYFxglIohSniBcPaTEtL=''
   WCHfdmKqzGAYFxglIohSniBcPaTEtX={'imgPoster':WCHfdmKqzGAYFxglIohSniBcPaTEts,'imgFanart':img_fanart,'imgClearlogo':WCHfdmKqzGAYFxglIohSniBcPaTEtL}
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
  return WCHfdmKqzGAYFxglIohSniBcPaTEtX
 def Get_Episode_List(WCHfdmKqzGAYFxglIohSniBcPaTEwt,WCHfdmKqzGAYFxglIohSniBcPaTEev,WCHfdmKqzGAYFxglIohSniBcPaTEeb,page_int=1,orderby='desc'):
  WCHfdmKqzGAYFxglIohSniBcPaTEtp=[]
  WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEeO=1
  WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEkV
  WCHfdmKqzGAYFxglIohSniBcPaTEtj={}
  if WCHfdmKqzGAYFxglIohSniBcPaTEeb=='contentid':
   WCHfdmKqzGAYFxglIohSniBcPaTEtu=WCHfdmKqzGAYFxglIohSniBcPaTEwt.ContentidToProgramid(WCHfdmKqzGAYFxglIohSniBcPaTEev)
   WCHfdmKqzGAYFxglIohSniBcPaTEtj=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetProgramInfo(WCHfdmKqzGAYFxglIohSniBcPaTEev)
  else:
   WCHfdmKqzGAYFxglIohSniBcPaTEtu=WCHfdmKqzGAYFxglIohSniBcPaTEev
   WCHfdmKqzGAYFxglIohSniBcPaTEtV=WCHfdmKqzGAYFxglIohSniBcPaTEwt.ProgramidToContentid(WCHfdmKqzGAYFxglIohSniBcPaTEev)
   if WCHfdmKqzGAYFxglIohSniBcPaTEtV!='':WCHfdmKqzGAYFxglIohSniBcPaTEtj=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetProgramInfo(WCHfdmKqzGAYFxglIohSniBcPaTEtV)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/vod/programs-contents/'+WCHfdmKqzGAYFxglIohSniBcPaTEtu
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ={}
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['limit'] =WCHfdmKqzGAYFxglIohSniBcPaTEwt.EP_LIMIT
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['offset']=WCHfdmKqzGAYFxglIohSniBcPaTEkX((page_int-1)*WCHfdmKqzGAYFxglIohSniBcPaTEwt.EP_LIMIT)
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['orderby']=orderby 
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV))
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   WCHfdmKqzGAYFxglIohSniBcPaTEeu=WCHfdmKqzGAYFxglIohSniBcPaTEwb['list']
   for WCHfdmKqzGAYFxglIohSniBcPaTEeX in WCHfdmKqzGAYFxglIohSniBcPaTEeu:
    WCHfdmKqzGAYFxglIohSniBcPaTEtD=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('synopsis'))
    WCHfdmKqzGAYFxglIohSniBcPaTEtM=WCHfdmKqzGAYFxglIohSniBcPaTEwt.HTTPTAG+WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('image')
    WCHfdmKqzGAYFxglIohSniBcPaTEtU=WCHfdmKqzGAYFxglIohSniBcPaTEtQ=WCHfdmKqzGAYFxglIohSniBcPaTEtN=''
    if WCHfdmKqzGAYFxglIohSniBcPaTEtj!={}:
     WCHfdmKqzGAYFxglIohSniBcPaTEtU =WCHfdmKqzGAYFxglIohSniBcPaTEtj.get('imgPoster')
     WCHfdmKqzGAYFxglIohSniBcPaTEtQ =WCHfdmKqzGAYFxglIohSniBcPaTEtj.get('imgFanart')
     WCHfdmKqzGAYFxglIohSniBcPaTEtN=WCHfdmKqzGAYFxglIohSniBcPaTEtj.get('imgClearlogo')
     WCHfdmKqzGAYFxglIohSniBcPaTEty={'thumb':WCHfdmKqzGAYFxglIohSniBcPaTEtM,'poster':WCHfdmKqzGAYFxglIohSniBcPaTEtU,'fanart':WCHfdmKqzGAYFxglIohSniBcPaTEtQ,'clearlogo':WCHfdmKqzGAYFxglIohSniBcPaTEtN}
    else:
     WCHfdmKqzGAYFxglIohSniBcPaTEty=WCHfdmKqzGAYFxglIohSniBcPaTEtM
    WCHfdmKqzGAYFxglIohSniBcPaTEes={'programtitle':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('programtitle'),'episodetitle':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('episodetitle'),'episodenumber':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('episodenumber'),'releasedate':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('releasedate'),'releaseweekday':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('releaseweekday'),'programid':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('programid'),'contentid':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('contentid'),'age':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('targetage'),'playtime':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('playtime'),'synopsis':WCHfdmKqzGAYFxglIohSniBcPaTEtD,'episodeactors':WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('episodeactors').split(',')if WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('episodeactors')!='' else[],'thumbnail':WCHfdmKqzGAYFxglIohSniBcPaTEty}
    WCHfdmKqzGAYFxglIohSniBcPaTEtp.append(WCHfdmKqzGAYFxglIohSniBcPaTEes)
   WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEwb['pagecount'])
   if WCHfdmKqzGAYFxglIohSniBcPaTEwb['count']:WCHfdmKqzGAYFxglIohSniBcPaTEeO =WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEwb['count'])
   else:WCHfdmKqzGAYFxglIohSniBcPaTEeO=WCHfdmKqzGAYFxglIohSniBcPaTEwt.EP_LIMIT*page_int
   WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEeU>WCHfdmKqzGAYFxglIohSniBcPaTEeO
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[],WCHfdmKqzGAYFxglIohSniBcPaTEkV
  return WCHfdmKqzGAYFxglIohSniBcPaTEtp,WCHfdmKqzGAYFxglIohSniBcPaTEeQ
 def GetEPGList(WCHfdmKqzGAYFxglIohSniBcPaTEwt,genre):
  WCHfdmKqzGAYFxglIohSniBcPaTEtb={}
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEtv=WCHfdmKqzGAYFxglIohSniBcPaTEwt.Get_Now_Datetime()
   if genre=='all':
    WCHfdmKqzGAYFxglIohSniBcPaTEtO =WCHfdmKqzGAYFxglIohSniBcPaTEtv+datetime.timedelta(hours=3)
   else:
    WCHfdmKqzGAYFxglIohSniBcPaTEtO =WCHfdmKqzGAYFxglIohSniBcPaTEtv+datetime.timedelta(hours=3)
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/live/epgs'
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ={'limit':'100','offset':'0','genre':genre,'startdatetime':WCHfdmKqzGAYFxglIohSniBcPaTEtv.strftime('%Y-%m-%d %H:00'),'enddatetime':WCHfdmKqzGAYFxglIohSniBcPaTEtO.strftime('%Y-%m-%d %H:00')}
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV))
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   WCHfdmKqzGAYFxglIohSniBcPaTErw=WCHfdmKqzGAYFxglIohSniBcPaTEwb['list']
   for WCHfdmKqzGAYFxglIohSniBcPaTEeX in WCHfdmKqzGAYFxglIohSniBcPaTErw:
    WCHfdmKqzGAYFxglIohSniBcPaTEre=''
    for WCHfdmKqzGAYFxglIohSniBcPaTErt in WCHfdmKqzGAYFxglIohSniBcPaTEeX['list']:
     if WCHfdmKqzGAYFxglIohSniBcPaTEre:WCHfdmKqzGAYFxglIohSniBcPaTEre+='\n'
     WCHfdmKqzGAYFxglIohSniBcPaTEre+=WCHfdmKqzGAYFxglIohSniBcPaTEwt.Get_ChangeText(WCHfdmKqzGAYFxglIohSniBcPaTErt['title'])+'\n'
     WCHfdmKqzGAYFxglIohSniBcPaTEre+=' [%s ~ %s]'%(WCHfdmKqzGAYFxglIohSniBcPaTErt['starttime'][-5:],WCHfdmKqzGAYFxglIohSniBcPaTErt['endtime'][-5:])+'\n'
    WCHfdmKqzGAYFxglIohSniBcPaTEtb[WCHfdmKqzGAYFxglIohSniBcPaTEeX['channelid']]=WCHfdmKqzGAYFxglIohSniBcPaTEre
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
  return WCHfdmKqzGAYFxglIohSniBcPaTEtb
 def Get_LiveChannel_List(WCHfdmKqzGAYFxglIohSniBcPaTEwt,genre,WCHfdmKqzGAYFxglIohSniBcPaTEeV):
  WCHfdmKqzGAYFxglIohSniBcPaTEeM=[]
  (WCHfdmKqzGAYFxglIohSniBcPaTEwQ,WCHfdmKqzGAYFxglIohSniBcPaTEwJ)=WCHfdmKqzGAYFxglIohSniBcPaTEwt.Baseapi_Parse(WCHfdmKqzGAYFxglIohSniBcPaTEeV)
  if WCHfdmKqzGAYFxglIohSniBcPaTEwQ=='':return WCHfdmKqzGAYFxglIohSniBcPaTEeM
  WCHfdmKqzGAYFxglIohSniBcPaTErk=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetEPGList(genre)
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV))
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ['genre']=genre
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('celllist' in WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']):return[]
   WCHfdmKqzGAYFxglIohSniBcPaTEeu=WCHfdmKqzGAYFxglIohSniBcPaTEwb['cell_toplist']['celllist']
   for WCHfdmKqzGAYFxglIohSniBcPaTEeX in WCHfdmKqzGAYFxglIohSniBcPaTEeu:
    WCHfdmKqzGAYFxglIohSniBcPaTEtV=WCHfdmKqzGAYFxglIohSniBcPaTEeX['contentid']
    if WCHfdmKqzGAYFxglIohSniBcPaTEtV in WCHfdmKqzGAYFxglIohSniBcPaTErk:
     WCHfdmKqzGAYFxglIohSniBcPaTErV=WCHfdmKqzGAYFxglIohSniBcPaTErk[WCHfdmKqzGAYFxglIohSniBcPaTEtV]
    else:
     WCHfdmKqzGAYFxglIohSniBcPaTErV=''
    WCHfdmKqzGAYFxglIohSniBcPaTEes={'studio':WCHfdmKqzGAYFxglIohSniBcPaTEeX['title_list'][0]['text'],'tvshowtitle':WCHfdmKqzGAYFxglIohSniBcPaTEwt.Get_ChangeText(WCHfdmKqzGAYFxglIohSniBcPaTEeX['title_list'][1]['text']),'channelid':WCHfdmKqzGAYFxglIohSniBcPaTEtV,'age':WCHfdmKqzGAYFxglIohSniBcPaTEeX['age'],'thumbnail':'https://%s'%WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('thumbnail'),'epg':WCHfdmKqzGAYFxglIohSniBcPaTErV}
    WCHfdmKqzGAYFxglIohSniBcPaTEeM.append(WCHfdmKqzGAYFxglIohSniBcPaTEes)
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return[]
  return WCHfdmKqzGAYFxglIohSniBcPaTEeM
 def Get_Search_List(WCHfdmKqzGAYFxglIohSniBcPaTEwt,search_key,sType,page_int,exclusion21=WCHfdmKqzGAYFxglIohSniBcPaTEkV):
  WCHfdmKqzGAYFxglIohSniBcPaTErJ=[]
  WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEeO=1
  WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEkV
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/cf/search/list.js'
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':WCHfdmKqzGAYFxglIohSniBcPaTEkX((page_int-1)*WCHfdmKqzGAYFxglIohSniBcPaTEwt.SEARCH_LIMIT),'limit':WCHfdmKqzGAYFxglIohSniBcPaTEwt.SEARCH_LIMIT,'orderby':'score'}
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV))
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEtJ=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('celllist' in WCHfdmKqzGAYFxglIohSniBcPaTEtJ['cell_toplist']):return WCHfdmKqzGAYFxglIohSniBcPaTErJ,WCHfdmKqzGAYFxglIohSniBcPaTEeQ
   WCHfdmKqzGAYFxglIohSniBcPaTEeu=WCHfdmKqzGAYFxglIohSniBcPaTEtJ['cell_toplist']['celllist']
   for WCHfdmKqzGAYFxglIohSniBcPaTEeX in WCHfdmKqzGAYFxglIohSniBcPaTEeu:
    WCHfdmKqzGAYFxglIohSniBcPaTEeN =WCHfdmKqzGAYFxglIohSniBcPaTEeX['event_list'][1]['url']
    WCHfdmKqzGAYFxglIohSniBcPaTEey=urllib.parse.urlsplit(WCHfdmKqzGAYFxglIohSniBcPaTEeN).query
    WCHfdmKqzGAYFxglIohSniBcPaTEeb=WCHfdmKqzGAYFxglIohSniBcPaTEey[0:WCHfdmKqzGAYFxglIohSniBcPaTEey.find('=')]
    WCHfdmKqzGAYFxglIohSniBcPaTEev=WCHfdmKqzGAYFxglIohSniBcPaTEey[WCHfdmKqzGAYFxglIohSniBcPaTEey.find('=')+1:]
    WCHfdmKqzGAYFxglIohSniBcPaTEes={'title':WCHfdmKqzGAYFxglIohSniBcPaTEeX['title_list'][0]['text'],'age':WCHfdmKqzGAYFxglIohSniBcPaTEeX['age'],'thumbnail':'https://%s'%WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('thumbnail'),'videoid':WCHfdmKqzGAYFxglIohSniBcPaTEev,'vidtype':WCHfdmKqzGAYFxglIohSniBcPaTEeb}
    if exclusion21==WCHfdmKqzGAYFxglIohSniBcPaTEkV or WCHfdmKqzGAYFxglIohSniBcPaTEeX.get('age')!='21':
     WCHfdmKqzGAYFxglIohSniBcPaTErJ.append(WCHfdmKqzGAYFxglIohSniBcPaTEes)
   WCHfdmKqzGAYFxglIohSniBcPaTEeU=WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEtJ['cell_toplist']['pagecount'])
   if WCHfdmKqzGAYFxglIohSniBcPaTEtJ['cell_toplist']['count']:WCHfdmKqzGAYFxglIohSniBcPaTEeO =WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTEtJ['cell_toplist']['count'])
   else:WCHfdmKqzGAYFxglIohSniBcPaTEeO=WCHfdmKqzGAYFxglIohSniBcPaTEwt.LIST_LIMIT
   WCHfdmKqzGAYFxglIohSniBcPaTEeQ=WCHfdmKqzGAYFxglIohSniBcPaTEeU>WCHfdmKqzGAYFxglIohSniBcPaTEeO
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
  return WCHfdmKqzGAYFxglIohSniBcPaTErJ,WCHfdmKqzGAYFxglIohSniBcPaTEeQ 
 def GetStreamingURL(WCHfdmKqzGAYFxglIohSniBcPaTEwt,mode,WCHfdmKqzGAYFxglIohSniBcPaTEtV,quality_int,pvrmode='-'):
  WCHfdmKqzGAYFxglIohSniBcPaTEru=WCHfdmKqzGAYFxglIohSniBcPaTErM=WCHfdmKqzGAYFxglIohSniBcPaTErU=streaming_preview=''
  WCHfdmKqzGAYFxglIohSniBcPaTErX=[]
  WCHfdmKqzGAYFxglIohSniBcPaTErs='hls'
  if mode=='LIVE':
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ =WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/live/channels/'+WCHfdmKqzGAYFxglIohSniBcPaTEtV
   WCHfdmKqzGAYFxglIohSniBcPaTErL='live'
  elif mode=='VOD':
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ =WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/cf/vod/contents/'+WCHfdmKqzGAYFxglIohSniBcPaTEtV
   WCHfdmKqzGAYFxglIohSniBcPaTErL='vod'
  elif mode=='MOVIE':
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ =WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/cf/movie/contents/'+WCHfdmKqzGAYFxglIohSniBcPaTEtV
   WCHfdmKqzGAYFxglIohSniBcPaTErL='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    WCHfdmKqzGAYFxglIohSniBcPaTEwJ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV)
    WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
    WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
    WCHfdmKqzGAYFxglIohSniBcPaTErp=WCHfdmKqzGAYFxglIohSniBcPaTEwb['qualities']['list']
    if WCHfdmKqzGAYFxglIohSniBcPaTErp==WCHfdmKqzGAYFxglIohSniBcPaTEkr:return(WCHfdmKqzGAYFxglIohSniBcPaTEru,WCHfdmKqzGAYFxglIohSniBcPaTErM,WCHfdmKqzGAYFxglIohSniBcPaTErU,streaming_preview)
    for WCHfdmKqzGAYFxglIohSniBcPaTErj in WCHfdmKqzGAYFxglIohSniBcPaTErp:
     WCHfdmKqzGAYFxglIohSniBcPaTErX.append(WCHfdmKqzGAYFxglIohSniBcPaTEkj(WCHfdmKqzGAYFxglIohSniBcPaTErj.get('id').rstrip('p')))
    if 'type' in WCHfdmKqzGAYFxglIohSniBcPaTEwb:
     if WCHfdmKqzGAYFxglIohSniBcPaTEwb['type']=='onair':
      WCHfdmKqzGAYFxglIohSniBcPaTErL='onairvod'
    if 'drms' in WCHfdmKqzGAYFxglIohSniBcPaTEwb:
     if WCHfdmKqzGAYFxglIohSniBcPaTEwb['drms']:
      WCHfdmKqzGAYFxglIohSniBcPaTErs='dash'
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
   return(WCHfdmKqzGAYFxglIohSniBcPaTEru,WCHfdmKqzGAYFxglIohSniBcPaTErM,WCHfdmKqzGAYFxglIohSniBcPaTErU,streaming_preview)
  try:
   WCHfdmKqzGAYFxglIohSniBcPaTErR=WCHfdmKqzGAYFxglIohSniBcPaTEwt.CheckQuality(quality_int,WCHfdmKqzGAYFxglIohSniBcPaTErX)
   if mode=='LIVE' and pvrmode!='-':
    WCHfdmKqzGAYFxglIohSniBcPaTErD='auto'
   else:
    WCHfdmKqzGAYFxglIohSniBcPaTErD=WCHfdmKqzGAYFxglIohSniBcPaTEkX(WCHfdmKqzGAYFxglIohSniBcPaTErR)+'p'
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/streaming'
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ={'contentid':WCHfdmKqzGAYFxglIohSniBcPaTEtV,'contenttype':WCHfdmKqzGAYFxglIohSniBcPaTErL,'action':WCHfdmKqzGAYFxglIohSniBcPaTErs,'quality':WCHfdmKqzGAYFxglIohSniBcPaTErD,'deviceModelId':'Windows 10','guid':WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ.update(WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkJ))
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   WCHfdmKqzGAYFxglIohSniBcPaTEru=WCHfdmKqzGAYFxglIohSniBcPaTEwb['playurl']
   if WCHfdmKqzGAYFxglIohSniBcPaTEru==WCHfdmKqzGAYFxglIohSniBcPaTEkr:return(WCHfdmKqzGAYFxglIohSniBcPaTEru,WCHfdmKqzGAYFxglIohSniBcPaTErM,WCHfdmKqzGAYFxglIohSniBcPaTErU,streaming_preview)
   WCHfdmKqzGAYFxglIohSniBcPaTErM=WCHfdmKqzGAYFxglIohSniBcPaTEwb['awscookie']
   WCHfdmKqzGAYFxglIohSniBcPaTErU =WCHfdmKqzGAYFxglIohSniBcPaTEwb['drm']
   if 'previewmsg' in WCHfdmKqzGAYFxglIohSniBcPaTEwb['preview']:streaming_preview=WCHfdmKqzGAYFxglIohSniBcPaTEwb['preview']['previewmsg']
  except WCHfdmKqzGAYFxglIohSniBcPaTEks as exception:
   WCHfdmKqzGAYFxglIohSniBcPaTEkL(exception)
  return(WCHfdmKqzGAYFxglIohSniBcPaTEru,WCHfdmKqzGAYFxglIohSniBcPaTErM,WCHfdmKqzGAYFxglIohSniBcPaTErU,streaming_preview) 
 def GetBookmarkInfo(WCHfdmKqzGAYFxglIohSniBcPaTEwt,WCHfdmKqzGAYFxglIohSniBcPaTEev,WCHfdmKqzGAYFxglIohSniBcPaTEeb,WCHfdmKqzGAYFxglIohSniBcPaTErL):
  if WCHfdmKqzGAYFxglIohSniBcPaTEeb=='tvshow':
   if WCHfdmKqzGAYFxglIohSniBcPaTErL=='contentid':
    WCHfdmKqzGAYFxglIohSniBcPaTEtV=WCHfdmKqzGAYFxglIohSniBcPaTEev
    WCHfdmKqzGAYFxglIohSniBcPaTEev =WCHfdmKqzGAYFxglIohSniBcPaTEwt.ContentidToProgramid(WCHfdmKqzGAYFxglIohSniBcPaTEtV)
   else:
    WCHfdmKqzGAYFxglIohSniBcPaTEtV=WCHfdmKqzGAYFxglIohSniBcPaTEwt.ProgramidToContentid(WCHfdmKqzGAYFxglIohSniBcPaTEev)
  else:
   WCHfdmKqzGAYFxglIohSniBcPaTEtV=''
  WCHfdmKqzGAYFxglIohSniBcPaTErQ={'indexinfo':{'ott':'wavve','videoid':WCHfdmKqzGAYFxglIohSniBcPaTEev,'vidtype':WCHfdmKqzGAYFxglIohSniBcPaTEeb,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':WCHfdmKqzGAYFxglIohSniBcPaTEeb,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if WCHfdmKqzGAYFxglIohSniBcPaTEeb=='tvshow':
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/cf/vod/contents/'+WCHfdmKqzGAYFxglIohSniBcPaTEtV 
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV)
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('programtitle' in WCHfdmKqzGAYFxglIohSniBcPaTEwb):return{}
   WCHfdmKqzGAYFxglIohSniBcPaTErN=WCHfdmKqzGAYFxglIohSniBcPaTEwb
   WCHfdmKqzGAYFxglIohSniBcPaTEry=WCHfdmKqzGAYFxglIohSniBcPaTErN.get('programtitle')
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['title']=WCHfdmKqzGAYFxglIohSniBcPaTEry
   if WCHfdmKqzGAYFxglIohSniBcPaTErN.get('targetage')=='18' or WCHfdmKqzGAYFxglIohSniBcPaTErN.get('targetage')=='19' or WCHfdmKqzGAYFxglIohSniBcPaTErN.get('targetage')=='21':
    WCHfdmKqzGAYFxglIohSniBcPaTEry +=u' (%s)'%(WCHfdmKqzGAYFxglIohSniBcPaTErN.get('targetage'))
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['title'] =WCHfdmKqzGAYFxglIohSniBcPaTEry
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['mpaa'] =WCHfdmKqzGAYFxglIohSniBcPaTErN.get('targetage')
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['plot'] =WCHfdmKqzGAYFxglIohSniBcPaTErN.get('programsynopsis').replace('<br>','\n')
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['studio'] =WCHfdmKqzGAYFxglIohSniBcPaTErN.get('channelname')
   if WCHfdmKqzGAYFxglIohSniBcPaTErN.get('firstreleaseyear')!='':WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['year'] =WCHfdmKqzGAYFxglIohSniBcPaTErN.get('firstreleaseyear')
   if WCHfdmKqzGAYFxglIohSniBcPaTErN.get('firstreleasedate')!='':WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['premiered']=WCHfdmKqzGAYFxglIohSniBcPaTErN.get('firstreleasedate')
   if WCHfdmKqzGAYFxglIohSniBcPaTErN.get('genretext') !='':WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['genre'] =[WCHfdmKqzGAYFxglIohSniBcPaTErN.get('genretext')]
   WCHfdmKqzGAYFxglIohSniBcPaTErb=[]
   for WCHfdmKqzGAYFxglIohSniBcPaTErv in WCHfdmKqzGAYFxglIohSniBcPaTErN['actors']['list']:WCHfdmKqzGAYFxglIohSniBcPaTErb.append(WCHfdmKqzGAYFxglIohSniBcPaTErv.get('text'))
   if WCHfdmKqzGAYFxglIohSniBcPaTEkR(WCHfdmKqzGAYFxglIohSniBcPaTErb)>0:
    if WCHfdmKqzGAYFxglIohSniBcPaTErb[0]!='':WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['cast']=WCHfdmKqzGAYFxglIohSniBcPaTErb
   WCHfdmKqzGAYFxglIohSniBcPaTEtU =''
   WCHfdmKqzGAYFxglIohSniBcPaTEtQ =''
   WCHfdmKqzGAYFxglIohSniBcPaTEtN=''
   if WCHfdmKqzGAYFxglIohSniBcPaTErN.get('programposterimage')!='':WCHfdmKqzGAYFxglIohSniBcPaTEtU =WCHfdmKqzGAYFxglIohSniBcPaTEwt.HTTPTAG+WCHfdmKqzGAYFxglIohSniBcPaTErN.get('programposterimage')
   if WCHfdmKqzGAYFxglIohSniBcPaTErN.get('programimage') !='':WCHfdmKqzGAYFxglIohSniBcPaTEtQ =WCHfdmKqzGAYFxglIohSniBcPaTEwt.HTTPTAG+WCHfdmKqzGAYFxglIohSniBcPaTErN.get('programimage')
   if WCHfdmKqzGAYFxglIohSniBcPaTErN.get('programcirlceimage')!='':WCHfdmKqzGAYFxglIohSniBcPaTEtN=WCHfdmKqzGAYFxglIohSniBcPaTEwt.HTTPTAG+WCHfdmKqzGAYFxglIohSniBcPaTErN.get('programcirlceimage')
   if 'poster_default' in WCHfdmKqzGAYFxglIohSniBcPaTEtU:
    WCHfdmKqzGAYFxglIohSniBcPaTEtU =WCHfdmKqzGAYFxglIohSniBcPaTEtQ
    WCHfdmKqzGAYFxglIohSniBcPaTEtN=''
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['thumbnail']['poster']=WCHfdmKqzGAYFxglIohSniBcPaTEtU
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['thumbnail']['thumb']=WCHfdmKqzGAYFxglIohSniBcPaTEtQ
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['thumbnail']['clearlogo']=WCHfdmKqzGAYFxglIohSniBcPaTEtN
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['thumbnail']['fanart']=WCHfdmKqzGAYFxglIohSniBcPaTEtQ
  else:
   WCHfdmKqzGAYFxglIohSniBcPaTEwQ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.API_DOMAIN+'/movie/contents/'+WCHfdmKqzGAYFxglIohSniBcPaTEev 
   WCHfdmKqzGAYFxglIohSniBcPaTEwJ=WCHfdmKqzGAYFxglIohSniBcPaTEwt.GetDefaultParams(login=WCHfdmKqzGAYFxglIohSniBcPaTEkV)
   WCHfdmKqzGAYFxglIohSniBcPaTEwy=WCHfdmKqzGAYFxglIohSniBcPaTEwt.callRequestCookies('Get',WCHfdmKqzGAYFxglIohSniBcPaTEwQ,payload=WCHfdmKqzGAYFxglIohSniBcPaTEkr,params=WCHfdmKqzGAYFxglIohSniBcPaTEwJ,headers=WCHfdmKqzGAYFxglIohSniBcPaTEkr,cookies=WCHfdmKqzGAYFxglIohSniBcPaTEkr)
   WCHfdmKqzGAYFxglIohSniBcPaTEwb=json.loads(WCHfdmKqzGAYFxglIohSniBcPaTEwy.text)
   if not('title' in WCHfdmKqzGAYFxglIohSniBcPaTEwb):return{}
   WCHfdmKqzGAYFxglIohSniBcPaTErN=WCHfdmKqzGAYFxglIohSniBcPaTEwb
   WCHfdmKqzGAYFxglIohSniBcPaTEry=WCHfdmKqzGAYFxglIohSniBcPaTErN.get('title')
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['title']=WCHfdmKqzGAYFxglIohSniBcPaTEry
   if WCHfdmKqzGAYFxglIohSniBcPaTErN.get('targetage')=='18' or WCHfdmKqzGAYFxglIohSniBcPaTErN.get('targetage')=='19' or WCHfdmKqzGAYFxglIohSniBcPaTErN.get('targetage')=='21':
    WCHfdmKqzGAYFxglIohSniBcPaTEry +=u' (%s)'%(WCHfdmKqzGAYFxglIohSniBcPaTErN.get('targetage'))
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['title'] =WCHfdmKqzGAYFxglIohSniBcPaTEry
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['mpaa'] =WCHfdmKqzGAYFxglIohSniBcPaTErN.get('targetage')
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['plot'] =WCHfdmKqzGAYFxglIohSniBcPaTErN.get('synopsis').replace('<br>','\n')
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['duration']=WCHfdmKqzGAYFxglIohSniBcPaTErN.get('playtime')
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['country']=WCHfdmKqzGAYFxglIohSniBcPaTErN.get('country')
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['studio'] =WCHfdmKqzGAYFxglIohSniBcPaTErN.get('cpname')
   if WCHfdmKqzGAYFxglIohSniBcPaTErN.get('releasedate')!='':
    WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['year'] =WCHfdmKqzGAYFxglIohSniBcPaTErN.get('releasedate')[:4]
    WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['premiered']=WCHfdmKqzGAYFxglIohSniBcPaTErN.get('releasedate')
   WCHfdmKqzGAYFxglIohSniBcPaTErb=[]
   for WCHfdmKqzGAYFxglIohSniBcPaTErv in WCHfdmKqzGAYFxglIohSniBcPaTErN['actors']['list']:WCHfdmKqzGAYFxglIohSniBcPaTErb.append(WCHfdmKqzGAYFxglIohSniBcPaTErv.get('text'))
   if WCHfdmKqzGAYFxglIohSniBcPaTEkR(WCHfdmKqzGAYFxglIohSniBcPaTErb)>0:
    if WCHfdmKqzGAYFxglIohSniBcPaTErb[0]!='':WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['cast']=WCHfdmKqzGAYFxglIohSniBcPaTErb
   WCHfdmKqzGAYFxglIohSniBcPaTErO=[]
   for WCHfdmKqzGAYFxglIohSniBcPaTEkw in WCHfdmKqzGAYFxglIohSniBcPaTErN['directors']['list']:WCHfdmKqzGAYFxglIohSniBcPaTErO.append(WCHfdmKqzGAYFxglIohSniBcPaTEkw.get('text'))
   if WCHfdmKqzGAYFxglIohSniBcPaTEkR(WCHfdmKqzGAYFxglIohSniBcPaTErO)>0:
    if WCHfdmKqzGAYFxglIohSniBcPaTErO[0]!='':WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['director']=WCHfdmKqzGAYFxglIohSniBcPaTErO
   WCHfdmKqzGAYFxglIohSniBcPaTEek=[]
   for WCHfdmKqzGAYFxglIohSniBcPaTEke in WCHfdmKqzGAYFxglIohSniBcPaTErN['genre']['list']:WCHfdmKqzGAYFxglIohSniBcPaTEek.append(WCHfdmKqzGAYFxglIohSniBcPaTEke.get('text'))
   if WCHfdmKqzGAYFxglIohSniBcPaTEkR(WCHfdmKqzGAYFxglIohSniBcPaTEek)>0:
    if WCHfdmKqzGAYFxglIohSniBcPaTEek[0]!='':WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['infoLabels']['genre']=WCHfdmKqzGAYFxglIohSniBcPaTEek
   WCHfdmKqzGAYFxglIohSniBcPaTEtU ='https://%s'%WCHfdmKqzGAYFxglIohSniBcPaTErN['image']
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['thumbnail']['poster'] =WCHfdmKqzGAYFxglIohSniBcPaTEtU
   WCHfdmKqzGAYFxglIohSniBcPaTErQ['saveinfo']['thumbnail']['thumb'] =WCHfdmKqzGAYFxglIohSniBcPaTEtU
  return WCHfdmKqzGAYFxglIohSniBcPaTErQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
