__author__="NightRain"
mlNpiQJfcEIHAadODryKRgvwuVUbsT=object
mlNpiQJfcEIHAadODryKRgvwuVUbsL=None
mlNpiQJfcEIHAadODryKRgvwuVUbsk=False
mlNpiQJfcEIHAadODryKRgvwuVUbsn=open
mlNpiQJfcEIHAadODryKRgvwuVUbjX=True
mlNpiQJfcEIHAadODryKRgvwuVUbjP=range
mlNpiQJfcEIHAadODryKRgvwuVUbjY=str
mlNpiQJfcEIHAadODryKRgvwuVUbjC=len
mlNpiQJfcEIHAadODryKRgvwuVUbjG=Exception
mlNpiQJfcEIHAadODryKRgvwuVUbjt=print
mlNpiQJfcEIHAadODryKRgvwuVUbjs=dict
mlNpiQJfcEIHAadODryKRgvwuVUbjz=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
mlNpiQJfcEIHAadODryKRgvwuVUbXY =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class mlNpiQJfcEIHAadODryKRgvwuVUbXP(mlNpiQJfcEIHAadODryKRgvwuVUbsT):
 def __init__(mlNpiQJfcEIHAadODryKRgvwuVUbXC):
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN='https://apis.wavve.com'
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV ={}
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.Init_WV_Total()
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.DEVICE ='pc'
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.DRM ='wm'
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.PARTNER ='pooq'
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.POOQZONE ='none'
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.REGION ='kor'
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.TARGETAGE ='all'
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.HTTPTAG ='https://'
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.LIST_LIMIT=30 
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.EP_LIMIT =30 
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.MV_LIMIT =24 
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.SEARCH_LIMIT=20 
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.DEFAULT_HEADER={'user-agent':mlNpiQJfcEIHAadODryKRgvwuVUbXC.USER_AGENT}
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.KodiVersion=20
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV_SESSION_COOKIES1=''
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV_SESSION_COOKIES2=''
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.COOKIE_FILE_NAME =''
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV_STREAM_FILENAME =''
 def Init_WV_Total(mlNpiQJfcEIHAadODryKRgvwuVUbXC):
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV={'account':{},'cookies':{},}
 def callRequestCookies(mlNpiQJfcEIHAadODryKRgvwuVUbXC,jobtype,mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbsL,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL,redirects=mlNpiQJfcEIHAadODryKRgvwuVUbsk):
  mlNpiQJfcEIHAadODryKRgvwuVUbXG=mlNpiQJfcEIHAadODryKRgvwuVUbXC.DEFAULT_HEADER
  if headers:mlNpiQJfcEIHAadODryKRgvwuVUbXG.update(headers)
  if jobtype=='Get':
   mlNpiQJfcEIHAadODryKRgvwuVUbXt=requests.get(mlNpiQJfcEIHAadODryKRgvwuVUbPW,params=params,headers=mlNpiQJfcEIHAadODryKRgvwuVUbXG,cookies=cookies,allow_redirects=redirects)
  else:
   mlNpiQJfcEIHAadODryKRgvwuVUbXt=requests.post(mlNpiQJfcEIHAadODryKRgvwuVUbPW,json=payload,params=params,headers=mlNpiQJfcEIHAadODryKRgvwuVUbXG,cookies=cookies,allow_redirects=redirects)
  return mlNpiQJfcEIHAadODryKRgvwuVUbXt
 def JsonFile_Save(mlNpiQJfcEIHAadODryKRgvwuVUbXC,filename,mlNpiQJfcEIHAadODryKRgvwuVUbXs):
  if filename=='':return mlNpiQJfcEIHAadODryKRgvwuVUbsk
  try:
   fp=mlNpiQJfcEIHAadODryKRgvwuVUbsn(filename,'w',-1,'utf-8')
   json.dump(mlNpiQJfcEIHAadODryKRgvwuVUbXs,fp,indent=4,ensure_ascii=mlNpiQJfcEIHAadODryKRgvwuVUbsk)
   fp.close()
  except:
   return mlNpiQJfcEIHAadODryKRgvwuVUbsk
  return mlNpiQJfcEIHAadODryKRgvwuVUbjX
 def JsonFile_Load(mlNpiQJfcEIHAadODryKRgvwuVUbXC,filename):
  if filename=='':return{}
  try:
   fp=mlNpiQJfcEIHAadODryKRgvwuVUbsn(filename,'r',-1,'utf-8')
   mlNpiQJfcEIHAadODryKRgvwuVUbXz=json.load(fp)
   fp.close()
  except:
   return{}
  return mlNpiQJfcEIHAadODryKRgvwuVUbXz
 def TextFile_Save(mlNpiQJfcEIHAadODryKRgvwuVUbXC,filename,resText):
  if filename=='':return mlNpiQJfcEIHAadODryKRgvwuVUbsk
  try:
   fp=mlNpiQJfcEIHAadODryKRgvwuVUbsn(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return mlNpiQJfcEIHAadODryKRgvwuVUbsk
  return mlNpiQJfcEIHAadODryKRgvwuVUbjX
 def Save_session_acount(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbXe,mlNpiQJfcEIHAadODryKRgvwuVUbXW,mlNpiQJfcEIHAadODryKRgvwuVUbXo):
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['account']['wvid']=base64.standard_b64encode(mlNpiQJfcEIHAadODryKRgvwuVUbXe.encode()).decode('utf-8')
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['account']['wvpw']=base64.standard_b64encode(mlNpiQJfcEIHAadODryKRgvwuVUbXW.encode()).decode('utf-8')
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['account']['wvpf']=mlNpiQJfcEIHAadODryKRgvwuVUbXo 
 def Load_session_acount(mlNpiQJfcEIHAadODryKRgvwuVUbXC):
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbXe=base64.standard_b64decode(mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['account']['wvid']).decode('utf-8')
   mlNpiQJfcEIHAadODryKRgvwuVUbXW=base64.standard_b64decode(mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['account']['wvpw']).decode('utf-8')
   mlNpiQJfcEIHAadODryKRgvwuVUbXo=mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['account']['wvpf']
  except:
   return '','',0
  return mlNpiQJfcEIHAadODryKRgvwuVUbXe,mlNpiQJfcEIHAadODryKRgvwuVUbXW,mlNpiQJfcEIHAadODryKRgvwuVUbXo
 def GetDefaultParams(mlNpiQJfcEIHAadODryKRgvwuVUbXC,login=mlNpiQJfcEIHAadODryKRgvwuVUbjX):
  mlNpiQJfcEIHAadODryKRgvwuVUbXM={'apikey':mlNpiQJfcEIHAadODryKRgvwuVUbXC.APIKEY,'credential':mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['cookies']['credential']if login else 'none','device':mlNpiQJfcEIHAadODryKRgvwuVUbXC.DEVICE,'drm':mlNpiQJfcEIHAadODryKRgvwuVUbXC.DRM,'partner':mlNpiQJfcEIHAadODryKRgvwuVUbXC.PARTNER,'pooqzone':mlNpiQJfcEIHAadODryKRgvwuVUbXC.POOQZONE,'region':mlNpiQJfcEIHAadODryKRgvwuVUbXC.REGION,'targetage':mlNpiQJfcEIHAadODryKRgvwuVUbXC.TARGETAGE,'client_version':'6.0.1',}
  return mlNpiQJfcEIHAadODryKRgvwuVUbXM
 def GetDefaultParams_AND(mlNpiQJfcEIHAadODryKRgvwuVUbXC):
  mlNpiQJfcEIHAadODryKRgvwuVUbXM={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['cookies']['credential'],'device':'ott','drm':mlNpiQJfcEIHAadODryKRgvwuVUbXC.DRM,'partner':mlNpiQJfcEIHAadODryKRgvwuVUbXC.PARTNER,'pooqzone':mlNpiQJfcEIHAadODryKRgvwuVUbXC.POOQZONE,'region':mlNpiQJfcEIHAadODryKRgvwuVUbXC.REGION,'targetage':mlNpiQJfcEIHAadODryKRgvwuVUbXC.TARGETAGE,}
  return mlNpiQJfcEIHAadODryKRgvwuVUbXM
 def GetGUID(mlNpiQJfcEIHAadODryKRgvwuVUbXC,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   mlNpiQJfcEIHAadODryKRgvwuVUbXq=mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   mlNpiQJfcEIHAadODryKRgvwuVUbXx=GenerateRandomString(5)
   mlNpiQJfcEIHAadODryKRgvwuVUbXB=mlNpiQJfcEIHAadODryKRgvwuVUbXx+media+mlNpiQJfcEIHAadODryKRgvwuVUbXq
   return mlNpiQJfcEIHAadODryKRgvwuVUbXB
  def GenerateRandomString(num):
   from random import randint
   mlNpiQJfcEIHAadODryKRgvwuVUbXh=""
   for i in mlNpiQJfcEIHAadODryKRgvwuVUbjP(0,num):
    s=mlNpiQJfcEIHAadODryKRgvwuVUbjY(randint(1,5))
    mlNpiQJfcEIHAadODryKRgvwuVUbXh+=s
   return mlNpiQJfcEIHAadODryKRgvwuVUbXh
  if guidType==3:
   mlNpiQJfcEIHAadODryKRgvwuVUbXB=guid_str
  else:
   mlNpiQJfcEIHAadODryKRgvwuVUbXB=GenerateID(guid_str)
  mlNpiQJfcEIHAadODryKRgvwuVUbXS=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetHash(mlNpiQJfcEIHAadODryKRgvwuVUbXB)
  if guidType in[2,3]:
   mlNpiQJfcEIHAadODryKRgvwuVUbXS='%s-%s-%s-%s-%s'%(mlNpiQJfcEIHAadODryKRgvwuVUbXS[:8],mlNpiQJfcEIHAadODryKRgvwuVUbXS[8:12],mlNpiQJfcEIHAadODryKRgvwuVUbXS[12:16],mlNpiQJfcEIHAadODryKRgvwuVUbXS[16:20],mlNpiQJfcEIHAadODryKRgvwuVUbXS[20:])
  return mlNpiQJfcEIHAadODryKRgvwuVUbXS
 def GetHash(mlNpiQJfcEIHAadODryKRgvwuVUbXC,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return mlNpiQJfcEIHAadODryKRgvwuVUbjY(m.hexdigest())
 def CheckQuality(mlNpiQJfcEIHAadODryKRgvwuVUbXC,sel_qt,qt_list):
  mlNpiQJfcEIHAadODryKRgvwuVUbXF=0
  for mlNpiQJfcEIHAadODryKRgvwuVUbXT in qt_list:
   if sel_qt>=mlNpiQJfcEIHAadODryKRgvwuVUbXT:return mlNpiQJfcEIHAadODryKRgvwuVUbXT
   mlNpiQJfcEIHAadODryKRgvwuVUbXF=mlNpiQJfcEIHAadODryKRgvwuVUbXT
  return mlNpiQJfcEIHAadODryKRgvwuVUbXF
 def Get_Now_Datetime(mlNpiQJfcEIHAadODryKRgvwuVUbXC):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbXC,in_text):
  mlNpiQJfcEIHAadODryKRgvwuVUbXk=in_text.replace('&lt;','<').replace('&gt;','>')
  mlNpiQJfcEIHAadODryKRgvwuVUbXk=mlNpiQJfcEIHAadODryKRgvwuVUbXk.replace('<br>','\n')
  mlNpiQJfcEIHAadODryKRgvwuVUbXk=mlNpiQJfcEIHAadODryKRgvwuVUbXk.replace('$O$','')
  mlNpiQJfcEIHAadODryKRgvwuVUbXk=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',mlNpiQJfcEIHAadODryKRgvwuVUbXk)
  mlNpiQJfcEIHAadODryKRgvwuVUbXk=mlNpiQJfcEIHAadODryKRgvwuVUbXk.lstrip('#')
  return mlNpiQJfcEIHAadODryKRgvwuVUbXk
 def make_str_ToCookie(mlNpiQJfcEIHAadODryKRgvwuVUbXC,cookieStr):
  mlNpiQJfcEIHAadODryKRgvwuVUbXn={}
  for mlNpiQJfcEIHAadODryKRgvwuVUbPX in cookieStr.split(';'):
   mlNpiQJfcEIHAadODryKRgvwuVUbPY=mlNpiQJfcEIHAadODryKRgvwuVUbPX.split('=')
   mlNpiQJfcEIHAadODryKRgvwuVUbXn[mlNpiQJfcEIHAadODryKRgvwuVUbPY[0]]=mlNpiQJfcEIHAadODryKRgvwuVUbPY[1]
  return mlNpiQJfcEIHAadODryKRgvwuVUbXn 
 def make_stream_header(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbPj,mlNpiQJfcEIHAadODryKRgvwuVUbXn):
  mlNpiQJfcEIHAadODryKRgvwuVUbPC=''
  if mlNpiQJfcEIHAadODryKRgvwuVUbXn not in[{},mlNpiQJfcEIHAadODryKRgvwuVUbsL,'']:
   mlNpiQJfcEIHAadODryKRgvwuVUbPG=mlNpiQJfcEIHAadODryKRgvwuVUbjC(mlNpiQJfcEIHAadODryKRgvwuVUbXn)
   for mlNpiQJfcEIHAadODryKRgvwuVUbPt,mlNpiQJfcEIHAadODryKRgvwuVUbPs in mlNpiQJfcEIHAadODryKRgvwuVUbXn.items():
    mlNpiQJfcEIHAadODryKRgvwuVUbPC+='{}={}'.format(mlNpiQJfcEIHAadODryKRgvwuVUbPt,mlNpiQJfcEIHAadODryKRgvwuVUbPs)
    mlNpiQJfcEIHAadODryKRgvwuVUbPG+=-1
    if mlNpiQJfcEIHAadODryKRgvwuVUbPG>0:mlNpiQJfcEIHAadODryKRgvwuVUbPC+='; '
   mlNpiQJfcEIHAadODryKRgvwuVUbPj['cookie']=mlNpiQJfcEIHAadODryKRgvwuVUbPC
  mlNpiQJfcEIHAadODryKRgvwuVUbPz=''
  i=0
  for mlNpiQJfcEIHAadODryKRgvwuVUbPt,mlNpiQJfcEIHAadODryKRgvwuVUbPs in mlNpiQJfcEIHAadODryKRgvwuVUbPj.items():
   i=i+1
   if i>1:mlNpiQJfcEIHAadODryKRgvwuVUbPz+='&'
   mlNpiQJfcEIHAadODryKRgvwuVUbPz+='{}={}'.format(mlNpiQJfcEIHAadODryKRgvwuVUbPt,urllib.parse.quote(mlNpiQJfcEIHAadODryKRgvwuVUbPs))
  return mlNpiQJfcEIHAadODryKRgvwuVUbPz
 def GetCredential(mlNpiQJfcEIHAadODryKRgvwuVUbXC,user_id,user_pw,user_pf):
  mlNpiQJfcEIHAadODryKRgvwuVUbPe=mlNpiQJfcEIHAadODryKRgvwuVUbsk
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+ '/login'
   mlNpiQJfcEIHAadODryKRgvwuVUbXM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk)
   mlNpiQJfcEIHAadODryKRgvwuVUbPo={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Post',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbPo,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['cookies']['credential']=mlNpiQJfcEIHAadODryKRgvwuVUbPq['credential']
   if user_pf!=0:
    mlNpiQJfcEIHAadODryKRgvwuVUbPo={'id':mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['cookies']['credential'],'password':'','profile':mlNpiQJfcEIHAadODryKRgvwuVUbjY(user_pf),'pushid':'','type':'credential'}
    mlNpiQJfcEIHAadODryKRgvwuVUbXM =mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbjX) 
    mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Post',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbPo,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
    mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
    mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['cookies']['credential']=mlNpiQJfcEIHAadODryKRgvwuVUbPq['credential']
   mlNpiQJfcEIHAadODryKRgvwuVUbPx=user_id+mlNpiQJfcEIHAadODryKRgvwuVUbjY(user_pf) 
   mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['cookies']['uuid']=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetGUID(guid_str=mlNpiQJfcEIHAadODryKRgvwuVUbPx,guidType=3)
   mlNpiQJfcEIHAadODryKRgvwuVUbPe=mlNpiQJfcEIHAadODryKRgvwuVUbjX
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   mlNpiQJfcEIHAadODryKRgvwuVUbXC.Init_WV_Total()
  return mlNpiQJfcEIHAadODryKRgvwuVUbPe
 def GetIssue(mlNpiQJfcEIHAadODryKRgvwuVUbXC):
  mlNpiQJfcEIHAadODryKRgvwuVUbPB=mlNpiQJfcEIHAadODryKRgvwuVUbsk
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/guid/issue'
   mlNpiQJfcEIHAadODryKRgvwuVUbXM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams()
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   mlNpiQJfcEIHAadODryKRgvwuVUbPh=mlNpiQJfcEIHAadODryKRgvwuVUbPq['guid']
   mlNpiQJfcEIHAadODryKRgvwuVUbPS=mlNpiQJfcEIHAadODryKRgvwuVUbPq['guidtimestamp']
   if mlNpiQJfcEIHAadODryKRgvwuVUbPh:mlNpiQJfcEIHAadODryKRgvwuVUbPB=mlNpiQJfcEIHAadODryKRgvwuVUbjX
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   mlNpiQJfcEIHAadODryKRgvwuVUbPh='none'
   mlNpiQJfcEIHAadODryKRgvwuVUbPS='none' 
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.guid=mlNpiQJfcEIHAadODryKRgvwuVUbPh
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.guidtimestamp=mlNpiQJfcEIHAadODryKRgvwuVUbPS
  return mlNpiQJfcEIHAadODryKRgvwuVUbPB
 def Baseapi_Parse(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbPk):
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPF =urllib.parse.urlsplit(mlNpiQJfcEIHAadODryKRgvwuVUbPk)
   if mlNpiQJfcEIHAadODryKRgvwuVUbPF.netloc=='':
    mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.HTTPTAG+mlNpiQJfcEIHAadODryKRgvwuVUbPF.netloc+mlNpiQJfcEIHAadODryKRgvwuVUbPF.path
   else:
    mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbPF.scheme+'://'+mlNpiQJfcEIHAadODryKRgvwuVUbPF.netloc+mlNpiQJfcEIHAadODryKRgvwuVUbPF.path
   mlNpiQJfcEIHAadODryKRgvwuVUbXM=mlNpiQJfcEIHAadODryKRgvwuVUbjs(urllib.parse.parse_qsl(mlNpiQJfcEIHAadODryKRgvwuVUbPF.query))
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return '',{}
  return mlNpiQJfcEIHAadODryKRgvwuVUbPW,mlNpiQJfcEIHAadODryKRgvwuVUbXM
 def GetSupermultiUrl(mlNpiQJfcEIHAadODryKRgvwuVUbXC,sCode,sIndex='0'):
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/cf/supermultisections/'+sCode
   mlNpiQJfcEIHAadODryKRgvwuVUbXM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk)
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   mlNpiQJfcEIHAadODryKRgvwuVUbPT=mlNpiQJfcEIHAadODryKRgvwuVUbPq['multisectionlist'][mlNpiQJfcEIHAadODryKRgvwuVUbjz(sIndex)]['eventlist'][1]['url']
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return ''
  return mlNpiQJfcEIHAadODryKRgvwuVUbPT
 def Get_LiveCatagory_List(mlNpiQJfcEIHAadODryKRgvwuVUbXC,sCode,sIndex='0'):
  mlNpiQJfcEIHAadODryKRgvwuVUbPL=[]
  mlNpiQJfcEIHAadODryKRgvwuVUbPk =mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetSupermultiUrl(sCode,sIndex)
  (mlNpiQJfcEIHAadODryKRgvwuVUbPW,mlNpiQJfcEIHAadODryKRgvwuVUbXM)=mlNpiQJfcEIHAadODryKRgvwuVUbXC.Baseapi_Parse(mlNpiQJfcEIHAadODryKRgvwuVUbPk)
  if mlNpiQJfcEIHAadODryKRgvwuVUbPW=='':return mlNpiQJfcEIHAadODryKRgvwuVUbPL,''
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if not('filter_item_list' in mlNpiQJfcEIHAadODryKRgvwuVUbPq['filter']['filterlist'][0]):return[],''
   mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['filter']['filterlist'][0]['filter_item_list']
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbYX:
    mlNpiQJfcEIHAadODryKRgvwuVUbYC={'title':mlNpiQJfcEIHAadODryKRgvwuVUbYP['title'],'genre':mlNpiQJfcEIHAadODryKRgvwuVUbYP['api_parameters'][mlNpiQJfcEIHAadODryKRgvwuVUbYP['api_parameters'].index('=')+1:]}
    mlNpiQJfcEIHAadODryKRgvwuVUbPL.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[],''
  return mlNpiQJfcEIHAadODryKRgvwuVUbPL,mlNpiQJfcEIHAadODryKRgvwuVUbPk
 def Get_MainCatagory_List(mlNpiQJfcEIHAadODryKRgvwuVUbXC,sCode,sIndex,sType):
  mlNpiQJfcEIHAadODryKRgvwuVUbPL=[]
  mlNpiQJfcEIHAadODryKRgvwuVUbPW='https://apis.wavve.com/es/category/launcher-band'
  mlNpiQJfcEIHAadODryKRgvwuVUbXM={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if not('celllist' in mlNpiQJfcEIHAadODryKRgvwuVUbPq['band']):return[]
   mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['band']['celllist']
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbYX:
    mlNpiQJfcEIHAadODryKRgvwuVUbYG =mlNpiQJfcEIHAadODryKRgvwuVUbYP['event_list'][1]['url']
    (mlNpiQJfcEIHAadODryKRgvwuVUbYt,mlNpiQJfcEIHAadODryKRgvwuVUbYs)=mlNpiQJfcEIHAadODryKRgvwuVUbXC.Baseapi_Parse(mlNpiQJfcEIHAadODryKRgvwuVUbYG)
    mlNpiQJfcEIHAadODryKRgvwuVUbYC={'title':mlNpiQJfcEIHAadODryKRgvwuVUbYP['title_list'][0]['text'],'suburl':mlNpiQJfcEIHAadODryKRgvwuVUbYt,'subapi':mlNpiQJfcEIHAadODryKRgvwuVUbYs.get('api'),'subtype':'catagory' if mlNpiQJfcEIHAadODryKRgvwuVUbYs else 'supersection'}
    mlNpiQJfcEIHAadODryKRgvwuVUbPL.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[]
  return mlNpiQJfcEIHAadODryKRgvwuVUbPL
 def Get_SuperMultiSection_List(mlNpiQJfcEIHAadODryKRgvwuVUbXC,subapi_text):
  mlNpiQJfcEIHAadODryKRgvwuVUbPL=[]
  if '/multiband/' in subapi_text: 
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=subapi_text 
   mlNpiQJfcEIHAadODryKRgvwuVUbXM={'client':'40'}
  else:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=subapi_text 
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbPW.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   mlNpiQJfcEIHAadODryKRgvwuVUbXM={}
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if not('multisectionlist' in mlNpiQJfcEIHAadODryKRgvwuVUbPq):return[]
   mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['multisectionlist']
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbYX:
    mlNpiQJfcEIHAadODryKRgvwuVUbYj=mlNpiQJfcEIHAadODryKRgvwuVUbYP['title']
    if mlNpiQJfcEIHAadODryKRgvwuVUbjC(mlNpiQJfcEIHAadODryKRgvwuVUbYj)==0:continue
    if mlNpiQJfcEIHAadODryKRgvwuVUbYj=='minor':continue
    if re.search(u'베너',mlNpiQJfcEIHAadODryKRgvwuVUbYj):continue
    if re.search(u'배너',mlNpiQJfcEIHAadODryKRgvwuVUbYj):continue 
    if mlNpiQJfcEIHAadODryKRgvwuVUbYP['force_refresh']=='y':continue
    if mlNpiQJfcEIHAadODryKRgvwuVUbjC(mlNpiQJfcEIHAadODryKRgvwuVUbYP['eventlist'])>=3:
     mlNpiQJfcEIHAadODryKRgvwuVUbYs =mlNpiQJfcEIHAadODryKRgvwuVUbYP['eventlist'][2]['url']
    else:
     mlNpiQJfcEIHAadODryKRgvwuVUbYs =mlNpiQJfcEIHAadODryKRgvwuVUbYP['eventlist'][1]['url']
    mlNpiQJfcEIHAadODryKRgvwuVUbYz=mlNpiQJfcEIHAadODryKRgvwuVUbYP['cell_type']
    if mlNpiQJfcEIHAadODryKRgvwuVUbYz=='band_2':
     if mlNpiQJfcEIHAadODryKRgvwuVUbYs.find('channellist=')>=0:
      mlNpiQJfcEIHAadODryKRgvwuVUbYz='band_live'
    mlNpiQJfcEIHAadODryKRgvwuVUbYC={'title':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbYj),'subapi':mlNpiQJfcEIHAadODryKRgvwuVUbYs,'cell_type':mlNpiQJfcEIHAadODryKRgvwuVUbYz}
    mlNpiQJfcEIHAadODryKRgvwuVUbPL.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[]
  return mlNpiQJfcEIHAadODryKRgvwuVUbPL
 def Get_BandLiveSection_List(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbPk,page_int=1):
  mlNpiQJfcEIHAadODryKRgvwuVUbYe=[]
  mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbYh=1
  mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbsk
  try:
   (mlNpiQJfcEIHAadODryKRgvwuVUbPW,mlNpiQJfcEIHAadODryKRgvwuVUbXM)=mlNpiQJfcEIHAadODryKRgvwuVUbXC.Baseapi_Parse(mlNpiQJfcEIHAadODryKRgvwuVUbPk)
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[],mlNpiQJfcEIHAadODryKRgvwuVUbsk
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbXM['limit']=mlNpiQJfcEIHAadODryKRgvwuVUbXC.LIST_LIMIT
   mlNpiQJfcEIHAadODryKRgvwuVUbXM['offset']=mlNpiQJfcEIHAadODryKRgvwuVUbjY((page_int-1)*mlNpiQJfcEIHAadODryKRgvwuVUbXC.LIST_LIMIT)
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if not('celllist' in mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']):return[],mlNpiQJfcEIHAadODryKRgvwuVUbsk
   mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['celllist']
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbYX:
    mlNpiQJfcEIHAadODryKRgvwuVUbYM =mlNpiQJfcEIHAadODryKRgvwuVUbYP['event_list'][1]['url']
    mlNpiQJfcEIHAadODryKRgvwuVUbYq=urllib.parse.urlsplit(mlNpiQJfcEIHAadODryKRgvwuVUbYM).query
    mlNpiQJfcEIHAadODryKRgvwuVUbYq=mlNpiQJfcEIHAadODryKRgvwuVUbjs(urllib.parse.parse_qsl(mlNpiQJfcEIHAadODryKRgvwuVUbYq))
    mlNpiQJfcEIHAadODryKRgvwuVUbYx='channelid'
    mlNpiQJfcEIHAadODryKRgvwuVUbYB=mlNpiQJfcEIHAadODryKRgvwuVUbYq[mlNpiQJfcEIHAadODryKRgvwuVUbYx]
    mlNpiQJfcEIHAadODryKRgvwuVUbYC={'studio':mlNpiQJfcEIHAadODryKRgvwuVUbYP['title_list'][0]['text'],'tvshowtitle':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbYP['title_list'][1]['text']),'channelid':mlNpiQJfcEIHAadODryKRgvwuVUbYB,'age':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('age'),'thumbnail':'https://%s'%mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('thumbnail')}
    mlNpiQJfcEIHAadODryKRgvwuVUbYe.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
   mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['pagecount'])
   if mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['count']:mlNpiQJfcEIHAadODryKRgvwuVUbYh =mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['count'])
   else:mlNpiQJfcEIHAadODryKRgvwuVUbYh=mlNpiQJfcEIHAadODryKRgvwuVUbXC.LIST_LIMIT*page_int
   mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbYW>mlNpiQJfcEIHAadODryKRgvwuVUbYh
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[],mlNpiQJfcEIHAadODryKRgvwuVUbsk
  return mlNpiQJfcEIHAadODryKRgvwuVUbYe,mlNpiQJfcEIHAadODryKRgvwuVUbYo
 def Get_Band2Section_List(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbPk,page_int=1):
  mlNpiQJfcEIHAadODryKRgvwuVUbYS=[]
  mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbYh=1
  mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbsk
  try:
   (mlNpiQJfcEIHAadODryKRgvwuVUbPW,mlNpiQJfcEIHAadODryKRgvwuVUbXM)=mlNpiQJfcEIHAadODryKRgvwuVUbXC.Baseapi_Parse(mlNpiQJfcEIHAadODryKRgvwuVUbPk)
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[],mlNpiQJfcEIHAadODryKRgvwuVUbsk
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbXM['came'] ='BandView'
   mlNpiQJfcEIHAadODryKRgvwuVUbXM['limit']=mlNpiQJfcEIHAadODryKRgvwuVUbXC.LIST_LIMIT
   mlNpiQJfcEIHAadODryKRgvwuVUbXM['offset']=mlNpiQJfcEIHAadODryKRgvwuVUbjY((page_int-1)*mlNpiQJfcEIHAadODryKRgvwuVUbXC.LIST_LIMIT)
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if not('celllist' in mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']):return[],mlNpiQJfcEIHAadODryKRgvwuVUbsk
   mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['celllist']
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbYX:
    mlNpiQJfcEIHAadODryKRgvwuVUbYM =mlNpiQJfcEIHAadODryKRgvwuVUbYP['event_list'][1]['url']
    mlNpiQJfcEIHAadODryKRgvwuVUbYq=urllib.parse.urlsplit(mlNpiQJfcEIHAadODryKRgvwuVUbYM).query
    mlNpiQJfcEIHAadODryKRgvwuVUbYq=mlNpiQJfcEIHAadODryKRgvwuVUbjs(urllib.parse.parse_qsl(mlNpiQJfcEIHAadODryKRgvwuVUbYq))
    mlNpiQJfcEIHAadODryKRgvwuVUbYx='contentid'
    mlNpiQJfcEIHAadODryKRgvwuVUbYB=mlNpiQJfcEIHAadODryKRgvwuVUbYq[mlNpiQJfcEIHAadODryKRgvwuVUbYx]
    mlNpiQJfcEIHAadODryKRgvwuVUbYC={'programtitle':mlNpiQJfcEIHAadODryKRgvwuVUbYP['title_list'][0]['text'],'episodetitle':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbYP['title_list'][1]['text']),'age':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('age'),'thumbnail':mlNpiQJfcEIHAadODryKRgvwuVUbXC.HTTPTAG+mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('thumbnail'),'vidtype':mlNpiQJfcEIHAadODryKRgvwuVUbYx,'videoid':mlNpiQJfcEIHAadODryKRgvwuVUbYB}
    mlNpiQJfcEIHAadODryKRgvwuVUbYS.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
   mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['pagecount'])
   if mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['count']:mlNpiQJfcEIHAadODryKRgvwuVUbYh =mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['count'])
   else:mlNpiQJfcEIHAadODryKRgvwuVUbYh=mlNpiQJfcEIHAadODryKRgvwuVUbXC.LIST_LIMIT*page_int
   mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbYW>mlNpiQJfcEIHAadODryKRgvwuVUbYh
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[],mlNpiQJfcEIHAadODryKRgvwuVUbsk
  return mlNpiQJfcEIHAadODryKRgvwuVUbYS,mlNpiQJfcEIHAadODryKRgvwuVUbYo
 def Get_Program_List(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbPk,page_int=1,orderby='-'):
  mlNpiQJfcEIHAadODryKRgvwuVUbYF=[]
  mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbYh=1
  mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbsk
  (mlNpiQJfcEIHAadODryKRgvwuVUbPW,mlNpiQJfcEIHAadODryKRgvwuVUbXM)=mlNpiQJfcEIHAadODryKRgvwuVUbXC.Baseapi_Parse(mlNpiQJfcEIHAadODryKRgvwuVUbPk)
  if mlNpiQJfcEIHAadODryKRgvwuVUbPW=='':return mlNpiQJfcEIHAadODryKRgvwuVUbYF,mlNpiQJfcEIHAadODryKRgvwuVUbYo
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbXM['limit'] =mlNpiQJfcEIHAadODryKRgvwuVUbXC.LIST_LIMIT
   mlNpiQJfcEIHAadODryKRgvwuVUbXM['offset']=mlNpiQJfcEIHAadODryKRgvwuVUbjY((page_int-1)*mlNpiQJfcEIHAadODryKRgvwuVUbXC.LIST_LIMIT)
   mlNpiQJfcEIHAadODryKRgvwuVUbXM['page'] =mlNpiQJfcEIHAadODryKRgvwuVUbjY(page_int)
   if mlNpiQJfcEIHAadODryKRgvwuVUbXM.get('orderby')!='' and mlNpiQJfcEIHAadODryKRgvwuVUbXM.get('orderby')!='regdatefirst' and orderby!='-':
    mlNpiQJfcEIHAadODryKRgvwuVUbXM['orderby']=orderby 
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if mlNpiQJfcEIHAadODryKRgvwuVUbPq.get('cell_toplist')not in[{},mlNpiQJfcEIHAadODryKRgvwuVUbsL,'']:
    mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['celllist']
   elif mlNpiQJfcEIHAadODryKRgvwuVUbPq.get('band')not in[{},mlNpiQJfcEIHAadODryKRgvwuVUbsL,'']:
    mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['band']['celllist']
   else:
    return mlNpiQJfcEIHAadODryKRgvwuVUbYF,mlNpiQJfcEIHAadODryKRgvwuVUbYo
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbYX:
    for mlNpiQJfcEIHAadODryKRgvwuVUbYT in mlNpiQJfcEIHAadODryKRgvwuVUbYP['event_list']:
     if mlNpiQJfcEIHAadODryKRgvwuVUbYT.get('type')=='on-navigation':
      mlNpiQJfcEIHAadODryKRgvwuVUbYM =mlNpiQJfcEIHAadODryKRgvwuVUbYT['url']
    mlNpiQJfcEIHAadODryKRgvwuVUbYq=urllib.parse.urlsplit(mlNpiQJfcEIHAadODryKRgvwuVUbYM).query
    mlNpiQJfcEIHAadODryKRgvwuVUbYx=mlNpiQJfcEIHAadODryKRgvwuVUbYq[0:mlNpiQJfcEIHAadODryKRgvwuVUbYq.find('=')]
    mlNpiQJfcEIHAadODryKRgvwuVUbYL=mlNpiQJfcEIHAadODryKRgvwuVUbjs(urllib.parse.parse_qsl(mlNpiQJfcEIHAadODryKRgvwuVUbYq))
    mlNpiQJfcEIHAadODryKRgvwuVUbYB=mlNpiQJfcEIHAadODryKRgvwuVUbYL.get(mlNpiQJfcEIHAadODryKRgvwuVUbYx)
    mlNpiQJfcEIHAadODryKRgvwuVUbYC={'title':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('alt')or mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('title_list')[0].get('text'),'age':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('age'),'thumbnail':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('thumbnail'),'videoid':mlNpiQJfcEIHAadODryKRgvwuVUbYB,'vidtype':mlNpiQJfcEIHAadODryKRgvwuVUbYx,}
    if not mlNpiQJfcEIHAadODryKRgvwuVUbYC.get('thumbnail').startswith('http'):
     mlNpiQJfcEIHAadODryKRgvwuVUbYC['thumbnail']='https://%s'%mlNpiQJfcEIHAadODryKRgvwuVUbYC['thumbnail']
    mlNpiQJfcEIHAadODryKRgvwuVUbYF.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
   if mlNpiQJfcEIHAadODryKRgvwuVUbPq.get('cell_toplist')not in[{},mlNpiQJfcEIHAadODryKRgvwuVUbsL,'']:
    mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['pagecount'])
    if mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['count']:mlNpiQJfcEIHAadODryKRgvwuVUbYh =mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['count'])
    else:mlNpiQJfcEIHAadODryKRgvwuVUbYh=mlNpiQJfcEIHAadODryKRgvwuVUbXC.LIST_LIMIT*page_int
    mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbYW>mlNpiQJfcEIHAadODryKRgvwuVUbYh
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[],mlNpiQJfcEIHAadODryKRgvwuVUbsk
  return mlNpiQJfcEIHAadODryKRgvwuVUbYF,mlNpiQJfcEIHAadODryKRgvwuVUbYo
 def Get_Movie_List(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbPk,page_int=1,orderby='-'):
  mlNpiQJfcEIHAadODryKRgvwuVUbYk=[]
  mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbYh=1
  mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbsk
  (mlNpiQJfcEIHAadODryKRgvwuVUbPW,mlNpiQJfcEIHAadODryKRgvwuVUbXM)=mlNpiQJfcEIHAadODryKRgvwuVUbXC.Baseapi_Parse(mlNpiQJfcEIHAadODryKRgvwuVUbPk)
  if mlNpiQJfcEIHAadODryKRgvwuVUbPW=='':return mlNpiQJfcEIHAadODryKRgvwuVUbYk,mlNpiQJfcEIHAadODryKRgvwuVUbYo
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbXM['limit']=mlNpiQJfcEIHAadODryKRgvwuVUbXC.MV_LIMIT
   mlNpiQJfcEIHAadODryKRgvwuVUbXM['offset']=mlNpiQJfcEIHAadODryKRgvwuVUbjY((page_int-1)*mlNpiQJfcEIHAadODryKRgvwuVUbXC.MV_LIMIT)
   if mlNpiQJfcEIHAadODryKRgvwuVUbXM.get('orderby')!='' and mlNpiQJfcEIHAadODryKRgvwuVUbXM.get('orderby')!='regdatefirst' and orderby!='-':
    mlNpiQJfcEIHAadODryKRgvwuVUbXM['orderby']=orderby 
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if mlNpiQJfcEIHAadODryKRgvwuVUbPq.get('cell_toplist')not in[{},mlNpiQJfcEIHAadODryKRgvwuVUbsL,'']:
    mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['celllist']
   elif mlNpiQJfcEIHAadODryKRgvwuVUbPq.get('band')not in[{},mlNpiQJfcEIHAadODryKRgvwuVUbsL,'']:
    mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['band']['celllist']
   else:
    return mlNpiQJfcEIHAadODryKRgvwuVUbYk,mlNpiQJfcEIHAadODryKRgvwuVUbYo
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbYX:
    mlNpiQJfcEIHAadODryKRgvwuVUbYM =mlNpiQJfcEIHAadODryKRgvwuVUbYP['event_list'][1]['url']
    mlNpiQJfcEIHAadODryKRgvwuVUbYq=urllib.parse.urlsplit(mlNpiQJfcEIHAadODryKRgvwuVUbYM).query
    mlNpiQJfcEIHAadODryKRgvwuVUbYx=mlNpiQJfcEIHAadODryKRgvwuVUbYq[0:mlNpiQJfcEIHAadODryKRgvwuVUbYq.find('=')]
    mlNpiQJfcEIHAadODryKRgvwuVUbYL=mlNpiQJfcEIHAadODryKRgvwuVUbjs(urllib.parse.parse_qsl(mlNpiQJfcEIHAadODryKRgvwuVUbYq))
    mlNpiQJfcEIHAadODryKRgvwuVUbYB=mlNpiQJfcEIHAadODryKRgvwuVUbYL.get(mlNpiQJfcEIHAadODryKRgvwuVUbYx)
    mlNpiQJfcEIHAadODryKRgvwuVUbYC={'title':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('alt')or mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('title_list')[0].get('text'),'age':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('age'),'thumbnail':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('thumbnail'),'videoid':mlNpiQJfcEIHAadODryKRgvwuVUbYB,'vidtype':mlNpiQJfcEIHAadODryKRgvwuVUbYx,}
    if not mlNpiQJfcEIHAadODryKRgvwuVUbYC.get('thumbnail').startswith('http'):
     mlNpiQJfcEIHAadODryKRgvwuVUbYC['thumbnail']='https://%s'%mlNpiQJfcEIHAadODryKRgvwuVUbYC['thumbnail']
    mlNpiQJfcEIHAadODryKRgvwuVUbYk.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
   if mlNpiQJfcEIHAadODryKRgvwuVUbPq.get('cell_toplist')not in[{},mlNpiQJfcEIHAadODryKRgvwuVUbsL,'']:
    mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['pagecount'])
    if mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['count']:mlNpiQJfcEIHAadODryKRgvwuVUbYh =mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['count'])
    else:mlNpiQJfcEIHAadODryKRgvwuVUbYh=mlNpiQJfcEIHAadODryKRgvwuVUbXC.MV_LIMIT*page_int
    mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbYW>mlNpiQJfcEIHAadODryKRgvwuVUbYh
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[],mlNpiQJfcEIHAadODryKRgvwuVUbsk
  return mlNpiQJfcEIHAadODryKRgvwuVUbYk,mlNpiQJfcEIHAadODryKRgvwuVUbYo
 def ProgramidToContentid(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbCP):
  mlNpiQJfcEIHAadODryKRgvwuVUbYn=''
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW =mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/vod/programs-contentid/'+mlNpiQJfcEIHAadODryKRgvwuVUbCP
   mlNpiQJfcEIHAadODryKRgvwuVUbXM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk)
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbCX=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if not('contentid' in mlNpiQJfcEIHAadODryKRgvwuVUbCX):return mlNpiQJfcEIHAadODryKRgvwuVUbYn 
   mlNpiQJfcEIHAadODryKRgvwuVUbYn=mlNpiQJfcEIHAadODryKRgvwuVUbCX['contentid']
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
  return mlNpiQJfcEIHAadODryKRgvwuVUbYn
 def ContentidToSeasonid(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbYn):
  mlNpiQJfcEIHAadODryKRgvwuVUbCP=''
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW =mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/fz/vod/contents/'+mlNpiQJfcEIHAadODryKRgvwuVUbYn
   mlNpiQJfcEIHAadODryKRgvwuVUbXM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk)
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbCX=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if not('programid' in mlNpiQJfcEIHAadODryKRgvwuVUbCX):return mlNpiQJfcEIHAadODryKRgvwuVUbCP 
   mlNpiQJfcEIHAadODryKRgvwuVUbCP=mlNpiQJfcEIHAadODryKRgvwuVUbCX['programid']
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
  return mlNpiQJfcEIHAadODryKRgvwuVUbCP
 def GetProgramInfo(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbYn):
  mlNpiQJfcEIHAadODryKRgvwuVUbCY={}
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/fz/vod/contents/'+mlNpiQJfcEIHAadODryKRgvwuVUbYn
   mlNpiQJfcEIHAadODryKRgvwuVUbXM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk)
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbCX=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   mlNpiQJfcEIHAadODryKRgvwuVUbCG=img_fanart=mlNpiQJfcEIHAadODryKRgvwuVUbCt=''
   if mlNpiQJfcEIHAadODryKRgvwuVUbCX.get('programposterimage')!='':mlNpiQJfcEIHAadODryKRgvwuVUbCG =mlNpiQJfcEIHAadODryKRgvwuVUbXC.HTTPTAG+mlNpiQJfcEIHAadODryKRgvwuVUbCX.get('programposterimage')
   if mlNpiQJfcEIHAadODryKRgvwuVUbCX.get('programimage') !='':img_fanart =mlNpiQJfcEIHAadODryKRgvwuVUbXC.HTTPTAG+mlNpiQJfcEIHAadODryKRgvwuVUbCX.get('programimage')
   if mlNpiQJfcEIHAadODryKRgvwuVUbCX.get('programcircleimage')!='':mlNpiQJfcEIHAadODryKRgvwuVUbCt=mlNpiQJfcEIHAadODryKRgvwuVUbXC.HTTPTAG+mlNpiQJfcEIHAadODryKRgvwuVUbCX.get('programcircleimage')
   if 'poster_default' in mlNpiQJfcEIHAadODryKRgvwuVUbCG:
    mlNpiQJfcEIHAadODryKRgvwuVUbCG =img_fanart
    mlNpiQJfcEIHAadODryKRgvwuVUbCt=''
   mlNpiQJfcEIHAadODryKRgvwuVUbCY={'imgPoster':mlNpiQJfcEIHAadODryKRgvwuVUbCG,'imgFanart':img_fanart,'imgClearlogo':mlNpiQJfcEIHAadODryKRgvwuVUbCt,'programtitle':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbCX.get('programtitle')),'programid':mlNpiQJfcEIHAadODryKRgvwuVUbCX.get('programid'),'synopsis':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbCX.get('programsynopsis')),}
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
  return mlNpiQJfcEIHAadODryKRgvwuVUbCY
 def Get_Season_List(mlNpiQJfcEIHAadODryKRgvwuVUbXC,seasonid):
  mlNpiQJfcEIHAadODryKRgvwuVUbCs=[]
  mlNpiQJfcEIHAadODryKRgvwuVUbYn=mlNpiQJfcEIHAadODryKRgvwuVUbXC.ProgramidToContentid(seasonid)
  mlNpiQJfcEIHAadODryKRgvwuVUbCj=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetProgramInfo(mlNpiQJfcEIHAadODryKRgvwuVUbYn)
  mlNpiQJfcEIHAadODryKRgvwuVUbCz={'poster':mlNpiQJfcEIHAadODryKRgvwuVUbCj.get('imgPoster'),'fanart':mlNpiQJfcEIHAadODryKRgvwuVUbCj.get('imgFanart'),'clearlogo':mlNpiQJfcEIHAadODryKRgvwuVUbCj.get('imgClearlogo'),}
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   mlNpiQJfcEIHAadODryKRgvwuVUbXM={'limit':'10','offset':'0','orderby':'new',}
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   for mlNpiQJfcEIHAadODryKRgvwuVUbCe in mlNpiQJfcEIHAadODryKRgvwuVUbPq['filter']['filterlist'][0]['filter_item_list']:
    mlNpiQJfcEIHAadODryKRgvwuVUbYC={'season_Nm':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbCe.get('title')),'season_Id':mlNpiQJfcEIHAadODryKRgvwuVUbCe.get('api_path'),'thumbnail':mlNpiQJfcEIHAadODryKRgvwuVUbCz,'programNm':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbCj.get('programtitle')),'synopsis':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbCj.get('synopsis')),}
    mlNpiQJfcEIHAadODryKRgvwuVUbCs.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[]
  return mlNpiQJfcEIHAadODryKRgvwuVUbCs
 def Get_Episode_List(mlNpiQJfcEIHAadODryKRgvwuVUbXC,seasionid,page_int=1,orderby='desc'):
  mlNpiQJfcEIHAadODryKRgvwuVUbCW=[]
  mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbYh=1
  mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbsk
  mlNpiQJfcEIHAadODryKRgvwuVUbCj={}
  mlNpiQJfcEIHAadODryKRgvwuVUbYn=mlNpiQJfcEIHAadODryKRgvwuVUbXC.ProgramidToContentid(seasionid)
  mlNpiQJfcEIHAadODryKRgvwuVUbCj=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetProgramInfo(mlNpiQJfcEIHAadODryKRgvwuVUbYn)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   mlNpiQJfcEIHAadODryKRgvwuVUbXM={'limit':mlNpiQJfcEIHAadODryKRgvwuVUbXC.EP_LIMIT,'offset':mlNpiQJfcEIHAadODryKRgvwuVUbjY((page_int-1)*mlNpiQJfcEIHAadODryKRgvwuVUbXC.EP_LIMIT),'orderby':orderby,}
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['celllist']
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbYX:
    mlNpiQJfcEIHAadODryKRgvwuVUbCM=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('synopsis'))
    mlNpiQJfcEIHAadODryKRgvwuVUbCq=mlNpiQJfcEIHAadODryKRgvwuVUbXC.HTTPTAG+mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('thumbnail')
    mlNpiQJfcEIHAadODryKRgvwuVUbCx=mlNpiQJfcEIHAadODryKRgvwuVUbCB=mlNpiQJfcEIHAadODryKRgvwuVUbCh=''
    mlNpiQJfcEIHAadODryKRgvwuVUbCx =mlNpiQJfcEIHAadODryKRgvwuVUbCj.get('imgPoster')
    mlNpiQJfcEIHAadODryKRgvwuVUbCB =mlNpiQJfcEIHAadODryKRgvwuVUbCj.get('imgFanart')
    mlNpiQJfcEIHAadODryKRgvwuVUbCh =mlNpiQJfcEIHAadODryKRgvwuVUbCj.get('imgClearlogo')
    mlNpiQJfcEIHAadODryKRgvwuVUbCS=mlNpiQJfcEIHAadODryKRgvwuVUbCj.get('programtitle')
    mlNpiQJfcEIHAadODryKRgvwuVUbCz={'thumb':mlNpiQJfcEIHAadODryKRgvwuVUbCq,'poster':mlNpiQJfcEIHAadODryKRgvwuVUbCx,'fanart':mlNpiQJfcEIHAadODryKRgvwuVUbCB,'clearlogo':mlNpiQJfcEIHAadODryKRgvwuVUbCh}
    mlNpiQJfcEIHAadODryKRgvwuVUbYC={'programtitle':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbCS),'episodetitle':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbYP['title_list'][0]['text']),'episodenumber':mlNpiQJfcEIHAadODryKRgvwuVUbYP['title_list'][1]['text'].replace('$O$',''),'contentid':mlNpiQJfcEIHAadODryKRgvwuVUbYP['contentid'],'synopsis':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbCM),'episodeactors':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('actors').split(',')if mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('actors')!='' else[],'thumbnail':mlNpiQJfcEIHAadODryKRgvwuVUbCz,}
    mlNpiQJfcEIHAadODryKRgvwuVUbCW.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
   mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['pagecount'])
   if mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['count']:mlNpiQJfcEIHAadODryKRgvwuVUbYh =mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['count'])
   else:mlNpiQJfcEIHAadODryKRgvwuVUbYh=mlNpiQJfcEIHAadODryKRgvwuVUbXC.EP_LIMIT*page_int
   mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbYW>mlNpiQJfcEIHAadODryKRgvwuVUbYh
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[],mlNpiQJfcEIHAadODryKRgvwuVUbsk
  return mlNpiQJfcEIHAadODryKRgvwuVUbCW,mlNpiQJfcEIHAadODryKRgvwuVUbYo
 def GetEPGList(mlNpiQJfcEIHAadODryKRgvwuVUbXC,genre):
  mlNpiQJfcEIHAadODryKRgvwuVUbCF={}
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbCT=mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_Now_Datetime()
   if genre=='all':
    mlNpiQJfcEIHAadODryKRgvwuVUbCL =mlNpiQJfcEIHAadODryKRgvwuVUbCT+datetime.timedelta(hours=3)
   else:
    mlNpiQJfcEIHAadODryKRgvwuVUbCL =mlNpiQJfcEIHAadODryKRgvwuVUbCT+datetime.timedelta(hours=3)
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/live/epgs'
   mlNpiQJfcEIHAadODryKRgvwuVUbXM={'limit':'100','offset':'0','genre':genre,'startdatetime':mlNpiQJfcEIHAadODryKRgvwuVUbCT.strftime('%Y-%m-%d %H:00'),'enddatetime':mlNpiQJfcEIHAadODryKRgvwuVUbCL.strftime('%Y-%m-%d %H:00')}
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   mlNpiQJfcEIHAadODryKRgvwuVUbCk=mlNpiQJfcEIHAadODryKRgvwuVUbPq['list']
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbCk:
    mlNpiQJfcEIHAadODryKRgvwuVUbCn=''
    for mlNpiQJfcEIHAadODryKRgvwuVUbGX in mlNpiQJfcEIHAadODryKRgvwuVUbYP['list']:
     if mlNpiQJfcEIHAadODryKRgvwuVUbCn:mlNpiQJfcEIHAadODryKRgvwuVUbCn+='\n'
     mlNpiQJfcEIHAadODryKRgvwuVUbCn+=mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbGX['title'])+'\n'
     mlNpiQJfcEIHAadODryKRgvwuVUbCn+=' [%s ~ %s]'%(mlNpiQJfcEIHAadODryKRgvwuVUbGX['starttime'][-5:],mlNpiQJfcEIHAadODryKRgvwuVUbGX['endtime'][-5:])+'\n'
    mlNpiQJfcEIHAadODryKRgvwuVUbCF[mlNpiQJfcEIHAadODryKRgvwuVUbYP['channelid']]=mlNpiQJfcEIHAadODryKRgvwuVUbCn
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
  return mlNpiQJfcEIHAadODryKRgvwuVUbCF
 def Get_LiveChannel_List(mlNpiQJfcEIHAadODryKRgvwuVUbXC,genre,mlNpiQJfcEIHAadODryKRgvwuVUbPk):
  mlNpiQJfcEIHAadODryKRgvwuVUbYe=[]
  (mlNpiQJfcEIHAadODryKRgvwuVUbPW,mlNpiQJfcEIHAadODryKRgvwuVUbXM)=mlNpiQJfcEIHAadODryKRgvwuVUbXC.Baseapi_Parse(mlNpiQJfcEIHAadODryKRgvwuVUbPk)
  if mlNpiQJfcEIHAadODryKRgvwuVUbPW=='':return mlNpiQJfcEIHAadODryKRgvwuVUbYe
  mlNpiQJfcEIHAadODryKRgvwuVUbGP=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetEPGList(genre)
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbXM['genre']=genre
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if not('celllist' in mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']):return[]
   mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['celllist']
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbYX:
    mlNpiQJfcEIHAadODryKRgvwuVUbYn=mlNpiQJfcEIHAadODryKRgvwuVUbYP['contentid']
    if mlNpiQJfcEIHAadODryKRgvwuVUbYn in mlNpiQJfcEIHAadODryKRgvwuVUbGP:
     mlNpiQJfcEIHAadODryKRgvwuVUbGY=mlNpiQJfcEIHAadODryKRgvwuVUbGP[mlNpiQJfcEIHAadODryKRgvwuVUbYn]
    else:
     mlNpiQJfcEIHAadODryKRgvwuVUbGY=''
    mlNpiQJfcEIHAadODryKRgvwuVUbYC={'studio':mlNpiQJfcEIHAadODryKRgvwuVUbYP['title_list'][0]['text'],'tvshowtitle':mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbYP['title_list'][1]['text']),'channelid':mlNpiQJfcEIHAadODryKRgvwuVUbYn,'age':mlNpiQJfcEIHAadODryKRgvwuVUbYP['age'],'thumbnail':'https://%s'%mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('thumbnail'),'epg':mlNpiQJfcEIHAadODryKRgvwuVUbGY}
    mlNpiQJfcEIHAadODryKRgvwuVUbYe.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[]
  return mlNpiQJfcEIHAadODryKRgvwuVUbYe
 def Get_Search_List(mlNpiQJfcEIHAadODryKRgvwuVUbXC,search_key,sType,page_int,exclusion21=mlNpiQJfcEIHAadODryKRgvwuVUbsk):
  mlNpiQJfcEIHAadODryKRgvwuVUbGC=[]
  mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbYh=1
  mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbsk
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/fz/search/band.js'
   mlNpiQJfcEIHAadODryKRgvwuVUbXM={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':mlNpiQJfcEIHAadODryKRgvwuVUbjY((page_int-1)*mlNpiQJfcEIHAadODryKRgvwuVUbXC.SEARCH_LIMIT),'limit':mlNpiQJfcEIHAadODryKRgvwuVUbXC.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbCX=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if not('celllist' in mlNpiQJfcEIHAadODryKRgvwuVUbCX['band']):return mlNpiQJfcEIHAadODryKRgvwuVUbGC,mlNpiQJfcEIHAadODryKRgvwuVUbYo
   mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbCX['band']['celllist']
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbYX:
    mlNpiQJfcEIHAadODryKRgvwuVUbYM =mlNpiQJfcEIHAadODryKRgvwuVUbYP['event_list'][1]['url']
    mlNpiQJfcEIHAadODryKRgvwuVUbYq=urllib.parse.urlsplit(mlNpiQJfcEIHAadODryKRgvwuVUbYM).query
    mlNpiQJfcEIHAadODryKRgvwuVUbYx=mlNpiQJfcEIHAadODryKRgvwuVUbYq[0:mlNpiQJfcEIHAadODryKRgvwuVUbYq.find('=')]
    mlNpiQJfcEIHAadODryKRgvwuVUbYL=mlNpiQJfcEIHAadODryKRgvwuVUbjs(urllib.parse.parse_qsl(mlNpiQJfcEIHAadODryKRgvwuVUbYq))
    mlNpiQJfcEIHAadODryKRgvwuVUbYB=mlNpiQJfcEIHAadODryKRgvwuVUbYL.get(mlNpiQJfcEIHAadODryKRgvwuVUbYx)
    mlNpiQJfcEIHAadODryKRgvwuVUbYC={'title':mlNpiQJfcEIHAadODryKRgvwuVUbYP['title_list'][0]['text'],'age':mlNpiQJfcEIHAadODryKRgvwuVUbYP['age'],'thumbnail':'https://%s'%mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('thumbnail'),'videoid':mlNpiQJfcEIHAadODryKRgvwuVUbYB,'vidtype':mlNpiQJfcEIHAadODryKRgvwuVUbYx,}
    mlNpiQJfcEIHAadODryKRgvwuVUbGt=mlNpiQJfcEIHAadODryKRgvwuVUbsk
    for mlNpiQJfcEIHAadODryKRgvwuVUbGs in mlNpiQJfcEIHAadODryKRgvwuVUbYP['bottom_taglist']:
     if mlNpiQJfcEIHAadODryKRgvwuVUbGs=='won':
      mlNpiQJfcEIHAadODryKRgvwuVUbGt=mlNpiQJfcEIHAadODryKRgvwuVUbjX
      break
    if mlNpiQJfcEIHAadODryKRgvwuVUbGt==mlNpiQJfcEIHAadODryKRgvwuVUbjX: 
     mlNpiQJfcEIHAadODryKRgvwuVUbYC['title']=mlNpiQJfcEIHAadODryKRgvwuVUbYC['title']+' [개별구매]'
    if exclusion21==mlNpiQJfcEIHAadODryKRgvwuVUbsk or mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('age')!='21':
     mlNpiQJfcEIHAadODryKRgvwuVUbGC.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
   mlNpiQJfcEIHAadODryKRgvwuVUbYW=mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbCX['band']['pagecount'])
   if mlNpiQJfcEIHAadODryKRgvwuVUbCX['band']['count']:mlNpiQJfcEIHAadODryKRgvwuVUbYh =mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbCX['band']['count'])
   else:mlNpiQJfcEIHAadODryKRgvwuVUbYh=mlNpiQJfcEIHAadODryKRgvwuVUbXC.LIST_LIMIT
   mlNpiQJfcEIHAadODryKRgvwuVUbYo=mlNpiQJfcEIHAadODryKRgvwuVUbYW>mlNpiQJfcEIHAadODryKRgvwuVUbYh
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
  return mlNpiQJfcEIHAadODryKRgvwuVUbGC,mlNpiQJfcEIHAadODryKRgvwuVUbYo 
 def GetSecureToken(mlNpiQJfcEIHAadODryKRgvwuVUbXC):
  mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/ip'
  mlNpiQJfcEIHAadODryKRgvwuVUbXM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk)
  mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
  mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
  return mlNpiQJfcEIHAadODryKRgvwuVUbPq['securetoken']
 def Wavve_Parse_m3u8(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbtj):
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPj={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=requests.get(url=mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_url'],headers=mlNpiQJfcEIHAadODryKRgvwuVUbPj,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_cookie'])
   mlNpiQJfcEIHAadODryKRgvwuVUbGj=mlNpiQJfcEIHAadODryKRgvwuVUbPM.content.decode('utf-8')
   if '#EXTM3U' not in mlNpiQJfcEIHAadODryKRgvwuVUbGj:
    return mlNpiQJfcEIHAadODryKRgvwuVUbsk
   if '#EXT-X-STREAM-INF' not in mlNpiQJfcEIHAadODryKRgvwuVUbGj: 
    return mlNpiQJfcEIHAadODryKRgvwuVUbsk
   mlNpiQJfcEIHAadODryKRgvwuVUbGz=0
   for mlNpiQJfcEIHAadODryKRgvwuVUbGe in mlNpiQJfcEIHAadODryKRgvwuVUbGj.splitlines():
    if mlNpiQJfcEIHAadODryKRgvwuVUbGe.startswith('#EXT-X-STREAM-INF'):
     mlNpiQJfcEIHAadODryKRgvwuVUbGW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.MediaLine_Parse(mlNpiQJfcEIHAadODryKRgvwuVUbGe,'#EXT-X-STREAM-INF')
     if mlNpiQJfcEIHAadODryKRgvwuVUbGz<mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbGW.get('BANDWIDTH')):
      mlNpiQJfcEIHAadODryKRgvwuVUbGz=mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbGW.get('BANDWIDTH'))
   mlNpiQJfcEIHAadODryKRgvwuVUbGo=[]
   mlNpiQJfcEIHAadODryKRgvwuVUbGM=mlNpiQJfcEIHAadODryKRgvwuVUbsk
   for mlNpiQJfcEIHAadODryKRgvwuVUbGe in mlNpiQJfcEIHAadODryKRgvwuVUbGj.splitlines():
    if mlNpiQJfcEIHAadODryKRgvwuVUbGM==mlNpiQJfcEIHAadODryKRgvwuVUbjX:
     mlNpiQJfcEIHAadODryKRgvwuVUbGM=mlNpiQJfcEIHAadODryKRgvwuVUbsk
     continue
    if mlNpiQJfcEIHAadODryKRgvwuVUbGe.startswith('#EXT-X-STREAM-INF'):
     mlNpiQJfcEIHAadODryKRgvwuVUbGW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.MediaLine_Parse(mlNpiQJfcEIHAadODryKRgvwuVUbGe,'#EXT-X-STREAM-INF')
     if mlNpiQJfcEIHAadODryKRgvwuVUbGz!=mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbGW.get('BANDWIDTH')):
      mlNpiQJfcEIHAadODryKRgvwuVUbGM=mlNpiQJfcEIHAadODryKRgvwuVUbjX
      continue
    mlNpiQJfcEIHAadODryKRgvwuVUbGo.append(mlNpiQJfcEIHAadODryKRgvwuVUbGe)
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return mlNpiQJfcEIHAadODryKRgvwuVUbsk
  mlNpiQJfcEIHAadODryKRgvwuVUbGq='\n'.join(mlNpiQJfcEIHAadODryKRgvwuVUbGo)
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.TextFile_Save(mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV_STREAM_FILENAME,mlNpiQJfcEIHAadODryKRgvwuVUbGq)
  return mlNpiQJfcEIHAadODryKRgvwuVUbjX
 def Wavve_Parse_mpd(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbtj):
  mlNpiQJfcEIHAadODryKRgvwuVUbPj={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  mlNpiQJfcEIHAadODryKRgvwuVUbPM=requests.get(url=mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_url'],headers=mlNpiQJfcEIHAadODryKRgvwuVUbPj,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_cookie'])
  mlNpiQJfcEIHAadODryKRgvwuVUbGx=mlNpiQJfcEIHAadODryKRgvwuVUbPM.content.decode('utf-8')
  mlNpiQJfcEIHAadODryKRgvwuVUbGB =ET.ElementTree(ET.fromstring(mlNpiQJfcEIHAadODryKRgvwuVUbGx))
  mlNpiQJfcEIHAadODryKRgvwuVUbGh =mlNpiQJfcEIHAadODryKRgvwuVUbGB.getroot()
  mlNpiQJfcEIHAadODryKRgvwuVUbGS=re.match(r'\{.*\}',mlNpiQJfcEIHAadODryKRgvwuVUbGh.tag)[0] 
  mlNpiQJfcEIHAadODryKRgvwuVUbGF=mlNpiQJfcEIHAadODryKRgvwuVUbjs([node for _,node in ET.iterparse(io.StringIO(mlNpiQJfcEIHAadODryKRgvwuVUbGx),events=['start-ns'])])
  for mlNpiQJfcEIHAadODryKRgvwuVUbPt,mlNpiQJfcEIHAadODryKRgvwuVUbts in mlNpiQJfcEIHAadODryKRgvwuVUbGF.items():
   ET.register_namespace(mlNpiQJfcEIHAadODryKRgvwuVUbPt,mlNpiQJfcEIHAadODryKRgvwuVUbts)
  mlNpiQJfcEIHAadODryKRgvwuVUbGT=mlNpiQJfcEIHAadODryKRgvwuVUbGh.find(mlNpiQJfcEIHAadODryKRgvwuVUbGS+'Period')
  for mlNpiQJfcEIHAadODryKRgvwuVUbGL in mlNpiQJfcEIHAadODryKRgvwuVUbGT.findall(mlNpiQJfcEIHAadODryKRgvwuVUbGS+'AdaptationSet'):
   if mlNpiQJfcEIHAadODryKRgvwuVUbGL.attrib.get('mimeType')=='video/mp4':
    mlNpiQJfcEIHAadODryKRgvwuVUbGk=0
    for mlNpiQJfcEIHAadODryKRgvwuVUbGn in mlNpiQJfcEIHAadODryKRgvwuVUbGL.findall(mlNpiQJfcEIHAadODryKRgvwuVUbGS+'Representation'):
     mlNpiQJfcEIHAadODryKRgvwuVUbtX=mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbGn.attrib.get('bandwidth'))
     if mlNpiQJfcEIHAadODryKRgvwuVUbGk<mlNpiQJfcEIHAadODryKRgvwuVUbtX:mlNpiQJfcEIHAadODryKRgvwuVUbGk=mlNpiQJfcEIHAadODryKRgvwuVUbtX
    for mlNpiQJfcEIHAadODryKRgvwuVUbGn in mlNpiQJfcEIHAadODryKRgvwuVUbGL.findall(mlNpiQJfcEIHAadODryKRgvwuVUbGS+'Representation'):
     if mlNpiQJfcEIHAadODryKRgvwuVUbGk>mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbGn.attrib.get('bandwidth')):
      mlNpiQJfcEIHAadODryKRgvwuVUbGL.remove(mlNpiQJfcEIHAadODryKRgvwuVUbGn)
   elif mlNpiQJfcEIHAadODryKRgvwuVUbGL.attrib.get('mimeType')=='audio/mp4':
    mlNpiQJfcEIHAadODryKRgvwuVUbGk=0
    for mlNpiQJfcEIHAadODryKRgvwuVUbGn in mlNpiQJfcEIHAadODryKRgvwuVUbGL.findall(mlNpiQJfcEIHAadODryKRgvwuVUbGS+'Representation'):
     mlNpiQJfcEIHAadODryKRgvwuVUbtX=mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbGn.attrib.get('bandwidth'))
     if mlNpiQJfcEIHAadODryKRgvwuVUbGk<mlNpiQJfcEIHAadODryKRgvwuVUbtX:mlNpiQJfcEIHAadODryKRgvwuVUbGk=mlNpiQJfcEIHAadODryKRgvwuVUbtX
    for mlNpiQJfcEIHAadODryKRgvwuVUbGn in mlNpiQJfcEIHAadODryKRgvwuVUbGL.findall(mlNpiQJfcEIHAadODryKRgvwuVUbGS+'Representation'):
     if mlNpiQJfcEIHAadODryKRgvwuVUbGk>mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbGn.attrib.get('bandwidth')):
      mlNpiQJfcEIHAadODryKRgvwuVUbGL.remove(mlNpiQJfcEIHAadODryKRgvwuVUbGn)
   else:
    continue
  mlNpiQJfcEIHAadODryKRgvwuVUbtP=ET.tostring(mlNpiQJfcEIHAadODryKRgvwuVUbGh).decode('utf-8')
  mlNpiQJfcEIHAadODryKRgvwuVUbtY='<?xml version="1.0" encoding="UTF-8"?>\n'
  mlNpiQJfcEIHAadODryKRgvwuVUbXC.TextFile_Save(mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV_STREAM_FILENAME,mlNpiQJfcEIHAadODryKRgvwuVUbtY+mlNpiQJfcEIHAadODryKRgvwuVUbtP)
  return mlNpiQJfcEIHAadODryKRgvwuVUbjX
 def MediaLine_Parse(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbGe,prefix):
  mlNpiQJfcEIHAadODryKRgvwuVUbGW={}
  for mlNpiQJfcEIHAadODryKRgvwuVUbtC in mlNpiQJfcEIHAadODryKRgvwuVUbXY.split(mlNpiQJfcEIHAadODryKRgvwuVUbGe.replace(prefix+':',''))[1::2]:
   mlNpiQJfcEIHAadODryKRgvwuVUbtG,mlNpiQJfcEIHAadODryKRgvwuVUbts=mlNpiQJfcEIHAadODryKRgvwuVUbtC.split('=',1)
   mlNpiQJfcEIHAadODryKRgvwuVUbGW[mlNpiQJfcEIHAadODryKRgvwuVUbtG.upper()]=mlNpiQJfcEIHAadODryKRgvwuVUbts.replace('"','').strip()
  return mlNpiQJfcEIHAadODryKRgvwuVUbGW
 def GetStreamingURL(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mode,mlNpiQJfcEIHAadODryKRgvwuVUbYn,quality_int,pvrmode='-',playOption={}):
  mlNpiQJfcEIHAadODryKRgvwuVUbtj ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  mlNpiQJfcEIHAadODryKRgvwuVUbtz=[]
  if mode=='LIVE':
   mlNpiQJfcEIHAadODryKRgvwuVUbPW =mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/live/channels/'+mlNpiQJfcEIHAadODryKRgvwuVUbYn
   mlNpiQJfcEIHAadODryKRgvwuVUbte='live'
  elif mode=='VOD':
   mlNpiQJfcEIHAadODryKRgvwuVUbPW =mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/fz/vod/contents-detail/'+mlNpiQJfcEIHAadODryKRgvwuVUbYn 
   mlNpiQJfcEIHAadODryKRgvwuVUbte='vod'
  elif mode=='MOVIE':
   mlNpiQJfcEIHAadODryKRgvwuVUbPW =mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/fz/movie/contents/'+mlNpiQJfcEIHAadODryKRgvwuVUbYn
   mlNpiQJfcEIHAadODryKRgvwuVUbte='movie'
  mlNpiQJfcEIHAadODryKRgvwuVUbtW={'hdr':'sdr','uhd':'-',}
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbXM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk)
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   mlNpiQJfcEIHAadODryKRgvwuVUbto=mlNpiQJfcEIHAadODryKRgvwuVUbPq['qualities']['list']
   if mlNpiQJfcEIHAadODryKRgvwuVUbto==mlNpiQJfcEIHAadODryKRgvwuVUbsL:return mlNpiQJfcEIHAadODryKRgvwuVUbtj
   for mlNpiQJfcEIHAadODryKRgvwuVUbtM in mlNpiQJfcEIHAadODryKRgvwuVUbto:
    mlNpiQJfcEIHAadODryKRgvwuVUbtz.append(mlNpiQJfcEIHAadODryKRgvwuVUbjz(mlNpiQJfcEIHAadODryKRgvwuVUbtM.get('id').rstrip('p')))
   if 'type' in mlNpiQJfcEIHAadODryKRgvwuVUbPq:
    if mlNpiQJfcEIHAadODryKRgvwuVUbPq['type']=='onair':
     mlNpiQJfcEIHAadODryKRgvwuVUbte='onairvod'
   if 'drms' in mlNpiQJfcEIHAadODryKRgvwuVUbPq:
    if mlNpiQJfcEIHAadODryKRgvwuVUbPq['drms']:
     mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in mlNpiQJfcEIHAadODryKRgvwuVUbPq.get('qualities'):
     for mlNpiQJfcEIHAadODryKRgvwuVUbtq in mlNpiQJfcEIHAadODryKRgvwuVUbPq.get('qualities').get('mediatypes'):
      if mlNpiQJfcEIHAadODryKRgvwuVUbtq=='HDR10':
       mlNpiQJfcEIHAadODryKRgvwuVUbtW['hdr']='hdr'
       mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for mlNpiQJfcEIHAadODryKRgvwuVUbtq in mlNpiQJfcEIHAadODryKRgvwuVUbPq.get('qualities').get('list'):
     if mlNpiQJfcEIHAadODryKRgvwuVUbtq.get('name')=='UHD':
      mlNpiQJfcEIHAadODryKRgvwuVUbtW['uhd']='uhd'
      break
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return mlNpiQJfcEIHAadODryKRgvwuVUbtj
  mlNpiQJfcEIHAadODryKRgvwuVUbjt('stream_action : '+mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_action'])
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbtx=mlNpiQJfcEIHAadODryKRgvwuVUbXC.CheckQuality(quality_int,mlNpiQJfcEIHAadODryKRgvwuVUbtz)
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(mlNpiQJfcEIHAadODryKRgvwuVUbtx)
   if mlNpiQJfcEIHAadODryKRgvwuVUbtx<1080:
    mlNpiQJfcEIHAadODryKRgvwuVUbtW['uhd']='-'
    mlNpiQJfcEIHAadODryKRgvwuVUbtW['hdr']='sdr'
   if mlNpiQJfcEIHAadODryKRgvwuVUbtW['uhd']=='uhd':mlNpiQJfcEIHAadODryKRgvwuVUbtx=2160 
   mlNpiQJfcEIHAadODryKRgvwuVUbtB=mlNpiQJfcEIHAadODryKRgvwuVUbjY(mlNpiQJfcEIHAadODryKRgvwuVUbtx)+'p'
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(mlNpiQJfcEIHAadODryKRgvwuVUbtB)
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/fz/streaming'
   if mlNpiQJfcEIHAadODryKRgvwuVUbtW['hdr']=='hdr' or mlNpiQJfcEIHAadODryKRgvwuVUbtW['uhd']=='uhd':
    mlNpiQJfcEIHAadODryKRgvwuVUbXM={'contentid':mlNpiQJfcEIHAadODryKRgvwuVUbYn,'contenttype':mlNpiQJfcEIHAadODryKRgvwuVUbte,'quality':mlNpiQJfcEIHAadODryKRgvwuVUbtB,'modelid':'SHIELD Android TV','guid':mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams_AND())
   else:
    mlNpiQJfcEIHAadODryKRgvwuVUbXM={'contentid':mlNpiQJfcEIHAadODryKRgvwuVUbYn,'contenttype':mlNpiQJfcEIHAadODryKRgvwuVUbte,'quality':mlNpiQJfcEIHAadODryKRgvwuVUbtB,'deviceModelId':'Windows 10','guid':mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_action'],'protocol':mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbjX))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_url']=mlNpiQJfcEIHAadODryKRgvwuVUbPq['playurl']
   if mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_url']==mlNpiQJfcEIHAadODryKRgvwuVUbsL:return mlNpiQJfcEIHAadODryKRgvwuVUbtj
   mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_cookie']=mlNpiQJfcEIHAadODryKRgvwuVUbXC.make_str_ToCookie(mlNpiQJfcEIHAadODryKRgvwuVUbPq['awscookie'])
   mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_drm'] =mlNpiQJfcEIHAadODryKRgvwuVUbPq['drm']
   if 'previewmsg' in mlNpiQJfcEIHAadODryKRgvwuVUbPq['preview']:mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_preview']=mlNpiQJfcEIHAadODryKRgvwuVUbPq['preview']['previewmsg']
   if 'subtitles' in mlNpiQJfcEIHAadODryKRgvwuVUbPq:
    for mlNpiQJfcEIHAadODryKRgvwuVUbth in mlNpiQJfcEIHAadODryKRgvwuVUbPq['subtitles']:
     if mlNpiQJfcEIHAadODryKRgvwuVUbth.get('languagecode')=='ko':
      mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_vtt']=mlNpiQJfcEIHAadODryKRgvwuVUbth.get('url')
      break
    if mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_vtt']=='':
     for mlNpiQJfcEIHAadODryKRgvwuVUbth in mlNpiQJfcEIHAadODryKRgvwuVUbPq['subtitles']:
      if mlNpiQJfcEIHAadODryKRgvwuVUbth.get('languagecode')=='ko_cc':
       mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_vtt']=mlNpiQJfcEIHAadODryKRgvwuVUbth.get('url')
       break
   mlNpiQJfcEIHAadODryKRgvwuVUbtj['playParam']=mlNpiQJfcEIHAadODryKRgvwuVUbtW 
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
  return mlNpiQJfcEIHAadODryKRgvwuVUbtj 
 def GetSportsURL(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbYn,quality_int):
  mlNpiQJfcEIHAadODryKRgvwuVUbtj ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  mlNpiQJfcEIHAadODryKRgvwuVUbtz=[]
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/streaming/other'
   mlNpiQJfcEIHAadODryKRgvwuVUbXM={'contentid':mlNpiQJfcEIHAadODryKRgvwuVUbYn,'contenttype':'live','action':mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_action'],'quality':mlNpiQJfcEIHAadODryKRgvwuVUbjY(quality_int)+'p','deviceModelId':'Windows 10','guid':mlNpiQJfcEIHAadODryKRgvwuVUbXC.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbjX))
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_url']=mlNpiQJfcEIHAadODryKRgvwuVUbPq['playurl']
   if mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_url']==mlNpiQJfcEIHAadODryKRgvwuVUbsL:return mlNpiQJfcEIHAadODryKRgvwuVUbtj
   mlNpiQJfcEIHAadODryKRgvwuVUbtj['stream_cookie']=mlNpiQJfcEIHAadODryKRgvwuVUbPq['awscookie']
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
  return mlNpiQJfcEIHAadODryKRgvwuVUbtj
 def make_viewdate(mlNpiQJfcEIHAadODryKRgvwuVUbXC):
  mlNpiQJfcEIHAadODryKRgvwuVUbtS =mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_Now_Datetime()
  mlNpiQJfcEIHAadODryKRgvwuVUbtF =mlNpiQJfcEIHAadODryKRgvwuVUbtS+datetime.timedelta(days=-1)
  mlNpiQJfcEIHAadODryKRgvwuVUbtT =mlNpiQJfcEIHAadODryKRgvwuVUbtS+datetime.timedelta(days=1)
  mlNpiQJfcEIHAadODryKRgvwuVUbtL=[mlNpiQJfcEIHAadODryKRgvwuVUbtS.strftime('%Y%m%d'),mlNpiQJfcEIHAadODryKRgvwuVUbtT.strftime('%Y%m%d'),]
  return mlNpiQJfcEIHAadODryKRgvwuVUbtL
 def Get_Sports_Gamelist(mlNpiQJfcEIHAadODryKRgvwuVUbXC):
  mlNpiQJfcEIHAadODryKRgvwuVUbtk =mlNpiQJfcEIHAadODryKRgvwuVUbXC.make_viewdate()
  mlNpiQJfcEIHAadODryKRgvwuVUbtn=[]
  mlNpiQJfcEIHAadODryKRgvwuVUbsX =[]
  for mlNpiQJfcEIHAadODryKRgvwuVUbsP in mlNpiQJfcEIHAadODryKRgvwuVUbtk:
   mlNpiQJfcEIHAadODryKRgvwuVUbsY=mlNpiQJfcEIHAadODryKRgvwuVUbsP[:6]
   if mlNpiQJfcEIHAadODryKRgvwuVUbsY not in mlNpiQJfcEIHAadODryKRgvwuVUbtn:
    mlNpiQJfcEIHAadODryKRgvwuVUbtn.append(mlNpiQJfcEIHAadODryKRgvwuVUbsY)
  try:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   mlNpiQJfcEIHAadODryKRgvwuVUbXM={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   mlNpiQJfcEIHAadODryKRgvwuVUbXM.update(mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk))
   for mlNpiQJfcEIHAadODryKRgvwuVUbsC in mlNpiQJfcEIHAadODryKRgvwuVUbtn:
    mlNpiQJfcEIHAadODryKRgvwuVUbXM['date']=mlNpiQJfcEIHAadODryKRgvwuVUbsC
    mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
    mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
    mlNpiQJfcEIHAadODryKRgvwuVUbYX=mlNpiQJfcEIHAadODryKRgvwuVUbPq['cell_toplist']['celllist']
    for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbYX:
     mlNpiQJfcEIHAadODryKRgvwuVUbsG=mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('game_date')
     mlNpiQJfcEIHAadODryKRgvwuVUbst =mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('svc_id')
     if mlNpiQJfcEIHAadODryKRgvwuVUbst=='':continue
     if mlNpiQJfcEIHAadODryKRgvwuVUbsG in mlNpiQJfcEIHAadODryKRgvwuVUbtk:
      mlNpiQJfcEIHAadODryKRgvwuVUbsj=mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('game_status') 
      mlNpiQJfcEIHAadODryKRgvwuVUbsz =mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('title_list')[0].get('text')
      mlNpiQJfcEIHAadODryKRgvwuVUbsG =mlNpiQJfcEIHAadODryKRgvwuVUbsG[:4]+'-'+mlNpiQJfcEIHAadODryKRgvwuVUbsG[4:6]+'-'+mlNpiQJfcEIHAadODryKRgvwuVUbsG[-2:]
      mlNpiQJfcEIHAadODryKRgvwuVUbse =mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('game_time')
      mlNpiQJfcEIHAadODryKRgvwuVUbse =mlNpiQJfcEIHAadODryKRgvwuVUbse[:2]+':'+mlNpiQJfcEIHAadODryKRgvwuVUbse[-2:]
      mlNpiQJfcEIHAadODryKRgvwuVUbYC={'game_date':mlNpiQJfcEIHAadODryKRgvwuVUbsG,'game_time':mlNpiQJfcEIHAadODryKRgvwuVUbse,'svc_id':mlNpiQJfcEIHAadODryKRgvwuVUbst,'away_team':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('away_team').get('team_name'),'home_team':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('home_team').get('team_name'),'game_status':mlNpiQJfcEIHAadODryKRgvwuVUbsj,'game_place':mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('game_place'),}
      mlNpiQJfcEIHAadODryKRgvwuVUbsX.append(mlNpiQJfcEIHAadODryKRgvwuVUbYC)
  except mlNpiQJfcEIHAadODryKRgvwuVUbjG as exception:
   mlNpiQJfcEIHAadODryKRgvwuVUbjt(exception)
   return[]
  mlNpiQJfcEIHAadODryKRgvwuVUbsW=[]
  for i in mlNpiQJfcEIHAadODryKRgvwuVUbjP(2):
   for mlNpiQJfcEIHAadODryKRgvwuVUbYP in mlNpiQJfcEIHAadODryKRgvwuVUbsX:
    if i==0 and mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('game_status')=='LIVE':
     mlNpiQJfcEIHAadODryKRgvwuVUbsW.append(mlNpiQJfcEIHAadODryKRgvwuVUbYP)
    elif i==1 and mlNpiQJfcEIHAadODryKRgvwuVUbYP.get('game_status')!='LIVE':
     mlNpiQJfcEIHAadODryKRgvwuVUbsW.append(mlNpiQJfcEIHAadODryKRgvwuVUbYP)
  return mlNpiQJfcEIHAadODryKRgvwuVUbsW
 def GetBookmarkInfo(mlNpiQJfcEIHAadODryKRgvwuVUbXC,mlNpiQJfcEIHAadODryKRgvwuVUbYB,mlNpiQJfcEIHAadODryKRgvwuVUbYx,mlNpiQJfcEIHAadODryKRgvwuVUbte):
  if mlNpiQJfcEIHAadODryKRgvwuVUbYx=='tvshow':
   if mlNpiQJfcEIHAadODryKRgvwuVUbte=='contentid':
    mlNpiQJfcEIHAadODryKRgvwuVUbYn=mlNpiQJfcEIHAadODryKRgvwuVUbYB
    mlNpiQJfcEIHAadODryKRgvwuVUbYB =mlNpiQJfcEIHAadODryKRgvwuVUbXC.ContentidToSeasonid(mlNpiQJfcEIHAadODryKRgvwuVUbYn)
   else:
    mlNpiQJfcEIHAadODryKRgvwuVUbYn=mlNpiQJfcEIHAadODryKRgvwuVUbXC.ProgramidToContentid(mlNpiQJfcEIHAadODryKRgvwuVUbYB)
  else:
   mlNpiQJfcEIHAadODryKRgvwuVUbYn=''
  mlNpiQJfcEIHAadODryKRgvwuVUbso={'indexinfo':{'ott':'wavve','videoid':mlNpiQJfcEIHAadODryKRgvwuVUbYB,'vidtype':mlNpiQJfcEIHAadODryKRgvwuVUbYx,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':mlNpiQJfcEIHAadODryKRgvwuVUbYx,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if mlNpiQJfcEIHAadODryKRgvwuVUbYx=='tvshow':
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/fz/vod/contents/'+mlNpiQJfcEIHAadODryKRgvwuVUbYn 
   mlNpiQJfcEIHAadODryKRgvwuVUbXM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk)
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if not('programtitle' in mlNpiQJfcEIHAadODryKRgvwuVUbPq):return{}
   mlNpiQJfcEIHAadODryKRgvwuVUbsM=mlNpiQJfcEIHAadODryKRgvwuVUbPq
   mlNpiQJfcEIHAadODryKRgvwuVUbsq=mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('programtitle')
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['title']=mlNpiQJfcEIHAadODryKRgvwuVUbsq
   if mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('targetage')=='18' or mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('targetage')=='19' or mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('targetage')=='21':
    mlNpiQJfcEIHAadODryKRgvwuVUbsq +=u' (%s)'%(mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('targetage'))
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['title'] =mlNpiQJfcEIHAadODryKRgvwuVUbsq
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['mpaa'] =mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('targetage')
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['plot'] =mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('programsynopsis'))
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['studio'] =mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('channelname')
   if mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('firstreleaseyear')!='':mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['year'] =mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('firstreleaseyear')
   if mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('firstreleasedate')!='':mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['premiered']=mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('firstreleasedate')
   if mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('genretext') !='':mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['genre'] =[mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('genretext')]
   mlNpiQJfcEIHAadODryKRgvwuVUbsx=[]
   for mlNpiQJfcEIHAadODryKRgvwuVUbsB in mlNpiQJfcEIHAadODryKRgvwuVUbsM['actors']['list']:mlNpiQJfcEIHAadODryKRgvwuVUbsx.append(mlNpiQJfcEIHAadODryKRgvwuVUbsB.get('text'))
   if mlNpiQJfcEIHAadODryKRgvwuVUbjC(mlNpiQJfcEIHAadODryKRgvwuVUbsx)>0:
    if mlNpiQJfcEIHAadODryKRgvwuVUbsx[0]!='':mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['cast']=mlNpiQJfcEIHAadODryKRgvwuVUbsx
   mlNpiQJfcEIHAadODryKRgvwuVUbCx =''
   mlNpiQJfcEIHAadODryKRgvwuVUbCB =''
   mlNpiQJfcEIHAadODryKRgvwuVUbCh=''
   if mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('programposterimage')!='':mlNpiQJfcEIHAadODryKRgvwuVUbCx =mlNpiQJfcEIHAadODryKRgvwuVUbXC.HTTPTAG+mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('programposterimage')
   if mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('programimage') !='':mlNpiQJfcEIHAadODryKRgvwuVUbCB =mlNpiQJfcEIHAadODryKRgvwuVUbXC.HTTPTAG+mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('programimage')
   if mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('programcircleimage')!='':mlNpiQJfcEIHAadODryKRgvwuVUbCh=mlNpiQJfcEIHAadODryKRgvwuVUbXC.HTTPTAG+mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('programcircleimage')
   if 'poster_default' in mlNpiQJfcEIHAadODryKRgvwuVUbCx:
    mlNpiQJfcEIHAadODryKRgvwuVUbCx =mlNpiQJfcEIHAadODryKRgvwuVUbCB
    mlNpiQJfcEIHAadODryKRgvwuVUbCh=''
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['thumbnail']['poster']=mlNpiQJfcEIHAadODryKRgvwuVUbCx
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['thumbnail']['thumb']=mlNpiQJfcEIHAadODryKRgvwuVUbCB
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['thumbnail']['clearlogo']=mlNpiQJfcEIHAadODryKRgvwuVUbCh
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['thumbnail']['fanart']=mlNpiQJfcEIHAadODryKRgvwuVUbCB
  else:
   mlNpiQJfcEIHAadODryKRgvwuVUbPW=mlNpiQJfcEIHAadODryKRgvwuVUbXC.API_DOMAIN+'/movie/contents/'+mlNpiQJfcEIHAadODryKRgvwuVUbYB 
   mlNpiQJfcEIHAadODryKRgvwuVUbXM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.GetDefaultParams(login=mlNpiQJfcEIHAadODryKRgvwuVUbsk)
   mlNpiQJfcEIHAadODryKRgvwuVUbPM=mlNpiQJfcEIHAadODryKRgvwuVUbXC.callRequestCookies('Get',mlNpiQJfcEIHAadODryKRgvwuVUbPW,payload=mlNpiQJfcEIHAadODryKRgvwuVUbsL,params=mlNpiQJfcEIHAadODryKRgvwuVUbXM,headers=mlNpiQJfcEIHAadODryKRgvwuVUbsL,cookies=mlNpiQJfcEIHAadODryKRgvwuVUbsL)
   mlNpiQJfcEIHAadODryKRgvwuVUbPq=json.loads(mlNpiQJfcEIHAadODryKRgvwuVUbPM.text)
   if not('title' in mlNpiQJfcEIHAadODryKRgvwuVUbPq):return{}
   mlNpiQJfcEIHAadODryKRgvwuVUbsM=mlNpiQJfcEIHAadODryKRgvwuVUbPq
   mlNpiQJfcEIHAadODryKRgvwuVUbsq=mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('title')
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['title']=mlNpiQJfcEIHAadODryKRgvwuVUbsq
   if mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('targetage')=='18' or mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('targetage')=='19' or mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('targetage')=='21':
    mlNpiQJfcEIHAadODryKRgvwuVUbsq +=u' (%s)'%(mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('targetage'))
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['title'] =mlNpiQJfcEIHAadODryKRgvwuVUbsq
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['mpaa'] =mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('targetage')
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['plot'] =mlNpiQJfcEIHAadODryKRgvwuVUbXC.Get_ChangeText(mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('synopsis'))
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['duration']=mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('playtime')
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['country']=mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('country')
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['studio'] =mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('cpname')
   if mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('releasedate')!='':
    mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['year'] =mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('releasedate')[:4]
    mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['premiered']=mlNpiQJfcEIHAadODryKRgvwuVUbsM.get('releasedate')
   mlNpiQJfcEIHAadODryKRgvwuVUbsx=[]
   for mlNpiQJfcEIHAadODryKRgvwuVUbsB in mlNpiQJfcEIHAadODryKRgvwuVUbsM['actors']['list']:mlNpiQJfcEIHAadODryKRgvwuVUbsx.append(mlNpiQJfcEIHAadODryKRgvwuVUbsB.get('text'))
   if mlNpiQJfcEIHAadODryKRgvwuVUbjC(mlNpiQJfcEIHAadODryKRgvwuVUbsx)>0:
    if mlNpiQJfcEIHAadODryKRgvwuVUbsx[0]!='':mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['cast']=mlNpiQJfcEIHAadODryKRgvwuVUbsx
   mlNpiQJfcEIHAadODryKRgvwuVUbsh=[]
   for mlNpiQJfcEIHAadODryKRgvwuVUbsS in mlNpiQJfcEIHAadODryKRgvwuVUbsM['directors']['list']:mlNpiQJfcEIHAadODryKRgvwuVUbsh.append(mlNpiQJfcEIHAadODryKRgvwuVUbsS.get('text'))
   if mlNpiQJfcEIHAadODryKRgvwuVUbjC(mlNpiQJfcEIHAadODryKRgvwuVUbsh)>0:
    if mlNpiQJfcEIHAadODryKRgvwuVUbsh[0]!='':mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['director']=mlNpiQJfcEIHAadODryKRgvwuVUbsh
   mlNpiQJfcEIHAadODryKRgvwuVUbPL=[]
   for mlNpiQJfcEIHAadODryKRgvwuVUbsF in mlNpiQJfcEIHAadODryKRgvwuVUbsM['genre']['list']:mlNpiQJfcEIHAadODryKRgvwuVUbPL.append(mlNpiQJfcEIHAadODryKRgvwuVUbsF.get('text'))
   if mlNpiQJfcEIHAadODryKRgvwuVUbjC(mlNpiQJfcEIHAadODryKRgvwuVUbPL)>0:
    if mlNpiQJfcEIHAadODryKRgvwuVUbPL[0]!='':mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['infoLabels']['genre']=mlNpiQJfcEIHAadODryKRgvwuVUbPL
   mlNpiQJfcEIHAadODryKRgvwuVUbCx ='https://%s'%mlNpiQJfcEIHAadODryKRgvwuVUbsM['image']
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['thumbnail']['poster'] =mlNpiQJfcEIHAadODryKRgvwuVUbCx
   mlNpiQJfcEIHAadODryKRgvwuVUbso['saveinfo']['thumbnail']['thumb'] =mlNpiQJfcEIHAadODryKRgvwuVUbCx
  return mlNpiQJfcEIHAadODryKRgvwuVUbso
# Created by pyminifier (https://github.com/liftoff/pyminifier)
