__author__="NightRain"
oFapcRKVSbnlQTIkmyPYvwuGAhNXtU=object
oFapcRKVSbnlQTIkmyPYvwuGAhNXtj=None
oFapcRKVSbnlQTIkmyPYvwuGAhNXti=int
oFapcRKVSbnlQTIkmyPYvwuGAhNXte=True
oFapcRKVSbnlQTIkmyPYvwuGAhNXtH=False
oFapcRKVSbnlQTIkmyPYvwuGAhNXtz=type
oFapcRKVSbnlQTIkmyPYvwuGAhNXtL=dict
oFapcRKVSbnlQTIkmyPYvwuGAhNXtC=getattr
oFapcRKVSbnlQTIkmyPYvwuGAhNXtr=list
oFapcRKVSbnlQTIkmyPYvwuGAhNXtf=len
oFapcRKVSbnlQTIkmyPYvwuGAhNXtq=range
oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ=str
oFapcRKVSbnlQTIkmyPYvwuGAhNXtB=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
oFapcRKVSbnlQTIkmyPYvwuGAhNXOM=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://apis.wavve.com/v1/multiband/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&broadcastid=VN1000&came=MainCategory&contenttype=program&genre=01&uicode=VN1000&uiparent=GN56&uirank=21&uitype=VN1000','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/allprograms?WeekDay=all&adult=n&broadcastid=VN1001&came=MainCategory&contenttype=program&genre=02&subgenre=all&uicode=VN1001&uiparent=GN57&uirank=17&uitype=VN1001','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'CN21','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'vod09','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'4','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
oFapcRKVSbnlQTIkmyPYvwuGAhNXOE=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
oFapcRKVSbnlQTIkmyPYvwuGAhNXOg=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
oFapcRKVSbnlQTIkmyPYvwuGAhNXOD={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
oFapcRKVSbnlQTIkmyPYvwuGAhNXOW =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
oFapcRKVSbnlQTIkmyPYvwuGAhNXOt=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class oFapcRKVSbnlQTIkmyPYvwuGAhNXOs(oFapcRKVSbnlQTIkmyPYvwuGAhNXtU):
 def __init__(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,oFapcRKVSbnlQTIkmyPYvwuGAhNXOU,oFapcRKVSbnlQTIkmyPYvwuGAhNXOj,oFapcRKVSbnlQTIkmyPYvwuGAhNXOi):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_url =oFapcRKVSbnlQTIkmyPYvwuGAhNXOU
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle=oFapcRKVSbnlQTIkmyPYvwuGAhNXOj
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.main_params =oFapcRKVSbnlQTIkmyPYvwuGAhNXOi
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj =mlNpiQJfcEIHAadODryKRgvwuVUbXP() 
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,sting):
  try:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOH=xbmcgui.Dialog()
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOH.notification(__addonname__,sting)
  except:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtj
 def addon_log(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,string):
  try:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOz=string.encode('utf-8','ignore')
  except:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOz='addonException: addon_log'
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOL=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,oFapcRKVSbnlQTIkmyPYvwuGAhNXOz),level=oFapcRKVSbnlQTIkmyPYvwuGAhNXOL)
 def get_keyboard_input(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,oFapcRKVSbnlQTIkmyPYvwuGAhNXse):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOC=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj
  kb=xbmc.Keyboard()
  kb.setHeading(oFapcRKVSbnlQTIkmyPYvwuGAhNXse)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOC=kb.getText()
  return oFapcRKVSbnlQTIkmyPYvwuGAhNXOC
 def get_settings_account(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOr =__addon__.getSetting('id')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOf =__addon__.getSetting('pw')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOq=oFapcRKVSbnlQTIkmyPYvwuGAhNXti(__addon__.getSetting('selected_profile'))
  return(oFapcRKVSbnlQTIkmyPYvwuGAhNXOr,oFapcRKVSbnlQTIkmyPYvwuGAhNXOf,oFapcRKVSbnlQTIkmyPYvwuGAhNXOq)
 def get_settings_totalsearch(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOJ =oFapcRKVSbnlQTIkmyPYvwuGAhNXte if __addon__.getSetting('local_search')=='true' else oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOB=oFapcRKVSbnlQTIkmyPYvwuGAhNXte if __addon__.getSetting('local_history')=='true' else oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOx =oFapcRKVSbnlQTIkmyPYvwuGAhNXte if __addon__.getSetting('total_search')=='true' else oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsO=oFapcRKVSbnlQTIkmyPYvwuGAhNXte if __addon__.getSetting('total_history')=='true' else oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsM=oFapcRKVSbnlQTIkmyPYvwuGAhNXte if __addon__.getSetting('menu_bookmark')=='true' else oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  return(oFapcRKVSbnlQTIkmyPYvwuGAhNXOJ,oFapcRKVSbnlQTIkmyPYvwuGAhNXOB,oFapcRKVSbnlQTIkmyPYvwuGAhNXOx,oFapcRKVSbnlQTIkmyPYvwuGAhNXsO,oFapcRKVSbnlQTIkmyPYvwuGAhNXsM)
 def get_settings_makebookmark(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  return oFapcRKVSbnlQTIkmyPYvwuGAhNXte if __addon__.getSetting('make_bookmark')=='true' else oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
 def get_settings_play(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsE={'enable_hdr':oFapcRKVSbnlQTIkmyPYvwuGAhNXte if __addon__.getSetting('enable_hdr')=='true' else oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,'enable_uhd':oFapcRKVSbnlQTIkmyPYvwuGAhNXte if __addon__.getSetting('enable_uhd')=='true' else oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,'streamFilename':oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.WV_STREAM_FILENAME,}
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_selQuality()<1080:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsE['enable_hdr']=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsE['enable_uhd']=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  return(oFapcRKVSbnlQTIkmyPYvwuGAhNXsE)
 def get_settings_proxyport(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsg =oFapcRKVSbnlQTIkmyPYvwuGAhNXte if __addon__.getSetting('proxyYn')=='true' else oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsD=oFapcRKVSbnlQTIkmyPYvwuGAhNXti(__addon__.getSetting('proxyPort'))
  return oFapcRKVSbnlQTIkmyPYvwuGAhNXsg,oFapcRKVSbnlQTIkmyPYvwuGAhNXsD
 def get_selQuality(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  try:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsW=[1080,720,480,360]
   oFapcRKVSbnlQTIkmyPYvwuGAhNXst=oFapcRKVSbnlQTIkmyPYvwuGAhNXti(__addon__.getSetting('selected_quality'))
   return oFapcRKVSbnlQTIkmyPYvwuGAhNXsW[oFapcRKVSbnlQTIkmyPYvwuGAhNXst]
  except:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtj
  return 1080 
 def get_settings_exclusion21(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsd =__addon__.getSetting('exclusion21')
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXsd=='false':
   return oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  else:
   return oFapcRKVSbnlQTIkmyPYvwuGAhNXte
 def get_settings_direct_replay(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsU=oFapcRKVSbnlQTIkmyPYvwuGAhNXti(__addon__.getSetting('direct_replay'))
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXsU==0:
   return oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  else:
   return oFapcRKVSbnlQTIkmyPYvwuGAhNXte
 def set_winEpisodeOrderby(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,oFapcRKVSbnlQTIkmyPYvwuGAhNXsj):
  __addon__.setSetting('wavve_orderby',oFapcRKVSbnlQTIkmyPYvwuGAhNXsj)
 def get_winEpisodeOrderby(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsj=__addon__.getSetting('wavve_orderby')
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXsj in['',oFapcRKVSbnlQTIkmyPYvwuGAhNXtj]:oFapcRKVSbnlQTIkmyPYvwuGAhNXsj='desc'
  return oFapcRKVSbnlQTIkmyPYvwuGAhNXsj
 def add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,label,sublabel='',img='',infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params='',isLink=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,ContextMenu=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsi='%s?%s'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_url,urllib.parse.urlencode(params))
  if sublabel:oFapcRKVSbnlQTIkmyPYvwuGAhNXse='%s < %s >'%(label,sublabel)
  else: oFapcRKVSbnlQTIkmyPYvwuGAhNXse=label
  if not img:img='DefaultFolder.png'
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsH=xbmcgui.ListItem(oFapcRKVSbnlQTIkmyPYvwuGAhNXse)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtz(img)==oFapcRKVSbnlQTIkmyPYvwuGAhNXtL:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.setArt(img)
  else:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.setArt({'thumb':img,'poster':img})
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.KodiVersion>=20:
   if infoLabels:oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.Set_InfoTag(oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.setProperty('IsPlayable','true')
  if ContextMenu:oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,oFapcRKVSbnlQTIkmyPYvwuGAhNXsi,oFapcRKVSbnlQTIkmyPYvwuGAhNXsH,isFolder)
 def Set_InfoTag(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,video_InfoTag:xbmc.InfoTagVideo,oFapcRKVSbnlQTIkmyPYvwuGAhNXsB):
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXsz,value in oFapcRKVSbnlQTIkmyPYvwuGAhNXsB.items():
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXOD[oFapcRKVSbnlQTIkmyPYvwuGAhNXsz]['type']=='string':
    oFapcRKVSbnlQTIkmyPYvwuGAhNXtC(video_InfoTag,oFapcRKVSbnlQTIkmyPYvwuGAhNXOD[oFapcRKVSbnlQTIkmyPYvwuGAhNXsz]['func'])(value)
   elif oFapcRKVSbnlQTIkmyPYvwuGAhNXOD[oFapcRKVSbnlQTIkmyPYvwuGAhNXsz]['type']=='int':
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXtz(value)==oFapcRKVSbnlQTIkmyPYvwuGAhNXti:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXsL=oFapcRKVSbnlQTIkmyPYvwuGAhNXti(value)
    else:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXsL=0
    oFapcRKVSbnlQTIkmyPYvwuGAhNXtC(video_InfoTag,oFapcRKVSbnlQTIkmyPYvwuGAhNXOD[oFapcRKVSbnlQTIkmyPYvwuGAhNXsz]['func'])(oFapcRKVSbnlQTIkmyPYvwuGAhNXsL)
   elif oFapcRKVSbnlQTIkmyPYvwuGAhNXOD[oFapcRKVSbnlQTIkmyPYvwuGAhNXsz]['type']=='actor':
    if value!=[]:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXtC(video_InfoTag,oFapcRKVSbnlQTIkmyPYvwuGAhNXOD[oFapcRKVSbnlQTIkmyPYvwuGAhNXsz]['func'])([xbmc.Actor(name)for name in value])
   elif oFapcRKVSbnlQTIkmyPYvwuGAhNXOD[oFapcRKVSbnlQTIkmyPYvwuGAhNXsz]['type']=='list':
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXtz(value)==oFapcRKVSbnlQTIkmyPYvwuGAhNXtr:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXtC(video_InfoTag,oFapcRKVSbnlQTIkmyPYvwuGAhNXOD[oFapcRKVSbnlQTIkmyPYvwuGAhNXsz]['func'])(value)
    else:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXtC(video_InfoTag,oFapcRKVSbnlQTIkmyPYvwuGAhNXOD[oFapcRKVSbnlQTIkmyPYvwuGAhNXsz]['func'])([value])
 def dp_Main_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  (oFapcRKVSbnlQTIkmyPYvwuGAhNXOJ,oFapcRKVSbnlQTIkmyPYvwuGAhNXOB,oFapcRKVSbnlQTIkmyPYvwuGAhNXOx,oFapcRKVSbnlQTIkmyPYvwuGAhNXsO,oFapcRKVSbnlQTIkmyPYvwuGAhNXsM)=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_totalsearch()
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXsC in oFapcRKVSbnlQTIkmyPYvwuGAhNXOM:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse=oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('title')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsr=''
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('mode')=='SEARCH_GROUP' and oFapcRKVSbnlQTIkmyPYvwuGAhNXOJ ==oFapcRKVSbnlQTIkmyPYvwuGAhNXtH:continue
   elif oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('mode')=='SEARCH_HISTORY' and oFapcRKVSbnlQTIkmyPYvwuGAhNXOB==oFapcRKVSbnlQTIkmyPYvwuGAhNXtH:continue
   elif oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('mode')=='TOTAL_SEARCH' and oFapcRKVSbnlQTIkmyPYvwuGAhNXOx ==oFapcRKVSbnlQTIkmyPYvwuGAhNXtH:continue
   elif oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('mode')=='TOTAL_HISTORY' and oFapcRKVSbnlQTIkmyPYvwuGAhNXsO==oFapcRKVSbnlQTIkmyPYvwuGAhNXtH:continue
   elif oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('mode')=='MENU_BOOKMARK' and oFapcRKVSbnlQTIkmyPYvwuGAhNXsM==oFapcRKVSbnlQTIkmyPYvwuGAhNXtH:continue
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('mode'),'sCode':oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('sCode'),'sIndex':oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('sIndex'),'sType':oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('sType'),'suburl':oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('suburl'),'subapi':oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('subapi'),'page':oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('page'),'orderby':oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('orderby'),'ordernm':oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('ordernm')}
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsq=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsJ =oFapcRKVSbnlQTIkmyPYvwuGAhNXte
   else:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsq=oFapcRKVSbnlQTIkmyPYvwuGAhNXte
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsJ =oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsB={'title':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'plot':oFapcRKVSbnlQTIkmyPYvwuGAhNXse}
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('mode')=='XXX':oFapcRKVSbnlQTIkmyPYvwuGAhNXsB=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj
   if 'icon' in oFapcRKVSbnlQTIkmyPYvwuGAhNXsC:oFapcRKVSbnlQTIkmyPYvwuGAhNXsr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',oFapcRKVSbnlQTIkmyPYvwuGAhNXsC.get('icon')) 
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img=oFapcRKVSbnlQTIkmyPYvwuGAhNXsr,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXsB,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXsq,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf,isLink=oFapcRKVSbnlQTIkmyPYvwuGAhNXsJ)
  xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXte)
 def dp_Search_Group(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  if 'search_key' in args:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMs=args.get('search_key')
  else:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMs=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not oFapcRKVSbnlQTIkmyPYvwuGAhNXMs:
    return
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXME in oFapcRKVSbnlQTIkmyPYvwuGAhNXOE:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMg =oFapcRKVSbnlQTIkmyPYvwuGAhNXME.get('mode')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMD=oFapcRKVSbnlQTIkmyPYvwuGAhNXME.get('sType')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse=oFapcRKVSbnlQTIkmyPYvwuGAhNXME.get('title')
   (oFapcRKVSbnlQTIkmyPYvwuGAhNXMW,oFapcRKVSbnlQTIkmyPYvwuGAhNXMt)=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_Search_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXMs,oFapcRKVSbnlQTIkmyPYvwuGAhNXMD,1,exclusion21=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_exclusion21())
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsB={'plot':'검색어 : '+oFapcRKVSbnlQTIkmyPYvwuGAhNXMs+'\n\n'+oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.Search_FreeList(oFapcRKVSbnlQTIkmyPYvwuGAhNXMW)}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':oFapcRKVSbnlQTIkmyPYvwuGAhNXMg,'sType':oFapcRKVSbnlQTIkmyPYvwuGAhNXMD,'search_key':oFapcRKVSbnlQTIkmyPYvwuGAhNXMs,'page':'1',}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img='',infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXsB,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXOE)>0:xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXte)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.Save_Searched_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXMs)
 def Search_FreeList(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,search_list):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMd=''
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMU=7
  try:
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(search_list)==0:return '검색결과 없음'
   for i in oFapcRKVSbnlQTIkmyPYvwuGAhNXtq(oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(search_list)):
    if i>=oFapcRKVSbnlQTIkmyPYvwuGAhNXMU:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXMd=oFapcRKVSbnlQTIkmyPYvwuGAhNXMd+'...'
     break
    oFapcRKVSbnlQTIkmyPYvwuGAhNXMd=oFapcRKVSbnlQTIkmyPYvwuGAhNXMd+search_list[i]['title']+'\n'
  except:
   return ''
  return oFapcRKVSbnlQTIkmyPYvwuGAhNXMd
 def dp_Watch_Group(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMj in oFapcRKVSbnlQTIkmyPYvwuGAhNXOg:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse=oFapcRKVSbnlQTIkmyPYvwuGAhNXMj.get('title')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':oFapcRKVSbnlQTIkmyPYvwuGAhNXMj.get('mode'),'sType':oFapcRKVSbnlQTIkmyPYvwuGAhNXMj.get('sType')}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img='',infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXOg)>0:xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXte)
 def dp_Search_History(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMi=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.Load_List_File('search')
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMe in oFapcRKVSbnlQTIkmyPYvwuGAhNXMi:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMH=oFapcRKVSbnlQTIkmyPYvwuGAhNXtL(urllib.parse.parse_qsl(oFapcRKVSbnlQTIkmyPYvwuGAhNXMe))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMz=oFapcRKVSbnlQTIkmyPYvwuGAhNXMH.get('skey').strip()
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'SEARCH_GROUP','search_key':oFapcRKVSbnlQTIkmyPYvwuGAhNXMz,}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXML={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':oFapcRKVSbnlQTIkmyPYvwuGAhNXMz,'vType':'-',}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMC=urllib.parse.urlencode(oFapcRKVSbnlQTIkmyPYvwuGAhNXML)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMr=[('선택된 검색어 ( %s ) 삭제'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXMz),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXMC))]
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXMz,sublabel='',img=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf,ContextMenu=oFapcRKVSbnlQTIkmyPYvwuGAhNXMr)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'plot':'검색목록 전체를 삭제합니다.'}
  oFapcRKVSbnlQTIkmyPYvwuGAhNXse='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img=oFapcRKVSbnlQTIkmyPYvwuGAhNXsr,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf,isLink=oFapcRKVSbnlQTIkmyPYvwuGAhNXte)
  xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_Search_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMD =args.get('sType')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMq =oFapcRKVSbnlQTIkmyPYvwuGAhNXti(args.get('page'))
  if 'search_key' in args:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMs=args.get('search_key')
  else:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMs=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not oFapcRKVSbnlQTIkmyPYvwuGAhNXMs:
    xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle)
    return
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ,oFapcRKVSbnlQTIkmyPYvwuGAhNXMt=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_Search_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXMs,oFapcRKVSbnlQTIkmyPYvwuGAhNXMD,oFapcRKVSbnlQTIkmyPYvwuGAhNXMq,exclusion21=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_exclusion21())
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMx =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('videoid')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEO =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('vidtype')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('title')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEs=oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('thumbnail')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEM =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('age')
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXEM=='18' or oFapcRKVSbnlQTIkmyPYvwuGAhNXEM=='19' or oFapcRKVSbnlQTIkmyPYvwuGAhNXEM=='21':oFapcRKVSbnlQTIkmyPYvwuGAhNXse+=' (%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXEM)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'mediatype':'tvshow' if oFapcRKVSbnlQTIkmyPYvwuGAhNXMD=='vod' else 'movie','mpaa':oFapcRKVSbnlQTIkmyPYvwuGAhNXEM,'title':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'plot':oFapcRKVSbnlQTIkmyPYvwuGAhNXse}
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXMD=='vod':
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'EPISODE_LIST','seasonid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'page':'1',}
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsq=oFapcRKVSbnlQTIkmyPYvwuGAhNXte
   else:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'MOVIE','contentid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'title':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'thumbnail':oFapcRKVSbnlQTIkmyPYvwuGAhNXEs,'age':oFapcRKVSbnlQTIkmyPYvwuGAhNXEM,}
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsq=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMr=[]
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEg={'mode':'VIEW_DETAIL','values':{'videoid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'vidtype':'tvshow' if oFapcRKVSbnlQTIkmyPYvwuGAhNXMD=='vod' else 'movie','contenttype':oFapcRKVSbnlQTIkmyPYvwuGAhNXEO,}}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXED=json.dumps(oFapcRKVSbnlQTIkmyPYvwuGAhNXEg,separators=(',',':'))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXED=base64.standard_b64encode(oFapcRKVSbnlQTIkmyPYvwuGAhNXED.encode()).decode('utf-8')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXED=oFapcRKVSbnlQTIkmyPYvwuGAhNXED.replace('+','%2B')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEW='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXED)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMr.append(('상세정보 조회',oFapcRKVSbnlQTIkmyPYvwuGAhNXEW))
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_makebookmark():
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEg={'videoid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'vidtype':'tvshow' if oFapcRKVSbnlQTIkmyPYvwuGAhNXMD=='vod' else 'movie','vtitle':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'vsubtitle':'','contenttype':oFapcRKVSbnlQTIkmyPYvwuGAhNXEO,}
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEt=json.dumps(oFapcRKVSbnlQTIkmyPYvwuGAhNXEg)
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEt=urllib.parse.quote(oFapcRKVSbnlQTIkmyPYvwuGAhNXEt)
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEW='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXEt)
    oFapcRKVSbnlQTIkmyPYvwuGAhNXMr.append(('(통합) 찜 영상에 추가',oFapcRKVSbnlQTIkmyPYvwuGAhNXEW))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img=oFapcRKVSbnlQTIkmyPYvwuGAhNXEs,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXsq,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf,ContextMenu=oFapcRKVSbnlQTIkmyPYvwuGAhNXMr)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMt:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['mode'] ='SEARCH_LIST' 
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['sType']=oFapcRKVSbnlQTIkmyPYvwuGAhNXMD 
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['page'] =oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['search_key']=oFapcRKVSbnlQTIkmyPYvwuGAhNXMs
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse='[B]%s >>[/B]'%'다음 페이지'
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEd=oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXsr,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMD=='movie':xbmcplugin.setContent(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,'movies')
  else:xbmcplugin.setContent(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_Watch_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMD =args.get('sType')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsU=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_direct_replay()
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.Load_List_File(oFapcRKVSbnlQTIkmyPYvwuGAhNXMD)
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMH=oFapcRKVSbnlQTIkmyPYvwuGAhNXtL(urllib.parse.parse_qsl(oFapcRKVSbnlQTIkmyPYvwuGAhNXMB))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEU =oFapcRKVSbnlQTIkmyPYvwuGAhNXMH.get('code').strip()
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse =oFapcRKVSbnlQTIkmyPYvwuGAhNXMH.get('title').strip()
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEd =oFapcRKVSbnlQTIkmyPYvwuGAhNXMH.get('subtitle').strip()
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXEd=='None':oFapcRKVSbnlQTIkmyPYvwuGAhNXEd=''
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEs=oFapcRKVSbnlQTIkmyPYvwuGAhNXMH.get('img').strip()
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMx =oFapcRKVSbnlQTIkmyPYvwuGAhNXMH.get('videoid').strip()
   try:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEs=oFapcRKVSbnlQTIkmyPYvwuGAhNXEs.replace('\'','\"')
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEs=json.loads(oFapcRKVSbnlQTIkmyPYvwuGAhNXEs)
   except:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXtj
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'plot':'%s\n%s'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,oFapcRKVSbnlQTIkmyPYvwuGAhNXEd)}
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXMD=='vod':
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXsU==oFapcRKVSbnlQTIkmyPYvwuGAhNXtH or oFapcRKVSbnlQTIkmyPYvwuGAhNXMx==oFapcRKVSbnlQTIkmyPYvwuGAhNXtj:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXMf['mediatype']='tvshow'
     oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'SEASON_LIST','videoid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'vidtype':'contentid',}
     oFapcRKVSbnlQTIkmyPYvwuGAhNXsq=oFapcRKVSbnlQTIkmyPYvwuGAhNXte
    else:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXMf['mediatype']='episode'
     oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'VOD','programid':oFapcRKVSbnlQTIkmyPYvwuGAhNXEU,'contentid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'title':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'subtitle':oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,'thumbnail':oFapcRKVSbnlQTIkmyPYvwuGAhNXEs}
     oFapcRKVSbnlQTIkmyPYvwuGAhNXsq=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
   else:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXMf['mediatype']='movie'
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'MOVIE','contentid':oFapcRKVSbnlQTIkmyPYvwuGAhNXEU,'title':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'subtitle':oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,'thumbnail':oFapcRKVSbnlQTIkmyPYvwuGAhNXEs}
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsq=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
   oFapcRKVSbnlQTIkmyPYvwuGAhNXML={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':oFapcRKVSbnlQTIkmyPYvwuGAhNXEU,'vType':oFapcRKVSbnlQTIkmyPYvwuGAhNXMD,}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMC=urllib.parse.urlencode(oFapcRKVSbnlQTIkmyPYvwuGAhNXML)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMr=[('선택된 시청이력 ( %s ) 삭제'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXse),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXMC))]
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXEs,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXsq,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf,ContextMenu=oFapcRKVSbnlQTIkmyPYvwuGAhNXMr)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'plot':'시청목록을 삭제합니다.'}
  oFapcRKVSbnlQTIkmyPYvwuGAhNXse='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':oFapcRKVSbnlQTIkmyPYvwuGAhNXMD,}
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img=oFapcRKVSbnlQTIkmyPYvwuGAhNXsr,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf,isLink=oFapcRKVSbnlQTIkmyPYvwuGAhNXte)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMD=='movie':xbmcplugin.setContent(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,'movies')
  else:xbmcplugin.setContent(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def Load_List_File(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,stype): 
  try:
   if stype=='search':
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEj=oFapcRKVSbnlQTIkmyPYvwuGAhNXOt
   elif stype in['vod','movie']:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=oFapcRKVSbnlQTIkmyPYvwuGAhNXtB(oFapcRKVSbnlQTIkmyPYvwuGAhNXEj,'r',-1,'utf-8')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEi=fp.readlines()
   fp.close()
  except:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEi=[]
  return oFapcRKVSbnlQTIkmyPYvwuGAhNXEi
 def Save_Watched_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,oFapcRKVSbnlQTIkmyPYvwuGAhNXWr,oFapcRKVSbnlQTIkmyPYvwuGAhNXOi):
  try:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEe=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%oFapcRKVSbnlQTIkmyPYvwuGAhNXWr))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEH=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.Load_List_File(oFapcRKVSbnlQTIkmyPYvwuGAhNXWr) 
   fp=oFapcRKVSbnlQTIkmyPYvwuGAhNXtB(oFapcRKVSbnlQTIkmyPYvwuGAhNXEe,'w',-1,'utf-8')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEz=urllib.parse.urlencode(oFapcRKVSbnlQTIkmyPYvwuGAhNXOi)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEz=oFapcRKVSbnlQTIkmyPYvwuGAhNXEz+'\n'
   fp.write(oFapcRKVSbnlQTIkmyPYvwuGAhNXEz)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEL=0
   for oFapcRKVSbnlQTIkmyPYvwuGAhNXEC in oFapcRKVSbnlQTIkmyPYvwuGAhNXEH:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEr=oFapcRKVSbnlQTIkmyPYvwuGAhNXtL(urllib.parse.parse_qsl(oFapcRKVSbnlQTIkmyPYvwuGAhNXEC))
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEf=oFapcRKVSbnlQTIkmyPYvwuGAhNXOi.get('code').strip()
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEq=oFapcRKVSbnlQTIkmyPYvwuGAhNXEr.get('code').strip()
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXWr=='vod' and oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_direct_replay()==oFapcRKVSbnlQTIkmyPYvwuGAhNXte:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXEf=oFapcRKVSbnlQTIkmyPYvwuGAhNXOi.get('videoid').strip()
     oFapcRKVSbnlQTIkmyPYvwuGAhNXEq=oFapcRKVSbnlQTIkmyPYvwuGAhNXEr.get('videoid').strip()if oFapcRKVSbnlQTIkmyPYvwuGAhNXEq!=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj else '-'
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXEf!=oFapcRKVSbnlQTIkmyPYvwuGAhNXEq:
     fp.write(oFapcRKVSbnlQTIkmyPYvwuGAhNXEC)
     oFapcRKVSbnlQTIkmyPYvwuGAhNXEL+=1
     if oFapcRKVSbnlQTIkmyPYvwuGAhNXEL>=50:break
   fp.close()
  except:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtj
 def dp_History_Remove(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXEJ=args.get('delType')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXEB =args.get('sKey')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXEx =args.get('vType')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOH=xbmcgui.Dialog()
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXEJ=='SEARCH_ALL':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgO=oFapcRKVSbnlQTIkmyPYvwuGAhNXOH.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXEJ=='SEARCH_ONE':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgO=oFapcRKVSbnlQTIkmyPYvwuGAhNXOH.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXEJ=='WATCH_ALL':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgO=oFapcRKVSbnlQTIkmyPYvwuGAhNXOH.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXEJ=='WATCH_ONE':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgO=oFapcRKVSbnlQTIkmyPYvwuGAhNXOH.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXgO==oFapcRKVSbnlQTIkmyPYvwuGAhNXtH:sys.exit()
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXEJ=='SEARCH_ALL':
   if os.path.isfile(oFapcRKVSbnlQTIkmyPYvwuGAhNXOt):os.remove(oFapcRKVSbnlQTIkmyPYvwuGAhNXOt)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXEJ=='SEARCH_ONE':
   try:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEj=oFapcRKVSbnlQTIkmyPYvwuGAhNXOt
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEH=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.Load_List_File('search') 
    fp=oFapcRKVSbnlQTIkmyPYvwuGAhNXtB(oFapcRKVSbnlQTIkmyPYvwuGAhNXEj,'w',-1,'utf-8')
    for oFapcRKVSbnlQTIkmyPYvwuGAhNXEC in oFapcRKVSbnlQTIkmyPYvwuGAhNXEH:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXEr=oFapcRKVSbnlQTIkmyPYvwuGAhNXtL(urllib.parse.parse_qsl(oFapcRKVSbnlQTIkmyPYvwuGAhNXEC))
     oFapcRKVSbnlQTIkmyPYvwuGAhNXgs=oFapcRKVSbnlQTIkmyPYvwuGAhNXEr.get('skey').strip()
     if oFapcRKVSbnlQTIkmyPYvwuGAhNXEB!=oFapcRKVSbnlQTIkmyPYvwuGAhNXgs:
      fp.write(oFapcRKVSbnlQTIkmyPYvwuGAhNXEC)
    fp.close()
   except:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXtj
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXEJ=='WATCH_ALL':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%oFapcRKVSbnlQTIkmyPYvwuGAhNXEx))
   if os.path.isfile(oFapcRKVSbnlQTIkmyPYvwuGAhNXEj):os.remove(oFapcRKVSbnlQTIkmyPYvwuGAhNXEj)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXEJ=='WATCH_ONE':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%oFapcRKVSbnlQTIkmyPYvwuGAhNXEx))
   try:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEH=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.Load_List_File(oFapcRKVSbnlQTIkmyPYvwuGAhNXEx) 
    fp=oFapcRKVSbnlQTIkmyPYvwuGAhNXtB(oFapcRKVSbnlQTIkmyPYvwuGAhNXEj,'w',-1,'utf-8')
    for oFapcRKVSbnlQTIkmyPYvwuGAhNXEC in oFapcRKVSbnlQTIkmyPYvwuGAhNXEH:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXEr=oFapcRKVSbnlQTIkmyPYvwuGAhNXtL(urllib.parse.parse_qsl(oFapcRKVSbnlQTIkmyPYvwuGAhNXEC))
     oFapcRKVSbnlQTIkmyPYvwuGAhNXgs=oFapcRKVSbnlQTIkmyPYvwuGAhNXEr.get('code').strip()
     if oFapcRKVSbnlQTIkmyPYvwuGAhNXEB!=oFapcRKVSbnlQTIkmyPYvwuGAhNXgs:
      fp.write(oFapcRKVSbnlQTIkmyPYvwuGAhNXEC)
    fp.close()
   except:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXtj
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,oFapcRKVSbnlQTIkmyPYvwuGAhNXMs):
  try:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgM=oFapcRKVSbnlQTIkmyPYvwuGAhNXOt
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEH=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.Load_List_File('search') 
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgE={'skey':oFapcRKVSbnlQTIkmyPYvwuGAhNXMs.strip()}
   fp=oFapcRKVSbnlQTIkmyPYvwuGAhNXtB(oFapcRKVSbnlQTIkmyPYvwuGAhNXgM,'w',-1,'utf-8')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEz=urllib.parse.urlencode(oFapcRKVSbnlQTIkmyPYvwuGAhNXgE)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEz=oFapcRKVSbnlQTIkmyPYvwuGAhNXEz+'\n'
   fp.write(oFapcRKVSbnlQTIkmyPYvwuGAhNXEz)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEL=0
   for oFapcRKVSbnlQTIkmyPYvwuGAhNXEC in oFapcRKVSbnlQTIkmyPYvwuGAhNXEH:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEr=oFapcRKVSbnlQTIkmyPYvwuGAhNXtL(urllib.parse.parse_qsl(oFapcRKVSbnlQTIkmyPYvwuGAhNXEC))
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEf=oFapcRKVSbnlQTIkmyPYvwuGAhNXgE.get('skey').strip()
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEq=oFapcRKVSbnlQTIkmyPYvwuGAhNXEr.get('skey').strip()
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXEf!=oFapcRKVSbnlQTIkmyPYvwuGAhNXEq:
     fp.write(oFapcRKVSbnlQTIkmyPYvwuGAhNXEC)
     oFapcRKVSbnlQTIkmyPYvwuGAhNXEL+=1
     if oFapcRKVSbnlQTIkmyPYvwuGAhNXEL>=50:break
   fp.close()
  except:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtj
 def dp_Global_Search(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=args.get('mode')
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='TOTAL_SEARCH':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgD='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgD='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(oFapcRKVSbnlQTIkmyPYvwuGAhNXgD)
 def dp_Bookmark_Menu(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgD='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(oFapcRKVSbnlQTIkmyPYvwuGAhNXgD)
 def login_main(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  (oFapcRKVSbnlQTIkmyPYvwuGAhNXgW,oFapcRKVSbnlQTIkmyPYvwuGAhNXgt,oFapcRKVSbnlQTIkmyPYvwuGAhNXgd)=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_account()
  if not(oFapcRKVSbnlQTIkmyPYvwuGAhNXgW and oFapcRKVSbnlQTIkmyPYvwuGAhNXgt):
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOH=xbmcgui.Dialog()
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgO=oFapcRKVSbnlQTIkmyPYvwuGAhNXOH.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXgO==oFapcRKVSbnlQTIkmyPYvwuGAhNXte:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.cookiefile_check()==oFapcRKVSbnlQTIkmyPYvwuGAhNXte:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgU=0
   while oFapcRKVSbnlQTIkmyPYvwuGAhNXte:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXgU+=1
    time.sleep(0.05)
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXgU>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgj=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.GetCredential(oFapcRKVSbnlQTIkmyPYvwuGAhNXgW,oFapcRKVSbnlQTIkmyPYvwuGAhNXgt,oFapcRKVSbnlQTIkmyPYvwuGAhNXgd)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXgj:oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXgj==oFapcRKVSbnlQTIkmyPYvwuGAhNXtH:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsj =args.get('orderby')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.set_winEpisodeOrderby(oFapcRKVSbnlQTIkmyPYvwuGAhNXsj)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMg =args.get('mode')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgi =args.get('contentid')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXge =args.get('pvrmode')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgH=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_selQuality()
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsE =oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_play()
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log(oFapcRKVSbnlQTIkmyPYvwuGAhNXgi+' - '+oFapcRKVSbnlQTIkmyPYvwuGAhNXMg)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='SPORTS':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgz=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.GetSportsURL(oFapcRKVSbnlQTIkmyPYvwuGAhNXgi,oFapcRKVSbnlQTIkmyPYvwuGAhNXgH)
  else:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgz=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.GetStreamingURL(oFapcRKVSbnlQTIkmyPYvwuGAhNXMg,oFapcRKVSbnlQTIkmyPYvwuGAhNXgi,oFapcRKVSbnlQTIkmyPYvwuGAhNXgH,oFapcRKVSbnlQTIkmyPYvwuGAhNXge,playOption=oFapcRKVSbnlQTIkmyPYvwuGAhNXsE)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgL={'user-agent':oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.USER_AGENT}
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgC=oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_cookie'] 
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgr=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.make_stream_header(oFapcRKVSbnlQTIkmyPYvwuGAhNXgL,oFapcRKVSbnlQTIkmyPYvwuGAhNXgC)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgf='{}|{}'.format(oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_url'],oFapcRKVSbnlQTIkmyPYvwuGAhNXgr)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log('surl : '+oFapcRKVSbnlQTIkmyPYvwuGAhNXgf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_url']=='':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_noti(__language__(30907).encode('utf8'))
   return
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsg,oFapcRKVSbnlQTIkmyPYvwuGAhNXsD=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_proxyport()
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgq=urllib.parse.urlparse(oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_url'])
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgq=oFapcRKVSbnlQTIkmyPYvwuGAhNXgq.path.strip('/').split('/')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgq=oFapcRKVSbnlQTIkmyPYvwuGAhNXgq[oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXgq)-1] 
  if (oFapcRKVSbnlQTIkmyPYvwuGAhNXsg==oFapcRKVSbnlQTIkmyPYvwuGAhNXte and args.get('mode')in['VOD','MOVIE']and(oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['playParam']['hdr']=='hdr' or oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['playParam']['uhd']=='uhd')):
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXgq.split('.')[1]=='mpd':
    oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Wavve_Parse_mpd(oFapcRKVSbnlQTIkmyPYvwuGAhNXgz)
   else:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Wavve_Parse_m3u8(oFapcRKVSbnlQTIkmyPYvwuGAhNXgz)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgJ={'addon':'wavvem','playOption':oFapcRKVSbnlQTIkmyPYvwuGAhNXsE,}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgJ=json.dumps(oFapcRKVSbnlQTIkmyPYvwuGAhNXgJ,separators=(',',':'))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgJ=base64.standard_b64encode(oFapcRKVSbnlQTIkmyPYvwuGAhNXgJ.encode()).decode('utf-8')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgf ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(oFapcRKVSbnlQTIkmyPYvwuGAhNXsD,oFapcRKVSbnlQTIkmyPYvwuGAhNXgf,oFapcRKVSbnlQTIkmyPYvwuGAhNXgJ)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log('surl : '+oFapcRKVSbnlQTIkmyPYvwuGAhNXgf)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgB=xbmcgui.ListItem(path=oFapcRKVSbnlQTIkmyPYvwuGAhNXgf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_drm']:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log('!!streaming_drm!!')
   if 'licensetoken' in oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_drm']:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXgx=oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_drm']['licensetoken']
    oFapcRKVSbnlQTIkmyPYvwuGAhNXDO =oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_drm']['licenseurl']
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='MOVIE':
     oFapcRKVSbnlQTIkmyPYvwuGAhNXDs='https://www.wavve.com/player/movie?movieid=%s'%oFapcRKVSbnlQTIkmyPYvwuGAhNXgi
    else:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXDs='https://www.wavve.com/player/vod?programid=%s&page=1'%oFapcRKVSbnlQTIkmyPYvwuGAhNXgi
    oFapcRKVSbnlQTIkmyPYvwuGAhNXDM={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':oFapcRKVSbnlQTIkmyPYvwuGAhNXgx,'referer':oFapcRKVSbnlQTIkmyPYvwuGAhNXDs,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.USER_AGENT,}
   else:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXgx=oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_drm']['customdata']
    oFapcRKVSbnlQTIkmyPYvwuGAhNXDO =oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_drm']['drmhost']
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='MOVIE':
     oFapcRKVSbnlQTIkmyPYvwuGAhNXDs='https://www.wavve.com/player/movie?movieid=%s'%oFapcRKVSbnlQTIkmyPYvwuGAhNXgi
    else:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXDs='https://www.wavve.com/player/vod?programid=%s&page=1'%oFapcRKVSbnlQTIkmyPYvwuGAhNXgi
    oFapcRKVSbnlQTIkmyPYvwuGAhNXDM={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':oFapcRKVSbnlQTIkmyPYvwuGAhNXgx,'referer':oFapcRKVSbnlQTIkmyPYvwuGAhNXDs,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.USER_AGENT,}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXDE=oFapcRKVSbnlQTIkmyPYvwuGAhNXDO+'|'+urllib.parse.urlencode(oFapcRKVSbnlQTIkmyPYvwuGAhNXDM)+'|R{SSM}|'
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setProperty('inputstream','inputstream.adaptive')
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.KodiVersion<=20:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setProperty('inputstream.adaptive.manifest_type','mpd')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setProperty('inputstream.adaptive.license_key',oFapcRKVSbnlQTIkmyPYvwuGAhNXDE)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setProperty('inputstream.adaptive.stream_headers',oFapcRKVSbnlQTIkmyPYvwuGAhNXgr)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setProperty('inputstream.adaptive.manifest_headers',oFapcRKVSbnlQTIkmyPYvwuGAhNXgr)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg in['VOD','MOVIE']:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setContentLookup(oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setMimeType('application/x-mpegURL')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setProperty('inputstream','inputstream.adaptive')
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.KodiVersion<=20:
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_action']=='hls':
     oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setProperty('inputstream.adaptive.manifest_type','hls')
    else:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setProperty('inputstream.adaptive.manifest_type','mpd')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setProperty('inputstream.adaptive.stream_headers',oFapcRKVSbnlQTIkmyPYvwuGAhNXgr)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setProperty('inputstream.adaptive.manifest_headers',oFapcRKVSbnlQTIkmyPYvwuGAhNXgr)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_vtt']:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgB.setSubtitles([oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_vtt']])
  xbmcplugin.setResolvedUrl(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,oFapcRKVSbnlQTIkmyPYvwuGAhNXte,oFapcRKVSbnlQTIkmyPYvwuGAhNXgB)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDg=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_preview']:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_noti(oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_preview'].encode('utf-8'))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXDg=oFapcRKVSbnlQTIkmyPYvwuGAhNXte
  else:
   if '/preview.' in urllib.parse.urlsplit(oFapcRKVSbnlQTIkmyPYvwuGAhNXgz['stream_url']).path:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_noti(__language__(30908).encode('utf8'))
    oFapcRKVSbnlQTIkmyPYvwuGAhNXDg=oFapcRKVSbnlQTIkmyPYvwuGAhNXte
  try:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXDW=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and oFapcRKVSbnlQTIkmyPYvwuGAhNXDg==oFapcRKVSbnlQTIkmyPYvwuGAhNXtH and oFapcRKVSbnlQTIkmyPYvwuGAhNXDW!='-':
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'code':oFapcRKVSbnlQTIkmyPYvwuGAhNXDW,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.Save_Watched_List(args.get('mode').lower(),oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  except:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtj
 def logout(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOH=xbmcgui.Dialog()
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgO=oFapcRKVSbnlQTIkmyPYvwuGAhNXOH.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXgO==oFapcRKVSbnlQTIkmyPYvwuGAhNXtH:sys.exit()
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Init_WV_Total()
  if os.path.isfile(oFapcRKVSbnlQTIkmyPYvwuGAhNXOW):os.remove(oFapcRKVSbnlQTIkmyPYvwuGAhNXOW)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDt =oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_Now_Datetime()
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDd=oFapcRKVSbnlQTIkmyPYvwuGAhNXDt+datetime.timedelta(days=oFapcRKVSbnlQTIkmyPYvwuGAhNXti(__addon__.getSetting('cache_ttl')))
  (oFapcRKVSbnlQTIkmyPYvwuGAhNXgW,oFapcRKVSbnlQTIkmyPYvwuGAhNXgt,oFapcRKVSbnlQTIkmyPYvwuGAhNXgd)=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_account()
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Save_session_acount(oFapcRKVSbnlQTIkmyPYvwuGAhNXgW,oFapcRKVSbnlQTIkmyPYvwuGAhNXgt,oFapcRKVSbnlQTIkmyPYvwuGAhNXgd)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.WV['account']['token_limit']=oFapcRKVSbnlQTIkmyPYvwuGAhNXDd.strftime('%Y%m%d')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.JsonFile_Save(oFapcRKVSbnlQTIkmyPYvwuGAhNXOW,oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.WV)
 def cookiefile_check(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.WV=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.JsonFile_Load(oFapcRKVSbnlQTIkmyPYvwuGAhNXOW)
  if 'account' not in oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.WV:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Init_WV_Total()
   return oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  if 'uuid' not in oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.WV.get('cookies'):
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Init_WV_Total()
   return oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  (oFapcRKVSbnlQTIkmyPYvwuGAhNXDU,oFapcRKVSbnlQTIkmyPYvwuGAhNXDj,oFapcRKVSbnlQTIkmyPYvwuGAhNXDi)=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_account()
  (oFapcRKVSbnlQTIkmyPYvwuGAhNXDe,oFapcRKVSbnlQTIkmyPYvwuGAhNXDH,oFapcRKVSbnlQTIkmyPYvwuGAhNXDz)=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Load_session_acount()
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXDU!=oFapcRKVSbnlQTIkmyPYvwuGAhNXDe or oFapcRKVSbnlQTIkmyPYvwuGAhNXDj!=oFapcRKVSbnlQTIkmyPYvwuGAhNXDH or oFapcRKVSbnlQTIkmyPYvwuGAhNXDi!=oFapcRKVSbnlQTIkmyPYvwuGAhNXDz:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Init_WV_Total()
   return oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXti(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>oFapcRKVSbnlQTIkmyPYvwuGAhNXti(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.WV['account']['token_limit']):
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Init_WV_Total()
   return oFapcRKVSbnlQTIkmyPYvwuGAhNXtH
  return oFapcRKVSbnlQTIkmyPYvwuGAhNXte
 def dp_LiveCatagory_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDL =args.get('sCode')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDC=args.get('sIndex')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ,oFapcRKVSbnlQTIkmyPYvwuGAhNXDr=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_LiveCatagory_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXDL,oFapcRKVSbnlQTIkmyPYvwuGAhNXDC)
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('title')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'LIVE_LIST','genre':oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('genre'),'baseapi':oFapcRKVSbnlQTIkmyPYvwuGAhNXDr}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsB={'title':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'plot':oFapcRKVSbnlQTIkmyPYvwuGAhNXse}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img='',infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXsB,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ)>0:xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_MainCatagory_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDL =args.get('sCode')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDC=args.get('sIndex')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMD =args.get('sType')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_MainCatagory_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXDL,oFapcRKVSbnlQTIkmyPYvwuGAhNXDC,oFapcRKVSbnlQTIkmyPYvwuGAhNXMD)
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXMD in['vod','vod09']:
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('subtype')=='catagory':
     oFapcRKVSbnlQTIkmyPYvwuGAhNXMg='PROGRAM_LIST'
    else:
     oFapcRKVSbnlQTIkmyPYvwuGAhNXMg='SUPERSECTION_LIST'
   elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMD=='movie':
    oFapcRKVSbnlQTIkmyPYvwuGAhNXMg='MOVIE_LIST'
   else:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=''
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse='%s (%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('title'),args.get('ordernm'))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':oFapcRKVSbnlQTIkmyPYvwuGAhNXMg,'suburl':oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('suburl'),'subapi':oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_exclusion21():
    if oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('title')=='성인' or oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('title')=='성인+' or oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('title')=='에로티시즘' or oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('title')=='19':continue
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsB={'title':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'plot':oFapcRKVSbnlQTIkmyPYvwuGAhNXse}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img='',infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXsB,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ)>0:xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_Program_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDf =args.get('subapi')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMq=oFapcRKVSbnlQTIkmyPYvwuGAhNXti(args.get('page'))
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsj =args.get('orderby')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log('dp_Program_List')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log(oFapcRKVSbnlQTIkmyPYvwuGAhNXDf)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ,oFapcRKVSbnlQTIkmyPYvwuGAhNXMt=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_Program_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXDf,oFapcRKVSbnlQTIkmyPYvwuGAhNXMq,oFapcRKVSbnlQTIkmyPYvwuGAhNXsj)
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMx =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('videoid')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEO =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('vidtype')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('title')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEs=oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('thumbnail')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEM =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('age')
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXEM=='18' or oFapcRKVSbnlQTIkmyPYvwuGAhNXEM=='19' or oFapcRKVSbnlQTIkmyPYvwuGAhNXEM=='21':oFapcRKVSbnlQTIkmyPYvwuGAhNXse+=' (%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXEM)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsB={'plot':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'mpaa':oFapcRKVSbnlQTIkmyPYvwuGAhNXEM,'mediatype':'tvshow','title':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'SEASON_LIST','videoid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'vidtype':oFapcRKVSbnlQTIkmyPYvwuGAhNXEO,}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMr=[]
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEg={'mode':'VIEW_DETAIL','values':{'videoid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'vidtype':'tvshow','contenttype':oFapcRKVSbnlQTIkmyPYvwuGAhNXEO,}}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXED=json.dumps(oFapcRKVSbnlQTIkmyPYvwuGAhNXEg,separators=(',',':'))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXED=base64.standard_b64encode(oFapcRKVSbnlQTIkmyPYvwuGAhNXED.encode()).decode('utf-8')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXED=oFapcRKVSbnlQTIkmyPYvwuGAhNXED.replace('+','%2B')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEW='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXED)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMr.append(('상세정보 조회',oFapcRKVSbnlQTIkmyPYvwuGAhNXEW))
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_makebookmark():
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEg={'videoid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'vidtype':'tvshow','vtitle':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'vsubtitle':'','contenttype':oFapcRKVSbnlQTIkmyPYvwuGAhNXEO,}
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEt=json.dumps(oFapcRKVSbnlQTIkmyPYvwuGAhNXEg)
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEt=urllib.parse.quote(oFapcRKVSbnlQTIkmyPYvwuGAhNXEt)
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEW='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXEt)
    oFapcRKVSbnlQTIkmyPYvwuGAhNXMr.append(('(통합) 찜 영상에 추가',oFapcRKVSbnlQTIkmyPYvwuGAhNXEW))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img=oFapcRKVSbnlQTIkmyPYvwuGAhNXEs,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXsB,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf,ContextMenu=oFapcRKVSbnlQTIkmyPYvwuGAhNXMr)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMt:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['mode'] ='PROGRAM_LIST' 
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['subapi']=oFapcRKVSbnlQTIkmyPYvwuGAhNXDf 
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['page'] =oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse='[B]%s >>[/B]'%'다음 페이지'
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEd=oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXsr,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  xbmcplugin.setContent(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,'tvshows')
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ)>0:xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_Season_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMx=args.get('videoid')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXEO=args.get('vidtype')
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXEO=='contentid':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgi=oFapcRKVSbnlQTIkmyPYvwuGAhNXMx
   oFapcRKVSbnlQTIkmyPYvwuGAhNXDq =oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.ContentidToSeasonid(oFapcRKVSbnlQTIkmyPYvwuGAhNXMx)
  else:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgi=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.ProgramidToContentid(oFapcRKVSbnlQTIkmyPYvwuGAhNXMx)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXDq =oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.ContentidToSeasonid(oFapcRKVSbnlQTIkmyPYvwuGAhNXgi)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDJ=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_Season_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXDq)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXDJ)>1:
   for oFapcRKVSbnlQTIkmyPYvwuGAhNXDB in oFapcRKVSbnlQTIkmyPYvwuGAhNXDJ:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXDx=oFapcRKVSbnlQTIkmyPYvwuGAhNXDB.get('season_Id')
    oFapcRKVSbnlQTIkmyPYvwuGAhNXWO=oFapcRKVSbnlQTIkmyPYvwuGAhNXDB.get('season_Nm')
    oFapcRKVSbnlQTIkmyPYvwuGAhNXWs=oFapcRKVSbnlQTIkmyPYvwuGAhNXDB.get('programNm')
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEs=oFapcRKVSbnlQTIkmyPYvwuGAhNXDB.get('thumbnail')
    oFapcRKVSbnlQTIkmyPYvwuGAhNXWM =oFapcRKVSbnlQTIkmyPYvwuGAhNXDB.get('synopsis')
    oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'mediatype':'tvshow','title':oFapcRKVSbnlQTIkmyPYvwuGAhNXWO,'plot':oFapcRKVSbnlQTIkmyPYvwuGAhNXWM,}
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'EPISODE_LIST','seasonid':oFapcRKVSbnlQTIkmyPYvwuGAhNXDx,'page':'1',}
    oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXWO,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXWs,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXEs,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf,ContextMenu=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj)
   xbmcplugin.setContent(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
  else:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWE={'seasonid':oFapcRKVSbnlQTIkmyPYvwuGAhNXDq,'page':'1',}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Episode_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXWE)
 def dp_Episode_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDq =args.get('seasonid')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMq =oFapcRKVSbnlQTIkmyPYvwuGAhNXti(args.get('page'))
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ,oFapcRKVSbnlQTIkmyPYvwuGAhNXMt=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_Episode_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXDq,oFapcRKVSbnlQTIkmyPYvwuGAhNXMq,orderby=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_winEpisodeOrderby())
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEd=oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('episodenumber')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWg ='[%s]\n\n%s'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('episodetitle'),oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('synopsis'))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'mediatype':'episode','title':oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('programtitle'),'plot':oFapcRKVSbnlQTIkmyPYvwuGAhNXWg,'cast':oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('episodeactors'),}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'VOD','programid':oFapcRKVSbnlQTIkmyPYvwuGAhNXDq,'contentid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('contentid'),'thumbnail':oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('thumbnail'),'title':oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('programtitle'),'subtitle':oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('programtitle'),sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('thumbnail'),infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMq==1:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'plot':'정렬순서를 변경합니다.'}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['mode'] ='ORDER_BY' 
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_winEpisodeOrderby()=='desc':
    oFapcRKVSbnlQTIkmyPYvwuGAhNXse='정렬순서변경 : 최신화부터 -> 1회부터'
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['orderby']='asc'
   else:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXse='정렬순서변경 : 1회부터 -> 최신화부터'
    oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['orderby']='desc'
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img=oFapcRKVSbnlQTIkmyPYvwuGAhNXsr,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf,isLink=oFapcRKVSbnlQTIkmyPYvwuGAhNXte)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMt:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['mode'] ='EPISODE_LIST' 
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['seasonid']=oFapcRKVSbnlQTIkmyPYvwuGAhNXDq
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['page'] =oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse='[B]%s >>[/B]'%'다음 페이지'
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEd=oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXsr,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  xbmcplugin.setContent(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,'episodes')
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ)>0:xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_SuperSection_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWD =args.get('suburl')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDf =args.get('subapi')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log('dp_SuperSection_List')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log('suburl : '+oFapcRKVSbnlQTIkmyPYvwuGAhNXWD)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log('subapi : '+oFapcRKVSbnlQTIkmyPYvwuGAhNXDf)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_SuperMultiSection_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXWD)
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('title')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXDf =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('subapi')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWt=oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('cell_type')
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXDf.find('contenttype=movie')>=0 or oFapcRKVSbnlQTIkmyPYvwuGAhNXDf.find('mtype=svod')>=0:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXMg='MOVIE_LIST'
   elif re.search('themes/2\d{4}',oFapcRKVSbnlQTIkmyPYvwuGAhNXDf)or re.search('themes-band/9\d{4}',oFapcRKVSbnlQTIkmyPYvwuGAhNXDf):
    oFapcRKVSbnlQTIkmyPYvwuGAhNXMg='MOVIE_LIST'
   else:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXMg='PROGRAM_LIST'
   '''
   if subapi.find('mtype=svod') >= 0 or subapi.find('mtype=ppv') >= 0 or subapi.find('contenttype=movie') >= 0: #영화 #20201107
    mode = 'MOVIE_LIST'
   elif subapi.find('contenttype=program') >= 0:
    mode = 'PROGRAM_LIST'
   elif cell_type == 'band_71': # band_71 #20201107
    mode   = 'SUPERSECTION_LIST'
    (temp_url, temp_api) = self.WavveObj.Baseapi_Parse(subapi)
    suburl = temp_api.get('api')
    subapi = ''
   elif cell_type == 'band_2': # band_2
    mode = 'BAND2SECTION_LIST'
   elif cell_type == 'band_live':
    mode = 'BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}', subapi) :
    mode = 'MOVIE_LIST'
   else: # band_10
    mode = 'PROGRAM_LIST'
   '''   
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'plot':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'mediatype':'tvshow',}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':oFapcRKVSbnlQTIkmyPYvwuGAhNXMg,'suburl':oFapcRKVSbnlQTIkmyPYvwuGAhNXWD,'subapi':oFapcRKVSbnlQTIkmyPYvwuGAhNXDf,'page':'1',}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ)>0:xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_BandLiveSection_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDf =args.get('subapi')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMq=oFapcRKVSbnlQTIkmyPYvwuGAhNXti(args.get('page'))
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ,oFapcRKVSbnlQTIkmyPYvwuGAhNXMt=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_BandLiveSection_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXDf,oFapcRKVSbnlQTIkmyPYvwuGAhNXMq)
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWd =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('channelid')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWU =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('studio')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWj=oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('tvshowtitle')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEs =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('thumbnail')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEM =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('age')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'mediatype':'tvshow','mpaa':oFapcRKVSbnlQTIkmyPYvwuGAhNXEM,'title':'%s < %s >'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXWU,oFapcRKVSbnlQTIkmyPYvwuGAhNXWj),'tvshowtitle':oFapcRKVSbnlQTIkmyPYvwuGAhNXWj,'studio':oFapcRKVSbnlQTIkmyPYvwuGAhNXWU,'plot':oFapcRKVSbnlQTIkmyPYvwuGAhNXWU}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'LIVE','contentid':oFapcRKVSbnlQTIkmyPYvwuGAhNXWd}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXWU,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXWj,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('thumbnail'),infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMt:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['mode'] ='BANDLIVESECTION_LIST' 
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['subapi']=oFapcRKVSbnlQTIkmyPYvwuGAhNXDf
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['page'] =oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse='[B]%s >>[/B]'%'다음 페이지'
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEd=oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXsr,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ)>0:xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_Band2Section_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDf =args.get('subapi')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMq=oFapcRKVSbnlQTIkmyPYvwuGAhNXti(args.get('page'))
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ,oFapcRKVSbnlQTIkmyPYvwuGAhNXMt=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_Band2Section_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXDf,oFapcRKVSbnlQTIkmyPYvwuGAhNXMq)
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('programtitle')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEd =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('episodetitle')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'plot':oFapcRKVSbnlQTIkmyPYvwuGAhNXse+'\n\n'+oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,'mpaa':oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('age'),'mediatype':'episode'}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'VOD','programid':'-','contentid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('videoid'),'thumbnail':oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('thumbnail'),'title':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'subtitle':oFapcRKVSbnlQTIkmyPYvwuGAhNXEd}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('thumbnail'),infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMt:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['mode'] ='BAND2SECTION_LIST' 
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['subapi']=oFapcRKVSbnlQTIkmyPYvwuGAhNXDf
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['page'] =oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse='[B]%s >>[/B]'%'다음 페이지'
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEd=oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXsr,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ)>0:xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_Movie_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDf =args.get('subapi')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMq=oFapcRKVSbnlQTIkmyPYvwuGAhNXti(args.get('page'))
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsj =args.get('orderby')or '-'
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log('dp_Movie_List')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log(oFapcRKVSbnlQTIkmyPYvwuGAhNXDf)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ,oFapcRKVSbnlQTIkmyPYvwuGAhNXMt=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_Movie_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXDf,oFapcRKVSbnlQTIkmyPYvwuGAhNXMq,oFapcRKVSbnlQTIkmyPYvwuGAhNXsj)
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMx =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('videoid')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEO =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('vidtype')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('title')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEs=oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('thumbnail')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEM =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('age')
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXEM=='18' or oFapcRKVSbnlQTIkmyPYvwuGAhNXEM=='19' or oFapcRKVSbnlQTIkmyPYvwuGAhNXEM=='21':oFapcRKVSbnlQTIkmyPYvwuGAhNXse+=' (%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXEM)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'plot':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'mpaa':oFapcRKVSbnlQTIkmyPYvwuGAhNXEM,'mediatype':'movie'}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'MOVIE','contentid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'title':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'thumbnail':oFapcRKVSbnlQTIkmyPYvwuGAhNXEs,'age':oFapcRKVSbnlQTIkmyPYvwuGAhNXEM,}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMr=[]
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEg={'mode':'VIEW_DETAIL','values':{'videoid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'vidtype':'movie','contenttype':oFapcRKVSbnlQTIkmyPYvwuGAhNXEO,}}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXED=json.dumps(oFapcRKVSbnlQTIkmyPYvwuGAhNXEg,separators=(',',':'))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXED=base64.standard_b64encode(oFapcRKVSbnlQTIkmyPYvwuGAhNXED.encode()).decode('utf-8')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXED=oFapcRKVSbnlQTIkmyPYvwuGAhNXED.replace('+','%2B')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEW='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXED)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMr.append(('상세정보 조회',oFapcRKVSbnlQTIkmyPYvwuGAhNXEW))
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.get_settings_makebookmark():
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEg={'videoid':oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,'vidtype':'movie','vtitle':oFapcRKVSbnlQTIkmyPYvwuGAhNXse,'vsubtitle':'','contenttype':'programid',}
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEt=json.dumps(oFapcRKVSbnlQTIkmyPYvwuGAhNXEg)
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEt=urllib.parse.quote(oFapcRKVSbnlQTIkmyPYvwuGAhNXEt)
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEW='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXEt)
    oFapcRKVSbnlQTIkmyPYvwuGAhNXMr.append(('(통합) 찜 영상에 추가',oFapcRKVSbnlQTIkmyPYvwuGAhNXEW))
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel='',img=oFapcRKVSbnlQTIkmyPYvwuGAhNXEs,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf,ContextMenu=oFapcRKVSbnlQTIkmyPYvwuGAhNXMr)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMt:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['mode'] ='MOVIE_LIST' 
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['subapi']=oFapcRKVSbnlQTIkmyPYvwuGAhNXDf 
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['page'] =oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf['orderby']=oFapcRKVSbnlQTIkmyPYvwuGAhNXsj
   oFapcRKVSbnlQTIkmyPYvwuGAhNXse='[B]%s >>[/B]'%'다음 페이지'
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEd=oFapcRKVSbnlQTIkmyPYvwuGAhNXtJ(oFapcRKVSbnlQTIkmyPYvwuGAhNXMq+1)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXse,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXsr,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXtj,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXte,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  xbmcplugin.setContent(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,'movies')
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ)>0:xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_Set_Bookmark(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWi=urllib.parse.unquote(args.get('bm_param'))
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWi=json.loads(oFapcRKVSbnlQTIkmyPYvwuGAhNXWi)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMx =oFapcRKVSbnlQTIkmyPYvwuGAhNXWi.get('videoid')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXEO =oFapcRKVSbnlQTIkmyPYvwuGAhNXWi.get('vidtype')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWe =oFapcRKVSbnlQTIkmyPYvwuGAhNXWi.get('vtitle')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWH =oFapcRKVSbnlQTIkmyPYvwuGAhNXWi.get('vsubtitle')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWz=oFapcRKVSbnlQTIkmyPYvwuGAhNXWi.get('contenttype')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOH=xbmcgui.Dialog()
  oFapcRKVSbnlQTIkmyPYvwuGAhNXgO=oFapcRKVSbnlQTIkmyPYvwuGAhNXOH.yesno(__language__(30913).encode('utf8'),oFapcRKVSbnlQTIkmyPYvwuGAhNXWe+' \n\n'+__language__(30914))
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXgO==oFapcRKVSbnlQTIkmyPYvwuGAhNXtH:return
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWL=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.GetBookmarkInfo(oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,oFapcRKVSbnlQTIkmyPYvwuGAhNXEO,oFapcRKVSbnlQTIkmyPYvwuGAhNXWz)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWC=json.dumps(oFapcRKVSbnlQTIkmyPYvwuGAhNXWL)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWC=urllib.parse.quote(oFapcRKVSbnlQTIkmyPYvwuGAhNXWC)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXEW ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXWC)
  xbmc.executebuiltin(oFapcRKVSbnlQTIkmyPYvwuGAhNXEW)
 def dp_LiveChannel_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWr =args.get('genre')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXDr=args.get('baseapi')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_LiveChannel_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXWr,oFapcRKVSbnlQTIkmyPYvwuGAhNXDr)
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWd =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('channelid')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWU =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('studio')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWj=oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('tvshowtitle')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEs =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('thumbnail')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXEM =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('age')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWf =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('epg')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'mediatype':'episode','mpaa':oFapcRKVSbnlQTIkmyPYvwuGAhNXEM,'title':'%s < %s >'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXWU,oFapcRKVSbnlQTIkmyPYvwuGAhNXWj),'tvshowtitle':oFapcRKVSbnlQTIkmyPYvwuGAhNXWj,'studio':oFapcRKVSbnlQTIkmyPYvwuGAhNXWU,'plot':'%s\n\n%s'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXWU,oFapcRKVSbnlQTIkmyPYvwuGAhNXWf)}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'LIVE','contentid':oFapcRKVSbnlQTIkmyPYvwuGAhNXWd}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXWU,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXWj,img=oFapcRKVSbnlQTIkmyPYvwuGAhNXEs,infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtf(oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ)>0:xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_Sports_GameList(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,args):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.Get_Sports_Gamelist()
  for oFapcRKVSbnlQTIkmyPYvwuGAhNXMB in oFapcRKVSbnlQTIkmyPYvwuGAhNXMJ:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWq =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('game_date')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWJ =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('game_time')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWB =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('svc_id')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXWx =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('away_team')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtO =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('home_team')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXts=oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('game_status')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtM =oFapcRKVSbnlQTIkmyPYvwuGAhNXMB.get('game_place')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtE ='%s vs %s (%s)'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXWx,oFapcRKVSbnlQTIkmyPYvwuGAhNXtO,oFapcRKVSbnlQTIkmyPYvwuGAhNXtM)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtg =oFapcRKVSbnlQTIkmyPYvwuGAhNXWq+' '+oFapcRKVSbnlQTIkmyPYvwuGAhNXWJ
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXts=='LIVE':
    oFapcRKVSbnlQTIkmyPYvwuGAhNXts='~경기중~'
   elif oFapcRKVSbnlQTIkmyPYvwuGAhNXts=='END':
    oFapcRKVSbnlQTIkmyPYvwuGAhNXts='경기종료'
   elif oFapcRKVSbnlQTIkmyPYvwuGAhNXts=='CANCEL':
    oFapcRKVSbnlQTIkmyPYvwuGAhNXts='취소'
   else:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXts=''
   if oFapcRKVSbnlQTIkmyPYvwuGAhNXts=='':
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEd=oFapcRKVSbnlQTIkmyPYvwuGAhNXtE
   else:
    oFapcRKVSbnlQTIkmyPYvwuGAhNXEd=oFapcRKVSbnlQTIkmyPYvwuGAhNXtE+'  '+oFapcRKVSbnlQTIkmyPYvwuGAhNXts
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMf={'mediatype':'episode','title':oFapcRKVSbnlQTIkmyPYvwuGAhNXtE,'plot':'%s\n\n%s\n\n%s'%(oFapcRKVSbnlQTIkmyPYvwuGAhNXtg,oFapcRKVSbnlQTIkmyPYvwuGAhNXtE,oFapcRKVSbnlQTIkmyPYvwuGAhNXts)}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'SPORTS','contentid':oFapcRKVSbnlQTIkmyPYvwuGAhNXWB}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.add_dir(oFapcRKVSbnlQTIkmyPYvwuGAhNXtg,sublabel=oFapcRKVSbnlQTIkmyPYvwuGAhNXEd,img='',infoLabels=oFapcRKVSbnlQTIkmyPYvwuGAhNXMf,isFolder=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH,params=oFapcRKVSbnlQTIkmyPYvwuGAhNXsf)
  xbmcplugin.endOfDirectory(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd._addon_handle,cacheToDisc=oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
 def dp_View_Detail(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd,oFapcRKVSbnlQTIkmyPYvwuGAhNXtd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXMx =oFapcRKVSbnlQTIkmyPYvwuGAhNXtd.get('videoid')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXEO =oFapcRKVSbnlQTIkmyPYvwuGAhNXtd.get('vidtype') 
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWz=oFapcRKVSbnlQTIkmyPYvwuGAhNXtd.get('contenttype')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log(oFapcRKVSbnlQTIkmyPYvwuGAhNXMx)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log(oFapcRKVSbnlQTIkmyPYvwuGAhNXEO)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.addon_log(oFapcRKVSbnlQTIkmyPYvwuGAhNXWz)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXWL=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.GetBookmarkInfo(oFapcRKVSbnlQTIkmyPYvwuGAhNXMx,oFapcRKVSbnlQTIkmyPYvwuGAhNXEO,oFapcRKVSbnlQTIkmyPYvwuGAhNXWz)
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXEO=='tvshow':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'SEASON_LIST','videoid':oFapcRKVSbnlQTIkmyPYvwuGAhNXWL['indexinfo']['videoid'],'vidtype':oFapcRKVSbnlQTIkmyPYvwuGAhNXWL['indexinfo']['vidtype'],}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgD='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(oFapcRKVSbnlQTIkmyPYvwuGAhNXsf))
  else:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsf={'mode':'MOVIE','contentid':oFapcRKVSbnlQTIkmyPYvwuGAhNXWL['indexinfo']['videoid'],'title':oFapcRKVSbnlQTIkmyPYvwuGAhNXWL['saveinfo']['infoLabels']['title'],'thumbnail':oFapcRKVSbnlQTIkmyPYvwuGAhNXWL['saveinfo']['thumbnail'],'age':oFapcRKVSbnlQTIkmyPYvwuGAhNXWL['saveinfo']['infoLabels']['mpaa'],}
   oFapcRKVSbnlQTIkmyPYvwuGAhNXgD='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(oFapcRKVSbnlQTIkmyPYvwuGAhNXsf))
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsH=xbmcgui.ListItem(label=oFapcRKVSbnlQTIkmyPYvwuGAhNXWL['saveinfo']['title'],path=oFapcRKVSbnlQTIkmyPYvwuGAhNXgD)
  oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.setArt(oFapcRKVSbnlQTIkmyPYvwuGAhNXWL['saveinfo']['thumbnail'])
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.Set_InfoTag(oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.getVideoInfoTag(),oFapcRKVSbnlQTIkmyPYvwuGAhNXWL['saveinfo']['infoLabels'])
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXEO=='movie':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.setIsFolder(oFapcRKVSbnlQTIkmyPYvwuGAhNXtH)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.setProperty('IsPlayable','true')
  else:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.setIsFolder(oFapcRKVSbnlQTIkmyPYvwuGAhNXte)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXsH.setProperty('IsPlayable','false')
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOH=xbmcgui.Dialog()
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOH.info(oFapcRKVSbnlQTIkmyPYvwuGAhNXsH)
 def wavve_main(oFapcRKVSbnlQTIkmyPYvwuGAhNXOd):
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.WavveObj.KodiVersion=oFapcRKVSbnlQTIkmyPYvwuGAhNXti(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  oFapcRKVSbnlQTIkmyPYvwuGAhNXtD=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.main_params.get('params')
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXtD:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtW =base64.standard_b64decode(oFapcRKVSbnlQTIkmyPYvwuGAhNXtD).decode('utf-8')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtW =json.loads(oFapcRKVSbnlQTIkmyPYvwuGAhNXtW)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMg =oFapcRKVSbnlQTIkmyPYvwuGAhNXtW.get('mode')
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtd =oFapcRKVSbnlQTIkmyPYvwuGAhNXtW.get('values')
  else:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.main_params.get('mode',oFapcRKVSbnlQTIkmyPYvwuGAhNXtj)
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtd=oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.main_params
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='LOGOUT':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.logout()
   return
  oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.login_main()
  if oFapcRKVSbnlQTIkmyPYvwuGAhNXMg is oFapcRKVSbnlQTIkmyPYvwuGAhNXtj:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Main_List()
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg in['LIVE','VOD','MOVIE','SPORTS']:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.play_VIDEO(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='LIVE_CATAGORY':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_LiveCatagory_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='MAIN_CATAGORY':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_MainCatagory_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='SUPERSECTION_LIST':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_SuperSection_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='BANDLIVESECTION_LIST':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_BandLiveSection_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='BAND2SECTION_LIST':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Band2Section_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='PROGRAM_LIST':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Program_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='SEASON_LIST':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Season_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='EPISODE_LIST':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Episode_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='MOVIE_LIST':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Movie_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='LIVE_LIST':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_LiveChannel_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='ORDER_BY':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_setEpOrderby(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='SEARCH_GROUP':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Search_Group(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg in['SEARCH_LIST','LOCAL_SEARCH']:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Search_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='WATCH_GROUP':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Watch_Group(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='WATCH_LIST':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Watch_List(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='SET_BOOKMARK':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Set_Bookmark(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_History_Remove(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg in['TOTAL_SEARCH','TOTAL_HISTORY']:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Global_Search(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='SEARCH_HISTORY':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Search_History(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='MENU_BOOKMARK':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Bookmark_Menu(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='GAME_LIST':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_Sports_GameList(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  elif oFapcRKVSbnlQTIkmyPYvwuGAhNXMg=='VIEW_DETAIL':
   oFapcRKVSbnlQTIkmyPYvwuGAhNXOd.dp_View_Detail(oFapcRKVSbnlQTIkmyPYvwuGAhNXtd)
  else:
   oFapcRKVSbnlQTIkmyPYvwuGAhNXtj
# Created by pyminifier (https://github.com/liftoff/pyminifier)
