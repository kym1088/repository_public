__author__="NightRain"
SjCexnwDcOTtIsiBzydLfXuRmVqabE=object
SjCexnwDcOTtIsiBzydLfXuRmVqabW=None
SjCexnwDcOTtIsiBzydLfXuRmVqabK=int
SjCexnwDcOTtIsiBzydLfXuRmVqabg=True
SjCexnwDcOTtIsiBzydLfXuRmVqabN=False
SjCexnwDcOTtIsiBzydLfXuRmVqaGY=type
SjCexnwDcOTtIsiBzydLfXuRmVqaGA=dict
SjCexnwDcOTtIsiBzydLfXuRmVqaGo=len
SjCexnwDcOTtIsiBzydLfXuRmVqaGr=range
SjCexnwDcOTtIsiBzydLfXuRmVqaGP=str
SjCexnwDcOTtIsiBzydLfXuRmVqaGJ=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
SjCexnwDcOTtIsiBzydLfXuRmVqaYo=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
SjCexnwDcOTtIsiBzydLfXuRmVqaYr=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
SjCexnwDcOTtIsiBzydLfXuRmVqaYP=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
SjCexnwDcOTtIsiBzydLfXuRmVqaYJ =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
SjCexnwDcOTtIsiBzydLfXuRmVqaYb=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class SjCexnwDcOTtIsiBzydLfXuRmVqaYA(SjCexnwDcOTtIsiBzydLfXuRmVqabE):
 def __init__(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,SjCexnwDcOTtIsiBzydLfXuRmVqaYM,SjCexnwDcOTtIsiBzydLfXuRmVqaYQ,SjCexnwDcOTtIsiBzydLfXuRmVqaYp):
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_url =SjCexnwDcOTtIsiBzydLfXuRmVqaYM
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle=SjCexnwDcOTtIsiBzydLfXuRmVqaYQ
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.main_params =SjCexnwDcOTtIsiBzydLfXuRmVqaYp
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj =gyaqVnoXCYANWFulBjxTLKJsIpRcMw() 
 def addon_noti(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,sting):
  try:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYU=xbmcgui.Dialog()
   SjCexnwDcOTtIsiBzydLfXuRmVqaYU.notification(__addonname__,sting)
  except:
   SjCexnwDcOTtIsiBzydLfXuRmVqabW
 def addon_log(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,string):
  try:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYl=string.encode('utf-8','ignore')
  except:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYl='addonException: addon_log'
  SjCexnwDcOTtIsiBzydLfXuRmVqaYH=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,SjCexnwDcOTtIsiBzydLfXuRmVqaYl),level=SjCexnwDcOTtIsiBzydLfXuRmVqaYH)
 def get_keyboard_input(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,SjCexnwDcOTtIsiBzydLfXuRmVqaAM):
  SjCexnwDcOTtIsiBzydLfXuRmVqaYh=SjCexnwDcOTtIsiBzydLfXuRmVqabW
  kb=xbmc.Keyboard()
  kb.setHeading(SjCexnwDcOTtIsiBzydLfXuRmVqaAM)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   SjCexnwDcOTtIsiBzydLfXuRmVqaYh=kb.getText()
  return SjCexnwDcOTtIsiBzydLfXuRmVqaYh
 def get_settings_account(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  SjCexnwDcOTtIsiBzydLfXuRmVqaYk =__addon__.getSetting('id')
  SjCexnwDcOTtIsiBzydLfXuRmVqaYF =__addon__.getSetting('pw')
  SjCexnwDcOTtIsiBzydLfXuRmVqaYE=SjCexnwDcOTtIsiBzydLfXuRmVqabK(__addon__.getSetting('selected_profile'))
  return(SjCexnwDcOTtIsiBzydLfXuRmVqaYk,SjCexnwDcOTtIsiBzydLfXuRmVqaYF,SjCexnwDcOTtIsiBzydLfXuRmVqaYE)
 def get_settings_totalsearch(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  SjCexnwDcOTtIsiBzydLfXuRmVqaYW =SjCexnwDcOTtIsiBzydLfXuRmVqabg if __addon__.getSetting('local_search')=='true' else SjCexnwDcOTtIsiBzydLfXuRmVqabN
  SjCexnwDcOTtIsiBzydLfXuRmVqaYK=SjCexnwDcOTtIsiBzydLfXuRmVqabg if __addon__.getSetting('local_history')=='true' else SjCexnwDcOTtIsiBzydLfXuRmVqabN
  SjCexnwDcOTtIsiBzydLfXuRmVqaYg =SjCexnwDcOTtIsiBzydLfXuRmVqabg if __addon__.getSetting('total_search')=='true' else SjCexnwDcOTtIsiBzydLfXuRmVqabN
  SjCexnwDcOTtIsiBzydLfXuRmVqaYN=SjCexnwDcOTtIsiBzydLfXuRmVqabg if __addon__.getSetting('total_history')=='true' else SjCexnwDcOTtIsiBzydLfXuRmVqabN
  SjCexnwDcOTtIsiBzydLfXuRmVqaAY=SjCexnwDcOTtIsiBzydLfXuRmVqabg if __addon__.getSetting('menu_bookmark')=='true' else SjCexnwDcOTtIsiBzydLfXuRmVqabN
  return(SjCexnwDcOTtIsiBzydLfXuRmVqaYW,SjCexnwDcOTtIsiBzydLfXuRmVqaYK,SjCexnwDcOTtIsiBzydLfXuRmVqaYg,SjCexnwDcOTtIsiBzydLfXuRmVqaYN,SjCexnwDcOTtIsiBzydLfXuRmVqaAY)
 def get_settings_makebookmark(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  return SjCexnwDcOTtIsiBzydLfXuRmVqabg if __addon__.getSetting('make_bookmark')=='true' else SjCexnwDcOTtIsiBzydLfXuRmVqabN
 def get_selQuality(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  try:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAo=[1080,720,480,360]
   SjCexnwDcOTtIsiBzydLfXuRmVqaAr=SjCexnwDcOTtIsiBzydLfXuRmVqabK(__addon__.getSetting('selected_quality'))
   return SjCexnwDcOTtIsiBzydLfXuRmVqaAo[SjCexnwDcOTtIsiBzydLfXuRmVqaAr]
  except:
   SjCexnwDcOTtIsiBzydLfXuRmVqabW
  return 1080 
 def get_settings_exclusion21(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  SjCexnwDcOTtIsiBzydLfXuRmVqaAP =__addon__.getSetting('exclusion21')
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAP=='false':
   return SjCexnwDcOTtIsiBzydLfXuRmVqabN
  else:
   return SjCexnwDcOTtIsiBzydLfXuRmVqabg
 def get_settings_direct_replay(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  SjCexnwDcOTtIsiBzydLfXuRmVqaAJ=SjCexnwDcOTtIsiBzydLfXuRmVqabK(__addon__.getSetting('direct_replay'))
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAJ==0:
   return SjCexnwDcOTtIsiBzydLfXuRmVqabN
  else:
   return SjCexnwDcOTtIsiBzydLfXuRmVqabg
 def set_winEpisodeOrderby(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,SjCexnwDcOTtIsiBzydLfXuRmVqaAb):
  __addon__.setSetting('wavve_orderby',SjCexnwDcOTtIsiBzydLfXuRmVqaAb)
 def get_winEpisodeOrderby(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  SjCexnwDcOTtIsiBzydLfXuRmVqaAb=__addon__.getSetting('wavve_orderby')
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAb in['',SjCexnwDcOTtIsiBzydLfXuRmVqabW]:SjCexnwDcOTtIsiBzydLfXuRmVqaAb='desc'
  return SjCexnwDcOTtIsiBzydLfXuRmVqaAb
 def add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,label,sublabel='',img='',infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params='',isLink=SjCexnwDcOTtIsiBzydLfXuRmVqabN,ContextMenu=SjCexnwDcOTtIsiBzydLfXuRmVqabW):
  SjCexnwDcOTtIsiBzydLfXuRmVqaAG='%s?%s'%(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_url,urllib.parse.urlencode(params))
  if sublabel:SjCexnwDcOTtIsiBzydLfXuRmVqaAM='%s < %s >'%(label,sublabel)
  else: SjCexnwDcOTtIsiBzydLfXuRmVqaAM=label
  if not img:img='DefaultFolder.png'
  SjCexnwDcOTtIsiBzydLfXuRmVqaAQ=xbmcgui.ListItem(SjCexnwDcOTtIsiBzydLfXuRmVqaAM)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGY(img)==SjCexnwDcOTtIsiBzydLfXuRmVqaGA:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAQ.setArt(img)
  else:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAQ.setArt({'thumb':img,'poster':img})
  if infoLabels:SjCexnwDcOTtIsiBzydLfXuRmVqaAQ.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAQ.setProperty('IsPlayable','true')
  if ContextMenu:SjCexnwDcOTtIsiBzydLfXuRmVqaAQ.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,SjCexnwDcOTtIsiBzydLfXuRmVqaAG,SjCexnwDcOTtIsiBzydLfXuRmVqaAQ,isFolder)
 def dp_Main_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  (SjCexnwDcOTtIsiBzydLfXuRmVqaYW,SjCexnwDcOTtIsiBzydLfXuRmVqaYK,SjCexnwDcOTtIsiBzydLfXuRmVqaYg,SjCexnwDcOTtIsiBzydLfXuRmVqaYN,SjCexnwDcOTtIsiBzydLfXuRmVqaAY)=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_totalsearch()
  for SjCexnwDcOTtIsiBzydLfXuRmVqaAp in SjCexnwDcOTtIsiBzydLfXuRmVqaYo:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM=SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('title')
   SjCexnwDcOTtIsiBzydLfXuRmVqaAv=''
   if SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('mode')=='SEARCH_GROUP' and SjCexnwDcOTtIsiBzydLfXuRmVqaYW ==SjCexnwDcOTtIsiBzydLfXuRmVqabN:continue
   elif SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('mode')=='SEARCH_HISTORY' and SjCexnwDcOTtIsiBzydLfXuRmVqaYK==SjCexnwDcOTtIsiBzydLfXuRmVqabN:continue
   elif SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('mode')=='TOTAL_SEARCH' and SjCexnwDcOTtIsiBzydLfXuRmVqaYg ==SjCexnwDcOTtIsiBzydLfXuRmVqabN:continue
   elif SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('mode')=='TOTAL_HISTORY' and SjCexnwDcOTtIsiBzydLfXuRmVqaYN==SjCexnwDcOTtIsiBzydLfXuRmVqabN:continue
   elif SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('mode')=='MENU_BOOKMARK' and SjCexnwDcOTtIsiBzydLfXuRmVqaAY==SjCexnwDcOTtIsiBzydLfXuRmVqabN:continue
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('mode'),'sCode':SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('sCode'),'sIndex':SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('sIndex'),'sType':SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('sType'),'suburl':SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('suburl'),'subapi':SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('subapi'),'page':SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('page'),'orderby':SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('orderby'),'ordernm':SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('ordernm')}
   if SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    SjCexnwDcOTtIsiBzydLfXuRmVqaAl=SjCexnwDcOTtIsiBzydLfXuRmVqabN
    SjCexnwDcOTtIsiBzydLfXuRmVqaAH =SjCexnwDcOTtIsiBzydLfXuRmVqabg
   else:
    SjCexnwDcOTtIsiBzydLfXuRmVqaAl=SjCexnwDcOTtIsiBzydLfXuRmVqabg
    SjCexnwDcOTtIsiBzydLfXuRmVqaAH =SjCexnwDcOTtIsiBzydLfXuRmVqabN
   if 'icon' in SjCexnwDcOTtIsiBzydLfXuRmVqaAp:SjCexnwDcOTtIsiBzydLfXuRmVqaAv=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',SjCexnwDcOTtIsiBzydLfXuRmVqaAp.get('icon')) 
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img=SjCexnwDcOTtIsiBzydLfXuRmVqaAv,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqaAl,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU,isLink=SjCexnwDcOTtIsiBzydLfXuRmVqaAH)
  xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabg)
 def dp_Search_Group(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  if 'search_key' in args:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAF=args.get('search_key')
  else:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAF=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not SjCexnwDcOTtIsiBzydLfXuRmVqaAF:
    return
  for SjCexnwDcOTtIsiBzydLfXuRmVqaAE in SjCexnwDcOTtIsiBzydLfXuRmVqaYr:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAW =SjCexnwDcOTtIsiBzydLfXuRmVqaAE.get('mode')
   SjCexnwDcOTtIsiBzydLfXuRmVqaAK=SjCexnwDcOTtIsiBzydLfXuRmVqaAE.get('sType')
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM=SjCexnwDcOTtIsiBzydLfXuRmVqaAE.get('title')
   (SjCexnwDcOTtIsiBzydLfXuRmVqaAg,SjCexnwDcOTtIsiBzydLfXuRmVqaAN)=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_Search_List(SjCexnwDcOTtIsiBzydLfXuRmVqaAF,SjCexnwDcOTtIsiBzydLfXuRmVqaAK,1,exclusion21=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_exclusion21())
   SjCexnwDcOTtIsiBzydLfXuRmVqaoY={'plot':'검색어 : '+SjCexnwDcOTtIsiBzydLfXuRmVqaAF+'\n\n'+SjCexnwDcOTtIsiBzydLfXuRmVqaYG.Search_FreeList(SjCexnwDcOTtIsiBzydLfXuRmVqaAg)}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':SjCexnwDcOTtIsiBzydLfXuRmVqaAW,'sType':SjCexnwDcOTtIsiBzydLfXuRmVqaAK,'search_key':SjCexnwDcOTtIsiBzydLfXuRmVqaAF,'page':'1',}
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img='',infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoY,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(SjCexnwDcOTtIsiBzydLfXuRmVqaYr)>0:xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabg)
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.Save_Searched_List(SjCexnwDcOTtIsiBzydLfXuRmVqaAF)
 def Search_FreeList(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,search_list):
  SjCexnwDcOTtIsiBzydLfXuRmVqaoA=''
  SjCexnwDcOTtIsiBzydLfXuRmVqaor=7
  try:
   if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(search_list)==0:return '검색결과 없음'
   for i in SjCexnwDcOTtIsiBzydLfXuRmVqaGr(SjCexnwDcOTtIsiBzydLfXuRmVqaGo(search_list)):
    if i>=SjCexnwDcOTtIsiBzydLfXuRmVqaor:
     SjCexnwDcOTtIsiBzydLfXuRmVqaoA=SjCexnwDcOTtIsiBzydLfXuRmVqaoA+'...'
     break
    SjCexnwDcOTtIsiBzydLfXuRmVqaoA=SjCexnwDcOTtIsiBzydLfXuRmVqaoA+search_list[i]['title']+'\n'
  except:
   return ''
  return SjCexnwDcOTtIsiBzydLfXuRmVqaoA
 def dp_Watch_Group(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoP in SjCexnwDcOTtIsiBzydLfXuRmVqaYP:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM=SjCexnwDcOTtIsiBzydLfXuRmVqaoP.get('title')
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':SjCexnwDcOTtIsiBzydLfXuRmVqaoP.get('mode'),'sType':SjCexnwDcOTtIsiBzydLfXuRmVqaoP.get('sType')}
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img='',infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(SjCexnwDcOTtIsiBzydLfXuRmVqaYP)>0:xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabg)
 def dp_Search_History(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaoJ=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.Load_List_File('search')
  for SjCexnwDcOTtIsiBzydLfXuRmVqaob in SjCexnwDcOTtIsiBzydLfXuRmVqaoJ:
   SjCexnwDcOTtIsiBzydLfXuRmVqaoG=SjCexnwDcOTtIsiBzydLfXuRmVqaGA(urllib.parse.parse_qsl(SjCexnwDcOTtIsiBzydLfXuRmVqaob))
   SjCexnwDcOTtIsiBzydLfXuRmVqaoM=SjCexnwDcOTtIsiBzydLfXuRmVqaoG.get('skey').strip()
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'SEARCH_GROUP','search_key':SjCexnwDcOTtIsiBzydLfXuRmVqaoM,}
   SjCexnwDcOTtIsiBzydLfXuRmVqaoQ={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':SjCexnwDcOTtIsiBzydLfXuRmVqaoM,'vType':'-',}
   SjCexnwDcOTtIsiBzydLfXuRmVqaop=urllib.parse.urlencode(SjCexnwDcOTtIsiBzydLfXuRmVqaoQ)
   SjCexnwDcOTtIsiBzydLfXuRmVqaov=[('선택된 검색어 ( %s ) 삭제'%(SjCexnwDcOTtIsiBzydLfXuRmVqaoM),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqaop))]
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaoM,sublabel='',img=SjCexnwDcOTtIsiBzydLfXuRmVqabW,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU,ContextMenu=SjCexnwDcOTtIsiBzydLfXuRmVqaov)
  SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'plot':'검색목록 전체를 삭제합니다.'}
  SjCexnwDcOTtIsiBzydLfXuRmVqaAM='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  SjCexnwDcOTtIsiBzydLfXuRmVqaAv=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img=SjCexnwDcOTtIsiBzydLfXuRmVqaAv,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabN,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU,isLink=SjCexnwDcOTtIsiBzydLfXuRmVqabg)
  xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_Search_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaAK =args.get('sType')
  SjCexnwDcOTtIsiBzydLfXuRmVqaol =SjCexnwDcOTtIsiBzydLfXuRmVqabK(args.get('page'))
  if 'search_key' in args:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAF=args.get('search_key')
  else:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAF=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not SjCexnwDcOTtIsiBzydLfXuRmVqaAF:
    xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle)
    return
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH,SjCexnwDcOTtIsiBzydLfXuRmVqaAN=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_Search_List(SjCexnwDcOTtIsiBzydLfXuRmVqaAF,SjCexnwDcOTtIsiBzydLfXuRmVqaAK,SjCexnwDcOTtIsiBzydLfXuRmVqaol,exclusion21=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_exclusion21())
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   SjCexnwDcOTtIsiBzydLfXuRmVqaok =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('videoid')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoF =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('vidtype')
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('title')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoE=SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('thumbnail')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoW =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('age')
   if SjCexnwDcOTtIsiBzydLfXuRmVqaoW=='18' or SjCexnwDcOTtIsiBzydLfXuRmVqaoW=='19' or SjCexnwDcOTtIsiBzydLfXuRmVqaoW=='21':SjCexnwDcOTtIsiBzydLfXuRmVqaAM+=' (%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqaoW)
   SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'mediatype':'tvshow' if SjCexnwDcOTtIsiBzydLfXuRmVqaAK=='vod' else 'movie','mpaa':SjCexnwDcOTtIsiBzydLfXuRmVqaoW,'title':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'plot':SjCexnwDcOTtIsiBzydLfXuRmVqaAM}
   if SjCexnwDcOTtIsiBzydLfXuRmVqaAK=='vod':
    SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'EPISODE_LIST','videoid':SjCexnwDcOTtIsiBzydLfXuRmVqaok,'vidtype':SjCexnwDcOTtIsiBzydLfXuRmVqaoF,'page':'1'}
    SjCexnwDcOTtIsiBzydLfXuRmVqaAl=SjCexnwDcOTtIsiBzydLfXuRmVqabg
   else:
    SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'MOVIE','contentid':SjCexnwDcOTtIsiBzydLfXuRmVqaok,'title':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'thumbnail':SjCexnwDcOTtIsiBzydLfXuRmVqaoE,'age':SjCexnwDcOTtIsiBzydLfXuRmVqaoW}
    SjCexnwDcOTtIsiBzydLfXuRmVqaAl=SjCexnwDcOTtIsiBzydLfXuRmVqabN
   SjCexnwDcOTtIsiBzydLfXuRmVqaov=[]
   SjCexnwDcOTtIsiBzydLfXuRmVqaoK={'mode':'VIEW_DETAIL','values':{'videoid':SjCexnwDcOTtIsiBzydLfXuRmVqaok,'vidtype':'tvshow' if SjCexnwDcOTtIsiBzydLfXuRmVqaAK=='vod' else 'movie','contenttype':SjCexnwDcOTtIsiBzydLfXuRmVqaoF,}}
   SjCexnwDcOTtIsiBzydLfXuRmVqaog=json.dumps(SjCexnwDcOTtIsiBzydLfXuRmVqaoK,separators=(',',':'))
   SjCexnwDcOTtIsiBzydLfXuRmVqaog=base64.standard_b64encode(SjCexnwDcOTtIsiBzydLfXuRmVqaog.encode()).decode('utf-8')
   SjCexnwDcOTtIsiBzydLfXuRmVqaog=SjCexnwDcOTtIsiBzydLfXuRmVqaog.replace('+','%2B')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoN='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqaog)
   SjCexnwDcOTtIsiBzydLfXuRmVqaov.append(('상세정보 조회',SjCexnwDcOTtIsiBzydLfXuRmVqaoN))
   if SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_makebookmark():
    SjCexnwDcOTtIsiBzydLfXuRmVqaoK={'videoid':SjCexnwDcOTtIsiBzydLfXuRmVqaok,'vidtype':'tvshow' if SjCexnwDcOTtIsiBzydLfXuRmVqaAK=='vod' else 'movie','vtitle':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'vsubtitle':'','contenttype':SjCexnwDcOTtIsiBzydLfXuRmVqaoF,}
    SjCexnwDcOTtIsiBzydLfXuRmVqarY=json.dumps(SjCexnwDcOTtIsiBzydLfXuRmVqaoK)
    SjCexnwDcOTtIsiBzydLfXuRmVqarY=urllib.parse.quote(SjCexnwDcOTtIsiBzydLfXuRmVqarY)
    SjCexnwDcOTtIsiBzydLfXuRmVqaoN='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqarY)
    SjCexnwDcOTtIsiBzydLfXuRmVqaov.append(('(통합) 찜 영상에 추가',SjCexnwDcOTtIsiBzydLfXuRmVqaoN))
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img=SjCexnwDcOTtIsiBzydLfXuRmVqaoE,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqaAl,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU,ContextMenu=SjCexnwDcOTtIsiBzydLfXuRmVqaov)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAN:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['mode'] ='SEARCH_LIST' 
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['sType']=SjCexnwDcOTtIsiBzydLfXuRmVqaAK 
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['page'] =SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['search_key']=SjCexnwDcOTtIsiBzydLfXuRmVqaAF
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM='[B]%s >>[/B]'%'다음 페이지'
   SjCexnwDcOTtIsiBzydLfXuRmVqarA=SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAv=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqarA,img=SjCexnwDcOTtIsiBzydLfXuRmVqaAv,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAK=='movie':xbmcplugin.setContent(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,'movies')
  else:xbmcplugin.setContent(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_Watch_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaAK =args.get('sType')
  SjCexnwDcOTtIsiBzydLfXuRmVqaAJ=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_direct_replay()
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.Load_List_File(SjCexnwDcOTtIsiBzydLfXuRmVqaAK)
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   SjCexnwDcOTtIsiBzydLfXuRmVqaoG=SjCexnwDcOTtIsiBzydLfXuRmVqaGA(urllib.parse.parse_qsl(SjCexnwDcOTtIsiBzydLfXuRmVqaoh))
   SjCexnwDcOTtIsiBzydLfXuRmVqaro =SjCexnwDcOTtIsiBzydLfXuRmVqaoG.get('code').strip()
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM =SjCexnwDcOTtIsiBzydLfXuRmVqaoG.get('title').strip()
   SjCexnwDcOTtIsiBzydLfXuRmVqarA =SjCexnwDcOTtIsiBzydLfXuRmVqaoG.get('subtitle').strip()
   if SjCexnwDcOTtIsiBzydLfXuRmVqarA=='None':SjCexnwDcOTtIsiBzydLfXuRmVqarA=''
   SjCexnwDcOTtIsiBzydLfXuRmVqaoE=SjCexnwDcOTtIsiBzydLfXuRmVqaoG.get('img').strip()
   SjCexnwDcOTtIsiBzydLfXuRmVqaok =SjCexnwDcOTtIsiBzydLfXuRmVqaoG.get('videoid').strip()
   try:
    SjCexnwDcOTtIsiBzydLfXuRmVqaoE=SjCexnwDcOTtIsiBzydLfXuRmVqaoE.replace('\'','\"')
    SjCexnwDcOTtIsiBzydLfXuRmVqaoE=json.loads(SjCexnwDcOTtIsiBzydLfXuRmVqaoE)
   except:
    SjCexnwDcOTtIsiBzydLfXuRmVqabW
   SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'plot':'%s\n%s'%(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,SjCexnwDcOTtIsiBzydLfXuRmVqarA)}
   if SjCexnwDcOTtIsiBzydLfXuRmVqaAK=='vod':
    if SjCexnwDcOTtIsiBzydLfXuRmVqaAJ==SjCexnwDcOTtIsiBzydLfXuRmVqabN or SjCexnwDcOTtIsiBzydLfXuRmVqaok==SjCexnwDcOTtIsiBzydLfXuRmVqabW:
     SjCexnwDcOTtIsiBzydLfXuRmVqaoU['mediatype']='tvshow'
     SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'EPISODE_LIST','videoid':SjCexnwDcOTtIsiBzydLfXuRmVqaro,'vidtype':'programid','page':'1'}
     SjCexnwDcOTtIsiBzydLfXuRmVqaAl=SjCexnwDcOTtIsiBzydLfXuRmVqabg
    else:
     SjCexnwDcOTtIsiBzydLfXuRmVqaoU['mediatype']='episode'
     SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'VOD','programid':SjCexnwDcOTtIsiBzydLfXuRmVqaro,'contentid':SjCexnwDcOTtIsiBzydLfXuRmVqaok,'title':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'subtitle':SjCexnwDcOTtIsiBzydLfXuRmVqarA,'thumbnail':SjCexnwDcOTtIsiBzydLfXuRmVqaoE}
     SjCexnwDcOTtIsiBzydLfXuRmVqaAl=SjCexnwDcOTtIsiBzydLfXuRmVqabN
   else:
    SjCexnwDcOTtIsiBzydLfXuRmVqaoU['mediatype']='movie'
    SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'MOVIE','contentid':SjCexnwDcOTtIsiBzydLfXuRmVqaro,'title':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'subtitle':SjCexnwDcOTtIsiBzydLfXuRmVqarA,'thumbnail':SjCexnwDcOTtIsiBzydLfXuRmVqaoE}
    SjCexnwDcOTtIsiBzydLfXuRmVqaAl=SjCexnwDcOTtIsiBzydLfXuRmVqabN
   SjCexnwDcOTtIsiBzydLfXuRmVqaoQ={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':SjCexnwDcOTtIsiBzydLfXuRmVqaro,'vType':SjCexnwDcOTtIsiBzydLfXuRmVqaAK,}
   SjCexnwDcOTtIsiBzydLfXuRmVqaop=urllib.parse.urlencode(SjCexnwDcOTtIsiBzydLfXuRmVqaoQ)
   SjCexnwDcOTtIsiBzydLfXuRmVqaov=[('선택된 시청이력 ( %s ) 삭제'%(SjCexnwDcOTtIsiBzydLfXuRmVqaAM),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqaop))]
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqarA,img=SjCexnwDcOTtIsiBzydLfXuRmVqaoE,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqaAl,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU,ContextMenu=SjCexnwDcOTtIsiBzydLfXuRmVqaov)
  SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'plot':'시청목록을 삭제합니다.'}
  SjCexnwDcOTtIsiBzydLfXuRmVqaAM='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':SjCexnwDcOTtIsiBzydLfXuRmVqaAK,}
  SjCexnwDcOTtIsiBzydLfXuRmVqaAv=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img=SjCexnwDcOTtIsiBzydLfXuRmVqaAv,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabN,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU,isLink=SjCexnwDcOTtIsiBzydLfXuRmVqabg)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAK=='movie':xbmcplugin.setContent(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,'movies')
  else:xbmcplugin.setContent(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def Load_List_File(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,stype): 
  try:
   if stype=='search':
    SjCexnwDcOTtIsiBzydLfXuRmVqarP=SjCexnwDcOTtIsiBzydLfXuRmVqaYb
   elif stype in['vod','movie']:
    SjCexnwDcOTtIsiBzydLfXuRmVqarP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=SjCexnwDcOTtIsiBzydLfXuRmVqaGJ(SjCexnwDcOTtIsiBzydLfXuRmVqarP,'r',-1,'utf-8')
   SjCexnwDcOTtIsiBzydLfXuRmVqarJ=fp.readlines()
   fp.close()
  except:
   SjCexnwDcOTtIsiBzydLfXuRmVqarJ=[]
  return SjCexnwDcOTtIsiBzydLfXuRmVqarJ
 def Save_Watched_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,SjCexnwDcOTtIsiBzydLfXuRmVqabr,SjCexnwDcOTtIsiBzydLfXuRmVqaYp):
  try:
   SjCexnwDcOTtIsiBzydLfXuRmVqarb=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SjCexnwDcOTtIsiBzydLfXuRmVqabr))
   SjCexnwDcOTtIsiBzydLfXuRmVqarG=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.Load_List_File(SjCexnwDcOTtIsiBzydLfXuRmVqabr) 
   fp=SjCexnwDcOTtIsiBzydLfXuRmVqaGJ(SjCexnwDcOTtIsiBzydLfXuRmVqarb,'w',-1,'utf-8')
   SjCexnwDcOTtIsiBzydLfXuRmVqarM=urllib.parse.urlencode(SjCexnwDcOTtIsiBzydLfXuRmVqaYp)
   SjCexnwDcOTtIsiBzydLfXuRmVqarM=SjCexnwDcOTtIsiBzydLfXuRmVqarM+'\n'
   fp.write(SjCexnwDcOTtIsiBzydLfXuRmVqarM)
   SjCexnwDcOTtIsiBzydLfXuRmVqarQ=0
   for SjCexnwDcOTtIsiBzydLfXuRmVqarp in SjCexnwDcOTtIsiBzydLfXuRmVqarG:
    SjCexnwDcOTtIsiBzydLfXuRmVqarv=SjCexnwDcOTtIsiBzydLfXuRmVqaGA(urllib.parse.parse_qsl(SjCexnwDcOTtIsiBzydLfXuRmVqarp))
    SjCexnwDcOTtIsiBzydLfXuRmVqarU=SjCexnwDcOTtIsiBzydLfXuRmVqaYp.get('code').strip()
    SjCexnwDcOTtIsiBzydLfXuRmVqarl=SjCexnwDcOTtIsiBzydLfXuRmVqarv.get('code').strip()
    if SjCexnwDcOTtIsiBzydLfXuRmVqabr=='vod' and SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_direct_replay()==SjCexnwDcOTtIsiBzydLfXuRmVqabg:
     SjCexnwDcOTtIsiBzydLfXuRmVqarU=SjCexnwDcOTtIsiBzydLfXuRmVqaYp.get('videoid').strip()
     SjCexnwDcOTtIsiBzydLfXuRmVqarl=SjCexnwDcOTtIsiBzydLfXuRmVqarv.get('videoid').strip()if SjCexnwDcOTtIsiBzydLfXuRmVqarl!=SjCexnwDcOTtIsiBzydLfXuRmVqabW else '-'
    if SjCexnwDcOTtIsiBzydLfXuRmVqarU!=SjCexnwDcOTtIsiBzydLfXuRmVqarl:
     fp.write(SjCexnwDcOTtIsiBzydLfXuRmVqarp)
     SjCexnwDcOTtIsiBzydLfXuRmVqarQ+=1
     if SjCexnwDcOTtIsiBzydLfXuRmVqarQ>=50:break
   fp.close()
  except:
   SjCexnwDcOTtIsiBzydLfXuRmVqabW
 def dp_History_Remove(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqarH=args.get('delType')
  SjCexnwDcOTtIsiBzydLfXuRmVqarh =args.get('sKey')
  SjCexnwDcOTtIsiBzydLfXuRmVqark =args.get('vType')
  SjCexnwDcOTtIsiBzydLfXuRmVqaYU=xbmcgui.Dialog()
  if SjCexnwDcOTtIsiBzydLfXuRmVqarH=='SEARCH_ALL':
   SjCexnwDcOTtIsiBzydLfXuRmVqarF=SjCexnwDcOTtIsiBzydLfXuRmVqaYU.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif SjCexnwDcOTtIsiBzydLfXuRmVqarH=='SEARCH_ONE':
   SjCexnwDcOTtIsiBzydLfXuRmVqarF=SjCexnwDcOTtIsiBzydLfXuRmVqaYU.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif SjCexnwDcOTtIsiBzydLfXuRmVqarH=='WATCH_ALL':
   SjCexnwDcOTtIsiBzydLfXuRmVqarF=SjCexnwDcOTtIsiBzydLfXuRmVqaYU.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif SjCexnwDcOTtIsiBzydLfXuRmVqarH=='WATCH_ONE':
   SjCexnwDcOTtIsiBzydLfXuRmVqarF=SjCexnwDcOTtIsiBzydLfXuRmVqaYU.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if SjCexnwDcOTtIsiBzydLfXuRmVqarF==SjCexnwDcOTtIsiBzydLfXuRmVqabN:sys.exit()
  if SjCexnwDcOTtIsiBzydLfXuRmVqarH=='SEARCH_ALL':
   if os.path.isfile(SjCexnwDcOTtIsiBzydLfXuRmVqaYb):os.remove(SjCexnwDcOTtIsiBzydLfXuRmVqaYb)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqarH=='SEARCH_ONE':
   try:
    SjCexnwDcOTtIsiBzydLfXuRmVqarP=SjCexnwDcOTtIsiBzydLfXuRmVqaYb
    SjCexnwDcOTtIsiBzydLfXuRmVqarG=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.Load_List_File('search') 
    fp=SjCexnwDcOTtIsiBzydLfXuRmVqaGJ(SjCexnwDcOTtIsiBzydLfXuRmVqarP,'w',-1,'utf-8')
    for SjCexnwDcOTtIsiBzydLfXuRmVqarp in SjCexnwDcOTtIsiBzydLfXuRmVqarG:
     SjCexnwDcOTtIsiBzydLfXuRmVqarv=SjCexnwDcOTtIsiBzydLfXuRmVqaGA(urllib.parse.parse_qsl(SjCexnwDcOTtIsiBzydLfXuRmVqarp))
     SjCexnwDcOTtIsiBzydLfXuRmVqarE=SjCexnwDcOTtIsiBzydLfXuRmVqarv.get('skey').strip()
     if SjCexnwDcOTtIsiBzydLfXuRmVqarh!=SjCexnwDcOTtIsiBzydLfXuRmVqarE:
      fp.write(SjCexnwDcOTtIsiBzydLfXuRmVqarp)
    fp.close()
   except:
    SjCexnwDcOTtIsiBzydLfXuRmVqabW
  elif SjCexnwDcOTtIsiBzydLfXuRmVqarH=='WATCH_ALL':
   SjCexnwDcOTtIsiBzydLfXuRmVqarP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SjCexnwDcOTtIsiBzydLfXuRmVqark))
   if os.path.isfile(SjCexnwDcOTtIsiBzydLfXuRmVqarP):os.remove(SjCexnwDcOTtIsiBzydLfXuRmVqarP)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqarH=='WATCH_ONE':
   SjCexnwDcOTtIsiBzydLfXuRmVqarP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SjCexnwDcOTtIsiBzydLfXuRmVqark))
   try:
    SjCexnwDcOTtIsiBzydLfXuRmVqarG=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.Load_List_File(SjCexnwDcOTtIsiBzydLfXuRmVqark) 
    fp=SjCexnwDcOTtIsiBzydLfXuRmVqaGJ(SjCexnwDcOTtIsiBzydLfXuRmVqarP,'w',-1,'utf-8')
    for SjCexnwDcOTtIsiBzydLfXuRmVqarp in SjCexnwDcOTtIsiBzydLfXuRmVqarG:
     SjCexnwDcOTtIsiBzydLfXuRmVqarv=SjCexnwDcOTtIsiBzydLfXuRmVqaGA(urllib.parse.parse_qsl(SjCexnwDcOTtIsiBzydLfXuRmVqarp))
     SjCexnwDcOTtIsiBzydLfXuRmVqarE=SjCexnwDcOTtIsiBzydLfXuRmVqarv.get('code').strip()
     if SjCexnwDcOTtIsiBzydLfXuRmVqarh!=SjCexnwDcOTtIsiBzydLfXuRmVqarE:
      fp.write(SjCexnwDcOTtIsiBzydLfXuRmVqarp)
    fp.close()
   except:
    SjCexnwDcOTtIsiBzydLfXuRmVqabW
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,SjCexnwDcOTtIsiBzydLfXuRmVqaAF):
  try:
   SjCexnwDcOTtIsiBzydLfXuRmVqarW=SjCexnwDcOTtIsiBzydLfXuRmVqaYb
   SjCexnwDcOTtIsiBzydLfXuRmVqarG=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.Load_List_File('search') 
   SjCexnwDcOTtIsiBzydLfXuRmVqarK={'skey':SjCexnwDcOTtIsiBzydLfXuRmVqaAF.strip()}
   fp=SjCexnwDcOTtIsiBzydLfXuRmVqaGJ(SjCexnwDcOTtIsiBzydLfXuRmVqarW,'w',-1,'utf-8')
   SjCexnwDcOTtIsiBzydLfXuRmVqarM=urllib.parse.urlencode(SjCexnwDcOTtIsiBzydLfXuRmVqarK)
   SjCexnwDcOTtIsiBzydLfXuRmVqarM=SjCexnwDcOTtIsiBzydLfXuRmVqarM+'\n'
   fp.write(SjCexnwDcOTtIsiBzydLfXuRmVqarM)
   SjCexnwDcOTtIsiBzydLfXuRmVqarQ=0
   for SjCexnwDcOTtIsiBzydLfXuRmVqarp in SjCexnwDcOTtIsiBzydLfXuRmVqarG:
    SjCexnwDcOTtIsiBzydLfXuRmVqarv=SjCexnwDcOTtIsiBzydLfXuRmVqaGA(urllib.parse.parse_qsl(SjCexnwDcOTtIsiBzydLfXuRmVqarp))
    SjCexnwDcOTtIsiBzydLfXuRmVqarU=SjCexnwDcOTtIsiBzydLfXuRmVqarK.get('skey').strip()
    SjCexnwDcOTtIsiBzydLfXuRmVqarl=SjCexnwDcOTtIsiBzydLfXuRmVqarv.get('skey').strip()
    if SjCexnwDcOTtIsiBzydLfXuRmVqarU!=SjCexnwDcOTtIsiBzydLfXuRmVqarl:
     fp.write(SjCexnwDcOTtIsiBzydLfXuRmVqarp)
     SjCexnwDcOTtIsiBzydLfXuRmVqarQ+=1
     if SjCexnwDcOTtIsiBzydLfXuRmVqarQ>=50:break
   fp.close()
  except:
   SjCexnwDcOTtIsiBzydLfXuRmVqabW
 def dp_Global_Search(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaAW=args.get('mode')
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='TOTAL_SEARCH':
   SjCexnwDcOTtIsiBzydLfXuRmVqarg='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   SjCexnwDcOTtIsiBzydLfXuRmVqarg='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(SjCexnwDcOTtIsiBzydLfXuRmVqarg)
 def dp_Bookmark_Menu(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqarg='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(SjCexnwDcOTtIsiBzydLfXuRmVqarg)
 def login_main(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  (SjCexnwDcOTtIsiBzydLfXuRmVqarN,SjCexnwDcOTtIsiBzydLfXuRmVqaPY,SjCexnwDcOTtIsiBzydLfXuRmVqaPA)=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_account()
  if not(SjCexnwDcOTtIsiBzydLfXuRmVqarN and SjCexnwDcOTtIsiBzydLfXuRmVqaPY):
   SjCexnwDcOTtIsiBzydLfXuRmVqaYU=xbmcgui.Dialog()
   SjCexnwDcOTtIsiBzydLfXuRmVqarF=SjCexnwDcOTtIsiBzydLfXuRmVqaYU.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if SjCexnwDcOTtIsiBzydLfXuRmVqarF==SjCexnwDcOTtIsiBzydLfXuRmVqabg:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if SjCexnwDcOTtIsiBzydLfXuRmVqaYG.cookiefile_check()==SjCexnwDcOTtIsiBzydLfXuRmVqabg:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   SjCexnwDcOTtIsiBzydLfXuRmVqaPo=0
   while SjCexnwDcOTtIsiBzydLfXuRmVqabg:
    SjCexnwDcOTtIsiBzydLfXuRmVqaPo+=1
    time.sleep(0.05)
    if SjCexnwDcOTtIsiBzydLfXuRmVqaPo>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  SjCexnwDcOTtIsiBzydLfXuRmVqaPr=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.GetCredential(SjCexnwDcOTtIsiBzydLfXuRmVqarN,SjCexnwDcOTtIsiBzydLfXuRmVqaPY,SjCexnwDcOTtIsiBzydLfXuRmVqaPA)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaPr:SjCexnwDcOTtIsiBzydLfXuRmVqaYG.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if SjCexnwDcOTtIsiBzydLfXuRmVqaPr==SjCexnwDcOTtIsiBzydLfXuRmVqabN:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaAb =args.get('orderby')
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.set_winEpisodeOrderby(SjCexnwDcOTtIsiBzydLfXuRmVqaAb)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaAW =args.get('mode')
  SjCexnwDcOTtIsiBzydLfXuRmVqaPJ =args.get('contentid')
  SjCexnwDcOTtIsiBzydLfXuRmVqaPb =args.get('pvrmode')
  SjCexnwDcOTtIsiBzydLfXuRmVqaPG=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_selQuality()
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.addon_log(SjCexnwDcOTtIsiBzydLfXuRmVqaPJ+' - '+SjCexnwDcOTtIsiBzydLfXuRmVqaAW)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='SPORTS':
   SjCexnwDcOTtIsiBzydLfXuRmVqaPM,SjCexnwDcOTtIsiBzydLfXuRmVqaPQ=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.GetSportsURL(SjCexnwDcOTtIsiBzydLfXuRmVqaPJ,SjCexnwDcOTtIsiBzydLfXuRmVqaPG)
   SjCexnwDcOTtIsiBzydLfXuRmVqaPp =''
   SjCexnwDcOTtIsiBzydLfXuRmVqaPv=''
  else:
   SjCexnwDcOTtIsiBzydLfXuRmVqaPM,SjCexnwDcOTtIsiBzydLfXuRmVqaPQ,SjCexnwDcOTtIsiBzydLfXuRmVqaPp,SjCexnwDcOTtIsiBzydLfXuRmVqaPv=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.GetStreamingURL(SjCexnwDcOTtIsiBzydLfXuRmVqaAW,SjCexnwDcOTtIsiBzydLfXuRmVqaPJ,SjCexnwDcOTtIsiBzydLfXuRmVqaPG,SjCexnwDcOTtIsiBzydLfXuRmVqaPb)
  SjCexnwDcOTtIsiBzydLfXuRmVqaPU='%s|Cookie=%s'%(SjCexnwDcOTtIsiBzydLfXuRmVqaPM,SjCexnwDcOTtIsiBzydLfXuRmVqaPQ)
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.addon_log(SjCexnwDcOTtIsiBzydLfXuRmVqaPU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaPM=='':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.addon_noti(__language__(30907).encode('utf8'))
   return
  SjCexnwDcOTtIsiBzydLfXuRmVqaPl=xbmcgui.ListItem(path=SjCexnwDcOTtIsiBzydLfXuRmVqaPU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaPp:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.addon_log('!!streaming_drm!!')
   SjCexnwDcOTtIsiBzydLfXuRmVqaPH=SjCexnwDcOTtIsiBzydLfXuRmVqaPp['customdata']
   SjCexnwDcOTtIsiBzydLfXuRmVqaPh =SjCexnwDcOTtIsiBzydLfXuRmVqaPp['drmhost']
   SjCexnwDcOTtIsiBzydLfXuRmVqaPk =inputstreamhelper.Helper('mpd',drm='widevine')
   if SjCexnwDcOTtIsiBzydLfXuRmVqaPk.check_inputstream():
    if SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='MOVIE':
     SjCexnwDcOTtIsiBzydLfXuRmVqaPF='https://www.wavve.com/player/movie?movieid=%s'%SjCexnwDcOTtIsiBzydLfXuRmVqaPJ
    else:
     SjCexnwDcOTtIsiBzydLfXuRmVqaPF='https://www.wavve.com/player/vod?programid=%s&page=1'%SjCexnwDcOTtIsiBzydLfXuRmVqaPJ
    SjCexnwDcOTtIsiBzydLfXuRmVqaPE={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':SjCexnwDcOTtIsiBzydLfXuRmVqaPH,'referer':SjCexnwDcOTtIsiBzydLfXuRmVqaPF,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.USER_AGENT}
    SjCexnwDcOTtIsiBzydLfXuRmVqaPW=SjCexnwDcOTtIsiBzydLfXuRmVqaPh+'|'+urllib.parse.urlencode(SjCexnwDcOTtIsiBzydLfXuRmVqaPE)+'|R{SSM}|'
    SjCexnwDcOTtIsiBzydLfXuRmVqaPl.setProperty('inputstream',SjCexnwDcOTtIsiBzydLfXuRmVqaPk.inputstream_addon)
    SjCexnwDcOTtIsiBzydLfXuRmVqaPl.setProperty('inputstream.adaptive.manifest_type','mpd')
    SjCexnwDcOTtIsiBzydLfXuRmVqaPl.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    SjCexnwDcOTtIsiBzydLfXuRmVqaPl.setProperty('inputstream.adaptive.license_key',SjCexnwDcOTtIsiBzydLfXuRmVqaPW)
    SjCexnwDcOTtIsiBzydLfXuRmVqaPl.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.USER_AGENT,SjCexnwDcOTtIsiBzydLfXuRmVqaPQ))
  xbmcplugin.setResolvedUrl(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,SjCexnwDcOTtIsiBzydLfXuRmVqabg,SjCexnwDcOTtIsiBzydLfXuRmVqaPl)
  SjCexnwDcOTtIsiBzydLfXuRmVqaPK=SjCexnwDcOTtIsiBzydLfXuRmVqabN
  if SjCexnwDcOTtIsiBzydLfXuRmVqaPv:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.addon_noti(SjCexnwDcOTtIsiBzydLfXuRmVqaPv.encode('utf-8'))
   SjCexnwDcOTtIsiBzydLfXuRmVqaPK=SjCexnwDcOTtIsiBzydLfXuRmVqabg
  else:
   if '/preview.' in urllib.parse.urlsplit(SjCexnwDcOTtIsiBzydLfXuRmVqaPM).path:
    SjCexnwDcOTtIsiBzydLfXuRmVqaYG.addon_noti(__language__(30908).encode('utf8'))
    SjCexnwDcOTtIsiBzydLfXuRmVqaPK=SjCexnwDcOTtIsiBzydLfXuRmVqabg
  try:
   SjCexnwDcOTtIsiBzydLfXuRmVqaPg=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and SjCexnwDcOTtIsiBzydLfXuRmVqaPK==SjCexnwDcOTtIsiBzydLfXuRmVqabN and SjCexnwDcOTtIsiBzydLfXuRmVqaPg!='-':
    SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'code':SjCexnwDcOTtIsiBzydLfXuRmVqaPg,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    SjCexnwDcOTtIsiBzydLfXuRmVqaYG.Save_Watched_List(args.get('mode').lower(),SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  except:
   SjCexnwDcOTtIsiBzydLfXuRmVqabW
 def logout(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  SjCexnwDcOTtIsiBzydLfXuRmVqaYU=xbmcgui.Dialog()
  SjCexnwDcOTtIsiBzydLfXuRmVqarF=SjCexnwDcOTtIsiBzydLfXuRmVqaYU.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if SjCexnwDcOTtIsiBzydLfXuRmVqarF==SjCexnwDcOTtIsiBzydLfXuRmVqabN:sys.exit()
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Init_WV_Total()
  if os.path.isfile(SjCexnwDcOTtIsiBzydLfXuRmVqaYJ):os.remove(SjCexnwDcOTtIsiBzydLfXuRmVqaYJ)
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  SjCexnwDcOTtIsiBzydLfXuRmVqaPN =SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_Now_Datetime()
  SjCexnwDcOTtIsiBzydLfXuRmVqaJY=SjCexnwDcOTtIsiBzydLfXuRmVqaPN+datetime.timedelta(days=SjCexnwDcOTtIsiBzydLfXuRmVqabK(__addon__.getSetting('cache_ttl')))
  (SjCexnwDcOTtIsiBzydLfXuRmVqarN,SjCexnwDcOTtIsiBzydLfXuRmVqaPY,SjCexnwDcOTtIsiBzydLfXuRmVqaPA)=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_account()
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Save_session_acount(SjCexnwDcOTtIsiBzydLfXuRmVqarN,SjCexnwDcOTtIsiBzydLfXuRmVqaPY,SjCexnwDcOTtIsiBzydLfXuRmVqaPA)
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.WV['account']['token_limit']=SjCexnwDcOTtIsiBzydLfXuRmVqaJY.strftime('%Y%m%d')
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.JsonFile_Save(SjCexnwDcOTtIsiBzydLfXuRmVqaYJ,SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.WV)
 def cookiefile_check(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.WV=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.JsonFile_Load(SjCexnwDcOTtIsiBzydLfXuRmVqaYJ)
  if 'account' not in SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.WV:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Init_WV_Total()
   return SjCexnwDcOTtIsiBzydLfXuRmVqabN
  (SjCexnwDcOTtIsiBzydLfXuRmVqaJA,SjCexnwDcOTtIsiBzydLfXuRmVqaJo,SjCexnwDcOTtIsiBzydLfXuRmVqaJr)=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_account()
  (SjCexnwDcOTtIsiBzydLfXuRmVqaJP,SjCexnwDcOTtIsiBzydLfXuRmVqaJb,SjCexnwDcOTtIsiBzydLfXuRmVqaJG)=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Load_session_acount()
  if SjCexnwDcOTtIsiBzydLfXuRmVqaJA!=SjCexnwDcOTtIsiBzydLfXuRmVqaJP or SjCexnwDcOTtIsiBzydLfXuRmVqaJo!=SjCexnwDcOTtIsiBzydLfXuRmVqaJb or SjCexnwDcOTtIsiBzydLfXuRmVqaJr!=SjCexnwDcOTtIsiBzydLfXuRmVqaJG:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Init_WV_Total()
   return SjCexnwDcOTtIsiBzydLfXuRmVqabN
  if SjCexnwDcOTtIsiBzydLfXuRmVqabK(SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>SjCexnwDcOTtIsiBzydLfXuRmVqabK(SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.WV['account']['token_limit']):
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Init_WV_Total()
   return SjCexnwDcOTtIsiBzydLfXuRmVqabN
  return SjCexnwDcOTtIsiBzydLfXuRmVqabg
 def dp_LiveCatagory_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaJM =args.get('sCode')
  SjCexnwDcOTtIsiBzydLfXuRmVqaJQ=args.get('sIndex')
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH,SjCexnwDcOTtIsiBzydLfXuRmVqaJp=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_LiveCatagory_List(SjCexnwDcOTtIsiBzydLfXuRmVqaJM,SjCexnwDcOTtIsiBzydLfXuRmVqaJQ)
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('title')
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'LIVE_LIST','genre':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('genre'),'baseapi':SjCexnwDcOTtIsiBzydLfXuRmVqaJp}
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img='',infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(SjCexnwDcOTtIsiBzydLfXuRmVqaoH)>0:xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_MainCatagory_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaJM =args.get('sCode')
  SjCexnwDcOTtIsiBzydLfXuRmVqaJQ=args.get('sIndex')
  SjCexnwDcOTtIsiBzydLfXuRmVqaAK =args.get('sType')
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_MainCatagory_List(SjCexnwDcOTtIsiBzydLfXuRmVqaJM,SjCexnwDcOTtIsiBzydLfXuRmVqaJQ)
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   if SjCexnwDcOTtIsiBzydLfXuRmVqaAK=='vod':
    if SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('subtype')=='catagory':
     SjCexnwDcOTtIsiBzydLfXuRmVqaAW='PROGRAM_LIST'
    else:
     SjCexnwDcOTtIsiBzydLfXuRmVqaAW='SUPERSECTION_LIST'
   elif SjCexnwDcOTtIsiBzydLfXuRmVqaAK=='movie':
    SjCexnwDcOTtIsiBzydLfXuRmVqaAW='MOVIE_LIST'
   else:
    SjCexnwDcOTtIsiBzydLfXuRmVqaAW=''
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM='%s (%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('title'),args.get('ordernm'))
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':SjCexnwDcOTtIsiBzydLfXuRmVqaAW,'suburl':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('suburl'),'subapi':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_exclusion21():
    if SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('title')=='성인' or SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('title')=='성인+' or SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('title')=='에로티시즘' or SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('title')=='19':continue
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img='',infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(SjCexnwDcOTtIsiBzydLfXuRmVqaoH)>0:xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_Program_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaJv =args.get('subapi')
  SjCexnwDcOTtIsiBzydLfXuRmVqaol=SjCexnwDcOTtIsiBzydLfXuRmVqabK(args.get('page'))
  SjCexnwDcOTtIsiBzydLfXuRmVqaAb =args.get('orderby')
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH,SjCexnwDcOTtIsiBzydLfXuRmVqaAN=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_Program_List(SjCexnwDcOTtIsiBzydLfXuRmVqaJv,SjCexnwDcOTtIsiBzydLfXuRmVqaol,SjCexnwDcOTtIsiBzydLfXuRmVqaAb)
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   SjCexnwDcOTtIsiBzydLfXuRmVqaok =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('videoid')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoF =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('vidtype')
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('title')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoE=SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('thumbnail')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoW =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('age')
   if SjCexnwDcOTtIsiBzydLfXuRmVqaoW=='18' or SjCexnwDcOTtIsiBzydLfXuRmVqaoW=='19' or SjCexnwDcOTtIsiBzydLfXuRmVqaoW=='21':SjCexnwDcOTtIsiBzydLfXuRmVqaAM+=' (%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqaoW)
   SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'plot':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'mpaa':SjCexnwDcOTtIsiBzydLfXuRmVqaoW,'mediatype':'tvshow'}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'EPISODE_LIST','videoid':SjCexnwDcOTtIsiBzydLfXuRmVqaok,'vidtype':SjCexnwDcOTtIsiBzydLfXuRmVqaoF,'page':'1'}
   SjCexnwDcOTtIsiBzydLfXuRmVqaov=[]
   SjCexnwDcOTtIsiBzydLfXuRmVqaoK={'mode':'VIEW_DETAIL','values':{'videoid':SjCexnwDcOTtIsiBzydLfXuRmVqaok,'vidtype':'tvshow','contenttype':SjCexnwDcOTtIsiBzydLfXuRmVqaoF,}}
   SjCexnwDcOTtIsiBzydLfXuRmVqaog=json.dumps(SjCexnwDcOTtIsiBzydLfXuRmVqaoK,separators=(',',':'))
   SjCexnwDcOTtIsiBzydLfXuRmVqaog=base64.standard_b64encode(SjCexnwDcOTtIsiBzydLfXuRmVqaog.encode()).decode('utf-8')
   SjCexnwDcOTtIsiBzydLfXuRmVqaog=SjCexnwDcOTtIsiBzydLfXuRmVqaog.replace('+','%2B')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoN='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqaog)
   SjCexnwDcOTtIsiBzydLfXuRmVqaov.append(('상세정보 조회',SjCexnwDcOTtIsiBzydLfXuRmVqaoN))
   if SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_makebookmark():
    SjCexnwDcOTtIsiBzydLfXuRmVqaoK={'videoid':SjCexnwDcOTtIsiBzydLfXuRmVqaok,'vidtype':'tvshow','vtitle':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'vsubtitle':'','contenttype':SjCexnwDcOTtIsiBzydLfXuRmVqaoF,}
    SjCexnwDcOTtIsiBzydLfXuRmVqarY=json.dumps(SjCexnwDcOTtIsiBzydLfXuRmVqaoK)
    SjCexnwDcOTtIsiBzydLfXuRmVqarY=urllib.parse.quote(SjCexnwDcOTtIsiBzydLfXuRmVqarY)
    SjCexnwDcOTtIsiBzydLfXuRmVqaoN='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqarY)
    SjCexnwDcOTtIsiBzydLfXuRmVqaov.append(('(통합) 찜 영상에 추가',SjCexnwDcOTtIsiBzydLfXuRmVqaoN))
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img=SjCexnwDcOTtIsiBzydLfXuRmVqaoE,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU,ContextMenu=SjCexnwDcOTtIsiBzydLfXuRmVqaov)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAN:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['mode'] ='PROGRAM_LIST' 
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['subapi']=SjCexnwDcOTtIsiBzydLfXuRmVqaJv 
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['page'] =SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM='[B]%s >>[/B]'%'다음 페이지'
   SjCexnwDcOTtIsiBzydLfXuRmVqarA=SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAv=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqarA,img=SjCexnwDcOTtIsiBzydLfXuRmVqaAv,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  xbmcplugin.setContent(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,'tvshows')
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(SjCexnwDcOTtIsiBzydLfXuRmVqaoH)>0:xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_SuperSection_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaJU =args.get('suburl')
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_SuperMultiSection_List(SjCexnwDcOTtIsiBzydLfXuRmVqaJU)
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('title')
   SjCexnwDcOTtIsiBzydLfXuRmVqaJv =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('subapi')
   SjCexnwDcOTtIsiBzydLfXuRmVqaJl=SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('cell_type')
   if SjCexnwDcOTtIsiBzydLfXuRmVqaJv.find('mtype=svod')>=0 or SjCexnwDcOTtIsiBzydLfXuRmVqaJv.find('mtype=ppv')>=0 or SjCexnwDcOTtIsiBzydLfXuRmVqaJv.find('contenttype=movie')>=0:
    SjCexnwDcOTtIsiBzydLfXuRmVqaAW='MOVIE_LIST'
   elif SjCexnwDcOTtIsiBzydLfXuRmVqaJv.find('contenttype=program')>=0:
    SjCexnwDcOTtIsiBzydLfXuRmVqaAW='PROGRAM_LIST'
   elif SjCexnwDcOTtIsiBzydLfXuRmVqaJl=='band_71':
    SjCexnwDcOTtIsiBzydLfXuRmVqaAW ='SUPERSECTION_LIST'
    (SjCexnwDcOTtIsiBzydLfXuRmVqaJH,SjCexnwDcOTtIsiBzydLfXuRmVqaJh)=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Baseapi_Parse(SjCexnwDcOTtIsiBzydLfXuRmVqaJv)
    SjCexnwDcOTtIsiBzydLfXuRmVqaJU=SjCexnwDcOTtIsiBzydLfXuRmVqaJh.get('api')
    SjCexnwDcOTtIsiBzydLfXuRmVqaJv=''
   elif SjCexnwDcOTtIsiBzydLfXuRmVqaJl=='band_2':
    SjCexnwDcOTtIsiBzydLfXuRmVqaAW='BAND2SECTION_LIST'
   elif SjCexnwDcOTtIsiBzydLfXuRmVqaJl=='band_live':
    SjCexnwDcOTtIsiBzydLfXuRmVqaAW='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',SjCexnwDcOTtIsiBzydLfXuRmVqaJv):
    SjCexnwDcOTtIsiBzydLfXuRmVqaAW='MOVIE_LIST'
   else:
    SjCexnwDcOTtIsiBzydLfXuRmVqaAW='PROGRAM_LIST'
   SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'plot':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'mediatype':'tvshow'}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':SjCexnwDcOTtIsiBzydLfXuRmVqaAW,'suburl':SjCexnwDcOTtIsiBzydLfXuRmVqaJU,'subapi':SjCexnwDcOTtIsiBzydLfXuRmVqaJv,'page':'1'}
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img=SjCexnwDcOTtIsiBzydLfXuRmVqabW,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(SjCexnwDcOTtIsiBzydLfXuRmVqaoH)>0:xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_BandLiveSection_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaJv =args.get('subapi')
  SjCexnwDcOTtIsiBzydLfXuRmVqaol=SjCexnwDcOTtIsiBzydLfXuRmVqabK(args.get('page'))
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH,SjCexnwDcOTtIsiBzydLfXuRmVqaAN=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_BandLiveSection_List(SjCexnwDcOTtIsiBzydLfXuRmVqaJv,SjCexnwDcOTtIsiBzydLfXuRmVqaol)
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   SjCexnwDcOTtIsiBzydLfXuRmVqaJk =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('channelid')
   SjCexnwDcOTtIsiBzydLfXuRmVqaJF =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('studio')
   SjCexnwDcOTtIsiBzydLfXuRmVqaJE=SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('tvshowtitle')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoE =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('thumbnail')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoW =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('age')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'mediatype':'tvshow','mpaa':SjCexnwDcOTtIsiBzydLfXuRmVqaoW,'title':'%s < %s >'%(SjCexnwDcOTtIsiBzydLfXuRmVqaJF,SjCexnwDcOTtIsiBzydLfXuRmVqaJE),'tvshowtitle':SjCexnwDcOTtIsiBzydLfXuRmVqaJE,'studio':SjCexnwDcOTtIsiBzydLfXuRmVqaJF,'plot':SjCexnwDcOTtIsiBzydLfXuRmVqaJF}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'LIVE','contentid':SjCexnwDcOTtIsiBzydLfXuRmVqaJk}
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaJF,sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqaJE,img=SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('thumbnail'),infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabN,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAN:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['mode'] ='BANDLIVESECTION_LIST' 
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['subapi']=SjCexnwDcOTtIsiBzydLfXuRmVqaJv
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['page'] =SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM='[B]%s >>[/B]'%'다음 페이지'
   SjCexnwDcOTtIsiBzydLfXuRmVqarA=SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAv=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqarA,img=SjCexnwDcOTtIsiBzydLfXuRmVqaAv,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(SjCexnwDcOTtIsiBzydLfXuRmVqaoH)>0:xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_Band2Section_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaJv =args.get('subapi')
  SjCexnwDcOTtIsiBzydLfXuRmVqaol=SjCexnwDcOTtIsiBzydLfXuRmVqabK(args.get('page'))
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH,SjCexnwDcOTtIsiBzydLfXuRmVqaAN=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_Band2Section_List(SjCexnwDcOTtIsiBzydLfXuRmVqaJv,SjCexnwDcOTtIsiBzydLfXuRmVqaol)
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('programtitle')
   SjCexnwDcOTtIsiBzydLfXuRmVqarA =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('episodetitle')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'plot':SjCexnwDcOTtIsiBzydLfXuRmVqaAM+'\n\n'+SjCexnwDcOTtIsiBzydLfXuRmVqarA,'mpaa':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('age'),'mediatype':'episode'}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'VOD','programid':'-','contentid':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('videoid'),'thumbnail':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('thumbnail'),'title':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'subtitle':SjCexnwDcOTtIsiBzydLfXuRmVqarA}
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqarA,img=SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('thumbnail'),infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabN,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAN:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['mode'] ='BAND2SECTION_LIST' 
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['subapi']=SjCexnwDcOTtIsiBzydLfXuRmVqaJv
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['page'] =SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM='[B]%s >>[/B]'%'다음 페이지'
   SjCexnwDcOTtIsiBzydLfXuRmVqarA=SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAv=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqarA,img=SjCexnwDcOTtIsiBzydLfXuRmVqaAv,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(SjCexnwDcOTtIsiBzydLfXuRmVqaoH)>0:xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_Movie_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaJv =args.get('subapi')
  SjCexnwDcOTtIsiBzydLfXuRmVqaol=SjCexnwDcOTtIsiBzydLfXuRmVqabK(args.get('page'))
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH,SjCexnwDcOTtIsiBzydLfXuRmVqaAN=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_Movie_List(SjCexnwDcOTtIsiBzydLfXuRmVqaJv,SjCexnwDcOTtIsiBzydLfXuRmVqaol)
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   SjCexnwDcOTtIsiBzydLfXuRmVqaok =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('videoid')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoF =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('vidtype')
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('title')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoE=SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('thumbnail')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoW =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('age')
   if SjCexnwDcOTtIsiBzydLfXuRmVqaoW=='18' or SjCexnwDcOTtIsiBzydLfXuRmVqaoW=='19' or SjCexnwDcOTtIsiBzydLfXuRmVqaoW=='21':SjCexnwDcOTtIsiBzydLfXuRmVqaAM+=' (%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqaoW)
   SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'plot':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'mpaa':SjCexnwDcOTtIsiBzydLfXuRmVqaoW,'mediatype':'movie'}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'MOVIE','contentid':SjCexnwDcOTtIsiBzydLfXuRmVqaok,'title':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'thumbnail':SjCexnwDcOTtIsiBzydLfXuRmVqaoE,'age':SjCexnwDcOTtIsiBzydLfXuRmVqaoW,}
   SjCexnwDcOTtIsiBzydLfXuRmVqaov=[]
   SjCexnwDcOTtIsiBzydLfXuRmVqaoK={'mode':'VIEW_DETAIL','values':{'videoid':SjCexnwDcOTtIsiBzydLfXuRmVqaok,'vidtype':'movie','contenttype':SjCexnwDcOTtIsiBzydLfXuRmVqaoF,}}
   SjCexnwDcOTtIsiBzydLfXuRmVqaog=json.dumps(SjCexnwDcOTtIsiBzydLfXuRmVqaoK,separators=(',',':'))
   SjCexnwDcOTtIsiBzydLfXuRmVqaog=base64.standard_b64encode(SjCexnwDcOTtIsiBzydLfXuRmVqaog.encode()).decode('utf-8')
   SjCexnwDcOTtIsiBzydLfXuRmVqaog=SjCexnwDcOTtIsiBzydLfXuRmVqaog.replace('+','%2B')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoN='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqaog)
   SjCexnwDcOTtIsiBzydLfXuRmVqaov.append(('상세정보 조회',SjCexnwDcOTtIsiBzydLfXuRmVqaoN))
   if SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_settings_makebookmark():
    SjCexnwDcOTtIsiBzydLfXuRmVqaoK={'videoid':SjCexnwDcOTtIsiBzydLfXuRmVqaok,'vidtype':'movie','vtitle':SjCexnwDcOTtIsiBzydLfXuRmVqaAM,'vsubtitle':'','contenttype':'programid',}
    SjCexnwDcOTtIsiBzydLfXuRmVqarY=json.dumps(SjCexnwDcOTtIsiBzydLfXuRmVqaoK)
    SjCexnwDcOTtIsiBzydLfXuRmVqarY=urllib.parse.quote(SjCexnwDcOTtIsiBzydLfXuRmVqarY)
    SjCexnwDcOTtIsiBzydLfXuRmVqaoN='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqarY)
    SjCexnwDcOTtIsiBzydLfXuRmVqaov.append(('(통합) 찜 영상에 추가',SjCexnwDcOTtIsiBzydLfXuRmVqaoN))
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img=SjCexnwDcOTtIsiBzydLfXuRmVqaoE,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabN,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU,ContextMenu=SjCexnwDcOTtIsiBzydLfXuRmVqaov)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAN:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['mode'] ='MOVIE_LIST' 
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['subapi']=SjCexnwDcOTtIsiBzydLfXuRmVqaJv 
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['page'] =SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM='[B]%s >>[/B]'%'다음 페이지'
   SjCexnwDcOTtIsiBzydLfXuRmVqarA=SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAv=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqarA,img=SjCexnwDcOTtIsiBzydLfXuRmVqaAv,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  xbmcplugin.setContent(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,'movies')
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(SjCexnwDcOTtIsiBzydLfXuRmVqaoH)>0:xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_Set_Bookmark(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaJW=urllib.parse.unquote(args.get('bm_param'))
  SjCexnwDcOTtIsiBzydLfXuRmVqaJW=json.loads(SjCexnwDcOTtIsiBzydLfXuRmVqaJW)
  SjCexnwDcOTtIsiBzydLfXuRmVqaok =SjCexnwDcOTtIsiBzydLfXuRmVqaJW.get('videoid')
  SjCexnwDcOTtIsiBzydLfXuRmVqaoF =SjCexnwDcOTtIsiBzydLfXuRmVqaJW.get('vidtype')
  SjCexnwDcOTtIsiBzydLfXuRmVqaJK =SjCexnwDcOTtIsiBzydLfXuRmVqaJW.get('vtitle')
  SjCexnwDcOTtIsiBzydLfXuRmVqaJg =SjCexnwDcOTtIsiBzydLfXuRmVqaJW.get('vsubtitle')
  SjCexnwDcOTtIsiBzydLfXuRmVqaJN=SjCexnwDcOTtIsiBzydLfXuRmVqaJW.get('contenttype')
  SjCexnwDcOTtIsiBzydLfXuRmVqaYU=xbmcgui.Dialog()
  SjCexnwDcOTtIsiBzydLfXuRmVqarF=SjCexnwDcOTtIsiBzydLfXuRmVqaYU.yesno(__language__(30913).encode('utf8'),SjCexnwDcOTtIsiBzydLfXuRmVqaJK+' \n\n'+__language__(30914))
  if SjCexnwDcOTtIsiBzydLfXuRmVqarF==SjCexnwDcOTtIsiBzydLfXuRmVqabN:return
  SjCexnwDcOTtIsiBzydLfXuRmVqabY=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.GetBookmarkInfo(SjCexnwDcOTtIsiBzydLfXuRmVqaok,SjCexnwDcOTtIsiBzydLfXuRmVqaoF,SjCexnwDcOTtIsiBzydLfXuRmVqaJN)
  SjCexnwDcOTtIsiBzydLfXuRmVqabA=json.dumps(SjCexnwDcOTtIsiBzydLfXuRmVqabY)
  SjCexnwDcOTtIsiBzydLfXuRmVqabA=urllib.parse.quote(SjCexnwDcOTtIsiBzydLfXuRmVqabA)
  SjCexnwDcOTtIsiBzydLfXuRmVqaoN ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqabA)
  xbmc.executebuiltin(SjCexnwDcOTtIsiBzydLfXuRmVqaoN)
 def dp_Episode_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaok =args.get('videoid')
  SjCexnwDcOTtIsiBzydLfXuRmVqaoF =args.get('vidtype')
  SjCexnwDcOTtIsiBzydLfXuRmVqaol=SjCexnwDcOTtIsiBzydLfXuRmVqabK(args.get('page'))
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH,SjCexnwDcOTtIsiBzydLfXuRmVqaAN=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_Episode_List(SjCexnwDcOTtIsiBzydLfXuRmVqaok,SjCexnwDcOTtIsiBzydLfXuRmVqaoF,SjCexnwDcOTtIsiBzydLfXuRmVqaol,orderby=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_winEpisodeOrderby())
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   SjCexnwDcOTtIsiBzydLfXuRmVqarA='%s회, %s(%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('episodenumber'),SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('releasedate'),SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('releaseweekday'))
   SjCexnwDcOTtIsiBzydLfXuRmVqabo ='[%s]\n\n%s'%(SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('episodetitle'),SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('synopsis'))
   SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'mediatype':'episode','title':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('programtitle'),'year':SjCexnwDcOTtIsiBzydLfXuRmVqabK(SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('releasedate')[:4]),'aired':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('releasedate'),'mpaa':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('age'),'episode':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('episodenumber'),'duration':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('playtime'),'plot':SjCexnwDcOTtIsiBzydLfXuRmVqabo,'cast':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('episodeactors')}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'VOD','programid':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('programid'),'contentid':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('contentid'),'thumbnail':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('thumbnail'),'title':SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('programtitle'),'subtitle':SjCexnwDcOTtIsiBzydLfXuRmVqarA}
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('programtitle'),sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqarA,img=SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('thumbnail'),infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabN,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaol==1:
   SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'plot':'정렬순서를 변경합니다.'}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['mode'] ='ORDER_BY' 
   if SjCexnwDcOTtIsiBzydLfXuRmVqaYG.get_winEpisodeOrderby()=='desc':
    SjCexnwDcOTtIsiBzydLfXuRmVqaAM='정렬순서변경 : 최신화부터 -> 1회부터'
    SjCexnwDcOTtIsiBzydLfXuRmVqaAU['orderby']='asc'
   else:
    SjCexnwDcOTtIsiBzydLfXuRmVqaAM='정렬순서변경 : 1회부터 -> 최신화부터'
    SjCexnwDcOTtIsiBzydLfXuRmVqaAU['orderby']='desc'
   SjCexnwDcOTtIsiBzydLfXuRmVqaAv=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel='',img=SjCexnwDcOTtIsiBzydLfXuRmVqaAv,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabN,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU,isLink=SjCexnwDcOTtIsiBzydLfXuRmVqabg)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAN:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['mode'] ='EPISODE_LIST' 
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['videoid']=SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('programid')
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['vidtype']='programid'
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU['page'] =SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAM='[B]%s >>[/B]'%'다음 페이지'
   SjCexnwDcOTtIsiBzydLfXuRmVqarA=SjCexnwDcOTtIsiBzydLfXuRmVqaGP(SjCexnwDcOTtIsiBzydLfXuRmVqaol+1)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAv=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaAM,sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqarA,img=SjCexnwDcOTtIsiBzydLfXuRmVqaAv,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqabW,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabg,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  xbmcplugin.setContent(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,'episodes')
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(SjCexnwDcOTtIsiBzydLfXuRmVqaoH)>0:xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_LiveChannel_List(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqabr =args.get('genre')
  SjCexnwDcOTtIsiBzydLfXuRmVqaJp=args.get('baseapi')
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_LiveChannel_List(SjCexnwDcOTtIsiBzydLfXuRmVqabr,SjCexnwDcOTtIsiBzydLfXuRmVqaJp)
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   SjCexnwDcOTtIsiBzydLfXuRmVqaJk =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('channelid')
   SjCexnwDcOTtIsiBzydLfXuRmVqaJF =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('studio')
   SjCexnwDcOTtIsiBzydLfXuRmVqaJE=SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('tvshowtitle')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoE =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('thumbnail')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoW =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('age')
   SjCexnwDcOTtIsiBzydLfXuRmVqabP =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('epg')
   SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'mediatype':'episode','mpaa':SjCexnwDcOTtIsiBzydLfXuRmVqaoW,'title':'%s < %s >'%(SjCexnwDcOTtIsiBzydLfXuRmVqaJF,SjCexnwDcOTtIsiBzydLfXuRmVqaJE),'tvshowtitle':SjCexnwDcOTtIsiBzydLfXuRmVqaJE,'studio':SjCexnwDcOTtIsiBzydLfXuRmVqaJF,'plot':'%s\n\n%s'%(SjCexnwDcOTtIsiBzydLfXuRmVqaJF,SjCexnwDcOTtIsiBzydLfXuRmVqabP)}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'LIVE','contentid':SjCexnwDcOTtIsiBzydLfXuRmVqaJk}
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqaJF,sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqaJE,img=SjCexnwDcOTtIsiBzydLfXuRmVqaoE,infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabN,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaGo(SjCexnwDcOTtIsiBzydLfXuRmVqaoH)>0:xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_Sports_GameList(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,args):
  SjCexnwDcOTtIsiBzydLfXuRmVqaoH=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.Get_Sports_Gamelist()
  for SjCexnwDcOTtIsiBzydLfXuRmVqaoh in SjCexnwDcOTtIsiBzydLfXuRmVqaoH:
   SjCexnwDcOTtIsiBzydLfXuRmVqabJ =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('game_date')
   SjCexnwDcOTtIsiBzydLfXuRmVqabG =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('game_time')
   SjCexnwDcOTtIsiBzydLfXuRmVqabM =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('svc_id')
   SjCexnwDcOTtIsiBzydLfXuRmVqabQ =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('away_team')
   SjCexnwDcOTtIsiBzydLfXuRmVqabp =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('home_team')
   SjCexnwDcOTtIsiBzydLfXuRmVqabv=SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('game_status')
   SjCexnwDcOTtIsiBzydLfXuRmVqabU =SjCexnwDcOTtIsiBzydLfXuRmVqaoh.get('game_place')
   SjCexnwDcOTtIsiBzydLfXuRmVqabl ='%s vs %s (%s)'%(SjCexnwDcOTtIsiBzydLfXuRmVqabQ,SjCexnwDcOTtIsiBzydLfXuRmVqabp,SjCexnwDcOTtIsiBzydLfXuRmVqabU)
   SjCexnwDcOTtIsiBzydLfXuRmVqabH =SjCexnwDcOTtIsiBzydLfXuRmVqabJ+' '+SjCexnwDcOTtIsiBzydLfXuRmVqabG
   if SjCexnwDcOTtIsiBzydLfXuRmVqabv=='LIVE':
    SjCexnwDcOTtIsiBzydLfXuRmVqabv='~경기중~'
   elif SjCexnwDcOTtIsiBzydLfXuRmVqabv=='END':
    SjCexnwDcOTtIsiBzydLfXuRmVqabv='경기종료'
   elif SjCexnwDcOTtIsiBzydLfXuRmVqabv=='CANCEL':
    SjCexnwDcOTtIsiBzydLfXuRmVqabv='취소'
   else:
    SjCexnwDcOTtIsiBzydLfXuRmVqabv=''
   if SjCexnwDcOTtIsiBzydLfXuRmVqabv=='':
    SjCexnwDcOTtIsiBzydLfXuRmVqarA=SjCexnwDcOTtIsiBzydLfXuRmVqabl
   else:
    SjCexnwDcOTtIsiBzydLfXuRmVqarA=SjCexnwDcOTtIsiBzydLfXuRmVqabl+'  '+SjCexnwDcOTtIsiBzydLfXuRmVqabv
   SjCexnwDcOTtIsiBzydLfXuRmVqaoU={'mediatype':'episode','title':SjCexnwDcOTtIsiBzydLfXuRmVqabl,'plot':'%s\n\n%s\n\n%s'%(SjCexnwDcOTtIsiBzydLfXuRmVqabH,SjCexnwDcOTtIsiBzydLfXuRmVqabl,SjCexnwDcOTtIsiBzydLfXuRmVqabv)}
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'SPORTS','contentid':SjCexnwDcOTtIsiBzydLfXuRmVqabM}
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.add_dir(SjCexnwDcOTtIsiBzydLfXuRmVqabH,sublabel=SjCexnwDcOTtIsiBzydLfXuRmVqarA,img='',infoLabels=SjCexnwDcOTtIsiBzydLfXuRmVqaoU,isFolder=SjCexnwDcOTtIsiBzydLfXuRmVqabN,params=SjCexnwDcOTtIsiBzydLfXuRmVqaAU)
  xbmcplugin.endOfDirectory(SjCexnwDcOTtIsiBzydLfXuRmVqaYG._addon_handle,cacheToDisc=SjCexnwDcOTtIsiBzydLfXuRmVqabN)
 def dp_View_Detail(SjCexnwDcOTtIsiBzydLfXuRmVqaYG,SjCexnwDcOTtIsiBzydLfXuRmVqabF):
  SjCexnwDcOTtIsiBzydLfXuRmVqaok =SjCexnwDcOTtIsiBzydLfXuRmVqabF.get('videoid')
  SjCexnwDcOTtIsiBzydLfXuRmVqaoF =SjCexnwDcOTtIsiBzydLfXuRmVqabF.get('vidtype') 
  SjCexnwDcOTtIsiBzydLfXuRmVqaJN=SjCexnwDcOTtIsiBzydLfXuRmVqabF.get('contenttype')
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.addon_log(SjCexnwDcOTtIsiBzydLfXuRmVqaok)
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.addon_log(SjCexnwDcOTtIsiBzydLfXuRmVqaoF)
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.addon_log(SjCexnwDcOTtIsiBzydLfXuRmVqaJN)
  SjCexnwDcOTtIsiBzydLfXuRmVqabY=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.WavveObj.GetBookmarkInfo(SjCexnwDcOTtIsiBzydLfXuRmVqaok,SjCexnwDcOTtIsiBzydLfXuRmVqaoF,SjCexnwDcOTtIsiBzydLfXuRmVqaJN)
  if SjCexnwDcOTtIsiBzydLfXuRmVqaoF=='tvshow':
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'EPISODE_LIST','videoid':SjCexnwDcOTtIsiBzydLfXuRmVqabY['indexinfo']['videoid'],'vidtype':SjCexnwDcOTtIsiBzydLfXuRmVqabY['indexinfo']['vidtype'],'page':'1',}
   SjCexnwDcOTtIsiBzydLfXuRmVqarg='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(SjCexnwDcOTtIsiBzydLfXuRmVqaAU))
  else:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAU={'mode':'MOVIE','contentid':SjCexnwDcOTtIsiBzydLfXuRmVqabY['indexinfo']['videoid'],'title':SjCexnwDcOTtIsiBzydLfXuRmVqabY['saveinfo']['infoLabels']['title'],'thumbnail':SjCexnwDcOTtIsiBzydLfXuRmVqabY['saveinfo']['thumbnail'],'age':SjCexnwDcOTtIsiBzydLfXuRmVqabY['saveinfo']['infoLabels']['mpaa'],}
   SjCexnwDcOTtIsiBzydLfXuRmVqarg='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(SjCexnwDcOTtIsiBzydLfXuRmVqaAU))
  SjCexnwDcOTtIsiBzydLfXuRmVqaAQ=xbmcgui.ListItem(label=SjCexnwDcOTtIsiBzydLfXuRmVqabY['saveinfo']['title'],path=SjCexnwDcOTtIsiBzydLfXuRmVqarg)
  SjCexnwDcOTtIsiBzydLfXuRmVqaAQ.setArt(SjCexnwDcOTtIsiBzydLfXuRmVqabY['saveinfo']['thumbnail'])
  SjCexnwDcOTtIsiBzydLfXuRmVqaAQ.setInfo('Video',SjCexnwDcOTtIsiBzydLfXuRmVqabY['saveinfo']['infoLabels'])
  if SjCexnwDcOTtIsiBzydLfXuRmVqaoF=='movie':
   SjCexnwDcOTtIsiBzydLfXuRmVqaAQ.setIsFolder(SjCexnwDcOTtIsiBzydLfXuRmVqabN)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAQ.setProperty('IsPlayable','true')
  else:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAQ.setIsFolder(SjCexnwDcOTtIsiBzydLfXuRmVqabg)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAQ.setProperty('IsPlayable','false')
  SjCexnwDcOTtIsiBzydLfXuRmVqaYU=xbmcgui.Dialog()
  SjCexnwDcOTtIsiBzydLfXuRmVqaYU.info(SjCexnwDcOTtIsiBzydLfXuRmVqaAQ)
 def wavve_main(SjCexnwDcOTtIsiBzydLfXuRmVqaYG):
  SjCexnwDcOTtIsiBzydLfXuRmVqabh=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.main_params.get('params')
  if SjCexnwDcOTtIsiBzydLfXuRmVqabh:
   SjCexnwDcOTtIsiBzydLfXuRmVqabk =base64.standard_b64decode(SjCexnwDcOTtIsiBzydLfXuRmVqabh).decode('utf-8')
   SjCexnwDcOTtIsiBzydLfXuRmVqabk =json.loads(SjCexnwDcOTtIsiBzydLfXuRmVqabk)
   SjCexnwDcOTtIsiBzydLfXuRmVqaAW =SjCexnwDcOTtIsiBzydLfXuRmVqabk.get('mode')
   SjCexnwDcOTtIsiBzydLfXuRmVqabF =SjCexnwDcOTtIsiBzydLfXuRmVqabk.get('values')
  else:
   SjCexnwDcOTtIsiBzydLfXuRmVqaAW=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.main_params.get('mode',SjCexnwDcOTtIsiBzydLfXuRmVqabW)
   SjCexnwDcOTtIsiBzydLfXuRmVqabF=SjCexnwDcOTtIsiBzydLfXuRmVqaYG.main_params
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='LOGOUT':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.logout()
   return
  SjCexnwDcOTtIsiBzydLfXuRmVqaYG.login_main()
  if SjCexnwDcOTtIsiBzydLfXuRmVqaAW is SjCexnwDcOTtIsiBzydLfXuRmVqabW:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Main_List()
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW in['LIVE','VOD','MOVIE','SPORTS']:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.play_VIDEO(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='LIVE_CATAGORY':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_LiveCatagory_List(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='MAIN_CATAGORY':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_MainCatagory_List(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='SUPERSECTION_LIST':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_SuperSection_List(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='BANDLIVESECTION_LIST':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_BandLiveSection_List(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='BAND2SECTION_LIST':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Band2Section_List(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='PROGRAM_LIST':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Program_List(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='EPISODE_LIST':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Episode_List(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='MOVIE_LIST':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Movie_List(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='LIVE_LIST':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_LiveChannel_List(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='ORDER_BY':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_setEpOrderby(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='SEARCH_GROUP':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Search_Group(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW in['SEARCH_LIST','LOCAL_SEARCH']:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Search_List(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='WATCH_GROUP':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Watch_Group(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='WATCH_LIST':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Watch_List(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='SET_BOOKMARK':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Set_Bookmark(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_History_Remove(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW in['TOTAL_SEARCH','TOTAL_HISTORY']:
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Global_Search(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='SEARCH_HISTORY':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Search_History(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='MENU_BOOKMARK':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Bookmark_Menu(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='GAME_LIST':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_Sports_GameList(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  elif SjCexnwDcOTtIsiBzydLfXuRmVqaAW=='VIEW_DETAIL':
   SjCexnwDcOTtIsiBzydLfXuRmVqaYG.dp_View_Detail(SjCexnwDcOTtIsiBzydLfXuRmVqabF)
  else:
   SjCexnwDcOTtIsiBzydLfXuRmVqabW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
