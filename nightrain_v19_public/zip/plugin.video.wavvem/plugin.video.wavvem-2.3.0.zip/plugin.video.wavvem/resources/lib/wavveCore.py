__author__="NightRain"
gyaqVnoXCYANWFulBjxTLKJsIpRckw=object
gyaqVnoXCYANWFulBjxTLKJsIpRckt=None
gyaqVnoXCYANWFulBjxTLKJsIpRckz=False
gyaqVnoXCYANWFulBjxTLKJsIpRckE=open
gyaqVnoXCYANWFulBjxTLKJsIpRckh=True
gyaqVnoXCYANWFulBjxTLKJsIpRckH=range
gyaqVnoXCYANWFulBjxTLKJsIpRcke=str
gyaqVnoXCYANWFulBjxTLKJsIpRckv=Exception
gyaqVnoXCYANWFulBjxTLKJsIpRckU=print
gyaqVnoXCYANWFulBjxTLKJsIpRckf=dict
gyaqVnoXCYANWFulBjxTLKJsIpRckO=int
gyaqVnoXCYANWFulBjxTLKJsIpRckS=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class gyaqVnoXCYANWFulBjxTLKJsIpRcMw(gyaqVnoXCYANWFulBjxTLKJsIpRckw):
 def __init__(gyaqVnoXCYANWFulBjxTLKJsIpRcMt):
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN='https://apis.wavve.com'
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV ={}
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Init_WV_Total()
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.DEVICE ='pc'
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.DRM ='wm'
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.PARTNER ='pooq'
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.POOQZONE ='none'
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.REGION ='kor'
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.TARGETAGE ='all'
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.HTTPTAG ='https://'
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.LIST_LIMIT=30 
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.EP_LIMIT =30 
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.MV_LIMIT =24 
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.SEARCH_LIMIT=20 
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36'
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.DEFAULT_HEADER={'user-agent':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.USER_AGENT}
 def Init_WV_Total(gyaqVnoXCYANWFulBjxTLKJsIpRcMt):
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV={'account':{},'cookies':{},}
 def callRequestCookies(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,jobtype,gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRckt,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt,redirects=gyaqVnoXCYANWFulBjxTLKJsIpRckz):
  gyaqVnoXCYANWFulBjxTLKJsIpRcMz=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.DEFAULT_HEADER
  if headers:gyaqVnoXCYANWFulBjxTLKJsIpRcMz.update(headers)
  if jobtype=='Get':
   gyaqVnoXCYANWFulBjxTLKJsIpRcME=requests.get(gyaqVnoXCYANWFulBjxTLKJsIpRcMr,params=params,headers=gyaqVnoXCYANWFulBjxTLKJsIpRcMz,cookies=cookies,allow_redirects=redirects)
  else:
   gyaqVnoXCYANWFulBjxTLKJsIpRcME=requests.post(gyaqVnoXCYANWFulBjxTLKJsIpRcMr,data=payload,params=params,headers=gyaqVnoXCYANWFulBjxTLKJsIpRcMz,cookies=cookies,allow_redirects=redirects)
  return gyaqVnoXCYANWFulBjxTLKJsIpRcME
 def JsonFile_Save(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,filename,gyaqVnoXCYANWFulBjxTLKJsIpRcMk):
  if filename=='':return gyaqVnoXCYANWFulBjxTLKJsIpRckz
  try:
   fp=gyaqVnoXCYANWFulBjxTLKJsIpRckE(filename,'w',-1,'utf-8')
   json.dump(gyaqVnoXCYANWFulBjxTLKJsIpRcMk,fp,indent=4,ensure_ascii=gyaqVnoXCYANWFulBjxTLKJsIpRckz)
   fp.close()
  except:
   return gyaqVnoXCYANWFulBjxTLKJsIpRckz
  return gyaqVnoXCYANWFulBjxTLKJsIpRckh
 def JsonFile_Load(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,filename):
  if filename=='':return{}
  try:
   fp=gyaqVnoXCYANWFulBjxTLKJsIpRckE(filename,'r',-1,'utf-8')
   gyaqVnoXCYANWFulBjxTLKJsIpRcMH=json.load(fp)
   fp.close()
  except:
   return{}
  return gyaqVnoXCYANWFulBjxTLKJsIpRcMH
 def Save_session_acount(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,gyaqVnoXCYANWFulBjxTLKJsIpRcMe,gyaqVnoXCYANWFulBjxTLKJsIpRcMv,gyaqVnoXCYANWFulBjxTLKJsIpRcMU):
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV['account']['wvid']=base64.standard_b64encode(gyaqVnoXCYANWFulBjxTLKJsIpRcMe.encode()).decode('utf-8')
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV['account']['wvpw']=base64.standard_b64encode(gyaqVnoXCYANWFulBjxTLKJsIpRcMv.encode()).decode('utf-8')
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV['account']['wvpf']=gyaqVnoXCYANWFulBjxTLKJsIpRcMU 
 def Load_session_acount(gyaqVnoXCYANWFulBjxTLKJsIpRcMt):
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMe=base64.standard_b64decode(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV['account']['wvid']).decode('utf-8')
   gyaqVnoXCYANWFulBjxTLKJsIpRcMv=base64.standard_b64decode(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV['account']['wvpw']).decode('utf-8')
   gyaqVnoXCYANWFulBjxTLKJsIpRcMU=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV['account']['wvpf']
  except:
   return '','',0
  return gyaqVnoXCYANWFulBjxTLKJsIpRcMe,gyaqVnoXCYANWFulBjxTLKJsIpRcMv,gyaqVnoXCYANWFulBjxTLKJsIpRcMU
 def GetDefaultParams(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,login=gyaqVnoXCYANWFulBjxTLKJsIpRckh):
  gyaqVnoXCYANWFulBjxTLKJsIpRcMf={'apikey':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.APIKEY,'credential':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV['cookies']['credential']if login else 'none','device':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.DEVICE,'drm':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.DRM,'partner':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.PARTNER,'pooqzone':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.POOQZONE,'region':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.REGION,'targetage':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.TARGETAGE}
  return gyaqVnoXCYANWFulBjxTLKJsIpRcMf
 def GetGUID(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   gyaqVnoXCYANWFulBjxTLKJsIpRcMO=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   gyaqVnoXCYANWFulBjxTLKJsIpRcMS=GenerateRandomString(5)
   gyaqVnoXCYANWFulBjxTLKJsIpRcMQ=gyaqVnoXCYANWFulBjxTLKJsIpRcMS+media+gyaqVnoXCYANWFulBjxTLKJsIpRcMO
   return gyaqVnoXCYANWFulBjxTLKJsIpRcMQ
  def GenerateRandomString(num):
   from random import randint
   gyaqVnoXCYANWFulBjxTLKJsIpRcMP=""
   for i in gyaqVnoXCYANWFulBjxTLKJsIpRckH(0,num):
    s=gyaqVnoXCYANWFulBjxTLKJsIpRcke(randint(1,5))
    gyaqVnoXCYANWFulBjxTLKJsIpRcMP+=s
   return gyaqVnoXCYANWFulBjxTLKJsIpRcMP
  gyaqVnoXCYANWFulBjxTLKJsIpRcMQ=GenerateID(guid_str)
  gyaqVnoXCYANWFulBjxTLKJsIpRcMD=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetHash(gyaqVnoXCYANWFulBjxTLKJsIpRcMQ)
  if guidType==2:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMD='%s-%s-%s-%s-%s'%(gyaqVnoXCYANWFulBjxTLKJsIpRcMD[:8],gyaqVnoXCYANWFulBjxTLKJsIpRcMD[8:12],gyaqVnoXCYANWFulBjxTLKJsIpRcMD[12:16],gyaqVnoXCYANWFulBjxTLKJsIpRcMD[16:20],gyaqVnoXCYANWFulBjxTLKJsIpRcMD[20:])
  return gyaqVnoXCYANWFulBjxTLKJsIpRcMD
 def GetHash(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return gyaqVnoXCYANWFulBjxTLKJsIpRcke(m.hexdigest())
 def CheckQuality(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,sel_qt,qt_list):
  gyaqVnoXCYANWFulBjxTLKJsIpRcMm=0
  for gyaqVnoXCYANWFulBjxTLKJsIpRcMd in qt_list:
   if sel_qt>=gyaqVnoXCYANWFulBjxTLKJsIpRcMd:return gyaqVnoXCYANWFulBjxTLKJsIpRcMd
   gyaqVnoXCYANWFulBjxTLKJsIpRcMm=gyaqVnoXCYANWFulBjxTLKJsIpRcMd
  return gyaqVnoXCYANWFulBjxTLKJsIpRcMm
 def Get_Now_Datetime(gyaqVnoXCYANWFulBjxTLKJsIpRcMt):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,in_text):
  gyaqVnoXCYANWFulBjxTLKJsIpRcMb=in_text.replace('&lt;','<').replace('&gt;','>')
  gyaqVnoXCYANWFulBjxTLKJsIpRcMb=gyaqVnoXCYANWFulBjxTLKJsIpRcMb.replace('$O$','')
  gyaqVnoXCYANWFulBjxTLKJsIpRcMb=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',gyaqVnoXCYANWFulBjxTLKJsIpRcMb)
  gyaqVnoXCYANWFulBjxTLKJsIpRcMb=gyaqVnoXCYANWFulBjxTLKJsIpRcMb.lstrip('#')
  return gyaqVnoXCYANWFulBjxTLKJsIpRcMb
 def GetCredential(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,user_id,user_pw,user_pf):
  gyaqVnoXCYANWFulBjxTLKJsIpRcMG=gyaqVnoXCYANWFulBjxTLKJsIpRckz
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+ '/login'
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwM={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Post',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRcwM,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV['cookies']['credential']=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['credential']
   if user_pf!=0:
    gyaqVnoXCYANWFulBjxTLKJsIpRcwM={'id':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV['cookies']['credential'],'password':'','profile':gyaqVnoXCYANWFulBjxTLKJsIpRcke(user_pf),'pushid':'','type':'credential'}
    gyaqVnoXCYANWFulBjxTLKJsIpRcMf =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckh) 
    gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Post',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRcwM,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
    gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
    gyaqVnoXCYANWFulBjxTLKJsIpRcMt.WV['cookies']['credential']=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['credential']
   gyaqVnoXCYANWFulBjxTLKJsIpRcMG=gyaqVnoXCYANWFulBjxTLKJsIpRckh
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Init_WV_Total()
  return gyaqVnoXCYANWFulBjxTLKJsIpRcMG
 def GetIssue(gyaqVnoXCYANWFulBjxTLKJsIpRcMt):
  gyaqVnoXCYANWFulBjxTLKJsIpRcwE=gyaqVnoXCYANWFulBjxTLKJsIpRckz
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/guid/issue'
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams()
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwk=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['guid']
   gyaqVnoXCYANWFulBjxTLKJsIpRcwh=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['guidtimestamp']
   if gyaqVnoXCYANWFulBjxTLKJsIpRcwk:gyaqVnoXCYANWFulBjxTLKJsIpRcwE=gyaqVnoXCYANWFulBjxTLKJsIpRckh
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwk='none'
   gyaqVnoXCYANWFulBjxTLKJsIpRcwh='none' 
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.guid=gyaqVnoXCYANWFulBjxTLKJsIpRcwk
  gyaqVnoXCYANWFulBjxTLKJsIpRcMt.guidtimestamp=gyaqVnoXCYANWFulBjxTLKJsIpRcwh
  return gyaqVnoXCYANWFulBjxTLKJsIpRcwE
 def Baseapi_Parse(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,gyaqVnoXCYANWFulBjxTLKJsIpRcwU):
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcwH =urllib.parse.urlsplit(gyaqVnoXCYANWFulBjxTLKJsIpRcwU)
   if gyaqVnoXCYANWFulBjxTLKJsIpRcwH.netloc=='':
    gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.HTTPTAG+gyaqVnoXCYANWFulBjxTLKJsIpRcwH.netloc+gyaqVnoXCYANWFulBjxTLKJsIpRcwH.path
   else:
    gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcwH.scheme+'://'+gyaqVnoXCYANWFulBjxTLKJsIpRcwH.netloc+gyaqVnoXCYANWFulBjxTLKJsIpRcwH.path
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf=gyaqVnoXCYANWFulBjxTLKJsIpRckf(urllib.parse.parse_qsl(gyaqVnoXCYANWFulBjxTLKJsIpRcwH.query))
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return '',{}
  return gyaqVnoXCYANWFulBjxTLKJsIpRcMr,gyaqVnoXCYANWFulBjxTLKJsIpRcMf
 def GetSupermultiUrl(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,sCode,sIndex='0'):
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/cf/supermultisections/'+sCode
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwe=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['multisectionlist'][gyaqVnoXCYANWFulBjxTLKJsIpRckO(sIndex)]['eventlist'][1]['url']
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return ''
  return gyaqVnoXCYANWFulBjxTLKJsIpRcwe
 def Get_LiveCatagory_List(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,sCode,sIndex='0'):
  gyaqVnoXCYANWFulBjxTLKJsIpRcwv=[]
  gyaqVnoXCYANWFulBjxTLKJsIpRcwU =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetSupermultiUrl(sCode,sIndex)
  (gyaqVnoXCYANWFulBjxTLKJsIpRcMr,gyaqVnoXCYANWFulBjxTLKJsIpRcMf)=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Baseapi_Parse(gyaqVnoXCYANWFulBjxTLKJsIpRcwU)
  if gyaqVnoXCYANWFulBjxTLKJsIpRcMr=='':return gyaqVnoXCYANWFulBjxTLKJsIpRcwv,''
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('filter_item_list' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz['filter']['filterlist'][0]):return[],''
   gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['filter']['filterlist'][0]['filter_item_list']
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcwO:
    gyaqVnoXCYANWFulBjxTLKJsIpRcwQ={'title':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title'],'genre':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['api_parameters'][gyaqVnoXCYANWFulBjxTLKJsIpRcwS['api_parameters'].index('=')+1:]}
    gyaqVnoXCYANWFulBjxTLKJsIpRcwv.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwQ)
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[],''
  return gyaqVnoXCYANWFulBjxTLKJsIpRcwv,gyaqVnoXCYANWFulBjxTLKJsIpRcwU
 def Get_MainCatagory_List(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,sCode,sIndex='0'):
  gyaqVnoXCYANWFulBjxTLKJsIpRcwv=[]
  gyaqVnoXCYANWFulBjxTLKJsIpRcwU =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetSupermultiUrl(sCode,sIndex)
  (gyaqVnoXCYANWFulBjxTLKJsIpRcMr,gyaqVnoXCYANWFulBjxTLKJsIpRcMf)=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Baseapi_Parse(gyaqVnoXCYANWFulBjxTLKJsIpRcwU)
  if gyaqVnoXCYANWFulBjxTLKJsIpRcMr=='':return gyaqVnoXCYANWFulBjxTLKJsIpRcwv
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('celllist' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz['band']):return[]
   gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['band']['celllist']
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcwO:
    gyaqVnoXCYANWFulBjxTLKJsIpRcwP =gyaqVnoXCYANWFulBjxTLKJsIpRcwS['event_list'][1]['url']
    (gyaqVnoXCYANWFulBjxTLKJsIpRcwD,gyaqVnoXCYANWFulBjxTLKJsIpRcwm)=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Baseapi_Parse(gyaqVnoXCYANWFulBjxTLKJsIpRcwP)
    gyaqVnoXCYANWFulBjxTLKJsIpRcwQ={'title':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title_list'][0]['text'],'suburl':gyaqVnoXCYANWFulBjxTLKJsIpRcwD,'subapi':gyaqVnoXCYANWFulBjxTLKJsIpRcwm.get('api'),'subtype':'catagory' if gyaqVnoXCYANWFulBjxTLKJsIpRcwm else 'supersection'}
    gyaqVnoXCYANWFulBjxTLKJsIpRcwv.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwQ)
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[]
  return gyaqVnoXCYANWFulBjxTLKJsIpRcwv
 def Get_SuperMultiSection_List(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,subapi_text):
  gyaqVnoXCYANWFulBjxTLKJsIpRcwv=[]
  gyaqVnoXCYANWFulBjxTLKJsIpRcMf={}
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcwH =urllib.parse.urlsplit(subapi_text)
   if gyaqVnoXCYANWFulBjxTLKJsIpRcwH.path.find('apis.wavve.com')>=0: 
    gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.HTTPTAG+gyaqVnoXCYANWFulBjxTLKJsIpRcwH.path 
    gyaqVnoXCYANWFulBjxTLKJsIpRcMf=gyaqVnoXCYANWFulBjxTLKJsIpRckf(urllib.parse.parse_qsl(gyaqVnoXCYANWFulBjxTLKJsIpRcwH.query))
   else:
    gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/cf'+gyaqVnoXCYANWFulBjxTLKJsIpRcwH.path 
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMr.replace('supermultisection/','supermultisections/')
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[]
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRckt,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('multisectionlist' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz):return[]
   gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['multisectionlist']
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcwO:
    gyaqVnoXCYANWFulBjxTLKJsIpRcwd=gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title']
    if gyaqVnoXCYANWFulBjxTLKJsIpRckS(gyaqVnoXCYANWFulBjxTLKJsIpRcwd)==0:continue
    if gyaqVnoXCYANWFulBjxTLKJsIpRcwd=='minor':continue
    if re.search(u'베너',gyaqVnoXCYANWFulBjxTLKJsIpRcwd):continue
    if re.search(u'배너',gyaqVnoXCYANWFulBjxTLKJsIpRcwd):continue 
    if gyaqVnoXCYANWFulBjxTLKJsIpRcwS['force_refresh']=='y':continue
    if gyaqVnoXCYANWFulBjxTLKJsIpRckS(gyaqVnoXCYANWFulBjxTLKJsIpRcwS['eventlist'])>=3:
     gyaqVnoXCYANWFulBjxTLKJsIpRcwm =gyaqVnoXCYANWFulBjxTLKJsIpRcwS['eventlist'][2]['url']
    else:
     gyaqVnoXCYANWFulBjxTLKJsIpRcwm =gyaqVnoXCYANWFulBjxTLKJsIpRcwS['eventlist'][1]['url']
    gyaqVnoXCYANWFulBjxTLKJsIpRcwi=gyaqVnoXCYANWFulBjxTLKJsIpRcwS['cell_type']
    if gyaqVnoXCYANWFulBjxTLKJsIpRcwi=='band_2':
     if gyaqVnoXCYANWFulBjxTLKJsIpRcwm.find('channellist=')>=0:
      gyaqVnoXCYANWFulBjxTLKJsIpRcwi='band_live'
    gyaqVnoXCYANWFulBjxTLKJsIpRcwQ={'title':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Get_ChangeText(gyaqVnoXCYANWFulBjxTLKJsIpRcwd),'subapi':gyaqVnoXCYANWFulBjxTLKJsIpRcwm,'cell_type':gyaqVnoXCYANWFulBjxTLKJsIpRcwi}
    gyaqVnoXCYANWFulBjxTLKJsIpRcwv.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwQ)
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[]
  return gyaqVnoXCYANWFulBjxTLKJsIpRcwv
 def Get_BandLiveSection_List(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,gyaqVnoXCYANWFulBjxTLKJsIpRcwU,page_int=1):
  gyaqVnoXCYANWFulBjxTLKJsIpRcwb=[]
  gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRctk=1
  gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRckz
  try:
   (gyaqVnoXCYANWFulBjxTLKJsIpRcMr,gyaqVnoXCYANWFulBjxTLKJsIpRcMf)=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Baseapi_Parse(gyaqVnoXCYANWFulBjxTLKJsIpRcwU)
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[],gyaqVnoXCYANWFulBjxTLKJsIpRckz
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['limit']=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.LIST_LIMIT
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['offset']=gyaqVnoXCYANWFulBjxTLKJsIpRcke((page_int-1)*gyaqVnoXCYANWFulBjxTLKJsIpRcMt.LIST_LIMIT)
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('celllist' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']):return[],gyaqVnoXCYANWFulBjxTLKJsIpRckz
   gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['celllist']
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcwO:
    gyaqVnoXCYANWFulBjxTLKJsIpRctM =gyaqVnoXCYANWFulBjxTLKJsIpRcwS['event_list'][1]['url']
    gyaqVnoXCYANWFulBjxTLKJsIpRctw=urllib.parse.urlsplit(gyaqVnoXCYANWFulBjxTLKJsIpRctM).query
    gyaqVnoXCYANWFulBjxTLKJsIpRctw=gyaqVnoXCYANWFulBjxTLKJsIpRckf(urllib.parse.parse_qsl(gyaqVnoXCYANWFulBjxTLKJsIpRctw))
    gyaqVnoXCYANWFulBjxTLKJsIpRctz='channelid'
    gyaqVnoXCYANWFulBjxTLKJsIpRctE=gyaqVnoXCYANWFulBjxTLKJsIpRctw[gyaqVnoXCYANWFulBjxTLKJsIpRctz]
    gyaqVnoXCYANWFulBjxTLKJsIpRcwQ={'studio':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title_list'][0]['text'],'tvshowtitle':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Get_ChangeText(gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title_list'][1]['text']),'channelid':gyaqVnoXCYANWFulBjxTLKJsIpRctE,'age':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('age'),'thumbnail':'https://%s'%gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('thumbnail')}
    gyaqVnoXCYANWFulBjxTLKJsIpRcwb.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwQ)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['pagecount'])
   if gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['count']:gyaqVnoXCYANWFulBjxTLKJsIpRctk =gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['count'])
   else:gyaqVnoXCYANWFulBjxTLKJsIpRctk=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.LIST_LIMIT*page_int
   gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRcwG>gyaqVnoXCYANWFulBjxTLKJsIpRctk
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[],gyaqVnoXCYANWFulBjxTLKJsIpRckz
  return gyaqVnoXCYANWFulBjxTLKJsIpRcwb,gyaqVnoXCYANWFulBjxTLKJsIpRcwr
 def Get_Band2Section_List(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,gyaqVnoXCYANWFulBjxTLKJsIpRcwU,page_int=1):
  gyaqVnoXCYANWFulBjxTLKJsIpRcth=[]
  gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRctk=1
  gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRckz
  try:
   (gyaqVnoXCYANWFulBjxTLKJsIpRcMr,gyaqVnoXCYANWFulBjxTLKJsIpRcMf)=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Baseapi_Parse(gyaqVnoXCYANWFulBjxTLKJsIpRcwU)
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[],gyaqVnoXCYANWFulBjxTLKJsIpRckz
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['came'] ='BandView'
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['limit']=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.LIST_LIMIT
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['offset']=gyaqVnoXCYANWFulBjxTLKJsIpRcke((page_int-1)*gyaqVnoXCYANWFulBjxTLKJsIpRcMt.LIST_LIMIT)
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('celllist' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']):return[],gyaqVnoXCYANWFulBjxTLKJsIpRckz
   gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['celllist']
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcwO:
    gyaqVnoXCYANWFulBjxTLKJsIpRctM =gyaqVnoXCYANWFulBjxTLKJsIpRcwS['event_list'][1]['url']
    gyaqVnoXCYANWFulBjxTLKJsIpRctw=urllib.parse.urlsplit(gyaqVnoXCYANWFulBjxTLKJsIpRctM).query
    gyaqVnoXCYANWFulBjxTLKJsIpRctw=gyaqVnoXCYANWFulBjxTLKJsIpRckf(urllib.parse.parse_qsl(gyaqVnoXCYANWFulBjxTLKJsIpRctw))
    gyaqVnoXCYANWFulBjxTLKJsIpRctz='contentid'
    gyaqVnoXCYANWFulBjxTLKJsIpRctE=gyaqVnoXCYANWFulBjxTLKJsIpRctw[gyaqVnoXCYANWFulBjxTLKJsIpRctz]
    gyaqVnoXCYANWFulBjxTLKJsIpRcwQ={'programtitle':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title_list'][0]['text'],'episodetitle':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Get_ChangeText(gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title_list'][1]['text']),'age':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('age'),'thumbnail':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.HTTPTAG+gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('thumbnail'),'vidtype':gyaqVnoXCYANWFulBjxTLKJsIpRctz,'videoid':gyaqVnoXCYANWFulBjxTLKJsIpRctE}
    gyaqVnoXCYANWFulBjxTLKJsIpRcth.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwQ)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['pagecount'])
   if gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['count']:gyaqVnoXCYANWFulBjxTLKJsIpRctk =gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['count'])
   else:gyaqVnoXCYANWFulBjxTLKJsIpRctk=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.LIST_LIMIT*page_int
   gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRcwG>gyaqVnoXCYANWFulBjxTLKJsIpRctk
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[],gyaqVnoXCYANWFulBjxTLKJsIpRckz
  return gyaqVnoXCYANWFulBjxTLKJsIpRcth,gyaqVnoXCYANWFulBjxTLKJsIpRcwr
 def Get_Program_List(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,gyaqVnoXCYANWFulBjxTLKJsIpRcwU,page_int=1,orderby='-'):
  gyaqVnoXCYANWFulBjxTLKJsIpRctH=[]
  gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRctk=1
  gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRckz
  (gyaqVnoXCYANWFulBjxTLKJsIpRcMr,gyaqVnoXCYANWFulBjxTLKJsIpRcMf)=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Baseapi_Parse(gyaqVnoXCYANWFulBjxTLKJsIpRcwU)
  if gyaqVnoXCYANWFulBjxTLKJsIpRcMr=='':return gyaqVnoXCYANWFulBjxTLKJsIpRctH,gyaqVnoXCYANWFulBjxTLKJsIpRcwr
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['limit'] =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.LIST_LIMIT
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['offset']=gyaqVnoXCYANWFulBjxTLKJsIpRcke((page_int-1)*gyaqVnoXCYANWFulBjxTLKJsIpRcMt.LIST_LIMIT)
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['page'] =gyaqVnoXCYANWFulBjxTLKJsIpRcke(page_int)
   if gyaqVnoXCYANWFulBjxTLKJsIpRcMf.get('orderby')!='' and gyaqVnoXCYANWFulBjxTLKJsIpRcMf.get('orderby')!='regdatefirst' and orderby!='-':
    gyaqVnoXCYANWFulBjxTLKJsIpRcMf['orderby']=orderby 
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if gyaqVnoXCYANWFulBjxTLKJsIpRcwU.find('instantplay')>=0:
    if not('celllist' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz['band']):return gyaqVnoXCYANWFulBjxTLKJsIpRctH,gyaqVnoXCYANWFulBjxTLKJsIpRcwr
    gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['band']['celllist']
   else:
    if not('celllist' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']):return gyaqVnoXCYANWFulBjxTLKJsIpRctH,gyaqVnoXCYANWFulBjxTLKJsIpRcwr
    gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['celllist']
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcwO:
    for gyaqVnoXCYANWFulBjxTLKJsIpRcte in gyaqVnoXCYANWFulBjxTLKJsIpRcwS['event_list']:
     if gyaqVnoXCYANWFulBjxTLKJsIpRcte.get('type')=='on-navigation':
      gyaqVnoXCYANWFulBjxTLKJsIpRctM =gyaqVnoXCYANWFulBjxTLKJsIpRcte['url']
    gyaqVnoXCYANWFulBjxTLKJsIpRctw=urllib.parse.urlsplit(gyaqVnoXCYANWFulBjxTLKJsIpRctM).query
    gyaqVnoXCYANWFulBjxTLKJsIpRctz=gyaqVnoXCYANWFulBjxTLKJsIpRctw[0:gyaqVnoXCYANWFulBjxTLKJsIpRctw.find('=')]
    gyaqVnoXCYANWFulBjxTLKJsIpRctE=gyaqVnoXCYANWFulBjxTLKJsIpRctw[gyaqVnoXCYANWFulBjxTLKJsIpRctw.find('=')+1:]
    gyaqVnoXCYANWFulBjxTLKJsIpRcwQ={'title':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title_list'][0]['text'],'age':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['age'],'thumbnail':'https://%s'%gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('thumbnail'),'videoid':gyaqVnoXCYANWFulBjxTLKJsIpRctE,'vidtype':gyaqVnoXCYANWFulBjxTLKJsIpRctz}
    gyaqVnoXCYANWFulBjxTLKJsIpRctH.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwQ)
   if gyaqVnoXCYANWFulBjxTLKJsIpRcwU.find('instantplay')<0:
    gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['pagecount'])
    if gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['count']:gyaqVnoXCYANWFulBjxTLKJsIpRctk =gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['count'])
    else:gyaqVnoXCYANWFulBjxTLKJsIpRctk=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.LIST_LIMIT*page_int
    gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRcwG>gyaqVnoXCYANWFulBjxTLKJsIpRctk
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[],gyaqVnoXCYANWFulBjxTLKJsIpRckz
  return gyaqVnoXCYANWFulBjxTLKJsIpRctH,gyaqVnoXCYANWFulBjxTLKJsIpRcwr
 def Get_Movie_List(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,gyaqVnoXCYANWFulBjxTLKJsIpRcwU,page_int=1):
  gyaqVnoXCYANWFulBjxTLKJsIpRctv=[]
  gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRctk=1
  gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRckz
  (gyaqVnoXCYANWFulBjxTLKJsIpRcMr,gyaqVnoXCYANWFulBjxTLKJsIpRcMf)=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Baseapi_Parse(gyaqVnoXCYANWFulBjxTLKJsIpRcwU)
  if gyaqVnoXCYANWFulBjxTLKJsIpRcMr=='':return gyaqVnoXCYANWFulBjxTLKJsIpRctv,gyaqVnoXCYANWFulBjxTLKJsIpRcwr
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['limit']=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.MV_LIMIT
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['offset']=gyaqVnoXCYANWFulBjxTLKJsIpRcke((page_int-1)*gyaqVnoXCYANWFulBjxTLKJsIpRcMt.MV_LIMIT)
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('celllist' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']):return gyaqVnoXCYANWFulBjxTLKJsIpRctv,gyaqVnoXCYANWFulBjxTLKJsIpRcwr
   gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['celllist']
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcwO:
    gyaqVnoXCYANWFulBjxTLKJsIpRctM =gyaqVnoXCYANWFulBjxTLKJsIpRcwS['event_list'][1]['url']
    gyaqVnoXCYANWFulBjxTLKJsIpRctw=urllib.parse.urlsplit(gyaqVnoXCYANWFulBjxTLKJsIpRctM).query
    gyaqVnoXCYANWFulBjxTLKJsIpRctz=gyaqVnoXCYANWFulBjxTLKJsIpRctw[0:gyaqVnoXCYANWFulBjxTLKJsIpRctw.find('=')]
    gyaqVnoXCYANWFulBjxTLKJsIpRctE=gyaqVnoXCYANWFulBjxTLKJsIpRctw[gyaqVnoXCYANWFulBjxTLKJsIpRctw.find('=')+1:]
    gyaqVnoXCYANWFulBjxTLKJsIpRcwQ={'title':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title_list'][0]['text'],'age':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['age'],'thumbnail':'https://%s'%gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('thumbnail'),'videoid':gyaqVnoXCYANWFulBjxTLKJsIpRctE,'vidtype':gyaqVnoXCYANWFulBjxTLKJsIpRctz}
    gyaqVnoXCYANWFulBjxTLKJsIpRctv.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwQ)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['pagecount'])
   if gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['count']:gyaqVnoXCYANWFulBjxTLKJsIpRctk =gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['count'])
   else:gyaqVnoXCYANWFulBjxTLKJsIpRctk=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.MV_LIMIT*page_int
   gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRcwG>gyaqVnoXCYANWFulBjxTLKJsIpRctk
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[],gyaqVnoXCYANWFulBjxTLKJsIpRckz
  return gyaqVnoXCYANWFulBjxTLKJsIpRctv,gyaqVnoXCYANWFulBjxTLKJsIpRcwr
 def ProgramidToContentid(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,gyaqVnoXCYANWFulBjxTLKJsIpRctO):
  gyaqVnoXCYANWFulBjxTLKJsIpRctU=''
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/vod/programs-contentid/'+gyaqVnoXCYANWFulBjxTLKJsIpRctO
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRctf=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('contentid' in gyaqVnoXCYANWFulBjxTLKJsIpRctf):return gyaqVnoXCYANWFulBjxTLKJsIpRctU 
   gyaqVnoXCYANWFulBjxTLKJsIpRctU=gyaqVnoXCYANWFulBjxTLKJsIpRctf['contentid']
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
  return gyaqVnoXCYANWFulBjxTLKJsIpRctU
 def ContentidToProgramid(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,gyaqVnoXCYANWFulBjxTLKJsIpRctU):
  gyaqVnoXCYANWFulBjxTLKJsIpRctO=''
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/cf/vod/contents/'+gyaqVnoXCYANWFulBjxTLKJsIpRctU
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRctf=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('programid' in gyaqVnoXCYANWFulBjxTLKJsIpRctf):return gyaqVnoXCYANWFulBjxTLKJsIpRctO 
   gyaqVnoXCYANWFulBjxTLKJsIpRctO=gyaqVnoXCYANWFulBjxTLKJsIpRctf['programid']
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
  return gyaqVnoXCYANWFulBjxTLKJsIpRctO
 def GetProgramInfo(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,program_code):
  gyaqVnoXCYANWFulBjxTLKJsIpRctS={}
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/cf/vod/contents/'+program_code
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRctf=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(gyaqVnoXCYANWFulBjxTLKJsIpRctf)
   gyaqVnoXCYANWFulBjxTLKJsIpRctQ=img_fanart=gyaqVnoXCYANWFulBjxTLKJsIpRctP=''
   if gyaqVnoXCYANWFulBjxTLKJsIpRctf.get('programposterimage')!='':gyaqVnoXCYANWFulBjxTLKJsIpRctQ =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.HTTPTAG+gyaqVnoXCYANWFulBjxTLKJsIpRctf.get('programposterimage')
   if gyaqVnoXCYANWFulBjxTLKJsIpRctf.get('programimage') !='':img_fanart =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.HTTPTAG+gyaqVnoXCYANWFulBjxTLKJsIpRctf.get('programimage')
   if gyaqVnoXCYANWFulBjxTLKJsIpRctf.get('programcirlceimage')!='':gyaqVnoXCYANWFulBjxTLKJsIpRctP=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.HTTPTAG+gyaqVnoXCYANWFulBjxTLKJsIpRctf.get('programcirlceimage')
   if 'poster_default' in gyaqVnoXCYANWFulBjxTLKJsIpRctQ:
    gyaqVnoXCYANWFulBjxTLKJsIpRctQ =img_fanart
    gyaqVnoXCYANWFulBjxTLKJsIpRctP=''
   gyaqVnoXCYANWFulBjxTLKJsIpRctS={'imgPoster':gyaqVnoXCYANWFulBjxTLKJsIpRctQ,'imgFanart':img_fanart,'imgClearlogo':gyaqVnoXCYANWFulBjxTLKJsIpRctP}
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
  return gyaqVnoXCYANWFulBjxTLKJsIpRctS
 def Get_Episode_List(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,gyaqVnoXCYANWFulBjxTLKJsIpRctE,gyaqVnoXCYANWFulBjxTLKJsIpRctz,page_int=1,orderby='desc'):
  gyaqVnoXCYANWFulBjxTLKJsIpRctD=[]
  gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRctk=1
  gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRckz
  gyaqVnoXCYANWFulBjxTLKJsIpRctm={}
  if gyaqVnoXCYANWFulBjxTLKJsIpRctz=='contentid':
   gyaqVnoXCYANWFulBjxTLKJsIpRctO=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.ContentidToProgramid(gyaqVnoXCYANWFulBjxTLKJsIpRctE)
   gyaqVnoXCYANWFulBjxTLKJsIpRctm=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetProgramInfo(gyaqVnoXCYANWFulBjxTLKJsIpRctE)
  else:
   gyaqVnoXCYANWFulBjxTLKJsIpRctO=gyaqVnoXCYANWFulBjxTLKJsIpRctE
   gyaqVnoXCYANWFulBjxTLKJsIpRctU=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.ProgramidToContentid(gyaqVnoXCYANWFulBjxTLKJsIpRctE)
   if gyaqVnoXCYANWFulBjxTLKJsIpRctU!='':gyaqVnoXCYANWFulBjxTLKJsIpRctm=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetProgramInfo(gyaqVnoXCYANWFulBjxTLKJsIpRctU)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/vod/programs-contents/'+gyaqVnoXCYANWFulBjxTLKJsIpRctO
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf={}
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['limit'] =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.EP_LIMIT
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['offset']=gyaqVnoXCYANWFulBjxTLKJsIpRcke((page_int-1)*gyaqVnoXCYANWFulBjxTLKJsIpRcMt.EP_LIMIT)
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['orderby']=orderby 
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['list']
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcwO:
    gyaqVnoXCYANWFulBjxTLKJsIpRcti=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('synopsis'))
    gyaqVnoXCYANWFulBjxTLKJsIpRctb=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.HTTPTAG+gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('image')
    gyaqVnoXCYANWFulBjxTLKJsIpRctG=gyaqVnoXCYANWFulBjxTLKJsIpRctr=gyaqVnoXCYANWFulBjxTLKJsIpRczM=''
    if gyaqVnoXCYANWFulBjxTLKJsIpRctm!={}:
     gyaqVnoXCYANWFulBjxTLKJsIpRctG =gyaqVnoXCYANWFulBjxTLKJsIpRctm.get('imgPoster')
     gyaqVnoXCYANWFulBjxTLKJsIpRctr =gyaqVnoXCYANWFulBjxTLKJsIpRctm.get('imgFanart')
     gyaqVnoXCYANWFulBjxTLKJsIpRczM=gyaqVnoXCYANWFulBjxTLKJsIpRctm.get('imgClearlogo')
     gyaqVnoXCYANWFulBjxTLKJsIpRczw={'thumb':gyaqVnoXCYANWFulBjxTLKJsIpRctb,'poster':gyaqVnoXCYANWFulBjxTLKJsIpRctG,'fanart':gyaqVnoXCYANWFulBjxTLKJsIpRctr,'clearlogo':gyaqVnoXCYANWFulBjxTLKJsIpRczM}
    else:
     gyaqVnoXCYANWFulBjxTLKJsIpRczw=gyaqVnoXCYANWFulBjxTLKJsIpRctb
    gyaqVnoXCYANWFulBjxTLKJsIpRcwQ={'programtitle':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('programtitle'),'episodetitle':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('episodetitle'),'episodenumber':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('episodenumber'),'releasedate':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('releasedate'),'releaseweekday':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('releaseweekday'),'programid':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('programid'),'contentid':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('contentid'),'age':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('targetage'),'playtime':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('playtime'),'synopsis':gyaqVnoXCYANWFulBjxTLKJsIpRcti,'episodeactors':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('episodeactors').split(',')if gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('episodeactors')!='' else[],'thumbnail':gyaqVnoXCYANWFulBjxTLKJsIpRczw}
    gyaqVnoXCYANWFulBjxTLKJsIpRctD.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwQ)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRcwz['pagecount'])
   if gyaqVnoXCYANWFulBjxTLKJsIpRcwz['count']:gyaqVnoXCYANWFulBjxTLKJsIpRctk =gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRcwz['count'])
   else:gyaqVnoXCYANWFulBjxTLKJsIpRctk=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.EP_LIMIT*page_int
   gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRcwG>gyaqVnoXCYANWFulBjxTLKJsIpRctk
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[],gyaqVnoXCYANWFulBjxTLKJsIpRckz
  return gyaqVnoXCYANWFulBjxTLKJsIpRctD,gyaqVnoXCYANWFulBjxTLKJsIpRcwr
 def GetEPGList(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,genre):
  gyaqVnoXCYANWFulBjxTLKJsIpRczt={}
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRczE=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Get_Now_Datetime()
   if genre=='all':
    gyaqVnoXCYANWFulBjxTLKJsIpRczk =gyaqVnoXCYANWFulBjxTLKJsIpRczE+datetime.timedelta(hours=3)
   else:
    gyaqVnoXCYANWFulBjxTLKJsIpRczk =gyaqVnoXCYANWFulBjxTLKJsIpRczE+datetime.timedelta(hours=3)
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/live/epgs'
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf={'limit':'100','offset':'0','genre':genre,'startdatetime':gyaqVnoXCYANWFulBjxTLKJsIpRczE.strftime('%Y-%m-%d %H:00'),'enddatetime':gyaqVnoXCYANWFulBjxTLKJsIpRczk.strftime('%Y-%m-%d %H:00')}
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   gyaqVnoXCYANWFulBjxTLKJsIpRczh=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['list']
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRczh:
    gyaqVnoXCYANWFulBjxTLKJsIpRczH=''
    for gyaqVnoXCYANWFulBjxTLKJsIpRcze in gyaqVnoXCYANWFulBjxTLKJsIpRcwS['list']:
     if gyaqVnoXCYANWFulBjxTLKJsIpRczH:gyaqVnoXCYANWFulBjxTLKJsIpRczH+='\n'
     gyaqVnoXCYANWFulBjxTLKJsIpRczH+=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Get_ChangeText(gyaqVnoXCYANWFulBjxTLKJsIpRcze['title'])+'\n'
     gyaqVnoXCYANWFulBjxTLKJsIpRczH+=' [%s ~ %s]'%(gyaqVnoXCYANWFulBjxTLKJsIpRcze['starttime'][-5:],gyaqVnoXCYANWFulBjxTLKJsIpRcze['endtime'][-5:])+'\n'
    gyaqVnoXCYANWFulBjxTLKJsIpRczt[gyaqVnoXCYANWFulBjxTLKJsIpRcwS['channelid']]=gyaqVnoXCYANWFulBjxTLKJsIpRczH
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
  return gyaqVnoXCYANWFulBjxTLKJsIpRczt
 def Get_LiveChannel_List(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,genre,gyaqVnoXCYANWFulBjxTLKJsIpRcwU):
  gyaqVnoXCYANWFulBjxTLKJsIpRcwb=[]
  (gyaqVnoXCYANWFulBjxTLKJsIpRcMr,gyaqVnoXCYANWFulBjxTLKJsIpRcMf)=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Baseapi_Parse(gyaqVnoXCYANWFulBjxTLKJsIpRcwU)
  if gyaqVnoXCYANWFulBjxTLKJsIpRcMr=='':return gyaqVnoXCYANWFulBjxTLKJsIpRcwb
  gyaqVnoXCYANWFulBjxTLKJsIpRczv=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetEPGList(genre)
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf['genre']=genre
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('celllist' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']):return[]
   gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['celllist']
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcwO:
    gyaqVnoXCYANWFulBjxTLKJsIpRctU=gyaqVnoXCYANWFulBjxTLKJsIpRcwS['contentid']
    if gyaqVnoXCYANWFulBjxTLKJsIpRctU in gyaqVnoXCYANWFulBjxTLKJsIpRczv:
     gyaqVnoXCYANWFulBjxTLKJsIpRczU=gyaqVnoXCYANWFulBjxTLKJsIpRczv[gyaqVnoXCYANWFulBjxTLKJsIpRctU]
    else:
     gyaqVnoXCYANWFulBjxTLKJsIpRczU=''
    gyaqVnoXCYANWFulBjxTLKJsIpRcwQ={'studio':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title_list'][0]['text'],'tvshowtitle':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Get_ChangeText(gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title_list'][1]['text']),'channelid':gyaqVnoXCYANWFulBjxTLKJsIpRctU,'age':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['age'],'thumbnail':'https://%s'%gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('thumbnail'),'epg':gyaqVnoXCYANWFulBjxTLKJsIpRczU}
    gyaqVnoXCYANWFulBjxTLKJsIpRcwb.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwQ)
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[]
  return gyaqVnoXCYANWFulBjxTLKJsIpRcwb
 def Get_Search_List(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,search_key,sType,page_int,exclusion21=gyaqVnoXCYANWFulBjxTLKJsIpRckz):
  gyaqVnoXCYANWFulBjxTLKJsIpRczf=[]
  gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRctk=1
  gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRckz
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/cf/search/list.js'
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':gyaqVnoXCYANWFulBjxTLKJsIpRcke((page_int-1)*gyaqVnoXCYANWFulBjxTLKJsIpRcMt.SEARCH_LIMIT),'limit':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.SEARCH_LIMIT,'orderby':'score'}
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRctf=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('celllist' in gyaqVnoXCYANWFulBjxTLKJsIpRctf['cell_toplist']):return gyaqVnoXCYANWFulBjxTLKJsIpRczf,gyaqVnoXCYANWFulBjxTLKJsIpRcwr
   gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRctf['cell_toplist']['celllist']
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcwO:
    gyaqVnoXCYANWFulBjxTLKJsIpRctM =gyaqVnoXCYANWFulBjxTLKJsIpRcwS['event_list'][1]['url']
    gyaqVnoXCYANWFulBjxTLKJsIpRctw=urllib.parse.urlsplit(gyaqVnoXCYANWFulBjxTLKJsIpRctM).query
    gyaqVnoXCYANWFulBjxTLKJsIpRctz=gyaqVnoXCYANWFulBjxTLKJsIpRctw[0:gyaqVnoXCYANWFulBjxTLKJsIpRctw.find('=')]
    gyaqVnoXCYANWFulBjxTLKJsIpRctE=gyaqVnoXCYANWFulBjxTLKJsIpRctw[gyaqVnoXCYANWFulBjxTLKJsIpRctw.find('=')+1:]
    gyaqVnoXCYANWFulBjxTLKJsIpRcwQ={'title':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['title_list'][0]['text'],'age':gyaqVnoXCYANWFulBjxTLKJsIpRcwS['age'],'thumbnail':'https://%s'%gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('thumbnail'),'videoid':gyaqVnoXCYANWFulBjxTLKJsIpRctE,'vidtype':gyaqVnoXCYANWFulBjxTLKJsIpRctz}
    if exclusion21==gyaqVnoXCYANWFulBjxTLKJsIpRckz or gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('age')!='21':
     gyaqVnoXCYANWFulBjxTLKJsIpRczf.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwQ)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwG=gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRctf['cell_toplist']['pagecount'])
   if gyaqVnoXCYANWFulBjxTLKJsIpRctf['cell_toplist']['count']:gyaqVnoXCYANWFulBjxTLKJsIpRctk =gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRctf['cell_toplist']['count'])
   else:gyaqVnoXCYANWFulBjxTLKJsIpRctk=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.LIST_LIMIT
   gyaqVnoXCYANWFulBjxTLKJsIpRcwr=gyaqVnoXCYANWFulBjxTLKJsIpRcwG>gyaqVnoXCYANWFulBjxTLKJsIpRctk
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
  return gyaqVnoXCYANWFulBjxTLKJsIpRczf,gyaqVnoXCYANWFulBjxTLKJsIpRcwr 
 def GetStreamingURL(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,mode,gyaqVnoXCYANWFulBjxTLKJsIpRctU,quality_int,pvrmode='-'):
  gyaqVnoXCYANWFulBjxTLKJsIpRczO=gyaqVnoXCYANWFulBjxTLKJsIpRczb=gyaqVnoXCYANWFulBjxTLKJsIpRczG=streaming_preview=''
  gyaqVnoXCYANWFulBjxTLKJsIpRczS=[]
  gyaqVnoXCYANWFulBjxTLKJsIpRczQ='hls'
  if mode=='LIVE':
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/live/channels/'+gyaqVnoXCYANWFulBjxTLKJsIpRctU
   gyaqVnoXCYANWFulBjxTLKJsIpRczP='live'
  elif mode=='VOD':
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/cf/vod/contents/'+gyaqVnoXCYANWFulBjxTLKJsIpRctU
   gyaqVnoXCYANWFulBjxTLKJsIpRczP='vod'
  elif mode=='MOVIE':
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/cf/movie/contents/'+gyaqVnoXCYANWFulBjxTLKJsIpRctU
   gyaqVnoXCYANWFulBjxTLKJsIpRczP='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    gyaqVnoXCYANWFulBjxTLKJsIpRcMf=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz)
    gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
    gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
    gyaqVnoXCYANWFulBjxTLKJsIpRczD=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['qualities']['list']
    if gyaqVnoXCYANWFulBjxTLKJsIpRczD==gyaqVnoXCYANWFulBjxTLKJsIpRckt:return(gyaqVnoXCYANWFulBjxTLKJsIpRczO,gyaqVnoXCYANWFulBjxTLKJsIpRczb,gyaqVnoXCYANWFulBjxTLKJsIpRczG,streaming_preview)
    for gyaqVnoXCYANWFulBjxTLKJsIpRczm in gyaqVnoXCYANWFulBjxTLKJsIpRczD:
     gyaqVnoXCYANWFulBjxTLKJsIpRczS.append(gyaqVnoXCYANWFulBjxTLKJsIpRckO(gyaqVnoXCYANWFulBjxTLKJsIpRczm.get('id').rstrip('p')))
    if 'type' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz:
     if gyaqVnoXCYANWFulBjxTLKJsIpRcwz['type']=='onair':
      gyaqVnoXCYANWFulBjxTLKJsIpRczP='onairvod'
    if 'drms' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz:
     if gyaqVnoXCYANWFulBjxTLKJsIpRcwz['drms']:
      gyaqVnoXCYANWFulBjxTLKJsIpRczQ='dash'
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return(gyaqVnoXCYANWFulBjxTLKJsIpRczO,gyaqVnoXCYANWFulBjxTLKJsIpRczb,gyaqVnoXCYANWFulBjxTLKJsIpRczG,streaming_preview)
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRczd=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.CheckQuality(quality_int,gyaqVnoXCYANWFulBjxTLKJsIpRczS)
   if mode=='LIVE' and pvrmode!='-':
    gyaqVnoXCYANWFulBjxTLKJsIpRczi='auto'
   else:
    gyaqVnoXCYANWFulBjxTLKJsIpRczi=gyaqVnoXCYANWFulBjxTLKJsIpRcke(gyaqVnoXCYANWFulBjxTLKJsIpRczd)+'p'
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/streaming'
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf={'contentid':gyaqVnoXCYANWFulBjxTLKJsIpRctU,'contenttype':gyaqVnoXCYANWFulBjxTLKJsIpRczP,'action':gyaqVnoXCYANWFulBjxTLKJsIpRczQ,'quality':gyaqVnoXCYANWFulBjxTLKJsIpRczi,'deviceModelId':'Windows 10','guid':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckh))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   gyaqVnoXCYANWFulBjxTLKJsIpRczO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['playurl']
   if gyaqVnoXCYANWFulBjxTLKJsIpRczO==gyaqVnoXCYANWFulBjxTLKJsIpRckt:return(gyaqVnoXCYANWFulBjxTLKJsIpRczO,gyaqVnoXCYANWFulBjxTLKJsIpRczb,gyaqVnoXCYANWFulBjxTLKJsIpRczG,streaming_preview)
   gyaqVnoXCYANWFulBjxTLKJsIpRczb=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['awscookie']
   gyaqVnoXCYANWFulBjxTLKJsIpRczG =gyaqVnoXCYANWFulBjxTLKJsIpRcwz['drm']
   if 'previewmsg' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz['preview']:streaming_preview=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['preview']['previewmsg']
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
  return(gyaqVnoXCYANWFulBjxTLKJsIpRczO,gyaqVnoXCYANWFulBjxTLKJsIpRczb,gyaqVnoXCYANWFulBjxTLKJsIpRczG,streaming_preview) 
 def GetSportsURL(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,gyaqVnoXCYANWFulBjxTLKJsIpRctU,quality_int):
  gyaqVnoXCYANWFulBjxTLKJsIpRczO=gyaqVnoXCYANWFulBjxTLKJsIpRczb=''
  gyaqVnoXCYANWFulBjxTLKJsIpRczS=[]
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/streaming/other'
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf={'contentid':gyaqVnoXCYANWFulBjxTLKJsIpRctU,'contenttype':'live','action':'hls','quality':gyaqVnoXCYANWFulBjxTLKJsIpRcke(quality_int)+'p','deviceModelId':'Windows 10','guid':gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckh))
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   gyaqVnoXCYANWFulBjxTLKJsIpRczO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['playurl']
   if gyaqVnoXCYANWFulBjxTLKJsIpRczO==gyaqVnoXCYANWFulBjxTLKJsIpRckt:return(gyaqVnoXCYANWFulBjxTLKJsIpRczO,gyaqVnoXCYANWFulBjxTLKJsIpRczb)
   gyaqVnoXCYANWFulBjxTLKJsIpRczb=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['awscookie']
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
  return(gyaqVnoXCYANWFulBjxTLKJsIpRczO,gyaqVnoXCYANWFulBjxTLKJsIpRczb) 
 def make_viewdate(gyaqVnoXCYANWFulBjxTLKJsIpRcMt):
  gyaqVnoXCYANWFulBjxTLKJsIpRczr =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.Get_Now_Datetime()
  gyaqVnoXCYANWFulBjxTLKJsIpRcEM =gyaqVnoXCYANWFulBjxTLKJsIpRczr+datetime.timedelta(days=-1)
  gyaqVnoXCYANWFulBjxTLKJsIpRcEw =gyaqVnoXCYANWFulBjxTLKJsIpRczr+datetime.timedelta(days=1)
  gyaqVnoXCYANWFulBjxTLKJsIpRcEt=[gyaqVnoXCYANWFulBjxTLKJsIpRczr.strftime('%Y%m%d'),gyaqVnoXCYANWFulBjxTLKJsIpRcEw.strftime('%Y%m%d'),]
  return gyaqVnoXCYANWFulBjxTLKJsIpRcEt
 def Get_Sports_Gamelist(gyaqVnoXCYANWFulBjxTLKJsIpRcMt):
  gyaqVnoXCYANWFulBjxTLKJsIpRcEz =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.make_viewdate()
  gyaqVnoXCYANWFulBjxTLKJsIpRcEk=[]
  gyaqVnoXCYANWFulBjxTLKJsIpRcEh =[]
  for gyaqVnoXCYANWFulBjxTLKJsIpRcEH in gyaqVnoXCYANWFulBjxTLKJsIpRcEz:
   gyaqVnoXCYANWFulBjxTLKJsIpRcEe=gyaqVnoXCYANWFulBjxTLKJsIpRcEH[:6]
   if gyaqVnoXCYANWFulBjxTLKJsIpRcEe not in gyaqVnoXCYANWFulBjxTLKJsIpRcEk:
    gyaqVnoXCYANWFulBjxTLKJsIpRcEk.append(gyaqVnoXCYANWFulBjxTLKJsIpRcEe)
  try:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf.update(gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz))
   for gyaqVnoXCYANWFulBjxTLKJsIpRcEv in gyaqVnoXCYANWFulBjxTLKJsIpRcEk:
    gyaqVnoXCYANWFulBjxTLKJsIpRcMf['date']=gyaqVnoXCYANWFulBjxTLKJsIpRcEv
    gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
    gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
    gyaqVnoXCYANWFulBjxTLKJsIpRcwO=gyaqVnoXCYANWFulBjxTLKJsIpRcwz['cell_toplist']['celllist']
    for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcwO:
     gyaqVnoXCYANWFulBjxTLKJsIpRcEU=gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('game_date')
     gyaqVnoXCYANWFulBjxTLKJsIpRcEf =gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('svc_id')
     if gyaqVnoXCYANWFulBjxTLKJsIpRcEf=='':continue
     if gyaqVnoXCYANWFulBjxTLKJsIpRcEU in gyaqVnoXCYANWFulBjxTLKJsIpRcEz:
      gyaqVnoXCYANWFulBjxTLKJsIpRcEO=gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('game_status') 
      gyaqVnoXCYANWFulBjxTLKJsIpRcES =gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('title_list')[0].get('text')
      gyaqVnoXCYANWFulBjxTLKJsIpRcEU =gyaqVnoXCYANWFulBjxTLKJsIpRcEU[:4]+'-'+gyaqVnoXCYANWFulBjxTLKJsIpRcEU[4:6]+'-'+gyaqVnoXCYANWFulBjxTLKJsIpRcEU[-2:]
      gyaqVnoXCYANWFulBjxTLKJsIpRcEQ =gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('game_time')
      gyaqVnoXCYANWFulBjxTLKJsIpRcEQ =gyaqVnoXCYANWFulBjxTLKJsIpRcEQ[:2]+':'+gyaqVnoXCYANWFulBjxTLKJsIpRcEQ[-2:]
      gyaqVnoXCYANWFulBjxTLKJsIpRcwQ={'game_date':gyaqVnoXCYANWFulBjxTLKJsIpRcEU,'game_time':gyaqVnoXCYANWFulBjxTLKJsIpRcEQ,'svc_id':gyaqVnoXCYANWFulBjxTLKJsIpRcEf,'away_team':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('away_team').get('team_name'),'home_team':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('home_team').get('team_name'),'game_status':gyaqVnoXCYANWFulBjxTLKJsIpRcEO,'game_place':gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('game_place'),}
      gyaqVnoXCYANWFulBjxTLKJsIpRcEh.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwQ)
  except gyaqVnoXCYANWFulBjxTLKJsIpRckv as exception:
   gyaqVnoXCYANWFulBjxTLKJsIpRckU(exception)
   return[]
  gyaqVnoXCYANWFulBjxTLKJsIpRcEP=[]
  for i in gyaqVnoXCYANWFulBjxTLKJsIpRckH(2):
   for gyaqVnoXCYANWFulBjxTLKJsIpRcwS in gyaqVnoXCYANWFulBjxTLKJsIpRcEh:
    if i==0 and gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('game_status')=='LIVE':
     gyaqVnoXCYANWFulBjxTLKJsIpRcEP.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwS)
    elif i==1 and gyaqVnoXCYANWFulBjxTLKJsIpRcwS.get('game_status')!='LIVE':
     gyaqVnoXCYANWFulBjxTLKJsIpRcEP.append(gyaqVnoXCYANWFulBjxTLKJsIpRcwS)
  return gyaqVnoXCYANWFulBjxTLKJsIpRcEP
 def GetBookmarkInfo(gyaqVnoXCYANWFulBjxTLKJsIpRcMt,gyaqVnoXCYANWFulBjxTLKJsIpRctE,gyaqVnoXCYANWFulBjxTLKJsIpRctz,gyaqVnoXCYANWFulBjxTLKJsIpRczP):
  if gyaqVnoXCYANWFulBjxTLKJsIpRctz=='tvshow':
   if gyaqVnoXCYANWFulBjxTLKJsIpRczP=='contentid':
    gyaqVnoXCYANWFulBjxTLKJsIpRctU=gyaqVnoXCYANWFulBjxTLKJsIpRctE
    gyaqVnoXCYANWFulBjxTLKJsIpRctE =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.ContentidToProgramid(gyaqVnoXCYANWFulBjxTLKJsIpRctU)
   else:
    gyaqVnoXCYANWFulBjxTLKJsIpRctU=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.ProgramidToContentid(gyaqVnoXCYANWFulBjxTLKJsIpRctE)
  else:
   gyaqVnoXCYANWFulBjxTLKJsIpRctU=''
  gyaqVnoXCYANWFulBjxTLKJsIpRcED={'indexinfo':{'ott':'wavve','videoid':gyaqVnoXCYANWFulBjxTLKJsIpRctE,'vidtype':gyaqVnoXCYANWFulBjxTLKJsIpRctz,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':gyaqVnoXCYANWFulBjxTLKJsIpRctz,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if gyaqVnoXCYANWFulBjxTLKJsIpRctz=='tvshow':
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/cf/vod/contents/'+gyaqVnoXCYANWFulBjxTLKJsIpRctU 
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('programtitle' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz):return{}
   gyaqVnoXCYANWFulBjxTLKJsIpRcEm=gyaqVnoXCYANWFulBjxTLKJsIpRcwz
   gyaqVnoXCYANWFulBjxTLKJsIpRcEd=gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('programtitle')
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['title']=gyaqVnoXCYANWFulBjxTLKJsIpRcEd
   if gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('targetage')=='18' or gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('targetage')=='19' or gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('targetage')=='21':
    gyaqVnoXCYANWFulBjxTLKJsIpRcEd +=u' (%s)'%(gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('targetage'))
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['title'] =gyaqVnoXCYANWFulBjxTLKJsIpRcEd
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['mpaa'] =gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('targetage')
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['plot'] =gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('programsynopsis').replace('<br>','\n')
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['studio'] =gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('channelname')
   if gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('firstreleaseyear')!='':gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['year'] =gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('firstreleaseyear')
   if gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('firstreleasedate')!='':gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['premiered']=gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('firstreleasedate')
   if gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('genretext') !='':gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['genre'] =[gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('genretext')]
   gyaqVnoXCYANWFulBjxTLKJsIpRcEi=[]
   for gyaqVnoXCYANWFulBjxTLKJsIpRcEb in gyaqVnoXCYANWFulBjxTLKJsIpRcEm['actors']['list']:gyaqVnoXCYANWFulBjxTLKJsIpRcEi.append(gyaqVnoXCYANWFulBjxTLKJsIpRcEb.get('text'))
   if gyaqVnoXCYANWFulBjxTLKJsIpRckS(gyaqVnoXCYANWFulBjxTLKJsIpRcEi)>0:
    if gyaqVnoXCYANWFulBjxTLKJsIpRcEi[0]!='':gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['cast']=gyaqVnoXCYANWFulBjxTLKJsIpRcEi
   gyaqVnoXCYANWFulBjxTLKJsIpRctG =''
   gyaqVnoXCYANWFulBjxTLKJsIpRctr =''
   gyaqVnoXCYANWFulBjxTLKJsIpRczM=''
   if gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('programposterimage')!='':gyaqVnoXCYANWFulBjxTLKJsIpRctG =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.HTTPTAG+gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('programposterimage')
   if gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('programimage') !='':gyaqVnoXCYANWFulBjxTLKJsIpRctr =gyaqVnoXCYANWFulBjxTLKJsIpRcMt.HTTPTAG+gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('programimage')
   if gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('programcirlceimage')!='':gyaqVnoXCYANWFulBjxTLKJsIpRczM=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.HTTPTAG+gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('programcirlceimage')
   if 'poster_default' in gyaqVnoXCYANWFulBjxTLKJsIpRctG:
    gyaqVnoXCYANWFulBjxTLKJsIpRctG =gyaqVnoXCYANWFulBjxTLKJsIpRctr
    gyaqVnoXCYANWFulBjxTLKJsIpRczM=''
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['thumbnail']['poster']=gyaqVnoXCYANWFulBjxTLKJsIpRctG
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['thumbnail']['thumb']=gyaqVnoXCYANWFulBjxTLKJsIpRctr
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['thumbnail']['clearlogo']=gyaqVnoXCYANWFulBjxTLKJsIpRczM
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['thumbnail']['fanart']=gyaqVnoXCYANWFulBjxTLKJsIpRctr
  else:
   gyaqVnoXCYANWFulBjxTLKJsIpRcMr=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.API_DOMAIN+'/movie/contents/'+gyaqVnoXCYANWFulBjxTLKJsIpRctE 
   gyaqVnoXCYANWFulBjxTLKJsIpRcMf=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.GetDefaultParams(login=gyaqVnoXCYANWFulBjxTLKJsIpRckz)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwt=gyaqVnoXCYANWFulBjxTLKJsIpRcMt.callRequestCookies('Get',gyaqVnoXCYANWFulBjxTLKJsIpRcMr,payload=gyaqVnoXCYANWFulBjxTLKJsIpRckt,params=gyaqVnoXCYANWFulBjxTLKJsIpRcMf,headers=gyaqVnoXCYANWFulBjxTLKJsIpRckt,cookies=gyaqVnoXCYANWFulBjxTLKJsIpRckt)
   gyaqVnoXCYANWFulBjxTLKJsIpRcwz=json.loads(gyaqVnoXCYANWFulBjxTLKJsIpRcwt.text)
   if not('title' in gyaqVnoXCYANWFulBjxTLKJsIpRcwz):return{}
   gyaqVnoXCYANWFulBjxTLKJsIpRcEm=gyaqVnoXCYANWFulBjxTLKJsIpRcwz
   gyaqVnoXCYANWFulBjxTLKJsIpRcEd=gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('title')
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['title']=gyaqVnoXCYANWFulBjxTLKJsIpRcEd
   if gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('targetage')=='18' or gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('targetage')=='19' or gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('targetage')=='21':
    gyaqVnoXCYANWFulBjxTLKJsIpRcEd +=u' (%s)'%(gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('targetage'))
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['title'] =gyaqVnoXCYANWFulBjxTLKJsIpRcEd
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['mpaa'] =gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('targetage')
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['plot'] =gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('synopsis').replace('<br>','\n')
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['duration']=gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('playtime')
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['country']=gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('country')
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['studio'] =gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('cpname')
   if gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('releasedate')!='':
    gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['year'] =gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('releasedate')[:4]
    gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['premiered']=gyaqVnoXCYANWFulBjxTLKJsIpRcEm.get('releasedate')
   gyaqVnoXCYANWFulBjxTLKJsIpRcEi=[]
   for gyaqVnoXCYANWFulBjxTLKJsIpRcEb in gyaqVnoXCYANWFulBjxTLKJsIpRcEm['actors']['list']:gyaqVnoXCYANWFulBjxTLKJsIpRcEi.append(gyaqVnoXCYANWFulBjxTLKJsIpRcEb.get('text'))
   if gyaqVnoXCYANWFulBjxTLKJsIpRckS(gyaqVnoXCYANWFulBjxTLKJsIpRcEi)>0:
    if gyaqVnoXCYANWFulBjxTLKJsIpRcEi[0]!='':gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['cast']=gyaqVnoXCYANWFulBjxTLKJsIpRcEi
   gyaqVnoXCYANWFulBjxTLKJsIpRcEG=[]
   for gyaqVnoXCYANWFulBjxTLKJsIpRcEr in gyaqVnoXCYANWFulBjxTLKJsIpRcEm['directors']['list']:gyaqVnoXCYANWFulBjxTLKJsIpRcEG.append(gyaqVnoXCYANWFulBjxTLKJsIpRcEr.get('text'))
   if gyaqVnoXCYANWFulBjxTLKJsIpRckS(gyaqVnoXCYANWFulBjxTLKJsIpRcEG)>0:
    if gyaqVnoXCYANWFulBjxTLKJsIpRcEG[0]!='':gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['director']=gyaqVnoXCYANWFulBjxTLKJsIpRcEG
   gyaqVnoXCYANWFulBjxTLKJsIpRcwv=[]
   for gyaqVnoXCYANWFulBjxTLKJsIpRckM in gyaqVnoXCYANWFulBjxTLKJsIpRcEm['genre']['list']:gyaqVnoXCYANWFulBjxTLKJsIpRcwv.append(gyaqVnoXCYANWFulBjxTLKJsIpRckM.get('text'))
   if gyaqVnoXCYANWFulBjxTLKJsIpRckS(gyaqVnoXCYANWFulBjxTLKJsIpRcwv)>0:
    if gyaqVnoXCYANWFulBjxTLKJsIpRcwv[0]!='':gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['infoLabels']['genre']=gyaqVnoXCYANWFulBjxTLKJsIpRcwv
   gyaqVnoXCYANWFulBjxTLKJsIpRctG ='https://%s'%gyaqVnoXCYANWFulBjxTLKJsIpRcEm['image']
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['thumbnail']['poster'] =gyaqVnoXCYANWFulBjxTLKJsIpRctG
   gyaqVnoXCYANWFulBjxTLKJsIpRcED['saveinfo']['thumbnail']['thumb'] =gyaqVnoXCYANWFulBjxTLKJsIpRctG
  return gyaqVnoXCYANWFulBjxTLKJsIpRcED
# Created by pyminifier (https://github.com/liftoff/pyminifier)
