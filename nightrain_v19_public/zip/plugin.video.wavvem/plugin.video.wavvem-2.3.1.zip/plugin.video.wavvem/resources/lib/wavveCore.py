__author__="NightRain"
mbBsjgklWepwUfGdaMJYvtyFiPruIC=object
mbBsjgklWepwUfGdaMJYvtyFiPruIR=None
mbBsjgklWepwUfGdaMJYvtyFiPruIQ=False
mbBsjgklWepwUfGdaMJYvtyFiPruIE=open
mbBsjgklWepwUfGdaMJYvtyFiPruIT=True
mbBsjgklWepwUfGdaMJYvtyFiPruIx=range
mbBsjgklWepwUfGdaMJYvtyFiPruIo=str
mbBsjgklWepwUfGdaMJYvtyFiPruIS=Exception
mbBsjgklWepwUfGdaMJYvtyFiPruIz=print
mbBsjgklWepwUfGdaMJYvtyFiPruIX=dict
mbBsjgklWepwUfGdaMJYvtyFiPruIL=int
mbBsjgklWepwUfGdaMJYvtyFiPruID=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class mbBsjgklWepwUfGdaMJYvtyFiPruCR(mbBsjgklWepwUfGdaMJYvtyFiPruIC):
 def __init__(mbBsjgklWepwUfGdaMJYvtyFiPruCQ):
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN='https://apis.wavve.com'
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV ={}
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Init_WV_Total()
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.DEVICE ='pc'
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.DRM ='wm'
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.PARTNER ='pooq'
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.POOQZONE ='none'
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.REGION ='kor'
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.TARGETAGE ='all'
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.HTTPTAG ='https://'
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.LIST_LIMIT=30 
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.EP_LIMIT =30 
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.MV_LIMIT =24 
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.SEARCH_LIMIT=20 
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36'
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.DEFAULT_HEADER={'user-agent':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.USER_AGENT}
 def Init_WV_Total(mbBsjgklWepwUfGdaMJYvtyFiPruCQ):
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV={'account':{},'cookies':{},}
 def callRequestCookies(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,jobtype,mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruIR,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR,redirects=mbBsjgklWepwUfGdaMJYvtyFiPruIQ):
  mbBsjgklWepwUfGdaMJYvtyFiPruCE=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.DEFAULT_HEADER
  if headers:mbBsjgklWepwUfGdaMJYvtyFiPruCE.update(headers)
  if jobtype=='Get':
   mbBsjgklWepwUfGdaMJYvtyFiPruCT=requests.get(mbBsjgklWepwUfGdaMJYvtyFiPruCN,params=params,headers=mbBsjgklWepwUfGdaMJYvtyFiPruCE,cookies=cookies,allow_redirects=redirects)
  else:
   mbBsjgklWepwUfGdaMJYvtyFiPruCT=requests.post(mbBsjgklWepwUfGdaMJYvtyFiPruCN,data=payload,params=params,headers=mbBsjgklWepwUfGdaMJYvtyFiPruCE,cookies=cookies,allow_redirects=redirects)
  return mbBsjgklWepwUfGdaMJYvtyFiPruCT
 def JsonFile_Save(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,filename,mbBsjgklWepwUfGdaMJYvtyFiPruCI):
  if filename=='':return mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  try:
   fp=mbBsjgklWepwUfGdaMJYvtyFiPruIE(filename,'w',-1,'utf-8')
   json.dump(mbBsjgklWepwUfGdaMJYvtyFiPruCI,fp,indent=4,ensure_ascii=mbBsjgklWepwUfGdaMJYvtyFiPruIQ)
   fp.close()
  except:
   return mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  return mbBsjgklWepwUfGdaMJYvtyFiPruIT
 def JsonFile_Load(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,filename):
  if filename=='':return{}
  try:
   fp=mbBsjgklWepwUfGdaMJYvtyFiPruIE(filename,'r',-1,'utf-8')
   mbBsjgklWepwUfGdaMJYvtyFiPruCo=json.load(fp)
   fp.close()
  except:
   return{}
  return mbBsjgklWepwUfGdaMJYvtyFiPruCo
 def Save_session_acount(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mbBsjgklWepwUfGdaMJYvtyFiPruCS,mbBsjgklWepwUfGdaMJYvtyFiPruCz,mbBsjgklWepwUfGdaMJYvtyFiPruCX):
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV['account']['wvid']=base64.standard_b64encode(mbBsjgklWepwUfGdaMJYvtyFiPruCS.encode()).decode('utf-8')
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV['account']['wvpw']=base64.standard_b64encode(mbBsjgklWepwUfGdaMJYvtyFiPruCz.encode()).decode('utf-8')
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV['account']['wvpf']=mbBsjgklWepwUfGdaMJYvtyFiPruCX 
 def Load_session_acount(mbBsjgklWepwUfGdaMJYvtyFiPruCQ):
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCS=base64.standard_b64decode(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV['account']['wvid']).decode('utf-8')
   mbBsjgklWepwUfGdaMJYvtyFiPruCz=base64.standard_b64decode(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV['account']['wvpw']).decode('utf-8')
   mbBsjgklWepwUfGdaMJYvtyFiPruCX=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV['account']['wvpf']
  except:
   return '','',0
  return mbBsjgklWepwUfGdaMJYvtyFiPruCS,mbBsjgklWepwUfGdaMJYvtyFiPruCz,mbBsjgklWepwUfGdaMJYvtyFiPruCX
 def GetDefaultParams(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,login=mbBsjgklWepwUfGdaMJYvtyFiPruIT):
  mbBsjgklWepwUfGdaMJYvtyFiPruCL={'apikey':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.APIKEY,'credential':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV['cookies']['credential']if login else 'none','device':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.DEVICE,'drm':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.DRM,'partner':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.PARTNER,'pooqzone':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.POOQZONE,'region':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.REGION,'targetage':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.TARGETAGE}
  return mbBsjgklWepwUfGdaMJYvtyFiPruCL
 def GetGUID(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   mbBsjgklWepwUfGdaMJYvtyFiPruCD=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   mbBsjgklWepwUfGdaMJYvtyFiPruCq=GenerateRandomString(5)
   mbBsjgklWepwUfGdaMJYvtyFiPruCc=mbBsjgklWepwUfGdaMJYvtyFiPruCq+media+mbBsjgklWepwUfGdaMJYvtyFiPruCD
   return mbBsjgklWepwUfGdaMJYvtyFiPruCc
  def GenerateRandomString(num):
   from random import randint
   mbBsjgklWepwUfGdaMJYvtyFiPruCO=""
   for i in mbBsjgklWepwUfGdaMJYvtyFiPruIx(0,num):
    s=mbBsjgklWepwUfGdaMJYvtyFiPruIo(randint(1,5))
    mbBsjgklWepwUfGdaMJYvtyFiPruCO+=s
   return mbBsjgklWepwUfGdaMJYvtyFiPruCO
  mbBsjgklWepwUfGdaMJYvtyFiPruCc=GenerateID(guid_str)
  mbBsjgklWepwUfGdaMJYvtyFiPruCh=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetHash(mbBsjgklWepwUfGdaMJYvtyFiPruCc)
  if guidType==2:
   mbBsjgklWepwUfGdaMJYvtyFiPruCh='%s-%s-%s-%s-%s'%(mbBsjgklWepwUfGdaMJYvtyFiPruCh[:8],mbBsjgklWepwUfGdaMJYvtyFiPruCh[8:12],mbBsjgklWepwUfGdaMJYvtyFiPruCh[12:16],mbBsjgklWepwUfGdaMJYvtyFiPruCh[16:20],mbBsjgklWepwUfGdaMJYvtyFiPruCh[20:])
  return mbBsjgklWepwUfGdaMJYvtyFiPruCh
 def GetHash(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return mbBsjgklWepwUfGdaMJYvtyFiPruIo(m.hexdigest())
 def CheckQuality(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,sel_qt,qt_list):
  mbBsjgklWepwUfGdaMJYvtyFiPruCV=0
  for mbBsjgklWepwUfGdaMJYvtyFiPruCH in qt_list:
   if sel_qt>=mbBsjgklWepwUfGdaMJYvtyFiPruCH:return mbBsjgklWepwUfGdaMJYvtyFiPruCH
   mbBsjgklWepwUfGdaMJYvtyFiPruCV=mbBsjgklWepwUfGdaMJYvtyFiPruCH
  return mbBsjgklWepwUfGdaMJYvtyFiPruCV
 def Get_Now_Datetime(mbBsjgklWepwUfGdaMJYvtyFiPruCQ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,in_text):
  mbBsjgklWepwUfGdaMJYvtyFiPruCK=in_text.replace('&lt;','<').replace('&gt;','>')
  mbBsjgklWepwUfGdaMJYvtyFiPruCK=mbBsjgklWepwUfGdaMJYvtyFiPruCK.replace('$O$','')
  mbBsjgklWepwUfGdaMJYvtyFiPruCK=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',mbBsjgklWepwUfGdaMJYvtyFiPruCK)
  mbBsjgklWepwUfGdaMJYvtyFiPruCK=mbBsjgklWepwUfGdaMJYvtyFiPruCK.lstrip('#')
  return mbBsjgklWepwUfGdaMJYvtyFiPruCK
 def GetCredential(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,user_id,user_pw,user_pf):
  mbBsjgklWepwUfGdaMJYvtyFiPruCn=mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+ '/login'
   mbBsjgklWepwUfGdaMJYvtyFiPruCL=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ)
   mbBsjgklWepwUfGdaMJYvtyFiPruRC={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Post',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruRC,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV['cookies']['credential']=mbBsjgklWepwUfGdaMJYvtyFiPruRE['credential']
   if user_pf!=0:
    mbBsjgklWepwUfGdaMJYvtyFiPruRC={'id':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV['cookies']['credential'],'password':'','profile':mbBsjgklWepwUfGdaMJYvtyFiPruIo(user_pf),'pushid':'','type':'credential'}
    mbBsjgklWepwUfGdaMJYvtyFiPruCL =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIT) 
    mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Post',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruRC,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
    mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
    mbBsjgklWepwUfGdaMJYvtyFiPruCQ.WV['cookies']['credential']=mbBsjgklWepwUfGdaMJYvtyFiPruRE['credential']
   mbBsjgklWepwUfGdaMJYvtyFiPruCn=mbBsjgklWepwUfGdaMJYvtyFiPruIT
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Init_WV_Total()
  return mbBsjgklWepwUfGdaMJYvtyFiPruCn
 def GetIssue(mbBsjgklWepwUfGdaMJYvtyFiPruCQ):
  mbBsjgklWepwUfGdaMJYvtyFiPruRT=mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/guid/issue'
   mbBsjgklWepwUfGdaMJYvtyFiPruCL=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams()
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   mbBsjgklWepwUfGdaMJYvtyFiPruRI=mbBsjgklWepwUfGdaMJYvtyFiPruRE['guid']
   mbBsjgklWepwUfGdaMJYvtyFiPruRx=mbBsjgklWepwUfGdaMJYvtyFiPruRE['guidtimestamp']
   if mbBsjgklWepwUfGdaMJYvtyFiPruRI:mbBsjgklWepwUfGdaMJYvtyFiPruRT=mbBsjgklWepwUfGdaMJYvtyFiPruIT
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   mbBsjgklWepwUfGdaMJYvtyFiPruRI='none'
   mbBsjgklWepwUfGdaMJYvtyFiPruRx='none' 
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.guid=mbBsjgklWepwUfGdaMJYvtyFiPruRI
  mbBsjgklWepwUfGdaMJYvtyFiPruCQ.guidtimestamp=mbBsjgklWepwUfGdaMJYvtyFiPruRx
  return mbBsjgklWepwUfGdaMJYvtyFiPruRT
 def Baseapi_Parse(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mbBsjgklWepwUfGdaMJYvtyFiPruRX):
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruRo =urllib.parse.urlsplit(mbBsjgklWepwUfGdaMJYvtyFiPruRX)
   if mbBsjgklWepwUfGdaMJYvtyFiPruRo.netloc=='':
    mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.HTTPTAG+mbBsjgklWepwUfGdaMJYvtyFiPruRo.netloc+mbBsjgklWepwUfGdaMJYvtyFiPruRo.path
   else:
    mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruRo.scheme+'://'+mbBsjgklWepwUfGdaMJYvtyFiPruRo.netloc+mbBsjgklWepwUfGdaMJYvtyFiPruRo.path
   mbBsjgklWepwUfGdaMJYvtyFiPruCL=mbBsjgklWepwUfGdaMJYvtyFiPruIX(urllib.parse.parse_qsl(mbBsjgklWepwUfGdaMJYvtyFiPruRo.query))
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return '',{}
  return mbBsjgklWepwUfGdaMJYvtyFiPruCN,mbBsjgklWepwUfGdaMJYvtyFiPruCL
 def GetSupermultiUrl(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,sCode,sIndex='0'):
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/cf/supermultisections/'+sCode
   mbBsjgklWepwUfGdaMJYvtyFiPruCL=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ)
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   mbBsjgklWepwUfGdaMJYvtyFiPruRS=mbBsjgklWepwUfGdaMJYvtyFiPruRE['multisectionlist'][mbBsjgklWepwUfGdaMJYvtyFiPruIL(sIndex)]['eventlist'][1]['url']
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return ''
  return mbBsjgklWepwUfGdaMJYvtyFiPruRS
 def Get_LiveCatagory_List(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,sCode,sIndex='0'):
  mbBsjgklWepwUfGdaMJYvtyFiPruRz=[]
  mbBsjgklWepwUfGdaMJYvtyFiPruRX =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetSupermultiUrl(sCode,sIndex)
  (mbBsjgklWepwUfGdaMJYvtyFiPruCN,mbBsjgklWepwUfGdaMJYvtyFiPruCL)=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Baseapi_Parse(mbBsjgklWepwUfGdaMJYvtyFiPruRX)
  if mbBsjgklWepwUfGdaMJYvtyFiPruCN=='':return mbBsjgklWepwUfGdaMJYvtyFiPruRz,''
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('filter_item_list' in mbBsjgklWepwUfGdaMJYvtyFiPruRE['filter']['filterlist'][0]):return[],''
   mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruRE['filter']['filterlist'][0]['filter_item_list']
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruRD:
    mbBsjgklWepwUfGdaMJYvtyFiPruRc={'title':mbBsjgklWepwUfGdaMJYvtyFiPruRq['title'],'genre':mbBsjgklWepwUfGdaMJYvtyFiPruRq['api_parameters'][mbBsjgklWepwUfGdaMJYvtyFiPruRq['api_parameters'].index('=')+1:]}
    mbBsjgklWepwUfGdaMJYvtyFiPruRz.append(mbBsjgklWepwUfGdaMJYvtyFiPruRc)
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[],''
  return mbBsjgklWepwUfGdaMJYvtyFiPruRz,mbBsjgklWepwUfGdaMJYvtyFiPruRX
 def Get_MainCatagory_List(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,sCode,sIndex='0'):
  mbBsjgklWepwUfGdaMJYvtyFiPruRz=[]
  mbBsjgklWepwUfGdaMJYvtyFiPruRX =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetSupermultiUrl(sCode,sIndex)
  (mbBsjgklWepwUfGdaMJYvtyFiPruCN,mbBsjgklWepwUfGdaMJYvtyFiPruCL)=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Baseapi_Parse(mbBsjgklWepwUfGdaMJYvtyFiPruRX)
  if mbBsjgklWepwUfGdaMJYvtyFiPruCN=='':return mbBsjgklWepwUfGdaMJYvtyFiPruRz
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('celllist' in mbBsjgklWepwUfGdaMJYvtyFiPruRE['band']):return[]
   mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruRE['band']['celllist']
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruRD:
    mbBsjgklWepwUfGdaMJYvtyFiPruRO =mbBsjgklWepwUfGdaMJYvtyFiPruRq['event_list'][1]['url']
    (mbBsjgklWepwUfGdaMJYvtyFiPruRh,mbBsjgklWepwUfGdaMJYvtyFiPruRV)=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Baseapi_Parse(mbBsjgklWepwUfGdaMJYvtyFiPruRO)
    mbBsjgklWepwUfGdaMJYvtyFiPruRc={'title':mbBsjgklWepwUfGdaMJYvtyFiPruRq['title_list'][0]['text'],'suburl':mbBsjgklWepwUfGdaMJYvtyFiPruRh,'subapi':mbBsjgklWepwUfGdaMJYvtyFiPruRV.get('api'),'subtype':'catagory' if mbBsjgklWepwUfGdaMJYvtyFiPruRV else 'supersection'}
    mbBsjgklWepwUfGdaMJYvtyFiPruRz.append(mbBsjgklWepwUfGdaMJYvtyFiPruRc)
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[]
  return mbBsjgklWepwUfGdaMJYvtyFiPruRz
 def Get_SuperMultiSection_List(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,subapi_text):
  mbBsjgklWepwUfGdaMJYvtyFiPruRz=[]
  mbBsjgklWepwUfGdaMJYvtyFiPruCL={}
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruRo =urllib.parse.urlsplit(subapi_text)
   if mbBsjgklWepwUfGdaMJYvtyFiPruRo.path.find('apis.wavve.com')>=0: 
    mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.HTTPTAG+mbBsjgklWepwUfGdaMJYvtyFiPruRo.path 
    mbBsjgklWepwUfGdaMJYvtyFiPruCL=mbBsjgklWepwUfGdaMJYvtyFiPruIX(urllib.parse.parse_qsl(mbBsjgklWepwUfGdaMJYvtyFiPruRo.query))
   else:
    mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/cf'+mbBsjgklWepwUfGdaMJYvtyFiPruRo.path 
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCN.replace('supermultisection/','supermultisections/')
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[]
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruIR,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('multisectionlist' in mbBsjgklWepwUfGdaMJYvtyFiPruRE):return[]
   mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruRE['multisectionlist']
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruRD:
    mbBsjgklWepwUfGdaMJYvtyFiPruRH=mbBsjgklWepwUfGdaMJYvtyFiPruRq['title']
    if mbBsjgklWepwUfGdaMJYvtyFiPruID(mbBsjgklWepwUfGdaMJYvtyFiPruRH)==0:continue
    if mbBsjgklWepwUfGdaMJYvtyFiPruRH=='minor':continue
    if re.search(u'베너',mbBsjgklWepwUfGdaMJYvtyFiPruRH):continue
    if re.search(u'배너',mbBsjgklWepwUfGdaMJYvtyFiPruRH):continue 
    if mbBsjgklWepwUfGdaMJYvtyFiPruRq['force_refresh']=='y':continue
    if mbBsjgklWepwUfGdaMJYvtyFiPruID(mbBsjgklWepwUfGdaMJYvtyFiPruRq['eventlist'])>=3:
     mbBsjgklWepwUfGdaMJYvtyFiPruRV =mbBsjgklWepwUfGdaMJYvtyFiPruRq['eventlist'][2]['url']
    else:
     mbBsjgklWepwUfGdaMJYvtyFiPruRV =mbBsjgklWepwUfGdaMJYvtyFiPruRq['eventlist'][1]['url']
    mbBsjgklWepwUfGdaMJYvtyFiPruRA=mbBsjgklWepwUfGdaMJYvtyFiPruRq['cell_type']
    if mbBsjgklWepwUfGdaMJYvtyFiPruRA=='band_2':
     if mbBsjgklWepwUfGdaMJYvtyFiPruRV.find('channellist=')>=0:
      mbBsjgklWepwUfGdaMJYvtyFiPruRA='band_live'
    mbBsjgklWepwUfGdaMJYvtyFiPruRc={'title':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Get_ChangeText(mbBsjgklWepwUfGdaMJYvtyFiPruRH),'subapi':mbBsjgklWepwUfGdaMJYvtyFiPruRV,'cell_type':mbBsjgklWepwUfGdaMJYvtyFiPruRA}
    mbBsjgklWepwUfGdaMJYvtyFiPruRz.append(mbBsjgklWepwUfGdaMJYvtyFiPruRc)
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[]
  return mbBsjgklWepwUfGdaMJYvtyFiPruRz
 def Get_BandLiveSection_List(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mbBsjgklWepwUfGdaMJYvtyFiPruRX,page_int=1):
  mbBsjgklWepwUfGdaMJYvtyFiPruRK=[]
  mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruQI=1
  mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  try:
   (mbBsjgklWepwUfGdaMJYvtyFiPruCN,mbBsjgklWepwUfGdaMJYvtyFiPruCL)=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Baseapi_Parse(mbBsjgklWepwUfGdaMJYvtyFiPruRX)
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[],mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['limit']=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.LIST_LIMIT
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['offset']=mbBsjgklWepwUfGdaMJYvtyFiPruIo((page_int-1)*mbBsjgklWepwUfGdaMJYvtyFiPruCQ.LIST_LIMIT)
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('celllist' in mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']):return[],mbBsjgklWepwUfGdaMJYvtyFiPruIQ
   mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['celllist']
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruRD:
    mbBsjgklWepwUfGdaMJYvtyFiPruQC =mbBsjgklWepwUfGdaMJYvtyFiPruRq['event_list'][1]['url']
    mbBsjgklWepwUfGdaMJYvtyFiPruQR=urllib.parse.urlsplit(mbBsjgklWepwUfGdaMJYvtyFiPruQC).query
    mbBsjgklWepwUfGdaMJYvtyFiPruQR=mbBsjgklWepwUfGdaMJYvtyFiPruIX(urllib.parse.parse_qsl(mbBsjgklWepwUfGdaMJYvtyFiPruQR))
    mbBsjgklWepwUfGdaMJYvtyFiPruQE='channelid'
    mbBsjgklWepwUfGdaMJYvtyFiPruQT=mbBsjgklWepwUfGdaMJYvtyFiPruQR[mbBsjgklWepwUfGdaMJYvtyFiPruQE]
    mbBsjgklWepwUfGdaMJYvtyFiPruRc={'studio':mbBsjgklWepwUfGdaMJYvtyFiPruRq['title_list'][0]['text'],'tvshowtitle':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Get_ChangeText(mbBsjgklWepwUfGdaMJYvtyFiPruRq['title_list'][1]['text']),'channelid':mbBsjgklWepwUfGdaMJYvtyFiPruQT,'age':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('age'),'thumbnail':'https://%s'%mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('thumbnail')}
    mbBsjgklWepwUfGdaMJYvtyFiPruRK.append(mbBsjgklWepwUfGdaMJYvtyFiPruRc)
   mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['pagecount'])
   if mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['count']:mbBsjgklWepwUfGdaMJYvtyFiPruQI =mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['count'])
   else:mbBsjgklWepwUfGdaMJYvtyFiPruQI=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.LIST_LIMIT*page_int
   mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruRn>mbBsjgklWepwUfGdaMJYvtyFiPruQI
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[],mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  return mbBsjgklWepwUfGdaMJYvtyFiPruRK,mbBsjgklWepwUfGdaMJYvtyFiPruRN
 def Get_Band2Section_List(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mbBsjgklWepwUfGdaMJYvtyFiPruRX,page_int=1):
  mbBsjgklWepwUfGdaMJYvtyFiPruQx=[]
  mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruQI=1
  mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  try:
   (mbBsjgklWepwUfGdaMJYvtyFiPruCN,mbBsjgklWepwUfGdaMJYvtyFiPruCL)=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Baseapi_Parse(mbBsjgklWepwUfGdaMJYvtyFiPruRX)
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[],mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['came'] ='BandView'
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['limit']=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.LIST_LIMIT
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['offset']=mbBsjgklWepwUfGdaMJYvtyFiPruIo((page_int-1)*mbBsjgklWepwUfGdaMJYvtyFiPruCQ.LIST_LIMIT)
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('celllist' in mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']):return[],mbBsjgklWepwUfGdaMJYvtyFiPruIQ
   mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['celllist']
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruRD:
    mbBsjgklWepwUfGdaMJYvtyFiPruQC =mbBsjgklWepwUfGdaMJYvtyFiPruRq['event_list'][1]['url']
    mbBsjgklWepwUfGdaMJYvtyFiPruQR=urllib.parse.urlsplit(mbBsjgklWepwUfGdaMJYvtyFiPruQC).query
    mbBsjgklWepwUfGdaMJYvtyFiPruQR=mbBsjgklWepwUfGdaMJYvtyFiPruIX(urllib.parse.parse_qsl(mbBsjgklWepwUfGdaMJYvtyFiPruQR))
    mbBsjgklWepwUfGdaMJYvtyFiPruQE='contentid'
    mbBsjgklWepwUfGdaMJYvtyFiPruQT=mbBsjgklWepwUfGdaMJYvtyFiPruQR[mbBsjgklWepwUfGdaMJYvtyFiPruQE]
    mbBsjgklWepwUfGdaMJYvtyFiPruRc={'programtitle':mbBsjgklWepwUfGdaMJYvtyFiPruRq['title_list'][0]['text'],'episodetitle':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Get_ChangeText(mbBsjgklWepwUfGdaMJYvtyFiPruRq['title_list'][1]['text']),'age':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('age'),'thumbnail':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.HTTPTAG+mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('thumbnail'),'vidtype':mbBsjgklWepwUfGdaMJYvtyFiPruQE,'videoid':mbBsjgklWepwUfGdaMJYvtyFiPruQT}
    mbBsjgklWepwUfGdaMJYvtyFiPruQx.append(mbBsjgklWepwUfGdaMJYvtyFiPruRc)
   mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['pagecount'])
   if mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['count']:mbBsjgklWepwUfGdaMJYvtyFiPruQI =mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['count'])
   else:mbBsjgklWepwUfGdaMJYvtyFiPruQI=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.LIST_LIMIT*page_int
   mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruRn>mbBsjgklWepwUfGdaMJYvtyFiPruQI
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[],mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  return mbBsjgklWepwUfGdaMJYvtyFiPruQx,mbBsjgklWepwUfGdaMJYvtyFiPruRN
 def Get_Program_List(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mbBsjgklWepwUfGdaMJYvtyFiPruRX,page_int=1,orderby='-'):
  mbBsjgklWepwUfGdaMJYvtyFiPruQo=[]
  mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruQI=1
  mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  (mbBsjgklWepwUfGdaMJYvtyFiPruCN,mbBsjgklWepwUfGdaMJYvtyFiPruCL)=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Baseapi_Parse(mbBsjgklWepwUfGdaMJYvtyFiPruRX)
  if mbBsjgklWepwUfGdaMJYvtyFiPruCN=='':return mbBsjgklWepwUfGdaMJYvtyFiPruQo,mbBsjgklWepwUfGdaMJYvtyFiPruRN
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['limit'] =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.LIST_LIMIT
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['offset']=mbBsjgklWepwUfGdaMJYvtyFiPruIo((page_int-1)*mbBsjgklWepwUfGdaMJYvtyFiPruCQ.LIST_LIMIT)
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['page'] =mbBsjgklWepwUfGdaMJYvtyFiPruIo(page_int)
   if mbBsjgklWepwUfGdaMJYvtyFiPruCL.get('orderby')!='' and mbBsjgklWepwUfGdaMJYvtyFiPruCL.get('orderby')!='regdatefirst' and orderby!='-':
    mbBsjgklWepwUfGdaMJYvtyFiPruCL['orderby']=orderby 
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if mbBsjgklWepwUfGdaMJYvtyFiPruRX.find('instantplay')>=0:
    if not('celllist' in mbBsjgklWepwUfGdaMJYvtyFiPruRE['band']):return mbBsjgklWepwUfGdaMJYvtyFiPruQo,mbBsjgklWepwUfGdaMJYvtyFiPruRN
    mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruRE['band']['celllist']
   else:
    if not('celllist' in mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']):return mbBsjgklWepwUfGdaMJYvtyFiPruQo,mbBsjgklWepwUfGdaMJYvtyFiPruRN
    mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['celllist']
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruRD:
    for mbBsjgklWepwUfGdaMJYvtyFiPruQS in mbBsjgklWepwUfGdaMJYvtyFiPruRq['event_list']:
     if mbBsjgklWepwUfGdaMJYvtyFiPruQS.get('type')=='on-navigation':
      mbBsjgklWepwUfGdaMJYvtyFiPruQC =mbBsjgklWepwUfGdaMJYvtyFiPruQS['url']
    mbBsjgklWepwUfGdaMJYvtyFiPruQR=urllib.parse.urlsplit(mbBsjgklWepwUfGdaMJYvtyFiPruQC).query
    mbBsjgklWepwUfGdaMJYvtyFiPruQE=mbBsjgklWepwUfGdaMJYvtyFiPruQR[0:mbBsjgklWepwUfGdaMJYvtyFiPruQR.find('=')]
    mbBsjgklWepwUfGdaMJYvtyFiPruQT=mbBsjgklWepwUfGdaMJYvtyFiPruQR[mbBsjgklWepwUfGdaMJYvtyFiPruQR.find('=')+1:]
    mbBsjgklWepwUfGdaMJYvtyFiPruRc={'title':mbBsjgklWepwUfGdaMJYvtyFiPruRq['title_list'][0]['text'],'age':mbBsjgklWepwUfGdaMJYvtyFiPruRq['age'],'thumbnail':'https://%s'%mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('thumbnail'),'videoid':mbBsjgklWepwUfGdaMJYvtyFiPruQT,'vidtype':mbBsjgklWepwUfGdaMJYvtyFiPruQE}
    mbBsjgklWepwUfGdaMJYvtyFiPruQo.append(mbBsjgklWepwUfGdaMJYvtyFiPruRc)
   if mbBsjgklWepwUfGdaMJYvtyFiPruRX.find('instantplay')<0:
    mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['pagecount'])
    if mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['count']:mbBsjgklWepwUfGdaMJYvtyFiPruQI =mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['count'])
    else:mbBsjgklWepwUfGdaMJYvtyFiPruQI=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.LIST_LIMIT*page_int
    mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruRn>mbBsjgklWepwUfGdaMJYvtyFiPruQI
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[],mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  return mbBsjgklWepwUfGdaMJYvtyFiPruQo,mbBsjgklWepwUfGdaMJYvtyFiPruRN
 def Get_Movie_List(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mbBsjgklWepwUfGdaMJYvtyFiPruRX,page_int=1):
  mbBsjgklWepwUfGdaMJYvtyFiPruQz=[]
  mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruQI=1
  mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  (mbBsjgklWepwUfGdaMJYvtyFiPruCN,mbBsjgklWepwUfGdaMJYvtyFiPruCL)=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Baseapi_Parse(mbBsjgklWepwUfGdaMJYvtyFiPruRX)
  if mbBsjgklWepwUfGdaMJYvtyFiPruCN=='':return mbBsjgklWepwUfGdaMJYvtyFiPruQz,mbBsjgklWepwUfGdaMJYvtyFiPruRN
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['limit']=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.MV_LIMIT
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['offset']=mbBsjgklWepwUfGdaMJYvtyFiPruIo((page_int-1)*mbBsjgklWepwUfGdaMJYvtyFiPruCQ.MV_LIMIT)
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('celllist' in mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']):return mbBsjgklWepwUfGdaMJYvtyFiPruQz,mbBsjgklWepwUfGdaMJYvtyFiPruRN
   mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['celllist']
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruRD:
    mbBsjgklWepwUfGdaMJYvtyFiPruQC =mbBsjgklWepwUfGdaMJYvtyFiPruRq['event_list'][1]['url']
    mbBsjgklWepwUfGdaMJYvtyFiPruQR=urllib.parse.urlsplit(mbBsjgklWepwUfGdaMJYvtyFiPruQC).query
    mbBsjgklWepwUfGdaMJYvtyFiPruQE=mbBsjgklWepwUfGdaMJYvtyFiPruQR[0:mbBsjgklWepwUfGdaMJYvtyFiPruQR.find('=')]
    mbBsjgklWepwUfGdaMJYvtyFiPruQT=mbBsjgklWepwUfGdaMJYvtyFiPruQR[mbBsjgklWepwUfGdaMJYvtyFiPruQR.find('=')+1:]
    mbBsjgklWepwUfGdaMJYvtyFiPruRc={'title':mbBsjgklWepwUfGdaMJYvtyFiPruRq['title_list'][0]['text'],'age':mbBsjgklWepwUfGdaMJYvtyFiPruRq['age'],'thumbnail':'https://%s'%mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('thumbnail'),'videoid':mbBsjgklWepwUfGdaMJYvtyFiPruQT,'vidtype':mbBsjgklWepwUfGdaMJYvtyFiPruQE}
    mbBsjgklWepwUfGdaMJYvtyFiPruQz.append(mbBsjgklWepwUfGdaMJYvtyFiPruRc)
   mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['pagecount'])
   if mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['count']:mbBsjgklWepwUfGdaMJYvtyFiPruQI =mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['count'])
   else:mbBsjgklWepwUfGdaMJYvtyFiPruQI=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.MV_LIMIT*page_int
   mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruRn>mbBsjgklWepwUfGdaMJYvtyFiPruQI
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[],mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  return mbBsjgklWepwUfGdaMJYvtyFiPruQz,mbBsjgklWepwUfGdaMJYvtyFiPruRN
 def ProgramidToContentid(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mbBsjgklWepwUfGdaMJYvtyFiPruQD):
  mbBsjgklWepwUfGdaMJYvtyFiPruQX=''
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCN =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/vod/programs-contentid/'+mbBsjgklWepwUfGdaMJYvtyFiPruQD
   mbBsjgklWepwUfGdaMJYvtyFiPruCL=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ)
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruQL=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('contentid' in mbBsjgklWepwUfGdaMJYvtyFiPruQL):return mbBsjgklWepwUfGdaMJYvtyFiPruQX 
   mbBsjgklWepwUfGdaMJYvtyFiPruQX=mbBsjgklWepwUfGdaMJYvtyFiPruQL['contentid']
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
  return mbBsjgklWepwUfGdaMJYvtyFiPruQX
 def ContentidToProgramid(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mbBsjgklWepwUfGdaMJYvtyFiPruQX):
  mbBsjgklWepwUfGdaMJYvtyFiPruQD=''
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCN =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/cf/vod/contents/'+mbBsjgklWepwUfGdaMJYvtyFiPruQX
   mbBsjgklWepwUfGdaMJYvtyFiPruCL=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ)
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruQL=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('programid' in mbBsjgklWepwUfGdaMJYvtyFiPruQL):return mbBsjgklWepwUfGdaMJYvtyFiPruQD 
   mbBsjgklWepwUfGdaMJYvtyFiPruQD=mbBsjgklWepwUfGdaMJYvtyFiPruQL['programid']
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
  return mbBsjgklWepwUfGdaMJYvtyFiPruQD
 def GetProgramInfo(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,program_code):
  mbBsjgklWepwUfGdaMJYvtyFiPruQq={}
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/cf/vod/contents/'+program_code
   mbBsjgklWepwUfGdaMJYvtyFiPruCL=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ)
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruQL=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(mbBsjgklWepwUfGdaMJYvtyFiPruQL)
   mbBsjgklWepwUfGdaMJYvtyFiPruQc=img_fanart=mbBsjgklWepwUfGdaMJYvtyFiPruQO=''
   if mbBsjgklWepwUfGdaMJYvtyFiPruQL.get('programposterimage')!='':mbBsjgklWepwUfGdaMJYvtyFiPruQc =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.HTTPTAG+mbBsjgklWepwUfGdaMJYvtyFiPruQL.get('programposterimage')
   if mbBsjgklWepwUfGdaMJYvtyFiPruQL.get('programimage') !='':img_fanart =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.HTTPTAG+mbBsjgklWepwUfGdaMJYvtyFiPruQL.get('programimage')
   if mbBsjgklWepwUfGdaMJYvtyFiPruQL.get('programcirlceimage')!='':mbBsjgklWepwUfGdaMJYvtyFiPruQO=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.HTTPTAG+mbBsjgklWepwUfGdaMJYvtyFiPruQL.get('programcirlceimage')
   if 'poster_default' in mbBsjgklWepwUfGdaMJYvtyFiPruQc:
    mbBsjgklWepwUfGdaMJYvtyFiPruQc =img_fanart
    mbBsjgklWepwUfGdaMJYvtyFiPruQO=''
   mbBsjgklWepwUfGdaMJYvtyFiPruQq={'imgPoster':mbBsjgklWepwUfGdaMJYvtyFiPruQc,'imgFanart':img_fanart,'imgClearlogo':mbBsjgklWepwUfGdaMJYvtyFiPruQO}
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
  return mbBsjgklWepwUfGdaMJYvtyFiPruQq
 def Get_Episode_List(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mbBsjgklWepwUfGdaMJYvtyFiPruQT,mbBsjgklWepwUfGdaMJYvtyFiPruQE,page_int=1,orderby='desc'):
  mbBsjgklWepwUfGdaMJYvtyFiPruQh=[]
  mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruQI=1
  mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  mbBsjgklWepwUfGdaMJYvtyFiPruQV={}
  if mbBsjgklWepwUfGdaMJYvtyFiPruQE=='contentid':
   mbBsjgklWepwUfGdaMJYvtyFiPruQD=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.ContentidToProgramid(mbBsjgklWepwUfGdaMJYvtyFiPruQT)
   mbBsjgklWepwUfGdaMJYvtyFiPruQV=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetProgramInfo(mbBsjgklWepwUfGdaMJYvtyFiPruQT)
  else:
   mbBsjgklWepwUfGdaMJYvtyFiPruQD=mbBsjgklWepwUfGdaMJYvtyFiPruQT
   mbBsjgklWepwUfGdaMJYvtyFiPruQX=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.ProgramidToContentid(mbBsjgklWepwUfGdaMJYvtyFiPruQT)
   if mbBsjgklWepwUfGdaMJYvtyFiPruQX!='':mbBsjgklWepwUfGdaMJYvtyFiPruQV=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetProgramInfo(mbBsjgklWepwUfGdaMJYvtyFiPruQX)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/vod/programs-contents/'+mbBsjgklWepwUfGdaMJYvtyFiPruQD
   mbBsjgklWepwUfGdaMJYvtyFiPruCL={}
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['limit'] =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.EP_LIMIT
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['offset']=mbBsjgklWepwUfGdaMJYvtyFiPruIo((page_int-1)*mbBsjgklWepwUfGdaMJYvtyFiPruCQ.EP_LIMIT)
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['orderby']=orderby 
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruRE['list']
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruRD:
    mbBsjgklWepwUfGdaMJYvtyFiPruQA=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('synopsis'))
    mbBsjgklWepwUfGdaMJYvtyFiPruQK=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.HTTPTAG+mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('image')
    mbBsjgklWepwUfGdaMJYvtyFiPruQn=mbBsjgklWepwUfGdaMJYvtyFiPruQN=mbBsjgklWepwUfGdaMJYvtyFiPruEC=''
    if mbBsjgklWepwUfGdaMJYvtyFiPruQV!={}:
     mbBsjgklWepwUfGdaMJYvtyFiPruQn =mbBsjgklWepwUfGdaMJYvtyFiPruQV.get('imgPoster')
     mbBsjgklWepwUfGdaMJYvtyFiPruQN =mbBsjgklWepwUfGdaMJYvtyFiPruQV.get('imgFanart')
     mbBsjgklWepwUfGdaMJYvtyFiPruEC=mbBsjgklWepwUfGdaMJYvtyFiPruQV.get('imgClearlogo')
     mbBsjgklWepwUfGdaMJYvtyFiPruER={'thumb':mbBsjgklWepwUfGdaMJYvtyFiPruQK,'poster':mbBsjgklWepwUfGdaMJYvtyFiPruQn,'fanart':mbBsjgklWepwUfGdaMJYvtyFiPruQN,'clearlogo':mbBsjgklWepwUfGdaMJYvtyFiPruEC}
    else:
     mbBsjgklWepwUfGdaMJYvtyFiPruER=mbBsjgklWepwUfGdaMJYvtyFiPruQK
    mbBsjgklWepwUfGdaMJYvtyFiPruRc={'programtitle':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('programtitle'),'episodetitle':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('episodetitle'),'episodenumber':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('episodenumber'),'releasedate':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('releasedate'),'releaseweekday':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('releaseweekday'),'programid':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('programid'),'contentid':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('contentid'),'age':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('targetage'),'playtime':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('playtime'),'synopsis':mbBsjgklWepwUfGdaMJYvtyFiPruQA,'episodeactors':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('episodeactors').split(',')if mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('episodeactors')!='' else[],'thumbnail':mbBsjgklWepwUfGdaMJYvtyFiPruER}
    mbBsjgklWepwUfGdaMJYvtyFiPruQh.append(mbBsjgklWepwUfGdaMJYvtyFiPruRc)
   mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruRE['pagecount'])
   if mbBsjgklWepwUfGdaMJYvtyFiPruRE['count']:mbBsjgklWepwUfGdaMJYvtyFiPruQI =mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruRE['count'])
   else:mbBsjgklWepwUfGdaMJYvtyFiPruQI=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.EP_LIMIT*page_int
   mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruRn>mbBsjgklWepwUfGdaMJYvtyFiPruQI
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[],mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  return mbBsjgklWepwUfGdaMJYvtyFiPruQh,mbBsjgklWepwUfGdaMJYvtyFiPruRN
 def GetEPGList(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,genre):
  mbBsjgklWepwUfGdaMJYvtyFiPruEQ={}
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruET=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Get_Now_Datetime()
   if genre=='all':
    mbBsjgklWepwUfGdaMJYvtyFiPruEI =mbBsjgklWepwUfGdaMJYvtyFiPruET+datetime.timedelta(hours=3)
   else:
    mbBsjgklWepwUfGdaMJYvtyFiPruEI =mbBsjgklWepwUfGdaMJYvtyFiPruET+datetime.timedelta(hours=3)
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/live/epgs'
   mbBsjgklWepwUfGdaMJYvtyFiPruCL={'limit':'100','offset':'0','genre':genre,'startdatetime':mbBsjgklWepwUfGdaMJYvtyFiPruET.strftime('%Y-%m-%d %H:00'),'enddatetime':mbBsjgklWepwUfGdaMJYvtyFiPruEI.strftime('%Y-%m-%d %H:00')}
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   mbBsjgklWepwUfGdaMJYvtyFiPruEx=mbBsjgklWepwUfGdaMJYvtyFiPruRE['list']
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruEx:
    mbBsjgklWepwUfGdaMJYvtyFiPruEo=''
    for mbBsjgklWepwUfGdaMJYvtyFiPruES in mbBsjgklWepwUfGdaMJYvtyFiPruRq['list']:
     if mbBsjgklWepwUfGdaMJYvtyFiPruEo:mbBsjgklWepwUfGdaMJYvtyFiPruEo+='\n'
     mbBsjgklWepwUfGdaMJYvtyFiPruEo+=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Get_ChangeText(mbBsjgklWepwUfGdaMJYvtyFiPruES['title'])+'\n'
     mbBsjgklWepwUfGdaMJYvtyFiPruEo+=' [%s ~ %s]'%(mbBsjgklWepwUfGdaMJYvtyFiPruES['starttime'][-5:],mbBsjgklWepwUfGdaMJYvtyFiPruES['endtime'][-5:])+'\n'
    mbBsjgklWepwUfGdaMJYvtyFiPruEQ[mbBsjgklWepwUfGdaMJYvtyFiPruRq['channelid']]=mbBsjgklWepwUfGdaMJYvtyFiPruEo
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
  return mbBsjgklWepwUfGdaMJYvtyFiPruEQ
 def Get_LiveChannel_List(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,genre,mbBsjgklWepwUfGdaMJYvtyFiPruRX):
  mbBsjgklWepwUfGdaMJYvtyFiPruRK=[]
  (mbBsjgklWepwUfGdaMJYvtyFiPruCN,mbBsjgklWepwUfGdaMJYvtyFiPruCL)=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Baseapi_Parse(mbBsjgklWepwUfGdaMJYvtyFiPruRX)
  if mbBsjgklWepwUfGdaMJYvtyFiPruCN=='':return mbBsjgklWepwUfGdaMJYvtyFiPruRK
  mbBsjgklWepwUfGdaMJYvtyFiPruEz=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetEPGList(genre)
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   mbBsjgklWepwUfGdaMJYvtyFiPruCL['genre']=genre
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('celllist' in mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']):return[]
   mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['celllist']
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruRD:
    mbBsjgklWepwUfGdaMJYvtyFiPruQX=mbBsjgklWepwUfGdaMJYvtyFiPruRq['contentid']
    if mbBsjgklWepwUfGdaMJYvtyFiPruQX in mbBsjgklWepwUfGdaMJYvtyFiPruEz:
     mbBsjgklWepwUfGdaMJYvtyFiPruEX=mbBsjgklWepwUfGdaMJYvtyFiPruEz[mbBsjgklWepwUfGdaMJYvtyFiPruQX]
    else:
     mbBsjgklWepwUfGdaMJYvtyFiPruEX=''
    mbBsjgklWepwUfGdaMJYvtyFiPruRc={'studio':mbBsjgklWepwUfGdaMJYvtyFiPruRq['title_list'][0]['text'],'tvshowtitle':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Get_ChangeText(mbBsjgklWepwUfGdaMJYvtyFiPruRq['title_list'][1]['text']),'channelid':mbBsjgklWepwUfGdaMJYvtyFiPruQX,'age':mbBsjgklWepwUfGdaMJYvtyFiPruRq['age'],'thumbnail':'https://%s'%mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('thumbnail'),'epg':mbBsjgklWepwUfGdaMJYvtyFiPruEX}
    mbBsjgklWepwUfGdaMJYvtyFiPruRK.append(mbBsjgklWepwUfGdaMJYvtyFiPruRc)
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[]
  return mbBsjgklWepwUfGdaMJYvtyFiPruRK
 def Get_Search_List(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,search_key,sType,page_int,exclusion21=mbBsjgklWepwUfGdaMJYvtyFiPruIQ):
  mbBsjgklWepwUfGdaMJYvtyFiPruEL=[]
  mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruQI=1
  mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruIQ
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/cf/search/list.js'
   mbBsjgklWepwUfGdaMJYvtyFiPruCL={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':mbBsjgklWepwUfGdaMJYvtyFiPruIo((page_int-1)*mbBsjgklWepwUfGdaMJYvtyFiPruCQ.SEARCH_LIMIT),'limit':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.SEARCH_LIMIT,'orderby':'score'}
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruQL=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('celllist' in mbBsjgklWepwUfGdaMJYvtyFiPruQL['cell_toplist']):return mbBsjgklWepwUfGdaMJYvtyFiPruEL,mbBsjgklWepwUfGdaMJYvtyFiPruRN
   mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruQL['cell_toplist']['celllist']
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruRD:
    mbBsjgklWepwUfGdaMJYvtyFiPruQC =mbBsjgklWepwUfGdaMJYvtyFiPruRq['event_list'][1]['url']
    mbBsjgklWepwUfGdaMJYvtyFiPruQR=urllib.parse.urlsplit(mbBsjgklWepwUfGdaMJYvtyFiPruQC).query
    mbBsjgklWepwUfGdaMJYvtyFiPruQE=mbBsjgklWepwUfGdaMJYvtyFiPruQR[0:mbBsjgklWepwUfGdaMJYvtyFiPruQR.find('=')]
    mbBsjgklWepwUfGdaMJYvtyFiPruQT=mbBsjgklWepwUfGdaMJYvtyFiPruQR[mbBsjgklWepwUfGdaMJYvtyFiPruQR.find('=')+1:]
    mbBsjgklWepwUfGdaMJYvtyFiPruRc={'title':mbBsjgklWepwUfGdaMJYvtyFiPruRq['title_list'][0]['text'],'age':mbBsjgklWepwUfGdaMJYvtyFiPruRq['age'],'thumbnail':'https://%s'%mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('thumbnail'),'videoid':mbBsjgklWepwUfGdaMJYvtyFiPruQT,'vidtype':mbBsjgklWepwUfGdaMJYvtyFiPruQE}
    if exclusion21==mbBsjgklWepwUfGdaMJYvtyFiPruIQ or mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('age')!='21':
     mbBsjgklWepwUfGdaMJYvtyFiPruEL.append(mbBsjgklWepwUfGdaMJYvtyFiPruRc)
   mbBsjgklWepwUfGdaMJYvtyFiPruRn=mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruQL['cell_toplist']['pagecount'])
   if mbBsjgklWepwUfGdaMJYvtyFiPruQL['cell_toplist']['count']:mbBsjgklWepwUfGdaMJYvtyFiPruQI =mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruQL['cell_toplist']['count'])
   else:mbBsjgklWepwUfGdaMJYvtyFiPruQI=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.LIST_LIMIT
   mbBsjgklWepwUfGdaMJYvtyFiPruRN=mbBsjgklWepwUfGdaMJYvtyFiPruRn>mbBsjgklWepwUfGdaMJYvtyFiPruQI
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
  return mbBsjgklWepwUfGdaMJYvtyFiPruEL,mbBsjgklWepwUfGdaMJYvtyFiPruRN 
 def GetStreamingURL(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mode,mbBsjgklWepwUfGdaMJYvtyFiPruQX,quality_int,pvrmode='-'):
  mbBsjgklWepwUfGdaMJYvtyFiPruED ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'',}
  mbBsjgklWepwUfGdaMJYvtyFiPruEq=[]
  mbBsjgklWepwUfGdaMJYvtyFiPruEc='hls'
  if mode=='LIVE':
   mbBsjgklWepwUfGdaMJYvtyFiPruCN =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/live/channels/'+mbBsjgklWepwUfGdaMJYvtyFiPruQX
   mbBsjgklWepwUfGdaMJYvtyFiPruEO='live'
  elif mode=='VOD':
   mbBsjgklWepwUfGdaMJYvtyFiPruCN =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/cf/vod/contents/'+mbBsjgklWepwUfGdaMJYvtyFiPruQX
   mbBsjgklWepwUfGdaMJYvtyFiPruEO='vod'
  elif mode=='MOVIE':
   mbBsjgklWepwUfGdaMJYvtyFiPruCN =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/cf/movie/contents/'+mbBsjgklWepwUfGdaMJYvtyFiPruQX
   mbBsjgklWepwUfGdaMJYvtyFiPruEO='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    mbBsjgklWepwUfGdaMJYvtyFiPruCL=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ)
    mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
    mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
    mbBsjgklWepwUfGdaMJYvtyFiPruEh=mbBsjgklWepwUfGdaMJYvtyFiPruRE['qualities']['list']
    if mbBsjgklWepwUfGdaMJYvtyFiPruEh==mbBsjgklWepwUfGdaMJYvtyFiPruIR:return mbBsjgklWepwUfGdaMJYvtyFiPruED
    for mbBsjgklWepwUfGdaMJYvtyFiPruEV in mbBsjgklWepwUfGdaMJYvtyFiPruEh:
     mbBsjgklWepwUfGdaMJYvtyFiPruEq.append(mbBsjgklWepwUfGdaMJYvtyFiPruIL(mbBsjgklWepwUfGdaMJYvtyFiPruEV.get('id').rstrip('p')))
    if 'type' in mbBsjgklWepwUfGdaMJYvtyFiPruRE:
     if mbBsjgklWepwUfGdaMJYvtyFiPruRE['type']=='onair':
      mbBsjgklWepwUfGdaMJYvtyFiPruEO='onairvod'
    if 'drms' in mbBsjgklWepwUfGdaMJYvtyFiPruRE:
     if mbBsjgklWepwUfGdaMJYvtyFiPruRE['drms']:
      mbBsjgklWepwUfGdaMJYvtyFiPruEc='dash'
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return mbBsjgklWepwUfGdaMJYvtyFiPruED
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruEH=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.CheckQuality(quality_int,mbBsjgklWepwUfGdaMJYvtyFiPruEq)
   if mode=='LIVE' and pvrmode!='-':
    mbBsjgklWepwUfGdaMJYvtyFiPruEA='auto'
   else:
    mbBsjgklWepwUfGdaMJYvtyFiPruEA=mbBsjgklWepwUfGdaMJYvtyFiPruIo(mbBsjgklWepwUfGdaMJYvtyFiPruEH)+'p'
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/streaming'
   mbBsjgklWepwUfGdaMJYvtyFiPruCL={'contentid':mbBsjgklWepwUfGdaMJYvtyFiPruQX,'contenttype':mbBsjgklWepwUfGdaMJYvtyFiPruEO,'action':mbBsjgklWepwUfGdaMJYvtyFiPruEc,'quality':mbBsjgklWepwUfGdaMJYvtyFiPruEA,'deviceModelId':'Windows 10','guid':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIT))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   mbBsjgklWepwUfGdaMJYvtyFiPruED['stream_url']=mbBsjgklWepwUfGdaMJYvtyFiPruRE['playurl']
   if mbBsjgklWepwUfGdaMJYvtyFiPruED['stream_url']==mbBsjgklWepwUfGdaMJYvtyFiPruIR:return mbBsjgklWepwUfGdaMJYvtyFiPruED
   mbBsjgklWepwUfGdaMJYvtyFiPruED['stream_cookie']=mbBsjgklWepwUfGdaMJYvtyFiPruRE['awscookie']
   mbBsjgklWepwUfGdaMJYvtyFiPruED['stream_drm'] =mbBsjgklWepwUfGdaMJYvtyFiPruRE['drm']
   if 'previewmsg' in mbBsjgklWepwUfGdaMJYvtyFiPruRE['preview']:mbBsjgklWepwUfGdaMJYvtyFiPruED['stream_preview']=mbBsjgklWepwUfGdaMJYvtyFiPruRE['preview']['previewmsg']
   if 'subtitles' in mbBsjgklWepwUfGdaMJYvtyFiPruRE:
    for mbBsjgklWepwUfGdaMJYvtyFiPruEK in mbBsjgklWepwUfGdaMJYvtyFiPruRE['subtitles']:
     if mbBsjgklWepwUfGdaMJYvtyFiPruEK.get('languagecode')=='ko':
      mbBsjgklWepwUfGdaMJYvtyFiPruED['stream_vtt']=mbBsjgklWepwUfGdaMJYvtyFiPruEK.get('url')
      break
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
  return mbBsjgklWepwUfGdaMJYvtyFiPruED 
 def GetSportsURL(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mbBsjgklWepwUfGdaMJYvtyFiPruQX,quality_int):
  mbBsjgklWepwUfGdaMJYvtyFiPruED ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'',}
  mbBsjgklWepwUfGdaMJYvtyFiPruEq=[]
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/streaming/other'
   mbBsjgklWepwUfGdaMJYvtyFiPruCL={'contentid':mbBsjgklWepwUfGdaMJYvtyFiPruQX,'contenttype':'live','action':'hls','quality':mbBsjgklWepwUfGdaMJYvtyFiPruIo(quality_int)+'p','deviceModelId':'Windows 10','guid':mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIT))
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   mbBsjgklWepwUfGdaMJYvtyFiPruED['stream_url']=mbBsjgklWepwUfGdaMJYvtyFiPruRE['playurl']
   if mbBsjgklWepwUfGdaMJYvtyFiPruED['stream_url']==mbBsjgklWepwUfGdaMJYvtyFiPruIR:return mbBsjgklWepwUfGdaMJYvtyFiPruED
   mbBsjgklWepwUfGdaMJYvtyFiPruED['stream_cookie']=mbBsjgklWepwUfGdaMJYvtyFiPruRE['awscookie']
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
  return mbBsjgklWepwUfGdaMJYvtyFiPruED
 def make_viewdate(mbBsjgklWepwUfGdaMJYvtyFiPruCQ):
  mbBsjgklWepwUfGdaMJYvtyFiPruEn =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.Get_Now_Datetime()
  mbBsjgklWepwUfGdaMJYvtyFiPruEN =mbBsjgklWepwUfGdaMJYvtyFiPruEn+datetime.timedelta(days=-1)
  mbBsjgklWepwUfGdaMJYvtyFiPruTC =mbBsjgklWepwUfGdaMJYvtyFiPruEn+datetime.timedelta(days=1)
  mbBsjgklWepwUfGdaMJYvtyFiPruTR=[mbBsjgklWepwUfGdaMJYvtyFiPruEn.strftime('%Y%m%d'),mbBsjgklWepwUfGdaMJYvtyFiPruTC.strftime('%Y%m%d'),]
  return mbBsjgklWepwUfGdaMJYvtyFiPruTR
 def Get_Sports_Gamelist(mbBsjgklWepwUfGdaMJYvtyFiPruCQ):
  mbBsjgklWepwUfGdaMJYvtyFiPruTQ =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.make_viewdate()
  mbBsjgklWepwUfGdaMJYvtyFiPruTE=[]
  mbBsjgklWepwUfGdaMJYvtyFiPruTI =[]
  for mbBsjgklWepwUfGdaMJYvtyFiPruTx in mbBsjgklWepwUfGdaMJYvtyFiPruTQ:
   mbBsjgklWepwUfGdaMJYvtyFiPruTo=mbBsjgklWepwUfGdaMJYvtyFiPruTx[:6]
   if mbBsjgklWepwUfGdaMJYvtyFiPruTo not in mbBsjgklWepwUfGdaMJYvtyFiPruTE:
    mbBsjgklWepwUfGdaMJYvtyFiPruTE.append(mbBsjgklWepwUfGdaMJYvtyFiPruTo)
  try:
   mbBsjgklWepwUfGdaMJYvtyFiPruCN='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   mbBsjgklWepwUfGdaMJYvtyFiPruCL={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   mbBsjgklWepwUfGdaMJYvtyFiPruCL.update(mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ))
   for mbBsjgklWepwUfGdaMJYvtyFiPruTS in mbBsjgklWepwUfGdaMJYvtyFiPruTE:
    mbBsjgklWepwUfGdaMJYvtyFiPruCL['date']=mbBsjgklWepwUfGdaMJYvtyFiPruTS
    mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
    mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
    mbBsjgklWepwUfGdaMJYvtyFiPruRD=mbBsjgklWepwUfGdaMJYvtyFiPruRE['cell_toplist']['celllist']
    for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruRD:
     mbBsjgklWepwUfGdaMJYvtyFiPruTz=mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('game_date')
     mbBsjgklWepwUfGdaMJYvtyFiPruTX =mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('svc_id')
     if mbBsjgklWepwUfGdaMJYvtyFiPruTX=='':continue
     if mbBsjgklWepwUfGdaMJYvtyFiPruTz in mbBsjgklWepwUfGdaMJYvtyFiPruTQ:
      mbBsjgklWepwUfGdaMJYvtyFiPruTL=mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('game_status') 
      mbBsjgklWepwUfGdaMJYvtyFiPruTD =mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('title_list')[0].get('text')
      mbBsjgklWepwUfGdaMJYvtyFiPruTz =mbBsjgklWepwUfGdaMJYvtyFiPruTz[:4]+'-'+mbBsjgklWepwUfGdaMJYvtyFiPruTz[4:6]+'-'+mbBsjgklWepwUfGdaMJYvtyFiPruTz[-2:]
      mbBsjgklWepwUfGdaMJYvtyFiPruTq =mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('game_time')
      mbBsjgklWepwUfGdaMJYvtyFiPruTq =mbBsjgklWepwUfGdaMJYvtyFiPruTq[:2]+':'+mbBsjgklWepwUfGdaMJYvtyFiPruTq[-2:]
      mbBsjgklWepwUfGdaMJYvtyFiPruRc={'game_date':mbBsjgklWepwUfGdaMJYvtyFiPruTz,'game_time':mbBsjgklWepwUfGdaMJYvtyFiPruTq,'svc_id':mbBsjgklWepwUfGdaMJYvtyFiPruTX,'away_team':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('away_team').get('team_name'),'home_team':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('home_team').get('team_name'),'game_status':mbBsjgklWepwUfGdaMJYvtyFiPruTL,'game_place':mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('game_place'),}
      mbBsjgklWepwUfGdaMJYvtyFiPruTI.append(mbBsjgklWepwUfGdaMJYvtyFiPruRc)
  except mbBsjgklWepwUfGdaMJYvtyFiPruIS as exception:
   mbBsjgklWepwUfGdaMJYvtyFiPruIz(exception)
   return[]
  mbBsjgklWepwUfGdaMJYvtyFiPruTc=[]
  for i in mbBsjgklWepwUfGdaMJYvtyFiPruIx(2):
   for mbBsjgklWepwUfGdaMJYvtyFiPruRq in mbBsjgklWepwUfGdaMJYvtyFiPruTI:
    if i==0 and mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('game_status')=='LIVE':
     mbBsjgklWepwUfGdaMJYvtyFiPruTc.append(mbBsjgklWepwUfGdaMJYvtyFiPruRq)
    elif i==1 and mbBsjgklWepwUfGdaMJYvtyFiPruRq.get('game_status')!='LIVE':
     mbBsjgklWepwUfGdaMJYvtyFiPruTc.append(mbBsjgklWepwUfGdaMJYvtyFiPruRq)
  return mbBsjgklWepwUfGdaMJYvtyFiPruTc
 def GetBookmarkInfo(mbBsjgklWepwUfGdaMJYvtyFiPruCQ,mbBsjgklWepwUfGdaMJYvtyFiPruQT,mbBsjgklWepwUfGdaMJYvtyFiPruQE,mbBsjgklWepwUfGdaMJYvtyFiPruEO):
  if mbBsjgklWepwUfGdaMJYvtyFiPruQE=='tvshow':
   if mbBsjgklWepwUfGdaMJYvtyFiPruEO=='contentid':
    mbBsjgklWepwUfGdaMJYvtyFiPruQX=mbBsjgklWepwUfGdaMJYvtyFiPruQT
    mbBsjgklWepwUfGdaMJYvtyFiPruQT =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.ContentidToProgramid(mbBsjgklWepwUfGdaMJYvtyFiPruQX)
   else:
    mbBsjgklWepwUfGdaMJYvtyFiPruQX=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.ProgramidToContentid(mbBsjgklWepwUfGdaMJYvtyFiPruQT)
  else:
   mbBsjgklWepwUfGdaMJYvtyFiPruQX=''
  mbBsjgklWepwUfGdaMJYvtyFiPruTO={'indexinfo':{'ott':'wavve','videoid':mbBsjgklWepwUfGdaMJYvtyFiPruQT,'vidtype':mbBsjgklWepwUfGdaMJYvtyFiPruQE,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':mbBsjgklWepwUfGdaMJYvtyFiPruQE,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if mbBsjgklWepwUfGdaMJYvtyFiPruQE=='tvshow':
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/cf/vod/contents/'+mbBsjgklWepwUfGdaMJYvtyFiPruQX 
   mbBsjgklWepwUfGdaMJYvtyFiPruCL=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ)
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('programtitle' in mbBsjgklWepwUfGdaMJYvtyFiPruRE):return{}
   mbBsjgklWepwUfGdaMJYvtyFiPruTh=mbBsjgklWepwUfGdaMJYvtyFiPruRE
   mbBsjgklWepwUfGdaMJYvtyFiPruTV=mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('programtitle')
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['title']=mbBsjgklWepwUfGdaMJYvtyFiPruTV
   if mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('targetage')=='18' or mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('targetage')=='19' or mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('targetage')=='21':
    mbBsjgklWepwUfGdaMJYvtyFiPruTV +=u' (%s)'%(mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('targetage'))
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['title'] =mbBsjgklWepwUfGdaMJYvtyFiPruTV
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['mpaa'] =mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('targetage')
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['plot'] =mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('programsynopsis').replace('<br>','\n')
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['studio'] =mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('channelname')
   if mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('firstreleaseyear')!='':mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['year'] =mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('firstreleaseyear')
   if mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('firstreleasedate')!='':mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['premiered']=mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('firstreleasedate')
   if mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('genretext') !='':mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['genre'] =[mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('genretext')]
   mbBsjgklWepwUfGdaMJYvtyFiPruTH=[]
   for mbBsjgklWepwUfGdaMJYvtyFiPruTA in mbBsjgklWepwUfGdaMJYvtyFiPruTh['actors']['list']:mbBsjgklWepwUfGdaMJYvtyFiPruTH.append(mbBsjgklWepwUfGdaMJYvtyFiPruTA.get('text'))
   if mbBsjgklWepwUfGdaMJYvtyFiPruID(mbBsjgklWepwUfGdaMJYvtyFiPruTH)>0:
    if mbBsjgklWepwUfGdaMJYvtyFiPruTH[0]!='':mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['cast']=mbBsjgklWepwUfGdaMJYvtyFiPruTH
   mbBsjgklWepwUfGdaMJYvtyFiPruQn =''
   mbBsjgklWepwUfGdaMJYvtyFiPruQN =''
   mbBsjgklWepwUfGdaMJYvtyFiPruEC=''
   if mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('programposterimage')!='':mbBsjgklWepwUfGdaMJYvtyFiPruQn =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.HTTPTAG+mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('programposterimage')
   if mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('programimage') !='':mbBsjgklWepwUfGdaMJYvtyFiPruQN =mbBsjgklWepwUfGdaMJYvtyFiPruCQ.HTTPTAG+mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('programimage')
   if mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('programcirlceimage')!='':mbBsjgklWepwUfGdaMJYvtyFiPruEC=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.HTTPTAG+mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('programcirlceimage')
   if 'poster_default' in mbBsjgklWepwUfGdaMJYvtyFiPruQn:
    mbBsjgklWepwUfGdaMJYvtyFiPruQn =mbBsjgklWepwUfGdaMJYvtyFiPruQN
    mbBsjgklWepwUfGdaMJYvtyFiPruEC=''
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['thumbnail']['poster']=mbBsjgklWepwUfGdaMJYvtyFiPruQn
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['thumbnail']['thumb']=mbBsjgklWepwUfGdaMJYvtyFiPruQN
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['thumbnail']['clearlogo']=mbBsjgklWepwUfGdaMJYvtyFiPruEC
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['thumbnail']['fanart']=mbBsjgklWepwUfGdaMJYvtyFiPruQN
  else:
   mbBsjgklWepwUfGdaMJYvtyFiPruCN=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.API_DOMAIN+'/movie/contents/'+mbBsjgklWepwUfGdaMJYvtyFiPruQT 
   mbBsjgklWepwUfGdaMJYvtyFiPruCL=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.GetDefaultParams(login=mbBsjgklWepwUfGdaMJYvtyFiPruIQ)
   mbBsjgklWepwUfGdaMJYvtyFiPruRQ=mbBsjgklWepwUfGdaMJYvtyFiPruCQ.callRequestCookies('Get',mbBsjgklWepwUfGdaMJYvtyFiPruCN,payload=mbBsjgklWepwUfGdaMJYvtyFiPruIR,params=mbBsjgklWepwUfGdaMJYvtyFiPruCL,headers=mbBsjgklWepwUfGdaMJYvtyFiPruIR,cookies=mbBsjgklWepwUfGdaMJYvtyFiPruIR)
   mbBsjgklWepwUfGdaMJYvtyFiPruRE=json.loads(mbBsjgklWepwUfGdaMJYvtyFiPruRQ.text)
   if not('title' in mbBsjgklWepwUfGdaMJYvtyFiPruRE):return{}
   mbBsjgklWepwUfGdaMJYvtyFiPruTh=mbBsjgklWepwUfGdaMJYvtyFiPruRE
   mbBsjgklWepwUfGdaMJYvtyFiPruTV=mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('title')
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['title']=mbBsjgklWepwUfGdaMJYvtyFiPruTV
   if mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('targetage')=='18' or mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('targetage')=='19' or mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('targetage')=='21':
    mbBsjgklWepwUfGdaMJYvtyFiPruTV +=u' (%s)'%(mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('targetage'))
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['title'] =mbBsjgklWepwUfGdaMJYvtyFiPruTV
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['mpaa'] =mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('targetage')
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['plot'] =mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('synopsis').replace('<br>','\n')
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['duration']=mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('playtime')
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['country']=mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('country')
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['studio'] =mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('cpname')
   if mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('releasedate')!='':
    mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['year'] =mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('releasedate')[:4]
    mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['premiered']=mbBsjgklWepwUfGdaMJYvtyFiPruTh.get('releasedate')
   mbBsjgklWepwUfGdaMJYvtyFiPruTH=[]
   for mbBsjgklWepwUfGdaMJYvtyFiPruTA in mbBsjgklWepwUfGdaMJYvtyFiPruTh['actors']['list']:mbBsjgklWepwUfGdaMJYvtyFiPruTH.append(mbBsjgklWepwUfGdaMJYvtyFiPruTA.get('text'))
   if mbBsjgklWepwUfGdaMJYvtyFiPruID(mbBsjgklWepwUfGdaMJYvtyFiPruTH)>0:
    if mbBsjgklWepwUfGdaMJYvtyFiPruTH[0]!='':mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['cast']=mbBsjgklWepwUfGdaMJYvtyFiPruTH
   mbBsjgklWepwUfGdaMJYvtyFiPruTK=[]
   for mbBsjgklWepwUfGdaMJYvtyFiPruTn in mbBsjgklWepwUfGdaMJYvtyFiPruTh['directors']['list']:mbBsjgklWepwUfGdaMJYvtyFiPruTK.append(mbBsjgklWepwUfGdaMJYvtyFiPruTn.get('text'))
   if mbBsjgklWepwUfGdaMJYvtyFiPruID(mbBsjgklWepwUfGdaMJYvtyFiPruTK)>0:
    if mbBsjgklWepwUfGdaMJYvtyFiPruTK[0]!='':mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['director']=mbBsjgklWepwUfGdaMJYvtyFiPruTK
   mbBsjgklWepwUfGdaMJYvtyFiPruRz=[]
   for mbBsjgklWepwUfGdaMJYvtyFiPruTN in mbBsjgklWepwUfGdaMJYvtyFiPruTh['genre']['list']:mbBsjgklWepwUfGdaMJYvtyFiPruRz.append(mbBsjgklWepwUfGdaMJYvtyFiPruTN.get('text'))
   if mbBsjgklWepwUfGdaMJYvtyFiPruID(mbBsjgklWepwUfGdaMJYvtyFiPruRz)>0:
    if mbBsjgklWepwUfGdaMJYvtyFiPruRz[0]!='':mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['infoLabels']['genre']=mbBsjgklWepwUfGdaMJYvtyFiPruRz
   mbBsjgklWepwUfGdaMJYvtyFiPruQn ='https://%s'%mbBsjgklWepwUfGdaMJYvtyFiPruTh['image']
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['thumbnail']['poster'] =mbBsjgklWepwUfGdaMJYvtyFiPruQn
   mbBsjgklWepwUfGdaMJYvtyFiPruTO['saveinfo']['thumbnail']['thumb'] =mbBsjgklWepwUfGdaMJYvtyFiPruQn
  return mbBsjgklWepwUfGdaMJYvtyFiPruTO
# Created by pyminifier (https://github.com/liftoff/pyminifier)
