__author__="NightRain"
iHQGFuWSVjfRalCdbArEqLMcJkghIX=object
iHQGFuWSVjfRalCdbArEqLMcJkghIe=None
iHQGFuWSVjfRalCdbArEqLMcJkghIB=int
iHQGFuWSVjfRalCdbArEqLMcJkghIN=True
iHQGFuWSVjfRalCdbArEqLMcJkghIt=False
iHQGFuWSVjfRalCdbArEqLMcJkghIO=type
iHQGFuWSVjfRalCdbArEqLMcJkghIw=dict
iHQGFuWSVjfRalCdbArEqLMcJkghIs=len
iHQGFuWSVjfRalCdbArEqLMcJkghxo=range
iHQGFuWSVjfRalCdbArEqLMcJkghxU=str
iHQGFuWSVjfRalCdbArEqLMcJkghxn=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
iHQGFuWSVjfRalCdbArEqLMcJkghon=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
iHQGFuWSVjfRalCdbArEqLMcJkghop=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
iHQGFuWSVjfRalCdbArEqLMcJkghoT=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
iHQGFuWSVjfRalCdbArEqLMcJkghoP =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
iHQGFuWSVjfRalCdbArEqLMcJkghoI=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class iHQGFuWSVjfRalCdbArEqLMcJkghoU(iHQGFuWSVjfRalCdbArEqLMcJkghIX):
 def __init__(iHQGFuWSVjfRalCdbArEqLMcJkghox,iHQGFuWSVjfRalCdbArEqLMcJkghom,iHQGFuWSVjfRalCdbArEqLMcJkghoD,iHQGFuWSVjfRalCdbArEqLMcJkghov):
  iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_url =iHQGFuWSVjfRalCdbArEqLMcJkghom
  iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle=iHQGFuWSVjfRalCdbArEqLMcJkghoD
  iHQGFuWSVjfRalCdbArEqLMcJkghox.main_params =iHQGFuWSVjfRalCdbArEqLMcJkghov
  iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj =mbBsjgklWepwUfGdaMJYvtyFiPruCR() 
 def addon_noti(iHQGFuWSVjfRalCdbArEqLMcJkghox,sting):
  try:
   iHQGFuWSVjfRalCdbArEqLMcJkghoz=xbmcgui.Dialog()
   iHQGFuWSVjfRalCdbArEqLMcJkghoz.notification(__addonname__,sting)
  except:
   iHQGFuWSVjfRalCdbArEqLMcJkghIe
 def addon_log(iHQGFuWSVjfRalCdbArEqLMcJkghox,string):
  try:
   iHQGFuWSVjfRalCdbArEqLMcJkghoy=string.encode('utf-8','ignore')
  except:
   iHQGFuWSVjfRalCdbArEqLMcJkghoy='addonException: addon_log'
  iHQGFuWSVjfRalCdbArEqLMcJkghoY=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,iHQGFuWSVjfRalCdbArEqLMcJkghoy),level=iHQGFuWSVjfRalCdbArEqLMcJkghoY)
 def get_keyboard_input(iHQGFuWSVjfRalCdbArEqLMcJkghox,iHQGFuWSVjfRalCdbArEqLMcJkghUm):
  iHQGFuWSVjfRalCdbArEqLMcJkghoX=iHQGFuWSVjfRalCdbArEqLMcJkghIe
  kb=xbmc.Keyboard()
  kb.setHeading(iHQGFuWSVjfRalCdbArEqLMcJkghUm)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   iHQGFuWSVjfRalCdbArEqLMcJkghoX=kb.getText()
  return iHQGFuWSVjfRalCdbArEqLMcJkghoX
 def get_settings_account(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  iHQGFuWSVjfRalCdbArEqLMcJkghoe =__addon__.getSetting('id')
  iHQGFuWSVjfRalCdbArEqLMcJkghoB =__addon__.getSetting('pw')
  iHQGFuWSVjfRalCdbArEqLMcJkghoN=iHQGFuWSVjfRalCdbArEqLMcJkghIB(__addon__.getSetting('selected_profile'))
  return(iHQGFuWSVjfRalCdbArEqLMcJkghoe,iHQGFuWSVjfRalCdbArEqLMcJkghoB,iHQGFuWSVjfRalCdbArEqLMcJkghoN)
 def get_settings_totalsearch(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  iHQGFuWSVjfRalCdbArEqLMcJkghot =iHQGFuWSVjfRalCdbArEqLMcJkghIN if __addon__.getSetting('local_search')=='true' else iHQGFuWSVjfRalCdbArEqLMcJkghIt
  iHQGFuWSVjfRalCdbArEqLMcJkghoO=iHQGFuWSVjfRalCdbArEqLMcJkghIN if __addon__.getSetting('local_history')=='true' else iHQGFuWSVjfRalCdbArEqLMcJkghIt
  iHQGFuWSVjfRalCdbArEqLMcJkghow =iHQGFuWSVjfRalCdbArEqLMcJkghIN if __addon__.getSetting('total_search')=='true' else iHQGFuWSVjfRalCdbArEqLMcJkghIt
  iHQGFuWSVjfRalCdbArEqLMcJkghos=iHQGFuWSVjfRalCdbArEqLMcJkghIN if __addon__.getSetting('total_history')=='true' else iHQGFuWSVjfRalCdbArEqLMcJkghIt
  iHQGFuWSVjfRalCdbArEqLMcJkghUo=iHQGFuWSVjfRalCdbArEqLMcJkghIN if __addon__.getSetting('menu_bookmark')=='true' else iHQGFuWSVjfRalCdbArEqLMcJkghIt
  return(iHQGFuWSVjfRalCdbArEqLMcJkghot,iHQGFuWSVjfRalCdbArEqLMcJkghoO,iHQGFuWSVjfRalCdbArEqLMcJkghow,iHQGFuWSVjfRalCdbArEqLMcJkghos,iHQGFuWSVjfRalCdbArEqLMcJkghUo)
 def get_settings_makebookmark(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  return iHQGFuWSVjfRalCdbArEqLMcJkghIN if __addon__.getSetting('make_bookmark')=='true' else iHQGFuWSVjfRalCdbArEqLMcJkghIt
 def get_selQuality(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  try:
   iHQGFuWSVjfRalCdbArEqLMcJkghUn=[1080,720,480,360]
   iHQGFuWSVjfRalCdbArEqLMcJkghUp=iHQGFuWSVjfRalCdbArEqLMcJkghIB(__addon__.getSetting('selected_quality'))
   return iHQGFuWSVjfRalCdbArEqLMcJkghUn[iHQGFuWSVjfRalCdbArEqLMcJkghUp]
  except:
   iHQGFuWSVjfRalCdbArEqLMcJkghIe
  return 1080 
 def get_settings_exclusion21(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  iHQGFuWSVjfRalCdbArEqLMcJkghUT =__addon__.getSetting('exclusion21')
  if iHQGFuWSVjfRalCdbArEqLMcJkghUT=='false':
   return iHQGFuWSVjfRalCdbArEqLMcJkghIt
  else:
   return iHQGFuWSVjfRalCdbArEqLMcJkghIN
 def get_settings_direct_replay(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  iHQGFuWSVjfRalCdbArEqLMcJkghUP=iHQGFuWSVjfRalCdbArEqLMcJkghIB(__addon__.getSetting('direct_replay'))
  if iHQGFuWSVjfRalCdbArEqLMcJkghUP==0:
   return iHQGFuWSVjfRalCdbArEqLMcJkghIt
  else:
   return iHQGFuWSVjfRalCdbArEqLMcJkghIN
 def set_winEpisodeOrderby(iHQGFuWSVjfRalCdbArEqLMcJkghox,iHQGFuWSVjfRalCdbArEqLMcJkghUI):
  __addon__.setSetting('wavve_orderby',iHQGFuWSVjfRalCdbArEqLMcJkghUI)
 def get_winEpisodeOrderby(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  iHQGFuWSVjfRalCdbArEqLMcJkghUI=__addon__.getSetting('wavve_orderby')
  if iHQGFuWSVjfRalCdbArEqLMcJkghUI in['',iHQGFuWSVjfRalCdbArEqLMcJkghIe]:iHQGFuWSVjfRalCdbArEqLMcJkghUI='desc'
  return iHQGFuWSVjfRalCdbArEqLMcJkghUI
 def add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghox,label,sublabel='',img='',infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params='',isLink=iHQGFuWSVjfRalCdbArEqLMcJkghIt,ContextMenu=iHQGFuWSVjfRalCdbArEqLMcJkghIe):
  iHQGFuWSVjfRalCdbArEqLMcJkghUx='%s?%s'%(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_url,urllib.parse.urlencode(params))
  if sublabel:iHQGFuWSVjfRalCdbArEqLMcJkghUm='%s < %s >'%(label,sublabel)
  else: iHQGFuWSVjfRalCdbArEqLMcJkghUm=label
  if not img:img='DefaultFolder.png'
  iHQGFuWSVjfRalCdbArEqLMcJkghUD=xbmcgui.ListItem(iHQGFuWSVjfRalCdbArEqLMcJkghUm)
  if iHQGFuWSVjfRalCdbArEqLMcJkghIO(img)==iHQGFuWSVjfRalCdbArEqLMcJkghIw:
   iHQGFuWSVjfRalCdbArEqLMcJkghUD.setArt(img)
  else:
   iHQGFuWSVjfRalCdbArEqLMcJkghUD.setArt({'thumb':img,'poster':img})
  if infoLabels:iHQGFuWSVjfRalCdbArEqLMcJkghUD.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   iHQGFuWSVjfRalCdbArEqLMcJkghUD.setProperty('IsPlayable','true')
  if ContextMenu:iHQGFuWSVjfRalCdbArEqLMcJkghUD.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,iHQGFuWSVjfRalCdbArEqLMcJkghUx,iHQGFuWSVjfRalCdbArEqLMcJkghUD,isFolder)
 def dp_Main_List(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  (iHQGFuWSVjfRalCdbArEqLMcJkghot,iHQGFuWSVjfRalCdbArEqLMcJkghoO,iHQGFuWSVjfRalCdbArEqLMcJkghow,iHQGFuWSVjfRalCdbArEqLMcJkghos,iHQGFuWSVjfRalCdbArEqLMcJkghUo)=iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_totalsearch()
  for iHQGFuWSVjfRalCdbArEqLMcJkghUv in iHQGFuWSVjfRalCdbArEqLMcJkghon:
   iHQGFuWSVjfRalCdbArEqLMcJkghUm=iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('title')
   iHQGFuWSVjfRalCdbArEqLMcJkghUK=''
   if iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('mode')=='SEARCH_GROUP' and iHQGFuWSVjfRalCdbArEqLMcJkghot ==iHQGFuWSVjfRalCdbArEqLMcJkghIt:continue
   elif iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('mode')=='SEARCH_HISTORY' and iHQGFuWSVjfRalCdbArEqLMcJkghoO==iHQGFuWSVjfRalCdbArEqLMcJkghIt:continue
   elif iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('mode')=='TOTAL_SEARCH' and iHQGFuWSVjfRalCdbArEqLMcJkghow ==iHQGFuWSVjfRalCdbArEqLMcJkghIt:continue
   elif iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('mode')=='TOTAL_HISTORY' and iHQGFuWSVjfRalCdbArEqLMcJkghos==iHQGFuWSVjfRalCdbArEqLMcJkghIt:continue
   elif iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('mode')=='MENU_BOOKMARK' and iHQGFuWSVjfRalCdbArEqLMcJkghUo==iHQGFuWSVjfRalCdbArEqLMcJkghIt:continue
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('mode'),'sCode':iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('sCode'),'sIndex':iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('sIndex'),'sType':iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('sType'),'suburl':iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('suburl'),'subapi':iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('subapi'),'page':iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('page'),'orderby':iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('orderby'),'ordernm':iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('ordernm')}
   if iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    iHQGFuWSVjfRalCdbArEqLMcJkghUy=iHQGFuWSVjfRalCdbArEqLMcJkghIt
    iHQGFuWSVjfRalCdbArEqLMcJkghUY =iHQGFuWSVjfRalCdbArEqLMcJkghIN
   else:
    iHQGFuWSVjfRalCdbArEqLMcJkghUy=iHQGFuWSVjfRalCdbArEqLMcJkghIN
    iHQGFuWSVjfRalCdbArEqLMcJkghUY =iHQGFuWSVjfRalCdbArEqLMcJkghIt
   if 'icon' in iHQGFuWSVjfRalCdbArEqLMcJkghUv:iHQGFuWSVjfRalCdbArEqLMcJkghUK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',iHQGFuWSVjfRalCdbArEqLMcJkghUv.get('icon')) 
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img=iHQGFuWSVjfRalCdbArEqLMcJkghUK,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghUy,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz,isLink=iHQGFuWSVjfRalCdbArEqLMcJkghUY)
  xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIN)
 def dp_Search_Group(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  if 'search_key' in args:
   iHQGFuWSVjfRalCdbArEqLMcJkghUB=args.get('search_key')
  else:
   iHQGFuWSVjfRalCdbArEqLMcJkghUB=iHQGFuWSVjfRalCdbArEqLMcJkghox.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not iHQGFuWSVjfRalCdbArEqLMcJkghUB:
    return
  for iHQGFuWSVjfRalCdbArEqLMcJkghUN in iHQGFuWSVjfRalCdbArEqLMcJkghop:
   iHQGFuWSVjfRalCdbArEqLMcJkghUt =iHQGFuWSVjfRalCdbArEqLMcJkghUN.get('mode')
   iHQGFuWSVjfRalCdbArEqLMcJkghUO=iHQGFuWSVjfRalCdbArEqLMcJkghUN.get('sType')
   iHQGFuWSVjfRalCdbArEqLMcJkghUm=iHQGFuWSVjfRalCdbArEqLMcJkghUN.get('title')
   (iHQGFuWSVjfRalCdbArEqLMcJkghUw,iHQGFuWSVjfRalCdbArEqLMcJkghUs)=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_Search_List(iHQGFuWSVjfRalCdbArEqLMcJkghUB,iHQGFuWSVjfRalCdbArEqLMcJkghUO,1,exclusion21=iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_exclusion21())
   iHQGFuWSVjfRalCdbArEqLMcJkghno={'plot':'검색어 : '+iHQGFuWSVjfRalCdbArEqLMcJkghUB+'\n\n'+iHQGFuWSVjfRalCdbArEqLMcJkghox.Search_FreeList(iHQGFuWSVjfRalCdbArEqLMcJkghUw)}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':iHQGFuWSVjfRalCdbArEqLMcJkghUt,'sType':iHQGFuWSVjfRalCdbArEqLMcJkghUO,'search_key':iHQGFuWSVjfRalCdbArEqLMcJkghUB,'page':'1',}
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img='',infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghno,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghIs(iHQGFuWSVjfRalCdbArEqLMcJkghop)>0:xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIN)
  iHQGFuWSVjfRalCdbArEqLMcJkghox.Save_Searched_List(iHQGFuWSVjfRalCdbArEqLMcJkghUB)
 def Search_FreeList(iHQGFuWSVjfRalCdbArEqLMcJkghox,search_list):
  iHQGFuWSVjfRalCdbArEqLMcJkghnU=''
  iHQGFuWSVjfRalCdbArEqLMcJkghnp=7
  try:
   if iHQGFuWSVjfRalCdbArEqLMcJkghIs(search_list)==0:return '검색결과 없음'
   for i in iHQGFuWSVjfRalCdbArEqLMcJkghxo(iHQGFuWSVjfRalCdbArEqLMcJkghIs(search_list)):
    if i>=iHQGFuWSVjfRalCdbArEqLMcJkghnp:
     iHQGFuWSVjfRalCdbArEqLMcJkghnU=iHQGFuWSVjfRalCdbArEqLMcJkghnU+'...'
     break
    iHQGFuWSVjfRalCdbArEqLMcJkghnU=iHQGFuWSVjfRalCdbArEqLMcJkghnU+search_list[i]['title']+'\n'
  except:
   return ''
  return iHQGFuWSVjfRalCdbArEqLMcJkghnU
 def dp_Watch_Group(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  for iHQGFuWSVjfRalCdbArEqLMcJkghnT in iHQGFuWSVjfRalCdbArEqLMcJkghoT:
   iHQGFuWSVjfRalCdbArEqLMcJkghUm=iHQGFuWSVjfRalCdbArEqLMcJkghnT.get('title')
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':iHQGFuWSVjfRalCdbArEqLMcJkghnT.get('mode'),'sType':iHQGFuWSVjfRalCdbArEqLMcJkghnT.get('sType')}
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img='',infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghIs(iHQGFuWSVjfRalCdbArEqLMcJkghoT)>0:xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIN)
 def dp_Search_History(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghnP=iHQGFuWSVjfRalCdbArEqLMcJkghox.Load_List_File('search')
  for iHQGFuWSVjfRalCdbArEqLMcJkghnI in iHQGFuWSVjfRalCdbArEqLMcJkghnP:
   iHQGFuWSVjfRalCdbArEqLMcJkghnx=iHQGFuWSVjfRalCdbArEqLMcJkghIw(urllib.parse.parse_qsl(iHQGFuWSVjfRalCdbArEqLMcJkghnI))
   iHQGFuWSVjfRalCdbArEqLMcJkghnm=iHQGFuWSVjfRalCdbArEqLMcJkghnx.get('skey').strip()
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'SEARCH_GROUP','search_key':iHQGFuWSVjfRalCdbArEqLMcJkghnm,}
   iHQGFuWSVjfRalCdbArEqLMcJkghnD={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':iHQGFuWSVjfRalCdbArEqLMcJkghnm,'vType':'-',}
   iHQGFuWSVjfRalCdbArEqLMcJkghnv=urllib.parse.urlencode(iHQGFuWSVjfRalCdbArEqLMcJkghnD)
   iHQGFuWSVjfRalCdbArEqLMcJkghnK=[('선택된 검색어 ( %s ) 삭제'%(iHQGFuWSVjfRalCdbArEqLMcJkghnm),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghnv))]
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghnm,sublabel='',img=iHQGFuWSVjfRalCdbArEqLMcJkghIe,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz,ContextMenu=iHQGFuWSVjfRalCdbArEqLMcJkghnK)
  iHQGFuWSVjfRalCdbArEqLMcJkghnz={'plot':'검색목록 전체를 삭제합니다.'}
  iHQGFuWSVjfRalCdbArEqLMcJkghUm='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  iHQGFuWSVjfRalCdbArEqLMcJkghUK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img=iHQGFuWSVjfRalCdbArEqLMcJkghUK,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIt,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz,isLink=iHQGFuWSVjfRalCdbArEqLMcJkghIN)
  xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_Search_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghUO =args.get('sType')
  iHQGFuWSVjfRalCdbArEqLMcJkghny =iHQGFuWSVjfRalCdbArEqLMcJkghIB(args.get('page'))
  if 'search_key' in args:
   iHQGFuWSVjfRalCdbArEqLMcJkghUB=args.get('search_key')
  else:
   iHQGFuWSVjfRalCdbArEqLMcJkghUB=iHQGFuWSVjfRalCdbArEqLMcJkghox.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not iHQGFuWSVjfRalCdbArEqLMcJkghUB:
    xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle)
    return
  iHQGFuWSVjfRalCdbArEqLMcJkghnY,iHQGFuWSVjfRalCdbArEqLMcJkghUs=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_Search_List(iHQGFuWSVjfRalCdbArEqLMcJkghUB,iHQGFuWSVjfRalCdbArEqLMcJkghUO,iHQGFuWSVjfRalCdbArEqLMcJkghny,exclusion21=iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_exclusion21())
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   iHQGFuWSVjfRalCdbArEqLMcJkghne =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('videoid')
   iHQGFuWSVjfRalCdbArEqLMcJkghnB =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('vidtype')
   iHQGFuWSVjfRalCdbArEqLMcJkghUm =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('title')
   iHQGFuWSVjfRalCdbArEqLMcJkghnN=iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('thumbnail')
   iHQGFuWSVjfRalCdbArEqLMcJkghnt =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('age')
   if iHQGFuWSVjfRalCdbArEqLMcJkghnt=='18' or iHQGFuWSVjfRalCdbArEqLMcJkghnt=='19' or iHQGFuWSVjfRalCdbArEqLMcJkghnt=='21':iHQGFuWSVjfRalCdbArEqLMcJkghUm+=' (%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghnt)
   iHQGFuWSVjfRalCdbArEqLMcJkghnz={'mediatype':'tvshow' if iHQGFuWSVjfRalCdbArEqLMcJkghUO=='vod' else 'movie','mpaa':iHQGFuWSVjfRalCdbArEqLMcJkghnt,'title':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'plot':iHQGFuWSVjfRalCdbArEqLMcJkghUm}
   if iHQGFuWSVjfRalCdbArEqLMcJkghUO=='vod':
    iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'EPISODE_LIST','videoid':iHQGFuWSVjfRalCdbArEqLMcJkghne,'vidtype':iHQGFuWSVjfRalCdbArEqLMcJkghnB,'page':'1'}
    iHQGFuWSVjfRalCdbArEqLMcJkghUy=iHQGFuWSVjfRalCdbArEqLMcJkghIN
   else:
    iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'MOVIE','contentid':iHQGFuWSVjfRalCdbArEqLMcJkghne,'title':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'thumbnail':iHQGFuWSVjfRalCdbArEqLMcJkghnN,'age':iHQGFuWSVjfRalCdbArEqLMcJkghnt}
    iHQGFuWSVjfRalCdbArEqLMcJkghUy=iHQGFuWSVjfRalCdbArEqLMcJkghIt
   iHQGFuWSVjfRalCdbArEqLMcJkghnK=[]
   iHQGFuWSVjfRalCdbArEqLMcJkghnO={'mode':'VIEW_DETAIL','values':{'videoid':iHQGFuWSVjfRalCdbArEqLMcJkghne,'vidtype':'tvshow' if iHQGFuWSVjfRalCdbArEqLMcJkghUO=='vod' else 'movie','contenttype':iHQGFuWSVjfRalCdbArEqLMcJkghnB,}}
   iHQGFuWSVjfRalCdbArEqLMcJkghnw=json.dumps(iHQGFuWSVjfRalCdbArEqLMcJkghnO,separators=(',',':'))
   iHQGFuWSVjfRalCdbArEqLMcJkghnw=base64.standard_b64encode(iHQGFuWSVjfRalCdbArEqLMcJkghnw.encode()).decode('utf-8')
   iHQGFuWSVjfRalCdbArEqLMcJkghnw=iHQGFuWSVjfRalCdbArEqLMcJkghnw.replace('+','%2B')
   iHQGFuWSVjfRalCdbArEqLMcJkghns='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghnw)
   iHQGFuWSVjfRalCdbArEqLMcJkghnK.append(('상세정보 조회',iHQGFuWSVjfRalCdbArEqLMcJkghns))
   if iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_makebookmark():
    iHQGFuWSVjfRalCdbArEqLMcJkghnO={'videoid':iHQGFuWSVjfRalCdbArEqLMcJkghne,'vidtype':'tvshow' if iHQGFuWSVjfRalCdbArEqLMcJkghUO=='vod' else 'movie','vtitle':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'vsubtitle':'','contenttype':iHQGFuWSVjfRalCdbArEqLMcJkghnB,}
    iHQGFuWSVjfRalCdbArEqLMcJkghpo=json.dumps(iHQGFuWSVjfRalCdbArEqLMcJkghnO)
    iHQGFuWSVjfRalCdbArEqLMcJkghpo=urllib.parse.quote(iHQGFuWSVjfRalCdbArEqLMcJkghpo)
    iHQGFuWSVjfRalCdbArEqLMcJkghns='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghpo)
    iHQGFuWSVjfRalCdbArEqLMcJkghnK.append(('(통합) 찜 영상에 추가',iHQGFuWSVjfRalCdbArEqLMcJkghns))
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img=iHQGFuWSVjfRalCdbArEqLMcJkghnN,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghUy,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz,ContextMenu=iHQGFuWSVjfRalCdbArEqLMcJkghnK)
  if iHQGFuWSVjfRalCdbArEqLMcJkghUs:
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['mode'] ='SEARCH_LIST' 
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['sType']=iHQGFuWSVjfRalCdbArEqLMcJkghUO 
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['page'] =iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['search_key']=iHQGFuWSVjfRalCdbArEqLMcJkghUB
   iHQGFuWSVjfRalCdbArEqLMcJkghUm='[B]%s >>[/B]'%'다음 페이지'
   iHQGFuWSVjfRalCdbArEqLMcJkghpU=iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghpU,img=iHQGFuWSVjfRalCdbArEqLMcJkghUK,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghUO=='movie':xbmcplugin.setContent(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,'movies')
  else:xbmcplugin.setContent(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_Watch_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghUO =args.get('sType')
  iHQGFuWSVjfRalCdbArEqLMcJkghUP=iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_direct_replay()
  iHQGFuWSVjfRalCdbArEqLMcJkghnY=iHQGFuWSVjfRalCdbArEqLMcJkghox.Load_List_File(iHQGFuWSVjfRalCdbArEqLMcJkghUO)
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   iHQGFuWSVjfRalCdbArEqLMcJkghnx=iHQGFuWSVjfRalCdbArEqLMcJkghIw(urllib.parse.parse_qsl(iHQGFuWSVjfRalCdbArEqLMcJkghnX))
   iHQGFuWSVjfRalCdbArEqLMcJkghpn =iHQGFuWSVjfRalCdbArEqLMcJkghnx.get('code').strip()
   iHQGFuWSVjfRalCdbArEqLMcJkghUm =iHQGFuWSVjfRalCdbArEqLMcJkghnx.get('title').strip()
   iHQGFuWSVjfRalCdbArEqLMcJkghpU =iHQGFuWSVjfRalCdbArEqLMcJkghnx.get('subtitle').strip()
   if iHQGFuWSVjfRalCdbArEqLMcJkghpU=='None':iHQGFuWSVjfRalCdbArEqLMcJkghpU=''
   iHQGFuWSVjfRalCdbArEqLMcJkghnN=iHQGFuWSVjfRalCdbArEqLMcJkghnx.get('img').strip()
   iHQGFuWSVjfRalCdbArEqLMcJkghne =iHQGFuWSVjfRalCdbArEqLMcJkghnx.get('videoid').strip()
   try:
    iHQGFuWSVjfRalCdbArEqLMcJkghnN=iHQGFuWSVjfRalCdbArEqLMcJkghnN.replace('\'','\"')
    iHQGFuWSVjfRalCdbArEqLMcJkghnN=json.loads(iHQGFuWSVjfRalCdbArEqLMcJkghnN)
   except:
    iHQGFuWSVjfRalCdbArEqLMcJkghIe
   iHQGFuWSVjfRalCdbArEqLMcJkghnz={'plot':'%s\n%s'%(iHQGFuWSVjfRalCdbArEqLMcJkghUm,iHQGFuWSVjfRalCdbArEqLMcJkghpU)}
   if iHQGFuWSVjfRalCdbArEqLMcJkghUO=='vod':
    if iHQGFuWSVjfRalCdbArEqLMcJkghUP==iHQGFuWSVjfRalCdbArEqLMcJkghIt or iHQGFuWSVjfRalCdbArEqLMcJkghne==iHQGFuWSVjfRalCdbArEqLMcJkghIe:
     iHQGFuWSVjfRalCdbArEqLMcJkghnz['mediatype']='tvshow'
     iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'EPISODE_LIST','videoid':iHQGFuWSVjfRalCdbArEqLMcJkghpn,'vidtype':'programid','page':'1'}
     iHQGFuWSVjfRalCdbArEqLMcJkghUy=iHQGFuWSVjfRalCdbArEqLMcJkghIN
    else:
     iHQGFuWSVjfRalCdbArEqLMcJkghnz['mediatype']='episode'
     iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'VOD','programid':iHQGFuWSVjfRalCdbArEqLMcJkghpn,'contentid':iHQGFuWSVjfRalCdbArEqLMcJkghne,'title':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'subtitle':iHQGFuWSVjfRalCdbArEqLMcJkghpU,'thumbnail':iHQGFuWSVjfRalCdbArEqLMcJkghnN}
     iHQGFuWSVjfRalCdbArEqLMcJkghUy=iHQGFuWSVjfRalCdbArEqLMcJkghIt
   else:
    iHQGFuWSVjfRalCdbArEqLMcJkghnz['mediatype']='movie'
    iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'MOVIE','contentid':iHQGFuWSVjfRalCdbArEqLMcJkghpn,'title':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'subtitle':iHQGFuWSVjfRalCdbArEqLMcJkghpU,'thumbnail':iHQGFuWSVjfRalCdbArEqLMcJkghnN}
    iHQGFuWSVjfRalCdbArEqLMcJkghUy=iHQGFuWSVjfRalCdbArEqLMcJkghIt
   iHQGFuWSVjfRalCdbArEqLMcJkghnD={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':iHQGFuWSVjfRalCdbArEqLMcJkghpn,'vType':iHQGFuWSVjfRalCdbArEqLMcJkghUO,}
   iHQGFuWSVjfRalCdbArEqLMcJkghnv=urllib.parse.urlencode(iHQGFuWSVjfRalCdbArEqLMcJkghnD)
   iHQGFuWSVjfRalCdbArEqLMcJkghnK=[('선택된 시청이력 ( %s ) 삭제'%(iHQGFuWSVjfRalCdbArEqLMcJkghUm),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghnv))]
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghpU,img=iHQGFuWSVjfRalCdbArEqLMcJkghnN,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghUy,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz,ContextMenu=iHQGFuWSVjfRalCdbArEqLMcJkghnK)
  iHQGFuWSVjfRalCdbArEqLMcJkghnz={'plot':'시청목록을 삭제합니다.'}
  iHQGFuWSVjfRalCdbArEqLMcJkghUm='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':iHQGFuWSVjfRalCdbArEqLMcJkghUO,}
  iHQGFuWSVjfRalCdbArEqLMcJkghUK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img=iHQGFuWSVjfRalCdbArEqLMcJkghUK,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIt,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz,isLink=iHQGFuWSVjfRalCdbArEqLMcJkghIN)
  if iHQGFuWSVjfRalCdbArEqLMcJkghUO=='movie':xbmcplugin.setContent(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,'movies')
  else:xbmcplugin.setContent(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def Load_List_File(iHQGFuWSVjfRalCdbArEqLMcJkghox,stype): 
  try:
   if stype=='search':
    iHQGFuWSVjfRalCdbArEqLMcJkghpT=iHQGFuWSVjfRalCdbArEqLMcJkghoI
   elif stype in['vod','movie']:
    iHQGFuWSVjfRalCdbArEqLMcJkghpT=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=iHQGFuWSVjfRalCdbArEqLMcJkghxn(iHQGFuWSVjfRalCdbArEqLMcJkghpT,'r',-1,'utf-8')
   iHQGFuWSVjfRalCdbArEqLMcJkghpP=fp.readlines()
   fp.close()
  except:
   iHQGFuWSVjfRalCdbArEqLMcJkghpP=[]
  return iHQGFuWSVjfRalCdbArEqLMcJkghpP
 def Save_Watched_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,iHQGFuWSVjfRalCdbArEqLMcJkghIo,iHQGFuWSVjfRalCdbArEqLMcJkghov):
  try:
   iHQGFuWSVjfRalCdbArEqLMcJkghpI=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%iHQGFuWSVjfRalCdbArEqLMcJkghIo))
   iHQGFuWSVjfRalCdbArEqLMcJkghpx=iHQGFuWSVjfRalCdbArEqLMcJkghox.Load_List_File(iHQGFuWSVjfRalCdbArEqLMcJkghIo) 
   fp=iHQGFuWSVjfRalCdbArEqLMcJkghxn(iHQGFuWSVjfRalCdbArEqLMcJkghpI,'w',-1,'utf-8')
   iHQGFuWSVjfRalCdbArEqLMcJkghpm=urllib.parse.urlencode(iHQGFuWSVjfRalCdbArEqLMcJkghov)
   iHQGFuWSVjfRalCdbArEqLMcJkghpm=iHQGFuWSVjfRalCdbArEqLMcJkghpm+'\n'
   fp.write(iHQGFuWSVjfRalCdbArEqLMcJkghpm)
   iHQGFuWSVjfRalCdbArEqLMcJkghpD=0
   for iHQGFuWSVjfRalCdbArEqLMcJkghpv in iHQGFuWSVjfRalCdbArEqLMcJkghpx:
    iHQGFuWSVjfRalCdbArEqLMcJkghpK=iHQGFuWSVjfRalCdbArEqLMcJkghIw(urllib.parse.parse_qsl(iHQGFuWSVjfRalCdbArEqLMcJkghpv))
    iHQGFuWSVjfRalCdbArEqLMcJkghpz=iHQGFuWSVjfRalCdbArEqLMcJkghov.get('code').strip()
    iHQGFuWSVjfRalCdbArEqLMcJkghpy=iHQGFuWSVjfRalCdbArEqLMcJkghpK.get('code').strip()
    if iHQGFuWSVjfRalCdbArEqLMcJkghIo=='vod' and iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_direct_replay()==iHQGFuWSVjfRalCdbArEqLMcJkghIN:
     iHQGFuWSVjfRalCdbArEqLMcJkghpz=iHQGFuWSVjfRalCdbArEqLMcJkghov.get('videoid').strip()
     iHQGFuWSVjfRalCdbArEqLMcJkghpy=iHQGFuWSVjfRalCdbArEqLMcJkghpK.get('videoid').strip()if iHQGFuWSVjfRalCdbArEqLMcJkghpy!=iHQGFuWSVjfRalCdbArEqLMcJkghIe else '-'
    if iHQGFuWSVjfRalCdbArEqLMcJkghpz!=iHQGFuWSVjfRalCdbArEqLMcJkghpy:
     fp.write(iHQGFuWSVjfRalCdbArEqLMcJkghpv)
     iHQGFuWSVjfRalCdbArEqLMcJkghpD+=1
     if iHQGFuWSVjfRalCdbArEqLMcJkghpD>=50:break
   fp.close()
  except:
   iHQGFuWSVjfRalCdbArEqLMcJkghIe
 def dp_History_Remove(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghpY=args.get('delType')
  iHQGFuWSVjfRalCdbArEqLMcJkghpX =args.get('sKey')
  iHQGFuWSVjfRalCdbArEqLMcJkghpe =args.get('vType')
  iHQGFuWSVjfRalCdbArEqLMcJkghoz=xbmcgui.Dialog()
  if iHQGFuWSVjfRalCdbArEqLMcJkghpY=='SEARCH_ALL':
   iHQGFuWSVjfRalCdbArEqLMcJkghpB=iHQGFuWSVjfRalCdbArEqLMcJkghoz.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif iHQGFuWSVjfRalCdbArEqLMcJkghpY=='SEARCH_ONE':
   iHQGFuWSVjfRalCdbArEqLMcJkghpB=iHQGFuWSVjfRalCdbArEqLMcJkghoz.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif iHQGFuWSVjfRalCdbArEqLMcJkghpY=='WATCH_ALL':
   iHQGFuWSVjfRalCdbArEqLMcJkghpB=iHQGFuWSVjfRalCdbArEqLMcJkghoz.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif iHQGFuWSVjfRalCdbArEqLMcJkghpY=='WATCH_ONE':
   iHQGFuWSVjfRalCdbArEqLMcJkghpB=iHQGFuWSVjfRalCdbArEqLMcJkghoz.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if iHQGFuWSVjfRalCdbArEqLMcJkghpB==iHQGFuWSVjfRalCdbArEqLMcJkghIt:sys.exit()
  if iHQGFuWSVjfRalCdbArEqLMcJkghpY=='SEARCH_ALL':
   if os.path.isfile(iHQGFuWSVjfRalCdbArEqLMcJkghoI):os.remove(iHQGFuWSVjfRalCdbArEqLMcJkghoI)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghpY=='SEARCH_ONE':
   try:
    iHQGFuWSVjfRalCdbArEqLMcJkghpT=iHQGFuWSVjfRalCdbArEqLMcJkghoI
    iHQGFuWSVjfRalCdbArEqLMcJkghpx=iHQGFuWSVjfRalCdbArEqLMcJkghox.Load_List_File('search') 
    fp=iHQGFuWSVjfRalCdbArEqLMcJkghxn(iHQGFuWSVjfRalCdbArEqLMcJkghpT,'w',-1,'utf-8')
    for iHQGFuWSVjfRalCdbArEqLMcJkghpv in iHQGFuWSVjfRalCdbArEqLMcJkghpx:
     iHQGFuWSVjfRalCdbArEqLMcJkghpK=iHQGFuWSVjfRalCdbArEqLMcJkghIw(urllib.parse.parse_qsl(iHQGFuWSVjfRalCdbArEqLMcJkghpv))
     iHQGFuWSVjfRalCdbArEqLMcJkghpN=iHQGFuWSVjfRalCdbArEqLMcJkghpK.get('skey').strip()
     if iHQGFuWSVjfRalCdbArEqLMcJkghpX!=iHQGFuWSVjfRalCdbArEqLMcJkghpN:
      fp.write(iHQGFuWSVjfRalCdbArEqLMcJkghpv)
    fp.close()
   except:
    iHQGFuWSVjfRalCdbArEqLMcJkghIe
  elif iHQGFuWSVjfRalCdbArEqLMcJkghpY=='WATCH_ALL':
   iHQGFuWSVjfRalCdbArEqLMcJkghpT=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%iHQGFuWSVjfRalCdbArEqLMcJkghpe))
   if os.path.isfile(iHQGFuWSVjfRalCdbArEqLMcJkghpT):os.remove(iHQGFuWSVjfRalCdbArEqLMcJkghpT)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghpY=='WATCH_ONE':
   iHQGFuWSVjfRalCdbArEqLMcJkghpT=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%iHQGFuWSVjfRalCdbArEqLMcJkghpe))
   try:
    iHQGFuWSVjfRalCdbArEqLMcJkghpx=iHQGFuWSVjfRalCdbArEqLMcJkghox.Load_List_File(iHQGFuWSVjfRalCdbArEqLMcJkghpe) 
    fp=iHQGFuWSVjfRalCdbArEqLMcJkghxn(iHQGFuWSVjfRalCdbArEqLMcJkghpT,'w',-1,'utf-8')
    for iHQGFuWSVjfRalCdbArEqLMcJkghpv in iHQGFuWSVjfRalCdbArEqLMcJkghpx:
     iHQGFuWSVjfRalCdbArEqLMcJkghpK=iHQGFuWSVjfRalCdbArEqLMcJkghIw(urllib.parse.parse_qsl(iHQGFuWSVjfRalCdbArEqLMcJkghpv))
     iHQGFuWSVjfRalCdbArEqLMcJkghpN=iHQGFuWSVjfRalCdbArEqLMcJkghpK.get('code').strip()
     if iHQGFuWSVjfRalCdbArEqLMcJkghpX!=iHQGFuWSVjfRalCdbArEqLMcJkghpN:
      fp.write(iHQGFuWSVjfRalCdbArEqLMcJkghpv)
    fp.close()
   except:
    iHQGFuWSVjfRalCdbArEqLMcJkghIe
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,iHQGFuWSVjfRalCdbArEqLMcJkghUB):
  try:
   iHQGFuWSVjfRalCdbArEqLMcJkghpt=iHQGFuWSVjfRalCdbArEqLMcJkghoI
   iHQGFuWSVjfRalCdbArEqLMcJkghpx=iHQGFuWSVjfRalCdbArEqLMcJkghox.Load_List_File('search') 
   iHQGFuWSVjfRalCdbArEqLMcJkghpO={'skey':iHQGFuWSVjfRalCdbArEqLMcJkghUB.strip()}
   fp=iHQGFuWSVjfRalCdbArEqLMcJkghxn(iHQGFuWSVjfRalCdbArEqLMcJkghpt,'w',-1,'utf-8')
   iHQGFuWSVjfRalCdbArEqLMcJkghpm=urllib.parse.urlencode(iHQGFuWSVjfRalCdbArEqLMcJkghpO)
   iHQGFuWSVjfRalCdbArEqLMcJkghpm=iHQGFuWSVjfRalCdbArEqLMcJkghpm+'\n'
   fp.write(iHQGFuWSVjfRalCdbArEqLMcJkghpm)
   iHQGFuWSVjfRalCdbArEqLMcJkghpD=0
   for iHQGFuWSVjfRalCdbArEqLMcJkghpv in iHQGFuWSVjfRalCdbArEqLMcJkghpx:
    iHQGFuWSVjfRalCdbArEqLMcJkghpK=iHQGFuWSVjfRalCdbArEqLMcJkghIw(urllib.parse.parse_qsl(iHQGFuWSVjfRalCdbArEqLMcJkghpv))
    iHQGFuWSVjfRalCdbArEqLMcJkghpz=iHQGFuWSVjfRalCdbArEqLMcJkghpO.get('skey').strip()
    iHQGFuWSVjfRalCdbArEqLMcJkghpy=iHQGFuWSVjfRalCdbArEqLMcJkghpK.get('skey').strip()
    if iHQGFuWSVjfRalCdbArEqLMcJkghpz!=iHQGFuWSVjfRalCdbArEqLMcJkghpy:
     fp.write(iHQGFuWSVjfRalCdbArEqLMcJkghpv)
     iHQGFuWSVjfRalCdbArEqLMcJkghpD+=1
     if iHQGFuWSVjfRalCdbArEqLMcJkghpD>=50:break
   fp.close()
  except:
   iHQGFuWSVjfRalCdbArEqLMcJkghIe
 def dp_Global_Search(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghUt=args.get('mode')
  if iHQGFuWSVjfRalCdbArEqLMcJkghUt=='TOTAL_SEARCH':
   iHQGFuWSVjfRalCdbArEqLMcJkghpw='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   iHQGFuWSVjfRalCdbArEqLMcJkghpw='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(iHQGFuWSVjfRalCdbArEqLMcJkghpw)
 def dp_Bookmark_Menu(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghpw='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(iHQGFuWSVjfRalCdbArEqLMcJkghpw)
 def login_main(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  (iHQGFuWSVjfRalCdbArEqLMcJkghps,iHQGFuWSVjfRalCdbArEqLMcJkghTo,iHQGFuWSVjfRalCdbArEqLMcJkghTU)=iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_account()
  if not(iHQGFuWSVjfRalCdbArEqLMcJkghps and iHQGFuWSVjfRalCdbArEqLMcJkghTo):
   iHQGFuWSVjfRalCdbArEqLMcJkghoz=xbmcgui.Dialog()
   iHQGFuWSVjfRalCdbArEqLMcJkghpB=iHQGFuWSVjfRalCdbArEqLMcJkghoz.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if iHQGFuWSVjfRalCdbArEqLMcJkghpB==iHQGFuWSVjfRalCdbArEqLMcJkghIN:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if iHQGFuWSVjfRalCdbArEqLMcJkghox.cookiefile_check()==iHQGFuWSVjfRalCdbArEqLMcJkghIN:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   iHQGFuWSVjfRalCdbArEqLMcJkghTn=0
   while iHQGFuWSVjfRalCdbArEqLMcJkghIN:
    iHQGFuWSVjfRalCdbArEqLMcJkghTn+=1
    time.sleep(0.05)
    if iHQGFuWSVjfRalCdbArEqLMcJkghTn>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  iHQGFuWSVjfRalCdbArEqLMcJkghTp=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.GetCredential(iHQGFuWSVjfRalCdbArEqLMcJkghps,iHQGFuWSVjfRalCdbArEqLMcJkghTo,iHQGFuWSVjfRalCdbArEqLMcJkghTU)
  if iHQGFuWSVjfRalCdbArEqLMcJkghTp:iHQGFuWSVjfRalCdbArEqLMcJkghox.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if iHQGFuWSVjfRalCdbArEqLMcJkghTp==iHQGFuWSVjfRalCdbArEqLMcJkghIt:
   iHQGFuWSVjfRalCdbArEqLMcJkghox.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghUI =args.get('orderby')
  iHQGFuWSVjfRalCdbArEqLMcJkghox.set_winEpisodeOrderby(iHQGFuWSVjfRalCdbArEqLMcJkghUI)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghUt =args.get('mode')
  iHQGFuWSVjfRalCdbArEqLMcJkghTP =args.get('contentid')
  iHQGFuWSVjfRalCdbArEqLMcJkghTI =args.get('pvrmode')
  iHQGFuWSVjfRalCdbArEqLMcJkghTx=iHQGFuWSVjfRalCdbArEqLMcJkghox.get_selQuality()
  iHQGFuWSVjfRalCdbArEqLMcJkghox.addon_log(iHQGFuWSVjfRalCdbArEqLMcJkghTP+' - '+iHQGFuWSVjfRalCdbArEqLMcJkghUt)
  if iHQGFuWSVjfRalCdbArEqLMcJkghUt=='SPORTS':
   iHQGFuWSVjfRalCdbArEqLMcJkghTm=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.GetSportsURL(iHQGFuWSVjfRalCdbArEqLMcJkghTP,iHQGFuWSVjfRalCdbArEqLMcJkghTx)
  else:
   iHQGFuWSVjfRalCdbArEqLMcJkghTm=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.GetStreamingURL(iHQGFuWSVjfRalCdbArEqLMcJkghUt,iHQGFuWSVjfRalCdbArEqLMcJkghTP,iHQGFuWSVjfRalCdbArEqLMcJkghTx,iHQGFuWSVjfRalCdbArEqLMcJkghTI)
  iHQGFuWSVjfRalCdbArEqLMcJkghTD='%s|Cookie=%s'%(iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_url'],iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_cookie'])
  iHQGFuWSVjfRalCdbArEqLMcJkghox.addon_log(iHQGFuWSVjfRalCdbArEqLMcJkghTD)
  if iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_url']=='':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.addon_noti(__language__(30907).encode('utf8'))
   return
  iHQGFuWSVjfRalCdbArEqLMcJkghTv=xbmcgui.ListItem(path=iHQGFuWSVjfRalCdbArEqLMcJkghTD)
  if iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_drm']:
   iHQGFuWSVjfRalCdbArEqLMcJkghox.addon_log('!!streaming_drm!!')
   iHQGFuWSVjfRalCdbArEqLMcJkghTK=iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_drm']['customdata']
   iHQGFuWSVjfRalCdbArEqLMcJkghTz =iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_drm']['drmhost']
   iHQGFuWSVjfRalCdbArEqLMcJkghTy =inputstreamhelper.Helper('mpd',drm='widevine')
   if iHQGFuWSVjfRalCdbArEqLMcJkghTy.check_inputstream():
    if iHQGFuWSVjfRalCdbArEqLMcJkghUt=='MOVIE':
     iHQGFuWSVjfRalCdbArEqLMcJkghTY='https://www.wavve.com/player/movie?movieid=%s'%iHQGFuWSVjfRalCdbArEqLMcJkghTP
    else:
     iHQGFuWSVjfRalCdbArEqLMcJkghTY='https://www.wavve.com/player/vod?programid=%s&page=1'%iHQGFuWSVjfRalCdbArEqLMcJkghTP
    iHQGFuWSVjfRalCdbArEqLMcJkghTX={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':iHQGFuWSVjfRalCdbArEqLMcJkghTK,'referer':iHQGFuWSVjfRalCdbArEqLMcJkghTY,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.USER_AGENT}
    iHQGFuWSVjfRalCdbArEqLMcJkghTe=iHQGFuWSVjfRalCdbArEqLMcJkghTz+'|'+urllib.parse.urlencode(iHQGFuWSVjfRalCdbArEqLMcJkghTX)+'|R{SSM}|'
    iHQGFuWSVjfRalCdbArEqLMcJkghTv.setProperty('inputstream',iHQGFuWSVjfRalCdbArEqLMcJkghTy.inputstream_addon)
    iHQGFuWSVjfRalCdbArEqLMcJkghTv.setProperty('inputstream.adaptive.manifest_type','mpd')
    iHQGFuWSVjfRalCdbArEqLMcJkghTv.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    iHQGFuWSVjfRalCdbArEqLMcJkghTv.setProperty('inputstream.adaptive.license_key',iHQGFuWSVjfRalCdbArEqLMcJkghTe)
    iHQGFuWSVjfRalCdbArEqLMcJkghTv.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.USER_AGENT,iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_cookie']))
  if iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_vtt']:
   iHQGFuWSVjfRalCdbArEqLMcJkghTv.setSubtitles([iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_vtt']])
  xbmcplugin.setResolvedUrl(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,iHQGFuWSVjfRalCdbArEqLMcJkghIN,iHQGFuWSVjfRalCdbArEqLMcJkghTv)
  iHQGFuWSVjfRalCdbArEqLMcJkghTB=iHQGFuWSVjfRalCdbArEqLMcJkghIt
  if iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_preview']:
   iHQGFuWSVjfRalCdbArEqLMcJkghox.addon_noti(iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_preview'].encode('utf-8'))
   iHQGFuWSVjfRalCdbArEqLMcJkghTB=iHQGFuWSVjfRalCdbArEqLMcJkghIN
  else:
   if '/preview.' in urllib.parse.urlsplit(iHQGFuWSVjfRalCdbArEqLMcJkghTm['stream_url']).path:
    iHQGFuWSVjfRalCdbArEqLMcJkghox.addon_noti(__language__(30908).encode('utf8'))
    iHQGFuWSVjfRalCdbArEqLMcJkghTB=iHQGFuWSVjfRalCdbArEqLMcJkghIN
  try:
   iHQGFuWSVjfRalCdbArEqLMcJkghTN=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and iHQGFuWSVjfRalCdbArEqLMcJkghTB==iHQGFuWSVjfRalCdbArEqLMcJkghIt and iHQGFuWSVjfRalCdbArEqLMcJkghTN!='-':
    iHQGFuWSVjfRalCdbArEqLMcJkghUz={'code':iHQGFuWSVjfRalCdbArEqLMcJkghTN,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    iHQGFuWSVjfRalCdbArEqLMcJkghox.Save_Watched_List(args.get('mode').lower(),iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  except:
   iHQGFuWSVjfRalCdbArEqLMcJkghIe
 def logout(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  iHQGFuWSVjfRalCdbArEqLMcJkghoz=xbmcgui.Dialog()
  iHQGFuWSVjfRalCdbArEqLMcJkghpB=iHQGFuWSVjfRalCdbArEqLMcJkghoz.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if iHQGFuWSVjfRalCdbArEqLMcJkghpB==iHQGFuWSVjfRalCdbArEqLMcJkghIt:sys.exit()
  iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Init_WV_Total()
  if os.path.isfile(iHQGFuWSVjfRalCdbArEqLMcJkghoP):os.remove(iHQGFuWSVjfRalCdbArEqLMcJkghoP)
  iHQGFuWSVjfRalCdbArEqLMcJkghox.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  iHQGFuWSVjfRalCdbArEqLMcJkghTt =iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_Now_Datetime()
  iHQGFuWSVjfRalCdbArEqLMcJkghTO=iHQGFuWSVjfRalCdbArEqLMcJkghTt+datetime.timedelta(days=iHQGFuWSVjfRalCdbArEqLMcJkghIB(__addon__.getSetting('cache_ttl')))
  (iHQGFuWSVjfRalCdbArEqLMcJkghps,iHQGFuWSVjfRalCdbArEqLMcJkghTo,iHQGFuWSVjfRalCdbArEqLMcJkghTU)=iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_account()
  iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Save_session_acount(iHQGFuWSVjfRalCdbArEqLMcJkghps,iHQGFuWSVjfRalCdbArEqLMcJkghTo,iHQGFuWSVjfRalCdbArEqLMcJkghTU)
  iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.WV['account']['token_limit']=iHQGFuWSVjfRalCdbArEqLMcJkghTO.strftime('%Y%m%d')
  iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.JsonFile_Save(iHQGFuWSVjfRalCdbArEqLMcJkghoP,iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.WV)
 def cookiefile_check(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.WV=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.JsonFile_Load(iHQGFuWSVjfRalCdbArEqLMcJkghoP)
  if 'account' not in iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.WV:
   iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Init_WV_Total()
   return iHQGFuWSVjfRalCdbArEqLMcJkghIt
  (iHQGFuWSVjfRalCdbArEqLMcJkghTw,iHQGFuWSVjfRalCdbArEqLMcJkghTs,iHQGFuWSVjfRalCdbArEqLMcJkghPo)=iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_account()
  (iHQGFuWSVjfRalCdbArEqLMcJkghPU,iHQGFuWSVjfRalCdbArEqLMcJkghPn,iHQGFuWSVjfRalCdbArEqLMcJkghPp)=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Load_session_acount()
  if iHQGFuWSVjfRalCdbArEqLMcJkghTw!=iHQGFuWSVjfRalCdbArEqLMcJkghPU or iHQGFuWSVjfRalCdbArEqLMcJkghTs!=iHQGFuWSVjfRalCdbArEqLMcJkghPn or iHQGFuWSVjfRalCdbArEqLMcJkghPo!=iHQGFuWSVjfRalCdbArEqLMcJkghPp:
   iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Init_WV_Total()
   return iHQGFuWSVjfRalCdbArEqLMcJkghIt
  if iHQGFuWSVjfRalCdbArEqLMcJkghIB(iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>iHQGFuWSVjfRalCdbArEqLMcJkghIB(iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.WV['account']['token_limit']):
   iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Init_WV_Total()
   return iHQGFuWSVjfRalCdbArEqLMcJkghIt
  return iHQGFuWSVjfRalCdbArEqLMcJkghIN
 def dp_LiveCatagory_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghPT =args.get('sCode')
  iHQGFuWSVjfRalCdbArEqLMcJkghPI=args.get('sIndex')
  iHQGFuWSVjfRalCdbArEqLMcJkghnY,iHQGFuWSVjfRalCdbArEqLMcJkghPx=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_LiveCatagory_List(iHQGFuWSVjfRalCdbArEqLMcJkghPT,iHQGFuWSVjfRalCdbArEqLMcJkghPI)
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   iHQGFuWSVjfRalCdbArEqLMcJkghUm =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('title')
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'LIVE_LIST','genre':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('genre'),'baseapi':iHQGFuWSVjfRalCdbArEqLMcJkghPx}
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img='',infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghIs(iHQGFuWSVjfRalCdbArEqLMcJkghnY)>0:xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_MainCatagory_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghPT =args.get('sCode')
  iHQGFuWSVjfRalCdbArEqLMcJkghPI=args.get('sIndex')
  iHQGFuWSVjfRalCdbArEqLMcJkghUO =args.get('sType')
  iHQGFuWSVjfRalCdbArEqLMcJkghnY=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_MainCatagory_List(iHQGFuWSVjfRalCdbArEqLMcJkghPT,iHQGFuWSVjfRalCdbArEqLMcJkghPI)
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   if iHQGFuWSVjfRalCdbArEqLMcJkghUO=='vod':
    if iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('subtype')=='catagory':
     iHQGFuWSVjfRalCdbArEqLMcJkghUt='PROGRAM_LIST'
    else:
     iHQGFuWSVjfRalCdbArEqLMcJkghUt='SUPERSECTION_LIST'
   elif iHQGFuWSVjfRalCdbArEqLMcJkghUO=='movie':
    iHQGFuWSVjfRalCdbArEqLMcJkghUt='MOVIE_LIST'
   else:
    iHQGFuWSVjfRalCdbArEqLMcJkghUt=''
   iHQGFuWSVjfRalCdbArEqLMcJkghUm='%s (%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('title'),args.get('ordernm'))
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':iHQGFuWSVjfRalCdbArEqLMcJkghUt,'suburl':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('suburl'),'subapi':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_exclusion21():
    if iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('title')=='성인' or iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('title')=='성인+' or iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('title')=='에로티시즘' or iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('title')=='19':continue
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img='',infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghIs(iHQGFuWSVjfRalCdbArEqLMcJkghnY)>0:xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_Program_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghPm =args.get('subapi')
  iHQGFuWSVjfRalCdbArEqLMcJkghny=iHQGFuWSVjfRalCdbArEqLMcJkghIB(args.get('page'))
  iHQGFuWSVjfRalCdbArEqLMcJkghUI =args.get('orderby')
  iHQGFuWSVjfRalCdbArEqLMcJkghnY,iHQGFuWSVjfRalCdbArEqLMcJkghUs=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_Program_List(iHQGFuWSVjfRalCdbArEqLMcJkghPm,iHQGFuWSVjfRalCdbArEqLMcJkghny,iHQGFuWSVjfRalCdbArEqLMcJkghUI)
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   iHQGFuWSVjfRalCdbArEqLMcJkghne =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('videoid')
   iHQGFuWSVjfRalCdbArEqLMcJkghnB =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('vidtype')
   iHQGFuWSVjfRalCdbArEqLMcJkghUm =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('title')
   iHQGFuWSVjfRalCdbArEqLMcJkghnN=iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('thumbnail')
   iHQGFuWSVjfRalCdbArEqLMcJkghnt =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('age')
   if iHQGFuWSVjfRalCdbArEqLMcJkghnt=='18' or iHQGFuWSVjfRalCdbArEqLMcJkghnt=='19' or iHQGFuWSVjfRalCdbArEqLMcJkghnt=='21':iHQGFuWSVjfRalCdbArEqLMcJkghUm+=' (%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghnt)
   iHQGFuWSVjfRalCdbArEqLMcJkghnz={'plot':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'mpaa':iHQGFuWSVjfRalCdbArEqLMcJkghnt,'mediatype':'tvshow'}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'EPISODE_LIST','videoid':iHQGFuWSVjfRalCdbArEqLMcJkghne,'vidtype':iHQGFuWSVjfRalCdbArEqLMcJkghnB,'page':'1'}
   iHQGFuWSVjfRalCdbArEqLMcJkghnK=[]
   iHQGFuWSVjfRalCdbArEqLMcJkghnO={'mode':'VIEW_DETAIL','values':{'videoid':iHQGFuWSVjfRalCdbArEqLMcJkghne,'vidtype':'tvshow','contenttype':iHQGFuWSVjfRalCdbArEqLMcJkghnB,}}
   iHQGFuWSVjfRalCdbArEqLMcJkghnw=json.dumps(iHQGFuWSVjfRalCdbArEqLMcJkghnO,separators=(',',':'))
   iHQGFuWSVjfRalCdbArEqLMcJkghnw=base64.standard_b64encode(iHQGFuWSVjfRalCdbArEqLMcJkghnw.encode()).decode('utf-8')
   iHQGFuWSVjfRalCdbArEqLMcJkghnw=iHQGFuWSVjfRalCdbArEqLMcJkghnw.replace('+','%2B')
   iHQGFuWSVjfRalCdbArEqLMcJkghns='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghnw)
   iHQGFuWSVjfRalCdbArEqLMcJkghnK.append(('상세정보 조회',iHQGFuWSVjfRalCdbArEqLMcJkghns))
   if iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_makebookmark():
    iHQGFuWSVjfRalCdbArEqLMcJkghnO={'videoid':iHQGFuWSVjfRalCdbArEqLMcJkghne,'vidtype':'tvshow','vtitle':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'vsubtitle':'','contenttype':iHQGFuWSVjfRalCdbArEqLMcJkghnB,}
    iHQGFuWSVjfRalCdbArEqLMcJkghpo=json.dumps(iHQGFuWSVjfRalCdbArEqLMcJkghnO)
    iHQGFuWSVjfRalCdbArEqLMcJkghpo=urllib.parse.quote(iHQGFuWSVjfRalCdbArEqLMcJkghpo)
    iHQGFuWSVjfRalCdbArEqLMcJkghns='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghpo)
    iHQGFuWSVjfRalCdbArEqLMcJkghnK.append(('(통합) 찜 영상에 추가',iHQGFuWSVjfRalCdbArEqLMcJkghns))
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img=iHQGFuWSVjfRalCdbArEqLMcJkghnN,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz,ContextMenu=iHQGFuWSVjfRalCdbArEqLMcJkghnK)
  if iHQGFuWSVjfRalCdbArEqLMcJkghUs:
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['mode'] ='PROGRAM_LIST' 
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['subapi']=iHQGFuWSVjfRalCdbArEqLMcJkghPm 
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['page'] =iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUm='[B]%s >>[/B]'%'다음 페이지'
   iHQGFuWSVjfRalCdbArEqLMcJkghpU=iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghpU,img=iHQGFuWSVjfRalCdbArEqLMcJkghUK,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  xbmcplugin.setContent(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,'tvshows')
  if iHQGFuWSVjfRalCdbArEqLMcJkghIs(iHQGFuWSVjfRalCdbArEqLMcJkghnY)>0:xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_SuperSection_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghPD =args.get('suburl')
  iHQGFuWSVjfRalCdbArEqLMcJkghnY=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_SuperMultiSection_List(iHQGFuWSVjfRalCdbArEqLMcJkghPD)
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   iHQGFuWSVjfRalCdbArEqLMcJkghUm =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('title')
   iHQGFuWSVjfRalCdbArEqLMcJkghPm =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('subapi')
   iHQGFuWSVjfRalCdbArEqLMcJkghPv=iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('cell_type')
   if iHQGFuWSVjfRalCdbArEqLMcJkghPm.find('mtype=svod')>=0 or iHQGFuWSVjfRalCdbArEqLMcJkghPm.find('mtype=ppv')>=0 or iHQGFuWSVjfRalCdbArEqLMcJkghPm.find('contenttype=movie')>=0:
    iHQGFuWSVjfRalCdbArEqLMcJkghUt='MOVIE_LIST'
   elif iHQGFuWSVjfRalCdbArEqLMcJkghPm.find('contenttype=program')>=0:
    iHQGFuWSVjfRalCdbArEqLMcJkghUt='PROGRAM_LIST'
   elif iHQGFuWSVjfRalCdbArEqLMcJkghPv=='band_71':
    iHQGFuWSVjfRalCdbArEqLMcJkghUt ='SUPERSECTION_LIST'
    (iHQGFuWSVjfRalCdbArEqLMcJkghPK,iHQGFuWSVjfRalCdbArEqLMcJkghPz)=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Baseapi_Parse(iHQGFuWSVjfRalCdbArEqLMcJkghPm)
    iHQGFuWSVjfRalCdbArEqLMcJkghPD=iHQGFuWSVjfRalCdbArEqLMcJkghPz.get('api')
    iHQGFuWSVjfRalCdbArEqLMcJkghPm=''
   elif iHQGFuWSVjfRalCdbArEqLMcJkghPv=='band_2':
    iHQGFuWSVjfRalCdbArEqLMcJkghUt='BAND2SECTION_LIST'
   elif iHQGFuWSVjfRalCdbArEqLMcJkghPv=='band_live':
    iHQGFuWSVjfRalCdbArEqLMcJkghUt='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',iHQGFuWSVjfRalCdbArEqLMcJkghPm):
    iHQGFuWSVjfRalCdbArEqLMcJkghUt='MOVIE_LIST'
   else:
    iHQGFuWSVjfRalCdbArEqLMcJkghUt='PROGRAM_LIST'
   iHQGFuWSVjfRalCdbArEqLMcJkghnz={'plot':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'mediatype':'tvshow'}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':iHQGFuWSVjfRalCdbArEqLMcJkghUt,'suburl':iHQGFuWSVjfRalCdbArEqLMcJkghPD,'subapi':iHQGFuWSVjfRalCdbArEqLMcJkghPm,'page':'1'}
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img=iHQGFuWSVjfRalCdbArEqLMcJkghIe,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghIs(iHQGFuWSVjfRalCdbArEqLMcJkghnY)>0:xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_BandLiveSection_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghPm =args.get('subapi')
  iHQGFuWSVjfRalCdbArEqLMcJkghny=iHQGFuWSVjfRalCdbArEqLMcJkghIB(args.get('page'))
  iHQGFuWSVjfRalCdbArEqLMcJkghnY,iHQGFuWSVjfRalCdbArEqLMcJkghUs=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_BandLiveSection_List(iHQGFuWSVjfRalCdbArEqLMcJkghPm,iHQGFuWSVjfRalCdbArEqLMcJkghny)
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   iHQGFuWSVjfRalCdbArEqLMcJkghPy =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('channelid')
   iHQGFuWSVjfRalCdbArEqLMcJkghPY =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('studio')
   iHQGFuWSVjfRalCdbArEqLMcJkghPX=iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('tvshowtitle')
   iHQGFuWSVjfRalCdbArEqLMcJkghnN =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('thumbnail')
   iHQGFuWSVjfRalCdbArEqLMcJkghnt =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('age')
   iHQGFuWSVjfRalCdbArEqLMcJkghnz={'mediatype':'tvshow','mpaa':iHQGFuWSVjfRalCdbArEqLMcJkghnt,'title':'%s < %s >'%(iHQGFuWSVjfRalCdbArEqLMcJkghPY,iHQGFuWSVjfRalCdbArEqLMcJkghPX),'tvshowtitle':iHQGFuWSVjfRalCdbArEqLMcJkghPX,'studio':iHQGFuWSVjfRalCdbArEqLMcJkghPY,'plot':iHQGFuWSVjfRalCdbArEqLMcJkghPY}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'LIVE','contentid':iHQGFuWSVjfRalCdbArEqLMcJkghPy}
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghPY,sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghPX,img=iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('thumbnail'),infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIt,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghUs:
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['mode'] ='BANDLIVESECTION_LIST' 
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['subapi']=iHQGFuWSVjfRalCdbArEqLMcJkghPm
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['page'] =iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUm='[B]%s >>[/B]'%'다음 페이지'
   iHQGFuWSVjfRalCdbArEqLMcJkghpU=iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghpU,img=iHQGFuWSVjfRalCdbArEqLMcJkghUK,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghIs(iHQGFuWSVjfRalCdbArEqLMcJkghnY)>0:xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_Band2Section_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghPm =args.get('subapi')
  iHQGFuWSVjfRalCdbArEqLMcJkghny=iHQGFuWSVjfRalCdbArEqLMcJkghIB(args.get('page'))
  iHQGFuWSVjfRalCdbArEqLMcJkghnY,iHQGFuWSVjfRalCdbArEqLMcJkghUs=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_Band2Section_List(iHQGFuWSVjfRalCdbArEqLMcJkghPm,iHQGFuWSVjfRalCdbArEqLMcJkghny)
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   iHQGFuWSVjfRalCdbArEqLMcJkghUm =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('programtitle')
   iHQGFuWSVjfRalCdbArEqLMcJkghpU =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('episodetitle')
   iHQGFuWSVjfRalCdbArEqLMcJkghnz={'plot':iHQGFuWSVjfRalCdbArEqLMcJkghUm+'\n\n'+iHQGFuWSVjfRalCdbArEqLMcJkghpU,'mpaa':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('age'),'mediatype':'episode'}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'VOD','programid':'-','contentid':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('videoid'),'thumbnail':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('thumbnail'),'title':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'subtitle':iHQGFuWSVjfRalCdbArEqLMcJkghpU}
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghpU,img=iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('thumbnail'),infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIt,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghUs:
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['mode'] ='BAND2SECTION_LIST' 
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['subapi']=iHQGFuWSVjfRalCdbArEqLMcJkghPm
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['page'] =iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUm='[B]%s >>[/B]'%'다음 페이지'
   iHQGFuWSVjfRalCdbArEqLMcJkghpU=iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghpU,img=iHQGFuWSVjfRalCdbArEqLMcJkghUK,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghIs(iHQGFuWSVjfRalCdbArEqLMcJkghnY)>0:xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_Movie_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghPm =args.get('subapi')
  iHQGFuWSVjfRalCdbArEqLMcJkghny=iHQGFuWSVjfRalCdbArEqLMcJkghIB(args.get('page'))
  iHQGFuWSVjfRalCdbArEqLMcJkghnY,iHQGFuWSVjfRalCdbArEqLMcJkghUs=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_Movie_List(iHQGFuWSVjfRalCdbArEqLMcJkghPm,iHQGFuWSVjfRalCdbArEqLMcJkghny)
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   iHQGFuWSVjfRalCdbArEqLMcJkghne =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('videoid')
   iHQGFuWSVjfRalCdbArEqLMcJkghnB =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('vidtype')
   iHQGFuWSVjfRalCdbArEqLMcJkghUm =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('title')
   iHQGFuWSVjfRalCdbArEqLMcJkghnN=iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('thumbnail')
   iHQGFuWSVjfRalCdbArEqLMcJkghnt =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('age')
   if iHQGFuWSVjfRalCdbArEqLMcJkghnt=='18' or iHQGFuWSVjfRalCdbArEqLMcJkghnt=='19' or iHQGFuWSVjfRalCdbArEqLMcJkghnt=='21':iHQGFuWSVjfRalCdbArEqLMcJkghUm+=' (%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghnt)
   iHQGFuWSVjfRalCdbArEqLMcJkghnz={'plot':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'mpaa':iHQGFuWSVjfRalCdbArEqLMcJkghnt,'mediatype':'movie'}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'MOVIE','contentid':iHQGFuWSVjfRalCdbArEqLMcJkghne,'title':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'thumbnail':iHQGFuWSVjfRalCdbArEqLMcJkghnN,'age':iHQGFuWSVjfRalCdbArEqLMcJkghnt,}
   iHQGFuWSVjfRalCdbArEqLMcJkghnK=[]
   iHQGFuWSVjfRalCdbArEqLMcJkghnO={'mode':'VIEW_DETAIL','values':{'videoid':iHQGFuWSVjfRalCdbArEqLMcJkghne,'vidtype':'movie','contenttype':iHQGFuWSVjfRalCdbArEqLMcJkghnB,}}
   iHQGFuWSVjfRalCdbArEqLMcJkghnw=json.dumps(iHQGFuWSVjfRalCdbArEqLMcJkghnO,separators=(',',':'))
   iHQGFuWSVjfRalCdbArEqLMcJkghnw=base64.standard_b64encode(iHQGFuWSVjfRalCdbArEqLMcJkghnw.encode()).decode('utf-8')
   iHQGFuWSVjfRalCdbArEqLMcJkghnw=iHQGFuWSVjfRalCdbArEqLMcJkghnw.replace('+','%2B')
   iHQGFuWSVjfRalCdbArEqLMcJkghns='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghnw)
   iHQGFuWSVjfRalCdbArEqLMcJkghnK.append(('상세정보 조회',iHQGFuWSVjfRalCdbArEqLMcJkghns))
   if iHQGFuWSVjfRalCdbArEqLMcJkghox.get_settings_makebookmark():
    iHQGFuWSVjfRalCdbArEqLMcJkghnO={'videoid':iHQGFuWSVjfRalCdbArEqLMcJkghne,'vidtype':'movie','vtitle':iHQGFuWSVjfRalCdbArEqLMcJkghUm,'vsubtitle':'','contenttype':'programid',}
    iHQGFuWSVjfRalCdbArEqLMcJkghpo=json.dumps(iHQGFuWSVjfRalCdbArEqLMcJkghnO)
    iHQGFuWSVjfRalCdbArEqLMcJkghpo=urllib.parse.quote(iHQGFuWSVjfRalCdbArEqLMcJkghpo)
    iHQGFuWSVjfRalCdbArEqLMcJkghns='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghpo)
    iHQGFuWSVjfRalCdbArEqLMcJkghnK.append(('(통합) 찜 영상에 추가',iHQGFuWSVjfRalCdbArEqLMcJkghns))
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img=iHQGFuWSVjfRalCdbArEqLMcJkghnN,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIt,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz,ContextMenu=iHQGFuWSVjfRalCdbArEqLMcJkghnK)
  if iHQGFuWSVjfRalCdbArEqLMcJkghUs:
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['mode'] ='MOVIE_LIST' 
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['subapi']=iHQGFuWSVjfRalCdbArEqLMcJkghPm 
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['page'] =iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUm='[B]%s >>[/B]'%'다음 페이지'
   iHQGFuWSVjfRalCdbArEqLMcJkghpU=iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghpU,img=iHQGFuWSVjfRalCdbArEqLMcJkghUK,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  xbmcplugin.setContent(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,'movies')
  if iHQGFuWSVjfRalCdbArEqLMcJkghIs(iHQGFuWSVjfRalCdbArEqLMcJkghnY)>0:xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_Set_Bookmark(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghPe=urllib.parse.unquote(args.get('bm_param'))
  iHQGFuWSVjfRalCdbArEqLMcJkghPe=json.loads(iHQGFuWSVjfRalCdbArEqLMcJkghPe)
  iHQGFuWSVjfRalCdbArEqLMcJkghne =iHQGFuWSVjfRalCdbArEqLMcJkghPe.get('videoid')
  iHQGFuWSVjfRalCdbArEqLMcJkghnB =iHQGFuWSVjfRalCdbArEqLMcJkghPe.get('vidtype')
  iHQGFuWSVjfRalCdbArEqLMcJkghPB =iHQGFuWSVjfRalCdbArEqLMcJkghPe.get('vtitle')
  iHQGFuWSVjfRalCdbArEqLMcJkghPN =iHQGFuWSVjfRalCdbArEqLMcJkghPe.get('vsubtitle')
  iHQGFuWSVjfRalCdbArEqLMcJkghPt=iHQGFuWSVjfRalCdbArEqLMcJkghPe.get('contenttype')
  iHQGFuWSVjfRalCdbArEqLMcJkghoz=xbmcgui.Dialog()
  iHQGFuWSVjfRalCdbArEqLMcJkghpB=iHQGFuWSVjfRalCdbArEqLMcJkghoz.yesno(__language__(30913).encode('utf8'),iHQGFuWSVjfRalCdbArEqLMcJkghPB+' \n\n'+__language__(30914))
  if iHQGFuWSVjfRalCdbArEqLMcJkghpB==iHQGFuWSVjfRalCdbArEqLMcJkghIt:return
  iHQGFuWSVjfRalCdbArEqLMcJkghPO=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.GetBookmarkInfo(iHQGFuWSVjfRalCdbArEqLMcJkghne,iHQGFuWSVjfRalCdbArEqLMcJkghnB,iHQGFuWSVjfRalCdbArEqLMcJkghPt)
  iHQGFuWSVjfRalCdbArEqLMcJkghPw=json.dumps(iHQGFuWSVjfRalCdbArEqLMcJkghPO)
  iHQGFuWSVjfRalCdbArEqLMcJkghPw=urllib.parse.quote(iHQGFuWSVjfRalCdbArEqLMcJkghPw)
  iHQGFuWSVjfRalCdbArEqLMcJkghns ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghPw)
  xbmc.executebuiltin(iHQGFuWSVjfRalCdbArEqLMcJkghns)
 def dp_Episode_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghne =args.get('videoid')
  iHQGFuWSVjfRalCdbArEqLMcJkghnB =args.get('vidtype')
  iHQGFuWSVjfRalCdbArEqLMcJkghny=iHQGFuWSVjfRalCdbArEqLMcJkghIB(args.get('page'))
  iHQGFuWSVjfRalCdbArEqLMcJkghnY,iHQGFuWSVjfRalCdbArEqLMcJkghUs=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_Episode_List(iHQGFuWSVjfRalCdbArEqLMcJkghne,iHQGFuWSVjfRalCdbArEqLMcJkghnB,iHQGFuWSVjfRalCdbArEqLMcJkghny,orderby=iHQGFuWSVjfRalCdbArEqLMcJkghox.get_winEpisodeOrderby())
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   iHQGFuWSVjfRalCdbArEqLMcJkghpU='%s회, %s(%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('episodenumber'),iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('releasedate'),iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('releaseweekday'))
   iHQGFuWSVjfRalCdbArEqLMcJkghPs ='[%s]\n\n%s'%(iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('episodetitle'),iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('synopsis'))
   iHQGFuWSVjfRalCdbArEqLMcJkghnz={'mediatype':'episode','title':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('programtitle'),'year':iHQGFuWSVjfRalCdbArEqLMcJkghIB(iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('releasedate')[:4]),'aired':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('releasedate'),'mpaa':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('age'),'episode':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('episodenumber'),'duration':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('playtime'),'plot':iHQGFuWSVjfRalCdbArEqLMcJkghPs,'cast':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('episodeactors')}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'VOD','programid':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('programid'),'contentid':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('contentid'),'thumbnail':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('thumbnail'),'title':iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('programtitle'),'subtitle':iHQGFuWSVjfRalCdbArEqLMcJkghpU}
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('programtitle'),sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghpU,img=iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('thumbnail'),infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIt,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghny==1:
   iHQGFuWSVjfRalCdbArEqLMcJkghnz={'plot':'정렬순서를 변경합니다.'}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['mode'] ='ORDER_BY' 
   if iHQGFuWSVjfRalCdbArEqLMcJkghox.get_winEpisodeOrderby()=='desc':
    iHQGFuWSVjfRalCdbArEqLMcJkghUm='정렬순서변경 : 최신화부터 -> 1회부터'
    iHQGFuWSVjfRalCdbArEqLMcJkghUz['orderby']='asc'
   else:
    iHQGFuWSVjfRalCdbArEqLMcJkghUm='정렬순서변경 : 1회부터 -> 최신화부터'
    iHQGFuWSVjfRalCdbArEqLMcJkghUz['orderby']='desc'
   iHQGFuWSVjfRalCdbArEqLMcJkghUK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel='',img=iHQGFuWSVjfRalCdbArEqLMcJkghUK,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIt,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz,isLink=iHQGFuWSVjfRalCdbArEqLMcJkghIN)
  if iHQGFuWSVjfRalCdbArEqLMcJkghUs:
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['mode'] ='EPISODE_LIST' 
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['videoid']=iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('programid')
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['vidtype']='programid'
   iHQGFuWSVjfRalCdbArEqLMcJkghUz['page'] =iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUm='[B]%s >>[/B]'%'다음 페이지'
   iHQGFuWSVjfRalCdbArEqLMcJkghpU=iHQGFuWSVjfRalCdbArEqLMcJkghxU(iHQGFuWSVjfRalCdbArEqLMcJkghny+1)
   iHQGFuWSVjfRalCdbArEqLMcJkghUK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghUm,sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghpU,img=iHQGFuWSVjfRalCdbArEqLMcJkghUK,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghIe,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIN,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  xbmcplugin.setContent(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,'episodes')
  if iHQGFuWSVjfRalCdbArEqLMcJkghIs(iHQGFuWSVjfRalCdbArEqLMcJkghnY)>0:xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_LiveChannel_List(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghIo =args.get('genre')
  iHQGFuWSVjfRalCdbArEqLMcJkghPx=args.get('baseapi')
  iHQGFuWSVjfRalCdbArEqLMcJkghnY=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_LiveChannel_List(iHQGFuWSVjfRalCdbArEqLMcJkghIo,iHQGFuWSVjfRalCdbArEqLMcJkghPx)
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   iHQGFuWSVjfRalCdbArEqLMcJkghPy =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('channelid')
   iHQGFuWSVjfRalCdbArEqLMcJkghPY =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('studio')
   iHQGFuWSVjfRalCdbArEqLMcJkghPX=iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('tvshowtitle')
   iHQGFuWSVjfRalCdbArEqLMcJkghnN =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('thumbnail')
   iHQGFuWSVjfRalCdbArEqLMcJkghnt =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('age')
   iHQGFuWSVjfRalCdbArEqLMcJkghIU =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('epg')
   iHQGFuWSVjfRalCdbArEqLMcJkghnz={'mediatype':'episode','mpaa':iHQGFuWSVjfRalCdbArEqLMcJkghnt,'title':'%s < %s >'%(iHQGFuWSVjfRalCdbArEqLMcJkghPY,iHQGFuWSVjfRalCdbArEqLMcJkghPX),'tvshowtitle':iHQGFuWSVjfRalCdbArEqLMcJkghPX,'studio':iHQGFuWSVjfRalCdbArEqLMcJkghPY,'plot':'%s\n\n%s'%(iHQGFuWSVjfRalCdbArEqLMcJkghPY,iHQGFuWSVjfRalCdbArEqLMcJkghIU)}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'LIVE','contentid':iHQGFuWSVjfRalCdbArEqLMcJkghPy}
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghPY,sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghPX,img=iHQGFuWSVjfRalCdbArEqLMcJkghnN,infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIt,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  if iHQGFuWSVjfRalCdbArEqLMcJkghIs(iHQGFuWSVjfRalCdbArEqLMcJkghnY)>0:xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_Sports_GameList(iHQGFuWSVjfRalCdbArEqLMcJkghox,args):
  iHQGFuWSVjfRalCdbArEqLMcJkghnY=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.Get_Sports_Gamelist()
  for iHQGFuWSVjfRalCdbArEqLMcJkghnX in iHQGFuWSVjfRalCdbArEqLMcJkghnY:
   iHQGFuWSVjfRalCdbArEqLMcJkghIn =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('game_date')
   iHQGFuWSVjfRalCdbArEqLMcJkghIp =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('game_time')
   iHQGFuWSVjfRalCdbArEqLMcJkghIT =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('svc_id')
   iHQGFuWSVjfRalCdbArEqLMcJkghIP =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('away_team')
   iHQGFuWSVjfRalCdbArEqLMcJkghIx =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('home_team')
   iHQGFuWSVjfRalCdbArEqLMcJkghIm=iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('game_status')
   iHQGFuWSVjfRalCdbArEqLMcJkghID =iHQGFuWSVjfRalCdbArEqLMcJkghnX.get('game_place')
   iHQGFuWSVjfRalCdbArEqLMcJkghIv ='%s vs %s (%s)'%(iHQGFuWSVjfRalCdbArEqLMcJkghIP,iHQGFuWSVjfRalCdbArEqLMcJkghIx,iHQGFuWSVjfRalCdbArEqLMcJkghID)
   iHQGFuWSVjfRalCdbArEqLMcJkghIK =iHQGFuWSVjfRalCdbArEqLMcJkghIn+' '+iHQGFuWSVjfRalCdbArEqLMcJkghIp
   if iHQGFuWSVjfRalCdbArEqLMcJkghIm=='LIVE':
    iHQGFuWSVjfRalCdbArEqLMcJkghIm='~경기중~'
   elif iHQGFuWSVjfRalCdbArEqLMcJkghIm=='END':
    iHQGFuWSVjfRalCdbArEqLMcJkghIm='경기종료'
   elif iHQGFuWSVjfRalCdbArEqLMcJkghIm=='CANCEL':
    iHQGFuWSVjfRalCdbArEqLMcJkghIm='취소'
   else:
    iHQGFuWSVjfRalCdbArEqLMcJkghIm=''
   if iHQGFuWSVjfRalCdbArEqLMcJkghIm=='':
    iHQGFuWSVjfRalCdbArEqLMcJkghpU=iHQGFuWSVjfRalCdbArEqLMcJkghIv
   else:
    iHQGFuWSVjfRalCdbArEqLMcJkghpU=iHQGFuWSVjfRalCdbArEqLMcJkghIv+'  '+iHQGFuWSVjfRalCdbArEqLMcJkghIm
   iHQGFuWSVjfRalCdbArEqLMcJkghnz={'mediatype':'episode','title':iHQGFuWSVjfRalCdbArEqLMcJkghIv,'plot':'%s\n\n%s\n\n%s'%(iHQGFuWSVjfRalCdbArEqLMcJkghIK,iHQGFuWSVjfRalCdbArEqLMcJkghIv,iHQGFuWSVjfRalCdbArEqLMcJkghIm)}
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'SPORTS','contentid':iHQGFuWSVjfRalCdbArEqLMcJkghIT}
   iHQGFuWSVjfRalCdbArEqLMcJkghox.add_dir(iHQGFuWSVjfRalCdbArEqLMcJkghIK,sublabel=iHQGFuWSVjfRalCdbArEqLMcJkghpU,img='',infoLabels=iHQGFuWSVjfRalCdbArEqLMcJkghnz,isFolder=iHQGFuWSVjfRalCdbArEqLMcJkghIt,params=iHQGFuWSVjfRalCdbArEqLMcJkghUz)
  xbmcplugin.endOfDirectory(iHQGFuWSVjfRalCdbArEqLMcJkghox._addon_handle,cacheToDisc=iHQGFuWSVjfRalCdbArEqLMcJkghIt)
 def dp_View_Detail(iHQGFuWSVjfRalCdbArEqLMcJkghox,iHQGFuWSVjfRalCdbArEqLMcJkghIY):
  iHQGFuWSVjfRalCdbArEqLMcJkghne =iHQGFuWSVjfRalCdbArEqLMcJkghIY.get('videoid')
  iHQGFuWSVjfRalCdbArEqLMcJkghnB =iHQGFuWSVjfRalCdbArEqLMcJkghIY.get('vidtype') 
  iHQGFuWSVjfRalCdbArEqLMcJkghPt=iHQGFuWSVjfRalCdbArEqLMcJkghIY.get('contenttype')
  iHQGFuWSVjfRalCdbArEqLMcJkghox.addon_log(iHQGFuWSVjfRalCdbArEqLMcJkghne)
  iHQGFuWSVjfRalCdbArEqLMcJkghox.addon_log(iHQGFuWSVjfRalCdbArEqLMcJkghnB)
  iHQGFuWSVjfRalCdbArEqLMcJkghox.addon_log(iHQGFuWSVjfRalCdbArEqLMcJkghPt)
  iHQGFuWSVjfRalCdbArEqLMcJkghPO=iHQGFuWSVjfRalCdbArEqLMcJkghox.WavveObj.GetBookmarkInfo(iHQGFuWSVjfRalCdbArEqLMcJkghne,iHQGFuWSVjfRalCdbArEqLMcJkghnB,iHQGFuWSVjfRalCdbArEqLMcJkghPt)
  if iHQGFuWSVjfRalCdbArEqLMcJkghnB=='tvshow':
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'EPISODE_LIST','videoid':iHQGFuWSVjfRalCdbArEqLMcJkghPO['indexinfo']['videoid'],'vidtype':iHQGFuWSVjfRalCdbArEqLMcJkghPO['indexinfo']['vidtype'],'page':'1',}
   iHQGFuWSVjfRalCdbArEqLMcJkghpw='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(iHQGFuWSVjfRalCdbArEqLMcJkghUz))
  else:
   iHQGFuWSVjfRalCdbArEqLMcJkghUz={'mode':'MOVIE','contentid':iHQGFuWSVjfRalCdbArEqLMcJkghPO['indexinfo']['videoid'],'title':iHQGFuWSVjfRalCdbArEqLMcJkghPO['saveinfo']['infoLabels']['title'],'thumbnail':iHQGFuWSVjfRalCdbArEqLMcJkghPO['saveinfo']['thumbnail'],'age':iHQGFuWSVjfRalCdbArEqLMcJkghPO['saveinfo']['infoLabels']['mpaa'],}
   iHQGFuWSVjfRalCdbArEqLMcJkghpw='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(iHQGFuWSVjfRalCdbArEqLMcJkghUz))
  iHQGFuWSVjfRalCdbArEqLMcJkghUD=xbmcgui.ListItem(label=iHQGFuWSVjfRalCdbArEqLMcJkghPO['saveinfo']['title'],path=iHQGFuWSVjfRalCdbArEqLMcJkghpw)
  iHQGFuWSVjfRalCdbArEqLMcJkghUD.setArt(iHQGFuWSVjfRalCdbArEqLMcJkghPO['saveinfo']['thumbnail'])
  iHQGFuWSVjfRalCdbArEqLMcJkghUD.setInfo('Video',iHQGFuWSVjfRalCdbArEqLMcJkghPO['saveinfo']['infoLabels'])
  if iHQGFuWSVjfRalCdbArEqLMcJkghnB=='movie':
   iHQGFuWSVjfRalCdbArEqLMcJkghUD.setIsFolder(iHQGFuWSVjfRalCdbArEqLMcJkghIt)
   iHQGFuWSVjfRalCdbArEqLMcJkghUD.setProperty('IsPlayable','true')
  else:
   iHQGFuWSVjfRalCdbArEqLMcJkghUD.setIsFolder(iHQGFuWSVjfRalCdbArEqLMcJkghIN)
   iHQGFuWSVjfRalCdbArEqLMcJkghUD.setProperty('IsPlayable','false')
  iHQGFuWSVjfRalCdbArEqLMcJkghoz=xbmcgui.Dialog()
  iHQGFuWSVjfRalCdbArEqLMcJkghoz.info(iHQGFuWSVjfRalCdbArEqLMcJkghUD)
 def wavve_main(iHQGFuWSVjfRalCdbArEqLMcJkghox):
  iHQGFuWSVjfRalCdbArEqLMcJkghIz=iHQGFuWSVjfRalCdbArEqLMcJkghox.main_params.get('params')
  if iHQGFuWSVjfRalCdbArEqLMcJkghIz:
   iHQGFuWSVjfRalCdbArEqLMcJkghIy =base64.standard_b64decode(iHQGFuWSVjfRalCdbArEqLMcJkghIz).decode('utf-8')
   iHQGFuWSVjfRalCdbArEqLMcJkghIy =json.loads(iHQGFuWSVjfRalCdbArEqLMcJkghIy)
   iHQGFuWSVjfRalCdbArEqLMcJkghUt =iHQGFuWSVjfRalCdbArEqLMcJkghIy.get('mode')
   iHQGFuWSVjfRalCdbArEqLMcJkghIY =iHQGFuWSVjfRalCdbArEqLMcJkghIy.get('values')
  else:
   iHQGFuWSVjfRalCdbArEqLMcJkghUt=iHQGFuWSVjfRalCdbArEqLMcJkghox.main_params.get('mode',iHQGFuWSVjfRalCdbArEqLMcJkghIe)
   iHQGFuWSVjfRalCdbArEqLMcJkghIY=iHQGFuWSVjfRalCdbArEqLMcJkghox.main_params
  if iHQGFuWSVjfRalCdbArEqLMcJkghUt=='LOGOUT':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.logout()
   return
  iHQGFuWSVjfRalCdbArEqLMcJkghox.login_main()
  if iHQGFuWSVjfRalCdbArEqLMcJkghUt is iHQGFuWSVjfRalCdbArEqLMcJkghIe:
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Main_List()
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt in['LIVE','VOD','MOVIE','SPORTS']:
   iHQGFuWSVjfRalCdbArEqLMcJkghox.play_VIDEO(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='LIVE_CATAGORY':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_LiveCatagory_List(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='MAIN_CATAGORY':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_MainCatagory_List(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='SUPERSECTION_LIST':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_SuperSection_List(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='BANDLIVESECTION_LIST':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_BandLiveSection_List(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='BAND2SECTION_LIST':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Band2Section_List(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='PROGRAM_LIST':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Program_List(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='EPISODE_LIST':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Episode_List(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='MOVIE_LIST':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Movie_List(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='LIVE_LIST':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_LiveChannel_List(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='ORDER_BY':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_setEpOrderby(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='SEARCH_GROUP':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Search_Group(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt in['SEARCH_LIST','LOCAL_SEARCH']:
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Search_List(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='WATCH_GROUP':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Watch_Group(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='WATCH_LIST':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Watch_List(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='SET_BOOKMARK':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Set_Bookmark(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_History_Remove(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt in['TOTAL_SEARCH','TOTAL_HISTORY']:
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Global_Search(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='SEARCH_HISTORY':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Search_History(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='MENU_BOOKMARK':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Bookmark_Menu(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='GAME_LIST':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_Sports_GameList(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  elif iHQGFuWSVjfRalCdbArEqLMcJkghUt=='VIEW_DETAIL':
   iHQGFuWSVjfRalCdbArEqLMcJkghox.dp_View_Detail(iHQGFuWSVjfRalCdbArEqLMcJkghIY)
  else:
   iHQGFuWSVjfRalCdbArEqLMcJkghIe
# Created by pyminifier (https://github.com/liftoff/pyminifier)
