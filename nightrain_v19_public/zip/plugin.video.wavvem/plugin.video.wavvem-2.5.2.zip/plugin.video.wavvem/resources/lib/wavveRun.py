__author__="NightRain"
IyQPNkszHjOERYXTafVmUWCoDBbdAr=object
IyQPNkszHjOERYXTafVmUWCoDBbdAF=None
IyQPNkszHjOERYXTafVmUWCoDBbdAG=int
IyQPNkszHjOERYXTafVmUWCoDBbdAl=True
IyQPNkszHjOERYXTafVmUWCoDBbdAq=False
IyQPNkszHjOERYXTafVmUWCoDBbdAv=type
IyQPNkszHjOERYXTafVmUWCoDBbdAh=dict
IyQPNkszHjOERYXTafVmUWCoDBbdAK=getattr
IyQPNkszHjOERYXTafVmUWCoDBbdAp=list
IyQPNkszHjOERYXTafVmUWCoDBbdAn=len
IyQPNkszHjOERYXTafVmUWCoDBbdAw=range
IyQPNkszHjOERYXTafVmUWCoDBbdAt=str
IyQPNkszHjOERYXTafVmUWCoDBbdAM=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
IyQPNkszHjOERYXTafVmUWCoDBbdeg=[{'title':'LIVE 채널','mode':'SUB_CATAGORY','icon':'live.png','mCode':'GN55','sType':'live'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST_OLD','icon':'hot.png','subapi':'apis.wavve.com/v1/catalog?broadcastid=VN500&catalogType=ranking&category=all&code=VN500----GN51&&rankingType=realtime&uicode=VN500&uiparent=GN51-VN500&uirank=0&uitype=band_14','page':'1','orderby':'viewtime'},{'title':'인기 드라마','mode':'PROGRAM_LIST_OLD','subapi':'apis.wavve.com/v1/catalog?broadcastid=VN561&catalogType=ranking&category=vod&genre=drama&rankingType=realtime&uicode=VN561&uiparent=GN56-VN561&uirank=1&uitype=band_98','page':'1','orderby':'viewtime'},{'title':'인기 예능','mode':'PROGRAM_LIST_OLD','subapi':'apis.wavve.com/v1/catalog?broadcastid=VN562&catalogType=ranking&category=vod&genre=variety&rankingType=realtime&uicode=VN562&uiparent=GN57-VN562&uirank=1&uitype=band_98','page':'1','orderby':'viewtime'},{'title':'-----------------','mode':'XXX'},{'title':'분류별 - 예능','mode':'SUB_CATAGORY','mCode':'GN57','sType':'vod'},{'title':'분류별 - 드라마','mode':'SUB_CATAGORY','mCode':'GN56','sType':'vod'},{'title':'분류별 - 영화','mode':'SUB_CATAGORY','mCode':'GN59','sType':'movie'},{'title':'분류별 - 시사교양','mode':'SUB_CATAGORY','mCode':'GN20','sType':'vod'},{'title':'분류별 - 애니','mode':'SUB_CATAGORY','mCode':'GN21','sType':'vod'},{'title':'분류별 - 해외시리즈','mode':'SUB_CATAGORY','mCode':'GN12','sType':'vod'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
IyQPNkszHjOERYXTafVmUWCoDBbder=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
IyQPNkszHjOERYXTafVmUWCoDBbdeF=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
IyQPNkszHjOERYXTafVmUWCoDBbdeG={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
IyQPNkszHjOERYXTafVmUWCoDBbdel =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
IyQPNkszHjOERYXTafVmUWCoDBbdeA=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class IyQPNkszHjOERYXTafVmUWCoDBbdeL(IyQPNkszHjOERYXTafVmUWCoDBbdAr):
 def __init__(IyQPNkszHjOERYXTafVmUWCoDBbdeq,IyQPNkszHjOERYXTafVmUWCoDBbdev,IyQPNkszHjOERYXTafVmUWCoDBbdeh,IyQPNkszHjOERYXTafVmUWCoDBbdeK):
  IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_url =IyQPNkszHjOERYXTafVmUWCoDBbdev
  IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle=IyQPNkszHjOERYXTafVmUWCoDBbdeh
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.main_params =IyQPNkszHjOERYXTafVmUWCoDBbdeK
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj =hEPKQqindrBTxwtzHVUOXoDMplkNcR() 
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.WV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_stream(mpd,m3u8)'))
 def addon_noti(IyQPNkszHjOERYXTafVmUWCoDBbdeq,sting):
  try:
   IyQPNkszHjOERYXTafVmUWCoDBbden=xbmcgui.Dialog()
   IyQPNkszHjOERYXTafVmUWCoDBbden.notification(__addonname__,sting)
  except:
   IyQPNkszHjOERYXTafVmUWCoDBbdAF
 def addon_log(IyQPNkszHjOERYXTafVmUWCoDBbdeq,string):
  try:
   IyQPNkszHjOERYXTafVmUWCoDBbdew=string.encode('utf-8','ignore')
  except:
   IyQPNkszHjOERYXTafVmUWCoDBbdew='addonException: addon_log'
  IyQPNkszHjOERYXTafVmUWCoDBbdet=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,IyQPNkszHjOERYXTafVmUWCoDBbdew),level=IyQPNkszHjOERYXTafVmUWCoDBbdet)
 def get_keyboard_input(IyQPNkszHjOERYXTafVmUWCoDBbdeq,IyQPNkszHjOERYXTafVmUWCoDBbdLp):
  IyQPNkszHjOERYXTafVmUWCoDBbdeM=IyQPNkszHjOERYXTafVmUWCoDBbdAF
  kb=xbmc.Keyboard()
  kb.setHeading(IyQPNkszHjOERYXTafVmUWCoDBbdLp)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   IyQPNkszHjOERYXTafVmUWCoDBbdeM=kb.getText()
  return IyQPNkszHjOERYXTafVmUWCoDBbdeM
 def get_settings_account(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  IyQPNkszHjOERYXTafVmUWCoDBbdeJ =__addon__.getSetting('id')
  IyQPNkszHjOERYXTafVmUWCoDBbdeu =__addon__.getSetting('pw')
  IyQPNkszHjOERYXTafVmUWCoDBbdei=IyQPNkszHjOERYXTafVmUWCoDBbdAG(__addon__.getSetting('selected_profile'))
  return(IyQPNkszHjOERYXTafVmUWCoDBbdeJ,IyQPNkszHjOERYXTafVmUWCoDBbdeu,IyQPNkszHjOERYXTafVmUWCoDBbdei)
 def get_settings_totalsearch(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  IyQPNkszHjOERYXTafVmUWCoDBbdeS =IyQPNkszHjOERYXTafVmUWCoDBbdAl if __addon__.getSetting('local_search')=='true' else IyQPNkszHjOERYXTafVmUWCoDBbdAq
  IyQPNkszHjOERYXTafVmUWCoDBbdex=IyQPNkszHjOERYXTafVmUWCoDBbdAl if __addon__.getSetting('local_history')=='true' else IyQPNkszHjOERYXTafVmUWCoDBbdAq
  IyQPNkszHjOERYXTafVmUWCoDBbdec =IyQPNkszHjOERYXTafVmUWCoDBbdAl if __addon__.getSetting('total_search')=='true' else IyQPNkszHjOERYXTafVmUWCoDBbdAq
  IyQPNkszHjOERYXTafVmUWCoDBbdLe=IyQPNkszHjOERYXTafVmUWCoDBbdAl if __addon__.getSetting('total_history')=='true' else IyQPNkszHjOERYXTafVmUWCoDBbdAq
  IyQPNkszHjOERYXTafVmUWCoDBbdLg=IyQPNkszHjOERYXTafVmUWCoDBbdAl if __addon__.getSetting('menu_bookmark')=='true' else IyQPNkszHjOERYXTafVmUWCoDBbdAq
  return(IyQPNkszHjOERYXTafVmUWCoDBbdeS,IyQPNkszHjOERYXTafVmUWCoDBbdex,IyQPNkszHjOERYXTafVmUWCoDBbdec,IyQPNkszHjOERYXTafVmUWCoDBbdLe,IyQPNkszHjOERYXTafVmUWCoDBbdLg)
 def get_settings_makebookmark(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  return IyQPNkszHjOERYXTafVmUWCoDBbdAl if __addon__.getSetting('make_bookmark')=='true' else IyQPNkszHjOERYXTafVmUWCoDBbdAq
 def get_settings_play(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  IyQPNkszHjOERYXTafVmUWCoDBbdLr={'enable_hdr':IyQPNkszHjOERYXTafVmUWCoDBbdAl if __addon__.getSetting('enable_hdr')=='true' else IyQPNkszHjOERYXTafVmUWCoDBbdAq,'enable_uhd':IyQPNkszHjOERYXTafVmUWCoDBbdAl if __addon__.getSetting('enable_uhd')=='true' else IyQPNkszHjOERYXTafVmUWCoDBbdAq,'streamFilename':IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.WV_STREAM_FILENAME,}
  if IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_selQuality()<1080:
   IyQPNkszHjOERYXTafVmUWCoDBbdLr['enable_hdr']=IyQPNkszHjOERYXTafVmUWCoDBbdAq
   IyQPNkszHjOERYXTafVmUWCoDBbdLr['enable_uhd']=IyQPNkszHjOERYXTafVmUWCoDBbdAq
  return(IyQPNkszHjOERYXTafVmUWCoDBbdLr)
 def get_settings_proxyport(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  IyQPNkszHjOERYXTafVmUWCoDBbdLF =IyQPNkszHjOERYXTafVmUWCoDBbdAl if __addon__.getSetting('proxyYn')=='true' else IyQPNkszHjOERYXTafVmUWCoDBbdAq
  IyQPNkszHjOERYXTafVmUWCoDBbdLG=IyQPNkszHjOERYXTafVmUWCoDBbdAG(__addon__.getSetting('proxyPort'))
  return IyQPNkszHjOERYXTafVmUWCoDBbdLF,IyQPNkszHjOERYXTafVmUWCoDBbdLG
 def get_selQuality(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  try:
   IyQPNkszHjOERYXTafVmUWCoDBbdLl=[1080,720,480,360]
   IyQPNkszHjOERYXTafVmUWCoDBbdLA=IyQPNkszHjOERYXTafVmUWCoDBbdAG(__addon__.getSetting('selected_quality'))
   return IyQPNkszHjOERYXTafVmUWCoDBbdLl[IyQPNkszHjOERYXTafVmUWCoDBbdLA]
  except:
   IyQPNkszHjOERYXTafVmUWCoDBbdAF
  return 1080 
 def get_settings_exclusion21(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  IyQPNkszHjOERYXTafVmUWCoDBbdLq =__addon__.getSetting('exclusion21')
  if IyQPNkszHjOERYXTafVmUWCoDBbdLq=='false':
   return IyQPNkszHjOERYXTafVmUWCoDBbdAq
  else:
   return IyQPNkszHjOERYXTafVmUWCoDBbdAl
 def get_settings_direct_replay(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  IyQPNkszHjOERYXTafVmUWCoDBbdLv=IyQPNkszHjOERYXTafVmUWCoDBbdAG(__addon__.getSetting('direct_replay'))
  if IyQPNkszHjOERYXTafVmUWCoDBbdLv==0:
   return IyQPNkszHjOERYXTafVmUWCoDBbdAq
  else:
   return IyQPNkszHjOERYXTafVmUWCoDBbdAl
 def set_winEpisodeOrderby(IyQPNkszHjOERYXTafVmUWCoDBbdeq,IyQPNkszHjOERYXTafVmUWCoDBbdLh):
  __addon__.setSetting('wavve_orderby',IyQPNkszHjOERYXTafVmUWCoDBbdLh)
 def get_winEpisodeOrderby(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  IyQPNkszHjOERYXTafVmUWCoDBbdLh=__addon__.getSetting('wavve_orderby')
  if IyQPNkszHjOERYXTafVmUWCoDBbdLh in['',IyQPNkszHjOERYXTafVmUWCoDBbdAF]:IyQPNkszHjOERYXTafVmUWCoDBbdLh='desc'
  return IyQPNkszHjOERYXTafVmUWCoDBbdLh
 def add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdeq,label,sublabel='',img='',infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdAF,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params='',isLink=IyQPNkszHjOERYXTafVmUWCoDBbdAq,ContextMenu=IyQPNkszHjOERYXTafVmUWCoDBbdAF):
  IyQPNkszHjOERYXTafVmUWCoDBbdLK='%s?%s'%(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_url,urllib.parse.urlencode(params))
  if sublabel:IyQPNkszHjOERYXTafVmUWCoDBbdLp='%s < %s >'%(label,sublabel)
  else: IyQPNkszHjOERYXTafVmUWCoDBbdLp=label
  if not img:img='DefaultFolder.png'
  IyQPNkszHjOERYXTafVmUWCoDBbdLn=xbmcgui.ListItem(IyQPNkszHjOERYXTafVmUWCoDBbdLp)
  if IyQPNkszHjOERYXTafVmUWCoDBbdAv(img)==IyQPNkszHjOERYXTafVmUWCoDBbdAh:
   IyQPNkszHjOERYXTafVmUWCoDBbdLn.setArt(img)
  else:
   IyQPNkszHjOERYXTafVmUWCoDBbdLn.setArt({'thumb':img,'poster':img})
  if IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.KodiVersion>=20:
   if infoLabels:IyQPNkszHjOERYXTafVmUWCoDBbdeq.Set_InfoTag(IyQPNkszHjOERYXTafVmUWCoDBbdLn.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:IyQPNkszHjOERYXTafVmUWCoDBbdLn.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   IyQPNkszHjOERYXTafVmUWCoDBbdLn.setProperty('IsPlayable','true')
  if ContextMenu:IyQPNkszHjOERYXTafVmUWCoDBbdLn.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,IyQPNkszHjOERYXTafVmUWCoDBbdLK,IyQPNkszHjOERYXTafVmUWCoDBbdLn,isFolder)
 def Set_InfoTag(IyQPNkszHjOERYXTafVmUWCoDBbdeq,video_InfoTag:xbmc.InfoTagVideo,IyQPNkszHjOERYXTafVmUWCoDBbdLx):
  for IyQPNkszHjOERYXTafVmUWCoDBbdLw,value in IyQPNkszHjOERYXTafVmUWCoDBbdLx.items():
   if IyQPNkszHjOERYXTafVmUWCoDBbdeG[IyQPNkszHjOERYXTafVmUWCoDBbdLw]['type']=='string':
    IyQPNkszHjOERYXTafVmUWCoDBbdAK(video_InfoTag,IyQPNkszHjOERYXTafVmUWCoDBbdeG[IyQPNkszHjOERYXTafVmUWCoDBbdLw]['func'])(value)
   elif IyQPNkszHjOERYXTafVmUWCoDBbdeG[IyQPNkszHjOERYXTafVmUWCoDBbdLw]['type']=='int':
    if IyQPNkszHjOERYXTafVmUWCoDBbdAv(value)==IyQPNkszHjOERYXTafVmUWCoDBbdAG:
     IyQPNkszHjOERYXTafVmUWCoDBbdLt=IyQPNkszHjOERYXTafVmUWCoDBbdAG(value)
    else:
     IyQPNkszHjOERYXTafVmUWCoDBbdLt=0
    IyQPNkszHjOERYXTafVmUWCoDBbdAK(video_InfoTag,IyQPNkszHjOERYXTafVmUWCoDBbdeG[IyQPNkszHjOERYXTafVmUWCoDBbdLw]['func'])(IyQPNkszHjOERYXTafVmUWCoDBbdLt)
   elif IyQPNkszHjOERYXTafVmUWCoDBbdeG[IyQPNkszHjOERYXTafVmUWCoDBbdLw]['type']=='actor':
    if value!=[]:
     IyQPNkszHjOERYXTafVmUWCoDBbdAK(video_InfoTag,IyQPNkszHjOERYXTafVmUWCoDBbdeG[IyQPNkszHjOERYXTafVmUWCoDBbdLw]['func'])([xbmc.Actor(name)for name in value])
   elif IyQPNkszHjOERYXTafVmUWCoDBbdeG[IyQPNkszHjOERYXTafVmUWCoDBbdLw]['type']=='list':
    if IyQPNkszHjOERYXTafVmUWCoDBbdAv(value)==IyQPNkszHjOERYXTafVmUWCoDBbdAp:
     IyQPNkszHjOERYXTafVmUWCoDBbdAK(video_InfoTag,IyQPNkszHjOERYXTafVmUWCoDBbdeG[IyQPNkszHjOERYXTafVmUWCoDBbdLw]['func'])(value)
    else:
     IyQPNkszHjOERYXTafVmUWCoDBbdAK(video_InfoTag,IyQPNkszHjOERYXTafVmUWCoDBbdeG[IyQPNkszHjOERYXTafVmUWCoDBbdLw]['func'])([value])
 def dp_Main_List(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  (IyQPNkszHjOERYXTafVmUWCoDBbdeS,IyQPNkszHjOERYXTafVmUWCoDBbdex,IyQPNkszHjOERYXTafVmUWCoDBbdec,IyQPNkszHjOERYXTafVmUWCoDBbdLe,IyQPNkszHjOERYXTafVmUWCoDBbdLg)=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_totalsearch()
  for IyQPNkszHjOERYXTafVmUWCoDBbdLM in IyQPNkszHjOERYXTafVmUWCoDBbdeg:
   IyQPNkszHjOERYXTafVmUWCoDBbdLp=IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('title')
   IyQPNkszHjOERYXTafVmUWCoDBbdLJ=''
   if IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('mode')=='SEARCH_GROUP' and IyQPNkszHjOERYXTafVmUWCoDBbdeS ==IyQPNkszHjOERYXTafVmUWCoDBbdAq:continue
   elif IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('mode')=='SEARCH_HISTORY' and IyQPNkszHjOERYXTafVmUWCoDBbdex==IyQPNkszHjOERYXTafVmUWCoDBbdAq:continue
   elif IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('mode')=='TOTAL_SEARCH' and IyQPNkszHjOERYXTafVmUWCoDBbdec ==IyQPNkszHjOERYXTafVmUWCoDBbdAq:continue
   elif IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('mode')=='TOTAL_HISTORY' and IyQPNkszHjOERYXTafVmUWCoDBbdLe==IyQPNkszHjOERYXTafVmUWCoDBbdAq:continue
   elif IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('mode')=='MENU_BOOKMARK' and IyQPNkszHjOERYXTafVmUWCoDBbdLg==IyQPNkszHjOERYXTafVmUWCoDBbdAq:continue
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('mode'),'mCode':IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('mCode'),'genre':IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('genre'),'sCode':IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('sCode'),'sIndex':IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('sIndex'),'sType':IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('sType'),'suburl':IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('suburl'),'subapi':IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('subapi'),'page':IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('page'),'orderby':IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('orderby'),'ordernm':IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('ordernm'),}
   if IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    IyQPNkszHjOERYXTafVmUWCoDBbdLi=IyQPNkszHjOERYXTafVmUWCoDBbdAq
    IyQPNkszHjOERYXTafVmUWCoDBbdLS =IyQPNkszHjOERYXTafVmUWCoDBbdAl
   else:
    IyQPNkszHjOERYXTafVmUWCoDBbdLi=IyQPNkszHjOERYXTafVmUWCoDBbdAl
    IyQPNkszHjOERYXTafVmUWCoDBbdLS =IyQPNkszHjOERYXTafVmUWCoDBbdAq
   IyQPNkszHjOERYXTafVmUWCoDBbdLx={'title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'plot':IyQPNkszHjOERYXTafVmUWCoDBbdLp}
   if IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('mode')=='XXX':IyQPNkszHjOERYXTafVmUWCoDBbdLx=IyQPNkszHjOERYXTafVmUWCoDBbdAF
   if 'icon' in IyQPNkszHjOERYXTafVmUWCoDBbdLM:IyQPNkszHjOERYXTafVmUWCoDBbdLJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',IyQPNkszHjOERYXTafVmUWCoDBbdLM.get('icon')) 
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img=IyQPNkszHjOERYXTafVmUWCoDBbdLJ,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdLx,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdLi,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,isLink=IyQPNkszHjOERYXTafVmUWCoDBbdLS)
  xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAl)
 def dp_Search_Group(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  if 'search_key' in args:
   IyQPNkszHjOERYXTafVmUWCoDBbdgL=args.get('search_key')
  else:
   IyQPNkszHjOERYXTafVmUWCoDBbdgL=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not IyQPNkszHjOERYXTafVmUWCoDBbdgL:
    return
  for IyQPNkszHjOERYXTafVmUWCoDBbdgr in IyQPNkszHjOERYXTafVmUWCoDBbder:
   IyQPNkszHjOERYXTafVmUWCoDBbdgF =IyQPNkszHjOERYXTafVmUWCoDBbdgr.get('mode')
   IyQPNkszHjOERYXTafVmUWCoDBbdgG=IyQPNkszHjOERYXTafVmUWCoDBbdgr.get('sType')
   IyQPNkszHjOERYXTafVmUWCoDBbdLp=IyQPNkszHjOERYXTafVmUWCoDBbdgr.get('title')
   (IyQPNkszHjOERYXTafVmUWCoDBbdgl,IyQPNkszHjOERYXTafVmUWCoDBbdgA)=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_Search_List(IyQPNkszHjOERYXTafVmUWCoDBbdgL,IyQPNkszHjOERYXTafVmUWCoDBbdgG,1,exclusion21=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_exclusion21())
   IyQPNkszHjOERYXTafVmUWCoDBbdLx={'plot':'검색어 : '+IyQPNkszHjOERYXTafVmUWCoDBbdgL+'\n\n'+IyQPNkszHjOERYXTafVmUWCoDBbdeq.Search_FreeList(IyQPNkszHjOERYXTafVmUWCoDBbdgl)}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':IyQPNkszHjOERYXTafVmUWCoDBbdgF,'sType':IyQPNkszHjOERYXTafVmUWCoDBbdgG,'search_key':IyQPNkszHjOERYXTafVmUWCoDBbdgL,'page':'1',}
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img='',infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdLx,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbder)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAl)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.Save_Searched_List(IyQPNkszHjOERYXTafVmUWCoDBbdgL)
 def Search_FreeList(IyQPNkszHjOERYXTafVmUWCoDBbdeq,search_list):
  IyQPNkszHjOERYXTafVmUWCoDBbdgq=''
  IyQPNkszHjOERYXTafVmUWCoDBbdgv=7
  try:
   if IyQPNkszHjOERYXTafVmUWCoDBbdAn(search_list)==0:return '검색결과 없음'
   for i in IyQPNkszHjOERYXTafVmUWCoDBbdAw(IyQPNkszHjOERYXTafVmUWCoDBbdAn(search_list)):
    if i>=IyQPNkszHjOERYXTafVmUWCoDBbdgv:
     IyQPNkszHjOERYXTafVmUWCoDBbdgq=IyQPNkszHjOERYXTafVmUWCoDBbdgq+'...'
     break
    IyQPNkszHjOERYXTafVmUWCoDBbdgq=IyQPNkszHjOERYXTafVmUWCoDBbdgq+search_list[i]['title']+'\n'
  except:
   return ''
  return IyQPNkszHjOERYXTafVmUWCoDBbdgq
 def dp_Watch_Group(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  for IyQPNkszHjOERYXTafVmUWCoDBbdgh in IyQPNkszHjOERYXTafVmUWCoDBbdeF:
   IyQPNkszHjOERYXTafVmUWCoDBbdLp=IyQPNkszHjOERYXTafVmUWCoDBbdgh.get('title')
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':IyQPNkszHjOERYXTafVmUWCoDBbdgh.get('mode'),'sType':IyQPNkszHjOERYXTafVmUWCoDBbdgh.get('sType')}
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img='',infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdAF,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdeF)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAl)
 def dp_Search_History(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdgK=IyQPNkszHjOERYXTafVmUWCoDBbdeq.Load_List_File('search')
  for IyQPNkszHjOERYXTafVmUWCoDBbdgp in IyQPNkszHjOERYXTafVmUWCoDBbdgK:
   IyQPNkszHjOERYXTafVmUWCoDBbdgn=IyQPNkszHjOERYXTafVmUWCoDBbdAh(urllib.parse.parse_qsl(IyQPNkszHjOERYXTafVmUWCoDBbdgp))
   IyQPNkszHjOERYXTafVmUWCoDBbdgw=IyQPNkszHjOERYXTafVmUWCoDBbdgn.get('skey').strip()
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'SEARCH_GROUP','search_key':IyQPNkszHjOERYXTafVmUWCoDBbdgw,}
   IyQPNkszHjOERYXTafVmUWCoDBbdgt={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':IyQPNkszHjOERYXTafVmUWCoDBbdgw,'vType':'-',}
   IyQPNkszHjOERYXTafVmUWCoDBbdgM=urllib.parse.urlencode(IyQPNkszHjOERYXTafVmUWCoDBbdgt)
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ=[('선택된 검색어 ( %s ) 삭제'%(IyQPNkszHjOERYXTafVmUWCoDBbdgw),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdgM))]
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdgw,sublabel='',img=IyQPNkszHjOERYXTafVmUWCoDBbdAF,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdAF,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,ContextMenu=IyQPNkszHjOERYXTafVmUWCoDBbdgJ)
  IyQPNkszHjOERYXTafVmUWCoDBbdgu={'plot':'검색목록 전체를 삭제합니다.'}
  IyQPNkszHjOERYXTafVmUWCoDBbdLp='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  IyQPNkszHjOERYXTafVmUWCoDBbdLJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img=IyQPNkszHjOERYXTafVmUWCoDBbdLJ,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdgu,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAq,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,isLink=IyQPNkszHjOERYXTafVmUWCoDBbdAl)
  xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_Search_List(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdgG =args.get('sType')
  IyQPNkszHjOERYXTafVmUWCoDBbdgi =IyQPNkszHjOERYXTafVmUWCoDBbdAG(args.get('page'))
  if 'search_key' in args:
   IyQPNkszHjOERYXTafVmUWCoDBbdgL=args.get('search_key')
  else:
   IyQPNkszHjOERYXTafVmUWCoDBbdgL=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not IyQPNkszHjOERYXTafVmUWCoDBbdgL:
    xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle)
    return
  IyQPNkszHjOERYXTafVmUWCoDBbdgS,IyQPNkszHjOERYXTafVmUWCoDBbdgA=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_Search_List(IyQPNkszHjOERYXTafVmUWCoDBbdgL,IyQPNkszHjOERYXTafVmUWCoDBbdgG,IyQPNkszHjOERYXTafVmUWCoDBbdgi,exclusion21=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_exclusion21())
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   IyQPNkszHjOERYXTafVmUWCoDBbdgc =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('videoid')
   IyQPNkszHjOERYXTafVmUWCoDBbdre =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('vidtype')
   IyQPNkszHjOERYXTafVmUWCoDBbdLp =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('title')
   IyQPNkszHjOERYXTafVmUWCoDBbdrL=IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('thumbnail')
   IyQPNkszHjOERYXTafVmUWCoDBbdrg =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('age')
   if IyQPNkszHjOERYXTafVmUWCoDBbdrg=='18' or IyQPNkszHjOERYXTafVmUWCoDBbdrg=='19' or IyQPNkszHjOERYXTafVmUWCoDBbdrg=='21':IyQPNkszHjOERYXTafVmUWCoDBbdLp+=' (%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrg)
   IyQPNkszHjOERYXTafVmUWCoDBbdgu={'mediatype':'tvshow' if IyQPNkszHjOERYXTafVmUWCoDBbdgG=='vod' else 'movie','mpaa':IyQPNkszHjOERYXTafVmUWCoDBbdrg,'title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'plot':IyQPNkszHjOERYXTafVmUWCoDBbdLp+'\n\n'+IyQPNkszHjOERYXTafVmUWCoDBbdgc+'\n'+IyQPNkszHjOERYXTafVmUWCoDBbdre,}
   if IyQPNkszHjOERYXTafVmUWCoDBbdgG=='vod':
    IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'EPISODE_LIST','seasonid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'page':'1',}
    IyQPNkszHjOERYXTafVmUWCoDBbdLi=IyQPNkszHjOERYXTafVmUWCoDBbdAl
   else:
    IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'MOVIE','contentid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'thumbnail':IyQPNkszHjOERYXTafVmUWCoDBbdrL,'age':IyQPNkszHjOERYXTafVmUWCoDBbdrg,}
    IyQPNkszHjOERYXTafVmUWCoDBbdLi=IyQPNkszHjOERYXTafVmUWCoDBbdAq
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ=[]
   IyQPNkszHjOERYXTafVmUWCoDBbdrF={'mode':'VIEW_DETAIL','values':{'videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':'tvshow' if IyQPNkszHjOERYXTafVmUWCoDBbdgG=='vod' else 'movie','contenttype':IyQPNkszHjOERYXTafVmUWCoDBbdre,}}
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdrF,separators=(',',':'))
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=base64.standard_b64encode(IyQPNkszHjOERYXTafVmUWCoDBbdrG.encode()).decode('utf-8')
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=IyQPNkszHjOERYXTafVmUWCoDBbdrG.replace('+','%2B')
   IyQPNkszHjOERYXTafVmUWCoDBbdrl='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrG)
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ.append(('상세정보 조회',IyQPNkszHjOERYXTafVmUWCoDBbdrl))
   if IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_makebookmark():
    IyQPNkszHjOERYXTafVmUWCoDBbdrF={'videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':'tvshow' if IyQPNkszHjOERYXTafVmUWCoDBbdgG=='vod' else 'movie','vtitle':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'vsubtitle':'','contenttype':IyQPNkszHjOERYXTafVmUWCoDBbdre,}
    IyQPNkszHjOERYXTafVmUWCoDBbdrA=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdrF)
    IyQPNkszHjOERYXTafVmUWCoDBbdrA=urllib.parse.quote(IyQPNkszHjOERYXTafVmUWCoDBbdrA)
    IyQPNkszHjOERYXTafVmUWCoDBbdrl='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrA)
    IyQPNkszHjOERYXTafVmUWCoDBbdgJ.append(('(통합) 찜 영상에 추가',IyQPNkszHjOERYXTafVmUWCoDBbdrl))
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img=IyQPNkszHjOERYXTafVmUWCoDBbdrL,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdgu,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdLi,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,ContextMenu=IyQPNkszHjOERYXTafVmUWCoDBbdgJ)
  if IyQPNkszHjOERYXTafVmUWCoDBbdgA:
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['mode'] ='SEARCH_LIST' 
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['sType']=IyQPNkszHjOERYXTafVmUWCoDBbdgG 
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['page'] =IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['search_key']=IyQPNkszHjOERYXTafVmUWCoDBbdgL
   IyQPNkszHjOERYXTafVmUWCoDBbdLp='[B]%s >>[/B]'%'다음 페이지'
   IyQPNkszHjOERYXTafVmUWCoDBbdrq=IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdrq,img=IyQPNkszHjOERYXTafVmUWCoDBbdLJ,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdAF,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdgG=='movie':xbmcplugin.setContent(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,'movies')
  else:xbmcplugin.setContent(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_Watch_List(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdgG =args.get('sType')
  IyQPNkszHjOERYXTafVmUWCoDBbdLv=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_direct_replay()
  IyQPNkszHjOERYXTafVmUWCoDBbdgS=IyQPNkszHjOERYXTafVmUWCoDBbdeq.Load_List_File(IyQPNkszHjOERYXTafVmUWCoDBbdgG)
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   IyQPNkszHjOERYXTafVmUWCoDBbdgn=IyQPNkszHjOERYXTafVmUWCoDBbdAh(urllib.parse.parse_qsl(IyQPNkszHjOERYXTafVmUWCoDBbdgx))
   IyQPNkszHjOERYXTafVmUWCoDBbdrv =IyQPNkszHjOERYXTafVmUWCoDBbdgn.get('code').strip()
   IyQPNkszHjOERYXTafVmUWCoDBbdLp =IyQPNkszHjOERYXTafVmUWCoDBbdgn.get('title').strip()
   IyQPNkszHjOERYXTafVmUWCoDBbdrq =IyQPNkszHjOERYXTafVmUWCoDBbdgn.get('subtitle').strip()
   if IyQPNkszHjOERYXTafVmUWCoDBbdrq=='None':IyQPNkszHjOERYXTafVmUWCoDBbdrq=''
   IyQPNkszHjOERYXTafVmUWCoDBbdrL=IyQPNkszHjOERYXTafVmUWCoDBbdgn.get('img').strip()
   IyQPNkszHjOERYXTafVmUWCoDBbdgc =IyQPNkszHjOERYXTafVmUWCoDBbdgn.get('videoid').strip()
   try:
    IyQPNkszHjOERYXTafVmUWCoDBbdrL=IyQPNkszHjOERYXTafVmUWCoDBbdrL.replace('\'','\"')
    IyQPNkszHjOERYXTafVmUWCoDBbdrL=json.loads(IyQPNkszHjOERYXTafVmUWCoDBbdrL)
   except:
    IyQPNkszHjOERYXTafVmUWCoDBbdAF
   IyQPNkszHjOERYXTafVmUWCoDBbdgu={'plot':'%s\n%s'%(IyQPNkszHjOERYXTafVmUWCoDBbdLp,IyQPNkszHjOERYXTafVmUWCoDBbdrq)}
   if IyQPNkszHjOERYXTafVmUWCoDBbdgG=='vod':
    if IyQPNkszHjOERYXTafVmUWCoDBbdLv==IyQPNkszHjOERYXTafVmUWCoDBbdAq or IyQPNkszHjOERYXTafVmUWCoDBbdgc==IyQPNkszHjOERYXTafVmUWCoDBbdAF:
     IyQPNkszHjOERYXTafVmUWCoDBbdgu['mediatype']='tvshow'
     IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'SEASON_LIST','videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':'contentid',}
     IyQPNkszHjOERYXTafVmUWCoDBbdLi=IyQPNkszHjOERYXTafVmUWCoDBbdAl
    else:
     IyQPNkszHjOERYXTafVmUWCoDBbdgu['mediatype']='episode'
     IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'VOD','programid':IyQPNkszHjOERYXTafVmUWCoDBbdrv,'contentid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'subtitle':IyQPNkszHjOERYXTafVmUWCoDBbdrq,'thumbnail':IyQPNkszHjOERYXTafVmUWCoDBbdrL}
     IyQPNkszHjOERYXTafVmUWCoDBbdLi=IyQPNkszHjOERYXTafVmUWCoDBbdAq
   else:
    IyQPNkszHjOERYXTafVmUWCoDBbdgu['mediatype']='movie'
    IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'MOVIE','contentid':IyQPNkszHjOERYXTafVmUWCoDBbdrv,'title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'subtitle':IyQPNkszHjOERYXTafVmUWCoDBbdrq,'thumbnail':IyQPNkszHjOERYXTafVmUWCoDBbdrL}
    IyQPNkszHjOERYXTafVmUWCoDBbdLi=IyQPNkszHjOERYXTafVmUWCoDBbdAq
   IyQPNkszHjOERYXTafVmUWCoDBbdgt={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':IyQPNkszHjOERYXTafVmUWCoDBbdrv,'vType':IyQPNkszHjOERYXTafVmUWCoDBbdgG,}
   IyQPNkszHjOERYXTafVmUWCoDBbdgM=urllib.parse.urlencode(IyQPNkszHjOERYXTafVmUWCoDBbdgt)
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ=[('선택된 시청이력 ( %s ) 삭제'%(IyQPNkszHjOERYXTafVmUWCoDBbdLp),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdgM))]
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdrq,img=IyQPNkszHjOERYXTafVmUWCoDBbdrL,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdgu,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdLi,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,ContextMenu=IyQPNkszHjOERYXTafVmUWCoDBbdgJ)
  IyQPNkszHjOERYXTafVmUWCoDBbdgu={'plot':'시청목록을 삭제합니다.'}
  IyQPNkszHjOERYXTafVmUWCoDBbdLp='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':IyQPNkszHjOERYXTafVmUWCoDBbdgG,}
  IyQPNkszHjOERYXTafVmUWCoDBbdLJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img=IyQPNkszHjOERYXTafVmUWCoDBbdLJ,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdgu,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAq,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,isLink=IyQPNkszHjOERYXTafVmUWCoDBbdAl)
  if IyQPNkszHjOERYXTafVmUWCoDBbdgG=='movie':xbmcplugin.setContent(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,'movies')
  else:xbmcplugin.setContent(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def Load_List_File(IyQPNkszHjOERYXTafVmUWCoDBbdeq,stype): 
  try:
   if stype=='search':
    IyQPNkszHjOERYXTafVmUWCoDBbdrh=IyQPNkszHjOERYXTafVmUWCoDBbdeA
   elif stype in['vod','movie']:
    IyQPNkszHjOERYXTafVmUWCoDBbdrh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=IyQPNkszHjOERYXTafVmUWCoDBbdAM(IyQPNkszHjOERYXTafVmUWCoDBbdrh,'r',-1,'utf-8')
   IyQPNkszHjOERYXTafVmUWCoDBbdrK=fp.readlines()
   fp.close()
  except:
   IyQPNkszHjOERYXTafVmUWCoDBbdrK=[]
  return IyQPNkszHjOERYXTafVmUWCoDBbdrK
 def Save_Watched_List(IyQPNkszHjOERYXTafVmUWCoDBbdeq,IyQPNkszHjOERYXTafVmUWCoDBbdlu,IyQPNkszHjOERYXTafVmUWCoDBbdeK):
  try:
   IyQPNkszHjOERYXTafVmUWCoDBbdrp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IyQPNkszHjOERYXTafVmUWCoDBbdlu))
   IyQPNkszHjOERYXTafVmUWCoDBbdrn=IyQPNkszHjOERYXTafVmUWCoDBbdeq.Load_List_File(IyQPNkszHjOERYXTafVmUWCoDBbdlu) 
   fp=IyQPNkszHjOERYXTafVmUWCoDBbdAM(IyQPNkszHjOERYXTafVmUWCoDBbdrp,'w',-1,'utf-8')
   IyQPNkszHjOERYXTafVmUWCoDBbdrw=urllib.parse.urlencode(IyQPNkszHjOERYXTafVmUWCoDBbdeK)
   IyQPNkszHjOERYXTafVmUWCoDBbdrw=IyQPNkszHjOERYXTafVmUWCoDBbdrw+'\n'
   fp.write(IyQPNkszHjOERYXTafVmUWCoDBbdrw)
   IyQPNkszHjOERYXTafVmUWCoDBbdrt=0
   for IyQPNkszHjOERYXTafVmUWCoDBbdrM in IyQPNkszHjOERYXTafVmUWCoDBbdrn:
    IyQPNkszHjOERYXTafVmUWCoDBbdrJ=IyQPNkszHjOERYXTafVmUWCoDBbdAh(urllib.parse.parse_qsl(IyQPNkszHjOERYXTafVmUWCoDBbdrM))
    IyQPNkszHjOERYXTafVmUWCoDBbdru=IyQPNkszHjOERYXTafVmUWCoDBbdeK.get('code').strip()
    IyQPNkszHjOERYXTafVmUWCoDBbdri=IyQPNkszHjOERYXTafVmUWCoDBbdrJ.get('code').strip()
    if IyQPNkszHjOERYXTafVmUWCoDBbdlu=='vod' and IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_direct_replay()==IyQPNkszHjOERYXTafVmUWCoDBbdAl:
     IyQPNkszHjOERYXTafVmUWCoDBbdru=IyQPNkszHjOERYXTafVmUWCoDBbdeK.get('videoid').strip()
     IyQPNkszHjOERYXTafVmUWCoDBbdri=IyQPNkszHjOERYXTafVmUWCoDBbdrJ.get('videoid').strip()if IyQPNkszHjOERYXTafVmUWCoDBbdri!=IyQPNkszHjOERYXTafVmUWCoDBbdAF else '-'
    if IyQPNkszHjOERYXTafVmUWCoDBbdru!=IyQPNkszHjOERYXTafVmUWCoDBbdri:
     fp.write(IyQPNkszHjOERYXTafVmUWCoDBbdrM)
     IyQPNkszHjOERYXTafVmUWCoDBbdrt+=1
     if IyQPNkszHjOERYXTafVmUWCoDBbdrt>=50:break
   fp.close()
  except:
   IyQPNkszHjOERYXTafVmUWCoDBbdAF
 def dp_History_Remove(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdrS=args.get('delType')
  IyQPNkszHjOERYXTafVmUWCoDBbdrx =args.get('sKey')
  IyQPNkszHjOERYXTafVmUWCoDBbdrc =args.get('vType')
  IyQPNkszHjOERYXTafVmUWCoDBbden=xbmcgui.Dialog()
  if IyQPNkszHjOERYXTafVmUWCoDBbdrS=='SEARCH_ALL':
   IyQPNkszHjOERYXTafVmUWCoDBbdFe=IyQPNkszHjOERYXTafVmUWCoDBbden.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif IyQPNkszHjOERYXTafVmUWCoDBbdrS=='SEARCH_ONE':
   IyQPNkszHjOERYXTafVmUWCoDBbdFe=IyQPNkszHjOERYXTafVmUWCoDBbden.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif IyQPNkszHjOERYXTafVmUWCoDBbdrS=='WATCH_ALL':
   IyQPNkszHjOERYXTafVmUWCoDBbdFe=IyQPNkszHjOERYXTafVmUWCoDBbden.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif IyQPNkszHjOERYXTafVmUWCoDBbdrS=='WATCH_ONE':
   IyQPNkszHjOERYXTafVmUWCoDBbdFe=IyQPNkszHjOERYXTafVmUWCoDBbden.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if IyQPNkszHjOERYXTafVmUWCoDBbdFe==IyQPNkszHjOERYXTafVmUWCoDBbdAq:sys.exit()
  if IyQPNkszHjOERYXTafVmUWCoDBbdrS=='SEARCH_ALL':
   if os.path.isfile(IyQPNkszHjOERYXTafVmUWCoDBbdeA):os.remove(IyQPNkszHjOERYXTafVmUWCoDBbdeA)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdrS=='SEARCH_ONE':
   try:
    IyQPNkszHjOERYXTafVmUWCoDBbdrh=IyQPNkszHjOERYXTafVmUWCoDBbdeA
    IyQPNkszHjOERYXTafVmUWCoDBbdrn=IyQPNkszHjOERYXTafVmUWCoDBbdeq.Load_List_File('search') 
    fp=IyQPNkszHjOERYXTafVmUWCoDBbdAM(IyQPNkszHjOERYXTafVmUWCoDBbdrh,'w',-1,'utf-8')
    for IyQPNkszHjOERYXTafVmUWCoDBbdrM in IyQPNkszHjOERYXTafVmUWCoDBbdrn:
     IyQPNkszHjOERYXTafVmUWCoDBbdrJ=IyQPNkszHjOERYXTafVmUWCoDBbdAh(urllib.parse.parse_qsl(IyQPNkszHjOERYXTafVmUWCoDBbdrM))
     IyQPNkszHjOERYXTafVmUWCoDBbdFL=IyQPNkszHjOERYXTafVmUWCoDBbdrJ.get('skey').strip()
     if IyQPNkszHjOERYXTafVmUWCoDBbdrx!=IyQPNkszHjOERYXTafVmUWCoDBbdFL:
      fp.write(IyQPNkszHjOERYXTafVmUWCoDBbdrM)
    fp.close()
   except:
    IyQPNkszHjOERYXTafVmUWCoDBbdAF
  elif IyQPNkszHjOERYXTafVmUWCoDBbdrS=='WATCH_ALL':
   IyQPNkszHjOERYXTafVmUWCoDBbdrh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IyQPNkszHjOERYXTafVmUWCoDBbdrc))
   if os.path.isfile(IyQPNkszHjOERYXTafVmUWCoDBbdrh):os.remove(IyQPNkszHjOERYXTafVmUWCoDBbdrh)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdrS=='WATCH_ONE':
   IyQPNkszHjOERYXTafVmUWCoDBbdrh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IyQPNkszHjOERYXTafVmUWCoDBbdrc))
   try:
    IyQPNkszHjOERYXTafVmUWCoDBbdrn=IyQPNkszHjOERYXTafVmUWCoDBbdeq.Load_List_File(IyQPNkszHjOERYXTafVmUWCoDBbdrc) 
    fp=IyQPNkszHjOERYXTafVmUWCoDBbdAM(IyQPNkszHjOERYXTafVmUWCoDBbdrh,'w',-1,'utf-8')
    for IyQPNkszHjOERYXTafVmUWCoDBbdrM in IyQPNkszHjOERYXTafVmUWCoDBbdrn:
     IyQPNkszHjOERYXTafVmUWCoDBbdrJ=IyQPNkszHjOERYXTafVmUWCoDBbdAh(urllib.parse.parse_qsl(IyQPNkszHjOERYXTafVmUWCoDBbdrM))
     IyQPNkszHjOERYXTafVmUWCoDBbdFL=IyQPNkszHjOERYXTafVmUWCoDBbdrJ.get('code').strip()
     if IyQPNkszHjOERYXTafVmUWCoDBbdrx!=IyQPNkszHjOERYXTafVmUWCoDBbdFL:
      fp.write(IyQPNkszHjOERYXTafVmUWCoDBbdrM)
    fp.close()
   except:
    IyQPNkszHjOERYXTafVmUWCoDBbdAF
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(IyQPNkszHjOERYXTafVmUWCoDBbdeq,IyQPNkszHjOERYXTafVmUWCoDBbdgL):
  try:
   IyQPNkszHjOERYXTafVmUWCoDBbdFg=IyQPNkszHjOERYXTafVmUWCoDBbdeA
   IyQPNkszHjOERYXTafVmUWCoDBbdrn=IyQPNkszHjOERYXTafVmUWCoDBbdeq.Load_List_File('search') 
   IyQPNkszHjOERYXTafVmUWCoDBbdFr={'skey':IyQPNkszHjOERYXTafVmUWCoDBbdgL.strip()}
   fp=IyQPNkszHjOERYXTafVmUWCoDBbdAM(IyQPNkszHjOERYXTafVmUWCoDBbdFg,'w',-1,'utf-8')
   IyQPNkszHjOERYXTafVmUWCoDBbdrw=urllib.parse.urlencode(IyQPNkszHjOERYXTafVmUWCoDBbdFr)
   IyQPNkszHjOERYXTafVmUWCoDBbdrw=IyQPNkszHjOERYXTafVmUWCoDBbdrw+'\n'
   fp.write(IyQPNkszHjOERYXTafVmUWCoDBbdrw)
   IyQPNkszHjOERYXTafVmUWCoDBbdrt=0
   for IyQPNkszHjOERYXTafVmUWCoDBbdrM in IyQPNkszHjOERYXTafVmUWCoDBbdrn:
    IyQPNkszHjOERYXTafVmUWCoDBbdrJ=IyQPNkszHjOERYXTafVmUWCoDBbdAh(urllib.parse.parse_qsl(IyQPNkszHjOERYXTafVmUWCoDBbdrM))
    IyQPNkszHjOERYXTafVmUWCoDBbdru=IyQPNkszHjOERYXTafVmUWCoDBbdFr.get('skey').strip()
    IyQPNkszHjOERYXTafVmUWCoDBbdri=IyQPNkszHjOERYXTafVmUWCoDBbdrJ.get('skey').strip()
    if IyQPNkszHjOERYXTafVmUWCoDBbdru!=IyQPNkszHjOERYXTafVmUWCoDBbdri:
     fp.write(IyQPNkszHjOERYXTafVmUWCoDBbdrM)
     IyQPNkszHjOERYXTafVmUWCoDBbdrt+=1
     if IyQPNkszHjOERYXTafVmUWCoDBbdrt>=50:break
   fp.close()
  except:
   IyQPNkszHjOERYXTafVmUWCoDBbdAF
 def dp_Global_Search(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdgF=args.get('mode')
  if IyQPNkszHjOERYXTafVmUWCoDBbdgF=='TOTAL_SEARCH':
   IyQPNkszHjOERYXTafVmUWCoDBbdFG='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   IyQPNkszHjOERYXTafVmUWCoDBbdFG='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(IyQPNkszHjOERYXTafVmUWCoDBbdFG)
 def dp_Bookmark_Menu(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdFG='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(IyQPNkszHjOERYXTafVmUWCoDBbdFG)
 def login_main(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  (IyQPNkszHjOERYXTafVmUWCoDBbdFl,IyQPNkszHjOERYXTafVmUWCoDBbdFA,IyQPNkszHjOERYXTafVmUWCoDBbdFq)=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_account()
  if not(IyQPNkszHjOERYXTafVmUWCoDBbdFl and IyQPNkszHjOERYXTafVmUWCoDBbdFA):
   IyQPNkszHjOERYXTafVmUWCoDBbden=xbmcgui.Dialog()
   IyQPNkszHjOERYXTafVmUWCoDBbdFe=IyQPNkszHjOERYXTafVmUWCoDBbden.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if IyQPNkszHjOERYXTafVmUWCoDBbdFe==IyQPNkszHjOERYXTafVmUWCoDBbdAl:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if IyQPNkszHjOERYXTafVmUWCoDBbdeq.cookiefile_check()==IyQPNkszHjOERYXTafVmUWCoDBbdAl:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   IyQPNkszHjOERYXTafVmUWCoDBbdFv=0
   while IyQPNkszHjOERYXTafVmUWCoDBbdAl:
    IyQPNkszHjOERYXTafVmUWCoDBbdFv+=1
    time.sleep(0.05)
    if IyQPNkszHjOERYXTafVmUWCoDBbdFv>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  IyQPNkszHjOERYXTafVmUWCoDBbdFh=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.GetCredential_new(IyQPNkszHjOERYXTafVmUWCoDBbdFl,IyQPNkszHjOERYXTafVmUWCoDBbdFA,IyQPNkszHjOERYXTafVmUWCoDBbdFq)
  if IyQPNkszHjOERYXTafVmUWCoDBbdFh:IyQPNkszHjOERYXTafVmUWCoDBbdeq.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if IyQPNkszHjOERYXTafVmUWCoDBbdFh==IyQPNkszHjOERYXTafVmUWCoDBbdAq:
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdLh =args.get('orderby')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.set_winEpisodeOrderby(IyQPNkszHjOERYXTafVmUWCoDBbdLh)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdgF =args.get('mode')
  IyQPNkszHjOERYXTafVmUWCoDBbdFK =args.get('contentid')
  IyQPNkszHjOERYXTafVmUWCoDBbdFp =args.get('pvrmode')
  IyQPNkszHjOERYXTafVmUWCoDBbdFn=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_selQuality()
  IyQPNkszHjOERYXTafVmUWCoDBbdLr =IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_play()
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('mode        : '+IyQPNkszHjOERYXTafVmUWCoDBbdgF)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('contentid   : '+IyQPNkszHjOERYXTafVmUWCoDBbdFK)
  IyQPNkszHjOERYXTafVmUWCoDBbdFw=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.GetStreamingURL(IyQPNkszHjOERYXTafVmUWCoDBbdgF,IyQPNkszHjOERYXTafVmUWCoDBbdFK,IyQPNkszHjOERYXTafVmUWCoDBbdFn,IyQPNkszHjOERYXTafVmUWCoDBbdFp,playOption=IyQPNkszHjOERYXTafVmUWCoDBbdLr)
  IyQPNkszHjOERYXTafVmUWCoDBbdFt={'user-agent':IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.USER_AGENT}
  IyQPNkszHjOERYXTafVmUWCoDBbdFM=IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_cookie'] 
  IyQPNkszHjOERYXTafVmUWCoDBbdFJ=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.make_stream_header(IyQPNkszHjOERYXTafVmUWCoDBbdFt,IyQPNkszHjOERYXTafVmUWCoDBbdFM)
  IyQPNkszHjOERYXTafVmUWCoDBbdFu='{}|{}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_url'],IyQPNkszHjOERYXTafVmUWCoDBbdFJ)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('surl : '+IyQPNkszHjOERYXTafVmUWCoDBbdFu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_url']=='':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_noti(__language__(30907).encode('utf8'))
   return
  IyQPNkszHjOERYXTafVmUWCoDBbdLF,IyQPNkszHjOERYXTafVmUWCoDBbdLG=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_proxyport()
  IyQPNkszHjOERYXTafVmUWCoDBbdFi=urllib.parse.urlparse(IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_url'])
  IyQPNkszHjOERYXTafVmUWCoDBbdFi=IyQPNkszHjOERYXTafVmUWCoDBbdFi.path.strip('/').split('/')
  IyQPNkszHjOERYXTafVmUWCoDBbdFi=IyQPNkszHjOERYXTafVmUWCoDBbdFi[IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdFi)-1] 
  if (IyQPNkszHjOERYXTafVmUWCoDBbdLF==IyQPNkszHjOERYXTafVmUWCoDBbdAl and args.get('mode')in['VOD','MOVIE']and(IyQPNkszHjOERYXTafVmUWCoDBbdFw['playParam']['hdr']=='hdr' or IyQPNkszHjOERYXTafVmUWCoDBbdFw['playParam']['uhd']=='uhd')):
   if IyQPNkszHjOERYXTafVmUWCoDBbdFi.split('.')[1]=='mpd':
    IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Wavve_Parse_mpd(IyQPNkszHjOERYXTafVmUWCoDBbdFw)
   else:
    IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Wavve_Parse_m3u8(IyQPNkszHjOERYXTafVmUWCoDBbdFw)
   IyQPNkszHjOERYXTafVmUWCoDBbdFS={'addon':'wavvem','playOption':IyQPNkszHjOERYXTafVmUWCoDBbdLr,}
   IyQPNkszHjOERYXTafVmUWCoDBbdFS=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdFS,separators=(',',':'))
   IyQPNkszHjOERYXTafVmUWCoDBbdFS=base64.standard_b64encode(IyQPNkszHjOERYXTafVmUWCoDBbdFS.encode()).decode('utf-8')
   IyQPNkszHjOERYXTafVmUWCoDBbdFu ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdLG,IyQPNkszHjOERYXTafVmUWCoDBbdFu,IyQPNkszHjOERYXTafVmUWCoDBbdFS)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('surl : '+IyQPNkszHjOERYXTafVmUWCoDBbdFu)
  IyQPNkszHjOERYXTafVmUWCoDBbdFx=xbmcgui.ListItem(path=IyQPNkszHjOERYXTafVmUWCoDBbdFu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_drm']:
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('!!streaming_drm!!')
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   if 'licensetoken' in IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_drm']:
    IyQPNkszHjOERYXTafVmUWCoDBbdGe=IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_drm']['licensetoken']
    IyQPNkszHjOERYXTafVmUWCoDBbdGL =IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_drm']['licenseurl']
    if IyQPNkszHjOERYXTafVmUWCoDBbdgF=='MOVIE':
     IyQPNkszHjOERYXTafVmUWCoDBbdGg='https://www.wavve.com/player/movie?movieid=%s'%IyQPNkszHjOERYXTafVmUWCoDBbdFK
    else:
     IyQPNkszHjOERYXTafVmUWCoDBbdGg='https://www.wavve.com/player/vod?programid=%s&page=1'%IyQPNkszHjOERYXTafVmUWCoDBbdFK
    IyQPNkszHjOERYXTafVmUWCoDBbdGr={'content-type':'application/octet-stream','origin':'https://www.wavve.com','License-Token':IyQPNkszHjOERYXTafVmUWCoDBbdGe,'referer':IyQPNkszHjOERYXTafVmUWCoDBbdGg,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.USER_AGENT,}
   else:
    IyQPNkszHjOERYXTafVmUWCoDBbdGe=IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_drm']['customdata']
    IyQPNkszHjOERYXTafVmUWCoDBbdGL =IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_drm']['drmhost']
    if IyQPNkszHjOERYXTafVmUWCoDBbdgF=='MOVIE':
     IyQPNkszHjOERYXTafVmUWCoDBbdGg='https://www.wavve.com/player/movie?movieid=%s'%IyQPNkszHjOERYXTafVmUWCoDBbdFK
    else:
     IyQPNkszHjOERYXTafVmUWCoDBbdGg='https://www.wavve.com/player/vod?programid=%s&page=1'%IyQPNkszHjOERYXTafVmUWCoDBbdFK
    IyQPNkszHjOERYXTafVmUWCoDBbdGr={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':IyQPNkszHjOERYXTafVmUWCoDBbdGe,'referer':IyQPNkszHjOERYXTafVmUWCoDBbdGg,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.USER_AGENT,}
   IyQPNkszHjOERYXTafVmUWCoDBbdGF=IyQPNkszHjOERYXTafVmUWCoDBbdGL+'|'+urllib.parse.urlencode(IyQPNkszHjOERYXTafVmUWCoDBbdGr)+'|R{SSM}|'
   IyQPNkszHjOERYXTafVmUWCoDBbdFx.setProperty('inputstream','inputstream.adaptive')
   if IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.KodiVersion<=20:
    IyQPNkszHjOERYXTafVmUWCoDBbdFx.setProperty('inputstream.adaptive.manifest_type','mpd')
   IyQPNkszHjOERYXTafVmUWCoDBbdFx.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
   IyQPNkszHjOERYXTafVmUWCoDBbdFx.setProperty('inputstream.adaptive.license_key',IyQPNkszHjOERYXTafVmUWCoDBbdGF)
   IyQPNkszHjOERYXTafVmUWCoDBbdFx.setProperty('inputstream.adaptive.stream_headers',IyQPNkszHjOERYXTafVmUWCoDBbdFJ)
   IyQPNkszHjOERYXTafVmUWCoDBbdFx.setProperty('inputstream.adaptive.manifest_headers',IyQPNkszHjOERYXTafVmUWCoDBbdFJ)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF in['VOD','MOVIE']:
   IyQPNkszHjOERYXTafVmUWCoDBbdFx.setContentLookup(IyQPNkszHjOERYXTafVmUWCoDBbdAq)
   IyQPNkszHjOERYXTafVmUWCoDBbdFx.setMimeType('application/x-mpegURL')
   IyQPNkszHjOERYXTafVmUWCoDBbdFx.setProperty('inputstream','inputstream.adaptive')
   if IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.KodiVersion<=20:
    if IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_action']=='hls':
     IyQPNkszHjOERYXTafVmUWCoDBbdFx.setProperty('inputstream.adaptive.manifest_type','hls')
    else:
     IyQPNkszHjOERYXTafVmUWCoDBbdFx.setProperty('inputstream.adaptive.manifest_type','mpd')
   IyQPNkszHjOERYXTafVmUWCoDBbdFx.setProperty('inputstream.adaptive.stream_headers',IyQPNkszHjOERYXTafVmUWCoDBbdFJ)
   IyQPNkszHjOERYXTafVmUWCoDBbdFx.setProperty('inputstream.adaptive.manifest_headers',IyQPNkszHjOERYXTafVmUWCoDBbdFJ)
  if IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_vtt']:
   IyQPNkszHjOERYXTafVmUWCoDBbdFx.setSubtitles([IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_vtt']])
  xbmcplugin.setResolvedUrl(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,IyQPNkszHjOERYXTafVmUWCoDBbdAl,IyQPNkszHjOERYXTafVmUWCoDBbdFx)
  IyQPNkszHjOERYXTafVmUWCoDBbdGl=IyQPNkszHjOERYXTafVmUWCoDBbdAq
  if IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_preview']:
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_noti(IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_preview'].encode('utf-8'))
   IyQPNkszHjOERYXTafVmUWCoDBbdGl=IyQPNkszHjOERYXTafVmUWCoDBbdAl
  else:
   if '/preview.' in urllib.parse.urlsplit(IyQPNkszHjOERYXTafVmUWCoDBbdFw['stream_url']).path:
    IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_noti(__language__(30908).encode('utf8'))
    IyQPNkszHjOERYXTafVmUWCoDBbdGl=IyQPNkszHjOERYXTafVmUWCoDBbdAl
  try:
   IyQPNkszHjOERYXTafVmUWCoDBbdGA=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and IyQPNkszHjOERYXTafVmUWCoDBbdGl==IyQPNkszHjOERYXTafVmUWCoDBbdAq and IyQPNkszHjOERYXTafVmUWCoDBbdGA!='-':
    IyQPNkszHjOERYXTafVmUWCoDBbdLu={'code':IyQPNkszHjOERYXTafVmUWCoDBbdGA,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    IyQPNkszHjOERYXTafVmUWCoDBbdeq.Save_Watched_List(args.get('mode').lower(),IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  except:
   IyQPNkszHjOERYXTafVmUWCoDBbdAF
 def logout(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  IyQPNkszHjOERYXTafVmUWCoDBbden=xbmcgui.Dialog()
  IyQPNkszHjOERYXTafVmUWCoDBbdFe=IyQPNkszHjOERYXTafVmUWCoDBbden.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if IyQPNkszHjOERYXTafVmUWCoDBbdFe==IyQPNkszHjOERYXTafVmUWCoDBbdAq:sys.exit()
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Init_WV_Total()
  if os.path.isfile(IyQPNkszHjOERYXTafVmUWCoDBbdel):os.remove(IyQPNkszHjOERYXTafVmUWCoDBbdel)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  IyQPNkszHjOERYXTafVmUWCoDBbdGq =IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_Now_Datetime()
  IyQPNkszHjOERYXTafVmUWCoDBbdGv=IyQPNkszHjOERYXTafVmUWCoDBbdGq+datetime.timedelta(days=IyQPNkszHjOERYXTafVmUWCoDBbdAG(__addon__.getSetting('cache_ttl')))
  (IyQPNkszHjOERYXTafVmUWCoDBbdFl,IyQPNkszHjOERYXTafVmUWCoDBbdFA,IyQPNkszHjOERYXTafVmUWCoDBbdFq)=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_account()
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Save_session_acount(IyQPNkszHjOERYXTafVmUWCoDBbdFl,IyQPNkszHjOERYXTafVmUWCoDBbdFA,IyQPNkszHjOERYXTafVmUWCoDBbdFq)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.WV['account']['token_limit']=IyQPNkszHjOERYXTafVmUWCoDBbdGv.strftime('%Y%m%d')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.JsonFile_Save(IyQPNkszHjOERYXTafVmUWCoDBbdel,IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.WV)
 def cookiefile_check(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.WV=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.JsonFile_Load(IyQPNkszHjOERYXTafVmUWCoDBbdel)
  if 'account' not in IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.WV:
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Init_WV_Total()
   return IyQPNkszHjOERYXTafVmUWCoDBbdAq
  if 'uuid' not in IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.WV.get('cookies'):
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Init_WV_Total()
   return IyQPNkszHjOERYXTafVmUWCoDBbdAq
  (IyQPNkszHjOERYXTafVmUWCoDBbdGh,IyQPNkszHjOERYXTafVmUWCoDBbdGK,IyQPNkszHjOERYXTafVmUWCoDBbdGp)=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_account()
  (IyQPNkszHjOERYXTafVmUWCoDBbdGn,IyQPNkszHjOERYXTafVmUWCoDBbdGw,IyQPNkszHjOERYXTafVmUWCoDBbdGt)=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Load_session_acount()
  if IyQPNkszHjOERYXTafVmUWCoDBbdGh!=IyQPNkszHjOERYXTafVmUWCoDBbdGn or IyQPNkszHjOERYXTafVmUWCoDBbdGK!=IyQPNkszHjOERYXTafVmUWCoDBbdGw or IyQPNkszHjOERYXTafVmUWCoDBbdGp!=IyQPNkszHjOERYXTafVmUWCoDBbdGt:
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Init_WV_Total()
   return IyQPNkszHjOERYXTafVmUWCoDBbdAq
  if IyQPNkszHjOERYXTafVmUWCoDBbdAG(IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>IyQPNkszHjOERYXTafVmUWCoDBbdAG(IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.WV['account']['token_limit']):
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Init_WV_Total()
   return IyQPNkszHjOERYXTafVmUWCoDBbdAq
  return IyQPNkszHjOERYXTafVmUWCoDBbdAl
 def dp_LiveCatagory_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdGM =args.get('sCode')
  IyQPNkszHjOERYXTafVmUWCoDBbdGJ=args.get('sIndex')
  addon_log('sCode  : {}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdGM)) 
  addon_log('sIndex : {}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdGJ)) 
  IyQPNkszHjOERYXTafVmUWCoDBbdgS,IyQPNkszHjOERYXTafVmUWCoDBbdGu=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_LiveCatagory_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdGM,IyQPNkszHjOERYXTafVmUWCoDBbdGJ)
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   IyQPNkszHjOERYXTafVmUWCoDBbdLp =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('title')
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'LIVE_LIST_OLD','genre':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('genre'),'baseapi':IyQPNkszHjOERYXTafVmUWCoDBbdGu}
   IyQPNkszHjOERYXTafVmUWCoDBbdLx={'title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'plot':IyQPNkszHjOERYXTafVmUWCoDBbdLp}
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img='',infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdLx,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_MainCatagory_List(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdGM =args.get('sCode')
  IyQPNkszHjOERYXTafVmUWCoDBbdGJ=args.get('sIndex')
  IyQPNkszHjOERYXTafVmUWCoDBbdgG =args.get('sType')
  IyQPNkszHjOERYXTafVmUWCoDBbdgS=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_MainCatagory_List(IyQPNkszHjOERYXTafVmUWCoDBbdGM,IyQPNkszHjOERYXTafVmUWCoDBbdGJ,IyQPNkszHjOERYXTafVmUWCoDBbdgG)
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   if IyQPNkszHjOERYXTafVmUWCoDBbdgG in['vod','vod09']:
    if IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('subtype')=='catagory':
     IyQPNkszHjOERYXTafVmUWCoDBbdgF='PROGRAM_LIST'
    else:
     IyQPNkszHjOERYXTafVmUWCoDBbdgF='SUPERSECTION_LIST'
   elif IyQPNkszHjOERYXTafVmUWCoDBbdgG=='movie':
    IyQPNkszHjOERYXTafVmUWCoDBbdgF='MOVIE_LIST_OLD'
   else:
    IyQPNkszHjOERYXTafVmUWCoDBbdgF=''
   IyQPNkszHjOERYXTafVmUWCoDBbdLp='%s (%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('title'),args.get('ordernm'))
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':IyQPNkszHjOERYXTafVmUWCoDBbdgF,'suburl':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('suburl'),'subapi':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('subapi'),'page':'1','orderby':args.get('orderby')}
   IyQPNkszHjOERYXTafVmUWCoDBbdLx={'title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'plot':IyQPNkszHjOERYXTafVmUWCoDBbdLp}
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img='',infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdLx,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_SubCatagory_List(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdGi =args.get('mCode')
  IyQPNkszHjOERYXTafVmUWCoDBbdgG =args.get('sType')
  IyQPNkszHjOERYXTafVmUWCoDBbdgS=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_SubCatagory_List(IyQPNkszHjOERYXTafVmUWCoDBbdGi)
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   if IyQPNkszHjOERYXTafVmUWCoDBbdgG in['vod']:
    IyQPNkszHjOERYXTafVmUWCoDBbdgF='PROGRAM_LIST_NEW'
   elif IyQPNkszHjOERYXTafVmUWCoDBbdgG in['movie']:
    IyQPNkszHjOERYXTafVmUWCoDBbdgF='MOVIE_LIST_NEW'
   elif IyQPNkszHjOERYXTafVmUWCoDBbdgG in['live']:
    IyQPNkszHjOERYXTafVmUWCoDBbdgF='LIVE_LIST_NEW'
   else:
    IyQPNkszHjOERYXTafVmUWCoDBbdgF=''
   IyQPNkszHjOERYXTafVmUWCoDBbdLp=IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('title')
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':IyQPNkszHjOERYXTafVmUWCoDBbdgF,'mCode':IyQPNkszHjOERYXTafVmUWCoDBbdGi,'sCode':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('sCode'),'page':'1','sType':IyQPNkszHjOERYXTafVmUWCoDBbdgG,}
   IyQPNkszHjOERYXTafVmUWCoDBbdLx={'title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'plot':IyQPNkszHjOERYXTafVmUWCoDBbdLp}
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img='',infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdLx,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_Program_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdGS =args.get('subapi')
  IyQPNkszHjOERYXTafVmUWCoDBbdgi=IyQPNkszHjOERYXTafVmUWCoDBbdAG(args.get('page'))
  IyQPNkszHjOERYXTafVmUWCoDBbdLh =args.get('orderby')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('dp_Program_List_Old')
  IyQPNkszHjOERYXTafVmUWCoDBbdgS,IyQPNkszHjOERYXTafVmUWCoDBbdgA=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_Program_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdGS,IyQPNkszHjOERYXTafVmUWCoDBbdgi,IyQPNkszHjOERYXTafVmUWCoDBbdLh)
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   IyQPNkszHjOERYXTafVmUWCoDBbdgc =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('videoid')
   IyQPNkszHjOERYXTafVmUWCoDBbdre =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('vidtype')
   IyQPNkszHjOERYXTafVmUWCoDBbdLp =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('title')
   IyQPNkszHjOERYXTafVmUWCoDBbdrL=IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('thumbnail')
   IyQPNkszHjOERYXTafVmUWCoDBbdLx={'plot':IyQPNkszHjOERYXTafVmUWCoDBbdLp+'\n\n'+IyQPNkszHjOERYXTafVmUWCoDBbdgc+'\n'+IyQPNkszHjOERYXTafVmUWCoDBbdre,'mediatype':'tvshow','title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'SEASON_LIST','videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':IyQPNkszHjOERYXTafVmUWCoDBbdre,}
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ=[]
   IyQPNkszHjOERYXTafVmUWCoDBbdrF={'mode':'VIEW_DETAIL','values':{'videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':'tvshow','contenttype':IyQPNkszHjOERYXTafVmUWCoDBbdre,}}
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdrF,separators=(',',':'))
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=base64.standard_b64encode(IyQPNkszHjOERYXTafVmUWCoDBbdrG.encode()).decode('utf-8')
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=IyQPNkszHjOERYXTafVmUWCoDBbdrG.replace('+','%2B')
   IyQPNkszHjOERYXTafVmUWCoDBbdrl='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrG)
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ.append(('상세정보 조회',IyQPNkszHjOERYXTafVmUWCoDBbdrl))
   if IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_makebookmark():
    IyQPNkszHjOERYXTafVmUWCoDBbdrF={'videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':'tvshow','vtitle':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'vsubtitle':'','contenttype':IyQPNkszHjOERYXTafVmUWCoDBbdre,}
    IyQPNkszHjOERYXTafVmUWCoDBbdrA=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdrF)
    IyQPNkszHjOERYXTafVmUWCoDBbdrA=urllib.parse.quote(IyQPNkszHjOERYXTafVmUWCoDBbdrA)
    IyQPNkszHjOERYXTafVmUWCoDBbdrl='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrA)
    IyQPNkszHjOERYXTafVmUWCoDBbdgJ.append(('(통합) 찜 영상에 추가',IyQPNkszHjOERYXTafVmUWCoDBbdrl))
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img=IyQPNkszHjOERYXTafVmUWCoDBbdrL,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdLx,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,ContextMenu=IyQPNkszHjOERYXTafVmUWCoDBbdgJ)
  if IyQPNkszHjOERYXTafVmUWCoDBbdgA:
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['mode'] ='PROGRAM_LIST_OLD' 
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['subapi']=IyQPNkszHjOERYXTafVmUWCoDBbdGS 
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['page'] =IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLp='[B]%s >>[/B]'%'다음 페이지'
   IyQPNkszHjOERYXTafVmUWCoDBbdrq=IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdrq,img=IyQPNkszHjOERYXTafVmUWCoDBbdLJ,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdAF,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  xbmcplugin.setContent(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,'tvshows')
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_Program_List_New(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdGi =args.get('mCode')
  IyQPNkszHjOERYXTafVmUWCoDBbdGM =args.get('sCode')
  IyQPNkszHjOERYXTafVmUWCoDBbdgi=IyQPNkszHjOERYXTafVmUWCoDBbdAG(args.get('page'))
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('dp_Program_List_New')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('mCode   : {}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdGi))
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('sCode   : {}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdGM))
  IyQPNkszHjOERYXTafVmUWCoDBbdgS,IyQPNkszHjOERYXTafVmUWCoDBbdgA=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_Program_List_new(IyQPNkszHjOERYXTafVmUWCoDBbdGi,IyQPNkszHjOERYXTafVmUWCoDBbdGM,IyQPNkszHjOERYXTafVmUWCoDBbdgi)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('GN_LIST : {}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)))
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   IyQPNkszHjOERYXTafVmUWCoDBbdgc =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('videoid')
   IyQPNkszHjOERYXTafVmUWCoDBbdre =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('vidtype')
   IyQPNkszHjOERYXTafVmUWCoDBbdLp =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('title')
   IyQPNkszHjOERYXTafVmUWCoDBbdrL=IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('thumbnail')
   IyQPNkszHjOERYXTafVmUWCoDBbdLx={'plot':IyQPNkszHjOERYXTafVmUWCoDBbdLp+'\n\n'+IyQPNkszHjOERYXTafVmUWCoDBbdgc+'\n'+IyQPNkszHjOERYXTafVmUWCoDBbdre,'mediatype':'tvshow','title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'SEASON_LIST','videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':IyQPNkszHjOERYXTafVmUWCoDBbdre,}
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ=[]
   IyQPNkszHjOERYXTafVmUWCoDBbdrF={'mode':'VIEW_DETAIL','values':{'videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':'tvshow','contenttype':IyQPNkszHjOERYXTafVmUWCoDBbdre,}}
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdrF,separators=(',',':'))
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=base64.standard_b64encode(IyQPNkszHjOERYXTafVmUWCoDBbdrG.encode()).decode('utf-8')
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=IyQPNkszHjOERYXTafVmUWCoDBbdrG.replace('+','%2B')
   IyQPNkszHjOERYXTafVmUWCoDBbdrl='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrG)
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ.append(('상세정보 조회',IyQPNkszHjOERYXTafVmUWCoDBbdrl))
   if IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_makebookmark():
    IyQPNkszHjOERYXTafVmUWCoDBbdrF={'videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':'tvshow','vtitle':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'vsubtitle':'','contenttype':IyQPNkszHjOERYXTafVmUWCoDBbdre,}
    IyQPNkszHjOERYXTafVmUWCoDBbdrA=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdrF)
    IyQPNkszHjOERYXTafVmUWCoDBbdrA=urllib.parse.quote(IyQPNkszHjOERYXTafVmUWCoDBbdrA)
    IyQPNkszHjOERYXTafVmUWCoDBbdrl='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrA)
    IyQPNkszHjOERYXTafVmUWCoDBbdgJ.append(('(통합) 찜 영상에 추가',IyQPNkszHjOERYXTafVmUWCoDBbdrl))
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img=IyQPNkszHjOERYXTafVmUWCoDBbdrL,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdLx,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,ContextMenu=IyQPNkszHjOERYXTafVmUWCoDBbdgJ)
  if IyQPNkszHjOERYXTafVmUWCoDBbdgA:
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['mode'] ='PROGRAM_LIST_NEW' 
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['mCode']=IyQPNkszHjOERYXTafVmUWCoDBbdGi
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['sCode']=IyQPNkszHjOERYXTafVmUWCoDBbdGM
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['page'] =IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLp='[B]%s >>[/B]'%'다음 페이지'
   IyQPNkszHjOERYXTafVmUWCoDBbdrq=IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdrq,img=IyQPNkszHjOERYXTafVmUWCoDBbdLJ,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdAF,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  xbmcplugin.setContent(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,'tvshows')
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_Movie_List_New(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdGi =args.get('mCode')
  IyQPNkszHjOERYXTafVmUWCoDBbdGM =args.get('sCode')
  IyQPNkszHjOERYXTafVmUWCoDBbdgi=IyQPNkszHjOERYXTafVmUWCoDBbdAG(args.get('page'))
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('dp_Movie_List_New')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('mCode   : {}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdGi))
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('sCode   : {}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdGM))
  IyQPNkszHjOERYXTafVmUWCoDBbdgS,IyQPNkszHjOERYXTafVmUWCoDBbdgA=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_Movie_List_new(IyQPNkszHjOERYXTafVmUWCoDBbdGi,IyQPNkszHjOERYXTafVmUWCoDBbdGM,IyQPNkszHjOERYXTafVmUWCoDBbdgi)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('GN_LIST : {}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)))
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   IyQPNkszHjOERYXTafVmUWCoDBbdgc =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('videoid')
   IyQPNkszHjOERYXTafVmUWCoDBbdre =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('vidtype')
   IyQPNkszHjOERYXTafVmUWCoDBbdLp =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('title')
   IyQPNkszHjOERYXTafVmUWCoDBbdrL=IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('thumbnail')
   IyQPNkszHjOERYXTafVmUWCoDBbdGx =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('playtime')
   IyQPNkszHjOERYXTafVmUWCoDBbdGc =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('year')
   IyQPNkszHjOERYXTafVmUWCoDBbdLx={'plot':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'mediatype':'movie','year':IyQPNkszHjOERYXTafVmUWCoDBbdGc,'duration':IyQPNkszHjOERYXTafVmUWCoDBbdAG(IyQPNkszHjOERYXTafVmUWCoDBbdGx),}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'MOVIE','contentid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'thumbnail':IyQPNkszHjOERYXTafVmUWCoDBbdrL,}
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ=[]
   IyQPNkszHjOERYXTafVmUWCoDBbdrF={'mode':'VIEW_DETAIL','values':{'videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':'movie','contenttype':IyQPNkszHjOERYXTafVmUWCoDBbdre,}}
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdrF,separators=(',',':'))
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=base64.standard_b64encode(IyQPNkszHjOERYXTafVmUWCoDBbdrG.encode()).decode('utf-8')
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=IyQPNkszHjOERYXTafVmUWCoDBbdrG.replace('+','%2B')
   IyQPNkszHjOERYXTafVmUWCoDBbdrl='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrG)
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ.append(('상세정보 조회',IyQPNkszHjOERYXTafVmUWCoDBbdrl))
   if IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_makebookmark():
    IyQPNkszHjOERYXTafVmUWCoDBbdrF={'videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':'movie','vtitle':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'vsubtitle':'','contenttype':'programid',}
    IyQPNkszHjOERYXTafVmUWCoDBbdrA=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdrF)
    IyQPNkszHjOERYXTafVmUWCoDBbdrA=urllib.parse.quote(IyQPNkszHjOERYXTafVmUWCoDBbdrA)
    IyQPNkszHjOERYXTafVmUWCoDBbdrl='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrA)
    IyQPNkszHjOERYXTafVmUWCoDBbdgJ.append(('(통합) 찜 영상에 추가',IyQPNkszHjOERYXTafVmUWCoDBbdrl))
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img=IyQPNkszHjOERYXTafVmUWCoDBbdrL,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdLx,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAq,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,ContextMenu=IyQPNkszHjOERYXTafVmUWCoDBbdgJ)
  if IyQPNkszHjOERYXTafVmUWCoDBbdgA:
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['mode'] ='MOVIE_LIST_NEW' 
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['mCode']=IyQPNkszHjOERYXTafVmUWCoDBbdGi
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['sCode']=IyQPNkszHjOERYXTafVmUWCoDBbdGM
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['page'] =IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLp='[B]%s >>[/B]'%'다음 페이지'
   IyQPNkszHjOERYXTafVmUWCoDBbdrq=IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdrq,img=IyQPNkszHjOERYXTafVmUWCoDBbdLJ,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdAF,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  xbmcplugin.setContent(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,'movies')
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_Season_List(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdgc=args.get('videoid')
  IyQPNkszHjOERYXTafVmUWCoDBbdre=args.get('vidtype')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('dp_Season_List')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('videoid : {}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdgc))
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('vidtype : {}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdre))
  if IyQPNkszHjOERYXTafVmUWCoDBbdre=='contentid':
   IyQPNkszHjOERYXTafVmUWCoDBbdFK=IyQPNkszHjOERYXTafVmUWCoDBbdgc
  else:
   IyQPNkszHjOERYXTafVmUWCoDBbdFK=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.ProgramidToContentid(IyQPNkszHjOERYXTafVmUWCoDBbdgc)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('contentid : {}'.format(IyQPNkszHjOERYXTafVmUWCoDBbdFK))
  IyQPNkszHjOERYXTafVmUWCoDBbdle=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_Season_List(IyQPNkszHjOERYXTafVmUWCoDBbdFK)
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdle)>1:
   for IyQPNkszHjOERYXTafVmUWCoDBbdlL in IyQPNkszHjOERYXTafVmUWCoDBbdle:
    IyQPNkszHjOERYXTafVmUWCoDBbdlg=IyQPNkszHjOERYXTafVmUWCoDBbdlL.get('season_Id')
    IyQPNkszHjOERYXTafVmUWCoDBbdlr=IyQPNkszHjOERYXTafVmUWCoDBbdlL.get('season_Nm')
    IyQPNkszHjOERYXTafVmUWCoDBbdlF=IyQPNkszHjOERYXTafVmUWCoDBbdlL.get('programNm')
    IyQPNkszHjOERYXTafVmUWCoDBbdrL=IyQPNkszHjOERYXTafVmUWCoDBbdlL.get('thumbnail')
    IyQPNkszHjOERYXTafVmUWCoDBbdlG =IyQPNkszHjOERYXTafVmUWCoDBbdlL.get('synopsis')
    IyQPNkszHjOERYXTafVmUWCoDBbdgu={'mediatype':'tvshow','title':IyQPNkszHjOERYXTafVmUWCoDBbdlr,'plot':IyQPNkszHjOERYXTafVmUWCoDBbdlG,}
    IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'EPISODE_LIST','seasonid':IyQPNkszHjOERYXTafVmUWCoDBbdlg,'page':'1',}
    IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdlr,sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdlF,img=IyQPNkszHjOERYXTafVmUWCoDBbdrL,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdgu,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,ContextMenu=IyQPNkszHjOERYXTafVmUWCoDBbdAF)
   xbmcplugin.setContent(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
  else:
   IyQPNkszHjOERYXTafVmUWCoDBbdlg=IyQPNkszHjOERYXTafVmUWCoDBbdle[0].get('season_Id')
   IyQPNkszHjOERYXTafVmUWCoDBbdlA={'seasonid':IyQPNkszHjOERYXTafVmUWCoDBbdlg,'page':'1',}
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Episode_List(IyQPNkszHjOERYXTafVmUWCoDBbdlA)
 def dp_Episode_List(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdlq =args.get('seasonid')
  IyQPNkszHjOERYXTafVmUWCoDBbdgi =IyQPNkszHjOERYXTafVmUWCoDBbdAG(args.get('page'))
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('seasonid : '+IyQPNkszHjOERYXTafVmUWCoDBbdlq)
  IyQPNkszHjOERYXTafVmUWCoDBbdgS,IyQPNkszHjOERYXTafVmUWCoDBbdgA=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_Episode_List_New(IyQPNkszHjOERYXTafVmUWCoDBbdlq,IyQPNkszHjOERYXTafVmUWCoDBbdgi,orderby=IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_winEpisodeOrderby())
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   IyQPNkszHjOERYXTafVmUWCoDBbdrq='{}회'.format(IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('episodenumber'))
   IyQPNkszHjOERYXTafVmUWCoDBbdlv ='[%s]\n\n%s'%(IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('episodetitle'),IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('synopsis'))
   IyQPNkszHjOERYXTafVmUWCoDBbdgu={'mediatype':'episode','title':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('programtitle'),'year':IyQPNkszHjOERYXTafVmUWCoDBbdAG(IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('releasedate')[:4]),'aired':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('releasedate'),'episode':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('episodenumber'),'duration':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('playtime'),'plot':IyQPNkszHjOERYXTafVmUWCoDBbdlv,'cast':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('episodeactors'),}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'VOD','programid':IyQPNkszHjOERYXTafVmUWCoDBbdlq,'contentid':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('contentid'),'thumbnail':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('thumbnail'),'title':IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('programtitle'),'subtitle':IyQPNkszHjOERYXTafVmUWCoDBbdrq,}
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('programtitle'),sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdrq,img=IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('thumbnail'),infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdgu,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAq,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdgi==1:
   IyQPNkszHjOERYXTafVmUWCoDBbdgu={'plot':'정렬순서를 변경합니다.'}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['mode'] ='ORDER_BY' 
   if IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_winEpisodeOrderby()=='desc':
    IyQPNkszHjOERYXTafVmUWCoDBbdLp='정렬순서변경 : 최신화부터 -> 1회부터'
    IyQPNkszHjOERYXTafVmUWCoDBbdLu['orderby']='asc'
   else:
    IyQPNkszHjOERYXTafVmUWCoDBbdLp='정렬순서변경 : 1회부터 -> 최신화부터'
    IyQPNkszHjOERYXTafVmUWCoDBbdLu['orderby']='desc'
   IyQPNkszHjOERYXTafVmUWCoDBbdLJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img=IyQPNkszHjOERYXTafVmUWCoDBbdLJ,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdgu,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAq,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,isLink=IyQPNkszHjOERYXTafVmUWCoDBbdAl)
  if IyQPNkszHjOERYXTafVmUWCoDBbdgA:
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['mode'] ='EPISODE_LIST' 
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['seasonid']=IyQPNkszHjOERYXTafVmUWCoDBbdlq
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['page'] =IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLp='[B]%s >>[/B]'%'다음 페이지'
   IyQPNkszHjOERYXTafVmUWCoDBbdrq=IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdrq,img=IyQPNkszHjOERYXTafVmUWCoDBbdLJ,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdAF,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  xbmcplugin.setContent(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,'episodes')
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_SuperSection_List(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdlh =args.get('suburl')
  IyQPNkszHjOERYXTafVmUWCoDBbdGS =args.get('subapi')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('dp_SuperSection_List')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('suburl : '+IyQPNkszHjOERYXTafVmUWCoDBbdlh)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('subapi : '+IyQPNkszHjOERYXTafVmUWCoDBbdGS)
  IyQPNkszHjOERYXTafVmUWCoDBbdgS=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_SuperMultiSection_List(IyQPNkszHjOERYXTafVmUWCoDBbdlh)
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   IyQPNkszHjOERYXTafVmUWCoDBbdLp =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('title')
   IyQPNkszHjOERYXTafVmUWCoDBbdGS =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('subapi')
   IyQPNkszHjOERYXTafVmUWCoDBbdlK=IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('cell_type')
   if IyQPNkszHjOERYXTafVmUWCoDBbdGS.find('contenttype=movie')>=0 or IyQPNkszHjOERYXTafVmUWCoDBbdGS.find('mtype=svod')>=0:
    IyQPNkszHjOERYXTafVmUWCoDBbdgF='MOVIE_LIST_OLD'
   elif re.search('themes/2\d{4}',IyQPNkszHjOERYXTafVmUWCoDBbdGS)or re.search('themes-band/9\d{4}',IyQPNkszHjOERYXTafVmUWCoDBbdGS):
    IyQPNkszHjOERYXTafVmUWCoDBbdgF='MOVIE_LIST_OLD'
   else:
    IyQPNkszHjOERYXTafVmUWCoDBbdgF='PROGRAM_LIST_OLD'
   IyQPNkszHjOERYXTafVmUWCoDBbdgu={'plot':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'mediatype':'tvshow',}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':IyQPNkszHjOERYXTafVmUWCoDBbdgF,'suburl':IyQPNkszHjOERYXTafVmUWCoDBbdlh,'subapi':IyQPNkszHjOERYXTafVmUWCoDBbdGS,'page':'1',}
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img=IyQPNkszHjOERYXTafVmUWCoDBbdAF,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdgu,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_Movie_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdGS =args.get('subapi')
  IyQPNkszHjOERYXTafVmUWCoDBbdgi=IyQPNkszHjOERYXTafVmUWCoDBbdAG(args.get('page'))
  IyQPNkszHjOERYXTafVmUWCoDBbdLh =args.get('orderby')or '-'
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log('dp_Movie_List')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log(IyQPNkszHjOERYXTafVmUWCoDBbdGS)
  IyQPNkszHjOERYXTafVmUWCoDBbdgS,IyQPNkszHjOERYXTafVmUWCoDBbdgA=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_Movie_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdGS,IyQPNkszHjOERYXTafVmUWCoDBbdgi,IyQPNkszHjOERYXTafVmUWCoDBbdLh)
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   IyQPNkszHjOERYXTafVmUWCoDBbdgc =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('videoid')
   IyQPNkszHjOERYXTafVmUWCoDBbdre =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('vidtype')
   IyQPNkszHjOERYXTafVmUWCoDBbdLp =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('title')
   IyQPNkszHjOERYXTafVmUWCoDBbdrL=IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('thumbnail')
   IyQPNkszHjOERYXTafVmUWCoDBbdrg =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('age')
   if IyQPNkszHjOERYXTafVmUWCoDBbdrg=='18' or IyQPNkszHjOERYXTafVmUWCoDBbdrg=='19' or IyQPNkszHjOERYXTafVmUWCoDBbdrg=='21':IyQPNkszHjOERYXTafVmUWCoDBbdLp+=' (%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrg)
   IyQPNkszHjOERYXTafVmUWCoDBbdgu={'plot':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'mpaa':IyQPNkszHjOERYXTafVmUWCoDBbdrg,'mediatype':'movie'}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'MOVIE','contentid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'title':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'thumbnail':IyQPNkszHjOERYXTafVmUWCoDBbdrL,'age':IyQPNkszHjOERYXTafVmUWCoDBbdrg,}
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ=[]
   IyQPNkszHjOERYXTafVmUWCoDBbdrF={'mode':'VIEW_DETAIL','values':{'videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':'movie','contenttype':IyQPNkszHjOERYXTafVmUWCoDBbdre,}}
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdrF,separators=(',',':'))
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=base64.standard_b64encode(IyQPNkszHjOERYXTafVmUWCoDBbdrG.encode()).decode('utf-8')
   IyQPNkszHjOERYXTafVmUWCoDBbdrG=IyQPNkszHjOERYXTafVmUWCoDBbdrG.replace('+','%2B')
   IyQPNkszHjOERYXTafVmUWCoDBbdrl='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrG)
   IyQPNkszHjOERYXTafVmUWCoDBbdgJ.append(('상세정보 조회',IyQPNkszHjOERYXTafVmUWCoDBbdrl))
   if IyQPNkszHjOERYXTafVmUWCoDBbdeq.get_settings_makebookmark():
    IyQPNkszHjOERYXTafVmUWCoDBbdrF={'videoid':IyQPNkszHjOERYXTafVmUWCoDBbdgc,'vidtype':'movie','vtitle':IyQPNkszHjOERYXTafVmUWCoDBbdLp,'vsubtitle':'','contenttype':'programid',}
    IyQPNkszHjOERYXTafVmUWCoDBbdrA=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdrF)
    IyQPNkszHjOERYXTafVmUWCoDBbdrA=urllib.parse.quote(IyQPNkszHjOERYXTafVmUWCoDBbdrA)
    IyQPNkszHjOERYXTafVmUWCoDBbdrl='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdrA)
    IyQPNkszHjOERYXTafVmUWCoDBbdgJ.append(('(통합) 찜 영상에 추가',IyQPNkszHjOERYXTafVmUWCoDBbdrl))
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel='',img=IyQPNkszHjOERYXTafVmUWCoDBbdrL,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdgu,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAq,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu,ContextMenu=IyQPNkszHjOERYXTafVmUWCoDBbdgJ)
  if IyQPNkszHjOERYXTafVmUWCoDBbdgA:
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['mode'] ='MOVIE_LIST_OLD' 
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['subapi']=IyQPNkszHjOERYXTafVmUWCoDBbdGS 
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['page'] =IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['orderby']=IyQPNkszHjOERYXTafVmUWCoDBbdLh
   IyQPNkszHjOERYXTafVmUWCoDBbdLp='[B]%s >>[/B]'%'다음 페이지'
   IyQPNkszHjOERYXTafVmUWCoDBbdrq=IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdrq,img=IyQPNkszHjOERYXTafVmUWCoDBbdLJ,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdAF,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  xbmcplugin.setContent(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,'movies')
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_Set_Bookmark(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdlp=urllib.parse.unquote(args.get('bm_param'))
  IyQPNkszHjOERYXTafVmUWCoDBbdlp=json.loads(IyQPNkszHjOERYXTafVmUWCoDBbdlp)
  IyQPNkszHjOERYXTafVmUWCoDBbdgc =IyQPNkszHjOERYXTafVmUWCoDBbdlp.get('videoid')
  IyQPNkszHjOERYXTafVmUWCoDBbdre =IyQPNkszHjOERYXTafVmUWCoDBbdlp.get('vidtype')
  IyQPNkszHjOERYXTafVmUWCoDBbdln =IyQPNkszHjOERYXTafVmUWCoDBbdlp.get('vtitle')
  IyQPNkszHjOERYXTafVmUWCoDBbdlw =IyQPNkszHjOERYXTafVmUWCoDBbdlp.get('vsubtitle')
  IyQPNkszHjOERYXTafVmUWCoDBbdlt=IyQPNkszHjOERYXTafVmUWCoDBbdlp.get('contenttype')
  IyQPNkszHjOERYXTafVmUWCoDBbden=xbmcgui.Dialog()
  IyQPNkszHjOERYXTafVmUWCoDBbdFe=IyQPNkszHjOERYXTafVmUWCoDBbden.yesno(__language__(30913).encode('utf8'),IyQPNkszHjOERYXTafVmUWCoDBbdln+' \n\n'+__language__(30914))
  if IyQPNkszHjOERYXTafVmUWCoDBbdFe==IyQPNkszHjOERYXTafVmUWCoDBbdAq:return
  IyQPNkszHjOERYXTafVmUWCoDBbdlM=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.GetBookmarkInfo(IyQPNkszHjOERYXTafVmUWCoDBbdgc,IyQPNkszHjOERYXTafVmUWCoDBbdre,IyQPNkszHjOERYXTafVmUWCoDBbdlt)
  IyQPNkszHjOERYXTafVmUWCoDBbdlJ=json.dumps(IyQPNkszHjOERYXTafVmUWCoDBbdlM)
  IyQPNkszHjOERYXTafVmUWCoDBbdlJ=urllib.parse.quote(IyQPNkszHjOERYXTafVmUWCoDBbdlJ)
  IyQPNkszHjOERYXTafVmUWCoDBbdrl ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(IyQPNkszHjOERYXTafVmUWCoDBbdlJ)
  xbmc.executebuiltin(IyQPNkszHjOERYXTafVmUWCoDBbdrl)
 def dp_LiveChannel_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdlu =args.get('genre')
  IyQPNkszHjOERYXTafVmUWCoDBbdGu=args.get('baseapi')
  IyQPNkszHjOERYXTafVmUWCoDBbdgS=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_LiveChannel_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdlu,IyQPNkszHjOERYXTafVmUWCoDBbdGu)
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   IyQPNkszHjOERYXTafVmUWCoDBbdli =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('channelid')
   IyQPNkszHjOERYXTafVmUWCoDBbdlS =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('studio')
   IyQPNkszHjOERYXTafVmUWCoDBbdlx=IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('tvshowtitle')
   IyQPNkszHjOERYXTafVmUWCoDBbdrL =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('thumbnail')
   IyQPNkszHjOERYXTafVmUWCoDBbdrg =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('age')
   IyQPNkszHjOERYXTafVmUWCoDBbdlc =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('epg')
   IyQPNkszHjOERYXTafVmUWCoDBbdgu={'mediatype':'episode','mpaa':IyQPNkszHjOERYXTafVmUWCoDBbdrg,'title':'%s < %s >'%(IyQPNkszHjOERYXTafVmUWCoDBbdlS,IyQPNkszHjOERYXTafVmUWCoDBbdlx),'tvshowtitle':IyQPNkszHjOERYXTafVmUWCoDBbdlx,'studio':IyQPNkszHjOERYXTafVmUWCoDBbdlS,'plot':'%s\n\n%s'%(IyQPNkszHjOERYXTafVmUWCoDBbdlS,IyQPNkszHjOERYXTafVmUWCoDBbdlc)}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'LIVE','contentid':IyQPNkszHjOERYXTafVmUWCoDBbdli}
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdlS,sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdlx,img=IyQPNkszHjOERYXTafVmUWCoDBbdrL,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdgu,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAq,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_LiveChannel_List_New(IyQPNkszHjOERYXTafVmUWCoDBbdeq,args):
  IyQPNkszHjOERYXTafVmUWCoDBbdGi =args.get('mCode')
  IyQPNkszHjOERYXTafVmUWCoDBbdGM =args.get('sCode')
  IyQPNkszHjOERYXTafVmUWCoDBbdgi=IyQPNkszHjOERYXTafVmUWCoDBbdAG(args.get('page'))
  IyQPNkszHjOERYXTafVmUWCoDBbdgS,IyQPNkszHjOERYXTafVmUWCoDBbdgA=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.Get_LiveChannel_List_New(IyQPNkszHjOERYXTafVmUWCoDBbdGi,IyQPNkszHjOERYXTafVmUWCoDBbdGM,IyQPNkszHjOERYXTafVmUWCoDBbdgi)
  for IyQPNkszHjOERYXTafVmUWCoDBbdgx in IyQPNkszHjOERYXTafVmUWCoDBbdgS:
   IyQPNkszHjOERYXTafVmUWCoDBbdli =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('channelid')
   IyQPNkszHjOERYXTafVmUWCoDBbdlS =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('studio')
   IyQPNkszHjOERYXTafVmUWCoDBbdlx=IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('tvshowtitle')
   IyQPNkszHjOERYXTafVmUWCoDBbdrL =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('thumbnail')
   IyQPNkszHjOERYXTafVmUWCoDBbdlc =IyQPNkszHjOERYXTafVmUWCoDBbdgx.get('epg')
   IyQPNkszHjOERYXTafVmUWCoDBbdgu={'mediatype':'episode','title':'%s < %s >'%(IyQPNkszHjOERYXTafVmUWCoDBbdlS,IyQPNkszHjOERYXTafVmUWCoDBbdlx),'tvshowtitle':IyQPNkszHjOERYXTafVmUWCoDBbdlx,'studio':IyQPNkszHjOERYXTafVmUWCoDBbdlS,'plot':'%s\n\n%s'%(IyQPNkszHjOERYXTafVmUWCoDBbdlS,IyQPNkszHjOERYXTafVmUWCoDBbdlc),}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'LIVE','contentid':IyQPNkszHjOERYXTafVmUWCoDBbdli,}
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdlS,sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdlx,img=IyQPNkszHjOERYXTafVmUWCoDBbdrL,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdgu,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAq,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdgA:
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={}
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['mode'] ='LIVE_LIST_NEW' 
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['mCode']=IyQPNkszHjOERYXTafVmUWCoDBbdGi
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['sCode']=IyQPNkszHjOERYXTafVmUWCoDBbdGM
   IyQPNkszHjOERYXTafVmUWCoDBbdLu['page'] =IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLp='[B]%s >>[/B]'%'다음 페이지'
   IyQPNkszHjOERYXTafVmUWCoDBbdrq=IyQPNkszHjOERYXTafVmUWCoDBbdAt(IyQPNkszHjOERYXTafVmUWCoDBbdgi+1)
   IyQPNkszHjOERYXTafVmUWCoDBbdLJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.add_dir(IyQPNkszHjOERYXTafVmUWCoDBbdLp,sublabel=IyQPNkszHjOERYXTafVmUWCoDBbdrq,img=IyQPNkszHjOERYXTafVmUWCoDBbdLJ,infoLabels=IyQPNkszHjOERYXTafVmUWCoDBbdAF,isFolder=IyQPNkszHjOERYXTafVmUWCoDBbdAl,params=IyQPNkszHjOERYXTafVmUWCoDBbdLu)
  if IyQPNkszHjOERYXTafVmUWCoDBbdAn(IyQPNkszHjOERYXTafVmUWCoDBbdgS)>0:xbmcplugin.endOfDirectory(IyQPNkszHjOERYXTafVmUWCoDBbdeq._addon_handle,cacheToDisc=IyQPNkszHjOERYXTafVmUWCoDBbdAq)
 def dp_View_Detail(IyQPNkszHjOERYXTafVmUWCoDBbdeq,IyQPNkszHjOERYXTafVmUWCoDBbdAg):
  IyQPNkszHjOERYXTafVmUWCoDBbdgc =IyQPNkszHjOERYXTafVmUWCoDBbdAg.get('videoid')
  IyQPNkszHjOERYXTafVmUWCoDBbdre =IyQPNkszHjOERYXTafVmUWCoDBbdAg.get('vidtype') 
  IyQPNkszHjOERYXTafVmUWCoDBbdlt=IyQPNkszHjOERYXTafVmUWCoDBbdAg.get('contenttype')
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log(IyQPNkszHjOERYXTafVmUWCoDBbdgc)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log(IyQPNkszHjOERYXTafVmUWCoDBbdre)
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.addon_log(IyQPNkszHjOERYXTafVmUWCoDBbdlt)
  IyQPNkszHjOERYXTafVmUWCoDBbdlM=IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.GetBookmarkInfo(IyQPNkszHjOERYXTafVmUWCoDBbdgc,IyQPNkszHjOERYXTafVmUWCoDBbdre,IyQPNkszHjOERYXTafVmUWCoDBbdlt)
  if IyQPNkszHjOERYXTafVmUWCoDBbdre=='tvshow':
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'SEASON_LIST','videoid':IyQPNkszHjOERYXTafVmUWCoDBbdlM['indexinfo']['videoid'],'vidtype':IyQPNkszHjOERYXTafVmUWCoDBbdlM['indexinfo']['vidtype'],}
   IyQPNkszHjOERYXTafVmUWCoDBbdFG='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(IyQPNkszHjOERYXTafVmUWCoDBbdLu))
  else:
   IyQPNkszHjOERYXTafVmUWCoDBbdLu={'mode':'MOVIE','contentid':IyQPNkszHjOERYXTafVmUWCoDBbdlM['indexinfo']['videoid'],'title':IyQPNkszHjOERYXTafVmUWCoDBbdlM['saveinfo']['infoLabels']['title'],'thumbnail':IyQPNkszHjOERYXTafVmUWCoDBbdlM['saveinfo']['thumbnail'],'age':IyQPNkszHjOERYXTafVmUWCoDBbdlM['saveinfo']['infoLabels']['mpaa'],}
   IyQPNkszHjOERYXTafVmUWCoDBbdFG='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(IyQPNkszHjOERYXTafVmUWCoDBbdLu))
  IyQPNkszHjOERYXTafVmUWCoDBbdLn=xbmcgui.ListItem(label=IyQPNkszHjOERYXTafVmUWCoDBbdlM['saveinfo']['title'],path=IyQPNkszHjOERYXTafVmUWCoDBbdFG)
  IyQPNkszHjOERYXTafVmUWCoDBbdLn.setArt(IyQPNkszHjOERYXTafVmUWCoDBbdlM['saveinfo']['thumbnail'])
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.Set_InfoTag(IyQPNkszHjOERYXTafVmUWCoDBbdLn.getVideoInfoTag(),IyQPNkszHjOERYXTafVmUWCoDBbdlM['saveinfo']['infoLabels'])
  if IyQPNkszHjOERYXTafVmUWCoDBbdre=='movie':
   IyQPNkszHjOERYXTafVmUWCoDBbdLn.setIsFolder(IyQPNkszHjOERYXTafVmUWCoDBbdAq)
   IyQPNkszHjOERYXTafVmUWCoDBbdLn.setProperty('IsPlayable','true')
  else:
   IyQPNkszHjOERYXTafVmUWCoDBbdLn.setIsFolder(IyQPNkszHjOERYXTafVmUWCoDBbdAl)
   IyQPNkszHjOERYXTafVmUWCoDBbdLn.setProperty('IsPlayable','false')
  IyQPNkszHjOERYXTafVmUWCoDBbden=xbmcgui.Dialog()
  IyQPNkszHjOERYXTafVmUWCoDBbden.info(IyQPNkszHjOERYXTafVmUWCoDBbdLn)
 def wavve_main(IyQPNkszHjOERYXTafVmUWCoDBbdeq):
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.WavveObj.KodiVersion=IyQPNkszHjOERYXTafVmUWCoDBbdAG(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  IyQPNkszHjOERYXTafVmUWCoDBbdAe=IyQPNkszHjOERYXTafVmUWCoDBbdeq.main_params.get('params')
  if IyQPNkszHjOERYXTafVmUWCoDBbdAe:
   IyQPNkszHjOERYXTafVmUWCoDBbdAL =base64.standard_b64decode(IyQPNkszHjOERYXTafVmUWCoDBbdAe).decode('utf-8')
   IyQPNkszHjOERYXTafVmUWCoDBbdAL =json.loads(IyQPNkszHjOERYXTafVmUWCoDBbdAL)
   IyQPNkszHjOERYXTafVmUWCoDBbdgF =IyQPNkszHjOERYXTafVmUWCoDBbdAL.get('mode')
   IyQPNkszHjOERYXTafVmUWCoDBbdAg =IyQPNkszHjOERYXTafVmUWCoDBbdAL.get('values')
  else:
   IyQPNkszHjOERYXTafVmUWCoDBbdgF=IyQPNkszHjOERYXTafVmUWCoDBbdeq.main_params.get('mode',IyQPNkszHjOERYXTafVmUWCoDBbdAF)
   IyQPNkszHjOERYXTafVmUWCoDBbdAg=IyQPNkszHjOERYXTafVmUWCoDBbdeq.main_params
  if IyQPNkszHjOERYXTafVmUWCoDBbdgF=='LOGOUT':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.logout()
   return
  IyQPNkszHjOERYXTafVmUWCoDBbdeq.login_main()
  if IyQPNkszHjOERYXTafVmUWCoDBbdgF is IyQPNkszHjOERYXTafVmUWCoDBbdAF:
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Main_List()
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF in['LIVE','VOD','MOVIE','SPORTS']:
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.play_VIDEO(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='LIVE_CATAGORY_OLD':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_LiveCatagory_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='MAIN_CATAGORY':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_MainCatagory_List(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='SUPERSECTION_LIST':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_SuperSection_List(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='PROGRAM_LIST_OLD':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Program_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='PROGRAM_LIST_NEW':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Program_List_New(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='SEASON_LIST':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Season_List(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='EPISODE_LIST':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Episode_List(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='MOVIE_LIST_NEW':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Movie_List_New(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='MOVIE_LIST_OLD':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Movie_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='LIVE_LIST_OLD':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_LiveChannel_List_Old(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='LIVE_LIST_NEW':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_LiveChannel_List_New(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='ORDER_BY':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_setEpOrderby(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='SEARCH_GROUP':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Search_Group(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF in['SEARCH_LIST','LOCAL_SEARCH']:
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Search_List(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='WATCH_GROUP':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Watch_Group(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='WATCH_LIST':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Watch_List(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='SET_BOOKMARK':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Set_Bookmark(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_History_Remove(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF in['TOTAL_SEARCH','TOTAL_HISTORY']:
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Global_Search(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='SEARCH_HISTORY':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Search_History(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='MENU_BOOKMARK':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_Bookmark_Menu(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='VIEW_DETAIL':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_View_Detail(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  elif IyQPNkszHjOERYXTafVmUWCoDBbdgF=='SUB_CATAGORY':
   IyQPNkszHjOERYXTafVmUWCoDBbdeq.dp_SubCatagory_List(IyQPNkszHjOERYXTafVmUWCoDBbdAg)
  else:
   IyQPNkszHjOERYXTafVmUWCoDBbdAF
# Created by pyminifier (https://github.com/liftoff/pyminifier)
