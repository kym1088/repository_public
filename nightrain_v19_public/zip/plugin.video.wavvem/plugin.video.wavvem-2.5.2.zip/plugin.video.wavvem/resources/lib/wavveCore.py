__author__="NightRain"
hEPKQqindrBTxwtzHVUOXoDMplkNYy=None
hEPKQqindrBTxwtzHVUOXoDMplkNYv=object
hEPKQqindrBTxwtzHVUOXoDMplkNYu=print
hEPKQqindrBTxwtzHVUOXoDMplkNYA=str
hEPKQqindrBTxwtzHVUOXoDMplkNYG=False
hEPKQqindrBTxwtzHVUOXoDMplkNYa=open
hEPKQqindrBTxwtzHVUOXoDMplkNYF=True
hEPKQqindrBTxwtzHVUOXoDMplkNYI=range
hEPKQqindrBTxwtzHVUOXoDMplkNYJ=len
hEPKQqindrBTxwtzHVUOXoDMplkNYS=Exception
hEPKQqindrBTxwtzHVUOXoDMplkNYg=dict
hEPKQqindrBTxwtzHVUOXoDMplkNYj=int
import urllib
import re
import json
import sys
import requests
import datetime
import base64
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
import httpx
try:
 import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
 __addon__=xbmcaddon.Addon()
 __language__ =__addon__.getLocalizedString
 __profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 __version__=__addon__.getAddonInfo('version')
 __addonid__=__addon__.getAddonInfo('id')
 __addonname__=__addon__.getAddonInfo('name')
except:
 hEPKQqindrBTxwtzHVUOXoDMplkNYy
def addon_log(string):
 try:
  hEPKQqindrBTxwtzHVUOXoDMplkNcf=string.encode('utf-8','ignore')
  hEPKQqindrBTxwtzHVUOXoDMplkNcW=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,hEPKQqindrBTxwtzHVUOXoDMplkNcf),level=hEPKQqindrBTxwtzHVUOXoDMplkNcW)
 except:
  hEPKQqindrBTxwtzHVUOXoDMplkNcf='addonException: addon_log'
hEPKQqindrBTxwtzHVUOXoDMplkNcs =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
hEPKQqindrBTxwtzHVUOXoDMplkNcL={'GN57':'variety','GN56':'drama','GN59':'movie','GN21':'animation',}
class hEPKQqindrBTxwtzHVUOXoDMplkNcR(hEPKQqindrBTxwtzHVUOXoDMplkNYv):
 def __init__(hEPKQqindrBTxwtzHVUOXoDMplkNcY):
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN='https://apis.wavve.com'
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV ={}
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.Init_WV_Total()
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.DEVICE ='pc'
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.DRM ='wm'
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.PARTNER ='pooq'
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.POOQZONE ='none'
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.REGION ='kor'
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.TARGETAGE ='all'
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG ='https://'
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.LIST_LIMIT=40 
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.EP_LIMIT =30 
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.MV_LIMIT =24 
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.SEARCH_LIMIT=20 
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36'
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.DEFAULT_HEADER={'user-agent':hEPKQqindrBTxwtzHVUOXoDMplkNcY.USER_AGENT}
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.KodiVersion=20
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV_SESSION_COOKIES1=''
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV_SESSION_COOKIES2=''
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV_SESSION_COOKIES3=''
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.COOKIE_FILE_NAME =''
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV_STREAM_FILENAME =''
 def Init_WV_Total(hEPKQqindrBTxwtzHVUOXoDMplkNcY):
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV={'account':{},'cookies':{},}
 def make_auth_header(hEPKQqindrBTxwtzHVUOXoDMplkNcY):
  return{'authorization':'Bearer {}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential']),'wavve-credential':hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential'],}
 def callRequestCookies(hEPKQqindrBTxwtzHVUOXoDMplkNcY,jobtype,hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNYy,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy):
  hEPKQqindrBTxwtzHVUOXoDMplkNcm=hEPKQqindrBTxwtzHVUOXoDMplkNcY.DEFAULT_HEADER
  if headers:hEPKQqindrBTxwtzHVUOXoDMplkNcm.update(headers)
  if jobtype=='Get':
   hEPKQqindrBTxwtzHVUOXoDMplkNcC=httpx.get(hEPKQqindrBTxwtzHVUOXoDMplkNRA,params=params,headers=hEPKQqindrBTxwtzHVUOXoDMplkNcm,cookies=cookies)
  else:
   hEPKQqindrBTxwtzHVUOXoDMplkNcC=httpx.post(hEPKQqindrBTxwtzHVUOXoDMplkNRA,json=payload,params=params,headers=hEPKQqindrBTxwtzHVUOXoDMplkNcm,cookies=cookies)
  hEPKQqindrBTxwtzHVUOXoDMplkNYu(hEPKQqindrBTxwtzHVUOXoDMplkNYA(hEPKQqindrBTxwtzHVUOXoDMplkNcC.status_code)+' - '+hEPKQqindrBTxwtzHVUOXoDMplkNYA(hEPKQqindrBTxwtzHVUOXoDMplkNcC.url))
  return hEPKQqindrBTxwtzHVUOXoDMplkNcC
 def callRequestCookies_req(hEPKQqindrBTxwtzHVUOXoDMplkNcY,jobtype,hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNYy,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy):
  hEPKQqindrBTxwtzHVUOXoDMplkNcm=hEPKQqindrBTxwtzHVUOXoDMplkNcY.DEFAULT_HEADER
  if headers:hEPKQqindrBTxwtzHVUOXoDMplkNcm.update(headers)
  if jobtype=='Get':
   hEPKQqindrBTxwtzHVUOXoDMplkNcC=requests.get(hEPKQqindrBTxwtzHVUOXoDMplkNRA,params=params,headers=hEPKQqindrBTxwtzHVUOXoDMplkNcm,cookies=cookies)
  else:
   hEPKQqindrBTxwtzHVUOXoDMplkNcC=requests.post(hEPKQqindrBTxwtzHVUOXoDMplkNRA,json=payload,params=params,headers=hEPKQqindrBTxwtzHVUOXoDMplkNcm,cookies=cookies)
  hEPKQqindrBTxwtzHVUOXoDMplkNYu(hEPKQqindrBTxwtzHVUOXoDMplkNYA(hEPKQqindrBTxwtzHVUOXoDMplkNcC.status_code)+' - '+hEPKQqindrBTxwtzHVUOXoDMplkNYA(hEPKQqindrBTxwtzHVUOXoDMplkNcC.url))
  return hEPKQqindrBTxwtzHVUOXoDMplkNcC 
 def JsonFile_Save(hEPKQqindrBTxwtzHVUOXoDMplkNcY,filename,hEPKQqindrBTxwtzHVUOXoDMplkNce):
  if filename=='':return hEPKQqindrBTxwtzHVUOXoDMplkNYG
  try:
   fp=hEPKQqindrBTxwtzHVUOXoDMplkNYa(filename,'w',-1,'utf-8')
   json.dump(hEPKQqindrBTxwtzHVUOXoDMplkNce,fp,indent=4,ensure_ascii=hEPKQqindrBTxwtzHVUOXoDMplkNYG)
   fp.close()
  except:
   return hEPKQqindrBTxwtzHVUOXoDMplkNYG
  return hEPKQqindrBTxwtzHVUOXoDMplkNYF
 def JsonFile_Load(hEPKQqindrBTxwtzHVUOXoDMplkNcY,filename):
  if filename=='':return{}
  try:
   fp=hEPKQqindrBTxwtzHVUOXoDMplkNYa(filename,'r',-1,'utf-8')
   hEPKQqindrBTxwtzHVUOXoDMplkNcv=json.load(fp)
   fp.close()
  except:
   return{}
  return hEPKQqindrBTxwtzHVUOXoDMplkNcv
 def TextFile_Save(hEPKQqindrBTxwtzHVUOXoDMplkNcY,filename,resText):
  if filename=='':return hEPKQqindrBTxwtzHVUOXoDMplkNYG
  try:
   fp=hEPKQqindrBTxwtzHVUOXoDMplkNYa(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return hEPKQqindrBTxwtzHVUOXoDMplkNYG
  return hEPKQqindrBTxwtzHVUOXoDMplkNYF
 def Save_session_acount(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNcu,hEPKQqindrBTxwtzHVUOXoDMplkNcA,hEPKQqindrBTxwtzHVUOXoDMplkNcG):
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['account']['wvid']=base64.standard_b64encode(hEPKQqindrBTxwtzHVUOXoDMplkNcu.encode()).decode('utf-8')
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['account']['wvpw']=base64.standard_b64encode(hEPKQqindrBTxwtzHVUOXoDMplkNcA.encode()).decode('utf-8')
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['account']['wvpf']=hEPKQqindrBTxwtzHVUOXoDMplkNcG 
 def Load_session_acount(hEPKQqindrBTxwtzHVUOXoDMplkNcY):
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNcu=base64.standard_b64decode(hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['account']['wvid']).decode('utf-8')
   hEPKQqindrBTxwtzHVUOXoDMplkNcA=base64.standard_b64decode(hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['account']['wvpw']).decode('utf-8')
   hEPKQqindrBTxwtzHVUOXoDMplkNcG=hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['account']['wvpf']
  except:
   return '','',0
  return hEPKQqindrBTxwtzHVUOXoDMplkNcu,hEPKQqindrBTxwtzHVUOXoDMplkNcA,hEPKQqindrBTxwtzHVUOXoDMplkNcG
 def GetDefaultParams(hEPKQqindrBTxwtzHVUOXoDMplkNcY):
  hEPKQqindrBTxwtzHVUOXoDMplkNca={'apikey':hEPKQqindrBTxwtzHVUOXoDMplkNcY.APIKEY,'device':hEPKQqindrBTxwtzHVUOXoDMplkNcY.DEVICE,'partner':hEPKQqindrBTxwtzHVUOXoDMplkNcY.PARTNER,'region':hEPKQqindrBTxwtzHVUOXoDMplkNcY.REGION,'targetage':hEPKQqindrBTxwtzHVUOXoDMplkNcY.TARGETAGE,'pooqzone':hEPKQqindrBTxwtzHVUOXoDMplkNcY.POOQZONE,'drm':hEPKQqindrBTxwtzHVUOXoDMplkNcY.DRM,}
  return hEPKQqindrBTxwtzHVUOXoDMplkNca
 def GetDefaultParams_AND(hEPKQqindrBTxwtzHVUOXoDMplkNcY):
  hEPKQqindrBTxwtzHVUOXoDMplkNca={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential'],'device':'ott','drm':hEPKQqindrBTxwtzHVUOXoDMplkNcY.DRM,'partner':hEPKQqindrBTxwtzHVUOXoDMplkNcY.PARTNER,'pooqzone':hEPKQqindrBTxwtzHVUOXoDMplkNcY.POOQZONE,'region':hEPKQqindrBTxwtzHVUOXoDMplkNcY.REGION,'targetage':hEPKQqindrBTxwtzHVUOXoDMplkNcY.TARGETAGE,}
  return hEPKQqindrBTxwtzHVUOXoDMplkNca
 def GetGUID(hEPKQqindrBTxwtzHVUOXoDMplkNcY,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   hEPKQqindrBTxwtzHVUOXoDMplkNcF=hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   hEPKQqindrBTxwtzHVUOXoDMplkNcI=GenerateRandomString(5)
   hEPKQqindrBTxwtzHVUOXoDMplkNcJ=hEPKQqindrBTxwtzHVUOXoDMplkNcI+media+hEPKQqindrBTxwtzHVUOXoDMplkNcF
   return hEPKQqindrBTxwtzHVUOXoDMplkNcJ
  def GenerateRandomString(num):
   from random import randint
   hEPKQqindrBTxwtzHVUOXoDMplkNcS=""
   for i in hEPKQqindrBTxwtzHVUOXoDMplkNYI(0,num):
    s=hEPKQqindrBTxwtzHVUOXoDMplkNYA(randint(1,5))
    hEPKQqindrBTxwtzHVUOXoDMplkNcS+=s
   return hEPKQqindrBTxwtzHVUOXoDMplkNcS
  if guidType==3:
   hEPKQqindrBTxwtzHVUOXoDMplkNcJ=guid_str
  else:
   hEPKQqindrBTxwtzHVUOXoDMplkNcJ=GenerateID(guid_str)
  hEPKQqindrBTxwtzHVUOXoDMplkNcg=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetHash(hEPKQqindrBTxwtzHVUOXoDMplkNcJ)
  if guidType in[2,3]:
   hEPKQqindrBTxwtzHVUOXoDMplkNcg='%s-%s-%s-%s-%s'%(hEPKQqindrBTxwtzHVUOXoDMplkNcg[:8],hEPKQqindrBTxwtzHVUOXoDMplkNcg[8:12],hEPKQqindrBTxwtzHVUOXoDMplkNcg[12:16],hEPKQqindrBTxwtzHVUOXoDMplkNcg[16:20],hEPKQqindrBTxwtzHVUOXoDMplkNcg[20:])
  return hEPKQqindrBTxwtzHVUOXoDMplkNcg
 def GetHash(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return hEPKQqindrBTxwtzHVUOXoDMplkNYA(m.hexdigest())
 def CheckQuality(hEPKQqindrBTxwtzHVUOXoDMplkNcY,sel_qt,qt_list):
  hEPKQqindrBTxwtzHVUOXoDMplkNcj=0
  for hEPKQqindrBTxwtzHVUOXoDMplkNcb in qt_list:
   if sel_qt>=hEPKQqindrBTxwtzHVUOXoDMplkNcb:return hEPKQqindrBTxwtzHVUOXoDMplkNcb
   hEPKQqindrBTxwtzHVUOXoDMplkNcj=hEPKQqindrBTxwtzHVUOXoDMplkNcb
  return hEPKQqindrBTxwtzHVUOXoDMplkNcj
 def Get_Now_Datetime(hEPKQqindrBTxwtzHVUOXoDMplkNcY):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNcY,in_text):
  hEPKQqindrBTxwtzHVUOXoDMplkNRf=in_text.replace('&lt;','<').replace('&gt;','>')
  hEPKQqindrBTxwtzHVUOXoDMplkNRf=hEPKQqindrBTxwtzHVUOXoDMplkNRf.replace('<br>','\n')
  hEPKQqindrBTxwtzHVUOXoDMplkNRf=hEPKQqindrBTxwtzHVUOXoDMplkNRf.replace('$O$','')
  hEPKQqindrBTxwtzHVUOXoDMplkNRf=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',hEPKQqindrBTxwtzHVUOXoDMplkNRf)
  hEPKQqindrBTxwtzHVUOXoDMplkNRf=hEPKQqindrBTxwtzHVUOXoDMplkNRf.lstrip('#')
  return hEPKQqindrBTxwtzHVUOXoDMplkNRf
 def make_str_ToCookie(hEPKQqindrBTxwtzHVUOXoDMplkNcY,cookieStr):
  hEPKQqindrBTxwtzHVUOXoDMplkNRW={}
  for hEPKQqindrBTxwtzHVUOXoDMplkNRs in cookieStr.split(';'):
   hEPKQqindrBTxwtzHVUOXoDMplkNRL=hEPKQqindrBTxwtzHVUOXoDMplkNRs.split('=')
   hEPKQqindrBTxwtzHVUOXoDMplkNRW[hEPKQqindrBTxwtzHVUOXoDMplkNRL[0]]=hEPKQqindrBTxwtzHVUOXoDMplkNRL[1]
  return hEPKQqindrBTxwtzHVUOXoDMplkNRW 
 def make_stream_header(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNRy,hEPKQqindrBTxwtzHVUOXoDMplkNRW):
  hEPKQqindrBTxwtzHVUOXoDMplkNRY=''
  if hEPKQqindrBTxwtzHVUOXoDMplkNRW not in[{},hEPKQqindrBTxwtzHVUOXoDMplkNYy,'']:
   hEPKQqindrBTxwtzHVUOXoDMplkNRm=hEPKQqindrBTxwtzHVUOXoDMplkNYJ(hEPKQqindrBTxwtzHVUOXoDMplkNRW)
   for hEPKQqindrBTxwtzHVUOXoDMplkNRC,hEPKQqindrBTxwtzHVUOXoDMplkNRe in hEPKQqindrBTxwtzHVUOXoDMplkNRW.items():
    hEPKQqindrBTxwtzHVUOXoDMplkNRY+='{}={}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNRC,hEPKQqindrBTxwtzHVUOXoDMplkNRe)
    hEPKQqindrBTxwtzHVUOXoDMplkNRm+=-1
    if hEPKQqindrBTxwtzHVUOXoDMplkNRm>0:hEPKQqindrBTxwtzHVUOXoDMplkNRY+='; '
   hEPKQqindrBTxwtzHVUOXoDMplkNRy['cookie']=hEPKQqindrBTxwtzHVUOXoDMplkNRY
  hEPKQqindrBTxwtzHVUOXoDMplkNRv=''
  i=0
  for hEPKQqindrBTxwtzHVUOXoDMplkNRC,hEPKQqindrBTxwtzHVUOXoDMplkNRe in hEPKQqindrBTxwtzHVUOXoDMplkNRy.items():
   i=i+1
   if i>1:hEPKQqindrBTxwtzHVUOXoDMplkNRv+='&'
   hEPKQqindrBTxwtzHVUOXoDMplkNRv+='{}={}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNRC,urllib.parse.quote(hEPKQqindrBTxwtzHVUOXoDMplkNRe))
  return hEPKQqindrBTxwtzHVUOXoDMplkNRv
 def GetCredential(hEPKQqindrBTxwtzHVUOXoDMplkNcY,user_id,user_pw,user_pf):
  hEPKQqindrBTxwtzHVUOXoDMplkNRu=hEPKQqindrBTxwtzHVUOXoDMplkNYG
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+ '/login'
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRy={'content-type':'application/json',}
   hEPKQqindrBTxwtzHVUOXoDMplkNRG={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Post',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNRG,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNRy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   addon_log('url : {}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNRA))
   addon_log('res : {}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text))
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential']=hEPKQqindrBTxwtzHVUOXoDMplkNRF['credential']
   if user_pf!=0:
    hEPKQqindrBTxwtzHVUOXoDMplkNRG={'id':hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential'],'password':'','profile':hEPKQqindrBTxwtzHVUOXoDMplkNYA(user_pf),'pushid':'','type':'credential'}
    hEPKQqindrBTxwtzHVUOXoDMplkNca =hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams() 
    hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Post',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNRG,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
    hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
    hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential']=hEPKQqindrBTxwtzHVUOXoDMplkNRF['credential']
   hEPKQqindrBTxwtzHVUOXoDMplkNRI=user_id+hEPKQqindrBTxwtzHVUOXoDMplkNYA(user_pf) 
   hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['uuid']=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetGUID(guid_str=hEPKQqindrBTxwtzHVUOXoDMplkNRI,guidType=3)
   hEPKQqindrBTxwtzHVUOXoDMplkNRu=hEPKQqindrBTxwtzHVUOXoDMplkNYF
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   hEPKQqindrBTxwtzHVUOXoDMplkNcY.Init_WV_Total()
  return hEPKQqindrBTxwtzHVUOXoDMplkNRu
 def GetCredential_new(hEPKQqindrBTxwtzHVUOXoDMplkNcY,user_id,user_pw,user_pf):
  hEPKQqindrBTxwtzHVUOXoDMplkNRu=hEPKQqindrBTxwtzHVUOXoDMplkNYG
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='https://account-api.wavve.com/v1/signin/wavve'
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRy={'wavve-credential':'none','content-type':'application/json',}
   hEPKQqindrBTxwtzHVUOXoDMplkNRG={'id':user_id,'password':user_pw,'device':'pc','type':'wavve',}
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Post',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNRG,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNRy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   addon_log('url : {}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNRA))
   addon_log('res : {}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text))
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential']=hEPKQqindrBTxwtzHVUOXoDMplkNRF['credential']
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='https://account-api.wavve.com/v1/signin'
   hEPKQqindrBTxwtzHVUOXoDMplkNRy={'wavve-credential':hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential'],'content-type':'application/json',}
   hEPKQqindrBTxwtzHVUOXoDMplkNRG={'id':hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential'],'profile':hEPKQqindrBTxwtzHVUOXoDMplkNYA(user_pf),'device':'pc','type':'credential',}
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Post',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNRG,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNRy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential']=hEPKQqindrBTxwtzHVUOXoDMplkNRF['credential']
   hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['uuid'] =hEPKQqindrBTxwtzHVUOXoDMplkNRF['device_id']
   hEPKQqindrBTxwtzHVUOXoDMplkNRu=hEPKQqindrBTxwtzHVUOXoDMplkNYF
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   hEPKQqindrBTxwtzHVUOXoDMplkNcY.Init_WV_Total()
  return hEPKQqindrBTxwtzHVUOXoDMplkNRu
 def GetIssue(hEPKQqindrBTxwtzHVUOXoDMplkNcY):
  hEPKQqindrBTxwtzHVUOXoDMplkNRJ=hEPKQqindrBTxwtzHVUOXoDMplkNYG
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/guid/issue'
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNRS=hEPKQqindrBTxwtzHVUOXoDMplkNRF['guid']
   hEPKQqindrBTxwtzHVUOXoDMplkNRg=hEPKQqindrBTxwtzHVUOXoDMplkNRF['guidtimestamp']
   if hEPKQqindrBTxwtzHVUOXoDMplkNRS:hEPKQqindrBTxwtzHVUOXoDMplkNRJ=hEPKQqindrBTxwtzHVUOXoDMplkNYF
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   hEPKQqindrBTxwtzHVUOXoDMplkNRS='none'
   hEPKQqindrBTxwtzHVUOXoDMplkNRg='none' 
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.guid=hEPKQqindrBTxwtzHVUOXoDMplkNRS
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.guidtimestamp=hEPKQqindrBTxwtzHVUOXoDMplkNRg
  return hEPKQqindrBTxwtzHVUOXoDMplkNRJ
 def Baseapi_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNfR):
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRj =urllib.parse.urlsplit(hEPKQqindrBTxwtzHVUOXoDMplkNfR)
   if hEPKQqindrBTxwtzHVUOXoDMplkNRj.netloc=='':
    hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNRj.netloc+hEPKQqindrBTxwtzHVUOXoDMplkNRj.path
   else:
    hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNRj.scheme+'://'+hEPKQqindrBTxwtzHVUOXoDMplkNRj.netloc+hEPKQqindrBTxwtzHVUOXoDMplkNRj.path
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNYg(urllib.parse.parse_qsl(hEPKQqindrBTxwtzHVUOXoDMplkNRj.query))
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return '',{}
  return hEPKQqindrBTxwtzHVUOXoDMplkNRA,hEPKQqindrBTxwtzHVUOXoDMplkNca
 def GetSupermultiUrl(hEPKQqindrBTxwtzHVUOXoDMplkNcY,sCode,sIndex='0'):
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/cf/supermultisections/'+sCode
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNRb=hEPKQqindrBTxwtzHVUOXoDMplkNRF['multisectionlist'][hEPKQqindrBTxwtzHVUOXoDMplkNYj(sIndex)]['eventlist'][1]['url']
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return ''
  return hEPKQqindrBTxwtzHVUOXoDMplkNRb
 def Get_LiveCatagory_List_Old(hEPKQqindrBTxwtzHVUOXoDMplkNcY,sCode,sIndex='0'):
  hEPKQqindrBTxwtzHVUOXoDMplkNfc=[]
  hEPKQqindrBTxwtzHVUOXoDMplkNfR =hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetSupermultiUrl(sCode,sIndex)
  (hEPKQqindrBTxwtzHVUOXoDMplkNRA,hEPKQqindrBTxwtzHVUOXoDMplkNca)=hEPKQqindrBTxwtzHVUOXoDMplkNcY.Baseapi_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNfR)
  if hEPKQqindrBTxwtzHVUOXoDMplkNRA=='':return hEPKQqindrBTxwtzHVUOXoDMplkNfc,''
  addon_log('Get_LiveCatagory_List url : {}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNRA))
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if not('filter_item_list' in hEPKQqindrBTxwtzHVUOXoDMplkNRF['filter']['filterlist'][0]):return[],''
   hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['filter']['filterlist'][0]['filter_item_list']
   for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
    hEPKQqindrBTxwtzHVUOXoDMplkNfL={'title':hEPKQqindrBTxwtzHVUOXoDMplkNfs['title'],'genre':hEPKQqindrBTxwtzHVUOXoDMplkNfs['api_parameters'][hEPKQqindrBTxwtzHVUOXoDMplkNfs['api_parameters'].index('=')+1:]}
    hEPKQqindrBTxwtzHVUOXoDMplkNfc.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return[],''
  return hEPKQqindrBTxwtzHVUOXoDMplkNfc,hEPKQqindrBTxwtzHVUOXoDMplkNfR
 def Get_MainCatagory_List(hEPKQqindrBTxwtzHVUOXoDMplkNcY,sCode,sIndex,sType):
  hEPKQqindrBTxwtzHVUOXoDMplkNfc=[]
  hEPKQqindrBTxwtzHVUOXoDMplkNRA='https://apis.wavve.com/es/category/launcher-band'
  hEPKQqindrBTxwtzHVUOXoDMplkNca={'uitype':sCode,'uiparent':'GN52-'+sCode,'uirank':sIndex,'broadcastid':sCode,'offset':'0','limit':'20','uicode':sCode,'mtype':'N','ctype':sType,'orderby':'default',}
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if not('celllist' in hEPKQqindrBTxwtzHVUOXoDMplkNRF['band']):return[]
   hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['band']['celllist']
   for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
    hEPKQqindrBTxwtzHVUOXoDMplkNfY =hEPKQqindrBTxwtzHVUOXoDMplkNfs['event_list'][1]['url']
    (hEPKQqindrBTxwtzHVUOXoDMplkNfm,hEPKQqindrBTxwtzHVUOXoDMplkNfC)=hEPKQqindrBTxwtzHVUOXoDMplkNcY.Baseapi_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNfY)
    hEPKQqindrBTxwtzHVUOXoDMplkNfL={'title':hEPKQqindrBTxwtzHVUOXoDMplkNfs['title_list'][0]['text'],'suburl':hEPKQqindrBTxwtzHVUOXoDMplkNfm,'subapi':hEPKQqindrBTxwtzHVUOXoDMplkNfC.get('api'),'subtype':'catagory' if hEPKQqindrBTxwtzHVUOXoDMplkNfC else 'supersection'}
    hEPKQqindrBTxwtzHVUOXoDMplkNfc.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return[]
  return hEPKQqindrBTxwtzHVUOXoDMplkNfc
 def Get_SuperMultiSection_List(hEPKQqindrBTxwtzHVUOXoDMplkNcY,subapi_text):
  hEPKQqindrBTxwtzHVUOXoDMplkNfc=[]
  if '/multiband/' in subapi_text: 
   hEPKQqindrBTxwtzHVUOXoDMplkNRA=subapi_text 
   hEPKQqindrBTxwtzHVUOXoDMplkNca={'client':'40'}
  else:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA=subapi_text 
   hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNRA.replace('www.wavve.com','apis.wavve.com').replace('supermultisection','v1/multiband')
   hEPKQqindrBTxwtzHVUOXoDMplkNca={}
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if not('multisectionlist' in hEPKQqindrBTxwtzHVUOXoDMplkNRF):return[]
   hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['multisectionlist']
   for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
    hEPKQqindrBTxwtzHVUOXoDMplkNfe=hEPKQqindrBTxwtzHVUOXoDMplkNfs['title']
    if hEPKQqindrBTxwtzHVUOXoDMplkNYJ(hEPKQqindrBTxwtzHVUOXoDMplkNfe)==0:continue
    if hEPKQqindrBTxwtzHVUOXoDMplkNfe=='minor':continue
    if re.search(u'베너',hEPKQqindrBTxwtzHVUOXoDMplkNfe):continue
    if re.search(u'배너',hEPKQqindrBTxwtzHVUOXoDMplkNfe):continue 
    if hEPKQqindrBTxwtzHVUOXoDMplkNfs['force_refresh']=='y':continue
    if hEPKQqindrBTxwtzHVUOXoDMplkNYJ(hEPKQqindrBTxwtzHVUOXoDMplkNfs['eventlist'])>=3:
     hEPKQqindrBTxwtzHVUOXoDMplkNfC =hEPKQqindrBTxwtzHVUOXoDMplkNfs['eventlist'][2]['url']
    else:
     hEPKQqindrBTxwtzHVUOXoDMplkNfC =hEPKQqindrBTxwtzHVUOXoDMplkNfs['eventlist'][1]['url']
    hEPKQqindrBTxwtzHVUOXoDMplkNfy=hEPKQqindrBTxwtzHVUOXoDMplkNfs['cell_type']
    if hEPKQqindrBTxwtzHVUOXoDMplkNfy=='band_2':
     if hEPKQqindrBTxwtzHVUOXoDMplkNfC.find('channellist=')>=0:
      hEPKQqindrBTxwtzHVUOXoDMplkNfy='band_live'
    hEPKQqindrBTxwtzHVUOXoDMplkNfL={'title':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNfe),'subapi':hEPKQqindrBTxwtzHVUOXoDMplkNfC,'cell_type':hEPKQqindrBTxwtzHVUOXoDMplkNfy}
    hEPKQqindrBTxwtzHVUOXoDMplkNfc.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return[]
  return hEPKQqindrBTxwtzHVUOXoDMplkNfc
 def Get_SubCatagory_List(hEPKQqindrBTxwtzHVUOXoDMplkNcY,mCode):
  hEPKQqindrBTxwtzHVUOXoDMplkNfc=[]
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='https://apis.wavve.com/v1/category/{}'.format(mCode)
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if 'data' not in hEPKQqindrBTxwtzHVUOXoDMplkNRF:return[]
   hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['layout']['category']['sub_category_list']
   for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
    hEPKQqindrBTxwtzHVUOXoDMplkNfL={'mCode':mCode,'sCode':hEPKQqindrBTxwtzHVUOXoDMplkNfs['code'],'title':hEPKQqindrBTxwtzHVUOXoDMplkNfs['element_list'][0]['property']['text'],}
    hEPKQqindrBTxwtzHVUOXoDMplkNfc.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return[]
  return hEPKQqindrBTxwtzHVUOXoDMplkNfc
 def Get_Program_List_Old(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNfR,page_int=1,orderby='-'):
  hEPKQqindrBTxwtzHVUOXoDMplkNfv=[]
  hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYG
  (hEPKQqindrBTxwtzHVUOXoDMplkNRA,hEPKQqindrBTxwtzHVUOXoDMplkNca)=hEPKQqindrBTxwtzHVUOXoDMplkNcY.Baseapi_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNfR)
  if hEPKQqindrBTxwtzHVUOXoDMplkNRA=='':return hEPKQqindrBTxwtzHVUOXoDMplkNfv,hEPKQqindrBTxwtzHVUOXoDMplkNfu
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNca['limit'] =hEPKQqindrBTxwtzHVUOXoDMplkNcY.LIST_LIMIT
   hEPKQqindrBTxwtzHVUOXoDMplkNca['offset']=hEPKQqindrBTxwtzHVUOXoDMplkNYA((page_int-1)*hEPKQqindrBTxwtzHVUOXoDMplkNcY.LIST_LIMIT)
   if orderby not in['-','',hEPKQqindrBTxwtzHVUOXoDMplkNYy]:
    hEPKQqindrBTxwtzHVUOXoDMplkNca['orderby']=orderby 
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['context_list']
   for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
    hEPKQqindrBTxwtzHVUOXoDMplkNfL={'title':hEPKQqindrBTxwtzHVUOXoDMplkNfs['program']['title'],'thumbnail':hEPKQqindrBTxwtzHVUOXoDMplkNfs['program']['vertical_logo_y_image'],'videoid':hEPKQqindrBTxwtzHVUOXoDMplkNfs['context_id'],'vidtype':'contentid',}
    hEPKQqindrBTxwtzHVUOXoDMplkNfv.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
   if hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['pagecount'])>page_int:
    hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYF
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   addon_log('error : {}'.format(exception))
   return[],hEPKQqindrBTxwtzHVUOXoDMplkNYG
  return hEPKQqindrBTxwtzHVUOXoDMplkNfv,hEPKQqindrBTxwtzHVUOXoDMplkNfu
 def Get_Program_List_new(hEPKQqindrBTxwtzHVUOXoDMplkNcY,mCode,sCode,page_int=1):
  hEPKQqindrBTxwtzHVUOXoDMplkNfv=[]
  hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYG
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='https://apis.wavve.com/v1/category/{}/sub/{}'.format(mCode,sCode)
   hEPKQqindrBTxwtzHVUOXoDMplkNRy={'accept':'application/json, text/plain, */*','accept-encoding':'gzip, deflate, br, zstd','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','authorization':'Bearer {}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential']),'cache-control':'no-cache','origin':'https://www.wavve.com','pragma':'no-cache','priority':'u=1, i','referer':'https://www.wavve.com/','wavve-credential':hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential'],}
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNca['guid']=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetGUID(guidType=3)
   hEPKQqindrBTxwtzHVUOXoDMplkNca['client_version']='7.2.60'
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNRy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNfR =hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['layout']['catalog']['catalog_list'][0]['element_list'][0]['action_list'][0]['execute']['data']['url']
   (hEPKQqindrBTxwtzHVUOXoDMplkNRA,hEPKQqindrBTxwtzHVUOXoDMplkNca)=hEPKQqindrBTxwtzHVUOXoDMplkNcY.Baseapi_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNfR)
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(hEPKQqindrBTxwtzHVUOXoDMplkNca)
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(hEPKQqindrBTxwtzHVUOXoDMplkNRA)
   if 'allprograms' in hEPKQqindrBTxwtzHVUOXoDMplkNRA:
    hEPKQqindrBTxwtzHVUOXoDMplkNRA='https://apis.wavve.com/v1/catalog'
   hEPKQqindrBTxwtzHVUOXoDMplkNca['limit'] =hEPKQqindrBTxwtzHVUOXoDMplkNcY.LIST_LIMIT
   hEPKQqindrBTxwtzHVUOXoDMplkNca['offset']=hEPKQqindrBTxwtzHVUOXoDMplkNYA((page_int-1)*hEPKQqindrBTxwtzHVUOXoDMplkNcY.LIST_LIMIT)
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if 'data' in hEPKQqindrBTxwtzHVUOXoDMplkNRF:
    hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['context_list']
    for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
     hEPKQqindrBTxwtzHVUOXoDMplkNfL={'title':hEPKQqindrBTxwtzHVUOXoDMplkNfs['program']['title'],'thumbnail':hEPKQqindrBTxwtzHVUOXoDMplkNfs['program']['vertical_logo_y_image'],'videoid':hEPKQqindrBTxwtzHVUOXoDMplkNfs['context_id'],'vidtype':'programid',}
     hEPKQqindrBTxwtzHVUOXoDMplkNfv.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
    if hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['pagecount'])>hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['count']):
     hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYF
   '''
   else:
    section_list = res_json['cell_toplist']['celllist']
    for i_section in section_list:
     id_url = ''
     for i_list in i_section['event_list']:
      if i_list['type'] == 'on-navigation':
       id_url = i_list['url']
     if id_url == '': break
     id_dict = urllib.parse.urlsplit(id_url).query
     vidtype = id_dict[0:id_dict.find('=')] # programid, contentid
     queryDict = dict(urllib.parse.parse_qsl(id_dict ) ) 
     videoid = queryDict.get(vidtype)
     temp_list = {'title' : i_section['alt'], 'thumbnail' : i_section['thumbnail'], 'videoid' : videoid, 'vidtype' : vidtype, #contentid/programid (programid) }
     program_list.append(temp_list )
    #if int(res_json['cell_toplist']['pagecount']) > page_int:
    if int(res_json['cell_toplist']['pagecount']) > int(res_json['cell_toplist']['count']):
     more_page = True
   '''   
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   addon_log('error : {}'.format(exception))
   return[],hEPKQqindrBTxwtzHVUOXoDMplkNYG
  return hEPKQqindrBTxwtzHVUOXoDMplkNfv,hEPKQqindrBTxwtzHVUOXoDMplkNfu
 def Get_Movie_List_new(hEPKQqindrBTxwtzHVUOXoDMplkNcY,mCode,sCode,page_int=1):
  hEPKQqindrBTxwtzHVUOXoDMplkNfA=[]
  hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYG
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='https://apis.wavve.com/v1/category/{}/sub/{}'.format(mCode,sCode)
   hEPKQqindrBTxwtzHVUOXoDMplkNRy={'accept':'application/json, text/plain, */*','accept-encoding':'gzip, deflate, br, zstd','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','authorization':'Bearer {}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential']),'cache-control':'no-cache','origin':'https://www.wavve.com','pragma':'no-cache','priority':'u=1, i','referer':'https://www.wavve.com/','wavve-credential':hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential'],}
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNca['guid']=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetGUID(guidType=3)
   hEPKQqindrBTxwtzHVUOXoDMplkNca['client_version']='7.2.60'
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNRy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNfR =hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['layout']['catalog']['catalog_list'][0]['element_list'][0]['action_list'][0]['execute']['data']['url']
   (hEPKQqindrBTxwtzHVUOXoDMplkNRA,hEPKQqindrBTxwtzHVUOXoDMplkNca)=hEPKQqindrBTxwtzHVUOXoDMplkNcY.Baseapi_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNfR)
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(hEPKQqindrBTxwtzHVUOXoDMplkNca)
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(hEPKQqindrBTxwtzHVUOXoDMplkNRA)
   hEPKQqindrBTxwtzHVUOXoDMplkNca['limit'] =hEPKQqindrBTxwtzHVUOXoDMplkNcY.LIST_LIMIT
   hEPKQqindrBTxwtzHVUOXoDMplkNca['offset']=hEPKQqindrBTxwtzHVUOXoDMplkNYA((page_int-1)*hEPKQqindrBTxwtzHVUOXoDMplkNcY.LIST_LIMIT)
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if 'data' in hEPKQqindrBTxwtzHVUOXoDMplkNRF:
    hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['context_list']
    for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
     hEPKQqindrBTxwtzHVUOXoDMplkNfL={'title':hEPKQqindrBTxwtzHVUOXoDMplkNfs['content']['title'],'thumbnail':hEPKQqindrBTxwtzHVUOXoDMplkNfs['program']['vertical_logo_y_image'],'videoid':hEPKQqindrBTxwtzHVUOXoDMplkNfs['content']['refer_id'],'playtime':hEPKQqindrBTxwtzHVUOXoDMplkNfs['content']['play_time']or '0','year':hEPKQqindrBTxwtzHVUOXoDMplkNfs['content']['original_release_year'],'vidtype':'movieid',}
     hEPKQqindrBTxwtzHVUOXoDMplkNfA.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
    if hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['pagecount'])> hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['count']):
     hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYF
   '''
   else:
    section_list = res_json['cell_toplist']['celllist']
    for i_section in section_list:
     id_url = ''
     for i_list in i_section['event_list']:
      if i_list['type'] == 'on-navigation':
       id_url = i_list['url']
     if id_url == '': break
     id_dict = urllib.parse.urlsplit(id_url).query
     vidtype = id_dict[0:id_dict.find('=')] # programid, contentid
     queryDict = dict(urllib.parse.parse_qsl(id_dict ) ) 
     videoid = queryDict.get(vidtype)
     temp_list = {'title' : i_section['alt'], 'thumbnail' : i_section['thumbnail'], 'videoid' : videoid, 'vidtype' : 'movieid', #vidtype, #movieid }
     movie_list.append(temp_list )
    #if int(res_json['cell_toplist']['pagecount']) > 0 and res_json['cell_toplist']['pagecount'] != res_json['cell_toplist']['count']:
    if int(res_json['cell_toplist']['pagecount']) > int(res_json['cell_toplist']['count']):
     more_page = True
   '''   
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   addon_log('error : {}'.format(exception))
   return[],hEPKQqindrBTxwtzHVUOXoDMplkNYG
  return hEPKQqindrBTxwtzHVUOXoDMplkNfA,hEPKQqindrBTxwtzHVUOXoDMplkNfu
 def Get_LiveChannel_List_New(hEPKQqindrBTxwtzHVUOXoDMplkNcY,mCode,sCode,page_int=1):
  hEPKQqindrBTxwtzHVUOXoDMplkNfG=[]
  hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYG
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='https://apis.wavve.com/v1/category/{}/sub/{}'.format(mCode,sCode)
   hEPKQqindrBTxwtzHVUOXoDMplkNRy={'accept':'application/json, text/plain, */*','accept-encoding':'gzip, deflate, br, zstd','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','authorization':'Bearer {}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential']),'cache-control':'no-cache','origin':'https://www.wavve.com','pragma':'no-cache','priority':'u=1, i','referer':'https://www.wavve.com/','wavve-credential':hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential'],}
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNca['guid']=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetGUID(guidType=3)
   hEPKQqindrBTxwtzHVUOXoDMplkNca['client_version']='7.2.60'
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNRy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNfR =hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['layout']['catalog']['catalog_list'][0]['element_list'][0]['action_list'][0]['execute']['data']['url']
   (hEPKQqindrBTxwtzHVUOXoDMplkNRA,hEPKQqindrBTxwtzHVUOXoDMplkNca)=hEPKQqindrBTxwtzHVUOXoDMplkNcY.Baseapi_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNfR)
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(hEPKQqindrBTxwtzHVUOXoDMplkNca)
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(hEPKQqindrBTxwtzHVUOXoDMplkNRA)
   if 'genre' in hEPKQqindrBTxwtzHVUOXoDMplkNca:
    hEPKQqindrBTxwtzHVUOXoDMplkNfa='all'
   else:
    hEPKQqindrBTxwtzHVUOXoDMplkNfa=hEPKQqindrBTxwtzHVUOXoDMplkNca.get('genre')
   hEPKQqindrBTxwtzHVUOXoDMplkNfF=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetEPGList(hEPKQqindrBTxwtzHVUOXoDMplkNfa)
   hEPKQqindrBTxwtzHVUOXoDMplkNca['limit'] =hEPKQqindrBTxwtzHVUOXoDMplkNcY.LIST_LIMIT
   hEPKQqindrBTxwtzHVUOXoDMplkNca['offset']=hEPKQqindrBTxwtzHVUOXoDMplkNYA((page_int-1)*hEPKQqindrBTxwtzHVUOXoDMplkNcY.LIST_LIMIT)
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if 'data' in hEPKQqindrBTxwtzHVUOXoDMplkNRF:
    hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['context_list']
    for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
     hEPKQqindrBTxwtzHVUOXoDMplkNfI=hEPKQqindrBTxwtzHVUOXoDMplkNfs['context_id']
     if hEPKQqindrBTxwtzHVUOXoDMplkNfI in hEPKQqindrBTxwtzHVUOXoDMplkNfF:
      hEPKQqindrBTxwtzHVUOXoDMplkNfJ=hEPKQqindrBTxwtzHVUOXoDMplkNfF[hEPKQqindrBTxwtzHVUOXoDMplkNfI]
     else:
      hEPKQqindrBTxwtzHVUOXoDMplkNfJ=''
     hEPKQqindrBTxwtzHVUOXoDMplkNfL={'studio':hEPKQqindrBTxwtzHVUOXoDMplkNfs['live']['name'],'tvshowtitle':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNfs['live']['program_title']),'channelid':hEPKQqindrBTxwtzHVUOXoDMplkNfs['context_id'],'thumbnail':hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNfs['live']['thumbnail_url']if not hEPKQqindrBTxwtzHVUOXoDMplkNfs['live']['thumbnail_url'].startswith('http')else hEPKQqindrBTxwtzHVUOXoDMplkNfs['live']['thumbnail_url'],'epg':hEPKQqindrBTxwtzHVUOXoDMplkNfJ,}
     hEPKQqindrBTxwtzHVUOXoDMplkNfG.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
    if hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['top_context']['pagecount'])>hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['data']['top_context']['count']):
     hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYF
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   addon_log('error : {}'.format(exception))
   return[],hEPKQqindrBTxwtzHVUOXoDMplkNYG
  return hEPKQqindrBTxwtzHVUOXoDMplkNfG,hEPKQqindrBTxwtzHVUOXoDMplkNfu
 def Get_Movie_List_Old(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNfR,page_int=1,orderby='-'):
  hEPKQqindrBTxwtzHVUOXoDMplkNfA=[]
  hEPKQqindrBTxwtzHVUOXoDMplkNfS=hEPKQqindrBTxwtzHVUOXoDMplkNWf=1
  hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYG
  (hEPKQqindrBTxwtzHVUOXoDMplkNRA,hEPKQqindrBTxwtzHVUOXoDMplkNca)=hEPKQqindrBTxwtzHVUOXoDMplkNcY.Baseapi_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNfR)
  if hEPKQqindrBTxwtzHVUOXoDMplkNRA=='':return hEPKQqindrBTxwtzHVUOXoDMplkNfA,hEPKQqindrBTxwtzHVUOXoDMplkNfu
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNca['limit']=hEPKQqindrBTxwtzHVUOXoDMplkNcY.MV_LIMIT
   hEPKQqindrBTxwtzHVUOXoDMplkNca['offset']=hEPKQqindrBTxwtzHVUOXoDMplkNYA((page_int-1)*hEPKQqindrBTxwtzHVUOXoDMplkNcY.MV_LIMIT)
   if hEPKQqindrBTxwtzHVUOXoDMplkNca.get('orderby')!='' and hEPKQqindrBTxwtzHVUOXoDMplkNca.get('orderby')!='regdatefirst' and orderby!='-':
    hEPKQqindrBTxwtzHVUOXoDMplkNca['orderby']=orderby 
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('cell_toplist')not in[{},hEPKQqindrBTxwtzHVUOXoDMplkNYy,'']:
    hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['celllist']
   elif hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('band')not in[{},hEPKQqindrBTxwtzHVUOXoDMplkNYy,'']:
    hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['band']['celllist']
   else:
    return hEPKQqindrBTxwtzHVUOXoDMplkNfA,hEPKQqindrBTxwtzHVUOXoDMplkNfu
   for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
    hEPKQqindrBTxwtzHVUOXoDMplkNfg =hEPKQqindrBTxwtzHVUOXoDMplkNfs['event_list'][1]['url']
    hEPKQqindrBTxwtzHVUOXoDMplkNfj=urllib.parse.urlsplit(hEPKQqindrBTxwtzHVUOXoDMplkNfg).query
    hEPKQqindrBTxwtzHVUOXoDMplkNfb=hEPKQqindrBTxwtzHVUOXoDMplkNfj[0:hEPKQqindrBTxwtzHVUOXoDMplkNfj.find('=')]
    hEPKQqindrBTxwtzHVUOXoDMplkNWc=hEPKQqindrBTxwtzHVUOXoDMplkNYg(urllib.parse.parse_qsl(hEPKQqindrBTxwtzHVUOXoDMplkNfj))
    hEPKQqindrBTxwtzHVUOXoDMplkNWR=hEPKQqindrBTxwtzHVUOXoDMplkNWc.get(hEPKQqindrBTxwtzHVUOXoDMplkNfb)
    hEPKQqindrBTxwtzHVUOXoDMplkNfL={'title':hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('alt')or hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('title_list')[0].get('text'),'age':hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('age'),'thumbnail':hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('thumbnail'),'videoid':hEPKQqindrBTxwtzHVUOXoDMplkNWR,'vidtype':hEPKQqindrBTxwtzHVUOXoDMplkNfb,}
    if not hEPKQqindrBTxwtzHVUOXoDMplkNfL.get('thumbnail').startswith('http'):
     hEPKQqindrBTxwtzHVUOXoDMplkNfL['thumbnail']='https://%s'%hEPKQqindrBTxwtzHVUOXoDMplkNfL['thumbnail']
    hEPKQqindrBTxwtzHVUOXoDMplkNfA.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
   if hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('cell_toplist')not in[{},hEPKQqindrBTxwtzHVUOXoDMplkNYy,'']:
    hEPKQqindrBTxwtzHVUOXoDMplkNfS=hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['pagecount'])
    if hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['count']:hEPKQqindrBTxwtzHVUOXoDMplkNWf =hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['count'])
    else:hEPKQqindrBTxwtzHVUOXoDMplkNWf=hEPKQqindrBTxwtzHVUOXoDMplkNcY.MV_LIMIT*page_int
    hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNfS>hEPKQqindrBTxwtzHVUOXoDMplkNWf
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return[],hEPKQqindrBTxwtzHVUOXoDMplkNYG
  return hEPKQqindrBTxwtzHVUOXoDMplkNfA,hEPKQqindrBTxwtzHVUOXoDMplkNfu
 def Get_Season_List(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNfI):
  hEPKQqindrBTxwtzHVUOXoDMplkNWs=[]
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='{}/fz/vod/contents-detail/{}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN,hEPKQqindrBTxwtzHVUOXoDMplkNfI)
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNWL={'poster':(hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('seasonposterimage'))if hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('seasonposterimage')else '','fanart':(hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('season_horizontal_logoY_image'))if hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('season_horizontal_logoY_image')else '','clearlogo':(hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('programtitlelogoimage'))if hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('programtitlelogoimage')else '',}
   for hEPKQqindrBTxwtzHVUOXoDMplkNWY in hEPKQqindrBTxwtzHVUOXoDMplkNRF['season_list']['season_item_list']:
    hEPKQqindrBTxwtzHVUOXoDMplkNfL={'season_Nm':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNWY.get('title')),'season_Id':hEPKQqindrBTxwtzHVUOXoDMplkNWY.get('id'),'thumbnail':hEPKQqindrBTxwtzHVUOXoDMplkNWL,'programNm':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNRF['programtitle']),'synopsis':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNRF['seasonsynopsis']),}
    hEPKQqindrBTxwtzHVUOXoDMplkNWs.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return[]
  return hEPKQqindrBTxwtzHVUOXoDMplkNWs
 def Get_Episode_List(hEPKQqindrBTxwtzHVUOXoDMplkNcY,seasionid,page_int=1,orderby='desc'):
  hEPKQqindrBTxwtzHVUOXoDMplkNWm=[]
  hEPKQqindrBTxwtzHVUOXoDMplkNfS=hEPKQqindrBTxwtzHVUOXoDMplkNWf=1
  hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYG
  hEPKQqindrBTxwtzHVUOXoDMplkNWC={}
  hEPKQqindrBTxwtzHVUOXoDMplkNfI=hEPKQqindrBTxwtzHVUOXoDMplkNcY.ProgramidToContentid(seasionid)
  hEPKQqindrBTxwtzHVUOXoDMplkNWC=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetProgramInfo(hEPKQqindrBTxwtzHVUOXoDMplkNfI)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   hEPKQqindrBTxwtzHVUOXoDMplkNca={'limit':hEPKQqindrBTxwtzHVUOXoDMplkNcY.EP_LIMIT,'offset':hEPKQqindrBTxwtzHVUOXoDMplkNYA((page_int-1)*hEPKQqindrBTxwtzHVUOXoDMplkNcY.EP_LIMIT),'orderby':orderby,}
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['celllist']
   for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
    hEPKQqindrBTxwtzHVUOXoDMplkNWy=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('synopsis'))
    hEPKQqindrBTxwtzHVUOXoDMplkNWv=hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('thumbnail')
    if not hEPKQqindrBTxwtzHVUOXoDMplkNWv.startswith('http'):
     hEPKQqindrBTxwtzHVUOXoDMplkNWv=hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNWv
    hEPKQqindrBTxwtzHVUOXoDMplkNWu=hEPKQqindrBTxwtzHVUOXoDMplkNWA=hEPKQqindrBTxwtzHVUOXoDMplkNWG=''
    hEPKQqindrBTxwtzHVUOXoDMplkNWu =hEPKQqindrBTxwtzHVUOXoDMplkNWC.get('imgPoster')
    hEPKQqindrBTxwtzHVUOXoDMplkNWA =hEPKQqindrBTxwtzHVUOXoDMplkNWC.get('imgFanart')
    hEPKQqindrBTxwtzHVUOXoDMplkNWG =hEPKQqindrBTxwtzHVUOXoDMplkNWC.get('imgClearlogo')
    hEPKQqindrBTxwtzHVUOXoDMplkNWa=hEPKQqindrBTxwtzHVUOXoDMplkNWC.get('programtitle')
    hEPKQqindrBTxwtzHVUOXoDMplkNWL={'thumb':hEPKQqindrBTxwtzHVUOXoDMplkNWv,'poster':hEPKQqindrBTxwtzHVUOXoDMplkNWu,'fanart':hEPKQqindrBTxwtzHVUOXoDMplkNWA,'clearlogo':hEPKQqindrBTxwtzHVUOXoDMplkNWG}
    hEPKQqindrBTxwtzHVUOXoDMplkNfL={'programtitle':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNWa),'episodetitle':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNfs['title_list'][0]['text']),'episodenumber':hEPKQqindrBTxwtzHVUOXoDMplkNfs['title_list'][1]['text'].replace('$O$',''),'contentid':hEPKQqindrBTxwtzHVUOXoDMplkNfs['contentid'],'synopsis':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNWy),'episodeactors':hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('actors').split(',')if hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('actors')!='' else[],'thumbnail':hEPKQqindrBTxwtzHVUOXoDMplkNWL,}
    hEPKQqindrBTxwtzHVUOXoDMplkNWm.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
   hEPKQqindrBTxwtzHVUOXoDMplkNfS=hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['pagecount'])
   if hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['count']:hEPKQqindrBTxwtzHVUOXoDMplkNWf =hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['count'])
   else:hEPKQqindrBTxwtzHVUOXoDMplkNWf=hEPKQqindrBTxwtzHVUOXoDMplkNcY.EP_LIMIT*page_int
   hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNfS>hEPKQqindrBTxwtzHVUOXoDMplkNWf
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return[],hEPKQqindrBTxwtzHVUOXoDMplkNYG
  return hEPKQqindrBTxwtzHVUOXoDMplkNWm,hEPKQqindrBTxwtzHVUOXoDMplkNfu
 def Get_Episode_List_New(hEPKQqindrBTxwtzHVUOXoDMplkNcY,seasionid,page_int=1,orderby='desc'):
  hEPKQqindrBTxwtzHVUOXoDMplkNWm=[]
  hEPKQqindrBTxwtzHVUOXoDMplkNfS=hEPKQqindrBTxwtzHVUOXoDMplkNWf=1
  hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYG
  hEPKQqindrBTxwtzHVUOXoDMplkNWC={}
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='{}/fz/vod/programs/{}/contents'.format(hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN,seasionid)
   hEPKQqindrBTxwtzHVUOXoDMplkNca={'limit':hEPKQqindrBTxwtzHVUOXoDMplkNcY.EP_LIMIT,'offset':hEPKQqindrBTxwtzHVUOXoDMplkNYA((page_int-1)*hEPKQqindrBTxwtzHVUOXoDMplkNcY.EP_LIMIT),'orderby':orderby,}
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['celllist']
   for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
    hEPKQqindrBTxwtzHVUOXoDMplkNWy=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('synopsis'))
    hEPKQqindrBTxwtzHVUOXoDMplkNWv=hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('thumbnail')
    if not hEPKQqindrBTxwtzHVUOXoDMplkNWv.startswith('http'):
     hEPKQqindrBTxwtzHVUOXoDMplkNWv=hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNWv
    hEPKQqindrBTxwtzHVUOXoDMplkNWL={'thumb':hEPKQqindrBTxwtzHVUOXoDMplkNWv}
    hEPKQqindrBTxwtzHVUOXoDMplkNfL={'programtitle':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNfs['alt']),'episodetitle':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNfs['episodetitle']),'episodenumber':hEPKQqindrBTxwtzHVUOXoDMplkNfs['episodenumber'],'releasedate':hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('releasedate').replace('-',''),'releaseweekday':hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('releaseweekday'),'contentid':hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('contentid'),'playtime':hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('playtime'))if hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('playtime')else 0,'synopsis':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNWy),'episodeactors':hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('actors').split(',')if hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('actors')!='' else[],'thumbnail':hEPKQqindrBTxwtzHVUOXoDMplkNWL,}
    hEPKQqindrBTxwtzHVUOXoDMplkNWm.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
   hEPKQqindrBTxwtzHVUOXoDMplkNfS=hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['pagecount'])
   if hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['count']:hEPKQqindrBTxwtzHVUOXoDMplkNWf =hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['count'])
   else:hEPKQqindrBTxwtzHVUOXoDMplkNWf=hEPKQqindrBTxwtzHVUOXoDMplkNcY.EP_LIMIT*page_int
   hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNfS>hEPKQqindrBTxwtzHVUOXoDMplkNWf
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return[],hEPKQqindrBTxwtzHVUOXoDMplkNYG
  return hEPKQqindrBTxwtzHVUOXoDMplkNWm,hEPKQqindrBTxwtzHVUOXoDMplkNfu
 def GetEPGList(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNfa):
  hEPKQqindrBTxwtzHVUOXoDMplkNWF={}
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNWI=hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_Now_Datetime()
   if hEPKQqindrBTxwtzHVUOXoDMplkNfa=='all':
    hEPKQqindrBTxwtzHVUOXoDMplkNWJ =hEPKQqindrBTxwtzHVUOXoDMplkNWI+datetime.timedelta(hours=3)
   else:
    hEPKQqindrBTxwtzHVUOXoDMplkNWJ =hEPKQqindrBTxwtzHVUOXoDMplkNWI+datetime.timedelta(hours=3)
   hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/live/epgs'
   hEPKQqindrBTxwtzHVUOXoDMplkNca={'limit':'100','offset':'0','genre':hEPKQqindrBTxwtzHVUOXoDMplkNfa,'startdatetime':hEPKQqindrBTxwtzHVUOXoDMplkNWI.strftime('%Y-%m-%d %H:00'),'enddatetime':hEPKQqindrBTxwtzHVUOXoDMplkNWJ.strftime('%Y-%m-%d %H:00')}
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNWS=hEPKQqindrBTxwtzHVUOXoDMplkNRF['list']
   for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNWS:
    hEPKQqindrBTxwtzHVUOXoDMplkNWg=''
    for hEPKQqindrBTxwtzHVUOXoDMplkNWj in hEPKQqindrBTxwtzHVUOXoDMplkNfs['list']:
     if hEPKQqindrBTxwtzHVUOXoDMplkNWg:hEPKQqindrBTxwtzHVUOXoDMplkNWg+='\n'
     hEPKQqindrBTxwtzHVUOXoDMplkNWg+=hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNWj['title'])+'\n'
     hEPKQqindrBTxwtzHVUOXoDMplkNWg+=' [%s ~ %s]'%(hEPKQqindrBTxwtzHVUOXoDMplkNWj['starttime'][-5:],hEPKQqindrBTxwtzHVUOXoDMplkNWj['endtime'][-5:])+'\n'
    hEPKQqindrBTxwtzHVUOXoDMplkNWF[hEPKQqindrBTxwtzHVUOXoDMplkNfs['channelid']]=hEPKQqindrBTxwtzHVUOXoDMplkNWg
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
  return hEPKQqindrBTxwtzHVUOXoDMplkNWF
 def Get_LiveChannel_List_Old(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNfa,hEPKQqindrBTxwtzHVUOXoDMplkNfR):
  hEPKQqindrBTxwtzHVUOXoDMplkNWb=[]
  (hEPKQqindrBTxwtzHVUOXoDMplkNRA,hEPKQqindrBTxwtzHVUOXoDMplkNca)=hEPKQqindrBTxwtzHVUOXoDMplkNcY.Baseapi_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNfR)
  if hEPKQqindrBTxwtzHVUOXoDMplkNRA=='':return hEPKQqindrBTxwtzHVUOXoDMplkNWb
  hEPKQqindrBTxwtzHVUOXoDMplkNfF=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetEPGList(hEPKQqindrBTxwtzHVUOXoDMplkNfa)
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNca['genre']=hEPKQqindrBTxwtzHVUOXoDMplkNfa
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNcY.JsonFile_Save(hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV_SESSION_COOKIES3,hEPKQqindrBTxwtzHVUOXoDMplkNRF)
   if not('celllist' in hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']):return[]
   hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNRF['cell_toplist']['celllist']
   for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
    hEPKQqindrBTxwtzHVUOXoDMplkNfI=hEPKQqindrBTxwtzHVUOXoDMplkNfs['contentid']
    if hEPKQqindrBTxwtzHVUOXoDMplkNfI in hEPKQqindrBTxwtzHVUOXoDMplkNfF:
     hEPKQqindrBTxwtzHVUOXoDMplkNfJ=hEPKQqindrBTxwtzHVUOXoDMplkNfF[hEPKQqindrBTxwtzHVUOXoDMplkNfI]
    else:
     hEPKQqindrBTxwtzHVUOXoDMplkNfJ=''
    hEPKQqindrBTxwtzHVUOXoDMplkNfL={'studio':hEPKQqindrBTxwtzHVUOXoDMplkNfs['title_list'][0]['text'],'tvshowtitle':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNfs['title_list'][1]['text']),'channelid':hEPKQqindrBTxwtzHVUOXoDMplkNfI,'age':hEPKQqindrBTxwtzHVUOXoDMplkNfs['age'],'thumbnail':'https://%s'%hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('thumbnail'),'thumbnail':hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('thumbnail')if not hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('thumbnail').startswith('http')else hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('thumbnail'),'epg':hEPKQqindrBTxwtzHVUOXoDMplkNfJ}
    hEPKQqindrBTxwtzHVUOXoDMplkNWb.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return[]
  return hEPKQqindrBTxwtzHVUOXoDMplkNWb
 def Get_Search_List(hEPKQqindrBTxwtzHVUOXoDMplkNcY,search_key,sType,page_int,exclusion21=hEPKQqindrBTxwtzHVUOXoDMplkNYG):
  hEPKQqindrBTxwtzHVUOXoDMplkNsc=[]
  hEPKQqindrBTxwtzHVUOXoDMplkNfS=hEPKQqindrBTxwtzHVUOXoDMplkNWf=1
  hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNYG
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/fz/search/band.js'
   hEPKQqindrBTxwtzHVUOXoDMplkNca={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':hEPKQqindrBTxwtzHVUOXoDMplkNYA((page_int-1)*hEPKQqindrBTxwtzHVUOXoDMplkNcY.SEARCH_LIMIT),'limit':hEPKQqindrBTxwtzHVUOXoDMplkNcY.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNsR=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if not('celllist' in hEPKQqindrBTxwtzHVUOXoDMplkNsR['band']):return hEPKQqindrBTxwtzHVUOXoDMplkNsc,hEPKQqindrBTxwtzHVUOXoDMplkNfu
   hEPKQqindrBTxwtzHVUOXoDMplkNfW=hEPKQqindrBTxwtzHVUOXoDMplkNsR['band']['celllist']
   for hEPKQqindrBTxwtzHVUOXoDMplkNfs in hEPKQqindrBTxwtzHVUOXoDMplkNfW:
    hEPKQqindrBTxwtzHVUOXoDMplkNfg=''
    for hEPKQqindrBTxwtzHVUOXoDMplkNWY in hEPKQqindrBTxwtzHVUOXoDMplkNfs['event_list']:
     if hEPKQqindrBTxwtzHVUOXoDMplkNWY['type']=='on-navigation':
      hEPKQqindrBTxwtzHVUOXoDMplkNfg=hEPKQqindrBTxwtzHVUOXoDMplkNWY['url']
    if hEPKQqindrBTxwtzHVUOXoDMplkNfg=='':break
    hEPKQqindrBTxwtzHVUOXoDMplkNfj=urllib.parse.urlsplit(hEPKQqindrBTxwtzHVUOXoDMplkNfg).query
    hEPKQqindrBTxwtzHVUOXoDMplkNfb=hEPKQqindrBTxwtzHVUOXoDMplkNfj[0:hEPKQqindrBTxwtzHVUOXoDMplkNfj.find('=')]
    hEPKQqindrBTxwtzHVUOXoDMplkNWc=hEPKQqindrBTxwtzHVUOXoDMplkNYg(urllib.parse.parse_qsl(hEPKQqindrBTxwtzHVUOXoDMplkNfj))
    hEPKQqindrBTxwtzHVUOXoDMplkNWR=hEPKQqindrBTxwtzHVUOXoDMplkNWc.get(hEPKQqindrBTxwtzHVUOXoDMplkNfb)
    hEPKQqindrBTxwtzHVUOXoDMplkNsf=hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('thumbnail')
    if not hEPKQqindrBTxwtzHVUOXoDMplkNsf.startswith('https://'):
     hEPKQqindrBTxwtzHVUOXoDMplkNsf='https://'+hEPKQqindrBTxwtzHVUOXoDMplkNsf
    hEPKQqindrBTxwtzHVUOXoDMplkNfL={'title':hEPKQqindrBTxwtzHVUOXoDMplkNfs['title_list'][0]['text'],'age':hEPKQqindrBTxwtzHVUOXoDMplkNfs['age'],'thumbnail':hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('thumbnail'),'videoid':hEPKQqindrBTxwtzHVUOXoDMplkNWR,'vidtype':hEPKQqindrBTxwtzHVUOXoDMplkNfb,}
    hEPKQqindrBTxwtzHVUOXoDMplkNsW=hEPKQqindrBTxwtzHVUOXoDMplkNYG
    for hEPKQqindrBTxwtzHVUOXoDMplkNsL in hEPKQqindrBTxwtzHVUOXoDMplkNfs['bottom_taglist']:
     if hEPKQqindrBTxwtzHVUOXoDMplkNsL=='won':
      hEPKQqindrBTxwtzHVUOXoDMplkNsW=hEPKQqindrBTxwtzHVUOXoDMplkNYF
      break
    if hEPKQqindrBTxwtzHVUOXoDMplkNsW==hEPKQqindrBTxwtzHVUOXoDMplkNYF: 
     hEPKQqindrBTxwtzHVUOXoDMplkNfL['title']=hEPKQqindrBTxwtzHVUOXoDMplkNfL['title']+' [개별구매]'
    if exclusion21==hEPKQqindrBTxwtzHVUOXoDMplkNYG or hEPKQqindrBTxwtzHVUOXoDMplkNfs.get('age')!='21':
     hEPKQqindrBTxwtzHVUOXoDMplkNsc.append(hEPKQqindrBTxwtzHVUOXoDMplkNfL)
   hEPKQqindrBTxwtzHVUOXoDMplkNfS=hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNsR['band']['pagecount'])
   if hEPKQqindrBTxwtzHVUOXoDMplkNsR['band']['count']:hEPKQqindrBTxwtzHVUOXoDMplkNWf =hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNsR['band']['count'])
   else:hEPKQqindrBTxwtzHVUOXoDMplkNWf=hEPKQqindrBTxwtzHVUOXoDMplkNcY.LIST_LIMIT
   hEPKQqindrBTxwtzHVUOXoDMplkNfu=hEPKQqindrBTxwtzHVUOXoDMplkNfS>hEPKQqindrBTxwtzHVUOXoDMplkNWf
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
  return hEPKQqindrBTxwtzHVUOXoDMplkNsc,hEPKQqindrBTxwtzHVUOXoDMplkNfu 
 def GetSecureToken(hEPKQqindrBTxwtzHVUOXoDMplkNcY):
  hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/ip'
  hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
  hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
  hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
  return hEPKQqindrBTxwtzHVUOXoDMplkNRF['securetoken']
 def Wavve_Parse_m3u8(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNLY):
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRy={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=requests.get(url=hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_url'],headers=hEPKQqindrBTxwtzHVUOXoDMplkNRy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_cookie'])
   hEPKQqindrBTxwtzHVUOXoDMplkNsY=hEPKQqindrBTxwtzHVUOXoDMplkNRa.content.decode('utf-8')
   if '#EXTM3U' not in hEPKQqindrBTxwtzHVUOXoDMplkNsY:
    return hEPKQqindrBTxwtzHVUOXoDMplkNYG
   if '#EXT-X-STREAM-INF' not in hEPKQqindrBTxwtzHVUOXoDMplkNsY: 
    return hEPKQqindrBTxwtzHVUOXoDMplkNYG
   hEPKQqindrBTxwtzHVUOXoDMplkNsm=0
   for hEPKQqindrBTxwtzHVUOXoDMplkNsC in hEPKQqindrBTxwtzHVUOXoDMplkNsY.splitlines():
    if hEPKQqindrBTxwtzHVUOXoDMplkNsC.startswith('#EXT-X-STREAM-INF'):
     hEPKQqindrBTxwtzHVUOXoDMplkNse=hEPKQqindrBTxwtzHVUOXoDMplkNcY.MediaLine_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNsC,'#EXT-X-STREAM-INF')
     if hEPKQqindrBTxwtzHVUOXoDMplkNsm<hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNse.get('BANDWIDTH')):
      hEPKQqindrBTxwtzHVUOXoDMplkNsm=hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNse.get('BANDWIDTH'))
   hEPKQqindrBTxwtzHVUOXoDMplkNsy=[]
   hEPKQqindrBTxwtzHVUOXoDMplkNsv=hEPKQqindrBTxwtzHVUOXoDMplkNYG
   for hEPKQqindrBTxwtzHVUOXoDMplkNsC in hEPKQqindrBTxwtzHVUOXoDMplkNsY.splitlines():
    if hEPKQqindrBTxwtzHVUOXoDMplkNsv==hEPKQqindrBTxwtzHVUOXoDMplkNYF:
     hEPKQqindrBTxwtzHVUOXoDMplkNsv=hEPKQqindrBTxwtzHVUOXoDMplkNYG
     continue
    if hEPKQqindrBTxwtzHVUOXoDMplkNsC.startswith('#EXT-X-STREAM-INF'):
     hEPKQqindrBTxwtzHVUOXoDMplkNse=hEPKQqindrBTxwtzHVUOXoDMplkNcY.MediaLine_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNsC,'#EXT-X-STREAM-INF')
     if hEPKQqindrBTxwtzHVUOXoDMplkNsm!=hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNse.get('BANDWIDTH')):
      hEPKQqindrBTxwtzHVUOXoDMplkNsv=hEPKQqindrBTxwtzHVUOXoDMplkNYF
      continue
    hEPKQqindrBTxwtzHVUOXoDMplkNsy.append(hEPKQqindrBTxwtzHVUOXoDMplkNsC)
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return hEPKQqindrBTxwtzHVUOXoDMplkNYG
  hEPKQqindrBTxwtzHVUOXoDMplkNsu='\n'.join(hEPKQqindrBTxwtzHVUOXoDMplkNsy)
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.TextFile_Save(hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV_STREAM_FILENAME,hEPKQqindrBTxwtzHVUOXoDMplkNsu)
  return hEPKQqindrBTxwtzHVUOXoDMplkNYF
 def Wavve_Parse_mpd(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNLY):
  hEPKQqindrBTxwtzHVUOXoDMplkNRy={'user-agent':'pooqV2/5.6.0 (Linux;Android 10) ExoPlayerLib/2.13.3'}
  hEPKQqindrBTxwtzHVUOXoDMplkNRa=requests.get(url=hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_url'],headers=hEPKQqindrBTxwtzHVUOXoDMplkNRy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_cookie'])
  hEPKQqindrBTxwtzHVUOXoDMplkNsA=hEPKQqindrBTxwtzHVUOXoDMplkNRa.content.decode('utf-8')
  hEPKQqindrBTxwtzHVUOXoDMplkNsG =ET.ElementTree(ET.fromstring(hEPKQqindrBTxwtzHVUOXoDMplkNsA))
  hEPKQqindrBTxwtzHVUOXoDMplkNsa =hEPKQqindrBTxwtzHVUOXoDMplkNsG.getroot()
  hEPKQqindrBTxwtzHVUOXoDMplkNsF=re.match(r'\{.*\}',hEPKQqindrBTxwtzHVUOXoDMplkNsa.tag)[0] 
  hEPKQqindrBTxwtzHVUOXoDMplkNsI=hEPKQqindrBTxwtzHVUOXoDMplkNYg([node for _,node in ET.iterparse(io.StringIO(hEPKQqindrBTxwtzHVUOXoDMplkNsA),events=['start-ns'])])
  for hEPKQqindrBTxwtzHVUOXoDMplkNRC,hEPKQqindrBTxwtzHVUOXoDMplkNLs in hEPKQqindrBTxwtzHVUOXoDMplkNsI.items():
   ET.register_namespace(hEPKQqindrBTxwtzHVUOXoDMplkNRC,hEPKQqindrBTxwtzHVUOXoDMplkNLs)
  hEPKQqindrBTxwtzHVUOXoDMplkNsJ=hEPKQqindrBTxwtzHVUOXoDMplkNsa.find(hEPKQqindrBTxwtzHVUOXoDMplkNsF+'Period')
  for hEPKQqindrBTxwtzHVUOXoDMplkNsS in hEPKQqindrBTxwtzHVUOXoDMplkNsJ.findall(hEPKQqindrBTxwtzHVUOXoDMplkNsF+'AdaptationSet'):
   if hEPKQqindrBTxwtzHVUOXoDMplkNsS.attrib.get('mimeType')=='video/mp4':
    hEPKQqindrBTxwtzHVUOXoDMplkNsg=0
    for hEPKQqindrBTxwtzHVUOXoDMplkNsj in hEPKQqindrBTxwtzHVUOXoDMplkNsS.findall(hEPKQqindrBTxwtzHVUOXoDMplkNsF+'Representation'):
     hEPKQqindrBTxwtzHVUOXoDMplkNsb=hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNsj.attrib.get('bandwidth'))
     if hEPKQqindrBTxwtzHVUOXoDMplkNsg<hEPKQqindrBTxwtzHVUOXoDMplkNsb:hEPKQqindrBTxwtzHVUOXoDMplkNsg=hEPKQqindrBTxwtzHVUOXoDMplkNsb
    for hEPKQqindrBTxwtzHVUOXoDMplkNsj in hEPKQqindrBTxwtzHVUOXoDMplkNsS.findall(hEPKQqindrBTxwtzHVUOXoDMplkNsF+'Representation'):
     if hEPKQqindrBTxwtzHVUOXoDMplkNsg>hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNsj.attrib.get('bandwidth')):
      hEPKQqindrBTxwtzHVUOXoDMplkNsS.remove(hEPKQqindrBTxwtzHVUOXoDMplkNsj)
   elif hEPKQqindrBTxwtzHVUOXoDMplkNsS.attrib.get('mimeType')=='audio/mp4':
    hEPKQqindrBTxwtzHVUOXoDMplkNsg=0
    for hEPKQqindrBTxwtzHVUOXoDMplkNsj in hEPKQqindrBTxwtzHVUOXoDMplkNsS.findall(hEPKQqindrBTxwtzHVUOXoDMplkNsF+'Representation'):
     hEPKQqindrBTxwtzHVUOXoDMplkNsb=hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNsj.attrib.get('bandwidth'))
     if hEPKQqindrBTxwtzHVUOXoDMplkNsg<hEPKQqindrBTxwtzHVUOXoDMplkNsb:hEPKQqindrBTxwtzHVUOXoDMplkNsg=hEPKQqindrBTxwtzHVUOXoDMplkNsb
    for hEPKQqindrBTxwtzHVUOXoDMplkNsj in hEPKQqindrBTxwtzHVUOXoDMplkNsS.findall(hEPKQqindrBTxwtzHVUOXoDMplkNsF+'Representation'):
     if hEPKQqindrBTxwtzHVUOXoDMplkNsg>hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNsj.attrib.get('bandwidth')):
      hEPKQqindrBTxwtzHVUOXoDMplkNsS.remove(hEPKQqindrBTxwtzHVUOXoDMplkNsj)
   else:
    continue
  hEPKQqindrBTxwtzHVUOXoDMplkNLc=ET.tostring(hEPKQqindrBTxwtzHVUOXoDMplkNsa).decode('utf-8')
  hEPKQqindrBTxwtzHVUOXoDMplkNLR='<?xml version="1.0" encoding="UTF-8"?>\n'
  hEPKQqindrBTxwtzHVUOXoDMplkNcY.TextFile_Save(hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV_STREAM_FILENAME,hEPKQqindrBTxwtzHVUOXoDMplkNLR+hEPKQqindrBTxwtzHVUOXoDMplkNLc)
  return hEPKQqindrBTxwtzHVUOXoDMplkNYF
 def MediaLine_Parse(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNsC,prefix):
  hEPKQqindrBTxwtzHVUOXoDMplkNse={}
  for hEPKQqindrBTxwtzHVUOXoDMplkNLf in hEPKQqindrBTxwtzHVUOXoDMplkNcs.split(hEPKQqindrBTxwtzHVUOXoDMplkNsC.replace(prefix+':',''))[1::2]:
   hEPKQqindrBTxwtzHVUOXoDMplkNLW,hEPKQqindrBTxwtzHVUOXoDMplkNLs=hEPKQqindrBTxwtzHVUOXoDMplkNLf.split('=',1)
   hEPKQqindrBTxwtzHVUOXoDMplkNse[hEPKQqindrBTxwtzHVUOXoDMplkNLW.upper()]=hEPKQqindrBTxwtzHVUOXoDMplkNLs.replace('"','').strip()
  return hEPKQqindrBTxwtzHVUOXoDMplkNse
 def GetStreamingURL(hEPKQqindrBTxwtzHVUOXoDMplkNcY,mode,hEPKQqindrBTxwtzHVUOXoDMplkNfI,quality_int,pvrmode='-',playOption={}):
  hEPKQqindrBTxwtzHVUOXoDMplkNLY ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  hEPKQqindrBTxwtzHVUOXoDMplkNLm=[]
  if mode=='LIVE':
   hEPKQqindrBTxwtzHVUOXoDMplkNRA =hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/live/channels/'+hEPKQqindrBTxwtzHVUOXoDMplkNfI
   hEPKQqindrBTxwtzHVUOXoDMplkNLC='live'
  elif mode=='VOD':
   hEPKQqindrBTxwtzHVUOXoDMplkNRA =hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/fz/vod/contents-detail/'+hEPKQqindrBTxwtzHVUOXoDMplkNfI 
   hEPKQqindrBTxwtzHVUOXoDMplkNLC='vod'
  elif mode=='MOVIE':
   hEPKQqindrBTxwtzHVUOXoDMplkNRA =hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/fz/movie/contents/'+hEPKQqindrBTxwtzHVUOXoDMplkNfI
   hEPKQqindrBTxwtzHVUOXoDMplkNLC='movie'
  hEPKQqindrBTxwtzHVUOXoDMplkNLe={'hdr':'sdr','uhd':'-',}
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNLy=hEPKQqindrBTxwtzHVUOXoDMplkNRF['qualities']['list']
   if hEPKQqindrBTxwtzHVUOXoDMplkNLy==hEPKQqindrBTxwtzHVUOXoDMplkNYy:return hEPKQqindrBTxwtzHVUOXoDMplkNLY
   for hEPKQqindrBTxwtzHVUOXoDMplkNLv in hEPKQqindrBTxwtzHVUOXoDMplkNLy:
    hEPKQqindrBTxwtzHVUOXoDMplkNLm.append(hEPKQqindrBTxwtzHVUOXoDMplkNYj(hEPKQqindrBTxwtzHVUOXoDMplkNLv.get('id').rstrip('p')))
   if 'drms' in hEPKQqindrBTxwtzHVUOXoDMplkNRF:
    if hEPKQqindrBTxwtzHVUOXoDMplkNRF['drms']:
     hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_action']='dash' 
   if playOption.get('enable_hdr'):
    if 'mediatypes' in hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('qualities'):
     for hEPKQqindrBTxwtzHVUOXoDMplkNLu in hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('qualities').get('mediatypes'):
      if hEPKQqindrBTxwtzHVUOXoDMplkNLu=='HDR10':
       hEPKQqindrBTxwtzHVUOXoDMplkNLe['hdr']='hdr'
       hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_action']='dash'
       break
   if playOption.get('enable_uhd'):
    for hEPKQqindrBTxwtzHVUOXoDMplkNLu in hEPKQqindrBTxwtzHVUOXoDMplkNRF.get('qualities').get('list'):
     if hEPKQqindrBTxwtzHVUOXoDMplkNLu.get('name')=='UHD':
      hEPKQqindrBTxwtzHVUOXoDMplkNLe['uhd']='uhd'
      break
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
   return hEPKQqindrBTxwtzHVUOXoDMplkNLY
  hEPKQqindrBTxwtzHVUOXoDMplkNYu('stream_action : '+hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_action'])
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNLA=hEPKQqindrBTxwtzHVUOXoDMplkNcY.CheckQuality(quality_int,hEPKQqindrBTxwtzHVUOXoDMplkNLm)
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(hEPKQqindrBTxwtzHVUOXoDMplkNLA)
   if hEPKQqindrBTxwtzHVUOXoDMplkNLA<1080:
    hEPKQqindrBTxwtzHVUOXoDMplkNLe['uhd']='-'
    hEPKQqindrBTxwtzHVUOXoDMplkNLe['hdr']='sdr'
   if hEPKQqindrBTxwtzHVUOXoDMplkNLe['uhd']=='uhd':hEPKQqindrBTxwtzHVUOXoDMplkNLA=2160 
   hEPKQqindrBTxwtzHVUOXoDMplkNLG=hEPKQqindrBTxwtzHVUOXoDMplkNYA(hEPKQqindrBTxwtzHVUOXoDMplkNLA)+'p'
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(hEPKQqindrBTxwtzHVUOXoDMplkNLG)
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='https://delivery.wavve.com/v1/streaming/{}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNLC)
   if hEPKQqindrBTxwtzHVUOXoDMplkNLe['hdr']=='hdr' or hEPKQqindrBTxwtzHVUOXoDMplkNLe['uhd']=='uhd':
    hEPKQqindrBTxwtzHVUOXoDMplkNca={'service':'wavve','contentid':hEPKQqindrBTxwtzHVUOXoDMplkNfI,'audioChannel':'2ch','contenttype':hEPKQqindrBTxwtzHVUOXoDMplkNLC,'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n','action':hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_action'],'protocol':hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_action'],'quality':hEPKQqindrBTxwtzHVUOXoDMplkNLG,'modelid':'SHIELD Android TV','guid':hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
    hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams_AND())
   else:
    hEPKQqindrBTxwtzHVUOXoDMplkNca={'service':'wavve','contentid':hEPKQqindrBTxwtzHVUOXoDMplkNfI,'audioChannel':'2ch','contenttype':hEPKQqindrBTxwtzHVUOXoDMplkNLC,'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n','action':hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_action'],'protocol':hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_action'],'quality':hEPKQqindrBTxwtzHVUOXoDMplkNLG,'deviceModelId':'Windows 10','guid':hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
    hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRy={'wavve-credential':hEPKQqindrBTxwtzHVUOXoDMplkNcY.WV['cookies']['credential'],}
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNRy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_url']=hEPKQqindrBTxwtzHVUOXoDMplkNRF['playurl']
   if hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_url']==hEPKQqindrBTxwtzHVUOXoDMplkNYy:return hEPKQqindrBTxwtzHVUOXoDMplkNLY
   hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_cookie']=hEPKQqindrBTxwtzHVUOXoDMplkNcY.make_str_ToCookie(hEPKQqindrBTxwtzHVUOXoDMplkNRF['awscookie'])
   hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_drm'] =hEPKQqindrBTxwtzHVUOXoDMplkNRF['drm']
   if 'previewmsg' in hEPKQqindrBTxwtzHVUOXoDMplkNRF['preview']:hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_preview']=hEPKQqindrBTxwtzHVUOXoDMplkNRF['preview']['previewmsg']
   if 'subtitles' in hEPKQqindrBTxwtzHVUOXoDMplkNRF:
    for hEPKQqindrBTxwtzHVUOXoDMplkNLa in hEPKQqindrBTxwtzHVUOXoDMplkNRF['subtitles']:
     if hEPKQqindrBTxwtzHVUOXoDMplkNLa.get('languagecode')=='ko':
      hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_vtt']=hEPKQqindrBTxwtzHVUOXoDMplkNLa.get('url')
      break
    if hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_vtt']=='':
     for hEPKQqindrBTxwtzHVUOXoDMplkNLa in hEPKQqindrBTxwtzHVUOXoDMplkNRF['subtitles']:
      if hEPKQqindrBTxwtzHVUOXoDMplkNLa.get('languagecode')=='ko_cc':
       hEPKQqindrBTxwtzHVUOXoDMplkNLY['stream_vtt']=hEPKQqindrBTxwtzHVUOXoDMplkNLa.get('url')
       break
   hEPKQqindrBTxwtzHVUOXoDMplkNLY['playParam']=hEPKQqindrBTxwtzHVUOXoDMplkNLe 
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
  return hEPKQqindrBTxwtzHVUOXoDMplkNLY 
 def make_viewdate(hEPKQqindrBTxwtzHVUOXoDMplkNcY):
  hEPKQqindrBTxwtzHVUOXoDMplkNLF =hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_Now_Datetime()
  hEPKQqindrBTxwtzHVUOXoDMplkNLI =hEPKQqindrBTxwtzHVUOXoDMplkNLF+datetime.timedelta(days=-1)
  hEPKQqindrBTxwtzHVUOXoDMplkNLJ =hEPKQqindrBTxwtzHVUOXoDMplkNLF+datetime.timedelta(days=1)
  hEPKQqindrBTxwtzHVUOXoDMplkNLS=[hEPKQqindrBTxwtzHVUOXoDMplkNLF.strftime('%Y%m%d'),hEPKQqindrBTxwtzHVUOXoDMplkNLJ.strftime('%Y%m%d'),]
  return hEPKQqindrBTxwtzHVUOXoDMplkNLS
 def GetBookmarkInfo(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNWR,hEPKQqindrBTxwtzHVUOXoDMplkNfb,hEPKQqindrBTxwtzHVUOXoDMplkNLC):
  if hEPKQqindrBTxwtzHVUOXoDMplkNfb=='tvshow':
   if hEPKQqindrBTxwtzHVUOXoDMplkNLC=='contentid':
    hEPKQqindrBTxwtzHVUOXoDMplkNfI=hEPKQqindrBTxwtzHVUOXoDMplkNWR
   else:
    hEPKQqindrBTxwtzHVUOXoDMplkNfI=hEPKQqindrBTxwtzHVUOXoDMplkNcY.ProgramidToContentid(hEPKQqindrBTxwtzHVUOXoDMplkNWR)
  else:
   hEPKQqindrBTxwtzHVUOXoDMplkNfI=''
  hEPKQqindrBTxwtzHVUOXoDMplkNLg={'indexinfo':{'ott':'wavve','videoid':hEPKQqindrBTxwtzHVUOXoDMplkNWR,'vidtype':hEPKQqindrBTxwtzHVUOXoDMplkNfb,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':hEPKQqindrBTxwtzHVUOXoDMplkNfb,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if hEPKQqindrBTxwtzHVUOXoDMplkNfb=='tvshow':
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='{}/fz/vod/contents-detail/{}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN,hEPKQqindrBTxwtzHVUOXoDMplkNfI)
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if not('programtitle' in hEPKQqindrBTxwtzHVUOXoDMplkNRF):return{}
   hEPKQqindrBTxwtzHVUOXoDMplkNLj=hEPKQqindrBTxwtzHVUOXoDMplkNRF
   if hEPKQqindrBTxwtzHVUOXoDMplkNfb=='tvshow' and hEPKQqindrBTxwtzHVUOXoDMplkNLC=='contentid':
    hEPKQqindrBTxwtzHVUOXoDMplkNLg['indexinfo']['videoid']=hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('programid')
   hEPKQqindrBTxwtzHVUOXoDMplkNLb=hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('programtitle')
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['title']=hEPKQqindrBTxwtzHVUOXoDMplkNLb
   if hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('targetage')=='18' or hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('targetage')=='19' or hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('targetage')=='21':
    hEPKQqindrBTxwtzHVUOXoDMplkNLb +=u' (%s)'%(hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('targetage'))
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['title'] =hEPKQqindrBTxwtzHVUOXoDMplkNLb
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['mpaa'] =hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('targetage')
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['plot'] =hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('programsynopsis'))
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['studio'] =hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('channelname')
   if hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('firstreleaseyear')!='':hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['year'] =hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('firstreleaseyear')
   if hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('firstreleasedate')!='':hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['premiered']=hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('firstreleasedate')
   if hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('genretext') !='':hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['genre'] =[hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('genretext')]
   hEPKQqindrBTxwtzHVUOXoDMplkNYc=[]
   for hEPKQqindrBTxwtzHVUOXoDMplkNYR in hEPKQqindrBTxwtzHVUOXoDMplkNLj['actors']['list']:hEPKQqindrBTxwtzHVUOXoDMplkNYc.append(hEPKQqindrBTxwtzHVUOXoDMplkNYR.get('text'))
   if hEPKQqindrBTxwtzHVUOXoDMplkNYJ(hEPKQqindrBTxwtzHVUOXoDMplkNYc)>0:
    if hEPKQqindrBTxwtzHVUOXoDMplkNYc[0]!='':hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['cast']=hEPKQqindrBTxwtzHVUOXoDMplkNYc
   hEPKQqindrBTxwtzHVUOXoDMplkNWu =''
   hEPKQqindrBTxwtzHVUOXoDMplkNWA =''
   hEPKQqindrBTxwtzHVUOXoDMplkNWG=''
   if hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('seasonposterimage') !='':hEPKQqindrBTxwtzHVUOXoDMplkNWu =hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('seasonposterimage')
   if hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('season_horizontal_logoY_image')!='':hEPKQqindrBTxwtzHVUOXoDMplkNWA =hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('season_horizontal_logoY_image')
   if hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('programtitlelogoimage') !='':hEPKQqindrBTxwtzHVUOXoDMplkNWG=hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('programtitlelogoimage')
   if 'poster_default' in hEPKQqindrBTxwtzHVUOXoDMplkNWu:
    hEPKQqindrBTxwtzHVUOXoDMplkNWu =hEPKQqindrBTxwtzHVUOXoDMplkNWA
    hEPKQqindrBTxwtzHVUOXoDMplkNWG=''
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['thumbnail']['poster']=hEPKQqindrBTxwtzHVUOXoDMplkNWu
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['thumbnail']['thumb']=hEPKQqindrBTxwtzHVUOXoDMplkNWA
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['thumbnail']['clearlogo']=hEPKQqindrBTxwtzHVUOXoDMplkNWG
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['thumbnail']['fanart']=hEPKQqindrBTxwtzHVUOXoDMplkNWA
  else:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/fz/movie/contents/'+hEPKQqindrBTxwtzHVUOXoDMplkNWR 
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNRF=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if not('title' in hEPKQqindrBTxwtzHVUOXoDMplkNRF):return{}
   hEPKQqindrBTxwtzHVUOXoDMplkNLj=hEPKQqindrBTxwtzHVUOXoDMplkNRF
   hEPKQqindrBTxwtzHVUOXoDMplkNLb=hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('title')
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['title']=hEPKQqindrBTxwtzHVUOXoDMplkNLb
   if hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('targetage')=='18' or hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('targetage')=='19' or hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('targetage')=='21':
    hEPKQqindrBTxwtzHVUOXoDMplkNLb +=u' (%s)'%(hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('targetage'))
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['title'] =hEPKQqindrBTxwtzHVUOXoDMplkNLb
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['mpaa'] =hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('targetage')
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['plot'] =hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('synopsis'))
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['duration']=hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('playtime')
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['country']=hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('country')
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['studio'] =hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('cpname')
   if hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('releasedate')!='':
    hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['year'] =hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('releasedate')[:4]
    hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['premiered']=hEPKQqindrBTxwtzHVUOXoDMplkNLj.get('releasedate')
   hEPKQqindrBTxwtzHVUOXoDMplkNYc=[]
   for hEPKQqindrBTxwtzHVUOXoDMplkNYR in hEPKQqindrBTxwtzHVUOXoDMplkNLj['actors']['list']:hEPKQqindrBTxwtzHVUOXoDMplkNYc.append(hEPKQqindrBTxwtzHVUOXoDMplkNYR.get('text'))
   if hEPKQqindrBTxwtzHVUOXoDMplkNYJ(hEPKQqindrBTxwtzHVUOXoDMplkNYc)>0:
    if hEPKQqindrBTxwtzHVUOXoDMplkNYc[0]!='':hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['cast']=hEPKQqindrBTxwtzHVUOXoDMplkNYc
   hEPKQqindrBTxwtzHVUOXoDMplkNYf=[]
   for hEPKQqindrBTxwtzHVUOXoDMplkNYW in hEPKQqindrBTxwtzHVUOXoDMplkNLj['directors']['list']:hEPKQqindrBTxwtzHVUOXoDMplkNYf.append(hEPKQqindrBTxwtzHVUOXoDMplkNYW.get('text'))
   if hEPKQqindrBTxwtzHVUOXoDMplkNYJ(hEPKQqindrBTxwtzHVUOXoDMplkNYf)>0:
    if hEPKQqindrBTxwtzHVUOXoDMplkNYf[0]!='':hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['director']=hEPKQqindrBTxwtzHVUOXoDMplkNYf
   hEPKQqindrBTxwtzHVUOXoDMplkNfc=[]
   for hEPKQqindrBTxwtzHVUOXoDMplkNYs in hEPKQqindrBTxwtzHVUOXoDMplkNLj['genre']['list']:hEPKQqindrBTxwtzHVUOXoDMplkNfc.append(hEPKQqindrBTxwtzHVUOXoDMplkNYs.get('text'))
   if hEPKQqindrBTxwtzHVUOXoDMplkNYJ(hEPKQqindrBTxwtzHVUOXoDMplkNfc)>0:
    if hEPKQqindrBTxwtzHVUOXoDMplkNfc[0]!='':hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['infoLabels']['genre']=hEPKQqindrBTxwtzHVUOXoDMplkNfc
   hEPKQqindrBTxwtzHVUOXoDMplkNWu ='https://%s'%hEPKQqindrBTxwtzHVUOXoDMplkNLj['image']
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['thumbnail']['poster'] =hEPKQqindrBTxwtzHVUOXoDMplkNWu
   hEPKQqindrBTxwtzHVUOXoDMplkNLg['saveinfo']['thumbnail']['thumb'] =hEPKQqindrBTxwtzHVUOXoDMplkNWu
  return hEPKQqindrBTxwtzHVUOXoDMplkNLg
 def ProgramidToContentid(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNYL):
  hEPKQqindrBTxwtzHVUOXoDMplkNfI=''
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA =hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/fz/vod/programs/landing'
   hEPKQqindrBTxwtzHVUOXoDMplkNca={'history':'all','programid':hEPKQqindrBTxwtzHVUOXoDMplkNYL,}
   hEPKQqindrBTxwtzHVUOXoDMplkNca.update(hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams())
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNsR=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if not('content_id' in hEPKQqindrBTxwtzHVUOXoDMplkNsR):return hEPKQqindrBTxwtzHVUOXoDMplkNfI 
   hEPKQqindrBTxwtzHVUOXoDMplkNfI=hEPKQqindrBTxwtzHVUOXoDMplkNsR['content_id']
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
  return hEPKQqindrBTxwtzHVUOXoDMplkNfI
 def ContentidToSeasonid(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNfI):
  hEPKQqindrBTxwtzHVUOXoDMplkNYL=''
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='{}/fz/vod/contents-detail/{}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN,hEPKQqindrBTxwtzHVUOXoDMplkNfI)
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNsR=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   if not('programid' in hEPKQqindrBTxwtzHVUOXoDMplkNsR):return hEPKQqindrBTxwtzHVUOXoDMplkNYL 
   hEPKQqindrBTxwtzHVUOXoDMplkNYL=hEPKQqindrBTxwtzHVUOXoDMplkNsR['programid']
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
  return hEPKQqindrBTxwtzHVUOXoDMplkNYL
 def GetProgramInfo_bak(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNfI):
  hEPKQqindrBTxwtzHVUOXoDMplkNYm={}
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA=hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN+'/fz/vod/contents/'+hEPKQqindrBTxwtzHVUOXoDMplkNfI
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNsR=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNYC=img_fanart=hEPKQqindrBTxwtzHVUOXoDMplkNYe=''
   if hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programposterimage')!='':hEPKQqindrBTxwtzHVUOXoDMplkNYC =hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programposterimage')
   if hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programimage') !='':img_fanart =hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programimage')
   if hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programcircleimage')!='':hEPKQqindrBTxwtzHVUOXoDMplkNYe=hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programcircleimage')
   if 'poster_default' in hEPKQqindrBTxwtzHVUOXoDMplkNYC:
    hEPKQqindrBTxwtzHVUOXoDMplkNYC =img_fanart
    hEPKQqindrBTxwtzHVUOXoDMplkNYe=''
   hEPKQqindrBTxwtzHVUOXoDMplkNYm={'imgPoster':hEPKQqindrBTxwtzHVUOXoDMplkNYC,'imgFanart':img_fanart,'imgClearlogo':hEPKQqindrBTxwtzHVUOXoDMplkNYe,'programtitle':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programtitle')),'programid':hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programid'),'synopsis':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programsynopsis')),}
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
  return hEPKQqindrBTxwtzHVUOXoDMplkNYm
 def GetProgramInfo(hEPKQqindrBTxwtzHVUOXoDMplkNcY,hEPKQqindrBTxwtzHVUOXoDMplkNfI):
  hEPKQqindrBTxwtzHVUOXoDMplkNYm={}
  try:
   hEPKQqindrBTxwtzHVUOXoDMplkNRA='{}/fz/vod/contents-detail/{}'.format(hEPKQqindrBTxwtzHVUOXoDMplkNcY.API_DOMAIN,hEPKQqindrBTxwtzHVUOXoDMplkNfI)
   hEPKQqindrBTxwtzHVUOXoDMplkNca=hEPKQqindrBTxwtzHVUOXoDMplkNcY.GetDefaultParams()
   hEPKQqindrBTxwtzHVUOXoDMplkNRa=hEPKQqindrBTxwtzHVUOXoDMplkNcY.callRequestCookies('Get',hEPKQqindrBTxwtzHVUOXoDMplkNRA,payload=hEPKQqindrBTxwtzHVUOXoDMplkNYy,params=hEPKQqindrBTxwtzHVUOXoDMplkNca,headers=hEPKQqindrBTxwtzHVUOXoDMplkNYy,cookies=hEPKQqindrBTxwtzHVUOXoDMplkNYy)
   hEPKQqindrBTxwtzHVUOXoDMplkNsR=json.loads(hEPKQqindrBTxwtzHVUOXoDMplkNRa.text)
   hEPKQqindrBTxwtzHVUOXoDMplkNYC=img_fanart=hEPKQqindrBTxwtzHVUOXoDMplkNYe=''
   if hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('seasonposterimage') !='':hEPKQqindrBTxwtzHVUOXoDMplkNYC =hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('seasonposterimage')
   if hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('season_horizontal_logoY_image')!='':img_fanart =hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('season_horizontal_logoY_image')
   if hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programtitlelogoimage') !='':hEPKQqindrBTxwtzHVUOXoDMplkNYe=hEPKQqindrBTxwtzHVUOXoDMplkNcY.HTTPTAG+hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programtitlelogoimage')
   hEPKQqindrBTxwtzHVUOXoDMplkNYm={'imgPoster':hEPKQqindrBTxwtzHVUOXoDMplkNYC,'imgFanart':img_fanart,'imgClearlogo':hEPKQqindrBTxwtzHVUOXoDMplkNYe,'programtitle':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programtitle')),'programid':hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('programid'),'synopsis':hEPKQqindrBTxwtzHVUOXoDMplkNcY.Get_ChangeText(hEPKQqindrBTxwtzHVUOXoDMplkNsR.get('seasonsynopsis')),}
  except hEPKQqindrBTxwtzHVUOXoDMplkNYS as exception:
   hEPKQqindrBTxwtzHVUOXoDMplkNYu(exception)
  return hEPKQqindrBTxwtzHVUOXoDMplkNYm 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
