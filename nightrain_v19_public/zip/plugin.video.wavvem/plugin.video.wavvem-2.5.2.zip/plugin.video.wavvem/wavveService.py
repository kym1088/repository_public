# -*- coding: utf-8 -*-
__author__ = "NightRain"

import xbmc, xbmcaddon, xbmcvfs
import os
import sys


ADDON_PATH = xbmcvfs.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
PROXY_PATH   = os.path.join( ADDON_PATH, 'resources', 'lib' )
sys.path.append( PROXY_PATH )
PKG_PATH   = os.path.join( ADDON_PATH, 'packages' )
sys.path.append( PKG_PATH )

from wavveProxy import *


monitor = xbmc.Monitor()
proxyObj = WavveProxy()
xbmc.sleep(1100) # 1.1초
proxyObj.PORT = int( xbmcaddon.Addon().getSetting( 'proxyPort' ) )

proxyObj.start()
    
while not monitor.abortRequested():
	if monitor.waitForAbort(60): # 1분
		break


proxyObj.stop()


	
