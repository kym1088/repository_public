__author__="NightRain"
EzLrcBpXIWwnSuHoFPVNimdKsxUgfO=object
EzLrcBpXIWwnSuHoFPVNimdKsxUgfy=None
EzLrcBpXIWwnSuHoFPVNimdKsxUgfT=False
EzLrcBpXIWwnSuHoFPVNimdKsxUgfY=int
EzLrcBpXIWwnSuHoFPVNimdKsxUgft=True
EzLrcBpXIWwnSuHoFPVNimdKsxUgfv=len
EzLrcBpXIWwnSuHoFPVNimdKsxUgMh=str
EzLrcBpXIWwnSuHoFPVNimdKsxUgMC=dict
EzLrcBpXIWwnSuHoFPVNimdKsxUgMl=open
EzLrcBpXIWwnSuHoFPVNimdKsxUgMq=Exception
EzLrcBpXIWwnSuHoFPVNimdKsxUgMf=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
EzLrcBpXIWwnSuHoFPVNimdKsxUghl=[{'title':'홈','uicode':'GN1','came':'home'},{'title':'LIVE 채널','uicode':'GN3','came':'live'},{'title':'VOD 방송','uicode':'GN2','came':'broadcast'},{'title':'영화(Movie)','uicode':'GN17','came':'movie'},{'title':'해외시리즈','uicode':'GN12','came':'global'},{'title':'분류별 - 방송(VOD) - 인기순','uicode':'GENRE','came':'vodgenre','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 방송(VOD) - 최신순','uicode':'GENRE','came':'vodgenre','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','uicode':'GENRE','came':'moviegenre_svod','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','uicode':'GENRE','came':'moviegenre_svod','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색','uicode':'SEARCH','came':'-'},{'title':'Watched(시청목록)','uicode':'WATCH','came':'-'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
EzLrcBpXIWwnSuHoFPVNimdKsxUghq='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
EzLrcBpXIWwnSuHoFPVNimdKsxUghf=xbmc.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class EzLrcBpXIWwnSuHoFPVNimdKsxUghC(EzLrcBpXIWwnSuHoFPVNimdKsxUgfO):
 def __init__(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,EzLrcBpXIWwnSuHoFPVNimdKsxUghj,EzLrcBpXIWwnSuHoFPVNimdKsxUghJ,EzLrcBpXIWwnSuHoFPVNimdKsxUghe):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_url =EzLrcBpXIWwnSuHoFPVNimdKsxUghj
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle=EzLrcBpXIWwnSuHoFPVNimdKsxUghJ
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params =EzLrcBpXIWwnSuHoFPVNimdKsxUghe
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj =swoROTLXaMnvgFJdcVxqfrYWjztlUS() 
 def addon_noti(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,sting):
  try:
   EzLrcBpXIWwnSuHoFPVNimdKsxUghD=xbmcgui.Dialog()
   EzLrcBpXIWwnSuHoFPVNimdKsxUghD.notification(__addonname__,sting)
  except:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfy
 def addon_log(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,string,isDebug=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT):
  try:
   EzLrcBpXIWwnSuHoFPVNimdKsxUghb=string.encode('utf-8','ignore')
  except:
   EzLrcBpXIWwnSuHoFPVNimdKsxUghb='addonException: addon_log'
  if isDebug:EzLrcBpXIWwnSuHoFPVNimdKsxUghQ=xbmc.LOGDEBUG
  else:EzLrcBpXIWwnSuHoFPVNimdKsxUghQ=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,EzLrcBpXIWwnSuHoFPVNimdKsxUghb),level=EzLrcBpXIWwnSuHoFPVNimdKsxUghQ)
 def get_keyboard_input(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,EzLrcBpXIWwnSuHoFPVNimdKsxUgCq):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghR=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy
  kb=xbmc.Keyboard()
  kb.setHeading(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   EzLrcBpXIWwnSuHoFPVNimdKsxUghR=kb.getText()
  return EzLrcBpXIWwnSuHoFPVNimdKsxUghR
 def get_settings_login_info(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghG =__addon__.getSetting('id')
  EzLrcBpXIWwnSuHoFPVNimdKsxUghA =__addon__.getSetting('pw')
  EzLrcBpXIWwnSuHoFPVNimdKsxUghk=__addon__.getSetting('selected_profile')
  return(EzLrcBpXIWwnSuHoFPVNimdKsxUghG,EzLrcBpXIWwnSuHoFPVNimdKsxUghA,EzLrcBpXIWwnSuHoFPVNimdKsxUghk)
 def get_selQuality(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  try:
   EzLrcBpXIWwnSuHoFPVNimdKsxUghO=[1080,720,480,360]
   EzLrcBpXIWwnSuHoFPVNimdKsxUghy=EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(__addon__.getSetting('selected_quality'))
   return EzLrcBpXIWwnSuHoFPVNimdKsxUghO[EzLrcBpXIWwnSuHoFPVNimdKsxUghy]
  except:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfy
  return 1080 
 def get_settings_exclusion21(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghT =__addon__.getSetting('exclusion21')
  if EzLrcBpXIWwnSuHoFPVNimdKsxUghT=='false':
   return EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
  else:
   return EzLrcBpXIWwnSuHoFPVNimdKsxUgft
 def get_settings_direct_replay(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghY=EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(__addon__.getSetting('direct_replay'))
  if EzLrcBpXIWwnSuHoFPVNimdKsxUghY==0:
   return EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
  else:
   return EzLrcBpXIWwnSuHoFPVNimdKsxUgft
 def get_settings_addinfo(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUght =__addon__.getSetting('add_infoyn')
  if EzLrcBpXIWwnSuHoFPVNimdKsxUght=='false':
   return EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
  else:
   return EzLrcBpXIWwnSuHoFPVNimdKsxUgft
 def get_settings_thumbnail_landyn(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghv =EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(__addon__.getSetting('thumbnail_way'))
  if EzLrcBpXIWwnSuHoFPVNimdKsxUghv==0:
   return EzLrcBpXIWwnSuHoFPVNimdKsxUgft
  else:
   return EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
 def set_winCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,credential):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh=xbmcgui.Window(10000)
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh.setProperty('WAVVE_M_CREDENTIAL',credential)
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh.setProperty('WAVVE_M_LOGINTIME',EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh=xbmcgui.Window(10000)
  return EzLrcBpXIWwnSuHoFPVNimdKsxUgCh.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,EzLrcBpXIWwnSuHoFPVNimdKsxUgCk):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh=xbmcgui.Window(10000)
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh.setProperty('WAVVE_M_ORDERBY',EzLrcBpXIWwnSuHoFPVNimdKsxUgCk)
 def get_winEpisodeOrderby(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh=xbmcgui.Window(10000)
  return EzLrcBpXIWwnSuHoFPVNimdKsxUgCh.getProperty('WAVVE_M_ORDERBY')
 def add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,label,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=''):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCl='%s?%s'%(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_url,urllib.parse.urlencode(params))
  if sublabel:EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='%s < %s >'%(label,sublabel)
  else: EzLrcBpXIWwnSuHoFPVNimdKsxUgCq=label
  if not img:img='DefaultFolder.png'
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCf=xbmcgui.ListItem(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq)
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCf.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:EzLrcBpXIWwnSuHoFPVNimdKsxUgCf.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:EzLrcBpXIWwnSuHoFPVNimdKsxUgCf.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle,EzLrcBpXIWwnSuHoFPVNimdKsxUgCl,EzLrcBpXIWwnSuHoFPVNimdKsxUgCf,isFolder)
 def dp_Main_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  for EzLrcBpXIWwnSuHoFPVNimdKsxUgCM in EzLrcBpXIWwnSuHoFPVNimdKsxUghl:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq=EzLrcBpXIWwnSuHoFPVNimdKsxUgCM.get('title')
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgCM.get('uicode')=='GENRE':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'GENRE','uicode':EzLrcBpXIWwnSuHoFPVNimdKsxUgCM.get('came'),'genre':'-','subgenre':'-','orderby':EzLrcBpXIWwnSuHoFPVNimdKsxUgCM.get('orderby'),'ordernm':EzLrcBpXIWwnSuHoFPVNimdKsxUgCM.get('ordernm')}
   elif EzLrcBpXIWwnSuHoFPVNimdKsxUgCM.get('uicode')=='WATCH':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'WATCH','genre':'-'}
   elif EzLrcBpXIWwnSuHoFPVNimdKsxUgCM.get('uicode')=='SEARCH':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'SEARCH','genre':'-'}
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'GNB_LIST','uicode':EzLrcBpXIWwnSuHoFPVNimdKsxUgCM.get('uicode'),'came':EzLrcBpXIWwnSuHoFPVNimdKsxUgCM.get('came')}
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgft
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgCM.get('uicode')=='XXX':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode']='XXX'
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgfv(EzLrcBpXIWwnSuHoFPVNimdKsxUghl)>0:xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle)
 def login_main(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  (EzLrcBpXIWwnSuHoFPVNimdKsxUgCa,EzLrcBpXIWwnSuHoFPVNimdKsxUgCD,EzLrcBpXIWwnSuHoFPVNimdKsxUgCb)=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_settings_login_info()
  if not(EzLrcBpXIWwnSuHoFPVNimdKsxUgCa and EzLrcBpXIWwnSuHoFPVNimdKsxUgCD):
   EzLrcBpXIWwnSuHoFPVNimdKsxUghD=xbmcgui.Dialog()
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCQ=EzLrcBpXIWwnSuHoFPVNimdKsxUghD.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgCQ==EzLrcBpXIWwnSuHoFPVNimdKsxUgft:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_winEpisodeOrderby()=='':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.set_winEpisodeOrderby('desc')
  if EzLrcBpXIWwnSuHoFPVNimdKsxUghM.cookiefile_check():return
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCR =EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCG=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgCG==EzLrcBpXIWwnSuHoFPVNimdKsxUgfy or EzLrcBpXIWwnSuHoFPVNimdKsxUgCG=='':EzLrcBpXIWwnSuHoFPVNimdKsxUgCG=EzLrcBpXIWwnSuHoFPVNimdKsxUgfY('19000101')
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCA=0
   while EzLrcBpXIWwnSuHoFPVNimdKsxUgft:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCA+=1
    time.sleep(0.05)
    if EzLrcBpXIWwnSuHoFPVNimdKsxUgCG>=EzLrcBpXIWwnSuHoFPVNimdKsxUgCR:return
    if EzLrcBpXIWwnSuHoFPVNimdKsxUgCA>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgCG>=EzLrcBpXIWwnSuHoFPVNimdKsxUgCR:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.GetCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUgCa,EzLrcBpXIWwnSuHoFPVNimdKsxUgCD,EzLrcBpXIWwnSuHoFPVNimdKsxUgCb):
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.set_winCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.LoadCredential())
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCk =args.get('orderby')
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.set_winEpisodeOrderby(EzLrcBpXIWwnSuHoFPVNimdKsxUgCk)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Gnb_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.SaveCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_winCredential())
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCO=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.GetGnList(args.get('uicode'))
  for EzLrcBpXIWwnSuHoFPVNimdKsxUgCy in EzLrcBpXIWwnSuHoFPVNimdKsxUgCO:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq=EzLrcBpXIWwnSuHoFPVNimdKsxUgCy.get('title')
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'GN_LIST' if EzLrcBpXIWwnSuHoFPVNimdKsxUgCy.get('uicode')!='CY1' else 'GN_MYVIEW','uicode':EzLrcBpXIWwnSuHoFPVNimdKsxUgCy.get('uicode'),'came':args.get('came'),'page':'1'}
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgfv(EzLrcBpXIWwnSuHoFPVNimdKsxUgCO)>0:xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle,cacheToDisc=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT)
 def dp_Myview_Group(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='VOD 시청내역'
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'MYVIEW_LIST','uicode':'vod','page':'1'}
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='영화 시청내역'
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['uicode']='movie'
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle)
 def dp_Myview_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.SaveCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_winCredential())
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCT =EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_settings_addinfo()
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCY=args.get('uicode')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCt =EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(args.get('page'))
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCv,EzLrcBpXIWwnSuHoFPVNimdKsxUglh=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.GetMyviewList(EzLrcBpXIWwnSuHoFPVNimdKsxUgCY,EzLrcBpXIWwnSuHoFPVNimdKsxUgCt,addinfoyn=EzLrcBpXIWwnSuHoFPVNimdKsxUgCT)
  for EzLrcBpXIWwnSuHoFPVNimdKsxUglC in EzLrcBpXIWwnSuHoFPVNimdKsxUgCv:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq =EzLrcBpXIWwnSuHoFPVNimdKsxUglC.get('title')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglq =EzLrcBpXIWwnSuHoFPVNimdKsxUglC.get('subtitle')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglf=EzLrcBpXIWwnSuHoFPVNimdKsxUglC.get('thumbnail')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglM=EzLrcBpXIWwnSuHoFPVNimdKsxUglC.get('info')
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgCY=='movie' and EzLrcBpXIWwnSuHoFPVNimdKsxUgCT==EzLrcBpXIWwnSuHoFPVNimdKsxUgft:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='%s (%s)'%(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUglM.get('year')))
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUglM['plot']=EzLrcBpXIWwnSuHoFPVNimdKsxUgCq
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgCY=='vod':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'DEEP_LIST','contentid':EzLrcBpXIWwnSuHoFPVNimdKsxUglC.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,'subtitle':EzLrcBpXIWwnSuHoFPVNimdKsxUglq,'thumbnail':EzLrcBpXIWwnSuHoFPVNimdKsxUglf,'viewage':EzLrcBpXIWwnSuHoFPVNimdKsxUglC.get('viewage')}
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgft
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'MOVIE','contentid':EzLrcBpXIWwnSuHoFPVNimdKsxUglC.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,'subtitle':EzLrcBpXIWwnSuHoFPVNimdKsxUglq,'thumbnail':EzLrcBpXIWwnSuHoFPVNimdKsxUglf,'viewage':EzLrcBpXIWwnSuHoFPVNimdKsxUglC.get('viewage')}
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
   if EzLrcBpXIWwnSuHoFPVNimdKsxUglC.get('viewage')=='21':EzLrcBpXIWwnSuHoFPVNimdKsxUglq+=' (%s)'%(EzLrcBpXIWwnSuHoFPVNimdKsxUglC.get('viewage'))
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel=EzLrcBpXIWwnSuHoFPVNimdKsxUglq,img=EzLrcBpXIWwnSuHoFPVNimdKsxUglf,infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUglM,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUglh:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode'] ='MYVIEW_LIST' 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['uicode']=EzLrcBpXIWwnSuHoFPVNimdKsxUgCY 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['page'] =EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUgCt+1)
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='[B]%s >>[/B]'%'다음 페이지'
   EzLrcBpXIWwnSuHoFPVNimdKsxUglq=EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUgCt+1)
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel=EzLrcBpXIWwnSuHoFPVNimdKsxUglq,img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgfv(EzLrcBpXIWwnSuHoFPVNimdKsxUgCv)>0:xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle,cacheToDisc=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT)
 def dp_Genre_Group(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.SaveCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_winCredential())
  EzLrcBpXIWwnSuHoFPVNimdKsxUglj =args.get('mode') 
  EzLrcBpXIWwnSuHoFPVNimdKsxUglJ =args.get('uicode')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgle =args.get('genre') 
  EzLrcBpXIWwnSuHoFPVNimdKsxUgla=args.get('subgenre')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCk =args.get('orderby')
  EzLrcBpXIWwnSuHoFPVNimdKsxUglD =args.get('ordernm')
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgle=='-':
   EzLrcBpXIWwnSuHoFPVNimdKsxUglb=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.GetGenreGroup(EzLrcBpXIWwnSuHoFPVNimdKsxUglJ,EzLrcBpXIWwnSuHoFPVNimdKsxUgle,EzLrcBpXIWwnSuHoFPVNimdKsxUgCk,EzLrcBpXIWwnSuHoFPVNimdKsxUglD,exclusion21=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_settings_exclusion21())
  else:
   EzLrcBpXIWwnSuHoFPVNimdKsxUglQ={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':EzLrcBpXIWwnSuHoFPVNimdKsxUgCk,'ordernm':EzLrcBpXIWwnSuHoFPVNimdKsxUglD}
   EzLrcBpXIWwnSuHoFPVNimdKsxUglb=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.GetGenreGroup_sub(EzLrcBpXIWwnSuHoFPVNimdKsxUglQ)
  for EzLrcBpXIWwnSuHoFPVNimdKsxUglR in EzLrcBpXIWwnSuHoFPVNimdKsxUglb:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq =EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('title')+'  ('+EzLrcBpXIWwnSuHoFPVNimdKsxUglD+')'
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':EzLrcBpXIWwnSuHoFPVNimdKsxUglj,'uicode':EzLrcBpXIWwnSuHoFPVNimdKsxUglJ,'genre':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('genre'),'subgenre':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('subgenre'),'adult':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('adult'),'page':'1','broadcastid':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('broadcastid'),'contenttype':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('contenttype'),'uiparent':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('uiparent'),'uirank':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('uirank'),'uitype':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('uitype'),'orderby':EzLrcBpXIWwnSuHoFPVNimdKsxUgCk,'ordernm':EzLrcBpXIWwnSuHoFPVNimdKsxUglD}
   if EzLrcBpXIWwnSuHoFPVNimdKsxUglJ=='moviegenre' or EzLrcBpXIWwnSuHoFPVNimdKsxUglJ=='moviegenre_svod' or EzLrcBpXIWwnSuHoFPVNimdKsxUglJ=='moviegenre_ppv' or EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('subgenre')!='-':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode'] ='GENRE_LIST'
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgfy
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgfv(EzLrcBpXIWwnSuHoFPVNimdKsxUglb)>0:xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle,cacheToDisc=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT)
 def dp_Genre_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.SaveCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_winCredential())
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCT=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_settings_addinfo()
  EzLrcBpXIWwnSuHoFPVNimdKsxUglJ =args.get('uicode')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCt=EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(args.get('page'))
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'adult':args.get('adult'),'broadcastid':args.get('broadcastid'),'contenttype':args.get('contenttype'),'genre':args.get('genre'),'subgenre':args.get('subgenre'),'uiparent':args.get('uiparent'),'uirank':args.get('uirank'),'uitype':args.get('uitype'),'orderby':args.get('orderby')}
  if args.get('genre')==args.get('subgenre'):
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['subgenre']='all'
  EzLrcBpXIWwnSuHoFPVNimdKsxUglb,EzLrcBpXIWwnSuHoFPVNimdKsxUglh=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.GetGenreList(EzLrcBpXIWwnSuHoFPVNimdKsxUglJ,EzLrcBpXIWwnSuHoFPVNimdKsxUgCj,EzLrcBpXIWwnSuHoFPVNimdKsxUgCt,addinfoyn=EzLrcBpXIWwnSuHoFPVNimdKsxUgCT)
  for EzLrcBpXIWwnSuHoFPVNimdKsxUglR in EzLrcBpXIWwnSuHoFPVNimdKsxUglb:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq =EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('title')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglf=EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('thumbnail')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglM=EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('info')
   if EzLrcBpXIWwnSuHoFPVNimdKsxUglJ=='moviegenre_svod' and EzLrcBpXIWwnSuHoFPVNimdKsxUgCT==EzLrcBpXIWwnSuHoFPVNimdKsxUgft:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='%s (%s)'%(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUglM.get('year')))
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUglM['plot']=EzLrcBpXIWwnSuHoFPVNimdKsxUgCq
   if EzLrcBpXIWwnSuHoFPVNimdKsxUglJ=='vodgenre':
    EzLrcBpXIWwnSuHoFPVNimdKsxUglG={'mode':'DEEP_LIST','contentid':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('uicode'),'contentidType':'contentid','uicode':'vod','page':'1','title':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,'subtitle':'','thumbnail':EzLrcBpXIWwnSuHoFPVNimdKsxUglf,'viewage':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('viewage')}
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgft
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUglG={'mode':'MOVIE','contentid':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('uicode'),'contentidType':'contentid','uicode':'movie','page':'1','title':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,'subtitle':'','thumbnail':EzLrcBpXIWwnSuHoFPVNimdKsxUglf,'viewage':EzLrcBpXIWwnSuHoFPVNimdKsxUglR.get('viewage')}
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
   if EzLrcBpXIWwnSuHoFPVNimdKsxUglG.get('viewage')=='21':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq+=' (%s)'%(EzLrcBpXIWwnSuHoFPVNimdKsxUglG.get('viewage'))
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img=EzLrcBpXIWwnSuHoFPVNimdKsxUglf,infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUglM,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ,params=EzLrcBpXIWwnSuHoFPVNimdKsxUglG)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUglh:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode'] ='GENRE_LIST' 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['uicode']=EzLrcBpXIWwnSuHoFPVNimdKsxUglJ 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['page'] =EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUgCt+1)
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='[B]%s >>[/B]'%'다음 페이지'
   EzLrcBpXIWwnSuHoFPVNimdKsxUglq=EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUgCt+1)
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel=EzLrcBpXIWwnSuHoFPVNimdKsxUglq,img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgfv(EzLrcBpXIWwnSuHoFPVNimdKsxUglb)>0:xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle,cacheToDisc=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT)
 def dp_Deeplink_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.SaveCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_winCredential())
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCT=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_settings_addinfo()
  EzLrcBpXIWwnSuHoFPVNimdKsxUglJ =args.get('uicode')
  EzLrcBpXIWwnSuHoFPVNimdKsxUglA =args.get('came')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCt=EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(args.get('page'))
  EzLrcBpXIWwnSuHoFPVNimdKsxUglk,EzLrcBpXIWwnSuHoFPVNimdKsxUglh=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.GetDeeplinkList(EzLrcBpXIWwnSuHoFPVNimdKsxUglJ,EzLrcBpXIWwnSuHoFPVNimdKsxUglA,EzLrcBpXIWwnSuHoFPVNimdKsxUgCt,addinfoyn=EzLrcBpXIWwnSuHoFPVNimdKsxUgCT)
  for EzLrcBpXIWwnSuHoFPVNimdKsxUglO in EzLrcBpXIWwnSuHoFPVNimdKsxUglk:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq =EzLrcBpXIWwnSuHoFPVNimdKsxUglO.get('title')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglq =EzLrcBpXIWwnSuHoFPVNimdKsxUglO.get('subtitle')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglf=EzLrcBpXIWwnSuHoFPVNimdKsxUglO.get('thumbnail')
   EzLrcBpXIWwnSuHoFPVNimdKsxUgly=EzLrcBpXIWwnSuHoFPVNimdKsxUglO.get('uicode')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglT=EzLrcBpXIWwnSuHoFPVNimdKsxUglO.get('channelepg')
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'uicode':EzLrcBpXIWwnSuHoFPVNimdKsxUgly,'came':EzLrcBpXIWwnSuHoFPVNimdKsxUglA,'contentid':EzLrcBpXIWwnSuHoFPVNimdKsxUglO.get('contentid'),'contentidType':EzLrcBpXIWwnSuHoFPVNimdKsxUglO.get('contentidType'),'page':'1','title':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,'subtitle':EzLrcBpXIWwnSuHoFPVNimdKsxUglq,'thumbnail':EzLrcBpXIWwnSuHoFPVNimdKsxUglf,'viewage':EzLrcBpXIWwnSuHoFPVNimdKsxUglO.get('viewage')}
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgly=='channel':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode'] ='LIVE'
   elif EzLrcBpXIWwnSuHoFPVNimdKsxUgly=='movie':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode'] ='MOVIE'
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode'] ='DEEP_LIST'
   EzLrcBpXIWwnSuHoFPVNimdKsxUglM=EzLrcBpXIWwnSuHoFPVNimdKsxUglO.get('info')
   if EzLrcBpXIWwnSuHoFPVNimdKsxUglT:
    EzLrcBpXIWwnSuHoFPVNimdKsxUglM['plot']='%s\n\n%s'%(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,EzLrcBpXIWwnSuHoFPVNimdKsxUglT)
   elif EzLrcBpXIWwnSuHoFPVNimdKsxUgly=='movie' and EzLrcBpXIWwnSuHoFPVNimdKsxUgCT==EzLrcBpXIWwnSuHoFPVNimdKsxUgft:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='%s (%s)'%(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUglM.get('year')))
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUglM['plot']='%s\n\n%s'%(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,EzLrcBpXIWwnSuHoFPVNimdKsxUglq)
   if EzLrcBpXIWwnSuHoFPVNimdKsxUglO.get('viewage')=='21':EzLrcBpXIWwnSuHoFPVNimdKsxUglq+=' (%s)'%(EzLrcBpXIWwnSuHoFPVNimdKsxUglO.get('viewage'))
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgly in['channel','movie']:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
   elif EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['contentidType']=='direct':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode']='VOD'
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgft
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel=EzLrcBpXIWwnSuHoFPVNimdKsxUglq,img=EzLrcBpXIWwnSuHoFPVNimdKsxUglf,infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUglM,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUglh:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode'] ='GN_LIST' 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['uicode']=EzLrcBpXIWwnSuHoFPVNimdKsxUglJ 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['page'] =EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUgCt+1)
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='[B]%s >>[/B]'%'다음 페이지'
   EzLrcBpXIWwnSuHoFPVNimdKsxUglq=EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUgCt+1)
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel=EzLrcBpXIWwnSuHoFPVNimdKsxUglq,img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgfv(EzLrcBpXIWwnSuHoFPVNimdKsxUglk)>0:xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle,cacheToDisc=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT)
 def dp_Episodelink_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.SaveCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_winCredential())
  EzLrcBpXIWwnSuHoFPVNimdKsxUglY =args.get('contentid')
  EzLrcBpXIWwnSuHoFPVNimdKsxUglt=args.get('contentidType')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCY =args.get('uicode')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCt =EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(args.get('page'))
  EzLrcBpXIWwnSuHoFPVNimdKsxUglv,EzLrcBpXIWwnSuHoFPVNimdKsxUglh=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.GetEpisodeList(EzLrcBpXIWwnSuHoFPVNimdKsxUglY,EzLrcBpXIWwnSuHoFPVNimdKsxUgCY,EzLrcBpXIWwnSuHoFPVNimdKsxUglt,EzLrcBpXIWwnSuHoFPVNimdKsxUgCt,orderby=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_winEpisodeOrderby())
  for EzLrcBpXIWwnSuHoFPVNimdKsxUgqh in EzLrcBpXIWwnSuHoFPVNimdKsxUglv:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq =EzLrcBpXIWwnSuHoFPVNimdKsxUgqh.get('title')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglq =EzLrcBpXIWwnSuHoFPVNimdKsxUgqh.get('subtitle')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglf=EzLrcBpXIWwnSuHoFPVNimdKsxUgqh.get('thumbnail')
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'VOD','uicode':EzLrcBpXIWwnSuHoFPVNimdKsxUgqh.get('uicode'),'contentid':EzLrcBpXIWwnSuHoFPVNimdKsxUgqh.get('contentid'),'programid':EzLrcBpXIWwnSuHoFPVNimdKsxUgqh.get('programid'),'title':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,'subtitle':EzLrcBpXIWwnSuHoFPVNimdKsxUglq,'thumbnail':EzLrcBpXIWwnSuHoFPVNimdKsxUglf,'viewage':EzLrcBpXIWwnSuHoFPVNimdKsxUgqh.get('viewage')}
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgqh.get('viewage')=='21':EzLrcBpXIWwnSuHoFPVNimdKsxUglq+=' (%s)'%(EzLrcBpXIWwnSuHoFPVNimdKsxUgqh.get('viewage'))
   EzLrcBpXIWwnSuHoFPVNimdKsxUgqC=EzLrcBpXIWwnSuHoFPVNimdKsxUgqh.get('info')
   EzLrcBpXIWwnSuHoFPVNimdKsxUgqC['plot']=EzLrcBpXIWwnSuHoFPVNimdKsxUgqh.get('synopsis')
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel=EzLrcBpXIWwnSuHoFPVNimdKsxUglq,img=EzLrcBpXIWwnSuHoFPVNimdKsxUglf,infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgqC,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgCt==1:
   EzLrcBpXIWwnSuHoFPVNimdKsxUglM={'plot':'정렬순서를 변경합니다.'}
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={}
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode'] ='ORDER_BY' 
   if EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_winEpisodeOrderby()=='desc':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='정렬순서변경 : 최신화부터 -> 1회부터'
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['orderby']='asc'
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='정렬순서변경 : 1회부터 -> 최신화부터'
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['orderby']='desc'
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUglM,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUglh:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode'] ='DEEP_LIST' 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['uicode'] =EzLrcBpXIWwnSuHoFPVNimdKsxUgCY 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['contentid'] =EzLrcBpXIWwnSuHoFPVNimdKsxUglY 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['contentidType']=EzLrcBpXIWwnSuHoFPVNimdKsxUglt 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['page'] =EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUgCt+1)
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='[B]%s >>[/B]'%'다음 페이지'
   EzLrcBpXIWwnSuHoFPVNimdKsxUglq=EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUgCt+1)
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel=EzLrcBpXIWwnSuHoFPVNimdKsxUglq,img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgfv(EzLrcBpXIWwnSuHoFPVNimdKsxUglv)>0:xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle,cacheToDisc=EzLrcBpXIWwnSuHoFPVNimdKsxUgft)
 def play_VIDEO(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.SaveCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_winCredential())
  EzLrcBpXIWwnSuHoFPVNimdKsxUglY =args.get('contentid')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCY=args.get('uicode')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgql=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_selQuality()
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.addon_log(EzLrcBpXIWwnSuHoFPVNimdKsxUglY+' - '+EzLrcBpXIWwnSuHoFPVNimdKsxUgCY,EzLrcBpXIWwnSuHoFPVNimdKsxUgfT)
  EzLrcBpXIWwnSuHoFPVNimdKsxUgqf,EzLrcBpXIWwnSuHoFPVNimdKsxUgqM,EzLrcBpXIWwnSuHoFPVNimdKsxUgqj,EzLrcBpXIWwnSuHoFPVNimdKsxUgqJ=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.GetStreamingURL(EzLrcBpXIWwnSuHoFPVNimdKsxUglY,EzLrcBpXIWwnSuHoFPVNimdKsxUgCY,EzLrcBpXIWwnSuHoFPVNimdKsxUgql)
  EzLrcBpXIWwnSuHoFPVNimdKsxUgqe='%s|Cookie=%s'%(EzLrcBpXIWwnSuHoFPVNimdKsxUgqf,EzLrcBpXIWwnSuHoFPVNimdKsxUgqM)
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.addon_log(EzLrcBpXIWwnSuHoFPVNimdKsxUgqe,EzLrcBpXIWwnSuHoFPVNimdKsxUgfT)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgqf=='':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.addon_noti(__language__(30907).encode('utf8'))
   return
  EzLrcBpXIWwnSuHoFPVNimdKsxUgqa=xbmcgui.ListItem(path=EzLrcBpXIWwnSuHoFPVNimdKsxUgqe)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgqj:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgqD=EzLrcBpXIWwnSuHoFPVNimdKsxUgqj['customdata']
   EzLrcBpXIWwnSuHoFPVNimdKsxUgqb =EzLrcBpXIWwnSuHoFPVNimdKsxUgqj['drmhost']
   EzLrcBpXIWwnSuHoFPVNimdKsxUgqQ =inputstreamhelper.Helper('mpd',drm='widevine')
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgqQ.check_inputstream():
    if EzLrcBpXIWwnSuHoFPVNimdKsxUgCY=='movie':
     EzLrcBpXIWwnSuHoFPVNimdKsxUgqR='https://www.wavve.com/player/movie?movieid=%s'%EzLrcBpXIWwnSuHoFPVNimdKsxUglY
    else:
     EzLrcBpXIWwnSuHoFPVNimdKsxUgqR='https://www.wavve.com/player/vod?programid=%s&page=1'%EzLrcBpXIWwnSuHoFPVNimdKsxUglY
    EzLrcBpXIWwnSuHoFPVNimdKsxUgqG={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':EzLrcBpXIWwnSuHoFPVNimdKsxUgqD,'referer':EzLrcBpXIWwnSuHoFPVNimdKsxUgqR,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':EzLrcBpXIWwnSuHoFPVNimdKsxUghq}
    EzLrcBpXIWwnSuHoFPVNimdKsxUgqA=EzLrcBpXIWwnSuHoFPVNimdKsxUgqb+'|'+urllib.parse.urlencode(EzLrcBpXIWwnSuHoFPVNimdKsxUgqG)+'|R{SSM}|'
    EzLrcBpXIWwnSuHoFPVNimdKsxUgqa.setProperty('inputstream',EzLrcBpXIWwnSuHoFPVNimdKsxUgqQ.inputstream_addon)
    EzLrcBpXIWwnSuHoFPVNimdKsxUgqa.setProperty('inputstream.adaptive.manifest_type','mpd')
    EzLrcBpXIWwnSuHoFPVNimdKsxUgqa.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    EzLrcBpXIWwnSuHoFPVNimdKsxUgqa.setProperty('inputstream.adaptive.license_key',EzLrcBpXIWwnSuHoFPVNimdKsxUgqA)
    EzLrcBpXIWwnSuHoFPVNimdKsxUgqa.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(EzLrcBpXIWwnSuHoFPVNimdKsxUghq,EzLrcBpXIWwnSuHoFPVNimdKsxUgqM))
  xbmcplugin.setResolvedUrl(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle,EzLrcBpXIWwnSuHoFPVNimdKsxUgft,EzLrcBpXIWwnSuHoFPVNimdKsxUgqa)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgqJ:
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.addon_noti(EzLrcBpXIWwnSuHoFPVNimdKsxUgqJ.encode('utf-8'))
  else:
   if '/preview.' in urllib.parse.urlsplit(EzLrcBpXIWwnSuHoFPVNimdKsxUgqf).path:EzLrcBpXIWwnSuHoFPVNimdKsxUghM.addon_noti(__language__(30908).encode('utf8'))
  try:
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('viewage')!='21':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'code':args.get('programid')if args.get('mode')=='VOD' else args.get('contentid'),'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    EzLrcBpXIWwnSuHoFPVNimdKsxUghM.Save_Watched_List(args.get('mode').lower(),EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  except:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfy
 def dp_Watch_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgle =args.get('genre')
  EzLrcBpXIWwnSuHoFPVNimdKsxUghY=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_settings_direct_replay()
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgle=='-':
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='VOD 시청내역'
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'WATCH','genre':'vod'}
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='영화 시청내역'
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['genre']='movie'
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
   xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle)
  else:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgqk=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.Load_Watched_List(EzLrcBpXIWwnSuHoFPVNimdKsxUgle)
   for EzLrcBpXIWwnSuHoFPVNimdKsxUgqO in EzLrcBpXIWwnSuHoFPVNimdKsxUgqk:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgqy=EzLrcBpXIWwnSuHoFPVNimdKsxUgMC(urllib.parse.parse_qsl(EzLrcBpXIWwnSuHoFPVNimdKsxUgqO))
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCq =EzLrcBpXIWwnSuHoFPVNimdKsxUgqy.get('title').strip()
    EzLrcBpXIWwnSuHoFPVNimdKsxUglq =EzLrcBpXIWwnSuHoFPVNimdKsxUgqy.get('subtitle').strip()
    if EzLrcBpXIWwnSuHoFPVNimdKsxUglq=='None':EzLrcBpXIWwnSuHoFPVNimdKsxUglq=''
    EzLrcBpXIWwnSuHoFPVNimdKsxUglf=EzLrcBpXIWwnSuHoFPVNimdKsxUgqy.get('img')
    EzLrcBpXIWwnSuHoFPVNimdKsxUgqT =EzLrcBpXIWwnSuHoFPVNimdKsxUgqy.get('videoid')
    EzLrcBpXIWwnSuHoFPVNimdKsxUglM={}
    if EzLrcBpXIWwnSuHoFPVNimdKsxUgle=='movie' and EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_settings_addinfo()==EzLrcBpXIWwnSuHoFPVNimdKsxUgft:
     EzLrcBpXIWwnSuHoFPVNimdKsxUgqY=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.GetMovieInfoList([EzLrcBpXIWwnSuHoFPVNimdKsxUgqy.get('code')])
     EzLrcBpXIWwnSuHoFPVNimdKsxUglM=EzLrcBpXIWwnSuHoFPVNimdKsxUgqY.get(EzLrcBpXIWwnSuHoFPVNimdKsxUgqy.get('code'))
    else:
     EzLrcBpXIWwnSuHoFPVNimdKsxUglM['plot']='%s\n%s'%(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,EzLrcBpXIWwnSuHoFPVNimdKsxUglq)
    if EzLrcBpXIWwnSuHoFPVNimdKsxUgle=='vod':
     if EzLrcBpXIWwnSuHoFPVNimdKsxUghY==EzLrcBpXIWwnSuHoFPVNimdKsxUgfT or EzLrcBpXIWwnSuHoFPVNimdKsxUgqT==EzLrcBpXIWwnSuHoFPVNimdKsxUgfy:
      EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'DEEP_LIST','contentid':EzLrcBpXIWwnSuHoFPVNimdKsxUgqy.get('code'),'contentidType':'programid','uicode':'vod','page':'1'}
      EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgft
     else:
      EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'VOD','contentid':EzLrcBpXIWwnSuHoFPVNimdKsxUgqT,'contentidType':'contentid','programid':EzLrcBpXIWwnSuHoFPVNimdKsxUgqy.get('code'),'uicode':'vod','title':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,'subtitle':EzLrcBpXIWwnSuHoFPVNimdKsxUglq,'thumbnail':EzLrcBpXIWwnSuHoFPVNimdKsxUglf}
      EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
    else:
     EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'MOVIE','contentid':EzLrcBpXIWwnSuHoFPVNimdKsxUgqy.get('code'),'contentidType':'contentid','uicode':'movie','title':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,'thumbnail':EzLrcBpXIWwnSuHoFPVNimdKsxUglf}
     EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
    EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel=EzLrcBpXIWwnSuHoFPVNimdKsxUglq,img=EzLrcBpXIWwnSuHoFPVNimdKsxUglf,infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUglM,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
   EzLrcBpXIWwnSuHoFPVNimdKsxUglM={'plot':'시청목록을 삭제합니다.'}
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='*** 시청목록 삭제 ***'
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'MYVIEW_REMOVE','genre':EzLrcBpXIWwnSuHoFPVNimdKsxUgle}
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUglM,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
   xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle,cacheToDisc=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT)
 def dp_Search_Group(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='VOD 검색'
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'SEARCH_LIST','genre':'vod','page':'1'}
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='영화 검색'
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['genre']='movie'
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle)
 def dp_Search_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.SaveCredential(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_winCredential())
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCT=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_settings_addinfo()
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCY=args.get('genre')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCt =EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(args.get('page'))
  if 'search_key' in args:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgqv=args.get('search_key')
  else:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgqv=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not EzLrcBpXIWwnSuHoFPVNimdKsxUgqv:return
  EzLrcBpXIWwnSuHoFPVNimdKsxUgfh,EzLrcBpXIWwnSuHoFPVNimdKsxUglh=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.GetSearchList(EzLrcBpXIWwnSuHoFPVNimdKsxUgqv,EzLrcBpXIWwnSuHoFPVNimdKsxUgCY,EzLrcBpXIWwnSuHoFPVNimdKsxUgCt,exclusion21=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_settings_exclusion21(),addinfoyn=EzLrcBpXIWwnSuHoFPVNimdKsxUgCT)
  for EzLrcBpXIWwnSuHoFPVNimdKsxUgfC in EzLrcBpXIWwnSuHoFPVNimdKsxUgfh:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq =EzLrcBpXIWwnSuHoFPVNimdKsxUgfC.get('title')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglf=EzLrcBpXIWwnSuHoFPVNimdKsxUgfC.get('thumbnail')
   EzLrcBpXIWwnSuHoFPVNimdKsxUglM=EzLrcBpXIWwnSuHoFPVNimdKsxUgfC.get('info')
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgCY=='movie' and EzLrcBpXIWwnSuHoFPVNimdKsxUgCT==EzLrcBpXIWwnSuHoFPVNimdKsxUgft:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='%s (%s)'%(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUglM.get('year')))
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUglM['plot']=EzLrcBpXIWwnSuHoFPVNimdKsxUgCq
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgCY=='vod':
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'DEEP_LIST','contentid':EzLrcBpXIWwnSuHoFPVNimdKsxUgfC.get('programid'),'contentidType':'programid','uicode':'vod','page':'1','title':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,'subtitle':'','thumbnail':EzLrcBpXIWwnSuHoFPVNimdKsxUglf,'viewage':EzLrcBpXIWwnSuHoFPVNimdKsxUgfC.get('viewage')}
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgft
   else:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCj={'mode':'MOVIE','contentid':EzLrcBpXIWwnSuHoFPVNimdKsxUgfC.get('contentid'),'contentidType':'contentid','uicode':'movie','page':'1','title':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,'subtitle':'','thumbnail':EzLrcBpXIWwnSuHoFPVNimdKsxUglf,'viewage':EzLrcBpXIWwnSuHoFPVNimdKsxUgfC.get('viewage')}
    EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ=EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgCj.get('viewage')=='21':EzLrcBpXIWwnSuHoFPVNimdKsxUgCq+=' (%s)'%(EzLrcBpXIWwnSuHoFPVNimdKsxUgCj.get('viewage'))
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel='',img=EzLrcBpXIWwnSuHoFPVNimdKsxUglf,infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUglM,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgCJ,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUglh:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['mode'] ='SEARCH_LIST' 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['genre']=EzLrcBpXIWwnSuHoFPVNimdKsxUgCY 
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['page'] =EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUgCt+1)
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCj['search_key']=EzLrcBpXIWwnSuHoFPVNimdKsxUgqv
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCq='[B]%s >>[/B]'%'다음 페이지'
   EzLrcBpXIWwnSuHoFPVNimdKsxUglq=EzLrcBpXIWwnSuHoFPVNimdKsxUgMh(EzLrcBpXIWwnSuHoFPVNimdKsxUgCt+1)
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.add_dir(EzLrcBpXIWwnSuHoFPVNimdKsxUgCq,sublabel=EzLrcBpXIWwnSuHoFPVNimdKsxUglq,img='',infoLabels=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy,isFolder=EzLrcBpXIWwnSuHoFPVNimdKsxUgft,params=EzLrcBpXIWwnSuHoFPVNimdKsxUgCj)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgfv(EzLrcBpXIWwnSuHoFPVNimdKsxUgfh)>0:xbmcplugin.endOfDirectory(EzLrcBpXIWwnSuHoFPVNimdKsxUghM._addon_handle)
 def Load_Watched_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,EzLrcBpXIWwnSuHoFPVNimdKsxUgle):
  try:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfl=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EzLrcBpXIWwnSuHoFPVNimdKsxUgle))
   fp=EzLrcBpXIWwnSuHoFPVNimdKsxUgMl(EzLrcBpXIWwnSuHoFPVNimdKsxUgfl,'r',-1,'utf-8')
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfq=fp.readlines()
   fp.close()
  except:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfq=[]
  return EzLrcBpXIWwnSuHoFPVNimdKsxUgfq
 def Save_Watched_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,EzLrcBpXIWwnSuHoFPVNimdKsxUgle,EzLrcBpXIWwnSuHoFPVNimdKsxUghe):
  try:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfl=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EzLrcBpXIWwnSuHoFPVNimdKsxUgle))
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfM=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.Load_Watched_List(EzLrcBpXIWwnSuHoFPVNimdKsxUgle) 
   fp=EzLrcBpXIWwnSuHoFPVNimdKsxUgMl(EzLrcBpXIWwnSuHoFPVNimdKsxUgfl,'w',-1,'utf-8')
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfj=urllib.parse.urlencode(EzLrcBpXIWwnSuHoFPVNimdKsxUghe)
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfj=EzLrcBpXIWwnSuHoFPVNimdKsxUgfj+'\n'
   fp.write(EzLrcBpXIWwnSuHoFPVNimdKsxUgfj)
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfJ=0
   for EzLrcBpXIWwnSuHoFPVNimdKsxUgfe in EzLrcBpXIWwnSuHoFPVNimdKsxUgfM:
    EzLrcBpXIWwnSuHoFPVNimdKsxUgfa=EzLrcBpXIWwnSuHoFPVNimdKsxUgMC(urllib.parse.parse_qsl(EzLrcBpXIWwnSuHoFPVNimdKsxUgfe))
    EzLrcBpXIWwnSuHoFPVNimdKsxUgfD=EzLrcBpXIWwnSuHoFPVNimdKsxUghe.get('code')
    EzLrcBpXIWwnSuHoFPVNimdKsxUgfb=EzLrcBpXIWwnSuHoFPVNimdKsxUgfa.get('code')
    if EzLrcBpXIWwnSuHoFPVNimdKsxUgle=='vod' and EzLrcBpXIWwnSuHoFPVNimdKsxUghM.get_settings_direct_replay()==EzLrcBpXIWwnSuHoFPVNimdKsxUgft:
     EzLrcBpXIWwnSuHoFPVNimdKsxUgfD=EzLrcBpXIWwnSuHoFPVNimdKsxUghe.get('videoid')
     EzLrcBpXIWwnSuHoFPVNimdKsxUgfb=EzLrcBpXIWwnSuHoFPVNimdKsxUgfa.get('videoid')if EzLrcBpXIWwnSuHoFPVNimdKsxUgfb!=EzLrcBpXIWwnSuHoFPVNimdKsxUgfy else '-'
    if EzLrcBpXIWwnSuHoFPVNimdKsxUgfD!=EzLrcBpXIWwnSuHoFPVNimdKsxUgfb:
     fp.write(EzLrcBpXIWwnSuHoFPVNimdKsxUgfe)
     EzLrcBpXIWwnSuHoFPVNimdKsxUgfJ+=1
     if EzLrcBpXIWwnSuHoFPVNimdKsxUgfJ>=50:break
   fp.close()
  except:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfy
 def Delete_Watched_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,EzLrcBpXIWwnSuHoFPVNimdKsxUgle):
  try:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfl=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EzLrcBpXIWwnSuHoFPVNimdKsxUgle))
   fp=EzLrcBpXIWwnSuHoFPVNimdKsxUgMl(EzLrcBpXIWwnSuHoFPVNimdKsxUgfl,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfy
 def dp_WatchList_Delete(EzLrcBpXIWwnSuHoFPVNimdKsxUghM,args):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgle=args.get('genre')
  EzLrcBpXIWwnSuHoFPVNimdKsxUghD=xbmcgui.Dialog()
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCQ=EzLrcBpXIWwnSuHoFPVNimdKsxUghD.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgCQ==EzLrcBpXIWwnSuHoFPVNimdKsxUgfT:sys.exit()
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.Delete_Watched_List(EzLrcBpXIWwnSuHoFPVNimdKsxUgle)
  xbmc.executebuiltin("Container.Refresh")
 def logout(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUghD=xbmcgui.Dialog()
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCQ=EzLrcBpXIWwnSuHoFPVNimdKsxUghD.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgCQ==EzLrcBpXIWwnSuHoFPVNimdKsxUgfT:sys.exit()
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.wininfo_clear()
  if os.path.isfile(EzLrcBpXIWwnSuHoFPVNimdKsxUghf):os.remove(EzLrcBpXIWwnSuHoFPVNimdKsxUghf)
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh=xbmcgui.Window(10000)
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh.setProperty('WAVVE_M_CREDENTIAL','')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgfQ =EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.Get_Now_Datetime()
  EzLrcBpXIWwnSuHoFPVNimdKsxUgfR=EzLrcBpXIWwnSuHoFPVNimdKsxUgfQ+datetime.timedelta(days=EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(__addon__.getSetting('cache_ttl')))
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh=xbmcgui.Window(10000)
  EzLrcBpXIWwnSuHoFPVNimdKsxUgfG={'wavve_token':EzLrcBpXIWwnSuHoFPVNimdKsxUgCh.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':EzLrcBpXIWwnSuHoFPVNimdKsxUgfR.strftime('%Y-%m-%d')}
  try: 
   fp=EzLrcBpXIWwnSuHoFPVNimdKsxUgMl(EzLrcBpXIWwnSuHoFPVNimdKsxUghf,'w',-1,'utf-8')
   json.dump(EzLrcBpXIWwnSuHoFPVNimdKsxUgfG,fp)
   fp.close()
  except EzLrcBpXIWwnSuHoFPVNimdKsxUgMq as exception:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgMf(exception)
 def cookiefile_check(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUgfG={}
  try: 
   fp=EzLrcBpXIWwnSuHoFPVNimdKsxUgMl(EzLrcBpXIWwnSuHoFPVNimdKsxUghf,'r',-1,'utf-8')
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfG= json.load(fp)
   fp.close()
  except EzLrcBpXIWwnSuHoFPVNimdKsxUgMq as exception:
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.wininfo_clear()
   return EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCa =__addon__.getSetting('id')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCD =__addon__.getSetting('pw')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgfA =__addon__.getSetting('selected_profile')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgfG['wavve_id']=base64.standard_b64decode(EzLrcBpXIWwnSuHoFPVNimdKsxUgfG['wavve_id']).decode('utf-8')
  EzLrcBpXIWwnSuHoFPVNimdKsxUgfG['wavve_pw']=base64.standard_b64decode(EzLrcBpXIWwnSuHoFPVNimdKsxUgfG['wavve_pw']).decode('utf-8')
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgCa!=EzLrcBpXIWwnSuHoFPVNimdKsxUgfG['wavve_id']or EzLrcBpXIWwnSuHoFPVNimdKsxUgCD!=EzLrcBpXIWwnSuHoFPVNimdKsxUgfG['wavve_pw']or EzLrcBpXIWwnSuHoFPVNimdKsxUgfA!=EzLrcBpXIWwnSuHoFPVNimdKsxUgfG['wavve_profile']:
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.wininfo_clear()
   return EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCR =EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  EzLrcBpXIWwnSuHoFPVNimdKsxUgfk=EzLrcBpXIWwnSuHoFPVNimdKsxUgfG['wavve_limitdate']
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCG =EzLrcBpXIWwnSuHoFPVNimdKsxUgfY(re.sub('-','',EzLrcBpXIWwnSuHoFPVNimdKsxUgfk))
  if EzLrcBpXIWwnSuHoFPVNimdKsxUgCG<EzLrcBpXIWwnSuHoFPVNimdKsxUgCR:
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.wininfo_clear()
   return EzLrcBpXIWwnSuHoFPVNimdKsxUgfT
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh=xbmcgui.Window(10000)
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh.setProperty('WAVVE_M_CREDENTIAL',EzLrcBpXIWwnSuHoFPVNimdKsxUgfG['wavve_token'])
  EzLrcBpXIWwnSuHoFPVNimdKsxUgCh.setProperty('WAVVE_M_LOGINTIME',EzLrcBpXIWwnSuHoFPVNimdKsxUgfk)
  return EzLrcBpXIWwnSuHoFPVNimdKsxUgft
 def wavve_main(EzLrcBpXIWwnSuHoFPVNimdKsxUghM):
  EzLrcBpXIWwnSuHoFPVNimdKsxUglj=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params.get('mode',EzLrcBpXIWwnSuHoFPVNimdKsxUgfy)
  if EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='LOGOUT':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.logout()
   return
  EzLrcBpXIWwnSuHoFPVNimdKsxUghM.login_main()
  if EzLrcBpXIWwnSuHoFPVNimdKsxUglj is EzLrcBpXIWwnSuHoFPVNimdKsxUgfy:
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_Main_List()
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='GNB_LIST':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_Gnb_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='GN_LIST':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_Deeplink_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='DEEP_LIST':
   EzLrcBpXIWwnSuHoFPVNimdKsxUgCY=EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params.get('uicode',EzLrcBpXIWwnSuHoFPVNimdKsxUgfy)
   if EzLrcBpXIWwnSuHoFPVNimdKsxUgCY in['quick','vod','program','x']:
    EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_Episodelink_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
   else:EzLrcBpXIWwnSuHoFPVNimdKsxUgfy
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj in['LIVE','VOD','MOVIE']:
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.play_VIDEO(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='GN_MYVIEW':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_Myview_Group(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='MYVIEW_LIST':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_Myview_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='GENRE':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_Genre_Group(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='GENRE_LIST':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_Genre_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='WATCH':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_Watch_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='MYVIEW_REMOVE':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_WatchList_Delete(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='SEARCH':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_Search_Group(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='SEARCH_LIST':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_Search_List(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  elif EzLrcBpXIWwnSuHoFPVNimdKsxUglj=='ORDER_BY':
   EzLrcBpXIWwnSuHoFPVNimdKsxUghM.dp_setEpOrderby(EzLrcBpXIWwnSuHoFPVNimdKsxUghM.main_params)
  else:
   EzLrcBpXIWwnSuHoFPVNimdKsxUgfy
# Created by pyminifier (https://github.com/liftoff/pyminifier)
