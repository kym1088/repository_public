__author__="NightRain"
swoROTLXaMnvgFJdcVxqfrYWjztlyB=object
swoROTLXaMnvgFJdcVxqfrYWjztlyu=None
swoROTLXaMnvgFJdcVxqfrYWjztlyP=False
swoROTLXaMnvgFJdcVxqfrYWjztlyh=range
swoROTLXaMnvgFJdcVxqfrYWjztlyK=str
swoROTLXaMnvgFJdcVxqfrYWjztlyG=True
swoROTLXaMnvgFJdcVxqfrYWjztlyD=Exception
swoROTLXaMnvgFJdcVxqfrYWjztlyp=print
swoROTLXaMnvgFJdcVxqfrYWjztlyC=len
swoROTLXaMnvgFJdcVxqfrYWjztlye=dict
swoROTLXaMnvgFJdcVxqfrYWjztlyA=int
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
swoROTLXaMnvgFJdcVxqfrYWjztlUN='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
class swoROTLXaMnvgFJdcVxqfrYWjztlUS(swoROTLXaMnvgFJdcVxqfrYWjztlyB):
 def __init__(swoROTLXaMnvgFJdcVxqfrYWjztlUB):
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN='https://apis.pooq.co.kr'
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.APIKEY='E5F3E0D30947AA5440556471321BB6D9'
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.CREDENTIAL='none'
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.DEVICE='pc'
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.DRM='wm'
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.PARTNER='pooq'
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.POOQZONE='none'
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.REGION='kor'
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.TARGETAGE ='all'
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.HTTPTAG='https://'
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.LIST_LIMIT=30 
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.EP_LIMIT=30 
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.MV_LIMIT=24 
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.guid='none' 
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.guidtimestamp='none' 
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.DEFAULT_HEADER={'user-agent':swoROTLXaMnvgFJdcVxqfrYWjztlUN}
 def callRequestCookies(swoROTLXaMnvgFJdcVxqfrYWjztlUB,jobtype,swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlyu,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu,redirects=swoROTLXaMnvgFJdcVxqfrYWjztlyP):
  swoROTLXaMnvgFJdcVxqfrYWjztlUy=swoROTLXaMnvgFJdcVxqfrYWjztlUB.DEFAULT_HEADER
  if headers:swoROTLXaMnvgFJdcVxqfrYWjztlUy.update(headers)
  if jobtype=='Get':
   swoROTLXaMnvgFJdcVxqfrYWjztlUu=requests.get(swoROTLXaMnvgFJdcVxqfrYWjztlUK,params=params,headers=swoROTLXaMnvgFJdcVxqfrYWjztlUy,cookies=cookies,allow_redirects=redirects)
  else:
   swoROTLXaMnvgFJdcVxqfrYWjztlUu=requests.post(swoROTLXaMnvgFJdcVxqfrYWjztlUK,data=payload,params=params,headers=swoROTLXaMnvgFJdcVxqfrYWjztlUy,cookies=cookies,allow_redirects=redirects)
  return swoROTLXaMnvgFJdcVxqfrYWjztlUu
 def SaveCredential(swoROTLXaMnvgFJdcVxqfrYWjztlUB,swoROTLXaMnvgFJdcVxqfrYWjztlUP):
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.CREDENTIAL=swoROTLXaMnvgFJdcVxqfrYWjztlUP
 def LoadCredential(swoROTLXaMnvgFJdcVxqfrYWjztlUB):
  return swoROTLXaMnvgFJdcVxqfrYWjztlUB.CREDENTIAL
 def GetDefaultParams(swoROTLXaMnvgFJdcVxqfrYWjztlUB):
  swoROTLXaMnvgFJdcVxqfrYWjztlUh={'apikey':swoROTLXaMnvgFJdcVxqfrYWjztlUB.APIKEY,'credential':swoROTLXaMnvgFJdcVxqfrYWjztlUB.CREDENTIAL,'device':swoROTLXaMnvgFJdcVxqfrYWjztlUB.DEVICE,'drm':swoROTLXaMnvgFJdcVxqfrYWjztlUB.DRM,'partner':swoROTLXaMnvgFJdcVxqfrYWjztlUB.PARTNER,'pooqzone':swoROTLXaMnvgFJdcVxqfrYWjztlUB.POOQZONE,'region':swoROTLXaMnvgFJdcVxqfrYWjztlUB.REGION,'targetage':swoROTLXaMnvgFJdcVxqfrYWjztlUB.TARGETAGE}
  return swoROTLXaMnvgFJdcVxqfrYWjztlUh
 def makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB,domain,path,query1=swoROTLXaMnvgFJdcVxqfrYWjztlyu,query2=swoROTLXaMnvgFJdcVxqfrYWjztlyu):
  swoROTLXaMnvgFJdcVxqfrYWjztlUK=domain+path
  if query1:
   swoROTLXaMnvgFJdcVxqfrYWjztlUK+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   swoROTLXaMnvgFJdcVxqfrYWjztlUK+='&%s'%urllib.parse.urlencode(query2)
  return swoROTLXaMnvgFJdcVxqfrYWjztlUK
 def GetGUID(swoROTLXaMnvgFJdcVxqfrYWjztlUB,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   swoROTLXaMnvgFJdcVxqfrYWjztlUp=swoROTLXaMnvgFJdcVxqfrYWjztlUB.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   swoROTLXaMnvgFJdcVxqfrYWjztlUC=GenerateRandomString(5)
   swoROTLXaMnvgFJdcVxqfrYWjztlUe=swoROTLXaMnvgFJdcVxqfrYWjztlUC+media+swoROTLXaMnvgFJdcVxqfrYWjztlUp
   return swoROTLXaMnvgFJdcVxqfrYWjztlUe
  def GenerateRandomString(num):
   from random import randint
   swoROTLXaMnvgFJdcVxqfrYWjztlUA=""
   for i in swoROTLXaMnvgFJdcVxqfrYWjztlyh(0,num):
    s=swoROTLXaMnvgFJdcVxqfrYWjztlyK(randint(1,5))
    swoROTLXaMnvgFJdcVxqfrYWjztlUA+=s
   return swoROTLXaMnvgFJdcVxqfrYWjztlUA
  swoROTLXaMnvgFJdcVxqfrYWjztlUe=GenerateID(guid_str)
  swoROTLXaMnvgFJdcVxqfrYWjztlUE=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetHash(swoROTLXaMnvgFJdcVxqfrYWjztlUe)
  if guidType==2:
   swoROTLXaMnvgFJdcVxqfrYWjztlUE='%s-%s-%s-%s-%s'%(swoROTLXaMnvgFJdcVxqfrYWjztlUE[:8],swoROTLXaMnvgFJdcVxqfrYWjztlUE[8:12],swoROTLXaMnvgFJdcVxqfrYWjztlUE[12:16],swoROTLXaMnvgFJdcVxqfrYWjztlUE[16:20],swoROTLXaMnvgFJdcVxqfrYWjztlUE[20:])
  return swoROTLXaMnvgFJdcVxqfrYWjztlUE
 def GetHash(swoROTLXaMnvgFJdcVxqfrYWjztlUB,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return swoROTLXaMnvgFJdcVxqfrYWjztlyK(m.hexdigest())
 def CheckQuality(swoROTLXaMnvgFJdcVxqfrYWjztlUB,sel_qt,qt_list):
  swoROTLXaMnvgFJdcVxqfrYWjztlUI=0
  for swoROTLXaMnvgFJdcVxqfrYWjztlUH in qt_list:
   if sel_qt>=swoROTLXaMnvgFJdcVxqfrYWjztlUH:return swoROTLXaMnvgFJdcVxqfrYWjztlUH
   swoROTLXaMnvgFJdcVxqfrYWjztlUI=swoROTLXaMnvgFJdcVxqfrYWjztlUH
  return swoROTLXaMnvgFJdcVxqfrYWjztlUI
 def GetCredential(swoROTLXaMnvgFJdcVxqfrYWjztlUB,user_id,user_pw,user_pf):
  swoROTLXaMnvgFJdcVxqfrYWjztlUb=swoROTLXaMnvgFJdcVxqfrYWjztlyP
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/login'
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlUm={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Post',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlUm,params=swoROTLXaMnvgFJdcVxqfrYWjztlUh,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   swoROTLXaMnvgFJdcVxqfrYWjztlUP=swoROTLXaMnvgFJdcVxqfrYWjztlUi['credential']
   if user_pf!=0:
    swoROTLXaMnvgFJdcVxqfrYWjztlUm={'id':swoROTLXaMnvgFJdcVxqfrYWjztlUP,'password':'','profile':swoROTLXaMnvgFJdcVxqfrYWjztlyK(user_pf),'pushid':'','type':'credential'}
    swoROTLXaMnvgFJdcVxqfrYWjztlUh['credential']=swoROTLXaMnvgFJdcVxqfrYWjztlUP 
    swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Post',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlUm,params=swoROTLXaMnvgFJdcVxqfrYWjztlUh,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
    swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
    swoROTLXaMnvgFJdcVxqfrYWjztlUP=swoROTLXaMnvgFJdcVxqfrYWjztlUi['credential']
   if swoROTLXaMnvgFJdcVxqfrYWjztlUP:swoROTLXaMnvgFJdcVxqfrYWjztlUb=swoROTLXaMnvgFJdcVxqfrYWjztlyG
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
   swoROTLXaMnvgFJdcVxqfrYWjztlUP='none' 
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.SaveCredential(swoROTLXaMnvgFJdcVxqfrYWjztlUP)
  return swoROTLXaMnvgFJdcVxqfrYWjztlUb
 def GetIssue(swoROTLXaMnvgFJdcVxqfrYWjztlUB):
  swoROTLXaMnvgFJdcVxqfrYWjztlSU=swoROTLXaMnvgFJdcVxqfrYWjztlyP
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/guid/issue'
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlUh,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   swoROTLXaMnvgFJdcVxqfrYWjztlSN=swoROTLXaMnvgFJdcVxqfrYWjztlUi['guid']
   swoROTLXaMnvgFJdcVxqfrYWjztlSB=swoROTLXaMnvgFJdcVxqfrYWjztlUi['guidtimestamp']
   if swoROTLXaMnvgFJdcVxqfrYWjztlSN:swoROTLXaMnvgFJdcVxqfrYWjztlSU=swoROTLXaMnvgFJdcVxqfrYWjztlyG
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
   swoROTLXaMnvgFJdcVxqfrYWjztlSN='none'
   swoROTLXaMnvgFJdcVxqfrYWjztlSB='none' 
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.guid=swoROTLXaMnvgFJdcVxqfrYWjztlSN
  swoROTLXaMnvgFJdcVxqfrYWjztlUB.guidtimestamp=swoROTLXaMnvgFJdcVxqfrYWjztlSB
  return swoROTLXaMnvgFJdcVxqfrYWjztlSU
 def GetGnList(swoROTLXaMnvgFJdcVxqfrYWjztlUB,gn_str):
  swoROTLXaMnvgFJdcVxqfrYWjztlSy=[]
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/cf/supermultisections/'+gn_str
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlUh,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   if not('multisectionlist' in swoROTLXaMnvgFJdcVxqfrYWjztlUi):return swoROTLXaMnvgFJdcVxqfrYWjztlyu 
   swoROTLXaMnvgFJdcVxqfrYWjztlSu=swoROTLXaMnvgFJdcVxqfrYWjztlUi['multisectionlist']
   for swoROTLXaMnvgFJdcVxqfrYWjztlSP in swoROTLXaMnvgFJdcVxqfrYWjztlSu:
    swoROTLXaMnvgFJdcVxqfrYWjztlSh=swoROTLXaMnvgFJdcVxqfrYWjztlSP['title']
    if swoROTLXaMnvgFJdcVxqfrYWjztlyC(swoROTLXaMnvgFJdcVxqfrYWjztlSh)==0:continue
    if swoROTLXaMnvgFJdcVxqfrYWjztlSh=='minor':continue 
    if re.search(u'베너',swoROTLXaMnvgFJdcVxqfrYWjztlSh):continue
    swoROTLXaMnvgFJdcVxqfrYWjztlSh=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',swoROTLXaMnvgFJdcVxqfrYWjztlSh)
    swoROTLXaMnvgFJdcVxqfrYWjztlSh=swoROTLXaMnvgFJdcVxqfrYWjztlSh.lstrip('#')
    for swoROTLXaMnvgFJdcVxqfrYWjztlSK in swoROTLXaMnvgFJdcVxqfrYWjztlSP['eventlist'][0]['bodylist']:
     if re.search(r'uicode:',swoROTLXaMnvgFJdcVxqfrYWjztlSK):
      swoROTLXaMnvgFJdcVxqfrYWjztlSG={'title':swoROTLXaMnvgFJdcVxqfrYWjztlSh,'uicode':re.sub(r'uicode:','',swoROTLXaMnvgFJdcVxqfrYWjztlSK)}
      swoROTLXaMnvgFJdcVxqfrYWjztlSy.append(swoROTLXaMnvgFJdcVxqfrYWjztlSG)
      break
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
  return swoROTLXaMnvgFJdcVxqfrYWjztlSy
 def GetDeeplinkList(swoROTLXaMnvgFJdcVxqfrYWjztlUB,gn_str,came_str,page_int,addinfoyn=swoROTLXaMnvgFJdcVxqfrYWjztlyP):
  swoROTLXaMnvgFJdcVxqfrYWjztlSD=[]
  swoROTLXaMnvgFJdcVxqfrYWjztlSp=swoROTLXaMnvgFJdcVxqfrYWjztlNP=1
  swoROTLXaMnvgFJdcVxqfrYWjztlSC='quick'
  swoROTLXaMnvgFJdcVxqfrYWjztlSe=swoROTLXaMnvgFJdcVxqfrYWjztlNB=swoROTLXaMnvgFJdcVxqfrYWjztlNy=''
  swoROTLXaMnvgFJdcVxqfrYWjztlSA=swoROTLXaMnvgFJdcVxqfrYWjztlyP
  swoROTLXaMnvgFJdcVxqfrYWjztlSE={}
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/cf/deeplink/'+gn_str
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlUh,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   if not('url' in swoROTLXaMnvgFJdcVxqfrYWjztlUi):return swoROTLXaMnvgFJdcVxqfrYWjztlyu 
   swoROTLXaMnvgFJdcVxqfrYWjztlSI=swoROTLXaMnvgFJdcVxqfrYWjztlUi['url']
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ=urllib.parse.urlsplit(swoROTLXaMnvgFJdcVxqfrYWjztlSI).path
   swoROTLXaMnvgFJdcVxqfrYWjztlSH=swoROTLXaMnvgFJdcVxqfrYWjztlye(urllib.parse.parse_qsl(urllib.parse.urlsplit(swoROTLXaMnvgFJdcVxqfrYWjztlSI).query))
   swoROTLXaMnvgFJdcVxqfrYWjztlSH['came']=came_str 
   swoROTLXaMnvgFJdcVxqfrYWjztlSH['limit']=swoROTLXaMnvgFJdcVxqfrYWjztlyK(swoROTLXaMnvgFJdcVxqfrYWjztlUB.LIST_LIMIT)
   if 'contenttype' in swoROTLXaMnvgFJdcVxqfrYWjztlSH:swoROTLXaMnvgFJdcVxqfrYWjztlSC=swoROTLXaMnvgFJdcVxqfrYWjztlSH['contenttype']
   if came_str=='movie':swoROTLXaMnvgFJdcVxqfrYWjztlSH['mtype']='svod'
   if page_int!=1:
    swoROTLXaMnvgFJdcVxqfrYWjztlSH['offset']=swoROTLXaMnvgFJdcVxqfrYWjztlyK((page_int-1)*swoROTLXaMnvgFJdcVxqfrYWjztlUB.LIST_LIMIT)
    swoROTLXaMnvgFJdcVxqfrYWjztlSH['page'] =swoROTLXaMnvgFJdcVxqfrYWjztlyK(page_int)
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.HTTPTAG+swoROTLXaMnvgFJdcVxqfrYWjztlUQ
   swoROTLXaMnvgFJdcVxqfrYWjztlSH.update(swoROTLXaMnvgFJdcVxqfrYWjztlUh)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlSH,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   if not('celllist' in swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']):return swoROTLXaMnvgFJdcVxqfrYWjztlSD,swoROTLXaMnvgFJdcVxqfrYWjztlSA 
   swoROTLXaMnvgFJdcVxqfrYWjztlSb=swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['celllist']
   if(swoROTLXaMnvgFJdcVxqfrYWjztlSC=='channel' and came_str=='live'):
    if('genre' in swoROTLXaMnvgFJdcVxqfrYWjztlSH):
     swoROTLXaMnvgFJdcVxqfrYWjztlSQ=swoROTLXaMnvgFJdcVxqfrYWjztlSH['genre']
    else:
     swoROTLXaMnvgFJdcVxqfrYWjztlSQ='all'
    swoROTLXaMnvgFJdcVxqfrYWjztlyp("*epgcall*")
    swoROTLXaMnvgFJdcVxqfrYWjztlSE=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetEPGList(swoROTLXaMnvgFJdcVxqfrYWjztlSQ)
   for swoROTLXaMnvgFJdcVxqfrYWjztlSP in swoROTLXaMnvgFJdcVxqfrYWjztlSb:
    swoROTLXaMnvgFJdcVxqfrYWjztlSm=swoROTLXaMnvgFJdcVxqfrYWjztlSi=thumbnail=''
    swoROTLXaMnvgFJdcVxqfrYWjztlSm=swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('title_list')[0].get('text')
    if(swoROTLXaMnvgFJdcVxqfrYWjztlyC(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('title_list'))>1):
     if(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('title_list')[1].get('text').startswith('@')):
      for swoROTLXaMnvgFJdcVxqfrYWjztlSk in swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('bottom_taglist'):
       if swoROTLXaMnvgFJdcVxqfrYWjztlSk=='playy' or swoROTLXaMnvgFJdcVxqfrYWjztlSk=='won':swoROTLXaMnvgFJdcVxqfrYWjztlSi=swoROTLXaMnvgFJdcVxqfrYWjztlSk
     else:
      swoROTLXaMnvgFJdcVxqfrYWjztlSi=swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('title_list')[1].get('text')
      swoROTLXaMnvgFJdcVxqfrYWjztlSi=re.sub(r'(\$O\$)|(\&[a-z]{2}\;)','',swoROTLXaMnvgFJdcVxqfrYWjztlSi)
    if(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('thumbnail')!=''):thumbnail='https://%s'%swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('thumbnail')
    swoROTLXaMnvgFJdcVxqfrYWjztlNU=swoROTLXaMnvgFJdcVxqfrYWjztlSP['event_list'][1].get('url')
    swoROTLXaMnvgFJdcVxqfrYWjztlNS=swoROTLXaMnvgFJdcVxqfrYWjztlye(urllib.parse.parse_qsl(urllib.parse.urlsplit(swoROTLXaMnvgFJdcVxqfrYWjztlNU).query))
    if re.search(u'programid=\&',swoROTLXaMnvgFJdcVxqfrYWjztlNU)and('contentid' in swoROTLXaMnvgFJdcVxqfrYWjztlNS):
     swoROTLXaMnvgFJdcVxqfrYWjztlSe=swoROTLXaMnvgFJdcVxqfrYWjztlNS['contentid']
     swoROTLXaMnvgFJdcVxqfrYWjztlNB='direct'
    elif('contentid' in swoROTLXaMnvgFJdcVxqfrYWjztlNS):
     swoROTLXaMnvgFJdcVxqfrYWjztlSe=swoROTLXaMnvgFJdcVxqfrYWjztlNS['contentid']
     swoROTLXaMnvgFJdcVxqfrYWjztlNB='contentid'
    elif('programid' in swoROTLXaMnvgFJdcVxqfrYWjztlNS):
     swoROTLXaMnvgFJdcVxqfrYWjztlSe=swoROTLXaMnvgFJdcVxqfrYWjztlNS['programid']
     swoROTLXaMnvgFJdcVxqfrYWjztlNB='programid'
     swoROTLXaMnvgFJdcVxqfrYWjztlSC ='program' 
    elif('channelid' in swoROTLXaMnvgFJdcVxqfrYWjztlNS):
     swoROTLXaMnvgFJdcVxqfrYWjztlSe=swoROTLXaMnvgFJdcVxqfrYWjztlNS['channelid']
     swoROTLXaMnvgFJdcVxqfrYWjztlNB='channelid'
     if swoROTLXaMnvgFJdcVxqfrYWjztlSe in swoROTLXaMnvgFJdcVxqfrYWjztlSE:
      swoROTLXaMnvgFJdcVxqfrYWjztlNy=swoROTLXaMnvgFJdcVxqfrYWjztlSE[swoROTLXaMnvgFJdcVxqfrYWjztlSe]
     else:
      swoROTLXaMnvgFJdcVxqfrYWjztlNy=''
    elif('movieid' in swoROTLXaMnvgFJdcVxqfrYWjztlNS):
     swoROTLXaMnvgFJdcVxqfrYWjztlSe=swoROTLXaMnvgFJdcVxqfrYWjztlNS['movieid']
     swoROTLXaMnvgFJdcVxqfrYWjztlNB='movieid'
     swoROTLXaMnvgFJdcVxqfrYWjztlSC='movie' 
    else:
     swoROTLXaMnvgFJdcVxqfrYWjztlSe ='-'
     swoROTLXaMnvgFJdcVxqfrYWjztlNB='-'
    swoROTLXaMnvgFJdcVxqfrYWjztlNu={}
    swoROTLXaMnvgFJdcVxqfrYWjztlNu['mpaa'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('age')
    try:
     if('channelid' in swoROTLXaMnvgFJdcVxqfrYWjztlNS):
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['mediatype'] ='video'
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['title'] ='%s < %s >'%(swoROTLXaMnvgFJdcVxqfrYWjztlSm,swoROTLXaMnvgFJdcVxqfrYWjztlSi)
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['tvshowtitle']=swoROTLXaMnvgFJdcVxqfrYWjztlSi
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['studio'] =swoROTLXaMnvgFJdcVxqfrYWjztlSm
     elif('movieid' in swoROTLXaMnvgFJdcVxqfrYWjztlNS):
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['mediatype'] ='movie'
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['title'] =title_list
     else:
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['mediatype'] ='episode'
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['title'] =title_list
    except:
     swoROTLXaMnvgFJdcVxqfrYWjztlyu
    swoROTLXaMnvgFJdcVxqfrYWjztlSG={'title':swoROTLXaMnvgFJdcVxqfrYWjztlSm,'subtitle':swoROTLXaMnvgFJdcVxqfrYWjztlSi,'thumbnail':thumbnail,'uicode':swoROTLXaMnvgFJdcVxqfrYWjztlSC,'contentid':swoROTLXaMnvgFJdcVxqfrYWjztlSe,'contentidType':swoROTLXaMnvgFJdcVxqfrYWjztlNB,'viewage':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('age'),'channelepg':swoROTLXaMnvgFJdcVxqfrYWjztlNy,'info':swoROTLXaMnvgFJdcVxqfrYWjztlNu}
    swoROTLXaMnvgFJdcVxqfrYWjztlSD.append(swoROTLXaMnvgFJdcVxqfrYWjztlSG)
   swoROTLXaMnvgFJdcVxqfrYWjztlSp=swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['pagecount'])
   if swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['count']:swoROTLXaMnvgFJdcVxqfrYWjztlNP =swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['count'])
   else:swoROTLXaMnvgFJdcVxqfrYWjztlNP=swoROTLXaMnvgFJdcVxqfrYWjztlUB.LIST_LIMIT
   swoROTLXaMnvgFJdcVxqfrYWjztlSA=swoROTLXaMnvgFJdcVxqfrYWjztlSp>swoROTLXaMnvgFJdcVxqfrYWjztlNP
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
  try:
   if swoROTLXaMnvgFJdcVxqfrYWjztlSD[0].get('contentidType')=='movieid' and addinfoyn==swoROTLXaMnvgFJdcVxqfrYWjztlyG:
    swoROTLXaMnvgFJdcVxqfrYWjztlNh=[]
    swoROTLXaMnvgFJdcVxqfrYWjztlNK={}
    for swoROTLXaMnvgFJdcVxqfrYWjztlNG in swoROTLXaMnvgFJdcVxqfrYWjztlSD:swoROTLXaMnvgFJdcVxqfrYWjztlNh.append(swoROTLXaMnvgFJdcVxqfrYWjztlNG.get('contentid'))
    swoROTLXaMnvgFJdcVxqfrYWjztlNK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetMovieInfoList(swoROTLXaMnvgFJdcVxqfrYWjztlNh)
    for i in swoROTLXaMnvgFJdcVxqfrYWjztlyh(swoROTLXaMnvgFJdcVxqfrYWjztlyC(swoROTLXaMnvgFJdcVxqfrYWjztlSD)):
     swoROTLXaMnvgFJdcVxqfrYWjztlSD[i]['info']=swoROTLXaMnvgFJdcVxqfrYWjztlNK.get(swoROTLXaMnvgFJdcVxqfrYWjztlSD[i]['contentid'])
  except:
   swoROTLXaMnvgFJdcVxqfrYWjztlyu
  return(swoROTLXaMnvgFJdcVxqfrYWjztlSD,swoROTLXaMnvgFJdcVxqfrYWjztlSA)
 def GetEpisodeList(swoROTLXaMnvgFJdcVxqfrYWjztlUB,swoROTLXaMnvgFJdcVxqfrYWjztlSe,swoROTLXaMnvgFJdcVxqfrYWjztlSC,swoROTLXaMnvgFJdcVxqfrYWjztlNB,page_int,orderby='desc'):
  swoROTLXaMnvgFJdcVxqfrYWjztlND=[]
  swoROTLXaMnvgFJdcVxqfrYWjztlSp=swoROTLXaMnvgFJdcVxqfrYWjztlNP=1
  swoROTLXaMnvgFJdcVxqfrYWjztlSA=swoROTLXaMnvgFJdcVxqfrYWjztlyP
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   if swoROTLXaMnvgFJdcVxqfrYWjztlNB=='contentid':
    swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/cf/vod/contents/'+swoROTLXaMnvgFJdcVxqfrYWjztlSe
    swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
    swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlUh,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
    swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
    if not('programid' in swoROTLXaMnvgFJdcVxqfrYWjztlUi):return swoROTLXaMnvgFJdcVxqfrYWjztlyu 
    swoROTLXaMnvgFJdcVxqfrYWjztlNC=swoROTLXaMnvgFJdcVxqfrYWjztlUi['programid']
   else:
    swoROTLXaMnvgFJdcVxqfrYWjztlNC=swoROTLXaMnvgFJdcVxqfrYWjztlSe
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/vod/programs-contents/'+swoROTLXaMnvgFJdcVxqfrYWjztlNC
   swoROTLXaMnvgFJdcVxqfrYWjztlSH={'limit':swoROTLXaMnvgFJdcVxqfrYWjztlUB.EP_LIMIT,'offset':swoROTLXaMnvgFJdcVxqfrYWjztlyK((page_int-1)*swoROTLXaMnvgFJdcVxqfrYWjztlUB.EP_LIMIT),'orderby':orderby}
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlSH.update(swoROTLXaMnvgFJdcVxqfrYWjztlUh)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlSH,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   if not('list' in swoROTLXaMnvgFJdcVxqfrYWjztlUi):return swoROTLXaMnvgFJdcVxqfrYWjztlyu 
   swoROTLXaMnvgFJdcVxqfrYWjztlNe=swoROTLXaMnvgFJdcVxqfrYWjztlUi['list']
   for swoROTLXaMnvgFJdcVxqfrYWjztlSP in swoROTLXaMnvgFJdcVxqfrYWjztlNe:
    swoROTLXaMnvgFJdcVxqfrYWjztlNA =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('programtitle')
    swoROTLXaMnvgFJdcVxqfrYWjztlNE ='%s회, %s(%s)'%(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('episodenumber'),swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('releasedate'),swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('releaseweekday'))
    if(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('image')!=''):tmp_thumbnail='https://%s'%swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('image')
    swoROTLXaMnvgFJdcVxqfrYWjztlNI=swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('synopsis')
    swoROTLXaMnvgFJdcVxqfrYWjztlNI=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',swoROTLXaMnvgFJdcVxqfrYWjztlNI)
    swoROTLXaMnvgFJdcVxqfrYWjztlNu={}
    swoROTLXaMnvgFJdcVxqfrYWjztlNu['title'] =swoROTLXaMnvgFJdcVxqfrYWjztlNA
    swoROTLXaMnvgFJdcVxqfrYWjztlNu['mediatype']='episode' 
    swoROTLXaMnvgFJdcVxqfrYWjztlNu['mpaa'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('targetage')
    try:
     if 'episodenumber' in swoROTLXaMnvgFJdcVxqfrYWjztlSP:swoROTLXaMnvgFJdcVxqfrYWjztlNu['episode'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('episodenumber')
     if 'releasedate' in swoROTLXaMnvgFJdcVxqfrYWjztlSP:swoROTLXaMnvgFJdcVxqfrYWjztlNu['year'] =swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('releasedate')[:4])
     if 'releasedate' in swoROTLXaMnvgFJdcVxqfrYWjztlSP:swoROTLXaMnvgFJdcVxqfrYWjztlNu['aired'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('releasedate')
     if 'playtime' in swoROTLXaMnvgFJdcVxqfrYWjztlSP:swoROTLXaMnvgFJdcVxqfrYWjztlNu['duration']=swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('playtime')
     if 'episodeactors' in swoROTLXaMnvgFJdcVxqfrYWjztlSP:
      if swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('episodeactors')!='':swoROTLXaMnvgFJdcVxqfrYWjztlNu['cast']=swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('episodeactors').split(',')
    except:
     swoROTLXaMnvgFJdcVxqfrYWjztlyu
    swoROTLXaMnvgFJdcVxqfrYWjztlNH={'title':swoROTLXaMnvgFJdcVxqfrYWjztlNA,'subtitle':swoROTLXaMnvgFJdcVxqfrYWjztlNE,'thumbnail':tmp_thumbnail,'uicode':swoROTLXaMnvgFJdcVxqfrYWjztlSC,'contentid':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('contentid'),'programid':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('programid'),'synopsis':swoROTLXaMnvgFJdcVxqfrYWjztlNI,'viewage':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('targetage'),'info':swoROTLXaMnvgFJdcVxqfrYWjztlNu}
    swoROTLXaMnvgFJdcVxqfrYWjztlND.append(swoROTLXaMnvgFJdcVxqfrYWjztlNH)
   swoROTLXaMnvgFJdcVxqfrYWjztlSp=swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlUi['pagecount'])
   if swoROTLXaMnvgFJdcVxqfrYWjztlUi['count']:swoROTLXaMnvgFJdcVxqfrYWjztlNP =swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlUi['count'])
   else:swoROTLXaMnvgFJdcVxqfrYWjztlNP=swoROTLXaMnvgFJdcVxqfrYWjztlUB.EP_LIMIT
   swoROTLXaMnvgFJdcVxqfrYWjztlSA=swoROTLXaMnvgFJdcVxqfrYWjztlSp>swoROTLXaMnvgFJdcVxqfrYWjztlNP
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
  return(swoROTLXaMnvgFJdcVxqfrYWjztlND,swoROTLXaMnvgFJdcVxqfrYWjztlSA)
 def GetMyviewList(swoROTLXaMnvgFJdcVxqfrYWjztlUB,swoROTLXaMnvgFJdcVxqfrYWjztlSC,page_int,addinfoyn=swoROTLXaMnvgFJdcVxqfrYWjztlyP):
  swoROTLXaMnvgFJdcVxqfrYWjztlNb=[]
  swoROTLXaMnvgFJdcVxqfrYWjztlSp=swoROTLXaMnvgFJdcVxqfrYWjztlNP=1
  swoROTLXaMnvgFJdcVxqfrYWjztlSA=swoROTLXaMnvgFJdcVxqfrYWjztlyP
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/myview/contents'
   swoROTLXaMnvgFJdcVxqfrYWjztlSH={'contenttype':swoROTLXaMnvgFJdcVxqfrYWjztlSC,'limit':swoROTLXaMnvgFJdcVxqfrYWjztlUB.MV_LIMIT,'offset':swoROTLXaMnvgFJdcVxqfrYWjztlyK((page_int-1)*swoROTLXaMnvgFJdcVxqfrYWjztlUB.MV_LIMIT),'orderby':'new'}
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlSH.update(swoROTLXaMnvgFJdcVxqfrYWjztlUh)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlSH,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   if not('list' in swoROTLXaMnvgFJdcVxqfrYWjztlUi[0]):return swoROTLXaMnvgFJdcVxqfrYWjztlyu 
   swoROTLXaMnvgFJdcVxqfrYWjztlNQ=swoROTLXaMnvgFJdcVxqfrYWjztlUi[0]['list']
   for swoROTLXaMnvgFJdcVxqfrYWjztlSP in swoROTLXaMnvgFJdcVxqfrYWjztlNQ:
    swoROTLXaMnvgFJdcVxqfrYWjztlNu={}
    if swoROTLXaMnvgFJdcVxqfrYWjztlSC=='vod':
     swoROTLXaMnvgFJdcVxqfrYWjztlNA =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('programtitle')
     swoROTLXaMnvgFJdcVxqfrYWjztlNE='%s회, %s'%(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('episodenumber'),swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('releasedate'))
     swoROTLXaMnvgFJdcVxqfrYWjztlSe=swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('contentid')
     swoROTLXaMnvgFJdcVxqfrYWjztlNC=swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('programid')
     swoROTLXaMnvgFJdcVxqfrYWjztlNu['title'] =swoROTLXaMnvgFJdcVxqfrYWjztlNA
     swoROTLXaMnvgFJdcVxqfrYWjztlNu['mediatype']='episode' 
     swoROTLXaMnvgFJdcVxqfrYWjztlNu['mpaa'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('targetage')
     try:
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['studio'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('channelname')
     except:
      swoROTLXaMnvgFJdcVxqfrYWjztlyu
     try:
      if 'releasedate' in swoROTLXaMnvgFJdcVxqfrYWjztlSP:swoROTLXaMnvgFJdcVxqfrYWjztlNu['year'] =swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('releasedate')[:4])
      if 'releasedate' in swoROTLXaMnvgFJdcVxqfrYWjztlSP:swoROTLXaMnvgFJdcVxqfrYWjztlNu['aired'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('releasedate')
     except:
      swoROTLXaMnvgFJdcVxqfrYWjztlyu
    else:
     swoROTLXaMnvgFJdcVxqfrYWjztlNA =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('title')
     swoROTLXaMnvgFJdcVxqfrYWjztlNE='' 
     swoROTLXaMnvgFJdcVxqfrYWjztlSe=swoROTLXaMnvgFJdcVxqfrYWjztlNC=swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('movieid')
     swoROTLXaMnvgFJdcVxqfrYWjztlNu['title'] =swoROTLXaMnvgFJdcVxqfrYWjztlNA
     swoROTLXaMnvgFJdcVxqfrYWjztlNu['mediatype']='movie' 
     swoROTLXaMnvgFJdcVxqfrYWjztlNu['mpaa'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('targetage')
     try:
      if 'releasedate' in swoROTLXaMnvgFJdcVxqfrYWjztlSP:swoROTLXaMnvgFJdcVxqfrYWjztlNu['year'] =swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('releasedate')[:4])
      if 'releasedate' in swoROTLXaMnvgFJdcVxqfrYWjztlSP:swoROTLXaMnvgFJdcVxqfrYWjztlNu['aired'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('releasedate')
     except:
      swoROTLXaMnvgFJdcVxqfrYWjztlyu
    if(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('image')!=''):tmp_thumbnail='https://%s'%swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('image')
    swoROTLXaMnvgFJdcVxqfrYWjztlNm={'title':swoROTLXaMnvgFJdcVxqfrYWjztlNA,'subtitle':swoROTLXaMnvgFJdcVxqfrYWjztlNE,'thumbnail':tmp_thumbnail,'uicode':swoROTLXaMnvgFJdcVxqfrYWjztlSC,'contentid':swoROTLXaMnvgFJdcVxqfrYWjztlSe,'programid':swoROTLXaMnvgFJdcVxqfrYWjztlNC,'viewage':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('targetage'),'info':swoROTLXaMnvgFJdcVxqfrYWjztlNu}
    swoROTLXaMnvgFJdcVxqfrYWjztlNb.append(swoROTLXaMnvgFJdcVxqfrYWjztlNm)
   swoROTLXaMnvgFJdcVxqfrYWjztlSp=swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlUi[0]['pagecount'])
   if swoROTLXaMnvgFJdcVxqfrYWjztlUi[0]['count']:swoROTLXaMnvgFJdcVxqfrYWjztlNP =swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlUi[0]['count'])
   else:swoROTLXaMnvgFJdcVxqfrYWjztlNP=swoROTLXaMnvgFJdcVxqfrYWjztlUB.MV_LIMIT
   swoROTLXaMnvgFJdcVxqfrYWjztlSA=swoROTLXaMnvgFJdcVxqfrYWjztlSp>swoROTLXaMnvgFJdcVxqfrYWjztlNP
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
  try:
   if swoROTLXaMnvgFJdcVxqfrYWjztlSC=='movie' and addinfoyn==swoROTLXaMnvgFJdcVxqfrYWjztlyG:
    swoROTLXaMnvgFJdcVxqfrYWjztlNh=[]
    swoROTLXaMnvgFJdcVxqfrYWjztlNK={}
    for swoROTLXaMnvgFJdcVxqfrYWjztlNG in swoROTLXaMnvgFJdcVxqfrYWjztlNb:swoROTLXaMnvgFJdcVxqfrYWjztlNh.append(swoROTLXaMnvgFJdcVxqfrYWjztlNG.get('contentid'))
    swoROTLXaMnvgFJdcVxqfrYWjztlNK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetMovieInfoList(swoROTLXaMnvgFJdcVxqfrYWjztlNh)
    for i in swoROTLXaMnvgFJdcVxqfrYWjztlyh(swoROTLXaMnvgFJdcVxqfrYWjztlyC(swoROTLXaMnvgFJdcVxqfrYWjztlNb)):
     swoROTLXaMnvgFJdcVxqfrYWjztlNb[i]['info']=swoROTLXaMnvgFJdcVxqfrYWjztlNK.get(swoROTLXaMnvgFJdcVxqfrYWjztlNb[i]['contentid'])
  except:
   swoROTLXaMnvgFJdcVxqfrYWjztlyu
  return swoROTLXaMnvgFJdcVxqfrYWjztlNb,swoROTLXaMnvgFJdcVxqfrYWjztlSA
 def GetSearchList(swoROTLXaMnvgFJdcVxqfrYWjztlUB,search_key,genre,page_int,exclusion21=swoROTLXaMnvgFJdcVxqfrYWjztlyP,addinfoyn=swoROTLXaMnvgFJdcVxqfrYWjztlyP):
  swoROTLXaMnvgFJdcVxqfrYWjztlNk=[]
  swoROTLXaMnvgFJdcVxqfrYWjztlSp=swoROTLXaMnvgFJdcVxqfrYWjztlNP=1
  swoROTLXaMnvgFJdcVxqfrYWjztlSA=swoROTLXaMnvgFJdcVxqfrYWjztlyP
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/cf/search/list.js'
   swoROTLXaMnvgFJdcVxqfrYWjztlSH={'type':'program' if genre=='vod' else 'movie','keyword':search_key,'offset':swoROTLXaMnvgFJdcVxqfrYWjztlyK((page_int-1)*swoROTLXaMnvgFJdcVxqfrYWjztlUB.LIST_LIMIT),'limit':swoROTLXaMnvgFJdcVxqfrYWjztlUB.LIST_LIMIT,'orderby':'score','isplayymovie':'y'}
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlSH.update(swoROTLXaMnvgFJdcVxqfrYWjztlUh)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlSH,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   if not('celllist' in swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']):return swoROTLXaMnvgFJdcVxqfrYWjztlNk,swoROTLXaMnvgFJdcVxqfrYWjztlSA
   swoROTLXaMnvgFJdcVxqfrYWjztlNi=swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['celllist']
   for swoROTLXaMnvgFJdcVxqfrYWjztlSP in swoROTLXaMnvgFJdcVxqfrYWjztlNi:
    swoROTLXaMnvgFJdcVxqfrYWjztlNu={}
    swoROTLXaMnvgFJdcVxqfrYWjztlNA =swoROTLXaMnvgFJdcVxqfrYWjztlSP['title_list'][0]['text']
    if(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('thumbnail')!=''):tmp_thumbnail='https://%s'%swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('thumbnail')
    for swoROTLXaMnvgFJdcVxqfrYWjztlSK in swoROTLXaMnvgFJdcVxqfrYWjztlSP['event_list'][0]['bodylist']:
     if re.search(r'uicode:',swoROTLXaMnvgFJdcVxqfrYWjztlSK):
      if genre=='vod':
       swoROTLXaMnvgFJdcVxqfrYWjztlSe=''
       swoROTLXaMnvgFJdcVxqfrYWjztlNC=re.sub(r'uicode:','',swoROTLXaMnvgFJdcVxqfrYWjztlSK)
       swoROTLXaMnvgFJdcVxqfrYWjztlNu['mediatype']='episode' 
      else:
       swoROTLXaMnvgFJdcVxqfrYWjztlSe=re.sub(r'uicode:','',swoROTLXaMnvgFJdcVxqfrYWjztlSK)
       swoROTLXaMnvgFJdcVxqfrYWjztlNC=''
       if swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('bottom_taglist')[0]=='playy':
        swoROTLXaMnvgFJdcVxqfrYWjztlNA+=' [playy]'
       swoROTLXaMnvgFJdcVxqfrYWjztlNu['mediatype']='movie' 
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['title'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP['title_list'][0]['text']
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['mpaa'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('age')
      swoROTLXaMnvgFJdcVxqfrYWjztlNm={'title':swoROTLXaMnvgFJdcVxqfrYWjztlNA,'thumbnail':tmp_thumbnail,'uicode':genre,'contentid':swoROTLXaMnvgFJdcVxqfrYWjztlSe,'programid':swoROTLXaMnvgFJdcVxqfrYWjztlNC,'viewage':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('age'),'info':swoROTLXaMnvgFJdcVxqfrYWjztlNu}
    if exclusion21==swoROTLXaMnvgFJdcVxqfrYWjztlyP or swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('age')!='21':
     swoROTLXaMnvgFJdcVxqfrYWjztlNk.append(swoROTLXaMnvgFJdcVxqfrYWjztlNm)
   swoROTLXaMnvgFJdcVxqfrYWjztlSp=swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['pagecount'])
   if swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['count']:swoROTLXaMnvgFJdcVxqfrYWjztlNP =swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['count'])
   else:swoROTLXaMnvgFJdcVxqfrYWjztlNP=swoROTLXaMnvgFJdcVxqfrYWjztlUB.LIST_LIMIT
   swoROTLXaMnvgFJdcVxqfrYWjztlSA=swoROTLXaMnvgFJdcVxqfrYWjztlSp>swoROTLXaMnvgFJdcVxqfrYWjztlNP
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
  try:
   if genre=='movie' and addinfoyn==swoROTLXaMnvgFJdcVxqfrYWjztlyG:
    swoROTLXaMnvgFJdcVxqfrYWjztlNh=[]
    swoROTLXaMnvgFJdcVxqfrYWjztlNK={}
    for swoROTLXaMnvgFJdcVxqfrYWjztlNG in swoROTLXaMnvgFJdcVxqfrYWjztlNk:swoROTLXaMnvgFJdcVxqfrYWjztlNh.append(swoROTLXaMnvgFJdcVxqfrYWjztlNG.get('contentid'))
    swoROTLXaMnvgFJdcVxqfrYWjztlNK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetMovieInfoList(swoROTLXaMnvgFJdcVxqfrYWjztlNh)
    for i in swoROTLXaMnvgFJdcVxqfrYWjztlyh(swoROTLXaMnvgFJdcVxqfrYWjztlyC(swoROTLXaMnvgFJdcVxqfrYWjztlNk)):
     swoROTLXaMnvgFJdcVxqfrYWjztlNk[i]['info']=swoROTLXaMnvgFJdcVxqfrYWjztlNK.get(swoROTLXaMnvgFJdcVxqfrYWjztlNk[i]['contentid'])
  except:
   swoROTLXaMnvgFJdcVxqfrYWjztlyu
  return swoROTLXaMnvgFJdcVxqfrYWjztlNk,swoROTLXaMnvgFJdcVxqfrYWjztlSA 
 def GetGenreGroup(swoROTLXaMnvgFJdcVxqfrYWjztlUB,maintype,subtype,swoROTLXaMnvgFJdcVxqfrYWjztlNp,ordernm,exclusion21=swoROTLXaMnvgFJdcVxqfrYWjztlyP):
  swoROTLXaMnvgFJdcVxqfrYWjztlBU=[]
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/cf/filters'
   swoROTLXaMnvgFJdcVxqfrYWjztlSH={'type':maintype}
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlSH.update(swoROTLXaMnvgFJdcVxqfrYWjztlUh)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlSH,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   if not(maintype in swoROTLXaMnvgFJdcVxqfrYWjztlUi):return swoROTLXaMnvgFJdcVxqfrYWjztlyu 
   swoROTLXaMnvgFJdcVxqfrYWjztlBS=swoROTLXaMnvgFJdcVxqfrYWjztlUi[maintype]
   if subtype=='-':
    for swoROTLXaMnvgFJdcVxqfrYWjztlSP in swoROTLXaMnvgFJdcVxqfrYWjztlBS:
     swoROTLXaMnvgFJdcVxqfrYWjztlBN=swoROTLXaMnvgFJdcVxqfrYWjztlye(urllib.parse.parse_qsl(urllib.parse.urlsplit(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('url')).query))
     swoROTLXaMnvgFJdcVxqfrYWjztlNm={'title':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('text'),'genre':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('id'),'subgenre':'-','adult':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('adult'),'broadcastid':swoROTLXaMnvgFJdcVxqfrYWjztlBN.get('broadcastid'),'contenttype':swoROTLXaMnvgFJdcVxqfrYWjztlBN.get('contenttype'),'uiparent':swoROTLXaMnvgFJdcVxqfrYWjztlBN.get('uiparent'),'uirank':swoROTLXaMnvgFJdcVxqfrYWjztlBN.get('uirank'),'uitype':swoROTLXaMnvgFJdcVxqfrYWjztlBN.get('uitype'),'orderby':swoROTLXaMnvgFJdcVxqfrYWjztlNp,'ordernm':ordernm}
     if exclusion21==swoROTLXaMnvgFJdcVxqfrYWjztlyP or swoROTLXaMnvgFJdcVxqfrYWjztlNm.get('adult')=='n':
      swoROTLXaMnvgFJdcVxqfrYWjztlBU.append(swoROTLXaMnvgFJdcVxqfrYWjztlNm)
   else:
    for swoROTLXaMnvgFJdcVxqfrYWjztlSP in swoROTLXaMnvgFJdcVxqfrYWjztlBS:
     if swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('id')==subtype:
      for tt in swoROTLXaMnvgFJdcVxqfrYWjztlSP['sublist']:
       swoROTLXaMnvgFJdcVxqfrYWjztlBN=swoROTLXaMnvgFJdcVxqfrYWjztlye(urlparse.parse_qsl(urlparse.urlsplit(tt.get('url')).query))
       swoROTLXaMnvgFJdcVxqfrYWjztlNm={'title':tt.get('text'),'genre':subtype,'subgenre':tt.get('id'),'adult':tt.get('adult'),'broadcastid':swoROTLXaMnvgFJdcVxqfrYWjztlBN.get('broadcastid'),'contenttype':swoROTLXaMnvgFJdcVxqfrYWjztlBN.get('contenttype'),'uiparent':swoROTLXaMnvgFJdcVxqfrYWjztlBN.get('uiparent'),'uirank':swoROTLXaMnvgFJdcVxqfrYWjztlBN.get('uirank'),'uitype':swoROTLXaMnvgFJdcVxqfrYWjztlBN.get('uitype'),'orderby':swoROTLXaMnvgFJdcVxqfrYWjztlNp,'ordernm':ordernm}
       swoROTLXaMnvgFJdcVxqfrYWjztlBU.append(swoROTLXaMnvgFJdcVxqfrYWjztlNm)
      break
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
  return swoROTLXaMnvgFJdcVxqfrYWjztlBU
 def GetGenreGroup_sub(swoROTLXaMnvgFJdcVxqfrYWjztlUB,in_params):
  swoROTLXaMnvgFJdcVxqfrYWjztlBU=[]
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/cf/vod/newcontents'
   swoROTLXaMnvgFJdcVxqfrYWjztlSH={'WeekDay':'all','limit':'20','offset':'0','orderby':in_params.get('orderby'),'adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlSH.update(swoROTLXaMnvgFJdcVxqfrYWjztlUh)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlSH,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   if not('filter_item_list' in swoROTLXaMnvgFJdcVxqfrYWjztlUi['filter']['filterlist'][1]):return swoROTLXaMnvgFJdcVxqfrYWjztlyu 
   swoROTLXaMnvgFJdcVxqfrYWjztlBS=swoROTLXaMnvgFJdcVxqfrYWjztlUi['filter']['filterlist'][1]['filter_item_list']
   for swoROTLXaMnvgFJdcVxqfrYWjztlSP in swoROTLXaMnvgFJdcVxqfrYWjztlBS:
    swoROTLXaMnvgFJdcVxqfrYWjztlNm={'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype'),'adult':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('adult'),'title':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('title'),'subgenre':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('api_parameters')[swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('api_parameters').find('=')+1:],'orderby':in_params.get('orderby')}
    swoROTLXaMnvgFJdcVxqfrYWjztlBU.append(swoROTLXaMnvgFJdcVxqfrYWjztlNm)
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
  return swoROTLXaMnvgFJdcVxqfrYWjztlBU
 def GetGenreList(swoROTLXaMnvgFJdcVxqfrYWjztlUB,genre,in_params,page_int,addinfoyn=swoROTLXaMnvgFJdcVxqfrYWjztlyP):
  swoROTLXaMnvgFJdcVxqfrYWjztlBU=[]
  swoROTLXaMnvgFJdcVxqfrYWjztlSp=swoROTLXaMnvgFJdcVxqfrYWjztlNP=1
  swoROTLXaMnvgFJdcVxqfrYWjztlSA=swoROTLXaMnvgFJdcVxqfrYWjztlyP
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlSH={'WeekDay':'all','adult':in_params.get('adult'),'broadcastid':in_params.get('broadcastid'),'contenttype':in_params.get('contenttype'),'genre':in_params.get('genre'),'orderby':in_params.get('orderby'),'uiparent':in_params.get('uiparent'),'uirank':in_params.get('uirank'),'uitype':in_params.get('uitype')}
   if genre=='vodgenre':
    swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/cf/vod/newcontents'
    if in_params.get('subgenre')!='-':
     swoROTLXaMnvgFJdcVxqfrYWjztlSH['subgenre']=in_params.get('subgenre')
   else:
    swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/cf/movie/contents'
    swoROTLXaMnvgFJdcVxqfrYWjztlSH['price'] ='all'
    swoROTLXaMnvgFJdcVxqfrYWjztlSH['sptheme']='svod' 
   swoROTLXaMnvgFJdcVxqfrYWjztlSH['limit']=swoROTLXaMnvgFJdcVxqfrYWjztlUB.LIST_LIMIT
   swoROTLXaMnvgFJdcVxqfrYWjztlSH['offset']=swoROTLXaMnvgFJdcVxqfrYWjztlyK((page_int-1)*swoROTLXaMnvgFJdcVxqfrYWjztlUB.LIST_LIMIT)
   swoROTLXaMnvgFJdcVxqfrYWjztlSH['page'] =swoROTLXaMnvgFJdcVxqfrYWjztlyK(page_int)
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlSH.update(swoROTLXaMnvgFJdcVxqfrYWjztlUh)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlSH,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   if not('celllist' in swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']):return swoROTLXaMnvgFJdcVxqfrYWjztlyu 
   swoROTLXaMnvgFJdcVxqfrYWjztlBS=swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['celllist']
   for swoROTLXaMnvgFJdcVxqfrYWjztlSP in swoROTLXaMnvgFJdcVxqfrYWjztlBS:
    swoROTLXaMnvgFJdcVxqfrYWjztlNu={}
    swoROTLXaMnvgFJdcVxqfrYWjztlNA=tmp_thumbnail=''
    swoROTLXaMnvgFJdcVxqfrYWjztlNA =swoROTLXaMnvgFJdcVxqfrYWjztlSP['title_list'][0]['text']
    if(swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('thumbnail')!=''):tmp_thumbnail='https://%s'%swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('thumbnail')
    for swoROTLXaMnvgFJdcVxqfrYWjztlSK in swoROTLXaMnvgFJdcVxqfrYWjztlSP['event_list'][0]['bodylist']:
     if re.search(r'uicode:',swoROTLXaMnvgFJdcVxqfrYWjztlSK):
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['title'] =swoROTLXaMnvgFJdcVxqfrYWjztlNA
      swoROTLXaMnvgFJdcVxqfrYWjztlNu['mpaa'] =swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('age')
      if genre=='moviegenre_svod':
       swoROTLXaMnvgFJdcVxqfrYWjztlNu['mediatype']='movie' 
      else:
       swoROTLXaMnvgFJdcVxqfrYWjztlNu['mediatype']='episode' 
      swoROTLXaMnvgFJdcVxqfrYWjztlNm={'title':swoROTLXaMnvgFJdcVxqfrYWjztlNA,'uicode':re.sub(r'uicode:','',swoROTLXaMnvgFJdcVxqfrYWjztlSK),'thumbnail':tmp_thumbnail,'viewage':swoROTLXaMnvgFJdcVxqfrYWjztlSP.get('age'),'info':swoROTLXaMnvgFJdcVxqfrYWjztlNu}
    swoROTLXaMnvgFJdcVxqfrYWjztlBU.append(swoROTLXaMnvgFJdcVxqfrYWjztlNm)
   swoROTLXaMnvgFJdcVxqfrYWjztlSp=swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['pagecount'])
   if swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['count']:swoROTLXaMnvgFJdcVxqfrYWjztlNP =swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlUi['cell_toplist']['count'])
   else:swoROTLXaMnvgFJdcVxqfrYWjztlNP=swoROTLXaMnvgFJdcVxqfrYWjztlUB.LIST_LIMIT
   swoROTLXaMnvgFJdcVxqfrYWjztlSA=swoROTLXaMnvgFJdcVxqfrYWjztlSp>swoROTLXaMnvgFJdcVxqfrYWjztlNP
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
  try:
   if genre=='moviegenre_svod' and addinfoyn==swoROTLXaMnvgFJdcVxqfrYWjztlyG:
    swoROTLXaMnvgFJdcVxqfrYWjztlNh=[]
    swoROTLXaMnvgFJdcVxqfrYWjztlNK={}
    for swoROTLXaMnvgFJdcVxqfrYWjztlNG in swoROTLXaMnvgFJdcVxqfrYWjztlBU:swoROTLXaMnvgFJdcVxqfrYWjztlNh.append(swoROTLXaMnvgFJdcVxqfrYWjztlNG.get('uicode'))
    swoROTLXaMnvgFJdcVxqfrYWjztlNK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetMovieInfoList(swoROTLXaMnvgFJdcVxqfrYWjztlNh)
    for i in swoROTLXaMnvgFJdcVxqfrYWjztlyh(swoROTLXaMnvgFJdcVxqfrYWjztlyC(swoROTLXaMnvgFJdcVxqfrYWjztlBU)):
     swoROTLXaMnvgFJdcVxqfrYWjztlBU[i]['info']=swoROTLXaMnvgFJdcVxqfrYWjztlNK.get(swoROTLXaMnvgFJdcVxqfrYWjztlBU[i]['uicode'])
  except:
   swoROTLXaMnvgFJdcVxqfrYWjztlyu
  return swoROTLXaMnvgFJdcVxqfrYWjztlBU,swoROTLXaMnvgFJdcVxqfrYWjztlSA
 def Get_Now_Datetime(swoROTLXaMnvgFJdcVxqfrYWjztlUB):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetEPGList(swoROTLXaMnvgFJdcVxqfrYWjztlUB,genre):
  swoROTLXaMnvgFJdcVxqfrYWjztlBu={}
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlBP=swoROTLXaMnvgFJdcVxqfrYWjztlUB.Get_Now_Datetime()
   if genre=='all':
    swoROTLXaMnvgFJdcVxqfrYWjztlBh =swoROTLXaMnvgFJdcVxqfrYWjztlBP+datetime.timedelta(hours=2)
   else:
    swoROTLXaMnvgFJdcVxqfrYWjztlBh =swoROTLXaMnvgFJdcVxqfrYWjztlBP+datetime.timedelta(hours=3)
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlSH={'limit':'100','offset':'0','genre':genre,'startdatetime':swoROTLXaMnvgFJdcVxqfrYWjztlBP.strftime('%Y-%m-%d %H:%M'),'enddatetime':swoROTLXaMnvgFJdcVxqfrYWjztlBh.strftime('%Y-%m-%d %H:%M')}
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/live/epgs'
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlSH.update(swoROTLXaMnvgFJdcVxqfrYWjztlUh)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlSH,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   swoROTLXaMnvgFJdcVxqfrYWjztlBK=swoROTLXaMnvgFJdcVxqfrYWjztlUi['list']
   for swoROTLXaMnvgFJdcVxqfrYWjztlSP in swoROTLXaMnvgFJdcVxqfrYWjztlBK:
    swoROTLXaMnvgFJdcVxqfrYWjztlBG=''
    for swoROTLXaMnvgFJdcVxqfrYWjztlBD in swoROTLXaMnvgFJdcVxqfrYWjztlSP['list']:
     if swoROTLXaMnvgFJdcVxqfrYWjztlBG:swoROTLXaMnvgFJdcVxqfrYWjztlBG+='\n'
     swoROTLXaMnvgFJdcVxqfrYWjztlBG+=swoROTLXaMnvgFJdcVxqfrYWjztlBD['title'].replace('&lt;','<').replace('&gt;','>')+'\n'
     swoROTLXaMnvgFJdcVxqfrYWjztlBG+=' [%s ~ %s]'%(swoROTLXaMnvgFJdcVxqfrYWjztlBD['starttime'][-5:],swoROTLXaMnvgFJdcVxqfrYWjztlBD['endtime'][-5:])+'\n'
    swoROTLXaMnvgFJdcVxqfrYWjztlBu[swoROTLXaMnvgFJdcVxqfrYWjztlSP['channelid']]=swoROTLXaMnvgFJdcVxqfrYWjztlBG
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
  return swoROTLXaMnvgFJdcVxqfrYWjztlBu
 def GetMovieInfoList(swoROTLXaMnvgFJdcVxqfrYWjztlUB,movie_list):
  swoROTLXaMnvgFJdcVxqfrYWjztlBp={}
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlUh =swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ=swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN+'/movie/contents/'
   for swoROTLXaMnvgFJdcVxqfrYWjztlNG in movie_list:
    swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUQ+swoROTLXaMnvgFJdcVxqfrYWjztlNG
    swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlUh,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
    swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
    swoROTLXaMnvgFJdcVxqfrYWjztlNu={}
    swoROTLXaMnvgFJdcVxqfrYWjztlNu['mediatype']='movie'
    swoROTLXaMnvgFJdcVxqfrYWjztlBC=[]
    for swoROTLXaMnvgFJdcVxqfrYWjztlBe in swoROTLXaMnvgFJdcVxqfrYWjztlUi['actors']['list']:swoROTLXaMnvgFJdcVxqfrYWjztlBC.append(swoROTLXaMnvgFJdcVxqfrYWjztlBe.get('text'))
    if swoROTLXaMnvgFJdcVxqfrYWjztlBC[0]!='':swoROTLXaMnvgFJdcVxqfrYWjztlNu['cast']=swoROTLXaMnvgFJdcVxqfrYWjztlBC
    swoROTLXaMnvgFJdcVxqfrYWjztlBA=[]
    for swoROTLXaMnvgFJdcVxqfrYWjztlBE in swoROTLXaMnvgFJdcVxqfrYWjztlUi['directors']['list']:swoROTLXaMnvgFJdcVxqfrYWjztlBA.append(swoROTLXaMnvgFJdcVxqfrYWjztlBE.get('text'))
    if swoROTLXaMnvgFJdcVxqfrYWjztlBA[0]!='':swoROTLXaMnvgFJdcVxqfrYWjztlNu['director']=swoROTLXaMnvgFJdcVxqfrYWjztlBA
    swoROTLXaMnvgFJdcVxqfrYWjztlBU=[]
    for swoROTLXaMnvgFJdcVxqfrYWjztlBI in swoROTLXaMnvgFJdcVxqfrYWjztlUi['genre']['list']:swoROTLXaMnvgFJdcVxqfrYWjztlBU.append(swoROTLXaMnvgFJdcVxqfrYWjztlBI.get('text'))
    if swoROTLXaMnvgFJdcVxqfrYWjztlBU[0]!='':swoROTLXaMnvgFJdcVxqfrYWjztlNu['genre']=swoROTLXaMnvgFJdcVxqfrYWjztlBU
    if swoROTLXaMnvgFJdcVxqfrYWjztlUi.get('releasedate')!='':
     swoROTLXaMnvgFJdcVxqfrYWjztlNu['year'] =swoROTLXaMnvgFJdcVxqfrYWjztlUi['releasedate'][:4]
     swoROTLXaMnvgFJdcVxqfrYWjztlNu['aired'] =swoROTLXaMnvgFJdcVxqfrYWjztlUi['releasedate']
    swoROTLXaMnvgFJdcVxqfrYWjztlNu['country']=swoROTLXaMnvgFJdcVxqfrYWjztlUi['country']
    swoROTLXaMnvgFJdcVxqfrYWjztlNu['duration']=swoROTLXaMnvgFJdcVxqfrYWjztlUi['playtime']
    swoROTLXaMnvgFJdcVxqfrYWjztlNu['title'] =swoROTLXaMnvgFJdcVxqfrYWjztlUi['title']
    swoROTLXaMnvgFJdcVxqfrYWjztlNu['mpaa'] =swoROTLXaMnvgFJdcVxqfrYWjztlUi['targetage']
    swoROTLXaMnvgFJdcVxqfrYWjztlNu['plot'] =swoROTLXaMnvgFJdcVxqfrYWjztlUi['synopsis']
    swoROTLXaMnvgFJdcVxqfrYWjztlBp[swoROTLXaMnvgFJdcVxqfrYWjztlNG]=swoROTLXaMnvgFJdcVxqfrYWjztlNu
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   return{}
  return swoROTLXaMnvgFJdcVxqfrYWjztlBp
 def GetStreamingURL(swoROTLXaMnvgFJdcVxqfrYWjztlUB,swoROTLXaMnvgFJdcVxqfrYWjztlSe,swoROTLXaMnvgFJdcVxqfrYWjztlSC,quality_int):
  swoROTLXaMnvgFJdcVxqfrYWjztlBH=swoROTLXaMnvgFJdcVxqfrYWjztlyS=swoROTLXaMnvgFJdcVxqfrYWjztlyN=streaming_preview=''
  swoROTLXaMnvgFJdcVxqfrYWjztlBb=[]
  try:
   if swoROTLXaMnvgFJdcVxqfrYWjztlSC=='channel':
    swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/live/channels/'+swoROTLXaMnvgFJdcVxqfrYWjztlSe
    swoROTLXaMnvgFJdcVxqfrYWjztlBQ='live'
   elif swoROTLXaMnvgFJdcVxqfrYWjztlSC=='movie':
    swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/cf/movie/contents/'+swoROTLXaMnvgFJdcVxqfrYWjztlSe
    swoROTLXaMnvgFJdcVxqfrYWjztlBQ='movie'
   else: 
    swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/cf/vod/contents/'+swoROTLXaMnvgFJdcVxqfrYWjztlSe
    swoROTLXaMnvgFJdcVxqfrYWjztlBQ='vod'
   swoROTLXaMnvgFJdcVxqfrYWjztlUh=swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetDefaultParams()
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlUh,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   swoROTLXaMnvgFJdcVxqfrYWjztlBm=swoROTLXaMnvgFJdcVxqfrYWjztlUi['qualities']['list']
   if swoROTLXaMnvgFJdcVxqfrYWjztlBm==swoROTLXaMnvgFJdcVxqfrYWjztlyu:return(swoROTLXaMnvgFJdcVxqfrYWjztlBH,swoROTLXaMnvgFJdcVxqfrYWjztlyS,swoROTLXaMnvgFJdcVxqfrYWjztlyN,streaming_preview)
   swoROTLXaMnvgFJdcVxqfrYWjztlBk='hls'
   if 'drms' in swoROTLXaMnvgFJdcVxqfrYWjztlUi:
    if swoROTLXaMnvgFJdcVxqfrYWjztlUi['drms']:
     swoROTLXaMnvgFJdcVxqfrYWjztlBk='dash'
   if 'type' in swoROTLXaMnvgFJdcVxqfrYWjztlUi:
    if swoROTLXaMnvgFJdcVxqfrYWjztlUi['type']=='onair':
     swoROTLXaMnvgFJdcVxqfrYWjztlBQ='onairvod'
   for swoROTLXaMnvgFJdcVxqfrYWjztlBi in swoROTLXaMnvgFJdcVxqfrYWjztlBm:
    swoROTLXaMnvgFJdcVxqfrYWjztlBb.append(swoROTLXaMnvgFJdcVxqfrYWjztlyA(swoROTLXaMnvgFJdcVxqfrYWjztlBi.get('id').rstrip('p')))
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   return(swoROTLXaMnvgFJdcVxqfrYWjztlBH,swoROTLXaMnvgFJdcVxqfrYWjztlyS,swoROTLXaMnvgFJdcVxqfrYWjztlyN,streaming_preview)
  try:
   swoROTLXaMnvgFJdcVxqfrYWjztlyU=swoROTLXaMnvgFJdcVxqfrYWjztlUB.CheckQuality(quality_int,swoROTLXaMnvgFJdcVxqfrYWjztlBb)
   swoROTLXaMnvgFJdcVxqfrYWjztlUQ='/streaming'
   swoROTLXaMnvgFJdcVxqfrYWjztlSH={'contentid':swoROTLXaMnvgFJdcVxqfrYWjztlSe,'contenttype':swoROTLXaMnvgFJdcVxqfrYWjztlBQ,'action':swoROTLXaMnvgFJdcVxqfrYWjztlBk,'quality':swoROTLXaMnvgFJdcVxqfrYWjztlyK(swoROTLXaMnvgFJdcVxqfrYWjztlyU)+'p','deviceModelId':'Windows 10','guid':swoROTLXaMnvgFJdcVxqfrYWjztlUB.GetGUID(guidType=2),'lastplayid':swoROTLXaMnvgFJdcVxqfrYWjztlUB.guid,'authtype':'cookie','isabr':'y','ishevc':'n'}
   swoROTLXaMnvgFJdcVxqfrYWjztlUK=swoROTLXaMnvgFJdcVxqfrYWjztlUB.makeurl(swoROTLXaMnvgFJdcVxqfrYWjztlUB.API_DOMAIN,swoROTLXaMnvgFJdcVxqfrYWjztlUQ)
   swoROTLXaMnvgFJdcVxqfrYWjztlSH.update(swoROTLXaMnvgFJdcVxqfrYWjztlUh)
   swoROTLXaMnvgFJdcVxqfrYWjztlUk=swoROTLXaMnvgFJdcVxqfrYWjztlUB.callRequestCookies('Get',swoROTLXaMnvgFJdcVxqfrYWjztlUK,payload=swoROTLXaMnvgFJdcVxqfrYWjztlyu,params=swoROTLXaMnvgFJdcVxqfrYWjztlSH,headers=swoROTLXaMnvgFJdcVxqfrYWjztlyu,cookies=swoROTLXaMnvgFJdcVxqfrYWjztlyu)
   swoROTLXaMnvgFJdcVxqfrYWjztlUi=json.loads(swoROTLXaMnvgFJdcVxqfrYWjztlUk.text)
   swoROTLXaMnvgFJdcVxqfrYWjztlBH=swoROTLXaMnvgFJdcVxqfrYWjztlUi['playurl']
   if swoROTLXaMnvgFJdcVxqfrYWjztlBH==swoROTLXaMnvgFJdcVxqfrYWjztlyu:return swoROTLXaMnvgFJdcVxqfrYWjztlyu
   swoROTLXaMnvgFJdcVxqfrYWjztlyS=swoROTLXaMnvgFJdcVxqfrYWjztlUi['awscookie']
   swoROTLXaMnvgFJdcVxqfrYWjztlyN =swoROTLXaMnvgFJdcVxqfrYWjztlUi['drm']
   if 'previewmsg' in swoROTLXaMnvgFJdcVxqfrYWjztlUi['preview']:streaming_preview=swoROTLXaMnvgFJdcVxqfrYWjztlUi['preview']['previewmsg']
  except swoROTLXaMnvgFJdcVxqfrYWjztlyD as exception:
   swoROTLXaMnvgFJdcVxqfrYWjztlyp(exception)
  swoROTLXaMnvgFJdcVxqfrYWjztlBH=swoROTLXaMnvgFJdcVxqfrYWjztlBH.replace('pooq.co.kr','wavve.com')
  return(swoROTLXaMnvgFJdcVxqfrYWjztlBH,swoROTLXaMnvgFJdcVxqfrYWjztlyS,swoROTLXaMnvgFJdcVxqfrYWjztlyN,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
