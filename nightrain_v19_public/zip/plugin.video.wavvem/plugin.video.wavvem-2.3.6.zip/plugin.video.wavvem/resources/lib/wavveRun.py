__author__="NightRain"
QSaMbpHtfXjDOcUKoGhRlLPqENsFkd=object
QSaMbpHtfXjDOcUKoGhRlLPqENsFkz=None
QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ=int
QSaMbpHtfXjDOcUKoGhRlLPqENsFkY=True
QSaMbpHtfXjDOcUKoGhRlLPqENsFkA=False
QSaMbpHtfXjDOcUKoGhRlLPqENsFky=type
QSaMbpHtfXjDOcUKoGhRlLPqENsFkv=dict
QSaMbpHtfXjDOcUKoGhRlLPqENsFkn=len
QSaMbpHtfXjDOcUKoGhRlLPqENsFkx=range
QSaMbpHtfXjDOcUKoGhRlLPqENsFkw=str
QSaMbpHtfXjDOcUKoGhRlLPqENsFkB=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
QSaMbpHtfXjDOcUKoGhRlLPqENsFId=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
QSaMbpHtfXjDOcUKoGhRlLPqENsFIz=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
QSaMbpHtfXjDOcUKoGhRlLPqENsFIJ=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
QSaMbpHtfXjDOcUKoGhRlLPqENsFIY =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
QSaMbpHtfXjDOcUKoGhRlLPqENsFIA=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class QSaMbpHtfXjDOcUKoGhRlLPqENsFIr(QSaMbpHtfXjDOcUKoGhRlLPqENsFkd):
 def __init__(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,QSaMbpHtfXjDOcUKoGhRlLPqENsFIy,QSaMbpHtfXjDOcUKoGhRlLPqENsFIv,QSaMbpHtfXjDOcUKoGhRlLPqENsFIn):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_url =QSaMbpHtfXjDOcUKoGhRlLPqENsFIy
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle=QSaMbpHtfXjDOcUKoGhRlLPqENsFIv
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.main_params =QSaMbpHtfXjDOcUKoGhRlLPqENsFIn
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj =WUvsgTwcBQpfdGFeViHxzCEkyDuMja() 
 def addon_noti(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,sting):
  try:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIw=xbmcgui.Dialog()
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIw.notification(__addonname__,sting)
  except:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFkz
 def addon_log(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,string):
  try:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIB=string.encode('utf-8','ignore')
  except:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIB='addonException: addon_log'
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIu=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,QSaMbpHtfXjDOcUKoGhRlLPqENsFIB),level=QSaMbpHtfXjDOcUKoGhRlLPqENsFIu)
 def get_keyboard_input(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,QSaMbpHtfXjDOcUKoGhRlLPqENsFrv):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIg=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz
  kb=xbmc.Keyboard()
  kb.setHeading(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIg=kb.getText()
  return QSaMbpHtfXjDOcUKoGhRlLPqENsFIg
 def get_settings_account(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIV =__addon__.getSetting('id')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIW =__addon__.getSetting('pw')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIT=QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(__addon__.getSetting('selected_profile'))
  return(QSaMbpHtfXjDOcUKoGhRlLPqENsFIV,QSaMbpHtfXjDOcUKoGhRlLPqENsFIW,QSaMbpHtfXjDOcUKoGhRlLPqENsFIT)
 def get_settings_totalsearch(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIC =QSaMbpHtfXjDOcUKoGhRlLPqENsFkY if __addon__.getSetting('local_search')=='true' else QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIi=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY if __addon__.getSetting('local_history')=='true' else QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIe =QSaMbpHtfXjDOcUKoGhRlLPqENsFkY if __addon__.getSetting('total_search')=='true' else QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIm=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY if __addon__.getSetting('total_history')=='true' else QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrI=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY if __addon__.getSetting('menu_bookmark')=='true' else QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  return(QSaMbpHtfXjDOcUKoGhRlLPqENsFIC,QSaMbpHtfXjDOcUKoGhRlLPqENsFIi,QSaMbpHtfXjDOcUKoGhRlLPqENsFIe,QSaMbpHtfXjDOcUKoGhRlLPqENsFIm,QSaMbpHtfXjDOcUKoGhRlLPqENsFrI)
 def get_settings_makebookmark(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  return QSaMbpHtfXjDOcUKoGhRlLPqENsFkY if __addon__.getSetting('make_bookmark')=='true' else QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
 def get_settings_play(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrd={'enable_hdr':QSaMbpHtfXjDOcUKoGhRlLPqENsFkY if __addon__.getSetting('enable_hdr')=='true' else QSaMbpHtfXjDOcUKoGhRlLPqENsFkA,}
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFrd['enable_hdr']==QSaMbpHtfXjDOcUKoGhRlLPqENsFkY:
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_selQuality()<1080:QSaMbpHtfXjDOcUKoGhRlLPqENsFrd['enable_hdr']=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  return(QSaMbpHtfXjDOcUKoGhRlLPqENsFrd)
 def get_selQuality(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  try:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrz=[1080,720,480,360]
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrJ=QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(__addon__.getSetting('selected_quality'))
   return QSaMbpHtfXjDOcUKoGhRlLPqENsFrz[QSaMbpHtfXjDOcUKoGhRlLPqENsFrJ]
  except:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFkz
  return 1080 
 def get_settings_exclusion21(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrY =__addon__.getSetting('exclusion21')
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFrY=='false':
   return QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  else:
   return QSaMbpHtfXjDOcUKoGhRlLPqENsFkY
 def get_settings_direct_replay(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrA=QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(__addon__.getSetting('direct_replay'))
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFrA==0:
   return QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  else:
   return QSaMbpHtfXjDOcUKoGhRlLPqENsFkY
 def set_winEpisodeOrderby(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,QSaMbpHtfXjDOcUKoGhRlLPqENsFrk):
  __addon__.setSetting('wavve_orderby',QSaMbpHtfXjDOcUKoGhRlLPqENsFrk)
 def get_winEpisodeOrderby(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrk=__addon__.getSetting('wavve_orderby')
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFrk in['',QSaMbpHtfXjDOcUKoGhRlLPqENsFkz]:QSaMbpHtfXjDOcUKoGhRlLPqENsFrk='desc'
  return QSaMbpHtfXjDOcUKoGhRlLPqENsFrk
 def add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,label,sublabel='',img='',infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params='',isLink=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA,ContextMenu=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFry='%s?%s'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_url,urllib.parse.urlencode(params))
  if sublabel:QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='%s < %s >'%(label,sublabel)
  else: QSaMbpHtfXjDOcUKoGhRlLPqENsFrv=label
  if not img:img='DefaultFolder.png'
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrn=xbmcgui.ListItem(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFky(img)==QSaMbpHtfXjDOcUKoGhRlLPqENsFkv:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrn.setArt(img)
  else:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrn.setArt({'thumb':img,'poster':img})
  if infoLabels:QSaMbpHtfXjDOcUKoGhRlLPqENsFrn.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrn.setProperty('IsPlayable','true')
  if ContextMenu:QSaMbpHtfXjDOcUKoGhRlLPqENsFrn.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,QSaMbpHtfXjDOcUKoGhRlLPqENsFry,QSaMbpHtfXjDOcUKoGhRlLPqENsFrn,isFolder)
 def dp_Main_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  (QSaMbpHtfXjDOcUKoGhRlLPqENsFIC,QSaMbpHtfXjDOcUKoGhRlLPqENsFIi,QSaMbpHtfXjDOcUKoGhRlLPqENsFIe,QSaMbpHtfXjDOcUKoGhRlLPqENsFIm,QSaMbpHtfXjDOcUKoGhRlLPqENsFrI)=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_totalsearch()
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFrx in QSaMbpHtfXjDOcUKoGhRlLPqENsFId:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv=QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('title')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrw=''
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('mode')=='SEARCH_GROUP' and QSaMbpHtfXjDOcUKoGhRlLPqENsFIC ==QSaMbpHtfXjDOcUKoGhRlLPqENsFkA:continue
   elif QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('mode')=='SEARCH_HISTORY' and QSaMbpHtfXjDOcUKoGhRlLPqENsFIi==QSaMbpHtfXjDOcUKoGhRlLPqENsFkA:continue
   elif QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('mode')=='TOTAL_SEARCH' and QSaMbpHtfXjDOcUKoGhRlLPqENsFIe ==QSaMbpHtfXjDOcUKoGhRlLPqENsFkA:continue
   elif QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('mode')=='TOTAL_HISTORY' and QSaMbpHtfXjDOcUKoGhRlLPqENsFIm==QSaMbpHtfXjDOcUKoGhRlLPqENsFkA:continue
   elif QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('mode')=='MENU_BOOKMARK' and QSaMbpHtfXjDOcUKoGhRlLPqENsFrI==QSaMbpHtfXjDOcUKoGhRlLPqENsFkA:continue
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('mode'),'sCode':QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('sCode'),'sIndex':QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('sIndex'),'sType':QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('sType'),'suburl':QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('suburl'),'subapi':QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('subapi'),'page':QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('page'),'orderby':QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('orderby'),'ordernm':QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('ordernm')}
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFru=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
    QSaMbpHtfXjDOcUKoGhRlLPqENsFrg =QSaMbpHtfXjDOcUKoGhRlLPqENsFkY
   else:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFru=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY
    QSaMbpHtfXjDOcUKoGhRlLPqENsFrg =QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
   if 'icon' in QSaMbpHtfXjDOcUKoGhRlLPqENsFrx:QSaMbpHtfXjDOcUKoGhRlLPqENsFrw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',QSaMbpHtfXjDOcUKoGhRlLPqENsFrx.get('icon')) 
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img=QSaMbpHtfXjDOcUKoGhRlLPqENsFrw,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFru,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB,isLink=QSaMbpHtfXjDOcUKoGhRlLPqENsFrg)
  xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY)
 def dp_Search_Group(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  if 'search_key' in args:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrT=args.get('search_key')
  else:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrT=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not QSaMbpHtfXjDOcUKoGhRlLPqENsFrT:
    return
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFrC in QSaMbpHtfXjDOcUKoGhRlLPqENsFIz:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFri =QSaMbpHtfXjDOcUKoGhRlLPqENsFrC.get('mode')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFre=QSaMbpHtfXjDOcUKoGhRlLPqENsFrC.get('sType')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv=QSaMbpHtfXjDOcUKoGhRlLPqENsFrC.get('title')
   (QSaMbpHtfXjDOcUKoGhRlLPqENsFrm,QSaMbpHtfXjDOcUKoGhRlLPqENsFdI)=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_Search_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFrT,QSaMbpHtfXjDOcUKoGhRlLPqENsFre,1,exclusion21=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_exclusion21())
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdr={'plot':'검색어 : '+QSaMbpHtfXjDOcUKoGhRlLPqENsFrT+'\n\n'+QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.Search_FreeList(QSaMbpHtfXjDOcUKoGhRlLPqENsFrm)}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':QSaMbpHtfXjDOcUKoGhRlLPqENsFri,'sType':QSaMbpHtfXjDOcUKoGhRlLPqENsFre,'search_key':QSaMbpHtfXjDOcUKoGhRlLPqENsFrT,'page':'1',}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img='',infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdr,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFIz)>0:xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.Save_Searched_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFrT)
 def Search_FreeList(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,search_list):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdz=''
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdJ=7
  try:
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(search_list)==0:return '검색결과 없음'
   for i in QSaMbpHtfXjDOcUKoGhRlLPqENsFkx(QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(search_list)):
    if i>=QSaMbpHtfXjDOcUKoGhRlLPqENsFdJ:
     QSaMbpHtfXjDOcUKoGhRlLPqENsFdz=QSaMbpHtfXjDOcUKoGhRlLPqENsFdz+'...'
     break
    QSaMbpHtfXjDOcUKoGhRlLPqENsFdz=QSaMbpHtfXjDOcUKoGhRlLPqENsFdz+search_list[i]['title']+'\n'
  except:
   return ''
  return QSaMbpHtfXjDOcUKoGhRlLPqENsFdz
 def dp_Watch_Group(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdY in QSaMbpHtfXjDOcUKoGhRlLPqENsFIJ:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv=QSaMbpHtfXjDOcUKoGhRlLPqENsFdY.get('title')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':QSaMbpHtfXjDOcUKoGhRlLPqENsFdY.get('mode'),'sType':QSaMbpHtfXjDOcUKoGhRlLPqENsFdY.get('sType')}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img='',infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFIJ)>0:xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY)
 def dp_Search_History(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdA=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.Load_List_File('search')
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdk in QSaMbpHtfXjDOcUKoGhRlLPqENsFdA:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdy=QSaMbpHtfXjDOcUKoGhRlLPqENsFkv(urllib.parse.parse_qsl(QSaMbpHtfXjDOcUKoGhRlLPqENsFdk))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdv=QSaMbpHtfXjDOcUKoGhRlLPqENsFdy.get('skey').strip()
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'SEARCH_GROUP','search_key':QSaMbpHtfXjDOcUKoGhRlLPqENsFdv,}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdn={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':QSaMbpHtfXjDOcUKoGhRlLPqENsFdv,'vType':'-',}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdx=urllib.parse.urlencode(QSaMbpHtfXjDOcUKoGhRlLPqENsFdn)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdw=[('선택된 검색어 ( %s ) 삭제'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFdv),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFdx))]
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFdv,sublabel='',img=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB,ContextMenu=QSaMbpHtfXjDOcUKoGhRlLPqENsFdw)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'plot':'검색목록 전체를 삭제합니다.'}
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img=QSaMbpHtfXjDOcUKoGhRlLPqENsFrw,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB,isLink=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY)
  xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_Search_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFre =args.get('sType')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdu =QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(args.get('page'))
  if 'search_key' in args:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrT=args.get('search_key')
  else:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrT=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not QSaMbpHtfXjDOcUKoGhRlLPqENsFrT:
    xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle)
    return
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg,QSaMbpHtfXjDOcUKoGhRlLPqENsFdI=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_Search_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFrT,QSaMbpHtfXjDOcUKoGhRlLPqENsFre,QSaMbpHtfXjDOcUKoGhRlLPqENsFdu,exclusion21=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_exclusion21())
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdW =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('videoid')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdT =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('vidtype')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('title')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdC=QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('thumbnail')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdi =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('age')
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFdi=='18' or QSaMbpHtfXjDOcUKoGhRlLPqENsFdi=='19' or QSaMbpHtfXjDOcUKoGhRlLPqENsFdi=='21':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv+=' (%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFdi)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'mediatype':'tvshow' if QSaMbpHtfXjDOcUKoGhRlLPqENsFre=='vod' else 'movie','mpaa':QSaMbpHtfXjDOcUKoGhRlLPqENsFdi,'title':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'plot':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv}
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFre=='vod':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'EPISODE_LIST','seasonid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'page':'1',}
    QSaMbpHtfXjDOcUKoGhRlLPqENsFru=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY
   else:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'MOVIE','contentid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'title':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'thumbnail':QSaMbpHtfXjDOcUKoGhRlLPqENsFdC,'age':QSaMbpHtfXjDOcUKoGhRlLPqENsFdi,}
    QSaMbpHtfXjDOcUKoGhRlLPqENsFru=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdw=[]
   QSaMbpHtfXjDOcUKoGhRlLPqENsFde={'mode':'VIEW_DETAIL','values':{'videoid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'vidtype':'tvshow' if QSaMbpHtfXjDOcUKoGhRlLPqENsFre=='vod' else 'movie','contenttype':QSaMbpHtfXjDOcUKoGhRlLPqENsFdT,}}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdm=json.dumps(QSaMbpHtfXjDOcUKoGhRlLPqENsFde,separators=(',',':'))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdm=base64.standard_b64encode(QSaMbpHtfXjDOcUKoGhRlLPqENsFdm.encode()).decode('utf-8')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdm=QSaMbpHtfXjDOcUKoGhRlLPqENsFdm.replace('+','%2B')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzI='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFdm)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdw.append(('상세정보 조회',QSaMbpHtfXjDOcUKoGhRlLPqENsFzI))
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_makebookmark():
    QSaMbpHtfXjDOcUKoGhRlLPqENsFde={'videoid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'vidtype':'tvshow' if QSaMbpHtfXjDOcUKoGhRlLPqENsFre=='vod' else 'movie','vtitle':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'vsubtitle':'','contenttype':QSaMbpHtfXjDOcUKoGhRlLPqENsFdT,}
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzr=json.dumps(QSaMbpHtfXjDOcUKoGhRlLPqENsFde)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzr=urllib.parse.quote(QSaMbpHtfXjDOcUKoGhRlLPqENsFzr)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzI='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFzr)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFdw.append(('(통합) 찜 영상에 추가',QSaMbpHtfXjDOcUKoGhRlLPqENsFzI))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img=QSaMbpHtfXjDOcUKoGhRlLPqENsFdC,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFru,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB,ContextMenu=QSaMbpHtfXjDOcUKoGhRlLPqENsFdw)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFdI:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['mode'] ='SEARCH_LIST' 
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['sType']=QSaMbpHtfXjDOcUKoGhRlLPqENsFre 
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['page'] =QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['search_key']=QSaMbpHtfXjDOcUKoGhRlLPqENsFrT
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='[B]%s >>[/B]'%'다음 페이지'
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzd=QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFrw,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFre=='movie':xbmcplugin.setContent(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,'movies')
  else:xbmcplugin.setContent(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_Watch_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFre =args.get('sType')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrA=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_direct_replay()
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.Load_List_File(QSaMbpHtfXjDOcUKoGhRlLPqENsFre)
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdy=QSaMbpHtfXjDOcUKoGhRlLPqENsFkv(urllib.parse.parse_qsl(QSaMbpHtfXjDOcUKoGhRlLPqENsFdV))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzJ =QSaMbpHtfXjDOcUKoGhRlLPqENsFdy.get('code').strip()
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv =QSaMbpHtfXjDOcUKoGhRlLPqENsFdy.get('title').strip()
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzd =QSaMbpHtfXjDOcUKoGhRlLPqENsFdy.get('subtitle').strip()
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFzd=='None':QSaMbpHtfXjDOcUKoGhRlLPqENsFzd=''
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdC=QSaMbpHtfXjDOcUKoGhRlLPqENsFdy.get('img').strip()
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdW =QSaMbpHtfXjDOcUKoGhRlLPqENsFdy.get('videoid').strip()
   try:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFdC=QSaMbpHtfXjDOcUKoGhRlLPqENsFdC.replace('\'','\"')
    QSaMbpHtfXjDOcUKoGhRlLPqENsFdC=json.loads(QSaMbpHtfXjDOcUKoGhRlLPqENsFdC)
   except:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFkz
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'plot':'%s\n%s'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,QSaMbpHtfXjDOcUKoGhRlLPqENsFzd)}
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFre=='vod':
    if QSaMbpHtfXjDOcUKoGhRlLPqENsFrA==QSaMbpHtfXjDOcUKoGhRlLPqENsFkA or QSaMbpHtfXjDOcUKoGhRlLPqENsFdW==QSaMbpHtfXjDOcUKoGhRlLPqENsFkz:
     QSaMbpHtfXjDOcUKoGhRlLPqENsFdB['mediatype']='tvshow'
     QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'SEASON_LIST','videoid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'vidtype':'contentid',}
     QSaMbpHtfXjDOcUKoGhRlLPqENsFru=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY
    else:
     QSaMbpHtfXjDOcUKoGhRlLPqENsFdB['mediatype']='episode'
     QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'VOD','programid':QSaMbpHtfXjDOcUKoGhRlLPqENsFzJ,'contentid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'title':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'subtitle':QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,'thumbnail':QSaMbpHtfXjDOcUKoGhRlLPqENsFdC}
     QSaMbpHtfXjDOcUKoGhRlLPqENsFru=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
   else:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFdB['mediatype']='movie'
    QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'MOVIE','contentid':QSaMbpHtfXjDOcUKoGhRlLPqENsFzJ,'title':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'subtitle':QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,'thumbnail':QSaMbpHtfXjDOcUKoGhRlLPqENsFdC}
    QSaMbpHtfXjDOcUKoGhRlLPqENsFru=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdn={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':QSaMbpHtfXjDOcUKoGhRlLPqENsFzJ,'vType':QSaMbpHtfXjDOcUKoGhRlLPqENsFre,}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdx=urllib.parse.urlencode(QSaMbpHtfXjDOcUKoGhRlLPqENsFdn)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdw=[('선택된 시청이력 ( %s ) 삭제'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFdx))]
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFdC,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFru,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB,ContextMenu=QSaMbpHtfXjDOcUKoGhRlLPqENsFdw)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'plot':'시청목록을 삭제합니다.'}
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':QSaMbpHtfXjDOcUKoGhRlLPqENsFre,}
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img=QSaMbpHtfXjDOcUKoGhRlLPqENsFrw,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB,isLink=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFre=='movie':xbmcplugin.setContent(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,'movies')
  else:xbmcplugin.setContent(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def Load_List_File(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,stype): 
  try:
   if stype=='search':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzY=QSaMbpHtfXjDOcUKoGhRlLPqENsFIA
   elif stype in['vod','movie']:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=QSaMbpHtfXjDOcUKoGhRlLPqENsFkB(QSaMbpHtfXjDOcUKoGhRlLPqENsFzY,'r',-1,'utf-8')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzA=fp.readlines()
   fp.close()
  except:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzA=[]
  return QSaMbpHtfXjDOcUKoGhRlLPqENsFzA
 def Save_Watched_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,QSaMbpHtfXjDOcUKoGhRlLPqENsFAx,QSaMbpHtfXjDOcUKoGhRlLPqENsFIn):
  try:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QSaMbpHtfXjDOcUKoGhRlLPqENsFAx))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzy=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.Load_List_File(QSaMbpHtfXjDOcUKoGhRlLPqENsFAx) 
   fp=QSaMbpHtfXjDOcUKoGhRlLPqENsFkB(QSaMbpHtfXjDOcUKoGhRlLPqENsFzk,'w',-1,'utf-8')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzv=urllib.parse.urlencode(QSaMbpHtfXjDOcUKoGhRlLPqENsFIn)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzv=QSaMbpHtfXjDOcUKoGhRlLPqENsFzv+'\n'
   fp.write(QSaMbpHtfXjDOcUKoGhRlLPqENsFzv)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzn=0
   for QSaMbpHtfXjDOcUKoGhRlLPqENsFzx in QSaMbpHtfXjDOcUKoGhRlLPqENsFzy:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzw=QSaMbpHtfXjDOcUKoGhRlLPqENsFkv(urllib.parse.parse_qsl(QSaMbpHtfXjDOcUKoGhRlLPqENsFzx))
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzB=QSaMbpHtfXjDOcUKoGhRlLPqENsFIn.get('code').strip()
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzu=QSaMbpHtfXjDOcUKoGhRlLPqENsFzw.get('code').strip()
    if QSaMbpHtfXjDOcUKoGhRlLPqENsFAx=='vod' and QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_direct_replay()==QSaMbpHtfXjDOcUKoGhRlLPqENsFkY:
     QSaMbpHtfXjDOcUKoGhRlLPqENsFzB=QSaMbpHtfXjDOcUKoGhRlLPqENsFIn.get('videoid').strip()
     QSaMbpHtfXjDOcUKoGhRlLPqENsFzu=QSaMbpHtfXjDOcUKoGhRlLPqENsFzw.get('videoid').strip()if QSaMbpHtfXjDOcUKoGhRlLPqENsFzu!=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz else '-'
    if QSaMbpHtfXjDOcUKoGhRlLPqENsFzB!=QSaMbpHtfXjDOcUKoGhRlLPqENsFzu:
     fp.write(QSaMbpHtfXjDOcUKoGhRlLPqENsFzx)
     QSaMbpHtfXjDOcUKoGhRlLPqENsFzn+=1
     if QSaMbpHtfXjDOcUKoGhRlLPqENsFzn>=50:break
   fp.close()
  except:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFkz
 def dp_History_Remove(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFzg=args.get('delType')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFzV =args.get('sKey')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFzW =args.get('vType')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIw=xbmcgui.Dialog()
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFzg=='SEARCH_ALL':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzT=QSaMbpHtfXjDOcUKoGhRlLPqENsFIw.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFzg=='SEARCH_ONE':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzT=QSaMbpHtfXjDOcUKoGhRlLPqENsFIw.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFzg=='WATCH_ALL':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzT=QSaMbpHtfXjDOcUKoGhRlLPqENsFIw.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFzg=='WATCH_ONE':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzT=QSaMbpHtfXjDOcUKoGhRlLPqENsFIw.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFzT==QSaMbpHtfXjDOcUKoGhRlLPqENsFkA:sys.exit()
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFzg=='SEARCH_ALL':
   if os.path.isfile(QSaMbpHtfXjDOcUKoGhRlLPqENsFIA):os.remove(QSaMbpHtfXjDOcUKoGhRlLPqENsFIA)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFzg=='SEARCH_ONE':
   try:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzY=QSaMbpHtfXjDOcUKoGhRlLPqENsFIA
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzy=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.Load_List_File('search') 
    fp=QSaMbpHtfXjDOcUKoGhRlLPqENsFkB(QSaMbpHtfXjDOcUKoGhRlLPqENsFzY,'w',-1,'utf-8')
    for QSaMbpHtfXjDOcUKoGhRlLPqENsFzx in QSaMbpHtfXjDOcUKoGhRlLPqENsFzy:
     QSaMbpHtfXjDOcUKoGhRlLPqENsFzw=QSaMbpHtfXjDOcUKoGhRlLPqENsFkv(urllib.parse.parse_qsl(QSaMbpHtfXjDOcUKoGhRlLPqENsFzx))
     QSaMbpHtfXjDOcUKoGhRlLPqENsFzC=QSaMbpHtfXjDOcUKoGhRlLPqENsFzw.get('skey').strip()
     if QSaMbpHtfXjDOcUKoGhRlLPqENsFzV!=QSaMbpHtfXjDOcUKoGhRlLPqENsFzC:
      fp.write(QSaMbpHtfXjDOcUKoGhRlLPqENsFzx)
    fp.close()
   except:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFkz
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFzg=='WATCH_ALL':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QSaMbpHtfXjDOcUKoGhRlLPqENsFzW))
   if os.path.isfile(QSaMbpHtfXjDOcUKoGhRlLPqENsFzY):os.remove(QSaMbpHtfXjDOcUKoGhRlLPqENsFzY)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFzg=='WATCH_ONE':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QSaMbpHtfXjDOcUKoGhRlLPqENsFzW))
   try:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzy=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.Load_List_File(QSaMbpHtfXjDOcUKoGhRlLPqENsFzW) 
    fp=QSaMbpHtfXjDOcUKoGhRlLPqENsFkB(QSaMbpHtfXjDOcUKoGhRlLPqENsFzY,'w',-1,'utf-8')
    for QSaMbpHtfXjDOcUKoGhRlLPqENsFzx in QSaMbpHtfXjDOcUKoGhRlLPqENsFzy:
     QSaMbpHtfXjDOcUKoGhRlLPqENsFzw=QSaMbpHtfXjDOcUKoGhRlLPqENsFkv(urllib.parse.parse_qsl(QSaMbpHtfXjDOcUKoGhRlLPqENsFzx))
     QSaMbpHtfXjDOcUKoGhRlLPqENsFzC=QSaMbpHtfXjDOcUKoGhRlLPqENsFzw.get('code').strip()
     if QSaMbpHtfXjDOcUKoGhRlLPqENsFzV!=QSaMbpHtfXjDOcUKoGhRlLPqENsFzC:
      fp.write(QSaMbpHtfXjDOcUKoGhRlLPqENsFzx)
    fp.close()
   except:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFkz
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,QSaMbpHtfXjDOcUKoGhRlLPqENsFrT):
  try:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzi=QSaMbpHtfXjDOcUKoGhRlLPqENsFIA
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzy=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.Load_List_File('search') 
   QSaMbpHtfXjDOcUKoGhRlLPqENsFze={'skey':QSaMbpHtfXjDOcUKoGhRlLPqENsFrT.strip()}
   fp=QSaMbpHtfXjDOcUKoGhRlLPqENsFkB(QSaMbpHtfXjDOcUKoGhRlLPqENsFzi,'w',-1,'utf-8')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzv=urllib.parse.urlencode(QSaMbpHtfXjDOcUKoGhRlLPqENsFze)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzv=QSaMbpHtfXjDOcUKoGhRlLPqENsFzv+'\n'
   fp.write(QSaMbpHtfXjDOcUKoGhRlLPqENsFzv)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzn=0
   for QSaMbpHtfXjDOcUKoGhRlLPqENsFzx in QSaMbpHtfXjDOcUKoGhRlLPqENsFzy:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzw=QSaMbpHtfXjDOcUKoGhRlLPqENsFkv(urllib.parse.parse_qsl(QSaMbpHtfXjDOcUKoGhRlLPqENsFzx))
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzB=QSaMbpHtfXjDOcUKoGhRlLPqENsFze.get('skey').strip()
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzu=QSaMbpHtfXjDOcUKoGhRlLPqENsFzw.get('skey').strip()
    if QSaMbpHtfXjDOcUKoGhRlLPqENsFzB!=QSaMbpHtfXjDOcUKoGhRlLPqENsFzu:
     fp.write(QSaMbpHtfXjDOcUKoGhRlLPqENsFzx)
     QSaMbpHtfXjDOcUKoGhRlLPqENsFzn+=1
     if QSaMbpHtfXjDOcUKoGhRlLPqENsFzn>=50:break
   fp.close()
  except:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFkz
 def dp_Global_Search(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFri=args.get('mode')
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='TOTAL_SEARCH':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzm='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzm='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(QSaMbpHtfXjDOcUKoGhRlLPqENsFzm)
 def dp_Bookmark_Menu(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFzm='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(QSaMbpHtfXjDOcUKoGhRlLPqENsFzm)
 def login_main(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  (QSaMbpHtfXjDOcUKoGhRlLPqENsFJI,QSaMbpHtfXjDOcUKoGhRlLPqENsFJr,QSaMbpHtfXjDOcUKoGhRlLPqENsFJd)=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_account()
  if not(QSaMbpHtfXjDOcUKoGhRlLPqENsFJI and QSaMbpHtfXjDOcUKoGhRlLPqENsFJr):
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIw=xbmcgui.Dialog()
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzT=QSaMbpHtfXjDOcUKoGhRlLPqENsFIw.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFzT==QSaMbpHtfXjDOcUKoGhRlLPqENsFkY:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.cookiefile_check()==QSaMbpHtfXjDOcUKoGhRlLPqENsFkY:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJz=0
   while QSaMbpHtfXjDOcUKoGhRlLPqENsFkY:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFJz+=1
    time.sleep(0.05)
    if QSaMbpHtfXjDOcUKoGhRlLPqENsFJz>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFJY=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.GetCredential(QSaMbpHtfXjDOcUKoGhRlLPqENsFJI,QSaMbpHtfXjDOcUKoGhRlLPqENsFJr,QSaMbpHtfXjDOcUKoGhRlLPqENsFJd)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFJY:QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFJY==QSaMbpHtfXjDOcUKoGhRlLPqENsFkA:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrk =args.get('orderby')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.set_winEpisodeOrderby(QSaMbpHtfXjDOcUKoGhRlLPqENsFrk)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFri =args.get('mode')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFJA =args.get('contentid')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFJk =args.get('pvrmode')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFJy=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_selQuality()
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrd =QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_play()
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.addon_log(QSaMbpHtfXjDOcUKoGhRlLPqENsFJA+' - '+QSaMbpHtfXjDOcUKoGhRlLPqENsFri)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='SPORTS':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJv=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.GetSportsURL(QSaMbpHtfXjDOcUKoGhRlLPqENsFJA,QSaMbpHtfXjDOcUKoGhRlLPqENsFJy)
  else:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJv=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.GetStreamingURL(QSaMbpHtfXjDOcUKoGhRlLPqENsFri,QSaMbpHtfXjDOcUKoGhRlLPqENsFJA,QSaMbpHtfXjDOcUKoGhRlLPqENsFJy,QSaMbpHtfXjDOcUKoGhRlLPqENsFJk,playOption=QSaMbpHtfXjDOcUKoGhRlLPqENsFrd)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFJn=QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_cookie']
  QSaMbpHtfXjDOcUKoGhRlLPqENsFJx='{}|Cookie={}'.format(QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_url'],QSaMbpHtfXjDOcUKoGhRlLPqENsFJn)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.addon_log(QSaMbpHtfXjDOcUKoGhRlLPqENsFJx)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_url']=='':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.addon_noti(__language__(30907).encode('utf8'))
   return
  QSaMbpHtfXjDOcUKoGhRlLPqENsFJw=xbmcgui.ListItem(path=QSaMbpHtfXjDOcUKoGhRlLPqENsFJx)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_drm']:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.addon_log('!!streaming_drm!!')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJB=QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_drm']['customdata']
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJu =QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_drm']['drmhost']
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJg =inputstreamhelper.Helper('mpd',drm='widevine')
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFJg.check_inputstream():
    if QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='MOVIE':
     QSaMbpHtfXjDOcUKoGhRlLPqENsFJV='https://www.wavve.com/player/movie?movieid=%s'%QSaMbpHtfXjDOcUKoGhRlLPqENsFJA
    else:
     QSaMbpHtfXjDOcUKoGhRlLPqENsFJV='https://www.wavve.com/player/vod?programid=%s&page=1'%QSaMbpHtfXjDOcUKoGhRlLPqENsFJA
    QSaMbpHtfXjDOcUKoGhRlLPqENsFJW={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':QSaMbpHtfXjDOcUKoGhRlLPqENsFJB,'referer':QSaMbpHtfXjDOcUKoGhRlLPqENsFJV,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.USER_AGENT,}
    QSaMbpHtfXjDOcUKoGhRlLPqENsFJT=QSaMbpHtfXjDOcUKoGhRlLPqENsFJu+'|'+urllib.parse.urlencode(QSaMbpHtfXjDOcUKoGhRlLPqENsFJW)+'|R{SSM}|'
    QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setProperty('inputstream',QSaMbpHtfXjDOcUKoGhRlLPqENsFJg.inputstream_addon)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setProperty('inputstream.adaptive.manifest_type','mpd')
    QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setProperty('inputstream.adaptive.license_key',QSaMbpHtfXjDOcUKoGhRlLPqENsFJT)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.USER_AGENT,QSaMbpHtfXjDOcUKoGhRlLPqENsFJn))
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri in['VOD','MOVIE']:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setContentLookup(QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setMimeType('application/x-mpegURL')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setProperty('inputstream','inputstream.adaptive')
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_action']=='hls':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setProperty('inputstream.adaptive.manifest_type','hls')
   else:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setProperty('inputstream.adaptive.manifest_type','mpd')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.USER_AGENT,QSaMbpHtfXjDOcUKoGhRlLPqENsFJn))
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_vtt']:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJw.setSubtitles([QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_vtt']])
  xbmcplugin.setResolvedUrl(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,QSaMbpHtfXjDOcUKoGhRlLPqENsFJw)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFJC=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_preview']:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.addon_noti(QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_preview'].encode('utf-8'))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJC=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY
  else:
   if '/preview.' in urllib.parse.urlsplit(QSaMbpHtfXjDOcUKoGhRlLPqENsFJv['stream_url']).path:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.addon_noti(__language__(30908).encode('utf8'))
    QSaMbpHtfXjDOcUKoGhRlLPqENsFJC=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY
  try:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJi=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and QSaMbpHtfXjDOcUKoGhRlLPqENsFJC==QSaMbpHtfXjDOcUKoGhRlLPqENsFkA and QSaMbpHtfXjDOcUKoGhRlLPqENsFJi!='-':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'code':QSaMbpHtfXjDOcUKoGhRlLPqENsFJi,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.Save_Watched_List(args.get('mode').lower(),QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  except:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFkz
 def logout(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIw=xbmcgui.Dialog()
  QSaMbpHtfXjDOcUKoGhRlLPqENsFzT=QSaMbpHtfXjDOcUKoGhRlLPqENsFIw.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFzT==QSaMbpHtfXjDOcUKoGhRlLPqENsFkA:sys.exit()
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Init_WV_Total()
  if os.path.isfile(QSaMbpHtfXjDOcUKoGhRlLPqENsFIY):os.remove(QSaMbpHtfXjDOcUKoGhRlLPqENsFIY)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFJe =QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_Now_Datetime()
  QSaMbpHtfXjDOcUKoGhRlLPqENsFJm=QSaMbpHtfXjDOcUKoGhRlLPqENsFJe+datetime.timedelta(days=QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(__addon__.getSetting('cache_ttl')))
  (QSaMbpHtfXjDOcUKoGhRlLPqENsFJI,QSaMbpHtfXjDOcUKoGhRlLPqENsFJr,QSaMbpHtfXjDOcUKoGhRlLPqENsFJd)=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_account()
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Save_session_acount(QSaMbpHtfXjDOcUKoGhRlLPqENsFJI,QSaMbpHtfXjDOcUKoGhRlLPqENsFJr,QSaMbpHtfXjDOcUKoGhRlLPqENsFJd)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.WV['account']['token_limit']=QSaMbpHtfXjDOcUKoGhRlLPqENsFJm.strftime('%Y%m%d')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.JsonFile_Save(QSaMbpHtfXjDOcUKoGhRlLPqENsFIY,QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.WV)
 def cookiefile_check(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.WV=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.JsonFile_Load(QSaMbpHtfXjDOcUKoGhRlLPqENsFIY)
  if 'account' not in QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.WV:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Init_WV_Total()
   return QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  if 'uuid' not in QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.WV.get('cookies'):
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Init_WV_Total()
   return QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  (QSaMbpHtfXjDOcUKoGhRlLPqENsFYI,QSaMbpHtfXjDOcUKoGhRlLPqENsFYr,QSaMbpHtfXjDOcUKoGhRlLPqENsFYd)=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_account()
  (QSaMbpHtfXjDOcUKoGhRlLPqENsFYz,QSaMbpHtfXjDOcUKoGhRlLPqENsFYJ,QSaMbpHtfXjDOcUKoGhRlLPqENsFYA)=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Load_session_acount()
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFYI!=QSaMbpHtfXjDOcUKoGhRlLPqENsFYz or QSaMbpHtfXjDOcUKoGhRlLPqENsFYr!=QSaMbpHtfXjDOcUKoGhRlLPqENsFYJ or QSaMbpHtfXjDOcUKoGhRlLPqENsFYd!=QSaMbpHtfXjDOcUKoGhRlLPqENsFYA:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Init_WV_Total()
   return QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.WV['account']['token_limit']):
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Init_WV_Total()
   return QSaMbpHtfXjDOcUKoGhRlLPqENsFkA
  return QSaMbpHtfXjDOcUKoGhRlLPqENsFkY
 def dp_LiveCatagory_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYk =args.get('sCode')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYy=args.get('sIndex')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg,QSaMbpHtfXjDOcUKoGhRlLPqENsFYv=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_LiveCatagory_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFYk,QSaMbpHtfXjDOcUKoGhRlLPqENsFYy)
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('title')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'LIVE_LIST','genre':QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('genre'),'baseapi':QSaMbpHtfXjDOcUKoGhRlLPqENsFYv}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img='',infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFdg)>0:xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_MainCatagory_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYk =args.get('sCode')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYy=args.get('sIndex')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFre =args.get('sType')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_MainCatagory_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFYk,QSaMbpHtfXjDOcUKoGhRlLPqENsFYy)
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFre=='vod':
    if QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('subtype')=='catagory':
     QSaMbpHtfXjDOcUKoGhRlLPqENsFri='PROGRAM_LIST'
    else:
     QSaMbpHtfXjDOcUKoGhRlLPqENsFri='SUPERSECTION_LIST'
   elif QSaMbpHtfXjDOcUKoGhRlLPqENsFre=='movie':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFri='MOVIE_LIST'
   else:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFri=''
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='%s (%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('title'),args.get('ordernm'))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':QSaMbpHtfXjDOcUKoGhRlLPqENsFri,'suburl':QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('suburl'),'subapi':QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_exclusion21():
    if QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('title')=='성인' or QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('title')=='성인+' or QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('title')=='에로티시즘' or QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('title')=='19':continue
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img='',infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFdg)>0:xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_Program_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYn =args.get('subapi')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdu=QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(args.get('page'))
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrk =args.get('orderby')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg,QSaMbpHtfXjDOcUKoGhRlLPqENsFdI=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_Program_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFYn,QSaMbpHtfXjDOcUKoGhRlLPqENsFdu,QSaMbpHtfXjDOcUKoGhRlLPqENsFrk)
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdW =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('videoid')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdT =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('vidtype')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('title')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdC=QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('thumbnail')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdi =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('age')
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFdi=='18' or QSaMbpHtfXjDOcUKoGhRlLPqENsFdi=='19' or QSaMbpHtfXjDOcUKoGhRlLPqENsFdi=='21':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv+=' (%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFdi)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'plot':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'mpaa':QSaMbpHtfXjDOcUKoGhRlLPqENsFdi,'mediatype':'tvshow',}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'SEASON_LIST','videoid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'vidtype':QSaMbpHtfXjDOcUKoGhRlLPqENsFdT,}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdw=[]
   QSaMbpHtfXjDOcUKoGhRlLPqENsFde={'mode':'VIEW_DETAIL','values':{'videoid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'vidtype':'tvshow','contenttype':QSaMbpHtfXjDOcUKoGhRlLPqENsFdT,}}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdm=json.dumps(QSaMbpHtfXjDOcUKoGhRlLPqENsFde,separators=(',',':'))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdm=base64.standard_b64encode(QSaMbpHtfXjDOcUKoGhRlLPqENsFdm.encode()).decode('utf-8')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdm=QSaMbpHtfXjDOcUKoGhRlLPqENsFdm.replace('+','%2B')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzI='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFdm)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdw.append(('상세정보 조회',QSaMbpHtfXjDOcUKoGhRlLPqENsFzI))
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_makebookmark():
    QSaMbpHtfXjDOcUKoGhRlLPqENsFde={'videoid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'vidtype':'tvshow','vtitle':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'vsubtitle':'','contenttype':QSaMbpHtfXjDOcUKoGhRlLPqENsFdT,}
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzr=json.dumps(QSaMbpHtfXjDOcUKoGhRlLPqENsFde)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzr=urllib.parse.quote(QSaMbpHtfXjDOcUKoGhRlLPqENsFzr)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzI='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFzr)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFdw.append(('(통합) 찜 영상에 추가',QSaMbpHtfXjDOcUKoGhRlLPqENsFzI))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img=QSaMbpHtfXjDOcUKoGhRlLPqENsFdC,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB,ContextMenu=QSaMbpHtfXjDOcUKoGhRlLPqENsFdw)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFdI:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['mode'] ='PROGRAM_LIST' 
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['subapi']=QSaMbpHtfXjDOcUKoGhRlLPqENsFYn 
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['page'] =QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='[B]%s >>[/B]'%'다음 페이지'
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzd=QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFrw,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  xbmcplugin.setContent(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,'tvshows')
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFdg)>0:xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_Season_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdW=args.get('videoid')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdT=args.get('vidtype')
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFdT=='contentid':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJA=QSaMbpHtfXjDOcUKoGhRlLPqENsFdW
   QSaMbpHtfXjDOcUKoGhRlLPqENsFYx =QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.ContentidToSeasonid(QSaMbpHtfXjDOcUKoGhRlLPqENsFdW)
  else:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFJA=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.ProgramidToContentid(QSaMbpHtfXjDOcUKoGhRlLPqENsFdW)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFYx =QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.ContentidToSeasonid(QSaMbpHtfXjDOcUKoGhRlLPqENsFJA)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYw=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_Season_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFYx)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFYw)>1:
   for QSaMbpHtfXjDOcUKoGhRlLPqENsFYB in QSaMbpHtfXjDOcUKoGhRlLPqENsFYw:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFYu=QSaMbpHtfXjDOcUKoGhRlLPqENsFYB.get('season_Id')
    QSaMbpHtfXjDOcUKoGhRlLPqENsFYg=QSaMbpHtfXjDOcUKoGhRlLPqENsFYB.get('season_Nm')
    QSaMbpHtfXjDOcUKoGhRlLPqENsFYV=QSaMbpHtfXjDOcUKoGhRlLPqENsFYB.get('programNm')
    QSaMbpHtfXjDOcUKoGhRlLPqENsFdC=QSaMbpHtfXjDOcUKoGhRlLPqENsFYB.get('thumbnail')
    QSaMbpHtfXjDOcUKoGhRlLPqENsFYW =QSaMbpHtfXjDOcUKoGhRlLPqENsFYB.get('synopsis')
    QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'mediatype':'tvshow','title':QSaMbpHtfXjDOcUKoGhRlLPqENsFYg,'plot':QSaMbpHtfXjDOcUKoGhRlLPqENsFYW,}
    QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'EPISODE_LIST','seasonid':QSaMbpHtfXjDOcUKoGhRlLPqENsFYu,'page':'1',}
    QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFYg,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFYV,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFdC,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB,ContextMenu=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz)
   xbmcplugin.setContent(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
  else:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFYT={'seasonid':QSaMbpHtfXjDOcUKoGhRlLPqENsFYx,'page':'1',}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Episode_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFYT)
 def dp_Episode_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYx =args.get('seasonid')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdu =QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(args.get('page'))
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg,QSaMbpHtfXjDOcUKoGhRlLPqENsFdI=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_Episode_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFYx,QSaMbpHtfXjDOcUKoGhRlLPqENsFdu,orderby=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_winEpisodeOrderby())
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzd=QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('episodenumber')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFYC ='[%s]\n\n%s'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('episodetitle'),QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('synopsis'))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'mediatype':'episode','title':QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('programtitle'),'plot':QSaMbpHtfXjDOcUKoGhRlLPqENsFYC,'cast':QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('episodeactors'),}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'VOD','programid':QSaMbpHtfXjDOcUKoGhRlLPqENsFYx,'contentid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('contentid'),'thumbnail':QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('thumbnail'),'title':QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('programtitle'),'subtitle':QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('programtitle'),sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('thumbnail'),infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFdu==1:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'plot':'정렬순서를 변경합니다.'}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['mode'] ='ORDER_BY' 
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_winEpisodeOrderby()=='desc':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='정렬순서변경 : 최신화부터 -> 1회부터'
    QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['orderby']='asc'
   else:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='정렬순서변경 : 1회부터 -> 최신화부터'
    QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['orderby']='desc'
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img=QSaMbpHtfXjDOcUKoGhRlLPqENsFrw,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB,isLink=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFdI:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['mode'] ='EPISODE_LIST' 
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['seasonid']=QSaMbpHtfXjDOcUKoGhRlLPqENsFYx
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['page'] =QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='[B]%s >>[/B]'%'다음 페이지'
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzd=QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFrw,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  xbmcplugin.setContent(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,'episodes')
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFdg)>0:xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_SuperSection_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYi =args.get('suburl')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_SuperMultiSection_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFYi)
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('title')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFYn =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('subapi')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFYe=QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('cell_type')
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFYn.find('mtype=svod')>=0 or QSaMbpHtfXjDOcUKoGhRlLPqENsFYn.find('mtype=ppv')>=0 or QSaMbpHtfXjDOcUKoGhRlLPqENsFYn.find('contenttype=movie')>=0:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFri='MOVIE_LIST'
   elif QSaMbpHtfXjDOcUKoGhRlLPqENsFYn.find('contenttype=program')>=0:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFri='PROGRAM_LIST'
   elif QSaMbpHtfXjDOcUKoGhRlLPqENsFYe=='band_71':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFri ='SUPERSECTION_LIST'
    (QSaMbpHtfXjDOcUKoGhRlLPqENsFYm,QSaMbpHtfXjDOcUKoGhRlLPqENsFAI)=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Baseapi_Parse(QSaMbpHtfXjDOcUKoGhRlLPqENsFYn)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFYi=QSaMbpHtfXjDOcUKoGhRlLPqENsFAI.get('api')
    QSaMbpHtfXjDOcUKoGhRlLPqENsFYn=''
   elif QSaMbpHtfXjDOcUKoGhRlLPqENsFYe=='band_2':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFri='BAND2SECTION_LIST'
   elif QSaMbpHtfXjDOcUKoGhRlLPqENsFYe=='band_live':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFri='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',QSaMbpHtfXjDOcUKoGhRlLPqENsFYn):
    QSaMbpHtfXjDOcUKoGhRlLPqENsFri='MOVIE_LIST'
   else:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFri='PROGRAM_LIST'
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'plot':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'mediatype':'tvshow'}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':QSaMbpHtfXjDOcUKoGhRlLPqENsFri,'suburl':QSaMbpHtfXjDOcUKoGhRlLPqENsFYi,'subapi':QSaMbpHtfXjDOcUKoGhRlLPqENsFYn,'page':'1'}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFdg)>0:xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_BandLiveSection_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYn =args.get('subapi')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdu=QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(args.get('page'))
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg,QSaMbpHtfXjDOcUKoGhRlLPqENsFdI=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_BandLiveSection_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFYn,QSaMbpHtfXjDOcUKoGhRlLPqENsFdu)
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAr =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('channelid')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAd =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('studio')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAz=QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('tvshowtitle')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdC =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('thumbnail')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdi =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('age')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'mediatype':'tvshow','mpaa':QSaMbpHtfXjDOcUKoGhRlLPqENsFdi,'title':'%s < %s >'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFAd,QSaMbpHtfXjDOcUKoGhRlLPqENsFAz),'tvshowtitle':QSaMbpHtfXjDOcUKoGhRlLPqENsFAz,'studio':QSaMbpHtfXjDOcUKoGhRlLPqENsFAd,'plot':QSaMbpHtfXjDOcUKoGhRlLPqENsFAd}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'LIVE','contentid':QSaMbpHtfXjDOcUKoGhRlLPqENsFAr}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFAd,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFAz,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('thumbnail'),infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFdI:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['mode'] ='BANDLIVESECTION_LIST' 
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['subapi']=QSaMbpHtfXjDOcUKoGhRlLPqENsFYn
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['page'] =QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='[B]%s >>[/B]'%'다음 페이지'
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzd=QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFrw,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFdg)>0:xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_Band2Section_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYn =args.get('subapi')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdu=QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(args.get('page'))
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg,QSaMbpHtfXjDOcUKoGhRlLPqENsFdI=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_Band2Section_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFYn,QSaMbpHtfXjDOcUKoGhRlLPqENsFdu)
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('programtitle')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzd =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('episodetitle')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'plot':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv+'\n\n'+QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,'mpaa':QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('age'),'mediatype':'episode'}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'VOD','programid':'-','contentid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('videoid'),'thumbnail':QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('thumbnail'),'title':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'subtitle':QSaMbpHtfXjDOcUKoGhRlLPqENsFzd}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('thumbnail'),infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFdI:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['mode'] ='BAND2SECTION_LIST' 
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['subapi']=QSaMbpHtfXjDOcUKoGhRlLPqENsFYn
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['page'] =QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='[B]%s >>[/B]'%'다음 페이지'
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzd=QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFrw,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFdg)>0:xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_Movie_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYn =args.get('subapi')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdu=QSaMbpHtfXjDOcUKoGhRlLPqENsFkJ(args.get('page'))
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrk =args.get('orderby')or '-'
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg,QSaMbpHtfXjDOcUKoGhRlLPqENsFdI=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_Movie_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFYn,QSaMbpHtfXjDOcUKoGhRlLPqENsFdu,QSaMbpHtfXjDOcUKoGhRlLPqENsFrk)
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdW =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('videoid')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdT =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('vidtype')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('title')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdC=QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('thumbnail')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdi =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('age')
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFdi=='18' or QSaMbpHtfXjDOcUKoGhRlLPqENsFdi=='19' or QSaMbpHtfXjDOcUKoGhRlLPqENsFdi=='21':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv+=' (%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFdi)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'plot':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'mpaa':QSaMbpHtfXjDOcUKoGhRlLPqENsFdi,'mediatype':'movie'}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'MOVIE','contentid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'title':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'thumbnail':QSaMbpHtfXjDOcUKoGhRlLPqENsFdC,'age':QSaMbpHtfXjDOcUKoGhRlLPqENsFdi,}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdw=[]
   QSaMbpHtfXjDOcUKoGhRlLPqENsFde={'mode':'VIEW_DETAIL','values':{'videoid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'vidtype':'movie','contenttype':QSaMbpHtfXjDOcUKoGhRlLPqENsFdT,}}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdm=json.dumps(QSaMbpHtfXjDOcUKoGhRlLPqENsFde,separators=(',',':'))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdm=base64.standard_b64encode(QSaMbpHtfXjDOcUKoGhRlLPqENsFdm.encode()).decode('utf-8')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdm=QSaMbpHtfXjDOcUKoGhRlLPqENsFdm.replace('+','%2B')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzI='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFdm)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdw.append(('상세정보 조회',QSaMbpHtfXjDOcUKoGhRlLPqENsFzI))
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.get_settings_makebookmark():
    QSaMbpHtfXjDOcUKoGhRlLPqENsFde={'videoid':QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,'vidtype':'movie','vtitle':QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,'vsubtitle':'','contenttype':'programid',}
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzr=json.dumps(QSaMbpHtfXjDOcUKoGhRlLPqENsFde)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzr=urllib.parse.quote(QSaMbpHtfXjDOcUKoGhRlLPqENsFzr)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzI='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFzr)
    QSaMbpHtfXjDOcUKoGhRlLPqENsFdw.append(('(통합) 찜 영상에 추가',QSaMbpHtfXjDOcUKoGhRlLPqENsFzI))
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel='',img=QSaMbpHtfXjDOcUKoGhRlLPqENsFdC,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB,ContextMenu=QSaMbpHtfXjDOcUKoGhRlLPqENsFdw)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFdI:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['mode'] ='MOVIE_LIST' 
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['subapi']=QSaMbpHtfXjDOcUKoGhRlLPqENsFYn 
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['page'] =QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB['orderby']=QSaMbpHtfXjDOcUKoGhRlLPqENsFrk
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrv='[B]%s >>[/B]'%'다음 페이지'
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzd=QSaMbpHtfXjDOcUKoGhRlLPqENsFkw(QSaMbpHtfXjDOcUKoGhRlLPqENsFdu+1)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFrv,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFrw,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFkz,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkY,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  xbmcplugin.setContent(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,'movies')
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFdg)>0:xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_Set_Bookmark(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAJ=urllib.parse.unquote(args.get('bm_param'))
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAJ=json.loads(QSaMbpHtfXjDOcUKoGhRlLPqENsFAJ)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdW =QSaMbpHtfXjDOcUKoGhRlLPqENsFAJ.get('videoid')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdT =QSaMbpHtfXjDOcUKoGhRlLPqENsFAJ.get('vidtype')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAY =QSaMbpHtfXjDOcUKoGhRlLPqENsFAJ.get('vtitle')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAk =QSaMbpHtfXjDOcUKoGhRlLPqENsFAJ.get('vsubtitle')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAy=QSaMbpHtfXjDOcUKoGhRlLPqENsFAJ.get('contenttype')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIw=xbmcgui.Dialog()
  QSaMbpHtfXjDOcUKoGhRlLPqENsFzT=QSaMbpHtfXjDOcUKoGhRlLPqENsFIw.yesno(__language__(30913).encode('utf8'),QSaMbpHtfXjDOcUKoGhRlLPqENsFAY+' \n\n'+__language__(30914))
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFzT==QSaMbpHtfXjDOcUKoGhRlLPqENsFkA:return
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAv=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.GetBookmarkInfo(QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,QSaMbpHtfXjDOcUKoGhRlLPqENsFdT,QSaMbpHtfXjDOcUKoGhRlLPqENsFAy)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAn=json.dumps(QSaMbpHtfXjDOcUKoGhRlLPqENsFAv)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAn=urllib.parse.quote(QSaMbpHtfXjDOcUKoGhRlLPqENsFAn)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFzI ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFAn)
  xbmc.executebuiltin(QSaMbpHtfXjDOcUKoGhRlLPqENsFzI)
 def dp_LiveChannel_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAx =args.get('genre')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFYv=args.get('baseapi')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_LiveChannel_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFAx,QSaMbpHtfXjDOcUKoGhRlLPqENsFYv)
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAr =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('channelid')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAd =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('studio')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAz=QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('tvshowtitle')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdC =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('thumbnail')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdi =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('age')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAw =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('epg')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'mediatype':'episode','mpaa':QSaMbpHtfXjDOcUKoGhRlLPqENsFdi,'title':'%s < %s >'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFAd,QSaMbpHtfXjDOcUKoGhRlLPqENsFAz),'tvshowtitle':QSaMbpHtfXjDOcUKoGhRlLPqENsFAz,'studio':QSaMbpHtfXjDOcUKoGhRlLPqENsFAd,'plot':'%s\n\n%s'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFAd,QSaMbpHtfXjDOcUKoGhRlLPqENsFAw)}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'LIVE','contentid':QSaMbpHtfXjDOcUKoGhRlLPqENsFAr}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFAd,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFAz,img=QSaMbpHtfXjDOcUKoGhRlLPqENsFdC,infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFkn(QSaMbpHtfXjDOcUKoGhRlLPqENsFdg)>0:xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_Sports_GameList(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,args):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdg=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.Get_Sports_Gamelist()
  for QSaMbpHtfXjDOcUKoGhRlLPqENsFdV in QSaMbpHtfXjDOcUKoGhRlLPqENsFdg:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAB =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('game_date')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAu =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('game_time')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAg =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('svc_id')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAV =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('away_team')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAW =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('home_team')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAT=QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('game_status')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAC =QSaMbpHtfXjDOcUKoGhRlLPqENsFdV.get('game_place')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAi ='%s vs %s (%s)'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFAV,QSaMbpHtfXjDOcUKoGhRlLPqENsFAW,QSaMbpHtfXjDOcUKoGhRlLPqENsFAC)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFAe =QSaMbpHtfXjDOcUKoGhRlLPqENsFAB+' '+QSaMbpHtfXjDOcUKoGhRlLPqENsFAu
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFAT=='LIVE':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFAT='~경기중~'
   elif QSaMbpHtfXjDOcUKoGhRlLPqENsFAT=='END':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFAT='경기종료'
   elif QSaMbpHtfXjDOcUKoGhRlLPqENsFAT=='CANCEL':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFAT='취소'
   else:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFAT=''
   if QSaMbpHtfXjDOcUKoGhRlLPqENsFAT=='':
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzd=QSaMbpHtfXjDOcUKoGhRlLPqENsFAi
   else:
    QSaMbpHtfXjDOcUKoGhRlLPqENsFzd=QSaMbpHtfXjDOcUKoGhRlLPqENsFAi+'  '+QSaMbpHtfXjDOcUKoGhRlLPqENsFAT
   QSaMbpHtfXjDOcUKoGhRlLPqENsFdB={'mediatype':'episode','title':QSaMbpHtfXjDOcUKoGhRlLPqENsFAi,'plot':'%s\n\n%s\n\n%s'%(QSaMbpHtfXjDOcUKoGhRlLPqENsFAe,QSaMbpHtfXjDOcUKoGhRlLPqENsFAi,QSaMbpHtfXjDOcUKoGhRlLPqENsFAT)}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'SPORTS','contentid':QSaMbpHtfXjDOcUKoGhRlLPqENsFAg}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.add_dir(QSaMbpHtfXjDOcUKoGhRlLPqENsFAe,sublabel=QSaMbpHtfXjDOcUKoGhRlLPqENsFzd,img='',infoLabels=QSaMbpHtfXjDOcUKoGhRlLPqENsFdB,isFolder=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA,params=QSaMbpHtfXjDOcUKoGhRlLPqENsFrB)
  xbmcplugin.endOfDirectory(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk._addon_handle,cacheToDisc=QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
 def dp_View_Detail(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk,QSaMbpHtfXjDOcUKoGhRlLPqENsFkr):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdW =QSaMbpHtfXjDOcUKoGhRlLPqENsFkr.get('videoid')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFdT =QSaMbpHtfXjDOcUKoGhRlLPqENsFkr.get('vidtype') 
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAy=QSaMbpHtfXjDOcUKoGhRlLPqENsFkr.get('contenttype')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.addon_log(QSaMbpHtfXjDOcUKoGhRlLPqENsFdW)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.addon_log(QSaMbpHtfXjDOcUKoGhRlLPqENsFdT)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.addon_log(QSaMbpHtfXjDOcUKoGhRlLPqENsFAy)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAv=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.WavveObj.GetBookmarkInfo(QSaMbpHtfXjDOcUKoGhRlLPqENsFdW,QSaMbpHtfXjDOcUKoGhRlLPqENsFdT,QSaMbpHtfXjDOcUKoGhRlLPqENsFAy)
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFdT=='tvshow':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'SEASON_LIST','videoid':QSaMbpHtfXjDOcUKoGhRlLPqENsFAv['indexinfo']['videoid'],'vidtype':QSaMbpHtfXjDOcUKoGhRlLPqENsFAv['indexinfo']['vidtype'],}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzm='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(QSaMbpHtfXjDOcUKoGhRlLPqENsFrB))
  else:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrB={'mode':'MOVIE','contentid':QSaMbpHtfXjDOcUKoGhRlLPqENsFAv['indexinfo']['videoid'],'title':QSaMbpHtfXjDOcUKoGhRlLPqENsFAv['saveinfo']['infoLabels']['title'],'thumbnail':QSaMbpHtfXjDOcUKoGhRlLPqENsFAv['saveinfo']['thumbnail'],'age':QSaMbpHtfXjDOcUKoGhRlLPqENsFAv['saveinfo']['infoLabels']['mpaa'],}
   QSaMbpHtfXjDOcUKoGhRlLPqENsFzm='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(QSaMbpHtfXjDOcUKoGhRlLPqENsFrB))
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrn=xbmcgui.ListItem(label=QSaMbpHtfXjDOcUKoGhRlLPqENsFAv['saveinfo']['title'],path=QSaMbpHtfXjDOcUKoGhRlLPqENsFzm)
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrn.setArt(QSaMbpHtfXjDOcUKoGhRlLPqENsFAv['saveinfo']['thumbnail'])
  QSaMbpHtfXjDOcUKoGhRlLPqENsFrn.setInfo('Video',QSaMbpHtfXjDOcUKoGhRlLPqENsFAv['saveinfo']['infoLabels'])
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFdT=='movie':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrn.setIsFolder(QSaMbpHtfXjDOcUKoGhRlLPqENsFkA)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrn.setProperty('IsPlayable','true')
  else:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrn.setIsFolder(QSaMbpHtfXjDOcUKoGhRlLPqENsFkY)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFrn.setProperty('IsPlayable','false')
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIw=xbmcgui.Dialog()
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIw.info(QSaMbpHtfXjDOcUKoGhRlLPqENsFrn)
 def wavve_main(QSaMbpHtfXjDOcUKoGhRlLPqENsFIk):
  QSaMbpHtfXjDOcUKoGhRlLPqENsFAm=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.main_params.get('params')
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFAm:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFkI =base64.standard_b64decode(QSaMbpHtfXjDOcUKoGhRlLPqENsFAm).decode('utf-8')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFkI =json.loads(QSaMbpHtfXjDOcUKoGhRlLPqENsFkI)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFri =QSaMbpHtfXjDOcUKoGhRlLPqENsFkI.get('mode')
   QSaMbpHtfXjDOcUKoGhRlLPqENsFkr =QSaMbpHtfXjDOcUKoGhRlLPqENsFkI.get('values')
  else:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFri=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.main_params.get('mode',QSaMbpHtfXjDOcUKoGhRlLPqENsFkz)
   QSaMbpHtfXjDOcUKoGhRlLPqENsFkr=QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.main_params
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='LOGOUT':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.logout()
   return
  QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.login_main()
  if QSaMbpHtfXjDOcUKoGhRlLPqENsFri is QSaMbpHtfXjDOcUKoGhRlLPqENsFkz:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Main_List()
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri in['LIVE','VOD','MOVIE','SPORTS']:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.play_VIDEO(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='LIVE_CATAGORY':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_LiveCatagory_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='MAIN_CATAGORY':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_MainCatagory_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='SUPERSECTION_LIST':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_SuperSection_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='BANDLIVESECTION_LIST':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_BandLiveSection_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='BAND2SECTION_LIST':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Band2Section_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='PROGRAM_LIST':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Program_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='SEASON_LIST':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Season_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='EPISODE_LIST':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Episode_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='MOVIE_LIST':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Movie_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='LIVE_LIST':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_LiveChannel_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='ORDER_BY':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_setEpOrderby(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='SEARCH_GROUP':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Search_Group(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri in['SEARCH_LIST','LOCAL_SEARCH']:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Search_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='WATCH_GROUP':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Watch_Group(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='WATCH_LIST':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Watch_List(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='SET_BOOKMARK':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Set_Bookmark(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_History_Remove(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri in['TOTAL_SEARCH','TOTAL_HISTORY']:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Global_Search(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='SEARCH_HISTORY':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Search_History(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='MENU_BOOKMARK':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Bookmark_Menu(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='GAME_LIST':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_Sports_GameList(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  elif QSaMbpHtfXjDOcUKoGhRlLPqENsFri=='VIEW_DETAIL':
   QSaMbpHtfXjDOcUKoGhRlLPqENsFIk.dp_View_Detail(QSaMbpHtfXjDOcUKoGhRlLPqENsFkr)
  else:
   QSaMbpHtfXjDOcUKoGhRlLPqENsFkz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
