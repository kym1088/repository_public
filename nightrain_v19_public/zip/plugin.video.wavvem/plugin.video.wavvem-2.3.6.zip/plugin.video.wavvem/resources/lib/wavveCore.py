__author__="NightRain"
WUvsgTwcBQpfdGFeViHxzCEkyDuMhO=object
WUvsgTwcBQpfdGFeViHxzCEkyDuMhP=None
WUvsgTwcBQpfdGFeViHxzCEkyDuMhb=False
WUvsgTwcBQpfdGFeViHxzCEkyDuMho=open
WUvsgTwcBQpfdGFeViHxzCEkyDuMhA=True
WUvsgTwcBQpfdGFeViHxzCEkyDuMhI=range
WUvsgTwcBQpfdGFeViHxzCEkyDuMht=str
WUvsgTwcBQpfdGFeViHxzCEkyDuMhY=Exception
WUvsgTwcBQpfdGFeViHxzCEkyDuMhS=print
WUvsgTwcBQpfdGFeViHxzCEkyDuMhK=dict
WUvsgTwcBQpfdGFeViHxzCEkyDuMhN=int
WUvsgTwcBQpfdGFeViHxzCEkyDuMhJ=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class WUvsgTwcBQpfdGFeViHxzCEkyDuMja(WUvsgTwcBQpfdGFeViHxzCEkyDuMhO):
 def __init__(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN='https://apis.wavve.com'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV ={}
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Init_WV_Total()
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.DEVICE ='pc'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.DRM ='wm'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.PARTNER ='pooq'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.POOQZONE ='none'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.REGION ='kor'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.TARGETAGE ='all'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.HTTPTAG ='https://'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.LIST_LIMIT=30 
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.EP_LIMIT =30 
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.MV_LIMIT =24 
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.SEARCH_LIMIT=20 
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.USER_AGENT ='ozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.DEFAULT_HEADER={'user-agent':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.USER_AGENT}
 def Init_WV_Total(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV={'account':{},'cookies':{},}
 def callRequestCookies(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,jobtype,WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,redirects=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjX=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.DEFAULT_HEADER
  if headers:WUvsgTwcBQpfdGFeViHxzCEkyDuMjX.update(headers)
  if jobtype=='Get':
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjL=requests.get(WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,params=params,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMjX,cookies=cookies,allow_redirects=redirects)
  else:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjL=requests.post(WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,json=payload,params=params,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMjX,cookies=cookies,allow_redirects=redirects)
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMjL
 def JsonFile_Save(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,filename,WUvsgTwcBQpfdGFeViHxzCEkyDuMjh):
  if filename=='':return WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  try:
   fp=WUvsgTwcBQpfdGFeViHxzCEkyDuMho(filename,'w',-1,'utf-8')
   json.dump(WUvsgTwcBQpfdGFeViHxzCEkyDuMjh,fp,indent=4,ensure_ascii=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb)
   fp.close()
  except:
   return WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMhA
 def JsonFile_Load(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,filename):
  if filename=='':return{}
  try:
   fp=WUvsgTwcBQpfdGFeViHxzCEkyDuMho(filename,'r',-1,'utf-8')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjR=json.load(fp)
   fp.close()
  except:
   return{}
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMjR
 def Save_session_acount(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,WUvsgTwcBQpfdGFeViHxzCEkyDuMjO,WUvsgTwcBQpfdGFeViHxzCEkyDuMjP,WUvsgTwcBQpfdGFeViHxzCEkyDuMjb):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['account']['wvid']=base64.standard_b64encode(WUvsgTwcBQpfdGFeViHxzCEkyDuMjO.encode()).decode('utf-8')
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['account']['wvpw']=base64.standard_b64encode(WUvsgTwcBQpfdGFeViHxzCEkyDuMjP.encode()).decode('utf-8')
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['account']['wvpf']=WUvsgTwcBQpfdGFeViHxzCEkyDuMjb 
 def Load_session_acount(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl):
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjO=base64.standard_b64decode(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['account']['wvid']).decode('utf-8')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjP=base64.standard_b64decode(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['account']['wvpw']).decode('utf-8')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjb=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['account']['wvpf']
  except:
   return '','',0
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMjO,WUvsgTwcBQpfdGFeViHxzCEkyDuMjP,WUvsgTwcBQpfdGFeViHxzCEkyDuMjb
 def GetDefaultParams(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhA):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjo={'apikey':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.APIKEY,'credential':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['cookies']['credential']if login else 'none','device':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.DEVICE,'drm':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.DRM,'partner':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.PARTNER,'pooqzone':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.POOQZONE,'region':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.REGION,'targetage':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.TARGETAGE,}
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMjo
 def GetDefaultParams_AND(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjo={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['cookies']['credential'],'device':'ott','drm':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.DRM,'partner':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.PARTNER,'pooqzone':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.POOQZONE,'region':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.REGION,'targetage':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.TARGETAGE,}
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMjo
 def GetGUID(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjA=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjI=GenerateRandomString(5)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjt=WUvsgTwcBQpfdGFeViHxzCEkyDuMjI+media+WUvsgTwcBQpfdGFeViHxzCEkyDuMjA
   return WUvsgTwcBQpfdGFeViHxzCEkyDuMjt
  def GenerateRandomString(num):
   from random import randint
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjY=""
   for i in WUvsgTwcBQpfdGFeViHxzCEkyDuMhI(0,num):
    s=WUvsgTwcBQpfdGFeViHxzCEkyDuMht(randint(1,5))
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjY+=s
   return WUvsgTwcBQpfdGFeViHxzCEkyDuMjY
  if guidType==3:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjt=guid_str
  else:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjt=GenerateID(guid_str)
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjS=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetHash(WUvsgTwcBQpfdGFeViHxzCEkyDuMjt)
  if guidType in[2,3]:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjS='%s-%s-%s-%s-%s'%(WUvsgTwcBQpfdGFeViHxzCEkyDuMjS[:8],WUvsgTwcBQpfdGFeViHxzCEkyDuMjS[8:12],WUvsgTwcBQpfdGFeViHxzCEkyDuMjS[12:16],WUvsgTwcBQpfdGFeViHxzCEkyDuMjS[16:20],WUvsgTwcBQpfdGFeViHxzCEkyDuMjS[20:])
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMjS
 def GetHash(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMht(m.hexdigest())
 def CheckQuality(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,sel_qt,qt_list):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjK=0
  for WUvsgTwcBQpfdGFeViHxzCEkyDuMjN in qt_list:
   if sel_qt>=WUvsgTwcBQpfdGFeViHxzCEkyDuMjN:return WUvsgTwcBQpfdGFeViHxzCEkyDuMjN
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjK=WUvsgTwcBQpfdGFeViHxzCEkyDuMjN
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMjK
 def Get_Now_Datetime(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,in_text):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjm=in_text.replace('&lt;','<').replace('&gt;','>')
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjm=WUvsgTwcBQpfdGFeViHxzCEkyDuMjm.replace('$O$','')
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjm=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',WUvsgTwcBQpfdGFeViHxzCEkyDuMjm)
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjm=WUvsgTwcBQpfdGFeViHxzCEkyDuMjm.lstrip('#')
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMjm
 def GetCredential(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,user_id,user_pw,user_pf):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjq=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+ '/login'
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaj={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Post',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMaj,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['cookies']['credential']=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['credential']
   if user_pf!=0:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaj={'id':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['cookies']['credential'],'password':'','profile':WUvsgTwcBQpfdGFeViHxzCEkyDuMht(user_pf),'pushid':'','type':'credential'}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjo =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhA) 
    WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Post',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMaj,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['cookies']['credential']=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['credential']
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaL=user_id+WUvsgTwcBQpfdGFeViHxzCEkyDuMht(user_pf) 
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['cookies']['uuid']=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetGUID(guid_str=WUvsgTwcBQpfdGFeViHxzCEkyDuMaL,guidType=3)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjq=WUvsgTwcBQpfdGFeViHxzCEkyDuMhA
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Init_WV_Total()
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMjq
 def GetIssue(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMah=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/guid/issue'
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams()
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMar=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['guid']
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaR=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['guidtimestamp']
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMar:WUvsgTwcBQpfdGFeViHxzCEkyDuMah=WUvsgTwcBQpfdGFeViHxzCEkyDuMhA
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMar='none'
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaR='none' 
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.guid=WUvsgTwcBQpfdGFeViHxzCEkyDuMar
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.guidtimestamp=WUvsgTwcBQpfdGFeViHxzCEkyDuMaR
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMah
 def Baseapi_Parse(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,WUvsgTwcBQpfdGFeViHxzCEkyDuMao):
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaO =urllib.parse.urlsplit(WUvsgTwcBQpfdGFeViHxzCEkyDuMao)
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMaO.netloc=='':
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.HTTPTAG+WUvsgTwcBQpfdGFeViHxzCEkyDuMaO.netloc+WUvsgTwcBQpfdGFeViHxzCEkyDuMaO.path
   else:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMaO.scheme+'://'+WUvsgTwcBQpfdGFeViHxzCEkyDuMaO.netloc+WUvsgTwcBQpfdGFeViHxzCEkyDuMaO.path
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMhK(urllib.parse.parse_qsl(WUvsgTwcBQpfdGFeViHxzCEkyDuMaO.query))
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return '',{}
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,WUvsgTwcBQpfdGFeViHxzCEkyDuMjo
 def GetSupermultiUrl(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,sCode,sIndex='0'):
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/cf/supermultisections/'+sCode
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaP=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['multisectionlist'][WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(sIndex)]['eventlist'][1]['url']
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return ''
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMaP
 def Get_LiveCatagory_List(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,sCode,sIndex='0'):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMab=[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMao =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetSupermultiUrl(sCode,sIndex)
  (WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,WUvsgTwcBQpfdGFeViHxzCEkyDuMjo)=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Baseapi_Parse(WUvsgTwcBQpfdGFeViHxzCEkyDuMao)
  if WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=='':return WUvsgTwcBQpfdGFeViHxzCEkyDuMab,''
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('filter_item_list' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['filter']['filterlist'][0]):return[],''
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['filter']['filterlist'][0]['filter_item_list']
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMaI:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'title':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title'],'genre':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['api_parameters'][WUvsgTwcBQpfdGFeViHxzCEkyDuMat['api_parameters'].index('=')+1:]}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMab.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[],''
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMab,WUvsgTwcBQpfdGFeViHxzCEkyDuMao
 def Get_MainCatagory_List(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,sCode,sIndex='0'):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMab=[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMao =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetSupermultiUrl(sCode,sIndex)
  (WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,WUvsgTwcBQpfdGFeViHxzCEkyDuMjo)=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Baseapi_Parse(WUvsgTwcBQpfdGFeViHxzCEkyDuMao)
  if WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=='':return WUvsgTwcBQpfdGFeViHxzCEkyDuMab
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('celllist' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['band']):return[]
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['band']['celllist']
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMaI:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaS =WUvsgTwcBQpfdGFeViHxzCEkyDuMat['event_list'][1]['url']
    (WUvsgTwcBQpfdGFeViHxzCEkyDuMaK,WUvsgTwcBQpfdGFeViHxzCEkyDuMaN)=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Baseapi_Parse(WUvsgTwcBQpfdGFeViHxzCEkyDuMaS)
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'title':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title_list'][0]['text'],'suburl':WUvsgTwcBQpfdGFeViHxzCEkyDuMaK,'subapi':WUvsgTwcBQpfdGFeViHxzCEkyDuMaN.get('api'),'subtype':'catagory' if WUvsgTwcBQpfdGFeViHxzCEkyDuMaN else 'supersection'}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMab.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[]
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMab
 def Get_SuperMultiSection_List(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,subapi_text):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMab=[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjo={}
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaO =urllib.parse.urlsplit(subapi_text)
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMaO.path.find('apis.wavve.com')>=0: 
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.HTTPTAG+WUvsgTwcBQpfdGFeViHxzCEkyDuMaO.path 
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMhK(urllib.parse.parse_qsl(WUvsgTwcBQpfdGFeViHxzCEkyDuMaO.query))
   else:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/cf'+WUvsgTwcBQpfdGFeViHxzCEkyDuMaO.path 
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjn.replace('supermultisection/','supermultisections/')
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[]
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('multisectionlist' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX):return[]
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['multisectionlist']
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMaI:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaJ=WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title']
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMhJ(WUvsgTwcBQpfdGFeViHxzCEkyDuMaJ)==0:continue
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMaJ=='minor':continue
    if re.search(u'베너',WUvsgTwcBQpfdGFeViHxzCEkyDuMaJ):continue
    if re.search(u'배너',WUvsgTwcBQpfdGFeViHxzCEkyDuMaJ):continue 
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMat['force_refresh']=='y':continue
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMhJ(WUvsgTwcBQpfdGFeViHxzCEkyDuMat['eventlist'])>=3:
     WUvsgTwcBQpfdGFeViHxzCEkyDuMaN =WUvsgTwcBQpfdGFeViHxzCEkyDuMat['eventlist'][2]['url']
    else:
     WUvsgTwcBQpfdGFeViHxzCEkyDuMaN =WUvsgTwcBQpfdGFeViHxzCEkyDuMat['eventlist'][1]['url']
    WUvsgTwcBQpfdGFeViHxzCEkyDuMam=WUvsgTwcBQpfdGFeViHxzCEkyDuMat['cell_type']
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMam=='band_2':
     if WUvsgTwcBQpfdGFeViHxzCEkyDuMaN.find('channellist=')>=0:
      WUvsgTwcBQpfdGFeViHxzCEkyDuMam='band_live'
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'title':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Get_ChangeText(WUvsgTwcBQpfdGFeViHxzCEkyDuMaJ),'subapi':WUvsgTwcBQpfdGFeViHxzCEkyDuMaN,'cell_type':WUvsgTwcBQpfdGFeViHxzCEkyDuMam}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMab.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[]
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMab
 def Get_BandLiveSection_List(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,WUvsgTwcBQpfdGFeViHxzCEkyDuMao,page_int=1):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMaq=[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=1
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  try:
   (WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,WUvsgTwcBQpfdGFeViHxzCEkyDuMjo)=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Baseapi_Parse(WUvsgTwcBQpfdGFeViHxzCEkyDuMao)
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[],WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['limit']=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.LIST_LIMIT
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['offset']=WUvsgTwcBQpfdGFeViHxzCEkyDuMht((page_int-1)*WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.LIST_LIMIT)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('celllist' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']):return[],WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['celllist']
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMaI:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMla =WUvsgTwcBQpfdGFeViHxzCEkyDuMat['event_list'][1]['url']
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlX=urllib.parse.urlsplit(WUvsgTwcBQpfdGFeViHxzCEkyDuMla).query
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlX=WUvsgTwcBQpfdGFeViHxzCEkyDuMhK(urllib.parse.parse_qsl(WUvsgTwcBQpfdGFeViHxzCEkyDuMlX))
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlL='channelid'
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlh=WUvsgTwcBQpfdGFeViHxzCEkyDuMlX[WUvsgTwcBQpfdGFeViHxzCEkyDuMlL]
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'studio':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title_list'][0]['text'],'tvshowtitle':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Get_ChangeText(WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title_list'][1]['text']),'channelid':WUvsgTwcBQpfdGFeViHxzCEkyDuMlh,'age':WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('age'),'thumbnail':'https://%s'%WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('thumbnail')}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaq.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['pagecount'])
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['count']:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr =WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['count'])
   else:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.LIST_LIMIT*page_int
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMan>WUvsgTwcBQpfdGFeViHxzCEkyDuMlr
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[],WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMaq,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj
 def Get_Band2Section_List(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,WUvsgTwcBQpfdGFeViHxzCEkyDuMao,page_int=1):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlR=[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=1
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  try:
   (WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,WUvsgTwcBQpfdGFeViHxzCEkyDuMjo)=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Baseapi_Parse(WUvsgTwcBQpfdGFeViHxzCEkyDuMao)
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[],WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['came'] ='BandView'
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['limit']=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.LIST_LIMIT
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['offset']=WUvsgTwcBQpfdGFeViHxzCEkyDuMht((page_int-1)*WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.LIST_LIMIT)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('celllist' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']):return[],WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['celllist']
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMaI:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMla =WUvsgTwcBQpfdGFeViHxzCEkyDuMat['event_list'][1]['url']
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlX=urllib.parse.urlsplit(WUvsgTwcBQpfdGFeViHxzCEkyDuMla).query
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlX=WUvsgTwcBQpfdGFeViHxzCEkyDuMhK(urllib.parse.parse_qsl(WUvsgTwcBQpfdGFeViHxzCEkyDuMlX))
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlL='contentid'
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlh=WUvsgTwcBQpfdGFeViHxzCEkyDuMlX[WUvsgTwcBQpfdGFeViHxzCEkyDuMlL]
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'programtitle':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title_list'][0]['text'],'episodetitle':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Get_ChangeText(WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title_list'][1]['text']),'age':WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('age'),'thumbnail':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.HTTPTAG+WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('thumbnail'),'vidtype':WUvsgTwcBQpfdGFeViHxzCEkyDuMlL,'videoid':WUvsgTwcBQpfdGFeViHxzCEkyDuMlh}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlR.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['pagecount'])
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['count']:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr =WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['count'])
   else:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.LIST_LIMIT*page_int
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMan>WUvsgTwcBQpfdGFeViHxzCEkyDuMlr
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[],WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMlR,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj
 def Get_Program_List(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,WUvsgTwcBQpfdGFeViHxzCEkyDuMao,page_int=1,orderby='-'):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlO=[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=1
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  (WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,WUvsgTwcBQpfdGFeViHxzCEkyDuMjo)=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Baseapi_Parse(WUvsgTwcBQpfdGFeViHxzCEkyDuMao)
  if WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=='':return WUvsgTwcBQpfdGFeViHxzCEkyDuMlO,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['limit'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.LIST_LIMIT
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['offset']=WUvsgTwcBQpfdGFeViHxzCEkyDuMht((page_int-1)*WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.LIST_LIMIT)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['page'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMht(page_int)
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.get('orderby')!='' and WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.get('orderby')!='regdatefirst' and orderby!='-':
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['orderby']=orderby 
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMao.find('instantplay')>=0:
    if not('celllist' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['band']):return WUvsgTwcBQpfdGFeViHxzCEkyDuMlO,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['band']['celllist']
   else:
    if not('celllist' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']):return WUvsgTwcBQpfdGFeViHxzCEkyDuMlO,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['celllist']
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMaI:
    for WUvsgTwcBQpfdGFeViHxzCEkyDuMlP in WUvsgTwcBQpfdGFeViHxzCEkyDuMat['event_list']:
     if WUvsgTwcBQpfdGFeViHxzCEkyDuMlP.get('type')=='on-navigation':
      WUvsgTwcBQpfdGFeViHxzCEkyDuMla =WUvsgTwcBQpfdGFeViHxzCEkyDuMlP['url']
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlX=urllib.parse.urlsplit(WUvsgTwcBQpfdGFeViHxzCEkyDuMla).query
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlL=WUvsgTwcBQpfdGFeViHxzCEkyDuMlX[0:WUvsgTwcBQpfdGFeViHxzCEkyDuMlX.find('=')]
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlh=WUvsgTwcBQpfdGFeViHxzCEkyDuMlX[WUvsgTwcBQpfdGFeViHxzCEkyDuMlX.find('=')+1:]
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'title':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['alt'],'age':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['age'],'thumbnail':'https://%s'%WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('thumbnail'),'videoid':WUvsgTwcBQpfdGFeViHxzCEkyDuMlh,'vidtype':WUvsgTwcBQpfdGFeViHxzCEkyDuMlL,}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlO.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMao.find('instantplay')<0:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['pagecount'])
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['count']:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr =WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['count'])
    else:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.LIST_LIMIT*page_int
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMan>WUvsgTwcBQpfdGFeViHxzCEkyDuMlr
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[],WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMlO,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj
 def Get_Movie_List(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,WUvsgTwcBQpfdGFeViHxzCEkyDuMao,page_int=1,orderby='-'):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlb=[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=1
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  (WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,WUvsgTwcBQpfdGFeViHxzCEkyDuMjo)=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Baseapi_Parse(WUvsgTwcBQpfdGFeViHxzCEkyDuMao)
  if WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=='':return WUvsgTwcBQpfdGFeViHxzCEkyDuMlb,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['limit']=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.MV_LIMIT
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['offset']=WUvsgTwcBQpfdGFeViHxzCEkyDuMht((page_int-1)*WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.MV_LIMIT)
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.get('orderby')!='' and WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.get('orderby')!='regdatefirst' and orderby!='-':
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['orderby']=orderby 
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('celllist' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']):return WUvsgTwcBQpfdGFeViHxzCEkyDuMlb,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['celllist']
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMaI:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMla =WUvsgTwcBQpfdGFeViHxzCEkyDuMat['event_list'][1]['url']
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlX=urllib.parse.urlsplit(WUvsgTwcBQpfdGFeViHxzCEkyDuMla).query
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlL=WUvsgTwcBQpfdGFeViHxzCEkyDuMlX[0:WUvsgTwcBQpfdGFeViHxzCEkyDuMlX.find('=')]
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlh=WUvsgTwcBQpfdGFeViHxzCEkyDuMlX[WUvsgTwcBQpfdGFeViHxzCEkyDuMlX.find('=')+1:]
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'title':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['alt'],'age':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['age'],'thumbnail':'https://%s'%WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('thumbnail'),'videoid':WUvsgTwcBQpfdGFeViHxzCEkyDuMlh,'vidtype':WUvsgTwcBQpfdGFeViHxzCEkyDuMlL,}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlb.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['pagecount'])
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['count']:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr =WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['count'])
   else:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.MV_LIMIT*page_int
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMan>WUvsgTwcBQpfdGFeViHxzCEkyDuMlr
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[],WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMlb,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj
 def ProgramidToContentid(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,WUvsgTwcBQpfdGFeViHxzCEkyDuMlI):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlo=''
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/vod/programs-contentid/'+WUvsgTwcBQpfdGFeViHxzCEkyDuMlI
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlA=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('contentid' in WUvsgTwcBQpfdGFeViHxzCEkyDuMlA):return WUvsgTwcBQpfdGFeViHxzCEkyDuMlo 
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlo=WUvsgTwcBQpfdGFeViHxzCEkyDuMlA['contentid']
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMlo
 def ContentidToSeasonid(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,WUvsgTwcBQpfdGFeViHxzCEkyDuMlo):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlI=''
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/fz/vod/contents/'+WUvsgTwcBQpfdGFeViHxzCEkyDuMlo
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlA=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('programid' in WUvsgTwcBQpfdGFeViHxzCEkyDuMlA):return WUvsgTwcBQpfdGFeViHxzCEkyDuMlI 
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlI=WUvsgTwcBQpfdGFeViHxzCEkyDuMlA['programid']
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMlI
 def GetProgramInfo(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,WUvsgTwcBQpfdGFeViHxzCEkyDuMlo):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlt={}
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/fz/vod/contents/'+WUvsgTwcBQpfdGFeViHxzCEkyDuMlo
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlA=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlY=img_fanart=WUvsgTwcBQpfdGFeViHxzCEkyDuMlS=''
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMlA.get('programposterimage')!='':WUvsgTwcBQpfdGFeViHxzCEkyDuMlY =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.HTTPTAG+WUvsgTwcBQpfdGFeViHxzCEkyDuMlA.get('programposterimage')
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMlA.get('programimage') !='':img_fanart =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.HTTPTAG+WUvsgTwcBQpfdGFeViHxzCEkyDuMlA.get('programimage')
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMlA.get('programcircleimage')!='':WUvsgTwcBQpfdGFeViHxzCEkyDuMlS=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.HTTPTAG+WUvsgTwcBQpfdGFeViHxzCEkyDuMlA.get('programcircleimage')
   if 'poster_default' in WUvsgTwcBQpfdGFeViHxzCEkyDuMlY:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlY =img_fanart
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlS=''
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlt={'imgPoster':WUvsgTwcBQpfdGFeViHxzCEkyDuMlY,'imgFanart':img_fanart,'imgClearlogo':WUvsgTwcBQpfdGFeViHxzCEkyDuMlS,'programtitle':WUvsgTwcBQpfdGFeViHxzCEkyDuMlA.get('programtitle'),'programid':WUvsgTwcBQpfdGFeViHxzCEkyDuMlA.get('programid'),'synopsis':WUvsgTwcBQpfdGFeViHxzCEkyDuMlA.get('programsynopsis').replace('<br>','\n'),}
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMlt
 def Get_Season_List(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,seasonid):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlK=[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.ProgramidToContentid(seasonid)
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlN=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetProgramInfo(WUvsgTwcBQpfdGFeViHxzCEkyDuMlo)
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlJ={'poster':WUvsgTwcBQpfdGFeViHxzCEkyDuMlN.get('imgPoster'),'fanart':WUvsgTwcBQpfdGFeViHxzCEkyDuMlN.get('imgFanart'),'clearlogo':WUvsgTwcBQpfdGFeViHxzCEkyDuMlN.get('imgClearlogo'),}
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo={'limit':'10','offset':'0','orderby':'new',}
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMlm in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['filter']['filterlist'][0]['filter_item_list']:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'season_Nm':WUvsgTwcBQpfdGFeViHxzCEkyDuMlm.get('title'),'season_Id':WUvsgTwcBQpfdGFeViHxzCEkyDuMlm.get('api_path'),'thumbnail':WUvsgTwcBQpfdGFeViHxzCEkyDuMlJ,'programNm':WUvsgTwcBQpfdGFeViHxzCEkyDuMlN.get('programtitle'),'synopsis':WUvsgTwcBQpfdGFeViHxzCEkyDuMlN.get('synopsis'),}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlK.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[]
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMlK
 def Get_Episode_List(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,seasionid,page_int=1,orderby='desc'):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlq=[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=1
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlN={}
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.ProgramidToContentid(seasionid)
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlN=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetProgramInfo(WUvsgTwcBQpfdGFeViHxzCEkyDuMlo)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo={'limit':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.EP_LIMIT,'offset':WUvsgTwcBQpfdGFeViHxzCEkyDuMht((page_int-1)*WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.EP_LIMIT),'orderby':orderby,}
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['celllist']
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMaI:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXj=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('synopsis'))
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXa=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.HTTPTAG+WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('thumbnail')
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXl=WUvsgTwcBQpfdGFeViHxzCEkyDuMXL=WUvsgTwcBQpfdGFeViHxzCEkyDuMXh=''
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXl =WUvsgTwcBQpfdGFeViHxzCEkyDuMlN.get('imgPoster')
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXL =WUvsgTwcBQpfdGFeViHxzCEkyDuMlN.get('imgFanart')
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXh =WUvsgTwcBQpfdGFeViHxzCEkyDuMlN.get('imgClearlogo')
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXr=WUvsgTwcBQpfdGFeViHxzCEkyDuMlN.get('programtitle')
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlJ={'thumb':WUvsgTwcBQpfdGFeViHxzCEkyDuMXa,'poster':WUvsgTwcBQpfdGFeViHxzCEkyDuMXl,'fanart':WUvsgTwcBQpfdGFeViHxzCEkyDuMXL,'clearlogo':WUvsgTwcBQpfdGFeViHxzCEkyDuMXh}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'programtitle':WUvsgTwcBQpfdGFeViHxzCEkyDuMXr,'episodetitle':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title_list'][0]['text'],'episodenumber':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title_list'][1]['text'].replace('$O$',''),'contentid':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['contentid'],'synopsis':WUvsgTwcBQpfdGFeViHxzCEkyDuMXj,'episodeactors':WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('actors').split(',')if WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('actors')!='' else[],'thumbnail':WUvsgTwcBQpfdGFeViHxzCEkyDuMlJ,}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlq.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['pagecount'])
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['count']:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr =WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['count'])
   else:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.EP_LIMIT*page_int
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMan>WUvsgTwcBQpfdGFeViHxzCEkyDuMlr
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[],WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMlq,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj
 def GetEPGList(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,genre):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMXR={}
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXO=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Get_Now_Datetime()
   if genre=='all':
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXP =WUvsgTwcBQpfdGFeViHxzCEkyDuMXO+datetime.timedelta(hours=3)
   else:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXP =WUvsgTwcBQpfdGFeViHxzCEkyDuMXO+datetime.timedelta(hours=3)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/live/epgs'
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo={'limit':'100','offset':'0','genre':genre,'startdatetime':WUvsgTwcBQpfdGFeViHxzCEkyDuMXO.strftime('%Y-%m-%d %H:00'),'enddatetime':WUvsgTwcBQpfdGFeViHxzCEkyDuMXP.strftime('%Y-%m-%d %H:00')}
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXb=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['list']
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMXb:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXo=''
    for WUvsgTwcBQpfdGFeViHxzCEkyDuMXA in WUvsgTwcBQpfdGFeViHxzCEkyDuMat['list']:
     if WUvsgTwcBQpfdGFeViHxzCEkyDuMXo:WUvsgTwcBQpfdGFeViHxzCEkyDuMXo+='\n'
     WUvsgTwcBQpfdGFeViHxzCEkyDuMXo+=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Get_ChangeText(WUvsgTwcBQpfdGFeViHxzCEkyDuMXA['title'])+'\n'
     WUvsgTwcBQpfdGFeViHxzCEkyDuMXo+=' [%s ~ %s]'%(WUvsgTwcBQpfdGFeViHxzCEkyDuMXA['starttime'][-5:],WUvsgTwcBQpfdGFeViHxzCEkyDuMXA['endtime'][-5:])+'\n'
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXR[WUvsgTwcBQpfdGFeViHxzCEkyDuMat['channelid']]=WUvsgTwcBQpfdGFeViHxzCEkyDuMXo
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMXR
 def Get_LiveChannel_List(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,genre,WUvsgTwcBQpfdGFeViHxzCEkyDuMao):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMaq=[]
  (WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,WUvsgTwcBQpfdGFeViHxzCEkyDuMjo)=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Baseapi_Parse(WUvsgTwcBQpfdGFeViHxzCEkyDuMao)
  if WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=='':return WUvsgTwcBQpfdGFeViHxzCEkyDuMaq
  WUvsgTwcBQpfdGFeViHxzCEkyDuMXI=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetEPGList(genre)
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['genre']=genre
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('celllist' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']):return[]
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['celllist']
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMaI:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlo=WUvsgTwcBQpfdGFeViHxzCEkyDuMat['contentid']
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMlo in WUvsgTwcBQpfdGFeViHxzCEkyDuMXI:
     WUvsgTwcBQpfdGFeViHxzCEkyDuMXt=WUvsgTwcBQpfdGFeViHxzCEkyDuMXI[WUvsgTwcBQpfdGFeViHxzCEkyDuMlo]
    else:
     WUvsgTwcBQpfdGFeViHxzCEkyDuMXt=''
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'studio':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title_list'][0]['text'],'tvshowtitle':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Get_ChangeText(WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title_list'][1]['text']),'channelid':WUvsgTwcBQpfdGFeViHxzCEkyDuMlo,'age':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['age'],'thumbnail':'https://%s'%WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('thumbnail'),'epg':WUvsgTwcBQpfdGFeViHxzCEkyDuMXt}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaq.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[]
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMaq
 def Get_Search_List(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,search_key,sType,page_int,exclusion21=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMXY=[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=1
  WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/fz/search/band.js'
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':WUvsgTwcBQpfdGFeViHxzCEkyDuMht((page_int-1)*WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.SEARCH_LIMIT),'limit':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlA=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('celllist' in WUvsgTwcBQpfdGFeViHxzCEkyDuMlA['band']):return WUvsgTwcBQpfdGFeViHxzCEkyDuMXY,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMlA['band']['celllist']
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMaI:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMla =WUvsgTwcBQpfdGFeViHxzCEkyDuMat['event_list'][1]['url']
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlX=urllib.parse.urlsplit(WUvsgTwcBQpfdGFeViHxzCEkyDuMla).query
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlL=WUvsgTwcBQpfdGFeViHxzCEkyDuMlX[0:WUvsgTwcBQpfdGFeViHxzCEkyDuMlX.find('=')]
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlh=WUvsgTwcBQpfdGFeViHxzCEkyDuMlX[WUvsgTwcBQpfdGFeViHxzCEkyDuMlX.find('=')+1:]
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'title':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['title_list'][0]['text'],'age':WUvsgTwcBQpfdGFeViHxzCEkyDuMat['age'],'thumbnail':'https://%s'%WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('thumbnail'),'videoid':WUvsgTwcBQpfdGFeViHxzCEkyDuMlh,'vidtype':WUvsgTwcBQpfdGFeViHxzCEkyDuMlL,}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXS=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb
    for WUvsgTwcBQpfdGFeViHxzCEkyDuMXK in WUvsgTwcBQpfdGFeViHxzCEkyDuMat['bottom_taglist']:
     if WUvsgTwcBQpfdGFeViHxzCEkyDuMXK=='won':
      WUvsgTwcBQpfdGFeViHxzCEkyDuMXS=WUvsgTwcBQpfdGFeViHxzCEkyDuMhA
      break
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMXS==WUvsgTwcBQpfdGFeViHxzCEkyDuMhA: 
     WUvsgTwcBQpfdGFeViHxzCEkyDuMaY['title']=WUvsgTwcBQpfdGFeViHxzCEkyDuMaY['title']+' [개별구매]'
    if exclusion21==WUvsgTwcBQpfdGFeViHxzCEkyDuMhb or WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('age')!='21':
     WUvsgTwcBQpfdGFeViHxzCEkyDuMXY.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMan=WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMlA['band']['pagecount'])
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMlA['band']['count']:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr =WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMlA['band']['count'])
   else:WUvsgTwcBQpfdGFeViHxzCEkyDuMlr=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.LIST_LIMIT
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlj=WUvsgTwcBQpfdGFeViHxzCEkyDuMan>WUvsgTwcBQpfdGFeViHxzCEkyDuMlr
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMXY,WUvsgTwcBQpfdGFeViHxzCEkyDuMlj 
 def GetSecureToken(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/ip'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb)
  WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
  WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['securetoken']
 def GetStreamingURL(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,mode,WUvsgTwcBQpfdGFeViHxzCEkyDuMlo,quality_int,pvrmode='-',playOption={}):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMXN ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  WUvsgTwcBQpfdGFeViHxzCEkyDuMXJ=[]
  if mode=='LIVE':
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/live/channels/'+WUvsgTwcBQpfdGFeViHxzCEkyDuMlo
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXm='live'
  elif mode=='VOD':
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/fz/vod/contents/'+WUvsgTwcBQpfdGFeViHxzCEkyDuMlo
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXm='vod'
  elif mode=='MOVIE':
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/fz/movie/contents/'+WUvsgTwcBQpfdGFeViHxzCEkyDuMlo
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXm='movie'
  WUvsgTwcBQpfdGFeViHxzCEkyDuMXq={'hdr':'sdr',}
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXn=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['qualities']['list']
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMXn==WUvsgTwcBQpfdGFeViHxzCEkyDuMhP:return WUvsgTwcBQpfdGFeViHxzCEkyDuMXN
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMLj in WUvsgTwcBQpfdGFeViHxzCEkyDuMXn:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXJ.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMhN(WUvsgTwcBQpfdGFeViHxzCEkyDuMLj.get('id').rstrip('p')))
   if 'type' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX:
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['type']=='onair':
     WUvsgTwcBQpfdGFeViHxzCEkyDuMXm='onairvod'
   if 'drms' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX:
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['drms']:
     WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_action']='dash'
   if playOption.get('enable_hdr'):
    if 'mediatypes' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX.get('qualities'):
     for WUvsgTwcBQpfdGFeViHxzCEkyDuMLa in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX.get('qualities').get('mediatypes'):
      if WUvsgTwcBQpfdGFeViHxzCEkyDuMLa=='HDR10':
       WUvsgTwcBQpfdGFeViHxzCEkyDuMXq['hdr']='hdr'
       WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_action']='dash'
       break
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return WUvsgTwcBQpfdGFeViHxzCEkyDuMXN
  WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_action'])
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLl=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.CheckQuality(quality_int,WUvsgTwcBQpfdGFeViHxzCEkyDuMXJ)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLX=WUvsgTwcBQpfdGFeViHxzCEkyDuMht(WUvsgTwcBQpfdGFeViHxzCEkyDuMLl)+'p'
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/fz/streaming'
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMXq['hdr']=='hdr':
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjo={'contentid':WUvsgTwcBQpfdGFeViHxzCEkyDuMlo,'contenttype':WUvsgTwcBQpfdGFeViHxzCEkyDuMXm,'quality':WUvsgTwcBQpfdGFeViHxzCEkyDuMLX,'modelid':'SHIELD Android TV','guid':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams_AND())
   else:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjo={'contentid':WUvsgTwcBQpfdGFeViHxzCEkyDuMlo,'contenttype':WUvsgTwcBQpfdGFeViHxzCEkyDuMXm,'quality':WUvsgTwcBQpfdGFeViHxzCEkyDuMLX,'deviceModelId':'Windows 10','guid':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_action'],'protocol':WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhA))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_url']=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['playurl']
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_url']==WUvsgTwcBQpfdGFeViHxzCEkyDuMhP:return WUvsgTwcBQpfdGFeViHxzCEkyDuMXN
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_cookie']=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['awscookie']
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_drm'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['drm']
   if 'previewmsg' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['preview']:WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_preview']=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['preview']['previewmsg']
   if 'subtitles' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX:
    for WUvsgTwcBQpfdGFeViHxzCEkyDuMLh in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['subtitles']:
     if WUvsgTwcBQpfdGFeViHxzCEkyDuMLh.get('languagecode')=='ko':
      WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_vtt']=WUvsgTwcBQpfdGFeViHxzCEkyDuMLh.get('url')
      break
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMXN 
 def GetSportsURL(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,WUvsgTwcBQpfdGFeViHxzCEkyDuMlo,quality_int):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMXN ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  WUvsgTwcBQpfdGFeViHxzCEkyDuMXJ=[]
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/streaming/other'
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo={'contentid':WUvsgTwcBQpfdGFeViHxzCEkyDuMlo,'contenttype':'live','action':WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_action'],'quality':WUvsgTwcBQpfdGFeViHxzCEkyDuMht(quality_int)+'p','deviceModelId':'Windows 10','guid':WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhA))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_url']=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['playurl']
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_url']==WUvsgTwcBQpfdGFeViHxzCEkyDuMhP:return WUvsgTwcBQpfdGFeViHxzCEkyDuMXN
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXN['stream_cookie']=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['awscookie']
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMXN
 def make_viewdate(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMLr =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.Get_Now_Datetime()
  WUvsgTwcBQpfdGFeViHxzCEkyDuMLR =WUvsgTwcBQpfdGFeViHxzCEkyDuMLr+datetime.timedelta(days=-1)
  WUvsgTwcBQpfdGFeViHxzCEkyDuMLO =WUvsgTwcBQpfdGFeViHxzCEkyDuMLr+datetime.timedelta(days=1)
  WUvsgTwcBQpfdGFeViHxzCEkyDuMLP=[WUvsgTwcBQpfdGFeViHxzCEkyDuMLr.strftime('%Y%m%d'),WUvsgTwcBQpfdGFeViHxzCEkyDuMLO.strftime('%Y%m%d'),]
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMLP
 def Get_Sports_Gamelist(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl):
  WUvsgTwcBQpfdGFeViHxzCEkyDuMLb =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.make_viewdate()
  WUvsgTwcBQpfdGFeViHxzCEkyDuMLo=[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMLA =[]
  for WUvsgTwcBQpfdGFeViHxzCEkyDuMLI in WUvsgTwcBQpfdGFeViHxzCEkyDuMLb:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLt=WUvsgTwcBQpfdGFeViHxzCEkyDuMLI[:6]
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMLt not in WUvsgTwcBQpfdGFeViHxzCEkyDuMLo:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMLo.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMLt)
  try:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo.update(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb))
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMLY in WUvsgTwcBQpfdGFeViHxzCEkyDuMLo:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMjo['date']=WUvsgTwcBQpfdGFeViHxzCEkyDuMLY
    WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
    WUvsgTwcBQpfdGFeViHxzCEkyDuMaI=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX['cell_toplist']['celllist']
    for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMaI:
     WUvsgTwcBQpfdGFeViHxzCEkyDuMLS=WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('game_date')
     WUvsgTwcBQpfdGFeViHxzCEkyDuMLK =WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('svc_id')
     if WUvsgTwcBQpfdGFeViHxzCEkyDuMLK=='':continue
     if WUvsgTwcBQpfdGFeViHxzCEkyDuMLS in WUvsgTwcBQpfdGFeViHxzCEkyDuMLb:
      WUvsgTwcBQpfdGFeViHxzCEkyDuMLN=WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('game_status') 
      WUvsgTwcBQpfdGFeViHxzCEkyDuMLJ =WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('title_list')[0].get('text')
      WUvsgTwcBQpfdGFeViHxzCEkyDuMLS =WUvsgTwcBQpfdGFeViHxzCEkyDuMLS[:4]+'-'+WUvsgTwcBQpfdGFeViHxzCEkyDuMLS[4:6]+'-'+WUvsgTwcBQpfdGFeViHxzCEkyDuMLS[-2:]
      WUvsgTwcBQpfdGFeViHxzCEkyDuMLm =WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('game_time')
      WUvsgTwcBQpfdGFeViHxzCEkyDuMLm =WUvsgTwcBQpfdGFeViHxzCEkyDuMLm[:2]+':'+WUvsgTwcBQpfdGFeViHxzCEkyDuMLm[-2:]
      WUvsgTwcBQpfdGFeViHxzCEkyDuMaY={'game_date':WUvsgTwcBQpfdGFeViHxzCEkyDuMLS,'game_time':WUvsgTwcBQpfdGFeViHxzCEkyDuMLm,'svc_id':WUvsgTwcBQpfdGFeViHxzCEkyDuMLK,'away_team':WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('away_team').get('team_name'),'home_team':WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('home_team').get('team_name'),'game_status':WUvsgTwcBQpfdGFeViHxzCEkyDuMLN,'game_place':WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('game_place'),}
      WUvsgTwcBQpfdGFeViHxzCEkyDuMLA.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMaY)
  except WUvsgTwcBQpfdGFeViHxzCEkyDuMhY as exception:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhS(exception)
   return[]
  WUvsgTwcBQpfdGFeViHxzCEkyDuMLq=[]
  for i in WUvsgTwcBQpfdGFeViHxzCEkyDuMhI(2):
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMat in WUvsgTwcBQpfdGFeViHxzCEkyDuMLA:
    if i==0 and WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('game_status')=='LIVE':
     WUvsgTwcBQpfdGFeViHxzCEkyDuMLq.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMat)
    elif i==1 and WUvsgTwcBQpfdGFeViHxzCEkyDuMat.get('game_status')!='LIVE':
     WUvsgTwcBQpfdGFeViHxzCEkyDuMLq.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMat)
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMLq
 def GetBookmarkInfo(WUvsgTwcBQpfdGFeViHxzCEkyDuMjl,WUvsgTwcBQpfdGFeViHxzCEkyDuMlh,WUvsgTwcBQpfdGFeViHxzCEkyDuMlL,WUvsgTwcBQpfdGFeViHxzCEkyDuMXm):
  if WUvsgTwcBQpfdGFeViHxzCEkyDuMlL=='tvshow':
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMXm=='contentid':
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlo=WUvsgTwcBQpfdGFeViHxzCEkyDuMlh
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlh =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.ContentidToSeasonid(WUvsgTwcBQpfdGFeViHxzCEkyDuMlo)
   else:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMlo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.ProgramidToContentid(WUvsgTwcBQpfdGFeViHxzCEkyDuMlh)
  else:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMlo=''
  WUvsgTwcBQpfdGFeViHxzCEkyDuMLn={'indexinfo':{'ott':'wavve','videoid':WUvsgTwcBQpfdGFeViHxzCEkyDuMlh,'vidtype':WUvsgTwcBQpfdGFeViHxzCEkyDuMlL,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':WUvsgTwcBQpfdGFeViHxzCEkyDuMlL,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if WUvsgTwcBQpfdGFeViHxzCEkyDuMlL=='tvshow':
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/fz/vod/contents/'+WUvsgTwcBQpfdGFeViHxzCEkyDuMlo 
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('programtitle' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX):return{}
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhj=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX
   WUvsgTwcBQpfdGFeViHxzCEkyDuMha=WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('programtitle')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['title']=WUvsgTwcBQpfdGFeViHxzCEkyDuMha
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('targetage')=='18' or WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('targetage')=='19' or WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('targetage')=='21':
    WUvsgTwcBQpfdGFeViHxzCEkyDuMha +=u' (%s)'%(WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('targetage'))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['title'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMha
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['mpaa'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('targetage')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['plot'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('programsynopsis').replace('<br>','\n')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['studio'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('channelname')
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('firstreleaseyear')!='':WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['year'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('firstreleaseyear')
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('firstreleasedate')!='':WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['premiered']=WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('firstreleasedate')
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('genretext') !='':WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['genre'] =[WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('genretext')]
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhl=[]
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMhX in WUvsgTwcBQpfdGFeViHxzCEkyDuMhj['actors']['list']:WUvsgTwcBQpfdGFeViHxzCEkyDuMhl.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMhX.get('text'))
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhJ(WUvsgTwcBQpfdGFeViHxzCEkyDuMhl)>0:
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMhl[0]!='':WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['cast']=WUvsgTwcBQpfdGFeViHxzCEkyDuMhl
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXl =''
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXL =''
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXh=''
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('programposterimage')!='':WUvsgTwcBQpfdGFeViHxzCEkyDuMXl =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.HTTPTAG+WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('programposterimage')
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('programimage') !='':WUvsgTwcBQpfdGFeViHxzCEkyDuMXL =WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.HTTPTAG+WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('programimage')
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('programcircleimage')!='':WUvsgTwcBQpfdGFeViHxzCEkyDuMXh=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.HTTPTAG+WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('programcircleimage')
   if 'poster_default' in WUvsgTwcBQpfdGFeViHxzCEkyDuMXl:
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXl =WUvsgTwcBQpfdGFeViHxzCEkyDuMXL
    WUvsgTwcBQpfdGFeViHxzCEkyDuMXh=''
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['thumbnail']['poster']=WUvsgTwcBQpfdGFeViHxzCEkyDuMXl
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['thumbnail']['thumb']=WUvsgTwcBQpfdGFeViHxzCEkyDuMXL
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['thumbnail']['clearlogo']=WUvsgTwcBQpfdGFeViHxzCEkyDuMXh
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['thumbnail']['fanart']=WUvsgTwcBQpfdGFeViHxzCEkyDuMXL
  else:
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjn=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.API_DOMAIN+'/movie/contents/'+WUvsgTwcBQpfdGFeViHxzCEkyDuMlh 
   WUvsgTwcBQpfdGFeViHxzCEkyDuMjo=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.GetDefaultParams(login=WUvsgTwcBQpfdGFeViHxzCEkyDuMhb)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMal=WUvsgTwcBQpfdGFeViHxzCEkyDuMjl.callRequestCookies('Get',WUvsgTwcBQpfdGFeViHxzCEkyDuMjn,payload=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,params=WUvsgTwcBQpfdGFeViHxzCEkyDuMjo,headers=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP,cookies=WUvsgTwcBQpfdGFeViHxzCEkyDuMhP)
   WUvsgTwcBQpfdGFeViHxzCEkyDuMaX=json.loads(WUvsgTwcBQpfdGFeViHxzCEkyDuMal.text)
   if not('title' in WUvsgTwcBQpfdGFeViHxzCEkyDuMaX):return{}
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhj=WUvsgTwcBQpfdGFeViHxzCEkyDuMaX
   WUvsgTwcBQpfdGFeViHxzCEkyDuMha=WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('title')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['title']=WUvsgTwcBQpfdGFeViHxzCEkyDuMha
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('targetage')=='18' or WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('targetage')=='19' or WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('targetage')=='21':
    WUvsgTwcBQpfdGFeViHxzCEkyDuMha +=u' (%s)'%(WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('targetage'))
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['title'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMha
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['mpaa'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('targetage')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['plot'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('synopsis').replace('<br>','\n')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['duration']=WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('playtime')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['country']=WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('country')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['studio'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('cpname')
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('releasedate')!='':
    WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['year'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('releasedate')[:4]
    WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['premiered']=WUvsgTwcBQpfdGFeViHxzCEkyDuMhj.get('releasedate')
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhl=[]
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMhX in WUvsgTwcBQpfdGFeViHxzCEkyDuMhj['actors']['list']:WUvsgTwcBQpfdGFeViHxzCEkyDuMhl.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMhX.get('text'))
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhJ(WUvsgTwcBQpfdGFeViHxzCEkyDuMhl)>0:
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMhl[0]!='':WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['cast']=WUvsgTwcBQpfdGFeViHxzCEkyDuMhl
   WUvsgTwcBQpfdGFeViHxzCEkyDuMhL=[]
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMhr in WUvsgTwcBQpfdGFeViHxzCEkyDuMhj['directors']['list']:WUvsgTwcBQpfdGFeViHxzCEkyDuMhL.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMhr.get('text'))
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhJ(WUvsgTwcBQpfdGFeViHxzCEkyDuMhL)>0:
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMhL[0]!='':WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['director']=WUvsgTwcBQpfdGFeViHxzCEkyDuMhL
   WUvsgTwcBQpfdGFeViHxzCEkyDuMab=[]
   for WUvsgTwcBQpfdGFeViHxzCEkyDuMhR in WUvsgTwcBQpfdGFeViHxzCEkyDuMhj['genre']['list']:WUvsgTwcBQpfdGFeViHxzCEkyDuMab.append(WUvsgTwcBQpfdGFeViHxzCEkyDuMhR.get('text'))
   if WUvsgTwcBQpfdGFeViHxzCEkyDuMhJ(WUvsgTwcBQpfdGFeViHxzCEkyDuMab)>0:
    if WUvsgTwcBQpfdGFeViHxzCEkyDuMab[0]!='':WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['infoLabels']['genre']=WUvsgTwcBQpfdGFeViHxzCEkyDuMab
   WUvsgTwcBQpfdGFeViHxzCEkyDuMXl ='https://%s'%WUvsgTwcBQpfdGFeViHxzCEkyDuMhj['image']
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['thumbnail']['poster'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMXl
   WUvsgTwcBQpfdGFeViHxzCEkyDuMLn['saveinfo']['thumbnail']['thumb'] =WUvsgTwcBQpfdGFeViHxzCEkyDuMXl
  return WUvsgTwcBQpfdGFeViHxzCEkyDuMLn
# Created by pyminifier (https://github.com/liftoff/pyminifier)
