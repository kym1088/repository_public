__author__="NightRain"
eNBjhuiqdsLbTGnEAIXlSWtoPCzkUv=object
eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ=None
eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV=False
eNBjhuiqdsLbTGnEAIXlSWtoPCzkUr=True
eNBjhuiqdsLbTGnEAIXlSWtoPCzkKp=range
eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM=str
eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw=Exception
eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ=print
eNBjhuiqdsLbTGnEAIXlSWtoPCzkKU=dict
eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY=int
eNBjhuiqdsLbTGnEAIXlSWtoPCzkKD=len
import urllib
import re
import json
import sys
import requests
import datetime
class eNBjhuiqdsLbTGnEAIXlSWtoPCzkpM(eNBjhuiqdsLbTGnEAIXlSWtoPCzkUv):
 def __init__(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN='https://apis.wavve.com'
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.CREDENTIAL='none'
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.DEVICE ='pc'
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.DRM ='wm'
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.PARTNER ='pooq'
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.POOQZONE ='none'
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.REGION ='kor'
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.TARGETAGE ='all'
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.HTTPTAG ='https://'
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.LIST_LIMIT=30 
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.EP_LIMIT =30 
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.MV_LIMIT =24 
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.SEARCH_LIMIT=20 
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.guid ='none' 
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.guidtimestamp='none' 
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.DEFAULT_HEADER={'user-agent':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.USER_AGENT}
 def callRequestCookies(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,jobtype,eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,redirects=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpQ=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.DEFAULT_HEADER
  if headers:eNBjhuiqdsLbTGnEAIXlSWtoPCzkpQ.update(headers)
  if jobtype=='Get':
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpU=requests.get(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,params=params,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpQ,cookies=cookies,allow_redirects=redirects)
  else:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpU=requests.post(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,data=payload,params=params,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpQ,cookies=cookies,allow_redirects=redirects)
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpU
 def SaveCredential(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,eNBjhuiqdsLbTGnEAIXlSWtoPCzkpK):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.CREDENTIAL=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpK
 def LoadCredential(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw):
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.CREDENTIAL
 def GetDefaultParams(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUr):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY={'apikey':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.APIKEY,'credential':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.CREDENTIAL if login else 'none','device':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.DEVICE,'drm':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.DRM,'partner':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.PARTNER,'pooqzone':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.POOQZONE,'region':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.REGION,'targetage':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.TARGETAGE}
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY
 def GetGUID(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpR=GenerateRandomString(5)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpH=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpR+media+eNBjhuiqdsLbTGnEAIXlSWtoPCzkpD
   return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpH
  def GenerateRandomString(num):
   from random import randint
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpg=""
   for i in eNBjhuiqdsLbTGnEAIXlSWtoPCzkKp(0,num):
    s=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM(randint(1,5))
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpg+=s
   return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpg
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpH=GenerateID(guid_str)
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpF=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetHash(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpH)
  if guidType==2:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpF='%s-%s-%s-%s-%s'%(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpF[:8],eNBjhuiqdsLbTGnEAIXlSWtoPCzkpF[8:12],eNBjhuiqdsLbTGnEAIXlSWtoPCzkpF[12:16],eNBjhuiqdsLbTGnEAIXlSWtoPCzkpF[16:20],eNBjhuiqdsLbTGnEAIXlSWtoPCzkpF[20:])
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpF
 def GetHash(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM(m.hexdigest())
 def CheckQuality(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,sel_qt,qt_list):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpc=0
  for eNBjhuiqdsLbTGnEAIXlSWtoPCzkpx in qt_list:
   if sel_qt>=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpx:return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpx
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpc=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpx
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpc
 def Get_Now_Datetime(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,in_text):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpy=in_text.replace('&lt;','<').replace('&gt;','>')
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpy=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpy.replace('$O$','')
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpy=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpy)
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpy=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpy.lstrip('#')
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpy
 def GetCredential(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,user_id,user_pw,user_pf):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+ '/login'
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams()
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpa={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Post',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpa,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpK=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['credential']
   if user_pf!=0:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpa={'id':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpK,'password':'','profile':eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM(user_pf),'pushid':'','type':'credential'}
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['credential']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpK 
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Post',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpa,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpK=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['credential']
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpK:eNBjhuiqdsLbTGnEAIXlSWtoPCzkpf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUr
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpK='none' 
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.SaveCredential(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpK)
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpf
 def GetIssue(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpV=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/guid/issue'
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams()
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpr=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['guid']
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMp=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['guidtimestamp']
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpr:eNBjhuiqdsLbTGnEAIXlSWtoPCzkpV=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUr
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpr='none'
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMp='none' 
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.guid=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpr
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.guidtimestamp=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMp
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpV
 def Baseapi_Parse(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK):
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw =urllib.parse.urlsplit(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK)
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw.netloc=='':
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.HTTPTAG+eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw.netloc+eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw.path
   else:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw.scheme+'://'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw.netloc+eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw.path
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKU(urllib.parse.parse_qsl(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw.query))
  except:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return '',{}
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY
 def GetSupermultiUrl(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,sCode,sIndex='0'):
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/cf/supermultisections/'+sCode
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMQ=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['multisectionlist'][eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(sIndex)]['eventlist'][1]['url']
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return ''
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkMQ
 def Get_LiveCatagory_List(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,sCode,sIndex='0'):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU=[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetSupermultiUrl(sCode,sIndex)
  (eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY)=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Baseapi_Parse(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK)
  if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=='':return eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU,''
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('filter_item_list' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['filter']['filterlist'][0]):return[],''
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['filter']['filterlist'][0]['filter_item_list']
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH={'title':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title'],'genre':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['api_parameters'][eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['api_parameters'].index('=')+1:]}
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH)
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[],''
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK
 def Get_MainCatagory_List(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,sCode,sIndex='0'):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU=[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetSupermultiUrl(sCode,sIndex)
  (eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY)=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Baseapi_Parse(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK)
  if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=='':return eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('celllist' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['band']):return[]
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['band']['celllist']
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMg =eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['event_list'][1]['url']
    (eNBjhuiqdsLbTGnEAIXlSWtoPCzkMF,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMc)=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Baseapi_Parse(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMg)
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH={'title':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title_list'][0]['text'],'suburl':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMF,'subapi':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMc.get('api'),'subtype':'catagory' if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMc else 'supersection'}
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH)
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[]
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU
 def Get_SuperMultiSection_List(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,subapi_text):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU=[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY={}
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw =urllib.parse.urlsplit(subapi_text)
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw.path.find('apis.wavve.com')>=0: 
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.HTTPTAG+eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw.path 
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKU(urllib.parse.parse_qsl(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw.query))
   else:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/cf'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkMw.path 
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO.replace('supermultisection/','supermultisections/')
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[]
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('multisectionlist' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ):return[]
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['multisectionlist']
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMx=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title']
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkKD(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMx)==0:continue
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMx=='minor':continue
    if re.search(u'베너',eNBjhuiqdsLbTGnEAIXlSWtoPCzkMx):continue
    if re.search(u'배너',eNBjhuiqdsLbTGnEAIXlSWtoPCzkMx):continue 
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkKD(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['eventlist'])>=3:
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkMc =eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['eventlist'][2]['url']
    else:
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkMc =eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['eventlist'][1]['url']
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMm=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['cell_type']
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMm=='band_2':
     if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMc.find('channellist=')>=0:
      eNBjhuiqdsLbTGnEAIXlSWtoPCzkMm='band_live'
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH={'title':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Get_ChangeText(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMx),'subapi':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMc,'cell_type':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMm}
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH)
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[]
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU
 def Get_BandLiveSection_List(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK,page_int=1):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMy=[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=1
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  try:
   (eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY)=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Baseapi_Parse(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK)
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[],eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['limit']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.LIST_LIMIT
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['offset']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM((page_int-1)*eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.LIST_LIMIT)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('celllist' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']):return[],eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['celllist']
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMa =eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['event_list'][1]['url']
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv=urllib.parse.urlsplit(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMa).query
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKU(urllib.parse.parse_qsl(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv))
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ='channelid'
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv[eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ]
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH={'studio':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title_list'][0]['text'],'tvshowtitle':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Get_ChangeText(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title_list'][1]['text']),'channelid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV,'age':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('age'),'thumbnail':'https://%s'%eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('thumbnail')}
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMy.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['pagecount'])
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['count']:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr =eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['count'])
   else:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.LIST_LIMIT*page_int
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf>eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[],eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkMy,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO
 def Get_Band2Section_List(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK,page_int=1):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkwp=[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=1
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  try:
   (eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY)=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Baseapi_Parse(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK)
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[],eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['came'] ='BandView'
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['limit']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.LIST_LIMIT
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['offset']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM((page_int-1)*eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.LIST_LIMIT)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('celllist' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']):return[],eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['celllist']
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMa =eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['event_list'][1]['url']
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv=urllib.parse.urlsplit(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMa).query
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKU(urllib.parse.parse_qsl(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv))
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ='contentid'
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv[eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ]
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH={'programtitle':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title_list'][0]['text'],'episodetitle':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Get_ChangeText(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title_list'][1]['text']),'age':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('age'),'thumbnail':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.HTTPTAG+eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('thumbnail'),'vidtype':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ,'videoid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV}
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwp.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['pagecount'])
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['count']:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr =eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['count'])
   else:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.LIST_LIMIT*page_int
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf>eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[],eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwp,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO
 def Get_Program_List(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK,page_int=1,orderby='-'):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkwM=[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=1
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  (eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY)=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Baseapi_Parse(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK)
  if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=='':return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwM,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['limit'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.LIST_LIMIT
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['offset']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM((page_int-1)*eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.LIST_LIMIT)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['page'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM(page_int)
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.get('orderby')!='' and eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.get('orderby')!='regdatefirst' and orderby!='-':
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['orderby']=orderby 
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK.find('instantplay')>=0:
    if not('celllist' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['band']):return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwM,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['band']['celllist']
   else:
    if not('celllist' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']):return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwM,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['celllist']
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD:
    for eNBjhuiqdsLbTGnEAIXlSWtoPCzkwQ in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['event_list']:
     if eNBjhuiqdsLbTGnEAIXlSWtoPCzkwQ.get('type')=='on-navigation':
      eNBjhuiqdsLbTGnEAIXlSWtoPCzkMa =eNBjhuiqdsLbTGnEAIXlSWtoPCzkwQ['url']
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv=urllib.parse.urlsplit(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMa).query
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv[0:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv.find('=')]
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv[eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv.find('=')+1:]
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH={'title':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title_list'][0]['text'],'age':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['age'],'thumbnail':'https://%s'%eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('thumbnail'),'videoid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV,'vidtype':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ}
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwM.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH)
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK.find('instantplay')<0:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['pagecount'])
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['count']:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr =eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['count'])
    else:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.LIST_LIMIT*page_int
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf>eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[],eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwM,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO
 def Get_Movie_List(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK,page_int=1):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkwU=[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=1
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  (eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY)=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Baseapi_Parse(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK)
  if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=='':return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwU,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['limit']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.MV_LIMIT
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['offset']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM((page_int-1)*eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.MV_LIMIT)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('celllist' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']):return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwU,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['celllist']
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMa =eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['event_list'][1]['url']
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv=urllib.parse.urlsplit(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMa).query
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv[0:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv.find('=')]
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv[eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv.find('=')+1:]
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH={'title':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title_list'][0]['text'],'age':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['age'],'thumbnail':'https://%s'%eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('thumbnail'),'videoid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV,'vidtype':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ}
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwU.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['pagecount'])
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['count']:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr =eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['count'])
   else:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.MV_LIMIT*page_int
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf>eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[],eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwU,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO
 def ProgramidToContentid(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,eNBjhuiqdsLbTGnEAIXlSWtoPCzkwD):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK=''
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/vod/programs-contentid/'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkwD
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('contentid' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY):return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK 
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY['contentid']
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK
 def ContentidToProgramid(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkwD=''
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/cf/vod/contents/'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('programid' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY):return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwD 
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY['programid']
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwD
 def GetProgramInfo(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,program_code):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkwR={}
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/cf/vod/contents/'+program_code
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwH=img_fanart=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwg=''
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY.get('programposterimage')!='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwH =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.HTTPTAG+eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY.get('programposterimage')
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY.get('programimage') !='':img_fanart =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.HTTPTAG+eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY.get('programimage')
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY.get('programcirlceimage')!='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwg=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.HTTPTAG+eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY.get('programcirlceimage')
   if 'poster_default' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkwH:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwH =img_fanart
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwg=''
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwR={'imgPoster':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwH,'imgFanart':img_fanart,'imgClearlogo':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwg}
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwR
 def Get_Episode_List(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ,page_int=1,orderby='desc'):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkwF=[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=1
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkwc={}
  if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ=='contentid':
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.ContentidToProgramid(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwc=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetProgramInfo(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV)
  else:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.ProgramidToContentid(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV)
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK!='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwc=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetProgramInfo(eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/vod/programs-contents/'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkwD
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY={}
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['limit'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.EP_LIMIT
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['offset']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM((page_int-1)*eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.EP_LIMIT)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['orderby']=orderby 
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['list']
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwm=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('synopsis'))
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwy=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.HTTPTAG+eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('image')
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwa=''
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkwc!={}:
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkwf =eNBjhuiqdsLbTGnEAIXlSWtoPCzkwc.get('imgPoster')
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkwO =eNBjhuiqdsLbTGnEAIXlSWtoPCzkwc.get('imgFanart')
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkwa=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwc.get('imgClearlogo')
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkwv={'thumb':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwy,'poster':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwf,'fanart':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwO,'clearlogo':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwa}
    else:
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkwv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwy
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH={'programtitle':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('programtitle'),'episodetitle':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('episodetitle'),'episodenumber':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('episodenumber'),'releasedate':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('releasedate'),'releaseweekday':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('releaseweekday'),'programid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('programid'),'contentid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('contentid'),'age':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('targetage'),'playtime':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('playtime'),'synopsis':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwm,'episodeactors':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('episodeactors').split(',')if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('episodeactors')!='' else[],'thumbnail':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwv}
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwF.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['pagecount'])
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['count']:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr =eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['count'])
   else:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.EP_LIMIT*page_int
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf>eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[],eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwF,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO
 def GetEPGList(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,genre):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkwJ={}
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwV=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Get_Now_Datetime()
   if genre=='all':
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwr =eNBjhuiqdsLbTGnEAIXlSWtoPCzkwV+datetime.timedelta(hours=3)
   else:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwr =eNBjhuiqdsLbTGnEAIXlSWtoPCzkwV+datetime.timedelta(hours=3)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/live/epgs'
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY={'limit':'100','offset':'0','genre':genre,'startdatetime':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwV.strftime('%Y-%m-%d %H:00'),'enddatetime':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwr.strftime('%Y-%m-%d %H:00')}
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkQp=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['list']
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkQp:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkQM=''
    for eNBjhuiqdsLbTGnEAIXlSWtoPCzkQw in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['list']:
     if eNBjhuiqdsLbTGnEAIXlSWtoPCzkQM:eNBjhuiqdsLbTGnEAIXlSWtoPCzkQM+='\n'
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkQM+=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Get_ChangeText(eNBjhuiqdsLbTGnEAIXlSWtoPCzkQw['title'])+'\n'
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkQM+=' [%s ~ %s]'%(eNBjhuiqdsLbTGnEAIXlSWtoPCzkQw['starttime'][-5:],eNBjhuiqdsLbTGnEAIXlSWtoPCzkQw['endtime'][-5:])+'\n'
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwJ[eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['channelid']]=eNBjhuiqdsLbTGnEAIXlSWtoPCzkQM
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkwJ
 def Get_LiveChannel_List(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,genre,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMy=[]
  (eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY)=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Baseapi_Parse(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMK)
  if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=='':return eNBjhuiqdsLbTGnEAIXlSWtoPCzkMy
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQU=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetEPGList(genre)
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['genre']=genre
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('celllist' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']):return[]
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['celllist']
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['contentid']
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK in eNBjhuiqdsLbTGnEAIXlSWtoPCzkQU:
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkQK=eNBjhuiqdsLbTGnEAIXlSWtoPCzkQU[eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK]
    else:
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkQK=''
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH={'studio':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title_list'][0]['text'],'tvshowtitle':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Get_ChangeText(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title_list'][1]['text']),'channelid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK,'age':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['age'],'thumbnail':'https://%s'%eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('thumbnail'),'epg':eNBjhuiqdsLbTGnEAIXlSWtoPCzkQK}
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMy.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH)
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[]
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkMy
 def Get_Search_List(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,search_key,sType,page_int,exclusion21=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQY=[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=1
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/cf/search/list.js'
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM((page_int-1)*eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.SEARCH_LIMIT),'limit':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.SEARCH_LIMIT,'orderby':'score'}
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('celllist' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY['cell_toplist']):return eNBjhuiqdsLbTGnEAIXlSWtoPCzkQY,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY['cell_toplist']['celllist']
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMa =eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['event_list'][1]['url']
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv=urllib.parse.urlsplit(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMa).query
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv[0:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv.find('=')]
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv[eNBjhuiqdsLbTGnEAIXlSWtoPCzkMv.find('=')+1:]
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH={'title':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['title_list'][0]['text'],'age':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR['age'],'thumbnail':'https://%s'%eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('thumbnail'),'videoid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV,'vidtype':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ}
    if exclusion21==eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV or eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('age')!='21':
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkQY.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY['cell_toplist']['pagecount'])
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY['cell_toplist']['count']:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr =eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkwY['cell_toplist']['count'])
   else:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.LIST_LIMIT
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMf>eNBjhuiqdsLbTGnEAIXlSWtoPCzkMr
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkQY,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMO 
 def GetStreamingURL(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,mode,eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK,quality_int,pvrmode='-'):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkQy=eNBjhuiqdsLbTGnEAIXlSWtoPCzkQf=streaming_preview=''
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQR=[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQH='hls'
  if mode=='LIVE':
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/live/channels/'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkQg='live'
  elif mode=='VOD':
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/cf/vod/contents/'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkQg='vod'
  elif mode=='MOVIE':
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/cf/movie/contents/'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkQg='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV)
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkQF=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['qualities']['list']
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkQF==eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ:return(eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQy,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQf,streaming_preview)
    for eNBjhuiqdsLbTGnEAIXlSWtoPCzkQc in eNBjhuiqdsLbTGnEAIXlSWtoPCzkQF:
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkQR.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkKY(eNBjhuiqdsLbTGnEAIXlSWtoPCzkQc.get('id').rstrip('p')))
    if 'type' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ:
     if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['type']=='onair':
      eNBjhuiqdsLbTGnEAIXlSWtoPCzkQg='onairvod'
    if 'drms' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ:
     if eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['drms']:
      eNBjhuiqdsLbTGnEAIXlSWtoPCzkQH='dash'
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return(eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQy,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQf,streaming_preview)
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkQx=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.CheckQuality(quality_int,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQR)
   if mode=='LIVE' and pvrmode!='-':
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkQm='auto'
   else:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkQm=eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM(eNBjhuiqdsLbTGnEAIXlSWtoPCzkQx)+'p'
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/streaming'
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY={'contentid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK,'contenttype':eNBjhuiqdsLbTGnEAIXlSWtoPCzkQg,'action':eNBjhuiqdsLbTGnEAIXlSWtoPCzkQH,'quality':eNBjhuiqdsLbTGnEAIXlSWtoPCzkQm,'deviceModelId':'Windows 10','guid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUr))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['playurl']
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD==eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ:return(eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQy,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQf,streaming_preview)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkQy=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['awscookie']
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkQf =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['drm']
   if 'previewmsg' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['preview']:streaming_preview=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['preview']['previewmsg']
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
  return(eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQy,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQf,streaming_preview) 
 def GetSportsURL(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK,quality_int):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkQy=''
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQR=[]
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/streaming/other'
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY={'contentid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK,'contenttype':'live','action':'hls','quality':eNBjhuiqdsLbTGnEAIXlSWtoPCzkKM(quality_int)+'p','deviceModelId':'Windows 10','guid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUr))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['playurl']
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD==eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ:return(eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQy)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkQy=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['awscookie']
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
  return(eNBjhuiqdsLbTGnEAIXlSWtoPCzkQD,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQy) 
 def make_viewdate(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQO =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.Get_Now_Datetime()
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQa =eNBjhuiqdsLbTGnEAIXlSWtoPCzkQO+datetime.timedelta(days=-1)
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQv =eNBjhuiqdsLbTGnEAIXlSWtoPCzkQO+datetime.timedelta(days=1)
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQJ=[eNBjhuiqdsLbTGnEAIXlSWtoPCzkQO.strftime('%Y%m%d'),eNBjhuiqdsLbTGnEAIXlSWtoPCzkQv.strftime('%Y%m%d'),]
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkQJ
 def Get_Sports_Gamelist(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw):
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQV =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.make_viewdate()
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkQr=[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkUp =[]
  for eNBjhuiqdsLbTGnEAIXlSWtoPCzkUM in eNBjhuiqdsLbTGnEAIXlSWtoPCzkQV:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUw=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUM[:6]
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUw not in eNBjhuiqdsLbTGnEAIXlSWtoPCzkQr:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkQr.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkUw)
  try:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY.update(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV))
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkUQ in eNBjhuiqdsLbTGnEAIXlSWtoPCzkQr:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY['date']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUQ
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ['cell_toplist']['celllist']
    for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkMD:
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkUK=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('game_date')
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkUY =eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('svc_id')
     if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUY=='':continue
     if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUK in eNBjhuiqdsLbTGnEAIXlSWtoPCzkQV:
      eNBjhuiqdsLbTGnEAIXlSWtoPCzkUD=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('game_status') 
      eNBjhuiqdsLbTGnEAIXlSWtoPCzkUR =eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('title_list')[0].get('text')
      eNBjhuiqdsLbTGnEAIXlSWtoPCzkUK =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUK[:4]+'-'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkUK[4:6]+'-'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkUK[-2:]
      eNBjhuiqdsLbTGnEAIXlSWtoPCzkUH =eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('game_time')
      eNBjhuiqdsLbTGnEAIXlSWtoPCzkUH =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUH[:2]+':'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkUH[-2:]
      eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH={'game_date':eNBjhuiqdsLbTGnEAIXlSWtoPCzkUK,'game_time':eNBjhuiqdsLbTGnEAIXlSWtoPCzkUH,'svc_id':eNBjhuiqdsLbTGnEAIXlSWtoPCzkUY,'away_team':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('away_team').get('team_name'),'home_team':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('home_team').get('team_name'),'game_status':eNBjhuiqdsLbTGnEAIXlSWtoPCzkUD,'game_place':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('game_place'),}
      eNBjhuiqdsLbTGnEAIXlSWtoPCzkUp.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMH)
  except eNBjhuiqdsLbTGnEAIXlSWtoPCzkKw as exception:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkKQ(exception)
   return[]
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkUg=[]
  for i in eNBjhuiqdsLbTGnEAIXlSWtoPCzkKp(2):
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR in eNBjhuiqdsLbTGnEAIXlSWtoPCzkUp:
    if i==0 and eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('game_status')=='LIVE':
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkUg.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR)
    elif i==1 and eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR.get('game_status')!='LIVE':
     eNBjhuiqdsLbTGnEAIXlSWtoPCzkUg.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMR)
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkUg
 def GetBookmarkInfo(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV,eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ,eNBjhuiqdsLbTGnEAIXlSWtoPCzkQg):
  if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ=='tvshow':
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkQg=='contentid':
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.ContentidToProgramid(eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK)
   else:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.ProgramidToContentid(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV)
  else:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK=''
  eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF={'indexinfo':{'ott':'wavve','videoid':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV,'vidtype':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMJ=='tvshow':
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/cf/vod/contents/'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkwK 
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('programtitle' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ):return{}
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUx=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('programtitle')
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['title']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUx
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('targetage')=='18' or eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('targetage')=='19' or eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('targetage')=='21':
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkUx +=u' (%s)'%(eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('targetage'))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['title'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUx
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['mpaa'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('targetage')
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['plot'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('programsynopsis').replace('<br>','\n')
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['studio'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('channelname')
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('firstreleaseyear')!='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['year'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('firstreleaseyear')
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('firstreleasedate')!='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['premiered']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('firstreleasedate')
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('genretext') !='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['genre'] =[eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('genretext')]
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUm=[]
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkUy in eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc['actors']['list']:eNBjhuiqdsLbTGnEAIXlSWtoPCzkUm.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkUy.get('text'))
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkKD(eNBjhuiqdsLbTGnEAIXlSWtoPCzkUm)>0:
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUm[0]!='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['cast']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUm
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwf =''
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwO =''
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwa=''
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('programposterimage')!='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwf =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.HTTPTAG+eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('programposterimage')
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('programimage') !='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwO =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.HTTPTAG+eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('programimage')
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('programcirlceimage')!='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkwa=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.HTTPTAG+eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('programcirlceimage')
   if 'poster_default' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkwf:
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwf =eNBjhuiqdsLbTGnEAIXlSWtoPCzkwO
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkwa=''
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['thumbnail']['poster']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwf
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['thumbnail']['thumb']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwO
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['thumbnail']['clearlogo']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwa
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['thumbnail']['fanart']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkwO
  else:
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.API_DOMAIN+'/movie/contents/'+eNBjhuiqdsLbTGnEAIXlSWtoPCzkMV 
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.GetDefaultParams(login=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUV)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpw.callRequestCookies('Get',eNBjhuiqdsLbTGnEAIXlSWtoPCzkpO,payload=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,params=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpY,headers=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ,cookies=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUJ)
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ=json.loads(eNBjhuiqdsLbTGnEAIXlSWtoPCzkpv.text)
   if not('title' in eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ):return{}
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc=eNBjhuiqdsLbTGnEAIXlSWtoPCzkpJ
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUx=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('title')
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['title']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUx
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('targetage')=='18' or eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('targetage')=='19' or eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('targetage')=='21':
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkUx +=u' (%s)'%(eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('targetage'))
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['title'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUx
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['mpaa'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('targetage')
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['plot'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('synopsis').replace('<br>','\n')
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['duration']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('playtime')
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['country']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('country')
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['studio'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('cpname')
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('releasedate')!='':
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['year'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('releasedate')[:4]
    eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['premiered']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc.get('releasedate')
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUm=[]
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkUy in eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc['actors']['list']:eNBjhuiqdsLbTGnEAIXlSWtoPCzkUm.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkUy.get('text'))
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkKD(eNBjhuiqdsLbTGnEAIXlSWtoPCzkUm)>0:
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUm[0]!='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['cast']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUm
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUf=[]
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkUO in eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc['directors']['list']:eNBjhuiqdsLbTGnEAIXlSWtoPCzkUf.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkUO.get('text'))
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkKD(eNBjhuiqdsLbTGnEAIXlSWtoPCzkUf)>0:
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkUf[0]!='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['director']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkUf
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU=[]
   for eNBjhuiqdsLbTGnEAIXlSWtoPCzkUa in eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc['genre']['list']:eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU.append(eNBjhuiqdsLbTGnEAIXlSWtoPCzkUa.get('text'))
   if eNBjhuiqdsLbTGnEAIXlSWtoPCzkKD(eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU)>0:
    if eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU[0]!='':eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['infoLabels']['genre']=eNBjhuiqdsLbTGnEAIXlSWtoPCzkMU
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkwf ='https://%s'%eNBjhuiqdsLbTGnEAIXlSWtoPCzkUc['image']
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['thumbnail']['poster'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkwf
   eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF['saveinfo']['thumbnail']['thumb'] =eNBjhuiqdsLbTGnEAIXlSWtoPCzkwf
  return eNBjhuiqdsLbTGnEAIXlSWtoPCzkUF
# Created by pyminifier (https://github.com/liftoff/pyminifier)
