__author__="NightRain"
QBEHCqUgnGPYapWFXeMoRNrLvlzhKj=object
QBEHCqUgnGPYapWFXeMoRNrLvlzhKy=None
QBEHCqUgnGPYapWFXeMoRNrLvlzhKi=True
QBEHCqUgnGPYapWFXeMoRNrLvlzhKV=False
QBEHCqUgnGPYapWFXeMoRNrLvlzhKs=int
QBEHCqUgnGPYapWFXeMoRNrLvlzhKw=type
QBEHCqUgnGPYapWFXeMoRNrLvlzhKI=dict
QBEHCqUgnGPYapWFXeMoRNrLvlzhKT=len
QBEHCqUgnGPYapWFXeMoRNrLvlzhKt=range
QBEHCqUgnGPYapWFXeMoRNrLvlzhKx=str
QBEHCqUgnGPYapWFXeMoRNrLvlzhKf=open
QBEHCqUgnGPYapWFXeMoRNrLvlzhKJ=Exception
QBEHCqUgnGPYapWFXeMoRNrLvlzhbD=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
QBEHCqUgnGPYapWFXeMoRNrLvlzhDk=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
QBEHCqUgnGPYapWFXeMoRNrLvlzhDu=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
QBEHCqUgnGPYapWFXeMoRNrLvlzhDA=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
QBEHCqUgnGPYapWFXeMoRNrLvlzhDm =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
QBEHCqUgnGPYapWFXeMoRNrLvlzhDK=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class QBEHCqUgnGPYapWFXeMoRNrLvlzhDS(QBEHCqUgnGPYapWFXeMoRNrLvlzhKj):
 def __init__(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,QBEHCqUgnGPYapWFXeMoRNrLvlzhDd,QBEHCqUgnGPYapWFXeMoRNrLvlzhDO,QBEHCqUgnGPYapWFXeMoRNrLvlzhDc):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_url =QBEHCqUgnGPYapWFXeMoRNrLvlzhDd
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle=QBEHCqUgnGPYapWFXeMoRNrLvlzhDO
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params =QBEHCqUgnGPYapWFXeMoRNrLvlzhDc
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj =eNBjhuiqdsLbTGnEAIXlSWtoPCzkpM() 
 def addon_noti(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,sting):
  try:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDy=xbmcgui.Dialog()
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDy.notification(__addonname__,sting)
  except:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
 def addon_log(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,string):
  try:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDi=string.encode('utf-8','ignore')
  except:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDi='addonException: addon_log'
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDV=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,QBEHCqUgnGPYapWFXeMoRNrLvlzhDi),level=QBEHCqUgnGPYapWFXeMoRNrLvlzhDV)
 def get_keyboard_input(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,QBEHCqUgnGPYapWFXeMoRNrLvlzhSd):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDs=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
  kb=xbmc.Keyboard()
  kb.setHeading(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDs=kb.getText()
  return QBEHCqUgnGPYapWFXeMoRNrLvlzhDs
 def get_settings_login_info(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDw =__addon__.getSetting('id')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDI =__addon__.getSetting('pw')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDT=__addon__.getSetting('selected_profile')
  return(QBEHCqUgnGPYapWFXeMoRNrLvlzhDw,QBEHCqUgnGPYapWFXeMoRNrLvlzhDI,QBEHCqUgnGPYapWFXeMoRNrLvlzhDT)
 def get_settings_totalsearch(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDt =QBEHCqUgnGPYapWFXeMoRNrLvlzhKi if __addon__.getSetting('local_search')=='true' else QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDx=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi if __addon__.getSetting('local_history')=='true' else QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDf =QBEHCqUgnGPYapWFXeMoRNrLvlzhKi if __addon__.getSetting('total_search')=='true' else QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDJ=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi if __addon__.getSetting('total_history')=='true' else QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSD=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi if __addon__.getSetting('menu_bookmark')=='true' else QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
  return(QBEHCqUgnGPYapWFXeMoRNrLvlzhDt,QBEHCqUgnGPYapWFXeMoRNrLvlzhDx,QBEHCqUgnGPYapWFXeMoRNrLvlzhDf,QBEHCqUgnGPYapWFXeMoRNrLvlzhDJ,QBEHCqUgnGPYapWFXeMoRNrLvlzhSD)
 def get_settings_makebookmark(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  return QBEHCqUgnGPYapWFXeMoRNrLvlzhKi if __addon__.getSetting('make_bookmark')=='true' else QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
 def get_selQuality(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  try:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSk=[1080,720,480,360]
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSu=QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(__addon__.getSetting('selected_quality'))
   return QBEHCqUgnGPYapWFXeMoRNrLvlzhSk[QBEHCqUgnGPYapWFXeMoRNrLvlzhSu]
  except:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
  return 1080 
 def get_settings_exclusion21(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSA =__addon__.getSetting('exclusion21')
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSA=='false':
   return QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
  else:
   return QBEHCqUgnGPYapWFXeMoRNrLvlzhKi
 def get_settings_direct_replay(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSm=QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(__addon__.getSetting('direct_replay'))
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSm==0:
   return QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
  else:
   return QBEHCqUgnGPYapWFXeMoRNrLvlzhKi
 def set_winCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,credential):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK=xbmcgui.Window(10000)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK.setProperty('WAVVE_M_CREDENTIAL',credential)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK.setProperty('WAVVE_M_LOGINTIME',QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK=xbmcgui.Window(10000)
  return QBEHCqUgnGPYapWFXeMoRNrLvlzhSK.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,QBEHCqUgnGPYapWFXeMoRNrLvlzhAS):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK=xbmcgui.Window(10000)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK.setProperty('WAVVE_M_ORDERBY',QBEHCqUgnGPYapWFXeMoRNrLvlzhAS)
 def get_winEpisodeOrderby(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK=xbmcgui.Window(10000)
  return QBEHCqUgnGPYapWFXeMoRNrLvlzhSK.getProperty('WAVVE_M_ORDERBY')
 def add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,label,sublabel='',img='',infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params='',isLink=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV,ContextMenu=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSb='%s?%s'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_url,urllib.parse.urlencode(params))
  if sublabel:QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='%s < %s >'%(label,sublabel)
  else: QBEHCqUgnGPYapWFXeMoRNrLvlzhSd=label
  if not img:img='DefaultFolder.png'
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSO=xbmcgui.ListItem(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKw(img)==QBEHCqUgnGPYapWFXeMoRNrLvlzhKI:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSO.setArt(img)
  else:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSO.setArt({'thumb':img,'poster':img})
  if infoLabels:QBEHCqUgnGPYapWFXeMoRNrLvlzhSO.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSO.setProperty('IsPlayable','true')
  if ContextMenu:QBEHCqUgnGPYapWFXeMoRNrLvlzhSO.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,QBEHCqUgnGPYapWFXeMoRNrLvlzhSb,QBEHCqUgnGPYapWFXeMoRNrLvlzhSO,isFolder)
 def dp_Main_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  (QBEHCqUgnGPYapWFXeMoRNrLvlzhDt,QBEHCqUgnGPYapWFXeMoRNrLvlzhDx,QBEHCqUgnGPYapWFXeMoRNrLvlzhDf,QBEHCqUgnGPYapWFXeMoRNrLvlzhDJ,QBEHCqUgnGPYapWFXeMoRNrLvlzhSD)=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_settings_totalsearch()
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhSc in QBEHCqUgnGPYapWFXeMoRNrLvlzhDk:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd=QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('title')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSj=''
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('mode')=='SEARCH_GROUP' and QBEHCqUgnGPYapWFXeMoRNrLvlzhDt ==QBEHCqUgnGPYapWFXeMoRNrLvlzhKV:continue
   elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('mode')=='SEARCH_HISTORY' and QBEHCqUgnGPYapWFXeMoRNrLvlzhDx==QBEHCqUgnGPYapWFXeMoRNrLvlzhKV:continue
   elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('mode')=='TOTAL_SEARCH' and QBEHCqUgnGPYapWFXeMoRNrLvlzhDf ==QBEHCqUgnGPYapWFXeMoRNrLvlzhKV:continue
   elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('mode')=='TOTAL_HISTORY' and QBEHCqUgnGPYapWFXeMoRNrLvlzhDJ==QBEHCqUgnGPYapWFXeMoRNrLvlzhKV:continue
   elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('mode')=='MENU_BOOKMARK' and QBEHCqUgnGPYapWFXeMoRNrLvlzhSD==QBEHCqUgnGPYapWFXeMoRNrLvlzhKV:continue
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('mode'),'sCode':QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('sCode'),'sIndex':QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('sIndex'),'sType':QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('sType'),'suburl':QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('suburl'),'subapi':QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('subapi'),'page':QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('page'),'orderby':QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('orderby'),'ordernm':QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('ordernm')}
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSi=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSV =QBEHCqUgnGPYapWFXeMoRNrLvlzhKi
   else:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSi=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSV =QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
   if 'icon' in QBEHCqUgnGPYapWFXeMoRNrLvlzhSc:QBEHCqUgnGPYapWFXeMoRNrLvlzhSj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',QBEHCqUgnGPYapWFXeMoRNrLvlzhSc.get('icon')) 
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img=QBEHCqUgnGPYapWFXeMoRNrLvlzhSj,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhSi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy,isLink=QBEHCqUgnGPYapWFXeMoRNrLvlzhSV)
  xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi)
 def dp_Search_Group(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  if 'search_key' in args:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSI=args.get('search_key')
  else:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSI=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not QBEHCqUgnGPYapWFXeMoRNrLvlzhSI:
    return
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhST in QBEHCqUgnGPYapWFXeMoRNrLvlzhDu:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSt =QBEHCqUgnGPYapWFXeMoRNrLvlzhST.get('mode')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSx=QBEHCqUgnGPYapWFXeMoRNrLvlzhST.get('sType')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd=QBEHCqUgnGPYapWFXeMoRNrLvlzhST.get('title')
   (QBEHCqUgnGPYapWFXeMoRNrLvlzhSf,QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ)=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_Search_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhSI,QBEHCqUgnGPYapWFXeMoRNrLvlzhSx,1,exclusion21=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_settings_exclusion21())
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkD={'plot':'검색어 : '+QBEHCqUgnGPYapWFXeMoRNrLvlzhSI+'\n\n'+QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.Search_FreeList(QBEHCqUgnGPYapWFXeMoRNrLvlzhSf)}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':QBEHCqUgnGPYapWFXeMoRNrLvlzhSt,'sType':QBEHCqUgnGPYapWFXeMoRNrLvlzhSx,'search_key':QBEHCqUgnGPYapWFXeMoRNrLvlzhSI,'page':'1',}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img='',infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhkD,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(QBEHCqUgnGPYapWFXeMoRNrLvlzhDu)>0:xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.Save_Searched_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhSI)
 def Search_FreeList(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,search_list):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkS=''
  QBEHCqUgnGPYapWFXeMoRNrLvlzhku=7
  try:
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(search_list)==0:return '검색결과 없음'
   for i in QBEHCqUgnGPYapWFXeMoRNrLvlzhKt(QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(search_list)):
    if i>=QBEHCqUgnGPYapWFXeMoRNrLvlzhku:
     QBEHCqUgnGPYapWFXeMoRNrLvlzhkS=QBEHCqUgnGPYapWFXeMoRNrLvlzhkS+'...'
     break
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkS=QBEHCqUgnGPYapWFXeMoRNrLvlzhkS+search_list[i]['title']+'\n'
  except:
   return ''
  return QBEHCqUgnGPYapWFXeMoRNrLvlzhkS
 def dp_Watch_Group(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhkA in QBEHCqUgnGPYapWFXeMoRNrLvlzhDA:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd=QBEHCqUgnGPYapWFXeMoRNrLvlzhkA.get('title')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':QBEHCqUgnGPYapWFXeMoRNrLvlzhkA.get('mode'),'sType':QBEHCqUgnGPYapWFXeMoRNrLvlzhkA.get('sType')}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img='',infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(QBEHCqUgnGPYapWFXeMoRNrLvlzhDA)>0:xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi)
 def dp_Search_History(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkm=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.Load_List_File('search')
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhkK in QBEHCqUgnGPYapWFXeMoRNrLvlzhkm:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkb=QBEHCqUgnGPYapWFXeMoRNrLvlzhKI(urllib.parse.parse_qsl(QBEHCqUgnGPYapWFXeMoRNrLvlzhkK))
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkd=QBEHCqUgnGPYapWFXeMoRNrLvlzhkb.get('skey').strip()
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'SEARCH_GROUP','search_key':QBEHCqUgnGPYapWFXeMoRNrLvlzhkd,}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkO={'mode':'SEARCH_REMOVE','sType':'ONE','skey':QBEHCqUgnGPYapWFXeMoRNrLvlzhkd,}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkc=urllib.parse.urlencode(QBEHCqUgnGPYapWFXeMoRNrLvlzhkO)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkj=[('선택된 검색어 ( %s ) 삭제'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhkd),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhkc))]
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhkd,sublabel='',img=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy,ContextMenu=QBEHCqUgnGPYapWFXeMoRNrLvlzhkj)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'plot':'검색목록 전체를 삭제합니다.'}
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'SEARCH_REMOVE','sType':'ALL','skey':'-',}
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img=QBEHCqUgnGPYapWFXeMoRNrLvlzhSj,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy,isLink=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi)
  xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def dp_Search_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSx =args.get('sType')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhki =QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(args.get('page'))
  if 'search_key' in args:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSI=args.get('search_key')
  else:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSI=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not QBEHCqUgnGPYapWFXeMoRNrLvlzhSI:
    xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle)
    return
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV,QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_Search_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhSI,QBEHCqUgnGPYapWFXeMoRNrLvlzhSx,QBEHCqUgnGPYapWFXeMoRNrLvlzhki,exclusion21=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_settings_exclusion21())
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('title')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkw=QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('thumbnail')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkI =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('age')
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhkI=='18' or QBEHCqUgnGPYapWFXeMoRNrLvlzhkI=='19' or QBEHCqUgnGPYapWFXeMoRNrLvlzhkI=='21':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd+=' (%s)'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhkI)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'mediatype':'tvshow' if QBEHCqUgnGPYapWFXeMoRNrLvlzhSx=='vod' else 'movie','mpaa':QBEHCqUgnGPYapWFXeMoRNrLvlzhkI,'title':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'plot':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd}
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhSx=='vod':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'EPISODE_LIST','videoid':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('videoid'),'vidtype':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('vidtype'),'page':'1'}
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSi=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi
   else:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'MOVIE','contentid':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('videoid'),'title':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'thumbnail':QBEHCqUgnGPYapWFXeMoRNrLvlzhkw,'age':QBEHCqUgnGPYapWFXeMoRNrLvlzhkI}
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSi=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_settings_makebookmark():
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkT={'videoid':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('videoid'),'vidtype':'tvshow' if QBEHCqUgnGPYapWFXeMoRNrLvlzhSx=='vod' else 'movie','vtitle':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'vsubtitle':'','contenttype':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('vidtype'),}
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkt=json.dumps(QBEHCqUgnGPYapWFXeMoRNrLvlzhkT)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkt=urllib.parse.quote(QBEHCqUgnGPYapWFXeMoRNrLvlzhkt)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkx='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhkt)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkj=[('(통합) 찜 영상에 추가',QBEHCqUgnGPYapWFXeMoRNrLvlzhkx)]
   else:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkj=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img=QBEHCqUgnGPYapWFXeMoRNrLvlzhkw,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhSi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy,ContextMenu=QBEHCqUgnGPYapWFXeMoRNrLvlzhkj)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['mode'] ='SEARCH_LIST' 
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['sType']=QBEHCqUgnGPYapWFXeMoRNrLvlzhSx 
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['page'] =QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['search_key']=QBEHCqUgnGPYapWFXeMoRNrLvlzhSI
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='[B]%s >>[/B]'%'다음 페이지'
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkf=QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,img=QBEHCqUgnGPYapWFXeMoRNrLvlzhSj,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSx=='movie':xbmcplugin.setContent(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,'movies')
  else:xbmcplugin.setContent(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def dp_Watch_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSx =args.get('sType')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSm=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_settings_direct_replay()
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.Load_List_File(QBEHCqUgnGPYapWFXeMoRNrLvlzhSx)
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkb=QBEHCqUgnGPYapWFXeMoRNrLvlzhKI(urllib.parse.parse_qsl(QBEHCqUgnGPYapWFXeMoRNrLvlzhks))
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkJ =QBEHCqUgnGPYapWFXeMoRNrLvlzhkb.get('code').strip()
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd =QBEHCqUgnGPYapWFXeMoRNrLvlzhkb.get('title').strip()
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkf =QBEHCqUgnGPYapWFXeMoRNrLvlzhkb.get('subtitle').strip()
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhkf=='None':QBEHCqUgnGPYapWFXeMoRNrLvlzhkf=''
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkw=QBEHCqUgnGPYapWFXeMoRNrLvlzhkb.get('img').strip()
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuD =QBEHCqUgnGPYapWFXeMoRNrLvlzhkb.get('videoid').strip()
   try:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkw=QBEHCqUgnGPYapWFXeMoRNrLvlzhkw.replace('\'','\"')
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkw=json.loads(QBEHCqUgnGPYapWFXeMoRNrLvlzhkw)
   except:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
   QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'plot':'%s\n%s'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,QBEHCqUgnGPYapWFXeMoRNrLvlzhkf)}
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhSx=='vod':
    if QBEHCqUgnGPYapWFXeMoRNrLvlzhSm==QBEHCqUgnGPYapWFXeMoRNrLvlzhKV or QBEHCqUgnGPYapWFXeMoRNrLvlzhuD==QBEHCqUgnGPYapWFXeMoRNrLvlzhKy:
     QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'EPISODE_LIST','videoid':QBEHCqUgnGPYapWFXeMoRNrLvlzhkJ,'vidtype':'programid','page':'1'}
     QBEHCqUgnGPYapWFXeMoRNrLvlzhSi=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi
    else:
     QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'VOD','programid':QBEHCqUgnGPYapWFXeMoRNrLvlzhkJ,'contentid':QBEHCqUgnGPYapWFXeMoRNrLvlzhuD,'title':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'subtitle':QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,'thumbnail':QBEHCqUgnGPYapWFXeMoRNrLvlzhkw}
     QBEHCqUgnGPYapWFXeMoRNrLvlzhSi=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
   else:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'MOVIE','contentid':QBEHCqUgnGPYapWFXeMoRNrLvlzhkJ,'title':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'subtitle':QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,'thumbnail':QBEHCqUgnGPYapWFXeMoRNrLvlzhkw}
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSi=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,img=QBEHCqUgnGPYapWFXeMoRNrLvlzhkw,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhSi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'plot':'시청목록을 삭제합니다.'}
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='*** 시청목록 삭제 ***'
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'MYVIEW_REMOVE','sType':QBEHCqUgnGPYapWFXeMoRNrLvlzhSx,'skey':'-',}
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img=QBEHCqUgnGPYapWFXeMoRNrLvlzhSj,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy,isLink=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSx=='movie':xbmcplugin.setContent(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,'movies')
  else:xbmcplugin.setContent(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def Load_List_File(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,QBEHCqUgnGPYapWFXeMoRNrLvlzhui): 
  try:
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhui=='search':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhuS=QBEHCqUgnGPYapWFXeMoRNrLvlzhDK
   elif QBEHCqUgnGPYapWFXeMoRNrLvlzhui in['vod','movie']:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhuS=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QBEHCqUgnGPYapWFXeMoRNrLvlzhui))
   else:
    return[]
   fp=QBEHCqUgnGPYapWFXeMoRNrLvlzhKf(QBEHCqUgnGPYapWFXeMoRNrLvlzhuS,'r',-1,'utf-8')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuk=fp.readlines()
   fp.close()
  except:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuk=[]
  return QBEHCqUgnGPYapWFXeMoRNrLvlzhuk
 def Save_Watched_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,QBEHCqUgnGPYapWFXeMoRNrLvlzhmJ,QBEHCqUgnGPYapWFXeMoRNrLvlzhDc):
  try:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QBEHCqUgnGPYapWFXeMoRNrLvlzhmJ))
   QBEHCqUgnGPYapWFXeMoRNrLvlzhum=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.Load_List_File(QBEHCqUgnGPYapWFXeMoRNrLvlzhmJ) 
   fp=QBEHCqUgnGPYapWFXeMoRNrLvlzhKf(QBEHCqUgnGPYapWFXeMoRNrLvlzhuA,'w',-1,'utf-8')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuK=urllib.parse.urlencode(QBEHCqUgnGPYapWFXeMoRNrLvlzhDc)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuK=QBEHCqUgnGPYapWFXeMoRNrLvlzhuK+'\n'
   fp.write(QBEHCqUgnGPYapWFXeMoRNrLvlzhuK)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhub=0
   for QBEHCqUgnGPYapWFXeMoRNrLvlzhud in QBEHCqUgnGPYapWFXeMoRNrLvlzhum:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhuO=QBEHCqUgnGPYapWFXeMoRNrLvlzhKI(urllib.parse.parse_qsl(QBEHCqUgnGPYapWFXeMoRNrLvlzhud))
    QBEHCqUgnGPYapWFXeMoRNrLvlzhuc=QBEHCqUgnGPYapWFXeMoRNrLvlzhDc.get('code').strip()
    QBEHCqUgnGPYapWFXeMoRNrLvlzhuj=QBEHCqUgnGPYapWFXeMoRNrLvlzhuO.get('code').strip()
    if QBEHCqUgnGPYapWFXeMoRNrLvlzhmJ=='vod' and QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_settings_direct_replay()==QBEHCqUgnGPYapWFXeMoRNrLvlzhKi:
     QBEHCqUgnGPYapWFXeMoRNrLvlzhuc=QBEHCqUgnGPYapWFXeMoRNrLvlzhDc.get('videoid').strip()
     QBEHCqUgnGPYapWFXeMoRNrLvlzhuj=QBEHCqUgnGPYapWFXeMoRNrLvlzhuO.get('videoid').strip()if QBEHCqUgnGPYapWFXeMoRNrLvlzhuj!=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy else '-'
    if QBEHCqUgnGPYapWFXeMoRNrLvlzhuc!=QBEHCqUgnGPYapWFXeMoRNrLvlzhuj:
     fp.write(QBEHCqUgnGPYapWFXeMoRNrLvlzhud)
     QBEHCqUgnGPYapWFXeMoRNrLvlzhub+=1
     if QBEHCqUgnGPYapWFXeMoRNrLvlzhub>=50:break
   fp.close()
  except:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
 def Delete_List_File(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,QBEHCqUgnGPYapWFXeMoRNrLvlzhui,skey='-'):
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhui=='ALL':
   try:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhuS=QBEHCqUgnGPYapWFXeMoRNrLvlzhDK
    fp=QBEHCqUgnGPYapWFXeMoRNrLvlzhKf(QBEHCqUgnGPYapWFXeMoRNrLvlzhuS,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhui=='ONE':
   try:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhuS=QBEHCqUgnGPYapWFXeMoRNrLvlzhDK
    QBEHCqUgnGPYapWFXeMoRNrLvlzhum=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.Load_List_File('search') 
    fp=QBEHCqUgnGPYapWFXeMoRNrLvlzhKf(QBEHCqUgnGPYapWFXeMoRNrLvlzhuS,'w',-1,'utf-8')
    for QBEHCqUgnGPYapWFXeMoRNrLvlzhud in QBEHCqUgnGPYapWFXeMoRNrLvlzhum:
     QBEHCqUgnGPYapWFXeMoRNrLvlzhuO=QBEHCqUgnGPYapWFXeMoRNrLvlzhKI(urllib.parse.parse_qsl(QBEHCqUgnGPYapWFXeMoRNrLvlzhud))
     QBEHCqUgnGPYapWFXeMoRNrLvlzhuy=QBEHCqUgnGPYapWFXeMoRNrLvlzhuO.get('skey').strip()
     if skey!=QBEHCqUgnGPYapWFXeMoRNrLvlzhuy:
      fp.write(QBEHCqUgnGPYapWFXeMoRNrLvlzhud)
    fp.close()
   except:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhui in['vod','movie']:
   try:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhuS=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%QBEHCqUgnGPYapWFXeMoRNrLvlzhui))
    fp=QBEHCqUgnGPYapWFXeMoRNrLvlzhKf(QBEHCqUgnGPYapWFXeMoRNrLvlzhuS,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
 def dp_Listfile_Delete(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhui=args.get('sType')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkd =args.get('skey')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDy=xbmcgui.Dialog()
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhui=='ALL':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuV=QBEHCqUgnGPYapWFXeMoRNrLvlzhDy.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhui=='ONE':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuV=QBEHCqUgnGPYapWFXeMoRNrLvlzhDy.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhui in['vod','movie']:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuV=QBEHCqUgnGPYapWFXeMoRNrLvlzhDy.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhuV==QBEHCqUgnGPYapWFXeMoRNrLvlzhKV:sys.exit()
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.Delete_List_File(QBEHCqUgnGPYapWFXeMoRNrLvlzhui,skey=QBEHCqUgnGPYapWFXeMoRNrLvlzhkd)
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,QBEHCqUgnGPYapWFXeMoRNrLvlzhSI):
  try:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhus=QBEHCqUgnGPYapWFXeMoRNrLvlzhDK
   QBEHCqUgnGPYapWFXeMoRNrLvlzhum=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.Load_List_File('search') 
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuw={'skey':QBEHCqUgnGPYapWFXeMoRNrLvlzhSI.strip()}
   fp=QBEHCqUgnGPYapWFXeMoRNrLvlzhKf(QBEHCqUgnGPYapWFXeMoRNrLvlzhus,'w',-1,'utf-8')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuK=urllib.parse.urlencode(QBEHCqUgnGPYapWFXeMoRNrLvlzhuw)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuK=QBEHCqUgnGPYapWFXeMoRNrLvlzhuK+'\n'
   fp.write(QBEHCqUgnGPYapWFXeMoRNrLvlzhuK)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhub=0
   for QBEHCqUgnGPYapWFXeMoRNrLvlzhud in QBEHCqUgnGPYapWFXeMoRNrLvlzhum:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhuO=QBEHCqUgnGPYapWFXeMoRNrLvlzhKI(urllib.parse.parse_qsl(QBEHCqUgnGPYapWFXeMoRNrLvlzhud))
    QBEHCqUgnGPYapWFXeMoRNrLvlzhuc=QBEHCqUgnGPYapWFXeMoRNrLvlzhuw.get('skey').strip()
    QBEHCqUgnGPYapWFXeMoRNrLvlzhuj=QBEHCqUgnGPYapWFXeMoRNrLvlzhuO.get('skey').strip()
    if QBEHCqUgnGPYapWFXeMoRNrLvlzhuc!=QBEHCqUgnGPYapWFXeMoRNrLvlzhuj:
     fp.write(QBEHCqUgnGPYapWFXeMoRNrLvlzhud)
     QBEHCqUgnGPYapWFXeMoRNrLvlzhub+=1
     if QBEHCqUgnGPYapWFXeMoRNrLvlzhub>=50:break
   fp.close()
  except:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
 def dp_Global_Search(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=args.get('mode')
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='TOTAL_SEARCH':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuI='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuI='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(QBEHCqUgnGPYapWFXeMoRNrLvlzhuI)
 def dp_Bookmark_Menu(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhuI='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(QBEHCqUgnGPYapWFXeMoRNrLvlzhuI)
 def login_main(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  (QBEHCqUgnGPYapWFXeMoRNrLvlzhuT,QBEHCqUgnGPYapWFXeMoRNrLvlzhut,QBEHCqUgnGPYapWFXeMoRNrLvlzhux)=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_settings_login_info()
  if not(QBEHCqUgnGPYapWFXeMoRNrLvlzhuT and QBEHCqUgnGPYapWFXeMoRNrLvlzhut):
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDy=xbmcgui.Dialog()
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuV=QBEHCqUgnGPYapWFXeMoRNrLvlzhDy.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhuV==QBEHCqUgnGPYapWFXeMoRNrLvlzhKi:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winEpisodeOrderby()=='':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.set_winEpisodeOrderby('desc')
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.cookiefile_check():return
  QBEHCqUgnGPYapWFXeMoRNrLvlzhuf =QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  QBEHCqUgnGPYapWFXeMoRNrLvlzhuJ=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhuJ==QBEHCqUgnGPYapWFXeMoRNrLvlzhKy or QBEHCqUgnGPYapWFXeMoRNrLvlzhuJ=='':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuJ=QBEHCqUgnGPYapWFXeMoRNrLvlzhKs('19000101')
  else:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhuJ=QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(re.sub('-','',QBEHCqUgnGPYapWFXeMoRNrLvlzhuJ))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAD=0
   while QBEHCqUgnGPYapWFXeMoRNrLvlzhKi:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhAD+=1
    time.sleep(0.05)
    if QBEHCqUgnGPYapWFXeMoRNrLvlzhuJ>=QBEHCqUgnGPYapWFXeMoRNrLvlzhuf:return
    if QBEHCqUgnGPYapWFXeMoRNrLvlzhAD>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhuJ>=QBEHCqUgnGPYapWFXeMoRNrLvlzhuf:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.GetCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhuT,QBEHCqUgnGPYapWFXeMoRNrLvlzhut,QBEHCqUgnGPYapWFXeMoRNrLvlzhux):
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.set_winCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.LoadCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAS =args.get('orderby')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.set_winEpisodeOrderby(QBEHCqUgnGPYapWFXeMoRNrLvlzhAS)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSt =args.get('mode')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAk =args.get('contentid')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAu =args.get('pvrmode')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAm=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_selQuality()
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.addon_log(QBEHCqUgnGPYapWFXeMoRNrLvlzhAk+' - '+QBEHCqUgnGPYapWFXeMoRNrLvlzhSt)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='SPORTS':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAK,QBEHCqUgnGPYapWFXeMoRNrLvlzhAb=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.GetSportsURL(QBEHCqUgnGPYapWFXeMoRNrLvlzhAk,QBEHCqUgnGPYapWFXeMoRNrLvlzhAm)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAd =''
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAO=''
  else:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAK,QBEHCqUgnGPYapWFXeMoRNrLvlzhAb,QBEHCqUgnGPYapWFXeMoRNrLvlzhAd,QBEHCqUgnGPYapWFXeMoRNrLvlzhAO=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.GetStreamingURL(QBEHCqUgnGPYapWFXeMoRNrLvlzhSt,QBEHCqUgnGPYapWFXeMoRNrLvlzhAk,QBEHCqUgnGPYapWFXeMoRNrLvlzhAm,QBEHCqUgnGPYapWFXeMoRNrLvlzhAu)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAc='%s|Cookie=%s'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhAK,QBEHCqUgnGPYapWFXeMoRNrLvlzhAb)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.addon_log(QBEHCqUgnGPYapWFXeMoRNrLvlzhAc)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhAK=='':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.addon_noti(__language__(30907).encode('utf8'))
   return
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAj=xbmcgui.ListItem(path=QBEHCqUgnGPYapWFXeMoRNrLvlzhAc)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhAd:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.addon_log('!!streaming_drm!!')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAy=QBEHCqUgnGPYapWFXeMoRNrLvlzhAd['customdata']
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAi =QBEHCqUgnGPYapWFXeMoRNrLvlzhAd['drmhost']
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAV =inputstreamhelper.Helper('mpd',drm='widevine')
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhAV.check_inputstream():
    if QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='MOVIE':
     QBEHCqUgnGPYapWFXeMoRNrLvlzhAs='https://www.wavve.com/player/movie?movieid=%s'%QBEHCqUgnGPYapWFXeMoRNrLvlzhAk
    else:
     QBEHCqUgnGPYapWFXeMoRNrLvlzhAs='https://www.wavve.com/player/vod?programid=%s&page=1'%QBEHCqUgnGPYapWFXeMoRNrLvlzhAk
    QBEHCqUgnGPYapWFXeMoRNrLvlzhAw={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':QBEHCqUgnGPYapWFXeMoRNrLvlzhAy,'referer':QBEHCqUgnGPYapWFXeMoRNrLvlzhAs,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.USER_AGENT}
    QBEHCqUgnGPYapWFXeMoRNrLvlzhAI=QBEHCqUgnGPYapWFXeMoRNrLvlzhAi+'|'+urllib.parse.urlencode(QBEHCqUgnGPYapWFXeMoRNrLvlzhAw)+'|R{SSM}|'
    QBEHCqUgnGPYapWFXeMoRNrLvlzhAj.setProperty('inputstream',QBEHCqUgnGPYapWFXeMoRNrLvlzhAV.inputstream_addon)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhAj.setProperty('inputstream.adaptive.manifest_type','mpd')
    QBEHCqUgnGPYapWFXeMoRNrLvlzhAj.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    QBEHCqUgnGPYapWFXeMoRNrLvlzhAj.setProperty('inputstream.adaptive.license_key',QBEHCqUgnGPYapWFXeMoRNrLvlzhAI)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhAj.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.USER_AGENT,QBEHCqUgnGPYapWFXeMoRNrLvlzhAb))
  else:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAj.setContentLookup(QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAj.setMimeType('application/x-mpegURL')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAj.setProperty('inputstream','inputstream.ffmpegdirect')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAj.setProperty('inputstream.ffmpegdirect.mime_type','hls')
  xbmcplugin.setResolvedUrl(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,QBEHCqUgnGPYapWFXeMoRNrLvlzhAj)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAT=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhAO:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.addon_noti(QBEHCqUgnGPYapWFXeMoRNrLvlzhAO.encode('utf-8'))
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAT=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi
  else:
   if '/preview.' in urllib.parse.urlsplit(QBEHCqUgnGPYapWFXeMoRNrLvlzhAK).path:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.addon_noti(__language__(30908).encode('utf8'))
    QBEHCqUgnGPYapWFXeMoRNrLvlzhAT=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi
  try:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAt=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and QBEHCqUgnGPYapWFXeMoRNrLvlzhAT==QBEHCqUgnGPYapWFXeMoRNrLvlzhKV and QBEHCqUgnGPYapWFXeMoRNrLvlzhAt!='-':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'code':QBEHCqUgnGPYapWFXeMoRNrLvlzhAt,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.Save_Watched_List(args.get('mode').lower(),QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  except:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
 def logout(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDy=xbmcgui.Dialog()
  QBEHCqUgnGPYapWFXeMoRNrLvlzhuV=QBEHCqUgnGPYapWFXeMoRNrLvlzhDy.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhuV==QBEHCqUgnGPYapWFXeMoRNrLvlzhKV:sys.exit()
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.wininfo_clear()
  if os.path.isfile(QBEHCqUgnGPYapWFXeMoRNrLvlzhDm):os.remove(QBEHCqUgnGPYapWFXeMoRNrLvlzhDm)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK=xbmcgui.Window(10000)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK.setProperty('WAVVE_M_CREDENTIAL','')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAx =QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_Now_Datetime()
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAf=QBEHCqUgnGPYapWFXeMoRNrLvlzhAx+datetime.timedelta(days=QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(__addon__.getSetting('cache_ttl')))
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK=xbmcgui.Window(10000)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ={'wavve_token':QBEHCqUgnGPYapWFXeMoRNrLvlzhSK.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':QBEHCqUgnGPYapWFXeMoRNrLvlzhAf.strftime('%Y-%m-%d')}
  try: 
   fp=QBEHCqUgnGPYapWFXeMoRNrLvlzhKf(QBEHCqUgnGPYapWFXeMoRNrLvlzhDm,'w',-1,'utf-8')
   json.dump(QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ,fp)
   fp.close()
  except QBEHCqUgnGPYapWFXeMoRNrLvlzhKJ as exception:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhbD(exception)
 def cookiefile_check(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ={}
  try: 
   fp=QBEHCqUgnGPYapWFXeMoRNrLvlzhKf(QBEHCqUgnGPYapWFXeMoRNrLvlzhDm,'r',-1,'utf-8')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ= json.load(fp)
   fp.close()
  except QBEHCqUgnGPYapWFXeMoRNrLvlzhKJ as exception:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.wininfo_clear()
   return QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
  QBEHCqUgnGPYapWFXeMoRNrLvlzhuT =__addon__.getSetting('id')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhut =__addon__.getSetting('pw')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmD =__addon__.getSetting('selected_profile')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ['wavve_id']=base64.standard_b64decode(QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ['wavve_id']).decode('utf-8')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ['wavve_pw']=base64.standard_b64decode(QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ['wavve_pw']).decode('utf-8')
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhuT!=QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ['wavve_id']or QBEHCqUgnGPYapWFXeMoRNrLvlzhut!=QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ['wavve_pw']or QBEHCqUgnGPYapWFXeMoRNrLvlzhmD!=QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ['wavve_profile']:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.wininfo_clear()
   return QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
  QBEHCqUgnGPYapWFXeMoRNrLvlzhuf =QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmS=QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ['wavve_limitdate']
  QBEHCqUgnGPYapWFXeMoRNrLvlzhuJ =QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(re.sub('-','',QBEHCqUgnGPYapWFXeMoRNrLvlzhmS))
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhuJ<QBEHCqUgnGPYapWFXeMoRNrLvlzhuf:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.wininfo_clear()
   return QBEHCqUgnGPYapWFXeMoRNrLvlzhKV
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK=xbmcgui.Window(10000)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK.setProperty('WAVVE_M_CREDENTIAL',QBEHCqUgnGPYapWFXeMoRNrLvlzhAJ['wavve_token'])
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSK.setProperty('WAVVE_M_LOGINTIME',QBEHCqUgnGPYapWFXeMoRNrLvlzhmS)
  return QBEHCqUgnGPYapWFXeMoRNrLvlzhKi
 def dp_LiveCatagory_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmk =args.get('sCode')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmu=args.get('sIndex')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV,QBEHCqUgnGPYapWFXeMoRNrLvlzhmA=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_LiveCatagory_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhmk,QBEHCqUgnGPYapWFXeMoRNrLvlzhmu)
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('title')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'LIVE_LIST','genre':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('genre'),'baseapi':QBEHCqUgnGPYapWFXeMoRNrLvlzhmA}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img='',infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(QBEHCqUgnGPYapWFXeMoRNrLvlzhkV)>0:xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def dp_MainCatagory_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmk =args.get('sCode')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmu=args.get('sIndex')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSx =args.get('sType')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_MainCatagory_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhmk,QBEHCqUgnGPYapWFXeMoRNrLvlzhmu)
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhSx=='vod':
    if QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('subtype')=='catagory':
     QBEHCqUgnGPYapWFXeMoRNrLvlzhSt='PROGRAM_LIST'
    else:
     QBEHCqUgnGPYapWFXeMoRNrLvlzhSt='SUPERSECTION_LIST'
   elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSx=='movie':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSt='MOVIE_LIST'
   else:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=''
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='%s (%s)'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('title'),args.get('ordernm'))
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':QBEHCqUgnGPYapWFXeMoRNrLvlzhSt,'suburl':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('suburl'),'subapi':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_settings_exclusion21():
    if QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('title')=='성인' or QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('title')=='성인+':continue
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img='',infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(QBEHCqUgnGPYapWFXeMoRNrLvlzhkV)>0:xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def dp_Program_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmK =args.get('subapi')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhki=QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(args.get('page'))
  QBEHCqUgnGPYapWFXeMoRNrLvlzhAS =args.get('orderby')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV,QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_Program_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhmK,QBEHCqUgnGPYapWFXeMoRNrLvlzhki,QBEHCqUgnGPYapWFXeMoRNrLvlzhAS)
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('title')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkw=QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('thumbnail')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkI =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('age')
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhkI=='18' or QBEHCqUgnGPYapWFXeMoRNrLvlzhkI=='19' or QBEHCqUgnGPYapWFXeMoRNrLvlzhkI=='21':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd+=' (%s)'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhkI)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'plot':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'mpaa':QBEHCqUgnGPYapWFXeMoRNrLvlzhkI,'mediatype':'tvshow'}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'EPISODE_LIST','videoid':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('videoid'),'vidtype':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('vidtype'),'page':'1'}
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_settings_makebookmark():
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkT={'videoid':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('videoid'),'vidtype':'tvshow','vtitle':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'vsubtitle':'','contenttype':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('vidtype'),}
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkt=json.dumps(QBEHCqUgnGPYapWFXeMoRNrLvlzhkT)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkt=urllib.parse.quote(QBEHCqUgnGPYapWFXeMoRNrLvlzhkt)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkx='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhkt)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkj=[('(통합) 찜 영상에 추가',QBEHCqUgnGPYapWFXeMoRNrLvlzhkx)]
   else:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkj=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img=QBEHCqUgnGPYapWFXeMoRNrLvlzhkw,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy,ContextMenu=QBEHCqUgnGPYapWFXeMoRNrLvlzhkj)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['mode'] ='PROGRAM_LIST' 
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['subapi']=QBEHCqUgnGPYapWFXeMoRNrLvlzhmK 
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['page'] =QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='[B]%s >>[/B]'%'다음 페이지'
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkf=QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,img=QBEHCqUgnGPYapWFXeMoRNrLvlzhSj,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  xbmcplugin.setContent(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,'tvshows')
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(QBEHCqUgnGPYapWFXeMoRNrLvlzhkV)>0:xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def dp_SuperSection_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmb =args.get('suburl')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_SuperMultiSection_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhmb)
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('title')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhmK =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('subapi')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhmd=QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('cell_type')
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhmK.find('mtype=svod')>=0 or QBEHCqUgnGPYapWFXeMoRNrLvlzhmK.find('mtype=ppv')>=0:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSt='MOVIE_LIST'
   elif QBEHCqUgnGPYapWFXeMoRNrLvlzhmd=='band_71':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSt ='SUPERSECTION_LIST'
    (QBEHCqUgnGPYapWFXeMoRNrLvlzhmO,QBEHCqUgnGPYapWFXeMoRNrLvlzhmc)=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Baseapi_Parse(QBEHCqUgnGPYapWFXeMoRNrLvlzhmK)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhmb=QBEHCqUgnGPYapWFXeMoRNrLvlzhmc.get('api')
    QBEHCqUgnGPYapWFXeMoRNrLvlzhmK=''
   elif QBEHCqUgnGPYapWFXeMoRNrLvlzhmd=='band_2':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSt='BAND2SECTION_LIST'
   elif QBEHCqUgnGPYapWFXeMoRNrLvlzhmd=='band_live':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSt='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',QBEHCqUgnGPYapWFXeMoRNrLvlzhmK):
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSt='MOVIE_LIST'
   else:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSt='PROGRAM_LIST'
   QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'plot':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'mediatype':'tvshow'}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':QBEHCqUgnGPYapWFXeMoRNrLvlzhSt,'suburl':QBEHCqUgnGPYapWFXeMoRNrLvlzhmb,'subapi':QBEHCqUgnGPYapWFXeMoRNrLvlzhmK,'page':'1'}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(QBEHCqUgnGPYapWFXeMoRNrLvlzhkV)>0:xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def dp_BandLiveSection_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmK =args.get('subapi')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhki=QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(args.get('page'))
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV,QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_BandLiveSection_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhmK,QBEHCqUgnGPYapWFXeMoRNrLvlzhki)
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhmj =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('channelid')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhmy =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('studio')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhmi=QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('tvshowtitle')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkw =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('thumbnail')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkI =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('age')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'mediatype':'tvshow','mpaa':QBEHCqUgnGPYapWFXeMoRNrLvlzhkI,'title':'%s < %s >'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhmy,QBEHCqUgnGPYapWFXeMoRNrLvlzhmi),'tvshowtitle':QBEHCqUgnGPYapWFXeMoRNrLvlzhmi,'studio':QBEHCqUgnGPYapWFXeMoRNrLvlzhmy,'plot':QBEHCqUgnGPYapWFXeMoRNrLvlzhmy}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'LIVE','contentid':QBEHCqUgnGPYapWFXeMoRNrLvlzhmj}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhmy,sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhmi,img=QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('thumbnail'),infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['mode'] ='BANDLIVESECTION_LIST' 
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['subapi']=QBEHCqUgnGPYapWFXeMoRNrLvlzhmK
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['page'] =QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='[B]%s >>[/B]'%'다음 페이지'
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkf=QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,img=QBEHCqUgnGPYapWFXeMoRNrLvlzhSj,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(QBEHCqUgnGPYapWFXeMoRNrLvlzhkV)>0:xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def dp_Band2Section_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmK =args.get('subapi')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhki=QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(args.get('page'))
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV,QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_Band2Section_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhmK,QBEHCqUgnGPYapWFXeMoRNrLvlzhki)
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('programtitle')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkf =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('episodetitle')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'plot':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd+'\n\n'+QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,'mpaa':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('age'),'mediatype':'episode'}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'VOD','programid':'-','contentid':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('videoid'),'thumbnail':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('thumbnail'),'title':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'subtitle':QBEHCqUgnGPYapWFXeMoRNrLvlzhkf}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,img=QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('thumbnail'),infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['mode'] ='BAND2SECTION_LIST' 
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['subapi']=QBEHCqUgnGPYapWFXeMoRNrLvlzhmK
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['page'] =QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='[B]%s >>[/B]'%'다음 페이지'
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkf=QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,img=QBEHCqUgnGPYapWFXeMoRNrLvlzhSj,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(QBEHCqUgnGPYapWFXeMoRNrLvlzhkV)>0:xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def dp_Movie_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmK =args.get('subapi')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhki=QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(args.get('page'))
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV,QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_Movie_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhmK,QBEHCqUgnGPYapWFXeMoRNrLvlzhki)
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('title')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkw=QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('thumbnail')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkI =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('age')
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhkI=='18' or QBEHCqUgnGPYapWFXeMoRNrLvlzhkI=='19' or QBEHCqUgnGPYapWFXeMoRNrLvlzhkI=='21':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd+=' (%s)'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhkI)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'plot':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'mpaa':QBEHCqUgnGPYapWFXeMoRNrLvlzhkI,'mediatype':'movie'}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'MOVIE','contentid':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('videoid'),'title':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'thumbnail':QBEHCqUgnGPYapWFXeMoRNrLvlzhkw,'age':QBEHCqUgnGPYapWFXeMoRNrLvlzhkI}
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_settings_makebookmark():
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkT={'videoid':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('videoid'),'vidtype':'movie','vtitle':QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,'vsubtitle':'','contenttype':'programid',}
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkt=json.dumps(QBEHCqUgnGPYapWFXeMoRNrLvlzhkT)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkt=urllib.parse.quote(QBEHCqUgnGPYapWFXeMoRNrLvlzhkt)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkx='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhkt)
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkj=[('(통합) 찜 영상에 추가',QBEHCqUgnGPYapWFXeMoRNrLvlzhkx)]
   else:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkj=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img=QBEHCqUgnGPYapWFXeMoRNrLvlzhkw,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy,ContextMenu=QBEHCqUgnGPYapWFXeMoRNrLvlzhkj)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['mode'] ='MOVIE_LIST' 
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['subapi']=QBEHCqUgnGPYapWFXeMoRNrLvlzhmK 
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['page'] =QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='[B]%s >>[/B]'%'다음 페이지'
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkf=QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,img=QBEHCqUgnGPYapWFXeMoRNrLvlzhSj,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  xbmcplugin.setContent(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,'movies')
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(QBEHCqUgnGPYapWFXeMoRNrLvlzhkV)>0:xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def dp_Set_Bookmark(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmV=urllib.parse.unquote(args.get('bm_param'))
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmV=json.loads(QBEHCqUgnGPYapWFXeMoRNrLvlzhmV)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhuD =QBEHCqUgnGPYapWFXeMoRNrLvlzhmV.get('videoid')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhms =QBEHCqUgnGPYapWFXeMoRNrLvlzhmV.get('vidtype')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmw =QBEHCqUgnGPYapWFXeMoRNrLvlzhmV.get('vtitle')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmI =QBEHCqUgnGPYapWFXeMoRNrLvlzhmV.get('vsubtitle')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmT=QBEHCqUgnGPYapWFXeMoRNrLvlzhmV.get('contenttype')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDy=xbmcgui.Dialog()
  QBEHCqUgnGPYapWFXeMoRNrLvlzhuV=QBEHCqUgnGPYapWFXeMoRNrLvlzhDy.yesno(__language__(30913).encode('utf8'),QBEHCqUgnGPYapWFXeMoRNrLvlzhmw+' \n\n'+__language__(30914))
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhuV==QBEHCqUgnGPYapWFXeMoRNrLvlzhKV:return
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmt=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.GetBookmarkInfo(QBEHCqUgnGPYapWFXeMoRNrLvlzhuD,QBEHCqUgnGPYapWFXeMoRNrLvlzhms,QBEHCqUgnGPYapWFXeMoRNrLvlzhmT)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmx=json.dumps(QBEHCqUgnGPYapWFXeMoRNrLvlzhmt)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmx=urllib.parse.quote(QBEHCqUgnGPYapWFXeMoRNrLvlzhmx)
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkx ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhmx)
  xbmc.executebuiltin(QBEHCqUgnGPYapWFXeMoRNrLvlzhkx)
 def dp_Episode_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhuD =args.get('videoid')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhms =args.get('vidtype')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhki=QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(args.get('page'))
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV,QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_Episode_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhuD,QBEHCqUgnGPYapWFXeMoRNrLvlzhms,QBEHCqUgnGPYapWFXeMoRNrLvlzhki,orderby=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winEpisodeOrderby())
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkf='%s회, %s(%s)'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('episodenumber'),QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('releasedate'),QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('releaseweekday'))
   QBEHCqUgnGPYapWFXeMoRNrLvlzhmf ='[%s]\n\n%s'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('episodetitle'),QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('synopsis'))
   QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'mediatype':'episode','title':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('programtitle'),'year':QBEHCqUgnGPYapWFXeMoRNrLvlzhKs(QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('releasedate')[:4]),'aired':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('releasedate'),'mpaa':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('age'),'episode':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('episodenumber'),'duration':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('playtime'),'plot':QBEHCqUgnGPYapWFXeMoRNrLvlzhmf,'cast':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('episodeactors')}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'VOD','programid':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('programid'),'contentid':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('contentid'),'thumbnail':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('thumbnail'),'title':QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('programtitle'),'subtitle':QBEHCqUgnGPYapWFXeMoRNrLvlzhkf}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('programtitle'),sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,img=QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('thumbnail'),infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhki==1:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'plot':'정렬순서를 변경합니다.'}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['mode'] ='ORDER_BY' 
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winEpisodeOrderby()=='desc':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='정렬순서변경 : 최신화부터 -> 1회부터'
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['orderby']='asc'
   else:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='정렬순서변경 : 1회부터 -> 최신화부터'
    QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['orderby']='desc'
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel='',img=QBEHCqUgnGPYapWFXeMoRNrLvlzhSj,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy,isLink=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSJ:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['mode'] ='EPISODE_LIST' 
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['videoid']=QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('programid')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['vidtype']='programid'
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy['page'] =QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSd='[B]%s >>[/B]'%'다음 페이지'
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkf=QBEHCqUgnGPYapWFXeMoRNrLvlzhKx(QBEHCqUgnGPYapWFXeMoRNrLvlzhki+1)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhSd,sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,img=QBEHCqUgnGPYapWFXeMoRNrLvlzhSj,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhKy,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKi,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  xbmcplugin.setContent(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,'episodes')
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(QBEHCqUgnGPYapWFXeMoRNrLvlzhkV)>0:xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def dp_LiveChannel_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmJ =args.get('genre')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhmA=args.get('baseapi')
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_LiveChannel_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhmJ,QBEHCqUgnGPYapWFXeMoRNrLvlzhmA)
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhmj =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('channelid')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhmy =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('studio')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhmi=QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('tvshowtitle')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkw =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('thumbnail')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhkI =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('age')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKD =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('epg')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'mediatype':'episode','mpaa':QBEHCqUgnGPYapWFXeMoRNrLvlzhkI,'title':'%s < %s >'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhmy,QBEHCqUgnGPYapWFXeMoRNrLvlzhmi),'tvshowtitle':QBEHCqUgnGPYapWFXeMoRNrLvlzhmi,'studio':QBEHCqUgnGPYapWFXeMoRNrLvlzhmy,'plot':'%s\n\n%s'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhmy,QBEHCqUgnGPYapWFXeMoRNrLvlzhKD)}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'LIVE','contentid':QBEHCqUgnGPYapWFXeMoRNrLvlzhmj}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhmy,sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhmi,img=QBEHCqUgnGPYapWFXeMoRNrLvlzhkw,infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhKT(QBEHCqUgnGPYapWFXeMoRNrLvlzhkV)>0:xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def dp_Sports_GameList(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb,args):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.SaveCredential(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.get_winCredential())
  QBEHCqUgnGPYapWFXeMoRNrLvlzhkV=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.WavveObj.Get_Sports_Gamelist()
  for QBEHCqUgnGPYapWFXeMoRNrLvlzhks in QBEHCqUgnGPYapWFXeMoRNrLvlzhkV:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKS =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('game_date')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKk =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('game_time')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKu =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('svc_id')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKA =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('away_team')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKm =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('home_team')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKb=QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('game_status')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKd =QBEHCqUgnGPYapWFXeMoRNrLvlzhks.get('game_place')
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKO ='%s vs %s (%s)'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhKA,QBEHCqUgnGPYapWFXeMoRNrLvlzhKm,QBEHCqUgnGPYapWFXeMoRNrLvlzhKd)
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKc =QBEHCqUgnGPYapWFXeMoRNrLvlzhKS+' '+QBEHCqUgnGPYapWFXeMoRNrLvlzhKk
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhKb=='LIVE':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhKb='~경기중~'
   elif QBEHCqUgnGPYapWFXeMoRNrLvlzhKb=='END':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhKb='경기종료'
   elif QBEHCqUgnGPYapWFXeMoRNrLvlzhKb=='CANCEL':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhKb='취소'
   else:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhKb=''
   if QBEHCqUgnGPYapWFXeMoRNrLvlzhKb=='':
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkf=QBEHCqUgnGPYapWFXeMoRNrLvlzhKO
   else:
    QBEHCqUgnGPYapWFXeMoRNrLvlzhkf=QBEHCqUgnGPYapWFXeMoRNrLvlzhKO+'  '+QBEHCqUgnGPYapWFXeMoRNrLvlzhKb
   QBEHCqUgnGPYapWFXeMoRNrLvlzhky={'mediatype':'episode','title':QBEHCqUgnGPYapWFXeMoRNrLvlzhKO,'plot':'%s\n\n%s\n\n%s'%(QBEHCqUgnGPYapWFXeMoRNrLvlzhKc,QBEHCqUgnGPYapWFXeMoRNrLvlzhKO,QBEHCqUgnGPYapWFXeMoRNrLvlzhKb)}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhSy={'mode':'SPORTS','contentid':QBEHCqUgnGPYapWFXeMoRNrLvlzhKu}
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.add_dir(QBEHCqUgnGPYapWFXeMoRNrLvlzhKc,sublabel=QBEHCqUgnGPYapWFXeMoRNrLvlzhkf,img='',infoLabels=QBEHCqUgnGPYapWFXeMoRNrLvlzhky,isFolder=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV,params=QBEHCqUgnGPYapWFXeMoRNrLvlzhSy)
  xbmcplugin.endOfDirectory(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb._addon_handle,cacheToDisc=QBEHCqUgnGPYapWFXeMoRNrLvlzhKV)
 def wavve_main(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb):
  QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params.get('mode',QBEHCqUgnGPYapWFXeMoRNrLvlzhKy)
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='LOGOUT':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.logout()
   return
  QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.login_main()
  if QBEHCqUgnGPYapWFXeMoRNrLvlzhSt is QBEHCqUgnGPYapWFXeMoRNrLvlzhKy:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Main_List()
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt in['LIVE','VOD','MOVIE','SPORTS']:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.play_VIDEO(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='LIVE_CATAGORY':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_LiveCatagory_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='MAIN_CATAGORY':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_MainCatagory_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='SUPERSECTION_LIST':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_SuperSection_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='BANDLIVESECTION_LIST':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_BandLiveSection_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='BAND2SECTION_LIST':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Band2Section_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='PROGRAM_LIST':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Program_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='EPISODE_LIST':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Episode_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='MOVIE_LIST':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Movie_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='LIVE_LIST':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_LiveChannel_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='ORDER_BY':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_setEpOrderby(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='SEARCH_GROUP':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Search_Group(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt in['SEARCH_LIST','LOCAL_SEARCH']:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Search_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='WATCH_GROUP':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Watch_Group(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='WATCH_LIST':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Watch_List(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='SET_BOOKMARK':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Set_Bookmark(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Listfile_Delete(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt in['TOTAL_SEARCH','TOTAL_HISTORY']:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Global_Search(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='SEARCH_HISTORY':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Search_History(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='MENU_BOOKMARK':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Bookmark_Menu(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  elif QBEHCqUgnGPYapWFXeMoRNrLvlzhSt=='GAME_LIST':
   QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.dp_Sports_GameList(QBEHCqUgnGPYapWFXeMoRNrLvlzhDb.main_params)
  else:
   QBEHCqUgnGPYapWFXeMoRNrLvlzhKy
# Created by pyminifier (https://github.com/liftoff/pyminifier)
