__author__="NightRain"
VlwdpByTFLCRExivHoWfamshutIMkz=object
VlwdpByTFLCRExivHoWfamshutIMke=None
VlwdpByTFLCRExivHoWfamshutIMkQ=int
VlwdpByTFLCRExivHoWfamshutIMkD=False
VlwdpByTFLCRExivHoWfamshutIMkg=True
VlwdpByTFLCRExivHoWfamshutIMkU=len
VlwdpByTFLCRExivHoWfamshutIMkc=open
VlwdpByTFLCRExivHoWfamshutIMkN=dict
VlwdpByTFLCRExivHoWfamshutIMkS=Exception
VlwdpByTFLCRExivHoWfamshutIMjn=print
VlwdpByTFLCRExivHoWfamshutIMjq=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
VlwdpByTFLCRExivHoWfamshutIMnY=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1'},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1'},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순'},{'title':'-----------------','mode':'XXX'},{'title':'검색 (search)','mode':'SEARCH_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP'}]
VlwdpByTFLCRExivHoWfamshutIMnO=[{'title':'VOD 검색','mode':'SEARCH_LIST','sType':'vod'},{'title':'영화 검색','mode':'SEARCH_LIST','sType':'movie'}]
VlwdpByTFLCRExivHoWfamshutIMnk=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
VlwdpByTFLCRExivHoWfamshutIMnj='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
VlwdpByTFLCRExivHoWfamshutIMnb=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class VlwdpByTFLCRExivHoWfamshutIMnq(VlwdpByTFLCRExivHoWfamshutIMkz):
 def __init__(VlwdpByTFLCRExivHoWfamshutIMnr,VlwdpByTFLCRExivHoWfamshutIMnJ,VlwdpByTFLCRExivHoWfamshutIMnP,VlwdpByTFLCRExivHoWfamshutIMnX):
  VlwdpByTFLCRExivHoWfamshutIMnr._addon_url =VlwdpByTFLCRExivHoWfamshutIMnJ
  VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle=VlwdpByTFLCRExivHoWfamshutIMnP
  VlwdpByTFLCRExivHoWfamshutIMnr.main_params =VlwdpByTFLCRExivHoWfamshutIMnX
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj =IfrqlKMRdpUzbAtvgeDXwOjYkCFyuL() 
 def addon_noti(VlwdpByTFLCRExivHoWfamshutIMnr,sting):
  try:
   VlwdpByTFLCRExivHoWfamshutIMnG=xbmcgui.Dialog()
   VlwdpByTFLCRExivHoWfamshutIMnG.notification(__addonname__,sting)
  except:
   VlwdpByTFLCRExivHoWfamshutIMke
 def addon_log(VlwdpByTFLCRExivHoWfamshutIMnr,string):
  try:
   VlwdpByTFLCRExivHoWfamshutIMnK=string.encode('utf-8','ignore')
  except:
   VlwdpByTFLCRExivHoWfamshutIMnK='addonException: addon_log'
  VlwdpByTFLCRExivHoWfamshutIMnz=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,VlwdpByTFLCRExivHoWfamshutIMnK),level=VlwdpByTFLCRExivHoWfamshutIMnz)
 def get_keyboard_input(VlwdpByTFLCRExivHoWfamshutIMnr,VlwdpByTFLCRExivHoWfamshutIMqk):
  VlwdpByTFLCRExivHoWfamshutIMne=VlwdpByTFLCRExivHoWfamshutIMke
  kb=xbmc.Keyboard()
  kb.setHeading(VlwdpByTFLCRExivHoWfamshutIMqk)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   VlwdpByTFLCRExivHoWfamshutIMne=kb.getText()
  return VlwdpByTFLCRExivHoWfamshutIMne
 def get_settings_login_info(VlwdpByTFLCRExivHoWfamshutIMnr):
  VlwdpByTFLCRExivHoWfamshutIMnQ =__addon__.getSetting('id')
  VlwdpByTFLCRExivHoWfamshutIMnD =__addon__.getSetting('pw')
  VlwdpByTFLCRExivHoWfamshutIMng=__addon__.getSetting('selected_profile')
  return(VlwdpByTFLCRExivHoWfamshutIMnQ,VlwdpByTFLCRExivHoWfamshutIMnD,VlwdpByTFLCRExivHoWfamshutIMng)
 def get_selQuality(VlwdpByTFLCRExivHoWfamshutIMnr):
  try:
   VlwdpByTFLCRExivHoWfamshutIMnU=[1080,720,480,360]
   VlwdpByTFLCRExivHoWfamshutIMnc=VlwdpByTFLCRExivHoWfamshutIMkQ(__addon__.getSetting('selected_quality'))
   return VlwdpByTFLCRExivHoWfamshutIMnU[VlwdpByTFLCRExivHoWfamshutIMnc]
  except:
   VlwdpByTFLCRExivHoWfamshutIMke
  return 1080 
 def get_settings_exclusion21(VlwdpByTFLCRExivHoWfamshutIMnr):
  VlwdpByTFLCRExivHoWfamshutIMnN =__addon__.getSetting('exclusion21')
  if VlwdpByTFLCRExivHoWfamshutIMnN=='false':
   return VlwdpByTFLCRExivHoWfamshutIMkD
  else:
   return VlwdpByTFLCRExivHoWfamshutIMkg
 def get_settings_direct_replay(VlwdpByTFLCRExivHoWfamshutIMnr):
  VlwdpByTFLCRExivHoWfamshutIMnS=VlwdpByTFLCRExivHoWfamshutIMkQ(__addon__.getSetting('direct_replay'))
  if VlwdpByTFLCRExivHoWfamshutIMnS==0:
   return VlwdpByTFLCRExivHoWfamshutIMkD
  else:
   return VlwdpByTFLCRExivHoWfamshutIMkg
 def get_settings_addinfo(VlwdpByTFLCRExivHoWfamshutIMnr):
  VlwdpByTFLCRExivHoWfamshutIMqn =__addon__.getSetting('add_infoyn')
  if VlwdpByTFLCRExivHoWfamshutIMqn=='false':
   return VlwdpByTFLCRExivHoWfamshutIMkD
  else:
   return VlwdpByTFLCRExivHoWfamshutIMkg
 def set_winCredential(VlwdpByTFLCRExivHoWfamshutIMnr,credential):
  VlwdpByTFLCRExivHoWfamshutIMqY=xbmcgui.Window(10000)
  VlwdpByTFLCRExivHoWfamshutIMqY.setProperty('WAVVE_M_CREDENTIAL',credential)
  VlwdpByTFLCRExivHoWfamshutIMqY.setProperty('WAVVE_M_LOGINTIME',VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(VlwdpByTFLCRExivHoWfamshutIMnr):
  VlwdpByTFLCRExivHoWfamshutIMqY=xbmcgui.Window(10000)
  return VlwdpByTFLCRExivHoWfamshutIMqY.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(VlwdpByTFLCRExivHoWfamshutIMnr,VlwdpByTFLCRExivHoWfamshutIMqU):
  VlwdpByTFLCRExivHoWfamshutIMqY=xbmcgui.Window(10000)
  VlwdpByTFLCRExivHoWfamshutIMqY.setProperty('WAVVE_M_ORDERBY',VlwdpByTFLCRExivHoWfamshutIMqU)
 def get_winEpisodeOrderby(VlwdpByTFLCRExivHoWfamshutIMnr):
  VlwdpByTFLCRExivHoWfamshutIMqY=xbmcgui.Window(10000)
  return VlwdpByTFLCRExivHoWfamshutIMqY.getProperty('WAVVE_M_ORDERBY')
 def add_dir(VlwdpByTFLCRExivHoWfamshutIMnr,VlwdpByTFLCRExivHoWfamshutIMkP,sublabel='',img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=''):
  VlwdpByTFLCRExivHoWfamshutIMqO='%s?%s'%(VlwdpByTFLCRExivHoWfamshutIMnr._addon_url,urllib.parse.urlencode(params))
  if sublabel:VlwdpByTFLCRExivHoWfamshutIMqk='%s < %s >'%(VlwdpByTFLCRExivHoWfamshutIMkP,sublabel)
  else: VlwdpByTFLCRExivHoWfamshutIMqk=VlwdpByTFLCRExivHoWfamshutIMkP
  if not img:img='DefaultFolder.png'
  VlwdpByTFLCRExivHoWfamshutIMqj=xbmcgui.ListItem(VlwdpByTFLCRExivHoWfamshutIMqk)
  VlwdpByTFLCRExivHoWfamshutIMqj.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:VlwdpByTFLCRExivHoWfamshutIMqj.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:VlwdpByTFLCRExivHoWfamshutIMqj.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,VlwdpByTFLCRExivHoWfamshutIMqO,VlwdpByTFLCRExivHoWfamshutIMqj,isFolder)
 def dp_Main_List(VlwdpByTFLCRExivHoWfamshutIMnr):
  for VlwdpByTFLCRExivHoWfamshutIMqb in VlwdpByTFLCRExivHoWfamshutIMnY:
   VlwdpByTFLCRExivHoWfamshutIMqk=VlwdpByTFLCRExivHoWfamshutIMqb.get('title')
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':VlwdpByTFLCRExivHoWfamshutIMqb.get('mode'),'sCode':VlwdpByTFLCRExivHoWfamshutIMqb.get('sCode'),'sIndex':VlwdpByTFLCRExivHoWfamshutIMqb.get('sIndex'),'sType':VlwdpByTFLCRExivHoWfamshutIMqb.get('sType'),'subapi':VlwdpByTFLCRExivHoWfamshutIMqb.get('subapi'),'page':VlwdpByTFLCRExivHoWfamshutIMqb.get('page'),'orderby':VlwdpByTFLCRExivHoWfamshutIMqb.get('orderby'),'ordernm':VlwdpByTFLCRExivHoWfamshutIMqb.get('ordernm')}
   if VlwdpByTFLCRExivHoWfamshutIMqb.get('mode')=='XXX':
    VlwdpByTFLCRExivHoWfamshutIMqJ=VlwdpByTFLCRExivHoWfamshutIMkD
   else:
    VlwdpByTFLCRExivHoWfamshutIMqJ=VlwdpByTFLCRExivHoWfamshutIMkg
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel='',img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMqJ,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMnY)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkg)
 def dp_Search_Group(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  for VlwdpByTFLCRExivHoWfamshutIMqX in VlwdpByTFLCRExivHoWfamshutIMnO:
   VlwdpByTFLCRExivHoWfamshutIMqk=VlwdpByTFLCRExivHoWfamshutIMqX.get('title')
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':VlwdpByTFLCRExivHoWfamshutIMqX.get('mode'),'sType':VlwdpByTFLCRExivHoWfamshutIMqX.get('sType'),'page':'1'}
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel='',img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMnO)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkg)
 def dp_Watch_Group(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  for VlwdpByTFLCRExivHoWfamshutIMqA in VlwdpByTFLCRExivHoWfamshutIMnk:
   VlwdpByTFLCRExivHoWfamshutIMqk=VlwdpByTFLCRExivHoWfamshutIMqA.get('title')
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':VlwdpByTFLCRExivHoWfamshutIMqA.get('mode'),'sType':VlwdpByTFLCRExivHoWfamshutIMqA.get('sType')}
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel='',img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMnk)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkg)
 def login_main(VlwdpByTFLCRExivHoWfamshutIMnr):
  (VlwdpByTFLCRExivHoWfamshutIMqG,VlwdpByTFLCRExivHoWfamshutIMqK,VlwdpByTFLCRExivHoWfamshutIMqz)=VlwdpByTFLCRExivHoWfamshutIMnr.get_settings_login_info()
  if not(VlwdpByTFLCRExivHoWfamshutIMqG and VlwdpByTFLCRExivHoWfamshutIMqK):
   VlwdpByTFLCRExivHoWfamshutIMnG=xbmcgui.Dialog()
   VlwdpByTFLCRExivHoWfamshutIMqe=VlwdpByTFLCRExivHoWfamshutIMnG.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if VlwdpByTFLCRExivHoWfamshutIMqe==VlwdpByTFLCRExivHoWfamshutIMkg:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if VlwdpByTFLCRExivHoWfamshutIMnr.get_winEpisodeOrderby()=='':
   VlwdpByTFLCRExivHoWfamshutIMnr.set_winEpisodeOrderby('desc')
  if VlwdpByTFLCRExivHoWfamshutIMnr.cookiefile_check():return
  VlwdpByTFLCRExivHoWfamshutIMqQ =VlwdpByTFLCRExivHoWfamshutIMkQ(VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  VlwdpByTFLCRExivHoWfamshutIMqD=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if VlwdpByTFLCRExivHoWfamshutIMqD==VlwdpByTFLCRExivHoWfamshutIMke or VlwdpByTFLCRExivHoWfamshutIMqD=='':
   VlwdpByTFLCRExivHoWfamshutIMqD=VlwdpByTFLCRExivHoWfamshutIMkQ('19000101')
  else:
   VlwdpByTFLCRExivHoWfamshutIMqD=VlwdpByTFLCRExivHoWfamshutIMkQ(re.sub('-','',VlwdpByTFLCRExivHoWfamshutIMqD))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   VlwdpByTFLCRExivHoWfamshutIMqg=0
   while VlwdpByTFLCRExivHoWfamshutIMkg:
    VlwdpByTFLCRExivHoWfamshutIMqg+=1
    time.sleep(0.05)
    if VlwdpByTFLCRExivHoWfamshutIMqD>=VlwdpByTFLCRExivHoWfamshutIMqQ:return
    if VlwdpByTFLCRExivHoWfamshutIMqg>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if VlwdpByTFLCRExivHoWfamshutIMqD>=VlwdpByTFLCRExivHoWfamshutIMqQ:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.GetCredential(VlwdpByTFLCRExivHoWfamshutIMqG,VlwdpByTFLCRExivHoWfamshutIMqK,VlwdpByTFLCRExivHoWfamshutIMqz):
   VlwdpByTFLCRExivHoWfamshutIMnr.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  VlwdpByTFLCRExivHoWfamshutIMnr.set_winCredential(VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.LoadCredential())
  VlwdpByTFLCRExivHoWfamshutIMnr.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMqU =args.get('orderby')
  VlwdpByTFLCRExivHoWfamshutIMnr.set_winEpisodeOrderby(VlwdpByTFLCRExivHoWfamshutIMqU)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.SaveCredential(VlwdpByTFLCRExivHoWfamshutIMnr.get_winCredential())
  VlwdpByTFLCRExivHoWfamshutIMqc =args.get('mode')
  VlwdpByTFLCRExivHoWfamshutIMqN =args.get('contentid')
  VlwdpByTFLCRExivHoWfamshutIMqS =args.get('pvrmode')
  VlwdpByTFLCRExivHoWfamshutIMYn=VlwdpByTFLCRExivHoWfamshutIMnr.get_selQuality()
  VlwdpByTFLCRExivHoWfamshutIMnr.addon_log(VlwdpByTFLCRExivHoWfamshutIMqN+' - '+VlwdpByTFLCRExivHoWfamshutIMqc)
  VlwdpByTFLCRExivHoWfamshutIMYq,VlwdpByTFLCRExivHoWfamshutIMYO,VlwdpByTFLCRExivHoWfamshutIMYk,VlwdpByTFLCRExivHoWfamshutIMYj=VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.GetStreamingURL(VlwdpByTFLCRExivHoWfamshutIMqc,VlwdpByTFLCRExivHoWfamshutIMqN,VlwdpByTFLCRExivHoWfamshutIMYn,VlwdpByTFLCRExivHoWfamshutIMqS)
  VlwdpByTFLCRExivHoWfamshutIMYb='%s|Cookie=%s'%(VlwdpByTFLCRExivHoWfamshutIMYq,VlwdpByTFLCRExivHoWfamshutIMYO)
  VlwdpByTFLCRExivHoWfamshutIMnr.addon_log(VlwdpByTFLCRExivHoWfamshutIMYb)
  if VlwdpByTFLCRExivHoWfamshutIMYq=='':
   VlwdpByTFLCRExivHoWfamshutIMnr.addon_noti(__language__(30907).encode('utf8'))
   return
  VlwdpByTFLCRExivHoWfamshutIMYr=xbmcgui.ListItem(path=VlwdpByTFLCRExivHoWfamshutIMYb)
  if VlwdpByTFLCRExivHoWfamshutIMYk:
   VlwdpByTFLCRExivHoWfamshutIMnr.addon_log('!!streaming_drm!!')
   VlwdpByTFLCRExivHoWfamshutIMYJ=VlwdpByTFLCRExivHoWfamshutIMYk['customdata']
   VlwdpByTFLCRExivHoWfamshutIMYP =VlwdpByTFLCRExivHoWfamshutIMYk['drmhost']
   VlwdpByTFLCRExivHoWfamshutIMYX =inputstreamhelper.Helper('mpd',drm='widevine')
   if VlwdpByTFLCRExivHoWfamshutIMYX.check_inputstream():
    if VlwdpByTFLCRExivHoWfamshutIMqc=='MOVIE':
     VlwdpByTFLCRExivHoWfamshutIMYA='https://www.wavve.com/player/movie?movieid=%s'%VlwdpByTFLCRExivHoWfamshutIMqN
    else:
     VlwdpByTFLCRExivHoWfamshutIMYA='https://www.wavve.com/player/vod?programid=%s&page=1'%VlwdpByTFLCRExivHoWfamshutIMqN
    VlwdpByTFLCRExivHoWfamshutIMYG={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':VlwdpByTFLCRExivHoWfamshutIMYJ,'referer':VlwdpByTFLCRExivHoWfamshutIMYA,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':VlwdpByTFLCRExivHoWfamshutIMnj}
    VlwdpByTFLCRExivHoWfamshutIMYK=VlwdpByTFLCRExivHoWfamshutIMYP+'|'+urllib.parse.urlencode(VlwdpByTFLCRExivHoWfamshutIMYG)+'|R{SSM}|'
    VlwdpByTFLCRExivHoWfamshutIMYr.setProperty('inputstream',VlwdpByTFLCRExivHoWfamshutIMYX.inputstream_addon)
    VlwdpByTFLCRExivHoWfamshutIMYr.setProperty('inputstream.adaptive.manifest_type','mpd')
    VlwdpByTFLCRExivHoWfamshutIMYr.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    VlwdpByTFLCRExivHoWfamshutIMYr.setProperty('inputstream.adaptive.license_key',VlwdpByTFLCRExivHoWfamshutIMYK)
    VlwdpByTFLCRExivHoWfamshutIMYr.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(VlwdpByTFLCRExivHoWfamshutIMnj,VlwdpByTFLCRExivHoWfamshutIMYO))
  xbmcplugin.setResolvedUrl(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,VlwdpByTFLCRExivHoWfamshutIMkg,VlwdpByTFLCRExivHoWfamshutIMYr)
  VlwdpByTFLCRExivHoWfamshutIMYz=VlwdpByTFLCRExivHoWfamshutIMkD
  if VlwdpByTFLCRExivHoWfamshutIMYj:
   VlwdpByTFLCRExivHoWfamshutIMnr.addon_noti(VlwdpByTFLCRExivHoWfamshutIMYj.encode('utf-8'))
   VlwdpByTFLCRExivHoWfamshutIMYz=VlwdpByTFLCRExivHoWfamshutIMkg
  else:
   if '/preview.' in urllib.parse.urlsplit(VlwdpByTFLCRExivHoWfamshutIMYq).path:
    VlwdpByTFLCRExivHoWfamshutIMnr.addon_noti(__language__(30908).encode('utf8'))
    VlwdpByTFLCRExivHoWfamshutIMYz=VlwdpByTFLCRExivHoWfamshutIMkg
  try:
   VlwdpByTFLCRExivHoWfamshutIMYe=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and VlwdpByTFLCRExivHoWfamshutIMYz==VlwdpByTFLCRExivHoWfamshutIMkD and VlwdpByTFLCRExivHoWfamshutIMYe!='-':
    VlwdpByTFLCRExivHoWfamshutIMqr={'code':VlwdpByTFLCRExivHoWfamshutIMYe,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    VlwdpByTFLCRExivHoWfamshutIMnr.Save_Watched_List(args.get('mode').lower(),VlwdpByTFLCRExivHoWfamshutIMqr)
  except:
   VlwdpByTFLCRExivHoWfamshutIMke
 def Load_Watched_List(VlwdpByTFLCRExivHoWfamshutIMnr,VlwdpByTFLCRExivHoWfamshutIMkr):
  try:
   VlwdpByTFLCRExivHoWfamshutIMYQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VlwdpByTFLCRExivHoWfamshutIMkr))
   fp=VlwdpByTFLCRExivHoWfamshutIMkc(VlwdpByTFLCRExivHoWfamshutIMYQ,'r',-1,'utf-8')
   VlwdpByTFLCRExivHoWfamshutIMYD=fp.readlines()
   fp.close()
  except:
   VlwdpByTFLCRExivHoWfamshutIMYD=[]
  return VlwdpByTFLCRExivHoWfamshutIMYD
 def Save_Watched_List(VlwdpByTFLCRExivHoWfamshutIMnr,VlwdpByTFLCRExivHoWfamshutIMkr,VlwdpByTFLCRExivHoWfamshutIMnX):
  try:
   VlwdpByTFLCRExivHoWfamshutIMYQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VlwdpByTFLCRExivHoWfamshutIMkr))
   VlwdpByTFLCRExivHoWfamshutIMYg=VlwdpByTFLCRExivHoWfamshutIMnr.Load_Watched_List(VlwdpByTFLCRExivHoWfamshutIMkr) 
   fp=VlwdpByTFLCRExivHoWfamshutIMkc(VlwdpByTFLCRExivHoWfamshutIMYQ,'w',-1,'utf-8')
   VlwdpByTFLCRExivHoWfamshutIMYU=urllib.parse.urlencode(VlwdpByTFLCRExivHoWfamshutIMnX)
   VlwdpByTFLCRExivHoWfamshutIMYU=VlwdpByTFLCRExivHoWfamshutIMYU+'\n'
   fp.write(VlwdpByTFLCRExivHoWfamshutIMYU)
   VlwdpByTFLCRExivHoWfamshutIMYc=0
   for VlwdpByTFLCRExivHoWfamshutIMYN in VlwdpByTFLCRExivHoWfamshutIMYg:
    VlwdpByTFLCRExivHoWfamshutIMYS=VlwdpByTFLCRExivHoWfamshutIMkN(urllib.parse.parse_qsl(VlwdpByTFLCRExivHoWfamshutIMYN))
    VlwdpByTFLCRExivHoWfamshutIMOn=VlwdpByTFLCRExivHoWfamshutIMnX.get('code').strip()
    VlwdpByTFLCRExivHoWfamshutIMOq=VlwdpByTFLCRExivHoWfamshutIMYS.get('code').strip()
    if VlwdpByTFLCRExivHoWfamshutIMkr=='vod' and VlwdpByTFLCRExivHoWfamshutIMnr.get_settings_direct_replay()==VlwdpByTFLCRExivHoWfamshutIMkg:
     VlwdpByTFLCRExivHoWfamshutIMOn=VlwdpByTFLCRExivHoWfamshutIMnX.get('videoid').strip()
     VlwdpByTFLCRExivHoWfamshutIMOq=VlwdpByTFLCRExivHoWfamshutIMYS.get('videoid').strip()if VlwdpByTFLCRExivHoWfamshutIMOq!=VlwdpByTFLCRExivHoWfamshutIMke else '-'
    if VlwdpByTFLCRExivHoWfamshutIMOn!=VlwdpByTFLCRExivHoWfamshutIMOq:
     fp.write(VlwdpByTFLCRExivHoWfamshutIMYN)
     VlwdpByTFLCRExivHoWfamshutIMYc+=1
     if VlwdpByTFLCRExivHoWfamshutIMYc>=50:break
   fp.close()
  except:
   VlwdpByTFLCRExivHoWfamshutIMke
 def Delete_Watched_List(VlwdpByTFLCRExivHoWfamshutIMnr,VlwdpByTFLCRExivHoWfamshutIMkr):
  try:
   VlwdpByTFLCRExivHoWfamshutIMYQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VlwdpByTFLCRExivHoWfamshutIMkr))
   fp=VlwdpByTFLCRExivHoWfamshutIMkc(VlwdpByTFLCRExivHoWfamshutIMYQ,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   VlwdpByTFLCRExivHoWfamshutIMke
 def dp_WatchList_Delete(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMOY=args.get('sType')
  VlwdpByTFLCRExivHoWfamshutIMnG=xbmcgui.Dialog()
  VlwdpByTFLCRExivHoWfamshutIMqe=VlwdpByTFLCRExivHoWfamshutIMnG.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if VlwdpByTFLCRExivHoWfamshutIMqe==VlwdpByTFLCRExivHoWfamshutIMkD:sys.exit()
  VlwdpByTFLCRExivHoWfamshutIMnr.Delete_Watched_List(VlwdpByTFLCRExivHoWfamshutIMOY)
  xbmc.executebuiltin("Container.Refresh")
 def logout(VlwdpByTFLCRExivHoWfamshutIMnr):
  VlwdpByTFLCRExivHoWfamshutIMnG=xbmcgui.Dialog()
  VlwdpByTFLCRExivHoWfamshutIMqe=VlwdpByTFLCRExivHoWfamshutIMnG.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if VlwdpByTFLCRExivHoWfamshutIMqe==VlwdpByTFLCRExivHoWfamshutIMkD:sys.exit()
  VlwdpByTFLCRExivHoWfamshutIMnr.wininfo_clear()
  if os.path.isfile(VlwdpByTFLCRExivHoWfamshutIMnb):os.remove(VlwdpByTFLCRExivHoWfamshutIMnb)
  VlwdpByTFLCRExivHoWfamshutIMnr.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(VlwdpByTFLCRExivHoWfamshutIMnr):
  VlwdpByTFLCRExivHoWfamshutIMqY=xbmcgui.Window(10000)
  VlwdpByTFLCRExivHoWfamshutIMqY.setProperty('WAVVE_M_CREDENTIAL','')
  VlwdpByTFLCRExivHoWfamshutIMqY.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(VlwdpByTFLCRExivHoWfamshutIMnr):
  VlwdpByTFLCRExivHoWfamshutIMOk =VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_Now_Datetime()
  VlwdpByTFLCRExivHoWfamshutIMOj=VlwdpByTFLCRExivHoWfamshutIMOk+datetime.timedelta(days=VlwdpByTFLCRExivHoWfamshutIMkQ(__addon__.getSetting('cache_ttl')))
  VlwdpByTFLCRExivHoWfamshutIMqY=xbmcgui.Window(10000)
  VlwdpByTFLCRExivHoWfamshutIMOb={'wavve_token':VlwdpByTFLCRExivHoWfamshutIMqY.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':VlwdpByTFLCRExivHoWfamshutIMOj.strftime('%Y-%m-%d')}
  try: 
   fp=VlwdpByTFLCRExivHoWfamshutIMkc(VlwdpByTFLCRExivHoWfamshutIMnb,'w',-1,'utf-8')
   json.dump(VlwdpByTFLCRExivHoWfamshutIMOb,fp)
   fp.close()
  except VlwdpByTFLCRExivHoWfamshutIMkS as exception:
   VlwdpByTFLCRExivHoWfamshutIMjn(exception)
 def cookiefile_check(VlwdpByTFLCRExivHoWfamshutIMnr):
  VlwdpByTFLCRExivHoWfamshutIMOb={}
  try: 
   fp=VlwdpByTFLCRExivHoWfamshutIMkc(VlwdpByTFLCRExivHoWfamshutIMnb,'r',-1,'utf-8')
   VlwdpByTFLCRExivHoWfamshutIMOb= json.load(fp)
   fp.close()
  except VlwdpByTFLCRExivHoWfamshutIMkS as exception:
   VlwdpByTFLCRExivHoWfamshutIMnr.wininfo_clear()
   return VlwdpByTFLCRExivHoWfamshutIMkD
  VlwdpByTFLCRExivHoWfamshutIMqG =__addon__.getSetting('id')
  VlwdpByTFLCRExivHoWfamshutIMqK =__addon__.getSetting('pw')
  VlwdpByTFLCRExivHoWfamshutIMOr =__addon__.getSetting('selected_profile')
  VlwdpByTFLCRExivHoWfamshutIMOb['wavve_id']=base64.standard_b64decode(VlwdpByTFLCRExivHoWfamshutIMOb['wavve_id']).decode('utf-8')
  VlwdpByTFLCRExivHoWfamshutIMOb['wavve_pw']=base64.standard_b64decode(VlwdpByTFLCRExivHoWfamshutIMOb['wavve_pw']).decode('utf-8')
  if VlwdpByTFLCRExivHoWfamshutIMqG!=VlwdpByTFLCRExivHoWfamshutIMOb['wavve_id']or VlwdpByTFLCRExivHoWfamshutIMqK!=VlwdpByTFLCRExivHoWfamshutIMOb['wavve_pw']or VlwdpByTFLCRExivHoWfamshutIMOr!=VlwdpByTFLCRExivHoWfamshutIMOb['wavve_profile']:
   VlwdpByTFLCRExivHoWfamshutIMnr.wininfo_clear()
   return VlwdpByTFLCRExivHoWfamshutIMkD
  VlwdpByTFLCRExivHoWfamshutIMqQ =VlwdpByTFLCRExivHoWfamshutIMkQ(VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  VlwdpByTFLCRExivHoWfamshutIMOJ=VlwdpByTFLCRExivHoWfamshutIMOb['wavve_limitdate']
  VlwdpByTFLCRExivHoWfamshutIMqD =VlwdpByTFLCRExivHoWfamshutIMkQ(re.sub('-','',VlwdpByTFLCRExivHoWfamshutIMOJ))
  if VlwdpByTFLCRExivHoWfamshutIMqD<VlwdpByTFLCRExivHoWfamshutIMqQ:
   VlwdpByTFLCRExivHoWfamshutIMnr.wininfo_clear()
   return VlwdpByTFLCRExivHoWfamshutIMkD
  VlwdpByTFLCRExivHoWfamshutIMqY=xbmcgui.Window(10000)
  VlwdpByTFLCRExivHoWfamshutIMqY.setProperty('WAVVE_M_CREDENTIAL',VlwdpByTFLCRExivHoWfamshutIMOb['wavve_token'])
  VlwdpByTFLCRExivHoWfamshutIMqY.setProperty('WAVVE_M_LOGINTIME',VlwdpByTFLCRExivHoWfamshutIMOJ)
  return VlwdpByTFLCRExivHoWfamshutIMkg
 def dp_LiveCatagory_List(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.SaveCredential(VlwdpByTFLCRExivHoWfamshutIMnr.get_winCredential())
  VlwdpByTFLCRExivHoWfamshutIMOP =args.get('sCode')
  VlwdpByTFLCRExivHoWfamshutIMOX=args.get('sIndex')
  VlwdpByTFLCRExivHoWfamshutIMOA,VlwdpByTFLCRExivHoWfamshutIMOG=VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_LiveCatagory_List(VlwdpByTFLCRExivHoWfamshutIMOP,VlwdpByTFLCRExivHoWfamshutIMOX)
  for VlwdpByTFLCRExivHoWfamshutIMOK in VlwdpByTFLCRExivHoWfamshutIMOA:
   VlwdpByTFLCRExivHoWfamshutIMqk =VlwdpByTFLCRExivHoWfamshutIMOK.get('title')
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'LIVE_LIST','genre':VlwdpByTFLCRExivHoWfamshutIMOK.get('genre'),'baseapi':VlwdpByTFLCRExivHoWfamshutIMOG}
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel='',img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMOA)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkD)
 def dp_MainCatagory_List(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.SaveCredential(VlwdpByTFLCRExivHoWfamshutIMnr.get_winCredential())
  VlwdpByTFLCRExivHoWfamshutIMOP =args.get('sCode')
  VlwdpByTFLCRExivHoWfamshutIMOX=args.get('sIndex')
  VlwdpByTFLCRExivHoWfamshutIMOY =args.get('sType')
  VlwdpByTFLCRExivHoWfamshutIMOA=VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_MainCatagory_List(VlwdpByTFLCRExivHoWfamshutIMOP,VlwdpByTFLCRExivHoWfamshutIMOX)
  for VlwdpByTFLCRExivHoWfamshutIMOK in VlwdpByTFLCRExivHoWfamshutIMOA:
   if VlwdpByTFLCRExivHoWfamshutIMOY=='vod':
    if VlwdpByTFLCRExivHoWfamshutIMOK.get('subtype')=='catagory':
     VlwdpByTFLCRExivHoWfamshutIMqc='PROGRAM_LIST'
    else:
     VlwdpByTFLCRExivHoWfamshutIMqc='SUPERSECTION_LIST'
   elif VlwdpByTFLCRExivHoWfamshutIMOY=='movie':
    VlwdpByTFLCRExivHoWfamshutIMqc='MOVIE_LIST'
   else:
    VlwdpByTFLCRExivHoWfamshutIMqc=''
   VlwdpByTFLCRExivHoWfamshutIMqk='%s (%s)'%(VlwdpByTFLCRExivHoWfamshutIMOK.get('title'),args.get('ordernm'))
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':VlwdpByTFLCRExivHoWfamshutIMqc,'suburl':VlwdpByTFLCRExivHoWfamshutIMOK.get('suburl'),'subapi':VlwdpByTFLCRExivHoWfamshutIMOK.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if VlwdpByTFLCRExivHoWfamshutIMnr.get_settings_exclusion21():
    if VlwdpByTFLCRExivHoWfamshutIMOK.get('title')=='성인' or VlwdpByTFLCRExivHoWfamshutIMOK.get('title')=='성인+':continue
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel='',img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMOA)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkD)
 def dp_Program_List(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.SaveCredential(VlwdpByTFLCRExivHoWfamshutIMnr.get_winCredential())
  VlwdpByTFLCRExivHoWfamshutIMOz =args.get('subapi')
  VlwdpByTFLCRExivHoWfamshutIMOe=VlwdpByTFLCRExivHoWfamshutIMkQ(args.get('page'))
  VlwdpByTFLCRExivHoWfamshutIMqU =args.get('orderby')
  VlwdpByTFLCRExivHoWfamshutIMOA,VlwdpByTFLCRExivHoWfamshutIMOQ=VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_Program_List(VlwdpByTFLCRExivHoWfamshutIMOz,VlwdpByTFLCRExivHoWfamshutIMOe,VlwdpByTFLCRExivHoWfamshutIMqU)
  for VlwdpByTFLCRExivHoWfamshutIMOK in VlwdpByTFLCRExivHoWfamshutIMOA:
   VlwdpByTFLCRExivHoWfamshutIMqk =VlwdpByTFLCRExivHoWfamshutIMOK.get('title')
   VlwdpByTFLCRExivHoWfamshutIMOD=VlwdpByTFLCRExivHoWfamshutIMOK.get('thumbnail')
   VlwdpByTFLCRExivHoWfamshutIMOg =VlwdpByTFLCRExivHoWfamshutIMOK.get('age')
   if VlwdpByTFLCRExivHoWfamshutIMOg=='18' or VlwdpByTFLCRExivHoWfamshutIMOg=='19' or VlwdpByTFLCRExivHoWfamshutIMOg=='21':VlwdpByTFLCRExivHoWfamshutIMqk+=' (%s)'%(VlwdpByTFLCRExivHoWfamshutIMOg)
   VlwdpByTFLCRExivHoWfamshutIMOU={'plot':VlwdpByTFLCRExivHoWfamshutIMqk,'mpaa':VlwdpByTFLCRExivHoWfamshutIMOg,'mediatype':'episode'}
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'EPISODE_LIST','videoid':VlwdpByTFLCRExivHoWfamshutIMOK.get('videoid'),'vidtype':VlwdpByTFLCRExivHoWfamshutIMOK.get('vidtype'),'page':'1'}
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel='',img=VlwdpByTFLCRExivHoWfamshutIMOD,infoLabels=VlwdpByTFLCRExivHoWfamshutIMOU,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMOQ:
   VlwdpByTFLCRExivHoWfamshutIMqr={}
   VlwdpByTFLCRExivHoWfamshutIMqr['mode'] ='PROGRAM_LIST' 
   VlwdpByTFLCRExivHoWfamshutIMqr['subapi']=VlwdpByTFLCRExivHoWfamshutIMOz 
   VlwdpByTFLCRExivHoWfamshutIMqr['page'] =VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMqk='[B]%s >>[/B]'%'다음 페이지'
   VlwdpByTFLCRExivHoWfamshutIMOc=VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel=VlwdpByTFLCRExivHoWfamshutIMOc,img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMOA)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkD)
 def dp_SuperSection_List(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.SaveCredential(VlwdpByTFLCRExivHoWfamshutIMnr.get_winCredential())
  VlwdpByTFLCRExivHoWfamshutIMON =args.get('suburl')
  VlwdpByTFLCRExivHoWfamshutIMOA=VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_SuperMultiSection_List(VlwdpByTFLCRExivHoWfamshutIMON)
  for VlwdpByTFLCRExivHoWfamshutIMOK in VlwdpByTFLCRExivHoWfamshutIMOA:
   VlwdpByTFLCRExivHoWfamshutIMqk =VlwdpByTFLCRExivHoWfamshutIMOK.get('title')
   VlwdpByTFLCRExivHoWfamshutIMOz =VlwdpByTFLCRExivHoWfamshutIMOK.get('subapi')
   VlwdpByTFLCRExivHoWfamshutIMOS=VlwdpByTFLCRExivHoWfamshutIMOK.get('cell_type')
   if VlwdpByTFLCRExivHoWfamshutIMOS=='band_2':
    VlwdpByTFLCRExivHoWfamshutIMqc='BAND2SECTION_LIST'
   elif VlwdpByTFLCRExivHoWfamshutIMOS=='band_live':
    VlwdpByTFLCRExivHoWfamshutIMqc='BANDLIVESECTION_LIST'
   else:
    VlwdpByTFLCRExivHoWfamshutIMqc='PROGRAM_LIST'
   VlwdpByTFLCRExivHoWfamshutIMOU={'plot':VlwdpByTFLCRExivHoWfamshutIMqk,'mediatype':'episode'}
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':VlwdpByTFLCRExivHoWfamshutIMqc,'suburl':VlwdpByTFLCRExivHoWfamshutIMON,'subapi':VlwdpByTFLCRExivHoWfamshutIMOK.get('subapi'),'page':'1'}
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel='',img=VlwdpByTFLCRExivHoWfamshutIMke,infoLabels=VlwdpByTFLCRExivHoWfamshutIMOU,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMOA)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkD)
 def dp_BandLiveSection_List(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.SaveCredential(VlwdpByTFLCRExivHoWfamshutIMnr.get_winCredential())
  VlwdpByTFLCRExivHoWfamshutIMOz =args.get('subapi')
  VlwdpByTFLCRExivHoWfamshutIMOe=VlwdpByTFLCRExivHoWfamshutIMkQ(args.get('page'))
  VlwdpByTFLCRExivHoWfamshutIMOA,VlwdpByTFLCRExivHoWfamshutIMOQ=VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_BandLiveSection_List(VlwdpByTFLCRExivHoWfamshutIMOz,VlwdpByTFLCRExivHoWfamshutIMOe)
  for VlwdpByTFLCRExivHoWfamshutIMOK in VlwdpByTFLCRExivHoWfamshutIMOA:
   VlwdpByTFLCRExivHoWfamshutIMkn =VlwdpByTFLCRExivHoWfamshutIMOK.get('channelid')
   VlwdpByTFLCRExivHoWfamshutIMkq =VlwdpByTFLCRExivHoWfamshutIMOK.get('studio')
   VlwdpByTFLCRExivHoWfamshutIMkY=VlwdpByTFLCRExivHoWfamshutIMOK.get('tvshowtitle')
   VlwdpByTFLCRExivHoWfamshutIMOD =VlwdpByTFLCRExivHoWfamshutIMOK.get('thumbnail')
   VlwdpByTFLCRExivHoWfamshutIMOg =VlwdpByTFLCRExivHoWfamshutIMOK.get('age')
   VlwdpByTFLCRExivHoWfamshutIMOU={'mediatype':'video','mpaa':VlwdpByTFLCRExivHoWfamshutIMOg,'title':'%s < %s >'%(VlwdpByTFLCRExivHoWfamshutIMkq,VlwdpByTFLCRExivHoWfamshutIMkY),'tvshowtitle':VlwdpByTFLCRExivHoWfamshutIMkY,'studio':VlwdpByTFLCRExivHoWfamshutIMkq,'plot':VlwdpByTFLCRExivHoWfamshutIMkq}
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'LIVE','contentid':VlwdpByTFLCRExivHoWfamshutIMkn}
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMkq,sublabel=VlwdpByTFLCRExivHoWfamshutIMkY,img=VlwdpByTFLCRExivHoWfamshutIMOK.get('thumbnail'),infoLabels=VlwdpByTFLCRExivHoWfamshutIMOU,isFolder=VlwdpByTFLCRExivHoWfamshutIMkD,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMOQ:
   VlwdpByTFLCRExivHoWfamshutIMqr={}
   VlwdpByTFLCRExivHoWfamshutIMqr['mode'] ='BANDLIVESECTION_LIST' 
   VlwdpByTFLCRExivHoWfamshutIMqr['subapi']=VlwdpByTFLCRExivHoWfamshutIMOz
   VlwdpByTFLCRExivHoWfamshutIMqr['page'] =VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMqk='[B]%s >>[/B]'%'다음 페이지'
   VlwdpByTFLCRExivHoWfamshutIMOc=VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel=VlwdpByTFLCRExivHoWfamshutIMOc,img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMOA)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkD)
 def dp_Band2Section_List(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.SaveCredential(VlwdpByTFLCRExivHoWfamshutIMnr.get_winCredential())
  VlwdpByTFLCRExivHoWfamshutIMOz =args.get('subapi')
  VlwdpByTFLCRExivHoWfamshutIMOe=VlwdpByTFLCRExivHoWfamshutIMkQ(args.get('page'))
  VlwdpByTFLCRExivHoWfamshutIMOA,VlwdpByTFLCRExivHoWfamshutIMOQ=VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_Band2Section_List(VlwdpByTFLCRExivHoWfamshutIMOz,VlwdpByTFLCRExivHoWfamshutIMOe)
  for VlwdpByTFLCRExivHoWfamshutIMOK in VlwdpByTFLCRExivHoWfamshutIMOA:
   VlwdpByTFLCRExivHoWfamshutIMqk =VlwdpByTFLCRExivHoWfamshutIMOK.get('programtitle')
   VlwdpByTFLCRExivHoWfamshutIMOc =VlwdpByTFLCRExivHoWfamshutIMOK.get('episodetitle')
   VlwdpByTFLCRExivHoWfamshutIMOU={'plot':VlwdpByTFLCRExivHoWfamshutIMqk+'\n\n'+VlwdpByTFLCRExivHoWfamshutIMOc,'mpaa':VlwdpByTFLCRExivHoWfamshutIMOK.get('age'),'mediatype':'episode'}
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'VOD','programid':'-','contentid':VlwdpByTFLCRExivHoWfamshutIMOK.get('videoid'),'thumbnail':VlwdpByTFLCRExivHoWfamshutIMOK.get('thumbnail'),'title':VlwdpByTFLCRExivHoWfamshutIMqk,'subtitle':VlwdpByTFLCRExivHoWfamshutIMOc}
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel=VlwdpByTFLCRExivHoWfamshutIMOc,img=VlwdpByTFLCRExivHoWfamshutIMOK.get('thumbnail'),infoLabels=VlwdpByTFLCRExivHoWfamshutIMOU,isFolder=VlwdpByTFLCRExivHoWfamshutIMkD,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMOQ:
   VlwdpByTFLCRExivHoWfamshutIMqr={}
   VlwdpByTFLCRExivHoWfamshutIMqr['mode'] ='BAND2SECTION_LIST' 
   VlwdpByTFLCRExivHoWfamshutIMqr['subapi']=VlwdpByTFLCRExivHoWfamshutIMOz
   VlwdpByTFLCRExivHoWfamshutIMqr['page'] =VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMqk='[B]%s >>[/B]'%'다음 페이지'
   VlwdpByTFLCRExivHoWfamshutIMOc=VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel=VlwdpByTFLCRExivHoWfamshutIMOc,img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMOA)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkD)
 def dp_Movie_List(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.SaveCredential(VlwdpByTFLCRExivHoWfamshutIMnr.get_winCredential())
  VlwdpByTFLCRExivHoWfamshutIMOz =args.get('subapi')
  VlwdpByTFLCRExivHoWfamshutIMOe=VlwdpByTFLCRExivHoWfamshutIMkQ(args.get('page'))
  VlwdpByTFLCRExivHoWfamshutIMOA,VlwdpByTFLCRExivHoWfamshutIMOQ=VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_Movie_List(VlwdpByTFLCRExivHoWfamshutIMOz,VlwdpByTFLCRExivHoWfamshutIMOe)
  for VlwdpByTFLCRExivHoWfamshutIMOK in VlwdpByTFLCRExivHoWfamshutIMOA:
   VlwdpByTFLCRExivHoWfamshutIMqk =VlwdpByTFLCRExivHoWfamshutIMOK.get('title')
   VlwdpByTFLCRExivHoWfamshutIMOD=VlwdpByTFLCRExivHoWfamshutIMOK.get('thumbnail')
   VlwdpByTFLCRExivHoWfamshutIMOg =VlwdpByTFLCRExivHoWfamshutIMOK.get('age')
   if VlwdpByTFLCRExivHoWfamshutIMOg=='18' or VlwdpByTFLCRExivHoWfamshutIMOg=='19' or VlwdpByTFLCRExivHoWfamshutIMOg=='21':VlwdpByTFLCRExivHoWfamshutIMqk+=' (%s)'%(VlwdpByTFLCRExivHoWfamshutIMOg)
   VlwdpByTFLCRExivHoWfamshutIMOU={'plot':VlwdpByTFLCRExivHoWfamshutIMqk,'mpaa':VlwdpByTFLCRExivHoWfamshutIMOg,'mediatype':'movie'}
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'MOVIE','contentid':VlwdpByTFLCRExivHoWfamshutIMOK.get('videoid'),'title':VlwdpByTFLCRExivHoWfamshutIMqk,'thumbnail':VlwdpByTFLCRExivHoWfamshutIMOD,'age':VlwdpByTFLCRExivHoWfamshutIMOg}
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel='',img=VlwdpByTFLCRExivHoWfamshutIMOD,infoLabels=VlwdpByTFLCRExivHoWfamshutIMOU,isFolder=VlwdpByTFLCRExivHoWfamshutIMkD,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMOQ:
   VlwdpByTFLCRExivHoWfamshutIMqr={}
   VlwdpByTFLCRExivHoWfamshutIMqr['mode'] ='MOVIE_LIST' 
   VlwdpByTFLCRExivHoWfamshutIMqr['subapi']=VlwdpByTFLCRExivHoWfamshutIMOz 
   VlwdpByTFLCRExivHoWfamshutIMqr['page'] =VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMqk='[B]%s >>[/B]'%'다음 페이지'
   VlwdpByTFLCRExivHoWfamshutIMOc=VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel=VlwdpByTFLCRExivHoWfamshutIMOc,img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMOA)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkD)
 def dp_Episode_List(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.SaveCredential(VlwdpByTFLCRExivHoWfamshutIMnr.get_winCredential())
  VlwdpByTFLCRExivHoWfamshutIMkO =args.get('videoid')
  VlwdpByTFLCRExivHoWfamshutIMkj =args.get('vidtype')
  VlwdpByTFLCRExivHoWfamshutIMOe=VlwdpByTFLCRExivHoWfamshutIMkQ(args.get('page'))
  VlwdpByTFLCRExivHoWfamshutIMOA,VlwdpByTFLCRExivHoWfamshutIMOQ=VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_Episode_List(VlwdpByTFLCRExivHoWfamshutIMkO,VlwdpByTFLCRExivHoWfamshutIMkj,VlwdpByTFLCRExivHoWfamshutIMOe,orderby=VlwdpByTFLCRExivHoWfamshutIMnr.get_winEpisodeOrderby())
  for VlwdpByTFLCRExivHoWfamshutIMOK in VlwdpByTFLCRExivHoWfamshutIMOA:
   VlwdpByTFLCRExivHoWfamshutIMOc='%s회, %s(%s)'%(VlwdpByTFLCRExivHoWfamshutIMOK.get('episodenumber'),VlwdpByTFLCRExivHoWfamshutIMOK.get('releasedate'),VlwdpByTFLCRExivHoWfamshutIMOK.get('releaseweekday'))
   VlwdpByTFLCRExivHoWfamshutIMkb ='[%s]\n\n%s'%(VlwdpByTFLCRExivHoWfamshutIMOK.get('episodetitle'),VlwdpByTFLCRExivHoWfamshutIMOK.get('synopsis'))
   VlwdpByTFLCRExivHoWfamshutIMOU={'mediatype':'episode','title':VlwdpByTFLCRExivHoWfamshutIMOK.get('programtitle'),'year':VlwdpByTFLCRExivHoWfamshutIMkQ(VlwdpByTFLCRExivHoWfamshutIMOK.get('releasedate')[:4]),'aired':VlwdpByTFLCRExivHoWfamshutIMOK.get('releasedate'),'mpaa':VlwdpByTFLCRExivHoWfamshutIMOK.get('age'),'episode':VlwdpByTFLCRExivHoWfamshutIMOK.get('episodenumber'),'duration':VlwdpByTFLCRExivHoWfamshutIMOK.get('playtime'),'plot':VlwdpByTFLCRExivHoWfamshutIMkb,'cast':VlwdpByTFLCRExivHoWfamshutIMOK.get('episodeactors')}
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'VOD','programid':VlwdpByTFLCRExivHoWfamshutIMOK.get('programid'),'contentid':VlwdpByTFLCRExivHoWfamshutIMOK.get('contentid'),'thumbnail':VlwdpByTFLCRExivHoWfamshutIMOK.get('thumbnail'),'title':VlwdpByTFLCRExivHoWfamshutIMOK.get('programtitle'),'subtitle':VlwdpByTFLCRExivHoWfamshutIMOc}
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMOK.get('programtitle'),sublabel=VlwdpByTFLCRExivHoWfamshutIMOc,img=VlwdpByTFLCRExivHoWfamshutIMOK.get('thumbnail'),infoLabels=VlwdpByTFLCRExivHoWfamshutIMOU,isFolder=VlwdpByTFLCRExivHoWfamshutIMkD,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMOe==1:
   VlwdpByTFLCRExivHoWfamshutIMOU={'plot':'정렬순서를 변경합니다.'}
   VlwdpByTFLCRExivHoWfamshutIMqr={}
   VlwdpByTFLCRExivHoWfamshutIMqr['mode'] ='ORDER_BY' 
   if VlwdpByTFLCRExivHoWfamshutIMnr.get_winEpisodeOrderby()=='desc':
    VlwdpByTFLCRExivHoWfamshutIMqk='정렬순서변경 : 최신화부터 -> 1회부터'
    VlwdpByTFLCRExivHoWfamshutIMqr['orderby']='asc'
   else:
    VlwdpByTFLCRExivHoWfamshutIMqk='정렬순서변경 : 1회부터 -> 최신화부터'
    VlwdpByTFLCRExivHoWfamshutIMqr['orderby']='desc'
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel='',img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMOU,isFolder=VlwdpByTFLCRExivHoWfamshutIMkD,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMOQ:
   VlwdpByTFLCRExivHoWfamshutIMqr={}
   VlwdpByTFLCRExivHoWfamshutIMqr['mode'] ='EPISODE_LIST' 
   VlwdpByTFLCRExivHoWfamshutIMqr['videoid']=VlwdpByTFLCRExivHoWfamshutIMOK.get('programid')
   VlwdpByTFLCRExivHoWfamshutIMqr['vidtype']='programid'
   VlwdpByTFLCRExivHoWfamshutIMqr['page'] =VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMqk='[B]%s >>[/B]'%'다음 페이지'
   VlwdpByTFLCRExivHoWfamshutIMOc=VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel=VlwdpByTFLCRExivHoWfamshutIMOc,img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMOA)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkD)
 def dp_LiveChannel_List(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.SaveCredential(VlwdpByTFLCRExivHoWfamshutIMnr.get_winCredential())
  VlwdpByTFLCRExivHoWfamshutIMkr =args.get('genre')
  VlwdpByTFLCRExivHoWfamshutIMOG=args.get('baseapi')
  VlwdpByTFLCRExivHoWfamshutIMOA=VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_LiveChannel_List(VlwdpByTFLCRExivHoWfamshutIMkr,VlwdpByTFLCRExivHoWfamshutIMOG)
  for VlwdpByTFLCRExivHoWfamshutIMOK in VlwdpByTFLCRExivHoWfamshutIMOA:
   VlwdpByTFLCRExivHoWfamshutIMkn =VlwdpByTFLCRExivHoWfamshutIMOK.get('channelid')
   VlwdpByTFLCRExivHoWfamshutIMkq =VlwdpByTFLCRExivHoWfamshutIMOK.get('studio')
   VlwdpByTFLCRExivHoWfamshutIMkY=VlwdpByTFLCRExivHoWfamshutIMOK.get('tvshowtitle')
   VlwdpByTFLCRExivHoWfamshutIMOD =VlwdpByTFLCRExivHoWfamshutIMOK.get('thumbnail')
   VlwdpByTFLCRExivHoWfamshutIMOg =VlwdpByTFLCRExivHoWfamshutIMOK.get('age')
   VlwdpByTFLCRExivHoWfamshutIMkJ =VlwdpByTFLCRExivHoWfamshutIMOK.get('epg')
   VlwdpByTFLCRExivHoWfamshutIMOU={'mediatype':'video','mpaa':VlwdpByTFLCRExivHoWfamshutIMOg,'title':'%s < %s >'%(VlwdpByTFLCRExivHoWfamshutIMkq,VlwdpByTFLCRExivHoWfamshutIMkY),'tvshowtitle':VlwdpByTFLCRExivHoWfamshutIMkY,'studio':VlwdpByTFLCRExivHoWfamshutIMkq,'plot':'%s\n\n%s'%(VlwdpByTFLCRExivHoWfamshutIMkq,VlwdpByTFLCRExivHoWfamshutIMkJ)}
   VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'LIVE','contentid':VlwdpByTFLCRExivHoWfamshutIMkn}
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(label=VlwdpByTFLCRExivHoWfamshutIMkq,sublabel=VlwdpByTFLCRExivHoWfamshutIMkY,img=VlwdpByTFLCRExivHoWfamshutIMOD,infoLabels=VlwdpByTFLCRExivHoWfamshutIMOU,isFolder=VlwdpByTFLCRExivHoWfamshutIMkD,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMOA)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkD)
 def dp_Search_List(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.SaveCredential(VlwdpByTFLCRExivHoWfamshutIMnr.get_winCredential())
  VlwdpByTFLCRExivHoWfamshutIMOY =args.get('sType')
  VlwdpByTFLCRExivHoWfamshutIMOe =VlwdpByTFLCRExivHoWfamshutIMkQ(args.get('page'))
  if 'search_key' in args:
   VlwdpByTFLCRExivHoWfamshutIMkX=args.get('search_key')
  else:
   VlwdpByTFLCRExivHoWfamshutIMkX=VlwdpByTFLCRExivHoWfamshutIMnr.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VlwdpByTFLCRExivHoWfamshutIMkX:return
  VlwdpByTFLCRExivHoWfamshutIMOA,VlwdpByTFLCRExivHoWfamshutIMOQ=VlwdpByTFLCRExivHoWfamshutIMnr.WavveObj.Get_Search_List(VlwdpByTFLCRExivHoWfamshutIMkX,VlwdpByTFLCRExivHoWfamshutIMOY,VlwdpByTFLCRExivHoWfamshutIMOe,exclusion21=VlwdpByTFLCRExivHoWfamshutIMnr.get_settings_exclusion21())
  for VlwdpByTFLCRExivHoWfamshutIMOK in VlwdpByTFLCRExivHoWfamshutIMOA:
   VlwdpByTFLCRExivHoWfamshutIMqk =VlwdpByTFLCRExivHoWfamshutIMOK.get('title')
   VlwdpByTFLCRExivHoWfamshutIMOD=VlwdpByTFLCRExivHoWfamshutIMOK.get('thumbnail')
   VlwdpByTFLCRExivHoWfamshutIMOg =VlwdpByTFLCRExivHoWfamshutIMOK.get('age')
   if VlwdpByTFLCRExivHoWfamshutIMOg=='18' or VlwdpByTFLCRExivHoWfamshutIMOg=='19' or VlwdpByTFLCRExivHoWfamshutIMOg=='21':VlwdpByTFLCRExivHoWfamshutIMqk+=' (%s)'%(VlwdpByTFLCRExivHoWfamshutIMOg)
   VlwdpByTFLCRExivHoWfamshutIMOU={'mediatype':'episode' if VlwdpByTFLCRExivHoWfamshutIMOY=='vod' else 'movie','mpaa':VlwdpByTFLCRExivHoWfamshutIMOg,'title':VlwdpByTFLCRExivHoWfamshutIMqk,'plot':VlwdpByTFLCRExivHoWfamshutIMqk}
   if VlwdpByTFLCRExivHoWfamshutIMOY=='vod':
    VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'EPISODE_LIST','videoid':VlwdpByTFLCRExivHoWfamshutIMOK.get('videoid'),'vidtype':VlwdpByTFLCRExivHoWfamshutIMOK.get('vidtype'),'page':'1'}
    VlwdpByTFLCRExivHoWfamshutIMqJ=VlwdpByTFLCRExivHoWfamshutIMkg
   else:
    VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'MOVIE','contentid':VlwdpByTFLCRExivHoWfamshutIMOK.get('videoid'),'title':VlwdpByTFLCRExivHoWfamshutIMqk,'thumbnail':VlwdpByTFLCRExivHoWfamshutIMOD,'age':VlwdpByTFLCRExivHoWfamshutIMOg}
    VlwdpByTFLCRExivHoWfamshutIMqJ=VlwdpByTFLCRExivHoWfamshutIMkD
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel='',img=VlwdpByTFLCRExivHoWfamshutIMOD,infoLabels=VlwdpByTFLCRExivHoWfamshutIMOU,isFolder=VlwdpByTFLCRExivHoWfamshutIMqJ,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMOQ:
   VlwdpByTFLCRExivHoWfamshutIMqr['mode'] ='SEARCH_LIST' 
   VlwdpByTFLCRExivHoWfamshutIMqr['sType']=VlwdpByTFLCRExivHoWfamshutIMOY 
   VlwdpByTFLCRExivHoWfamshutIMqr['page'] =VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMqr['search_key']=VlwdpByTFLCRExivHoWfamshutIMkX
   VlwdpByTFLCRExivHoWfamshutIMqk='[B]%s >>[/B]'%'다음 페이지'
   VlwdpByTFLCRExivHoWfamshutIMOc=VlwdpByTFLCRExivHoWfamshutIMjq(VlwdpByTFLCRExivHoWfamshutIMOe+1)
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel=VlwdpByTFLCRExivHoWfamshutIMOc,img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMke,isFolder=VlwdpByTFLCRExivHoWfamshutIMkg,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  if VlwdpByTFLCRExivHoWfamshutIMkU(VlwdpByTFLCRExivHoWfamshutIMOA)>0:xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle)
 def dp_Watch_List(VlwdpByTFLCRExivHoWfamshutIMnr,args):
  VlwdpByTFLCRExivHoWfamshutIMOY =args.get('sType')
  VlwdpByTFLCRExivHoWfamshutIMnS=VlwdpByTFLCRExivHoWfamshutIMnr.get_settings_direct_replay()
  VlwdpByTFLCRExivHoWfamshutIMOA=VlwdpByTFLCRExivHoWfamshutIMnr.Load_Watched_List(VlwdpByTFLCRExivHoWfamshutIMOY)
  for VlwdpByTFLCRExivHoWfamshutIMOK in VlwdpByTFLCRExivHoWfamshutIMOA:
   VlwdpByTFLCRExivHoWfamshutIMkA=VlwdpByTFLCRExivHoWfamshutIMkN(urllib.parse.parse_qsl(VlwdpByTFLCRExivHoWfamshutIMOK))
   VlwdpByTFLCRExivHoWfamshutIMkG =VlwdpByTFLCRExivHoWfamshutIMkA.get('code').strip()
   VlwdpByTFLCRExivHoWfamshutIMqk =VlwdpByTFLCRExivHoWfamshutIMkA.get('title').strip()
   VlwdpByTFLCRExivHoWfamshutIMOc =VlwdpByTFLCRExivHoWfamshutIMkA.get('subtitle').strip()
   if VlwdpByTFLCRExivHoWfamshutIMOc=='None':VlwdpByTFLCRExivHoWfamshutIMOc=''
   VlwdpByTFLCRExivHoWfamshutIMOD=VlwdpByTFLCRExivHoWfamshutIMkA.get('img').strip()
   VlwdpByTFLCRExivHoWfamshutIMkO =VlwdpByTFLCRExivHoWfamshutIMkA.get('videoid').strip()
   VlwdpByTFLCRExivHoWfamshutIMOU={'plot':'%s\n%s'%(VlwdpByTFLCRExivHoWfamshutIMqk,VlwdpByTFLCRExivHoWfamshutIMOc)}
   if VlwdpByTFLCRExivHoWfamshutIMOY=='vod':
    if VlwdpByTFLCRExivHoWfamshutIMnS==VlwdpByTFLCRExivHoWfamshutIMkD or VlwdpByTFLCRExivHoWfamshutIMkO==VlwdpByTFLCRExivHoWfamshutIMke:
     VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'EPISODE_LIST','videoid':VlwdpByTFLCRExivHoWfamshutIMkG,'vidtype':'programid','page':'1'}
     VlwdpByTFLCRExivHoWfamshutIMqJ=VlwdpByTFLCRExivHoWfamshutIMkg
    else:
     VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'VOD','programid':VlwdpByTFLCRExivHoWfamshutIMkG,'contentid':VlwdpByTFLCRExivHoWfamshutIMkO,'title':VlwdpByTFLCRExivHoWfamshutIMqk,'subtitle':VlwdpByTFLCRExivHoWfamshutIMOc,'thumbnail':VlwdpByTFLCRExivHoWfamshutIMOD}
     VlwdpByTFLCRExivHoWfamshutIMqJ=VlwdpByTFLCRExivHoWfamshutIMkD
   else:
    VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'MOVIE','contentid':VlwdpByTFLCRExivHoWfamshutIMkG,'title':VlwdpByTFLCRExivHoWfamshutIMqk,'subtitle':VlwdpByTFLCRExivHoWfamshutIMOc,'thumbnail':VlwdpByTFLCRExivHoWfamshutIMOD}
    VlwdpByTFLCRExivHoWfamshutIMqJ=VlwdpByTFLCRExivHoWfamshutIMkD
   VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel=VlwdpByTFLCRExivHoWfamshutIMOc,img=VlwdpByTFLCRExivHoWfamshutIMOD,infoLabels=VlwdpByTFLCRExivHoWfamshutIMOU,isFolder=VlwdpByTFLCRExivHoWfamshutIMqJ,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  VlwdpByTFLCRExivHoWfamshutIMOU={'plot':'시청목록을 삭제합니다.'}
  VlwdpByTFLCRExivHoWfamshutIMqk='*** 시청목록 삭제 ***'
  VlwdpByTFLCRExivHoWfamshutIMqr={'mode':'MYVIEW_REMOVE','sType':VlwdpByTFLCRExivHoWfamshutIMOY}
  VlwdpByTFLCRExivHoWfamshutIMnr.add_dir(VlwdpByTFLCRExivHoWfamshutIMqk,sublabel='',img='',infoLabels=VlwdpByTFLCRExivHoWfamshutIMOU,isFolder=VlwdpByTFLCRExivHoWfamshutIMkD,params=VlwdpByTFLCRExivHoWfamshutIMqr)
  xbmcplugin.endOfDirectory(VlwdpByTFLCRExivHoWfamshutIMnr._addon_handle,cacheToDisc=VlwdpByTFLCRExivHoWfamshutIMkD)
 def wavve_main(VlwdpByTFLCRExivHoWfamshutIMnr):
  VlwdpByTFLCRExivHoWfamshutIMqc=VlwdpByTFLCRExivHoWfamshutIMnr.main_params.get('mode',VlwdpByTFLCRExivHoWfamshutIMke)
  if VlwdpByTFLCRExivHoWfamshutIMqc=='LOGOUT':
   VlwdpByTFLCRExivHoWfamshutIMnr.logout()
   return
  VlwdpByTFLCRExivHoWfamshutIMnr.login_main()
  if VlwdpByTFLCRExivHoWfamshutIMqc is VlwdpByTFLCRExivHoWfamshutIMke:
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_Main_List()
  elif VlwdpByTFLCRExivHoWfamshutIMqc in['LIVE','VOD','MOVIE']:
   VlwdpByTFLCRExivHoWfamshutIMnr.play_VIDEO(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='LIVE_CATAGORY':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_LiveCatagory_List(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='MAIN_CATAGORY':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_MainCatagory_List(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='SUPERSECTION_LIST':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_SuperSection_List(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='BANDLIVESECTION_LIST':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_BandLiveSection_List(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='BAND2SECTION_LIST':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_Band2Section_List(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='PROGRAM_LIST':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_Program_List(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='EPISODE_LIST':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_Episode_List(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='MOVIE_LIST':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_Movie_List(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='LIVE_LIST':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_LiveChannel_List(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='ORDER_BY':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_setEpOrderby(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='SEARCH_GROUP':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_Search_Group(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='SEARCH_LIST':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_Search_List(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='WATCH_GROUP':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_Watch_Group(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='WATCH_LIST':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_Watch_List(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  elif VlwdpByTFLCRExivHoWfamshutIMqc=='MYVIEW_REMOVE':
   VlwdpByTFLCRExivHoWfamshutIMnr.dp_WatchList_Delete(VlwdpByTFLCRExivHoWfamshutIMnr.main_params)
  else:
   VlwdpByTFLCRExivHoWfamshutIMke
# Created by pyminifier (https://github.com/liftoff/pyminifier)
