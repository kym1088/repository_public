__author__="NightRain"
IfrqlKMRdpUzbAtvgeDXwOjYkCFymW=object
IfrqlKMRdpUzbAtvgeDXwOjYkCFymT=None
IfrqlKMRdpUzbAtvgeDXwOjYkCFymH=False
IfrqlKMRdpUzbAtvgeDXwOjYkCFyms=True
IfrqlKMRdpUzbAtvgeDXwOjYkCFymG=range
IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ=str
IfrqlKMRdpUzbAtvgeDXwOjYkCFymi=Exception
IfrqlKMRdpUzbAtvgeDXwOjYkCFymN=print
IfrqlKMRdpUzbAtvgeDXwOjYkCFymJ=dict
IfrqlKMRdpUzbAtvgeDXwOjYkCFymc=int
IfrqlKMRdpUzbAtvgeDXwOjYkCFymE=len
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
IfrqlKMRdpUzbAtvgeDXwOjYkCFyuo='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
class IfrqlKMRdpUzbAtvgeDXwOjYkCFyuL(IfrqlKMRdpUzbAtvgeDXwOjYkCFymW):
 def __init__(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN='https://apis.wavve.com'
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.CREDENTIAL='none'
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.DEVICE ='pc'
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.DRM ='wm'
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.PARTNER ='pooq'
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.POOQZONE ='none'
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.REGION ='kor'
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.TARGETAGE ='all'
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.HTTPTAG ='https://'
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT=30 
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.EP_LIMIT =30 
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.MV_LIMIT =24 
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.guid ='none' 
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.guidtimestamp='none' 
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.DEFAULT_HEADER={'user-agent':IfrqlKMRdpUzbAtvgeDXwOjYkCFyuo}
 def callRequestCookies(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,jobtype,IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,redirects=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyuP=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.DEFAULT_HEADER
  if headers:IfrqlKMRdpUzbAtvgeDXwOjYkCFyuP.update(headers)
  if jobtype=='Get':
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuS=requests.get(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,params=params,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuP,cookies=cookies,allow_redirects=redirects)
  else:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuS=requests.post(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,data=payload,params=params,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuP,cookies=cookies,allow_redirects=redirects)
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyuS
 def SaveCredential(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,IfrqlKMRdpUzbAtvgeDXwOjYkCFyuh):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.CREDENTIAL=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuh
 def LoadCredential(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum):
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.CREDENTIAL
 def GetDefaultParams(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,login=IfrqlKMRdpUzbAtvgeDXwOjYkCFyms):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyua={'apikey':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.APIKEY,'credential':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.CREDENTIAL if login else 'none','device':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.DEVICE,'drm':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.DRM,'partner':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.PARTNER,'pooqzone':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.POOQZONE,'region':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.REGION,'targetage':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.TARGETAGE}
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyua
 def GetGUID(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuW=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuT=GenerateRandomString(5)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuH=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuT+media+IfrqlKMRdpUzbAtvgeDXwOjYkCFyuW
   return IfrqlKMRdpUzbAtvgeDXwOjYkCFyuH
  def GenerateRandomString(num):
   from random import randint
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyus=""
   for i in IfrqlKMRdpUzbAtvgeDXwOjYkCFymG(0,num):
    s=IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ(randint(1,5))
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyus+=s
   return IfrqlKMRdpUzbAtvgeDXwOjYkCFyus
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyuH=GenerateID(guid_str)
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyuG=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetHash(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuH)
  if guidType==2:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuG='%s-%s-%s-%s-%s'%(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuG[:8],IfrqlKMRdpUzbAtvgeDXwOjYkCFyuG[8:12],IfrqlKMRdpUzbAtvgeDXwOjYkCFyuG[12:16],IfrqlKMRdpUzbAtvgeDXwOjYkCFyuG[16:20],IfrqlKMRdpUzbAtvgeDXwOjYkCFyuG[20:])
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyuG
 def GetHash(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ(m.hexdigest())
 def CheckQuality(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,sel_qt,qt_list):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyuQ=0
  for IfrqlKMRdpUzbAtvgeDXwOjYkCFyui in qt_list:
   if sel_qt>=IfrqlKMRdpUzbAtvgeDXwOjYkCFyui:return IfrqlKMRdpUzbAtvgeDXwOjYkCFyui
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuQ=IfrqlKMRdpUzbAtvgeDXwOjYkCFyui
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyuQ
 def Get_Now_Datetime(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,in_text):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyuJ=in_text.replace('&lt;','<').replace('&gt;','>')
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyuJ=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuJ.replace('$O$','')
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyuJ=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuJ)
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyuJ=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuJ.lstrip('#')
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyuJ
 def GetCredential(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,user_id,user_pw,user_pf):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyuc=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+ '/login'
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams()
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyux={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Post',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFyux,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuh=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['credential']
   if user_pf!=0:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyux={'id':IfrqlKMRdpUzbAtvgeDXwOjYkCFyuh,'password':'','profile':IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ(user_pf),'pushid':'','type':'credential'}
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['credential']=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuh 
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Post',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFyux,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyuh=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['credential']
   if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuh:IfrqlKMRdpUzbAtvgeDXwOjYkCFyuc=IfrqlKMRdpUzbAtvgeDXwOjYkCFyms
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuh='none' 
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.SaveCredential(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuh)
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyuc
 def GetIssue(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyun=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+'/guid/issue'
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams()
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLu=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['guid']
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLo=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['guidtimestamp']
   if IfrqlKMRdpUzbAtvgeDXwOjYkCFyLu:IfrqlKMRdpUzbAtvgeDXwOjYkCFyun=IfrqlKMRdpUzbAtvgeDXwOjYkCFyms
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLu='none'
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLo='none' 
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.guid=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLu
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.guidtimestamp=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLo
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyun
 def Baseapi_Parse(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh):
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLm =urllib.parse.urlsplit(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh)
   if IfrqlKMRdpUzbAtvgeDXwOjYkCFyLm.netloc=='':
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.HTTPTAG+IfrqlKMRdpUzbAtvgeDXwOjYkCFyLm.netloc+IfrqlKMRdpUzbAtvgeDXwOjYkCFyLm.path
   else:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLm.scheme+'://'+IfrqlKMRdpUzbAtvgeDXwOjYkCFyLm.netloc+IfrqlKMRdpUzbAtvgeDXwOjYkCFyLm.path
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua=IfrqlKMRdpUzbAtvgeDXwOjYkCFymJ(urllib.parse.parse_qsl(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLm.query))
  except:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return '',{}
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,IfrqlKMRdpUzbAtvgeDXwOjYkCFyua
 def GetSupermultiUrl(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,sCode,sIndex='0'):
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+'/cf/supermultisections/'+sCode
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLP=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['multisectionlist'][IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(sIndex)]['eventlist'][1]['url']
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return ''
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyLP
 def Get_LiveCatagory_List(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,sCode,sIndex='0'):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS=[]
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh =IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetSupermultiUrl(sCode,sIndex)
  (IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,IfrqlKMRdpUzbAtvgeDXwOjYkCFyua)=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Baseapi_Parse(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh)
  if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=='':return IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS,''
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.update(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH))
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   if not('filter_item_list' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['filter']['filterlist'][0]):return[],''
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['filter']['filterlist'][0]['filter_item_list']
   for IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT in IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH={'title':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title'],'genre':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['api_parameters'][IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['api_parameters'].index('=')+1:]}
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS.append(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH)
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[],''
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh
 def Get_MainCatagory_List(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,sCode,sIndex='0'):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS=[]
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh =IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetSupermultiUrl(sCode,sIndex)
  (IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,IfrqlKMRdpUzbAtvgeDXwOjYkCFyua)=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Baseapi_Parse(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh)
  if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=='':return IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.update(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH))
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   if not('celllist' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['band']):return[]
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['band']['celllist']
   for IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT in IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLs =IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['event_list'][1]['url']
    (IfrqlKMRdpUzbAtvgeDXwOjYkCFyLG,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLQ)=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Baseapi_Parse(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLs)
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH={'title':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title_list'][0]['text'],'suburl':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLG,'subapi':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLQ.get('api'),'subtype':'catagory' if IfrqlKMRdpUzbAtvgeDXwOjYkCFyLQ else 'supersection'}
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS.append(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH)
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[]
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS
 def Get_SuperMultiSection_List(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,subapi_text):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS=[]
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLm =urllib.parse.urlsplit(subapi_text)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+'/cf'+IfrqlKMRdpUzbAtvgeDXwOjYkCFyLm.path 
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE.replace('supermultisection/','supermultisections/')
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[]
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   if not('multisectionlist' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB):return[]
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['multisectionlist']
   for IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT in IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLi=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title']
    if IfrqlKMRdpUzbAtvgeDXwOjYkCFymE(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLi)==0:continue
    if IfrqlKMRdpUzbAtvgeDXwOjYkCFyLi=='minor':continue 
    if re.search(u'베너',IfrqlKMRdpUzbAtvgeDXwOjYkCFyLi):continue
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLQ =IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['eventlist'][2]['url']
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLN=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['cell_type']
    if IfrqlKMRdpUzbAtvgeDXwOjYkCFyLN=='band_2':
     if IfrqlKMRdpUzbAtvgeDXwOjYkCFyLQ.find('channellist=')>=0:
      IfrqlKMRdpUzbAtvgeDXwOjYkCFyLN='band_live'
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH={'title':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Get_ChangeText(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLi),'subapi':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLQ,'cell_type':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLN}
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS.append(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS)
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[]
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyLS
 def Get_BandLiveSection_List(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh,page_int=1):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLJ=[]
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=1
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  try:
   (IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,IfrqlKMRdpUzbAtvgeDXwOjYkCFyua)=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Baseapi_Parse(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh)
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[],IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['limit']=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['offset']=IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ((page_int-1)*IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.update(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH))
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   if not('celllist' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']):return[],IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['celllist']
   for IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT in IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLx =IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['event_list'][1]['url']
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV=urllib.parse.urlsplit(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLx).query
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV=IfrqlKMRdpUzbAtvgeDXwOjYkCFymJ(urllib.parse.parse_qsl(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV))
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB='channelid'
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV[IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB]
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH={'studio':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title_list'][0]['text'],'tvshowtitle':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Get_ChangeText(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title_list'][1]['text']),'channelid':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn,'age':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('age'),'thumbnail':'https://%s'%IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('thumbnail')}
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLJ.append(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['pagecount'])
   if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['count']:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou =IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['count'])
   else:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT*page_int
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc>IfrqlKMRdpUzbAtvgeDXwOjYkCFyou
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[],IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyLJ,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE
 def Get_Band2Section_List(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh,page_int=1):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyoL=[]
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=1
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  try:
   (IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,IfrqlKMRdpUzbAtvgeDXwOjYkCFyua)=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Baseapi_Parse(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh)
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[],IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['came'] ='BandView'
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['limit']=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['offset']=IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ((page_int-1)*IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.update(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH))
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   if not('celllist' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']):return[],IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['celllist']
   for IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT in IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLx =IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['event_list'][1]['url']
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV=urllib.parse.urlsplit(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLx).query
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV=IfrqlKMRdpUzbAtvgeDXwOjYkCFymJ(urllib.parse.parse_qsl(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV))
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB='contentid'
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV[IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB]
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH={'programtitle':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title_list'][0]['text'],'episodetitle':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Get_ChangeText(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title_list'][1]['text']),'age':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('age'),'thumbnail':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.HTTPTAG+IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('thumbnail'),'vidtype':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB,'videoid':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn}
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyoL.append(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['pagecount'])
   if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['count']:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou =IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['count'])
   else:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT*page_int
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc>IfrqlKMRdpUzbAtvgeDXwOjYkCFyou
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[],IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyoL,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE
 def Get_Program_List(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh,page_int=1,orderby='-'):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyom=[]
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=1
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  (IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,IfrqlKMRdpUzbAtvgeDXwOjYkCFyua)=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Baseapi_Parse(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh)
  if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=='':return IfrqlKMRdpUzbAtvgeDXwOjYkCFyom,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['limit'] =IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['offset']=IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ((page_int-1)*IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['page'] =IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ(page_int)
   if IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.get('orderby')!='' and IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.get('orderby')!='regdatefirst' and orderby!='-':
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['orderby']=orderby 
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.update(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH))
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   if not('celllist' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']):return IfrqlKMRdpUzbAtvgeDXwOjYkCFyom,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['celllist']
   for IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT in IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLx =IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['event_list'][1]['url']
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV=urllib.parse.urlsplit(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLx).query
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV[0:IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV.find('=')]
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV[IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV.find('=')+1:]
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH={'title':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title_list'][0]['text'],'age':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['age'],'thumbnail':'https://%s'%IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('thumbnail'),'videoid':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn,'vidtype':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB}
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyom.append(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['pagecount'])
   if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['count']:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou =IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['count'])
   else:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT*page_int
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc>IfrqlKMRdpUzbAtvgeDXwOjYkCFyou
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[],IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyom,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE
 def Get_Movie_List(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh,page_int=1):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyoP=[]
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=1
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  (IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,IfrqlKMRdpUzbAtvgeDXwOjYkCFyua)=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Baseapi_Parse(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh)
  if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=='':return IfrqlKMRdpUzbAtvgeDXwOjYkCFyoP,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['limit']=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.MV_LIMIT
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['offset']=IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ((page_int-1)*IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.MV_LIMIT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.update(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH))
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   if not('celllist' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']):return IfrqlKMRdpUzbAtvgeDXwOjYkCFyoP,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['celllist']
   for IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT in IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLx =IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['event_list'][1]['url']
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV=urllib.parse.urlsplit(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLx).query
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV[0:IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV.find('=')]
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV[IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV.find('=')+1:]
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH={'title':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title_list'][0]['text'],'age':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['age'],'thumbnail':'https://%s'%IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('thumbnail'),'videoid':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn,'vidtype':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB}
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyoP.append(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['pagecount'])
   if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['count']:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou =IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['count'])
   else:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.MV_LIMIT*page_int
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc>IfrqlKMRdpUzbAtvgeDXwOjYkCFyou
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[],IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyoP,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE
 def ChangeToProgramid(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,IfrqlKMRdpUzbAtvgeDXwOjYkCFyoc):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyoS=''
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE =IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+'/cf/vod/contents/'+IfrqlKMRdpUzbAtvgeDXwOjYkCFyoc
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyoh=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   if not('programid' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyoh):return IfrqlKMRdpUzbAtvgeDXwOjYkCFyoS 
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyoS=IfrqlKMRdpUzbAtvgeDXwOjYkCFyoh['programid']
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyoS
 def Get_Episode_List(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB,page_int=1,orderby='desc'):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyoa=[]
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=1
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  if IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB=='contentid':
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyoS=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.ChangeToProgramid(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn)
  else:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyoS=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+'/vod/programs-contents/'+IfrqlKMRdpUzbAtvgeDXwOjYkCFyoS
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua={}
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['limit'] =IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.EP_LIMIT
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['offset']=IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ((page_int-1)*IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.EP_LIMIT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['orderby']=orderby 
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.update(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH))
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['list']
   for IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT in IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyoT=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('synopsis'))
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH={'programtitle':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('programtitle'),'episodetitle':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('episodetitle'),'episodenumber':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('episodenumber'),'releasedate':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('releasedate'),'releaseweekday':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('releaseweekday'),'programid':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('programid'),'contentid':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('contentid'),'age':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('targetage'),'playtime':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('playtime'),'synopsis':IfrqlKMRdpUzbAtvgeDXwOjYkCFyoT,'episodeactors':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('episodeactors').split(','),'thumbnail':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.HTTPTAG+IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('image')}
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyoa.append(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['pagecount'])
   if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['count']:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou =IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['count'])
   else:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.EP_LIMIT*page_int
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc>IfrqlKMRdpUzbAtvgeDXwOjYkCFyou
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[],IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyoa,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE
 def GetEPGList(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,genre):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyoH={}
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyos=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Get_Now_Datetime()
   if genre=='all':
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyoG =IfrqlKMRdpUzbAtvgeDXwOjYkCFyos+datetime.timedelta(hours=3)
   else:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyoG =IfrqlKMRdpUzbAtvgeDXwOjYkCFyos+datetime.timedelta(hours=3)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+'/live/epgs'
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua={'limit':'100','offset':'0','genre':genre,'startdatetime':IfrqlKMRdpUzbAtvgeDXwOjYkCFyos.strftime('%Y-%m-%d %H:00'),'enddatetime':IfrqlKMRdpUzbAtvgeDXwOjYkCFyoG.strftime('%Y-%m-%d %H:00')}
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.update(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH))
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyoQ=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['list']
   for IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT in IfrqlKMRdpUzbAtvgeDXwOjYkCFyoQ:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyoi=''
    for IfrqlKMRdpUzbAtvgeDXwOjYkCFyoN in IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['list']:
     if IfrqlKMRdpUzbAtvgeDXwOjYkCFyoi:IfrqlKMRdpUzbAtvgeDXwOjYkCFyoi+='\n'
     IfrqlKMRdpUzbAtvgeDXwOjYkCFyoi+=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Get_ChangeText(IfrqlKMRdpUzbAtvgeDXwOjYkCFyoN['title'])+'\n'
     IfrqlKMRdpUzbAtvgeDXwOjYkCFyoi+=' [%s ~ %s]'%(IfrqlKMRdpUzbAtvgeDXwOjYkCFyoN['starttime'][-5:],IfrqlKMRdpUzbAtvgeDXwOjYkCFyoN['endtime'][-5:])+'\n'
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyoH[IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['channelid']]=IfrqlKMRdpUzbAtvgeDXwOjYkCFyoi
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyoH
 def Get_LiveChannel_List(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,genre,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLJ=[]
  (IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,IfrqlKMRdpUzbAtvgeDXwOjYkCFyua)=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Baseapi_Parse(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLh)
  if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=='':return IfrqlKMRdpUzbAtvgeDXwOjYkCFyLJ
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyoJ=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetEPGList(genre)
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.update(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH))
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua['genre']=genre
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   if not('celllist' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']):return[]
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['cell_toplist']['celllist']
   for IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT in IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyoc=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['contentid']
    if IfrqlKMRdpUzbAtvgeDXwOjYkCFyoc in IfrqlKMRdpUzbAtvgeDXwOjYkCFyoJ:
     IfrqlKMRdpUzbAtvgeDXwOjYkCFyoE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyoJ[IfrqlKMRdpUzbAtvgeDXwOjYkCFyoc]
    else:
     IfrqlKMRdpUzbAtvgeDXwOjYkCFyoE=''
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH={'studio':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title_list'][0]['text'],'tvshowtitle':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.Get_ChangeText(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title_list'][1]['text']),'channelid':IfrqlKMRdpUzbAtvgeDXwOjYkCFyoc,'age':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['age'],'thumbnail':'https://%s'%IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('thumbnail'),'epg':IfrqlKMRdpUzbAtvgeDXwOjYkCFyoE}
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLJ.append(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH)
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return[]
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyLJ
 def Get_Search_List(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,search_key,sType,page_int,exclusion21=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyox=[]
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=1
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+'/cf/search/list.js'
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ((page_int-1)*IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT),'limit':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT,'orderby':'score'}
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.update(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH))
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyoh=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   if not('celllist' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyoh['cell_toplist']):return IfrqlKMRdpUzbAtvgeDXwOjYkCFyox,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW=IfrqlKMRdpUzbAtvgeDXwOjYkCFyoh['cell_toplist']['celllist']
   for IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT in IfrqlKMRdpUzbAtvgeDXwOjYkCFyLW:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLx =IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['event_list'][1]['url']
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV=urllib.parse.urlsplit(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLx).query
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV[0:IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV.find('=')]
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV[IfrqlKMRdpUzbAtvgeDXwOjYkCFyLV.find('=')+1:]
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH={'title':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['title_list'][0]['text'],'age':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT['age'],'thumbnail':'https://%s'%IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('thumbnail'),'videoid':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLn,'vidtype':IfrqlKMRdpUzbAtvgeDXwOjYkCFyLB}
    if exclusion21==IfrqlKMRdpUzbAtvgeDXwOjYkCFymH or IfrqlKMRdpUzbAtvgeDXwOjYkCFyLT.get('age')!='21':
     IfrqlKMRdpUzbAtvgeDXwOjYkCFyox.append(IfrqlKMRdpUzbAtvgeDXwOjYkCFyLH)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc=IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyoh['cell_toplist']['pagecount'])
   if IfrqlKMRdpUzbAtvgeDXwOjYkCFyoh['cell_toplist']['count']:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou =IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFyoh['cell_toplist']['count'])
   else:IfrqlKMRdpUzbAtvgeDXwOjYkCFyou=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.LIST_LIMIT
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyLc>IfrqlKMRdpUzbAtvgeDXwOjYkCFyou
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
  return IfrqlKMRdpUzbAtvgeDXwOjYkCFyox,IfrqlKMRdpUzbAtvgeDXwOjYkCFyLE 
 def GetStreamingURL(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum,mode,IfrqlKMRdpUzbAtvgeDXwOjYkCFyoc,quality_int,pvrmode='-'):
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyoV=IfrqlKMRdpUzbAtvgeDXwOjYkCFymh=IfrqlKMRdpUzbAtvgeDXwOjYkCFyma=streaming_preview=''
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyoB=[]
  IfrqlKMRdpUzbAtvgeDXwOjYkCFyon='hls'
  if mode=='LIVE':
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE =IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+'/live/channels/'+IfrqlKMRdpUzbAtvgeDXwOjYkCFyoc
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymu='live'
  elif mode=='VOD':
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE =IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+'/cf/vod/contents/'+IfrqlKMRdpUzbAtvgeDXwOjYkCFyoc
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymu='vod'
  elif mode=='MOVIE':
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE =IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+'/cf/movie/contents/'+IfrqlKMRdpUzbAtvgeDXwOjYkCFyoc
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymu='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyua=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFymH)
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
    IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
    IfrqlKMRdpUzbAtvgeDXwOjYkCFymL=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['qualities']['list']
    if IfrqlKMRdpUzbAtvgeDXwOjYkCFymL==IfrqlKMRdpUzbAtvgeDXwOjYkCFymT:return(IfrqlKMRdpUzbAtvgeDXwOjYkCFyoV,IfrqlKMRdpUzbAtvgeDXwOjYkCFymh,IfrqlKMRdpUzbAtvgeDXwOjYkCFyma,streaming_preview)
    for IfrqlKMRdpUzbAtvgeDXwOjYkCFymo in IfrqlKMRdpUzbAtvgeDXwOjYkCFymL:
     IfrqlKMRdpUzbAtvgeDXwOjYkCFyoB.append(IfrqlKMRdpUzbAtvgeDXwOjYkCFymc(IfrqlKMRdpUzbAtvgeDXwOjYkCFymo.get('id').rstrip('p')))
    if 'type' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB:
     if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['type']=='onair':
      IfrqlKMRdpUzbAtvgeDXwOjYkCFymu='onairvod'
    if 'drms' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB:
     if IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['drms']:
      IfrqlKMRdpUzbAtvgeDXwOjYkCFyon='dash'
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
   return(IfrqlKMRdpUzbAtvgeDXwOjYkCFyoV,IfrqlKMRdpUzbAtvgeDXwOjYkCFymh,IfrqlKMRdpUzbAtvgeDXwOjYkCFyma,streaming_preview)
  try:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymP=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.CheckQuality(quality_int,IfrqlKMRdpUzbAtvgeDXwOjYkCFyoB)
   if mode=='LIVE' and pvrmode!='-':
    IfrqlKMRdpUzbAtvgeDXwOjYkCFymS='auto'
   else:
    IfrqlKMRdpUzbAtvgeDXwOjYkCFymS=IfrqlKMRdpUzbAtvgeDXwOjYkCFymQ(IfrqlKMRdpUzbAtvgeDXwOjYkCFymP)+'p'
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.API_DOMAIN+'/streaming'
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua={'contentid':IfrqlKMRdpUzbAtvgeDXwOjYkCFyoc,'contenttype':IfrqlKMRdpUzbAtvgeDXwOjYkCFymu,'action':IfrqlKMRdpUzbAtvgeDXwOjYkCFyon,'quality':IfrqlKMRdpUzbAtvgeDXwOjYkCFymS,'deviceModelId':'Windows 10','guid':IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyua.update(IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.GetDefaultParams(login=IfrqlKMRdpUzbAtvgeDXwOjYkCFyms))
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyum.callRequestCookies('Get',IfrqlKMRdpUzbAtvgeDXwOjYkCFyuE,payload=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,params=IfrqlKMRdpUzbAtvgeDXwOjYkCFyua,headers=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT,cookies=IfrqlKMRdpUzbAtvgeDXwOjYkCFymT)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB=json.loads(IfrqlKMRdpUzbAtvgeDXwOjYkCFyuV.text)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyoV=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['playurl']
   if IfrqlKMRdpUzbAtvgeDXwOjYkCFyoV==IfrqlKMRdpUzbAtvgeDXwOjYkCFymT:return(IfrqlKMRdpUzbAtvgeDXwOjYkCFyoV,IfrqlKMRdpUzbAtvgeDXwOjYkCFymh,IfrqlKMRdpUzbAtvgeDXwOjYkCFyma,streaming_preview)
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymh=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['awscookie']
   IfrqlKMRdpUzbAtvgeDXwOjYkCFyma =IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['drm']
   if 'previewmsg' in IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['preview']:streaming_preview=IfrqlKMRdpUzbAtvgeDXwOjYkCFyuB['preview']['previewmsg']
  except IfrqlKMRdpUzbAtvgeDXwOjYkCFymi as exception:
   IfrqlKMRdpUzbAtvgeDXwOjYkCFymN(exception)
  return(IfrqlKMRdpUzbAtvgeDXwOjYkCFyoV,IfrqlKMRdpUzbAtvgeDXwOjYkCFymh,IfrqlKMRdpUzbAtvgeDXwOjYkCFyma,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
