__author__="NightRain"
LrHTsdbBvgKIhRmwJYaUpNuWFDtxqP=object
LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA=None
LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc=False
LrHTsdbBvgKIhRmwJYaUpNuWFDtxqe=open
LrHTsdbBvgKIhRmwJYaUpNuWFDtxql=True
LrHTsdbBvgKIhRmwJYaUpNuWFDtxqV=range
LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy=str
LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS=Exception
LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ=print
LrHTsdbBvgKIhRmwJYaUpNuWFDtxqi=dict
LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG=int
LrHTsdbBvgKIhRmwJYaUpNuWFDtxqz=len
import urllib
import re
import json
import sys
import requests
import datetime
import base64
class LrHTsdbBvgKIhRmwJYaUpNuWFDtxkE(LrHTsdbBvgKIhRmwJYaUpNuWFDtxqP):
 def __init__(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN='https://apis.wavve.com'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV ={}
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Init_WV_Total()
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.DEVICE ='pc'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.DRM ='wm'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.PARTNER ='pooq'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.POOQZONE ='none'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.REGION ='kor'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.TARGETAGE ='all'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.HTTPTAG ='https://'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.LIST_LIMIT=30 
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.EP_LIMIT =30 
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.MV_LIMIT =24 
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.SEARCH_LIMIT=20 
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.DEFAULT_HEADER={'user-agent':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.USER_AGENT}
 def Init_WV_Total(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV={'account':{},'cookies':{},}
 def callRequestCookies(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,jobtype,LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,redirects=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkn=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.DEFAULT_HEADER
  if headers:LrHTsdbBvgKIhRmwJYaUpNuWFDtxkn.update(headers)
  if jobtype=='Get':
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkf=requests.get(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,params=params,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkn,cookies=cookies,allow_redirects=redirects)
  else:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkf=requests.post(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,data=payload,params=params,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkn,cookies=cookies,allow_redirects=redirects)
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxkf
 def JsonFile_Save(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,filename,LrHTsdbBvgKIhRmwJYaUpNuWFDtxkq):
  if filename=='':return LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  try:
   fp=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqe(filename,'w',-1,'utf-8')
   json.dump(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkq,fp,indent=4,ensure_ascii=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc)
   fp.close()
  except:
   return LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxql
 def JsonFile_Load(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,filename):
  if filename=='':return{}
  try:
   fp=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqe(filename,'r',-1,'utf-8')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkM=json.load(fp)
   fp.close()
  except:
   return{}
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxkM
 def Save_session_acount(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,LrHTsdbBvgKIhRmwJYaUpNuWFDtxkP,LrHTsdbBvgKIhRmwJYaUpNuWFDtxkA,LrHTsdbBvgKIhRmwJYaUpNuWFDtxkc):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['account']['wvid']=base64.standard_b64encode(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkP.encode()).decode('utf-8')
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['account']['wvpw']=base64.standard_b64encode(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkA.encode()).decode('utf-8')
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['account']['wvpf']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkc 
 def Load_session_acount(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC):
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkP=base64.standard_b64decode(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['account']['wvid']).decode('utf-8')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkA=base64.standard_b64decode(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['account']['wvpw']).decode('utf-8')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkc=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['account']['wvpf']
  except:
   return '','',0
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxkP,LrHTsdbBvgKIhRmwJYaUpNuWFDtxkA,LrHTsdbBvgKIhRmwJYaUpNuWFDtxkc
 def GetDefaultParams(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxql):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxke={'apikey':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.APIKEY,'credential':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['cookies']['credential']if login else 'none','device':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.DEVICE,'drm':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.DRM,'partner':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.PARTNER,'pooqzone':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.POOQZONE,'region':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.REGION,'targetage':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.TARGETAGE,}
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxke
 def GetDefaultParams_AND(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxke={'apikey':'6A87455D54481A536DFB8AD397C5EC4D','credential':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['cookies']['credential'],'device':'ott','drm':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.DRM,'partner':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.PARTNER,'pooqzone':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.POOQZONE,'region':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.REGION,'targetage':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.TARGETAGE,}
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxke
 def GetGUID(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkl=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkV=GenerateRandomString(5)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxky=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkV+media+LrHTsdbBvgKIhRmwJYaUpNuWFDtxkl
   return LrHTsdbBvgKIhRmwJYaUpNuWFDtxky
  def GenerateRandomString(num):
   from random import randint
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkS=""
   for i in LrHTsdbBvgKIhRmwJYaUpNuWFDtxqV(0,num):
    s=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy(randint(1,5))
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxkS+=s
   return LrHTsdbBvgKIhRmwJYaUpNuWFDtxkS
  if guidType==3:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxky=guid_str
  else:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxky=GenerateID(guid_str)
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkQ=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetHash(LrHTsdbBvgKIhRmwJYaUpNuWFDtxky)
  if guidType in[2,3]:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkQ='%s-%s-%s-%s-%s'%(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkQ[:8],LrHTsdbBvgKIhRmwJYaUpNuWFDtxkQ[8:12],LrHTsdbBvgKIhRmwJYaUpNuWFDtxkQ[12:16],LrHTsdbBvgKIhRmwJYaUpNuWFDtxkQ[16:20],LrHTsdbBvgKIhRmwJYaUpNuWFDtxkQ[20:])
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxkQ
 def GetHash(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy(m.hexdigest())
 def CheckQuality(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,sel_qt,qt_list):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxki=0
  for LrHTsdbBvgKIhRmwJYaUpNuWFDtxkG in qt_list:
   if sel_qt>=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkG:return LrHTsdbBvgKIhRmwJYaUpNuWFDtxkG
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxki=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkG
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxki
 def Get_Now_Datetime(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,in_text):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkO=in_text.replace('&lt;','<').replace('&gt;','>')
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkO=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkO.replace('$O$','')
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkO=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkO)
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkO=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkO.lstrip('#')
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxkO
 def GetCredential(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,user_id,user_pw,user_pf):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkj=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+ '/login'
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEk={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Post',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEk,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['cookies']['credential']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['credential']
   if user_pf!=0:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEk={'id':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['cookies']['credential'],'password':'','profile':LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy(user_pf),'pushid':'','type':'credential'}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxke =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxql) 
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Post',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEk,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['cookies']['credential']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['credential']
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEf=user_id+LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy(user_pf) 
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['cookies']['uuid']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetGUID(guid_str=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEf,guidType=3)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkj=LrHTsdbBvgKIhRmwJYaUpNuWFDtxql
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Init_WV_Total()
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxkj
 def GetIssue(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEq=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/guid/issue'
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams()
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEo=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['guid']
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEM=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['guidtimestamp']
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEo:LrHTsdbBvgKIhRmwJYaUpNuWFDtxEq=LrHTsdbBvgKIhRmwJYaUpNuWFDtxql
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEo='none'
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEM='none' 
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.guid=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEo
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.guidtimestamp=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEM
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxEq
 def Baseapi_Parse(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe):
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP =urllib.parse.urlsplit(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe)
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP.netloc=='':
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.HTTPTAG+LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP.netloc+LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP.path
   else:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP.scheme+'://'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP.netloc+LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP.path
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqi(urllib.parse.parse_qsl(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP.query))
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return '',{}
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,LrHTsdbBvgKIhRmwJYaUpNuWFDtxke
 def GetSupermultiUrl(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,sCode,sIndex='0'):
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/cf/supermultisections/'+sCode
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEA=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['multisectionlist'][LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(sIndex)]['eventlist'][1]['url']
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return ''
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxEA
 def Get_LiveCatagory_List(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,sCode,sIndex='0'):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc=[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetSupermultiUrl(sCode,sIndex)
  (LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,LrHTsdbBvgKIhRmwJYaUpNuWFDtxke)=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Baseapi_Parse(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe)
  if LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=='':return LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc,''
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('filter_item_list' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['filter']['filterlist'][0]):return[],''
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['filter']['filterlist'][0]['filter_item_list']
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'title':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title'],'genre':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['api_parameters'][LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['api_parameters'].index('=')+1:]}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[],''
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc,LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe
 def Get_MainCatagory_List(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,sCode,sIndex='0'):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc=[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetSupermultiUrl(sCode,sIndex)
  (LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,LrHTsdbBvgKIhRmwJYaUpNuWFDtxke)=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Baseapi_Parse(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe)
  if LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=='':return LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('celllist' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['band']):return[]
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['band']['celllist']
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEQ =LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['event_list'][1]['url']
    (LrHTsdbBvgKIhRmwJYaUpNuWFDtxEi,LrHTsdbBvgKIhRmwJYaUpNuWFDtxEG)=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Baseapi_Parse(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEQ)
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'title':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title_list'][0]['text'],'suburl':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEi,'subapi':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEG.get('api'),'subtype':'catagory' if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEG else 'supersection'}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[]
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc
 def Get_SuperMultiSection_List(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,subapi_text):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc=[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxke={}
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP =urllib.parse.urlsplit(subapi_text)
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP.path.find('apis.wavve.com')>=0: 
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.HTTPTAG+LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP.path 
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqi(urllib.parse.parse_qsl(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP.query))
   else:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/cf'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxEP.path 
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX.replace('supermultisection/','supermultisections/')
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[]
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('multisectionlist' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn):return[]
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['multisectionlist']
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEz=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title']
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqz(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEz)==0:continue
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEz=='minor':continue
    if re.search(u'베너',LrHTsdbBvgKIhRmwJYaUpNuWFDtxEz):continue
    if re.search(u'배너',LrHTsdbBvgKIhRmwJYaUpNuWFDtxEz):continue 
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['force_refresh']=='y':continue
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqz(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['eventlist'])>=3:
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxEG =LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['eventlist'][2]['url']
    else:
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxEG =LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['eventlist'][1]['url']
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEO=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['cell_type']
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEO=='band_2':
     if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEG.find('channellist=')>=0:
      LrHTsdbBvgKIhRmwJYaUpNuWFDtxEO='band_live'
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'title':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Get_ChangeText(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEz),'subapi':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEG,'cell_type':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEO}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[]
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc
 def Get_BandLiveSection_List(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe,page_int=1):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEj=[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=1
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  try:
   (LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,LrHTsdbBvgKIhRmwJYaUpNuWFDtxke)=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Baseapi_Parse(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe)
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[],LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['limit']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.LIST_LIMIT
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['offset']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy((page_int-1)*LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.LIST_LIMIT)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('celllist' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']):return[],LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['celllist']
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCE =LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['event_list'][1]['url']
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn=urllib.parse.urlsplit(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCE).query
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqi(urllib.parse.parse_qsl(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn))
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf='channelid'
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn[LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf]
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'studio':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title_list'][0]['text'],'tvshowtitle':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Get_ChangeText(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title_list'][1]['text']),'channelid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq,'age':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('age'),'thumbnail':'https://%s'%LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('thumbnail')}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEj.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['pagecount'])
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['count']:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['count'])
   else:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.LIST_LIMIT*page_int
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX>LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[],LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxEj,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk
 def Get_Band2Section_List(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe,page_int=1):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCM=[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=1
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  try:
   (LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,LrHTsdbBvgKIhRmwJYaUpNuWFDtxke)=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Baseapi_Parse(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe)
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[],LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['came'] ='BandView'
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['limit']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.LIST_LIMIT
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['offset']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy((page_int-1)*LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.LIST_LIMIT)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('celllist' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']):return[],LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['celllist']
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCE =LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['event_list'][1]['url']
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn=urllib.parse.urlsplit(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCE).query
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqi(urllib.parse.parse_qsl(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn))
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf='contentid'
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn[LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf]
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'programtitle':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title_list'][0]['text'],'episodetitle':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Get_ChangeText(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title_list'][1]['text']),'age':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('age'),'thumbnail':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.HTTPTAG+LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('thumbnail'),'vidtype':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf,'videoid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCM.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['pagecount'])
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['count']:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['count'])
   else:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.LIST_LIMIT*page_int
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX>LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[],LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCM,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk
 def Get_Program_List(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe,page_int=1,orderby='-'):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCP=[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=1
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  (LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,LrHTsdbBvgKIhRmwJYaUpNuWFDtxke)=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Baseapi_Parse(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe)
  if LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=='':return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCP,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['limit'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.LIST_LIMIT
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['offset']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy((page_int-1)*LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.LIST_LIMIT)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['page'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy(page_int)
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.get('orderby')!='' and LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.get('orderby')!='regdatefirst' and orderby!='-':
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['orderby']=orderby 
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe.find('instantplay')>=0:
    if not('celllist' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['band']):return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCP,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['band']['celllist']
   else:
    if not('celllist' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']):return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCP,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['celllist']
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV:
    for LrHTsdbBvgKIhRmwJYaUpNuWFDtxCA in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['event_list']:
     if LrHTsdbBvgKIhRmwJYaUpNuWFDtxCA.get('type')=='on-navigation':
      LrHTsdbBvgKIhRmwJYaUpNuWFDtxCE =LrHTsdbBvgKIhRmwJYaUpNuWFDtxCA['url']
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn=urllib.parse.urlsplit(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCE).query
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn[0:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn.find('=')]
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn[LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn.find('=')+1:]
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'title':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['alt'],'age':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['age'],'thumbnail':'https://%s'%LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('thumbnail'),'videoid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq,'vidtype':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf,}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCP.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe.find('instantplay')<0:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['pagecount'])
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['count']:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['count'])
    else:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.LIST_LIMIT*page_int
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX>LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[],LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCP,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk
 def Get_Movie_List(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe,page_int=1,orderby='-'):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCc=[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=1
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  (LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,LrHTsdbBvgKIhRmwJYaUpNuWFDtxke)=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Baseapi_Parse(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe)
  if LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=='':return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCc,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['limit']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.MV_LIMIT
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['offset']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy((page_int-1)*LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.MV_LIMIT)
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.get('orderby')!='' and LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.get('orderby')!='regdatefirst' and orderby!='-':
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['orderby']=orderby 
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('celllist' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']):return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCc,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['celllist']
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCE =LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['event_list'][1]['url']
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn=urllib.parse.urlsplit(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCE).query
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn[0:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn.find('=')]
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn[LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn.find('=')+1:]
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'title':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['alt'],'age':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['age'],'thumbnail':'https://%s'%LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('thumbnail'),'videoid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq,'vidtype':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf,}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCc.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['pagecount'])
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['count']:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['count'])
   else:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.MV_LIMIT*page_int
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX>LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[],LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCc,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk
 def ProgramidToContentid(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCV):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe=''
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/vod/programs-contentid/'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxCV
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('contentid' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl):return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe 
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl['contentid']
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe
 def ContentidToSeasonid(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCV=''
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/fz/vod/contents/'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('programid' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl):return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCV 
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl['programid']
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCV
 def GetProgramInfo(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCy={}
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/fz/vod/contents/'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCS=img_fanart=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCQ=''
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl.get('programposterimage')!='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCS =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.HTTPTAG+LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl.get('programposterimage')
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl.get('programimage') !='':img_fanart =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.HTTPTAG+LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl.get('programimage')
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl.get('programcircleimage')!='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCQ=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.HTTPTAG+LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl.get('programcircleimage')
   if 'poster_default' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxCS:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCS =img_fanart
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCQ=''
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCy={'imgPoster':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCS,'imgFanart':img_fanart,'imgClearlogo':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCQ,'programtitle':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl.get('programtitle'),'programid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl.get('programid'),'synopsis':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl.get('programsynopsis').replace('<br>','\n'),}
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCy
 def Get_Season_List(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,seasonid):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCi=[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.ProgramidToContentid(seasonid)
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetProgramInfo(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe)
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCz={'poster':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG.get('imgPoster'),'fanart':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG.get('imgFanart'),'clearlogo':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG.get('imgClearlogo'),}
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/fz/vod/programs-contents/'+seasonid
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke={'limit':'10','offset':'0','orderby':'new',}
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxCO in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['filter']['filterlist'][0]['filter_item_list']:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'season_Nm':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCO.get('title'),'season_Id':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCO.get('api_path'),'thumbnail':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCz,'programNm':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG.get('programtitle'),'synopsis':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG.get('synopsis'),}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCi.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[]
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCi
 def Get_Episode_List(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,seasionid,page_int=1,orderby='desc'):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCj=[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=1
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG={}
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.ProgramidToContentid(seasionid)
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetProgramInfo(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/fz/vod/programs-contents/'+seasionid
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke={'limit':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.EP_LIMIT,'offset':LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy((page_int-1)*LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.EP_LIMIT),'orderby':orderby,}
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['celllist']
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnk=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('synopsis'))
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnE=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.HTTPTAG+LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('thumbnail')
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxnf=LrHTsdbBvgKIhRmwJYaUpNuWFDtxnq=''
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnC =LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG.get('imgPoster')
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnf =LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG.get('imgFanart')
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnq =LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG.get('imgClearlogo')
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxno=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCG.get('programtitle')
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCz={'thumb':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnE,'poster':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnC,'fanart':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnf,'clearlogo':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnq}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'programtitle':LrHTsdbBvgKIhRmwJYaUpNuWFDtxno,'episodetitle':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title_list'][0]['text'],'episodenumber':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title_list'][1]['text'].replace('$O$',''),'contentid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['contentid'],'synopsis':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnk,'episodeactors':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('actors').split(',')if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('actors')!='' else[],'thumbnail':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCz,}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCj.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['pagecount'])
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['count']:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['count'])
   else:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.EP_LIMIT*page_int
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX>LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[],LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxCj,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk
 def GetEPGList(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,genre):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxnM={}
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnP=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Get_Now_Datetime()
   if genre=='all':
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnA =LrHTsdbBvgKIhRmwJYaUpNuWFDtxnP+datetime.timedelta(hours=3)
   else:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnA =LrHTsdbBvgKIhRmwJYaUpNuWFDtxnP+datetime.timedelta(hours=3)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/live/epgs'
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke={'limit':'100','offset':'0','genre':genre,'startdatetime':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnP.strftime('%Y-%m-%d %H:00'),'enddatetime':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnA.strftime('%Y-%m-%d %H:00')}
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnc=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['list']
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxnc:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxne=''
    for LrHTsdbBvgKIhRmwJYaUpNuWFDtxnl in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['list']:
     if LrHTsdbBvgKIhRmwJYaUpNuWFDtxne:LrHTsdbBvgKIhRmwJYaUpNuWFDtxne+='\n'
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxne+=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Get_ChangeText(LrHTsdbBvgKIhRmwJYaUpNuWFDtxnl['title'])+'\n'
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxne+=' [%s ~ %s]'%(LrHTsdbBvgKIhRmwJYaUpNuWFDtxnl['starttime'][-5:],LrHTsdbBvgKIhRmwJYaUpNuWFDtxnl['endtime'][-5:])+'\n'
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnM[LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['channelid']]=LrHTsdbBvgKIhRmwJYaUpNuWFDtxne
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxnM
 def Get_LiveChannel_List(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,genre,LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEj=[]
  (LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,LrHTsdbBvgKIhRmwJYaUpNuWFDtxke)=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Baseapi_Parse(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEe)
  if LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=='':return LrHTsdbBvgKIhRmwJYaUpNuWFDtxEj
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxnV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetEPGList(genre)
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['genre']=genre
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('celllist' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']):return[]
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['celllist']
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['contentid']
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe in LrHTsdbBvgKIhRmwJYaUpNuWFDtxnV:
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxny=LrHTsdbBvgKIhRmwJYaUpNuWFDtxnV[LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe]
    else:
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxny=''
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'studio':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title_list'][0]['text'],'tvshowtitle':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Get_ChangeText(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title_list'][1]['text']),'channelid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe,'age':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['age'],'thumbnail':'https://%s'%LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('thumbnail'),'epg':LrHTsdbBvgKIhRmwJYaUpNuWFDtxny}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEj.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[]
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxEj
 def Get_Search_List(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,search_key,sType,page_int,exclusion21=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxnS=[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=1
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/fz/search/band.js'
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy((page_int-1)*LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.SEARCH_LIMIT),'limit':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.SEARCH_LIMIT,'orderby':'score','mtype':'svod',}
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('celllist' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl['band']):return LrHTsdbBvgKIhRmwJYaUpNuWFDtxnS,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl['band']['celllist']
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCE =LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['event_list'][1]['url']
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn=urllib.parse.urlsplit(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCE).query
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn[0:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn.find('=')]
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn[LrHTsdbBvgKIhRmwJYaUpNuWFDtxCn.find('=')+1:]
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'title':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['title_list'][0]['text'],'age':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['age'],'thumbnail':'https://%s'%LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('thumbnail'),'videoid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq,'vidtype':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf,}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnQ=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc
    for LrHTsdbBvgKIhRmwJYaUpNuWFDtxni in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy['bottom_taglist']:
     if LrHTsdbBvgKIhRmwJYaUpNuWFDtxni=='won':
      LrHTsdbBvgKIhRmwJYaUpNuWFDtxnQ=LrHTsdbBvgKIhRmwJYaUpNuWFDtxql
      break
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxnQ==LrHTsdbBvgKIhRmwJYaUpNuWFDtxql: 
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxES['title']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxES['title']+' [개별구매]'
    if exclusion21==LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc or LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('age')!='21':
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxnS.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl['band']['pagecount'])
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl['band']['count']:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCl['band']['count'])
   else:LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.LIST_LIMIT
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEX>LrHTsdbBvgKIhRmwJYaUpNuWFDtxCo
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxnS,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCk 
 def GetSecureToken(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/ip'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc)
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['securetoken']
 def GetStreamingURL(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,mode,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe,quality_int,pvrmode='-',playOption={}):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxnz=[]
  if mode=='LIVE':
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/live/channels/'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnO='live'
  elif mode=='VOD':
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/fz/vod/contents/'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnO='vod'
  elif mode=='MOVIE':
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/fz/movie/contents/'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnO='movie'
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxnj={'hdr':'sdr',}
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['qualities']['list']
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxnX==LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA:return LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxfk in LrHTsdbBvgKIhRmwJYaUpNuWFDtxnX:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnz.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxqG(LrHTsdbBvgKIhRmwJYaUpNuWFDtxfk.get('id').rstrip('p')))
   if 'type' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn:
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['type']=='onair':
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxnO='onairvod'
   if 'drms' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn:
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['drms']:
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_action']='dash'
   if playOption.get('enable_hdr'):
    if 'mediatypes' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn.get('qualities'):
     for LrHTsdbBvgKIhRmwJYaUpNuWFDtxfE in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn.get('qualities').get('mediatypes'):
      if LrHTsdbBvgKIhRmwJYaUpNuWFDtxfE=='HDR10':
       LrHTsdbBvgKIhRmwJYaUpNuWFDtxnj['hdr']='hdr'
       LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_action']='dash'
       break
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_action'])
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.CheckQuality(quality_int,LrHTsdbBvgKIhRmwJYaUpNuWFDtxnz)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfn=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy(LrHTsdbBvgKIhRmwJYaUpNuWFDtxfC)+'p'
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/fz/streaming'
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxnj['hdr']=='hdr':
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxke={'contentid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe,'contenttype':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnO,'quality':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfn,'modelid':'SHIELD Android TV','guid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','protocol':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_action'],'hdr':'HDR10','videocodec':'HEVC','audiocodec':'AAC','issurround':'y','format':'normal','withinsubtitle':'n',}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams_AND())
   else:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxke={'contentid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe,'contenttype':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnO,'quality':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfn,'deviceModelId':'Windows 10','guid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n','action':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_action'],'protocol':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_action'],'hdr':'sdr','videocodec':'avc','audiocodec':'aac','issurround':'n','format':'normal','withinsubtitle':'n',}
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxql))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_url']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['playurl']
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_url']==LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA:return LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_cookie']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['awscookie']
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_drm'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['drm']
   if 'previewmsg' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['preview']:LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_preview']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['preview']['previewmsg']
   if 'subtitles' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn:
    for LrHTsdbBvgKIhRmwJYaUpNuWFDtxfq in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['subtitles']:
     if LrHTsdbBvgKIhRmwJYaUpNuWFDtxfq.get('languagecode')=='ko':
      LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_vtt']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxfq.get('url')
      break
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG 
 def GetSportsURL(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe,quality_int):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG ={'stream_url':'','stream_cookie':'','stream_drm':'','stream_preview':'','stream_vtt':'','stream_action':'hls',}
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxnz=[]
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/streaming/other'
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke={'contentid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe,'contenttype':'live','action':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_action'],'quality':LrHTsdbBvgKIhRmwJYaUpNuWFDtxqy(quality_int)+'p','deviceModelId':'Windows 10','guid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.WV['cookies']['uuid'],'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n',}
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxql))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_url']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['playurl']
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_url']==LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA:return LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG['stream_cookie']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['awscookie']
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxnG
 def make_viewdate(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxfo =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.Get_Now_Datetime()
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxfM =LrHTsdbBvgKIhRmwJYaUpNuWFDtxfo+datetime.timedelta(days=-1)
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxfP =LrHTsdbBvgKIhRmwJYaUpNuWFDtxfo+datetime.timedelta(days=1)
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxfA=[LrHTsdbBvgKIhRmwJYaUpNuWFDtxfo.strftime('%Y%m%d'),LrHTsdbBvgKIhRmwJYaUpNuWFDtxfP.strftime('%Y%m%d'),]
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxfA
 def Get_Sports_Gamelist(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC):
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxfc =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.make_viewdate()
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxfe=[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxfl =[]
  for LrHTsdbBvgKIhRmwJYaUpNuWFDtxfV in LrHTsdbBvgKIhRmwJYaUpNuWFDtxfc:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfy=LrHTsdbBvgKIhRmwJYaUpNuWFDtxfV[:6]
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxfy not in LrHTsdbBvgKIhRmwJYaUpNuWFDtxfe:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxfe.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxfy)
  try:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX='https://annexapi.wavve.com/skb/baseball/teammonthlycalendarlist'
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke={'IF':'IF-PORG-002','m':'getTeamCalendarListBand','response_format':'json','spo_itm_cd':'KBO','teamcd':'all','tgroup':'B','tvalue':'BC123','ver':'2.0',}
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke.update(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc))
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxfS in LrHTsdbBvgKIhRmwJYaUpNuWFDtxfe:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxke['date']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxfS
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn['cell_toplist']['celllist']
    for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEV:
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxfQ=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('game_date')
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxfi =LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('svc_id')
     if LrHTsdbBvgKIhRmwJYaUpNuWFDtxfi=='':continue
     if LrHTsdbBvgKIhRmwJYaUpNuWFDtxfQ in LrHTsdbBvgKIhRmwJYaUpNuWFDtxfc:
      LrHTsdbBvgKIhRmwJYaUpNuWFDtxfG=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('game_status') 
      LrHTsdbBvgKIhRmwJYaUpNuWFDtxfz =LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('title_list')[0].get('text')
      LrHTsdbBvgKIhRmwJYaUpNuWFDtxfQ =LrHTsdbBvgKIhRmwJYaUpNuWFDtxfQ[:4]+'-'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxfQ[4:6]+'-'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxfQ[-2:]
      LrHTsdbBvgKIhRmwJYaUpNuWFDtxfO =LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('game_time')
      LrHTsdbBvgKIhRmwJYaUpNuWFDtxfO =LrHTsdbBvgKIhRmwJYaUpNuWFDtxfO[:2]+':'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxfO[-2:]
      LrHTsdbBvgKIhRmwJYaUpNuWFDtxES={'game_date':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfQ,'game_time':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfO,'svc_id':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfi,'away_team':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('away_team').get('team_name'),'home_team':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('home_team').get('team_name'),'game_status':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfG,'game_place':LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('game_place'),}
      LrHTsdbBvgKIhRmwJYaUpNuWFDtxfl.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxES)
  except LrHTsdbBvgKIhRmwJYaUpNuWFDtxqS as exception:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqQ(exception)
   return[]
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxfj=[]
  for i in LrHTsdbBvgKIhRmwJYaUpNuWFDtxqV(2):
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy in LrHTsdbBvgKIhRmwJYaUpNuWFDtxfl:
    if i==0 and LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('game_status')=='LIVE':
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxfj.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy)
    elif i==1 and LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy.get('game_status')!='LIVE':
     LrHTsdbBvgKIhRmwJYaUpNuWFDtxfj.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEy)
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxfj
 def GetBookmarkInfo(LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq,LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf,LrHTsdbBvgKIhRmwJYaUpNuWFDtxnO):
  if LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf=='tvshow':
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxnO=='contentid':
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe=LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.ContentidToSeasonid(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe)
   else:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.ProgramidToContentid(LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq)
  else:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe=''
  LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX={'indexinfo':{'ott':'wavve','videoid':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq,'vidtype':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if LrHTsdbBvgKIhRmwJYaUpNuWFDtxCf=='tvshow':
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/fz/vod/contents/'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxCe 
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('programtitle' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn):return{}
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqE=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('programtitle')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['title']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqE
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('targetage')=='18' or LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('targetage')=='19' or LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('targetage')=='21':
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxqE +=u' (%s)'%(LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('targetage'))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['title'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqE
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['mpaa'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('targetage')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['plot'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('programsynopsis').replace('<br>','\n')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['studio'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('channelname')
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('firstreleaseyear')!='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['year'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('firstreleaseyear')
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('firstreleasedate')!='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['premiered']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('firstreleasedate')
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('genretext') !='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['genre'] =[LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('genretext')]
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqC=[]
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxqn in LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk['actors']['list']:LrHTsdbBvgKIhRmwJYaUpNuWFDtxqC.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxqn.get('text'))
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqz(LrHTsdbBvgKIhRmwJYaUpNuWFDtxqC)>0:
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqC[0]!='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['cast']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqC
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnC =''
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnf =''
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnq=''
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('programposterimage')!='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnC =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.HTTPTAG+LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('programposterimage')
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('programimage') !='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnf =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.HTTPTAG+LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('programimage')
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('programcircleimage')!='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxnq=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.HTTPTAG+LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('programcircleimage')
   if 'poster_default' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxnC:
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnC =LrHTsdbBvgKIhRmwJYaUpNuWFDtxnf
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxnq=''
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['thumbnail']['poster']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxnC
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['thumbnail']['thumb']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxnf
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['thumbnail']['clearlogo']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxnq
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['thumbnail']['fanart']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxnf
  else:
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.API_DOMAIN+'/movie/contents/'+LrHTsdbBvgKIhRmwJYaUpNuWFDtxCq 
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxke=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.GetDefaultParams(login=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqc)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC=LrHTsdbBvgKIhRmwJYaUpNuWFDtxkC.callRequestCookies('Get',LrHTsdbBvgKIhRmwJYaUpNuWFDtxkX,payload=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,params=LrHTsdbBvgKIhRmwJYaUpNuWFDtxke,headers=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA,cookies=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqA)
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn=json.loads(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEC.text)
   if not('title' in LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn):return{}
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEn
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqE=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('title')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['title']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqE
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('targetage')=='18' or LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('targetage')=='19' or LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('targetage')=='21':
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxqE +=u' (%s)'%(LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('targetage'))
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['title'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqE
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['mpaa'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('targetage')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['plot'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('synopsis').replace('<br>','\n')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['duration']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('playtime')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['country']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('country')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['studio'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('cpname')
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('releasedate')!='':
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['year'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('releasedate')[:4]
    LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['premiered']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk.get('releasedate')
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqC=[]
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxqn in LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk['actors']['list']:LrHTsdbBvgKIhRmwJYaUpNuWFDtxqC.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxqn.get('text'))
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqz(LrHTsdbBvgKIhRmwJYaUpNuWFDtxqC)>0:
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqC[0]!='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['cast']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqC
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxqf=[]
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxqo in LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk['directors']['list']:LrHTsdbBvgKIhRmwJYaUpNuWFDtxqf.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxqo.get('text'))
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqz(LrHTsdbBvgKIhRmwJYaUpNuWFDtxqf)>0:
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqf[0]!='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['director']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxqf
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc=[]
   for LrHTsdbBvgKIhRmwJYaUpNuWFDtxqM in LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk['genre']['list']:LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc.append(LrHTsdbBvgKIhRmwJYaUpNuWFDtxqM.get('text'))
   if LrHTsdbBvgKIhRmwJYaUpNuWFDtxqz(LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc)>0:
    if LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc[0]!='':LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['infoLabels']['genre']=LrHTsdbBvgKIhRmwJYaUpNuWFDtxEc
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxnC ='https://%s'%LrHTsdbBvgKIhRmwJYaUpNuWFDtxqk['image']
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['thumbnail']['poster'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxnC
   LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX['saveinfo']['thumbnail']['thumb'] =LrHTsdbBvgKIhRmwJYaUpNuWFDtxnC
  return LrHTsdbBvgKIhRmwJYaUpNuWFDtxfX
# Created by pyminifier (https://github.com/liftoff/pyminifier)
