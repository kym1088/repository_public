__author__="NightRain"
qKlrygpNGjxncFJRaiCtAkfMBIWXUE=object
qKlrygpNGjxncFJRaiCtAkfMBIWXUd=None
qKlrygpNGjxncFJRaiCtAkfMBIWXUo=int
qKlrygpNGjxncFJRaiCtAkfMBIWXUV=True
qKlrygpNGjxncFJRaiCtAkfMBIWXUz=False
qKlrygpNGjxncFJRaiCtAkfMBIWXUY=type
qKlrygpNGjxncFJRaiCtAkfMBIWXUv=dict
qKlrygpNGjxncFJRaiCtAkfMBIWXUQ=len
qKlrygpNGjxncFJRaiCtAkfMBIWXUs=range
qKlrygpNGjxncFJRaiCtAkfMBIWXUb=str
qKlrygpNGjxncFJRaiCtAkfMBIWXUP=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import json
qKlrygpNGjxncFJRaiCtAkfMBIWXwE=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1390539&contenttype=vod&genre=01&orderby=viewtime&uicode=VN4&uiparent=FN0&uirank=0&uitype=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?WeekDay=all&broadcastid=1311034&contenttype=vod&genre=02&orderby=viewtime&uicode=VN3&uiparent=FN0&uirank=0&uitype=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'modifydate','ordernm':'업데이트순','icon':''},{'title':'프로야구 - 경기중 시청가능','mode':'GAME_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'}]
qKlrygpNGjxncFJRaiCtAkfMBIWXwd=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
qKlrygpNGjxncFJRaiCtAkfMBIWXwo=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
qKlrygpNGjxncFJRaiCtAkfMBIWXwV =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
qKlrygpNGjxncFJRaiCtAkfMBIWXwz=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class qKlrygpNGjxncFJRaiCtAkfMBIWXwT(qKlrygpNGjxncFJRaiCtAkfMBIWXUE):
 def __init__(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,qKlrygpNGjxncFJRaiCtAkfMBIWXwY,qKlrygpNGjxncFJRaiCtAkfMBIWXwv,qKlrygpNGjxncFJRaiCtAkfMBIWXwQ):
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_url =qKlrygpNGjxncFJRaiCtAkfMBIWXwY
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle=qKlrygpNGjxncFJRaiCtAkfMBIWXwv
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.main_params =qKlrygpNGjxncFJRaiCtAkfMBIWXwQ
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj =LrHTsdbBvgKIhRmwJYaUpNuWFDtxkE() 
 def addon_noti(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,sting):
  try:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwb=xbmcgui.Dialog()
   qKlrygpNGjxncFJRaiCtAkfMBIWXwb.notification(__addonname__,sting)
  except:
   qKlrygpNGjxncFJRaiCtAkfMBIWXUd
 def addon_log(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,string):
  try:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwP=string.encode('utf-8','ignore')
  except:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwP='addonException: addon_log'
  qKlrygpNGjxncFJRaiCtAkfMBIWXwu=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,qKlrygpNGjxncFJRaiCtAkfMBIWXwP),level=qKlrygpNGjxncFJRaiCtAkfMBIWXwu)
 def get_keyboard_input(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,qKlrygpNGjxncFJRaiCtAkfMBIWXTv):
  qKlrygpNGjxncFJRaiCtAkfMBIWXwm=qKlrygpNGjxncFJRaiCtAkfMBIWXUd
  kb=xbmc.Keyboard()
  kb.setHeading(qKlrygpNGjxncFJRaiCtAkfMBIWXTv)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   qKlrygpNGjxncFJRaiCtAkfMBIWXwm=kb.getText()
  return qKlrygpNGjxncFJRaiCtAkfMBIWXwm
 def get_settings_account(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  qKlrygpNGjxncFJRaiCtAkfMBIWXwe =__addon__.getSetting('id')
  qKlrygpNGjxncFJRaiCtAkfMBIWXwD =__addon__.getSetting('pw')
  qKlrygpNGjxncFJRaiCtAkfMBIWXwL=qKlrygpNGjxncFJRaiCtAkfMBIWXUo(__addon__.getSetting('selected_profile'))
  return(qKlrygpNGjxncFJRaiCtAkfMBIWXwe,qKlrygpNGjxncFJRaiCtAkfMBIWXwD,qKlrygpNGjxncFJRaiCtAkfMBIWXwL)
 def get_settings_totalsearch(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  qKlrygpNGjxncFJRaiCtAkfMBIWXwH =qKlrygpNGjxncFJRaiCtAkfMBIWXUV if __addon__.getSetting('local_search')=='true' else qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  qKlrygpNGjxncFJRaiCtAkfMBIWXwh=qKlrygpNGjxncFJRaiCtAkfMBIWXUV if __addon__.getSetting('local_history')=='true' else qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  qKlrygpNGjxncFJRaiCtAkfMBIWXwS =qKlrygpNGjxncFJRaiCtAkfMBIWXUV if __addon__.getSetting('total_search')=='true' else qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  qKlrygpNGjxncFJRaiCtAkfMBIWXwO=qKlrygpNGjxncFJRaiCtAkfMBIWXUV if __addon__.getSetting('total_history')=='true' else qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  qKlrygpNGjxncFJRaiCtAkfMBIWXTw=qKlrygpNGjxncFJRaiCtAkfMBIWXUV if __addon__.getSetting('menu_bookmark')=='true' else qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  return(qKlrygpNGjxncFJRaiCtAkfMBIWXwH,qKlrygpNGjxncFJRaiCtAkfMBIWXwh,qKlrygpNGjxncFJRaiCtAkfMBIWXwS,qKlrygpNGjxncFJRaiCtAkfMBIWXwO,qKlrygpNGjxncFJRaiCtAkfMBIWXTw)
 def get_settings_makebookmark(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  return qKlrygpNGjxncFJRaiCtAkfMBIWXUV if __addon__.getSetting('make_bookmark')=='true' else qKlrygpNGjxncFJRaiCtAkfMBIWXUz
 def get_settings_play(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  qKlrygpNGjxncFJRaiCtAkfMBIWXTE={'enable_hdr':qKlrygpNGjxncFJRaiCtAkfMBIWXUV if __addon__.getSetting('enable_hdr')=='true' else qKlrygpNGjxncFJRaiCtAkfMBIWXUz,}
  if qKlrygpNGjxncFJRaiCtAkfMBIWXTE['enable_hdr']==qKlrygpNGjxncFJRaiCtAkfMBIWXUV:
   if qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_selQuality()<1080:qKlrygpNGjxncFJRaiCtAkfMBIWXTE['enable_hdr']=qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  return(qKlrygpNGjxncFJRaiCtAkfMBIWXTE)
 def get_selQuality(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  try:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTd=[1080,720,480,360]
   qKlrygpNGjxncFJRaiCtAkfMBIWXTo=qKlrygpNGjxncFJRaiCtAkfMBIWXUo(__addon__.getSetting('selected_quality'))
   return qKlrygpNGjxncFJRaiCtAkfMBIWXTd[qKlrygpNGjxncFJRaiCtAkfMBIWXTo]
  except:
   qKlrygpNGjxncFJRaiCtAkfMBIWXUd
  return 1080 
 def get_settings_exclusion21(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  qKlrygpNGjxncFJRaiCtAkfMBIWXTV =__addon__.getSetting('exclusion21')
  if qKlrygpNGjxncFJRaiCtAkfMBIWXTV=='false':
   return qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  else:
   return qKlrygpNGjxncFJRaiCtAkfMBIWXUV
 def get_settings_direct_replay(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  qKlrygpNGjxncFJRaiCtAkfMBIWXTz=qKlrygpNGjxncFJRaiCtAkfMBIWXUo(__addon__.getSetting('direct_replay'))
  if qKlrygpNGjxncFJRaiCtAkfMBIWXTz==0:
   return qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  else:
   return qKlrygpNGjxncFJRaiCtAkfMBIWXUV
 def set_winEpisodeOrderby(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,qKlrygpNGjxncFJRaiCtAkfMBIWXTU):
  __addon__.setSetting('wavve_orderby',qKlrygpNGjxncFJRaiCtAkfMBIWXTU)
 def get_winEpisodeOrderby(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  qKlrygpNGjxncFJRaiCtAkfMBIWXTU=__addon__.getSetting('wavve_orderby')
  if qKlrygpNGjxncFJRaiCtAkfMBIWXTU in['',qKlrygpNGjxncFJRaiCtAkfMBIWXUd]:qKlrygpNGjxncFJRaiCtAkfMBIWXTU='desc'
  return qKlrygpNGjxncFJRaiCtAkfMBIWXTU
 def add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,label,sublabel='',img='',infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params='',isLink=qKlrygpNGjxncFJRaiCtAkfMBIWXUz,ContextMenu=qKlrygpNGjxncFJRaiCtAkfMBIWXUd):
  qKlrygpNGjxncFJRaiCtAkfMBIWXTY='%s?%s'%(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_url,urllib.parse.urlencode(params))
  if sublabel:qKlrygpNGjxncFJRaiCtAkfMBIWXTv='%s < %s >'%(label,sublabel)
  else: qKlrygpNGjxncFJRaiCtAkfMBIWXTv=label
  if not img:img='DefaultFolder.png'
  qKlrygpNGjxncFJRaiCtAkfMBIWXTQ=xbmcgui.ListItem(qKlrygpNGjxncFJRaiCtAkfMBIWXTv)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUY(img)==qKlrygpNGjxncFJRaiCtAkfMBIWXUv:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTQ.setArt(img)
  else:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTQ.setArt({'thumb':img,'poster':img})
  if infoLabels:qKlrygpNGjxncFJRaiCtAkfMBIWXTQ.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTQ.setProperty('IsPlayable','true')
  if ContextMenu:qKlrygpNGjxncFJRaiCtAkfMBIWXTQ.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,qKlrygpNGjxncFJRaiCtAkfMBIWXTY,qKlrygpNGjxncFJRaiCtAkfMBIWXTQ,isFolder)
 def dp_Main_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  (qKlrygpNGjxncFJRaiCtAkfMBIWXwH,qKlrygpNGjxncFJRaiCtAkfMBIWXwh,qKlrygpNGjxncFJRaiCtAkfMBIWXwS,qKlrygpNGjxncFJRaiCtAkfMBIWXwO,qKlrygpNGjxncFJRaiCtAkfMBIWXTw)=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_totalsearch()
  for qKlrygpNGjxncFJRaiCtAkfMBIWXTs in qKlrygpNGjxncFJRaiCtAkfMBIWXwE:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv=qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('title')
   qKlrygpNGjxncFJRaiCtAkfMBIWXTb=''
   if qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('mode')=='SEARCH_GROUP' and qKlrygpNGjxncFJRaiCtAkfMBIWXwH ==qKlrygpNGjxncFJRaiCtAkfMBIWXUz:continue
   elif qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('mode')=='SEARCH_HISTORY' and qKlrygpNGjxncFJRaiCtAkfMBIWXwh==qKlrygpNGjxncFJRaiCtAkfMBIWXUz:continue
   elif qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('mode')=='TOTAL_SEARCH' and qKlrygpNGjxncFJRaiCtAkfMBIWXwS ==qKlrygpNGjxncFJRaiCtAkfMBIWXUz:continue
   elif qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('mode')=='TOTAL_HISTORY' and qKlrygpNGjxncFJRaiCtAkfMBIWXwO==qKlrygpNGjxncFJRaiCtAkfMBIWXUz:continue
   elif qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('mode')=='MENU_BOOKMARK' and qKlrygpNGjxncFJRaiCtAkfMBIWXTw==qKlrygpNGjxncFJRaiCtAkfMBIWXUz:continue
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('mode'),'sCode':qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('sCode'),'sIndex':qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('sIndex'),'sType':qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('sType'),'suburl':qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('suburl'),'subapi':qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('subapi'),'page':qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('page'),'orderby':qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('orderby'),'ordernm':qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('ordernm')}
   if qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    qKlrygpNGjxncFJRaiCtAkfMBIWXTu=qKlrygpNGjxncFJRaiCtAkfMBIWXUz
    qKlrygpNGjxncFJRaiCtAkfMBIWXTm =qKlrygpNGjxncFJRaiCtAkfMBIWXUV
   else:
    qKlrygpNGjxncFJRaiCtAkfMBIWXTu=qKlrygpNGjxncFJRaiCtAkfMBIWXUV
    qKlrygpNGjxncFJRaiCtAkfMBIWXTm =qKlrygpNGjxncFJRaiCtAkfMBIWXUz
   if 'icon' in qKlrygpNGjxncFJRaiCtAkfMBIWXTs:qKlrygpNGjxncFJRaiCtAkfMBIWXTb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',qKlrygpNGjxncFJRaiCtAkfMBIWXTs.get('icon')) 
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img=qKlrygpNGjxncFJRaiCtAkfMBIWXTb,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXTu,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP,isLink=qKlrygpNGjxncFJRaiCtAkfMBIWXTm)
  xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUV)
 def dp_Search_Group(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  if 'search_key' in args:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTL=args.get('search_key')
  else:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTL=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not qKlrygpNGjxncFJRaiCtAkfMBIWXTL:
    return
  for qKlrygpNGjxncFJRaiCtAkfMBIWXTH in qKlrygpNGjxncFJRaiCtAkfMBIWXwd:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTh =qKlrygpNGjxncFJRaiCtAkfMBIWXTH.get('mode')
   qKlrygpNGjxncFJRaiCtAkfMBIWXTS=qKlrygpNGjxncFJRaiCtAkfMBIWXTH.get('sType')
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv=qKlrygpNGjxncFJRaiCtAkfMBIWXTH.get('title')
   (qKlrygpNGjxncFJRaiCtAkfMBIWXTO,qKlrygpNGjxncFJRaiCtAkfMBIWXEw)=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_Search_List(qKlrygpNGjxncFJRaiCtAkfMBIWXTL,qKlrygpNGjxncFJRaiCtAkfMBIWXTS,1,exclusion21=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_exclusion21())
   qKlrygpNGjxncFJRaiCtAkfMBIWXET={'plot':'검색어 : '+qKlrygpNGjxncFJRaiCtAkfMBIWXTL+'\n\n'+qKlrygpNGjxncFJRaiCtAkfMBIWXwU.Search_FreeList(qKlrygpNGjxncFJRaiCtAkfMBIWXTO)}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':qKlrygpNGjxncFJRaiCtAkfMBIWXTh,'sType':qKlrygpNGjxncFJRaiCtAkfMBIWXTS,'search_key':qKlrygpNGjxncFJRaiCtAkfMBIWXTL,'page':'1',}
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img='',infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXET,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXwd)>0:xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUV)
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.Save_Searched_List(qKlrygpNGjxncFJRaiCtAkfMBIWXTL)
 def Search_FreeList(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,search_list):
  qKlrygpNGjxncFJRaiCtAkfMBIWXEd=''
  qKlrygpNGjxncFJRaiCtAkfMBIWXEo=7
  try:
   if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(search_list)==0:return '검색결과 없음'
   for i in qKlrygpNGjxncFJRaiCtAkfMBIWXUs(qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(search_list)):
    if i>=qKlrygpNGjxncFJRaiCtAkfMBIWXEo:
     qKlrygpNGjxncFJRaiCtAkfMBIWXEd=qKlrygpNGjxncFJRaiCtAkfMBIWXEd+'...'
     break
    qKlrygpNGjxncFJRaiCtAkfMBIWXEd=qKlrygpNGjxncFJRaiCtAkfMBIWXEd+search_list[i]['title']+'\n'
  except:
   return ''
  return qKlrygpNGjxncFJRaiCtAkfMBIWXEd
 def dp_Watch_Group(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEV in qKlrygpNGjxncFJRaiCtAkfMBIWXwo:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv=qKlrygpNGjxncFJRaiCtAkfMBIWXEV.get('title')
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':qKlrygpNGjxncFJRaiCtAkfMBIWXEV.get('mode'),'sType':qKlrygpNGjxncFJRaiCtAkfMBIWXEV.get('sType')}
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img='',infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXwo)>0:xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUV)
 def dp_Search_History(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXEz=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.Load_List_File('search')
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEU in qKlrygpNGjxncFJRaiCtAkfMBIWXEz:
   qKlrygpNGjxncFJRaiCtAkfMBIWXEY=qKlrygpNGjxncFJRaiCtAkfMBIWXUv(urllib.parse.parse_qsl(qKlrygpNGjxncFJRaiCtAkfMBIWXEU))
   qKlrygpNGjxncFJRaiCtAkfMBIWXEv=qKlrygpNGjxncFJRaiCtAkfMBIWXEY.get('skey').strip()
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'SEARCH_GROUP','search_key':qKlrygpNGjxncFJRaiCtAkfMBIWXEv,}
   qKlrygpNGjxncFJRaiCtAkfMBIWXEQ={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':qKlrygpNGjxncFJRaiCtAkfMBIWXEv,'vType':'-',}
   qKlrygpNGjxncFJRaiCtAkfMBIWXEs=urllib.parse.urlencode(qKlrygpNGjxncFJRaiCtAkfMBIWXEQ)
   qKlrygpNGjxncFJRaiCtAkfMBIWXEb=[('선택된 검색어 ( %s ) 삭제'%(qKlrygpNGjxncFJRaiCtAkfMBIWXEv),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXEs))]
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXEv,sublabel='',img=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP,ContextMenu=qKlrygpNGjxncFJRaiCtAkfMBIWXEb)
  qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'plot':'검색목록 전체를 삭제합니다.'}
  qKlrygpNGjxncFJRaiCtAkfMBIWXTv='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  qKlrygpNGjxncFJRaiCtAkfMBIWXTb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img=qKlrygpNGjxncFJRaiCtAkfMBIWXTb,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUz,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP,isLink=qKlrygpNGjxncFJRaiCtAkfMBIWXUV)
  xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_Search_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXTS =args.get('sType')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEu =qKlrygpNGjxncFJRaiCtAkfMBIWXUo(args.get('page'))
  if 'search_key' in args:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTL=args.get('search_key')
  else:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTL=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not qKlrygpNGjxncFJRaiCtAkfMBIWXTL:
    xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle)
    return
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm,qKlrygpNGjxncFJRaiCtAkfMBIWXEw=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_Search_List(qKlrygpNGjxncFJRaiCtAkfMBIWXTL,qKlrygpNGjxncFJRaiCtAkfMBIWXTS,qKlrygpNGjxncFJRaiCtAkfMBIWXEu,exclusion21=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_exclusion21())
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   qKlrygpNGjxncFJRaiCtAkfMBIWXED =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('videoid')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEL =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('vidtype')
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('title')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEH=qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('thumbnail')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEh =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('age')
   if qKlrygpNGjxncFJRaiCtAkfMBIWXEh=='18' or qKlrygpNGjxncFJRaiCtAkfMBIWXEh=='19' or qKlrygpNGjxncFJRaiCtAkfMBIWXEh=='21':qKlrygpNGjxncFJRaiCtAkfMBIWXTv+=' (%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXEh)
   qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'mediatype':'tvshow' if qKlrygpNGjxncFJRaiCtAkfMBIWXTS=='vod' else 'movie','mpaa':qKlrygpNGjxncFJRaiCtAkfMBIWXEh,'title':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'plot':qKlrygpNGjxncFJRaiCtAkfMBIWXTv}
   if qKlrygpNGjxncFJRaiCtAkfMBIWXTS=='vod':
    qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'EPISODE_LIST','seasonid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'page':'1',}
    qKlrygpNGjxncFJRaiCtAkfMBIWXTu=qKlrygpNGjxncFJRaiCtAkfMBIWXUV
   else:
    qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'MOVIE','contentid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'title':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'thumbnail':qKlrygpNGjxncFJRaiCtAkfMBIWXEH,'age':qKlrygpNGjxncFJRaiCtAkfMBIWXEh,}
    qKlrygpNGjxncFJRaiCtAkfMBIWXTu=qKlrygpNGjxncFJRaiCtAkfMBIWXUz
   qKlrygpNGjxncFJRaiCtAkfMBIWXEb=[]
   qKlrygpNGjxncFJRaiCtAkfMBIWXES={'mode':'VIEW_DETAIL','values':{'videoid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'vidtype':'tvshow' if qKlrygpNGjxncFJRaiCtAkfMBIWXTS=='vod' else 'movie','contenttype':qKlrygpNGjxncFJRaiCtAkfMBIWXEL,}}
   qKlrygpNGjxncFJRaiCtAkfMBIWXEO=json.dumps(qKlrygpNGjxncFJRaiCtAkfMBIWXES,separators=(',',':'))
   qKlrygpNGjxncFJRaiCtAkfMBIWXEO=base64.standard_b64encode(qKlrygpNGjxncFJRaiCtAkfMBIWXEO.encode()).decode('utf-8')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEO=qKlrygpNGjxncFJRaiCtAkfMBIWXEO.replace('+','%2B')
   qKlrygpNGjxncFJRaiCtAkfMBIWXdw='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXEO)
   qKlrygpNGjxncFJRaiCtAkfMBIWXEb.append(('상세정보 조회',qKlrygpNGjxncFJRaiCtAkfMBIWXdw))
   if qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_makebookmark():
    qKlrygpNGjxncFJRaiCtAkfMBIWXES={'videoid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'vidtype':'tvshow' if qKlrygpNGjxncFJRaiCtAkfMBIWXTS=='vod' else 'movie','vtitle':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'vsubtitle':'','contenttype':qKlrygpNGjxncFJRaiCtAkfMBIWXEL,}
    qKlrygpNGjxncFJRaiCtAkfMBIWXdT=json.dumps(qKlrygpNGjxncFJRaiCtAkfMBIWXES)
    qKlrygpNGjxncFJRaiCtAkfMBIWXdT=urllib.parse.quote(qKlrygpNGjxncFJRaiCtAkfMBIWXdT)
    qKlrygpNGjxncFJRaiCtAkfMBIWXdw='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXdT)
    qKlrygpNGjxncFJRaiCtAkfMBIWXEb.append(('(통합) 찜 영상에 추가',qKlrygpNGjxncFJRaiCtAkfMBIWXdw))
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img=qKlrygpNGjxncFJRaiCtAkfMBIWXEH,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXTu,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP,ContextMenu=qKlrygpNGjxncFJRaiCtAkfMBIWXEb)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXEw:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['mode'] ='SEARCH_LIST' 
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['sType']=qKlrygpNGjxncFJRaiCtAkfMBIWXTS 
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['page'] =qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['search_key']=qKlrygpNGjxncFJRaiCtAkfMBIWXTL
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv='[B]%s >>[/B]'%'다음 페이지'
   qKlrygpNGjxncFJRaiCtAkfMBIWXdE=qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXdE,img=qKlrygpNGjxncFJRaiCtAkfMBIWXTb,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXTS=='movie':xbmcplugin.setContent(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,'movies')
  else:xbmcplugin.setContent(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_Watch_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXTS =args.get('sType')
  qKlrygpNGjxncFJRaiCtAkfMBIWXTz=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_direct_replay()
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.Load_List_File(qKlrygpNGjxncFJRaiCtAkfMBIWXTS)
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   qKlrygpNGjxncFJRaiCtAkfMBIWXEY=qKlrygpNGjxncFJRaiCtAkfMBIWXUv(urllib.parse.parse_qsl(qKlrygpNGjxncFJRaiCtAkfMBIWXEe))
   qKlrygpNGjxncFJRaiCtAkfMBIWXdo =qKlrygpNGjxncFJRaiCtAkfMBIWXEY.get('code').strip()
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv =qKlrygpNGjxncFJRaiCtAkfMBIWXEY.get('title').strip()
   qKlrygpNGjxncFJRaiCtAkfMBIWXdE =qKlrygpNGjxncFJRaiCtAkfMBIWXEY.get('subtitle').strip()
   if qKlrygpNGjxncFJRaiCtAkfMBIWXdE=='None':qKlrygpNGjxncFJRaiCtAkfMBIWXdE=''
   qKlrygpNGjxncFJRaiCtAkfMBIWXEH=qKlrygpNGjxncFJRaiCtAkfMBIWXEY.get('img').strip()
   qKlrygpNGjxncFJRaiCtAkfMBIWXED =qKlrygpNGjxncFJRaiCtAkfMBIWXEY.get('videoid').strip()
   try:
    qKlrygpNGjxncFJRaiCtAkfMBIWXEH=qKlrygpNGjxncFJRaiCtAkfMBIWXEH.replace('\'','\"')
    qKlrygpNGjxncFJRaiCtAkfMBIWXEH=json.loads(qKlrygpNGjxncFJRaiCtAkfMBIWXEH)
   except:
    qKlrygpNGjxncFJRaiCtAkfMBIWXUd
   qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'plot':'%s\n%s'%(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,qKlrygpNGjxncFJRaiCtAkfMBIWXdE)}
   if qKlrygpNGjxncFJRaiCtAkfMBIWXTS=='vod':
    if qKlrygpNGjxncFJRaiCtAkfMBIWXTz==qKlrygpNGjxncFJRaiCtAkfMBIWXUz or qKlrygpNGjxncFJRaiCtAkfMBIWXED==qKlrygpNGjxncFJRaiCtAkfMBIWXUd:
     qKlrygpNGjxncFJRaiCtAkfMBIWXEP['mediatype']='tvshow'
     qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'SEASON_LIST','videoid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'vidtype':'contentid',}
     qKlrygpNGjxncFJRaiCtAkfMBIWXTu=qKlrygpNGjxncFJRaiCtAkfMBIWXUV
    else:
     qKlrygpNGjxncFJRaiCtAkfMBIWXEP['mediatype']='episode'
     qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'VOD','programid':qKlrygpNGjxncFJRaiCtAkfMBIWXdo,'contentid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'title':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'subtitle':qKlrygpNGjxncFJRaiCtAkfMBIWXdE,'thumbnail':qKlrygpNGjxncFJRaiCtAkfMBIWXEH}
     qKlrygpNGjxncFJRaiCtAkfMBIWXTu=qKlrygpNGjxncFJRaiCtAkfMBIWXUz
   else:
    qKlrygpNGjxncFJRaiCtAkfMBIWXEP['mediatype']='movie'
    qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'MOVIE','contentid':qKlrygpNGjxncFJRaiCtAkfMBIWXdo,'title':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'subtitle':qKlrygpNGjxncFJRaiCtAkfMBIWXdE,'thumbnail':qKlrygpNGjxncFJRaiCtAkfMBIWXEH}
    qKlrygpNGjxncFJRaiCtAkfMBIWXTu=qKlrygpNGjxncFJRaiCtAkfMBIWXUz
   qKlrygpNGjxncFJRaiCtAkfMBIWXEQ={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':qKlrygpNGjxncFJRaiCtAkfMBIWXdo,'vType':qKlrygpNGjxncFJRaiCtAkfMBIWXTS,}
   qKlrygpNGjxncFJRaiCtAkfMBIWXEs=urllib.parse.urlencode(qKlrygpNGjxncFJRaiCtAkfMBIWXEQ)
   qKlrygpNGjxncFJRaiCtAkfMBIWXEb=[('선택된 시청이력 ( %s ) 삭제'%(qKlrygpNGjxncFJRaiCtAkfMBIWXTv),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXEs))]
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXdE,img=qKlrygpNGjxncFJRaiCtAkfMBIWXEH,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXTu,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP,ContextMenu=qKlrygpNGjxncFJRaiCtAkfMBIWXEb)
  qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'plot':'시청목록을 삭제합니다.'}
  qKlrygpNGjxncFJRaiCtAkfMBIWXTv='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':qKlrygpNGjxncFJRaiCtAkfMBIWXTS,}
  qKlrygpNGjxncFJRaiCtAkfMBIWXTb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img=qKlrygpNGjxncFJRaiCtAkfMBIWXTb,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUz,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP,isLink=qKlrygpNGjxncFJRaiCtAkfMBIWXUV)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXTS=='movie':xbmcplugin.setContent(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,'movies')
  else:xbmcplugin.setContent(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def Load_List_File(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,stype): 
  try:
   if stype=='search':
    qKlrygpNGjxncFJRaiCtAkfMBIWXdV=qKlrygpNGjxncFJRaiCtAkfMBIWXwz
   elif stype in['vod','movie']:
    qKlrygpNGjxncFJRaiCtAkfMBIWXdV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   else:
    return[]
   fp=qKlrygpNGjxncFJRaiCtAkfMBIWXUP(qKlrygpNGjxncFJRaiCtAkfMBIWXdV,'r',-1,'utf-8')
   qKlrygpNGjxncFJRaiCtAkfMBIWXdz=fp.readlines()
   fp.close()
  except:
   qKlrygpNGjxncFJRaiCtAkfMBIWXdz=[]
  return qKlrygpNGjxncFJRaiCtAkfMBIWXdz
 def Save_Watched_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,qKlrygpNGjxncFJRaiCtAkfMBIWXzs,qKlrygpNGjxncFJRaiCtAkfMBIWXwQ):
  try:
   qKlrygpNGjxncFJRaiCtAkfMBIWXdU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qKlrygpNGjxncFJRaiCtAkfMBIWXzs))
   qKlrygpNGjxncFJRaiCtAkfMBIWXdY=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.Load_List_File(qKlrygpNGjxncFJRaiCtAkfMBIWXzs) 
   fp=qKlrygpNGjxncFJRaiCtAkfMBIWXUP(qKlrygpNGjxncFJRaiCtAkfMBIWXdU,'w',-1,'utf-8')
   qKlrygpNGjxncFJRaiCtAkfMBIWXdv=urllib.parse.urlencode(qKlrygpNGjxncFJRaiCtAkfMBIWXwQ)
   qKlrygpNGjxncFJRaiCtAkfMBIWXdv=qKlrygpNGjxncFJRaiCtAkfMBIWXdv+'\n'
   fp.write(qKlrygpNGjxncFJRaiCtAkfMBIWXdv)
   qKlrygpNGjxncFJRaiCtAkfMBIWXdQ=0
   for qKlrygpNGjxncFJRaiCtAkfMBIWXds in qKlrygpNGjxncFJRaiCtAkfMBIWXdY:
    qKlrygpNGjxncFJRaiCtAkfMBIWXdb=qKlrygpNGjxncFJRaiCtAkfMBIWXUv(urllib.parse.parse_qsl(qKlrygpNGjxncFJRaiCtAkfMBIWXds))
    qKlrygpNGjxncFJRaiCtAkfMBIWXdP=qKlrygpNGjxncFJRaiCtAkfMBIWXwQ.get('code').strip()
    qKlrygpNGjxncFJRaiCtAkfMBIWXdu=qKlrygpNGjxncFJRaiCtAkfMBIWXdb.get('code').strip()
    if qKlrygpNGjxncFJRaiCtAkfMBIWXzs=='vod' and qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_direct_replay()==qKlrygpNGjxncFJRaiCtAkfMBIWXUV:
     qKlrygpNGjxncFJRaiCtAkfMBIWXdP=qKlrygpNGjxncFJRaiCtAkfMBIWXwQ.get('videoid').strip()
     qKlrygpNGjxncFJRaiCtAkfMBIWXdu=qKlrygpNGjxncFJRaiCtAkfMBIWXdb.get('videoid').strip()if qKlrygpNGjxncFJRaiCtAkfMBIWXdu!=qKlrygpNGjxncFJRaiCtAkfMBIWXUd else '-'
    if qKlrygpNGjxncFJRaiCtAkfMBIWXdP!=qKlrygpNGjxncFJRaiCtAkfMBIWXdu:
     fp.write(qKlrygpNGjxncFJRaiCtAkfMBIWXds)
     qKlrygpNGjxncFJRaiCtAkfMBIWXdQ+=1
     if qKlrygpNGjxncFJRaiCtAkfMBIWXdQ>=50:break
   fp.close()
  except:
   qKlrygpNGjxncFJRaiCtAkfMBIWXUd
 def dp_History_Remove(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXdm=args.get('delType')
  qKlrygpNGjxncFJRaiCtAkfMBIWXde =args.get('sKey')
  qKlrygpNGjxncFJRaiCtAkfMBIWXdD =args.get('vType')
  qKlrygpNGjxncFJRaiCtAkfMBIWXwb=xbmcgui.Dialog()
  if qKlrygpNGjxncFJRaiCtAkfMBIWXdm=='SEARCH_ALL':
   qKlrygpNGjxncFJRaiCtAkfMBIWXdL=qKlrygpNGjxncFJRaiCtAkfMBIWXwb.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXdm=='SEARCH_ONE':
   qKlrygpNGjxncFJRaiCtAkfMBIWXdL=qKlrygpNGjxncFJRaiCtAkfMBIWXwb.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXdm=='WATCH_ALL':
   qKlrygpNGjxncFJRaiCtAkfMBIWXdL=qKlrygpNGjxncFJRaiCtAkfMBIWXwb.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXdm=='WATCH_ONE':
   qKlrygpNGjxncFJRaiCtAkfMBIWXdL=qKlrygpNGjxncFJRaiCtAkfMBIWXwb.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if qKlrygpNGjxncFJRaiCtAkfMBIWXdL==qKlrygpNGjxncFJRaiCtAkfMBIWXUz:sys.exit()
  if qKlrygpNGjxncFJRaiCtAkfMBIWXdm=='SEARCH_ALL':
   if os.path.isfile(qKlrygpNGjxncFJRaiCtAkfMBIWXwz):os.remove(qKlrygpNGjxncFJRaiCtAkfMBIWXwz)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXdm=='SEARCH_ONE':
   try:
    qKlrygpNGjxncFJRaiCtAkfMBIWXdV=qKlrygpNGjxncFJRaiCtAkfMBIWXwz
    qKlrygpNGjxncFJRaiCtAkfMBIWXdY=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.Load_List_File('search') 
    fp=qKlrygpNGjxncFJRaiCtAkfMBIWXUP(qKlrygpNGjxncFJRaiCtAkfMBIWXdV,'w',-1,'utf-8')
    for qKlrygpNGjxncFJRaiCtAkfMBIWXds in qKlrygpNGjxncFJRaiCtAkfMBIWXdY:
     qKlrygpNGjxncFJRaiCtAkfMBIWXdb=qKlrygpNGjxncFJRaiCtAkfMBIWXUv(urllib.parse.parse_qsl(qKlrygpNGjxncFJRaiCtAkfMBIWXds))
     qKlrygpNGjxncFJRaiCtAkfMBIWXdH=qKlrygpNGjxncFJRaiCtAkfMBIWXdb.get('skey').strip()
     if qKlrygpNGjxncFJRaiCtAkfMBIWXde!=qKlrygpNGjxncFJRaiCtAkfMBIWXdH:
      fp.write(qKlrygpNGjxncFJRaiCtAkfMBIWXds)
    fp.close()
   except:
    qKlrygpNGjxncFJRaiCtAkfMBIWXUd
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXdm=='WATCH_ALL':
   qKlrygpNGjxncFJRaiCtAkfMBIWXdV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qKlrygpNGjxncFJRaiCtAkfMBIWXdD))
   if os.path.isfile(qKlrygpNGjxncFJRaiCtAkfMBIWXdV):os.remove(qKlrygpNGjxncFJRaiCtAkfMBIWXdV)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXdm=='WATCH_ONE':
   qKlrygpNGjxncFJRaiCtAkfMBIWXdV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qKlrygpNGjxncFJRaiCtAkfMBIWXdD))
   try:
    qKlrygpNGjxncFJRaiCtAkfMBIWXdY=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.Load_List_File(qKlrygpNGjxncFJRaiCtAkfMBIWXdD) 
    fp=qKlrygpNGjxncFJRaiCtAkfMBIWXUP(qKlrygpNGjxncFJRaiCtAkfMBIWXdV,'w',-1,'utf-8')
    for qKlrygpNGjxncFJRaiCtAkfMBIWXds in qKlrygpNGjxncFJRaiCtAkfMBIWXdY:
     qKlrygpNGjxncFJRaiCtAkfMBIWXdb=qKlrygpNGjxncFJRaiCtAkfMBIWXUv(urllib.parse.parse_qsl(qKlrygpNGjxncFJRaiCtAkfMBIWXds))
     qKlrygpNGjxncFJRaiCtAkfMBIWXdH=qKlrygpNGjxncFJRaiCtAkfMBIWXdb.get('code').strip()
     if qKlrygpNGjxncFJRaiCtAkfMBIWXde!=qKlrygpNGjxncFJRaiCtAkfMBIWXdH:
      fp.write(qKlrygpNGjxncFJRaiCtAkfMBIWXds)
    fp.close()
   except:
    qKlrygpNGjxncFJRaiCtAkfMBIWXUd
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,qKlrygpNGjxncFJRaiCtAkfMBIWXTL):
  try:
   qKlrygpNGjxncFJRaiCtAkfMBIWXdh=qKlrygpNGjxncFJRaiCtAkfMBIWXwz
   qKlrygpNGjxncFJRaiCtAkfMBIWXdY=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.Load_List_File('search') 
   qKlrygpNGjxncFJRaiCtAkfMBIWXdS={'skey':qKlrygpNGjxncFJRaiCtAkfMBIWXTL.strip()}
   fp=qKlrygpNGjxncFJRaiCtAkfMBIWXUP(qKlrygpNGjxncFJRaiCtAkfMBIWXdh,'w',-1,'utf-8')
   qKlrygpNGjxncFJRaiCtAkfMBIWXdv=urllib.parse.urlencode(qKlrygpNGjxncFJRaiCtAkfMBIWXdS)
   qKlrygpNGjxncFJRaiCtAkfMBIWXdv=qKlrygpNGjxncFJRaiCtAkfMBIWXdv+'\n'
   fp.write(qKlrygpNGjxncFJRaiCtAkfMBIWXdv)
   qKlrygpNGjxncFJRaiCtAkfMBIWXdQ=0
   for qKlrygpNGjxncFJRaiCtAkfMBIWXds in qKlrygpNGjxncFJRaiCtAkfMBIWXdY:
    qKlrygpNGjxncFJRaiCtAkfMBIWXdb=qKlrygpNGjxncFJRaiCtAkfMBIWXUv(urllib.parse.parse_qsl(qKlrygpNGjxncFJRaiCtAkfMBIWXds))
    qKlrygpNGjxncFJRaiCtAkfMBIWXdP=qKlrygpNGjxncFJRaiCtAkfMBIWXdS.get('skey').strip()
    qKlrygpNGjxncFJRaiCtAkfMBIWXdu=qKlrygpNGjxncFJRaiCtAkfMBIWXdb.get('skey').strip()
    if qKlrygpNGjxncFJRaiCtAkfMBIWXdP!=qKlrygpNGjxncFJRaiCtAkfMBIWXdu:
     fp.write(qKlrygpNGjxncFJRaiCtAkfMBIWXds)
     qKlrygpNGjxncFJRaiCtAkfMBIWXdQ+=1
     if qKlrygpNGjxncFJRaiCtAkfMBIWXdQ>=50:break
   fp.close()
  except:
   qKlrygpNGjxncFJRaiCtAkfMBIWXUd
 def dp_Global_Search(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXTh=args.get('mode')
  if qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='TOTAL_SEARCH':
   qKlrygpNGjxncFJRaiCtAkfMBIWXdO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   qKlrygpNGjxncFJRaiCtAkfMBIWXdO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(qKlrygpNGjxncFJRaiCtAkfMBIWXdO)
 def dp_Bookmark_Menu(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXdO='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(qKlrygpNGjxncFJRaiCtAkfMBIWXdO)
 def login_main(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  (qKlrygpNGjxncFJRaiCtAkfMBIWXow,qKlrygpNGjxncFJRaiCtAkfMBIWXoT,qKlrygpNGjxncFJRaiCtAkfMBIWXoE)=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_account()
  if not(qKlrygpNGjxncFJRaiCtAkfMBIWXow and qKlrygpNGjxncFJRaiCtAkfMBIWXoT):
   qKlrygpNGjxncFJRaiCtAkfMBIWXwb=xbmcgui.Dialog()
   qKlrygpNGjxncFJRaiCtAkfMBIWXdL=qKlrygpNGjxncFJRaiCtAkfMBIWXwb.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if qKlrygpNGjxncFJRaiCtAkfMBIWXdL==qKlrygpNGjxncFJRaiCtAkfMBIWXUV:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if qKlrygpNGjxncFJRaiCtAkfMBIWXwU.cookiefile_check()==qKlrygpNGjxncFJRaiCtAkfMBIWXUV:return
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   qKlrygpNGjxncFJRaiCtAkfMBIWXod=0
   while qKlrygpNGjxncFJRaiCtAkfMBIWXUV:
    qKlrygpNGjxncFJRaiCtAkfMBIWXod+=1
    time.sleep(0.05)
    if qKlrygpNGjxncFJRaiCtAkfMBIWXod>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  qKlrygpNGjxncFJRaiCtAkfMBIWXoV=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.GetCredential(qKlrygpNGjxncFJRaiCtAkfMBIWXow,qKlrygpNGjxncFJRaiCtAkfMBIWXoT,qKlrygpNGjxncFJRaiCtAkfMBIWXoE)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXoV:qKlrygpNGjxncFJRaiCtAkfMBIWXwU.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
  if qKlrygpNGjxncFJRaiCtAkfMBIWXoV==qKlrygpNGjxncFJRaiCtAkfMBIWXUz:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_setEpOrderby(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXTU =args.get('orderby')
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.set_winEpisodeOrderby(qKlrygpNGjxncFJRaiCtAkfMBIWXTU)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXTh =args.get('mode')
  qKlrygpNGjxncFJRaiCtAkfMBIWXoz =args.get('contentid')
  qKlrygpNGjxncFJRaiCtAkfMBIWXoU =args.get('pvrmode')
  qKlrygpNGjxncFJRaiCtAkfMBIWXoY=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_selQuality()
  qKlrygpNGjxncFJRaiCtAkfMBIWXTE =qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_play()
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.addon_log(qKlrygpNGjxncFJRaiCtAkfMBIWXoz+' - '+qKlrygpNGjxncFJRaiCtAkfMBIWXTh)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='SPORTS':
   qKlrygpNGjxncFJRaiCtAkfMBIWXov=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.GetSportsURL(qKlrygpNGjxncFJRaiCtAkfMBIWXoz,qKlrygpNGjxncFJRaiCtAkfMBIWXoY)
  else:
   qKlrygpNGjxncFJRaiCtAkfMBIWXov=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.GetStreamingURL(qKlrygpNGjxncFJRaiCtAkfMBIWXTh,qKlrygpNGjxncFJRaiCtAkfMBIWXoz,qKlrygpNGjxncFJRaiCtAkfMBIWXoY,qKlrygpNGjxncFJRaiCtAkfMBIWXoU,playOption=qKlrygpNGjxncFJRaiCtAkfMBIWXTE)
  qKlrygpNGjxncFJRaiCtAkfMBIWXoQ=qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_cookie']
  qKlrygpNGjxncFJRaiCtAkfMBIWXos='{}|Cookie={}'.format(qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_url'],qKlrygpNGjxncFJRaiCtAkfMBIWXoQ)
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.addon_log(qKlrygpNGjxncFJRaiCtAkfMBIWXos)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_url']=='':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.addon_noti(__language__(30907).encode('utf8'))
   return
  qKlrygpNGjxncFJRaiCtAkfMBIWXob=xbmcgui.ListItem(path=qKlrygpNGjxncFJRaiCtAkfMBIWXos)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_drm']:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.addon_log('!!streaming_drm!!')
   qKlrygpNGjxncFJRaiCtAkfMBIWXoP=qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_drm']['customdata']
   qKlrygpNGjxncFJRaiCtAkfMBIWXou =qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_drm']['drmhost']
   qKlrygpNGjxncFJRaiCtAkfMBIWXom =inputstreamhelper.Helper('mpd',drm='widevine')
   if qKlrygpNGjxncFJRaiCtAkfMBIWXom.check_inputstream():
    if qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='MOVIE':
     qKlrygpNGjxncFJRaiCtAkfMBIWXoe='https://www.wavve.com/player/movie?movieid=%s'%qKlrygpNGjxncFJRaiCtAkfMBIWXoz
    else:
     qKlrygpNGjxncFJRaiCtAkfMBIWXoe='https://www.wavve.com/player/vod?programid=%s&page=1'%qKlrygpNGjxncFJRaiCtAkfMBIWXoz
    qKlrygpNGjxncFJRaiCtAkfMBIWXoD={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':qKlrygpNGjxncFJRaiCtAkfMBIWXoP,'referer':qKlrygpNGjxncFJRaiCtAkfMBIWXoe,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.USER_AGENT,}
    qKlrygpNGjxncFJRaiCtAkfMBIWXoL=qKlrygpNGjxncFJRaiCtAkfMBIWXou+'|'+urllib.parse.urlencode(qKlrygpNGjxncFJRaiCtAkfMBIWXoD)+'|R{SSM}|'
    qKlrygpNGjxncFJRaiCtAkfMBIWXob.setProperty('inputstream',qKlrygpNGjxncFJRaiCtAkfMBIWXom.inputstream_addon)
    qKlrygpNGjxncFJRaiCtAkfMBIWXob.setProperty('inputstream.adaptive.manifest_type','mpd')
    qKlrygpNGjxncFJRaiCtAkfMBIWXob.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    qKlrygpNGjxncFJRaiCtAkfMBIWXob.setProperty('inputstream.adaptive.license_key',qKlrygpNGjxncFJRaiCtAkfMBIWXoL)
    qKlrygpNGjxncFJRaiCtAkfMBIWXob.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.USER_AGENT,qKlrygpNGjxncFJRaiCtAkfMBIWXoQ))
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh in['VOD','MOVIE']:
   qKlrygpNGjxncFJRaiCtAkfMBIWXob.setContentLookup(qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
   qKlrygpNGjxncFJRaiCtAkfMBIWXob.setMimeType('application/x-mpegURL')
   qKlrygpNGjxncFJRaiCtAkfMBIWXob.setProperty('inputstream','inputstream.adaptive')
   if qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_action']=='hls':
    qKlrygpNGjxncFJRaiCtAkfMBIWXob.setProperty('inputstream.adaptive.manifest_type','hls')
   else:
    qKlrygpNGjxncFJRaiCtAkfMBIWXob.setProperty('inputstream.adaptive.manifest_type','mpd')
   qKlrygpNGjxncFJRaiCtAkfMBIWXob.setProperty('inputstream.adaptive.stream_headers','user-agent={}&Cookie={}'.format(qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.USER_AGENT,qKlrygpNGjxncFJRaiCtAkfMBIWXoQ))
  if qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_vtt']:
   qKlrygpNGjxncFJRaiCtAkfMBIWXob.setSubtitles([qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_vtt']])
  xbmcplugin.setResolvedUrl(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,qKlrygpNGjxncFJRaiCtAkfMBIWXUV,qKlrygpNGjxncFJRaiCtAkfMBIWXob)
  qKlrygpNGjxncFJRaiCtAkfMBIWXoH=qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  if qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_preview']:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.addon_noti(qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_preview'].encode('utf-8'))
   qKlrygpNGjxncFJRaiCtAkfMBIWXoH=qKlrygpNGjxncFJRaiCtAkfMBIWXUV
  else:
   if '/preview.' in urllib.parse.urlsplit(qKlrygpNGjxncFJRaiCtAkfMBIWXov['stream_url']).path:
    qKlrygpNGjxncFJRaiCtAkfMBIWXwU.addon_noti(__language__(30908).encode('utf8'))
    qKlrygpNGjxncFJRaiCtAkfMBIWXoH=qKlrygpNGjxncFJRaiCtAkfMBIWXUV
  try:
   qKlrygpNGjxncFJRaiCtAkfMBIWXoh=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and qKlrygpNGjxncFJRaiCtAkfMBIWXoH==qKlrygpNGjxncFJRaiCtAkfMBIWXUz and qKlrygpNGjxncFJRaiCtAkfMBIWXoh!='-':
    qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'code':qKlrygpNGjxncFJRaiCtAkfMBIWXoh,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    qKlrygpNGjxncFJRaiCtAkfMBIWXwU.Save_Watched_List(args.get('mode').lower(),qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  except:
   qKlrygpNGjxncFJRaiCtAkfMBIWXUd
 def logout(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  qKlrygpNGjxncFJRaiCtAkfMBIWXwb=xbmcgui.Dialog()
  qKlrygpNGjxncFJRaiCtAkfMBIWXdL=qKlrygpNGjxncFJRaiCtAkfMBIWXwb.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if qKlrygpNGjxncFJRaiCtAkfMBIWXdL==qKlrygpNGjxncFJRaiCtAkfMBIWXUz:sys.exit()
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Init_WV_Total()
  if os.path.isfile(qKlrygpNGjxncFJRaiCtAkfMBIWXwV):os.remove(qKlrygpNGjxncFJRaiCtAkfMBIWXwV)
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  qKlrygpNGjxncFJRaiCtAkfMBIWXoS =qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_Now_Datetime()
  qKlrygpNGjxncFJRaiCtAkfMBIWXoO=qKlrygpNGjxncFJRaiCtAkfMBIWXoS+datetime.timedelta(days=qKlrygpNGjxncFJRaiCtAkfMBIWXUo(__addon__.getSetting('cache_ttl')))
  (qKlrygpNGjxncFJRaiCtAkfMBIWXow,qKlrygpNGjxncFJRaiCtAkfMBIWXoT,qKlrygpNGjxncFJRaiCtAkfMBIWXoE)=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_account()
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Save_session_acount(qKlrygpNGjxncFJRaiCtAkfMBIWXow,qKlrygpNGjxncFJRaiCtAkfMBIWXoT,qKlrygpNGjxncFJRaiCtAkfMBIWXoE)
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.WV['account']['token_limit']=qKlrygpNGjxncFJRaiCtAkfMBIWXoO.strftime('%Y%m%d')
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.JsonFile_Save(qKlrygpNGjxncFJRaiCtAkfMBIWXwV,qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.WV)
 def cookiefile_check(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.WV=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.JsonFile_Load(qKlrygpNGjxncFJRaiCtAkfMBIWXwV)
  if 'account' not in qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.WV:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Init_WV_Total()
   return qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  if 'uuid' not in qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.WV.get('cookies'):
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Init_WV_Total()
   return qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  (qKlrygpNGjxncFJRaiCtAkfMBIWXVw,qKlrygpNGjxncFJRaiCtAkfMBIWXVT,qKlrygpNGjxncFJRaiCtAkfMBIWXVE)=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_account()
  (qKlrygpNGjxncFJRaiCtAkfMBIWXVd,qKlrygpNGjxncFJRaiCtAkfMBIWXVo,qKlrygpNGjxncFJRaiCtAkfMBIWXVz)=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Load_session_acount()
  if qKlrygpNGjxncFJRaiCtAkfMBIWXVw!=qKlrygpNGjxncFJRaiCtAkfMBIWXVd or qKlrygpNGjxncFJRaiCtAkfMBIWXVT!=qKlrygpNGjxncFJRaiCtAkfMBIWXVo or qKlrygpNGjxncFJRaiCtAkfMBIWXVE!=qKlrygpNGjxncFJRaiCtAkfMBIWXVz:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Init_WV_Total()
   return qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUo(qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))>qKlrygpNGjxncFJRaiCtAkfMBIWXUo(qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.WV['account']['token_limit']):
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Init_WV_Total()
   return qKlrygpNGjxncFJRaiCtAkfMBIWXUz
  return qKlrygpNGjxncFJRaiCtAkfMBIWXUV
 def dp_LiveCatagory_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXVU =args.get('sCode')
  qKlrygpNGjxncFJRaiCtAkfMBIWXVY=args.get('sIndex')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm,qKlrygpNGjxncFJRaiCtAkfMBIWXVv=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_LiveCatagory_List(qKlrygpNGjxncFJRaiCtAkfMBIWXVU,qKlrygpNGjxncFJRaiCtAkfMBIWXVY)
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('title')
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'LIVE_LIST','genre':qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('genre'),'baseapi':qKlrygpNGjxncFJRaiCtAkfMBIWXVv}
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img='',infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXEm)>0:xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_MainCatagory_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXVU =args.get('sCode')
  qKlrygpNGjxncFJRaiCtAkfMBIWXVY=args.get('sIndex')
  qKlrygpNGjxncFJRaiCtAkfMBIWXTS =args.get('sType')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_MainCatagory_List(qKlrygpNGjxncFJRaiCtAkfMBIWXVU,qKlrygpNGjxncFJRaiCtAkfMBIWXVY)
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   if qKlrygpNGjxncFJRaiCtAkfMBIWXTS=='vod':
    if qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('subtype')=='catagory':
     qKlrygpNGjxncFJRaiCtAkfMBIWXTh='PROGRAM_LIST'
    else:
     qKlrygpNGjxncFJRaiCtAkfMBIWXTh='SUPERSECTION_LIST'
   elif qKlrygpNGjxncFJRaiCtAkfMBIWXTS=='movie':
    qKlrygpNGjxncFJRaiCtAkfMBIWXTh='MOVIE_LIST'
   else:
    qKlrygpNGjxncFJRaiCtAkfMBIWXTh=''
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv='%s (%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('title'),args.get('ordernm'))
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':qKlrygpNGjxncFJRaiCtAkfMBIWXTh,'suburl':qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('suburl'),'subapi':qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_exclusion21():
    if qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('title')=='성인' or qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('title')=='성인+' or qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('title')=='에로티시즘' or qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('title')=='19':continue
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img='',infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXEm)>0:xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_Program_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXVQ =args.get('subapi')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEu=qKlrygpNGjxncFJRaiCtAkfMBIWXUo(args.get('page'))
  qKlrygpNGjxncFJRaiCtAkfMBIWXTU =args.get('orderby')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm,qKlrygpNGjxncFJRaiCtAkfMBIWXEw=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_Program_List(qKlrygpNGjxncFJRaiCtAkfMBIWXVQ,qKlrygpNGjxncFJRaiCtAkfMBIWXEu,qKlrygpNGjxncFJRaiCtAkfMBIWXTU)
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   qKlrygpNGjxncFJRaiCtAkfMBIWXED =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('videoid')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEL =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('vidtype')
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('title')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEH=qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('thumbnail')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEh =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('age')
   if qKlrygpNGjxncFJRaiCtAkfMBIWXEh=='18' or qKlrygpNGjxncFJRaiCtAkfMBIWXEh=='19' or qKlrygpNGjxncFJRaiCtAkfMBIWXEh=='21':qKlrygpNGjxncFJRaiCtAkfMBIWXTv+=' (%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXEh)
   qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'plot':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'mpaa':qKlrygpNGjxncFJRaiCtAkfMBIWXEh,'mediatype':'tvshow',}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'SEASON_LIST','videoid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'vidtype':qKlrygpNGjxncFJRaiCtAkfMBIWXEL,}
   qKlrygpNGjxncFJRaiCtAkfMBIWXEb=[]
   qKlrygpNGjxncFJRaiCtAkfMBIWXES={'mode':'VIEW_DETAIL','values':{'videoid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'vidtype':'tvshow','contenttype':qKlrygpNGjxncFJRaiCtAkfMBIWXEL,}}
   qKlrygpNGjxncFJRaiCtAkfMBIWXEO=json.dumps(qKlrygpNGjxncFJRaiCtAkfMBIWXES,separators=(',',':'))
   qKlrygpNGjxncFJRaiCtAkfMBIWXEO=base64.standard_b64encode(qKlrygpNGjxncFJRaiCtAkfMBIWXEO.encode()).decode('utf-8')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEO=qKlrygpNGjxncFJRaiCtAkfMBIWXEO.replace('+','%2B')
   qKlrygpNGjxncFJRaiCtAkfMBIWXdw='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXEO)
   qKlrygpNGjxncFJRaiCtAkfMBIWXEb.append(('상세정보 조회',qKlrygpNGjxncFJRaiCtAkfMBIWXdw))
   if qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_makebookmark():
    qKlrygpNGjxncFJRaiCtAkfMBIWXES={'videoid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'vidtype':'tvshow','vtitle':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'vsubtitle':'','contenttype':qKlrygpNGjxncFJRaiCtAkfMBIWXEL,}
    qKlrygpNGjxncFJRaiCtAkfMBIWXdT=json.dumps(qKlrygpNGjxncFJRaiCtAkfMBIWXES)
    qKlrygpNGjxncFJRaiCtAkfMBIWXdT=urllib.parse.quote(qKlrygpNGjxncFJRaiCtAkfMBIWXdT)
    qKlrygpNGjxncFJRaiCtAkfMBIWXdw='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXdT)
    qKlrygpNGjxncFJRaiCtAkfMBIWXEb.append(('(통합) 찜 영상에 추가',qKlrygpNGjxncFJRaiCtAkfMBIWXdw))
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img=qKlrygpNGjxncFJRaiCtAkfMBIWXEH,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP,ContextMenu=qKlrygpNGjxncFJRaiCtAkfMBIWXEb)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXEw:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['mode'] ='PROGRAM_LIST' 
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['subapi']=qKlrygpNGjxncFJRaiCtAkfMBIWXVQ 
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['page'] =qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv='[B]%s >>[/B]'%'다음 페이지'
   qKlrygpNGjxncFJRaiCtAkfMBIWXdE=qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXdE,img=qKlrygpNGjxncFJRaiCtAkfMBIWXTb,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  xbmcplugin.setContent(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,'tvshows')
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXEm)>0:xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_Season_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXED=args.get('videoid')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEL=args.get('vidtype')
  if qKlrygpNGjxncFJRaiCtAkfMBIWXEL=='contentid':
   qKlrygpNGjxncFJRaiCtAkfMBIWXoz=qKlrygpNGjxncFJRaiCtAkfMBIWXED
   qKlrygpNGjxncFJRaiCtAkfMBIWXVs =qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.ContentidToSeasonid(qKlrygpNGjxncFJRaiCtAkfMBIWXED)
  else:
   qKlrygpNGjxncFJRaiCtAkfMBIWXoz=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.ProgramidToContentid(qKlrygpNGjxncFJRaiCtAkfMBIWXED)
   qKlrygpNGjxncFJRaiCtAkfMBIWXVs =qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.ContentidToSeasonid(qKlrygpNGjxncFJRaiCtAkfMBIWXoz)
  qKlrygpNGjxncFJRaiCtAkfMBIWXVb=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_Season_List(qKlrygpNGjxncFJRaiCtAkfMBIWXVs)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXVb)>1:
   for qKlrygpNGjxncFJRaiCtAkfMBIWXVP in qKlrygpNGjxncFJRaiCtAkfMBIWXVb:
    qKlrygpNGjxncFJRaiCtAkfMBIWXVu=qKlrygpNGjxncFJRaiCtAkfMBIWXVP.get('season_Id')
    qKlrygpNGjxncFJRaiCtAkfMBIWXVm=qKlrygpNGjxncFJRaiCtAkfMBIWXVP.get('season_Nm')
    qKlrygpNGjxncFJRaiCtAkfMBIWXVe=qKlrygpNGjxncFJRaiCtAkfMBIWXVP.get('programNm')
    qKlrygpNGjxncFJRaiCtAkfMBIWXEH=qKlrygpNGjxncFJRaiCtAkfMBIWXVP.get('thumbnail')
    qKlrygpNGjxncFJRaiCtAkfMBIWXVD =qKlrygpNGjxncFJRaiCtAkfMBIWXVP.get('synopsis')
    qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'mediatype':'tvshow','title':qKlrygpNGjxncFJRaiCtAkfMBIWXVm,'plot':qKlrygpNGjxncFJRaiCtAkfMBIWXVD,}
    qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'EPISODE_LIST','seasonid':qKlrygpNGjxncFJRaiCtAkfMBIWXVu,'page':'1',}
    qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXVm,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXVe,img=qKlrygpNGjxncFJRaiCtAkfMBIWXEH,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP,ContextMenu=qKlrygpNGjxncFJRaiCtAkfMBIWXUd)
   xbmcplugin.setContent(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
  else:
   qKlrygpNGjxncFJRaiCtAkfMBIWXVL={'seasonid':qKlrygpNGjxncFJRaiCtAkfMBIWXVs,'page':'1',}
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Episode_List(qKlrygpNGjxncFJRaiCtAkfMBIWXVL)
 def dp_Episode_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXVs =args.get('seasonid')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEu =qKlrygpNGjxncFJRaiCtAkfMBIWXUo(args.get('page'))
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm,qKlrygpNGjxncFJRaiCtAkfMBIWXEw=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_Episode_List(qKlrygpNGjxncFJRaiCtAkfMBIWXVs,qKlrygpNGjxncFJRaiCtAkfMBIWXEu,orderby=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_winEpisodeOrderby())
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   qKlrygpNGjxncFJRaiCtAkfMBIWXdE=qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('episodenumber')
   qKlrygpNGjxncFJRaiCtAkfMBIWXVH ='[%s]\n\n%s'%(qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('episodetitle'),qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('synopsis'))
   qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'mediatype':'episode','title':qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('programtitle'),'plot':qKlrygpNGjxncFJRaiCtAkfMBIWXVH,'cast':qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('episodeactors'),}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'VOD','programid':qKlrygpNGjxncFJRaiCtAkfMBIWXVs,'contentid':qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('contentid'),'thumbnail':qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('thumbnail'),'title':qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('programtitle'),'subtitle':qKlrygpNGjxncFJRaiCtAkfMBIWXdE,}
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('programtitle'),sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXdE,img=qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('thumbnail'),infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUz,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXEu==1:
   qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'plot':'정렬순서를 변경합니다.'}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['mode'] ='ORDER_BY' 
   if qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_winEpisodeOrderby()=='desc':
    qKlrygpNGjxncFJRaiCtAkfMBIWXTv='정렬순서변경 : 최신화부터 -> 1회부터'
    qKlrygpNGjxncFJRaiCtAkfMBIWXTP['orderby']='asc'
   else:
    qKlrygpNGjxncFJRaiCtAkfMBIWXTv='정렬순서변경 : 1회부터 -> 최신화부터'
    qKlrygpNGjxncFJRaiCtAkfMBIWXTP['orderby']='desc'
   qKlrygpNGjxncFJRaiCtAkfMBIWXTb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img=qKlrygpNGjxncFJRaiCtAkfMBIWXTb,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUz,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP,isLink=qKlrygpNGjxncFJRaiCtAkfMBIWXUV)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXEw:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['mode'] ='EPISODE_LIST' 
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['seasonid']=qKlrygpNGjxncFJRaiCtAkfMBIWXVs
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['page'] =qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv='[B]%s >>[/B]'%'다음 페이지'
   qKlrygpNGjxncFJRaiCtAkfMBIWXdE=qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXdE,img=qKlrygpNGjxncFJRaiCtAkfMBIWXTb,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  xbmcplugin.setContent(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,'episodes')
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXEm)>0:xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_SuperSection_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXVh =args.get('suburl')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_SuperMultiSection_List(qKlrygpNGjxncFJRaiCtAkfMBIWXVh)
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('title')
   qKlrygpNGjxncFJRaiCtAkfMBIWXVQ =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('subapi')
   qKlrygpNGjxncFJRaiCtAkfMBIWXVS=qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('cell_type')
   if qKlrygpNGjxncFJRaiCtAkfMBIWXVQ.find('mtype=svod')>=0 or qKlrygpNGjxncFJRaiCtAkfMBIWXVQ.find('mtype=ppv')>=0 or qKlrygpNGjxncFJRaiCtAkfMBIWXVQ.find('contenttype=movie')>=0:
    qKlrygpNGjxncFJRaiCtAkfMBIWXTh='MOVIE_LIST'
   elif qKlrygpNGjxncFJRaiCtAkfMBIWXVQ.find('contenttype=program')>=0:
    qKlrygpNGjxncFJRaiCtAkfMBIWXTh='PROGRAM_LIST'
   elif qKlrygpNGjxncFJRaiCtAkfMBIWXVS=='band_71':
    qKlrygpNGjxncFJRaiCtAkfMBIWXTh ='SUPERSECTION_LIST'
    (qKlrygpNGjxncFJRaiCtAkfMBIWXVO,qKlrygpNGjxncFJRaiCtAkfMBIWXzw)=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Baseapi_Parse(qKlrygpNGjxncFJRaiCtAkfMBIWXVQ)
    qKlrygpNGjxncFJRaiCtAkfMBIWXVh=qKlrygpNGjxncFJRaiCtAkfMBIWXzw.get('api')
    qKlrygpNGjxncFJRaiCtAkfMBIWXVQ=''
   elif qKlrygpNGjxncFJRaiCtAkfMBIWXVS=='band_2':
    qKlrygpNGjxncFJRaiCtAkfMBIWXTh='BAND2SECTION_LIST'
   elif qKlrygpNGjxncFJRaiCtAkfMBIWXVS=='band_live':
    qKlrygpNGjxncFJRaiCtAkfMBIWXTh='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',qKlrygpNGjxncFJRaiCtAkfMBIWXVQ):
    qKlrygpNGjxncFJRaiCtAkfMBIWXTh='MOVIE_LIST'
   else:
    qKlrygpNGjxncFJRaiCtAkfMBIWXTh='PROGRAM_LIST'
   qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'plot':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'mediatype':'tvshow'}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':qKlrygpNGjxncFJRaiCtAkfMBIWXTh,'suburl':qKlrygpNGjxncFJRaiCtAkfMBIWXVh,'subapi':qKlrygpNGjxncFJRaiCtAkfMBIWXVQ,'page':'1'}
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXEm)>0:xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_BandLiveSection_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXVQ =args.get('subapi')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEu=qKlrygpNGjxncFJRaiCtAkfMBIWXUo(args.get('page'))
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm,qKlrygpNGjxncFJRaiCtAkfMBIWXEw=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_BandLiveSection_List(qKlrygpNGjxncFJRaiCtAkfMBIWXVQ,qKlrygpNGjxncFJRaiCtAkfMBIWXEu)
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   qKlrygpNGjxncFJRaiCtAkfMBIWXzT =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('channelid')
   qKlrygpNGjxncFJRaiCtAkfMBIWXzE =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('studio')
   qKlrygpNGjxncFJRaiCtAkfMBIWXzd=qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('tvshowtitle')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEH =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('thumbnail')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEh =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('age')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'mediatype':'tvshow','mpaa':qKlrygpNGjxncFJRaiCtAkfMBIWXEh,'title':'%s < %s >'%(qKlrygpNGjxncFJRaiCtAkfMBIWXzE,qKlrygpNGjxncFJRaiCtAkfMBIWXzd),'tvshowtitle':qKlrygpNGjxncFJRaiCtAkfMBIWXzd,'studio':qKlrygpNGjxncFJRaiCtAkfMBIWXzE,'plot':qKlrygpNGjxncFJRaiCtAkfMBIWXzE}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'LIVE','contentid':qKlrygpNGjxncFJRaiCtAkfMBIWXzT}
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXzE,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXzd,img=qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('thumbnail'),infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUz,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXEw:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['mode'] ='BANDLIVESECTION_LIST' 
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['subapi']=qKlrygpNGjxncFJRaiCtAkfMBIWXVQ
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['page'] =qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv='[B]%s >>[/B]'%'다음 페이지'
   qKlrygpNGjxncFJRaiCtAkfMBIWXdE=qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXdE,img=qKlrygpNGjxncFJRaiCtAkfMBIWXTb,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXEm)>0:xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_Band2Section_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXVQ =args.get('subapi')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEu=qKlrygpNGjxncFJRaiCtAkfMBIWXUo(args.get('page'))
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm,qKlrygpNGjxncFJRaiCtAkfMBIWXEw=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_Band2Section_List(qKlrygpNGjxncFJRaiCtAkfMBIWXVQ,qKlrygpNGjxncFJRaiCtAkfMBIWXEu)
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('programtitle')
   qKlrygpNGjxncFJRaiCtAkfMBIWXdE =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('episodetitle')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'plot':qKlrygpNGjxncFJRaiCtAkfMBIWXTv+'\n\n'+qKlrygpNGjxncFJRaiCtAkfMBIWXdE,'mpaa':qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('age'),'mediatype':'episode'}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'VOD','programid':'-','contentid':qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('videoid'),'thumbnail':qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('thumbnail'),'title':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'subtitle':qKlrygpNGjxncFJRaiCtAkfMBIWXdE}
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXdE,img=qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('thumbnail'),infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUz,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXEw:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['mode'] ='BAND2SECTION_LIST' 
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['subapi']=qKlrygpNGjxncFJRaiCtAkfMBIWXVQ
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['page'] =qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv='[B]%s >>[/B]'%'다음 페이지'
   qKlrygpNGjxncFJRaiCtAkfMBIWXdE=qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXdE,img=qKlrygpNGjxncFJRaiCtAkfMBIWXTb,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXEm)>0:xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_Movie_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXVQ =args.get('subapi')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEu=qKlrygpNGjxncFJRaiCtAkfMBIWXUo(args.get('page'))
  qKlrygpNGjxncFJRaiCtAkfMBIWXTU =args.get('orderby')or '-'
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm,qKlrygpNGjxncFJRaiCtAkfMBIWXEw=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_Movie_List(qKlrygpNGjxncFJRaiCtAkfMBIWXVQ,qKlrygpNGjxncFJRaiCtAkfMBIWXEu,qKlrygpNGjxncFJRaiCtAkfMBIWXTU)
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   qKlrygpNGjxncFJRaiCtAkfMBIWXED =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('videoid')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEL =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('vidtype')
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('title')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEH=qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('thumbnail')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEh =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('age')
   if qKlrygpNGjxncFJRaiCtAkfMBIWXEh=='18' or qKlrygpNGjxncFJRaiCtAkfMBIWXEh=='19' or qKlrygpNGjxncFJRaiCtAkfMBIWXEh=='21':qKlrygpNGjxncFJRaiCtAkfMBIWXTv+=' (%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXEh)
   qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'plot':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'mpaa':qKlrygpNGjxncFJRaiCtAkfMBIWXEh,'mediatype':'movie'}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'MOVIE','contentid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'title':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'thumbnail':qKlrygpNGjxncFJRaiCtAkfMBIWXEH,'age':qKlrygpNGjxncFJRaiCtAkfMBIWXEh,}
   qKlrygpNGjxncFJRaiCtAkfMBIWXEb=[]
   qKlrygpNGjxncFJRaiCtAkfMBIWXES={'mode':'VIEW_DETAIL','values':{'videoid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'vidtype':'movie','contenttype':qKlrygpNGjxncFJRaiCtAkfMBIWXEL,}}
   qKlrygpNGjxncFJRaiCtAkfMBIWXEO=json.dumps(qKlrygpNGjxncFJRaiCtAkfMBIWXES,separators=(',',':'))
   qKlrygpNGjxncFJRaiCtAkfMBIWXEO=base64.standard_b64encode(qKlrygpNGjxncFJRaiCtAkfMBIWXEO.encode()).decode('utf-8')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEO=qKlrygpNGjxncFJRaiCtAkfMBIWXEO.replace('+','%2B')
   qKlrygpNGjxncFJRaiCtAkfMBIWXdw='RunPlugin(plugin://plugin.video.wavvem/?params=%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXEO)
   qKlrygpNGjxncFJRaiCtAkfMBIWXEb.append(('상세정보 조회',qKlrygpNGjxncFJRaiCtAkfMBIWXdw))
   if qKlrygpNGjxncFJRaiCtAkfMBIWXwU.get_settings_makebookmark():
    qKlrygpNGjxncFJRaiCtAkfMBIWXES={'videoid':qKlrygpNGjxncFJRaiCtAkfMBIWXED,'vidtype':'movie','vtitle':qKlrygpNGjxncFJRaiCtAkfMBIWXTv,'vsubtitle':'','contenttype':'programid',}
    qKlrygpNGjxncFJRaiCtAkfMBIWXdT=json.dumps(qKlrygpNGjxncFJRaiCtAkfMBIWXES)
    qKlrygpNGjxncFJRaiCtAkfMBIWXdT=urllib.parse.quote(qKlrygpNGjxncFJRaiCtAkfMBIWXdT)
    qKlrygpNGjxncFJRaiCtAkfMBIWXdw='RunPlugin(plugin://plugin.video.wavvem/?mode=SET_BOOKMARK&bm_param=%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXdT)
    qKlrygpNGjxncFJRaiCtAkfMBIWXEb.append(('(통합) 찜 영상에 추가',qKlrygpNGjxncFJRaiCtAkfMBIWXdw))
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel='',img=qKlrygpNGjxncFJRaiCtAkfMBIWXEH,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUz,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP,ContextMenu=qKlrygpNGjxncFJRaiCtAkfMBIWXEb)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXEw:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['mode'] ='MOVIE_LIST' 
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['subapi']=qKlrygpNGjxncFJRaiCtAkfMBIWXVQ 
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['page'] =qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP['orderby']=qKlrygpNGjxncFJRaiCtAkfMBIWXTU
   qKlrygpNGjxncFJRaiCtAkfMBIWXTv='[B]%s >>[/B]'%'다음 페이지'
   qKlrygpNGjxncFJRaiCtAkfMBIWXdE=qKlrygpNGjxncFJRaiCtAkfMBIWXUb(qKlrygpNGjxncFJRaiCtAkfMBIWXEu+1)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTb=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXTv,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXdE,img=qKlrygpNGjxncFJRaiCtAkfMBIWXTb,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXUd,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUV,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  xbmcplugin.setContent(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,'movies')
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXEm)>0:xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_Set_Bookmark(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXzo=urllib.parse.unquote(args.get('bm_param'))
  qKlrygpNGjxncFJRaiCtAkfMBIWXzo=json.loads(qKlrygpNGjxncFJRaiCtAkfMBIWXzo)
  qKlrygpNGjxncFJRaiCtAkfMBIWXED =qKlrygpNGjxncFJRaiCtAkfMBIWXzo.get('videoid')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEL =qKlrygpNGjxncFJRaiCtAkfMBIWXzo.get('vidtype')
  qKlrygpNGjxncFJRaiCtAkfMBIWXzV =qKlrygpNGjxncFJRaiCtAkfMBIWXzo.get('vtitle')
  qKlrygpNGjxncFJRaiCtAkfMBIWXzU =qKlrygpNGjxncFJRaiCtAkfMBIWXzo.get('vsubtitle')
  qKlrygpNGjxncFJRaiCtAkfMBIWXzY=qKlrygpNGjxncFJRaiCtAkfMBIWXzo.get('contenttype')
  qKlrygpNGjxncFJRaiCtAkfMBIWXwb=xbmcgui.Dialog()
  qKlrygpNGjxncFJRaiCtAkfMBIWXdL=qKlrygpNGjxncFJRaiCtAkfMBIWXwb.yesno(__language__(30913).encode('utf8'),qKlrygpNGjxncFJRaiCtAkfMBIWXzV+' \n\n'+__language__(30914))
  if qKlrygpNGjxncFJRaiCtAkfMBIWXdL==qKlrygpNGjxncFJRaiCtAkfMBIWXUz:return
  qKlrygpNGjxncFJRaiCtAkfMBIWXzv=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.GetBookmarkInfo(qKlrygpNGjxncFJRaiCtAkfMBIWXED,qKlrygpNGjxncFJRaiCtAkfMBIWXEL,qKlrygpNGjxncFJRaiCtAkfMBIWXzY)
  qKlrygpNGjxncFJRaiCtAkfMBIWXzQ=json.dumps(qKlrygpNGjxncFJRaiCtAkfMBIWXzv)
  qKlrygpNGjxncFJRaiCtAkfMBIWXzQ=urllib.parse.quote(qKlrygpNGjxncFJRaiCtAkfMBIWXzQ)
  qKlrygpNGjxncFJRaiCtAkfMBIWXdw ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXzQ)
  xbmc.executebuiltin(qKlrygpNGjxncFJRaiCtAkfMBIWXdw)
 def dp_LiveChannel_List(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXzs =args.get('genre')
  qKlrygpNGjxncFJRaiCtAkfMBIWXVv=args.get('baseapi')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_LiveChannel_List(qKlrygpNGjxncFJRaiCtAkfMBIWXzs,qKlrygpNGjxncFJRaiCtAkfMBIWXVv)
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   qKlrygpNGjxncFJRaiCtAkfMBIWXzT =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('channelid')
   qKlrygpNGjxncFJRaiCtAkfMBIWXzE =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('studio')
   qKlrygpNGjxncFJRaiCtAkfMBIWXzd=qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('tvshowtitle')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEH =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('thumbnail')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEh =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('age')
   qKlrygpNGjxncFJRaiCtAkfMBIWXzb =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('epg')
   qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'mediatype':'episode','mpaa':qKlrygpNGjxncFJRaiCtAkfMBIWXEh,'title':'%s < %s >'%(qKlrygpNGjxncFJRaiCtAkfMBIWXzE,qKlrygpNGjxncFJRaiCtAkfMBIWXzd),'tvshowtitle':qKlrygpNGjxncFJRaiCtAkfMBIWXzd,'studio':qKlrygpNGjxncFJRaiCtAkfMBIWXzE,'plot':'%s\n\n%s'%(qKlrygpNGjxncFJRaiCtAkfMBIWXzE,qKlrygpNGjxncFJRaiCtAkfMBIWXzb)}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'LIVE','contentid':qKlrygpNGjxncFJRaiCtAkfMBIWXzT}
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXzE,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXzd,img=qKlrygpNGjxncFJRaiCtAkfMBIWXEH,infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUz,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXUQ(qKlrygpNGjxncFJRaiCtAkfMBIWXEm)>0:xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_Sports_GameList(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,args):
  qKlrygpNGjxncFJRaiCtAkfMBIWXEm=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.Get_Sports_Gamelist()
  for qKlrygpNGjxncFJRaiCtAkfMBIWXEe in qKlrygpNGjxncFJRaiCtAkfMBIWXEm:
   qKlrygpNGjxncFJRaiCtAkfMBIWXzP =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('game_date')
   qKlrygpNGjxncFJRaiCtAkfMBIWXzu =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('game_time')
   qKlrygpNGjxncFJRaiCtAkfMBIWXzm =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('svc_id')
   qKlrygpNGjxncFJRaiCtAkfMBIWXze =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('away_team')
   qKlrygpNGjxncFJRaiCtAkfMBIWXzD =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('home_team')
   qKlrygpNGjxncFJRaiCtAkfMBIWXzL=qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('game_status')
   qKlrygpNGjxncFJRaiCtAkfMBIWXzH =qKlrygpNGjxncFJRaiCtAkfMBIWXEe.get('game_place')
   qKlrygpNGjxncFJRaiCtAkfMBIWXzh ='%s vs %s (%s)'%(qKlrygpNGjxncFJRaiCtAkfMBIWXze,qKlrygpNGjxncFJRaiCtAkfMBIWXzD,qKlrygpNGjxncFJRaiCtAkfMBIWXzH)
   qKlrygpNGjxncFJRaiCtAkfMBIWXzS =qKlrygpNGjxncFJRaiCtAkfMBIWXzP+' '+qKlrygpNGjxncFJRaiCtAkfMBIWXzu
   if qKlrygpNGjxncFJRaiCtAkfMBIWXzL=='LIVE':
    qKlrygpNGjxncFJRaiCtAkfMBIWXzL='~경기중~'
   elif qKlrygpNGjxncFJRaiCtAkfMBIWXzL=='END':
    qKlrygpNGjxncFJRaiCtAkfMBIWXzL='경기종료'
   elif qKlrygpNGjxncFJRaiCtAkfMBIWXzL=='CANCEL':
    qKlrygpNGjxncFJRaiCtAkfMBIWXzL='취소'
   else:
    qKlrygpNGjxncFJRaiCtAkfMBIWXzL=''
   if qKlrygpNGjxncFJRaiCtAkfMBIWXzL=='':
    qKlrygpNGjxncFJRaiCtAkfMBIWXdE=qKlrygpNGjxncFJRaiCtAkfMBIWXzh
   else:
    qKlrygpNGjxncFJRaiCtAkfMBIWXdE=qKlrygpNGjxncFJRaiCtAkfMBIWXzh+'  '+qKlrygpNGjxncFJRaiCtAkfMBIWXzL
   qKlrygpNGjxncFJRaiCtAkfMBIWXEP={'mediatype':'episode','title':qKlrygpNGjxncFJRaiCtAkfMBIWXzh,'plot':'%s\n\n%s\n\n%s'%(qKlrygpNGjxncFJRaiCtAkfMBIWXzS,qKlrygpNGjxncFJRaiCtAkfMBIWXzh,qKlrygpNGjxncFJRaiCtAkfMBIWXzL)}
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'SPORTS','contentid':qKlrygpNGjxncFJRaiCtAkfMBIWXzm}
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.add_dir(qKlrygpNGjxncFJRaiCtAkfMBIWXzS,sublabel=qKlrygpNGjxncFJRaiCtAkfMBIWXdE,img='',infoLabels=qKlrygpNGjxncFJRaiCtAkfMBIWXEP,isFolder=qKlrygpNGjxncFJRaiCtAkfMBIWXUz,params=qKlrygpNGjxncFJRaiCtAkfMBIWXTP)
  xbmcplugin.endOfDirectory(qKlrygpNGjxncFJRaiCtAkfMBIWXwU._addon_handle,cacheToDisc=qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
 def dp_View_Detail(qKlrygpNGjxncFJRaiCtAkfMBIWXwU,qKlrygpNGjxncFJRaiCtAkfMBIWXUT):
  qKlrygpNGjxncFJRaiCtAkfMBIWXED =qKlrygpNGjxncFJRaiCtAkfMBIWXUT.get('videoid')
  qKlrygpNGjxncFJRaiCtAkfMBIWXEL =qKlrygpNGjxncFJRaiCtAkfMBIWXUT.get('vidtype') 
  qKlrygpNGjxncFJRaiCtAkfMBIWXzY=qKlrygpNGjxncFJRaiCtAkfMBIWXUT.get('contenttype')
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.addon_log(qKlrygpNGjxncFJRaiCtAkfMBIWXED)
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.addon_log(qKlrygpNGjxncFJRaiCtAkfMBIWXEL)
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.addon_log(qKlrygpNGjxncFJRaiCtAkfMBIWXzY)
  qKlrygpNGjxncFJRaiCtAkfMBIWXzv=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.WavveObj.GetBookmarkInfo(qKlrygpNGjxncFJRaiCtAkfMBIWXED,qKlrygpNGjxncFJRaiCtAkfMBIWXEL,qKlrygpNGjxncFJRaiCtAkfMBIWXzY)
  if qKlrygpNGjxncFJRaiCtAkfMBIWXEL=='tvshow':
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'SEASON_LIST','videoid':qKlrygpNGjxncFJRaiCtAkfMBIWXzv['indexinfo']['videoid'],'vidtype':qKlrygpNGjxncFJRaiCtAkfMBIWXzv['indexinfo']['vidtype'],}
   qKlrygpNGjxncFJRaiCtAkfMBIWXdO='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(qKlrygpNGjxncFJRaiCtAkfMBIWXTP))
  else:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTP={'mode':'MOVIE','contentid':qKlrygpNGjxncFJRaiCtAkfMBIWXzv['indexinfo']['videoid'],'title':qKlrygpNGjxncFJRaiCtAkfMBIWXzv['saveinfo']['infoLabels']['title'],'thumbnail':qKlrygpNGjxncFJRaiCtAkfMBIWXzv['saveinfo']['thumbnail'],'age':qKlrygpNGjxncFJRaiCtAkfMBIWXzv['saveinfo']['infoLabels']['mpaa'],}
   qKlrygpNGjxncFJRaiCtAkfMBIWXdO='plugin://plugin.video.wavvem/?%s'%(urllib.parse.urlencode(qKlrygpNGjxncFJRaiCtAkfMBIWXTP))
  qKlrygpNGjxncFJRaiCtAkfMBIWXTQ=xbmcgui.ListItem(label=qKlrygpNGjxncFJRaiCtAkfMBIWXzv['saveinfo']['title'],path=qKlrygpNGjxncFJRaiCtAkfMBIWXdO)
  qKlrygpNGjxncFJRaiCtAkfMBIWXTQ.setArt(qKlrygpNGjxncFJRaiCtAkfMBIWXzv['saveinfo']['thumbnail'])
  qKlrygpNGjxncFJRaiCtAkfMBIWXTQ.setInfo('Video',qKlrygpNGjxncFJRaiCtAkfMBIWXzv['saveinfo']['infoLabels'])
  if qKlrygpNGjxncFJRaiCtAkfMBIWXEL=='movie':
   qKlrygpNGjxncFJRaiCtAkfMBIWXTQ.setIsFolder(qKlrygpNGjxncFJRaiCtAkfMBIWXUz)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTQ.setProperty('IsPlayable','true')
  else:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTQ.setIsFolder(qKlrygpNGjxncFJRaiCtAkfMBIWXUV)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTQ.setProperty('IsPlayable','false')
  qKlrygpNGjxncFJRaiCtAkfMBIWXwb=xbmcgui.Dialog()
  qKlrygpNGjxncFJRaiCtAkfMBIWXwb.info(qKlrygpNGjxncFJRaiCtAkfMBIWXTQ)
 def wavve_main(qKlrygpNGjxncFJRaiCtAkfMBIWXwU):
  qKlrygpNGjxncFJRaiCtAkfMBIWXzO=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.main_params.get('params')
  if qKlrygpNGjxncFJRaiCtAkfMBIWXzO:
   qKlrygpNGjxncFJRaiCtAkfMBIWXUw =base64.standard_b64decode(qKlrygpNGjxncFJRaiCtAkfMBIWXzO).decode('utf-8')
   qKlrygpNGjxncFJRaiCtAkfMBIWXUw =json.loads(qKlrygpNGjxncFJRaiCtAkfMBIWXUw)
   qKlrygpNGjxncFJRaiCtAkfMBIWXTh =qKlrygpNGjxncFJRaiCtAkfMBIWXUw.get('mode')
   qKlrygpNGjxncFJRaiCtAkfMBIWXUT =qKlrygpNGjxncFJRaiCtAkfMBIWXUw.get('values')
  else:
   qKlrygpNGjxncFJRaiCtAkfMBIWXTh=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.main_params.get('mode',qKlrygpNGjxncFJRaiCtAkfMBIWXUd)
   qKlrygpNGjxncFJRaiCtAkfMBIWXUT=qKlrygpNGjxncFJRaiCtAkfMBIWXwU.main_params
  if qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='LOGOUT':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.logout()
   return
  qKlrygpNGjxncFJRaiCtAkfMBIWXwU.login_main()
  if qKlrygpNGjxncFJRaiCtAkfMBIWXTh is qKlrygpNGjxncFJRaiCtAkfMBIWXUd:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Main_List()
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh in['LIVE','VOD','MOVIE','SPORTS']:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.play_VIDEO(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='LIVE_CATAGORY':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_LiveCatagory_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='MAIN_CATAGORY':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_MainCatagory_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='SUPERSECTION_LIST':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_SuperSection_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='BANDLIVESECTION_LIST':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_BandLiveSection_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='BAND2SECTION_LIST':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Band2Section_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='PROGRAM_LIST':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Program_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='SEASON_LIST':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Season_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='EPISODE_LIST':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Episode_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='MOVIE_LIST':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Movie_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='LIVE_LIST':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_LiveChannel_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='ORDER_BY':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_setEpOrderby(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='SEARCH_GROUP':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Search_Group(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh in['SEARCH_LIST','LOCAL_SEARCH']:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Search_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='WATCH_GROUP':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Watch_Group(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='WATCH_LIST':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Watch_List(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='SET_BOOKMARK':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Set_Bookmark(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_History_Remove(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh in['TOTAL_SEARCH','TOTAL_HISTORY']:
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Global_Search(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='SEARCH_HISTORY':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Search_History(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='MENU_BOOKMARK':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Bookmark_Menu(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='GAME_LIST':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_Sports_GameList(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  elif qKlrygpNGjxncFJRaiCtAkfMBIWXTh=='VIEW_DETAIL':
   qKlrygpNGjxncFJRaiCtAkfMBIWXwU.dp_View_Detail(qKlrygpNGjxncFJRaiCtAkfMBIWXUT)
  else:
   qKlrygpNGjxncFJRaiCtAkfMBIWXUd
# Created by pyminifier (https://github.com/liftoff/pyminifier)
