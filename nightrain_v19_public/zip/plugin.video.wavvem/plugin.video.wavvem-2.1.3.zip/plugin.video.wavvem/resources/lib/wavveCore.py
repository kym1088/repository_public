__author__="NightRain"
kfJqgKmUryQnWVztHbhXFCNoEveaTL=object
kfJqgKmUryQnWVztHbhXFCNoEveaTY=None
kfJqgKmUryQnWVztHbhXFCNoEveaTc=False
kfJqgKmUryQnWVztHbhXFCNoEveaTB=True
kfJqgKmUryQnWVztHbhXFCNoEveaTu=range
kfJqgKmUryQnWVztHbhXFCNoEveaTp=str
kfJqgKmUryQnWVztHbhXFCNoEveaTS=Exception
kfJqgKmUryQnWVztHbhXFCNoEveaTD=print
kfJqgKmUryQnWVztHbhXFCNoEveaTA=dict
kfJqgKmUryQnWVztHbhXFCNoEveaTj=int
kfJqgKmUryQnWVztHbhXFCNoEveaTs=len
import urllib
import http.cookiejar 
import re
import json
import sys
import requests
import datetime
class kfJqgKmUryQnWVztHbhXFCNoEveaGl(kfJqgKmUryQnWVztHbhXFCNoEveaTL):
 def __init__(kfJqgKmUryQnWVztHbhXFCNoEveaGR):
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN='https://apis.wavve.com'
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.CREDENTIAL='none'
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.DEVICE ='pc'
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.DRM ='wm'
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.PARTNER ='pooq'
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.POOQZONE ='none'
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.REGION ='kor'
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.TARGETAGE ='all'
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.HTTPTAG ='https://'
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT=30 
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.EP_LIMIT =30 
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.MV_LIMIT =24 
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.guid ='none' 
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.guidtimestamp='none' 
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.DEFAULT_HEADER={'user-agent':kfJqgKmUryQnWVztHbhXFCNoEveaGR.USER_AGENT}
 def callRequestCookies(kfJqgKmUryQnWVztHbhXFCNoEveaGR,jobtype,kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaTY,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY,redirects=kfJqgKmUryQnWVztHbhXFCNoEveaTc):
  kfJqgKmUryQnWVztHbhXFCNoEveaGT=kfJqgKmUryQnWVztHbhXFCNoEveaGR.DEFAULT_HEADER
  if headers:kfJqgKmUryQnWVztHbhXFCNoEveaGT.update(headers)
  if jobtype=='Get':
   kfJqgKmUryQnWVztHbhXFCNoEveaGP=requests.get(kfJqgKmUryQnWVztHbhXFCNoEveaGj,params=params,headers=kfJqgKmUryQnWVztHbhXFCNoEveaGT,cookies=cookies,allow_redirects=redirects)
  else:
   kfJqgKmUryQnWVztHbhXFCNoEveaGP=requests.post(kfJqgKmUryQnWVztHbhXFCNoEveaGj,data=payload,params=params,headers=kfJqgKmUryQnWVztHbhXFCNoEveaGT,cookies=cookies,allow_redirects=redirects)
  return kfJqgKmUryQnWVztHbhXFCNoEveaGP
 def SaveCredential(kfJqgKmUryQnWVztHbhXFCNoEveaGR,kfJqgKmUryQnWVztHbhXFCNoEveaGi):
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.CREDENTIAL=kfJqgKmUryQnWVztHbhXFCNoEveaGi
 def LoadCredential(kfJqgKmUryQnWVztHbhXFCNoEveaGR):
  return kfJqgKmUryQnWVztHbhXFCNoEveaGR.CREDENTIAL
 def GetDefaultParams(kfJqgKmUryQnWVztHbhXFCNoEveaGR,login=kfJqgKmUryQnWVztHbhXFCNoEveaTB):
  kfJqgKmUryQnWVztHbhXFCNoEveaGM={'apikey':kfJqgKmUryQnWVztHbhXFCNoEveaGR.APIKEY,'credential':kfJqgKmUryQnWVztHbhXFCNoEveaGR.CREDENTIAL if login else 'none','device':kfJqgKmUryQnWVztHbhXFCNoEveaGR.DEVICE,'drm':kfJqgKmUryQnWVztHbhXFCNoEveaGR.DRM,'partner':kfJqgKmUryQnWVztHbhXFCNoEveaGR.PARTNER,'pooqzone':kfJqgKmUryQnWVztHbhXFCNoEveaGR.POOQZONE,'region':kfJqgKmUryQnWVztHbhXFCNoEveaGR.REGION,'targetage':kfJqgKmUryQnWVztHbhXFCNoEveaGR.TARGETAGE}
  return kfJqgKmUryQnWVztHbhXFCNoEveaGM
 def GetGUID(kfJqgKmUryQnWVztHbhXFCNoEveaGR,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   kfJqgKmUryQnWVztHbhXFCNoEveaGd=kfJqgKmUryQnWVztHbhXFCNoEveaGR.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   kfJqgKmUryQnWVztHbhXFCNoEveaGL=GenerateRandomString(5)
   kfJqgKmUryQnWVztHbhXFCNoEveaGY=kfJqgKmUryQnWVztHbhXFCNoEveaGL+media+kfJqgKmUryQnWVztHbhXFCNoEveaGd
   return kfJqgKmUryQnWVztHbhXFCNoEveaGY
  def GenerateRandomString(num):
   from random import randint
   kfJqgKmUryQnWVztHbhXFCNoEveaGc=""
   for i in kfJqgKmUryQnWVztHbhXFCNoEveaTu(0,num):
    s=kfJqgKmUryQnWVztHbhXFCNoEveaTp(randint(1,5))
    kfJqgKmUryQnWVztHbhXFCNoEveaGc+=s
   return kfJqgKmUryQnWVztHbhXFCNoEveaGc
  kfJqgKmUryQnWVztHbhXFCNoEveaGY=GenerateID(guid_str)
  kfJqgKmUryQnWVztHbhXFCNoEveaGB=kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetHash(kfJqgKmUryQnWVztHbhXFCNoEveaGY)
  if guidType==2:
   kfJqgKmUryQnWVztHbhXFCNoEveaGB='%s-%s-%s-%s-%s'%(kfJqgKmUryQnWVztHbhXFCNoEveaGB[:8],kfJqgKmUryQnWVztHbhXFCNoEveaGB[8:12],kfJqgKmUryQnWVztHbhXFCNoEveaGB[12:16],kfJqgKmUryQnWVztHbhXFCNoEveaGB[16:20],kfJqgKmUryQnWVztHbhXFCNoEveaGB[20:])
  return kfJqgKmUryQnWVztHbhXFCNoEveaGB
 def GetHash(kfJqgKmUryQnWVztHbhXFCNoEveaGR,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return kfJqgKmUryQnWVztHbhXFCNoEveaTp(m.hexdigest())
 def CheckQuality(kfJqgKmUryQnWVztHbhXFCNoEveaGR,sel_qt,qt_list):
  kfJqgKmUryQnWVztHbhXFCNoEveaGu=0
  for kfJqgKmUryQnWVztHbhXFCNoEveaGp in qt_list:
   if sel_qt>=kfJqgKmUryQnWVztHbhXFCNoEveaGp:return kfJqgKmUryQnWVztHbhXFCNoEveaGp
   kfJqgKmUryQnWVztHbhXFCNoEveaGu=kfJqgKmUryQnWVztHbhXFCNoEveaGp
  return kfJqgKmUryQnWVztHbhXFCNoEveaGu
 def Get_Now_Datetime(kfJqgKmUryQnWVztHbhXFCNoEveaGR):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(kfJqgKmUryQnWVztHbhXFCNoEveaGR,in_text):
  kfJqgKmUryQnWVztHbhXFCNoEveaGD=in_text.replace('&lt;','<').replace('&gt;','>')
  kfJqgKmUryQnWVztHbhXFCNoEveaGD=kfJqgKmUryQnWVztHbhXFCNoEveaGD.replace('$O$','')
  kfJqgKmUryQnWVztHbhXFCNoEveaGD=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',kfJqgKmUryQnWVztHbhXFCNoEveaGD)
  kfJqgKmUryQnWVztHbhXFCNoEveaGD=kfJqgKmUryQnWVztHbhXFCNoEveaGD.lstrip('#')
  return kfJqgKmUryQnWVztHbhXFCNoEveaGD
 def GetCredential(kfJqgKmUryQnWVztHbhXFCNoEveaGR,user_id,user_pw,user_pf):
  kfJqgKmUryQnWVztHbhXFCNoEveaGA=kfJqgKmUryQnWVztHbhXFCNoEveaTc
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+ '/login'
   kfJqgKmUryQnWVztHbhXFCNoEveaGM=kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams()
   kfJqgKmUryQnWVztHbhXFCNoEveaGs={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Post',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaGs,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   kfJqgKmUryQnWVztHbhXFCNoEveaGi=kfJqgKmUryQnWVztHbhXFCNoEveaGO['credential']
   if user_pf!=0:
    kfJqgKmUryQnWVztHbhXFCNoEveaGs={'id':kfJqgKmUryQnWVztHbhXFCNoEveaGi,'password':'','profile':kfJqgKmUryQnWVztHbhXFCNoEveaTp(user_pf),'pushid':'','type':'credential'}
    kfJqgKmUryQnWVztHbhXFCNoEveaGM['credential']=kfJqgKmUryQnWVztHbhXFCNoEveaGi 
    kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Post',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaGs,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
    kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
    kfJqgKmUryQnWVztHbhXFCNoEveaGi=kfJqgKmUryQnWVztHbhXFCNoEveaGO['credential']
   if kfJqgKmUryQnWVztHbhXFCNoEveaGi:kfJqgKmUryQnWVztHbhXFCNoEveaGA=kfJqgKmUryQnWVztHbhXFCNoEveaTB
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   kfJqgKmUryQnWVztHbhXFCNoEveaGi='none' 
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.SaveCredential(kfJqgKmUryQnWVztHbhXFCNoEveaGi)
  return kfJqgKmUryQnWVztHbhXFCNoEveaGA
 def GetIssue(kfJqgKmUryQnWVztHbhXFCNoEveaGR):
  kfJqgKmUryQnWVztHbhXFCNoEveaGI=kfJqgKmUryQnWVztHbhXFCNoEveaTc
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+'/guid/issue'
   kfJqgKmUryQnWVztHbhXFCNoEveaGM=kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams()
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   kfJqgKmUryQnWVztHbhXFCNoEveaGw=kfJqgKmUryQnWVztHbhXFCNoEveaGO['guid']
   kfJqgKmUryQnWVztHbhXFCNoEvealG=kfJqgKmUryQnWVztHbhXFCNoEveaGO['guidtimestamp']
   if kfJqgKmUryQnWVztHbhXFCNoEveaGw:kfJqgKmUryQnWVztHbhXFCNoEveaGI=kfJqgKmUryQnWVztHbhXFCNoEveaTB
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   kfJqgKmUryQnWVztHbhXFCNoEveaGw='none'
   kfJqgKmUryQnWVztHbhXFCNoEvealG='none' 
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.guid=kfJqgKmUryQnWVztHbhXFCNoEveaGw
  kfJqgKmUryQnWVztHbhXFCNoEveaGR.guidtimestamp=kfJqgKmUryQnWVztHbhXFCNoEvealG
  return kfJqgKmUryQnWVztHbhXFCNoEveaGI
 def Baseapi_Parse(kfJqgKmUryQnWVztHbhXFCNoEveaGR,kfJqgKmUryQnWVztHbhXFCNoEveali):
  try:
   kfJqgKmUryQnWVztHbhXFCNoEvealR =urllib.parse.urlsplit(kfJqgKmUryQnWVztHbhXFCNoEveali)
   if kfJqgKmUryQnWVztHbhXFCNoEvealR.netloc=='':
    kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEveaGR.HTTPTAG+kfJqgKmUryQnWVztHbhXFCNoEvealR.netloc+kfJqgKmUryQnWVztHbhXFCNoEvealR.path
   else:
    kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEvealR.scheme+'://'+kfJqgKmUryQnWVztHbhXFCNoEvealR.netloc+kfJqgKmUryQnWVztHbhXFCNoEvealR.path
   kfJqgKmUryQnWVztHbhXFCNoEveaGM=kfJqgKmUryQnWVztHbhXFCNoEveaTA(urllib.parse.parse_qsl(kfJqgKmUryQnWVztHbhXFCNoEvealR.query))
  except:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return '',{}
  return kfJqgKmUryQnWVztHbhXFCNoEveaGj,kfJqgKmUryQnWVztHbhXFCNoEveaGM
 def GetSupermultiUrl(kfJqgKmUryQnWVztHbhXFCNoEveaGR,sCode,sIndex='0'):
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+'/cf/supermultisections/'+sCode
   kfJqgKmUryQnWVztHbhXFCNoEveaGM=kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc)
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   kfJqgKmUryQnWVztHbhXFCNoEvealT=kfJqgKmUryQnWVztHbhXFCNoEveaGO['multisectionlist'][kfJqgKmUryQnWVztHbhXFCNoEveaTj(sIndex)]['eventlist'][1]['url']
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return ''
  return kfJqgKmUryQnWVztHbhXFCNoEvealT
 def Get_LiveCatagory_List(kfJqgKmUryQnWVztHbhXFCNoEveaGR,sCode,sIndex='0'):
  kfJqgKmUryQnWVztHbhXFCNoEvealP=[]
  kfJqgKmUryQnWVztHbhXFCNoEveali =kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetSupermultiUrl(sCode,sIndex)
  (kfJqgKmUryQnWVztHbhXFCNoEveaGj,kfJqgKmUryQnWVztHbhXFCNoEveaGM)=kfJqgKmUryQnWVztHbhXFCNoEveaGR.Baseapi_Parse(kfJqgKmUryQnWVztHbhXFCNoEveali)
  if kfJqgKmUryQnWVztHbhXFCNoEveaGj=='':return kfJqgKmUryQnWVztHbhXFCNoEvealP,''
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc))
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   if not('filter_item_list' in kfJqgKmUryQnWVztHbhXFCNoEveaGO['filter']['filterlist'][0]):return[],''
   kfJqgKmUryQnWVztHbhXFCNoEveald=kfJqgKmUryQnWVztHbhXFCNoEveaGO['filter']['filterlist'][0]['filter_item_list']
   for kfJqgKmUryQnWVztHbhXFCNoEvealL in kfJqgKmUryQnWVztHbhXFCNoEveald:
    kfJqgKmUryQnWVztHbhXFCNoEvealY={'title':kfJqgKmUryQnWVztHbhXFCNoEvealL['title'],'genre':kfJqgKmUryQnWVztHbhXFCNoEvealL['api_parameters'][kfJqgKmUryQnWVztHbhXFCNoEvealL['api_parameters'].index('=')+1:]}
    kfJqgKmUryQnWVztHbhXFCNoEvealP.append(kfJqgKmUryQnWVztHbhXFCNoEvealY)
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[],''
  return kfJqgKmUryQnWVztHbhXFCNoEvealP,kfJqgKmUryQnWVztHbhXFCNoEveali
 def Get_MainCatagory_List(kfJqgKmUryQnWVztHbhXFCNoEveaGR,sCode,sIndex='0'):
  kfJqgKmUryQnWVztHbhXFCNoEvealP=[]
  kfJqgKmUryQnWVztHbhXFCNoEveali =kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetSupermultiUrl(sCode,sIndex)
  (kfJqgKmUryQnWVztHbhXFCNoEveaGj,kfJqgKmUryQnWVztHbhXFCNoEveaGM)=kfJqgKmUryQnWVztHbhXFCNoEveaGR.Baseapi_Parse(kfJqgKmUryQnWVztHbhXFCNoEveali)
  if kfJqgKmUryQnWVztHbhXFCNoEveaGj=='':return kfJqgKmUryQnWVztHbhXFCNoEvealP
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc))
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   if not('celllist' in kfJqgKmUryQnWVztHbhXFCNoEveaGO['band']):return[]
   kfJqgKmUryQnWVztHbhXFCNoEveald=kfJqgKmUryQnWVztHbhXFCNoEveaGO['band']['celllist']
   for kfJqgKmUryQnWVztHbhXFCNoEvealL in kfJqgKmUryQnWVztHbhXFCNoEveald:
    kfJqgKmUryQnWVztHbhXFCNoEvealc =kfJqgKmUryQnWVztHbhXFCNoEvealL['event_list'][1]['url']
    (kfJqgKmUryQnWVztHbhXFCNoEvealB,kfJqgKmUryQnWVztHbhXFCNoEvealu)=kfJqgKmUryQnWVztHbhXFCNoEveaGR.Baseapi_Parse(kfJqgKmUryQnWVztHbhXFCNoEvealc)
    kfJqgKmUryQnWVztHbhXFCNoEvealY={'title':kfJqgKmUryQnWVztHbhXFCNoEvealL['title_list'][0]['text'],'suburl':kfJqgKmUryQnWVztHbhXFCNoEvealB,'subapi':kfJqgKmUryQnWVztHbhXFCNoEvealu.get('api'),'subtype':'catagory' if kfJqgKmUryQnWVztHbhXFCNoEvealu else 'supersection'}
    kfJqgKmUryQnWVztHbhXFCNoEvealP.append(kfJqgKmUryQnWVztHbhXFCNoEvealY)
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[]
  return kfJqgKmUryQnWVztHbhXFCNoEvealP
 def Get_SuperMultiSection_List(kfJqgKmUryQnWVztHbhXFCNoEveaGR,subapi_text):
  kfJqgKmUryQnWVztHbhXFCNoEvealP=[]
  kfJqgKmUryQnWVztHbhXFCNoEveaGM={}
  try:
   kfJqgKmUryQnWVztHbhXFCNoEvealR =urllib.parse.urlsplit(subapi_text)
   if kfJqgKmUryQnWVztHbhXFCNoEvealR.path.find('apis.wavve.com')>=0: 
    kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEveaGR.HTTPTAG+kfJqgKmUryQnWVztHbhXFCNoEvealR.path 
    kfJqgKmUryQnWVztHbhXFCNoEveaGM=kfJqgKmUryQnWVztHbhXFCNoEveaTA(urllib.parse.parse_qsl(kfJqgKmUryQnWVztHbhXFCNoEvealR.query))
   else:
    kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+'/cf'+kfJqgKmUryQnWVztHbhXFCNoEvealR.path 
   kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEveaGj.replace('supermultisection/','supermultisections/')
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[]
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc))
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaTY,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   if not('multisectionlist' in kfJqgKmUryQnWVztHbhXFCNoEveaGO):return[]
   kfJqgKmUryQnWVztHbhXFCNoEveald=kfJqgKmUryQnWVztHbhXFCNoEveaGO['multisectionlist']
   for kfJqgKmUryQnWVztHbhXFCNoEvealL in kfJqgKmUryQnWVztHbhXFCNoEveald:
    kfJqgKmUryQnWVztHbhXFCNoEvealp=kfJqgKmUryQnWVztHbhXFCNoEvealL['title']
    if kfJqgKmUryQnWVztHbhXFCNoEveaTs(kfJqgKmUryQnWVztHbhXFCNoEvealp)==0:continue
    if kfJqgKmUryQnWVztHbhXFCNoEvealp=='minor':continue
    if re.search(u'베너',kfJqgKmUryQnWVztHbhXFCNoEvealp):continue
    if re.search(u'배너',kfJqgKmUryQnWVztHbhXFCNoEvealp):continue 
    if kfJqgKmUryQnWVztHbhXFCNoEveaTs(kfJqgKmUryQnWVztHbhXFCNoEvealL['eventlist'])>=3:
     kfJqgKmUryQnWVztHbhXFCNoEvealu =kfJqgKmUryQnWVztHbhXFCNoEvealL['eventlist'][2]['url']
    else:
     kfJqgKmUryQnWVztHbhXFCNoEvealu =kfJqgKmUryQnWVztHbhXFCNoEvealL['eventlist'][1]['url']
    kfJqgKmUryQnWVztHbhXFCNoEvealS=kfJqgKmUryQnWVztHbhXFCNoEvealL['cell_type']
    if kfJqgKmUryQnWVztHbhXFCNoEvealS=='band_2':
     if kfJqgKmUryQnWVztHbhXFCNoEvealu.find('channellist=')>=0:
      kfJqgKmUryQnWVztHbhXFCNoEvealS='band_live'
    kfJqgKmUryQnWVztHbhXFCNoEvealY={'title':kfJqgKmUryQnWVztHbhXFCNoEveaGR.Get_ChangeText(kfJqgKmUryQnWVztHbhXFCNoEvealp),'subapi':kfJqgKmUryQnWVztHbhXFCNoEvealu,'cell_type':kfJqgKmUryQnWVztHbhXFCNoEvealS}
    kfJqgKmUryQnWVztHbhXFCNoEvealP.append(kfJqgKmUryQnWVztHbhXFCNoEvealY)
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[]
  return kfJqgKmUryQnWVztHbhXFCNoEvealP
 def Get_BandLiveSection_List(kfJqgKmUryQnWVztHbhXFCNoEveaGR,kfJqgKmUryQnWVztHbhXFCNoEveali,page_int=1):
  kfJqgKmUryQnWVztHbhXFCNoEvealD=[]
  kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEvealw=1
  kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEveaTc
  try:
   (kfJqgKmUryQnWVztHbhXFCNoEveaGj,kfJqgKmUryQnWVztHbhXFCNoEveaGM)=kfJqgKmUryQnWVztHbhXFCNoEveaGR.Baseapi_Parse(kfJqgKmUryQnWVztHbhXFCNoEveali)
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[],kfJqgKmUryQnWVztHbhXFCNoEveaTc
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['limit']=kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['offset']=kfJqgKmUryQnWVztHbhXFCNoEveaTp((page_int-1)*kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT)
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc))
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   if not('celllist' in kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']):return[],kfJqgKmUryQnWVztHbhXFCNoEveaTc
   kfJqgKmUryQnWVztHbhXFCNoEveald=kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['celllist']
   for kfJqgKmUryQnWVztHbhXFCNoEvealL in kfJqgKmUryQnWVztHbhXFCNoEveald:
    kfJqgKmUryQnWVztHbhXFCNoEveals =kfJqgKmUryQnWVztHbhXFCNoEvealL['event_list'][1]['url']
    kfJqgKmUryQnWVztHbhXFCNoEvealx=urllib.parse.urlsplit(kfJqgKmUryQnWVztHbhXFCNoEveals).query
    kfJqgKmUryQnWVztHbhXFCNoEvealx=kfJqgKmUryQnWVztHbhXFCNoEveaTA(urllib.parse.parse_qsl(kfJqgKmUryQnWVztHbhXFCNoEvealx))
    kfJqgKmUryQnWVztHbhXFCNoEvealO='channelid'
    kfJqgKmUryQnWVztHbhXFCNoEvealI=kfJqgKmUryQnWVztHbhXFCNoEvealx[kfJqgKmUryQnWVztHbhXFCNoEvealO]
    kfJqgKmUryQnWVztHbhXFCNoEvealY={'studio':kfJqgKmUryQnWVztHbhXFCNoEvealL['title_list'][0]['text'],'tvshowtitle':kfJqgKmUryQnWVztHbhXFCNoEveaGR.Get_ChangeText(kfJqgKmUryQnWVztHbhXFCNoEvealL['title_list'][1]['text']),'channelid':kfJqgKmUryQnWVztHbhXFCNoEvealI,'age':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('age'),'thumbnail':'https://%s'%kfJqgKmUryQnWVztHbhXFCNoEvealL.get('thumbnail')}
    kfJqgKmUryQnWVztHbhXFCNoEvealD.append(kfJqgKmUryQnWVztHbhXFCNoEvealY)
   kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['pagecount'])
   if kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['count']:kfJqgKmUryQnWVztHbhXFCNoEvealw =kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['count'])
   else:kfJqgKmUryQnWVztHbhXFCNoEvealw=kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT*page_int
   kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEvealA>kfJqgKmUryQnWVztHbhXFCNoEvealw
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[],kfJqgKmUryQnWVztHbhXFCNoEveaTc
  return kfJqgKmUryQnWVztHbhXFCNoEvealD,kfJqgKmUryQnWVztHbhXFCNoEvealj
 def Get_Band2Section_List(kfJqgKmUryQnWVztHbhXFCNoEveaGR,kfJqgKmUryQnWVztHbhXFCNoEveali,page_int=1):
  kfJqgKmUryQnWVztHbhXFCNoEveaRG=[]
  kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEvealw=1
  kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEveaTc
  try:
   (kfJqgKmUryQnWVztHbhXFCNoEveaGj,kfJqgKmUryQnWVztHbhXFCNoEveaGM)=kfJqgKmUryQnWVztHbhXFCNoEveaGR.Baseapi_Parse(kfJqgKmUryQnWVztHbhXFCNoEveali)
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[],kfJqgKmUryQnWVztHbhXFCNoEveaTc
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['came'] ='BandView'
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['limit']=kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['offset']=kfJqgKmUryQnWVztHbhXFCNoEveaTp((page_int-1)*kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT)
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc))
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   if not('celllist' in kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']):return[],kfJqgKmUryQnWVztHbhXFCNoEveaTc
   kfJqgKmUryQnWVztHbhXFCNoEveald=kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['celllist']
   for kfJqgKmUryQnWVztHbhXFCNoEvealL in kfJqgKmUryQnWVztHbhXFCNoEveald:
    kfJqgKmUryQnWVztHbhXFCNoEveals =kfJqgKmUryQnWVztHbhXFCNoEvealL['event_list'][1]['url']
    kfJqgKmUryQnWVztHbhXFCNoEvealx=urllib.parse.urlsplit(kfJqgKmUryQnWVztHbhXFCNoEveals).query
    kfJqgKmUryQnWVztHbhXFCNoEvealx=kfJqgKmUryQnWVztHbhXFCNoEveaTA(urllib.parse.parse_qsl(kfJqgKmUryQnWVztHbhXFCNoEvealx))
    kfJqgKmUryQnWVztHbhXFCNoEvealO='contentid'
    kfJqgKmUryQnWVztHbhXFCNoEvealI=kfJqgKmUryQnWVztHbhXFCNoEvealx[kfJqgKmUryQnWVztHbhXFCNoEvealO]
    kfJqgKmUryQnWVztHbhXFCNoEvealY={'programtitle':kfJqgKmUryQnWVztHbhXFCNoEvealL['title_list'][0]['text'],'episodetitle':kfJqgKmUryQnWVztHbhXFCNoEveaGR.Get_ChangeText(kfJqgKmUryQnWVztHbhXFCNoEvealL['title_list'][1]['text']),'age':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('age'),'thumbnail':kfJqgKmUryQnWVztHbhXFCNoEveaGR.HTTPTAG+kfJqgKmUryQnWVztHbhXFCNoEvealL.get('thumbnail'),'vidtype':kfJqgKmUryQnWVztHbhXFCNoEvealO,'videoid':kfJqgKmUryQnWVztHbhXFCNoEvealI}
    kfJqgKmUryQnWVztHbhXFCNoEveaRG.append(kfJqgKmUryQnWVztHbhXFCNoEvealY)
   kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['pagecount'])
   if kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['count']:kfJqgKmUryQnWVztHbhXFCNoEvealw =kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['count'])
   else:kfJqgKmUryQnWVztHbhXFCNoEvealw=kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT*page_int
   kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEvealA>kfJqgKmUryQnWVztHbhXFCNoEvealw
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[],kfJqgKmUryQnWVztHbhXFCNoEveaTc
  return kfJqgKmUryQnWVztHbhXFCNoEveaRG,kfJqgKmUryQnWVztHbhXFCNoEvealj
 def Get_Program_List(kfJqgKmUryQnWVztHbhXFCNoEveaGR,kfJqgKmUryQnWVztHbhXFCNoEveali,page_int=1,orderby='-'):
  kfJqgKmUryQnWVztHbhXFCNoEveaRl=[]
  kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEvealw=1
  kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEveaTc
  (kfJqgKmUryQnWVztHbhXFCNoEveaGj,kfJqgKmUryQnWVztHbhXFCNoEveaGM)=kfJqgKmUryQnWVztHbhXFCNoEveaGR.Baseapi_Parse(kfJqgKmUryQnWVztHbhXFCNoEveali)
  if kfJqgKmUryQnWVztHbhXFCNoEveaGj=='':return kfJqgKmUryQnWVztHbhXFCNoEveaRl,kfJqgKmUryQnWVztHbhXFCNoEvealj
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['limit'] =kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['offset']=kfJqgKmUryQnWVztHbhXFCNoEveaTp((page_int-1)*kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT)
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['page'] =kfJqgKmUryQnWVztHbhXFCNoEveaTp(page_int)
   if kfJqgKmUryQnWVztHbhXFCNoEveaGM.get('orderby')!='' and kfJqgKmUryQnWVztHbhXFCNoEveaGM.get('orderby')!='regdatefirst' and orderby!='-':
    kfJqgKmUryQnWVztHbhXFCNoEveaGM['orderby']=orderby 
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc))
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   if kfJqgKmUryQnWVztHbhXFCNoEveali.find('instantplay')>=0:
    if not('celllist' in kfJqgKmUryQnWVztHbhXFCNoEveaGO['band']):return kfJqgKmUryQnWVztHbhXFCNoEveaRl,kfJqgKmUryQnWVztHbhXFCNoEvealj
    kfJqgKmUryQnWVztHbhXFCNoEveald=kfJqgKmUryQnWVztHbhXFCNoEveaGO['band']['celllist']
   else:
    if not('celllist' in kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']):return kfJqgKmUryQnWVztHbhXFCNoEveaRl,kfJqgKmUryQnWVztHbhXFCNoEvealj
    kfJqgKmUryQnWVztHbhXFCNoEveald=kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['celllist']
   for kfJqgKmUryQnWVztHbhXFCNoEvealL in kfJqgKmUryQnWVztHbhXFCNoEveald:
    for kfJqgKmUryQnWVztHbhXFCNoEveaRT in kfJqgKmUryQnWVztHbhXFCNoEvealL['event_list']:
     if kfJqgKmUryQnWVztHbhXFCNoEveaRT.get('type')=='on-navigation':
      kfJqgKmUryQnWVztHbhXFCNoEveals =kfJqgKmUryQnWVztHbhXFCNoEveaRT['url']
    kfJqgKmUryQnWVztHbhXFCNoEvealx=urllib.parse.urlsplit(kfJqgKmUryQnWVztHbhXFCNoEveals).query
    kfJqgKmUryQnWVztHbhXFCNoEvealO=kfJqgKmUryQnWVztHbhXFCNoEvealx[0:kfJqgKmUryQnWVztHbhXFCNoEvealx.find('=')]
    kfJqgKmUryQnWVztHbhXFCNoEvealI=kfJqgKmUryQnWVztHbhXFCNoEvealx[kfJqgKmUryQnWVztHbhXFCNoEvealx.find('=')+1:]
    kfJqgKmUryQnWVztHbhXFCNoEvealY={'title':kfJqgKmUryQnWVztHbhXFCNoEvealL['title_list'][0]['text'],'age':kfJqgKmUryQnWVztHbhXFCNoEvealL['age'],'thumbnail':'https://%s'%kfJqgKmUryQnWVztHbhXFCNoEvealL.get('thumbnail'),'videoid':kfJqgKmUryQnWVztHbhXFCNoEvealI,'vidtype':kfJqgKmUryQnWVztHbhXFCNoEvealO}
    kfJqgKmUryQnWVztHbhXFCNoEveaRl.append(kfJqgKmUryQnWVztHbhXFCNoEvealY)
   if kfJqgKmUryQnWVztHbhXFCNoEveali.find('instantplay')<0:
    kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['pagecount'])
    if kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['count']:kfJqgKmUryQnWVztHbhXFCNoEvealw =kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['count'])
    else:kfJqgKmUryQnWVztHbhXFCNoEvealw=kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT*page_int
    kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEvealA>kfJqgKmUryQnWVztHbhXFCNoEvealw
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[],kfJqgKmUryQnWVztHbhXFCNoEveaTc
  return kfJqgKmUryQnWVztHbhXFCNoEveaRl,kfJqgKmUryQnWVztHbhXFCNoEvealj
 def Get_Movie_List(kfJqgKmUryQnWVztHbhXFCNoEveaGR,kfJqgKmUryQnWVztHbhXFCNoEveali,page_int=1):
  kfJqgKmUryQnWVztHbhXFCNoEveaRP=[]
  kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEvealw=1
  kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEveaTc
  (kfJqgKmUryQnWVztHbhXFCNoEveaGj,kfJqgKmUryQnWVztHbhXFCNoEveaGM)=kfJqgKmUryQnWVztHbhXFCNoEveaGR.Baseapi_Parse(kfJqgKmUryQnWVztHbhXFCNoEveali)
  if kfJqgKmUryQnWVztHbhXFCNoEveaGj=='':return kfJqgKmUryQnWVztHbhXFCNoEveaRP,kfJqgKmUryQnWVztHbhXFCNoEvealj
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['limit']=kfJqgKmUryQnWVztHbhXFCNoEveaGR.MV_LIMIT
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['offset']=kfJqgKmUryQnWVztHbhXFCNoEveaTp((page_int-1)*kfJqgKmUryQnWVztHbhXFCNoEveaGR.MV_LIMIT)
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc))
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   if not('celllist' in kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']):return kfJqgKmUryQnWVztHbhXFCNoEveaRP,kfJqgKmUryQnWVztHbhXFCNoEvealj
   kfJqgKmUryQnWVztHbhXFCNoEveald=kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['celllist']
   for kfJqgKmUryQnWVztHbhXFCNoEvealL in kfJqgKmUryQnWVztHbhXFCNoEveald:
    kfJqgKmUryQnWVztHbhXFCNoEveals =kfJqgKmUryQnWVztHbhXFCNoEvealL['event_list'][1]['url']
    kfJqgKmUryQnWVztHbhXFCNoEvealx=urllib.parse.urlsplit(kfJqgKmUryQnWVztHbhXFCNoEveals).query
    kfJqgKmUryQnWVztHbhXFCNoEvealO=kfJqgKmUryQnWVztHbhXFCNoEvealx[0:kfJqgKmUryQnWVztHbhXFCNoEvealx.find('=')]
    kfJqgKmUryQnWVztHbhXFCNoEvealI=kfJqgKmUryQnWVztHbhXFCNoEvealx[kfJqgKmUryQnWVztHbhXFCNoEvealx.find('=')+1:]
    kfJqgKmUryQnWVztHbhXFCNoEvealY={'title':kfJqgKmUryQnWVztHbhXFCNoEvealL['title_list'][0]['text'],'age':kfJqgKmUryQnWVztHbhXFCNoEvealL['age'],'thumbnail':'https://%s'%kfJqgKmUryQnWVztHbhXFCNoEvealL.get('thumbnail'),'videoid':kfJqgKmUryQnWVztHbhXFCNoEvealI,'vidtype':kfJqgKmUryQnWVztHbhXFCNoEvealO}
    kfJqgKmUryQnWVztHbhXFCNoEveaRP.append(kfJqgKmUryQnWVztHbhXFCNoEvealY)
   kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['pagecount'])
   if kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['count']:kfJqgKmUryQnWVztHbhXFCNoEvealw =kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['count'])
   else:kfJqgKmUryQnWVztHbhXFCNoEvealw=kfJqgKmUryQnWVztHbhXFCNoEveaGR.MV_LIMIT*page_int
   kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEvealA>kfJqgKmUryQnWVztHbhXFCNoEvealw
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[],kfJqgKmUryQnWVztHbhXFCNoEveaTc
  return kfJqgKmUryQnWVztHbhXFCNoEveaRP,kfJqgKmUryQnWVztHbhXFCNoEvealj
 def ChangeToProgramid(kfJqgKmUryQnWVztHbhXFCNoEveaGR,kfJqgKmUryQnWVztHbhXFCNoEveaRj):
  kfJqgKmUryQnWVztHbhXFCNoEveaRi=''
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGj =kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+'/cf/vod/contents/'+kfJqgKmUryQnWVztHbhXFCNoEveaRj
   kfJqgKmUryQnWVztHbhXFCNoEveaGM=kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc)
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaRM=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   if not('programid' in kfJqgKmUryQnWVztHbhXFCNoEveaRM):return kfJqgKmUryQnWVztHbhXFCNoEveaRi 
   kfJqgKmUryQnWVztHbhXFCNoEveaRi=kfJqgKmUryQnWVztHbhXFCNoEveaRM['programid']
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
  return kfJqgKmUryQnWVztHbhXFCNoEveaRi
 def Get_Episode_List(kfJqgKmUryQnWVztHbhXFCNoEveaGR,kfJqgKmUryQnWVztHbhXFCNoEvealI,kfJqgKmUryQnWVztHbhXFCNoEvealO,page_int=1,orderby='desc'):
  kfJqgKmUryQnWVztHbhXFCNoEveaRd=[]
  kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEvealw=1
  kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEveaTc
  if kfJqgKmUryQnWVztHbhXFCNoEvealO=='contentid':
   kfJqgKmUryQnWVztHbhXFCNoEveaRi=kfJqgKmUryQnWVztHbhXFCNoEveaGR.ChangeToProgramid(kfJqgKmUryQnWVztHbhXFCNoEvealI)
  else:
   kfJqgKmUryQnWVztHbhXFCNoEveaRi=kfJqgKmUryQnWVztHbhXFCNoEvealI
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+'/vod/programs-contents/'+kfJqgKmUryQnWVztHbhXFCNoEveaRi
   kfJqgKmUryQnWVztHbhXFCNoEveaGM={}
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['limit'] =kfJqgKmUryQnWVztHbhXFCNoEveaGR.EP_LIMIT
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['offset']=kfJqgKmUryQnWVztHbhXFCNoEveaTp((page_int-1)*kfJqgKmUryQnWVztHbhXFCNoEveaGR.EP_LIMIT)
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['orderby']=orderby 
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc))
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   kfJqgKmUryQnWVztHbhXFCNoEveald=kfJqgKmUryQnWVztHbhXFCNoEveaGO['list']
   for kfJqgKmUryQnWVztHbhXFCNoEvealL in kfJqgKmUryQnWVztHbhXFCNoEveald:
    kfJqgKmUryQnWVztHbhXFCNoEveaRY=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',kfJqgKmUryQnWVztHbhXFCNoEvealL.get('synopsis'))
    kfJqgKmUryQnWVztHbhXFCNoEvealY={'programtitle':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('programtitle'),'episodetitle':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('episodetitle'),'episodenumber':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('episodenumber'),'releasedate':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('releasedate'),'releaseweekday':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('releaseweekday'),'programid':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('programid'),'contentid':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('contentid'),'age':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('targetage'),'playtime':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('playtime'),'synopsis':kfJqgKmUryQnWVztHbhXFCNoEveaRY,'episodeactors':kfJqgKmUryQnWVztHbhXFCNoEvealL.get('episodeactors').split(','),'thumbnail':kfJqgKmUryQnWVztHbhXFCNoEveaGR.HTTPTAG+kfJqgKmUryQnWVztHbhXFCNoEvealL.get('image')}
    kfJqgKmUryQnWVztHbhXFCNoEveaRd.append(kfJqgKmUryQnWVztHbhXFCNoEvealY)
   kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaGO['pagecount'])
   if kfJqgKmUryQnWVztHbhXFCNoEveaGO['count']:kfJqgKmUryQnWVztHbhXFCNoEvealw =kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaGO['count'])
   else:kfJqgKmUryQnWVztHbhXFCNoEvealw=kfJqgKmUryQnWVztHbhXFCNoEveaGR.EP_LIMIT*page_int
   kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEvealA>kfJqgKmUryQnWVztHbhXFCNoEvealw
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[],kfJqgKmUryQnWVztHbhXFCNoEveaTc
  return kfJqgKmUryQnWVztHbhXFCNoEveaRd,kfJqgKmUryQnWVztHbhXFCNoEvealj
 def GetEPGList(kfJqgKmUryQnWVztHbhXFCNoEveaGR,genre):
  kfJqgKmUryQnWVztHbhXFCNoEveaRc={}
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaRB=kfJqgKmUryQnWVztHbhXFCNoEveaGR.Get_Now_Datetime()
   if genre=='all':
    kfJqgKmUryQnWVztHbhXFCNoEveaRu =kfJqgKmUryQnWVztHbhXFCNoEveaRB+datetime.timedelta(hours=3)
   else:
    kfJqgKmUryQnWVztHbhXFCNoEveaRu =kfJqgKmUryQnWVztHbhXFCNoEveaRB+datetime.timedelta(hours=3)
   kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+'/live/epgs'
   kfJqgKmUryQnWVztHbhXFCNoEveaGM={'limit':'100','offset':'0','genre':genre,'startdatetime':kfJqgKmUryQnWVztHbhXFCNoEveaRB.strftime('%Y-%m-%d %H:00'),'enddatetime':kfJqgKmUryQnWVztHbhXFCNoEveaRu.strftime('%Y-%m-%d %H:00')}
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc))
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   kfJqgKmUryQnWVztHbhXFCNoEveaRp=kfJqgKmUryQnWVztHbhXFCNoEveaGO['list']
   for kfJqgKmUryQnWVztHbhXFCNoEvealL in kfJqgKmUryQnWVztHbhXFCNoEveaRp:
    kfJqgKmUryQnWVztHbhXFCNoEveaRS=''
    for kfJqgKmUryQnWVztHbhXFCNoEveaRD in kfJqgKmUryQnWVztHbhXFCNoEvealL['list']:
     if kfJqgKmUryQnWVztHbhXFCNoEveaRS:kfJqgKmUryQnWVztHbhXFCNoEveaRS+='\n'
     kfJqgKmUryQnWVztHbhXFCNoEveaRS+=kfJqgKmUryQnWVztHbhXFCNoEveaGR.Get_ChangeText(kfJqgKmUryQnWVztHbhXFCNoEveaRD['title'])+'\n'
     kfJqgKmUryQnWVztHbhXFCNoEveaRS+=' [%s ~ %s]'%(kfJqgKmUryQnWVztHbhXFCNoEveaRD['starttime'][-5:],kfJqgKmUryQnWVztHbhXFCNoEveaRD['endtime'][-5:])+'\n'
    kfJqgKmUryQnWVztHbhXFCNoEveaRc[kfJqgKmUryQnWVztHbhXFCNoEvealL['channelid']]=kfJqgKmUryQnWVztHbhXFCNoEveaRS
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
  return kfJqgKmUryQnWVztHbhXFCNoEveaRc
 def Get_LiveChannel_List(kfJqgKmUryQnWVztHbhXFCNoEveaGR,genre,kfJqgKmUryQnWVztHbhXFCNoEveali):
  kfJqgKmUryQnWVztHbhXFCNoEvealD=[]
  (kfJqgKmUryQnWVztHbhXFCNoEveaGj,kfJqgKmUryQnWVztHbhXFCNoEveaGM)=kfJqgKmUryQnWVztHbhXFCNoEveaGR.Baseapi_Parse(kfJqgKmUryQnWVztHbhXFCNoEveali)
  if kfJqgKmUryQnWVztHbhXFCNoEveaGj=='':return kfJqgKmUryQnWVztHbhXFCNoEvealD
  kfJqgKmUryQnWVztHbhXFCNoEveaRA=kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetEPGList(genre)
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc))
   kfJqgKmUryQnWVztHbhXFCNoEveaGM['genre']=genre
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   if not('celllist' in kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']):return[]
   kfJqgKmUryQnWVztHbhXFCNoEveald=kfJqgKmUryQnWVztHbhXFCNoEveaGO['cell_toplist']['celllist']
   for kfJqgKmUryQnWVztHbhXFCNoEvealL in kfJqgKmUryQnWVztHbhXFCNoEveald:
    kfJqgKmUryQnWVztHbhXFCNoEveaRj=kfJqgKmUryQnWVztHbhXFCNoEvealL['contentid']
    if kfJqgKmUryQnWVztHbhXFCNoEveaRj in kfJqgKmUryQnWVztHbhXFCNoEveaRA:
     kfJqgKmUryQnWVztHbhXFCNoEveaRs=kfJqgKmUryQnWVztHbhXFCNoEveaRA[kfJqgKmUryQnWVztHbhXFCNoEveaRj]
    else:
     kfJqgKmUryQnWVztHbhXFCNoEveaRs=''
    kfJqgKmUryQnWVztHbhXFCNoEvealY={'studio':kfJqgKmUryQnWVztHbhXFCNoEvealL['title_list'][0]['text'],'tvshowtitle':kfJqgKmUryQnWVztHbhXFCNoEveaGR.Get_ChangeText(kfJqgKmUryQnWVztHbhXFCNoEvealL['title_list'][1]['text']),'channelid':kfJqgKmUryQnWVztHbhXFCNoEveaRj,'age':kfJqgKmUryQnWVztHbhXFCNoEvealL['age'],'thumbnail':'https://%s'%kfJqgKmUryQnWVztHbhXFCNoEvealL.get('thumbnail'),'epg':kfJqgKmUryQnWVztHbhXFCNoEveaRs}
    kfJqgKmUryQnWVztHbhXFCNoEvealD.append(kfJqgKmUryQnWVztHbhXFCNoEvealY)
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return[]
  return kfJqgKmUryQnWVztHbhXFCNoEvealD
 def Get_Search_List(kfJqgKmUryQnWVztHbhXFCNoEveaGR,search_key,sType,page_int,exclusion21=kfJqgKmUryQnWVztHbhXFCNoEveaTc):
  kfJqgKmUryQnWVztHbhXFCNoEveaRx=[]
  kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEvealw=1
  kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEveaTc
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+'/cf/search/list.js'
   kfJqgKmUryQnWVztHbhXFCNoEveaGM={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':kfJqgKmUryQnWVztHbhXFCNoEveaTp((page_int-1)*kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT),'limit':kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT,'orderby':'score'}
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc))
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaRM=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   if not('celllist' in kfJqgKmUryQnWVztHbhXFCNoEveaRM['cell_toplist']):return kfJqgKmUryQnWVztHbhXFCNoEveaRx,kfJqgKmUryQnWVztHbhXFCNoEvealj
   kfJqgKmUryQnWVztHbhXFCNoEveald=kfJqgKmUryQnWVztHbhXFCNoEveaRM['cell_toplist']['celllist']
   for kfJqgKmUryQnWVztHbhXFCNoEvealL in kfJqgKmUryQnWVztHbhXFCNoEveald:
    kfJqgKmUryQnWVztHbhXFCNoEveals =kfJqgKmUryQnWVztHbhXFCNoEvealL['event_list'][1]['url']
    kfJqgKmUryQnWVztHbhXFCNoEvealx=urllib.parse.urlsplit(kfJqgKmUryQnWVztHbhXFCNoEveals).query
    kfJqgKmUryQnWVztHbhXFCNoEvealO=kfJqgKmUryQnWVztHbhXFCNoEvealx[0:kfJqgKmUryQnWVztHbhXFCNoEvealx.find('=')]
    kfJqgKmUryQnWVztHbhXFCNoEvealI=kfJqgKmUryQnWVztHbhXFCNoEvealx[kfJqgKmUryQnWVztHbhXFCNoEvealx.find('=')+1:]
    kfJqgKmUryQnWVztHbhXFCNoEvealY={'title':kfJqgKmUryQnWVztHbhXFCNoEvealL['title_list'][0]['text'],'age':kfJqgKmUryQnWVztHbhXFCNoEvealL['age'],'thumbnail':'https://%s'%kfJqgKmUryQnWVztHbhXFCNoEvealL.get('thumbnail'),'videoid':kfJqgKmUryQnWVztHbhXFCNoEvealI,'vidtype':kfJqgKmUryQnWVztHbhXFCNoEvealO}
    if exclusion21==kfJqgKmUryQnWVztHbhXFCNoEveaTc or kfJqgKmUryQnWVztHbhXFCNoEvealL.get('age')!='21':
     kfJqgKmUryQnWVztHbhXFCNoEveaRx.append(kfJqgKmUryQnWVztHbhXFCNoEvealY)
   kfJqgKmUryQnWVztHbhXFCNoEvealA=kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaRM['cell_toplist']['pagecount'])
   if kfJqgKmUryQnWVztHbhXFCNoEveaRM['cell_toplist']['count']:kfJqgKmUryQnWVztHbhXFCNoEvealw =kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaRM['cell_toplist']['count'])
   else:kfJqgKmUryQnWVztHbhXFCNoEvealw=kfJqgKmUryQnWVztHbhXFCNoEveaGR.LIST_LIMIT
   kfJqgKmUryQnWVztHbhXFCNoEvealj=kfJqgKmUryQnWVztHbhXFCNoEvealA>kfJqgKmUryQnWVztHbhXFCNoEvealw
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
  return kfJqgKmUryQnWVztHbhXFCNoEveaRx,kfJqgKmUryQnWVztHbhXFCNoEvealj 
 def GetStreamingURL(kfJqgKmUryQnWVztHbhXFCNoEveaGR,mode,kfJqgKmUryQnWVztHbhXFCNoEveaRj,quality_int,pvrmode='-'):
  kfJqgKmUryQnWVztHbhXFCNoEveaRO=kfJqgKmUryQnWVztHbhXFCNoEveaTM=kfJqgKmUryQnWVztHbhXFCNoEveaTd=streaming_preview=''
  kfJqgKmUryQnWVztHbhXFCNoEveaRI=[]
  kfJqgKmUryQnWVztHbhXFCNoEveaRw='hls'
  if mode=='LIVE':
   kfJqgKmUryQnWVztHbhXFCNoEveaGj =kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+'/live/channels/'+kfJqgKmUryQnWVztHbhXFCNoEveaRj
   kfJqgKmUryQnWVztHbhXFCNoEveaTG='live'
  elif mode=='VOD':
   kfJqgKmUryQnWVztHbhXFCNoEveaGj =kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+'/cf/vod/contents/'+kfJqgKmUryQnWVztHbhXFCNoEveaRj
   kfJqgKmUryQnWVztHbhXFCNoEveaTG='vod'
  elif mode=='MOVIE':
   kfJqgKmUryQnWVztHbhXFCNoEveaGj =kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+'/cf/movie/contents/'+kfJqgKmUryQnWVztHbhXFCNoEveaRj
   kfJqgKmUryQnWVztHbhXFCNoEveaTG='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    kfJqgKmUryQnWVztHbhXFCNoEveaGM=kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTc)
    kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
    kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
    kfJqgKmUryQnWVztHbhXFCNoEveaTl=kfJqgKmUryQnWVztHbhXFCNoEveaGO['qualities']['list']
    if kfJqgKmUryQnWVztHbhXFCNoEveaTl==kfJqgKmUryQnWVztHbhXFCNoEveaTY:return(kfJqgKmUryQnWVztHbhXFCNoEveaRO,kfJqgKmUryQnWVztHbhXFCNoEveaTM,kfJqgKmUryQnWVztHbhXFCNoEveaTd,streaming_preview)
    for kfJqgKmUryQnWVztHbhXFCNoEveaTR in kfJqgKmUryQnWVztHbhXFCNoEveaTl:
     kfJqgKmUryQnWVztHbhXFCNoEveaRI.append(kfJqgKmUryQnWVztHbhXFCNoEveaTj(kfJqgKmUryQnWVztHbhXFCNoEveaTR.get('id').rstrip('p')))
    if 'type' in kfJqgKmUryQnWVztHbhXFCNoEveaGO:
     if kfJqgKmUryQnWVztHbhXFCNoEveaGO['type']=='onair':
      kfJqgKmUryQnWVztHbhXFCNoEveaTG='onairvod'
    if 'drms' in kfJqgKmUryQnWVztHbhXFCNoEveaGO:
     if kfJqgKmUryQnWVztHbhXFCNoEveaGO['drms']:
      kfJqgKmUryQnWVztHbhXFCNoEveaRw='dash'
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
   return(kfJqgKmUryQnWVztHbhXFCNoEveaRO,kfJqgKmUryQnWVztHbhXFCNoEveaTM,kfJqgKmUryQnWVztHbhXFCNoEveaTd,streaming_preview)
  try:
   kfJqgKmUryQnWVztHbhXFCNoEveaTP=kfJqgKmUryQnWVztHbhXFCNoEveaGR.CheckQuality(quality_int,kfJqgKmUryQnWVztHbhXFCNoEveaRI)
   if mode=='LIVE' and pvrmode!='-':
    kfJqgKmUryQnWVztHbhXFCNoEveaTi='auto'
   else:
    kfJqgKmUryQnWVztHbhXFCNoEveaTi=kfJqgKmUryQnWVztHbhXFCNoEveaTp(kfJqgKmUryQnWVztHbhXFCNoEveaTP)+'p'
   kfJqgKmUryQnWVztHbhXFCNoEveaGj=kfJqgKmUryQnWVztHbhXFCNoEveaGR.API_DOMAIN+'/streaming'
   kfJqgKmUryQnWVztHbhXFCNoEveaGM={'contentid':kfJqgKmUryQnWVztHbhXFCNoEveaRj,'contenttype':kfJqgKmUryQnWVztHbhXFCNoEveaTG,'action':kfJqgKmUryQnWVztHbhXFCNoEveaRw,'quality':kfJqgKmUryQnWVztHbhXFCNoEveaTi,'deviceModelId':'Windows 10','guid':kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   kfJqgKmUryQnWVztHbhXFCNoEveaGM.update(kfJqgKmUryQnWVztHbhXFCNoEveaGR.GetDefaultParams(login=kfJqgKmUryQnWVztHbhXFCNoEveaTB))
   kfJqgKmUryQnWVztHbhXFCNoEveaGx=kfJqgKmUryQnWVztHbhXFCNoEveaGR.callRequestCookies('Get',kfJqgKmUryQnWVztHbhXFCNoEveaGj,payload=kfJqgKmUryQnWVztHbhXFCNoEveaTY,params=kfJqgKmUryQnWVztHbhXFCNoEveaGM,headers=kfJqgKmUryQnWVztHbhXFCNoEveaTY,cookies=kfJqgKmUryQnWVztHbhXFCNoEveaTY)
   kfJqgKmUryQnWVztHbhXFCNoEveaGO=json.loads(kfJqgKmUryQnWVztHbhXFCNoEveaGx.text)
   kfJqgKmUryQnWVztHbhXFCNoEveaRO=kfJqgKmUryQnWVztHbhXFCNoEveaGO['playurl']
   if kfJqgKmUryQnWVztHbhXFCNoEveaRO==kfJqgKmUryQnWVztHbhXFCNoEveaTY:return(kfJqgKmUryQnWVztHbhXFCNoEveaRO,kfJqgKmUryQnWVztHbhXFCNoEveaTM,kfJqgKmUryQnWVztHbhXFCNoEveaTd,streaming_preview)
   kfJqgKmUryQnWVztHbhXFCNoEveaTM=kfJqgKmUryQnWVztHbhXFCNoEveaGO['awscookie']
   kfJqgKmUryQnWVztHbhXFCNoEveaTd =kfJqgKmUryQnWVztHbhXFCNoEveaGO['drm']
   if 'previewmsg' in kfJqgKmUryQnWVztHbhXFCNoEveaGO['preview']:streaming_preview=kfJqgKmUryQnWVztHbhXFCNoEveaGO['preview']['previewmsg']
  except kfJqgKmUryQnWVztHbhXFCNoEveaTS as exception:
   kfJqgKmUryQnWVztHbhXFCNoEveaTD(exception)
  return(kfJqgKmUryQnWVztHbhXFCNoEveaRO,kfJqgKmUryQnWVztHbhXFCNoEveaTM,kfJqgKmUryQnWVztHbhXFCNoEveaTd,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
