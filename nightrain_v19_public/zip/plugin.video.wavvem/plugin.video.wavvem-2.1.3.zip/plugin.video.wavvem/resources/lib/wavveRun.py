__author__="NightRain"
lsdzjKyCoqFmwhQSvnaWTLiUcJPHDY=object
lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI=None
lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV=int
lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX=False
lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR=True
lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB=len
lsdzjKyCoqFmwhQSvnaWTLiUcJPHDE=open
lsdzjKyCoqFmwhQSvnaWTLiUcJPHDf=dict
lsdzjKyCoqFmwhQSvnaWTLiUcJPHDb=Exception
lsdzjKyCoqFmwhQSvnaWTLiUcJPHrO=print
lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
lsdzjKyCoqFmwhQSvnaWTLiUcJPHOM=[{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51'},{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1'},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1'},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순'},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순'},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순'},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순'},{'title':'검색 (search)','mode':'SEARCH_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP'}]
lsdzjKyCoqFmwhQSvnaWTLiUcJPHOA=[{'title':'VOD 검색','mode':'SEARCH_LIST','sType':'vod'},{'title':'영화 검색','mode':'SEARCH_LIST','sType':'movie'}]
lsdzjKyCoqFmwhQSvnaWTLiUcJPHOD=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
lsdzjKyCoqFmwhQSvnaWTLiUcJPHOr=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
from wavveCore import*
class lsdzjKyCoqFmwhQSvnaWTLiUcJPHOk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHDY):
 def __init__(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,lsdzjKyCoqFmwhQSvnaWTLiUcJPHOe,lsdzjKyCoqFmwhQSvnaWTLiUcJPHOg,lsdzjKyCoqFmwhQSvnaWTLiUcJPHOp):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_url =lsdzjKyCoqFmwhQSvnaWTLiUcJPHOe
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOg
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params =lsdzjKyCoqFmwhQSvnaWTLiUcJPHOp
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj =kfJqgKmUryQnWVztHbhXFCNoEveaGl() 
 def addon_noti(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,sting):
  try:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHON=xbmcgui.Dialog()
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHON.notification(__addonname__,sting)
  except:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI
 def addon_log(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,string):
  try:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOG=string.encode('utf-8','ignore')
  except:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOG='addonException: addon_log'
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOt=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,lsdzjKyCoqFmwhQSvnaWTLiUcJPHOG),level=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOt)
 def get_keyboard_input(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOY=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI
  kb=xbmc.Keyboard()
  kb.setHeading(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOY=kb.getText()
  return lsdzjKyCoqFmwhQSvnaWTLiUcJPHOY
 def get_settings_login_info(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOI =__addon__.getSetting('id')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOV =__addon__.getSetting('pw')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOX=__addon__.getSetting('selected_profile')
  return(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOI,lsdzjKyCoqFmwhQSvnaWTLiUcJPHOV,lsdzjKyCoqFmwhQSvnaWTLiUcJPHOX)
 def get_selQuality(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  try:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOR=[1080,720,480,360]
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOB=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(__addon__.getSetting('selected_quality'))
   return lsdzjKyCoqFmwhQSvnaWTLiUcJPHOR[lsdzjKyCoqFmwhQSvnaWTLiUcJPHOB]
  except:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI
  return 1080 
 def get_settings_exclusion21(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOE =__addon__.getSetting('exclusion21')
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHOE=='false':
   return lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX
  else:
   return lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR
 def get_settings_direct_replay(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOf=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(__addon__.getSetting('direct_replay'))
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHOf==0:
   return lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX
  else:
   return lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR
 def get_settings_addinfo(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOb =__addon__.getSetting('add_infoyn')
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHOb=='false':
   return lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX
  else:
   return lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR
 def set_winCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,credential):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO=xbmcgui.Window(10000)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO.setProperty('WAVVE_M_CREDENTIAL',credential)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO.setProperty('WAVVE_M_LOGINTIME',lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO=xbmcgui.Window(10000)
  return lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkR):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO=xbmcgui.Window(10000)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO.setProperty('WAVVE_M_ORDERBY',lsdzjKyCoqFmwhQSvnaWTLiUcJPHkR)
 def get_winEpisodeOrderby(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO=xbmcgui.Window(10000)
  return lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO.getProperty('WAVVE_M_ORDERBY')
 def add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,label,sublabel='',img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=''):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkM='%s?%s'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_url,urllib.parse.urlencode(params))
  if sublabel:lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA='%s < %s >'%(label,sublabel)
  else: lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA=label
  if not img:img='DefaultFolder.png'
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkD=xbmcgui.ListItem(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkD.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:lsdzjKyCoqFmwhQSvnaWTLiUcJPHkD.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:lsdzjKyCoqFmwhQSvnaWTLiUcJPHkD.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkM,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkD,isFolder)
 def dp_Main_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr in lsdzjKyCoqFmwhQSvnaWTLiUcJPHOM:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr.get('title')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr.get('mode'),'sCode':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr.get('sCode'),'sIndex':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr.get('sIndex'),'sType':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr.get('sType'),'suburl':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr.get('suburl'),'subapi':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr.get('subapi'),'page':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr.get('page'),'orderby':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr.get('orderby'),'ordernm':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr.get('ordernm')}
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkr.get('mode')=='XXX':
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHke=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX
   else:
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHke=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel='',img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHke,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOM)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR)
 def dp_Search_Group(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHkp in lsdzjKyCoqFmwhQSvnaWTLiUcJPHOA:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkp.get('title')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkp.get('mode'),'sType':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkp.get('sType'),'page':'1'}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel='',img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOA)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR)
 def dp_Watch_Group(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHku in lsdzjKyCoqFmwhQSvnaWTLiUcJPHOD:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA=lsdzjKyCoqFmwhQSvnaWTLiUcJPHku.get('title')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':lsdzjKyCoqFmwhQSvnaWTLiUcJPHku.get('mode'),'sType':lsdzjKyCoqFmwhQSvnaWTLiUcJPHku.get('sType')}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel='',img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOD)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR)
 def login_main(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  (lsdzjKyCoqFmwhQSvnaWTLiUcJPHkN,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkG,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkt)=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_settings_login_info()
  if not(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkN and lsdzjKyCoqFmwhQSvnaWTLiUcJPHkG):
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHON=xbmcgui.Dialog()
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkY=lsdzjKyCoqFmwhQSvnaWTLiUcJPHON.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkY==lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winEpisodeOrderby()=='':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.set_winEpisodeOrderby('desc')
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.cookiefile_check():return
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkI =lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkV=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkV==lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI or lsdzjKyCoqFmwhQSvnaWTLiUcJPHkV=='':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkV=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV('19000101')
  else:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkV=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(re.sub('-','',lsdzjKyCoqFmwhQSvnaWTLiUcJPHkV))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkX=0
   while lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR:
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkX+=1
    time.sleep(0.05)
    if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkV>=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkI:return
    if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkX>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkV>=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkI:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.GetCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkN,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkG,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkt):
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.set_winCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.LoadCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkR =args.get('orderby')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.set_winEpisodeOrderby(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkR)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.SaveCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB =args.get('mode')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkE =args.get('contentid')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkf =args.get('pvrmode')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkb=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_selQuality()
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.addon_log(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkE+' - '+lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHMO,lsdzjKyCoqFmwhQSvnaWTLiUcJPHMk,lsdzjKyCoqFmwhQSvnaWTLiUcJPHMA,lsdzjKyCoqFmwhQSvnaWTLiUcJPHMD=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.GetStreamingURL(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkE,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkb,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkf)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHMr='%s|Cookie=%s'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHMO,lsdzjKyCoqFmwhQSvnaWTLiUcJPHMk)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.addon_log(lsdzjKyCoqFmwhQSvnaWTLiUcJPHMr)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHMO=='':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.addon_noti(__language__(30907).encode('utf8'))
   return
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHMx=xbmcgui.ListItem(path=lsdzjKyCoqFmwhQSvnaWTLiUcJPHMr)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHMA:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.addon_log('!!streaming_drm!!')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMe=lsdzjKyCoqFmwhQSvnaWTLiUcJPHMA['customdata']
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMg =lsdzjKyCoqFmwhQSvnaWTLiUcJPHMA['drmhost']
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMp =inputstreamhelper.Helper('mpd',drm='widevine')
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHMp.check_inputstream():
    if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='MOVIE':
     lsdzjKyCoqFmwhQSvnaWTLiUcJPHMu='https://www.wavve.com/player/movie?movieid=%s'%lsdzjKyCoqFmwhQSvnaWTLiUcJPHkE
    else:
     lsdzjKyCoqFmwhQSvnaWTLiUcJPHMu='https://www.wavve.com/player/vod?programid=%s&page=1'%lsdzjKyCoqFmwhQSvnaWTLiUcJPHkE
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHMN={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':lsdzjKyCoqFmwhQSvnaWTLiUcJPHMe,'referer':lsdzjKyCoqFmwhQSvnaWTLiUcJPHMu,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.USER_AGENT}
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHMG=lsdzjKyCoqFmwhQSvnaWTLiUcJPHMg+'|'+urllib.parse.urlencode(lsdzjKyCoqFmwhQSvnaWTLiUcJPHMN)+'|R{SSM}|'
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHMx.setProperty('inputstream',lsdzjKyCoqFmwhQSvnaWTLiUcJPHMp.inputstream_addon)
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHMx.setProperty('inputstream.adaptive.manifest_type','mpd')
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHMx.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHMx.setProperty('inputstream.adaptive.license_key',lsdzjKyCoqFmwhQSvnaWTLiUcJPHMG)
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHMx.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.USER_AGENT,lsdzjKyCoqFmwhQSvnaWTLiUcJPHMk))
  xbmcplugin.setResolvedUrl(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,lsdzjKyCoqFmwhQSvnaWTLiUcJPHMx)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHMt=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHMD:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.addon_noti(lsdzjKyCoqFmwhQSvnaWTLiUcJPHMD.encode('utf-8'))
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMt=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR
  else:
   if '/preview.' in urllib.parse.urlsplit(lsdzjKyCoqFmwhQSvnaWTLiUcJPHMO).path:
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.addon_noti(__language__(30908).encode('utf8'))
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHMt=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR
  try:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMY=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and lsdzjKyCoqFmwhQSvnaWTLiUcJPHMt==lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX and lsdzjKyCoqFmwhQSvnaWTLiUcJPHMY!='-':
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'code':lsdzjKyCoqFmwhQSvnaWTLiUcJPHMY,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.Save_Watched_List(args.get('mode').lower(),lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  except:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI
 def Load_Watched_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,lsdzjKyCoqFmwhQSvnaWTLiUcJPHDg):
  try:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMI=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lsdzjKyCoqFmwhQSvnaWTLiUcJPHDg))
   fp=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDE(lsdzjKyCoqFmwhQSvnaWTLiUcJPHMI,'r',-1,'utf-8')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMV=fp.readlines()
   fp.close()
  except:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMV=[]
  return lsdzjKyCoqFmwhQSvnaWTLiUcJPHMV
 def Save_Watched_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,lsdzjKyCoqFmwhQSvnaWTLiUcJPHDg,lsdzjKyCoqFmwhQSvnaWTLiUcJPHOp):
  try:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMI=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lsdzjKyCoqFmwhQSvnaWTLiUcJPHDg))
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMX=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.Load_Watched_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHDg) 
   fp=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDE(lsdzjKyCoqFmwhQSvnaWTLiUcJPHMI,'w',-1,'utf-8')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMR=urllib.parse.urlencode(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOp)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMR=lsdzjKyCoqFmwhQSvnaWTLiUcJPHMR+'\n'
   fp.write(lsdzjKyCoqFmwhQSvnaWTLiUcJPHMR)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMB=0
   for lsdzjKyCoqFmwhQSvnaWTLiUcJPHME in lsdzjKyCoqFmwhQSvnaWTLiUcJPHMX:
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHMf=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDf(urllib.parse.parse_qsl(lsdzjKyCoqFmwhQSvnaWTLiUcJPHME))
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHMb=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOp.get('code').strip()
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHAO=lsdzjKyCoqFmwhQSvnaWTLiUcJPHMf.get('code').strip()
    if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDg=='vod' and lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_settings_direct_replay()==lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR:
     lsdzjKyCoqFmwhQSvnaWTLiUcJPHMb=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOp.get('videoid').strip()
     lsdzjKyCoqFmwhQSvnaWTLiUcJPHAO=lsdzjKyCoqFmwhQSvnaWTLiUcJPHMf.get('videoid').strip()if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAO!=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI else '-'
    if lsdzjKyCoqFmwhQSvnaWTLiUcJPHMb!=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAO:
     fp.write(lsdzjKyCoqFmwhQSvnaWTLiUcJPHME)
     lsdzjKyCoqFmwhQSvnaWTLiUcJPHMB+=1
     if lsdzjKyCoqFmwhQSvnaWTLiUcJPHMB>=50:break
   fp.close()
  except:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI
 def Delete_Watched_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,lsdzjKyCoqFmwhQSvnaWTLiUcJPHDg):
  try:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHMI=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lsdzjKyCoqFmwhQSvnaWTLiUcJPHDg))
   fp=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDE(lsdzjKyCoqFmwhQSvnaWTLiUcJPHMI,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI
 def dp_WatchList_Delete(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk=args.get('sType')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHON=xbmcgui.Dialog()
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkY=lsdzjKyCoqFmwhQSvnaWTLiUcJPHON.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkY==lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX:sys.exit()
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.Delete_Watched_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk)
  xbmc.executebuiltin("Container.Refresh")
 def logout(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHON=xbmcgui.Dialog()
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkY=lsdzjKyCoqFmwhQSvnaWTLiUcJPHON.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkY==lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX:sys.exit()
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.wininfo_clear()
  if os.path.isfile(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOr):os.remove(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOr)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO=xbmcgui.Window(10000)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO.setProperty('WAVVE_M_CREDENTIAL','')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAM =lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_Now_Datetime()
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAD=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAM+datetime.timedelta(days=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(__addon__.getSetting('cache_ttl')))
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO=xbmcgui.Window(10000)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr={'wavve_token':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAD.strftime('%Y-%m-%d')}
  try: 
   fp=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDE(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOr,'w',-1,'utf-8')
   json.dump(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr,fp)
   fp.close()
  except lsdzjKyCoqFmwhQSvnaWTLiUcJPHDb as exception:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHrO(exception)
 def cookiefile_check(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr={}
  try: 
   fp=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDE(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOr,'r',-1,'utf-8')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr= json.load(fp)
   fp.close()
  except lsdzjKyCoqFmwhQSvnaWTLiUcJPHDb as exception:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.wininfo_clear()
   return lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkN =__addon__.getSetting('id')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkG =__addon__.getSetting('pw')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAx =__addon__.getSetting('selected_profile')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr['wavve_id']=base64.standard_b64decode(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr['wavve_id']).decode('utf-8')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr['wavve_pw']=base64.standard_b64decode(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr['wavve_pw']).decode('utf-8')
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkN!=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr['wavve_id']or lsdzjKyCoqFmwhQSvnaWTLiUcJPHkG!=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr['wavve_pw']or lsdzjKyCoqFmwhQSvnaWTLiUcJPHAx!=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr['wavve_profile']:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.wininfo_clear()
   return lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkI =lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAe=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr['wavve_limitdate']
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkV =lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(re.sub('-','',lsdzjKyCoqFmwhQSvnaWTLiUcJPHAe))
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkV<lsdzjKyCoqFmwhQSvnaWTLiUcJPHkI:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.wininfo_clear()
   return lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO=xbmcgui.Window(10000)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO.setProperty('WAVVE_M_CREDENTIAL',lsdzjKyCoqFmwhQSvnaWTLiUcJPHAr['wavve_token'])
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkO.setProperty('WAVVE_M_LOGINTIME',lsdzjKyCoqFmwhQSvnaWTLiUcJPHAe)
  return lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR
 def dp_LiveCatagory_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.SaveCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAg =args.get('sCode')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAp=args.get('sIndex')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAN=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_LiveCatagory_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAg,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAp)
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG in lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('title')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'LIVE_LIST','genre':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('genre'),'baseapi':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAN}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel='',img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX)
 def dp_MainCatagory_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.SaveCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAg =args.get('sCode')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAp=args.get('sIndex')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk =args.get('sType')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_MainCatagory_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAg,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAp)
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG in lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu:
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk=='vod':
    if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('subtype')=='catagory':
     lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB='PROGRAM_LIST'
    else:
     lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB='SUPERSECTION_LIST'
   elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk=='movie':
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB='MOVIE_LIST'
   else:
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=''
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA='%s (%s)'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('title'),args.get('ordernm'))
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB,'suburl':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('suburl'),'subapi':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_settings_exclusion21():
    if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('title')=='성인' or lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('title')=='성인+':continue
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel='',img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX)
 def dp_Program_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.SaveCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt =args.get('subapi')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(args.get('page'))
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkR =args.get('orderby')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_Program_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY,lsdzjKyCoqFmwhQSvnaWTLiUcJPHkR)
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG in lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('title')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('thumbnail')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('age')
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX=='18' or lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX=='19' or lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX=='21':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA+=' (%s)'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR={'plot':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,'mpaa':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX,'mediatype':'episode'}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'EPISODE_LIST','videoid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('videoid'),'vidtype':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('vidtype'),'page':'1'}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel='',img=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV,infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['mode'] ='PROGRAM_LIST' 
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['subapi']=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt 
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['page'] =lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA='[B]%s >>[/B]'%'다음 페이지'
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB=lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX)
 def dp_SuperSection_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.SaveCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAE =args.get('suburl')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_SuperMultiSection_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAE)
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG in lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('title')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('subapi')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAf=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('cell_type')
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt.find('mtype=svod')>=0 or lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt.find('mtype=ppv')>=0:
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB='MOVIE_LIST'
   elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHAf=='band_71':
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB ='SUPERSECTION_LIST'
    (lsdzjKyCoqFmwhQSvnaWTLiUcJPHAb,lsdzjKyCoqFmwhQSvnaWTLiUcJPHDO)=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Baseapi_Parse(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt)
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHAE=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDO.get('api')
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt=''
   elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHAf=='band_2':
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB='BAND2SECTION_LIST'
   elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHAf=='band_live':
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt):
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB='MOVIE_LIST'
   else:
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB='PROGRAM_LIST'
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR={'plot':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,'mediatype':'episode'}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB,'suburl':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAE,'subapi':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt,'page':'1'}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel='',img=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX)
 def dp_BandLiveSection_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.SaveCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt =args.get('subapi')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(args.get('page'))
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_BandLiveSection_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY)
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG in lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDk =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('channelid')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDM =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('studio')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDA=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('tvshowtitle')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('thumbnail')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('age')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR={'mediatype':'video','mpaa':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX,'title':'%s < %s >'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHDM,lsdzjKyCoqFmwhQSvnaWTLiUcJPHDA),'tvshowtitle':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDA,'studio':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDM,'plot':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDM}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'LIVE','contentid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDk}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHDM,sublabel=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDA,img=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('thumbnail'),infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['mode'] ='BANDLIVESECTION_LIST' 
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['subapi']=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['page'] =lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA='[B]%s >>[/B]'%'다음 페이지'
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB=lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX)
 def dp_Band2Section_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.SaveCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt =args.get('subapi')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(args.get('page'))
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_Band2Section_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY)
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG in lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('programtitle')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('episodetitle')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR={'plot':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA+'\n\n'+lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,'mpaa':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('age'),'mediatype':'episode'}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'VOD','programid':'-','contentid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('videoid'),'thumbnail':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('thumbnail'),'title':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,'subtitle':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,img=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('thumbnail'),infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['mode'] ='BAND2SECTION_LIST' 
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['subapi']=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['page'] =lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA='[B]%s >>[/B]'%'다음 페이지'
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB=lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX)
 def dp_Movie_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.SaveCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt =args.get('subapi')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(args.get('page'))
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_Movie_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY)
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG in lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('title')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('thumbnail')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('age')
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX=='18' or lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX=='19' or lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX=='21':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA+=' (%s)'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR={'plot':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,'mpaa':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX,'mediatype':'movie'}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'MOVIE','contentid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('videoid'),'title':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,'thumbnail':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV,'age':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel='',img=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV,infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['mode'] ='MOVIE_LIST' 
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['subapi']=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAt 
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['page'] =lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA='[B]%s >>[/B]'%'다음 페이지'
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB=lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX)
 def dp_Episode_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.SaveCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHDr =args.get('videoid')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHDx =args.get('vidtype')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(args.get('page'))
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_Episode_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHDr,lsdzjKyCoqFmwhQSvnaWTLiUcJPHDx,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY,orderby=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winEpisodeOrderby())
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG in lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB='%s회, %s(%s)'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('episodenumber'),lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('releasedate'),lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('releaseweekday'))
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDe ='[%s]\n\n%s'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('episodetitle'),lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('synopsis'))
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR={'mediatype':'episode','title':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('programtitle'),'year':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('releasedate')[:4]),'aired':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('releasedate'),'mpaa':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('age'),'episode':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('episodenumber'),'duration':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('playtime'),'plot':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDe,'cast':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('episodeactors')}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'VOD','programid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('programid'),'contentid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('contentid'),'thumbnail':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('thumbnail'),'title':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('programtitle'),'subtitle':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('programtitle'),sublabel=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,img=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('thumbnail'),infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY==1:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR={'plot':'정렬순서를 변경합니다.'}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['mode'] ='ORDER_BY' 
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winEpisodeOrderby()=='desc':
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA='정렬순서변경 : 최신화부터 -> 1회부터'
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['orderby']='asc'
   else:
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA='정렬순서변경 : 1회부터 -> 최신화부터'
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['orderby']='desc'
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel='',img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['mode'] ='EPISODE_LIST' 
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['videoid']=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('programid')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['vidtype']='programid'
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['page'] =lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA='[B]%s >>[/B]'%'다음 페이지'
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB=lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX)
 def dp_LiveChannel_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.SaveCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHDg =args.get('genre')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAN=args.get('baseapi')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_LiveChannel_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHDg,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAN)
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG in lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDk =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('channelid')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDM =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('studio')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDA=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('tvshowtitle')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('thumbnail')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('age')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDp =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('epg')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR={'mediatype':'video','mpaa':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX,'title':'%s < %s >'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHDM,lsdzjKyCoqFmwhQSvnaWTLiUcJPHDA),'tvshowtitle':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDA,'studio':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDM,'plot':'%s\n\n%s'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHDM,lsdzjKyCoqFmwhQSvnaWTLiUcJPHDp)}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'LIVE','contentid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDk}
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHDM,sublabel=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDA,img=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV,infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX)
 def dp_Search_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.SaveCredential(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_winCredential())
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk =args.get('sType')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY =lsdzjKyCoqFmwhQSvnaWTLiUcJPHDV(args.get('page'))
  if 'search_key' in args:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDu=args.get('search_key')
  else:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDu=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not lsdzjKyCoqFmwhQSvnaWTLiUcJPHDu:return
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.WavveObj.Get_Search_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHDu,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY,exclusion21=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_settings_exclusion21())
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG in lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('title')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('thumbnail')
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX =lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('age')
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX=='18' or lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX=='19' or lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX=='21':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA+=' (%s)'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR={'mediatype':'episode' if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk=='vod' else 'movie','mpaa':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX,'title':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,'plot':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA}
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk=='vod':
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'EPISODE_LIST','videoid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('videoid'),'vidtype':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('vidtype'),'page':'1'}
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHke=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR
   else:
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'MOVIE','contentid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG.get('videoid'),'title':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,'thumbnail':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV,'age':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAX}
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHke=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel='',img=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV,infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHke,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAI:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['mode'] ='SEARCH_LIST' 
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['sType']=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk 
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['page'] =lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx['search_key']=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDu
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA='[B]%s >>[/B]'%'다음 페이지'
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB=lsdzjKyCoqFmwhQSvnaWTLiUcJPHrk(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAY+1)
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHDB(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu)>0:xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle)
 def dp_Watch_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx,args):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk =args.get('sType')
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOf=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.get_settings_direct_replay()
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.Load_Watched_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk)
  for lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG in lsdzjKyCoqFmwhQSvnaWTLiUcJPHAu:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDN=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDf(urllib.parse.parse_qsl(lsdzjKyCoqFmwhQSvnaWTLiUcJPHAG))
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDG =lsdzjKyCoqFmwhQSvnaWTLiUcJPHDN.get('code').strip()
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA =lsdzjKyCoqFmwhQSvnaWTLiUcJPHDN.get('title').strip()
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB =lsdzjKyCoqFmwhQSvnaWTLiUcJPHDN.get('subtitle').strip()
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB=='None':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB=''
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDN.get('img').strip()
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDr =lsdzjKyCoqFmwhQSvnaWTLiUcJPHDN.get('videoid').strip()
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR={'plot':'%s\n%s'%(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB)}
   if lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk=='vod':
    if lsdzjKyCoqFmwhQSvnaWTLiUcJPHOf==lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX or lsdzjKyCoqFmwhQSvnaWTLiUcJPHDr==lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI:
     lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'EPISODE_LIST','videoid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDG,'vidtype':'programid','page':'1'}
     lsdzjKyCoqFmwhQSvnaWTLiUcJPHke=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDR
    else:
     lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'VOD','programid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDG,'contentid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDr,'title':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,'subtitle':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,'thumbnail':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV}
     lsdzjKyCoqFmwhQSvnaWTLiUcJPHke=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX
   else:
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'MOVIE','contentid':lsdzjKyCoqFmwhQSvnaWTLiUcJPHDG,'title':lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,'subtitle':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,'thumbnail':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV}
    lsdzjKyCoqFmwhQSvnaWTLiUcJPHke=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAB,img=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAV,infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHke,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR={'plot':'시청목록을 삭제합니다.'}
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA='*** 시청목록 삭제 ***'
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx={'mode':'MYVIEW_REMOVE','sType':lsdzjKyCoqFmwhQSvnaWTLiUcJPHAk}
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.add_dir(lsdzjKyCoqFmwhQSvnaWTLiUcJPHkA,sublabel='',img='',infoLabels=lsdzjKyCoqFmwhQSvnaWTLiUcJPHAR,isFolder=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX,params=lsdzjKyCoqFmwhQSvnaWTLiUcJPHkx)
  xbmcplugin.endOfDirectory(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx._addon_handle,cacheToDisc=lsdzjKyCoqFmwhQSvnaWTLiUcJPHDX)
 def wavve_main(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx):
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params.get('mode',lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI)
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='LOGOUT':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.logout()
   return
  lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.login_main()
  if lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB is lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_Main_List()
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB in['LIVE','VOD','MOVIE']:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.play_VIDEO(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='LIVE_CATAGORY':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_LiveCatagory_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='MAIN_CATAGORY':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_MainCatagory_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='SUPERSECTION_LIST':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_SuperSection_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='BANDLIVESECTION_LIST':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_BandLiveSection_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='BAND2SECTION_LIST':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_Band2Section_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='PROGRAM_LIST':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_Program_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='EPISODE_LIST':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_Episode_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='MOVIE_LIST':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_Movie_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='LIVE_LIST':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_LiveChannel_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='ORDER_BY':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_setEpOrderby(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='SEARCH_GROUP':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_Search_Group(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='SEARCH_LIST':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_Search_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='WATCH_GROUP':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_Watch_Group(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='WATCH_LIST':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_Watch_List(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  elif lsdzjKyCoqFmwhQSvnaWTLiUcJPHkB=='MYVIEW_REMOVE':
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.dp_WatchList_Delete(lsdzjKyCoqFmwhQSvnaWTLiUcJPHOx.main_params)
  else:
   lsdzjKyCoqFmwhQSvnaWTLiUcJPHDI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
