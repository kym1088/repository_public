__author__="NightRain"
AwERGhgecFkLrxHNTulqCdtPvaypOi=object
AwERGhgecFkLrxHNTulqCdtPvaypOz=None
AwERGhgecFkLrxHNTulqCdtPvaypOb=False
AwERGhgecFkLrxHNTulqCdtPvaypOn=True
AwERGhgecFkLrxHNTulqCdtPvaypOI=range
AwERGhgecFkLrxHNTulqCdtPvaypOJ=str
AwERGhgecFkLrxHNTulqCdtPvaypMU=Exception
AwERGhgecFkLrxHNTulqCdtPvaypMW=print
AwERGhgecFkLrxHNTulqCdtPvaypMK=dict
AwERGhgecFkLrxHNTulqCdtPvaypMO=int
AwERGhgecFkLrxHNTulqCdtPvaypMm=len
import urllib
import re
import json
import sys
import requests
import datetime
class AwERGhgecFkLrxHNTulqCdtPvaypUW(AwERGhgecFkLrxHNTulqCdtPvaypOi):
 def __init__(AwERGhgecFkLrxHNTulqCdtPvaypUK):
  AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN='https://apis.wavve.com'
  AwERGhgecFkLrxHNTulqCdtPvaypUK.APIKEY ='E5F3E0D30947AA5440556471321BB6D9'
  AwERGhgecFkLrxHNTulqCdtPvaypUK.CREDENTIAL='none'
  AwERGhgecFkLrxHNTulqCdtPvaypUK.DEVICE ='pc'
  AwERGhgecFkLrxHNTulqCdtPvaypUK.DRM ='wm'
  AwERGhgecFkLrxHNTulqCdtPvaypUK.PARTNER ='pooq'
  AwERGhgecFkLrxHNTulqCdtPvaypUK.POOQZONE ='none'
  AwERGhgecFkLrxHNTulqCdtPvaypUK.REGION ='kor'
  AwERGhgecFkLrxHNTulqCdtPvaypUK.TARGETAGE ='all'
  AwERGhgecFkLrxHNTulqCdtPvaypUK.HTTPTAG ='https://'
  AwERGhgecFkLrxHNTulqCdtPvaypUK.LIST_LIMIT=30 
  AwERGhgecFkLrxHNTulqCdtPvaypUK.EP_LIMIT =30 
  AwERGhgecFkLrxHNTulqCdtPvaypUK.MV_LIMIT =24 
  AwERGhgecFkLrxHNTulqCdtPvaypUK.SEARCH_LIMIT=20 
  AwERGhgecFkLrxHNTulqCdtPvaypUK.guid ='none' 
  AwERGhgecFkLrxHNTulqCdtPvaypUK.guidtimestamp='none' 
  AwERGhgecFkLrxHNTulqCdtPvaypUK.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  AwERGhgecFkLrxHNTulqCdtPvaypUK.DEFAULT_HEADER={'user-agent':AwERGhgecFkLrxHNTulqCdtPvaypUK.USER_AGENT}
 def callRequestCookies(AwERGhgecFkLrxHNTulqCdtPvaypUK,jobtype,AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypOz,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz,redirects=AwERGhgecFkLrxHNTulqCdtPvaypOb):
  AwERGhgecFkLrxHNTulqCdtPvaypUO=AwERGhgecFkLrxHNTulqCdtPvaypUK.DEFAULT_HEADER
  if headers:AwERGhgecFkLrxHNTulqCdtPvaypUO.update(headers)
  if jobtype=='Get':
   AwERGhgecFkLrxHNTulqCdtPvaypUM=requests.get(AwERGhgecFkLrxHNTulqCdtPvaypUi,params=params,headers=AwERGhgecFkLrxHNTulqCdtPvaypUO,cookies=cookies,allow_redirects=redirects)
  else:
   AwERGhgecFkLrxHNTulqCdtPvaypUM=requests.post(AwERGhgecFkLrxHNTulqCdtPvaypUi,data=payload,params=params,headers=AwERGhgecFkLrxHNTulqCdtPvaypUO,cookies=cookies,allow_redirects=redirects)
  return AwERGhgecFkLrxHNTulqCdtPvaypUM
 def SaveCredential(AwERGhgecFkLrxHNTulqCdtPvaypUK,AwERGhgecFkLrxHNTulqCdtPvaypUm):
  AwERGhgecFkLrxHNTulqCdtPvaypUK.CREDENTIAL=AwERGhgecFkLrxHNTulqCdtPvaypUm
 def LoadCredential(AwERGhgecFkLrxHNTulqCdtPvaypUK):
  return AwERGhgecFkLrxHNTulqCdtPvaypUK.CREDENTIAL
 def GetDefaultParams(AwERGhgecFkLrxHNTulqCdtPvaypUK,login=AwERGhgecFkLrxHNTulqCdtPvaypOn):
  AwERGhgecFkLrxHNTulqCdtPvaypUS={'apikey':AwERGhgecFkLrxHNTulqCdtPvaypUK.APIKEY,'credential':AwERGhgecFkLrxHNTulqCdtPvaypUK.CREDENTIAL if login else 'none','device':AwERGhgecFkLrxHNTulqCdtPvaypUK.DEVICE,'drm':AwERGhgecFkLrxHNTulqCdtPvaypUK.DRM,'partner':AwERGhgecFkLrxHNTulqCdtPvaypUK.PARTNER,'pooqzone':AwERGhgecFkLrxHNTulqCdtPvaypUK.POOQZONE,'region':AwERGhgecFkLrxHNTulqCdtPvaypUK.REGION,'targetage':AwERGhgecFkLrxHNTulqCdtPvaypUK.TARGETAGE}
  return AwERGhgecFkLrxHNTulqCdtPvaypUS
 def GetGUID(AwERGhgecFkLrxHNTulqCdtPvaypUK,guid_str='POOQ',guidType=1):
  def GenerateID(media):
   AwERGhgecFkLrxHNTulqCdtPvaypUB=AwERGhgecFkLrxHNTulqCdtPvaypUK.Get_Now_Datetime().strftime('%Y%m%d%H%M%S')
   AwERGhgecFkLrxHNTulqCdtPvaypUs=GenerateRandomString(5)
   AwERGhgecFkLrxHNTulqCdtPvaypUo=AwERGhgecFkLrxHNTulqCdtPvaypUs+media+AwERGhgecFkLrxHNTulqCdtPvaypUB
   return AwERGhgecFkLrxHNTulqCdtPvaypUo
  def GenerateRandomString(num):
   from random import randint
   AwERGhgecFkLrxHNTulqCdtPvaypUj=""
   for i in AwERGhgecFkLrxHNTulqCdtPvaypOI(0,num):
    s=AwERGhgecFkLrxHNTulqCdtPvaypOJ(randint(1,5))
    AwERGhgecFkLrxHNTulqCdtPvaypUj+=s
   return AwERGhgecFkLrxHNTulqCdtPvaypUj
  AwERGhgecFkLrxHNTulqCdtPvaypUo=GenerateID(guid_str)
  AwERGhgecFkLrxHNTulqCdtPvaypUV=AwERGhgecFkLrxHNTulqCdtPvaypUK.GetHash(AwERGhgecFkLrxHNTulqCdtPvaypUo)
  if guidType==2:
   AwERGhgecFkLrxHNTulqCdtPvaypUV='%s-%s-%s-%s-%s'%(AwERGhgecFkLrxHNTulqCdtPvaypUV[:8],AwERGhgecFkLrxHNTulqCdtPvaypUV[8:12],AwERGhgecFkLrxHNTulqCdtPvaypUV[12:16],AwERGhgecFkLrxHNTulqCdtPvaypUV[16:20],AwERGhgecFkLrxHNTulqCdtPvaypUV[20:])
  return AwERGhgecFkLrxHNTulqCdtPvaypUV
 def GetHash(AwERGhgecFkLrxHNTulqCdtPvaypUK,hash_str):
  import hashlib
  m=hashlib.md5()
  m.update(hash_str.encode('utf-8'))
  return AwERGhgecFkLrxHNTulqCdtPvaypOJ(m.hexdigest())
 def CheckQuality(AwERGhgecFkLrxHNTulqCdtPvaypUK,sel_qt,qt_list):
  AwERGhgecFkLrxHNTulqCdtPvaypUD=0
  for AwERGhgecFkLrxHNTulqCdtPvaypUX in qt_list:
   if sel_qt>=AwERGhgecFkLrxHNTulqCdtPvaypUX:return AwERGhgecFkLrxHNTulqCdtPvaypUX
   AwERGhgecFkLrxHNTulqCdtPvaypUD=AwERGhgecFkLrxHNTulqCdtPvaypUX
  return AwERGhgecFkLrxHNTulqCdtPvaypUD
 def Get_Now_Datetime(AwERGhgecFkLrxHNTulqCdtPvaypUK):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_ChangeText(AwERGhgecFkLrxHNTulqCdtPvaypUK,in_text):
  AwERGhgecFkLrxHNTulqCdtPvaypUf=in_text.replace('&lt;','<').replace('&gt;','>')
  AwERGhgecFkLrxHNTulqCdtPvaypUf=AwERGhgecFkLrxHNTulqCdtPvaypUf.replace('$O$','')
  AwERGhgecFkLrxHNTulqCdtPvaypUf=re.sub('\n|\!|\~|(@0@)|(@\^0@)','',AwERGhgecFkLrxHNTulqCdtPvaypUf)
  AwERGhgecFkLrxHNTulqCdtPvaypUf=AwERGhgecFkLrxHNTulqCdtPvaypUf.lstrip('#')
  return AwERGhgecFkLrxHNTulqCdtPvaypUf
 def GetCredential(AwERGhgecFkLrxHNTulqCdtPvaypUK,user_id,user_pw,user_pf):
  AwERGhgecFkLrxHNTulqCdtPvaypUQ=AwERGhgecFkLrxHNTulqCdtPvaypOb
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+ '/login'
   AwERGhgecFkLrxHNTulqCdtPvaypUS=AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams()
   AwERGhgecFkLrxHNTulqCdtPvaypUz={'id':user_id,'password':user_pw,'profile':'0','pushid':'','type':'general'}
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Post',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypUz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   AwERGhgecFkLrxHNTulqCdtPvaypUm=AwERGhgecFkLrxHNTulqCdtPvaypUn['credential']
   if user_pf!=0:
    AwERGhgecFkLrxHNTulqCdtPvaypUz={'id':AwERGhgecFkLrxHNTulqCdtPvaypUm,'password':'','profile':AwERGhgecFkLrxHNTulqCdtPvaypOJ(user_pf),'pushid':'','type':'credential'}
    AwERGhgecFkLrxHNTulqCdtPvaypUS['credential']=AwERGhgecFkLrxHNTulqCdtPvaypUm 
    AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Post',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypUz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
    AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
    AwERGhgecFkLrxHNTulqCdtPvaypUm=AwERGhgecFkLrxHNTulqCdtPvaypUn['credential']
   if AwERGhgecFkLrxHNTulqCdtPvaypUm:AwERGhgecFkLrxHNTulqCdtPvaypUQ=AwERGhgecFkLrxHNTulqCdtPvaypOn
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   AwERGhgecFkLrxHNTulqCdtPvaypUm='none' 
  AwERGhgecFkLrxHNTulqCdtPvaypUK.SaveCredential(AwERGhgecFkLrxHNTulqCdtPvaypUm)
  return AwERGhgecFkLrxHNTulqCdtPvaypUQ
 def GetIssue(AwERGhgecFkLrxHNTulqCdtPvaypUK):
  AwERGhgecFkLrxHNTulqCdtPvaypUI=AwERGhgecFkLrxHNTulqCdtPvaypOb
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/guid/issue'
   AwERGhgecFkLrxHNTulqCdtPvaypUS=AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams()
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   AwERGhgecFkLrxHNTulqCdtPvaypUJ=AwERGhgecFkLrxHNTulqCdtPvaypUn['guid']
   AwERGhgecFkLrxHNTulqCdtPvaypWU=AwERGhgecFkLrxHNTulqCdtPvaypUn['guidtimestamp']
   if AwERGhgecFkLrxHNTulqCdtPvaypUJ:AwERGhgecFkLrxHNTulqCdtPvaypUI=AwERGhgecFkLrxHNTulqCdtPvaypOn
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   AwERGhgecFkLrxHNTulqCdtPvaypUJ='none'
   AwERGhgecFkLrxHNTulqCdtPvaypWU='none' 
  AwERGhgecFkLrxHNTulqCdtPvaypUK.guid=AwERGhgecFkLrxHNTulqCdtPvaypUJ
  AwERGhgecFkLrxHNTulqCdtPvaypUK.guidtimestamp=AwERGhgecFkLrxHNTulqCdtPvaypWU
  return AwERGhgecFkLrxHNTulqCdtPvaypUI
 def Baseapi_Parse(AwERGhgecFkLrxHNTulqCdtPvaypUK,AwERGhgecFkLrxHNTulqCdtPvaypWm):
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypWK =urllib.parse.urlsplit(AwERGhgecFkLrxHNTulqCdtPvaypWm)
   if AwERGhgecFkLrxHNTulqCdtPvaypWK.netloc=='':
    AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUK.HTTPTAG+AwERGhgecFkLrxHNTulqCdtPvaypWK.netloc+AwERGhgecFkLrxHNTulqCdtPvaypWK.path
   else:
    AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypWK.scheme+'://'+AwERGhgecFkLrxHNTulqCdtPvaypWK.netloc+AwERGhgecFkLrxHNTulqCdtPvaypWK.path
   AwERGhgecFkLrxHNTulqCdtPvaypUS=AwERGhgecFkLrxHNTulqCdtPvaypMK(urllib.parse.parse_qsl(AwERGhgecFkLrxHNTulqCdtPvaypWK.query))
  except:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return '',{}
  return AwERGhgecFkLrxHNTulqCdtPvaypUi,AwERGhgecFkLrxHNTulqCdtPvaypUS
 def GetSupermultiUrl(AwERGhgecFkLrxHNTulqCdtPvaypUK,sCode,sIndex='0'):
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/cf/supermultisections/'+sCode
   AwERGhgecFkLrxHNTulqCdtPvaypUS=AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb)
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   AwERGhgecFkLrxHNTulqCdtPvaypWO=AwERGhgecFkLrxHNTulqCdtPvaypUn['multisectionlist'][AwERGhgecFkLrxHNTulqCdtPvaypMO(sIndex)]['eventlist'][1]['url']
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return ''
  return AwERGhgecFkLrxHNTulqCdtPvaypWO
 def Get_LiveCatagory_List(AwERGhgecFkLrxHNTulqCdtPvaypUK,sCode,sIndex='0'):
  AwERGhgecFkLrxHNTulqCdtPvaypWM=[]
  AwERGhgecFkLrxHNTulqCdtPvaypWm =AwERGhgecFkLrxHNTulqCdtPvaypUK.GetSupermultiUrl(sCode,sIndex)
  (AwERGhgecFkLrxHNTulqCdtPvaypUi,AwERGhgecFkLrxHNTulqCdtPvaypUS)=AwERGhgecFkLrxHNTulqCdtPvaypUK.Baseapi_Parse(AwERGhgecFkLrxHNTulqCdtPvaypWm)
  if AwERGhgecFkLrxHNTulqCdtPvaypUi=='':return AwERGhgecFkLrxHNTulqCdtPvaypWM,''
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb))
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   if not('filter_item_list' in AwERGhgecFkLrxHNTulqCdtPvaypUn['filter']['filterlist'][0]):return[],''
   AwERGhgecFkLrxHNTulqCdtPvaypWB=AwERGhgecFkLrxHNTulqCdtPvaypUn['filter']['filterlist'][0]['filter_item_list']
   for AwERGhgecFkLrxHNTulqCdtPvaypWs in AwERGhgecFkLrxHNTulqCdtPvaypWB:
    AwERGhgecFkLrxHNTulqCdtPvaypWo={'title':AwERGhgecFkLrxHNTulqCdtPvaypWs['title'],'genre':AwERGhgecFkLrxHNTulqCdtPvaypWs['api_parameters'][AwERGhgecFkLrxHNTulqCdtPvaypWs['api_parameters'].index('=')+1:]}
    AwERGhgecFkLrxHNTulqCdtPvaypWM.append(AwERGhgecFkLrxHNTulqCdtPvaypWo)
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[],''
  return AwERGhgecFkLrxHNTulqCdtPvaypWM,AwERGhgecFkLrxHNTulqCdtPvaypWm
 def Get_MainCatagory_List(AwERGhgecFkLrxHNTulqCdtPvaypUK,sCode,sIndex='0'):
  AwERGhgecFkLrxHNTulqCdtPvaypWM=[]
  AwERGhgecFkLrxHNTulqCdtPvaypWm =AwERGhgecFkLrxHNTulqCdtPvaypUK.GetSupermultiUrl(sCode,sIndex)
  (AwERGhgecFkLrxHNTulqCdtPvaypUi,AwERGhgecFkLrxHNTulqCdtPvaypUS)=AwERGhgecFkLrxHNTulqCdtPvaypUK.Baseapi_Parse(AwERGhgecFkLrxHNTulqCdtPvaypWm)
  if AwERGhgecFkLrxHNTulqCdtPvaypUi=='':return AwERGhgecFkLrxHNTulqCdtPvaypWM
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb))
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   if not('celllist' in AwERGhgecFkLrxHNTulqCdtPvaypUn['band']):return[]
   AwERGhgecFkLrxHNTulqCdtPvaypWB=AwERGhgecFkLrxHNTulqCdtPvaypUn['band']['celllist']
   for AwERGhgecFkLrxHNTulqCdtPvaypWs in AwERGhgecFkLrxHNTulqCdtPvaypWB:
    AwERGhgecFkLrxHNTulqCdtPvaypWj =AwERGhgecFkLrxHNTulqCdtPvaypWs['event_list'][1]['url']
    (AwERGhgecFkLrxHNTulqCdtPvaypWV,AwERGhgecFkLrxHNTulqCdtPvaypWD)=AwERGhgecFkLrxHNTulqCdtPvaypUK.Baseapi_Parse(AwERGhgecFkLrxHNTulqCdtPvaypWj)
    AwERGhgecFkLrxHNTulqCdtPvaypWo={'title':AwERGhgecFkLrxHNTulqCdtPvaypWs['title_list'][0]['text'],'suburl':AwERGhgecFkLrxHNTulqCdtPvaypWV,'subapi':AwERGhgecFkLrxHNTulqCdtPvaypWD.get('api'),'subtype':'catagory' if AwERGhgecFkLrxHNTulqCdtPvaypWD else 'supersection'}
    AwERGhgecFkLrxHNTulqCdtPvaypWM.append(AwERGhgecFkLrxHNTulqCdtPvaypWo)
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[]
  return AwERGhgecFkLrxHNTulqCdtPvaypWM
 def Get_SuperMultiSection_List(AwERGhgecFkLrxHNTulqCdtPvaypUK,subapi_text):
  AwERGhgecFkLrxHNTulqCdtPvaypWM=[]
  AwERGhgecFkLrxHNTulqCdtPvaypUS={}
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypWK =urllib.parse.urlsplit(subapi_text)
   if AwERGhgecFkLrxHNTulqCdtPvaypWK.path.find('apis.wavve.com')>=0: 
    AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUK.HTTPTAG+AwERGhgecFkLrxHNTulqCdtPvaypWK.path 
    AwERGhgecFkLrxHNTulqCdtPvaypUS=AwERGhgecFkLrxHNTulqCdtPvaypMK(urllib.parse.parse_qsl(AwERGhgecFkLrxHNTulqCdtPvaypWK.query))
   else:
    AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/cf'+AwERGhgecFkLrxHNTulqCdtPvaypWK.path 
   AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUi.replace('supermultisection/','supermultisections/')
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[]
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb))
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypOz,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   if not('multisectionlist' in AwERGhgecFkLrxHNTulqCdtPvaypUn):return[]
   AwERGhgecFkLrxHNTulqCdtPvaypWB=AwERGhgecFkLrxHNTulqCdtPvaypUn['multisectionlist']
   for AwERGhgecFkLrxHNTulqCdtPvaypWs in AwERGhgecFkLrxHNTulqCdtPvaypWB:
    AwERGhgecFkLrxHNTulqCdtPvaypWX=AwERGhgecFkLrxHNTulqCdtPvaypWs['title']
    if AwERGhgecFkLrxHNTulqCdtPvaypMm(AwERGhgecFkLrxHNTulqCdtPvaypWX)==0:continue
    if AwERGhgecFkLrxHNTulqCdtPvaypWX=='minor':continue
    if re.search(u'베너',AwERGhgecFkLrxHNTulqCdtPvaypWX):continue
    if re.search(u'배너',AwERGhgecFkLrxHNTulqCdtPvaypWX):continue 
    if AwERGhgecFkLrxHNTulqCdtPvaypMm(AwERGhgecFkLrxHNTulqCdtPvaypWs['eventlist'])>=3:
     AwERGhgecFkLrxHNTulqCdtPvaypWD =AwERGhgecFkLrxHNTulqCdtPvaypWs['eventlist'][2]['url']
    else:
     AwERGhgecFkLrxHNTulqCdtPvaypWD =AwERGhgecFkLrxHNTulqCdtPvaypWs['eventlist'][1]['url']
    AwERGhgecFkLrxHNTulqCdtPvaypWY=AwERGhgecFkLrxHNTulqCdtPvaypWs['cell_type']
    if AwERGhgecFkLrxHNTulqCdtPvaypWY=='band_2':
     if AwERGhgecFkLrxHNTulqCdtPvaypWD.find('channellist=')>=0:
      AwERGhgecFkLrxHNTulqCdtPvaypWY='band_live'
    AwERGhgecFkLrxHNTulqCdtPvaypWo={'title':AwERGhgecFkLrxHNTulqCdtPvaypUK.Get_ChangeText(AwERGhgecFkLrxHNTulqCdtPvaypWX),'subapi':AwERGhgecFkLrxHNTulqCdtPvaypWD,'cell_type':AwERGhgecFkLrxHNTulqCdtPvaypWY}
    AwERGhgecFkLrxHNTulqCdtPvaypWM.append(AwERGhgecFkLrxHNTulqCdtPvaypWo)
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[]
  return AwERGhgecFkLrxHNTulqCdtPvaypWM
 def Get_BandLiveSection_List(AwERGhgecFkLrxHNTulqCdtPvaypUK,AwERGhgecFkLrxHNTulqCdtPvaypWm,page_int=1):
  AwERGhgecFkLrxHNTulqCdtPvaypWf=[]
  AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypWJ=1
  AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypOb
  try:
   (AwERGhgecFkLrxHNTulqCdtPvaypUi,AwERGhgecFkLrxHNTulqCdtPvaypUS)=AwERGhgecFkLrxHNTulqCdtPvaypUK.Baseapi_Parse(AwERGhgecFkLrxHNTulqCdtPvaypWm)
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[],AwERGhgecFkLrxHNTulqCdtPvaypOb
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUS['limit']=AwERGhgecFkLrxHNTulqCdtPvaypUK.LIST_LIMIT
   AwERGhgecFkLrxHNTulqCdtPvaypUS['offset']=AwERGhgecFkLrxHNTulqCdtPvaypOJ((page_int-1)*AwERGhgecFkLrxHNTulqCdtPvaypUK.LIST_LIMIT)
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb))
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   if not('celllist' in AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']):return[],AwERGhgecFkLrxHNTulqCdtPvaypOb
   AwERGhgecFkLrxHNTulqCdtPvaypWB=AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['celllist']
   for AwERGhgecFkLrxHNTulqCdtPvaypWs in AwERGhgecFkLrxHNTulqCdtPvaypWB:
    AwERGhgecFkLrxHNTulqCdtPvaypWz =AwERGhgecFkLrxHNTulqCdtPvaypWs['event_list'][1]['url']
    AwERGhgecFkLrxHNTulqCdtPvaypWb=urllib.parse.urlsplit(AwERGhgecFkLrxHNTulqCdtPvaypWz).query
    AwERGhgecFkLrxHNTulqCdtPvaypWb=AwERGhgecFkLrxHNTulqCdtPvaypMK(urllib.parse.parse_qsl(AwERGhgecFkLrxHNTulqCdtPvaypWb))
    AwERGhgecFkLrxHNTulqCdtPvaypWn='channelid'
    AwERGhgecFkLrxHNTulqCdtPvaypWI=AwERGhgecFkLrxHNTulqCdtPvaypWb[AwERGhgecFkLrxHNTulqCdtPvaypWn]
    AwERGhgecFkLrxHNTulqCdtPvaypWo={'studio':AwERGhgecFkLrxHNTulqCdtPvaypWs['title_list'][0]['text'],'tvshowtitle':AwERGhgecFkLrxHNTulqCdtPvaypUK.Get_ChangeText(AwERGhgecFkLrxHNTulqCdtPvaypWs['title_list'][1]['text']),'channelid':AwERGhgecFkLrxHNTulqCdtPvaypWI,'age':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('age'),'thumbnail':'https://%s'%AwERGhgecFkLrxHNTulqCdtPvaypWs.get('thumbnail')}
    AwERGhgecFkLrxHNTulqCdtPvaypWf.append(AwERGhgecFkLrxHNTulqCdtPvaypWo)
   AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['pagecount'])
   if AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['count']:AwERGhgecFkLrxHNTulqCdtPvaypWJ =AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['count'])
   else:AwERGhgecFkLrxHNTulqCdtPvaypWJ=AwERGhgecFkLrxHNTulqCdtPvaypUK.LIST_LIMIT*page_int
   AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypWQ>AwERGhgecFkLrxHNTulqCdtPvaypWJ
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[],AwERGhgecFkLrxHNTulqCdtPvaypOb
  return AwERGhgecFkLrxHNTulqCdtPvaypWf,AwERGhgecFkLrxHNTulqCdtPvaypWi
 def Get_Band2Section_List(AwERGhgecFkLrxHNTulqCdtPvaypUK,AwERGhgecFkLrxHNTulqCdtPvaypWm,page_int=1):
  AwERGhgecFkLrxHNTulqCdtPvaypKU=[]
  AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypWJ=1
  AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypOb
  try:
   (AwERGhgecFkLrxHNTulqCdtPvaypUi,AwERGhgecFkLrxHNTulqCdtPvaypUS)=AwERGhgecFkLrxHNTulqCdtPvaypUK.Baseapi_Parse(AwERGhgecFkLrxHNTulqCdtPvaypWm)
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[],AwERGhgecFkLrxHNTulqCdtPvaypOb
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUS['came'] ='BandView'
   AwERGhgecFkLrxHNTulqCdtPvaypUS['limit']=AwERGhgecFkLrxHNTulqCdtPvaypUK.LIST_LIMIT
   AwERGhgecFkLrxHNTulqCdtPvaypUS['offset']=AwERGhgecFkLrxHNTulqCdtPvaypOJ((page_int-1)*AwERGhgecFkLrxHNTulqCdtPvaypUK.LIST_LIMIT)
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb))
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   if not('celllist' in AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']):return[],AwERGhgecFkLrxHNTulqCdtPvaypOb
   AwERGhgecFkLrxHNTulqCdtPvaypWB=AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['celllist']
   for AwERGhgecFkLrxHNTulqCdtPvaypWs in AwERGhgecFkLrxHNTulqCdtPvaypWB:
    AwERGhgecFkLrxHNTulqCdtPvaypWz =AwERGhgecFkLrxHNTulqCdtPvaypWs['event_list'][1]['url']
    AwERGhgecFkLrxHNTulqCdtPvaypWb=urllib.parse.urlsplit(AwERGhgecFkLrxHNTulqCdtPvaypWz).query
    AwERGhgecFkLrxHNTulqCdtPvaypWb=AwERGhgecFkLrxHNTulqCdtPvaypMK(urllib.parse.parse_qsl(AwERGhgecFkLrxHNTulqCdtPvaypWb))
    AwERGhgecFkLrxHNTulqCdtPvaypWn='contentid'
    AwERGhgecFkLrxHNTulqCdtPvaypWI=AwERGhgecFkLrxHNTulqCdtPvaypWb[AwERGhgecFkLrxHNTulqCdtPvaypWn]
    AwERGhgecFkLrxHNTulqCdtPvaypWo={'programtitle':AwERGhgecFkLrxHNTulqCdtPvaypWs['title_list'][0]['text'],'episodetitle':AwERGhgecFkLrxHNTulqCdtPvaypUK.Get_ChangeText(AwERGhgecFkLrxHNTulqCdtPvaypWs['title_list'][1]['text']),'age':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('age'),'thumbnail':AwERGhgecFkLrxHNTulqCdtPvaypUK.HTTPTAG+AwERGhgecFkLrxHNTulqCdtPvaypWs.get('thumbnail'),'vidtype':AwERGhgecFkLrxHNTulqCdtPvaypWn,'videoid':AwERGhgecFkLrxHNTulqCdtPvaypWI}
    AwERGhgecFkLrxHNTulqCdtPvaypKU.append(AwERGhgecFkLrxHNTulqCdtPvaypWo)
   AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['pagecount'])
   if AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['count']:AwERGhgecFkLrxHNTulqCdtPvaypWJ =AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['count'])
   else:AwERGhgecFkLrxHNTulqCdtPvaypWJ=AwERGhgecFkLrxHNTulqCdtPvaypUK.LIST_LIMIT*page_int
   AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypWQ>AwERGhgecFkLrxHNTulqCdtPvaypWJ
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[],AwERGhgecFkLrxHNTulqCdtPvaypOb
  return AwERGhgecFkLrxHNTulqCdtPvaypKU,AwERGhgecFkLrxHNTulqCdtPvaypWi
 def Get_Program_List(AwERGhgecFkLrxHNTulqCdtPvaypUK,AwERGhgecFkLrxHNTulqCdtPvaypWm,page_int=1,orderby='-'):
  AwERGhgecFkLrxHNTulqCdtPvaypKW=[]
  AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypWJ=1
  AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypOb
  (AwERGhgecFkLrxHNTulqCdtPvaypUi,AwERGhgecFkLrxHNTulqCdtPvaypUS)=AwERGhgecFkLrxHNTulqCdtPvaypUK.Baseapi_Parse(AwERGhgecFkLrxHNTulqCdtPvaypWm)
  if AwERGhgecFkLrxHNTulqCdtPvaypUi=='':return AwERGhgecFkLrxHNTulqCdtPvaypKW,AwERGhgecFkLrxHNTulqCdtPvaypWi
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUS['limit'] =AwERGhgecFkLrxHNTulqCdtPvaypUK.LIST_LIMIT
   AwERGhgecFkLrxHNTulqCdtPvaypUS['offset']=AwERGhgecFkLrxHNTulqCdtPvaypOJ((page_int-1)*AwERGhgecFkLrxHNTulqCdtPvaypUK.LIST_LIMIT)
   AwERGhgecFkLrxHNTulqCdtPvaypUS['page'] =AwERGhgecFkLrxHNTulqCdtPvaypOJ(page_int)
   if AwERGhgecFkLrxHNTulqCdtPvaypUS.get('orderby')!='' and AwERGhgecFkLrxHNTulqCdtPvaypUS.get('orderby')!='regdatefirst' and orderby!='-':
    AwERGhgecFkLrxHNTulqCdtPvaypUS['orderby']=orderby 
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb))
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   if AwERGhgecFkLrxHNTulqCdtPvaypWm.find('instantplay')>=0:
    if not('celllist' in AwERGhgecFkLrxHNTulqCdtPvaypUn['band']):return AwERGhgecFkLrxHNTulqCdtPvaypKW,AwERGhgecFkLrxHNTulqCdtPvaypWi
    AwERGhgecFkLrxHNTulqCdtPvaypWB=AwERGhgecFkLrxHNTulqCdtPvaypUn['band']['celllist']
   else:
    if not('celllist' in AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']):return AwERGhgecFkLrxHNTulqCdtPvaypKW,AwERGhgecFkLrxHNTulqCdtPvaypWi
    AwERGhgecFkLrxHNTulqCdtPvaypWB=AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['celllist']
   for AwERGhgecFkLrxHNTulqCdtPvaypWs in AwERGhgecFkLrxHNTulqCdtPvaypWB:
    for AwERGhgecFkLrxHNTulqCdtPvaypKO in AwERGhgecFkLrxHNTulqCdtPvaypWs['event_list']:
     if AwERGhgecFkLrxHNTulqCdtPvaypKO.get('type')=='on-navigation':
      AwERGhgecFkLrxHNTulqCdtPvaypWz =AwERGhgecFkLrxHNTulqCdtPvaypKO['url']
    AwERGhgecFkLrxHNTulqCdtPvaypWb=urllib.parse.urlsplit(AwERGhgecFkLrxHNTulqCdtPvaypWz).query
    AwERGhgecFkLrxHNTulqCdtPvaypWn=AwERGhgecFkLrxHNTulqCdtPvaypWb[0:AwERGhgecFkLrxHNTulqCdtPvaypWb.find('=')]
    AwERGhgecFkLrxHNTulqCdtPvaypWI=AwERGhgecFkLrxHNTulqCdtPvaypWb[AwERGhgecFkLrxHNTulqCdtPvaypWb.find('=')+1:]
    AwERGhgecFkLrxHNTulqCdtPvaypWo={'title':AwERGhgecFkLrxHNTulqCdtPvaypWs['title_list'][0]['text'],'age':AwERGhgecFkLrxHNTulqCdtPvaypWs['age'],'thumbnail':'https://%s'%AwERGhgecFkLrxHNTulqCdtPvaypWs.get('thumbnail'),'videoid':AwERGhgecFkLrxHNTulqCdtPvaypWI,'vidtype':AwERGhgecFkLrxHNTulqCdtPvaypWn}
    AwERGhgecFkLrxHNTulqCdtPvaypKW.append(AwERGhgecFkLrxHNTulqCdtPvaypWo)
   if AwERGhgecFkLrxHNTulqCdtPvaypWm.find('instantplay')<0:
    AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['pagecount'])
    if AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['count']:AwERGhgecFkLrxHNTulqCdtPvaypWJ =AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['count'])
    else:AwERGhgecFkLrxHNTulqCdtPvaypWJ=AwERGhgecFkLrxHNTulqCdtPvaypUK.LIST_LIMIT*page_int
    AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypWQ>AwERGhgecFkLrxHNTulqCdtPvaypWJ
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[],AwERGhgecFkLrxHNTulqCdtPvaypOb
  return AwERGhgecFkLrxHNTulqCdtPvaypKW,AwERGhgecFkLrxHNTulqCdtPvaypWi
 def Get_Movie_List(AwERGhgecFkLrxHNTulqCdtPvaypUK,AwERGhgecFkLrxHNTulqCdtPvaypWm,page_int=1):
  AwERGhgecFkLrxHNTulqCdtPvaypKM=[]
  AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypWJ=1
  AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypOb
  (AwERGhgecFkLrxHNTulqCdtPvaypUi,AwERGhgecFkLrxHNTulqCdtPvaypUS)=AwERGhgecFkLrxHNTulqCdtPvaypUK.Baseapi_Parse(AwERGhgecFkLrxHNTulqCdtPvaypWm)
  if AwERGhgecFkLrxHNTulqCdtPvaypUi=='':return AwERGhgecFkLrxHNTulqCdtPvaypKM,AwERGhgecFkLrxHNTulqCdtPvaypWi
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUS['limit']=AwERGhgecFkLrxHNTulqCdtPvaypUK.MV_LIMIT
   AwERGhgecFkLrxHNTulqCdtPvaypUS['offset']=AwERGhgecFkLrxHNTulqCdtPvaypOJ((page_int-1)*AwERGhgecFkLrxHNTulqCdtPvaypUK.MV_LIMIT)
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb))
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   if not('celllist' in AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']):return AwERGhgecFkLrxHNTulqCdtPvaypKM,AwERGhgecFkLrxHNTulqCdtPvaypWi
   AwERGhgecFkLrxHNTulqCdtPvaypWB=AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['celllist']
   for AwERGhgecFkLrxHNTulqCdtPvaypWs in AwERGhgecFkLrxHNTulqCdtPvaypWB:
    AwERGhgecFkLrxHNTulqCdtPvaypWz =AwERGhgecFkLrxHNTulqCdtPvaypWs['event_list'][1]['url']
    AwERGhgecFkLrxHNTulqCdtPvaypWb=urllib.parse.urlsplit(AwERGhgecFkLrxHNTulqCdtPvaypWz).query
    AwERGhgecFkLrxHNTulqCdtPvaypWn=AwERGhgecFkLrxHNTulqCdtPvaypWb[0:AwERGhgecFkLrxHNTulqCdtPvaypWb.find('=')]
    AwERGhgecFkLrxHNTulqCdtPvaypWI=AwERGhgecFkLrxHNTulqCdtPvaypWb[AwERGhgecFkLrxHNTulqCdtPvaypWb.find('=')+1:]
    AwERGhgecFkLrxHNTulqCdtPvaypWo={'title':AwERGhgecFkLrxHNTulqCdtPvaypWs['title_list'][0]['text'],'age':AwERGhgecFkLrxHNTulqCdtPvaypWs['age'],'thumbnail':'https://%s'%AwERGhgecFkLrxHNTulqCdtPvaypWs.get('thumbnail'),'videoid':AwERGhgecFkLrxHNTulqCdtPvaypWI,'vidtype':AwERGhgecFkLrxHNTulqCdtPvaypWn}
    AwERGhgecFkLrxHNTulqCdtPvaypKM.append(AwERGhgecFkLrxHNTulqCdtPvaypWo)
   AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['pagecount'])
   if AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['count']:AwERGhgecFkLrxHNTulqCdtPvaypWJ =AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['count'])
   else:AwERGhgecFkLrxHNTulqCdtPvaypWJ=AwERGhgecFkLrxHNTulqCdtPvaypUK.MV_LIMIT*page_int
   AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypWQ>AwERGhgecFkLrxHNTulqCdtPvaypWJ
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[],AwERGhgecFkLrxHNTulqCdtPvaypOb
  return AwERGhgecFkLrxHNTulqCdtPvaypKM,AwERGhgecFkLrxHNTulqCdtPvaypWi
 def ProgramidToContentid(AwERGhgecFkLrxHNTulqCdtPvaypUK,AwERGhgecFkLrxHNTulqCdtPvaypKB):
  AwERGhgecFkLrxHNTulqCdtPvaypKm=''
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUi =AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/vod/programs-contentid/'+AwERGhgecFkLrxHNTulqCdtPvaypKB
   AwERGhgecFkLrxHNTulqCdtPvaypUS=AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb)
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypKS=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   if not('contentid' in AwERGhgecFkLrxHNTulqCdtPvaypKS):return AwERGhgecFkLrxHNTulqCdtPvaypKm 
   AwERGhgecFkLrxHNTulqCdtPvaypKm=AwERGhgecFkLrxHNTulqCdtPvaypKS['contentid']
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
  return AwERGhgecFkLrxHNTulqCdtPvaypKm
 def ContentidToProgramid(AwERGhgecFkLrxHNTulqCdtPvaypUK,AwERGhgecFkLrxHNTulqCdtPvaypKm):
  AwERGhgecFkLrxHNTulqCdtPvaypKB=''
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUi =AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/cf/vod/contents/'+AwERGhgecFkLrxHNTulqCdtPvaypKm
   AwERGhgecFkLrxHNTulqCdtPvaypUS=AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb)
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypKS=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   if not('programid' in AwERGhgecFkLrxHNTulqCdtPvaypKS):return AwERGhgecFkLrxHNTulqCdtPvaypKB 
   AwERGhgecFkLrxHNTulqCdtPvaypKB=AwERGhgecFkLrxHNTulqCdtPvaypKS['programid']
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
  return AwERGhgecFkLrxHNTulqCdtPvaypKB
 def GetProgramInfo(AwERGhgecFkLrxHNTulqCdtPvaypUK,program_code):
  AwERGhgecFkLrxHNTulqCdtPvaypKs={}
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/cf/vod/contents/'+program_code
   AwERGhgecFkLrxHNTulqCdtPvaypUS=AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb)
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypKS=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   AwERGhgecFkLrxHNTulqCdtPvaypMW(AwERGhgecFkLrxHNTulqCdtPvaypKS)
   AwERGhgecFkLrxHNTulqCdtPvaypKo=img_fanart=AwERGhgecFkLrxHNTulqCdtPvaypKj=''
   if AwERGhgecFkLrxHNTulqCdtPvaypKS.get('programposterimage')!='':AwERGhgecFkLrxHNTulqCdtPvaypKo =AwERGhgecFkLrxHNTulqCdtPvaypUK.HTTPTAG+AwERGhgecFkLrxHNTulqCdtPvaypKS.get('programposterimage')
   if AwERGhgecFkLrxHNTulqCdtPvaypKS.get('programimage') !='':img_fanart =AwERGhgecFkLrxHNTulqCdtPvaypUK.HTTPTAG+AwERGhgecFkLrxHNTulqCdtPvaypKS.get('programimage')
   if AwERGhgecFkLrxHNTulqCdtPvaypKS.get('programcirlceimage')!='':AwERGhgecFkLrxHNTulqCdtPvaypKj=AwERGhgecFkLrxHNTulqCdtPvaypUK.HTTPTAG+AwERGhgecFkLrxHNTulqCdtPvaypKS.get('programcirlceimage')
   if 'poster_default' in AwERGhgecFkLrxHNTulqCdtPvaypKo:
    AwERGhgecFkLrxHNTulqCdtPvaypKo =img_fanart
    AwERGhgecFkLrxHNTulqCdtPvaypKj=''
   AwERGhgecFkLrxHNTulqCdtPvaypKs={'imgPoster':AwERGhgecFkLrxHNTulqCdtPvaypKo,'imgFanart':img_fanart,'imgClearlogo':AwERGhgecFkLrxHNTulqCdtPvaypKj}
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
  return AwERGhgecFkLrxHNTulqCdtPvaypKs
 def Get_Episode_List(AwERGhgecFkLrxHNTulqCdtPvaypUK,AwERGhgecFkLrxHNTulqCdtPvaypWI,AwERGhgecFkLrxHNTulqCdtPvaypWn,page_int=1,orderby='desc'):
  AwERGhgecFkLrxHNTulqCdtPvaypKV=[]
  AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypWJ=1
  AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypOb
  AwERGhgecFkLrxHNTulqCdtPvaypKD={}
  if AwERGhgecFkLrxHNTulqCdtPvaypWn=='contentid':
   AwERGhgecFkLrxHNTulqCdtPvaypKB=AwERGhgecFkLrxHNTulqCdtPvaypUK.ContentidToProgramid(AwERGhgecFkLrxHNTulqCdtPvaypWI)
   AwERGhgecFkLrxHNTulqCdtPvaypKD=AwERGhgecFkLrxHNTulqCdtPvaypUK.GetProgramInfo(AwERGhgecFkLrxHNTulqCdtPvaypWI)
  else:
   AwERGhgecFkLrxHNTulqCdtPvaypKB=AwERGhgecFkLrxHNTulqCdtPvaypWI
   AwERGhgecFkLrxHNTulqCdtPvaypKm=AwERGhgecFkLrxHNTulqCdtPvaypUK.ProgramidToContentid(AwERGhgecFkLrxHNTulqCdtPvaypWI)
   if AwERGhgecFkLrxHNTulqCdtPvaypKm!='':AwERGhgecFkLrxHNTulqCdtPvaypKD=AwERGhgecFkLrxHNTulqCdtPvaypUK.GetProgramInfo(AwERGhgecFkLrxHNTulqCdtPvaypKm)
  if orderby=='desc':
   orderby='new'
  else:
   orderby='old'
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/vod/programs-contents/'+AwERGhgecFkLrxHNTulqCdtPvaypKB
   AwERGhgecFkLrxHNTulqCdtPvaypUS={}
   AwERGhgecFkLrxHNTulqCdtPvaypUS['limit'] =AwERGhgecFkLrxHNTulqCdtPvaypUK.EP_LIMIT
   AwERGhgecFkLrxHNTulqCdtPvaypUS['offset']=AwERGhgecFkLrxHNTulqCdtPvaypOJ((page_int-1)*AwERGhgecFkLrxHNTulqCdtPvaypUK.EP_LIMIT)
   AwERGhgecFkLrxHNTulqCdtPvaypUS['orderby']=orderby 
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb))
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   AwERGhgecFkLrxHNTulqCdtPvaypWB=AwERGhgecFkLrxHNTulqCdtPvaypUn['list']
   for AwERGhgecFkLrxHNTulqCdtPvaypWs in AwERGhgecFkLrxHNTulqCdtPvaypWB:
    AwERGhgecFkLrxHNTulqCdtPvaypKY=re.sub(u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)','',AwERGhgecFkLrxHNTulqCdtPvaypWs.get('synopsis'))
    AwERGhgecFkLrxHNTulqCdtPvaypKf=AwERGhgecFkLrxHNTulqCdtPvaypUK.HTTPTAG+AwERGhgecFkLrxHNTulqCdtPvaypWs.get('image')
    AwERGhgecFkLrxHNTulqCdtPvaypKQ=AwERGhgecFkLrxHNTulqCdtPvaypKi=AwERGhgecFkLrxHNTulqCdtPvaypKz=''
    if AwERGhgecFkLrxHNTulqCdtPvaypKD!={}:
     AwERGhgecFkLrxHNTulqCdtPvaypKQ =AwERGhgecFkLrxHNTulqCdtPvaypKD.get('imgPoster')
     AwERGhgecFkLrxHNTulqCdtPvaypKi =AwERGhgecFkLrxHNTulqCdtPvaypKD.get('imgFanart')
     AwERGhgecFkLrxHNTulqCdtPvaypKz=AwERGhgecFkLrxHNTulqCdtPvaypKD.get('imgClearlogo')
     AwERGhgecFkLrxHNTulqCdtPvaypKb={'thumb':AwERGhgecFkLrxHNTulqCdtPvaypKf,'poster':AwERGhgecFkLrxHNTulqCdtPvaypKQ,'fanart':AwERGhgecFkLrxHNTulqCdtPvaypKi,'clearlogo':AwERGhgecFkLrxHNTulqCdtPvaypKz}
    else:
     AwERGhgecFkLrxHNTulqCdtPvaypKb=AwERGhgecFkLrxHNTulqCdtPvaypKf
    AwERGhgecFkLrxHNTulqCdtPvaypWo={'programtitle':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('programtitle'),'episodetitle':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('episodetitle'),'episodenumber':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('episodenumber'),'releasedate':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('releasedate'),'releaseweekday':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('releaseweekday'),'programid':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('programid'),'contentid':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('contentid'),'age':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('targetage'),'playtime':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('playtime'),'synopsis':AwERGhgecFkLrxHNTulqCdtPvaypKY,'episodeactors':AwERGhgecFkLrxHNTulqCdtPvaypWs.get('episodeactors').split(',')if AwERGhgecFkLrxHNTulqCdtPvaypWs.get('episodeactors')!='' else[],'thumbnail':AwERGhgecFkLrxHNTulqCdtPvaypKb}
    AwERGhgecFkLrxHNTulqCdtPvaypKV.append(AwERGhgecFkLrxHNTulqCdtPvaypWo)
   AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypUn['pagecount'])
   if AwERGhgecFkLrxHNTulqCdtPvaypUn['count']:AwERGhgecFkLrxHNTulqCdtPvaypWJ =AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypUn['count'])
   else:AwERGhgecFkLrxHNTulqCdtPvaypWJ=AwERGhgecFkLrxHNTulqCdtPvaypUK.EP_LIMIT*page_int
   AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypWQ>AwERGhgecFkLrxHNTulqCdtPvaypWJ
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[],AwERGhgecFkLrxHNTulqCdtPvaypOb
  return AwERGhgecFkLrxHNTulqCdtPvaypKV,AwERGhgecFkLrxHNTulqCdtPvaypWi
 def GetEPGList(AwERGhgecFkLrxHNTulqCdtPvaypUK,genre):
  AwERGhgecFkLrxHNTulqCdtPvaypKn={}
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypKI=AwERGhgecFkLrxHNTulqCdtPvaypUK.Get_Now_Datetime()
   if genre=='all':
    AwERGhgecFkLrxHNTulqCdtPvaypKJ =AwERGhgecFkLrxHNTulqCdtPvaypKI+datetime.timedelta(hours=3)
   else:
    AwERGhgecFkLrxHNTulqCdtPvaypKJ =AwERGhgecFkLrxHNTulqCdtPvaypKI+datetime.timedelta(hours=3)
   AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/live/epgs'
   AwERGhgecFkLrxHNTulqCdtPvaypUS={'limit':'100','offset':'0','genre':genre,'startdatetime':AwERGhgecFkLrxHNTulqCdtPvaypKI.strftime('%Y-%m-%d %H:00'),'enddatetime':AwERGhgecFkLrxHNTulqCdtPvaypKJ.strftime('%Y-%m-%d %H:00')}
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb))
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   AwERGhgecFkLrxHNTulqCdtPvaypOU=AwERGhgecFkLrxHNTulqCdtPvaypUn['list']
   for AwERGhgecFkLrxHNTulqCdtPvaypWs in AwERGhgecFkLrxHNTulqCdtPvaypOU:
    AwERGhgecFkLrxHNTulqCdtPvaypOW=''
    for AwERGhgecFkLrxHNTulqCdtPvaypOK in AwERGhgecFkLrxHNTulqCdtPvaypWs['list']:
     if AwERGhgecFkLrxHNTulqCdtPvaypOW:AwERGhgecFkLrxHNTulqCdtPvaypOW+='\n'
     AwERGhgecFkLrxHNTulqCdtPvaypOW+=AwERGhgecFkLrxHNTulqCdtPvaypUK.Get_ChangeText(AwERGhgecFkLrxHNTulqCdtPvaypOK['title'])+'\n'
     AwERGhgecFkLrxHNTulqCdtPvaypOW+=' [%s ~ %s]'%(AwERGhgecFkLrxHNTulqCdtPvaypOK['starttime'][-5:],AwERGhgecFkLrxHNTulqCdtPvaypOK['endtime'][-5:])+'\n'
    AwERGhgecFkLrxHNTulqCdtPvaypKn[AwERGhgecFkLrxHNTulqCdtPvaypWs['channelid']]=AwERGhgecFkLrxHNTulqCdtPvaypOW
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
  return AwERGhgecFkLrxHNTulqCdtPvaypKn
 def Get_LiveChannel_List(AwERGhgecFkLrxHNTulqCdtPvaypUK,genre,AwERGhgecFkLrxHNTulqCdtPvaypWm):
  AwERGhgecFkLrxHNTulqCdtPvaypWf=[]
  (AwERGhgecFkLrxHNTulqCdtPvaypUi,AwERGhgecFkLrxHNTulqCdtPvaypUS)=AwERGhgecFkLrxHNTulqCdtPvaypUK.Baseapi_Parse(AwERGhgecFkLrxHNTulqCdtPvaypWm)
  if AwERGhgecFkLrxHNTulqCdtPvaypUi=='':return AwERGhgecFkLrxHNTulqCdtPvaypWf
  AwERGhgecFkLrxHNTulqCdtPvaypOM=AwERGhgecFkLrxHNTulqCdtPvaypUK.GetEPGList(genre)
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb))
   AwERGhgecFkLrxHNTulqCdtPvaypUS['genre']=genre
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   if not('celllist' in AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']):return[]
   AwERGhgecFkLrxHNTulqCdtPvaypWB=AwERGhgecFkLrxHNTulqCdtPvaypUn['cell_toplist']['celllist']
   for AwERGhgecFkLrxHNTulqCdtPvaypWs in AwERGhgecFkLrxHNTulqCdtPvaypWB:
    AwERGhgecFkLrxHNTulqCdtPvaypKm=AwERGhgecFkLrxHNTulqCdtPvaypWs['contentid']
    if AwERGhgecFkLrxHNTulqCdtPvaypKm in AwERGhgecFkLrxHNTulqCdtPvaypOM:
     AwERGhgecFkLrxHNTulqCdtPvaypOm=AwERGhgecFkLrxHNTulqCdtPvaypOM[AwERGhgecFkLrxHNTulqCdtPvaypKm]
    else:
     AwERGhgecFkLrxHNTulqCdtPvaypOm=''
    AwERGhgecFkLrxHNTulqCdtPvaypWo={'studio':AwERGhgecFkLrxHNTulqCdtPvaypWs['title_list'][0]['text'],'tvshowtitle':AwERGhgecFkLrxHNTulqCdtPvaypUK.Get_ChangeText(AwERGhgecFkLrxHNTulqCdtPvaypWs['title_list'][1]['text']),'channelid':AwERGhgecFkLrxHNTulqCdtPvaypKm,'age':AwERGhgecFkLrxHNTulqCdtPvaypWs['age'],'thumbnail':'https://%s'%AwERGhgecFkLrxHNTulqCdtPvaypWs.get('thumbnail'),'epg':AwERGhgecFkLrxHNTulqCdtPvaypOm}
    AwERGhgecFkLrxHNTulqCdtPvaypWf.append(AwERGhgecFkLrxHNTulqCdtPvaypWo)
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return[]
  return AwERGhgecFkLrxHNTulqCdtPvaypWf
 def Get_Search_List(AwERGhgecFkLrxHNTulqCdtPvaypUK,search_key,sType,page_int,exclusion21=AwERGhgecFkLrxHNTulqCdtPvaypOb):
  AwERGhgecFkLrxHNTulqCdtPvaypOS=[]
  AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypWJ=1
  AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypOb
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/cf/search/list.js'
   AwERGhgecFkLrxHNTulqCdtPvaypUS={'type':'program' if sType=='vod' else 'movie','keyword':search_key,'offset':AwERGhgecFkLrxHNTulqCdtPvaypOJ((page_int-1)*AwERGhgecFkLrxHNTulqCdtPvaypUK.SEARCH_LIMIT),'limit':AwERGhgecFkLrxHNTulqCdtPvaypUK.SEARCH_LIMIT,'orderby':'score'}
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb))
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypKS=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   if not('celllist' in AwERGhgecFkLrxHNTulqCdtPvaypKS['cell_toplist']):return AwERGhgecFkLrxHNTulqCdtPvaypOS,AwERGhgecFkLrxHNTulqCdtPvaypWi
   AwERGhgecFkLrxHNTulqCdtPvaypWB=AwERGhgecFkLrxHNTulqCdtPvaypKS['cell_toplist']['celllist']
   for AwERGhgecFkLrxHNTulqCdtPvaypWs in AwERGhgecFkLrxHNTulqCdtPvaypWB:
    AwERGhgecFkLrxHNTulqCdtPvaypWz =AwERGhgecFkLrxHNTulqCdtPvaypWs['event_list'][1]['url']
    AwERGhgecFkLrxHNTulqCdtPvaypWb=urllib.parse.urlsplit(AwERGhgecFkLrxHNTulqCdtPvaypWz).query
    AwERGhgecFkLrxHNTulqCdtPvaypWn=AwERGhgecFkLrxHNTulqCdtPvaypWb[0:AwERGhgecFkLrxHNTulqCdtPvaypWb.find('=')]
    AwERGhgecFkLrxHNTulqCdtPvaypWI=AwERGhgecFkLrxHNTulqCdtPvaypWb[AwERGhgecFkLrxHNTulqCdtPvaypWb.find('=')+1:]
    AwERGhgecFkLrxHNTulqCdtPvaypWo={'title':AwERGhgecFkLrxHNTulqCdtPvaypWs['title_list'][0]['text'],'age':AwERGhgecFkLrxHNTulqCdtPvaypWs['age'],'thumbnail':'https://%s'%AwERGhgecFkLrxHNTulqCdtPvaypWs.get('thumbnail'),'videoid':AwERGhgecFkLrxHNTulqCdtPvaypWI,'vidtype':AwERGhgecFkLrxHNTulqCdtPvaypWn}
    if exclusion21==AwERGhgecFkLrxHNTulqCdtPvaypOb or AwERGhgecFkLrxHNTulqCdtPvaypWs.get('age')!='21':
     AwERGhgecFkLrxHNTulqCdtPvaypOS.append(AwERGhgecFkLrxHNTulqCdtPvaypWo)
   AwERGhgecFkLrxHNTulqCdtPvaypWQ=AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypKS['cell_toplist']['pagecount'])
   if AwERGhgecFkLrxHNTulqCdtPvaypKS['cell_toplist']['count']:AwERGhgecFkLrxHNTulqCdtPvaypWJ =AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypKS['cell_toplist']['count'])
   else:AwERGhgecFkLrxHNTulqCdtPvaypWJ=AwERGhgecFkLrxHNTulqCdtPvaypUK.LIST_LIMIT
   AwERGhgecFkLrxHNTulqCdtPvaypWi=AwERGhgecFkLrxHNTulqCdtPvaypWQ>AwERGhgecFkLrxHNTulqCdtPvaypWJ
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
  return AwERGhgecFkLrxHNTulqCdtPvaypOS,AwERGhgecFkLrxHNTulqCdtPvaypWi 
 def GetStreamingURL(AwERGhgecFkLrxHNTulqCdtPvaypUK,mode,AwERGhgecFkLrxHNTulqCdtPvaypKm,quality_int,pvrmode='-'):
  AwERGhgecFkLrxHNTulqCdtPvaypOB=AwERGhgecFkLrxHNTulqCdtPvaypOf=AwERGhgecFkLrxHNTulqCdtPvaypOQ=streaming_preview=''
  AwERGhgecFkLrxHNTulqCdtPvaypOs=[]
  AwERGhgecFkLrxHNTulqCdtPvaypOo='hls'
  if mode=='LIVE':
   AwERGhgecFkLrxHNTulqCdtPvaypUi =AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/live/channels/'+AwERGhgecFkLrxHNTulqCdtPvaypKm
   AwERGhgecFkLrxHNTulqCdtPvaypOj='live'
  elif mode=='VOD':
   AwERGhgecFkLrxHNTulqCdtPvaypUi =AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/cf/vod/contents/'+AwERGhgecFkLrxHNTulqCdtPvaypKm
   AwERGhgecFkLrxHNTulqCdtPvaypOj='vod'
  elif mode=='MOVIE':
   AwERGhgecFkLrxHNTulqCdtPvaypUi =AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/cf/movie/contents/'+AwERGhgecFkLrxHNTulqCdtPvaypKm
   AwERGhgecFkLrxHNTulqCdtPvaypOj='movie'
  try:
   if mode!='LIVE' or pvrmode=='-':
    AwERGhgecFkLrxHNTulqCdtPvaypUS=AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOb)
    AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
    AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
    AwERGhgecFkLrxHNTulqCdtPvaypOV=AwERGhgecFkLrxHNTulqCdtPvaypUn['qualities']['list']
    if AwERGhgecFkLrxHNTulqCdtPvaypOV==AwERGhgecFkLrxHNTulqCdtPvaypOz:return(AwERGhgecFkLrxHNTulqCdtPvaypOB,AwERGhgecFkLrxHNTulqCdtPvaypOf,AwERGhgecFkLrxHNTulqCdtPvaypOQ,streaming_preview)
    for AwERGhgecFkLrxHNTulqCdtPvaypOD in AwERGhgecFkLrxHNTulqCdtPvaypOV:
     AwERGhgecFkLrxHNTulqCdtPvaypOs.append(AwERGhgecFkLrxHNTulqCdtPvaypMO(AwERGhgecFkLrxHNTulqCdtPvaypOD.get('id').rstrip('p')))
    if 'type' in AwERGhgecFkLrxHNTulqCdtPvaypUn:
     if AwERGhgecFkLrxHNTulqCdtPvaypUn['type']=='onair':
      AwERGhgecFkLrxHNTulqCdtPvaypOj='onairvod'
    if 'drms' in AwERGhgecFkLrxHNTulqCdtPvaypUn:
     if AwERGhgecFkLrxHNTulqCdtPvaypUn['drms']:
      AwERGhgecFkLrxHNTulqCdtPvaypOo='dash'
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
   return(AwERGhgecFkLrxHNTulqCdtPvaypOB,AwERGhgecFkLrxHNTulqCdtPvaypOf,AwERGhgecFkLrxHNTulqCdtPvaypOQ,streaming_preview)
  try:
   AwERGhgecFkLrxHNTulqCdtPvaypOX=AwERGhgecFkLrxHNTulqCdtPvaypUK.CheckQuality(quality_int,AwERGhgecFkLrxHNTulqCdtPvaypOs)
   if mode=='LIVE' and pvrmode!='-':
    AwERGhgecFkLrxHNTulqCdtPvaypOY='auto'
   else:
    AwERGhgecFkLrxHNTulqCdtPvaypOY=AwERGhgecFkLrxHNTulqCdtPvaypOJ(AwERGhgecFkLrxHNTulqCdtPvaypOX)+'p'
   AwERGhgecFkLrxHNTulqCdtPvaypUi=AwERGhgecFkLrxHNTulqCdtPvaypUK.API_DOMAIN+'/streaming'
   AwERGhgecFkLrxHNTulqCdtPvaypUS={'contentid':AwERGhgecFkLrxHNTulqCdtPvaypKm,'contenttype':AwERGhgecFkLrxHNTulqCdtPvaypOj,'action':AwERGhgecFkLrxHNTulqCdtPvaypOo,'quality':AwERGhgecFkLrxHNTulqCdtPvaypOY,'deviceModelId':'Windows 10','guid':AwERGhgecFkLrxHNTulqCdtPvaypUK.GetGUID(guidType=2),'lastplayid':'','authtype':'cookie','isabr':'y','ishevc':'n'}
   AwERGhgecFkLrxHNTulqCdtPvaypUS.update(AwERGhgecFkLrxHNTulqCdtPvaypUK.GetDefaultParams(login=AwERGhgecFkLrxHNTulqCdtPvaypOn))
   AwERGhgecFkLrxHNTulqCdtPvaypUb=AwERGhgecFkLrxHNTulqCdtPvaypUK.callRequestCookies('Get',AwERGhgecFkLrxHNTulqCdtPvaypUi,payload=AwERGhgecFkLrxHNTulqCdtPvaypOz,params=AwERGhgecFkLrxHNTulqCdtPvaypUS,headers=AwERGhgecFkLrxHNTulqCdtPvaypOz,cookies=AwERGhgecFkLrxHNTulqCdtPvaypOz)
   AwERGhgecFkLrxHNTulqCdtPvaypUn=json.loads(AwERGhgecFkLrxHNTulqCdtPvaypUb.text)
   AwERGhgecFkLrxHNTulqCdtPvaypOB=AwERGhgecFkLrxHNTulqCdtPvaypUn['playurl']
   if AwERGhgecFkLrxHNTulqCdtPvaypOB==AwERGhgecFkLrxHNTulqCdtPvaypOz:return(AwERGhgecFkLrxHNTulqCdtPvaypOB,AwERGhgecFkLrxHNTulqCdtPvaypOf,AwERGhgecFkLrxHNTulqCdtPvaypOQ,streaming_preview)
   AwERGhgecFkLrxHNTulqCdtPvaypOf=AwERGhgecFkLrxHNTulqCdtPvaypUn['awscookie']
   AwERGhgecFkLrxHNTulqCdtPvaypOQ =AwERGhgecFkLrxHNTulqCdtPvaypUn['drm']
   if 'previewmsg' in AwERGhgecFkLrxHNTulqCdtPvaypUn['preview']:streaming_preview=AwERGhgecFkLrxHNTulqCdtPvaypUn['preview']['previewmsg']
  except AwERGhgecFkLrxHNTulqCdtPvaypMU as exception:
   AwERGhgecFkLrxHNTulqCdtPvaypMW(exception)
  return(AwERGhgecFkLrxHNTulqCdtPvaypOB,AwERGhgecFkLrxHNTulqCdtPvaypOf,AwERGhgecFkLrxHNTulqCdtPvaypOQ,streaming_preview) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
