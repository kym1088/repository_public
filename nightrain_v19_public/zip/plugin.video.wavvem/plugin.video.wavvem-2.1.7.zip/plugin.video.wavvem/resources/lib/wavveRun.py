__author__="NightRain"
BwzXoRQOlGWfDYmbcCLesjrpFUEVuA=object
BwzXoRQOlGWfDYmbcCLesjrpFUEVuH=None
BwzXoRQOlGWfDYmbcCLesjrpFUEVuT=True
BwzXoRQOlGWfDYmbcCLesjrpFUEVua=False
BwzXoRQOlGWfDYmbcCLesjrpFUEVux=int
BwzXoRQOlGWfDYmbcCLesjrpFUEVuJ=type
BwzXoRQOlGWfDYmbcCLesjrpFUEVuy=dict
BwzXoRQOlGWfDYmbcCLesjrpFUEVuS=len
BwzXoRQOlGWfDYmbcCLesjrpFUEVug=range
BwzXoRQOlGWfDYmbcCLesjrpFUEVNk=str
BwzXoRQOlGWfDYmbcCLesjrpFUEVNP=open
BwzXoRQOlGWfDYmbcCLesjrpFUEVNq=Exception
BwzXoRQOlGWfDYmbcCLesjrpFUEVNK=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
BwzXoRQOlGWfDYmbcCLesjrpFUEVkq=[{'title':'LIVE 채널','mode':'LIVE_CATAGORY','sCode':'GN54','sIndex':'0','sType':'live','icon':'live.png'},{'title':'홈','mode':'SUPERSECTION_LIST','suburl':'https://www.wavve.com/supermultisection/GN51','icon':'home.png'},{'title':'지금 핫한 프로그램','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/es/vod/hotepisodes?orderby=viewtime&contenttype=vod&genre=all&WeekDay=all&uitype=VN500&uiparent=GN51-VN500&uirank=5&broadcastid=127431&offset=0&limit=20&uicode=VN500','page':'1','icon':'hot.png'},{'title':'인기 드라마','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4','page':'1','icon':''},{'title':'인기 예능','mode':'PROGRAM_LIST','subapi':'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3','page':'1','icon':''},{'title':'분류별 - VOD 방송  - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'1','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 해외시리즈 - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'viewtime','ordernm':'인기순','icon':''},{'title':'분류별 - 해외시리즈 - 최신순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'2','sType':'vod','orderby':'new','ordernm':'최신순','icon':''},{'title':'분류별 - 영화(Movie) - 인기순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'paid','ordernm':'인기순','icon':''},{'title':'분류별 - 영화(Movie) - 업데이트순','mode':'MAIN_CATAGORY','sCode':'GN52','sIndex':'3','sType':'movie','orderby':'displaystart','ordernm':'업데이트순','icon':''},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH_GROUP','icon':'history.png'},{'title':'(웨이브) 검색','mode':'SEARCH_GROUP','icon':'search.png'},{'title':'(웨이브) 검색기록','mode':'SEARCH_HISTORY','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','icon':'search_history.png'}]
BwzXoRQOlGWfDYmbcCLesjrpFUEVkK=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','sType':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','sType':'movie'}]
BwzXoRQOlGWfDYmbcCLesjrpFUEVkM=[{'title':'VOD 시청내역','mode':'WATCH_LIST','sType':'vod'},{'title':'영화 시청내역','mode':'WATCH_LIST','sType':'movie'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
BwzXoRQOlGWfDYmbcCLesjrpFUEVku =xbmcvfs.translatePath(os.path.join(__profile__,'wavve_cookies.json'))
BwzXoRQOlGWfDYmbcCLesjrpFUEVkN=xbmcvfs.translatePath(os.path.join(__profile__,'wavve_searched.txt'))
from wavveCore import*
class BwzXoRQOlGWfDYmbcCLesjrpFUEVkP(BwzXoRQOlGWfDYmbcCLesjrpFUEVuA):
 def __init__(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,BwzXoRQOlGWfDYmbcCLesjrpFUEVkv,BwzXoRQOlGWfDYmbcCLesjrpFUEVkn,BwzXoRQOlGWfDYmbcCLesjrpFUEVkh):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_url =BwzXoRQOlGWfDYmbcCLesjrpFUEVkv
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle=BwzXoRQOlGWfDYmbcCLesjrpFUEVkn
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params =BwzXoRQOlGWfDYmbcCLesjrpFUEVkh
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj =AwERGhgecFkLrxHNTulqCdtPvaypUW() 
 def addon_noti(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,sting):
  try:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkI=xbmcgui.Dialog()
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkI.notification(__addonname__,sting)
  except:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVuH
 def addon_log(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,string):
  try:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVki=string.encode('utf-8','ignore')
  except:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVki='addonException: addon_log'
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkA=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,BwzXoRQOlGWfDYmbcCLesjrpFUEVki),level=BwzXoRQOlGWfDYmbcCLesjrpFUEVkA)
 def get_keyboard_input(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,BwzXoRQOlGWfDYmbcCLesjrpFUEVPt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkH=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH
  kb=xbmc.Keyboard()
  kb.setHeading(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkH=kb.getText()
  return BwzXoRQOlGWfDYmbcCLesjrpFUEVkH
 def get_settings_login_info(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkT =__addon__.getSetting('id')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVka =__addon__.getSetting('pw')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkx=__addon__.getSetting('selected_profile')
  return(BwzXoRQOlGWfDYmbcCLesjrpFUEVkT,BwzXoRQOlGWfDYmbcCLesjrpFUEVka,BwzXoRQOlGWfDYmbcCLesjrpFUEVkx)
 def get_settings_totalsearch(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkJ =BwzXoRQOlGWfDYmbcCLesjrpFUEVuT if __addon__.getSetting('local_search')=='true' else BwzXoRQOlGWfDYmbcCLesjrpFUEVua
  BwzXoRQOlGWfDYmbcCLesjrpFUEVky=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT if __addon__.getSetting('local_history')=='true' else BwzXoRQOlGWfDYmbcCLesjrpFUEVua
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkS =BwzXoRQOlGWfDYmbcCLesjrpFUEVuT if __addon__.getSetting('total_search')=='true' else BwzXoRQOlGWfDYmbcCLesjrpFUEVua
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkg=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT if __addon__.getSetting('total_history')=='true' else BwzXoRQOlGWfDYmbcCLesjrpFUEVua
  return(BwzXoRQOlGWfDYmbcCLesjrpFUEVkJ,BwzXoRQOlGWfDYmbcCLesjrpFUEVky,BwzXoRQOlGWfDYmbcCLesjrpFUEVkS,BwzXoRQOlGWfDYmbcCLesjrpFUEVkg)
 def get_selQuality(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  try:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPk=[1080,720,480,360]
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPq=BwzXoRQOlGWfDYmbcCLesjrpFUEVux(__addon__.getSetting('selected_quality'))
   return BwzXoRQOlGWfDYmbcCLesjrpFUEVPk[BwzXoRQOlGWfDYmbcCLesjrpFUEVPq]
  except:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVuH
  return 1080 
 def get_settings_exclusion21(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPK =__addon__.getSetting('exclusion21')
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVPK=='false':
   return BwzXoRQOlGWfDYmbcCLesjrpFUEVua
  else:
   return BwzXoRQOlGWfDYmbcCLesjrpFUEVuT
 def get_settings_direct_replay(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPM=BwzXoRQOlGWfDYmbcCLesjrpFUEVux(__addon__.getSetting('direct_replay'))
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVPM==0:
   return BwzXoRQOlGWfDYmbcCLesjrpFUEVua
  else:
   return BwzXoRQOlGWfDYmbcCLesjrpFUEVuT
 def set_winCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,credential):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu=xbmcgui.Window(10000)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu.setProperty('WAVVE_M_CREDENTIAL',credential)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu.setProperty('WAVVE_M_LOGINTIME',BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu=xbmcgui.Window(10000)
  return BwzXoRQOlGWfDYmbcCLesjrpFUEVPu.getProperty('WAVVE_M_CREDENTIAL')
 def set_winEpisodeOrderby(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,BwzXoRQOlGWfDYmbcCLesjrpFUEVKy):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu=xbmcgui.Window(10000)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu.setProperty('WAVVE_M_ORDERBY',BwzXoRQOlGWfDYmbcCLesjrpFUEVKy)
 def get_winEpisodeOrderby(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu=xbmcgui.Window(10000)
  return BwzXoRQOlGWfDYmbcCLesjrpFUEVPu.getProperty('WAVVE_M_ORDERBY')
 def add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,label,sublabel='',img='',infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params='',isLink=BwzXoRQOlGWfDYmbcCLesjrpFUEVua,ContextMenu=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPN='%s?%s'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_url,urllib.parse.urlencode(params))
  if sublabel:BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='%s < %s >'%(label,sublabel)
  else: BwzXoRQOlGWfDYmbcCLesjrpFUEVPt=label
  if not img:img='DefaultFolder.png'
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPv=xbmcgui.ListItem(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuJ(img)==BwzXoRQOlGWfDYmbcCLesjrpFUEVuy:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPv.setArt(img)
  else:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPv.setArt({'thumb':img,'poster':img})
  if infoLabels:BwzXoRQOlGWfDYmbcCLesjrpFUEVPv.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPv.setProperty('IsPlayable','true')
  if ContextMenu:BwzXoRQOlGWfDYmbcCLesjrpFUEVPv.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,BwzXoRQOlGWfDYmbcCLesjrpFUEVPN,BwzXoRQOlGWfDYmbcCLesjrpFUEVPv,isFolder)
 def dp_Main_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  (BwzXoRQOlGWfDYmbcCLesjrpFUEVkJ,BwzXoRQOlGWfDYmbcCLesjrpFUEVky,BwzXoRQOlGWfDYmbcCLesjrpFUEVkS,BwzXoRQOlGWfDYmbcCLesjrpFUEVkg)=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_settings_totalsearch()
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVPn in BwzXoRQOlGWfDYmbcCLesjrpFUEVkq:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt=BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('title')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPh=''
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('mode')=='SEARCH_GROUP' and BwzXoRQOlGWfDYmbcCLesjrpFUEVkJ ==BwzXoRQOlGWfDYmbcCLesjrpFUEVua:continue
   elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('mode')=='SEARCH_HISTORY' and BwzXoRQOlGWfDYmbcCLesjrpFUEVky==BwzXoRQOlGWfDYmbcCLesjrpFUEVua:continue
   elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('mode')=='TOTAL_SEARCH' and BwzXoRQOlGWfDYmbcCLesjrpFUEVkS ==BwzXoRQOlGWfDYmbcCLesjrpFUEVua:continue
   elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('mode')=='TOTAL_HISTORY' and BwzXoRQOlGWfDYmbcCLesjrpFUEVkg==BwzXoRQOlGWfDYmbcCLesjrpFUEVua:continue
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('mode'),'sCode':BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('sCode'),'sIndex':BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('sIndex'),'sType':BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('sType'),'suburl':BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('suburl'),'subapi':BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('subapi'),'page':BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('page'),'orderby':BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('orderby'),'ordernm':BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('ordernm')}
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY']:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPI=BwzXoRQOlGWfDYmbcCLesjrpFUEVua
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPi =BwzXoRQOlGWfDYmbcCLesjrpFUEVuT
   else:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPI=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPi =BwzXoRQOlGWfDYmbcCLesjrpFUEVua
   if 'icon' in BwzXoRQOlGWfDYmbcCLesjrpFUEVPn:BwzXoRQOlGWfDYmbcCLesjrpFUEVPh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',BwzXoRQOlGWfDYmbcCLesjrpFUEVPn.get('icon')) 
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img=BwzXoRQOlGWfDYmbcCLesjrpFUEVPh,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVPI,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd,isLink=BwzXoRQOlGWfDYmbcCLesjrpFUEVPi)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVkq)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT)
 def dp_Search_Group(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  if 'search_key' in args:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPH=args.get('search_key')
  else:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPH=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not BwzXoRQOlGWfDYmbcCLesjrpFUEVPH:
    return
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVPT in BwzXoRQOlGWfDYmbcCLesjrpFUEVkK:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPa =BwzXoRQOlGWfDYmbcCLesjrpFUEVPT.get('mode')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPx=BwzXoRQOlGWfDYmbcCLesjrpFUEVPT.get('sType')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt=BwzXoRQOlGWfDYmbcCLesjrpFUEVPT.get('title')
   (BwzXoRQOlGWfDYmbcCLesjrpFUEVPJ,BwzXoRQOlGWfDYmbcCLesjrpFUEVPy)=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_Search_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVPH,BwzXoRQOlGWfDYmbcCLesjrpFUEVPx,1,exclusion21=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_settings_exclusion21())
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPS={'plot':'검색어 : '+BwzXoRQOlGWfDYmbcCLesjrpFUEVPH+'\n\n'+BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.Search_FreeList(BwzXoRQOlGWfDYmbcCLesjrpFUEVPJ)}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':BwzXoRQOlGWfDYmbcCLesjrpFUEVPa,'sType':BwzXoRQOlGWfDYmbcCLesjrpFUEVPx,'search_key':BwzXoRQOlGWfDYmbcCLesjrpFUEVPH,'page':'1',}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img='',infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVPS,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVkK)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.Save_Searched_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVPH)
 def Search_FreeList(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,search_list):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPg=''
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqk=7
  try:
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(search_list)==0:return '검색결과 없음'
   for i in BwzXoRQOlGWfDYmbcCLesjrpFUEVug(BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(search_list)):
    if i>=BwzXoRQOlGWfDYmbcCLesjrpFUEVqk:
     BwzXoRQOlGWfDYmbcCLesjrpFUEVPg=BwzXoRQOlGWfDYmbcCLesjrpFUEVPg+'...'
     break
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPg=BwzXoRQOlGWfDYmbcCLesjrpFUEVPg+search_list[i]['title']+'\n'
  except:
   return ''
  return BwzXoRQOlGWfDYmbcCLesjrpFUEVPg
 def dp_Watch_Group(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqP in BwzXoRQOlGWfDYmbcCLesjrpFUEVkM:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt=BwzXoRQOlGWfDYmbcCLesjrpFUEVqP.get('title')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':BwzXoRQOlGWfDYmbcCLesjrpFUEVqP.get('mode'),'sType':BwzXoRQOlGWfDYmbcCLesjrpFUEVqP.get('sType')}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img='',infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVkM)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT)
 def dp_Search_History(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqK=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.Load_List_File('search')
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqM in BwzXoRQOlGWfDYmbcCLesjrpFUEVqK:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqu=BwzXoRQOlGWfDYmbcCLesjrpFUEVuy(urllib.parse.parse_qsl(BwzXoRQOlGWfDYmbcCLesjrpFUEVqM))
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqN=BwzXoRQOlGWfDYmbcCLesjrpFUEVqu.get('skey').strip()
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'SEARCH_GROUP','search_key':BwzXoRQOlGWfDYmbcCLesjrpFUEVqN,}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqt={'mode':'SEARCH_REMOVE','sType':'ONE','skey':BwzXoRQOlGWfDYmbcCLesjrpFUEVqN,}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqv=urllib.parse.urlencode(BwzXoRQOlGWfDYmbcCLesjrpFUEVqt)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqn=[('선택된 검색어 ( %s ) 삭제'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVqN),'RunPlugin(plugin://plugin.video.wavvem/?%s)'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVqv))]
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVqN,sublabel='',img=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd,ContextMenu=BwzXoRQOlGWfDYmbcCLesjrpFUEVqn)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'plot':'검색목록 전체를 삭제합니다.'}
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='*** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) ***'
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'SEARCH_REMOVE','sType':'ALL','skey':'-',}
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img=BwzXoRQOlGWfDYmbcCLesjrpFUEVPh,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVua,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd,isLink=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT)
  xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def dp_Search_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.SaveCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPx =args.get('sType')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqI =BwzXoRQOlGWfDYmbcCLesjrpFUEVux(args.get('page'))
  if 'search_key' in args:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPH=args.get('search_key')
  else:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPH=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not BwzXoRQOlGWfDYmbcCLesjrpFUEVPH:
    xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle)
    return
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqi,BwzXoRQOlGWfDYmbcCLesjrpFUEVPy=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_Search_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVPH,BwzXoRQOlGWfDYmbcCLesjrpFUEVPx,BwzXoRQOlGWfDYmbcCLesjrpFUEVqI,exclusion21=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_settings_exclusion21())
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqA in BwzXoRQOlGWfDYmbcCLesjrpFUEVqi:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('title')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqH=BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('thumbnail')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqT =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('age')
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVqT=='18' or BwzXoRQOlGWfDYmbcCLesjrpFUEVqT=='19' or BwzXoRQOlGWfDYmbcCLesjrpFUEVqT=='21':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt+=' (%s)'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVqT)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'mediatype':'tvshow' if BwzXoRQOlGWfDYmbcCLesjrpFUEVPx=='vod' else 'movie','mpaa':BwzXoRQOlGWfDYmbcCLesjrpFUEVqT,'title':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,'plot':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt}
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVPx=='vod':
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'EPISODE_LIST','videoid':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('videoid'),'vidtype':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('vidtype'),'page':'1'}
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPI=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT
   else:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'MOVIE','contentid':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('videoid'),'title':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,'thumbnail':BwzXoRQOlGWfDYmbcCLesjrpFUEVqH,'age':BwzXoRQOlGWfDYmbcCLesjrpFUEVqT}
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPI=BwzXoRQOlGWfDYmbcCLesjrpFUEVua
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img=BwzXoRQOlGWfDYmbcCLesjrpFUEVqH,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVPI,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVPy:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['mode'] ='SEARCH_LIST' 
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['sType']=BwzXoRQOlGWfDYmbcCLesjrpFUEVPx 
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['page'] =BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['search_key']=BwzXoRQOlGWfDYmbcCLesjrpFUEVPH
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='[B]%s >>[/B]'%'다음 페이지'
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqa=BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel=BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,img=BwzXoRQOlGWfDYmbcCLesjrpFUEVPh,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def dp_Watch_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPx =args.get('sType')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPM=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_settings_direct_replay()
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqi=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.Load_List_File(BwzXoRQOlGWfDYmbcCLesjrpFUEVPx)
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqA in BwzXoRQOlGWfDYmbcCLesjrpFUEVqi:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqu=BwzXoRQOlGWfDYmbcCLesjrpFUEVuy(urllib.parse.parse_qsl(BwzXoRQOlGWfDYmbcCLesjrpFUEVqA))
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqx =BwzXoRQOlGWfDYmbcCLesjrpFUEVqu.get('code').strip()
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt =BwzXoRQOlGWfDYmbcCLesjrpFUEVqu.get('title').strip()
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqa =BwzXoRQOlGWfDYmbcCLesjrpFUEVqu.get('subtitle').strip()
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVqa=='None':BwzXoRQOlGWfDYmbcCLesjrpFUEVqa=''
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqH=BwzXoRQOlGWfDYmbcCLesjrpFUEVqu.get('img').strip()
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqJ =BwzXoRQOlGWfDYmbcCLesjrpFUEVqu.get('videoid').strip()
   try:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVqH=BwzXoRQOlGWfDYmbcCLesjrpFUEVqH.replace('\'','\"')
    BwzXoRQOlGWfDYmbcCLesjrpFUEVqH=json.loads(BwzXoRQOlGWfDYmbcCLesjrpFUEVqH)
   except:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVuH
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'plot':'%s\n%s'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,BwzXoRQOlGWfDYmbcCLesjrpFUEVqa)}
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVPx=='vod':
    if BwzXoRQOlGWfDYmbcCLesjrpFUEVPM==BwzXoRQOlGWfDYmbcCLesjrpFUEVua or BwzXoRQOlGWfDYmbcCLesjrpFUEVqJ==BwzXoRQOlGWfDYmbcCLesjrpFUEVuH:
     BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'EPISODE_LIST','videoid':BwzXoRQOlGWfDYmbcCLesjrpFUEVqx,'vidtype':'programid','page':'1'}
     BwzXoRQOlGWfDYmbcCLesjrpFUEVPI=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT
    else:
     BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'VOD','programid':BwzXoRQOlGWfDYmbcCLesjrpFUEVqx,'contentid':BwzXoRQOlGWfDYmbcCLesjrpFUEVqJ,'title':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,'subtitle':BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,'thumbnail':BwzXoRQOlGWfDYmbcCLesjrpFUEVqH}
     BwzXoRQOlGWfDYmbcCLesjrpFUEVPI=BwzXoRQOlGWfDYmbcCLesjrpFUEVua
   else:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'MOVIE','contentid':BwzXoRQOlGWfDYmbcCLesjrpFUEVqx,'title':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,'subtitle':BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,'thumbnail':BwzXoRQOlGWfDYmbcCLesjrpFUEVqH}
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPI=BwzXoRQOlGWfDYmbcCLesjrpFUEVua
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel=BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,img=BwzXoRQOlGWfDYmbcCLesjrpFUEVqH,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVPI,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'plot':'시청목록을 삭제합니다.'}
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='*** 시청목록 삭제 ***'
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'MYVIEW_REMOVE','sType':BwzXoRQOlGWfDYmbcCLesjrpFUEVPx,'skey':'-',}
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img=BwzXoRQOlGWfDYmbcCLesjrpFUEVPh,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVua,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd,isLink=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT)
  xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def Load_List_File(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,BwzXoRQOlGWfDYmbcCLesjrpFUEVKn): 
  try:
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVKn=='search':
    BwzXoRQOlGWfDYmbcCLesjrpFUEVqy=BwzXoRQOlGWfDYmbcCLesjrpFUEVkN
   elif BwzXoRQOlGWfDYmbcCLesjrpFUEVKn in['vod','movie']:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVqy=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BwzXoRQOlGWfDYmbcCLesjrpFUEVKn))
   else:
    return[]
   fp=BwzXoRQOlGWfDYmbcCLesjrpFUEVNP(BwzXoRQOlGWfDYmbcCLesjrpFUEVqy,'r',-1,'utf-8')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqS=fp.readlines()
   fp.close()
  except:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqS=[]
  return BwzXoRQOlGWfDYmbcCLesjrpFUEVqS
 def Save_Watched_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,BwzXoRQOlGWfDYmbcCLesjrpFUEVuI,BwzXoRQOlGWfDYmbcCLesjrpFUEVkh):
  try:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BwzXoRQOlGWfDYmbcCLesjrpFUEVuI))
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKk=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.Load_List_File(BwzXoRQOlGWfDYmbcCLesjrpFUEVuI) 
   fp=BwzXoRQOlGWfDYmbcCLesjrpFUEVNP(BwzXoRQOlGWfDYmbcCLesjrpFUEVqg,'w',-1,'utf-8')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKP=urllib.parse.urlencode(BwzXoRQOlGWfDYmbcCLesjrpFUEVkh)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKP=BwzXoRQOlGWfDYmbcCLesjrpFUEVKP+'\n'
   fp.write(BwzXoRQOlGWfDYmbcCLesjrpFUEVKP)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKq=0
   for BwzXoRQOlGWfDYmbcCLesjrpFUEVKM in BwzXoRQOlGWfDYmbcCLesjrpFUEVKk:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVKu=BwzXoRQOlGWfDYmbcCLesjrpFUEVuy(urllib.parse.parse_qsl(BwzXoRQOlGWfDYmbcCLesjrpFUEVKM))
    BwzXoRQOlGWfDYmbcCLesjrpFUEVKN=BwzXoRQOlGWfDYmbcCLesjrpFUEVkh.get('code').strip()
    BwzXoRQOlGWfDYmbcCLesjrpFUEVKt=BwzXoRQOlGWfDYmbcCLesjrpFUEVKu.get('code').strip()
    if BwzXoRQOlGWfDYmbcCLesjrpFUEVuI=='vod' and BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_settings_direct_replay()==BwzXoRQOlGWfDYmbcCLesjrpFUEVuT:
     BwzXoRQOlGWfDYmbcCLesjrpFUEVKN=BwzXoRQOlGWfDYmbcCLesjrpFUEVkh.get('videoid').strip()
     BwzXoRQOlGWfDYmbcCLesjrpFUEVKt=BwzXoRQOlGWfDYmbcCLesjrpFUEVKu.get('videoid').strip()if BwzXoRQOlGWfDYmbcCLesjrpFUEVKt!=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH else '-'
    if BwzXoRQOlGWfDYmbcCLesjrpFUEVKN!=BwzXoRQOlGWfDYmbcCLesjrpFUEVKt:
     fp.write(BwzXoRQOlGWfDYmbcCLesjrpFUEVKM)
     BwzXoRQOlGWfDYmbcCLesjrpFUEVKq+=1
     if BwzXoRQOlGWfDYmbcCLesjrpFUEVKq>=50:break
   fp.close()
  except:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVuH
 def Delete_List_File(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,BwzXoRQOlGWfDYmbcCLesjrpFUEVKn,skey='-'):
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVKn=='ALL':
   try:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVqy=BwzXoRQOlGWfDYmbcCLesjrpFUEVkN
    fp=BwzXoRQOlGWfDYmbcCLesjrpFUEVNP(BwzXoRQOlGWfDYmbcCLesjrpFUEVqy,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVuH
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVKn=='ONE':
   try:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVqy=BwzXoRQOlGWfDYmbcCLesjrpFUEVkN
    BwzXoRQOlGWfDYmbcCLesjrpFUEVKk=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.Load_List_File('search') 
    fp=BwzXoRQOlGWfDYmbcCLesjrpFUEVNP(BwzXoRQOlGWfDYmbcCLesjrpFUEVqy,'w',-1,'utf-8')
    for BwzXoRQOlGWfDYmbcCLesjrpFUEVKM in BwzXoRQOlGWfDYmbcCLesjrpFUEVKk:
     BwzXoRQOlGWfDYmbcCLesjrpFUEVKu=BwzXoRQOlGWfDYmbcCLesjrpFUEVuy(urllib.parse.parse_qsl(BwzXoRQOlGWfDYmbcCLesjrpFUEVKM))
     BwzXoRQOlGWfDYmbcCLesjrpFUEVKv=BwzXoRQOlGWfDYmbcCLesjrpFUEVKu.get('skey').strip()
     if skey!=BwzXoRQOlGWfDYmbcCLesjrpFUEVKv:
      fp.write(BwzXoRQOlGWfDYmbcCLesjrpFUEVKM)
    fp.close()
   except:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVuH
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVKn in['vod','movie']:
   try:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVqy=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BwzXoRQOlGWfDYmbcCLesjrpFUEVKn))
    fp=BwzXoRQOlGWfDYmbcCLesjrpFUEVNP(BwzXoRQOlGWfDYmbcCLesjrpFUEVqy,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVuH
 def dp_Listfile_Delete(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKn=args.get('sType')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqN =args.get('skey')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkI=xbmcgui.Dialog()
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVKn=='ALL':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKh=BwzXoRQOlGWfDYmbcCLesjrpFUEVkI.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVKn=='ONE':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKh=BwzXoRQOlGWfDYmbcCLesjrpFUEVkI.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVKn in['vod','movie']:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKh=BwzXoRQOlGWfDYmbcCLesjrpFUEVkI.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVKh==BwzXoRQOlGWfDYmbcCLesjrpFUEVua:sys.exit()
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.Delete_List_File(BwzXoRQOlGWfDYmbcCLesjrpFUEVKn,skey=BwzXoRQOlGWfDYmbcCLesjrpFUEVqN)
  xbmc.executebuiltin("Container.Refresh")
 def Save_Searched_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,BwzXoRQOlGWfDYmbcCLesjrpFUEVPH):
  try:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKd=BwzXoRQOlGWfDYmbcCLesjrpFUEVkN
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKk=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.Load_List_File('search') 
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKI={'skey':BwzXoRQOlGWfDYmbcCLesjrpFUEVPH.strip()}
   fp=BwzXoRQOlGWfDYmbcCLesjrpFUEVNP(BwzXoRQOlGWfDYmbcCLesjrpFUEVKd,'w',-1,'utf-8')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKP=urllib.parse.urlencode(BwzXoRQOlGWfDYmbcCLesjrpFUEVKI)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKP=BwzXoRQOlGWfDYmbcCLesjrpFUEVKP+'\n'
   fp.write(BwzXoRQOlGWfDYmbcCLesjrpFUEVKP)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKq=0
   for BwzXoRQOlGWfDYmbcCLesjrpFUEVKM in BwzXoRQOlGWfDYmbcCLesjrpFUEVKk:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVKu=BwzXoRQOlGWfDYmbcCLesjrpFUEVuy(urllib.parse.parse_qsl(BwzXoRQOlGWfDYmbcCLesjrpFUEVKM))
    BwzXoRQOlGWfDYmbcCLesjrpFUEVKN=BwzXoRQOlGWfDYmbcCLesjrpFUEVKI.get('skey').strip()
    BwzXoRQOlGWfDYmbcCLesjrpFUEVKt=BwzXoRQOlGWfDYmbcCLesjrpFUEVKu.get('skey').strip()
    if BwzXoRQOlGWfDYmbcCLesjrpFUEVKN!=BwzXoRQOlGWfDYmbcCLesjrpFUEVKt:
     fp.write(BwzXoRQOlGWfDYmbcCLesjrpFUEVKM)
     BwzXoRQOlGWfDYmbcCLesjrpFUEVKq+=1
     if BwzXoRQOlGWfDYmbcCLesjrpFUEVKq>=50:break
   fp.close()
  except:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVuH
 def dp_Global_Search(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=args.get('mode')
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='TOTAL_SEARCH':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKi='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKi='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(BwzXoRQOlGWfDYmbcCLesjrpFUEVKi)
 def login_main(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  (BwzXoRQOlGWfDYmbcCLesjrpFUEVKA,BwzXoRQOlGWfDYmbcCLesjrpFUEVKH,BwzXoRQOlGWfDYmbcCLesjrpFUEVKT)=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_settings_login_info()
  if not(BwzXoRQOlGWfDYmbcCLesjrpFUEVKA and BwzXoRQOlGWfDYmbcCLesjrpFUEVKH):
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkI=xbmcgui.Dialog()
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKh=BwzXoRQOlGWfDYmbcCLesjrpFUEVkI.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVKh==BwzXoRQOlGWfDYmbcCLesjrpFUEVuT:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winEpisodeOrderby()=='':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.set_winEpisodeOrderby('desc')
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.cookiefile_check():return
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKa =BwzXoRQOlGWfDYmbcCLesjrpFUEVux(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKx=xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINTIME')
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVKx==BwzXoRQOlGWfDYmbcCLesjrpFUEVuH or BwzXoRQOlGWfDYmbcCLesjrpFUEVKx=='':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKx=BwzXoRQOlGWfDYmbcCLesjrpFUEVux('19000101')
  else:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKx=BwzXoRQOlGWfDYmbcCLesjrpFUEVux(re.sub('-','',BwzXoRQOlGWfDYmbcCLesjrpFUEVKx))
  if xbmcgui.Window(10000).getProperty('WAVVE_M_LOGINWAIT')=='TRUE':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVKJ=0
   while BwzXoRQOlGWfDYmbcCLesjrpFUEVuT:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVKJ+=1
    time.sleep(0.05)
    if BwzXoRQOlGWfDYmbcCLesjrpFUEVKx>=BwzXoRQOlGWfDYmbcCLesjrpFUEVKa:return
    if BwzXoRQOlGWfDYmbcCLesjrpFUEVKJ>600:return
  else:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','TRUE')
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVKx>=BwzXoRQOlGWfDYmbcCLesjrpFUEVKa:
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   return
  if not BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.GetCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVKA,BwzXoRQOlGWfDYmbcCLesjrpFUEVKH,BwzXoRQOlGWfDYmbcCLesjrpFUEVKT):
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
   sys.exit()
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.set_winCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.LoadCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WAVVE_M_LOGINWAIT','FALSE')
 def dp_setEpOrderby(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKy =args.get('orderby')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.set_winEpisodeOrderby(BwzXoRQOlGWfDYmbcCLesjrpFUEVKy)
  xbmc.executebuiltin("Container.Refresh")
 def play_VIDEO(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.SaveCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPa =args.get('mode')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKS =args.get('contentid')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKg =args.get('pvrmode')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMk=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_selQuality()
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.addon_log(BwzXoRQOlGWfDYmbcCLesjrpFUEVKS+' - '+BwzXoRQOlGWfDYmbcCLesjrpFUEVPa)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMP,BwzXoRQOlGWfDYmbcCLesjrpFUEVMq,BwzXoRQOlGWfDYmbcCLesjrpFUEVMK,BwzXoRQOlGWfDYmbcCLesjrpFUEVMu=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.GetStreamingURL(BwzXoRQOlGWfDYmbcCLesjrpFUEVPa,BwzXoRQOlGWfDYmbcCLesjrpFUEVKS,BwzXoRQOlGWfDYmbcCLesjrpFUEVMk,BwzXoRQOlGWfDYmbcCLesjrpFUEVKg)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMN='%s|Cookie=%s'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVMP,BwzXoRQOlGWfDYmbcCLesjrpFUEVMq)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.addon_log(BwzXoRQOlGWfDYmbcCLesjrpFUEVMN)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVMP=='':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.addon_noti(__language__(30907).encode('utf8'))
   return
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMt=xbmcgui.ListItem(path=BwzXoRQOlGWfDYmbcCLesjrpFUEVMN)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVMK:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.addon_log('!!streaming_drm!!')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVMv=BwzXoRQOlGWfDYmbcCLesjrpFUEVMK['customdata']
   BwzXoRQOlGWfDYmbcCLesjrpFUEVMn =BwzXoRQOlGWfDYmbcCLesjrpFUEVMK['drmhost']
   BwzXoRQOlGWfDYmbcCLesjrpFUEVMh =inputstreamhelper.Helper('mpd',drm='widevine')
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVMh.check_inputstream():
    if BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='MOVIE':
     BwzXoRQOlGWfDYmbcCLesjrpFUEVMd='https://www.wavve.com/player/movie?movieid=%s'%BwzXoRQOlGWfDYmbcCLesjrpFUEVKS
    else:
     BwzXoRQOlGWfDYmbcCLesjrpFUEVMd='https://www.wavve.com/player/vod?programid=%s&page=1'%BwzXoRQOlGWfDYmbcCLesjrpFUEVKS
    BwzXoRQOlGWfDYmbcCLesjrpFUEVMI={'content-type':'application/octet-stream','origin':'https://www.wavve.com','pallycon-customdata':BwzXoRQOlGWfDYmbcCLesjrpFUEVMv,'referer':BwzXoRQOlGWfDYmbcCLesjrpFUEVMd,'sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.USER_AGENT}
    BwzXoRQOlGWfDYmbcCLesjrpFUEVMi=BwzXoRQOlGWfDYmbcCLesjrpFUEVMn+'|'+urllib.parse.urlencode(BwzXoRQOlGWfDYmbcCLesjrpFUEVMI)+'|R{SSM}|'
    BwzXoRQOlGWfDYmbcCLesjrpFUEVMt.setProperty('inputstream',BwzXoRQOlGWfDYmbcCLesjrpFUEVMh.inputstream_addon)
    BwzXoRQOlGWfDYmbcCLesjrpFUEVMt.setProperty('inputstream.adaptive.manifest_type','mpd')
    BwzXoRQOlGWfDYmbcCLesjrpFUEVMt.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
    BwzXoRQOlGWfDYmbcCLesjrpFUEVMt.setProperty('inputstream.adaptive.license_key',BwzXoRQOlGWfDYmbcCLesjrpFUEVMi)
    BwzXoRQOlGWfDYmbcCLesjrpFUEVMt.setProperty('inputstream.adaptive.stream_headers','user-agent=%s&Cookie=%s'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.USER_AGENT,BwzXoRQOlGWfDYmbcCLesjrpFUEVMq))
  xbmcplugin.setResolvedUrl(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,BwzXoRQOlGWfDYmbcCLesjrpFUEVMt)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMA=BwzXoRQOlGWfDYmbcCLesjrpFUEVua
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVMu:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.addon_noti(BwzXoRQOlGWfDYmbcCLesjrpFUEVMu.encode('utf-8'))
   BwzXoRQOlGWfDYmbcCLesjrpFUEVMA=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT
  else:
   if '/preview.' in urllib.parse.urlsplit(BwzXoRQOlGWfDYmbcCLesjrpFUEVMP).path:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.addon_noti(__language__(30908).encode('utf8'))
    BwzXoRQOlGWfDYmbcCLesjrpFUEVMA=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT
  try:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVMH=args.get('programid')if args.get('mode')=='VOD' else args.get('contentid')
   if args.get('mode')in['VOD','MOVIE']and args.get('title')and args.get('age')!='21' and BwzXoRQOlGWfDYmbcCLesjrpFUEVMA==BwzXoRQOlGWfDYmbcCLesjrpFUEVua and BwzXoRQOlGWfDYmbcCLesjrpFUEVMH!='-':
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'code':BwzXoRQOlGWfDYmbcCLesjrpFUEVMH,'img':args.get('thumbnail'),'title':args.get('title'),'subtitle':args.get('subtitle'),'videoid':args.get('contentid')}
    BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.Save_Watched_List(args.get('mode').lower(),BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  except:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVuH
 def logout(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkI=xbmcgui.Dialog()
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKh=BwzXoRQOlGWfDYmbcCLesjrpFUEVkI.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVKh==BwzXoRQOlGWfDYmbcCLesjrpFUEVua:sys.exit()
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.wininfo_clear()
  if os.path.isfile(BwzXoRQOlGWfDYmbcCLesjrpFUEVku):os.remove(BwzXoRQOlGWfDYmbcCLesjrpFUEVku)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu=xbmcgui.Window(10000)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu.setProperty('WAVVE_M_CREDENTIAL','')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu.setProperty('WAVVE_M_LOGINTIME','')
 def cookiefile_save(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMT =BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_Now_Datetime()
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMa=BwzXoRQOlGWfDYmbcCLesjrpFUEVMT+datetime.timedelta(days=BwzXoRQOlGWfDYmbcCLesjrpFUEVux(__addon__.getSetting('cache_ttl')))
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu=xbmcgui.Window(10000)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMx={'wavve_token':BwzXoRQOlGWfDYmbcCLesjrpFUEVPu.getProperty('WAVVE_M_CREDENTIAL'),'wavve_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'wavve_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'wavve_profile':__addon__.getSetting('selected_profile'),'wavve_limitdate':BwzXoRQOlGWfDYmbcCLesjrpFUEVMa.strftime('%Y-%m-%d')}
  try: 
   fp=BwzXoRQOlGWfDYmbcCLesjrpFUEVNP(BwzXoRQOlGWfDYmbcCLesjrpFUEVku,'w',-1,'utf-8')
   json.dump(BwzXoRQOlGWfDYmbcCLesjrpFUEVMx,fp)
   fp.close()
  except BwzXoRQOlGWfDYmbcCLesjrpFUEVNq as exception:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVNK(exception)
 def cookiefile_check(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMx={}
  try: 
   fp=BwzXoRQOlGWfDYmbcCLesjrpFUEVNP(BwzXoRQOlGWfDYmbcCLesjrpFUEVku,'r',-1,'utf-8')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVMx= json.load(fp)
   fp.close()
  except BwzXoRQOlGWfDYmbcCLesjrpFUEVNq as exception:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.wininfo_clear()
   return BwzXoRQOlGWfDYmbcCLesjrpFUEVua
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKA =__addon__.getSetting('id')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKH =__addon__.getSetting('pw')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMJ =__addon__.getSetting('selected_profile')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMx['wavve_id']=base64.standard_b64decode(BwzXoRQOlGWfDYmbcCLesjrpFUEVMx['wavve_id']).decode('utf-8')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMx['wavve_pw']=base64.standard_b64decode(BwzXoRQOlGWfDYmbcCLesjrpFUEVMx['wavve_pw']).decode('utf-8')
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVKA!=BwzXoRQOlGWfDYmbcCLesjrpFUEVMx['wavve_id']or BwzXoRQOlGWfDYmbcCLesjrpFUEVKH!=BwzXoRQOlGWfDYmbcCLesjrpFUEVMx['wavve_pw']or BwzXoRQOlGWfDYmbcCLesjrpFUEVMJ!=BwzXoRQOlGWfDYmbcCLesjrpFUEVMx['wavve_profile']:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.wininfo_clear()
   return BwzXoRQOlGWfDYmbcCLesjrpFUEVua
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKa =BwzXoRQOlGWfDYmbcCLesjrpFUEVux(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_Now_Datetime().strftime('%Y%m%d'))
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMy=BwzXoRQOlGWfDYmbcCLesjrpFUEVMx['wavve_limitdate']
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKx =BwzXoRQOlGWfDYmbcCLesjrpFUEVux(re.sub('-','',BwzXoRQOlGWfDYmbcCLesjrpFUEVMy))
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVKx<BwzXoRQOlGWfDYmbcCLesjrpFUEVKa:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.wininfo_clear()
   return BwzXoRQOlGWfDYmbcCLesjrpFUEVua
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu=xbmcgui.Window(10000)
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu.setProperty('WAVVE_M_CREDENTIAL',BwzXoRQOlGWfDYmbcCLesjrpFUEVMx['wavve_token'])
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPu.setProperty('WAVVE_M_LOGINTIME',BwzXoRQOlGWfDYmbcCLesjrpFUEVMy)
  return BwzXoRQOlGWfDYmbcCLesjrpFUEVuT
 def dp_LiveCatagory_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.SaveCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMS =args.get('sCode')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMg=args.get('sIndex')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqi,BwzXoRQOlGWfDYmbcCLesjrpFUEVuk=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_LiveCatagory_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVMS,BwzXoRQOlGWfDYmbcCLesjrpFUEVMg)
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqA in BwzXoRQOlGWfDYmbcCLesjrpFUEVqi:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('title')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'LIVE_LIST','genre':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('genre'),'baseapi':BwzXoRQOlGWfDYmbcCLesjrpFUEVuk}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img='',infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVqi)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def dp_MainCatagory_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.SaveCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMS =args.get('sCode')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVMg=args.get('sIndex')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPx =args.get('sType')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqi=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_MainCatagory_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVMS,BwzXoRQOlGWfDYmbcCLesjrpFUEVMg)
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqA in BwzXoRQOlGWfDYmbcCLesjrpFUEVqi:
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVPx=='vod':
    if BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('subtype')=='catagory':
     BwzXoRQOlGWfDYmbcCLesjrpFUEVPa='PROGRAM_LIST'
    else:
     BwzXoRQOlGWfDYmbcCLesjrpFUEVPa='SUPERSECTION_LIST'
   elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPx=='movie':
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPa='MOVIE_LIST'
   else:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=''
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='%s (%s)'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('title'),args.get('ordernm'))
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':BwzXoRQOlGWfDYmbcCLesjrpFUEVPa,'suburl':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('suburl'),'subapi':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('subapi'),'page':'1','orderby':args.get('orderby')}
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_settings_exclusion21():
    if BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('title')=='성인' or BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('title')=='성인+':continue
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img='',infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVqi)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def dp_Program_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.SaveCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVuP =args.get('subapi')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqI=BwzXoRQOlGWfDYmbcCLesjrpFUEVux(args.get('page'))
  BwzXoRQOlGWfDYmbcCLesjrpFUEVKy =args.get('orderby')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqi,BwzXoRQOlGWfDYmbcCLesjrpFUEVPy=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_Program_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVuP,BwzXoRQOlGWfDYmbcCLesjrpFUEVqI,BwzXoRQOlGWfDYmbcCLesjrpFUEVKy)
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqA in BwzXoRQOlGWfDYmbcCLesjrpFUEVqi:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('title')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqH=BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('thumbnail')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqT =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('age')
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVqT=='18' or BwzXoRQOlGWfDYmbcCLesjrpFUEVqT=='19' or BwzXoRQOlGWfDYmbcCLesjrpFUEVqT=='21':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt+=' (%s)'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVqT)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'plot':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,'mpaa':BwzXoRQOlGWfDYmbcCLesjrpFUEVqT,'mediatype':'tvshow'}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'EPISODE_LIST','videoid':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('videoid'),'vidtype':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('vidtype'),'page':'1'}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img=BwzXoRQOlGWfDYmbcCLesjrpFUEVqH,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVPy:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['mode'] ='PROGRAM_LIST' 
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['subapi']=BwzXoRQOlGWfDYmbcCLesjrpFUEVuP 
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['page'] =BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='[B]%s >>[/B]'%'다음 페이지'
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqa=BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel=BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,img=BwzXoRQOlGWfDYmbcCLesjrpFUEVPh,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVqi)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def dp_SuperSection_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.SaveCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVuq =args.get('suburl')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqi=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_SuperMultiSection_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVuq)
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqA in BwzXoRQOlGWfDYmbcCLesjrpFUEVqi:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('title')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVuP =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('subapi')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVuK=BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('cell_type')
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVuP.find('mtype=svod')>=0 or BwzXoRQOlGWfDYmbcCLesjrpFUEVuP.find('mtype=ppv')>=0:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPa='MOVIE_LIST'
   elif BwzXoRQOlGWfDYmbcCLesjrpFUEVuK=='band_71':
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPa ='SUPERSECTION_LIST'
    (BwzXoRQOlGWfDYmbcCLesjrpFUEVuM,BwzXoRQOlGWfDYmbcCLesjrpFUEVuN)=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Baseapi_Parse(BwzXoRQOlGWfDYmbcCLesjrpFUEVuP)
    BwzXoRQOlGWfDYmbcCLesjrpFUEVuq=BwzXoRQOlGWfDYmbcCLesjrpFUEVuN.get('api')
    BwzXoRQOlGWfDYmbcCLesjrpFUEVuP=''
   elif BwzXoRQOlGWfDYmbcCLesjrpFUEVuK=='band_2':
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPa='BAND2SECTION_LIST'
   elif BwzXoRQOlGWfDYmbcCLesjrpFUEVuK=='band_live':
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPa='BANDLIVESECTION_LIST'
   elif re.search('themes/2\d{4}',BwzXoRQOlGWfDYmbcCLesjrpFUEVuP):
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPa='MOVIE_LIST'
   else:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPa='PROGRAM_LIST'
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'plot':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,'mediatype':'tvshow'}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':BwzXoRQOlGWfDYmbcCLesjrpFUEVPa,'suburl':BwzXoRQOlGWfDYmbcCLesjrpFUEVuq,'subapi':BwzXoRQOlGWfDYmbcCLesjrpFUEVuP,'page':'1'}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVqi)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def dp_BandLiveSection_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.SaveCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVuP =args.get('subapi')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqI=BwzXoRQOlGWfDYmbcCLesjrpFUEVux(args.get('page'))
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqi,BwzXoRQOlGWfDYmbcCLesjrpFUEVPy=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_BandLiveSection_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVuP,BwzXoRQOlGWfDYmbcCLesjrpFUEVqI)
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqA in BwzXoRQOlGWfDYmbcCLesjrpFUEVqi:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVut =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('channelid')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVuv =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('studio')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVun=BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('tvshowtitle')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqH =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('thumbnail')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqT =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('age')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'mediatype':'tvshow','mpaa':BwzXoRQOlGWfDYmbcCLesjrpFUEVqT,'title':'%s < %s >'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVuv,BwzXoRQOlGWfDYmbcCLesjrpFUEVun),'tvshowtitle':BwzXoRQOlGWfDYmbcCLesjrpFUEVun,'studio':BwzXoRQOlGWfDYmbcCLesjrpFUEVuv,'plot':BwzXoRQOlGWfDYmbcCLesjrpFUEVuv}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'LIVE','contentid':BwzXoRQOlGWfDYmbcCLesjrpFUEVut}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVuv,sublabel=BwzXoRQOlGWfDYmbcCLesjrpFUEVun,img=BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('thumbnail'),infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVua,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVPy:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['mode'] ='BANDLIVESECTION_LIST' 
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['subapi']=BwzXoRQOlGWfDYmbcCLesjrpFUEVuP
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['page'] =BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='[B]%s >>[/B]'%'다음 페이지'
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqa=BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel=BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,img=BwzXoRQOlGWfDYmbcCLesjrpFUEVPh,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVqi)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def dp_Band2Section_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.SaveCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVuP =args.get('subapi')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqI=BwzXoRQOlGWfDYmbcCLesjrpFUEVux(args.get('page'))
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqi,BwzXoRQOlGWfDYmbcCLesjrpFUEVPy=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_Band2Section_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVuP,BwzXoRQOlGWfDYmbcCLesjrpFUEVqI)
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqA in BwzXoRQOlGWfDYmbcCLesjrpFUEVqi:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('programtitle')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqa =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('episodetitle')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'plot':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt+'\n\n'+BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,'mpaa':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('age'),'mediatype':'episode'}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'VOD','programid':'-','contentid':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('videoid'),'thumbnail':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('thumbnail'),'title':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,'subtitle':BwzXoRQOlGWfDYmbcCLesjrpFUEVqa}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel=BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,img=BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('thumbnail'),infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVua,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVPy:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['mode'] ='BAND2SECTION_LIST' 
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['subapi']=BwzXoRQOlGWfDYmbcCLesjrpFUEVuP
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['page'] =BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='[B]%s >>[/B]'%'다음 페이지'
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqa=BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel=BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,img=BwzXoRQOlGWfDYmbcCLesjrpFUEVPh,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVqi)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def dp_Movie_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.SaveCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVuP =args.get('subapi')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqI=BwzXoRQOlGWfDYmbcCLesjrpFUEVux(args.get('page'))
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqi,BwzXoRQOlGWfDYmbcCLesjrpFUEVPy=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_Movie_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVuP,BwzXoRQOlGWfDYmbcCLesjrpFUEVqI)
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqA in BwzXoRQOlGWfDYmbcCLesjrpFUEVqi:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('title')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqH=BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('thumbnail')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqT =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('age')
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVqT=='18' or BwzXoRQOlGWfDYmbcCLesjrpFUEVqT=='19' or BwzXoRQOlGWfDYmbcCLesjrpFUEVqT=='21':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt+=' (%s)'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVqT)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'plot':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,'mpaa':BwzXoRQOlGWfDYmbcCLesjrpFUEVqT,'mediatype':'movie'}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'MOVIE','contentid':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('videoid'),'title':BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,'thumbnail':BwzXoRQOlGWfDYmbcCLesjrpFUEVqH,'age':BwzXoRQOlGWfDYmbcCLesjrpFUEVqT}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img=BwzXoRQOlGWfDYmbcCLesjrpFUEVqH,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVua,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVPy:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['mode'] ='MOVIE_LIST' 
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['subapi']=BwzXoRQOlGWfDYmbcCLesjrpFUEVuP 
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['page'] =BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='[B]%s >>[/B]'%'다음 페이지'
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqa=BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel=BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,img=BwzXoRQOlGWfDYmbcCLesjrpFUEVPh,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVqi)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def dp_Episode_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.SaveCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqJ =args.get('videoid')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVuh =args.get('vidtype')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqI=BwzXoRQOlGWfDYmbcCLesjrpFUEVux(args.get('page'))
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqi,BwzXoRQOlGWfDYmbcCLesjrpFUEVPy=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_Episode_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVqJ,BwzXoRQOlGWfDYmbcCLesjrpFUEVuh,BwzXoRQOlGWfDYmbcCLesjrpFUEVqI,orderby=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winEpisodeOrderby())
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqA in BwzXoRQOlGWfDYmbcCLesjrpFUEVqi:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqa='%s회, %s(%s)'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('episodenumber'),BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('releasedate'),BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('releaseweekday'))
   BwzXoRQOlGWfDYmbcCLesjrpFUEVud ='[%s]\n\n%s'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('episodetitle'),BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('synopsis'))
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'mediatype':'episode','title':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('programtitle'),'year':BwzXoRQOlGWfDYmbcCLesjrpFUEVux(BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('releasedate')[:4]),'aired':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('releasedate'),'mpaa':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('age'),'episode':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('episodenumber'),'duration':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('playtime'),'plot':BwzXoRQOlGWfDYmbcCLesjrpFUEVud,'cast':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('episodeactors')}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'VOD','programid':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('programid'),'contentid':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('contentid'),'thumbnail':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('thumbnail'),'title':BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('programtitle'),'subtitle':BwzXoRQOlGWfDYmbcCLesjrpFUEVqa}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('programtitle'),sublabel=BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,img=BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('thumbnail'),infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVua,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVqI==1:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'plot':'정렬순서를 변경합니다.'}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['mode'] ='ORDER_BY' 
   if BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winEpisodeOrderby()=='desc':
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='정렬순서변경 : 최신화부터 -> 1회부터'
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['orderby']='asc'
   else:
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='정렬순서변경 : 1회부터 -> 최신화부터'
    BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['orderby']='desc'
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel='',img=BwzXoRQOlGWfDYmbcCLesjrpFUEVPh,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVua,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd,isLink=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVPy:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['mode'] ='EPISODE_LIST' 
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['videoid']=BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('programid')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['vidtype']='programid'
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd['page'] =BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPt='[B]%s >>[/B]'%'다음 페이지'
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqa=BwzXoRQOlGWfDYmbcCLesjrpFUEVNk(BwzXoRQOlGWfDYmbcCLesjrpFUEVqI+1)
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPh=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVPt,sublabel=BwzXoRQOlGWfDYmbcCLesjrpFUEVqa,img=BwzXoRQOlGWfDYmbcCLesjrpFUEVPh,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVuH,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVuT,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVqi)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def dp_LiveChannel_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt,args):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.SaveCredential(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.get_winCredential())
  BwzXoRQOlGWfDYmbcCLesjrpFUEVuI =args.get('genre')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVuk=args.get('baseapi')
  BwzXoRQOlGWfDYmbcCLesjrpFUEVqi=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.WavveObj.Get_LiveChannel_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVuI,BwzXoRQOlGWfDYmbcCLesjrpFUEVuk)
  for BwzXoRQOlGWfDYmbcCLesjrpFUEVqA in BwzXoRQOlGWfDYmbcCLesjrpFUEVqi:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVut =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('channelid')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVuv =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('studio')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVun=BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('tvshowtitle')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqH =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('thumbnail')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqT =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('age')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVui =BwzXoRQOlGWfDYmbcCLesjrpFUEVqA.get('epg')
   BwzXoRQOlGWfDYmbcCLesjrpFUEVqh={'mediatype':'episode','mpaa':BwzXoRQOlGWfDYmbcCLesjrpFUEVqT,'title':'%s < %s >'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVuv,BwzXoRQOlGWfDYmbcCLesjrpFUEVun),'tvshowtitle':BwzXoRQOlGWfDYmbcCLesjrpFUEVun,'studio':BwzXoRQOlGWfDYmbcCLesjrpFUEVuv,'plot':'%s\n\n%s'%(BwzXoRQOlGWfDYmbcCLesjrpFUEVuv,BwzXoRQOlGWfDYmbcCLesjrpFUEVui)}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVPd={'mode':'LIVE','contentid':BwzXoRQOlGWfDYmbcCLesjrpFUEVut}
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.add_dir(BwzXoRQOlGWfDYmbcCLesjrpFUEVuv,sublabel=BwzXoRQOlGWfDYmbcCLesjrpFUEVun,img=BwzXoRQOlGWfDYmbcCLesjrpFUEVqH,infoLabels=BwzXoRQOlGWfDYmbcCLesjrpFUEVqh,isFolder=BwzXoRQOlGWfDYmbcCLesjrpFUEVua,params=BwzXoRQOlGWfDYmbcCLesjrpFUEVPd)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVuS(BwzXoRQOlGWfDYmbcCLesjrpFUEVqi)>0:xbmcplugin.endOfDirectory(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt._addon_handle,cacheToDisc=BwzXoRQOlGWfDYmbcCLesjrpFUEVua)
 def wavve_main(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt):
  BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params.get('mode',BwzXoRQOlGWfDYmbcCLesjrpFUEVuH)
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='LOGOUT':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.logout()
   return
  BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.login_main()
  if BwzXoRQOlGWfDYmbcCLesjrpFUEVPa is BwzXoRQOlGWfDYmbcCLesjrpFUEVuH:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Main_List()
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa in['LIVE','VOD','MOVIE']:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.play_VIDEO(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='LIVE_CATAGORY':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_LiveCatagory_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='MAIN_CATAGORY':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_MainCatagory_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='SUPERSECTION_LIST':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_SuperSection_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='BANDLIVESECTION_LIST':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_BandLiveSection_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='BAND2SECTION_LIST':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Band2Section_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='PROGRAM_LIST':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Program_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='EPISODE_LIST':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Episode_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='MOVIE_LIST':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Movie_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='LIVE_LIST':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_LiveChannel_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='ORDER_BY':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_setEpOrderby(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='SEARCH_GROUP':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Search_Group(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa in['SEARCH_LIST','LOCAL_SEARCH']:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Search_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='WATCH_GROUP':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Watch_Group(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='WATCH_LIST':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Watch_List(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Listfile_Delete(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa in['TOTAL_SEARCH','TOTAL_HISTORY']:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Global_Search(BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.main_params)
  elif BwzXoRQOlGWfDYmbcCLesjrpFUEVPa=='SEARCH_HISTORY':
   BwzXoRQOlGWfDYmbcCLesjrpFUEVkt.dp_Search_History()
  else:
   BwzXoRQOlGWfDYmbcCLesjrpFUEVuH
# Created by pyminifier (https://github.com/liftoff/pyminifier)
