# -*- coding: utf-8 -*-
__author__ = "NightRain"


import os
import sys
import datetime
import time
import json
import urllib.parse
import xbmcaddon, xbmcvfs, xbmcgui, xbmc
from sqlite3  import dbapi2 as database


__addon__     = xbmcaddon.Addon()
__language__  = __addon__.getLocalizedString
__version__   = __addon__.getAddonInfo('version')
__addonid__   = __addon__.getAddonInfo('id')
__addonname__ = __addon__.getAddonInfo('name')
__profile__   = __addon__.getAddonInfo('profile')


class CleanerRun( object ):
	def __init__( self ):
		self.DAY_TTL        = __addon__.getSetting( 'day_ttl' )
		self.THUMB_FOLDER   = xbmcvfs.translatePath( 'special://thumbnails' )
		self.DB_FILE        = xbmcvfs.translatePath( os.path.join('special://database', 'Textures13.db') )
		self.DATE_FILE      = xbmcvfs.translatePath( os.path.join(__profile__, 'cleaner_update.json') )
		self.PACKAGE_FOLDER = xbmcvfs.translatePath( os.path.join('special://home', 'addons', 'packages') )

	def get_params( self ):
		p = urllib.parse.parse_qs(sys.argv[2][1:])
		for i in p.keys():
			p[i] = p[i][0]
		return p

	def addon_noti( self, sting ):
		dialog = xbmcgui.Dialog()
		dialog.notification(__addonname__, sting, time=3000, sound=False)

	def addon_log( self, string ):
		try:
			log_message = string.encode('utf-8', 'ignore')
		except:
			log_message = 'addonException: addon_log'
		xbmc.log( "[%s-%s]: %s" %(__addonid__, __version__, log_message), level=xbmc.LOGINFO )

	def Get_Now_Datetime( self ):
		return datetime.datetime.now( datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul') )

	def Makedate_SaveJson( self ):
		json_data = { 'makedate' : self.Get_Now_Datetime().strftime('%Y-%m-%d')	}
		try:		
			fp = open(self.DATE_FILE, 'w', -1, 'utf-8')
			json.dump(json_data, fp)
			fp.close()
		except Exception as exception:
			return

	def clean( self, isMessage=True ):
		if os.path.exists(self.DB_FILE):
			dbcon = database.connect(self.DB_FILE, isolation_level=None)
			dbcur = dbcon.cursor()
			dbcur.execute('''PRAGMA synchronous = OFF''')
			dbcur.execute('''PRAGMA journal_mode = OFF''')
		else:
			if isMessage: 
				self.addon_noti('Failed!')
			else:
				self.addon_log('Thumbnail clean Failed!')
			return

		#current_date = datetime.date(datetime.utcnow())
		current_date = self.Get_Now_Datetime()
		back_date    = ( current_date - datetime.timedelta(days=int(self.DAY_TTL)) ).strftime('%Y-%m-%d %H:%M:%S')


		if isMessage: 
			progress_dialog = xbmcgui.DialogProgress()
			progress_dialog.create(__language__(30903).encode('utf8'), '')
			progress_dialog.update(0, __language__(30904).encode('utf8'))


		dbcur.execute( 'SELECT idtexture FROM sizes WHERE lastusetime < ?', (back_date,) )
		result = dbcur.fetchall()
		result_length = len(result)

		if result_length == 0:
			if isMessage: 
				progress_dialog.close()
				self.addon_noti( __language__(30908).encode('utf8') )
			else:
				self.addon_log( 'No Thumbnails to Clear' )
			return


		item_list = []
		for count, item in enumerate(result):
			if isMessage:
				if progress_dialog.iscanceled(): break

			_id = item[0]
			dbcur.execute( 'SELECT cachedurl FROM texture WHERE id = ?', (_id,) )
			url = dbcur.fetchall()[0][0]
			path = os.path.join(self.THUMB_FOLDER, url)
			try:
				item_list.append( (_id,) )
				os.remove(path)
			except: pass

			if isMessage:
				percent = int((count/float(result_length))*100)
				line = '[B]총 수량:[/B] %s[CR][B]현재:[/B] %02d.%s' % (result_length, count, str(path))
				progress_dialog.update(max(1, percent), line)


		if isMessage: progress_dialog.update( 33, __language__(30905).encode('utf8') )
		dbcur.executemany( 'DELETE FROM sizes WHERE idtexture = ?', item_list )
		if isMessage: progress_dialog.update( 66, __language__(30906).encode('utf8') )
		dbcur.executemany( 'DELETE FROM texture WHERE id=?', item_list )
		if isMessage: progress_dialog.update( 99, __language__(30907).encode('utf8') )
		dbcur.execute( 'VACUUM' )
		dbcon.commit()

		self.addon_log( 'Thumbnail clean : ' + str(result_length) )

		if isMessage:
			#xbmc.sleep(1000)
			progress_dialog.close()
			self.addon_noti('Success!')
		else:
			self.addon_log('Thumbnail clean Success!')

		return


	def PackageFile_Delete ( self ):
		if __addon__.getSetting( 'includePkg') == 'false': return

		now = time.time()
		
		for f in os.listdir( self.PACKAGE_FOLDER ):
			iFile = os.path.join(self.PACKAGE_FOLDER, f)

			if os.stat(iFile).st_mtime < now - int(self.DAY_TTL) * 86400:
				if os.path.isfile(iFile):
					os.remove( iFile )
					#self.addon_log( iFile )


	def cleaner_main( self ):
		dialog = xbmcgui.Dialog()
		ret = dialog.yesno( (str(self.DAY_TTL) + __language__(30901)).encode('utf8'), __language__(30902).encode('utf8') )
		if ret == False: return

		self.PackageFile_Delete() ##

		self.clean( isMessage=True )
		self.Makedate_SaveJson()


	def service_cleaner( self ):
		self.clean( isMessage=False )
		self.Makedate_SaveJson()
		self.addon_log(' service_cleaner run !! ')



if __name__ == "__main__":
	runObj = CleanerRun()

	mode = runObj.get_params().get('mode', None)

	if mode is None:
		runObj.cleaner_main()
	
	elif mode == 'SERVICE_REMOVE':
		runObj.service_cleaner()



### main process end ####

