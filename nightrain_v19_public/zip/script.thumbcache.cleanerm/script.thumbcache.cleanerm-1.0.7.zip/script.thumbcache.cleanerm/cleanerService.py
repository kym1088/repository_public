# -*- coding: utf-8 -*-
__author__ = "NightRain"

from cleanerServiceRun import *


monitor = xbmc.Monitor()
serviceObj = CleanerServiceRun()
xbmc.sleep(serviceObj.START_INTERVAL)
    
while not monitor.abortRequested():
	if monitor.waitForAbort(serviceObj.INTERVAL):
		break

	serviceObj.service_run()


	
