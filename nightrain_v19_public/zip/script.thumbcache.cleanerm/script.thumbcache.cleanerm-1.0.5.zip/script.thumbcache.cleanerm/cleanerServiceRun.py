# -*- coding: utf-8 -*-
__author__ = "NightRain"

import datetime
import os
import json
import xbmc, xbmcaddon, xbmcvfs

__addon__     = xbmcaddon.Addon()
__version__   = __addon__.getAddonInfo('version')
__addonid__   = __addon__.getAddonInfo('id')
__profile__   = __addon__.getAddonInfo('profile')


class CleanerServiceRun():

	def __init__( self ):
		self.START_INTERVAL   = 5000  ### 5초
		self.INTERVAL         = 600  ### 10분
		self.DATE_FILE        = xbmcvfs.translatePath(os.path.join(__profile__, 'cleaner_update.json')) 

	def addon_log( self, string ):
		log_message = str(string).encode('utf-8', 'ignore')
		xbmc.log( "[%s-%s]: %s" %(__addonid__, __version__, log_message), level=xbmc.LOGINFO )

	def Get_Now_Datetime( self ):
		return datetime.datetime.now( datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul') )

	def runDate_check( self ):
		if os.path.exists(self.DATE_FILE) == False: return False
		try:
			fp = open(self.DATE_FILE, 'r', -1, 'utf-8')
			json_data = json.load(fp)
			fp.close()
			make_date = json_data['makedate'] 
		except Exception as exception:
			make_date = '-'

		if make_date == self.Get_Now_Datetime().strftime('%Y-%m-%d') : return True
		else: return False


	def Makedate_SaveJson( self ):
		json_data = { 'makedate' : self.Get_Now_Datetime().strftime('%Y-%m-%d')	}
		try:		
			fp = open(self.DATE_FILE, 'w', -1, 'utf-8')
			json.dump(json_data, fp)
			fp.close()
		except Exception as exception:
			return
			

	def service_run(self):
		if __addon__.getSetting( 'autoRemove') == 'false': return

		#self.addon_log( 'before' )
		if self.runDate_check() :
			#self.addon_log( 'True' )
			return

		xbmc.executebuiltin('RunPlugin("plugin://script.thumbcache.cleanerm/?mode=SERVICE_REMOVE")')
		#self.Makedate_SaveJson()
		#self.addon_log('CleanerServiceRun!!!')


##### class End #####        