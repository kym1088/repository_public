__author__="NightRain"
gJRbVedXKFoNtmUyhwkCqYQLsWAnlx=object
gJRbVedXKFoNtmUyhwkCqYQLsWAnlD=None
gJRbVedXKFoNtmUyhwkCqYQLsWAnlI=True
gJRbVedXKFoNtmUyhwkCqYQLsWAnlT=False
gJRbVedXKFoNtmUyhwkCqYQLsWAnlv=type
gJRbVedXKFoNtmUyhwkCqYQLsWAnlu=dict
gJRbVedXKFoNtmUyhwkCqYQLsWAnlP=int
gJRbVedXKFoNtmUyhwkCqYQLsWAnla=open
gJRbVedXKFoNtmUyhwkCqYQLsWAnlB=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
gJRbVedXKFoNtmUyhwkCqYQLsWAnxl=[{'title':'실시간 (전체)','mode':'LIVE_LIST','genre':'-'},{'title':'실시간 (장르별)','mode':'LIVE_GROUP'},]
gJRbVedXKFoNtmUyhwkCqYQLsWAnxI =xbmcvfs.translatePath(os.path.join(__profile__,'samsungtv_cookies.json'))
from samsungtvCore import*
class gJRbVedXKFoNtmUyhwkCqYQLsWAnxD(gJRbVedXKFoNtmUyhwkCqYQLsWAnlx):
 def __init__(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT,gJRbVedXKFoNtmUyhwkCqYQLsWAnxv,gJRbVedXKFoNtmUyhwkCqYQLsWAnxu,gJRbVedXKFoNtmUyhwkCqYQLsWAnxP):
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxT._addon_url =gJRbVedXKFoNtmUyhwkCqYQLsWAnxv
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxT._addon_handle=gJRbVedXKFoNtmUyhwkCqYQLsWAnxu
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.main_params =gJRbVedXKFoNtmUyhwkCqYQLsWAnxP
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj =ELbiqKvVhdfQtlxAjNSwmXnzCDPOuT() 
 def addon_noti(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT,sting):
  try:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxB=xbmcgui.Dialog()
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxB.notification(__addonname__,sting)
  except:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnlD
 def addon_log(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT,string):
  try:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxO=string.encode('utf-8','ignore')
  except:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxO='addonException: addon_log'
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxp=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,gJRbVedXKFoNtmUyhwkCqYQLsWAnxO),level=gJRbVedXKFoNtmUyhwkCqYQLsWAnxp)
 def get_keyboard_input(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT,gJRbVedXKFoNtmUyhwkCqYQLsWAnxf):
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxM=gJRbVedXKFoNtmUyhwkCqYQLsWAnlD
  kb=xbmc.Keyboard()
  kb.setHeading(gJRbVedXKFoNtmUyhwkCqYQLsWAnxf)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxM=kb.getText()
  return gJRbVedXKFoNtmUyhwkCqYQLsWAnxM
 def add_dir(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT,label,sublabel='',img='',infoLabels=gJRbVedXKFoNtmUyhwkCqYQLsWAnlD,isFolder=gJRbVedXKFoNtmUyhwkCqYQLsWAnlI,params='',isLink=gJRbVedXKFoNtmUyhwkCqYQLsWAnlT,ContextMenu=gJRbVedXKFoNtmUyhwkCqYQLsWAnlD):
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxz='%s?%s'%(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT._addon_url,urllib.parse.urlencode(params))
  if sublabel:gJRbVedXKFoNtmUyhwkCqYQLsWAnxf='%s < %s >'%(label,sublabel)
  else: gJRbVedXKFoNtmUyhwkCqYQLsWAnxf=label
  if not img:img='DefaultFolder.png'
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxj=xbmcgui.ListItem(gJRbVedXKFoNtmUyhwkCqYQLsWAnxf)
  if gJRbVedXKFoNtmUyhwkCqYQLsWAnlv(img)==gJRbVedXKFoNtmUyhwkCqYQLsWAnlu:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxj.setArt(img)
  else:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxj.setArt({'thumb':img,'poster':img})
  if infoLabels:gJRbVedXKFoNtmUyhwkCqYQLsWAnxj.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxj.setProperty('IsPlayable','true')
  if ContextMenu:gJRbVedXKFoNtmUyhwkCqYQLsWAnxj.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT._addon_handle,gJRbVedXKFoNtmUyhwkCqYQLsWAnxz,gJRbVedXKFoNtmUyhwkCqYQLsWAnxj,isFolder)
 def dp_Main_List(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT,args):
  for gJRbVedXKFoNtmUyhwkCqYQLsWAnxi in gJRbVedXKFoNtmUyhwkCqYQLsWAnxl:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxf=gJRbVedXKFoNtmUyhwkCqYQLsWAnxi.get('title')
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxG=''
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxH={'mode':gJRbVedXKFoNtmUyhwkCqYQLsWAnxi.get('mode'),'genre':gJRbVedXKFoNtmUyhwkCqYQLsWAnxi.get('genre'),}
   if gJRbVedXKFoNtmUyhwkCqYQLsWAnxi.get('mode')in['XXX']:
    gJRbVedXKFoNtmUyhwkCqYQLsWAnxr=gJRbVedXKFoNtmUyhwkCqYQLsWAnlT
    gJRbVedXKFoNtmUyhwkCqYQLsWAnxE =gJRbVedXKFoNtmUyhwkCqYQLsWAnlI
   else:
    gJRbVedXKFoNtmUyhwkCqYQLsWAnxr=gJRbVedXKFoNtmUyhwkCqYQLsWAnlI
    gJRbVedXKFoNtmUyhwkCqYQLsWAnxE =gJRbVedXKFoNtmUyhwkCqYQLsWAnlT
   if 'icon' in gJRbVedXKFoNtmUyhwkCqYQLsWAnxi:gJRbVedXKFoNtmUyhwkCqYQLsWAnxG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',gJRbVedXKFoNtmUyhwkCqYQLsWAnxi.get('icon')) 
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.add_dir(gJRbVedXKFoNtmUyhwkCqYQLsWAnxf,sublabel='',img=gJRbVedXKFoNtmUyhwkCqYQLsWAnxG,infoLabels=gJRbVedXKFoNtmUyhwkCqYQLsWAnlD,isFolder=gJRbVedXKFoNtmUyhwkCqYQLsWAnxr,params=gJRbVedXKFoNtmUyhwkCqYQLsWAnxH,isLink=gJRbVedXKFoNtmUyhwkCqYQLsWAnxE)
  xbmcplugin.endOfDirectory(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT._addon_handle)
 def login_main(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT):
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.KodiVersion=gJRbVedXKFoNtmUyhwkCqYQLsWAnlP(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  if not os.path.isdir(xbmcvfs.translatePath(__profile__)):os.mkdir(xbmcvfs.translatePath(__profile__))
  try: 
   fp=gJRbVedXKFoNtmUyhwkCqYQLsWAnla(gJRbVedXKFoNtmUyhwkCqYQLsWAnxI,'r',-1,'utf-8')
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.SSTV= json.load(fp)
   fp.close()
  except gJRbVedXKFoNtmUyhwkCqYQLsWAnlB as exception:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.SSTV['limit_date']='0'
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxc =gJRbVedXKFoNtmUyhwkCqYQLsWAnlP(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDx=gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.SSTV['limit_date']
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDl =gJRbVedXKFoNtmUyhwkCqYQLsWAnlP(re.sub('-','',gJRbVedXKFoNtmUyhwkCqYQLsWAnDx))
  if gJRbVedXKFoNtmUyhwkCqYQLsWAnxc<=gJRbVedXKFoNtmUyhwkCqYQLsWAnDl:
   return gJRbVedXKFoNtmUyhwkCqYQLsWAnlI
  if gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.Get_BaseCookies()==gJRbVedXKFoNtmUyhwkCqYQLsWAnlT:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.addon_noti('init error!')
   return gJRbVedXKFoNtmUyhwkCqYQLsWAnlT
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDI =gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.Get_Now_Datetime()
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDT=gJRbVedXKFoNtmUyhwkCqYQLsWAnDI+datetime.timedelta(days=gJRbVedXKFoNtmUyhwkCqYQLsWAnlP(__addon__.getSetting('cache_ttl')))
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.SSTV['limit_date']=gJRbVedXKFoNtmUyhwkCqYQLsWAnDT.strftime('%Y-%m-%d')
  try: 
   fp=gJRbVedXKFoNtmUyhwkCqYQLsWAnla(gJRbVedXKFoNtmUyhwkCqYQLsWAnxI,'w',-1,'utf-8')
   json.dump(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.SSTV,fp,indent=4,ensure_ascii=gJRbVedXKFoNtmUyhwkCqYQLsWAnlT)
   fp.close()
  except gJRbVedXKFoNtmUyhwkCqYQLsWAnlB as exception:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.addon_noti('file save error!')
   return gJRbVedXKFoNtmUyhwkCqYQLsWAnlT
  return gJRbVedXKFoNtmUyhwkCqYQLsWAnlI
 def dp_LiveChannel_List(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT,args):
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDu=args.get('genre')
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDP=gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.GetLiveChannelList(view_genre=gJRbVedXKFoNtmUyhwkCqYQLsWAnDu)
  for gJRbVedXKFoNtmUyhwkCqYQLsWAnDa in gJRbVedXKFoNtmUyhwkCqYQLsWAnDP:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnDB =gJRbVedXKFoNtmUyhwkCqYQLsWAnDa.get('chid')
   gJRbVedXKFoNtmUyhwkCqYQLsWAnDO =gJRbVedXKFoNtmUyhwkCqYQLsWAnDa.get('channlnm')
   gJRbVedXKFoNtmUyhwkCqYQLsWAnDp =gJRbVedXKFoNtmUyhwkCqYQLsWAnDa.get('genre')
   gJRbVedXKFoNtmUyhwkCqYQLsWAnDM =gJRbVedXKFoNtmUyhwkCqYQLsWAnDa.get('programnm')
   gJRbVedXKFoNtmUyhwkCqYQLsWAnDz =gJRbVedXKFoNtmUyhwkCqYQLsWAnDa.get('thumbnail')
   gJRbVedXKFoNtmUyhwkCqYQLsWAnDf =gJRbVedXKFoNtmUyhwkCqYQLsWAnDa.get('epg')
   gJRbVedXKFoNtmUyhwkCqYQLsWAnDj={'mediatype':'episode','title':gJRbVedXKFoNtmUyhwkCqYQLsWAnDM,'studio':gJRbVedXKFoNtmUyhwkCqYQLsWAnDO,'genre':gJRbVedXKFoNtmUyhwkCqYQLsWAnDp,'plot':'%s\n\n%s'%(gJRbVedXKFoNtmUyhwkCqYQLsWAnDO,gJRbVedXKFoNtmUyhwkCqYQLsWAnDf),}
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxH={'mode':'LIVE','chid':gJRbVedXKFoNtmUyhwkCqYQLsWAnDB,}
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.add_dir(gJRbVedXKFoNtmUyhwkCqYQLsWAnDO,sublabel=gJRbVedXKFoNtmUyhwkCqYQLsWAnDM,img=gJRbVedXKFoNtmUyhwkCqYQLsWAnDz,infoLabels=gJRbVedXKFoNtmUyhwkCqYQLsWAnDj,isFolder=gJRbVedXKFoNtmUyhwkCqYQLsWAnlT,params=gJRbVedXKFoNtmUyhwkCqYQLsWAnxH)
  xbmcplugin.endOfDirectory(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT._addon_handle,cacheToDisc=gJRbVedXKFoNtmUyhwkCqYQLsWAnlT)
 def dp_LiveGroup_List(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT,args):
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDP=gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.GetGenreList()
  for gJRbVedXKFoNtmUyhwkCqYQLsWAnDa in gJRbVedXKFoNtmUyhwkCqYQLsWAnDP:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnDu =gJRbVedXKFoNtmUyhwkCqYQLsWAnDa.get('genre')
   gJRbVedXKFoNtmUyhwkCqYQLsWAnDj={'plot':gJRbVedXKFoNtmUyhwkCqYQLsWAnDu}
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxH={'mode':'LIVE_LIST','genre':gJRbVedXKFoNtmUyhwkCqYQLsWAnDu,}
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.add_dir(gJRbVedXKFoNtmUyhwkCqYQLsWAnDu,sublabel='',img='',infoLabels=gJRbVedXKFoNtmUyhwkCqYQLsWAnDj,isFolder=gJRbVedXKFoNtmUyhwkCqYQLsWAnlI,params=gJRbVedXKFoNtmUyhwkCqYQLsWAnxH)
  xbmcplugin.endOfDirectory(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT._addon_handle,cacheToDisc=gJRbVedXKFoNtmUyhwkCqYQLsWAnlT)
 def play_VIDEO(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT,args):
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDB =args.get('chid')
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDG=gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.GetBroadURL(gJRbVedXKFoNtmUyhwkCqYQLsWAnDB)
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.addon_log('%s - url : %s'%(gJRbVedXKFoNtmUyhwkCqYQLsWAnDB,gJRbVedXKFoNtmUyhwkCqYQLsWAnDG))
  if gJRbVedXKFoNtmUyhwkCqYQLsWAnDG=='':
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.addon_noti(__language__(30906).encode('utf8'))
   return
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDH={'user-agent':gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.USER_AGENT,'origin':'https://www.samsungtvplus.com',}
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDr=gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.make_stream_header(gJRbVedXKFoNtmUyhwkCqYQLsWAnDH,gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.makeDefaultCookies())
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.addon_log('stream_headers : '+gJRbVedXKFoNtmUyhwkCqYQLsWAnDr)
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDG='{}|{}'.format(gJRbVedXKFoNtmUyhwkCqYQLsWAnDG,gJRbVedXKFoNtmUyhwkCqYQLsWAnDr)
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDE=xbmcgui.ListItem(path=gJRbVedXKFoNtmUyhwkCqYQLsWAnDG)
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDE.setContentLookup(gJRbVedXKFoNtmUyhwkCqYQLsWAnlT)
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDE.setMimeType('application/x-mpegURL')
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDE.setProperty('inputstream','inputstream.adaptive')
  if gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.SamsungtvObj.KodiVersion<=20:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnDE.setProperty('inputstream.adaptive.manifest_type','hls')
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDE.setProperty('inputstream.adaptive.stream_headers',gJRbVedXKFoNtmUyhwkCqYQLsWAnDr)
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDE.setProperty('inputstream.adaptive.manifest_headers',gJRbVedXKFoNtmUyhwkCqYQLsWAnDr)
  xbmcplugin.setResolvedUrl(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT._addon_handle,gJRbVedXKFoNtmUyhwkCqYQLsWAnlI,gJRbVedXKFoNtmUyhwkCqYQLsWAnDE)
 def STV_logout(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT):
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxB=xbmcgui.Dialog()
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDS=gJRbVedXKFoNtmUyhwkCqYQLsWAnxB.yesno(__language__(30905).encode('utf8'),__language__(30907).encode('utf8'))
  if gJRbVedXKFoNtmUyhwkCqYQLsWAnDS==gJRbVedXKFoNtmUyhwkCqYQLsWAnlT:return 
  if os.path.isfile(gJRbVedXKFoNtmUyhwkCqYQLsWAnxI):os.remove(gJRbVedXKFoNtmUyhwkCqYQLsWAnxI)
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.addon_noti(__language__(30904).encode('utf-8'))
 def dp_Test(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT,args):
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.addon_noti('test')
 def samsungtv_main(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT):
  gJRbVedXKFoNtmUyhwkCqYQLsWAnDc=gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.main_params.get('mode',gJRbVedXKFoNtmUyhwkCqYQLsWAnlD)
  if gJRbVedXKFoNtmUyhwkCqYQLsWAnDc=='LOGOUT':
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.STV_logout()
   return
  gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.login_main()
  if gJRbVedXKFoNtmUyhwkCqYQLsWAnDc is gJRbVedXKFoNtmUyhwkCqYQLsWAnlD:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.dp_Main_List(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.main_params)
  elif gJRbVedXKFoNtmUyhwkCqYQLsWAnDc=='LIVE_LIST':
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.dp_LiveChannel_List(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.main_params)
  elif gJRbVedXKFoNtmUyhwkCqYQLsWAnDc=='LIVE':
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.play_VIDEO(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.main_params)
  elif gJRbVedXKFoNtmUyhwkCqYQLsWAnDc=='LIVE_GROUP':
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.dp_LiveGroup_List(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.main_params)
  elif gJRbVedXKFoNtmUyhwkCqYQLsWAnDc=='CAPTCHA_TEST':
   gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.dp_Test(gJRbVedXKFoNtmUyhwkCqYQLsWAnxT.main_params)
  else:
   gJRbVedXKFoNtmUyhwkCqYQLsWAnlD
# Created by pyminifier (https://github.com/liftoff/pyminifier)
