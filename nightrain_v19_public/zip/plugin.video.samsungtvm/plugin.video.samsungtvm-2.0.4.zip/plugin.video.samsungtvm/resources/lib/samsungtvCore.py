__author__="NightRain"
ELbiqKvVhdfQtlxAjNSwmXnzCDPOTr=object
ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp=None
ELbiqKvVhdfQtlxAjNSwmXnzCDPOTy=False
ELbiqKvVhdfQtlxAjNSwmXnzCDPOTW=int
ELbiqKvVhdfQtlxAjNSwmXnzCDPOku=len
ELbiqKvVhdfQtlxAjNSwmXnzCDPOkT=Exception
ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB=print
ELbiqKvVhdfQtlxAjNSwmXnzCDPOks=True
ELbiqKvVhdfQtlxAjNSwmXnzCDPOka=str
ELbiqKvVhdfQtlxAjNSwmXnzCDPOkg=range
import urllib
import re
import json
import requests
import datetime
import time
import zlib
import base64
class ELbiqKvVhdfQtlxAjNSwmXnzCDPOuT(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTr):
 def __init__(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.DEFAULT_HEADER ={'user-agent':ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.USER_AGENT}
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.API_DOMAIN ='https://www.samsungtvplus.com'
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.SSTV={}
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.KodiVersion=20
 def callRequestCookies(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk,jobtype,ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH,payload=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,params=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,headers=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,cookies=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,redirects=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTy):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuB=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.DEFAULT_HEADER
  if headers:ELbiqKvVhdfQtlxAjNSwmXnzCDPOuB.update(headers)
  if jobtype=='Get':
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOus=requests.get(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH,params=params,headers=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuB,cookies=cookies,allow_redirects=redirects)
  else:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOus=requests.post(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH,data=payload,params=params,headers=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuB,cookies=cookies,allow_redirects=redirects)
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOus
 def Get_Now_Datetime(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOug =ELbiqKvVhdfQtlxAjNSwmXnzCDPOTW(time.time())
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuo=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTW(ELbiqKvVhdfQtlxAjNSwmXnzCDPOug-ELbiqKvVhdfQtlxAjNSwmXnzCDPOug%3600)
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOuo,ELbiqKvVhdfQtlxAjNSwmXnzCDPOug
 def zlib_decompress(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk,ELbiqKvVhdfQtlxAjNSwmXnzCDPOuF):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuc=zlib.decompress(base64.standard_b64decode(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuF))
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOuc.decode('utf-8')
 def zlib_compress(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk,ELbiqKvVhdfQtlxAjNSwmXnzCDPOuc):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuF=zlib.compress(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuc.encode('utf-8'))
  return base64.standard_b64encode(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuF).decode('utf-8')
 def makeDefaultCookies(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk,vToken=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,vUserinfo=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI={}
  if ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.SSTV.get('session') !='':ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI['session'] =ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.SSTV.get('session')
  if ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.SSTV.get('session.sig')!='':ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI['session.sig']=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.SSTV.get('session.sig')
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI
 def make_stream_header(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk,ELbiqKvVhdfQtlxAjNSwmXnzCDPOuM,ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuJ=''
  if ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI not in[{},ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,'']:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuR=ELbiqKvVhdfQtlxAjNSwmXnzCDPOku(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI)
   for ELbiqKvVhdfQtlxAjNSwmXnzCDPOue,ELbiqKvVhdfQtlxAjNSwmXnzCDPOuG in ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI.items():
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOuJ+='{}={}'.format(ELbiqKvVhdfQtlxAjNSwmXnzCDPOue,ELbiqKvVhdfQtlxAjNSwmXnzCDPOuG)
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOuR+=-1
    if ELbiqKvVhdfQtlxAjNSwmXnzCDPOuR>0:ELbiqKvVhdfQtlxAjNSwmXnzCDPOuJ+='; '
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuM['cookie']=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuJ
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOuY=''
  i=0
  for ELbiqKvVhdfQtlxAjNSwmXnzCDPOue,ELbiqKvVhdfQtlxAjNSwmXnzCDPOuG in ELbiqKvVhdfQtlxAjNSwmXnzCDPOuM.items():
   i=i+1
   if i>1:ELbiqKvVhdfQtlxAjNSwmXnzCDPOuY+='&'
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuY+='{}={}'.format(ELbiqKvVhdfQtlxAjNSwmXnzCDPOue,urllib.parse.quote(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuG))
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOuY
 def Get_BaseCookies(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk):
  try:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.API_DOMAIN
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuU=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.callRequestCookies('Get',ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH,payload=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,params=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,headers=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,cookies=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp)
   for ELbiqKvVhdfQtlxAjNSwmXnzCDPOur in ELbiqKvVhdfQtlxAjNSwmXnzCDPOuU.cookies:
    if ELbiqKvVhdfQtlxAjNSwmXnzCDPOur.name=='session':
     ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.SSTV['session']=ELbiqKvVhdfQtlxAjNSwmXnzCDPOur.value
    elif ELbiqKvVhdfQtlxAjNSwmXnzCDPOur.name=='session.sig':
     ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.SSTV['session.sig']=ELbiqKvVhdfQtlxAjNSwmXnzCDPOur.value
  except ELbiqKvVhdfQtlxAjNSwmXnzCDPOkT as exception:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB(exception)
   return ELbiqKvVhdfQtlxAjNSwmXnzCDPOTy
  try:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.API_DOMAIN+'/user'
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.makeDefaultCookies()
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuU=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.callRequestCookies('Get',ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH,payload=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,params=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,headers=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,cookies=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI)
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOup=json.loads(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuU.text)
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.SSTV['countryCode']=ELbiqKvVhdfQtlxAjNSwmXnzCDPOup.get('countryCode')
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.SSTV['uuid'] =ELbiqKvVhdfQtlxAjNSwmXnzCDPOup.get('uuid')
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.SSTV['ip'] =ELbiqKvVhdfQtlxAjNSwmXnzCDPOup.get('ip')
  except ELbiqKvVhdfQtlxAjNSwmXnzCDPOkT as exception:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB(exception)
   return ELbiqKvVhdfQtlxAjNSwmXnzCDPOTy
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOks
 def Get_BaseJson_Request(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOup={}
  try:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.API_DOMAIN+'/api/lives'
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuo,ELbiqKvVhdfQtlxAjNSwmXnzCDPOug=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.GetNoCache()
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuy=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.zlib_compress(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.SSTV['uuid']+':'+ELbiqKvVhdfQtlxAjNSwmXnzCDPOka(ELbiqKvVhdfQtlxAjNSwmXnzCDPOug))
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI =ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.makeDefaultCookies()
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuW ={'t':ELbiqKvVhdfQtlxAjNSwmXnzCDPOka(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuo)}
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuM ={'x-cred-payload':ELbiqKvVhdfQtlxAjNSwmXnzCDPOuy}
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuU=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.callRequestCookies('Get',ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH,payload=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,params=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuW,headers=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuM,cookies=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuI)
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOup=json.loads(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuU.text)
  except ELbiqKvVhdfQtlxAjNSwmXnzCDPOkT as exception:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB(exception)
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOup
 def GetGenreList(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOTu=[]
  try:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOup=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.Get_BaseJson_Request()
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOTk=ELbiqKvVhdfQtlxAjNSwmXnzCDPOup['live']['genrelist']
   for ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB in ELbiqKvVhdfQtlxAjNSwmXnzCDPOTk:
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTs={'genre':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('name'),}
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTu.append(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTs)
  except ELbiqKvVhdfQtlxAjNSwmXnzCDPOkT as exception:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB(exception)
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOTu
 def GetLiveChannelList(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk,view_genre='-'):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOTu=[]
  try:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOup=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.Get_BaseJson_Request()
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOTk=ELbiqKvVhdfQtlxAjNSwmXnzCDPOup['live']['channel']
   for ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB in ELbiqKvVhdfQtlxAjNSwmXnzCDPOTk:
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTa=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('genre').get('name')
    if ELbiqKvVhdfQtlxAjNSwmXnzCDPOTa!=view_genre and view_genre!='-':continue
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.Make_EpgList(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('program'))
    if ELbiqKvVhdfQtlxAjNSwmXnzCDPOku(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg)>1:
     ELbiqKvVhdfQtlxAjNSwmXnzCDPOTo=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg[0].get('endtm').replace('-','').replace(':','').replace(' ','')
     ELbiqKvVhdfQtlxAjNSwmXnzCDPOug=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.Get_Now_Datetime().strftime('%Y%m%d%H%M')
     if ELbiqKvVhdfQtlxAjNSwmXnzCDPOTW(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTo)<ELbiqKvVhdfQtlxAjNSwmXnzCDPOTW(ELbiqKvVhdfQtlxAjNSwmXnzCDPOug):
      ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg.pop(0)
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTc =ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('logo')
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTF=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg[0].get('thumbnail')
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTs={'chid':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('id'),'channlnm':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('name'),'genre':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTa,'programnm':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg[0].get('title'),'thumbnail':{'thumb':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTF,'clearlogo':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTc,'icon':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTc,'fanart':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTF},'epg':ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.Make_EpgString(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg),}
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTu.append(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTs)
  except ELbiqKvVhdfQtlxAjNSwmXnzCDPOkT as exception:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB(exception)
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOTu
 def Make_EpgList(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk,programList):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg=[]
  try:
   for ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB in programList:
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTI=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('start_time')
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTJ =ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('duration') 
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTR=datetime.datetime.strptime(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTI,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTo =ELbiqKvVhdfQtlxAjNSwmXnzCDPOTR+datetime.timedelta(seconds=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTJ)
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTs={'title':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('title'),'starttm':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTR.strftime('%Y-%m-%d %H:%M'),'endtm':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTo.strftime('%Y-%m-%d %H:%M'),'thumbnail':ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('thumbnail'),}
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg.append(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTs)
  except ELbiqKvVhdfQtlxAjNSwmXnzCDPOkT as exception:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB(exception)
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg
 def Make_EpgString(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk,ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOTe=''
  try:
   for i in ELbiqKvVhdfQtlxAjNSwmXnzCDPOkg(ELbiqKvVhdfQtlxAjNSwmXnzCDPOku(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg)):
    if i>3:break
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTG=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg[i].get('starttm')[-5:]
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTM =ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg[i].get('endtm')[-5:]
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTY =ELbiqKvVhdfQtlxAjNSwmXnzCDPOTg[i].get('title')
    ELbiqKvVhdfQtlxAjNSwmXnzCDPOTe+='%s\n[%s ~ %s]\n\n'%(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTY,ELbiqKvVhdfQtlxAjNSwmXnzCDPOTG,ELbiqKvVhdfQtlxAjNSwmXnzCDPOTM)
  except ELbiqKvVhdfQtlxAjNSwmXnzCDPOkT as exception:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB(exception)
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOTe
 def GetBroadURL(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk,chid):
  ELbiqKvVhdfQtlxAjNSwmXnzCDPOTH=''
  try:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOup=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.Get_BaseJson_Request()
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOTk=ELbiqKvVhdfQtlxAjNSwmXnzCDPOup['live']['channel']
   for ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB in ELbiqKvVhdfQtlxAjNSwmXnzCDPOTk:
    if ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('id')==chid:
     ELbiqKvVhdfQtlxAjNSwmXnzCDPOTU =ELbiqKvVhdfQtlxAjNSwmXnzCDPOTB.get('program')[0].get('stream_url')
     ELbiqKvVhdfQtlxAjNSwmXnzCDPOTH=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.zlib_decompress(ELbiqKvVhdfQtlxAjNSwmXnzCDPOTU)
     break
  except ELbiqKvVhdfQtlxAjNSwmXnzCDPOkT as exception:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB(exception)
  return ELbiqKvVhdfQtlxAjNSwmXnzCDPOTH
 def GetTest(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk,streamurl):
  try:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.zlib_decompress(streamurl)
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH)
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH='https://play-kr.samsungtvplus.com/tvplus/web/v3/play?tid=eVFDcm9hRjhaR1RVNHAva2JJWTR3dm5YWGo3SWlIekpoUENlbmRaaDVCRXROSU9DbWRoT3lKN3JHbGdnU1BSTUlzUHptbFBGS01qWG9hYjdoZElQTXRrZ3ozbXlsUkdIOHoxTGxDcGRsekhnaXJ0Q21qUU1ycWNZdURmWjhidUxyZFpxUjdiODFUZEs1NFFBYm9hWnBPL2gvZXRINWZ0cVJhMFA3RjFZUXU2NVJtZVpZZGl6VjhmUXhCWnVWaEQwZjV2L1hTeUhOblN1akRLR2dsYzVvQzREclhUYzdOc1NzUlZkTVp5UnF6OG5HWERDRjR0dHVDUmxuRVpjbk81eSt1RXhiZkN5aHJUZWRyemdSWWloQURyTnZmRlFwQnVVZTdzay9Ob2ZBekk9'
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuM ={'origin':ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.API_DOMAIN}
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOuU=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuk.callRequestCookies('Get',ELbiqKvVhdfQtlxAjNSwmXnzCDPOuH,payload=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,params=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp,headers=ELbiqKvVhdfQtlxAjNSwmXnzCDPOuM,cookies=ELbiqKvVhdfQtlxAjNSwmXnzCDPOTp)
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB(ELbiqKvVhdfQtlxAjNSwmXnzCDPOuU.text)
  except ELbiqKvVhdfQtlxAjNSwmXnzCDPOkT as exception:
   ELbiqKvVhdfQtlxAjNSwmXnzCDPOkB(exception)
  return
# Created by pyminifier (https://github.com/liftoff/pyminifier)
