__author__="NightRain"
BNoSlmXyRvOYhTEUiLwIHcnKCVFWGJ=object
BNoSlmXyRvOYhTEUiLwIHcnKCVFWGd=None
BNoSlmXyRvOYhTEUiLwIHcnKCVFWtQ=True
BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG=False
BNoSlmXyRvOYhTEUiLwIHcnKCVFWte=type
BNoSlmXyRvOYhTEUiLwIHcnKCVFWtr=dict
BNoSlmXyRvOYhTEUiLwIHcnKCVFWtP=open
BNoSlmXyRvOYhTEUiLwIHcnKCVFWtz=Exception
BNoSlmXyRvOYhTEUiLwIHcnKCVFWtb=int
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
BNoSlmXyRvOYhTEUiLwIHcnKCVFWQt=[{'title':'실시간 (전체)','mode':'LIVE_LIST','genre':'-'},{'title':'실시간 (장르별)','mode':'LIVE_GROUP'},]
BNoSlmXyRvOYhTEUiLwIHcnKCVFWQe =xbmcvfs.translatePath(os.path.join(__profile__,'samsungtv_cookies.json'))
from samsungtvCore import*
class BNoSlmXyRvOYhTEUiLwIHcnKCVFWQG(BNoSlmXyRvOYhTEUiLwIHcnKCVFWGJ):
 def __init__(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr,BNoSlmXyRvOYhTEUiLwIHcnKCVFWQP,BNoSlmXyRvOYhTEUiLwIHcnKCVFWQz,BNoSlmXyRvOYhTEUiLwIHcnKCVFWQb):
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr._addon_url =BNoSlmXyRvOYhTEUiLwIHcnKCVFWQP
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr._addon_handle=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQz
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.main_params =BNoSlmXyRvOYhTEUiLwIHcnKCVFWQb
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj =NLHjXBAgOwQeIrvcWRKsdJinPmMuly() 
 def addon_noti(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr,sting):
  try:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQp=xbmcgui.Dialog()
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQp.notification(__addonname__,sting)
  except:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWGd
 def addon_log(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr,string):
  try:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQM=string.encode('utf-8','ignore')
  except:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQM='addonException: addon_log'
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQg=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,BNoSlmXyRvOYhTEUiLwIHcnKCVFWQM),level=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQg)
 def get_keyboard_input(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr,BNoSlmXyRvOYhTEUiLwIHcnKCVFWQf):
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQj=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGd
  kb=xbmc.Keyboard()
  kb.setHeading(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQf)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQj=kb.getText()
  return BNoSlmXyRvOYhTEUiLwIHcnKCVFWQj
 def add_dir(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr,label,sublabel='',img='',infoLabels=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGd,isFolder=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtQ,params='',isLink=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG,ContextMenu=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGd):
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQs='%s?%s'%(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr._addon_url,urllib.parse.urlencode(params))
  if sublabel:BNoSlmXyRvOYhTEUiLwIHcnKCVFWQf='%s < %s >'%(label,sublabel)
  else: BNoSlmXyRvOYhTEUiLwIHcnKCVFWQf=label
  if not img:img='DefaultFolder.png'
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQk=xbmcgui.ListItem(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQf)
  if BNoSlmXyRvOYhTEUiLwIHcnKCVFWte(img)==BNoSlmXyRvOYhTEUiLwIHcnKCVFWtr:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQk.setArt(img)
  else:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQk.setArt({'thumb':img,'poster':img})
  if infoLabels:BNoSlmXyRvOYhTEUiLwIHcnKCVFWQk.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQk.setProperty('IsPlayable','true')
  if ContextMenu:BNoSlmXyRvOYhTEUiLwIHcnKCVFWQk.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr._addon_handle,BNoSlmXyRvOYhTEUiLwIHcnKCVFWQs,BNoSlmXyRvOYhTEUiLwIHcnKCVFWQk,isFolder)
 def dp_Main_List(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr,args):
  for BNoSlmXyRvOYhTEUiLwIHcnKCVFWQa in BNoSlmXyRvOYhTEUiLwIHcnKCVFWQt:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQf=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQa.get('title')
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQD=''
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQA={'mode':BNoSlmXyRvOYhTEUiLwIHcnKCVFWQa.get('mode'),'genre':BNoSlmXyRvOYhTEUiLwIHcnKCVFWQa.get('genre'),}
   if BNoSlmXyRvOYhTEUiLwIHcnKCVFWQa.get('mode')in['XXX']:
    BNoSlmXyRvOYhTEUiLwIHcnKCVFWQq=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG
    BNoSlmXyRvOYhTEUiLwIHcnKCVFWQx =BNoSlmXyRvOYhTEUiLwIHcnKCVFWtQ
   else:
    BNoSlmXyRvOYhTEUiLwIHcnKCVFWQq=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtQ
    BNoSlmXyRvOYhTEUiLwIHcnKCVFWQx =BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG
   if 'icon' in BNoSlmXyRvOYhTEUiLwIHcnKCVFWQa:BNoSlmXyRvOYhTEUiLwIHcnKCVFWQD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',BNoSlmXyRvOYhTEUiLwIHcnKCVFWQa.get('icon')) 
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.add_dir(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQf,sublabel='',img=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQD,infoLabels=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGd,isFolder=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQq,params=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQA,isLink=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQx)
  xbmcplugin.endOfDirectory(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr._addon_handle)
 def login_main(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr):
  if not os.path.isdir(xbmcvfs.translatePath(__profile__)):os.mkdir(xbmcvfs.translatePath(__profile__))
  try: 
   fp=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtP(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQe,'r',-1,'utf-8')
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj.SSTV= json.load(fp)
   fp.close()
  except BNoSlmXyRvOYhTEUiLwIHcnKCVFWtz as exception:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj.SSTV['limit_date']='0'
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQd =BNoSlmXyRvOYhTEUiLwIHcnKCVFWtb(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGQ=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj.SSTV['limit_date']
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGt =BNoSlmXyRvOYhTEUiLwIHcnKCVFWtb(re.sub('-','',BNoSlmXyRvOYhTEUiLwIHcnKCVFWGQ))
  if BNoSlmXyRvOYhTEUiLwIHcnKCVFWQd<=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGt:
   return BNoSlmXyRvOYhTEUiLwIHcnKCVFWtQ
  if BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj.Get_BaseCookies()==BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.addon_noti('init error!')
   return BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGe =BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj.Get_Now_Datetime()
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGr=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGe+datetime.timedelta(days=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtb(__addon__.getSetting('cache_ttl')))
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj.SSTV['limit_date']=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGr.strftime('%Y-%m-%d')
  try: 
   fp=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtP(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQe,'w',-1,'utf-8')
   json.dump(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj.SSTV,fp,indent=4,ensure_ascii=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG)
   fp.close()
  except BNoSlmXyRvOYhTEUiLwIHcnKCVFWtz as exception:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.addon_noti('file save error!')
   return BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG
  return BNoSlmXyRvOYhTEUiLwIHcnKCVFWtQ
 def dp_LiveChannel_List(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr,args):
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGz=args.get('genre')
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGb=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj.GetLiveChannelList(view_genre=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGz)
  for BNoSlmXyRvOYhTEUiLwIHcnKCVFWGu in BNoSlmXyRvOYhTEUiLwIHcnKCVFWGb:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWGp =BNoSlmXyRvOYhTEUiLwIHcnKCVFWGu.get('chid')
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWGM =BNoSlmXyRvOYhTEUiLwIHcnKCVFWGu.get('channlnm')
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWGg =BNoSlmXyRvOYhTEUiLwIHcnKCVFWGu.get('genre')
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWGj =BNoSlmXyRvOYhTEUiLwIHcnKCVFWGu.get('programnm')
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWGs =BNoSlmXyRvOYhTEUiLwIHcnKCVFWGu.get('thumbnail')
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWGf =BNoSlmXyRvOYhTEUiLwIHcnKCVFWGu.get('epg')
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWGk={'mediatype':'episode','title':BNoSlmXyRvOYhTEUiLwIHcnKCVFWGj,'studio':BNoSlmXyRvOYhTEUiLwIHcnKCVFWGM,'genre':BNoSlmXyRvOYhTEUiLwIHcnKCVFWGg,'plot':'%s\n\n%s'%(BNoSlmXyRvOYhTEUiLwIHcnKCVFWGM,BNoSlmXyRvOYhTEUiLwIHcnKCVFWGf),}
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQA={'mode':'LIVE','chid':BNoSlmXyRvOYhTEUiLwIHcnKCVFWGp,}
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.add_dir(BNoSlmXyRvOYhTEUiLwIHcnKCVFWGM,sublabel=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGj,img=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGs,infoLabels=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGk,isFolder=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG,params=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQA)
  xbmcplugin.endOfDirectory(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr._addon_handle,cacheToDisc=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG)
 def dp_LiveGroup_List(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr,args):
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGb=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj.GetGenreList()
  for BNoSlmXyRvOYhTEUiLwIHcnKCVFWGu in BNoSlmXyRvOYhTEUiLwIHcnKCVFWGb:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWGz =BNoSlmXyRvOYhTEUiLwIHcnKCVFWGu.get('genre')
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWGk={'plot':BNoSlmXyRvOYhTEUiLwIHcnKCVFWGz}
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQA={'mode':'LIVE_LIST','genre':BNoSlmXyRvOYhTEUiLwIHcnKCVFWGz,}
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.add_dir(BNoSlmXyRvOYhTEUiLwIHcnKCVFWGz,sublabel='',img='',infoLabels=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGk,isFolder=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtQ,params=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQA)
  xbmcplugin.endOfDirectory(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr._addon_handle,cacheToDisc=BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG)
 def play_VIDEO(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr,args):
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGp =args.get('chid')
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGD=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.SamsungtvObj.GetBroadURL(BNoSlmXyRvOYhTEUiLwIHcnKCVFWGp)
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.addon_log('%s - url : %s'%(BNoSlmXyRvOYhTEUiLwIHcnKCVFWGp,BNoSlmXyRvOYhTEUiLwIHcnKCVFWGD))
  if BNoSlmXyRvOYhTEUiLwIHcnKCVFWGD=='':
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.addon_noti(__language__(30906).encode('utf8'))
   return
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGD+='|origin=https://www.samsungtvplus.com'
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGA=xbmcgui.ListItem(path=BNoSlmXyRvOYhTEUiLwIHcnKCVFWGD)
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGA.setContentLookup(BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG)
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGA.setMimeType('application/x-mpegURL')
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGA.setProperty('inputstream','inputstream.adaptive')
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGA.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr._addon_handle,BNoSlmXyRvOYhTEUiLwIHcnKCVFWtQ,BNoSlmXyRvOYhTEUiLwIHcnKCVFWGA)
 def STV_logout(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr):
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQp=xbmcgui.Dialog()
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGq=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQp.yesno(__language__(30905).encode('utf8'),__language__(30907).encode('utf8'))
  if BNoSlmXyRvOYhTEUiLwIHcnKCVFWGq==BNoSlmXyRvOYhTEUiLwIHcnKCVFWtG:return 
  if os.path.isfile(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQe):os.remove(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQe)
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.addon_noti(__language__(30904).encode('utf-8'))
 def dp_Test(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr,args):
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.addon_noti('test')
 def samsungtv_main(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr):
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWGx=BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.main_params.get('mode',BNoSlmXyRvOYhTEUiLwIHcnKCVFWGd)
  if BNoSlmXyRvOYhTEUiLwIHcnKCVFWGx=='LOGOUT':
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.STV_logout()
   return
  BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.login_main()
  if BNoSlmXyRvOYhTEUiLwIHcnKCVFWGx is BNoSlmXyRvOYhTEUiLwIHcnKCVFWGd:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.dp_Main_List(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.main_params)
  elif BNoSlmXyRvOYhTEUiLwIHcnKCVFWGx=='LIVE_LIST':
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.dp_LiveChannel_List(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.main_params)
  elif BNoSlmXyRvOYhTEUiLwIHcnKCVFWGx=='LIVE':
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.play_VIDEO(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.main_params)
  elif BNoSlmXyRvOYhTEUiLwIHcnKCVFWGx=='LIVE_GROUP':
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.dp_LiveGroup_List(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.main_params)
  elif BNoSlmXyRvOYhTEUiLwIHcnKCVFWGx=='CAPTCHA_TEST':
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.dp_Test(BNoSlmXyRvOYhTEUiLwIHcnKCVFWQr.main_params)
  else:
   BNoSlmXyRvOYhTEUiLwIHcnKCVFWGd
# Created by pyminifier (https://github.com/liftoff/pyminifier)
