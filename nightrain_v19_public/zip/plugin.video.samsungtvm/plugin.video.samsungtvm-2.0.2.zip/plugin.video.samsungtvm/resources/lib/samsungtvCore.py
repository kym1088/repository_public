__author__="NightRain"
NLHjXBAgOwQeIrvcWRKsdJinPmMuya=object
NLHjXBAgOwQeIrvcWRKsdJinPmMuyf=None
NLHjXBAgOwQeIrvcWRKsdJinPmMuyp=False
NLHjXBAgOwQeIrvcWRKsdJinPmMuyY=int
NLHjXBAgOwQeIrvcWRKsdJinPmMuyq=Exception
NLHjXBAgOwQeIrvcWRKsdJinPmMuyS=print
NLHjXBAgOwQeIrvcWRKsdJinPmMuyG=True
NLHjXBAgOwQeIrvcWRKsdJinPmMuyz=str
NLHjXBAgOwQeIrvcWRKsdJinPmMuyC=len
NLHjXBAgOwQeIrvcWRKsdJinPmMutl=range
import urllib
import re
import json
import requests
import datetime
import time
import zlib
import base64
class NLHjXBAgOwQeIrvcWRKsdJinPmMuly(NLHjXBAgOwQeIrvcWRKsdJinPmMuya):
 def __init__(NLHjXBAgOwQeIrvcWRKsdJinPmMult):
  NLHjXBAgOwQeIrvcWRKsdJinPmMult.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
  NLHjXBAgOwQeIrvcWRKsdJinPmMult.DEFAULT_HEADER ={'user-agent':NLHjXBAgOwQeIrvcWRKsdJinPmMult.USER_AGENT}
  NLHjXBAgOwQeIrvcWRKsdJinPmMult.API_DOMAIN ='https://www.samsungtvplus.com'
  NLHjXBAgOwQeIrvcWRKsdJinPmMult.SSTV={}
 def callRequestCookies(NLHjXBAgOwQeIrvcWRKsdJinPmMult,jobtype,NLHjXBAgOwQeIrvcWRKsdJinPmMulb,payload=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,params=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,headers=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,cookies=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,redirects=NLHjXBAgOwQeIrvcWRKsdJinPmMuyp):
  NLHjXBAgOwQeIrvcWRKsdJinPmMulD=NLHjXBAgOwQeIrvcWRKsdJinPmMult.DEFAULT_HEADER
  if headers:NLHjXBAgOwQeIrvcWRKsdJinPmMulD.update(headers)
  if jobtype=='Get':
   NLHjXBAgOwQeIrvcWRKsdJinPmMulU=requests.get(NLHjXBAgOwQeIrvcWRKsdJinPmMulb,params=params,headers=NLHjXBAgOwQeIrvcWRKsdJinPmMulD,cookies=cookies,allow_redirects=redirects)
  else:
   NLHjXBAgOwQeIrvcWRKsdJinPmMulU=requests.post(NLHjXBAgOwQeIrvcWRKsdJinPmMulb,data=payload,params=params,headers=NLHjXBAgOwQeIrvcWRKsdJinPmMulD,cookies=cookies,allow_redirects=redirects)
  return NLHjXBAgOwQeIrvcWRKsdJinPmMulU
 def Get_Now_Datetime(NLHjXBAgOwQeIrvcWRKsdJinPmMult):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(NLHjXBAgOwQeIrvcWRKsdJinPmMult):
  NLHjXBAgOwQeIrvcWRKsdJinPmMulo =NLHjXBAgOwQeIrvcWRKsdJinPmMuyY(time.time())
  NLHjXBAgOwQeIrvcWRKsdJinPmMulk=NLHjXBAgOwQeIrvcWRKsdJinPmMuyY(NLHjXBAgOwQeIrvcWRKsdJinPmMulo-NLHjXBAgOwQeIrvcWRKsdJinPmMulo%3600)
  return NLHjXBAgOwQeIrvcWRKsdJinPmMulk,NLHjXBAgOwQeIrvcWRKsdJinPmMulo
 def zlib_decompress(NLHjXBAgOwQeIrvcWRKsdJinPmMult,NLHjXBAgOwQeIrvcWRKsdJinPmMulF):
  NLHjXBAgOwQeIrvcWRKsdJinPmMulV=zlib.decompress(base64.standard_b64decode(NLHjXBAgOwQeIrvcWRKsdJinPmMulF))
  return NLHjXBAgOwQeIrvcWRKsdJinPmMulV.decode('utf-8')
 def zlib_compress(NLHjXBAgOwQeIrvcWRKsdJinPmMult,NLHjXBAgOwQeIrvcWRKsdJinPmMulV):
  NLHjXBAgOwQeIrvcWRKsdJinPmMulF=zlib.compress(NLHjXBAgOwQeIrvcWRKsdJinPmMulV.encode('utf-8'))
  return base64.standard_b64encode(NLHjXBAgOwQeIrvcWRKsdJinPmMulF).decode('utf-8')
 def makeDefaultCookies(NLHjXBAgOwQeIrvcWRKsdJinPmMult,vToken=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,vUserinfo=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf):
  NLHjXBAgOwQeIrvcWRKsdJinPmMulx={}
  if NLHjXBAgOwQeIrvcWRKsdJinPmMult.SSTV.get('session') !='':NLHjXBAgOwQeIrvcWRKsdJinPmMulx['session'] =NLHjXBAgOwQeIrvcWRKsdJinPmMult.SSTV.get('session')
  if NLHjXBAgOwQeIrvcWRKsdJinPmMult.SSTV.get('session.sig')!='':NLHjXBAgOwQeIrvcWRKsdJinPmMulx['session.sig']=NLHjXBAgOwQeIrvcWRKsdJinPmMult.SSTV.get('session.sig')
  return NLHjXBAgOwQeIrvcWRKsdJinPmMulx
 def Get_BaseCookies(NLHjXBAgOwQeIrvcWRKsdJinPmMult):
  try:
   NLHjXBAgOwQeIrvcWRKsdJinPmMulb=NLHjXBAgOwQeIrvcWRKsdJinPmMult.API_DOMAIN
   NLHjXBAgOwQeIrvcWRKsdJinPmMulE=NLHjXBAgOwQeIrvcWRKsdJinPmMult.callRequestCookies('Get',NLHjXBAgOwQeIrvcWRKsdJinPmMulb,payload=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,params=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,headers=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,cookies=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf)
   for NLHjXBAgOwQeIrvcWRKsdJinPmMulT in NLHjXBAgOwQeIrvcWRKsdJinPmMulE.cookies:
    if NLHjXBAgOwQeIrvcWRKsdJinPmMulT.name=='session':
     NLHjXBAgOwQeIrvcWRKsdJinPmMult.SSTV['session']=NLHjXBAgOwQeIrvcWRKsdJinPmMulT.value
    elif NLHjXBAgOwQeIrvcWRKsdJinPmMulT.name=='session.sig':
     NLHjXBAgOwQeIrvcWRKsdJinPmMult.SSTV['session.sig']=NLHjXBAgOwQeIrvcWRKsdJinPmMulT.value
  except NLHjXBAgOwQeIrvcWRKsdJinPmMuyq as exception:
   NLHjXBAgOwQeIrvcWRKsdJinPmMuyS(exception)
   return NLHjXBAgOwQeIrvcWRKsdJinPmMuyp
  try:
   NLHjXBAgOwQeIrvcWRKsdJinPmMulb=NLHjXBAgOwQeIrvcWRKsdJinPmMult.API_DOMAIN+'/user'
   NLHjXBAgOwQeIrvcWRKsdJinPmMulx=NLHjXBAgOwQeIrvcWRKsdJinPmMult.makeDefaultCookies()
   NLHjXBAgOwQeIrvcWRKsdJinPmMulE=NLHjXBAgOwQeIrvcWRKsdJinPmMult.callRequestCookies('Get',NLHjXBAgOwQeIrvcWRKsdJinPmMulb,payload=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,params=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,headers=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,cookies=NLHjXBAgOwQeIrvcWRKsdJinPmMulx)
   NLHjXBAgOwQeIrvcWRKsdJinPmMula=json.loads(NLHjXBAgOwQeIrvcWRKsdJinPmMulE.text)
   NLHjXBAgOwQeIrvcWRKsdJinPmMult.SSTV['countryCode']=NLHjXBAgOwQeIrvcWRKsdJinPmMula.get('countryCode')
   NLHjXBAgOwQeIrvcWRKsdJinPmMult.SSTV['uuid'] =NLHjXBAgOwQeIrvcWRKsdJinPmMula.get('uuid')
   NLHjXBAgOwQeIrvcWRKsdJinPmMult.SSTV['ip'] =NLHjXBAgOwQeIrvcWRKsdJinPmMula.get('ip')
  except NLHjXBAgOwQeIrvcWRKsdJinPmMuyq as exception:
   NLHjXBAgOwQeIrvcWRKsdJinPmMuyS(exception)
   return NLHjXBAgOwQeIrvcWRKsdJinPmMuyp
  return NLHjXBAgOwQeIrvcWRKsdJinPmMuyG
 def Get_BaseJson_Request(NLHjXBAgOwQeIrvcWRKsdJinPmMult):
  NLHjXBAgOwQeIrvcWRKsdJinPmMula={}
  try:
   NLHjXBAgOwQeIrvcWRKsdJinPmMulb=NLHjXBAgOwQeIrvcWRKsdJinPmMult.API_DOMAIN+'/api/lives'
   NLHjXBAgOwQeIrvcWRKsdJinPmMulk,NLHjXBAgOwQeIrvcWRKsdJinPmMulo=NLHjXBAgOwQeIrvcWRKsdJinPmMult.GetNoCache()
   NLHjXBAgOwQeIrvcWRKsdJinPmMulf=NLHjXBAgOwQeIrvcWRKsdJinPmMult.zlib_compress(NLHjXBAgOwQeIrvcWRKsdJinPmMult.SSTV['uuid']+':'+NLHjXBAgOwQeIrvcWRKsdJinPmMuyz(NLHjXBAgOwQeIrvcWRKsdJinPmMulo))
   NLHjXBAgOwQeIrvcWRKsdJinPmMulx =NLHjXBAgOwQeIrvcWRKsdJinPmMult.makeDefaultCookies()
   NLHjXBAgOwQeIrvcWRKsdJinPmMulp ={'t':NLHjXBAgOwQeIrvcWRKsdJinPmMuyz(NLHjXBAgOwQeIrvcWRKsdJinPmMulk)}
   NLHjXBAgOwQeIrvcWRKsdJinPmMulY ={'x-cred-payload':NLHjXBAgOwQeIrvcWRKsdJinPmMulf}
   NLHjXBAgOwQeIrvcWRKsdJinPmMulE=NLHjXBAgOwQeIrvcWRKsdJinPmMult.callRequestCookies('Get',NLHjXBAgOwQeIrvcWRKsdJinPmMulb,payload=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,params=NLHjXBAgOwQeIrvcWRKsdJinPmMulp,headers=NLHjXBAgOwQeIrvcWRKsdJinPmMulY,cookies=NLHjXBAgOwQeIrvcWRKsdJinPmMulx)
   NLHjXBAgOwQeIrvcWRKsdJinPmMula=json.loads(NLHjXBAgOwQeIrvcWRKsdJinPmMulE.text)
  except NLHjXBAgOwQeIrvcWRKsdJinPmMuyq as exception:
   NLHjXBAgOwQeIrvcWRKsdJinPmMuyS(exception)
  return NLHjXBAgOwQeIrvcWRKsdJinPmMula
 def GetGenreList(NLHjXBAgOwQeIrvcWRKsdJinPmMult):
  NLHjXBAgOwQeIrvcWRKsdJinPmMulq=[]
  try:
   NLHjXBAgOwQeIrvcWRKsdJinPmMula=NLHjXBAgOwQeIrvcWRKsdJinPmMult.Get_BaseJson_Request()
   NLHjXBAgOwQeIrvcWRKsdJinPmMulS=NLHjXBAgOwQeIrvcWRKsdJinPmMula['live']['genrelist']
   for NLHjXBAgOwQeIrvcWRKsdJinPmMulG in NLHjXBAgOwQeIrvcWRKsdJinPmMulS:
    NLHjXBAgOwQeIrvcWRKsdJinPmMulz={'genre':NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('name'),}
    NLHjXBAgOwQeIrvcWRKsdJinPmMulq.append(NLHjXBAgOwQeIrvcWRKsdJinPmMulz)
  except NLHjXBAgOwQeIrvcWRKsdJinPmMuyq as exception:
   NLHjXBAgOwQeIrvcWRKsdJinPmMuyS(exception)
  return NLHjXBAgOwQeIrvcWRKsdJinPmMulq
 def GetLiveChannelList(NLHjXBAgOwQeIrvcWRKsdJinPmMult,view_genre='-'):
  NLHjXBAgOwQeIrvcWRKsdJinPmMulq=[]
  try:
   NLHjXBAgOwQeIrvcWRKsdJinPmMula=NLHjXBAgOwQeIrvcWRKsdJinPmMult.Get_BaseJson_Request()
   NLHjXBAgOwQeIrvcWRKsdJinPmMulS=NLHjXBAgOwQeIrvcWRKsdJinPmMula['live']['channel']
   for NLHjXBAgOwQeIrvcWRKsdJinPmMulG in NLHjXBAgOwQeIrvcWRKsdJinPmMulS:
    NLHjXBAgOwQeIrvcWRKsdJinPmMulC=NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('genre').get('name')
    if NLHjXBAgOwQeIrvcWRKsdJinPmMulC!=view_genre and view_genre!='-':continue
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyl=NLHjXBAgOwQeIrvcWRKsdJinPmMult.Make_EpgList(NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('program'))
    if NLHjXBAgOwQeIrvcWRKsdJinPmMuyC(NLHjXBAgOwQeIrvcWRKsdJinPmMuyl)>1:
     NLHjXBAgOwQeIrvcWRKsdJinPmMuyt=NLHjXBAgOwQeIrvcWRKsdJinPmMuyl[0].get('endtm').replace('-','').replace(':','').replace(' ','')
     NLHjXBAgOwQeIrvcWRKsdJinPmMulo=NLHjXBAgOwQeIrvcWRKsdJinPmMult.Get_Now_Datetime().strftime('%Y%m%d%H%M')
     if NLHjXBAgOwQeIrvcWRKsdJinPmMuyY(NLHjXBAgOwQeIrvcWRKsdJinPmMuyt)<NLHjXBAgOwQeIrvcWRKsdJinPmMuyY(NLHjXBAgOwQeIrvcWRKsdJinPmMulo):
      NLHjXBAgOwQeIrvcWRKsdJinPmMuyl.pop(0)
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyD =NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('logo')
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyU=NLHjXBAgOwQeIrvcWRKsdJinPmMuyl[0].get('thumbnail')
    NLHjXBAgOwQeIrvcWRKsdJinPmMulz={'chid':NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('id'),'channlnm':NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('name'),'genre':NLHjXBAgOwQeIrvcWRKsdJinPmMulC,'programnm':NLHjXBAgOwQeIrvcWRKsdJinPmMuyl[0].get('title'),'thumbnail':{'thumb':NLHjXBAgOwQeIrvcWRKsdJinPmMuyU,'clearlogo':NLHjXBAgOwQeIrvcWRKsdJinPmMuyD,'icon':NLHjXBAgOwQeIrvcWRKsdJinPmMuyD,'fanart':NLHjXBAgOwQeIrvcWRKsdJinPmMuyU},'epg':NLHjXBAgOwQeIrvcWRKsdJinPmMult.Make_EpgString(NLHjXBAgOwQeIrvcWRKsdJinPmMuyl),}
    NLHjXBAgOwQeIrvcWRKsdJinPmMulq.append(NLHjXBAgOwQeIrvcWRKsdJinPmMulz)
  except NLHjXBAgOwQeIrvcWRKsdJinPmMuyq as exception:
   NLHjXBAgOwQeIrvcWRKsdJinPmMuyS(exception)
  return NLHjXBAgOwQeIrvcWRKsdJinPmMulq
 def Make_EpgList(NLHjXBAgOwQeIrvcWRKsdJinPmMult,programList):
  NLHjXBAgOwQeIrvcWRKsdJinPmMuyl=[]
  try:
   for NLHjXBAgOwQeIrvcWRKsdJinPmMulG in programList:
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyh=NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('start_time')
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyo =NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('duration') 
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyk=datetime.datetime.strptime(NLHjXBAgOwQeIrvcWRKsdJinPmMuyh,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyt =NLHjXBAgOwQeIrvcWRKsdJinPmMuyk+datetime.timedelta(seconds=NLHjXBAgOwQeIrvcWRKsdJinPmMuyo)
    NLHjXBAgOwQeIrvcWRKsdJinPmMulz={'title':NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('title'),'starttm':NLHjXBAgOwQeIrvcWRKsdJinPmMuyk.strftime('%Y-%m-%d %H:%M'),'endtm':NLHjXBAgOwQeIrvcWRKsdJinPmMuyt.strftime('%Y-%m-%d %H:%M'),'thumbnail':NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('thumbnail'),}
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyl.append(NLHjXBAgOwQeIrvcWRKsdJinPmMulz)
  except NLHjXBAgOwQeIrvcWRKsdJinPmMuyq as exception:
   NLHjXBAgOwQeIrvcWRKsdJinPmMuyS(exception)
  return NLHjXBAgOwQeIrvcWRKsdJinPmMuyl
 def Make_EpgString(NLHjXBAgOwQeIrvcWRKsdJinPmMult,NLHjXBAgOwQeIrvcWRKsdJinPmMuyl):
  NLHjXBAgOwQeIrvcWRKsdJinPmMuyV=''
  try:
   for i in NLHjXBAgOwQeIrvcWRKsdJinPmMutl(NLHjXBAgOwQeIrvcWRKsdJinPmMuyC(NLHjXBAgOwQeIrvcWRKsdJinPmMuyl)):
    if i>3:break
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyF=NLHjXBAgOwQeIrvcWRKsdJinPmMuyl[i].get('starttm')[-5:]
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyx =NLHjXBAgOwQeIrvcWRKsdJinPmMuyl[i].get('endtm')[-5:]
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyb =NLHjXBAgOwQeIrvcWRKsdJinPmMuyl[i].get('title')
    NLHjXBAgOwQeIrvcWRKsdJinPmMuyV+='%s\n[%s ~ %s]\n\n'%(NLHjXBAgOwQeIrvcWRKsdJinPmMuyb,NLHjXBAgOwQeIrvcWRKsdJinPmMuyF,NLHjXBAgOwQeIrvcWRKsdJinPmMuyx)
  except NLHjXBAgOwQeIrvcWRKsdJinPmMuyq as exception:
   NLHjXBAgOwQeIrvcWRKsdJinPmMuyS(exception)
  return NLHjXBAgOwQeIrvcWRKsdJinPmMuyV
 def GetBroadURL(NLHjXBAgOwQeIrvcWRKsdJinPmMult,chid):
  NLHjXBAgOwQeIrvcWRKsdJinPmMuyE=''
  try:
   NLHjXBAgOwQeIrvcWRKsdJinPmMula=NLHjXBAgOwQeIrvcWRKsdJinPmMult.Get_BaseJson_Request()
   NLHjXBAgOwQeIrvcWRKsdJinPmMulS=NLHjXBAgOwQeIrvcWRKsdJinPmMula['live']['channel']
   for NLHjXBAgOwQeIrvcWRKsdJinPmMulG in NLHjXBAgOwQeIrvcWRKsdJinPmMulS:
    if NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('id')==chid:
     NLHjXBAgOwQeIrvcWRKsdJinPmMuyT =NLHjXBAgOwQeIrvcWRKsdJinPmMulG.get('program')[0].get('stream_url_new')
     NLHjXBAgOwQeIrvcWRKsdJinPmMuyE=NLHjXBAgOwQeIrvcWRKsdJinPmMult.zlib_decompress(NLHjXBAgOwQeIrvcWRKsdJinPmMuyT)
     break
  except NLHjXBAgOwQeIrvcWRKsdJinPmMuyq as exception:
   NLHjXBAgOwQeIrvcWRKsdJinPmMuyS(exception)
  return NLHjXBAgOwQeIrvcWRKsdJinPmMuyE
 def GetTest(NLHjXBAgOwQeIrvcWRKsdJinPmMult,streamurl):
  try:
   NLHjXBAgOwQeIrvcWRKsdJinPmMulb=NLHjXBAgOwQeIrvcWRKsdJinPmMult.zlib_decompress(streamurl)
   NLHjXBAgOwQeIrvcWRKsdJinPmMuyS(NLHjXBAgOwQeIrvcWRKsdJinPmMulb)
   NLHjXBAgOwQeIrvcWRKsdJinPmMulb='https://play-kr.samsungtvplus.com/tvplus/web/v3/play?tid=eVFDcm9hRjhaR1RVNHAva2JJWTR3dm5YWGo3SWlIekpoUENlbmRaaDVCRXROSU9DbWRoT3lKN3JHbGdnU1BSTUlzUHptbFBGS01qWG9hYjdoZElQTXRrZ3ozbXlsUkdIOHoxTGxDcGRsekhnaXJ0Q21qUU1ycWNZdURmWjhidUxyZFpxUjdiODFUZEs1NFFBYm9hWnBPL2gvZXRINWZ0cVJhMFA3RjFZUXU2NVJtZVpZZGl6VjhmUXhCWnVWaEQwZjV2L1hTeUhOblN1akRLR2dsYzVvQzREclhUYzdOc1NzUlZkTVp5UnF6OG5HWERDRjR0dHVDUmxuRVpjbk81eSt1RXhiZkN5aHJUZWRyemdSWWloQURyTnZmRlFwQnVVZTdzay9Ob2ZBekk9'
   NLHjXBAgOwQeIrvcWRKsdJinPmMulY ={'origin':NLHjXBAgOwQeIrvcWRKsdJinPmMult.API_DOMAIN}
   NLHjXBAgOwQeIrvcWRKsdJinPmMulE=NLHjXBAgOwQeIrvcWRKsdJinPmMult.callRequestCookies('Get',NLHjXBAgOwQeIrvcWRKsdJinPmMulb,payload=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,params=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf,headers=NLHjXBAgOwQeIrvcWRKsdJinPmMulY,cookies=NLHjXBAgOwQeIrvcWRKsdJinPmMuyf)
   NLHjXBAgOwQeIrvcWRKsdJinPmMuyS(NLHjXBAgOwQeIrvcWRKsdJinPmMulE.text)
  except NLHjXBAgOwQeIrvcWRKsdJinPmMuyq as exception:
   NLHjXBAgOwQeIrvcWRKsdJinPmMuyS(exception)
  return
# Created by pyminifier (https://github.com/liftoff/pyminifier)
