__author__="NightRain"
iQmhRWgPtojCxAVGXrekSTEysnpvNu=object
iQmhRWgPtojCxAVGXrekSTEysnpvNI=None
iQmhRWgPtojCxAVGXrekSTEysnpvNf=False
iQmhRWgPtojCxAVGXrekSTEysnpvNO=int
iQmhRWgPtojCxAVGXrekSTEysnpvNY=Exception
iQmhRWgPtojCxAVGXrekSTEysnpvNH=print
iQmhRWgPtojCxAVGXrekSTEysnpvND=True
iQmhRWgPtojCxAVGXrekSTEysnpvNq=str
iQmhRWgPtojCxAVGXrekSTEysnpvNJ=len
iQmhRWgPtojCxAVGXrekSTEysnpvKa=range
import urllib
import re
import json
import requests
import datetime
import time
import zlib
import base64
class iQmhRWgPtojCxAVGXrekSTEysnpvaN(iQmhRWgPtojCxAVGXrekSTEysnpvNu):
 def __init__(iQmhRWgPtojCxAVGXrekSTEysnpvaK):
  iQmhRWgPtojCxAVGXrekSTEysnpvaK.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
  iQmhRWgPtojCxAVGXrekSTEysnpvaK.DEFAULT_HEADER ={'user-agent':iQmhRWgPtojCxAVGXrekSTEysnpvaK.USER_AGENT}
  iQmhRWgPtojCxAVGXrekSTEysnpvaK.API_DOMAIN ='https://www.samsungtvplus.com'
  iQmhRWgPtojCxAVGXrekSTEysnpvaK.SSTV={}
 def callRequestCookies(iQmhRWgPtojCxAVGXrekSTEysnpvaK,jobtype,iQmhRWgPtojCxAVGXrekSTEysnpvaz,payload=iQmhRWgPtojCxAVGXrekSTEysnpvNI,params=iQmhRWgPtojCxAVGXrekSTEysnpvNI,headers=iQmhRWgPtojCxAVGXrekSTEysnpvNI,cookies=iQmhRWgPtojCxAVGXrekSTEysnpvNI,redirects=iQmhRWgPtojCxAVGXrekSTEysnpvNf):
  iQmhRWgPtojCxAVGXrekSTEysnpvaF=iQmhRWgPtojCxAVGXrekSTEysnpvaK.DEFAULT_HEADER
  if headers:iQmhRWgPtojCxAVGXrekSTEysnpvaF.update(headers)
  if jobtype=='Get':
   iQmhRWgPtojCxAVGXrekSTEysnpvab=requests.get(iQmhRWgPtojCxAVGXrekSTEysnpvaz,params=params,headers=iQmhRWgPtojCxAVGXrekSTEysnpvaF,cookies=cookies,allow_redirects=redirects)
  else:
   iQmhRWgPtojCxAVGXrekSTEysnpvab=requests.post(iQmhRWgPtojCxAVGXrekSTEysnpvaz,data=payload,params=params,headers=iQmhRWgPtojCxAVGXrekSTEysnpvaF,cookies=cookies,allow_redirects=redirects)
  return iQmhRWgPtojCxAVGXrekSTEysnpvab
 def Get_Now_Datetime(iQmhRWgPtojCxAVGXrekSTEysnpvaK):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(iQmhRWgPtojCxAVGXrekSTEysnpvaK):
  iQmhRWgPtojCxAVGXrekSTEysnpval =iQmhRWgPtojCxAVGXrekSTEysnpvNO(time.time())
  iQmhRWgPtojCxAVGXrekSTEysnpvaL=iQmhRWgPtojCxAVGXrekSTEysnpvNO(iQmhRWgPtojCxAVGXrekSTEysnpval-iQmhRWgPtojCxAVGXrekSTEysnpval%3600)
  return iQmhRWgPtojCxAVGXrekSTEysnpvaL,iQmhRWgPtojCxAVGXrekSTEysnpval
 def zlib_decompress(iQmhRWgPtojCxAVGXrekSTEysnpvaK,iQmhRWgPtojCxAVGXrekSTEysnpvaB):
  iQmhRWgPtojCxAVGXrekSTEysnpvaM=zlib.decompress(base64.standard_b64decode(iQmhRWgPtojCxAVGXrekSTEysnpvaB))
  return iQmhRWgPtojCxAVGXrekSTEysnpvaM.decode('utf-8')
 def zlib_compress(iQmhRWgPtojCxAVGXrekSTEysnpvaK,iQmhRWgPtojCxAVGXrekSTEysnpvaM):
  iQmhRWgPtojCxAVGXrekSTEysnpvaB=zlib.compress(iQmhRWgPtojCxAVGXrekSTEysnpvaM.encode('utf-8'))
  return base64.standard_b64encode(iQmhRWgPtojCxAVGXrekSTEysnpvaB).decode('utf-8')
 def makeDefaultCookies(iQmhRWgPtojCxAVGXrekSTEysnpvaK,vToken=iQmhRWgPtojCxAVGXrekSTEysnpvNI,vUserinfo=iQmhRWgPtojCxAVGXrekSTEysnpvNI):
  iQmhRWgPtojCxAVGXrekSTEysnpvaw={}
  if iQmhRWgPtojCxAVGXrekSTEysnpvaK.SSTV.get('session') !='':iQmhRWgPtojCxAVGXrekSTEysnpvaw['session'] =iQmhRWgPtojCxAVGXrekSTEysnpvaK.SSTV.get('session')
  if iQmhRWgPtojCxAVGXrekSTEysnpvaK.SSTV.get('session.sig')!='':iQmhRWgPtojCxAVGXrekSTEysnpvaw['session.sig']=iQmhRWgPtojCxAVGXrekSTEysnpvaK.SSTV.get('session.sig')
  return iQmhRWgPtojCxAVGXrekSTEysnpvaw
 def Get_BaseCookies(iQmhRWgPtojCxAVGXrekSTEysnpvaK):
  try:
   iQmhRWgPtojCxAVGXrekSTEysnpvaz=iQmhRWgPtojCxAVGXrekSTEysnpvaK.API_DOMAIN
   iQmhRWgPtojCxAVGXrekSTEysnpvac=iQmhRWgPtojCxAVGXrekSTEysnpvaK.callRequestCookies('Get',iQmhRWgPtojCxAVGXrekSTEysnpvaz,payload=iQmhRWgPtojCxAVGXrekSTEysnpvNI,params=iQmhRWgPtojCxAVGXrekSTEysnpvNI,headers=iQmhRWgPtojCxAVGXrekSTEysnpvNI,cookies=iQmhRWgPtojCxAVGXrekSTEysnpvNI)
   for iQmhRWgPtojCxAVGXrekSTEysnpvaU in iQmhRWgPtojCxAVGXrekSTEysnpvac.cookies:
    if iQmhRWgPtojCxAVGXrekSTEysnpvaU.name=='session':
     iQmhRWgPtojCxAVGXrekSTEysnpvaK.SSTV['session']=iQmhRWgPtojCxAVGXrekSTEysnpvaU.value
    elif iQmhRWgPtojCxAVGXrekSTEysnpvaU.name=='session.sig':
     iQmhRWgPtojCxAVGXrekSTEysnpvaK.SSTV['session.sig']=iQmhRWgPtojCxAVGXrekSTEysnpvaU.value
  except iQmhRWgPtojCxAVGXrekSTEysnpvNY as exception:
   iQmhRWgPtojCxAVGXrekSTEysnpvNH(exception)
   return iQmhRWgPtojCxAVGXrekSTEysnpvNf
  try:
   iQmhRWgPtojCxAVGXrekSTEysnpvaz=iQmhRWgPtojCxAVGXrekSTEysnpvaK.API_DOMAIN+'/user'
   iQmhRWgPtojCxAVGXrekSTEysnpvaw=iQmhRWgPtojCxAVGXrekSTEysnpvaK.makeDefaultCookies()
   iQmhRWgPtojCxAVGXrekSTEysnpvac=iQmhRWgPtojCxAVGXrekSTEysnpvaK.callRequestCookies('Get',iQmhRWgPtojCxAVGXrekSTEysnpvaz,payload=iQmhRWgPtojCxAVGXrekSTEysnpvNI,params=iQmhRWgPtojCxAVGXrekSTEysnpvNI,headers=iQmhRWgPtojCxAVGXrekSTEysnpvNI,cookies=iQmhRWgPtojCxAVGXrekSTEysnpvaw)
   iQmhRWgPtojCxAVGXrekSTEysnpvau=json.loads(iQmhRWgPtojCxAVGXrekSTEysnpvac.text)
   iQmhRWgPtojCxAVGXrekSTEysnpvaK.SSTV['countryCode']=iQmhRWgPtojCxAVGXrekSTEysnpvau.get('countryCode')
   iQmhRWgPtojCxAVGXrekSTEysnpvaK.SSTV['uuid'] =iQmhRWgPtojCxAVGXrekSTEysnpvau.get('uuid')
   iQmhRWgPtojCxAVGXrekSTEysnpvaK.SSTV['ip'] =iQmhRWgPtojCxAVGXrekSTEysnpvau.get('ip')
  except iQmhRWgPtojCxAVGXrekSTEysnpvNY as exception:
   iQmhRWgPtojCxAVGXrekSTEysnpvNH(exception)
   return iQmhRWgPtojCxAVGXrekSTEysnpvNf
  return iQmhRWgPtojCxAVGXrekSTEysnpvND
 def Get_BaseJson_Request(iQmhRWgPtojCxAVGXrekSTEysnpvaK):
  iQmhRWgPtojCxAVGXrekSTEysnpvau={}
  try:
   iQmhRWgPtojCxAVGXrekSTEysnpvaz=iQmhRWgPtojCxAVGXrekSTEysnpvaK.API_DOMAIN+'/api/lives'
   iQmhRWgPtojCxAVGXrekSTEysnpvaL,iQmhRWgPtojCxAVGXrekSTEysnpval=iQmhRWgPtojCxAVGXrekSTEysnpvaK.GetNoCache()
   iQmhRWgPtojCxAVGXrekSTEysnpvaI=iQmhRWgPtojCxAVGXrekSTEysnpvaK.zlib_compress(iQmhRWgPtojCxAVGXrekSTEysnpvaK.SSTV['uuid']+':'+iQmhRWgPtojCxAVGXrekSTEysnpvNq(iQmhRWgPtojCxAVGXrekSTEysnpval))
   iQmhRWgPtojCxAVGXrekSTEysnpvaw =iQmhRWgPtojCxAVGXrekSTEysnpvaK.makeDefaultCookies()
   iQmhRWgPtojCxAVGXrekSTEysnpvaf ={'t':iQmhRWgPtojCxAVGXrekSTEysnpvNq(iQmhRWgPtojCxAVGXrekSTEysnpvaL)}
   iQmhRWgPtojCxAVGXrekSTEysnpvaO ={'x-cred-payload':iQmhRWgPtojCxAVGXrekSTEysnpvaI}
   iQmhRWgPtojCxAVGXrekSTEysnpvac=iQmhRWgPtojCxAVGXrekSTEysnpvaK.callRequestCookies('Get',iQmhRWgPtojCxAVGXrekSTEysnpvaz,payload=iQmhRWgPtojCxAVGXrekSTEysnpvNI,params=iQmhRWgPtojCxAVGXrekSTEysnpvaf,headers=iQmhRWgPtojCxAVGXrekSTEysnpvaO,cookies=iQmhRWgPtojCxAVGXrekSTEysnpvaw)
   iQmhRWgPtojCxAVGXrekSTEysnpvau=json.loads(iQmhRWgPtojCxAVGXrekSTEysnpvac.text)
  except iQmhRWgPtojCxAVGXrekSTEysnpvNY as exception:
   iQmhRWgPtojCxAVGXrekSTEysnpvNH(exception)
  return iQmhRWgPtojCxAVGXrekSTEysnpvau
 def GetGenreList(iQmhRWgPtojCxAVGXrekSTEysnpvaK):
  iQmhRWgPtojCxAVGXrekSTEysnpvaY=[]
  try:
   iQmhRWgPtojCxAVGXrekSTEysnpvau=iQmhRWgPtojCxAVGXrekSTEysnpvaK.Get_BaseJson_Request()
   iQmhRWgPtojCxAVGXrekSTEysnpvaH=iQmhRWgPtojCxAVGXrekSTEysnpvau['live']['genrelist']
   for iQmhRWgPtojCxAVGXrekSTEysnpvaD in iQmhRWgPtojCxAVGXrekSTEysnpvaH:
    iQmhRWgPtojCxAVGXrekSTEysnpvaq={'genre':iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('name'),}
    iQmhRWgPtojCxAVGXrekSTEysnpvaY.append(iQmhRWgPtojCxAVGXrekSTEysnpvaq)
  except iQmhRWgPtojCxAVGXrekSTEysnpvNY as exception:
   iQmhRWgPtojCxAVGXrekSTEysnpvNH(exception)
  return iQmhRWgPtojCxAVGXrekSTEysnpvaY
 def GetLiveChannelList(iQmhRWgPtojCxAVGXrekSTEysnpvaK,view_genre='-'):
  iQmhRWgPtojCxAVGXrekSTEysnpvaY=[]
  try:
   iQmhRWgPtojCxAVGXrekSTEysnpvau=iQmhRWgPtojCxAVGXrekSTEysnpvaK.Get_BaseJson_Request()
   iQmhRWgPtojCxAVGXrekSTEysnpvaH=iQmhRWgPtojCxAVGXrekSTEysnpvau['live']['channel']
   for iQmhRWgPtojCxAVGXrekSTEysnpvaD in iQmhRWgPtojCxAVGXrekSTEysnpvaH:
    iQmhRWgPtojCxAVGXrekSTEysnpvaJ=iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('genre').get('name')
    if iQmhRWgPtojCxAVGXrekSTEysnpvaJ!=view_genre and view_genre!='-':continue
    iQmhRWgPtojCxAVGXrekSTEysnpvNa=iQmhRWgPtojCxAVGXrekSTEysnpvaK.Make_EpgList(iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('program'))
    if iQmhRWgPtojCxAVGXrekSTEysnpvNJ(iQmhRWgPtojCxAVGXrekSTEysnpvNa)>1:
     iQmhRWgPtojCxAVGXrekSTEysnpvNK=iQmhRWgPtojCxAVGXrekSTEysnpvNa[0].get('endtm').replace('-','').replace(':','').replace(' ','')
     iQmhRWgPtojCxAVGXrekSTEysnpval=iQmhRWgPtojCxAVGXrekSTEysnpvaK.Get_Now_Datetime().strftime('%Y%m%d%H%M')
     if iQmhRWgPtojCxAVGXrekSTEysnpvNO(iQmhRWgPtojCxAVGXrekSTEysnpvNK)<iQmhRWgPtojCxAVGXrekSTEysnpvNO(iQmhRWgPtojCxAVGXrekSTEysnpval):
      iQmhRWgPtojCxAVGXrekSTEysnpvNa.pop(0)
    iQmhRWgPtojCxAVGXrekSTEysnpvNF =iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('logo')
    iQmhRWgPtojCxAVGXrekSTEysnpvNb=iQmhRWgPtojCxAVGXrekSTEysnpvNa[0].get('thumbnail')
    iQmhRWgPtojCxAVGXrekSTEysnpvaq={'chid':iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('id'),'channlnm':iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('name'),'genre':iQmhRWgPtojCxAVGXrekSTEysnpvaJ,'programnm':iQmhRWgPtojCxAVGXrekSTEysnpvNa[0].get('title'),'thumbnail':{'thumb':iQmhRWgPtojCxAVGXrekSTEysnpvNb,'clearlogo':iQmhRWgPtojCxAVGXrekSTEysnpvNF,'icon':iQmhRWgPtojCxAVGXrekSTEysnpvNF,'fanart':iQmhRWgPtojCxAVGXrekSTEysnpvNb},'epg':iQmhRWgPtojCxAVGXrekSTEysnpvaK.Make_EpgString(iQmhRWgPtojCxAVGXrekSTEysnpvNa),}
    iQmhRWgPtojCxAVGXrekSTEysnpvaY.append(iQmhRWgPtojCxAVGXrekSTEysnpvaq)
  except iQmhRWgPtojCxAVGXrekSTEysnpvNY as exception:
   iQmhRWgPtojCxAVGXrekSTEysnpvNH(exception)
  return iQmhRWgPtojCxAVGXrekSTEysnpvaY
 def Make_EpgList(iQmhRWgPtojCxAVGXrekSTEysnpvaK,programList):
  iQmhRWgPtojCxAVGXrekSTEysnpvNa=[]
  try:
   for iQmhRWgPtojCxAVGXrekSTEysnpvaD in programList:
    iQmhRWgPtojCxAVGXrekSTEysnpvNd=iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('start_time')
    iQmhRWgPtojCxAVGXrekSTEysnpvNl =iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('duration') 
    iQmhRWgPtojCxAVGXrekSTEysnpvNL=datetime.datetime.strptime(iQmhRWgPtojCxAVGXrekSTEysnpvNd,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
    iQmhRWgPtojCxAVGXrekSTEysnpvNK =iQmhRWgPtojCxAVGXrekSTEysnpvNL+datetime.timedelta(seconds=iQmhRWgPtojCxAVGXrekSTEysnpvNl)
    iQmhRWgPtojCxAVGXrekSTEysnpvaq={'title':iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('title'),'starttm':iQmhRWgPtojCxAVGXrekSTEysnpvNL.strftime('%Y-%m-%d %H:%M'),'endtm':iQmhRWgPtojCxAVGXrekSTEysnpvNK.strftime('%Y-%m-%d %H:%M'),'thumbnail':iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('thumbnail'),}
    iQmhRWgPtojCxAVGXrekSTEysnpvNa.append(iQmhRWgPtojCxAVGXrekSTEysnpvaq)
  except iQmhRWgPtojCxAVGXrekSTEysnpvNY as exception:
   iQmhRWgPtojCxAVGXrekSTEysnpvNH(exception)
  return iQmhRWgPtojCxAVGXrekSTEysnpvNa
 def Make_EpgString(iQmhRWgPtojCxAVGXrekSTEysnpvaK,iQmhRWgPtojCxAVGXrekSTEysnpvNa):
  iQmhRWgPtojCxAVGXrekSTEysnpvNM=''
  try:
   for i in iQmhRWgPtojCxAVGXrekSTEysnpvKa(iQmhRWgPtojCxAVGXrekSTEysnpvNJ(iQmhRWgPtojCxAVGXrekSTEysnpvNa)):
    if i>3:break
    iQmhRWgPtojCxAVGXrekSTEysnpvNB=iQmhRWgPtojCxAVGXrekSTEysnpvNa[i].get('starttm')[-5:]
    iQmhRWgPtojCxAVGXrekSTEysnpvNw =iQmhRWgPtojCxAVGXrekSTEysnpvNa[i].get('endtm')[-5:]
    iQmhRWgPtojCxAVGXrekSTEysnpvNz =iQmhRWgPtojCxAVGXrekSTEysnpvNa[i].get('title')
    iQmhRWgPtojCxAVGXrekSTEysnpvNM+='%s\n[%s ~ %s]\n\n'%(iQmhRWgPtojCxAVGXrekSTEysnpvNz,iQmhRWgPtojCxAVGXrekSTEysnpvNB,iQmhRWgPtojCxAVGXrekSTEysnpvNw)
  except iQmhRWgPtojCxAVGXrekSTEysnpvNY as exception:
   iQmhRWgPtojCxAVGXrekSTEysnpvNH(exception)
  return iQmhRWgPtojCxAVGXrekSTEysnpvNM
 def GetBroadURL(iQmhRWgPtojCxAVGXrekSTEysnpvaK,chid):
  iQmhRWgPtojCxAVGXrekSTEysnpvNc=''
  try:
   iQmhRWgPtojCxAVGXrekSTEysnpvau=iQmhRWgPtojCxAVGXrekSTEysnpvaK.Get_BaseJson_Request()
   iQmhRWgPtojCxAVGXrekSTEysnpvaH=iQmhRWgPtojCxAVGXrekSTEysnpvau['live']['channel']
   for iQmhRWgPtojCxAVGXrekSTEysnpvaD in iQmhRWgPtojCxAVGXrekSTEysnpvaH:
    if iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('id')==chid:
     iQmhRWgPtojCxAVGXrekSTEysnpvNU =iQmhRWgPtojCxAVGXrekSTEysnpvaD.get('program')[0].get('stream_url_new')
     iQmhRWgPtojCxAVGXrekSTEysnpvNc=iQmhRWgPtojCxAVGXrekSTEysnpvaK.zlib_decompress(iQmhRWgPtojCxAVGXrekSTEysnpvNU)
     break
  except iQmhRWgPtojCxAVGXrekSTEysnpvNY as exception:
   iQmhRWgPtojCxAVGXrekSTEysnpvNH(exception)
  return iQmhRWgPtojCxAVGXrekSTEysnpvNc
 def GetTest(iQmhRWgPtojCxAVGXrekSTEysnpvaK,streamurl):
  try:
   iQmhRWgPtojCxAVGXrekSTEysnpvaz=iQmhRWgPtojCxAVGXrekSTEysnpvaK.zlib_decompress(streamurl)
   iQmhRWgPtojCxAVGXrekSTEysnpvNH(iQmhRWgPtojCxAVGXrekSTEysnpvaz)
   iQmhRWgPtojCxAVGXrekSTEysnpvaz='https://play-kr.samsungtvplus.com/tvplus/web/v3/play?tid=eVFDcm9hRjhaR1RVNHAva2JJWTR3dm5YWGo3SWlIekpoUENlbmRaaDVCRXROSU9DbWRoT3lKN3JHbGdnU1BSTUlzUHptbFBGS01qWG9hYjdoZElQTXRrZ3ozbXlsUkdIOHoxTGxDcGRsekhnaXJ0Q21qUU1ycWNZdURmWjhidUxyZFpxUjdiODFUZEs1NFFBYm9hWnBPL2gvZXRINWZ0cVJhMFA3RjFZUXU2NVJtZVpZZGl6VjhmUXhCWnVWaEQwZjV2L1hTeUhOblN1akRLR2dsYzVvQzREclhUYzdOc1NzUlZkTVp5UnF6OG5HWERDRjR0dHVDUmxuRVpjbk81eSt1RXhiZkN5aHJUZWRyemdSWWloQURyTnZmRlFwQnVVZTdzay9Ob2ZBekk9'
   iQmhRWgPtojCxAVGXrekSTEysnpvaO ={'origin':iQmhRWgPtojCxAVGXrekSTEysnpvaK.API_DOMAIN}
   iQmhRWgPtojCxAVGXrekSTEysnpvac=iQmhRWgPtojCxAVGXrekSTEysnpvaK.callRequestCookies('Get',iQmhRWgPtojCxAVGXrekSTEysnpvaz,payload=iQmhRWgPtojCxAVGXrekSTEysnpvNI,params=iQmhRWgPtojCxAVGXrekSTEysnpvNI,headers=iQmhRWgPtojCxAVGXrekSTEysnpvaO,cookies=iQmhRWgPtojCxAVGXrekSTEysnpvNI)
   iQmhRWgPtojCxAVGXrekSTEysnpvNH(iQmhRWgPtojCxAVGXrekSTEysnpvac.text)
  except iQmhRWgPtojCxAVGXrekSTEysnpvNY as exception:
   iQmhRWgPtojCxAVGXrekSTEysnpvNH(exception)
  return
# Created by pyminifier (https://github.com/liftoff/pyminifier)
