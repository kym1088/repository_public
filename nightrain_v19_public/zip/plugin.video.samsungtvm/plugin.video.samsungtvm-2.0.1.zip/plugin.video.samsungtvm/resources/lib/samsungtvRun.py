__author__="NightRain"
FELbqOoVtDcvmyunhkpMCXfQSHAeBT=object
FELbqOoVtDcvmyunhkpMCXfQSHAeBG=None
FELbqOoVtDcvmyunhkpMCXfQSHAezs=True
FELbqOoVtDcvmyunhkpMCXfQSHAezB=False
FELbqOoVtDcvmyunhkpMCXfQSHAezl=type
FELbqOoVtDcvmyunhkpMCXfQSHAezU=dict
FELbqOoVtDcvmyunhkpMCXfQSHAeza=open
FELbqOoVtDcvmyunhkpMCXfQSHAezi=Exception
FELbqOoVtDcvmyunhkpMCXfQSHAezI=int
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
FELbqOoVtDcvmyunhkpMCXfQSHAesz=[{'title':'실시간 (전체)','mode':'LIVE_LIST','genre':'-'},{'title':'실시간 (장르별)','mode':'LIVE_GROUP'},]
FELbqOoVtDcvmyunhkpMCXfQSHAesl =xbmcvfs.translatePath(os.path.join(__profile__,'samsungtv_cookies.json'))
from samsungtvCore import*
class FELbqOoVtDcvmyunhkpMCXfQSHAesB(FELbqOoVtDcvmyunhkpMCXfQSHAeBT):
 def __init__(FELbqOoVtDcvmyunhkpMCXfQSHAesU,FELbqOoVtDcvmyunhkpMCXfQSHAesa,FELbqOoVtDcvmyunhkpMCXfQSHAesi,FELbqOoVtDcvmyunhkpMCXfQSHAesI):
  FELbqOoVtDcvmyunhkpMCXfQSHAesU._addon_url =FELbqOoVtDcvmyunhkpMCXfQSHAesa
  FELbqOoVtDcvmyunhkpMCXfQSHAesU._addon_handle=FELbqOoVtDcvmyunhkpMCXfQSHAesi
  FELbqOoVtDcvmyunhkpMCXfQSHAesU.main_params =FELbqOoVtDcvmyunhkpMCXfQSHAesI
  FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj =iQmhRWgPtojCxAVGXrekSTEysnpvaN() 
 def addon_noti(FELbqOoVtDcvmyunhkpMCXfQSHAesU,sting):
  try:
   FELbqOoVtDcvmyunhkpMCXfQSHAesW=xbmcgui.Dialog()
   FELbqOoVtDcvmyunhkpMCXfQSHAesW.notification(__addonname__,sting)
  except:
   FELbqOoVtDcvmyunhkpMCXfQSHAeBG
 def addon_log(FELbqOoVtDcvmyunhkpMCXfQSHAesU,string):
  try:
   FELbqOoVtDcvmyunhkpMCXfQSHAesK=string.encode('utf-8','ignore')
  except:
   FELbqOoVtDcvmyunhkpMCXfQSHAesK='addonException: addon_log'
  FELbqOoVtDcvmyunhkpMCXfQSHAesj=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,FELbqOoVtDcvmyunhkpMCXfQSHAesK),level=FELbqOoVtDcvmyunhkpMCXfQSHAesj)
 def get_keyboard_input(FELbqOoVtDcvmyunhkpMCXfQSHAesU,FELbqOoVtDcvmyunhkpMCXfQSHAesN):
  FELbqOoVtDcvmyunhkpMCXfQSHAesR=FELbqOoVtDcvmyunhkpMCXfQSHAeBG
  kb=xbmc.Keyboard()
  kb.setHeading(FELbqOoVtDcvmyunhkpMCXfQSHAesN)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   FELbqOoVtDcvmyunhkpMCXfQSHAesR=kb.getText()
  return FELbqOoVtDcvmyunhkpMCXfQSHAesR
 def add_dir(FELbqOoVtDcvmyunhkpMCXfQSHAesU,label,sublabel='',img='',infoLabels=FELbqOoVtDcvmyunhkpMCXfQSHAeBG,isFolder=FELbqOoVtDcvmyunhkpMCXfQSHAezs,params='',isLink=FELbqOoVtDcvmyunhkpMCXfQSHAezB,ContextMenu=FELbqOoVtDcvmyunhkpMCXfQSHAeBG):
  FELbqOoVtDcvmyunhkpMCXfQSHAesY='%s?%s'%(FELbqOoVtDcvmyunhkpMCXfQSHAesU._addon_url,urllib.parse.urlencode(params))
  if sublabel:FELbqOoVtDcvmyunhkpMCXfQSHAesN='%s < %s >'%(label,sublabel)
  else: FELbqOoVtDcvmyunhkpMCXfQSHAesN=label
  if not img:img='DefaultFolder.png'
  FELbqOoVtDcvmyunhkpMCXfQSHAesd=xbmcgui.ListItem(FELbqOoVtDcvmyunhkpMCXfQSHAesN)
  if FELbqOoVtDcvmyunhkpMCXfQSHAezl(img)==FELbqOoVtDcvmyunhkpMCXfQSHAezU:
   FELbqOoVtDcvmyunhkpMCXfQSHAesd.setArt(img)
  else:
   FELbqOoVtDcvmyunhkpMCXfQSHAesd.setArt({'thumb':img,'poster':img})
  if infoLabels:FELbqOoVtDcvmyunhkpMCXfQSHAesd.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   FELbqOoVtDcvmyunhkpMCXfQSHAesd.setProperty('IsPlayable','true')
  if ContextMenu:FELbqOoVtDcvmyunhkpMCXfQSHAesd.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(FELbqOoVtDcvmyunhkpMCXfQSHAesU._addon_handle,FELbqOoVtDcvmyunhkpMCXfQSHAesY,FELbqOoVtDcvmyunhkpMCXfQSHAesd,isFolder)
 def dp_Main_List(FELbqOoVtDcvmyunhkpMCXfQSHAesU,args):
  for FELbqOoVtDcvmyunhkpMCXfQSHAesg in FELbqOoVtDcvmyunhkpMCXfQSHAesz:
   FELbqOoVtDcvmyunhkpMCXfQSHAesN=FELbqOoVtDcvmyunhkpMCXfQSHAesg.get('title')
   FELbqOoVtDcvmyunhkpMCXfQSHAesJ=''
   FELbqOoVtDcvmyunhkpMCXfQSHAesP={'mode':FELbqOoVtDcvmyunhkpMCXfQSHAesg.get('mode'),'genre':FELbqOoVtDcvmyunhkpMCXfQSHAesg.get('genre'),}
   if FELbqOoVtDcvmyunhkpMCXfQSHAesg.get('mode')in['XXX']:
    FELbqOoVtDcvmyunhkpMCXfQSHAesw=FELbqOoVtDcvmyunhkpMCXfQSHAezB
    FELbqOoVtDcvmyunhkpMCXfQSHAesr =FELbqOoVtDcvmyunhkpMCXfQSHAezs
   else:
    FELbqOoVtDcvmyunhkpMCXfQSHAesw=FELbqOoVtDcvmyunhkpMCXfQSHAezs
    FELbqOoVtDcvmyunhkpMCXfQSHAesr =FELbqOoVtDcvmyunhkpMCXfQSHAezB
   if 'icon' in FELbqOoVtDcvmyunhkpMCXfQSHAesg:FELbqOoVtDcvmyunhkpMCXfQSHAesJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',FELbqOoVtDcvmyunhkpMCXfQSHAesg.get('icon')) 
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.add_dir(FELbqOoVtDcvmyunhkpMCXfQSHAesN,sublabel='',img=FELbqOoVtDcvmyunhkpMCXfQSHAesJ,infoLabels=FELbqOoVtDcvmyunhkpMCXfQSHAeBG,isFolder=FELbqOoVtDcvmyunhkpMCXfQSHAesw,params=FELbqOoVtDcvmyunhkpMCXfQSHAesP,isLink=FELbqOoVtDcvmyunhkpMCXfQSHAesr)
  xbmcplugin.endOfDirectory(FELbqOoVtDcvmyunhkpMCXfQSHAesU._addon_handle)
 def login_main(FELbqOoVtDcvmyunhkpMCXfQSHAesU):
  if not os.path.isdir(xbmcvfs.translatePath(__profile__)):os.mkdir(xbmcvfs.translatePath(__profile__))
  try: 
   fp=FELbqOoVtDcvmyunhkpMCXfQSHAeza(FELbqOoVtDcvmyunhkpMCXfQSHAesl,'r',-1,'utf-8')
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj.SSTV= json.load(fp)
   fp.close()
  except FELbqOoVtDcvmyunhkpMCXfQSHAezi as exception:
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj.SSTV['limit_date']='0'
  FELbqOoVtDcvmyunhkpMCXfQSHAesG =FELbqOoVtDcvmyunhkpMCXfQSHAezI(FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  FELbqOoVtDcvmyunhkpMCXfQSHAeBs=FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj.SSTV['limit_date']
  FELbqOoVtDcvmyunhkpMCXfQSHAeBz =FELbqOoVtDcvmyunhkpMCXfQSHAezI(re.sub('-','',FELbqOoVtDcvmyunhkpMCXfQSHAeBs))
  if FELbqOoVtDcvmyunhkpMCXfQSHAesG<=FELbqOoVtDcvmyunhkpMCXfQSHAeBz:
   return FELbqOoVtDcvmyunhkpMCXfQSHAezs
  if FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj.Get_BaseCookies()==FELbqOoVtDcvmyunhkpMCXfQSHAezB:
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.addon_noti('init error!')
   return FELbqOoVtDcvmyunhkpMCXfQSHAezB
  FELbqOoVtDcvmyunhkpMCXfQSHAeBl =FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj.Get_Now_Datetime()
  FELbqOoVtDcvmyunhkpMCXfQSHAeBU=FELbqOoVtDcvmyunhkpMCXfQSHAeBl+datetime.timedelta(days=FELbqOoVtDcvmyunhkpMCXfQSHAezI(__addon__.getSetting('cache_ttl')))
  FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj.SSTV['limit_date']=FELbqOoVtDcvmyunhkpMCXfQSHAeBU.strftime('%Y-%m-%d')
  try: 
   fp=FELbqOoVtDcvmyunhkpMCXfQSHAeza(FELbqOoVtDcvmyunhkpMCXfQSHAesl,'w',-1,'utf-8')
   json.dump(FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj.SSTV,fp,indent=4,ensure_ascii=FELbqOoVtDcvmyunhkpMCXfQSHAezB)
   fp.close()
  except FELbqOoVtDcvmyunhkpMCXfQSHAezi as exception:
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.addon_noti('file save error!')
   return FELbqOoVtDcvmyunhkpMCXfQSHAezB
  return FELbqOoVtDcvmyunhkpMCXfQSHAezs
 def dp_LiveChannel_List(FELbqOoVtDcvmyunhkpMCXfQSHAesU,args):
  FELbqOoVtDcvmyunhkpMCXfQSHAeBi=args.get('genre')
  FELbqOoVtDcvmyunhkpMCXfQSHAeBI=FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj.GetLiveChannelList(view_genre=FELbqOoVtDcvmyunhkpMCXfQSHAeBi)
  for FELbqOoVtDcvmyunhkpMCXfQSHAeBx in FELbqOoVtDcvmyunhkpMCXfQSHAeBI:
   FELbqOoVtDcvmyunhkpMCXfQSHAeBW =FELbqOoVtDcvmyunhkpMCXfQSHAeBx.get('chid')
   FELbqOoVtDcvmyunhkpMCXfQSHAeBK =FELbqOoVtDcvmyunhkpMCXfQSHAeBx.get('channlnm')
   FELbqOoVtDcvmyunhkpMCXfQSHAeBj =FELbqOoVtDcvmyunhkpMCXfQSHAeBx.get('genre')
   FELbqOoVtDcvmyunhkpMCXfQSHAeBR =FELbqOoVtDcvmyunhkpMCXfQSHAeBx.get('programnm')
   FELbqOoVtDcvmyunhkpMCXfQSHAeBY =FELbqOoVtDcvmyunhkpMCXfQSHAeBx.get('thumbnail')
   FELbqOoVtDcvmyunhkpMCXfQSHAeBN =FELbqOoVtDcvmyunhkpMCXfQSHAeBx.get('epg')
   FELbqOoVtDcvmyunhkpMCXfQSHAeBd={'mediatype':'episode','title':FELbqOoVtDcvmyunhkpMCXfQSHAeBR,'studio':FELbqOoVtDcvmyunhkpMCXfQSHAeBK,'genre':FELbqOoVtDcvmyunhkpMCXfQSHAeBj,'plot':'%s\n\n%s'%(FELbqOoVtDcvmyunhkpMCXfQSHAeBK,FELbqOoVtDcvmyunhkpMCXfQSHAeBN),}
   FELbqOoVtDcvmyunhkpMCXfQSHAesP={'mode':'LIVE','chid':FELbqOoVtDcvmyunhkpMCXfQSHAeBW,}
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.add_dir(FELbqOoVtDcvmyunhkpMCXfQSHAeBK,sublabel=FELbqOoVtDcvmyunhkpMCXfQSHAeBR,img=FELbqOoVtDcvmyunhkpMCXfQSHAeBY,infoLabels=FELbqOoVtDcvmyunhkpMCXfQSHAeBd,isFolder=FELbqOoVtDcvmyunhkpMCXfQSHAezB,params=FELbqOoVtDcvmyunhkpMCXfQSHAesP)
  xbmcplugin.endOfDirectory(FELbqOoVtDcvmyunhkpMCXfQSHAesU._addon_handle,cacheToDisc=FELbqOoVtDcvmyunhkpMCXfQSHAezs)
 def dp_LiveGroup_List(FELbqOoVtDcvmyunhkpMCXfQSHAesU,args):
  FELbqOoVtDcvmyunhkpMCXfQSHAeBI=FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj.GetGenreList()
  for FELbqOoVtDcvmyunhkpMCXfQSHAeBx in FELbqOoVtDcvmyunhkpMCXfQSHAeBI:
   FELbqOoVtDcvmyunhkpMCXfQSHAeBi =FELbqOoVtDcvmyunhkpMCXfQSHAeBx.get('genre')
   FELbqOoVtDcvmyunhkpMCXfQSHAeBd={'plot':FELbqOoVtDcvmyunhkpMCXfQSHAeBi}
   FELbqOoVtDcvmyunhkpMCXfQSHAesP={'mode':'LIVE_LIST','genre':FELbqOoVtDcvmyunhkpMCXfQSHAeBi,}
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.add_dir(FELbqOoVtDcvmyunhkpMCXfQSHAeBi,sublabel='',img='',infoLabels=FELbqOoVtDcvmyunhkpMCXfQSHAeBd,isFolder=FELbqOoVtDcvmyunhkpMCXfQSHAezs,params=FELbqOoVtDcvmyunhkpMCXfQSHAesP)
  xbmcplugin.endOfDirectory(FELbqOoVtDcvmyunhkpMCXfQSHAesU._addon_handle,cacheToDisc=FELbqOoVtDcvmyunhkpMCXfQSHAezs)
 def play_VIDEO(FELbqOoVtDcvmyunhkpMCXfQSHAesU,args):
  FELbqOoVtDcvmyunhkpMCXfQSHAeBW =args.get('chid')
  FELbqOoVtDcvmyunhkpMCXfQSHAeBJ=FELbqOoVtDcvmyunhkpMCXfQSHAesU.SamsungtvObj.GetBroadURL(FELbqOoVtDcvmyunhkpMCXfQSHAeBW)
  FELbqOoVtDcvmyunhkpMCXfQSHAesU.addon_log('%s - url : %s'%(FELbqOoVtDcvmyunhkpMCXfQSHAeBW,FELbqOoVtDcvmyunhkpMCXfQSHAeBJ))
  if FELbqOoVtDcvmyunhkpMCXfQSHAeBJ=='':
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.addon_noti(__language__(30906).encode('utf8'))
   return
  FELbqOoVtDcvmyunhkpMCXfQSHAeBJ+='|origin=https://www.samsungtvplus.com'
  FELbqOoVtDcvmyunhkpMCXfQSHAeBP=xbmcgui.ListItem(path=FELbqOoVtDcvmyunhkpMCXfQSHAeBJ)
  FELbqOoVtDcvmyunhkpMCXfQSHAeBP.setContentLookup(FELbqOoVtDcvmyunhkpMCXfQSHAezB)
  FELbqOoVtDcvmyunhkpMCXfQSHAeBP.setMimeType('application/x-mpegURL')
  FELbqOoVtDcvmyunhkpMCXfQSHAeBP.setProperty('inputstream','inputstream.adaptive')
  FELbqOoVtDcvmyunhkpMCXfQSHAeBP.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(FELbqOoVtDcvmyunhkpMCXfQSHAesU._addon_handle,FELbqOoVtDcvmyunhkpMCXfQSHAezs,FELbqOoVtDcvmyunhkpMCXfQSHAeBP)
 def STV_logout(FELbqOoVtDcvmyunhkpMCXfQSHAesU):
  FELbqOoVtDcvmyunhkpMCXfQSHAesW=xbmcgui.Dialog()
  FELbqOoVtDcvmyunhkpMCXfQSHAeBw=FELbqOoVtDcvmyunhkpMCXfQSHAesW.yesno(__language__(30905).encode('utf8'),__language__(30907).encode('utf8'))
  if FELbqOoVtDcvmyunhkpMCXfQSHAeBw==FELbqOoVtDcvmyunhkpMCXfQSHAezB:return 
  if os.path.isfile(FELbqOoVtDcvmyunhkpMCXfQSHAesl):os.remove(FELbqOoVtDcvmyunhkpMCXfQSHAesl)
  FELbqOoVtDcvmyunhkpMCXfQSHAesU.addon_noti(__language__(30904).encode('utf-8'))
 def dp_Test(FELbqOoVtDcvmyunhkpMCXfQSHAesU,args):
  FELbqOoVtDcvmyunhkpMCXfQSHAesU.addon_noti('test')
 def samsungtv_main(FELbqOoVtDcvmyunhkpMCXfQSHAesU):
  FELbqOoVtDcvmyunhkpMCXfQSHAeBr=FELbqOoVtDcvmyunhkpMCXfQSHAesU.main_params.get('mode',FELbqOoVtDcvmyunhkpMCXfQSHAeBG)
  if FELbqOoVtDcvmyunhkpMCXfQSHAeBr=='LOGOUT':
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.STV_logout()
   return
  FELbqOoVtDcvmyunhkpMCXfQSHAesU.login_main()
  if FELbqOoVtDcvmyunhkpMCXfQSHAeBr is FELbqOoVtDcvmyunhkpMCXfQSHAeBG:
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.dp_Main_List(FELbqOoVtDcvmyunhkpMCXfQSHAesU.main_params)
  elif FELbqOoVtDcvmyunhkpMCXfQSHAeBr=='LIVE_LIST':
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.dp_LiveChannel_List(FELbqOoVtDcvmyunhkpMCXfQSHAesU.main_params)
  elif FELbqOoVtDcvmyunhkpMCXfQSHAeBr=='LIVE':
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.play_VIDEO(FELbqOoVtDcvmyunhkpMCXfQSHAesU.main_params)
  elif FELbqOoVtDcvmyunhkpMCXfQSHAeBr=='LIVE_GROUP':
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.dp_LiveGroup_List(FELbqOoVtDcvmyunhkpMCXfQSHAesU.main_params)
  elif FELbqOoVtDcvmyunhkpMCXfQSHAeBr=='CAPTCHA_TEST':
   FELbqOoVtDcvmyunhkpMCXfQSHAesU.dp_Test(FELbqOoVtDcvmyunhkpMCXfQSHAesU.main_params)
  else:
   FELbqOoVtDcvmyunhkpMCXfQSHAeBG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
