__author__="NightRain"
PWvkcGbEozYdfsgpmDCMUBJRuqihFw=object
PWvkcGbEozYdfsgpmDCMUBJRuqihFO=None
PWvkcGbEozYdfsgpmDCMUBJRuqihFy=False
PWvkcGbEozYdfsgpmDCMUBJRuqihFN=int
PWvkcGbEozYdfsgpmDCMUBJRuqihQK=len
PWvkcGbEozYdfsgpmDCMUBJRuqihQF=Exception
PWvkcGbEozYdfsgpmDCMUBJRuqihQA=print
PWvkcGbEozYdfsgpmDCMUBJRuqihQa=True
PWvkcGbEozYdfsgpmDCMUBJRuqihQl=str
PWvkcGbEozYdfsgpmDCMUBJRuqihQt=range
import urllib
import re
import json
import requests
import datetime
import time
import zlib
import base64
class PWvkcGbEozYdfsgpmDCMUBJRuqihKF(PWvkcGbEozYdfsgpmDCMUBJRuqihFw):
 def __init__(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ):
  PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
  PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.DEFAULT_HEADER ={'user-agent':PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.USER_AGENT}
  PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.API_DOMAIN ='https://www.samsungtvplus.com'
  PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.SSTV={}
  PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.KodiVersion=20
 def callRequestCookies(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ,jobtype,PWvkcGbEozYdfsgpmDCMUBJRuqihKV,payload=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,params=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,headers=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,cookies=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,redirects=PWvkcGbEozYdfsgpmDCMUBJRuqihFy):
  PWvkcGbEozYdfsgpmDCMUBJRuqihKA=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.DEFAULT_HEADER
  if headers:PWvkcGbEozYdfsgpmDCMUBJRuqihKA.update(headers)
  if jobtype=='Get':
   PWvkcGbEozYdfsgpmDCMUBJRuqihKa=requests.get(PWvkcGbEozYdfsgpmDCMUBJRuqihKV,params=params,headers=PWvkcGbEozYdfsgpmDCMUBJRuqihKA,cookies=cookies,allow_redirects=redirects)
  else:
   PWvkcGbEozYdfsgpmDCMUBJRuqihKa=requests.post(PWvkcGbEozYdfsgpmDCMUBJRuqihKV,data=payload,params=params,headers=PWvkcGbEozYdfsgpmDCMUBJRuqihKA,cookies=cookies,allow_redirects=redirects)
  return PWvkcGbEozYdfsgpmDCMUBJRuqihKa
 def Get_Now_Datetime(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ):
  PWvkcGbEozYdfsgpmDCMUBJRuqihKt =PWvkcGbEozYdfsgpmDCMUBJRuqihFN(time.time())
  PWvkcGbEozYdfsgpmDCMUBJRuqihKH=PWvkcGbEozYdfsgpmDCMUBJRuqihFN(PWvkcGbEozYdfsgpmDCMUBJRuqihKt-PWvkcGbEozYdfsgpmDCMUBJRuqihKt%3600)
  return PWvkcGbEozYdfsgpmDCMUBJRuqihKH,PWvkcGbEozYdfsgpmDCMUBJRuqihKt
 def zlib_decompress(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ,PWvkcGbEozYdfsgpmDCMUBJRuqihKX):
  PWvkcGbEozYdfsgpmDCMUBJRuqihKr=zlib.decompress(base64.standard_b64decode(PWvkcGbEozYdfsgpmDCMUBJRuqihKX))
  return PWvkcGbEozYdfsgpmDCMUBJRuqihKr.decode('utf-8')
 def zlib_compress(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ,PWvkcGbEozYdfsgpmDCMUBJRuqihKr):
  PWvkcGbEozYdfsgpmDCMUBJRuqihKX=zlib.compress(PWvkcGbEozYdfsgpmDCMUBJRuqihKr.encode('utf-8'))
  return base64.standard_b64encode(PWvkcGbEozYdfsgpmDCMUBJRuqihKX).decode('utf-8')
 def makeDefaultCookies(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ,vToken=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,vUserinfo=PWvkcGbEozYdfsgpmDCMUBJRuqihFO):
  PWvkcGbEozYdfsgpmDCMUBJRuqihKx={}
  if PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.SSTV.get('session') !='':PWvkcGbEozYdfsgpmDCMUBJRuqihKx['session'] =PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.SSTV.get('session')
  if PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.SSTV.get('session.sig')!='':PWvkcGbEozYdfsgpmDCMUBJRuqihKx['session.sig']=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.SSTV.get('session.sig')
  return PWvkcGbEozYdfsgpmDCMUBJRuqihKx
 def make_stream_header(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ,PWvkcGbEozYdfsgpmDCMUBJRuqihKn,PWvkcGbEozYdfsgpmDCMUBJRuqihKx):
  PWvkcGbEozYdfsgpmDCMUBJRuqihKI=''
  if PWvkcGbEozYdfsgpmDCMUBJRuqihKx not in[{},PWvkcGbEozYdfsgpmDCMUBJRuqihFO,'']:
   PWvkcGbEozYdfsgpmDCMUBJRuqihKe=PWvkcGbEozYdfsgpmDCMUBJRuqihQK(PWvkcGbEozYdfsgpmDCMUBJRuqihKx)
   for PWvkcGbEozYdfsgpmDCMUBJRuqihKS,PWvkcGbEozYdfsgpmDCMUBJRuqihKj in PWvkcGbEozYdfsgpmDCMUBJRuqihKx.items():
    PWvkcGbEozYdfsgpmDCMUBJRuqihKI+='{}={}'.format(PWvkcGbEozYdfsgpmDCMUBJRuqihKS,PWvkcGbEozYdfsgpmDCMUBJRuqihKj)
    PWvkcGbEozYdfsgpmDCMUBJRuqihKe+=-1
    if PWvkcGbEozYdfsgpmDCMUBJRuqihKe>0:PWvkcGbEozYdfsgpmDCMUBJRuqihKI+='; '
   PWvkcGbEozYdfsgpmDCMUBJRuqihKn['cookie']=PWvkcGbEozYdfsgpmDCMUBJRuqihKI
  PWvkcGbEozYdfsgpmDCMUBJRuqihKL=''
  i=0
  for PWvkcGbEozYdfsgpmDCMUBJRuqihKS,PWvkcGbEozYdfsgpmDCMUBJRuqihKj in PWvkcGbEozYdfsgpmDCMUBJRuqihKn.items():
   i=i+1
   if i>1:PWvkcGbEozYdfsgpmDCMUBJRuqihKL+='&'
   PWvkcGbEozYdfsgpmDCMUBJRuqihKL+='{}={}'.format(PWvkcGbEozYdfsgpmDCMUBJRuqihKS,urllib.parse.quote(PWvkcGbEozYdfsgpmDCMUBJRuqihKj))
  return PWvkcGbEozYdfsgpmDCMUBJRuqihKL
 def Get_BaseCookies(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ):
  try:
   PWvkcGbEozYdfsgpmDCMUBJRuqihKV=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.API_DOMAIN
   PWvkcGbEozYdfsgpmDCMUBJRuqihKT=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.callRequestCookies('Get',PWvkcGbEozYdfsgpmDCMUBJRuqihKV,payload=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,params=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,headers=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,cookies=PWvkcGbEozYdfsgpmDCMUBJRuqihFO)
   for PWvkcGbEozYdfsgpmDCMUBJRuqihKw in PWvkcGbEozYdfsgpmDCMUBJRuqihKT.cookies:
    if PWvkcGbEozYdfsgpmDCMUBJRuqihKw.name=='session':
     PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.SSTV['session']=PWvkcGbEozYdfsgpmDCMUBJRuqihKw.value
    elif PWvkcGbEozYdfsgpmDCMUBJRuqihKw.name=='session.sig':
     PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.SSTV['session.sig']=PWvkcGbEozYdfsgpmDCMUBJRuqihKw.value
  except PWvkcGbEozYdfsgpmDCMUBJRuqihQF as exception:
   PWvkcGbEozYdfsgpmDCMUBJRuqihQA(exception)
   return PWvkcGbEozYdfsgpmDCMUBJRuqihFy
  try:
   PWvkcGbEozYdfsgpmDCMUBJRuqihKV=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.API_DOMAIN+'/user'
   PWvkcGbEozYdfsgpmDCMUBJRuqihKx=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.makeDefaultCookies()
   PWvkcGbEozYdfsgpmDCMUBJRuqihKT=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.callRequestCookies('Get',PWvkcGbEozYdfsgpmDCMUBJRuqihKV,payload=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,params=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,headers=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,cookies=PWvkcGbEozYdfsgpmDCMUBJRuqihKx)
   PWvkcGbEozYdfsgpmDCMUBJRuqihKO=json.loads(PWvkcGbEozYdfsgpmDCMUBJRuqihKT.text)
   PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.SSTV['countryCode']=PWvkcGbEozYdfsgpmDCMUBJRuqihKO.get('countryCode')
   PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.SSTV['uuid'] =PWvkcGbEozYdfsgpmDCMUBJRuqihKO.get('uuid')
   PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.SSTV['ip'] =PWvkcGbEozYdfsgpmDCMUBJRuqihKO.get('ip')
  except PWvkcGbEozYdfsgpmDCMUBJRuqihQF as exception:
   PWvkcGbEozYdfsgpmDCMUBJRuqihQA(exception)
   return PWvkcGbEozYdfsgpmDCMUBJRuqihFy
  return PWvkcGbEozYdfsgpmDCMUBJRuqihQa
 def Get_BaseJson_Request(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ):
  PWvkcGbEozYdfsgpmDCMUBJRuqihKO={}
  try:
   PWvkcGbEozYdfsgpmDCMUBJRuqihKV=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.API_DOMAIN+'/api/lives'
   PWvkcGbEozYdfsgpmDCMUBJRuqihKH,PWvkcGbEozYdfsgpmDCMUBJRuqihKt=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.GetNoCache()
   PWvkcGbEozYdfsgpmDCMUBJRuqihKy=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.zlib_compress(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.SSTV['uuid']+':'+PWvkcGbEozYdfsgpmDCMUBJRuqihQl(PWvkcGbEozYdfsgpmDCMUBJRuqihKt))
   PWvkcGbEozYdfsgpmDCMUBJRuqihKx =PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.makeDefaultCookies()
   PWvkcGbEozYdfsgpmDCMUBJRuqihKN ={'t':PWvkcGbEozYdfsgpmDCMUBJRuqihQl(PWvkcGbEozYdfsgpmDCMUBJRuqihKH)}
   PWvkcGbEozYdfsgpmDCMUBJRuqihKn ={'x-cred-payload':PWvkcGbEozYdfsgpmDCMUBJRuqihKy}
   PWvkcGbEozYdfsgpmDCMUBJRuqihKT=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.callRequestCookies('Get',PWvkcGbEozYdfsgpmDCMUBJRuqihKV,payload=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,params=PWvkcGbEozYdfsgpmDCMUBJRuqihKN,headers=PWvkcGbEozYdfsgpmDCMUBJRuqihKn,cookies=PWvkcGbEozYdfsgpmDCMUBJRuqihKx)
   PWvkcGbEozYdfsgpmDCMUBJRuqihKO=json.loads(PWvkcGbEozYdfsgpmDCMUBJRuqihKT.text)
  except PWvkcGbEozYdfsgpmDCMUBJRuqihQF as exception:
   PWvkcGbEozYdfsgpmDCMUBJRuqihQA(exception)
  return PWvkcGbEozYdfsgpmDCMUBJRuqihKO
 def GetGenreList(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ):
  PWvkcGbEozYdfsgpmDCMUBJRuqihFK=[]
  try:
   PWvkcGbEozYdfsgpmDCMUBJRuqihKO=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.Get_BaseJson_Request()
   PWvkcGbEozYdfsgpmDCMUBJRuqihFQ=PWvkcGbEozYdfsgpmDCMUBJRuqihKO['live']['genrelist']
   for PWvkcGbEozYdfsgpmDCMUBJRuqihFA in PWvkcGbEozYdfsgpmDCMUBJRuqihFQ:
    PWvkcGbEozYdfsgpmDCMUBJRuqihFa={'genre':PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('name'),}
    PWvkcGbEozYdfsgpmDCMUBJRuqihFK.append(PWvkcGbEozYdfsgpmDCMUBJRuqihFa)
  except PWvkcGbEozYdfsgpmDCMUBJRuqihQF as exception:
   PWvkcGbEozYdfsgpmDCMUBJRuqihQA(exception)
  return PWvkcGbEozYdfsgpmDCMUBJRuqihFK
 def GetLiveChannelList(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ,view_genre='-'):
  PWvkcGbEozYdfsgpmDCMUBJRuqihFK=[]
  try:
   PWvkcGbEozYdfsgpmDCMUBJRuqihKO=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.Get_BaseJson_Request()
   PWvkcGbEozYdfsgpmDCMUBJRuqihFQ=PWvkcGbEozYdfsgpmDCMUBJRuqihKO['live']['channel']
   for PWvkcGbEozYdfsgpmDCMUBJRuqihFA in PWvkcGbEozYdfsgpmDCMUBJRuqihFQ:
    PWvkcGbEozYdfsgpmDCMUBJRuqihFl=PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('genre').get('name')
    if PWvkcGbEozYdfsgpmDCMUBJRuqihFl!=view_genre and view_genre!='-':continue
    PWvkcGbEozYdfsgpmDCMUBJRuqihFt=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.Make_EpgList(PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('program'))
    if PWvkcGbEozYdfsgpmDCMUBJRuqihQK(PWvkcGbEozYdfsgpmDCMUBJRuqihFt)>1:
     PWvkcGbEozYdfsgpmDCMUBJRuqihFH=PWvkcGbEozYdfsgpmDCMUBJRuqihFt[0].get('endtm').replace('-','').replace(':','').replace(' ','')
     PWvkcGbEozYdfsgpmDCMUBJRuqihKt=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.Get_Now_Datetime().strftime('%Y%m%d%H%M')
     if PWvkcGbEozYdfsgpmDCMUBJRuqihFN(PWvkcGbEozYdfsgpmDCMUBJRuqihFH)<PWvkcGbEozYdfsgpmDCMUBJRuqihFN(PWvkcGbEozYdfsgpmDCMUBJRuqihKt):
      PWvkcGbEozYdfsgpmDCMUBJRuqihFt.pop(0)
    PWvkcGbEozYdfsgpmDCMUBJRuqihFr =PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('logo')
    PWvkcGbEozYdfsgpmDCMUBJRuqihFX=PWvkcGbEozYdfsgpmDCMUBJRuqihFt[0].get('thumbnail')
    PWvkcGbEozYdfsgpmDCMUBJRuqihFa={'chid':PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('id'),'channlnm':PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('name'),'genre':PWvkcGbEozYdfsgpmDCMUBJRuqihFl,'programnm':PWvkcGbEozYdfsgpmDCMUBJRuqihFt[0].get('title'),'thumbnail':{'thumb':PWvkcGbEozYdfsgpmDCMUBJRuqihFX,'clearlogo':PWvkcGbEozYdfsgpmDCMUBJRuqihFr,'icon':PWvkcGbEozYdfsgpmDCMUBJRuqihFr,'fanart':PWvkcGbEozYdfsgpmDCMUBJRuqihFX},'epg':PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.Make_EpgString(PWvkcGbEozYdfsgpmDCMUBJRuqihFt),}
    PWvkcGbEozYdfsgpmDCMUBJRuqihFK.append(PWvkcGbEozYdfsgpmDCMUBJRuqihFa)
  except PWvkcGbEozYdfsgpmDCMUBJRuqihQF as exception:
   PWvkcGbEozYdfsgpmDCMUBJRuqihQA(exception)
  return PWvkcGbEozYdfsgpmDCMUBJRuqihFK
 def Make_EpgList(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ,programList):
  PWvkcGbEozYdfsgpmDCMUBJRuqihFt=[]
  try:
   for PWvkcGbEozYdfsgpmDCMUBJRuqihFA in programList:
    PWvkcGbEozYdfsgpmDCMUBJRuqihFx=PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('start_time')
    PWvkcGbEozYdfsgpmDCMUBJRuqihFI =PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('duration') 
    PWvkcGbEozYdfsgpmDCMUBJRuqihFe=datetime.datetime.strptime(PWvkcGbEozYdfsgpmDCMUBJRuqihFx,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
    PWvkcGbEozYdfsgpmDCMUBJRuqihFH =PWvkcGbEozYdfsgpmDCMUBJRuqihFe+datetime.timedelta(seconds=PWvkcGbEozYdfsgpmDCMUBJRuqihFI)
    PWvkcGbEozYdfsgpmDCMUBJRuqihFa={'title':PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('title'),'starttm':PWvkcGbEozYdfsgpmDCMUBJRuqihFe.strftime('%Y-%m-%d %H:%M'),'endtm':PWvkcGbEozYdfsgpmDCMUBJRuqihFH.strftime('%Y-%m-%d %H:%M'),'thumbnail':PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('thumbnail'),}
    PWvkcGbEozYdfsgpmDCMUBJRuqihFt.append(PWvkcGbEozYdfsgpmDCMUBJRuqihFa)
  except PWvkcGbEozYdfsgpmDCMUBJRuqihQF as exception:
   PWvkcGbEozYdfsgpmDCMUBJRuqihQA(exception)
  return PWvkcGbEozYdfsgpmDCMUBJRuqihFt
 def Make_EpgString(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ,PWvkcGbEozYdfsgpmDCMUBJRuqihFt):
  PWvkcGbEozYdfsgpmDCMUBJRuqihFS=''
  try:
   for i in PWvkcGbEozYdfsgpmDCMUBJRuqihQt(PWvkcGbEozYdfsgpmDCMUBJRuqihQK(PWvkcGbEozYdfsgpmDCMUBJRuqihFt)):
    if i>3:break
    PWvkcGbEozYdfsgpmDCMUBJRuqihFj=PWvkcGbEozYdfsgpmDCMUBJRuqihFt[i].get('starttm')[-5:]
    PWvkcGbEozYdfsgpmDCMUBJRuqihFn =PWvkcGbEozYdfsgpmDCMUBJRuqihFt[i].get('endtm')[-5:]
    PWvkcGbEozYdfsgpmDCMUBJRuqihFL =PWvkcGbEozYdfsgpmDCMUBJRuqihFt[i].get('title')
    PWvkcGbEozYdfsgpmDCMUBJRuqihFS+='%s\n[%s ~ %s]\n\n'%(PWvkcGbEozYdfsgpmDCMUBJRuqihFL,PWvkcGbEozYdfsgpmDCMUBJRuqihFj,PWvkcGbEozYdfsgpmDCMUBJRuqihFn)
  except PWvkcGbEozYdfsgpmDCMUBJRuqihQF as exception:
   PWvkcGbEozYdfsgpmDCMUBJRuqihQA(exception)
  return PWvkcGbEozYdfsgpmDCMUBJRuqihFS
 def GetBroadURL(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ,chid):
  PWvkcGbEozYdfsgpmDCMUBJRuqihFV=''
  try:
   PWvkcGbEozYdfsgpmDCMUBJRuqihKO=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.Get_BaseJson_Request()
   PWvkcGbEozYdfsgpmDCMUBJRuqihFQ=PWvkcGbEozYdfsgpmDCMUBJRuqihKO['live']['channel']
   for PWvkcGbEozYdfsgpmDCMUBJRuqihFA in PWvkcGbEozYdfsgpmDCMUBJRuqihFQ:
    if PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('id')==chid:
     PWvkcGbEozYdfsgpmDCMUBJRuqihFT =PWvkcGbEozYdfsgpmDCMUBJRuqihFA.get('program')[0].get('stream_url_new')
     PWvkcGbEozYdfsgpmDCMUBJRuqihFV=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.zlib_decompress(PWvkcGbEozYdfsgpmDCMUBJRuqihFT)
     break
  except PWvkcGbEozYdfsgpmDCMUBJRuqihQF as exception:
   PWvkcGbEozYdfsgpmDCMUBJRuqihQA(exception)
  return PWvkcGbEozYdfsgpmDCMUBJRuqihFV
 def GetTest(PWvkcGbEozYdfsgpmDCMUBJRuqihKQ,streamurl):
  try:
   PWvkcGbEozYdfsgpmDCMUBJRuqihKV=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.zlib_decompress(streamurl)
   PWvkcGbEozYdfsgpmDCMUBJRuqihQA(PWvkcGbEozYdfsgpmDCMUBJRuqihKV)
   PWvkcGbEozYdfsgpmDCMUBJRuqihKV='https://play-kr.samsungtvplus.com/tvplus/web/v3/play?tid=eVFDcm9hRjhaR1RVNHAva2JJWTR3dm5YWGo3SWlIekpoUENlbmRaaDVCRXROSU9DbWRoT3lKN3JHbGdnU1BSTUlzUHptbFBGS01qWG9hYjdoZElQTXRrZ3ozbXlsUkdIOHoxTGxDcGRsekhnaXJ0Q21qUU1ycWNZdURmWjhidUxyZFpxUjdiODFUZEs1NFFBYm9hWnBPL2gvZXRINWZ0cVJhMFA3RjFZUXU2NVJtZVpZZGl6VjhmUXhCWnVWaEQwZjV2L1hTeUhOblN1akRLR2dsYzVvQzREclhUYzdOc1NzUlZkTVp5UnF6OG5HWERDRjR0dHVDUmxuRVpjbk81eSt1RXhiZkN5aHJUZWRyemdSWWloQURyTnZmRlFwQnVVZTdzay9Ob2ZBekk9'
   PWvkcGbEozYdfsgpmDCMUBJRuqihKn ={'origin':PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.API_DOMAIN}
   PWvkcGbEozYdfsgpmDCMUBJRuqihKT=PWvkcGbEozYdfsgpmDCMUBJRuqihKQ.callRequestCookies('Get',PWvkcGbEozYdfsgpmDCMUBJRuqihKV,payload=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,params=PWvkcGbEozYdfsgpmDCMUBJRuqihFO,headers=PWvkcGbEozYdfsgpmDCMUBJRuqihKn,cookies=PWvkcGbEozYdfsgpmDCMUBJRuqihFO)
   PWvkcGbEozYdfsgpmDCMUBJRuqihQA(PWvkcGbEozYdfsgpmDCMUBJRuqihKT.text)
  except PWvkcGbEozYdfsgpmDCMUBJRuqihQF as exception:
   PWvkcGbEozYdfsgpmDCMUBJRuqihQA(exception)
  return
# Created by pyminifier (https://github.com/liftoff/pyminifier)
