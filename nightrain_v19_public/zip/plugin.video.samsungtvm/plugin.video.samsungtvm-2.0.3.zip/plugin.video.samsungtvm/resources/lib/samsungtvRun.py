__author__="NightRain"
qFPduixDWCeJgOvrYKjlhQINcfzSpV=object
qFPduixDWCeJgOvrYKjlhQINcfzSpy=None
qFPduixDWCeJgOvrYKjlhQINcfzSpE=True
qFPduixDWCeJgOvrYKjlhQINcfzSpL=False
qFPduixDWCeJgOvrYKjlhQINcfzSpM=type
qFPduixDWCeJgOvrYKjlhQINcfzSpb=dict
qFPduixDWCeJgOvrYKjlhQINcfzSpR=int
qFPduixDWCeJgOvrYKjlhQINcfzSpA=open
qFPduixDWCeJgOvrYKjlhQINcfzSps=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
qFPduixDWCeJgOvrYKjlhQINcfzSVp=[{'title':'실시간 (전체)','mode':'LIVE_LIST','genre':'-'},{'title':'실시간 (장르별)','mode':'LIVE_GROUP'},]
qFPduixDWCeJgOvrYKjlhQINcfzSVE =xbmcvfs.translatePath(os.path.join(__profile__,'samsungtv_cookies.json'))
from samsungtvCore import*
class qFPduixDWCeJgOvrYKjlhQINcfzSVy(qFPduixDWCeJgOvrYKjlhQINcfzSpV):
 def __init__(qFPduixDWCeJgOvrYKjlhQINcfzSVL,qFPduixDWCeJgOvrYKjlhQINcfzSVM,qFPduixDWCeJgOvrYKjlhQINcfzSVb,qFPduixDWCeJgOvrYKjlhQINcfzSVR):
  qFPduixDWCeJgOvrYKjlhQINcfzSVL._addon_url =qFPduixDWCeJgOvrYKjlhQINcfzSVM
  qFPduixDWCeJgOvrYKjlhQINcfzSVL._addon_handle=qFPduixDWCeJgOvrYKjlhQINcfzSVb
  qFPduixDWCeJgOvrYKjlhQINcfzSVL.main_params =qFPduixDWCeJgOvrYKjlhQINcfzSVR
  qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj =PWvkcGbEozYdfsgpmDCMUBJRuqihKF() 
 def addon_noti(qFPduixDWCeJgOvrYKjlhQINcfzSVL,sting):
  try:
   qFPduixDWCeJgOvrYKjlhQINcfzSVs=xbmcgui.Dialog()
   qFPduixDWCeJgOvrYKjlhQINcfzSVs.notification(__addonname__,sting)
  except:
   qFPduixDWCeJgOvrYKjlhQINcfzSpy
 def addon_log(qFPduixDWCeJgOvrYKjlhQINcfzSVL,string):
  try:
   qFPduixDWCeJgOvrYKjlhQINcfzSVT=string.encode('utf-8','ignore')
  except:
   qFPduixDWCeJgOvrYKjlhQINcfzSVT='addonException: addon_log'
  qFPduixDWCeJgOvrYKjlhQINcfzSVB=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,qFPduixDWCeJgOvrYKjlhQINcfzSVT),level=qFPduixDWCeJgOvrYKjlhQINcfzSVB)
 def get_keyboard_input(qFPduixDWCeJgOvrYKjlhQINcfzSVL,qFPduixDWCeJgOvrYKjlhQINcfzSVo):
  qFPduixDWCeJgOvrYKjlhQINcfzSVa=qFPduixDWCeJgOvrYKjlhQINcfzSpy
  kb=xbmc.Keyboard()
  kb.setHeading(qFPduixDWCeJgOvrYKjlhQINcfzSVo)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   qFPduixDWCeJgOvrYKjlhQINcfzSVa=kb.getText()
  return qFPduixDWCeJgOvrYKjlhQINcfzSVa
 def add_dir(qFPduixDWCeJgOvrYKjlhQINcfzSVL,label,sublabel='',img='',infoLabels=qFPduixDWCeJgOvrYKjlhQINcfzSpy,isFolder=qFPduixDWCeJgOvrYKjlhQINcfzSpE,params='',isLink=qFPduixDWCeJgOvrYKjlhQINcfzSpL,ContextMenu=qFPduixDWCeJgOvrYKjlhQINcfzSpy):
  qFPduixDWCeJgOvrYKjlhQINcfzSVk='%s?%s'%(qFPduixDWCeJgOvrYKjlhQINcfzSVL._addon_url,urllib.parse.urlencode(params))
  if sublabel:qFPduixDWCeJgOvrYKjlhQINcfzSVo='%s < %s >'%(label,sublabel)
  else: qFPduixDWCeJgOvrYKjlhQINcfzSVo=label
  if not img:img='DefaultFolder.png'
  qFPduixDWCeJgOvrYKjlhQINcfzSVm=xbmcgui.ListItem(qFPduixDWCeJgOvrYKjlhQINcfzSVo)
  if qFPduixDWCeJgOvrYKjlhQINcfzSpM(img)==qFPduixDWCeJgOvrYKjlhQINcfzSpb:
   qFPduixDWCeJgOvrYKjlhQINcfzSVm.setArt(img)
  else:
   qFPduixDWCeJgOvrYKjlhQINcfzSVm.setArt({'thumb':img,'poster':img})
  if infoLabels:qFPduixDWCeJgOvrYKjlhQINcfzSVm.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   qFPduixDWCeJgOvrYKjlhQINcfzSVm.setProperty('IsPlayable','true')
  if ContextMenu:qFPduixDWCeJgOvrYKjlhQINcfzSVm.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(qFPduixDWCeJgOvrYKjlhQINcfzSVL._addon_handle,qFPduixDWCeJgOvrYKjlhQINcfzSVk,qFPduixDWCeJgOvrYKjlhQINcfzSVm,isFolder)
 def dp_Main_List(qFPduixDWCeJgOvrYKjlhQINcfzSVL,args):
  for qFPduixDWCeJgOvrYKjlhQINcfzSVX in qFPduixDWCeJgOvrYKjlhQINcfzSVp:
   qFPduixDWCeJgOvrYKjlhQINcfzSVo=qFPduixDWCeJgOvrYKjlhQINcfzSVX.get('title')
   qFPduixDWCeJgOvrYKjlhQINcfzSVG=''
   qFPduixDWCeJgOvrYKjlhQINcfzSVH={'mode':qFPduixDWCeJgOvrYKjlhQINcfzSVX.get('mode'),'genre':qFPduixDWCeJgOvrYKjlhQINcfzSVX.get('genre'),}
   if qFPduixDWCeJgOvrYKjlhQINcfzSVX.get('mode')in['XXX']:
    qFPduixDWCeJgOvrYKjlhQINcfzSVU=qFPduixDWCeJgOvrYKjlhQINcfzSpL
    qFPduixDWCeJgOvrYKjlhQINcfzSVw =qFPduixDWCeJgOvrYKjlhQINcfzSpE
   else:
    qFPduixDWCeJgOvrYKjlhQINcfzSVU=qFPduixDWCeJgOvrYKjlhQINcfzSpE
    qFPduixDWCeJgOvrYKjlhQINcfzSVw =qFPduixDWCeJgOvrYKjlhQINcfzSpL
   if 'icon' in qFPduixDWCeJgOvrYKjlhQINcfzSVX:qFPduixDWCeJgOvrYKjlhQINcfzSVG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',qFPduixDWCeJgOvrYKjlhQINcfzSVX.get('icon')) 
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.add_dir(qFPduixDWCeJgOvrYKjlhQINcfzSVo,sublabel='',img=qFPduixDWCeJgOvrYKjlhQINcfzSVG,infoLabels=qFPduixDWCeJgOvrYKjlhQINcfzSpy,isFolder=qFPduixDWCeJgOvrYKjlhQINcfzSVU,params=qFPduixDWCeJgOvrYKjlhQINcfzSVH,isLink=qFPduixDWCeJgOvrYKjlhQINcfzSVw)
  xbmcplugin.endOfDirectory(qFPduixDWCeJgOvrYKjlhQINcfzSVL._addon_handle)
 def login_main(qFPduixDWCeJgOvrYKjlhQINcfzSVL):
  qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.KodiVersion=qFPduixDWCeJgOvrYKjlhQINcfzSpR(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  if not os.path.isdir(xbmcvfs.translatePath(__profile__)):os.mkdir(xbmcvfs.translatePath(__profile__))
  try: 
   fp=qFPduixDWCeJgOvrYKjlhQINcfzSpA(qFPduixDWCeJgOvrYKjlhQINcfzSVE,'r',-1,'utf-8')
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.SSTV= json.load(fp)
   fp.close()
  except qFPduixDWCeJgOvrYKjlhQINcfzSps as exception:
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.SSTV['limit_date']='0'
  qFPduixDWCeJgOvrYKjlhQINcfzSVt =qFPduixDWCeJgOvrYKjlhQINcfzSpR(qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  qFPduixDWCeJgOvrYKjlhQINcfzSyV=qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.SSTV['limit_date']
  qFPduixDWCeJgOvrYKjlhQINcfzSyp =qFPduixDWCeJgOvrYKjlhQINcfzSpR(re.sub('-','',qFPduixDWCeJgOvrYKjlhQINcfzSyV))
  if qFPduixDWCeJgOvrYKjlhQINcfzSVt<=qFPduixDWCeJgOvrYKjlhQINcfzSyp:
   return qFPduixDWCeJgOvrYKjlhQINcfzSpE
  if qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.Get_BaseCookies()==qFPduixDWCeJgOvrYKjlhQINcfzSpL:
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.addon_noti('init error!')
   return qFPduixDWCeJgOvrYKjlhQINcfzSpL
  qFPduixDWCeJgOvrYKjlhQINcfzSyE =qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.Get_Now_Datetime()
  qFPduixDWCeJgOvrYKjlhQINcfzSyL=qFPduixDWCeJgOvrYKjlhQINcfzSyE+datetime.timedelta(days=qFPduixDWCeJgOvrYKjlhQINcfzSpR(__addon__.getSetting('cache_ttl')))
  qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.SSTV['limit_date']=qFPduixDWCeJgOvrYKjlhQINcfzSyL.strftime('%Y-%m-%d')
  try: 
   fp=qFPduixDWCeJgOvrYKjlhQINcfzSpA(qFPduixDWCeJgOvrYKjlhQINcfzSVE,'w',-1,'utf-8')
   json.dump(qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.SSTV,fp,indent=4,ensure_ascii=qFPduixDWCeJgOvrYKjlhQINcfzSpL)
   fp.close()
  except qFPduixDWCeJgOvrYKjlhQINcfzSps as exception:
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.addon_noti('file save error!')
   return qFPduixDWCeJgOvrYKjlhQINcfzSpL
  return qFPduixDWCeJgOvrYKjlhQINcfzSpE
 def dp_LiveChannel_List(qFPduixDWCeJgOvrYKjlhQINcfzSVL,args):
  qFPduixDWCeJgOvrYKjlhQINcfzSyb=args.get('genre')
  qFPduixDWCeJgOvrYKjlhQINcfzSyR=qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.GetLiveChannelList(view_genre=qFPduixDWCeJgOvrYKjlhQINcfzSyb)
  for qFPduixDWCeJgOvrYKjlhQINcfzSyA in qFPduixDWCeJgOvrYKjlhQINcfzSyR:
   qFPduixDWCeJgOvrYKjlhQINcfzSys =qFPduixDWCeJgOvrYKjlhQINcfzSyA.get('chid')
   qFPduixDWCeJgOvrYKjlhQINcfzSyT =qFPduixDWCeJgOvrYKjlhQINcfzSyA.get('channlnm')
   qFPduixDWCeJgOvrYKjlhQINcfzSyB =qFPduixDWCeJgOvrYKjlhQINcfzSyA.get('genre')
   qFPduixDWCeJgOvrYKjlhQINcfzSya =qFPduixDWCeJgOvrYKjlhQINcfzSyA.get('programnm')
   qFPduixDWCeJgOvrYKjlhQINcfzSyk =qFPduixDWCeJgOvrYKjlhQINcfzSyA.get('thumbnail')
   qFPduixDWCeJgOvrYKjlhQINcfzSyo =qFPduixDWCeJgOvrYKjlhQINcfzSyA.get('epg')
   qFPduixDWCeJgOvrYKjlhQINcfzSym={'mediatype':'episode','title':qFPduixDWCeJgOvrYKjlhQINcfzSya,'studio':qFPduixDWCeJgOvrYKjlhQINcfzSyT,'genre':qFPduixDWCeJgOvrYKjlhQINcfzSyB,'plot':'%s\n\n%s'%(qFPduixDWCeJgOvrYKjlhQINcfzSyT,qFPduixDWCeJgOvrYKjlhQINcfzSyo),}
   qFPduixDWCeJgOvrYKjlhQINcfzSVH={'mode':'LIVE','chid':qFPduixDWCeJgOvrYKjlhQINcfzSys,}
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.add_dir(qFPduixDWCeJgOvrYKjlhQINcfzSyT,sublabel=qFPduixDWCeJgOvrYKjlhQINcfzSya,img=qFPduixDWCeJgOvrYKjlhQINcfzSyk,infoLabels=qFPduixDWCeJgOvrYKjlhQINcfzSym,isFolder=qFPduixDWCeJgOvrYKjlhQINcfzSpL,params=qFPduixDWCeJgOvrYKjlhQINcfzSVH)
  xbmcplugin.endOfDirectory(qFPduixDWCeJgOvrYKjlhQINcfzSVL._addon_handle,cacheToDisc=qFPduixDWCeJgOvrYKjlhQINcfzSpL)
 def dp_LiveGroup_List(qFPduixDWCeJgOvrYKjlhQINcfzSVL,args):
  qFPduixDWCeJgOvrYKjlhQINcfzSyR=qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.GetGenreList()
  for qFPduixDWCeJgOvrYKjlhQINcfzSyA in qFPduixDWCeJgOvrYKjlhQINcfzSyR:
   qFPduixDWCeJgOvrYKjlhQINcfzSyb =qFPduixDWCeJgOvrYKjlhQINcfzSyA.get('genre')
   qFPduixDWCeJgOvrYKjlhQINcfzSym={'plot':qFPduixDWCeJgOvrYKjlhQINcfzSyb}
   qFPduixDWCeJgOvrYKjlhQINcfzSVH={'mode':'LIVE_LIST','genre':qFPduixDWCeJgOvrYKjlhQINcfzSyb,}
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.add_dir(qFPduixDWCeJgOvrYKjlhQINcfzSyb,sublabel='',img='',infoLabels=qFPduixDWCeJgOvrYKjlhQINcfzSym,isFolder=qFPduixDWCeJgOvrYKjlhQINcfzSpE,params=qFPduixDWCeJgOvrYKjlhQINcfzSVH)
  xbmcplugin.endOfDirectory(qFPduixDWCeJgOvrYKjlhQINcfzSVL._addon_handle,cacheToDisc=qFPduixDWCeJgOvrYKjlhQINcfzSpL)
 def play_VIDEO(qFPduixDWCeJgOvrYKjlhQINcfzSVL,args):
  qFPduixDWCeJgOvrYKjlhQINcfzSys =args.get('chid')
  qFPduixDWCeJgOvrYKjlhQINcfzSyG=qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.GetBroadURL(qFPduixDWCeJgOvrYKjlhQINcfzSys)
  qFPduixDWCeJgOvrYKjlhQINcfzSVL.addon_log('%s - url : %s'%(qFPduixDWCeJgOvrYKjlhQINcfzSys,qFPduixDWCeJgOvrYKjlhQINcfzSyG))
  if qFPduixDWCeJgOvrYKjlhQINcfzSyG=='':
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.addon_noti(__language__(30906).encode('utf8'))
   return
  qFPduixDWCeJgOvrYKjlhQINcfzSyH={'user-agent':qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.USER_AGENT,'origin':'https://www.samsungtvplus.com',}
  qFPduixDWCeJgOvrYKjlhQINcfzSyU=qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.make_stream_header(qFPduixDWCeJgOvrYKjlhQINcfzSyH,qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.makeDefaultCookies())
  qFPduixDWCeJgOvrYKjlhQINcfzSyG='{}|{}'.format(qFPduixDWCeJgOvrYKjlhQINcfzSyG,qFPduixDWCeJgOvrYKjlhQINcfzSyU)
  qFPduixDWCeJgOvrYKjlhQINcfzSyw=xbmcgui.ListItem(path=qFPduixDWCeJgOvrYKjlhQINcfzSyG)
  qFPduixDWCeJgOvrYKjlhQINcfzSyw.setContentLookup(qFPduixDWCeJgOvrYKjlhQINcfzSpL)
  qFPduixDWCeJgOvrYKjlhQINcfzSyw.setMimeType('application/x-mpegURL')
  qFPduixDWCeJgOvrYKjlhQINcfzSyw.setProperty('inputstream','inputstream.adaptive')
  if qFPduixDWCeJgOvrYKjlhQINcfzSVL.SamsungtvObj.KodiVersion<=20:
   qFPduixDWCeJgOvrYKjlhQINcfzSyw.setProperty('inputstream.adaptive.manifest_type','hls')
  qFPduixDWCeJgOvrYKjlhQINcfzSyw.setProperty('inputstream.adaptive.stream_headers',qFPduixDWCeJgOvrYKjlhQINcfzSyU)
  qFPduixDWCeJgOvrYKjlhQINcfzSyw.setProperty('inputstream.adaptive.manifest_headers',qFPduixDWCeJgOvrYKjlhQINcfzSyU)
  xbmcplugin.setResolvedUrl(qFPduixDWCeJgOvrYKjlhQINcfzSVL._addon_handle,qFPduixDWCeJgOvrYKjlhQINcfzSpE,qFPduixDWCeJgOvrYKjlhQINcfzSyw)
 def STV_logout(qFPduixDWCeJgOvrYKjlhQINcfzSVL):
  qFPduixDWCeJgOvrYKjlhQINcfzSVs=xbmcgui.Dialog()
  qFPduixDWCeJgOvrYKjlhQINcfzSyn=qFPduixDWCeJgOvrYKjlhQINcfzSVs.yesno(__language__(30905).encode('utf8'),__language__(30907).encode('utf8'))
  if qFPduixDWCeJgOvrYKjlhQINcfzSyn==qFPduixDWCeJgOvrYKjlhQINcfzSpL:return 
  if os.path.isfile(qFPduixDWCeJgOvrYKjlhQINcfzSVE):os.remove(qFPduixDWCeJgOvrYKjlhQINcfzSVE)
  qFPduixDWCeJgOvrYKjlhQINcfzSVL.addon_noti(__language__(30904).encode('utf-8'))
 def dp_Test(qFPduixDWCeJgOvrYKjlhQINcfzSVL,args):
  qFPduixDWCeJgOvrYKjlhQINcfzSVL.addon_noti('test')
 def samsungtv_main(qFPduixDWCeJgOvrYKjlhQINcfzSVL):
  qFPduixDWCeJgOvrYKjlhQINcfzSyt=qFPduixDWCeJgOvrYKjlhQINcfzSVL.main_params.get('mode',qFPduixDWCeJgOvrYKjlhQINcfzSpy)
  if qFPduixDWCeJgOvrYKjlhQINcfzSyt=='LOGOUT':
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.STV_logout()
   return
  qFPduixDWCeJgOvrYKjlhQINcfzSVL.login_main()
  if qFPduixDWCeJgOvrYKjlhQINcfzSyt is qFPduixDWCeJgOvrYKjlhQINcfzSpy:
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.dp_Main_List(qFPduixDWCeJgOvrYKjlhQINcfzSVL.main_params)
  elif qFPduixDWCeJgOvrYKjlhQINcfzSyt=='LIVE_LIST':
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.dp_LiveChannel_List(qFPduixDWCeJgOvrYKjlhQINcfzSVL.main_params)
  elif qFPduixDWCeJgOvrYKjlhQINcfzSyt=='LIVE':
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.play_VIDEO(qFPduixDWCeJgOvrYKjlhQINcfzSVL.main_params)
  elif qFPduixDWCeJgOvrYKjlhQINcfzSyt=='LIVE_GROUP':
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.dp_LiveGroup_List(qFPduixDWCeJgOvrYKjlhQINcfzSVL.main_params)
  elif qFPduixDWCeJgOvrYKjlhQINcfzSyt=='CAPTCHA_TEST':
   qFPduixDWCeJgOvrYKjlhQINcfzSVL.dp_Test(qFPduixDWCeJgOvrYKjlhQINcfzSVL.main_params)
  else:
   qFPduixDWCeJgOvrYKjlhQINcfzSpy
# Created by pyminifier (https://github.com/liftoff/pyminifier)
