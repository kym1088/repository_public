__author__="NightRain"
sQxyAUeWgKbXDjopciakwCTVNMmFLh=object
sQxyAUeWgKbXDjopciakwCTVNMmFLR=None
sQxyAUeWgKbXDjopciakwCTVNMmFLt=False
sQxyAUeWgKbXDjopciakwCTVNMmFLn=int
sQxyAUeWgKbXDjopciakwCTVNMmFJE=len
sQxyAUeWgKbXDjopciakwCTVNMmFJL=Exception
sQxyAUeWgKbXDjopciakwCTVNMmFJu=print
sQxyAUeWgKbXDjopciakwCTVNMmFJv=True
sQxyAUeWgKbXDjopciakwCTVNMmFJH=str
sQxyAUeWgKbXDjopciakwCTVNMmFJz=range
import urllib
import re
import json
import requests
import datetime
import time
import zlib
import base64
class sQxyAUeWgKbXDjopciakwCTVNMmFEL(sQxyAUeWgKbXDjopciakwCTVNMmFLh):
 def __init__(sQxyAUeWgKbXDjopciakwCTVNMmFEJ):
  sQxyAUeWgKbXDjopciakwCTVNMmFEJ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  sQxyAUeWgKbXDjopciakwCTVNMmFEJ.DEFAULT_HEADER={'user-agent':sQxyAUeWgKbXDjopciakwCTVNMmFEJ.USER_AGENT}
  sQxyAUeWgKbXDjopciakwCTVNMmFEJ.API_DOMAIN ='https://www.samsungtvplus.com'
  sQxyAUeWgKbXDjopciakwCTVNMmFEJ.SSTV={}
  sQxyAUeWgKbXDjopciakwCTVNMmFEJ.KodiVersion=20
 def callRequestCookies(sQxyAUeWgKbXDjopciakwCTVNMmFEJ,jobtype,sQxyAUeWgKbXDjopciakwCTVNMmFEI,payload=sQxyAUeWgKbXDjopciakwCTVNMmFLR,params=sQxyAUeWgKbXDjopciakwCTVNMmFLR,headers=sQxyAUeWgKbXDjopciakwCTVNMmFLR,cookies=sQxyAUeWgKbXDjopciakwCTVNMmFLR,redirects=sQxyAUeWgKbXDjopciakwCTVNMmFLt):
  sQxyAUeWgKbXDjopciakwCTVNMmFEu=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.DEFAULT_HEADER
  if headers:sQxyAUeWgKbXDjopciakwCTVNMmFEu.update(headers)
  if jobtype=='Get':
   sQxyAUeWgKbXDjopciakwCTVNMmFEv=requests.get(sQxyAUeWgKbXDjopciakwCTVNMmFEI,params=params,headers=sQxyAUeWgKbXDjopciakwCTVNMmFEu,cookies=cookies,allow_redirects=redirects)
  else:
   sQxyAUeWgKbXDjopciakwCTVNMmFEv=requests.post(sQxyAUeWgKbXDjopciakwCTVNMmFEI,data=payload,params=params,headers=sQxyAUeWgKbXDjopciakwCTVNMmFEu,cookies=cookies,allow_redirects=redirects)
  return sQxyAUeWgKbXDjopciakwCTVNMmFEv
 def Get_Now_Datetime(sQxyAUeWgKbXDjopciakwCTVNMmFEJ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(sQxyAUeWgKbXDjopciakwCTVNMmFEJ):
  sQxyAUeWgKbXDjopciakwCTVNMmFEz =sQxyAUeWgKbXDjopciakwCTVNMmFLn(time.time())
  sQxyAUeWgKbXDjopciakwCTVNMmFEq=sQxyAUeWgKbXDjopciakwCTVNMmFLn(sQxyAUeWgKbXDjopciakwCTVNMmFEz-sQxyAUeWgKbXDjopciakwCTVNMmFEz%3600)
  return sQxyAUeWgKbXDjopciakwCTVNMmFEq,sQxyAUeWgKbXDjopciakwCTVNMmFEz
 def zlib_decompress(sQxyAUeWgKbXDjopciakwCTVNMmFEJ,sQxyAUeWgKbXDjopciakwCTVNMmFEB):
  sQxyAUeWgKbXDjopciakwCTVNMmFEY=zlib.decompress(base64.standard_b64decode(sQxyAUeWgKbXDjopciakwCTVNMmFEB))
  return sQxyAUeWgKbXDjopciakwCTVNMmFEY.decode('utf-8')
 def zlib_compress(sQxyAUeWgKbXDjopciakwCTVNMmFEJ,sQxyAUeWgKbXDjopciakwCTVNMmFEY):
  sQxyAUeWgKbXDjopciakwCTVNMmFEB=zlib.compress(sQxyAUeWgKbXDjopciakwCTVNMmFEY.encode('utf-8'))
  return base64.standard_b64encode(sQxyAUeWgKbXDjopciakwCTVNMmFEB).decode('utf-8')
 def makeDefaultCookies(sQxyAUeWgKbXDjopciakwCTVNMmFEJ,vToken=sQxyAUeWgKbXDjopciakwCTVNMmFLR,vUserinfo=sQxyAUeWgKbXDjopciakwCTVNMmFLR):
  sQxyAUeWgKbXDjopciakwCTVNMmFEG={}
  if sQxyAUeWgKbXDjopciakwCTVNMmFEJ.SSTV.get('session') !='':sQxyAUeWgKbXDjopciakwCTVNMmFEG['session'] =sQxyAUeWgKbXDjopciakwCTVNMmFEJ.SSTV.get('session')
  if sQxyAUeWgKbXDjopciakwCTVNMmFEJ.SSTV.get('session.sig')!='':sQxyAUeWgKbXDjopciakwCTVNMmFEG['session.sig']=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.SSTV.get('session.sig')
  return sQxyAUeWgKbXDjopciakwCTVNMmFEG
 def make_stream_header(sQxyAUeWgKbXDjopciakwCTVNMmFEJ,sQxyAUeWgKbXDjopciakwCTVNMmFEP,sQxyAUeWgKbXDjopciakwCTVNMmFEG):
  sQxyAUeWgKbXDjopciakwCTVNMmFEd=''
  if sQxyAUeWgKbXDjopciakwCTVNMmFEG not in[{},sQxyAUeWgKbXDjopciakwCTVNMmFLR,'']:
   sQxyAUeWgKbXDjopciakwCTVNMmFEf=sQxyAUeWgKbXDjopciakwCTVNMmFJE(sQxyAUeWgKbXDjopciakwCTVNMmFEG)
   for sQxyAUeWgKbXDjopciakwCTVNMmFEr,sQxyAUeWgKbXDjopciakwCTVNMmFEO in sQxyAUeWgKbXDjopciakwCTVNMmFEG.items():
    sQxyAUeWgKbXDjopciakwCTVNMmFEd+='{}={}'.format(sQxyAUeWgKbXDjopciakwCTVNMmFEr,sQxyAUeWgKbXDjopciakwCTVNMmFEO)
    sQxyAUeWgKbXDjopciakwCTVNMmFEf+=-1
    if sQxyAUeWgKbXDjopciakwCTVNMmFEf>0:sQxyAUeWgKbXDjopciakwCTVNMmFEd+='; '
   sQxyAUeWgKbXDjopciakwCTVNMmFEP['cookie']=sQxyAUeWgKbXDjopciakwCTVNMmFEd
  sQxyAUeWgKbXDjopciakwCTVNMmFEl=''
  i=0
  for sQxyAUeWgKbXDjopciakwCTVNMmFEr,sQxyAUeWgKbXDjopciakwCTVNMmFEO in sQxyAUeWgKbXDjopciakwCTVNMmFEP.items():
   i=i+1
   if i>1:sQxyAUeWgKbXDjopciakwCTVNMmFEl+='&'
   sQxyAUeWgKbXDjopciakwCTVNMmFEl+='{}={}'.format(sQxyAUeWgKbXDjopciakwCTVNMmFEr,urllib.parse.quote(sQxyAUeWgKbXDjopciakwCTVNMmFEO))
  return sQxyAUeWgKbXDjopciakwCTVNMmFEl
 def Get_BaseCookies(sQxyAUeWgKbXDjopciakwCTVNMmFEJ):
  try:
   sQxyAUeWgKbXDjopciakwCTVNMmFEI=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.API_DOMAIN
   sQxyAUeWgKbXDjopciakwCTVNMmFES=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.callRequestCookies('Get',sQxyAUeWgKbXDjopciakwCTVNMmFEI,payload=sQxyAUeWgKbXDjopciakwCTVNMmFLR,params=sQxyAUeWgKbXDjopciakwCTVNMmFLR,headers=sQxyAUeWgKbXDjopciakwCTVNMmFLR,cookies=sQxyAUeWgKbXDjopciakwCTVNMmFLR)
   for sQxyAUeWgKbXDjopciakwCTVNMmFEh in sQxyAUeWgKbXDjopciakwCTVNMmFES.cookies:
    if sQxyAUeWgKbXDjopciakwCTVNMmFEh.name=='session':
     sQxyAUeWgKbXDjopciakwCTVNMmFEJ.SSTV['session']=sQxyAUeWgKbXDjopciakwCTVNMmFEh.value
    elif sQxyAUeWgKbXDjopciakwCTVNMmFEh.name=='session.sig':
     sQxyAUeWgKbXDjopciakwCTVNMmFEJ.SSTV['session.sig']=sQxyAUeWgKbXDjopciakwCTVNMmFEh.value
  except sQxyAUeWgKbXDjopciakwCTVNMmFJL as exception:
   sQxyAUeWgKbXDjopciakwCTVNMmFJu(exception)
   return sQxyAUeWgKbXDjopciakwCTVNMmFLt
  try:
   sQxyAUeWgKbXDjopciakwCTVNMmFEI=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.API_DOMAIN+'/user'
   sQxyAUeWgKbXDjopciakwCTVNMmFEG=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.makeDefaultCookies()
   sQxyAUeWgKbXDjopciakwCTVNMmFES=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.callRequestCookies('Get',sQxyAUeWgKbXDjopciakwCTVNMmFEI,payload=sQxyAUeWgKbXDjopciakwCTVNMmFLR,params=sQxyAUeWgKbXDjopciakwCTVNMmFLR,headers=sQxyAUeWgKbXDjopciakwCTVNMmFLR,cookies=sQxyAUeWgKbXDjopciakwCTVNMmFEG)
   sQxyAUeWgKbXDjopciakwCTVNMmFER=json.loads(sQxyAUeWgKbXDjopciakwCTVNMmFES.text)
   sQxyAUeWgKbXDjopciakwCTVNMmFEJ.SSTV['countryCode']=sQxyAUeWgKbXDjopciakwCTVNMmFER.get('countryCode')
   sQxyAUeWgKbXDjopciakwCTVNMmFEJ.SSTV['uuid'] =sQxyAUeWgKbXDjopciakwCTVNMmFER.get('uuid')
   sQxyAUeWgKbXDjopciakwCTVNMmFEJ.SSTV['ip'] =sQxyAUeWgKbXDjopciakwCTVNMmFER.get('ip')
  except sQxyAUeWgKbXDjopciakwCTVNMmFJL as exception:
   sQxyAUeWgKbXDjopciakwCTVNMmFJu(exception)
   return sQxyAUeWgKbXDjopciakwCTVNMmFLt
  return sQxyAUeWgKbXDjopciakwCTVNMmFJv
 def Get_BaseJson_Request(sQxyAUeWgKbXDjopciakwCTVNMmFEJ):
  sQxyAUeWgKbXDjopciakwCTVNMmFER={}
  try:
   sQxyAUeWgKbXDjopciakwCTVNMmFEI=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.API_DOMAIN+'/api/lives'
   sQxyAUeWgKbXDjopciakwCTVNMmFEq,sQxyAUeWgKbXDjopciakwCTVNMmFEz=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.GetNoCache()
   sQxyAUeWgKbXDjopciakwCTVNMmFEt=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.zlib_compress(sQxyAUeWgKbXDjopciakwCTVNMmFEJ.SSTV['uuid']+':'+sQxyAUeWgKbXDjopciakwCTVNMmFJH(sQxyAUeWgKbXDjopciakwCTVNMmFEz))
   sQxyAUeWgKbXDjopciakwCTVNMmFEG =sQxyAUeWgKbXDjopciakwCTVNMmFEJ.makeDefaultCookies()
   sQxyAUeWgKbXDjopciakwCTVNMmFEn ={'t':sQxyAUeWgKbXDjopciakwCTVNMmFJH(sQxyAUeWgKbXDjopciakwCTVNMmFEq)}
   sQxyAUeWgKbXDjopciakwCTVNMmFEP ={'x-cred-payload':sQxyAUeWgKbXDjopciakwCTVNMmFEt}
   sQxyAUeWgKbXDjopciakwCTVNMmFES=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.callRequestCookies('Get',sQxyAUeWgKbXDjopciakwCTVNMmFEI,payload=sQxyAUeWgKbXDjopciakwCTVNMmFLR,params=sQxyAUeWgKbXDjopciakwCTVNMmFEn,headers=sQxyAUeWgKbXDjopciakwCTVNMmFEP,cookies=sQxyAUeWgKbXDjopciakwCTVNMmFEG)
   sQxyAUeWgKbXDjopciakwCTVNMmFER=json.loads(sQxyAUeWgKbXDjopciakwCTVNMmFES.text)
  except sQxyAUeWgKbXDjopciakwCTVNMmFJL as exception:
   sQxyAUeWgKbXDjopciakwCTVNMmFJu(exception)
  return sQxyAUeWgKbXDjopciakwCTVNMmFER
 def GetGenreList(sQxyAUeWgKbXDjopciakwCTVNMmFEJ):
  sQxyAUeWgKbXDjopciakwCTVNMmFLE=[]
  try:
   sQxyAUeWgKbXDjopciakwCTVNMmFER=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.Get_BaseJson_Request()
   sQxyAUeWgKbXDjopciakwCTVNMmFLJ=sQxyAUeWgKbXDjopciakwCTVNMmFER['live']['genrelist']
   for sQxyAUeWgKbXDjopciakwCTVNMmFLu in sQxyAUeWgKbXDjopciakwCTVNMmFLJ:
    sQxyAUeWgKbXDjopciakwCTVNMmFLv={'genre':sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('name'),}
    sQxyAUeWgKbXDjopciakwCTVNMmFLE.append(sQxyAUeWgKbXDjopciakwCTVNMmFLv)
  except sQxyAUeWgKbXDjopciakwCTVNMmFJL as exception:
   sQxyAUeWgKbXDjopciakwCTVNMmFJu(exception)
  return sQxyAUeWgKbXDjopciakwCTVNMmFLE
 def GetLiveChannelList(sQxyAUeWgKbXDjopciakwCTVNMmFEJ,view_genre='-'):
  sQxyAUeWgKbXDjopciakwCTVNMmFLE=[]
  try:
   sQxyAUeWgKbXDjopciakwCTVNMmFER=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.Get_BaseJson_Request()
   sQxyAUeWgKbXDjopciakwCTVNMmFLJ=sQxyAUeWgKbXDjopciakwCTVNMmFER['live']['channel']
   for sQxyAUeWgKbXDjopciakwCTVNMmFLu in sQxyAUeWgKbXDjopciakwCTVNMmFLJ:
    sQxyAUeWgKbXDjopciakwCTVNMmFLH=sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('genre').get('name')
    if sQxyAUeWgKbXDjopciakwCTVNMmFLH!=view_genre and view_genre!='-':continue
    sQxyAUeWgKbXDjopciakwCTVNMmFLz=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.Make_EpgList(sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('program'))
    if sQxyAUeWgKbXDjopciakwCTVNMmFJE(sQxyAUeWgKbXDjopciakwCTVNMmFLz)>1:
     sQxyAUeWgKbXDjopciakwCTVNMmFLq=sQxyAUeWgKbXDjopciakwCTVNMmFLz[0].get('endtm').replace('-','').replace(':','').replace(' ','')
     sQxyAUeWgKbXDjopciakwCTVNMmFEz=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.Get_Now_Datetime().strftime('%Y%m%d%H%M')
     if sQxyAUeWgKbXDjopciakwCTVNMmFLn(sQxyAUeWgKbXDjopciakwCTVNMmFLq)<sQxyAUeWgKbXDjopciakwCTVNMmFLn(sQxyAUeWgKbXDjopciakwCTVNMmFEz):
      sQxyAUeWgKbXDjopciakwCTVNMmFLz.pop(0)
    sQxyAUeWgKbXDjopciakwCTVNMmFLY =sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('logo')
    sQxyAUeWgKbXDjopciakwCTVNMmFLB=sQxyAUeWgKbXDjopciakwCTVNMmFLz[0].get('thumbnail')
    sQxyAUeWgKbXDjopciakwCTVNMmFLv={'chid':sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('id'),'channlnm':sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('name'),'genre':sQxyAUeWgKbXDjopciakwCTVNMmFLH,'programnm':sQxyAUeWgKbXDjopciakwCTVNMmFLz[0].get('title'),'thumbnail':{'thumb':sQxyAUeWgKbXDjopciakwCTVNMmFLB,'clearlogo':sQxyAUeWgKbXDjopciakwCTVNMmFLY,'icon':sQxyAUeWgKbXDjopciakwCTVNMmFLY,'fanart':sQxyAUeWgKbXDjopciakwCTVNMmFLB},'epg':sQxyAUeWgKbXDjopciakwCTVNMmFEJ.Make_EpgString(sQxyAUeWgKbXDjopciakwCTVNMmFLz),}
    sQxyAUeWgKbXDjopciakwCTVNMmFLE.append(sQxyAUeWgKbXDjopciakwCTVNMmFLv)
  except sQxyAUeWgKbXDjopciakwCTVNMmFJL as exception:
   sQxyAUeWgKbXDjopciakwCTVNMmFJu(exception)
  return sQxyAUeWgKbXDjopciakwCTVNMmFLE
 def Make_EpgList(sQxyAUeWgKbXDjopciakwCTVNMmFEJ,programList):
  sQxyAUeWgKbXDjopciakwCTVNMmFLz=[]
  try:
   for sQxyAUeWgKbXDjopciakwCTVNMmFLu in programList:
    sQxyAUeWgKbXDjopciakwCTVNMmFLG=sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('start_time')
    sQxyAUeWgKbXDjopciakwCTVNMmFLd =sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('duration') 
    sQxyAUeWgKbXDjopciakwCTVNMmFLf=datetime.datetime.strptime(sQxyAUeWgKbXDjopciakwCTVNMmFLG,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
    sQxyAUeWgKbXDjopciakwCTVNMmFLq =sQxyAUeWgKbXDjopciakwCTVNMmFLf+datetime.timedelta(seconds=sQxyAUeWgKbXDjopciakwCTVNMmFLd)
    sQxyAUeWgKbXDjopciakwCTVNMmFLv={'title':sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('title'),'starttm':sQxyAUeWgKbXDjopciakwCTVNMmFLf.strftime('%Y-%m-%d %H:%M'),'endtm':sQxyAUeWgKbXDjopciakwCTVNMmFLq.strftime('%Y-%m-%d %H:%M'),'thumbnail':sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('thumbnail'),}
    sQxyAUeWgKbXDjopciakwCTVNMmFLz.append(sQxyAUeWgKbXDjopciakwCTVNMmFLv)
  except sQxyAUeWgKbXDjopciakwCTVNMmFJL as exception:
   sQxyAUeWgKbXDjopciakwCTVNMmFJu(exception)
  return sQxyAUeWgKbXDjopciakwCTVNMmFLz
 def Make_EpgString(sQxyAUeWgKbXDjopciakwCTVNMmFEJ,sQxyAUeWgKbXDjopciakwCTVNMmFLz):
  sQxyAUeWgKbXDjopciakwCTVNMmFLr=''
  try:
   for i in sQxyAUeWgKbXDjopciakwCTVNMmFJz(sQxyAUeWgKbXDjopciakwCTVNMmFJE(sQxyAUeWgKbXDjopciakwCTVNMmFLz)):
    if i>3:break
    sQxyAUeWgKbXDjopciakwCTVNMmFLO=sQxyAUeWgKbXDjopciakwCTVNMmFLz[i].get('starttm')[-5:]
    sQxyAUeWgKbXDjopciakwCTVNMmFLP =sQxyAUeWgKbXDjopciakwCTVNMmFLz[i].get('endtm')[-5:]
    sQxyAUeWgKbXDjopciakwCTVNMmFLl =sQxyAUeWgKbXDjopciakwCTVNMmFLz[i].get('title')
    sQxyAUeWgKbXDjopciakwCTVNMmFLr+='%s\n[%s ~ %s]\n\n'%(sQxyAUeWgKbXDjopciakwCTVNMmFLl,sQxyAUeWgKbXDjopciakwCTVNMmFLO,sQxyAUeWgKbXDjopciakwCTVNMmFLP)
  except sQxyAUeWgKbXDjopciakwCTVNMmFJL as exception:
   sQxyAUeWgKbXDjopciakwCTVNMmFJu(exception)
  return sQxyAUeWgKbXDjopciakwCTVNMmFLr
 def GetBroadURL(sQxyAUeWgKbXDjopciakwCTVNMmFEJ,chid):
  sQxyAUeWgKbXDjopciakwCTVNMmFLI=''
  try:
   sQxyAUeWgKbXDjopciakwCTVNMmFER=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.Get_BaseJson_Request()
   sQxyAUeWgKbXDjopciakwCTVNMmFLJ=sQxyAUeWgKbXDjopciakwCTVNMmFER['live']['channel']
   for sQxyAUeWgKbXDjopciakwCTVNMmFLu in sQxyAUeWgKbXDjopciakwCTVNMmFLJ:
    if sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('id')==chid:
     sQxyAUeWgKbXDjopciakwCTVNMmFLS =sQxyAUeWgKbXDjopciakwCTVNMmFLu.get('program')[0].get('stream_url')
     sQxyAUeWgKbXDjopciakwCTVNMmFLI=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.zlib_decompress(sQxyAUeWgKbXDjopciakwCTVNMmFLS)
     break
  except sQxyAUeWgKbXDjopciakwCTVNMmFJL as exception:
   sQxyAUeWgKbXDjopciakwCTVNMmFJu(exception)
  return sQxyAUeWgKbXDjopciakwCTVNMmFLI
 def GetTest(sQxyAUeWgKbXDjopciakwCTVNMmFEJ,streamurl):
  try:
   sQxyAUeWgKbXDjopciakwCTVNMmFEI=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.zlib_decompress(streamurl)
   sQxyAUeWgKbXDjopciakwCTVNMmFJu(sQxyAUeWgKbXDjopciakwCTVNMmFEI)
   sQxyAUeWgKbXDjopciakwCTVNMmFEI='https://play-kr.samsungtvplus.com/tvplus/web/v3/play?tid=eVFDcm9hRjhaR1RVNHAva2JJWTR3dm5YWGo3SWlIekpoUENlbmRaaDVCRXROSU9DbWRoT3lKN3JHbGdnU1BSTUlzUHptbFBGS01qWG9hYjdoZElQTXRrZ3ozbXlsUkdIOHoxTGxDcGRsekhnaXJ0Q21qUU1ycWNZdURmWjhidUxyZFpxUjdiODFUZEs1NFFBYm9hWnBPL2gvZXRINWZ0cVJhMFA3RjFZUXU2NVJtZVpZZGl6VjhmUXhCWnVWaEQwZjV2L1hTeUhOblN1akRLR2dsYzVvQzREclhUYzdOc1NzUlZkTVp5UnF6OG5HWERDRjR0dHVDUmxuRVpjbk81eSt1RXhiZkN5aHJUZWRyemdSWWloQURyTnZmRlFwQnVVZTdzay9Ob2ZBekk9'
   sQxyAUeWgKbXDjopciakwCTVNMmFEP ={'origin':sQxyAUeWgKbXDjopciakwCTVNMmFEJ.API_DOMAIN}
   sQxyAUeWgKbXDjopciakwCTVNMmFES=sQxyAUeWgKbXDjopciakwCTVNMmFEJ.callRequestCookies('Get',sQxyAUeWgKbXDjopciakwCTVNMmFEI,payload=sQxyAUeWgKbXDjopciakwCTVNMmFLR,params=sQxyAUeWgKbXDjopciakwCTVNMmFLR,headers=sQxyAUeWgKbXDjopciakwCTVNMmFEP,cookies=sQxyAUeWgKbXDjopciakwCTVNMmFLR)
   sQxyAUeWgKbXDjopciakwCTVNMmFJu(sQxyAUeWgKbXDjopciakwCTVNMmFES.text)
  except sQxyAUeWgKbXDjopciakwCTVNMmFJL as exception:
   sQxyAUeWgKbXDjopciakwCTVNMmFJu(exception)
  return
# Created by pyminifier (https://github.com/liftoff/pyminifier)
