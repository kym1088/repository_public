__author__="NightRain"
lBiofMnLcRYNHDrTWpVFUvxGqJdKwC=object
lBiofMnLcRYNHDrTWpVFUvxGqJdKwz=None
lBiofMnLcRYNHDrTWpVFUvxGqJdKwy=True
lBiofMnLcRYNHDrTWpVFUvxGqJdKwe=False
lBiofMnLcRYNHDrTWpVFUvxGqJdKwE=type
lBiofMnLcRYNHDrTWpVFUvxGqJdKwa=dict
lBiofMnLcRYNHDrTWpVFUvxGqJdKwA=int
lBiofMnLcRYNHDrTWpVFUvxGqJdKwX=open
lBiofMnLcRYNHDrTWpVFUvxGqJdKwO=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import inputstreamhelper
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
lBiofMnLcRYNHDrTWpVFUvxGqJdKPw=[{'title':'실시간 (전체)','mode':'LIVE_LIST','genre':'-'},{'title':'실시간 (장르별)','mode':'LIVE_GROUP'},]
lBiofMnLcRYNHDrTWpVFUvxGqJdKPz =xbmcvfs.translatePath(os.path.join(__profile__,'samsungtv_cookies.json'))
from samsungtvCore import*
class lBiofMnLcRYNHDrTWpVFUvxGqJdKPC(lBiofMnLcRYNHDrTWpVFUvxGqJdKwC):
 def __init__(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy,lBiofMnLcRYNHDrTWpVFUvxGqJdKPe,lBiofMnLcRYNHDrTWpVFUvxGqJdKPE,lBiofMnLcRYNHDrTWpVFUvxGqJdKPa):
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPy._addon_url =lBiofMnLcRYNHDrTWpVFUvxGqJdKPe
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPy._addon_handle=lBiofMnLcRYNHDrTWpVFUvxGqJdKPE
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.main_params =lBiofMnLcRYNHDrTWpVFUvxGqJdKPa
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj =sQxyAUeWgKbXDjopciakwCTVNMmFEL() 
 def addon_noti(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy,sting):
  try:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPX=xbmcgui.Dialog()
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPX.notification(__addonname__,sting)
  except:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKwz
 def addon_log(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy,string):
  try:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPO=string.encode('utf-8','ignore')
  except:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPO='addonException: addon_log'
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPk=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,lBiofMnLcRYNHDrTWpVFUvxGqJdKPO),level=lBiofMnLcRYNHDrTWpVFUvxGqJdKPk)
 def get_keyboard_input(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy,lBiofMnLcRYNHDrTWpVFUvxGqJdKPu):
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPQ=lBiofMnLcRYNHDrTWpVFUvxGqJdKwz
  kb=xbmc.Keyboard()
  kb.setHeading(lBiofMnLcRYNHDrTWpVFUvxGqJdKPu)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPQ=kb.getText()
  return lBiofMnLcRYNHDrTWpVFUvxGqJdKPQ
 def add_dir(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy,label,sublabel='',img='',infoLabels=lBiofMnLcRYNHDrTWpVFUvxGqJdKwz,isFolder=lBiofMnLcRYNHDrTWpVFUvxGqJdKwy,params='',isLink=lBiofMnLcRYNHDrTWpVFUvxGqJdKwe,ContextMenu=lBiofMnLcRYNHDrTWpVFUvxGqJdKwz):
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPS='%s?%s'%(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy._addon_url,urllib.parse.urlencode(params))
  if sublabel:lBiofMnLcRYNHDrTWpVFUvxGqJdKPu='%s < %s >'%(label,sublabel)
  else: lBiofMnLcRYNHDrTWpVFUvxGqJdKPu=label
  if not img:img='DefaultFolder.png'
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPj=xbmcgui.ListItem(lBiofMnLcRYNHDrTWpVFUvxGqJdKPu)
  if lBiofMnLcRYNHDrTWpVFUvxGqJdKwE(img)==lBiofMnLcRYNHDrTWpVFUvxGqJdKwa:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPj.setArt(img)
  else:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPj.setArt({'thumb':img,'poster':img})
  if infoLabels:lBiofMnLcRYNHDrTWpVFUvxGqJdKPj.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPj.setProperty('IsPlayable','true')
  if ContextMenu:lBiofMnLcRYNHDrTWpVFUvxGqJdKPj.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy._addon_handle,lBiofMnLcRYNHDrTWpVFUvxGqJdKPS,lBiofMnLcRYNHDrTWpVFUvxGqJdKPj,isFolder)
 def dp_Main_List(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy,args):
  for lBiofMnLcRYNHDrTWpVFUvxGqJdKPt in lBiofMnLcRYNHDrTWpVFUvxGqJdKPw:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPu=lBiofMnLcRYNHDrTWpVFUvxGqJdKPt.get('title')
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPm=''
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPg={'mode':lBiofMnLcRYNHDrTWpVFUvxGqJdKPt.get('mode'),'genre':lBiofMnLcRYNHDrTWpVFUvxGqJdKPt.get('genre'),}
   if lBiofMnLcRYNHDrTWpVFUvxGqJdKPt.get('mode')in['XXX']:
    lBiofMnLcRYNHDrTWpVFUvxGqJdKPI=lBiofMnLcRYNHDrTWpVFUvxGqJdKwe
    lBiofMnLcRYNHDrTWpVFUvxGqJdKPs =lBiofMnLcRYNHDrTWpVFUvxGqJdKwy
   else:
    lBiofMnLcRYNHDrTWpVFUvxGqJdKPI=lBiofMnLcRYNHDrTWpVFUvxGqJdKwy
    lBiofMnLcRYNHDrTWpVFUvxGqJdKPs =lBiofMnLcRYNHDrTWpVFUvxGqJdKwe
   if 'icon' in lBiofMnLcRYNHDrTWpVFUvxGqJdKPt:lBiofMnLcRYNHDrTWpVFUvxGqJdKPm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',lBiofMnLcRYNHDrTWpVFUvxGqJdKPt.get('icon')) 
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.add_dir(lBiofMnLcRYNHDrTWpVFUvxGqJdKPu,sublabel='',img=lBiofMnLcRYNHDrTWpVFUvxGqJdKPm,infoLabels=lBiofMnLcRYNHDrTWpVFUvxGqJdKwz,isFolder=lBiofMnLcRYNHDrTWpVFUvxGqJdKPI,params=lBiofMnLcRYNHDrTWpVFUvxGqJdKPg,isLink=lBiofMnLcRYNHDrTWpVFUvxGqJdKPs)
  xbmcplugin.endOfDirectory(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy._addon_handle)
 def login_main(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy):
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.KodiVersion=lBiofMnLcRYNHDrTWpVFUvxGqJdKwA(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  if not os.path.isdir(xbmcvfs.translatePath(__profile__)):os.mkdir(xbmcvfs.translatePath(__profile__))
  try: 
   fp=lBiofMnLcRYNHDrTWpVFUvxGqJdKwX(lBiofMnLcRYNHDrTWpVFUvxGqJdKPz,'r',-1,'utf-8')
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.SSTV= json.load(fp)
   fp.close()
  except lBiofMnLcRYNHDrTWpVFUvxGqJdKwO as exception:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.SSTV['limit_date']='0'
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPh =lBiofMnLcRYNHDrTWpVFUvxGqJdKwA(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCP=lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.SSTV['limit_date']
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCw =lBiofMnLcRYNHDrTWpVFUvxGqJdKwA(re.sub('-','',lBiofMnLcRYNHDrTWpVFUvxGqJdKCP))
  if lBiofMnLcRYNHDrTWpVFUvxGqJdKPh<=lBiofMnLcRYNHDrTWpVFUvxGqJdKCw:
   return lBiofMnLcRYNHDrTWpVFUvxGqJdKwy
  if lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.Get_BaseCookies()==lBiofMnLcRYNHDrTWpVFUvxGqJdKwe:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.addon_noti('init error!')
   return lBiofMnLcRYNHDrTWpVFUvxGqJdKwe
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCz =lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.Get_Now_Datetime()
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCy=lBiofMnLcRYNHDrTWpVFUvxGqJdKCz+datetime.timedelta(days=lBiofMnLcRYNHDrTWpVFUvxGqJdKwA(__addon__.getSetting('cache_ttl')))
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.SSTV['limit_date']=lBiofMnLcRYNHDrTWpVFUvxGqJdKCy.strftime('%Y-%m-%d')
  try: 
   fp=lBiofMnLcRYNHDrTWpVFUvxGqJdKwX(lBiofMnLcRYNHDrTWpVFUvxGqJdKPz,'w',-1,'utf-8')
   json.dump(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.SSTV,fp,indent=4,ensure_ascii=lBiofMnLcRYNHDrTWpVFUvxGqJdKwe)
   fp.close()
  except lBiofMnLcRYNHDrTWpVFUvxGqJdKwO as exception:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.addon_noti('file save error!')
   return lBiofMnLcRYNHDrTWpVFUvxGqJdKwe
  return lBiofMnLcRYNHDrTWpVFUvxGqJdKwy
 def dp_LiveChannel_List(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy,args):
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCE=args.get('genre')
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCa=lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.GetLiveChannelList(view_genre=lBiofMnLcRYNHDrTWpVFUvxGqJdKCE)
  for lBiofMnLcRYNHDrTWpVFUvxGqJdKCA in lBiofMnLcRYNHDrTWpVFUvxGqJdKCa:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKCX =lBiofMnLcRYNHDrTWpVFUvxGqJdKCA.get('chid')
   lBiofMnLcRYNHDrTWpVFUvxGqJdKCO =lBiofMnLcRYNHDrTWpVFUvxGqJdKCA.get('channlnm')
   lBiofMnLcRYNHDrTWpVFUvxGqJdKCk =lBiofMnLcRYNHDrTWpVFUvxGqJdKCA.get('genre')
   lBiofMnLcRYNHDrTWpVFUvxGqJdKCQ =lBiofMnLcRYNHDrTWpVFUvxGqJdKCA.get('programnm')
   lBiofMnLcRYNHDrTWpVFUvxGqJdKCS =lBiofMnLcRYNHDrTWpVFUvxGqJdKCA.get('thumbnail')
   lBiofMnLcRYNHDrTWpVFUvxGqJdKCu =lBiofMnLcRYNHDrTWpVFUvxGqJdKCA.get('epg')
   lBiofMnLcRYNHDrTWpVFUvxGqJdKCj={'mediatype':'episode','title':lBiofMnLcRYNHDrTWpVFUvxGqJdKCQ,'studio':lBiofMnLcRYNHDrTWpVFUvxGqJdKCO,'genre':lBiofMnLcRYNHDrTWpVFUvxGqJdKCk,'plot':'%s\n\n%s'%(lBiofMnLcRYNHDrTWpVFUvxGqJdKCO,lBiofMnLcRYNHDrTWpVFUvxGqJdKCu),}
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPg={'mode':'LIVE','chid':lBiofMnLcRYNHDrTWpVFUvxGqJdKCX,}
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.add_dir(lBiofMnLcRYNHDrTWpVFUvxGqJdKCO,sublabel=lBiofMnLcRYNHDrTWpVFUvxGqJdKCQ,img=lBiofMnLcRYNHDrTWpVFUvxGqJdKCS,infoLabels=lBiofMnLcRYNHDrTWpVFUvxGqJdKCj,isFolder=lBiofMnLcRYNHDrTWpVFUvxGqJdKwe,params=lBiofMnLcRYNHDrTWpVFUvxGqJdKPg)
  xbmcplugin.endOfDirectory(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy._addon_handle,cacheToDisc=lBiofMnLcRYNHDrTWpVFUvxGqJdKwe)
 def dp_LiveGroup_List(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy,args):
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCa=lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.GetGenreList()
  for lBiofMnLcRYNHDrTWpVFUvxGqJdKCA in lBiofMnLcRYNHDrTWpVFUvxGqJdKCa:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKCE =lBiofMnLcRYNHDrTWpVFUvxGqJdKCA.get('genre')
   lBiofMnLcRYNHDrTWpVFUvxGqJdKCj={'plot':lBiofMnLcRYNHDrTWpVFUvxGqJdKCE}
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPg={'mode':'LIVE_LIST','genre':lBiofMnLcRYNHDrTWpVFUvxGqJdKCE,}
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.add_dir(lBiofMnLcRYNHDrTWpVFUvxGqJdKCE,sublabel='',img='',infoLabels=lBiofMnLcRYNHDrTWpVFUvxGqJdKCj,isFolder=lBiofMnLcRYNHDrTWpVFUvxGqJdKwy,params=lBiofMnLcRYNHDrTWpVFUvxGqJdKPg)
  xbmcplugin.endOfDirectory(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy._addon_handle,cacheToDisc=lBiofMnLcRYNHDrTWpVFUvxGqJdKwe)
 def play_VIDEO(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy,args):
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCX =args.get('chid')
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCm=lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.GetBroadURL(lBiofMnLcRYNHDrTWpVFUvxGqJdKCX)
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.addon_log('%s - url : %s'%(lBiofMnLcRYNHDrTWpVFUvxGqJdKCX,lBiofMnLcRYNHDrTWpVFUvxGqJdKCm))
  if lBiofMnLcRYNHDrTWpVFUvxGqJdKCm=='':
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.addon_noti(__language__(30906).encode('utf8'))
   return
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCg={'user-agent':lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.USER_AGENT,'origin':'https://www.samsungtvplus.com',}
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCI=lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.make_stream_header(lBiofMnLcRYNHDrTWpVFUvxGqJdKCg,lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.makeDefaultCookies())
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.addon_log('stream_headers : '+lBiofMnLcRYNHDrTWpVFUvxGqJdKCI)
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCm='{}|{}'.format(lBiofMnLcRYNHDrTWpVFUvxGqJdKCm,lBiofMnLcRYNHDrTWpVFUvxGqJdKCI)
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCs=xbmcgui.ListItem(path=lBiofMnLcRYNHDrTWpVFUvxGqJdKCm)
  inputstreamhelper.Helper('hls',drm='com.widevine.alpha').check_inputstream()
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCs.setContentLookup(lBiofMnLcRYNHDrTWpVFUvxGqJdKwe)
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCs.setMimeType('application/x-mpegURL')
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCs.setProperty('inputstream','inputstream.adaptive')
  if lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.SamsungtvObj.KodiVersion<=20:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKCs.setProperty('inputstream.adaptive.manifest_type','hls')
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCs.setProperty('inputstream.adaptive.stream_headers',lBiofMnLcRYNHDrTWpVFUvxGqJdKCI)
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCs.setProperty('inputstream.adaptive.manifest_headers',lBiofMnLcRYNHDrTWpVFUvxGqJdKCI)
  xbmcplugin.setResolvedUrl(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy._addon_handle,lBiofMnLcRYNHDrTWpVFUvxGqJdKwy,lBiofMnLcRYNHDrTWpVFUvxGqJdKCs)
 def STV_logout(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy):
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPX=xbmcgui.Dialog()
  lBiofMnLcRYNHDrTWpVFUvxGqJdKCh=lBiofMnLcRYNHDrTWpVFUvxGqJdKPX.yesno(__language__(30905).encode('utf8'),__language__(30907).encode('utf8'))
  if lBiofMnLcRYNHDrTWpVFUvxGqJdKCh==lBiofMnLcRYNHDrTWpVFUvxGqJdKwe:return 
  if os.path.isfile(lBiofMnLcRYNHDrTWpVFUvxGqJdKPz):os.remove(lBiofMnLcRYNHDrTWpVFUvxGqJdKPz)
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.addon_noti(__language__(30904).encode('utf-8'))
 def dp_Test(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy,args):
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.addon_noti('test')
 def samsungtv_main(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy):
  lBiofMnLcRYNHDrTWpVFUvxGqJdKwP=lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.main_params.get('mode',lBiofMnLcRYNHDrTWpVFUvxGqJdKwz)
  if lBiofMnLcRYNHDrTWpVFUvxGqJdKwP=='LOGOUT':
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.STV_logout()
   return
  lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.login_main()
  if lBiofMnLcRYNHDrTWpVFUvxGqJdKwP is lBiofMnLcRYNHDrTWpVFUvxGqJdKwz:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.dp_Main_List(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.main_params)
  elif lBiofMnLcRYNHDrTWpVFUvxGqJdKwP=='LIVE_LIST':
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.dp_LiveChannel_List(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.main_params)
  elif lBiofMnLcRYNHDrTWpVFUvxGqJdKwP=='LIVE':
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.play_VIDEO(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.main_params)
  elif lBiofMnLcRYNHDrTWpVFUvxGqJdKwP=='LIVE_GROUP':
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.dp_LiveGroup_List(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.main_params)
  elif lBiofMnLcRYNHDrTWpVFUvxGqJdKwP=='CAPTCHA_TEST':
   lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.dp_Test(lBiofMnLcRYNHDrTWpVFUvxGqJdKPy.main_params)
  else:
   lBiofMnLcRYNHDrTWpVFUvxGqJdKwz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
