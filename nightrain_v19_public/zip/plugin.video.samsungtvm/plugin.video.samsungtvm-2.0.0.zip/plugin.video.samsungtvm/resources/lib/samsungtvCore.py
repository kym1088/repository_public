__author__="NightRain"
JSUmbaYtRKeVvcBLkWgNHIsFTDpMjr=object
JSUmbaYtRKeVvcBLkWgNHIsFTDpMju=None
JSUmbaYtRKeVvcBLkWgNHIsFTDpMjy=False
JSUmbaYtRKeVvcBLkWgNHIsFTDpMjq=int
JSUmbaYtRKeVvcBLkWgNHIsFTDpMjx=Exception
JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP=print
JSUmbaYtRKeVvcBLkWgNHIsFTDpMjC=True
JSUmbaYtRKeVvcBLkWgNHIsFTDpMjl=str
JSUmbaYtRKeVvcBLkWgNHIsFTDpMji=range
JSUmbaYtRKeVvcBLkWgNHIsFTDpMfn=len
import urllib
import re
import json
import requests
import datetime
import time
import zlib
import base64
class JSUmbaYtRKeVvcBLkWgNHIsFTDpMnj(JSUmbaYtRKeVvcBLkWgNHIsFTDpMjr):
 def __init__(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.DEFAULT_HEADER ={'user-agent':JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.USER_AGENT}
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.API_DOMAIN ='https://www.samsungtvplus.com'
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.SSTV={}
 def callRequestCookies(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf,jobtype,JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz,payload=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,params=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,headers=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,cookies=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,redirects=JSUmbaYtRKeVvcBLkWgNHIsFTDpMjy):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnO=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.DEFAULT_HEADER
  if headers:JSUmbaYtRKeVvcBLkWgNHIsFTDpMnO.update(headers)
  if jobtype=='Get':
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnX=requests.get(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz,params=params,headers=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnO,cookies=cookies,allow_redirects=redirects)
  else:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnX=requests.post(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz,data=payload,params=params,headers=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnO,cookies=cookies,allow_redirects=redirects)
  return JSUmbaYtRKeVvcBLkWgNHIsFTDpMnX
 def Get_Now_Datetime(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetNoCache(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnw =JSUmbaYtRKeVvcBLkWgNHIsFTDpMjq(time.time())
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnG=JSUmbaYtRKeVvcBLkWgNHIsFTDpMjq(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnw-JSUmbaYtRKeVvcBLkWgNHIsFTDpMnw%3600)
  return JSUmbaYtRKeVvcBLkWgNHIsFTDpMnG,JSUmbaYtRKeVvcBLkWgNHIsFTDpMnw
 def zlib_decompress(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf,JSUmbaYtRKeVvcBLkWgNHIsFTDpMnE):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnA=zlib.decompress(base64.standard_b64decode(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnE))
  return JSUmbaYtRKeVvcBLkWgNHIsFTDpMnA.decode('utf-8')
 def zlib_compress(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf,JSUmbaYtRKeVvcBLkWgNHIsFTDpMnA):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnE=zlib.compress(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnA.encode('utf-8'))
  return base64.standard_b64encode(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnE).decode('utf-8')
 def makeDefaultCookies(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf,vToken=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,vUserinfo=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnd={}
  if JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.SSTV.get('session') !='':JSUmbaYtRKeVvcBLkWgNHIsFTDpMnd['session'] =JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.SSTV.get('session')
  if JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.SSTV.get('session.sig')!='':JSUmbaYtRKeVvcBLkWgNHIsFTDpMnd['session.sig']=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.SSTV.get('session.sig')
  return JSUmbaYtRKeVvcBLkWgNHIsFTDpMnd
 def Get_BaseCookies(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf):
  try:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.API_DOMAIN
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnh=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.callRequestCookies('Get',JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz,payload=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,params=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,headers=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,cookies=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju)
   for JSUmbaYtRKeVvcBLkWgNHIsFTDpMnQ in JSUmbaYtRKeVvcBLkWgNHIsFTDpMnh.cookies:
    if JSUmbaYtRKeVvcBLkWgNHIsFTDpMnQ.name=='session':
     JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.SSTV['session']=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnQ.value
    elif JSUmbaYtRKeVvcBLkWgNHIsFTDpMnQ.name=='session.sig':
     JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.SSTV['session.sig']=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnQ.value
  except JSUmbaYtRKeVvcBLkWgNHIsFTDpMjx as exception:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP(exception)
   return JSUmbaYtRKeVvcBLkWgNHIsFTDpMjy
  try:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.API_DOMAIN+'/user'
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnd=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.makeDefaultCookies()
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnh=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.callRequestCookies('Get',JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz,payload=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,params=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,headers=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,cookies=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnd)
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr=json.loads(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnh.text)
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.SSTV['countryCode']=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr.get('countryCode')
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.SSTV['uuid'] =JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr.get('uuid')
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.SSTV['ip'] =JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr.get('ip')
  except JSUmbaYtRKeVvcBLkWgNHIsFTDpMjx as exception:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP(exception)
   return JSUmbaYtRKeVvcBLkWgNHIsFTDpMjy
  return JSUmbaYtRKeVvcBLkWgNHIsFTDpMjC
 def Get_BaseJson_Request(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr={}
  try:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.API_DOMAIN+'/api/lives'
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnG,JSUmbaYtRKeVvcBLkWgNHIsFTDpMnw=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.GetNoCache()
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnu=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.zlib_compress(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.SSTV['uuid']+':'+JSUmbaYtRKeVvcBLkWgNHIsFTDpMjl(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnw))
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnd =JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.makeDefaultCookies()
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMny ={'t':JSUmbaYtRKeVvcBLkWgNHIsFTDpMjl(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnG)}
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnq ={'x-cred-payload':JSUmbaYtRKeVvcBLkWgNHIsFTDpMnu}
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnh=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.callRequestCookies('Get',JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz,payload=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,params=JSUmbaYtRKeVvcBLkWgNHIsFTDpMny,headers=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnq,cookies=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnd)
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr=json.loads(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnh.text)
  except JSUmbaYtRKeVvcBLkWgNHIsFTDpMjx as exception:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP(exception)
  return JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr
 def GetGenreList(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnx=[]
  try:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.Get_BaseJson_Request()
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnP=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr['live']['genrelist']
   for JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC in JSUmbaYtRKeVvcBLkWgNHIsFTDpMnP:
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMnl={'genre':JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('name'),}
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMnx.append(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnl)
  except JSUmbaYtRKeVvcBLkWgNHIsFTDpMjx as exception:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP(exception)
  return JSUmbaYtRKeVvcBLkWgNHIsFTDpMnx
 def GetLiveChannelList(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf,view_genre='-'):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMnx=[]
  try:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.Get_BaseJson_Request()
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnP=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr['live']['channel']
   for JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC in JSUmbaYtRKeVvcBLkWgNHIsFTDpMnP:
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMni=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('genre').get('name')
    if JSUmbaYtRKeVvcBLkWgNHIsFTDpMni!=view_genre and view_genre!='-':continue
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMjn =JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('logo')
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMjf=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('program')[0].get('thumbnail')
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMnl={'chid':JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('id'),'channlnm':JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('name'),'genre':JSUmbaYtRKeVvcBLkWgNHIsFTDpMni,'programnm':JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('program')[0].get('title'),'thumbnail':{'thumb':JSUmbaYtRKeVvcBLkWgNHIsFTDpMjf,'clearlogo':JSUmbaYtRKeVvcBLkWgNHIsFTDpMjn,'icon':JSUmbaYtRKeVvcBLkWgNHIsFTDpMjn,'fanart':JSUmbaYtRKeVvcBLkWgNHIsFTDpMjf},'epg':JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.Make_EpgString(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.Make_EpgList(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('program')))}
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMnx.append(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnl)
  except JSUmbaYtRKeVvcBLkWgNHIsFTDpMjx as exception:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP(exception)
  return JSUmbaYtRKeVvcBLkWgNHIsFTDpMnx
 def Make_EpgList(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf,programList):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMjO=[]
  try:
   for JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC in programList:
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMjX=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('start_time')
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMjo =JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('duration') 
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMjw=datetime.datetime.strptime(JSUmbaYtRKeVvcBLkWgNHIsFTDpMjX,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMjG =JSUmbaYtRKeVvcBLkWgNHIsFTDpMjw+datetime.timedelta(seconds=JSUmbaYtRKeVvcBLkWgNHIsFTDpMjo)
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMnl={'title':JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('title'),'starttm':JSUmbaYtRKeVvcBLkWgNHIsFTDpMjw.strftime('%Y-%m-%d %H:%M'),'endtm':JSUmbaYtRKeVvcBLkWgNHIsFTDpMjG.strftime('%Y-%m-%d %H:%M'),}
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMjO.append(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnl)
  except JSUmbaYtRKeVvcBLkWgNHIsFTDpMjx as exception:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP(exception)
  return JSUmbaYtRKeVvcBLkWgNHIsFTDpMjO
 def Make_EpgString(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf,JSUmbaYtRKeVvcBLkWgNHIsFTDpMjO):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMjA=''
  try:
   for i in JSUmbaYtRKeVvcBLkWgNHIsFTDpMji(JSUmbaYtRKeVvcBLkWgNHIsFTDpMfn(JSUmbaYtRKeVvcBLkWgNHIsFTDpMjO)):
    if i>3:break
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMjE=JSUmbaYtRKeVvcBLkWgNHIsFTDpMjO[i].get('starttm')[-5:]
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMjd =JSUmbaYtRKeVvcBLkWgNHIsFTDpMjO[i].get('endtm')[-5:]
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMjz =JSUmbaYtRKeVvcBLkWgNHIsFTDpMjO[i].get('title')
    JSUmbaYtRKeVvcBLkWgNHIsFTDpMjA+='%s\n[%s ~ %s]\n\n'%(JSUmbaYtRKeVvcBLkWgNHIsFTDpMjz,JSUmbaYtRKeVvcBLkWgNHIsFTDpMjE,JSUmbaYtRKeVvcBLkWgNHIsFTDpMjd)
  except JSUmbaYtRKeVvcBLkWgNHIsFTDpMjx as exception:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP(exception)
  return JSUmbaYtRKeVvcBLkWgNHIsFTDpMjA
 def GetBroadURL(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf,chid):
  JSUmbaYtRKeVvcBLkWgNHIsFTDpMjh=''
  try:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.Get_BaseJson_Request()
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnP=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnr['live']['channel']
   for JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC in JSUmbaYtRKeVvcBLkWgNHIsFTDpMnP:
    if JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('id')==chid:
     JSUmbaYtRKeVvcBLkWgNHIsFTDpMjQ =JSUmbaYtRKeVvcBLkWgNHIsFTDpMnC.get('program')[0].get('stream_url_new')
     JSUmbaYtRKeVvcBLkWgNHIsFTDpMjh=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.zlib_decompress(JSUmbaYtRKeVvcBLkWgNHIsFTDpMjQ)
     break
  except JSUmbaYtRKeVvcBLkWgNHIsFTDpMjx as exception:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP(exception)
  return JSUmbaYtRKeVvcBLkWgNHIsFTDpMjh
 def GetTest(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf,streamurl):
  try:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.zlib_decompress(streamurl)
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz)
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz='https://play-kr.samsungtvplus.com/tvplus/web/v3/play?tid=eVFDcm9hRjhaR1RVNHAva2JJWTR3dm5YWGo3SWlIekpoUENlbmRaaDVCRXROSU9DbWRoT3lKN3JHbGdnU1BSTUlzUHptbFBGS01qWG9hYjdoZElQTXRrZ3ozbXlsUkdIOHoxTGxDcGRsekhnaXJ0Q21qUU1ycWNZdURmWjhidUxyZFpxUjdiODFUZEs1NFFBYm9hWnBPL2gvZXRINWZ0cVJhMFA3RjFZUXU2NVJtZVpZZGl6VjhmUXhCWnVWaEQwZjV2L1hTeUhOblN1akRLR2dsYzVvQzREclhUYzdOc1NzUlZkTVp5UnF6OG5HWERDRjR0dHVDUmxuRVpjbk81eSt1RXhiZkN5aHJUZWRyemdSWWloQURyTnZmRlFwQnVVZTdzay9Ob2ZBekk9'
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnq ={'origin':JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.API_DOMAIN}
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMnh=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnf.callRequestCookies('Get',JSUmbaYtRKeVvcBLkWgNHIsFTDpMnz,payload=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,params=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju,headers=JSUmbaYtRKeVvcBLkWgNHIsFTDpMnq,cookies=JSUmbaYtRKeVvcBLkWgNHIsFTDpMju)
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP(JSUmbaYtRKeVvcBLkWgNHIsFTDpMnh.text)
  except JSUmbaYtRKeVvcBLkWgNHIsFTDpMjx as exception:
   JSUmbaYtRKeVvcBLkWgNHIsFTDpMjP(exception)
  return
# Created by pyminifier (https://github.com/liftoff/pyminifier)
