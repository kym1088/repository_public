__author__="NightRain"
PUDTxQgeHblyKqrCsWLtXmNdMhaIJE=object
PUDTxQgeHblyKqrCsWLtXmNdMhaIJk=None
PUDTxQgeHblyKqrCsWLtXmNdMhaIOj=True
PUDTxQgeHblyKqrCsWLtXmNdMhaIOJ=False
PUDTxQgeHblyKqrCsWLtXmNdMhaIOc=type
PUDTxQgeHblyKqrCsWLtXmNdMhaIOp=dict
PUDTxQgeHblyKqrCsWLtXmNdMhaIOG=open
PUDTxQgeHblyKqrCsWLtXmNdMhaIOw=Exception
PUDTxQgeHblyKqrCsWLtXmNdMhaIOS=int
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
PUDTxQgeHblyKqrCsWLtXmNdMhaIjO=[{'title':'실시간 (전체)','mode':'LIVE_LIST','genre':'-'},{'title':'실시간 (장르별)','mode':'LIVE_GROUP'},]
PUDTxQgeHblyKqrCsWLtXmNdMhaIjc =xbmcvfs.translatePath(os.path.join(__profile__,'samsungtv_cookies.json'))
from samsungtvCore import*
class PUDTxQgeHblyKqrCsWLtXmNdMhaIjJ(PUDTxQgeHblyKqrCsWLtXmNdMhaIJE):
 def __init__(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp,PUDTxQgeHblyKqrCsWLtXmNdMhaIjG,PUDTxQgeHblyKqrCsWLtXmNdMhaIjw,PUDTxQgeHblyKqrCsWLtXmNdMhaIjS):
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjp._addon_url =PUDTxQgeHblyKqrCsWLtXmNdMhaIjG
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjp._addon_handle=PUDTxQgeHblyKqrCsWLtXmNdMhaIjw
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.main_params =PUDTxQgeHblyKqrCsWLtXmNdMhaIjS
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj =JSUmbaYtRKeVvcBLkWgNHIsFTDpMnj() 
 def addon_noti(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp,sting):
  try:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjF=xbmcgui.Dialog()
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjF.notification(__addonname__,sting)
  except:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIJk
 def addon_log(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp,string):
  try:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIji=string.encode('utf-8','ignore')
  except:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIji='addonException: addon_log'
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjY=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,PUDTxQgeHblyKqrCsWLtXmNdMhaIji),level=PUDTxQgeHblyKqrCsWLtXmNdMhaIjY)
 def get_keyboard_input(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp,PUDTxQgeHblyKqrCsWLtXmNdMhaIjV):
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjf=PUDTxQgeHblyKqrCsWLtXmNdMhaIJk
  kb=xbmc.Keyboard()
  kb.setHeading(PUDTxQgeHblyKqrCsWLtXmNdMhaIjV)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjf=kb.getText()
  return PUDTxQgeHblyKqrCsWLtXmNdMhaIjf
 def add_dir(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp,label,sublabel='',img='',infoLabels=PUDTxQgeHblyKqrCsWLtXmNdMhaIJk,isFolder=PUDTxQgeHblyKqrCsWLtXmNdMhaIOj,params='',isLink=PUDTxQgeHblyKqrCsWLtXmNdMhaIOJ,ContextMenu=PUDTxQgeHblyKqrCsWLtXmNdMhaIJk):
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjn='%s?%s'%(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp._addon_url,urllib.parse.urlencode(params))
  if sublabel:PUDTxQgeHblyKqrCsWLtXmNdMhaIjV='%s < %s >'%(label,sublabel)
  else: PUDTxQgeHblyKqrCsWLtXmNdMhaIjV=label
  if not img:img='DefaultFolder.png'
  PUDTxQgeHblyKqrCsWLtXmNdMhaIju=xbmcgui.ListItem(PUDTxQgeHblyKqrCsWLtXmNdMhaIjV)
  if PUDTxQgeHblyKqrCsWLtXmNdMhaIOc(img)==PUDTxQgeHblyKqrCsWLtXmNdMhaIOp:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIju.setArt(img)
  else:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIju.setArt({'thumb':img,'poster':img})
  if infoLabels:PUDTxQgeHblyKqrCsWLtXmNdMhaIju.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIju.setProperty('IsPlayable','true')
  if ContextMenu:PUDTxQgeHblyKqrCsWLtXmNdMhaIju.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp._addon_handle,PUDTxQgeHblyKqrCsWLtXmNdMhaIjn,PUDTxQgeHblyKqrCsWLtXmNdMhaIju,isFolder)
 def dp_Main_List(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp,args):
  for PUDTxQgeHblyKqrCsWLtXmNdMhaIjo in PUDTxQgeHblyKqrCsWLtXmNdMhaIjO:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjV=PUDTxQgeHblyKqrCsWLtXmNdMhaIjo.get('title')
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjz=''
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjA={'mode':PUDTxQgeHblyKqrCsWLtXmNdMhaIjo.get('mode'),'genre':PUDTxQgeHblyKqrCsWLtXmNdMhaIjo.get('genre'),}
   if PUDTxQgeHblyKqrCsWLtXmNdMhaIjo.get('mode')in['XXX']:
    PUDTxQgeHblyKqrCsWLtXmNdMhaIjB=PUDTxQgeHblyKqrCsWLtXmNdMhaIOJ
    PUDTxQgeHblyKqrCsWLtXmNdMhaIjR =PUDTxQgeHblyKqrCsWLtXmNdMhaIOj
   else:
    PUDTxQgeHblyKqrCsWLtXmNdMhaIjB=PUDTxQgeHblyKqrCsWLtXmNdMhaIOj
    PUDTxQgeHblyKqrCsWLtXmNdMhaIjR =PUDTxQgeHblyKqrCsWLtXmNdMhaIOJ
   if 'icon' in PUDTxQgeHblyKqrCsWLtXmNdMhaIjo:PUDTxQgeHblyKqrCsWLtXmNdMhaIjz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',PUDTxQgeHblyKqrCsWLtXmNdMhaIjo.get('icon')) 
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.add_dir(PUDTxQgeHblyKqrCsWLtXmNdMhaIjV,sublabel='',img=PUDTxQgeHblyKqrCsWLtXmNdMhaIjz,infoLabels=PUDTxQgeHblyKqrCsWLtXmNdMhaIJk,isFolder=PUDTxQgeHblyKqrCsWLtXmNdMhaIjB,params=PUDTxQgeHblyKqrCsWLtXmNdMhaIjA,isLink=PUDTxQgeHblyKqrCsWLtXmNdMhaIjR)
  xbmcplugin.endOfDirectory(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp._addon_handle)
 def login_main(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp):
  if not os.path.isdir(xbmcvfs.translatePath(__profile__)):os.mkdir(xbmcvfs.translatePath(__profile__))
  try: 
   fp=PUDTxQgeHblyKqrCsWLtXmNdMhaIOG(PUDTxQgeHblyKqrCsWLtXmNdMhaIjc,'r',-1,'utf-8')
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj.SSTV= json.load(fp)
   fp.close()
  except PUDTxQgeHblyKqrCsWLtXmNdMhaIOw as exception:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj.SSTV['limit_date']='0'
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjk =PUDTxQgeHblyKqrCsWLtXmNdMhaIOS(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJj=PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj.SSTV['limit_date']
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJO =PUDTxQgeHblyKqrCsWLtXmNdMhaIOS(re.sub('-','',PUDTxQgeHblyKqrCsWLtXmNdMhaIJj))
  if PUDTxQgeHblyKqrCsWLtXmNdMhaIjk<=PUDTxQgeHblyKqrCsWLtXmNdMhaIJO:
   return PUDTxQgeHblyKqrCsWLtXmNdMhaIOj
  if PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj.Get_BaseCookies()==PUDTxQgeHblyKqrCsWLtXmNdMhaIOJ:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.addon_noti('init error!')
   return PUDTxQgeHblyKqrCsWLtXmNdMhaIOJ
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJc =PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj.Get_Now_Datetime()
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJp=PUDTxQgeHblyKqrCsWLtXmNdMhaIJc+datetime.timedelta(days=PUDTxQgeHblyKqrCsWLtXmNdMhaIOS(__addon__.getSetting('cache_ttl')))
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj.SSTV['limit_date']=PUDTxQgeHblyKqrCsWLtXmNdMhaIJp.strftime('%Y-%m-%d')
  try: 
   fp=PUDTxQgeHblyKqrCsWLtXmNdMhaIOG(PUDTxQgeHblyKqrCsWLtXmNdMhaIjc,'w',-1,'utf-8')
   json.dump(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj.SSTV,fp,indent=4,ensure_ascii=PUDTxQgeHblyKqrCsWLtXmNdMhaIOJ)
   fp.close()
  except PUDTxQgeHblyKqrCsWLtXmNdMhaIOw as exception:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.addon_noti('file save error!')
   return PUDTxQgeHblyKqrCsWLtXmNdMhaIOJ
  return PUDTxQgeHblyKqrCsWLtXmNdMhaIOj
 def dp_LiveChannel_List(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp,args):
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJw=args.get('genre')
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJS=PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj.GetLiveChannelList(view_genre=PUDTxQgeHblyKqrCsWLtXmNdMhaIJw)
  for PUDTxQgeHblyKqrCsWLtXmNdMhaIJv in PUDTxQgeHblyKqrCsWLtXmNdMhaIJS:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIJF =PUDTxQgeHblyKqrCsWLtXmNdMhaIJv.get('chid')
   PUDTxQgeHblyKqrCsWLtXmNdMhaIJi =PUDTxQgeHblyKqrCsWLtXmNdMhaIJv.get('channlnm')
   PUDTxQgeHblyKqrCsWLtXmNdMhaIJY =PUDTxQgeHblyKqrCsWLtXmNdMhaIJv.get('genre')
   PUDTxQgeHblyKqrCsWLtXmNdMhaIJf =PUDTxQgeHblyKqrCsWLtXmNdMhaIJv.get('programnm')
   PUDTxQgeHblyKqrCsWLtXmNdMhaIJn =PUDTxQgeHblyKqrCsWLtXmNdMhaIJv.get('thumbnail')
   PUDTxQgeHblyKqrCsWLtXmNdMhaIJV =PUDTxQgeHblyKqrCsWLtXmNdMhaIJv.get('epg')
   PUDTxQgeHblyKqrCsWLtXmNdMhaIJu={'mediatype':'episode','title':PUDTxQgeHblyKqrCsWLtXmNdMhaIJf,'studio':PUDTxQgeHblyKqrCsWLtXmNdMhaIJi,'genre':PUDTxQgeHblyKqrCsWLtXmNdMhaIJY,'plot':'%s\n\n%s'%(PUDTxQgeHblyKqrCsWLtXmNdMhaIJi,PUDTxQgeHblyKqrCsWLtXmNdMhaIJV),}
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjA={'mode':'LIVE','chid':PUDTxQgeHblyKqrCsWLtXmNdMhaIJF,}
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.add_dir(PUDTxQgeHblyKqrCsWLtXmNdMhaIJi,sublabel=PUDTxQgeHblyKqrCsWLtXmNdMhaIJf,img=PUDTxQgeHblyKqrCsWLtXmNdMhaIJn,infoLabels=PUDTxQgeHblyKqrCsWLtXmNdMhaIJu,isFolder=PUDTxQgeHblyKqrCsWLtXmNdMhaIOJ,params=PUDTxQgeHblyKqrCsWLtXmNdMhaIjA)
  xbmcplugin.endOfDirectory(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp._addon_handle,cacheToDisc=PUDTxQgeHblyKqrCsWLtXmNdMhaIOj)
 def dp_LiveGroup_List(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp,args):
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJS=PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj.GetGenreList()
  for PUDTxQgeHblyKqrCsWLtXmNdMhaIJv in PUDTxQgeHblyKqrCsWLtXmNdMhaIJS:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIJw =PUDTxQgeHblyKqrCsWLtXmNdMhaIJv.get('genre')
   PUDTxQgeHblyKqrCsWLtXmNdMhaIJu={'plot':PUDTxQgeHblyKqrCsWLtXmNdMhaIJw}
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjA={'mode':'LIVE_LIST','genre':PUDTxQgeHblyKqrCsWLtXmNdMhaIJw,}
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.add_dir(PUDTxQgeHblyKqrCsWLtXmNdMhaIJw,sublabel='',img='',infoLabels=PUDTxQgeHblyKqrCsWLtXmNdMhaIJu,isFolder=PUDTxQgeHblyKqrCsWLtXmNdMhaIOj,params=PUDTxQgeHblyKqrCsWLtXmNdMhaIjA)
  xbmcplugin.endOfDirectory(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp._addon_handle,cacheToDisc=PUDTxQgeHblyKqrCsWLtXmNdMhaIOj)
 def play_VIDEO(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp,args):
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJF =args.get('chid')
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJz=PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.SamsungtvObj.GetBroadURL(PUDTxQgeHblyKqrCsWLtXmNdMhaIJF)
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.addon_log('%s - url : %s'%(PUDTxQgeHblyKqrCsWLtXmNdMhaIJF,PUDTxQgeHblyKqrCsWLtXmNdMhaIJz))
  if PUDTxQgeHblyKqrCsWLtXmNdMhaIJz=='':
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.addon_noti(__language__(30906).encode('utf8'))
   return
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJz+='|origin=https://www.samsungtvplus.com'
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJA=xbmcgui.ListItem(path=PUDTxQgeHblyKqrCsWLtXmNdMhaIJz)
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJA.setContentLookup(PUDTxQgeHblyKqrCsWLtXmNdMhaIOJ)
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJA.setMimeType('application/x-mpegURL')
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJA.setProperty('inputstream','inputstream.adaptive')
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJA.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp._addon_handle,PUDTxQgeHblyKqrCsWLtXmNdMhaIOj,PUDTxQgeHblyKqrCsWLtXmNdMhaIJA)
 def STV_logout(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp):
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjF=xbmcgui.Dialog()
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJB=PUDTxQgeHblyKqrCsWLtXmNdMhaIjF.yesno(__language__(30905).encode('utf8'),__language__(30907).encode('utf8'))
  if PUDTxQgeHblyKqrCsWLtXmNdMhaIJB==PUDTxQgeHblyKqrCsWLtXmNdMhaIOJ:return 
  if os.path.isfile(PUDTxQgeHblyKqrCsWLtXmNdMhaIjc):os.remove(PUDTxQgeHblyKqrCsWLtXmNdMhaIjc)
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.addon_noti(__language__(30904).encode('utf-8'))
 def dp_Test(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp,args):
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.addon_noti('test')
 def samsungtv_main(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp):
  PUDTxQgeHblyKqrCsWLtXmNdMhaIJR=PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.main_params.get('mode',PUDTxQgeHblyKqrCsWLtXmNdMhaIJk)
  if PUDTxQgeHblyKqrCsWLtXmNdMhaIJR=='LOGOUT':
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.STV_logout()
   return
  PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.login_main()
  if PUDTxQgeHblyKqrCsWLtXmNdMhaIJR is PUDTxQgeHblyKqrCsWLtXmNdMhaIJk:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.dp_Main_List(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.main_params)
  elif PUDTxQgeHblyKqrCsWLtXmNdMhaIJR=='LIVE_LIST':
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.dp_LiveChannel_List(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.main_params)
  elif PUDTxQgeHblyKqrCsWLtXmNdMhaIJR=='LIVE':
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.play_VIDEO(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.main_params)
  elif PUDTxQgeHblyKqrCsWLtXmNdMhaIJR=='LIVE_GROUP':
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.dp_LiveGroup_List(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.main_params)
  elif PUDTxQgeHblyKqrCsWLtXmNdMhaIJR=='CAPTCHA_TEST':
   PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.dp_Test(PUDTxQgeHblyKqrCsWLtXmNdMhaIjp.main_params)
  else:
   PUDTxQgeHblyKqrCsWLtXmNdMhaIJk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
