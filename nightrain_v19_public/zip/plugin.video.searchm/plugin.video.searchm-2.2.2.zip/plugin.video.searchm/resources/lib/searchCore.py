__author__="NightRain"
BDMYnUAqOoepfFrgjyWkSwElubmhLN=object
BDMYnUAqOoepfFrgjyWkSwElubmhLX=None
BDMYnUAqOoepfFrgjyWkSwElubmhLi=True
BDMYnUAqOoepfFrgjyWkSwElubmhLT=print
BDMYnUAqOoepfFrgjyWkSwElubmhVz=str
BDMYnUAqOoepfFrgjyWkSwElubmhVx=int
BDMYnUAqOoepfFrgjyWkSwElubmhVQ=False
BDMYnUAqOoepfFrgjyWkSwElubmhVC=dict
BDMYnUAqOoepfFrgjyWkSwElubmhVL=Exception
BDMYnUAqOoepfFrgjyWkSwElubmhVG=len
BDMYnUAqOoepfFrgjyWkSwElubmhVs=open
BDMYnUAqOoepfFrgjyWkSwElubmhVt=type
BDMYnUAqOoepfFrgjyWkSwElubmhVP=list
BDMYnUAqOoepfFrgjyWkSwElubmhVv=isinstance
BDMYnUAqOoepfFrgjyWkSwElubmhVd=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
import http.cookiejar
class BDMYnUAqOoepfFrgjyWkSwElubmhzx(BDMYnUAqOoepfFrgjyWkSwElubmhLN):
 def __init__(BDMYnUAqOoepfFrgjyWkSwElubmhzQ):
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_WAVVE ='https://apis.wavve.com'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_TVING_SEARCH='https://search-api.tving.com'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_TVING_IMG ='https://image.tving.com'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_WATCHA ='https://api-mars.watcha.com'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_NETFLIX ='https://www.netflix.com'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_COUPANG ='https://discover.coupangstreaming.com'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_PRIMEV ='https://www.primevideo.com'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.WAVVE_LIMIT =20 
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_LIMIT =30
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.WATCHA_LIMIT =30
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_LIMIT =20 
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.COUPANG_LIMIT =10 
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DISNEY_LIMIT =10 
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DERECTOR_LIMIT =4
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.CAST_LIMIT =10
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.GENRE_LIMIT =4
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_MOVIE_LITE=['2610061','2610161','261062']
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100','APIKEY':'1e7952d0917d6aab1f0293a063697610','TELECODE':'CSCD0900',}
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_HEADER={'user-agent':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND1 ='_342x192'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND2 ='_665x375'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_PORT ='_342x684'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LOGO ='_550x124'
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF={}
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']={}
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']={}
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ={}
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.PV={}
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.HTTP_CLIENT=requests.Session()
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.CP_ORIGINAL_COOKIE =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.PV_ORIGINAL_COOKIE =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ_ORIGINAL_COOKIE =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_ORIGINAL_COOKIE =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_SESSION_COOKIES1 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_SESSION_COOKIES2 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_SESSION_COOKIES3 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_SESSION_COOKIES4 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_SESSION_FULLTEXT1 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_SESSION_FULLTEXT2 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_SESSION_FULLTEXT3 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_SESSION_FULLTEXT4 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_CONTEXTJSON_FILE1 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_CONTEXTJSON_FILE2 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_CONTEXTJSON_FILE3 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_CONTEXTJSON_FILE4 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_FALCORJSON_FILE1 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_FALCORJSON_FILE2 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_FALCORJSON_FILE3 =''
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_FALCORJSON_FILE4 =''
 '''
 def callRequestCookies(self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):
  #setHeader = {'user-agent' : self.USER_AGENT }
  setHeader = self.DEFAULT_HEADER
  if headers: setHeader.update(headers )
  if jobtype == 'Get': # Get/Post
   res = requests.get(url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  else:
   res = requests.post(url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  return res
 ''' 
 def Call_Request(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,BDMYnUAqOoepfFrgjyWkSwElubmhzP,payload=BDMYnUAqOoepfFrgjyWkSwElubmhLX,json=BDMYnUAqOoepfFrgjyWkSwElubmhLX,params=BDMYnUAqOoepfFrgjyWkSwElubmhLX,headers=BDMYnUAqOoepfFrgjyWkSwElubmhLX,cookies=BDMYnUAqOoepfFrgjyWkSwElubmhLX,redirects=BDMYnUAqOoepfFrgjyWkSwElubmhLi,method='-'):
  BDMYnUAqOoepfFrgjyWkSwElubmhzC={'user-agent':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.USER_AGENT}
  if headers:BDMYnUAqOoepfFrgjyWkSwElubmhzC.update(headers)
  if payload!=BDMYnUAqOoepfFrgjyWkSwElubmhLX or method=='POST':
   BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.HTTP_CLIENT.post(url=BDMYnUAqOoepfFrgjyWkSwElubmhzP,data=payload,json=json,params=params,headers=BDMYnUAqOoepfFrgjyWkSwElubmhzC,cookies=cookies,allow_redirects=redirects)
  else:
   BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.HTTP_CLIENT.get(url=BDMYnUAqOoepfFrgjyWkSwElubmhzP,params=params,headers=BDMYnUAqOoepfFrgjyWkSwElubmhzC,cookies=cookies,allow_redirects=redirects)
  BDMYnUAqOoepfFrgjyWkSwElubmhLT(BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhzL.status_code)+' - '+BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhzL.url))
  return BDMYnUAqOoepfFrgjyWkSwElubmhzL
 def GetNoCache(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,timetype=1,minutes=0):
  if timetype==1:
   ts=BDMYnUAqOoepfFrgjyWkSwElubmhVx(time.time())
   mi=BDMYnUAqOoepfFrgjyWkSwElubmhVx(minutes*60)
  else:
   ts=BDMYnUAqOoepfFrgjyWkSwElubmhVx(time.time()*1000)
   mi=BDMYnUAqOoepfFrgjyWkSwElubmhVx(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(BDMYnUAqOoepfFrgjyWkSwElubmhzQ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,search_key,sType,page_int):
  BDMYnUAqOoepfFrgjyWkSwElubmhzG=[]
  BDMYnUAqOoepfFrgjyWkSwElubmhzs=BDMYnUAqOoepfFrgjyWkSwElubmhxQ=1
  BDMYnUAqOoepfFrgjyWkSwElubmhzt=BDMYnUAqOoepfFrgjyWkSwElubmhVQ
  try:
   BDMYnUAqOoepfFrgjyWkSwElubmhzP=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_WAVVE+'/fz/search/band.js'
   BDMYnUAqOoepfFrgjyWkSwElubmhzv={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':BDMYnUAqOoepfFrgjyWkSwElubmhVz((page_int-1)*BDMYnUAqOoepfFrgjyWkSwElubmhzQ.WAVVE_LIMIT),'limit':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.WAVVE_LIMIT,'orderby':'score','mtype':'svod',}
   BDMYnUAqOoepfFrgjyWkSwElubmhzv.update(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.WAVVE_PARAMS)
   BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.Call_Request(BDMYnUAqOoepfFrgjyWkSwElubmhzP,payload=BDMYnUAqOoepfFrgjyWkSwElubmhLX,params=BDMYnUAqOoepfFrgjyWkSwElubmhzv,headers=BDMYnUAqOoepfFrgjyWkSwElubmhLX,cookies=BDMYnUAqOoepfFrgjyWkSwElubmhLX,method='GET')
   BDMYnUAqOoepfFrgjyWkSwElubmhzd=json.loads(BDMYnUAqOoepfFrgjyWkSwElubmhzL.text)
   if not('celllist' in BDMYnUAqOoepfFrgjyWkSwElubmhzd['band']):return BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt
   BDMYnUAqOoepfFrgjyWkSwElubmhzK=BDMYnUAqOoepfFrgjyWkSwElubmhzd['band']['celllist']
   for BDMYnUAqOoepfFrgjyWkSwElubmhzR in BDMYnUAqOoepfFrgjyWkSwElubmhzK:
    BDMYnUAqOoepfFrgjyWkSwElubmhzc =BDMYnUAqOoepfFrgjyWkSwElubmhzR['event_list'][1]['url']
    BDMYnUAqOoepfFrgjyWkSwElubmhzI=urllib.parse.urlsplit(BDMYnUAqOoepfFrgjyWkSwElubmhzc).query
    BDMYnUAqOoepfFrgjyWkSwElubmhzH=BDMYnUAqOoepfFrgjyWkSwElubmhzI[0:BDMYnUAqOoepfFrgjyWkSwElubmhzI.find('=')]
    BDMYnUAqOoepfFrgjyWkSwElubmhza=BDMYnUAqOoepfFrgjyWkSwElubmhVC(urllib.parse.parse_qsl(BDMYnUAqOoepfFrgjyWkSwElubmhzI))
    BDMYnUAqOoepfFrgjyWkSwElubmhzJ=BDMYnUAqOoepfFrgjyWkSwElubmhza.get(BDMYnUAqOoepfFrgjyWkSwElubmhzH)
    BDMYnUAqOoepfFrgjyWkSwElubmhzH='TVSHOW' if BDMYnUAqOoepfFrgjyWkSwElubmhzH=='programid' else 'MOVIE' 
    BDMYnUAqOoepfFrgjyWkSwElubmhzN=BDMYnUAqOoepfFrgjyWkSwElubmhzR['title_list'][0]['text']
    BDMYnUAqOoepfFrgjyWkSwElubmhzX =BDMYnUAqOoepfFrgjyWkSwElubmhzR['age']
    BDMYnUAqOoepfFrgjyWkSwElubmhzi={'title':BDMYnUAqOoepfFrgjyWkSwElubmhzN}
    BDMYnUAqOoepfFrgjyWkSwElubmhzT=BDMYnUAqOoepfFrgjyWkSwElubmhVQ
    for BDMYnUAqOoepfFrgjyWkSwElubmhxz in BDMYnUAqOoepfFrgjyWkSwElubmhzR['bottom_taglist']:
     if BDMYnUAqOoepfFrgjyWkSwElubmhxz=='won':
      BDMYnUAqOoepfFrgjyWkSwElubmhzT=BDMYnUAqOoepfFrgjyWkSwElubmhLi
      break
    if BDMYnUAqOoepfFrgjyWkSwElubmhzT==BDMYnUAqOoepfFrgjyWkSwElubmhLi: 
     BDMYnUAqOoepfFrgjyWkSwElubmhzi['title']=BDMYnUAqOoepfFrgjyWkSwElubmhzi['title']+' [개별구매]'
    if BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('age')!='21':
     BDMYnUAqOoepfFrgjyWkSwElubmhzG.append(BDMYnUAqOoepfFrgjyWkSwElubmhzi)
   BDMYnUAqOoepfFrgjyWkSwElubmhzs=BDMYnUAqOoepfFrgjyWkSwElubmhVx(BDMYnUAqOoepfFrgjyWkSwElubmhzd['band']['pagecount'])
   if BDMYnUAqOoepfFrgjyWkSwElubmhzd['band']['count']:BDMYnUAqOoepfFrgjyWkSwElubmhxQ =BDMYnUAqOoepfFrgjyWkSwElubmhVx(BDMYnUAqOoepfFrgjyWkSwElubmhzd['band']['count'])
   else:BDMYnUAqOoepfFrgjyWkSwElubmhxQ=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.LIST_LIMIT
   BDMYnUAqOoepfFrgjyWkSwElubmhzt=BDMYnUAqOoepfFrgjyWkSwElubmhzs>BDMYnUAqOoepfFrgjyWkSwElubmhxQ
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception)
  return BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt 
 def Get_Search_Tving(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,search_key,sType,page_int):
  BDMYnUAqOoepfFrgjyWkSwElubmhzG=[]
  BDMYnUAqOoepfFrgjyWkSwElubmhzt=BDMYnUAqOoepfFrgjyWkSwElubmhVQ
  try:
   BDMYnUAqOoepfFrgjyWkSwElubmhxC ='/search/getSearch.jsp'
   BDMYnUAqOoepfFrgjyWkSwElubmhxL={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':BDMYnUAqOoepfFrgjyWkSwElubmhVz(page_int),'pageSize':BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_PARMAS.get('SCREENCODE'),'os':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_PARMAS.get('OSCODE'),'network':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_LIMIT)if sType=='TVSHOW' else '0','vodMVReqCnt':BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_LIMIT)if sType=='MOVIE' else '0','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_PARMAS.get('APIKEY'),'networkCode':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_PARMAS.get('NETWORKCODE'),'osCode ':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_PARMAS.get('OSCODE'),'teleCode ':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_PARMAS.get('TELECODE'),'screenCode ':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_PARMAS.get('SCREENCODE')}
   BDMYnUAqOoepfFrgjyWkSwElubmhzP=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_TVING_SEARCH+BDMYnUAqOoepfFrgjyWkSwElubmhxC
   BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.Call_Request(BDMYnUAqOoepfFrgjyWkSwElubmhzP,payload=BDMYnUAqOoepfFrgjyWkSwElubmhLX,params=BDMYnUAqOoepfFrgjyWkSwElubmhxL,headers=BDMYnUAqOoepfFrgjyWkSwElubmhLX,cookies=BDMYnUAqOoepfFrgjyWkSwElubmhLX,method='GET')
   BDMYnUAqOoepfFrgjyWkSwElubmhxV=json.loads(BDMYnUAqOoepfFrgjyWkSwElubmhzL.text)
   if sType=='TVSHOW':
    if not('programRsb' in BDMYnUAqOoepfFrgjyWkSwElubmhxV):return BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt
    BDMYnUAqOoepfFrgjyWkSwElubmhxG=BDMYnUAqOoepfFrgjyWkSwElubmhxV['programRsb']['dataList']
    BDMYnUAqOoepfFrgjyWkSwElubmhxs =BDMYnUAqOoepfFrgjyWkSwElubmhVx(BDMYnUAqOoepfFrgjyWkSwElubmhxV['programRsb']['count'])
    for BDMYnUAqOoepfFrgjyWkSwElubmhzR in BDMYnUAqOoepfFrgjyWkSwElubmhxG:
     BDMYnUAqOoepfFrgjyWkSwElubmhxt=BDMYnUAqOoepfFrgjyWkSwElubmhzR['mast_cd']
     BDMYnUAqOoepfFrgjyWkSwElubmhzN =BDMYnUAqOoepfFrgjyWkSwElubmhzR['mast_nm']
     BDMYnUAqOoepfFrgjyWkSwElubmhxP=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_TVING_IMG+BDMYnUAqOoepfFrgjyWkSwElubmhzR['web_url4']
     BDMYnUAqOoepfFrgjyWkSwElubmhxv =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_TVING_IMG+BDMYnUAqOoepfFrgjyWkSwElubmhzR['web_url']
     try:
      BDMYnUAqOoepfFrgjyWkSwElubmhxd =[]
      BDMYnUAqOoepfFrgjyWkSwElubmhxK=[]
      BDMYnUAqOoepfFrgjyWkSwElubmhxR =[]
      BDMYnUAqOoepfFrgjyWkSwElubmhxc =0
      BDMYnUAqOoepfFrgjyWkSwElubmhxI =''
      BDMYnUAqOoepfFrgjyWkSwElubmhxH =''
      BDMYnUAqOoepfFrgjyWkSwElubmhxa =''
      if BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('actor') !='' and BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('actor') !='-':BDMYnUAqOoepfFrgjyWkSwElubmhxd =BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('actor').split(',')
      if BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('director')!='' and BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('director')!='-':BDMYnUAqOoepfFrgjyWkSwElubmhxK=BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('director').split(',')
      if BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('cate_nm')!='' and BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('cate_nm')!='-':BDMYnUAqOoepfFrgjyWkSwElubmhxR =BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('cate_nm').split('/')
      if 'targetage' in BDMYnUAqOoepfFrgjyWkSwElubmhzR:BDMYnUAqOoepfFrgjyWkSwElubmhxI=BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('targetage')
      if 'broad_dt' in BDMYnUAqOoepfFrgjyWkSwElubmhzR:
       BDMYnUAqOoepfFrgjyWkSwElubmhxJ=BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('broad_dt')
       BDMYnUAqOoepfFrgjyWkSwElubmhxa='%s-%s-%s'%(BDMYnUAqOoepfFrgjyWkSwElubmhxJ[:4],BDMYnUAqOoepfFrgjyWkSwElubmhxJ[4:6],BDMYnUAqOoepfFrgjyWkSwElubmhxJ[6:])
       BDMYnUAqOoepfFrgjyWkSwElubmhxH =BDMYnUAqOoepfFrgjyWkSwElubmhxJ[:4]
     except:
      BDMYnUAqOoepfFrgjyWkSwElubmhLX
     BDMYnUAqOoepfFrgjyWkSwElubmhzi={'title':BDMYnUAqOoepfFrgjyWkSwElubmhzN,}
     BDMYnUAqOoepfFrgjyWkSwElubmhzG.append(BDMYnUAqOoepfFrgjyWkSwElubmhzi)
   else:
    if not('vodMVRsb' in BDMYnUAqOoepfFrgjyWkSwElubmhxV):return BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt
    BDMYnUAqOoepfFrgjyWkSwElubmhxN=BDMYnUAqOoepfFrgjyWkSwElubmhxV['vodMVRsb']['dataList']
    BDMYnUAqOoepfFrgjyWkSwElubmhxs =BDMYnUAqOoepfFrgjyWkSwElubmhVx(BDMYnUAqOoepfFrgjyWkSwElubmhxV['vodMVRsb']['count'])
    BDMYnUAqOoepfFrgjyWkSwElubmhLT(BDMYnUAqOoepfFrgjyWkSwElubmhxs)
    for BDMYnUAqOoepfFrgjyWkSwElubmhzR in BDMYnUAqOoepfFrgjyWkSwElubmhxN:
     BDMYnUAqOoepfFrgjyWkSwElubmhxt=BDMYnUAqOoepfFrgjyWkSwElubmhzR['mast_cd']
     BDMYnUAqOoepfFrgjyWkSwElubmhzN =BDMYnUAqOoepfFrgjyWkSwElubmhzR['mast_nm'].strip()
     BDMYnUAqOoepfFrgjyWkSwElubmhxP =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_TVING_IMG+BDMYnUAqOoepfFrgjyWkSwElubmhzR['web_url']
     BDMYnUAqOoepfFrgjyWkSwElubmhxv =BDMYnUAqOoepfFrgjyWkSwElubmhxP
     BDMYnUAqOoepfFrgjyWkSwElubmhxX=''
     try:
      BDMYnUAqOoepfFrgjyWkSwElubmhxd =[]
      BDMYnUAqOoepfFrgjyWkSwElubmhxK=[]
      BDMYnUAqOoepfFrgjyWkSwElubmhxR =[]
      BDMYnUAqOoepfFrgjyWkSwElubmhxc =0
      BDMYnUAqOoepfFrgjyWkSwElubmhxI =''
      BDMYnUAqOoepfFrgjyWkSwElubmhxH =''
      BDMYnUAqOoepfFrgjyWkSwElubmhxa =''
      if BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('actor') !='' and BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('actor') !='-':BDMYnUAqOoepfFrgjyWkSwElubmhxd =BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('actor').split(',')
      if BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('director')!='' and BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('director')!='-':BDMYnUAqOoepfFrgjyWkSwElubmhxK=BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('director').split(',')
      if BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('cate_nm')!='' and BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('cate_nm')!='-':BDMYnUAqOoepfFrgjyWkSwElubmhxR =BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('cate_nm').split('/')
      if BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('runtime_sec')!='':BDMYnUAqOoepfFrgjyWkSwElubmhxc=BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('runtime_sec')
      if 'grade_nm' in BDMYnUAqOoepfFrgjyWkSwElubmhzR:BDMYnUAqOoepfFrgjyWkSwElubmhxI=BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('grade_nm')
      BDMYnUAqOoepfFrgjyWkSwElubmhxi=''
      BDMYnUAqOoepfFrgjyWkSwElubmhxJ=BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('broad_dt')
      if BDMYnUAqOoepfFrgjyWkSwElubmhxi!='':
       BDMYnUAqOoepfFrgjyWkSwElubmhxa='%s-%s-%s'%(BDMYnUAqOoepfFrgjyWkSwElubmhxJ[:4],BDMYnUAqOoepfFrgjyWkSwElubmhxJ[4:6],BDMYnUAqOoepfFrgjyWkSwElubmhxJ[6:])
       BDMYnUAqOoepfFrgjyWkSwElubmhxH =BDMYnUAqOoepfFrgjyWkSwElubmhxJ[:4]
     except:
      BDMYnUAqOoepfFrgjyWkSwElubmhLX
     BDMYnUAqOoepfFrgjyWkSwElubmhzi={'title':BDMYnUAqOoepfFrgjyWkSwElubmhzN,}
     BDMYnUAqOoepfFrgjyWkSwElubmhxT=BDMYnUAqOoepfFrgjyWkSwElubmhVQ
     for BDMYnUAqOoepfFrgjyWkSwElubmhxz in BDMYnUAqOoepfFrgjyWkSwElubmhzR['bill']:
      if BDMYnUAqOoepfFrgjyWkSwElubmhxz in BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_MOVIE_LITE:
       BDMYnUAqOoepfFrgjyWkSwElubmhxT=BDMYnUAqOoepfFrgjyWkSwElubmhLi
       break
     if BDMYnUAqOoepfFrgjyWkSwElubmhxT==BDMYnUAqOoepfFrgjyWkSwElubmhVQ: 
      BDMYnUAqOoepfFrgjyWkSwElubmhzi['title']=BDMYnUAqOoepfFrgjyWkSwElubmhzi['title']+' [개별구매]'
     BDMYnUAqOoepfFrgjyWkSwElubmhzG.append(BDMYnUAqOoepfFrgjyWkSwElubmhzi)
   if BDMYnUAqOoepfFrgjyWkSwElubmhxs>(page_int*BDMYnUAqOoepfFrgjyWkSwElubmhzQ.TVING_LIMIT):BDMYnUAqOoepfFrgjyWkSwElubmhzt=BDMYnUAqOoepfFrgjyWkSwElubmhLi
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception)
  return BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt
 def Get_Search_Watcha(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,search_key,page_int):
  BDMYnUAqOoepfFrgjyWkSwElubmhzG=[]
  BDMYnUAqOoepfFrgjyWkSwElubmhzt=BDMYnUAqOoepfFrgjyWkSwElubmhVQ
  try:
   BDMYnUAqOoepfFrgjyWkSwElubmhzP=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_WATCHA+'/api/search.json'
   BDMYnUAqOoepfFrgjyWkSwElubmhxL={'query':search_key,'page':BDMYnUAqOoepfFrgjyWkSwElubmhVz(page_int),'per':BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.WATCHA_LIMIT),'exclude':'limited',}
   BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.Call_Request(BDMYnUAqOoepfFrgjyWkSwElubmhzP,payload=BDMYnUAqOoepfFrgjyWkSwElubmhLX,params=BDMYnUAqOoepfFrgjyWkSwElubmhxL,headers=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.WATCHA_HEADER,cookies=BDMYnUAqOoepfFrgjyWkSwElubmhLX,method='GET')
   BDMYnUAqOoepfFrgjyWkSwElubmhxV=json.loads(BDMYnUAqOoepfFrgjyWkSwElubmhzL.text)
   if not('results' in BDMYnUAqOoepfFrgjyWkSwElubmhxV):return BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt
   BDMYnUAqOoepfFrgjyWkSwElubmhQz=BDMYnUAqOoepfFrgjyWkSwElubmhxV['results']
   BDMYnUAqOoepfFrgjyWkSwElubmhzt=BDMYnUAqOoepfFrgjyWkSwElubmhxV['meta']['has_next']
   for BDMYnUAqOoepfFrgjyWkSwElubmhzR in BDMYnUAqOoepfFrgjyWkSwElubmhQz:
    BDMYnUAqOoepfFrgjyWkSwElubmhQx =BDMYnUAqOoepfFrgjyWkSwElubmhzR['code']
    BDMYnUAqOoepfFrgjyWkSwElubmhQC=BDMYnUAqOoepfFrgjyWkSwElubmhzR['content_type']
    BDMYnUAqOoepfFrgjyWkSwElubmhQL =BDMYnUAqOoepfFrgjyWkSwElubmhzR['title']
    BDMYnUAqOoepfFrgjyWkSwElubmhQV =BDMYnUAqOoepfFrgjyWkSwElubmhzR['story']
    BDMYnUAqOoepfFrgjyWkSwElubmhxP=BDMYnUAqOoepfFrgjyWkSwElubmhxv=BDMYnUAqOoepfFrgjyWkSwElubmhLK=''
    if BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('poster') !=BDMYnUAqOoepfFrgjyWkSwElubmhLX:BDMYnUAqOoepfFrgjyWkSwElubmhxP=BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('poster').get('original')
    if BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('stillcut')!=BDMYnUAqOoepfFrgjyWkSwElubmhLX:BDMYnUAqOoepfFrgjyWkSwElubmhxv =BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('stillcut').get('large')
    if BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('thumbnail')!=BDMYnUAqOoepfFrgjyWkSwElubmhLX:BDMYnUAqOoepfFrgjyWkSwElubmhLK=BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('thumbnail').get('large')
    if BDMYnUAqOoepfFrgjyWkSwElubmhLK=='' :BDMYnUAqOoepfFrgjyWkSwElubmhLK=BDMYnUAqOoepfFrgjyWkSwElubmhxv
    BDMYnUAqOoepfFrgjyWkSwElubmhQG={'thumb':BDMYnUAqOoepfFrgjyWkSwElubmhxv,'poster':BDMYnUAqOoepfFrgjyWkSwElubmhxP,'fanart':BDMYnUAqOoepfFrgjyWkSwElubmhLK}
    BDMYnUAqOoepfFrgjyWkSwElubmhxH =BDMYnUAqOoepfFrgjyWkSwElubmhzR['year']
    BDMYnUAqOoepfFrgjyWkSwElubmhQs =BDMYnUAqOoepfFrgjyWkSwElubmhzR['film_rating_code']
    BDMYnUAqOoepfFrgjyWkSwElubmhQt=BDMYnUAqOoepfFrgjyWkSwElubmhzR['film_rating_short']
    BDMYnUAqOoepfFrgjyWkSwElubmhQP =BDMYnUAqOoepfFrgjyWkSwElubmhzR['film_rating_long']
    if BDMYnUAqOoepfFrgjyWkSwElubmhQC=='movies':
     BDMYnUAqOoepfFrgjyWkSwElubmhxc =BDMYnUAqOoepfFrgjyWkSwElubmhzR['duration']
    else:
     BDMYnUAqOoepfFrgjyWkSwElubmhxc ='0'
    BDMYnUAqOoepfFrgjyWkSwElubmhzi={'title':BDMYnUAqOoepfFrgjyWkSwElubmhQL,}
    BDMYnUAqOoepfFrgjyWkSwElubmhzG.append(BDMYnUAqOoepfFrgjyWkSwElubmhzi)
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception)
  return BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt
 def Get_Search_Coupang(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,search_key,page_int):
  BDMYnUAqOoepfFrgjyWkSwElubmhzG=[]
  BDMYnUAqOoepfFrgjyWkSwElubmhzt=BDMYnUAqOoepfFrgjyWkSwElubmhVQ
  try:
   CP=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.jsonfile_To_dic(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.CP_ORIGINAL_COOKIE)
   BDMYnUAqOoepfFrgjyWkSwElubmhzP=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_COUPANG+'/v2/search' 
   BDMYnUAqOoepfFrgjyWkSwElubmhxL={'query':search_key,'platform':'WEBCLIENT','page':BDMYnUAqOoepfFrgjyWkSwElubmhVz(page_int),'perPage':BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.COUPANG_LIMIT),}
   BDMYnUAqOoepfFrgjyWkSwElubmhQv={'x-membersrl':CP['SESSION']['member_srl'],'x-pcid':CP['SESSION']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.Call_Request(BDMYnUAqOoepfFrgjyWkSwElubmhzP,payload=BDMYnUAqOoepfFrgjyWkSwElubmhLX,params=BDMYnUAqOoepfFrgjyWkSwElubmhxL,headers=BDMYnUAqOoepfFrgjyWkSwElubmhQv,cookies=BDMYnUAqOoepfFrgjyWkSwElubmhLX,method='GET')
   BDMYnUAqOoepfFrgjyWkSwElubmhzd=json.loads(BDMYnUAqOoepfFrgjyWkSwElubmhzL.text)
   if BDMYnUAqOoepfFrgjyWkSwElubmhVG(BDMYnUAqOoepfFrgjyWkSwElubmhzd.get('data').get('data'))==0:return BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt
   for BDMYnUAqOoepfFrgjyWkSwElubmhzR in BDMYnUAqOoepfFrgjyWkSwElubmhzd.get('data').get('data'):
    BDMYnUAqOoepfFrgjyWkSwElubmhzR=BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('data')
    BDMYnUAqOoepfFrgjyWkSwElubmhzi={'title':BDMYnUAqOoepfFrgjyWkSwElubmhzR.get('title'),}
    BDMYnUAqOoepfFrgjyWkSwElubmhzG.append(BDMYnUAqOoepfFrgjyWkSwElubmhzi)
   if BDMYnUAqOoepfFrgjyWkSwElubmhzd.get('pagination').get('totalPages')>page_int:
    BDMYnUAqOoepfFrgjyWkSwElubmhzt=BDMYnUAqOoepfFrgjyWkSwElubmhLi
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception)
  return BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt
 def Selenium_Cookies_Load(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,in_filename):
  fp=BDMYnUAqOoepfFrgjyWkSwElubmhVs(in_filename,'rb',-1)
  try:
   BDMYnUAqOoepfFrgjyWkSwElubmhQd=pickle.loads(fp.read())
   if BDMYnUAqOoepfFrgjyWkSwElubmhVt(BDMYnUAqOoepfFrgjyWkSwElubmhQd)==BDMYnUAqOoepfFrgjyWkSwElubmhVP:
    for BDMYnUAqOoepfFrgjyWkSwElubmhQK in BDMYnUAqOoepfFrgjyWkSwElubmhQd:
     BDMYnUAqOoepfFrgjyWkSwElubmhzQ.HTTP_CLIENT.cookies.set_cookie(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.To_Cookielib(BDMYnUAqOoepfFrgjyWkSwElubmhQK)) 
   else:
    BDMYnUAqOoepfFrgjyWkSwElubmhzQ.HTTP_CLIENT.cookies.update(BDMYnUAqOoepfFrgjyWkSwElubmhQd) 
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception)
  finally:
   fp.close()
 def To_Cookielib(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,selenium_cookie):
  return http.cookiejar.Cookie(version=0,name=selenium_cookie['name'],value=selenium_cookie['value'],port=BDMYnUAqOoepfFrgjyWkSwElubmhLX,port_specified=BDMYnUAqOoepfFrgjyWkSwElubmhVQ,domain=selenium_cookie['domain'],domain_specified=BDMYnUAqOoepfFrgjyWkSwElubmhLi,domain_initial_dot=BDMYnUAqOoepfFrgjyWkSwElubmhVQ,path=selenium_cookie['path'],path_specified=BDMYnUAqOoepfFrgjyWkSwElubmhLi,secure=selenium_cookie['secure'],expires=selenium_cookie['expiry'],discard=BDMYnUAqOoepfFrgjyWkSwElubmhVQ,comment=BDMYnUAqOoepfFrgjyWkSwElubmhLX,comment_url=BDMYnUAqOoepfFrgjyWkSwElubmhLX,rest={'HttpOnly':selenium_cookie['httpOnly']},rfc2109=BDMYnUAqOoepfFrgjyWkSwElubmhVQ,)
 def Get_Search_Primev(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,search_key):
  BDMYnUAqOoepfFrgjyWkSwElubmhzG=[]
  try:
   BDMYnUAqOoepfFrgjyWkSwElubmhzQ.PV=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.jsonfile_To_dic(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.PV_ORIGINAL_COOKIE)
   BDMYnUAqOoepfFrgjyWkSwElubmhQc=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.PV['COOKIES']
   BDMYnUAqOoepfFrgjyWkSwElubmhzP=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_PRIMEV+'/search/ref=atv_nb_sr?phrase='+urllib.parse.quote_plus(search_key)+'&ie=UTF8'
   BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.Call_Request(BDMYnUAqOoepfFrgjyWkSwElubmhzP,params=BDMYnUAqOoepfFrgjyWkSwElubmhLX,headers=BDMYnUAqOoepfFrgjyWkSwElubmhLX,cookies=BDMYnUAqOoepfFrgjyWkSwElubmhQc,method='GET')
   if BDMYnUAqOoepfFrgjyWkSwElubmhzL.status_code!=200:return[]
   BDMYnUAqOoepfFrgjyWkSwElubmhQI='{"props":{"containers"'
   BDMYnUAqOoepfFrgjyWkSwElubmhQH=r'<script type="text/template">\s*(.*?)\s*</script>'
   BDMYnUAqOoepfFrgjyWkSwElubmhQa=re.compile(BDMYnUAqOoepfFrgjyWkSwElubmhQH,re.DOTALL).findall(BDMYnUAqOoepfFrgjyWkSwElubmhzL.text)
   BDMYnUAqOoepfFrgjyWkSwElubmhQJ='{}'
   for BDMYnUAqOoepfFrgjyWkSwElubmhQN in BDMYnUAqOoepfFrgjyWkSwElubmhQa:
    if BDMYnUAqOoepfFrgjyWkSwElubmhQI in BDMYnUAqOoepfFrgjyWkSwElubmhQN:
     BDMYnUAqOoepfFrgjyWkSwElubmhQJ=BDMYnUAqOoepfFrgjyWkSwElubmhQN
     break
   BDMYnUAqOoepfFrgjyWkSwElubmhzd=json.loads(BDMYnUAqOoepfFrgjyWkSwElubmhQJ)
   BDMYnUAqOoepfFrgjyWkSwElubmhzQ.dic_To_jsonfile(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_CONTEXTJSON_FILE1,BDMYnUAqOoepfFrgjyWkSwElubmhzd)
   BDMYnUAqOoepfFrgjyWkSwElubmhQX=BDMYnUAqOoepfFrgjyWkSwElubmhzd.get('props')
   for BDMYnUAqOoepfFrgjyWkSwElubmhQi in BDMYnUAqOoepfFrgjyWkSwElubmhQX.get('containers'):
    if BDMYnUAqOoepfFrgjyWkSwElubmhQi.get('containerType')=='Grid':
     BDMYnUAqOoepfFrgjyWkSwElubmhQT=BDMYnUAqOoepfFrgjyWkSwElubmhQi.get('entities')
     break
   for BDMYnUAqOoepfFrgjyWkSwElubmhCz in BDMYnUAqOoepfFrgjyWkSwElubmhQT:
    if 'titleID' not in BDMYnUAqOoepfFrgjyWkSwElubmhCz:return[]
    BDMYnUAqOoepfFrgjyWkSwElubmhzi={'title':BDMYnUAqOoepfFrgjyWkSwElubmhCz.get('title'),}
    BDMYnUAqOoepfFrgjyWkSwElubmhzG.append(BDMYnUAqOoepfFrgjyWkSwElubmhzi)
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception)
  return BDMYnUAqOoepfFrgjyWkSwElubmhzG
 def Get_Search_Disney(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,search_key):
  BDMYnUAqOoepfFrgjyWkSwElubmhzG=[]
  BDMYnUAqOoepfFrgjyWkSwElubmhzP=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['services']['content']['getSearchResults']['href']
  BDMYnUAqOoepfFrgjyWkSwElubmhCx={'apiVersion':'5.1','region':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge','pageSize':BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DISNEY_LIMIT),'query':search_key,}
  BDMYnUAqOoepfFrgjyWkSwElubmhzP=BDMYnUAqOoepfFrgjyWkSwElubmhzP.format(**BDMYnUAqOoepfFrgjyWkSwElubmhCx)
  BDMYnUAqOoepfFrgjyWkSwElubmhQv=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.make_DZ_Headers(accessToken=BDMYnUAqOoepfFrgjyWkSwElubmhLi,Bearer=BDMYnUAqOoepfFrgjyWkSwElubmhLi)
  BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.Call_Request(BDMYnUAqOoepfFrgjyWkSwElubmhzP,headers=BDMYnUAqOoepfFrgjyWkSwElubmhQv,cookies=BDMYnUAqOoepfFrgjyWkSwElubmhLX,method='GET')
  if BDMYnUAqOoepfFrgjyWkSwElubmhzL.status_code not in[200,201]:return[]
  BDMYnUAqOoepfFrgjyWkSwElubmhCQ=BDMYnUAqOoepfFrgjyWkSwElubmhzL.json().get('data').get('search')
  for BDMYnUAqOoepfFrgjyWkSwElubmhCz in BDMYnUAqOoepfFrgjyWkSwElubmhCQ.get('hits'):
   BDMYnUAqOoepfFrgjyWkSwElubmhCz=BDMYnUAqOoepfFrgjyWkSwElubmhCz.get('hit')
   if BDMYnUAqOoepfFrgjyWkSwElubmhCz.get('type')=='DmcSeries': 
    BDMYnUAqOoepfFrgjyWkSwElubmhQL =BDMYnUAqOoepfFrgjyWkSwElubmhCz.get('text').get('title').get('full').get('series').get('default').get('content')
   elif BDMYnUAqOoepfFrgjyWkSwElubmhCz.get('type')=='DmcVideo':
    BDMYnUAqOoepfFrgjyWkSwElubmhQL =BDMYnUAqOoepfFrgjyWkSwElubmhCz.get('text').get('title').get('full').get('program').get('default').get('content')
   elif BDMYnUAqOoepfFrgjyWkSwElubmhCz.get('type')=='StandardCollection':
    BDMYnUAqOoepfFrgjyWkSwElubmhQL =BDMYnUAqOoepfFrgjyWkSwElubmhCz.get('text').get('title').get('full').get('collection').get('default').get('content')
   else:
    return BDMYnUAqOoepfFrgjyWkSwElubmhzG
   BDMYnUAqOoepfFrgjyWkSwElubmhzi={'title':BDMYnUAqOoepfFrgjyWkSwElubmhQL,}
   BDMYnUAqOoepfFrgjyWkSwElubmhzG.append(BDMYnUAqOoepfFrgjyWkSwElubmhzi)
  return BDMYnUAqOoepfFrgjyWkSwElubmhzG
 def dic_To_jsonfile(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,filename,BDMYnUAqOoepfFrgjyWkSwElubmhCL):
  if filename=='':return
  fp=BDMYnUAqOoepfFrgjyWkSwElubmhVs(filename,'w',-1,'utf-8')
  json.dump(BDMYnUAqOoepfFrgjyWkSwElubmhCL,fp,indent=4,ensure_ascii=BDMYnUAqOoepfFrgjyWkSwElubmhVQ)
  fp.close()
 def jsonfile_To_dic(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,filename):
  if filename=='':return BDMYnUAqOoepfFrgjyWkSwElubmhLX
  try:
   fp=BDMYnUAqOoepfFrgjyWkSwElubmhVs(filename,'r',-1,'utf-8')
   BDMYnUAqOoepfFrgjyWkSwElubmhCG=json.load(fp)
   fp.close()
  except:
   BDMYnUAqOoepfFrgjyWkSwElubmhCG={}
  return BDMYnUAqOoepfFrgjyWkSwElubmhCG
 def tempFileSave(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,filename,resText):
  if filename=='':return
  fp=BDMYnUAqOoepfFrgjyWkSwElubmhVs(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,filename):
  if filename=='':return
  try:
   fp=BDMYnUAqOoepfFrgjyWkSwElubmhVs(filename,'r',-1,'utf-8')
   BDMYnUAqOoepfFrgjyWkSwElubmhCG=fp.read()
   fp.close()
  except:
   BDMYnUAqOoepfFrgjyWkSwElubmhCG=''
  return BDMYnUAqOoepfFrgjyWkSwElubmhCG
 def make_DZ_Headers(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,accessToken=BDMYnUAqOoepfFrgjyWkSwElubmhLi,Bearer=BDMYnUAqOoepfFrgjyWkSwElubmhVQ):
  if accessToken:
   BDMYnUAqOoepfFrgjyWkSwElubmhCs=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['account']['accessToken']
  else:
   BDMYnUAqOoepfFrgjyWkSwElubmhCs=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['headers']['clientApiKey']
  if Bearer:
   BDMYnUAqOoepfFrgjyWkSwElubmhCs='Bearer {}'.format(BDMYnUAqOoepfFrgjyWkSwElubmhCs)
  BDMYnUAqOoepfFrgjyWkSwElubmhQv={'authorization':BDMYnUAqOoepfFrgjyWkSwElubmhCs,'x-application-version':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['headers']['sdkAppVersion'],'x-bamsdk-client-id':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['headers']['clientId'],'x-bamsdk-platform':'windows','x-bamsdk-version':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['headers']['sdkVersion'],'x-dss-edge-accept':'vnd.dss.edge+json; version=2',}
  return BDMYnUAqOoepfFrgjyWkSwElubmhQv
 def DZ_ReToken(BDMYnUAqOoepfFrgjyWkSwElubmhzQ):
  try:
   BDMYnUAqOoepfFrgjyWkSwElubmhzP =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['services']['orchestration']['refreshToken']['href']
   BDMYnUAqOoepfFrgjyWkSwElubmhQv=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.make_DZ_Headers(accessToken=BDMYnUAqOoepfFrgjyWkSwElubmhVQ,Bearer=BDMYnUAqOoepfFrgjyWkSwElubmhVQ)
   BDMYnUAqOoepfFrgjyWkSwElubmhCt={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['account']['refreshToken'],}}}
   BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.Call_Request(BDMYnUAqOoepfFrgjyWkSwElubmhzP,json=BDMYnUAqOoepfFrgjyWkSwElubmhCt,headers=BDMYnUAqOoepfFrgjyWkSwElubmhQv,cookies=BDMYnUAqOoepfFrgjyWkSwElubmhLX,method='POST')
   if BDMYnUAqOoepfFrgjyWkSwElubmhzL.status_code not in[200,201]:return BDMYnUAqOoepfFrgjyWkSwElubmhVQ
   BDMYnUAqOoepfFrgjyWkSwElubmhCQ=BDMYnUAqOoepfFrgjyWkSwElubmhzL.json()
   BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['account']['accessToken'] =BDMYnUAqOoepfFrgjyWkSwElubmhCQ.get('extensions').get('sdk').get('token').get('accessToken')
   BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['account']['accessTokenType']=BDMYnUAqOoepfFrgjyWkSwElubmhCQ.get('extensions').get('sdk').get('token').get('accessTokenType')
   BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['account']['refreshToken'] =BDMYnUAqOoepfFrgjyWkSwElubmhCQ.get('extensions').get('sdk').get('token').get('refreshToken')
   BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['account']['token_limit'] =BDMYnUAqOoepfFrgjyWkSwElubmhVx(time.time())+14400 
   BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['account']['deviceId'] =BDMYnUAqOoepfFrgjyWkSwElubmhCQ.get('extensions').get('sdk').get('session').get('device').get('id')
   BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DZ['account']['sessionId'] =BDMYnUAqOoepfFrgjyWkSwElubmhCQ.get('extensions').get('sdk').get('session').get('sessionId')
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception)
   return BDMYnUAqOoepfFrgjyWkSwElubmhVQ
  return BDMYnUAqOoepfFrgjyWkSwElubmhLi
 def Init_NF_Total(BDMYnUAqOoepfFrgjyWkSwElubmhzQ):
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF={}
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']={}
  BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']={}
 def make_NF_XnetflixHeaders(BDMYnUAqOoepfFrgjyWkSwElubmhzQ):
  BDMYnUAqOoepfFrgjyWkSwElubmhQv={'x-netflix.browsername':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['esnModel'],'x-netflix.esnprefix':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['nowGuid'],'x-netflix.uiversion':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return BDMYnUAqOoepfFrgjyWkSwElubmhQv
 def make_NF_ApiParams(BDMYnUAqOoepfFrgjyWkSwElubmhzQ):
  BDMYnUAqOoepfFrgjyWkSwElubmhzv={'avif':'false','webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','isTop10KidsSupported':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/mre/pathEvaluator',}
  return BDMYnUAqOoepfFrgjyWkSwElubmhzv
 def extract_json(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,content,name):
  BDMYnUAqOoepfFrgjyWkSwElubmhQH=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  BDMYnUAqOoepfFrgjyWkSwElubmhQJ=BDMYnUAqOoepfFrgjyWkSwElubmhLX
  BDMYnUAqOoepfFrgjyWkSwElubmhCP=re.compile(BDMYnUAqOoepfFrgjyWkSwElubmhQH.format(name),re.DOTALL).findall(content)
  BDMYnUAqOoepfFrgjyWkSwElubmhQJ=BDMYnUAqOoepfFrgjyWkSwElubmhCP[0]
  BDMYnUAqOoepfFrgjyWkSwElubmhCv=BDMYnUAqOoepfFrgjyWkSwElubmhQJ.replace('\\"','\\\\"') 
  BDMYnUAqOoepfFrgjyWkSwElubmhCv=BDMYnUAqOoepfFrgjyWkSwElubmhCv.replace('\\s','\\\\s') 
  BDMYnUAqOoepfFrgjyWkSwElubmhCv=BDMYnUAqOoepfFrgjyWkSwElubmhCv.replace('\\n','\\\\n') 
  BDMYnUAqOoepfFrgjyWkSwElubmhCv=BDMYnUAqOoepfFrgjyWkSwElubmhCv.replace('\\t','\\\\t') 
  BDMYnUAqOoepfFrgjyWkSwElubmhCv=BDMYnUAqOoepfFrgjyWkSwElubmhCv.encode().decode('unicode_escape') 
  BDMYnUAqOoepfFrgjyWkSwElubmhCv=re.sub(r'\\(?!["])',r'\\\\',BDMYnUAqOoepfFrgjyWkSwElubmhCv) 
  return json.loads(BDMYnUAqOoepfFrgjyWkSwElubmhCv)
 def NF_makestr_paths(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,paths):
  BDMYnUAqOoepfFrgjyWkSwElubmhCG=[]
  if BDMYnUAqOoepfFrgjyWkSwElubmhVv(paths,BDMYnUAqOoepfFrgjyWkSwElubmhVx):
   return '%d'%(paths)
  elif BDMYnUAqOoepfFrgjyWkSwElubmhVv(paths,BDMYnUAqOoepfFrgjyWkSwElubmhVz):
   return '"%s"'%(paths)
  for BDMYnUAqOoepfFrgjyWkSwElubmhCd in paths:
   if BDMYnUAqOoepfFrgjyWkSwElubmhVv(BDMYnUAqOoepfFrgjyWkSwElubmhCd,BDMYnUAqOoepfFrgjyWkSwElubmhVx):
    BDMYnUAqOoepfFrgjyWkSwElubmhCG.append('%d'%(BDMYnUAqOoepfFrgjyWkSwElubmhCd))
   elif BDMYnUAqOoepfFrgjyWkSwElubmhVv(BDMYnUAqOoepfFrgjyWkSwElubmhCd,BDMYnUAqOoepfFrgjyWkSwElubmhVz):
    BDMYnUAqOoepfFrgjyWkSwElubmhCG.append('"%s"'%(BDMYnUAqOoepfFrgjyWkSwElubmhCd))
   elif BDMYnUAqOoepfFrgjyWkSwElubmhVv(BDMYnUAqOoepfFrgjyWkSwElubmhCd,BDMYnUAqOoepfFrgjyWkSwElubmhVP):
    BDMYnUAqOoepfFrgjyWkSwElubmhCG.append('[%s]'%(','.join(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_makestr_paths(BDMYnUAqOoepfFrgjyWkSwElubmhCd))))
   elif BDMYnUAqOoepfFrgjyWkSwElubmhVv(BDMYnUAqOoepfFrgjyWkSwElubmhCd,BDMYnUAqOoepfFrgjyWkSwElubmhVC):
    BDMYnUAqOoepfFrgjyWkSwElubmhCK=''
    for BDMYnUAqOoepfFrgjyWkSwElubmhCR,BDMYnUAqOoepfFrgjyWkSwElubmhCc in BDMYnUAqOoepfFrgjyWkSwElubmhCd.items():
     BDMYnUAqOoepfFrgjyWkSwElubmhCK+='"%s":%s,'%(BDMYnUAqOoepfFrgjyWkSwElubmhCR,BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_makestr_paths(BDMYnUAqOoepfFrgjyWkSwElubmhCc))
    BDMYnUAqOoepfFrgjyWkSwElubmhCG.append('{%s}'%(BDMYnUAqOoepfFrgjyWkSwElubmhCK[:-1]))
  return BDMYnUAqOoepfFrgjyWkSwElubmhCG
 def NF_Call_pathapi(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,BDMYnUAqOoepfFrgjyWkSwElubmhLx,referer=''):
  BDMYnUAqOoepfFrgjyWkSwElubmhCI='%s/nq/website/memberapi/%s/pathEvaluator'%(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_NETFLIX,BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['identifier'])
  BDMYnUAqOoepfFrgjyWkSwElubmhCt={'path':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_makestr_paths(BDMYnUAqOoepfFrgjyWkSwElubmhLx),'authURL':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']['authURL']}
  BDMYnUAqOoepfFrgjyWkSwElubmhzv=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.make_NF_ApiParams()
  BDMYnUAqOoepfFrgjyWkSwElubmhQv={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_NETFLIX,'sec-ch-ua':'"Google Chrome";v="101", "Not)A;Brand";v="8", "Chromium";v="101"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':BDMYnUAqOoepfFrgjyWkSwElubmhQv['referer']=referer
  BDMYnUAqOoepfFrgjyWkSwElubmhCH=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.make_NF_XnetflixHeaders()
  BDMYnUAqOoepfFrgjyWkSwElubmhQv.update(BDMYnUAqOoepfFrgjyWkSwElubmhCH)
  BDMYnUAqOoepfFrgjyWkSwElubmhQc=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_Get_DefaultCookies()
  BDMYnUAqOoepfFrgjyWkSwElubmhQc['profilesNewSession']='0'
  try:
   BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.Call_Request(BDMYnUAqOoepfFrgjyWkSwElubmhCI,payload=BDMYnUAqOoepfFrgjyWkSwElubmhCt,params=BDMYnUAqOoepfFrgjyWkSwElubmhzv,headers=BDMYnUAqOoepfFrgjyWkSwElubmhQv,cookies=BDMYnUAqOoepfFrgjyWkSwElubmhQc,method='POST')
   return BDMYnUAqOoepfFrgjyWkSwElubmhzL
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception)
   return BDMYnUAqOoepfFrgjyWkSwElubmhLX
 def Get_Search_Netflix(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,search_key,page_int,byReference=''):
  BDMYnUAqOoepfFrgjyWkSwElubmhCa=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.DERECTOR_LIMIT
  BDMYnUAqOoepfFrgjyWkSwElubmhCJ =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.CAST_LIMIT
  BDMYnUAqOoepfFrgjyWkSwElubmhCN =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.GENRE_LIMIT
  BDMYnUAqOoepfFrgjyWkSwElubmhCX =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_LIMIT*(page_int-1)
  BDMYnUAqOoepfFrgjyWkSwElubmhCi =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_LIMIT*page_int 
  BDMYnUAqOoepfFrgjyWkSwElubmhCT="|%s"%(search_key)
  BDMYnUAqOoepfFrgjyWkSwElubmhLz ='%s/search?%s'%(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   BDMYnUAqOoepfFrgjyWkSwElubmhLx=[["search","byTerm",BDMYnUAqOoepfFrgjyWkSwElubmhCT,"titles",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_LIMIT,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"summary"],["search","byTerm",BDMYnUAqOoepfFrgjyWkSwElubmhCT,"titles",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_LIMIT,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",BDMYnUAqOoepfFrgjyWkSwElubmhCT,"titles",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_LIMIT,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference","boxarts",[BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND2,BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_PORT],"jpg"],["search","byTerm",BDMYnUAqOoepfFrgjyWkSwElubmhCT,"titles",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_LIMIT,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference","interestingMoment",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND1,"jpg"],["search","byTerm",BDMYnUAqOoepfFrgjyWkSwElubmhCT,"titles",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_LIMIT,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference","storyArt",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND2,"jpg"],["search","byTerm",BDMYnUAqOoepfFrgjyWkSwElubmhCT,"titles",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_LIMIT,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference",["cast","creators","directors"],{"from":0,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCa},["id","name"]],["search","byTerm",BDMYnUAqOoepfFrgjyWkSwElubmhCT,"titles",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_LIMIT,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference","genres",{"from":0,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCN},["id","name"]],["search","byTerm",BDMYnUAqOoepfFrgjyWkSwElubmhCT,"titles",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NETFLIX_LIMIT,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LOGO,"png"],]
  else:
   BDMYnUAqOoepfFrgjyWkSwElubmhLx=[["search","byReference",byReference,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"summary"],["search","byReference",byReference,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference","boxarts",[BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND2,BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference","interestingMoment",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference","storyArt",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference",["cast","creators","directors"],{"from":0,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCa},["id","name"]],["search","byReference",byReference,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference","genres",{"from":0,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCN},["id","name"]],["search","byReference",byReference,{"from":BDMYnUAqOoepfFrgjyWkSwElubmhCX,"to":BDMYnUAqOoepfFrgjyWkSwElubmhCi},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LOGO,"png"],]
  try:
   BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_Call_pathapi(BDMYnUAqOoepfFrgjyWkSwElubmhLx,BDMYnUAqOoepfFrgjyWkSwElubmhLz)
   BDMYnUAqOoepfFrgjyWkSwElubmhzd=json.loads(BDMYnUAqOoepfFrgjyWkSwElubmhzL.text)
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception)
  (BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt,byReference)=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.Search_Netflix_Make(BDMYnUAqOoepfFrgjyWkSwElubmhzd)
  return BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt,byReference
 def Search_Netflix_Make(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,jsonSource):
  BDMYnUAqOoepfFrgjyWkSwElubmhzG=[]
  BDMYnUAqOoepfFrgjyWkSwElubmhzt =BDMYnUAqOoepfFrgjyWkSwElubmhVQ
  BDMYnUAqOoepfFrgjyWkSwElubmhLQ=''
  BDMYnUAqOoepfFrgjyWkSwElubmhLC=jsonSource.get('paths')[0][1]
  if BDMYnUAqOoepfFrgjyWkSwElubmhLC=='byTerm':
   BDMYnUAqOoepfFrgjyWkSwElubmhCX =jsonSource['paths'][0][5]['from']
   BDMYnUAqOoepfFrgjyWkSwElubmhCi =jsonSource['paths'][0][5]['to']
  else:
   BDMYnUAqOoepfFrgjyWkSwElubmhCX =jsonSource['paths'][0][3]['from']
   BDMYnUAqOoepfFrgjyWkSwElubmhCi =jsonSource['paths'][0][3]['to']
  BDMYnUAqOoepfFrgjyWkSwElubmhLQ=BDMYnUAqOoepfFrgjyWkSwElubmhVP(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  BDMYnUAqOoepfFrgjyWkSwElubmhLV=jsonSource.get('jsonGraph').get('search').get('byReference').get(BDMYnUAqOoepfFrgjyWkSwElubmhLQ)
  BDMYnUAqOoepfFrgjyWkSwElubmhLG =jsonSource.get('jsonGraph').get('videos')
  BDMYnUAqOoepfFrgjyWkSwElubmhLs=jsonSource.get('jsonGraph').get('person')
  BDMYnUAqOoepfFrgjyWkSwElubmhLt=jsonSource.get('jsonGraph').get('genres')
  BDMYnUAqOoepfFrgjyWkSwElubmhzt=BDMYnUAqOoepfFrgjyWkSwElubmhLi if BDMYnUAqOoepfFrgjyWkSwElubmhLV[BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhCi)]['reference']['$type']=='ref' else BDMYnUAqOoepfFrgjyWkSwElubmhVQ
  for BDMYnUAqOoepfFrgjyWkSwElubmhLP in BDMYnUAqOoepfFrgjyWkSwElubmhVd(BDMYnUAqOoepfFrgjyWkSwElubmhCX,BDMYnUAqOoepfFrgjyWkSwElubmhCi):
   if BDMYnUAqOoepfFrgjyWkSwElubmhLV[BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhLP)]['reference']['$type']=='ref':
    BDMYnUAqOoepfFrgjyWkSwElubmhzJ =BDMYnUAqOoepfFrgjyWkSwElubmhLV[BDMYnUAqOoepfFrgjyWkSwElubmhVz(BDMYnUAqOoepfFrgjyWkSwElubmhLP)]['reference']['value'][1]
    BDMYnUAqOoepfFrgjyWkSwElubmhLv=BDMYnUAqOoepfFrgjyWkSwElubmhLG[BDMYnUAqOoepfFrgjyWkSwElubmhzJ]
    BDMYnUAqOoepfFrgjyWkSwElubmhQL =BDMYnUAqOoepfFrgjyWkSwElubmhLv['title']['value']
    if BDMYnUAqOoepfFrgjyWkSwElubmhLv['availability']['value']['isPlayable']==BDMYnUAqOoepfFrgjyWkSwElubmhVQ:
     continue
    BDMYnUAqOoepfFrgjyWkSwElubmhzH =BDMYnUAqOoepfFrgjyWkSwElubmhLv['summary']['value']['type']
    BDMYnUAqOoepfFrgjyWkSwElubmhxc =0 if BDMYnUAqOoepfFrgjyWkSwElubmhzH!='movie' else BDMYnUAqOoepfFrgjyWkSwElubmhLv['runtime']['value']
    if BDMYnUAqOoepfFrgjyWkSwElubmhLv['sequiturEvidence']['value']['value']:
     BDMYnUAqOoepfFrgjyWkSwElubmhLd=BDMYnUAqOoepfFrgjyWkSwElubmhLv['sequiturEvidence']['value']['value']['text']
    else:
     BDMYnUAqOoepfFrgjyWkSwElubmhLd=''
    BDMYnUAqOoepfFrgjyWkSwElubmhxP =BDMYnUAqOoepfFrgjyWkSwElubmhLv['boxarts'][BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_PORT]['jpg']['value']['url']
    BDMYnUAqOoepfFrgjyWkSwElubmhLK =BDMYnUAqOoepfFrgjyWkSwElubmhLv['boxarts'][BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND2]['jpg']['value']['url']
    BDMYnUAqOoepfFrgjyWkSwElubmhxv=''
    if 'value' in BDMYnUAqOoepfFrgjyWkSwElubmhLv['storyArt'][BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND2]['jpg']:
     BDMYnUAqOoepfFrgjyWkSwElubmhxv =BDMYnUAqOoepfFrgjyWkSwElubmhLv['storyArt'][BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND2]['jpg']['value']['url']
    if BDMYnUAqOoepfFrgjyWkSwElubmhxv=='' and 'value' in BDMYnUAqOoepfFrgjyWkSwElubmhLv['interestingMoment'][BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND1]['jpg']:
     BDMYnUAqOoepfFrgjyWkSwElubmhxv =BDMYnUAqOoepfFrgjyWkSwElubmhLv['interestingMoment'][BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LAND1]['jpg']['value']['url']
    BDMYnUAqOoepfFrgjyWkSwElubmhxX=''
    if 'value' in BDMYnUAqOoepfFrgjyWkSwElubmhLv['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LOGO]['png']:
     BDMYnUAqOoepfFrgjyWkSwElubmhxX=BDMYnUAqOoepfFrgjyWkSwElubmhLv['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][BDMYnUAqOoepfFrgjyWkSwElubmhzQ.ART_SIZE_LOGO]['png']['value']['url']
    BDMYnUAqOoepfFrgjyWkSwElubmhxR =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_Subid_List(BDMYnUAqOoepfFrgjyWkSwElubmhLv['genres'])
    for i in BDMYnUAqOoepfFrgjyWkSwElubmhVd(BDMYnUAqOoepfFrgjyWkSwElubmhVG(BDMYnUAqOoepfFrgjyWkSwElubmhxR)):
     BDMYnUAqOoepfFrgjyWkSwElubmhxR[i]=BDMYnUAqOoepfFrgjyWkSwElubmhLt[BDMYnUAqOoepfFrgjyWkSwElubmhxR[i]]['name']['value']
    BDMYnUAqOoepfFrgjyWkSwElubmhxK=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_Subid_List(BDMYnUAqOoepfFrgjyWkSwElubmhLv['directors'])
    BDMYnUAqOoepfFrgjyWkSwElubmhLR =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_Subid_List(BDMYnUAqOoepfFrgjyWkSwElubmhLv['creators'])
    BDMYnUAqOoepfFrgjyWkSwElubmhxK.extend(BDMYnUAqOoepfFrgjyWkSwElubmhLR)
    for i in BDMYnUAqOoepfFrgjyWkSwElubmhVd(BDMYnUAqOoepfFrgjyWkSwElubmhVG(BDMYnUAqOoepfFrgjyWkSwElubmhxK)):
     BDMYnUAqOoepfFrgjyWkSwElubmhxK[i]=BDMYnUAqOoepfFrgjyWkSwElubmhLs[BDMYnUAqOoepfFrgjyWkSwElubmhxK[i]]['name']['value']
    BDMYnUAqOoepfFrgjyWkSwElubmhxd=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_Subid_List(BDMYnUAqOoepfFrgjyWkSwElubmhLv['cast'])
    for i in BDMYnUAqOoepfFrgjyWkSwElubmhVd(BDMYnUAqOoepfFrgjyWkSwElubmhVG(BDMYnUAqOoepfFrgjyWkSwElubmhxd)):
     BDMYnUAqOoepfFrgjyWkSwElubmhxd[i]=BDMYnUAqOoepfFrgjyWkSwElubmhLs[BDMYnUAqOoepfFrgjyWkSwElubmhxd[i]]['name']['value']
    if 'maturityDescription' in BDMYnUAqOoepfFrgjyWkSwElubmhLv['maturity']['value']['rating']:
     BDMYnUAqOoepfFrgjyWkSwElubmhxI=BDMYnUAqOoepfFrgjyWkSwElubmhLv['maturity']['value']['rating']['maturityDescription']
    BDMYnUAqOoepfFrgjyWkSwElubmhzi={'videoid':BDMYnUAqOoepfFrgjyWkSwElubmhzJ,'vidtype':BDMYnUAqOoepfFrgjyWkSwElubmhzH,'title':BDMYnUAqOoepfFrgjyWkSwElubmhQL,'mpaa':BDMYnUAqOoepfFrgjyWkSwElubmhxI,'regularSynopsis':BDMYnUAqOoepfFrgjyWkSwElubmhLv['regularSynopsis']['value'],'dpSupplemental':BDMYnUAqOoepfFrgjyWkSwElubmhLv['dpSupplementalMessage']['value'],'sequiturEvidence':BDMYnUAqOoepfFrgjyWkSwElubmhLd,'thumbnail':{'poster':BDMYnUAqOoepfFrgjyWkSwElubmhxP,'thumb':BDMYnUAqOoepfFrgjyWkSwElubmhxv,'fanart':BDMYnUAqOoepfFrgjyWkSwElubmhLK,'clearlogo':BDMYnUAqOoepfFrgjyWkSwElubmhxX},'year':BDMYnUAqOoepfFrgjyWkSwElubmhLv['releaseYear']['value'],'duration':BDMYnUAqOoepfFrgjyWkSwElubmhxc,'info_genre':BDMYnUAqOoepfFrgjyWkSwElubmhxR,'director':BDMYnUAqOoepfFrgjyWkSwElubmhxK,'cast':BDMYnUAqOoepfFrgjyWkSwElubmhxd,}
    BDMYnUAqOoepfFrgjyWkSwElubmhzG.append(BDMYnUAqOoepfFrgjyWkSwElubmhzi)
  return BDMYnUAqOoepfFrgjyWkSwElubmhzG,BDMYnUAqOoepfFrgjyWkSwElubmhzt,BDMYnUAqOoepfFrgjyWkSwElubmhLQ
 def NF_Subid_List(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,subJson):
  BDMYnUAqOoepfFrgjyWkSwElubmhLc=[]
  try:
   for i in BDMYnUAqOoepfFrgjyWkSwElubmhVd(BDMYnUAqOoepfFrgjyWkSwElubmhVG(subJson)):
    if subJson.get(BDMYnUAqOoepfFrgjyWkSwElubmhVz(i)).get('$type')!='ref':break
    BDMYnUAqOoepfFrgjyWkSwElubmhLI=subJson.get(BDMYnUAqOoepfFrgjyWkSwElubmhVz(i)).get('value')[1]
    BDMYnUAqOoepfFrgjyWkSwElubmhLc.append(BDMYnUAqOoepfFrgjyWkSwElubmhLI)
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception)
  return BDMYnUAqOoepfFrgjyWkSwElubmhLc
 def NF_CookieFile_Load(BDMYnUAqOoepfFrgjyWkSwElubmhzQ,cookie_filename):
  BDMYnUAqOoepfFrgjyWkSwElubmhQc={}
  try:
   if os.path.isfile(cookie_filename)==BDMYnUAqOoepfFrgjyWkSwElubmhVQ:return{}
   BDMYnUAqOoepfFrgjyWkSwElubmhLH=BDMYnUAqOoepfFrgjyWkSwElubmhVs(cookie_filename,'rb',-1)
   BDMYnUAqOoepfFrgjyWkSwElubmhLa =pickle.loads(BDMYnUAqOoepfFrgjyWkSwElubmhLH.read())
   BDMYnUAqOoepfFrgjyWkSwElubmhLH.close()
   for BDMYnUAqOoepfFrgjyWkSwElubmhQK in BDMYnUAqOoepfFrgjyWkSwElubmhLa:
    BDMYnUAqOoepfFrgjyWkSwElubmhQc[BDMYnUAqOoepfFrgjyWkSwElubmhQK.name]=BDMYnUAqOoepfFrgjyWkSwElubmhQK.value
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception) 
  return BDMYnUAqOoepfFrgjyWkSwElubmhQc
 def NF_Get_DefaultCookies(BDMYnUAqOoepfFrgjyWkSwElubmhzQ):
  BDMYnUAqOoepfFrgjyWkSwElubmhQc={}
  if BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']['flwssn'] :BDMYnUAqOoepfFrgjyWkSwElubmhQc['flwssn'] =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']['flwssn']
  if BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']['nfvdid'] :BDMYnUAqOoepfFrgjyWkSwElubmhQc['nfvdid'] =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']['nfvdid']
  if BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']['SecureNetflixId']:BDMYnUAqOoepfFrgjyWkSwElubmhQc['SecureNetflixId']=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']['SecureNetflixId']
  if BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']['NetflixId'] :BDMYnUAqOoepfFrgjyWkSwElubmhQc['NetflixId'] =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']['NetflixId']
  if BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']['memclid'] :BDMYnUAqOoepfFrgjyWkSwElubmhQc['memclid'] =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['COOKIES']['memclid']
  return BDMYnUAqOoepfFrgjyWkSwElubmhQc
 def NF_Get_BaseSession(BDMYnUAqOoepfFrgjyWkSwElubmhzQ):
  try:
   BDMYnUAqOoepfFrgjyWkSwElubmhzP=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.API_NETFLIX+'/browse' 
   BDMYnUAqOoepfFrgjyWkSwElubmhQc=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_Get_DefaultCookies()
   BDMYnUAqOoepfFrgjyWkSwElubmhzL=BDMYnUAqOoepfFrgjyWkSwElubmhzQ.Call_Request(BDMYnUAqOoepfFrgjyWkSwElubmhzP,payload=BDMYnUAqOoepfFrgjyWkSwElubmhLX,params=BDMYnUAqOoepfFrgjyWkSwElubmhLX,headers=BDMYnUAqOoepfFrgjyWkSwElubmhLX,cookies=BDMYnUAqOoepfFrgjyWkSwElubmhQc,method='GET')
   if BDMYnUAqOoepfFrgjyWkSwElubmhzL.status_code!=200:
    BDMYnUAqOoepfFrgjyWkSwElubmhLT('pass 1 status_code error')
    return BDMYnUAqOoepfFrgjyWkSwElubmhVQ
   BDMYnUAqOoepfFrgjyWkSwElubmhLJ =BDMYnUAqOoepfFrgjyWkSwElubmhzQ.extract_json(BDMYnUAqOoepfFrgjyWkSwElubmhzL.text,'reactContext')
   BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF['SESSION']={'mainGuid':BDMYnUAqOoepfFrgjyWkSwElubmhLJ['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':BDMYnUAqOoepfFrgjyWkSwElubmhLJ['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':BDMYnUAqOoepfFrgjyWkSwElubmhLJ['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':BDMYnUAqOoepfFrgjyWkSwElubmhLJ['models']['memberContext']['data']['userInfo']['esn'],'identifier':BDMYnUAqOoepfFrgjyWkSwElubmhLJ['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':BDMYnUAqOoepfFrgjyWkSwElubmhLJ['models']['abContext']['data']['headers'],}
   BDMYnUAqOoepfFrgjyWkSwElubmhzQ.dic_To_jsonfile(BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF_SESSION_COOKIES1,BDMYnUAqOoepfFrgjyWkSwElubmhzQ.NF)
  except BDMYnUAqOoepfFrgjyWkSwElubmhVL as exception:
   BDMYnUAqOoepfFrgjyWkSwElubmhLT('pass 1 error')
   BDMYnUAqOoepfFrgjyWkSwElubmhLT(exception)
   return BDMYnUAqOoepfFrgjyWkSwElubmhVQ
  return BDMYnUAqOoepfFrgjyWkSwElubmhLi
# Created by pyminifier (https://github.com/liftoff/pyminifier)
