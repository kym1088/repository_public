__author__="NightRain"
KYnfjovlVBGrptmcwOLaFHEICRQXgz=object
KYnfjovlVBGrptmcwOLaFHEICRQXgy=None
KYnfjovlVBGrptmcwOLaFHEICRQXgu=True
KYnfjovlVBGrptmcwOLaFHEICRQXgU=False
KYnfjovlVBGrptmcwOLaFHEICRQXgx=type
KYnfjovlVBGrptmcwOLaFHEICRQXgi=dict
KYnfjovlVBGrptmcwOLaFHEICRQXgb=open
KYnfjovlVBGrptmcwOLaFHEICRQXgk=len
KYnfjovlVBGrptmcwOLaFHEICRQXgq=Exception
KYnfjovlVBGrptmcwOLaFHEICRQXdD=int
KYnfjovlVBGrptmcwOLaFHEICRQXdJ=range
KYnfjovlVBGrptmcwOLaFHEICRQXdM=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
KYnfjovlVBGrptmcwOLaFHEICRQXDM=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
KYnfjovlVBGrptmcwOLaFHEICRQXDA={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
KYnfjovlVBGrptmcwOLaFHEICRQXDg=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
KYnfjovlVBGrptmcwOLaFHEICRQXDd =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class KYnfjovlVBGrptmcwOLaFHEICRQXDJ(KYnfjovlVBGrptmcwOLaFHEICRQXgz):
 def __init__(KYnfjovlVBGrptmcwOLaFHEICRQXDN,KYnfjovlVBGrptmcwOLaFHEICRQXDS,KYnfjovlVBGrptmcwOLaFHEICRQXDh,KYnfjovlVBGrptmcwOLaFHEICRQXDe):
  KYnfjovlVBGrptmcwOLaFHEICRQXDN._addon_url =KYnfjovlVBGrptmcwOLaFHEICRQXDS
  KYnfjovlVBGrptmcwOLaFHEICRQXDN._addon_handle=KYnfjovlVBGrptmcwOLaFHEICRQXDh
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.main_params =KYnfjovlVBGrptmcwOLaFHEICRQXDe
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj =BDMYnUAqOoepfFrgjyWkSwElubmhzx() 
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_authinfo.json'))
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(KYnfjovlVBGrptmcwOLaFHEICRQXDN,sting):
  try:
   KYnfjovlVBGrptmcwOLaFHEICRQXDW=xbmcgui.Dialog()
   KYnfjovlVBGrptmcwOLaFHEICRQXDW.notification(__addonname__,sting)
  except:
   KYnfjovlVBGrptmcwOLaFHEICRQXgy
 def addon_log(KYnfjovlVBGrptmcwOLaFHEICRQXDN,string):
  try:
   KYnfjovlVBGrptmcwOLaFHEICRQXDP=string.encode('utf-8','ignore')
  except:
   KYnfjovlVBGrptmcwOLaFHEICRQXDP='addonException: addon_log'
  KYnfjovlVBGrptmcwOLaFHEICRQXDT=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,KYnfjovlVBGrptmcwOLaFHEICRQXDP),level=KYnfjovlVBGrptmcwOLaFHEICRQXDT)
 def get_keyboard_input(KYnfjovlVBGrptmcwOLaFHEICRQXDN,KYnfjovlVBGrptmcwOLaFHEICRQXDb):
  KYnfjovlVBGrptmcwOLaFHEICRQXDz=KYnfjovlVBGrptmcwOLaFHEICRQXgy
  kb=xbmc.Keyboard()
  kb.setHeading(KYnfjovlVBGrptmcwOLaFHEICRQXDb)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   KYnfjovlVBGrptmcwOLaFHEICRQXDz=kb.getText()
  return KYnfjovlVBGrptmcwOLaFHEICRQXDz
 def get_settings_menubookmark(KYnfjovlVBGrptmcwOLaFHEICRQXDN):
  KYnfjovlVBGrptmcwOLaFHEICRQXDy=KYnfjovlVBGrptmcwOLaFHEICRQXgu if __addon__.getSetting('menu_bookmark')=='true' else KYnfjovlVBGrptmcwOLaFHEICRQXgU
  return(KYnfjovlVBGrptmcwOLaFHEICRQXDy)
 def get_settings_makebookmark(KYnfjovlVBGrptmcwOLaFHEICRQXDN):
  return KYnfjovlVBGrptmcwOLaFHEICRQXgu if __addon__.getSetting('make_bookmark')=='true' else KYnfjovlVBGrptmcwOLaFHEICRQXgU
 def get_settings_select_info(KYnfjovlVBGrptmcwOLaFHEICRQXDN):
  KYnfjovlVBGrptmcwOLaFHEICRQXDu=[]
  if __addon__.getSetting('netflixyn')=='true':KYnfjovlVBGrptmcwOLaFHEICRQXDu.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':KYnfjovlVBGrptmcwOLaFHEICRQXDu.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':KYnfjovlVBGrptmcwOLaFHEICRQXDu.append('tving')
  if __addon__.getSetting('watchayn')=='true':KYnfjovlVBGrptmcwOLaFHEICRQXDu.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':KYnfjovlVBGrptmcwOLaFHEICRQXDu.append('coupang')
  if __addon__.getSetting('primevyn')=='true':KYnfjovlVBGrptmcwOLaFHEICRQXDu.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':KYnfjovlVBGrptmcwOLaFHEICRQXDu.append('disney')
  return KYnfjovlVBGrptmcwOLaFHEICRQXDu
 def add_dir(KYnfjovlVBGrptmcwOLaFHEICRQXDN,label,sublabel='',img='',infoLabels=KYnfjovlVBGrptmcwOLaFHEICRQXgy,isFolder=KYnfjovlVBGrptmcwOLaFHEICRQXgu,params='',isLink=KYnfjovlVBGrptmcwOLaFHEICRQXgU,ContextMenu=KYnfjovlVBGrptmcwOLaFHEICRQXgy,direct_url=KYnfjovlVBGrptmcwOLaFHEICRQXgy):
  if direct_url:
   KYnfjovlVBGrptmcwOLaFHEICRQXDU=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   KYnfjovlVBGrptmcwOLaFHEICRQXDi=json.dumps(params,separators=(',',':'))
   KYnfjovlVBGrptmcwOLaFHEICRQXDi=base64.standard_b64encode(KYnfjovlVBGrptmcwOLaFHEICRQXDi.encode()).decode('utf-8')
   KYnfjovlVBGrptmcwOLaFHEICRQXDi=KYnfjovlVBGrptmcwOLaFHEICRQXDi.replace('+','%2B')
   KYnfjovlVBGrptmcwOLaFHEICRQXDU='%s?params=%s'%(KYnfjovlVBGrptmcwOLaFHEICRQXDN._addon_url,KYnfjovlVBGrptmcwOLaFHEICRQXDi)
  if sublabel and sublabel!='-':KYnfjovlVBGrptmcwOLaFHEICRQXDb='%s < %s >'%(label,sublabel)
  else: KYnfjovlVBGrptmcwOLaFHEICRQXDb=label
  if not img:img='DefaultFolder.png'
  KYnfjovlVBGrptmcwOLaFHEICRQXDk=xbmcgui.ListItem(KYnfjovlVBGrptmcwOLaFHEICRQXDb)
  if KYnfjovlVBGrptmcwOLaFHEICRQXgx(img)==KYnfjovlVBGrptmcwOLaFHEICRQXgi:
   KYnfjovlVBGrptmcwOLaFHEICRQXDk.setArt(img)
  else:
   KYnfjovlVBGrptmcwOLaFHEICRQXDk.setArt({'thumb':img,'poster':img})
  if infoLabels:KYnfjovlVBGrptmcwOLaFHEICRQXDk.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   KYnfjovlVBGrptmcwOLaFHEICRQXDk.setProperty('IsPlayable','true')
  if ContextMenu:KYnfjovlVBGrptmcwOLaFHEICRQXDk.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(KYnfjovlVBGrptmcwOLaFHEICRQXDN._addon_handle,KYnfjovlVBGrptmcwOLaFHEICRQXDU,KYnfjovlVBGrptmcwOLaFHEICRQXDk,isFolder)
 def Load_Searched_List(KYnfjovlVBGrptmcwOLaFHEICRQXDN):
  try:
   KYnfjovlVBGrptmcwOLaFHEICRQXDq=KYnfjovlVBGrptmcwOLaFHEICRQXDd
   fp=KYnfjovlVBGrptmcwOLaFHEICRQXgb(KYnfjovlVBGrptmcwOLaFHEICRQXDq,'r',-1,'utf-8')
   KYnfjovlVBGrptmcwOLaFHEICRQXJD=fp.readlines()
   fp.close()
  except:
   KYnfjovlVBGrptmcwOLaFHEICRQXJD=[]
  return KYnfjovlVBGrptmcwOLaFHEICRQXJD
 def Save_Searched_List(KYnfjovlVBGrptmcwOLaFHEICRQXDN,KYnfjovlVBGrptmcwOLaFHEICRQXMU):
  try:
   KYnfjovlVBGrptmcwOLaFHEICRQXDq=KYnfjovlVBGrptmcwOLaFHEICRQXDd
   KYnfjovlVBGrptmcwOLaFHEICRQXJM=KYnfjovlVBGrptmcwOLaFHEICRQXDN.Load_Searched_List() 
   KYnfjovlVBGrptmcwOLaFHEICRQXJA={'skey':KYnfjovlVBGrptmcwOLaFHEICRQXMU.strip()}
   fp=KYnfjovlVBGrptmcwOLaFHEICRQXgb(KYnfjovlVBGrptmcwOLaFHEICRQXDq,'w',-1,'utf-8')
   KYnfjovlVBGrptmcwOLaFHEICRQXJg=urllib.parse.urlencode(KYnfjovlVBGrptmcwOLaFHEICRQXJA)
   KYnfjovlVBGrptmcwOLaFHEICRQXJg=KYnfjovlVBGrptmcwOLaFHEICRQXJg+'\n'
   fp.write(KYnfjovlVBGrptmcwOLaFHEICRQXJg)
   KYnfjovlVBGrptmcwOLaFHEICRQXJd=0
   for KYnfjovlVBGrptmcwOLaFHEICRQXJN in KYnfjovlVBGrptmcwOLaFHEICRQXJM:
    KYnfjovlVBGrptmcwOLaFHEICRQXJS=KYnfjovlVBGrptmcwOLaFHEICRQXgi(urllib.parse.parse_qsl(KYnfjovlVBGrptmcwOLaFHEICRQXJN))
    KYnfjovlVBGrptmcwOLaFHEICRQXJh=KYnfjovlVBGrptmcwOLaFHEICRQXJA.get('skey').strip()
    KYnfjovlVBGrptmcwOLaFHEICRQXJe=KYnfjovlVBGrptmcwOLaFHEICRQXJS.get('skey').strip()
    if KYnfjovlVBGrptmcwOLaFHEICRQXJh!=KYnfjovlVBGrptmcwOLaFHEICRQXJe:
     fp.write(KYnfjovlVBGrptmcwOLaFHEICRQXJN)
     KYnfjovlVBGrptmcwOLaFHEICRQXJd+=1
     if KYnfjovlVBGrptmcwOLaFHEICRQXJd>=50:break
   fp.close()
  except:
   KYnfjovlVBGrptmcwOLaFHEICRQXgy
 def dp_Search_History(KYnfjovlVBGrptmcwOLaFHEICRQXDN,args):
  KYnfjovlVBGrptmcwOLaFHEICRQXJs=KYnfjovlVBGrptmcwOLaFHEICRQXDN.Load_Searched_List()
  for KYnfjovlVBGrptmcwOLaFHEICRQXJW in KYnfjovlVBGrptmcwOLaFHEICRQXJs:
   KYnfjovlVBGrptmcwOLaFHEICRQXJP=KYnfjovlVBGrptmcwOLaFHEICRQXgi(urllib.parse.parse_qsl(KYnfjovlVBGrptmcwOLaFHEICRQXJW))
   KYnfjovlVBGrptmcwOLaFHEICRQXJT=KYnfjovlVBGrptmcwOLaFHEICRQXJP.get('skey').strip()
   KYnfjovlVBGrptmcwOLaFHEICRQXDx={'mode':'TOTAL_SEARCH','search_key':KYnfjovlVBGrptmcwOLaFHEICRQXJT,}
   KYnfjovlVBGrptmcwOLaFHEICRQXJz={'mode':'HISTORY_REMOVE','skey':KYnfjovlVBGrptmcwOLaFHEICRQXJT,'delmode':'ONE',}
   KYnfjovlVBGrptmcwOLaFHEICRQXJy=urllib.parse.urlencode(KYnfjovlVBGrptmcwOLaFHEICRQXJz)
   KYnfjovlVBGrptmcwOLaFHEICRQXJu=[('선택된 검색어 ( %s ) 삭제'%(KYnfjovlVBGrptmcwOLaFHEICRQXJT),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(KYnfjovlVBGrptmcwOLaFHEICRQXJy))]
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.add_dir(KYnfjovlVBGrptmcwOLaFHEICRQXJT,sublabel='',img=KYnfjovlVBGrptmcwOLaFHEICRQXgy,infoLabels=KYnfjovlVBGrptmcwOLaFHEICRQXgy,isFolder=KYnfjovlVBGrptmcwOLaFHEICRQXgu,params=KYnfjovlVBGrptmcwOLaFHEICRQXDx,ContextMenu=KYnfjovlVBGrptmcwOLaFHEICRQXJu)
  KYnfjovlVBGrptmcwOLaFHEICRQXJx={'plot':'검색목록 전체를 삭제합니다.'}
  KYnfjovlVBGrptmcwOLaFHEICRQXDb='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  KYnfjovlVBGrptmcwOLaFHEICRQXDx={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  KYnfjovlVBGrptmcwOLaFHEICRQXJi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.add_dir(KYnfjovlVBGrptmcwOLaFHEICRQXDb,sublabel='',img=KYnfjovlVBGrptmcwOLaFHEICRQXJi,infoLabels=KYnfjovlVBGrptmcwOLaFHEICRQXJx,isFolder=KYnfjovlVBGrptmcwOLaFHEICRQXgU,params=KYnfjovlVBGrptmcwOLaFHEICRQXDx,isLink=KYnfjovlVBGrptmcwOLaFHEICRQXgu)
  xbmcplugin.endOfDirectory(KYnfjovlVBGrptmcwOLaFHEICRQXDN._addon_handle,cacheToDisc=KYnfjovlVBGrptmcwOLaFHEICRQXgU)
 def Delete_History_List(KYnfjovlVBGrptmcwOLaFHEICRQXDN,KYnfjovlVBGrptmcwOLaFHEICRQXJT,KYnfjovlVBGrptmcwOLaFHEICRQXJq):
  if KYnfjovlVBGrptmcwOLaFHEICRQXJq=='ALL':
   try:
    KYnfjovlVBGrptmcwOLaFHEICRQXDq=KYnfjovlVBGrptmcwOLaFHEICRQXDd
    fp=KYnfjovlVBGrptmcwOLaFHEICRQXgb(KYnfjovlVBGrptmcwOLaFHEICRQXDq,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    KYnfjovlVBGrptmcwOLaFHEICRQXgy
  else:
   try:
    KYnfjovlVBGrptmcwOLaFHEICRQXDq=KYnfjovlVBGrptmcwOLaFHEICRQXDd
    KYnfjovlVBGrptmcwOLaFHEICRQXJM=KYnfjovlVBGrptmcwOLaFHEICRQXDN.Load_Searched_List() 
    fp=KYnfjovlVBGrptmcwOLaFHEICRQXgb(KYnfjovlVBGrptmcwOLaFHEICRQXDq,'w',-1,'utf-8')
    for KYnfjovlVBGrptmcwOLaFHEICRQXJN in KYnfjovlVBGrptmcwOLaFHEICRQXJM:
     KYnfjovlVBGrptmcwOLaFHEICRQXJS=KYnfjovlVBGrptmcwOLaFHEICRQXgi(urllib.parse.parse_qsl(KYnfjovlVBGrptmcwOLaFHEICRQXJN))
     KYnfjovlVBGrptmcwOLaFHEICRQXJk=KYnfjovlVBGrptmcwOLaFHEICRQXJS.get('skey').strip()
     if KYnfjovlVBGrptmcwOLaFHEICRQXJT!=KYnfjovlVBGrptmcwOLaFHEICRQXJk:
      fp.write(KYnfjovlVBGrptmcwOLaFHEICRQXJN)
    fp.close()
   except:
    KYnfjovlVBGrptmcwOLaFHEICRQXgy
 def dp_History_Delete(KYnfjovlVBGrptmcwOLaFHEICRQXDN,args):
  KYnfjovlVBGrptmcwOLaFHEICRQXJT =args.get('skey') 
  KYnfjovlVBGrptmcwOLaFHEICRQXJq=args.get('delmode')
  KYnfjovlVBGrptmcwOLaFHEICRQXDW=xbmcgui.Dialog()
  if KYnfjovlVBGrptmcwOLaFHEICRQXJq=='ALL':
   KYnfjovlVBGrptmcwOLaFHEICRQXMD=KYnfjovlVBGrptmcwOLaFHEICRQXDW.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   KYnfjovlVBGrptmcwOLaFHEICRQXMD=KYnfjovlVBGrptmcwOLaFHEICRQXDW.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if KYnfjovlVBGrptmcwOLaFHEICRQXMD==KYnfjovlVBGrptmcwOLaFHEICRQXgU:sys.exit()
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.Delete_History_List(KYnfjovlVBGrptmcwOLaFHEICRQXJT,KYnfjovlVBGrptmcwOLaFHEICRQXJq)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(KYnfjovlVBGrptmcwOLaFHEICRQXDN):
  KYnfjovlVBGrptmcwOLaFHEICRQXDy=KYnfjovlVBGrptmcwOLaFHEICRQXDN.get_settings_menubookmark()
  for KYnfjovlVBGrptmcwOLaFHEICRQXMJ in KYnfjovlVBGrptmcwOLaFHEICRQXDM:
   KYnfjovlVBGrptmcwOLaFHEICRQXDb=KYnfjovlVBGrptmcwOLaFHEICRQXMJ.get('title')
   KYnfjovlVBGrptmcwOLaFHEICRQXJi=''
   if KYnfjovlVBGrptmcwOLaFHEICRQXMJ.get('mode')=='MENU_BOOKMARK' and KYnfjovlVBGrptmcwOLaFHEICRQXDy==KYnfjovlVBGrptmcwOLaFHEICRQXgU:continue
   KYnfjovlVBGrptmcwOLaFHEICRQXDx={'mode':KYnfjovlVBGrptmcwOLaFHEICRQXMJ.get('mode')}
   if KYnfjovlVBGrptmcwOLaFHEICRQXMJ.get('mode')in['XXX','MENU_BOOKMARK']:
    KYnfjovlVBGrptmcwOLaFHEICRQXMA=KYnfjovlVBGrptmcwOLaFHEICRQXgU
    KYnfjovlVBGrptmcwOLaFHEICRQXMg =KYnfjovlVBGrptmcwOLaFHEICRQXgu
   else:
    KYnfjovlVBGrptmcwOLaFHEICRQXMA=KYnfjovlVBGrptmcwOLaFHEICRQXgu
    KYnfjovlVBGrptmcwOLaFHEICRQXMg =KYnfjovlVBGrptmcwOLaFHEICRQXgU
   if 'icon' in KYnfjovlVBGrptmcwOLaFHEICRQXMJ:KYnfjovlVBGrptmcwOLaFHEICRQXJi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',KYnfjovlVBGrptmcwOLaFHEICRQXMJ.get('icon')) 
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.add_dir(KYnfjovlVBGrptmcwOLaFHEICRQXDb,sublabel='',img=KYnfjovlVBGrptmcwOLaFHEICRQXJi,infoLabels=KYnfjovlVBGrptmcwOLaFHEICRQXgy,isFolder=KYnfjovlVBGrptmcwOLaFHEICRQXMA,params=KYnfjovlVBGrptmcwOLaFHEICRQXDx,isLink=KYnfjovlVBGrptmcwOLaFHEICRQXMg)
  xbmcplugin.endOfDirectory(KYnfjovlVBGrptmcwOLaFHEICRQXDN._addon_handle,cacheToDisc=KYnfjovlVBGrptmcwOLaFHEICRQXgU)
 def option_check(KYnfjovlVBGrptmcwOLaFHEICRQXDN):
  KYnfjovlVBGrptmcwOLaFHEICRQXDu=KYnfjovlVBGrptmcwOLaFHEICRQXDN.get_settings_select_info()
  if KYnfjovlVBGrptmcwOLaFHEICRQXgk(KYnfjovlVBGrptmcwOLaFHEICRQXDu)==0:
   KYnfjovlVBGrptmcwOLaFHEICRQXDW=xbmcgui.Dialog()
   KYnfjovlVBGrptmcwOLaFHEICRQXMD=KYnfjovlVBGrptmcwOLaFHEICRQXDW.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if KYnfjovlVBGrptmcwOLaFHEICRQXMD==KYnfjovlVBGrptmcwOLaFHEICRQXgu:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in KYnfjovlVBGrptmcwOLaFHEICRQXDu:
   if KYnfjovlVBGrptmcwOLaFHEICRQXDN.NF_cookiefile_check()==KYnfjovlVBGrptmcwOLaFHEICRQXgU:
    KYnfjovlVBGrptmcwOLaFHEICRQXDN.NF_login(showMessage=KYnfjovlVBGrptmcwOLaFHEICRQXgu)
  if 'disney' in KYnfjovlVBGrptmcwOLaFHEICRQXDu:
   if KYnfjovlVBGrptmcwOLaFHEICRQXDN.DZ_cookiefile_check()==KYnfjovlVBGrptmcwOLaFHEICRQXgU:
    KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.DZ={}
 def DZ_cookiefile_check(KYnfjovlVBGrptmcwOLaFHEICRQXDN):
  KYnfjovlVBGrptmcwOLaFHEICRQXMN={}
  try: 
   fp=KYnfjovlVBGrptmcwOLaFHEICRQXgb(KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   KYnfjovlVBGrptmcwOLaFHEICRQXMN= json.load(fp)
   fp.close()
  except KYnfjovlVBGrptmcwOLaFHEICRQXgq as exception:
   return KYnfjovlVBGrptmcwOLaFHEICRQXgU
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.DZ=KYnfjovlVBGrptmcwOLaFHEICRQXMN
  if KYnfjovlVBGrptmcwOLaFHEICRQXdD(time.time())>KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.DZ['account']['token_limit']:
   if KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.DZ_ReToken()==KYnfjovlVBGrptmcwOLaFHEICRQXgU:
    KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_noti(__language__(30920).encode('utf-8'))
    return KYnfjovlVBGrptmcwOLaFHEICRQXgU
   try: 
    fp=KYnfjovlVBGrptmcwOLaFHEICRQXgb(KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.DZ,fp,indent=4,ensure_ascii=KYnfjovlVBGrptmcwOLaFHEICRQXgU)
    fp.close()
   except KYnfjovlVBGrptmcwOLaFHEICRQXgq as exception:
    return KYnfjovlVBGrptmcwOLaFHEICRQXgU
  return KYnfjovlVBGrptmcwOLaFHEICRQXgu
 def NF_cookiefile_check(KYnfjovlVBGrptmcwOLaFHEICRQXDN):
  KYnfjovlVBGrptmcwOLaFHEICRQXMN={}
  try: 
   fp=KYnfjovlVBGrptmcwOLaFHEICRQXgb(KYnfjovlVBGrptmcwOLaFHEICRQXDg,'r',-1,'utf-8')
   KYnfjovlVBGrptmcwOLaFHEICRQXMN= json.load(fp)
   fp.close()
  except KYnfjovlVBGrptmcwOLaFHEICRQXgq as exception:
   return KYnfjovlVBGrptmcwOLaFHEICRQXgU
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF=KYnfjovlVBGrptmcwOLaFHEICRQXMN
  KYnfjovlVBGrptmcwOLaFHEICRQXMh =KYnfjovlVBGrptmcwOLaFHEICRQXdD(KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  KYnfjovlVBGrptmcwOLaFHEICRQXMe=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF['SESSION']['limitdate']
  KYnfjovlVBGrptmcwOLaFHEICRQXMs =KYnfjovlVBGrptmcwOLaFHEICRQXdD(re.sub('-','',KYnfjovlVBGrptmcwOLaFHEICRQXMe))
  if KYnfjovlVBGrptmcwOLaFHEICRQXMs<KYnfjovlVBGrptmcwOLaFHEICRQXMh:
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Init_NF_Total()
   if KYnfjovlVBGrptmcwOLaFHEICRQXDN.NF_login(showMessage=KYnfjovlVBGrptmcwOLaFHEICRQXgU)==KYnfjovlVBGrptmcwOLaFHEICRQXgU:
    return KYnfjovlVBGrptmcwOLaFHEICRQXgU
  KYnfjovlVBGrptmcwOLaFHEICRQXMW=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF_CookieFile_Load(KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF_ORIGINAL_COOKIE)
  if(KYnfjovlVBGrptmcwOLaFHEICRQXMW['NetflixId']!=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF['COOKIES']['NetflixId']or KYnfjovlVBGrptmcwOLaFHEICRQXMW['SecureNetflixId']!=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF['COOKIES']['SecureNetflixId']or KYnfjovlVBGrptmcwOLaFHEICRQXMW['flwssn']!=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF['COOKIES']['flwssn']or KYnfjovlVBGrptmcwOLaFHEICRQXMW['memclid']!=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF['COOKIES']['memclid']or KYnfjovlVBGrptmcwOLaFHEICRQXMW['nfvdid']!=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF['COOKIES']['nfvdid']):
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Init_NF_Total()
   if KYnfjovlVBGrptmcwOLaFHEICRQXDN.NF_login(showMessage=KYnfjovlVBGrptmcwOLaFHEICRQXgU)==KYnfjovlVBGrptmcwOLaFHEICRQXgU:
    return KYnfjovlVBGrptmcwOLaFHEICRQXgU
  return KYnfjovlVBGrptmcwOLaFHEICRQXgu
 def NF_login(KYnfjovlVBGrptmcwOLaFHEICRQXDN,showMessage=KYnfjovlVBGrptmcwOLaFHEICRQXgu):
  if showMessage:
   KYnfjovlVBGrptmcwOLaFHEICRQXDW=xbmcgui.Dialog()
   KYnfjovlVBGrptmcwOLaFHEICRQXMD=KYnfjovlVBGrptmcwOLaFHEICRQXDW.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if KYnfjovlVBGrptmcwOLaFHEICRQXMD==KYnfjovlVBGrptmcwOLaFHEICRQXgU:
    return KYnfjovlVBGrptmcwOLaFHEICRQXgU 
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF['COOKIES']=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF_CookieFile_Load(KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF_ORIGINAL_COOKIE)
  KYnfjovlVBGrptmcwOLaFHEICRQXMP=KYnfjovlVBGrptmcwOLaFHEICRQXgU if KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF['COOKIES']=={}else KYnfjovlVBGrptmcwOLaFHEICRQXgu
  if KYnfjovlVBGrptmcwOLaFHEICRQXMP:
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_log('pass1 ok!')
  else:
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_log('pass1 error!')
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_noti(__language__(30905).encode('utf-8'))
   return KYnfjovlVBGrptmcwOLaFHEICRQXgU 
  KYnfjovlVBGrptmcwOLaFHEICRQXMP=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF_Get_BaseSession()
  if KYnfjovlVBGrptmcwOLaFHEICRQXMP:
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_log('pass2 ok!')
  else:
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_log('pass2 error!')
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_noti(__language__(30905).encode('utf-8'))
   return KYnfjovlVBGrptmcwOLaFHEICRQXgU 
  KYnfjovlVBGrptmcwOLaFHEICRQXMT =KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Now_Datetime()
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF['SESSION']['limitdate']=KYnfjovlVBGrptmcwOLaFHEICRQXMT.strftime('%Y-%m-%d')
  try: 
   fp=KYnfjovlVBGrptmcwOLaFHEICRQXgb(KYnfjovlVBGrptmcwOLaFHEICRQXDg,'w',-1,'utf-8')
   json.dump(KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF,fp,indent=4,ensure_ascii=KYnfjovlVBGrptmcwOLaFHEICRQXgU)
   fp.close()
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_log('pass3 save ok!')
  except KYnfjovlVBGrptmcwOLaFHEICRQXgq as exception:
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_log('pass3 save error!')
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_noti(__language__(30905).encode('utf-8'))
   return KYnfjovlVBGrptmcwOLaFHEICRQXgU
  if showMessage:KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_noti(__language__(30904).encode('utf-8'))
  return KYnfjovlVBGrptmcwOLaFHEICRQXgu
 def NF_logout(KYnfjovlVBGrptmcwOLaFHEICRQXDN):
  KYnfjovlVBGrptmcwOLaFHEICRQXDW=xbmcgui.Dialog()
  KYnfjovlVBGrptmcwOLaFHEICRQXMD=KYnfjovlVBGrptmcwOLaFHEICRQXDW.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if KYnfjovlVBGrptmcwOLaFHEICRQXMD==KYnfjovlVBGrptmcwOLaFHEICRQXgU:return 
  if os.path.isfile(KYnfjovlVBGrptmcwOLaFHEICRQXDg):os.remove(KYnfjovlVBGrptmcwOLaFHEICRQXDg)
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(KYnfjovlVBGrptmcwOLaFHEICRQXDN,KYnfjovlVBGrptmcwOLaFHEICRQXMx):
  KYnfjovlVBGrptmcwOLaFHEICRQXMz=''
  KYnfjovlVBGrptmcwOLaFHEICRQXMy=7
  try:
   for i in KYnfjovlVBGrptmcwOLaFHEICRQXdJ(KYnfjovlVBGrptmcwOLaFHEICRQXgk(KYnfjovlVBGrptmcwOLaFHEICRQXMx)):
    if i>=KYnfjovlVBGrptmcwOLaFHEICRQXMy:
     KYnfjovlVBGrptmcwOLaFHEICRQXMz=KYnfjovlVBGrptmcwOLaFHEICRQXMz+'...'
     break
    KYnfjovlVBGrptmcwOLaFHEICRQXMz=KYnfjovlVBGrptmcwOLaFHEICRQXMz+KYnfjovlVBGrptmcwOLaFHEICRQXMx[i]['title']+'\n'
  except:
   return ''
  return KYnfjovlVBGrptmcwOLaFHEICRQXMz
 def dp_Search_Group(KYnfjovlVBGrptmcwOLaFHEICRQXDN,args):
  KYnfjovlVBGrptmcwOLaFHEICRQXDu =KYnfjovlVBGrptmcwOLaFHEICRQXDN.get_settings_select_info()
  KYnfjovlVBGrptmcwOLaFHEICRQXMu=[]
  if 'search_key' in args:
   KYnfjovlVBGrptmcwOLaFHEICRQXMU=args.get('search_key')
  else:
   KYnfjovlVBGrptmcwOLaFHEICRQXMU=KYnfjovlVBGrptmcwOLaFHEICRQXDN.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not KYnfjovlVBGrptmcwOLaFHEICRQXMU:
    return
  if 'wavve' in KYnfjovlVBGrptmcwOLaFHEICRQXDu:
   (KYnfjovlVBGrptmcwOLaFHEICRQXMx,KYnfjovlVBGrptmcwOLaFHEICRQXMi)=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Search_Wavve(KYnfjovlVBGrptmcwOLaFHEICRQXMU,'TVSHOW',1)
   if KYnfjovlVBGrptmcwOLaFHEICRQXgk(KYnfjovlVBGrptmcwOLaFHEICRQXMx)>0:
    KYnfjovlVBGrptmcwOLaFHEICRQXMb={'sType':'wavve_tvshow','sList':KYnfjovlVBGrptmcwOLaFHEICRQXDN.MakeText_FreeList(KYnfjovlVBGrptmcwOLaFHEICRQXMx),}
    KYnfjovlVBGrptmcwOLaFHEICRQXMu.append(KYnfjovlVBGrptmcwOLaFHEICRQXMb)
   (KYnfjovlVBGrptmcwOLaFHEICRQXMx,KYnfjovlVBGrptmcwOLaFHEICRQXMi)=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Search_Wavve(KYnfjovlVBGrptmcwOLaFHEICRQXMU,'MOVIE',1)
   if KYnfjovlVBGrptmcwOLaFHEICRQXgk(KYnfjovlVBGrptmcwOLaFHEICRQXMx)>0:
    KYnfjovlVBGrptmcwOLaFHEICRQXMb={'sType':'wavve_movie','sList':KYnfjovlVBGrptmcwOLaFHEICRQXDN.MakeText_FreeList(KYnfjovlVBGrptmcwOLaFHEICRQXMx),}
    KYnfjovlVBGrptmcwOLaFHEICRQXMu.append(KYnfjovlVBGrptmcwOLaFHEICRQXMb)
  if 'tving' in KYnfjovlVBGrptmcwOLaFHEICRQXDu:
   (KYnfjovlVBGrptmcwOLaFHEICRQXMx,KYnfjovlVBGrptmcwOLaFHEICRQXMi)=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Search_Tving(KYnfjovlVBGrptmcwOLaFHEICRQXMU,'TVSHOW',1)
   if KYnfjovlVBGrptmcwOLaFHEICRQXgk(KYnfjovlVBGrptmcwOLaFHEICRQXMx)>0:
    KYnfjovlVBGrptmcwOLaFHEICRQXMb={'sType':'tving_tvshow','sList':KYnfjovlVBGrptmcwOLaFHEICRQXDN.MakeText_FreeList(KYnfjovlVBGrptmcwOLaFHEICRQXMx),}
    KYnfjovlVBGrptmcwOLaFHEICRQXMu.append(KYnfjovlVBGrptmcwOLaFHEICRQXMb)
   (KYnfjovlVBGrptmcwOLaFHEICRQXMx,KYnfjovlVBGrptmcwOLaFHEICRQXMi)=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Search_Tving(KYnfjovlVBGrptmcwOLaFHEICRQXMU,'MOVIE',1)
   if KYnfjovlVBGrptmcwOLaFHEICRQXgk(KYnfjovlVBGrptmcwOLaFHEICRQXMx)>0:
    KYnfjovlVBGrptmcwOLaFHEICRQXMb={'sType':'tving_movie','sList':KYnfjovlVBGrptmcwOLaFHEICRQXDN.MakeText_FreeList(KYnfjovlVBGrptmcwOLaFHEICRQXMx),}
    KYnfjovlVBGrptmcwOLaFHEICRQXMu.append(KYnfjovlVBGrptmcwOLaFHEICRQXMb)
  if 'watcha' in KYnfjovlVBGrptmcwOLaFHEICRQXDu:
   (KYnfjovlVBGrptmcwOLaFHEICRQXMx,KYnfjovlVBGrptmcwOLaFHEICRQXMi)=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Search_Watcha(KYnfjovlVBGrptmcwOLaFHEICRQXMU,1)
   if KYnfjovlVBGrptmcwOLaFHEICRQXgk(KYnfjovlVBGrptmcwOLaFHEICRQXMx)>0:
    KYnfjovlVBGrptmcwOLaFHEICRQXMb={'sType':'watcha_list','sList':KYnfjovlVBGrptmcwOLaFHEICRQXDN.MakeText_FreeList(KYnfjovlVBGrptmcwOLaFHEICRQXMx),}
    KYnfjovlVBGrptmcwOLaFHEICRQXMu.append(KYnfjovlVBGrptmcwOLaFHEICRQXMb)
  if 'coupang' in KYnfjovlVBGrptmcwOLaFHEICRQXDu:
   (KYnfjovlVBGrptmcwOLaFHEICRQXMx,KYnfjovlVBGrptmcwOLaFHEICRQXMi)=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Search_Coupang(KYnfjovlVBGrptmcwOLaFHEICRQXMU,1)
   if KYnfjovlVBGrptmcwOLaFHEICRQXgk(KYnfjovlVBGrptmcwOLaFHEICRQXMx)>0:
    KYnfjovlVBGrptmcwOLaFHEICRQXMb={'sType':'coupang_list','sList':KYnfjovlVBGrptmcwOLaFHEICRQXDN.MakeText_FreeList(KYnfjovlVBGrptmcwOLaFHEICRQXMx),}
    KYnfjovlVBGrptmcwOLaFHEICRQXMu.append(KYnfjovlVBGrptmcwOLaFHEICRQXMb)
  if 'netflix' in KYnfjovlVBGrptmcwOLaFHEICRQXDu:
   try:
    (KYnfjovlVBGrptmcwOLaFHEICRQXMx,KYnfjovlVBGrptmcwOLaFHEICRQXMi,KYnfjovlVBGrptmcwOLaFHEICRQXMk)=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Search_Netflix(KYnfjovlVBGrptmcwOLaFHEICRQXMU,1)
   except:
    KYnfjovlVBGrptmcwOLaFHEICRQXMx=[]
    KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_noti(__language__(30919).encode('utf8'))
   if KYnfjovlVBGrptmcwOLaFHEICRQXgk(KYnfjovlVBGrptmcwOLaFHEICRQXMx)>0:
    KYnfjovlVBGrptmcwOLaFHEICRQXMb={'sType':'netflix_list','sList':KYnfjovlVBGrptmcwOLaFHEICRQXDN.MakeText_FreeList(KYnfjovlVBGrptmcwOLaFHEICRQXMx),}
    KYnfjovlVBGrptmcwOLaFHEICRQXMu.append(KYnfjovlVBGrptmcwOLaFHEICRQXMb)
  if 'amazon' in KYnfjovlVBGrptmcwOLaFHEICRQXDu:
   (KYnfjovlVBGrptmcwOLaFHEICRQXMx)=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Search_Primev(KYnfjovlVBGrptmcwOLaFHEICRQXMU)
   if KYnfjovlVBGrptmcwOLaFHEICRQXgk(KYnfjovlVBGrptmcwOLaFHEICRQXMx)>0:
    KYnfjovlVBGrptmcwOLaFHEICRQXMb={'sType':'primev_list','sList':KYnfjovlVBGrptmcwOLaFHEICRQXDN.MakeText_FreeList(KYnfjovlVBGrptmcwOLaFHEICRQXMx),}
    KYnfjovlVBGrptmcwOLaFHEICRQXMu.append(KYnfjovlVBGrptmcwOLaFHEICRQXMb)
  if 'disney' in KYnfjovlVBGrptmcwOLaFHEICRQXDu:
   try:
    (KYnfjovlVBGrptmcwOLaFHEICRQXMx)=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Search_Disney(KYnfjovlVBGrptmcwOLaFHEICRQXMU)
   except:
    KYnfjovlVBGrptmcwOLaFHEICRQXMx=[]
    KYnfjovlVBGrptmcwOLaFHEICRQXDN.addon_noti(__language__(30921).encode('utf8'))
   if KYnfjovlVBGrptmcwOLaFHEICRQXgk(KYnfjovlVBGrptmcwOLaFHEICRQXMx)>0:
    KYnfjovlVBGrptmcwOLaFHEICRQXMb={'sType':'disney_list','sList':KYnfjovlVBGrptmcwOLaFHEICRQXDN.MakeText_FreeList(KYnfjovlVBGrptmcwOLaFHEICRQXMx),}
    KYnfjovlVBGrptmcwOLaFHEICRQXMu.append(KYnfjovlVBGrptmcwOLaFHEICRQXMb)
  for KYnfjovlVBGrptmcwOLaFHEICRQXMq in KYnfjovlVBGrptmcwOLaFHEICRQXMu:
   KYnfjovlVBGrptmcwOLaFHEICRQXAD=KYnfjovlVBGrptmcwOLaFHEICRQXDA[KYnfjovlVBGrptmcwOLaFHEICRQXMq.get('sType')]
   KYnfjovlVBGrptmcwOLaFHEICRQXAJ={'plot':'검색어 : '+KYnfjovlVBGrptmcwOLaFHEICRQXMU+'\n\n'+KYnfjovlVBGrptmcwOLaFHEICRQXMq.get('sList')}
   KYnfjovlVBGrptmcwOLaFHEICRQXDb=KYnfjovlVBGrptmcwOLaFHEICRQXAD.get('title')
   KYnfjovlVBGrptmcwOLaFHEICRQXDx={'mode':KYnfjovlVBGrptmcwOLaFHEICRQXAD.get('mode'),'ott':KYnfjovlVBGrptmcwOLaFHEICRQXAD.get('ott'),'vidtype':KYnfjovlVBGrptmcwOLaFHEICRQXAD.get('vidtype'),'search_key':KYnfjovlVBGrptmcwOLaFHEICRQXMU}
   if KYnfjovlVBGrptmcwOLaFHEICRQXAD.get('ott')=='netflix':
    KYnfjovlVBGrptmcwOLaFHEICRQXAM=''
    KYnfjovlVBGrptmcwOLaFHEICRQXDx['page'] ='1'
    KYnfjovlVBGrptmcwOLaFHEICRQXDx['byReference']='-'
   else:
    KYnfjovlVBGrptmcwOLaFHEICRQXAM=KYnfjovlVBGrptmcwOLaFHEICRQXDN.make_Hyper_Link(KYnfjovlVBGrptmcwOLaFHEICRQXDx)
   KYnfjovlVBGrptmcwOLaFHEICRQXJi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',KYnfjovlVBGrptmcwOLaFHEICRQXAD.get('icon'))
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.add_dir(KYnfjovlVBGrptmcwOLaFHEICRQXDb,sublabel='',img=KYnfjovlVBGrptmcwOLaFHEICRQXJi,infoLabels=KYnfjovlVBGrptmcwOLaFHEICRQXAJ,isFolder=KYnfjovlVBGrptmcwOLaFHEICRQXgu,params=KYnfjovlVBGrptmcwOLaFHEICRQXDx,isLink=KYnfjovlVBGrptmcwOLaFHEICRQXgU,direct_url=KYnfjovlVBGrptmcwOLaFHEICRQXAM)
  xbmcplugin.endOfDirectory(KYnfjovlVBGrptmcwOLaFHEICRQXDN._addon_handle)
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.Save_Searched_List(KYnfjovlVBGrptmcwOLaFHEICRQXMU)
 def make_Hyper_Link(KYnfjovlVBGrptmcwOLaFHEICRQXDN,args):
  KYnfjovlVBGrptmcwOLaFHEICRQXAg =args.get('ott')
  KYnfjovlVBGrptmcwOLaFHEICRQXAd =args.get('vidtype')
  KYnfjovlVBGrptmcwOLaFHEICRQXMU=args.get('search_key')
  KYnfjovlVBGrptmcwOLaFHEICRQXAM='-'
  if KYnfjovlVBGrptmcwOLaFHEICRQXAg=='wavve':
   KYnfjovlVBGrptmcwOLaFHEICRQXAN={'mode':'LOCAL_SEARCH','sType':'movie' if KYnfjovlVBGrptmcwOLaFHEICRQXAd=='MOVIE' else 'vod','search_key':KYnfjovlVBGrptmcwOLaFHEICRQXMU,'page':'1',}
   KYnfjovlVBGrptmcwOLaFHEICRQXAS=urllib.parse.urlencode(KYnfjovlVBGrptmcwOLaFHEICRQXAN)
   KYnfjovlVBGrptmcwOLaFHEICRQXAM='plugin://plugin.video.wavvem/?'
   KYnfjovlVBGrptmcwOLaFHEICRQXAM+=KYnfjovlVBGrptmcwOLaFHEICRQXAS
  elif KYnfjovlVBGrptmcwOLaFHEICRQXAg=='tving':
   KYnfjovlVBGrptmcwOLaFHEICRQXAN={'mode':'LOCAL_SEARCH','stype':'movie' if KYnfjovlVBGrptmcwOLaFHEICRQXAd=='MOVIE' else 'vod','search_key':KYnfjovlVBGrptmcwOLaFHEICRQXMU,'page':'1',}
   KYnfjovlVBGrptmcwOLaFHEICRQXAS=urllib.parse.urlencode(KYnfjovlVBGrptmcwOLaFHEICRQXAN)
   KYnfjovlVBGrptmcwOLaFHEICRQXAM='plugin://plugin.video.tvingm/?'
   KYnfjovlVBGrptmcwOLaFHEICRQXAM+=KYnfjovlVBGrptmcwOLaFHEICRQXAS
  elif KYnfjovlVBGrptmcwOLaFHEICRQXAg=='watcha':
   KYnfjovlVBGrptmcwOLaFHEICRQXAN={'mode':'LOCAL_SEARCH','search_key':KYnfjovlVBGrptmcwOLaFHEICRQXMU,'page':'1',}
   KYnfjovlVBGrptmcwOLaFHEICRQXAS=urllib.parse.urlencode(KYnfjovlVBGrptmcwOLaFHEICRQXAN)
   KYnfjovlVBGrptmcwOLaFHEICRQXAM='plugin://plugin.video.watcham/?'
   KYnfjovlVBGrptmcwOLaFHEICRQXAM+=KYnfjovlVBGrptmcwOLaFHEICRQXAS
  elif KYnfjovlVBGrptmcwOLaFHEICRQXAg=='coupang':
   KYnfjovlVBGrptmcwOLaFHEICRQXAN={'mode':'LOCAL_SEARCH','search_key':KYnfjovlVBGrptmcwOLaFHEICRQXMU,'page':'1',}
   KYnfjovlVBGrptmcwOLaFHEICRQXAS=urllib.parse.urlencode(KYnfjovlVBGrptmcwOLaFHEICRQXAN)
   KYnfjovlVBGrptmcwOLaFHEICRQXAM='plugin://plugin.video.coupangm/?'
   KYnfjovlVBGrptmcwOLaFHEICRQXAM+=KYnfjovlVBGrptmcwOLaFHEICRQXAS
  elif KYnfjovlVBGrptmcwOLaFHEICRQXAg=='netflix':
   KYnfjovlVBGrptmcwOLaFHEICRQXAh=args.get('videoid')
   KYnfjovlVBGrptmcwOLaFHEICRQXAe=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.NF['SESSION']['nowGuid']
   if KYnfjovlVBGrptmcwOLaFHEICRQXAd=='TVSHOW':
    KYnfjovlVBGrptmcwOLaFHEICRQXAM='plugin://plugin.video.netflix/directory/show/%s/'%(KYnfjovlVBGrptmcwOLaFHEICRQXAh)
   else:
    KYnfjovlVBGrptmcwOLaFHEICRQXAM='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(KYnfjovlVBGrptmcwOLaFHEICRQXAh,KYnfjovlVBGrptmcwOLaFHEICRQXAe)
  elif KYnfjovlVBGrptmcwOLaFHEICRQXAg=='amazon':
   KYnfjovlVBGrptmcwOLaFHEICRQXAN={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':KYnfjovlVBGrptmcwOLaFHEICRQXMU,}}
   KYnfjovlVBGrptmcwOLaFHEICRQXAS=json.dumps(KYnfjovlVBGrptmcwOLaFHEICRQXAN,separators=(',',':'))
   KYnfjovlVBGrptmcwOLaFHEICRQXAS=base64.standard_b64encode(KYnfjovlVBGrptmcwOLaFHEICRQXAS.encode()).decode('utf-8')
   KYnfjovlVBGrptmcwOLaFHEICRQXAS=KYnfjovlVBGrptmcwOLaFHEICRQXAS.replace('+','%2B')
   KYnfjovlVBGrptmcwOLaFHEICRQXAM='plugin://plugin.video.primevm/?params='
   KYnfjovlVBGrptmcwOLaFHEICRQXAM+=KYnfjovlVBGrptmcwOLaFHEICRQXAS
  elif KYnfjovlVBGrptmcwOLaFHEICRQXAg=='disney':
   KYnfjovlVBGrptmcwOLaFHEICRQXAN={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':KYnfjovlVBGrptmcwOLaFHEICRQXMU,}}
   KYnfjovlVBGrptmcwOLaFHEICRQXAS=json.dumps(KYnfjovlVBGrptmcwOLaFHEICRQXAN,separators=(',',':'))
   KYnfjovlVBGrptmcwOLaFHEICRQXAS=base64.standard_b64encode(KYnfjovlVBGrptmcwOLaFHEICRQXAS.encode()).decode('utf-8')
   KYnfjovlVBGrptmcwOLaFHEICRQXAS=KYnfjovlVBGrptmcwOLaFHEICRQXAS.replace('+','%2B')
   KYnfjovlVBGrptmcwOLaFHEICRQXAM='plugin://plugin.video.disneym/?params='
   KYnfjovlVBGrptmcwOLaFHEICRQXAM+=KYnfjovlVBGrptmcwOLaFHEICRQXAS
  return KYnfjovlVBGrptmcwOLaFHEICRQXAM
 def dp_Nf_Search(KYnfjovlVBGrptmcwOLaFHEICRQXDN,args):
  KYnfjovlVBGrptmcwOLaFHEICRQXAs =KYnfjovlVBGrptmcwOLaFHEICRQXdD(args.get('page'))
  KYnfjovlVBGrptmcwOLaFHEICRQXMU =args.get('search_key')
  KYnfjovlVBGrptmcwOLaFHEICRQXMk=args.get('byReference')
  (KYnfjovlVBGrptmcwOLaFHEICRQXMx,KYnfjovlVBGrptmcwOLaFHEICRQXMi,KYnfjovlVBGrptmcwOLaFHEICRQXMk)=KYnfjovlVBGrptmcwOLaFHEICRQXDN.SearchObj.Get_Search_Netflix(KYnfjovlVBGrptmcwOLaFHEICRQXMU,KYnfjovlVBGrptmcwOLaFHEICRQXAs,byReference=KYnfjovlVBGrptmcwOLaFHEICRQXMk)
  for KYnfjovlVBGrptmcwOLaFHEICRQXAW in KYnfjovlVBGrptmcwOLaFHEICRQXMx:
   KYnfjovlVBGrptmcwOLaFHEICRQXAh =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('videoid')
   KYnfjovlVBGrptmcwOLaFHEICRQXAd =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('vidtype')
   KYnfjovlVBGrptmcwOLaFHEICRQXDb =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('title')
   KYnfjovlVBGrptmcwOLaFHEICRQXAP =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('mpaa')
   KYnfjovlVBGrptmcwOLaFHEICRQXAT =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('regularSynopsis')
   KYnfjovlVBGrptmcwOLaFHEICRQXAz =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('dpSupplemental')
   KYnfjovlVBGrptmcwOLaFHEICRQXAy=KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('sequiturEvidence')
   KYnfjovlVBGrptmcwOLaFHEICRQXAu =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('thumbnail')
   KYnfjovlVBGrptmcwOLaFHEICRQXAU =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('year')
   KYnfjovlVBGrptmcwOLaFHEICRQXAx =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('duration')
   KYnfjovlVBGrptmcwOLaFHEICRQXAi =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('info_genre')
   KYnfjovlVBGrptmcwOLaFHEICRQXAb =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('director')
   KYnfjovlVBGrptmcwOLaFHEICRQXAk =KYnfjovlVBGrptmcwOLaFHEICRQXAW.get('cast')
   if KYnfjovlVBGrptmcwOLaFHEICRQXAd=='movie':
    KYnfjovlVBGrptmcwOLaFHEICRQXJU=' (%s)'%(KYnfjovlVBGrptmcwOLaFHEICRQXdM(KYnfjovlVBGrptmcwOLaFHEICRQXAU))
   else:
    KYnfjovlVBGrptmcwOLaFHEICRQXJU=''
   KYnfjovlVBGrptmcwOLaFHEICRQXAq=''
   if KYnfjovlVBGrptmcwOLaFHEICRQXAT:KYnfjovlVBGrptmcwOLaFHEICRQXAq=KYnfjovlVBGrptmcwOLaFHEICRQXAq+'\n\n'+KYnfjovlVBGrptmcwOLaFHEICRQXAT
   if KYnfjovlVBGrptmcwOLaFHEICRQXAz :KYnfjovlVBGrptmcwOLaFHEICRQXAq=KYnfjovlVBGrptmcwOLaFHEICRQXAq+'\n\n'+KYnfjovlVBGrptmcwOLaFHEICRQXAz
   if KYnfjovlVBGrptmcwOLaFHEICRQXAy:KYnfjovlVBGrptmcwOLaFHEICRQXAq=KYnfjovlVBGrptmcwOLaFHEICRQXAq+'\n\n'+KYnfjovlVBGrptmcwOLaFHEICRQXAy
   KYnfjovlVBGrptmcwOLaFHEICRQXAq=KYnfjovlVBGrptmcwOLaFHEICRQXAq.strip()
   KYnfjovlVBGrptmcwOLaFHEICRQXJx={'mediatype':'tvshow' if KYnfjovlVBGrptmcwOLaFHEICRQXAd=='show' else 'movie','title':KYnfjovlVBGrptmcwOLaFHEICRQXDb,'mpaa':KYnfjovlVBGrptmcwOLaFHEICRQXAP,'plot':KYnfjovlVBGrptmcwOLaFHEICRQXAq,'duration':KYnfjovlVBGrptmcwOLaFHEICRQXAx,'genre':KYnfjovlVBGrptmcwOLaFHEICRQXAi,'director':KYnfjovlVBGrptmcwOLaFHEICRQXAb,'cast':KYnfjovlVBGrptmcwOLaFHEICRQXAk,'year':KYnfjovlVBGrptmcwOLaFHEICRQXAU,}
   KYnfjovlVBGrptmcwOLaFHEICRQXDx={'ott':'netflix','vidtype':'TVSHOW' if KYnfjovlVBGrptmcwOLaFHEICRQXAd=='show' else 'MOVIE','videoid':KYnfjovlVBGrptmcwOLaFHEICRQXAh,}
   KYnfjovlVBGrptmcwOLaFHEICRQXAM=KYnfjovlVBGrptmcwOLaFHEICRQXDN.make_Hyper_Link(KYnfjovlVBGrptmcwOLaFHEICRQXDx)
   KYnfjovlVBGrptmcwOLaFHEICRQXMA=KYnfjovlVBGrptmcwOLaFHEICRQXgu if KYnfjovlVBGrptmcwOLaFHEICRQXAd=='show' else KYnfjovlVBGrptmcwOLaFHEICRQXgU
   if KYnfjovlVBGrptmcwOLaFHEICRQXDN.get_settings_makebookmark():
    KYnfjovlVBGrptmcwOLaFHEICRQXgD={'mode':'SET_BOOKMARK','values':{'videoid':KYnfjovlVBGrptmcwOLaFHEICRQXAh,'vidtype':'tvshow' if KYnfjovlVBGrptmcwOLaFHEICRQXAd=='show' else 'movie','vtitle':KYnfjovlVBGrptmcwOLaFHEICRQXDb+KYnfjovlVBGrptmcwOLaFHEICRQXJU,'vsubtitle':'','vinfo':KYnfjovlVBGrptmcwOLaFHEICRQXJx,'thumbnail':KYnfjovlVBGrptmcwOLaFHEICRQXAu,}}
    KYnfjovlVBGrptmcwOLaFHEICRQXgJ=json.dumps(KYnfjovlVBGrptmcwOLaFHEICRQXgD,separators=(',',':'))
    KYnfjovlVBGrptmcwOLaFHEICRQXgJ=base64.standard_b64encode(KYnfjovlVBGrptmcwOLaFHEICRQXgJ.encode()).decode('utf-8')
    KYnfjovlVBGrptmcwOLaFHEICRQXgJ=KYnfjovlVBGrptmcwOLaFHEICRQXgJ.replace('+','%2B')
    KYnfjovlVBGrptmcwOLaFHEICRQXgM='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(KYnfjovlVBGrptmcwOLaFHEICRQXgJ)
    KYnfjovlVBGrptmcwOLaFHEICRQXJu=[('(통합) 찜 영상에 추가',KYnfjovlVBGrptmcwOLaFHEICRQXgM)]
   else:
    KYnfjovlVBGrptmcwOLaFHEICRQXJu=KYnfjovlVBGrptmcwOLaFHEICRQXgy
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.add_dir(KYnfjovlVBGrptmcwOLaFHEICRQXDb+KYnfjovlVBGrptmcwOLaFHEICRQXJU,sublabel=KYnfjovlVBGrptmcwOLaFHEICRQXgy,img=KYnfjovlVBGrptmcwOLaFHEICRQXAu,infoLabels=KYnfjovlVBGrptmcwOLaFHEICRQXJx,isFolder=KYnfjovlVBGrptmcwOLaFHEICRQXMA,params=KYnfjovlVBGrptmcwOLaFHEICRQXDx,isLink=KYnfjovlVBGrptmcwOLaFHEICRQXgU,ContextMenu=KYnfjovlVBGrptmcwOLaFHEICRQXJu,direct_url=KYnfjovlVBGrptmcwOLaFHEICRQXAM)
  if KYnfjovlVBGrptmcwOLaFHEICRQXMi:
   KYnfjovlVBGrptmcwOLaFHEICRQXDx={}
   KYnfjovlVBGrptmcwOLaFHEICRQXDx['mode'] ='NF_SEARCH' 
   KYnfjovlVBGrptmcwOLaFHEICRQXDx['page'] =KYnfjovlVBGrptmcwOLaFHEICRQXdM(KYnfjovlVBGrptmcwOLaFHEICRQXAs+1)
   KYnfjovlVBGrptmcwOLaFHEICRQXDx['search_key']=KYnfjovlVBGrptmcwOLaFHEICRQXMU
   KYnfjovlVBGrptmcwOLaFHEICRQXDx['byReference']=KYnfjovlVBGrptmcwOLaFHEICRQXMk
   KYnfjovlVBGrptmcwOLaFHEICRQXDb='[B]%s >>[/B]'%'다음 페이지'
   KYnfjovlVBGrptmcwOLaFHEICRQXgA=KYnfjovlVBGrptmcwOLaFHEICRQXdM(KYnfjovlVBGrptmcwOLaFHEICRQXAs+1)
   KYnfjovlVBGrptmcwOLaFHEICRQXJi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.add_dir(KYnfjovlVBGrptmcwOLaFHEICRQXDb,sublabel=KYnfjovlVBGrptmcwOLaFHEICRQXgA,img=KYnfjovlVBGrptmcwOLaFHEICRQXJi,infoLabels=KYnfjovlVBGrptmcwOLaFHEICRQXgy,isFolder=KYnfjovlVBGrptmcwOLaFHEICRQXgu,params=KYnfjovlVBGrptmcwOLaFHEICRQXDx)
  xbmcplugin.setContent(KYnfjovlVBGrptmcwOLaFHEICRQXDN._addon_handle,'movies')
  xbmcplugin.endOfDirectory(KYnfjovlVBGrptmcwOLaFHEICRQXDN._addon_handle)
 def dp_Bookmark_Menu(KYnfjovlVBGrptmcwOLaFHEICRQXDN,args):
  KYnfjovlVBGrptmcwOLaFHEICRQXgd='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(KYnfjovlVBGrptmcwOLaFHEICRQXgd)
 def dp_Set_Bookmark(KYnfjovlVBGrptmcwOLaFHEICRQXDN,args):
  KYnfjovlVBGrptmcwOLaFHEICRQXAh =args.get('videoid')
  KYnfjovlVBGrptmcwOLaFHEICRQXAd =args.get('vidtype')
  KYnfjovlVBGrptmcwOLaFHEICRQXgN =args.get('vtitle')
  KYnfjovlVBGrptmcwOLaFHEICRQXgS =args.get('vsubtitle')
  KYnfjovlVBGrptmcwOLaFHEICRQXgh =args.get('vinfo')
  KYnfjovlVBGrptmcwOLaFHEICRQXAu =args.get('thumbnail')
  KYnfjovlVBGrptmcwOLaFHEICRQXDW=xbmcgui.Dialog()
  KYnfjovlVBGrptmcwOLaFHEICRQXMD=KYnfjovlVBGrptmcwOLaFHEICRQXDW.yesno(__language__(30917).encode('utf8'),KYnfjovlVBGrptmcwOLaFHEICRQXgN+' \n\n'+__language__(30918))
  if KYnfjovlVBGrptmcwOLaFHEICRQXMD==KYnfjovlVBGrptmcwOLaFHEICRQXgU:return
  KYnfjovlVBGrptmcwOLaFHEICRQXge={'indexinfo':{'ott':'netflix','videoid':KYnfjovlVBGrptmcwOLaFHEICRQXAh,'vidtype':KYnfjovlVBGrptmcwOLaFHEICRQXAd,},'saveinfo':{'title':KYnfjovlVBGrptmcwOLaFHEICRQXgN,'subtitle':KYnfjovlVBGrptmcwOLaFHEICRQXgS,'thumbnail':KYnfjovlVBGrptmcwOLaFHEICRQXAu,'infoLabels':KYnfjovlVBGrptmcwOLaFHEICRQXgh,},}
  KYnfjovlVBGrptmcwOLaFHEICRQXDx={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':KYnfjovlVBGrptmcwOLaFHEICRQXge,}}
  KYnfjovlVBGrptmcwOLaFHEICRQXDi=json.dumps(KYnfjovlVBGrptmcwOLaFHEICRQXDx,separators=(',',':'))
  KYnfjovlVBGrptmcwOLaFHEICRQXDi=base64.standard_b64encode(KYnfjovlVBGrptmcwOLaFHEICRQXDi.encode()).decode('utf-8')
  KYnfjovlVBGrptmcwOLaFHEICRQXDi=KYnfjovlVBGrptmcwOLaFHEICRQXDi.replace('+','%2B')
  KYnfjovlVBGrptmcwOLaFHEICRQXgM='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(KYnfjovlVBGrptmcwOLaFHEICRQXDi)
  xbmc.executebuiltin(KYnfjovlVBGrptmcwOLaFHEICRQXgM)
 def search_main(KYnfjovlVBGrptmcwOLaFHEICRQXDN):
  KYnfjovlVBGrptmcwOLaFHEICRQXgs=KYnfjovlVBGrptmcwOLaFHEICRQXDN.main_params.get('params')
  if KYnfjovlVBGrptmcwOLaFHEICRQXgs:
   KYnfjovlVBGrptmcwOLaFHEICRQXgW =base64.standard_b64decode(KYnfjovlVBGrptmcwOLaFHEICRQXgs).decode('utf-8')
   KYnfjovlVBGrptmcwOLaFHEICRQXgW =json.loads(KYnfjovlVBGrptmcwOLaFHEICRQXgW)
   KYnfjovlVBGrptmcwOLaFHEICRQXgP =KYnfjovlVBGrptmcwOLaFHEICRQXgW.get('mode')
   KYnfjovlVBGrptmcwOLaFHEICRQXgT =KYnfjovlVBGrptmcwOLaFHEICRQXgW.get('values')
  else:
   KYnfjovlVBGrptmcwOLaFHEICRQXgP=KYnfjovlVBGrptmcwOLaFHEICRQXDN.main_params.get('mode',KYnfjovlVBGrptmcwOLaFHEICRQXgy)
   KYnfjovlVBGrptmcwOLaFHEICRQXgT=KYnfjovlVBGrptmcwOLaFHEICRQXDN.main_params
  if KYnfjovlVBGrptmcwOLaFHEICRQXgP=='NFLOGOUT':
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.NF_logout()
   return
  elif KYnfjovlVBGrptmcwOLaFHEICRQXgP=='NFLOGIN':
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.NF_login(showMessage=KYnfjovlVBGrptmcwOLaFHEICRQXgu)
   return
  KYnfjovlVBGrptmcwOLaFHEICRQXDN.option_check()
  if KYnfjovlVBGrptmcwOLaFHEICRQXgP is KYnfjovlVBGrptmcwOLaFHEICRQXgy:
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.dp_Main_List()
  elif KYnfjovlVBGrptmcwOLaFHEICRQXgP=='TOTAL_SEARCH':
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.dp_Search_Group(KYnfjovlVBGrptmcwOLaFHEICRQXgT)
  elif KYnfjovlVBGrptmcwOLaFHEICRQXgP=='NF_SEARCH':
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.dp_Nf_Search(KYnfjovlVBGrptmcwOLaFHEICRQXgT)
  elif KYnfjovlVBGrptmcwOLaFHEICRQXgP=='TOTAL_HISTORY':
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.dp_Search_History(KYnfjovlVBGrptmcwOLaFHEICRQXgT)
  elif KYnfjovlVBGrptmcwOLaFHEICRQXgP=='HISTORY_REMOVE':
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.dp_History_Delete(KYnfjovlVBGrptmcwOLaFHEICRQXgT)
  elif KYnfjovlVBGrptmcwOLaFHEICRQXgP=='MENU_BOOKMARK':
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.dp_Bookmark_Menu(KYnfjovlVBGrptmcwOLaFHEICRQXgT)
  elif KYnfjovlVBGrptmcwOLaFHEICRQXgP=='SET_BOOKMARK':
   KYnfjovlVBGrptmcwOLaFHEICRQXDN.dp_Set_Bookmark(KYnfjovlVBGrptmcwOLaFHEICRQXgT)
  else:
   KYnfjovlVBGrptmcwOLaFHEICRQXgy
# Created by pyminifier (https://github.com/liftoff/pyminifier)
