__author__="NightRain"
dqBEXUDxeGybHKziJApkjPvMcRgmOn=object
dqBEXUDxeGybHKziJApkjPvMcRgmOV=None
dqBEXUDxeGybHKziJApkjPvMcRgmOa=False
dqBEXUDxeGybHKziJApkjPvMcRgmOQ=print
dqBEXUDxeGybHKziJApkjPvMcRgmOS=str
dqBEXUDxeGybHKziJApkjPvMcRgmOh=int
dqBEXUDxeGybHKziJApkjPvMcRgmOI=Exception
dqBEXUDxeGybHKziJApkjPvMcRgmOf=True
dqBEXUDxeGybHKziJApkjPvMcRgmlw=open
dqBEXUDxeGybHKziJApkjPvMcRgmlT=isinstance
dqBEXUDxeGybHKziJApkjPvMcRgmlL=list
dqBEXUDxeGybHKziJApkjPvMcRgmlN=dict
dqBEXUDxeGybHKziJApkjPvMcRgmlO=range
dqBEXUDxeGybHKziJApkjPvMcRgmlY=len
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class dqBEXUDxeGybHKziJApkjPvMcRgmwT(dqBEXUDxeGybHKziJApkjPvMcRgmOn):
 def __init__(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.DEFAULT_HEADER ={'user-agent':dqBEXUDxeGybHKziJApkjPvMcRgmwL.USER_AGENT}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_WAVVE ='https://apis.wavve.com'
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_TVING_SEARCH='https://search.tving.com'
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_TVING_IMG ='https://image.tving.com'
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_WATCHA ='https://api-mars.watcha.com'
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX ='https://www.netflix.com'
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.WAVVE_LIMIT =20 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.TVING_LIMIT =30
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.WATCHA_LIMIT =30
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_LIMIT =20 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.DERECTOR_LIMIT =4
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.CAST_LIMIT =10
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.GENRE_LIMIT =4
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.TVING_MOVIE_LITE=['2610061','2610161','261062']
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_HEADER={'user-agent':dqBEXUDxeGybHKziJApkjPvMcRgmwL.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND1 ='_342x192'
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND2 ='_665x375'
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_PORT ='_342x684'
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LOGO ='_550x124'
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF={}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']={}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']={}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.Init_NF_Cookies()
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.Init_NF_Session()
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_COOKIES1 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_COOKIES2 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_COOKIES3 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_COOKIES4 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_FULLTEXT1 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_FULLTEXT2 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_FULLTEXT3 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_FULLTEXT4 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_CONTEXTJSON_FILE1 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_CONTEXTJSON_FILE2 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_CONTEXTJSON_FILE3 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_CONTEXTJSON_FILE4 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_FALCORJSON_FILE1 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_FALCORJSON_FILE2 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_FALCORJSON_FILE3 =''
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_FALCORJSON_FILE4 =''
 def callRequestCookies(dqBEXUDxeGybHKziJApkjPvMcRgmwL,jobtype,dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmOV,params=dqBEXUDxeGybHKziJApkjPvMcRgmOV,headers=dqBEXUDxeGybHKziJApkjPvMcRgmOV,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmOV,redirects=dqBEXUDxeGybHKziJApkjPvMcRgmOa):
  dqBEXUDxeGybHKziJApkjPvMcRgmwN=dqBEXUDxeGybHKziJApkjPvMcRgmwL.DEFAULT_HEADER
  if headers:dqBEXUDxeGybHKziJApkjPvMcRgmwN.update(headers)
  if jobtype=='Get':
   dqBEXUDxeGybHKziJApkjPvMcRgmwO=requests.get(dqBEXUDxeGybHKziJApkjPvMcRgmwW,params=params,headers=dqBEXUDxeGybHKziJApkjPvMcRgmwN,cookies=cookies,allow_redirects=redirects)
  else:
   dqBEXUDxeGybHKziJApkjPvMcRgmwO=requests.post(dqBEXUDxeGybHKziJApkjPvMcRgmwW,data=payload,params=params,headers=dqBEXUDxeGybHKziJApkjPvMcRgmwN,cookies=cookies,allow_redirects=redirects)
  return dqBEXUDxeGybHKziJApkjPvMcRgmwO
 def callRequestCookies_NF(dqBEXUDxeGybHKziJApkjPvMcRgmwL,jobtype,dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmOV,params=dqBEXUDxeGybHKziJApkjPvMcRgmOV,headers=dqBEXUDxeGybHKziJApkjPvMcRgmOV,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmOV,redirects=dqBEXUDxeGybHKziJApkjPvMcRgmOa,addCookie=''):
  dqBEXUDxeGybHKziJApkjPvMcRgmwN=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_HEADER
  if headers:dqBEXUDxeGybHKziJApkjPvMcRgmwN.update(headers)
  if jobtype=='Get':
   dqBEXUDxeGybHKziJApkjPvMcRgmwO=requests.get(dqBEXUDxeGybHKziJApkjPvMcRgmwW,params=params,headers=dqBEXUDxeGybHKziJApkjPvMcRgmwN,cookies=cookies,allow_redirects=redirects)
  else:
   dqBEXUDxeGybHKziJApkjPvMcRgmwO=requests.post(dqBEXUDxeGybHKziJApkjPvMcRgmwW,data=payload,params=params,headers=dqBEXUDxeGybHKziJApkjPvMcRgmwN,cookies=cookies,allow_redirects=redirects)
  dqBEXUDxeGybHKziJApkjPvMcRgmOQ(dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmwO.status_code)+' - '+dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmwO.url))
  '''
  print(res.url )
  print(res.status_code )
  print(res.cookies )
  print(res.text )
  '''  
  try:
   if addCookie=='baseurl':
    if 'location' in dqBEXUDxeGybHKziJApkjPvMcRgmwO.headers:
     dqBEXUDxeGybHKziJApkjPvMcRgmwl=urllib.parse.urlsplit(dqBEXUDxeGybHKziJApkjPvMcRgmwO.headers.get('location')).path
     dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['contryurl']=dqBEXUDxeGybHKziJApkjPvMcRgmwl[1:3]
  except:
   dqBEXUDxeGybHKziJApkjPvMcRgmOV
  for dqBEXUDxeGybHKziJApkjPvMcRgmwY in dqBEXUDxeGybHKziJApkjPvMcRgmwO.cookies:
   if dqBEXUDxeGybHKziJApkjPvMcRgmwY.name=='flwssn':
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['flwssn']['value'] =dqBEXUDxeGybHKziJApkjPvMcRgmwY.value
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['flwssn']['expires'] =dqBEXUDxeGybHKziJApkjPvMcRgmwY.expires
   elif dqBEXUDxeGybHKziJApkjPvMcRgmwY.name=='nfvdid':
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['nfvdid']['value'] =dqBEXUDxeGybHKziJApkjPvMcRgmwY.value
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['nfvdid']['expires'] =dqBEXUDxeGybHKziJApkjPvMcRgmwY.expires
   elif dqBEXUDxeGybHKziJApkjPvMcRgmwY.name=='SecureNetflixId':
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['SecureNetflixId']['value'] =dqBEXUDxeGybHKziJApkjPvMcRgmwY.value
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['SecureNetflixId']['expires'] =dqBEXUDxeGybHKziJApkjPvMcRgmwY.expires
   elif dqBEXUDxeGybHKziJApkjPvMcRgmwY.name=='NetflixId':
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['NetflixId']['value'] =dqBEXUDxeGybHKziJApkjPvMcRgmwY.value
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['NetflixId']['expires'] =dqBEXUDxeGybHKziJApkjPvMcRgmwY.expires
   elif dqBEXUDxeGybHKziJApkjPvMcRgmwY.name=='memclid':
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['memclid']['value'] =dqBEXUDxeGybHKziJApkjPvMcRgmwY.value
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['memclid']['expires'] =dqBEXUDxeGybHKziJApkjPvMcRgmwY.expires
   elif dqBEXUDxeGybHKziJApkjPvMcRgmwY.name=='clSharedContext':
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['clSharedContext']['value'] =dqBEXUDxeGybHKziJApkjPvMcRgmwY.value
    dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['clSharedContext']['expires'] =dqBEXUDxeGybHKziJApkjPvMcRgmwL.GetNoCache(timetype=1,minutes=5)
  return dqBEXUDxeGybHKziJApkjPvMcRgmwO
 def GetNoCache(dqBEXUDxeGybHKziJApkjPvMcRgmwL,timetype=1,minutes=0):
  if timetype==1:
   ts=dqBEXUDxeGybHKziJApkjPvMcRgmOh(time.time())
   mi=dqBEXUDxeGybHKziJApkjPvMcRgmOh(minutes*60)
  else:
   ts=dqBEXUDxeGybHKziJApkjPvMcRgmOh(time.time()*1000)
   mi=dqBEXUDxeGybHKziJApkjPvMcRgmOh(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(dqBEXUDxeGybHKziJApkjPvMcRgmwL,search_key,sType,page_int):
  dqBEXUDxeGybHKziJApkjPvMcRgmwC=[]
  dqBEXUDxeGybHKziJApkjPvMcRgmwt=dqBEXUDxeGybHKziJApkjPvMcRgmTL=1
  dqBEXUDxeGybHKziJApkjPvMcRgmwF=dqBEXUDxeGybHKziJApkjPvMcRgmOa
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwW=dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_WAVVE+'/cf/search/list.js'
   dqBEXUDxeGybHKziJApkjPvMcRgmws={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':dqBEXUDxeGybHKziJApkjPvMcRgmOS((page_int-1)*dqBEXUDxeGybHKziJApkjPvMcRgmwL.WAVVE_LIMIT),'limit':dqBEXUDxeGybHKziJApkjPvMcRgmwL.WAVVE_LIMIT,'orderby':'score'}
   dqBEXUDxeGybHKziJApkjPvMcRgmws.update(dqBEXUDxeGybHKziJApkjPvMcRgmwL.WAVVE_PARAMS)
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.callRequestCookies('Get',dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmOV,params=dqBEXUDxeGybHKziJApkjPvMcRgmws,headers=dqBEXUDxeGybHKziJApkjPvMcRgmOV,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmOV)
   dqBEXUDxeGybHKziJApkjPvMcRgmwr=json.loads(dqBEXUDxeGybHKziJApkjPvMcRgmwu.text)
   if not('celllist' in dqBEXUDxeGybHKziJApkjPvMcRgmwr['cell_toplist']):return dqBEXUDxeGybHKziJApkjPvMcRgmwC,dqBEXUDxeGybHKziJApkjPvMcRgmwF
   dqBEXUDxeGybHKziJApkjPvMcRgmwn=dqBEXUDxeGybHKziJApkjPvMcRgmwr['cell_toplist']['celllist']
   for dqBEXUDxeGybHKziJApkjPvMcRgmwV in dqBEXUDxeGybHKziJApkjPvMcRgmwn:
    dqBEXUDxeGybHKziJApkjPvMcRgmwa =dqBEXUDxeGybHKziJApkjPvMcRgmwV['event_list'][1]['url']
    dqBEXUDxeGybHKziJApkjPvMcRgmwQ=urllib.parse.urlsplit(dqBEXUDxeGybHKziJApkjPvMcRgmwa).query
    dqBEXUDxeGybHKziJApkjPvMcRgmwS=dqBEXUDxeGybHKziJApkjPvMcRgmwQ[0:dqBEXUDxeGybHKziJApkjPvMcRgmwQ.find('=')]
    dqBEXUDxeGybHKziJApkjPvMcRgmwh=dqBEXUDxeGybHKziJApkjPvMcRgmwQ[dqBEXUDxeGybHKziJApkjPvMcRgmwQ.find('=')+1:]
    dqBEXUDxeGybHKziJApkjPvMcRgmwS='TVSHOW' if dqBEXUDxeGybHKziJApkjPvMcRgmwS=='programid' else 'MOVIE' 
    dqBEXUDxeGybHKziJApkjPvMcRgmwI=dqBEXUDxeGybHKziJApkjPvMcRgmwV['title_list'][0]['text']
    dqBEXUDxeGybHKziJApkjPvMcRgmwf =dqBEXUDxeGybHKziJApkjPvMcRgmwV['age']
    dqBEXUDxeGybHKziJApkjPvMcRgmTw={'title':dqBEXUDxeGybHKziJApkjPvMcRgmwI}
    if dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('age')!='21':
     dqBEXUDxeGybHKziJApkjPvMcRgmwC.append(dqBEXUDxeGybHKziJApkjPvMcRgmTw)
   dqBEXUDxeGybHKziJApkjPvMcRgmwt=dqBEXUDxeGybHKziJApkjPvMcRgmOh(dqBEXUDxeGybHKziJApkjPvMcRgmwr['cell_toplist']['pagecount'])
   if dqBEXUDxeGybHKziJApkjPvMcRgmwr['cell_toplist']['count']:dqBEXUDxeGybHKziJApkjPvMcRgmTL =dqBEXUDxeGybHKziJApkjPvMcRgmOh(dqBEXUDxeGybHKziJApkjPvMcRgmwr['cell_toplist']['count'])
   else:dqBEXUDxeGybHKziJApkjPvMcRgmTL=dqBEXUDxeGybHKziJApkjPvMcRgmwL.LIST_LIMIT
   dqBEXUDxeGybHKziJApkjPvMcRgmwF=dqBEXUDxeGybHKziJApkjPvMcRgmwt>dqBEXUDxeGybHKziJApkjPvMcRgmTL
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
  return dqBEXUDxeGybHKziJApkjPvMcRgmwC,dqBEXUDxeGybHKziJApkjPvMcRgmwF 
 def Get_Search_Tving(dqBEXUDxeGybHKziJApkjPvMcRgmwL,search_key,sType,page_int):
  dqBEXUDxeGybHKziJApkjPvMcRgmwC=[]
  dqBEXUDxeGybHKziJApkjPvMcRgmwF=dqBEXUDxeGybHKziJApkjPvMcRgmOa
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmTN ='/search/getSearch.jsp'
   dqBEXUDxeGybHKziJApkjPvMcRgmTO={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':dqBEXUDxeGybHKziJApkjPvMcRgmOS(page_int),'pageSize':dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmwL.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':dqBEXUDxeGybHKziJApkjPvMcRgmwL.TVING_PARMAS.get('SCREENCODE'),'os':dqBEXUDxeGybHKziJApkjPvMcRgmwL.TVING_PARMAS.get('OSCODE'),'network':dqBEXUDxeGybHKziJApkjPvMcRgmwL.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmwL.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmwL.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmwL.GetNoCache(2))}
   dqBEXUDxeGybHKziJApkjPvMcRgmwW=dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_TVING_SEARCH+dqBEXUDxeGybHKziJApkjPvMcRgmTN
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.callRequestCookies('Get',dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmOV,params=dqBEXUDxeGybHKziJApkjPvMcRgmTO,headers=dqBEXUDxeGybHKziJApkjPvMcRgmOV,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmOV)
   dqBEXUDxeGybHKziJApkjPvMcRgmTl=json.loads(dqBEXUDxeGybHKziJApkjPvMcRgmwu.text)
   if sType=='TVSHOW':
    if not('programRsb' in dqBEXUDxeGybHKziJApkjPvMcRgmTl):return dqBEXUDxeGybHKziJApkjPvMcRgmwC,dqBEXUDxeGybHKziJApkjPvMcRgmwF
    dqBEXUDxeGybHKziJApkjPvMcRgmTY=dqBEXUDxeGybHKziJApkjPvMcRgmTl['programRsb']['dataList']
    dqBEXUDxeGybHKziJApkjPvMcRgmTo =dqBEXUDxeGybHKziJApkjPvMcRgmOh(dqBEXUDxeGybHKziJApkjPvMcRgmTl['programRsb']['count'])
    for dqBEXUDxeGybHKziJApkjPvMcRgmwV in dqBEXUDxeGybHKziJApkjPvMcRgmTY:
     dqBEXUDxeGybHKziJApkjPvMcRgmTC=dqBEXUDxeGybHKziJApkjPvMcRgmwV['mast_cd']
     dqBEXUDxeGybHKziJApkjPvMcRgmwI =dqBEXUDxeGybHKziJApkjPvMcRgmwV['mast_nm']
     dqBEXUDxeGybHKziJApkjPvMcRgmTt=dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_TVING_IMG+dqBEXUDxeGybHKziJApkjPvMcRgmwV['web_url4']
     dqBEXUDxeGybHKziJApkjPvMcRgmTF =dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_TVING_IMG+dqBEXUDxeGybHKziJApkjPvMcRgmwV['web_url']
     try:
      dqBEXUDxeGybHKziJApkjPvMcRgmTW =[]
      dqBEXUDxeGybHKziJApkjPvMcRgmTs=[]
      dqBEXUDxeGybHKziJApkjPvMcRgmTu =[]
      dqBEXUDxeGybHKziJApkjPvMcRgmTr =0
      dqBEXUDxeGybHKziJApkjPvMcRgmTn =''
      dqBEXUDxeGybHKziJApkjPvMcRgmTV =''
      dqBEXUDxeGybHKziJApkjPvMcRgmTa =''
      if dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('actor') !='' and dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('actor') !='-':dqBEXUDxeGybHKziJApkjPvMcRgmTW =dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('actor').split(',')
      if dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('director')!='' and dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('director')!='-':dqBEXUDxeGybHKziJApkjPvMcRgmTs=dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('director').split(',')
      if dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('cate_nm')!='' and dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('cate_nm')!='-':dqBEXUDxeGybHKziJApkjPvMcRgmTu =dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('cate_nm').split('/')
      if 'targetage' in dqBEXUDxeGybHKziJApkjPvMcRgmwV:dqBEXUDxeGybHKziJApkjPvMcRgmTn=dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('targetage')
      if 'broad_dt' in dqBEXUDxeGybHKziJApkjPvMcRgmwV:
       dqBEXUDxeGybHKziJApkjPvMcRgmTQ=dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('broad_dt')
       dqBEXUDxeGybHKziJApkjPvMcRgmTa='%s-%s-%s'%(dqBEXUDxeGybHKziJApkjPvMcRgmTQ[:4],dqBEXUDxeGybHKziJApkjPvMcRgmTQ[4:6],dqBEXUDxeGybHKziJApkjPvMcRgmTQ[6:])
       dqBEXUDxeGybHKziJApkjPvMcRgmTV =dqBEXUDxeGybHKziJApkjPvMcRgmTQ[:4]
     except:
      dqBEXUDxeGybHKziJApkjPvMcRgmOV
     dqBEXUDxeGybHKziJApkjPvMcRgmTw={'title':dqBEXUDxeGybHKziJApkjPvMcRgmwI,}
     dqBEXUDxeGybHKziJApkjPvMcRgmwC.append(dqBEXUDxeGybHKziJApkjPvMcRgmTw)
   else:
    if not('vodMVRsb' in dqBEXUDxeGybHKziJApkjPvMcRgmTl):return dqBEXUDxeGybHKziJApkjPvMcRgmwC,dqBEXUDxeGybHKziJApkjPvMcRgmwF
    dqBEXUDxeGybHKziJApkjPvMcRgmTS=dqBEXUDxeGybHKziJApkjPvMcRgmTl['vodMVRsb']['dataList']
    dqBEXUDxeGybHKziJApkjPvMcRgmTo =dqBEXUDxeGybHKziJApkjPvMcRgmOh(dqBEXUDxeGybHKziJApkjPvMcRgmTl['vodMVRsb']['count'])
    dqBEXUDxeGybHKziJApkjPvMcRgmOQ(dqBEXUDxeGybHKziJApkjPvMcRgmTo)
    for dqBEXUDxeGybHKziJApkjPvMcRgmwV in dqBEXUDxeGybHKziJApkjPvMcRgmTS:
     dqBEXUDxeGybHKziJApkjPvMcRgmTC=dqBEXUDxeGybHKziJApkjPvMcRgmwV['mast_cd']
     dqBEXUDxeGybHKziJApkjPvMcRgmwI =dqBEXUDxeGybHKziJApkjPvMcRgmwV['mast_nm'].strip()
     dqBEXUDxeGybHKziJApkjPvMcRgmTt =dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_TVING_IMG+dqBEXUDxeGybHKziJApkjPvMcRgmwV['web_url']
     dqBEXUDxeGybHKziJApkjPvMcRgmTF =dqBEXUDxeGybHKziJApkjPvMcRgmTt
     dqBEXUDxeGybHKziJApkjPvMcRgmTh=''
     try:
      dqBEXUDxeGybHKziJApkjPvMcRgmTW =[]
      dqBEXUDxeGybHKziJApkjPvMcRgmTs=[]
      dqBEXUDxeGybHKziJApkjPvMcRgmTu =[]
      dqBEXUDxeGybHKziJApkjPvMcRgmTr =0
      dqBEXUDxeGybHKziJApkjPvMcRgmTn =''
      dqBEXUDxeGybHKziJApkjPvMcRgmTV =''
      dqBEXUDxeGybHKziJApkjPvMcRgmTa =''
      if dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('actor') !='' and dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('actor') !='-':dqBEXUDxeGybHKziJApkjPvMcRgmTW =dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('actor').split(',')
      if dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('director')!='' and dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('director')!='-':dqBEXUDxeGybHKziJApkjPvMcRgmTs=dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('director').split(',')
      if dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('cate_nm')!='' and dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('cate_nm')!='-':dqBEXUDxeGybHKziJApkjPvMcRgmTu =dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('cate_nm').split('/')
      if dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('runtime_sec')!='':dqBEXUDxeGybHKziJApkjPvMcRgmTr=dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('runtime_sec')
      if 'grade_nm' in dqBEXUDxeGybHKziJApkjPvMcRgmwV:dqBEXUDxeGybHKziJApkjPvMcRgmTn=dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('grade_nm')
      dqBEXUDxeGybHKziJApkjPvMcRgmTQ=dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('broad_dt')
      if data_str!='':
       dqBEXUDxeGybHKziJApkjPvMcRgmTa='%s-%s-%s'%(dqBEXUDxeGybHKziJApkjPvMcRgmTQ[:4],dqBEXUDxeGybHKziJApkjPvMcRgmTQ[4:6],dqBEXUDxeGybHKziJApkjPvMcRgmTQ[6:])
       dqBEXUDxeGybHKziJApkjPvMcRgmTV =dqBEXUDxeGybHKziJApkjPvMcRgmTQ[:4]
     except:
      dqBEXUDxeGybHKziJApkjPvMcRgmOV
     dqBEXUDxeGybHKziJApkjPvMcRgmTw={'title':dqBEXUDxeGybHKziJApkjPvMcRgmwI,}
     dqBEXUDxeGybHKziJApkjPvMcRgmTI=dqBEXUDxeGybHKziJApkjPvMcRgmOa
     for dqBEXUDxeGybHKziJApkjPvMcRgmTf in dqBEXUDxeGybHKziJApkjPvMcRgmwV['bill']:
      if dqBEXUDxeGybHKziJApkjPvMcRgmTf in dqBEXUDxeGybHKziJApkjPvMcRgmwL.TVING_MOVIE_LITE:
       dqBEXUDxeGybHKziJApkjPvMcRgmTI=dqBEXUDxeGybHKziJApkjPvMcRgmOf
       break
     if dqBEXUDxeGybHKziJApkjPvMcRgmTI==dqBEXUDxeGybHKziJApkjPvMcRgmOa: 
      dqBEXUDxeGybHKziJApkjPvMcRgmTw['title']=dqBEXUDxeGybHKziJApkjPvMcRgmTw['title']+' [개별구매]'
     dqBEXUDxeGybHKziJApkjPvMcRgmwC.append(dqBEXUDxeGybHKziJApkjPvMcRgmTw)
   if dqBEXUDxeGybHKziJApkjPvMcRgmTo>(page_int*dqBEXUDxeGybHKziJApkjPvMcRgmwL.TVING_LIMIT):dqBEXUDxeGybHKziJApkjPvMcRgmwF=dqBEXUDxeGybHKziJApkjPvMcRgmOf
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
  return dqBEXUDxeGybHKziJApkjPvMcRgmwC,dqBEXUDxeGybHKziJApkjPvMcRgmwF
 def Get_Search_Watcha(dqBEXUDxeGybHKziJApkjPvMcRgmwL,search_key,page_int):
  dqBEXUDxeGybHKziJApkjPvMcRgmwC=[]
  dqBEXUDxeGybHKziJApkjPvMcRgmwF=dqBEXUDxeGybHKziJApkjPvMcRgmOa
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwW=dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_WATCHA+'/api/search.json'
   dqBEXUDxeGybHKziJApkjPvMcRgmTO={'query':search_key,'page':dqBEXUDxeGybHKziJApkjPvMcRgmOS(page_int),'per':dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmwL.WATCHA_LIMIT),'exclude':'limited',}
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.callRequestCookies('Get',dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmOV,params=dqBEXUDxeGybHKziJApkjPvMcRgmTO,headers=dqBEXUDxeGybHKziJApkjPvMcRgmwL.WATCHA_HEADER,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmOV)
   dqBEXUDxeGybHKziJApkjPvMcRgmTl=json.loads(dqBEXUDxeGybHKziJApkjPvMcRgmwu.text)
   if not('results' in dqBEXUDxeGybHKziJApkjPvMcRgmTl):return dqBEXUDxeGybHKziJApkjPvMcRgmwC,dqBEXUDxeGybHKziJApkjPvMcRgmwF
   dqBEXUDxeGybHKziJApkjPvMcRgmLw=dqBEXUDxeGybHKziJApkjPvMcRgmTl['results']
   dqBEXUDxeGybHKziJApkjPvMcRgmwF=dqBEXUDxeGybHKziJApkjPvMcRgmTl['meta']['has_next']
   for dqBEXUDxeGybHKziJApkjPvMcRgmwV in dqBEXUDxeGybHKziJApkjPvMcRgmLw:
    dqBEXUDxeGybHKziJApkjPvMcRgmLT =dqBEXUDxeGybHKziJApkjPvMcRgmwV['code']
    dqBEXUDxeGybHKziJApkjPvMcRgmLN=dqBEXUDxeGybHKziJApkjPvMcRgmwV['content_type']
    dqBEXUDxeGybHKziJApkjPvMcRgmLO =dqBEXUDxeGybHKziJApkjPvMcRgmwV['title']
    dqBEXUDxeGybHKziJApkjPvMcRgmLl =dqBEXUDxeGybHKziJApkjPvMcRgmwV['story']
    dqBEXUDxeGybHKziJApkjPvMcRgmTt=dqBEXUDxeGybHKziJApkjPvMcRgmTF=dqBEXUDxeGybHKziJApkjPvMcRgmOW=''
    if dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('poster') !=dqBEXUDxeGybHKziJApkjPvMcRgmOV:dqBEXUDxeGybHKziJApkjPvMcRgmTt=dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('poster').get('original')
    if dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('stillcut')!=dqBEXUDxeGybHKziJApkjPvMcRgmOV:dqBEXUDxeGybHKziJApkjPvMcRgmTF =dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('stillcut').get('large')
    if dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('thumbnail')!=dqBEXUDxeGybHKziJApkjPvMcRgmOV:dqBEXUDxeGybHKziJApkjPvMcRgmOW=dqBEXUDxeGybHKziJApkjPvMcRgmwV.get('thumbnail').get('large')
    if dqBEXUDxeGybHKziJApkjPvMcRgmOW=='' :dqBEXUDxeGybHKziJApkjPvMcRgmOW=dqBEXUDxeGybHKziJApkjPvMcRgmTF
    dqBEXUDxeGybHKziJApkjPvMcRgmLY={'thumb':dqBEXUDxeGybHKziJApkjPvMcRgmTF,'poster':dqBEXUDxeGybHKziJApkjPvMcRgmTt,'fanart':dqBEXUDxeGybHKziJApkjPvMcRgmOW}
    dqBEXUDxeGybHKziJApkjPvMcRgmTV =dqBEXUDxeGybHKziJApkjPvMcRgmwV['year']
    dqBEXUDxeGybHKziJApkjPvMcRgmLo =dqBEXUDxeGybHKziJApkjPvMcRgmwV['film_rating_code']
    dqBEXUDxeGybHKziJApkjPvMcRgmLC=dqBEXUDxeGybHKziJApkjPvMcRgmwV['film_rating_short']
    dqBEXUDxeGybHKziJApkjPvMcRgmLt =dqBEXUDxeGybHKziJApkjPvMcRgmwV['film_rating_long']
    if dqBEXUDxeGybHKziJApkjPvMcRgmLN=='movies':
     dqBEXUDxeGybHKziJApkjPvMcRgmTr =dqBEXUDxeGybHKziJApkjPvMcRgmwV['duration']
    else:
     dqBEXUDxeGybHKziJApkjPvMcRgmTr ='0'
    dqBEXUDxeGybHKziJApkjPvMcRgmTw={'title':dqBEXUDxeGybHKziJApkjPvMcRgmLO,}
    dqBEXUDxeGybHKziJApkjPvMcRgmwC.append(dqBEXUDxeGybHKziJApkjPvMcRgmTw)
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
  return dqBEXUDxeGybHKziJApkjPvMcRgmwC,dqBEXUDxeGybHKziJApkjPvMcRgmwF
 def dic_To_jsonfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL,filename,dic):
  if filename=='':return
  fp=dqBEXUDxeGybHKziJApkjPvMcRgmlw(filename,'w',-1,'utf-8')
  json.dump(dic,fp)
  fp.close()
 def jsonfile_To_dic(dqBEXUDxeGybHKziJApkjPvMcRgmwL,filename):
  if filename=='':return dqBEXUDxeGybHKziJApkjPvMcRgmOV
  try:
   fp=dqBEXUDxeGybHKziJApkjPvMcRgmlw(filename,'r',-1,'utf-8')
   dqBEXUDxeGybHKziJApkjPvMcRgmLF=json.load(fp)
   fp.close()
  except:
   dqBEXUDxeGybHKziJApkjPvMcRgmLF={}
  return dqBEXUDxeGybHKziJApkjPvMcRgmLF
 def tempFileSave(dqBEXUDxeGybHKziJApkjPvMcRgmwL,filename,resText):
  if filename=='':return
  fp=dqBEXUDxeGybHKziJApkjPvMcRgmlw(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(dqBEXUDxeGybHKziJApkjPvMcRgmwL,filename):
  if filename=='':return
  try:
   fp=dqBEXUDxeGybHKziJApkjPvMcRgmlw(filename,'r',-1,'utf-8')
   dqBEXUDxeGybHKziJApkjPvMcRgmLF=fp.read()
   fp.close()
  except:
   dqBEXUDxeGybHKziJApkjPvMcRgmLF=''
  return dqBEXUDxeGybHKziJApkjPvMcRgmLF
 def Init_NF_Total(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF={}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']={}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']={}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.Init_NF_Cookies()
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.Init_NF_Session()
 def Init_NF_Cookies(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['lhpuuidh'] ={'keyname':'','value':'','expires':0}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['lhpuuidhT'] ={'keyname':'','value':'','expires':0}
 def Check_NF_CookieExp(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  dqBEXUDxeGybHKziJApkjPvMcRgmLW=dqBEXUDxeGybHKziJApkjPvMcRgmwL.GetNoCache(timetype=1,minutes=0)
  if dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['flwssn']['expires'] <=dqBEXUDxeGybHKziJApkjPvMcRgmLW:dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  if dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['nfvdid']['expires'] <=dqBEXUDxeGybHKziJApkjPvMcRgmLW:dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  if dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['SecureNetflixId']['expires']<=dqBEXUDxeGybHKziJApkjPvMcRgmLW:dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  if dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['NetflixId']['expires'] <=dqBEXUDxeGybHKziJApkjPvMcRgmLW:dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  if dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['memclid']['expires'] <=dqBEXUDxeGybHKziJApkjPvMcRgmLW:dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  if dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['clSharedContext']['expires']<=dqBEXUDxeGybHKziJApkjPvMcRgmLW:dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
 def Init_NF_Session(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['account'] ={'nfid':'','nfpw':'','nfpfnum':0}
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['membershipStatus']='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['esnModel'] ='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['username'] ='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['authURL'] ='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['mainGuid'] ='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['nowGuid'] ='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['abContext'] ='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['identifier'] ='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['contryurl'] ='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['countryCode'] ='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['countryIsoCode'] ='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['loco'] ='' 
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['limitdate'] =''
 def make_NF_DefaultCookies(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  dqBEXUDxeGybHKziJApkjPvMcRgmLs={}
  if dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['flwssn']['value'] :dqBEXUDxeGybHKziJApkjPvMcRgmLs['flwssn'] =dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['flwssn']['value']
  if dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['nfvdid']['value'] :dqBEXUDxeGybHKziJApkjPvMcRgmLs['nfvdid'] =dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['nfvdid']['value']
  if dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['SecureNetflixId']['value']:dqBEXUDxeGybHKziJApkjPvMcRgmLs['SecureNetflixId']=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['SecureNetflixId']['value']
  if dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['NetflixId']['value'] :dqBEXUDxeGybHKziJApkjPvMcRgmLs['NetflixId'] =dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['NetflixId']['value']
  if dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['memclid']['value'] :dqBEXUDxeGybHKziJApkjPvMcRgmLs['memclid'] =dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['memclid']['value']
  return dqBEXUDxeGybHKziJApkjPvMcRgmLs
 def make_NF_XnetflixHeaders(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  dqBEXUDxeGybHKziJApkjPvMcRgmLu={'x-netflix.browsername':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['esnModel'],'x-netflix.esnprefix':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['nowGuid'],'x-netflix.uiversion':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return dqBEXUDxeGybHKziJApkjPvMcRgmLu
 def make_NF_ApiParams(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  dqBEXUDxeGybHKziJApkjPvMcRgmws={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'false','persoInfoDensity':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['identifier']),}
  return dqBEXUDxeGybHKziJApkjPvMcRgmws
 def extract_json(dqBEXUDxeGybHKziJApkjPvMcRgmwL,content,name):
  dqBEXUDxeGybHKziJApkjPvMcRgmLr=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  dqBEXUDxeGybHKziJApkjPvMcRgmLn=dqBEXUDxeGybHKziJApkjPvMcRgmOV
  dqBEXUDxeGybHKziJApkjPvMcRgmLV=re.compile(dqBEXUDxeGybHKziJApkjPvMcRgmLr.format(name),re.DOTALL).findall(content)
  dqBEXUDxeGybHKziJApkjPvMcRgmLn=dqBEXUDxeGybHKziJApkjPvMcRgmLV[0]
  dqBEXUDxeGybHKziJApkjPvMcRgmLa=dqBEXUDxeGybHKziJApkjPvMcRgmLn.replace('\\"','\\\\"') 
  dqBEXUDxeGybHKziJApkjPvMcRgmLa=dqBEXUDxeGybHKziJApkjPvMcRgmLa.replace('\\s','\\\\s') 
  dqBEXUDxeGybHKziJApkjPvMcRgmLa=dqBEXUDxeGybHKziJApkjPvMcRgmLa.replace('\\n','\\\\n') 
  dqBEXUDxeGybHKziJApkjPvMcRgmLa=dqBEXUDxeGybHKziJApkjPvMcRgmLa.replace('\\t','\\\\t') 
  dqBEXUDxeGybHKziJApkjPvMcRgmLa=dqBEXUDxeGybHKziJApkjPvMcRgmLa.encode().decode('unicode_escape') 
  dqBEXUDxeGybHKziJApkjPvMcRgmLa=re.sub(r'\\(?!["])',r'\\\\',dqBEXUDxeGybHKziJApkjPvMcRgmLa) 
  return json.loads(dqBEXUDxeGybHKziJApkjPvMcRgmLa)
 def Save_session_acount(dqBEXUDxeGybHKziJApkjPvMcRgmwL,dqBEXUDxeGybHKziJApkjPvMcRgmLQ,dqBEXUDxeGybHKziJApkjPvMcRgmLS,dqBEXUDxeGybHKziJApkjPvMcRgmLh):
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['account']['nfid'] =base64.standard_b64encode(dqBEXUDxeGybHKziJApkjPvMcRgmLQ.encode()).decode('utf-8')
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['account']['nfpw'] =base64.standard_b64encode(dqBEXUDxeGybHKziJApkjPvMcRgmLS.encode()).decode('utf-8')
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['account']['nfpfnum']=dqBEXUDxeGybHKziJApkjPvMcRgmLh
 def Load_session_acount(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  dqBEXUDxeGybHKziJApkjPvMcRgmLQ =base64.standard_b64decode(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['account']['nfid']).decode('utf-8')
  dqBEXUDxeGybHKziJApkjPvMcRgmLS =base64.standard_b64decode(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['account']['nfpw']).decode('utf-8')
  dqBEXUDxeGybHKziJApkjPvMcRgmLh=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['account']['nfpfnum']
  return dqBEXUDxeGybHKziJApkjPvMcRgmLQ,dqBEXUDxeGybHKziJApkjPvMcRgmLS,dqBEXUDxeGybHKziJApkjPvMcRgmLh
 def Get_NF_BaseCookies(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwW=dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX+'/login' 
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.callRequestCookies_NF('Get',dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmOV,params=dqBEXUDxeGybHKziJApkjPvMcRgmOV,headers=dqBEXUDxeGybHKziJApkjPvMcRgmOV,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmOV,addCookie='baseurl')
   if dqBEXUDxeGybHKziJApkjPvMcRgmwu.status_code!=302:
    dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 1-1 status_code error')
    return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 1-1 error')
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
   return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwW=dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX+'/'+dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['contryurl']+'/login' 
   dqBEXUDxeGybHKziJApkjPvMcRgmLs=dqBEXUDxeGybHKziJApkjPvMcRgmwL.make_NF_DefaultCookies()
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.callRequestCookies_NF('Get',dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmOV,params=dqBEXUDxeGybHKziJApkjPvMcRgmOV,headers=dqBEXUDxeGybHKziJApkjPvMcRgmOV,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmLs)
   if dqBEXUDxeGybHKziJApkjPvMcRgmwu.status_code!=200:
    dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 1-2 status_code error')
    return dqBEXUDxeGybHKziJApkjPvMcRgmOa
   dqBEXUDxeGybHKziJApkjPvMcRgmLI=dqBEXUDxeGybHKziJApkjPvMcRgmwL.extract_json(dqBEXUDxeGybHKziJApkjPvMcRgmwu.text,'reactContext')
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.dic_To_jsonfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_CONTEXTJSON_FILE1,dqBEXUDxeGybHKziJApkjPvMcRgmLI)
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['membershipStatus']=dqBEXUDxeGybHKziJApkjPvMcRgmLI['models']['userInfo']['data']['membershipStatus']
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['authURL'] =dqBEXUDxeGybHKziJApkjPvMcRgmLI['models']['userInfo']['data']['authURL']
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['esnModel'] =dqBEXUDxeGybHKziJApkjPvMcRgmLI['models']['esnGeneratorModel']['data']['esn']
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['abContext'] =dqBEXUDxeGybHKziJApkjPvMcRgmLI['models']['abContext']['data']['headers']
   dqBEXUDxeGybHKziJApkjPvMcRgmLf=dqBEXUDxeGybHKziJApkjPvMcRgmLI['models']['loginContext']['data']['geo']['requestCountry']['id']
   dqBEXUDxeGybHKziJApkjPvMcRgmNw ='+82' 
   dqBEXUDxeGybHKziJApkjPvMcRgmNT =dqBEXUDxeGybHKziJApkjPvMcRgmLI['models']['countryCodes']['data']['codes']
   for dqBEXUDxeGybHKziJApkjPvMcRgmNL in dqBEXUDxeGybHKziJApkjPvMcRgmNT:
    if dqBEXUDxeGybHKziJApkjPvMcRgmNL['id']==dqBEXUDxeGybHKziJApkjPvMcRgmLf:
     dqBEXUDxeGybHKziJApkjPvMcRgmNw='+'+dqBEXUDxeGybHKziJApkjPvMcRgmNL['code']
     break
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['countryCode'] =dqBEXUDxeGybHKziJApkjPvMcRgmNw 
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['countryIsoCode']=dqBEXUDxeGybHKziJApkjPvMcRgmLf 
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.dic_To_jsonfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_COOKIES1,dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF)
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 1-2 error')
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
   return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  return dqBEXUDxeGybHKziJApkjPvMcRgmOf
 def Get_NF_BaseLogin(dqBEXUDxeGybHKziJApkjPvMcRgmwL,user_id,user_pw,user_pfnum):
  dqBEXUDxeGybHKziJApkjPvMcRgmwL.Save_session_acount(user_id,user_pw,user_pfnum)
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwW=dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX+'/'+dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['contryurl']+'/login' 
   dqBEXUDxeGybHKziJApkjPvMcRgmNO={'userLoginId':user_id,'password':user_pw,'rememberMe':'true','flow':'websiteSignUp','mode':'login','action':'loginAction','withFields':'rememberMe,nextPage,userLoginId,password,countryCode,countryIsoCode','authURL':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['authURL'],'nextPage':'','showPassword':'','countryCode':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['countryCode'],'countryIsoCode':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['countryIsoCode'],}
   dqBEXUDxeGybHKziJApkjPvMcRgmLu={'referer':dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX+'/'+dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['contryurl']+'/login'}
   dqBEXUDxeGybHKziJApkjPvMcRgmLs=dqBEXUDxeGybHKziJApkjPvMcRgmwL.make_NF_DefaultCookies()
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.callRequestCookies_NF('Post',dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmNO,params=dqBEXUDxeGybHKziJApkjPvMcRgmOV,headers=dqBEXUDxeGybHKziJApkjPvMcRgmLu,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmLs)
   if dqBEXUDxeGybHKziJApkjPvMcRgmwu.status_code!=302:
    dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 2-1 status_code error')
    return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 2-1 error')
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
   return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwW=dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX+'/'+dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['contryurl']+'/' 
   dqBEXUDxeGybHKziJApkjPvMcRgmLu={'referer':dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX+'/'+dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['contryurl']+'/login'}
   dqBEXUDxeGybHKziJApkjPvMcRgmLs=dqBEXUDxeGybHKziJApkjPvMcRgmwL.make_NF_DefaultCookies()
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.callRequestCookies_NF('Get',dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmOV,params=dqBEXUDxeGybHKziJApkjPvMcRgmOV,headers=dqBEXUDxeGybHKziJApkjPvMcRgmLu,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmLs)
   if dqBEXUDxeGybHKziJApkjPvMcRgmwu.status_code!=302:
    dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 2-2 status_code error')
    return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 2-2 error')
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
   return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwW=dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX+'/browse' 
   dqBEXUDxeGybHKziJApkjPvMcRgmLu={'referer':dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX+'/'+dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['contryurl']+'/login'}
   dqBEXUDxeGybHKziJApkjPvMcRgmLs=dqBEXUDxeGybHKziJApkjPvMcRgmwL.make_NF_DefaultCookies()
   dqBEXUDxeGybHKziJApkjPvMcRgmLs['clSharedContext']=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['clSharedContext']['value']
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.callRequestCookies_NF('Get',dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmOV,params=dqBEXUDxeGybHKziJApkjPvMcRgmOV,headers=dqBEXUDxeGybHKziJApkjPvMcRgmLu,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmLs)
   if dqBEXUDxeGybHKziJApkjPvMcRgmwu.status_code!=200:
    dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 2-3 status_code error')
    return dqBEXUDxeGybHKziJApkjPvMcRgmOa
   dqBEXUDxeGybHKziJApkjPvMcRgmNl=dqBEXUDxeGybHKziJApkjPvMcRgmwL.extract_json(dqBEXUDxeGybHKziJApkjPvMcRgmwu.text,'reactContext')
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.dic_To_jsonfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_CONTEXTJSON_FILE2,dqBEXUDxeGybHKziJApkjPvMcRgmNl)
   dqBEXUDxeGybHKziJApkjPvMcRgmNY=dqBEXUDxeGybHKziJApkjPvMcRgmwL.extract_json(dqBEXUDxeGybHKziJApkjPvMcRgmwu.text,'falcorCache')
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.dic_To_jsonfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_FALCORJSON_FILE2,dqBEXUDxeGybHKziJApkjPvMcRgmNY)
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 2-3 error')
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
   return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  dqBEXUDxeGybHKziJApkjPvMcRgmNo=dqBEXUDxeGybHKziJApkjPvMcRgmwL.Get_NF_LoginData(dqBEXUDxeGybHKziJApkjPvMcRgmNl,dqBEXUDxeGybHKziJApkjPvMcRgmNY,user_pfnum)
  if dqBEXUDxeGybHKziJApkjPvMcRgmNo==dqBEXUDxeGybHKziJApkjPvMcRgmOa:
   return dqBEXUDxeGybHKziJApkjPvMcRgmOa 
  return dqBEXUDxeGybHKziJApkjPvMcRgmOf
 def Get_NF_LoginData(dqBEXUDxeGybHKziJApkjPvMcRgmwL,dqBEXUDxeGybHKziJApkjPvMcRgmNl,dqBEXUDxeGybHKziJApkjPvMcRgmNY,user_pfnum):
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['membershipStatus']=dqBEXUDxeGybHKziJApkjPvMcRgmNl['models']['userInfo']['data']['membershipStatus']
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['username'] =dqBEXUDxeGybHKziJApkjPvMcRgmNl['models']['userInfo']['data']['name']
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['authURL'] =dqBEXUDxeGybHKziJApkjPvMcRgmNl['models']['userInfo']['data']['authURL'] 
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['mainGuid'] =dqBEXUDxeGybHKziJApkjPvMcRgmNl['models']['userInfo']['data']['guid'] 
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['nowGuid'] =dqBEXUDxeGybHKziJApkjPvMcRgmNl['models']['userInfo']['data']['userGuid']
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['esnModel'] =dqBEXUDxeGybHKziJApkjPvMcRgmNl['models']['esnGeneratorModel']['data']['esn']
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['abContext'] =dqBEXUDxeGybHKziJApkjPvMcRgmNl['models']['abContext']['data']['headers']
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['identifier'] =dqBEXUDxeGybHKziJApkjPvMcRgmNl['models']['serverDefs']['data']['BUILD_IDENTIFIER']
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['nowGuid'] =dqBEXUDxeGybHKziJApkjPvMcRgmNY['profilesList'][dqBEXUDxeGybHKziJApkjPvMcRgmOS(user_pfnum)]['value'][1]
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.dic_To_jsonfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_COOKIES2,dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF)
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 2-3-sub error')
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
   return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  return dqBEXUDxeGybHKziJApkjPvMcRgmOf
 def Get_NF_ActivateProfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwW='%s/api/shakti/%s/profiles/switch'%(dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX,dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['identifier'])
   dqBEXUDxeGybHKziJApkjPvMcRgmws={'switchProfileGuid':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['nowGuid'],'authURL':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['authURL'],'_':dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmwL.GetNoCache(timetype=2,minutes=0)),}
   dqBEXUDxeGybHKziJApkjPvMcRgmLu={'referer':dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX+'/browse','accept':'*/*','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
   dqBEXUDxeGybHKziJApkjPvMcRgmNC=dqBEXUDxeGybHKziJApkjPvMcRgmwL.make_NF_XnetflixHeaders()
   dqBEXUDxeGybHKziJApkjPvMcRgmNC['x-netflix.request.client.user.guid']=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['mainGuid']
   dqBEXUDxeGybHKziJApkjPvMcRgmLu.update(dqBEXUDxeGybHKziJApkjPvMcRgmNC)
   dqBEXUDxeGybHKziJApkjPvMcRgmLs=dqBEXUDxeGybHKziJApkjPvMcRgmwL.make_NF_DefaultCookies()
   dqBEXUDxeGybHKziJApkjPvMcRgmLs['clSharedContext']=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['clSharedContext']['value']
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.callRequestCookies_NF('Get',dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmOV,params=dqBEXUDxeGybHKziJApkjPvMcRgmws,headers=dqBEXUDxeGybHKziJApkjPvMcRgmLu,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmLs)
   if dqBEXUDxeGybHKziJApkjPvMcRgmwu.status_code!=200:
    dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 3 status_code error')
    return dqBEXUDxeGybHKziJApkjPvMcRgmOa
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.dic_To_jsonfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_COOKIES2,dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF)
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 3 error')
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
   return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  return dqBEXUDxeGybHKziJApkjPvMcRgmOf
 def Get_NF_BrowseMain(dqBEXUDxeGybHKziJApkjPvMcRgmwL):
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwW=dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX+'/browse' 
   dqBEXUDxeGybHKziJApkjPvMcRgmLu={'referer':dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX+'/browse','sec-fetch-dest':'document','sec-fetch-mode':'navigate','sec-fetch-site':'same-origin','sec-fetch-user':'?1',}
   dqBEXUDxeGybHKziJApkjPvMcRgmLs=dqBEXUDxeGybHKziJApkjPvMcRgmwL.make_NF_DefaultCookies()
   dqBEXUDxeGybHKziJApkjPvMcRgmLs['clSharedContext']=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['clSharedContext']['value']
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.callRequestCookies_NF('Get',dqBEXUDxeGybHKziJApkjPvMcRgmwW,payload=dqBEXUDxeGybHKziJApkjPvMcRgmOV,params=dqBEXUDxeGybHKziJApkjPvMcRgmOV,headers=dqBEXUDxeGybHKziJApkjPvMcRgmLu,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmLs,addCookie='lhpuuidh')
   if dqBEXUDxeGybHKziJApkjPvMcRgmwu.status_code!=200:
    dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 4-main status_code error')
    return dqBEXUDxeGybHKziJApkjPvMcRgmOa
   dqBEXUDxeGybHKziJApkjPvMcRgmNl=dqBEXUDxeGybHKziJApkjPvMcRgmwL.extract_json(dqBEXUDxeGybHKziJApkjPvMcRgmwu.text,'reactContext')
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.dic_To_jsonfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_CONTEXTJSON_FILE3,dqBEXUDxeGybHKziJApkjPvMcRgmNl)
   dqBEXUDxeGybHKziJApkjPvMcRgmNY=dqBEXUDxeGybHKziJApkjPvMcRgmwL.extract_json(dqBEXUDxeGybHKziJApkjPvMcRgmwu.text,'falcorCache')
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.dic_To_jsonfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_FALCORJSON_FILE3,dqBEXUDxeGybHKziJApkjPvMcRgmNY)
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 4-main error')
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
   return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  dqBEXUDxeGybHKziJApkjPvMcRgmNo=dqBEXUDxeGybHKziJApkjPvMcRgmwL.Get_NF_BrowseSub(dqBEXUDxeGybHKziJApkjPvMcRgmNl,dqBEXUDxeGybHKziJApkjPvMcRgmNY)
  if dqBEXUDxeGybHKziJApkjPvMcRgmNo==dqBEXUDxeGybHKziJApkjPvMcRgmOa:
   return dqBEXUDxeGybHKziJApkjPvMcRgmOa 
  return dqBEXUDxeGybHKziJApkjPvMcRgmOf
 def Get_NF_BrowseSub(dqBEXUDxeGybHKziJApkjPvMcRgmwL,dqBEXUDxeGybHKziJApkjPvMcRgmNl,dqBEXUDxeGybHKziJApkjPvMcRgmNY):
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmNt =dqBEXUDxeGybHKziJApkjPvMcRgmNY['loco']['value'][1]
   dqBEXUDxeGybHKziJApkjPvMcRgmNF=dqBEXUDxeGybHKziJApkjPvMcRgmwL.GetNoCache(timetype=2,minutes=180)
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['loco'] =dqBEXUDxeGybHKziJApkjPvMcRgmNt
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['lhpuuidh']={'keyname':'lhpuuidh-browse-%s'%(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['nowGuid']),'value':'%s%s'%('KR%3AKO-KR%3A',dqBEXUDxeGybHKziJApkjPvMcRgmNt),'expires':dqBEXUDxeGybHKziJApkjPvMcRgmOh(dqBEXUDxeGybHKziJApkjPvMcRgmNF/1000)}
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['lhpuuidhT']={'keyname':'lhpuuidh-browse-%s-T'%(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['nowGuid']),'value':dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmNF),'expires':dqBEXUDxeGybHKziJApkjPvMcRgmOh(dqBEXUDxeGybHKziJApkjPvMcRgmNF/1000)}
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.dic_To_jsonfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_SESSION_COOKIES3,dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF)
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ('pass 4-sub error')
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
   return dqBEXUDxeGybHKziJApkjPvMcRgmOa
  return dqBEXUDxeGybHKziJApkjPvMcRgmOf
 def NF_makestr_paths(dqBEXUDxeGybHKziJApkjPvMcRgmwL,paths):
  dqBEXUDxeGybHKziJApkjPvMcRgmLF=[]
  if dqBEXUDxeGybHKziJApkjPvMcRgmlT(paths,dqBEXUDxeGybHKziJApkjPvMcRgmOh):
   return '%d'%(paths)
  elif dqBEXUDxeGybHKziJApkjPvMcRgmlT(paths,dqBEXUDxeGybHKziJApkjPvMcRgmOS):
   return '"%s"'%(paths)
  for dqBEXUDxeGybHKziJApkjPvMcRgmNW in paths:
   if dqBEXUDxeGybHKziJApkjPvMcRgmlT(dqBEXUDxeGybHKziJApkjPvMcRgmNW,dqBEXUDxeGybHKziJApkjPvMcRgmOh):
    dqBEXUDxeGybHKziJApkjPvMcRgmLF.append('%d'%(dqBEXUDxeGybHKziJApkjPvMcRgmNW))
   elif dqBEXUDxeGybHKziJApkjPvMcRgmlT(dqBEXUDxeGybHKziJApkjPvMcRgmNW,dqBEXUDxeGybHKziJApkjPvMcRgmOS):
    dqBEXUDxeGybHKziJApkjPvMcRgmLF.append('"%s"'%(dqBEXUDxeGybHKziJApkjPvMcRgmNW))
   elif dqBEXUDxeGybHKziJApkjPvMcRgmlT(dqBEXUDxeGybHKziJApkjPvMcRgmNW,dqBEXUDxeGybHKziJApkjPvMcRgmlL):
    dqBEXUDxeGybHKziJApkjPvMcRgmLF.append('[%s]'%(','.join(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_makestr_paths(dqBEXUDxeGybHKziJApkjPvMcRgmNW))))
   elif dqBEXUDxeGybHKziJApkjPvMcRgmlT(dqBEXUDxeGybHKziJApkjPvMcRgmNW,dqBEXUDxeGybHKziJApkjPvMcRgmlN):
    dqBEXUDxeGybHKziJApkjPvMcRgmNs=''
    for dqBEXUDxeGybHKziJApkjPvMcRgmNu,dqBEXUDxeGybHKziJApkjPvMcRgmNr in dqBEXUDxeGybHKziJApkjPvMcRgmNW.items():
     dqBEXUDxeGybHKziJApkjPvMcRgmNs+='"%s":%s,'%(dqBEXUDxeGybHKziJApkjPvMcRgmNu,dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_makestr_paths(dqBEXUDxeGybHKziJApkjPvMcRgmNr))
    dqBEXUDxeGybHKziJApkjPvMcRgmLF.append('{%s}'%(dqBEXUDxeGybHKziJApkjPvMcRgmNs[:-1]))
  return dqBEXUDxeGybHKziJApkjPvMcRgmLF
 def NF_Call_pathapi(dqBEXUDxeGybHKziJApkjPvMcRgmwL,dqBEXUDxeGybHKziJApkjPvMcRgmOw,referer=''):
  dqBEXUDxeGybHKziJApkjPvMcRgmNn='%s/nq/website/memberapi/%s/pathEvaluator'%(dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX,dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['identifier'])
  dqBEXUDxeGybHKziJApkjPvMcRgmNO={'path':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_makestr_paths(dqBEXUDxeGybHKziJApkjPvMcRgmOw),'authURL':dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['SESSION']['authURL']}
  dqBEXUDxeGybHKziJApkjPvMcRgmws=dqBEXUDxeGybHKziJApkjPvMcRgmwL.make_NF_ApiParams()
  dqBEXUDxeGybHKziJApkjPvMcRgmLu={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':dqBEXUDxeGybHKziJApkjPvMcRgmLu['referer']=referer
  dqBEXUDxeGybHKziJApkjPvMcRgmNC=dqBEXUDxeGybHKziJApkjPvMcRgmwL.make_NF_XnetflixHeaders()
  dqBEXUDxeGybHKziJApkjPvMcRgmLu.update(dqBEXUDxeGybHKziJApkjPvMcRgmNC)
  dqBEXUDxeGybHKziJApkjPvMcRgmLs=dqBEXUDxeGybHKziJApkjPvMcRgmwL.make_NF_DefaultCookies()
  dqBEXUDxeGybHKziJApkjPvMcRgmLs[dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['lhpuuidh']['keyname']]=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['lhpuuidh']['value']
  dqBEXUDxeGybHKziJApkjPvMcRgmLs[dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['lhpuuidhT']['keyname']]=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF['COOKIES']['lhpuuidhT']['value']
  dqBEXUDxeGybHKziJApkjPvMcRgmLs['profilesNewSession']='0'
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.callRequestCookies('Post',dqBEXUDxeGybHKziJApkjPvMcRgmNn,payload=dqBEXUDxeGybHKziJApkjPvMcRgmNO,params=dqBEXUDxeGybHKziJApkjPvMcRgmws,headers=dqBEXUDxeGybHKziJApkjPvMcRgmLu,cookies=dqBEXUDxeGybHKziJApkjPvMcRgmLs)
   return dqBEXUDxeGybHKziJApkjPvMcRgmwu
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
   return dqBEXUDxeGybHKziJApkjPvMcRgmOV
 def Get_Search_Netflix(dqBEXUDxeGybHKziJApkjPvMcRgmwL,search_key,page_int,byReference=''):
  dqBEXUDxeGybHKziJApkjPvMcRgmNV=dqBEXUDxeGybHKziJApkjPvMcRgmwL.DERECTOR_LIMIT
  dqBEXUDxeGybHKziJApkjPvMcRgmNa =dqBEXUDxeGybHKziJApkjPvMcRgmwL.CAST_LIMIT
  dqBEXUDxeGybHKziJApkjPvMcRgmNQ =dqBEXUDxeGybHKziJApkjPvMcRgmwL.GENRE_LIMIT
  dqBEXUDxeGybHKziJApkjPvMcRgmNS =dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_LIMIT*(page_int-1)
  dqBEXUDxeGybHKziJApkjPvMcRgmNh =dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_LIMIT*page_int 
  dqBEXUDxeGybHKziJApkjPvMcRgmNI="|%s"%(search_key)
  dqBEXUDxeGybHKziJApkjPvMcRgmNf ='%s/search?%s'%(dqBEXUDxeGybHKziJApkjPvMcRgmwL.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   dqBEXUDxeGybHKziJApkjPvMcRgmOw=[["search","byTerm",dqBEXUDxeGybHKziJApkjPvMcRgmNI,"titles",dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_LIMIT,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"summary"],["search","byTerm",dqBEXUDxeGybHKziJApkjPvMcRgmNI,"titles",dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_LIMIT,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",dqBEXUDxeGybHKziJApkjPvMcRgmNI,"titles",dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_LIMIT,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference","boxarts",[dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND2,dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_PORT],"jpg"],["search","byTerm",dqBEXUDxeGybHKziJApkjPvMcRgmNI,"titles",dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_LIMIT,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference","interestingMoment",dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND1,"jpg"],["search","byTerm",dqBEXUDxeGybHKziJApkjPvMcRgmNI,"titles",dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_LIMIT,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference","storyArt",dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND2,"jpg"],["search","byTerm",dqBEXUDxeGybHKziJApkjPvMcRgmNI,"titles",dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_LIMIT,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference",["cast","creators","directors"],{"from":0,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNV},["id","name"]],["search","byTerm",dqBEXUDxeGybHKziJApkjPvMcRgmNI,"titles",dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_LIMIT,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference","genres",{"from":0,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNQ},["id","name"]],["search","byTerm",dqBEXUDxeGybHKziJApkjPvMcRgmNI,"titles",dqBEXUDxeGybHKziJApkjPvMcRgmwL.NETFLIX_LIMIT,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LOGO,"png"],]
  else:
   dqBEXUDxeGybHKziJApkjPvMcRgmOw=[["search","byReference",byReference,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"summary"],["search","byReference",byReference,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference","boxarts",[dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND2,dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference","interestingMoment",dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference","storyArt",dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference",["cast","creators","directors"],{"from":0,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNV},["id","name"]],["search","byReference",byReference,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference","genres",{"from":0,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNQ},["id","name"]],["search","byReference",byReference,{"from":dqBEXUDxeGybHKziJApkjPvMcRgmNS,"to":dqBEXUDxeGybHKziJApkjPvMcRgmNh},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LOGO,"png"],]
  try:
   dqBEXUDxeGybHKziJApkjPvMcRgmwu=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_Call_pathapi(dqBEXUDxeGybHKziJApkjPvMcRgmOw,dqBEXUDxeGybHKziJApkjPvMcRgmNf)
   dqBEXUDxeGybHKziJApkjPvMcRgmwr=json.loads(dqBEXUDxeGybHKziJApkjPvMcRgmwu.text)
   dqBEXUDxeGybHKziJApkjPvMcRgmwL.dic_To_jsonfile(dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_CONTEXTJSON_FILE4,dqBEXUDxeGybHKziJApkjPvMcRgmwr)
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
  (dqBEXUDxeGybHKziJApkjPvMcRgmwC,dqBEXUDxeGybHKziJApkjPvMcRgmwF,byReference)=dqBEXUDxeGybHKziJApkjPvMcRgmwL.Search_Netflix_Make(dqBEXUDxeGybHKziJApkjPvMcRgmwr)
  return dqBEXUDxeGybHKziJApkjPvMcRgmwC,dqBEXUDxeGybHKziJApkjPvMcRgmwF,byReference
 def Search_Netflix_Make(dqBEXUDxeGybHKziJApkjPvMcRgmwL,jsonSource):
  dqBEXUDxeGybHKziJApkjPvMcRgmwC=[]
  dqBEXUDxeGybHKziJApkjPvMcRgmwF =dqBEXUDxeGybHKziJApkjPvMcRgmOa
  dqBEXUDxeGybHKziJApkjPvMcRgmOT=''
  dqBEXUDxeGybHKziJApkjPvMcRgmOL=jsonSource.get('paths')[0][1]
  if dqBEXUDxeGybHKziJApkjPvMcRgmOL=='byTerm':
   dqBEXUDxeGybHKziJApkjPvMcRgmNS =jsonSource['paths'][0][5]['from']
   dqBEXUDxeGybHKziJApkjPvMcRgmNh =jsonSource['paths'][0][5]['to']
  else:
   dqBEXUDxeGybHKziJApkjPvMcRgmNS =jsonSource['paths'][0][3]['from']
   dqBEXUDxeGybHKziJApkjPvMcRgmNh =jsonSource['paths'][0][3]['to']
  dqBEXUDxeGybHKziJApkjPvMcRgmOT=dqBEXUDxeGybHKziJApkjPvMcRgmlL(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  dqBEXUDxeGybHKziJApkjPvMcRgmON=jsonSource.get('jsonGraph').get('search').get('byReference').get(dqBEXUDxeGybHKziJApkjPvMcRgmOT)
  dqBEXUDxeGybHKziJApkjPvMcRgmOl =jsonSource.get('jsonGraph').get('videos')
  dqBEXUDxeGybHKziJApkjPvMcRgmOY=jsonSource.get('jsonGraph').get('person')
  dqBEXUDxeGybHKziJApkjPvMcRgmOo=jsonSource.get('jsonGraph').get('genres')
  dqBEXUDxeGybHKziJApkjPvMcRgmwF=dqBEXUDxeGybHKziJApkjPvMcRgmOf if dqBEXUDxeGybHKziJApkjPvMcRgmON[dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmNh)]['reference']['$type']=='ref' else dqBEXUDxeGybHKziJApkjPvMcRgmOa
  for dqBEXUDxeGybHKziJApkjPvMcRgmOC in dqBEXUDxeGybHKziJApkjPvMcRgmlO(dqBEXUDxeGybHKziJApkjPvMcRgmNS,dqBEXUDxeGybHKziJApkjPvMcRgmNh):
   if dqBEXUDxeGybHKziJApkjPvMcRgmON[dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmOC)]['reference']['$type']=='ref':
    dqBEXUDxeGybHKziJApkjPvMcRgmwh =dqBEXUDxeGybHKziJApkjPvMcRgmON[dqBEXUDxeGybHKziJApkjPvMcRgmOS(dqBEXUDxeGybHKziJApkjPvMcRgmOC)]['reference']['value'][1]
    dqBEXUDxeGybHKziJApkjPvMcRgmOt=dqBEXUDxeGybHKziJApkjPvMcRgmOl[dqBEXUDxeGybHKziJApkjPvMcRgmwh]
    dqBEXUDxeGybHKziJApkjPvMcRgmLO =dqBEXUDxeGybHKziJApkjPvMcRgmOt['title']['value']
    if dqBEXUDxeGybHKziJApkjPvMcRgmOt['availability']['value']['isPlayable']==dqBEXUDxeGybHKziJApkjPvMcRgmOa:
     continue
    dqBEXUDxeGybHKziJApkjPvMcRgmwS =dqBEXUDxeGybHKziJApkjPvMcRgmOt['summary']['value']['type']
    dqBEXUDxeGybHKziJApkjPvMcRgmTr =0 if dqBEXUDxeGybHKziJApkjPvMcRgmwS!='movie' else dqBEXUDxeGybHKziJApkjPvMcRgmOt['runtime']['value']
    if dqBEXUDxeGybHKziJApkjPvMcRgmOt['sequiturEvidence']['value']['value']:
     dqBEXUDxeGybHKziJApkjPvMcRgmOF=dqBEXUDxeGybHKziJApkjPvMcRgmOt['sequiturEvidence']['value']['value']['text']
    else:
     dqBEXUDxeGybHKziJApkjPvMcRgmOF=''
    dqBEXUDxeGybHKziJApkjPvMcRgmTt =dqBEXUDxeGybHKziJApkjPvMcRgmOt['boxarts'][dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_PORT]['jpg']['value']['url']
    dqBEXUDxeGybHKziJApkjPvMcRgmOW =dqBEXUDxeGybHKziJApkjPvMcRgmOt['boxarts'][dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND2]['jpg']['value']['url']
    dqBEXUDxeGybHKziJApkjPvMcRgmTF=''
    if 'value' in dqBEXUDxeGybHKziJApkjPvMcRgmOt['storyArt'][dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND2]['jpg']:
     dqBEXUDxeGybHKziJApkjPvMcRgmTF =dqBEXUDxeGybHKziJApkjPvMcRgmOt['storyArt'][dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND2]['jpg']['value']['url']
    if dqBEXUDxeGybHKziJApkjPvMcRgmTF=='' and 'value' in dqBEXUDxeGybHKziJApkjPvMcRgmOt['interestingMoment'][dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND1]['jpg']:
     dqBEXUDxeGybHKziJApkjPvMcRgmTF =dqBEXUDxeGybHKziJApkjPvMcRgmOt['interestingMoment'][dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LAND1]['jpg']['value']['url']
    dqBEXUDxeGybHKziJApkjPvMcRgmTh=''
    if 'value' in dqBEXUDxeGybHKziJApkjPvMcRgmOt['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LOGO]['png']:
     dqBEXUDxeGybHKziJApkjPvMcRgmTh=dqBEXUDxeGybHKziJApkjPvMcRgmOt['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][dqBEXUDxeGybHKziJApkjPvMcRgmwL.ART_SIZE_LOGO]['png']['value']['url']
    dqBEXUDxeGybHKziJApkjPvMcRgmTu =dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_Subid_List(dqBEXUDxeGybHKziJApkjPvMcRgmOt['genres'])
    for i in dqBEXUDxeGybHKziJApkjPvMcRgmlO(dqBEXUDxeGybHKziJApkjPvMcRgmlY(dqBEXUDxeGybHKziJApkjPvMcRgmTu)):
     dqBEXUDxeGybHKziJApkjPvMcRgmTu[i]=dqBEXUDxeGybHKziJApkjPvMcRgmOo[dqBEXUDxeGybHKziJApkjPvMcRgmTu[i]]['name']['value']
    dqBEXUDxeGybHKziJApkjPvMcRgmTs=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_Subid_List(dqBEXUDxeGybHKziJApkjPvMcRgmOt['directors'])
    dqBEXUDxeGybHKziJApkjPvMcRgmOs =dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_Subid_List(dqBEXUDxeGybHKziJApkjPvMcRgmOt['creators'])
    dqBEXUDxeGybHKziJApkjPvMcRgmTs.extend(dqBEXUDxeGybHKziJApkjPvMcRgmOs)
    for i in dqBEXUDxeGybHKziJApkjPvMcRgmlO(dqBEXUDxeGybHKziJApkjPvMcRgmlY(dqBEXUDxeGybHKziJApkjPvMcRgmTs)):
     dqBEXUDxeGybHKziJApkjPvMcRgmTs[i]=dqBEXUDxeGybHKziJApkjPvMcRgmOY[dqBEXUDxeGybHKziJApkjPvMcRgmTs[i]]['name']['value']
    dqBEXUDxeGybHKziJApkjPvMcRgmTW=dqBEXUDxeGybHKziJApkjPvMcRgmwL.NF_Subid_List(dqBEXUDxeGybHKziJApkjPvMcRgmOt['cast'])
    for i in dqBEXUDxeGybHKziJApkjPvMcRgmlO(dqBEXUDxeGybHKziJApkjPvMcRgmlY(dqBEXUDxeGybHKziJApkjPvMcRgmTW)):
     dqBEXUDxeGybHKziJApkjPvMcRgmTW[i]=dqBEXUDxeGybHKziJApkjPvMcRgmOY[dqBEXUDxeGybHKziJApkjPvMcRgmTW[i]]['name']['value']
    if 'maturityDescription' in dqBEXUDxeGybHKziJApkjPvMcRgmOt['maturity']['value']['rating']:
     dqBEXUDxeGybHKziJApkjPvMcRgmTn=dqBEXUDxeGybHKziJApkjPvMcRgmOt['maturity']['value']['rating']['maturityDescription']
    dqBEXUDxeGybHKziJApkjPvMcRgmTw={'videoid':dqBEXUDxeGybHKziJApkjPvMcRgmwh,'vidtype':dqBEXUDxeGybHKziJApkjPvMcRgmwS,'title':dqBEXUDxeGybHKziJApkjPvMcRgmLO,'mpaa':dqBEXUDxeGybHKziJApkjPvMcRgmTn,'regularSynopsis':dqBEXUDxeGybHKziJApkjPvMcRgmOt['regularSynopsis']['value'],'dpSupplemental':dqBEXUDxeGybHKziJApkjPvMcRgmOt['dpSupplementalMessage']['value'],'sequiturEvidence':dqBEXUDxeGybHKziJApkjPvMcRgmOF,'thumbnail':{'poster':dqBEXUDxeGybHKziJApkjPvMcRgmTt,'thumb':dqBEXUDxeGybHKziJApkjPvMcRgmTF,'fanart':dqBEXUDxeGybHKziJApkjPvMcRgmOW,'clearlogo':dqBEXUDxeGybHKziJApkjPvMcRgmTh},'year':dqBEXUDxeGybHKziJApkjPvMcRgmOt['releaseYear']['value'],'duration':dqBEXUDxeGybHKziJApkjPvMcRgmTr,'info_genre':dqBEXUDxeGybHKziJApkjPvMcRgmTu,'director':dqBEXUDxeGybHKziJApkjPvMcRgmTs,'cast':dqBEXUDxeGybHKziJApkjPvMcRgmTW,}
    dqBEXUDxeGybHKziJApkjPvMcRgmwC.append(dqBEXUDxeGybHKziJApkjPvMcRgmTw)
  return dqBEXUDxeGybHKziJApkjPvMcRgmwC,dqBEXUDxeGybHKziJApkjPvMcRgmwF,dqBEXUDxeGybHKziJApkjPvMcRgmOT
 def NF_Subid_List(dqBEXUDxeGybHKziJApkjPvMcRgmwL,subJson):
  dqBEXUDxeGybHKziJApkjPvMcRgmOu=[]
  try:
   for i in dqBEXUDxeGybHKziJApkjPvMcRgmlO(dqBEXUDxeGybHKziJApkjPvMcRgmlY(subJson)):
    if subJson.get(dqBEXUDxeGybHKziJApkjPvMcRgmOS(i)).get('$type')!='ref':break
    dqBEXUDxeGybHKziJApkjPvMcRgmOr=subJson.get(dqBEXUDxeGybHKziJApkjPvMcRgmOS(i)).get('value')[1]
    dqBEXUDxeGybHKziJApkjPvMcRgmOu.append(dqBEXUDxeGybHKziJApkjPvMcRgmOr)
  except dqBEXUDxeGybHKziJApkjPvMcRgmOI as exception:
   dqBEXUDxeGybHKziJApkjPvMcRgmOQ(exception)
  return dqBEXUDxeGybHKziJApkjPvMcRgmOu
# Created by pyminifier (https://github.com/liftoff/pyminifier)
