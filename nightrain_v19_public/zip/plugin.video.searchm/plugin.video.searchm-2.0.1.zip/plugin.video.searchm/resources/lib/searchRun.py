__author__="NightRain"
wVvJuqNhtRHzmeOoacXPTsGLEyQxbj=object
wVvJuqNhtRHzmeOoacXPTsGLEyQxbB=None
wVvJuqNhtRHzmeOoacXPTsGLEyQxbp=True
wVvJuqNhtRHzmeOoacXPTsGLEyQxbr=False
wVvJuqNhtRHzmeOoacXPTsGLEyQxbM=type
wVvJuqNhtRHzmeOoacXPTsGLEyQxbl=dict
wVvJuqNhtRHzmeOoacXPTsGLEyQxbi=open
wVvJuqNhtRHzmeOoacXPTsGLEyQxbU=len
wVvJuqNhtRHzmeOoacXPTsGLEyQxbA=Exception
wVvJuqNhtRHzmeOoacXPTsGLEyQxbK=str
wVvJuqNhtRHzmeOoacXPTsGLEyQxbf=int
wVvJuqNhtRHzmeOoacXPTsGLEyQxbF=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
wVvJuqNhtRHzmeOoacXPTsGLEyQxgn=[{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
wVvJuqNhtRHzmeOoacXPTsGLEyQxgS={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},}
wVvJuqNhtRHzmeOoacXPTsGLEyQxgb=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
wVvJuqNhtRHzmeOoacXPTsGLEyQxgd =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class wVvJuqNhtRHzmeOoacXPTsGLEyQxgI(wVvJuqNhtRHzmeOoacXPTsGLEyQxbj):
 def __init__(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,wVvJuqNhtRHzmeOoacXPTsGLEyQxgW,wVvJuqNhtRHzmeOoacXPTsGLEyQxgj,wVvJuqNhtRHzmeOoacXPTsGLEyQxgB):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY._addon_url =wVvJuqNhtRHzmeOoacXPTsGLEyQxgW
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY._addon_handle=wVvJuqNhtRHzmeOoacXPTsGLEyQxgj
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.main_params =wVvJuqNhtRHzmeOoacXPTsGLEyQxgB
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj =dqBEXUDxeGybHKziJApkjPvMcRgmwT() 
 def addon_noti(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,sting):
  try:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgr=xbmcgui.Dialog()
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgr.notification(__addonname__,sting)
  except:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxbB
 def addon_log(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,string):
  try:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgM=string.encode('utf-8','ignore')
  except:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgM='addonException: addon_log'
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgl=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,wVvJuqNhtRHzmeOoacXPTsGLEyQxgM),level=wVvJuqNhtRHzmeOoacXPTsGLEyQxgl)
 def get_keyboard_input(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,wVvJuqNhtRHzmeOoacXPTsGLEyQxgk):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgi=wVvJuqNhtRHzmeOoacXPTsGLEyQxbB
  kb=xbmc.Keyboard()
  kb.setHeading(wVvJuqNhtRHzmeOoacXPTsGLEyQxgk)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgi=kb.getText()
  return wVvJuqNhtRHzmeOoacXPTsGLEyQxgi
 def get_settings_select_info(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgU=[]
  if __addon__.getSetting('netflixyn')=='true':wVvJuqNhtRHzmeOoacXPTsGLEyQxgU.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':wVvJuqNhtRHzmeOoacXPTsGLEyQxgU.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':wVvJuqNhtRHzmeOoacXPTsGLEyQxgU.append('tving')
  if __addon__.getSetting('watchayn')=='true':wVvJuqNhtRHzmeOoacXPTsGLEyQxgU.append('watcha')
  return wVvJuqNhtRHzmeOoacXPTsGLEyQxgU
 def get_settings_netflix(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgA =__addon__.getSetting('nfid')
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgK =__addon__.getSetting('nfpw')
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgf=__addon__.getSetting('nf_profile')
  return(wVvJuqNhtRHzmeOoacXPTsGLEyQxgA,wVvJuqNhtRHzmeOoacXPTsGLEyQxgK,wVvJuqNhtRHzmeOoacXPTsGLEyQxgf)
 def add_dir(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,label,sublabel='',img='',infoLabels=wVvJuqNhtRHzmeOoacXPTsGLEyQxbB,isFolder=wVvJuqNhtRHzmeOoacXPTsGLEyQxbp,params='',isLink=wVvJuqNhtRHzmeOoacXPTsGLEyQxbr,ContextMenu=wVvJuqNhtRHzmeOoacXPTsGLEyQxbB):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgF='%s?%s'%(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY._addon_url,urllib.parse.urlencode(params))
  if sublabel:wVvJuqNhtRHzmeOoacXPTsGLEyQxgk='%s < %s >'%(label,sublabel)
  else: wVvJuqNhtRHzmeOoacXPTsGLEyQxgk=label
  if not img:img='DefaultFolder.png'
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgC=xbmcgui.ListItem(wVvJuqNhtRHzmeOoacXPTsGLEyQxgk)
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxbM(img)==wVvJuqNhtRHzmeOoacXPTsGLEyQxbl:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgC.setArt(img)
  else:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgC.setArt({'thumb':img,'poster':img})
  if infoLabels:wVvJuqNhtRHzmeOoacXPTsGLEyQxgC.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgC.setProperty('IsPlayable','true')
  if ContextMenu:wVvJuqNhtRHzmeOoacXPTsGLEyQxgC.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY._addon_handle,wVvJuqNhtRHzmeOoacXPTsGLEyQxgF,wVvJuqNhtRHzmeOoacXPTsGLEyQxgC,isFolder)
 def Load_Searched_List(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY):
  try:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgD=wVvJuqNhtRHzmeOoacXPTsGLEyQxgd
   fp=wVvJuqNhtRHzmeOoacXPTsGLEyQxbi(wVvJuqNhtRHzmeOoacXPTsGLEyQxgD,'r',-1,'utf-8')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIg=fp.readlines()
   fp.close()
  except:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIg=[]
  return wVvJuqNhtRHzmeOoacXPTsGLEyQxIg
 def Save_Searched_List(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,wVvJuqNhtRHzmeOoacXPTsGLEyQxnD):
  try:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgD=wVvJuqNhtRHzmeOoacXPTsGLEyQxgd
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIn=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.Load_Searched_List() 
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIS={'skey':wVvJuqNhtRHzmeOoacXPTsGLEyQxnD.strip()}
   fp=wVvJuqNhtRHzmeOoacXPTsGLEyQxbi(wVvJuqNhtRHzmeOoacXPTsGLEyQxgD,'w',-1,'utf-8')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIb=urllib.parse.urlencode(wVvJuqNhtRHzmeOoacXPTsGLEyQxIS)
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIb=wVvJuqNhtRHzmeOoacXPTsGLEyQxIb+'\n'
   fp.write(wVvJuqNhtRHzmeOoacXPTsGLEyQxIb)
   wVvJuqNhtRHzmeOoacXPTsGLEyQxId=0
   for wVvJuqNhtRHzmeOoacXPTsGLEyQxIY in wVvJuqNhtRHzmeOoacXPTsGLEyQxIn:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxIW=wVvJuqNhtRHzmeOoacXPTsGLEyQxbl(urllib.parse.parse_qsl(wVvJuqNhtRHzmeOoacXPTsGLEyQxIY))
    wVvJuqNhtRHzmeOoacXPTsGLEyQxIj=wVvJuqNhtRHzmeOoacXPTsGLEyQxIS.get('skey').strip()
    wVvJuqNhtRHzmeOoacXPTsGLEyQxIB=wVvJuqNhtRHzmeOoacXPTsGLEyQxIW.get('skey').strip()
    if wVvJuqNhtRHzmeOoacXPTsGLEyQxIj!=wVvJuqNhtRHzmeOoacXPTsGLEyQxIB:
     fp.write(wVvJuqNhtRHzmeOoacXPTsGLEyQxIY)
     wVvJuqNhtRHzmeOoacXPTsGLEyQxId+=1
     if wVvJuqNhtRHzmeOoacXPTsGLEyQxId>=50:break
   fp.close()
  except:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxbB
 def dp_Search_History(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxIp=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.Load_Searched_List()
  for wVvJuqNhtRHzmeOoacXPTsGLEyQxIr in wVvJuqNhtRHzmeOoacXPTsGLEyQxIp:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIM=wVvJuqNhtRHzmeOoacXPTsGLEyQxbl(urllib.parse.parse_qsl(wVvJuqNhtRHzmeOoacXPTsGLEyQxIr))
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIl=wVvJuqNhtRHzmeOoacXPTsGLEyQxIM.get('skey').strip()
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIi={'mode':'TOTAL_SEARCH','search_key':wVvJuqNhtRHzmeOoacXPTsGLEyQxIl,}
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIU={'mode':'HISTORY_REMOVE','skey':wVvJuqNhtRHzmeOoacXPTsGLEyQxIl,'delmode':'ONE',}
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIA=urllib.parse.urlencode(wVvJuqNhtRHzmeOoacXPTsGLEyQxIU)
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIK=[('선택된 검색어 ( %s ) 삭제'%(wVvJuqNhtRHzmeOoacXPTsGLEyQxIl),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(wVvJuqNhtRHzmeOoacXPTsGLEyQxIA))]
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.add_dir(wVvJuqNhtRHzmeOoacXPTsGLEyQxIl,sublabel='',img=wVvJuqNhtRHzmeOoacXPTsGLEyQxbB,infoLabels=wVvJuqNhtRHzmeOoacXPTsGLEyQxbB,isFolder=wVvJuqNhtRHzmeOoacXPTsGLEyQxbp,params=wVvJuqNhtRHzmeOoacXPTsGLEyQxIi,ContextMenu=wVvJuqNhtRHzmeOoacXPTsGLEyQxIK)
  wVvJuqNhtRHzmeOoacXPTsGLEyQxIF={'plot':'검색목록 전체를 삭제합니다.'}
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgk='*** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) ***'
  wVvJuqNhtRHzmeOoacXPTsGLEyQxIi={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  wVvJuqNhtRHzmeOoacXPTsGLEyQxIk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.add_dir(wVvJuqNhtRHzmeOoacXPTsGLEyQxgk,sublabel='',img=wVvJuqNhtRHzmeOoacXPTsGLEyQxIk,infoLabels=wVvJuqNhtRHzmeOoacXPTsGLEyQxIF,isFolder=wVvJuqNhtRHzmeOoacXPTsGLEyQxbr,params=wVvJuqNhtRHzmeOoacXPTsGLEyQxIi,isLink=wVvJuqNhtRHzmeOoacXPTsGLEyQxbp)
  xbmcplugin.endOfDirectory(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY._addon_handle,cacheToDisc=wVvJuqNhtRHzmeOoacXPTsGLEyQxbr)
 def Delete_History_List(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,wVvJuqNhtRHzmeOoacXPTsGLEyQxIl,wVvJuqNhtRHzmeOoacXPTsGLEyQxng):
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxng=='ALL':
   try:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxgD=wVvJuqNhtRHzmeOoacXPTsGLEyQxgd
    fp=wVvJuqNhtRHzmeOoacXPTsGLEyQxbi(wVvJuqNhtRHzmeOoacXPTsGLEyQxgD,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxbB
  else:
   try:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxgD=wVvJuqNhtRHzmeOoacXPTsGLEyQxgd
    wVvJuqNhtRHzmeOoacXPTsGLEyQxIn=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.Load_Searched_List() 
    fp=wVvJuqNhtRHzmeOoacXPTsGLEyQxbi(wVvJuqNhtRHzmeOoacXPTsGLEyQxgD,'w',-1,'utf-8')
    for wVvJuqNhtRHzmeOoacXPTsGLEyQxIY in wVvJuqNhtRHzmeOoacXPTsGLEyQxIn:
     wVvJuqNhtRHzmeOoacXPTsGLEyQxIW=wVvJuqNhtRHzmeOoacXPTsGLEyQxbl(urllib.parse.parse_qsl(wVvJuqNhtRHzmeOoacXPTsGLEyQxIY))
     wVvJuqNhtRHzmeOoacXPTsGLEyQxID=wVvJuqNhtRHzmeOoacXPTsGLEyQxIW.get('skey').strip()
     if wVvJuqNhtRHzmeOoacXPTsGLEyQxIl!=wVvJuqNhtRHzmeOoacXPTsGLEyQxID:
      fp.write(wVvJuqNhtRHzmeOoacXPTsGLEyQxIY)
    fp.close()
   except:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxbB
 def dp_History_Delete(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,args):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxIl =args.get('skey') 
  wVvJuqNhtRHzmeOoacXPTsGLEyQxng=args.get('delmode')
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgr=xbmcgui.Dialog()
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxng=='ALL':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxnI=wVvJuqNhtRHzmeOoacXPTsGLEyQxgr.yesno(__language__(30913).encode('utf8'),__language__(30915).encode('utf8'))
  else:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxnI=wVvJuqNhtRHzmeOoacXPTsGLEyQxgr.yesno(__language__(30914).encode('utf8'),__language__(30915).encode('utf8'))
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxnI==wVvJuqNhtRHzmeOoacXPTsGLEyQxbr:sys.exit()
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.Delete_History_List(wVvJuqNhtRHzmeOoacXPTsGLEyQxIl,wVvJuqNhtRHzmeOoacXPTsGLEyQxng)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY):
  for wVvJuqNhtRHzmeOoacXPTsGLEyQxnS in wVvJuqNhtRHzmeOoacXPTsGLEyQxgn:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgk=wVvJuqNhtRHzmeOoacXPTsGLEyQxnS.get('title')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIk=''
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIi={'mode':wVvJuqNhtRHzmeOoacXPTsGLEyQxnS.get('mode')}
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxnS.get('mode')=='XXX':
    wVvJuqNhtRHzmeOoacXPTsGLEyQxIi['mode']='XXX'
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnb=wVvJuqNhtRHzmeOoacXPTsGLEyQxbr
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnd =wVvJuqNhtRHzmeOoacXPTsGLEyQxbp
   else:
    if 'icon' in wVvJuqNhtRHzmeOoacXPTsGLEyQxnS:
     wVvJuqNhtRHzmeOoacXPTsGLEyQxIk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',wVvJuqNhtRHzmeOoacXPTsGLEyQxnS.get('icon')) 
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnb=wVvJuqNhtRHzmeOoacXPTsGLEyQxbp
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnd =wVvJuqNhtRHzmeOoacXPTsGLEyQxbr
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.add_dir(wVvJuqNhtRHzmeOoacXPTsGLEyQxgk,sublabel='',img=wVvJuqNhtRHzmeOoacXPTsGLEyQxIk,infoLabels=wVvJuqNhtRHzmeOoacXPTsGLEyQxbB,isFolder=wVvJuqNhtRHzmeOoacXPTsGLEyQxnb,params=wVvJuqNhtRHzmeOoacXPTsGLEyQxIi,isLink=wVvJuqNhtRHzmeOoacXPTsGLEyQxnd)
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxbU(wVvJuqNhtRHzmeOoacXPTsGLEyQxgn)>0:xbmcplugin.endOfDirectory(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY._addon_handle)
 def option_check(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgU=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.get_settings_select_info()
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxbU(wVvJuqNhtRHzmeOoacXPTsGLEyQxgU)==0:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgr=xbmcgui.Dialog()
   wVvJuqNhtRHzmeOoacXPTsGLEyQxnI=wVvJuqNhtRHzmeOoacXPTsGLEyQxgr.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxnI==wVvJuqNhtRHzmeOoacXPTsGLEyQxbp:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in wVvJuqNhtRHzmeOoacXPTsGLEyQxgU:
   (wVvJuqNhtRHzmeOoacXPTsGLEyQxnY,wVvJuqNhtRHzmeOoacXPTsGLEyQxnW,wVvJuqNhtRHzmeOoacXPTsGLEyQxnj)=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.get_settings_netflix()
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxnY=='' or wVvJuqNhtRHzmeOoacXPTsGLEyQxnW=='':
    wVvJuqNhtRHzmeOoacXPTsGLEyQxgr=xbmcgui.Dialog()
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnI=wVvJuqNhtRHzmeOoacXPTsGLEyQxgr.yesno(__language__(30902).encode('utf8'),__language__(30903).encode('utf8'))
    if wVvJuqNhtRHzmeOoacXPTsGLEyQxnI==wVvJuqNhtRHzmeOoacXPTsGLEyQxbp:
     __addon__.openSettings()
     sys.exit()
    else:
     sys.exit()
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.NF_cookiefile_check()==wVvJuqNhtRHzmeOoacXPTsGLEyQxbr:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxgr=xbmcgui.Dialog()
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnI=wVvJuqNhtRHzmeOoacXPTsGLEyQxgr.yesno(__language__(30907).encode('utf8'),__language__(30916).encode('utf8'))
    if wVvJuqNhtRHzmeOoacXPTsGLEyQxnI==wVvJuqNhtRHzmeOoacXPTsGLEyQxbp:
     if wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.NF_login(inputCheck=wVvJuqNhtRHzmeOoacXPTsGLEyQxbr)==wVvJuqNhtRHzmeOoacXPTsGLEyQxbr:
      sys.exit()
    else:
     sys.exit()
 def NF_cookiefile_check(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnB={}
  try: 
   fp=wVvJuqNhtRHzmeOoacXPTsGLEyQxbi(wVvJuqNhtRHzmeOoacXPTsGLEyQxgb,'r',-1,'utf-8')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxnB= json.load(fp)
   fp.close()
  except wVvJuqNhtRHzmeOoacXPTsGLEyQxbA as exception:
   return wVvJuqNhtRHzmeOoacXPTsGLEyQxbr
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.NF=wVvJuqNhtRHzmeOoacXPTsGLEyQxnB
  (wVvJuqNhtRHzmeOoacXPTsGLEyQxnY,wVvJuqNhtRHzmeOoacXPTsGLEyQxnW,wVvJuqNhtRHzmeOoacXPTsGLEyQxnj)=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.get_settings_netflix()
  (wVvJuqNhtRHzmeOoacXPTsGLEyQxnp,wVvJuqNhtRHzmeOoacXPTsGLEyQxnr,wVvJuqNhtRHzmeOoacXPTsGLEyQxnM)=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Load_session_acount()
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxnY!=wVvJuqNhtRHzmeOoacXPTsGLEyQxnp or wVvJuqNhtRHzmeOoacXPTsGLEyQxnW!=wVvJuqNhtRHzmeOoacXPTsGLEyQxnr or wVvJuqNhtRHzmeOoacXPTsGLEyQxnj!=wVvJuqNhtRHzmeOoacXPTsGLEyQxbK(wVvJuqNhtRHzmeOoacXPTsGLEyQxnM):
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Init_NF_Total()
   return wVvJuqNhtRHzmeOoacXPTsGLEyQxbr
  return wVvJuqNhtRHzmeOoacXPTsGLEyQxbp
 def NF_login(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,inputCheck=wVvJuqNhtRHzmeOoacXPTsGLEyQxbp):
  (wVvJuqNhtRHzmeOoacXPTsGLEyQxnl,wVvJuqNhtRHzmeOoacXPTsGLEyQxni,wVvJuqNhtRHzmeOoacXPTsGLEyQxnU)=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.get_settings_netflix()
  if inputCheck==wVvJuqNhtRHzmeOoacXPTsGLEyQxbp:
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxnl=='' or wVvJuqNhtRHzmeOoacXPTsGLEyQxni=='':
    wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_noti(__language__(30902).encode('utf-8'))
    return wVvJuqNhtRHzmeOoacXPTsGLEyQxbr
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgr=xbmcgui.Dialog()
   wVvJuqNhtRHzmeOoacXPTsGLEyQxnI=wVvJuqNhtRHzmeOoacXPTsGLEyQxgr.yesno(__language__(30911).encode('utf8'),__language__(30912).encode('utf8'))
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxnI==wVvJuqNhtRHzmeOoacXPTsGLEyQxbr:
    return wVvJuqNhtRHzmeOoacXPTsGLEyQxbr 
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnA=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_NF_BaseCookies()
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxnA:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_log('pass1 ok!')
  else:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_log('pass1 error!')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_noti(__language__(30905).encode('utf-8'))
   return wVvJuqNhtRHzmeOoacXPTsGLEyQxbr 
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnA=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_NF_BaseLogin(wVvJuqNhtRHzmeOoacXPTsGLEyQxnl,wVvJuqNhtRHzmeOoacXPTsGLEyQxni,wVvJuqNhtRHzmeOoacXPTsGLEyQxnU)
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxnA:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_log('pass2 ok!')
  else:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_log('pass2 error!')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_noti(__language__(30905).encode('utf-8'))
   return wVvJuqNhtRHzmeOoacXPTsGLEyQxbr 
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnA=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_NF_ActivateProfile()
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxnA:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_log('pass3 ok!')
  else:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_log('pass3 error!')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_noti(__language__(30905).encode('utf-8'))
   return wVvJuqNhtRHzmeOoacXPTsGLEyQxbr 
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnA=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_NF_BrowseMain()
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxnA:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_log('pass4 ok!')
  else:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_log('pass4 error!')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_noti(__language__(30905).encode('utf-8'))
   return wVvJuqNhtRHzmeOoacXPTsGLEyQxbr 
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnK =wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_Now_Datetime()
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnf=wVvJuqNhtRHzmeOoacXPTsGLEyQxnK+datetime.timedelta(days=wVvJuqNhtRHzmeOoacXPTsGLEyQxbf(__addon__.getSetting('cache_ttl')))
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.NF['SESSION']['limitdate']=wVvJuqNhtRHzmeOoacXPTsGLEyQxnf.strftime('%Y-%m-%d')
  try: 
   fp=wVvJuqNhtRHzmeOoacXPTsGLEyQxbi(wVvJuqNhtRHzmeOoacXPTsGLEyQxgb,'w',-1,'utf-8')
   json.dump(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.NF,fp)
   fp.close()
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_log('pass5 save ok!')
  except wVvJuqNhtRHzmeOoacXPTsGLEyQxbA as exception:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_log('pass5 save error!')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_noti(__language__(30905).encode('utf-8'))
   return wVvJuqNhtRHzmeOoacXPTsGLEyQxbr
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_noti(__language__(30904).encode('utf-8'))
  return wVvJuqNhtRHzmeOoacXPTsGLEyQxbp
 def NF_logout(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgr=xbmcgui.Dialog()
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnI=wVvJuqNhtRHzmeOoacXPTsGLEyQxgr.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxnI==wVvJuqNhtRHzmeOoacXPTsGLEyQxbr:return 
  if os.path.isfile(wVvJuqNhtRHzmeOoacXPTsGLEyQxgb):os.remove(wVvJuqNhtRHzmeOoacXPTsGLEyQxgb)
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,wVvJuqNhtRHzmeOoacXPTsGLEyQxSg):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnF=''
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnk=7
  try:
   for i in wVvJuqNhtRHzmeOoacXPTsGLEyQxbF(wVvJuqNhtRHzmeOoacXPTsGLEyQxbU(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg)):
    if i>=wVvJuqNhtRHzmeOoacXPTsGLEyQxnk:
     wVvJuqNhtRHzmeOoacXPTsGLEyQxnF=wVvJuqNhtRHzmeOoacXPTsGLEyQxnF+'...'
     break
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnF=wVvJuqNhtRHzmeOoacXPTsGLEyQxnF+wVvJuqNhtRHzmeOoacXPTsGLEyQxSg[i]['title']+'\n'
  except:
   return ''
  return wVvJuqNhtRHzmeOoacXPTsGLEyQxnF
 def dp_Search_Group(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,args):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgU =wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.get_settings_select_info()
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnC=[]
  if 'search_key' in args:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxnD=args.get('search_key')
  else:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxnD=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not wVvJuqNhtRHzmeOoacXPTsGLEyQxnD:
    xbmcplugin.endOfDirectory(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY._addon_handle)
    return
  if 'wavve' in wVvJuqNhtRHzmeOoacXPTsGLEyQxgU:
   (wVvJuqNhtRHzmeOoacXPTsGLEyQxSg,wVvJuqNhtRHzmeOoacXPTsGLEyQxSI)=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_Search_Wavve(wVvJuqNhtRHzmeOoacXPTsGLEyQxnD,'TVSHOW',1)
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxbU(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg)>0:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxSn={'sType':'wavve_tvshow','sList':wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.MakeText_FreeList(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg),}
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnC.append(wVvJuqNhtRHzmeOoacXPTsGLEyQxSn)
   (wVvJuqNhtRHzmeOoacXPTsGLEyQxSg,wVvJuqNhtRHzmeOoacXPTsGLEyQxSI)=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_Search_Wavve(wVvJuqNhtRHzmeOoacXPTsGLEyQxnD,'MOVIE',1)
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxbU(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg)>0:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxSn={'sType':'wavve_movie','sList':wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.MakeText_FreeList(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg),}
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnC.append(wVvJuqNhtRHzmeOoacXPTsGLEyQxSn)
  if 'tving' in wVvJuqNhtRHzmeOoacXPTsGLEyQxgU:
   (wVvJuqNhtRHzmeOoacXPTsGLEyQxSg,wVvJuqNhtRHzmeOoacXPTsGLEyQxSI)=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_Search_Tving(wVvJuqNhtRHzmeOoacXPTsGLEyQxnD,'TVSHOW',1)
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxbU(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg)>0:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxSn={'sType':'tving_tvshow','sList':wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.MakeText_FreeList(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg),}
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnC.append(wVvJuqNhtRHzmeOoacXPTsGLEyQxSn)
   (wVvJuqNhtRHzmeOoacXPTsGLEyQxSg,wVvJuqNhtRHzmeOoacXPTsGLEyQxSI)=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_Search_Tving(wVvJuqNhtRHzmeOoacXPTsGLEyQxnD,'MOVIE',1)
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxbU(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg)>0:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxSn={'sType':'tving_movie','sList':wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.MakeText_FreeList(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg),}
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnC.append(wVvJuqNhtRHzmeOoacXPTsGLEyQxSn)
  if 'watcha' in wVvJuqNhtRHzmeOoacXPTsGLEyQxgU:
   (wVvJuqNhtRHzmeOoacXPTsGLEyQxSg,wVvJuqNhtRHzmeOoacXPTsGLEyQxSI)=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_Search_Watcha(wVvJuqNhtRHzmeOoacXPTsGLEyQxnD,1)
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxbU(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg)>0:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxSn={'sType':'watcha_list','sList':wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.MakeText_FreeList(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg),}
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnC.append(wVvJuqNhtRHzmeOoacXPTsGLEyQxSn)
  if 'netflix' in wVvJuqNhtRHzmeOoacXPTsGLEyQxgU:
   (wVvJuqNhtRHzmeOoacXPTsGLEyQxSg,wVvJuqNhtRHzmeOoacXPTsGLEyQxSI,wVvJuqNhtRHzmeOoacXPTsGLEyQxSb)=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_Search_Netflix(wVvJuqNhtRHzmeOoacXPTsGLEyQxnD,1)
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxbU(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg)>0:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxSn={'sType':'netflix_list','sList':wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.MakeText_FreeList(wVvJuqNhtRHzmeOoacXPTsGLEyQxSg),}
    wVvJuqNhtRHzmeOoacXPTsGLEyQxnC.append(wVvJuqNhtRHzmeOoacXPTsGLEyQxSn)
  for wVvJuqNhtRHzmeOoacXPTsGLEyQxSd in wVvJuqNhtRHzmeOoacXPTsGLEyQxnC:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSY=wVvJuqNhtRHzmeOoacXPTsGLEyQxgS[wVvJuqNhtRHzmeOoacXPTsGLEyQxSd.get('sType')]
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSW={'plot':'검색어 : '+wVvJuqNhtRHzmeOoacXPTsGLEyQxnD+'\n\n'+wVvJuqNhtRHzmeOoacXPTsGLEyQxSd.get('sList')}
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgk=wVvJuqNhtRHzmeOoacXPTsGLEyQxSY.get('title')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIi={'mode':wVvJuqNhtRHzmeOoacXPTsGLEyQxSY.get('mode'),'ott':wVvJuqNhtRHzmeOoacXPTsGLEyQxSY.get('ott'),'vidtype':wVvJuqNhtRHzmeOoacXPTsGLEyQxSY.get('vidtype'),'search_key':wVvJuqNhtRHzmeOoacXPTsGLEyQxnD}
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxSY.get('ott')=='netflix':
    wVvJuqNhtRHzmeOoacXPTsGLEyQxIi['page'] ='1'
    wVvJuqNhtRHzmeOoacXPTsGLEyQxIi['byReference']='-'
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',wVvJuqNhtRHzmeOoacXPTsGLEyQxSY.get('icon'))
   wVvJuqNhtRHzmeOoacXPTsGLEyQxnb=wVvJuqNhtRHzmeOoacXPTsGLEyQxbp if wVvJuqNhtRHzmeOoacXPTsGLEyQxSY.get('mode')!='HYPER_LINK' else wVvJuqNhtRHzmeOoacXPTsGLEyQxbr
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.add_dir(wVvJuqNhtRHzmeOoacXPTsGLEyQxgk,sublabel='',img=wVvJuqNhtRHzmeOoacXPTsGLEyQxIk,infoLabels=wVvJuqNhtRHzmeOoacXPTsGLEyQxSW,isFolder=wVvJuqNhtRHzmeOoacXPTsGLEyQxnb,params=wVvJuqNhtRHzmeOoacXPTsGLEyQxIi,isLink=wVvJuqNhtRHzmeOoacXPTsGLEyQxbp)
  xbmcplugin.endOfDirectory(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY._addon_handle)
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.Save_Searched_List(wVvJuqNhtRHzmeOoacXPTsGLEyQxnD)
 def dp_Hyper_Link(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,args):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxSj =args.get('mode')
  wVvJuqNhtRHzmeOoacXPTsGLEyQxSB =args.get('ott')
  wVvJuqNhtRHzmeOoacXPTsGLEyQxSp =args.get('vidtype')
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnD=args.get('search_key')
  wVvJuqNhtRHzmeOoacXPTsGLEyQxSr='-'
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxSB=='wavve':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSM={'mode':'LOCAL_SEARCH','sType':'movie' if wVvJuqNhtRHzmeOoacXPTsGLEyQxSp=='MOVIE' else 'vod','search_key':wVvJuqNhtRHzmeOoacXPTsGLEyQxnD,'page':'1',}
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSl=urllib.parse.urlencode(wVvJuqNhtRHzmeOoacXPTsGLEyQxSM)
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSr='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(wVvJuqNhtRHzmeOoacXPTsGLEyQxSl)
  elif wVvJuqNhtRHzmeOoacXPTsGLEyQxSB=='tving':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSM={'mode':'LOCAL_SEARCH','stype':'movie' if wVvJuqNhtRHzmeOoacXPTsGLEyQxSp=='MOVIE' else 'vod','search_key':wVvJuqNhtRHzmeOoacXPTsGLEyQxnD,'page':'1',}
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSl=urllib.parse.urlencode(wVvJuqNhtRHzmeOoacXPTsGLEyQxSM)
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSr='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(wVvJuqNhtRHzmeOoacXPTsGLEyQxSl)
  elif wVvJuqNhtRHzmeOoacXPTsGLEyQxSB=='watcha':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSM={'mode':'LOCAL_SEARCH','search_key':wVvJuqNhtRHzmeOoacXPTsGLEyQxnD,'page':'1',}
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSl=urllib.parse.urlencode(wVvJuqNhtRHzmeOoacXPTsGLEyQxSM)
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSr='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(wVvJuqNhtRHzmeOoacXPTsGLEyQxSl)
  elif wVvJuqNhtRHzmeOoacXPTsGLEyQxSB=='netflix':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSi=args.get('videoid')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSU=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.NF['SESSION']['nowGuid']
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxSp=='TVSHOW':
    wVvJuqNhtRHzmeOoacXPTsGLEyQxSr='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(wVvJuqNhtRHzmeOoacXPTsGLEyQxSi)
   else:
    wVvJuqNhtRHzmeOoacXPTsGLEyQxSr='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(wVvJuqNhtRHzmeOoacXPTsGLEyQxSi,wVvJuqNhtRHzmeOoacXPTsGLEyQxSU)
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.addon_log('ott_url ==> ( '+wVvJuqNhtRHzmeOoacXPTsGLEyQxSr+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(wVvJuqNhtRHzmeOoacXPTsGLEyQxSr)
 def dp_Nf_Search(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY,args):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxSA =wVvJuqNhtRHzmeOoacXPTsGLEyQxbf(args.get('page'))
  wVvJuqNhtRHzmeOoacXPTsGLEyQxnD =args.get('search_key')
  wVvJuqNhtRHzmeOoacXPTsGLEyQxSb=args.get('byReference')
  (wVvJuqNhtRHzmeOoacXPTsGLEyQxSg,wVvJuqNhtRHzmeOoacXPTsGLEyQxSI,wVvJuqNhtRHzmeOoacXPTsGLEyQxSb)=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.SearchObj.Get_Search_Netflix(wVvJuqNhtRHzmeOoacXPTsGLEyQxnD,wVvJuqNhtRHzmeOoacXPTsGLEyQxSA,byReference=wVvJuqNhtRHzmeOoacXPTsGLEyQxSb)
  for wVvJuqNhtRHzmeOoacXPTsGLEyQxSK in wVvJuqNhtRHzmeOoacXPTsGLEyQxSg:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSi =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('videoid')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSp =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('vidtype')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgk =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('title')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSf =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('mpaa')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSF =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('regularSynopsis')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSk =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('dpSupplemental')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSC=wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('sequiturEvidence')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxSD =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('thumbnail')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxbg =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('year')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxbI =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('duration')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxbn =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('info_genre')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxbS =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('director')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxbd =wVvJuqNhtRHzmeOoacXPTsGLEyQxSK.get('cast')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIf=wVvJuqNhtRHzmeOoacXPTsGLEyQxbK(wVvJuqNhtRHzmeOoacXPTsGLEyQxbg)if wVvJuqNhtRHzmeOoacXPTsGLEyQxSp=='movie' else ''
   wVvJuqNhtRHzmeOoacXPTsGLEyQxbY=''
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxSF:wVvJuqNhtRHzmeOoacXPTsGLEyQxbY=wVvJuqNhtRHzmeOoacXPTsGLEyQxbY+'\n\n'+wVvJuqNhtRHzmeOoacXPTsGLEyQxSF
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxSk :wVvJuqNhtRHzmeOoacXPTsGLEyQxbY=wVvJuqNhtRHzmeOoacXPTsGLEyQxbY+'\n\n'+wVvJuqNhtRHzmeOoacXPTsGLEyQxSk
   if wVvJuqNhtRHzmeOoacXPTsGLEyQxSC:wVvJuqNhtRHzmeOoacXPTsGLEyQxbY=wVvJuqNhtRHzmeOoacXPTsGLEyQxbY+'\n\n'+wVvJuqNhtRHzmeOoacXPTsGLEyQxSC
   wVvJuqNhtRHzmeOoacXPTsGLEyQxbY=wVvJuqNhtRHzmeOoacXPTsGLEyQxbY.strip()
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIF={'mediatype':'tvshow' if wVvJuqNhtRHzmeOoacXPTsGLEyQxSp=='show' else 'movie','title':wVvJuqNhtRHzmeOoacXPTsGLEyQxgk,'mpaa':wVvJuqNhtRHzmeOoacXPTsGLEyQxSf,'plot':wVvJuqNhtRHzmeOoacXPTsGLEyQxbY,'duration':wVvJuqNhtRHzmeOoacXPTsGLEyQxbI,'genre':wVvJuqNhtRHzmeOoacXPTsGLEyQxbn,'director':wVvJuqNhtRHzmeOoacXPTsGLEyQxbS,'cast':wVvJuqNhtRHzmeOoacXPTsGLEyQxbd,}
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIi={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if wVvJuqNhtRHzmeOoacXPTsGLEyQxSp=='show' else 'MOVIE','videoid':wVvJuqNhtRHzmeOoacXPTsGLEyQxSi,}
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.add_dir(wVvJuqNhtRHzmeOoacXPTsGLEyQxgk,sublabel=wVvJuqNhtRHzmeOoacXPTsGLEyQxIf,img=wVvJuqNhtRHzmeOoacXPTsGLEyQxSD,infoLabels=wVvJuqNhtRHzmeOoacXPTsGLEyQxIF,isFolder=wVvJuqNhtRHzmeOoacXPTsGLEyQxbr,params=wVvJuqNhtRHzmeOoacXPTsGLEyQxIi,isLink=wVvJuqNhtRHzmeOoacXPTsGLEyQxbp)
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxSI:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIi={}
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIi['mode'] ='NF_SEARCH' 
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIi['page'] =wVvJuqNhtRHzmeOoacXPTsGLEyQxbK(wVvJuqNhtRHzmeOoacXPTsGLEyQxSA+1)
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIi['search_key']=wVvJuqNhtRHzmeOoacXPTsGLEyQxnD
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIi['byReference']=wVvJuqNhtRHzmeOoacXPTsGLEyQxSb
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgk='[B]%s >>[/B]'%'다음 페이지'
   wVvJuqNhtRHzmeOoacXPTsGLEyQxbW=wVvJuqNhtRHzmeOoacXPTsGLEyQxbK(wVvJuqNhtRHzmeOoacXPTsGLEyQxSA+1)
   wVvJuqNhtRHzmeOoacXPTsGLEyQxIk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.add_dir(wVvJuqNhtRHzmeOoacXPTsGLEyQxgk,sublabel=wVvJuqNhtRHzmeOoacXPTsGLEyQxbW,img=wVvJuqNhtRHzmeOoacXPTsGLEyQxIk,infoLabels=wVvJuqNhtRHzmeOoacXPTsGLEyQxbB,isFolder=wVvJuqNhtRHzmeOoacXPTsGLEyQxbp,params=wVvJuqNhtRHzmeOoacXPTsGLEyQxIi)
  xbmcplugin.endOfDirectory(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY._addon_handle)
 def search_main(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY):
  wVvJuqNhtRHzmeOoacXPTsGLEyQxSj=wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.main_params.get('mode',wVvJuqNhtRHzmeOoacXPTsGLEyQxbB)
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxSj=='NFLOGOUT':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.NF_logout()
   return
  elif wVvJuqNhtRHzmeOoacXPTsGLEyQxSj=='NFLOGIN':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.NF_login()
   return
  wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.option_check()
  if wVvJuqNhtRHzmeOoacXPTsGLEyQxSj is wVvJuqNhtRHzmeOoacXPTsGLEyQxbB:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.dp_Main_List()
  elif wVvJuqNhtRHzmeOoacXPTsGLEyQxSj=='TOTAL_SEARCH':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.dp_Search_Group(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.main_params)
  elif wVvJuqNhtRHzmeOoacXPTsGLEyQxSj=='HYPER_LINK':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.dp_Hyper_Link(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.main_params)
  elif wVvJuqNhtRHzmeOoacXPTsGLEyQxSj=='NF_SEARCH':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.dp_Nf_Search(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.main_params)
  elif wVvJuqNhtRHzmeOoacXPTsGLEyQxSj=='TOTAL_HISTORY':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.dp_Search_History()
  elif wVvJuqNhtRHzmeOoacXPTsGLEyQxSj=='HISTORY_REMOVE':
   wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.dp_History_Delete(wVvJuqNhtRHzmeOoacXPTsGLEyQxgY.main_params)
  else:
   wVvJuqNhtRHzmeOoacXPTsGLEyQxbB
# Created by pyminifier (https://github.com/liftoff/pyminifier)
