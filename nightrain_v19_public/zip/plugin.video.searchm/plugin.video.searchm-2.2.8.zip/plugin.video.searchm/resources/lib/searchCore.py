__author__="NightRain"
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvQ=object
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ=None
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr=True
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH=print
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs=str
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvG=int
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN=False
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvn=dict
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc=Exception
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvW=len
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvj=open
SpdmRYkVMaiOFoEuIXLxKfBwyCPgve=type
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvt=list
SpdmRYkVMaiOFoEuIXLxKfBwyCPgvz=isinstance
SpdmRYkVMaiOFoEuIXLxKfBwyCPgDT=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
import http.cookiejar
import httpx
class SpdmRYkVMaiOFoEuIXLxKfBwyCPgTU(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvQ):
 def __init__(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_WAVVE ='https://apis.wavve.com'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_TVING_SEARCH='https://search-api.tving.com'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_TVING_IMG ='https://image.tving.com'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_WATCHA ='https://api-mars.watcha.com'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_NETFLIX ='https://www.netflix.com'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_COUPANG ='https://www.coupangplay.com'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_PRIMEV ='https://www.primevideo.com'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_DISNEY ='https://disney.api.edge.bamgrid.com/explore'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_DISNEY_VERSION ='v1.11'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.WAVVE_LIMIT =20 
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.TVING_LIMIT =30
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.WATCHA_LIMIT =30
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_LIMIT =20 
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.COUPANG_LIMIT =10 
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DISNEY_LIMIT =10 
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DERECTOR_LIMIT =4
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.CAST_LIMIT =10
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.GENRE_LIMIT =4
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.TVING_MOVIE_LITE=['2610061','2610161','261062']
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.WAVVE_PARAMS ={'apikey':'E5F3E0D30947AA5440556471321BB6D9','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all','client_version':'7.1.40',}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100','APIKEY':'1e7952d0917d6aab1f0293a063697610','TELECODE':'CSCD0900',}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_HEADER={'user-agent':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND1 ='_342x192'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND2 ='_665x375'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_PORT ='_342x684'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LOGO ='_550x124'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF={}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['COOKIES']={}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']={}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ={}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.PV={}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.HTTP_CLIENT=requests.Session()
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.CP_ORIGINAL_COOKIE =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.PV_ORIGINAL_COOKIE =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ_ORIGINAL_COOKIE =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_ORIGINAL_COOKIE =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_SESSION_COOKIES1 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_SESSION_COOKIES2 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_SESSION_COOKIES3 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_SESSION_COOKIES4 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_SESSION_FULLTEXT1 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_SESSION_FULLTEXT2 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_SESSION_FULLTEXT3 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_SESSION_FULLTEXT4 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_CONTEXTJSON_FILE1 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_CONTEXTJSON_FILE2 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_CONTEXTJSON_FILE3 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_CONTEXTJSON_FILE4 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_FALCORJSON_FILE1 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_FALCORJSON_FILE2 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_FALCORJSON_FILE3 =''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_FALCORJSON_FILE4 =''
 '''
 def callRequestCookies(self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):
  #setHeader = {'user-agent' : self.USER_AGENT }
  setHeader = self.DEFAULT_HEADER
  if headers: setHeader.update(headers )
  if jobtype == 'Get': # Get/Post
   res = requests.get(url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  else:
   res = requests.post(url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  return res
 ''' 
 def Call_Request_bak(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,payload=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,json=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,params=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,redirects=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr,method='-'):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTb={'user-agent':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.USER_AGENT}
  if headers:SpdmRYkVMaiOFoEuIXLxKfBwyCPgTb.update(headers)
  if payload!=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ or method=='POST':
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.HTTP_CLIENT.post(url=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,data=payload,json=json,params=params,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTb,cookies=cookies,allow_redirects=redirects)
  else:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.HTTP_CLIENT.get(url=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,params=params,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTb,cookies=cookies,allow_redirects=redirects)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.status_code)+' - '+SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.url))
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv
 def Call_Request(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,payload=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,json=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,params=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,redirects=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr,method='-'):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTb={'user-agent':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.USER_AGENT}
  if headers:SpdmRYkVMaiOFoEuIXLxKfBwyCPgTb.update(headers)
  if payload!=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ or method=='POST':
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=httpx.post(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,data=payload,json=json,params=params,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTb,cookies=cookies,follow_redirects=redirects)
  else:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=httpx.get(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,params=params,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTb,cookies=cookies,follow_redirects=redirects)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.status_code)+' - '+SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.url))
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv
 def GetNoCache(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,timetype=1,minutes=0):
  if timetype==1:
   ts=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvG(time.time())
   mi=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvG(minutes*60)
  else:
   ts=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvG(time.time()*1000)
   mi=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvG(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,search_key,sType,page_int):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq=[]
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTA=SpdmRYkVMaiOFoEuIXLxKfBwyCPgUb=1
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN
  try:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_WAVVE+'/fz/search/band.js'
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs((page_int-1)*SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.WAVVE_LIMIT),'limit':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.WAVVE_LIMIT,'orderby':'score','mtype':'svod',}
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ.update(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.WAVVE_PARAMS)
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.Call_Request(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,payload=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,params=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,method='GET')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr=json.loads(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.text)
   if not('celllist' in SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr['band']):return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTH=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr['band']['celllist']
   for SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs in SpdmRYkVMaiOFoEuIXLxKfBwyCPgTH:
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTG=''
    for SpdmRYkVMaiOFoEuIXLxKfBwyCPgTN in SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['event_list']:
     if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTN['type']=='on-navigation':
      SpdmRYkVMaiOFoEuIXLxKfBwyCPgTG=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTN['url']
    if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTG=='':break
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTn=urllib.parse.urlsplit(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTG).query
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTc=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTn[0:SpdmRYkVMaiOFoEuIXLxKfBwyCPgTn.find('=')]
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTW=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvn(urllib.parse.parse_qsl(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTn))
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTj=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTW.get(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTc)
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTc='TVSHOW' if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTc=='programid' else 'MOVIE' 
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTe=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['title_list'][0]['text']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTt =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['age']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz={'title':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTe}
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUT=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN
    for SpdmRYkVMaiOFoEuIXLxKfBwyCPgUh in SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['bottom_taglist']:
     if SpdmRYkVMaiOFoEuIXLxKfBwyCPgUh=='won':
      SpdmRYkVMaiOFoEuIXLxKfBwyCPgUT=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr
      break
    if SpdmRYkVMaiOFoEuIXLxKfBwyCPgUT==SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr: 
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz['title']=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz['title']+' [개별구매]'
    if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs.get('age')!='21':
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq.append(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz)
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTA=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvG(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr['band']['pagecount'])
   if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr['band']['count']:SpdmRYkVMaiOFoEuIXLxKfBwyCPgUb =SpdmRYkVMaiOFoEuIXLxKfBwyCPgvG(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr['band']['count'])
   else:SpdmRYkVMaiOFoEuIXLxKfBwyCPgUb=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.LIST_LIMIT
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTA>SpdmRYkVMaiOFoEuIXLxKfBwyCPgUb
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception)
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl 
 def Get_Search_Tving(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,search_key,sType,page_int):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq=[]
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN
  try:
   if sType=='TVSHOW':
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ ='https://gw.tving.com/bff/search/v2/more/content/series/search'
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUv='AI_SCH_SERIES'
   else:
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ ='https://gw.tving.com/bff/search/v2/more/content/movie/search'
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUv='AI_SCH_MOVIE'
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ={'keyword':search_key,'pageNo':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(page_int),'pageSize':'20','bandComposeMethod':'MANUAL','bandCode':SpdmRYkVMaiOFoEuIXLxKfBwyCPgUv,'osCode':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.TVING_PARMAS['OSCODE'],'screenCode':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.TVING_PARMAS['SCREENCODE'],}
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.Call_Request(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,payload=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,params=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,method='GET')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr=json.loads(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.text).get('data').get('bands')[0]
   for SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs in SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr['items']:
    if sType=='TVSHOW':
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz={'program':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['code'],'title':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['title'],'thumbnail':{'poster':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['imageUrl']}}
    else:
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz={'movie':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['code'],'title':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['title'],'thumbnail':{'poster':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['imageUrl']}}
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq.append(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz)
   if 'nextApiUrl' in SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr:SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception)
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl
 def Get_Search_Watcha(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,search_key,page_int):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq=[]
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN
  try:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_WATCHA+'/api/search.json'
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgUD={'query':search_key,'page':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(page_int),'per':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.WATCHA_LIMIT),'exclude':'limited',}
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.Call_Request(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,payload=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,params=SpdmRYkVMaiOFoEuIXLxKfBwyCPgUD,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.WATCHA_HEADER,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,method='GET')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgUq=json.loads(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.text)
   if not('results' in SpdmRYkVMaiOFoEuIXLxKfBwyCPgUq):return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgUA=SpdmRYkVMaiOFoEuIXLxKfBwyCPgUq['results']
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl=SpdmRYkVMaiOFoEuIXLxKfBwyCPgUq['meta']['has_next']
   for SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs in SpdmRYkVMaiOFoEuIXLxKfBwyCPgUA:
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUl =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['code']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUQ=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['content_type']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUJ =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['title']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUr =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['story']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUH=SpdmRYkVMaiOFoEuIXLxKfBwyCPgbj=SpdmRYkVMaiOFoEuIXLxKfBwyCPgbW=''
    if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs.get('poster') !=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ:SpdmRYkVMaiOFoEuIXLxKfBwyCPgUH=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs.get('poster').get('original')
    if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs.get('stillcut')!=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ:SpdmRYkVMaiOFoEuIXLxKfBwyCPgbj =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs.get('stillcut').get('large')
    if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs.get('thumbnail')!=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ:SpdmRYkVMaiOFoEuIXLxKfBwyCPgbW=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs.get('thumbnail').get('large')
    if SpdmRYkVMaiOFoEuIXLxKfBwyCPgbW=='' :SpdmRYkVMaiOFoEuIXLxKfBwyCPgbW=SpdmRYkVMaiOFoEuIXLxKfBwyCPgbj
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUs={'thumb':SpdmRYkVMaiOFoEuIXLxKfBwyCPgbj,'poster':SpdmRYkVMaiOFoEuIXLxKfBwyCPgUH,'fanart':SpdmRYkVMaiOFoEuIXLxKfBwyCPgbW}
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUG =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['year']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUN =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['film_rating_code']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUn=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['film_rating_short']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUc =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['film_rating_long']
    if SpdmRYkVMaiOFoEuIXLxKfBwyCPgUQ=='movies':
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgUW =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs['duration']
    else:
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgUW ='0'
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz={'title':SpdmRYkVMaiOFoEuIXLxKfBwyCPgUJ,}
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq.append(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz)
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception)
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl
 def Get_Search_Coupang(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,search_key,page_int):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq=[]
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN
  try:
   CP=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.jsonfile_To_dic(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.CP_ORIGINAL_COOKIE)
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_COUPANG+'/api-discover/v3/search'
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ={'query':search_key,'platform':'WEBCLIENT','page':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(page_int),'perPage':'48','filterSearchGroupTypes':'','filterSearchGroupType':'TITLES-EVENT_LIVE-EVENT_CHANNELS','includeChannelContents':'true','includeSportsChannelContents':'true',}
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj={'x-membersrl':CP['COOKIES']['member_srl'],'x-pcid':CP['COOKIES']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.Call_Request(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,payload=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,params=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,method='GET')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr=json.loads(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.text)
   if SpdmRYkVMaiOFoEuIXLxKfBwyCPgvW(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr.get('data').get('contents'))==0:return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl
   for SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs in SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr.get('data').get('contents'):
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz={'title':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTs.get('title'),}
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq.append(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz)
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception)
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl
 def Selenium_Cookies_Load(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,in_filename):
  fp=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvj(in_filename,'rb',-1)
  try:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgUe=pickle.loads(fp.read())
   if SpdmRYkVMaiOFoEuIXLxKfBwyCPgve(SpdmRYkVMaiOFoEuIXLxKfBwyCPgUe)==SpdmRYkVMaiOFoEuIXLxKfBwyCPgvt:
    for SpdmRYkVMaiOFoEuIXLxKfBwyCPgUt in SpdmRYkVMaiOFoEuIXLxKfBwyCPgUe:
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.HTTP_CLIENT.cookies.set_cookie(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.To_Cookielib(SpdmRYkVMaiOFoEuIXLxKfBwyCPgUt)) 
   else:
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.HTTP_CLIENT.cookies.update(SpdmRYkVMaiOFoEuIXLxKfBwyCPgUe) 
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception)
  finally:
   fp.close()
 def To_Cookielib(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,selenium_cookie):
  return http.cookiejar.Cookie(version=0,name=selenium_cookie['name'],value=selenium_cookie['value'],port=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,port_specified=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN,domain=selenium_cookie['domain'],domain_specified=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr,domain_initial_dot=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN,path=selenium_cookie['path'],path_specified=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr,secure=selenium_cookie['secure'],expires=selenium_cookie['expiry'],discard=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN,comment=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,comment_url=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,rest={'HttpOnly':selenium_cookie['httpOnly']},rfc2109=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN,)
 def Get_Search_Primev(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,search_key):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq=[]
  try:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.PV=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.jsonfile_To_dic(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.PV_ORIGINAL_COOKIE)
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghT=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.PV['COOKIES']
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj={'accept':'application/json','x-requested-with':'WebAppSPA',}
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghU ='dvWebAppClientVersion=1.0.121730.0'
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ='https://www.primevideo.com/region/fe/search/ref=atv_nb_sug?ie=UTF8&phrase={}&{}'.format(urllib.parse.quote_plus(search_key),SpdmRYkVMaiOFoEuIXLxKfBwyCPghU)
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.Call_Request(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,params=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPghT,method='GET')
   if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.status_code!=200:return[]
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghb=json.loads(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.text)
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghb=SpdmRYkVMaiOFoEuIXLxKfBwyCPghb['body']['containers'][0]
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghv=SpdmRYkVMaiOFoEuIXLxKfBwyCPghb.get('entities')
   for SpdmRYkVMaiOFoEuIXLxKfBwyCPghD in SpdmRYkVMaiOFoEuIXLxKfBwyCPghv:
    if 'titleID' not in SpdmRYkVMaiOFoEuIXLxKfBwyCPghD:return[]
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz={'title':SpdmRYkVMaiOFoEuIXLxKfBwyCPghD.get('title'),}
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq.append(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz)
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception)
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq
 def Get_Search_Disney(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,search_key):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq=[]
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ ='{}/{}/search'.format(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_DISNEY,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_DISNEY_VERSION)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.make_DZ_Headers(accessToken=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr,Bearer=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ ={'query':search_key,}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.Call_Request(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,params=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,method='GET')
  if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.status_code not in[200,201]:return[]
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghq=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.json().get('data').get('page').get('containers')
  for SpdmRYkVMaiOFoEuIXLxKfBwyCPghD in SpdmRYkVMaiOFoEuIXLxKfBwyCPghq[0]['items']:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz={'title':SpdmRYkVMaiOFoEuIXLxKfBwyCPghD['visuals']['title'],}
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq.append(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz)
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq
 def Get_Search_Disney_back(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,search_key):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq=[]
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['services']['content']['getSearchResults']['href']
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghA={'apiVersion':'5.1','region':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge','pageSize':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DISNEY_LIMIT),'query':search_key,}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ.format(**SpdmRYkVMaiOFoEuIXLxKfBwyCPghA)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.make_DZ_Headers(accessToken=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr,Bearer=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.Call_Request(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,method='GET')
  if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.status_code not in[200,201]:return[]
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghq=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.json().get('data').get('search')
  for SpdmRYkVMaiOFoEuIXLxKfBwyCPghD in SpdmRYkVMaiOFoEuIXLxKfBwyCPghq.get('hits'):
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghD=SpdmRYkVMaiOFoEuIXLxKfBwyCPghD.get('hit')
   if SpdmRYkVMaiOFoEuIXLxKfBwyCPghD.get('type')=='DmcSeries': 
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUJ =SpdmRYkVMaiOFoEuIXLxKfBwyCPghD.get('text').get('title').get('full').get('series').get('default').get('content')
   elif SpdmRYkVMaiOFoEuIXLxKfBwyCPghD.get('type')=='DmcVideo':
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUJ =SpdmRYkVMaiOFoEuIXLxKfBwyCPghD.get('text').get('title').get('full').get('program').get('default').get('content')
   elif SpdmRYkVMaiOFoEuIXLxKfBwyCPghD.get('type')=='StandardCollection':
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUJ =SpdmRYkVMaiOFoEuIXLxKfBwyCPghD.get('text').get('title').get('full').get('collection').get('default').get('content')
   else:
    return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz={'title':SpdmRYkVMaiOFoEuIXLxKfBwyCPgUJ,}
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq.append(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz)
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq
 def dic_To_jsonfile(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,filename,SpdmRYkVMaiOFoEuIXLxKfBwyCPghl):
  if filename=='':return
  fp=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvj(filename,'w',-1,'utf-8')
  json.dump(SpdmRYkVMaiOFoEuIXLxKfBwyCPghl,fp,indent=4,ensure_ascii=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN)
  fp.close()
 def jsonfile_To_dic(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,filename):
  if filename=='':return SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ
  try:
   fp=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvj(filename,'r',-1,'utf-8')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ=json.load(fp)
   fp.close()
  except:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ={}
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ
 def tempFileSave(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,filename,resText):
  if filename=='':return
  fp=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvj(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,filename):
  if filename=='':return
  try:
   fp=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvj(filename,'r',-1,'utf-8')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ=fp.read()
   fp.close()
  except:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ=''
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ
 def make_DZ_Headers(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,accessToken=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr,Bearer=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN):
  if accessToken:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghr=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['account']['accessToken']
  else:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghr=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['headers']['clientApiKey']
  if Bearer:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghr='Bearer {}'.format(SpdmRYkVMaiOFoEuIXLxKfBwyCPghr)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['headers']['sdkVersion']='34.4' 
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj={'authorization':SpdmRYkVMaiOFoEuIXLxKfBwyCPghr,'x-application-version':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['headers']['buildId'],'x-bamsdk-client-id':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['headers']['clientId'],'x-bamsdk-platform':'javascript/windows/chrome','x-bamsdk-platform-id':'browser','x-bamsdk-version':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['headers']['sdkVersion'],'x-bamtech-wpnx-mlp-identifier':'/','x-bamtech-wpnx-mlp-locale':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['headers']['lang'],}
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj
 def DZ_ReToken(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh):
  try:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['services']['orchestration']['refreshToken']['href']
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.make_DZ_Headers(accessToken=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN,Bearer=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN)
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghH={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['account']['refreshToken'],}}}
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.Call_Request(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,json=SpdmRYkVMaiOFoEuIXLxKfBwyCPghH,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,method='POST')
   if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.status_code not in[200,201]:return SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghq=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.json()
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['account']['accessToken'] =SpdmRYkVMaiOFoEuIXLxKfBwyCPghq.get('extensions').get('sdk').get('token').get('accessToken')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['account']['accessTokenType']=SpdmRYkVMaiOFoEuIXLxKfBwyCPghq.get('extensions').get('sdk').get('token').get('accessTokenType')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['account']['refreshToken'] =SpdmRYkVMaiOFoEuIXLxKfBwyCPghq.get('extensions').get('sdk').get('token').get('refreshToken')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['account']['token_limit'] =SpdmRYkVMaiOFoEuIXLxKfBwyCPgvG(time.time())+14400 
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['account']['deviceId'] =SpdmRYkVMaiOFoEuIXLxKfBwyCPghq.get('extensions').get('sdk').get('session').get('device').get('id')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DZ['account']['sessionId'] =SpdmRYkVMaiOFoEuIXLxKfBwyCPghq.get('extensions').get('sdk').get('session').get('sessionId')
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception)
   return SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr
 def Init_NF_Total(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF={}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['COOKIES']={}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']={}
 def make_NF_XnetflixHeaders(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj={'x-netflix.browsername':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['esnModel'],'x-netflix.esnprefix':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['nowGuid'],'x-netflix.uiversion':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj
 def make_NF_ApiParams(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ={'avif':'false','webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','isTop10KidsSupported':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/mre/pathEvaluator',}
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ
 def extract_json(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,content,name):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghs=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghG=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghN=re.compile(SpdmRYkVMaiOFoEuIXLxKfBwyCPghs.format(name),re.DOTALL).findall(content)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghG=SpdmRYkVMaiOFoEuIXLxKfBwyCPghN[0]
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghn=SpdmRYkVMaiOFoEuIXLxKfBwyCPghG.replace('\\"','\\\\"') 
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghn=SpdmRYkVMaiOFoEuIXLxKfBwyCPghn.replace('\\s','\\\\s') 
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghn=SpdmRYkVMaiOFoEuIXLxKfBwyCPghn.replace('\\n','\\\\n') 
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghn=SpdmRYkVMaiOFoEuIXLxKfBwyCPghn.replace('\\t','\\\\t') 
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghn=SpdmRYkVMaiOFoEuIXLxKfBwyCPghn.encode().decode('unicode_escape') 
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghn=re.sub(r'\\(?!["])',r'\\\\',SpdmRYkVMaiOFoEuIXLxKfBwyCPghn) 
  return json.loads(SpdmRYkVMaiOFoEuIXLxKfBwyCPghn)
 def NF_makestr_paths(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,paths):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ=[]
  if SpdmRYkVMaiOFoEuIXLxKfBwyCPgvz(paths,SpdmRYkVMaiOFoEuIXLxKfBwyCPgvG):
   return '%d'%(paths)
  elif SpdmRYkVMaiOFoEuIXLxKfBwyCPgvz(paths,SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs):
   return '"%s"'%(paths)
  for SpdmRYkVMaiOFoEuIXLxKfBwyCPghc in paths:
   if SpdmRYkVMaiOFoEuIXLxKfBwyCPgvz(SpdmRYkVMaiOFoEuIXLxKfBwyCPghc,SpdmRYkVMaiOFoEuIXLxKfBwyCPgvG):
    SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ.append('%d'%(SpdmRYkVMaiOFoEuIXLxKfBwyCPghc))
   elif SpdmRYkVMaiOFoEuIXLxKfBwyCPgvz(SpdmRYkVMaiOFoEuIXLxKfBwyCPghc,SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs):
    SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ.append('"%s"'%(SpdmRYkVMaiOFoEuIXLxKfBwyCPghc))
   elif SpdmRYkVMaiOFoEuIXLxKfBwyCPgvz(SpdmRYkVMaiOFoEuIXLxKfBwyCPghc,SpdmRYkVMaiOFoEuIXLxKfBwyCPgvt):
    SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ.append('[%s]'%(','.join(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_makestr_paths(SpdmRYkVMaiOFoEuIXLxKfBwyCPghc))))
   elif SpdmRYkVMaiOFoEuIXLxKfBwyCPgvz(SpdmRYkVMaiOFoEuIXLxKfBwyCPghc,SpdmRYkVMaiOFoEuIXLxKfBwyCPgvn):
    SpdmRYkVMaiOFoEuIXLxKfBwyCPghW=''
    for SpdmRYkVMaiOFoEuIXLxKfBwyCPghj,SpdmRYkVMaiOFoEuIXLxKfBwyCPghe in SpdmRYkVMaiOFoEuIXLxKfBwyCPghc.items():
     SpdmRYkVMaiOFoEuIXLxKfBwyCPghW+='"%s":%s,'%(SpdmRYkVMaiOFoEuIXLxKfBwyCPghj,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_makestr_paths(SpdmRYkVMaiOFoEuIXLxKfBwyCPghe))
    SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ.append('{%s}'%(SpdmRYkVMaiOFoEuIXLxKfBwyCPghW[:-1]))
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPghJ
 def NF_Call_pathapi(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,SpdmRYkVMaiOFoEuIXLxKfBwyCPgbl,referer=''):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPght='%s/nq/website/memberapi/%s/pathEvaluator'%(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_NETFLIX,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['identifier'])
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghH={'path':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_makestr_paths(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbl),'authURL':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']['authURL']}
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.make_NF_ApiParams()
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_NETFLIX,'sec-ch-ua':'"Google Chrome";v="101", "Not)A;Brand";v="8", "Chromium";v="101"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj['referer']=referer
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghz=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.make_NF_XnetflixHeaders()
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj.update(SpdmRYkVMaiOFoEuIXLxKfBwyCPghz)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghT=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_Get_DefaultCookies()
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghT['profilesNewSession']='0'
  try:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.Call_Request(SpdmRYkVMaiOFoEuIXLxKfBwyCPght,payload=SpdmRYkVMaiOFoEuIXLxKfBwyCPghH,params=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTJ,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgUj,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPghT,method='POST')
   return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception)
   return SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ
 def Get_Search_Netflix(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,search_key,page_int,byReference=''):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbT=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.DERECTOR_LIMIT
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbU =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.CAST_LIMIT
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbh =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.GENRE_LIMIT
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_LIMIT*(page_int-1)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_LIMIT*page_int 
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbq="|%s"%(search_key)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbA ='%s/search?%s'%(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgbl=[["search","byTerm",SpdmRYkVMaiOFoEuIXLxKfBwyCPgbq,"titles",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_LIMIT,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"summary"],["search","byTerm",SpdmRYkVMaiOFoEuIXLxKfBwyCPgbq,"titles",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_LIMIT,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",SpdmRYkVMaiOFoEuIXLxKfBwyCPgbq,"titles",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_LIMIT,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference","boxarts",[SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND2,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_PORT],"jpg"],["search","byTerm",SpdmRYkVMaiOFoEuIXLxKfBwyCPgbq,"titles",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_LIMIT,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference","interestingMoment",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND1,"jpg"],["search","byTerm",SpdmRYkVMaiOFoEuIXLxKfBwyCPgbq,"titles",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_LIMIT,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference","storyArt",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND2,"jpg"],["search","byTerm",SpdmRYkVMaiOFoEuIXLxKfBwyCPgbq,"titles",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_LIMIT,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference",["cast","creators","directors"],{"from":0,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbT},["id","name"]],["search","byTerm",SpdmRYkVMaiOFoEuIXLxKfBwyCPgbq,"titles",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_LIMIT,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference","genres",{"from":0,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbh},["id","name"]],["search","byTerm",SpdmRYkVMaiOFoEuIXLxKfBwyCPgbq,"titles",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NETFLIX_LIMIT,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LOGO,"png"],]
  else:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgbl=[["search","byReference",byReference,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"summary"],["search","byReference",byReference,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference","boxarts",[SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND2,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference","interestingMoment",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference","storyArt",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference",["cast","creators","directors"],{"from":0,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbT},["id","name"]],["search","byReference",byReference,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference","genres",{"from":0,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbh},["id","name"]],["search","byReference",byReference,{"from":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,"to":SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LOGO,"png"],]
  try:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_Call_pathapi(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbl,SpdmRYkVMaiOFoEuIXLxKfBwyCPgbA)
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr=json.loads(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.text)
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception)
  (SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl,byReference)=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.Search_Netflix_Make(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTr)
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl,byReference
 def Search_Netflix_Make(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,jsonSource):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq=[]
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl =SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbQ=''
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbJ=jsonSource.get('paths')[0][1]
  if SpdmRYkVMaiOFoEuIXLxKfBwyCPgbJ=='byTerm':
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv =jsonSource['paths'][0][5]['from']
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD =jsonSource['paths'][0][5]['to']
  else:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv =jsonSource['paths'][0][3]['from']
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD =jsonSource['paths'][0][3]['to']
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbQ=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvt(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbr=jsonSource.get('jsonGraph').get('search').get('byReference').get(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbQ)
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbH =jsonSource.get('jsonGraph').get('videos')
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbs=jsonSource.get('jsonGraph').get('person')
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgbG=jsonSource.get('jsonGraph').get('genres')
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr if SpdmRYkVMaiOFoEuIXLxKfBwyCPgbr[SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD)]['reference']['$type']=='ref' else SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN
  for SpdmRYkVMaiOFoEuIXLxKfBwyCPgbN in SpdmRYkVMaiOFoEuIXLxKfBwyCPgDT(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbv,SpdmRYkVMaiOFoEuIXLxKfBwyCPgbD):
   if SpdmRYkVMaiOFoEuIXLxKfBwyCPgbr[SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbN)]['reference']['$type']=='ref':
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTj =SpdmRYkVMaiOFoEuIXLxKfBwyCPgbr[SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbN)]['reference']['value'][1]
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn=SpdmRYkVMaiOFoEuIXLxKfBwyCPgbH[SpdmRYkVMaiOFoEuIXLxKfBwyCPgTj]
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUJ =SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['title']['value']
    if SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['availability']['value']['isPlayable']==SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN:
     continue
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTc =SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['summary']['value']['type']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUW =0 if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTc!='movie' else SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['runtime']['value']
    if SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['sequiturEvidence']['value']['value']:
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgbc=SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['sequiturEvidence']['value']['value']['text']
    else:
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgbc=''
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgUH =SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['boxarts'][SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_PORT]['jpg']['value']['url']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgbW =SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['boxarts'][SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND2]['jpg']['value']['url']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgbj=''
    if 'value' in SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['storyArt'][SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND2]['jpg']:
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgbj =SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['storyArt'][SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND2]['jpg']['value']['url']
    if SpdmRYkVMaiOFoEuIXLxKfBwyCPgbj=='' and 'value' in SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['interestingMoment'][SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND1]['jpg']:
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgbj =SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['interestingMoment'][SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LAND1]['jpg']['value']['url']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgbe=''
    if 'value' in SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LOGO]['png']:
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgbe=SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.ART_SIZE_LOGO]['png']['value']['url']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgbt =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_Subid_List(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['genres'])
    for i in SpdmRYkVMaiOFoEuIXLxKfBwyCPgDT(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvW(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbt)):
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgbt[i]=SpdmRYkVMaiOFoEuIXLxKfBwyCPgbG[SpdmRYkVMaiOFoEuIXLxKfBwyCPgbt[i]]['name']['value']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgbz=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_Subid_List(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['directors'])
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgvT =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_Subid_List(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['creators'])
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgbz.extend(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvT)
    for i in SpdmRYkVMaiOFoEuIXLxKfBwyCPgDT(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvW(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbz)):
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgbz[i]=SpdmRYkVMaiOFoEuIXLxKfBwyCPgbs[SpdmRYkVMaiOFoEuIXLxKfBwyCPgbz[i]]['name']['value']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgvU=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_Subid_List(SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['cast'])
    for i in SpdmRYkVMaiOFoEuIXLxKfBwyCPgDT(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvW(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvU)):
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgvU[i]=SpdmRYkVMaiOFoEuIXLxKfBwyCPgbs[SpdmRYkVMaiOFoEuIXLxKfBwyCPgvU[i]]['name']['value']
    if 'maturityDescription' in SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['maturity']['value']['rating']:
     SpdmRYkVMaiOFoEuIXLxKfBwyCPgvh=SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['maturity']['value']['rating']['maturityDescription']
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz={'videoid':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTj,'vidtype':SpdmRYkVMaiOFoEuIXLxKfBwyCPgTc,'title':SpdmRYkVMaiOFoEuIXLxKfBwyCPgUJ,'mpaa':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvh,'regularSynopsis':SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['regularSynopsis']['value'],'dpSupplemental':SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['dpSupplementalMessage']['value'],'sequiturEvidence':SpdmRYkVMaiOFoEuIXLxKfBwyCPgbc,'thumbnail':{'poster':SpdmRYkVMaiOFoEuIXLxKfBwyCPgUH,'thumb':SpdmRYkVMaiOFoEuIXLxKfBwyCPgbj,'fanart':SpdmRYkVMaiOFoEuIXLxKfBwyCPgbW,'clearlogo':SpdmRYkVMaiOFoEuIXLxKfBwyCPgbe},'year':SpdmRYkVMaiOFoEuIXLxKfBwyCPgbn['releaseYear']['value'],'duration':SpdmRYkVMaiOFoEuIXLxKfBwyCPgUW,'info_genre':SpdmRYkVMaiOFoEuIXLxKfBwyCPgbt,'director':SpdmRYkVMaiOFoEuIXLxKfBwyCPgbz,'cast':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvU,}
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq.append(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTz)
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgTq,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTl,SpdmRYkVMaiOFoEuIXLxKfBwyCPgbQ
 def NF_Subid_List(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,subJson):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPgvb=[]
  try:
   for i in SpdmRYkVMaiOFoEuIXLxKfBwyCPgDT(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvW(subJson)):
    if subJson.get(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(i)).get('$type')!='ref':break
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgvD=subJson.get(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvs(i)).get('value')[1]
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgvb.append(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvD)
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception)
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgvb
 def NF_CookieFile_Load(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh,cookie_filename):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghT={}
  try:
   if os.path.isfile(cookie_filename)==SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN:return{}
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvq=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvj(cookie_filename,'rb',-1)
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvA =pickle.loads(SpdmRYkVMaiOFoEuIXLxKfBwyCPgvq.read())
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvq.close()
   for SpdmRYkVMaiOFoEuIXLxKfBwyCPgUt in SpdmRYkVMaiOFoEuIXLxKfBwyCPgvA:
    SpdmRYkVMaiOFoEuIXLxKfBwyCPghT[SpdmRYkVMaiOFoEuIXLxKfBwyCPgUt.name]=SpdmRYkVMaiOFoEuIXLxKfBwyCPgUt.value
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception) 
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPghT
 def NF_Get_DefaultCookies(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh):
  SpdmRYkVMaiOFoEuIXLxKfBwyCPghT={}
  if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['COOKIES']['flwssn'] :SpdmRYkVMaiOFoEuIXLxKfBwyCPghT['flwssn'] =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['COOKIES']['flwssn']
  if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['COOKIES']['nfvdid'] :SpdmRYkVMaiOFoEuIXLxKfBwyCPghT['nfvdid'] =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['COOKIES']['nfvdid']
  if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['COOKIES']['SecureNetflixId']:SpdmRYkVMaiOFoEuIXLxKfBwyCPghT['SecureNetflixId']=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['COOKIES']['SecureNetflixId']
  if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['COOKIES']['NetflixId'] :SpdmRYkVMaiOFoEuIXLxKfBwyCPghT['NetflixId'] =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['COOKIES']['NetflixId']
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPghT
 def NF_Get_BaseSession(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh):
  try:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.API_NETFLIX+'/browse' 
   SpdmRYkVMaiOFoEuIXLxKfBwyCPghT=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_Get_DefaultCookies()
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv=SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.Call_Request(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTQ,payload=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,params=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,headers=SpdmRYkVMaiOFoEuIXLxKfBwyCPgvJ,cookies=SpdmRYkVMaiOFoEuIXLxKfBwyCPghT,method='GET')
   if SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.status_code!=200:
    SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH('pass 1 status_code error')
    return SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvl =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.extract_json(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTv.text,'reactContext')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF['SESSION']={'mainGuid':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvl['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvl['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvl['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvl['models']['memberContext']['data']['userInfo']['esn'],'identifier':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvl['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':SpdmRYkVMaiOFoEuIXLxKfBwyCPgvl['models']['abContext']['data']['headers'],}
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.dic_To_jsonfile(SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF_SESSION_COOKIES1,SpdmRYkVMaiOFoEuIXLxKfBwyCPgTh.NF)
  except SpdmRYkVMaiOFoEuIXLxKfBwyCPgvc as exception:
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH('pass 1 error')
   SpdmRYkVMaiOFoEuIXLxKfBwyCPgvH(exception)
   return SpdmRYkVMaiOFoEuIXLxKfBwyCPgvN
  return SpdmRYkVMaiOFoEuIXLxKfBwyCPgvr
# Created by pyminifier (https://github.com/liftoff/pyminifier)
