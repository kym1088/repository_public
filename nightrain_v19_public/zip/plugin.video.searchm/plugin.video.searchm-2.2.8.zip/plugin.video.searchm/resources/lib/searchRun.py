__author__="NightRain"
mWEHfTdVQyBFAKLNwhiDgaxJPGrRec=object
mWEHfTdVQyBFAKLNwhiDgaxJPGrRek=None
mWEHfTdVQyBFAKLNwhiDgaxJPGrReY=True
mWEHfTdVQyBFAKLNwhiDgaxJPGrRes=False
mWEHfTdVQyBFAKLNwhiDgaxJPGrRej=type
mWEHfTdVQyBFAKLNwhiDgaxJPGrReM=dict
mWEHfTdVQyBFAKLNwhiDgaxJPGrReS=open
mWEHfTdVQyBFAKLNwhiDgaxJPGrReX=len
mWEHfTdVQyBFAKLNwhiDgaxJPGrReo=Exception
mWEHfTdVQyBFAKLNwhiDgaxJPGrRlt=int
mWEHfTdVQyBFAKLNwhiDgaxJPGrRlp=range
mWEHfTdVQyBFAKLNwhiDgaxJPGrRlq=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
mWEHfTdVQyBFAKLNwhiDgaxJPGrRtq=[{'title':'통합검색 (웨이브,티빙,쿠팡,디즈니)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
mWEHfTdVQyBFAKLNwhiDgaxJPGrRtb={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
mWEHfTdVQyBFAKLNwhiDgaxJPGrRte=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
mWEHfTdVQyBFAKLNwhiDgaxJPGrRtl =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class mWEHfTdVQyBFAKLNwhiDgaxJPGrRtp(mWEHfTdVQyBFAKLNwhiDgaxJPGrRec):
 def __init__(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,mWEHfTdVQyBFAKLNwhiDgaxJPGrRtC,mWEHfTdVQyBFAKLNwhiDgaxJPGrRtO,mWEHfTdVQyBFAKLNwhiDgaxJPGrRtu):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv._addon_url =mWEHfTdVQyBFAKLNwhiDgaxJPGrRtC
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv._addon_handle=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtO
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.main_params =mWEHfTdVQyBFAKLNwhiDgaxJPGrRtu
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj =SpdmRYkVMaiOFoEuIXLxKfBwyCPgTU() 
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_authinfo.json'))
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,sting):
  try:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI=xbmcgui.Dialog()
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI.notification(__addonname__,sting)
  except:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRek
 def addon_log(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,string):
  try:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtz=string.encode('utf-8','ignore')
  except:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtz='addonException: addon_log'
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtU=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,mWEHfTdVQyBFAKLNwhiDgaxJPGrRtz),level=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtU)
 def get_keyboard_input(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtc=mWEHfTdVQyBFAKLNwhiDgaxJPGrRek
  kb=xbmc.Keyboard()
  kb.setHeading(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtc=kb.getText()
  return mWEHfTdVQyBFAKLNwhiDgaxJPGrRtc
 def get_settings_menubookmark(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtk=mWEHfTdVQyBFAKLNwhiDgaxJPGrReY if __addon__.getSetting('menu_bookmark')=='true' else mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
  return(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtk)
 def get_settings_makebookmark(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv):
  return mWEHfTdVQyBFAKLNwhiDgaxJPGrReY if __addon__.getSetting('make_bookmark')=='true' else mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
 def get_settings_select_info(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY=[]
  if __addon__.getSetting('wavveyn')=='true':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY.append('tving')
  if __addon__.getSetting('watchayn')=='true':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY.append('coupang')
  if __addon__.getSetting('primevyn')=='true':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY.append('disney')
  return mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY
 def add_dir(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,label,sublabel='',img='',infoLabels=mWEHfTdVQyBFAKLNwhiDgaxJPGrRek,isFolder=mWEHfTdVQyBFAKLNwhiDgaxJPGrReY,params='',isLink=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes,ContextMenu=mWEHfTdVQyBFAKLNwhiDgaxJPGrRek,direct_url=mWEHfTdVQyBFAKLNwhiDgaxJPGrRek):
  if direct_url:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRts=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM=json.dumps(params,separators=(',',':'))
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM=base64.standard_b64encode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM.encode()).decode('utf-8')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM.replace('+','%2B')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRts='%s?params=%s'%(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv._addon_url,mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM)
  if sublabel and sublabel!='-':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS='%s < %s >'%(label,sublabel)
  else: mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS=label
  if not img:img='DefaultFolder.png'
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtX=xbmcgui.ListItem(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS)
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRej(img)==mWEHfTdVQyBFAKLNwhiDgaxJPGrReM:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtX.setArt(img)
  else:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtX.setArt({'thumb':img,'poster':img})
  if infoLabels:mWEHfTdVQyBFAKLNwhiDgaxJPGrRtX.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtX.setProperty('IsPlayable','true')
  if ContextMenu:mWEHfTdVQyBFAKLNwhiDgaxJPGrRtX.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv._addon_handle,mWEHfTdVQyBFAKLNwhiDgaxJPGrRts,mWEHfTdVQyBFAKLNwhiDgaxJPGrRtX,isFolder)
 def Load_Searched_List(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv):
  try:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRto=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtl
   fp=mWEHfTdVQyBFAKLNwhiDgaxJPGrReS(mWEHfTdVQyBFAKLNwhiDgaxJPGrRto,'r',-1,'utf-8')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpt=fp.readlines()
   fp.close()
  except:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpt=[]
  return mWEHfTdVQyBFAKLNwhiDgaxJPGrRpt
 def Save_Searched_List(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs):
  try:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRto=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtl
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpq=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.Load_Searched_List() 
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpb={'skey':mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs.strip()}
   fp=mWEHfTdVQyBFAKLNwhiDgaxJPGrReS(mWEHfTdVQyBFAKLNwhiDgaxJPGrRto,'w',-1,'utf-8')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpe=urllib.parse.urlencode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpb)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpe=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpe+'\n'
   fp.write(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpe)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpl=0
   for mWEHfTdVQyBFAKLNwhiDgaxJPGrRpv in mWEHfTdVQyBFAKLNwhiDgaxJPGrRpq:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRpC=mWEHfTdVQyBFAKLNwhiDgaxJPGrReM(urllib.parse.parse_qsl(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpv))
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRpO=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpb.get('skey').strip()
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRpu=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpC.get('skey').strip()
    if mWEHfTdVQyBFAKLNwhiDgaxJPGrRpO!=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpu:
     fp.write(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpv)
     mWEHfTdVQyBFAKLNwhiDgaxJPGrRpl+=1
     if mWEHfTdVQyBFAKLNwhiDgaxJPGrRpl>=50:break
   fp.close()
  except:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRek
 def dp_Search_History(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,args):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRpn=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.Load_Searched_List()
  for mWEHfTdVQyBFAKLNwhiDgaxJPGrRpI in mWEHfTdVQyBFAKLNwhiDgaxJPGrRpn:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpz=mWEHfTdVQyBFAKLNwhiDgaxJPGrReM(urllib.parse.parse_qsl(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpI))
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpU=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpz.get('skey').strip()
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj={'mode':'TOTAL_SEARCH','search_key':mWEHfTdVQyBFAKLNwhiDgaxJPGrRpU,}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpc={'mode':'HISTORY_REMOVE','skey':mWEHfTdVQyBFAKLNwhiDgaxJPGrRpU,'delmode':'ONE',}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpk=urllib.parse.urlencode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpc)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpY=[('선택된 검색어 ( %s ) 삭제'%(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpU),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpk))]
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.add_dir(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpU,sublabel='',img=mWEHfTdVQyBFAKLNwhiDgaxJPGrRek,infoLabels=mWEHfTdVQyBFAKLNwhiDgaxJPGrRek,isFolder=mWEHfTdVQyBFAKLNwhiDgaxJPGrReY,params=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj,ContextMenu=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpY)
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRpj={'plot':'검색목록 전체를 삭제합니다.'}
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRpM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.add_dir(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS,sublabel='',img=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpM,infoLabels=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpj,isFolder=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes,params=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj,isLink=mWEHfTdVQyBFAKLNwhiDgaxJPGrReY)
  xbmcplugin.endOfDirectory(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv._addon_handle,cacheToDisc=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes)
 def Delete_History_List(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,mWEHfTdVQyBFAKLNwhiDgaxJPGrRpU,mWEHfTdVQyBFAKLNwhiDgaxJPGrRpo):
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRpo=='ALL':
   try:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRto=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtl
    fp=mWEHfTdVQyBFAKLNwhiDgaxJPGrReS(mWEHfTdVQyBFAKLNwhiDgaxJPGrRto,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRek
  else:
   try:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRto=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtl
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRpq=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.Load_Searched_List() 
    fp=mWEHfTdVQyBFAKLNwhiDgaxJPGrReS(mWEHfTdVQyBFAKLNwhiDgaxJPGrRto,'w',-1,'utf-8')
    for mWEHfTdVQyBFAKLNwhiDgaxJPGrRpv in mWEHfTdVQyBFAKLNwhiDgaxJPGrRpq:
     mWEHfTdVQyBFAKLNwhiDgaxJPGrRpC=mWEHfTdVQyBFAKLNwhiDgaxJPGrReM(urllib.parse.parse_qsl(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpv))
     mWEHfTdVQyBFAKLNwhiDgaxJPGrRpX=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpC.get('skey').strip()
     if mWEHfTdVQyBFAKLNwhiDgaxJPGrRpU!=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpX:
      fp.write(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpv)
    fp.close()
   except:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRek
 def dp_History_Delete(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,args):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRpU =args.get('skey') 
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRpo=args.get('delmode')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI=xbmcgui.Dialog()
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRpo=='ALL':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRqt=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRqt=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRqt==mWEHfTdVQyBFAKLNwhiDgaxJPGrRes:sys.exit()
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.Delete_History_List(mWEHfTdVQyBFAKLNwhiDgaxJPGrRpU,mWEHfTdVQyBFAKLNwhiDgaxJPGrRpo)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtk=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.get_settings_menubookmark()
  for mWEHfTdVQyBFAKLNwhiDgaxJPGrRqp in mWEHfTdVQyBFAKLNwhiDgaxJPGrRtq:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqp.get('title')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpM=''
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRqp.get('mode')=='MENU_BOOKMARK' and mWEHfTdVQyBFAKLNwhiDgaxJPGrRtk==mWEHfTdVQyBFAKLNwhiDgaxJPGrRes:continue
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj={'mode':mWEHfTdVQyBFAKLNwhiDgaxJPGrRqp.get('mode')}
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRqp.get('mode')in['XXX','MENU_BOOKMARK']:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqb=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqe =mWEHfTdVQyBFAKLNwhiDgaxJPGrReY
   else:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqb=mWEHfTdVQyBFAKLNwhiDgaxJPGrReY
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqe =mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
   if 'icon' in mWEHfTdVQyBFAKLNwhiDgaxJPGrRqp:mWEHfTdVQyBFAKLNwhiDgaxJPGrRpM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',mWEHfTdVQyBFAKLNwhiDgaxJPGrRqp.get('icon')) 
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.add_dir(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS,sublabel='',img=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpM,infoLabels=mWEHfTdVQyBFAKLNwhiDgaxJPGrRek,isFolder=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqb,params=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj,isLink=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqe)
  xbmcplugin.endOfDirectory(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv._addon_handle,cacheToDisc=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes)
 def option_check(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.get_settings_select_info()
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY)==0:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI=xbmcgui.Dialog()
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRqt=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRqt==mWEHfTdVQyBFAKLNwhiDgaxJPGrReY:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY:
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.NF_cookiefile_check()==mWEHfTdVQyBFAKLNwhiDgaxJPGrRes:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.NF_login(showMessage=mWEHfTdVQyBFAKLNwhiDgaxJPGrReY)
  if 'disney' in mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY:
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.DZ_cookiefile_check()==mWEHfTdVQyBFAKLNwhiDgaxJPGrRes:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.DZ={}
 def DZ_cookiefile_check(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqv={}
  try: 
   fp=mWEHfTdVQyBFAKLNwhiDgaxJPGrReS(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRqv= json.load(fp)
   fp.close()
  except mWEHfTdVQyBFAKLNwhiDgaxJPGrReo as exception:
   return mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.DZ=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqv
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRlt(time.time())>mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.DZ['account']['token_limit']:
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.DZ_ReToken()==mWEHfTdVQyBFAKLNwhiDgaxJPGrRes:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_noti(__language__(30920).encode('utf-8'))
    return mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
   try: 
    fp=mWEHfTdVQyBFAKLNwhiDgaxJPGrReS(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.DZ,fp,indent=4,ensure_ascii=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes)
    fp.close()
   except mWEHfTdVQyBFAKLNwhiDgaxJPGrReo as exception:
    return mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
  return mWEHfTdVQyBFAKLNwhiDgaxJPGrReY
 def NF_cookiefile_check(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqv={}
  try: 
   fp=mWEHfTdVQyBFAKLNwhiDgaxJPGrReS(mWEHfTdVQyBFAKLNwhiDgaxJPGrRte,'r',-1,'utf-8')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRqv= json.load(fp)
   fp.close()
  except mWEHfTdVQyBFAKLNwhiDgaxJPGrReo as exception:
   return mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqv
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqO =mWEHfTdVQyBFAKLNwhiDgaxJPGrRlt(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqu=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF['SESSION']['limitdate']
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqn =mWEHfTdVQyBFAKLNwhiDgaxJPGrRlt(re.sub('-','',mWEHfTdVQyBFAKLNwhiDgaxJPGrRqu))
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRqn<mWEHfTdVQyBFAKLNwhiDgaxJPGrRqO:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Init_NF_Total()
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.NF_login(showMessage=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes)==mWEHfTdVQyBFAKLNwhiDgaxJPGrRes:
    return mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqI=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF_CookieFile_Load(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF_ORIGINAL_COOKIE)
  if(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqI['NetflixId']!=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF['COOKIES']['NetflixId']or mWEHfTdVQyBFAKLNwhiDgaxJPGrRqI['SecureNetflixId']!=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF['COOKIES']['SecureNetflixId']or mWEHfTdVQyBFAKLNwhiDgaxJPGrRqI['flwssn']!=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF['COOKIES']['flwssn']or mWEHfTdVQyBFAKLNwhiDgaxJPGrRqI['nfvdid']!=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF['COOKIES']['nfvdid']):
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Init_NF_Total()
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.NF_login(showMessage=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes)==mWEHfTdVQyBFAKLNwhiDgaxJPGrRes:
    return mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
  return mWEHfTdVQyBFAKLNwhiDgaxJPGrReY
 def NF_login(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,showMessage=mWEHfTdVQyBFAKLNwhiDgaxJPGrReY):
  if showMessage:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI=xbmcgui.Dialog()
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRqt=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRqt==mWEHfTdVQyBFAKLNwhiDgaxJPGrRes:
    return mWEHfTdVQyBFAKLNwhiDgaxJPGrRes 
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF['COOKIES']=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF_CookieFile_Load(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF_ORIGINAL_COOKIE)
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqz=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes if mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF['COOKIES']=={}else mWEHfTdVQyBFAKLNwhiDgaxJPGrReY
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRqz:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_log('pass1 ok!')
  else:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_log('pass1 error!')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_noti(__language__(30905).encode('utf-8'))
   return mWEHfTdVQyBFAKLNwhiDgaxJPGrRes 
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqz=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF_Get_BaseSession()
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRqz:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_log('pass2 ok!')
  else:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_log('pass2 error!')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_noti(__language__(30905).encode('utf-8'))
   return mWEHfTdVQyBFAKLNwhiDgaxJPGrRes 
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqU =mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Now_Datetime()
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF['SESSION']['limitdate']=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqU.strftime('%Y-%m-%d')
  try: 
   fp=mWEHfTdVQyBFAKLNwhiDgaxJPGrReS(mWEHfTdVQyBFAKLNwhiDgaxJPGrRte,'w',-1,'utf-8')
   json.dump(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF,fp,indent=4,ensure_ascii=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes)
   fp.close()
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_log('pass3 save ok!')
  except mWEHfTdVQyBFAKLNwhiDgaxJPGrReo as exception:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_log('pass3 save error!')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_noti(__language__(30905).encode('utf-8'))
   return mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
  if showMessage:mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_noti(__language__(30904).encode('utf-8'))
  return mWEHfTdVQyBFAKLNwhiDgaxJPGrReY
 def NF_logout(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI=xbmcgui.Dialog()
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqt=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRqt==mWEHfTdVQyBFAKLNwhiDgaxJPGrRes:return 
  if os.path.isfile(mWEHfTdVQyBFAKLNwhiDgaxJPGrRte):os.remove(mWEHfTdVQyBFAKLNwhiDgaxJPGrRte)
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqc=''
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqk=7
  try:
   for i in mWEHfTdVQyBFAKLNwhiDgaxJPGrRlp(mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)):
    if i>=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqk:
     mWEHfTdVQyBFAKLNwhiDgaxJPGrRqc=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqc+'...'
     break
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqc=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqc+mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj[i]['title']+'\n'
  except:
   return ''
  return mWEHfTdVQyBFAKLNwhiDgaxJPGrRqc
 def dp_Search_Group(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,args):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY =mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.get_settings_select_info()
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqY=[]
  if 'search_key' in args:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs=args.get('search_key')
  else:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs:
    return
  if 'wavve' in mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_log('wavve search_key : {}'.format(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs))
   (mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqM)=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Search_Wavve(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,'TVSHOW',1)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_log('wavve tvshow cnt : {}'.format(mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)))
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)>0:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS={'sType':'wavve_tvshow','sList':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.MakeText_FreeList(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj),}
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqY.append(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS)
   (mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqM)=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Search_Wavve(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,'MOVIE',1)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_log('wavve movie cnt : {}'.format(mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)))
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)>0:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS={'sType':'wavve_movie','sList':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.MakeText_FreeList(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj),}
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqY.append(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS)
  if 'tving' in mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY:
   (mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqM)=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Search_Tving(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,'TVSHOW',1)
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)>0:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS={'sType':'tving_tvshow','sList':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.MakeText_FreeList(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj),}
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqY.append(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS)
   (mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqM)=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Search_Tving(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,'MOVIE',1)
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)>0:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS={'sType':'tving_movie','sList':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.MakeText_FreeList(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj),}
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqY.append(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS)
  if 'watcha' in mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY:
   (mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqM)=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Search_Watcha(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,1)
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)>0:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS={'sType':'watcha_list','sList':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.MakeText_FreeList(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj),}
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqY.append(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS)
  if 'coupang' in mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY:
   (mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqM)=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Search_Coupang(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,1)
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)>0:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS={'sType':'coupang_list','sList':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.MakeText_FreeList(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj),}
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqY.append(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS)
  if 'netflix' in mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY:
   try:
    (mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqM,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqX)=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Search_Netflix(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,1)
   except:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj=[]
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_noti(__language__(30919).encode('utf8'))
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)>0:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS={'sType':'netflix_list','sList':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.MakeText_FreeList(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj),}
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqY.append(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS)
  if 'amazon' in mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY:
   (mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Search_Primev(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs)
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)>0:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS={'sType':'primev_list','sList':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.MakeText_FreeList(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj),}
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqY.append(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS)
  if 'disney' in mWEHfTdVQyBFAKLNwhiDgaxJPGrRtY:
   try:
    (mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Search_Disney(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs)
   except:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj=[]
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.addon_noti(__language__(30921).encode('utf8'))
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrReX(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj)>0:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS={'sType':'disney_list','sList':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.MakeText_FreeList(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj),}
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRqY.append(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqS)
  for mWEHfTdVQyBFAKLNwhiDgaxJPGrRqo in mWEHfTdVQyBFAKLNwhiDgaxJPGrRqY:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbt=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtb[mWEHfTdVQyBFAKLNwhiDgaxJPGrRqo.get('sType')]
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbp={'plot':'검색어 : '+mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs+'\n\n'+mWEHfTdVQyBFAKLNwhiDgaxJPGrRqo.get('sList')}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbt.get('title')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj={'mode':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbt.get('mode'),'ott':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbt.get('ott'),'vidtype':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbt.get('vidtype'),'search_key':mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs}
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbt.get('ott')=='netflix':
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq=''
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj['page'] ='1'
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj['byReference']='-'
   else:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.make_Hyper_Link(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',mWEHfTdVQyBFAKLNwhiDgaxJPGrRbt.get('icon'))
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.add_dir(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS,sublabel='',img=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpM,infoLabels=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbp,isFolder=mWEHfTdVQyBFAKLNwhiDgaxJPGrReY,params=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj,isLink=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes,direct_url=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq)
  xbmcplugin.endOfDirectory(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv._addon_handle)
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.Save_Searched_List(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs)
 def make_Hyper_Link(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,args):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRbe =args.get('ott')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl =args.get('vidtype')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs=args.get('search_key')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq='-'
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbe=='wavve':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv={'mode':'LOCAL_SEARCH','sType':'movie' if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl=='MOVIE' else 'vod','search_key':mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,'page':'1',}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC=urllib.parse.urlencode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq='plugin://plugin.video.wavvem/?'
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq+=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRbe=='tving':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv={'mode':'LOCAL_SEARCH','stype':'movie' if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl=='MOVIE' else 'vod','search_key':mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,'page':'1',}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC=urllib.parse.urlencode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq='plugin://plugin.video.tvingm/?'
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq+=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRbe=='watcha':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv={'mode':'LOCAL_SEARCH','search_key':mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,'page':'1',}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC=urllib.parse.urlencode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq='plugin://plugin.video.watcham/?'
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq+=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRbe=='coupang':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv={'mode':'LOCAL_SEARCH','search_key':mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,'page':'1',}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC=urllib.parse.urlencode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq='plugin://plugin.video.coupangm/?'
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq+=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRbe=='netflix':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbO=args.get('videoid')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbu=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.NF['SESSION']['nowGuid']
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl=='TVSHOW':
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq='plugin://plugin.video.netflix/directory/show/%s/'%(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbO)
   else:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbO,mWEHfTdVQyBFAKLNwhiDgaxJPGrRbu)
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRbe=='amazon':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,}}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC=json.dumps(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv,separators=(',',':'))
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC=base64.standard_b64encode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC.encode()).decode('utf-8')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC.replace('+','%2B')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq='plugin://plugin.video.primevm/?params='
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq+=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRbe=='disney':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,}}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC=json.dumps(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbv,separators=(',',':'))
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC=base64.standard_b64encode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC.encode()).decode('utf-8')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC.replace('+','%2B')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq='plugin://plugin.video.disneym/?params='
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq+=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbC
  return mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq
 def dp_Nf_Search(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,args):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRbn =mWEHfTdVQyBFAKLNwhiDgaxJPGrRlt(args.get('page'))
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs =args.get('search_key')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqX=args.get('byReference')
  (mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqM,mWEHfTdVQyBFAKLNwhiDgaxJPGrRqX)=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.SearchObj.Get_Search_Netflix(mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs,mWEHfTdVQyBFAKLNwhiDgaxJPGrRbn,byReference=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqX)
  for mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI in mWEHfTdVQyBFAKLNwhiDgaxJPGrRqj:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbO =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('videoid')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('vidtype')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('title')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbz =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('mpaa')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbU =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('regularSynopsis')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbc =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('dpSupplemental')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbk=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('sequiturEvidence')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbY =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('thumbnail')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbs =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('year')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbj =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('duration')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbM =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('info_genre')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbS =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('director')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbX =mWEHfTdVQyBFAKLNwhiDgaxJPGrRbI.get('cast')
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl=='movie':
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRps=' (%s)'%(mWEHfTdVQyBFAKLNwhiDgaxJPGrRlq(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbs))
   else:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRps=''
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbo=''
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbU:mWEHfTdVQyBFAKLNwhiDgaxJPGrRbo=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbo+'\n\n'+mWEHfTdVQyBFAKLNwhiDgaxJPGrRbU
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbc :mWEHfTdVQyBFAKLNwhiDgaxJPGrRbo=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbo+'\n\n'+mWEHfTdVQyBFAKLNwhiDgaxJPGrRbc
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbk:mWEHfTdVQyBFAKLNwhiDgaxJPGrRbo=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbo+'\n\n'+mWEHfTdVQyBFAKLNwhiDgaxJPGrRbk
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbo=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbo.strip()
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpj={'mediatype':'tvshow' if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl=='show' else 'movie','title':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS,'mpaa':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbz,'plot':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbo,'duration':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbj,'genre':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbM,'director':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbS,'cast':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbX,'year':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbs,}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj={'ott':'netflix','vidtype':'TVSHOW' if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl=='show' else 'MOVIE','videoid':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbO,}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.make_Hyper_Link(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRqb=mWEHfTdVQyBFAKLNwhiDgaxJPGrReY if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl=='show' else mWEHfTdVQyBFAKLNwhiDgaxJPGrRes
   if mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.get_settings_makebookmark():
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRet={'mode':'SET_BOOKMARK','values':{'videoid':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbO,'vidtype':'tvshow' if mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl=='show' else 'movie','vtitle':mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS+mWEHfTdVQyBFAKLNwhiDgaxJPGrRps,'vsubtitle':'','vinfo':mWEHfTdVQyBFAKLNwhiDgaxJPGrRpj,'thumbnail':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbY,}}
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRep=json.dumps(mWEHfTdVQyBFAKLNwhiDgaxJPGrRet,separators=(',',':'))
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRep=base64.standard_b64encode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRep.encode()).decode('utf-8')
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRep=mWEHfTdVQyBFAKLNwhiDgaxJPGrRep.replace('+','%2B')
    mWEHfTdVQyBFAKLNwhiDgaxJPGrReq='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(mWEHfTdVQyBFAKLNwhiDgaxJPGrRep)
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRpY=[('(통합) 찜 영상에 추가',mWEHfTdVQyBFAKLNwhiDgaxJPGrReq)]
   else:
    mWEHfTdVQyBFAKLNwhiDgaxJPGrRpY=mWEHfTdVQyBFAKLNwhiDgaxJPGrRek
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.add_dir(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS+mWEHfTdVQyBFAKLNwhiDgaxJPGrRps,sublabel=mWEHfTdVQyBFAKLNwhiDgaxJPGrRek,img=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbY,infoLabels=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpj,isFolder=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqb,params=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj,isLink=mWEHfTdVQyBFAKLNwhiDgaxJPGrRes,ContextMenu=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpY,direct_url=mWEHfTdVQyBFAKLNwhiDgaxJPGrRbq)
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRqM:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj={}
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj['mode'] ='NF_SEARCH' 
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj['page'] =mWEHfTdVQyBFAKLNwhiDgaxJPGrRlq(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbn+1)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj['search_key']=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqs
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj['byReference']=mWEHfTdVQyBFAKLNwhiDgaxJPGrRqX
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS='[B]%s >>[/B]'%'다음 페이지'
   mWEHfTdVQyBFAKLNwhiDgaxJPGrReb=mWEHfTdVQyBFAKLNwhiDgaxJPGrRlq(mWEHfTdVQyBFAKLNwhiDgaxJPGrRbn+1)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRpM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.add_dir(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtS,sublabel=mWEHfTdVQyBFAKLNwhiDgaxJPGrReb,img=mWEHfTdVQyBFAKLNwhiDgaxJPGrRpM,infoLabels=mWEHfTdVQyBFAKLNwhiDgaxJPGrRek,isFolder=mWEHfTdVQyBFAKLNwhiDgaxJPGrReY,params=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj)
  xbmcplugin.setContent(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv._addon_handle,'movies')
  xbmcplugin.endOfDirectory(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv._addon_handle)
 def dp_Bookmark_Menu(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,args):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRel='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(mWEHfTdVQyBFAKLNwhiDgaxJPGrRel)
 def dp_Set_Bookmark(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv,args):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRbO =args.get('videoid')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl =args.get('vidtype')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRev =args.get('vtitle')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrReC =args.get('vsubtitle')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrReO =args.get('vinfo')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRbY =args.get('thumbnail')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI=xbmcgui.Dialog()
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRqt=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtI.yesno(__language__(30917).encode('utf8'),mWEHfTdVQyBFAKLNwhiDgaxJPGrRev+' \n\n'+__language__(30918))
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRqt==mWEHfTdVQyBFAKLNwhiDgaxJPGrRes:return
  mWEHfTdVQyBFAKLNwhiDgaxJPGrReu={'indexinfo':{'ott':'netflix','videoid':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbO,'vidtype':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbl,},'saveinfo':{'title':mWEHfTdVQyBFAKLNwhiDgaxJPGrRev,'subtitle':mWEHfTdVQyBFAKLNwhiDgaxJPGrReC,'thumbnail':mWEHfTdVQyBFAKLNwhiDgaxJPGrRbY,'infoLabels':mWEHfTdVQyBFAKLNwhiDgaxJPGrReO,},}
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':mWEHfTdVQyBFAKLNwhiDgaxJPGrReu,}}
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM=json.dumps(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtj,separators=(',',':'))
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM=base64.standard_b64encode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM.encode()).decode('utf-8')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM.replace('+','%2B')
  mWEHfTdVQyBFAKLNwhiDgaxJPGrReq='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtM)
  xbmc.executebuiltin(mWEHfTdVQyBFAKLNwhiDgaxJPGrReq)
 def search_main(mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv):
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRen=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.main_params.get('params')
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRen:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrReI =base64.standard_b64decode(mWEHfTdVQyBFAKLNwhiDgaxJPGrRen).decode('utf-8')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrReI =json.loads(mWEHfTdVQyBFAKLNwhiDgaxJPGrReI)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRez =mWEHfTdVQyBFAKLNwhiDgaxJPGrReI.get('mode')
   mWEHfTdVQyBFAKLNwhiDgaxJPGrReU =mWEHfTdVQyBFAKLNwhiDgaxJPGrReI.get('values')
  else:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRez=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.main_params.get('mode',mWEHfTdVQyBFAKLNwhiDgaxJPGrRek)
   mWEHfTdVQyBFAKLNwhiDgaxJPGrReU=mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.main_params
  mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.option_check()
  if mWEHfTdVQyBFAKLNwhiDgaxJPGrRez is mWEHfTdVQyBFAKLNwhiDgaxJPGrRek:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.dp_Main_List()
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRez=='TOTAL_SEARCH':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.dp_Search_Group(mWEHfTdVQyBFAKLNwhiDgaxJPGrReU)
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRez=='NF_SEARCH':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.dp_Nf_Search(mWEHfTdVQyBFAKLNwhiDgaxJPGrReU)
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRez=='TOTAL_HISTORY':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.dp_Search_History(mWEHfTdVQyBFAKLNwhiDgaxJPGrReU)
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRez=='HISTORY_REMOVE':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.dp_History_Delete(mWEHfTdVQyBFAKLNwhiDgaxJPGrReU)
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRez=='MENU_BOOKMARK':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.dp_Bookmark_Menu(mWEHfTdVQyBFAKLNwhiDgaxJPGrReU)
  elif mWEHfTdVQyBFAKLNwhiDgaxJPGrRez=='SET_BOOKMARK':
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRtv.dp_Set_Bookmark(mWEHfTdVQyBFAKLNwhiDgaxJPGrReU)
  else:
   mWEHfTdVQyBFAKLNwhiDgaxJPGrRek
# Created by pyminifier (https://github.com/liftoff/pyminifier)
