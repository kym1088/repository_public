__author__="NightRain"
UfzEeWiCgDtqMFlJcAdnRmasHBOPru=object
UfzEeWiCgDtqMFlJcAdnRmasHBOPrS=None
UfzEeWiCgDtqMFlJcAdnRmasHBOPrw=True
UfzEeWiCgDtqMFlJcAdnRmasHBOPrj=False
UfzEeWiCgDtqMFlJcAdnRmasHBOPrv=type
UfzEeWiCgDtqMFlJcAdnRmasHBOPrb=dict
UfzEeWiCgDtqMFlJcAdnRmasHBOPrk=open
UfzEeWiCgDtqMFlJcAdnRmasHBOPrK=len
UfzEeWiCgDtqMFlJcAdnRmasHBOPrX=Exception
UfzEeWiCgDtqMFlJcAdnRmasHBOPrh=range
UfzEeWiCgDtqMFlJcAdnRmasHBOPrQ=int
UfzEeWiCgDtqMFlJcAdnRmasHBOPrx=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
UfzEeWiCgDtqMFlJcAdnRmasHBOPGo=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
UfzEeWiCgDtqMFlJcAdnRmasHBOPGT={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'HYPER_LINK','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'HYPER_LINK','ott':'amazon','vidtype':'-','icon':'primev.png'},}
UfzEeWiCgDtqMFlJcAdnRmasHBOPGr=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
UfzEeWiCgDtqMFlJcAdnRmasHBOPGp =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class UfzEeWiCgDtqMFlJcAdnRmasHBOPGV(UfzEeWiCgDtqMFlJcAdnRmasHBOPru):
 def __init__(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,UfzEeWiCgDtqMFlJcAdnRmasHBOPGu,UfzEeWiCgDtqMFlJcAdnRmasHBOPGS,UfzEeWiCgDtqMFlJcAdnRmasHBOPGw):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN._addon_url =UfzEeWiCgDtqMFlJcAdnRmasHBOPGu
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN._addon_handle=UfzEeWiCgDtqMFlJcAdnRmasHBOPGS
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.main_params =UfzEeWiCgDtqMFlJcAdnRmasHBOPGw
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj =JnmpfLkuzHexYbolSdqOaTWswyEVUX() 
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_cookies.pk'))
 def addon_noti(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,sting):
  try:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGv=xbmcgui.Dialog()
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGv.notification(__addonname__,sting)
  except:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPrS
 def addon_log(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,string):
  try:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGb=string.encode('utf-8','ignore')
  except:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGb='addonException: addon_log'
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGk=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,UfzEeWiCgDtqMFlJcAdnRmasHBOPGb),level=UfzEeWiCgDtqMFlJcAdnRmasHBOPGk)
 def get_keyboard_input(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,UfzEeWiCgDtqMFlJcAdnRmasHBOPGx):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGK=UfzEeWiCgDtqMFlJcAdnRmasHBOPrS
  kb=xbmc.Keyboard()
  kb.setHeading(UfzEeWiCgDtqMFlJcAdnRmasHBOPGx)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGK=kb.getText()
  return UfzEeWiCgDtqMFlJcAdnRmasHBOPGK
 def get_settings_menubookmark(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGX=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw if __addon__.getSetting('menu_bookmark')=='true' else UfzEeWiCgDtqMFlJcAdnRmasHBOPrj
  return(UfzEeWiCgDtqMFlJcAdnRmasHBOPGX)
 def get_settings_makebookmark(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN):
  return UfzEeWiCgDtqMFlJcAdnRmasHBOPrw if __addon__.getSetting('make_bookmark')=='true' else UfzEeWiCgDtqMFlJcAdnRmasHBOPrj
 def get_settings_select_info(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGh=[]
  if __addon__.getSetting('netflixyn')=='true':UfzEeWiCgDtqMFlJcAdnRmasHBOPGh.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':UfzEeWiCgDtqMFlJcAdnRmasHBOPGh.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':UfzEeWiCgDtqMFlJcAdnRmasHBOPGh.append('tving')
  if __addon__.getSetting('watchayn')=='true':UfzEeWiCgDtqMFlJcAdnRmasHBOPGh.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':UfzEeWiCgDtqMFlJcAdnRmasHBOPGh.append('coupang')
  if __addon__.getSetting('primevyn')=='true':UfzEeWiCgDtqMFlJcAdnRmasHBOPGh.append('amazon')
  return UfzEeWiCgDtqMFlJcAdnRmasHBOPGh
 def add_dir(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,label,sublabel='',img='',infoLabels=UfzEeWiCgDtqMFlJcAdnRmasHBOPrS,isFolder=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw,params='',isLink=UfzEeWiCgDtqMFlJcAdnRmasHBOPrj,ContextMenu=UfzEeWiCgDtqMFlJcAdnRmasHBOPrS):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGQ='%s?%s'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN._addon_url,urllib.parse.urlencode(params))
  if sublabel:UfzEeWiCgDtqMFlJcAdnRmasHBOPGx='%s < %s >'%(label,sublabel)
  else: UfzEeWiCgDtqMFlJcAdnRmasHBOPGx=label
  if not img:img='DefaultFolder.png'
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGy=xbmcgui.ListItem(UfzEeWiCgDtqMFlJcAdnRmasHBOPGx)
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPrv(img)==UfzEeWiCgDtqMFlJcAdnRmasHBOPrb:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGy.setArt(img)
  else:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGy.setArt({'thumb':img,'poster':img})
  if infoLabels:UfzEeWiCgDtqMFlJcAdnRmasHBOPGy.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGy.setProperty('IsPlayable','true')
  if ContextMenu:UfzEeWiCgDtqMFlJcAdnRmasHBOPGy.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN._addon_handle,UfzEeWiCgDtqMFlJcAdnRmasHBOPGQ,UfzEeWiCgDtqMFlJcAdnRmasHBOPGy,isFolder)
 def Load_Searched_List(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN):
  try:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGL=UfzEeWiCgDtqMFlJcAdnRmasHBOPGp
   fp=UfzEeWiCgDtqMFlJcAdnRmasHBOPrk(UfzEeWiCgDtqMFlJcAdnRmasHBOPGL,'r',-1,'utf-8')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGI=fp.readlines()
   fp.close()
  except:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGI=[]
  return UfzEeWiCgDtqMFlJcAdnRmasHBOPGI
 def Save_Searched_List(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,UfzEeWiCgDtqMFlJcAdnRmasHBOPok):
  try:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGL=UfzEeWiCgDtqMFlJcAdnRmasHBOPGp
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGY=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.Load_Searched_List() 
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVG={'skey':UfzEeWiCgDtqMFlJcAdnRmasHBOPok.strip()}
   fp=UfzEeWiCgDtqMFlJcAdnRmasHBOPrk(UfzEeWiCgDtqMFlJcAdnRmasHBOPGL,'w',-1,'utf-8')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVo=urllib.parse.urlencode(UfzEeWiCgDtqMFlJcAdnRmasHBOPVG)
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVo=UfzEeWiCgDtqMFlJcAdnRmasHBOPVo+'\n'
   fp.write(UfzEeWiCgDtqMFlJcAdnRmasHBOPVo)
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVT=0
   for UfzEeWiCgDtqMFlJcAdnRmasHBOPVr in UfzEeWiCgDtqMFlJcAdnRmasHBOPGY:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPVp=UfzEeWiCgDtqMFlJcAdnRmasHBOPrb(urllib.parse.parse_qsl(UfzEeWiCgDtqMFlJcAdnRmasHBOPVr))
    UfzEeWiCgDtqMFlJcAdnRmasHBOPVN=UfzEeWiCgDtqMFlJcAdnRmasHBOPVG.get('skey').strip()
    UfzEeWiCgDtqMFlJcAdnRmasHBOPVu=UfzEeWiCgDtqMFlJcAdnRmasHBOPVp.get('skey').strip()
    if UfzEeWiCgDtqMFlJcAdnRmasHBOPVN!=UfzEeWiCgDtqMFlJcAdnRmasHBOPVu:
     fp.write(UfzEeWiCgDtqMFlJcAdnRmasHBOPVr)
     UfzEeWiCgDtqMFlJcAdnRmasHBOPVT+=1
     if UfzEeWiCgDtqMFlJcAdnRmasHBOPVT>=50:break
   fp.close()
  except:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPrS
 def dp_Search_History(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,args):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPVS=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.Load_Searched_List()
  for UfzEeWiCgDtqMFlJcAdnRmasHBOPVw in UfzEeWiCgDtqMFlJcAdnRmasHBOPVS:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVj=UfzEeWiCgDtqMFlJcAdnRmasHBOPrb(urllib.parse.parse_qsl(UfzEeWiCgDtqMFlJcAdnRmasHBOPVw))
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVv=UfzEeWiCgDtqMFlJcAdnRmasHBOPVj.get('skey').strip()
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVb={'mode':'TOTAL_SEARCH','search_key':UfzEeWiCgDtqMFlJcAdnRmasHBOPVv,}
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVk={'mode':'HISTORY_REMOVE','skey':UfzEeWiCgDtqMFlJcAdnRmasHBOPVv,'delmode':'ONE',}
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVK=urllib.parse.urlencode(UfzEeWiCgDtqMFlJcAdnRmasHBOPVk)
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVX=[('선택된 검색어 ( %s ) 삭제'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPVv),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPVK))]
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.add_dir(UfzEeWiCgDtqMFlJcAdnRmasHBOPVv,sublabel='',img=UfzEeWiCgDtqMFlJcAdnRmasHBOPrS,infoLabels=UfzEeWiCgDtqMFlJcAdnRmasHBOPrS,isFolder=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw,params=UfzEeWiCgDtqMFlJcAdnRmasHBOPVb,ContextMenu=UfzEeWiCgDtqMFlJcAdnRmasHBOPVX)
  UfzEeWiCgDtqMFlJcAdnRmasHBOPVQ={'plot':'검색목록 전체를 삭제합니다.'}
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGx='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  UfzEeWiCgDtqMFlJcAdnRmasHBOPVb={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  UfzEeWiCgDtqMFlJcAdnRmasHBOPVx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.add_dir(UfzEeWiCgDtqMFlJcAdnRmasHBOPGx,sublabel='',img=UfzEeWiCgDtqMFlJcAdnRmasHBOPVx,infoLabels=UfzEeWiCgDtqMFlJcAdnRmasHBOPVQ,isFolder=UfzEeWiCgDtqMFlJcAdnRmasHBOPrj,params=UfzEeWiCgDtqMFlJcAdnRmasHBOPVb,isLink=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw)
  xbmcplugin.endOfDirectory(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN._addon_handle,cacheToDisc=UfzEeWiCgDtqMFlJcAdnRmasHBOPrj)
 def Delete_History_List(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,UfzEeWiCgDtqMFlJcAdnRmasHBOPVv,UfzEeWiCgDtqMFlJcAdnRmasHBOPVI):
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPVI=='ALL':
   try:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPGL=UfzEeWiCgDtqMFlJcAdnRmasHBOPGp
    fp=UfzEeWiCgDtqMFlJcAdnRmasHBOPrk(UfzEeWiCgDtqMFlJcAdnRmasHBOPGL,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPrS
  else:
   try:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPGL=UfzEeWiCgDtqMFlJcAdnRmasHBOPGp
    UfzEeWiCgDtqMFlJcAdnRmasHBOPGY=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.Load_Searched_List() 
    fp=UfzEeWiCgDtqMFlJcAdnRmasHBOPrk(UfzEeWiCgDtqMFlJcAdnRmasHBOPGL,'w',-1,'utf-8')
    for UfzEeWiCgDtqMFlJcAdnRmasHBOPVr in UfzEeWiCgDtqMFlJcAdnRmasHBOPGY:
     UfzEeWiCgDtqMFlJcAdnRmasHBOPVp=UfzEeWiCgDtqMFlJcAdnRmasHBOPrb(urllib.parse.parse_qsl(UfzEeWiCgDtqMFlJcAdnRmasHBOPVr))
     UfzEeWiCgDtqMFlJcAdnRmasHBOPVL=UfzEeWiCgDtqMFlJcAdnRmasHBOPVp.get('skey').strip()
     if UfzEeWiCgDtqMFlJcAdnRmasHBOPVv!=UfzEeWiCgDtqMFlJcAdnRmasHBOPVL:
      fp.write(UfzEeWiCgDtqMFlJcAdnRmasHBOPVr)
    fp.close()
   except:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPrS
 def dp_History_Delete(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,args):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPVv =args.get('skey') 
  UfzEeWiCgDtqMFlJcAdnRmasHBOPVI=args.get('delmode')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGv=xbmcgui.Dialog()
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPVI=='ALL':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVY=UfzEeWiCgDtqMFlJcAdnRmasHBOPGv.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVY=UfzEeWiCgDtqMFlJcAdnRmasHBOPGv.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPVY==UfzEeWiCgDtqMFlJcAdnRmasHBOPrj:sys.exit()
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.Delete_History_List(UfzEeWiCgDtqMFlJcAdnRmasHBOPVv,UfzEeWiCgDtqMFlJcAdnRmasHBOPVI)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGX=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.get_settings_menubookmark()
  for UfzEeWiCgDtqMFlJcAdnRmasHBOPoG in UfzEeWiCgDtqMFlJcAdnRmasHBOPGo:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGx=UfzEeWiCgDtqMFlJcAdnRmasHBOPoG.get('title')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVx=''
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPoG.get('mode')=='MENU_BOOKMARK' and UfzEeWiCgDtqMFlJcAdnRmasHBOPGX==UfzEeWiCgDtqMFlJcAdnRmasHBOPrj:continue
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVb={'mode':UfzEeWiCgDtqMFlJcAdnRmasHBOPoG.get('mode')}
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPoG.get('mode')in['XXX','MENU_BOOKMARK']:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoV=UfzEeWiCgDtqMFlJcAdnRmasHBOPrj
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoT =UfzEeWiCgDtqMFlJcAdnRmasHBOPrw
   else:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoV=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoT =UfzEeWiCgDtqMFlJcAdnRmasHBOPrj
   if 'icon' in UfzEeWiCgDtqMFlJcAdnRmasHBOPoG:UfzEeWiCgDtqMFlJcAdnRmasHBOPVx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',UfzEeWiCgDtqMFlJcAdnRmasHBOPoG.get('icon')) 
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.add_dir(UfzEeWiCgDtqMFlJcAdnRmasHBOPGx,sublabel='',img=UfzEeWiCgDtqMFlJcAdnRmasHBOPVx,infoLabels=UfzEeWiCgDtqMFlJcAdnRmasHBOPrS,isFolder=UfzEeWiCgDtqMFlJcAdnRmasHBOPoV,params=UfzEeWiCgDtqMFlJcAdnRmasHBOPVb,isLink=UfzEeWiCgDtqMFlJcAdnRmasHBOPoT)
  xbmcplugin.endOfDirectory(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN._addon_handle,cacheToDisc=UfzEeWiCgDtqMFlJcAdnRmasHBOPrj)
 def option_check(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGh=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.get_settings_select_info()
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPrK(UfzEeWiCgDtqMFlJcAdnRmasHBOPGh)==0:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGv=xbmcgui.Dialog()
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVY=UfzEeWiCgDtqMFlJcAdnRmasHBOPGv.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPVY==UfzEeWiCgDtqMFlJcAdnRmasHBOPrw:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in UfzEeWiCgDtqMFlJcAdnRmasHBOPGh:
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.NF_cookiefile_check()==UfzEeWiCgDtqMFlJcAdnRmasHBOPrj:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.NF_login(showMessage=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw)
 def NF_cookiefile_check(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPop={}
  try: 
   fp=UfzEeWiCgDtqMFlJcAdnRmasHBOPrk(UfzEeWiCgDtqMFlJcAdnRmasHBOPGr,'r',-1,'utf-8')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPop= json.load(fp)
   fp.close()
  except UfzEeWiCgDtqMFlJcAdnRmasHBOPrX as exception:
   return UfzEeWiCgDtqMFlJcAdnRmasHBOPrj
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF=UfzEeWiCgDtqMFlJcAdnRmasHBOPop
  UfzEeWiCgDtqMFlJcAdnRmasHBOPoN=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF_CookieFile_Load(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF_ORIGINAL_COOKIE)
  if(UfzEeWiCgDtqMFlJcAdnRmasHBOPoN['NetflixId']!=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF['COOKIES']['NetflixId']or UfzEeWiCgDtqMFlJcAdnRmasHBOPoN['SecureNetflixId']!=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF['COOKIES']['SecureNetflixId']or UfzEeWiCgDtqMFlJcAdnRmasHBOPoN['flwssn']!=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF['COOKIES']['flwssn']or UfzEeWiCgDtqMFlJcAdnRmasHBOPoN['memclid']!=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF['COOKIES']['memclid']or UfzEeWiCgDtqMFlJcAdnRmasHBOPoN['nfvdid']!=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF['COOKIES']['nfvdid']):
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.Init_NF_Total()
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.NF_login(showMessage=UfzEeWiCgDtqMFlJcAdnRmasHBOPrj)==UfzEeWiCgDtqMFlJcAdnRmasHBOPrj:
    return UfzEeWiCgDtqMFlJcAdnRmasHBOPrj
  return UfzEeWiCgDtqMFlJcAdnRmasHBOPrw
 def NF_login(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,showMessage=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw):
  if showMessage:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGv=xbmcgui.Dialog()
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVY=UfzEeWiCgDtqMFlJcAdnRmasHBOPGv.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPVY==UfzEeWiCgDtqMFlJcAdnRmasHBOPrj:
    return UfzEeWiCgDtqMFlJcAdnRmasHBOPrj 
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF['COOKIES']=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF_CookieFile_Load(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF_ORIGINAL_COOKIE)
  UfzEeWiCgDtqMFlJcAdnRmasHBOPou=UfzEeWiCgDtqMFlJcAdnRmasHBOPrj if UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF['COOKIES']=={}else UfzEeWiCgDtqMFlJcAdnRmasHBOPrw
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPou:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_log('pass1 ok!')
  else:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_log('pass1 error!')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_noti(__language__(30905).encode('utf-8'))
   return UfzEeWiCgDtqMFlJcAdnRmasHBOPrj 
  UfzEeWiCgDtqMFlJcAdnRmasHBOPou=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF_Get_BaseSession()
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPou:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_log('pass2 ok!')
  else:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_log('pass2 error!')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_noti(__language__(30905).encode('utf-8'))
   return UfzEeWiCgDtqMFlJcAdnRmasHBOPrj 
  UfzEeWiCgDtqMFlJcAdnRmasHBOPoS =UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.Get_Now_Datetime()
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF['SESSION']['limitdate']=UfzEeWiCgDtqMFlJcAdnRmasHBOPoS.strftime('%Y-%m-%d')
  try: 
   fp=UfzEeWiCgDtqMFlJcAdnRmasHBOPrk(UfzEeWiCgDtqMFlJcAdnRmasHBOPGr,'w',-1,'utf-8')
   json.dump(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF,fp,indent=4,ensure_ascii=UfzEeWiCgDtqMFlJcAdnRmasHBOPrj)
   fp.close()
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_log('pass3 save ok!')
  except UfzEeWiCgDtqMFlJcAdnRmasHBOPrX as exception:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_log('pass3 save error!')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_noti(__language__(30905).encode('utf-8'))
   return UfzEeWiCgDtqMFlJcAdnRmasHBOPrj
  if showMessage:UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_noti(__language__(30904).encode('utf-8'))
  return UfzEeWiCgDtqMFlJcAdnRmasHBOPrw
 def NF_logout(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGv=xbmcgui.Dialog()
  UfzEeWiCgDtqMFlJcAdnRmasHBOPVY=UfzEeWiCgDtqMFlJcAdnRmasHBOPGv.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPVY==UfzEeWiCgDtqMFlJcAdnRmasHBOPrj:return 
  if os.path.isfile(UfzEeWiCgDtqMFlJcAdnRmasHBOPGr):os.remove(UfzEeWiCgDtqMFlJcAdnRmasHBOPGr)
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,UfzEeWiCgDtqMFlJcAdnRmasHBOPoK):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPoj=''
  UfzEeWiCgDtqMFlJcAdnRmasHBOPov=7
  try:
   for i in UfzEeWiCgDtqMFlJcAdnRmasHBOPrh(UfzEeWiCgDtqMFlJcAdnRmasHBOPrK(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK)):
    if i>=UfzEeWiCgDtqMFlJcAdnRmasHBOPov:
     UfzEeWiCgDtqMFlJcAdnRmasHBOPoj=UfzEeWiCgDtqMFlJcAdnRmasHBOPoj+'...'
     break
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoj=UfzEeWiCgDtqMFlJcAdnRmasHBOPoj+UfzEeWiCgDtqMFlJcAdnRmasHBOPoK[i]['title']+'\n'
  except:
   return ''
  return UfzEeWiCgDtqMFlJcAdnRmasHBOPoj
 def dp_Search_Group(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,args):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGh =UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.get_settings_select_info()
  UfzEeWiCgDtqMFlJcAdnRmasHBOPob=[]
  if 'search_key' in args:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPok=args.get('search_key')
  else:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPok=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not UfzEeWiCgDtqMFlJcAdnRmasHBOPok:
    return
  if 'wavve' in UfzEeWiCgDtqMFlJcAdnRmasHBOPGh:
   (UfzEeWiCgDtqMFlJcAdnRmasHBOPoK,UfzEeWiCgDtqMFlJcAdnRmasHBOPoX)=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.Get_Search_Wavve(UfzEeWiCgDtqMFlJcAdnRmasHBOPok,'TVSHOW',1)
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPrK(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK)>0:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoh={'sType':'wavve_tvshow','sList':UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.MakeText_FreeList(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK),}
    UfzEeWiCgDtqMFlJcAdnRmasHBOPob.append(UfzEeWiCgDtqMFlJcAdnRmasHBOPoh)
   (UfzEeWiCgDtqMFlJcAdnRmasHBOPoK,UfzEeWiCgDtqMFlJcAdnRmasHBOPoX)=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.Get_Search_Wavve(UfzEeWiCgDtqMFlJcAdnRmasHBOPok,'MOVIE',1)
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPrK(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK)>0:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoh={'sType':'wavve_movie','sList':UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.MakeText_FreeList(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK),}
    UfzEeWiCgDtqMFlJcAdnRmasHBOPob.append(UfzEeWiCgDtqMFlJcAdnRmasHBOPoh)
  if 'tving' in UfzEeWiCgDtqMFlJcAdnRmasHBOPGh:
   (UfzEeWiCgDtqMFlJcAdnRmasHBOPoK,UfzEeWiCgDtqMFlJcAdnRmasHBOPoX)=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.Get_Search_Tving(UfzEeWiCgDtqMFlJcAdnRmasHBOPok,'TVSHOW',1)
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPrK(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK)>0:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoh={'sType':'tving_tvshow','sList':UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.MakeText_FreeList(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK),}
    UfzEeWiCgDtqMFlJcAdnRmasHBOPob.append(UfzEeWiCgDtqMFlJcAdnRmasHBOPoh)
   (UfzEeWiCgDtqMFlJcAdnRmasHBOPoK,UfzEeWiCgDtqMFlJcAdnRmasHBOPoX)=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.Get_Search_Tving(UfzEeWiCgDtqMFlJcAdnRmasHBOPok,'MOVIE',1)
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPrK(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK)>0:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoh={'sType':'tving_movie','sList':UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.MakeText_FreeList(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK),}
    UfzEeWiCgDtqMFlJcAdnRmasHBOPob.append(UfzEeWiCgDtqMFlJcAdnRmasHBOPoh)
  if 'watcha' in UfzEeWiCgDtqMFlJcAdnRmasHBOPGh:
   (UfzEeWiCgDtqMFlJcAdnRmasHBOPoK,UfzEeWiCgDtqMFlJcAdnRmasHBOPoX)=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.Get_Search_Watcha(UfzEeWiCgDtqMFlJcAdnRmasHBOPok,1)
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPrK(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK)>0:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoh={'sType':'watcha_list','sList':UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.MakeText_FreeList(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK),}
    UfzEeWiCgDtqMFlJcAdnRmasHBOPob.append(UfzEeWiCgDtqMFlJcAdnRmasHBOPoh)
  if 'coupang' in UfzEeWiCgDtqMFlJcAdnRmasHBOPGh:
   (UfzEeWiCgDtqMFlJcAdnRmasHBOPoK,UfzEeWiCgDtqMFlJcAdnRmasHBOPoX)=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.Get_Search_Coupang(UfzEeWiCgDtqMFlJcAdnRmasHBOPok,1)
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPrK(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK)>0:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoh={'sType':'coupang_list','sList':UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.MakeText_FreeList(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK),}
    UfzEeWiCgDtqMFlJcAdnRmasHBOPob.append(UfzEeWiCgDtqMFlJcAdnRmasHBOPoh)
  if 'netflix' in UfzEeWiCgDtqMFlJcAdnRmasHBOPGh:
   try:
    (UfzEeWiCgDtqMFlJcAdnRmasHBOPoK,UfzEeWiCgDtqMFlJcAdnRmasHBOPoX,UfzEeWiCgDtqMFlJcAdnRmasHBOPoQ)=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.Get_Search_Netflix(UfzEeWiCgDtqMFlJcAdnRmasHBOPok,1)
   except:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoK=[]
    UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_noti(__language__(30919).encode('utf8'))
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPrK(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK)>0:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoh={'sType':'netflix_list','sList':UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.MakeText_FreeList(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK),}
    UfzEeWiCgDtqMFlJcAdnRmasHBOPob.append(UfzEeWiCgDtqMFlJcAdnRmasHBOPoh)
  if 'amazon' in UfzEeWiCgDtqMFlJcAdnRmasHBOPGh:
   (UfzEeWiCgDtqMFlJcAdnRmasHBOPoK)=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.Get_Search_Primev(UfzEeWiCgDtqMFlJcAdnRmasHBOPok)
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPrK(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK)>0:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPoh={'sType':'primev_list','sList':UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.MakeText_FreeList(UfzEeWiCgDtqMFlJcAdnRmasHBOPoK),}
    UfzEeWiCgDtqMFlJcAdnRmasHBOPob.append(UfzEeWiCgDtqMFlJcAdnRmasHBOPoh)
  for UfzEeWiCgDtqMFlJcAdnRmasHBOPox in UfzEeWiCgDtqMFlJcAdnRmasHBOPob:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPoy=UfzEeWiCgDtqMFlJcAdnRmasHBOPGT[UfzEeWiCgDtqMFlJcAdnRmasHBOPox.get('sType')]
   UfzEeWiCgDtqMFlJcAdnRmasHBOPoL={'plot':'검색어 : '+UfzEeWiCgDtqMFlJcAdnRmasHBOPok+'\n\n'+UfzEeWiCgDtqMFlJcAdnRmasHBOPox.get('sList')}
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGx=UfzEeWiCgDtqMFlJcAdnRmasHBOPoy.get('title')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVb={'mode':UfzEeWiCgDtqMFlJcAdnRmasHBOPoy.get('mode'),'ott':UfzEeWiCgDtqMFlJcAdnRmasHBOPoy.get('ott'),'vidtype':UfzEeWiCgDtqMFlJcAdnRmasHBOPoy.get('vidtype'),'search_key':UfzEeWiCgDtqMFlJcAdnRmasHBOPok}
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPoy.get('ott')=='netflix':
    UfzEeWiCgDtqMFlJcAdnRmasHBOPVb['page'] ='1'
    UfzEeWiCgDtqMFlJcAdnRmasHBOPVb['byReference']='-'
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',UfzEeWiCgDtqMFlJcAdnRmasHBOPoy.get('icon'))
   UfzEeWiCgDtqMFlJcAdnRmasHBOPoV=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw if UfzEeWiCgDtqMFlJcAdnRmasHBOPoy.get('mode')!='HYPER_LINK' else UfzEeWiCgDtqMFlJcAdnRmasHBOPrj
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.add_dir(UfzEeWiCgDtqMFlJcAdnRmasHBOPGx,sublabel='',img=UfzEeWiCgDtqMFlJcAdnRmasHBOPVx,infoLabels=UfzEeWiCgDtqMFlJcAdnRmasHBOPoL,isFolder=UfzEeWiCgDtqMFlJcAdnRmasHBOPoV,params=UfzEeWiCgDtqMFlJcAdnRmasHBOPVb,isLink=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw)
  xbmcplugin.endOfDirectory(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN._addon_handle)
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.Save_Searched_List(UfzEeWiCgDtqMFlJcAdnRmasHBOPok)
 def dp_Hyper_Link(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,args):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPoI =args.get('mode')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPoY =args.get('ott')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPTG =args.get('vidtype')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPok=args.get('search_key')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPTV='-'
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPoY=='wavve':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTo={'mode':'LOCAL_SEARCH','sType':'movie' if UfzEeWiCgDtqMFlJcAdnRmasHBOPTG=='MOVIE' else 'vod','search_key':UfzEeWiCgDtqMFlJcAdnRmasHBOPok,'page':'1',}
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTr=urllib.parse.urlencode(UfzEeWiCgDtqMFlJcAdnRmasHBOPTo)
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTV='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPTr)
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoY=='tving':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTo={'mode':'LOCAL_SEARCH','stype':'movie' if UfzEeWiCgDtqMFlJcAdnRmasHBOPTG=='MOVIE' else 'vod','search_key':UfzEeWiCgDtqMFlJcAdnRmasHBOPok,'page':'1',}
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTr=urllib.parse.urlencode(UfzEeWiCgDtqMFlJcAdnRmasHBOPTo)
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTV='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPTr)
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoY=='watcha':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTo={'mode':'LOCAL_SEARCH','search_key':UfzEeWiCgDtqMFlJcAdnRmasHBOPok,'page':'1',}
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTr=urllib.parse.urlencode(UfzEeWiCgDtqMFlJcAdnRmasHBOPTo)
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTV='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPTr)
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoY=='coupang':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTo={'mode':'LOCAL_SEARCH','search_key':UfzEeWiCgDtqMFlJcAdnRmasHBOPok,'page':'1',}
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTr=urllib.parse.urlencode(UfzEeWiCgDtqMFlJcAdnRmasHBOPTo)
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTV='ActivateWindow(10025,"plugin://plugin.video.coupangm/?%s",return)'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPTr)
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoY=='netflix':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTp=args.get('videoid')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTN=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.NF['SESSION']['nowGuid']
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPTG=='TVSHOW':
    UfzEeWiCgDtqMFlJcAdnRmasHBOPTV='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPTp)
   else:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPTV='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPTp,UfzEeWiCgDtqMFlJcAdnRmasHBOPTN)
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoY=='amazon':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTo={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':UfzEeWiCgDtqMFlJcAdnRmasHBOPok,}}
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTr=json.dumps(UfzEeWiCgDtqMFlJcAdnRmasHBOPTo,separators=(',',':'))
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTr=base64.standard_b64encode(UfzEeWiCgDtqMFlJcAdnRmasHBOPTr.encode()).decode('utf-8')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTr=UfzEeWiCgDtqMFlJcAdnRmasHBOPTr.replace('+','%2B')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_log('ott_param_str : '+UfzEeWiCgDtqMFlJcAdnRmasHBOPTr)
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTV='ActivateWindow(10025,"plugin://plugin.video.primevm/?params=%s",return)'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPTr)
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.addon_log('ott_url ==> ( '+UfzEeWiCgDtqMFlJcAdnRmasHBOPTV+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(UfzEeWiCgDtqMFlJcAdnRmasHBOPTV)
 def dp_Nf_Search(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,args):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPTu =UfzEeWiCgDtqMFlJcAdnRmasHBOPrQ(args.get('page'))
  UfzEeWiCgDtqMFlJcAdnRmasHBOPok =args.get('search_key')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPoQ=args.get('byReference')
  (UfzEeWiCgDtqMFlJcAdnRmasHBOPoK,UfzEeWiCgDtqMFlJcAdnRmasHBOPoX,UfzEeWiCgDtqMFlJcAdnRmasHBOPoQ)=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.SearchObj.Get_Search_Netflix(UfzEeWiCgDtqMFlJcAdnRmasHBOPok,UfzEeWiCgDtqMFlJcAdnRmasHBOPTu,byReference=UfzEeWiCgDtqMFlJcAdnRmasHBOPoQ)
  for UfzEeWiCgDtqMFlJcAdnRmasHBOPTS in UfzEeWiCgDtqMFlJcAdnRmasHBOPoK:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTp =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('videoid')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTG =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('vidtype')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGx =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('title')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTw =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('mpaa')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTj =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('regularSynopsis')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTv =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('dpSupplemental')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTb=UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('sequiturEvidence')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTk =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('thumbnail')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTK =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('year')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTX =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('duration')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTh =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('info_genre')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTQ =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('director')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTx =UfzEeWiCgDtqMFlJcAdnRmasHBOPTS.get('cast')
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPTG=='movie':
    UfzEeWiCgDtqMFlJcAdnRmasHBOPVh=' (%s)'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPrx(UfzEeWiCgDtqMFlJcAdnRmasHBOPTK))
   else:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPVh=''
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTy=''
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPTj:UfzEeWiCgDtqMFlJcAdnRmasHBOPTy=UfzEeWiCgDtqMFlJcAdnRmasHBOPTy+'\n\n'+UfzEeWiCgDtqMFlJcAdnRmasHBOPTj
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPTv :UfzEeWiCgDtqMFlJcAdnRmasHBOPTy=UfzEeWiCgDtqMFlJcAdnRmasHBOPTy+'\n\n'+UfzEeWiCgDtqMFlJcAdnRmasHBOPTv
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPTb:UfzEeWiCgDtqMFlJcAdnRmasHBOPTy=UfzEeWiCgDtqMFlJcAdnRmasHBOPTy+'\n\n'+UfzEeWiCgDtqMFlJcAdnRmasHBOPTb
   UfzEeWiCgDtqMFlJcAdnRmasHBOPTy=UfzEeWiCgDtqMFlJcAdnRmasHBOPTy.strip()
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVQ={'mediatype':'tvshow' if UfzEeWiCgDtqMFlJcAdnRmasHBOPTG=='show' else 'movie','title':UfzEeWiCgDtqMFlJcAdnRmasHBOPGx,'mpaa':UfzEeWiCgDtqMFlJcAdnRmasHBOPTw,'plot':UfzEeWiCgDtqMFlJcAdnRmasHBOPTy,'duration':UfzEeWiCgDtqMFlJcAdnRmasHBOPTX,'genre':UfzEeWiCgDtqMFlJcAdnRmasHBOPTh,'director':UfzEeWiCgDtqMFlJcAdnRmasHBOPTQ,'cast':UfzEeWiCgDtqMFlJcAdnRmasHBOPTx,'year':UfzEeWiCgDtqMFlJcAdnRmasHBOPTK,}
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVb={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if UfzEeWiCgDtqMFlJcAdnRmasHBOPTG=='show' else 'MOVIE','videoid':UfzEeWiCgDtqMFlJcAdnRmasHBOPTp,}
   if UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.get_settings_makebookmark():
    UfzEeWiCgDtqMFlJcAdnRmasHBOPTL={'videoid':UfzEeWiCgDtqMFlJcAdnRmasHBOPTp,'vidtype':'tvshow' if UfzEeWiCgDtqMFlJcAdnRmasHBOPTG=='show' else 'movie','vtitle':UfzEeWiCgDtqMFlJcAdnRmasHBOPGx+UfzEeWiCgDtqMFlJcAdnRmasHBOPVh,'vsubtitle':'','vinfo':UfzEeWiCgDtqMFlJcAdnRmasHBOPVQ,'thumbnail':UfzEeWiCgDtqMFlJcAdnRmasHBOPTk,}
    UfzEeWiCgDtqMFlJcAdnRmasHBOPTI=json.dumps(UfzEeWiCgDtqMFlJcAdnRmasHBOPTL)
    UfzEeWiCgDtqMFlJcAdnRmasHBOPTI=urllib.parse.quote(UfzEeWiCgDtqMFlJcAdnRmasHBOPTI)
    UfzEeWiCgDtqMFlJcAdnRmasHBOPTY='RunPlugin(plugin://plugin.video.searchm/?mode=SET_BOOKMARK&bm_param=%s)'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPTI)
    UfzEeWiCgDtqMFlJcAdnRmasHBOPVX=[('(통합) 찜 영상에 추가',UfzEeWiCgDtqMFlJcAdnRmasHBOPTY)]
   else:
    UfzEeWiCgDtqMFlJcAdnRmasHBOPVX=UfzEeWiCgDtqMFlJcAdnRmasHBOPrS
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.add_dir(UfzEeWiCgDtqMFlJcAdnRmasHBOPGx+UfzEeWiCgDtqMFlJcAdnRmasHBOPVh,sublabel=UfzEeWiCgDtqMFlJcAdnRmasHBOPrS,img=UfzEeWiCgDtqMFlJcAdnRmasHBOPTk,infoLabels=UfzEeWiCgDtqMFlJcAdnRmasHBOPVQ,isFolder=UfzEeWiCgDtqMFlJcAdnRmasHBOPrj,params=UfzEeWiCgDtqMFlJcAdnRmasHBOPVb,isLink=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw,ContextMenu=UfzEeWiCgDtqMFlJcAdnRmasHBOPVX)
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPoX:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVb={}
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVb['mode'] ='NF_SEARCH' 
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVb['page'] =UfzEeWiCgDtqMFlJcAdnRmasHBOPrx(UfzEeWiCgDtqMFlJcAdnRmasHBOPTu+1)
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVb['search_key']=UfzEeWiCgDtqMFlJcAdnRmasHBOPok
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVb['byReference']=UfzEeWiCgDtqMFlJcAdnRmasHBOPoQ
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGx='[B]%s >>[/B]'%'다음 페이지'
   UfzEeWiCgDtqMFlJcAdnRmasHBOPrG=UfzEeWiCgDtqMFlJcAdnRmasHBOPrx(UfzEeWiCgDtqMFlJcAdnRmasHBOPTu+1)
   UfzEeWiCgDtqMFlJcAdnRmasHBOPVx=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.add_dir(UfzEeWiCgDtqMFlJcAdnRmasHBOPGx,sublabel=UfzEeWiCgDtqMFlJcAdnRmasHBOPrG,img=UfzEeWiCgDtqMFlJcAdnRmasHBOPVx,infoLabels=UfzEeWiCgDtqMFlJcAdnRmasHBOPrS,isFolder=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw,params=UfzEeWiCgDtqMFlJcAdnRmasHBOPVb)
  xbmcplugin.setContent(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN._addon_handle,'movies')
  xbmcplugin.endOfDirectory(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN._addon_handle)
 def dp_Bookmark_Menu(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,args):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPTV='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(UfzEeWiCgDtqMFlJcAdnRmasHBOPTV)
 def dp_Set_Bookmark(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN,args):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPrV=urllib.parse.unquote(args.get('bm_param'))
  UfzEeWiCgDtqMFlJcAdnRmasHBOPrV=json.loads(UfzEeWiCgDtqMFlJcAdnRmasHBOPrV)
  UfzEeWiCgDtqMFlJcAdnRmasHBOPTp =UfzEeWiCgDtqMFlJcAdnRmasHBOPrV.get('videoid')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPTG =UfzEeWiCgDtqMFlJcAdnRmasHBOPrV.get('vidtype')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPro =UfzEeWiCgDtqMFlJcAdnRmasHBOPrV.get('vtitle')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPrT =UfzEeWiCgDtqMFlJcAdnRmasHBOPrV.get('vsubtitle')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPrp =UfzEeWiCgDtqMFlJcAdnRmasHBOPrV.get('vinfo')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPTk =UfzEeWiCgDtqMFlJcAdnRmasHBOPrV.get('thumbnail')
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGv=xbmcgui.Dialog()
  UfzEeWiCgDtqMFlJcAdnRmasHBOPVY=UfzEeWiCgDtqMFlJcAdnRmasHBOPGv.yesno(__language__(30917).encode('utf8'),UfzEeWiCgDtqMFlJcAdnRmasHBOPro+' \n\n'+__language__(30918))
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPVY==UfzEeWiCgDtqMFlJcAdnRmasHBOPrj:return
  UfzEeWiCgDtqMFlJcAdnRmasHBOPrN={'indexinfo':{'ott':'netflix','videoid':UfzEeWiCgDtqMFlJcAdnRmasHBOPTp,'vidtype':UfzEeWiCgDtqMFlJcAdnRmasHBOPTG,},'saveinfo':{'title':UfzEeWiCgDtqMFlJcAdnRmasHBOPro,'subtitle':UfzEeWiCgDtqMFlJcAdnRmasHBOPrT,'thumbnail':UfzEeWiCgDtqMFlJcAdnRmasHBOPTk,'infoLabels':UfzEeWiCgDtqMFlJcAdnRmasHBOPrp,},}
  UfzEeWiCgDtqMFlJcAdnRmasHBOPTI=json.dumps(UfzEeWiCgDtqMFlJcAdnRmasHBOPrN)
  UfzEeWiCgDtqMFlJcAdnRmasHBOPTI=urllib.parse.quote(UfzEeWiCgDtqMFlJcAdnRmasHBOPTI)
  UfzEeWiCgDtqMFlJcAdnRmasHBOPTY='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(UfzEeWiCgDtqMFlJcAdnRmasHBOPTI)
  xbmc.executebuiltin(UfzEeWiCgDtqMFlJcAdnRmasHBOPTY)
 def search_main(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN):
  UfzEeWiCgDtqMFlJcAdnRmasHBOPoI=UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.main_params.get('mode',UfzEeWiCgDtqMFlJcAdnRmasHBOPrS)
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPoI=='NFLOGOUT':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.NF_logout()
   return
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoI=='NFLOGIN':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.NF_login(showMessage=UfzEeWiCgDtqMFlJcAdnRmasHBOPrw)
   return
  UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.option_check()
  if UfzEeWiCgDtqMFlJcAdnRmasHBOPoI is UfzEeWiCgDtqMFlJcAdnRmasHBOPrS:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.dp_Main_List()
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoI=='TOTAL_SEARCH':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.dp_Search_Group(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.main_params)
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoI=='HYPER_LINK':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.dp_Hyper_Link(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.main_params)
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoI=='NF_SEARCH':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.dp_Nf_Search(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.main_params)
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoI=='TOTAL_HISTORY':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.dp_Search_History(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.main_params)
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoI=='HISTORY_REMOVE':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.dp_History_Delete(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.main_params)
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoI=='MENU_BOOKMARK':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.dp_Bookmark_Menu(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.main_params)
  elif UfzEeWiCgDtqMFlJcAdnRmasHBOPoI=='SET_BOOKMARK':
   UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.dp_Set_Bookmark(UfzEeWiCgDtqMFlJcAdnRmasHBOPGN.main_params)
  else:
   UfzEeWiCgDtqMFlJcAdnRmasHBOPrS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
