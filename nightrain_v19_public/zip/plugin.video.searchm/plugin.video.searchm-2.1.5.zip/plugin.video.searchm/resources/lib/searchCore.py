__author__="NightRain"
JnmpfLkuzHexYbolSdqOaTWswyEVgA=object
JnmpfLkuzHexYbolSdqOaTWswyEVgK=None
JnmpfLkuzHexYbolSdqOaTWswyEVgM=False
JnmpfLkuzHexYbolSdqOaTWswyEVgc=True
JnmpfLkuzHexYbolSdqOaTWswyEVgB=print
JnmpfLkuzHexYbolSdqOaTWswyEVgr=str
JnmpfLkuzHexYbolSdqOaTWswyEVgh=int
JnmpfLkuzHexYbolSdqOaTWswyEVgD=Exception
JnmpfLkuzHexYbolSdqOaTWswyEVNU=len
JnmpfLkuzHexYbolSdqOaTWswyEVNX=open
JnmpfLkuzHexYbolSdqOaTWswyEVNF=type
JnmpfLkuzHexYbolSdqOaTWswyEVNC=list
JnmpfLkuzHexYbolSdqOaTWswyEVNg=isinstance
JnmpfLkuzHexYbolSdqOaTWswyEVNR=dict
JnmpfLkuzHexYbolSdqOaTWswyEVNj=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
import http.cookiejar
class JnmpfLkuzHexYbolSdqOaTWswyEVUX(JnmpfLkuzHexYbolSdqOaTWswyEVgA):
 def __init__(JnmpfLkuzHexYbolSdqOaTWswyEVUF):
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.DEFAULT_HEADER ={'user-agent':JnmpfLkuzHexYbolSdqOaTWswyEVUF.USER_AGENT}
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_WAVVE ='https://apis.wavve.com'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_TVING_SEARCH='https://search.tving.com'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_TVING_IMG ='https://image.tving.com'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_WATCHA ='https://api-mars.watcha.com'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_NETFLIX ='https://www.netflix.com'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_COUPANG ='https://discover.coupangstreaming.com'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_PRIMEV ='https://www.primevideo.com'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.WAVVE_LIMIT =20 
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.TVING_LIMIT =30
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.WATCHA_LIMIT =30
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_LIMIT =20 
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.COUPANG_LIMIT =10 
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.DERECTOR_LIMIT =4
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.CAST_LIMIT =10
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.GENRE_LIMIT =4
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.TVING_MOVIE_LITE=['2610061','2610161','261062']
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_HEADER={'user-agent':JnmpfLkuzHexYbolSdqOaTWswyEVUF.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND1 ='_342x192'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND2 ='_665x375'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_PORT ='_342x684'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LOGO ='_550x124'
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF={}
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']={}
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']={}
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.HTTP_CLIENT=requests.Session()
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.CP_ORIGINAL_COOKIE =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.PV_ORIGINAL_COOKIE =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_ORIGINAL_COOKIE =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_SESSION_COOKIES1 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_SESSION_COOKIES2 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_SESSION_COOKIES3 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_SESSION_COOKIES4 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_SESSION_FULLTEXT1 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_SESSION_FULLTEXT2 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_SESSION_FULLTEXT3 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_SESSION_FULLTEXT4 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_CONTEXTJSON_FILE1 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_CONTEXTJSON_FILE2 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_CONTEXTJSON_FILE3 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_CONTEXTJSON_FILE4 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_FALCORJSON_FILE1 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_FALCORJSON_FILE2 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_FALCORJSON_FILE3 =''
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_FALCORJSON_FILE4 =''
 def callRequestCookies(JnmpfLkuzHexYbolSdqOaTWswyEVUF,jobtype,JnmpfLkuzHexYbolSdqOaTWswyEVUt,payload=JnmpfLkuzHexYbolSdqOaTWswyEVgK,params=JnmpfLkuzHexYbolSdqOaTWswyEVgK,headers=JnmpfLkuzHexYbolSdqOaTWswyEVgK,cookies=JnmpfLkuzHexYbolSdqOaTWswyEVgK,redirects=JnmpfLkuzHexYbolSdqOaTWswyEVgM):
  JnmpfLkuzHexYbolSdqOaTWswyEVUC=JnmpfLkuzHexYbolSdqOaTWswyEVUF.DEFAULT_HEADER
  if headers:JnmpfLkuzHexYbolSdqOaTWswyEVUC.update(headers)
  if jobtype=='Get':
   JnmpfLkuzHexYbolSdqOaTWswyEVUg=requests.get(JnmpfLkuzHexYbolSdqOaTWswyEVUt,params=params,headers=JnmpfLkuzHexYbolSdqOaTWswyEVUC,cookies=cookies,allow_redirects=redirects)
  else:
   JnmpfLkuzHexYbolSdqOaTWswyEVUg=requests.post(JnmpfLkuzHexYbolSdqOaTWswyEVUt,data=payload,params=params,headers=JnmpfLkuzHexYbolSdqOaTWswyEVUC,cookies=cookies,allow_redirects=redirects)
  return JnmpfLkuzHexYbolSdqOaTWswyEVUg
 def Call_Request(JnmpfLkuzHexYbolSdqOaTWswyEVUF,JnmpfLkuzHexYbolSdqOaTWswyEVUt,payload=JnmpfLkuzHexYbolSdqOaTWswyEVgK,params=JnmpfLkuzHexYbolSdqOaTWswyEVgK,headers=JnmpfLkuzHexYbolSdqOaTWswyEVgK,cookies=JnmpfLkuzHexYbolSdqOaTWswyEVgK,redirects=JnmpfLkuzHexYbolSdqOaTWswyEVgc,method='-'):
  JnmpfLkuzHexYbolSdqOaTWswyEVUN={'user-agent':JnmpfLkuzHexYbolSdqOaTWswyEVUF.USER_AGENT}
  if headers:JnmpfLkuzHexYbolSdqOaTWswyEVUN.update(headers)
  if payload!=JnmpfLkuzHexYbolSdqOaTWswyEVgK or method=='POST':
   JnmpfLkuzHexYbolSdqOaTWswyEVUR=JnmpfLkuzHexYbolSdqOaTWswyEVUF.HTTP_CLIENT.post(url=JnmpfLkuzHexYbolSdqOaTWswyEVUt,data=payload,params=params,headers=JnmpfLkuzHexYbolSdqOaTWswyEVUN,cookies=cookies,allow_redirects=redirects)
  else:
   JnmpfLkuzHexYbolSdqOaTWswyEVUR=JnmpfLkuzHexYbolSdqOaTWswyEVUF.HTTP_CLIENT.get(url=JnmpfLkuzHexYbolSdqOaTWswyEVUt,params=params,headers=JnmpfLkuzHexYbolSdqOaTWswyEVUN,cookies=cookies,allow_redirects=redirects)
  JnmpfLkuzHexYbolSdqOaTWswyEVgB(JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVUR.status_code)+' - '+JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVUR.url))
  return JnmpfLkuzHexYbolSdqOaTWswyEVUR
 def GetNoCache(JnmpfLkuzHexYbolSdqOaTWswyEVUF,timetype=1,minutes=0):
  if timetype==1:
   ts=JnmpfLkuzHexYbolSdqOaTWswyEVgh(time.time())
   mi=JnmpfLkuzHexYbolSdqOaTWswyEVgh(minutes*60)
  else:
   ts=JnmpfLkuzHexYbolSdqOaTWswyEVgh(time.time()*1000)
   mi=JnmpfLkuzHexYbolSdqOaTWswyEVgh(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(JnmpfLkuzHexYbolSdqOaTWswyEVUF):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(JnmpfLkuzHexYbolSdqOaTWswyEVUF,search_key,sType,page_int):
  JnmpfLkuzHexYbolSdqOaTWswyEVUG=[]
  JnmpfLkuzHexYbolSdqOaTWswyEVUi=JnmpfLkuzHexYbolSdqOaTWswyEVXU=1
  JnmpfLkuzHexYbolSdqOaTWswyEVUv=JnmpfLkuzHexYbolSdqOaTWswyEVgM
  try:
   JnmpfLkuzHexYbolSdqOaTWswyEVUt=JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_WAVVE+'/cf/search/list.js'
   JnmpfLkuzHexYbolSdqOaTWswyEVUQ={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':JnmpfLkuzHexYbolSdqOaTWswyEVgr((page_int-1)*JnmpfLkuzHexYbolSdqOaTWswyEVUF.WAVVE_LIMIT),'limit':JnmpfLkuzHexYbolSdqOaTWswyEVUF.WAVVE_LIMIT,'orderby':'score'}
   JnmpfLkuzHexYbolSdqOaTWswyEVUQ.update(JnmpfLkuzHexYbolSdqOaTWswyEVUF.WAVVE_PARAMS)
   JnmpfLkuzHexYbolSdqOaTWswyEVUR=JnmpfLkuzHexYbolSdqOaTWswyEVUF.callRequestCookies('Get',JnmpfLkuzHexYbolSdqOaTWswyEVUt,payload=JnmpfLkuzHexYbolSdqOaTWswyEVgK,params=JnmpfLkuzHexYbolSdqOaTWswyEVUQ,headers=JnmpfLkuzHexYbolSdqOaTWswyEVgK,cookies=JnmpfLkuzHexYbolSdqOaTWswyEVgK)
   JnmpfLkuzHexYbolSdqOaTWswyEVUI=json.loads(JnmpfLkuzHexYbolSdqOaTWswyEVUR.text)
   if not('celllist' in JnmpfLkuzHexYbolSdqOaTWswyEVUI['cell_toplist']):return JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv
   JnmpfLkuzHexYbolSdqOaTWswyEVUP=JnmpfLkuzHexYbolSdqOaTWswyEVUI['cell_toplist']['celllist']
   for JnmpfLkuzHexYbolSdqOaTWswyEVUA in JnmpfLkuzHexYbolSdqOaTWswyEVUP:
    JnmpfLkuzHexYbolSdqOaTWswyEVUK =JnmpfLkuzHexYbolSdqOaTWswyEVUA['event_list'][1]['url']
    JnmpfLkuzHexYbolSdqOaTWswyEVUM=urllib.parse.urlsplit(JnmpfLkuzHexYbolSdqOaTWswyEVUK).query
    JnmpfLkuzHexYbolSdqOaTWswyEVUc=JnmpfLkuzHexYbolSdqOaTWswyEVUM[0:JnmpfLkuzHexYbolSdqOaTWswyEVUM.find('=')]
    JnmpfLkuzHexYbolSdqOaTWswyEVUB=JnmpfLkuzHexYbolSdqOaTWswyEVUM[JnmpfLkuzHexYbolSdqOaTWswyEVUM.find('=')+1:]
    JnmpfLkuzHexYbolSdqOaTWswyEVUc='TVSHOW' if JnmpfLkuzHexYbolSdqOaTWswyEVUc=='programid' else 'MOVIE' 
    JnmpfLkuzHexYbolSdqOaTWswyEVUr=JnmpfLkuzHexYbolSdqOaTWswyEVUA['title_list'][0]['text']
    JnmpfLkuzHexYbolSdqOaTWswyEVUh =JnmpfLkuzHexYbolSdqOaTWswyEVUA['age']
    JnmpfLkuzHexYbolSdqOaTWswyEVUD={'title':JnmpfLkuzHexYbolSdqOaTWswyEVUr}
    if JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('age')!='21':
     JnmpfLkuzHexYbolSdqOaTWswyEVUG.append(JnmpfLkuzHexYbolSdqOaTWswyEVUD)
   JnmpfLkuzHexYbolSdqOaTWswyEVUi=JnmpfLkuzHexYbolSdqOaTWswyEVgh(JnmpfLkuzHexYbolSdqOaTWswyEVUI['cell_toplist']['pagecount'])
   if JnmpfLkuzHexYbolSdqOaTWswyEVUI['cell_toplist']['count']:JnmpfLkuzHexYbolSdqOaTWswyEVXU =JnmpfLkuzHexYbolSdqOaTWswyEVgh(JnmpfLkuzHexYbolSdqOaTWswyEVUI['cell_toplist']['count'])
   else:JnmpfLkuzHexYbolSdqOaTWswyEVXU=JnmpfLkuzHexYbolSdqOaTWswyEVUF.LIST_LIMIT
   JnmpfLkuzHexYbolSdqOaTWswyEVUv=JnmpfLkuzHexYbolSdqOaTWswyEVUi>JnmpfLkuzHexYbolSdqOaTWswyEVXU
  except JnmpfLkuzHexYbolSdqOaTWswyEVgD as exception:
   JnmpfLkuzHexYbolSdqOaTWswyEVgB(exception)
  return JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv 
 def Get_Search_Tving(JnmpfLkuzHexYbolSdqOaTWswyEVUF,search_key,sType,page_int):
  JnmpfLkuzHexYbolSdqOaTWswyEVUG=[]
  JnmpfLkuzHexYbolSdqOaTWswyEVUv=JnmpfLkuzHexYbolSdqOaTWswyEVgM
  try:
   JnmpfLkuzHexYbolSdqOaTWswyEVXF ='/search/getSearch.jsp'
   JnmpfLkuzHexYbolSdqOaTWswyEVXC={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':JnmpfLkuzHexYbolSdqOaTWswyEVgr(page_int),'pageSize':JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVUF.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':JnmpfLkuzHexYbolSdqOaTWswyEVUF.TVING_PARMAS.get('SCREENCODE'),'os':JnmpfLkuzHexYbolSdqOaTWswyEVUF.TVING_PARMAS.get('OSCODE'),'network':JnmpfLkuzHexYbolSdqOaTWswyEVUF.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVUF.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVUF.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVUF.GetNoCache(2))}
   JnmpfLkuzHexYbolSdqOaTWswyEVUt=JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_TVING_SEARCH+JnmpfLkuzHexYbolSdqOaTWswyEVXF
   JnmpfLkuzHexYbolSdqOaTWswyEVUR=JnmpfLkuzHexYbolSdqOaTWswyEVUF.callRequestCookies('Get',JnmpfLkuzHexYbolSdqOaTWswyEVUt,payload=JnmpfLkuzHexYbolSdqOaTWswyEVgK,params=JnmpfLkuzHexYbolSdqOaTWswyEVXC,headers=JnmpfLkuzHexYbolSdqOaTWswyEVgK,cookies=JnmpfLkuzHexYbolSdqOaTWswyEVgK)
   JnmpfLkuzHexYbolSdqOaTWswyEVXg=json.loads(JnmpfLkuzHexYbolSdqOaTWswyEVUR.text)
   if sType=='TVSHOW':
    if not('programRsb' in JnmpfLkuzHexYbolSdqOaTWswyEVXg):return JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv
    JnmpfLkuzHexYbolSdqOaTWswyEVXN=JnmpfLkuzHexYbolSdqOaTWswyEVXg['programRsb']['dataList']
    JnmpfLkuzHexYbolSdqOaTWswyEVXR =JnmpfLkuzHexYbolSdqOaTWswyEVgh(JnmpfLkuzHexYbolSdqOaTWswyEVXg['programRsb']['count'])
    for JnmpfLkuzHexYbolSdqOaTWswyEVUA in JnmpfLkuzHexYbolSdqOaTWswyEVXN:
     JnmpfLkuzHexYbolSdqOaTWswyEVXj=JnmpfLkuzHexYbolSdqOaTWswyEVUA['mast_cd']
     JnmpfLkuzHexYbolSdqOaTWswyEVUr =JnmpfLkuzHexYbolSdqOaTWswyEVUA['mast_nm']
     JnmpfLkuzHexYbolSdqOaTWswyEVXG=JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_TVING_IMG+JnmpfLkuzHexYbolSdqOaTWswyEVUA['web_url4']
     JnmpfLkuzHexYbolSdqOaTWswyEVXi =JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_TVING_IMG+JnmpfLkuzHexYbolSdqOaTWswyEVUA['web_url']
     try:
      JnmpfLkuzHexYbolSdqOaTWswyEVXv =[]
      JnmpfLkuzHexYbolSdqOaTWswyEVXt=[]
      JnmpfLkuzHexYbolSdqOaTWswyEVXQ =[]
      JnmpfLkuzHexYbolSdqOaTWswyEVXI =0
      JnmpfLkuzHexYbolSdqOaTWswyEVXP =''
      JnmpfLkuzHexYbolSdqOaTWswyEVXA =''
      JnmpfLkuzHexYbolSdqOaTWswyEVXK =''
      if JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('actor') !='' and JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('actor') !='-':JnmpfLkuzHexYbolSdqOaTWswyEVXv =JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('actor').split(',')
      if JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('director')!='' and JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('director')!='-':JnmpfLkuzHexYbolSdqOaTWswyEVXt=JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('director').split(',')
      if JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('cate_nm')!='' and JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('cate_nm')!='-':JnmpfLkuzHexYbolSdqOaTWswyEVXQ =JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('cate_nm').split('/')
      if 'targetage' in JnmpfLkuzHexYbolSdqOaTWswyEVUA:JnmpfLkuzHexYbolSdqOaTWswyEVXP=JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('targetage')
      if 'broad_dt' in JnmpfLkuzHexYbolSdqOaTWswyEVUA:
       JnmpfLkuzHexYbolSdqOaTWswyEVXM=JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('broad_dt')
       JnmpfLkuzHexYbolSdqOaTWswyEVXK='%s-%s-%s'%(JnmpfLkuzHexYbolSdqOaTWswyEVXM[:4],JnmpfLkuzHexYbolSdqOaTWswyEVXM[4:6],JnmpfLkuzHexYbolSdqOaTWswyEVXM[6:])
       JnmpfLkuzHexYbolSdqOaTWswyEVXA =JnmpfLkuzHexYbolSdqOaTWswyEVXM[:4]
     except:
      JnmpfLkuzHexYbolSdqOaTWswyEVgK
     JnmpfLkuzHexYbolSdqOaTWswyEVUD={'title':JnmpfLkuzHexYbolSdqOaTWswyEVUr,}
     JnmpfLkuzHexYbolSdqOaTWswyEVUG.append(JnmpfLkuzHexYbolSdqOaTWswyEVUD)
   else:
    if not('vodMVRsb' in JnmpfLkuzHexYbolSdqOaTWswyEVXg):return JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv
    JnmpfLkuzHexYbolSdqOaTWswyEVXc=JnmpfLkuzHexYbolSdqOaTWswyEVXg['vodMVRsb']['dataList']
    JnmpfLkuzHexYbolSdqOaTWswyEVXR =JnmpfLkuzHexYbolSdqOaTWswyEVgh(JnmpfLkuzHexYbolSdqOaTWswyEVXg['vodMVRsb']['count'])
    JnmpfLkuzHexYbolSdqOaTWswyEVgB(JnmpfLkuzHexYbolSdqOaTWswyEVXR)
    for JnmpfLkuzHexYbolSdqOaTWswyEVUA in JnmpfLkuzHexYbolSdqOaTWswyEVXc:
     JnmpfLkuzHexYbolSdqOaTWswyEVXj=JnmpfLkuzHexYbolSdqOaTWswyEVUA['mast_cd']
     JnmpfLkuzHexYbolSdqOaTWswyEVUr =JnmpfLkuzHexYbolSdqOaTWswyEVUA['mast_nm'].strip()
     JnmpfLkuzHexYbolSdqOaTWswyEVXG =JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_TVING_IMG+JnmpfLkuzHexYbolSdqOaTWswyEVUA['web_url']
     JnmpfLkuzHexYbolSdqOaTWswyEVXi =JnmpfLkuzHexYbolSdqOaTWswyEVXG
     JnmpfLkuzHexYbolSdqOaTWswyEVXB=''
     try:
      JnmpfLkuzHexYbolSdqOaTWswyEVXv =[]
      JnmpfLkuzHexYbolSdqOaTWswyEVXt=[]
      JnmpfLkuzHexYbolSdqOaTWswyEVXQ =[]
      JnmpfLkuzHexYbolSdqOaTWswyEVXI =0
      JnmpfLkuzHexYbolSdqOaTWswyEVXP =''
      JnmpfLkuzHexYbolSdqOaTWswyEVXA =''
      JnmpfLkuzHexYbolSdqOaTWswyEVXK =''
      if JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('actor') !='' and JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('actor') !='-':JnmpfLkuzHexYbolSdqOaTWswyEVXv =JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('actor').split(',')
      if JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('director')!='' and JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('director')!='-':JnmpfLkuzHexYbolSdqOaTWswyEVXt=JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('director').split(',')
      if JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('cate_nm')!='' and JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('cate_nm')!='-':JnmpfLkuzHexYbolSdqOaTWswyEVXQ =JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('cate_nm').split('/')
      if JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('runtime_sec')!='':JnmpfLkuzHexYbolSdqOaTWswyEVXI=JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('runtime_sec')
      if 'grade_nm' in JnmpfLkuzHexYbolSdqOaTWswyEVUA:JnmpfLkuzHexYbolSdqOaTWswyEVXP=JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('grade_nm')
      JnmpfLkuzHexYbolSdqOaTWswyEVXr=''
      JnmpfLkuzHexYbolSdqOaTWswyEVXM=JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('broad_dt')
      if JnmpfLkuzHexYbolSdqOaTWswyEVXr!='':
       JnmpfLkuzHexYbolSdqOaTWswyEVXK='%s-%s-%s'%(JnmpfLkuzHexYbolSdqOaTWswyEVXM[:4],JnmpfLkuzHexYbolSdqOaTWswyEVXM[4:6],JnmpfLkuzHexYbolSdqOaTWswyEVXM[6:])
       JnmpfLkuzHexYbolSdqOaTWswyEVXA =JnmpfLkuzHexYbolSdqOaTWswyEVXM[:4]
     except:
      JnmpfLkuzHexYbolSdqOaTWswyEVgK
     JnmpfLkuzHexYbolSdqOaTWswyEVUD={'title':JnmpfLkuzHexYbolSdqOaTWswyEVUr,}
     JnmpfLkuzHexYbolSdqOaTWswyEVXh=JnmpfLkuzHexYbolSdqOaTWswyEVgM
     for JnmpfLkuzHexYbolSdqOaTWswyEVXD in JnmpfLkuzHexYbolSdqOaTWswyEVUA['bill']:
      if JnmpfLkuzHexYbolSdqOaTWswyEVXD in JnmpfLkuzHexYbolSdqOaTWswyEVUF.TVING_MOVIE_LITE:
       JnmpfLkuzHexYbolSdqOaTWswyEVXh=JnmpfLkuzHexYbolSdqOaTWswyEVgc
       break
     if JnmpfLkuzHexYbolSdqOaTWswyEVXh==JnmpfLkuzHexYbolSdqOaTWswyEVgM: 
      JnmpfLkuzHexYbolSdqOaTWswyEVUD['title']=JnmpfLkuzHexYbolSdqOaTWswyEVUD['title']+' [개별구매]'
     JnmpfLkuzHexYbolSdqOaTWswyEVUG.append(JnmpfLkuzHexYbolSdqOaTWswyEVUD)
   if JnmpfLkuzHexYbolSdqOaTWswyEVXR>(page_int*JnmpfLkuzHexYbolSdqOaTWswyEVUF.TVING_LIMIT):JnmpfLkuzHexYbolSdqOaTWswyEVUv=JnmpfLkuzHexYbolSdqOaTWswyEVgc
  except JnmpfLkuzHexYbolSdqOaTWswyEVgD as exception:
   JnmpfLkuzHexYbolSdqOaTWswyEVgB(exception)
  return JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv
 def Get_Search_Watcha(JnmpfLkuzHexYbolSdqOaTWswyEVUF,search_key,page_int):
  JnmpfLkuzHexYbolSdqOaTWswyEVUG=[]
  JnmpfLkuzHexYbolSdqOaTWswyEVUv=JnmpfLkuzHexYbolSdqOaTWswyEVgM
  try:
   JnmpfLkuzHexYbolSdqOaTWswyEVUt=JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_WATCHA+'/api/search.json'
   JnmpfLkuzHexYbolSdqOaTWswyEVXC={'query':search_key,'page':JnmpfLkuzHexYbolSdqOaTWswyEVgr(page_int),'per':JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVUF.WATCHA_LIMIT),'exclude':'limited',}
   JnmpfLkuzHexYbolSdqOaTWswyEVUR=JnmpfLkuzHexYbolSdqOaTWswyEVUF.callRequestCookies('Get',JnmpfLkuzHexYbolSdqOaTWswyEVUt,payload=JnmpfLkuzHexYbolSdqOaTWswyEVgK,params=JnmpfLkuzHexYbolSdqOaTWswyEVXC,headers=JnmpfLkuzHexYbolSdqOaTWswyEVUF.WATCHA_HEADER,cookies=JnmpfLkuzHexYbolSdqOaTWswyEVgK)
   JnmpfLkuzHexYbolSdqOaTWswyEVXg=json.loads(JnmpfLkuzHexYbolSdqOaTWswyEVUR.text)
   if not('results' in JnmpfLkuzHexYbolSdqOaTWswyEVXg):return JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv
   JnmpfLkuzHexYbolSdqOaTWswyEVFU=JnmpfLkuzHexYbolSdqOaTWswyEVXg['results']
   JnmpfLkuzHexYbolSdqOaTWswyEVUv=JnmpfLkuzHexYbolSdqOaTWswyEVXg['meta']['has_next']
   for JnmpfLkuzHexYbolSdqOaTWswyEVUA in JnmpfLkuzHexYbolSdqOaTWswyEVFU:
    JnmpfLkuzHexYbolSdqOaTWswyEVFX =JnmpfLkuzHexYbolSdqOaTWswyEVUA['code']
    JnmpfLkuzHexYbolSdqOaTWswyEVFC=JnmpfLkuzHexYbolSdqOaTWswyEVUA['content_type']
    JnmpfLkuzHexYbolSdqOaTWswyEVFg =JnmpfLkuzHexYbolSdqOaTWswyEVUA['title']
    JnmpfLkuzHexYbolSdqOaTWswyEVFN =JnmpfLkuzHexYbolSdqOaTWswyEVUA['story']
    JnmpfLkuzHexYbolSdqOaTWswyEVXG=JnmpfLkuzHexYbolSdqOaTWswyEVXi=JnmpfLkuzHexYbolSdqOaTWswyEVgj=''
    if JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('poster') !=JnmpfLkuzHexYbolSdqOaTWswyEVgK:JnmpfLkuzHexYbolSdqOaTWswyEVXG=JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('poster').get('original')
    if JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('stillcut')!=JnmpfLkuzHexYbolSdqOaTWswyEVgK:JnmpfLkuzHexYbolSdqOaTWswyEVXi =JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('stillcut').get('large')
    if JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('thumbnail')!=JnmpfLkuzHexYbolSdqOaTWswyEVgK:JnmpfLkuzHexYbolSdqOaTWswyEVgj=JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('thumbnail').get('large')
    if JnmpfLkuzHexYbolSdqOaTWswyEVgj=='' :JnmpfLkuzHexYbolSdqOaTWswyEVgj=JnmpfLkuzHexYbolSdqOaTWswyEVXi
    JnmpfLkuzHexYbolSdqOaTWswyEVFR={'thumb':JnmpfLkuzHexYbolSdqOaTWswyEVXi,'poster':JnmpfLkuzHexYbolSdqOaTWswyEVXG,'fanart':JnmpfLkuzHexYbolSdqOaTWswyEVgj}
    JnmpfLkuzHexYbolSdqOaTWswyEVXA =JnmpfLkuzHexYbolSdqOaTWswyEVUA['year']
    JnmpfLkuzHexYbolSdqOaTWswyEVFj =JnmpfLkuzHexYbolSdqOaTWswyEVUA['film_rating_code']
    JnmpfLkuzHexYbolSdqOaTWswyEVFG=JnmpfLkuzHexYbolSdqOaTWswyEVUA['film_rating_short']
    JnmpfLkuzHexYbolSdqOaTWswyEVFi =JnmpfLkuzHexYbolSdqOaTWswyEVUA['film_rating_long']
    if JnmpfLkuzHexYbolSdqOaTWswyEVFC=='movies':
     JnmpfLkuzHexYbolSdqOaTWswyEVXI =JnmpfLkuzHexYbolSdqOaTWswyEVUA['duration']
    else:
     JnmpfLkuzHexYbolSdqOaTWswyEVXI ='0'
    JnmpfLkuzHexYbolSdqOaTWswyEVUD={'title':JnmpfLkuzHexYbolSdqOaTWswyEVFg,}
    JnmpfLkuzHexYbolSdqOaTWswyEVUG.append(JnmpfLkuzHexYbolSdqOaTWswyEVUD)
  except JnmpfLkuzHexYbolSdqOaTWswyEVgD as exception:
   JnmpfLkuzHexYbolSdqOaTWswyEVgB(exception)
  return JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv
 def Get_Search_Coupang(JnmpfLkuzHexYbolSdqOaTWswyEVUF,search_key,page_int):
  JnmpfLkuzHexYbolSdqOaTWswyEVUG=[]
  JnmpfLkuzHexYbolSdqOaTWswyEVUv=JnmpfLkuzHexYbolSdqOaTWswyEVgM
  try:
   CP=JnmpfLkuzHexYbolSdqOaTWswyEVUF.jsonfile_To_dic(JnmpfLkuzHexYbolSdqOaTWswyEVUF.CP_ORIGINAL_COOKIE)
   JnmpfLkuzHexYbolSdqOaTWswyEVUt=JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_COUPANG+'/v2/search' 
   JnmpfLkuzHexYbolSdqOaTWswyEVXC={'query':search_key,'platform':'WEBCLIENT','page':JnmpfLkuzHexYbolSdqOaTWswyEVgr(page_int),'perPage':JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVUF.COUPANG_LIMIT),}
   JnmpfLkuzHexYbolSdqOaTWswyEVFv={'x-membersrl':CP['SESSION']['member_srl'],'x-pcid':CP['SESSION']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   JnmpfLkuzHexYbolSdqOaTWswyEVUR=JnmpfLkuzHexYbolSdqOaTWswyEVUF.callRequestCookies('Get',JnmpfLkuzHexYbolSdqOaTWswyEVUt,payload=JnmpfLkuzHexYbolSdqOaTWswyEVgK,params=JnmpfLkuzHexYbolSdqOaTWswyEVXC,headers=JnmpfLkuzHexYbolSdqOaTWswyEVFv,cookies=JnmpfLkuzHexYbolSdqOaTWswyEVgK)
   JnmpfLkuzHexYbolSdqOaTWswyEVUI=json.loads(JnmpfLkuzHexYbolSdqOaTWswyEVUR.text)
   if JnmpfLkuzHexYbolSdqOaTWswyEVNU(JnmpfLkuzHexYbolSdqOaTWswyEVUI.get('data').get('data'))==0:return JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv
   for JnmpfLkuzHexYbolSdqOaTWswyEVUA in JnmpfLkuzHexYbolSdqOaTWswyEVUI.get('data').get('data'):
    JnmpfLkuzHexYbolSdqOaTWswyEVUA=JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('data')
    JnmpfLkuzHexYbolSdqOaTWswyEVUD={'title':JnmpfLkuzHexYbolSdqOaTWswyEVUA.get('title'),}
    JnmpfLkuzHexYbolSdqOaTWswyEVUG.append(JnmpfLkuzHexYbolSdqOaTWswyEVUD)
   if JnmpfLkuzHexYbolSdqOaTWswyEVUI.get('pagination').get('totalPages')>page_int:
    JnmpfLkuzHexYbolSdqOaTWswyEVUv=JnmpfLkuzHexYbolSdqOaTWswyEVgc
  except JnmpfLkuzHexYbolSdqOaTWswyEVgD as exception:
   JnmpfLkuzHexYbolSdqOaTWswyEVgB(exception)
  return JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv
 def Selenium_Cookies_Load(JnmpfLkuzHexYbolSdqOaTWswyEVUF,in_filename):
  fp=JnmpfLkuzHexYbolSdqOaTWswyEVNX(in_filename,'rb',-1)
  try:
   JnmpfLkuzHexYbolSdqOaTWswyEVFt=pickle.loads(fp.read())
   if JnmpfLkuzHexYbolSdqOaTWswyEVNF(JnmpfLkuzHexYbolSdqOaTWswyEVFt)==JnmpfLkuzHexYbolSdqOaTWswyEVNC:
    for JnmpfLkuzHexYbolSdqOaTWswyEVFQ in JnmpfLkuzHexYbolSdqOaTWswyEVFt:
     JnmpfLkuzHexYbolSdqOaTWswyEVUF.HTTP_CLIENT.cookies.set_cookie(JnmpfLkuzHexYbolSdqOaTWswyEVUF.To_Cookielib(JnmpfLkuzHexYbolSdqOaTWswyEVFQ)) 
   else:
    JnmpfLkuzHexYbolSdqOaTWswyEVUF.HTTP_CLIENT.cookies.update(JnmpfLkuzHexYbolSdqOaTWswyEVFt) 
  except JnmpfLkuzHexYbolSdqOaTWswyEVgD as exception:
   JnmpfLkuzHexYbolSdqOaTWswyEVgB(exception)
  finally:
   fp.close()
 def To_Cookielib(JnmpfLkuzHexYbolSdqOaTWswyEVUF,selenium_cookie):
  return http.cookiejar.Cookie(version=0,name=selenium_cookie['name'],value=selenium_cookie['value'],port=JnmpfLkuzHexYbolSdqOaTWswyEVgK,port_specified=JnmpfLkuzHexYbolSdqOaTWswyEVgM,domain=selenium_cookie['domain'],domain_specified=JnmpfLkuzHexYbolSdqOaTWswyEVgc,domain_initial_dot=JnmpfLkuzHexYbolSdqOaTWswyEVgM,path=selenium_cookie['path'],path_specified=JnmpfLkuzHexYbolSdqOaTWswyEVgc,secure=selenium_cookie['secure'],expires=selenium_cookie['expiry'],discard=JnmpfLkuzHexYbolSdqOaTWswyEVgM,comment=JnmpfLkuzHexYbolSdqOaTWswyEVgK,comment_url=JnmpfLkuzHexYbolSdqOaTWswyEVgK,rest={'HttpOnly':selenium_cookie['httpOnly']},rfc2109=JnmpfLkuzHexYbolSdqOaTWswyEVgM,)
 def Get_Search_Primev(JnmpfLkuzHexYbolSdqOaTWswyEVUF,search_key):
  JnmpfLkuzHexYbolSdqOaTWswyEVUG=[]
  try:
   JnmpfLkuzHexYbolSdqOaTWswyEVUF.Selenium_Cookies_Load(JnmpfLkuzHexYbolSdqOaTWswyEVUF.PV_ORIGINAL_COOKIE)
   JnmpfLkuzHexYbolSdqOaTWswyEVUt=JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_PRIMEV+'/search/ref=atv_nb_sr?phrase='+urllib.parse.quote_plus(search_key)+'&ie=UTF8'
   JnmpfLkuzHexYbolSdqOaTWswyEVUR=JnmpfLkuzHexYbolSdqOaTWswyEVUF.Call_Request(JnmpfLkuzHexYbolSdqOaTWswyEVUt,params=JnmpfLkuzHexYbolSdqOaTWswyEVgK,headers=JnmpfLkuzHexYbolSdqOaTWswyEVgK,method='GET')
   if JnmpfLkuzHexYbolSdqOaTWswyEVUR.status_code!=200:return[]
   JnmpfLkuzHexYbolSdqOaTWswyEVFP='{"props":{"results"'
   JnmpfLkuzHexYbolSdqOaTWswyEVFA=r'<script type="text/template">\s*(.*?)\s*</script>'
   JnmpfLkuzHexYbolSdqOaTWswyEVFK=re.compile(JnmpfLkuzHexYbolSdqOaTWswyEVFA,re.DOTALL).findall(JnmpfLkuzHexYbolSdqOaTWswyEVUR.text)
   JnmpfLkuzHexYbolSdqOaTWswyEVFM='{}'
   for JnmpfLkuzHexYbolSdqOaTWswyEVFc in JnmpfLkuzHexYbolSdqOaTWswyEVFK:
    if JnmpfLkuzHexYbolSdqOaTWswyEVFP in JnmpfLkuzHexYbolSdqOaTWswyEVFc:
     JnmpfLkuzHexYbolSdqOaTWswyEVFM=JnmpfLkuzHexYbolSdqOaTWswyEVFc
     break
   JnmpfLkuzHexYbolSdqOaTWswyEVUI=json.loads(JnmpfLkuzHexYbolSdqOaTWswyEVFM)
   JnmpfLkuzHexYbolSdqOaTWswyEVFB=JnmpfLkuzHexYbolSdqOaTWswyEVUI.get('props').get('results').get('items')
   for JnmpfLkuzHexYbolSdqOaTWswyEVFr in JnmpfLkuzHexYbolSdqOaTWswyEVFB:
    if 'titleID' not in JnmpfLkuzHexYbolSdqOaTWswyEVFr:return[]
    JnmpfLkuzHexYbolSdqOaTWswyEVUD={'title':JnmpfLkuzHexYbolSdqOaTWswyEVFr.get('title').get('text'),}
    JnmpfLkuzHexYbolSdqOaTWswyEVUG.append(JnmpfLkuzHexYbolSdqOaTWswyEVUD)
  except JnmpfLkuzHexYbolSdqOaTWswyEVgD as exception:
   JnmpfLkuzHexYbolSdqOaTWswyEVgB(exception)
  return JnmpfLkuzHexYbolSdqOaTWswyEVUG
 def dic_To_jsonfile(JnmpfLkuzHexYbolSdqOaTWswyEVUF,filename,JnmpfLkuzHexYbolSdqOaTWswyEVFh):
  if filename=='':return
  fp=JnmpfLkuzHexYbolSdqOaTWswyEVNX(filename,'w',-1,'utf-8')
  json.dump(JnmpfLkuzHexYbolSdqOaTWswyEVFh,fp,indent=4,ensure_ascii=JnmpfLkuzHexYbolSdqOaTWswyEVgM)
  fp.close()
 def jsonfile_To_dic(JnmpfLkuzHexYbolSdqOaTWswyEVUF,filename):
  if filename=='':return JnmpfLkuzHexYbolSdqOaTWswyEVgK
  try:
   fp=JnmpfLkuzHexYbolSdqOaTWswyEVNX(filename,'r',-1,'utf-8')
   JnmpfLkuzHexYbolSdqOaTWswyEVCU=json.load(fp)
   fp.close()
  except:
   JnmpfLkuzHexYbolSdqOaTWswyEVCU={}
  return JnmpfLkuzHexYbolSdqOaTWswyEVCU
 def tempFileSave(JnmpfLkuzHexYbolSdqOaTWswyEVUF,filename,resText):
  if filename=='':return
  fp=JnmpfLkuzHexYbolSdqOaTWswyEVNX(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(JnmpfLkuzHexYbolSdqOaTWswyEVUF,filename):
  if filename=='':return
  try:
   fp=JnmpfLkuzHexYbolSdqOaTWswyEVNX(filename,'r',-1,'utf-8')
   JnmpfLkuzHexYbolSdqOaTWswyEVCU=fp.read()
   fp.close()
  except:
   JnmpfLkuzHexYbolSdqOaTWswyEVCU=''
  return JnmpfLkuzHexYbolSdqOaTWswyEVCU
 def Init_NF_Total(JnmpfLkuzHexYbolSdqOaTWswyEVUF):
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF={}
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']={}
  JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']={}
 def make_NF_XnetflixHeaders(JnmpfLkuzHexYbolSdqOaTWswyEVUF):
  JnmpfLkuzHexYbolSdqOaTWswyEVFv={'x-netflix.browsername':JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['esnModel'],'x-netflix.esnprefix':JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['nowGuid'],'x-netflix.uiversion':JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return JnmpfLkuzHexYbolSdqOaTWswyEVFv
 def make_NF_ApiParams(JnmpfLkuzHexYbolSdqOaTWswyEVUF):
  JnmpfLkuzHexYbolSdqOaTWswyEVUQ={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['identifier']),}
  return JnmpfLkuzHexYbolSdqOaTWswyEVUQ
 def extract_json(JnmpfLkuzHexYbolSdqOaTWswyEVUF,content,name):
  JnmpfLkuzHexYbolSdqOaTWswyEVFA=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  JnmpfLkuzHexYbolSdqOaTWswyEVFM=JnmpfLkuzHexYbolSdqOaTWswyEVgK
  JnmpfLkuzHexYbolSdqOaTWswyEVCX=re.compile(JnmpfLkuzHexYbolSdqOaTWswyEVFA.format(name),re.DOTALL).findall(content)
  JnmpfLkuzHexYbolSdqOaTWswyEVFM=JnmpfLkuzHexYbolSdqOaTWswyEVCX[0]
  JnmpfLkuzHexYbolSdqOaTWswyEVCF=JnmpfLkuzHexYbolSdqOaTWswyEVFM.replace('\\"','\\\\"') 
  JnmpfLkuzHexYbolSdqOaTWswyEVCF=JnmpfLkuzHexYbolSdqOaTWswyEVCF.replace('\\s','\\\\s') 
  JnmpfLkuzHexYbolSdqOaTWswyEVCF=JnmpfLkuzHexYbolSdqOaTWswyEVCF.replace('\\n','\\\\n') 
  JnmpfLkuzHexYbolSdqOaTWswyEVCF=JnmpfLkuzHexYbolSdqOaTWswyEVCF.replace('\\t','\\\\t') 
  JnmpfLkuzHexYbolSdqOaTWswyEVCF=JnmpfLkuzHexYbolSdqOaTWswyEVCF.encode().decode('unicode_escape') 
  JnmpfLkuzHexYbolSdqOaTWswyEVCF=re.sub(r'\\(?!["])',r'\\\\',JnmpfLkuzHexYbolSdqOaTWswyEVCF) 
  return json.loads(JnmpfLkuzHexYbolSdqOaTWswyEVCF)
 def NF_makestr_paths(JnmpfLkuzHexYbolSdqOaTWswyEVUF,paths):
  JnmpfLkuzHexYbolSdqOaTWswyEVCU=[]
  if JnmpfLkuzHexYbolSdqOaTWswyEVNg(paths,JnmpfLkuzHexYbolSdqOaTWswyEVgh):
   return '%d'%(paths)
  elif JnmpfLkuzHexYbolSdqOaTWswyEVNg(paths,JnmpfLkuzHexYbolSdqOaTWswyEVgr):
   return '"%s"'%(paths)
  for JnmpfLkuzHexYbolSdqOaTWswyEVCg in paths:
   if JnmpfLkuzHexYbolSdqOaTWswyEVNg(JnmpfLkuzHexYbolSdqOaTWswyEVCg,JnmpfLkuzHexYbolSdqOaTWswyEVgh):
    JnmpfLkuzHexYbolSdqOaTWswyEVCU.append('%d'%(JnmpfLkuzHexYbolSdqOaTWswyEVCg))
   elif JnmpfLkuzHexYbolSdqOaTWswyEVNg(JnmpfLkuzHexYbolSdqOaTWswyEVCg,JnmpfLkuzHexYbolSdqOaTWswyEVgr):
    JnmpfLkuzHexYbolSdqOaTWswyEVCU.append('"%s"'%(JnmpfLkuzHexYbolSdqOaTWswyEVCg))
   elif JnmpfLkuzHexYbolSdqOaTWswyEVNg(JnmpfLkuzHexYbolSdqOaTWswyEVCg,JnmpfLkuzHexYbolSdqOaTWswyEVNC):
    JnmpfLkuzHexYbolSdqOaTWswyEVCU.append('[%s]'%(','.join(JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_makestr_paths(JnmpfLkuzHexYbolSdqOaTWswyEVCg))))
   elif JnmpfLkuzHexYbolSdqOaTWswyEVNg(JnmpfLkuzHexYbolSdqOaTWswyEVCg,JnmpfLkuzHexYbolSdqOaTWswyEVNR):
    JnmpfLkuzHexYbolSdqOaTWswyEVCN=''
    for JnmpfLkuzHexYbolSdqOaTWswyEVCR,JnmpfLkuzHexYbolSdqOaTWswyEVCj in JnmpfLkuzHexYbolSdqOaTWswyEVCg.items():
     JnmpfLkuzHexYbolSdqOaTWswyEVCN+='"%s":%s,'%(JnmpfLkuzHexYbolSdqOaTWswyEVCR,JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_makestr_paths(JnmpfLkuzHexYbolSdqOaTWswyEVCj))
    JnmpfLkuzHexYbolSdqOaTWswyEVCU.append('{%s}'%(JnmpfLkuzHexYbolSdqOaTWswyEVCN[:-1]))
  return JnmpfLkuzHexYbolSdqOaTWswyEVCU
 def NF_Call_pathapi(JnmpfLkuzHexYbolSdqOaTWswyEVUF,JnmpfLkuzHexYbolSdqOaTWswyEVCB,referer=''):
  JnmpfLkuzHexYbolSdqOaTWswyEVCG='%s/nq/website/memberapi/%s/pathEvaluator'%(JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_NETFLIX,JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['identifier'])
  JnmpfLkuzHexYbolSdqOaTWswyEVCi={'path':JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_makestr_paths(JnmpfLkuzHexYbolSdqOaTWswyEVCB),'authURL':JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']['authURL']}
  JnmpfLkuzHexYbolSdqOaTWswyEVUQ=JnmpfLkuzHexYbolSdqOaTWswyEVUF.make_NF_ApiParams()
  JnmpfLkuzHexYbolSdqOaTWswyEVFv={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':JnmpfLkuzHexYbolSdqOaTWswyEVFv['referer']=referer
  JnmpfLkuzHexYbolSdqOaTWswyEVCv=JnmpfLkuzHexYbolSdqOaTWswyEVUF.make_NF_XnetflixHeaders()
  JnmpfLkuzHexYbolSdqOaTWswyEVFv.update(JnmpfLkuzHexYbolSdqOaTWswyEVCv)
  JnmpfLkuzHexYbolSdqOaTWswyEVCt=JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_Get_DefaultCookies()
  JnmpfLkuzHexYbolSdqOaTWswyEVCt['profilesNewSession']='0'
  try:
   JnmpfLkuzHexYbolSdqOaTWswyEVUR=JnmpfLkuzHexYbolSdqOaTWswyEVUF.callRequestCookies('Post',JnmpfLkuzHexYbolSdqOaTWswyEVCG,payload=JnmpfLkuzHexYbolSdqOaTWswyEVCi,params=JnmpfLkuzHexYbolSdqOaTWswyEVUQ,headers=JnmpfLkuzHexYbolSdqOaTWswyEVFv,cookies=JnmpfLkuzHexYbolSdqOaTWswyEVCt)
   return JnmpfLkuzHexYbolSdqOaTWswyEVUR
  except JnmpfLkuzHexYbolSdqOaTWswyEVgD as exception:
   JnmpfLkuzHexYbolSdqOaTWswyEVgB(exception)
   return JnmpfLkuzHexYbolSdqOaTWswyEVgK
 def Get_Search_Netflix(JnmpfLkuzHexYbolSdqOaTWswyEVUF,search_key,page_int,byReference=''):
  JnmpfLkuzHexYbolSdqOaTWswyEVCQ=JnmpfLkuzHexYbolSdqOaTWswyEVUF.DERECTOR_LIMIT
  JnmpfLkuzHexYbolSdqOaTWswyEVCI =JnmpfLkuzHexYbolSdqOaTWswyEVUF.CAST_LIMIT
  JnmpfLkuzHexYbolSdqOaTWswyEVCP =JnmpfLkuzHexYbolSdqOaTWswyEVUF.GENRE_LIMIT
  JnmpfLkuzHexYbolSdqOaTWswyEVCA =JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_LIMIT*(page_int-1)
  JnmpfLkuzHexYbolSdqOaTWswyEVCK =JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_LIMIT*page_int 
  JnmpfLkuzHexYbolSdqOaTWswyEVCM="|%s"%(search_key)
  JnmpfLkuzHexYbolSdqOaTWswyEVCc ='%s/search?%s'%(JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   JnmpfLkuzHexYbolSdqOaTWswyEVCB=[["search","byTerm",JnmpfLkuzHexYbolSdqOaTWswyEVCM,"titles",JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_LIMIT,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"summary"],["search","byTerm",JnmpfLkuzHexYbolSdqOaTWswyEVCM,"titles",JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_LIMIT,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",JnmpfLkuzHexYbolSdqOaTWswyEVCM,"titles",JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_LIMIT,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference","boxarts",[JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND2,JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_PORT],"jpg"],["search","byTerm",JnmpfLkuzHexYbolSdqOaTWswyEVCM,"titles",JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_LIMIT,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference","interestingMoment",JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND1,"jpg"],["search","byTerm",JnmpfLkuzHexYbolSdqOaTWswyEVCM,"titles",JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_LIMIT,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference","storyArt",JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND2,"jpg"],["search","byTerm",JnmpfLkuzHexYbolSdqOaTWswyEVCM,"titles",JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_LIMIT,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference",["cast","creators","directors"],{"from":0,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCQ},["id","name"]],["search","byTerm",JnmpfLkuzHexYbolSdqOaTWswyEVCM,"titles",JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_LIMIT,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference","genres",{"from":0,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCP},["id","name"]],["search","byTerm",JnmpfLkuzHexYbolSdqOaTWswyEVCM,"titles",JnmpfLkuzHexYbolSdqOaTWswyEVUF.NETFLIX_LIMIT,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LOGO,"png"],]
  else:
   JnmpfLkuzHexYbolSdqOaTWswyEVCB=[["search","byReference",byReference,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"summary"],["search","byReference",byReference,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference","boxarts",[JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND2,JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference","interestingMoment",JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference","storyArt",JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference",["cast","creators","directors"],{"from":0,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCQ},["id","name"]],["search","byReference",byReference,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference","genres",{"from":0,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCP},["id","name"]],["search","byReference",byReference,{"from":JnmpfLkuzHexYbolSdqOaTWswyEVCA,"to":JnmpfLkuzHexYbolSdqOaTWswyEVCK},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LOGO,"png"],]
  try:
   JnmpfLkuzHexYbolSdqOaTWswyEVUR=JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_Call_pathapi(JnmpfLkuzHexYbolSdqOaTWswyEVCB,JnmpfLkuzHexYbolSdqOaTWswyEVCc)
   JnmpfLkuzHexYbolSdqOaTWswyEVUI=json.loads(JnmpfLkuzHexYbolSdqOaTWswyEVUR.text)
  except JnmpfLkuzHexYbolSdqOaTWswyEVgD as exception:
   JnmpfLkuzHexYbolSdqOaTWswyEVgB(exception)
  (JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv,byReference)=JnmpfLkuzHexYbolSdqOaTWswyEVUF.Search_Netflix_Make(JnmpfLkuzHexYbolSdqOaTWswyEVUI)
  return JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv,byReference
 def Search_Netflix_Make(JnmpfLkuzHexYbolSdqOaTWswyEVUF,jsonSource):
  JnmpfLkuzHexYbolSdqOaTWswyEVUG=[]
  JnmpfLkuzHexYbolSdqOaTWswyEVUv =JnmpfLkuzHexYbolSdqOaTWswyEVgM
  JnmpfLkuzHexYbolSdqOaTWswyEVCr=''
  JnmpfLkuzHexYbolSdqOaTWswyEVCh=jsonSource.get('paths')[0][1]
  if JnmpfLkuzHexYbolSdqOaTWswyEVCh=='byTerm':
   JnmpfLkuzHexYbolSdqOaTWswyEVCA =jsonSource['paths'][0][5]['from']
   JnmpfLkuzHexYbolSdqOaTWswyEVCK =jsonSource['paths'][0][5]['to']
  else:
   JnmpfLkuzHexYbolSdqOaTWswyEVCA =jsonSource['paths'][0][3]['from']
   JnmpfLkuzHexYbolSdqOaTWswyEVCK =jsonSource['paths'][0][3]['to']
  JnmpfLkuzHexYbolSdqOaTWswyEVCr=JnmpfLkuzHexYbolSdqOaTWswyEVNC(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  JnmpfLkuzHexYbolSdqOaTWswyEVCD=jsonSource.get('jsonGraph').get('search').get('byReference').get(JnmpfLkuzHexYbolSdqOaTWswyEVCr)
  JnmpfLkuzHexYbolSdqOaTWswyEVgU =jsonSource.get('jsonGraph').get('videos')
  JnmpfLkuzHexYbolSdqOaTWswyEVgX=jsonSource.get('jsonGraph').get('person')
  JnmpfLkuzHexYbolSdqOaTWswyEVgF=jsonSource.get('jsonGraph').get('genres')
  JnmpfLkuzHexYbolSdqOaTWswyEVUv=JnmpfLkuzHexYbolSdqOaTWswyEVgc if JnmpfLkuzHexYbolSdqOaTWswyEVCD[JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVCK)]['reference']['$type']=='ref' else JnmpfLkuzHexYbolSdqOaTWswyEVgM
  for JnmpfLkuzHexYbolSdqOaTWswyEVgC in JnmpfLkuzHexYbolSdqOaTWswyEVNj(JnmpfLkuzHexYbolSdqOaTWswyEVCA,JnmpfLkuzHexYbolSdqOaTWswyEVCK):
   if JnmpfLkuzHexYbolSdqOaTWswyEVCD[JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVgC)]['reference']['$type']=='ref':
    JnmpfLkuzHexYbolSdqOaTWswyEVUB =JnmpfLkuzHexYbolSdqOaTWswyEVCD[JnmpfLkuzHexYbolSdqOaTWswyEVgr(JnmpfLkuzHexYbolSdqOaTWswyEVgC)]['reference']['value'][1]
    JnmpfLkuzHexYbolSdqOaTWswyEVgN=JnmpfLkuzHexYbolSdqOaTWswyEVgU[JnmpfLkuzHexYbolSdqOaTWswyEVUB]
    JnmpfLkuzHexYbolSdqOaTWswyEVFg =JnmpfLkuzHexYbolSdqOaTWswyEVgN['title']['value']
    if JnmpfLkuzHexYbolSdqOaTWswyEVgN['availability']['value']['isPlayable']==JnmpfLkuzHexYbolSdqOaTWswyEVgM:
     continue
    JnmpfLkuzHexYbolSdqOaTWswyEVUc =JnmpfLkuzHexYbolSdqOaTWswyEVgN['summary']['value']['type']
    JnmpfLkuzHexYbolSdqOaTWswyEVXI =0 if JnmpfLkuzHexYbolSdqOaTWswyEVUc!='movie' else JnmpfLkuzHexYbolSdqOaTWswyEVgN['runtime']['value']
    if JnmpfLkuzHexYbolSdqOaTWswyEVgN['sequiturEvidence']['value']['value']:
     JnmpfLkuzHexYbolSdqOaTWswyEVgR=JnmpfLkuzHexYbolSdqOaTWswyEVgN['sequiturEvidence']['value']['value']['text']
    else:
     JnmpfLkuzHexYbolSdqOaTWswyEVgR=''
    JnmpfLkuzHexYbolSdqOaTWswyEVXG =JnmpfLkuzHexYbolSdqOaTWswyEVgN['boxarts'][JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_PORT]['jpg']['value']['url']
    JnmpfLkuzHexYbolSdqOaTWswyEVgj =JnmpfLkuzHexYbolSdqOaTWswyEVgN['boxarts'][JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND2]['jpg']['value']['url']
    JnmpfLkuzHexYbolSdqOaTWswyEVXi=''
    if 'value' in JnmpfLkuzHexYbolSdqOaTWswyEVgN['storyArt'][JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND2]['jpg']:
     JnmpfLkuzHexYbolSdqOaTWswyEVXi =JnmpfLkuzHexYbolSdqOaTWswyEVgN['storyArt'][JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND2]['jpg']['value']['url']
    if JnmpfLkuzHexYbolSdqOaTWswyEVXi=='' and 'value' in JnmpfLkuzHexYbolSdqOaTWswyEVgN['interestingMoment'][JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND1]['jpg']:
     JnmpfLkuzHexYbolSdqOaTWswyEVXi =JnmpfLkuzHexYbolSdqOaTWswyEVgN['interestingMoment'][JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LAND1]['jpg']['value']['url']
    JnmpfLkuzHexYbolSdqOaTWswyEVXB=''
    if 'value' in JnmpfLkuzHexYbolSdqOaTWswyEVgN['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LOGO]['png']:
     JnmpfLkuzHexYbolSdqOaTWswyEVXB=JnmpfLkuzHexYbolSdqOaTWswyEVgN['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][JnmpfLkuzHexYbolSdqOaTWswyEVUF.ART_SIZE_LOGO]['png']['value']['url']
    JnmpfLkuzHexYbolSdqOaTWswyEVXQ =JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_Subid_List(JnmpfLkuzHexYbolSdqOaTWswyEVgN['genres'])
    for i in JnmpfLkuzHexYbolSdqOaTWswyEVNj(JnmpfLkuzHexYbolSdqOaTWswyEVNU(JnmpfLkuzHexYbolSdqOaTWswyEVXQ)):
     JnmpfLkuzHexYbolSdqOaTWswyEVXQ[i]=JnmpfLkuzHexYbolSdqOaTWswyEVgF[JnmpfLkuzHexYbolSdqOaTWswyEVXQ[i]]['name']['value']
    JnmpfLkuzHexYbolSdqOaTWswyEVXt=JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_Subid_List(JnmpfLkuzHexYbolSdqOaTWswyEVgN['directors'])
    JnmpfLkuzHexYbolSdqOaTWswyEVgG =JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_Subid_List(JnmpfLkuzHexYbolSdqOaTWswyEVgN['creators'])
    JnmpfLkuzHexYbolSdqOaTWswyEVXt.extend(JnmpfLkuzHexYbolSdqOaTWswyEVgG)
    for i in JnmpfLkuzHexYbolSdqOaTWswyEVNj(JnmpfLkuzHexYbolSdqOaTWswyEVNU(JnmpfLkuzHexYbolSdqOaTWswyEVXt)):
     JnmpfLkuzHexYbolSdqOaTWswyEVXt[i]=JnmpfLkuzHexYbolSdqOaTWswyEVgX[JnmpfLkuzHexYbolSdqOaTWswyEVXt[i]]['name']['value']
    JnmpfLkuzHexYbolSdqOaTWswyEVXv=JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_Subid_List(JnmpfLkuzHexYbolSdqOaTWswyEVgN['cast'])
    for i in JnmpfLkuzHexYbolSdqOaTWswyEVNj(JnmpfLkuzHexYbolSdqOaTWswyEVNU(JnmpfLkuzHexYbolSdqOaTWswyEVXv)):
     JnmpfLkuzHexYbolSdqOaTWswyEVXv[i]=JnmpfLkuzHexYbolSdqOaTWswyEVgX[JnmpfLkuzHexYbolSdqOaTWswyEVXv[i]]['name']['value']
    if 'maturityDescription' in JnmpfLkuzHexYbolSdqOaTWswyEVgN['maturity']['value']['rating']:
     JnmpfLkuzHexYbolSdqOaTWswyEVXP=JnmpfLkuzHexYbolSdqOaTWswyEVgN['maturity']['value']['rating']['maturityDescription']
    JnmpfLkuzHexYbolSdqOaTWswyEVUD={'videoid':JnmpfLkuzHexYbolSdqOaTWswyEVUB,'vidtype':JnmpfLkuzHexYbolSdqOaTWswyEVUc,'title':JnmpfLkuzHexYbolSdqOaTWswyEVFg,'mpaa':JnmpfLkuzHexYbolSdqOaTWswyEVXP,'regularSynopsis':JnmpfLkuzHexYbolSdqOaTWswyEVgN['regularSynopsis']['value'],'dpSupplemental':JnmpfLkuzHexYbolSdqOaTWswyEVgN['dpSupplementalMessage']['value'],'sequiturEvidence':JnmpfLkuzHexYbolSdqOaTWswyEVgR,'thumbnail':{'poster':JnmpfLkuzHexYbolSdqOaTWswyEVXG,'thumb':JnmpfLkuzHexYbolSdqOaTWswyEVXi,'fanart':JnmpfLkuzHexYbolSdqOaTWswyEVgj,'clearlogo':JnmpfLkuzHexYbolSdqOaTWswyEVXB},'year':JnmpfLkuzHexYbolSdqOaTWswyEVgN['releaseYear']['value'],'duration':JnmpfLkuzHexYbolSdqOaTWswyEVXI,'info_genre':JnmpfLkuzHexYbolSdqOaTWswyEVXQ,'director':JnmpfLkuzHexYbolSdqOaTWswyEVXt,'cast':JnmpfLkuzHexYbolSdqOaTWswyEVXv,}
    JnmpfLkuzHexYbolSdqOaTWswyEVUG.append(JnmpfLkuzHexYbolSdqOaTWswyEVUD)
  return JnmpfLkuzHexYbolSdqOaTWswyEVUG,JnmpfLkuzHexYbolSdqOaTWswyEVUv,JnmpfLkuzHexYbolSdqOaTWswyEVCr
 def NF_Subid_List(JnmpfLkuzHexYbolSdqOaTWswyEVUF,subJson):
  JnmpfLkuzHexYbolSdqOaTWswyEVgi=[]
  try:
   for i in JnmpfLkuzHexYbolSdqOaTWswyEVNj(JnmpfLkuzHexYbolSdqOaTWswyEVNU(subJson)):
    if subJson.get(JnmpfLkuzHexYbolSdqOaTWswyEVgr(i)).get('$type')!='ref':break
    JnmpfLkuzHexYbolSdqOaTWswyEVgv=subJson.get(JnmpfLkuzHexYbolSdqOaTWswyEVgr(i)).get('value')[1]
    JnmpfLkuzHexYbolSdqOaTWswyEVgi.append(JnmpfLkuzHexYbolSdqOaTWswyEVgv)
  except JnmpfLkuzHexYbolSdqOaTWswyEVgD as exception:
   JnmpfLkuzHexYbolSdqOaTWswyEVgB(exception)
  return JnmpfLkuzHexYbolSdqOaTWswyEVgi
 def NF_CookieFile_Load(JnmpfLkuzHexYbolSdqOaTWswyEVUF,cookie_filename):
  JnmpfLkuzHexYbolSdqOaTWswyEVCt={}
  try:
   if os.path.isfile(cookie_filename)==JnmpfLkuzHexYbolSdqOaTWswyEVgM:return{}
   JnmpfLkuzHexYbolSdqOaTWswyEVgt=JnmpfLkuzHexYbolSdqOaTWswyEVNX(cookie_filename,'rb',-1)
   JnmpfLkuzHexYbolSdqOaTWswyEVgQ =pickle.loads(JnmpfLkuzHexYbolSdqOaTWswyEVgt.read())
   JnmpfLkuzHexYbolSdqOaTWswyEVgt.close()
   for JnmpfLkuzHexYbolSdqOaTWswyEVFQ in JnmpfLkuzHexYbolSdqOaTWswyEVgQ:
    JnmpfLkuzHexYbolSdqOaTWswyEVCt[JnmpfLkuzHexYbolSdqOaTWswyEVFQ.name]=JnmpfLkuzHexYbolSdqOaTWswyEVFQ.value
  except:
   JnmpfLkuzHexYbolSdqOaTWswyEVgB(exception) 
  return JnmpfLkuzHexYbolSdqOaTWswyEVCt
 def NF_Get_DefaultCookies(JnmpfLkuzHexYbolSdqOaTWswyEVUF):
  JnmpfLkuzHexYbolSdqOaTWswyEVCt={}
  if JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['flwssn'] :JnmpfLkuzHexYbolSdqOaTWswyEVCt['flwssn'] =JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['flwssn']
  if JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['nfvdid'] :JnmpfLkuzHexYbolSdqOaTWswyEVCt['nfvdid'] =JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['nfvdid']
  if JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['SecureNetflixId']:JnmpfLkuzHexYbolSdqOaTWswyEVCt['SecureNetflixId']=JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['SecureNetflixId']
  if JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['NetflixId'] :JnmpfLkuzHexYbolSdqOaTWswyEVCt['NetflixId'] =JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['NetflixId']
  if JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['memclid'] :JnmpfLkuzHexYbolSdqOaTWswyEVCt['memclid'] =JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['memclid']
  if JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['clSharedContext']:JnmpfLkuzHexYbolSdqOaTWswyEVCt['clSharedContext']=JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['COOKIES']['clSharedContext']
  return JnmpfLkuzHexYbolSdqOaTWswyEVCt
 def NF_Get_BaseSession(JnmpfLkuzHexYbolSdqOaTWswyEVUF):
  try:
   JnmpfLkuzHexYbolSdqOaTWswyEVUt=JnmpfLkuzHexYbolSdqOaTWswyEVUF.API_NETFLIX+'/browse' 
   JnmpfLkuzHexYbolSdqOaTWswyEVCt=JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_Get_DefaultCookies()
   JnmpfLkuzHexYbolSdqOaTWswyEVUR=JnmpfLkuzHexYbolSdqOaTWswyEVUF.callRequestCookies('Get',JnmpfLkuzHexYbolSdqOaTWswyEVUt,payload=JnmpfLkuzHexYbolSdqOaTWswyEVgK,params=JnmpfLkuzHexYbolSdqOaTWswyEVgK,headers=JnmpfLkuzHexYbolSdqOaTWswyEVgK,cookies=JnmpfLkuzHexYbolSdqOaTWswyEVCt)
   if JnmpfLkuzHexYbolSdqOaTWswyEVUR.status_code!=200:
    JnmpfLkuzHexYbolSdqOaTWswyEVgB('pass 1 status_code error')
    return JnmpfLkuzHexYbolSdqOaTWswyEVgM
   JnmpfLkuzHexYbolSdqOaTWswyEVgI =JnmpfLkuzHexYbolSdqOaTWswyEVUF.extract_json(JnmpfLkuzHexYbolSdqOaTWswyEVUR.text,'reactContext')
   JnmpfLkuzHexYbolSdqOaTWswyEVgP=JnmpfLkuzHexYbolSdqOaTWswyEVUF.extract_json(JnmpfLkuzHexYbolSdqOaTWswyEVUR.text,'falcorCache')
   JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF['SESSION']={'mainGuid':JnmpfLkuzHexYbolSdqOaTWswyEVgI['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':JnmpfLkuzHexYbolSdqOaTWswyEVgI['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':JnmpfLkuzHexYbolSdqOaTWswyEVgI['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':JnmpfLkuzHexYbolSdqOaTWswyEVgI['models']['memberContext']['data']['userInfo']['esn'],'identifier':JnmpfLkuzHexYbolSdqOaTWswyEVgI['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':JnmpfLkuzHexYbolSdqOaTWswyEVgI['models']['abContext']['data']['headers'],}
   JnmpfLkuzHexYbolSdqOaTWswyEVUF.dic_To_jsonfile(JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF_SESSION_COOKIES1,JnmpfLkuzHexYbolSdqOaTWswyEVUF.NF)
  except JnmpfLkuzHexYbolSdqOaTWswyEVgD as exception:
   JnmpfLkuzHexYbolSdqOaTWswyEVgB('pass 1 error')
   JnmpfLkuzHexYbolSdqOaTWswyEVgB(exception)
   return JnmpfLkuzHexYbolSdqOaTWswyEVgM
  return JnmpfLkuzHexYbolSdqOaTWswyEVgc
# Created by pyminifier (https://github.com/liftoff/pyminifier)
