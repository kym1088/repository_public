__author__="NightRain"
kQxfLsMiWEUPdwaGHoeDJNRFCrbKYu=object
kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq=None
kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB=True
kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA=False
kQxfLsMiWEUPdwaGHoeDJNRFCrbKYn=type
kQxfLsMiWEUPdwaGHoeDJNRFCrbKYc=dict
kQxfLsMiWEUPdwaGHoeDJNRFCrbKYz=open
kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj=len
kQxfLsMiWEUPdwaGHoeDJNRFCrbKYt=Exception
kQxfLsMiWEUPdwaGHoeDJNRFCrbKIO=int
kQxfLsMiWEUPdwaGHoeDJNRFCrbKIX=range
kQxfLsMiWEUPdwaGHoeDJNRFCrbKIh=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
kQxfLsMiWEUPdwaGHoeDJNRFCrbKOh=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
kQxfLsMiWEUPdwaGHoeDJNRFCrbKOS={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
kQxfLsMiWEUPdwaGHoeDJNRFCrbKOY=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
kQxfLsMiWEUPdwaGHoeDJNRFCrbKOI =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class kQxfLsMiWEUPdwaGHoeDJNRFCrbKOX(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYu):
 def __init__(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,kQxfLsMiWEUPdwaGHoeDJNRFCrbKOv,kQxfLsMiWEUPdwaGHoeDJNRFCrbKOT,kQxfLsMiWEUPdwaGHoeDJNRFCrbKOy):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp._addon_url =kQxfLsMiWEUPdwaGHoeDJNRFCrbKOv
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp._addon_handle=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOT
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.main_params =kQxfLsMiWEUPdwaGHoeDJNRFCrbKOy
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj =eCkMbofJaxLYTvRtgHhOpuBEWKnXPs() 
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_cookies.pk'))
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,sting):
  try:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm=xbmcgui.Dialog()
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm.notification(__addonname__,sting)
  except:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq
 def addon_log(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,string):
  try:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOl=string.encode('utf-8','ignore')
  except:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOl='addonException: addon_log'
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOg=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,kQxfLsMiWEUPdwaGHoeDJNRFCrbKOl),level=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOg)
 def get_keyboard_input(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOu=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq
  kb=xbmc.Keyboard()
  kb.setHeading(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOu=kb.getText()
  return kQxfLsMiWEUPdwaGHoeDJNRFCrbKOu
 def get_settings_menubookmark(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOq=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB if __addon__.getSetting('menu_bookmark')=='true' else kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
  return(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOq)
 def get_settings_makebookmark(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp):
  return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB if __addon__.getSetting('make_bookmark')=='true' else kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
 def get_settings_select_info(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB=[]
  if __addon__.getSetting('netflixyn')=='true':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB.append('tving')
  if __addon__.getSetting('watchayn')=='true':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB.append('coupang')
  if __addon__.getSetting('primevyn')=='true':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB.append('disney')
  return kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB
 def add_dir(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,label,sublabel='',img='',infoLabels=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq,isFolder=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB,params='',isLink=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA,ContextMenu=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq,direct_url=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq):
  if direct_url:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOA=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc=json.dumps(params,separators=(',',':'))
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc=base64.standard_b64encode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc.encode()).decode('utf-8')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc.replace('+','%2B')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOA='%s?params=%s'%(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp._addon_url,kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc)
  if sublabel and sublabel!='-':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz='%s < %s >'%(label,sublabel)
  else: kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz=label
  if not img:img='DefaultFolder.png'
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOj=xbmcgui.ListItem(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz)
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYn(img)==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYc:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOj.setArt(img)
  else:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOj.setArt({'thumb':img,'poster':img})
  if infoLabels:kQxfLsMiWEUPdwaGHoeDJNRFCrbKOj.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOj.setProperty('IsPlayable','true')
  if ContextMenu:kQxfLsMiWEUPdwaGHoeDJNRFCrbKOj.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp._addon_handle,kQxfLsMiWEUPdwaGHoeDJNRFCrbKOA,kQxfLsMiWEUPdwaGHoeDJNRFCrbKOj,isFolder)
 def Load_Searched_List(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp):
  try:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOt=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOI
   fp=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYz(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOt,'r',-1,'utf-8')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXO=fp.readlines()
   fp.close()
  except:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXO=[]
  return kQxfLsMiWEUPdwaGHoeDJNRFCrbKXO
 def Save_Searched_List(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA):
  try:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOt=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOI
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXh=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.Load_Searched_List() 
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXS={'skey':kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA.strip()}
   fp=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYz(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOt,'w',-1,'utf-8')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXY=urllib.parse.urlencode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXS)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXY=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXY+'\n'
   fp.write(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXY)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXI=0
   for kQxfLsMiWEUPdwaGHoeDJNRFCrbKXp in kQxfLsMiWEUPdwaGHoeDJNRFCrbKXh:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKXv=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYc(urllib.parse.parse_qsl(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXp))
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKXT=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXS.get('skey').strip()
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKXy=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXv.get('skey').strip()
    if kQxfLsMiWEUPdwaGHoeDJNRFCrbKXT!=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXy:
     fp.write(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXp)
     kQxfLsMiWEUPdwaGHoeDJNRFCrbKXI+=1
     if kQxfLsMiWEUPdwaGHoeDJNRFCrbKXI>=50:break
   fp.close()
  except:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq
 def dp_Search_History(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,args):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKXV=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.Load_Searched_List()
  for kQxfLsMiWEUPdwaGHoeDJNRFCrbKXm in kQxfLsMiWEUPdwaGHoeDJNRFCrbKXV:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXl=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYc(urllib.parse.parse_qsl(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXm))
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXg=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXl.get('skey').strip()
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn={'mode':'TOTAL_SEARCH','search_key':kQxfLsMiWEUPdwaGHoeDJNRFCrbKXg,}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXu={'mode':'HISTORY_REMOVE','skey':kQxfLsMiWEUPdwaGHoeDJNRFCrbKXg,'delmode':'ONE',}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXq=urllib.parse.urlencode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXu)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXB=[('선택된 검색어 ( %s ) 삭제'%(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXg),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXq))]
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.add_dir(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXg,sublabel='',img=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq,infoLabels=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq,isFolder=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB,params=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn,ContextMenu=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXB)
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKXn={'plot':'검색목록 전체를 삭제합니다.'}
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKXc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.add_dir(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz,sublabel='',img=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXc,infoLabels=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXn,isFolder=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA,params=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn,isLink=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB)
  xbmcplugin.endOfDirectory(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp._addon_handle,cacheToDisc=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA)
 def Delete_History_List(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,kQxfLsMiWEUPdwaGHoeDJNRFCrbKXg,kQxfLsMiWEUPdwaGHoeDJNRFCrbKXt):
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKXt=='ALL':
   try:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKOt=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOI
    fp=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYz(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOt,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq
  else:
   try:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKOt=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOI
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKXh=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.Load_Searched_List() 
    fp=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYz(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOt,'w',-1,'utf-8')
    for kQxfLsMiWEUPdwaGHoeDJNRFCrbKXp in kQxfLsMiWEUPdwaGHoeDJNRFCrbKXh:
     kQxfLsMiWEUPdwaGHoeDJNRFCrbKXv=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYc(urllib.parse.parse_qsl(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXp))
     kQxfLsMiWEUPdwaGHoeDJNRFCrbKXj=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXv.get('skey').strip()
     if kQxfLsMiWEUPdwaGHoeDJNRFCrbKXg!=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXj:
      fp.write(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXp)
    fp.close()
   except:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq
 def dp_History_Delete(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,args):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKXg =args.get('skey') 
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKXt=args.get('delmode')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm=xbmcgui.Dialog()
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKXt=='ALL':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKhO=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKhO=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKhO==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA:sys.exit()
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.Delete_History_List(kQxfLsMiWEUPdwaGHoeDJNRFCrbKXg,kQxfLsMiWEUPdwaGHoeDJNRFCrbKXt)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOq=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.get_settings_menubookmark()
  for kQxfLsMiWEUPdwaGHoeDJNRFCrbKhX in kQxfLsMiWEUPdwaGHoeDJNRFCrbKOh:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhX.get('title')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXc=''
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKhX.get('mode')=='MENU_BOOKMARK' and kQxfLsMiWEUPdwaGHoeDJNRFCrbKOq==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA:continue
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn={'mode':kQxfLsMiWEUPdwaGHoeDJNRFCrbKhX.get('mode')}
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKhX.get('mode')in['XXX','MENU_BOOKMARK']:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhS=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhY =kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB
   else:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhS=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhY =kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
   if 'icon' in kQxfLsMiWEUPdwaGHoeDJNRFCrbKhX:kQxfLsMiWEUPdwaGHoeDJNRFCrbKXc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',kQxfLsMiWEUPdwaGHoeDJNRFCrbKhX.get('icon')) 
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.add_dir(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz,sublabel='',img=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXc,infoLabels=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq,isFolder=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhS,params=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn,isLink=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhY)
  xbmcplugin.endOfDirectory(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp._addon_handle,cacheToDisc=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA)
 def option_check(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.get_settings_select_info()
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB)==0:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm=xbmcgui.Dialog()
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKhO=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKhO==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB:
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.NF_cookiefile_check()==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.NF_login(showMessage=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB)
  if 'disney' in kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB:
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.DZ_cookiefile_check()==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.DZ={}
 def DZ_cookiefile_check(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhp={}
  try: 
   fp=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYz(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKhp= json.load(fp)
   fp.close()
  except kQxfLsMiWEUPdwaGHoeDJNRFCrbKYt as exception:
   return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.DZ=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhp
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKIO(time.time())>kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.DZ['account']['token_limit']:
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.DZ_ReToken()==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_noti(__language__(30920).encode('utf-8'))
    return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
   try: 
    fp=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYz(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.DZ,fp,indent=4,ensure_ascii=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA)
    fp.close()
   except kQxfLsMiWEUPdwaGHoeDJNRFCrbKYt as exception:
    return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
  return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB
 def NF_cookiefile_check(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhp={}
  try: 
   fp=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYz(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOY,'r',-1,'utf-8')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKhp= json.load(fp)
   fp.close()
  except kQxfLsMiWEUPdwaGHoeDJNRFCrbKYt as exception:
   return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhp
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhT =kQxfLsMiWEUPdwaGHoeDJNRFCrbKIO(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhy=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF['SESSION']['limitdate']
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhV =kQxfLsMiWEUPdwaGHoeDJNRFCrbKIO(re.sub('-','',kQxfLsMiWEUPdwaGHoeDJNRFCrbKhy))
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKhV<kQxfLsMiWEUPdwaGHoeDJNRFCrbKhT:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Init_NF_Total()
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.NF_login(showMessage=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA)==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA:
    return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhm=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF_CookieFile_Load(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF_ORIGINAL_COOKIE)
  if(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhm['NetflixId']!=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF['COOKIES']['NetflixId']or kQxfLsMiWEUPdwaGHoeDJNRFCrbKhm['SecureNetflixId']!=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF['COOKIES']['SecureNetflixId']or kQxfLsMiWEUPdwaGHoeDJNRFCrbKhm['flwssn']!=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF['COOKIES']['flwssn']or kQxfLsMiWEUPdwaGHoeDJNRFCrbKhm['memclid']!=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF['COOKIES']['memclid']or kQxfLsMiWEUPdwaGHoeDJNRFCrbKhm['nfvdid']!=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF['COOKIES']['nfvdid']):
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Init_NF_Total()
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.NF_login(showMessage=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA)==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA:
    return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
  return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB
 def NF_login(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,showMessage=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB):
  if showMessage:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm=xbmcgui.Dialog()
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKhO=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKhO==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA:
    return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA 
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF['COOKIES']=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF_CookieFile_Load(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF_ORIGINAL_COOKIE)
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhl=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA if kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF['COOKIES']=={}else kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKhl:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_log('pass1 ok!')
  else:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_log('pass1 error!')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_noti(__language__(30905).encode('utf-8'))
   return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA 
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhl=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF_Get_BaseSession()
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKhl:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_log('pass2 ok!')
  else:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_log('pass2 error!')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_noti(__language__(30905).encode('utf-8'))
   return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA 
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhg =kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Now_Datetime()
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF['SESSION']['limitdate']=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhg.strftime('%Y-%m-%d')
  try: 
   fp=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYz(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOY,'w',-1,'utf-8')
   json.dump(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF,fp,indent=4,ensure_ascii=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA)
   fp.close()
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_log('pass3 save ok!')
  except kQxfLsMiWEUPdwaGHoeDJNRFCrbKYt as exception:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_log('pass3 save error!')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_noti(__language__(30905).encode('utf-8'))
   return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
  if showMessage:kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_noti(__language__(30904).encode('utf-8'))
  return kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB
 def NF_logout(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm=xbmcgui.Dialog()
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhO=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKhO==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA:return 
  if os.path.isfile(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOY):os.remove(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOY)
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhu=''
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhq=7
  try:
   for i in kQxfLsMiWEUPdwaGHoeDJNRFCrbKIX(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)):
    if i>=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhq:
     kQxfLsMiWEUPdwaGHoeDJNRFCrbKhu=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhu+'...'
     break
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhu=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhu+kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn[i]['title']+'\n'
  except:
   return ''
  return kQxfLsMiWEUPdwaGHoeDJNRFCrbKhu
 def dp_Search_Group(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,args):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB =kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.get_settings_select_info()
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhB=[]
  if 'search_key' in args:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA=args.get('search_key')
  else:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA:
    return
  if 'wavve' in kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB:
   (kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhc)=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Search_Wavve(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,'TVSHOW',1)
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)>0:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz={'sType':'wavve_tvshow','sList':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.MakeText_FreeList(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn),}
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhB.append(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz)
   (kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhc)=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Search_Wavve(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,'MOVIE',1)
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)>0:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz={'sType':'wavve_movie','sList':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.MakeText_FreeList(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn),}
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhB.append(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz)
  if 'tving' in kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB:
   (kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhc)=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Search_Tving(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,'TVSHOW',1)
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)>0:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz={'sType':'tving_tvshow','sList':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.MakeText_FreeList(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn),}
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhB.append(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz)
   (kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhc)=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Search_Tving(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,'MOVIE',1)
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)>0:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz={'sType':'tving_movie','sList':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.MakeText_FreeList(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn),}
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhB.append(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz)
  if 'watcha' in kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB:
   (kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhc)=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Search_Watcha(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,1)
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)>0:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz={'sType':'watcha_list','sList':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.MakeText_FreeList(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn),}
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhB.append(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz)
  if 'coupang' in kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB:
   (kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhc)=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Search_Coupang(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,1)
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)>0:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz={'sType':'coupang_list','sList':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.MakeText_FreeList(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn),}
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhB.append(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz)
  if 'netflix' in kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB:
   try:
    (kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhc,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhj)=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Search_Netflix(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,1)
   except:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn=[]
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_noti(__language__(30919).encode('utf8'))
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)>0:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz={'sType':'netflix_list','sList':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.MakeText_FreeList(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn),}
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhB.append(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz)
  if 'amazon' in kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB:
   (kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Search_Primev(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA)
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)>0:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz={'sType':'primev_list','sList':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.MakeText_FreeList(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn),}
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhB.append(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz)
  if 'disney' in kQxfLsMiWEUPdwaGHoeDJNRFCrbKOB:
   try:
    (kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Search_Disney(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA)
   except:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn=[]
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.addon_noti(__language__(30921).encode('utf8'))
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYj(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn)>0:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz={'sType':'disney_list','sList':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.MakeText_FreeList(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn),}
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKhB.append(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhz)
  for kQxfLsMiWEUPdwaGHoeDJNRFCrbKht in kQxfLsMiWEUPdwaGHoeDJNRFCrbKhB:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSO=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOS[kQxfLsMiWEUPdwaGHoeDJNRFCrbKht.get('sType')]
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSX={'plot':'검색어 : '+kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA+'\n\n'+kQxfLsMiWEUPdwaGHoeDJNRFCrbKht.get('sList')}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSO.get('title')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn={'mode':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSO.get('mode'),'ott':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSO.get('ott'),'vidtype':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSO.get('vidtype'),'search_key':kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA}
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSO.get('ott')=='netflix':
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh=''
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn['page'] ='1'
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn['byReference']='-'
   else:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.make_Hyper_Link(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',kQxfLsMiWEUPdwaGHoeDJNRFCrbKSO.get('icon'))
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.add_dir(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz,sublabel='',img=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXc,infoLabels=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSX,isFolder=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB,params=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn,isLink=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA,direct_url=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh)
  xbmcplugin.endOfDirectory(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp._addon_handle)
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.Save_Searched_List(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA)
 def make_Hyper_Link(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,args):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKSY =args.get('ott')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI =args.get('vidtype')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA=args.get('search_key')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh='-'
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSY=='wavve':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp={'mode':'LOCAL_SEARCH','sType':'movie' if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI=='MOVIE' else 'vod','search_key':kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,'page':'1',}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv=urllib.parse.urlencode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh='plugin://plugin.video.wavvem/?'
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh+=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKSY=='tving':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp={'mode':'LOCAL_SEARCH','stype':'movie' if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI=='MOVIE' else 'vod','search_key':kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,'page':'1',}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv=urllib.parse.urlencode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh='plugin://plugin.video.tvingm/?'
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh+=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKSY=='watcha':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp={'mode':'LOCAL_SEARCH','search_key':kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,'page':'1',}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv=urllib.parse.urlencode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh='plugin://plugin.video.watcham/?'
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh+=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKSY=='coupang':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp={'mode':'LOCAL_SEARCH','search_key':kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,'page':'1',}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv=urllib.parse.urlencode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh='plugin://plugin.video.coupangm/?'
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh+=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKSY=='netflix':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKST=args.get('videoid')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSy=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.NF['SESSION']['nowGuid']
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI=='TVSHOW':
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh='plugin://plugin.video.netflix/directory/show/%s/'%(kQxfLsMiWEUPdwaGHoeDJNRFCrbKST)
   else:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(kQxfLsMiWEUPdwaGHoeDJNRFCrbKST,kQxfLsMiWEUPdwaGHoeDJNRFCrbKSy)
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKSY=='amazon':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,}}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv=json.dumps(kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp,separators=(',',':'))
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv=base64.standard_b64encode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv.encode()).decode('utf-8')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv.replace('+','%2B')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh='plugin://plugin.video.primevm/?params='
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh+=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKSY=='disney':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,}}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv=json.dumps(kQxfLsMiWEUPdwaGHoeDJNRFCrbKSp,separators=(',',':'))
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv=base64.standard_b64encode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv.encode()).decode('utf-8')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv.replace('+','%2B')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh='plugin://plugin.video.disneym/?params='
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh+=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSv
  return kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh
 def dp_Nf_Search(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,args):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKSV =kQxfLsMiWEUPdwaGHoeDJNRFCrbKIO(args.get('page'))
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA =args.get('search_key')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhj=args.get('byReference')
  (kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhc,kQxfLsMiWEUPdwaGHoeDJNRFCrbKhj)=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.SearchObj.Get_Search_Netflix(kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA,kQxfLsMiWEUPdwaGHoeDJNRFCrbKSV,byReference=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhj)
  for kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm in kQxfLsMiWEUPdwaGHoeDJNRFCrbKhn:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKST =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('videoid')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('vidtype')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('title')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSl =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('mpaa')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSg =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('regularSynopsis')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSu =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('dpSupplemental')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSq=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('sequiturEvidence')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSB =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('thumbnail')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSA =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('year')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSn =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('duration')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSc =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('info_genre')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSz =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('director')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSj =kQxfLsMiWEUPdwaGHoeDJNRFCrbKSm.get('cast')
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI=='movie':
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKXA=' (%s)'%(kQxfLsMiWEUPdwaGHoeDJNRFCrbKIh(kQxfLsMiWEUPdwaGHoeDJNRFCrbKSA))
   else:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKXA=''
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSt=''
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSg:kQxfLsMiWEUPdwaGHoeDJNRFCrbKSt=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSt+'\n\n'+kQxfLsMiWEUPdwaGHoeDJNRFCrbKSg
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSu :kQxfLsMiWEUPdwaGHoeDJNRFCrbKSt=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSt+'\n\n'+kQxfLsMiWEUPdwaGHoeDJNRFCrbKSu
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSq:kQxfLsMiWEUPdwaGHoeDJNRFCrbKSt=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSt+'\n\n'+kQxfLsMiWEUPdwaGHoeDJNRFCrbKSq
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSt=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSt.strip()
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXn={'mediatype':'tvshow' if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI=='show' else 'movie','title':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz,'mpaa':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSl,'plot':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSt,'duration':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSn,'genre':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSc,'director':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSz,'cast':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSj,'year':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSA,}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn={'ott':'netflix','vidtype':'TVSHOW' if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI=='show' else 'MOVIE','videoid':kQxfLsMiWEUPdwaGHoeDJNRFCrbKST,}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.make_Hyper_Link(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKhS=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI=='show' else kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA
   if kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.get_settings_makebookmark():
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKYO={'mode':'SET_BOOKMARK','values':{'videoid':kQxfLsMiWEUPdwaGHoeDJNRFCrbKST,'vidtype':'tvshow' if kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI=='show' else 'movie','vtitle':kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz+kQxfLsMiWEUPdwaGHoeDJNRFCrbKXA,'vsubtitle':'','vinfo':kQxfLsMiWEUPdwaGHoeDJNRFCrbKXn,'thumbnail':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSB,}}
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKYX=json.dumps(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYO,separators=(',',':'))
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKYX=base64.standard_b64encode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYX.encode()).decode('utf-8')
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKYX=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYX.replace('+','%2B')
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKYh='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYX)
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKXB=[('(통합) 찜 영상에 추가',kQxfLsMiWEUPdwaGHoeDJNRFCrbKYh)]
   else:
    kQxfLsMiWEUPdwaGHoeDJNRFCrbKXB=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.add_dir(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz+kQxfLsMiWEUPdwaGHoeDJNRFCrbKXA,sublabel=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq,img=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSB,infoLabels=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXn,isFolder=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhS,params=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn,isLink=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA,ContextMenu=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXB,direct_url=kQxfLsMiWEUPdwaGHoeDJNRFCrbKSh)
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKhc:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn={}
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn['mode'] ='NF_SEARCH' 
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn['page'] =kQxfLsMiWEUPdwaGHoeDJNRFCrbKIh(kQxfLsMiWEUPdwaGHoeDJNRFCrbKSV+1)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn['search_key']=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhA
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn['byReference']=kQxfLsMiWEUPdwaGHoeDJNRFCrbKhj
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz='[B]%s >>[/B]'%'다음 페이지'
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKYS=kQxfLsMiWEUPdwaGHoeDJNRFCrbKIh(kQxfLsMiWEUPdwaGHoeDJNRFCrbKSV+1)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKXc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.add_dir(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOz,sublabel=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYS,img=kQxfLsMiWEUPdwaGHoeDJNRFCrbKXc,infoLabels=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq,isFolder=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB,params=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn)
  xbmcplugin.setContent(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp._addon_handle,'movies')
  xbmcplugin.endOfDirectory(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp._addon_handle)
 def dp_Bookmark_Menu(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,args):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKYI='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYI)
 def dp_Set_Bookmark(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp,args):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKST =args.get('videoid')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI =args.get('vidtype')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKYp =args.get('vtitle')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKYv =args.get('vsubtitle')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKYT =args.get('vinfo')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKSB =args.get('thumbnail')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm=xbmcgui.Dialog()
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKhO=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOm.yesno(__language__(30917).encode('utf8'),kQxfLsMiWEUPdwaGHoeDJNRFCrbKYp+' \n\n'+__language__(30918))
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKhO==kQxfLsMiWEUPdwaGHoeDJNRFCrbKYA:return
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKYy={'indexinfo':{'ott':'netflix','videoid':kQxfLsMiWEUPdwaGHoeDJNRFCrbKST,'vidtype':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSI,},'saveinfo':{'title':kQxfLsMiWEUPdwaGHoeDJNRFCrbKYp,'subtitle':kQxfLsMiWEUPdwaGHoeDJNRFCrbKYv,'thumbnail':kQxfLsMiWEUPdwaGHoeDJNRFCrbKSB,'infoLabels':kQxfLsMiWEUPdwaGHoeDJNRFCrbKYT,},}
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':kQxfLsMiWEUPdwaGHoeDJNRFCrbKYy,}}
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc=json.dumps(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOn,separators=(',',':'))
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc=base64.standard_b64encode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc.encode()).decode('utf-8')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc.replace('+','%2B')
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKYh='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOc)
  xbmc.executebuiltin(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYh)
 def search_main(kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp):
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKYV=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.main_params.get('params')
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYV:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKYm =base64.standard_b64decode(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYV).decode('utf-8')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKYm =json.loads(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYm)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKYl =kQxfLsMiWEUPdwaGHoeDJNRFCrbKYm.get('mode')
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKYg =kQxfLsMiWEUPdwaGHoeDJNRFCrbKYm.get('values')
  else:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKYl=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.main_params.get('mode',kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq)
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKYg=kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.main_params
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYl=='NFLOGOUT':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.NF_logout()
   return
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKYl=='NFLOGIN':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.NF_login(showMessage=kQxfLsMiWEUPdwaGHoeDJNRFCrbKYB)
   return
  kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.option_check()
  if kQxfLsMiWEUPdwaGHoeDJNRFCrbKYl is kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.dp_Main_List()
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKYl=='TOTAL_SEARCH':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.dp_Search_Group(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYg)
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKYl=='NF_SEARCH':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.dp_Nf_Search(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYg)
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKYl=='TOTAL_HISTORY':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.dp_Search_History(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYg)
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKYl=='HISTORY_REMOVE':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.dp_History_Delete(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYg)
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKYl=='MENU_BOOKMARK':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.dp_Bookmark_Menu(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYg)
  elif kQxfLsMiWEUPdwaGHoeDJNRFCrbKYl=='SET_BOOKMARK':
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKOp.dp_Set_Bookmark(kQxfLsMiWEUPdwaGHoeDJNRFCrbKYg)
  else:
   kQxfLsMiWEUPdwaGHoeDJNRFCrbKYq
# Created by pyminifier (https://github.com/liftoff/pyminifier)
