__author__="NightRain"
eCkMbofJaxLYTvRtgHhOpuBEWKnXzl=object
eCkMbofJaxLYTvRtgHhOpuBEWKnXzS=None
eCkMbofJaxLYTvRtgHhOpuBEWKnXzc=True
eCkMbofJaxLYTvRtgHhOpuBEWKnXzI=print
eCkMbofJaxLYTvRtgHhOpuBEWKnXzr=str
eCkMbofJaxLYTvRtgHhOpuBEWKnXzV=int
eCkMbofJaxLYTvRtgHhOpuBEWKnXzD=False
eCkMbofJaxLYTvRtgHhOpuBEWKnXNP=Exception
eCkMbofJaxLYTvRtgHhOpuBEWKnXNs=len
eCkMbofJaxLYTvRtgHhOpuBEWKnXNQ=open
eCkMbofJaxLYTvRtgHhOpuBEWKnXNU=type
eCkMbofJaxLYTvRtgHhOpuBEWKnXNz=list
eCkMbofJaxLYTvRtgHhOpuBEWKnXNy=isinstance
eCkMbofJaxLYTvRtgHhOpuBEWKnXNm=dict
eCkMbofJaxLYTvRtgHhOpuBEWKnXNi=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
import http.cookiejar
class eCkMbofJaxLYTvRtgHhOpuBEWKnXPs(eCkMbofJaxLYTvRtgHhOpuBEWKnXzl):
 def __init__(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_WAVVE ='https://apis.wavve.com'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_TVING_SEARCH='https://search.tving.com'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_TVING_IMG ='https://image.tving.com'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_WATCHA ='https://api-mars.watcha.com'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_NETFLIX ='https://www.netflix.com'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_COUPANG ='https://discover.coupangstreaming.com'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_PRIMEV ='https://www.primevideo.com'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.WAVVE_LIMIT =20 
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.TVING_LIMIT =30
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.WATCHA_LIMIT =30
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_LIMIT =20 
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.COUPANG_LIMIT =10 
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DISNEY_LIMIT =10 
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DERECTOR_LIMIT =4
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.CAST_LIMIT =10
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.GENRE_LIMIT =4
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.TVING_MOVIE_LITE=['2610061','2610161','261062']
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_HEADER={'user-agent':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND1 ='_342x192'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND2 ='_665x375'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_PORT ='_342x684'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LOGO ='_550x124'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF={}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']={}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']={}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ={}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.HTTP_CLIENT=requests.Session()
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.CP_ORIGINAL_COOKIE =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.PV_ORIGINAL_COOKIE =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ_ORIGINAL_COOKIE =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_ORIGINAL_COOKIE =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_SESSION_COOKIES1 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_SESSION_COOKIES2 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_SESSION_COOKIES3 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_SESSION_COOKIES4 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_SESSION_FULLTEXT1 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_SESSION_FULLTEXT2 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_SESSION_FULLTEXT3 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_SESSION_FULLTEXT4 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_CONTEXTJSON_FILE1 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_CONTEXTJSON_FILE2 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_CONTEXTJSON_FILE3 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_CONTEXTJSON_FILE4 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_FALCORJSON_FILE1 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_FALCORJSON_FILE2 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_FALCORJSON_FILE3 =''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_FALCORJSON_FILE4 =''
 '''
 def callRequestCookies(self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):
  #setHeader = {'user-agent' : self.USER_AGENT }
  setHeader = self.DEFAULT_HEADER
  if headers: setHeader.update(headers )
  if jobtype == 'Get': # Get/Post
   res = requests.get(url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  else:
   res = requests.post(url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  return res
 ''' 
 def Call_Request(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,eCkMbofJaxLYTvRtgHhOpuBEWKnXPw,payload=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,json=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,params=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,cookies=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,redirects=eCkMbofJaxLYTvRtgHhOpuBEWKnXzc,method='-'):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPU={'user-agent':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.USER_AGENT}
  if headers:eCkMbofJaxLYTvRtgHhOpuBEWKnXPU.update(headers)
  if payload!=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS or method=='POST':
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.HTTP_CLIENT.post(url=eCkMbofJaxLYTvRtgHhOpuBEWKnXPw,data=payload,json=json,params=params,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXPU,cookies=cookies,allow_redirects=redirects)
  else:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.HTTP_CLIENT.get(url=eCkMbofJaxLYTvRtgHhOpuBEWKnXPw,params=params,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXPU,cookies=cookies,allow_redirects=redirects)
  eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.status_code)+' - '+eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.url))
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXPz
 def GetNoCache(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,timetype=1,minutes=0):
  if timetype==1:
   ts=eCkMbofJaxLYTvRtgHhOpuBEWKnXzV(time.time())
   mi=eCkMbofJaxLYTvRtgHhOpuBEWKnXzV(minutes*60)
  else:
   ts=eCkMbofJaxLYTvRtgHhOpuBEWKnXzV(time.time()*1000)
   mi=eCkMbofJaxLYTvRtgHhOpuBEWKnXzV(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,search_key,sType,page_int):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPy=[]
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPm=eCkMbofJaxLYTvRtgHhOpuBEWKnXsP=1
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPi=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
  try:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPw=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_WAVVE+'/fz/search/band.js'
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPA={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr((page_int-1)*eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.WAVVE_LIMIT),'limit':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.WAVVE_LIMIT,'orderby':'score','mtype':'svod',}
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPA.update(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.WAVVE_PARAMS)
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.Call_Request(eCkMbofJaxLYTvRtgHhOpuBEWKnXPw,payload=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,params=eCkMbofJaxLYTvRtgHhOpuBEWKnXPA,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,cookies=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,method='GET')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPG=json.loads(eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.text)
   if not('celllist' in eCkMbofJaxLYTvRtgHhOpuBEWKnXPG['band']):return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPF=eCkMbofJaxLYTvRtgHhOpuBEWKnXPG['band']['celllist']
   for eCkMbofJaxLYTvRtgHhOpuBEWKnXPj in eCkMbofJaxLYTvRtgHhOpuBEWKnXPF:
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPd =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['event_list'][1]['url']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPq=urllib.parse.urlsplit(eCkMbofJaxLYTvRtgHhOpuBEWKnXPd).query
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPl=eCkMbofJaxLYTvRtgHhOpuBEWKnXPq[0:eCkMbofJaxLYTvRtgHhOpuBEWKnXPq.find('=')]
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPS=eCkMbofJaxLYTvRtgHhOpuBEWKnXPq[eCkMbofJaxLYTvRtgHhOpuBEWKnXPq.find('=')+1:]
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPl='TVSHOW' if eCkMbofJaxLYTvRtgHhOpuBEWKnXPl=='programid' else 'MOVIE' 
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPc=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['title_list'][0]['text']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPI =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['age']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPr={'title':eCkMbofJaxLYTvRtgHhOpuBEWKnXPc}
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPV=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
    for eCkMbofJaxLYTvRtgHhOpuBEWKnXPD in eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['bottom_taglist']:
     if eCkMbofJaxLYTvRtgHhOpuBEWKnXPD=='won':
      eCkMbofJaxLYTvRtgHhOpuBEWKnXPV=eCkMbofJaxLYTvRtgHhOpuBEWKnXzc
      break
    if eCkMbofJaxLYTvRtgHhOpuBEWKnXPV==eCkMbofJaxLYTvRtgHhOpuBEWKnXzc: 
     eCkMbofJaxLYTvRtgHhOpuBEWKnXPr['title']=eCkMbofJaxLYTvRtgHhOpuBEWKnXPr['title']+' [개별구매]'
    if eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('age')!='21':
     eCkMbofJaxLYTvRtgHhOpuBEWKnXPy.append(eCkMbofJaxLYTvRtgHhOpuBEWKnXPr)
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPm=eCkMbofJaxLYTvRtgHhOpuBEWKnXzV(eCkMbofJaxLYTvRtgHhOpuBEWKnXPG['band']['pagecount'])
   if eCkMbofJaxLYTvRtgHhOpuBEWKnXPG['band']['count']:eCkMbofJaxLYTvRtgHhOpuBEWKnXsP =eCkMbofJaxLYTvRtgHhOpuBEWKnXzV(eCkMbofJaxLYTvRtgHhOpuBEWKnXPG['band']['count'])
   else:eCkMbofJaxLYTvRtgHhOpuBEWKnXsP=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.LIST_LIMIT
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPi=eCkMbofJaxLYTvRtgHhOpuBEWKnXPm>eCkMbofJaxLYTvRtgHhOpuBEWKnXsP
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception)
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi 
 def Get_Search_Tving(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,search_key,sType,page_int):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPy=[]
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPi=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
  try:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXsQ ='/search/getSearch.jsp'
   eCkMbofJaxLYTvRtgHhOpuBEWKnXsU={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(page_int),'pageSize':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.TVING_PARMAS.get('SCREENCODE'),'os':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.TVING_PARMAS.get('OSCODE'),'network':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.GetNoCache(2))}
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPw=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_TVING_SEARCH+eCkMbofJaxLYTvRtgHhOpuBEWKnXsQ
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.Call_Request(eCkMbofJaxLYTvRtgHhOpuBEWKnXPw,payload=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,params=eCkMbofJaxLYTvRtgHhOpuBEWKnXsU,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,cookies=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,method='GET')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXsz=json.loads(eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.text)
   if sType=='TVSHOW':
    if not('programRsb' in eCkMbofJaxLYTvRtgHhOpuBEWKnXsz):return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsN=eCkMbofJaxLYTvRtgHhOpuBEWKnXsz['programRsb']['dataList']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsy =eCkMbofJaxLYTvRtgHhOpuBEWKnXzV(eCkMbofJaxLYTvRtgHhOpuBEWKnXsz['programRsb']['count'])
    for eCkMbofJaxLYTvRtgHhOpuBEWKnXPj in eCkMbofJaxLYTvRtgHhOpuBEWKnXsN:
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsm=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['mast_cd']
     eCkMbofJaxLYTvRtgHhOpuBEWKnXPc =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['mast_nm']
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsi=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_TVING_IMG+eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['web_url4']
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsw =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_TVING_IMG+eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['web_url']
     try:
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsA =[]
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsG=[]
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsF =[]
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsj =0
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsd =''
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsq =''
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsl =''
      if eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('actor') !='' and eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('actor') !='-':eCkMbofJaxLYTvRtgHhOpuBEWKnXsA =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('actor').split(',')
      if eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('director')!='' and eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('director')!='-':eCkMbofJaxLYTvRtgHhOpuBEWKnXsG=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('director').split(',')
      if eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('cate_nm')!='' and eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('cate_nm')!='-':eCkMbofJaxLYTvRtgHhOpuBEWKnXsF =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('cate_nm').split('/')
      if 'targetage' in eCkMbofJaxLYTvRtgHhOpuBEWKnXPj:eCkMbofJaxLYTvRtgHhOpuBEWKnXsd=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('targetage')
      if 'broad_dt' in eCkMbofJaxLYTvRtgHhOpuBEWKnXPj:
       eCkMbofJaxLYTvRtgHhOpuBEWKnXsS=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('broad_dt')
       eCkMbofJaxLYTvRtgHhOpuBEWKnXsl='%s-%s-%s'%(eCkMbofJaxLYTvRtgHhOpuBEWKnXsS[:4],eCkMbofJaxLYTvRtgHhOpuBEWKnXsS[4:6],eCkMbofJaxLYTvRtgHhOpuBEWKnXsS[6:])
       eCkMbofJaxLYTvRtgHhOpuBEWKnXsq =eCkMbofJaxLYTvRtgHhOpuBEWKnXsS[:4]
     except:
      eCkMbofJaxLYTvRtgHhOpuBEWKnXzS
     eCkMbofJaxLYTvRtgHhOpuBEWKnXPr={'title':eCkMbofJaxLYTvRtgHhOpuBEWKnXPc,}
     eCkMbofJaxLYTvRtgHhOpuBEWKnXPy.append(eCkMbofJaxLYTvRtgHhOpuBEWKnXPr)
   else:
    if not('vodMVRsb' in eCkMbofJaxLYTvRtgHhOpuBEWKnXsz):return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsc=eCkMbofJaxLYTvRtgHhOpuBEWKnXsz['vodMVRsb']['dataList']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsy =eCkMbofJaxLYTvRtgHhOpuBEWKnXzV(eCkMbofJaxLYTvRtgHhOpuBEWKnXsz['vodMVRsb']['count'])
    eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(eCkMbofJaxLYTvRtgHhOpuBEWKnXsy)
    for eCkMbofJaxLYTvRtgHhOpuBEWKnXPj in eCkMbofJaxLYTvRtgHhOpuBEWKnXsc:
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsm=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['mast_cd']
     eCkMbofJaxLYTvRtgHhOpuBEWKnXPc =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['mast_nm'].strip()
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsi =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_TVING_IMG+eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['web_url']
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsw =eCkMbofJaxLYTvRtgHhOpuBEWKnXsi
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsI=''
     try:
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsA =[]
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsG=[]
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsF =[]
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsj =0
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsd =''
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsq =''
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsl =''
      if eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('actor') !='' and eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('actor') !='-':eCkMbofJaxLYTvRtgHhOpuBEWKnXsA =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('actor').split(',')
      if eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('director')!='' and eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('director')!='-':eCkMbofJaxLYTvRtgHhOpuBEWKnXsG=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('director').split(',')
      if eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('cate_nm')!='' and eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('cate_nm')!='-':eCkMbofJaxLYTvRtgHhOpuBEWKnXsF =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('cate_nm').split('/')
      if eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('runtime_sec')!='':eCkMbofJaxLYTvRtgHhOpuBEWKnXsj=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('runtime_sec')
      if 'grade_nm' in eCkMbofJaxLYTvRtgHhOpuBEWKnXPj:eCkMbofJaxLYTvRtgHhOpuBEWKnXsd=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('grade_nm')
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsr=''
      eCkMbofJaxLYTvRtgHhOpuBEWKnXsS=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('broad_dt')
      if eCkMbofJaxLYTvRtgHhOpuBEWKnXsr!='':
       eCkMbofJaxLYTvRtgHhOpuBEWKnXsl='%s-%s-%s'%(eCkMbofJaxLYTvRtgHhOpuBEWKnXsS[:4],eCkMbofJaxLYTvRtgHhOpuBEWKnXsS[4:6],eCkMbofJaxLYTvRtgHhOpuBEWKnXsS[6:])
       eCkMbofJaxLYTvRtgHhOpuBEWKnXsq =eCkMbofJaxLYTvRtgHhOpuBEWKnXsS[:4]
     except:
      eCkMbofJaxLYTvRtgHhOpuBEWKnXzS
     eCkMbofJaxLYTvRtgHhOpuBEWKnXPr={'title':eCkMbofJaxLYTvRtgHhOpuBEWKnXPc,}
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsV=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
     for eCkMbofJaxLYTvRtgHhOpuBEWKnXPD in eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['bill']:
      if eCkMbofJaxLYTvRtgHhOpuBEWKnXPD in eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.TVING_MOVIE_LITE:
       eCkMbofJaxLYTvRtgHhOpuBEWKnXsV=eCkMbofJaxLYTvRtgHhOpuBEWKnXzc
       break
     if eCkMbofJaxLYTvRtgHhOpuBEWKnXsV==eCkMbofJaxLYTvRtgHhOpuBEWKnXzD: 
      eCkMbofJaxLYTvRtgHhOpuBEWKnXPr['title']=eCkMbofJaxLYTvRtgHhOpuBEWKnXPr['title']+' [개별구매]'
     eCkMbofJaxLYTvRtgHhOpuBEWKnXPy.append(eCkMbofJaxLYTvRtgHhOpuBEWKnXPr)
   if eCkMbofJaxLYTvRtgHhOpuBEWKnXsy>(page_int*eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.TVING_LIMIT):eCkMbofJaxLYTvRtgHhOpuBEWKnXPi=eCkMbofJaxLYTvRtgHhOpuBEWKnXzc
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception)
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi
 def Get_Search_Watcha(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,search_key,page_int):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPy=[]
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPi=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
  try:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPw=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_WATCHA+'/api/search.json'
   eCkMbofJaxLYTvRtgHhOpuBEWKnXsU={'query':search_key,'page':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(page_int),'per':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.WATCHA_LIMIT),'exclude':'limited',}
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.Call_Request(eCkMbofJaxLYTvRtgHhOpuBEWKnXPw,payload=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,params=eCkMbofJaxLYTvRtgHhOpuBEWKnXsU,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.WATCHA_HEADER,cookies=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,method='GET')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXsz=json.loads(eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.text)
   if not('results' in eCkMbofJaxLYTvRtgHhOpuBEWKnXsz):return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi
   eCkMbofJaxLYTvRtgHhOpuBEWKnXsD=eCkMbofJaxLYTvRtgHhOpuBEWKnXsz['results']
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPi=eCkMbofJaxLYTvRtgHhOpuBEWKnXsz['meta']['has_next']
   for eCkMbofJaxLYTvRtgHhOpuBEWKnXPj in eCkMbofJaxLYTvRtgHhOpuBEWKnXsD:
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQP =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['code']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQs=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['content_type']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQU =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['title']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQz =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['story']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsi=eCkMbofJaxLYTvRtgHhOpuBEWKnXsw=eCkMbofJaxLYTvRtgHhOpuBEWKnXzw=''
    if eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('poster') !=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS:eCkMbofJaxLYTvRtgHhOpuBEWKnXsi=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('poster').get('original')
    if eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('stillcut')!=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS:eCkMbofJaxLYTvRtgHhOpuBEWKnXsw =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('stillcut').get('large')
    if eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('thumbnail')!=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS:eCkMbofJaxLYTvRtgHhOpuBEWKnXzw=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('thumbnail').get('large')
    if eCkMbofJaxLYTvRtgHhOpuBEWKnXzw=='' :eCkMbofJaxLYTvRtgHhOpuBEWKnXzw=eCkMbofJaxLYTvRtgHhOpuBEWKnXsw
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQN={'thumb':eCkMbofJaxLYTvRtgHhOpuBEWKnXsw,'poster':eCkMbofJaxLYTvRtgHhOpuBEWKnXsi,'fanart':eCkMbofJaxLYTvRtgHhOpuBEWKnXzw}
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsq =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['year']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQy =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['film_rating_code']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQm=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['film_rating_short']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQi =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['film_rating_long']
    if eCkMbofJaxLYTvRtgHhOpuBEWKnXQs=='movies':
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsj =eCkMbofJaxLYTvRtgHhOpuBEWKnXPj['duration']
    else:
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsj ='0'
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPr={'title':eCkMbofJaxLYTvRtgHhOpuBEWKnXQU,}
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPy.append(eCkMbofJaxLYTvRtgHhOpuBEWKnXPr)
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception)
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi
 def Get_Search_Coupang(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,search_key,page_int):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPy=[]
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPi=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
  try:
   CP=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.jsonfile_To_dic(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.CP_ORIGINAL_COOKIE)
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPw=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_COUPANG+'/v2/search' 
   eCkMbofJaxLYTvRtgHhOpuBEWKnXsU={'query':search_key,'platform':'WEBCLIENT','page':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(page_int),'perPage':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.COUPANG_LIMIT),}
   eCkMbofJaxLYTvRtgHhOpuBEWKnXQw={'x-membersrl':CP['SESSION']['member_srl'],'x-pcid':CP['SESSION']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.Call_Request(eCkMbofJaxLYTvRtgHhOpuBEWKnXPw,payload=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,params=eCkMbofJaxLYTvRtgHhOpuBEWKnXsU,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXQw,cookies=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,method='GET')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPG=json.loads(eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.text)
   if eCkMbofJaxLYTvRtgHhOpuBEWKnXNs(eCkMbofJaxLYTvRtgHhOpuBEWKnXPG.get('data').get('data'))==0:return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi
   for eCkMbofJaxLYTvRtgHhOpuBEWKnXPj in eCkMbofJaxLYTvRtgHhOpuBEWKnXPG.get('data').get('data'):
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPj=eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('data')
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPr={'title':eCkMbofJaxLYTvRtgHhOpuBEWKnXPj.get('title'),}
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPy.append(eCkMbofJaxLYTvRtgHhOpuBEWKnXPr)
   if eCkMbofJaxLYTvRtgHhOpuBEWKnXPG.get('pagination').get('totalPages')>page_int:
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPi=eCkMbofJaxLYTvRtgHhOpuBEWKnXzc
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception)
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi
 def Selenium_Cookies_Load(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,in_filename):
  fp=eCkMbofJaxLYTvRtgHhOpuBEWKnXNQ(in_filename,'rb',-1)
  try:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXQA=pickle.loads(fp.read())
   if eCkMbofJaxLYTvRtgHhOpuBEWKnXNU(eCkMbofJaxLYTvRtgHhOpuBEWKnXQA)==eCkMbofJaxLYTvRtgHhOpuBEWKnXNz:
    for eCkMbofJaxLYTvRtgHhOpuBEWKnXQG in eCkMbofJaxLYTvRtgHhOpuBEWKnXQA:
     eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.HTTP_CLIENT.cookies.set_cookie(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.To_Cookielib(eCkMbofJaxLYTvRtgHhOpuBEWKnXQG)) 
   else:
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.HTTP_CLIENT.cookies.update(eCkMbofJaxLYTvRtgHhOpuBEWKnXQA) 
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception)
  finally:
   fp.close()
 def To_Cookielib(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,selenium_cookie):
  return http.cookiejar.Cookie(version=0,name=selenium_cookie['name'],value=selenium_cookie['value'],port=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,port_specified=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD,domain=selenium_cookie['domain'],domain_specified=eCkMbofJaxLYTvRtgHhOpuBEWKnXzc,domain_initial_dot=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD,path=selenium_cookie['path'],path_specified=eCkMbofJaxLYTvRtgHhOpuBEWKnXzc,secure=selenium_cookie['secure'],expires=selenium_cookie['expiry'],discard=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD,comment=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,comment_url=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,rest={'HttpOnly':selenium_cookie['httpOnly']},rfc2109=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD,)
 def Get_Search_Primev(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,search_key):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPy=[]
  try:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.Selenium_Cookies_Load(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.PV_ORIGINAL_COOKIE)
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPw=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_PRIMEV+'/search/ref=atv_nb_sr?phrase='+urllib.parse.quote_plus(search_key)+'&ie=UTF8'
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.Call_Request(eCkMbofJaxLYTvRtgHhOpuBEWKnXPw,params=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,method='GET')
   if eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.status_code!=200:return[]
   eCkMbofJaxLYTvRtgHhOpuBEWKnXQj='{"props":{"results"'
   eCkMbofJaxLYTvRtgHhOpuBEWKnXQd=r'<script type="text/template">\s*(.*?)\s*</script>'
   eCkMbofJaxLYTvRtgHhOpuBEWKnXQq=re.compile(eCkMbofJaxLYTvRtgHhOpuBEWKnXQd,re.DOTALL).findall(eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.text)
   eCkMbofJaxLYTvRtgHhOpuBEWKnXQl='{}'
   for eCkMbofJaxLYTvRtgHhOpuBEWKnXQS in eCkMbofJaxLYTvRtgHhOpuBEWKnXQq:
    if eCkMbofJaxLYTvRtgHhOpuBEWKnXQj in eCkMbofJaxLYTvRtgHhOpuBEWKnXQS:
     eCkMbofJaxLYTvRtgHhOpuBEWKnXQl=eCkMbofJaxLYTvRtgHhOpuBEWKnXQS
     break
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPG=json.loads(eCkMbofJaxLYTvRtgHhOpuBEWKnXQl)
   eCkMbofJaxLYTvRtgHhOpuBEWKnXQc=eCkMbofJaxLYTvRtgHhOpuBEWKnXPG.get('props').get('results').get('items')
   for eCkMbofJaxLYTvRtgHhOpuBEWKnXQI in eCkMbofJaxLYTvRtgHhOpuBEWKnXQc:
    if 'titleID' not in eCkMbofJaxLYTvRtgHhOpuBEWKnXQI:return[]
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPr={'title':eCkMbofJaxLYTvRtgHhOpuBEWKnXQI.get('title').get('text'),}
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPy.append(eCkMbofJaxLYTvRtgHhOpuBEWKnXPr)
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception)
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy
 def Get_Search_Disney(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,search_key):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPy=[]
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPw=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['services']['content']['getSearchResults']['href']
  eCkMbofJaxLYTvRtgHhOpuBEWKnXQr={'apiVersion':'5.1','region':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge','pageSize':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DISNEY_LIMIT),'query':search_key,}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPw=eCkMbofJaxLYTvRtgHhOpuBEWKnXPw.format(**eCkMbofJaxLYTvRtgHhOpuBEWKnXQr)
  eCkMbofJaxLYTvRtgHhOpuBEWKnXQw=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.make_DZ_Headers(accessToken=eCkMbofJaxLYTvRtgHhOpuBEWKnXzc,Bearer=eCkMbofJaxLYTvRtgHhOpuBEWKnXzc)
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.Call_Request(eCkMbofJaxLYTvRtgHhOpuBEWKnXPw,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXQw,method='GET')
  if eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.status_code not in[200,201]:return[]
  eCkMbofJaxLYTvRtgHhOpuBEWKnXQV=eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.json().get('data').get('search')
  for eCkMbofJaxLYTvRtgHhOpuBEWKnXQI in eCkMbofJaxLYTvRtgHhOpuBEWKnXQV.get('hits'):
   eCkMbofJaxLYTvRtgHhOpuBEWKnXQI=eCkMbofJaxLYTvRtgHhOpuBEWKnXQI.get('hit')
   if eCkMbofJaxLYTvRtgHhOpuBEWKnXQI.get('type')=='DmcSeries': 
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQU =eCkMbofJaxLYTvRtgHhOpuBEWKnXQI.get('text').get('title').get('full').get('series').get('default').get('content')
   elif eCkMbofJaxLYTvRtgHhOpuBEWKnXQI.get('type')=='DmcVideo':
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQU =eCkMbofJaxLYTvRtgHhOpuBEWKnXQI.get('text').get('title').get('full').get('program').get('default').get('content')
   elif eCkMbofJaxLYTvRtgHhOpuBEWKnXQI.get('type')=='StandardCollection':
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQU =eCkMbofJaxLYTvRtgHhOpuBEWKnXQI.get('text').get('title').get('full').get('collection').get('default').get('content')
   else:
    return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPr={'title':eCkMbofJaxLYTvRtgHhOpuBEWKnXQU,}
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPy.append(eCkMbofJaxLYTvRtgHhOpuBEWKnXPr)
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy
 def dic_To_jsonfile(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,filename,eCkMbofJaxLYTvRtgHhOpuBEWKnXQD):
  if filename=='':return
  fp=eCkMbofJaxLYTvRtgHhOpuBEWKnXNQ(filename,'w',-1,'utf-8')
  json.dump(eCkMbofJaxLYTvRtgHhOpuBEWKnXQD,fp,indent=4,ensure_ascii=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD)
  fp.close()
 def jsonfile_To_dic(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,filename):
  if filename=='':return eCkMbofJaxLYTvRtgHhOpuBEWKnXzS
  try:
   fp=eCkMbofJaxLYTvRtgHhOpuBEWKnXNQ(filename,'r',-1,'utf-8')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUs=json.load(fp)
   fp.close()
  except:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUs={}
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXUs
 def tempFileSave(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,filename,resText):
  if filename=='':return
  fp=eCkMbofJaxLYTvRtgHhOpuBEWKnXNQ(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,filename):
  if filename=='':return
  try:
   fp=eCkMbofJaxLYTvRtgHhOpuBEWKnXNQ(filename,'r',-1,'utf-8')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUs=fp.read()
   fp.close()
  except:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUs=''
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXUs
 def make_DZ_Headers(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,accessToken=eCkMbofJaxLYTvRtgHhOpuBEWKnXzc,Bearer=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD):
  if accessToken:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUQ=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['account']['accessToken']
  else:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUQ=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['headers']['clientApiKey']
  if Bearer:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUQ='Bearer {}'.format(eCkMbofJaxLYTvRtgHhOpuBEWKnXUQ)
  eCkMbofJaxLYTvRtgHhOpuBEWKnXQw={'authorization':eCkMbofJaxLYTvRtgHhOpuBEWKnXUQ,'x-application-version':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['headers']['sdkAppVersion'],'x-bamsdk-client-id':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['headers']['clientId'],'x-bamsdk-platform':'windows','x-bamsdk-version':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['headers']['sdkVersion'],'x-dss-edge-accept':'vnd.dss.edge+json; version=2',}
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXQw
 def DZ_ReToken(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ):
  try:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPw =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['services']['orchestration']['refreshToken']['href']
   eCkMbofJaxLYTvRtgHhOpuBEWKnXQw=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.make_DZ_Headers(accessToken=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD,Bearer=eCkMbofJaxLYTvRtgHhOpuBEWKnXzD)
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUz={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['account']['refreshToken'],}}}
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.Call_Request(eCkMbofJaxLYTvRtgHhOpuBEWKnXPw,json=eCkMbofJaxLYTvRtgHhOpuBEWKnXUz,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXQw,method='POST')
   if eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.status_code not in[200,201]:return eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
   eCkMbofJaxLYTvRtgHhOpuBEWKnXQV=eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.json()
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['account']['accessToken'] =eCkMbofJaxLYTvRtgHhOpuBEWKnXQV.get('extensions').get('sdk').get('token').get('accessToken')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['account']['accessTokenType']=eCkMbofJaxLYTvRtgHhOpuBEWKnXQV.get('extensions').get('sdk').get('token').get('accessTokenType')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['account']['refreshToken'] =eCkMbofJaxLYTvRtgHhOpuBEWKnXQV.get('extensions').get('sdk').get('token').get('refreshToken')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['account']['token_limit'] =eCkMbofJaxLYTvRtgHhOpuBEWKnXzV(time.time())+14400 
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['account']['deviceId'] =eCkMbofJaxLYTvRtgHhOpuBEWKnXQV.get('extensions').get('sdk').get('session').get('device').get('id')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DZ['account']['sessionId'] =eCkMbofJaxLYTvRtgHhOpuBEWKnXQV.get('extensions').get('sdk').get('session').get('sessionId')
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception)
   return eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXzc
 def Init_NF_Total(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF={}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']={}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']={}
 def make_NF_XnetflixHeaders(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXQw={'x-netflix.browsername':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['esnModel'],'x-netflix.esnprefix':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['nowGuid'],'x-netflix.uiversion':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXQw
 def make_NF_ApiParams(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPA={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['identifier']),}
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXPA
 def extract_json(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,content,name):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXQd=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  eCkMbofJaxLYTvRtgHhOpuBEWKnXQl=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUN=re.compile(eCkMbofJaxLYTvRtgHhOpuBEWKnXQd.format(name),re.DOTALL).findall(content)
  eCkMbofJaxLYTvRtgHhOpuBEWKnXQl=eCkMbofJaxLYTvRtgHhOpuBEWKnXUN[0]
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUy=eCkMbofJaxLYTvRtgHhOpuBEWKnXQl.replace('\\"','\\\\"') 
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUy=eCkMbofJaxLYTvRtgHhOpuBEWKnXUy.replace('\\s','\\\\s') 
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUy=eCkMbofJaxLYTvRtgHhOpuBEWKnXUy.replace('\\n','\\\\n') 
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUy=eCkMbofJaxLYTvRtgHhOpuBEWKnXUy.replace('\\t','\\\\t') 
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUy=eCkMbofJaxLYTvRtgHhOpuBEWKnXUy.encode().decode('unicode_escape') 
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUy=re.sub(r'\\(?!["])',r'\\\\',eCkMbofJaxLYTvRtgHhOpuBEWKnXUy) 
  return json.loads(eCkMbofJaxLYTvRtgHhOpuBEWKnXUy)
 def NF_makestr_paths(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,paths):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUs=[]
  if eCkMbofJaxLYTvRtgHhOpuBEWKnXNy(paths,eCkMbofJaxLYTvRtgHhOpuBEWKnXzV):
   return '%d'%(paths)
  elif eCkMbofJaxLYTvRtgHhOpuBEWKnXNy(paths,eCkMbofJaxLYTvRtgHhOpuBEWKnXzr):
   return '"%s"'%(paths)
  for eCkMbofJaxLYTvRtgHhOpuBEWKnXUm in paths:
   if eCkMbofJaxLYTvRtgHhOpuBEWKnXNy(eCkMbofJaxLYTvRtgHhOpuBEWKnXUm,eCkMbofJaxLYTvRtgHhOpuBEWKnXzV):
    eCkMbofJaxLYTvRtgHhOpuBEWKnXUs.append('%d'%(eCkMbofJaxLYTvRtgHhOpuBEWKnXUm))
   elif eCkMbofJaxLYTvRtgHhOpuBEWKnXNy(eCkMbofJaxLYTvRtgHhOpuBEWKnXUm,eCkMbofJaxLYTvRtgHhOpuBEWKnXzr):
    eCkMbofJaxLYTvRtgHhOpuBEWKnXUs.append('"%s"'%(eCkMbofJaxLYTvRtgHhOpuBEWKnXUm))
   elif eCkMbofJaxLYTvRtgHhOpuBEWKnXNy(eCkMbofJaxLYTvRtgHhOpuBEWKnXUm,eCkMbofJaxLYTvRtgHhOpuBEWKnXNz):
    eCkMbofJaxLYTvRtgHhOpuBEWKnXUs.append('[%s]'%(','.join(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_makestr_paths(eCkMbofJaxLYTvRtgHhOpuBEWKnXUm))))
   elif eCkMbofJaxLYTvRtgHhOpuBEWKnXNy(eCkMbofJaxLYTvRtgHhOpuBEWKnXUm,eCkMbofJaxLYTvRtgHhOpuBEWKnXNm):
    eCkMbofJaxLYTvRtgHhOpuBEWKnXUi=''
    for eCkMbofJaxLYTvRtgHhOpuBEWKnXUw,eCkMbofJaxLYTvRtgHhOpuBEWKnXUA in eCkMbofJaxLYTvRtgHhOpuBEWKnXUm.items():
     eCkMbofJaxLYTvRtgHhOpuBEWKnXUi+='"%s":%s,'%(eCkMbofJaxLYTvRtgHhOpuBEWKnXUw,eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_makestr_paths(eCkMbofJaxLYTvRtgHhOpuBEWKnXUA))
    eCkMbofJaxLYTvRtgHhOpuBEWKnXUs.append('{%s}'%(eCkMbofJaxLYTvRtgHhOpuBEWKnXUi[:-1]))
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXUs
 def NF_Call_pathapi(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,eCkMbofJaxLYTvRtgHhOpuBEWKnXUV,referer=''):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUG='%s/nq/website/memberapi/%s/pathEvaluator'%(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_NETFLIX,eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['identifier'])
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUz={'path':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_makestr_paths(eCkMbofJaxLYTvRtgHhOpuBEWKnXUV),'authURL':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']['authURL']}
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPA=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.make_NF_ApiParams()
  eCkMbofJaxLYTvRtgHhOpuBEWKnXQw={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':eCkMbofJaxLYTvRtgHhOpuBEWKnXQw['referer']=referer
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUF=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.make_NF_XnetflixHeaders()
  eCkMbofJaxLYTvRtgHhOpuBEWKnXQw.update(eCkMbofJaxLYTvRtgHhOpuBEWKnXUF)
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUj=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_Get_DefaultCookies()
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUj['profilesNewSession']='0'
  try:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.Call_Request(eCkMbofJaxLYTvRtgHhOpuBEWKnXUG,payload=eCkMbofJaxLYTvRtgHhOpuBEWKnXUz,params=eCkMbofJaxLYTvRtgHhOpuBEWKnXPA,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXQw,cookies=eCkMbofJaxLYTvRtgHhOpuBEWKnXUj,method='POST')
   return eCkMbofJaxLYTvRtgHhOpuBEWKnXPz
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception)
   return eCkMbofJaxLYTvRtgHhOpuBEWKnXzS
 def Get_Search_Netflix(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,search_key,page_int,byReference=''):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUd=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.DERECTOR_LIMIT
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUq =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.CAST_LIMIT
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUl =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.GENRE_LIMIT
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUS =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_LIMIT*(page_int-1)
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUc =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_LIMIT*page_int 
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUI="|%s"%(search_key)
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUr ='%s/search?%s'%(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUV=[["search","byTerm",eCkMbofJaxLYTvRtgHhOpuBEWKnXUI,"titles",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_LIMIT,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"summary"],["search","byTerm",eCkMbofJaxLYTvRtgHhOpuBEWKnXUI,"titles",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_LIMIT,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",eCkMbofJaxLYTvRtgHhOpuBEWKnXUI,"titles",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_LIMIT,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference","boxarts",[eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND2,eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_PORT],"jpg"],["search","byTerm",eCkMbofJaxLYTvRtgHhOpuBEWKnXUI,"titles",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_LIMIT,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference","interestingMoment",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND1,"jpg"],["search","byTerm",eCkMbofJaxLYTvRtgHhOpuBEWKnXUI,"titles",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_LIMIT,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference","storyArt",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND2,"jpg"],["search","byTerm",eCkMbofJaxLYTvRtgHhOpuBEWKnXUI,"titles",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_LIMIT,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference",["cast","creators","directors"],{"from":0,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUd},["id","name"]],["search","byTerm",eCkMbofJaxLYTvRtgHhOpuBEWKnXUI,"titles",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_LIMIT,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference","genres",{"from":0,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUl},["id","name"]],["search","byTerm",eCkMbofJaxLYTvRtgHhOpuBEWKnXUI,"titles",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NETFLIX_LIMIT,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LOGO,"png"],]
  else:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUV=[["search","byReference",byReference,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"summary"],["search","byReference",byReference,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference","boxarts",[eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND2,eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference","interestingMoment",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference","storyArt",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference",["cast","creators","directors"],{"from":0,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUd},["id","name"]],["search","byReference",byReference,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference","genres",{"from":0,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUl},["id","name"]],["search","byReference",byReference,{"from":eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,"to":eCkMbofJaxLYTvRtgHhOpuBEWKnXUc},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LOGO,"png"],]
  try:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_Call_pathapi(eCkMbofJaxLYTvRtgHhOpuBEWKnXUV,eCkMbofJaxLYTvRtgHhOpuBEWKnXUr)
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPG=json.loads(eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.text)
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception)
  (eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi,byReference)=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.Search_Netflix_Make(eCkMbofJaxLYTvRtgHhOpuBEWKnXPG)
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi,byReference
 def Search_Netflix_Make(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,jsonSource):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPy=[]
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPi =eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUD=''
  eCkMbofJaxLYTvRtgHhOpuBEWKnXzP=jsonSource.get('paths')[0][1]
  if eCkMbofJaxLYTvRtgHhOpuBEWKnXzP=='byTerm':
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUS =jsonSource['paths'][0][5]['from']
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUc =jsonSource['paths'][0][5]['to']
  else:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUS =jsonSource['paths'][0][3]['from']
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUc =jsonSource['paths'][0][3]['to']
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUD=eCkMbofJaxLYTvRtgHhOpuBEWKnXNz(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  eCkMbofJaxLYTvRtgHhOpuBEWKnXzs=jsonSource.get('jsonGraph').get('search').get('byReference').get(eCkMbofJaxLYTvRtgHhOpuBEWKnXUD)
  eCkMbofJaxLYTvRtgHhOpuBEWKnXzQ =jsonSource.get('jsonGraph').get('videos')
  eCkMbofJaxLYTvRtgHhOpuBEWKnXzU=jsonSource.get('jsonGraph').get('person')
  eCkMbofJaxLYTvRtgHhOpuBEWKnXzN=jsonSource.get('jsonGraph').get('genres')
  eCkMbofJaxLYTvRtgHhOpuBEWKnXPi=eCkMbofJaxLYTvRtgHhOpuBEWKnXzc if eCkMbofJaxLYTvRtgHhOpuBEWKnXzs[eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXUc)]['reference']['$type']=='ref' else eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
  for eCkMbofJaxLYTvRtgHhOpuBEWKnXzy in eCkMbofJaxLYTvRtgHhOpuBEWKnXNi(eCkMbofJaxLYTvRtgHhOpuBEWKnXUS,eCkMbofJaxLYTvRtgHhOpuBEWKnXUc):
   if eCkMbofJaxLYTvRtgHhOpuBEWKnXzs[eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXzy)]['reference']['$type']=='ref':
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPS =eCkMbofJaxLYTvRtgHhOpuBEWKnXzs[eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(eCkMbofJaxLYTvRtgHhOpuBEWKnXzy)]['reference']['value'][1]
    eCkMbofJaxLYTvRtgHhOpuBEWKnXzm=eCkMbofJaxLYTvRtgHhOpuBEWKnXzQ[eCkMbofJaxLYTvRtgHhOpuBEWKnXPS]
    eCkMbofJaxLYTvRtgHhOpuBEWKnXQU =eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['title']['value']
    if eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['availability']['value']['isPlayable']==eCkMbofJaxLYTvRtgHhOpuBEWKnXzD:
     continue
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPl =eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['summary']['value']['type']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsj =0 if eCkMbofJaxLYTvRtgHhOpuBEWKnXPl!='movie' else eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['runtime']['value']
    if eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['sequiturEvidence']['value']['value']:
     eCkMbofJaxLYTvRtgHhOpuBEWKnXzi=eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['sequiturEvidence']['value']['value']['text']
    else:
     eCkMbofJaxLYTvRtgHhOpuBEWKnXzi=''
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsi =eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['boxarts'][eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_PORT]['jpg']['value']['url']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXzw =eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['boxarts'][eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND2]['jpg']['value']['url']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsw=''
    if 'value' in eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['storyArt'][eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND2]['jpg']:
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsw =eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['storyArt'][eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND2]['jpg']['value']['url']
    if eCkMbofJaxLYTvRtgHhOpuBEWKnXsw=='' and 'value' in eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['interestingMoment'][eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND1]['jpg']:
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsw =eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['interestingMoment'][eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LAND1]['jpg']['value']['url']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsI=''
    if 'value' in eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LOGO]['png']:
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsI=eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.ART_SIZE_LOGO]['png']['value']['url']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsF =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_Subid_List(eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['genres'])
    for i in eCkMbofJaxLYTvRtgHhOpuBEWKnXNi(eCkMbofJaxLYTvRtgHhOpuBEWKnXNs(eCkMbofJaxLYTvRtgHhOpuBEWKnXsF)):
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsF[i]=eCkMbofJaxLYTvRtgHhOpuBEWKnXzN[eCkMbofJaxLYTvRtgHhOpuBEWKnXsF[i]]['name']['value']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsG=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_Subid_List(eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['directors'])
    eCkMbofJaxLYTvRtgHhOpuBEWKnXzA =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_Subid_List(eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['creators'])
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsG.extend(eCkMbofJaxLYTvRtgHhOpuBEWKnXzA)
    for i in eCkMbofJaxLYTvRtgHhOpuBEWKnXNi(eCkMbofJaxLYTvRtgHhOpuBEWKnXNs(eCkMbofJaxLYTvRtgHhOpuBEWKnXsG)):
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsG[i]=eCkMbofJaxLYTvRtgHhOpuBEWKnXzU[eCkMbofJaxLYTvRtgHhOpuBEWKnXsG[i]]['name']['value']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXsA=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_Subid_List(eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['cast'])
    for i in eCkMbofJaxLYTvRtgHhOpuBEWKnXNi(eCkMbofJaxLYTvRtgHhOpuBEWKnXNs(eCkMbofJaxLYTvRtgHhOpuBEWKnXsA)):
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsA[i]=eCkMbofJaxLYTvRtgHhOpuBEWKnXzU[eCkMbofJaxLYTvRtgHhOpuBEWKnXsA[i]]['name']['value']
    if 'maturityDescription' in eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['maturity']['value']['rating']:
     eCkMbofJaxLYTvRtgHhOpuBEWKnXsd=eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['maturity']['value']['rating']['maturityDescription']
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPr={'videoid':eCkMbofJaxLYTvRtgHhOpuBEWKnXPS,'vidtype':eCkMbofJaxLYTvRtgHhOpuBEWKnXPl,'title':eCkMbofJaxLYTvRtgHhOpuBEWKnXQU,'mpaa':eCkMbofJaxLYTvRtgHhOpuBEWKnXsd,'regularSynopsis':eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['regularSynopsis']['value'],'dpSupplemental':eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['dpSupplementalMessage']['value'],'sequiturEvidence':eCkMbofJaxLYTvRtgHhOpuBEWKnXzi,'thumbnail':{'poster':eCkMbofJaxLYTvRtgHhOpuBEWKnXsi,'thumb':eCkMbofJaxLYTvRtgHhOpuBEWKnXsw,'fanart':eCkMbofJaxLYTvRtgHhOpuBEWKnXzw,'clearlogo':eCkMbofJaxLYTvRtgHhOpuBEWKnXsI},'year':eCkMbofJaxLYTvRtgHhOpuBEWKnXzm['releaseYear']['value'],'duration':eCkMbofJaxLYTvRtgHhOpuBEWKnXsj,'info_genre':eCkMbofJaxLYTvRtgHhOpuBEWKnXsF,'director':eCkMbofJaxLYTvRtgHhOpuBEWKnXsG,'cast':eCkMbofJaxLYTvRtgHhOpuBEWKnXsA,}
    eCkMbofJaxLYTvRtgHhOpuBEWKnXPy.append(eCkMbofJaxLYTvRtgHhOpuBEWKnXPr)
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXPy,eCkMbofJaxLYTvRtgHhOpuBEWKnXPi,eCkMbofJaxLYTvRtgHhOpuBEWKnXUD
 def NF_Subid_List(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,subJson):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXzG=[]
  try:
   for i in eCkMbofJaxLYTvRtgHhOpuBEWKnXNi(eCkMbofJaxLYTvRtgHhOpuBEWKnXNs(subJson)):
    if subJson.get(eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(i)).get('$type')!='ref':break
    eCkMbofJaxLYTvRtgHhOpuBEWKnXzF=subJson.get(eCkMbofJaxLYTvRtgHhOpuBEWKnXzr(i)).get('value')[1]
    eCkMbofJaxLYTvRtgHhOpuBEWKnXzG.append(eCkMbofJaxLYTvRtgHhOpuBEWKnXzF)
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception)
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXzG
 def NF_CookieFile_Load(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ,cookie_filename):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUj={}
  try:
   if os.path.isfile(cookie_filename)==eCkMbofJaxLYTvRtgHhOpuBEWKnXzD:return{}
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzj=eCkMbofJaxLYTvRtgHhOpuBEWKnXNQ(cookie_filename,'rb',-1)
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzd =pickle.loads(eCkMbofJaxLYTvRtgHhOpuBEWKnXzj.read())
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzj.close()
   for eCkMbofJaxLYTvRtgHhOpuBEWKnXQG in eCkMbofJaxLYTvRtgHhOpuBEWKnXzd:
    eCkMbofJaxLYTvRtgHhOpuBEWKnXUj[eCkMbofJaxLYTvRtgHhOpuBEWKnXQG.name]=eCkMbofJaxLYTvRtgHhOpuBEWKnXQG.value
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception) 
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXUj
 def NF_Get_DefaultCookies(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ):
  eCkMbofJaxLYTvRtgHhOpuBEWKnXUj={}
  if eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['flwssn'] :eCkMbofJaxLYTvRtgHhOpuBEWKnXUj['flwssn'] =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['flwssn']
  if eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['nfvdid'] :eCkMbofJaxLYTvRtgHhOpuBEWKnXUj['nfvdid'] =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['nfvdid']
  if eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['SecureNetflixId']:eCkMbofJaxLYTvRtgHhOpuBEWKnXUj['SecureNetflixId']=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['SecureNetflixId']
  if eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['NetflixId'] :eCkMbofJaxLYTvRtgHhOpuBEWKnXUj['NetflixId'] =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['NetflixId']
  if eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['memclid'] :eCkMbofJaxLYTvRtgHhOpuBEWKnXUj['memclid'] =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['memclid']
  if eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['clSharedContext']:eCkMbofJaxLYTvRtgHhOpuBEWKnXUj['clSharedContext']=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['COOKIES']['clSharedContext']
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXUj
 def NF_Get_BaseSession(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ):
  try:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPw=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.API_NETFLIX+'/browse' 
   eCkMbofJaxLYTvRtgHhOpuBEWKnXUj=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_Get_DefaultCookies()
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPz=eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.Call_Request(eCkMbofJaxLYTvRtgHhOpuBEWKnXPw,payload=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,params=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,headers=eCkMbofJaxLYTvRtgHhOpuBEWKnXzS,cookies=eCkMbofJaxLYTvRtgHhOpuBEWKnXUj,method='GET')
   if eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.status_code!=200:
    eCkMbofJaxLYTvRtgHhOpuBEWKnXzI('pass 1 status_code error')
    return eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzq =eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.extract_json(eCkMbofJaxLYTvRtgHhOpuBEWKnXPz.text,'reactContext')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF['SESSION']={'mainGuid':eCkMbofJaxLYTvRtgHhOpuBEWKnXzq['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':eCkMbofJaxLYTvRtgHhOpuBEWKnXzq['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':eCkMbofJaxLYTvRtgHhOpuBEWKnXzq['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':eCkMbofJaxLYTvRtgHhOpuBEWKnXzq['models']['memberContext']['data']['userInfo']['esn'],'identifier':eCkMbofJaxLYTvRtgHhOpuBEWKnXzq['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':eCkMbofJaxLYTvRtgHhOpuBEWKnXzq['models']['abContext']['data']['headers'],}
   eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.dic_To_jsonfile(eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF_SESSION_COOKIES1,eCkMbofJaxLYTvRtgHhOpuBEWKnXPQ.NF)
  except eCkMbofJaxLYTvRtgHhOpuBEWKnXNP as exception:
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI('pass 1 error')
   eCkMbofJaxLYTvRtgHhOpuBEWKnXzI(exception)
   return eCkMbofJaxLYTvRtgHhOpuBEWKnXzD
  return eCkMbofJaxLYTvRtgHhOpuBEWKnXzc
# Created by pyminifier (https://github.com/liftoff/pyminifier)
