__author__="NightRain"
WsRekqlVYvKugFOcyPMUpNGAiLmETQ=object
WsRekqlVYvKugFOcyPMUpNGAiLmETI=None
WsRekqlVYvKugFOcyPMUpNGAiLmETa=True
WsRekqlVYvKugFOcyPMUpNGAiLmETd=False
WsRekqlVYvKugFOcyPMUpNGAiLmETC=type
WsRekqlVYvKugFOcyPMUpNGAiLmETr=dict
WsRekqlVYvKugFOcyPMUpNGAiLmETB=open
WsRekqlVYvKugFOcyPMUpNGAiLmETh=len
WsRekqlVYvKugFOcyPMUpNGAiLmETb=Exception
WsRekqlVYvKugFOcyPMUpNGAiLmESf=int
WsRekqlVYvKugFOcyPMUpNGAiLmESz=range
WsRekqlVYvKugFOcyPMUpNGAiLmESH=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
WsRekqlVYvKugFOcyPMUpNGAiLmEfH=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
WsRekqlVYvKugFOcyPMUpNGAiLmEfj={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
WsRekqlVYvKugFOcyPMUpNGAiLmEfT=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
WsRekqlVYvKugFOcyPMUpNGAiLmEfS =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class WsRekqlVYvKugFOcyPMUpNGAiLmEfz(WsRekqlVYvKugFOcyPMUpNGAiLmETQ):
 def __init__(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,WsRekqlVYvKugFOcyPMUpNGAiLmEft,WsRekqlVYvKugFOcyPMUpNGAiLmEfo,WsRekqlVYvKugFOcyPMUpNGAiLmEfx):
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn._addon_url =WsRekqlVYvKugFOcyPMUpNGAiLmEft
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn._addon_handle=WsRekqlVYvKugFOcyPMUpNGAiLmEfo
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.main_params =WsRekqlVYvKugFOcyPMUpNGAiLmEfx
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj =QrGPlHUVjWIXCEObcpFMqdJmNvgBRk() 
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_authinfo.json'))
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,sting):
  try:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfX=xbmcgui.Dialog()
   WsRekqlVYvKugFOcyPMUpNGAiLmEfX.notification(__addonname__,sting)
  except:
   WsRekqlVYvKugFOcyPMUpNGAiLmETI
 def addon_log(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,string):
  try:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfJ=string.encode('utf-8','ignore')
  except:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfJ='addonException: addon_log'
  WsRekqlVYvKugFOcyPMUpNGAiLmEfw=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,WsRekqlVYvKugFOcyPMUpNGAiLmEfJ),level=WsRekqlVYvKugFOcyPMUpNGAiLmEfw)
 def get_keyboard_input(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,WsRekqlVYvKugFOcyPMUpNGAiLmEfB):
  WsRekqlVYvKugFOcyPMUpNGAiLmEfQ=WsRekqlVYvKugFOcyPMUpNGAiLmETI
  kb=xbmc.Keyboard()
  kb.setHeading(WsRekqlVYvKugFOcyPMUpNGAiLmEfB)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   WsRekqlVYvKugFOcyPMUpNGAiLmEfQ=kb.getText()
  return WsRekqlVYvKugFOcyPMUpNGAiLmEfQ
 def get_settings_menubookmark(WsRekqlVYvKugFOcyPMUpNGAiLmEfn):
  WsRekqlVYvKugFOcyPMUpNGAiLmEfI=WsRekqlVYvKugFOcyPMUpNGAiLmETa if __addon__.getSetting('menu_bookmark')=='true' else WsRekqlVYvKugFOcyPMUpNGAiLmETd
  return(WsRekqlVYvKugFOcyPMUpNGAiLmEfI)
 def get_settings_makebookmark(WsRekqlVYvKugFOcyPMUpNGAiLmEfn):
  return WsRekqlVYvKugFOcyPMUpNGAiLmETa if __addon__.getSetting('make_bookmark')=='true' else WsRekqlVYvKugFOcyPMUpNGAiLmETd
 def get_settings_select_info(WsRekqlVYvKugFOcyPMUpNGAiLmEfn):
  WsRekqlVYvKugFOcyPMUpNGAiLmEfa=[]
  if __addon__.getSetting('netflixyn')=='true':WsRekqlVYvKugFOcyPMUpNGAiLmEfa.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':WsRekqlVYvKugFOcyPMUpNGAiLmEfa.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':WsRekqlVYvKugFOcyPMUpNGAiLmEfa.append('tving')
  if __addon__.getSetting('watchayn')=='true':WsRekqlVYvKugFOcyPMUpNGAiLmEfa.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':WsRekqlVYvKugFOcyPMUpNGAiLmEfa.append('coupang')
  if __addon__.getSetting('primevyn')=='true':WsRekqlVYvKugFOcyPMUpNGAiLmEfa.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':WsRekqlVYvKugFOcyPMUpNGAiLmEfa.append('disney')
  return WsRekqlVYvKugFOcyPMUpNGAiLmEfa
 def add_dir(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,label,sublabel='',img='',infoLabels=WsRekqlVYvKugFOcyPMUpNGAiLmETI,isFolder=WsRekqlVYvKugFOcyPMUpNGAiLmETa,params='',isLink=WsRekqlVYvKugFOcyPMUpNGAiLmETd,ContextMenu=WsRekqlVYvKugFOcyPMUpNGAiLmETI,direct_url=WsRekqlVYvKugFOcyPMUpNGAiLmETI):
  if direct_url:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfd=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   WsRekqlVYvKugFOcyPMUpNGAiLmEfr=json.dumps(params,separators=(',',':'))
   WsRekqlVYvKugFOcyPMUpNGAiLmEfr=base64.standard_b64encode(WsRekqlVYvKugFOcyPMUpNGAiLmEfr.encode()).decode('utf-8')
   WsRekqlVYvKugFOcyPMUpNGAiLmEfr=WsRekqlVYvKugFOcyPMUpNGAiLmEfr.replace('+','%2B')
   WsRekqlVYvKugFOcyPMUpNGAiLmEfd='%s?params=%s'%(WsRekqlVYvKugFOcyPMUpNGAiLmEfn._addon_url,WsRekqlVYvKugFOcyPMUpNGAiLmEfr)
  if sublabel and sublabel!='-':WsRekqlVYvKugFOcyPMUpNGAiLmEfB='%s < %s >'%(label,sublabel)
  else: WsRekqlVYvKugFOcyPMUpNGAiLmEfB=label
  if not img:img='DefaultFolder.png'
  WsRekqlVYvKugFOcyPMUpNGAiLmEfh=xbmcgui.ListItem(WsRekqlVYvKugFOcyPMUpNGAiLmEfB)
  if WsRekqlVYvKugFOcyPMUpNGAiLmETC(img)==WsRekqlVYvKugFOcyPMUpNGAiLmETr:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfh.setArt(img)
  else:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfh.setArt({'thumb':img,'poster':img})
  if infoLabels:WsRekqlVYvKugFOcyPMUpNGAiLmEfh.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfh.setProperty('IsPlayable','true')
  if ContextMenu:WsRekqlVYvKugFOcyPMUpNGAiLmEfh.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(WsRekqlVYvKugFOcyPMUpNGAiLmEfn._addon_handle,WsRekqlVYvKugFOcyPMUpNGAiLmEfd,WsRekqlVYvKugFOcyPMUpNGAiLmEfh,isFolder)
 def Load_Searched_List(WsRekqlVYvKugFOcyPMUpNGAiLmEfn):
  try:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfb=WsRekqlVYvKugFOcyPMUpNGAiLmEfS
   fp=WsRekqlVYvKugFOcyPMUpNGAiLmETB(WsRekqlVYvKugFOcyPMUpNGAiLmEfb,'r',-1,'utf-8')
   WsRekqlVYvKugFOcyPMUpNGAiLmEzf=fp.readlines()
   fp.close()
  except:
   WsRekqlVYvKugFOcyPMUpNGAiLmEzf=[]
  return WsRekqlVYvKugFOcyPMUpNGAiLmEzf
 def Save_Searched_List(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,WsRekqlVYvKugFOcyPMUpNGAiLmEHd):
  try:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfb=WsRekqlVYvKugFOcyPMUpNGAiLmEfS
   WsRekqlVYvKugFOcyPMUpNGAiLmEzH=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.Load_Searched_List() 
   WsRekqlVYvKugFOcyPMUpNGAiLmEzj={'skey':WsRekqlVYvKugFOcyPMUpNGAiLmEHd.strip()}
   fp=WsRekqlVYvKugFOcyPMUpNGAiLmETB(WsRekqlVYvKugFOcyPMUpNGAiLmEfb,'w',-1,'utf-8')
   WsRekqlVYvKugFOcyPMUpNGAiLmEzT=urllib.parse.urlencode(WsRekqlVYvKugFOcyPMUpNGAiLmEzj)
   WsRekqlVYvKugFOcyPMUpNGAiLmEzT=WsRekqlVYvKugFOcyPMUpNGAiLmEzT+'\n'
   fp.write(WsRekqlVYvKugFOcyPMUpNGAiLmEzT)
   WsRekqlVYvKugFOcyPMUpNGAiLmEzS=0
   for WsRekqlVYvKugFOcyPMUpNGAiLmEzn in WsRekqlVYvKugFOcyPMUpNGAiLmEzH:
    WsRekqlVYvKugFOcyPMUpNGAiLmEzt=WsRekqlVYvKugFOcyPMUpNGAiLmETr(urllib.parse.parse_qsl(WsRekqlVYvKugFOcyPMUpNGAiLmEzn))
    WsRekqlVYvKugFOcyPMUpNGAiLmEzo=WsRekqlVYvKugFOcyPMUpNGAiLmEzj.get('skey').strip()
    WsRekqlVYvKugFOcyPMUpNGAiLmEzx=WsRekqlVYvKugFOcyPMUpNGAiLmEzt.get('skey').strip()
    if WsRekqlVYvKugFOcyPMUpNGAiLmEzo!=WsRekqlVYvKugFOcyPMUpNGAiLmEzx:
     fp.write(WsRekqlVYvKugFOcyPMUpNGAiLmEzn)
     WsRekqlVYvKugFOcyPMUpNGAiLmEzS+=1
     if WsRekqlVYvKugFOcyPMUpNGAiLmEzS>=50:break
   fp.close()
  except:
   WsRekqlVYvKugFOcyPMUpNGAiLmETI
 def dp_Search_History(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,args):
  WsRekqlVYvKugFOcyPMUpNGAiLmEzD=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.Load_Searched_List()
  for WsRekqlVYvKugFOcyPMUpNGAiLmEzX in WsRekqlVYvKugFOcyPMUpNGAiLmEzD:
   WsRekqlVYvKugFOcyPMUpNGAiLmEzJ=WsRekqlVYvKugFOcyPMUpNGAiLmETr(urllib.parse.parse_qsl(WsRekqlVYvKugFOcyPMUpNGAiLmEzX))
   WsRekqlVYvKugFOcyPMUpNGAiLmEzw=WsRekqlVYvKugFOcyPMUpNGAiLmEzJ.get('skey').strip()
   WsRekqlVYvKugFOcyPMUpNGAiLmEfC={'mode':'TOTAL_SEARCH','search_key':WsRekqlVYvKugFOcyPMUpNGAiLmEzw,}
   WsRekqlVYvKugFOcyPMUpNGAiLmEzQ={'mode':'HISTORY_REMOVE','skey':WsRekqlVYvKugFOcyPMUpNGAiLmEzw,'delmode':'ONE',}
   WsRekqlVYvKugFOcyPMUpNGAiLmEzI=urllib.parse.urlencode(WsRekqlVYvKugFOcyPMUpNGAiLmEzQ)
   WsRekqlVYvKugFOcyPMUpNGAiLmEza=[('선택된 검색어 ( %s ) 삭제'%(WsRekqlVYvKugFOcyPMUpNGAiLmEzw),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(WsRekqlVYvKugFOcyPMUpNGAiLmEzI))]
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.add_dir(WsRekqlVYvKugFOcyPMUpNGAiLmEzw,sublabel='',img=WsRekqlVYvKugFOcyPMUpNGAiLmETI,infoLabels=WsRekqlVYvKugFOcyPMUpNGAiLmETI,isFolder=WsRekqlVYvKugFOcyPMUpNGAiLmETa,params=WsRekqlVYvKugFOcyPMUpNGAiLmEfC,ContextMenu=WsRekqlVYvKugFOcyPMUpNGAiLmEza)
  WsRekqlVYvKugFOcyPMUpNGAiLmEzC={'plot':'검색목록 전체를 삭제합니다.'}
  WsRekqlVYvKugFOcyPMUpNGAiLmEfB='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  WsRekqlVYvKugFOcyPMUpNGAiLmEfC={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  WsRekqlVYvKugFOcyPMUpNGAiLmEzr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.add_dir(WsRekqlVYvKugFOcyPMUpNGAiLmEfB,sublabel='',img=WsRekqlVYvKugFOcyPMUpNGAiLmEzr,infoLabels=WsRekqlVYvKugFOcyPMUpNGAiLmEzC,isFolder=WsRekqlVYvKugFOcyPMUpNGAiLmETd,params=WsRekqlVYvKugFOcyPMUpNGAiLmEfC,isLink=WsRekqlVYvKugFOcyPMUpNGAiLmETa)
  xbmcplugin.endOfDirectory(WsRekqlVYvKugFOcyPMUpNGAiLmEfn._addon_handle,cacheToDisc=WsRekqlVYvKugFOcyPMUpNGAiLmETd)
 def Delete_History_List(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,WsRekqlVYvKugFOcyPMUpNGAiLmEzw,WsRekqlVYvKugFOcyPMUpNGAiLmEzb):
  if WsRekqlVYvKugFOcyPMUpNGAiLmEzb=='ALL':
   try:
    WsRekqlVYvKugFOcyPMUpNGAiLmEfb=WsRekqlVYvKugFOcyPMUpNGAiLmEfS
    fp=WsRekqlVYvKugFOcyPMUpNGAiLmETB(WsRekqlVYvKugFOcyPMUpNGAiLmEfb,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    WsRekqlVYvKugFOcyPMUpNGAiLmETI
  else:
   try:
    WsRekqlVYvKugFOcyPMUpNGAiLmEfb=WsRekqlVYvKugFOcyPMUpNGAiLmEfS
    WsRekqlVYvKugFOcyPMUpNGAiLmEzH=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.Load_Searched_List() 
    fp=WsRekqlVYvKugFOcyPMUpNGAiLmETB(WsRekqlVYvKugFOcyPMUpNGAiLmEfb,'w',-1,'utf-8')
    for WsRekqlVYvKugFOcyPMUpNGAiLmEzn in WsRekqlVYvKugFOcyPMUpNGAiLmEzH:
     WsRekqlVYvKugFOcyPMUpNGAiLmEzt=WsRekqlVYvKugFOcyPMUpNGAiLmETr(urllib.parse.parse_qsl(WsRekqlVYvKugFOcyPMUpNGAiLmEzn))
     WsRekqlVYvKugFOcyPMUpNGAiLmEzh=WsRekqlVYvKugFOcyPMUpNGAiLmEzt.get('skey').strip()
     if WsRekqlVYvKugFOcyPMUpNGAiLmEzw!=WsRekqlVYvKugFOcyPMUpNGAiLmEzh:
      fp.write(WsRekqlVYvKugFOcyPMUpNGAiLmEzn)
    fp.close()
   except:
    WsRekqlVYvKugFOcyPMUpNGAiLmETI
 def dp_History_Delete(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,args):
  WsRekqlVYvKugFOcyPMUpNGAiLmEzw =args.get('skey') 
  WsRekqlVYvKugFOcyPMUpNGAiLmEzb=args.get('delmode')
  WsRekqlVYvKugFOcyPMUpNGAiLmEfX=xbmcgui.Dialog()
  if WsRekqlVYvKugFOcyPMUpNGAiLmEzb=='ALL':
   WsRekqlVYvKugFOcyPMUpNGAiLmEHf=WsRekqlVYvKugFOcyPMUpNGAiLmEfX.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   WsRekqlVYvKugFOcyPMUpNGAiLmEHf=WsRekqlVYvKugFOcyPMUpNGAiLmEfX.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if WsRekqlVYvKugFOcyPMUpNGAiLmEHf==WsRekqlVYvKugFOcyPMUpNGAiLmETd:sys.exit()
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.Delete_History_List(WsRekqlVYvKugFOcyPMUpNGAiLmEzw,WsRekqlVYvKugFOcyPMUpNGAiLmEzb)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(WsRekqlVYvKugFOcyPMUpNGAiLmEfn):
  WsRekqlVYvKugFOcyPMUpNGAiLmEfI=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.get_settings_menubookmark()
  for WsRekqlVYvKugFOcyPMUpNGAiLmEHz in WsRekqlVYvKugFOcyPMUpNGAiLmEfH:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfB=WsRekqlVYvKugFOcyPMUpNGAiLmEHz.get('title')
   WsRekqlVYvKugFOcyPMUpNGAiLmEzr=''
   if WsRekqlVYvKugFOcyPMUpNGAiLmEHz.get('mode')=='MENU_BOOKMARK' and WsRekqlVYvKugFOcyPMUpNGAiLmEfI==WsRekqlVYvKugFOcyPMUpNGAiLmETd:continue
   WsRekqlVYvKugFOcyPMUpNGAiLmEfC={'mode':WsRekqlVYvKugFOcyPMUpNGAiLmEHz.get('mode')}
   if WsRekqlVYvKugFOcyPMUpNGAiLmEHz.get('mode')in['XXX','MENU_BOOKMARK']:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHj=WsRekqlVYvKugFOcyPMUpNGAiLmETd
    WsRekqlVYvKugFOcyPMUpNGAiLmEHT =WsRekqlVYvKugFOcyPMUpNGAiLmETa
   else:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHj=WsRekqlVYvKugFOcyPMUpNGAiLmETa
    WsRekqlVYvKugFOcyPMUpNGAiLmEHT =WsRekqlVYvKugFOcyPMUpNGAiLmETd
   if 'icon' in WsRekqlVYvKugFOcyPMUpNGAiLmEHz:WsRekqlVYvKugFOcyPMUpNGAiLmEzr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',WsRekqlVYvKugFOcyPMUpNGAiLmEHz.get('icon')) 
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.add_dir(WsRekqlVYvKugFOcyPMUpNGAiLmEfB,sublabel='',img=WsRekqlVYvKugFOcyPMUpNGAiLmEzr,infoLabels=WsRekqlVYvKugFOcyPMUpNGAiLmETI,isFolder=WsRekqlVYvKugFOcyPMUpNGAiLmEHj,params=WsRekqlVYvKugFOcyPMUpNGAiLmEfC,isLink=WsRekqlVYvKugFOcyPMUpNGAiLmEHT)
  xbmcplugin.endOfDirectory(WsRekqlVYvKugFOcyPMUpNGAiLmEfn._addon_handle,cacheToDisc=WsRekqlVYvKugFOcyPMUpNGAiLmETd)
 def option_check(WsRekqlVYvKugFOcyPMUpNGAiLmEfn):
  WsRekqlVYvKugFOcyPMUpNGAiLmEfa=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.get_settings_select_info()
  if WsRekqlVYvKugFOcyPMUpNGAiLmETh(WsRekqlVYvKugFOcyPMUpNGAiLmEfa)==0:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfX=xbmcgui.Dialog()
   WsRekqlVYvKugFOcyPMUpNGAiLmEHf=WsRekqlVYvKugFOcyPMUpNGAiLmEfX.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if WsRekqlVYvKugFOcyPMUpNGAiLmEHf==WsRekqlVYvKugFOcyPMUpNGAiLmETa:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in WsRekqlVYvKugFOcyPMUpNGAiLmEfa:
   if WsRekqlVYvKugFOcyPMUpNGAiLmEfn.NF_cookiefile_check()==WsRekqlVYvKugFOcyPMUpNGAiLmETd:
    WsRekqlVYvKugFOcyPMUpNGAiLmEfn.NF_login(showMessage=WsRekqlVYvKugFOcyPMUpNGAiLmETa)
  if 'disney' in WsRekqlVYvKugFOcyPMUpNGAiLmEfa:
   if WsRekqlVYvKugFOcyPMUpNGAiLmEfn.DZ_cookiefile_check()==WsRekqlVYvKugFOcyPMUpNGAiLmETd:
    WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.DZ={}
 def DZ_cookiefile_check(WsRekqlVYvKugFOcyPMUpNGAiLmEfn):
  WsRekqlVYvKugFOcyPMUpNGAiLmEHn={}
  try: 
   fp=WsRekqlVYvKugFOcyPMUpNGAiLmETB(WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   WsRekqlVYvKugFOcyPMUpNGAiLmEHn= json.load(fp)
   fp.close()
  except WsRekqlVYvKugFOcyPMUpNGAiLmETb as exception:
   return WsRekqlVYvKugFOcyPMUpNGAiLmETd
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.DZ=WsRekqlVYvKugFOcyPMUpNGAiLmEHn
  if WsRekqlVYvKugFOcyPMUpNGAiLmESf(time.time())>WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.DZ['account']['token_limit']:
   if WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.DZ_ReToken()==WsRekqlVYvKugFOcyPMUpNGAiLmETd:
    WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_noti(__language__(30920).encode('utf-8'))
    return WsRekqlVYvKugFOcyPMUpNGAiLmETd
   try: 
    fp=WsRekqlVYvKugFOcyPMUpNGAiLmETB(WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.DZ,fp,indent=4,ensure_ascii=WsRekqlVYvKugFOcyPMUpNGAiLmETd)
    fp.close()
   except WsRekqlVYvKugFOcyPMUpNGAiLmETb as exception:
    return WsRekqlVYvKugFOcyPMUpNGAiLmETd
  return WsRekqlVYvKugFOcyPMUpNGAiLmETa
 def NF_cookiefile_check(WsRekqlVYvKugFOcyPMUpNGAiLmEfn):
  WsRekqlVYvKugFOcyPMUpNGAiLmEHn={}
  try: 
   fp=WsRekqlVYvKugFOcyPMUpNGAiLmETB(WsRekqlVYvKugFOcyPMUpNGAiLmEfT,'r',-1,'utf-8')
   WsRekqlVYvKugFOcyPMUpNGAiLmEHn= json.load(fp)
   fp.close()
  except WsRekqlVYvKugFOcyPMUpNGAiLmETb as exception:
   return WsRekqlVYvKugFOcyPMUpNGAiLmETd
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF=WsRekqlVYvKugFOcyPMUpNGAiLmEHn
  WsRekqlVYvKugFOcyPMUpNGAiLmEHo =WsRekqlVYvKugFOcyPMUpNGAiLmESf(WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  WsRekqlVYvKugFOcyPMUpNGAiLmEHx=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF['SESSION']['limitdate']
  WsRekqlVYvKugFOcyPMUpNGAiLmEHD =WsRekqlVYvKugFOcyPMUpNGAiLmESf(re.sub('-','',WsRekqlVYvKugFOcyPMUpNGAiLmEHx))
  if WsRekqlVYvKugFOcyPMUpNGAiLmEHD<WsRekqlVYvKugFOcyPMUpNGAiLmEHo:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Init_NF_Total()
   if WsRekqlVYvKugFOcyPMUpNGAiLmEfn.NF_login(showMessage=WsRekqlVYvKugFOcyPMUpNGAiLmETd)==WsRekqlVYvKugFOcyPMUpNGAiLmETd:
    return WsRekqlVYvKugFOcyPMUpNGAiLmETd
  WsRekqlVYvKugFOcyPMUpNGAiLmEHX=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF_CookieFile_Load(WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF_ORIGINAL_COOKIE)
  if(WsRekqlVYvKugFOcyPMUpNGAiLmEHX['NetflixId']!=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF['COOKIES']['NetflixId']or WsRekqlVYvKugFOcyPMUpNGAiLmEHX['SecureNetflixId']!=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF['COOKIES']['SecureNetflixId']or WsRekqlVYvKugFOcyPMUpNGAiLmEHX['flwssn']!=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF['COOKIES']['flwssn']or WsRekqlVYvKugFOcyPMUpNGAiLmEHX['memclid']!=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF['COOKIES']['memclid']or WsRekqlVYvKugFOcyPMUpNGAiLmEHX['nfvdid']!=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF['COOKIES']['nfvdid']):
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Init_NF_Total()
   if WsRekqlVYvKugFOcyPMUpNGAiLmEfn.NF_login(showMessage=WsRekqlVYvKugFOcyPMUpNGAiLmETd)==WsRekqlVYvKugFOcyPMUpNGAiLmETd:
    return WsRekqlVYvKugFOcyPMUpNGAiLmETd
  return WsRekqlVYvKugFOcyPMUpNGAiLmETa
 def NF_login(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,showMessage=WsRekqlVYvKugFOcyPMUpNGAiLmETa):
  if showMessage:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfX=xbmcgui.Dialog()
   WsRekqlVYvKugFOcyPMUpNGAiLmEHf=WsRekqlVYvKugFOcyPMUpNGAiLmEfX.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if WsRekqlVYvKugFOcyPMUpNGAiLmEHf==WsRekqlVYvKugFOcyPMUpNGAiLmETd:
    return WsRekqlVYvKugFOcyPMUpNGAiLmETd 
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF['COOKIES']=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF_CookieFile_Load(WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF_ORIGINAL_COOKIE)
  WsRekqlVYvKugFOcyPMUpNGAiLmEHJ=WsRekqlVYvKugFOcyPMUpNGAiLmETd if WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF['COOKIES']=={}else WsRekqlVYvKugFOcyPMUpNGAiLmETa
  if WsRekqlVYvKugFOcyPMUpNGAiLmEHJ:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_log('pass1 ok!')
  else:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_log('pass1 error!')
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_noti(__language__(30905).encode('utf-8'))
   return WsRekqlVYvKugFOcyPMUpNGAiLmETd 
  WsRekqlVYvKugFOcyPMUpNGAiLmEHJ=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF_Get_BaseSession()
  if WsRekqlVYvKugFOcyPMUpNGAiLmEHJ:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_log('pass2 ok!')
  else:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_log('pass2 error!')
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_noti(__language__(30905).encode('utf-8'))
   return WsRekqlVYvKugFOcyPMUpNGAiLmETd 
  WsRekqlVYvKugFOcyPMUpNGAiLmEHw =WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Now_Datetime()
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF['SESSION']['limitdate']=WsRekqlVYvKugFOcyPMUpNGAiLmEHw.strftime('%Y-%m-%d')
  try: 
   fp=WsRekqlVYvKugFOcyPMUpNGAiLmETB(WsRekqlVYvKugFOcyPMUpNGAiLmEfT,'w',-1,'utf-8')
   json.dump(WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF,fp,indent=4,ensure_ascii=WsRekqlVYvKugFOcyPMUpNGAiLmETd)
   fp.close()
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_log('pass3 save ok!')
  except WsRekqlVYvKugFOcyPMUpNGAiLmETb as exception:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_log('pass3 save error!')
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_noti(__language__(30905).encode('utf-8'))
   return WsRekqlVYvKugFOcyPMUpNGAiLmETd
  if showMessage:WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_noti(__language__(30904).encode('utf-8'))
  return WsRekqlVYvKugFOcyPMUpNGAiLmETa
 def NF_logout(WsRekqlVYvKugFOcyPMUpNGAiLmEfn):
  WsRekqlVYvKugFOcyPMUpNGAiLmEfX=xbmcgui.Dialog()
  WsRekqlVYvKugFOcyPMUpNGAiLmEHf=WsRekqlVYvKugFOcyPMUpNGAiLmEfX.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if WsRekqlVYvKugFOcyPMUpNGAiLmEHf==WsRekqlVYvKugFOcyPMUpNGAiLmETd:return 
  if os.path.isfile(WsRekqlVYvKugFOcyPMUpNGAiLmEfT):os.remove(WsRekqlVYvKugFOcyPMUpNGAiLmEfT)
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,WsRekqlVYvKugFOcyPMUpNGAiLmEHC):
  WsRekqlVYvKugFOcyPMUpNGAiLmEHQ=''
  WsRekqlVYvKugFOcyPMUpNGAiLmEHI=7
  try:
   for i in WsRekqlVYvKugFOcyPMUpNGAiLmESz(WsRekqlVYvKugFOcyPMUpNGAiLmETh(WsRekqlVYvKugFOcyPMUpNGAiLmEHC)):
    if i>=WsRekqlVYvKugFOcyPMUpNGAiLmEHI:
     WsRekqlVYvKugFOcyPMUpNGAiLmEHQ=WsRekqlVYvKugFOcyPMUpNGAiLmEHQ+'...'
     break
    WsRekqlVYvKugFOcyPMUpNGAiLmEHQ=WsRekqlVYvKugFOcyPMUpNGAiLmEHQ+WsRekqlVYvKugFOcyPMUpNGAiLmEHC[i]['title']+'\n'
  except:
   return ''
  return WsRekqlVYvKugFOcyPMUpNGAiLmEHQ
 def dp_Search_Group(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,args):
  WsRekqlVYvKugFOcyPMUpNGAiLmEfa =WsRekqlVYvKugFOcyPMUpNGAiLmEfn.get_settings_select_info()
  WsRekqlVYvKugFOcyPMUpNGAiLmEHa=[]
  if 'search_key' in args:
   WsRekqlVYvKugFOcyPMUpNGAiLmEHd=args.get('search_key')
  else:
   WsRekqlVYvKugFOcyPMUpNGAiLmEHd=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not WsRekqlVYvKugFOcyPMUpNGAiLmEHd:
    return
  if 'wavve' in WsRekqlVYvKugFOcyPMUpNGAiLmEfa:
   (WsRekqlVYvKugFOcyPMUpNGAiLmEHC,WsRekqlVYvKugFOcyPMUpNGAiLmEHr)=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Search_Wavve(WsRekqlVYvKugFOcyPMUpNGAiLmEHd,'TVSHOW',1)
   if WsRekqlVYvKugFOcyPMUpNGAiLmETh(WsRekqlVYvKugFOcyPMUpNGAiLmEHC)>0:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHB={'sType':'wavve_tvshow','sList':WsRekqlVYvKugFOcyPMUpNGAiLmEfn.MakeText_FreeList(WsRekqlVYvKugFOcyPMUpNGAiLmEHC),}
    WsRekqlVYvKugFOcyPMUpNGAiLmEHa.append(WsRekqlVYvKugFOcyPMUpNGAiLmEHB)
   (WsRekqlVYvKugFOcyPMUpNGAiLmEHC,WsRekqlVYvKugFOcyPMUpNGAiLmEHr)=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Search_Wavve(WsRekqlVYvKugFOcyPMUpNGAiLmEHd,'MOVIE',1)
   if WsRekqlVYvKugFOcyPMUpNGAiLmETh(WsRekqlVYvKugFOcyPMUpNGAiLmEHC)>0:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHB={'sType':'wavve_movie','sList':WsRekqlVYvKugFOcyPMUpNGAiLmEfn.MakeText_FreeList(WsRekqlVYvKugFOcyPMUpNGAiLmEHC),}
    WsRekqlVYvKugFOcyPMUpNGAiLmEHa.append(WsRekqlVYvKugFOcyPMUpNGAiLmEHB)
  if 'tving' in WsRekqlVYvKugFOcyPMUpNGAiLmEfa:
   (WsRekqlVYvKugFOcyPMUpNGAiLmEHC,WsRekqlVYvKugFOcyPMUpNGAiLmEHr)=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Search_Tving(WsRekqlVYvKugFOcyPMUpNGAiLmEHd,'TVSHOW',1)
   if WsRekqlVYvKugFOcyPMUpNGAiLmETh(WsRekqlVYvKugFOcyPMUpNGAiLmEHC)>0:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHB={'sType':'tving_tvshow','sList':WsRekqlVYvKugFOcyPMUpNGAiLmEfn.MakeText_FreeList(WsRekqlVYvKugFOcyPMUpNGAiLmEHC),}
    WsRekqlVYvKugFOcyPMUpNGAiLmEHa.append(WsRekqlVYvKugFOcyPMUpNGAiLmEHB)
   (WsRekqlVYvKugFOcyPMUpNGAiLmEHC,WsRekqlVYvKugFOcyPMUpNGAiLmEHr)=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Search_Tving(WsRekqlVYvKugFOcyPMUpNGAiLmEHd,'MOVIE',1)
   if WsRekqlVYvKugFOcyPMUpNGAiLmETh(WsRekqlVYvKugFOcyPMUpNGAiLmEHC)>0:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHB={'sType':'tving_movie','sList':WsRekqlVYvKugFOcyPMUpNGAiLmEfn.MakeText_FreeList(WsRekqlVYvKugFOcyPMUpNGAiLmEHC),}
    WsRekqlVYvKugFOcyPMUpNGAiLmEHa.append(WsRekqlVYvKugFOcyPMUpNGAiLmEHB)
  if 'watcha' in WsRekqlVYvKugFOcyPMUpNGAiLmEfa:
   (WsRekqlVYvKugFOcyPMUpNGAiLmEHC,WsRekqlVYvKugFOcyPMUpNGAiLmEHr)=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Search_Watcha(WsRekqlVYvKugFOcyPMUpNGAiLmEHd,1)
   if WsRekqlVYvKugFOcyPMUpNGAiLmETh(WsRekqlVYvKugFOcyPMUpNGAiLmEHC)>0:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHB={'sType':'watcha_list','sList':WsRekqlVYvKugFOcyPMUpNGAiLmEfn.MakeText_FreeList(WsRekqlVYvKugFOcyPMUpNGAiLmEHC),}
    WsRekqlVYvKugFOcyPMUpNGAiLmEHa.append(WsRekqlVYvKugFOcyPMUpNGAiLmEHB)
  if 'coupang' in WsRekqlVYvKugFOcyPMUpNGAiLmEfa:
   (WsRekqlVYvKugFOcyPMUpNGAiLmEHC,WsRekqlVYvKugFOcyPMUpNGAiLmEHr)=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Search_Coupang(WsRekqlVYvKugFOcyPMUpNGAiLmEHd,1)
   if WsRekqlVYvKugFOcyPMUpNGAiLmETh(WsRekqlVYvKugFOcyPMUpNGAiLmEHC)>0:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHB={'sType':'coupang_list','sList':WsRekqlVYvKugFOcyPMUpNGAiLmEfn.MakeText_FreeList(WsRekqlVYvKugFOcyPMUpNGAiLmEHC),}
    WsRekqlVYvKugFOcyPMUpNGAiLmEHa.append(WsRekqlVYvKugFOcyPMUpNGAiLmEHB)
  if 'netflix' in WsRekqlVYvKugFOcyPMUpNGAiLmEfa:
   try:
    (WsRekqlVYvKugFOcyPMUpNGAiLmEHC,WsRekqlVYvKugFOcyPMUpNGAiLmEHr,WsRekqlVYvKugFOcyPMUpNGAiLmEHh)=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Search_Netflix(WsRekqlVYvKugFOcyPMUpNGAiLmEHd,1)
   except:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHC=[]
    WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_noti(__language__(30919).encode('utf8'))
   if WsRekqlVYvKugFOcyPMUpNGAiLmETh(WsRekqlVYvKugFOcyPMUpNGAiLmEHC)>0:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHB={'sType':'netflix_list','sList':WsRekqlVYvKugFOcyPMUpNGAiLmEfn.MakeText_FreeList(WsRekqlVYvKugFOcyPMUpNGAiLmEHC),}
    WsRekqlVYvKugFOcyPMUpNGAiLmEHa.append(WsRekqlVYvKugFOcyPMUpNGAiLmEHB)
  if 'amazon' in WsRekqlVYvKugFOcyPMUpNGAiLmEfa:
   (WsRekqlVYvKugFOcyPMUpNGAiLmEHC)=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Search_Primev(WsRekqlVYvKugFOcyPMUpNGAiLmEHd)
   if WsRekqlVYvKugFOcyPMUpNGAiLmETh(WsRekqlVYvKugFOcyPMUpNGAiLmEHC)>0:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHB={'sType':'primev_list','sList':WsRekqlVYvKugFOcyPMUpNGAiLmEfn.MakeText_FreeList(WsRekqlVYvKugFOcyPMUpNGAiLmEHC),}
    WsRekqlVYvKugFOcyPMUpNGAiLmEHa.append(WsRekqlVYvKugFOcyPMUpNGAiLmEHB)
  if 'disney' in WsRekqlVYvKugFOcyPMUpNGAiLmEfa:
   try:
    (WsRekqlVYvKugFOcyPMUpNGAiLmEHC)=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Search_Disney(WsRekqlVYvKugFOcyPMUpNGAiLmEHd)
   except:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHC=[]
    WsRekqlVYvKugFOcyPMUpNGAiLmEfn.addon_noti(__language__(30921).encode('utf8'))
   if WsRekqlVYvKugFOcyPMUpNGAiLmETh(WsRekqlVYvKugFOcyPMUpNGAiLmEHC)>0:
    WsRekqlVYvKugFOcyPMUpNGAiLmEHB={'sType':'disney_list','sList':WsRekqlVYvKugFOcyPMUpNGAiLmEfn.MakeText_FreeList(WsRekqlVYvKugFOcyPMUpNGAiLmEHC),}
    WsRekqlVYvKugFOcyPMUpNGAiLmEHa.append(WsRekqlVYvKugFOcyPMUpNGAiLmEHB)
  for WsRekqlVYvKugFOcyPMUpNGAiLmEHb in WsRekqlVYvKugFOcyPMUpNGAiLmEHa:
   WsRekqlVYvKugFOcyPMUpNGAiLmEjf=WsRekqlVYvKugFOcyPMUpNGAiLmEfj[WsRekqlVYvKugFOcyPMUpNGAiLmEHb.get('sType')]
   WsRekqlVYvKugFOcyPMUpNGAiLmEjz={'plot':'검색어 : '+WsRekqlVYvKugFOcyPMUpNGAiLmEHd+'\n\n'+WsRekqlVYvKugFOcyPMUpNGAiLmEHb.get('sList')}
   WsRekqlVYvKugFOcyPMUpNGAiLmEfB=WsRekqlVYvKugFOcyPMUpNGAiLmEjf.get('title')
   WsRekqlVYvKugFOcyPMUpNGAiLmEfC={'mode':WsRekqlVYvKugFOcyPMUpNGAiLmEjf.get('mode'),'ott':WsRekqlVYvKugFOcyPMUpNGAiLmEjf.get('ott'),'vidtype':WsRekqlVYvKugFOcyPMUpNGAiLmEjf.get('vidtype'),'search_key':WsRekqlVYvKugFOcyPMUpNGAiLmEHd}
   if WsRekqlVYvKugFOcyPMUpNGAiLmEjf.get('ott')=='netflix':
    WsRekqlVYvKugFOcyPMUpNGAiLmEjH=''
    WsRekqlVYvKugFOcyPMUpNGAiLmEfC['page'] ='1'
    WsRekqlVYvKugFOcyPMUpNGAiLmEfC['byReference']='-'
   else:
    WsRekqlVYvKugFOcyPMUpNGAiLmEjH=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.make_Hyper_Link(WsRekqlVYvKugFOcyPMUpNGAiLmEfC)
   WsRekqlVYvKugFOcyPMUpNGAiLmEzr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',WsRekqlVYvKugFOcyPMUpNGAiLmEjf.get('icon'))
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.add_dir(WsRekqlVYvKugFOcyPMUpNGAiLmEfB,sublabel='',img=WsRekqlVYvKugFOcyPMUpNGAiLmEzr,infoLabels=WsRekqlVYvKugFOcyPMUpNGAiLmEjz,isFolder=WsRekqlVYvKugFOcyPMUpNGAiLmETa,params=WsRekqlVYvKugFOcyPMUpNGAiLmEfC,isLink=WsRekqlVYvKugFOcyPMUpNGAiLmETd,direct_url=WsRekqlVYvKugFOcyPMUpNGAiLmEjH)
  xbmcplugin.endOfDirectory(WsRekqlVYvKugFOcyPMUpNGAiLmEfn._addon_handle)
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.Save_Searched_List(WsRekqlVYvKugFOcyPMUpNGAiLmEHd)
 def make_Hyper_Link(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,args):
  WsRekqlVYvKugFOcyPMUpNGAiLmEjT =args.get('ott')
  WsRekqlVYvKugFOcyPMUpNGAiLmEjS =args.get('vidtype')
  WsRekqlVYvKugFOcyPMUpNGAiLmEHd=args.get('search_key')
  WsRekqlVYvKugFOcyPMUpNGAiLmEjH='-'
  if WsRekqlVYvKugFOcyPMUpNGAiLmEjT=='wavve':
   WsRekqlVYvKugFOcyPMUpNGAiLmEjn={'mode':'LOCAL_SEARCH','sType':'movie' if WsRekqlVYvKugFOcyPMUpNGAiLmEjS=='MOVIE' else 'vod','search_key':WsRekqlVYvKugFOcyPMUpNGAiLmEHd,'page':'1',}
   WsRekqlVYvKugFOcyPMUpNGAiLmEjt=urllib.parse.urlencode(WsRekqlVYvKugFOcyPMUpNGAiLmEjn)
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH='plugin://plugin.video.wavvem/?'
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH+=WsRekqlVYvKugFOcyPMUpNGAiLmEjt
  elif WsRekqlVYvKugFOcyPMUpNGAiLmEjT=='tving':
   WsRekqlVYvKugFOcyPMUpNGAiLmEjn={'mode':'LOCAL_SEARCH','stype':'movie' if WsRekqlVYvKugFOcyPMUpNGAiLmEjS=='MOVIE' else 'vod','search_key':WsRekqlVYvKugFOcyPMUpNGAiLmEHd,'page':'1',}
   WsRekqlVYvKugFOcyPMUpNGAiLmEjt=urllib.parse.urlencode(WsRekqlVYvKugFOcyPMUpNGAiLmEjn)
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH='plugin://plugin.video.tvingm/?'
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH+=WsRekqlVYvKugFOcyPMUpNGAiLmEjt
  elif WsRekqlVYvKugFOcyPMUpNGAiLmEjT=='watcha':
   WsRekqlVYvKugFOcyPMUpNGAiLmEjn={'mode':'LOCAL_SEARCH','search_key':WsRekqlVYvKugFOcyPMUpNGAiLmEHd,'page':'1',}
   WsRekqlVYvKugFOcyPMUpNGAiLmEjt=urllib.parse.urlencode(WsRekqlVYvKugFOcyPMUpNGAiLmEjn)
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH='plugin://plugin.video.watcham/?'
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH+=WsRekqlVYvKugFOcyPMUpNGAiLmEjt
  elif WsRekqlVYvKugFOcyPMUpNGAiLmEjT=='coupang':
   WsRekqlVYvKugFOcyPMUpNGAiLmEjn={'mode':'LOCAL_SEARCH','search_key':WsRekqlVYvKugFOcyPMUpNGAiLmEHd,'page':'1',}
   WsRekqlVYvKugFOcyPMUpNGAiLmEjt=urllib.parse.urlencode(WsRekqlVYvKugFOcyPMUpNGAiLmEjn)
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH='plugin://plugin.video.coupangm/?'
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH+=WsRekqlVYvKugFOcyPMUpNGAiLmEjt
  elif WsRekqlVYvKugFOcyPMUpNGAiLmEjT=='netflix':
   WsRekqlVYvKugFOcyPMUpNGAiLmEjo=args.get('videoid')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjx=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.NF['SESSION']['nowGuid']
   if WsRekqlVYvKugFOcyPMUpNGAiLmEjS=='TVSHOW':
    WsRekqlVYvKugFOcyPMUpNGAiLmEjH='plugin://plugin.video.netflix/directory/show/%s/'%(WsRekqlVYvKugFOcyPMUpNGAiLmEjo)
   else:
    WsRekqlVYvKugFOcyPMUpNGAiLmEjH='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(WsRekqlVYvKugFOcyPMUpNGAiLmEjo,WsRekqlVYvKugFOcyPMUpNGAiLmEjx)
  elif WsRekqlVYvKugFOcyPMUpNGAiLmEjT=='amazon':
   WsRekqlVYvKugFOcyPMUpNGAiLmEjn={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':WsRekqlVYvKugFOcyPMUpNGAiLmEHd,}}
   WsRekqlVYvKugFOcyPMUpNGAiLmEjt=json.dumps(WsRekqlVYvKugFOcyPMUpNGAiLmEjn,separators=(',',':'))
   WsRekqlVYvKugFOcyPMUpNGAiLmEjt=base64.standard_b64encode(WsRekqlVYvKugFOcyPMUpNGAiLmEjt.encode()).decode('utf-8')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjt=WsRekqlVYvKugFOcyPMUpNGAiLmEjt.replace('+','%2B')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH='plugin://plugin.video.primevm/?params='
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH+=WsRekqlVYvKugFOcyPMUpNGAiLmEjt
  elif WsRekqlVYvKugFOcyPMUpNGAiLmEjT=='disney':
   WsRekqlVYvKugFOcyPMUpNGAiLmEjn={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':WsRekqlVYvKugFOcyPMUpNGAiLmEHd,}}
   WsRekqlVYvKugFOcyPMUpNGAiLmEjt=json.dumps(WsRekqlVYvKugFOcyPMUpNGAiLmEjn,separators=(',',':'))
   WsRekqlVYvKugFOcyPMUpNGAiLmEjt=base64.standard_b64encode(WsRekqlVYvKugFOcyPMUpNGAiLmEjt.encode()).decode('utf-8')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjt=WsRekqlVYvKugFOcyPMUpNGAiLmEjt.replace('+','%2B')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH='plugin://plugin.video.disneym/?params='
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH+=WsRekqlVYvKugFOcyPMUpNGAiLmEjt
  return WsRekqlVYvKugFOcyPMUpNGAiLmEjH
 def dp_Nf_Search(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,args):
  WsRekqlVYvKugFOcyPMUpNGAiLmEjD =WsRekqlVYvKugFOcyPMUpNGAiLmESf(args.get('page'))
  WsRekqlVYvKugFOcyPMUpNGAiLmEHd =args.get('search_key')
  WsRekqlVYvKugFOcyPMUpNGAiLmEHh=args.get('byReference')
  (WsRekqlVYvKugFOcyPMUpNGAiLmEHC,WsRekqlVYvKugFOcyPMUpNGAiLmEHr,WsRekqlVYvKugFOcyPMUpNGAiLmEHh)=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.SearchObj.Get_Search_Netflix(WsRekqlVYvKugFOcyPMUpNGAiLmEHd,WsRekqlVYvKugFOcyPMUpNGAiLmEjD,byReference=WsRekqlVYvKugFOcyPMUpNGAiLmEHh)
  for WsRekqlVYvKugFOcyPMUpNGAiLmEjX in WsRekqlVYvKugFOcyPMUpNGAiLmEHC:
   WsRekqlVYvKugFOcyPMUpNGAiLmEjo =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('videoid')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjS =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('vidtype')
   WsRekqlVYvKugFOcyPMUpNGAiLmEfB =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('title')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjJ =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('mpaa')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjw =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('regularSynopsis')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjQ =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('dpSupplemental')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjI=WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('sequiturEvidence')
   WsRekqlVYvKugFOcyPMUpNGAiLmEja =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('thumbnail')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjd =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('year')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjC =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('duration')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjr =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('info_genre')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjB =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('director')
   WsRekqlVYvKugFOcyPMUpNGAiLmEjh =WsRekqlVYvKugFOcyPMUpNGAiLmEjX.get('cast')
   if WsRekqlVYvKugFOcyPMUpNGAiLmEjS=='movie':
    WsRekqlVYvKugFOcyPMUpNGAiLmEzd=' (%s)'%(WsRekqlVYvKugFOcyPMUpNGAiLmESH(WsRekqlVYvKugFOcyPMUpNGAiLmEjd))
   else:
    WsRekqlVYvKugFOcyPMUpNGAiLmEzd=''
   WsRekqlVYvKugFOcyPMUpNGAiLmEjb=''
   if WsRekqlVYvKugFOcyPMUpNGAiLmEjw:WsRekqlVYvKugFOcyPMUpNGAiLmEjb=WsRekqlVYvKugFOcyPMUpNGAiLmEjb+'\n\n'+WsRekqlVYvKugFOcyPMUpNGAiLmEjw
   if WsRekqlVYvKugFOcyPMUpNGAiLmEjQ :WsRekqlVYvKugFOcyPMUpNGAiLmEjb=WsRekqlVYvKugFOcyPMUpNGAiLmEjb+'\n\n'+WsRekqlVYvKugFOcyPMUpNGAiLmEjQ
   if WsRekqlVYvKugFOcyPMUpNGAiLmEjI:WsRekqlVYvKugFOcyPMUpNGAiLmEjb=WsRekqlVYvKugFOcyPMUpNGAiLmEjb+'\n\n'+WsRekqlVYvKugFOcyPMUpNGAiLmEjI
   WsRekqlVYvKugFOcyPMUpNGAiLmEjb=WsRekqlVYvKugFOcyPMUpNGAiLmEjb.strip()
   WsRekqlVYvKugFOcyPMUpNGAiLmEzC={'mediatype':'tvshow' if WsRekqlVYvKugFOcyPMUpNGAiLmEjS=='show' else 'movie','title':WsRekqlVYvKugFOcyPMUpNGAiLmEfB,'mpaa':WsRekqlVYvKugFOcyPMUpNGAiLmEjJ,'plot':WsRekqlVYvKugFOcyPMUpNGAiLmEjb,'duration':WsRekqlVYvKugFOcyPMUpNGAiLmEjC,'genre':WsRekqlVYvKugFOcyPMUpNGAiLmEjr,'director':WsRekqlVYvKugFOcyPMUpNGAiLmEjB,'cast':WsRekqlVYvKugFOcyPMUpNGAiLmEjh,'year':WsRekqlVYvKugFOcyPMUpNGAiLmEjd,}
   WsRekqlVYvKugFOcyPMUpNGAiLmEfC={'ott':'netflix','vidtype':'TVSHOW' if WsRekqlVYvKugFOcyPMUpNGAiLmEjS=='show' else 'MOVIE','videoid':WsRekqlVYvKugFOcyPMUpNGAiLmEjo,}
   WsRekqlVYvKugFOcyPMUpNGAiLmEjH=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.make_Hyper_Link(WsRekqlVYvKugFOcyPMUpNGAiLmEfC)
   WsRekqlVYvKugFOcyPMUpNGAiLmEHj=WsRekqlVYvKugFOcyPMUpNGAiLmETa if WsRekqlVYvKugFOcyPMUpNGAiLmEjS=='show' else WsRekqlVYvKugFOcyPMUpNGAiLmETd
   if WsRekqlVYvKugFOcyPMUpNGAiLmEfn.get_settings_makebookmark():
    WsRekqlVYvKugFOcyPMUpNGAiLmETf={'mode':'SET_BOOKMARK','values':{'videoid':WsRekqlVYvKugFOcyPMUpNGAiLmEjo,'vidtype':'tvshow' if WsRekqlVYvKugFOcyPMUpNGAiLmEjS=='show' else 'movie','vtitle':WsRekqlVYvKugFOcyPMUpNGAiLmEfB+WsRekqlVYvKugFOcyPMUpNGAiLmEzd,'vsubtitle':'','vinfo':WsRekqlVYvKugFOcyPMUpNGAiLmEzC,'thumbnail':WsRekqlVYvKugFOcyPMUpNGAiLmEja,}}
    WsRekqlVYvKugFOcyPMUpNGAiLmETz=json.dumps(WsRekqlVYvKugFOcyPMUpNGAiLmETf,separators=(',',':'))
    WsRekqlVYvKugFOcyPMUpNGAiLmETz=base64.standard_b64encode(WsRekqlVYvKugFOcyPMUpNGAiLmETz.encode()).decode('utf-8')
    WsRekqlVYvKugFOcyPMUpNGAiLmETz=WsRekqlVYvKugFOcyPMUpNGAiLmETz.replace('+','%2B')
    WsRekqlVYvKugFOcyPMUpNGAiLmETH='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(WsRekqlVYvKugFOcyPMUpNGAiLmETz)
    WsRekqlVYvKugFOcyPMUpNGAiLmEza=[('(통합) 찜 영상에 추가',WsRekqlVYvKugFOcyPMUpNGAiLmETH)]
   else:
    WsRekqlVYvKugFOcyPMUpNGAiLmEza=WsRekqlVYvKugFOcyPMUpNGAiLmETI
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.add_dir(WsRekqlVYvKugFOcyPMUpNGAiLmEfB+WsRekqlVYvKugFOcyPMUpNGAiLmEzd,sublabel=WsRekqlVYvKugFOcyPMUpNGAiLmETI,img=WsRekqlVYvKugFOcyPMUpNGAiLmEja,infoLabels=WsRekqlVYvKugFOcyPMUpNGAiLmEzC,isFolder=WsRekqlVYvKugFOcyPMUpNGAiLmEHj,params=WsRekqlVYvKugFOcyPMUpNGAiLmEfC,isLink=WsRekqlVYvKugFOcyPMUpNGAiLmETd,ContextMenu=WsRekqlVYvKugFOcyPMUpNGAiLmEza,direct_url=WsRekqlVYvKugFOcyPMUpNGAiLmEjH)
  if WsRekqlVYvKugFOcyPMUpNGAiLmEHr:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfC={}
   WsRekqlVYvKugFOcyPMUpNGAiLmEfC['mode'] ='NF_SEARCH' 
   WsRekqlVYvKugFOcyPMUpNGAiLmEfC['page'] =WsRekqlVYvKugFOcyPMUpNGAiLmESH(WsRekqlVYvKugFOcyPMUpNGAiLmEjD+1)
   WsRekqlVYvKugFOcyPMUpNGAiLmEfC['search_key']=WsRekqlVYvKugFOcyPMUpNGAiLmEHd
   WsRekqlVYvKugFOcyPMUpNGAiLmEfC['byReference']=WsRekqlVYvKugFOcyPMUpNGAiLmEHh
   WsRekqlVYvKugFOcyPMUpNGAiLmEfB='[B]%s >>[/B]'%'다음 페이지'
   WsRekqlVYvKugFOcyPMUpNGAiLmETj=WsRekqlVYvKugFOcyPMUpNGAiLmESH(WsRekqlVYvKugFOcyPMUpNGAiLmEjD+1)
   WsRekqlVYvKugFOcyPMUpNGAiLmEzr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.add_dir(WsRekqlVYvKugFOcyPMUpNGAiLmEfB,sublabel=WsRekqlVYvKugFOcyPMUpNGAiLmETj,img=WsRekqlVYvKugFOcyPMUpNGAiLmEzr,infoLabels=WsRekqlVYvKugFOcyPMUpNGAiLmETI,isFolder=WsRekqlVYvKugFOcyPMUpNGAiLmETa,params=WsRekqlVYvKugFOcyPMUpNGAiLmEfC)
  xbmcplugin.setContent(WsRekqlVYvKugFOcyPMUpNGAiLmEfn._addon_handle,'movies')
  xbmcplugin.endOfDirectory(WsRekqlVYvKugFOcyPMUpNGAiLmEfn._addon_handle)
 def dp_Bookmark_Menu(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,args):
  WsRekqlVYvKugFOcyPMUpNGAiLmETS='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(WsRekqlVYvKugFOcyPMUpNGAiLmETS)
 def dp_Set_Bookmark(WsRekqlVYvKugFOcyPMUpNGAiLmEfn,args):
  WsRekqlVYvKugFOcyPMUpNGAiLmEjo =args.get('videoid')
  WsRekqlVYvKugFOcyPMUpNGAiLmEjS =args.get('vidtype')
  WsRekqlVYvKugFOcyPMUpNGAiLmETn =args.get('vtitle')
  WsRekqlVYvKugFOcyPMUpNGAiLmETt =args.get('vsubtitle')
  WsRekqlVYvKugFOcyPMUpNGAiLmETo =args.get('vinfo')
  WsRekqlVYvKugFOcyPMUpNGAiLmEja =args.get('thumbnail')
  WsRekqlVYvKugFOcyPMUpNGAiLmEfX=xbmcgui.Dialog()
  WsRekqlVYvKugFOcyPMUpNGAiLmEHf=WsRekqlVYvKugFOcyPMUpNGAiLmEfX.yesno(__language__(30917).encode('utf8'),WsRekqlVYvKugFOcyPMUpNGAiLmETn+' \n\n'+__language__(30918))
  if WsRekqlVYvKugFOcyPMUpNGAiLmEHf==WsRekqlVYvKugFOcyPMUpNGAiLmETd:return
  WsRekqlVYvKugFOcyPMUpNGAiLmETx={'indexinfo':{'ott':'netflix','videoid':WsRekqlVYvKugFOcyPMUpNGAiLmEjo,'vidtype':WsRekqlVYvKugFOcyPMUpNGAiLmEjS,},'saveinfo':{'title':WsRekqlVYvKugFOcyPMUpNGAiLmETn,'subtitle':WsRekqlVYvKugFOcyPMUpNGAiLmETt,'thumbnail':WsRekqlVYvKugFOcyPMUpNGAiLmEja,'infoLabels':WsRekqlVYvKugFOcyPMUpNGAiLmETo,},}
  WsRekqlVYvKugFOcyPMUpNGAiLmEfC={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':WsRekqlVYvKugFOcyPMUpNGAiLmETx,}}
  WsRekqlVYvKugFOcyPMUpNGAiLmEfr=json.dumps(WsRekqlVYvKugFOcyPMUpNGAiLmEfC,separators=(',',':'))
  WsRekqlVYvKugFOcyPMUpNGAiLmEfr=base64.standard_b64encode(WsRekqlVYvKugFOcyPMUpNGAiLmEfr.encode()).decode('utf-8')
  WsRekqlVYvKugFOcyPMUpNGAiLmEfr=WsRekqlVYvKugFOcyPMUpNGAiLmEfr.replace('+','%2B')
  WsRekqlVYvKugFOcyPMUpNGAiLmETH='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(WsRekqlVYvKugFOcyPMUpNGAiLmEfr)
  xbmc.executebuiltin(WsRekqlVYvKugFOcyPMUpNGAiLmETH)
 def search_main(WsRekqlVYvKugFOcyPMUpNGAiLmEfn):
  WsRekqlVYvKugFOcyPMUpNGAiLmETD=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.main_params.get('params')
  if WsRekqlVYvKugFOcyPMUpNGAiLmETD:
   WsRekqlVYvKugFOcyPMUpNGAiLmETX =base64.standard_b64decode(WsRekqlVYvKugFOcyPMUpNGAiLmETD).decode('utf-8')
   WsRekqlVYvKugFOcyPMUpNGAiLmETX =json.loads(WsRekqlVYvKugFOcyPMUpNGAiLmETX)
   WsRekqlVYvKugFOcyPMUpNGAiLmETJ =WsRekqlVYvKugFOcyPMUpNGAiLmETX.get('mode')
   WsRekqlVYvKugFOcyPMUpNGAiLmETw =WsRekqlVYvKugFOcyPMUpNGAiLmETX.get('values')
  else:
   WsRekqlVYvKugFOcyPMUpNGAiLmETJ=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.main_params.get('mode',WsRekqlVYvKugFOcyPMUpNGAiLmETI)
   WsRekqlVYvKugFOcyPMUpNGAiLmETw=WsRekqlVYvKugFOcyPMUpNGAiLmEfn.main_params
  if WsRekqlVYvKugFOcyPMUpNGAiLmETJ=='NFLOGOUT':
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.NF_logout()
   return
  elif WsRekqlVYvKugFOcyPMUpNGAiLmETJ=='NFLOGIN':
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.NF_login(showMessage=WsRekqlVYvKugFOcyPMUpNGAiLmETa)
   return
  WsRekqlVYvKugFOcyPMUpNGAiLmEfn.option_check()
  if WsRekqlVYvKugFOcyPMUpNGAiLmETJ is WsRekqlVYvKugFOcyPMUpNGAiLmETI:
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.dp_Main_List()
  elif WsRekqlVYvKugFOcyPMUpNGAiLmETJ=='TOTAL_SEARCH':
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.dp_Search_Group(WsRekqlVYvKugFOcyPMUpNGAiLmETw)
  elif WsRekqlVYvKugFOcyPMUpNGAiLmETJ=='NF_SEARCH':
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.dp_Nf_Search(WsRekqlVYvKugFOcyPMUpNGAiLmETw)
  elif WsRekqlVYvKugFOcyPMUpNGAiLmETJ=='TOTAL_HISTORY':
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.dp_Search_History(WsRekqlVYvKugFOcyPMUpNGAiLmETw)
  elif WsRekqlVYvKugFOcyPMUpNGAiLmETJ=='HISTORY_REMOVE':
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.dp_History_Delete(WsRekqlVYvKugFOcyPMUpNGAiLmETw)
  elif WsRekqlVYvKugFOcyPMUpNGAiLmETJ=='MENU_BOOKMARK':
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.dp_Bookmark_Menu(WsRekqlVYvKugFOcyPMUpNGAiLmETw)
  elif WsRekqlVYvKugFOcyPMUpNGAiLmETJ=='SET_BOOKMARK':
   WsRekqlVYvKugFOcyPMUpNGAiLmEfn.dp_Set_Bookmark(WsRekqlVYvKugFOcyPMUpNGAiLmETw)
  else:
   WsRekqlVYvKugFOcyPMUpNGAiLmETI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
