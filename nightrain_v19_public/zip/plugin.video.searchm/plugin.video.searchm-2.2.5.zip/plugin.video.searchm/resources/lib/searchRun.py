__author__="NightRain"
LieskvglVaCJjxHXEGtrzYhUqFpbco=object
LieskvglVaCJjxHXEGtrzYhUqFpbcS=None
LieskvglVaCJjxHXEGtrzYhUqFpbcR=True
LieskvglVaCJjxHXEGtrzYhUqFpbcw=False
LieskvglVaCJjxHXEGtrzYhUqFpbcd=type
LieskvglVaCJjxHXEGtrzYhUqFpbcP=dict
LieskvglVaCJjxHXEGtrzYhUqFpbcK=open
LieskvglVaCJjxHXEGtrzYhUqFpbcQ=len
LieskvglVaCJjxHXEGtrzYhUqFpbcA=Exception
LieskvglVaCJjxHXEGtrzYhUqFpbMD=int
LieskvglVaCJjxHXEGtrzYhUqFpbMI=range
LieskvglVaCJjxHXEGtrzYhUqFpbMm=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
LieskvglVaCJjxHXEGtrzYhUqFpbDm=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
LieskvglVaCJjxHXEGtrzYhUqFpbDT={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
LieskvglVaCJjxHXEGtrzYhUqFpbDc=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
LieskvglVaCJjxHXEGtrzYhUqFpbDM =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class LieskvglVaCJjxHXEGtrzYhUqFpbDI(LieskvglVaCJjxHXEGtrzYhUqFpbco):
 def __init__(LieskvglVaCJjxHXEGtrzYhUqFpbDN,LieskvglVaCJjxHXEGtrzYhUqFpbDy,LieskvglVaCJjxHXEGtrzYhUqFpbDf,LieskvglVaCJjxHXEGtrzYhUqFpbDn):
  LieskvglVaCJjxHXEGtrzYhUqFpbDN._addon_url =LieskvglVaCJjxHXEGtrzYhUqFpbDy
  LieskvglVaCJjxHXEGtrzYhUqFpbDN._addon_handle=LieskvglVaCJjxHXEGtrzYhUqFpbDf
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.main_params =LieskvglVaCJjxHXEGtrzYhUqFpbDn
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj =QNqBHzxTJnjpuWeOgIXblPKkrwiYoh() 
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_authinfo.json'))
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(LieskvglVaCJjxHXEGtrzYhUqFpbDN,sting):
  try:
   LieskvglVaCJjxHXEGtrzYhUqFpbDW=xbmcgui.Dialog()
   LieskvglVaCJjxHXEGtrzYhUqFpbDW.notification(__addonname__,sting)
  except:
   LieskvglVaCJjxHXEGtrzYhUqFpbcS
 def addon_log(LieskvglVaCJjxHXEGtrzYhUqFpbDN,string):
  try:
   LieskvglVaCJjxHXEGtrzYhUqFpbDu=string.encode('utf-8','ignore')
  except:
   LieskvglVaCJjxHXEGtrzYhUqFpbDu='addonException: addon_log'
  LieskvglVaCJjxHXEGtrzYhUqFpbDO=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,LieskvglVaCJjxHXEGtrzYhUqFpbDu),level=LieskvglVaCJjxHXEGtrzYhUqFpbDO)
 def get_keyboard_input(LieskvglVaCJjxHXEGtrzYhUqFpbDN,LieskvglVaCJjxHXEGtrzYhUqFpbDK):
  LieskvglVaCJjxHXEGtrzYhUqFpbDo=LieskvglVaCJjxHXEGtrzYhUqFpbcS
  kb=xbmc.Keyboard()
  kb.setHeading(LieskvglVaCJjxHXEGtrzYhUqFpbDK)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   LieskvglVaCJjxHXEGtrzYhUqFpbDo=kb.getText()
  return LieskvglVaCJjxHXEGtrzYhUqFpbDo
 def get_settings_menubookmark(LieskvglVaCJjxHXEGtrzYhUqFpbDN):
  LieskvglVaCJjxHXEGtrzYhUqFpbDS=LieskvglVaCJjxHXEGtrzYhUqFpbcR if __addon__.getSetting('menu_bookmark')=='true' else LieskvglVaCJjxHXEGtrzYhUqFpbcw
  return(LieskvglVaCJjxHXEGtrzYhUqFpbDS)
 def get_settings_makebookmark(LieskvglVaCJjxHXEGtrzYhUqFpbDN):
  return LieskvglVaCJjxHXEGtrzYhUqFpbcR if __addon__.getSetting('make_bookmark')=='true' else LieskvglVaCJjxHXEGtrzYhUqFpbcw
 def get_settings_select_info(LieskvglVaCJjxHXEGtrzYhUqFpbDN):
  LieskvglVaCJjxHXEGtrzYhUqFpbDR=[]
  if __addon__.getSetting('netflixyn')=='true':LieskvglVaCJjxHXEGtrzYhUqFpbDR.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':LieskvglVaCJjxHXEGtrzYhUqFpbDR.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':LieskvglVaCJjxHXEGtrzYhUqFpbDR.append('tving')
  if __addon__.getSetting('watchayn')=='true':LieskvglVaCJjxHXEGtrzYhUqFpbDR.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':LieskvglVaCJjxHXEGtrzYhUqFpbDR.append('coupang')
  if __addon__.getSetting('primevyn')=='true':LieskvglVaCJjxHXEGtrzYhUqFpbDR.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':LieskvglVaCJjxHXEGtrzYhUqFpbDR.append('disney')
  return LieskvglVaCJjxHXEGtrzYhUqFpbDR
 def add_dir(LieskvglVaCJjxHXEGtrzYhUqFpbDN,label,sublabel='',img='',infoLabels=LieskvglVaCJjxHXEGtrzYhUqFpbcS,isFolder=LieskvglVaCJjxHXEGtrzYhUqFpbcR,params='',isLink=LieskvglVaCJjxHXEGtrzYhUqFpbcw,ContextMenu=LieskvglVaCJjxHXEGtrzYhUqFpbcS,direct_url=LieskvglVaCJjxHXEGtrzYhUqFpbcS):
  if direct_url:
   LieskvglVaCJjxHXEGtrzYhUqFpbDw=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   LieskvglVaCJjxHXEGtrzYhUqFpbDP=json.dumps(params,separators=(',',':'))
   LieskvglVaCJjxHXEGtrzYhUqFpbDP=base64.standard_b64encode(LieskvglVaCJjxHXEGtrzYhUqFpbDP.encode()).decode('utf-8')
   LieskvglVaCJjxHXEGtrzYhUqFpbDP=LieskvglVaCJjxHXEGtrzYhUqFpbDP.replace('+','%2B')
   LieskvglVaCJjxHXEGtrzYhUqFpbDw='%s?params=%s'%(LieskvglVaCJjxHXEGtrzYhUqFpbDN._addon_url,LieskvglVaCJjxHXEGtrzYhUqFpbDP)
  if sublabel and sublabel!='-':LieskvglVaCJjxHXEGtrzYhUqFpbDK='%s < %s >'%(label,sublabel)
  else: LieskvglVaCJjxHXEGtrzYhUqFpbDK=label
  if not img:img='DefaultFolder.png'
  LieskvglVaCJjxHXEGtrzYhUqFpbDQ=xbmcgui.ListItem(LieskvglVaCJjxHXEGtrzYhUqFpbDK)
  if LieskvglVaCJjxHXEGtrzYhUqFpbcd(img)==LieskvglVaCJjxHXEGtrzYhUqFpbcP:
   LieskvglVaCJjxHXEGtrzYhUqFpbDQ.setArt(img)
  else:
   LieskvglVaCJjxHXEGtrzYhUqFpbDQ.setArt({'thumb':img,'poster':img})
  if infoLabels:LieskvglVaCJjxHXEGtrzYhUqFpbDQ.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   LieskvglVaCJjxHXEGtrzYhUqFpbDQ.setProperty('IsPlayable','true')
  if ContextMenu:LieskvglVaCJjxHXEGtrzYhUqFpbDQ.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(LieskvglVaCJjxHXEGtrzYhUqFpbDN._addon_handle,LieskvglVaCJjxHXEGtrzYhUqFpbDw,LieskvglVaCJjxHXEGtrzYhUqFpbDQ,isFolder)
 def Load_Searched_List(LieskvglVaCJjxHXEGtrzYhUqFpbDN):
  try:
   LieskvglVaCJjxHXEGtrzYhUqFpbDA=LieskvglVaCJjxHXEGtrzYhUqFpbDM
   fp=LieskvglVaCJjxHXEGtrzYhUqFpbcK(LieskvglVaCJjxHXEGtrzYhUqFpbDA,'r',-1,'utf-8')
   LieskvglVaCJjxHXEGtrzYhUqFpbID=fp.readlines()
   fp.close()
  except:
   LieskvglVaCJjxHXEGtrzYhUqFpbID=[]
  return LieskvglVaCJjxHXEGtrzYhUqFpbID
 def Save_Searched_List(LieskvglVaCJjxHXEGtrzYhUqFpbDN,LieskvglVaCJjxHXEGtrzYhUqFpbmw):
  try:
   LieskvglVaCJjxHXEGtrzYhUqFpbDA=LieskvglVaCJjxHXEGtrzYhUqFpbDM
   LieskvglVaCJjxHXEGtrzYhUqFpbIm=LieskvglVaCJjxHXEGtrzYhUqFpbDN.Load_Searched_List() 
   LieskvglVaCJjxHXEGtrzYhUqFpbIT={'skey':LieskvglVaCJjxHXEGtrzYhUqFpbmw.strip()}
   fp=LieskvglVaCJjxHXEGtrzYhUqFpbcK(LieskvglVaCJjxHXEGtrzYhUqFpbDA,'w',-1,'utf-8')
   LieskvglVaCJjxHXEGtrzYhUqFpbIc=urllib.parse.urlencode(LieskvglVaCJjxHXEGtrzYhUqFpbIT)
   LieskvglVaCJjxHXEGtrzYhUqFpbIc=LieskvglVaCJjxHXEGtrzYhUqFpbIc+'\n'
   fp.write(LieskvglVaCJjxHXEGtrzYhUqFpbIc)
   LieskvglVaCJjxHXEGtrzYhUqFpbIM=0
   for LieskvglVaCJjxHXEGtrzYhUqFpbIN in LieskvglVaCJjxHXEGtrzYhUqFpbIm:
    LieskvglVaCJjxHXEGtrzYhUqFpbIy=LieskvglVaCJjxHXEGtrzYhUqFpbcP(urllib.parse.parse_qsl(LieskvglVaCJjxHXEGtrzYhUqFpbIN))
    LieskvglVaCJjxHXEGtrzYhUqFpbIf=LieskvglVaCJjxHXEGtrzYhUqFpbIT.get('skey').strip()
    LieskvglVaCJjxHXEGtrzYhUqFpbIn=LieskvglVaCJjxHXEGtrzYhUqFpbIy.get('skey').strip()
    if LieskvglVaCJjxHXEGtrzYhUqFpbIf!=LieskvglVaCJjxHXEGtrzYhUqFpbIn:
     fp.write(LieskvglVaCJjxHXEGtrzYhUqFpbIN)
     LieskvglVaCJjxHXEGtrzYhUqFpbIM+=1
     if LieskvglVaCJjxHXEGtrzYhUqFpbIM>=50:break
   fp.close()
  except:
   LieskvglVaCJjxHXEGtrzYhUqFpbcS
 def dp_Search_History(LieskvglVaCJjxHXEGtrzYhUqFpbDN,args):
  LieskvglVaCJjxHXEGtrzYhUqFpbIB=LieskvglVaCJjxHXEGtrzYhUqFpbDN.Load_Searched_List()
  for LieskvglVaCJjxHXEGtrzYhUqFpbIW in LieskvglVaCJjxHXEGtrzYhUqFpbIB:
   LieskvglVaCJjxHXEGtrzYhUqFpbIu=LieskvglVaCJjxHXEGtrzYhUqFpbcP(urllib.parse.parse_qsl(LieskvglVaCJjxHXEGtrzYhUqFpbIW))
   LieskvglVaCJjxHXEGtrzYhUqFpbIO=LieskvglVaCJjxHXEGtrzYhUqFpbIu.get('skey').strip()
   LieskvglVaCJjxHXEGtrzYhUqFpbDd={'mode':'TOTAL_SEARCH','search_key':LieskvglVaCJjxHXEGtrzYhUqFpbIO,}
   LieskvglVaCJjxHXEGtrzYhUqFpbIo={'mode':'HISTORY_REMOVE','skey':LieskvglVaCJjxHXEGtrzYhUqFpbIO,'delmode':'ONE',}
   LieskvglVaCJjxHXEGtrzYhUqFpbIS=urllib.parse.urlencode(LieskvglVaCJjxHXEGtrzYhUqFpbIo)
   LieskvglVaCJjxHXEGtrzYhUqFpbIR=[('선택된 검색어 ( %s ) 삭제'%(LieskvglVaCJjxHXEGtrzYhUqFpbIO),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(LieskvglVaCJjxHXEGtrzYhUqFpbIS))]
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.add_dir(LieskvglVaCJjxHXEGtrzYhUqFpbIO,sublabel='',img=LieskvglVaCJjxHXEGtrzYhUqFpbcS,infoLabels=LieskvglVaCJjxHXEGtrzYhUqFpbcS,isFolder=LieskvglVaCJjxHXEGtrzYhUqFpbcR,params=LieskvglVaCJjxHXEGtrzYhUqFpbDd,ContextMenu=LieskvglVaCJjxHXEGtrzYhUqFpbIR)
  LieskvglVaCJjxHXEGtrzYhUqFpbId={'plot':'검색목록 전체를 삭제합니다.'}
  LieskvglVaCJjxHXEGtrzYhUqFpbDK='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  LieskvglVaCJjxHXEGtrzYhUqFpbDd={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  LieskvglVaCJjxHXEGtrzYhUqFpbIP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.add_dir(LieskvglVaCJjxHXEGtrzYhUqFpbDK,sublabel='',img=LieskvglVaCJjxHXEGtrzYhUqFpbIP,infoLabels=LieskvglVaCJjxHXEGtrzYhUqFpbId,isFolder=LieskvglVaCJjxHXEGtrzYhUqFpbcw,params=LieskvglVaCJjxHXEGtrzYhUqFpbDd,isLink=LieskvglVaCJjxHXEGtrzYhUqFpbcR)
  xbmcplugin.endOfDirectory(LieskvglVaCJjxHXEGtrzYhUqFpbDN._addon_handle,cacheToDisc=LieskvglVaCJjxHXEGtrzYhUqFpbcw)
 def Delete_History_List(LieskvglVaCJjxHXEGtrzYhUqFpbDN,LieskvglVaCJjxHXEGtrzYhUqFpbIO,LieskvglVaCJjxHXEGtrzYhUqFpbIA):
  if LieskvglVaCJjxHXEGtrzYhUqFpbIA=='ALL':
   try:
    LieskvglVaCJjxHXEGtrzYhUqFpbDA=LieskvglVaCJjxHXEGtrzYhUqFpbDM
    fp=LieskvglVaCJjxHXEGtrzYhUqFpbcK(LieskvglVaCJjxHXEGtrzYhUqFpbDA,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    LieskvglVaCJjxHXEGtrzYhUqFpbcS
  else:
   try:
    LieskvglVaCJjxHXEGtrzYhUqFpbDA=LieskvglVaCJjxHXEGtrzYhUqFpbDM
    LieskvglVaCJjxHXEGtrzYhUqFpbIm=LieskvglVaCJjxHXEGtrzYhUqFpbDN.Load_Searched_List() 
    fp=LieskvglVaCJjxHXEGtrzYhUqFpbcK(LieskvglVaCJjxHXEGtrzYhUqFpbDA,'w',-1,'utf-8')
    for LieskvglVaCJjxHXEGtrzYhUqFpbIN in LieskvglVaCJjxHXEGtrzYhUqFpbIm:
     LieskvglVaCJjxHXEGtrzYhUqFpbIy=LieskvglVaCJjxHXEGtrzYhUqFpbcP(urllib.parse.parse_qsl(LieskvglVaCJjxHXEGtrzYhUqFpbIN))
     LieskvglVaCJjxHXEGtrzYhUqFpbIQ=LieskvglVaCJjxHXEGtrzYhUqFpbIy.get('skey').strip()
     if LieskvglVaCJjxHXEGtrzYhUqFpbIO!=LieskvglVaCJjxHXEGtrzYhUqFpbIQ:
      fp.write(LieskvglVaCJjxHXEGtrzYhUqFpbIN)
    fp.close()
   except:
    LieskvglVaCJjxHXEGtrzYhUqFpbcS
 def dp_History_Delete(LieskvglVaCJjxHXEGtrzYhUqFpbDN,args):
  LieskvglVaCJjxHXEGtrzYhUqFpbIO =args.get('skey') 
  LieskvglVaCJjxHXEGtrzYhUqFpbIA=args.get('delmode')
  LieskvglVaCJjxHXEGtrzYhUqFpbDW=xbmcgui.Dialog()
  if LieskvglVaCJjxHXEGtrzYhUqFpbIA=='ALL':
   LieskvglVaCJjxHXEGtrzYhUqFpbmD=LieskvglVaCJjxHXEGtrzYhUqFpbDW.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   LieskvglVaCJjxHXEGtrzYhUqFpbmD=LieskvglVaCJjxHXEGtrzYhUqFpbDW.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if LieskvglVaCJjxHXEGtrzYhUqFpbmD==LieskvglVaCJjxHXEGtrzYhUqFpbcw:sys.exit()
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.Delete_History_List(LieskvglVaCJjxHXEGtrzYhUqFpbIO,LieskvglVaCJjxHXEGtrzYhUqFpbIA)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(LieskvglVaCJjxHXEGtrzYhUqFpbDN):
  LieskvglVaCJjxHXEGtrzYhUqFpbDS=LieskvglVaCJjxHXEGtrzYhUqFpbDN.get_settings_menubookmark()
  for LieskvglVaCJjxHXEGtrzYhUqFpbmI in LieskvglVaCJjxHXEGtrzYhUqFpbDm:
   LieskvglVaCJjxHXEGtrzYhUqFpbDK=LieskvglVaCJjxHXEGtrzYhUqFpbmI.get('title')
   LieskvglVaCJjxHXEGtrzYhUqFpbIP=''
   if LieskvglVaCJjxHXEGtrzYhUqFpbmI.get('mode')=='MENU_BOOKMARK' and LieskvglVaCJjxHXEGtrzYhUqFpbDS==LieskvglVaCJjxHXEGtrzYhUqFpbcw:continue
   LieskvglVaCJjxHXEGtrzYhUqFpbDd={'mode':LieskvglVaCJjxHXEGtrzYhUqFpbmI.get('mode')}
   if LieskvglVaCJjxHXEGtrzYhUqFpbmI.get('mode')in['XXX','MENU_BOOKMARK']:
    LieskvglVaCJjxHXEGtrzYhUqFpbmT=LieskvglVaCJjxHXEGtrzYhUqFpbcw
    LieskvglVaCJjxHXEGtrzYhUqFpbmc =LieskvglVaCJjxHXEGtrzYhUqFpbcR
   else:
    LieskvglVaCJjxHXEGtrzYhUqFpbmT=LieskvglVaCJjxHXEGtrzYhUqFpbcR
    LieskvglVaCJjxHXEGtrzYhUqFpbmc =LieskvglVaCJjxHXEGtrzYhUqFpbcw
   if 'icon' in LieskvglVaCJjxHXEGtrzYhUqFpbmI:LieskvglVaCJjxHXEGtrzYhUqFpbIP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',LieskvglVaCJjxHXEGtrzYhUqFpbmI.get('icon')) 
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.add_dir(LieskvglVaCJjxHXEGtrzYhUqFpbDK,sublabel='',img=LieskvglVaCJjxHXEGtrzYhUqFpbIP,infoLabels=LieskvglVaCJjxHXEGtrzYhUqFpbcS,isFolder=LieskvglVaCJjxHXEGtrzYhUqFpbmT,params=LieskvglVaCJjxHXEGtrzYhUqFpbDd,isLink=LieskvglVaCJjxHXEGtrzYhUqFpbmc)
  xbmcplugin.endOfDirectory(LieskvglVaCJjxHXEGtrzYhUqFpbDN._addon_handle,cacheToDisc=LieskvglVaCJjxHXEGtrzYhUqFpbcw)
 def option_check(LieskvglVaCJjxHXEGtrzYhUqFpbDN):
  LieskvglVaCJjxHXEGtrzYhUqFpbDR=LieskvglVaCJjxHXEGtrzYhUqFpbDN.get_settings_select_info()
  if LieskvglVaCJjxHXEGtrzYhUqFpbcQ(LieskvglVaCJjxHXEGtrzYhUqFpbDR)==0:
   LieskvglVaCJjxHXEGtrzYhUqFpbDW=xbmcgui.Dialog()
   LieskvglVaCJjxHXEGtrzYhUqFpbmD=LieskvglVaCJjxHXEGtrzYhUqFpbDW.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if LieskvglVaCJjxHXEGtrzYhUqFpbmD==LieskvglVaCJjxHXEGtrzYhUqFpbcR:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in LieskvglVaCJjxHXEGtrzYhUqFpbDR:
   if LieskvglVaCJjxHXEGtrzYhUqFpbDN.NF_cookiefile_check()==LieskvglVaCJjxHXEGtrzYhUqFpbcw:
    LieskvglVaCJjxHXEGtrzYhUqFpbDN.NF_login(showMessage=LieskvglVaCJjxHXEGtrzYhUqFpbcR)
  if 'disney' in LieskvglVaCJjxHXEGtrzYhUqFpbDR:
   if LieskvglVaCJjxHXEGtrzYhUqFpbDN.DZ_cookiefile_check()==LieskvglVaCJjxHXEGtrzYhUqFpbcw:
    LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.DZ={}
 def DZ_cookiefile_check(LieskvglVaCJjxHXEGtrzYhUqFpbDN):
  LieskvglVaCJjxHXEGtrzYhUqFpbmN={}
  try: 
   fp=LieskvglVaCJjxHXEGtrzYhUqFpbcK(LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   LieskvglVaCJjxHXEGtrzYhUqFpbmN= json.load(fp)
   fp.close()
  except LieskvglVaCJjxHXEGtrzYhUqFpbcA as exception:
   return LieskvglVaCJjxHXEGtrzYhUqFpbcw
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.DZ=LieskvglVaCJjxHXEGtrzYhUqFpbmN
  if LieskvglVaCJjxHXEGtrzYhUqFpbMD(time.time())>LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.DZ['account']['token_limit']:
   if LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.DZ_ReToken()==LieskvglVaCJjxHXEGtrzYhUqFpbcw:
    LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_noti(__language__(30920).encode('utf-8'))
    return LieskvglVaCJjxHXEGtrzYhUqFpbcw
   try: 
    fp=LieskvglVaCJjxHXEGtrzYhUqFpbcK(LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.DZ,fp,indent=4,ensure_ascii=LieskvglVaCJjxHXEGtrzYhUqFpbcw)
    fp.close()
   except LieskvglVaCJjxHXEGtrzYhUqFpbcA as exception:
    return LieskvglVaCJjxHXEGtrzYhUqFpbcw
  return LieskvglVaCJjxHXEGtrzYhUqFpbcR
 def NF_cookiefile_check(LieskvglVaCJjxHXEGtrzYhUqFpbDN):
  LieskvglVaCJjxHXEGtrzYhUqFpbmN={}
  try: 
   fp=LieskvglVaCJjxHXEGtrzYhUqFpbcK(LieskvglVaCJjxHXEGtrzYhUqFpbDc,'r',-1,'utf-8')
   LieskvglVaCJjxHXEGtrzYhUqFpbmN= json.load(fp)
   fp.close()
  except LieskvglVaCJjxHXEGtrzYhUqFpbcA as exception:
   return LieskvglVaCJjxHXEGtrzYhUqFpbcw
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF=LieskvglVaCJjxHXEGtrzYhUqFpbmN
  LieskvglVaCJjxHXEGtrzYhUqFpbmf =LieskvglVaCJjxHXEGtrzYhUqFpbMD(LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  LieskvglVaCJjxHXEGtrzYhUqFpbmn=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF['SESSION']['limitdate']
  LieskvglVaCJjxHXEGtrzYhUqFpbmB =LieskvglVaCJjxHXEGtrzYhUqFpbMD(re.sub('-','',LieskvglVaCJjxHXEGtrzYhUqFpbmn))
  if LieskvglVaCJjxHXEGtrzYhUqFpbmB<LieskvglVaCJjxHXEGtrzYhUqFpbmf:
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Init_NF_Total()
   if LieskvglVaCJjxHXEGtrzYhUqFpbDN.NF_login(showMessage=LieskvglVaCJjxHXEGtrzYhUqFpbcw)==LieskvglVaCJjxHXEGtrzYhUqFpbcw:
    return LieskvglVaCJjxHXEGtrzYhUqFpbcw
  LieskvglVaCJjxHXEGtrzYhUqFpbmW=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF_CookieFile_Load(LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF_ORIGINAL_COOKIE)
  if(LieskvglVaCJjxHXEGtrzYhUqFpbmW['NetflixId']!=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF['COOKIES']['NetflixId']or LieskvglVaCJjxHXEGtrzYhUqFpbmW['SecureNetflixId']!=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF['COOKIES']['SecureNetflixId']or LieskvglVaCJjxHXEGtrzYhUqFpbmW['flwssn']!=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF['COOKIES']['flwssn']or LieskvglVaCJjxHXEGtrzYhUqFpbmW['nfvdid']!=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF['COOKIES']['nfvdid']):
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Init_NF_Total()
   if LieskvglVaCJjxHXEGtrzYhUqFpbDN.NF_login(showMessage=LieskvglVaCJjxHXEGtrzYhUqFpbcw)==LieskvglVaCJjxHXEGtrzYhUqFpbcw:
    return LieskvglVaCJjxHXEGtrzYhUqFpbcw
  return LieskvglVaCJjxHXEGtrzYhUqFpbcR
 def NF_login(LieskvglVaCJjxHXEGtrzYhUqFpbDN,showMessage=LieskvglVaCJjxHXEGtrzYhUqFpbcR):
  if showMessage:
   LieskvglVaCJjxHXEGtrzYhUqFpbDW=xbmcgui.Dialog()
   LieskvglVaCJjxHXEGtrzYhUqFpbmD=LieskvglVaCJjxHXEGtrzYhUqFpbDW.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if LieskvglVaCJjxHXEGtrzYhUqFpbmD==LieskvglVaCJjxHXEGtrzYhUqFpbcw:
    return LieskvglVaCJjxHXEGtrzYhUqFpbcw 
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF['COOKIES']=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF_CookieFile_Load(LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF_ORIGINAL_COOKIE)
  LieskvglVaCJjxHXEGtrzYhUqFpbmu=LieskvglVaCJjxHXEGtrzYhUqFpbcw if LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF['COOKIES']=={}else LieskvglVaCJjxHXEGtrzYhUqFpbcR
  if LieskvglVaCJjxHXEGtrzYhUqFpbmu:
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_log('pass1 ok!')
  else:
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_log('pass1 error!')
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_noti(__language__(30905).encode('utf-8'))
   return LieskvglVaCJjxHXEGtrzYhUqFpbcw 
  LieskvglVaCJjxHXEGtrzYhUqFpbmu=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF_Get_BaseSession()
  if LieskvglVaCJjxHXEGtrzYhUqFpbmu:
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_log('pass2 ok!')
  else:
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_log('pass2 error!')
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_noti(__language__(30905).encode('utf-8'))
   return LieskvglVaCJjxHXEGtrzYhUqFpbcw 
  LieskvglVaCJjxHXEGtrzYhUqFpbmO =LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Now_Datetime()
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF['SESSION']['limitdate']=LieskvglVaCJjxHXEGtrzYhUqFpbmO.strftime('%Y-%m-%d')
  try: 
   fp=LieskvglVaCJjxHXEGtrzYhUqFpbcK(LieskvglVaCJjxHXEGtrzYhUqFpbDc,'w',-1,'utf-8')
   json.dump(LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF,fp,indent=4,ensure_ascii=LieskvglVaCJjxHXEGtrzYhUqFpbcw)
   fp.close()
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_log('pass3 save ok!')
  except LieskvglVaCJjxHXEGtrzYhUqFpbcA as exception:
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_log('pass3 save error!')
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_noti(__language__(30905).encode('utf-8'))
   return LieskvglVaCJjxHXEGtrzYhUqFpbcw
  if showMessage:LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_noti(__language__(30904).encode('utf-8'))
  return LieskvglVaCJjxHXEGtrzYhUqFpbcR
 def NF_logout(LieskvglVaCJjxHXEGtrzYhUqFpbDN):
  LieskvglVaCJjxHXEGtrzYhUqFpbDW=xbmcgui.Dialog()
  LieskvglVaCJjxHXEGtrzYhUqFpbmD=LieskvglVaCJjxHXEGtrzYhUqFpbDW.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if LieskvglVaCJjxHXEGtrzYhUqFpbmD==LieskvglVaCJjxHXEGtrzYhUqFpbcw:return 
  if os.path.isfile(LieskvglVaCJjxHXEGtrzYhUqFpbDc):os.remove(LieskvglVaCJjxHXEGtrzYhUqFpbDc)
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(LieskvglVaCJjxHXEGtrzYhUqFpbDN,LieskvglVaCJjxHXEGtrzYhUqFpbmd):
  LieskvglVaCJjxHXEGtrzYhUqFpbmo=''
  LieskvglVaCJjxHXEGtrzYhUqFpbmS=7
  try:
   for i in LieskvglVaCJjxHXEGtrzYhUqFpbMI(LieskvglVaCJjxHXEGtrzYhUqFpbcQ(LieskvglVaCJjxHXEGtrzYhUqFpbmd)):
    if i>=LieskvglVaCJjxHXEGtrzYhUqFpbmS:
     LieskvglVaCJjxHXEGtrzYhUqFpbmo=LieskvglVaCJjxHXEGtrzYhUqFpbmo+'...'
     break
    LieskvglVaCJjxHXEGtrzYhUqFpbmo=LieskvglVaCJjxHXEGtrzYhUqFpbmo+LieskvglVaCJjxHXEGtrzYhUqFpbmd[i]['title']+'\n'
  except:
   return ''
  return LieskvglVaCJjxHXEGtrzYhUqFpbmo
 def dp_Search_Group(LieskvglVaCJjxHXEGtrzYhUqFpbDN,args):
  LieskvglVaCJjxHXEGtrzYhUqFpbDR =LieskvglVaCJjxHXEGtrzYhUqFpbDN.get_settings_select_info()
  LieskvglVaCJjxHXEGtrzYhUqFpbmR=[]
  if 'search_key' in args:
   LieskvglVaCJjxHXEGtrzYhUqFpbmw=args.get('search_key')
  else:
   LieskvglVaCJjxHXEGtrzYhUqFpbmw=LieskvglVaCJjxHXEGtrzYhUqFpbDN.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not LieskvglVaCJjxHXEGtrzYhUqFpbmw:
    return
  if 'wavve' in LieskvglVaCJjxHXEGtrzYhUqFpbDR:
   (LieskvglVaCJjxHXEGtrzYhUqFpbmd,LieskvglVaCJjxHXEGtrzYhUqFpbmP)=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Search_Wavve(LieskvglVaCJjxHXEGtrzYhUqFpbmw,'TVSHOW',1)
   if LieskvglVaCJjxHXEGtrzYhUqFpbcQ(LieskvglVaCJjxHXEGtrzYhUqFpbmd)>0:
    LieskvglVaCJjxHXEGtrzYhUqFpbmK={'sType':'wavve_tvshow','sList':LieskvglVaCJjxHXEGtrzYhUqFpbDN.MakeText_FreeList(LieskvglVaCJjxHXEGtrzYhUqFpbmd),}
    LieskvglVaCJjxHXEGtrzYhUqFpbmR.append(LieskvglVaCJjxHXEGtrzYhUqFpbmK)
   (LieskvglVaCJjxHXEGtrzYhUqFpbmd,LieskvglVaCJjxHXEGtrzYhUqFpbmP)=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Search_Wavve(LieskvglVaCJjxHXEGtrzYhUqFpbmw,'MOVIE',1)
   if LieskvglVaCJjxHXEGtrzYhUqFpbcQ(LieskvglVaCJjxHXEGtrzYhUqFpbmd)>0:
    LieskvglVaCJjxHXEGtrzYhUqFpbmK={'sType':'wavve_movie','sList':LieskvglVaCJjxHXEGtrzYhUqFpbDN.MakeText_FreeList(LieskvglVaCJjxHXEGtrzYhUqFpbmd),}
    LieskvglVaCJjxHXEGtrzYhUqFpbmR.append(LieskvglVaCJjxHXEGtrzYhUqFpbmK)
  if 'tving' in LieskvglVaCJjxHXEGtrzYhUqFpbDR:
   (LieskvglVaCJjxHXEGtrzYhUqFpbmd,LieskvglVaCJjxHXEGtrzYhUqFpbmP)=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Search_Tving(LieskvglVaCJjxHXEGtrzYhUqFpbmw,'TVSHOW',1)
   if LieskvglVaCJjxHXEGtrzYhUqFpbcQ(LieskvglVaCJjxHXEGtrzYhUqFpbmd)>0:
    LieskvglVaCJjxHXEGtrzYhUqFpbmK={'sType':'tving_tvshow','sList':LieskvglVaCJjxHXEGtrzYhUqFpbDN.MakeText_FreeList(LieskvglVaCJjxHXEGtrzYhUqFpbmd),}
    LieskvglVaCJjxHXEGtrzYhUqFpbmR.append(LieskvglVaCJjxHXEGtrzYhUqFpbmK)
   (LieskvglVaCJjxHXEGtrzYhUqFpbmd,LieskvglVaCJjxHXEGtrzYhUqFpbmP)=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Search_Tving(LieskvglVaCJjxHXEGtrzYhUqFpbmw,'MOVIE',1)
   if LieskvglVaCJjxHXEGtrzYhUqFpbcQ(LieskvglVaCJjxHXEGtrzYhUqFpbmd)>0:
    LieskvglVaCJjxHXEGtrzYhUqFpbmK={'sType':'tving_movie','sList':LieskvglVaCJjxHXEGtrzYhUqFpbDN.MakeText_FreeList(LieskvglVaCJjxHXEGtrzYhUqFpbmd),}
    LieskvglVaCJjxHXEGtrzYhUqFpbmR.append(LieskvglVaCJjxHXEGtrzYhUqFpbmK)
  if 'watcha' in LieskvglVaCJjxHXEGtrzYhUqFpbDR:
   (LieskvglVaCJjxHXEGtrzYhUqFpbmd,LieskvglVaCJjxHXEGtrzYhUqFpbmP)=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Search_Watcha(LieskvglVaCJjxHXEGtrzYhUqFpbmw,1)
   if LieskvglVaCJjxHXEGtrzYhUqFpbcQ(LieskvglVaCJjxHXEGtrzYhUqFpbmd)>0:
    LieskvglVaCJjxHXEGtrzYhUqFpbmK={'sType':'watcha_list','sList':LieskvglVaCJjxHXEGtrzYhUqFpbDN.MakeText_FreeList(LieskvglVaCJjxHXEGtrzYhUqFpbmd),}
    LieskvglVaCJjxHXEGtrzYhUqFpbmR.append(LieskvglVaCJjxHXEGtrzYhUqFpbmK)
  if 'coupang' in LieskvglVaCJjxHXEGtrzYhUqFpbDR:
   (LieskvglVaCJjxHXEGtrzYhUqFpbmd,LieskvglVaCJjxHXEGtrzYhUqFpbmP)=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Search_Coupang(LieskvglVaCJjxHXEGtrzYhUqFpbmw,1)
   if LieskvglVaCJjxHXEGtrzYhUqFpbcQ(LieskvglVaCJjxHXEGtrzYhUqFpbmd)>0:
    LieskvglVaCJjxHXEGtrzYhUqFpbmK={'sType':'coupang_list','sList':LieskvglVaCJjxHXEGtrzYhUqFpbDN.MakeText_FreeList(LieskvglVaCJjxHXEGtrzYhUqFpbmd),}
    LieskvglVaCJjxHXEGtrzYhUqFpbmR.append(LieskvglVaCJjxHXEGtrzYhUqFpbmK)
  if 'netflix' in LieskvglVaCJjxHXEGtrzYhUqFpbDR:
   try:
    (LieskvglVaCJjxHXEGtrzYhUqFpbmd,LieskvglVaCJjxHXEGtrzYhUqFpbmP,LieskvglVaCJjxHXEGtrzYhUqFpbmQ)=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Search_Netflix(LieskvglVaCJjxHXEGtrzYhUqFpbmw,1)
   except:
    LieskvglVaCJjxHXEGtrzYhUqFpbmd=[]
    LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_noti(__language__(30919).encode('utf8'))
   if LieskvglVaCJjxHXEGtrzYhUqFpbcQ(LieskvglVaCJjxHXEGtrzYhUqFpbmd)>0:
    LieskvglVaCJjxHXEGtrzYhUqFpbmK={'sType':'netflix_list','sList':LieskvglVaCJjxHXEGtrzYhUqFpbDN.MakeText_FreeList(LieskvglVaCJjxHXEGtrzYhUqFpbmd),}
    LieskvglVaCJjxHXEGtrzYhUqFpbmR.append(LieskvglVaCJjxHXEGtrzYhUqFpbmK)
  if 'amazon' in LieskvglVaCJjxHXEGtrzYhUqFpbDR:
   (LieskvglVaCJjxHXEGtrzYhUqFpbmd)=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Search_Primev(LieskvglVaCJjxHXEGtrzYhUqFpbmw)
   if LieskvglVaCJjxHXEGtrzYhUqFpbcQ(LieskvglVaCJjxHXEGtrzYhUqFpbmd)>0:
    LieskvglVaCJjxHXEGtrzYhUqFpbmK={'sType':'primev_list','sList':LieskvglVaCJjxHXEGtrzYhUqFpbDN.MakeText_FreeList(LieskvglVaCJjxHXEGtrzYhUqFpbmd),}
    LieskvglVaCJjxHXEGtrzYhUqFpbmR.append(LieskvglVaCJjxHXEGtrzYhUqFpbmK)
  if 'disney' in LieskvglVaCJjxHXEGtrzYhUqFpbDR:
   try:
    (LieskvglVaCJjxHXEGtrzYhUqFpbmd)=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Search_Disney(LieskvglVaCJjxHXEGtrzYhUqFpbmw)
   except:
    LieskvglVaCJjxHXEGtrzYhUqFpbmd=[]
    LieskvglVaCJjxHXEGtrzYhUqFpbDN.addon_noti(__language__(30921).encode('utf8'))
   if LieskvglVaCJjxHXEGtrzYhUqFpbcQ(LieskvglVaCJjxHXEGtrzYhUqFpbmd)>0:
    LieskvglVaCJjxHXEGtrzYhUqFpbmK={'sType':'disney_list','sList':LieskvglVaCJjxHXEGtrzYhUqFpbDN.MakeText_FreeList(LieskvglVaCJjxHXEGtrzYhUqFpbmd),}
    LieskvglVaCJjxHXEGtrzYhUqFpbmR.append(LieskvglVaCJjxHXEGtrzYhUqFpbmK)
  for LieskvglVaCJjxHXEGtrzYhUqFpbmA in LieskvglVaCJjxHXEGtrzYhUqFpbmR:
   LieskvglVaCJjxHXEGtrzYhUqFpbTD=LieskvglVaCJjxHXEGtrzYhUqFpbDT[LieskvglVaCJjxHXEGtrzYhUqFpbmA.get('sType')]
   LieskvglVaCJjxHXEGtrzYhUqFpbTI={'plot':'검색어 : '+LieskvglVaCJjxHXEGtrzYhUqFpbmw+'\n\n'+LieskvglVaCJjxHXEGtrzYhUqFpbmA.get('sList')}
   LieskvglVaCJjxHXEGtrzYhUqFpbDK=LieskvglVaCJjxHXEGtrzYhUqFpbTD.get('title')
   LieskvglVaCJjxHXEGtrzYhUqFpbDd={'mode':LieskvglVaCJjxHXEGtrzYhUqFpbTD.get('mode'),'ott':LieskvglVaCJjxHXEGtrzYhUqFpbTD.get('ott'),'vidtype':LieskvglVaCJjxHXEGtrzYhUqFpbTD.get('vidtype'),'search_key':LieskvglVaCJjxHXEGtrzYhUqFpbmw}
   if LieskvglVaCJjxHXEGtrzYhUqFpbTD.get('ott')=='netflix':
    LieskvglVaCJjxHXEGtrzYhUqFpbTm=''
    LieskvglVaCJjxHXEGtrzYhUqFpbDd['page'] ='1'
    LieskvglVaCJjxHXEGtrzYhUqFpbDd['byReference']='-'
   else:
    LieskvglVaCJjxHXEGtrzYhUqFpbTm=LieskvglVaCJjxHXEGtrzYhUqFpbDN.make_Hyper_Link(LieskvglVaCJjxHXEGtrzYhUqFpbDd)
   LieskvglVaCJjxHXEGtrzYhUqFpbIP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',LieskvglVaCJjxHXEGtrzYhUqFpbTD.get('icon'))
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.add_dir(LieskvglVaCJjxHXEGtrzYhUqFpbDK,sublabel='',img=LieskvglVaCJjxHXEGtrzYhUqFpbIP,infoLabels=LieskvglVaCJjxHXEGtrzYhUqFpbTI,isFolder=LieskvglVaCJjxHXEGtrzYhUqFpbcR,params=LieskvglVaCJjxHXEGtrzYhUqFpbDd,isLink=LieskvglVaCJjxHXEGtrzYhUqFpbcw,direct_url=LieskvglVaCJjxHXEGtrzYhUqFpbTm)
  xbmcplugin.endOfDirectory(LieskvglVaCJjxHXEGtrzYhUqFpbDN._addon_handle)
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.Save_Searched_List(LieskvglVaCJjxHXEGtrzYhUqFpbmw)
 def make_Hyper_Link(LieskvglVaCJjxHXEGtrzYhUqFpbDN,args):
  LieskvglVaCJjxHXEGtrzYhUqFpbTc =args.get('ott')
  LieskvglVaCJjxHXEGtrzYhUqFpbTM =args.get('vidtype')
  LieskvglVaCJjxHXEGtrzYhUqFpbmw=args.get('search_key')
  LieskvglVaCJjxHXEGtrzYhUqFpbTm='-'
  if LieskvglVaCJjxHXEGtrzYhUqFpbTc=='wavve':
   LieskvglVaCJjxHXEGtrzYhUqFpbTN={'mode':'LOCAL_SEARCH','sType':'movie' if LieskvglVaCJjxHXEGtrzYhUqFpbTM=='MOVIE' else 'vod','search_key':LieskvglVaCJjxHXEGtrzYhUqFpbmw,'page':'1',}
   LieskvglVaCJjxHXEGtrzYhUqFpbTy=urllib.parse.urlencode(LieskvglVaCJjxHXEGtrzYhUqFpbTN)
   LieskvglVaCJjxHXEGtrzYhUqFpbTm='plugin://plugin.video.wavvem/?'
   LieskvglVaCJjxHXEGtrzYhUqFpbTm+=LieskvglVaCJjxHXEGtrzYhUqFpbTy
  elif LieskvglVaCJjxHXEGtrzYhUqFpbTc=='tving':
   LieskvglVaCJjxHXEGtrzYhUqFpbTN={'mode':'LOCAL_SEARCH','stype':'movie' if LieskvglVaCJjxHXEGtrzYhUqFpbTM=='MOVIE' else 'vod','search_key':LieskvglVaCJjxHXEGtrzYhUqFpbmw,'page':'1',}
   LieskvglVaCJjxHXEGtrzYhUqFpbTy=urllib.parse.urlencode(LieskvglVaCJjxHXEGtrzYhUqFpbTN)
   LieskvglVaCJjxHXEGtrzYhUqFpbTm='plugin://plugin.video.tvingm/?'
   LieskvglVaCJjxHXEGtrzYhUqFpbTm+=LieskvglVaCJjxHXEGtrzYhUqFpbTy
  elif LieskvglVaCJjxHXEGtrzYhUqFpbTc=='watcha':
   LieskvglVaCJjxHXEGtrzYhUqFpbTN={'mode':'LOCAL_SEARCH','search_key':LieskvglVaCJjxHXEGtrzYhUqFpbmw,'page':'1',}
   LieskvglVaCJjxHXEGtrzYhUqFpbTy=urllib.parse.urlencode(LieskvglVaCJjxHXEGtrzYhUqFpbTN)
   LieskvglVaCJjxHXEGtrzYhUqFpbTm='plugin://plugin.video.watcham/?'
   LieskvglVaCJjxHXEGtrzYhUqFpbTm+=LieskvglVaCJjxHXEGtrzYhUqFpbTy
  elif LieskvglVaCJjxHXEGtrzYhUqFpbTc=='coupang':
   LieskvglVaCJjxHXEGtrzYhUqFpbTN={'mode':'LOCAL_SEARCH','search_key':LieskvglVaCJjxHXEGtrzYhUqFpbmw,'page':'1',}
   LieskvglVaCJjxHXEGtrzYhUqFpbTy=urllib.parse.urlencode(LieskvglVaCJjxHXEGtrzYhUqFpbTN)
   LieskvglVaCJjxHXEGtrzYhUqFpbTm='plugin://plugin.video.coupangm/?'
   LieskvglVaCJjxHXEGtrzYhUqFpbTm+=LieskvglVaCJjxHXEGtrzYhUqFpbTy
  elif LieskvglVaCJjxHXEGtrzYhUqFpbTc=='netflix':
   LieskvglVaCJjxHXEGtrzYhUqFpbTf=args.get('videoid')
   LieskvglVaCJjxHXEGtrzYhUqFpbTn=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.NF['SESSION']['nowGuid']
   if LieskvglVaCJjxHXEGtrzYhUqFpbTM=='TVSHOW':
    LieskvglVaCJjxHXEGtrzYhUqFpbTm='plugin://plugin.video.netflix/directory/show/%s/'%(LieskvglVaCJjxHXEGtrzYhUqFpbTf)
   else:
    LieskvglVaCJjxHXEGtrzYhUqFpbTm='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(LieskvglVaCJjxHXEGtrzYhUqFpbTf,LieskvglVaCJjxHXEGtrzYhUqFpbTn)
  elif LieskvglVaCJjxHXEGtrzYhUqFpbTc=='amazon':
   LieskvglVaCJjxHXEGtrzYhUqFpbTN={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':LieskvglVaCJjxHXEGtrzYhUqFpbmw,}}
   LieskvglVaCJjxHXEGtrzYhUqFpbTy=json.dumps(LieskvglVaCJjxHXEGtrzYhUqFpbTN,separators=(',',':'))
   LieskvglVaCJjxHXEGtrzYhUqFpbTy=base64.standard_b64encode(LieskvglVaCJjxHXEGtrzYhUqFpbTy.encode()).decode('utf-8')
   LieskvglVaCJjxHXEGtrzYhUqFpbTy=LieskvglVaCJjxHXEGtrzYhUqFpbTy.replace('+','%2B')
   LieskvglVaCJjxHXEGtrzYhUqFpbTm='plugin://plugin.video.primevm/?params='
   LieskvglVaCJjxHXEGtrzYhUqFpbTm+=LieskvglVaCJjxHXEGtrzYhUqFpbTy
  elif LieskvglVaCJjxHXEGtrzYhUqFpbTc=='disney':
   LieskvglVaCJjxHXEGtrzYhUqFpbTN={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':LieskvglVaCJjxHXEGtrzYhUqFpbmw,}}
   LieskvglVaCJjxHXEGtrzYhUqFpbTy=json.dumps(LieskvglVaCJjxHXEGtrzYhUqFpbTN,separators=(',',':'))
   LieskvglVaCJjxHXEGtrzYhUqFpbTy=base64.standard_b64encode(LieskvglVaCJjxHXEGtrzYhUqFpbTy.encode()).decode('utf-8')
   LieskvglVaCJjxHXEGtrzYhUqFpbTy=LieskvglVaCJjxHXEGtrzYhUqFpbTy.replace('+','%2B')
   LieskvglVaCJjxHXEGtrzYhUqFpbTm='plugin://plugin.video.disneym/?params='
   LieskvglVaCJjxHXEGtrzYhUqFpbTm+=LieskvglVaCJjxHXEGtrzYhUqFpbTy
  return LieskvglVaCJjxHXEGtrzYhUqFpbTm
 def dp_Nf_Search(LieskvglVaCJjxHXEGtrzYhUqFpbDN,args):
  LieskvglVaCJjxHXEGtrzYhUqFpbTB =LieskvglVaCJjxHXEGtrzYhUqFpbMD(args.get('page'))
  LieskvglVaCJjxHXEGtrzYhUqFpbmw =args.get('search_key')
  LieskvglVaCJjxHXEGtrzYhUqFpbmQ=args.get('byReference')
  (LieskvglVaCJjxHXEGtrzYhUqFpbmd,LieskvglVaCJjxHXEGtrzYhUqFpbmP,LieskvglVaCJjxHXEGtrzYhUqFpbmQ)=LieskvglVaCJjxHXEGtrzYhUqFpbDN.SearchObj.Get_Search_Netflix(LieskvglVaCJjxHXEGtrzYhUqFpbmw,LieskvglVaCJjxHXEGtrzYhUqFpbTB,byReference=LieskvglVaCJjxHXEGtrzYhUqFpbmQ)
  for LieskvglVaCJjxHXEGtrzYhUqFpbTW in LieskvglVaCJjxHXEGtrzYhUqFpbmd:
   LieskvglVaCJjxHXEGtrzYhUqFpbTf =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('videoid')
   LieskvglVaCJjxHXEGtrzYhUqFpbTM =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('vidtype')
   LieskvglVaCJjxHXEGtrzYhUqFpbDK =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('title')
   LieskvglVaCJjxHXEGtrzYhUqFpbTu =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('mpaa')
   LieskvglVaCJjxHXEGtrzYhUqFpbTO =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('regularSynopsis')
   LieskvglVaCJjxHXEGtrzYhUqFpbTo =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('dpSupplemental')
   LieskvglVaCJjxHXEGtrzYhUqFpbTS=LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('sequiturEvidence')
   LieskvglVaCJjxHXEGtrzYhUqFpbTR =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('thumbnail')
   LieskvglVaCJjxHXEGtrzYhUqFpbTw =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('year')
   LieskvglVaCJjxHXEGtrzYhUqFpbTd =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('duration')
   LieskvglVaCJjxHXEGtrzYhUqFpbTP =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('info_genre')
   LieskvglVaCJjxHXEGtrzYhUqFpbTK =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('director')
   LieskvglVaCJjxHXEGtrzYhUqFpbTQ =LieskvglVaCJjxHXEGtrzYhUqFpbTW.get('cast')
   if LieskvglVaCJjxHXEGtrzYhUqFpbTM=='movie':
    LieskvglVaCJjxHXEGtrzYhUqFpbIw=' (%s)'%(LieskvglVaCJjxHXEGtrzYhUqFpbMm(LieskvglVaCJjxHXEGtrzYhUqFpbTw))
   else:
    LieskvglVaCJjxHXEGtrzYhUqFpbIw=''
   LieskvglVaCJjxHXEGtrzYhUqFpbTA=''
   if LieskvglVaCJjxHXEGtrzYhUqFpbTO:LieskvglVaCJjxHXEGtrzYhUqFpbTA=LieskvglVaCJjxHXEGtrzYhUqFpbTA+'\n\n'+LieskvglVaCJjxHXEGtrzYhUqFpbTO
   if LieskvglVaCJjxHXEGtrzYhUqFpbTo :LieskvglVaCJjxHXEGtrzYhUqFpbTA=LieskvglVaCJjxHXEGtrzYhUqFpbTA+'\n\n'+LieskvglVaCJjxHXEGtrzYhUqFpbTo
   if LieskvglVaCJjxHXEGtrzYhUqFpbTS:LieskvglVaCJjxHXEGtrzYhUqFpbTA=LieskvglVaCJjxHXEGtrzYhUqFpbTA+'\n\n'+LieskvglVaCJjxHXEGtrzYhUqFpbTS
   LieskvglVaCJjxHXEGtrzYhUqFpbTA=LieskvglVaCJjxHXEGtrzYhUqFpbTA.strip()
   LieskvglVaCJjxHXEGtrzYhUqFpbId={'mediatype':'tvshow' if LieskvglVaCJjxHXEGtrzYhUqFpbTM=='show' else 'movie','title':LieskvglVaCJjxHXEGtrzYhUqFpbDK,'mpaa':LieskvglVaCJjxHXEGtrzYhUqFpbTu,'plot':LieskvglVaCJjxHXEGtrzYhUqFpbTA,'duration':LieskvglVaCJjxHXEGtrzYhUqFpbTd,'genre':LieskvglVaCJjxHXEGtrzYhUqFpbTP,'director':LieskvglVaCJjxHXEGtrzYhUqFpbTK,'cast':LieskvglVaCJjxHXEGtrzYhUqFpbTQ,'year':LieskvglVaCJjxHXEGtrzYhUqFpbTw,}
   LieskvglVaCJjxHXEGtrzYhUqFpbDd={'ott':'netflix','vidtype':'TVSHOW' if LieskvglVaCJjxHXEGtrzYhUqFpbTM=='show' else 'MOVIE','videoid':LieskvglVaCJjxHXEGtrzYhUqFpbTf,}
   LieskvglVaCJjxHXEGtrzYhUqFpbTm=LieskvglVaCJjxHXEGtrzYhUqFpbDN.make_Hyper_Link(LieskvglVaCJjxHXEGtrzYhUqFpbDd)
   LieskvglVaCJjxHXEGtrzYhUqFpbmT=LieskvglVaCJjxHXEGtrzYhUqFpbcR if LieskvglVaCJjxHXEGtrzYhUqFpbTM=='show' else LieskvglVaCJjxHXEGtrzYhUqFpbcw
   if LieskvglVaCJjxHXEGtrzYhUqFpbDN.get_settings_makebookmark():
    LieskvglVaCJjxHXEGtrzYhUqFpbcD={'mode':'SET_BOOKMARK','values':{'videoid':LieskvglVaCJjxHXEGtrzYhUqFpbTf,'vidtype':'tvshow' if LieskvglVaCJjxHXEGtrzYhUqFpbTM=='show' else 'movie','vtitle':LieskvglVaCJjxHXEGtrzYhUqFpbDK+LieskvglVaCJjxHXEGtrzYhUqFpbIw,'vsubtitle':'','vinfo':LieskvglVaCJjxHXEGtrzYhUqFpbId,'thumbnail':LieskvglVaCJjxHXEGtrzYhUqFpbTR,}}
    LieskvglVaCJjxHXEGtrzYhUqFpbcI=json.dumps(LieskvglVaCJjxHXEGtrzYhUqFpbcD,separators=(',',':'))
    LieskvglVaCJjxHXEGtrzYhUqFpbcI=base64.standard_b64encode(LieskvglVaCJjxHXEGtrzYhUqFpbcI.encode()).decode('utf-8')
    LieskvglVaCJjxHXEGtrzYhUqFpbcI=LieskvglVaCJjxHXEGtrzYhUqFpbcI.replace('+','%2B')
    LieskvglVaCJjxHXEGtrzYhUqFpbcm='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(LieskvglVaCJjxHXEGtrzYhUqFpbcI)
    LieskvglVaCJjxHXEGtrzYhUqFpbIR=[('(통합) 찜 영상에 추가',LieskvglVaCJjxHXEGtrzYhUqFpbcm)]
   else:
    LieskvglVaCJjxHXEGtrzYhUqFpbIR=LieskvglVaCJjxHXEGtrzYhUqFpbcS
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.add_dir(LieskvglVaCJjxHXEGtrzYhUqFpbDK+LieskvglVaCJjxHXEGtrzYhUqFpbIw,sublabel=LieskvglVaCJjxHXEGtrzYhUqFpbcS,img=LieskvglVaCJjxHXEGtrzYhUqFpbTR,infoLabels=LieskvglVaCJjxHXEGtrzYhUqFpbId,isFolder=LieskvglVaCJjxHXEGtrzYhUqFpbmT,params=LieskvglVaCJjxHXEGtrzYhUqFpbDd,isLink=LieskvglVaCJjxHXEGtrzYhUqFpbcw,ContextMenu=LieskvglVaCJjxHXEGtrzYhUqFpbIR,direct_url=LieskvglVaCJjxHXEGtrzYhUqFpbTm)
  if LieskvglVaCJjxHXEGtrzYhUqFpbmP:
   LieskvglVaCJjxHXEGtrzYhUqFpbDd={}
   LieskvglVaCJjxHXEGtrzYhUqFpbDd['mode'] ='NF_SEARCH' 
   LieskvglVaCJjxHXEGtrzYhUqFpbDd['page'] =LieskvglVaCJjxHXEGtrzYhUqFpbMm(LieskvglVaCJjxHXEGtrzYhUqFpbTB+1)
   LieskvglVaCJjxHXEGtrzYhUqFpbDd['search_key']=LieskvglVaCJjxHXEGtrzYhUqFpbmw
   LieskvglVaCJjxHXEGtrzYhUqFpbDd['byReference']=LieskvglVaCJjxHXEGtrzYhUqFpbmQ
   LieskvglVaCJjxHXEGtrzYhUqFpbDK='[B]%s >>[/B]'%'다음 페이지'
   LieskvglVaCJjxHXEGtrzYhUqFpbcT=LieskvglVaCJjxHXEGtrzYhUqFpbMm(LieskvglVaCJjxHXEGtrzYhUqFpbTB+1)
   LieskvglVaCJjxHXEGtrzYhUqFpbIP=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.add_dir(LieskvglVaCJjxHXEGtrzYhUqFpbDK,sublabel=LieskvglVaCJjxHXEGtrzYhUqFpbcT,img=LieskvglVaCJjxHXEGtrzYhUqFpbIP,infoLabels=LieskvglVaCJjxHXEGtrzYhUqFpbcS,isFolder=LieskvglVaCJjxHXEGtrzYhUqFpbcR,params=LieskvglVaCJjxHXEGtrzYhUqFpbDd)
  xbmcplugin.setContent(LieskvglVaCJjxHXEGtrzYhUqFpbDN._addon_handle,'movies')
  xbmcplugin.endOfDirectory(LieskvglVaCJjxHXEGtrzYhUqFpbDN._addon_handle)
 def dp_Bookmark_Menu(LieskvglVaCJjxHXEGtrzYhUqFpbDN,args):
  LieskvglVaCJjxHXEGtrzYhUqFpbcM='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(LieskvglVaCJjxHXEGtrzYhUqFpbcM)
 def dp_Set_Bookmark(LieskvglVaCJjxHXEGtrzYhUqFpbDN,args):
  LieskvglVaCJjxHXEGtrzYhUqFpbTf =args.get('videoid')
  LieskvglVaCJjxHXEGtrzYhUqFpbTM =args.get('vidtype')
  LieskvglVaCJjxHXEGtrzYhUqFpbcN =args.get('vtitle')
  LieskvglVaCJjxHXEGtrzYhUqFpbcy =args.get('vsubtitle')
  LieskvglVaCJjxHXEGtrzYhUqFpbcf =args.get('vinfo')
  LieskvglVaCJjxHXEGtrzYhUqFpbTR =args.get('thumbnail')
  LieskvglVaCJjxHXEGtrzYhUqFpbDW=xbmcgui.Dialog()
  LieskvglVaCJjxHXEGtrzYhUqFpbmD=LieskvglVaCJjxHXEGtrzYhUqFpbDW.yesno(__language__(30917).encode('utf8'),LieskvglVaCJjxHXEGtrzYhUqFpbcN+' \n\n'+__language__(30918))
  if LieskvglVaCJjxHXEGtrzYhUqFpbmD==LieskvglVaCJjxHXEGtrzYhUqFpbcw:return
  LieskvglVaCJjxHXEGtrzYhUqFpbcn={'indexinfo':{'ott':'netflix','videoid':LieskvglVaCJjxHXEGtrzYhUqFpbTf,'vidtype':LieskvglVaCJjxHXEGtrzYhUqFpbTM,},'saveinfo':{'title':LieskvglVaCJjxHXEGtrzYhUqFpbcN,'subtitle':LieskvglVaCJjxHXEGtrzYhUqFpbcy,'thumbnail':LieskvglVaCJjxHXEGtrzYhUqFpbTR,'infoLabels':LieskvglVaCJjxHXEGtrzYhUqFpbcf,},}
  LieskvglVaCJjxHXEGtrzYhUqFpbDd={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':LieskvglVaCJjxHXEGtrzYhUqFpbcn,}}
  LieskvglVaCJjxHXEGtrzYhUqFpbDP=json.dumps(LieskvglVaCJjxHXEGtrzYhUqFpbDd,separators=(',',':'))
  LieskvglVaCJjxHXEGtrzYhUqFpbDP=base64.standard_b64encode(LieskvglVaCJjxHXEGtrzYhUqFpbDP.encode()).decode('utf-8')
  LieskvglVaCJjxHXEGtrzYhUqFpbDP=LieskvglVaCJjxHXEGtrzYhUqFpbDP.replace('+','%2B')
  LieskvglVaCJjxHXEGtrzYhUqFpbcm='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(LieskvglVaCJjxHXEGtrzYhUqFpbDP)
  xbmc.executebuiltin(LieskvglVaCJjxHXEGtrzYhUqFpbcm)
 def search_main(LieskvglVaCJjxHXEGtrzYhUqFpbDN):
  LieskvglVaCJjxHXEGtrzYhUqFpbcB=LieskvglVaCJjxHXEGtrzYhUqFpbDN.main_params.get('params')
  if LieskvglVaCJjxHXEGtrzYhUqFpbcB:
   LieskvglVaCJjxHXEGtrzYhUqFpbcW =base64.standard_b64decode(LieskvglVaCJjxHXEGtrzYhUqFpbcB).decode('utf-8')
   LieskvglVaCJjxHXEGtrzYhUqFpbcW =json.loads(LieskvglVaCJjxHXEGtrzYhUqFpbcW)
   LieskvglVaCJjxHXEGtrzYhUqFpbcu =LieskvglVaCJjxHXEGtrzYhUqFpbcW.get('mode')
   LieskvglVaCJjxHXEGtrzYhUqFpbcO =LieskvglVaCJjxHXEGtrzYhUqFpbcW.get('values')
  else:
   LieskvglVaCJjxHXEGtrzYhUqFpbcu=LieskvglVaCJjxHXEGtrzYhUqFpbDN.main_params.get('mode',LieskvglVaCJjxHXEGtrzYhUqFpbcS)
   LieskvglVaCJjxHXEGtrzYhUqFpbcO=LieskvglVaCJjxHXEGtrzYhUqFpbDN.main_params
  if LieskvglVaCJjxHXEGtrzYhUqFpbcu=='NFLOGOUT':
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.NF_logout()
   return
  elif LieskvglVaCJjxHXEGtrzYhUqFpbcu=='NFLOGIN':
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.NF_login(showMessage=LieskvglVaCJjxHXEGtrzYhUqFpbcR)
   return
  LieskvglVaCJjxHXEGtrzYhUqFpbDN.option_check()
  if LieskvglVaCJjxHXEGtrzYhUqFpbcu is LieskvglVaCJjxHXEGtrzYhUqFpbcS:
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.dp_Main_List()
  elif LieskvglVaCJjxHXEGtrzYhUqFpbcu=='TOTAL_SEARCH':
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.dp_Search_Group(LieskvglVaCJjxHXEGtrzYhUqFpbcO)
  elif LieskvglVaCJjxHXEGtrzYhUqFpbcu=='NF_SEARCH':
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.dp_Nf_Search(LieskvglVaCJjxHXEGtrzYhUqFpbcO)
  elif LieskvglVaCJjxHXEGtrzYhUqFpbcu=='TOTAL_HISTORY':
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.dp_Search_History(LieskvglVaCJjxHXEGtrzYhUqFpbcO)
  elif LieskvglVaCJjxHXEGtrzYhUqFpbcu=='HISTORY_REMOVE':
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.dp_History_Delete(LieskvglVaCJjxHXEGtrzYhUqFpbcO)
  elif LieskvglVaCJjxHXEGtrzYhUqFpbcu=='MENU_BOOKMARK':
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.dp_Bookmark_Menu(LieskvglVaCJjxHXEGtrzYhUqFpbcO)
  elif LieskvglVaCJjxHXEGtrzYhUqFpbcu=='SET_BOOKMARK':
   LieskvglVaCJjxHXEGtrzYhUqFpbDN.dp_Set_Bookmark(LieskvglVaCJjxHXEGtrzYhUqFpbcO)
  else:
   LieskvglVaCJjxHXEGtrzYhUqFpbcS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
