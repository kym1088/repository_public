__author__="NightRain"
QNqBHzxTJnjpuWeOgIXblPKkrwiYcR=object
QNqBHzxTJnjpuWeOgIXblPKkrwiYca=None
QNqBHzxTJnjpuWeOgIXblPKkrwiYcE=True
QNqBHzxTJnjpuWeOgIXblPKkrwiYct=print
QNqBHzxTJnjpuWeOgIXblPKkrwiYcd=str
QNqBHzxTJnjpuWeOgIXblPKkrwiYcD=int
QNqBHzxTJnjpuWeOgIXblPKkrwiYcV=False
QNqBHzxTJnjpuWeOgIXblPKkrwiYCo=dict
QNqBHzxTJnjpuWeOgIXblPKkrwiYCh=Exception
QNqBHzxTJnjpuWeOgIXblPKkrwiYCA=len
QNqBHzxTJnjpuWeOgIXblPKkrwiYCf=open
QNqBHzxTJnjpuWeOgIXblPKkrwiYCc=type
QNqBHzxTJnjpuWeOgIXblPKkrwiYCs=list
QNqBHzxTJnjpuWeOgIXblPKkrwiYCy=isinstance
QNqBHzxTJnjpuWeOgIXblPKkrwiYCF=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
import http.cookiejar
class QNqBHzxTJnjpuWeOgIXblPKkrwiYoh(QNqBHzxTJnjpuWeOgIXblPKkrwiYcR):
 def __init__(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_WAVVE ='https://apis.wavve.com'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_TVING_SEARCH='https://search-api.tving.com'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_TVING_IMG ='https://image.tving.com'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_WATCHA ='https://api-mars.watcha.com'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_NETFLIX ='https://www.netflix.com'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_COUPANG ='https://www.coupangplay.com'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_PRIMEV ='https://www.primevideo.com'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_DISNEY ='https://disney.api.edge.bamgrid.com/explore'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_DISNEY_VERSION ='v1.11'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.WAVVE_LIMIT =20 
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_LIMIT =30
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.WATCHA_LIMIT =30
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_LIMIT =20 
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.COUPANG_LIMIT =10 
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DISNEY_LIMIT =10 
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DERECTOR_LIMIT =4
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.CAST_LIMIT =10
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.GENRE_LIMIT =4
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_MOVIE_LITE=['2610061','2610161','261062']
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100','APIKEY':'1e7952d0917d6aab1f0293a063697610','TELECODE':'CSCD0900',}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_HEADER={'user-agent':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND1 ='_342x192'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND2 ='_665x375'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_PORT ='_342x684'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LOGO ='_550x124'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF={}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['COOKIES']={}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']={}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ={}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.PV={}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.HTTP_CLIENT=requests.Session()
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.CP_ORIGINAL_COOKIE =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.PV_ORIGINAL_COOKIE =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ_ORIGINAL_COOKIE =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_ORIGINAL_COOKIE =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_SESSION_COOKIES1 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_SESSION_COOKIES2 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_SESSION_COOKIES3 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_SESSION_COOKIES4 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_SESSION_FULLTEXT1 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_SESSION_FULLTEXT2 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_SESSION_FULLTEXT3 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_SESSION_FULLTEXT4 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_CONTEXTJSON_FILE1 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_CONTEXTJSON_FILE2 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_CONTEXTJSON_FILE3 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_CONTEXTJSON_FILE4 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_FALCORJSON_FILE1 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_FALCORJSON_FILE2 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_FALCORJSON_FILE3 =''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_FALCORJSON_FILE4 =''
 '''
 def callRequestCookies(self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):
  #setHeader = {'user-agent' : self.USER_AGENT }
  setHeader = self.DEFAULT_HEADER
  if headers: setHeader.update(headers )
  if jobtype == 'Get': # Get/Post
   res = requests.get(url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  else:
   res = requests.post(url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  return res
 ''' 
 def Call_Request(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,payload=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,json=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,params=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,cookies=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,redirects=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE,method='-'):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYof={'user-agent':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.USER_AGENT}
  if headers:QNqBHzxTJnjpuWeOgIXblPKkrwiYof.update(headers)
  if payload!=QNqBHzxTJnjpuWeOgIXblPKkrwiYca or method=='POST':
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.HTTP_CLIENT.post(url=QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,data=payload,json=json,params=params,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYof,cookies=cookies,allow_redirects=redirects)
  else:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.HTTP_CLIENT.get(url=QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,params=params,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYof,cookies=cookies,allow_redirects=redirects)
  QNqBHzxTJnjpuWeOgIXblPKkrwiYct(QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.status_code)+' - '+QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.url))
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYoc
 def GetNoCache(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,timetype=1,minutes=0):
  if timetype==1:
   ts=QNqBHzxTJnjpuWeOgIXblPKkrwiYcD(time.time())
   mi=QNqBHzxTJnjpuWeOgIXblPKkrwiYcD(minutes*60)
  else:
   ts=QNqBHzxTJnjpuWeOgIXblPKkrwiYcD(time.time()*1000)
   mi=QNqBHzxTJnjpuWeOgIXblPKkrwiYcD(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,search_key,sType,page_int):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYos=[]
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoy=QNqBHzxTJnjpuWeOgIXblPKkrwiYhA=1
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoF=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
  try:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoS=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_WAVVE+'/fz/search/band.js'
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoU={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':QNqBHzxTJnjpuWeOgIXblPKkrwiYcd((page_int-1)*QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.WAVVE_LIMIT),'limit':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.WAVVE_LIMIT,'orderby':'score','mtype':'svod',}
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoU.update(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.WAVVE_PARAMS)
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.Call_Request(QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,payload=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,params=QNqBHzxTJnjpuWeOgIXblPKkrwiYoU,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,cookies=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,method='GET')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoG=json.loads(QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.text)
   if not('celllist' in QNqBHzxTJnjpuWeOgIXblPKkrwiYoG['band']):return QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF
   QNqBHzxTJnjpuWeOgIXblPKkrwiYov=QNqBHzxTJnjpuWeOgIXblPKkrwiYoG['band']['celllist']
   for QNqBHzxTJnjpuWeOgIXblPKkrwiYoM in QNqBHzxTJnjpuWeOgIXblPKkrwiYov:
    QNqBHzxTJnjpuWeOgIXblPKkrwiYom =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['event_list'][1]['url']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoL=urllib.parse.urlsplit(QNqBHzxTJnjpuWeOgIXblPKkrwiYom).query
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoR=QNqBHzxTJnjpuWeOgIXblPKkrwiYoL[0:QNqBHzxTJnjpuWeOgIXblPKkrwiYoL.find('=')]
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoa=QNqBHzxTJnjpuWeOgIXblPKkrwiYCo(urllib.parse.parse_qsl(QNqBHzxTJnjpuWeOgIXblPKkrwiYoL))
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoE=QNqBHzxTJnjpuWeOgIXblPKkrwiYoa.get(QNqBHzxTJnjpuWeOgIXblPKkrwiYoR)
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoR='TVSHOW' if QNqBHzxTJnjpuWeOgIXblPKkrwiYoR=='programid' else 'MOVIE' 
    QNqBHzxTJnjpuWeOgIXblPKkrwiYot=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['title_list'][0]['text']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYod =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['age']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoD={'title':QNqBHzxTJnjpuWeOgIXblPKkrwiYot}
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoV=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
    for QNqBHzxTJnjpuWeOgIXblPKkrwiYho in QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['bottom_taglist']:
     if QNqBHzxTJnjpuWeOgIXblPKkrwiYho=='won':
      QNqBHzxTJnjpuWeOgIXblPKkrwiYoV=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE
      break
    if QNqBHzxTJnjpuWeOgIXblPKkrwiYoV==QNqBHzxTJnjpuWeOgIXblPKkrwiYcE: 
     QNqBHzxTJnjpuWeOgIXblPKkrwiYoD['title']=QNqBHzxTJnjpuWeOgIXblPKkrwiYoD['title']+' [개별구매]'
    if QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('age')!='21':
     QNqBHzxTJnjpuWeOgIXblPKkrwiYos.append(QNqBHzxTJnjpuWeOgIXblPKkrwiYoD)
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoy=QNqBHzxTJnjpuWeOgIXblPKkrwiYcD(QNqBHzxTJnjpuWeOgIXblPKkrwiYoG['band']['pagecount'])
   if QNqBHzxTJnjpuWeOgIXblPKkrwiYoG['band']['count']:QNqBHzxTJnjpuWeOgIXblPKkrwiYhA =QNqBHzxTJnjpuWeOgIXblPKkrwiYcD(QNqBHzxTJnjpuWeOgIXblPKkrwiYoG['band']['count'])
   else:QNqBHzxTJnjpuWeOgIXblPKkrwiYhA=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.LIST_LIMIT
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoF=QNqBHzxTJnjpuWeOgIXblPKkrwiYoy>QNqBHzxTJnjpuWeOgIXblPKkrwiYhA
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception)
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF 
 def Get_Search_Tving(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,search_key,sType,page_int):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYos=[]
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoF=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
  try:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYhf ='/search/getSearch.jsp'
   QNqBHzxTJnjpuWeOgIXblPKkrwiYhc={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(page_int),'pageSize':QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_PARMAS.get('SCREENCODE'),'os':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_PARMAS.get('OSCODE'),'network':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_LIMIT)if sType=='TVSHOW' else '0','vodMVReqCnt':QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_LIMIT)if sType=='MOVIE' else '0','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_PARMAS.get('APIKEY'),'networkCode':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_PARMAS.get('NETWORKCODE'),'osCode ':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_PARMAS.get('OSCODE'),'teleCode ':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_PARMAS.get('TELECODE'),'screenCode ':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_PARMAS.get('SCREENCODE')}
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoS=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_TVING_SEARCH+QNqBHzxTJnjpuWeOgIXblPKkrwiYhf
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.Call_Request(QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,payload=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,params=QNqBHzxTJnjpuWeOgIXblPKkrwiYhc,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,cookies=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,method='GET')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYhC=json.loads(QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.text)
   if sType=='TVSHOW':
    if not('programRsb' in QNqBHzxTJnjpuWeOgIXblPKkrwiYhC):return QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhs=QNqBHzxTJnjpuWeOgIXblPKkrwiYhC['programRsb']['dataList']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhy =QNqBHzxTJnjpuWeOgIXblPKkrwiYcD(QNqBHzxTJnjpuWeOgIXblPKkrwiYhC['programRsb']['count'])
    for QNqBHzxTJnjpuWeOgIXblPKkrwiYoM in QNqBHzxTJnjpuWeOgIXblPKkrwiYhs:
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhF=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['mast_cd']
     QNqBHzxTJnjpuWeOgIXblPKkrwiYot =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['mast_nm']
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhS=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_TVING_IMG+QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['web_url4']
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhU =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_TVING_IMG+QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['web_url']
     try:
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhG =[]
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhv=[]
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhM =[]
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhm =0
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhL =''
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhR =''
      QNqBHzxTJnjpuWeOgIXblPKkrwiYha =''
      if QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('actor') !='' and QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('actor') !='-':QNqBHzxTJnjpuWeOgIXblPKkrwiYhG =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('actor').split(',')
      if QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('director')!='' and QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('director')!='-':QNqBHzxTJnjpuWeOgIXblPKkrwiYhv=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('director').split(',')
      if QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('cate_nm')!='' and QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('cate_nm')!='-':QNqBHzxTJnjpuWeOgIXblPKkrwiYhM =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('cate_nm').split('/')
      if 'targetage' in QNqBHzxTJnjpuWeOgIXblPKkrwiYoM:QNqBHzxTJnjpuWeOgIXblPKkrwiYhL=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('targetage')
      if 'broad_dt' in QNqBHzxTJnjpuWeOgIXblPKkrwiYoM:
       QNqBHzxTJnjpuWeOgIXblPKkrwiYhE=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('broad_dt')
       QNqBHzxTJnjpuWeOgIXblPKkrwiYha='%s-%s-%s'%(QNqBHzxTJnjpuWeOgIXblPKkrwiYhE[:4],QNqBHzxTJnjpuWeOgIXblPKkrwiYhE[4:6],QNqBHzxTJnjpuWeOgIXblPKkrwiYhE[6:])
       QNqBHzxTJnjpuWeOgIXblPKkrwiYhR =QNqBHzxTJnjpuWeOgIXblPKkrwiYhE[:4]
     except:
      QNqBHzxTJnjpuWeOgIXblPKkrwiYca
     QNqBHzxTJnjpuWeOgIXblPKkrwiYoD={'title':QNqBHzxTJnjpuWeOgIXblPKkrwiYot,}
     QNqBHzxTJnjpuWeOgIXblPKkrwiYos.append(QNqBHzxTJnjpuWeOgIXblPKkrwiYoD)
   else:
    if not('vodMVRsb' in QNqBHzxTJnjpuWeOgIXblPKkrwiYhC):return QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF
    QNqBHzxTJnjpuWeOgIXblPKkrwiYht=QNqBHzxTJnjpuWeOgIXblPKkrwiYhC['vodMVRsb']['dataList']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhy =QNqBHzxTJnjpuWeOgIXblPKkrwiYcD(QNqBHzxTJnjpuWeOgIXblPKkrwiYhC['vodMVRsb']['count'])
    QNqBHzxTJnjpuWeOgIXblPKkrwiYct(QNqBHzxTJnjpuWeOgIXblPKkrwiYhy)
    for QNqBHzxTJnjpuWeOgIXblPKkrwiYoM in QNqBHzxTJnjpuWeOgIXblPKkrwiYht:
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhF=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['mast_cd']
     QNqBHzxTJnjpuWeOgIXblPKkrwiYot =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['mast_nm'].strip()
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhS =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_TVING_IMG+QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['web_url']
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhU =QNqBHzxTJnjpuWeOgIXblPKkrwiYhS
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhd=''
     try:
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhG =[]
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhv=[]
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhM =[]
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhm =0
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhL =''
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhR =''
      QNqBHzxTJnjpuWeOgIXblPKkrwiYha =''
      if QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('actor') !='' and QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('actor') !='-':QNqBHzxTJnjpuWeOgIXblPKkrwiYhG =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('actor').split(',')
      if QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('director')!='' and QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('director')!='-':QNqBHzxTJnjpuWeOgIXblPKkrwiYhv=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('director').split(',')
      if QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('cate_nm')!='' and QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('cate_nm')!='-':QNqBHzxTJnjpuWeOgIXblPKkrwiYhM =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('cate_nm').split('/')
      if QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('runtime_sec')!='':QNqBHzxTJnjpuWeOgIXblPKkrwiYhm=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('runtime_sec')
      if 'grade_nm' in QNqBHzxTJnjpuWeOgIXblPKkrwiYoM:QNqBHzxTJnjpuWeOgIXblPKkrwiYhL=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('grade_nm')
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhD=''
      QNqBHzxTJnjpuWeOgIXblPKkrwiYhE=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('broad_dt')
      if QNqBHzxTJnjpuWeOgIXblPKkrwiYhD!='':
       QNqBHzxTJnjpuWeOgIXblPKkrwiYha='%s-%s-%s'%(QNqBHzxTJnjpuWeOgIXblPKkrwiYhE[:4],QNqBHzxTJnjpuWeOgIXblPKkrwiYhE[4:6],QNqBHzxTJnjpuWeOgIXblPKkrwiYhE[6:])
       QNqBHzxTJnjpuWeOgIXblPKkrwiYhR =QNqBHzxTJnjpuWeOgIXblPKkrwiYhE[:4]
     except:
      QNqBHzxTJnjpuWeOgIXblPKkrwiYca
     QNqBHzxTJnjpuWeOgIXblPKkrwiYoD={'title':QNqBHzxTJnjpuWeOgIXblPKkrwiYot,}
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhV=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
     for QNqBHzxTJnjpuWeOgIXblPKkrwiYho in QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['bill']:
      if QNqBHzxTJnjpuWeOgIXblPKkrwiYho in QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_MOVIE_LITE:
       QNqBHzxTJnjpuWeOgIXblPKkrwiYhV=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE
       break
     if QNqBHzxTJnjpuWeOgIXblPKkrwiYhV==QNqBHzxTJnjpuWeOgIXblPKkrwiYcV: 
      QNqBHzxTJnjpuWeOgIXblPKkrwiYoD['title']=QNqBHzxTJnjpuWeOgIXblPKkrwiYoD['title']+' [개별구매]'
     QNqBHzxTJnjpuWeOgIXblPKkrwiYos.append(QNqBHzxTJnjpuWeOgIXblPKkrwiYoD)
   if QNqBHzxTJnjpuWeOgIXblPKkrwiYhy>(page_int*QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.TVING_LIMIT):QNqBHzxTJnjpuWeOgIXblPKkrwiYoF=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception)
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF
 def Get_Search_Watcha(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,search_key,page_int):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYos=[]
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoF=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
  try:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoS=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_WATCHA+'/api/search.json'
   QNqBHzxTJnjpuWeOgIXblPKkrwiYhc={'query':search_key,'page':QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(page_int),'per':QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.WATCHA_LIMIT),'exclude':'limited',}
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.Call_Request(QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,payload=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,params=QNqBHzxTJnjpuWeOgIXblPKkrwiYhc,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.WATCHA_HEADER,cookies=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,method='GET')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYhC=json.loads(QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.text)
   if not('results' in QNqBHzxTJnjpuWeOgIXblPKkrwiYhC):return QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAo=QNqBHzxTJnjpuWeOgIXblPKkrwiYhC['results']
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoF=QNqBHzxTJnjpuWeOgIXblPKkrwiYhC['meta']['has_next']
   for QNqBHzxTJnjpuWeOgIXblPKkrwiYoM in QNqBHzxTJnjpuWeOgIXblPKkrwiYAo:
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAh =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['code']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAf=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['content_type']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAc =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['title']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAC =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['story']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhS=QNqBHzxTJnjpuWeOgIXblPKkrwiYhU=QNqBHzxTJnjpuWeOgIXblPKkrwiYcS=''
    if QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('poster') !=QNqBHzxTJnjpuWeOgIXblPKkrwiYca:QNqBHzxTJnjpuWeOgIXblPKkrwiYhS=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('poster').get('original')
    if QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('stillcut')!=QNqBHzxTJnjpuWeOgIXblPKkrwiYca:QNqBHzxTJnjpuWeOgIXblPKkrwiYhU =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('stillcut').get('large')
    if QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('thumbnail')!=QNqBHzxTJnjpuWeOgIXblPKkrwiYca:QNqBHzxTJnjpuWeOgIXblPKkrwiYcS=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('thumbnail').get('large')
    if QNqBHzxTJnjpuWeOgIXblPKkrwiYcS=='' :QNqBHzxTJnjpuWeOgIXblPKkrwiYcS=QNqBHzxTJnjpuWeOgIXblPKkrwiYhU
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAs={'thumb':QNqBHzxTJnjpuWeOgIXblPKkrwiYhU,'poster':QNqBHzxTJnjpuWeOgIXblPKkrwiYhS,'fanart':QNqBHzxTJnjpuWeOgIXblPKkrwiYcS}
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhR =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['year']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAy =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['film_rating_code']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAF=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['film_rating_short']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAS =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['film_rating_long']
    if QNqBHzxTJnjpuWeOgIXblPKkrwiYAf=='movies':
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhm =QNqBHzxTJnjpuWeOgIXblPKkrwiYoM['duration']
    else:
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhm ='0'
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoD={'title':QNqBHzxTJnjpuWeOgIXblPKkrwiYAc,}
    QNqBHzxTJnjpuWeOgIXblPKkrwiYos.append(QNqBHzxTJnjpuWeOgIXblPKkrwiYoD)
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception)
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF
 def Get_Search_Coupang(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,search_key,page_int):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYos=[]
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoF=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
  try:
   CP=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.jsonfile_To_dic(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.CP_ORIGINAL_COOKIE)
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoS=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_COUPANG+'/api-discover/v2/search' 
   QNqBHzxTJnjpuWeOgIXblPKkrwiYhc={'query':search_key,'platform':'WEBCLIENT','page':QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(page_int),'perPage':QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.COUPANG_LIMIT),}
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAU={'x-membersrl':CP['COOKIES']['member_srl'],'x-pcid':CP['COOKIES']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.Call_Request(QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,payload=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,params=QNqBHzxTJnjpuWeOgIXblPKkrwiYhc,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYAU,cookies=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,method='GET')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoG=json.loads(QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.text)
   if QNqBHzxTJnjpuWeOgIXblPKkrwiYCA(QNqBHzxTJnjpuWeOgIXblPKkrwiYoG.get('data').get('data'))==0:return QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF
   for QNqBHzxTJnjpuWeOgIXblPKkrwiYoM in QNqBHzxTJnjpuWeOgIXblPKkrwiYoG.get('data').get('data'):
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoM=QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('data')
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoD={'title':QNqBHzxTJnjpuWeOgIXblPKkrwiYoM.get('title'),}
    QNqBHzxTJnjpuWeOgIXblPKkrwiYos.append(QNqBHzxTJnjpuWeOgIXblPKkrwiYoD)
   if QNqBHzxTJnjpuWeOgIXblPKkrwiYoG.get('pagination').get('totalPages')>page_int:
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoF=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception)
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF
 def Selenium_Cookies_Load(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,in_filename):
  fp=QNqBHzxTJnjpuWeOgIXblPKkrwiYCf(in_filename,'rb',-1)
  try:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAG=pickle.loads(fp.read())
   if QNqBHzxTJnjpuWeOgIXblPKkrwiYCc(QNqBHzxTJnjpuWeOgIXblPKkrwiYAG)==QNqBHzxTJnjpuWeOgIXblPKkrwiYCs:
    for QNqBHzxTJnjpuWeOgIXblPKkrwiYAv in QNqBHzxTJnjpuWeOgIXblPKkrwiYAG:
     QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.HTTP_CLIENT.cookies.set_cookie(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.To_Cookielib(QNqBHzxTJnjpuWeOgIXblPKkrwiYAv)) 
   else:
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.HTTP_CLIENT.cookies.update(QNqBHzxTJnjpuWeOgIXblPKkrwiYAG) 
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception)
  finally:
   fp.close()
 def To_Cookielib(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,selenium_cookie):
  return http.cookiejar.Cookie(version=0,name=selenium_cookie['name'],value=selenium_cookie['value'],port=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,port_specified=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV,domain=selenium_cookie['domain'],domain_specified=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE,domain_initial_dot=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV,path=selenium_cookie['path'],path_specified=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE,secure=selenium_cookie['secure'],expires=selenium_cookie['expiry'],discard=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV,comment=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,comment_url=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,rest={'HttpOnly':selenium_cookie['httpOnly']},rfc2109=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV,)
 def Get_Search_Primev(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,search_key):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYos=[]
  try:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.PV=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.jsonfile_To_dic(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.PV_ORIGINAL_COOKIE)
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAm=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.PV['COOKIES']
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAU={'accept':'application/json','x-requested-with':'WebSPA',}
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAL ='dvWebSPAClientVersion=1.0.110699.0'
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoS='https://www.primevideo.com/region/fe/search/ref=atv_nb_sug?ie=UTF8&phrase={}&{}'.format(urllib.parse.quote_plus(search_key),QNqBHzxTJnjpuWeOgIXblPKkrwiYAL)
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.Call_Request(QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,params=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYAU,cookies=QNqBHzxTJnjpuWeOgIXblPKkrwiYAm,method='GET')
   if QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.status_code!=200:return[]
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAR=json.loads(QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.text)
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAR=QNqBHzxTJnjpuWeOgIXblPKkrwiYAR['page'][0]['assembly']['body'][0]['props']['search']['containers'][0]
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAa=QNqBHzxTJnjpuWeOgIXblPKkrwiYAR.get('entities')
   for QNqBHzxTJnjpuWeOgIXblPKkrwiYAE in QNqBHzxTJnjpuWeOgIXblPKkrwiYAa:
    if 'titleID' not in QNqBHzxTJnjpuWeOgIXblPKkrwiYAE:return[]
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoD={'title':QNqBHzxTJnjpuWeOgIXblPKkrwiYAE.get('title'),}
    QNqBHzxTJnjpuWeOgIXblPKkrwiYos.append(QNqBHzxTJnjpuWeOgIXblPKkrwiYoD)
   '''
   TAG_RESULT = '{"props":{"containers"'
   JSON_REGEX = r'<script type="text/template">\s*(.*?)\s*</script>'
   text_array = re.compile(JSON_REGEX, re.DOTALL).findall(response.text )
   json_str = '{}'
   for cur_str in text_array:
    if TAG_RESULT in cur_str :
     json_str = cur_str
     break
   res_json = json.loads(json_str )
   self.dic_To_jsonfile(self.NF_CONTEXTJSON_FILE1, res_json ) #####
   # 검색 리스트 처리
   PORPS = res_json.get('props')
   for i_containers in PORPS.get('containers'):
    if i_containers.get('containerType') == 'Grid':
     ITEMS = i_containers.get('entities' )
     #OPTS  = i_containers                 
     break
   for i_item in ITEMS:
    if 'titleID' not in i_item: return [] # 검색시 리턴값 없을 때
    temp_list = {'title' : i_item.get('title'), }
    search_list.append(temp_list )
   '''   
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception)
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYos
 def Get_Search_Disney(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,search_key):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYos=[]
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoS ='{}/{}/search'.format(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_DISNEY,QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_DISNEY_VERSION)
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAU=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.make_DZ_Headers(accessToken=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE,Bearer=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE)
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoU ={'query':search_key,}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.Call_Request(QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,params=QNqBHzxTJnjpuWeOgIXblPKkrwiYoU,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYAU,cookies=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,method='GET')
  if QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.status_code not in[200,201]:return[]
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAt=QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.json().get('data').get('page').get('containers')
  for QNqBHzxTJnjpuWeOgIXblPKkrwiYAE in QNqBHzxTJnjpuWeOgIXblPKkrwiYAt[0]['items']:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoD={'title':QNqBHzxTJnjpuWeOgIXblPKkrwiYAE['visuals']['title'],}
   QNqBHzxTJnjpuWeOgIXblPKkrwiYos.append(QNqBHzxTJnjpuWeOgIXblPKkrwiYoD)
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYos
 def Get_Search_Disney_back(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,search_key):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYos=[]
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoS=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['services']['content']['getSearchResults']['href']
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAd={'apiVersion':'5.1','region':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge','pageSize':QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DISNEY_LIMIT),'query':search_key,}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoS=QNqBHzxTJnjpuWeOgIXblPKkrwiYoS.format(**QNqBHzxTJnjpuWeOgIXblPKkrwiYAd)
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAU=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.make_DZ_Headers(accessToken=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE,Bearer=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE)
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.Call_Request(QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYAU,cookies=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,method='GET')
  if QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.status_code not in[200,201]:return[]
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAt=QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.json().get('data').get('search')
  for QNqBHzxTJnjpuWeOgIXblPKkrwiYAE in QNqBHzxTJnjpuWeOgIXblPKkrwiYAt.get('hits'):
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAE=QNqBHzxTJnjpuWeOgIXblPKkrwiYAE.get('hit')
   if QNqBHzxTJnjpuWeOgIXblPKkrwiYAE.get('type')=='DmcSeries': 
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAc =QNqBHzxTJnjpuWeOgIXblPKkrwiYAE.get('text').get('title').get('full').get('series').get('default').get('content')
   elif QNqBHzxTJnjpuWeOgIXblPKkrwiYAE.get('type')=='DmcVideo':
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAc =QNqBHzxTJnjpuWeOgIXblPKkrwiYAE.get('text').get('title').get('full').get('program').get('default').get('content')
   elif QNqBHzxTJnjpuWeOgIXblPKkrwiYAE.get('type')=='StandardCollection':
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAc =QNqBHzxTJnjpuWeOgIXblPKkrwiYAE.get('text').get('title').get('full').get('collection').get('default').get('content')
   else:
    return QNqBHzxTJnjpuWeOgIXblPKkrwiYos
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoD={'title':QNqBHzxTJnjpuWeOgIXblPKkrwiYAc,}
   QNqBHzxTJnjpuWeOgIXblPKkrwiYos.append(QNqBHzxTJnjpuWeOgIXblPKkrwiYoD)
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYos
 def dic_To_jsonfile(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,filename,QNqBHzxTJnjpuWeOgIXblPKkrwiYAD):
  if filename=='':return
  fp=QNqBHzxTJnjpuWeOgIXblPKkrwiYCf(filename,'w',-1,'utf-8')
  json.dump(QNqBHzxTJnjpuWeOgIXblPKkrwiYAD,fp,indent=4,ensure_ascii=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV)
  fp.close()
 def jsonfile_To_dic(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,filename):
  if filename=='':return QNqBHzxTJnjpuWeOgIXblPKkrwiYca
  try:
   fp=QNqBHzxTJnjpuWeOgIXblPKkrwiYCf(filename,'r',-1,'utf-8')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfo=json.load(fp)
   fp.close()
  except:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfo={}
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYfo
 def tempFileSave(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,filename,resText):
  if filename=='':return
  fp=QNqBHzxTJnjpuWeOgIXblPKkrwiYCf(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,filename):
  if filename=='':return
  try:
   fp=QNqBHzxTJnjpuWeOgIXblPKkrwiYCf(filename,'r',-1,'utf-8')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfo=fp.read()
   fp.close()
  except:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfo=''
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYfo
 def make_DZ_Headers(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,accessToken=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE,Bearer=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV):
  if accessToken:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfh=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['account']['accessToken']
  else:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfh=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['headers']['clientApiKey']
  if Bearer:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfh='Bearer {}'.format(QNqBHzxTJnjpuWeOgIXblPKkrwiYfh)
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAU={'authorization':QNqBHzxTJnjpuWeOgIXblPKkrwiYfh,'x-application-version':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['headers']['sdkAppVersion'],'x-bamsdk-client-id':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['headers']['clientId'],'x-bamsdk-platform':'javascript/windows/chrome','x-bamsdk-version':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['headers']['sdkVersion'],'x-dss-edge-accept':'vnd.dss.edge+json; version=2',}
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYAU
 def DZ_ReToken(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA):
  try:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoS =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['services']['orchestration']['refreshToken']['href']
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAU=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.make_DZ_Headers(accessToken=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV,Bearer=QNqBHzxTJnjpuWeOgIXblPKkrwiYcV)
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfA={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['account']['refreshToken'],}}}
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.Call_Request(QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,json=QNqBHzxTJnjpuWeOgIXblPKkrwiYfA,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYAU,cookies=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,method='POST')
   if QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.status_code not in[200,201]:return QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAt=QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.json()
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['account']['accessToken'] =QNqBHzxTJnjpuWeOgIXblPKkrwiYAt.get('extensions').get('sdk').get('token').get('accessToken')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['account']['accessTokenType']=QNqBHzxTJnjpuWeOgIXblPKkrwiYAt.get('extensions').get('sdk').get('token').get('accessTokenType')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['account']['refreshToken'] =QNqBHzxTJnjpuWeOgIXblPKkrwiYAt.get('extensions').get('sdk').get('token').get('refreshToken')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['account']['token_limit'] =QNqBHzxTJnjpuWeOgIXblPKkrwiYcD(time.time())+14400 
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['account']['deviceId'] =QNqBHzxTJnjpuWeOgIXblPKkrwiYAt.get('extensions').get('sdk').get('session').get('device').get('id')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DZ['account']['sessionId'] =QNqBHzxTJnjpuWeOgIXblPKkrwiYAt.get('extensions').get('sdk').get('session').get('sessionId')
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception)
   return QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYcE
 def Init_NF_Total(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF={}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['COOKIES']={}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']={}
 def make_NF_XnetflixHeaders(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAU={'x-netflix.browsername':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['esnModel'],'x-netflix.esnprefix':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['nowGuid'],'x-netflix.uiversion':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYAU
 def make_NF_ApiParams(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoU={'avif':'false','webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','isTop10KidsSupported':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/mre/pathEvaluator',}
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYoU
 def extract_json(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,content,name):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfc=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfC=QNqBHzxTJnjpuWeOgIXblPKkrwiYca
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfs=re.compile(QNqBHzxTJnjpuWeOgIXblPKkrwiYfc.format(name),re.DOTALL).findall(content)
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfC=QNqBHzxTJnjpuWeOgIXblPKkrwiYfs[0]
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfy=QNqBHzxTJnjpuWeOgIXblPKkrwiYfC.replace('\\"','\\\\"') 
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfy=QNqBHzxTJnjpuWeOgIXblPKkrwiYfy.replace('\\s','\\\\s') 
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfy=QNqBHzxTJnjpuWeOgIXblPKkrwiYfy.replace('\\n','\\\\n') 
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfy=QNqBHzxTJnjpuWeOgIXblPKkrwiYfy.replace('\\t','\\\\t') 
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfy=QNqBHzxTJnjpuWeOgIXblPKkrwiYfy.encode().decode('unicode_escape') 
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfy=re.sub(r'\\(?!["])',r'\\\\',QNqBHzxTJnjpuWeOgIXblPKkrwiYfy) 
  return json.loads(QNqBHzxTJnjpuWeOgIXblPKkrwiYfy)
 def NF_makestr_paths(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,paths):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfo=[]
  if QNqBHzxTJnjpuWeOgIXblPKkrwiYCy(paths,QNqBHzxTJnjpuWeOgIXblPKkrwiYcD):
   return '%d'%(paths)
  elif QNqBHzxTJnjpuWeOgIXblPKkrwiYCy(paths,QNqBHzxTJnjpuWeOgIXblPKkrwiYcd):
   return '"%s"'%(paths)
  for QNqBHzxTJnjpuWeOgIXblPKkrwiYfF in paths:
   if QNqBHzxTJnjpuWeOgIXblPKkrwiYCy(QNqBHzxTJnjpuWeOgIXblPKkrwiYfF,QNqBHzxTJnjpuWeOgIXblPKkrwiYcD):
    QNqBHzxTJnjpuWeOgIXblPKkrwiYfo.append('%d'%(QNqBHzxTJnjpuWeOgIXblPKkrwiYfF))
   elif QNqBHzxTJnjpuWeOgIXblPKkrwiYCy(QNqBHzxTJnjpuWeOgIXblPKkrwiYfF,QNqBHzxTJnjpuWeOgIXblPKkrwiYcd):
    QNqBHzxTJnjpuWeOgIXblPKkrwiYfo.append('"%s"'%(QNqBHzxTJnjpuWeOgIXblPKkrwiYfF))
   elif QNqBHzxTJnjpuWeOgIXblPKkrwiYCy(QNqBHzxTJnjpuWeOgIXblPKkrwiYfF,QNqBHzxTJnjpuWeOgIXblPKkrwiYCs):
    QNqBHzxTJnjpuWeOgIXblPKkrwiYfo.append('[%s]'%(','.join(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_makestr_paths(QNqBHzxTJnjpuWeOgIXblPKkrwiYfF))))
   elif QNqBHzxTJnjpuWeOgIXblPKkrwiYCy(QNqBHzxTJnjpuWeOgIXblPKkrwiYfF,QNqBHzxTJnjpuWeOgIXblPKkrwiYCo):
    QNqBHzxTJnjpuWeOgIXblPKkrwiYfS=''
    for QNqBHzxTJnjpuWeOgIXblPKkrwiYfU,QNqBHzxTJnjpuWeOgIXblPKkrwiYfG in QNqBHzxTJnjpuWeOgIXblPKkrwiYfF.items():
     QNqBHzxTJnjpuWeOgIXblPKkrwiYfS+='"%s":%s,'%(QNqBHzxTJnjpuWeOgIXblPKkrwiYfU,QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_makestr_paths(QNqBHzxTJnjpuWeOgIXblPKkrwiYfG))
    QNqBHzxTJnjpuWeOgIXblPKkrwiYfo.append('{%s}'%(QNqBHzxTJnjpuWeOgIXblPKkrwiYfS[:-1]))
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYfo
 def NF_Call_pathapi(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,QNqBHzxTJnjpuWeOgIXblPKkrwiYfD,referer=''):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfv='%s/nq/website/memberapi/%s/pathEvaluator'%(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_NETFLIX,QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['identifier'])
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfA={'path':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_makestr_paths(QNqBHzxTJnjpuWeOgIXblPKkrwiYfD),'authURL':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']['authURL']}
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoU=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.make_NF_ApiParams()
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAU={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_NETFLIX,'sec-ch-ua':'"Google Chrome";v="101", "Not)A;Brand";v="8", "Chromium";v="101"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':QNqBHzxTJnjpuWeOgIXblPKkrwiYAU['referer']=referer
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfM=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.make_NF_XnetflixHeaders()
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAU.update(QNqBHzxTJnjpuWeOgIXblPKkrwiYfM)
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAm=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_Get_DefaultCookies()
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAm['profilesNewSession']='0'
  try:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.Call_Request(QNqBHzxTJnjpuWeOgIXblPKkrwiYfv,payload=QNqBHzxTJnjpuWeOgIXblPKkrwiYfA,params=QNqBHzxTJnjpuWeOgIXblPKkrwiYoU,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYAU,cookies=QNqBHzxTJnjpuWeOgIXblPKkrwiYAm,method='POST')
   return QNqBHzxTJnjpuWeOgIXblPKkrwiYoc
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception)
   return QNqBHzxTJnjpuWeOgIXblPKkrwiYca
 def Get_Search_Netflix(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,search_key,page_int,byReference=''):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfm=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.DERECTOR_LIMIT
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfL =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.CAST_LIMIT
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfR =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.GENRE_LIMIT
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfa =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_LIMIT*(page_int-1)
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfE =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_LIMIT*page_int 
  QNqBHzxTJnjpuWeOgIXblPKkrwiYft="|%s"%(search_key)
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfd ='%s/search?%s'%(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfD=[["search","byTerm",QNqBHzxTJnjpuWeOgIXblPKkrwiYft,"titles",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_LIMIT,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"summary"],["search","byTerm",QNqBHzxTJnjpuWeOgIXblPKkrwiYft,"titles",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_LIMIT,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",QNqBHzxTJnjpuWeOgIXblPKkrwiYft,"titles",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_LIMIT,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference","boxarts",[QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND2,QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_PORT],"jpg"],["search","byTerm",QNqBHzxTJnjpuWeOgIXblPKkrwiYft,"titles",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_LIMIT,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference","interestingMoment",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND1,"jpg"],["search","byTerm",QNqBHzxTJnjpuWeOgIXblPKkrwiYft,"titles",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_LIMIT,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference","storyArt",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND2,"jpg"],["search","byTerm",QNqBHzxTJnjpuWeOgIXblPKkrwiYft,"titles",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_LIMIT,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference",["cast","creators","directors"],{"from":0,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfm},["id","name"]],["search","byTerm",QNqBHzxTJnjpuWeOgIXblPKkrwiYft,"titles",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_LIMIT,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference","genres",{"from":0,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfR},["id","name"]],["search","byTerm",QNqBHzxTJnjpuWeOgIXblPKkrwiYft,"titles",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NETFLIX_LIMIT,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LOGO,"png"],]
  else:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfD=[["search","byReference",byReference,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"summary"],["search","byReference",byReference,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference","boxarts",[QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND2,QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference","interestingMoment",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference","storyArt",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference",["cast","creators","directors"],{"from":0,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfm},["id","name"]],["search","byReference",byReference,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference","genres",{"from":0,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfR},["id","name"]],["search","byReference",byReference,{"from":QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,"to":QNqBHzxTJnjpuWeOgIXblPKkrwiYfE},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LOGO,"png"],]
  try:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_Call_pathapi(QNqBHzxTJnjpuWeOgIXblPKkrwiYfD,QNqBHzxTJnjpuWeOgIXblPKkrwiYfd)
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoG=json.loads(QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.text)
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception)
  (QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF,byReference)=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.Search_Netflix_Make(QNqBHzxTJnjpuWeOgIXblPKkrwiYoG)
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF,byReference
 def Search_Netflix_Make(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,jsonSource):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYos=[]
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoF =QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfV=''
  QNqBHzxTJnjpuWeOgIXblPKkrwiYco=jsonSource.get('paths')[0][1]
  if QNqBHzxTJnjpuWeOgIXblPKkrwiYco=='byTerm':
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfa =jsonSource['paths'][0][5]['from']
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfE =jsonSource['paths'][0][5]['to']
  else:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfa =jsonSource['paths'][0][3]['from']
   QNqBHzxTJnjpuWeOgIXblPKkrwiYfE =jsonSource['paths'][0][3]['to']
  QNqBHzxTJnjpuWeOgIXblPKkrwiYfV=QNqBHzxTJnjpuWeOgIXblPKkrwiYCs(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  QNqBHzxTJnjpuWeOgIXblPKkrwiYch=jsonSource.get('jsonGraph').get('search').get('byReference').get(QNqBHzxTJnjpuWeOgIXblPKkrwiYfV)
  QNqBHzxTJnjpuWeOgIXblPKkrwiYcA =jsonSource.get('jsonGraph').get('videos')
  QNqBHzxTJnjpuWeOgIXblPKkrwiYcf=jsonSource.get('jsonGraph').get('person')
  QNqBHzxTJnjpuWeOgIXblPKkrwiYcC=jsonSource.get('jsonGraph').get('genres')
  QNqBHzxTJnjpuWeOgIXblPKkrwiYoF=QNqBHzxTJnjpuWeOgIXblPKkrwiYcE if QNqBHzxTJnjpuWeOgIXblPKkrwiYch[QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYfE)]['reference']['$type']=='ref' else QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
  for QNqBHzxTJnjpuWeOgIXblPKkrwiYcs in QNqBHzxTJnjpuWeOgIXblPKkrwiYCF(QNqBHzxTJnjpuWeOgIXblPKkrwiYfa,QNqBHzxTJnjpuWeOgIXblPKkrwiYfE):
   if QNqBHzxTJnjpuWeOgIXblPKkrwiYch[QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYcs)]['reference']['$type']=='ref':
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoE =QNqBHzxTJnjpuWeOgIXblPKkrwiYch[QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(QNqBHzxTJnjpuWeOgIXblPKkrwiYcs)]['reference']['value'][1]
    QNqBHzxTJnjpuWeOgIXblPKkrwiYcy=QNqBHzxTJnjpuWeOgIXblPKkrwiYcA[QNqBHzxTJnjpuWeOgIXblPKkrwiYoE]
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAc =QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['title']['value']
    if QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['availability']['value']['isPlayable']==QNqBHzxTJnjpuWeOgIXblPKkrwiYcV:
     continue
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoR =QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['summary']['value']['type']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhm =0 if QNqBHzxTJnjpuWeOgIXblPKkrwiYoR!='movie' else QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['runtime']['value']
    if QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['sequiturEvidence']['value']['value']:
     QNqBHzxTJnjpuWeOgIXblPKkrwiYcF=QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['sequiturEvidence']['value']['value']['text']
    else:
     QNqBHzxTJnjpuWeOgIXblPKkrwiYcF=''
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhS =QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['boxarts'][QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_PORT]['jpg']['value']['url']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYcS =QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['boxarts'][QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND2]['jpg']['value']['url']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhU=''
    if 'value' in QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['storyArt'][QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND2]['jpg']:
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhU =QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['storyArt'][QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND2]['jpg']['value']['url']
    if QNqBHzxTJnjpuWeOgIXblPKkrwiYhU=='' and 'value' in QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['interestingMoment'][QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND1]['jpg']:
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhU =QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['interestingMoment'][QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LAND1]['jpg']['value']['url']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhd=''
    if 'value' in QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LOGO]['png']:
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhd=QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.ART_SIZE_LOGO]['png']['value']['url']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhM =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_Subid_List(QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['genres'])
    for i in QNqBHzxTJnjpuWeOgIXblPKkrwiYCF(QNqBHzxTJnjpuWeOgIXblPKkrwiYCA(QNqBHzxTJnjpuWeOgIXblPKkrwiYhM)):
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhM[i]=QNqBHzxTJnjpuWeOgIXblPKkrwiYcC[QNqBHzxTJnjpuWeOgIXblPKkrwiYhM[i]]['name']['value']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhv=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_Subid_List(QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['directors'])
    QNqBHzxTJnjpuWeOgIXblPKkrwiYcU =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_Subid_List(QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['creators'])
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhv.extend(QNqBHzxTJnjpuWeOgIXblPKkrwiYcU)
    for i in QNqBHzxTJnjpuWeOgIXblPKkrwiYCF(QNqBHzxTJnjpuWeOgIXblPKkrwiYCA(QNqBHzxTJnjpuWeOgIXblPKkrwiYhv)):
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhv[i]=QNqBHzxTJnjpuWeOgIXblPKkrwiYcf[QNqBHzxTJnjpuWeOgIXblPKkrwiYhv[i]]['name']['value']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYhG=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_Subid_List(QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['cast'])
    for i in QNqBHzxTJnjpuWeOgIXblPKkrwiYCF(QNqBHzxTJnjpuWeOgIXblPKkrwiYCA(QNqBHzxTJnjpuWeOgIXblPKkrwiYhG)):
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhG[i]=QNqBHzxTJnjpuWeOgIXblPKkrwiYcf[QNqBHzxTJnjpuWeOgIXblPKkrwiYhG[i]]['name']['value']
    if 'maturityDescription' in QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['maturity']['value']['rating']:
     QNqBHzxTJnjpuWeOgIXblPKkrwiYhL=QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['maturity']['value']['rating']['maturityDescription']
    QNqBHzxTJnjpuWeOgIXblPKkrwiYoD={'videoid':QNqBHzxTJnjpuWeOgIXblPKkrwiYoE,'vidtype':QNqBHzxTJnjpuWeOgIXblPKkrwiYoR,'title':QNqBHzxTJnjpuWeOgIXblPKkrwiYAc,'mpaa':QNqBHzxTJnjpuWeOgIXblPKkrwiYhL,'regularSynopsis':QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['regularSynopsis']['value'],'dpSupplemental':QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['dpSupplementalMessage']['value'],'sequiturEvidence':QNqBHzxTJnjpuWeOgIXblPKkrwiYcF,'thumbnail':{'poster':QNqBHzxTJnjpuWeOgIXblPKkrwiYhS,'thumb':QNqBHzxTJnjpuWeOgIXblPKkrwiYhU,'fanart':QNqBHzxTJnjpuWeOgIXblPKkrwiYcS,'clearlogo':QNqBHzxTJnjpuWeOgIXblPKkrwiYhd},'year':QNqBHzxTJnjpuWeOgIXblPKkrwiYcy['releaseYear']['value'],'duration':QNqBHzxTJnjpuWeOgIXblPKkrwiYhm,'info_genre':QNqBHzxTJnjpuWeOgIXblPKkrwiYhM,'director':QNqBHzxTJnjpuWeOgIXblPKkrwiYhv,'cast':QNqBHzxTJnjpuWeOgIXblPKkrwiYhG,}
    QNqBHzxTJnjpuWeOgIXblPKkrwiYos.append(QNqBHzxTJnjpuWeOgIXblPKkrwiYoD)
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYos,QNqBHzxTJnjpuWeOgIXblPKkrwiYoF,QNqBHzxTJnjpuWeOgIXblPKkrwiYfV
 def NF_Subid_List(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,subJson):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYcG=[]
  try:
   for i in QNqBHzxTJnjpuWeOgIXblPKkrwiYCF(QNqBHzxTJnjpuWeOgIXblPKkrwiYCA(subJson)):
    if subJson.get(QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(i)).get('$type')!='ref':break
    QNqBHzxTJnjpuWeOgIXblPKkrwiYcv=subJson.get(QNqBHzxTJnjpuWeOgIXblPKkrwiYcd(i)).get('value')[1]
    QNqBHzxTJnjpuWeOgIXblPKkrwiYcG.append(QNqBHzxTJnjpuWeOgIXblPKkrwiYcv)
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception)
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYcG
 def NF_CookieFile_Load(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA,cookie_filename):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAm={}
  try:
   if os.path.isfile(cookie_filename)==QNqBHzxTJnjpuWeOgIXblPKkrwiYcV:return{}
   QNqBHzxTJnjpuWeOgIXblPKkrwiYcM=QNqBHzxTJnjpuWeOgIXblPKkrwiYCf(cookie_filename,'rb',-1)
   QNqBHzxTJnjpuWeOgIXblPKkrwiYcm =pickle.loads(QNqBHzxTJnjpuWeOgIXblPKkrwiYcM.read())
   QNqBHzxTJnjpuWeOgIXblPKkrwiYcM.close()
   for QNqBHzxTJnjpuWeOgIXblPKkrwiYAv in QNqBHzxTJnjpuWeOgIXblPKkrwiYcm:
    QNqBHzxTJnjpuWeOgIXblPKkrwiYAm[QNqBHzxTJnjpuWeOgIXblPKkrwiYAv.name]=QNqBHzxTJnjpuWeOgIXblPKkrwiYAv.value
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception) 
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYAm
 def NF_Get_DefaultCookies(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA):
  QNqBHzxTJnjpuWeOgIXblPKkrwiYAm={}
  if QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['COOKIES']['flwssn'] :QNqBHzxTJnjpuWeOgIXblPKkrwiYAm['flwssn'] =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['COOKIES']['flwssn']
  if QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['COOKIES']['nfvdid'] :QNqBHzxTJnjpuWeOgIXblPKkrwiYAm['nfvdid'] =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['COOKIES']['nfvdid']
  if QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['COOKIES']['SecureNetflixId']:QNqBHzxTJnjpuWeOgIXblPKkrwiYAm['SecureNetflixId']=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['COOKIES']['SecureNetflixId']
  if QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['COOKIES']['NetflixId'] :QNqBHzxTJnjpuWeOgIXblPKkrwiYAm['NetflixId'] =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['COOKIES']['NetflixId']
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYAm
 def NF_Get_BaseSession(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA):
  try:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoS=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.API_NETFLIX+'/browse' 
   QNqBHzxTJnjpuWeOgIXblPKkrwiYAm=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_Get_DefaultCookies()
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoc=QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.Call_Request(QNqBHzxTJnjpuWeOgIXblPKkrwiYoS,payload=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,params=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,headers=QNqBHzxTJnjpuWeOgIXblPKkrwiYca,cookies=QNqBHzxTJnjpuWeOgIXblPKkrwiYAm,method='GET')
   if QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.status_code!=200:
    QNqBHzxTJnjpuWeOgIXblPKkrwiYct('pass 1 status_code error')
    return QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
   QNqBHzxTJnjpuWeOgIXblPKkrwiYcL =QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.extract_json(QNqBHzxTJnjpuWeOgIXblPKkrwiYoc.text,'reactContext')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF['SESSION']={'mainGuid':QNqBHzxTJnjpuWeOgIXblPKkrwiYcL['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':QNqBHzxTJnjpuWeOgIXblPKkrwiYcL['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':QNqBHzxTJnjpuWeOgIXblPKkrwiYcL['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':QNqBHzxTJnjpuWeOgIXblPKkrwiYcL['models']['memberContext']['data']['userInfo']['esn'],'identifier':QNqBHzxTJnjpuWeOgIXblPKkrwiYcL['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':QNqBHzxTJnjpuWeOgIXblPKkrwiYcL['models']['abContext']['data']['headers'],}
   QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.dic_To_jsonfile(QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF_SESSION_COOKIES1,QNqBHzxTJnjpuWeOgIXblPKkrwiYoA.NF)
  except QNqBHzxTJnjpuWeOgIXblPKkrwiYCh as exception:
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct('pass 1 error')
   QNqBHzxTJnjpuWeOgIXblPKkrwiYct(exception)
   return QNqBHzxTJnjpuWeOgIXblPKkrwiYcV
  return QNqBHzxTJnjpuWeOgIXblPKkrwiYcE
# Created by pyminifier (https://github.com/liftoff/pyminifier)
