# -*- coding: utf-8 -*-

from http.cookiejar import CookieJar
from threading import RLock


class PickleableCookieJar(CookieJar):
	"""A pickleable CookieJar class"""
	# This code has been adapted from RequestsCookieJar of "Requests" module
	@classmethod
	def cast(cls, cookie_jar: CookieJar):
		"""Make a kind of cast to convert the class from CookieJar to PickleableCookieJar"""
		assert isinstance(cookie_jar, CookieJar)
		cookie_jar.__class__ = cls
		assert isinstance(cookie_jar, PickleableCookieJar)
		return cookie_jar

	def __getstate__(self):
		"""Unlike a normal CookieJar, this class is pickleable."""
		state = self.__dict__.copy()
		# remove the unpickleable RLock object
		state.pop('_cookies_lock')
		return state

	def __setstate__(self, state):
		"""Unlike a normal CookieJar, this class is pickleable."""
		self.__dict__.update(state)
		if '_cookies_lock' not in self.__dict__:
			self._cookies_lock = RLock()

