__author__="NightRain"
JyhkEwzNvnLieKrCgMcqAVaIGlUdTX=object
JyhkEwzNvnLieKrCgMcqAVaIGlUdTp=None
JyhkEwzNvnLieKrCgMcqAVaIGlUdTB=True
JyhkEwzNvnLieKrCgMcqAVaIGlUdTW=print
JyhkEwzNvnLieKrCgMcqAVaIGlUdsY=str
JyhkEwzNvnLieKrCgMcqAVaIGlUdsu=int
JyhkEwzNvnLieKrCgMcqAVaIGlUdsf=False
JyhkEwzNvnLieKrCgMcqAVaIGlUdsO=dict
JyhkEwzNvnLieKrCgMcqAVaIGlUdsT=Exception
JyhkEwzNvnLieKrCgMcqAVaIGlUdsx=len
JyhkEwzNvnLieKrCgMcqAVaIGlUdsb=open
JyhkEwzNvnLieKrCgMcqAVaIGlUdsP=type
JyhkEwzNvnLieKrCgMcqAVaIGlUdsm=list
JyhkEwzNvnLieKrCgMcqAVaIGlUdso=isinstance
JyhkEwzNvnLieKrCgMcqAVaIGlUdsj=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
import http.cookiejar
class JyhkEwzNvnLieKrCgMcqAVaIGlUdYu(JyhkEwzNvnLieKrCgMcqAVaIGlUdTX):
 def __init__(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_WAVVE ='https://apis.wavve.com'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_TVING_SEARCH='https://search-api.tving.com'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_TVING_IMG ='https://image.tving.com'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_WATCHA ='https://api-mars.watcha.com'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_NETFLIX ='https://www.netflix.com'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_COUPANG ='https://discover.coupangstreaming.com'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_PRIMEV ='https://www.primevideo.com'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.WAVVE_LIMIT =20 
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_LIMIT =30
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.WATCHA_LIMIT =30
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_LIMIT =20 
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.COUPANG_LIMIT =10 
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DISNEY_LIMIT =10 
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DERECTOR_LIMIT =4
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.CAST_LIMIT =10
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.GENRE_LIMIT =4
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_MOVIE_LITE=['2610061','2610161','261062']
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100','APIKEY':'1e7952d0917d6aab1f0293a063697610','TELECODE':'CSCD0900',}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_HEADER={'user-agent':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND1 ='_342x192'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND2 ='_665x375'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_PORT ='_342x684'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LOGO ='_550x124'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF={}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['COOKIES']={}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']={}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ={}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.PV={}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.HTTP_CLIENT=requests.Session()
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.CP_ORIGINAL_COOKIE =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.PV_ORIGINAL_COOKIE =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ_ORIGINAL_COOKIE =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_ORIGINAL_COOKIE =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_SESSION_COOKIES1 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_SESSION_COOKIES2 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_SESSION_COOKIES3 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_SESSION_COOKIES4 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_SESSION_FULLTEXT1 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_SESSION_FULLTEXT2 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_SESSION_FULLTEXT3 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_SESSION_FULLTEXT4 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_CONTEXTJSON_FILE1 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_CONTEXTJSON_FILE2 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_CONTEXTJSON_FILE3 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_CONTEXTJSON_FILE4 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_FALCORJSON_FILE1 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_FALCORJSON_FILE2 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_FALCORJSON_FILE3 =''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_FALCORJSON_FILE4 =''
 '''
 def callRequestCookies(self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):
  #setHeader = {'user-agent' : self.USER_AGENT }
  setHeader = self.DEFAULT_HEADER
  if headers: setHeader.update(headers )
  if jobtype == 'Get': # Get/Post
   res = requests.get(url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  else:
   res = requests.post(url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  return res
 ''' 
 def Call_Request(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,JyhkEwzNvnLieKrCgMcqAVaIGlUdYm,payload=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,json=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,params=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,cookies=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,redirects=JyhkEwzNvnLieKrCgMcqAVaIGlUdTB,method='-'):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYO={'user-agent':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.USER_AGENT}
  if headers:JyhkEwzNvnLieKrCgMcqAVaIGlUdYO.update(headers)
  if payload!=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp or method=='POST':
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.HTTP_CLIENT.post(url=JyhkEwzNvnLieKrCgMcqAVaIGlUdYm,data=payload,json=json,params=params,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdYO,cookies=cookies,allow_redirects=redirects)
  else:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.HTTP_CLIENT.get(url=JyhkEwzNvnLieKrCgMcqAVaIGlUdYm,params=params,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdYO,cookies=cookies,allow_redirects=redirects)
  JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.status_code)+' - '+JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.url))
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdYT
 def GetNoCache(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,timetype=1,minutes=0):
  if timetype==1:
   ts=JyhkEwzNvnLieKrCgMcqAVaIGlUdsu(time.time())
   mi=JyhkEwzNvnLieKrCgMcqAVaIGlUdsu(minutes*60)
  else:
   ts=JyhkEwzNvnLieKrCgMcqAVaIGlUdsu(time.time()*1000)
   mi=JyhkEwzNvnLieKrCgMcqAVaIGlUdsu(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,search_key,sType,page_int):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYx=[]
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYb=JyhkEwzNvnLieKrCgMcqAVaIGlUduf=1
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYP=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
  try:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYm=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_WAVVE+'/fz/search/band.js'
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYo={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':JyhkEwzNvnLieKrCgMcqAVaIGlUdsY((page_int-1)*JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.WAVVE_LIMIT),'limit':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.WAVVE_LIMIT,'orderby':'score','mtype':'svod',}
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYo.update(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.WAVVE_PARAMS)
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.Call_Request(JyhkEwzNvnLieKrCgMcqAVaIGlUdYm,payload=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,params=JyhkEwzNvnLieKrCgMcqAVaIGlUdYo,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,cookies=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,method='GET')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYj=json.loads(JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.text)
   if not('celllist' in JyhkEwzNvnLieKrCgMcqAVaIGlUdYj['band']):return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYt=JyhkEwzNvnLieKrCgMcqAVaIGlUdYj['band']['celllist']
   for JyhkEwzNvnLieKrCgMcqAVaIGlUdYF in JyhkEwzNvnLieKrCgMcqAVaIGlUdYt:
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYQ =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['event_list'][1]['url']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYS=urllib.parse.urlsplit(JyhkEwzNvnLieKrCgMcqAVaIGlUdYQ).query
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYH=JyhkEwzNvnLieKrCgMcqAVaIGlUdYS[0:JyhkEwzNvnLieKrCgMcqAVaIGlUdYS.find('=')]
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYD=JyhkEwzNvnLieKrCgMcqAVaIGlUdsO(urllib.parse.parse_qsl(JyhkEwzNvnLieKrCgMcqAVaIGlUdYS))
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYR=JyhkEwzNvnLieKrCgMcqAVaIGlUdYD.get(JyhkEwzNvnLieKrCgMcqAVaIGlUdYH)
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYH='TVSHOW' if JyhkEwzNvnLieKrCgMcqAVaIGlUdYH=='programid' else 'MOVIE' 
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYX=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['title_list'][0]['text']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYp =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['age']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYB={'title':JyhkEwzNvnLieKrCgMcqAVaIGlUdYX}
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYW=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
    for JyhkEwzNvnLieKrCgMcqAVaIGlUduY in JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['bottom_taglist']:
     if JyhkEwzNvnLieKrCgMcqAVaIGlUduY=='won':
      JyhkEwzNvnLieKrCgMcqAVaIGlUdYW=JyhkEwzNvnLieKrCgMcqAVaIGlUdTB
      break
    if JyhkEwzNvnLieKrCgMcqAVaIGlUdYW==JyhkEwzNvnLieKrCgMcqAVaIGlUdTB: 
     JyhkEwzNvnLieKrCgMcqAVaIGlUdYB['title']=JyhkEwzNvnLieKrCgMcqAVaIGlUdYB['title']+' [개별구매]'
    if JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('age')!='21':
     JyhkEwzNvnLieKrCgMcqAVaIGlUdYx.append(JyhkEwzNvnLieKrCgMcqAVaIGlUdYB)
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYb=JyhkEwzNvnLieKrCgMcqAVaIGlUdsu(JyhkEwzNvnLieKrCgMcqAVaIGlUdYj['band']['pagecount'])
   if JyhkEwzNvnLieKrCgMcqAVaIGlUdYj['band']['count']:JyhkEwzNvnLieKrCgMcqAVaIGlUduf =JyhkEwzNvnLieKrCgMcqAVaIGlUdsu(JyhkEwzNvnLieKrCgMcqAVaIGlUdYj['band']['count'])
   else:JyhkEwzNvnLieKrCgMcqAVaIGlUduf=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.LIST_LIMIT
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYP=JyhkEwzNvnLieKrCgMcqAVaIGlUdYb>JyhkEwzNvnLieKrCgMcqAVaIGlUduf
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception)
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP 
 def Get_Search_Tving(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,search_key,sType,page_int):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYx=[]
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYP=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
  try:
   JyhkEwzNvnLieKrCgMcqAVaIGlUduO ='/search/getSearch.jsp'
   JyhkEwzNvnLieKrCgMcqAVaIGlUduT={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(page_int),'pageSize':JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_PARMAS.get('SCREENCODE'),'os':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_PARMAS.get('OSCODE'),'network':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_LIMIT)if sType=='TVSHOW' else '0','vodMVReqCnt':JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_LIMIT)if sType=='MOVIE' else '0','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_PARMAS.get('APIKEY'),'networkCode':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_PARMAS.get('NETWORKCODE'),'osCode ':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_PARMAS.get('OSCODE'),'teleCode ':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_PARMAS.get('TELECODE'),'screenCode ':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_PARMAS.get('SCREENCODE')}
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYm=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_TVING_SEARCH+JyhkEwzNvnLieKrCgMcqAVaIGlUduO
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.Call_Request(JyhkEwzNvnLieKrCgMcqAVaIGlUdYm,payload=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,params=JyhkEwzNvnLieKrCgMcqAVaIGlUduT,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,cookies=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,method='GET')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdus=json.loads(JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.text)
   if sType=='TVSHOW':
    if not('programRsb' in JyhkEwzNvnLieKrCgMcqAVaIGlUdus):return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP
    JyhkEwzNvnLieKrCgMcqAVaIGlUdux=JyhkEwzNvnLieKrCgMcqAVaIGlUdus['programRsb']['dataList']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdub =JyhkEwzNvnLieKrCgMcqAVaIGlUdsu(JyhkEwzNvnLieKrCgMcqAVaIGlUdus['programRsb']['count'])
    for JyhkEwzNvnLieKrCgMcqAVaIGlUdYF in JyhkEwzNvnLieKrCgMcqAVaIGlUdux:
     JyhkEwzNvnLieKrCgMcqAVaIGlUduP=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['mast_cd']
     JyhkEwzNvnLieKrCgMcqAVaIGlUdYX =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['mast_nm']
     JyhkEwzNvnLieKrCgMcqAVaIGlUdum=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_TVING_IMG+JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['web_url4']
     JyhkEwzNvnLieKrCgMcqAVaIGlUduo =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_TVING_IMG+JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['web_url']
     try:
      JyhkEwzNvnLieKrCgMcqAVaIGlUduj =[]
      JyhkEwzNvnLieKrCgMcqAVaIGlUdut=[]
      JyhkEwzNvnLieKrCgMcqAVaIGlUduF =[]
      JyhkEwzNvnLieKrCgMcqAVaIGlUduQ =0
      JyhkEwzNvnLieKrCgMcqAVaIGlUduS =''
      JyhkEwzNvnLieKrCgMcqAVaIGlUduH =''
      JyhkEwzNvnLieKrCgMcqAVaIGlUduD =''
      if JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('actor') !='' and JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('actor') !='-':JyhkEwzNvnLieKrCgMcqAVaIGlUduj =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('actor').split(',')
      if JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('director')!='' and JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('director')!='-':JyhkEwzNvnLieKrCgMcqAVaIGlUdut=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('director').split(',')
      if JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('cate_nm')!='' and JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('cate_nm')!='-':JyhkEwzNvnLieKrCgMcqAVaIGlUduF =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('cate_nm').split('/')
      if 'targetage' in JyhkEwzNvnLieKrCgMcqAVaIGlUdYF:JyhkEwzNvnLieKrCgMcqAVaIGlUduS=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('targetage')
      if 'broad_dt' in JyhkEwzNvnLieKrCgMcqAVaIGlUdYF:
       JyhkEwzNvnLieKrCgMcqAVaIGlUduR=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('broad_dt')
       JyhkEwzNvnLieKrCgMcqAVaIGlUduD='%s-%s-%s'%(JyhkEwzNvnLieKrCgMcqAVaIGlUduR[:4],JyhkEwzNvnLieKrCgMcqAVaIGlUduR[4:6],JyhkEwzNvnLieKrCgMcqAVaIGlUduR[6:])
       JyhkEwzNvnLieKrCgMcqAVaIGlUduH =JyhkEwzNvnLieKrCgMcqAVaIGlUduR[:4]
     except:
      JyhkEwzNvnLieKrCgMcqAVaIGlUdTp
     JyhkEwzNvnLieKrCgMcqAVaIGlUdYB={'title':JyhkEwzNvnLieKrCgMcqAVaIGlUdYX,}
     JyhkEwzNvnLieKrCgMcqAVaIGlUdYx.append(JyhkEwzNvnLieKrCgMcqAVaIGlUdYB)
   else:
    if not('vodMVRsb' in JyhkEwzNvnLieKrCgMcqAVaIGlUdus):return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP
    JyhkEwzNvnLieKrCgMcqAVaIGlUduX=JyhkEwzNvnLieKrCgMcqAVaIGlUdus['vodMVRsb']['dataList']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdub =JyhkEwzNvnLieKrCgMcqAVaIGlUdsu(JyhkEwzNvnLieKrCgMcqAVaIGlUdus['vodMVRsb']['count'])
    JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(JyhkEwzNvnLieKrCgMcqAVaIGlUdub)
    for JyhkEwzNvnLieKrCgMcqAVaIGlUdYF in JyhkEwzNvnLieKrCgMcqAVaIGlUduX:
     JyhkEwzNvnLieKrCgMcqAVaIGlUduP=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['mast_cd']
     JyhkEwzNvnLieKrCgMcqAVaIGlUdYX =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['mast_nm'].strip()
     JyhkEwzNvnLieKrCgMcqAVaIGlUdum =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_TVING_IMG+JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['web_url']
     JyhkEwzNvnLieKrCgMcqAVaIGlUduo =JyhkEwzNvnLieKrCgMcqAVaIGlUdum
     JyhkEwzNvnLieKrCgMcqAVaIGlUdup=''
     try:
      JyhkEwzNvnLieKrCgMcqAVaIGlUduj =[]
      JyhkEwzNvnLieKrCgMcqAVaIGlUdut=[]
      JyhkEwzNvnLieKrCgMcqAVaIGlUduF =[]
      JyhkEwzNvnLieKrCgMcqAVaIGlUduQ =0
      JyhkEwzNvnLieKrCgMcqAVaIGlUduS =''
      JyhkEwzNvnLieKrCgMcqAVaIGlUduH =''
      JyhkEwzNvnLieKrCgMcqAVaIGlUduD =''
      if JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('actor') !='' and JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('actor') !='-':JyhkEwzNvnLieKrCgMcqAVaIGlUduj =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('actor').split(',')
      if JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('director')!='' and JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('director')!='-':JyhkEwzNvnLieKrCgMcqAVaIGlUdut=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('director').split(',')
      if JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('cate_nm')!='' and JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('cate_nm')!='-':JyhkEwzNvnLieKrCgMcqAVaIGlUduF =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('cate_nm').split('/')
      if JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('runtime_sec')!='':JyhkEwzNvnLieKrCgMcqAVaIGlUduQ=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('runtime_sec')
      if 'grade_nm' in JyhkEwzNvnLieKrCgMcqAVaIGlUdYF:JyhkEwzNvnLieKrCgMcqAVaIGlUduS=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('grade_nm')
      JyhkEwzNvnLieKrCgMcqAVaIGlUduB=''
      JyhkEwzNvnLieKrCgMcqAVaIGlUduR=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('broad_dt')
      if JyhkEwzNvnLieKrCgMcqAVaIGlUduB!='':
       JyhkEwzNvnLieKrCgMcqAVaIGlUduD='%s-%s-%s'%(JyhkEwzNvnLieKrCgMcqAVaIGlUduR[:4],JyhkEwzNvnLieKrCgMcqAVaIGlUduR[4:6],JyhkEwzNvnLieKrCgMcqAVaIGlUduR[6:])
       JyhkEwzNvnLieKrCgMcqAVaIGlUduH =JyhkEwzNvnLieKrCgMcqAVaIGlUduR[:4]
     except:
      JyhkEwzNvnLieKrCgMcqAVaIGlUdTp
     JyhkEwzNvnLieKrCgMcqAVaIGlUdYB={'title':JyhkEwzNvnLieKrCgMcqAVaIGlUdYX,}
     JyhkEwzNvnLieKrCgMcqAVaIGlUduW=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
     for JyhkEwzNvnLieKrCgMcqAVaIGlUduY in JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['bill']:
      if JyhkEwzNvnLieKrCgMcqAVaIGlUduY in JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_MOVIE_LITE:
       JyhkEwzNvnLieKrCgMcqAVaIGlUduW=JyhkEwzNvnLieKrCgMcqAVaIGlUdTB
       break
     if JyhkEwzNvnLieKrCgMcqAVaIGlUduW==JyhkEwzNvnLieKrCgMcqAVaIGlUdsf: 
      JyhkEwzNvnLieKrCgMcqAVaIGlUdYB['title']=JyhkEwzNvnLieKrCgMcqAVaIGlUdYB['title']+' [개별구매]'
     JyhkEwzNvnLieKrCgMcqAVaIGlUdYx.append(JyhkEwzNvnLieKrCgMcqAVaIGlUdYB)
   if JyhkEwzNvnLieKrCgMcqAVaIGlUdub>(page_int*JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.TVING_LIMIT):JyhkEwzNvnLieKrCgMcqAVaIGlUdYP=JyhkEwzNvnLieKrCgMcqAVaIGlUdTB
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception)
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP
 def Get_Search_Watcha(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,search_key,page_int):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYx=[]
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYP=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
  try:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYm=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_WATCHA+'/api/search.json'
   JyhkEwzNvnLieKrCgMcqAVaIGlUduT={'query':search_key,'page':JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(page_int),'per':JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.WATCHA_LIMIT),'exclude':'limited',}
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.Call_Request(JyhkEwzNvnLieKrCgMcqAVaIGlUdYm,payload=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,params=JyhkEwzNvnLieKrCgMcqAVaIGlUduT,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.WATCHA_HEADER,cookies=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,method='GET')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdus=json.loads(JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.text)
   if not('results' in JyhkEwzNvnLieKrCgMcqAVaIGlUdus):return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP
   JyhkEwzNvnLieKrCgMcqAVaIGlUdfY=JyhkEwzNvnLieKrCgMcqAVaIGlUdus['results']
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYP=JyhkEwzNvnLieKrCgMcqAVaIGlUdus['meta']['has_next']
   for JyhkEwzNvnLieKrCgMcqAVaIGlUdYF in JyhkEwzNvnLieKrCgMcqAVaIGlUdfY:
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfu =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['code']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfO=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['content_type']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfT =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['title']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfs =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['story']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdum=JyhkEwzNvnLieKrCgMcqAVaIGlUduo=JyhkEwzNvnLieKrCgMcqAVaIGlUdTt=''
    if JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('poster') !=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp:JyhkEwzNvnLieKrCgMcqAVaIGlUdum=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('poster').get('original')
    if JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('stillcut')!=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp:JyhkEwzNvnLieKrCgMcqAVaIGlUduo =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('stillcut').get('large')
    if JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('thumbnail')!=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp:JyhkEwzNvnLieKrCgMcqAVaIGlUdTt=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('thumbnail').get('large')
    if JyhkEwzNvnLieKrCgMcqAVaIGlUdTt=='' :JyhkEwzNvnLieKrCgMcqAVaIGlUdTt=JyhkEwzNvnLieKrCgMcqAVaIGlUduo
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfx={'thumb':JyhkEwzNvnLieKrCgMcqAVaIGlUduo,'poster':JyhkEwzNvnLieKrCgMcqAVaIGlUdum,'fanart':JyhkEwzNvnLieKrCgMcqAVaIGlUdTt}
    JyhkEwzNvnLieKrCgMcqAVaIGlUduH =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['year']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfb =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['film_rating_code']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfP=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['film_rating_short']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfm =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['film_rating_long']
    if JyhkEwzNvnLieKrCgMcqAVaIGlUdfO=='movies':
     JyhkEwzNvnLieKrCgMcqAVaIGlUduQ =JyhkEwzNvnLieKrCgMcqAVaIGlUdYF['duration']
    else:
     JyhkEwzNvnLieKrCgMcqAVaIGlUduQ ='0'
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYB={'title':JyhkEwzNvnLieKrCgMcqAVaIGlUdfT,}
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYx.append(JyhkEwzNvnLieKrCgMcqAVaIGlUdYB)
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception)
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP
 def Get_Search_Coupang(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,search_key,page_int):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYx=[]
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYP=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
  try:
   CP=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.jsonfile_To_dic(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.CP_ORIGINAL_COOKIE)
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYm=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_COUPANG+'/v2/search' 
   JyhkEwzNvnLieKrCgMcqAVaIGlUduT={'query':search_key,'platform':'WEBCLIENT','page':JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(page_int),'perPage':JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.COUPANG_LIMIT),}
   JyhkEwzNvnLieKrCgMcqAVaIGlUdfo={'x-membersrl':CP['COOKIES']['member_srl'],'x-pcid':CP['COOKIES']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.Call_Request(JyhkEwzNvnLieKrCgMcqAVaIGlUdYm,payload=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,params=JyhkEwzNvnLieKrCgMcqAVaIGlUduT,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdfo,cookies=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,method='GET')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYj=json.loads(JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.text)
   if JyhkEwzNvnLieKrCgMcqAVaIGlUdsx(JyhkEwzNvnLieKrCgMcqAVaIGlUdYj.get('data').get('data'))==0:return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP
   for JyhkEwzNvnLieKrCgMcqAVaIGlUdYF in JyhkEwzNvnLieKrCgMcqAVaIGlUdYj.get('data').get('data'):
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYF=JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('data')
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYB={'title':JyhkEwzNvnLieKrCgMcqAVaIGlUdYF.get('title'),}
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYx.append(JyhkEwzNvnLieKrCgMcqAVaIGlUdYB)
   if JyhkEwzNvnLieKrCgMcqAVaIGlUdYj.get('pagination').get('totalPages')>page_int:
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYP=JyhkEwzNvnLieKrCgMcqAVaIGlUdTB
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception)
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP
 def Selenium_Cookies_Load(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,in_filename):
  fp=JyhkEwzNvnLieKrCgMcqAVaIGlUdsb(in_filename,'rb',-1)
  try:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdfj=pickle.loads(fp.read())
   if JyhkEwzNvnLieKrCgMcqAVaIGlUdsP(JyhkEwzNvnLieKrCgMcqAVaIGlUdfj)==JyhkEwzNvnLieKrCgMcqAVaIGlUdsm:
    for JyhkEwzNvnLieKrCgMcqAVaIGlUdft in JyhkEwzNvnLieKrCgMcqAVaIGlUdfj:
     JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.HTTP_CLIENT.cookies.set_cookie(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.To_Cookielib(JyhkEwzNvnLieKrCgMcqAVaIGlUdft)) 
   else:
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.HTTP_CLIENT.cookies.update(JyhkEwzNvnLieKrCgMcqAVaIGlUdfj) 
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception)
  finally:
   fp.close()
 def To_Cookielib(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,selenium_cookie):
  return http.cookiejar.Cookie(version=0,name=selenium_cookie['name'],value=selenium_cookie['value'],port=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,port_specified=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf,domain=selenium_cookie['domain'],domain_specified=JyhkEwzNvnLieKrCgMcqAVaIGlUdTB,domain_initial_dot=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf,path=selenium_cookie['path'],path_specified=JyhkEwzNvnLieKrCgMcqAVaIGlUdTB,secure=selenium_cookie['secure'],expires=selenium_cookie['expiry'],discard=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf,comment=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,comment_url=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,rest={'HttpOnly':selenium_cookie['httpOnly']},rfc2109=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf,)
 def Get_Search_Primev(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,search_key):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYx=[]
  try:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.PV=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.jsonfile_To_dic(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.PV_ORIGINAL_COOKIE)
   JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.PV['COOKIES']
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYm=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_PRIMEV+'/search/ref=atv_nb_sr?phrase='+urllib.parse.quote_plus(search_key)+'&ie=UTF8'
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.Call_Request(JyhkEwzNvnLieKrCgMcqAVaIGlUdYm,params=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,cookies=JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ,method='GET')
   if JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.status_code!=200:return[]
   JyhkEwzNvnLieKrCgMcqAVaIGlUdfS='{"props":{"containers"'
   JyhkEwzNvnLieKrCgMcqAVaIGlUdfH=r'<script type="text/template">\s*(.*?)\s*</script>'
   JyhkEwzNvnLieKrCgMcqAVaIGlUdfD=re.compile(JyhkEwzNvnLieKrCgMcqAVaIGlUdfH,re.DOTALL).findall(JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.text)
   JyhkEwzNvnLieKrCgMcqAVaIGlUdfR='{}'
   for JyhkEwzNvnLieKrCgMcqAVaIGlUdfX in JyhkEwzNvnLieKrCgMcqAVaIGlUdfD:
    if JyhkEwzNvnLieKrCgMcqAVaIGlUdfS in JyhkEwzNvnLieKrCgMcqAVaIGlUdfX:
     JyhkEwzNvnLieKrCgMcqAVaIGlUdfR=JyhkEwzNvnLieKrCgMcqAVaIGlUdfX
     break
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYj=json.loads(JyhkEwzNvnLieKrCgMcqAVaIGlUdfR)
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.dic_To_jsonfile(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_CONTEXTJSON_FILE1,JyhkEwzNvnLieKrCgMcqAVaIGlUdYj)
   JyhkEwzNvnLieKrCgMcqAVaIGlUdfp=JyhkEwzNvnLieKrCgMcqAVaIGlUdYj.get('props')
   for JyhkEwzNvnLieKrCgMcqAVaIGlUdfB in JyhkEwzNvnLieKrCgMcqAVaIGlUdfp.get('containers'):
    if JyhkEwzNvnLieKrCgMcqAVaIGlUdfB.get('containerType')=='Grid':
     JyhkEwzNvnLieKrCgMcqAVaIGlUdfW=JyhkEwzNvnLieKrCgMcqAVaIGlUdfB.get('entities')
     break
   for JyhkEwzNvnLieKrCgMcqAVaIGlUdOY in JyhkEwzNvnLieKrCgMcqAVaIGlUdfW:
    if 'titleID' not in JyhkEwzNvnLieKrCgMcqAVaIGlUdOY:return[]
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYB={'title':JyhkEwzNvnLieKrCgMcqAVaIGlUdOY.get('title'),}
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYx.append(JyhkEwzNvnLieKrCgMcqAVaIGlUdYB)
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception)
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx
 def Get_Search_Disney(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,search_key):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYx=[]
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYm=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['services']['content']['getSearchResults']['href']
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOu={'apiVersion':'5.1','region':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge','pageSize':JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DISNEY_LIMIT),'query':search_key,}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYm=JyhkEwzNvnLieKrCgMcqAVaIGlUdYm.format(**JyhkEwzNvnLieKrCgMcqAVaIGlUdOu)
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfo=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.make_DZ_Headers(accessToken=JyhkEwzNvnLieKrCgMcqAVaIGlUdTB,Bearer=JyhkEwzNvnLieKrCgMcqAVaIGlUdTB)
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.Call_Request(JyhkEwzNvnLieKrCgMcqAVaIGlUdYm,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdfo,cookies=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,method='GET')
  if JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.status_code not in[200,201]:return[]
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOf=JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.json().get('data').get('search')
  for JyhkEwzNvnLieKrCgMcqAVaIGlUdOY in JyhkEwzNvnLieKrCgMcqAVaIGlUdOf.get('hits'):
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOY=JyhkEwzNvnLieKrCgMcqAVaIGlUdOY.get('hit')
   if JyhkEwzNvnLieKrCgMcqAVaIGlUdOY.get('type')=='DmcSeries': 
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfT =JyhkEwzNvnLieKrCgMcqAVaIGlUdOY.get('text').get('title').get('full').get('series').get('default').get('content')
   elif JyhkEwzNvnLieKrCgMcqAVaIGlUdOY.get('type')=='DmcVideo':
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfT =JyhkEwzNvnLieKrCgMcqAVaIGlUdOY.get('text').get('title').get('full').get('program').get('default').get('content')
   elif JyhkEwzNvnLieKrCgMcqAVaIGlUdOY.get('type')=='StandardCollection':
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfT =JyhkEwzNvnLieKrCgMcqAVaIGlUdOY.get('text').get('title').get('full').get('collection').get('default').get('content')
   else:
    return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYB={'title':JyhkEwzNvnLieKrCgMcqAVaIGlUdfT,}
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYx.append(JyhkEwzNvnLieKrCgMcqAVaIGlUdYB)
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx
 def dic_To_jsonfile(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,filename,JyhkEwzNvnLieKrCgMcqAVaIGlUdOT):
  if filename=='':return
  fp=JyhkEwzNvnLieKrCgMcqAVaIGlUdsb(filename,'w',-1,'utf-8')
  json.dump(JyhkEwzNvnLieKrCgMcqAVaIGlUdOT,fp,indent=4,ensure_ascii=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf)
  fp.close()
 def jsonfile_To_dic(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,filename):
  if filename=='':return JyhkEwzNvnLieKrCgMcqAVaIGlUdTp
  try:
   fp=JyhkEwzNvnLieKrCgMcqAVaIGlUdsb(filename,'r',-1,'utf-8')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOx=json.load(fp)
   fp.close()
  except:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOx={}
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdOx
 def tempFileSave(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,filename,resText):
  if filename=='':return
  fp=JyhkEwzNvnLieKrCgMcqAVaIGlUdsb(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,filename):
  if filename=='':return
  try:
   fp=JyhkEwzNvnLieKrCgMcqAVaIGlUdsb(filename,'r',-1,'utf-8')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOx=fp.read()
   fp.close()
  except:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOx=''
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdOx
 def make_DZ_Headers(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,accessToken=JyhkEwzNvnLieKrCgMcqAVaIGlUdTB,Bearer=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf):
  if accessToken:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOb=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['account']['accessToken']
  else:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOb=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['headers']['clientApiKey']
  if Bearer:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOb='Bearer {}'.format(JyhkEwzNvnLieKrCgMcqAVaIGlUdOb)
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfo={'authorization':JyhkEwzNvnLieKrCgMcqAVaIGlUdOb,'x-application-version':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['headers']['sdkAppVersion'],'x-bamsdk-client-id':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['headers']['clientId'],'x-bamsdk-platform':'windows','x-bamsdk-version':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['headers']['sdkVersion'],'x-dss-edge-accept':'vnd.dss.edge+json; version=2',}
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdfo
 def DZ_ReToken(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf):
  try:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYm =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['services']['orchestration']['refreshToken']['href']
   JyhkEwzNvnLieKrCgMcqAVaIGlUdfo=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.make_DZ_Headers(accessToken=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf,Bearer=JyhkEwzNvnLieKrCgMcqAVaIGlUdsf)
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOP={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['account']['refreshToken'],}}}
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.Call_Request(JyhkEwzNvnLieKrCgMcqAVaIGlUdYm,json=JyhkEwzNvnLieKrCgMcqAVaIGlUdOP,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdfo,cookies=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,method='POST')
   if JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.status_code not in[200,201]:return JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOf=JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.json()
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['account']['accessToken'] =JyhkEwzNvnLieKrCgMcqAVaIGlUdOf.get('extensions').get('sdk').get('token').get('accessToken')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['account']['accessTokenType']=JyhkEwzNvnLieKrCgMcqAVaIGlUdOf.get('extensions').get('sdk').get('token').get('accessTokenType')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['account']['refreshToken'] =JyhkEwzNvnLieKrCgMcqAVaIGlUdOf.get('extensions').get('sdk').get('token').get('refreshToken')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['account']['token_limit'] =JyhkEwzNvnLieKrCgMcqAVaIGlUdsu(time.time())+14400 
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['account']['deviceId'] =JyhkEwzNvnLieKrCgMcqAVaIGlUdOf.get('extensions').get('sdk').get('session').get('device').get('id')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DZ['account']['sessionId'] =JyhkEwzNvnLieKrCgMcqAVaIGlUdOf.get('extensions').get('sdk').get('session').get('sessionId')
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception)
   return JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdTB
 def Init_NF_Total(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF={}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['COOKIES']={}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']={}
 def make_NF_XnetflixHeaders(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfo={'x-netflix.browsername':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['esnModel'],'x-netflix.esnprefix':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['nowGuid'],'x-netflix.uiversion':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdfo
 def make_NF_ApiParams(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYo={'avif':'false','webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','isTop10KidsSupported':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/mre/pathEvaluator',}
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdYo
 def extract_json(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,content,name):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfH=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfR=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOm=re.compile(JyhkEwzNvnLieKrCgMcqAVaIGlUdfH.format(name),re.DOTALL).findall(content)
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfR=JyhkEwzNvnLieKrCgMcqAVaIGlUdOm[0]
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOo=JyhkEwzNvnLieKrCgMcqAVaIGlUdfR.replace('\\"','\\\\"') 
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOo=JyhkEwzNvnLieKrCgMcqAVaIGlUdOo.replace('\\s','\\\\s') 
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOo=JyhkEwzNvnLieKrCgMcqAVaIGlUdOo.replace('\\n','\\\\n') 
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOo=JyhkEwzNvnLieKrCgMcqAVaIGlUdOo.replace('\\t','\\\\t') 
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOo=JyhkEwzNvnLieKrCgMcqAVaIGlUdOo.encode().decode('unicode_escape') 
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOo=re.sub(r'\\(?!["])',r'\\\\',JyhkEwzNvnLieKrCgMcqAVaIGlUdOo) 
  return json.loads(JyhkEwzNvnLieKrCgMcqAVaIGlUdOo)
 def NF_makestr_paths(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,paths):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOx=[]
  if JyhkEwzNvnLieKrCgMcqAVaIGlUdso(paths,JyhkEwzNvnLieKrCgMcqAVaIGlUdsu):
   return '%d'%(paths)
  elif JyhkEwzNvnLieKrCgMcqAVaIGlUdso(paths,JyhkEwzNvnLieKrCgMcqAVaIGlUdsY):
   return '"%s"'%(paths)
  for JyhkEwzNvnLieKrCgMcqAVaIGlUdOj in paths:
   if JyhkEwzNvnLieKrCgMcqAVaIGlUdso(JyhkEwzNvnLieKrCgMcqAVaIGlUdOj,JyhkEwzNvnLieKrCgMcqAVaIGlUdsu):
    JyhkEwzNvnLieKrCgMcqAVaIGlUdOx.append('%d'%(JyhkEwzNvnLieKrCgMcqAVaIGlUdOj))
   elif JyhkEwzNvnLieKrCgMcqAVaIGlUdso(JyhkEwzNvnLieKrCgMcqAVaIGlUdOj,JyhkEwzNvnLieKrCgMcqAVaIGlUdsY):
    JyhkEwzNvnLieKrCgMcqAVaIGlUdOx.append('"%s"'%(JyhkEwzNvnLieKrCgMcqAVaIGlUdOj))
   elif JyhkEwzNvnLieKrCgMcqAVaIGlUdso(JyhkEwzNvnLieKrCgMcqAVaIGlUdOj,JyhkEwzNvnLieKrCgMcqAVaIGlUdsm):
    JyhkEwzNvnLieKrCgMcqAVaIGlUdOx.append('[%s]'%(','.join(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_makestr_paths(JyhkEwzNvnLieKrCgMcqAVaIGlUdOj))))
   elif JyhkEwzNvnLieKrCgMcqAVaIGlUdso(JyhkEwzNvnLieKrCgMcqAVaIGlUdOj,JyhkEwzNvnLieKrCgMcqAVaIGlUdsO):
    JyhkEwzNvnLieKrCgMcqAVaIGlUdOt=''
    for JyhkEwzNvnLieKrCgMcqAVaIGlUdOF,JyhkEwzNvnLieKrCgMcqAVaIGlUdOQ in JyhkEwzNvnLieKrCgMcqAVaIGlUdOj.items():
     JyhkEwzNvnLieKrCgMcqAVaIGlUdOt+='"%s":%s,'%(JyhkEwzNvnLieKrCgMcqAVaIGlUdOF,JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_makestr_paths(JyhkEwzNvnLieKrCgMcqAVaIGlUdOQ))
    JyhkEwzNvnLieKrCgMcqAVaIGlUdOx.append('{%s}'%(JyhkEwzNvnLieKrCgMcqAVaIGlUdOt[:-1]))
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdOx
 def NF_Call_pathapi(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,JyhkEwzNvnLieKrCgMcqAVaIGlUdTu,referer=''):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOS='%s/nq/website/memberapi/%s/pathEvaluator'%(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_NETFLIX,JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['identifier'])
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOP={'path':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_makestr_paths(JyhkEwzNvnLieKrCgMcqAVaIGlUdTu),'authURL':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']['authURL']}
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYo=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.make_NF_ApiParams()
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfo={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_NETFLIX,'sec-ch-ua':'"Google Chrome";v="101", "Not)A;Brand";v="8", "Chromium";v="101"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':JyhkEwzNvnLieKrCgMcqAVaIGlUdfo['referer']=referer
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOH=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.make_NF_XnetflixHeaders()
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfo.update(JyhkEwzNvnLieKrCgMcqAVaIGlUdOH)
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_Get_DefaultCookies()
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ['profilesNewSession']='0'
  try:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.Call_Request(JyhkEwzNvnLieKrCgMcqAVaIGlUdOS,payload=JyhkEwzNvnLieKrCgMcqAVaIGlUdOP,params=JyhkEwzNvnLieKrCgMcqAVaIGlUdYo,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdfo,cookies=JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ,method='POST')
   return JyhkEwzNvnLieKrCgMcqAVaIGlUdYT
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception)
   return JyhkEwzNvnLieKrCgMcqAVaIGlUdTp
 def Get_Search_Netflix(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,search_key,page_int,byReference=''):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOD=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.DERECTOR_LIMIT
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOR =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.CAST_LIMIT
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOX =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.GENRE_LIMIT
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOp =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_LIMIT*(page_int-1)
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOB =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_LIMIT*page_int 
  JyhkEwzNvnLieKrCgMcqAVaIGlUdOW="|%s"%(search_key)
  JyhkEwzNvnLieKrCgMcqAVaIGlUdTY ='%s/search?%s'%(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTu=[["search","byTerm",JyhkEwzNvnLieKrCgMcqAVaIGlUdOW,"titles",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_LIMIT,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"summary"],["search","byTerm",JyhkEwzNvnLieKrCgMcqAVaIGlUdOW,"titles",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_LIMIT,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",JyhkEwzNvnLieKrCgMcqAVaIGlUdOW,"titles",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_LIMIT,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference","boxarts",[JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND2,JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_PORT],"jpg"],["search","byTerm",JyhkEwzNvnLieKrCgMcqAVaIGlUdOW,"titles",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_LIMIT,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference","interestingMoment",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND1,"jpg"],["search","byTerm",JyhkEwzNvnLieKrCgMcqAVaIGlUdOW,"titles",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_LIMIT,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference","storyArt",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND2,"jpg"],["search","byTerm",JyhkEwzNvnLieKrCgMcqAVaIGlUdOW,"titles",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_LIMIT,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference",["cast","creators","directors"],{"from":0,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOD},["id","name"]],["search","byTerm",JyhkEwzNvnLieKrCgMcqAVaIGlUdOW,"titles",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_LIMIT,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference","genres",{"from":0,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOX},["id","name"]],["search","byTerm",JyhkEwzNvnLieKrCgMcqAVaIGlUdOW,"titles",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NETFLIX_LIMIT,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LOGO,"png"],]
  else:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTu=[["search","byReference",byReference,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"summary"],["search","byReference",byReference,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference","boxarts",[JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND2,JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference","interestingMoment",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference","storyArt",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference",["cast","creators","directors"],{"from":0,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOD},["id","name"]],["search","byReference",byReference,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference","genres",{"from":0,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOX},["id","name"]],["search","byReference",byReference,{"from":JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,"to":JyhkEwzNvnLieKrCgMcqAVaIGlUdOB},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LOGO,"png"],]
  try:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_Call_pathapi(JyhkEwzNvnLieKrCgMcqAVaIGlUdTu,JyhkEwzNvnLieKrCgMcqAVaIGlUdTY)
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYj=json.loads(JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.text)
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception)
  (JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP,byReference)=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.Search_Netflix_Make(JyhkEwzNvnLieKrCgMcqAVaIGlUdYj)
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP,byReference
 def Search_Netflix_Make(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,jsonSource):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYx=[]
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYP =JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
  JyhkEwzNvnLieKrCgMcqAVaIGlUdTf=''
  JyhkEwzNvnLieKrCgMcqAVaIGlUdTO=jsonSource.get('paths')[0][1]
  if JyhkEwzNvnLieKrCgMcqAVaIGlUdTO=='byTerm':
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOp =jsonSource['paths'][0][5]['from']
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOB =jsonSource['paths'][0][5]['to']
  else:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOp =jsonSource['paths'][0][3]['from']
   JyhkEwzNvnLieKrCgMcqAVaIGlUdOB =jsonSource['paths'][0][3]['to']
  JyhkEwzNvnLieKrCgMcqAVaIGlUdTf=JyhkEwzNvnLieKrCgMcqAVaIGlUdsm(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  JyhkEwzNvnLieKrCgMcqAVaIGlUdTs=jsonSource.get('jsonGraph').get('search').get('byReference').get(JyhkEwzNvnLieKrCgMcqAVaIGlUdTf)
  JyhkEwzNvnLieKrCgMcqAVaIGlUdTx =jsonSource.get('jsonGraph').get('videos')
  JyhkEwzNvnLieKrCgMcqAVaIGlUdTb=jsonSource.get('jsonGraph').get('person')
  JyhkEwzNvnLieKrCgMcqAVaIGlUdTP=jsonSource.get('jsonGraph').get('genres')
  JyhkEwzNvnLieKrCgMcqAVaIGlUdYP=JyhkEwzNvnLieKrCgMcqAVaIGlUdTB if JyhkEwzNvnLieKrCgMcqAVaIGlUdTs[JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdOB)]['reference']['$type']=='ref' else JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
  for JyhkEwzNvnLieKrCgMcqAVaIGlUdTm in JyhkEwzNvnLieKrCgMcqAVaIGlUdsj(JyhkEwzNvnLieKrCgMcqAVaIGlUdOp,JyhkEwzNvnLieKrCgMcqAVaIGlUdOB):
   if JyhkEwzNvnLieKrCgMcqAVaIGlUdTs[JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdTm)]['reference']['$type']=='ref':
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYR =JyhkEwzNvnLieKrCgMcqAVaIGlUdTs[JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(JyhkEwzNvnLieKrCgMcqAVaIGlUdTm)]['reference']['value'][1]
    JyhkEwzNvnLieKrCgMcqAVaIGlUdTo=JyhkEwzNvnLieKrCgMcqAVaIGlUdTx[JyhkEwzNvnLieKrCgMcqAVaIGlUdYR]
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfT =JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['title']['value']
    if JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['availability']['value']['isPlayable']==JyhkEwzNvnLieKrCgMcqAVaIGlUdsf:
     continue
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYH =JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['summary']['value']['type']
    JyhkEwzNvnLieKrCgMcqAVaIGlUduQ =0 if JyhkEwzNvnLieKrCgMcqAVaIGlUdYH!='movie' else JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['runtime']['value']
    if JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['sequiturEvidence']['value']['value']:
     JyhkEwzNvnLieKrCgMcqAVaIGlUdTj=JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['sequiturEvidence']['value']['value']['text']
    else:
     JyhkEwzNvnLieKrCgMcqAVaIGlUdTj=''
    JyhkEwzNvnLieKrCgMcqAVaIGlUdum =JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['boxarts'][JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_PORT]['jpg']['value']['url']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdTt =JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['boxarts'][JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND2]['jpg']['value']['url']
    JyhkEwzNvnLieKrCgMcqAVaIGlUduo=''
    if 'value' in JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['storyArt'][JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND2]['jpg']:
     JyhkEwzNvnLieKrCgMcqAVaIGlUduo =JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['storyArt'][JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND2]['jpg']['value']['url']
    if JyhkEwzNvnLieKrCgMcqAVaIGlUduo=='' and 'value' in JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['interestingMoment'][JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND1]['jpg']:
     JyhkEwzNvnLieKrCgMcqAVaIGlUduo =JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['interestingMoment'][JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LAND1]['jpg']['value']['url']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdup=''
    if 'value' in JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LOGO]['png']:
     JyhkEwzNvnLieKrCgMcqAVaIGlUdup=JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.ART_SIZE_LOGO]['png']['value']['url']
    JyhkEwzNvnLieKrCgMcqAVaIGlUduF =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_Subid_List(JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['genres'])
    for i in JyhkEwzNvnLieKrCgMcqAVaIGlUdsj(JyhkEwzNvnLieKrCgMcqAVaIGlUdsx(JyhkEwzNvnLieKrCgMcqAVaIGlUduF)):
     JyhkEwzNvnLieKrCgMcqAVaIGlUduF[i]=JyhkEwzNvnLieKrCgMcqAVaIGlUdTP[JyhkEwzNvnLieKrCgMcqAVaIGlUduF[i]]['name']['value']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdut=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_Subid_List(JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['directors'])
    JyhkEwzNvnLieKrCgMcqAVaIGlUdTF =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_Subid_List(JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['creators'])
    JyhkEwzNvnLieKrCgMcqAVaIGlUdut.extend(JyhkEwzNvnLieKrCgMcqAVaIGlUdTF)
    for i in JyhkEwzNvnLieKrCgMcqAVaIGlUdsj(JyhkEwzNvnLieKrCgMcqAVaIGlUdsx(JyhkEwzNvnLieKrCgMcqAVaIGlUdut)):
     JyhkEwzNvnLieKrCgMcqAVaIGlUdut[i]=JyhkEwzNvnLieKrCgMcqAVaIGlUdTb[JyhkEwzNvnLieKrCgMcqAVaIGlUdut[i]]['name']['value']
    JyhkEwzNvnLieKrCgMcqAVaIGlUduj=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_Subid_List(JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['cast'])
    for i in JyhkEwzNvnLieKrCgMcqAVaIGlUdsj(JyhkEwzNvnLieKrCgMcqAVaIGlUdsx(JyhkEwzNvnLieKrCgMcqAVaIGlUduj)):
     JyhkEwzNvnLieKrCgMcqAVaIGlUduj[i]=JyhkEwzNvnLieKrCgMcqAVaIGlUdTb[JyhkEwzNvnLieKrCgMcqAVaIGlUduj[i]]['name']['value']
    if 'maturityDescription' in JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['maturity']['value']['rating']:
     JyhkEwzNvnLieKrCgMcqAVaIGlUduS=JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['maturity']['value']['rating']['maturityDescription']
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYB={'videoid':JyhkEwzNvnLieKrCgMcqAVaIGlUdYR,'vidtype':JyhkEwzNvnLieKrCgMcqAVaIGlUdYH,'title':JyhkEwzNvnLieKrCgMcqAVaIGlUdfT,'mpaa':JyhkEwzNvnLieKrCgMcqAVaIGlUduS,'regularSynopsis':JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['regularSynopsis']['value'],'dpSupplemental':JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['dpSupplementalMessage']['value'],'sequiturEvidence':JyhkEwzNvnLieKrCgMcqAVaIGlUdTj,'thumbnail':{'poster':JyhkEwzNvnLieKrCgMcqAVaIGlUdum,'thumb':JyhkEwzNvnLieKrCgMcqAVaIGlUduo,'fanart':JyhkEwzNvnLieKrCgMcqAVaIGlUdTt,'clearlogo':JyhkEwzNvnLieKrCgMcqAVaIGlUdup},'year':JyhkEwzNvnLieKrCgMcqAVaIGlUdTo['releaseYear']['value'],'duration':JyhkEwzNvnLieKrCgMcqAVaIGlUduQ,'info_genre':JyhkEwzNvnLieKrCgMcqAVaIGlUduF,'director':JyhkEwzNvnLieKrCgMcqAVaIGlUdut,'cast':JyhkEwzNvnLieKrCgMcqAVaIGlUduj,}
    JyhkEwzNvnLieKrCgMcqAVaIGlUdYx.append(JyhkEwzNvnLieKrCgMcqAVaIGlUdYB)
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdYx,JyhkEwzNvnLieKrCgMcqAVaIGlUdYP,JyhkEwzNvnLieKrCgMcqAVaIGlUdTf
 def NF_Subid_List(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,subJson):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdTQ=[]
  try:
   for i in JyhkEwzNvnLieKrCgMcqAVaIGlUdsj(JyhkEwzNvnLieKrCgMcqAVaIGlUdsx(subJson)):
    if subJson.get(JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(i)).get('$type')!='ref':break
    JyhkEwzNvnLieKrCgMcqAVaIGlUdTS=subJson.get(JyhkEwzNvnLieKrCgMcqAVaIGlUdsY(i)).get('value')[1]
    JyhkEwzNvnLieKrCgMcqAVaIGlUdTQ.append(JyhkEwzNvnLieKrCgMcqAVaIGlUdTS)
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception)
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdTQ
 def NF_CookieFile_Load(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf,cookie_filename):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ={}
  try:
   if os.path.isfile(cookie_filename)==JyhkEwzNvnLieKrCgMcqAVaIGlUdsf:return{}
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTH=JyhkEwzNvnLieKrCgMcqAVaIGlUdsb(cookie_filename,'rb',-1)
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTD =pickle.loads(JyhkEwzNvnLieKrCgMcqAVaIGlUdTH.read())
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTH.close()
   for JyhkEwzNvnLieKrCgMcqAVaIGlUdft in JyhkEwzNvnLieKrCgMcqAVaIGlUdTD:
    JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ[JyhkEwzNvnLieKrCgMcqAVaIGlUdft.name]=JyhkEwzNvnLieKrCgMcqAVaIGlUdft.value
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception) 
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ
 def NF_Get_DefaultCookies(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf):
  JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ={}
  if JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['COOKIES']['flwssn'] :JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ['flwssn'] =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['COOKIES']['flwssn']
  if JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['COOKIES']['nfvdid'] :JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ['nfvdid'] =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['COOKIES']['nfvdid']
  if JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['COOKIES']['SecureNetflixId']:JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ['SecureNetflixId']=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['COOKIES']['SecureNetflixId']
  if JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['COOKIES']['NetflixId'] :JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ['NetflixId'] =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['COOKIES']['NetflixId']
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ
 def NF_Get_BaseSession(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf):
  try:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYm=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.API_NETFLIX+'/browse' 
   JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_Get_DefaultCookies()
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYT=JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.Call_Request(JyhkEwzNvnLieKrCgMcqAVaIGlUdYm,payload=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,params=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,headers=JyhkEwzNvnLieKrCgMcqAVaIGlUdTp,cookies=JyhkEwzNvnLieKrCgMcqAVaIGlUdfQ,method='GET')
   if JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.status_code!=200:
    JyhkEwzNvnLieKrCgMcqAVaIGlUdTW('pass 1 status_code error')
    return JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTR =JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.extract_json(JyhkEwzNvnLieKrCgMcqAVaIGlUdYT.text,'reactContext')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF['SESSION']={'mainGuid':JyhkEwzNvnLieKrCgMcqAVaIGlUdTR['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':JyhkEwzNvnLieKrCgMcqAVaIGlUdTR['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':JyhkEwzNvnLieKrCgMcqAVaIGlUdTR['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':JyhkEwzNvnLieKrCgMcqAVaIGlUdTR['models']['memberContext']['data']['userInfo']['esn'],'identifier':JyhkEwzNvnLieKrCgMcqAVaIGlUdTR['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':JyhkEwzNvnLieKrCgMcqAVaIGlUdTR['models']['abContext']['data']['headers'],}
   JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.dic_To_jsonfile(JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF_SESSION_COOKIES1,JyhkEwzNvnLieKrCgMcqAVaIGlUdYf.NF)
  except JyhkEwzNvnLieKrCgMcqAVaIGlUdsT as exception:
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW('pass 1 error')
   JyhkEwzNvnLieKrCgMcqAVaIGlUdTW(exception)
   return JyhkEwzNvnLieKrCgMcqAVaIGlUdsf
  return JyhkEwzNvnLieKrCgMcqAVaIGlUdTB
# Created by pyminifier (https://github.com/liftoff/pyminifier)
