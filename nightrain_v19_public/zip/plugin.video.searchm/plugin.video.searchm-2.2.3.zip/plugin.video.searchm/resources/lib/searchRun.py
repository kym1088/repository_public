__author__="NightRain"
WJoPbEhvmsiTqYCLpAIdzuKxVkDRGr=object
WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ=None
WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU=True
WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX=False
WJoPbEhvmsiTqYCLpAIdzuKxVkDRGM=type
WJoPbEhvmsiTqYCLpAIdzuKxVkDRGw=dict
WJoPbEhvmsiTqYCLpAIdzuKxVkDRGn=open
WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf=len
WJoPbEhvmsiTqYCLpAIdzuKxVkDRGF=Exception
WJoPbEhvmsiTqYCLpAIdzuKxVkDRyN=int
WJoPbEhvmsiTqYCLpAIdzuKxVkDRyt=range
WJoPbEhvmsiTqYCLpAIdzuKxVkDRyj=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
WJoPbEhvmsiTqYCLpAIdzuKxVkDRNj=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
WJoPbEhvmsiTqYCLpAIdzuKxVkDRNB={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
WJoPbEhvmsiTqYCLpAIdzuKxVkDRNG=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
WJoPbEhvmsiTqYCLpAIdzuKxVkDRNy =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class WJoPbEhvmsiTqYCLpAIdzuKxVkDRNt(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGr):
 def __init__(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,WJoPbEhvmsiTqYCLpAIdzuKxVkDRNe,WJoPbEhvmsiTqYCLpAIdzuKxVkDRNS,WJoPbEhvmsiTqYCLpAIdzuKxVkDRNc):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg._addon_url =WJoPbEhvmsiTqYCLpAIdzuKxVkDRNe
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg._addon_handle=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNS
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.main_params =WJoPbEhvmsiTqYCLpAIdzuKxVkDRNc
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj =JyhkEwzNvnLieKrCgMcqAVaIGlUdYu() 
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_authinfo.json'))
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,sting):
  try:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl=xbmcgui.Dialog()
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl.notification(__addonname__,sting)
  except:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ
 def addon_log(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,string):
  try:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNO=string.encode('utf-8','ignore')
  except:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNO='addonException: addon_log'
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNH=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,WJoPbEhvmsiTqYCLpAIdzuKxVkDRNO),level=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNH)
 def get_keyboard_input(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNr=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ
  kb=xbmc.Keyboard()
  kb.setHeading(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNr=kb.getText()
  return WJoPbEhvmsiTqYCLpAIdzuKxVkDRNr
 def get_settings_menubookmark(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNQ=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU if __addon__.getSetting('menu_bookmark')=='true' else WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
  return(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNQ)
 def get_settings_makebookmark(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg):
  return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU if __addon__.getSetting('make_bookmark')=='true' else WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
 def get_settings_select_info(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU=[]
  if __addon__.getSetting('netflixyn')=='true':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU.append('tving')
  if __addon__.getSetting('watchayn')=='true':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU.append('coupang')
  if __addon__.getSetting('primevyn')=='true':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU.append('disney')
  return WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU
 def add_dir(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,label,sublabel='',img='',infoLabels=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ,isFolder=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU,params='',isLink=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX,ContextMenu=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ,direct_url=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ):
  if direct_url:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNX=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw=json.dumps(params,separators=(',',':'))
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw=base64.standard_b64encode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw.encode()).decode('utf-8')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw.replace('+','%2B')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNX='%s?params=%s'%(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg._addon_url,WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw)
  if sublabel and sublabel!='-':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn='%s < %s >'%(label,sublabel)
  else: WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn=label
  if not img:img='DefaultFolder.png'
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNf=xbmcgui.ListItem(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn)
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGM(img)==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGw:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNf.setArt(img)
  else:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNf.setArt({'thumb':img,'poster':img})
  if infoLabels:WJoPbEhvmsiTqYCLpAIdzuKxVkDRNf.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNf.setProperty('IsPlayable','true')
  if ContextMenu:WJoPbEhvmsiTqYCLpAIdzuKxVkDRNf.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg._addon_handle,WJoPbEhvmsiTqYCLpAIdzuKxVkDRNX,WJoPbEhvmsiTqYCLpAIdzuKxVkDRNf,isFolder)
 def Load_Searched_List(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg):
  try:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNF=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNy
   fp=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGn(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNF,'r',-1,'utf-8')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtN=fp.readlines()
   fp.close()
  except:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtN=[]
  return WJoPbEhvmsiTqYCLpAIdzuKxVkDRtN
 def Save_Searched_List(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX):
  try:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNF=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNy
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtj=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.Load_Searched_List() 
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtB={'skey':WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX.strip()}
   fp=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGn(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNF,'w',-1,'utf-8')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtG=urllib.parse.urlencode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtB)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtG=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtG+'\n'
   fp.write(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtG)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRty=0
   for WJoPbEhvmsiTqYCLpAIdzuKxVkDRtg in WJoPbEhvmsiTqYCLpAIdzuKxVkDRtj:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRte=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGw(urllib.parse.parse_qsl(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtg))
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRtS=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtB.get('skey').strip()
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRtc=WJoPbEhvmsiTqYCLpAIdzuKxVkDRte.get('skey').strip()
    if WJoPbEhvmsiTqYCLpAIdzuKxVkDRtS!=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtc:
     fp.write(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtg)
     WJoPbEhvmsiTqYCLpAIdzuKxVkDRty+=1
     if WJoPbEhvmsiTqYCLpAIdzuKxVkDRty>=50:break
   fp.close()
  except:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ
 def dp_Search_History(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,args):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRta=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.Load_Searched_List()
  for WJoPbEhvmsiTqYCLpAIdzuKxVkDRtl in WJoPbEhvmsiTqYCLpAIdzuKxVkDRta:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtO=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGw(urllib.parse.parse_qsl(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtl))
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtH=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtO.get('skey').strip()
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM={'mode':'TOTAL_SEARCH','search_key':WJoPbEhvmsiTqYCLpAIdzuKxVkDRtH,}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtr={'mode':'HISTORY_REMOVE','skey':WJoPbEhvmsiTqYCLpAIdzuKxVkDRtH,'delmode':'ONE',}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtQ=urllib.parse.urlencode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtr)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtU=[('선택된 검색어 ( %s ) 삭제'%(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtH),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtQ))]
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.add_dir(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtH,sublabel='',img=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ,infoLabels=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ,isFolder=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU,params=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM,ContextMenu=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtU)
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRtM={'plot':'검색목록 전체를 삭제합니다.'}
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRtw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.add_dir(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn,sublabel='',img=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtw,infoLabels=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtM,isFolder=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX,params=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM,isLink=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU)
  xbmcplugin.endOfDirectory(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg._addon_handle,cacheToDisc=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX)
 def Delete_History_List(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,WJoPbEhvmsiTqYCLpAIdzuKxVkDRtH,WJoPbEhvmsiTqYCLpAIdzuKxVkDRtF):
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRtF=='ALL':
   try:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRNF=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNy
    fp=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGn(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNF,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ
  else:
   try:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRNF=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNy
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRtj=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.Load_Searched_List() 
    fp=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGn(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNF,'w',-1,'utf-8')
    for WJoPbEhvmsiTqYCLpAIdzuKxVkDRtg in WJoPbEhvmsiTqYCLpAIdzuKxVkDRtj:
     WJoPbEhvmsiTqYCLpAIdzuKxVkDRte=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGw(urllib.parse.parse_qsl(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtg))
     WJoPbEhvmsiTqYCLpAIdzuKxVkDRtf=WJoPbEhvmsiTqYCLpAIdzuKxVkDRte.get('skey').strip()
     if WJoPbEhvmsiTqYCLpAIdzuKxVkDRtH!=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtf:
      fp.write(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtg)
    fp.close()
   except:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ
 def dp_History_Delete(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,args):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRtH =args.get('skey') 
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRtF=args.get('delmode')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl=xbmcgui.Dialog()
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRtF=='ALL':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRjN=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRjN=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRjN==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX:sys.exit()
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.Delete_History_List(WJoPbEhvmsiTqYCLpAIdzuKxVkDRtH,WJoPbEhvmsiTqYCLpAIdzuKxVkDRtF)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNQ=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.get_settings_menubookmark()
  for WJoPbEhvmsiTqYCLpAIdzuKxVkDRjt in WJoPbEhvmsiTqYCLpAIdzuKxVkDRNj:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjt.get('title')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtw=''
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRjt.get('mode')=='MENU_BOOKMARK' and WJoPbEhvmsiTqYCLpAIdzuKxVkDRNQ==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX:continue
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM={'mode':WJoPbEhvmsiTqYCLpAIdzuKxVkDRjt.get('mode')}
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRjt.get('mode')in['XXX','MENU_BOOKMARK']:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjB=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjG =WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU
   else:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjB=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjG =WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
   if 'icon' in WJoPbEhvmsiTqYCLpAIdzuKxVkDRjt:WJoPbEhvmsiTqYCLpAIdzuKxVkDRtw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',WJoPbEhvmsiTqYCLpAIdzuKxVkDRjt.get('icon')) 
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.add_dir(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn,sublabel='',img=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtw,infoLabels=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ,isFolder=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjB,params=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM,isLink=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjG)
  xbmcplugin.endOfDirectory(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg._addon_handle,cacheToDisc=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX)
 def option_check(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.get_settings_select_info()
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU)==0:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl=xbmcgui.Dialog()
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRjN=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRjN==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU:
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.NF_cookiefile_check()==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.NF_login(showMessage=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU)
  if 'disney' in WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU:
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.DZ_cookiefile_check()==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.DZ={}
 def DZ_cookiefile_check(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjg={}
  try: 
   fp=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGn(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRjg= json.load(fp)
   fp.close()
  except WJoPbEhvmsiTqYCLpAIdzuKxVkDRGF as exception:
   return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.DZ=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjg
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRyN(time.time())>WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.DZ['account']['token_limit']:
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.DZ_ReToken()==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_noti(__language__(30920).encode('utf-8'))
    return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
   try: 
    fp=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGn(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.DZ,fp,indent=4,ensure_ascii=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX)
    fp.close()
   except WJoPbEhvmsiTqYCLpAIdzuKxVkDRGF as exception:
    return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
  return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU
 def NF_cookiefile_check(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjg={}
  try: 
   fp=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGn(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNG,'r',-1,'utf-8')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRjg= json.load(fp)
   fp.close()
  except WJoPbEhvmsiTqYCLpAIdzuKxVkDRGF as exception:
   return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjg
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjS =WJoPbEhvmsiTqYCLpAIdzuKxVkDRyN(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjc=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF['SESSION']['limitdate']
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRja =WJoPbEhvmsiTqYCLpAIdzuKxVkDRyN(re.sub('-','',WJoPbEhvmsiTqYCLpAIdzuKxVkDRjc))
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRja<WJoPbEhvmsiTqYCLpAIdzuKxVkDRjS:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Init_NF_Total()
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.NF_login(showMessage=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX)==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX:
    return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjl=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF_CookieFile_Load(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF_ORIGINAL_COOKIE)
  if(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjl['NetflixId']!=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF['COOKIES']['NetflixId']or WJoPbEhvmsiTqYCLpAIdzuKxVkDRjl['SecureNetflixId']!=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF['COOKIES']['SecureNetflixId']or WJoPbEhvmsiTqYCLpAIdzuKxVkDRjl['flwssn']!=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF['COOKIES']['flwssn']or WJoPbEhvmsiTqYCLpAIdzuKxVkDRjl['nfvdid']!=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF['COOKIES']['nfvdid']):
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Init_NF_Total()
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.NF_login(showMessage=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX)==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX:
    return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
  return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU
 def NF_login(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,showMessage=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU):
  if showMessage:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl=xbmcgui.Dialog()
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRjN=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRjN==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX:
    return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX 
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF['COOKIES']=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF_CookieFile_Load(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF_ORIGINAL_COOKIE)
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjO=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX if WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF['COOKIES']=={}else WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRjO:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_log('pass1 ok!')
  else:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_log('pass1 error!')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_noti(__language__(30905).encode('utf-8'))
   return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX 
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjO=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF_Get_BaseSession()
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRjO:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_log('pass2 ok!')
  else:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_log('pass2 error!')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_noti(__language__(30905).encode('utf-8'))
   return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX 
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjH =WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Now_Datetime()
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF['SESSION']['limitdate']=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjH.strftime('%Y-%m-%d')
  try: 
   fp=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGn(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNG,'w',-1,'utf-8')
   json.dump(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF,fp,indent=4,ensure_ascii=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX)
   fp.close()
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_log('pass3 save ok!')
  except WJoPbEhvmsiTqYCLpAIdzuKxVkDRGF as exception:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_log('pass3 save error!')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_noti(__language__(30905).encode('utf-8'))
   return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
  if showMessage:WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_noti(__language__(30904).encode('utf-8'))
  return WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU
 def NF_logout(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl=xbmcgui.Dialog()
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjN=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRjN==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX:return 
  if os.path.isfile(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNG):os.remove(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNG)
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjr=''
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjQ=7
  try:
   for i in WJoPbEhvmsiTqYCLpAIdzuKxVkDRyt(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)):
    if i>=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjQ:
     WJoPbEhvmsiTqYCLpAIdzuKxVkDRjr=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjr+'...'
     break
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjr=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjr+WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM[i]['title']+'\n'
  except:
   return ''
  return WJoPbEhvmsiTqYCLpAIdzuKxVkDRjr
 def dp_Search_Group(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,args):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU =WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.get_settings_select_info()
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjU=[]
  if 'search_key' in args:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX=args.get('search_key')
  else:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX:
    return
  if 'wavve' in WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU:
   (WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjw)=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Search_Wavve(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,'TVSHOW',1)
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)>0:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn={'sType':'wavve_tvshow','sList':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.MakeText_FreeList(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM),}
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjU.append(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn)
   (WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjw)=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Search_Wavve(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,'MOVIE',1)
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)>0:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn={'sType':'wavve_movie','sList':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.MakeText_FreeList(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM),}
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjU.append(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn)
  if 'tving' in WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU:
   (WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjw)=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Search_Tving(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,'TVSHOW',1)
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)>0:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn={'sType':'tving_tvshow','sList':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.MakeText_FreeList(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM),}
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjU.append(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn)
   (WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjw)=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Search_Tving(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,'MOVIE',1)
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)>0:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn={'sType':'tving_movie','sList':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.MakeText_FreeList(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM),}
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjU.append(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn)
  if 'watcha' in WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU:
   (WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjw)=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Search_Watcha(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,1)
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)>0:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn={'sType':'watcha_list','sList':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.MakeText_FreeList(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM),}
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjU.append(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn)
  if 'coupang' in WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU:
   (WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjw)=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Search_Coupang(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,1)
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)>0:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn={'sType':'coupang_list','sList':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.MakeText_FreeList(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM),}
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjU.append(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn)
  if 'netflix' in WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU:
   try:
    (WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjw,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjf)=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Search_Netflix(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,1)
   except:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM=[]
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_noti(__language__(30919).encode('utf8'))
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)>0:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn={'sType':'netflix_list','sList':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.MakeText_FreeList(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM),}
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjU.append(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn)
  if 'amazon' in WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU:
   (WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Search_Primev(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX)
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)>0:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn={'sType':'primev_list','sList':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.MakeText_FreeList(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM),}
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjU.append(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn)
  if 'disney' in WJoPbEhvmsiTqYCLpAIdzuKxVkDRNU:
   try:
    (WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Search_Disney(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX)
   except:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM=[]
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.addon_noti(__language__(30921).encode('utf8'))
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGf(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM)>0:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn={'sType':'disney_list','sList':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.MakeText_FreeList(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM),}
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRjU.append(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjn)
  for WJoPbEhvmsiTqYCLpAIdzuKxVkDRjF in WJoPbEhvmsiTqYCLpAIdzuKxVkDRjU:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBN=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNB[WJoPbEhvmsiTqYCLpAIdzuKxVkDRjF.get('sType')]
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBt={'plot':'검색어 : '+WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX+'\n\n'+WJoPbEhvmsiTqYCLpAIdzuKxVkDRjF.get('sList')}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBN.get('title')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM={'mode':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBN.get('mode'),'ott':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBN.get('ott'),'vidtype':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBN.get('vidtype'),'search_key':WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX}
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBN.get('ott')=='netflix':
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj=''
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM['page'] ='1'
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM['byReference']='-'
   else:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.make_Hyper_Link(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',WJoPbEhvmsiTqYCLpAIdzuKxVkDRBN.get('icon'))
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.add_dir(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn,sublabel='',img=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtw,infoLabels=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBt,isFolder=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU,params=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM,isLink=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX,direct_url=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj)
  xbmcplugin.endOfDirectory(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg._addon_handle)
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.Save_Searched_List(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX)
 def make_Hyper_Link(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,args):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRBG =args.get('ott')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy =args.get('vidtype')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX=args.get('search_key')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj='-'
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBG=='wavve':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg={'mode':'LOCAL_SEARCH','sType':'movie' if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy=='MOVIE' else 'vod','search_key':WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,'page':'1',}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe=urllib.parse.urlencode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj='plugin://plugin.video.wavvem/?'
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj+=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRBG=='tving':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg={'mode':'LOCAL_SEARCH','stype':'movie' if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy=='MOVIE' else 'vod','search_key':WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,'page':'1',}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe=urllib.parse.urlencode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj='plugin://plugin.video.tvingm/?'
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj+=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRBG=='watcha':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg={'mode':'LOCAL_SEARCH','search_key':WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,'page':'1',}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe=urllib.parse.urlencode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj='plugin://plugin.video.watcham/?'
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj+=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRBG=='coupang':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg={'mode':'LOCAL_SEARCH','search_key':WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,'page':'1',}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe=urllib.parse.urlencode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj='plugin://plugin.video.coupangm/?'
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj+=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRBG=='netflix':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBS=args.get('videoid')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBc=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.NF['SESSION']['nowGuid']
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy=='TVSHOW':
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj='plugin://plugin.video.netflix/directory/show/%s/'%(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBS)
   else:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBS,WJoPbEhvmsiTqYCLpAIdzuKxVkDRBc)
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRBG=='amazon':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,}}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe=json.dumps(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg,separators=(',',':'))
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe=base64.standard_b64encode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe.encode()).decode('utf-8')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe.replace('+','%2B')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj='plugin://plugin.video.primevm/?params='
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj+=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRBG=='disney':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,}}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe=json.dumps(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBg,separators=(',',':'))
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe=base64.standard_b64encode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe.encode()).decode('utf-8')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe.replace('+','%2B')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj='plugin://plugin.video.disneym/?params='
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj+=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBe
  return WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj
 def dp_Nf_Search(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,args):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRBa =WJoPbEhvmsiTqYCLpAIdzuKxVkDRyN(args.get('page'))
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX =args.get('search_key')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjf=args.get('byReference')
  (WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjw,WJoPbEhvmsiTqYCLpAIdzuKxVkDRjf)=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.SearchObj.Get_Search_Netflix(WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX,WJoPbEhvmsiTqYCLpAIdzuKxVkDRBa,byReference=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjf)
  for WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl in WJoPbEhvmsiTqYCLpAIdzuKxVkDRjM:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBS =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('videoid')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('vidtype')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('title')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBO =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('mpaa')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBH =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('regularSynopsis')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBr =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('dpSupplemental')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBQ=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('sequiturEvidence')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBU =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('thumbnail')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBX =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('year')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBM =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('duration')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBw =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('info_genre')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBn =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('director')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBf =WJoPbEhvmsiTqYCLpAIdzuKxVkDRBl.get('cast')
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy=='movie':
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRtX=' (%s)'%(WJoPbEhvmsiTqYCLpAIdzuKxVkDRyj(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBX))
   else:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRtX=''
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBF=''
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBH:WJoPbEhvmsiTqYCLpAIdzuKxVkDRBF=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBF+'\n\n'+WJoPbEhvmsiTqYCLpAIdzuKxVkDRBH
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBr :WJoPbEhvmsiTqYCLpAIdzuKxVkDRBF=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBF+'\n\n'+WJoPbEhvmsiTqYCLpAIdzuKxVkDRBr
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBQ:WJoPbEhvmsiTqYCLpAIdzuKxVkDRBF=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBF+'\n\n'+WJoPbEhvmsiTqYCLpAIdzuKxVkDRBQ
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBF=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBF.strip()
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtM={'mediatype':'tvshow' if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy=='show' else 'movie','title':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn,'mpaa':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBO,'plot':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBF,'duration':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBM,'genre':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBw,'director':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBn,'cast':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBf,'year':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBX,}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM={'ott':'netflix','vidtype':'TVSHOW' if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy=='show' else 'MOVIE','videoid':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBS,}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.make_Hyper_Link(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRjB=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy=='show' else WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX
   if WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.get_settings_makebookmark():
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRGN={'mode':'SET_BOOKMARK','values':{'videoid':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBS,'vidtype':'tvshow' if WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy=='show' else 'movie','vtitle':WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn+WJoPbEhvmsiTqYCLpAIdzuKxVkDRtX,'vsubtitle':'','vinfo':WJoPbEhvmsiTqYCLpAIdzuKxVkDRtM,'thumbnail':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBU,}}
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRGt=json.dumps(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGN,separators=(',',':'))
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRGt=base64.standard_b64encode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGt.encode()).decode('utf-8')
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRGt=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGt.replace('+','%2B')
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRGj='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGt)
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRtU=[('(통합) 찜 영상에 추가',WJoPbEhvmsiTqYCLpAIdzuKxVkDRGj)]
   else:
    WJoPbEhvmsiTqYCLpAIdzuKxVkDRtU=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.add_dir(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn+WJoPbEhvmsiTqYCLpAIdzuKxVkDRtX,sublabel=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ,img=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBU,infoLabels=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtM,isFolder=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjB,params=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM,isLink=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX,ContextMenu=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtU,direct_url=WJoPbEhvmsiTqYCLpAIdzuKxVkDRBj)
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRjw:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM={}
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM['mode'] ='NF_SEARCH' 
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM['page'] =WJoPbEhvmsiTqYCLpAIdzuKxVkDRyj(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBa+1)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM['search_key']=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjX
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM['byReference']=WJoPbEhvmsiTqYCLpAIdzuKxVkDRjf
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn='[B]%s >>[/B]'%'다음 페이지'
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRGB=WJoPbEhvmsiTqYCLpAIdzuKxVkDRyj(WJoPbEhvmsiTqYCLpAIdzuKxVkDRBa+1)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRtw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.add_dir(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNn,sublabel=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGB,img=WJoPbEhvmsiTqYCLpAIdzuKxVkDRtw,infoLabels=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ,isFolder=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU,params=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM)
  xbmcplugin.setContent(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg._addon_handle,'movies')
  xbmcplugin.endOfDirectory(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg._addon_handle)
 def dp_Bookmark_Menu(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,args):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRGy='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGy)
 def dp_Set_Bookmark(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg,args):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRBS =args.get('videoid')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy =args.get('vidtype')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRGg =args.get('vtitle')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRGe =args.get('vsubtitle')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRGS =args.get('vinfo')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRBU =args.get('thumbnail')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl=xbmcgui.Dialog()
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRjN=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNl.yesno(__language__(30917).encode('utf8'),WJoPbEhvmsiTqYCLpAIdzuKxVkDRGg+' \n\n'+__language__(30918))
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRjN==WJoPbEhvmsiTqYCLpAIdzuKxVkDRGX:return
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRGc={'indexinfo':{'ott':'netflix','videoid':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBS,'vidtype':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBy,},'saveinfo':{'title':WJoPbEhvmsiTqYCLpAIdzuKxVkDRGg,'subtitle':WJoPbEhvmsiTqYCLpAIdzuKxVkDRGe,'thumbnail':WJoPbEhvmsiTqYCLpAIdzuKxVkDRBU,'infoLabels':WJoPbEhvmsiTqYCLpAIdzuKxVkDRGS,},}
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':WJoPbEhvmsiTqYCLpAIdzuKxVkDRGc,}}
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw=json.dumps(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNM,separators=(',',':'))
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw=base64.standard_b64encode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw.encode()).decode('utf-8')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw.replace('+','%2B')
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRGj='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNw)
  xbmc.executebuiltin(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGj)
 def search_main(WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg):
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRGa=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.main_params.get('params')
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGa:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRGl =base64.standard_b64decode(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGa).decode('utf-8')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRGl =json.loads(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGl)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRGO =WJoPbEhvmsiTqYCLpAIdzuKxVkDRGl.get('mode')
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRGH =WJoPbEhvmsiTqYCLpAIdzuKxVkDRGl.get('values')
  else:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRGO=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.main_params.get('mode',WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ)
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRGH=WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.main_params
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGO=='NFLOGOUT':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.NF_logout()
   return
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRGO=='NFLOGIN':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.NF_login(showMessage=WJoPbEhvmsiTqYCLpAIdzuKxVkDRGU)
   return
  WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.option_check()
  if WJoPbEhvmsiTqYCLpAIdzuKxVkDRGO is WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.dp_Main_List()
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRGO=='TOTAL_SEARCH':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.dp_Search_Group(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGH)
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRGO=='NF_SEARCH':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.dp_Nf_Search(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGH)
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRGO=='TOTAL_HISTORY':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.dp_Search_History(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGH)
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRGO=='HISTORY_REMOVE':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.dp_History_Delete(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGH)
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRGO=='MENU_BOOKMARK':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.dp_Bookmark_Menu(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGH)
  elif WJoPbEhvmsiTqYCLpAIdzuKxVkDRGO=='SET_BOOKMARK':
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRNg.dp_Set_Bookmark(WJoPbEhvmsiTqYCLpAIdzuKxVkDRGH)
  else:
   WJoPbEhvmsiTqYCLpAIdzuKxVkDRGQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
