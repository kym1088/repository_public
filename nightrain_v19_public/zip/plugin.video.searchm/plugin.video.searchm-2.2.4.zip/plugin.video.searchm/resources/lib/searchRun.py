__author__="NightRain"
bFdGgEcOhIpmiuqVWfrDawJRySTMPB=object
bFdGgEcOhIpmiuqVWfrDawJRySTMPA=None
bFdGgEcOhIpmiuqVWfrDawJRySTMPe=True
bFdGgEcOhIpmiuqVWfrDawJRySTMPt=False
bFdGgEcOhIpmiuqVWfrDawJRySTMPk=type
bFdGgEcOhIpmiuqVWfrDawJRySTMPo=dict
bFdGgEcOhIpmiuqVWfrDawJRySTMPl=open
bFdGgEcOhIpmiuqVWfrDawJRySTMPx=len
bFdGgEcOhIpmiuqVWfrDawJRySTMPY=Exception
bFdGgEcOhIpmiuqVWfrDawJRySTMUn=int
bFdGgEcOhIpmiuqVWfrDawJRySTMUC=range
bFdGgEcOhIpmiuqVWfrDawJRySTMUX=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
bFdGgEcOhIpmiuqVWfrDawJRySTMnX=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
bFdGgEcOhIpmiuqVWfrDawJRySTMnv={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
bFdGgEcOhIpmiuqVWfrDawJRySTMnP=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
bFdGgEcOhIpmiuqVWfrDawJRySTMnU =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class bFdGgEcOhIpmiuqVWfrDawJRySTMnC(bFdGgEcOhIpmiuqVWfrDawJRySTMPB):
 def __init__(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,bFdGgEcOhIpmiuqVWfrDawJRySTMnK,bFdGgEcOhIpmiuqVWfrDawJRySTMns,bFdGgEcOhIpmiuqVWfrDawJRySTMnz):
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH._addon_url =bFdGgEcOhIpmiuqVWfrDawJRySTMnK
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH._addon_handle=bFdGgEcOhIpmiuqVWfrDawJRySTMns
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.main_params =bFdGgEcOhIpmiuqVWfrDawJRySTMnz
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj =DgOctkmqxKlnCNWvLGuBFAdhwrzRpJ() 
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_authinfo.json'))
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,sting):
  try:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnN=xbmcgui.Dialog()
   bFdGgEcOhIpmiuqVWfrDawJRySTMnN.notification(__addonname__,sting)
  except:
   bFdGgEcOhIpmiuqVWfrDawJRySTMPA
 def addon_log(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,string):
  try:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnQ=string.encode('utf-8','ignore')
  except:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnQ='addonException: addon_log'
  bFdGgEcOhIpmiuqVWfrDawJRySTMnj=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,bFdGgEcOhIpmiuqVWfrDawJRySTMnQ),level=bFdGgEcOhIpmiuqVWfrDawJRySTMnj)
 def get_keyboard_input(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,bFdGgEcOhIpmiuqVWfrDawJRySTMnl):
  bFdGgEcOhIpmiuqVWfrDawJRySTMnB=bFdGgEcOhIpmiuqVWfrDawJRySTMPA
  kb=xbmc.Keyboard()
  kb.setHeading(bFdGgEcOhIpmiuqVWfrDawJRySTMnl)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   bFdGgEcOhIpmiuqVWfrDawJRySTMnB=kb.getText()
  return bFdGgEcOhIpmiuqVWfrDawJRySTMnB
 def get_settings_menubookmark(bFdGgEcOhIpmiuqVWfrDawJRySTMnH):
  bFdGgEcOhIpmiuqVWfrDawJRySTMnA=bFdGgEcOhIpmiuqVWfrDawJRySTMPe if __addon__.getSetting('menu_bookmark')=='true' else bFdGgEcOhIpmiuqVWfrDawJRySTMPt
  return(bFdGgEcOhIpmiuqVWfrDawJRySTMnA)
 def get_settings_makebookmark(bFdGgEcOhIpmiuqVWfrDawJRySTMnH):
  return bFdGgEcOhIpmiuqVWfrDawJRySTMPe if __addon__.getSetting('make_bookmark')=='true' else bFdGgEcOhIpmiuqVWfrDawJRySTMPt
 def get_settings_select_info(bFdGgEcOhIpmiuqVWfrDawJRySTMnH):
  bFdGgEcOhIpmiuqVWfrDawJRySTMne=[]
  if __addon__.getSetting('netflixyn')=='true':bFdGgEcOhIpmiuqVWfrDawJRySTMne.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':bFdGgEcOhIpmiuqVWfrDawJRySTMne.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':bFdGgEcOhIpmiuqVWfrDawJRySTMne.append('tving')
  if __addon__.getSetting('watchayn')=='true':bFdGgEcOhIpmiuqVWfrDawJRySTMne.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':bFdGgEcOhIpmiuqVWfrDawJRySTMne.append('coupang')
  if __addon__.getSetting('primevyn')=='true':bFdGgEcOhIpmiuqVWfrDawJRySTMne.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':bFdGgEcOhIpmiuqVWfrDawJRySTMne.append('disney')
  return bFdGgEcOhIpmiuqVWfrDawJRySTMne
 def add_dir(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,label,sublabel='',img='',infoLabels=bFdGgEcOhIpmiuqVWfrDawJRySTMPA,isFolder=bFdGgEcOhIpmiuqVWfrDawJRySTMPe,params='',isLink=bFdGgEcOhIpmiuqVWfrDawJRySTMPt,ContextMenu=bFdGgEcOhIpmiuqVWfrDawJRySTMPA,direct_url=bFdGgEcOhIpmiuqVWfrDawJRySTMPA):
  if direct_url:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnt=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   bFdGgEcOhIpmiuqVWfrDawJRySTMno=json.dumps(params,separators=(',',':'))
   bFdGgEcOhIpmiuqVWfrDawJRySTMno=base64.standard_b64encode(bFdGgEcOhIpmiuqVWfrDawJRySTMno.encode()).decode('utf-8')
   bFdGgEcOhIpmiuqVWfrDawJRySTMno=bFdGgEcOhIpmiuqVWfrDawJRySTMno.replace('+','%2B')
   bFdGgEcOhIpmiuqVWfrDawJRySTMnt='%s?params=%s'%(bFdGgEcOhIpmiuqVWfrDawJRySTMnH._addon_url,bFdGgEcOhIpmiuqVWfrDawJRySTMno)
  if sublabel and sublabel!='-':bFdGgEcOhIpmiuqVWfrDawJRySTMnl='%s < %s >'%(label,sublabel)
  else: bFdGgEcOhIpmiuqVWfrDawJRySTMnl=label
  if not img:img='DefaultFolder.png'
  bFdGgEcOhIpmiuqVWfrDawJRySTMnx=xbmcgui.ListItem(bFdGgEcOhIpmiuqVWfrDawJRySTMnl)
  if bFdGgEcOhIpmiuqVWfrDawJRySTMPk(img)==bFdGgEcOhIpmiuqVWfrDawJRySTMPo:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnx.setArt(img)
  else:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnx.setArt({'thumb':img,'poster':img})
  if infoLabels:bFdGgEcOhIpmiuqVWfrDawJRySTMnx.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnx.setProperty('IsPlayable','true')
  if ContextMenu:bFdGgEcOhIpmiuqVWfrDawJRySTMnx.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(bFdGgEcOhIpmiuqVWfrDawJRySTMnH._addon_handle,bFdGgEcOhIpmiuqVWfrDawJRySTMnt,bFdGgEcOhIpmiuqVWfrDawJRySTMnx,isFolder)
 def Load_Searched_List(bFdGgEcOhIpmiuqVWfrDawJRySTMnH):
  try:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnY=bFdGgEcOhIpmiuqVWfrDawJRySTMnU
   fp=bFdGgEcOhIpmiuqVWfrDawJRySTMPl(bFdGgEcOhIpmiuqVWfrDawJRySTMnY,'r',-1,'utf-8')
   bFdGgEcOhIpmiuqVWfrDawJRySTMCn=fp.readlines()
   fp.close()
  except:
   bFdGgEcOhIpmiuqVWfrDawJRySTMCn=[]
  return bFdGgEcOhIpmiuqVWfrDawJRySTMCn
 def Save_Searched_List(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,bFdGgEcOhIpmiuqVWfrDawJRySTMXt):
  try:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnY=bFdGgEcOhIpmiuqVWfrDawJRySTMnU
   bFdGgEcOhIpmiuqVWfrDawJRySTMCX=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.Load_Searched_List() 
   bFdGgEcOhIpmiuqVWfrDawJRySTMCv={'skey':bFdGgEcOhIpmiuqVWfrDawJRySTMXt.strip()}
   fp=bFdGgEcOhIpmiuqVWfrDawJRySTMPl(bFdGgEcOhIpmiuqVWfrDawJRySTMnY,'w',-1,'utf-8')
   bFdGgEcOhIpmiuqVWfrDawJRySTMCP=urllib.parse.urlencode(bFdGgEcOhIpmiuqVWfrDawJRySTMCv)
   bFdGgEcOhIpmiuqVWfrDawJRySTMCP=bFdGgEcOhIpmiuqVWfrDawJRySTMCP+'\n'
   fp.write(bFdGgEcOhIpmiuqVWfrDawJRySTMCP)
   bFdGgEcOhIpmiuqVWfrDawJRySTMCU=0
   for bFdGgEcOhIpmiuqVWfrDawJRySTMCH in bFdGgEcOhIpmiuqVWfrDawJRySTMCX:
    bFdGgEcOhIpmiuqVWfrDawJRySTMCK=bFdGgEcOhIpmiuqVWfrDawJRySTMPo(urllib.parse.parse_qsl(bFdGgEcOhIpmiuqVWfrDawJRySTMCH))
    bFdGgEcOhIpmiuqVWfrDawJRySTMCs=bFdGgEcOhIpmiuqVWfrDawJRySTMCv.get('skey').strip()
    bFdGgEcOhIpmiuqVWfrDawJRySTMCz=bFdGgEcOhIpmiuqVWfrDawJRySTMCK.get('skey').strip()
    if bFdGgEcOhIpmiuqVWfrDawJRySTMCs!=bFdGgEcOhIpmiuqVWfrDawJRySTMCz:
     fp.write(bFdGgEcOhIpmiuqVWfrDawJRySTMCH)
     bFdGgEcOhIpmiuqVWfrDawJRySTMCU+=1
     if bFdGgEcOhIpmiuqVWfrDawJRySTMCU>=50:break
   fp.close()
  except:
   bFdGgEcOhIpmiuqVWfrDawJRySTMPA
 def dp_Search_History(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,args):
  bFdGgEcOhIpmiuqVWfrDawJRySTMCL=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.Load_Searched_List()
  for bFdGgEcOhIpmiuqVWfrDawJRySTMCN in bFdGgEcOhIpmiuqVWfrDawJRySTMCL:
   bFdGgEcOhIpmiuqVWfrDawJRySTMCQ=bFdGgEcOhIpmiuqVWfrDawJRySTMPo(urllib.parse.parse_qsl(bFdGgEcOhIpmiuqVWfrDawJRySTMCN))
   bFdGgEcOhIpmiuqVWfrDawJRySTMCj=bFdGgEcOhIpmiuqVWfrDawJRySTMCQ.get('skey').strip()
   bFdGgEcOhIpmiuqVWfrDawJRySTMnk={'mode':'TOTAL_SEARCH','search_key':bFdGgEcOhIpmiuqVWfrDawJRySTMCj,}
   bFdGgEcOhIpmiuqVWfrDawJRySTMCB={'mode':'HISTORY_REMOVE','skey':bFdGgEcOhIpmiuqVWfrDawJRySTMCj,'delmode':'ONE',}
   bFdGgEcOhIpmiuqVWfrDawJRySTMCA=urllib.parse.urlencode(bFdGgEcOhIpmiuqVWfrDawJRySTMCB)
   bFdGgEcOhIpmiuqVWfrDawJRySTMCe=[('선택된 검색어 ( %s ) 삭제'%(bFdGgEcOhIpmiuqVWfrDawJRySTMCj),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(bFdGgEcOhIpmiuqVWfrDawJRySTMCA))]
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.add_dir(bFdGgEcOhIpmiuqVWfrDawJRySTMCj,sublabel='',img=bFdGgEcOhIpmiuqVWfrDawJRySTMPA,infoLabels=bFdGgEcOhIpmiuqVWfrDawJRySTMPA,isFolder=bFdGgEcOhIpmiuqVWfrDawJRySTMPe,params=bFdGgEcOhIpmiuqVWfrDawJRySTMnk,ContextMenu=bFdGgEcOhIpmiuqVWfrDawJRySTMCe)
  bFdGgEcOhIpmiuqVWfrDawJRySTMCk={'plot':'검색목록 전체를 삭제합니다.'}
  bFdGgEcOhIpmiuqVWfrDawJRySTMnl='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  bFdGgEcOhIpmiuqVWfrDawJRySTMnk={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  bFdGgEcOhIpmiuqVWfrDawJRySTMCo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.add_dir(bFdGgEcOhIpmiuqVWfrDawJRySTMnl,sublabel='',img=bFdGgEcOhIpmiuqVWfrDawJRySTMCo,infoLabels=bFdGgEcOhIpmiuqVWfrDawJRySTMCk,isFolder=bFdGgEcOhIpmiuqVWfrDawJRySTMPt,params=bFdGgEcOhIpmiuqVWfrDawJRySTMnk,isLink=bFdGgEcOhIpmiuqVWfrDawJRySTMPe)
  xbmcplugin.endOfDirectory(bFdGgEcOhIpmiuqVWfrDawJRySTMnH._addon_handle,cacheToDisc=bFdGgEcOhIpmiuqVWfrDawJRySTMPt)
 def Delete_History_List(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,bFdGgEcOhIpmiuqVWfrDawJRySTMCj,bFdGgEcOhIpmiuqVWfrDawJRySTMCY):
  if bFdGgEcOhIpmiuqVWfrDawJRySTMCY=='ALL':
   try:
    bFdGgEcOhIpmiuqVWfrDawJRySTMnY=bFdGgEcOhIpmiuqVWfrDawJRySTMnU
    fp=bFdGgEcOhIpmiuqVWfrDawJRySTMPl(bFdGgEcOhIpmiuqVWfrDawJRySTMnY,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    bFdGgEcOhIpmiuqVWfrDawJRySTMPA
  else:
   try:
    bFdGgEcOhIpmiuqVWfrDawJRySTMnY=bFdGgEcOhIpmiuqVWfrDawJRySTMnU
    bFdGgEcOhIpmiuqVWfrDawJRySTMCX=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.Load_Searched_List() 
    fp=bFdGgEcOhIpmiuqVWfrDawJRySTMPl(bFdGgEcOhIpmiuqVWfrDawJRySTMnY,'w',-1,'utf-8')
    for bFdGgEcOhIpmiuqVWfrDawJRySTMCH in bFdGgEcOhIpmiuqVWfrDawJRySTMCX:
     bFdGgEcOhIpmiuqVWfrDawJRySTMCK=bFdGgEcOhIpmiuqVWfrDawJRySTMPo(urllib.parse.parse_qsl(bFdGgEcOhIpmiuqVWfrDawJRySTMCH))
     bFdGgEcOhIpmiuqVWfrDawJRySTMCx=bFdGgEcOhIpmiuqVWfrDawJRySTMCK.get('skey').strip()
     if bFdGgEcOhIpmiuqVWfrDawJRySTMCj!=bFdGgEcOhIpmiuqVWfrDawJRySTMCx:
      fp.write(bFdGgEcOhIpmiuqVWfrDawJRySTMCH)
    fp.close()
   except:
    bFdGgEcOhIpmiuqVWfrDawJRySTMPA
 def dp_History_Delete(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,args):
  bFdGgEcOhIpmiuqVWfrDawJRySTMCj =args.get('skey') 
  bFdGgEcOhIpmiuqVWfrDawJRySTMCY=args.get('delmode')
  bFdGgEcOhIpmiuqVWfrDawJRySTMnN=xbmcgui.Dialog()
  if bFdGgEcOhIpmiuqVWfrDawJRySTMCY=='ALL':
   bFdGgEcOhIpmiuqVWfrDawJRySTMXn=bFdGgEcOhIpmiuqVWfrDawJRySTMnN.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   bFdGgEcOhIpmiuqVWfrDawJRySTMXn=bFdGgEcOhIpmiuqVWfrDawJRySTMnN.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if bFdGgEcOhIpmiuqVWfrDawJRySTMXn==bFdGgEcOhIpmiuqVWfrDawJRySTMPt:sys.exit()
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.Delete_History_List(bFdGgEcOhIpmiuqVWfrDawJRySTMCj,bFdGgEcOhIpmiuqVWfrDawJRySTMCY)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(bFdGgEcOhIpmiuqVWfrDawJRySTMnH):
  bFdGgEcOhIpmiuqVWfrDawJRySTMnA=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.get_settings_menubookmark()
  for bFdGgEcOhIpmiuqVWfrDawJRySTMXC in bFdGgEcOhIpmiuqVWfrDawJRySTMnX:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnl=bFdGgEcOhIpmiuqVWfrDawJRySTMXC.get('title')
   bFdGgEcOhIpmiuqVWfrDawJRySTMCo=''
   if bFdGgEcOhIpmiuqVWfrDawJRySTMXC.get('mode')=='MENU_BOOKMARK' and bFdGgEcOhIpmiuqVWfrDawJRySTMnA==bFdGgEcOhIpmiuqVWfrDawJRySTMPt:continue
   bFdGgEcOhIpmiuqVWfrDawJRySTMnk={'mode':bFdGgEcOhIpmiuqVWfrDawJRySTMXC.get('mode')}
   if bFdGgEcOhIpmiuqVWfrDawJRySTMXC.get('mode')in['XXX','MENU_BOOKMARK']:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXv=bFdGgEcOhIpmiuqVWfrDawJRySTMPt
    bFdGgEcOhIpmiuqVWfrDawJRySTMXP =bFdGgEcOhIpmiuqVWfrDawJRySTMPe
   else:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXv=bFdGgEcOhIpmiuqVWfrDawJRySTMPe
    bFdGgEcOhIpmiuqVWfrDawJRySTMXP =bFdGgEcOhIpmiuqVWfrDawJRySTMPt
   if 'icon' in bFdGgEcOhIpmiuqVWfrDawJRySTMXC:bFdGgEcOhIpmiuqVWfrDawJRySTMCo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',bFdGgEcOhIpmiuqVWfrDawJRySTMXC.get('icon')) 
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.add_dir(bFdGgEcOhIpmiuqVWfrDawJRySTMnl,sublabel='',img=bFdGgEcOhIpmiuqVWfrDawJRySTMCo,infoLabels=bFdGgEcOhIpmiuqVWfrDawJRySTMPA,isFolder=bFdGgEcOhIpmiuqVWfrDawJRySTMXv,params=bFdGgEcOhIpmiuqVWfrDawJRySTMnk,isLink=bFdGgEcOhIpmiuqVWfrDawJRySTMXP)
  xbmcplugin.endOfDirectory(bFdGgEcOhIpmiuqVWfrDawJRySTMnH._addon_handle,cacheToDisc=bFdGgEcOhIpmiuqVWfrDawJRySTMPt)
 def option_check(bFdGgEcOhIpmiuqVWfrDawJRySTMnH):
  bFdGgEcOhIpmiuqVWfrDawJRySTMne=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.get_settings_select_info()
  if bFdGgEcOhIpmiuqVWfrDawJRySTMPx(bFdGgEcOhIpmiuqVWfrDawJRySTMne)==0:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnN=xbmcgui.Dialog()
   bFdGgEcOhIpmiuqVWfrDawJRySTMXn=bFdGgEcOhIpmiuqVWfrDawJRySTMnN.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if bFdGgEcOhIpmiuqVWfrDawJRySTMXn==bFdGgEcOhIpmiuqVWfrDawJRySTMPe:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in bFdGgEcOhIpmiuqVWfrDawJRySTMne:
   if bFdGgEcOhIpmiuqVWfrDawJRySTMnH.NF_cookiefile_check()==bFdGgEcOhIpmiuqVWfrDawJRySTMPt:
    bFdGgEcOhIpmiuqVWfrDawJRySTMnH.NF_login(showMessage=bFdGgEcOhIpmiuqVWfrDawJRySTMPe)
  if 'disney' in bFdGgEcOhIpmiuqVWfrDawJRySTMne:
   if bFdGgEcOhIpmiuqVWfrDawJRySTMnH.DZ_cookiefile_check()==bFdGgEcOhIpmiuqVWfrDawJRySTMPt:
    bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.DZ={}
 def DZ_cookiefile_check(bFdGgEcOhIpmiuqVWfrDawJRySTMnH):
  bFdGgEcOhIpmiuqVWfrDawJRySTMXH={}
  try: 
   fp=bFdGgEcOhIpmiuqVWfrDawJRySTMPl(bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   bFdGgEcOhIpmiuqVWfrDawJRySTMXH= json.load(fp)
   fp.close()
  except bFdGgEcOhIpmiuqVWfrDawJRySTMPY as exception:
   return bFdGgEcOhIpmiuqVWfrDawJRySTMPt
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.DZ=bFdGgEcOhIpmiuqVWfrDawJRySTMXH
  if bFdGgEcOhIpmiuqVWfrDawJRySTMUn(time.time())>bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.DZ['account']['token_limit']:
   if bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.DZ_ReToken()==bFdGgEcOhIpmiuqVWfrDawJRySTMPt:
    bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_noti(__language__(30920).encode('utf-8'))
    return bFdGgEcOhIpmiuqVWfrDawJRySTMPt
   try: 
    fp=bFdGgEcOhIpmiuqVWfrDawJRySTMPl(bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.DZ,fp,indent=4,ensure_ascii=bFdGgEcOhIpmiuqVWfrDawJRySTMPt)
    fp.close()
   except bFdGgEcOhIpmiuqVWfrDawJRySTMPY as exception:
    return bFdGgEcOhIpmiuqVWfrDawJRySTMPt
  return bFdGgEcOhIpmiuqVWfrDawJRySTMPe
 def NF_cookiefile_check(bFdGgEcOhIpmiuqVWfrDawJRySTMnH):
  bFdGgEcOhIpmiuqVWfrDawJRySTMXH={}
  try: 
   fp=bFdGgEcOhIpmiuqVWfrDawJRySTMPl(bFdGgEcOhIpmiuqVWfrDawJRySTMnP,'r',-1,'utf-8')
   bFdGgEcOhIpmiuqVWfrDawJRySTMXH= json.load(fp)
   fp.close()
  except bFdGgEcOhIpmiuqVWfrDawJRySTMPY as exception:
   return bFdGgEcOhIpmiuqVWfrDawJRySTMPt
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF=bFdGgEcOhIpmiuqVWfrDawJRySTMXH
  bFdGgEcOhIpmiuqVWfrDawJRySTMXs =bFdGgEcOhIpmiuqVWfrDawJRySTMUn(bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  bFdGgEcOhIpmiuqVWfrDawJRySTMXz=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF['SESSION']['limitdate']
  bFdGgEcOhIpmiuqVWfrDawJRySTMXL =bFdGgEcOhIpmiuqVWfrDawJRySTMUn(re.sub('-','',bFdGgEcOhIpmiuqVWfrDawJRySTMXz))
  if bFdGgEcOhIpmiuqVWfrDawJRySTMXL<bFdGgEcOhIpmiuqVWfrDawJRySTMXs:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Init_NF_Total()
   if bFdGgEcOhIpmiuqVWfrDawJRySTMnH.NF_login(showMessage=bFdGgEcOhIpmiuqVWfrDawJRySTMPt)==bFdGgEcOhIpmiuqVWfrDawJRySTMPt:
    return bFdGgEcOhIpmiuqVWfrDawJRySTMPt
  bFdGgEcOhIpmiuqVWfrDawJRySTMXN=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF_CookieFile_Load(bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF_ORIGINAL_COOKIE)
  if(bFdGgEcOhIpmiuqVWfrDawJRySTMXN['NetflixId']!=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF['COOKIES']['NetflixId']or bFdGgEcOhIpmiuqVWfrDawJRySTMXN['SecureNetflixId']!=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF['COOKIES']['SecureNetflixId']or bFdGgEcOhIpmiuqVWfrDawJRySTMXN['flwssn']!=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF['COOKIES']['flwssn']or bFdGgEcOhIpmiuqVWfrDawJRySTMXN['nfvdid']!=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF['COOKIES']['nfvdid']):
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Init_NF_Total()
   if bFdGgEcOhIpmiuqVWfrDawJRySTMnH.NF_login(showMessage=bFdGgEcOhIpmiuqVWfrDawJRySTMPt)==bFdGgEcOhIpmiuqVWfrDawJRySTMPt:
    return bFdGgEcOhIpmiuqVWfrDawJRySTMPt
  return bFdGgEcOhIpmiuqVWfrDawJRySTMPe
 def NF_login(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,showMessage=bFdGgEcOhIpmiuqVWfrDawJRySTMPe):
  if showMessage:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnN=xbmcgui.Dialog()
   bFdGgEcOhIpmiuqVWfrDawJRySTMXn=bFdGgEcOhIpmiuqVWfrDawJRySTMnN.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if bFdGgEcOhIpmiuqVWfrDawJRySTMXn==bFdGgEcOhIpmiuqVWfrDawJRySTMPt:
    return bFdGgEcOhIpmiuqVWfrDawJRySTMPt 
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF['COOKIES']=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF_CookieFile_Load(bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF_ORIGINAL_COOKIE)
  bFdGgEcOhIpmiuqVWfrDawJRySTMXQ=bFdGgEcOhIpmiuqVWfrDawJRySTMPt if bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF['COOKIES']=={}else bFdGgEcOhIpmiuqVWfrDawJRySTMPe
  if bFdGgEcOhIpmiuqVWfrDawJRySTMXQ:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_log('pass1 ok!')
  else:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_log('pass1 error!')
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_noti(__language__(30905).encode('utf-8'))
   return bFdGgEcOhIpmiuqVWfrDawJRySTMPt 
  bFdGgEcOhIpmiuqVWfrDawJRySTMXQ=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF_Get_BaseSession()
  if bFdGgEcOhIpmiuqVWfrDawJRySTMXQ:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_log('pass2 ok!')
  else:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_log('pass2 error!')
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_noti(__language__(30905).encode('utf-8'))
   return bFdGgEcOhIpmiuqVWfrDawJRySTMPt 
  bFdGgEcOhIpmiuqVWfrDawJRySTMXj =bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Now_Datetime()
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF['SESSION']['limitdate']=bFdGgEcOhIpmiuqVWfrDawJRySTMXj.strftime('%Y-%m-%d')
  try: 
   fp=bFdGgEcOhIpmiuqVWfrDawJRySTMPl(bFdGgEcOhIpmiuqVWfrDawJRySTMnP,'w',-1,'utf-8')
   json.dump(bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF,fp,indent=4,ensure_ascii=bFdGgEcOhIpmiuqVWfrDawJRySTMPt)
   fp.close()
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_log('pass3 save ok!')
  except bFdGgEcOhIpmiuqVWfrDawJRySTMPY as exception:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_log('pass3 save error!')
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_noti(__language__(30905).encode('utf-8'))
   return bFdGgEcOhIpmiuqVWfrDawJRySTMPt
  if showMessage:bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_noti(__language__(30904).encode('utf-8'))
  return bFdGgEcOhIpmiuqVWfrDawJRySTMPe
 def NF_logout(bFdGgEcOhIpmiuqVWfrDawJRySTMnH):
  bFdGgEcOhIpmiuqVWfrDawJRySTMnN=xbmcgui.Dialog()
  bFdGgEcOhIpmiuqVWfrDawJRySTMXn=bFdGgEcOhIpmiuqVWfrDawJRySTMnN.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if bFdGgEcOhIpmiuqVWfrDawJRySTMXn==bFdGgEcOhIpmiuqVWfrDawJRySTMPt:return 
  if os.path.isfile(bFdGgEcOhIpmiuqVWfrDawJRySTMnP):os.remove(bFdGgEcOhIpmiuqVWfrDawJRySTMnP)
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,bFdGgEcOhIpmiuqVWfrDawJRySTMXk):
  bFdGgEcOhIpmiuqVWfrDawJRySTMXB=''
  bFdGgEcOhIpmiuqVWfrDawJRySTMXA=7
  try:
   for i in bFdGgEcOhIpmiuqVWfrDawJRySTMUC(bFdGgEcOhIpmiuqVWfrDawJRySTMPx(bFdGgEcOhIpmiuqVWfrDawJRySTMXk)):
    if i>=bFdGgEcOhIpmiuqVWfrDawJRySTMXA:
     bFdGgEcOhIpmiuqVWfrDawJRySTMXB=bFdGgEcOhIpmiuqVWfrDawJRySTMXB+'...'
     break
    bFdGgEcOhIpmiuqVWfrDawJRySTMXB=bFdGgEcOhIpmiuqVWfrDawJRySTMXB+bFdGgEcOhIpmiuqVWfrDawJRySTMXk[i]['title']+'\n'
  except:
   return ''
  return bFdGgEcOhIpmiuqVWfrDawJRySTMXB
 def dp_Search_Group(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,args):
  bFdGgEcOhIpmiuqVWfrDawJRySTMne =bFdGgEcOhIpmiuqVWfrDawJRySTMnH.get_settings_select_info()
  bFdGgEcOhIpmiuqVWfrDawJRySTMXe=[]
  if 'search_key' in args:
   bFdGgEcOhIpmiuqVWfrDawJRySTMXt=args.get('search_key')
  else:
   bFdGgEcOhIpmiuqVWfrDawJRySTMXt=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not bFdGgEcOhIpmiuqVWfrDawJRySTMXt:
    return
  if 'wavve' in bFdGgEcOhIpmiuqVWfrDawJRySTMne:
   (bFdGgEcOhIpmiuqVWfrDawJRySTMXk,bFdGgEcOhIpmiuqVWfrDawJRySTMXo)=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Search_Wavve(bFdGgEcOhIpmiuqVWfrDawJRySTMXt,'TVSHOW',1)
   if bFdGgEcOhIpmiuqVWfrDawJRySTMPx(bFdGgEcOhIpmiuqVWfrDawJRySTMXk)>0:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXl={'sType':'wavve_tvshow','sList':bFdGgEcOhIpmiuqVWfrDawJRySTMnH.MakeText_FreeList(bFdGgEcOhIpmiuqVWfrDawJRySTMXk),}
    bFdGgEcOhIpmiuqVWfrDawJRySTMXe.append(bFdGgEcOhIpmiuqVWfrDawJRySTMXl)
   (bFdGgEcOhIpmiuqVWfrDawJRySTMXk,bFdGgEcOhIpmiuqVWfrDawJRySTMXo)=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Search_Wavve(bFdGgEcOhIpmiuqVWfrDawJRySTMXt,'MOVIE',1)
   if bFdGgEcOhIpmiuqVWfrDawJRySTMPx(bFdGgEcOhIpmiuqVWfrDawJRySTMXk)>0:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXl={'sType':'wavve_movie','sList':bFdGgEcOhIpmiuqVWfrDawJRySTMnH.MakeText_FreeList(bFdGgEcOhIpmiuqVWfrDawJRySTMXk),}
    bFdGgEcOhIpmiuqVWfrDawJRySTMXe.append(bFdGgEcOhIpmiuqVWfrDawJRySTMXl)
  if 'tving' in bFdGgEcOhIpmiuqVWfrDawJRySTMne:
   (bFdGgEcOhIpmiuqVWfrDawJRySTMXk,bFdGgEcOhIpmiuqVWfrDawJRySTMXo)=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Search_Tving(bFdGgEcOhIpmiuqVWfrDawJRySTMXt,'TVSHOW',1)
   if bFdGgEcOhIpmiuqVWfrDawJRySTMPx(bFdGgEcOhIpmiuqVWfrDawJRySTMXk)>0:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXl={'sType':'tving_tvshow','sList':bFdGgEcOhIpmiuqVWfrDawJRySTMnH.MakeText_FreeList(bFdGgEcOhIpmiuqVWfrDawJRySTMXk),}
    bFdGgEcOhIpmiuqVWfrDawJRySTMXe.append(bFdGgEcOhIpmiuqVWfrDawJRySTMXl)
   (bFdGgEcOhIpmiuqVWfrDawJRySTMXk,bFdGgEcOhIpmiuqVWfrDawJRySTMXo)=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Search_Tving(bFdGgEcOhIpmiuqVWfrDawJRySTMXt,'MOVIE',1)
   if bFdGgEcOhIpmiuqVWfrDawJRySTMPx(bFdGgEcOhIpmiuqVWfrDawJRySTMXk)>0:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXl={'sType':'tving_movie','sList':bFdGgEcOhIpmiuqVWfrDawJRySTMnH.MakeText_FreeList(bFdGgEcOhIpmiuqVWfrDawJRySTMXk),}
    bFdGgEcOhIpmiuqVWfrDawJRySTMXe.append(bFdGgEcOhIpmiuqVWfrDawJRySTMXl)
  if 'watcha' in bFdGgEcOhIpmiuqVWfrDawJRySTMne:
   (bFdGgEcOhIpmiuqVWfrDawJRySTMXk,bFdGgEcOhIpmiuqVWfrDawJRySTMXo)=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Search_Watcha(bFdGgEcOhIpmiuqVWfrDawJRySTMXt,1)
   if bFdGgEcOhIpmiuqVWfrDawJRySTMPx(bFdGgEcOhIpmiuqVWfrDawJRySTMXk)>0:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXl={'sType':'watcha_list','sList':bFdGgEcOhIpmiuqVWfrDawJRySTMnH.MakeText_FreeList(bFdGgEcOhIpmiuqVWfrDawJRySTMXk),}
    bFdGgEcOhIpmiuqVWfrDawJRySTMXe.append(bFdGgEcOhIpmiuqVWfrDawJRySTMXl)
  if 'coupang' in bFdGgEcOhIpmiuqVWfrDawJRySTMne:
   (bFdGgEcOhIpmiuqVWfrDawJRySTMXk,bFdGgEcOhIpmiuqVWfrDawJRySTMXo)=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Search_Coupang(bFdGgEcOhIpmiuqVWfrDawJRySTMXt,1)
   if bFdGgEcOhIpmiuqVWfrDawJRySTMPx(bFdGgEcOhIpmiuqVWfrDawJRySTMXk)>0:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXl={'sType':'coupang_list','sList':bFdGgEcOhIpmiuqVWfrDawJRySTMnH.MakeText_FreeList(bFdGgEcOhIpmiuqVWfrDawJRySTMXk),}
    bFdGgEcOhIpmiuqVWfrDawJRySTMXe.append(bFdGgEcOhIpmiuqVWfrDawJRySTMXl)
  if 'netflix' in bFdGgEcOhIpmiuqVWfrDawJRySTMne:
   try:
    (bFdGgEcOhIpmiuqVWfrDawJRySTMXk,bFdGgEcOhIpmiuqVWfrDawJRySTMXo,bFdGgEcOhIpmiuqVWfrDawJRySTMXx)=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Search_Netflix(bFdGgEcOhIpmiuqVWfrDawJRySTMXt,1)
   except:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXk=[]
    bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_noti(__language__(30919).encode('utf8'))
   if bFdGgEcOhIpmiuqVWfrDawJRySTMPx(bFdGgEcOhIpmiuqVWfrDawJRySTMXk)>0:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXl={'sType':'netflix_list','sList':bFdGgEcOhIpmiuqVWfrDawJRySTMnH.MakeText_FreeList(bFdGgEcOhIpmiuqVWfrDawJRySTMXk),}
    bFdGgEcOhIpmiuqVWfrDawJRySTMXe.append(bFdGgEcOhIpmiuqVWfrDawJRySTMXl)
  if 'amazon' in bFdGgEcOhIpmiuqVWfrDawJRySTMne:
   (bFdGgEcOhIpmiuqVWfrDawJRySTMXk)=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Search_Primev(bFdGgEcOhIpmiuqVWfrDawJRySTMXt)
   if bFdGgEcOhIpmiuqVWfrDawJRySTMPx(bFdGgEcOhIpmiuqVWfrDawJRySTMXk)>0:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXl={'sType':'primev_list','sList':bFdGgEcOhIpmiuqVWfrDawJRySTMnH.MakeText_FreeList(bFdGgEcOhIpmiuqVWfrDawJRySTMXk),}
    bFdGgEcOhIpmiuqVWfrDawJRySTMXe.append(bFdGgEcOhIpmiuqVWfrDawJRySTMXl)
  if 'disney' in bFdGgEcOhIpmiuqVWfrDawJRySTMne:
   try:
    (bFdGgEcOhIpmiuqVWfrDawJRySTMXk)=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Search_Disney(bFdGgEcOhIpmiuqVWfrDawJRySTMXt)
   except:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXk=[]
    bFdGgEcOhIpmiuqVWfrDawJRySTMnH.addon_noti(__language__(30921).encode('utf8'))
   if bFdGgEcOhIpmiuqVWfrDawJRySTMPx(bFdGgEcOhIpmiuqVWfrDawJRySTMXk)>0:
    bFdGgEcOhIpmiuqVWfrDawJRySTMXl={'sType':'disney_list','sList':bFdGgEcOhIpmiuqVWfrDawJRySTMnH.MakeText_FreeList(bFdGgEcOhIpmiuqVWfrDawJRySTMXk),}
    bFdGgEcOhIpmiuqVWfrDawJRySTMXe.append(bFdGgEcOhIpmiuqVWfrDawJRySTMXl)
  for bFdGgEcOhIpmiuqVWfrDawJRySTMXY in bFdGgEcOhIpmiuqVWfrDawJRySTMXe:
   bFdGgEcOhIpmiuqVWfrDawJRySTMvn=bFdGgEcOhIpmiuqVWfrDawJRySTMnv[bFdGgEcOhIpmiuqVWfrDawJRySTMXY.get('sType')]
   bFdGgEcOhIpmiuqVWfrDawJRySTMvC={'plot':'검색어 : '+bFdGgEcOhIpmiuqVWfrDawJRySTMXt+'\n\n'+bFdGgEcOhIpmiuqVWfrDawJRySTMXY.get('sList')}
   bFdGgEcOhIpmiuqVWfrDawJRySTMnl=bFdGgEcOhIpmiuqVWfrDawJRySTMvn.get('title')
   bFdGgEcOhIpmiuqVWfrDawJRySTMnk={'mode':bFdGgEcOhIpmiuqVWfrDawJRySTMvn.get('mode'),'ott':bFdGgEcOhIpmiuqVWfrDawJRySTMvn.get('ott'),'vidtype':bFdGgEcOhIpmiuqVWfrDawJRySTMvn.get('vidtype'),'search_key':bFdGgEcOhIpmiuqVWfrDawJRySTMXt}
   if bFdGgEcOhIpmiuqVWfrDawJRySTMvn.get('ott')=='netflix':
    bFdGgEcOhIpmiuqVWfrDawJRySTMvX=''
    bFdGgEcOhIpmiuqVWfrDawJRySTMnk['page'] ='1'
    bFdGgEcOhIpmiuqVWfrDawJRySTMnk['byReference']='-'
   else:
    bFdGgEcOhIpmiuqVWfrDawJRySTMvX=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.make_Hyper_Link(bFdGgEcOhIpmiuqVWfrDawJRySTMnk)
   bFdGgEcOhIpmiuqVWfrDawJRySTMCo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',bFdGgEcOhIpmiuqVWfrDawJRySTMvn.get('icon'))
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.add_dir(bFdGgEcOhIpmiuqVWfrDawJRySTMnl,sublabel='',img=bFdGgEcOhIpmiuqVWfrDawJRySTMCo,infoLabels=bFdGgEcOhIpmiuqVWfrDawJRySTMvC,isFolder=bFdGgEcOhIpmiuqVWfrDawJRySTMPe,params=bFdGgEcOhIpmiuqVWfrDawJRySTMnk,isLink=bFdGgEcOhIpmiuqVWfrDawJRySTMPt,direct_url=bFdGgEcOhIpmiuqVWfrDawJRySTMvX)
  xbmcplugin.endOfDirectory(bFdGgEcOhIpmiuqVWfrDawJRySTMnH._addon_handle)
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.Save_Searched_List(bFdGgEcOhIpmiuqVWfrDawJRySTMXt)
 def make_Hyper_Link(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,args):
  bFdGgEcOhIpmiuqVWfrDawJRySTMvP =args.get('ott')
  bFdGgEcOhIpmiuqVWfrDawJRySTMvU =args.get('vidtype')
  bFdGgEcOhIpmiuqVWfrDawJRySTMXt=args.get('search_key')
  bFdGgEcOhIpmiuqVWfrDawJRySTMvX='-'
  if bFdGgEcOhIpmiuqVWfrDawJRySTMvP=='wavve':
   bFdGgEcOhIpmiuqVWfrDawJRySTMvH={'mode':'LOCAL_SEARCH','sType':'movie' if bFdGgEcOhIpmiuqVWfrDawJRySTMvU=='MOVIE' else 'vod','search_key':bFdGgEcOhIpmiuqVWfrDawJRySTMXt,'page':'1',}
   bFdGgEcOhIpmiuqVWfrDawJRySTMvK=urllib.parse.urlencode(bFdGgEcOhIpmiuqVWfrDawJRySTMvH)
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX='plugin://plugin.video.wavvem/?'
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX+=bFdGgEcOhIpmiuqVWfrDawJRySTMvK
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMvP=='tving':
   bFdGgEcOhIpmiuqVWfrDawJRySTMvH={'mode':'LOCAL_SEARCH','stype':'movie' if bFdGgEcOhIpmiuqVWfrDawJRySTMvU=='MOVIE' else 'vod','search_key':bFdGgEcOhIpmiuqVWfrDawJRySTMXt,'page':'1',}
   bFdGgEcOhIpmiuqVWfrDawJRySTMvK=urllib.parse.urlencode(bFdGgEcOhIpmiuqVWfrDawJRySTMvH)
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX='plugin://plugin.video.tvingm/?'
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX+=bFdGgEcOhIpmiuqVWfrDawJRySTMvK
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMvP=='watcha':
   bFdGgEcOhIpmiuqVWfrDawJRySTMvH={'mode':'LOCAL_SEARCH','search_key':bFdGgEcOhIpmiuqVWfrDawJRySTMXt,'page':'1',}
   bFdGgEcOhIpmiuqVWfrDawJRySTMvK=urllib.parse.urlencode(bFdGgEcOhIpmiuqVWfrDawJRySTMvH)
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX='plugin://plugin.video.watcham/?'
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX+=bFdGgEcOhIpmiuqVWfrDawJRySTMvK
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMvP=='coupang':
   bFdGgEcOhIpmiuqVWfrDawJRySTMvH={'mode':'LOCAL_SEARCH','search_key':bFdGgEcOhIpmiuqVWfrDawJRySTMXt,'page':'1',}
   bFdGgEcOhIpmiuqVWfrDawJRySTMvK=urllib.parse.urlencode(bFdGgEcOhIpmiuqVWfrDawJRySTMvH)
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX='plugin://plugin.video.coupangm/?'
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX+=bFdGgEcOhIpmiuqVWfrDawJRySTMvK
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMvP=='netflix':
   bFdGgEcOhIpmiuqVWfrDawJRySTMvs=args.get('videoid')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvz=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.NF['SESSION']['nowGuid']
   if bFdGgEcOhIpmiuqVWfrDawJRySTMvU=='TVSHOW':
    bFdGgEcOhIpmiuqVWfrDawJRySTMvX='plugin://plugin.video.netflix/directory/show/%s/'%(bFdGgEcOhIpmiuqVWfrDawJRySTMvs)
   else:
    bFdGgEcOhIpmiuqVWfrDawJRySTMvX='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(bFdGgEcOhIpmiuqVWfrDawJRySTMvs,bFdGgEcOhIpmiuqVWfrDawJRySTMvz)
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMvP=='amazon':
   bFdGgEcOhIpmiuqVWfrDawJRySTMvH={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':bFdGgEcOhIpmiuqVWfrDawJRySTMXt,}}
   bFdGgEcOhIpmiuqVWfrDawJRySTMvK=json.dumps(bFdGgEcOhIpmiuqVWfrDawJRySTMvH,separators=(',',':'))
   bFdGgEcOhIpmiuqVWfrDawJRySTMvK=base64.standard_b64encode(bFdGgEcOhIpmiuqVWfrDawJRySTMvK.encode()).decode('utf-8')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvK=bFdGgEcOhIpmiuqVWfrDawJRySTMvK.replace('+','%2B')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX='plugin://plugin.video.primevm/?params='
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX+=bFdGgEcOhIpmiuqVWfrDawJRySTMvK
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMvP=='disney':
   bFdGgEcOhIpmiuqVWfrDawJRySTMvH={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':bFdGgEcOhIpmiuqVWfrDawJRySTMXt,}}
   bFdGgEcOhIpmiuqVWfrDawJRySTMvK=json.dumps(bFdGgEcOhIpmiuqVWfrDawJRySTMvH,separators=(',',':'))
   bFdGgEcOhIpmiuqVWfrDawJRySTMvK=base64.standard_b64encode(bFdGgEcOhIpmiuqVWfrDawJRySTMvK.encode()).decode('utf-8')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvK=bFdGgEcOhIpmiuqVWfrDawJRySTMvK.replace('+','%2B')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX='plugin://plugin.video.disneym/?params='
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX+=bFdGgEcOhIpmiuqVWfrDawJRySTMvK
  return bFdGgEcOhIpmiuqVWfrDawJRySTMvX
 def dp_Nf_Search(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,args):
  bFdGgEcOhIpmiuqVWfrDawJRySTMvL =bFdGgEcOhIpmiuqVWfrDawJRySTMUn(args.get('page'))
  bFdGgEcOhIpmiuqVWfrDawJRySTMXt =args.get('search_key')
  bFdGgEcOhIpmiuqVWfrDawJRySTMXx=args.get('byReference')
  (bFdGgEcOhIpmiuqVWfrDawJRySTMXk,bFdGgEcOhIpmiuqVWfrDawJRySTMXo,bFdGgEcOhIpmiuqVWfrDawJRySTMXx)=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.SearchObj.Get_Search_Netflix(bFdGgEcOhIpmiuqVWfrDawJRySTMXt,bFdGgEcOhIpmiuqVWfrDawJRySTMvL,byReference=bFdGgEcOhIpmiuqVWfrDawJRySTMXx)
  for bFdGgEcOhIpmiuqVWfrDawJRySTMvN in bFdGgEcOhIpmiuqVWfrDawJRySTMXk:
   bFdGgEcOhIpmiuqVWfrDawJRySTMvs =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('videoid')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvU =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('vidtype')
   bFdGgEcOhIpmiuqVWfrDawJRySTMnl =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('title')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvQ =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('mpaa')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvj =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('regularSynopsis')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvB =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('dpSupplemental')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvA=bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('sequiturEvidence')
   bFdGgEcOhIpmiuqVWfrDawJRySTMve =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('thumbnail')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvt =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('year')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvk =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('duration')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvo =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('info_genre')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvl =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('director')
   bFdGgEcOhIpmiuqVWfrDawJRySTMvx =bFdGgEcOhIpmiuqVWfrDawJRySTMvN.get('cast')
   if bFdGgEcOhIpmiuqVWfrDawJRySTMvU=='movie':
    bFdGgEcOhIpmiuqVWfrDawJRySTMCt=' (%s)'%(bFdGgEcOhIpmiuqVWfrDawJRySTMUX(bFdGgEcOhIpmiuqVWfrDawJRySTMvt))
   else:
    bFdGgEcOhIpmiuqVWfrDawJRySTMCt=''
   bFdGgEcOhIpmiuqVWfrDawJRySTMvY=''
   if bFdGgEcOhIpmiuqVWfrDawJRySTMvj:bFdGgEcOhIpmiuqVWfrDawJRySTMvY=bFdGgEcOhIpmiuqVWfrDawJRySTMvY+'\n\n'+bFdGgEcOhIpmiuqVWfrDawJRySTMvj
   if bFdGgEcOhIpmiuqVWfrDawJRySTMvB :bFdGgEcOhIpmiuqVWfrDawJRySTMvY=bFdGgEcOhIpmiuqVWfrDawJRySTMvY+'\n\n'+bFdGgEcOhIpmiuqVWfrDawJRySTMvB
   if bFdGgEcOhIpmiuqVWfrDawJRySTMvA:bFdGgEcOhIpmiuqVWfrDawJRySTMvY=bFdGgEcOhIpmiuqVWfrDawJRySTMvY+'\n\n'+bFdGgEcOhIpmiuqVWfrDawJRySTMvA
   bFdGgEcOhIpmiuqVWfrDawJRySTMvY=bFdGgEcOhIpmiuqVWfrDawJRySTMvY.strip()
   bFdGgEcOhIpmiuqVWfrDawJRySTMCk={'mediatype':'tvshow' if bFdGgEcOhIpmiuqVWfrDawJRySTMvU=='show' else 'movie','title':bFdGgEcOhIpmiuqVWfrDawJRySTMnl,'mpaa':bFdGgEcOhIpmiuqVWfrDawJRySTMvQ,'plot':bFdGgEcOhIpmiuqVWfrDawJRySTMvY,'duration':bFdGgEcOhIpmiuqVWfrDawJRySTMvk,'genre':bFdGgEcOhIpmiuqVWfrDawJRySTMvo,'director':bFdGgEcOhIpmiuqVWfrDawJRySTMvl,'cast':bFdGgEcOhIpmiuqVWfrDawJRySTMvx,'year':bFdGgEcOhIpmiuqVWfrDawJRySTMvt,}
   bFdGgEcOhIpmiuqVWfrDawJRySTMnk={'ott':'netflix','vidtype':'TVSHOW' if bFdGgEcOhIpmiuqVWfrDawJRySTMvU=='show' else 'MOVIE','videoid':bFdGgEcOhIpmiuqVWfrDawJRySTMvs,}
   bFdGgEcOhIpmiuqVWfrDawJRySTMvX=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.make_Hyper_Link(bFdGgEcOhIpmiuqVWfrDawJRySTMnk)
   bFdGgEcOhIpmiuqVWfrDawJRySTMXv=bFdGgEcOhIpmiuqVWfrDawJRySTMPe if bFdGgEcOhIpmiuqVWfrDawJRySTMvU=='show' else bFdGgEcOhIpmiuqVWfrDawJRySTMPt
   if bFdGgEcOhIpmiuqVWfrDawJRySTMnH.get_settings_makebookmark():
    bFdGgEcOhIpmiuqVWfrDawJRySTMPn={'mode':'SET_BOOKMARK','values':{'videoid':bFdGgEcOhIpmiuqVWfrDawJRySTMvs,'vidtype':'tvshow' if bFdGgEcOhIpmiuqVWfrDawJRySTMvU=='show' else 'movie','vtitle':bFdGgEcOhIpmiuqVWfrDawJRySTMnl+bFdGgEcOhIpmiuqVWfrDawJRySTMCt,'vsubtitle':'','vinfo':bFdGgEcOhIpmiuqVWfrDawJRySTMCk,'thumbnail':bFdGgEcOhIpmiuqVWfrDawJRySTMve,}}
    bFdGgEcOhIpmiuqVWfrDawJRySTMPC=json.dumps(bFdGgEcOhIpmiuqVWfrDawJRySTMPn,separators=(',',':'))
    bFdGgEcOhIpmiuqVWfrDawJRySTMPC=base64.standard_b64encode(bFdGgEcOhIpmiuqVWfrDawJRySTMPC.encode()).decode('utf-8')
    bFdGgEcOhIpmiuqVWfrDawJRySTMPC=bFdGgEcOhIpmiuqVWfrDawJRySTMPC.replace('+','%2B')
    bFdGgEcOhIpmiuqVWfrDawJRySTMPX='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(bFdGgEcOhIpmiuqVWfrDawJRySTMPC)
    bFdGgEcOhIpmiuqVWfrDawJRySTMCe=[('(통합) 찜 영상에 추가',bFdGgEcOhIpmiuqVWfrDawJRySTMPX)]
   else:
    bFdGgEcOhIpmiuqVWfrDawJRySTMCe=bFdGgEcOhIpmiuqVWfrDawJRySTMPA
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.add_dir(bFdGgEcOhIpmiuqVWfrDawJRySTMnl+bFdGgEcOhIpmiuqVWfrDawJRySTMCt,sublabel=bFdGgEcOhIpmiuqVWfrDawJRySTMPA,img=bFdGgEcOhIpmiuqVWfrDawJRySTMve,infoLabels=bFdGgEcOhIpmiuqVWfrDawJRySTMCk,isFolder=bFdGgEcOhIpmiuqVWfrDawJRySTMXv,params=bFdGgEcOhIpmiuqVWfrDawJRySTMnk,isLink=bFdGgEcOhIpmiuqVWfrDawJRySTMPt,ContextMenu=bFdGgEcOhIpmiuqVWfrDawJRySTMCe,direct_url=bFdGgEcOhIpmiuqVWfrDawJRySTMvX)
  if bFdGgEcOhIpmiuqVWfrDawJRySTMXo:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnk={}
   bFdGgEcOhIpmiuqVWfrDawJRySTMnk['mode'] ='NF_SEARCH' 
   bFdGgEcOhIpmiuqVWfrDawJRySTMnk['page'] =bFdGgEcOhIpmiuqVWfrDawJRySTMUX(bFdGgEcOhIpmiuqVWfrDawJRySTMvL+1)
   bFdGgEcOhIpmiuqVWfrDawJRySTMnk['search_key']=bFdGgEcOhIpmiuqVWfrDawJRySTMXt
   bFdGgEcOhIpmiuqVWfrDawJRySTMnk['byReference']=bFdGgEcOhIpmiuqVWfrDawJRySTMXx
   bFdGgEcOhIpmiuqVWfrDawJRySTMnl='[B]%s >>[/B]'%'다음 페이지'
   bFdGgEcOhIpmiuqVWfrDawJRySTMPv=bFdGgEcOhIpmiuqVWfrDawJRySTMUX(bFdGgEcOhIpmiuqVWfrDawJRySTMvL+1)
   bFdGgEcOhIpmiuqVWfrDawJRySTMCo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.add_dir(bFdGgEcOhIpmiuqVWfrDawJRySTMnl,sublabel=bFdGgEcOhIpmiuqVWfrDawJRySTMPv,img=bFdGgEcOhIpmiuqVWfrDawJRySTMCo,infoLabels=bFdGgEcOhIpmiuqVWfrDawJRySTMPA,isFolder=bFdGgEcOhIpmiuqVWfrDawJRySTMPe,params=bFdGgEcOhIpmiuqVWfrDawJRySTMnk)
  xbmcplugin.setContent(bFdGgEcOhIpmiuqVWfrDawJRySTMnH._addon_handle,'movies')
  xbmcplugin.endOfDirectory(bFdGgEcOhIpmiuqVWfrDawJRySTMnH._addon_handle)
 def dp_Bookmark_Menu(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,args):
  bFdGgEcOhIpmiuqVWfrDawJRySTMPU='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(bFdGgEcOhIpmiuqVWfrDawJRySTMPU)
 def dp_Set_Bookmark(bFdGgEcOhIpmiuqVWfrDawJRySTMnH,args):
  bFdGgEcOhIpmiuqVWfrDawJRySTMvs =args.get('videoid')
  bFdGgEcOhIpmiuqVWfrDawJRySTMvU =args.get('vidtype')
  bFdGgEcOhIpmiuqVWfrDawJRySTMPH =args.get('vtitle')
  bFdGgEcOhIpmiuqVWfrDawJRySTMPK =args.get('vsubtitle')
  bFdGgEcOhIpmiuqVWfrDawJRySTMPs =args.get('vinfo')
  bFdGgEcOhIpmiuqVWfrDawJRySTMve =args.get('thumbnail')
  bFdGgEcOhIpmiuqVWfrDawJRySTMnN=xbmcgui.Dialog()
  bFdGgEcOhIpmiuqVWfrDawJRySTMXn=bFdGgEcOhIpmiuqVWfrDawJRySTMnN.yesno(__language__(30917).encode('utf8'),bFdGgEcOhIpmiuqVWfrDawJRySTMPH+' \n\n'+__language__(30918))
  if bFdGgEcOhIpmiuqVWfrDawJRySTMXn==bFdGgEcOhIpmiuqVWfrDawJRySTMPt:return
  bFdGgEcOhIpmiuqVWfrDawJRySTMPz={'indexinfo':{'ott':'netflix','videoid':bFdGgEcOhIpmiuqVWfrDawJRySTMvs,'vidtype':bFdGgEcOhIpmiuqVWfrDawJRySTMvU,},'saveinfo':{'title':bFdGgEcOhIpmiuqVWfrDawJRySTMPH,'subtitle':bFdGgEcOhIpmiuqVWfrDawJRySTMPK,'thumbnail':bFdGgEcOhIpmiuqVWfrDawJRySTMve,'infoLabels':bFdGgEcOhIpmiuqVWfrDawJRySTMPs,},}
  bFdGgEcOhIpmiuqVWfrDawJRySTMnk={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':bFdGgEcOhIpmiuqVWfrDawJRySTMPz,}}
  bFdGgEcOhIpmiuqVWfrDawJRySTMno=json.dumps(bFdGgEcOhIpmiuqVWfrDawJRySTMnk,separators=(',',':'))
  bFdGgEcOhIpmiuqVWfrDawJRySTMno=base64.standard_b64encode(bFdGgEcOhIpmiuqVWfrDawJRySTMno.encode()).decode('utf-8')
  bFdGgEcOhIpmiuqVWfrDawJRySTMno=bFdGgEcOhIpmiuqVWfrDawJRySTMno.replace('+','%2B')
  bFdGgEcOhIpmiuqVWfrDawJRySTMPX='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(bFdGgEcOhIpmiuqVWfrDawJRySTMno)
  xbmc.executebuiltin(bFdGgEcOhIpmiuqVWfrDawJRySTMPX)
 def search_main(bFdGgEcOhIpmiuqVWfrDawJRySTMnH):
  bFdGgEcOhIpmiuqVWfrDawJRySTMPL=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.main_params.get('params')
  if bFdGgEcOhIpmiuqVWfrDawJRySTMPL:
   bFdGgEcOhIpmiuqVWfrDawJRySTMPN =base64.standard_b64decode(bFdGgEcOhIpmiuqVWfrDawJRySTMPL).decode('utf-8')
   bFdGgEcOhIpmiuqVWfrDawJRySTMPN =json.loads(bFdGgEcOhIpmiuqVWfrDawJRySTMPN)
   bFdGgEcOhIpmiuqVWfrDawJRySTMPQ =bFdGgEcOhIpmiuqVWfrDawJRySTMPN.get('mode')
   bFdGgEcOhIpmiuqVWfrDawJRySTMPj =bFdGgEcOhIpmiuqVWfrDawJRySTMPN.get('values')
  else:
   bFdGgEcOhIpmiuqVWfrDawJRySTMPQ=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.main_params.get('mode',bFdGgEcOhIpmiuqVWfrDawJRySTMPA)
   bFdGgEcOhIpmiuqVWfrDawJRySTMPj=bFdGgEcOhIpmiuqVWfrDawJRySTMnH.main_params
  if bFdGgEcOhIpmiuqVWfrDawJRySTMPQ=='NFLOGOUT':
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.NF_logout()
   return
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMPQ=='NFLOGIN':
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.NF_login(showMessage=bFdGgEcOhIpmiuqVWfrDawJRySTMPe)
   return
  bFdGgEcOhIpmiuqVWfrDawJRySTMnH.option_check()
  if bFdGgEcOhIpmiuqVWfrDawJRySTMPQ is bFdGgEcOhIpmiuqVWfrDawJRySTMPA:
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.dp_Main_List()
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMPQ=='TOTAL_SEARCH':
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.dp_Search_Group(bFdGgEcOhIpmiuqVWfrDawJRySTMPj)
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMPQ=='NF_SEARCH':
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.dp_Nf_Search(bFdGgEcOhIpmiuqVWfrDawJRySTMPj)
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMPQ=='TOTAL_HISTORY':
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.dp_Search_History(bFdGgEcOhIpmiuqVWfrDawJRySTMPj)
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMPQ=='HISTORY_REMOVE':
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.dp_History_Delete(bFdGgEcOhIpmiuqVWfrDawJRySTMPj)
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMPQ=='MENU_BOOKMARK':
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.dp_Bookmark_Menu(bFdGgEcOhIpmiuqVWfrDawJRySTMPj)
  elif bFdGgEcOhIpmiuqVWfrDawJRySTMPQ=='SET_BOOKMARK':
   bFdGgEcOhIpmiuqVWfrDawJRySTMnH.dp_Set_Bookmark(bFdGgEcOhIpmiuqVWfrDawJRySTMPj)
  else:
   bFdGgEcOhIpmiuqVWfrDawJRySTMPA
# Created by pyminifier (https://github.com/liftoff/pyminifier)
