__author__="NightRain"
DgOctkmqxKlnCNWvLGuBFAdhwrzRyb=object
DgOctkmqxKlnCNWvLGuBFAdhwrzRyI=None
DgOctkmqxKlnCNWvLGuBFAdhwrzRyX=True
DgOctkmqxKlnCNWvLGuBFAdhwrzRyM=print
DgOctkmqxKlnCNWvLGuBFAdhwrzRfp=str
DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ=int
DgOctkmqxKlnCNWvLGuBFAdhwrzRfE=False
DgOctkmqxKlnCNWvLGuBFAdhwrzRfQ=dict
DgOctkmqxKlnCNWvLGuBFAdhwrzRfy=Exception
DgOctkmqxKlnCNWvLGuBFAdhwrzRfU=len
DgOctkmqxKlnCNWvLGuBFAdhwrzRfo=open
DgOctkmqxKlnCNWvLGuBFAdhwrzRfj=type
DgOctkmqxKlnCNWvLGuBFAdhwrzRfS=list
DgOctkmqxKlnCNWvLGuBFAdhwrzRfa=isinstance
DgOctkmqxKlnCNWvLGuBFAdhwrzRfH=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
import http.cookiejar
class DgOctkmqxKlnCNWvLGuBFAdhwrzRpJ(DgOctkmqxKlnCNWvLGuBFAdhwrzRyb):
 def __init__(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_WAVVE ='https://apis.wavve.com'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_TVING_SEARCH='https://search-api.tving.com'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_TVING_IMG ='https://image.tving.com'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_WATCHA ='https://api-mars.watcha.com'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_NETFLIX ='https://www.netflix.com'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_COUPANG ='https://discover.coupangstreaming.com'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_PRIMEV ='https://www.primevideo.com'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_DISNEY ='https://disney.api.edge.bamgrid.com/explore'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_DISNEY_VERSION ='v1.9'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.WAVVE_LIMIT =20 
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_LIMIT =30
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.WATCHA_LIMIT =30
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_LIMIT =20 
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.COUPANG_LIMIT =10 
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DISNEY_LIMIT =10 
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DERECTOR_LIMIT =4
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.CAST_LIMIT =10
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.GENRE_LIMIT =4
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_MOVIE_LITE=['2610061','2610161','261062']
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100','APIKEY':'1e7952d0917d6aab1f0293a063697610','TELECODE':'CSCD0900',}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_HEADER={'user-agent':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND1 ='_342x192'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND2 ='_665x375'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_PORT ='_342x684'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LOGO ='_550x124'
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF={}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['COOKIES']={}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']={}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ={}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.PV={}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.HTTP_CLIENT=requests.Session()
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.CP_ORIGINAL_COOKIE =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.PV_ORIGINAL_COOKIE =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ_ORIGINAL_COOKIE =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_ORIGINAL_COOKIE =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_SESSION_COOKIES1 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_SESSION_COOKIES2 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_SESSION_COOKIES3 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_SESSION_COOKIES4 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_SESSION_FULLTEXT1 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_SESSION_FULLTEXT2 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_SESSION_FULLTEXT3 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_SESSION_FULLTEXT4 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_CONTEXTJSON_FILE1 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_CONTEXTJSON_FILE2 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_CONTEXTJSON_FILE3 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_CONTEXTJSON_FILE4 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_FALCORJSON_FILE1 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_FALCORJSON_FILE2 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_FALCORJSON_FILE3 =''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_FALCORJSON_FILE4 =''
 '''
 def callRequestCookies(self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):
  #setHeader = {'user-agent' : self.USER_AGENT }
  setHeader = self.DEFAULT_HEADER
  if headers: setHeader.update(headers )
  if jobtype == 'Get': # Get/Post
   res = requests.get(url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  else:
   res = requests.post(url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  return res
 ''' 
 def Call_Request(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,payload=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,json=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,params=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,cookies=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,redirects=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX,method='-'):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpQ={'user-agent':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.USER_AGENT}
  if headers:DgOctkmqxKlnCNWvLGuBFAdhwrzRpQ.update(headers)
  if payload!=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI or method=='POST':
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.HTTP_CLIENT.post(url=DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,data=payload,json=json,params=params,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzRpQ,cookies=cookies,allow_redirects=redirects)
  else:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.HTTP_CLIENT.get(url=DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,params=params,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzRpQ,cookies=cookies,allow_redirects=redirects)
  DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.status_code)+' - '+DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.url))
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRpy
 def GetNoCache(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,timetype=1,minutes=0):
  if timetype==1:
   ts=DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ(time.time())
   mi=DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ(minutes*60)
  else:
   ts=DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ(time.time()*1000)
   mi=DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,search_key,sType,page_int):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpU=[]
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpo=DgOctkmqxKlnCNWvLGuBFAdhwrzRJE=1
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpj=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
  try:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpS=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_WAVVE+'/fz/search/band.js'
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpa={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':DgOctkmqxKlnCNWvLGuBFAdhwrzRfp((page_int-1)*DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.WAVVE_LIMIT),'limit':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.WAVVE_LIMIT,'orderby':'score','mtype':'svod',}
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpa.update(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.WAVVE_PARAMS)
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.Call_Request(DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,payload=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,params=DgOctkmqxKlnCNWvLGuBFAdhwrzRpa,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,cookies=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,method='GET')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpH=json.loads(DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.text)
   if not('celllist' in DgOctkmqxKlnCNWvLGuBFAdhwrzRpH['band']):return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpi=DgOctkmqxKlnCNWvLGuBFAdhwrzRpH['band']['celllist']
   for DgOctkmqxKlnCNWvLGuBFAdhwrzRpP in DgOctkmqxKlnCNWvLGuBFAdhwrzRpi:
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpe =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['event_list'][1]['url']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpT=urllib.parse.urlsplit(DgOctkmqxKlnCNWvLGuBFAdhwrzRpe).query
    DgOctkmqxKlnCNWvLGuBFAdhwrzRps=DgOctkmqxKlnCNWvLGuBFAdhwrzRpT[0:DgOctkmqxKlnCNWvLGuBFAdhwrzRpT.find('=')]
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpY=DgOctkmqxKlnCNWvLGuBFAdhwrzRfQ(urllib.parse.parse_qsl(DgOctkmqxKlnCNWvLGuBFAdhwrzRpT))
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpV=DgOctkmqxKlnCNWvLGuBFAdhwrzRpY.get(DgOctkmqxKlnCNWvLGuBFAdhwrzRps)
    DgOctkmqxKlnCNWvLGuBFAdhwrzRps='TVSHOW' if DgOctkmqxKlnCNWvLGuBFAdhwrzRps=='programid' else 'MOVIE' 
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpb=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['title_list'][0]['text']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpI =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['age']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpX={'title':DgOctkmqxKlnCNWvLGuBFAdhwrzRpb}
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpM=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
    for DgOctkmqxKlnCNWvLGuBFAdhwrzRJp in DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['bottom_taglist']:
     if DgOctkmqxKlnCNWvLGuBFAdhwrzRJp=='won':
      DgOctkmqxKlnCNWvLGuBFAdhwrzRpM=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX
      break
    if DgOctkmqxKlnCNWvLGuBFAdhwrzRpM==DgOctkmqxKlnCNWvLGuBFAdhwrzRyX: 
     DgOctkmqxKlnCNWvLGuBFAdhwrzRpX['title']=DgOctkmqxKlnCNWvLGuBFAdhwrzRpX['title']+' [개별구매]'
    if DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('age')!='21':
     DgOctkmqxKlnCNWvLGuBFAdhwrzRpU.append(DgOctkmqxKlnCNWvLGuBFAdhwrzRpX)
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpo=DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ(DgOctkmqxKlnCNWvLGuBFAdhwrzRpH['band']['pagecount'])
   if DgOctkmqxKlnCNWvLGuBFAdhwrzRpH['band']['count']:DgOctkmqxKlnCNWvLGuBFAdhwrzRJE =DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ(DgOctkmqxKlnCNWvLGuBFAdhwrzRpH['band']['count'])
   else:DgOctkmqxKlnCNWvLGuBFAdhwrzRJE=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.LIST_LIMIT
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpj=DgOctkmqxKlnCNWvLGuBFAdhwrzRpo>DgOctkmqxKlnCNWvLGuBFAdhwrzRJE
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception)
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj 
 def Get_Search_Tving(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,search_key,sType,page_int):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpU=[]
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpj=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
  try:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRJQ ='/search/getSearch.jsp'
   DgOctkmqxKlnCNWvLGuBFAdhwrzRJy={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(page_int),'pageSize':DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_PARMAS.get('SCREENCODE'),'os':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_PARMAS.get('OSCODE'),'network':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_LIMIT)if sType=='TVSHOW' else '0','vodMVReqCnt':DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_LIMIT)if sType=='MOVIE' else '0','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_PARMAS.get('APIKEY'),'networkCode':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_PARMAS.get('NETWORKCODE'),'osCode ':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_PARMAS.get('OSCODE'),'teleCode ':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_PARMAS.get('TELECODE'),'screenCode ':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_PARMAS.get('SCREENCODE')}
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpS=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_TVING_SEARCH+DgOctkmqxKlnCNWvLGuBFAdhwrzRJQ
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.Call_Request(DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,payload=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,params=DgOctkmqxKlnCNWvLGuBFAdhwrzRJy,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,cookies=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,method='GET')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRJf=json.loads(DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.text)
   if sType=='TVSHOW':
    if not('programRsb' in DgOctkmqxKlnCNWvLGuBFAdhwrzRJf):return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJU=DgOctkmqxKlnCNWvLGuBFAdhwrzRJf['programRsb']['dataList']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJo =DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ(DgOctkmqxKlnCNWvLGuBFAdhwrzRJf['programRsb']['count'])
    for DgOctkmqxKlnCNWvLGuBFAdhwrzRpP in DgOctkmqxKlnCNWvLGuBFAdhwrzRJU:
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJj=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['mast_cd']
     DgOctkmqxKlnCNWvLGuBFAdhwrzRpb =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['mast_nm']
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJS=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_TVING_IMG+DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['web_url4']
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJa =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_TVING_IMG+DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['web_url']
     try:
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJH =[]
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJi=[]
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJP =[]
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJe =0
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJT =''
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJs =''
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJY =''
      if DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('actor') !='' and DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('actor') !='-':DgOctkmqxKlnCNWvLGuBFAdhwrzRJH =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('actor').split(',')
      if DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('director')!='' and DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('director')!='-':DgOctkmqxKlnCNWvLGuBFAdhwrzRJi=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('director').split(',')
      if DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('cate_nm')!='' and DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('cate_nm')!='-':DgOctkmqxKlnCNWvLGuBFAdhwrzRJP =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('cate_nm').split('/')
      if 'targetage' in DgOctkmqxKlnCNWvLGuBFAdhwrzRpP:DgOctkmqxKlnCNWvLGuBFAdhwrzRJT=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('targetage')
      if 'broad_dt' in DgOctkmqxKlnCNWvLGuBFAdhwrzRpP:
       DgOctkmqxKlnCNWvLGuBFAdhwrzRJV=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('broad_dt')
       DgOctkmqxKlnCNWvLGuBFAdhwrzRJY='%s-%s-%s'%(DgOctkmqxKlnCNWvLGuBFAdhwrzRJV[:4],DgOctkmqxKlnCNWvLGuBFAdhwrzRJV[4:6],DgOctkmqxKlnCNWvLGuBFAdhwrzRJV[6:])
       DgOctkmqxKlnCNWvLGuBFAdhwrzRJs =DgOctkmqxKlnCNWvLGuBFAdhwrzRJV[:4]
     except:
      DgOctkmqxKlnCNWvLGuBFAdhwrzRyI
     DgOctkmqxKlnCNWvLGuBFAdhwrzRpX={'title':DgOctkmqxKlnCNWvLGuBFAdhwrzRpb,}
     DgOctkmqxKlnCNWvLGuBFAdhwrzRpU.append(DgOctkmqxKlnCNWvLGuBFAdhwrzRpX)
   else:
    if not('vodMVRsb' in DgOctkmqxKlnCNWvLGuBFAdhwrzRJf):return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJb=DgOctkmqxKlnCNWvLGuBFAdhwrzRJf['vodMVRsb']['dataList']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJo =DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ(DgOctkmqxKlnCNWvLGuBFAdhwrzRJf['vodMVRsb']['count'])
    DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(DgOctkmqxKlnCNWvLGuBFAdhwrzRJo)
    for DgOctkmqxKlnCNWvLGuBFAdhwrzRpP in DgOctkmqxKlnCNWvLGuBFAdhwrzRJb:
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJj=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['mast_cd']
     DgOctkmqxKlnCNWvLGuBFAdhwrzRpb =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['mast_nm'].strip()
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJS =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_TVING_IMG+DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['web_url']
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJa =DgOctkmqxKlnCNWvLGuBFAdhwrzRJS
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJI=''
     try:
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJH =[]
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJi=[]
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJP =[]
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJe =0
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJT =''
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJs =''
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJY =''
      if DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('actor') !='' and DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('actor') !='-':DgOctkmqxKlnCNWvLGuBFAdhwrzRJH =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('actor').split(',')
      if DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('director')!='' and DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('director')!='-':DgOctkmqxKlnCNWvLGuBFAdhwrzRJi=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('director').split(',')
      if DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('cate_nm')!='' and DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('cate_nm')!='-':DgOctkmqxKlnCNWvLGuBFAdhwrzRJP =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('cate_nm').split('/')
      if DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('runtime_sec')!='':DgOctkmqxKlnCNWvLGuBFAdhwrzRJe=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('runtime_sec')
      if 'grade_nm' in DgOctkmqxKlnCNWvLGuBFAdhwrzRpP:DgOctkmqxKlnCNWvLGuBFAdhwrzRJT=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('grade_nm')
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJX=''
      DgOctkmqxKlnCNWvLGuBFAdhwrzRJV=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('broad_dt')
      if DgOctkmqxKlnCNWvLGuBFAdhwrzRJX!='':
       DgOctkmqxKlnCNWvLGuBFAdhwrzRJY='%s-%s-%s'%(DgOctkmqxKlnCNWvLGuBFAdhwrzRJV[:4],DgOctkmqxKlnCNWvLGuBFAdhwrzRJV[4:6],DgOctkmqxKlnCNWvLGuBFAdhwrzRJV[6:])
       DgOctkmqxKlnCNWvLGuBFAdhwrzRJs =DgOctkmqxKlnCNWvLGuBFAdhwrzRJV[:4]
     except:
      DgOctkmqxKlnCNWvLGuBFAdhwrzRyI
     DgOctkmqxKlnCNWvLGuBFAdhwrzRpX={'title':DgOctkmqxKlnCNWvLGuBFAdhwrzRpb,}
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJM=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
     for DgOctkmqxKlnCNWvLGuBFAdhwrzRJp in DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['bill']:
      if DgOctkmqxKlnCNWvLGuBFAdhwrzRJp in DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_MOVIE_LITE:
       DgOctkmqxKlnCNWvLGuBFAdhwrzRJM=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX
       break
     if DgOctkmqxKlnCNWvLGuBFAdhwrzRJM==DgOctkmqxKlnCNWvLGuBFAdhwrzRfE: 
      DgOctkmqxKlnCNWvLGuBFAdhwrzRpX['title']=DgOctkmqxKlnCNWvLGuBFAdhwrzRpX['title']+' [개별구매]'
     DgOctkmqxKlnCNWvLGuBFAdhwrzRpU.append(DgOctkmqxKlnCNWvLGuBFAdhwrzRpX)
   if DgOctkmqxKlnCNWvLGuBFAdhwrzRJo>(page_int*DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.TVING_LIMIT):DgOctkmqxKlnCNWvLGuBFAdhwrzRpj=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception)
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj
 def Get_Search_Watcha(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,search_key,page_int):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpU=[]
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpj=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
  try:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpS=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_WATCHA+'/api/search.json'
   DgOctkmqxKlnCNWvLGuBFAdhwrzRJy={'query':search_key,'page':DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(page_int),'per':DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.WATCHA_LIMIT),'exclude':'limited',}
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.Call_Request(DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,payload=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,params=DgOctkmqxKlnCNWvLGuBFAdhwrzRJy,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.WATCHA_HEADER,cookies=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,method='GET')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRJf=json.loads(DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.text)
   if not('results' in DgOctkmqxKlnCNWvLGuBFAdhwrzRJf):return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj
   DgOctkmqxKlnCNWvLGuBFAdhwrzREp=DgOctkmqxKlnCNWvLGuBFAdhwrzRJf['results']
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpj=DgOctkmqxKlnCNWvLGuBFAdhwrzRJf['meta']['has_next']
   for DgOctkmqxKlnCNWvLGuBFAdhwrzRpP in DgOctkmqxKlnCNWvLGuBFAdhwrzREp:
    DgOctkmqxKlnCNWvLGuBFAdhwrzREJ =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['code']
    DgOctkmqxKlnCNWvLGuBFAdhwrzREQ=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['content_type']
    DgOctkmqxKlnCNWvLGuBFAdhwrzREy =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['title']
    DgOctkmqxKlnCNWvLGuBFAdhwrzREf =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['story']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJS=DgOctkmqxKlnCNWvLGuBFAdhwrzRJa=DgOctkmqxKlnCNWvLGuBFAdhwrzRyi=''
    if DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('poster') !=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI:DgOctkmqxKlnCNWvLGuBFAdhwrzRJS=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('poster').get('original')
    if DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('stillcut')!=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI:DgOctkmqxKlnCNWvLGuBFAdhwrzRJa =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('stillcut').get('large')
    if DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('thumbnail')!=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI:DgOctkmqxKlnCNWvLGuBFAdhwrzRyi=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('thumbnail').get('large')
    if DgOctkmqxKlnCNWvLGuBFAdhwrzRyi=='' :DgOctkmqxKlnCNWvLGuBFAdhwrzRyi=DgOctkmqxKlnCNWvLGuBFAdhwrzRJa
    DgOctkmqxKlnCNWvLGuBFAdhwrzREU={'thumb':DgOctkmqxKlnCNWvLGuBFAdhwrzRJa,'poster':DgOctkmqxKlnCNWvLGuBFAdhwrzRJS,'fanart':DgOctkmqxKlnCNWvLGuBFAdhwrzRyi}
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJs =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['year']
    DgOctkmqxKlnCNWvLGuBFAdhwrzREo =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['film_rating_code']
    DgOctkmqxKlnCNWvLGuBFAdhwrzREj=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['film_rating_short']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRES =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['film_rating_long']
    if DgOctkmqxKlnCNWvLGuBFAdhwrzREQ=='movies':
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJe =DgOctkmqxKlnCNWvLGuBFAdhwrzRpP['duration']
    else:
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJe ='0'
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpX={'title':DgOctkmqxKlnCNWvLGuBFAdhwrzREy,}
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpU.append(DgOctkmqxKlnCNWvLGuBFAdhwrzRpX)
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception)
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj
 def Get_Search_Coupang(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,search_key,page_int):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpU=[]
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpj=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
  try:
   CP=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.jsonfile_To_dic(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.CP_ORIGINAL_COOKIE)
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpS=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_COUPANG+'/v2/search' 
   DgOctkmqxKlnCNWvLGuBFAdhwrzRJy={'query':search_key,'platform':'WEBCLIENT','page':DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(page_int),'perPage':DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.COUPANG_LIMIT),}
   DgOctkmqxKlnCNWvLGuBFAdhwrzREa={'x-membersrl':CP['COOKIES']['member_srl'],'x-pcid':CP['COOKIES']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.Call_Request(DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,payload=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,params=DgOctkmqxKlnCNWvLGuBFAdhwrzRJy,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzREa,cookies=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,method='GET')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpH=json.loads(DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.text)
   if DgOctkmqxKlnCNWvLGuBFAdhwrzRfU(DgOctkmqxKlnCNWvLGuBFAdhwrzRpH.get('data').get('data'))==0:return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj
   for DgOctkmqxKlnCNWvLGuBFAdhwrzRpP in DgOctkmqxKlnCNWvLGuBFAdhwrzRpH.get('data').get('data'):
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpP=DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('data')
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpX={'title':DgOctkmqxKlnCNWvLGuBFAdhwrzRpP.get('title'),}
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpU.append(DgOctkmqxKlnCNWvLGuBFAdhwrzRpX)
   if DgOctkmqxKlnCNWvLGuBFAdhwrzRpH.get('pagination').get('totalPages')>page_int:
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpj=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception)
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj
 def Selenium_Cookies_Load(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,in_filename):
  fp=DgOctkmqxKlnCNWvLGuBFAdhwrzRfo(in_filename,'rb',-1)
  try:
   DgOctkmqxKlnCNWvLGuBFAdhwrzREH=pickle.loads(fp.read())
   if DgOctkmqxKlnCNWvLGuBFAdhwrzRfj(DgOctkmqxKlnCNWvLGuBFAdhwrzREH)==DgOctkmqxKlnCNWvLGuBFAdhwrzRfS:
    for DgOctkmqxKlnCNWvLGuBFAdhwrzREi in DgOctkmqxKlnCNWvLGuBFAdhwrzREH:
     DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.HTTP_CLIENT.cookies.set_cookie(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.To_Cookielib(DgOctkmqxKlnCNWvLGuBFAdhwrzREi)) 
   else:
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.HTTP_CLIENT.cookies.update(DgOctkmqxKlnCNWvLGuBFAdhwrzREH) 
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception)
  finally:
   fp.close()
 def To_Cookielib(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,selenium_cookie):
  return http.cookiejar.Cookie(version=0,name=selenium_cookie['name'],value=selenium_cookie['value'],port=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,port_specified=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE,domain=selenium_cookie['domain'],domain_specified=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX,domain_initial_dot=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE,path=selenium_cookie['path'],path_specified=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX,secure=selenium_cookie['secure'],expires=selenium_cookie['expiry'],discard=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE,comment=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,comment_url=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,rest={'HttpOnly':selenium_cookie['httpOnly']},rfc2109=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE,)
 def Get_Search_Primev(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,search_key):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpU=[]
  try:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.PV=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.jsonfile_To_dic(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.PV_ORIGINAL_COOKIE)
   DgOctkmqxKlnCNWvLGuBFAdhwrzREe=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.PV['COOKIES']
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpS=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_PRIMEV+'/search/ref=atv_nb_sr?phrase='+urllib.parse.quote_plus(search_key)+'&ie=UTF8'
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.Call_Request(DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,params=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,cookies=DgOctkmqxKlnCNWvLGuBFAdhwrzREe,method='GET')
   if DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.status_code!=200:return[]
   DgOctkmqxKlnCNWvLGuBFAdhwrzRET='{"props":{"containers"'
   DgOctkmqxKlnCNWvLGuBFAdhwrzREs=r'<script type="text/template">\s*(.*?)\s*</script>'
   DgOctkmqxKlnCNWvLGuBFAdhwrzREY=re.compile(DgOctkmqxKlnCNWvLGuBFAdhwrzREs,re.DOTALL).findall(DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.text)
   DgOctkmqxKlnCNWvLGuBFAdhwrzREV='{}'
   for DgOctkmqxKlnCNWvLGuBFAdhwrzREb in DgOctkmqxKlnCNWvLGuBFAdhwrzREY:
    if DgOctkmqxKlnCNWvLGuBFAdhwrzRET in DgOctkmqxKlnCNWvLGuBFAdhwrzREb:
     DgOctkmqxKlnCNWvLGuBFAdhwrzREV=DgOctkmqxKlnCNWvLGuBFAdhwrzREb
     break
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpH=json.loads(DgOctkmqxKlnCNWvLGuBFAdhwrzREV)
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.dic_To_jsonfile(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_CONTEXTJSON_FILE1,DgOctkmqxKlnCNWvLGuBFAdhwrzRpH)
   DgOctkmqxKlnCNWvLGuBFAdhwrzREI=DgOctkmqxKlnCNWvLGuBFAdhwrzRpH.get('props')
   for DgOctkmqxKlnCNWvLGuBFAdhwrzREX in DgOctkmqxKlnCNWvLGuBFAdhwrzREI.get('containers'):
    if DgOctkmqxKlnCNWvLGuBFAdhwrzREX.get('containerType')=='Grid':
     DgOctkmqxKlnCNWvLGuBFAdhwrzREM=DgOctkmqxKlnCNWvLGuBFAdhwrzREX.get('entities')
     break
   for DgOctkmqxKlnCNWvLGuBFAdhwrzRQp in DgOctkmqxKlnCNWvLGuBFAdhwrzREM:
    if 'titleID' not in DgOctkmqxKlnCNWvLGuBFAdhwrzRQp:return[]
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpX={'title':DgOctkmqxKlnCNWvLGuBFAdhwrzRQp.get('title'),}
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpU.append(DgOctkmqxKlnCNWvLGuBFAdhwrzRpX)
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception)
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU
 def Get_Search_Disney(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,search_key):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpU=[]
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpS=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['services']['content']['getSearchResults']['href']
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQJ={'apiVersion':'5.1','region':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge','pageSize':DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DISNEY_LIMIT),'query':search_key,}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpS=DgOctkmqxKlnCNWvLGuBFAdhwrzRpS.format(**DgOctkmqxKlnCNWvLGuBFAdhwrzRQJ)
  DgOctkmqxKlnCNWvLGuBFAdhwrzREa=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.make_DZ_Headers(accessToken=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX,Bearer=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX)
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.Call_Request(DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzREa,cookies=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,method='GET')
  if DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.status_code not in[200,201]:return[]
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQE=DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.json().get('data').get('search')
  for DgOctkmqxKlnCNWvLGuBFAdhwrzRQp in DgOctkmqxKlnCNWvLGuBFAdhwrzRQE.get('hits'):
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQp=DgOctkmqxKlnCNWvLGuBFAdhwrzRQp.get('hit')
   if DgOctkmqxKlnCNWvLGuBFAdhwrzRQp.get('type')=='DmcSeries': 
    DgOctkmqxKlnCNWvLGuBFAdhwrzREy =DgOctkmqxKlnCNWvLGuBFAdhwrzRQp.get('text').get('title').get('full').get('series').get('default').get('content')
   elif DgOctkmqxKlnCNWvLGuBFAdhwrzRQp.get('type')=='DmcVideo':
    DgOctkmqxKlnCNWvLGuBFAdhwrzREy =DgOctkmqxKlnCNWvLGuBFAdhwrzRQp.get('text').get('title').get('full').get('program').get('default').get('content')
   elif DgOctkmqxKlnCNWvLGuBFAdhwrzRQp.get('type')=='StandardCollection':
    DgOctkmqxKlnCNWvLGuBFAdhwrzREy =DgOctkmqxKlnCNWvLGuBFAdhwrzRQp.get('text').get('title').get('full').get('collection').get('default').get('content')
   else:
    return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpX={'title':DgOctkmqxKlnCNWvLGuBFAdhwrzREy,}
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpU.append(DgOctkmqxKlnCNWvLGuBFAdhwrzRpX)
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU
 def Get_Search_Disney2(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,search_key):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpU=[]
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpS ='{}/{}/search'.format(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_DISNEY,DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_DISNEY_VERSION)
  DgOctkmqxKlnCNWvLGuBFAdhwrzREa=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.make_DZ_Headers(accessToken=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX,Bearer=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX)
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpa ={'query':search_key,}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.Call_Request(DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzREa,params=DgOctkmqxKlnCNWvLGuBFAdhwrzRpa,cookies=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,method='GET')
  if DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.status_code not in[200,201]:return[]
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQE=DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.json().get('data').get('page').get('containers')
  for DgOctkmqxKlnCNWvLGuBFAdhwrzRQp in DgOctkmqxKlnCNWvLGuBFAdhwrzRQE[0]['items']:
   DgOctkmqxKlnCNWvLGuBFAdhwrzREy =DgOctkmqxKlnCNWvLGuBFAdhwrzRQp['visuals']['title']
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpX={'title':DgOctkmqxKlnCNWvLGuBFAdhwrzREy,}
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpU.append(DgOctkmqxKlnCNWvLGuBFAdhwrzRpX)
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU
 def dic_To_jsonfile(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,filename,DgOctkmqxKlnCNWvLGuBFAdhwrzRQy):
  if filename=='':return
  fp=DgOctkmqxKlnCNWvLGuBFAdhwrzRfo(filename,'w',-1,'utf-8')
  json.dump(DgOctkmqxKlnCNWvLGuBFAdhwrzRQy,fp,indent=4,ensure_ascii=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE)
  fp.close()
 def jsonfile_To_dic(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,filename):
  if filename=='':return DgOctkmqxKlnCNWvLGuBFAdhwrzRyI
  try:
   fp=DgOctkmqxKlnCNWvLGuBFAdhwrzRfo(filename,'r',-1,'utf-8')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQU=json.load(fp)
   fp.close()
  except:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQU={}
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRQU
 def tempFileSave(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,filename,resText):
  if filename=='':return
  fp=DgOctkmqxKlnCNWvLGuBFAdhwrzRfo(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,filename):
  if filename=='':return
  try:
   fp=DgOctkmqxKlnCNWvLGuBFAdhwrzRfo(filename,'r',-1,'utf-8')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQU=fp.read()
   fp.close()
  except:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQU=''
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRQU
 def make_DZ_Headers(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,accessToken=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX,Bearer=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE):
  if accessToken:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQo=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['account']['accessToken']
  else:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQo=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['headers']['clientApiKey']
  if Bearer:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQo='Bearer {}'.format(DgOctkmqxKlnCNWvLGuBFAdhwrzRQo)
  DgOctkmqxKlnCNWvLGuBFAdhwrzREa={'authorization':DgOctkmqxKlnCNWvLGuBFAdhwrzRQo,'x-application-version':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['headers']['sdkAppVersion'],'x-bamsdk-client-id':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['headers']['clientId'],'x-bamsdk-platform':'windows','x-bamsdk-version':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['headers']['sdkVersion'],'x-dss-edge-accept':'vnd.dss.edge+json; version=2',}
  return DgOctkmqxKlnCNWvLGuBFAdhwrzREa
 def DZ_ReToken(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE):
  try:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpS =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['services']['orchestration']['refreshToken']['href']
   DgOctkmqxKlnCNWvLGuBFAdhwrzREa=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.make_DZ_Headers(accessToken=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE,Bearer=DgOctkmqxKlnCNWvLGuBFAdhwrzRfE)
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQj={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['account']['refreshToken'],}}}
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.Call_Request(DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,json=DgOctkmqxKlnCNWvLGuBFAdhwrzRQj,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzREa,cookies=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,method='POST')
   if DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.status_code not in[200,201]:return DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQE=DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.json()
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['account']['accessToken'] =DgOctkmqxKlnCNWvLGuBFAdhwrzRQE.get('extensions').get('sdk').get('token').get('accessToken')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['account']['accessTokenType']=DgOctkmqxKlnCNWvLGuBFAdhwrzRQE.get('extensions').get('sdk').get('token').get('accessTokenType')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['account']['refreshToken'] =DgOctkmqxKlnCNWvLGuBFAdhwrzRQE.get('extensions').get('sdk').get('token').get('refreshToken')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['account']['token_limit'] =DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ(time.time())+14400 
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['account']['deviceId'] =DgOctkmqxKlnCNWvLGuBFAdhwrzRQE.get('extensions').get('sdk').get('session').get('device').get('id')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DZ['account']['sessionId'] =DgOctkmqxKlnCNWvLGuBFAdhwrzRQE.get('extensions').get('sdk').get('session').get('sessionId')
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception)
   return DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRyX
 def Init_NF_Total(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF={}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['COOKIES']={}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']={}
 def make_NF_XnetflixHeaders(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE):
  DgOctkmqxKlnCNWvLGuBFAdhwrzREa={'x-netflix.browsername':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['esnModel'],'x-netflix.esnprefix':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['nowGuid'],'x-netflix.uiversion':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return DgOctkmqxKlnCNWvLGuBFAdhwrzREa
 def make_NF_ApiParams(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpa={'avif':'false','webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','isTop10KidsSupported':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/mre/pathEvaluator',}
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRpa
 def extract_json(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,content,name):
  DgOctkmqxKlnCNWvLGuBFAdhwrzREs=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  DgOctkmqxKlnCNWvLGuBFAdhwrzREV=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQS=re.compile(DgOctkmqxKlnCNWvLGuBFAdhwrzREs.format(name),re.DOTALL).findall(content)
  DgOctkmqxKlnCNWvLGuBFAdhwrzREV=DgOctkmqxKlnCNWvLGuBFAdhwrzRQS[0]
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQa=DgOctkmqxKlnCNWvLGuBFAdhwrzREV.replace('\\"','\\\\"') 
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQa=DgOctkmqxKlnCNWvLGuBFAdhwrzRQa.replace('\\s','\\\\s') 
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQa=DgOctkmqxKlnCNWvLGuBFAdhwrzRQa.replace('\\n','\\\\n') 
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQa=DgOctkmqxKlnCNWvLGuBFAdhwrzRQa.replace('\\t','\\\\t') 
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQa=DgOctkmqxKlnCNWvLGuBFAdhwrzRQa.encode().decode('unicode_escape') 
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQa=re.sub(r'\\(?!["])',r'\\\\',DgOctkmqxKlnCNWvLGuBFAdhwrzRQa) 
  return json.loads(DgOctkmqxKlnCNWvLGuBFAdhwrzRQa)
 def NF_makestr_paths(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,paths):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQU=[]
  if DgOctkmqxKlnCNWvLGuBFAdhwrzRfa(paths,DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ):
   return '%d'%(paths)
  elif DgOctkmqxKlnCNWvLGuBFAdhwrzRfa(paths,DgOctkmqxKlnCNWvLGuBFAdhwrzRfp):
   return '"%s"'%(paths)
  for DgOctkmqxKlnCNWvLGuBFAdhwrzRQH in paths:
   if DgOctkmqxKlnCNWvLGuBFAdhwrzRfa(DgOctkmqxKlnCNWvLGuBFAdhwrzRQH,DgOctkmqxKlnCNWvLGuBFAdhwrzRfJ):
    DgOctkmqxKlnCNWvLGuBFAdhwrzRQU.append('%d'%(DgOctkmqxKlnCNWvLGuBFAdhwrzRQH))
   elif DgOctkmqxKlnCNWvLGuBFAdhwrzRfa(DgOctkmqxKlnCNWvLGuBFAdhwrzRQH,DgOctkmqxKlnCNWvLGuBFAdhwrzRfp):
    DgOctkmqxKlnCNWvLGuBFAdhwrzRQU.append('"%s"'%(DgOctkmqxKlnCNWvLGuBFAdhwrzRQH))
   elif DgOctkmqxKlnCNWvLGuBFAdhwrzRfa(DgOctkmqxKlnCNWvLGuBFAdhwrzRQH,DgOctkmqxKlnCNWvLGuBFAdhwrzRfS):
    DgOctkmqxKlnCNWvLGuBFAdhwrzRQU.append('[%s]'%(','.join(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_makestr_paths(DgOctkmqxKlnCNWvLGuBFAdhwrzRQH))))
   elif DgOctkmqxKlnCNWvLGuBFAdhwrzRfa(DgOctkmqxKlnCNWvLGuBFAdhwrzRQH,DgOctkmqxKlnCNWvLGuBFAdhwrzRfQ):
    DgOctkmqxKlnCNWvLGuBFAdhwrzRQi=''
    for DgOctkmqxKlnCNWvLGuBFAdhwrzRQP,DgOctkmqxKlnCNWvLGuBFAdhwrzRQe in DgOctkmqxKlnCNWvLGuBFAdhwrzRQH.items():
     DgOctkmqxKlnCNWvLGuBFAdhwrzRQi+='"%s":%s,'%(DgOctkmqxKlnCNWvLGuBFAdhwrzRQP,DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_makestr_paths(DgOctkmqxKlnCNWvLGuBFAdhwrzRQe))
    DgOctkmqxKlnCNWvLGuBFAdhwrzRQU.append('{%s}'%(DgOctkmqxKlnCNWvLGuBFAdhwrzRQi[:-1]))
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRQU
 def NF_Call_pathapi(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,DgOctkmqxKlnCNWvLGuBFAdhwrzRyJ,referer=''):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQT='%s/nq/website/memberapi/%s/pathEvaluator'%(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_NETFLIX,DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['identifier'])
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQj={'path':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_makestr_paths(DgOctkmqxKlnCNWvLGuBFAdhwrzRyJ),'authURL':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']['authURL']}
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpa=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.make_NF_ApiParams()
  DgOctkmqxKlnCNWvLGuBFAdhwrzREa={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_NETFLIX,'sec-ch-ua':'"Google Chrome";v="101", "Not)A;Brand";v="8", "Chromium";v="101"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':DgOctkmqxKlnCNWvLGuBFAdhwrzREa['referer']=referer
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQs=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.make_NF_XnetflixHeaders()
  DgOctkmqxKlnCNWvLGuBFAdhwrzREa.update(DgOctkmqxKlnCNWvLGuBFAdhwrzRQs)
  DgOctkmqxKlnCNWvLGuBFAdhwrzREe=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_Get_DefaultCookies()
  DgOctkmqxKlnCNWvLGuBFAdhwrzREe['profilesNewSession']='0'
  try:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.Call_Request(DgOctkmqxKlnCNWvLGuBFAdhwrzRQT,payload=DgOctkmqxKlnCNWvLGuBFAdhwrzRQj,params=DgOctkmqxKlnCNWvLGuBFAdhwrzRpa,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzREa,cookies=DgOctkmqxKlnCNWvLGuBFAdhwrzREe,method='POST')
   return DgOctkmqxKlnCNWvLGuBFAdhwrzRpy
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception)
   return DgOctkmqxKlnCNWvLGuBFAdhwrzRyI
 def Get_Search_Netflix(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,search_key,page_int,byReference=''):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQY=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.DERECTOR_LIMIT
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQV =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.CAST_LIMIT
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQb =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.GENRE_LIMIT
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQI =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_LIMIT*(page_int-1)
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQX =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_LIMIT*page_int 
  DgOctkmqxKlnCNWvLGuBFAdhwrzRQM="|%s"%(search_key)
  DgOctkmqxKlnCNWvLGuBFAdhwrzRyp ='%s/search?%s'%(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyJ=[["search","byTerm",DgOctkmqxKlnCNWvLGuBFAdhwrzRQM,"titles",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_LIMIT,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"summary"],["search","byTerm",DgOctkmqxKlnCNWvLGuBFAdhwrzRQM,"titles",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_LIMIT,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",DgOctkmqxKlnCNWvLGuBFAdhwrzRQM,"titles",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_LIMIT,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference","boxarts",[DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND2,DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_PORT],"jpg"],["search","byTerm",DgOctkmqxKlnCNWvLGuBFAdhwrzRQM,"titles",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_LIMIT,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference","interestingMoment",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND1,"jpg"],["search","byTerm",DgOctkmqxKlnCNWvLGuBFAdhwrzRQM,"titles",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_LIMIT,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference","storyArt",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND2,"jpg"],["search","byTerm",DgOctkmqxKlnCNWvLGuBFAdhwrzRQM,"titles",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_LIMIT,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference",["cast","creators","directors"],{"from":0,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQY},["id","name"]],["search","byTerm",DgOctkmqxKlnCNWvLGuBFAdhwrzRQM,"titles",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_LIMIT,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference","genres",{"from":0,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQb},["id","name"]],["search","byTerm",DgOctkmqxKlnCNWvLGuBFAdhwrzRQM,"titles",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NETFLIX_LIMIT,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LOGO,"png"],]
  else:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyJ=[["search","byReference",byReference,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"summary"],["search","byReference",byReference,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference","boxarts",[DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND2,DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference","interestingMoment",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference","storyArt",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference",["cast","creators","directors"],{"from":0,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQY},["id","name"]],["search","byReference",byReference,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference","genres",{"from":0,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQb},["id","name"]],["search","byReference",byReference,{"from":DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,"to":DgOctkmqxKlnCNWvLGuBFAdhwrzRQX},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LOGO,"png"],]
  try:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_Call_pathapi(DgOctkmqxKlnCNWvLGuBFAdhwrzRyJ,DgOctkmqxKlnCNWvLGuBFAdhwrzRyp)
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpH=json.loads(DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.text)
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception)
  (DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj,byReference)=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.Search_Netflix_Make(DgOctkmqxKlnCNWvLGuBFAdhwrzRpH)
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj,byReference
 def Search_Netflix_Make(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,jsonSource):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpU=[]
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpj =DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
  DgOctkmqxKlnCNWvLGuBFAdhwrzRyE=''
  DgOctkmqxKlnCNWvLGuBFAdhwrzRyQ=jsonSource.get('paths')[0][1]
  if DgOctkmqxKlnCNWvLGuBFAdhwrzRyQ=='byTerm':
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQI =jsonSource['paths'][0][5]['from']
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQX =jsonSource['paths'][0][5]['to']
  else:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQI =jsonSource['paths'][0][3]['from']
   DgOctkmqxKlnCNWvLGuBFAdhwrzRQX =jsonSource['paths'][0][3]['to']
  DgOctkmqxKlnCNWvLGuBFAdhwrzRyE=DgOctkmqxKlnCNWvLGuBFAdhwrzRfS(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  DgOctkmqxKlnCNWvLGuBFAdhwrzRyf=jsonSource.get('jsonGraph').get('search').get('byReference').get(DgOctkmqxKlnCNWvLGuBFAdhwrzRyE)
  DgOctkmqxKlnCNWvLGuBFAdhwrzRyU =jsonSource.get('jsonGraph').get('videos')
  DgOctkmqxKlnCNWvLGuBFAdhwrzRyo=jsonSource.get('jsonGraph').get('person')
  DgOctkmqxKlnCNWvLGuBFAdhwrzRyj=jsonSource.get('jsonGraph').get('genres')
  DgOctkmqxKlnCNWvLGuBFAdhwrzRpj=DgOctkmqxKlnCNWvLGuBFAdhwrzRyX if DgOctkmqxKlnCNWvLGuBFAdhwrzRyf[DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRQX)]['reference']['$type']=='ref' else DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
  for DgOctkmqxKlnCNWvLGuBFAdhwrzRyS in DgOctkmqxKlnCNWvLGuBFAdhwrzRfH(DgOctkmqxKlnCNWvLGuBFAdhwrzRQI,DgOctkmqxKlnCNWvLGuBFAdhwrzRQX):
   if DgOctkmqxKlnCNWvLGuBFAdhwrzRyf[DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRyS)]['reference']['$type']=='ref':
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpV =DgOctkmqxKlnCNWvLGuBFAdhwrzRyf[DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(DgOctkmqxKlnCNWvLGuBFAdhwrzRyS)]['reference']['value'][1]
    DgOctkmqxKlnCNWvLGuBFAdhwrzRya=DgOctkmqxKlnCNWvLGuBFAdhwrzRyU[DgOctkmqxKlnCNWvLGuBFAdhwrzRpV]
    DgOctkmqxKlnCNWvLGuBFAdhwrzREy =DgOctkmqxKlnCNWvLGuBFAdhwrzRya['title']['value']
    if DgOctkmqxKlnCNWvLGuBFAdhwrzRya['availability']['value']['isPlayable']==DgOctkmqxKlnCNWvLGuBFAdhwrzRfE:
     continue
    DgOctkmqxKlnCNWvLGuBFAdhwrzRps =DgOctkmqxKlnCNWvLGuBFAdhwrzRya['summary']['value']['type']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJe =0 if DgOctkmqxKlnCNWvLGuBFAdhwrzRps!='movie' else DgOctkmqxKlnCNWvLGuBFAdhwrzRya['runtime']['value']
    if DgOctkmqxKlnCNWvLGuBFAdhwrzRya['sequiturEvidence']['value']['value']:
     DgOctkmqxKlnCNWvLGuBFAdhwrzRyH=DgOctkmqxKlnCNWvLGuBFAdhwrzRya['sequiturEvidence']['value']['value']['text']
    else:
     DgOctkmqxKlnCNWvLGuBFAdhwrzRyH=''
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJS =DgOctkmqxKlnCNWvLGuBFAdhwrzRya['boxarts'][DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_PORT]['jpg']['value']['url']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRyi =DgOctkmqxKlnCNWvLGuBFAdhwrzRya['boxarts'][DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND2]['jpg']['value']['url']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJa=''
    if 'value' in DgOctkmqxKlnCNWvLGuBFAdhwrzRya['storyArt'][DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND2]['jpg']:
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJa =DgOctkmqxKlnCNWvLGuBFAdhwrzRya['storyArt'][DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND2]['jpg']['value']['url']
    if DgOctkmqxKlnCNWvLGuBFAdhwrzRJa=='' and 'value' in DgOctkmqxKlnCNWvLGuBFAdhwrzRya['interestingMoment'][DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND1]['jpg']:
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJa =DgOctkmqxKlnCNWvLGuBFAdhwrzRya['interestingMoment'][DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LAND1]['jpg']['value']['url']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJI=''
    if 'value' in DgOctkmqxKlnCNWvLGuBFAdhwrzRya['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LOGO]['png']:
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJI=DgOctkmqxKlnCNWvLGuBFAdhwrzRya['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.ART_SIZE_LOGO]['png']['value']['url']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJP =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_Subid_List(DgOctkmqxKlnCNWvLGuBFAdhwrzRya['genres'])
    for i in DgOctkmqxKlnCNWvLGuBFAdhwrzRfH(DgOctkmqxKlnCNWvLGuBFAdhwrzRfU(DgOctkmqxKlnCNWvLGuBFAdhwrzRJP)):
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJP[i]=DgOctkmqxKlnCNWvLGuBFAdhwrzRyj[DgOctkmqxKlnCNWvLGuBFAdhwrzRJP[i]]['name']['value']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJi=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_Subid_List(DgOctkmqxKlnCNWvLGuBFAdhwrzRya['directors'])
    DgOctkmqxKlnCNWvLGuBFAdhwrzRyP =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_Subid_List(DgOctkmqxKlnCNWvLGuBFAdhwrzRya['creators'])
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJi.extend(DgOctkmqxKlnCNWvLGuBFAdhwrzRyP)
    for i in DgOctkmqxKlnCNWvLGuBFAdhwrzRfH(DgOctkmqxKlnCNWvLGuBFAdhwrzRfU(DgOctkmqxKlnCNWvLGuBFAdhwrzRJi)):
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJi[i]=DgOctkmqxKlnCNWvLGuBFAdhwrzRyo[DgOctkmqxKlnCNWvLGuBFAdhwrzRJi[i]]['name']['value']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRJH=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_Subid_List(DgOctkmqxKlnCNWvLGuBFAdhwrzRya['cast'])
    for i in DgOctkmqxKlnCNWvLGuBFAdhwrzRfH(DgOctkmqxKlnCNWvLGuBFAdhwrzRfU(DgOctkmqxKlnCNWvLGuBFAdhwrzRJH)):
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJH[i]=DgOctkmqxKlnCNWvLGuBFAdhwrzRyo[DgOctkmqxKlnCNWvLGuBFAdhwrzRJH[i]]['name']['value']
    if 'maturityDescription' in DgOctkmqxKlnCNWvLGuBFAdhwrzRya['maturity']['value']['rating']:
     DgOctkmqxKlnCNWvLGuBFAdhwrzRJT=DgOctkmqxKlnCNWvLGuBFAdhwrzRya['maturity']['value']['rating']['maturityDescription']
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpX={'videoid':DgOctkmqxKlnCNWvLGuBFAdhwrzRpV,'vidtype':DgOctkmqxKlnCNWvLGuBFAdhwrzRps,'title':DgOctkmqxKlnCNWvLGuBFAdhwrzREy,'mpaa':DgOctkmqxKlnCNWvLGuBFAdhwrzRJT,'regularSynopsis':DgOctkmqxKlnCNWvLGuBFAdhwrzRya['regularSynopsis']['value'],'dpSupplemental':DgOctkmqxKlnCNWvLGuBFAdhwrzRya['dpSupplementalMessage']['value'],'sequiturEvidence':DgOctkmqxKlnCNWvLGuBFAdhwrzRyH,'thumbnail':{'poster':DgOctkmqxKlnCNWvLGuBFAdhwrzRJS,'thumb':DgOctkmqxKlnCNWvLGuBFAdhwrzRJa,'fanart':DgOctkmqxKlnCNWvLGuBFAdhwrzRyi,'clearlogo':DgOctkmqxKlnCNWvLGuBFAdhwrzRJI},'year':DgOctkmqxKlnCNWvLGuBFAdhwrzRya['releaseYear']['value'],'duration':DgOctkmqxKlnCNWvLGuBFAdhwrzRJe,'info_genre':DgOctkmqxKlnCNWvLGuBFAdhwrzRJP,'director':DgOctkmqxKlnCNWvLGuBFAdhwrzRJi,'cast':DgOctkmqxKlnCNWvLGuBFAdhwrzRJH,}
    DgOctkmqxKlnCNWvLGuBFAdhwrzRpU.append(DgOctkmqxKlnCNWvLGuBFAdhwrzRpX)
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRpU,DgOctkmqxKlnCNWvLGuBFAdhwrzRpj,DgOctkmqxKlnCNWvLGuBFAdhwrzRyE
 def NF_Subid_List(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,subJson):
  DgOctkmqxKlnCNWvLGuBFAdhwrzRye=[]
  try:
   for i in DgOctkmqxKlnCNWvLGuBFAdhwrzRfH(DgOctkmqxKlnCNWvLGuBFAdhwrzRfU(subJson)):
    if subJson.get(DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(i)).get('$type')!='ref':break
    DgOctkmqxKlnCNWvLGuBFAdhwrzRyT=subJson.get(DgOctkmqxKlnCNWvLGuBFAdhwrzRfp(i)).get('value')[1]
    DgOctkmqxKlnCNWvLGuBFAdhwrzRye.append(DgOctkmqxKlnCNWvLGuBFAdhwrzRyT)
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception)
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRye
 def NF_CookieFile_Load(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE,cookie_filename):
  DgOctkmqxKlnCNWvLGuBFAdhwrzREe={}
  try:
   if os.path.isfile(cookie_filename)==DgOctkmqxKlnCNWvLGuBFAdhwrzRfE:return{}
   DgOctkmqxKlnCNWvLGuBFAdhwrzRys=DgOctkmqxKlnCNWvLGuBFAdhwrzRfo(cookie_filename,'rb',-1)
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyY =pickle.loads(DgOctkmqxKlnCNWvLGuBFAdhwrzRys.read())
   DgOctkmqxKlnCNWvLGuBFAdhwrzRys.close()
   for DgOctkmqxKlnCNWvLGuBFAdhwrzREi in DgOctkmqxKlnCNWvLGuBFAdhwrzRyY:
    DgOctkmqxKlnCNWvLGuBFAdhwrzREe[DgOctkmqxKlnCNWvLGuBFAdhwrzREi.name]=DgOctkmqxKlnCNWvLGuBFAdhwrzREi.value
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception) 
  return DgOctkmqxKlnCNWvLGuBFAdhwrzREe
 def NF_Get_DefaultCookies(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE):
  DgOctkmqxKlnCNWvLGuBFAdhwrzREe={}
  if DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['COOKIES']['flwssn'] :DgOctkmqxKlnCNWvLGuBFAdhwrzREe['flwssn'] =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['COOKIES']['flwssn']
  if DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['COOKIES']['nfvdid'] :DgOctkmqxKlnCNWvLGuBFAdhwrzREe['nfvdid'] =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['COOKIES']['nfvdid']
  if DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['COOKIES']['SecureNetflixId']:DgOctkmqxKlnCNWvLGuBFAdhwrzREe['SecureNetflixId']=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['COOKIES']['SecureNetflixId']
  if DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['COOKIES']['NetflixId'] :DgOctkmqxKlnCNWvLGuBFAdhwrzREe['NetflixId'] =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['COOKIES']['NetflixId']
  return DgOctkmqxKlnCNWvLGuBFAdhwrzREe
 def NF_Get_BaseSession(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE):
  try:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpS=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.API_NETFLIX+'/browse' 
   DgOctkmqxKlnCNWvLGuBFAdhwrzREe=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_Get_DefaultCookies()
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpy=DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.Call_Request(DgOctkmqxKlnCNWvLGuBFAdhwrzRpS,payload=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,params=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,headers=DgOctkmqxKlnCNWvLGuBFAdhwrzRyI,cookies=DgOctkmqxKlnCNWvLGuBFAdhwrzREe,method='GET')
   if DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.status_code!=200:
    DgOctkmqxKlnCNWvLGuBFAdhwrzRyM('pass 1 status_code error')
    return DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyV =DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.extract_json(DgOctkmqxKlnCNWvLGuBFAdhwrzRpy.text,'reactContext')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF['SESSION']={'mainGuid':DgOctkmqxKlnCNWvLGuBFAdhwrzRyV['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':DgOctkmqxKlnCNWvLGuBFAdhwrzRyV['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':DgOctkmqxKlnCNWvLGuBFAdhwrzRyV['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':DgOctkmqxKlnCNWvLGuBFAdhwrzRyV['models']['memberContext']['data']['userInfo']['esn'],'identifier':DgOctkmqxKlnCNWvLGuBFAdhwrzRyV['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':DgOctkmqxKlnCNWvLGuBFAdhwrzRyV['models']['abContext']['data']['headers'],}
   DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.dic_To_jsonfile(DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF_SESSION_COOKIES1,DgOctkmqxKlnCNWvLGuBFAdhwrzRpE.NF)
  except DgOctkmqxKlnCNWvLGuBFAdhwrzRfy as exception:
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM('pass 1 error')
   DgOctkmqxKlnCNWvLGuBFAdhwrzRyM(exception)
   return DgOctkmqxKlnCNWvLGuBFAdhwrzRfE
  return DgOctkmqxKlnCNWvLGuBFAdhwrzRyX
# Created by pyminifier (https://github.com/liftoff/pyminifier)
