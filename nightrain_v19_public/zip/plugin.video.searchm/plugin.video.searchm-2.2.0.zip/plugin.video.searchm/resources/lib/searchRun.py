__author__="NightRain"
VHoGBIrXPnRapYTwNlULEqMOdxjFuz=object
VHoGBIrXPnRapYTwNlULEqMOdxjFut=None
VHoGBIrXPnRapYTwNlULEqMOdxjFuD=True
VHoGBIrXPnRapYTwNlULEqMOdxjFuA=False
VHoGBIrXPnRapYTwNlULEqMOdxjFuc=type
VHoGBIrXPnRapYTwNlULEqMOdxjFug=dict
VHoGBIrXPnRapYTwNlULEqMOdxjFuv=open
VHoGBIrXPnRapYTwNlULEqMOdxjFuJ=len
VHoGBIrXPnRapYTwNlULEqMOdxjFuy=Exception
VHoGBIrXPnRapYTwNlULEqMOdxjFhS=int
VHoGBIrXPnRapYTwNlULEqMOdxjFhb=range
VHoGBIrXPnRapYTwNlULEqMOdxjFhe=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
VHoGBIrXPnRapYTwNlULEqMOdxjFSe=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
VHoGBIrXPnRapYTwNlULEqMOdxjFSm={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
VHoGBIrXPnRapYTwNlULEqMOdxjFSu=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
VHoGBIrXPnRapYTwNlULEqMOdxjFSh =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class VHoGBIrXPnRapYTwNlULEqMOdxjFSb(VHoGBIrXPnRapYTwNlULEqMOdxjFuz):
 def __init__(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,VHoGBIrXPnRapYTwNlULEqMOdxjFSQ,VHoGBIrXPnRapYTwNlULEqMOdxjFSf,VHoGBIrXPnRapYTwNlULEqMOdxjFSk):
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW._addon_url =VHoGBIrXPnRapYTwNlULEqMOdxjFSQ
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW._addon_handle=VHoGBIrXPnRapYTwNlULEqMOdxjFSf
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.main_params =VHoGBIrXPnRapYTwNlULEqMOdxjFSk
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj =ygKupNaqjdrXETOYHDInbehwPWkstQ() 
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_cookies.pk'))
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,sting):
  try:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSK=xbmcgui.Dialog()
   VHoGBIrXPnRapYTwNlULEqMOdxjFSK.notification(__addonname__,sting)
  except:
   VHoGBIrXPnRapYTwNlULEqMOdxjFut
 def addon_log(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,string):
  try:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSs=string.encode('utf-8','ignore')
  except:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSs='addonException: addon_log'
  VHoGBIrXPnRapYTwNlULEqMOdxjFSC=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,VHoGBIrXPnRapYTwNlULEqMOdxjFSs),level=VHoGBIrXPnRapYTwNlULEqMOdxjFSC)
 def get_keyboard_input(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,VHoGBIrXPnRapYTwNlULEqMOdxjFSv):
  VHoGBIrXPnRapYTwNlULEqMOdxjFSz=VHoGBIrXPnRapYTwNlULEqMOdxjFut
  kb=xbmc.Keyboard()
  kb.setHeading(VHoGBIrXPnRapYTwNlULEqMOdxjFSv)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   VHoGBIrXPnRapYTwNlULEqMOdxjFSz=kb.getText()
  return VHoGBIrXPnRapYTwNlULEqMOdxjFSz
 def get_settings_menubookmark(VHoGBIrXPnRapYTwNlULEqMOdxjFSW):
  VHoGBIrXPnRapYTwNlULEqMOdxjFSt=VHoGBIrXPnRapYTwNlULEqMOdxjFuD if __addon__.getSetting('menu_bookmark')=='true' else VHoGBIrXPnRapYTwNlULEqMOdxjFuA
  return(VHoGBIrXPnRapYTwNlULEqMOdxjFSt)
 def get_settings_makebookmark(VHoGBIrXPnRapYTwNlULEqMOdxjFSW):
  return VHoGBIrXPnRapYTwNlULEqMOdxjFuD if __addon__.getSetting('make_bookmark')=='true' else VHoGBIrXPnRapYTwNlULEqMOdxjFuA
 def get_settings_select_info(VHoGBIrXPnRapYTwNlULEqMOdxjFSW):
  VHoGBIrXPnRapYTwNlULEqMOdxjFSD=[]
  if __addon__.getSetting('netflixyn')=='true':VHoGBIrXPnRapYTwNlULEqMOdxjFSD.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':VHoGBIrXPnRapYTwNlULEqMOdxjFSD.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':VHoGBIrXPnRapYTwNlULEqMOdxjFSD.append('tving')
  if __addon__.getSetting('watchayn')=='true':VHoGBIrXPnRapYTwNlULEqMOdxjFSD.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':VHoGBIrXPnRapYTwNlULEqMOdxjFSD.append('coupang')
  if __addon__.getSetting('primevyn')=='true':VHoGBIrXPnRapYTwNlULEqMOdxjFSD.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':VHoGBIrXPnRapYTwNlULEqMOdxjFSD.append('disney')
  return VHoGBIrXPnRapYTwNlULEqMOdxjFSD
 def add_dir(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,label,sublabel='',img='',infoLabels=VHoGBIrXPnRapYTwNlULEqMOdxjFut,isFolder=VHoGBIrXPnRapYTwNlULEqMOdxjFuD,params='',isLink=VHoGBIrXPnRapYTwNlULEqMOdxjFuA,ContextMenu=VHoGBIrXPnRapYTwNlULEqMOdxjFut,direct_url=VHoGBIrXPnRapYTwNlULEqMOdxjFut):
  if direct_url:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSA=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   VHoGBIrXPnRapYTwNlULEqMOdxjFSg=json.dumps(params,separators=(',',':'))
   VHoGBIrXPnRapYTwNlULEqMOdxjFSg=base64.standard_b64encode(VHoGBIrXPnRapYTwNlULEqMOdxjFSg.encode()).decode('utf-8')
   VHoGBIrXPnRapYTwNlULEqMOdxjFSg=VHoGBIrXPnRapYTwNlULEqMOdxjFSg.replace('+','%2B')
   VHoGBIrXPnRapYTwNlULEqMOdxjFSA='%s?params=%s'%(VHoGBIrXPnRapYTwNlULEqMOdxjFSW._addon_url,VHoGBIrXPnRapYTwNlULEqMOdxjFSg)
  if sublabel and sublabel!='-':VHoGBIrXPnRapYTwNlULEqMOdxjFSv='%s < %s >'%(label,sublabel)
  else: VHoGBIrXPnRapYTwNlULEqMOdxjFSv=label
  if not img:img='DefaultFolder.png'
  VHoGBIrXPnRapYTwNlULEqMOdxjFSJ=xbmcgui.ListItem(VHoGBIrXPnRapYTwNlULEqMOdxjFSv)
  if VHoGBIrXPnRapYTwNlULEqMOdxjFuc(img)==VHoGBIrXPnRapYTwNlULEqMOdxjFug:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSJ.setArt(img)
  else:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSJ.setArt({'thumb':img,'poster':img})
  if infoLabels:VHoGBIrXPnRapYTwNlULEqMOdxjFSJ.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSJ.setProperty('IsPlayable','true')
  if ContextMenu:VHoGBIrXPnRapYTwNlULEqMOdxjFSJ.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(VHoGBIrXPnRapYTwNlULEqMOdxjFSW._addon_handle,VHoGBIrXPnRapYTwNlULEqMOdxjFSA,VHoGBIrXPnRapYTwNlULEqMOdxjFSJ,isFolder)
 def Load_Searched_List(VHoGBIrXPnRapYTwNlULEqMOdxjFSW):
  try:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSy=VHoGBIrXPnRapYTwNlULEqMOdxjFSh
   fp=VHoGBIrXPnRapYTwNlULEqMOdxjFuv(VHoGBIrXPnRapYTwNlULEqMOdxjFSy,'r',-1,'utf-8')
   VHoGBIrXPnRapYTwNlULEqMOdxjFbS=fp.readlines()
   fp.close()
  except:
   VHoGBIrXPnRapYTwNlULEqMOdxjFbS=[]
  return VHoGBIrXPnRapYTwNlULEqMOdxjFbS
 def Save_Searched_List(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,VHoGBIrXPnRapYTwNlULEqMOdxjFeA):
  try:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSy=VHoGBIrXPnRapYTwNlULEqMOdxjFSh
   VHoGBIrXPnRapYTwNlULEqMOdxjFbe=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.Load_Searched_List() 
   VHoGBIrXPnRapYTwNlULEqMOdxjFbm={'skey':VHoGBIrXPnRapYTwNlULEqMOdxjFeA.strip()}
   fp=VHoGBIrXPnRapYTwNlULEqMOdxjFuv(VHoGBIrXPnRapYTwNlULEqMOdxjFSy,'w',-1,'utf-8')
   VHoGBIrXPnRapYTwNlULEqMOdxjFbu=urllib.parse.urlencode(VHoGBIrXPnRapYTwNlULEqMOdxjFbm)
   VHoGBIrXPnRapYTwNlULEqMOdxjFbu=VHoGBIrXPnRapYTwNlULEqMOdxjFbu+'\n'
   fp.write(VHoGBIrXPnRapYTwNlULEqMOdxjFbu)
   VHoGBIrXPnRapYTwNlULEqMOdxjFbh=0
   for VHoGBIrXPnRapYTwNlULEqMOdxjFbW in VHoGBIrXPnRapYTwNlULEqMOdxjFbe:
    VHoGBIrXPnRapYTwNlULEqMOdxjFbQ=VHoGBIrXPnRapYTwNlULEqMOdxjFug(urllib.parse.parse_qsl(VHoGBIrXPnRapYTwNlULEqMOdxjFbW))
    VHoGBIrXPnRapYTwNlULEqMOdxjFbf=VHoGBIrXPnRapYTwNlULEqMOdxjFbm.get('skey').strip()
    VHoGBIrXPnRapYTwNlULEqMOdxjFbk=VHoGBIrXPnRapYTwNlULEqMOdxjFbQ.get('skey').strip()
    if VHoGBIrXPnRapYTwNlULEqMOdxjFbf!=VHoGBIrXPnRapYTwNlULEqMOdxjFbk:
     fp.write(VHoGBIrXPnRapYTwNlULEqMOdxjFbW)
     VHoGBIrXPnRapYTwNlULEqMOdxjFbh+=1
     if VHoGBIrXPnRapYTwNlULEqMOdxjFbh>=50:break
   fp.close()
  except:
   VHoGBIrXPnRapYTwNlULEqMOdxjFut
 def dp_Search_History(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,args):
  VHoGBIrXPnRapYTwNlULEqMOdxjFbi=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.Load_Searched_List()
  for VHoGBIrXPnRapYTwNlULEqMOdxjFbK in VHoGBIrXPnRapYTwNlULEqMOdxjFbi:
   VHoGBIrXPnRapYTwNlULEqMOdxjFbs=VHoGBIrXPnRapYTwNlULEqMOdxjFug(urllib.parse.parse_qsl(VHoGBIrXPnRapYTwNlULEqMOdxjFbK))
   VHoGBIrXPnRapYTwNlULEqMOdxjFbC=VHoGBIrXPnRapYTwNlULEqMOdxjFbs.get('skey').strip()
   VHoGBIrXPnRapYTwNlULEqMOdxjFSc={'mode':'TOTAL_SEARCH','search_key':VHoGBIrXPnRapYTwNlULEqMOdxjFbC,}
   VHoGBIrXPnRapYTwNlULEqMOdxjFbz={'mode':'HISTORY_REMOVE','skey':VHoGBIrXPnRapYTwNlULEqMOdxjFbC,'delmode':'ONE',}
   VHoGBIrXPnRapYTwNlULEqMOdxjFbt=urllib.parse.urlencode(VHoGBIrXPnRapYTwNlULEqMOdxjFbz)
   VHoGBIrXPnRapYTwNlULEqMOdxjFbD=[('선택된 검색어 ( %s ) 삭제'%(VHoGBIrXPnRapYTwNlULEqMOdxjFbC),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(VHoGBIrXPnRapYTwNlULEqMOdxjFbt))]
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.add_dir(VHoGBIrXPnRapYTwNlULEqMOdxjFbC,sublabel='',img=VHoGBIrXPnRapYTwNlULEqMOdxjFut,infoLabels=VHoGBIrXPnRapYTwNlULEqMOdxjFut,isFolder=VHoGBIrXPnRapYTwNlULEqMOdxjFuD,params=VHoGBIrXPnRapYTwNlULEqMOdxjFSc,ContextMenu=VHoGBIrXPnRapYTwNlULEqMOdxjFbD)
  VHoGBIrXPnRapYTwNlULEqMOdxjFbc={'plot':'검색목록 전체를 삭제합니다.'}
  VHoGBIrXPnRapYTwNlULEqMOdxjFSv='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  VHoGBIrXPnRapYTwNlULEqMOdxjFSc={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  VHoGBIrXPnRapYTwNlULEqMOdxjFbg=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.add_dir(VHoGBIrXPnRapYTwNlULEqMOdxjFSv,sublabel='',img=VHoGBIrXPnRapYTwNlULEqMOdxjFbg,infoLabels=VHoGBIrXPnRapYTwNlULEqMOdxjFbc,isFolder=VHoGBIrXPnRapYTwNlULEqMOdxjFuA,params=VHoGBIrXPnRapYTwNlULEqMOdxjFSc,isLink=VHoGBIrXPnRapYTwNlULEqMOdxjFuD)
  xbmcplugin.endOfDirectory(VHoGBIrXPnRapYTwNlULEqMOdxjFSW._addon_handle,cacheToDisc=VHoGBIrXPnRapYTwNlULEqMOdxjFuA)
 def Delete_History_List(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,VHoGBIrXPnRapYTwNlULEqMOdxjFbC,VHoGBIrXPnRapYTwNlULEqMOdxjFby):
  if VHoGBIrXPnRapYTwNlULEqMOdxjFby=='ALL':
   try:
    VHoGBIrXPnRapYTwNlULEqMOdxjFSy=VHoGBIrXPnRapYTwNlULEqMOdxjFSh
    fp=VHoGBIrXPnRapYTwNlULEqMOdxjFuv(VHoGBIrXPnRapYTwNlULEqMOdxjFSy,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    VHoGBIrXPnRapYTwNlULEqMOdxjFut
  else:
   try:
    VHoGBIrXPnRapYTwNlULEqMOdxjFSy=VHoGBIrXPnRapYTwNlULEqMOdxjFSh
    VHoGBIrXPnRapYTwNlULEqMOdxjFbe=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.Load_Searched_List() 
    fp=VHoGBIrXPnRapYTwNlULEqMOdxjFuv(VHoGBIrXPnRapYTwNlULEqMOdxjFSy,'w',-1,'utf-8')
    for VHoGBIrXPnRapYTwNlULEqMOdxjFbW in VHoGBIrXPnRapYTwNlULEqMOdxjFbe:
     VHoGBIrXPnRapYTwNlULEqMOdxjFbQ=VHoGBIrXPnRapYTwNlULEqMOdxjFug(urllib.parse.parse_qsl(VHoGBIrXPnRapYTwNlULEqMOdxjFbW))
     VHoGBIrXPnRapYTwNlULEqMOdxjFbJ=VHoGBIrXPnRapYTwNlULEqMOdxjFbQ.get('skey').strip()
     if VHoGBIrXPnRapYTwNlULEqMOdxjFbC!=VHoGBIrXPnRapYTwNlULEqMOdxjFbJ:
      fp.write(VHoGBIrXPnRapYTwNlULEqMOdxjFbW)
    fp.close()
   except:
    VHoGBIrXPnRapYTwNlULEqMOdxjFut
 def dp_History_Delete(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,args):
  VHoGBIrXPnRapYTwNlULEqMOdxjFbC =args.get('skey') 
  VHoGBIrXPnRapYTwNlULEqMOdxjFby=args.get('delmode')
  VHoGBIrXPnRapYTwNlULEqMOdxjFSK=xbmcgui.Dialog()
  if VHoGBIrXPnRapYTwNlULEqMOdxjFby=='ALL':
   VHoGBIrXPnRapYTwNlULEqMOdxjFeS=VHoGBIrXPnRapYTwNlULEqMOdxjFSK.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   VHoGBIrXPnRapYTwNlULEqMOdxjFeS=VHoGBIrXPnRapYTwNlULEqMOdxjFSK.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if VHoGBIrXPnRapYTwNlULEqMOdxjFeS==VHoGBIrXPnRapYTwNlULEqMOdxjFuA:sys.exit()
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.Delete_History_List(VHoGBIrXPnRapYTwNlULEqMOdxjFbC,VHoGBIrXPnRapYTwNlULEqMOdxjFby)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(VHoGBIrXPnRapYTwNlULEqMOdxjFSW):
  VHoGBIrXPnRapYTwNlULEqMOdxjFSt=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.get_settings_menubookmark()
  for VHoGBIrXPnRapYTwNlULEqMOdxjFeb in VHoGBIrXPnRapYTwNlULEqMOdxjFSe:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSv=VHoGBIrXPnRapYTwNlULEqMOdxjFeb.get('title')
   VHoGBIrXPnRapYTwNlULEqMOdxjFbg=''
   if VHoGBIrXPnRapYTwNlULEqMOdxjFeb.get('mode')=='MENU_BOOKMARK' and VHoGBIrXPnRapYTwNlULEqMOdxjFSt==VHoGBIrXPnRapYTwNlULEqMOdxjFuA:continue
   VHoGBIrXPnRapYTwNlULEqMOdxjFSc={'mode':VHoGBIrXPnRapYTwNlULEqMOdxjFeb.get('mode')}
   if VHoGBIrXPnRapYTwNlULEqMOdxjFeb.get('mode')in['XXX','MENU_BOOKMARK']:
    VHoGBIrXPnRapYTwNlULEqMOdxjFem=VHoGBIrXPnRapYTwNlULEqMOdxjFuA
    VHoGBIrXPnRapYTwNlULEqMOdxjFeu =VHoGBIrXPnRapYTwNlULEqMOdxjFuD
   else:
    VHoGBIrXPnRapYTwNlULEqMOdxjFem=VHoGBIrXPnRapYTwNlULEqMOdxjFuD
    VHoGBIrXPnRapYTwNlULEqMOdxjFeu =VHoGBIrXPnRapYTwNlULEqMOdxjFuA
   if 'icon' in VHoGBIrXPnRapYTwNlULEqMOdxjFeb:VHoGBIrXPnRapYTwNlULEqMOdxjFbg=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',VHoGBIrXPnRapYTwNlULEqMOdxjFeb.get('icon')) 
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.add_dir(VHoGBIrXPnRapYTwNlULEqMOdxjFSv,sublabel='',img=VHoGBIrXPnRapYTwNlULEqMOdxjFbg,infoLabels=VHoGBIrXPnRapYTwNlULEqMOdxjFut,isFolder=VHoGBIrXPnRapYTwNlULEqMOdxjFem,params=VHoGBIrXPnRapYTwNlULEqMOdxjFSc,isLink=VHoGBIrXPnRapYTwNlULEqMOdxjFeu)
  xbmcplugin.endOfDirectory(VHoGBIrXPnRapYTwNlULEqMOdxjFSW._addon_handle,cacheToDisc=VHoGBIrXPnRapYTwNlULEqMOdxjFuA)
 def option_check(VHoGBIrXPnRapYTwNlULEqMOdxjFSW):
  VHoGBIrXPnRapYTwNlULEqMOdxjFSD=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.get_settings_select_info()
  if VHoGBIrXPnRapYTwNlULEqMOdxjFuJ(VHoGBIrXPnRapYTwNlULEqMOdxjFSD)==0:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSK=xbmcgui.Dialog()
   VHoGBIrXPnRapYTwNlULEqMOdxjFeS=VHoGBIrXPnRapYTwNlULEqMOdxjFSK.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if VHoGBIrXPnRapYTwNlULEqMOdxjFeS==VHoGBIrXPnRapYTwNlULEqMOdxjFuD:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in VHoGBIrXPnRapYTwNlULEqMOdxjFSD:
   if VHoGBIrXPnRapYTwNlULEqMOdxjFSW.NF_cookiefile_check()==VHoGBIrXPnRapYTwNlULEqMOdxjFuA:
    VHoGBIrXPnRapYTwNlULEqMOdxjFSW.NF_login(showMessage=VHoGBIrXPnRapYTwNlULEqMOdxjFuD)
  if 'disney' in VHoGBIrXPnRapYTwNlULEqMOdxjFSD:
   if VHoGBIrXPnRapYTwNlULEqMOdxjFSW.DZ_cookiefile_check()==VHoGBIrXPnRapYTwNlULEqMOdxjFuA:
    VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.DZ={}
 def DZ_cookiefile_check(VHoGBIrXPnRapYTwNlULEqMOdxjFSW):
  VHoGBIrXPnRapYTwNlULEqMOdxjFeW={}
  try: 
   fp=VHoGBIrXPnRapYTwNlULEqMOdxjFuv(VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   VHoGBIrXPnRapYTwNlULEqMOdxjFeW= json.load(fp)
   fp.close()
  except VHoGBIrXPnRapYTwNlULEqMOdxjFuy as exception:
   return VHoGBIrXPnRapYTwNlULEqMOdxjFuA
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.DZ=VHoGBIrXPnRapYTwNlULEqMOdxjFeW
  if VHoGBIrXPnRapYTwNlULEqMOdxjFhS(time.time())>VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.DZ['account']['token_limit']:
   if VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.DZ_ReToken()==VHoGBIrXPnRapYTwNlULEqMOdxjFuA:
    VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_noti(__language__(30920).encode('utf-8'))
    return VHoGBIrXPnRapYTwNlULEqMOdxjFuA
   try: 
    fp=VHoGBIrXPnRapYTwNlULEqMOdxjFuv(VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.DZ,fp,indent=4,ensure_ascii=VHoGBIrXPnRapYTwNlULEqMOdxjFuA)
    fp.close()
   except VHoGBIrXPnRapYTwNlULEqMOdxjFuy as exception:
    return VHoGBIrXPnRapYTwNlULEqMOdxjFuA
  return VHoGBIrXPnRapYTwNlULEqMOdxjFuD
 def NF_cookiefile_check(VHoGBIrXPnRapYTwNlULEqMOdxjFSW):
  VHoGBIrXPnRapYTwNlULEqMOdxjFeW={}
  try: 
   fp=VHoGBIrXPnRapYTwNlULEqMOdxjFuv(VHoGBIrXPnRapYTwNlULEqMOdxjFSu,'r',-1,'utf-8')
   VHoGBIrXPnRapYTwNlULEqMOdxjFeW= json.load(fp)
   fp.close()
  except VHoGBIrXPnRapYTwNlULEqMOdxjFuy as exception:
   return VHoGBIrXPnRapYTwNlULEqMOdxjFuA
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF=VHoGBIrXPnRapYTwNlULEqMOdxjFeW
  VHoGBIrXPnRapYTwNlULEqMOdxjFef =VHoGBIrXPnRapYTwNlULEqMOdxjFhS(VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  VHoGBIrXPnRapYTwNlULEqMOdxjFek=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF['SESSION']['limitdate']
  VHoGBIrXPnRapYTwNlULEqMOdxjFei =VHoGBIrXPnRapYTwNlULEqMOdxjFhS(re.sub('-','',VHoGBIrXPnRapYTwNlULEqMOdxjFek))
  if VHoGBIrXPnRapYTwNlULEqMOdxjFei<VHoGBIrXPnRapYTwNlULEqMOdxjFef:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Init_NF_Total()
   if VHoGBIrXPnRapYTwNlULEqMOdxjFSW.NF_login(showMessage=VHoGBIrXPnRapYTwNlULEqMOdxjFuA)==VHoGBIrXPnRapYTwNlULEqMOdxjFuA:
    return VHoGBIrXPnRapYTwNlULEqMOdxjFuA
  VHoGBIrXPnRapYTwNlULEqMOdxjFeK=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF_CookieFile_Load(VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF_ORIGINAL_COOKIE)
  if(VHoGBIrXPnRapYTwNlULEqMOdxjFeK['NetflixId']!=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF['COOKIES']['NetflixId']or VHoGBIrXPnRapYTwNlULEqMOdxjFeK['SecureNetflixId']!=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF['COOKIES']['SecureNetflixId']or VHoGBIrXPnRapYTwNlULEqMOdxjFeK['flwssn']!=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF['COOKIES']['flwssn']or VHoGBIrXPnRapYTwNlULEqMOdxjFeK['memclid']!=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF['COOKIES']['memclid']or VHoGBIrXPnRapYTwNlULEqMOdxjFeK['nfvdid']!=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF['COOKIES']['nfvdid']):
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Init_NF_Total()
   if VHoGBIrXPnRapYTwNlULEqMOdxjFSW.NF_login(showMessage=VHoGBIrXPnRapYTwNlULEqMOdxjFuA)==VHoGBIrXPnRapYTwNlULEqMOdxjFuA:
    return VHoGBIrXPnRapYTwNlULEqMOdxjFuA
  return VHoGBIrXPnRapYTwNlULEqMOdxjFuD
 def NF_login(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,showMessage=VHoGBIrXPnRapYTwNlULEqMOdxjFuD):
  if showMessage:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSK=xbmcgui.Dialog()
   VHoGBIrXPnRapYTwNlULEqMOdxjFeS=VHoGBIrXPnRapYTwNlULEqMOdxjFSK.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if VHoGBIrXPnRapYTwNlULEqMOdxjFeS==VHoGBIrXPnRapYTwNlULEqMOdxjFuA:
    return VHoGBIrXPnRapYTwNlULEqMOdxjFuA 
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF['COOKIES']=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF_CookieFile_Load(VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF_ORIGINAL_COOKIE)
  VHoGBIrXPnRapYTwNlULEqMOdxjFes=VHoGBIrXPnRapYTwNlULEqMOdxjFuA if VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF['COOKIES']=={}else VHoGBIrXPnRapYTwNlULEqMOdxjFuD
  if VHoGBIrXPnRapYTwNlULEqMOdxjFes:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_log('pass1 ok!')
  else:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_log('pass1 error!')
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_noti(__language__(30905).encode('utf-8'))
   return VHoGBIrXPnRapYTwNlULEqMOdxjFuA 
  VHoGBIrXPnRapYTwNlULEqMOdxjFes=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF_Get_BaseSession()
  if VHoGBIrXPnRapYTwNlULEqMOdxjFes:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_log('pass2 ok!')
  else:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_log('pass2 error!')
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_noti(__language__(30905).encode('utf-8'))
   return VHoGBIrXPnRapYTwNlULEqMOdxjFuA 
  VHoGBIrXPnRapYTwNlULEqMOdxjFeC =VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Now_Datetime()
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF['SESSION']['limitdate']=VHoGBIrXPnRapYTwNlULEqMOdxjFeC.strftime('%Y-%m-%d')
  try: 
   fp=VHoGBIrXPnRapYTwNlULEqMOdxjFuv(VHoGBIrXPnRapYTwNlULEqMOdxjFSu,'w',-1,'utf-8')
   json.dump(VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF,fp,indent=4,ensure_ascii=VHoGBIrXPnRapYTwNlULEqMOdxjFuA)
   fp.close()
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_log('pass3 save ok!')
  except VHoGBIrXPnRapYTwNlULEqMOdxjFuy as exception:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_log('pass3 save error!')
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_noti(__language__(30905).encode('utf-8'))
   return VHoGBIrXPnRapYTwNlULEqMOdxjFuA
  if showMessage:VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_noti(__language__(30904).encode('utf-8'))
  return VHoGBIrXPnRapYTwNlULEqMOdxjFuD
 def NF_logout(VHoGBIrXPnRapYTwNlULEqMOdxjFSW):
  VHoGBIrXPnRapYTwNlULEqMOdxjFSK=xbmcgui.Dialog()
  VHoGBIrXPnRapYTwNlULEqMOdxjFeS=VHoGBIrXPnRapYTwNlULEqMOdxjFSK.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if VHoGBIrXPnRapYTwNlULEqMOdxjFeS==VHoGBIrXPnRapYTwNlULEqMOdxjFuA:return 
  if os.path.isfile(VHoGBIrXPnRapYTwNlULEqMOdxjFSu):os.remove(VHoGBIrXPnRapYTwNlULEqMOdxjFSu)
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,VHoGBIrXPnRapYTwNlULEqMOdxjFec):
  VHoGBIrXPnRapYTwNlULEqMOdxjFez=''
  VHoGBIrXPnRapYTwNlULEqMOdxjFet=7
  try:
   for i in VHoGBIrXPnRapYTwNlULEqMOdxjFhb(VHoGBIrXPnRapYTwNlULEqMOdxjFuJ(VHoGBIrXPnRapYTwNlULEqMOdxjFec)):
    if i>=VHoGBIrXPnRapYTwNlULEqMOdxjFet:
     VHoGBIrXPnRapYTwNlULEqMOdxjFez=VHoGBIrXPnRapYTwNlULEqMOdxjFez+'...'
     break
    VHoGBIrXPnRapYTwNlULEqMOdxjFez=VHoGBIrXPnRapYTwNlULEqMOdxjFez+VHoGBIrXPnRapYTwNlULEqMOdxjFec[i]['title']+'\n'
  except:
   return ''
  return VHoGBIrXPnRapYTwNlULEqMOdxjFez
 def dp_Search_Group(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,args):
  VHoGBIrXPnRapYTwNlULEqMOdxjFSD =VHoGBIrXPnRapYTwNlULEqMOdxjFSW.get_settings_select_info()
  VHoGBIrXPnRapYTwNlULEqMOdxjFeD=[]
  if 'search_key' in args:
   VHoGBIrXPnRapYTwNlULEqMOdxjFeA=args.get('search_key')
  else:
   VHoGBIrXPnRapYTwNlULEqMOdxjFeA=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VHoGBIrXPnRapYTwNlULEqMOdxjFeA:
    return
  if 'wavve' in VHoGBIrXPnRapYTwNlULEqMOdxjFSD:
   (VHoGBIrXPnRapYTwNlULEqMOdxjFec,VHoGBIrXPnRapYTwNlULEqMOdxjFeg)=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Search_Wavve(VHoGBIrXPnRapYTwNlULEqMOdxjFeA,'TVSHOW',1)
   if VHoGBIrXPnRapYTwNlULEqMOdxjFuJ(VHoGBIrXPnRapYTwNlULEqMOdxjFec)>0:
    VHoGBIrXPnRapYTwNlULEqMOdxjFev={'sType':'wavve_tvshow','sList':VHoGBIrXPnRapYTwNlULEqMOdxjFSW.MakeText_FreeList(VHoGBIrXPnRapYTwNlULEqMOdxjFec),}
    VHoGBIrXPnRapYTwNlULEqMOdxjFeD.append(VHoGBIrXPnRapYTwNlULEqMOdxjFev)
   (VHoGBIrXPnRapYTwNlULEqMOdxjFec,VHoGBIrXPnRapYTwNlULEqMOdxjFeg)=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Search_Wavve(VHoGBIrXPnRapYTwNlULEqMOdxjFeA,'MOVIE',1)
   if VHoGBIrXPnRapYTwNlULEqMOdxjFuJ(VHoGBIrXPnRapYTwNlULEqMOdxjFec)>0:
    VHoGBIrXPnRapYTwNlULEqMOdxjFev={'sType':'wavve_movie','sList':VHoGBIrXPnRapYTwNlULEqMOdxjFSW.MakeText_FreeList(VHoGBIrXPnRapYTwNlULEqMOdxjFec),}
    VHoGBIrXPnRapYTwNlULEqMOdxjFeD.append(VHoGBIrXPnRapYTwNlULEqMOdxjFev)
  if 'tving' in VHoGBIrXPnRapYTwNlULEqMOdxjFSD:
   (VHoGBIrXPnRapYTwNlULEqMOdxjFec,VHoGBIrXPnRapYTwNlULEqMOdxjFeg)=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Search_Tving(VHoGBIrXPnRapYTwNlULEqMOdxjFeA,'TVSHOW',1)
   if VHoGBIrXPnRapYTwNlULEqMOdxjFuJ(VHoGBIrXPnRapYTwNlULEqMOdxjFec)>0:
    VHoGBIrXPnRapYTwNlULEqMOdxjFev={'sType':'tving_tvshow','sList':VHoGBIrXPnRapYTwNlULEqMOdxjFSW.MakeText_FreeList(VHoGBIrXPnRapYTwNlULEqMOdxjFec),}
    VHoGBIrXPnRapYTwNlULEqMOdxjFeD.append(VHoGBIrXPnRapYTwNlULEqMOdxjFev)
   (VHoGBIrXPnRapYTwNlULEqMOdxjFec,VHoGBIrXPnRapYTwNlULEqMOdxjFeg)=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Search_Tving(VHoGBIrXPnRapYTwNlULEqMOdxjFeA,'MOVIE',1)
   if VHoGBIrXPnRapYTwNlULEqMOdxjFuJ(VHoGBIrXPnRapYTwNlULEqMOdxjFec)>0:
    VHoGBIrXPnRapYTwNlULEqMOdxjFev={'sType':'tving_movie','sList':VHoGBIrXPnRapYTwNlULEqMOdxjFSW.MakeText_FreeList(VHoGBIrXPnRapYTwNlULEqMOdxjFec),}
    VHoGBIrXPnRapYTwNlULEqMOdxjFeD.append(VHoGBIrXPnRapYTwNlULEqMOdxjFev)
  if 'watcha' in VHoGBIrXPnRapYTwNlULEqMOdxjFSD:
   (VHoGBIrXPnRapYTwNlULEqMOdxjFec,VHoGBIrXPnRapYTwNlULEqMOdxjFeg)=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Search_Watcha(VHoGBIrXPnRapYTwNlULEqMOdxjFeA,1)
   if VHoGBIrXPnRapYTwNlULEqMOdxjFuJ(VHoGBIrXPnRapYTwNlULEqMOdxjFec)>0:
    VHoGBIrXPnRapYTwNlULEqMOdxjFev={'sType':'watcha_list','sList':VHoGBIrXPnRapYTwNlULEqMOdxjFSW.MakeText_FreeList(VHoGBIrXPnRapYTwNlULEqMOdxjFec),}
    VHoGBIrXPnRapYTwNlULEqMOdxjFeD.append(VHoGBIrXPnRapYTwNlULEqMOdxjFev)
  if 'coupang' in VHoGBIrXPnRapYTwNlULEqMOdxjFSD:
   (VHoGBIrXPnRapYTwNlULEqMOdxjFec,VHoGBIrXPnRapYTwNlULEqMOdxjFeg)=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Search_Coupang(VHoGBIrXPnRapYTwNlULEqMOdxjFeA,1)
   if VHoGBIrXPnRapYTwNlULEqMOdxjFuJ(VHoGBIrXPnRapYTwNlULEqMOdxjFec)>0:
    VHoGBIrXPnRapYTwNlULEqMOdxjFev={'sType':'coupang_list','sList':VHoGBIrXPnRapYTwNlULEqMOdxjFSW.MakeText_FreeList(VHoGBIrXPnRapYTwNlULEqMOdxjFec),}
    VHoGBIrXPnRapYTwNlULEqMOdxjFeD.append(VHoGBIrXPnRapYTwNlULEqMOdxjFev)
  if 'netflix' in VHoGBIrXPnRapYTwNlULEqMOdxjFSD:
   try:
    (VHoGBIrXPnRapYTwNlULEqMOdxjFec,VHoGBIrXPnRapYTwNlULEqMOdxjFeg,VHoGBIrXPnRapYTwNlULEqMOdxjFeJ)=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Search_Netflix(VHoGBIrXPnRapYTwNlULEqMOdxjFeA,1)
   except:
    VHoGBIrXPnRapYTwNlULEqMOdxjFec=[]
    VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_noti(__language__(30919).encode('utf8'))
   if VHoGBIrXPnRapYTwNlULEqMOdxjFuJ(VHoGBIrXPnRapYTwNlULEqMOdxjFec)>0:
    VHoGBIrXPnRapYTwNlULEqMOdxjFev={'sType':'netflix_list','sList':VHoGBIrXPnRapYTwNlULEqMOdxjFSW.MakeText_FreeList(VHoGBIrXPnRapYTwNlULEqMOdxjFec),}
    VHoGBIrXPnRapYTwNlULEqMOdxjFeD.append(VHoGBIrXPnRapYTwNlULEqMOdxjFev)
  if 'amazon' in VHoGBIrXPnRapYTwNlULEqMOdxjFSD:
   (VHoGBIrXPnRapYTwNlULEqMOdxjFec)=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Search_Primev(VHoGBIrXPnRapYTwNlULEqMOdxjFeA)
   if VHoGBIrXPnRapYTwNlULEqMOdxjFuJ(VHoGBIrXPnRapYTwNlULEqMOdxjFec)>0:
    VHoGBIrXPnRapYTwNlULEqMOdxjFev={'sType':'primev_list','sList':VHoGBIrXPnRapYTwNlULEqMOdxjFSW.MakeText_FreeList(VHoGBIrXPnRapYTwNlULEqMOdxjFec),}
    VHoGBIrXPnRapYTwNlULEqMOdxjFeD.append(VHoGBIrXPnRapYTwNlULEqMOdxjFev)
  if 'disney' in VHoGBIrXPnRapYTwNlULEqMOdxjFSD:
   try:
    (VHoGBIrXPnRapYTwNlULEqMOdxjFec)=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Search_Disney(VHoGBIrXPnRapYTwNlULEqMOdxjFeA)
   except:
    VHoGBIrXPnRapYTwNlULEqMOdxjFec=[]
    VHoGBIrXPnRapYTwNlULEqMOdxjFSW.addon_noti(__language__(30921).encode('utf8'))
   if VHoGBIrXPnRapYTwNlULEqMOdxjFuJ(VHoGBIrXPnRapYTwNlULEqMOdxjFec)>0:
    VHoGBIrXPnRapYTwNlULEqMOdxjFev={'sType':'disney_list','sList':VHoGBIrXPnRapYTwNlULEqMOdxjFSW.MakeText_FreeList(VHoGBIrXPnRapYTwNlULEqMOdxjFec),}
    VHoGBIrXPnRapYTwNlULEqMOdxjFeD.append(VHoGBIrXPnRapYTwNlULEqMOdxjFev)
  for VHoGBIrXPnRapYTwNlULEqMOdxjFey in VHoGBIrXPnRapYTwNlULEqMOdxjFeD:
   VHoGBIrXPnRapYTwNlULEqMOdxjFmS=VHoGBIrXPnRapYTwNlULEqMOdxjFSm[VHoGBIrXPnRapYTwNlULEqMOdxjFey.get('sType')]
   VHoGBIrXPnRapYTwNlULEqMOdxjFmb={'plot':'검색어 : '+VHoGBIrXPnRapYTwNlULEqMOdxjFeA+'\n\n'+VHoGBIrXPnRapYTwNlULEqMOdxjFey.get('sList')}
   VHoGBIrXPnRapYTwNlULEqMOdxjFSv=VHoGBIrXPnRapYTwNlULEqMOdxjFmS.get('title')
   VHoGBIrXPnRapYTwNlULEqMOdxjFSc={'mode':VHoGBIrXPnRapYTwNlULEqMOdxjFmS.get('mode'),'ott':VHoGBIrXPnRapYTwNlULEqMOdxjFmS.get('ott'),'vidtype':VHoGBIrXPnRapYTwNlULEqMOdxjFmS.get('vidtype'),'search_key':VHoGBIrXPnRapYTwNlULEqMOdxjFeA}
   if VHoGBIrXPnRapYTwNlULEqMOdxjFmS.get('ott')=='netflix':
    VHoGBIrXPnRapYTwNlULEqMOdxjFme=''
    VHoGBIrXPnRapYTwNlULEqMOdxjFSc['page'] ='1'
    VHoGBIrXPnRapYTwNlULEqMOdxjFSc['byReference']='-'
   else:
    VHoGBIrXPnRapYTwNlULEqMOdxjFme=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.make_Hyper_Link(VHoGBIrXPnRapYTwNlULEqMOdxjFSc)
   VHoGBIrXPnRapYTwNlULEqMOdxjFbg=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',VHoGBIrXPnRapYTwNlULEqMOdxjFmS.get('icon'))
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.add_dir(VHoGBIrXPnRapYTwNlULEqMOdxjFSv,sublabel='',img=VHoGBIrXPnRapYTwNlULEqMOdxjFbg,infoLabels=VHoGBIrXPnRapYTwNlULEqMOdxjFmb,isFolder=VHoGBIrXPnRapYTwNlULEqMOdxjFuD,params=VHoGBIrXPnRapYTwNlULEqMOdxjFSc,isLink=VHoGBIrXPnRapYTwNlULEqMOdxjFuA,direct_url=VHoGBIrXPnRapYTwNlULEqMOdxjFme)
  xbmcplugin.endOfDirectory(VHoGBIrXPnRapYTwNlULEqMOdxjFSW._addon_handle)
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.Save_Searched_List(VHoGBIrXPnRapYTwNlULEqMOdxjFeA)
 def make_Hyper_Link(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,args):
  VHoGBIrXPnRapYTwNlULEqMOdxjFmu =args.get('ott')
  VHoGBIrXPnRapYTwNlULEqMOdxjFmh =args.get('vidtype')
  VHoGBIrXPnRapYTwNlULEqMOdxjFeA=args.get('search_key')
  VHoGBIrXPnRapYTwNlULEqMOdxjFme='-'
  if VHoGBIrXPnRapYTwNlULEqMOdxjFmu=='wavve':
   VHoGBIrXPnRapYTwNlULEqMOdxjFmW={'mode':'LOCAL_SEARCH','sType':'movie' if VHoGBIrXPnRapYTwNlULEqMOdxjFmh=='MOVIE' else 'vod','search_key':VHoGBIrXPnRapYTwNlULEqMOdxjFeA,'page':'1',}
   VHoGBIrXPnRapYTwNlULEqMOdxjFmQ=urllib.parse.urlencode(VHoGBIrXPnRapYTwNlULEqMOdxjFmW)
   VHoGBIrXPnRapYTwNlULEqMOdxjFme='plugin://plugin.video.wavvem/?'
   VHoGBIrXPnRapYTwNlULEqMOdxjFme+=VHoGBIrXPnRapYTwNlULEqMOdxjFmQ
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFmu=='tving':
   VHoGBIrXPnRapYTwNlULEqMOdxjFmW={'mode':'LOCAL_SEARCH','stype':'movie' if VHoGBIrXPnRapYTwNlULEqMOdxjFmh=='MOVIE' else 'vod','search_key':VHoGBIrXPnRapYTwNlULEqMOdxjFeA,'page':'1',}
   VHoGBIrXPnRapYTwNlULEqMOdxjFmQ=urllib.parse.urlencode(VHoGBIrXPnRapYTwNlULEqMOdxjFmW)
   VHoGBIrXPnRapYTwNlULEqMOdxjFme='plugin://plugin.video.tvingm/?'
   VHoGBIrXPnRapYTwNlULEqMOdxjFme+=VHoGBIrXPnRapYTwNlULEqMOdxjFmQ
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFmu=='watcha':
   VHoGBIrXPnRapYTwNlULEqMOdxjFmW={'mode':'LOCAL_SEARCH','search_key':VHoGBIrXPnRapYTwNlULEqMOdxjFeA,'page':'1',}
   VHoGBIrXPnRapYTwNlULEqMOdxjFmQ=urllib.parse.urlencode(VHoGBIrXPnRapYTwNlULEqMOdxjFmW)
   VHoGBIrXPnRapYTwNlULEqMOdxjFme='plugin://plugin.video.watcham/?'
   VHoGBIrXPnRapYTwNlULEqMOdxjFme+=VHoGBIrXPnRapYTwNlULEqMOdxjFmQ
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFmu=='coupang':
   VHoGBIrXPnRapYTwNlULEqMOdxjFmW={'mode':'LOCAL_SEARCH','search_key':VHoGBIrXPnRapYTwNlULEqMOdxjFeA,'page':'1',}
   VHoGBIrXPnRapYTwNlULEqMOdxjFmQ=urllib.parse.urlencode(VHoGBIrXPnRapYTwNlULEqMOdxjFmW)
   VHoGBIrXPnRapYTwNlULEqMOdxjFme='plugin://plugin.video.coupangm/?'
   VHoGBIrXPnRapYTwNlULEqMOdxjFme+=VHoGBIrXPnRapYTwNlULEqMOdxjFmQ
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFmu=='netflix':
   VHoGBIrXPnRapYTwNlULEqMOdxjFmf=args.get('videoid')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmk=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.NF['SESSION']['nowGuid']
   if VHoGBIrXPnRapYTwNlULEqMOdxjFmh=='TVSHOW':
    VHoGBIrXPnRapYTwNlULEqMOdxjFme='plugin://plugin.video.netflix/directory/show/%s/'%(VHoGBIrXPnRapYTwNlULEqMOdxjFmf)
   else:
    VHoGBIrXPnRapYTwNlULEqMOdxjFme='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(VHoGBIrXPnRapYTwNlULEqMOdxjFmf,VHoGBIrXPnRapYTwNlULEqMOdxjFmk)
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFmu=='amazon':
   VHoGBIrXPnRapYTwNlULEqMOdxjFmW={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':VHoGBIrXPnRapYTwNlULEqMOdxjFeA,}}
   VHoGBIrXPnRapYTwNlULEqMOdxjFmQ=json.dumps(VHoGBIrXPnRapYTwNlULEqMOdxjFmW,separators=(',',':'))
   VHoGBIrXPnRapYTwNlULEqMOdxjFmQ=base64.standard_b64encode(VHoGBIrXPnRapYTwNlULEqMOdxjFmQ.encode()).decode('utf-8')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmQ=VHoGBIrXPnRapYTwNlULEqMOdxjFmQ.replace('+','%2B')
   VHoGBIrXPnRapYTwNlULEqMOdxjFme='plugin://plugin.video.primevm/?params='
   VHoGBIrXPnRapYTwNlULEqMOdxjFme+=VHoGBIrXPnRapYTwNlULEqMOdxjFmQ
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFmu=='disney':
   VHoGBIrXPnRapYTwNlULEqMOdxjFmW={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':VHoGBIrXPnRapYTwNlULEqMOdxjFeA,}}
   VHoGBIrXPnRapYTwNlULEqMOdxjFmQ=json.dumps(VHoGBIrXPnRapYTwNlULEqMOdxjFmW,separators=(',',':'))
   VHoGBIrXPnRapYTwNlULEqMOdxjFmQ=base64.standard_b64encode(VHoGBIrXPnRapYTwNlULEqMOdxjFmQ.encode()).decode('utf-8')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmQ=VHoGBIrXPnRapYTwNlULEqMOdxjFmQ.replace('+','%2B')
   VHoGBIrXPnRapYTwNlULEqMOdxjFme='plugin://plugin.video.disneym/?params='
   VHoGBIrXPnRapYTwNlULEqMOdxjFme+=VHoGBIrXPnRapYTwNlULEqMOdxjFmQ
  return VHoGBIrXPnRapYTwNlULEqMOdxjFme
 def dp_Nf_Search(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,args):
  VHoGBIrXPnRapYTwNlULEqMOdxjFmi =VHoGBIrXPnRapYTwNlULEqMOdxjFhS(args.get('page'))
  VHoGBIrXPnRapYTwNlULEqMOdxjFeA =args.get('search_key')
  VHoGBIrXPnRapYTwNlULEqMOdxjFeJ=args.get('byReference')
  (VHoGBIrXPnRapYTwNlULEqMOdxjFec,VHoGBIrXPnRapYTwNlULEqMOdxjFeg,VHoGBIrXPnRapYTwNlULEqMOdxjFeJ)=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.SearchObj.Get_Search_Netflix(VHoGBIrXPnRapYTwNlULEqMOdxjFeA,VHoGBIrXPnRapYTwNlULEqMOdxjFmi,byReference=VHoGBIrXPnRapYTwNlULEqMOdxjFeJ)
  for VHoGBIrXPnRapYTwNlULEqMOdxjFmK in VHoGBIrXPnRapYTwNlULEqMOdxjFec:
   VHoGBIrXPnRapYTwNlULEqMOdxjFmf =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('videoid')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmh =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('vidtype')
   VHoGBIrXPnRapYTwNlULEqMOdxjFSv =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('title')
   VHoGBIrXPnRapYTwNlULEqMOdxjFms =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('mpaa')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmC =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('regularSynopsis')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmz =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('dpSupplemental')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmt=VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('sequiturEvidence')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmD =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('thumbnail')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmA =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('year')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmc =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('duration')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmg =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('info_genre')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmv =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('director')
   VHoGBIrXPnRapYTwNlULEqMOdxjFmJ =VHoGBIrXPnRapYTwNlULEqMOdxjFmK.get('cast')
   if VHoGBIrXPnRapYTwNlULEqMOdxjFmh=='movie':
    VHoGBIrXPnRapYTwNlULEqMOdxjFbA=' (%s)'%(VHoGBIrXPnRapYTwNlULEqMOdxjFhe(VHoGBIrXPnRapYTwNlULEqMOdxjFmA))
   else:
    VHoGBIrXPnRapYTwNlULEqMOdxjFbA=''
   VHoGBIrXPnRapYTwNlULEqMOdxjFmy=''
   if VHoGBIrXPnRapYTwNlULEqMOdxjFmC:VHoGBIrXPnRapYTwNlULEqMOdxjFmy=VHoGBIrXPnRapYTwNlULEqMOdxjFmy+'\n\n'+VHoGBIrXPnRapYTwNlULEqMOdxjFmC
   if VHoGBIrXPnRapYTwNlULEqMOdxjFmz :VHoGBIrXPnRapYTwNlULEqMOdxjFmy=VHoGBIrXPnRapYTwNlULEqMOdxjFmy+'\n\n'+VHoGBIrXPnRapYTwNlULEqMOdxjFmz
   if VHoGBIrXPnRapYTwNlULEqMOdxjFmt:VHoGBIrXPnRapYTwNlULEqMOdxjFmy=VHoGBIrXPnRapYTwNlULEqMOdxjFmy+'\n\n'+VHoGBIrXPnRapYTwNlULEqMOdxjFmt
   VHoGBIrXPnRapYTwNlULEqMOdxjFmy=VHoGBIrXPnRapYTwNlULEqMOdxjFmy.strip()
   VHoGBIrXPnRapYTwNlULEqMOdxjFbc={'mediatype':'tvshow' if VHoGBIrXPnRapYTwNlULEqMOdxjFmh=='show' else 'movie','title':VHoGBIrXPnRapYTwNlULEqMOdxjFSv,'mpaa':VHoGBIrXPnRapYTwNlULEqMOdxjFms,'plot':VHoGBIrXPnRapYTwNlULEqMOdxjFmy,'duration':VHoGBIrXPnRapYTwNlULEqMOdxjFmc,'genre':VHoGBIrXPnRapYTwNlULEqMOdxjFmg,'director':VHoGBIrXPnRapYTwNlULEqMOdxjFmv,'cast':VHoGBIrXPnRapYTwNlULEqMOdxjFmJ,'year':VHoGBIrXPnRapYTwNlULEqMOdxjFmA,}
   VHoGBIrXPnRapYTwNlULEqMOdxjFSc={'ott':'netflix','vidtype':'TVSHOW' if VHoGBIrXPnRapYTwNlULEqMOdxjFmh=='show' else 'MOVIE','videoid':VHoGBIrXPnRapYTwNlULEqMOdxjFmf,}
   VHoGBIrXPnRapYTwNlULEqMOdxjFme=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.make_Hyper_Link(VHoGBIrXPnRapYTwNlULEqMOdxjFSc)
   VHoGBIrXPnRapYTwNlULEqMOdxjFem=VHoGBIrXPnRapYTwNlULEqMOdxjFuD if VHoGBIrXPnRapYTwNlULEqMOdxjFmh=='show' else VHoGBIrXPnRapYTwNlULEqMOdxjFuA
   if VHoGBIrXPnRapYTwNlULEqMOdxjFSW.get_settings_makebookmark():
    VHoGBIrXPnRapYTwNlULEqMOdxjFuS={'mode':'SET_BOOKMARK','values':{'videoid':VHoGBIrXPnRapYTwNlULEqMOdxjFmf,'vidtype':'tvshow' if VHoGBIrXPnRapYTwNlULEqMOdxjFmh=='show' else 'movie','vtitle':VHoGBIrXPnRapYTwNlULEqMOdxjFSv+VHoGBIrXPnRapYTwNlULEqMOdxjFbA,'vsubtitle':'','vinfo':VHoGBIrXPnRapYTwNlULEqMOdxjFbc,'thumbnail':VHoGBIrXPnRapYTwNlULEqMOdxjFmD,}}
    VHoGBIrXPnRapYTwNlULEqMOdxjFub=json.dumps(VHoGBIrXPnRapYTwNlULEqMOdxjFuS,separators=(',',':'))
    VHoGBIrXPnRapYTwNlULEqMOdxjFub=base64.standard_b64encode(VHoGBIrXPnRapYTwNlULEqMOdxjFub.encode()).decode('utf-8')
    VHoGBIrXPnRapYTwNlULEqMOdxjFub=VHoGBIrXPnRapYTwNlULEqMOdxjFub.replace('+','%2B')
    VHoGBIrXPnRapYTwNlULEqMOdxjFue='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(VHoGBIrXPnRapYTwNlULEqMOdxjFub)
    VHoGBIrXPnRapYTwNlULEqMOdxjFbD=[('(통합) 찜 영상에 추가',VHoGBIrXPnRapYTwNlULEqMOdxjFue)]
   else:
    VHoGBIrXPnRapYTwNlULEqMOdxjFbD=VHoGBIrXPnRapYTwNlULEqMOdxjFut
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.add_dir(VHoGBIrXPnRapYTwNlULEqMOdxjFSv+VHoGBIrXPnRapYTwNlULEqMOdxjFbA,sublabel=VHoGBIrXPnRapYTwNlULEqMOdxjFut,img=VHoGBIrXPnRapYTwNlULEqMOdxjFmD,infoLabels=VHoGBIrXPnRapYTwNlULEqMOdxjFbc,isFolder=VHoGBIrXPnRapYTwNlULEqMOdxjFem,params=VHoGBIrXPnRapYTwNlULEqMOdxjFSc,isLink=VHoGBIrXPnRapYTwNlULEqMOdxjFuA,ContextMenu=VHoGBIrXPnRapYTwNlULEqMOdxjFbD,direct_url=VHoGBIrXPnRapYTwNlULEqMOdxjFme)
  if VHoGBIrXPnRapYTwNlULEqMOdxjFeg:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSc={}
   VHoGBIrXPnRapYTwNlULEqMOdxjFSc['mode'] ='NF_SEARCH' 
   VHoGBIrXPnRapYTwNlULEqMOdxjFSc['page'] =VHoGBIrXPnRapYTwNlULEqMOdxjFhe(VHoGBIrXPnRapYTwNlULEqMOdxjFmi+1)
   VHoGBIrXPnRapYTwNlULEqMOdxjFSc['search_key']=VHoGBIrXPnRapYTwNlULEqMOdxjFeA
   VHoGBIrXPnRapYTwNlULEqMOdxjFSc['byReference']=VHoGBIrXPnRapYTwNlULEqMOdxjFeJ
   VHoGBIrXPnRapYTwNlULEqMOdxjFSv='[B]%s >>[/B]'%'다음 페이지'
   VHoGBIrXPnRapYTwNlULEqMOdxjFum=VHoGBIrXPnRapYTwNlULEqMOdxjFhe(VHoGBIrXPnRapYTwNlULEqMOdxjFmi+1)
   VHoGBIrXPnRapYTwNlULEqMOdxjFbg=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.add_dir(VHoGBIrXPnRapYTwNlULEqMOdxjFSv,sublabel=VHoGBIrXPnRapYTwNlULEqMOdxjFum,img=VHoGBIrXPnRapYTwNlULEqMOdxjFbg,infoLabels=VHoGBIrXPnRapYTwNlULEqMOdxjFut,isFolder=VHoGBIrXPnRapYTwNlULEqMOdxjFuD,params=VHoGBIrXPnRapYTwNlULEqMOdxjFSc)
  xbmcplugin.setContent(VHoGBIrXPnRapYTwNlULEqMOdxjFSW._addon_handle,'movies')
  xbmcplugin.endOfDirectory(VHoGBIrXPnRapYTwNlULEqMOdxjFSW._addon_handle)
 def dp_Bookmark_Menu(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,args):
  VHoGBIrXPnRapYTwNlULEqMOdxjFuh='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(VHoGBIrXPnRapYTwNlULEqMOdxjFuh)
 def dp_Set_Bookmark(VHoGBIrXPnRapYTwNlULEqMOdxjFSW,args):
  VHoGBIrXPnRapYTwNlULEqMOdxjFmf =args.get('videoid')
  VHoGBIrXPnRapYTwNlULEqMOdxjFmh =args.get('vidtype')
  VHoGBIrXPnRapYTwNlULEqMOdxjFuW =args.get('vtitle')
  VHoGBIrXPnRapYTwNlULEqMOdxjFuQ =args.get('vsubtitle')
  VHoGBIrXPnRapYTwNlULEqMOdxjFuf =args.get('vinfo')
  VHoGBIrXPnRapYTwNlULEqMOdxjFmD =args.get('thumbnail')
  VHoGBIrXPnRapYTwNlULEqMOdxjFSK=xbmcgui.Dialog()
  VHoGBIrXPnRapYTwNlULEqMOdxjFeS=VHoGBIrXPnRapYTwNlULEqMOdxjFSK.yesno(__language__(30917).encode('utf8'),VHoGBIrXPnRapYTwNlULEqMOdxjFuW+' \n\n'+__language__(30918))
  if VHoGBIrXPnRapYTwNlULEqMOdxjFeS==VHoGBIrXPnRapYTwNlULEqMOdxjFuA:return
  VHoGBIrXPnRapYTwNlULEqMOdxjFuk={'indexinfo':{'ott':'netflix','videoid':VHoGBIrXPnRapYTwNlULEqMOdxjFmf,'vidtype':VHoGBIrXPnRapYTwNlULEqMOdxjFmh,},'saveinfo':{'title':VHoGBIrXPnRapYTwNlULEqMOdxjFuW,'subtitle':VHoGBIrXPnRapYTwNlULEqMOdxjFuQ,'thumbnail':VHoGBIrXPnRapYTwNlULEqMOdxjFmD,'infoLabels':VHoGBIrXPnRapYTwNlULEqMOdxjFuf,},}
  VHoGBIrXPnRapYTwNlULEqMOdxjFSc={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':VHoGBIrXPnRapYTwNlULEqMOdxjFuk,}}
  VHoGBIrXPnRapYTwNlULEqMOdxjFSg=json.dumps(VHoGBIrXPnRapYTwNlULEqMOdxjFSc,separators=(',',':'))
  VHoGBIrXPnRapYTwNlULEqMOdxjFSg=base64.standard_b64encode(VHoGBIrXPnRapYTwNlULEqMOdxjFSg.encode()).decode('utf-8')
  VHoGBIrXPnRapYTwNlULEqMOdxjFSg=VHoGBIrXPnRapYTwNlULEqMOdxjFSg.replace('+','%2B')
  VHoGBIrXPnRapYTwNlULEqMOdxjFue='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(VHoGBIrXPnRapYTwNlULEqMOdxjFSg)
  xbmc.executebuiltin(VHoGBIrXPnRapYTwNlULEqMOdxjFue)
 def search_main(VHoGBIrXPnRapYTwNlULEqMOdxjFSW):
  VHoGBIrXPnRapYTwNlULEqMOdxjFui=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.main_params.get('params')
  if VHoGBIrXPnRapYTwNlULEqMOdxjFui:
   VHoGBIrXPnRapYTwNlULEqMOdxjFuK =base64.standard_b64decode(VHoGBIrXPnRapYTwNlULEqMOdxjFui).decode('utf-8')
   VHoGBIrXPnRapYTwNlULEqMOdxjFuK =json.loads(VHoGBIrXPnRapYTwNlULEqMOdxjFuK)
   VHoGBIrXPnRapYTwNlULEqMOdxjFus =VHoGBIrXPnRapYTwNlULEqMOdxjFuK.get('mode')
   VHoGBIrXPnRapYTwNlULEqMOdxjFuC =VHoGBIrXPnRapYTwNlULEqMOdxjFuK.get('values')
  else:
   VHoGBIrXPnRapYTwNlULEqMOdxjFus=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.main_params.get('mode',VHoGBIrXPnRapYTwNlULEqMOdxjFut)
   VHoGBIrXPnRapYTwNlULEqMOdxjFuC=VHoGBIrXPnRapYTwNlULEqMOdxjFSW.main_params
  if VHoGBIrXPnRapYTwNlULEqMOdxjFus=='NFLOGOUT':
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.NF_logout()
   return
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFus=='NFLOGIN':
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.NF_login(showMessage=VHoGBIrXPnRapYTwNlULEqMOdxjFuD)
   return
  VHoGBIrXPnRapYTwNlULEqMOdxjFSW.option_check()
  if VHoGBIrXPnRapYTwNlULEqMOdxjFus is VHoGBIrXPnRapYTwNlULEqMOdxjFut:
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.dp_Main_List()
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFus=='TOTAL_SEARCH':
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.dp_Search_Group(VHoGBIrXPnRapYTwNlULEqMOdxjFuC)
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFus=='NF_SEARCH':
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.dp_Nf_Search(VHoGBIrXPnRapYTwNlULEqMOdxjFuC)
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFus=='TOTAL_HISTORY':
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.dp_Search_History(VHoGBIrXPnRapYTwNlULEqMOdxjFuC)
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFus=='HISTORY_REMOVE':
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.dp_History_Delete(VHoGBIrXPnRapYTwNlULEqMOdxjFuC)
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFus=='MENU_BOOKMARK':
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.dp_Bookmark_Menu(VHoGBIrXPnRapYTwNlULEqMOdxjFuC)
  elif VHoGBIrXPnRapYTwNlULEqMOdxjFus=='SET_BOOKMARK':
   VHoGBIrXPnRapYTwNlULEqMOdxjFSW.dp_Set_Bookmark(VHoGBIrXPnRapYTwNlULEqMOdxjFuC)
  else:
   VHoGBIrXPnRapYTwNlULEqMOdxjFut
# Created by pyminifier (https://github.com/liftoff/pyminifier)
