__author__="NightRain"
ygKupNaqjdrXETOYHDInbehwPWksFL=object
ygKupNaqjdrXETOYHDInbehwPWksFM=None
ygKupNaqjdrXETOYHDInbehwPWksFf=True
ygKupNaqjdrXETOYHDInbehwPWksFA=print
ygKupNaqjdrXETOYHDInbehwPWksFx=str
ygKupNaqjdrXETOYHDInbehwPWksFB=int
ygKupNaqjdrXETOYHDInbehwPWksFJ=False
ygKupNaqjdrXETOYHDInbehwPWksVt=Exception
ygKupNaqjdrXETOYHDInbehwPWksVQ=len
ygKupNaqjdrXETOYHDInbehwPWksVU=open
ygKupNaqjdrXETOYHDInbehwPWksVo=type
ygKupNaqjdrXETOYHDInbehwPWksVF=list
ygKupNaqjdrXETOYHDInbehwPWksVi=isinstance
ygKupNaqjdrXETOYHDInbehwPWksVc=dict
ygKupNaqjdrXETOYHDInbehwPWksVm=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
import http.cookiejar
class ygKupNaqjdrXETOYHDInbehwPWkstQ(ygKupNaqjdrXETOYHDInbehwPWksFL):
 def __init__(ygKupNaqjdrXETOYHDInbehwPWkstU):
  ygKupNaqjdrXETOYHDInbehwPWkstU.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36'
  ygKupNaqjdrXETOYHDInbehwPWkstU.API_WAVVE ='https://apis.wavve.com'
  ygKupNaqjdrXETOYHDInbehwPWkstU.API_TVING_SEARCH='https://search.tving.com'
  ygKupNaqjdrXETOYHDInbehwPWkstU.API_TVING_IMG ='https://image.tving.com'
  ygKupNaqjdrXETOYHDInbehwPWkstU.API_WATCHA ='https://api-mars.watcha.com'
  ygKupNaqjdrXETOYHDInbehwPWkstU.API_NETFLIX ='https://www.netflix.com'
  ygKupNaqjdrXETOYHDInbehwPWkstU.API_COUPANG ='https://discover.coupangstreaming.com'
  ygKupNaqjdrXETOYHDInbehwPWkstU.API_PRIMEV ='https://www.primevideo.com'
  ygKupNaqjdrXETOYHDInbehwPWkstU.WAVVE_LIMIT =20 
  ygKupNaqjdrXETOYHDInbehwPWkstU.TVING_LIMIT =30
  ygKupNaqjdrXETOYHDInbehwPWkstU.WATCHA_LIMIT =30
  ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_LIMIT =20 
  ygKupNaqjdrXETOYHDInbehwPWkstU.COUPANG_LIMIT =10 
  ygKupNaqjdrXETOYHDInbehwPWkstU.DISNEY_LIMIT =10 
  ygKupNaqjdrXETOYHDInbehwPWkstU.DERECTOR_LIMIT =4
  ygKupNaqjdrXETOYHDInbehwPWkstU.CAST_LIMIT =10
  ygKupNaqjdrXETOYHDInbehwPWkstU.GENRE_LIMIT =4
  ygKupNaqjdrXETOYHDInbehwPWkstU.TVING_MOVIE_LITE=['2610061','2610161','261062']
  ygKupNaqjdrXETOYHDInbehwPWkstU.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  ygKupNaqjdrXETOYHDInbehwPWkstU.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  ygKupNaqjdrXETOYHDInbehwPWkstU.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_HEADER={'user-agent':ygKupNaqjdrXETOYHDInbehwPWkstU.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND1 ='_342x192'
  ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND2 ='_665x375'
  ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_PORT ='_342x684'
  ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LOGO ='_550x124'
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF={}
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']={}
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']={}
  ygKupNaqjdrXETOYHDInbehwPWkstU.DZ={}
  ygKupNaqjdrXETOYHDInbehwPWkstU.HTTP_CLIENT=requests.Session()
  ygKupNaqjdrXETOYHDInbehwPWkstU.CP_ORIGINAL_COOKIE =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.PV_ORIGINAL_COOKIE =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.DZ_ORIGINAL_COOKIE =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_ORIGINAL_COOKIE =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_SESSION_COOKIES1 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_SESSION_COOKIES2 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_SESSION_COOKIES3 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_SESSION_COOKIES4 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_SESSION_FULLTEXT1 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_SESSION_FULLTEXT2 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_SESSION_FULLTEXT3 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_SESSION_FULLTEXT4 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_CONTEXTJSON_FILE1 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_CONTEXTJSON_FILE2 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_CONTEXTJSON_FILE3 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_CONTEXTJSON_FILE4 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_FALCORJSON_FILE1 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_FALCORJSON_FILE2 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_FALCORJSON_FILE3 =''
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF_FALCORJSON_FILE4 =''
 '''
 def callRequestCookies(self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):
  #setHeader = {'user-agent' : self.USER_AGENT }
  setHeader = self.DEFAULT_HEADER
  if headers: setHeader.update(headers )
  if jobtype == 'Get': # Get/Post
   res = requests.get(url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  else:
   res = requests.post(url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  return res
 ''' 
 def Call_Request(ygKupNaqjdrXETOYHDInbehwPWkstU,ygKupNaqjdrXETOYHDInbehwPWkstz,payload=ygKupNaqjdrXETOYHDInbehwPWksFM,json=ygKupNaqjdrXETOYHDInbehwPWksFM,params=ygKupNaqjdrXETOYHDInbehwPWksFM,headers=ygKupNaqjdrXETOYHDInbehwPWksFM,cookies=ygKupNaqjdrXETOYHDInbehwPWksFM,redirects=ygKupNaqjdrXETOYHDInbehwPWksFf,method='-'):
  ygKupNaqjdrXETOYHDInbehwPWksto={'user-agent':ygKupNaqjdrXETOYHDInbehwPWkstU.USER_AGENT}
  if headers:ygKupNaqjdrXETOYHDInbehwPWksto.update(headers)
  if payload!=ygKupNaqjdrXETOYHDInbehwPWksFM or method=='POST':
   ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.HTTP_CLIENT.post(url=ygKupNaqjdrXETOYHDInbehwPWkstz,data=payload,json=json,params=params,headers=ygKupNaqjdrXETOYHDInbehwPWksto,cookies=cookies,allow_redirects=redirects)
  else:
   ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.HTTP_CLIENT.get(url=ygKupNaqjdrXETOYHDInbehwPWkstz,params=params,headers=ygKupNaqjdrXETOYHDInbehwPWksto,cookies=cookies,allow_redirects=redirects)
  ygKupNaqjdrXETOYHDInbehwPWksFA(ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWkstF.status_code)+' - '+ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWkstF.url))
  return ygKupNaqjdrXETOYHDInbehwPWkstF
 def GetNoCache(ygKupNaqjdrXETOYHDInbehwPWkstU,timetype=1,minutes=0):
  if timetype==1:
   ts=ygKupNaqjdrXETOYHDInbehwPWksFB(time.time())
   mi=ygKupNaqjdrXETOYHDInbehwPWksFB(minutes*60)
  else:
   ts=ygKupNaqjdrXETOYHDInbehwPWksFB(time.time()*1000)
   mi=ygKupNaqjdrXETOYHDInbehwPWksFB(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(ygKupNaqjdrXETOYHDInbehwPWkstU):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(ygKupNaqjdrXETOYHDInbehwPWkstU,search_key,sType,page_int):
  ygKupNaqjdrXETOYHDInbehwPWksti=[]
  ygKupNaqjdrXETOYHDInbehwPWkstc=ygKupNaqjdrXETOYHDInbehwPWksQt=1
  ygKupNaqjdrXETOYHDInbehwPWkstm=ygKupNaqjdrXETOYHDInbehwPWksFJ
  try:
   ygKupNaqjdrXETOYHDInbehwPWkstz=ygKupNaqjdrXETOYHDInbehwPWkstU.API_WAVVE+'/fz/search/band.js'
   ygKupNaqjdrXETOYHDInbehwPWkstl={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':ygKupNaqjdrXETOYHDInbehwPWksFx((page_int-1)*ygKupNaqjdrXETOYHDInbehwPWkstU.WAVVE_LIMIT),'limit':ygKupNaqjdrXETOYHDInbehwPWkstU.WAVVE_LIMIT,'orderby':'score','mtype':'svod',}
   ygKupNaqjdrXETOYHDInbehwPWkstl.update(ygKupNaqjdrXETOYHDInbehwPWkstU.WAVVE_PARAMS)
   ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.Call_Request(ygKupNaqjdrXETOYHDInbehwPWkstz,payload=ygKupNaqjdrXETOYHDInbehwPWksFM,params=ygKupNaqjdrXETOYHDInbehwPWkstl,headers=ygKupNaqjdrXETOYHDInbehwPWksFM,cookies=ygKupNaqjdrXETOYHDInbehwPWksFM,method='GET')
   ygKupNaqjdrXETOYHDInbehwPWkstv=json.loads(ygKupNaqjdrXETOYHDInbehwPWkstF.text)
   if not('celllist' in ygKupNaqjdrXETOYHDInbehwPWkstv['band']):return ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm
   ygKupNaqjdrXETOYHDInbehwPWkstS=ygKupNaqjdrXETOYHDInbehwPWkstv['band']['celllist']
   for ygKupNaqjdrXETOYHDInbehwPWkstC in ygKupNaqjdrXETOYHDInbehwPWkstS:
    ygKupNaqjdrXETOYHDInbehwPWkstR =ygKupNaqjdrXETOYHDInbehwPWkstC['event_list'][1]['url']
    ygKupNaqjdrXETOYHDInbehwPWkstG=urllib.parse.urlsplit(ygKupNaqjdrXETOYHDInbehwPWkstR).query
    ygKupNaqjdrXETOYHDInbehwPWkstL=ygKupNaqjdrXETOYHDInbehwPWkstG[0:ygKupNaqjdrXETOYHDInbehwPWkstG.find('=')]
    ygKupNaqjdrXETOYHDInbehwPWkstM=ygKupNaqjdrXETOYHDInbehwPWkstG[ygKupNaqjdrXETOYHDInbehwPWkstG.find('=')+1:]
    ygKupNaqjdrXETOYHDInbehwPWkstL='TVSHOW' if ygKupNaqjdrXETOYHDInbehwPWkstL=='programid' else 'MOVIE' 
    ygKupNaqjdrXETOYHDInbehwPWkstf=ygKupNaqjdrXETOYHDInbehwPWkstC['title_list'][0]['text']
    ygKupNaqjdrXETOYHDInbehwPWkstA =ygKupNaqjdrXETOYHDInbehwPWkstC['age']
    ygKupNaqjdrXETOYHDInbehwPWkstx={'title':ygKupNaqjdrXETOYHDInbehwPWkstf}
    ygKupNaqjdrXETOYHDInbehwPWkstB=ygKupNaqjdrXETOYHDInbehwPWksFJ
    for ygKupNaqjdrXETOYHDInbehwPWkstJ in ygKupNaqjdrXETOYHDInbehwPWkstC['bottom_taglist']:
     if ygKupNaqjdrXETOYHDInbehwPWkstJ=='won':
      ygKupNaqjdrXETOYHDInbehwPWkstB=ygKupNaqjdrXETOYHDInbehwPWksFf
      break
    if ygKupNaqjdrXETOYHDInbehwPWkstB==ygKupNaqjdrXETOYHDInbehwPWksFf: 
     ygKupNaqjdrXETOYHDInbehwPWkstx['title']=ygKupNaqjdrXETOYHDInbehwPWkstx['title']+' [개별구매]'
    if ygKupNaqjdrXETOYHDInbehwPWkstC.get('age')!='21':
     ygKupNaqjdrXETOYHDInbehwPWksti.append(ygKupNaqjdrXETOYHDInbehwPWkstx)
   ygKupNaqjdrXETOYHDInbehwPWkstc=ygKupNaqjdrXETOYHDInbehwPWksFB(ygKupNaqjdrXETOYHDInbehwPWkstv['band']['pagecount'])
   if ygKupNaqjdrXETOYHDInbehwPWkstv['band']['count']:ygKupNaqjdrXETOYHDInbehwPWksQt =ygKupNaqjdrXETOYHDInbehwPWksFB(ygKupNaqjdrXETOYHDInbehwPWkstv['band']['count'])
   else:ygKupNaqjdrXETOYHDInbehwPWksQt=ygKupNaqjdrXETOYHDInbehwPWkstU.LIST_LIMIT
   ygKupNaqjdrXETOYHDInbehwPWkstm=ygKupNaqjdrXETOYHDInbehwPWkstc>ygKupNaqjdrXETOYHDInbehwPWksQt
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception)
  return ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm 
 def Get_Search_Tving(ygKupNaqjdrXETOYHDInbehwPWkstU,search_key,sType,page_int):
  ygKupNaqjdrXETOYHDInbehwPWksti=[]
  ygKupNaqjdrXETOYHDInbehwPWkstm=ygKupNaqjdrXETOYHDInbehwPWksFJ
  try:
   ygKupNaqjdrXETOYHDInbehwPWksQU ='/search/getSearch.jsp'
   ygKupNaqjdrXETOYHDInbehwPWksQo={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':ygKupNaqjdrXETOYHDInbehwPWksFx(page_int),'pageSize':ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWkstU.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':ygKupNaqjdrXETOYHDInbehwPWkstU.TVING_PARMAS.get('SCREENCODE'),'os':ygKupNaqjdrXETOYHDInbehwPWkstU.TVING_PARMAS.get('OSCODE'),'network':ygKupNaqjdrXETOYHDInbehwPWkstU.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWkstU.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWkstU.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWkstU.GetNoCache(2))}
   ygKupNaqjdrXETOYHDInbehwPWkstz=ygKupNaqjdrXETOYHDInbehwPWkstU.API_TVING_SEARCH+ygKupNaqjdrXETOYHDInbehwPWksQU
   ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.Call_Request(ygKupNaqjdrXETOYHDInbehwPWkstz,payload=ygKupNaqjdrXETOYHDInbehwPWksFM,params=ygKupNaqjdrXETOYHDInbehwPWksQo,headers=ygKupNaqjdrXETOYHDInbehwPWksFM,cookies=ygKupNaqjdrXETOYHDInbehwPWksFM,method='GET')
   ygKupNaqjdrXETOYHDInbehwPWksQF=json.loads(ygKupNaqjdrXETOYHDInbehwPWkstF.text)
   if sType=='TVSHOW':
    if not('programRsb' in ygKupNaqjdrXETOYHDInbehwPWksQF):return ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm
    ygKupNaqjdrXETOYHDInbehwPWksQV=ygKupNaqjdrXETOYHDInbehwPWksQF['programRsb']['dataList']
    ygKupNaqjdrXETOYHDInbehwPWksQi =ygKupNaqjdrXETOYHDInbehwPWksFB(ygKupNaqjdrXETOYHDInbehwPWksQF['programRsb']['count'])
    for ygKupNaqjdrXETOYHDInbehwPWkstC in ygKupNaqjdrXETOYHDInbehwPWksQV:
     ygKupNaqjdrXETOYHDInbehwPWksQc=ygKupNaqjdrXETOYHDInbehwPWkstC['mast_cd']
     ygKupNaqjdrXETOYHDInbehwPWkstf =ygKupNaqjdrXETOYHDInbehwPWkstC['mast_nm']
     ygKupNaqjdrXETOYHDInbehwPWksQm=ygKupNaqjdrXETOYHDInbehwPWkstU.API_TVING_IMG+ygKupNaqjdrXETOYHDInbehwPWkstC['web_url4']
     ygKupNaqjdrXETOYHDInbehwPWksQz =ygKupNaqjdrXETOYHDInbehwPWkstU.API_TVING_IMG+ygKupNaqjdrXETOYHDInbehwPWkstC['web_url']
     try:
      ygKupNaqjdrXETOYHDInbehwPWksQl =[]
      ygKupNaqjdrXETOYHDInbehwPWksQv=[]
      ygKupNaqjdrXETOYHDInbehwPWksQS =[]
      ygKupNaqjdrXETOYHDInbehwPWksQC =0
      ygKupNaqjdrXETOYHDInbehwPWksQR =''
      ygKupNaqjdrXETOYHDInbehwPWksQG =''
      ygKupNaqjdrXETOYHDInbehwPWksQL =''
      if ygKupNaqjdrXETOYHDInbehwPWkstC.get('actor') !='' and ygKupNaqjdrXETOYHDInbehwPWkstC.get('actor') !='-':ygKupNaqjdrXETOYHDInbehwPWksQl =ygKupNaqjdrXETOYHDInbehwPWkstC.get('actor').split(',')
      if ygKupNaqjdrXETOYHDInbehwPWkstC.get('director')!='' and ygKupNaqjdrXETOYHDInbehwPWkstC.get('director')!='-':ygKupNaqjdrXETOYHDInbehwPWksQv=ygKupNaqjdrXETOYHDInbehwPWkstC.get('director').split(',')
      if ygKupNaqjdrXETOYHDInbehwPWkstC.get('cate_nm')!='' and ygKupNaqjdrXETOYHDInbehwPWkstC.get('cate_nm')!='-':ygKupNaqjdrXETOYHDInbehwPWksQS =ygKupNaqjdrXETOYHDInbehwPWkstC.get('cate_nm').split('/')
      if 'targetage' in ygKupNaqjdrXETOYHDInbehwPWkstC:ygKupNaqjdrXETOYHDInbehwPWksQR=ygKupNaqjdrXETOYHDInbehwPWkstC.get('targetage')
      if 'broad_dt' in ygKupNaqjdrXETOYHDInbehwPWkstC:
       ygKupNaqjdrXETOYHDInbehwPWksQM=ygKupNaqjdrXETOYHDInbehwPWkstC.get('broad_dt')
       ygKupNaqjdrXETOYHDInbehwPWksQL='%s-%s-%s'%(ygKupNaqjdrXETOYHDInbehwPWksQM[:4],ygKupNaqjdrXETOYHDInbehwPWksQM[4:6],ygKupNaqjdrXETOYHDInbehwPWksQM[6:])
       ygKupNaqjdrXETOYHDInbehwPWksQG =ygKupNaqjdrXETOYHDInbehwPWksQM[:4]
     except:
      ygKupNaqjdrXETOYHDInbehwPWksFM
     ygKupNaqjdrXETOYHDInbehwPWkstx={'title':ygKupNaqjdrXETOYHDInbehwPWkstf,}
     ygKupNaqjdrXETOYHDInbehwPWksti.append(ygKupNaqjdrXETOYHDInbehwPWkstx)
   else:
    if not('vodMVRsb' in ygKupNaqjdrXETOYHDInbehwPWksQF):return ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm
    ygKupNaqjdrXETOYHDInbehwPWksQf=ygKupNaqjdrXETOYHDInbehwPWksQF['vodMVRsb']['dataList']
    ygKupNaqjdrXETOYHDInbehwPWksQi =ygKupNaqjdrXETOYHDInbehwPWksFB(ygKupNaqjdrXETOYHDInbehwPWksQF['vodMVRsb']['count'])
    ygKupNaqjdrXETOYHDInbehwPWksFA(ygKupNaqjdrXETOYHDInbehwPWksQi)
    for ygKupNaqjdrXETOYHDInbehwPWkstC in ygKupNaqjdrXETOYHDInbehwPWksQf:
     ygKupNaqjdrXETOYHDInbehwPWksQc=ygKupNaqjdrXETOYHDInbehwPWkstC['mast_cd']
     ygKupNaqjdrXETOYHDInbehwPWkstf =ygKupNaqjdrXETOYHDInbehwPWkstC['mast_nm'].strip()
     ygKupNaqjdrXETOYHDInbehwPWksQm =ygKupNaqjdrXETOYHDInbehwPWkstU.API_TVING_IMG+ygKupNaqjdrXETOYHDInbehwPWkstC['web_url']
     ygKupNaqjdrXETOYHDInbehwPWksQz =ygKupNaqjdrXETOYHDInbehwPWksQm
     ygKupNaqjdrXETOYHDInbehwPWksQA=''
     try:
      ygKupNaqjdrXETOYHDInbehwPWksQl =[]
      ygKupNaqjdrXETOYHDInbehwPWksQv=[]
      ygKupNaqjdrXETOYHDInbehwPWksQS =[]
      ygKupNaqjdrXETOYHDInbehwPWksQC =0
      ygKupNaqjdrXETOYHDInbehwPWksQR =''
      ygKupNaqjdrXETOYHDInbehwPWksQG =''
      ygKupNaqjdrXETOYHDInbehwPWksQL =''
      if ygKupNaqjdrXETOYHDInbehwPWkstC.get('actor') !='' and ygKupNaqjdrXETOYHDInbehwPWkstC.get('actor') !='-':ygKupNaqjdrXETOYHDInbehwPWksQl =ygKupNaqjdrXETOYHDInbehwPWkstC.get('actor').split(',')
      if ygKupNaqjdrXETOYHDInbehwPWkstC.get('director')!='' and ygKupNaqjdrXETOYHDInbehwPWkstC.get('director')!='-':ygKupNaqjdrXETOYHDInbehwPWksQv=ygKupNaqjdrXETOYHDInbehwPWkstC.get('director').split(',')
      if ygKupNaqjdrXETOYHDInbehwPWkstC.get('cate_nm')!='' and ygKupNaqjdrXETOYHDInbehwPWkstC.get('cate_nm')!='-':ygKupNaqjdrXETOYHDInbehwPWksQS =ygKupNaqjdrXETOYHDInbehwPWkstC.get('cate_nm').split('/')
      if ygKupNaqjdrXETOYHDInbehwPWkstC.get('runtime_sec')!='':ygKupNaqjdrXETOYHDInbehwPWksQC=ygKupNaqjdrXETOYHDInbehwPWkstC.get('runtime_sec')
      if 'grade_nm' in ygKupNaqjdrXETOYHDInbehwPWkstC:ygKupNaqjdrXETOYHDInbehwPWksQR=ygKupNaqjdrXETOYHDInbehwPWkstC.get('grade_nm')
      ygKupNaqjdrXETOYHDInbehwPWksQx=''
      ygKupNaqjdrXETOYHDInbehwPWksQM=ygKupNaqjdrXETOYHDInbehwPWkstC.get('broad_dt')
      if ygKupNaqjdrXETOYHDInbehwPWksQx!='':
       ygKupNaqjdrXETOYHDInbehwPWksQL='%s-%s-%s'%(ygKupNaqjdrXETOYHDInbehwPWksQM[:4],ygKupNaqjdrXETOYHDInbehwPWksQM[4:6],ygKupNaqjdrXETOYHDInbehwPWksQM[6:])
       ygKupNaqjdrXETOYHDInbehwPWksQG =ygKupNaqjdrXETOYHDInbehwPWksQM[:4]
     except:
      ygKupNaqjdrXETOYHDInbehwPWksFM
     ygKupNaqjdrXETOYHDInbehwPWkstx={'title':ygKupNaqjdrXETOYHDInbehwPWkstf,}
     ygKupNaqjdrXETOYHDInbehwPWksQB=ygKupNaqjdrXETOYHDInbehwPWksFJ
     for ygKupNaqjdrXETOYHDInbehwPWkstJ in ygKupNaqjdrXETOYHDInbehwPWkstC['bill']:
      if ygKupNaqjdrXETOYHDInbehwPWkstJ in ygKupNaqjdrXETOYHDInbehwPWkstU.TVING_MOVIE_LITE:
       ygKupNaqjdrXETOYHDInbehwPWksQB=ygKupNaqjdrXETOYHDInbehwPWksFf
       break
     if ygKupNaqjdrXETOYHDInbehwPWksQB==ygKupNaqjdrXETOYHDInbehwPWksFJ: 
      ygKupNaqjdrXETOYHDInbehwPWkstx['title']=ygKupNaqjdrXETOYHDInbehwPWkstx['title']+' [개별구매]'
     ygKupNaqjdrXETOYHDInbehwPWksti.append(ygKupNaqjdrXETOYHDInbehwPWkstx)
   if ygKupNaqjdrXETOYHDInbehwPWksQi>(page_int*ygKupNaqjdrXETOYHDInbehwPWkstU.TVING_LIMIT):ygKupNaqjdrXETOYHDInbehwPWkstm=ygKupNaqjdrXETOYHDInbehwPWksFf
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception)
  return ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm
 def Get_Search_Watcha(ygKupNaqjdrXETOYHDInbehwPWkstU,search_key,page_int):
  ygKupNaqjdrXETOYHDInbehwPWksti=[]
  ygKupNaqjdrXETOYHDInbehwPWkstm=ygKupNaqjdrXETOYHDInbehwPWksFJ
  try:
   ygKupNaqjdrXETOYHDInbehwPWkstz=ygKupNaqjdrXETOYHDInbehwPWkstU.API_WATCHA+'/api/search.json'
   ygKupNaqjdrXETOYHDInbehwPWksQo={'query':search_key,'page':ygKupNaqjdrXETOYHDInbehwPWksFx(page_int),'per':ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWkstU.WATCHA_LIMIT),'exclude':'limited',}
   ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.Call_Request(ygKupNaqjdrXETOYHDInbehwPWkstz,payload=ygKupNaqjdrXETOYHDInbehwPWksFM,params=ygKupNaqjdrXETOYHDInbehwPWksQo,headers=ygKupNaqjdrXETOYHDInbehwPWkstU.WATCHA_HEADER,cookies=ygKupNaqjdrXETOYHDInbehwPWksFM,method='GET')
   ygKupNaqjdrXETOYHDInbehwPWksQF=json.loads(ygKupNaqjdrXETOYHDInbehwPWkstF.text)
   if not('results' in ygKupNaqjdrXETOYHDInbehwPWksQF):return ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm
   ygKupNaqjdrXETOYHDInbehwPWksQJ=ygKupNaqjdrXETOYHDInbehwPWksQF['results']
   ygKupNaqjdrXETOYHDInbehwPWkstm=ygKupNaqjdrXETOYHDInbehwPWksQF['meta']['has_next']
   for ygKupNaqjdrXETOYHDInbehwPWkstC in ygKupNaqjdrXETOYHDInbehwPWksQJ:
    ygKupNaqjdrXETOYHDInbehwPWksUt =ygKupNaqjdrXETOYHDInbehwPWkstC['code']
    ygKupNaqjdrXETOYHDInbehwPWksUQ=ygKupNaqjdrXETOYHDInbehwPWkstC['content_type']
    ygKupNaqjdrXETOYHDInbehwPWksUo =ygKupNaqjdrXETOYHDInbehwPWkstC['title']
    ygKupNaqjdrXETOYHDInbehwPWksUF =ygKupNaqjdrXETOYHDInbehwPWkstC['story']
    ygKupNaqjdrXETOYHDInbehwPWksQm=ygKupNaqjdrXETOYHDInbehwPWksQz=ygKupNaqjdrXETOYHDInbehwPWksFz=''
    if ygKupNaqjdrXETOYHDInbehwPWkstC.get('poster') !=ygKupNaqjdrXETOYHDInbehwPWksFM:ygKupNaqjdrXETOYHDInbehwPWksQm=ygKupNaqjdrXETOYHDInbehwPWkstC.get('poster').get('original')
    if ygKupNaqjdrXETOYHDInbehwPWkstC.get('stillcut')!=ygKupNaqjdrXETOYHDInbehwPWksFM:ygKupNaqjdrXETOYHDInbehwPWksQz =ygKupNaqjdrXETOYHDInbehwPWkstC.get('stillcut').get('large')
    if ygKupNaqjdrXETOYHDInbehwPWkstC.get('thumbnail')!=ygKupNaqjdrXETOYHDInbehwPWksFM:ygKupNaqjdrXETOYHDInbehwPWksFz=ygKupNaqjdrXETOYHDInbehwPWkstC.get('thumbnail').get('large')
    if ygKupNaqjdrXETOYHDInbehwPWksFz=='' :ygKupNaqjdrXETOYHDInbehwPWksFz=ygKupNaqjdrXETOYHDInbehwPWksQz
    ygKupNaqjdrXETOYHDInbehwPWksUV={'thumb':ygKupNaqjdrXETOYHDInbehwPWksQz,'poster':ygKupNaqjdrXETOYHDInbehwPWksQm,'fanart':ygKupNaqjdrXETOYHDInbehwPWksFz}
    ygKupNaqjdrXETOYHDInbehwPWksQG =ygKupNaqjdrXETOYHDInbehwPWkstC['year']
    ygKupNaqjdrXETOYHDInbehwPWksUi =ygKupNaqjdrXETOYHDInbehwPWkstC['film_rating_code']
    ygKupNaqjdrXETOYHDInbehwPWksUc=ygKupNaqjdrXETOYHDInbehwPWkstC['film_rating_short']
    ygKupNaqjdrXETOYHDInbehwPWksUm =ygKupNaqjdrXETOYHDInbehwPWkstC['film_rating_long']
    if ygKupNaqjdrXETOYHDInbehwPWksUQ=='movies':
     ygKupNaqjdrXETOYHDInbehwPWksQC =ygKupNaqjdrXETOYHDInbehwPWkstC['duration']
    else:
     ygKupNaqjdrXETOYHDInbehwPWksQC ='0'
    ygKupNaqjdrXETOYHDInbehwPWkstx={'title':ygKupNaqjdrXETOYHDInbehwPWksUo,}
    ygKupNaqjdrXETOYHDInbehwPWksti.append(ygKupNaqjdrXETOYHDInbehwPWkstx)
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception)
  return ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm
 def Get_Search_Coupang(ygKupNaqjdrXETOYHDInbehwPWkstU,search_key,page_int):
  ygKupNaqjdrXETOYHDInbehwPWksti=[]
  ygKupNaqjdrXETOYHDInbehwPWkstm=ygKupNaqjdrXETOYHDInbehwPWksFJ
  try:
   CP=ygKupNaqjdrXETOYHDInbehwPWkstU.jsonfile_To_dic(ygKupNaqjdrXETOYHDInbehwPWkstU.CP_ORIGINAL_COOKIE)
   ygKupNaqjdrXETOYHDInbehwPWkstz=ygKupNaqjdrXETOYHDInbehwPWkstU.API_COUPANG+'/v2/search' 
   ygKupNaqjdrXETOYHDInbehwPWksQo={'query':search_key,'platform':'WEBCLIENT','page':ygKupNaqjdrXETOYHDInbehwPWksFx(page_int),'perPage':ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWkstU.COUPANG_LIMIT),}
   ygKupNaqjdrXETOYHDInbehwPWksUz={'x-membersrl':CP['SESSION']['member_srl'],'x-pcid':CP['SESSION']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.Call_Request(ygKupNaqjdrXETOYHDInbehwPWkstz,payload=ygKupNaqjdrXETOYHDInbehwPWksFM,params=ygKupNaqjdrXETOYHDInbehwPWksQo,headers=ygKupNaqjdrXETOYHDInbehwPWksUz,cookies=ygKupNaqjdrXETOYHDInbehwPWksFM,method='GET')
   ygKupNaqjdrXETOYHDInbehwPWkstv=json.loads(ygKupNaqjdrXETOYHDInbehwPWkstF.text)
   if ygKupNaqjdrXETOYHDInbehwPWksVQ(ygKupNaqjdrXETOYHDInbehwPWkstv.get('data').get('data'))==0:return ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm
   for ygKupNaqjdrXETOYHDInbehwPWkstC in ygKupNaqjdrXETOYHDInbehwPWkstv.get('data').get('data'):
    ygKupNaqjdrXETOYHDInbehwPWkstC=ygKupNaqjdrXETOYHDInbehwPWkstC.get('data')
    ygKupNaqjdrXETOYHDInbehwPWkstx={'title':ygKupNaqjdrXETOYHDInbehwPWkstC.get('title'),}
    ygKupNaqjdrXETOYHDInbehwPWksti.append(ygKupNaqjdrXETOYHDInbehwPWkstx)
   if ygKupNaqjdrXETOYHDInbehwPWkstv.get('pagination').get('totalPages')>page_int:
    ygKupNaqjdrXETOYHDInbehwPWkstm=ygKupNaqjdrXETOYHDInbehwPWksFf
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception)
  return ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm
 def Selenium_Cookies_Load(ygKupNaqjdrXETOYHDInbehwPWkstU,in_filename):
  fp=ygKupNaqjdrXETOYHDInbehwPWksVU(in_filename,'rb',-1)
  try:
   ygKupNaqjdrXETOYHDInbehwPWksUl=pickle.loads(fp.read())
   if ygKupNaqjdrXETOYHDInbehwPWksVo(ygKupNaqjdrXETOYHDInbehwPWksUl)==ygKupNaqjdrXETOYHDInbehwPWksVF:
    for ygKupNaqjdrXETOYHDInbehwPWksUv in ygKupNaqjdrXETOYHDInbehwPWksUl:
     ygKupNaqjdrXETOYHDInbehwPWkstU.HTTP_CLIENT.cookies.set_cookie(ygKupNaqjdrXETOYHDInbehwPWkstU.To_Cookielib(ygKupNaqjdrXETOYHDInbehwPWksUv)) 
   else:
    ygKupNaqjdrXETOYHDInbehwPWkstU.HTTP_CLIENT.cookies.update(ygKupNaqjdrXETOYHDInbehwPWksUl) 
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception)
  finally:
   fp.close()
 def To_Cookielib(ygKupNaqjdrXETOYHDInbehwPWkstU,selenium_cookie):
  return http.cookiejar.Cookie(version=0,name=selenium_cookie['name'],value=selenium_cookie['value'],port=ygKupNaqjdrXETOYHDInbehwPWksFM,port_specified=ygKupNaqjdrXETOYHDInbehwPWksFJ,domain=selenium_cookie['domain'],domain_specified=ygKupNaqjdrXETOYHDInbehwPWksFf,domain_initial_dot=ygKupNaqjdrXETOYHDInbehwPWksFJ,path=selenium_cookie['path'],path_specified=ygKupNaqjdrXETOYHDInbehwPWksFf,secure=selenium_cookie['secure'],expires=selenium_cookie['expiry'],discard=ygKupNaqjdrXETOYHDInbehwPWksFJ,comment=ygKupNaqjdrXETOYHDInbehwPWksFM,comment_url=ygKupNaqjdrXETOYHDInbehwPWksFM,rest={'HttpOnly':selenium_cookie['httpOnly']},rfc2109=ygKupNaqjdrXETOYHDInbehwPWksFJ,)
 def Get_Search_Primev(ygKupNaqjdrXETOYHDInbehwPWkstU,search_key):
  ygKupNaqjdrXETOYHDInbehwPWksti=[]
  try:
   ygKupNaqjdrXETOYHDInbehwPWkstU.Selenium_Cookies_Load(ygKupNaqjdrXETOYHDInbehwPWkstU.PV_ORIGINAL_COOKIE)
   ygKupNaqjdrXETOYHDInbehwPWkstz=ygKupNaqjdrXETOYHDInbehwPWkstU.API_PRIMEV+'/search/ref=atv_nb_sr?phrase='+urllib.parse.quote_plus(search_key)+'&ie=UTF8'
   ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.Call_Request(ygKupNaqjdrXETOYHDInbehwPWkstz,params=ygKupNaqjdrXETOYHDInbehwPWksFM,headers=ygKupNaqjdrXETOYHDInbehwPWksFM,method='GET')
   if ygKupNaqjdrXETOYHDInbehwPWkstF.status_code!=200:return[]
   ygKupNaqjdrXETOYHDInbehwPWksUC='{"props":{"results"'
   ygKupNaqjdrXETOYHDInbehwPWksUR=r'<script type="text/template">\s*(.*?)\s*</script>'
   ygKupNaqjdrXETOYHDInbehwPWksUG=re.compile(ygKupNaqjdrXETOYHDInbehwPWksUR,re.DOTALL).findall(ygKupNaqjdrXETOYHDInbehwPWkstF.text)
   ygKupNaqjdrXETOYHDInbehwPWksUL='{}'
   for ygKupNaqjdrXETOYHDInbehwPWksUM in ygKupNaqjdrXETOYHDInbehwPWksUG:
    if ygKupNaqjdrXETOYHDInbehwPWksUC in ygKupNaqjdrXETOYHDInbehwPWksUM:
     ygKupNaqjdrXETOYHDInbehwPWksUL=ygKupNaqjdrXETOYHDInbehwPWksUM
     break
   ygKupNaqjdrXETOYHDInbehwPWkstv=json.loads(ygKupNaqjdrXETOYHDInbehwPWksUL)
   ygKupNaqjdrXETOYHDInbehwPWksUf=ygKupNaqjdrXETOYHDInbehwPWkstv.get('props').get('results').get('items')
   for ygKupNaqjdrXETOYHDInbehwPWksUA in ygKupNaqjdrXETOYHDInbehwPWksUf:
    if 'titleID' not in ygKupNaqjdrXETOYHDInbehwPWksUA:return[]
    ygKupNaqjdrXETOYHDInbehwPWkstx={'title':ygKupNaqjdrXETOYHDInbehwPWksUA.get('title').get('text'),}
    ygKupNaqjdrXETOYHDInbehwPWksti.append(ygKupNaqjdrXETOYHDInbehwPWkstx)
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception)
  return ygKupNaqjdrXETOYHDInbehwPWksti
 def Get_Search_Disney(ygKupNaqjdrXETOYHDInbehwPWkstU,search_key):
  ygKupNaqjdrXETOYHDInbehwPWksti=[]
  ygKupNaqjdrXETOYHDInbehwPWkstz=ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['services']['content']['getSearchResults']['href']
  ygKupNaqjdrXETOYHDInbehwPWksUx={'apiVersion':'5.1','region':ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge','pageSize':ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWkstU.DISNEY_LIMIT),'query':search_key,}
  ygKupNaqjdrXETOYHDInbehwPWkstz=ygKupNaqjdrXETOYHDInbehwPWkstz.format(**ygKupNaqjdrXETOYHDInbehwPWksUx)
  ygKupNaqjdrXETOYHDInbehwPWksUz=ygKupNaqjdrXETOYHDInbehwPWkstU.make_DZ_Headers(accessToken=ygKupNaqjdrXETOYHDInbehwPWksFf,Bearer=ygKupNaqjdrXETOYHDInbehwPWksFf)
  ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.Call_Request(ygKupNaqjdrXETOYHDInbehwPWkstz,headers=ygKupNaqjdrXETOYHDInbehwPWksUz,method='GET')
  if ygKupNaqjdrXETOYHDInbehwPWkstF.status_code not in[200,201]:return[]
  ygKupNaqjdrXETOYHDInbehwPWksUB=ygKupNaqjdrXETOYHDInbehwPWkstF.json().get('data').get('search')
  for ygKupNaqjdrXETOYHDInbehwPWksUA in ygKupNaqjdrXETOYHDInbehwPWksUB.get('hits'):
   ygKupNaqjdrXETOYHDInbehwPWksUA=ygKupNaqjdrXETOYHDInbehwPWksUA.get('hit')
   if ygKupNaqjdrXETOYHDInbehwPWksUA.get('type')=='DmcSeries': 
    ygKupNaqjdrXETOYHDInbehwPWksUo =ygKupNaqjdrXETOYHDInbehwPWksUA.get('text').get('title').get('full').get('series').get('default').get('content')
   elif ygKupNaqjdrXETOYHDInbehwPWksUA.get('type')=='DmcVideo':
    ygKupNaqjdrXETOYHDInbehwPWksUo =ygKupNaqjdrXETOYHDInbehwPWksUA.get('text').get('title').get('full').get('program').get('default').get('content')
   elif ygKupNaqjdrXETOYHDInbehwPWksUA.get('type')=='StandardCollection':
    ygKupNaqjdrXETOYHDInbehwPWksUo =ygKupNaqjdrXETOYHDInbehwPWksUA.get('text').get('title').get('full').get('collection').get('default').get('content')
   else:
    return ygKupNaqjdrXETOYHDInbehwPWksti
   ygKupNaqjdrXETOYHDInbehwPWkstx={'title':ygKupNaqjdrXETOYHDInbehwPWksUo,}
   ygKupNaqjdrXETOYHDInbehwPWksti.append(ygKupNaqjdrXETOYHDInbehwPWkstx)
  return ygKupNaqjdrXETOYHDInbehwPWksti
 def dic_To_jsonfile(ygKupNaqjdrXETOYHDInbehwPWkstU,filename,ygKupNaqjdrXETOYHDInbehwPWksUJ):
  if filename=='':return
  fp=ygKupNaqjdrXETOYHDInbehwPWksVU(filename,'w',-1,'utf-8')
  json.dump(ygKupNaqjdrXETOYHDInbehwPWksUJ,fp,indent=4,ensure_ascii=ygKupNaqjdrXETOYHDInbehwPWksFJ)
  fp.close()
 def jsonfile_To_dic(ygKupNaqjdrXETOYHDInbehwPWkstU,filename):
  if filename=='':return ygKupNaqjdrXETOYHDInbehwPWksFM
  try:
   fp=ygKupNaqjdrXETOYHDInbehwPWksVU(filename,'r',-1,'utf-8')
   ygKupNaqjdrXETOYHDInbehwPWksoQ=json.load(fp)
   fp.close()
  except:
   ygKupNaqjdrXETOYHDInbehwPWksoQ={}
  return ygKupNaqjdrXETOYHDInbehwPWksoQ
 def tempFileSave(ygKupNaqjdrXETOYHDInbehwPWkstU,filename,resText):
  if filename=='':return
  fp=ygKupNaqjdrXETOYHDInbehwPWksVU(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(ygKupNaqjdrXETOYHDInbehwPWkstU,filename):
  if filename=='':return
  try:
   fp=ygKupNaqjdrXETOYHDInbehwPWksVU(filename,'r',-1,'utf-8')
   ygKupNaqjdrXETOYHDInbehwPWksoQ=fp.read()
   fp.close()
  except:
   ygKupNaqjdrXETOYHDInbehwPWksoQ=''
  return ygKupNaqjdrXETOYHDInbehwPWksoQ
 def make_DZ_Headers(ygKupNaqjdrXETOYHDInbehwPWkstU,accessToken=ygKupNaqjdrXETOYHDInbehwPWksFf,Bearer=ygKupNaqjdrXETOYHDInbehwPWksFJ):
  if accessToken:
   ygKupNaqjdrXETOYHDInbehwPWksoU=ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['account']['accessToken']
  else:
   ygKupNaqjdrXETOYHDInbehwPWksoU=ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['headers']['clientApiKey']
  if Bearer:
   ygKupNaqjdrXETOYHDInbehwPWksoU='Bearer {}'.format(ygKupNaqjdrXETOYHDInbehwPWksoU)
  ygKupNaqjdrXETOYHDInbehwPWksUz={'authorization':ygKupNaqjdrXETOYHDInbehwPWksoU,'x-application-version':ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['headers']['sdkAppVersion'],'x-bamsdk-client-id':ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['headers']['clientId'],'x-bamsdk-platform':'windows','x-bamsdk-version':ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['headers']['sdkVersion'],'x-dss-edge-accept':'vnd.dss.edge+json; version=2',}
  return ygKupNaqjdrXETOYHDInbehwPWksUz
 def DZ_ReToken(ygKupNaqjdrXETOYHDInbehwPWkstU):
  try:
   ygKupNaqjdrXETOYHDInbehwPWkstz =ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['services']['orchestration']['refreshToken']['href']
   ygKupNaqjdrXETOYHDInbehwPWksUz=ygKupNaqjdrXETOYHDInbehwPWkstU.make_DZ_Headers(accessToken=ygKupNaqjdrXETOYHDInbehwPWksFJ,Bearer=ygKupNaqjdrXETOYHDInbehwPWksFJ)
   ygKupNaqjdrXETOYHDInbehwPWksoF={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['account']['refreshToken'],}}}
   ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.Call_Request(ygKupNaqjdrXETOYHDInbehwPWkstz,json=ygKupNaqjdrXETOYHDInbehwPWksoF,headers=ygKupNaqjdrXETOYHDInbehwPWksUz,method='POST')
   if ygKupNaqjdrXETOYHDInbehwPWkstF.status_code not in[200,201]:return ygKupNaqjdrXETOYHDInbehwPWksFJ
   ygKupNaqjdrXETOYHDInbehwPWksUB=ygKupNaqjdrXETOYHDInbehwPWkstF.json()
   ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['account']['accessToken'] =ygKupNaqjdrXETOYHDInbehwPWksUB.get('extensions').get('sdk').get('token').get('accessToken')
   ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['account']['accessTokenType']=ygKupNaqjdrXETOYHDInbehwPWksUB.get('extensions').get('sdk').get('token').get('accessTokenType')
   ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['account']['refreshToken'] =ygKupNaqjdrXETOYHDInbehwPWksUB.get('extensions').get('sdk').get('token').get('refreshToken')
   ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['account']['token_limit'] =ygKupNaqjdrXETOYHDInbehwPWksFB(time.time())+14400 
   ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['account']['deviceId'] =ygKupNaqjdrXETOYHDInbehwPWksUB.get('extensions').get('sdk').get('session').get('device').get('id')
   ygKupNaqjdrXETOYHDInbehwPWkstU.DZ['account']['sessionId'] =ygKupNaqjdrXETOYHDInbehwPWksUB.get('extensions').get('sdk').get('session').get('sessionId')
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception)
   return ygKupNaqjdrXETOYHDInbehwPWksFJ
  return ygKupNaqjdrXETOYHDInbehwPWksFf
 def Init_NF_Total(ygKupNaqjdrXETOYHDInbehwPWkstU):
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF={}
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']={}
  ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']={}
 def make_NF_XnetflixHeaders(ygKupNaqjdrXETOYHDInbehwPWkstU):
  ygKupNaqjdrXETOYHDInbehwPWksUz={'x-netflix.browsername':ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['esnModel'],'x-netflix.esnprefix':ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['nowGuid'],'x-netflix.uiversion':ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return ygKupNaqjdrXETOYHDInbehwPWksUz
 def make_NF_ApiParams(ygKupNaqjdrXETOYHDInbehwPWkstU):
  ygKupNaqjdrXETOYHDInbehwPWkstl={'avif':'false','webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','isTop10KidsSupported':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/mre/pathEvaluator',}
  return ygKupNaqjdrXETOYHDInbehwPWkstl
 def extract_json(ygKupNaqjdrXETOYHDInbehwPWkstU,content,name):
  ygKupNaqjdrXETOYHDInbehwPWksUR=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  ygKupNaqjdrXETOYHDInbehwPWksUL=ygKupNaqjdrXETOYHDInbehwPWksFM
  ygKupNaqjdrXETOYHDInbehwPWksoV=re.compile(ygKupNaqjdrXETOYHDInbehwPWksUR.format(name),re.DOTALL).findall(content)
  ygKupNaqjdrXETOYHDInbehwPWksUL=ygKupNaqjdrXETOYHDInbehwPWksoV[0]
  ygKupNaqjdrXETOYHDInbehwPWksoi=ygKupNaqjdrXETOYHDInbehwPWksUL.replace('\\"','\\\\"') 
  ygKupNaqjdrXETOYHDInbehwPWksoi=ygKupNaqjdrXETOYHDInbehwPWksoi.replace('\\s','\\\\s') 
  ygKupNaqjdrXETOYHDInbehwPWksoi=ygKupNaqjdrXETOYHDInbehwPWksoi.replace('\\n','\\\\n') 
  ygKupNaqjdrXETOYHDInbehwPWksoi=ygKupNaqjdrXETOYHDInbehwPWksoi.replace('\\t','\\\\t') 
  ygKupNaqjdrXETOYHDInbehwPWksoi=ygKupNaqjdrXETOYHDInbehwPWksoi.encode().decode('unicode_escape') 
  ygKupNaqjdrXETOYHDInbehwPWksoi=re.sub(r'\\(?!["])',r'\\\\',ygKupNaqjdrXETOYHDInbehwPWksoi) 
  return json.loads(ygKupNaqjdrXETOYHDInbehwPWksoi)
 def NF_makestr_paths(ygKupNaqjdrXETOYHDInbehwPWkstU,paths):
  ygKupNaqjdrXETOYHDInbehwPWksoQ=[]
  if ygKupNaqjdrXETOYHDInbehwPWksVi(paths,ygKupNaqjdrXETOYHDInbehwPWksFB):
   return '%d'%(paths)
  elif ygKupNaqjdrXETOYHDInbehwPWksVi(paths,ygKupNaqjdrXETOYHDInbehwPWksFx):
   return '"%s"'%(paths)
  for ygKupNaqjdrXETOYHDInbehwPWksoc in paths:
   if ygKupNaqjdrXETOYHDInbehwPWksVi(ygKupNaqjdrXETOYHDInbehwPWksoc,ygKupNaqjdrXETOYHDInbehwPWksFB):
    ygKupNaqjdrXETOYHDInbehwPWksoQ.append('%d'%(ygKupNaqjdrXETOYHDInbehwPWksoc))
   elif ygKupNaqjdrXETOYHDInbehwPWksVi(ygKupNaqjdrXETOYHDInbehwPWksoc,ygKupNaqjdrXETOYHDInbehwPWksFx):
    ygKupNaqjdrXETOYHDInbehwPWksoQ.append('"%s"'%(ygKupNaqjdrXETOYHDInbehwPWksoc))
   elif ygKupNaqjdrXETOYHDInbehwPWksVi(ygKupNaqjdrXETOYHDInbehwPWksoc,ygKupNaqjdrXETOYHDInbehwPWksVF):
    ygKupNaqjdrXETOYHDInbehwPWksoQ.append('[%s]'%(','.join(ygKupNaqjdrXETOYHDInbehwPWkstU.NF_makestr_paths(ygKupNaqjdrXETOYHDInbehwPWksoc))))
   elif ygKupNaqjdrXETOYHDInbehwPWksVi(ygKupNaqjdrXETOYHDInbehwPWksoc,ygKupNaqjdrXETOYHDInbehwPWksVc):
    ygKupNaqjdrXETOYHDInbehwPWksom=''
    for ygKupNaqjdrXETOYHDInbehwPWksoz,ygKupNaqjdrXETOYHDInbehwPWksol in ygKupNaqjdrXETOYHDInbehwPWksoc.items():
     ygKupNaqjdrXETOYHDInbehwPWksom+='"%s":%s,'%(ygKupNaqjdrXETOYHDInbehwPWksoz,ygKupNaqjdrXETOYHDInbehwPWkstU.NF_makestr_paths(ygKupNaqjdrXETOYHDInbehwPWksol))
    ygKupNaqjdrXETOYHDInbehwPWksoQ.append('{%s}'%(ygKupNaqjdrXETOYHDInbehwPWksom[:-1]))
  return ygKupNaqjdrXETOYHDInbehwPWksoQ
 def NF_Call_pathapi(ygKupNaqjdrXETOYHDInbehwPWkstU,ygKupNaqjdrXETOYHDInbehwPWksoB,referer=''):
  ygKupNaqjdrXETOYHDInbehwPWksov='%s/nq/website/memberapi/%s/pathEvaluator'%(ygKupNaqjdrXETOYHDInbehwPWkstU.API_NETFLIX,ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['identifier'])
  ygKupNaqjdrXETOYHDInbehwPWksoF={'path':ygKupNaqjdrXETOYHDInbehwPWkstU.NF_makestr_paths(ygKupNaqjdrXETOYHDInbehwPWksoB),'authURL':ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']['authURL']}
  ygKupNaqjdrXETOYHDInbehwPWkstl=ygKupNaqjdrXETOYHDInbehwPWkstU.make_NF_ApiParams()
  ygKupNaqjdrXETOYHDInbehwPWksUz={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':ygKupNaqjdrXETOYHDInbehwPWkstU.API_NETFLIX,'sec-ch-ua':'"Google Chrome";v="101", "Not)A;Brand";v="8", "Chromium";v="101"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':ygKupNaqjdrXETOYHDInbehwPWksUz['referer']=referer
  ygKupNaqjdrXETOYHDInbehwPWksoS=ygKupNaqjdrXETOYHDInbehwPWkstU.make_NF_XnetflixHeaders()
  ygKupNaqjdrXETOYHDInbehwPWksUz.update(ygKupNaqjdrXETOYHDInbehwPWksoS)
  ygKupNaqjdrXETOYHDInbehwPWksoC=ygKupNaqjdrXETOYHDInbehwPWkstU.NF_Get_DefaultCookies()
  ygKupNaqjdrXETOYHDInbehwPWksoC['profilesNewSession']='0'
  try:
   ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.Call_Request(ygKupNaqjdrXETOYHDInbehwPWksov,payload=ygKupNaqjdrXETOYHDInbehwPWksoF,params=ygKupNaqjdrXETOYHDInbehwPWkstl,headers=ygKupNaqjdrXETOYHDInbehwPWksUz,cookies=ygKupNaqjdrXETOYHDInbehwPWksoC,method='POST')
   return ygKupNaqjdrXETOYHDInbehwPWkstF
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception)
   return ygKupNaqjdrXETOYHDInbehwPWksFM
 def Get_Search_Netflix(ygKupNaqjdrXETOYHDInbehwPWkstU,search_key,page_int,byReference=''):
  ygKupNaqjdrXETOYHDInbehwPWksoR=ygKupNaqjdrXETOYHDInbehwPWkstU.DERECTOR_LIMIT
  ygKupNaqjdrXETOYHDInbehwPWksoG =ygKupNaqjdrXETOYHDInbehwPWkstU.CAST_LIMIT
  ygKupNaqjdrXETOYHDInbehwPWksoL =ygKupNaqjdrXETOYHDInbehwPWkstU.GENRE_LIMIT
  ygKupNaqjdrXETOYHDInbehwPWksoM =ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_LIMIT*(page_int-1)
  ygKupNaqjdrXETOYHDInbehwPWksof =ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_LIMIT*page_int 
  ygKupNaqjdrXETOYHDInbehwPWksoA="|%s"%(search_key)
  ygKupNaqjdrXETOYHDInbehwPWksox ='%s/search?%s'%(ygKupNaqjdrXETOYHDInbehwPWkstU.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   ygKupNaqjdrXETOYHDInbehwPWksoB=[["search","byTerm",ygKupNaqjdrXETOYHDInbehwPWksoA,"titles",ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_LIMIT,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"summary"],["search","byTerm",ygKupNaqjdrXETOYHDInbehwPWksoA,"titles",ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_LIMIT,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",ygKupNaqjdrXETOYHDInbehwPWksoA,"titles",ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_LIMIT,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference","boxarts",[ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND2,ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_PORT],"jpg"],["search","byTerm",ygKupNaqjdrXETOYHDInbehwPWksoA,"titles",ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_LIMIT,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference","interestingMoment",ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND1,"jpg"],["search","byTerm",ygKupNaqjdrXETOYHDInbehwPWksoA,"titles",ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_LIMIT,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference","storyArt",ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND2,"jpg"],["search","byTerm",ygKupNaqjdrXETOYHDInbehwPWksoA,"titles",ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_LIMIT,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference",["cast","creators","directors"],{"from":0,"to":ygKupNaqjdrXETOYHDInbehwPWksoR},["id","name"]],["search","byTerm",ygKupNaqjdrXETOYHDInbehwPWksoA,"titles",ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_LIMIT,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference","genres",{"from":0,"to":ygKupNaqjdrXETOYHDInbehwPWksoL},["id","name"]],["search","byTerm",ygKupNaqjdrXETOYHDInbehwPWksoA,"titles",ygKupNaqjdrXETOYHDInbehwPWkstU.NETFLIX_LIMIT,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LOGO,"png"],]
  else:
   ygKupNaqjdrXETOYHDInbehwPWksoB=[["search","byReference",byReference,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"summary"],["search","byReference",byReference,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference","boxarts",[ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND2,ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference","interestingMoment",ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference","storyArt",ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference",["cast","creators","directors"],{"from":0,"to":ygKupNaqjdrXETOYHDInbehwPWksoR},["id","name"]],["search","byReference",byReference,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference","genres",{"from":0,"to":ygKupNaqjdrXETOYHDInbehwPWksoL},["id","name"]],["search","byReference",byReference,{"from":ygKupNaqjdrXETOYHDInbehwPWksoM,"to":ygKupNaqjdrXETOYHDInbehwPWksof},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LOGO,"png"],]
  try:
   ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.NF_Call_pathapi(ygKupNaqjdrXETOYHDInbehwPWksoB,ygKupNaqjdrXETOYHDInbehwPWksox)
   ygKupNaqjdrXETOYHDInbehwPWkstv=json.loads(ygKupNaqjdrXETOYHDInbehwPWkstF.text)
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception)
  (ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm,byReference)=ygKupNaqjdrXETOYHDInbehwPWkstU.Search_Netflix_Make(ygKupNaqjdrXETOYHDInbehwPWkstv)
  return ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm,byReference
 def Search_Netflix_Make(ygKupNaqjdrXETOYHDInbehwPWkstU,jsonSource):
  ygKupNaqjdrXETOYHDInbehwPWksti=[]
  ygKupNaqjdrXETOYHDInbehwPWkstm =ygKupNaqjdrXETOYHDInbehwPWksFJ
  ygKupNaqjdrXETOYHDInbehwPWksoJ=''
  ygKupNaqjdrXETOYHDInbehwPWksFt=jsonSource.get('paths')[0][1]
  if ygKupNaqjdrXETOYHDInbehwPWksFt=='byTerm':
   ygKupNaqjdrXETOYHDInbehwPWksoM =jsonSource['paths'][0][5]['from']
   ygKupNaqjdrXETOYHDInbehwPWksof =jsonSource['paths'][0][5]['to']
  else:
   ygKupNaqjdrXETOYHDInbehwPWksoM =jsonSource['paths'][0][3]['from']
   ygKupNaqjdrXETOYHDInbehwPWksof =jsonSource['paths'][0][3]['to']
  ygKupNaqjdrXETOYHDInbehwPWksoJ=ygKupNaqjdrXETOYHDInbehwPWksVF(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  ygKupNaqjdrXETOYHDInbehwPWksFQ=jsonSource.get('jsonGraph').get('search').get('byReference').get(ygKupNaqjdrXETOYHDInbehwPWksoJ)
  ygKupNaqjdrXETOYHDInbehwPWksFU =jsonSource.get('jsonGraph').get('videos')
  ygKupNaqjdrXETOYHDInbehwPWksFo=jsonSource.get('jsonGraph').get('person')
  ygKupNaqjdrXETOYHDInbehwPWksFV=jsonSource.get('jsonGraph').get('genres')
  ygKupNaqjdrXETOYHDInbehwPWkstm=ygKupNaqjdrXETOYHDInbehwPWksFf if ygKupNaqjdrXETOYHDInbehwPWksFQ[ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWksof)]['reference']['$type']=='ref' else ygKupNaqjdrXETOYHDInbehwPWksFJ
  for ygKupNaqjdrXETOYHDInbehwPWksFi in ygKupNaqjdrXETOYHDInbehwPWksVm(ygKupNaqjdrXETOYHDInbehwPWksoM,ygKupNaqjdrXETOYHDInbehwPWksof):
   if ygKupNaqjdrXETOYHDInbehwPWksFQ[ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWksFi)]['reference']['$type']=='ref':
    ygKupNaqjdrXETOYHDInbehwPWkstM =ygKupNaqjdrXETOYHDInbehwPWksFQ[ygKupNaqjdrXETOYHDInbehwPWksFx(ygKupNaqjdrXETOYHDInbehwPWksFi)]['reference']['value'][1]
    ygKupNaqjdrXETOYHDInbehwPWksFc=ygKupNaqjdrXETOYHDInbehwPWksFU[ygKupNaqjdrXETOYHDInbehwPWkstM]
    ygKupNaqjdrXETOYHDInbehwPWksUo =ygKupNaqjdrXETOYHDInbehwPWksFc['title']['value']
    if ygKupNaqjdrXETOYHDInbehwPWksFc['availability']['value']['isPlayable']==ygKupNaqjdrXETOYHDInbehwPWksFJ:
     continue
    ygKupNaqjdrXETOYHDInbehwPWkstL =ygKupNaqjdrXETOYHDInbehwPWksFc['summary']['value']['type']
    ygKupNaqjdrXETOYHDInbehwPWksQC =0 if ygKupNaqjdrXETOYHDInbehwPWkstL!='movie' else ygKupNaqjdrXETOYHDInbehwPWksFc['runtime']['value']
    if ygKupNaqjdrXETOYHDInbehwPWksFc['sequiturEvidence']['value']['value']:
     ygKupNaqjdrXETOYHDInbehwPWksFm=ygKupNaqjdrXETOYHDInbehwPWksFc['sequiturEvidence']['value']['value']['text']
    else:
     ygKupNaqjdrXETOYHDInbehwPWksFm=''
    ygKupNaqjdrXETOYHDInbehwPWksQm =ygKupNaqjdrXETOYHDInbehwPWksFc['boxarts'][ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_PORT]['jpg']['value']['url']
    ygKupNaqjdrXETOYHDInbehwPWksFz =ygKupNaqjdrXETOYHDInbehwPWksFc['boxarts'][ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND2]['jpg']['value']['url']
    ygKupNaqjdrXETOYHDInbehwPWksQz=''
    if 'value' in ygKupNaqjdrXETOYHDInbehwPWksFc['storyArt'][ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND2]['jpg']:
     ygKupNaqjdrXETOYHDInbehwPWksQz =ygKupNaqjdrXETOYHDInbehwPWksFc['storyArt'][ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND2]['jpg']['value']['url']
    if ygKupNaqjdrXETOYHDInbehwPWksQz=='' and 'value' in ygKupNaqjdrXETOYHDInbehwPWksFc['interestingMoment'][ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND1]['jpg']:
     ygKupNaqjdrXETOYHDInbehwPWksQz =ygKupNaqjdrXETOYHDInbehwPWksFc['interestingMoment'][ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LAND1]['jpg']['value']['url']
    ygKupNaqjdrXETOYHDInbehwPWksQA=''
    if 'value' in ygKupNaqjdrXETOYHDInbehwPWksFc['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LOGO]['png']:
     ygKupNaqjdrXETOYHDInbehwPWksQA=ygKupNaqjdrXETOYHDInbehwPWksFc['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][ygKupNaqjdrXETOYHDInbehwPWkstU.ART_SIZE_LOGO]['png']['value']['url']
    ygKupNaqjdrXETOYHDInbehwPWksQS =ygKupNaqjdrXETOYHDInbehwPWkstU.NF_Subid_List(ygKupNaqjdrXETOYHDInbehwPWksFc['genres'])
    for i in ygKupNaqjdrXETOYHDInbehwPWksVm(ygKupNaqjdrXETOYHDInbehwPWksVQ(ygKupNaqjdrXETOYHDInbehwPWksQS)):
     ygKupNaqjdrXETOYHDInbehwPWksQS[i]=ygKupNaqjdrXETOYHDInbehwPWksFV[ygKupNaqjdrXETOYHDInbehwPWksQS[i]]['name']['value']
    ygKupNaqjdrXETOYHDInbehwPWksQv=ygKupNaqjdrXETOYHDInbehwPWkstU.NF_Subid_List(ygKupNaqjdrXETOYHDInbehwPWksFc['directors'])
    ygKupNaqjdrXETOYHDInbehwPWksFl =ygKupNaqjdrXETOYHDInbehwPWkstU.NF_Subid_List(ygKupNaqjdrXETOYHDInbehwPWksFc['creators'])
    ygKupNaqjdrXETOYHDInbehwPWksQv.extend(ygKupNaqjdrXETOYHDInbehwPWksFl)
    for i in ygKupNaqjdrXETOYHDInbehwPWksVm(ygKupNaqjdrXETOYHDInbehwPWksVQ(ygKupNaqjdrXETOYHDInbehwPWksQv)):
     ygKupNaqjdrXETOYHDInbehwPWksQv[i]=ygKupNaqjdrXETOYHDInbehwPWksFo[ygKupNaqjdrXETOYHDInbehwPWksQv[i]]['name']['value']
    ygKupNaqjdrXETOYHDInbehwPWksQl=ygKupNaqjdrXETOYHDInbehwPWkstU.NF_Subid_List(ygKupNaqjdrXETOYHDInbehwPWksFc['cast'])
    for i in ygKupNaqjdrXETOYHDInbehwPWksVm(ygKupNaqjdrXETOYHDInbehwPWksVQ(ygKupNaqjdrXETOYHDInbehwPWksQl)):
     ygKupNaqjdrXETOYHDInbehwPWksQl[i]=ygKupNaqjdrXETOYHDInbehwPWksFo[ygKupNaqjdrXETOYHDInbehwPWksQl[i]]['name']['value']
    if 'maturityDescription' in ygKupNaqjdrXETOYHDInbehwPWksFc['maturity']['value']['rating']:
     ygKupNaqjdrXETOYHDInbehwPWksQR=ygKupNaqjdrXETOYHDInbehwPWksFc['maturity']['value']['rating']['maturityDescription']
    ygKupNaqjdrXETOYHDInbehwPWkstx={'videoid':ygKupNaqjdrXETOYHDInbehwPWkstM,'vidtype':ygKupNaqjdrXETOYHDInbehwPWkstL,'title':ygKupNaqjdrXETOYHDInbehwPWksUo,'mpaa':ygKupNaqjdrXETOYHDInbehwPWksQR,'regularSynopsis':ygKupNaqjdrXETOYHDInbehwPWksFc['regularSynopsis']['value'],'dpSupplemental':ygKupNaqjdrXETOYHDInbehwPWksFc['dpSupplementalMessage']['value'],'sequiturEvidence':ygKupNaqjdrXETOYHDInbehwPWksFm,'thumbnail':{'poster':ygKupNaqjdrXETOYHDInbehwPWksQm,'thumb':ygKupNaqjdrXETOYHDInbehwPWksQz,'fanart':ygKupNaqjdrXETOYHDInbehwPWksFz,'clearlogo':ygKupNaqjdrXETOYHDInbehwPWksQA},'year':ygKupNaqjdrXETOYHDInbehwPWksFc['releaseYear']['value'],'duration':ygKupNaqjdrXETOYHDInbehwPWksQC,'info_genre':ygKupNaqjdrXETOYHDInbehwPWksQS,'director':ygKupNaqjdrXETOYHDInbehwPWksQv,'cast':ygKupNaqjdrXETOYHDInbehwPWksQl,}
    ygKupNaqjdrXETOYHDInbehwPWksti.append(ygKupNaqjdrXETOYHDInbehwPWkstx)
  return ygKupNaqjdrXETOYHDInbehwPWksti,ygKupNaqjdrXETOYHDInbehwPWkstm,ygKupNaqjdrXETOYHDInbehwPWksoJ
 def NF_Subid_List(ygKupNaqjdrXETOYHDInbehwPWkstU,subJson):
  ygKupNaqjdrXETOYHDInbehwPWksFv=[]
  try:
   for i in ygKupNaqjdrXETOYHDInbehwPWksVm(ygKupNaqjdrXETOYHDInbehwPWksVQ(subJson)):
    if subJson.get(ygKupNaqjdrXETOYHDInbehwPWksFx(i)).get('$type')!='ref':break
    ygKupNaqjdrXETOYHDInbehwPWksFS=subJson.get(ygKupNaqjdrXETOYHDInbehwPWksFx(i)).get('value')[1]
    ygKupNaqjdrXETOYHDInbehwPWksFv.append(ygKupNaqjdrXETOYHDInbehwPWksFS)
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception)
  return ygKupNaqjdrXETOYHDInbehwPWksFv
 def NF_CookieFile_Load(ygKupNaqjdrXETOYHDInbehwPWkstU,cookie_filename):
  ygKupNaqjdrXETOYHDInbehwPWksoC={}
  try:
   if os.path.isfile(cookie_filename)==ygKupNaqjdrXETOYHDInbehwPWksFJ:return{}
   ygKupNaqjdrXETOYHDInbehwPWksFC=ygKupNaqjdrXETOYHDInbehwPWksVU(cookie_filename,'rb',-1)
   ygKupNaqjdrXETOYHDInbehwPWksFR =pickle.loads(ygKupNaqjdrXETOYHDInbehwPWksFC.read())
   ygKupNaqjdrXETOYHDInbehwPWksFC.close()
   for ygKupNaqjdrXETOYHDInbehwPWksUv in ygKupNaqjdrXETOYHDInbehwPWksFR:
    ygKupNaqjdrXETOYHDInbehwPWksoC[ygKupNaqjdrXETOYHDInbehwPWksUv.name]=ygKupNaqjdrXETOYHDInbehwPWksUv.value
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception) 
  return ygKupNaqjdrXETOYHDInbehwPWksoC
 def NF_Get_DefaultCookies(ygKupNaqjdrXETOYHDInbehwPWkstU):
  ygKupNaqjdrXETOYHDInbehwPWksoC={}
  if ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']['flwssn'] :ygKupNaqjdrXETOYHDInbehwPWksoC['flwssn'] =ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']['flwssn']
  if ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']['nfvdid'] :ygKupNaqjdrXETOYHDInbehwPWksoC['nfvdid'] =ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']['nfvdid']
  if ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']['SecureNetflixId']:ygKupNaqjdrXETOYHDInbehwPWksoC['SecureNetflixId']=ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']['SecureNetflixId']
  if ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']['NetflixId'] :ygKupNaqjdrXETOYHDInbehwPWksoC['NetflixId'] =ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']['NetflixId']
  if ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']['memclid'] :ygKupNaqjdrXETOYHDInbehwPWksoC['memclid'] =ygKupNaqjdrXETOYHDInbehwPWkstU.NF['COOKIES']['memclid']
  return ygKupNaqjdrXETOYHDInbehwPWksoC
 def NF_Get_BaseSession(ygKupNaqjdrXETOYHDInbehwPWkstU):
  try:
   ygKupNaqjdrXETOYHDInbehwPWkstz=ygKupNaqjdrXETOYHDInbehwPWkstU.API_NETFLIX+'/browse' 
   ygKupNaqjdrXETOYHDInbehwPWksoC=ygKupNaqjdrXETOYHDInbehwPWkstU.NF_Get_DefaultCookies()
   ygKupNaqjdrXETOYHDInbehwPWkstF=ygKupNaqjdrXETOYHDInbehwPWkstU.Call_Request(ygKupNaqjdrXETOYHDInbehwPWkstz,payload=ygKupNaqjdrXETOYHDInbehwPWksFM,params=ygKupNaqjdrXETOYHDInbehwPWksFM,headers=ygKupNaqjdrXETOYHDInbehwPWksFM,cookies=ygKupNaqjdrXETOYHDInbehwPWksoC,method='GET')
   if ygKupNaqjdrXETOYHDInbehwPWkstF.status_code!=200:
    ygKupNaqjdrXETOYHDInbehwPWksFA('pass 1 status_code error')
    return ygKupNaqjdrXETOYHDInbehwPWksFJ
   ygKupNaqjdrXETOYHDInbehwPWksFG =ygKupNaqjdrXETOYHDInbehwPWkstU.extract_json(ygKupNaqjdrXETOYHDInbehwPWkstF.text,'reactContext')
   ygKupNaqjdrXETOYHDInbehwPWkstU.NF['SESSION']={'mainGuid':ygKupNaqjdrXETOYHDInbehwPWksFG['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':ygKupNaqjdrXETOYHDInbehwPWksFG['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':ygKupNaqjdrXETOYHDInbehwPWksFG['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':ygKupNaqjdrXETOYHDInbehwPWksFG['models']['memberContext']['data']['userInfo']['esn'],'identifier':ygKupNaqjdrXETOYHDInbehwPWksFG['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':ygKupNaqjdrXETOYHDInbehwPWksFG['models']['abContext']['data']['headers'],}
   ygKupNaqjdrXETOYHDInbehwPWkstU.dic_To_jsonfile(ygKupNaqjdrXETOYHDInbehwPWkstU.NF_SESSION_COOKIES1,ygKupNaqjdrXETOYHDInbehwPWkstU.NF)
  except ygKupNaqjdrXETOYHDInbehwPWksVt as exception:
   ygKupNaqjdrXETOYHDInbehwPWksFA('pass 1 error')
   ygKupNaqjdrXETOYHDInbehwPWksFA(exception)
   return ygKupNaqjdrXETOYHDInbehwPWksFJ
  return ygKupNaqjdrXETOYHDInbehwPWksFf
# Created by pyminifier (https://github.com/liftoff/pyminifier)
