__author__="NightRain"
NMnHAGmizTaCEDyLhXpgfFWbYRUBqK=object
NMnHAGmizTaCEDyLhXpgfFWbYRUBqO=None
NMnHAGmizTaCEDyLhXpgfFWbYRUBqd=True
NMnHAGmizTaCEDyLhXpgfFWbYRUBqx=False
NMnHAGmizTaCEDyLhXpgfFWbYRUBqe=type
NMnHAGmizTaCEDyLhXpgfFWbYRUBqw=dict
NMnHAGmizTaCEDyLhXpgfFWbYRUBqV=open
NMnHAGmizTaCEDyLhXpgfFWbYRUBqc=len
NMnHAGmizTaCEDyLhXpgfFWbYRUBqt=Exception
NMnHAGmizTaCEDyLhXpgfFWbYRUBqj=range
NMnHAGmizTaCEDyLhXpgfFWbYRUBqs=int
NMnHAGmizTaCEDyLhXpgfFWbYRUBqS=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
NMnHAGmizTaCEDyLhXpgfFWbYRUBrl=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
NMnHAGmizTaCEDyLhXpgfFWbYRUBro={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'HYPER_LINK','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},}
NMnHAGmizTaCEDyLhXpgfFWbYRUBrq=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
NMnHAGmizTaCEDyLhXpgfFWbYRUBrJ =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class NMnHAGmizTaCEDyLhXpgfFWbYRUBru(NMnHAGmizTaCEDyLhXpgfFWbYRUBqK):
 def __init__(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,NMnHAGmizTaCEDyLhXpgfFWbYRUBrK,NMnHAGmizTaCEDyLhXpgfFWbYRUBrO,NMnHAGmizTaCEDyLhXpgfFWbYRUBrd):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ._addon_url =NMnHAGmizTaCEDyLhXpgfFWbYRUBrK
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ._addon_handle=NMnHAGmizTaCEDyLhXpgfFWbYRUBrO
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.main_params =NMnHAGmizTaCEDyLhXpgfFWbYRUBrd
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj =AoxeprEjqwcTLPNJIblDHkMOYsUFWK() 
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
 def addon_noti(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,sting):
  try:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBre=xbmcgui.Dialog()
   NMnHAGmizTaCEDyLhXpgfFWbYRUBre.notification(__addonname__,sting)
  except:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBqO
 def addon_log(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,string):
  try:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrw=string.encode('utf-8','ignore')
  except:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrw='addonException: addon_log'
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrV=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,NMnHAGmizTaCEDyLhXpgfFWbYRUBrw),level=NMnHAGmizTaCEDyLhXpgfFWbYRUBrV)
 def get_keyboard_input(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,NMnHAGmizTaCEDyLhXpgfFWbYRUBrS):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrc=NMnHAGmizTaCEDyLhXpgfFWbYRUBqO
  kb=xbmc.Keyboard()
  kb.setHeading(NMnHAGmizTaCEDyLhXpgfFWbYRUBrS)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrc=kb.getText()
  return NMnHAGmizTaCEDyLhXpgfFWbYRUBrc
 def get_settings_menubookmark(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrt=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd if __addon__.getSetting('menu_bookmark')=='true' else NMnHAGmizTaCEDyLhXpgfFWbYRUBqx
  return(NMnHAGmizTaCEDyLhXpgfFWbYRUBrt)
 def get_settings_makebookmark(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ):
  return NMnHAGmizTaCEDyLhXpgfFWbYRUBqd if __addon__.getSetting('make_bookmark')=='true' else NMnHAGmizTaCEDyLhXpgfFWbYRUBqx
 def get_settings_select_info(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrj=[]
  if __addon__.getSetting('netflixyn')=='true':NMnHAGmizTaCEDyLhXpgfFWbYRUBrj.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':NMnHAGmizTaCEDyLhXpgfFWbYRUBrj.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':NMnHAGmizTaCEDyLhXpgfFWbYRUBrj.append('tving')
  if __addon__.getSetting('watchayn')=='true':NMnHAGmizTaCEDyLhXpgfFWbYRUBrj.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':NMnHAGmizTaCEDyLhXpgfFWbYRUBrj.append('coupang')
  return NMnHAGmizTaCEDyLhXpgfFWbYRUBrj
 def add_dir(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,label,sublabel='',img='',infoLabels=NMnHAGmizTaCEDyLhXpgfFWbYRUBqO,isFolder=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd,params='',isLink=NMnHAGmizTaCEDyLhXpgfFWbYRUBqx,ContextMenu=NMnHAGmizTaCEDyLhXpgfFWbYRUBqO):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrs='%s?%s'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ._addon_url,urllib.parse.urlencode(params))
  if sublabel:NMnHAGmizTaCEDyLhXpgfFWbYRUBrS='%s < %s >'%(label,sublabel)
  else: NMnHAGmizTaCEDyLhXpgfFWbYRUBrS=label
  if not img:img='DefaultFolder.png'
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrP=xbmcgui.ListItem(NMnHAGmizTaCEDyLhXpgfFWbYRUBrS)
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBqe(img)==NMnHAGmizTaCEDyLhXpgfFWbYRUBqw:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrP.setArt(img)
  else:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrP.setArt({'thumb':img,'poster':img})
  if infoLabels:NMnHAGmizTaCEDyLhXpgfFWbYRUBrP.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrP.setProperty('IsPlayable','true')
  if ContextMenu:NMnHAGmizTaCEDyLhXpgfFWbYRUBrP.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ._addon_handle,NMnHAGmizTaCEDyLhXpgfFWbYRUBrs,NMnHAGmizTaCEDyLhXpgfFWbYRUBrP,isFolder)
 def Load_Searched_List(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ):
  try:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrI=NMnHAGmizTaCEDyLhXpgfFWbYRUBrJ
   fp=NMnHAGmizTaCEDyLhXpgfFWbYRUBqV(NMnHAGmizTaCEDyLhXpgfFWbYRUBrI,'r',-1,'utf-8')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrk=fp.readlines()
   fp.close()
  except:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrk=[]
  return NMnHAGmizTaCEDyLhXpgfFWbYRUBrk
 def Save_Searched_List(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,NMnHAGmizTaCEDyLhXpgfFWbYRUBlV):
  try:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrI=NMnHAGmizTaCEDyLhXpgfFWbYRUBrJ
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrv=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.Load_Searched_List() 
   NMnHAGmizTaCEDyLhXpgfFWbYRUBur={'skey':NMnHAGmizTaCEDyLhXpgfFWbYRUBlV.strip()}
   fp=NMnHAGmizTaCEDyLhXpgfFWbYRUBqV(NMnHAGmizTaCEDyLhXpgfFWbYRUBrI,'w',-1,'utf-8')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBul=urllib.parse.urlencode(NMnHAGmizTaCEDyLhXpgfFWbYRUBur)
   NMnHAGmizTaCEDyLhXpgfFWbYRUBul=NMnHAGmizTaCEDyLhXpgfFWbYRUBul+'\n'
   fp.write(NMnHAGmizTaCEDyLhXpgfFWbYRUBul)
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuo=0
   for NMnHAGmizTaCEDyLhXpgfFWbYRUBuq in NMnHAGmizTaCEDyLhXpgfFWbYRUBrv:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBuJ=NMnHAGmizTaCEDyLhXpgfFWbYRUBqw(urllib.parse.parse_qsl(NMnHAGmizTaCEDyLhXpgfFWbYRUBuq))
    NMnHAGmizTaCEDyLhXpgfFWbYRUBuQ=NMnHAGmizTaCEDyLhXpgfFWbYRUBur.get('skey').strip()
    NMnHAGmizTaCEDyLhXpgfFWbYRUBuK=NMnHAGmizTaCEDyLhXpgfFWbYRUBuJ.get('skey').strip()
    if NMnHAGmizTaCEDyLhXpgfFWbYRUBuQ!=NMnHAGmizTaCEDyLhXpgfFWbYRUBuK:
     fp.write(NMnHAGmizTaCEDyLhXpgfFWbYRUBuq)
     NMnHAGmizTaCEDyLhXpgfFWbYRUBuo+=1
     if NMnHAGmizTaCEDyLhXpgfFWbYRUBuo>=50:break
   fp.close()
  except:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBqO
 def dp_Search_History(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,args):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBuO=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.Load_Searched_List()
  for NMnHAGmizTaCEDyLhXpgfFWbYRUBud in NMnHAGmizTaCEDyLhXpgfFWbYRUBuO:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBux=NMnHAGmizTaCEDyLhXpgfFWbYRUBqw(urllib.parse.parse_qsl(NMnHAGmizTaCEDyLhXpgfFWbYRUBud))
   NMnHAGmizTaCEDyLhXpgfFWbYRUBue=NMnHAGmizTaCEDyLhXpgfFWbYRUBux.get('skey').strip()
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuw={'mode':'TOTAL_SEARCH','search_key':NMnHAGmizTaCEDyLhXpgfFWbYRUBue,}
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuV={'mode':'HISTORY_REMOVE','skey':NMnHAGmizTaCEDyLhXpgfFWbYRUBue,'delmode':'ONE',}
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuc=urllib.parse.urlencode(NMnHAGmizTaCEDyLhXpgfFWbYRUBuV)
   NMnHAGmizTaCEDyLhXpgfFWbYRUBut=[('선택된 검색어 ( %s ) 삭제'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBue),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBuc))]
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.add_dir(NMnHAGmizTaCEDyLhXpgfFWbYRUBue,sublabel='',img=NMnHAGmizTaCEDyLhXpgfFWbYRUBqO,infoLabels=NMnHAGmizTaCEDyLhXpgfFWbYRUBqO,isFolder=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd,params=NMnHAGmizTaCEDyLhXpgfFWbYRUBuw,ContextMenu=NMnHAGmizTaCEDyLhXpgfFWbYRUBut)
  NMnHAGmizTaCEDyLhXpgfFWbYRUBus={'plot':'검색목록 전체를 삭제합니다.'}
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrS='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  NMnHAGmizTaCEDyLhXpgfFWbYRUBuw={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  NMnHAGmizTaCEDyLhXpgfFWbYRUBuS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.add_dir(NMnHAGmizTaCEDyLhXpgfFWbYRUBrS,sublabel='',img=NMnHAGmizTaCEDyLhXpgfFWbYRUBuS,infoLabels=NMnHAGmizTaCEDyLhXpgfFWbYRUBus,isFolder=NMnHAGmizTaCEDyLhXpgfFWbYRUBqx,params=NMnHAGmizTaCEDyLhXpgfFWbYRUBuw,isLink=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd)
  xbmcplugin.endOfDirectory(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ._addon_handle,cacheToDisc=NMnHAGmizTaCEDyLhXpgfFWbYRUBqx)
 def Delete_History_List(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,NMnHAGmizTaCEDyLhXpgfFWbYRUBue,NMnHAGmizTaCEDyLhXpgfFWbYRUBuk):
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBuk=='ALL':
   try:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBrI=NMnHAGmizTaCEDyLhXpgfFWbYRUBrJ
    fp=NMnHAGmizTaCEDyLhXpgfFWbYRUBqV(NMnHAGmizTaCEDyLhXpgfFWbYRUBrI,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBqO
  else:
   try:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBrI=NMnHAGmizTaCEDyLhXpgfFWbYRUBrJ
    NMnHAGmizTaCEDyLhXpgfFWbYRUBrv=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.Load_Searched_List() 
    fp=NMnHAGmizTaCEDyLhXpgfFWbYRUBqV(NMnHAGmizTaCEDyLhXpgfFWbYRUBrI,'w',-1,'utf-8')
    for NMnHAGmizTaCEDyLhXpgfFWbYRUBuq in NMnHAGmizTaCEDyLhXpgfFWbYRUBrv:
     NMnHAGmizTaCEDyLhXpgfFWbYRUBuJ=NMnHAGmizTaCEDyLhXpgfFWbYRUBqw(urllib.parse.parse_qsl(NMnHAGmizTaCEDyLhXpgfFWbYRUBuq))
     NMnHAGmizTaCEDyLhXpgfFWbYRUBuI=NMnHAGmizTaCEDyLhXpgfFWbYRUBuJ.get('skey').strip()
     if NMnHAGmizTaCEDyLhXpgfFWbYRUBue!=NMnHAGmizTaCEDyLhXpgfFWbYRUBuI:
      fp.write(NMnHAGmizTaCEDyLhXpgfFWbYRUBuq)
    fp.close()
   except:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBqO
 def dp_History_Delete(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,args):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBue =args.get('skey') 
  NMnHAGmizTaCEDyLhXpgfFWbYRUBuk=args.get('delmode')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBre=xbmcgui.Dialog()
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBuk=='ALL':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuv=NMnHAGmizTaCEDyLhXpgfFWbYRUBre.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuv=NMnHAGmizTaCEDyLhXpgfFWbYRUBre.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBuv==NMnHAGmizTaCEDyLhXpgfFWbYRUBqx:sys.exit()
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.Delete_History_List(NMnHAGmizTaCEDyLhXpgfFWbYRUBue,NMnHAGmizTaCEDyLhXpgfFWbYRUBuk)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrt=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.get_settings_menubookmark()
  for NMnHAGmizTaCEDyLhXpgfFWbYRUBlr in NMnHAGmizTaCEDyLhXpgfFWbYRUBrl:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrS=NMnHAGmizTaCEDyLhXpgfFWbYRUBlr.get('title')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuS=''
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBlr.get('mode')=='MENU_BOOKMARK' and NMnHAGmizTaCEDyLhXpgfFWbYRUBrt==NMnHAGmizTaCEDyLhXpgfFWbYRUBqx:continue
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuw={'mode':NMnHAGmizTaCEDyLhXpgfFWbYRUBlr.get('mode')}
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBlr.get('mode')in['XXX','MENU_BOOKMARK']:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlu=NMnHAGmizTaCEDyLhXpgfFWbYRUBqx
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlo =NMnHAGmizTaCEDyLhXpgfFWbYRUBqd
   else:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlu=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlo =NMnHAGmizTaCEDyLhXpgfFWbYRUBqx
   if 'icon' in NMnHAGmizTaCEDyLhXpgfFWbYRUBlr:NMnHAGmizTaCEDyLhXpgfFWbYRUBuS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',NMnHAGmizTaCEDyLhXpgfFWbYRUBlr.get('icon')) 
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.add_dir(NMnHAGmizTaCEDyLhXpgfFWbYRUBrS,sublabel='',img=NMnHAGmizTaCEDyLhXpgfFWbYRUBuS,infoLabels=NMnHAGmizTaCEDyLhXpgfFWbYRUBqO,isFolder=NMnHAGmizTaCEDyLhXpgfFWbYRUBlu,params=NMnHAGmizTaCEDyLhXpgfFWbYRUBuw,isLink=NMnHAGmizTaCEDyLhXpgfFWbYRUBlo)
  xbmcplugin.endOfDirectory(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ._addon_handle,cacheToDisc=NMnHAGmizTaCEDyLhXpgfFWbYRUBqx)
 def option_check(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrj=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.get_settings_select_info()
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBqc(NMnHAGmizTaCEDyLhXpgfFWbYRUBrj)==0:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBre=xbmcgui.Dialog()
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuv=NMnHAGmizTaCEDyLhXpgfFWbYRUBre.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBuv==NMnHAGmizTaCEDyLhXpgfFWbYRUBqd:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in NMnHAGmizTaCEDyLhXpgfFWbYRUBrj:
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.NF_cookiefile_check()==NMnHAGmizTaCEDyLhXpgfFWbYRUBqx:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.NF_login(showMessage=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd)
 def NF_cookiefile_check(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlJ={}
  try: 
   fp=NMnHAGmizTaCEDyLhXpgfFWbYRUBqV(NMnHAGmizTaCEDyLhXpgfFWbYRUBrq,'r',-1,'utf-8')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBlJ= json.load(fp)
   fp.close()
  except NMnHAGmizTaCEDyLhXpgfFWbYRUBqt as exception:
   return NMnHAGmizTaCEDyLhXpgfFWbYRUBqx
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF=NMnHAGmizTaCEDyLhXpgfFWbYRUBlJ
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlQ=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF_CookieFile_Load(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF_ORIGINAL_COOKIE)
  if(NMnHAGmizTaCEDyLhXpgfFWbYRUBlQ['NetflixId']!=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF['COOKIES']['NetflixId']or NMnHAGmizTaCEDyLhXpgfFWbYRUBlQ['SecureNetflixId']!=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF['COOKIES']['SecureNetflixId']or NMnHAGmizTaCEDyLhXpgfFWbYRUBlQ['flwssn']!=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF['COOKIES']['flwssn']or NMnHAGmizTaCEDyLhXpgfFWbYRUBlQ['memclid']!=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF['COOKIES']['memclid']or NMnHAGmizTaCEDyLhXpgfFWbYRUBlQ['nfvdid']!=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF['COOKIES']['nfvdid']):
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.Init_NF_Total()
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.NF_login(showMessage=NMnHAGmizTaCEDyLhXpgfFWbYRUBqx)==NMnHAGmizTaCEDyLhXpgfFWbYRUBqx:
    return NMnHAGmizTaCEDyLhXpgfFWbYRUBqx
  return NMnHAGmizTaCEDyLhXpgfFWbYRUBqd
 def NF_login(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,showMessage=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd):
  if showMessage:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBre=xbmcgui.Dialog()
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuv=NMnHAGmizTaCEDyLhXpgfFWbYRUBre.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBuv==NMnHAGmizTaCEDyLhXpgfFWbYRUBqx:
    return NMnHAGmizTaCEDyLhXpgfFWbYRUBqx 
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF['COOKIES']=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF_CookieFile_Load(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF_ORIGINAL_COOKIE)
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlK=NMnHAGmizTaCEDyLhXpgfFWbYRUBqx if NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF['COOKIES']=={}else NMnHAGmizTaCEDyLhXpgfFWbYRUBqd
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBlK:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_log('pass1 ok!')
  else:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_log('pass1 error!')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_noti(__language__(30905).encode('utf-8'))
   return NMnHAGmizTaCEDyLhXpgfFWbYRUBqx 
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlK=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF_Get_BaseSession()
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBlK:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_log('pass2 ok!')
  else:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_log('pass2 error!')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_noti(__language__(30905).encode('utf-8'))
   return NMnHAGmizTaCEDyLhXpgfFWbYRUBqx 
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlO =NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.Get_Now_Datetime()
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF['SESSION']['limitdate']=NMnHAGmizTaCEDyLhXpgfFWbYRUBlO.strftime('%Y-%m-%d')
  try: 
   fp=NMnHAGmizTaCEDyLhXpgfFWbYRUBqV(NMnHAGmizTaCEDyLhXpgfFWbYRUBrq,'w',-1,'utf-8')
   json.dump(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF,fp,indent=4,ensure_ascii=NMnHAGmizTaCEDyLhXpgfFWbYRUBqx)
   fp.close()
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_log('pass3 save ok!')
  except NMnHAGmizTaCEDyLhXpgfFWbYRUBqt as exception:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_log('pass3 save error!')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_noti(__language__(30905).encode('utf-8'))
   return NMnHAGmizTaCEDyLhXpgfFWbYRUBqx
  if showMessage:NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_noti(__language__(30904).encode('utf-8'))
  return NMnHAGmizTaCEDyLhXpgfFWbYRUBqd
 def NF_logout(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBre=xbmcgui.Dialog()
  NMnHAGmizTaCEDyLhXpgfFWbYRUBuv=NMnHAGmizTaCEDyLhXpgfFWbYRUBre.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBuv==NMnHAGmizTaCEDyLhXpgfFWbYRUBqx:return 
  if os.path.isfile(NMnHAGmizTaCEDyLhXpgfFWbYRUBrq):os.remove(NMnHAGmizTaCEDyLhXpgfFWbYRUBrq)
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,NMnHAGmizTaCEDyLhXpgfFWbYRUBlc):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlx=''
  NMnHAGmizTaCEDyLhXpgfFWbYRUBle=7
  try:
   for i in NMnHAGmizTaCEDyLhXpgfFWbYRUBqj(NMnHAGmizTaCEDyLhXpgfFWbYRUBqc(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc)):
    if i>=NMnHAGmizTaCEDyLhXpgfFWbYRUBle:
     NMnHAGmizTaCEDyLhXpgfFWbYRUBlx=NMnHAGmizTaCEDyLhXpgfFWbYRUBlx+'...'
     break
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlx=NMnHAGmizTaCEDyLhXpgfFWbYRUBlx+NMnHAGmizTaCEDyLhXpgfFWbYRUBlc[i]['title']+'\n'
  except:
   return ''
  return NMnHAGmizTaCEDyLhXpgfFWbYRUBlx
 def dp_Search_Group(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,args):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrj =NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.get_settings_select_info()
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlw=[]
  if 'search_key' in args:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBlV=args.get('search_key')
  else:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBlV=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not NMnHAGmizTaCEDyLhXpgfFWbYRUBlV:
    return
  if 'wavve' in NMnHAGmizTaCEDyLhXpgfFWbYRUBrj:
   (NMnHAGmizTaCEDyLhXpgfFWbYRUBlc,NMnHAGmizTaCEDyLhXpgfFWbYRUBlt)=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.Get_Search_Wavve(NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,'TVSHOW',1)
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBqc(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc)>0:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlj={'sType':'wavve_tvshow','sList':NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.MakeText_FreeList(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc),}
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlw.append(NMnHAGmizTaCEDyLhXpgfFWbYRUBlj)
   (NMnHAGmizTaCEDyLhXpgfFWbYRUBlc,NMnHAGmizTaCEDyLhXpgfFWbYRUBlt)=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.Get_Search_Wavve(NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,'MOVIE',1)
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBqc(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc)>0:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlj={'sType':'wavve_movie','sList':NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.MakeText_FreeList(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc),}
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlw.append(NMnHAGmizTaCEDyLhXpgfFWbYRUBlj)
  if 'tving' in NMnHAGmizTaCEDyLhXpgfFWbYRUBrj:
   (NMnHAGmizTaCEDyLhXpgfFWbYRUBlc,NMnHAGmizTaCEDyLhXpgfFWbYRUBlt)=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.Get_Search_Tving(NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,'TVSHOW',1)
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBqc(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc)>0:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlj={'sType':'tving_tvshow','sList':NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.MakeText_FreeList(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc),}
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlw.append(NMnHAGmizTaCEDyLhXpgfFWbYRUBlj)
   (NMnHAGmizTaCEDyLhXpgfFWbYRUBlc,NMnHAGmizTaCEDyLhXpgfFWbYRUBlt)=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.Get_Search_Tving(NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,'MOVIE',1)
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBqc(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc)>0:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlj={'sType':'tving_movie','sList':NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.MakeText_FreeList(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc),}
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlw.append(NMnHAGmizTaCEDyLhXpgfFWbYRUBlj)
  if 'watcha' in NMnHAGmizTaCEDyLhXpgfFWbYRUBrj:
   (NMnHAGmizTaCEDyLhXpgfFWbYRUBlc,NMnHAGmizTaCEDyLhXpgfFWbYRUBlt)=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.Get_Search_Watcha(NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,1)
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBqc(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc)>0:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlj={'sType':'watcha_list','sList':NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.MakeText_FreeList(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc),}
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlw.append(NMnHAGmizTaCEDyLhXpgfFWbYRUBlj)
  if 'coupang' in NMnHAGmizTaCEDyLhXpgfFWbYRUBrj:
   (NMnHAGmizTaCEDyLhXpgfFWbYRUBlc,NMnHAGmizTaCEDyLhXpgfFWbYRUBlt)=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.Get_Search_Coupang(NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,1)
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBqc(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc)>0:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlj={'sType':'coupang_list','sList':NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.MakeText_FreeList(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc),}
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlw.append(NMnHAGmizTaCEDyLhXpgfFWbYRUBlj)
  if 'netflix' in NMnHAGmizTaCEDyLhXpgfFWbYRUBrj:
   try:
    (NMnHAGmizTaCEDyLhXpgfFWbYRUBlc,NMnHAGmizTaCEDyLhXpgfFWbYRUBlt,NMnHAGmizTaCEDyLhXpgfFWbYRUBls)=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.Get_Search_Netflix(NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,1)
   except:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlc=[]
    NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_noti(__language__(30919).encode('utf8'))
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBqc(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc)>0:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlj={'sType':'netflix_list','sList':NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.MakeText_FreeList(NMnHAGmizTaCEDyLhXpgfFWbYRUBlc),}
    NMnHAGmizTaCEDyLhXpgfFWbYRUBlw.append(NMnHAGmizTaCEDyLhXpgfFWbYRUBlj)
  for NMnHAGmizTaCEDyLhXpgfFWbYRUBlS in NMnHAGmizTaCEDyLhXpgfFWbYRUBlw:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBlP=NMnHAGmizTaCEDyLhXpgfFWbYRUBro[NMnHAGmizTaCEDyLhXpgfFWbYRUBlS.get('sType')]
   NMnHAGmizTaCEDyLhXpgfFWbYRUBlI={'plot':'검색어 : '+NMnHAGmizTaCEDyLhXpgfFWbYRUBlV+'\n\n'+NMnHAGmizTaCEDyLhXpgfFWbYRUBlS.get('sList')}
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrS=NMnHAGmizTaCEDyLhXpgfFWbYRUBlP.get('title')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuw={'mode':NMnHAGmizTaCEDyLhXpgfFWbYRUBlP.get('mode'),'ott':NMnHAGmizTaCEDyLhXpgfFWbYRUBlP.get('ott'),'vidtype':NMnHAGmizTaCEDyLhXpgfFWbYRUBlP.get('vidtype'),'search_key':NMnHAGmizTaCEDyLhXpgfFWbYRUBlV}
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBlP.get('ott')=='netflix':
    NMnHAGmizTaCEDyLhXpgfFWbYRUBuw['page'] ='1'
    NMnHAGmizTaCEDyLhXpgfFWbYRUBuw['byReference']='-'
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',NMnHAGmizTaCEDyLhXpgfFWbYRUBlP.get('icon'))
   NMnHAGmizTaCEDyLhXpgfFWbYRUBlu=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd if NMnHAGmizTaCEDyLhXpgfFWbYRUBlP.get('mode')!='HYPER_LINK' else NMnHAGmizTaCEDyLhXpgfFWbYRUBqx
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.add_dir(NMnHAGmizTaCEDyLhXpgfFWbYRUBrS,sublabel='',img=NMnHAGmizTaCEDyLhXpgfFWbYRUBuS,infoLabels=NMnHAGmizTaCEDyLhXpgfFWbYRUBlI,isFolder=NMnHAGmizTaCEDyLhXpgfFWbYRUBlu,params=NMnHAGmizTaCEDyLhXpgfFWbYRUBuw,isLink=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd)
  xbmcplugin.endOfDirectory(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ._addon_handle)
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.Save_Searched_List(NMnHAGmizTaCEDyLhXpgfFWbYRUBlV)
 def dp_Hyper_Link(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,args):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlk =args.get('mode')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlv =args.get('ott')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBor =args.get('vidtype')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlV=args.get('search_key')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBou='-'
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBlv=='wavve':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBol={'mode':'LOCAL_SEARCH','sType':'movie' if NMnHAGmizTaCEDyLhXpgfFWbYRUBor=='MOVIE' else 'vod','search_key':NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,'page':'1',}
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoq=urllib.parse.urlencode(NMnHAGmizTaCEDyLhXpgfFWbYRUBol)
   NMnHAGmizTaCEDyLhXpgfFWbYRUBou='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBoq)
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlv=='tving':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBol={'mode':'LOCAL_SEARCH','stype':'movie' if NMnHAGmizTaCEDyLhXpgfFWbYRUBor=='MOVIE' else 'vod','search_key':NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,'page':'1',}
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoq=urllib.parse.urlencode(NMnHAGmizTaCEDyLhXpgfFWbYRUBol)
   NMnHAGmizTaCEDyLhXpgfFWbYRUBou='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBoq)
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlv=='watcha':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBol={'mode':'LOCAL_SEARCH','search_key':NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,'page':'1',}
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoq=urllib.parse.urlencode(NMnHAGmizTaCEDyLhXpgfFWbYRUBol)
   NMnHAGmizTaCEDyLhXpgfFWbYRUBou='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBoq)
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlv=='coupang':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBol={'mode':'LOCAL_SEARCH','search_key':NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,'page':'1',}
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoq=urllib.parse.urlencode(NMnHAGmizTaCEDyLhXpgfFWbYRUBol)
   NMnHAGmizTaCEDyLhXpgfFWbYRUBou='ActivateWindow(10025,"plugin://plugin.video.coupangm/?%s",return)'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBoq)
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlv=='netflix':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoJ=args.get('videoid')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoQ=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.NF['SESSION']['nowGuid']
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBor=='TVSHOW':
    NMnHAGmizTaCEDyLhXpgfFWbYRUBou='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBoJ)
   else:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBou='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBoJ,NMnHAGmizTaCEDyLhXpgfFWbYRUBoQ)
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.addon_log('ott_url ==> ( '+NMnHAGmizTaCEDyLhXpgfFWbYRUBou+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(NMnHAGmizTaCEDyLhXpgfFWbYRUBou)
 def dp_Nf_Search(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,args):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBoK =NMnHAGmizTaCEDyLhXpgfFWbYRUBqs(args.get('page'))
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlV =args.get('search_key')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBls=args.get('byReference')
  (NMnHAGmizTaCEDyLhXpgfFWbYRUBlc,NMnHAGmizTaCEDyLhXpgfFWbYRUBlt,NMnHAGmizTaCEDyLhXpgfFWbYRUBls)=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.SearchObj.Get_Search_Netflix(NMnHAGmizTaCEDyLhXpgfFWbYRUBlV,NMnHAGmizTaCEDyLhXpgfFWbYRUBoK,byReference=NMnHAGmizTaCEDyLhXpgfFWbYRUBls)
  for NMnHAGmizTaCEDyLhXpgfFWbYRUBoO in NMnHAGmizTaCEDyLhXpgfFWbYRUBlc:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoJ =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('videoid')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBor =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('vidtype')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrS =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('title')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBod =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('mpaa')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBox =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('regularSynopsis')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoe =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('dpSupplemental')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBow=NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('sequiturEvidence')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoV =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('thumbnail')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoc =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('year')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBot =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('duration')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoj =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('info_genre')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBos =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('director')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoS =NMnHAGmizTaCEDyLhXpgfFWbYRUBoO.get('cast')
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBor=='movie':
    NMnHAGmizTaCEDyLhXpgfFWbYRUBuj=' (%s)'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBqS(NMnHAGmizTaCEDyLhXpgfFWbYRUBoc))
   else:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBuj=''
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoP=''
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBox:NMnHAGmizTaCEDyLhXpgfFWbYRUBoP=NMnHAGmizTaCEDyLhXpgfFWbYRUBoP+'\n\n'+NMnHAGmizTaCEDyLhXpgfFWbYRUBox
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBoe :NMnHAGmizTaCEDyLhXpgfFWbYRUBoP=NMnHAGmizTaCEDyLhXpgfFWbYRUBoP+'\n\n'+NMnHAGmizTaCEDyLhXpgfFWbYRUBoe
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBow:NMnHAGmizTaCEDyLhXpgfFWbYRUBoP=NMnHAGmizTaCEDyLhXpgfFWbYRUBoP+'\n\n'+NMnHAGmizTaCEDyLhXpgfFWbYRUBow
   NMnHAGmizTaCEDyLhXpgfFWbYRUBoP=NMnHAGmizTaCEDyLhXpgfFWbYRUBoP.strip()
   NMnHAGmizTaCEDyLhXpgfFWbYRUBus={'mediatype':'tvshow' if NMnHAGmizTaCEDyLhXpgfFWbYRUBor=='show' else 'movie','title':NMnHAGmizTaCEDyLhXpgfFWbYRUBrS,'mpaa':NMnHAGmizTaCEDyLhXpgfFWbYRUBod,'plot':NMnHAGmizTaCEDyLhXpgfFWbYRUBoP,'duration':NMnHAGmizTaCEDyLhXpgfFWbYRUBot,'genre':NMnHAGmizTaCEDyLhXpgfFWbYRUBoj,'director':NMnHAGmizTaCEDyLhXpgfFWbYRUBos,'cast':NMnHAGmizTaCEDyLhXpgfFWbYRUBoS,'year':NMnHAGmizTaCEDyLhXpgfFWbYRUBoc,}
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuw={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if NMnHAGmizTaCEDyLhXpgfFWbYRUBor=='show' else 'MOVIE','videoid':NMnHAGmizTaCEDyLhXpgfFWbYRUBoJ,}
   if NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.get_settings_makebookmark():
    NMnHAGmizTaCEDyLhXpgfFWbYRUBoI={'videoid':NMnHAGmizTaCEDyLhXpgfFWbYRUBoJ,'vidtype':'tvshow' if NMnHAGmizTaCEDyLhXpgfFWbYRUBor=='show' else 'movie','vtitle':NMnHAGmizTaCEDyLhXpgfFWbYRUBrS+NMnHAGmizTaCEDyLhXpgfFWbYRUBuj,'vsubtitle':'','vinfo':NMnHAGmizTaCEDyLhXpgfFWbYRUBus,'thumbnail':NMnHAGmizTaCEDyLhXpgfFWbYRUBoV,}
    NMnHAGmizTaCEDyLhXpgfFWbYRUBok=json.dumps(NMnHAGmizTaCEDyLhXpgfFWbYRUBoI)
    NMnHAGmizTaCEDyLhXpgfFWbYRUBok=urllib.parse.quote(NMnHAGmizTaCEDyLhXpgfFWbYRUBok)
    NMnHAGmizTaCEDyLhXpgfFWbYRUBov='RunPlugin(plugin://plugin.video.searchm/?mode=SET_BOOKMARK&bm_param=%s)'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBok)
    NMnHAGmizTaCEDyLhXpgfFWbYRUBut=[('(통합) 찜 영상에 추가',NMnHAGmizTaCEDyLhXpgfFWbYRUBov)]
   else:
    NMnHAGmizTaCEDyLhXpgfFWbYRUBut=NMnHAGmizTaCEDyLhXpgfFWbYRUBqO
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.add_dir(NMnHAGmizTaCEDyLhXpgfFWbYRUBrS+NMnHAGmizTaCEDyLhXpgfFWbYRUBuj,sublabel=NMnHAGmizTaCEDyLhXpgfFWbYRUBqO,img=NMnHAGmizTaCEDyLhXpgfFWbYRUBoV,infoLabels=NMnHAGmizTaCEDyLhXpgfFWbYRUBus,isFolder=NMnHAGmizTaCEDyLhXpgfFWbYRUBqx,params=NMnHAGmizTaCEDyLhXpgfFWbYRUBuw,isLink=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd,ContextMenu=NMnHAGmizTaCEDyLhXpgfFWbYRUBut)
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBlt:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuw={}
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuw['mode'] ='NF_SEARCH' 
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuw['page'] =NMnHAGmizTaCEDyLhXpgfFWbYRUBqS(NMnHAGmizTaCEDyLhXpgfFWbYRUBoK+1)
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuw['search_key']=NMnHAGmizTaCEDyLhXpgfFWbYRUBlV
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuw['byReference']=NMnHAGmizTaCEDyLhXpgfFWbYRUBls
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrS='[B]%s >>[/B]'%'다음 페이지'
   NMnHAGmizTaCEDyLhXpgfFWbYRUBqr=NMnHAGmizTaCEDyLhXpgfFWbYRUBqS(NMnHAGmizTaCEDyLhXpgfFWbYRUBoK+1)
   NMnHAGmizTaCEDyLhXpgfFWbYRUBuS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.add_dir(NMnHAGmizTaCEDyLhXpgfFWbYRUBrS,sublabel=NMnHAGmizTaCEDyLhXpgfFWbYRUBqr,img=NMnHAGmizTaCEDyLhXpgfFWbYRUBuS,infoLabels=NMnHAGmizTaCEDyLhXpgfFWbYRUBqO,isFolder=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd,params=NMnHAGmizTaCEDyLhXpgfFWbYRUBuw)
  xbmcplugin.setContent(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ._addon_handle,'movies')
  xbmcplugin.endOfDirectory(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ._addon_handle)
 def dp_Bookmark_Menu(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,args):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBou='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(NMnHAGmizTaCEDyLhXpgfFWbYRUBou)
 def dp_Set_Bookmark(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ,args):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBqu=urllib.parse.unquote(args.get('bm_param'))
  NMnHAGmizTaCEDyLhXpgfFWbYRUBqu=json.loads(NMnHAGmizTaCEDyLhXpgfFWbYRUBqu)
  NMnHAGmizTaCEDyLhXpgfFWbYRUBoJ =NMnHAGmizTaCEDyLhXpgfFWbYRUBqu.get('videoid')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBor =NMnHAGmizTaCEDyLhXpgfFWbYRUBqu.get('vidtype')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBql =NMnHAGmizTaCEDyLhXpgfFWbYRUBqu.get('vtitle')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBqo =NMnHAGmizTaCEDyLhXpgfFWbYRUBqu.get('vsubtitle')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBqJ =NMnHAGmizTaCEDyLhXpgfFWbYRUBqu.get('vinfo')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBoV =NMnHAGmizTaCEDyLhXpgfFWbYRUBqu.get('thumbnail')
  NMnHAGmizTaCEDyLhXpgfFWbYRUBre=xbmcgui.Dialog()
  NMnHAGmizTaCEDyLhXpgfFWbYRUBuv=NMnHAGmizTaCEDyLhXpgfFWbYRUBre.yesno(__language__(30917).encode('utf8'),NMnHAGmizTaCEDyLhXpgfFWbYRUBql+' \n\n'+__language__(30918))
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBuv==NMnHAGmizTaCEDyLhXpgfFWbYRUBqx:return
  NMnHAGmizTaCEDyLhXpgfFWbYRUBqQ={'indexinfo':{'ott':'netflix','videoid':NMnHAGmizTaCEDyLhXpgfFWbYRUBoJ,'vidtype':NMnHAGmizTaCEDyLhXpgfFWbYRUBor,},'saveinfo':{'title':NMnHAGmizTaCEDyLhXpgfFWbYRUBql,'subtitle':NMnHAGmizTaCEDyLhXpgfFWbYRUBqo,'thumbnail':NMnHAGmizTaCEDyLhXpgfFWbYRUBoV,'infoLabels':NMnHAGmizTaCEDyLhXpgfFWbYRUBqJ,},}
  NMnHAGmizTaCEDyLhXpgfFWbYRUBok=json.dumps(NMnHAGmizTaCEDyLhXpgfFWbYRUBqQ)
  NMnHAGmizTaCEDyLhXpgfFWbYRUBok=urllib.parse.quote(NMnHAGmizTaCEDyLhXpgfFWbYRUBok)
  NMnHAGmizTaCEDyLhXpgfFWbYRUBov='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(NMnHAGmizTaCEDyLhXpgfFWbYRUBok)
  xbmc.executebuiltin(NMnHAGmizTaCEDyLhXpgfFWbYRUBov)
 def search_main(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ):
  NMnHAGmizTaCEDyLhXpgfFWbYRUBlk=NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.main_params.get('mode',NMnHAGmizTaCEDyLhXpgfFWbYRUBqO)
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBlk=='NFLOGOUT':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.NF_logout()
   return
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlk=='NFLOGIN':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.NF_login(showMessage=NMnHAGmizTaCEDyLhXpgfFWbYRUBqd)
   return
  NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.option_check()
  if NMnHAGmizTaCEDyLhXpgfFWbYRUBlk is NMnHAGmizTaCEDyLhXpgfFWbYRUBqO:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.dp_Main_List()
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlk=='TOTAL_SEARCH':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.dp_Search_Group(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.main_params)
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlk=='HYPER_LINK':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.dp_Hyper_Link(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.main_params)
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlk=='NF_SEARCH':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.dp_Nf_Search(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.main_params)
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlk=='TOTAL_HISTORY':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.dp_Search_History(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.main_params)
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlk=='HISTORY_REMOVE':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.dp_History_Delete(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.main_params)
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlk=='MENU_BOOKMARK':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.dp_Bookmark_Menu(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.main_params)
  elif NMnHAGmizTaCEDyLhXpgfFWbYRUBlk=='SET_BOOKMARK':
   NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.dp_Set_Bookmark(NMnHAGmizTaCEDyLhXpgfFWbYRUBrQ.main_params)
  else:
   NMnHAGmizTaCEDyLhXpgfFWbYRUBqO
# Created by pyminifier (https://github.com/liftoff/pyminifier)
