__author__="NightRain"
AoxeprEjqwcTLPNJIblDHkMOYsUFtf=object
AoxeprEjqwcTLPNJIblDHkMOYsUFth=None
AoxeprEjqwcTLPNJIblDHkMOYsUFti=False
AoxeprEjqwcTLPNJIblDHkMOYsUFtg=int
AoxeprEjqwcTLPNJIblDHkMOYsUFtB=str
AoxeprEjqwcTLPNJIblDHkMOYsUFtv=Exception
AoxeprEjqwcTLPNJIblDHkMOYsUFta=print
AoxeprEjqwcTLPNJIblDHkMOYsUFtC=True
AoxeprEjqwcTLPNJIblDHkMOYsUFtS=len
AoxeprEjqwcTLPNJIblDHkMOYsUFtd=open
AoxeprEjqwcTLPNJIblDHkMOYsUFtn=isinstance
AoxeprEjqwcTLPNJIblDHkMOYsUFtQ=list
AoxeprEjqwcTLPNJIblDHkMOYsUFtX=dict
AoxeprEjqwcTLPNJIblDHkMOYsUFtm=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
class AoxeprEjqwcTLPNJIblDHkMOYsUFWK(AoxeprEjqwcTLPNJIblDHkMOYsUFtf):
 def __init__(AoxeprEjqwcTLPNJIblDHkMOYsUFWR):
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.DEFAULT_HEADER ={'user-agent':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.USER_AGENT}
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_WAVVE ='https://apis.wavve.com'
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_TVING_SEARCH='https://search.tving.com'
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_TVING_IMG ='https://image.tving.com'
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_WATCHA ='https://api-mars.watcha.com'
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_NETFLIX ='https://www.netflix.com'
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_COUPANG ='https://discover.coupangstreaming.com'
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.WAVVE_LIMIT =20 
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.TVING_LIMIT =30
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.WATCHA_LIMIT =30
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_LIMIT =20 
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.COUPANG_LIMIT =10 
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.DERECTOR_LIMIT =4
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.CAST_LIMIT =10
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.GENRE_LIMIT =4
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.TVING_MOVIE_LITE=['2610061','2610161','261062']
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_HEADER={'user-agent':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND1 ='_342x192'
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND2 ='_665x375'
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_PORT ='_342x684'
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LOGO ='_550x124'
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF={}
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']={}
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']={}
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.CP_ORIGINAL_COOKIE =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_ORIGINAL_COOKIE =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_SESSION_COOKIES1 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_SESSION_COOKIES2 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_SESSION_COOKIES3 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_SESSION_COOKIES4 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_SESSION_FULLTEXT1 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_SESSION_FULLTEXT2 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_SESSION_FULLTEXT3 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_SESSION_FULLTEXT4 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_CONTEXTJSON_FILE1 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_CONTEXTJSON_FILE2 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_CONTEXTJSON_FILE3 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_CONTEXTJSON_FILE4 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_FALCORJSON_FILE1 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_FALCORJSON_FILE2 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_FALCORJSON_FILE3 =''
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_FALCORJSON_FILE4 =''
 def callRequestCookies(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,jobtype,AoxeprEjqwcTLPNJIblDHkMOYsUFWi,payload=AoxeprEjqwcTLPNJIblDHkMOYsUFth,params=AoxeprEjqwcTLPNJIblDHkMOYsUFth,headers=AoxeprEjqwcTLPNJIblDHkMOYsUFth,cookies=AoxeprEjqwcTLPNJIblDHkMOYsUFth,redirects=AoxeprEjqwcTLPNJIblDHkMOYsUFti):
  AoxeprEjqwcTLPNJIblDHkMOYsUFWz=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.DEFAULT_HEADER
  if headers:AoxeprEjqwcTLPNJIblDHkMOYsUFWz.update(headers)
  if jobtype=='Get':
   AoxeprEjqwcTLPNJIblDHkMOYsUFWt=requests.get(AoxeprEjqwcTLPNJIblDHkMOYsUFWi,params=params,headers=AoxeprEjqwcTLPNJIblDHkMOYsUFWz,cookies=cookies,allow_redirects=redirects)
  else:
   AoxeprEjqwcTLPNJIblDHkMOYsUFWt=requests.post(AoxeprEjqwcTLPNJIblDHkMOYsUFWi,data=payload,params=params,headers=AoxeprEjqwcTLPNJIblDHkMOYsUFWz,cookies=cookies,allow_redirects=redirects)
  return AoxeprEjqwcTLPNJIblDHkMOYsUFWt
 def GetNoCache(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,timetype=1,minutes=0):
  if timetype==1:
   ts=AoxeprEjqwcTLPNJIblDHkMOYsUFtg(time.time())
   mi=AoxeprEjqwcTLPNJIblDHkMOYsUFtg(minutes*60)
  else:
   ts=AoxeprEjqwcTLPNJIblDHkMOYsUFtg(time.time()*1000)
   mi=AoxeprEjqwcTLPNJIblDHkMOYsUFtg(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(AoxeprEjqwcTLPNJIblDHkMOYsUFWR):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,search_key,sType,page_int):
  AoxeprEjqwcTLPNJIblDHkMOYsUFWG=[]
  AoxeprEjqwcTLPNJIblDHkMOYsUFWf=AoxeprEjqwcTLPNJIblDHkMOYsUFWV=1
  AoxeprEjqwcTLPNJIblDHkMOYsUFWh=AoxeprEjqwcTLPNJIblDHkMOYsUFti
  try:
   AoxeprEjqwcTLPNJIblDHkMOYsUFWi=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_WAVVE+'/cf/search/list.js'
   AoxeprEjqwcTLPNJIblDHkMOYsUFWg={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':AoxeprEjqwcTLPNJIblDHkMOYsUFtB((page_int-1)*AoxeprEjqwcTLPNJIblDHkMOYsUFWR.WAVVE_LIMIT),'limit':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.WAVVE_LIMIT,'orderby':'score'}
   AoxeprEjqwcTLPNJIblDHkMOYsUFWg.update(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.WAVVE_PARAMS)
   AoxeprEjqwcTLPNJIblDHkMOYsUFWB=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.callRequestCookies('Get',AoxeprEjqwcTLPNJIblDHkMOYsUFWi,payload=AoxeprEjqwcTLPNJIblDHkMOYsUFth,params=AoxeprEjqwcTLPNJIblDHkMOYsUFWg,headers=AoxeprEjqwcTLPNJIblDHkMOYsUFth,cookies=AoxeprEjqwcTLPNJIblDHkMOYsUFth)
   AoxeprEjqwcTLPNJIblDHkMOYsUFWv=json.loads(AoxeprEjqwcTLPNJIblDHkMOYsUFWB.text)
   if not('celllist' in AoxeprEjqwcTLPNJIblDHkMOYsUFWv['cell_toplist']):return AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh
   AoxeprEjqwcTLPNJIblDHkMOYsUFWa=AoxeprEjqwcTLPNJIblDHkMOYsUFWv['cell_toplist']['celllist']
   for AoxeprEjqwcTLPNJIblDHkMOYsUFWC in AoxeprEjqwcTLPNJIblDHkMOYsUFWa:
    AoxeprEjqwcTLPNJIblDHkMOYsUFWS =AoxeprEjqwcTLPNJIblDHkMOYsUFWC['event_list'][1]['url']
    AoxeprEjqwcTLPNJIblDHkMOYsUFWd=urllib.parse.urlsplit(AoxeprEjqwcTLPNJIblDHkMOYsUFWS).query
    AoxeprEjqwcTLPNJIblDHkMOYsUFWn=AoxeprEjqwcTLPNJIblDHkMOYsUFWd[0:AoxeprEjqwcTLPNJIblDHkMOYsUFWd.find('=')]
    AoxeprEjqwcTLPNJIblDHkMOYsUFWQ=AoxeprEjqwcTLPNJIblDHkMOYsUFWd[AoxeprEjqwcTLPNJIblDHkMOYsUFWd.find('=')+1:]
    AoxeprEjqwcTLPNJIblDHkMOYsUFWn='TVSHOW' if AoxeprEjqwcTLPNJIblDHkMOYsUFWn=='programid' else 'MOVIE' 
    AoxeprEjqwcTLPNJIblDHkMOYsUFWX=AoxeprEjqwcTLPNJIblDHkMOYsUFWC['title_list'][0]['text']
    AoxeprEjqwcTLPNJIblDHkMOYsUFWm =AoxeprEjqwcTLPNJIblDHkMOYsUFWC['age']
    AoxeprEjqwcTLPNJIblDHkMOYsUFWy={'title':AoxeprEjqwcTLPNJIblDHkMOYsUFWX}
    if AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('age')!='21':
     AoxeprEjqwcTLPNJIblDHkMOYsUFWG.append(AoxeprEjqwcTLPNJIblDHkMOYsUFWy)
   AoxeprEjqwcTLPNJIblDHkMOYsUFWf=AoxeprEjqwcTLPNJIblDHkMOYsUFtg(AoxeprEjqwcTLPNJIblDHkMOYsUFWv['cell_toplist']['pagecount'])
   if AoxeprEjqwcTLPNJIblDHkMOYsUFWv['cell_toplist']['count']:AoxeprEjqwcTLPNJIblDHkMOYsUFWV =AoxeprEjqwcTLPNJIblDHkMOYsUFtg(AoxeprEjqwcTLPNJIblDHkMOYsUFWv['cell_toplist']['count'])
   else:AoxeprEjqwcTLPNJIblDHkMOYsUFWV=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.LIST_LIMIT
   AoxeprEjqwcTLPNJIblDHkMOYsUFWh=AoxeprEjqwcTLPNJIblDHkMOYsUFWf>AoxeprEjqwcTLPNJIblDHkMOYsUFWV
  except AoxeprEjqwcTLPNJIblDHkMOYsUFtv as exception:
   AoxeprEjqwcTLPNJIblDHkMOYsUFta(exception)
  return AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh 
 def Get_Search_Tving(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,search_key,sType,page_int):
  AoxeprEjqwcTLPNJIblDHkMOYsUFWG=[]
  AoxeprEjqwcTLPNJIblDHkMOYsUFWh=AoxeprEjqwcTLPNJIblDHkMOYsUFti
  try:
   AoxeprEjqwcTLPNJIblDHkMOYsUFKW ='/search/getSearch.jsp'
   AoxeprEjqwcTLPNJIblDHkMOYsUFKR={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':AoxeprEjqwcTLPNJIblDHkMOYsUFtB(page_int),'pageSize':AoxeprEjqwcTLPNJIblDHkMOYsUFtB(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.TVING_PARMAS.get('SCREENCODE'),'os':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.TVING_PARMAS.get('OSCODE'),'network':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':AoxeprEjqwcTLPNJIblDHkMOYsUFtB(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':AoxeprEjqwcTLPNJIblDHkMOYsUFtB(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':AoxeprEjqwcTLPNJIblDHkMOYsUFtB(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.GetNoCache(2))}
   AoxeprEjqwcTLPNJIblDHkMOYsUFWi=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_TVING_SEARCH+AoxeprEjqwcTLPNJIblDHkMOYsUFKW
   AoxeprEjqwcTLPNJIblDHkMOYsUFWB=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.callRequestCookies('Get',AoxeprEjqwcTLPNJIblDHkMOYsUFWi,payload=AoxeprEjqwcTLPNJIblDHkMOYsUFth,params=AoxeprEjqwcTLPNJIblDHkMOYsUFKR,headers=AoxeprEjqwcTLPNJIblDHkMOYsUFth,cookies=AoxeprEjqwcTLPNJIblDHkMOYsUFth)
   AoxeprEjqwcTLPNJIblDHkMOYsUFKz=json.loads(AoxeprEjqwcTLPNJIblDHkMOYsUFWB.text)
   if sType=='TVSHOW':
    if not('programRsb' in AoxeprEjqwcTLPNJIblDHkMOYsUFKz):return AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh
    AoxeprEjqwcTLPNJIblDHkMOYsUFKt=AoxeprEjqwcTLPNJIblDHkMOYsUFKz['programRsb']['dataList']
    AoxeprEjqwcTLPNJIblDHkMOYsUFKu =AoxeprEjqwcTLPNJIblDHkMOYsUFtg(AoxeprEjqwcTLPNJIblDHkMOYsUFKz['programRsb']['count'])
    for AoxeprEjqwcTLPNJIblDHkMOYsUFWC in AoxeprEjqwcTLPNJIblDHkMOYsUFKt:
     AoxeprEjqwcTLPNJIblDHkMOYsUFKG=AoxeprEjqwcTLPNJIblDHkMOYsUFWC['mast_cd']
     AoxeprEjqwcTLPNJIblDHkMOYsUFWX =AoxeprEjqwcTLPNJIblDHkMOYsUFWC['mast_nm']
     AoxeprEjqwcTLPNJIblDHkMOYsUFKf=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_TVING_IMG+AoxeprEjqwcTLPNJIblDHkMOYsUFWC['web_url4']
     AoxeprEjqwcTLPNJIblDHkMOYsUFKh =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_TVING_IMG+AoxeprEjqwcTLPNJIblDHkMOYsUFWC['web_url']
     try:
      AoxeprEjqwcTLPNJIblDHkMOYsUFKi =[]
      AoxeprEjqwcTLPNJIblDHkMOYsUFKg=[]
      AoxeprEjqwcTLPNJIblDHkMOYsUFKB =[]
      AoxeprEjqwcTLPNJIblDHkMOYsUFKv =0
      AoxeprEjqwcTLPNJIblDHkMOYsUFKa =''
      AoxeprEjqwcTLPNJIblDHkMOYsUFKC =''
      AoxeprEjqwcTLPNJIblDHkMOYsUFKS =''
      if AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('actor') !='' and AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('actor') !='-':AoxeprEjqwcTLPNJIblDHkMOYsUFKi =AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('actor').split(',')
      if AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('director')!='' and AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('director')!='-':AoxeprEjqwcTLPNJIblDHkMOYsUFKg=AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('director').split(',')
      if AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('cate_nm')!='' and AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('cate_nm')!='-':AoxeprEjqwcTLPNJIblDHkMOYsUFKB =AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('cate_nm').split('/')
      if 'targetage' in AoxeprEjqwcTLPNJIblDHkMOYsUFWC:AoxeprEjqwcTLPNJIblDHkMOYsUFKa=AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('targetage')
      if 'broad_dt' in AoxeprEjqwcTLPNJIblDHkMOYsUFWC:
       AoxeprEjqwcTLPNJIblDHkMOYsUFKd=AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('broad_dt')
       AoxeprEjqwcTLPNJIblDHkMOYsUFKS='%s-%s-%s'%(AoxeprEjqwcTLPNJIblDHkMOYsUFKd[:4],AoxeprEjqwcTLPNJIblDHkMOYsUFKd[4:6],AoxeprEjqwcTLPNJIblDHkMOYsUFKd[6:])
       AoxeprEjqwcTLPNJIblDHkMOYsUFKC =AoxeprEjqwcTLPNJIblDHkMOYsUFKd[:4]
     except:
      AoxeprEjqwcTLPNJIblDHkMOYsUFth
     AoxeprEjqwcTLPNJIblDHkMOYsUFWy={'title':AoxeprEjqwcTLPNJIblDHkMOYsUFWX,}
     AoxeprEjqwcTLPNJIblDHkMOYsUFWG.append(AoxeprEjqwcTLPNJIblDHkMOYsUFWy)
   else:
    if not('vodMVRsb' in AoxeprEjqwcTLPNJIblDHkMOYsUFKz):return AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh
    AoxeprEjqwcTLPNJIblDHkMOYsUFKn=AoxeprEjqwcTLPNJIblDHkMOYsUFKz['vodMVRsb']['dataList']
    AoxeprEjqwcTLPNJIblDHkMOYsUFKu =AoxeprEjqwcTLPNJIblDHkMOYsUFtg(AoxeprEjqwcTLPNJIblDHkMOYsUFKz['vodMVRsb']['count'])
    AoxeprEjqwcTLPNJIblDHkMOYsUFta(AoxeprEjqwcTLPNJIblDHkMOYsUFKu)
    for AoxeprEjqwcTLPNJIblDHkMOYsUFWC in AoxeprEjqwcTLPNJIblDHkMOYsUFKn:
     AoxeprEjqwcTLPNJIblDHkMOYsUFKG=AoxeprEjqwcTLPNJIblDHkMOYsUFWC['mast_cd']
     AoxeprEjqwcTLPNJIblDHkMOYsUFWX =AoxeprEjqwcTLPNJIblDHkMOYsUFWC['mast_nm'].strip()
     AoxeprEjqwcTLPNJIblDHkMOYsUFKf =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_TVING_IMG+AoxeprEjqwcTLPNJIblDHkMOYsUFWC['web_url']
     AoxeprEjqwcTLPNJIblDHkMOYsUFKh =AoxeprEjqwcTLPNJIblDHkMOYsUFKf
     AoxeprEjqwcTLPNJIblDHkMOYsUFKQ=''
     try:
      AoxeprEjqwcTLPNJIblDHkMOYsUFKi =[]
      AoxeprEjqwcTLPNJIblDHkMOYsUFKg=[]
      AoxeprEjqwcTLPNJIblDHkMOYsUFKB =[]
      AoxeprEjqwcTLPNJIblDHkMOYsUFKv =0
      AoxeprEjqwcTLPNJIblDHkMOYsUFKa =''
      AoxeprEjqwcTLPNJIblDHkMOYsUFKC =''
      AoxeprEjqwcTLPNJIblDHkMOYsUFKS =''
      if AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('actor') !='' and AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('actor') !='-':AoxeprEjqwcTLPNJIblDHkMOYsUFKi =AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('actor').split(',')
      if AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('director')!='' and AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('director')!='-':AoxeprEjqwcTLPNJIblDHkMOYsUFKg=AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('director').split(',')
      if AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('cate_nm')!='' and AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('cate_nm')!='-':AoxeprEjqwcTLPNJIblDHkMOYsUFKB =AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('cate_nm').split('/')
      if AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('runtime_sec')!='':AoxeprEjqwcTLPNJIblDHkMOYsUFKv=AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('runtime_sec')
      if 'grade_nm' in AoxeprEjqwcTLPNJIblDHkMOYsUFWC:AoxeprEjqwcTLPNJIblDHkMOYsUFKa=AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('grade_nm')
      AoxeprEjqwcTLPNJIblDHkMOYsUFKX=''
      AoxeprEjqwcTLPNJIblDHkMOYsUFKd=AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('broad_dt')
      if AoxeprEjqwcTLPNJIblDHkMOYsUFKX!='':
       AoxeprEjqwcTLPNJIblDHkMOYsUFKS='%s-%s-%s'%(AoxeprEjqwcTLPNJIblDHkMOYsUFKd[:4],AoxeprEjqwcTLPNJIblDHkMOYsUFKd[4:6],AoxeprEjqwcTLPNJIblDHkMOYsUFKd[6:])
       AoxeprEjqwcTLPNJIblDHkMOYsUFKC =AoxeprEjqwcTLPNJIblDHkMOYsUFKd[:4]
     except:
      AoxeprEjqwcTLPNJIblDHkMOYsUFth
     AoxeprEjqwcTLPNJIblDHkMOYsUFWy={'title':AoxeprEjqwcTLPNJIblDHkMOYsUFWX,}
     AoxeprEjqwcTLPNJIblDHkMOYsUFKm=AoxeprEjqwcTLPNJIblDHkMOYsUFti
     for AoxeprEjqwcTLPNJIblDHkMOYsUFKy in AoxeprEjqwcTLPNJIblDHkMOYsUFWC['bill']:
      if AoxeprEjqwcTLPNJIblDHkMOYsUFKy in AoxeprEjqwcTLPNJIblDHkMOYsUFWR.TVING_MOVIE_LITE:
       AoxeprEjqwcTLPNJIblDHkMOYsUFKm=AoxeprEjqwcTLPNJIblDHkMOYsUFtC
       break
     if AoxeprEjqwcTLPNJIblDHkMOYsUFKm==AoxeprEjqwcTLPNJIblDHkMOYsUFti: 
      AoxeprEjqwcTLPNJIblDHkMOYsUFWy['title']=AoxeprEjqwcTLPNJIblDHkMOYsUFWy['title']+' [개별구매]'
     AoxeprEjqwcTLPNJIblDHkMOYsUFWG.append(AoxeprEjqwcTLPNJIblDHkMOYsUFWy)
   if AoxeprEjqwcTLPNJIblDHkMOYsUFKu>(page_int*AoxeprEjqwcTLPNJIblDHkMOYsUFWR.TVING_LIMIT):AoxeprEjqwcTLPNJIblDHkMOYsUFWh=AoxeprEjqwcTLPNJIblDHkMOYsUFtC
  except AoxeprEjqwcTLPNJIblDHkMOYsUFtv as exception:
   AoxeprEjqwcTLPNJIblDHkMOYsUFta(exception)
  return AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh
 def Get_Search_Watcha(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,search_key,page_int):
  AoxeprEjqwcTLPNJIblDHkMOYsUFWG=[]
  AoxeprEjqwcTLPNJIblDHkMOYsUFWh=AoxeprEjqwcTLPNJIblDHkMOYsUFti
  try:
   AoxeprEjqwcTLPNJIblDHkMOYsUFWi=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_WATCHA+'/api/search.json'
   AoxeprEjqwcTLPNJIblDHkMOYsUFKR={'query':search_key,'page':AoxeprEjqwcTLPNJIblDHkMOYsUFtB(page_int),'per':AoxeprEjqwcTLPNJIblDHkMOYsUFtB(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.WATCHA_LIMIT),'exclude':'limited',}
   AoxeprEjqwcTLPNJIblDHkMOYsUFWB=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.callRequestCookies('Get',AoxeprEjqwcTLPNJIblDHkMOYsUFWi,payload=AoxeprEjqwcTLPNJIblDHkMOYsUFth,params=AoxeprEjqwcTLPNJIblDHkMOYsUFKR,headers=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.WATCHA_HEADER,cookies=AoxeprEjqwcTLPNJIblDHkMOYsUFth)
   AoxeprEjqwcTLPNJIblDHkMOYsUFKz=json.loads(AoxeprEjqwcTLPNJIblDHkMOYsUFWB.text)
   if not('results' in AoxeprEjqwcTLPNJIblDHkMOYsUFKz):return AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh
   AoxeprEjqwcTLPNJIblDHkMOYsUFKV=AoxeprEjqwcTLPNJIblDHkMOYsUFKz['results']
   AoxeprEjqwcTLPNJIblDHkMOYsUFWh=AoxeprEjqwcTLPNJIblDHkMOYsUFKz['meta']['has_next']
   for AoxeprEjqwcTLPNJIblDHkMOYsUFWC in AoxeprEjqwcTLPNJIblDHkMOYsUFKV:
    AoxeprEjqwcTLPNJIblDHkMOYsUFRW =AoxeprEjqwcTLPNJIblDHkMOYsUFWC['code']
    AoxeprEjqwcTLPNJIblDHkMOYsUFRK=AoxeprEjqwcTLPNJIblDHkMOYsUFWC['content_type']
    AoxeprEjqwcTLPNJIblDHkMOYsUFRz =AoxeprEjqwcTLPNJIblDHkMOYsUFWC['title']
    AoxeprEjqwcTLPNJIblDHkMOYsUFRt =AoxeprEjqwcTLPNJIblDHkMOYsUFWC['story']
    AoxeprEjqwcTLPNJIblDHkMOYsUFKf=AoxeprEjqwcTLPNJIblDHkMOYsUFKh=AoxeprEjqwcTLPNJIblDHkMOYsUFzm=''
    if AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('poster') !=AoxeprEjqwcTLPNJIblDHkMOYsUFth:AoxeprEjqwcTLPNJIblDHkMOYsUFKf=AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('poster').get('original')
    if AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('stillcut')!=AoxeprEjqwcTLPNJIblDHkMOYsUFth:AoxeprEjqwcTLPNJIblDHkMOYsUFKh =AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('stillcut').get('large')
    if AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('thumbnail')!=AoxeprEjqwcTLPNJIblDHkMOYsUFth:AoxeprEjqwcTLPNJIblDHkMOYsUFzm=AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('thumbnail').get('large')
    if AoxeprEjqwcTLPNJIblDHkMOYsUFzm=='' :AoxeprEjqwcTLPNJIblDHkMOYsUFzm=AoxeprEjqwcTLPNJIblDHkMOYsUFKh
    AoxeprEjqwcTLPNJIblDHkMOYsUFRu={'thumb':AoxeprEjqwcTLPNJIblDHkMOYsUFKh,'poster':AoxeprEjqwcTLPNJIblDHkMOYsUFKf,'fanart':AoxeprEjqwcTLPNJIblDHkMOYsUFzm}
    AoxeprEjqwcTLPNJIblDHkMOYsUFKC =AoxeprEjqwcTLPNJIblDHkMOYsUFWC['year']
    AoxeprEjqwcTLPNJIblDHkMOYsUFRG =AoxeprEjqwcTLPNJIblDHkMOYsUFWC['film_rating_code']
    AoxeprEjqwcTLPNJIblDHkMOYsUFRf=AoxeprEjqwcTLPNJIblDHkMOYsUFWC['film_rating_short']
    AoxeprEjqwcTLPNJIblDHkMOYsUFRh =AoxeprEjqwcTLPNJIblDHkMOYsUFWC['film_rating_long']
    if AoxeprEjqwcTLPNJIblDHkMOYsUFRK=='movies':
     AoxeprEjqwcTLPNJIblDHkMOYsUFKv =AoxeprEjqwcTLPNJIblDHkMOYsUFWC['duration']
    else:
     AoxeprEjqwcTLPNJIblDHkMOYsUFKv ='0'
    AoxeprEjqwcTLPNJIblDHkMOYsUFWy={'title':AoxeprEjqwcTLPNJIblDHkMOYsUFRz,}
    AoxeprEjqwcTLPNJIblDHkMOYsUFWG.append(AoxeprEjqwcTLPNJIblDHkMOYsUFWy)
  except AoxeprEjqwcTLPNJIblDHkMOYsUFtv as exception:
   AoxeprEjqwcTLPNJIblDHkMOYsUFta(exception)
  return AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh
 def Get_Search_Coupang(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,search_key,page_int):
  AoxeprEjqwcTLPNJIblDHkMOYsUFWG=[]
  AoxeprEjqwcTLPNJIblDHkMOYsUFWh=AoxeprEjqwcTLPNJIblDHkMOYsUFti
  try:
   CP=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.jsonfile_To_dic(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.CP_ORIGINAL_COOKIE)
   AoxeprEjqwcTLPNJIblDHkMOYsUFWi=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_COUPANG+'/v2/search' 
   AoxeprEjqwcTLPNJIblDHkMOYsUFKR={'query':search_key,'platform':'WEBCLIENT','page':AoxeprEjqwcTLPNJIblDHkMOYsUFtB(page_int),'perPage':AoxeprEjqwcTLPNJIblDHkMOYsUFtB(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.COUPANG_LIMIT),}
   AoxeprEjqwcTLPNJIblDHkMOYsUFRi={'x-membersrl':CP['SESSION']['member_srl'],'x-pcid':CP['SESSION']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   AoxeprEjqwcTLPNJIblDHkMOYsUFWB=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.callRequestCookies('Get',AoxeprEjqwcTLPNJIblDHkMOYsUFWi,payload=AoxeprEjqwcTLPNJIblDHkMOYsUFth,params=AoxeprEjqwcTLPNJIblDHkMOYsUFKR,headers=AoxeprEjqwcTLPNJIblDHkMOYsUFRi,cookies=AoxeprEjqwcTLPNJIblDHkMOYsUFth)
   AoxeprEjqwcTLPNJIblDHkMOYsUFWv=json.loads(AoxeprEjqwcTLPNJIblDHkMOYsUFWB.text)
   if AoxeprEjqwcTLPNJIblDHkMOYsUFtS(AoxeprEjqwcTLPNJIblDHkMOYsUFWv.get('data').get('data'))==0:return AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh
   for AoxeprEjqwcTLPNJIblDHkMOYsUFWC in AoxeprEjqwcTLPNJIblDHkMOYsUFWv.get('data').get('data'):
    AoxeprEjqwcTLPNJIblDHkMOYsUFWC=AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('data')
    AoxeprEjqwcTLPNJIblDHkMOYsUFWy={'title':AoxeprEjqwcTLPNJIblDHkMOYsUFWC.get('title'),}
    AoxeprEjqwcTLPNJIblDHkMOYsUFWG.append(AoxeprEjqwcTLPNJIblDHkMOYsUFWy)
   if AoxeprEjqwcTLPNJIblDHkMOYsUFWv.get('pagination').get('totalPages')>page_int:
    AoxeprEjqwcTLPNJIblDHkMOYsUFWh=AoxeprEjqwcTLPNJIblDHkMOYsUFtC
  except AoxeprEjqwcTLPNJIblDHkMOYsUFtv as exception:
   AoxeprEjqwcTLPNJIblDHkMOYsUFta(exception)
  return AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh
 def dic_To_jsonfile(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,filename,AoxeprEjqwcTLPNJIblDHkMOYsUFRg):
  if filename=='':return
  fp=AoxeprEjqwcTLPNJIblDHkMOYsUFtd(filename,'w',-1,'utf-8')
  json.dump(AoxeprEjqwcTLPNJIblDHkMOYsUFRg,fp,indent=4,ensure_ascii=AoxeprEjqwcTLPNJIblDHkMOYsUFti)
  fp.close()
 def jsonfile_To_dic(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,filename):
  if filename=='':return AoxeprEjqwcTLPNJIblDHkMOYsUFth
  try:
   fp=AoxeprEjqwcTLPNJIblDHkMOYsUFtd(filename,'r',-1,'utf-8')
   AoxeprEjqwcTLPNJIblDHkMOYsUFRv=json.load(fp)
   fp.close()
  except:
   AoxeprEjqwcTLPNJIblDHkMOYsUFRv={}
  return AoxeprEjqwcTLPNJIblDHkMOYsUFRv
 def tempFileSave(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,filename,resText):
  if filename=='':return
  fp=AoxeprEjqwcTLPNJIblDHkMOYsUFtd(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,filename):
  if filename=='':return
  try:
   fp=AoxeprEjqwcTLPNJIblDHkMOYsUFtd(filename,'r',-1,'utf-8')
   AoxeprEjqwcTLPNJIblDHkMOYsUFRv=fp.read()
   fp.close()
  except:
   AoxeprEjqwcTLPNJIblDHkMOYsUFRv=''
  return AoxeprEjqwcTLPNJIblDHkMOYsUFRv
 def Init_NF_Total(AoxeprEjqwcTLPNJIblDHkMOYsUFWR):
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF={}
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']={}
  AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']={}
 def make_NF_XnetflixHeaders(AoxeprEjqwcTLPNJIblDHkMOYsUFWR):
  AoxeprEjqwcTLPNJIblDHkMOYsUFRi={'x-netflix.browsername':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':AoxeprEjqwcTLPNJIblDHkMOYsUFtB(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['esnModel'],'x-netflix.esnprefix':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['nowGuid'],'x-netflix.uiversion':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return AoxeprEjqwcTLPNJIblDHkMOYsUFRi
 def make_NF_ApiParams(AoxeprEjqwcTLPNJIblDHkMOYsUFWR):
  AoxeprEjqwcTLPNJIblDHkMOYsUFWg={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['identifier']),}
  return AoxeprEjqwcTLPNJIblDHkMOYsUFWg
 def extract_json(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,content,name):
  AoxeprEjqwcTLPNJIblDHkMOYsUFRa=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  AoxeprEjqwcTLPNJIblDHkMOYsUFRC=AoxeprEjqwcTLPNJIblDHkMOYsUFth
  AoxeprEjqwcTLPNJIblDHkMOYsUFRS=re.compile(AoxeprEjqwcTLPNJIblDHkMOYsUFRa.format(name),re.DOTALL).findall(content)
  AoxeprEjqwcTLPNJIblDHkMOYsUFRC=AoxeprEjqwcTLPNJIblDHkMOYsUFRS[0]
  AoxeprEjqwcTLPNJIblDHkMOYsUFRd=AoxeprEjqwcTLPNJIblDHkMOYsUFRC.replace('\\"','\\\\"') 
  AoxeprEjqwcTLPNJIblDHkMOYsUFRd=AoxeprEjqwcTLPNJIblDHkMOYsUFRd.replace('\\s','\\\\s') 
  AoxeprEjqwcTLPNJIblDHkMOYsUFRd=AoxeprEjqwcTLPNJIblDHkMOYsUFRd.replace('\\n','\\\\n') 
  AoxeprEjqwcTLPNJIblDHkMOYsUFRd=AoxeprEjqwcTLPNJIblDHkMOYsUFRd.replace('\\t','\\\\t') 
  AoxeprEjqwcTLPNJIblDHkMOYsUFRd=AoxeprEjqwcTLPNJIblDHkMOYsUFRd.encode().decode('unicode_escape') 
  AoxeprEjqwcTLPNJIblDHkMOYsUFRd=re.sub(r'\\(?!["])',r'\\\\',AoxeprEjqwcTLPNJIblDHkMOYsUFRd) 
  return json.loads(AoxeprEjqwcTLPNJIblDHkMOYsUFRd)
 def NF_makestr_paths(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,paths):
  AoxeprEjqwcTLPNJIblDHkMOYsUFRv=[]
  if AoxeprEjqwcTLPNJIblDHkMOYsUFtn(paths,AoxeprEjqwcTLPNJIblDHkMOYsUFtg):
   return '%d'%(paths)
  elif AoxeprEjqwcTLPNJIblDHkMOYsUFtn(paths,AoxeprEjqwcTLPNJIblDHkMOYsUFtB):
   return '"%s"'%(paths)
  for AoxeprEjqwcTLPNJIblDHkMOYsUFRn in paths:
   if AoxeprEjqwcTLPNJIblDHkMOYsUFtn(AoxeprEjqwcTLPNJIblDHkMOYsUFRn,AoxeprEjqwcTLPNJIblDHkMOYsUFtg):
    AoxeprEjqwcTLPNJIblDHkMOYsUFRv.append('%d'%(AoxeprEjqwcTLPNJIblDHkMOYsUFRn))
   elif AoxeprEjqwcTLPNJIblDHkMOYsUFtn(AoxeprEjqwcTLPNJIblDHkMOYsUFRn,AoxeprEjqwcTLPNJIblDHkMOYsUFtB):
    AoxeprEjqwcTLPNJIblDHkMOYsUFRv.append('"%s"'%(AoxeprEjqwcTLPNJIblDHkMOYsUFRn))
   elif AoxeprEjqwcTLPNJIblDHkMOYsUFtn(AoxeprEjqwcTLPNJIblDHkMOYsUFRn,AoxeprEjqwcTLPNJIblDHkMOYsUFtQ):
    AoxeprEjqwcTLPNJIblDHkMOYsUFRv.append('[%s]'%(','.join(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_makestr_paths(AoxeprEjqwcTLPNJIblDHkMOYsUFRn))))
   elif AoxeprEjqwcTLPNJIblDHkMOYsUFtn(AoxeprEjqwcTLPNJIblDHkMOYsUFRn,AoxeprEjqwcTLPNJIblDHkMOYsUFtX):
    AoxeprEjqwcTLPNJIblDHkMOYsUFRQ=''
    for AoxeprEjqwcTLPNJIblDHkMOYsUFRX,AoxeprEjqwcTLPNJIblDHkMOYsUFRm in AoxeprEjqwcTLPNJIblDHkMOYsUFRn.items():
     AoxeprEjqwcTLPNJIblDHkMOYsUFRQ+='"%s":%s,'%(AoxeprEjqwcTLPNJIblDHkMOYsUFRX,AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_makestr_paths(AoxeprEjqwcTLPNJIblDHkMOYsUFRm))
    AoxeprEjqwcTLPNJIblDHkMOYsUFRv.append('{%s}'%(AoxeprEjqwcTLPNJIblDHkMOYsUFRQ[:-1]))
  return AoxeprEjqwcTLPNJIblDHkMOYsUFRv
 def NF_Call_pathapi(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,AoxeprEjqwcTLPNJIblDHkMOYsUFzg,referer=''):
  AoxeprEjqwcTLPNJIblDHkMOYsUFRy='%s/nq/website/memberapi/%s/pathEvaluator'%(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_NETFLIX,AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['identifier'])
  AoxeprEjqwcTLPNJIblDHkMOYsUFRV={'path':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_makestr_paths(AoxeprEjqwcTLPNJIblDHkMOYsUFzg),'authURL':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']['authURL']}
  AoxeprEjqwcTLPNJIblDHkMOYsUFWg=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.make_NF_ApiParams()
  AoxeprEjqwcTLPNJIblDHkMOYsUFRi={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':AoxeprEjqwcTLPNJIblDHkMOYsUFRi['referer']=referer
  AoxeprEjqwcTLPNJIblDHkMOYsUFzW=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.make_NF_XnetflixHeaders()
  AoxeprEjqwcTLPNJIblDHkMOYsUFRi.update(AoxeprEjqwcTLPNJIblDHkMOYsUFzW)
  AoxeprEjqwcTLPNJIblDHkMOYsUFzK=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_Get_DefaultCookies()
  AoxeprEjqwcTLPNJIblDHkMOYsUFzK['profilesNewSession']='0'
  try:
   AoxeprEjqwcTLPNJIblDHkMOYsUFWB=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.callRequestCookies('Post',AoxeprEjqwcTLPNJIblDHkMOYsUFRy,payload=AoxeprEjqwcTLPNJIblDHkMOYsUFRV,params=AoxeprEjqwcTLPNJIblDHkMOYsUFWg,headers=AoxeprEjqwcTLPNJIblDHkMOYsUFRi,cookies=AoxeprEjqwcTLPNJIblDHkMOYsUFzK)
   return AoxeprEjqwcTLPNJIblDHkMOYsUFWB
  except AoxeprEjqwcTLPNJIblDHkMOYsUFtv as exception:
   AoxeprEjqwcTLPNJIblDHkMOYsUFta(exception)
   return AoxeprEjqwcTLPNJIblDHkMOYsUFth
 def Get_Search_Netflix(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,search_key,page_int,byReference=''):
  AoxeprEjqwcTLPNJIblDHkMOYsUFzR=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.DERECTOR_LIMIT
  AoxeprEjqwcTLPNJIblDHkMOYsUFzt =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.CAST_LIMIT
  AoxeprEjqwcTLPNJIblDHkMOYsUFzu =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.GENRE_LIMIT
  AoxeprEjqwcTLPNJIblDHkMOYsUFzG =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_LIMIT*(page_int-1)
  AoxeprEjqwcTLPNJIblDHkMOYsUFzf =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_LIMIT*page_int 
  AoxeprEjqwcTLPNJIblDHkMOYsUFzh="|%s"%(search_key)
  AoxeprEjqwcTLPNJIblDHkMOYsUFzi ='%s/search?%s'%(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   AoxeprEjqwcTLPNJIblDHkMOYsUFzg=[["search","byTerm",AoxeprEjqwcTLPNJIblDHkMOYsUFzh,"titles",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_LIMIT,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"summary"],["search","byTerm",AoxeprEjqwcTLPNJIblDHkMOYsUFzh,"titles",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_LIMIT,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",AoxeprEjqwcTLPNJIblDHkMOYsUFzh,"titles",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_LIMIT,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference","boxarts",[AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND2,AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_PORT],"jpg"],["search","byTerm",AoxeprEjqwcTLPNJIblDHkMOYsUFzh,"titles",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_LIMIT,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference","interestingMoment",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND1,"jpg"],["search","byTerm",AoxeprEjqwcTLPNJIblDHkMOYsUFzh,"titles",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_LIMIT,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference","storyArt",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND2,"jpg"],["search","byTerm",AoxeprEjqwcTLPNJIblDHkMOYsUFzh,"titles",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_LIMIT,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference",["cast","creators","directors"],{"from":0,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzR},["id","name"]],["search","byTerm",AoxeprEjqwcTLPNJIblDHkMOYsUFzh,"titles",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_LIMIT,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference","genres",{"from":0,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzu},["id","name"]],["search","byTerm",AoxeprEjqwcTLPNJIblDHkMOYsUFzh,"titles",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NETFLIX_LIMIT,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LOGO,"png"],]
  else:
   AoxeprEjqwcTLPNJIblDHkMOYsUFzg=[["search","byReference",byReference,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"summary"],["search","byReference",byReference,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference","boxarts",[AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND2,AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference","interestingMoment",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference","storyArt",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference",["cast","creators","directors"],{"from":0,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzR},["id","name"]],["search","byReference",byReference,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference","genres",{"from":0,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzu},["id","name"]],["search","byReference",byReference,{"from":AoxeprEjqwcTLPNJIblDHkMOYsUFzG,"to":AoxeprEjqwcTLPNJIblDHkMOYsUFzf},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LOGO,"png"],]
  try:
   AoxeprEjqwcTLPNJIblDHkMOYsUFWB=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_Call_pathapi(AoxeprEjqwcTLPNJIblDHkMOYsUFzg,AoxeprEjqwcTLPNJIblDHkMOYsUFzi)
   AoxeprEjqwcTLPNJIblDHkMOYsUFWv=json.loads(AoxeprEjqwcTLPNJIblDHkMOYsUFWB.text)
  except AoxeprEjqwcTLPNJIblDHkMOYsUFtv as exception:
   AoxeprEjqwcTLPNJIblDHkMOYsUFta(exception)
  (AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh,byReference)=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.Search_Netflix_Make(AoxeprEjqwcTLPNJIblDHkMOYsUFWv)
  return AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh,byReference
 def Search_Netflix_Make(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,jsonSource):
  AoxeprEjqwcTLPNJIblDHkMOYsUFWG=[]
  AoxeprEjqwcTLPNJIblDHkMOYsUFWh =AoxeprEjqwcTLPNJIblDHkMOYsUFti
  AoxeprEjqwcTLPNJIblDHkMOYsUFzB=''
  AoxeprEjqwcTLPNJIblDHkMOYsUFzv=jsonSource.get('paths')[0][1]
  if AoxeprEjqwcTLPNJIblDHkMOYsUFzv=='byTerm':
   AoxeprEjqwcTLPNJIblDHkMOYsUFzG =jsonSource['paths'][0][5]['from']
   AoxeprEjqwcTLPNJIblDHkMOYsUFzf =jsonSource['paths'][0][5]['to']
  else:
   AoxeprEjqwcTLPNJIblDHkMOYsUFzG =jsonSource['paths'][0][3]['from']
   AoxeprEjqwcTLPNJIblDHkMOYsUFzf =jsonSource['paths'][0][3]['to']
  AoxeprEjqwcTLPNJIblDHkMOYsUFzB=AoxeprEjqwcTLPNJIblDHkMOYsUFtQ(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  AoxeprEjqwcTLPNJIblDHkMOYsUFza=jsonSource.get('jsonGraph').get('search').get('byReference').get(AoxeprEjqwcTLPNJIblDHkMOYsUFzB)
  AoxeprEjqwcTLPNJIblDHkMOYsUFzC =jsonSource.get('jsonGraph').get('videos')
  AoxeprEjqwcTLPNJIblDHkMOYsUFzS=jsonSource.get('jsonGraph').get('person')
  AoxeprEjqwcTLPNJIblDHkMOYsUFzd=jsonSource.get('jsonGraph').get('genres')
  AoxeprEjqwcTLPNJIblDHkMOYsUFWh=AoxeprEjqwcTLPNJIblDHkMOYsUFtC if AoxeprEjqwcTLPNJIblDHkMOYsUFza[AoxeprEjqwcTLPNJIblDHkMOYsUFtB(AoxeprEjqwcTLPNJIblDHkMOYsUFzf)]['reference']['$type']=='ref' else AoxeprEjqwcTLPNJIblDHkMOYsUFti
  for AoxeprEjqwcTLPNJIblDHkMOYsUFzn in AoxeprEjqwcTLPNJIblDHkMOYsUFtm(AoxeprEjqwcTLPNJIblDHkMOYsUFzG,AoxeprEjqwcTLPNJIblDHkMOYsUFzf):
   if AoxeprEjqwcTLPNJIblDHkMOYsUFza[AoxeprEjqwcTLPNJIblDHkMOYsUFtB(AoxeprEjqwcTLPNJIblDHkMOYsUFzn)]['reference']['$type']=='ref':
    AoxeprEjqwcTLPNJIblDHkMOYsUFWQ =AoxeprEjqwcTLPNJIblDHkMOYsUFza[AoxeprEjqwcTLPNJIblDHkMOYsUFtB(AoxeprEjqwcTLPNJIblDHkMOYsUFzn)]['reference']['value'][1]
    AoxeprEjqwcTLPNJIblDHkMOYsUFzQ=AoxeprEjqwcTLPNJIblDHkMOYsUFzC[AoxeprEjqwcTLPNJIblDHkMOYsUFWQ]
    AoxeprEjqwcTLPNJIblDHkMOYsUFRz =AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['title']['value']
    if AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['availability']['value']['isPlayable']==AoxeprEjqwcTLPNJIblDHkMOYsUFti:
     continue
    AoxeprEjqwcTLPNJIblDHkMOYsUFWn =AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['summary']['value']['type']
    AoxeprEjqwcTLPNJIblDHkMOYsUFKv =0 if AoxeprEjqwcTLPNJIblDHkMOYsUFWn!='movie' else AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['runtime']['value']
    if AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['sequiturEvidence']['value']['value']:
     AoxeprEjqwcTLPNJIblDHkMOYsUFzX=AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['sequiturEvidence']['value']['value']['text']
    else:
     AoxeprEjqwcTLPNJIblDHkMOYsUFzX=''
    AoxeprEjqwcTLPNJIblDHkMOYsUFKf =AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['boxarts'][AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_PORT]['jpg']['value']['url']
    AoxeprEjqwcTLPNJIblDHkMOYsUFzm =AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['boxarts'][AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND2]['jpg']['value']['url']
    AoxeprEjqwcTLPNJIblDHkMOYsUFKh=''
    if 'value' in AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['storyArt'][AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND2]['jpg']:
     AoxeprEjqwcTLPNJIblDHkMOYsUFKh =AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['storyArt'][AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND2]['jpg']['value']['url']
    if AoxeprEjqwcTLPNJIblDHkMOYsUFKh=='' and 'value' in AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['interestingMoment'][AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND1]['jpg']:
     AoxeprEjqwcTLPNJIblDHkMOYsUFKh =AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['interestingMoment'][AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LAND1]['jpg']['value']['url']
    AoxeprEjqwcTLPNJIblDHkMOYsUFKQ=''
    if 'value' in AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LOGO]['png']:
     AoxeprEjqwcTLPNJIblDHkMOYsUFKQ=AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][AoxeprEjqwcTLPNJIblDHkMOYsUFWR.ART_SIZE_LOGO]['png']['value']['url']
    AoxeprEjqwcTLPNJIblDHkMOYsUFKB =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_Subid_List(AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['genres'])
    for i in AoxeprEjqwcTLPNJIblDHkMOYsUFtm(AoxeprEjqwcTLPNJIblDHkMOYsUFtS(AoxeprEjqwcTLPNJIblDHkMOYsUFKB)):
     AoxeprEjqwcTLPNJIblDHkMOYsUFKB[i]=AoxeprEjqwcTLPNJIblDHkMOYsUFzd[AoxeprEjqwcTLPNJIblDHkMOYsUFKB[i]]['name']['value']
    AoxeprEjqwcTLPNJIblDHkMOYsUFKg=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_Subid_List(AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['directors'])
    AoxeprEjqwcTLPNJIblDHkMOYsUFzy =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_Subid_List(AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['creators'])
    AoxeprEjqwcTLPNJIblDHkMOYsUFKg.extend(AoxeprEjqwcTLPNJIblDHkMOYsUFzy)
    for i in AoxeprEjqwcTLPNJIblDHkMOYsUFtm(AoxeprEjqwcTLPNJIblDHkMOYsUFtS(AoxeprEjqwcTLPNJIblDHkMOYsUFKg)):
     AoxeprEjqwcTLPNJIblDHkMOYsUFKg[i]=AoxeprEjqwcTLPNJIblDHkMOYsUFzS[AoxeprEjqwcTLPNJIblDHkMOYsUFKg[i]]['name']['value']
    AoxeprEjqwcTLPNJIblDHkMOYsUFKi=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_Subid_List(AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['cast'])
    for i in AoxeprEjqwcTLPNJIblDHkMOYsUFtm(AoxeprEjqwcTLPNJIblDHkMOYsUFtS(AoxeprEjqwcTLPNJIblDHkMOYsUFKi)):
     AoxeprEjqwcTLPNJIblDHkMOYsUFKi[i]=AoxeprEjqwcTLPNJIblDHkMOYsUFzS[AoxeprEjqwcTLPNJIblDHkMOYsUFKi[i]]['name']['value']
    if 'maturityDescription' in AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['maturity']['value']['rating']:
     AoxeprEjqwcTLPNJIblDHkMOYsUFKa=AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['maturity']['value']['rating']['maturityDescription']
    AoxeprEjqwcTLPNJIblDHkMOYsUFWy={'videoid':AoxeprEjqwcTLPNJIblDHkMOYsUFWQ,'vidtype':AoxeprEjqwcTLPNJIblDHkMOYsUFWn,'title':AoxeprEjqwcTLPNJIblDHkMOYsUFRz,'mpaa':AoxeprEjqwcTLPNJIblDHkMOYsUFKa,'regularSynopsis':AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['regularSynopsis']['value'],'dpSupplemental':AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['dpSupplementalMessage']['value'],'sequiturEvidence':AoxeprEjqwcTLPNJIblDHkMOYsUFzX,'thumbnail':{'poster':AoxeprEjqwcTLPNJIblDHkMOYsUFKf,'thumb':AoxeprEjqwcTLPNJIblDHkMOYsUFKh,'fanart':AoxeprEjqwcTLPNJIblDHkMOYsUFzm,'clearlogo':AoxeprEjqwcTLPNJIblDHkMOYsUFKQ},'year':AoxeprEjqwcTLPNJIblDHkMOYsUFzQ['releaseYear']['value'],'duration':AoxeprEjqwcTLPNJIblDHkMOYsUFKv,'info_genre':AoxeprEjqwcTLPNJIblDHkMOYsUFKB,'director':AoxeprEjqwcTLPNJIblDHkMOYsUFKg,'cast':AoxeprEjqwcTLPNJIblDHkMOYsUFKi,}
    AoxeprEjqwcTLPNJIblDHkMOYsUFWG.append(AoxeprEjqwcTLPNJIblDHkMOYsUFWy)
  return AoxeprEjqwcTLPNJIblDHkMOYsUFWG,AoxeprEjqwcTLPNJIblDHkMOYsUFWh,AoxeprEjqwcTLPNJIblDHkMOYsUFzB
 def NF_Subid_List(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,subJson):
  AoxeprEjqwcTLPNJIblDHkMOYsUFzV=[]
  try:
   for i in AoxeprEjqwcTLPNJIblDHkMOYsUFtm(AoxeprEjqwcTLPNJIblDHkMOYsUFtS(subJson)):
    if subJson.get(AoxeprEjqwcTLPNJIblDHkMOYsUFtB(i)).get('$type')!='ref':break
    AoxeprEjqwcTLPNJIblDHkMOYsUFtW=subJson.get(AoxeprEjqwcTLPNJIblDHkMOYsUFtB(i)).get('value')[1]
    AoxeprEjqwcTLPNJIblDHkMOYsUFzV.append(AoxeprEjqwcTLPNJIblDHkMOYsUFtW)
  except AoxeprEjqwcTLPNJIblDHkMOYsUFtv as exception:
   AoxeprEjqwcTLPNJIblDHkMOYsUFta(exception)
  return AoxeprEjqwcTLPNJIblDHkMOYsUFzV
 def NF_CookieFile_Load(AoxeprEjqwcTLPNJIblDHkMOYsUFWR,cookie_filename):
  AoxeprEjqwcTLPNJIblDHkMOYsUFzK={}
  try:
   if os.path.isfile(cookie_filename)==AoxeprEjqwcTLPNJIblDHkMOYsUFti:return{}
   AoxeprEjqwcTLPNJIblDHkMOYsUFtK=AoxeprEjqwcTLPNJIblDHkMOYsUFtd(cookie_filename,'rb',-1)
   AoxeprEjqwcTLPNJIblDHkMOYsUFtR =pickle.loads(AoxeprEjqwcTLPNJIblDHkMOYsUFtK.read())
   AoxeprEjqwcTLPNJIblDHkMOYsUFtK.close()
   for AoxeprEjqwcTLPNJIblDHkMOYsUFtz in AoxeprEjqwcTLPNJIblDHkMOYsUFtR:
    AoxeprEjqwcTLPNJIblDHkMOYsUFzK[AoxeprEjqwcTLPNJIblDHkMOYsUFtz.name]=AoxeprEjqwcTLPNJIblDHkMOYsUFtz.value
  except:
   AoxeprEjqwcTLPNJIblDHkMOYsUFta(exception) 
  return AoxeprEjqwcTLPNJIblDHkMOYsUFzK
 def NF_Get_DefaultCookies(AoxeprEjqwcTLPNJIblDHkMOYsUFWR):
  AoxeprEjqwcTLPNJIblDHkMOYsUFzK={}
  if AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['flwssn'] :AoxeprEjqwcTLPNJIblDHkMOYsUFzK['flwssn'] =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['flwssn']
  if AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['nfvdid'] :AoxeprEjqwcTLPNJIblDHkMOYsUFzK['nfvdid'] =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['nfvdid']
  if AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['SecureNetflixId']:AoxeprEjqwcTLPNJIblDHkMOYsUFzK['SecureNetflixId']=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['SecureNetflixId']
  if AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['NetflixId'] :AoxeprEjqwcTLPNJIblDHkMOYsUFzK['NetflixId'] =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['NetflixId']
  if AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['memclid'] :AoxeprEjqwcTLPNJIblDHkMOYsUFzK['memclid'] =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['memclid']
  if AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['clSharedContext']:AoxeprEjqwcTLPNJIblDHkMOYsUFzK['clSharedContext']=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['COOKIES']['clSharedContext']
  return AoxeprEjqwcTLPNJIblDHkMOYsUFzK
 def NF_Get_BaseSession(AoxeprEjqwcTLPNJIblDHkMOYsUFWR):
  try:
   AoxeprEjqwcTLPNJIblDHkMOYsUFWi=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.API_NETFLIX+'/browse' 
   AoxeprEjqwcTLPNJIblDHkMOYsUFzK=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_Get_DefaultCookies()
   AoxeprEjqwcTLPNJIblDHkMOYsUFWB=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.callRequestCookies('Get',AoxeprEjqwcTLPNJIblDHkMOYsUFWi,payload=AoxeprEjqwcTLPNJIblDHkMOYsUFth,params=AoxeprEjqwcTLPNJIblDHkMOYsUFth,headers=AoxeprEjqwcTLPNJIblDHkMOYsUFth,cookies=AoxeprEjqwcTLPNJIblDHkMOYsUFzK)
   if AoxeprEjqwcTLPNJIblDHkMOYsUFWB.status_code!=200:
    AoxeprEjqwcTLPNJIblDHkMOYsUFta('pass 1 status_code error')
    return AoxeprEjqwcTLPNJIblDHkMOYsUFti
   AoxeprEjqwcTLPNJIblDHkMOYsUFtu =AoxeprEjqwcTLPNJIblDHkMOYsUFWR.extract_json(AoxeprEjqwcTLPNJIblDHkMOYsUFWB.text,'reactContext')
   AoxeprEjqwcTLPNJIblDHkMOYsUFtG=AoxeprEjqwcTLPNJIblDHkMOYsUFWR.extract_json(AoxeprEjqwcTLPNJIblDHkMOYsUFWB.text,'falcorCache')
   AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF['SESSION']={'mainGuid':AoxeprEjqwcTLPNJIblDHkMOYsUFtu['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':AoxeprEjqwcTLPNJIblDHkMOYsUFtu['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':AoxeprEjqwcTLPNJIblDHkMOYsUFtu['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':AoxeprEjqwcTLPNJIblDHkMOYsUFtu['models']['memberContext']['data']['userInfo']['esn'],'identifier':AoxeprEjqwcTLPNJIblDHkMOYsUFtu['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':AoxeprEjqwcTLPNJIblDHkMOYsUFtu['models']['abContext']['data']['headers'],}
   AoxeprEjqwcTLPNJIblDHkMOYsUFWR.dic_To_jsonfile(AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF_SESSION_COOKIES1,AoxeprEjqwcTLPNJIblDHkMOYsUFWR.NF)
  except AoxeprEjqwcTLPNJIblDHkMOYsUFtv as exception:
   AoxeprEjqwcTLPNJIblDHkMOYsUFta('pass 1 error')
   AoxeprEjqwcTLPNJIblDHkMOYsUFta(exception)
   return AoxeprEjqwcTLPNJIblDHkMOYsUFti
  return AoxeprEjqwcTLPNJIblDHkMOYsUFtC
# Created by pyminifier (https://github.com/liftoff/pyminifier)
