__author__="NightRain"
WXIrHVhLwOAivDEqegKJtcFjMBnUfx=object
WXIrHVhLwOAivDEqegKJtcFjMBnUfP=None
WXIrHVhLwOAivDEqegKJtcFjMBnUfR=False
WXIrHVhLwOAivDEqegKJtcFjMBnUfy=print
WXIrHVhLwOAivDEqegKJtcFjMBnUfm=str
WXIrHVhLwOAivDEqegKJtcFjMBnUkb=int
WXIrHVhLwOAivDEqegKJtcFjMBnUkC=Exception
WXIrHVhLwOAivDEqegKJtcFjMBnUkY=True
WXIrHVhLwOAivDEqegKJtcFjMBnUku=open
WXIrHVhLwOAivDEqegKJtcFjMBnUkf=isinstance
WXIrHVhLwOAivDEqegKJtcFjMBnUkG=list
WXIrHVhLwOAivDEqegKJtcFjMBnUko=dict
WXIrHVhLwOAivDEqegKJtcFjMBnUkN=range
WXIrHVhLwOAivDEqegKJtcFjMBnUkp=len
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class WXIrHVhLwOAivDEqegKJtcFjMBnUbC(WXIrHVhLwOAivDEqegKJtcFjMBnUfx):
 def __init__(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.DEFAULT_HEADER ={'user-agent':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.USER_AGENT}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_WAVVE ='https://apis.wavve.com'
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_TVING_SEARCH='https://search.tving.com'
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_TVING_IMG ='https://image.tving.com'
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_WATCHA ='https://api-mars.watcha.com'
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX ='https://www.netflix.com'
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.WAVVE_LIMIT =20 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.TVING_LIMIT =30
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.WATCHA_LIMIT =30
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_LIMIT =20 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.DERECTOR_LIMIT =4
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.CAST_LIMIT =10
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.GENRE_LIMIT =4
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.TVING_MOVIE_LITE=['2610061','2610161','261062']
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_HEADER={'user-agent':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND1 ='_342x192'
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND2 ='_665x375'
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_PORT ='_342x684'
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LOGO ='_550x124'
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF={}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']={}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']={}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.Init_NF_Cookies()
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.Init_NF_Session()
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_COOKIES1 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_COOKIES2 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_COOKIES3 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_COOKIES4 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_FULLTEXT1 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_FULLTEXT2 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_FULLTEXT3 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_FULLTEXT4 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_CONTEXTJSON_FILE1 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_CONTEXTJSON_FILE2 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_CONTEXTJSON_FILE3 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_CONTEXTJSON_FILE4 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_FALCORJSON_FILE1 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_FALCORJSON_FILE2 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_FALCORJSON_FILE3 =''
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_FALCORJSON_FILE4 =''
 def callRequestCookies(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,jobtype,WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,params=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,redirects=WXIrHVhLwOAivDEqegKJtcFjMBnUfR):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbu=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.DEFAULT_HEADER
  if headers:WXIrHVhLwOAivDEqegKJtcFjMBnUbu.update(headers)
  if jobtype=='Get':
   WXIrHVhLwOAivDEqegKJtcFjMBnUbf=requests.get(WXIrHVhLwOAivDEqegKJtcFjMBnUbs,params=params,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUbu,cookies=cookies,allow_redirects=redirects)
  else:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbf=requests.post(WXIrHVhLwOAivDEqegKJtcFjMBnUbs,data=payload,params=params,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUbu,cookies=cookies,allow_redirects=redirects)
  return WXIrHVhLwOAivDEqegKJtcFjMBnUbf
 def callRequestCookies_NF(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,jobtype,WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,params=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,redirects=WXIrHVhLwOAivDEqegKJtcFjMBnUfR,addCookie=''):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbu=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_HEADER
  if headers:WXIrHVhLwOAivDEqegKJtcFjMBnUbu.update(headers)
  if jobtype=='Get':
   WXIrHVhLwOAivDEqegKJtcFjMBnUbf=requests.get(WXIrHVhLwOAivDEqegKJtcFjMBnUbs,params=params,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUbu,cookies=cookies,allow_redirects=redirects)
  else:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbf=requests.post(WXIrHVhLwOAivDEqegKJtcFjMBnUbs,data=payload,params=params,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUbu,cookies=cookies,allow_redirects=redirects)
  WXIrHVhLwOAivDEqegKJtcFjMBnUfy(WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUbf.status_code)+' - '+WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUbf.url))
  '''
  print(res.url )
  print(res.status_code )
  print(res.cookies )
  print(res.text )
  '''  
  try:
   if addCookie=='baseurl':
    if 'location' in WXIrHVhLwOAivDEqegKJtcFjMBnUbf.headers:
     WXIrHVhLwOAivDEqegKJtcFjMBnUbk=urllib.parse.urlsplit(WXIrHVhLwOAivDEqegKJtcFjMBnUbf.headers.get('location')).path
     WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['contryurl']=WXIrHVhLwOAivDEqegKJtcFjMBnUbk[1:3]
  except:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfP
  for WXIrHVhLwOAivDEqegKJtcFjMBnUbG in WXIrHVhLwOAivDEqegKJtcFjMBnUbf.cookies:
   if WXIrHVhLwOAivDEqegKJtcFjMBnUbG.name=='flwssn':
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['flwssn']['value'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbG.value
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['flwssn']['expires'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbG.expires
   elif WXIrHVhLwOAivDEqegKJtcFjMBnUbG.name=='nfvdid':
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['nfvdid']['value'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbG.value
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['nfvdid']['expires'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbG.expires
   elif WXIrHVhLwOAivDEqegKJtcFjMBnUbG.name=='SecureNetflixId':
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['SecureNetflixId']['value'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbG.value
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['SecureNetflixId']['expires'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbG.expires
   elif WXIrHVhLwOAivDEqegKJtcFjMBnUbG.name=='NetflixId':
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['NetflixId']['value'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbG.value
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['NetflixId']['expires'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbG.expires
   elif WXIrHVhLwOAivDEqegKJtcFjMBnUbG.name=='memclid':
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['memclid']['value'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbG.value
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['memclid']['expires'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbG.expires
   elif WXIrHVhLwOAivDEqegKJtcFjMBnUbG.name=='clSharedContext':
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['clSharedContext']['value'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbG.value
    WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['clSharedContext']['expires'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.GetNoCache(timetype=1,minutes=5)
  return WXIrHVhLwOAivDEqegKJtcFjMBnUbf
 def GetNoCache(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,timetype=1,minutes=0):
  if timetype==1:
   ts=WXIrHVhLwOAivDEqegKJtcFjMBnUkb(time.time())
   mi=WXIrHVhLwOAivDEqegKJtcFjMBnUkb(minutes*60)
  else:
   ts=WXIrHVhLwOAivDEqegKJtcFjMBnUkb(time.time()*1000)
   mi=WXIrHVhLwOAivDEqegKJtcFjMBnUkb(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,search_key,sType,page_int):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbN=[]
  WXIrHVhLwOAivDEqegKJtcFjMBnUbp=WXIrHVhLwOAivDEqegKJtcFjMBnUCY=1
  WXIrHVhLwOAivDEqegKJtcFjMBnUbd=WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbs=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_WAVVE+'/cf/search/list.js'
   WXIrHVhLwOAivDEqegKJtcFjMBnUbl={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':WXIrHVhLwOAivDEqegKJtcFjMBnUfm((page_int-1)*WXIrHVhLwOAivDEqegKJtcFjMBnUbY.WAVVE_LIMIT),'limit':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.WAVVE_LIMIT,'orderby':'score'}
   WXIrHVhLwOAivDEqegKJtcFjMBnUbl.update(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.WAVVE_PARAMS)
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.callRequestCookies('Get',WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,params=WXIrHVhLwOAivDEqegKJtcFjMBnUbl,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUfP)
   WXIrHVhLwOAivDEqegKJtcFjMBnUbT=json.loads(WXIrHVhLwOAivDEqegKJtcFjMBnUba.text)
   if not('celllist' in WXIrHVhLwOAivDEqegKJtcFjMBnUbT['cell_toplist']):return WXIrHVhLwOAivDEqegKJtcFjMBnUbN,WXIrHVhLwOAivDEqegKJtcFjMBnUbd
   WXIrHVhLwOAivDEqegKJtcFjMBnUbz=WXIrHVhLwOAivDEqegKJtcFjMBnUbT['cell_toplist']['celllist']
   for WXIrHVhLwOAivDEqegKJtcFjMBnUbS in WXIrHVhLwOAivDEqegKJtcFjMBnUbz:
    WXIrHVhLwOAivDEqegKJtcFjMBnUbQ =WXIrHVhLwOAivDEqegKJtcFjMBnUbS['event_list'][1]['url']
    WXIrHVhLwOAivDEqegKJtcFjMBnUbx=urllib.parse.urlsplit(WXIrHVhLwOAivDEqegKJtcFjMBnUbQ).query
    WXIrHVhLwOAivDEqegKJtcFjMBnUbP=WXIrHVhLwOAivDEqegKJtcFjMBnUbx[0:WXIrHVhLwOAivDEqegKJtcFjMBnUbx.find('=')]
    WXIrHVhLwOAivDEqegKJtcFjMBnUbR=WXIrHVhLwOAivDEqegKJtcFjMBnUbx[WXIrHVhLwOAivDEqegKJtcFjMBnUbx.find('=')+1:]
    WXIrHVhLwOAivDEqegKJtcFjMBnUbP='TVSHOW' if WXIrHVhLwOAivDEqegKJtcFjMBnUbP=='programid' else 'MOVIE' 
    WXIrHVhLwOAivDEqegKJtcFjMBnUby=WXIrHVhLwOAivDEqegKJtcFjMBnUbS['title_list'][0]['text']
    WXIrHVhLwOAivDEqegKJtcFjMBnUbm =WXIrHVhLwOAivDEqegKJtcFjMBnUbS['age']
    WXIrHVhLwOAivDEqegKJtcFjMBnUCb={'title':WXIrHVhLwOAivDEqegKJtcFjMBnUby}
    if WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('age')!='21':
     WXIrHVhLwOAivDEqegKJtcFjMBnUbN.append(WXIrHVhLwOAivDEqegKJtcFjMBnUCb)
   WXIrHVhLwOAivDEqegKJtcFjMBnUbp=WXIrHVhLwOAivDEqegKJtcFjMBnUkb(WXIrHVhLwOAivDEqegKJtcFjMBnUbT['cell_toplist']['pagecount'])
   if WXIrHVhLwOAivDEqegKJtcFjMBnUbT['cell_toplist']['count']:WXIrHVhLwOAivDEqegKJtcFjMBnUCY =WXIrHVhLwOAivDEqegKJtcFjMBnUkb(WXIrHVhLwOAivDEqegKJtcFjMBnUbT['cell_toplist']['count'])
   else:WXIrHVhLwOAivDEqegKJtcFjMBnUCY=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.LIST_LIMIT
   WXIrHVhLwOAivDEqegKJtcFjMBnUbd=WXIrHVhLwOAivDEqegKJtcFjMBnUbp>WXIrHVhLwOAivDEqegKJtcFjMBnUCY
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
  return WXIrHVhLwOAivDEqegKJtcFjMBnUbN,WXIrHVhLwOAivDEqegKJtcFjMBnUbd 
 def Get_Search_Tving(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,search_key,sType,page_int):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbN=[]
  WXIrHVhLwOAivDEqegKJtcFjMBnUbd=WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUCu ='/search/getSearch.jsp'
   WXIrHVhLwOAivDEqegKJtcFjMBnUCf={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':WXIrHVhLwOAivDEqegKJtcFjMBnUfm(page_int),'pageSize':WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.TVING_PARMAS.get('SCREENCODE'),'os':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.TVING_PARMAS.get('OSCODE'),'network':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.GetNoCache(2))}
   WXIrHVhLwOAivDEqegKJtcFjMBnUbs=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_TVING_SEARCH+WXIrHVhLwOAivDEqegKJtcFjMBnUCu
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.callRequestCookies('Get',WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,params=WXIrHVhLwOAivDEqegKJtcFjMBnUCf,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUfP)
   WXIrHVhLwOAivDEqegKJtcFjMBnUCk=json.loads(WXIrHVhLwOAivDEqegKJtcFjMBnUba.text)
   if sType=='TVSHOW':
    if not('programRsb' in WXIrHVhLwOAivDEqegKJtcFjMBnUCk):return WXIrHVhLwOAivDEqegKJtcFjMBnUbN,WXIrHVhLwOAivDEqegKJtcFjMBnUbd
    WXIrHVhLwOAivDEqegKJtcFjMBnUCG=WXIrHVhLwOAivDEqegKJtcFjMBnUCk['programRsb']['dataList']
    WXIrHVhLwOAivDEqegKJtcFjMBnUCo =WXIrHVhLwOAivDEqegKJtcFjMBnUkb(WXIrHVhLwOAivDEqegKJtcFjMBnUCk['programRsb']['count'])
    for WXIrHVhLwOAivDEqegKJtcFjMBnUbS in WXIrHVhLwOAivDEqegKJtcFjMBnUCG:
     WXIrHVhLwOAivDEqegKJtcFjMBnUCN=WXIrHVhLwOAivDEqegKJtcFjMBnUbS['mast_cd']
     WXIrHVhLwOAivDEqegKJtcFjMBnUby =WXIrHVhLwOAivDEqegKJtcFjMBnUbS['mast_nm']
     WXIrHVhLwOAivDEqegKJtcFjMBnUCp=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_TVING_IMG+WXIrHVhLwOAivDEqegKJtcFjMBnUbS['web_url4']
     WXIrHVhLwOAivDEqegKJtcFjMBnUCd =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_TVING_IMG+WXIrHVhLwOAivDEqegKJtcFjMBnUbS['web_url']
     try:
      WXIrHVhLwOAivDEqegKJtcFjMBnUCs =[]
      WXIrHVhLwOAivDEqegKJtcFjMBnUCl=[]
      WXIrHVhLwOAivDEqegKJtcFjMBnUCa =[]
      WXIrHVhLwOAivDEqegKJtcFjMBnUCT =0
      WXIrHVhLwOAivDEqegKJtcFjMBnUCz =''
      WXIrHVhLwOAivDEqegKJtcFjMBnUCS =''
      WXIrHVhLwOAivDEqegKJtcFjMBnUCQ =''
      if WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('actor') !='' and WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('actor') !='-':WXIrHVhLwOAivDEqegKJtcFjMBnUCs =WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('actor').split(',')
      if WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('director')!='' and WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('director')!='-':WXIrHVhLwOAivDEqegKJtcFjMBnUCl=WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('director').split(',')
      if WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('cate_nm')!='' and WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('cate_nm')!='-':WXIrHVhLwOAivDEqegKJtcFjMBnUCa =WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('cate_nm').split('/')
      if 'targetage' in WXIrHVhLwOAivDEqegKJtcFjMBnUbS:WXIrHVhLwOAivDEqegKJtcFjMBnUCz=WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('targetage')
      if 'broad_dt' in WXIrHVhLwOAivDEqegKJtcFjMBnUbS:
       WXIrHVhLwOAivDEqegKJtcFjMBnUCx=WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('broad_dt')
       WXIrHVhLwOAivDEqegKJtcFjMBnUCQ='%s-%s-%s'%(WXIrHVhLwOAivDEqegKJtcFjMBnUCx[:4],WXIrHVhLwOAivDEqegKJtcFjMBnUCx[4:6],WXIrHVhLwOAivDEqegKJtcFjMBnUCx[6:])
       WXIrHVhLwOAivDEqegKJtcFjMBnUCS =WXIrHVhLwOAivDEqegKJtcFjMBnUCx[:4]
     except:
      WXIrHVhLwOAivDEqegKJtcFjMBnUfP
     WXIrHVhLwOAivDEqegKJtcFjMBnUCb={'title':WXIrHVhLwOAivDEqegKJtcFjMBnUby,}
     WXIrHVhLwOAivDEqegKJtcFjMBnUbN.append(WXIrHVhLwOAivDEqegKJtcFjMBnUCb)
   else:
    if not('vodMVRsb' in WXIrHVhLwOAivDEqegKJtcFjMBnUCk):return WXIrHVhLwOAivDEqegKJtcFjMBnUbN,WXIrHVhLwOAivDEqegKJtcFjMBnUbd
    WXIrHVhLwOAivDEqegKJtcFjMBnUCP=WXIrHVhLwOAivDEqegKJtcFjMBnUCk['vodMVRsb']['dataList']
    WXIrHVhLwOAivDEqegKJtcFjMBnUCo =WXIrHVhLwOAivDEqegKJtcFjMBnUkb(WXIrHVhLwOAivDEqegKJtcFjMBnUCk['vodMVRsb']['count'])
    WXIrHVhLwOAivDEqegKJtcFjMBnUfy(WXIrHVhLwOAivDEqegKJtcFjMBnUCo)
    for WXIrHVhLwOAivDEqegKJtcFjMBnUbS in WXIrHVhLwOAivDEqegKJtcFjMBnUCP:
     WXIrHVhLwOAivDEqegKJtcFjMBnUCN=WXIrHVhLwOAivDEqegKJtcFjMBnUbS['mast_cd']
     WXIrHVhLwOAivDEqegKJtcFjMBnUby =WXIrHVhLwOAivDEqegKJtcFjMBnUbS['mast_nm'].strip()
     WXIrHVhLwOAivDEqegKJtcFjMBnUCp =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_TVING_IMG+WXIrHVhLwOAivDEqegKJtcFjMBnUbS['web_url']
     WXIrHVhLwOAivDEqegKJtcFjMBnUCd =WXIrHVhLwOAivDEqegKJtcFjMBnUCp
     WXIrHVhLwOAivDEqegKJtcFjMBnUCR=''
     try:
      WXIrHVhLwOAivDEqegKJtcFjMBnUCs =[]
      WXIrHVhLwOAivDEqegKJtcFjMBnUCl=[]
      WXIrHVhLwOAivDEqegKJtcFjMBnUCa =[]
      WXIrHVhLwOAivDEqegKJtcFjMBnUCT =0
      WXIrHVhLwOAivDEqegKJtcFjMBnUCz =''
      WXIrHVhLwOAivDEqegKJtcFjMBnUCS =''
      WXIrHVhLwOAivDEqegKJtcFjMBnUCQ =''
      if WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('actor') !='' and WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('actor') !='-':WXIrHVhLwOAivDEqegKJtcFjMBnUCs =WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('actor').split(',')
      if WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('director')!='' and WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('director')!='-':WXIrHVhLwOAivDEqegKJtcFjMBnUCl=WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('director').split(',')
      if WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('cate_nm')!='' and WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('cate_nm')!='-':WXIrHVhLwOAivDEqegKJtcFjMBnUCa =WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('cate_nm').split('/')
      if WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('runtime_sec')!='':WXIrHVhLwOAivDEqegKJtcFjMBnUCT=WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('runtime_sec')
      if 'grade_nm' in WXIrHVhLwOAivDEqegKJtcFjMBnUbS:WXIrHVhLwOAivDEqegKJtcFjMBnUCz=WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('grade_nm')
      WXIrHVhLwOAivDEqegKJtcFjMBnUCy=''
      WXIrHVhLwOAivDEqegKJtcFjMBnUCx=WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('broad_dt')
      if WXIrHVhLwOAivDEqegKJtcFjMBnUCy!='':
       WXIrHVhLwOAivDEqegKJtcFjMBnUCQ='%s-%s-%s'%(WXIrHVhLwOAivDEqegKJtcFjMBnUCx[:4],WXIrHVhLwOAivDEqegKJtcFjMBnUCx[4:6],WXIrHVhLwOAivDEqegKJtcFjMBnUCx[6:])
       WXIrHVhLwOAivDEqegKJtcFjMBnUCS =WXIrHVhLwOAivDEqegKJtcFjMBnUCx[:4]
     except:
      WXIrHVhLwOAivDEqegKJtcFjMBnUfP
     WXIrHVhLwOAivDEqegKJtcFjMBnUCb={'title':WXIrHVhLwOAivDEqegKJtcFjMBnUby,}
     WXIrHVhLwOAivDEqegKJtcFjMBnUCm=WXIrHVhLwOAivDEqegKJtcFjMBnUfR
     for WXIrHVhLwOAivDEqegKJtcFjMBnUYb in WXIrHVhLwOAivDEqegKJtcFjMBnUbS['bill']:
      if WXIrHVhLwOAivDEqegKJtcFjMBnUYb in WXIrHVhLwOAivDEqegKJtcFjMBnUbY.TVING_MOVIE_LITE:
       WXIrHVhLwOAivDEqegKJtcFjMBnUCm=WXIrHVhLwOAivDEqegKJtcFjMBnUkY
       break
     if WXIrHVhLwOAivDEqegKJtcFjMBnUCm==WXIrHVhLwOAivDEqegKJtcFjMBnUfR: 
      WXIrHVhLwOAivDEqegKJtcFjMBnUCb['title']=WXIrHVhLwOAivDEqegKJtcFjMBnUCb['title']+' [개별구매]'
     WXIrHVhLwOAivDEqegKJtcFjMBnUbN.append(WXIrHVhLwOAivDEqegKJtcFjMBnUCb)
   if WXIrHVhLwOAivDEqegKJtcFjMBnUCo>(page_int*WXIrHVhLwOAivDEqegKJtcFjMBnUbY.TVING_LIMIT):WXIrHVhLwOAivDEqegKJtcFjMBnUbd=WXIrHVhLwOAivDEqegKJtcFjMBnUkY
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
  return WXIrHVhLwOAivDEqegKJtcFjMBnUbN,WXIrHVhLwOAivDEqegKJtcFjMBnUbd
 def Get_Search_Watcha(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,search_key,page_int):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbN=[]
  WXIrHVhLwOAivDEqegKJtcFjMBnUbd=WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbs=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_WATCHA+'/api/search.json'
   WXIrHVhLwOAivDEqegKJtcFjMBnUCf={'query':search_key,'page':WXIrHVhLwOAivDEqegKJtcFjMBnUfm(page_int),'per':WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.WATCHA_LIMIT),'exclude':'limited',}
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.callRequestCookies('Get',WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,params=WXIrHVhLwOAivDEqegKJtcFjMBnUCf,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.WATCHA_HEADER,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUfP)
   WXIrHVhLwOAivDEqegKJtcFjMBnUCk=json.loads(WXIrHVhLwOAivDEqegKJtcFjMBnUba.text)
   if not('results' in WXIrHVhLwOAivDEqegKJtcFjMBnUCk):return WXIrHVhLwOAivDEqegKJtcFjMBnUbN,WXIrHVhLwOAivDEqegKJtcFjMBnUbd
   WXIrHVhLwOAivDEqegKJtcFjMBnUYC=WXIrHVhLwOAivDEqegKJtcFjMBnUCk['results']
   WXIrHVhLwOAivDEqegKJtcFjMBnUbd=WXIrHVhLwOAivDEqegKJtcFjMBnUCk['meta']['has_next']
   for WXIrHVhLwOAivDEqegKJtcFjMBnUbS in WXIrHVhLwOAivDEqegKJtcFjMBnUYC:
    WXIrHVhLwOAivDEqegKJtcFjMBnUYu =WXIrHVhLwOAivDEqegKJtcFjMBnUbS['code']
    WXIrHVhLwOAivDEqegKJtcFjMBnUYf=WXIrHVhLwOAivDEqegKJtcFjMBnUbS['content_type']
    WXIrHVhLwOAivDEqegKJtcFjMBnUYk =WXIrHVhLwOAivDEqegKJtcFjMBnUbS['title']
    WXIrHVhLwOAivDEqegKJtcFjMBnUYG =WXIrHVhLwOAivDEqegKJtcFjMBnUbS['story']
    WXIrHVhLwOAivDEqegKJtcFjMBnUCp=WXIrHVhLwOAivDEqegKJtcFjMBnUCd=WXIrHVhLwOAivDEqegKJtcFjMBnUfT=''
    if WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('poster') !=WXIrHVhLwOAivDEqegKJtcFjMBnUfP:WXIrHVhLwOAivDEqegKJtcFjMBnUCp=WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('poster').get('original')
    if WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('stillcut')!=WXIrHVhLwOAivDEqegKJtcFjMBnUfP:WXIrHVhLwOAivDEqegKJtcFjMBnUCd =WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('stillcut').get('large')
    if WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('thumbnail')!=WXIrHVhLwOAivDEqegKJtcFjMBnUfP:WXIrHVhLwOAivDEqegKJtcFjMBnUfT=WXIrHVhLwOAivDEqegKJtcFjMBnUbS.get('thumbnail').get('large')
    if WXIrHVhLwOAivDEqegKJtcFjMBnUfT=='' :WXIrHVhLwOAivDEqegKJtcFjMBnUfT=WXIrHVhLwOAivDEqegKJtcFjMBnUCd
    WXIrHVhLwOAivDEqegKJtcFjMBnUYo={'thumb':WXIrHVhLwOAivDEqegKJtcFjMBnUCd,'poster':WXIrHVhLwOAivDEqegKJtcFjMBnUCp,'fanart':WXIrHVhLwOAivDEqegKJtcFjMBnUfT}
    WXIrHVhLwOAivDEqegKJtcFjMBnUCS =WXIrHVhLwOAivDEqegKJtcFjMBnUbS['year']
    WXIrHVhLwOAivDEqegKJtcFjMBnUYN =WXIrHVhLwOAivDEqegKJtcFjMBnUbS['film_rating_code']
    WXIrHVhLwOAivDEqegKJtcFjMBnUYp=WXIrHVhLwOAivDEqegKJtcFjMBnUbS['film_rating_short']
    WXIrHVhLwOAivDEqegKJtcFjMBnUYd =WXIrHVhLwOAivDEqegKJtcFjMBnUbS['film_rating_long']
    if WXIrHVhLwOAivDEqegKJtcFjMBnUYf=='movies':
     WXIrHVhLwOAivDEqegKJtcFjMBnUCT =WXIrHVhLwOAivDEqegKJtcFjMBnUbS['duration']
    else:
     WXIrHVhLwOAivDEqegKJtcFjMBnUCT ='0'
    WXIrHVhLwOAivDEqegKJtcFjMBnUCb={'title':WXIrHVhLwOAivDEqegKJtcFjMBnUYk,}
    WXIrHVhLwOAivDEqegKJtcFjMBnUbN.append(WXIrHVhLwOAivDEqegKJtcFjMBnUCb)
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
  return WXIrHVhLwOAivDEqegKJtcFjMBnUbN,WXIrHVhLwOAivDEqegKJtcFjMBnUbd
 def dic_To_jsonfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,filename,WXIrHVhLwOAivDEqegKJtcFjMBnUYs):
  if filename=='':return
  fp=WXIrHVhLwOAivDEqegKJtcFjMBnUku(filename,'w',-1,'utf-8')
  json.dump(WXIrHVhLwOAivDEqegKJtcFjMBnUYs,fp,indent=4,ensure_ascii=WXIrHVhLwOAivDEqegKJtcFjMBnUfR)
  fp.close()
 def jsonfile_To_dic(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,filename):
  if filename=='':return WXIrHVhLwOAivDEqegKJtcFjMBnUfP
  try:
   fp=WXIrHVhLwOAivDEqegKJtcFjMBnUku(filename,'r',-1,'utf-8')
   WXIrHVhLwOAivDEqegKJtcFjMBnUYa=json.load(fp)
   fp.close()
  except:
   WXIrHVhLwOAivDEqegKJtcFjMBnUYa={}
  return WXIrHVhLwOAivDEqegKJtcFjMBnUYa
 def tempFileSave(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,filename,resText):
  if filename=='':return
  fp=WXIrHVhLwOAivDEqegKJtcFjMBnUku(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,filename):
  if filename=='':return
  try:
   fp=WXIrHVhLwOAivDEqegKJtcFjMBnUku(filename,'r',-1,'utf-8')
   WXIrHVhLwOAivDEqegKJtcFjMBnUYa=fp.read()
   fp.close()
  except:
   WXIrHVhLwOAivDEqegKJtcFjMBnUYa=''
  return WXIrHVhLwOAivDEqegKJtcFjMBnUYa
 def Init_NF_Total(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF={}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']={}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']={}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.Init_NF_Cookies()
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.Init_NF_Session()
 def Init_NF_Cookies(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['lhpuuidh'] ={'keyname':'','value':'','expires':0}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['lhpuuidhT'] ={'keyname':'','value':'','expires':0}
 def Check_NF_CookieExp(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  WXIrHVhLwOAivDEqegKJtcFjMBnUYT=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.GetNoCache(timetype=1,minutes=0)
  if WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['flwssn']['expires'] <=WXIrHVhLwOAivDEqegKJtcFjMBnUYT:WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  if WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['nfvdid']['expires'] <=WXIrHVhLwOAivDEqegKJtcFjMBnUYT:WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  if WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['SecureNetflixId']['expires']<=WXIrHVhLwOAivDEqegKJtcFjMBnUYT:WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  if WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['NetflixId']['expires'] <=WXIrHVhLwOAivDEqegKJtcFjMBnUYT:WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  if WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['memclid']['expires'] <=WXIrHVhLwOAivDEqegKJtcFjMBnUYT:WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  if WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['clSharedContext']['expires']<=WXIrHVhLwOAivDEqegKJtcFjMBnUYT:WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
 def Init_NF_Session(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['account'] ={'nfid':'','nfpw':'','nfpfnum':0}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['membershipStatus']='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['esnModel'] ='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['username'] ='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['authURL'] ='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['mainGuid'] ='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['nowGuid'] ='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['abContext'] ='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['identifier'] ='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['contryurl'] ='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['countryCode'] ='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['countryIsoCode'] ='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['loco'] ='' 
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['limitdate'] =''
 def make_NF_DefaultCookies(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  WXIrHVhLwOAivDEqegKJtcFjMBnUYz={}
  if WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['flwssn']['value'] :WXIrHVhLwOAivDEqegKJtcFjMBnUYz['flwssn'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['flwssn']['value']
  if WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['nfvdid']['value'] :WXIrHVhLwOAivDEqegKJtcFjMBnUYz['nfvdid'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['nfvdid']['value']
  if WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['SecureNetflixId']['value']:WXIrHVhLwOAivDEqegKJtcFjMBnUYz['SecureNetflixId']=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['SecureNetflixId']['value']
  if WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['NetflixId']['value'] :WXIrHVhLwOAivDEqegKJtcFjMBnUYz['NetflixId'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['NetflixId']['value']
  if WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['memclid']['value'] :WXIrHVhLwOAivDEqegKJtcFjMBnUYz['memclid'] =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['memclid']['value']
  return WXIrHVhLwOAivDEqegKJtcFjMBnUYz
 def make_NF_XnetflixHeaders(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  WXIrHVhLwOAivDEqegKJtcFjMBnUYS={'x-netflix.browsername':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['esnModel'],'x-netflix.esnprefix':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['nowGuid'],'x-netflix.uiversion':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return WXIrHVhLwOAivDEqegKJtcFjMBnUYS
 def make_NF_ApiParams(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbl={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['identifier']),}
  return WXIrHVhLwOAivDEqegKJtcFjMBnUbl
 def extract_json(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,content,name):
  WXIrHVhLwOAivDEqegKJtcFjMBnUYQ=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  WXIrHVhLwOAivDEqegKJtcFjMBnUYx=WXIrHVhLwOAivDEqegKJtcFjMBnUfP
  WXIrHVhLwOAivDEqegKJtcFjMBnUYP=re.compile(WXIrHVhLwOAivDEqegKJtcFjMBnUYQ.format(name),re.DOTALL).findall(content)
  WXIrHVhLwOAivDEqegKJtcFjMBnUYx=WXIrHVhLwOAivDEqegKJtcFjMBnUYP[0]
  WXIrHVhLwOAivDEqegKJtcFjMBnUYR=WXIrHVhLwOAivDEqegKJtcFjMBnUYx.replace('\\"','\\\\"') 
  WXIrHVhLwOAivDEqegKJtcFjMBnUYR=WXIrHVhLwOAivDEqegKJtcFjMBnUYR.replace('\\s','\\\\s') 
  WXIrHVhLwOAivDEqegKJtcFjMBnUYR=WXIrHVhLwOAivDEqegKJtcFjMBnUYR.replace('\\n','\\\\n') 
  WXIrHVhLwOAivDEqegKJtcFjMBnUYR=WXIrHVhLwOAivDEqegKJtcFjMBnUYR.replace('\\t','\\\\t') 
  WXIrHVhLwOAivDEqegKJtcFjMBnUYR=WXIrHVhLwOAivDEqegKJtcFjMBnUYR.encode().decode('unicode_escape') 
  WXIrHVhLwOAivDEqegKJtcFjMBnUYR=re.sub(r'\\(?!["])',r'\\\\',WXIrHVhLwOAivDEqegKJtcFjMBnUYR) 
  return json.loads(WXIrHVhLwOAivDEqegKJtcFjMBnUYR)
 def Save_session_acount(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,WXIrHVhLwOAivDEqegKJtcFjMBnUYy,WXIrHVhLwOAivDEqegKJtcFjMBnUYm,WXIrHVhLwOAivDEqegKJtcFjMBnUub):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['account']['nfid'] =base64.standard_b64encode(WXIrHVhLwOAivDEqegKJtcFjMBnUYy.encode()).decode('utf-8')
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['account']['nfpw'] =base64.standard_b64encode(WXIrHVhLwOAivDEqegKJtcFjMBnUYm.encode()).decode('utf-8')
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['account']['nfpfnum']=WXIrHVhLwOAivDEqegKJtcFjMBnUub
 def Load_session_acount(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  WXIrHVhLwOAivDEqegKJtcFjMBnUYy =base64.standard_b64decode(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['account']['nfid']).decode('utf-8')
  WXIrHVhLwOAivDEqegKJtcFjMBnUYm =base64.standard_b64decode(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['account']['nfpw']).decode('utf-8')
  WXIrHVhLwOAivDEqegKJtcFjMBnUub=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['account']['nfpfnum']
  return WXIrHVhLwOAivDEqegKJtcFjMBnUYy,WXIrHVhLwOAivDEqegKJtcFjMBnUYm,WXIrHVhLwOAivDEqegKJtcFjMBnUub
 def Get_NF_BaseCookies(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbs=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX+'/login' 
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.callRequestCookies_NF('Get',WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,params=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,addCookie='baseurl')
   if WXIrHVhLwOAivDEqegKJtcFjMBnUba.status_code!=302:
    WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 1-1 status_code error')
    return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 1-1 error')
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbs=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX+'/'+WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['contryurl']+'/login' 
   WXIrHVhLwOAivDEqegKJtcFjMBnUYz=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.make_NF_DefaultCookies()
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.callRequestCookies_NF('Get',WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,params=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUYz)
   if WXIrHVhLwOAivDEqegKJtcFjMBnUba.status_code!=200:
    WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 1-2 status_code error')
    return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
   WXIrHVhLwOAivDEqegKJtcFjMBnUuC=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.extract_json(WXIrHVhLwOAivDEqegKJtcFjMBnUba.text,'reactContext')
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.dic_To_jsonfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_CONTEXTJSON_FILE1,WXIrHVhLwOAivDEqegKJtcFjMBnUuC)
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['membershipStatus']=WXIrHVhLwOAivDEqegKJtcFjMBnUuC['models']['userInfo']['data']['membershipStatus']
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['authURL'] =WXIrHVhLwOAivDEqegKJtcFjMBnUuC['models']['userInfo']['data']['authURL']
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['esnModel'] =WXIrHVhLwOAivDEqegKJtcFjMBnUuC['models']['esnGeneratorModel']['data']['esn']
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['abContext'] =WXIrHVhLwOAivDEqegKJtcFjMBnUuC['models']['abContext']['data']['headers']
   WXIrHVhLwOAivDEqegKJtcFjMBnUuY=WXIrHVhLwOAivDEqegKJtcFjMBnUuC['models']['loginContext']['data']['geo']['requestCountry']['id']
   WXIrHVhLwOAivDEqegKJtcFjMBnUuf ='+82' 
   WXIrHVhLwOAivDEqegKJtcFjMBnUuk =WXIrHVhLwOAivDEqegKJtcFjMBnUuC['models']['countryCodes']['data']['codes']
   for WXIrHVhLwOAivDEqegKJtcFjMBnUuG in WXIrHVhLwOAivDEqegKJtcFjMBnUuk:
    if WXIrHVhLwOAivDEqegKJtcFjMBnUuG['id']==WXIrHVhLwOAivDEqegKJtcFjMBnUuY:
     WXIrHVhLwOAivDEqegKJtcFjMBnUuf='+'+WXIrHVhLwOAivDEqegKJtcFjMBnUuG['code']
     break
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['countryCode'] =WXIrHVhLwOAivDEqegKJtcFjMBnUuf 
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['countryIsoCode']=WXIrHVhLwOAivDEqegKJtcFjMBnUuY 
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.dic_To_jsonfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_COOKIES1,WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF)
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 1-2 error')
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  return WXIrHVhLwOAivDEqegKJtcFjMBnUkY
 def Get_NF_BaseLogin(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,user_id,user_pw,user_pfnum):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbY.Save_session_acount(user_id,user_pw,user_pfnum)
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbs=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX+'/'+WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['contryurl']+'/login' 
   WXIrHVhLwOAivDEqegKJtcFjMBnUuo={'userLoginId':user_id,'password':user_pw,'rememberMe':'true','flow':'websiteSignUp','mode':'login','action':'loginAction','withFields':'rememberMe,nextPage,userLoginId,password,countryCode,countryIsoCode','authURL':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['authURL'],'nextPage':'','showPassword':'','countryCode':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['countryCode'],'countryIsoCode':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['countryIsoCode'],}
   WXIrHVhLwOAivDEqegKJtcFjMBnUYS={'referer':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX+'/'+WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['contryurl']+'/login'}
   WXIrHVhLwOAivDEqegKJtcFjMBnUYz=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.make_NF_DefaultCookies()
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.callRequestCookies_NF('Post',WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUuo,params=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUYS,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUYz)
   if WXIrHVhLwOAivDEqegKJtcFjMBnUba.status_code!=302:
    WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 2-1 status_code error')
    return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 2-1 error')
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbs=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX+'/'+WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['contryurl']+'/' 
   WXIrHVhLwOAivDEqegKJtcFjMBnUYS={'referer':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX+'/'+WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['contryurl']+'/login'}
   WXIrHVhLwOAivDEqegKJtcFjMBnUYz=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.make_NF_DefaultCookies()
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.callRequestCookies_NF('Get',WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,params=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUYS,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUYz)
   if WXIrHVhLwOAivDEqegKJtcFjMBnUba.status_code!=302:
    WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 2-2 status_code error')
    return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 2-2 error')
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbs=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX+'/browse' 
   WXIrHVhLwOAivDEqegKJtcFjMBnUYS={'referer':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX+'/'+WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['contryurl']+'/login'}
   WXIrHVhLwOAivDEqegKJtcFjMBnUYz=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.make_NF_DefaultCookies()
   WXIrHVhLwOAivDEqegKJtcFjMBnUYz['clSharedContext']=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['clSharedContext']['value']
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.callRequestCookies_NF('Get',WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,params=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUYS,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUYz)
   if WXIrHVhLwOAivDEqegKJtcFjMBnUba.status_code!=200:
    WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 2-3 status_code error')
    return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
   WXIrHVhLwOAivDEqegKJtcFjMBnUuN=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.extract_json(WXIrHVhLwOAivDEqegKJtcFjMBnUba.text,'reactContext')
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.dic_To_jsonfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_CONTEXTJSON_FILE2,WXIrHVhLwOAivDEqegKJtcFjMBnUuN)
   WXIrHVhLwOAivDEqegKJtcFjMBnUup=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.extract_json(WXIrHVhLwOAivDEqegKJtcFjMBnUba.text,'falcorCache')
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.dic_To_jsonfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_FALCORJSON_FILE2,WXIrHVhLwOAivDEqegKJtcFjMBnUup)
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 2-3 error')
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  WXIrHVhLwOAivDEqegKJtcFjMBnUud=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.Get_NF_LoginData(WXIrHVhLwOAivDEqegKJtcFjMBnUuN,WXIrHVhLwOAivDEqegKJtcFjMBnUup,user_pfnum)
  if WXIrHVhLwOAivDEqegKJtcFjMBnUud==WXIrHVhLwOAivDEqegKJtcFjMBnUfR:
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfR 
  return WXIrHVhLwOAivDEqegKJtcFjMBnUkY
 def Get_NF_LoginData(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,WXIrHVhLwOAivDEqegKJtcFjMBnUuN,WXIrHVhLwOAivDEqegKJtcFjMBnUup,user_pfnum):
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['membershipStatus']=WXIrHVhLwOAivDEqegKJtcFjMBnUuN['models']['userInfo']['data']['membershipStatus']
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['username'] =WXIrHVhLwOAivDEqegKJtcFjMBnUuN['models']['userInfo']['data']['name']
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['authURL'] =WXIrHVhLwOAivDEqegKJtcFjMBnUuN['models']['userInfo']['data']['authURL'] 
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['mainGuid'] =WXIrHVhLwOAivDEqegKJtcFjMBnUuN['models']['userInfo']['data']['guid'] 
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['nowGuid'] =WXIrHVhLwOAivDEqegKJtcFjMBnUuN['models']['userInfo']['data']['userGuid']
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['esnModel'] =WXIrHVhLwOAivDEqegKJtcFjMBnUuN['models']['esnGeneratorModel']['data']['esn']
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['abContext'] =WXIrHVhLwOAivDEqegKJtcFjMBnUuN['models']['abContext']['data']['headers']
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['identifier'] =WXIrHVhLwOAivDEqegKJtcFjMBnUuN['models']['serverDefs']['data']['BUILD_IDENTIFIER']
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['nowGuid'] =WXIrHVhLwOAivDEqegKJtcFjMBnUup['profilesList'][WXIrHVhLwOAivDEqegKJtcFjMBnUfm(user_pfnum)]['value'][1]
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.dic_To_jsonfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_COOKIES2,WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF)
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 2-3-sub error')
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  return WXIrHVhLwOAivDEqegKJtcFjMBnUkY
 def Get_NF_ActivateProfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbs='%s/api/shakti/%s/profiles/switch'%(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX,WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['identifier'])
   WXIrHVhLwOAivDEqegKJtcFjMBnUbl={'switchProfileGuid':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['nowGuid'],'authURL':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['authURL'],'_':WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.GetNoCache(timetype=2,minutes=0)),}
   WXIrHVhLwOAivDEqegKJtcFjMBnUYS={'referer':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX+'/browse','accept':'*/*','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
   WXIrHVhLwOAivDEqegKJtcFjMBnUus=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.make_NF_XnetflixHeaders()
   WXIrHVhLwOAivDEqegKJtcFjMBnUus['x-netflix.request.client.user.guid']=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['mainGuid']
   WXIrHVhLwOAivDEqegKJtcFjMBnUYS.update(WXIrHVhLwOAivDEqegKJtcFjMBnUus)
   WXIrHVhLwOAivDEqegKJtcFjMBnUYz=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.make_NF_DefaultCookies()
   WXIrHVhLwOAivDEqegKJtcFjMBnUYz['clSharedContext']=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['clSharedContext']['value']
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.callRequestCookies_NF('Get',WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,params=WXIrHVhLwOAivDEqegKJtcFjMBnUbl,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUYS,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUYz)
   if WXIrHVhLwOAivDEqegKJtcFjMBnUba.status_code!=200:
    WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 3 status_code error')
    return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.dic_To_jsonfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_COOKIES2,WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF)
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 3 error')
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  return WXIrHVhLwOAivDEqegKJtcFjMBnUkY
 def Get_NF_BrowseMain(WXIrHVhLwOAivDEqegKJtcFjMBnUbY):
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUbs=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX+'/browse' 
   WXIrHVhLwOAivDEqegKJtcFjMBnUYS={'referer':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX+'/browse','sec-fetch-dest':'document','sec-fetch-mode':'navigate','sec-fetch-site':'same-origin','sec-fetch-user':'?1',}
   WXIrHVhLwOAivDEqegKJtcFjMBnUYz=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.make_NF_DefaultCookies()
   WXIrHVhLwOAivDEqegKJtcFjMBnUYz['clSharedContext']=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['clSharedContext']['value']
   WXIrHVhLwOAivDEqegKJtcFjMBnUYz['profilesNewSession']='0' 
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.callRequestCookies_NF('Get',WXIrHVhLwOAivDEqegKJtcFjMBnUbs,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,params=WXIrHVhLwOAivDEqegKJtcFjMBnUfP,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUYS,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUYz,addCookie='lhpuuidh')
   if WXIrHVhLwOAivDEqegKJtcFjMBnUba.status_code!=200:
    WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 4-main status_code error')
    return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
   WXIrHVhLwOAivDEqegKJtcFjMBnUuN=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.extract_json(WXIrHVhLwOAivDEqegKJtcFjMBnUba.text,'reactContext')
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.dic_To_jsonfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_CONTEXTJSON_FILE3,WXIrHVhLwOAivDEqegKJtcFjMBnUuN)
   WXIrHVhLwOAivDEqegKJtcFjMBnUup=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.extract_json(WXIrHVhLwOAivDEqegKJtcFjMBnUba.text,'falcorCache')
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.dic_To_jsonfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_FALCORJSON_FILE3,WXIrHVhLwOAivDEqegKJtcFjMBnUup)
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 4-main error')
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  WXIrHVhLwOAivDEqegKJtcFjMBnUud=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.Get_NF_BrowseSub(WXIrHVhLwOAivDEqegKJtcFjMBnUuN,WXIrHVhLwOAivDEqegKJtcFjMBnUup)
  if WXIrHVhLwOAivDEqegKJtcFjMBnUud==WXIrHVhLwOAivDEqegKJtcFjMBnUfR:
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfR 
  return WXIrHVhLwOAivDEqegKJtcFjMBnUkY
 def Get_NF_BrowseSub(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,WXIrHVhLwOAivDEqegKJtcFjMBnUuN,WXIrHVhLwOAivDEqegKJtcFjMBnUup):
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUul =WXIrHVhLwOAivDEqegKJtcFjMBnUup['loco']['value'][1]
   WXIrHVhLwOAivDEqegKJtcFjMBnUua=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.GetNoCache(timetype=2,minutes=180)
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['loco'] =WXIrHVhLwOAivDEqegKJtcFjMBnUul
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['lhpuuidh']={'keyname':'lhpuuidh-browse-%s'%(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['nowGuid']),'value':'%s%s'%('KR%3AKO-KR%3A',WXIrHVhLwOAivDEqegKJtcFjMBnUul),'expires':WXIrHVhLwOAivDEqegKJtcFjMBnUkb(WXIrHVhLwOAivDEqegKJtcFjMBnUua/1000)}
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['COOKIES']['lhpuuidhT']={'keyname':'lhpuuidh-browse-%s-T'%(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['nowGuid']),'value':WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUua),'expires':WXIrHVhLwOAivDEqegKJtcFjMBnUkb(WXIrHVhLwOAivDEqegKJtcFjMBnUua/1000)}
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.dic_To_jsonfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_SESSION_COOKIES3,WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF)
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy('pass 4-sub error')
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  return WXIrHVhLwOAivDEqegKJtcFjMBnUkY
 def NF_makestr_paths(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,paths):
  WXIrHVhLwOAivDEqegKJtcFjMBnUYa=[]
  if WXIrHVhLwOAivDEqegKJtcFjMBnUkf(paths,WXIrHVhLwOAivDEqegKJtcFjMBnUkb):
   return '%d'%(paths)
  elif WXIrHVhLwOAivDEqegKJtcFjMBnUkf(paths,WXIrHVhLwOAivDEqegKJtcFjMBnUfm):
   return '"%s"'%(paths)
  for WXIrHVhLwOAivDEqegKJtcFjMBnUuT in paths:
   if WXIrHVhLwOAivDEqegKJtcFjMBnUkf(WXIrHVhLwOAivDEqegKJtcFjMBnUuT,WXIrHVhLwOAivDEqegKJtcFjMBnUkb):
    WXIrHVhLwOAivDEqegKJtcFjMBnUYa.append('%d'%(WXIrHVhLwOAivDEqegKJtcFjMBnUuT))
   elif WXIrHVhLwOAivDEqegKJtcFjMBnUkf(WXIrHVhLwOAivDEqegKJtcFjMBnUuT,WXIrHVhLwOAivDEqegKJtcFjMBnUfm):
    WXIrHVhLwOAivDEqegKJtcFjMBnUYa.append('"%s"'%(WXIrHVhLwOAivDEqegKJtcFjMBnUuT))
   elif WXIrHVhLwOAivDEqegKJtcFjMBnUkf(WXIrHVhLwOAivDEqegKJtcFjMBnUuT,WXIrHVhLwOAivDEqegKJtcFjMBnUkG):
    WXIrHVhLwOAivDEqegKJtcFjMBnUYa.append('[%s]'%(','.join(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_makestr_paths(WXIrHVhLwOAivDEqegKJtcFjMBnUuT))))
   elif WXIrHVhLwOAivDEqegKJtcFjMBnUkf(WXIrHVhLwOAivDEqegKJtcFjMBnUuT,WXIrHVhLwOAivDEqegKJtcFjMBnUko):
    WXIrHVhLwOAivDEqegKJtcFjMBnUuz=''
    for WXIrHVhLwOAivDEqegKJtcFjMBnUuS,WXIrHVhLwOAivDEqegKJtcFjMBnUuQ in WXIrHVhLwOAivDEqegKJtcFjMBnUuT.items():
     WXIrHVhLwOAivDEqegKJtcFjMBnUuz+='"%s":%s,'%(WXIrHVhLwOAivDEqegKJtcFjMBnUuS,WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_makestr_paths(WXIrHVhLwOAivDEqegKJtcFjMBnUuQ))
    WXIrHVhLwOAivDEqegKJtcFjMBnUYa.append('{%s}'%(WXIrHVhLwOAivDEqegKJtcFjMBnUuz[:-1]))
  return WXIrHVhLwOAivDEqegKJtcFjMBnUYa
 def NF_Call_pathapi(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,WXIrHVhLwOAivDEqegKJtcFjMBnUfu,referer=''):
  WXIrHVhLwOAivDEqegKJtcFjMBnUux='%s/nq/website/memberapi/%s/pathEvaluator'%(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX,WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['identifier'])
  WXIrHVhLwOAivDEqegKJtcFjMBnUuo={'path':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_makestr_paths(WXIrHVhLwOAivDEqegKJtcFjMBnUfu),'authURL':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF['SESSION']['authURL']}
  WXIrHVhLwOAivDEqegKJtcFjMBnUbl=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.make_NF_ApiParams()
  WXIrHVhLwOAivDEqegKJtcFjMBnUYS={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':WXIrHVhLwOAivDEqegKJtcFjMBnUYS['referer']=referer
  WXIrHVhLwOAivDEqegKJtcFjMBnUus=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.make_NF_XnetflixHeaders()
  WXIrHVhLwOAivDEqegKJtcFjMBnUYS.update(WXIrHVhLwOAivDEqegKJtcFjMBnUus)
  WXIrHVhLwOAivDEqegKJtcFjMBnUYz=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.make_NF_DefaultCookies()
  WXIrHVhLwOAivDEqegKJtcFjMBnUYz['profilesNewSession']='0'
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.callRequestCookies('Post',WXIrHVhLwOAivDEqegKJtcFjMBnUux,payload=WXIrHVhLwOAivDEqegKJtcFjMBnUuo,params=WXIrHVhLwOAivDEqegKJtcFjMBnUbl,headers=WXIrHVhLwOAivDEqegKJtcFjMBnUYS,cookies=WXIrHVhLwOAivDEqegKJtcFjMBnUYz)
   return WXIrHVhLwOAivDEqegKJtcFjMBnUba
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
   return WXIrHVhLwOAivDEqegKJtcFjMBnUfP
 def Get_Search_Netflix(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,search_key,page_int,byReference=''):
  WXIrHVhLwOAivDEqegKJtcFjMBnUuP=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.DERECTOR_LIMIT
  WXIrHVhLwOAivDEqegKJtcFjMBnUuR =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.CAST_LIMIT
  WXIrHVhLwOAivDEqegKJtcFjMBnUuy =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.GENRE_LIMIT
  WXIrHVhLwOAivDEqegKJtcFjMBnUum =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_LIMIT*(page_int-1)
  WXIrHVhLwOAivDEqegKJtcFjMBnUfb =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_LIMIT*page_int 
  WXIrHVhLwOAivDEqegKJtcFjMBnUfC="|%s"%(search_key)
  WXIrHVhLwOAivDEqegKJtcFjMBnUfY ='%s/search?%s'%(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfu=[["search","byTerm",WXIrHVhLwOAivDEqegKJtcFjMBnUfC,"titles",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_LIMIT,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"summary"],["search","byTerm",WXIrHVhLwOAivDEqegKJtcFjMBnUfC,"titles",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_LIMIT,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",WXIrHVhLwOAivDEqegKJtcFjMBnUfC,"titles",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_LIMIT,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference","boxarts",[WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND2,WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_PORT],"jpg"],["search","byTerm",WXIrHVhLwOAivDEqegKJtcFjMBnUfC,"titles",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_LIMIT,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference","interestingMoment",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND1,"jpg"],["search","byTerm",WXIrHVhLwOAivDEqegKJtcFjMBnUfC,"titles",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_LIMIT,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference","storyArt",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND2,"jpg"],["search","byTerm",WXIrHVhLwOAivDEqegKJtcFjMBnUfC,"titles",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_LIMIT,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference",["cast","creators","directors"],{"from":0,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUuP},["id","name"]],["search","byTerm",WXIrHVhLwOAivDEqegKJtcFjMBnUfC,"titles",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_LIMIT,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference","genres",{"from":0,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUuy},["id","name"]],["search","byTerm",WXIrHVhLwOAivDEqegKJtcFjMBnUfC,"titles",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NETFLIX_LIMIT,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LOGO,"png"],]
  else:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfu=[["search","byReference",byReference,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"summary"],["search","byReference",byReference,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference","boxarts",[WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND2,WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference","interestingMoment",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference","storyArt",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference",["cast","creators","directors"],{"from":0,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUuP},["id","name"]],["search","byReference",byReference,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference","genres",{"from":0,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUuy},["id","name"]],["search","byReference",byReference,{"from":WXIrHVhLwOAivDEqegKJtcFjMBnUum,"to":WXIrHVhLwOAivDEqegKJtcFjMBnUfb},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LOGO,"png"],]
  try:
   WXIrHVhLwOAivDEqegKJtcFjMBnUba=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_Call_pathapi(WXIrHVhLwOAivDEqegKJtcFjMBnUfu,WXIrHVhLwOAivDEqegKJtcFjMBnUfY)
   WXIrHVhLwOAivDEqegKJtcFjMBnUbT=json.loads(WXIrHVhLwOAivDEqegKJtcFjMBnUba.text)
   WXIrHVhLwOAivDEqegKJtcFjMBnUbY.dic_To_jsonfile(WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_CONTEXTJSON_FILE4,WXIrHVhLwOAivDEqegKJtcFjMBnUbT)
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
  (WXIrHVhLwOAivDEqegKJtcFjMBnUbN,WXIrHVhLwOAivDEqegKJtcFjMBnUbd,byReference)=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.Search_Netflix_Make(WXIrHVhLwOAivDEqegKJtcFjMBnUbT)
  return WXIrHVhLwOAivDEqegKJtcFjMBnUbN,WXIrHVhLwOAivDEqegKJtcFjMBnUbd,byReference
 def Search_Netflix_Make(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,jsonSource):
  WXIrHVhLwOAivDEqegKJtcFjMBnUbN=[]
  WXIrHVhLwOAivDEqegKJtcFjMBnUbd =WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  WXIrHVhLwOAivDEqegKJtcFjMBnUfk=''
  WXIrHVhLwOAivDEqegKJtcFjMBnUfG=jsonSource.get('paths')[0][1]
  if WXIrHVhLwOAivDEqegKJtcFjMBnUfG=='byTerm':
   WXIrHVhLwOAivDEqegKJtcFjMBnUum =jsonSource['paths'][0][5]['from']
   WXIrHVhLwOAivDEqegKJtcFjMBnUfb =jsonSource['paths'][0][5]['to']
  else:
   WXIrHVhLwOAivDEqegKJtcFjMBnUum =jsonSource['paths'][0][3]['from']
   WXIrHVhLwOAivDEqegKJtcFjMBnUfb =jsonSource['paths'][0][3]['to']
  WXIrHVhLwOAivDEqegKJtcFjMBnUfk=WXIrHVhLwOAivDEqegKJtcFjMBnUkG(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  WXIrHVhLwOAivDEqegKJtcFjMBnUfo=jsonSource.get('jsonGraph').get('search').get('byReference').get(WXIrHVhLwOAivDEqegKJtcFjMBnUfk)
  WXIrHVhLwOAivDEqegKJtcFjMBnUfN =jsonSource.get('jsonGraph').get('videos')
  WXIrHVhLwOAivDEqegKJtcFjMBnUfp=jsonSource.get('jsonGraph').get('person')
  WXIrHVhLwOAivDEqegKJtcFjMBnUfd=jsonSource.get('jsonGraph').get('genres')
  WXIrHVhLwOAivDEqegKJtcFjMBnUbd=WXIrHVhLwOAivDEqegKJtcFjMBnUkY if WXIrHVhLwOAivDEqegKJtcFjMBnUfo[WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUfb)]['reference']['$type']=='ref' else WXIrHVhLwOAivDEqegKJtcFjMBnUfR
  for WXIrHVhLwOAivDEqegKJtcFjMBnUfs in WXIrHVhLwOAivDEqegKJtcFjMBnUkN(WXIrHVhLwOAivDEqegKJtcFjMBnUum,WXIrHVhLwOAivDEqegKJtcFjMBnUfb):
   if WXIrHVhLwOAivDEqegKJtcFjMBnUfo[WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUfs)]['reference']['$type']=='ref':
    WXIrHVhLwOAivDEqegKJtcFjMBnUbR =WXIrHVhLwOAivDEqegKJtcFjMBnUfo[WXIrHVhLwOAivDEqegKJtcFjMBnUfm(WXIrHVhLwOAivDEqegKJtcFjMBnUfs)]['reference']['value'][1]
    WXIrHVhLwOAivDEqegKJtcFjMBnUfl=WXIrHVhLwOAivDEqegKJtcFjMBnUfN[WXIrHVhLwOAivDEqegKJtcFjMBnUbR]
    WXIrHVhLwOAivDEqegKJtcFjMBnUYk =WXIrHVhLwOAivDEqegKJtcFjMBnUfl['title']['value']
    if WXIrHVhLwOAivDEqegKJtcFjMBnUfl['availability']['value']['isPlayable']==WXIrHVhLwOAivDEqegKJtcFjMBnUfR:
     continue
    WXIrHVhLwOAivDEqegKJtcFjMBnUbP =WXIrHVhLwOAivDEqegKJtcFjMBnUfl['summary']['value']['type']
    WXIrHVhLwOAivDEqegKJtcFjMBnUCT =0 if WXIrHVhLwOAivDEqegKJtcFjMBnUbP!='movie' else WXIrHVhLwOAivDEqegKJtcFjMBnUfl['runtime']['value']
    if WXIrHVhLwOAivDEqegKJtcFjMBnUfl['sequiturEvidence']['value']['value']:
     WXIrHVhLwOAivDEqegKJtcFjMBnUfa=WXIrHVhLwOAivDEqegKJtcFjMBnUfl['sequiturEvidence']['value']['value']['text']
    else:
     WXIrHVhLwOAivDEqegKJtcFjMBnUfa=''
    WXIrHVhLwOAivDEqegKJtcFjMBnUCp =WXIrHVhLwOAivDEqegKJtcFjMBnUfl['boxarts'][WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_PORT]['jpg']['value']['url']
    WXIrHVhLwOAivDEqegKJtcFjMBnUfT =WXIrHVhLwOAivDEqegKJtcFjMBnUfl['boxarts'][WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND2]['jpg']['value']['url']
    WXIrHVhLwOAivDEqegKJtcFjMBnUCd=''
    if 'value' in WXIrHVhLwOAivDEqegKJtcFjMBnUfl['storyArt'][WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND2]['jpg']:
     WXIrHVhLwOAivDEqegKJtcFjMBnUCd =WXIrHVhLwOAivDEqegKJtcFjMBnUfl['storyArt'][WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND2]['jpg']['value']['url']
    if WXIrHVhLwOAivDEqegKJtcFjMBnUCd=='' and 'value' in WXIrHVhLwOAivDEqegKJtcFjMBnUfl['interestingMoment'][WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND1]['jpg']:
     WXIrHVhLwOAivDEqegKJtcFjMBnUCd =WXIrHVhLwOAivDEqegKJtcFjMBnUfl['interestingMoment'][WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LAND1]['jpg']['value']['url']
    WXIrHVhLwOAivDEqegKJtcFjMBnUCR=''
    if 'value' in WXIrHVhLwOAivDEqegKJtcFjMBnUfl['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LOGO]['png']:
     WXIrHVhLwOAivDEqegKJtcFjMBnUCR=WXIrHVhLwOAivDEqegKJtcFjMBnUfl['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][WXIrHVhLwOAivDEqegKJtcFjMBnUbY.ART_SIZE_LOGO]['png']['value']['url']
    WXIrHVhLwOAivDEqegKJtcFjMBnUCa =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_Subid_List(WXIrHVhLwOAivDEqegKJtcFjMBnUfl['genres'])
    for i in WXIrHVhLwOAivDEqegKJtcFjMBnUkN(WXIrHVhLwOAivDEqegKJtcFjMBnUkp(WXIrHVhLwOAivDEqegKJtcFjMBnUCa)):
     WXIrHVhLwOAivDEqegKJtcFjMBnUCa[i]=WXIrHVhLwOAivDEqegKJtcFjMBnUfd[WXIrHVhLwOAivDEqegKJtcFjMBnUCa[i]]['name']['value']
    WXIrHVhLwOAivDEqegKJtcFjMBnUCl=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_Subid_List(WXIrHVhLwOAivDEqegKJtcFjMBnUfl['directors'])
    WXIrHVhLwOAivDEqegKJtcFjMBnUfz =WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_Subid_List(WXIrHVhLwOAivDEqegKJtcFjMBnUfl['creators'])
    WXIrHVhLwOAivDEqegKJtcFjMBnUCl.extend(WXIrHVhLwOAivDEqegKJtcFjMBnUfz)
    for i in WXIrHVhLwOAivDEqegKJtcFjMBnUkN(WXIrHVhLwOAivDEqegKJtcFjMBnUkp(WXIrHVhLwOAivDEqegKJtcFjMBnUCl)):
     WXIrHVhLwOAivDEqegKJtcFjMBnUCl[i]=WXIrHVhLwOAivDEqegKJtcFjMBnUfp[WXIrHVhLwOAivDEqegKJtcFjMBnUCl[i]]['name']['value']
    WXIrHVhLwOAivDEqegKJtcFjMBnUCs=WXIrHVhLwOAivDEqegKJtcFjMBnUbY.NF_Subid_List(WXIrHVhLwOAivDEqegKJtcFjMBnUfl['cast'])
    for i in WXIrHVhLwOAivDEqegKJtcFjMBnUkN(WXIrHVhLwOAivDEqegKJtcFjMBnUkp(WXIrHVhLwOAivDEqegKJtcFjMBnUCs)):
     WXIrHVhLwOAivDEqegKJtcFjMBnUCs[i]=WXIrHVhLwOAivDEqegKJtcFjMBnUfp[WXIrHVhLwOAivDEqegKJtcFjMBnUCs[i]]['name']['value']
    if 'maturityDescription' in WXIrHVhLwOAivDEqegKJtcFjMBnUfl['maturity']['value']['rating']:
     WXIrHVhLwOAivDEqegKJtcFjMBnUCz=WXIrHVhLwOAivDEqegKJtcFjMBnUfl['maturity']['value']['rating']['maturityDescription']
    WXIrHVhLwOAivDEqegKJtcFjMBnUCb={'videoid':WXIrHVhLwOAivDEqegKJtcFjMBnUbR,'vidtype':WXIrHVhLwOAivDEqegKJtcFjMBnUbP,'title':WXIrHVhLwOAivDEqegKJtcFjMBnUYk,'mpaa':WXIrHVhLwOAivDEqegKJtcFjMBnUCz,'regularSynopsis':WXIrHVhLwOAivDEqegKJtcFjMBnUfl['regularSynopsis']['value'],'dpSupplemental':WXIrHVhLwOAivDEqegKJtcFjMBnUfl['dpSupplementalMessage']['value'],'sequiturEvidence':WXIrHVhLwOAivDEqegKJtcFjMBnUfa,'thumbnail':{'poster':WXIrHVhLwOAivDEqegKJtcFjMBnUCp,'thumb':WXIrHVhLwOAivDEqegKJtcFjMBnUCd,'fanart':WXIrHVhLwOAivDEqegKJtcFjMBnUfT,'clearlogo':WXIrHVhLwOAivDEqegKJtcFjMBnUCR},'year':WXIrHVhLwOAivDEqegKJtcFjMBnUfl['releaseYear']['value'],'duration':WXIrHVhLwOAivDEqegKJtcFjMBnUCT,'info_genre':WXIrHVhLwOAivDEqegKJtcFjMBnUCa,'director':WXIrHVhLwOAivDEqegKJtcFjMBnUCl,'cast':WXIrHVhLwOAivDEqegKJtcFjMBnUCs,}
    WXIrHVhLwOAivDEqegKJtcFjMBnUbN.append(WXIrHVhLwOAivDEqegKJtcFjMBnUCb)
  return WXIrHVhLwOAivDEqegKJtcFjMBnUbN,WXIrHVhLwOAivDEqegKJtcFjMBnUbd,WXIrHVhLwOAivDEqegKJtcFjMBnUfk
 def NF_Subid_List(WXIrHVhLwOAivDEqegKJtcFjMBnUbY,subJson):
  WXIrHVhLwOAivDEqegKJtcFjMBnUfS=[]
  try:
   for i in WXIrHVhLwOAivDEqegKJtcFjMBnUkN(WXIrHVhLwOAivDEqegKJtcFjMBnUkp(subJson)):
    if subJson.get(WXIrHVhLwOAivDEqegKJtcFjMBnUfm(i)).get('$type')!='ref':break
    WXIrHVhLwOAivDEqegKJtcFjMBnUfQ=subJson.get(WXIrHVhLwOAivDEqegKJtcFjMBnUfm(i)).get('value')[1]
    WXIrHVhLwOAivDEqegKJtcFjMBnUfS.append(WXIrHVhLwOAivDEqegKJtcFjMBnUfQ)
  except WXIrHVhLwOAivDEqegKJtcFjMBnUkC as exception:
   WXIrHVhLwOAivDEqegKJtcFjMBnUfy(exception)
  return WXIrHVhLwOAivDEqegKJtcFjMBnUfS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
