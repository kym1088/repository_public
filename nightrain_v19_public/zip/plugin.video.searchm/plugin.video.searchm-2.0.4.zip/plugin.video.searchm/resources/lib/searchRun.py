__author__="NightRain"
KYtodJLuQahViOHrDneMgsqCxjpSWw=object
KYtodJLuQahViOHrDneMgsqCxjpSWU=None
KYtodJLuQahViOHrDneMgsqCxjpSWG=True
KYtodJLuQahViOHrDneMgsqCxjpSWk=False
KYtodJLuQahViOHrDneMgsqCxjpSWI=type
KYtodJLuQahViOHrDneMgsqCxjpSRX=dict
KYtodJLuQahViOHrDneMgsqCxjpSRP=open
KYtodJLuQahViOHrDneMgsqCxjpSRT=len
KYtodJLuQahViOHrDneMgsqCxjpSRm=Exception
KYtodJLuQahViOHrDneMgsqCxjpSRW=str
KYtodJLuQahViOHrDneMgsqCxjpSRv=int
KYtodJLuQahViOHrDneMgsqCxjpSRb=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
KYtodJLuQahViOHrDneMgsqCxjpSXT=[{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
KYtodJLuQahViOHrDneMgsqCxjpSXm={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},}
KYtodJLuQahViOHrDneMgsqCxjpSXW=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
KYtodJLuQahViOHrDneMgsqCxjpSXR =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class KYtodJLuQahViOHrDneMgsqCxjpSXP(KYtodJLuQahViOHrDneMgsqCxjpSWw):
 def __init__(KYtodJLuQahViOHrDneMgsqCxjpSXv,KYtodJLuQahViOHrDneMgsqCxjpSXb,KYtodJLuQahViOHrDneMgsqCxjpSXF,KYtodJLuQahViOHrDneMgsqCxjpSXz):
  KYtodJLuQahViOHrDneMgsqCxjpSXv._addon_url =KYtodJLuQahViOHrDneMgsqCxjpSXb
  KYtodJLuQahViOHrDneMgsqCxjpSXv._addon_handle=KYtodJLuQahViOHrDneMgsqCxjpSXF
  KYtodJLuQahViOHrDneMgsqCxjpSXv.main_params =KYtodJLuQahViOHrDneMgsqCxjpSXz
  KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj =WXIrHVhLwOAivDEqegKJtcFjMBnUbC() 
 def addon_noti(KYtodJLuQahViOHrDneMgsqCxjpSXv,sting):
  try:
   KYtodJLuQahViOHrDneMgsqCxjpSXy=xbmcgui.Dialog()
   KYtodJLuQahViOHrDneMgsqCxjpSXy.notification(__addonname__,sting)
  except:
   KYtodJLuQahViOHrDneMgsqCxjpSWU
 def addon_log(KYtodJLuQahViOHrDneMgsqCxjpSXv,string):
  try:
   KYtodJLuQahViOHrDneMgsqCxjpSXB=string.encode('utf-8','ignore')
  except:
   KYtodJLuQahViOHrDneMgsqCxjpSXB='addonException: addon_log'
  KYtodJLuQahViOHrDneMgsqCxjpSXc=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,KYtodJLuQahViOHrDneMgsqCxjpSXB),level=KYtodJLuQahViOHrDneMgsqCxjpSXc)
 def get_keyboard_input(KYtodJLuQahViOHrDneMgsqCxjpSXv,KYtodJLuQahViOHrDneMgsqCxjpSXk):
  KYtodJLuQahViOHrDneMgsqCxjpSXl=KYtodJLuQahViOHrDneMgsqCxjpSWU
  kb=xbmc.Keyboard()
  kb.setHeading(KYtodJLuQahViOHrDneMgsqCxjpSXk)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   KYtodJLuQahViOHrDneMgsqCxjpSXl=kb.getText()
  return KYtodJLuQahViOHrDneMgsqCxjpSXl
 def get_settings_menubookmark(KYtodJLuQahViOHrDneMgsqCxjpSXv):
  KYtodJLuQahViOHrDneMgsqCxjpSXN=KYtodJLuQahViOHrDneMgsqCxjpSWG if __addon__.getSetting('menu_bookmark')=='true' else KYtodJLuQahViOHrDneMgsqCxjpSWk
  return(KYtodJLuQahViOHrDneMgsqCxjpSXN)
 def get_settings_makebookmark(KYtodJLuQahViOHrDneMgsqCxjpSXv):
  return KYtodJLuQahViOHrDneMgsqCxjpSWG if __addon__.getSetting('make_bookmark')=='true' else KYtodJLuQahViOHrDneMgsqCxjpSWk
 def get_settings_select_info(KYtodJLuQahViOHrDneMgsqCxjpSXv):
  KYtodJLuQahViOHrDneMgsqCxjpSXf=[]
  if __addon__.getSetting('netflixyn')=='true':KYtodJLuQahViOHrDneMgsqCxjpSXf.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':KYtodJLuQahViOHrDneMgsqCxjpSXf.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':KYtodJLuQahViOHrDneMgsqCxjpSXf.append('tving')
  if __addon__.getSetting('watchayn')=='true':KYtodJLuQahViOHrDneMgsqCxjpSXf.append('watcha')
  return KYtodJLuQahViOHrDneMgsqCxjpSXf
 def get_settings_netflix(KYtodJLuQahViOHrDneMgsqCxjpSXv):
  KYtodJLuQahViOHrDneMgsqCxjpSXE =__addon__.getSetting('nfid')
  KYtodJLuQahViOHrDneMgsqCxjpSXw =__addon__.getSetting('nfpw')
  KYtodJLuQahViOHrDneMgsqCxjpSXU=__addon__.getSetting('nf_profile')
  return(KYtodJLuQahViOHrDneMgsqCxjpSXE,KYtodJLuQahViOHrDneMgsqCxjpSXw,KYtodJLuQahViOHrDneMgsqCxjpSXU)
 def add_dir(KYtodJLuQahViOHrDneMgsqCxjpSXv,label,sublabel='',img='',infoLabels=KYtodJLuQahViOHrDneMgsqCxjpSWU,isFolder=KYtodJLuQahViOHrDneMgsqCxjpSWG,params='',isLink=KYtodJLuQahViOHrDneMgsqCxjpSWk,ContextMenu=KYtodJLuQahViOHrDneMgsqCxjpSWU):
  KYtodJLuQahViOHrDneMgsqCxjpSXG='%s?%s'%(KYtodJLuQahViOHrDneMgsqCxjpSXv._addon_url,urllib.parse.urlencode(params))
  if sublabel:KYtodJLuQahViOHrDneMgsqCxjpSXk='%s < %s >'%(label,sublabel)
  else: KYtodJLuQahViOHrDneMgsqCxjpSXk=label
  if not img:img='DefaultFolder.png'
  KYtodJLuQahViOHrDneMgsqCxjpSXI=xbmcgui.ListItem(KYtodJLuQahViOHrDneMgsqCxjpSXk)
  if KYtodJLuQahViOHrDneMgsqCxjpSWI(img)==KYtodJLuQahViOHrDneMgsqCxjpSRX:
   KYtodJLuQahViOHrDneMgsqCxjpSXI.setArt(img)
  else:
   KYtodJLuQahViOHrDneMgsqCxjpSXI.setArt({'thumb':img,'poster':img})
  if infoLabels:KYtodJLuQahViOHrDneMgsqCxjpSXI.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   KYtodJLuQahViOHrDneMgsqCxjpSXI.setProperty('IsPlayable','true')
  if ContextMenu:KYtodJLuQahViOHrDneMgsqCxjpSXI.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(KYtodJLuQahViOHrDneMgsqCxjpSXv._addon_handle,KYtodJLuQahViOHrDneMgsqCxjpSXG,KYtodJLuQahViOHrDneMgsqCxjpSXI,isFolder)
 def Load_Searched_List(KYtodJLuQahViOHrDneMgsqCxjpSXv):
  try:
   KYtodJLuQahViOHrDneMgsqCxjpSPX=KYtodJLuQahViOHrDneMgsqCxjpSXR
   fp=KYtodJLuQahViOHrDneMgsqCxjpSRP(KYtodJLuQahViOHrDneMgsqCxjpSPX,'r',-1,'utf-8')
   KYtodJLuQahViOHrDneMgsqCxjpSPT=fp.readlines()
   fp.close()
  except:
   KYtodJLuQahViOHrDneMgsqCxjpSPT=[]
  return KYtodJLuQahViOHrDneMgsqCxjpSPT
 def Save_Searched_List(KYtodJLuQahViOHrDneMgsqCxjpSXv,KYtodJLuQahViOHrDneMgsqCxjpSmP):
  try:
   KYtodJLuQahViOHrDneMgsqCxjpSPX=KYtodJLuQahViOHrDneMgsqCxjpSXR
   KYtodJLuQahViOHrDneMgsqCxjpSPm=KYtodJLuQahViOHrDneMgsqCxjpSXv.Load_Searched_List() 
   KYtodJLuQahViOHrDneMgsqCxjpSPW={'skey':KYtodJLuQahViOHrDneMgsqCxjpSmP.strip()}
   fp=KYtodJLuQahViOHrDneMgsqCxjpSRP(KYtodJLuQahViOHrDneMgsqCxjpSPX,'w',-1,'utf-8')
   KYtodJLuQahViOHrDneMgsqCxjpSPR=urllib.parse.urlencode(KYtodJLuQahViOHrDneMgsqCxjpSPW)
   KYtodJLuQahViOHrDneMgsqCxjpSPR=KYtodJLuQahViOHrDneMgsqCxjpSPR+'\n'
   fp.write(KYtodJLuQahViOHrDneMgsqCxjpSPR)
   KYtodJLuQahViOHrDneMgsqCxjpSPv=0
   for KYtodJLuQahViOHrDneMgsqCxjpSPb in KYtodJLuQahViOHrDneMgsqCxjpSPm:
    KYtodJLuQahViOHrDneMgsqCxjpSPF=KYtodJLuQahViOHrDneMgsqCxjpSRX(urllib.parse.parse_qsl(KYtodJLuQahViOHrDneMgsqCxjpSPb))
    KYtodJLuQahViOHrDneMgsqCxjpSPz=KYtodJLuQahViOHrDneMgsqCxjpSPW.get('skey').strip()
    KYtodJLuQahViOHrDneMgsqCxjpSPA=KYtodJLuQahViOHrDneMgsqCxjpSPF.get('skey').strip()
    if KYtodJLuQahViOHrDneMgsqCxjpSPz!=KYtodJLuQahViOHrDneMgsqCxjpSPA:
     fp.write(KYtodJLuQahViOHrDneMgsqCxjpSPb)
     KYtodJLuQahViOHrDneMgsqCxjpSPv+=1
     if KYtodJLuQahViOHrDneMgsqCxjpSPv>=50:break
   fp.close()
  except:
   KYtodJLuQahViOHrDneMgsqCxjpSWU
 def dp_Search_History(KYtodJLuQahViOHrDneMgsqCxjpSXv,args):
  KYtodJLuQahViOHrDneMgsqCxjpSPy=KYtodJLuQahViOHrDneMgsqCxjpSXv.Load_Searched_List()
  for KYtodJLuQahViOHrDneMgsqCxjpSPB in KYtodJLuQahViOHrDneMgsqCxjpSPy:
   KYtodJLuQahViOHrDneMgsqCxjpSPc=KYtodJLuQahViOHrDneMgsqCxjpSRX(urllib.parse.parse_qsl(KYtodJLuQahViOHrDneMgsqCxjpSPB))
   KYtodJLuQahViOHrDneMgsqCxjpSPl=KYtodJLuQahViOHrDneMgsqCxjpSPc.get('skey').strip()
   KYtodJLuQahViOHrDneMgsqCxjpSPN={'mode':'TOTAL_SEARCH','search_key':KYtodJLuQahViOHrDneMgsqCxjpSPl,}
   KYtodJLuQahViOHrDneMgsqCxjpSPf={'mode':'HISTORY_REMOVE','skey':KYtodJLuQahViOHrDneMgsqCxjpSPl,'delmode':'ONE',}
   KYtodJLuQahViOHrDneMgsqCxjpSPE=urllib.parse.urlencode(KYtodJLuQahViOHrDneMgsqCxjpSPf)
   KYtodJLuQahViOHrDneMgsqCxjpSPw=[('선택된 검색어 ( %s ) 삭제'%(KYtodJLuQahViOHrDneMgsqCxjpSPl),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(KYtodJLuQahViOHrDneMgsqCxjpSPE))]
   KYtodJLuQahViOHrDneMgsqCxjpSXv.add_dir(KYtodJLuQahViOHrDneMgsqCxjpSPl,sublabel='',img=KYtodJLuQahViOHrDneMgsqCxjpSWU,infoLabels=KYtodJLuQahViOHrDneMgsqCxjpSWU,isFolder=KYtodJLuQahViOHrDneMgsqCxjpSWG,params=KYtodJLuQahViOHrDneMgsqCxjpSPN,ContextMenu=KYtodJLuQahViOHrDneMgsqCxjpSPw)
  KYtodJLuQahViOHrDneMgsqCxjpSPG={'plot':'검색목록 전체를 삭제합니다.'}
  KYtodJLuQahViOHrDneMgsqCxjpSXk='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  KYtodJLuQahViOHrDneMgsqCxjpSPN={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  KYtodJLuQahViOHrDneMgsqCxjpSPk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  KYtodJLuQahViOHrDneMgsqCxjpSXv.add_dir(KYtodJLuQahViOHrDneMgsqCxjpSXk,sublabel='',img=KYtodJLuQahViOHrDneMgsqCxjpSPk,infoLabels=KYtodJLuQahViOHrDneMgsqCxjpSPG,isFolder=KYtodJLuQahViOHrDneMgsqCxjpSWk,params=KYtodJLuQahViOHrDneMgsqCxjpSPN,isLink=KYtodJLuQahViOHrDneMgsqCxjpSWG)
  xbmcplugin.endOfDirectory(KYtodJLuQahViOHrDneMgsqCxjpSXv._addon_handle,cacheToDisc=KYtodJLuQahViOHrDneMgsqCxjpSWk)
 def Delete_History_List(KYtodJLuQahViOHrDneMgsqCxjpSXv,KYtodJLuQahViOHrDneMgsqCxjpSPl,KYtodJLuQahViOHrDneMgsqCxjpSTP):
  if KYtodJLuQahViOHrDneMgsqCxjpSTP=='ALL':
   try:
    KYtodJLuQahViOHrDneMgsqCxjpSPX=KYtodJLuQahViOHrDneMgsqCxjpSXR
    fp=KYtodJLuQahViOHrDneMgsqCxjpSRP(KYtodJLuQahViOHrDneMgsqCxjpSPX,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    KYtodJLuQahViOHrDneMgsqCxjpSWU
  else:
   try:
    KYtodJLuQahViOHrDneMgsqCxjpSPX=KYtodJLuQahViOHrDneMgsqCxjpSXR
    KYtodJLuQahViOHrDneMgsqCxjpSPm=KYtodJLuQahViOHrDneMgsqCxjpSXv.Load_Searched_List() 
    fp=KYtodJLuQahViOHrDneMgsqCxjpSRP(KYtodJLuQahViOHrDneMgsqCxjpSPX,'w',-1,'utf-8')
    for KYtodJLuQahViOHrDneMgsqCxjpSPb in KYtodJLuQahViOHrDneMgsqCxjpSPm:
     KYtodJLuQahViOHrDneMgsqCxjpSPF=KYtodJLuQahViOHrDneMgsqCxjpSRX(urllib.parse.parse_qsl(KYtodJLuQahViOHrDneMgsqCxjpSPb))
     KYtodJLuQahViOHrDneMgsqCxjpSTX=KYtodJLuQahViOHrDneMgsqCxjpSPF.get('skey').strip()
     if KYtodJLuQahViOHrDneMgsqCxjpSPl!=KYtodJLuQahViOHrDneMgsqCxjpSTX:
      fp.write(KYtodJLuQahViOHrDneMgsqCxjpSPb)
    fp.close()
   except:
    KYtodJLuQahViOHrDneMgsqCxjpSWU
 def dp_History_Delete(KYtodJLuQahViOHrDneMgsqCxjpSXv,args):
  KYtodJLuQahViOHrDneMgsqCxjpSPl =args.get('skey') 
  KYtodJLuQahViOHrDneMgsqCxjpSTP=args.get('delmode')
  KYtodJLuQahViOHrDneMgsqCxjpSXy=xbmcgui.Dialog()
  if KYtodJLuQahViOHrDneMgsqCxjpSTP=='ALL':
   KYtodJLuQahViOHrDneMgsqCxjpSTm=KYtodJLuQahViOHrDneMgsqCxjpSXy.yesno(__language__(30913).encode('utf8'),__language__(30915).encode('utf8'))
  else:
   KYtodJLuQahViOHrDneMgsqCxjpSTm=KYtodJLuQahViOHrDneMgsqCxjpSXy.yesno(__language__(30914).encode('utf8'),__language__(30915).encode('utf8'))
  if KYtodJLuQahViOHrDneMgsqCxjpSTm==KYtodJLuQahViOHrDneMgsqCxjpSWk:sys.exit()
  KYtodJLuQahViOHrDneMgsqCxjpSXv.Delete_History_List(KYtodJLuQahViOHrDneMgsqCxjpSPl,KYtodJLuQahViOHrDneMgsqCxjpSTP)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(KYtodJLuQahViOHrDneMgsqCxjpSXv):
  KYtodJLuQahViOHrDneMgsqCxjpSXN=KYtodJLuQahViOHrDneMgsqCxjpSXv.get_settings_menubookmark()
  for KYtodJLuQahViOHrDneMgsqCxjpSTW in KYtodJLuQahViOHrDneMgsqCxjpSXT:
   KYtodJLuQahViOHrDneMgsqCxjpSXk=KYtodJLuQahViOHrDneMgsqCxjpSTW.get('title')
   KYtodJLuQahViOHrDneMgsqCxjpSPk=''
   if KYtodJLuQahViOHrDneMgsqCxjpSTW.get('mode')=='MENU_BOOKMARK' and KYtodJLuQahViOHrDneMgsqCxjpSXN==KYtodJLuQahViOHrDneMgsqCxjpSWk:continue
   KYtodJLuQahViOHrDneMgsqCxjpSPN={'mode':KYtodJLuQahViOHrDneMgsqCxjpSTW.get('mode')}
   if KYtodJLuQahViOHrDneMgsqCxjpSTW.get('mode')in['XXX','MENU_BOOKMARK']:
    KYtodJLuQahViOHrDneMgsqCxjpSTR=KYtodJLuQahViOHrDneMgsqCxjpSWk
    KYtodJLuQahViOHrDneMgsqCxjpSTv =KYtodJLuQahViOHrDneMgsqCxjpSWG
   else:
    KYtodJLuQahViOHrDneMgsqCxjpSTR=KYtodJLuQahViOHrDneMgsqCxjpSWG
    KYtodJLuQahViOHrDneMgsqCxjpSTv =KYtodJLuQahViOHrDneMgsqCxjpSWk
   if 'icon' in KYtodJLuQahViOHrDneMgsqCxjpSTW:KYtodJLuQahViOHrDneMgsqCxjpSPk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',KYtodJLuQahViOHrDneMgsqCxjpSTW.get('icon')) 
   KYtodJLuQahViOHrDneMgsqCxjpSXv.add_dir(KYtodJLuQahViOHrDneMgsqCxjpSXk,sublabel='',img=KYtodJLuQahViOHrDneMgsqCxjpSPk,infoLabels=KYtodJLuQahViOHrDneMgsqCxjpSWU,isFolder=KYtodJLuQahViOHrDneMgsqCxjpSTR,params=KYtodJLuQahViOHrDneMgsqCxjpSPN,isLink=KYtodJLuQahViOHrDneMgsqCxjpSTv)
  xbmcplugin.endOfDirectory(KYtodJLuQahViOHrDneMgsqCxjpSXv._addon_handle)
 def option_check(KYtodJLuQahViOHrDneMgsqCxjpSXv):
  KYtodJLuQahViOHrDneMgsqCxjpSXf=KYtodJLuQahViOHrDneMgsqCxjpSXv.get_settings_select_info()
  if KYtodJLuQahViOHrDneMgsqCxjpSRT(KYtodJLuQahViOHrDneMgsqCxjpSXf)==0:
   KYtodJLuQahViOHrDneMgsqCxjpSXy=xbmcgui.Dialog()
   KYtodJLuQahViOHrDneMgsqCxjpSTm=KYtodJLuQahViOHrDneMgsqCxjpSXy.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if KYtodJLuQahViOHrDneMgsqCxjpSTm==KYtodJLuQahViOHrDneMgsqCxjpSWG:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in KYtodJLuQahViOHrDneMgsqCxjpSXf:
   (KYtodJLuQahViOHrDneMgsqCxjpSTb,KYtodJLuQahViOHrDneMgsqCxjpSTF,KYtodJLuQahViOHrDneMgsqCxjpSTz)=KYtodJLuQahViOHrDneMgsqCxjpSXv.get_settings_netflix()
   if KYtodJLuQahViOHrDneMgsqCxjpSTb=='' or KYtodJLuQahViOHrDneMgsqCxjpSTF=='':
    KYtodJLuQahViOHrDneMgsqCxjpSXy=xbmcgui.Dialog()
    KYtodJLuQahViOHrDneMgsqCxjpSTm=KYtodJLuQahViOHrDneMgsqCxjpSXy.yesno(__language__(30902).encode('utf8'),__language__(30903).encode('utf8'))
    if KYtodJLuQahViOHrDneMgsqCxjpSTm==KYtodJLuQahViOHrDneMgsqCxjpSWG:
     __addon__.openSettings()
     sys.exit()
    else:
     sys.exit()
   if KYtodJLuQahViOHrDneMgsqCxjpSXv.NF_cookiefile_check()==KYtodJLuQahViOHrDneMgsqCxjpSWk:
    KYtodJLuQahViOHrDneMgsqCxjpSXy=xbmcgui.Dialog()
    KYtodJLuQahViOHrDneMgsqCxjpSTm=KYtodJLuQahViOHrDneMgsqCxjpSXy.yesno(__language__(30907).encode('utf8'),__language__(30916).encode('utf8'))
    if KYtodJLuQahViOHrDneMgsqCxjpSTm==KYtodJLuQahViOHrDneMgsqCxjpSWG:
     if KYtodJLuQahViOHrDneMgsqCxjpSXv.NF_login(inputCheck=KYtodJLuQahViOHrDneMgsqCxjpSWk)==KYtodJLuQahViOHrDneMgsqCxjpSWk:
      sys.exit()
    else:
     sys.exit()
 def NF_cookiefile_check(KYtodJLuQahViOHrDneMgsqCxjpSXv):
  KYtodJLuQahViOHrDneMgsqCxjpSTA={}
  try: 
   fp=KYtodJLuQahViOHrDneMgsqCxjpSRP(KYtodJLuQahViOHrDneMgsqCxjpSXW,'r',-1,'utf-8')
   KYtodJLuQahViOHrDneMgsqCxjpSTA= json.load(fp)
   fp.close()
  except KYtodJLuQahViOHrDneMgsqCxjpSRm as exception:
   return KYtodJLuQahViOHrDneMgsqCxjpSWk
  KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.NF=KYtodJLuQahViOHrDneMgsqCxjpSTA
  (KYtodJLuQahViOHrDneMgsqCxjpSTb,KYtodJLuQahViOHrDneMgsqCxjpSTF,KYtodJLuQahViOHrDneMgsqCxjpSTz)=KYtodJLuQahViOHrDneMgsqCxjpSXv.get_settings_netflix()
  (KYtodJLuQahViOHrDneMgsqCxjpSTy,KYtodJLuQahViOHrDneMgsqCxjpSTB,KYtodJLuQahViOHrDneMgsqCxjpSTc)=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Load_session_acount()
  if KYtodJLuQahViOHrDneMgsqCxjpSTb!=KYtodJLuQahViOHrDneMgsqCxjpSTy or KYtodJLuQahViOHrDneMgsqCxjpSTF!=KYtodJLuQahViOHrDneMgsqCxjpSTB or KYtodJLuQahViOHrDneMgsqCxjpSTz!=KYtodJLuQahViOHrDneMgsqCxjpSRW(KYtodJLuQahViOHrDneMgsqCxjpSTc):
   KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Init_NF_Total()
   return KYtodJLuQahViOHrDneMgsqCxjpSWk
  return KYtodJLuQahViOHrDneMgsqCxjpSWG
 def NF_login(KYtodJLuQahViOHrDneMgsqCxjpSXv,inputCheck=KYtodJLuQahViOHrDneMgsqCxjpSWG):
  (KYtodJLuQahViOHrDneMgsqCxjpSTl,KYtodJLuQahViOHrDneMgsqCxjpSTN,KYtodJLuQahViOHrDneMgsqCxjpSTf)=KYtodJLuQahViOHrDneMgsqCxjpSXv.get_settings_netflix()
  if inputCheck==KYtodJLuQahViOHrDneMgsqCxjpSWG:
   if KYtodJLuQahViOHrDneMgsqCxjpSTl=='' or KYtodJLuQahViOHrDneMgsqCxjpSTN=='':
    KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_noti(__language__(30902).encode('utf-8'))
    return KYtodJLuQahViOHrDneMgsqCxjpSWk
   KYtodJLuQahViOHrDneMgsqCxjpSXy=xbmcgui.Dialog()
   KYtodJLuQahViOHrDneMgsqCxjpSTm=KYtodJLuQahViOHrDneMgsqCxjpSXy.yesno(__language__(30911).encode('utf8'),__language__(30912).encode('utf8'))
   if KYtodJLuQahViOHrDneMgsqCxjpSTm==KYtodJLuQahViOHrDneMgsqCxjpSWk:
    return KYtodJLuQahViOHrDneMgsqCxjpSWk 
  KYtodJLuQahViOHrDneMgsqCxjpSTE=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_NF_BaseCookies()
  if KYtodJLuQahViOHrDneMgsqCxjpSTE:
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_log('pass1 ok!')
  else:
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_log('pass1 error!')
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_noti(__language__(30905).encode('utf-8'))
   return KYtodJLuQahViOHrDneMgsqCxjpSWk 
  KYtodJLuQahViOHrDneMgsqCxjpSTE=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_NF_BaseLogin(KYtodJLuQahViOHrDneMgsqCxjpSTl,KYtodJLuQahViOHrDneMgsqCxjpSTN,KYtodJLuQahViOHrDneMgsqCxjpSTf)
  if KYtodJLuQahViOHrDneMgsqCxjpSTE:
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_log('pass2 ok!')
  else:
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_log('pass2 error!')
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_noti(__language__(30905).encode('utf-8'))
   return KYtodJLuQahViOHrDneMgsqCxjpSWk 
  KYtodJLuQahViOHrDneMgsqCxjpSTE=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_NF_ActivateProfile()
  if KYtodJLuQahViOHrDneMgsqCxjpSTE:
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_log('pass3 ok!')
  else:
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_log('pass3 error!')
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_noti(__language__(30905).encode('utf-8'))
   return KYtodJLuQahViOHrDneMgsqCxjpSWk 
  KYtodJLuQahViOHrDneMgsqCxjpSTE=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_NF_BrowseMain()
  if KYtodJLuQahViOHrDneMgsqCxjpSTE:
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_log('pass4 ok!')
  else:
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_log('pass4 error!')
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_noti(__language__(30905).encode('utf-8'))
   return KYtodJLuQahViOHrDneMgsqCxjpSWk 
  KYtodJLuQahViOHrDneMgsqCxjpSTw =KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_Now_Datetime()
  KYtodJLuQahViOHrDneMgsqCxjpSTU=KYtodJLuQahViOHrDneMgsqCxjpSTw+datetime.timedelta(days=KYtodJLuQahViOHrDneMgsqCxjpSRv(__addon__.getSetting('cache_ttl')))
  KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.NF['SESSION']['limitdate']=KYtodJLuQahViOHrDneMgsqCxjpSTU.strftime('%Y-%m-%d')
  try: 
   fp=KYtodJLuQahViOHrDneMgsqCxjpSRP(KYtodJLuQahViOHrDneMgsqCxjpSXW,'w',-1,'utf-8')
   json.dump(KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.NF,fp,indent=4,ensure_ascii=KYtodJLuQahViOHrDneMgsqCxjpSWk)
   fp.close()
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_log('pass5 save ok!')
  except KYtodJLuQahViOHrDneMgsqCxjpSRm as exception:
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_log('pass5 save error!')
   KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_noti(__language__(30905).encode('utf-8'))
   return KYtodJLuQahViOHrDneMgsqCxjpSWk
  KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_noti(__language__(30904).encode('utf-8'))
  return KYtodJLuQahViOHrDneMgsqCxjpSWG
 def NF_logout(KYtodJLuQahViOHrDneMgsqCxjpSXv):
  KYtodJLuQahViOHrDneMgsqCxjpSXy=xbmcgui.Dialog()
  KYtodJLuQahViOHrDneMgsqCxjpSTm=KYtodJLuQahViOHrDneMgsqCxjpSXy.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if KYtodJLuQahViOHrDneMgsqCxjpSTm==KYtodJLuQahViOHrDneMgsqCxjpSWk:return 
  if os.path.isfile(KYtodJLuQahViOHrDneMgsqCxjpSXW):os.remove(KYtodJLuQahViOHrDneMgsqCxjpSXW)
  KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(KYtodJLuQahViOHrDneMgsqCxjpSXv,KYtodJLuQahViOHrDneMgsqCxjpSmT):
  KYtodJLuQahViOHrDneMgsqCxjpSTk=''
  KYtodJLuQahViOHrDneMgsqCxjpSTI=7
  try:
   for i in KYtodJLuQahViOHrDneMgsqCxjpSRb(KYtodJLuQahViOHrDneMgsqCxjpSRT(KYtodJLuQahViOHrDneMgsqCxjpSmT)):
    if i>=KYtodJLuQahViOHrDneMgsqCxjpSTI:
     KYtodJLuQahViOHrDneMgsqCxjpSTk=KYtodJLuQahViOHrDneMgsqCxjpSTk+'...'
     break
    KYtodJLuQahViOHrDneMgsqCxjpSTk=KYtodJLuQahViOHrDneMgsqCxjpSTk+KYtodJLuQahViOHrDneMgsqCxjpSmT[i]['title']+'\n'
  except:
   return ''
  return KYtodJLuQahViOHrDneMgsqCxjpSTk
 def dp_Search_Group(KYtodJLuQahViOHrDneMgsqCxjpSXv,args):
  KYtodJLuQahViOHrDneMgsqCxjpSXf =KYtodJLuQahViOHrDneMgsqCxjpSXv.get_settings_select_info()
  KYtodJLuQahViOHrDneMgsqCxjpSmX=[]
  if 'search_key' in args:
   KYtodJLuQahViOHrDneMgsqCxjpSmP=args.get('search_key')
  else:
   KYtodJLuQahViOHrDneMgsqCxjpSmP=KYtodJLuQahViOHrDneMgsqCxjpSXv.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not KYtodJLuQahViOHrDneMgsqCxjpSmP:
    xbmcplugin.endOfDirectory(KYtodJLuQahViOHrDneMgsqCxjpSXv._addon_handle)
    return
  if 'wavve' in KYtodJLuQahViOHrDneMgsqCxjpSXf:
   (KYtodJLuQahViOHrDneMgsqCxjpSmT,KYtodJLuQahViOHrDneMgsqCxjpSmW)=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_Search_Wavve(KYtodJLuQahViOHrDneMgsqCxjpSmP,'TVSHOW',1)
   if KYtodJLuQahViOHrDneMgsqCxjpSRT(KYtodJLuQahViOHrDneMgsqCxjpSmT)>0:
    KYtodJLuQahViOHrDneMgsqCxjpSmR={'sType':'wavve_tvshow','sList':KYtodJLuQahViOHrDneMgsqCxjpSXv.MakeText_FreeList(KYtodJLuQahViOHrDneMgsqCxjpSmT),}
    KYtodJLuQahViOHrDneMgsqCxjpSmX.append(KYtodJLuQahViOHrDneMgsqCxjpSmR)
   (KYtodJLuQahViOHrDneMgsqCxjpSmT,KYtodJLuQahViOHrDneMgsqCxjpSmW)=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_Search_Wavve(KYtodJLuQahViOHrDneMgsqCxjpSmP,'MOVIE',1)
   if KYtodJLuQahViOHrDneMgsqCxjpSRT(KYtodJLuQahViOHrDneMgsqCxjpSmT)>0:
    KYtodJLuQahViOHrDneMgsqCxjpSmR={'sType':'wavve_movie','sList':KYtodJLuQahViOHrDneMgsqCxjpSXv.MakeText_FreeList(KYtodJLuQahViOHrDneMgsqCxjpSmT),}
    KYtodJLuQahViOHrDneMgsqCxjpSmX.append(KYtodJLuQahViOHrDneMgsqCxjpSmR)
  if 'tving' in KYtodJLuQahViOHrDneMgsqCxjpSXf:
   (KYtodJLuQahViOHrDneMgsqCxjpSmT,KYtodJLuQahViOHrDneMgsqCxjpSmW)=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_Search_Tving(KYtodJLuQahViOHrDneMgsqCxjpSmP,'TVSHOW',1)
   if KYtodJLuQahViOHrDneMgsqCxjpSRT(KYtodJLuQahViOHrDneMgsqCxjpSmT)>0:
    KYtodJLuQahViOHrDneMgsqCxjpSmR={'sType':'tving_tvshow','sList':KYtodJLuQahViOHrDneMgsqCxjpSXv.MakeText_FreeList(KYtodJLuQahViOHrDneMgsqCxjpSmT),}
    KYtodJLuQahViOHrDneMgsqCxjpSmX.append(KYtodJLuQahViOHrDneMgsqCxjpSmR)
   (KYtodJLuQahViOHrDneMgsqCxjpSmT,KYtodJLuQahViOHrDneMgsqCxjpSmW)=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_Search_Tving(KYtodJLuQahViOHrDneMgsqCxjpSmP,'MOVIE',1)
   if KYtodJLuQahViOHrDneMgsqCxjpSRT(KYtodJLuQahViOHrDneMgsqCxjpSmT)>0:
    KYtodJLuQahViOHrDneMgsqCxjpSmR={'sType':'tving_movie','sList':KYtodJLuQahViOHrDneMgsqCxjpSXv.MakeText_FreeList(KYtodJLuQahViOHrDneMgsqCxjpSmT),}
    KYtodJLuQahViOHrDneMgsqCxjpSmX.append(KYtodJLuQahViOHrDneMgsqCxjpSmR)
  if 'watcha' in KYtodJLuQahViOHrDneMgsqCxjpSXf:
   (KYtodJLuQahViOHrDneMgsqCxjpSmT,KYtodJLuQahViOHrDneMgsqCxjpSmW)=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_Search_Watcha(KYtodJLuQahViOHrDneMgsqCxjpSmP,1)
   if KYtodJLuQahViOHrDneMgsqCxjpSRT(KYtodJLuQahViOHrDneMgsqCxjpSmT)>0:
    KYtodJLuQahViOHrDneMgsqCxjpSmR={'sType':'watcha_list','sList':KYtodJLuQahViOHrDneMgsqCxjpSXv.MakeText_FreeList(KYtodJLuQahViOHrDneMgsqCxjpSmT),}
    KYtodJLuQahViOHrDneMgsqCxjpSmX.append(KYtodJLuQahViOHrDneMgsqCxjpSmR)
  if 'netflix' in KYtodJLuQahViOHrDneMgsqCxjpSXf:
   (KYtodJLuQahViOHrDneMgsqCxjpSmT,KYtodJLuQahViOHrDneMgsqCxjpSmW,KYtodJLuQahViOHrDneMgsqCxjpSmv)=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_Search_Netflix(KYtodJLuQahViOHrDneMgsqCxjpSmP,1)
   if KYtodJLuQahViOHrDneMgsqCxjpSRT(KYtodJLuQahViOHrDneMgsqCxjpSmT)>0:
    KYtodJLuQahViOHrDneMgsqCxjpSmR={'sType':'netflix_list','sList':KYtodJLuQahViOHrDneMgsqCxjpSXv.MakeText_FreeList(KYtodJLuQahViOHrDneMgsqCxjpSmT),}
    KYtodJLuQahViOHrDneMgsqCxjpSmX.append(KYtodJLuQahViOHrDneMgsqCxjpSmR)
  for KYtodJLuQahViOHrDneMgsqCxjpSmb in KYtodJLuQahViOHrDneMgsqCxjpSmX:
   KYtodJLuQahViOHrDneMgsqCxjpSmF=KYtodJLuQahViOHrDneMgsqCxjpSXm[KYtodJLuQahViOHrDneMgsqCxjpSmb.get('sType')]
   KYtodJLuQahViOHrDneMgsqCxjpSmz={'plot':'검색어 : '+KYtodJLuQahViOHrDneMgsqCxjpSmP+'\n\n'+KYtodJLuQahViOHrDneMgsqCxjpSmb.get('sList')}
   KYtodJLuQahViOHrDneMgsqCxjpSXk=KYtodJLuQahViOHrDneMgsqCxjpSmF.get('title')
   KYtodJLuQahViOHrDneMgsqCxjpSPN={'mode':KYtodJLuQahViOHrDneMgsqCxjpSmF.get('mode'),'ott':KYtodJLuQahViOHrDneMgsqCxjpSmF.get('ott'),'vidtype':KYtodJLuQahViOHrDneMgsqCxjpSmF.get('vidtype'),'search_key':KYtodJLuQahViOHrDneMgsqCxjpSmP}
   if KYtodJLuQahViOHrDneMgsqCxjpSmF.get('ott')=='netflix':
    KYtodJLuQahViOHrDneMgsqCxjpSPN['page'] ='1'
    KYtodJLuQahViOHrDneMgsqCxjpSPN['byReference']='-'
   KYtodJLuQahViOHrDneMgsqCxjpSPk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',KYtodJLuQahViOHrDneMgsqCxjpSmF.get('icon'))
   KYtodJLuQahViOHrDneMgsqCxjpSTR=KYtodJLuQahViOHrDneMgsqCxjpSWG if KYtodJLuQahViOHrDneMgsqCxjpSmF.get('mode')!='HYPER_LINK' else KYtodJLuQahViOHrDneMgsqCxjpSWk
   KYtodJLuQahViOHrDneMgsqCxjpSXv.add_dir(KYtodJLuQahViOHrDneMgsqCxjpSXk,sublabel='',img=KYtodJLuQahViOHrDneMgsqCxjpSPk,infoLabels=KYtodJLuQahViOHrDneMgsqCxjpSmz,isFolder=KYtodJLuQahViOHrDneMgsqCxjpSTR,params=KYtodJLuQahViOHrDneMgsqCxjpSPN,isLink=KYtodJLuQahViOHrDneMgsqCxjpSWG)
  xbmcplugin.endOfDirectory(KYtodJLuQahViOHrDneMgsqCxjpSXv._addon_handle)
  KYtodJLuQahViOHrDneMgsqCxjpSXv.Save_Searched_List(KYtodJLuQahViOHrDneMgsqCxjpSmP)
 def dp_Hyper_Link(KYtodJLuQahViOHrDneMgsqCxjpSXv,args):
  KYtodJLuQahViOHrDneMgsqCxjpSmA =args.get('mode')
  KYtodJLuQahViOHrDneMgsqCxjpSmy =args.get('ott')
  KYtodJLuQahViOHrDneMgsqCxjpSmB =args.get('vidtype')
  KYtodJLuQahViOHrDneMgsqCxjpSmP=args.get('search_key')
  KYtodJLuQahViOHrDneMgsqCxjpSmc='-'
  if KYtodJLuQahViOHrDneMgsqCxjpSmy=='wavve':
   KYtodJLuQahViOHrDneMgsqCxjpSml={'mode':'LOCAL_SEARCH','sType':'movie' if KYtodJLuQahViOHrDneMgsqCxjpSmB=='MOVIE' else 'vod','search_key':KYtodJLuQahViOHrDneMgsqCxjpSmP,'page':'1',}
   KYtodJLuQahViOHrDneMgsqCxjpSmN=urllib.parse.urlencode(KYtodJLuQahViOHrDneMgsqCxjpSml)
   KYtodJLuQahViOHrDneMgsqCxjpSmc='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(KYtodJLuQahViOHrDneMgsqCxjpSmN)
  elif KYtodJLuQahViOHrDneMgsqCxjpSmy=='tving':
   KYtodJLuQahViOHrDneMgsqCxjpSml={'mode':'LOCAL_SEARCH','stype':'movie' if KYtodJLuQahViOHrDneMgsqCxjpSmB=='MOVIE' else 'vod','search_key':KYtodJLuQahViOHrDneMgsqCxjpSmP,'page':'1',}
   KYtodJLuQahViOHrDneMgsqCxjpSmN=urllib.parse.urlencode(KYtodJLuQahViOHrDneMgsqCxjpSml)
   KYtodJLuQahViOHrDneMgsqCxjpSmc='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(KYtodJLuQahViOHrDneMgsqCxjpSmN)
  elif KYtodJLuQahViOHrDneMgsqCxjpSmy=='watcha':
   KYtodJLuQahViOHrDneMgsqCxjpSml={'mode':'LOCAL_SEARCH','search_key':KYtodJLuQahViOHrDneMgsqCxjpSmP,'page':'1',}
   KYtodJLuQahViOHrDneMgsqCxjpSmN=urllib.parse.urlencode(KYtodJLuQahViOHrDneMgsqCxjpSml)
   KYtodJLuQahViOHrDneMgsqCxjpSmc='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(KYtodJLuQahViOHrDneMgsqCxjpSmN)
  elif KYtodJLuQahViOHrDneMgsqCxjpSmy=='netflix':
   KYtodJLuQahViOHrDneMgsqCxjpSmf=args.get('videoid')
   KYtodJLuQahViOHrDneMgsqCxjpSmE=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.NF['SESSION']['nowGuid']
   if KYtodJLuQahViOHrDneMgsqCxjpSmB=='TVSHOW':
    KYtodJLuQahViOHrDneMgsqCxjpSmc='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(KYtodJLuQahViOHrDneMgsqCxjpSmf)
   else:
    KYtodJLuQahViOHrDneMgsqCxjpSmc='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(KYtodJLuQahViOHrDneMgsqCxjpSmf,KYtodJLuQahViOHrDneMgsqCxjpSmE)
  KYtodJLuQahViOHrDneMgsqCxjpSXv.addon_log('ott_url ==> ( '+KYtodJLuQahViOHrDneMgsqCxjpSmc+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(KYtodJLuQahViOHrDneMgsqCxjpSmc)
 def dp_Nf_Search(KYtodJLuQahViOHrDneMgsqCxjpSXv,args):
  KYtodJLuQahViOHrDneMgsqCxjpSmw =KYtodJLuQahViOHrDneMgsqCxjpSRv(args.get('page'))
  KYtodJLuQahViOHrDneMgsqCxjpSmP =args.get('search_key')
  KYtodJLuQahViOHrDneMgsqCxjpSmv=args.get('byReference')
  (KYtodJLuQahViOHrDneMgsqCxjpSmT,KYtodJLuQahViOHrDneMgsqCxjpSmW,KYtodJLuQahViOHrDneMgsqCxjpSmv)=KYtodJLuQahViOHrDneMgsqCxjpSXv.SearchObj.Get_Search_Netflix(KYtodJLuQahViOHrDneMgsqCxjpSmP,KYtodJLuQahViOHrDneMgsqCxjpSmw,byReference=KYtodJLuQahViOHrDneMgsqCxjpSmv)
  for KYtodJLuQahViOHrDneMgsqCxjpSmU in KYtodJLuQahViOHrDneMgsqCxjpSmT:
   KYtodJLuQahViOHrDneMgsqCxjpSmf =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('videoid')
   KYtodJLuQahViOHrDneMgsqCxjpSmB =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('vidtype')
   KYtodJLuQahViOHrDneMgsqCxjpSXk =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('title')
   KYtodJLuQahViOHrDneMgsqCxjpSmG =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('mpaa')
   KYtodJLuQahViOHrDneMgsqCxjpSmk =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('regularSynopsis')
   KYtodJLuQahViOHrDneMgsqCxjpSmI =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('dpSupplemental')
   KYtodJLuQahViOHrDneMgsqCxjpSWX=KYtodJLuQahViOHrDneMgsqCxjpSmU.get('sequiturEvidence')
   KYtodJLuQahViOHrDneMgsqCxjpSWP =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('thumbnail')
   KYtodJLuQahViOHrDneMgsqCxjpSWT =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('year')
   KYtodJLuQahViOHrDneMgsqCxjpSWm =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('duration')
   KYtodJLuQahViOHrDneMgsqCxjpSWR =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('info_genre')
   KYtodJLuQahViOHrDneMgsqCxjpSWv =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('director')
   KYtodJLuQahViOHrDneMgsqCxjpSWb =KYtodJLuQahViOHrDneMgsqCxjpSmU.get('cast')
   if KYtodJLuQahViOHrDneMgsqCxjpSmB=='movie':
    KYtodJLuQahViOHrDneMgsqCxjpSPU=' (%s)'%(KYtodJLuQahViOHrDneMgsqCxjpSRW(KYtodJLuQahViOHrDneMgsqCxjpSWT))
   else:
    KYtodJLuQahViOHrDneMgsqCxjpSPU=''
   KYtodJLuQahViOHrDneMgsqCxjpSWF=''
   if KYtodJLuQahViOHrDneMgsqCxjpSmk:KYtodJLuQahViOHrDneMgsqCxjpSWF=KYtodJLuQahViOHrDneMgsqCxjpSWF+'\n\n'+KYtodJLuQahViOHrDneMgsqCxjpSmk
   if KYtodJLuQahViOHrDneMgsqCxjpSmI :KYtodJLuQahViOHrDneMgsqCxjpSWF=KYtodJLuQahViOHrDneMgsqCxjpSWF+'\n\n'+KYtodJLuQahViOHrDneMgsqCxjpSmI
   if KYtodJLuQahViOHrDneMgsqCxjpSWX:KYtodJLuQahViOHrDneMgsqCxjpSWF=KYtodJLuQahViOHrDneMgsqCxjpSWF+'\n\n'+KYtodJLuQahViOHrDneMgsqCxjpSWX
   KYtodJLuQahViOHrDneMgsqCxjpSWF=KYtodJLuQahViOHrDneMgsqCxjpSWF.strip()
   KYtodJLuQahViOHrDneMgsqCxjpSPG={'mediatype':'tvshow' if KYtodJLuQahViOHrDneMgsqCxjpSmB=='show' else 'movie','title':KYtodJLuQahViOHrDneMgsqCxjpSXk,'mpaa':KYtodJLuQahViOHrDneMgsqCxjpSmG,'plot':KYtodJLuQahViOHrDneMgsqCxjpSWF,'duration':KYtodJLuQahViOHrDneMgsqCxjpSWm,'genre':KYtodJLuQahViOHrDneMgsqCxjpSWR,'director':KYtodJLuQahViOHrDneMgsqCxjpSWv,'cast':KYtodJLuQahViOHrDneMgsqCxjpSWb,'year':KYtodJLuQahViOHrDneMgsqCxjpSWT,}
   KYtodJLuQahViOHrDneMgsqCxjpSPN={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if KYtodJLuQahViOHrDneMgsqCxjpSmB=='show' else 'MOVIE','videoid':KYtodJLuQahViOHrDneMgsqCxjpSmf,}
   if KYtodJLuQahViOHrDneMgsqCxjpSXv.get_settings_makebookmark():
    KYtodJLuQahViOHrDneMgsqCxjpSWz={'videoid':KYtodJLuQahViOHrDneMgsqCxjpSmf,'vidtype':'tvshow' if KYtodJLuQahViOHrDneMgsqCxjpSmB=='show' else 'movie','vtitle':KYtodJLuQahViOHrDneMgsqCxjpSXk+KYtodJLuQahViOHrDneMgsqCxjpSPU,'vsubtitle':'','vinfo':KYtodJLuQahViOHrDneMgsqCxjpSPG,'thumbnail':KYtodJLuQahViOHrDneMgsqCxjpSWP,}
    KYtodJLuQahViOHrDneMgsqCxjpSWA=json.dumps(KYtodJLuQahViOHrDneMgsqCxjpSWz)
    KYtodJLuQahViOHrDneMgsqCxjpSWA=urllib.parse.quote(KYtodJLuQahViOHrDneMgsqCxjpSWA)
    KYtodJLuQahViOHrDneMgsqCxjpSWy='RunPlugin(plugin://plugin.video.searchm/?mode=SET_BOOKMARK&bm_param=%s)'%(KYtodJLuQahViOHrDneMgsqCxjpSWA)
    KYtodJLuQahViOHrDneMgsqCxjpSPw=[('(통합) 찜 영상에 추가',KYtodJLuQahViOHrDneMgsqCxjpSWy)]
   else:
    KYtodJLuQahViOHrDneMgsqCxjpSPw=KYtodJLuQahViOHrDneMgsqCxjpSWU
   KYtodJLuQahViOHrDneMgsqCxjpSXv.add_dir(KYtodJLuQahViOHrDneMgsqCxjpSXk+KYtodJLuQahViOHrDneMgsqCxjpSPU,sublabel=KYtodJLuQahViOHrDneMgsqCxjpSWU,img=KYtodJLuQahViOHrDneMgsqCxjpSWP,infoLabels=KYtodJLuQahViOHrDneMgsqCxjpSPG,isFolder=KYtodJLuQahViOHrDneMgsqCxjpSWk,params=KYtodJLuQahViOHrDneMgsqCxjpSPN,isLink=KYtodJLuQahViOHrDneMgsqCxjpSWG,ContextMenu=KYtodJLuQahViOHrDneMgsqCxjpSPw)
  if KYtodJLuQahViOHrDneMgsqCxjpSmW:
   KYtodJLuQahViOHrDneMgsqCxjpSPN={}
   KYtodJLuQahViOHrDneMgsqCxjpSPN['mode'] ='NF_SEARCH' 
   KYtodJLuQahViOHrDneMgsqCxjpSPN['page'] =KYtodJLuQahViOHrDneMgsqCxjpSRW(KYtodJLuQahViOHrDneMgsqCxjpSmw+1)
   KYtodJLuQahViOHrDneMgsqCxjpSPN['search_key']=KYtodJLuQahViOHrDneMgsqCxjpSmP
   KYtodJLuQahViOHrDneMgsqCxjpSPN['byReference']=KYtodJLuQahViOHrDneMgsqCxjpSmv
   KYtodJLuQahViOHrDneMgsqCxjpSXk='[B]%s >>[/B]'%'다음 페이지'
   KYtodJLuQahViOHrDneMgsqCxjpSWB=KYtodJLuQahViOHrDneMgsqCxjpSRW(KYtodJLuQahViOHrDneMgsqCxjpSmw+1)
   KYtodJLuQahViOHrDneMgsqCxjpSPk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KYtodJLuQahViOHrDneMgsqCxjpSXv.add_dir(KYtodJLuQahViOHrDneMgsqCxjpSXk,sublabel=KYtodJLuQahViOHrDneMgsqCxjpSWB,img=KYtodJLuQahViOHrDneMgsqCxjpSPk,infoLabels=KYtodJLuQahViOHrDneMgsqCxjpSWU,isFolder=KYtodJLuQahViOHrDneMgsqCxjpSWG,params=KYtodJLuQahViOHrDneMgsqCxjpSPN)
  xbmcplugin.setContent(KYtodJLuQahViOHrDneMgsqCxjpSXv._addon_handle,'movies')
  xbmcplugin.endOfDirectory(KYtodJLuQahViOHrDneMgsqCxjpSXv._addon_handle)
 def dp_Bookmark_Menu(KYtodJLuQahViOHrDneMgsqCxjpSXv,args):
  KYtodJLuQahViOHrDneMgsqCxjpSmc='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(KYtodJLuQahViOHrDneMgsqCxjpSmc)
 def dp_Set_Bookmark(KYtodJLuQahViOHrDneMgsqCxjpSXv,args):
  KYtodJLuQahViOHrDneMgsqCxjpSWc=urllib.parse.unquote(args.get('bm_param'))
  KYtodJLuQahViOHrDneMgsqCxjpSWc=json.loads(KYtodJLuQahViOHrDneMgsqCxjpSWc)
  KYtodJLuQahViOHrDneMgsqCxjpSmf =KYtodJLuQahViOHrDneMgsqCxjpSWc.get('videoid')
  KYtodJLuQahViOHrDneMgsqCxjpSmB =KYtodJLuQahViOHrDneMgsqCxjpSWc.get('vidtype')
  KYtodJLuQahViOHrDneMgsqCxjpSWl =KYtodJLuQahViOHrDneMgsqCxjpSWc.get('vtitle')
  KYtodJLuQahViOHrDneMgsqCxjpSWN =KYtodJLuQahViOHrDneMgsqCxjpSWc.get('vsubtitle')
  KYtodJLuQahViOHrDneMgsqCxjpSWf =KYtodJLuQahViOHrDneMgsqCxjpSWc.get('vinfo')
  KYtodJLuQahViOHrDneMgsqCxjpSWP =KYtodJLuQahViOHrDneMgsqCxjpSWc.get('thumbnail')
  KYtodJLuQahViOHrDneMgsqCxjpSXy=xbmcgui.Dialog()
  KYtodJLuQahViOHrDneMgsqCxjpSTm=KYtodJLuQahViOHrDneMgsqCxjpSXy.yesno(__language__(30917).encode('utf8'),KYtodJLuQahViOHrDneMgsqCxjpSWl+' \n\n'+__language__(30918))
  if KYtodJLuQahViOHrDneMgsqCxjpSTm==KYtodJLuQahViOHrDneMgsqCxjpSWk:return
  KYtodJLuQahViOHrDneMgsqCxjpSWE={'indexinfo':{'ott':'netflix','videoid':KYtodJLuQahViOHrDneMgsqCxjpSmf,'vidtype':KYtodJLuQahViOHrDneMgsqCxjpSmB,},'saveinfo':{'title':KYtodJLuQahViOHrDneMgsqCxjpSWl,'subtitle':KYtodJLuQahViOHrDneMgsqCxjpSWN,'thumbnail':KYtodJLuQahViOHrDneMgsqCxjpSWP,'infoLabels':KYtodJLuQahViOHrDneMgsqCxjpSWf,},}
  KYtodJLuQahViOHrDneMgsqCxjpSWA=json.dumps(KYtodJLuQahViOHrDneMgsqCxjpSWE)
  KYtodJLuQahViOHrDneMgsqCxjpSWA=urllib.parse.quote(KYtodJLuQahViOHrDneMgsqCxjpSWA)
  KYtodJLuQahViOHrDneMgsqCxjpSWy='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(KYtodJLuQahViOHrDneMgsqCxjpSWA)
  xbmc.executebuiltin(KYtodJLuQahViOHrDneMgsqCxjpSWy)
 def search_main(KYtodJLuQahViOHrDneMgsqCxjpSXv):
  KYtodJLuQahViOHrDneMgsqCxjpSmA=KYtodJLuQahViOHrDneMgsqCxjpSXv.main_params.get('mode',KYtodJLuQahViOHrDneMgsqCxjpSWU)
  if KYtodJLuQahViOHrDneMgsqCxjpSmA=='NFLOGOUT':
   KYtodJLuQahViOHrDneMgsqCxjpSXv.NF_logout()
   return
  elif KYtodJLuQahViOHrDneMgsqCxjpSmA=='NFLOGIN':
   KYtodJLuQahViOHrDneMgsqCxjpSXv.NF_login()
   return
  KYtodJLuQahViOHrDneMgsqCxjpSXv.option_check()
  if KYtodJLuQahViOHrDneMgsqCxjpSmA is KYtodJLuQahViOHrDneMgsqCxjpSWU:
   KYtodJLuQahViOHrDneMgsqCxjpSXv.dp_Main_List()
  elif KYtodJLuQahViOHrDneMgsqCxjpSmA=='TOTAL_SEARCH':
   KYtodJLuQahViOHrDneMgsqCxjpSXv.dp_Search_Group(KYtodJLuQahViOHrDneMgsqCxjpSXv.main_params)
  elif KYtodJLuQahViOHrDneMgsqCxjpSmA=='HYPER_LINK':
   KYtodJLuQahViOHrDneMgsqCxjpSXv.dp_Hyper_Link(KYtodJLuQahViOHrDneMgsqCxjpSXv.main_params)
  elif KYtodJLuQahViOHrDneMgsqCxjpSmA=='NF_SEARCH':
   KYtodJLuQahViOHrDneMgsqCxjpSXv.dp_Nf_Search(KYtodJLuQahViOHrDneMgsqCxjpSXv.main_params)
  elif KYtodJLuQahViOHrDneMgsqCxjpSmA=='TOTAL_HISTORY':
   KYtodJLuQahViOHrDneMgsqCxjpSXv.dp_Search_History(KYtodJLuQahViOHrDneMgsqCxjpSXv.main_params)
  elif KYtodJLuQahViOHrDneMgsqCxjpSmA=='HISTORY_REMOVE':
   KYtodJLuQahViOHrDneMgsqCxjpSXv.dp_History_Delete(KYtodJLuQahViOHrDneMgsqCxjpSXv.main_params)
  elif KYtodJLuQahViOHrDneMgsqCxjpSmA=='MENU_BOOKMARK':
   KYtodJLuQahViOHrDneMgsqCxjpSXv.dp_Bookmark_Menu(KYtodJLuQahViOHrDneMgsqCxjpSXv.main_params)
  elif KYtodJLuQahViOHrDneMgsqCxjpSmA=='SET_BOOKMARK':
   KYtodJLuQahViOHrDneMgsqCxjpSXv.dp_Set_Bookmark(KYtodJLuQahViOHrDneMgsqCxjpSXv.main_params)
  else:
   KYtodJLuQahViOHrDneMgsqCxjpSWU
# Created by pyminifier (https://github.com/liftoff/pyminifier)
