# searchM-v19
 OTT 통합검색 애드온 for Kodi19 


## Version 2.0.4 (2021.04.02)
- 넷플릭스 변경관련 수정 (로그인 오류)

## Version 2.0.3 (2021.03.12)
- 통합 찜하기 기능 추가

## Version 2.0.2 (2021.03.07)
- contentType, 찜하기

## Version 2.0.1 (2021.02.22)
- 넷플릭스 검색 오류 수정

## Version 2.0.0 (2021.02.17)
- Initial addon version

