_A9='identifier'
_A8='containers'
_A7='SCREENCODE'
_A6='$type'
_A5='directors'
_A4='creators'
_A3='availability'
_A2='dpSupplementalMessage'
_A1='runtime'
_A0='releaseYear'
_z='accessToken'
_y='page'
_x='code'
_w='movie'
_v='program'
_u='accept'
_t='user-agent'
_s='png'
_r='LOGO_BRANDED_HORIZONTAL'
_q='artWorkByType'
_p='genres'
_o='cast'
_n='storyArt'
_m='interestingMoment'
_l='boxarts'
_k='maturity'
_j='regularSynopsis'
_i='authURL'
_h='utf-8'
_g='TVSHOW'
_f='POST'
_e='sequiturEvidence'
_d='summary'
_c='id'
_b='query'
_a='thumbnail'
_Z='text'
_Y='poster'
_X='url'
_W='type'
_V='false'
_U='account'
_T='name'
_S='GET'
_R='byTerm'
_Q='headers'
_P='byReference'
_O='abContext'
_N='true'
_M='data'
_L='jpg'
_K='COOKIES'
_J=True
_I='SESSION'
_H='reference'
_G='search'
_F=False
_E='to'
_D='from'
_C='title'
_B='value'
_A=None
__author__='NightRain'
import urllib,re,json,sys,time,requests,base64,datetime,pickle,os,http.cookiejar,httpx
'\nimport xbmcplugin, xbmcgui, xbmcaddon, xbmc, xbmcvfs\n__addon__ = xbmcaddon.Addon()\n__language__  = __addon__.getLocalizedString\n__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo(\'profile\'))\n__version__ = __addon__.getAddonInfo(\'version\')\n__addonid__ = __addon__.getAddonInfo(\'id\')\n__addonname__ = __addon__.getAddonInfo(\'name\')\n\n\ndef addon_log( string ):\n\ttry:\n\t\tlog_message = string.encode(\'utf-8\', \'ignore\')\n\texcept:\n\t\tlog_message = \'addonException: addon_log\'\n\tlevel = xbmc.LOGINFO\n\txbmc.log("[%s-%s]: %s" %(__addonid__, __version__, log_message), level=level)\n'
class Search:
	def __init__(A):B='no-cache';A.USER_AGENT='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36';A.API_WAVVE='https://apis.wavve.com';A.API_TVING_SEARCH='https://search-api.tving.com';A.API_TVING_IMG='https://image.tving.com';A.API_WATCHA='https://api-mars.watcha.com';A.API_NETFLIX='https://www.netflix.com';A.API_COUPANG='https://www.coupangplay.com';A.API_PRIMEV='https://www.primevideo.com';A.API_DISNEY='https://disney.api.edge.bamgrid.com/explore';A.API_DISNEY_VERSION='v1.11';A.WAVVE_LIMIT=20;A.TVING_LIMIT=30;A.WATCHA_LIMIT=30;A.NETFLIX_LIMIT=20;A.COUPANG_LIMIT=10;A.DISNEY_LIMIT=10;A.DERECTOR_LIMIT=4;A.CAST_LIMIT=10;A.GENRE_LIMIT=4;A.TVING_MOVIE_LITE=['2610061','2610161','261062'];A.WAVVE_PARAMS={'apikey':'E5F3E0D30947AA5440556471321BB6D9','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all','client_version':'7.1.40'};A.TVING_PARMAS={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900',_A7:'CSSD0100','APIKEY':'1e7952d0917d6aab1f0293a063697610','TELECODE':'CSCD0900'};A.WATCHA_HEADER={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'};A.NETFLIX_HEADER={_t:A.USER_AGENT,_u:'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':B,'pragma':B,'upgrade-insecure-requests':'1'};A.ART_SIZE_LAND1='_342x192';A.ART_SIZE_LAND2='_665x375';A.ART_SIZE_PORT='_342x684';A.ART_SIZE_LOGO='_550x124';A.NF={};A.NF[_K]={};A.NF[_I]={};A.DZ={};A.PV={};A.HTTP_CLIENT=requests.Session();A.CP_ORIGINAL_COOKIE='';A.PV_ORIGINAL_COOKIE='';A.DZ_ORIGINAL_COOKIE='';A.NF_ORIGINAL_COOKIE='';A.NF_SESSION_COOKIES1='';A.NF_SESSION_COOKIES2='';A.NF_SESSION_COOKIES3='';A.NF_SESSION_COOKIES4='';A.NF_SESSION_FULLTEXT1='';A.NF_SESSION_FULLTEXT2='';A.NF_SESSION_FULLTEXT3='';A.NF_SESSION_FULLTEXT4='';A.NF_CONTEXTJSON_FILE1='';A.NF_CONTEXTJSON_FILE2='';A.NF_CONTEXTJSON_FILE3='';A.NF_CONTEXTJSON_FILE4='';A.NF_FALCORJSON_FILE1='';A.NF_FALCORJSON_FILE2='';A.NF_FALCORJSON_FILE3='';A.NF_FALCORJSON_FILE4=''
	"\n\tdef callRequestCookies( self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):\n\t\t#setHeader = { 'user-agent' : self.USER_AGENT }\n\t\tsetHeader = self.DEFAULT_HEADER\n\t\tif headers: setHeader.update( headers )\n\n\t\tif jobtype == 'Get': # Get/Post\n\t\t\tres = requests.get( url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )\n\t\telse:\n\t\t\tres = requests.post( url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )\n\n\t\treturn res\n\t"
	def Call_Request_bak(B,url,payload=_A,json=_A,params=_A,headers=_A,cookies=_A,redirects=_J,method='-'):
		H=redirects;G=cookies;F=headers;E=params;D=payload;C={_t:B.USER_AGENT}
		if F:C.update(F)
		if D!=_A or method==_f:A=B.HTTP_CLIENT.post(url=url,data=D,json=json,params=E,headers=C,cookies=G,allow_redirects=H)
		else:A=B.HTTP_CLIENT.get(url=url,params=E,headers=C,cookies=G,allow_redirects=H)
		print(str(A.status_code)+' - '+str(A.url));return A
	def Call_Request(H,url,payload=_A,json=_A,params=_A,headers=_A,cookies=_A,redirects=_J,method='-'):
		G=redirects;F=cookies;E=headers;D=params;C=payload;B={_t:H.USER_AGENT}
		if E:B.update(E)
		if C!=_A or method==_f:A=httpx.post(url,data=C,json=json,params=D,headers=B,cookies=F,follow_redirects=G)
		else:A=httpx.get(url,params=D,headers=B,cookies=F,follow_redirects=G)
		print(str(A.status_code)+' - '+str(A.url));return A
	def GetNoCache(D,timetype=1,minutes=0):
		A=minutes
		if timetype==1:B=int(time.time());C=int(A*60)
		else:B=int(time.time()*1000);C=int(A*60*1000)
		if A!=0:B+=C
		return B
	def Get_Now_Datetime(A):return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
	def Get_Search_Wavve(A,search_key,sType,page_int):
		R='count';Q='age';P='celllist';D='band';E=[];L=F=1;G=_F
		try:
			S=A.API_WAVVE+'/fz/search/band.js';M={_W:_v if sType==_g else _w,'keyword':search_key,'offset':str((page_int-1)*A.WAVVE_LIMIT),'limit':A.WAVVE_LIMIT,'orderby':'score','mtype':'svod'};M.update(A.WAVVE_PARAMS);T=A.Call_Request(S,payload=_A,params=M,headers=_A,cookies=_A,method=_S);B=json.loads(T.text)
			if not P in B[D]:return E,G
			U=B[D][P]
			for C in U:
				H=''
				for N in C['event_list']:
					if N[_W]=='on-navigation':H=N[_X]
				if H=='':break
				I=urllib.parse.urlsplit(H).query;J=I[0:I.find('=')];V=dict(urllib.parse.parse_qsl(I));Z=V.get(J);J=_g if J=='programid'else'MOVIE';W=C['title_list'][0][_Z];a=C[Q];K={_C:W};O=_F
				for X in C['bottom_taglist']:
					if X=='won':O=_J;break
				if O==_J:K[_C]=K[_C]+' [개별구매]'
				if C.get(Q)!='21':E.append(K)
			L=int(B[D]['pagecount'])
			if B[D][R]:F=int(B[D][R])
			else:F=A.LIST_LIMIT
			G=L>F
		except Exception as Y:print(Y)
		return E,G
	def Get_Search_Tving(B,search_key,sType,page_int):
		J='imageUrl';C=sType;D=[];E=_F
		try:
			if C==_g:F='https://gw.tving.com/bff/search/v2/more/content/series/search';G='AI_SCH_SERIES'
			else:F='https://gw.tving.com/bff/search/v2/more/content/movie/search';G='AI_SCH_MOVIE'
			K={'keyword':search_key,'pageNo':str(page_int),'pageSize':'20','bandComposeMethod':'MANUAL','bandCode':G,'osCode':B.TVING_PARMAS['OSCODE'],'screenCode':B.TVING_PARMAS[_A7]};L=B.Call_Request(F,payload=_A,params=K,headers=_A,cookies=_A,method=_S);H=json.loads(L.text).get(_M).get('bands')[0]
			for A in H['items']:
				if C==_g:I={_v:A[_x],_C:A[_C],_a:{_Y:A[J]}}
				else:I={_w:A[_x],_C:A[_C],_a:{_Y:A[J]}}
				D.append(I)
			if'nextApiUrl'in H:E=_J
		except Exception as M:print(M)
		return D,E
	def Get_Search_Watcha(B,search_key,page_int):
		K='large';J='stillcut';I='results';D=[];E=_F
		try:
			L=B.API_WATCHA+'/api/search.json';M={_b:search_key,_y:str(page_int),'per':str(B.WATCHA_LIMIT),'exclude':'limited'};N=B.Call_Request(L,payload=_A,params=M,headers=B.WATCHA_HEADER,cookies=_A,method=_S);F=json.loads(N.text)
			if not I in F:return D,E
			O=F[I];E=F['meta']['has_next']
			for A in O:
				U=A[_x];P=A['content_type'];Q=A[_C];V=A['story'];H=G=C=''
				if A.get(_Y)!=_A:H=A.get(_Y).get('original')
				if A.get(J)!=_A:G=A.get(J).get(K)
				if A.get(_a)!=_A:C=A.get(_a).get(K)
				if C=='':C=G
				W={'thumb':G,_Y:H,'fanart':C};X=A['year'];Y=A['film_rating_code'];Z=A['film_rating_short'];a=A['film_rating_long']
				if P=='movies':R=A['duration']
				else:R='0'
				S={_C:Q};D.append(S)
		except Exception as T:print(T)
		return D,E
	def Get_Search_Coupang(A,search_key,page_int):
		G='contents';F='WEBCLIENT';B=[];C=_F
		try:
			D=A.jsonfile_To_dic(A.CP_ORIGINAL_COOKIE);H=A.API_COUPANG+'/api-discover/v3/search';I={_b:search_key,'platform':F,_y:str(page_int),'perPage':'48','filterSearchGroupTypes':'','filterSearchGroupType':'TITLES-EVENT_LIVE-EVENT_CHANNELS','includeChannelContents':_N,'includeSportsChannelContents':_N};J={'x-pcid':D[_K]['PCID'],'x-profileid':D[_I]['profileId'],'x-platform':F};K=A.Call_Request(H,payload=_A,params=I,headers=J,cookies=_A,method=_S);E=json.loads(K.text)
			if len(E.get(_M).get(G))==0:return B,C
			for L in E.get(_M).get(G):M={_C:L.get(_C)};B.append(M)
		except Exception as N:print(N)
		return B,C
	def Selenium_Cookies_Load(A,in_filename):
		C=open(in_filename,'rb',-1)
		try:
			B=pickle.loads(C.read())
			if type(B)==list:
				for D in B:A.HTTP_CLIENT.cookies.set_cookie(A.To_Cookielib(D))
			else:A.HTTP_CLIENT.cookies.update(B)
		except Exception as E:print(E)
		finally:C.close()
	def To_Cookielib(B,selenium_cookie):A=selenium_cookie;return http.cookiejar.Cookie(version=0,name=A[_T],value=A[_B],port=_A,port_specified=_F,domain=A['domain'],domain_specified=_J,domain_initial_dot=_F,path=A['path'],path_specified=_J,secure=A['secure'],expires=A['expiry'],discard=_F,comment=_A,comment_url=_A,rest={'HttpOnly':A['httpOnly']},rfc2109=_F)
	def Get_Search_Primev(A,search_key):
		C=[]
		try:
			A.PV=A.jsonfile_To_dic(A.PV_ORIGINAL_COOKIE);F=A.PV[_K];G={_u:'application/json','x-requested-with':'WebAppSPA'};H='dvWebAppClientVersion=1.0.121730.0';I='https://www.primevideo.com/region/fe/search/ref=atv_nb_sug?ie=UTF8&phrase={}&{}'.format(urllib.parse.quote_plus(search_key),H);D=A.Call_Request(I,params=_A,headers=G,cookies=F,method=_S)
			if D.status_code!=200:return[]
			B=json.loads(D.text);B=B['body'][_A8][0];J=B.get('entities')
			for E in J:
				if'titleID'not in E:return[]
				K={_C:E.get(_C)};C.append(K)
		except Exception as L:print(L)
		return C
	def Get_Search_Disney(A,search_key):
		B=[];D='{}/{}/search'.format(A.API_DISNEY,A.API_DISNEY_VERSION);E=A.make_DZ_Headers(accessToken=_J,Bearer=_J);F={_b:search_key};C=A.Call_Request(D,params=F,headers=E,cookies=_A,method=_S)
		if C.status_code not in[200,201]:return[]
		G=C.json().get(_M).get(_y).get(_A8)
		for H in G[0]['items']:I={_C:H['visuals'][_C]};B.append(I)
		return B
	def Get_Search_Disney_back(B,search_key):
		H='default';G='full';C='content';D=[];E=B.DZ['services'][C]['getSearchResults']['href'];J={'apiVersion':'5.1','region':B.DZ[_Q]['regionCode'],'kidsModeEnabled':_V,'impliedMaturityRating':'1870','appLanguage':B.DZ[_Q]['lang'][0:2],'partner':'disney','queryType':'ge','pageSize':str(B.DISNEY_LIMIT),_b:search_key};E=E.format(**J);K=B.make_DZ_Headers(accessToken=_J,Bearer=_J);I=B.Call_Request(E,headers=K,cookies=_A,method=_S)
		if I.status_code not in[200,201]:return[]
		L=I.json().get(_M).get(_G)
		for A in L.get('hits'):
			A=A.get('hit')
			if A.get(_W)=='DmcSeries':F=A.get(_Z).get(_C).get(G).get('series').get(H).get(C)
			elif A.get(_W)=='DmcVideo':F=A.get(_Z).get(_C).get(G).get(_v).get(H).get(C)
			elif A.get(_W)=='StandardCollection':F=A.get(_Z).get(_C).get(G).get('collection').get(H).get(C)
			else:return D
			M={_C:F};D.append(M)
		return D
	def dic_To_jsonfile(C,filename,dic):
		A=filename
		if A=='':return
		B=open(A,'w',-1,_h);json.dump(dic,B,indent=4,ensure_ascii=_F);B.close()
	def jsonfile_To_dic(D,filename):
		A=filename
		if A=='':return
		try:B=open(A,'r',-1,_h);C=json.load(B);B.close()
		except:C={}
		return C
	def tempFileSave(C,filename,resText):
		A=filename
		if A=='':return
		B=open(A,'w',-1,_h);B.write(resText);B.close()
	def tempFileLoad(D,filename):
		A=filename
		if A=='':return
		try:B=open(A,'r',-1,_h);C=B.read();B.close()
		except:C=''
		return C
	def make_DZ_Headers(A,accessToken=_J,Bearer=_F):
		C='sdkVersion'
		if accessToken:B=A.DZ[_U][_z]
		else:B=A.DZ[_Q]['clientApiKey']
		if Bearer:B='Bearer {}'.format(B)
		A.DZ[_Q][C]='34.4';D={'authorization':B,'x-application-version':A.DZ[_Q]['buildId'],'x-bamsdk-client-id':A.DZ[_Q]['clientId'],'x-bamsdk-platform':'javascript/windows/chrome','x-bamsdk-platform-id':'browser','x-bamsdk-version':A.DZ[_Q][C],'x-bamtech-wpnx-mlp-identifier':'/','x-bamtech-wpnx-mlp-locale':A.DZ[_Q]['lang']};return D
	def DZ_ReToken(A):
		J='sessionId';I='session';H='accessTokenType';F='token';E='sdk';D='extensions';C='refreshToken'
		try:
			K=A.DZ['services']['orchestration'][C]['href'];L=A.make_DZ_Headers(accessToken=_F,Bearer=_F);M={_b:'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{C:A.DZ[_U][C]}}};G=A.Call_Request(K,json=M,headers=L,cookies=_A,method=_f)
			if G.status_code not in[200,201]:return _F
			B=G.json();A.DZ[_U][_z]=B.get(D).get(E).get(F).get(_z);A.DZ[_U][H]=B.get(D).get(E).get(F).get(H);A.DZ[_U][C]=B.get(D).get(E).get(F).get(C);A.DZ[_U]['token_limit']=int(time.time())+14400;A.DZ[_U]['deviceId']=B.get(D).get(E).get(I).get('device').get(_c);A.DZ[_U][J]=B.get(D).get(E).get(I).get(J)
		except Exception as N:print(N);return _F
		return _J
	def Init_NF_Total(A):A.NF={};A.NF[_K]={};A.NF[_I]={}
	def make_NF_XnetflixHeaders(A):B={'x-netflix.browsername':A.NF[_I][_O]['X-Netflix.browserName'],'x-netflix.browserversion':str(A.NF[_I][_O]['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':A.NF[_I][_O]['X-Netflix.clientType'],'x-netflix.esn':A.NF[_I]['esnModel'],'x-netflix.esnprefix':A.NF[_I][_O]['X-Netflix.esnPrefix'],'x-netflix.osfullname':A.NF[_I][_O]['X-Netflix.osFullName'],'x-netflix.osname':A.NF[_I][_O]['X-Netflix.osName'],'x-netflix.osversion':A.NF[_I][_O]['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':A.NF[_I]['nowGuid'],'x-netflix.uiversion':A.NF[_I][_O]['X-Netflix.uiVersion']};return B
	def make_NF_ApiParams(B):A={'avif':_V,'webp':_V,'drmSystem':'widevine','isVolatileBillboardsEnabled':_N,'routeAPIRequestsThroughFTL':_V,'isTop10Supported':_N,'isTop10KidsSupported':_N,'hasVideoMerchInBob':_N,'hasVideoMerchInJaw':_N,'persoInfoDensity':_V,'infoDensityToggle':_V,'contextAwareImages':_N,'enableMultiLanguageCatalog':_V,'usePreviewModal':_N,'falcor_server':'0.1.0','withSize':_N,'materialize':_N,'original_path':'/shakti/mre/pathEvaluator'};return A
	def extract_json(E,content,name):C='netflix\\.{}\\s*=\\s*(.*?);\\s*</script>';B=_A;D=re.compile(C.format(name),re.DOTALL).findall(content);B=D[0];A=B.replace('\\"','\\\\"');A=A.replace('\\s','\\\\s');A=A.replace('\\n','\\\\n');A=A.replace('\\t','\\\\t');A=A.encode().decode('unicode_escape');A=re.sub('\\\\(?!["])','\\\\\\\\',A);return json.loads(A)
	def NF_makestr_paths(D,paths):
		F='"%s"';B=paths;C=[]
		if isinstance(B,int):return'%d'%B
		elif isinstance(B,str):return F%B
		for A in B:
			if isinstance(A,int):C.append('%d'%A)
			elif isinstance(A,str):C.append(F%A)
			elif isinstance(A,list):C.append('[%s]'%','.join(D.NF_makestr_paths(A)))
			elif isinstance(A,dict):
				E=''
				for(G,H)in A.items():E+='"%s":%s,'%(G,D.NF_makestr_paths(H))
				C.append('{%s}'%E[:-1])
		return C
	def NF_Call_pathapi(A,pathlist,referer=''):
		C=referer;E='%s/nq/website/memberapi/%s/pathEvaluator'%(A.API_NETFLIX,A.NF[_I][_A9]);F={'path':A.NF_makestr_paths(pathlist),_i:A.NF[_I][_i]};G=A.make_NF_ApiParams();B={_u:'*/*','content-type':'application/x-www-form-urlencoded','origin':A.API_NETFLIX,'sec-ch-ua':'"Google Chrome";v="101", "Not)A;Brand";v="8", "Chromium";v="101"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin'}
		if C!='':B['referer']=C
		H=A.make_NF_XnetflixHeaders();B.update(H);D=A.NF_Get_DefaultCookies();D['profilesNewSession']='0'
		try:I=A.Call_Request(E,payload=F,params=G,headers=B,cookies=D,method=_f);return I
		except Exception as J:print(J);return
	def Get_Search_Netflix(A,search_key,page_int,byReference=''):
		H=search_key;G=page_int;F='titles';D=byReference;I=A.DERECTOR_LIMIT;R=A.CAST_LIMIT;J=A.GENRE_LIMIT;B=A.NETFLIX_LIMIT*(G-1);C=A.NETFLIX_LIMIT*G;E='|%s'%H;L='%s/search?%s'%(A.API_NETFLIX,urllib.parse.urlencode({'q':H}))
		if D=='-'or G==1:K=[[_G,_R,E,F,A.NETFLIX_LIMIT,{_D:B,_E:C},_d],[_G,_R,E,F,A.NETFLIX_LIMIT,{_D:B,_E:C},_H,[_C,_d,_j,_A0,_A1,_k,_A2,_e,_A3]],[_G,_R,E,F,A.NETFLIX_LIMIT,{_D:B,_E:C},_H,_l,[A.ART_SIZE_LAND2,A.ART_SIZE_PORT],_L],[_G,_R,E,F,A.NETFLIX_LIMIT,{_D:B,_E:C},_H,_m,A.ART_SIZE_LAND1,_L],[_G,_R,E,F,A.NETFLIX_LIMIT,{_D:B,_E:C},_H,_n,A.ART_SIZE_LAND2,_L],[_G,_R,E,F,A.NETFLIX_LIMIT,{_D:B,_E:C},_H,[_o,_A4,_A5],{_D:0,_E:I},[_c,_T]],[_G,_R,E,F,A.NETFLIX_LIMIT,{_D:B,_E:C},_H,_p,{_D:0,_E:J},[_c,_T]],[_G,_R,E,F,A.NETFLIX_LIMIT,{_D:B,_E:C},_H,_q,_r,A.ART_SIZE_LOGO,_s]]
		else:K=[[_G,_P,D,{_D:B,_E:C},_d],[_G,_P,D,{_D:B,_E:C},_H,[_C,_d,_j,_A0,_A1,_k,_A2,_e,_A3]],[_G,_P,D,{_D:B,_E:C},_H,_l,[A.ART_SIZE_LAND2,A.ART_SIZE_PORT],_L],[_G,_P,D,{_D:B,_E:C},_H,_m,A.ART_SIZE_LAND1,_L],[_G,_P,D,{_D:B,_E:C},_H,_n,A.ART_SIZE_LAND2,_L],[_G,_P,D,{_D:B,_E:C},_H,[_o,_A4,_A5],{_D:0,_E:I},[_c,_T]],[_G,_P,D,{_D:B,_E:C},_H,_p,{_D:0,_E:J},[_c,_T]],[_G,_P,D,{_D:B,_E:C},_H,_q,_r,A.ART_SIZE_LOGO,_s]]
		try:M=A.NF_Call_pathapi(K,L);N=json.loads(M.text)
		except Exception as O:print(O)
		P,Q,D=A.Search_Netflix_Make(N);return P,Q,D
	def Search_Netflix_Make(B,jsonSource):
		X='rating';W='maturityDescription';G='jsonGraph';F='paths';C=jsonSource;N=[];O=_F;K='';Y=C.get(F)[0][1]
		if Y==_R:P=C[F][0][5][_D];L=C[F][0][5][_E]
		else:P=C[F][0][3][_D];L=C[F][0][3][_E]
		K=list(C.get(G).get(_G).get(_P).keys())[0];M=C.get(G).get(_G).get(_P).get(K);Z=C.get(G).get('videos');Q=C.get(G).get('person');a=C.get(G).get(_p);O=_J if M[str(L)][_H][_A6]=='ref'else _F
		for R in range(P,L):
			if M[str(R)][_H][_A6]=='ref':
				S=M[str(R)][_H][_B][1];A=Z[S];b=A[_C][_B]
				if A[_A3][_B]['isPlayable']==_F:continue
				T=A[_d][_B][_W];c=0 if T!=_w else A[_A1][_B]
				if A[_e][_B][_B]:U=A[_e][_B][_B][_Z]
				else:U=''
				d=A[_l][B.ART_SIZE_PORT][_L][_B][_X];e=A[_l][B.ART_SIZE_LAND2][_L][_B][_X];H=''
				if _B in A[_n][B.ART_SIZE_LAND2][_L]:H=A[_n][B.ART_SIZE_LAND2][_L][_B][_X]
				if H==''and _B in A[_m][B.ART_SIZE_LAND1][_L]:H=A[_m][B.ART_SIZE_LAND1][_L][_B][_X]
				V=''
				if _B in A[_q][_r][B.ART_SIZE_LOGO][_s]:V=A[_q][_r][B.ART_SIZE_LOGO][_s][_B][_X]
				I=B.NF_Subid_List(A[_p])
				for D in range(len(I)):I[D]=a[I[D]][_T][_B]
				E=B.NF_Subid_List(A[_A5]);f=B.NF_Subid_List(A[_A4]);E.extend(f)
				for D in range(len(E)):E[D]=Q[E[D]][_T][_B]
				J=B.NF_Subid_List(A[_o])
				for D in range(len(J)):J[D]=Q[J[D]][_T][_B]
				if W in A[_k][_B][X]:g=A[_k][_B][X][W]
				h={'videoid':S,'vidtype':T,_C:b,'mpaa':g,_j:A[_j][_B],'dpSupplemental':A[_A2][_B],_e:U,_a:{_Y:d,'thumb':H,'fanart':e,'clearlogo':V},'year':A[_A0][_B],'duration':c,'info_genre':I,'director':E,_o:J};N.append(h)
		return N,O,K;"\n\t\t\t\t\ttemp_list = {\n\t\t\t\t\t\t\t\t'title'      : tmp_title,\n\t\t\t\t\t\t\t\t'thumbnail'  : { 'poster' : tmp_poster, 'thumb' : tmp_thumb, 'fanart' : tmp_thumb, 'clearlogo' : tmp_clearlogo },\n\t\t\t\t\t\t\t\t'cast'       : cast_list,\n\t\t\t\t\t\t\t\t'director'   : director_list,\n\t\t\t\t\t\t\t\t'info_genre' : genre_list,\n\t\t\t\t\t\t\t\t'duration'   : duration,\n\t\t\t\t\t\t\t\t'mpaa'       : mpaa,\n\t\t\t\t\t\t\t\t'year'       : year,\n\t\t\t\t\t\t\t\t'aired'      : aired,\n\t\t\t\t\t}\n\t\t"
	def NF_Subid_List(F,subJson):
		A=subJson;B=[]
		try:
			for C in range(len(A)):
				if A.get(str(C)).get(_A6)!='ref':break
				D=A.get(str(C)).get(_B)[1];B.append(D)
		except Exception as E:print(E)
		return B
	def NF_CookieFile_Load(G,cookie_filename):
		A=cookie_filename;B={}
		try:
			if os.path.isfile(A)==_F:return{}
			C=open(A,'rb',-1);E=pickle.loads(C.read());C.close()
			for D in E:B[D.name]=D.value
		except Exception as F:print(F)
		return B
	def NF_Get_DefaultCookies(A):
		F='NetflixId';E='SecureNetflixId';D='nfvdid';C='flwssn';B={}
		if A.NF[_K][C]:B[C]=A.NF[_K][C]
		if A.NF[_K][D]:B[D]=A.NF[_K][D]
		if A.NF[_K][E]:B[E]=A.NF[_K][E]
		if A.NF[_K][F]:B[F]=A.NF[_K][F]
		return B
	def NF_Get_BaseSession(A):
		E='userInfo';D='memberContext';C='models'
		try:
			G=A.API_NETFLIX+'/browse';H=A.NF_Get_DefaultCookies();F=A.Call_Request(G,payload=_A,params=_A,headers=_A,cookies=H,method=_S)
			if F.status_code!=200:print('pass 1 status_code error');return _F
			B=A.extract_json(F.text,'reactContext');A.NF[_I]={'mainGuid':B[C][D][_M][E]['guid'],'nowGuid':B[C][D][_M][E]['userGuid'],_i:B[C][D][_M][E][_i],'esnModel':B[C][D][_M][E]['esn'],_A9:B[C]['serverDefs'][_M]['BUILD_IDENTIFIER'],_O:B[C][_O][_M][_Q]};A.dic_To_jsonfile(A.NF_SESSION_COOKIES1,A.NF)
		except Exception as I:print('pass 1 error');print(I);return _F
		return _J