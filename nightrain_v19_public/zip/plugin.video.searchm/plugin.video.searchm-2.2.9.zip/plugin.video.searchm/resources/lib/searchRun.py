_A6='vsubtitle'
_A5='limitdate'
_A4='tving.png'
_A3='wavve.png'
_A2='disney_list'
_A1='primev_list'
_A0='netflix_list'
_z='coupang_list'
_y='watcha_list'
_x='tving_movie'
_w='tving_tvshow'
_v='wavve_movie'
_u='wavve_tvshow'
_t='TOTAL_HISTORY'
_s='SET_BOOKMARK'
_r='byReference'
_q='SESSION'
_p='ALL'
_o='plot'
_n='HISTORY_REMOVE'
_m='delmode'
_l='NF_SEARCH'
_k='TOTAL_SEARCH'
_j='thumbnail'
_i='\n\n'
_h='img'
_g='path'
_f='amazon'
_e='coupang'
_d='watcha'
_c='XXX'
_b='MENU_BOOKMARK'
_a='movie'
_Z='%2B'
_Y='disney'
_X='tving'
_W='wavve'
_V='videoid'
_U='values'
_T='TVSHOW'
_S='page'
_R='COOKIES'
_Q='netflix'
_P='MOVIE'
_O='skey'
_N='true'
_M='sType'
_L='utf8'
_K='search_key'
_J='ott'
_I='icon'
_H=True
_G=None
_F='vidtype'
_E='-'
_D='title'
_C='utf-8'
_B=False
_A='mode'
__author__='NightRain'
import os,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,sys,datetime,time,urllib,base64,datetime,json
__addon__=xbmcaddon.Addon()
__language__=__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MAIN_GROUP=[{_D:'통합검색 (웨이브,티빙,쿠팡,디즈니)',_A:_k,_I:'search.png'},{_D:'검색기록',_A:_t,_I:'search_history.png'},{_D:'통합 찜 목록 (bookmark mini)',_A:_b,_I:'bookmark.png'},{_D:'-----------------',_A:_c},{_D:'본 애드온은 검색기능 만을 제공합니다.',_A:_c},{_D:'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.',_A:_c}]
SEARCH_FOLDER={_u:{_D:'웨이브 (VOD)',_A:_E,_J:_W,_F:_T,_I:_A3},_v:{_D:'웨이브 (영화)',_A:_E,_J:_W,_F:_P,_I:_A3},_w:{_D:'티빙 (VOD)',_A:_E,_J:_X,_F:_T,_I:_A4},_x:{_D:'티빙 (영화)',_A:_E,_J:_X,_F:_P,_I:_A4},_y:{_D:'왓챠 (영화,시리즈)',_A:_E,_J:_d,_F:_E,_I:'watcha.png'},_z:{_D:'쿠팡 (영화,시리즈)',_A:_E,_J:_e,_F:_E,_I:'coupang.png'},_A0:{_D:'넷플릭스 (영화,시리즈)',_A:_l,_J:_Q,_F:_E,_I:'netflix.png'},_A1:{_D:'프라임비디오 (영화,시리즈)',_A:_E,_J:_f,_F:_E,_I:'primev.png'},_A2:{_D:'디즈니플러스 (영화,시리즈)',_A:_E,_J:_Y,_F:_E,_I:'disney.jpg'}}
NF_COOKIE_FILE_NAME=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
SEARCHED_FILE_NAME=xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class SearchRun:
	def __init__(self,in_addonurl,in_handle,in_params):C='addon_data';B='userdata';A='special://home';self._addon_url=in_addonurl;self._addon_handle=in_handle;self.main_params=in_params;self.SearchObj=Search();self.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join(A,B,C,'plugin.video.coupangm','cp_cookies.json'));self.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join(A,B,C,'plugin.video.netflix',_R));self.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join(A,B,C,'plugin.video.primevm','pv_authinfo.json'));self.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join(A,B,C,'plugin.video.disneym','dz_cookies.json'))
	def addon_noti(self,sting):
		try:dialog=xbmcgui.Dialog();dialog.notification(__addonname__,sting)
		except:_G
	def addon_log(self,string):
		try:log_message=string.encode(_C,'ignore')
		except:log_message='addonException: addon_log'
		level=xbmc.LOGINFO;xbmc.log('[%s-%s]: %s'%(__addonid__,__version__,log_message),level=level)
	def get_keyboard_input(self,title):
		input_text=_G;kb=xbmc.Keyboard();kb.setHeading(title);xbmc.sleep(1000);kb.doModal()
		if kb.isConfirmed():input_text=kb.getText()
		return input_text
	def get_settings_menubookmark(self):menu_bookmark=_H if __addon__.getSetting('menu_bookmark')==_N else _B;return menu_bookmark
	def get_settings_makebookmark(self):return _H if __addon__.getSetting('make_bookmark')==_N else _B
	def get_settings_select_info(self):
		ott_select=[]
		if __addon__.getSetting('wavveyn')==_N:ott_select.append(_W)
		if __addon__.getSetting('tvingyn')==_N:ott_select.append(_X)
		if __addon__.getSetting('watchayn')==_N:ott_select.append(_d)
		if __addon__.getSetting('coupangyn')==_N:ott_select.append(_e)
		if __addon__.getSetting('primevyn')==_N:ott_select.append(_f)
		if __addon__.getSetting('disneyyn')==_N:ott_select.append(_Y)
		return ott_select
	def add_dir(self,label,sublabel='',img='',infoLabels=_G,isFolder=_H,params='',isLink=_B,ContextMenu=_G,direct_url=_G):
		if direct_url:url=direct_url
		else:params={_A:params.get(_A),_U:params};param_str=json.dumps(params,separators=(',',':'));param_str=base64.standard_b64encode(param_str.encode()).decode(_C);param_str=param_str.replace('+',_Z);url='%s?params=%s'%(self._addon_url,param_str)
		if sublabel and sublabel!=_E:title='%s < %s >'%(label,sublabel)
		else:title=label
		if not img:img='DefaultFolder.png'
		listitem=xbmcgui.ListItem(title)
		if type(img)==dict:listitem.setArt(img)
		else:listitem.setArt({'thumb':img,'poster':img})
		if infoLabels:listitem.setInfo('Video',infoLabels)
		if not isFolder and not isLink:listitem.setProperty('IsPlayable',_N)
		if ContextMenu:listitem.addContextMenuItems(ContextMenu)
		xbmcplugin.addDirectoryItem(self._addon_handle,url,listitem,isFolder)
	def Load_Searched_List(self):
		try:searchfile=SEARCHED_FILE_NAME;fp=open(searchfile,'r',-1,_C);result=fp.readlines();fp.close()
		except:result=[]
		return result
	def Save_Searched_List(self,search_key):
		try:
			searchfile=SEARCHED_FILE_NAME;oldlist=self.Load_Searched_List();save_params={_O:search_key.strip()};fp=open(searchfile,'w',-1,_C);newlist=urllib.parse.urlencode(save_params);newlist=newlist+'\n';fp.write(newlist);addcount=0
			for olditem in oldlist:
				old_dic=dict(urllib.parse.parse_qsl(olditem));new_id=save_params.get(_O).strip();old_id=old_dic.get(_O).strip()
				if new_id!=old_id:
					fp.write(olditem);addcount+=1
					if addcount>=50:break
			fp.close()
		except:_G
	def dp_Search_History(self,args):
		SEARCH_HISTORY=self.Load_Searched_List()
		for search_history in SEARCH_HISTORY:hist_params=dict(urllib.parse.parse_qsl(search_history));skey=hist_params.get(_O).strip();params={_A:_k,_K:skey};menu_param={_A:_n,_O:skey,_m:'ONE'};menu_param_str=urllib.parse.urlencode(menu_param);ContextMenu=[('선택된 검색어 ( %s ) 삭제'%skey,'RunPlugin(plugin://plugin.video.searchm/?%s)'%menu_param_str)];self.add_dir(skey,sublabel='',img=_G,infoLabels=_G,isFolder=_H,params=params,ContextMenu=ContextMenu)
		info={_o:'검색목록 전체를 삭제합니다.'};title='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **';params={_A:_n,_O:_E,_m:_p};icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_g),_h,'delete.png');self.add_dir(title,sublabel='',img=icon_img,infoLabels=info,isFolder=_B,params=params,isLink=_H);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_B)
	def Delete_History_List(self,skey,delmode):
		if delmode==_p:
			try:searchfile=SEARCHED_FILE_NAME;fp=open(searchfile,'w',-1,_C);fp.write('');fp.close()
			except:_G
		else:
			try:
				searchfile=SEARCHED_FILE_NAME;oldlist=self.Load_Searched_List();fp=open(searchfile,'w',-1,_C)
				for olditem in oldlist:
					old_dic=dict(urllib.parse.parse_qsl(olditem));old_skey=old_dic.get(_O).strip()
					if skey!=old_skey:fp.write(olditem)
				fp.close()
			except:_G
	def dp_History_Delete(self,args):
		skey=args.get(_O);delmode=args.get(_m);dialog=xbmcgui.Dialog()
		if delmode==_p:ret=dialog.yesno(__language__(30913).encode(_L),__language__(30908).encode(_L))
		else:ret=dialog.yesno(__language__(30914).encode(_L),__language__(30908).encode(_L))
		if ret==_B:sys.exit()
		self.Delete_History_List(skey,delmode);xbmc.executebuiltin('Container.Refresh')
	def dp_Main_List(self):
		menu_bookmark=self.get_settings_menubookmark()
		for main_group in MAIN_GROUP:
			title=main_group.get(_D);icon_img=''
			if main_group.get(_A)==_b and menu_bookmark==_B:continue
			params={_A:main_group.get(_A)}
			if main_group.get(_A)in[_c,_b]:isFolder=_B;isLink=_H
			else:isFolder=_H;isLink=_B
			if _I in main_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_g),_h,main_group.get(_I))
			self.add_dir(title,sublabel='',img=icon_img,infoLabels=_G,isFolder=isFolder,params=params,isLink=isLink)
		xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_B)
	def option_check(self):
		ott_select=self.get_settings_select_info()
		if len(ott_select)==0:
			dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30901).encode(_L),__language__(30903).encode(_L))
			if ret==_H:__addon__.openSettings();sys.exit()
			else:sys.exit()
		if _Q in ott_select:
			if self.NF_cookiefile_check()==_B:self.NF_login(showMessage=_H)
		if _Y in ott_select:
			if self.DZ_cookiefile_check()==_B:self.SearchObj.DZ={}
	def DZ_cookiefile_check(self):
		json_data={}
		try:fp=open(self.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,_C);json_data=json.load(fp);fp.close()
		except Exception as exception:return _B
		self.SearchObj.DZ=json_data
		if int(time.time())>self.SearchObj.DZ['account']['token_limit']:
			if self.SearchObj.DZ_ReToken()==_B:self.addon_noti(__language__(30920).encode(_C));return _B
			try:fp=open(self.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,_C);json.dump(self.SearchObj.DZ,fp,indent=4,ensure_ascii=_B);fp.close()
			except Exception as exception:return _B
		return _H
	def NF_cookiefile_check(self):
		D='nfvdid';C='flwssn';B='SecureNetflixId';A='NetflixId';json_data={}
		try:fp=open(NF_COOKIE_FILE_NAME,'r',-1,_C);json_data=json.load(fp);fp.close()
		except Exception as exception:return _B
		self.SearchObj.NF=json_data;nowDate=int(self.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'));limitDateStr=self.SearchObj.NF[_q][_A5];limitDate=int(re.sub(_E,'',limitDateStr))
		if limitDate<nowDate:
			self.SearchObj.Init_NF_Total()
			if self.NF_login(showMessage=_B)==_B:return _B
		original=self.SearchObj.NF_CookieFile_Load(self.SearchObj.NF_ORIGINAL_COOKIE)
		if original[A]!=self.SearchObj.NF[_R][A]or original[B]!=self.SearchObj.NF[_R][B]or original[C]!=self.SearchObj.NF[_R][C]or original[D]!=self.SearchObj.NF[_R][D]:
			self.SearchObj.Init_NF_Total()
			if self.NF_login(showMessage=_B)==_B:return _B
		return _H
	def NF_login(self,showMessage=_H):
		if showMessage:
			dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30911).encode(_L),__language__(30916).encode(_L))
			if ret==_B:return _B
		self.SearchObj.NF[_R]=self.SearchObj.NF_CookieFile_Load(self.SearchObj.NF_ORIGINAL_COOKIE);passok=_B if self.SearchObj.NF[_R]=={}else _H
		if passok:self.addon_log('pass1 ok!')
		else:self.addon_log('pass1 error!');self.addon_noti(__language__(30905).encode(_C));return _B
		passok=self.SearchObj.NF_Get_BaseSession()
		if passok:self.addon_log('pass2 ok!')
		else:self.addon_log('pass2 error!');self.addon_noti(__language__(30905).encode(_C));return _B
		current=self.SearchObj.Get_Now_Datetime();self.SearchObj.NF[_q][_A5]=current.strftime('%Y-%m-%d')
		try:fp=open(NF_COOKIE_FILE_NAME,'w',-1,_C);json.dump(self.SearchObj.NF,fp,indent=4,ensure_ascii=_B);fp.close();self.addon_log('pass3 save ok!')
		except Exception as exception:self.addon_log('pass3 save error!');self.addon_noti(__language__(30905).encode(_C));return _B
		if showMessage:self.addon_noti(__language__(30904).encode(_C))
		return _H
	def NF_logout(self):
		dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30910).encode(_L),__language__(30908).encode(_L))
		if ret==_B:return
		if os.path.isfile(NF_COOKIE_FILE_NAME):os.remove(NF_COOKIE_FILE_NAME)
		self.addon_noti(__language__(30909).encode(_C))
	def MakeText_FreeList(self,search_list):
		resultText='';max_count=7
		try:
			for i in range(len(search_list)):
				if i>=max_count:resultText=resultText+'...';break
				resultText=resultText+search_list[i][_D]+'\n'
		except:return''
		return resultText
	def dp_Search_Group(self,args):
		A='sList';ott_select=self.get_settings_select_info();search_result=[]
		if _K in args:search_key=args.get(_K)
		else:
			search_key=self.get_keyboard_input(__language__(30906).encode(_C))
			if not search_key:return
		if _W in ott_select:
			self.addon_log('wavve search_key : {}'.format(search_key));search_list,more_page=self.SearchObj.Get_Search_Wavve(search_key,_T,1);self.addon_log('wavve tvshow cnt : {}'.format(len(search_list)))
			if len(search_list)>0:temp={_M:_u,A:self.MakeText_FreeList(search_list)};search_result.append(temp)
			search_list,more_page=self.SearchObj.Get_Search_Wavve(search_key,_P,1);self.addon_log('wavve movie cnt : {}'.format(len(search_list)))
			if len(search_list)>0:temp={_M:_v,A:self.MakeText_FreeList(search_list)};search_result.append(temp)
		if _X in ott_select:
			search_list,more_page=self.SearchObj.Get_Search_Tving(search_key,_T,1)
			if len(search_list)>0:temp={_M:_w,A:self.MakeText_FreeList(search_list)};search_result.append(temp)
			search_list,more_page=self.SearchObj.Get_Search_Tving(search_key,_P,1)
			if len(search_list)>0:temp={_M:_x,A:self.MakeText_FreeList(search_list)};search_result.append(temp)
		if _d in ott_select:
			search_list,more_page=self.SearchObj.Get_Search_Watcha(search_key,1)
			if len(search_list)>0:temp={_M:_y,A:self.MakeText_FreeList(search_list)};search_result.append(temp)
		if _e in ott_select:
			search_list,more_page=self.SearchObj.Get_Search_Coupang(search_key,1)
			if len(search_list)>0:temp={_M:_z,A:self.MakeText_FreeList(search_list)};search_result.append(temp)
		if _Q in ott_select:
			try:search_list,more_page,byReference=self.SearchObj.Get_Search_Netflix(search_key,1)
			except:search_list=[];self.addon_noti(__language__(30919).encode(_L))
			if len(search_list)>0:temp={_M:_A0,A:self.MakeText_FreeList(search_list)};search_result.append(temp)
		if _f in ott_select:
			search_list=self.SearchObj.Get_Search_Primev(search_key)
			if len(search_list)>0:temp={_M:_A1,A:self.MakeText_FreeList(search_list)};search_result.append(temp)
		if _Y in ott_select:
			try:search_list=self.SearchObj.Get_Search_Disney(search_key)
			except:search_list=[];self.addon_noti(__language__(30921).encode(_L))
			if len(search_list)>0:temp={_M:_A2,A:self.MakeText_FreeList(search_list)};search_result.append(temp)
		for i_search in search_result:
			folder_info=SEARCH_FOLDER[i_search.get(_M)];infoLabels={_o:'검색어 : '+search_key+_i+i_search.get(A)};title=folder_info.get(_D);params={_A:folder_info.get(_A),_J:folder_info.get(_J),_F:folder_info.get(_F),_K:search_key}
			if folder_info.get(_J)==_Q:result_url='';params[_S]='1';params[_r]=_E
			else:result_url=self.make_Hyper_Link(params)
			icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_g),_h,folder_info.get(_I));self.add_dir(title,sublabel='',img=icon_img,infoLabels=infoLabels,isFolder=_H,params=params,isLink=_B,direct_url=result_url)
		xbmcplugin.endOfDirectory(self._addon_handle);self.Save_Searched_List(search_key)
	def make_Hyper_Link(self,args):
		C='LOCAL_SEARCH_LIST';B='vod';A='LOCAL_SEARCH';ott=args.get(_J);vidtype=args.get(_F);search_key=args.get(_K);result_url=_E
		if ott==_W:ott_param={_A:A,_M:_a if vidtype==_P else B,_K:search_key,_S:'1'};ott_param_str=urllib.parse.urlencode(ott_param);result_url='plugin://plugin.video.wavvem/?';result_url+=ott_param_str
		elif ott==_X:ott_param={_A:A,'stype':_a if vidtype==_P else B,_K:search_key,_S:'1'};ott_param_str=urllib.parse.urlencode(ott_param);result_url='plugin://plugin.video.tvingm/?';result_url+=ott_param_str
		elif ott==_d:ott_param={_A:A,_K:search_key,_S:'1'};ott_param_str=urllib.parse.urlencode(ott_param);result_url='plugin://plugin.video.watcham/?';result_url+=ott_param_str
		elif ott==_e:ott_param={_A:A,_K:search_key,_S:'1'};ott_param_str=urllib.parse.urlencode(ott_param);result_url='plugin://plugin.video.coupangm/?';result_url+=ott_param_str
		elif ott==_Q:
			videoid=args.get(_V);nowGuid=self.SearchObj.NF[_q]['nowGuid']
			if vidtype==_T:result_url='plugin://plugin.video.netflix/directory/show/%s/'%videoid
			else:result_url='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(videoid,nowGuid)
		elif ott==_f:ott_param={_A:C,_U:{_K:search_key}};ott_param_str=json.dumps(ott_param,separators=(',',':'));ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode(_C);ott_param_str=ott_param_str.replace('+',_Z);result_url='plugin://plugin.video.primevm/?params=';result_url+=ott_param_str
		elif ott==_Y:ott_param={_A:C,_U:{_K:search_key}};ott_param_str=json.dumps(ott_param,separators=(',',':'));ott_param_str=base64.standard_b64encode(ott_param_str.encode()).decode(_C);ott_param_str=ott_param_str.replace('+',_Z);result_url='plugin://plugin.video.disneym/?params=';result_url+=ott_param_str
		return result_url
	def dp_Nf_Search(self,args):
		G='tvshow';F='cast';E='director';D='duration';C='year';B='mpaa';A='show';page_int=int(args.get(_S));search_key=args.get(_K);byReference=args.get(_r);search_list,more_page,byReference=self.SearchObj.Get_Search_Netflix(search_key,page_int,byReference=byReference)
		for i_section in search_list:
			videoid=i_section.get(_V);vidtype=i_section.get(_F);title=i_section.get(_D);mpaa=i_section.get(B);regularSynopsis=i_section.get('regularSynopsis');dpSupplemental=i_section.get('dpSupplemental');sequiturEvidence=i_section.get('sequiturEvidence');thumbnail=i_section.get(_j);year=i_section.get(C);duration=i_section.get(D);info_genre=i_section.get('info_genre');director=i_section.get(E);cast=i_section.get(F)
			if vidtype==_a:sublabel=' (%s)'%str(year)
			else:sublabel=''
			plot=''
			if regularSynopsis:plot=plot+_i+regularSynopsis
			if dpSupplemental:plot=plot+_i+dpSupplemental
			if sequiturEvidence:plot=plot+_i+sequiturEvidence
			plot=plot.strip();info={'mediatype':G if vidtype==A else _a,_D:title,B:mpaa,_o:plot,D:duration,'genre':info_genre,E:director,F:cast,C:year};params={_J:_Q,_F:_T if vidtype==A else _P,_V:videoid};result_url=self.make_Hyper_Link(params);isFolder=_H if vidtype==A else _B
			if self.get_settings_makebookmark():bm_param={_A:_s,_U:{_V:videoid,_F:G if vidtype==A else _a,'vtitle':title+sublabel,_A6:'','vinfo':info,_j:thumbnail}};bm_param_str=json.dumps(bm_param,separators=(',',':'));bm_param_str=base64.standard_b64encode(bm_param_str.encode()).decode(_C);bm_param_str=bm_param_str.replace('+',_Z);bookmark_url='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%bm_param_str;ContextMenu=[('(통합) 찜 영상에 추가',bookmark_url)]
			else:ContextMenu=_G
			self.add_dir(title+sublabel,sublabel=_G,img=thumbnail,infoLabels=info,isFolder=isFolder,params=params,isLink=_B,ContextMenu=ContextMenu,direct_url=result_url)
		if more_page:params={};params[_A]=_l;params[_S]=str(page_int+1);params[_K]=search_key;params[_r]=byReference;title='[B]%s >>[/B]'%'다음 페이지';subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_g),_h,'next.png');self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_G,isFolder=_H,params=params)
		xbmcplugin.setContent(self._addon_handle,'movies');xbmcplugin.endOfDirectory(self._addon_handle)
	def dp_Bookmark_Menu(self,args):ott_url='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)';xbmc.executebuiltin('Dialog.Close(all,true)');xbmc.executebuiltin(ott_url)
	def dp_Set_Bookmark(self,args):
		videoid=args.get(_V);vidtype=args.get(_F);vtitle=args.get('vtitle');vsubtitle=args.get(_A6);vinfo=args.get('vinfo');thumbnail=args.get(_j);dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30917).encode(_L),vtitle+' \n\n'+__language__(30918))
		if ret==_B:return
		VIDEO_INFO={'indexinfo':{_J:_Q,_V:videoid,_F:vidtype},'saveinfo':{_D:vtitle,'subtitle':vsubtitle,_j:thumbnail,'infoLabels':vinfo}};params={_A:_s,_U:{'VIDEO_INFO':VIDEO_INFO}};param_str=json.dumps(params,separators=(',',':'));param_str=base64.standard_b64encode(param_str.encode()).decode(_C);param_str=param_str.replace('+',_Z);bookmark_url='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%param_str;xbmc.executebuiltin(bookmark_url)
	def search_main(self):
		paramText=self.main_params.get('params')
		if paramText:paramJson=base64.standard_b64decode(paramText).decode(_C);paramJson=json.loads(paramJson);mode=paramJson.get(_A);argsValue=paramJson.get(_U)
		else:mode=self.main_params.get(_A,_G);argsValue=self.main_params
		self.option_check()
		if mode is _G:self.dp_Main_List()
		elif mode==_k:self.dp_Search_Group(argsValue)
		elif mode==_l:self.dp_Nf_Search(argsValue)
		elif mode==_t:self.dp_Search_History(argsValue)
		elif mode==_n:self.dp_History_Delete(argsValue)
		elif mode==_b:self.dp_Bookmark_Menu(argsValue)
		elif mode==_s:self.dp_Set_Bookmark(argsValue)
		else:_G