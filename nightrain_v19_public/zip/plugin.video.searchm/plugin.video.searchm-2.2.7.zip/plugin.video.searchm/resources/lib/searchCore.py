__author__="NightRain"
npCzYPwsGaxfbFLoBHlAjeQDWvhtuX=object
npCzYPwsGaxfbFLoBHlAjeQDWvhtuy=None
npCzYPwsGaxfbFLoBHlAjeQDWvhtuN=True
npCzYPwsGaxfbFLoBHlAjeQDWvhtuO=print
npCzYPwsGaxfbFLoBHlAjeQDWvhtum=str
npCzYPwsGaxfbFLoBHlAjeQDWvhtud=int
npCzYPwsGaxfbFLoBHlAjeQDWvhtug=False
npCzYPwsGaxfbFLoBHlAjeQDWvhtuU=dict
npCzYPwsGaxfbFLoBHlAjeQDWvhtuc=Exception
npCzYPwsGaxfbFLoBHlAjeQDWvhtui=len
npCzYPwsGaxfbFLoBHlAjeQDWvhtuq=open
npCzYPwsGaxfbFLoBHlAjeQDWvhtuK=type
npCzYPwsGaxfbFLoBHlAjeQDWvhtuI=list
npCzYPwsGaxfbFLoBHlAjeQDWvhtur=isinstance
npCzYPwsGaxfbFLoBHlAjeQDWvhtSV=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
import http.cookiejar
import httpx
class npCzYPwsGaxfbFLoBHlAjeQDWvhtVk(npCzYPwsGaxfbFLoBHlAjeQDWvhtuX):
 def __init__(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_WAVVE ='https://apis.wavve.com'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_TVING_SEARCH='https://search-api.tving.com'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_TVING_IMG ='https://image.tving.com'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_WATCHA ='https://api-mars.watcha.com'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_NETFLIX ='https://www.netflix.com'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_COUPANG ='https://www.coupangplay.com'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_PRIMEV ='https://www.primevideo.com'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_DISNEY ='https://disney.api.edge.bamgrid.com/explore'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_DISNEY_VERSION ='v1.11'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.WAVVE_LIMIT =20 
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.TVING_LIMIT =30
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.WATCHA_LIMIT =30
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_LIMIT =20 
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.COUPANG_LIMIT =10 
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DISNEY_LIMIT =10 
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DERECTOR_LIMIT =4
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.CAST_LIMIT =10
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.GENRE_LIMIT =4
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.TVING_MOVIE_LITE=['2610061','2610161','261062']
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.WAVVE_PARAMS ={'apikey':'E5F3E0D30947AA5440556471321BB6D9','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all','client_version':'7.1.40',}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100','APIKEY':'1e7952d0917d6aab1f0293a063697610','TELECODE':'CSCD0900',}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_HEADER={'user-agent':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND1 ='_342x192'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND2 ='_665x375'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_PORT ='_342x684'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LOGO ='_550x124'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF={}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['COOKIES']={}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']={}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ={}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.PV={}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.HTTP_CLIENT=requests.Session()
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.CP_ORIGINAL_COOKIE =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.PV_ORIGINAL_COOKIE =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ_ORIGINAL_COOKIE =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_ORIGINAL_COOKIE =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_SESSION_COOKIES1 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_SESSION_COOKIES2 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_SESSION_COOKIES3 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_SESSION_COOKIES4 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_SESSION_FULLTEXT1 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_SESSION_FULLTEXT2 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_SESSION_FULLTEXT3 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_SESSION_FULLTEXT4 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_CONTEXTJSON_FILE1 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_CONTEXTJSON_FILE2 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_CONTEXTJSON_FILE3 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_CONTEXTJSON_FILE4 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_FALCORJSON_FILE1 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_FALCORJSON_FILE2 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_FALCORJSON_FILE3 =''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_FALCORJSON_FILE4 =''
 '''
 def callRequestCookies(self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):
  #setHeader = {'user-agent' : self.USER_AGENT }
  setHeader = self.DEFAULT_HEADER
  if headers: setHeader.update(headers )
  if jobtype == 'Get': # Get/Post
   res = requests.get(url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  else:
   res = requests.post(url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  return res
 ''' 
 def Call_Request_bak(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,payload=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,json=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,params=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,redirects=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN,method='-'):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVT={'user-agent':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.USER_AGENT}
  if headers:npCzYPwsGaxfbFLoBHlAjeQDWvhtVT.update(headers)
  if payload!=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy or method=='POST':
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.HTTP_CLIENT.post(url=npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,data=payload,json=json,params=params,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtVT,cookies=cookies,allow_redirects=redirects)
  else:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.HTTP_CLIENT.get(url=npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,params=params,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtVT,cookies=cookies,allow_redirects=redirects)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(npCzYPwsGaxfbFLoBHlAjeQDWvhtum(npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.status_code)+' - '+npCzYPwsGaxfbFLoBHlAjeQDWvhtum(npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.url))
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVu
 def Call_Request(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,payload=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,json=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,params=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,redirects=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN,method='-'):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVT={'user-agent':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.USER_AGENT}
  if headers:npCzYPwsGaxfbFLoBHlAjeQDWvhtVT.update(headers)
  if payload!=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy or method=='POST':
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=httpx.post(npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,data=payload,json=json,params=params,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtVT,cookies=cookies,follow_redirects=redirects)
  else:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=httpx.get(npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,params=params,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtVT,cookies=cookies,follow_redirects=redirects)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(npCzYPwsGaxfbFLoBHlAjeQDWvhtum(npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.status_code)+' - '+npCzYPwsGaxfbFLoBHlAjeQDWvhtum(npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.url))
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVu
 def GetNoCache(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,timetype=1,minutes=0):
  if timetype==1:
   ts=npCzYPwsGaxfbFLoBHlAjeQDWvhtud(time.time())
   mi=npCzYPwsGaxfbFLoBHlAjeQDWvhtud(minutes*60)
  else:
   ts=npCzYPwsGaxfbFLoBHlAjeQDWvhtud(time.time()*1000)
   mi=npCzYPwsGaxfbFLoBHlAjeQDWvhtud(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,search_key,sType,page_int):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ=[]
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVE=npCzYPwsGaxfbFLoBHlAjeQDWvhtkT=1
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVM=npCzYPwsGaxfbFLoBHlAjeQDWvhtug
  try:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVX=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_WAVVE+'/fz/search/band.js'
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVy={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':npCzYPwsGaxfbFLoBHlAjeQDWvhtum((page_int-1)*npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.WAVVE_LIMIT),'limit':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.WAVVE_LIMIT,'orderby':'score','mtype':'svod',}
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVy.update(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.WAVVE_PARAMS)
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.Call_Request(npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,payload=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,params=npCzYPwsGaxfbFLoBHlAjeQDWvhtVy,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,method='GET')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVN=json.loads(npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.text)
   if not('celllist' in npCzYPwsGaxfbFLoBHlAjeQDWvhtVN['band']):return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ,npCzYPwsGaxfbFLoBHlAjeQDWvhtVM
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVO=npCzYPwsGaxfbFLoBHlAjeQDWvhtVN['band']['celllist']
   for npCzYPwsGaxfbFLoBHlAjeQDWvhtVm in npCzYPwsGaxfbFLoBHlAjeQDWvhtVO:
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVd=''
    for npCzYPwsGaxfbFLoBHlAjeQDWvhtVg in npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['event_list']:
     if npCzYPwsGaxfbFLoBHlAjeQDWvhtVg['type']=='on-navigation':
      npCzYPwsGaxfbFLoBHlAjeQDWvhtVd=npCzYPwsGaxfbFLoBHlAjeQDWvhtVg['url']
    if npCzYPwsGaxfbFLoBHlAjeQDWvhtVd=='':break
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVU=urllib.parse.urlsplit(npCzYPwsGaxfbFLoBHlAjeQDWvhtVd).query
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVc=npCzYPwsGaxfbFLoBHlAjeQDWvhtVU[0:npCzYPwsGaxfbFLoBHlAjeQDWvhtVU.find('=')]
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVi=npCzYPwsGaxfbFLoBHlAjeQDWvhtuU(urllib.parse.parse_qsl(npCzYPwsGaxfbFLoBHlAjeQDWvhtVU))
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVq=npCzYPwsGaxfbFLoBHlAjeQDWvhtVi.get(npCzYPwsGaxfbFLoBHlAjeQDWvhtVc)
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVc='TVSHOW' if npCzYPwsGaxfbFLoBHlAjeQDWvhtVc=='programid' else 'MOVIE' 
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVK=npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['title_list'][0]['text']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVI =npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['age']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVr={'title':npCzYPwsGaxfbFLoBHlAjeQDWvhtVK}
    npCzYPwsGaxfbFLoBHlAjeQDWvhtkV=npCzYPwsGaxfbFLoBHlAjeQDWvhtug
    for npCzYPwsGaxfbFLoBHlAjeQDWvhtkR in npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['bottom_taglist']:
     if npCzYPwsGaxfbFLoBHlAjeQDWvhtkR=='won':
      npCzYPwsGaxfbFLoBHlAjeQDWvhtkV=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN
      break
    if npCzYPwsGaxfbFLoBHlAjeQDWvhtkV==npCzYPwsGaxfbFLoBHlAjeQDWvhtuN: 
     npCzYPwsGaxfbFLoBHlAjeQDWvhtVr['title']=npCzYPwsGaxfbFLoBHlAjeQDWvhtVr['title']+' [개별구매]'
    if npCzYPwsGaxfbFLoBHlAjeQDWvhtVm.get('age')!='21':
     npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ.append(npCzYPwsGaxfbFLoBHlAjeQDWvhtVr)
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVE=npCzYPwsGaxfbFLoBHlAjeQDWvhtud(npCzYPwsGaxfbFLoBHlAjeQDWvhtVN['band']['pagecount'])
   if npCzYPwsGaxfbFLoBHlAjeQDWvhtVN['band']['count']:npCzYPwsGaxfbFLoBHlAjeQDWvhtkT =npCzYPwsGaxfbFLoBHlAjeQDWvhtud(npCzYPwsGaxfbFLoBHlAjeQDWvhtVN['band']['count'])
   else:npCzYPwsGaxfbFLoBHlAjeQDWvhtkT=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.LIST_LIMIT
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVM=npCzYPwsGaxfbFLoBHlAjeQDWvhtVE>npCzYPwsGaxfbFLoBHlAjeQDWvhtkT
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception)
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ,npCzYPwsGaxfbFLoBHlAjeQDWvhtVM 
 def Get_Search_Tving(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,search_key,sType,page_int):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ=[]
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVM=npCzYPwsGaxfbFLoBHlAjeQDWvhtug
  try:
   if sType=='TVSHOW':
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVX ='https://gw.tving.com/bff/search/v2/more/content/series/search'
    npCzYPwsGaxfbFLoBHlAjeQDWvhtku='AI_SCH_SERIES'
   else:
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVX ='https://gw.tving.com/bff/search/v2/more/content/movie/search'
    npCzYPwsGaxfbFLoBHlAjeQDWvhtku='AI_SCH_MOVIE'
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVy={'keyword':search_key,'pageNo':npCzYPwsGaxfbFLoBHlAjeQDWvhtum(page_int),'pageSize':'20','bandComposeMethod':'MANUAL','bandCode':npCzYPwsGaxfbFLoBHlAjeQDWvhtku,'osCode':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.TVING_PARMAS['OSCODE'],'screenCode':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.TVING_PARMAS['SCREENCODE'],}
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.Call_Request(npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,payload=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,params=npCzYPwsGaxfbFLoBHlAjeQDWvhtVy,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,method='GET')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVN=json.loads(npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.text).get('data').get('bands')[0]
   for npCzYPwsGaxfbFLoBHlAjeQDWvhtVm in npCzYPwsGaxfbFLoBHlAjeQDWvhtVN['items']:
    if sType=='TVSHOW':
     npCzYPwsGaxfbFLoBHlAjeQDWvhtVr={'program':npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['code'],'title':npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['title'],'thumbnail':{'poster':npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['imageUrl']}}
    else:
     npCzYPwsGaxfbFLoBHlAjeQDWvhtVr={'movie':npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['code'],'title':npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['title'],'thumbnail':{'poster':npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['imageUrl']}}
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ.append(npCzYPwsGaxfbFLoBHlAjeQDWvhtVr)
   if 'nextApiUrl' in npCzYPwsGaxfbFLoBHlAjeQDWvhtVN:npCzYPwsGaxfbFLoBHlAjeQDWvhtVM=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception)
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ,npCzYPwsGaxfbFLoBHlAjeQDWvhtVM
 def Get_Search_Watcha(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,search_key,page_int):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ=[]
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVM=npCzYPwsGaxfbFLoBHlAjeQDWvhtug
  try:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVX=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_WATCHA+'/api/search.json'
   npCzYPwsGaxfbFLoBHlAjeQDWvhtkS={'query':search_key,'page':npCzYPwsGaxfbFLoBHlAjeQDWvhtum(page_int),'per':npCzYPwsGaxfbFLoBHlAjeQDWvhtum(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.WATCHA_LIMIT),'exclude':'limited',}
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.Call_Request(npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,payload=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,params=npCzYPwsGaxfbFLoBHlAjeQDWvhtkS,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.WATCHA_HEADER,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,method='GET')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtkJ=json.loads(npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.text)
   if not('results' in npCzYPwsGaxfbFLoBHlAjeQDWvhtkJ):return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ,npCzYPwsGaxfbFLoBHlAjeQDWvhtVM
   npCzYPwsGaxfbFLoBHlAjeQDWvhtkE=npCzYPwsGaxfbFLoBHlAjeQDWvhtkJ['results']
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVM=npCzYPwsGaxfbFLoBHlAjeQDWvhtkJ['meta']['has_next']
   for npCzYPwsGaxfbFLoBHlAjeQDWvhtVm in npCzYPwsGaxfbFLoBHlAjeQDWvhtkE:
    npCzYPwsGaxfbFLoBHlAjeQDWvhtkM =npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['code']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtkX=npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['content_type']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtky =npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['title']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtkN =npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['story']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtkO=npCzYPwsGaxfbFLoBHlAjeQDWvhtTq=npCzYPwsGaxfbFLoBHlAjeQDWvhtTi=''
    if npCzYPwsGaxfbFLoBHlAjeQDWvhtVm.get('poster') !=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy:npCzYPwsGaxfbFLoBHlAjeQDWvhtkO=npCzYPwsGaxfbFLoBHlAjeQDWvhtVm.get('poster').get('original')
    if npCzYPwsGaxfbFLoBHlAjeQDWvhtVm.get('stillcut')!=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy:npCzYPwsGaxfbFLoBHlAjeQDWvhtTq =npCzYPwsGaxfbFLoBHlAjeQDWvhtVm.get('stillcut').get('large')
    if npCzYPwsGaxfbFLoBHlAjeQDWvhtVm.get('thumbnail')!=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy:npCzYPwsGaxfbFLoBHlAjeQDWvhtTi=npCzYPwsGaxfbFLoBHlAjeQDWvhtVm.get('thumbnail').get('large')
    if npCzYPwsGaxfbFLoBHlAjeQDWvhtTi=='' :npCzYPwsGaxfbFLoBHlAjeQDWvhtTi=npCzYPwsGaxfbFLoBHlAjeQDWvhtTq
    npCzYPwsGaxfbFLoBHlAjeQDWvhtkm={'thumb':npCzYPwsGaxfbFLoBHlAjeQDWvhtTq,'poster':npCzYPwsGaxfbFLoBHlAjeQDWvhtkO,'fanart':npCzYPwsGaxfbFLoBHlAjeQDWvhtTi}
    npCzYPwsGaxfbFLoBHlAjeQDWvhtkd =npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['year']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtkg =npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['film_rating_code']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtkU=npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['film_rating_short']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtkc =npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['film_rating_long']
    if npCzYPwsGaxfbFLoBHlAjeQDWvhtkX=='movies':
     npCzYPwsGaxfbFLoBHlAjeQDWvhtki =npCzYPwsGaxfbFLoBHlAjeQDWvhtVm['duration']
    else:
     npCzYPwsGaxfbFLoBHlAjeQDWvhtki ='0'
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVr={'title':npCzYPwsGaxfbFLoBHlAjeQDWvhtky,}
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ.append(npCzYPwsGaxfbFLoBHlAjeQDWvhtVr)
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception)
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ,npCzYPwsGaxfbFLoBHlAjeQDWvhtVM
 def Get_Search_Coupang(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,search_key,page_int):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ=[]
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVM=npCzYPwsGaxfbFLoBHlAjeQDWvhtug
  try:
   CP=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.jsonfile_To_dic(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.CP_ORIGINAL_COOKIE)
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVX=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_COUPANG+'/api-discover/v3/search'
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVy={'query':search_key,'platform':'WEBCLIENT','page':npCzYPwsGaxfbFLoBHlAjeQDWvhtum(page_int),'perPage':'48','filterSearchGroupTypes':'','filterSearchGroupType':'TITLES-EVENT_LIVE-EVENT_CHANNELS','includeChannelContents':'true','includeSportsChannelContents':'true',}
   npCzYPwsGaxfbFLoBHlAjeQDWvhtkq={'x-membersrl':CP['COOKIES']['member_srl'],'x-pcid':CP['COOKIES']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.Call_Request(npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,payload=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,params=npCzYPwsGaxfbFLoBHlAjeQDWvhtVy,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtkq,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,method='GET')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVN=json.loads(npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.text)
   if npCzYPwsGaxfbFLoBHlAjeQDWvhtui(npCzYPwsGaxfbFLoBHlAjeQDWvhtVN.get('data').get('contents'))==0:return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ,npCzYPwsGaxfbFLoBHlAjeQDWvhtVM
   for npCzYPwsGaxfbFLoBHlAjeQDWvhtVm in npCzYPwsGaxfbFLoBHlAjeQDWvhtVN.get('data').get('contents'):
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVr={'title':npCzYPwsGaxfbFLoBHlAjeQDWvhtVm.get('title'),}
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ.append(npCzYPwsGaxfbFLoBHlAjeQDWvhtVr)
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception)
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ,npCzYPwsGaxfbFLoBHlAjeQDWvhtVM
 def Selenium_Cookies_Load(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,in_filename):
  fp=npCzYPwsGaxfbFLoBHlAjeQDWvhtuq(in_filename,'rb',-1)
  try:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtkK=pickle.loads(fp.read())
   if npCzYPwsGaxfbFLoBHlAjeQDWvhtuK(npCzYPwsGaxfbFLoBHlAjeQDWvhtkK)==npCzYPwsGaxfbFLoBHlAjeQDWvhtuI:
    for npCzYPwsGaxfbFLoBHlAjeQDWvhtkI in npCzYPwsGaxfbFLoBHlAjeQDWvhtkK:
     npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.HTTP_CLIENT.cookies.set_cookie(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.To_Cookielib(npCzYPwsGaxfbFLoBHlAjeQDWvhtkI)) 
   else:
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.HTTP_CLIENT.cookies.update(npCzYPwsGaxfbFLoBHlAjeQDWvhtkK) 
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception)
  finally:
   fp.close()
 def To_Cookielib(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,selenium_cookie):
  return http.cookiejar.Cookie(version=0,name=selenium_cookie['name'],value=selenium_cookie['value'],port=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,port_specified=npCzYPwsGaxfbFLoBHlAjeQDWvhtug,domain=selenium_cookie['domain'],domain_specified=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN,domain_initial_dot=npCzYPwsGaxfbFLoBHlAjeQDWvhtug,path=selenium_cookie['path'],path_specified=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN,secure=selenium_cookie['secure'],expires=selenium_cookie['expiry'],discard=npCzYPwsGaxfbFLoBHlAjeQDWvhtug,comment=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,comment_url=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,rest={'HttpOnly':selenium_cookie['httpOnly']},rfc2109=npCzYPwsGaxfbFLoBHlAjeQDWvhtug,)
 def Get_Search_Primev(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,search_key):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ=[]
  try:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.PV=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.jsonfile_To_dic(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.PV_ORIGINAL_COOKIE)
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRV=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.PV['COOKIES']
   npCzYPwsGaxfbFLoBHlAjeQDWvhtkq={'accept':'application/json','x-requested-with':'WebSPA',}
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRk ='dvWebSPAClientVersion=1.0.110699.0'
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVX='https://www.primevideo.com/region/fe/search/ref=atv_nb_sug?ie=UTF8&phrase={}&{}'.format(urllib.parse.quote_plus(search_key),npCzYPwsGaxfbFLoBHlAjeQDWvhtRk)
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.Call_Request(npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,params=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtkq,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtRV,method='GET')
   if npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.status_code!=200:return[]
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRT=json.loads(npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.text)
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRT=npCzYPwsGaxfbFLoBHlAjeQDWvhtRT['page'][0]['assembly']['body'][0]['props']['search']['containers'][0]
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRu=npCzYPwsGaxfbFLoBHlAjeQDWvhtRT.get('entities')
   for npCzYPwsGaxfbFLoBHlAjeQDWvhtRS in npCzYPwsGaxfbFLoBHlAjeQDWvhtRu:
    if 'titleID' not in npCzYPwsGaxfbFLoBHlAjeQDWvhtRS:return[]
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVr={'title':npCzYPwsGaxfbFLoBHlAjeQDWvhtRS.get('title'),}
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ.append(npCzYPwsGaxfbFLoBHlAjeQDWvhtVr)
   '''
   TAG_RESULT = '{"props":{"containers"'
   JSON_REGEX = r'<script type="text/template">\s*(.*?)\s*</script>'
   text_array = re.compile(JSON_REGEX, re.DOTALL).findall(response.text )
   json_str = '{}'
   for cur_str in text_array:
    if TAG_RESULT in cur_str :
     json_str = cur_str
     break
   res_json = json.loads(json_str )
   self.dic_To_jsonfile(self.NF_CONTEXTJSON_FILE1, res_json ) #####
   # 검색 리스트 처리
   PORPS = res_json.get('props')
   for i_containers in PORPS.get('containers'):
    if i_containers.get('containerType') == 'Grid':
     ITEMS = i_containers.get('entities' )
     #OPTS  = i_containers                 
     break
   for i_item in ITEMS:
    if 'titleID' not in i_item: return [] # 검색시 리턴값 없을 때
    temp_list = {'title' : i_item.get('title'), }
    search_list.append(temp_list )
   '''   
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception)
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ
 def Get_Search_Disney(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,search_key):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ=[]
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVX ='{}/{}/search'.format(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_DISNEY,npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_DISNEY_VERSION)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtkq=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.make_DZ_Headers(accessToken=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN,Bearer=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVy ={'query':search_key,}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.Call_Request(npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,params=npCzYPwsGaxfbFLoBHlAjeQDWvhtVy,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtkq,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,method='GET')
  if npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.status_code not in[200,201]:return[]
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRJ=npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.json().get('data').get('page').get('containers')
  for npCzYPwsGaxfbFLoBHlAjeQDWvhtRS in npCzYPwsGaxfbFLoBHlAjeQDWvhtRJ[0]['items']:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVr={'title':npCzYPwsGaxfbFLoBHlAjeQDWvhtRS['visuals']['title'],}
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ.append(npCzYPwsGaxfbFLoBHlAjeQDWvhtVr)
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ
 def Get_Search_Disney_back(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,search_key):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ=[]
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVX=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['services']['content']['getSearchResults']['href']
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRE={'apiVersion':'5.1','region':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge','pageSize':npCzYPwsGaxfbFLoBHlAjeQDWvhtum(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DISNEY_LIMIT),'query':search_key,}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVX=npCzYPwsGaxfbFLoBHlAjeQDWvhtVX.format(**npCzYPwsGaxfbFLoBHlAjeQDWvhtRE)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtkq=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.make_DZ_Headers(accessToken=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN,Bearer=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.Call_Request(npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtkq,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,method='GET')
  if npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.status_code not in[200,201]:return[]
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRJ=npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.json().get('data').get('search')
  for npCzYPwsGaxfbFLoBHlAjeQDWvhtRS in npCzYPwsGaxfbFLoBHlAjeQDWvhtRJ.get('hits'):
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRS=npCzYPwsGaxfbFLoBHlAjeQDWvhtRS.get('hit')
   if npCzYPwsGaxfbFLoBHlAjeQDWvhtRS.get('type')=='DmcSeries': 
    npCzYPwsGaxfbFLoBHlAjeQDWvhtky =npCzYPwsGaxfbFLoBHlAjeQDWvhtRS.get('text').get('title').get('full').get('series').get('default').get('content')
   elif npCzYPwsGaxfbFLoBHlAjeQDWvhtRS.get('type')=='DmcVideo':
    npCzYPwsGaxfbFLoBHlAjeQDWvhtky =npCzYPwsGaxfbFLoBHlAjeQDWvhtRS.get('text').get('title').get('full').get('program').get('default').get('content')
   elif npCzYPwsGaxfbFLoBHlAjeQDWvhtRS.get('type')=='StandardCollection':
    npCzYPwsGaxfbFLoBHlAjeQDWvhtky =npCzYPwsGaxfbFLoBHlAjeQDWvhtRS.get('text').get('title').get('full').get('collection').get('default').get('content')
   else:
    return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVr={'title':npCzYPwsGaxfbFLoBHlAjeQDWvhtky,}
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ.append(npCzYPwsGaxfbFLoBHlAjeQDWvhtVr)
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ
 def dic_To_jsonfile(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,filename,npCzYPwsGaxfbFLoBHlAjeQDWvhtRM):
  if filename=='':return
  fp=npCzYPwsGaxfbFLoBHlAjeQDWvhtuq(filename,'w',-1,'utf-8')
  json.dump(npCzYPwsGaxfbFLoBHlAjeQDWvhtRM,fp,indent=4,ensure_ascii=npCzYPwsGaxfbFLoBHlAjeQDWvhtug)
  fp.close()
 def jsonfile_To_dic(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,filename):
  if filename=='':return npCzYPwsGaxfbFLoBHlAjeQDWvhtuy
  try:
   fp=npCzYPwsGaxfbFLoBHlAjeQDWvhtuq(filename,'r',-1,'utf-8')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRy=json.load(fp)
   fp.close()
  except:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRy={}
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtRy
 def tempFileSave(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,filename,resText):
  if filename=='':return
  fp=npCzYPwsGaxfbFLoBHlAjeQDWvhtuq(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,filename):
  if filename=='':return
  try:
   fp=npCzYPwsGaxfbFLoBHlAjeQDWvhtuq(filename,'r',-1,'utf-8')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRy=fp.read()
   fp.close()
  except:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRy=''
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtRy
 def make_DZ_Headers(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,accessToken=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN,Bearer=npCzYPwsGaxfbFLoBHlAjeQDWvhtug):
  if accessToken:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRN=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['account']['accessToken']
  else:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRN=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['headers']['clientApiKey']
  if Bearer:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRN='Bearer {}'.format(npCzYPwsGaxfbFLoBHlAjeQDWvhtRN)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['headers']['sdkVersion']='34.4' 
  npCzYPwsGaxfbFLoBHlAjeQDWvhtkq={'authorization':npCzYPwsGaxfbFLoBHlAjeQDWvhtRN,'x-application-version':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['headers']['buildId'],'x-bamsdk-client-id':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['headers']['clientId'],'x-bamsdk-platform':'javascript/windows/chrome','x-bamsdk-platform-id':'browser','x-bamsdk-version':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['headers']['sdkVersion'],'x-bamtech-wpnx-mlp-identifier':'/','x-bamtech-wpnx-mlp-locale':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['headers']['lang'],}
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtkq
 def DZ_ReToken(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR):
  try:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVX =npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['services']['orchestration']['refreshToken']['href']
   npCzYPwsGaxfbFLoBHlAjeQDWvhtkq=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.make_DZ_Headers(accessToken=npCzYPwsGaxfbFLoBHlAjeQDWvhtug,Bearer=npCzYPwsGaxfbFLoBHlAjeQDWvhtug)
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRO={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['account']['refreshToken'],}}}
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.Call_Request(npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,json=npCzYPwsGaxfbFLoBHlAjeQDWvhtRO,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtkq,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,method='POST')
   if npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.status_code not in[200,201]:return npCzYPwsGaxfbFLoBHlAjeQDWvhtug
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRJ=npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.json()
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['account']['accessToken'] =npCzYPwsGaxfbFLoBHlAjeQDWvhtRJ.get('extensions').get('sdk').get('token').get('accessToken')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['account']['accessTokenType']=npCzYPwsGaxfbFLoBHlAjeQDWvhtRJ.get('extensions').get('sdk').get('token').get('accessTokenType')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['account']['refreshToken'] =npCzYPwsGaxfbFLoBHlAjeQDWvhtRJ.get('extensions').get('sdk').get('token').get('refreshToken')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['account']['token_limit'] =npCzYPwsGaxfbFLoBHlAjeQDWvhtud(time.time())+14400 
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['account']['deviceId'] =npCzYPwsGaxfbFLoBHlAjeQDWvhtRJ.get('extensions').get('sdk').get('session').get('device').get('id')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DZ['account']['sessionId'] =npCzYPwsGaxfbFLoBHlAjeQDWvhtRJ.get('extensions').get('sdk').get('session').get('sessionId')
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception)
   return npCzYPwsGaxfbFLoBHlAjeQDWvhtug
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtuN
 def Init_NF_Total(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF={}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['COOKIES']={}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']={}
 def make_NF_XnetflixHeaders(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtkq={'x-netflix.browsername':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':npCzYPwsGaxfbFLoBHlAjeQDWvhtum(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['esnModel'],'x-netflix.esnprefix':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['nowGuid'],'x-netflix.uiversion':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtkq
 def make_NF_ApiParams(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVy={'avif':'false','webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','isTop10KidsSupported':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/mre/pathEvaluator',}
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVy
 def extract_json(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,content,name):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRm=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRd=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRg=re.compile(npCzYPwsGaxfbFLoBHlAjeQDWvhtRm.format(name),re.DOTALL).findall(content)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRd=npCzYPwsGaxfbFLoBHlAjeQDWvhtRg[0]
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRU=npCzYPwsGaxfbFLoBHlAjeQDWvhtRd.replace('\\"','\\\\"') 
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRU=npCzYPwsGaxfbFLoBHlAjeQDWvhtRU.replace('\\s','\\\\s') 
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRU=npCzYPwsGaxfbFLoBHlAjeQDWvhtRU.replace('\\n','\\\\n') 
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRU=npCzYPwsGaxfbFLoBHlAjeQDWvhtRU.replace('\\t','\\\\t') 
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRU=npCzYPwsGaxfbFLoBHlAjeQDWvhtRU.encode().decode('unicode_escape') 
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRU=re.sub(r'\\(?!["])',r'\\\\',npCzYPwsGaxfbFLoBHlAjeQDWvhtRU) 
  return json.loads(npCzYPwsGaxfbFLoBHlAjeQDWvhtRU)
 def NF_makestr_paths(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,paths):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRy=[]
  if npCzYPwsGaxfbFLoBHlAjeQDWvhtur(paths,npCzYPwsGaxfbFLoBHlAjeQDWvhtud):
   return '%d'%(paths)
  elif npCzYPwsGaxfbFLoBHlAjeQDWvhtur(paths,npCzYPwsGaxfbFLoBHlAjeQDWvhtum):
   return '"%s"'%(paths)
  for npCzYPwsGaxfbFLoBHlAjeQDWvhtRc in paths:
   if npCzYPwsGaxfbFLoBHlAjeQDWvhtur(npCzYPwsGaxfbFLoBHlAjeQDWvhtRc,npCzYPwsGaxfbFLoBHlAjeQDWvhtud):
    npCzYPwsGaxfbFLoBHlAjeQDWvhtRy.append('%d'%(npCzYPwsGaxfbFLoBHlAjeQDWvhtRc))
   elif npCzYPwsGaxfbFLoBHlAjeQDWvhtur(npCzYPwsGaxfbFLoBHlAjeQDWvhtRc,npCzYPwsGaxfbFLoBHlAjeQDWvhtum):
    npCzYPwsGaxfbFLoBHlAjeQDWvhtRy.append('"%s"'%(npCzYPwsGaxfbFLoBHlAjeQDWvhtRc))
   elif npCzYPwsGaxfbFLoBHlAjeQDWvhtur(npCzYPwsGaxfbFLoBHlAjeQDWvhtRc,npCzYPwsGaxfbFLoBHlAjeQDWvhtuI):
    npCzYPwsGaxfbFLoBHlAjeQDWvhtRy.append('[%s]'%(','.join(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_makestr_paths(npCzYPwsGaxfbFLoBHlAjeQDWvhtRc))))
   elif npCzYPwsGaxfbFLoBHlAjeQDWvhtur(npCzYPwsGaxfbFLoBHlAjeQDWvhtRc,npCzYPwsGaxfbFLoBHlAjeQDWvhtuU):
    npCzYPwsGaxfbFLoBHlAjeQDWvhtRi=''
    for npCzYPwsGaxfbFLoBHlAjeQDWvhtRq,npCzYPwsGaxfbFLoBHlAjeQDWvhtRK in npCzYPwsGaxfbFLoBHlAjeQDWvhtRc.items():
     npCzYPwsGaxfbFLoBHlAjeQDWvhtRi+='"%s":%s,'%(npCzYPwsGaxfbFLoBHlAjeQDWvhtRq,npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_makestr_paths(npCzYPwsGaxfbFLoBHlAjeQDWvhtRK))
    npCzYPwsGaxfbFLoBHlAjeQDWvhtRy.append('{%s}'%(npCzYPwsGaxfbFLoBHlAjeQDWvhtRi[:-1]))
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtRy
 def NF_Call_pathapi(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,npCzYPwsGaxfbFLoBHlAjeQDWvhtTM,referer=''):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRI='%s/nq/website/memberapi/%s/pathEvaluator'%(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_NETFLIX,npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['identifier'])
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRO={'path':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_makestr_paths(npCzYPwsGaxfbFLoBHlAjeQDWvhtTM),'authURL':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']['authURL']}
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVy=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.make_NF_ApiParams()
  npCzYPwsGaxfbFLoBHlAjeQDWvhtkq={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_NETFLIX,'sec-ch-ua':'"Google Chrome";v="101", "Not)A;Brand";v="8", "Chromium";v="101"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':npCzYPwsGaxfbFLoBHlAjeQDWvhtkq['referer']=referer
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRr=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.make_NF_XnetflixHeaders()
  npCzYPwsGaxfbFLoBHlAjeQDWvhtkq.update(npCzYPwsGaxfbFLoBHlAjeQDWvhtRr)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRV=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_Get_DefaultCookies()
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRV['profilesNewSession']='0'
  try:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.Call_Request(npCzYPwsGaxfbFLoBHlAjeQDWvhtRI,payload=npCzYPwsGaxfbFLoBHlAjeQDWvhtRO,params=npCzYPwsGaxfbFLoBHlAjeQDWvhtVy,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtkq,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtRV,method='POST')
   return npCzYPwsGaxfbFLoBHlAjeQDWvhtVu
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception)
   return npCzYPwsGaxfbFLoBHlAjeQDWvhtuy
 def Get_Search_Netflix(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,search_key,page_int,byReference=''):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTV=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.DERECTOR_LIMIT
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTk =npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.CAST_LIMIT
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTR =npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.GENRE_LIMIT
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTu =npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_LIMIT*(page_int-1)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTS =npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_LIMIT*page_int 
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTJ="|%s"%(search_key)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTE ='%s/search?%s'%(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtTM=[["search","byTerm",npCzYPwsGaxfbFLoBHlAjeQDWvhtTJ,"titles",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_LIMIT,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"summary"],["search","byTerm",npCzYPwsGaxfbFLoBHlAjeQDWvhtTJ,"titles",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_LIMIT,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",npCzYPwsGaxfbFLoBHlAjeQDWvhtTJ,"titles",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_LIMIT,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference","boxarts",[npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND2,npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_PORT],"jpg"],["search","byTerm",npCzYPwsGaxfbFLoBHlAjeQDWvhtTJ,"titles",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_LIMIT,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference","interestingMoment",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND1,"jpg"],["search","byTerm",npCzYPwsGaxfbFLoBHlAjeQDWvhtTJ,"titles",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_LIMIT,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference","storyArt",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND2,"jpg"],["search","byTerm",npCzYPwsGaxfbFLoBHlAjeQDWvhtTJ,"titles",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_LIMIT,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference",["cast","creators","directors"],{"from":0,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTV},["id","name"]],["search","byTerm",npCzYPwsGaxfbFLoBHlAjeQDWvhtTJ,"titles",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_LIMIT,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference","genres",{"from":0,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTR},["id","name"]],["search","byTerm",npCzYPwsGaxfbFLoBHlAjeQDWvhtTJ,"titles",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NETFLIX_LIMIT,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LOGO,"png"],]
  else:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtTM=[["search","byReference",byReference,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"summary"],["search","byReference",byReference,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference","boxarts",[npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND2,npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference","interestingMoment",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference","storyArt",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference",["cast","creators","directors"],{"from":0,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTV},["id","name"]],["search","byReference",byReference,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference","genres",{"from":0,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTR},["id","name"]],["search","byReference",byReference,{"from":npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,"to":npCzYPwsGaxfbFLoBHlAjeQDWvhtTS},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LOGO,"png"],]
  try:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_Call_pathapi(npCzYPwsGaxfbFLoBHlAjeQDWvhtTM,npCzYPwsGaxfbFLoBHlAjeQDWvhtTE)
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVN=json.loads(npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.text)
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception)
  (npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ,npCzYPwsGaxfbFLoBHlAjeQDWvhtVM,byReference)=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.Search_Netflix_Make(npCzYPwsGaxfbFLoBHlAjeQDWvhtVN)
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ,npCzYPwsGaxfbFLoBHlAjeQDWvhtVM,byReference
 def Search_Netflix_Make(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,jsonSource):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ=[]
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVM =npCzYPwsGaxfbFLoBHlAjeQDWvhtug
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTX=''
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTy=jsonSource.get('paths')[0][1]
  if npCzYPwsGaxfbFLoBHlAjeQDWvhtTy=='byTerm':
   npCzYPwsGaxfbFLoBHlAjeQDWvhtTu =jsonSource['paths'][0][5]['from']
   npCzYPwsGaxfbFLoBHlAjeQDWvhtTS =jsonSource['paths'][0][5]['to']
  else:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtTu =jsonSource['paths'][0][3]['from']
   npCzYPwsGaxfbFLoBHlAjeQDWvhtTS =jsonSource['paths'][0][3]['to']
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTX=npCzYPwsGaxfbFLoBHlAjeQDWvhtuI(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTN=jsonSource.get('jsonGraph').get('search').get('byReference').get(npCzYPwsGaxfbFLoBHlAjeQDWvhtTX)
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTO =jsonSource.get('jsonGraph').get('videos')
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTm=jsonSource.get('jsonGraph').get('person')
  npCzYPwsGaxfbFLoBHlAjeQDWvhtTd=jsonSource.get('jsonGraph').get('genres')
  npCzYPwsGaxfbFLoBHlAjeQDWvhtVM=npCzYPwsGaxfbFLoBHlAjeQDWvhtuN if npCzYPwsGaxfbFLoBHlAjeQDWvhtTN[npCzYPwsGaxfbFLoBHlAjeQDWvhtum(npCzYPwsGaxfbFLoBHlAjeQDWvhtTS)]['reference']['$type']=='ref' else npCzYPwsGaxfbFLoBHlAjeQDWvhtug
  for npCzYPwsGaxfbFLoBHlAjeQDWvhtTg in npCzYPwsGaxfbFLoBHlAjeQDWvhtSV(npCzYPwsGaxfbFLoBHlAjeQDWvhtTu,npCzYPwsGaxfbFLoBHlAjeQDWvhtTS):
   if npCzYPwsGaxfbFLoBHlAjeQDWvhtTN[npCzYPwsGaxfbFLoBHlAjeQDWvhtum(npCzYPwsGaxfbFLoBHlAjeQDWvhtTg)]['reference']['$type']=='ref':
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVq =npCzYPwsGaxfbFLoBHlAjeQDWvhtTN[npCzYPwsGaxfbFLoBHlAjeQDWvhtum(npCzYPwsGaxfbFLoBHlAjeQDWvhtTg)]['reference']['value'][1]
    npCzYPwsGaxfbFLoBHlAjeQDWvhtTU=npCzYPwsGaxfbFLoBHlAjeQDWvhtTO[npCzYPwsGaxfbFLoBHlAjeQDWvhtVq]
    npCzYPwsGaxfbFLoBHlAjeQDWvhtky =npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['title']['value']
    if npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['availability']['value']['isPlayable']==npCzYPwsGaxfbFLoBHlAjeQDWvhtug:
     continue
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVc =npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['summary']['value']['type']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtki =0 if npCzYPwsGaxfbFLoBHlAjeQDWvhtVc!='movie' else npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['runtime']['value']
    if npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['sequiturEvidence']['value']['value']:
     npCzYPwsGaxfbFLoBHlAjeQDWvhtTc=npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['sequiturEvidence']['value']['value']['text']
    else:
     npCzYPwsGaxfbFLoBHlAjeQDWvhtTc=''
    npCzYPwsGaxfbFLoBHlAjeQDWvhtkO =npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['boxarts'][npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_PORT]['jpg']['value']['url']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtTi =npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['boxarts'][npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND2]['jpg']['value']['url']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtTq=''
    if 'value' in npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['storyArt'][npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND2]['jpg']:
     npCzYPwsGaxfbFLoBHlAjeQDWvhtTq =npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['storyArt'][npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND2]['jpg']['value']['url']
    if npCzYPwsGaxfbFLoBHlAjeQDWvhtTq=='' and 'value' in npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['interestingMoment'][npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND1]['jpg']:
     npCzYPwsGaxfbFLoBHlAjeQDWvhtTq =npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['interestingMoment'][npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LAND1]['jpg']['value']['url']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtTK=''
    if 'value' in npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LOGO]['png']:
     npCzYPwsGaxfbFLoBHlAjeQDWvhtTK=npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.ART_SIZE_LOGO]['png']['value']['url']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtTI =npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_Subid_List(npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['genres'])
    for i in npCzYPwsGaxfbFLoBHlAjeQDWvhtSV(npCzYPwsGaxfbFLoBHlAjeQDWvhtui(npCzYPwsGaxfbFLoBHlAjeQDWvhtTI)):
     npCzYPwsGaxfbFLoBHlAjeQDWvhtTI[i]=npCzYPwsGaxfbFLoBHlAjeQDWvhtTd[npCzYPwsGaxfbFLoBHlAjeQDWvhtTI[i]]['name']['value']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtTr=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_Subid_List(npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['directors'])
    npCzYPwsGaxfbFLoBHlAjeQDWvhtuV =npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_Subid_List(npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['creators'])
    npCzYPwsGaxfbFLoBHlAjeQDWvhtTr.extend(npCzYPwsGaxfbFLoBHlAjeQDWvhtuV)
    for i in npCzYPwsGaxfbFLoBHlAjeQDWvhtSV(npCzYPwsGaxfbFLoBHlAjeQDWvhtui(npCzYPwsGaxfbFLoBHlAjeQDWvhtTr)):
     npCzYPwsGaxfbFLoBHlAjeQDWvhtTr[i]=npCzYPwsGaxfbFLoBHlAjeQDWvhtTm[npCzYPwsGaxfbFLoBHlAjeQDWvhtTr[i]]['name']['value']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtuk=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_Subid_List(npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['cast'])
    for i in npCzYPwsGaxfbFLoBHlAjeQDWvhtSV(npCzYPwsGaxfbFLoBHlAjeQDWvhtui(npCzYPwsGaxfbFLoBHlAjeQDWvhtuk)):
     npCzYPwsGaxfbFLoBHlAjeQDWvhtuk[i]=npCzYPwsGaxfbFLoBHlAjeQDWvhtTm[npCzYPwsGaxfbFLoBHlAjeQDWvhtuk[i]]['name']['value']
    if 'maturityDescription' in npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['maturity']['value']['rating']:
     npCzYPwsGaxfbFLoBHlAjeQDWvhtuR=npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['maturity']['value']['rating']['maturityDescription']
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVr={'videoid':npCzYPwsGaxfbFLoBHlAjeQDWvhtVq,'vidtype':npCzYPwsGaxfbFLoBHlAjeQDWvhtVc,'title':npCzYPwsGaxfbFLoBHlAjeQDWvhtky,'mpaa':npCzYPwsGaxfbFLoBHlAjeQDWvhtuR,'regularSynopsis':npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['regularSynopsis']['value'],'dpSupplemental':npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['dpSupplementalMessage']['value'],'sequiturEvidence':npCzYPwsGaxfbFLoBHlAjeQDWvhtTc,'thumbnail':{'poster':npCzYPwsGaxfbFLoBHlAjeQDWvhtkO,'thumb':npCzYPwsGaxfbFLoBHlAjeQDWvhtTq,'fanart':npCzYPwsGaxfbFLoBHlAjeQDWvhtTi,'clearlogo':npCzYPwsGaxfbFLoBHlAjeQDWvhtTK},'year':npCzYPwsGaxfbFLoBHlAjeQDWvhtTU['releaseYear']['value'],'duration':npCzYPwsGaxfbFLoBHlAjeQDWvhtki,'info_genre':npCzYPwsGaxfbFLoBHlAjeQDWvhtTI,'director':npCzYPwsGaxfbFLoBHlAjeQDWvhtTr,'cast':npCzYPwsGaxfbFLoBHlAjeQDWvhtuk,}
    npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ.append(npCzYPwsGaxfbFLoBHlAjeQDWvhtVr)
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtVJ,npCzYPwsGaxfbFLoBHlAjeQDWvhtVM,npCzYPwsGaxfbFLoBHlAjeQDWvhtTX
 def NF_Subid_List(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,subJson):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtuT=[]
  try:
   for i in npCzYPwsGaxfbFLoBHlAjeQDWvhtSV(npCzYPwsGaxfbFLoBHlAjeQDWvhtui(subJson)):
    if subJson.get(npCzYPwsGaxfbFLoBHlAjeQDWvhtum(i)).get('$type')!='ref':break
    npCzYPwsGaxfbFLoBHlAjeQDWvhtuS=subJson.get(npCzYPwsGaxfbFLoBHlAjeQDWvhtum(i)).get('value')[1]
    npCzYPwsGaxfbFLoBHlAjeQDWvhtuT.append(npCzYPwsGaxfbFLoBHlAjeQDWvhtuS)
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception)
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtuT
 def NF_CookieFile_Load(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR,cookie_filename):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRV={}
  try:
   if os.path.isfile(cookie_filename)==npCzYPwsGaxfbFLoBHlAjeQDWvhtug:return{}
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuJ=npCzYPwsGaxfbFLoBHlAjeQDWvhtuq(cookie_filename,'rb',-1)
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuE =pickle.loads(npCzYPwsGaxfbFLoBHlAjeQDWvhtuJ.read())
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuJ.close()
   for npCzYPwsGaxfbFLoBHlAjeQDWvhtkI in npCzYPwsGaxfbFLoBHlAjeQDWvhtuE:
    npCzYPwsGaxfbFLoBHlAjeQDWvhtRV[npCzYPwsGaxfbFLoBHlAjeQDWvhtkI.name]=npCzYPwsGaxfbFLoBHlAjeQDWvhtkI.value
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception) 
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtRV
 def NF_Get_DefaultCookies(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR):
  npCzYPwsGaxfbFLoBHlAjeQDWvhtRV={}
  if npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['COOKIES']['flwssn'] :npCzYPwsGaxfbFLoBHlAjeQDWvhtRV['flwssn'] =npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['COOKIES']['flwssn']
  if npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['COOKIES']['nfvdid'] :npCzYPwsGaxfbFLoBHlAjeQDWvhtRV['nfvdid'] =npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['COOKIES']['nfvdid']
  if npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['COOKIES']['SecureNetflixId']:npCzYPwsGaxfbFLoBHlAjeQDWvhtRV['SecureNetflixId']=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['COOKIES']['SecureNetflixId']
  if npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['COOKIES']['NetflixId'] :npCzYPwsGaxfbFLoBHlAjeQDWvhtRV['NetflixId'] =npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['COOKIES']['NetflixId']
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtRV
 def NF_Get_BaseSession(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR):
  try:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVX=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.API_NETFLIX+'/browse' 
   npCzYPwsGaxfbFLoBHlAjeQDWvhtRV=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_Get_DefaultCookies()
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVu=npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.Call_Request(npCzYPwsGaxfbFLoBHlAjeQDWvhtVX,payload=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,params=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,headers=npCzYPwsGaxfbFLoBHlAjeQDWvhtuy,cookies=npCzYPwsGaxfbFLoBHlAjeQDWvhtRV,method='GET')
   if npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.status_code!=200:
    npCzYPwsGaxfbFLoBHlAjeQDWvhtuO('pass 1 status_code error')
    return npCzYPwsGaxfbFLoBHlAjeQDWvhtug
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuM =npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.extract_json(npCzYPwsGaxfbFLoBHlAjeQDWvhtVu.text,'reactContext')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF['SESSION']={'mainGuid':npCzYPwsGaxfbFLoBHlAjeQDWvhtuM['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':npCzYPwsGaxfbFLoBHlAjeQDWvhtuM['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':npCzYPwsGaxfbFLoBHlAjeQDWvhtuM['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':npCzYPwsGaxfbFLoBHlAjeQDWvhtuM['models']['memberContext']['data']['userInfo']['esn'],'identifier':npCzYPwsGaxfbFLoBHlAjeQDWvhtuM['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':npCzYPwsGaxfbFLoBHlAjeQDWvhtuM['models']['abContext']['data']['headers'],}
   npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.dic_To_jsonfile(npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF_SESSION_COOKIES1,npCzYPwsGaxfbFLoBHlAjeQDWvhtVR.NF)
  except npCzYPwsGaxfbFLoBHlAjeQDWvhtuc as exception:
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO('pass 1 error')
   npCzYPwsGaxfbFLoBHlAjeQDWvhtuO(exception)
   return npCzYPwsGaxfbFLoBHlAjeQDWvhtug
  return npCzYPwsGaxfbFLoBHlAjeQDWvhtuN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
