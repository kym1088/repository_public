__author__="NightRain"
VYqdAsEtiKLSrhRJkCcNTufHXzOMgW=object
VYqdAsEtiKLSrhRJkCcNTufHXzOMgv=None
VYqdAsEtiKLSrhRJkCcNTufHXzOMgP=True
VYqdAsEtiKLSrhRJkCcNTufHXzOMge=False
VYqdAsEtiKLSrhRJkCcNTufHXzOMgp=type
VYqdAsEtiKLSrhRJkCcNTufHXzOMgQ=dict
VYqdAsEtiKLSrhRJkCcNTufHXzOMgG=open
VYqdAsEtiKLSrhRJkCcNTufHXzOMgI=len
VYqdAsEtiKLSrhRJkCcNTufHXzOMgl=Exception
VYqdAsEtiKLSrhRJkCcNTufHXzOMjx=int
VYqdAsEtiKLSrhRJkCcNTufHXzOMja=range
VYqdAsEtiKLSrhRJkCcNTufHXzOMjb=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
VYqdAsEtiKLSrhRJkCcNTufHXzOMxb=[{'title':'통합검색 (웨이브,티빙,쿠팡,디즈니)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
VYqdAsEtiKLSrhRJkCcNTufHXzOMxw={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
VYqdAsEtiKLSrhRJkCcNTufHXzOMxg=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
VYqdAsEtiKLSrhRJkCcNTufHXzOMxj =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class VYqdAsEtiKLSrhRJkCcNTufHXzOMxa(VYqdAsEtiKLSrhRJkCcNTufHXzOMgW):
 def __init__(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,VYqdAsEtiKLSrhRJkCcNTufHXzOMxU,VYqdAsEtiKLSrhRJkCcNTufHXzOMxD,VYqdAsEtiKLSrhRJkCcNTufHXzOMxy):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo._addon_url =VYqdAsEtiKLSrhRJkCcNTufHXzOMxU
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo._addon_handle=VYqdAsEtiKLSrhRJkCcNTufHXzOMxD
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.main_params =VYqdAsEtiKLSrhRJkCcNTufHXzOMxy
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj =npCzYPwsGaxfbFLoBHlAjeQDWvhtVk() 
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_authinfo.json'))
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,sting):
  try:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxm=xbmcgui.Dialog()
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxm.notification(__addonname__,sting)
  except:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMgv
 def addon_log(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,string):
  try:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxn=string.encode('utf-8','ignore')
  except:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxn='addonException: addon_log'
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxB=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,VYqdAsEtiKLSrhRJkCcNTufHXzOMxn),level=VYqdAsEtiKLSrhRJkCcNTufHXzOMxB)
 def get_keyboard_input(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,VYqdAsEtiKLSrhRJkCcNTufHXzOMxG):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxW=VYqdAsEtiKLSrhRJkCcNTufHXzOMgv
  kb=xbmc.Keyboard()
  kb.setHeading(VYqdAsEtiKLSrhRJkCcNTufHXzOMxG)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxW=kb.getText()
  return VYqdAsEtiKLSrhRJkCcNTufHXzOMxW
 def get_settings_menubookmark(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxv=VYqdAsEtiKLSrhRJkCcNTufHXzOMgP if __addon__.getSetting('menu_bookmark')=='true' else VYqdAsEtiKLSrhRJkCcNTufHXzOMge
  return(VYqdAsEtiKLSrhRJkCcNTufHXzOMxv)
 def get_settings_makebookmark(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo):
  return VYqdAsEtiKLSrhRJkCcNTufHXzOMgP if __addon__.getSetting('make_bookmark')=='true' else VYqdAsEtiKLSrhRJkCcNTufHXzOMge
 def get_settings_select_info(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxP=[]
  if __addon__.getSetting('wavveyn')=='true':VYqdAsEtiKLSrhRJkCcNTufHXzOMxP.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':VYqdAsEtiKLSrhRJkCcNTufHXzOMxP.append('tving')
  if __addon__.getSetting('watchayn')=='true':VYqdAsEtiKLSrhRJkCcNTufHXzOMxP.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':VYqdAsEtiKLSrhRJkCcNTufHXzOMxP.append('coupang')
  if __addon__.getSetting('primevyn')=='true':VYqdAsEtiKLSrhRJkCcNTufHXzOMxP.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':VYqdAsEtiKLSrhRJkCcNTufHXzOMxP.append('disney')
  return VYqdAsEtiKLSrhRJkCcNTufHXzOMxP
 def add_dir(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,label,sublabel='',img='',infoLabels=VYqdAsEtiKLSrhRJkCcNTufHXzOMgv,isFolder=VYqdAsEtiKLSrhRJkCcNTufHXzOMgP,params='',isLink=VYqdAsEtiKLSrhRJkCcNTufHXzOMge,ContextMenu=VYqdAsEtiKLSrhRJkCcNTufHXzOMgv,direct_url=VYqdAsEtiKLSrhRJkCcNTufHXzOMgv):
  if direct_url:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxe=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ=json.dumps(params,separators=(',',':'))
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ=base64.standard_b64encode(VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ.encode()).decode('utf-8')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ=VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ.replace('+','%2B')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxe='%s?params=%s'%(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo._addon_url,VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ)
  if sublabel and sublabel!='-':VYqdAsEtiKLSrhRJkCcNTufHXzOMxG='%s < %s >'%(label,sublabel)
  else: VYqdAsEtiKLSrhRJkCcNTufHXzOMxG=label
  if not img:img='DefaultFolder.png'
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxI=xbmcgui.ListItem(VYqdAsEtiKLSrhRJkCcNTufHXzOMxG)
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMgp(img)==VYqdAsEtiKLSrhRJkCcNTufHXzOMgQ:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxI.setArt(img)
  else:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxI.setArt({'thumb':img,'poster':img})
  if infoLabels:VYqdAsEtiKLSrhRJkCcNTufHXzOMxI.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxI.setProperty('IsPlayable','true')
  if ContextMenu:VYqdAsEtiKLSrhRJkCcNTufHXzOMxI.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo._addon_handle,VYqdAsEtiKLSrhRJkCcNTufHXzOMxe,VYqdAsEtiKLSrhRJkCcNTufHXzOMxI,isFolder)
 def Load_Searched_List(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo):
  try:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxl=VYqdAsEtiKLSrhRJkCcNTufHXzOMxj
   fp=VYqdAsEtiKLSrhRJkCcNTufHXzOMgG(VYqdAsEtiKLSrhRJkCcNTufHXzOMxl,'r',-1,'utf-8')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMax=fp.readlines()
   fp.close()
  except:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMax=[]
  return VYqdAsEtiKLSrhRJkCcNTufHXzOMax
 def Save_Searched_List(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,VYqdAsEtiKLSrhRJkCcNTufHXzOMbe):
  try:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxl=VYqdAsEtiKLSrhRJkCcNTufHXzOMxj
   VYqdAsEtiKLSrhRJkCcNTufHXzOMab=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.Load_Searched_List() 
   VYqdAsEtiKLSrhRJkCcNTufHXzOMaw={'skey':VYqdAsEtiKLSrhRJkCcNTufHXzOMbe.strip()}
   fp=VYqdAsEtiKLSrhRJkCcNTufHXzOMgG(VYqdAsEtiKLSrhRJkCcNTufHXzOMxl,'w',-1,'utf-8')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMag=urllib.parse.urlencode(VYqdAsEtiKLSrhRJkCcNTufHXzOMaw)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMag=VYqdAsEtiKLSrhRJkCcNTufHXzOMag+'\n'
   fp.write(VYqdAsEtiKLSrhRJkCcNTufHXzOMag)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMaj=0
   for VYqdAsEtiKLSrhRJkCcNTufHXzOMao in VYqdAsEtiKLSrhRJkCcNTufHXzOMab:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMaU=VYqdAsEtiKLSrhRJkCcNTufHXzOMgQ(urllib.parse.parse_qsl(VYqdAsEtiKLSrhRJkCcNTufHXzOMao))
    VYqdAsEtiKLSrhRJkCcNTufHXzOMaD=VYqdAsEtiKLSrhRJkCcNTufHXzOMaw.get('skey').strip()
    VYqdAsEtiKLSrhRJkCcNTufHXzOMay=VYqdAsEtiKLSrhRJkCcNTufHXzOMaU.get('skey').strip()
    if VYqdAsEtiKLSrhRJkCcNTufHXzOMaD!=VYqdAsEtiKLSrhRJkCcNTufHXzOMay:
     fp.write(VYqdAsEtiKLSrhRJkCcNTufHXzOMao)
     VYqdAsEtiKLSrhRJkCcNTufHXzOMaj+=1
     if VYqdAsEtiKLSrhRJkCcNTufHXzOMaj>=50:break
   fp.close()
  except:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMgv
 def dp_Search_History(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,args):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMaF=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.Load_Searched_List()
  for VYqdAsEtiKLSrhRJkCcNTufHXzOMam in VYqdAsEtiKLSrhRJkCcNTufHXzOMaF:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMan=VYqdAsEtiKLSrhRJkCcNTufHXzOMgQ(urllib.parse.parse_qsl(VYqdAsEtiKLSrhRJkCcNTufHXzOMam))
   VYqdAsEtiKLSrhRJkCcNTufHXzOMaB=VYqdAsEtiKLSrhRJkCcNTufHXzOMan.get('skey').strip()
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxp={'mode':'TOTAL_SEARCH','search_key':VYqdAsEtiKLSrhRJkCcNTufHXzOMaB,}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMaW={'mode':'HISTORY_REMOVE','skey':VYqdAsEtiKLSrhRJkCcNTufHXzOMaB,'delmode':'ONE',}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMav=urllib.parse.urlencode(VYqdAsEtiKLSrhRJkCcNTufHXzOMaW)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMaP=[('선택된 검색어 ( %s ) 삭제'%(VYqdAsEtiKLSrhRJkCcNTufHXzOMaB),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(VYqdAsEtiKLSrhRJkCcNTufHXzOMav))]
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.add_dir(VYqdAsEtiKLSrhRJkCcNTufHXzOMaB,sublabel='',img=VYqdAsEtiKLSrhRJkCcNTufHXzOMgv,infoLabels=VYqdAsEtiKLSrhRJkCcNTufHXzOMgv,isFolder=VYqdAsEtiKLSrhRJkCcNTufHXzOMgP,params=VYqdAsEtiKLSrhRJkCcNTufHXzOMxp,ContextMenu=VYqdAsEtiKLSrhRJkCcNTufHXzOMaP)
  VYqdAsEtiKLSrhRJkCcNTufHXzOMap={'plot':'검색목록 전체를 삭제합니다.'}
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxG='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxp={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  VYqdAsEtiKLSrhRJkCcNTufHXzOMaQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.add_dir(VYqdAsEtiKLSrhRJkCcNTufHXzOMxG,sublabel='',img=VYqdAsEtiKLSrhRJkCcNTufHXzOMaQ,infoLabels=VYqdAsEtiKLSrhRJkCcNTufHXzOMap,isFolder=VYqdAsEtiKLSrhRJkCcNTufHXzOMge,params=VYqdAsEtiKLSrhRJkCcNTufHXzOMxp,isLink=VYqdAsEtiKLSrhRJkCcNTufHXzOMgP)
  xbmcplugin.endOfDirectory(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo._addon_handle,cacheToDisc=VYqdAsEtiKLSrhRJkCcNTufHXzOMge)
 def Delete_History_List(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,VYqdAsEtiKLSrhRJkCcNTufHXzOMaB,VYqdAsEtiKLSrhRJkCcNTufHXzOMal):
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMal=='ALL':
   try:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMxl=VYqdAsEtiKLSrhRJkCcNTufHXzOMxj
    fp=VYqdAsEtiKLSrhRJkCcNTufHXzOMgG(VYqdAsEtiKLSrhRJkCcNTufHXzOMxl,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMgv
  else:
   try:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMxl=VYqdAsEtiKLSrhRJkCcNTufHXzOMxj
    VYqdAsEtiKLSrhRJkCcNTufHXzOMab=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.Load_Searched_List() 
    fp=VYqdAsEtiKLSrhRJkCcNTufHXzOMgG(VYqdAsEtiKLSrhRJkCcNTufHXzOMxl,'w',-1,'utf-8')
    for VYqdAsEtiKLSrhRJkCcNTufHXzOMao in VYqdAsEtiKLSrhRJkCcNTufHXzOMab:
     VYqdAsEtiKLSrhRJkCcNTufHXzOMaU=VYqdAsEtiKLSrhRJkCcNTufHXzOMgQ(urllib.parse.parse_qsl(VYqdAsEtiKLSrhRJkCcNTufHXzOMao))
     VYqdAsEtiKLSrhRJkCcNTufHXzOMaI=VYqdAsEtiKLSrhRJkCcNTufHXzOMaU.get('skey').strip()
     if VYqdAsEtiKLSrhRJkCcNTufHXzOMaB!=VYqdAsEtiKLSrhRJkCcNTufHXzOMaI:
      fp.write(VYqdAsEtiKLSrhRJkCcNTufHXzOMao)
    fp.close()
   except:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMgv
 def dp_History_Delete(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,args):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMaB =args.get('skey') 
  VYqdAsEtiKLSrhRJkCcNTufHXzOMal=args.get('delmode')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxm=xbmcgui.Dialog()
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMal=='ALL':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMbx=VYqdAsEtiKLSrhRJkCcNTufHXzOMxm.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMbx=VYqdAsEtiKLSrhRJkCcNTufHXzOMxm.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMbx==VYqdAsEtiKLSrhRJkCcNTufHXzOMge:sys.exit()
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.Delete_History_List(VYqdAsEtiKLSrhRJkCcNTufHXzOMaB,VYqdAsEtiKLSrhRJkCcNTufHXzOMal)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxv=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.get_settings_menubookmark()
  for VYqdAsEtiKLSrhRJkCcNTufHXzOMba in VYqdAsEtiKLSrhRJkCcNTufHXzOMxb:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxG=VYqdAsEtiKLSrhRJkCcNTufHXzOMba.get('title')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMaQ=''
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMba.get('mode')=='MENU_BOOKMARK' and VYqdAsEtiKLSrhRJkCcNTufHXzOMxv==VYqdAsEtiKLSrhRJkCcNTufHXzOMge:continue
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxp={'mode':VYqdAsEtiKLSrhRJkCcNTufHXzOMba.get('mode')}
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMba.get('mode')in['XXX','MENU_BOOKMARK']:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbw=VYqdAsEtiKLSrhRJkCcNTufHXzOMge
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbg =VYqdAsEtiKLSrhRJkCcNTufHXzOMgP
   else:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbw=VYqdAsEtiKLSrhRJkCcNTufHXzOMgP
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbg =VYqdAsEtiKLSrhRJkCcNTufHXzOMge
   if 'icon' in VYqdAsEtiKLSrhRJkCcNTufHXzOMba:VYqdAsEtiKLSrhRJkCcNTufHXzOMaQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',VYqdAsEtiKLSrhRJkCcNTufHXzOMba.get('icon')) 
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.add_dir(VYqdAsEtiKLSrhRJkCcNTufHXzOMxG,sublabel='',img=VYqdAsEtiKLSrhRJkCcNTufHXzOMaQ,infoLabels=VYqdAsEtiKLSrhRJkCcNTufHXzOMgv,isFolder=VYqdAsEtiKLSrhRJkCcNTufHXzOMbw,params=VYqdAsEtiKLSrhRJkCcNTufHXzOMxp,isLink=VYqdAsEtiKLSrhRJkCcNTufHXzOMbg)
  xbmcplugin.endOfDirectory(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo._addon_handle,cacheToDisc=VYqdAsEtiKLSrhRJkCcNTufHXzOMge)
 def option_check(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxP=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.get_settings_select_info()
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMxP)==0:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxm=xbmcgui.Dialog()
   VYqdAsEtiKLSrhRJkCcNTufHXzOMbx=VYqdAsEtiKLSrhRJkCcNTufHXzOMxm.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMbx==VYqdAsEtiKLSrhRJkCcNTufHXzOMgP:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in VYqdAsEtiKLSrhRJkCcNTufHXzOMxP:
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.NF_cookiefile_check()==VYqdAsEtiKLSrhRJkCcNTufHXzOMge:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.NF_login(showMessage=VYqdAsEtiKLSrhRJkCcNTufHXzOMgP)
  if 'disney' in VYqdAsEtiKLSrhRJkCcNTufHXzOMxP:
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.DZ_cookiefile_check()==VYqdAsEtiKLSrhRJkCcNTufHXzOMge:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.DZ={}
 def DZ_cookiefile_check(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbo={}
  try: 
   fp=VYqdAsEtiKLSrhRJkCcNTufHXzOMgG(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMbo= json.load(fp)
   fp.close()
  except VYqdAsEtiKLSrhRJkCcNTufHXzOMgl as exception:
   return VYqdAsEtiKLSrhRJkCcNTufHXzOMge
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.DZ=VYqdAsEtiKLSrhRJkCcNTufHXzOMbo
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMjx(time.time())>VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.DZ['account']['token_limit']:
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.DZ_ReToken()==VYqdAsEtiKLSrhRJkCcNTufHXzOMge:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_noti(__language__(30920).encode('utf-8'))
    return VYqdAsEtiKLSrhRJkCcNTufHXzOMge
   try: 
    fp=VYqdAsEtiKLSrhRJkCcNTufHXzOMgG(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.DZ,fp,indent=4,ensure_ascii=VYqdAsEtiKLSrhRJkCcNTufHXzOMge)
    fp.close()
   except VYqdAsEtiKLSrhRJkCcNTufHXzOMgl as exception:
    return VYqdAsEtiKLSrhRJkCcNTufHXzOMge
  return VYqdAsEtiKLSrhRJkCcNTufHXzOMgP
 def NF_cookiefile_check(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbo={}
  try: 
   fp=VYqdAsEtiKLSrhRJkCcNTufHXzOMgG(VYqdAsEtiKLSrhRJkCcNTufHXzOMxg,'r',-1,'utf-8')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMbo= json.load(fp)
   fp.close()
  except VYqdAsEtiKLSrhRJkCcNTufHXzOMgl as exception:
   return VYqdAsEtiKLSrhRJkCcNTufHXzOMge
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF=VYqdAsEtiKLSrhRJkCcNTufHXzOMbo
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbD =VYqdAsEtiKLSrhRJkCcNTufHXzOMjx(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  VYqdAsEtiKLSrhRJkCcNTufHXzOMby=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF['SESSION']['limitdate']
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbF =VYqdAsEtiKLSrhRJkCcNTufHXzOMjx(re.sub('-','',VYqdAsEtiKLSrhRJkCcNTufHXzOMby))
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMbF<VYqdAsEtiKLSrhRJkCcNTufHXzOMbD:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Init_NF_Total()
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.NF_login(showMessage=VYqdAsEtiKLSrhRJkCcNTufHXzOMge)==VYqdAsEtiKLSrhRJkCcNTufHXzOMge:
    return VYqdAsEtiKLSrhRJkCcNTufHXzOMge
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbm=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF_CookieFile_Load(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF_ORIGINAL_COOKIE)
  if(VYqdAsEtiKLSrhRJkCcNTufHXzOMbm['NetflixId']!=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF['COOKIES']['NetflixId']or VYqdAsEtiKLSrhRJkCcNTufHXzOMbm['SecureNetflixId']!=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF['COOKIES']['SecureNetflixId']or VYqdAsEtiKLSrhRJkCcNTufHXzOMbm['flwssn']!=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF['COOKIES']['flwssn']or VYqdAsEtiKLSrhRJkCcNTufHXzOMbm['nfvdid']!=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF['COOKIES']['nfvdid']):
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Init_NF_Total()
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.NF_login(showMessage=VYqdAsEtiKLSrhRJkCcNTufHXzOMge)==VYqdAsEtiKLSrhRJkCcNTufHXzOMge:
    return VYqdAsEtiKLSrhRJkCcNTufHXzOMge
  return VYqdAsEtiKLSrhRJkCcNTufHXzOMgP
 def NF_login(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,showMessage=VYqdAsEtiKLSrhRJkCcNTufHXzOMgP):
  if showMessage:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxm=xbmcgui.Dialog()
   VYqdAsEtiKLSrhRJkCcNTufHXzOMbx=VYqdAsEtiKLSrhRJkCcNTufHXzOMxm.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMbx==VYqdAsEtiKLSrhRJkCcNTufHXzOMge:
    return VYqdAsEtiKLSrhRJkCcNTufHXzOMge 
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF['COOKIES']=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF_CookieFile_Load(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF_ORIGINAL_COOKIE)
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbn=VYqdAsEtiKLSrhRJkCcNTufHXzOMge if VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF['COOKIES']=={}else VYqdAsEtiKLSrhRJkCcNTufHXzOMgP
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMbn:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_log('pass1 ok!')
  else:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_log('pass1 error!')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_noti(__language__(30905).encode('utf-8'))
   return VYqdAsEtiKLSrhRJkCcNTufHXzOMge 
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbn=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF_Get_BaseSession()
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMbn:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_log('pass2 ok!')
  else:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_log('pass2 error!')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_noti(__language__(30905).encode('utf-8'))
   return VYqdAsEtiKLSrhRJkCcNTufHXzOMge 
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbB =VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Now_Datetime()
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF['SESSION']['limitdate']=VYqdAsEtiKLSrhRJkCcNTufHXzOMbB.strftime('%Y-%m-%d')
  try: 
   fp=VYqdAsEtiKLSrhRJkCcNTufHXzOMgG(VYqdAsEtiKLSrhRJkCcNTufHXzOMxg,'w',-1,'utf-8')
   json.dump(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF,fp,indent=4,ensure_ascii=VYqdAsEtiKLSrhRJkCcNTufHXzOMge)
   fp.close()
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_log('pass3 save ok!')
  except VYqdAsEtiKLSrhRJkCcNTufHXzOMgl as exception:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_log('pass3 save error!')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_noti(__language__(30905).encode('utf-8'))
   return VYqdAsEtiKLSrhRJkCcNTufHXzOMge
  if showMessage:VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_noti(__language__(30904).encode('utf-8'))
  return VYqdAsEtiKLSrhRJkCcNTufHXzOMgP
 def NF_logout(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxm=xbmcgui.Dialog()
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbx=VYqdAsEtiKLSrhRJkCcNTufHXzOMxm.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMbx==VYqdAsEtiKLSrhRJkCcNTufHXzOMge:return 
  if os.path.isfile(VYqdAsEtiKLSrhRJkCcNTufHXzOMxg):os.remove(VYqdAsEtiKLSrhRJkCcNTufHXzOMxg)
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,VYqdAsEtiKLSrhRJkCcNTufHXzOMbp):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbW=''
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbv=7
  try:
   for i in VYqdAsEtiKLSrhRJkCcNTufHXzOMja(VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)):
    if i>=VYqdAsEtiKLSrhRJkCcNTufHXzOMbv:
     VYqdAsEtiKLSrhRJkCcNTufHXzOMbW=VYqdAsEtiKLSrhRJkCcNTufHXzOMbW+'...'
     break
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbW=VYqdAsEtiKLSrhRJkCcNTufHXzOMbW+VYqdAsEtiKLSrhRJkCcNTufHXzOMbp[i]['title']+'\n'
  except:
   return ''
  return VYqdAsEtiKLSrhRJkCcNTufHXzOMbW
 def dp_Search_Group(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,args):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxP =VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.get_settings_select_info()
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbP=[]
  if 'search_key' in args:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMbe=args.get('search_key')
  else:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMbe=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not VYqdAsEtiKLSrhRJkCcNTufHXzOMbe:
    return
  if 'wavve' in VYqdAsEtiKLSrhRJkCcNTufHXzOMxP:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_log('wavve search_key : {}'.format(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe))
   (VYqdAsEtiKLSrhRJkCcNTufHXzOMbp,VYqdAsEtiKLSrhRJkCcNTufHXzOMbQ)=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Search_Wavve(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,'TVSHOW',1)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_log('wavve tvshow cnt : {}'.format(VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)))
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)>0:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbG={'sType':'wavve_tvshow','sList':VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.MakeText_FreeList(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp),}
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbP.append(VYqdAsEtiKLSrhRJkCcNTufHXzOMbG)
   (VYqdAsEtiKLSrhRJkCcNTufHXzOMbp,VYqdAsEtiKLSrhRJkCcNTufHXzOMbQ)=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Search_Wavve(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,'MOVIE',1)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_log('wavve movie cnt : {}'.format(VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)))
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)>0:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbG={'sType':'wavve_movie','sList':VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.MakeText_FreeList(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp),}
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbP.append(VYqdAsEtiKLSrhRJkCcNTufHXzOMbG)
  if 'tving' in VYqdAsEtiKLSrhRJkCcNTufHXzOMxP:
   (VYqdAsEtiKLSrhRJkCcNTufHXzOMbp,VYqdAsEtiKLSrhRJkCcNTufHXzOMbQ)=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Search_Tving(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,'TVSHOW',1)
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)>0:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbG={'sType':'tving_tvshow','sList':VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.MakeText_FreeList(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp),}
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbP.append(VYqdAsEtiKLSrhRJkCcNTufHXzOMbG)
   (VYqdAsEtiKLSrhRJkCcNTufHXzOMbp,VYqdAsEtiKLSrhRJkCcNTufHXzOMbQ)=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Search_Tving(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,'MOVIE',1)
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)>0:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbG={'sType':'tving_movie','sList':VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.MakeText_FreeList(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp),}
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbP.append(VYqdAsEtiKLSrhRJkCcNTufHXzOMbG)
  if 'watcha' in VYqdAsEtiKLSrhRJkCcNTufHXzOMxP:
   (VYqdAsEtiKLSrhRJkCcNTufHXzOMbp,VYqdAsEtiKLSrhRJkCcNTufHXzOMbQ)=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Search_Watcha(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,1)
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)>0:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbG={'sType':'watcha_list','sList':VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.MakeText_FreeList(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp),}
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbP.append(VYqdAsEtiKLSrhRJkCcNTufHXzOMbG)
  if 'coupang' in VYqdAsEtiKLSrhRJkCcNTufHXzOMxP:
   (VYqdAsEtiKLSrhRJkCcNTufHXzOMbp,VYqdAsEtiKLSrhRJkCcNTufHXzOMbQ)=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Search_Coupang(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,1)
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)>0:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbG={'sType':'coupang_list','sList':VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.MakeText_FreeList(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp),}
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbP.append(VYqdAsEtiKLSrhRJkCcNTufHXzOMbG)
  if 'netflix' in VYqdAsEtiKLSrhRJkCcNTufHXzOMxP:
   try:
    (VYqdAsEtiKLSrhRJkCcNTufHXzOMbp,VYqdAsEtiKLSrhRJkCcNTufHXzOMbQ,VYqdAsEtiKLSrhRJkCcNTufHXzOMbI)=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Search_Netflix(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,1)
   except:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbp=[]
    VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_noti(__language__(30919).encode('utf8'))
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)>0:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbG={'sType':'netflix_list','sList':VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.MakeText_FreeList(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp),}
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbP.append(VYqdAsEtiKLSrhRJkCcNTufHXzOMbG)
  if 'amazon' in VYqdAsEtiKLSrhRJkCcNTufHXzOMxP:
   (VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Search_Primev(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe)
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)>0:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbG={'sType':'primev_list','sList':VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.MakeText_FreeList(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp),}
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbP.append(VYqdAsEtiKLSrhRJkCcNTufHXzOMbG)
  if 'disney' in VYqdAsEtiKLSrhRJkCcNTufHXzOMxP:
   try:
    (VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Search_Disney(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe)
   except:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbp=[]
    VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.addon_noti(__language__(30921).encode('utf8'))
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMgI(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp)>0:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbG={'sType':'disney_list','sList':VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.MakeText_FreeList(VYqdAsEtiKLSrhRJkCcNTufHXzOMbp),}
    VYqdAsEtiKLSrhRJkCcNTufHXzOMbP.append(VYqdAsEtiKLSrhRJkCcNTufHXzOMbG)
  for VYqdAsEtiKLSrhRJkCcNTufHXzOMbl in VYqdAsEtiKLSrhRJkCcNTufHXzOMbP:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwx=VYqdAsEtiKLSrhRJkCcNTufHXzOMxw[VYqdAsEtiKLSrhRJkCcNTufHXzOMbl.get('sType')]
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwa={'plot':'검색어 : '+VYqdAsEtiKLSrhRJkCcNTufHXzOMbe+'\n\n'+VYqdAsEtiKLSrhRJkCcNTufHXzOMbl.get('sList')}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxG=VYqdAsEtiKLSrhRJkCcNTufHXzOMwx.get('title')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxp={'mode':VYqdAsEtiKLSrhRJkCcNTufHXzOMwx.get('mode'),'ott':VYqdAsEtiKLSrhRJkCcNTufHXzOMwx.get('ott'),'vidtype':VYqdAsEtiKLSrhRJkCcNTufHXzOMwx.get('vidtype'),'search_key':VYqdAsEtiKLSrhRJkCcNTufHXzOMbe}
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMwx.get('ott')=='netflix':
    VYqdAsEtiKLSrhRJkCcNTufHXzOMwb=''
    VYqdAsEtiKLSrhRJkCcNTufHXzOMxp['page'] ='1'
    VYqdAsEtiKLSrhRJkCcNTufHXzOMxp['byReference']='-'
   else:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMwb=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.make_Hyper_Link(VYqdAsEtiKLSrhRJkCcNTufHXzOMxp)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMaQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',VYqdAsEtiKLSrhRJkCcNTufHXzOMwx.get('icon'))
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.add_dir(VYqdAsEtiKLSrhRJkCcNTufHXzOMxG,sublabel='',img=VYqdAsEtiKLSrhRJkCcNTufHXzOMaQ,infoLabels=VYqdAsEtiKLSrhRJkCcNTufHXzOMwa,isFolder=VYqdAsEtiKLSrhRJkCcNTufHXzOMgP,params=VYqdAsEtiKLSrhRJkCcNTufHXzOMxp,isLink=VYqdAsEtiKLSrhRJkCcNTufHXzOMge,direct_url=VYqdAsEtiKLSrhRJkCcNTufHXzOMwb)
  xbmcplugin.endOfDirectory(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo._addon_handle)
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.Save_Searched_List(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe)
 def make_Hyper_Link(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,args):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMwg =args.get('ott')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMwj =args.get('vidtype')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbe=args.get('search_key')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMwb='-'
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMwg=='wavve':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwo={'mode':'LOCAL_SEARCH','sType':'movie' if VYqdAsEtiKLSrhRJkCcNTufHXzOMwj=='MOVIE' else 'vod','search_key':VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,'page':'1',}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwU=urllib.parse.urlencode(VYqdAsEtiKLSrhRJkCcNTufHXzOMwo)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb='plugin://plugin.video.wavvem/?'
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb+=VYqdAsEtiKLSrhRJkCcNTufHXzOMwU
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMwg=='tving':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwo={'mode':'LOCAL_SEARCH','stype':'movie' if VYqdAsEtiKLSrhRJkCcNTufHXzOMwj=='MOVIE' else 'vod','search_key':VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,'page':'1',}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwU=urllib.parse.urlencode(VYqdAsEtiKLSrhRJkCcNTufHXzOMwo)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb='plugin://plugin.video.tvingm/?'
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb+=VYqdAsEtiKLSrhRJkCcNTufHXzOMwU
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMwg=='watcha':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwo={'mode':'LOCAL_SEARCH','search_key':VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,'page':'1',}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwU=urllib.parse.urlencode(VYqdAsEtiKLSrhRJkCcNTufHXzOMwo)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb='plugin://plugin.video.watcham/?'
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb+=VYqdAsEtiKLSrhRJkCcNTufHXzOMwU
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMwg=='coupang':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwo={'mode':'LOCAL_SEARCH','search_key':VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,'page':'1',}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwU=urllib.parse.urlencode(VYqdAsEtiKLSrhRJkCcNTufHXzOMwo)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb='plugin://plugin.video.coupangm/?'
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb+=VYqdAsEtiKLSrhRJkCcNTufHXzOMwU
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMwg=='netflix':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwD=args.get('videoid')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwy=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.NF['SESSION']['nowGuid']
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMwj=='TVSHOW':
    VYqdAsEtiKLSrhRJkCcNTufHXzOMwb='plugin://plugin.video.netflix/directory/show/%s/'%(VYqdAsEtiKLSrhRJkCcNTufHXzOMwD)
   else:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMwb='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(VYqdAsEtiKLSrhRJkCcNTufHXzOMwD,VYqdAsEtiKLSrhRJkCcNTufHXzOMwy)
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMwg=='amazon':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwo={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,}}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwU=json.dumps(VYqdAsEtiKLSrhRJkCcNTufHXzOMwo,separators=(',',':'))
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwU=base64.standard_b64encode(VYqdAsEtiKLSrhRJkCcNTufHXzOMwU.encode()).decode('utf-8')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwU=VYqdAsEtiKLSrhRJkCcNTufHXzOMwU.replace('+','%2B')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb='plugin://plugin.video.primevm/?params='
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb+=VYqdAsEtiKLSrhRJkCcNTufHXzOMwU
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMwg=='disney':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwo={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,}}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwU=json.dumps(VYqdAsEtiKLSrhRJkCcNTufHXzOMwo,separators=(',',':'))
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwU=base64.standard_b64encode(VYqdAsEtiKLSrhRJkCcNTufHXzOMwU.encode()).decode('utf-8')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwU=VYqdAsEtiKLSrhRJkCcNTufHXzOMwU.replace('+','%2B')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb='plugin://plugin.video.disneym/?params='
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb+=VYqdAsEtiKLSrhRJkCcNTufHXzOMwU
  return VYqdAsEtiKLSrhRJkCcNTufHXzOMwb
 def dp_Nf_Search(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,args):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMwF =VYqdAsEtiKLSrhRJkCcNTufHXzOMjx(args.get('page'))
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbe =args.get('search_key')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbI=args.get('byReference')
  (VYqdAsEtiKLSrhRJkCcNTufHXzOMbp,VYqdAsEtiKLSrhRJkCcNTufHXzOMbQ,VYqdAsEtiKLSrhRJkCcNTufHXzOMbI)=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.SearchObj.Get_Search_Netflix(VYqdAsEtiKLSrhRJkCcNTufHXzOMbe,VYqdAsEtiKLSrhRJkCcNTufHXzOMwF,byReference=VYqdAsEtiKLSrhRJkCcNTufHXzOMbI)
  for VYqdAsEtiKLSrhRJkCcNTufHXzOMwm in VYqdAsEtiKLSrhRJkCcNTufHXzOMbp:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwD =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('videoid')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwj =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('vidtype')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxG =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('title')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwn =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('mpaa')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwB =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('regularSynopsis')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwW =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('dpSupplemental')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwv=VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('sequiturEvidence')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwP =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('thumbnail')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwe =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('year')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwp =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('duration')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwQ =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('info_genre')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwG =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('director')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwI =VYqdAsEtiKLSrhRJkCcNTufHXzOMwm.get('cast')
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMwj=='movie':
    VYqdAsEtiKLSrhRJkCcNTufHXzOMae=' (%s)'%(VYqdAsEtiKLSrhRJkCcNTufHXzOMjb(VYqdAsEtiKLSrhRJkCcNTufHXzOMwe))
   else:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMae=''
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwl=''
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMwB:VYqdAsEtiKLSrhRJkCcNTufHXzOMwl=VYqdAsEtiKLSrhRJkCcNTufHXzOMwl+'\n\n'+VYqdAsEtiKLSrhRJkCcNTufHXzOMwB
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMwW :VYqdAsEtiKLSrhRJkCcNTufHXzOMwl=VYqdAsEtiKLSrhRJkCcNTufHXzOMwl+'\n\n'+VYqdAsEtiKLSrhRJkCcNTufHXzOMwW
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMwv:VYqdAsEtiKLSrhRJkCcNTufHXzOMwl=VYqdAsEtiKLSrhRJkCcNTufHXzOMwl+'\n\n'+VYqdAsEtiKLSrhRJkCcNTufHXzOMwv
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwl=VYqdAsEtiKLSrhRJkCcNTufHXzOMwl.strip()
   VYqdAsEtiKLSrhRJkCcNTufHXzOMap={'mediatype':'tvshow' if VYqdAsEtiKLSrhRJkCcNTufHXzOMwj=='show' else 'movie','title':VYqdAsEtiKLSrhRJkCcNTufHXzOMxG,'mpaa':VYqdAsEtiKLSrhRJkCcNTufHXzOMwn,'plot':VYqdAsEtiKLSrhRJkCcNTufHXzOMwl,'duration':VYqdAsEtiKLSrhRJkCcNTufHXzOMwp,'genre':VYqdAsEtiKLSrhRJkCcNTufHXzOMwQ,'director':VYqdAsEtiKLSrhRJkCcNTufHXzOMwG,'cast':VYqdAsEtiKLSrhRJkCcNTufHXzOMwI,'year':VYqdAsEtiKLSrhRJkCcNTufHXzOMwe,}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxp={'ott':'netflix','vidtype':'TVSHOW' if VYqdAsEtiKLSrhRJkCcNTufHXzOMwj=='show' else 'MOVIE','videoid':VYqdAsEtiKLSrhRJkCcNTufHXzOMwD,}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMwb=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.make_Hyper_Link(VYqdAsEtiKLSrhRJkCcNTufHXzOMxp)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMbw=VYqdAsEtiKLSrhRJkCcNTufHXzOMgP if VYqdAsEtiKLSrhRJkCcNTufHXzOMwj=='show' else VYqdAsEtiKLSrhRJkCcNTufHXzOMge
   if VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.get_settings_makebookmark():
    VYqdAsEtiKLSrhRJkCcNTufHXzOMgx={'mode':'SET_BOOKMARK','values':{'videoid':VYqdAsEtiKLSrhRJkCcNTufHXzOMwD,'vidtype':'tvshow' if VYqdAsEtiKLSrhRJkCcNTufHXzOMwj=='show' else 'movie','vtitle':VYqdAsEtiKLSrhRJkCcNTufHXzOMxG+VYqdAsEtiKLSrhRJkCcNTufHXzOMae,'vsubtitle':'','vinfo':VYqdAsEtiKLSrhRJkCcNTufHXzOMap,'thumbnail':VYqdAsEtiKLSrhRJkCcNTufHXzOMwP,}}
    VYqdAsEtiKLSrhRJkCcNTufHXzOMga=json.dumps(VYqdAsEtiKLSrhRJkCcNTufHXzOMgx,separators=(',',':'))
    VYqdAsEtiKLSrhRJkCcNTufHXzOMga=base64.standard_b64encode(VYqdAsEtiKLSrhRJkCcNTufHXzOMga.encode()).decode('utf-8')
    VYqdAsEtiKLSrhRJkCcNTufHXzOMga=VYqdAsEtiKLSrhRJkCcNTufHXzOMga.replace('+','%2B')
    VYqdAsEtiKLSrhRJkCcNTufHXzOMgb='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(VYqdAsEtiKLSrhRJkCcNTufHXzOMga)
    VYqdAsEtiKLSrhRJkCcNTufHXzOMaP=[('(통합) 찜 영상에 추가',VYqdAsEtiKLSrhRJkCcNTufHXzOMgb)]
   else:
    VYqdAsEtiKLSrhRJkCcNTufHXzOMaP=VYqdAsEtiKLSrhRJkCcNTufHXzOMgv
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.add_dir(VYqdAsEtiKLSrhRJkCcNTufHXzOMxG+VYqdAsEtiKLSrhRJkCcNTufHXzOMae,sublabel=VYqdAsEtiKLSrhRJkCcNTufHXzOMgv,img=VYqdAsEtiKLSrhRJkCcNTufHXzOMwP,infoLabels=VYqdAsEtiKLSrhRJkCcNTufHXzOMap,isFolder=VYqdAsEtiKLSrhRJkCcNTufHXzOMbw,params=VYqdAsEtiKLSrhRJkCcNTufHXzOMxp,isLink=VYqdAsEtiKLSrhRJkCcNTufHXzOMge,ContextMenu=VYqdAsEtiKLSrhRJkCcNTufHXzOMaP,direct_url=VYqdAsEtiKLSrhRJkCcNTufHXzOMwb)
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMbQ:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxp={}
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxp['mode'] ='NF_SEARCH' 
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxp['page'] =VYqdAsEtiKLSrhRJkCcNTufHXzOMjb(VYqdAsEtiKLSrhRJkCcNTufHXzOMwF+1)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxp['search_key']=VYqdAsEtiKLSrhRJkCcNTufHXzOMbe
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxp['byReference']=VYqdAsEtiKLSrhRJkCcNTufHXzOMbI
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxG='[B]%s >>[/B]'%'다음 페이지'
   VYqdAsEtiKLSrhRJkCcNTufHXzOMgw=VYqdAsEtiKLSrhRJkCcNTufHXzOMjb(VYqdAsEtiKLSrhRJkCcNTufHXzOMwF+1)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMaQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.add_dir(VYqdAsEtiKLSrhRJkCcNTufHXzOMxG,sublabel=VYqdAsEtiKLSrhRJkCcNTufHXzOMgw,img=VYqdAsEtiKLSrhRJkCcNTufHXzOMaQ,infoLabels=VYqdAsEtiKLSrhRJkCcNTufHXzOMgv,isFolder=VYqdAsEtiKLSrhRJkCcNTufHXzOMgP,params=VYqdAsEtiKLSrhRJkCcNTufHXzOMxp)
  xbmcplugin.setContent(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo._addon_handle,'movies')
  xbmcplugin.endOfDirectory(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo._addon_handle)
 def dp_Bookmark_Menu(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,args):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMgj='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(VYqdAsEtiKLSrhRJkCcNTufHXzOMgj)
 def dp_Set_Bookmark(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo,args):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMwD =args.get('videoid')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMwj =args.get('vidtype')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMgo =args.get('vtitle')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMgU =args.get('vsubtitle')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMgD =args.get('vinfo')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMwP =args.get('thumbnail')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxm=xbmcgui.Dialog()
  VYqdAsEtiKLSrhRJkCcNTufHXzOMbx=VYqdAsEtiKLSrhRJkCcNTufHXzOMxm.yesno(__language__(30917).encode('utf8'),VYqdAsEtiKLSrhRJkCcNTufHXzOMgo+' \n\n'+__language__(30918))
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMbx==VYqdAsEtiKLSrhRJkCcNTufHXzOMge:return
  VYqdAsEtiKLSrhRJkCcNTufHXzOMgy={'indexinfo':{'ott':'netflix','videoid':VYqdAsEtiKLSrhRJkCcNTufHXzOMwD,'vidtype':VYqdAsEtiKLSrhRJkCcNTufHXzOMwj,},'saveinfo':{'title':VYqdAsEtiKLSrhRJkCcNTufHXzOMgo,'subtitle':VYqdAsEtiKLSrhRJkCcNTufHXzOMgU,'thumbnail':VYqdAsEtiKLSrhRJkCcNTufHXzOMwP,'infoLabels':VYqdAsEtiKLSrhRJkCcNTufHXzOMgD,},}
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxp={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':VYqdAsEtiKLSrhRJkCcNTufHXzOMgy,}}
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ=json.dumps(VYqdAsEtiKLSrhRJkCcNTufHXzOMxp,separators=(',',':'))
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ=base64.standard_b64encode(VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ.encode()).decode('utf-8')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ=VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ.replace('+','%2B')
  VYqdAsEtiKLSrhRJkCcNTufHXzOMgb='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(VYqdAsEtiKLSrhRJkCcNTufHXzOMxQ)
  xbmc.executebuiltin(VYqdAsEtiKLSrhRJkCcNTufHXzOMgb)
 def search_main(VYqdAsEtiKLSrhRJkCcNTufHXzOMxo):
  VYqdAsEtiKLSrhRJkCcNTufHXzOMgF=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.main_params.get('params')
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMgF:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMgm =base64.standard_b64decode(VYqdAsEtiKLSrhRJkCcNTufHXzOMgF).decode('utf-8')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMgm =json.loads(VYqdAsEtiKLSrhRJkCcNTufHXzOMgm)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMgn =VYqdAsEtiKLSrhRJkCcNTufHXzOMgm.get('mode')
   VYqdAsEtiKLSrhRJkCcNTufHXzOMgB =VYqdAsEtiKLSrhRJkCcNTufHXzOMgm.get('values')
  else:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMgn=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.main_params.get('mode',VYqdAsEtiKLSrhRJkCcNTufHXzOMgv)
   VYqdAsEtiKLSrhRJkCcNTufHXzOMgB=VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.main_params
  VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.option_check()
  if VYqdAsEtiKLSrhRJkCcNTufHXzOMgn is VYqdAsEtiKLSrhRJkCcNTufHXzOMgv:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.dp_Main_List()
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMgn=='TOTAL_SEARCH':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.dp_Search_Group(VYqdAsEtiKLSrhRJkCcNTufHXzOMgB)
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMgn=='NF_SEARCH':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.dp_Nf_Search(VYqdAsEtiKLSrhRJkCcNTufHXzOMgB)
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMgn=='TOTAL_HISTORY':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.dp_Search_History(VYqdAsEtiKLSrhRJkCcNTufHXzOMgB)
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMgn=='HISTORY_REMOVE':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.dp_History_Delete(VYqdAsEtiKLSrhRJkCcNTufHXzOMgB)
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMgn=='MENU_BOOKMARK':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.dp_Bookmark_Menu(VYqdAsEtiKLSrhRJkCcNTufHXzOMgB)
  elif VYqdAsEtiKLSrhRJkCcNTufHXzOMgn=='SET_BOOKMARK':
   VYqdAsEtiKLSrhRJkCcNTufHXzOMxo.dp_Set_Bookmark(VYqdAsEtiKLSrhRJkCcNTufHXzOMgB)
  else:
   VYqdAsEtiKLSrhRJkCcNTufHXzOMgv
# Created by pyminifier (https://github.com/liftoff/pyminifier)
