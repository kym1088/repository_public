__author__="NightRain"
RfvzyFgmHjMsnauAbSBcKtDVNLdWeC=object
RfvzyFgmHjMsnauAbSBcKtDVNLdWex=None
RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ=True
RfvzyFgmHjMsnauAbSBcKtDVNLdWeU=False
RfvzyFgmHjMsnauAbSBcKtDVNLdWeh=type
RfvzyFgmHjMsnauAbSBcKtDVNLdWer=dict
RfvzyFgmHjMsnauAbSBcKtDVNLdWeJ=open
RfvzyFgmHjMsnauAbSBcKtDVNLdWeG=len
RfvzyFgmHjMsnauAbSBcKtDVNLdWek=Exception
RfvzyFgmHjMsnauAbSBcKtDVNLdWeq=int
RfvzyFgmHjMsnauAbSBcKtDVNLdWeO=range
RfvzyFgmHjMsnauAbSBcKtDVNLdWew=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
RfvzyFgmHjMsnauAbSBcKtDVNLdWPi=[{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
RfvzyFgmHjMsnauAbSBcKtDVNLdWPl={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},}
RfvzyFgmHjMsnauAbSBcKtDVNLdWPe =xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
RfvzyFgmHjMsnauAbSBcKtDVNLdWPp=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
RfvzyFgmHjMsnauAbSBcKtDVNLdWPo =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class RfvzyFgmHjMsnauAbSBcKtDVNLdWPI(RfvzyFgmHjMsnauAbSBcKtDVNLdWeC):
 def __init__(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,RfvzyFgmHjMsnauAbSBcKtDVNLdWPY,RfvzyFgmHjMsnauAbSBcKtDVNLdWPE,RfvzyFgmHjMsnauAbSBcKtDVNLdWPC):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT._addon_url =RfvzyFgmHjMsnauAbSBcKtDVNLdWPY
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT._addon_handle=RfvzyFgmHjMsnauAbSBcKtDVNLdWPE
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.main_params =RfvzyFgmHjMsnauAbSBcKtDVNLdWPC
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj =JgUKSlVftXudDBLsWRiFoyYmAbCMOk() 
 def addon_noti(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,sting):
  try:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ=xbmcgui.Dialog()
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ.notification(__addonname__,sting)
  except:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWex
 def addon_log(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,string):
  try:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPU=string.encode('utf-8','ignore')
  except:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPU='addonException: addon_log'
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPh=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,RfvzyFgmHjMsnauAbSBcKtDVNLdWPU),level=RfvzyFgmHjMsnauAbSBcKtDVNLdWPh)
 def get_keyboard_input(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,RfvzyFgmHjMsnauAbSBcKtDVNLdWPq):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPr=RfvzyFgmHjMsnauAbSBcKtDVNLdWex
  kb=xbmc.Keyboard()
  kb.setHeading(RfvzyFgmHjMsnauAbSBcKtDVNLdWPq)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPr=kb.getText()
  return RfvzyFgmHjMsnauAbSBcKtDVNLdWPr
 def get_settings_menubookmark(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPJ=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ if __addon__.getSetting('menu_bookmark')=='true' else RfvzyFgmHjMsnauAbSBcKtDVNLdWeU
  return(RfvzyFgmHjMsnauAbSBcKtDVNLdWPJ)
 def get_settings_makebookmark(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT):
  return RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ if __addon__.getSetting('make_bookmark')=='true' else RfvzyFgmHjMsnauAbSBcKtDVNLdWeU
 def get_settings_select_info(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPG=[]
  if __addon__.getSetting('netflixyn')=='true':RfvzyFgmHjMsnauAbSBcKtDVNLdWPG.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':RfvzyFgmHjMsnauAbSBcKtDVNLdWPG.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':RfvzyFgmHjMsnauAbSBcKtDVNLdWPG.append('tving')
  if __addon__.getSetting('watchayn')=='true':RfvzyFgmHjMsnauAbSBcKtDVNLdWPG.append('watcha')
  return RfvzyFgmHjMsnauAbSBcKtDVNLdWPG
 def add_dir(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,label,sublabel='',img='',infoLabels=RfvzyFgmHjMsnauAbSBcKtDVNLdWex,isFolder=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ,params='',isLink=RfvzyFgmHjMsnauAbSBcKtDVNLdWeU,ContextMenu=RfvzyFgmHjMsnauAbSBcKtDVNLdWex):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPk='%s?%s'%(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT._addon_url,urllib.parse.urlencode(params))
  if sublabel:RfvzyFgmHjMsnauAbSBcKtDVNLdWPq='%s < %s >'%(label,sublabel)
  else: RfvzyFgmHjMsnauAbSBcKtDVNLdWPq=label
  if not img:img='DefaultFolder.png'
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPO=xbmcgui.ListItem(RfvzyFgmHjMsnauAbSBcKtDVNLdWPq)
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWeh(img)==RfvzyFgmHjMsnauAbSBcKtDVNLdWer:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPO.setArt(img)
  else:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPO.setArt({'thumb':img,'poster':img})
  if infoLabels:RfvzyFgmHjMsnauAbSBcKtDVNLdWPO.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPO.setProperty('IsPlayable','true')
  if ContextMenu:RfvzyFgmHjMsnauAbSBcKtDVNLdWPO.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT._addon_handle,RfvzyFgmHjMsnauAbSBcKtDVNLdWPk,RfvzyFgmHjMsnauAbSBcKtDVNLdWPO,isFolder)
 def Load_Searched_List(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT):
  try:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPw=RfvzyFgmHjMsnauAbSBcKtDVNLdWPo
   fp=RfvzyFgmHjMsnauAbSBcKtDVNLdWeJ(RfvzyFgmHjMsnauAbSBcKtDVNLdWPw,'r',-1,'utf-8')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPX=fp.readlines()
   fp.close()
  except:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPX=[]
  return RfvzyFgmHjMsnauAbSBcKtDVNLdWPX
 def Save_Searched_List(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ):
  try:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPw=RfvzyFgmHjMsnauAbSBcKtDVNLdWPo
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIP=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.Load_Searched_List() 
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIi={'skey':RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ.strip()}
   fp=RfvzyFgmHjMsnauAbSBcKtDVNLdWeJ(RfvzyFgmHjMsnauAbSBcKtDVNLdWPw,'w',-1,'utf-8')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIl=urllib.parse.urlencode(RfvzyFgmHjMsnauAbSBcKtDVNLdWIi)
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIl=RfvzyFgmHjMsnauAbSBcKtDVNLdWIl+'\n'
   fp.write(RfvzyFgmHjMsnauAbSBcKtDVNLdWIl)
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIe=0
   for RfvzyFgmHjMsnauAbSBcKtDVNLdWIp in RfvzyFgmHjMsnauAbSBcKtDVNLdWIP:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWIo=RfvzyFgmHjMsnauAbSBcKtDVNLdWer(urllib.parse.parse_qsl(RfvzyFgmHjMsnauAbSBcKtDVNLdWIp))
    RfvzyFgmHjMsnauAbSBcKtDVNLdWIT=RfvzyFgmHjMsnauAbSBcKtDVNLdWIi.get('skey').strip()
    RfvzyFgmHjMsnauAbSBcKtDVNLdWIY=RfvzyFgmHjMsnauAbSBcKtDVNLdWIo.get('skey').strip()
    if RfvzyFgmHjMsnauAbSBcKtDVNLdWIT!=RfvzyFgmHjMsnauAbSBcKtDVNLdWIY:
     fp.write(RfvzyFgmHjMsnauAbSBcKtDVNLdWIp)
     RfvzyFgmHjMsnauAbSBcKtDVNLdWIe+=1
     if RfvzyFgmHjMsnauAbSBcKtDVNLdWIe>=50:break
   fp.close()
  except:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWex
 def dp_Search_History(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,args):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWIE=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.Load_Searched_List()
  for RfvzyFgmHjMsnauAbSBcKtDVNLdWIC in RfvzyFgmHjMsnauAbSBcKtDVNLdWIE:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIx=RfvzyFgmHjMsnauAbSBcKtDVNLdWer(urllib.parse.parse_qsl(RfvzyFgmHjMsnauAbSBcKtDVNLdWIC))
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIQ=RfvzyFgmHjMsnauAbSBcKtDVNLdWIx.get('skey').strip()
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIU={'mode':'TOTAL_SEARCH','search_key':RfvzyFgmHjMsnauAbSBcKtDVNLdWIQ,}
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIh={'mode':'HISTORY_REMOVE','skey':RfvzyFgmHjMsnauAbSBcKtDVNLdWIQ,'delmode':'ONE',}
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIr=urllib.parse.urlencode(RfvzyFgmHjMsnauAbSBcKtDVNLdWIh)
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIJ=[('선택된 검색어 ( %s ) 삭제'%(RfvzyFgmHjMsnauAbSBcKtDVNLdWIQ),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(RfvzyFgmHjMsnauAbSBcKtDVNLdWIr))]
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.add_dir(RfvzyFgmHjMsnauAbSBcKtDVNLdWIQ,sublabel='',img=RfvzyFgmHjMsnauAbSBcKtDVNLdWex,infoLabels=RfvzyFgmHjMsnauAbSBcKtDVNLdWex,isFolder=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ,params=RfvzyFgmHjMsnauAbSBcKtDVNLdWIU,ContextMenu=RfvzyFgmHjMsnauAbSBcKtDVNLdWIJ)
  RfvzyFgmHjMsnauAbSBcKtDVNLdWIk={'plot':'검색목록 전체를 삭제합니다.'}
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPq='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  RfvzyFgmHjMsnauAbSBcKtDVNLdWIU={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  RfvzyFgmHjMsnauAbSBcKtDVNLdWIq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.add_dir(RfvzyFgmHjMsnauAbSBcKtDVNLdWPq,sublabel='',img=RfvzyFgmHjMsnauAbSBcKtDVNLdWIq,infoLabels=RfvzyFgmHjMsnauAbSBcKtDVNLdWIk,isFolder=RfvzyFgmHjMsnauAbSBcKtDVNLdWeU,params=RfvzyFgmHjMsnauAbSBcKtDVNLdWIU,isLink=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ)
  xbmcplugin.endOfDirectory(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT._addon_handle,cacheToDisc=RfvzyFgmHjMsnauAbSBcKtDVNLdWeU)
 def Delete_History_List(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,RfvzyFgmHjMsnauAbSBcKtDVNLdWIQ,RfvzyFgmHjMsnauAbSBcKtDVNLdWIX):
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWIX=='ALL':
   try:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWPw=RfvzyFgmHjMsnauAbSBcKtDVNLdWPo
    fp=RfvzyFgmHjMsnauAbSBcKtDVNLdWeJ(RfvzyFgmHjMsnauAbSBcKtDVNLdWPw,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWex
  else:
   try:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWPw=RfvzyFgmHjMsnauAbSBcKtDVNLdWPo
    RfvzyFgmHjMsnauAbSBcKtDVNLdWIP=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.Load_Searched_List() 
    fp=RfvzyFgmHjMsnauAbSBcKtDVNLdWeJ(RfvzyFgmHjMsnauAbSBcKtDVNLdWPw,'w',-1,'utf-8')
    for RfvzyFgmHjMsnauAbSBcKtDVNLdWIp in RfvzyFgmHjMsnauAbSBcKtDVNLdWIP:
     RfvzyFgmHjMsnauAbSBcKtDVNLdWIo=RfvzyFgmHjMsnauAbSBcKtDVNLdWer(urllib.parse.parse_qsl(RfvzyFgmHjMsnauAbSBcKtDVNLdWIp))
     RfvzyFgmHjMsnauAbSBcKtDVNLdWIw=RfvzyFgmHjMsnauAbSBcKtDVNLdWIo.get('skey').strip()
     if RfvzyFgmHjMsnauAbSBcKtDVNLdWIQ!=RfvzyFgmHjMsnauAbSBcKtDVNLdWIw:
      fp.write(RfvzyFgmHjMsnauAbSBcKtDVNLdWIp)
    fp.close()
   except:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWex
 def dp_History_Delete(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,args):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWIQ =args.get('skey') 
  RfvzyFgmHjMsnauAbSBcKtDVNLdWIX=args.get('delmode')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ=xbmcgui.Dialog()
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWIX=='ALL':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWiP=RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWiP=RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWiP==RfvzyFgmHjMsnauAbSBcKtDVNLdWeU:sys.exit()
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.Delete_History_List(RfvzyFgmHjMsnauAbSBcKtDVNLdWIQ,RfvzyFgmHjMsnauAbSBcKtDVNLdWIX)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPJ=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.get_settings_menubookmark()
  for RfvzyFgmHjMsnauAbSBcKtDVNLdWiI in RfvzyFgmHjMsnauAbSBcKtDVNLdWPi:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPq=RfvzyFgmHjMsnauAbSBcKtDVNLdWiI.get('title')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIq=''
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWiI.get('mode')=='MENU_BOOKMARK' and RfvzyFgmHjMsnauAbSBcKtDVNLdWPJ==RfvzyFgmHjMsnauAbSBcKtDVNLdWeU:continue
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIU={'mode':RfvzyFgmHjMsnauAbSBcKtDVNLdWiI.get('mode')}
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWiI.get('mode')in['XXX','MENU_BOOKMARK']:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWil=RfvzyFgmHjMsnauAbSBcKtDVNLdWeU
    RfvzyFgmHjMsnauAbSBcKtDVNLdWie =RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ
   else:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWil=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ
    RfvzyFgmHjMsnauAbSBcKtDVNLdWie =RfvzyFgmHjMsnauAbSBcKtDVNLdWeU
   if 'icon' in RfvzyFgmHjMsnauAbSBcKtDVNLdWiI:RfvzyFgmHjMsnauAbSBcKtDVNLdWIq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',RfvzyFgmHjMsnauAbSBcKtDVNLdWiI.get('icon')) 
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.add_dir(RfvzyFgmHjMsnauAbSBcKtDVNLdWPq,sublabel='',img=RfvzyFgmHjMsnauAbSBcKtDVNLdWIq,infoLabels=RfvzyFgmHjMsnauAbSBcKtDVNLdWex,isFolder=RfvzyFgmHjMsnauAbSBcKtDVNLdWil,params=RfvzyFgmHjMsnauAbSBcKtDVNLdWIU,isLink=RfvzyFgmHjMsnauAbSBcKtDVNLdWie)
  xbmcplugin.endOfDirectory(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT._addon_handle,cacheToDisc=RfvzyFgmHjMsnauAbSBcKtDVNLdWeU)
 def option_check(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPG=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.get_settings_select_info()
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWeG(RfvzyFgmHjMsnauAbSBcKtDVNLdWPG)==0:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ=xbmcgui.Dialog()
   RfvzyFgmHjMsnauAbSBcKtDVNLdWiP=RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWiP==RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in RfvzyFgmHjMsnauAbSBcKtDVNLdWPG:
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.NF_cookiefile_check()==RfvzyFgmHjMsnauAbSBcKtDVNLdWeU:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.NF_login(showMessage=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ)
 def NF_cookiefile_check(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWio={}
  try: 
   fp=RfvzyFgmHjMsnauAbSBcKtDVNLdWeJ(RfvzyFgmHjMsnauAbSBcKtDVNLdWPp,'r',-1,'utf-8')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWio= json.load(fp)
   fp.close()
  except RfvzyFgmHjMsnauAbSBcKtDVNLdWek as exception:
   return RfvzyFgmHjMsnauAbSBcKtDVNLdWeU
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.NF=RfvzyFgmHjMsnauAbSBcKtDVNLdWio
  RfvzyFgmHjMsnauAbSBcKtDVNLdWiT =RfvzyFgmHjMsnauAbSBcKtDVNLdWeq(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  RfvzyFgmHjMsnauAbSBcKtDVNLdWiY=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.NF['SESSION']['limitdate']
  RfvzyFgmHjMsnauAbSBcKtDVNLdWiE =RfvzyFgmHjMsnauAbSBcKtDVNLdWeq(re.sub('-','',RfvzyFgmHjMsnauAbSBcKtDVNLdWiY))
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWiE<RfvzyFgmHjMsnauAbSBcKtDVNLdWiT:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.Init_NF_Total()
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.NF_login(showMessage=RfvzyFgmHjMsnauAbSBcKtDVNLdWeU)==RfvzyFgmHjMsnauAbSBcKtDVNLdWeU:
    return RfvzyFgmHjMsnauAbSBcKtDVNLdWeU
  return RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ
 def NF_login(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,showMessage=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ):
  if showMessage:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ=xbmcgui.Dialog()
   RfvzyFgmHjMsnauAbSBcKtDVNLdWiP=RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWiP==RfvzyFgmHjMsnauAbSBcKtDVNLdWeU:
    return RfvzyFgmHjMsnauAbSBcKtDVNLdWeU 
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.NF['COOKIES']=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.NF_CookieFile_Load(RfvzyFgmHjMsnauAbSBcKtDVNLdWPe)
  RfvzyFgmHjMsnauAbSBcKtDVNLdWiC=RfvzyFgmHjMsnauAbSBcKtDVNLdWeU if RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.NF['COOKIES']=={}else RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWiC:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_log('pass1 ok!')
  else:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_log('pass1 error!')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_noti(__language__(30905).encode('utf-8'))
   return RfvzyFgmHjMsnauAbSBcKtDVNLdWeU 
  RfvzyFgmHjMsnauAbSBcKtDVNLdWiC=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.NF_Get_BaseSession()
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWiC:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_log('pass2 ok!')
  else:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_log('pass2 error!')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_noti(__language__(30905).encode('utf-8'))
   return RfvzyFgmHjMsnauAbSBcKtDVNLdWeU 
  RfvzyFgmHjMsnauAbSBcKtDVNLdWix =RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.Get_Now_Datetime()
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.NF['SESSION']['limitdate']=RfvzyFgmHjMsnauAbSBcKtDVNLdWix.strftime('%Y-%m-%d')
  try: 
   fp=RfvzyFgmHjMsnauAbSBcKtDVNLdWeJ(RfvzyFgmHjMsnauAbSBcKtDVNLdWPp,'w',-1,'utf-8')
   json.dump(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.NF,fp,indent=4,ensure_ascii=RfvzyFgmHjMsnauAbSBcKtDVNLdWeU)
   fp.close()
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_log('pass3 save ok!')
  except RfvzyFgmHjMsnauAbSBcKtDVNLdWek as exception:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_log('pass3 save error!')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_noti(__language__(30905).encode('utf-8'))
   return RfvzyFgmHjMsnauAbSBcKtDVNLdWeU
  if showMessage:RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_noti(__language__(30904).encode('utf-8'))
  return RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ
 def NF_logout(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ=xbmcgui.Dialog()
  RfvzyFgmHjMsnauAbSBcKtDVNLdWiP=RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWiP==RfvzyFgmHjMsnauAbSBcKtDVNLdWeU:return 
  if os.path.isfile(RfvzyFgmHjMsnauAbSBcKtDVNLdWPp):os.remove(RfvzyFgmHjMsnauAbSBcKtDVNLdWPp)
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,RfvzyFgmHjMsnauAbSBcKtDVNLdWiG):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWiU=''
  RfvzyFgmHjMsnauAbSBcKtDVNLdWih=7
  try:
   for i in RfvzyFgmHjMsnauAbSBcKtDVNLdWeO(RfvzyFgmHjMsnauAbSBcKtDVNLdWeG(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG)):
    if i>=RfvzyFgmHjMsnauAbSBcKtDVNLdWih:
     RfvzyFgmHjMsnauAbSBcKtDVNLdWiU=RfvzyFgmHjMsnauAbSBcKtDVNLdWiU+'...'
     break
    RfvzyFgmHjMsnauAbSBcKtDVNLdWiU=RfvzyFgmHjMsnauAbSBcKtDVNLdWiU+RfvzyFgmHjMsnauAbSBcKtDVNLdWiG[i]['title']+'\n'
  except:
   return ''
  return RfvzyFgmHjMsnauAbSBcKtDVNLdWiU
 def dp_Search_Group(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,args):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPG =RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.get_settings_select_info()
  RfvzyFgmHjMsnauAbSBcKtDVNLdWir=[]
  if 'search_key' in args:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ=args.get('search_key')
  else:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ:
    xbmcplugin.endOfDirectory(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT._addon_handle)
    return
  if 'wavve' in RfvzyFgmHjMsnauAbSBcKtDVNLdWPG:
   (RfvzyFgmHjMsnauAbSBcKtDVNLdWiG,RfvzyFgmHjMsnauAbSBcKtDVNLdWik)=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.Get_Search_Wavve(RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ,'TVSHOW',1)
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWeG(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG)>0:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWiq={'sType':'wavve_tvshow','sList':RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.MakeText_FreeList(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG),}
    RfvzyFgmHjMsnauAbSBcKtDVNLdWir.append(RfvzyFgmHjMsnauAbSBcKtDVNLdWiq)
   (RfvzyFgmHjMsnauAbSBcKtDVNLdWiG,RfvzyFgmHjMsnauAbSBcKtDVNLdWik)=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.Get_Search_Wavve(RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ,'MOVIE',1)
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWeG(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG)>0:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWiq={'sType':'wavve_movie','sList':RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.MakeText_FreeList(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG),}
    RfvzyFgmHjMsnauAbSBcKtDVNLdWir.append(RfvzyFgmHjMsnauAbSBcKtDVNLdWiq)
  if 'tving' in RfvzyFgmHjMsnauAbSBcKtDVNLdWPG:
   (RfvzyFgmHjMsnauAbSBcKtDVNLdWiG,RfvzyFgmHjMsnauAbSBcKtDVNLdWik)=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.Get_Search_Tving(RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ,'TVSHOW',1)
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWeG(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG)>0:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWiq={'sType':'tving_tvshow','sList':RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.MakeText_FreeList(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG),}
    RfvzyFgmHjMsnauAbSBcKtDVNLdWir.append(RfvzyFgmHjMsnauAbSBcKtDVNLdWiq)
   (RfvzyFgmHjMsnauAbSBcKtDVNLdWiG,RfvzyFgmHjMsnauAbSBcKtDVNLdWik)=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.Get_Search_Tving(RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ,'MOVIE',1)
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWeG(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG)>0:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWiq={'sType':'tving_movie','sList':RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.MakeText_FreeList(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG),}
    RfvzyFgmHjMsnauAbSBcKtDVNLdWir.append(RfvzyFgmHjMsnauAbSBcKtDVNLdWiq)
  if 'watcha' in RfvzyFgmHjMsnauAbSBcKtDVNLdWPG:
   (RfvzyFgmHjMsnauAbSBcKtDVNLdWiG,RfvzyFgmHjMsnauAbSBcKtDVNLdWik)=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.Get_Search_Watcha(RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ,1)
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWeG(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG)>0:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWiq={'sType':'watcha_list','sList':RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.MakeText_FreeList(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG),}
    RfvzyFgmHjMsnauAbSBcKtDVNLdWir.append(RfvzyFgmHjMsnauAbSBcKtDVNLdWiq)
  if 'netflix' in RfvzyFgmHjMsnauAbSBcKtDVNLdWPG:
   try:
    (RfvzyFgmHjMsnauAbSBcKtDVNLdWiG,RfvzyFgmHjMsnauAbSBcKtDVNLdWik,RfvzyFgmHjMsnauAbSBcKtDVNLdWiO)=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.Get_Search_Netflix(RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ,1)
   except:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWiG=[]
    RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_noti(__language__(30919).encode('utf8'))
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWeG(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG)>0:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWiq={'sType':'netflix_list','sList':RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.MakeText_FreeList(RfvzyFgmHjMsnauAbSBcKtDVNLdWiG),}
    RfvzyFgmHjMsnauAbSBcKtDVNLdWir.append(RfvzyFgmHjMsnauAbSBcKtDVNLdWiq)
  for RfvzyFgmHjMsnauAbSBcKtDVNLdWiw in RfvzyFgmHjMsnauAbSBcKtDVNLdWir:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWiX=RfvzyFgmHjMsnauAbSBcKtDVNLdWPl[RfvzyFgmHjMsnauAbSBcKtDVNLdWiw.get('sType')]
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlP={'plot':'검색어 : '+RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ+'\n\n'+RfvzyFgmHjMsnauAbSBcKtDVNLdWiw.get('sList')}
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPq=RfvzyFgmHjMsnauAbSBcKtDVNLdWiX.get('title')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIU={'mode':RfvzyFgmHjMsnauAbSBcKtDVNLdWiX.get('mode'),'ott':RfvzyFgmHjMsnauAbSBcKtDVNLdWiX.get('ott'),'vidtype':RfvzyFgmHjMsnauAbSBcKtDVNLdWiX.get('vidtype'),'search_key':RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ}
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWiX.get('ott')=='netflix':
    RfvzyFgmHjMsnauAbSBcKtDVNLdWIU['page'] ='1'
    RfvzyFgmHjMsnauAbSBcKtDVNLdWIU['byReference']='-'
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',RfvzyFgmHjMsnauAbSBcKtDVNLdWiX.get('icon'))
   RfvzyFgmHjMsnauAbSBcKtDVNLdWil=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ if RfvzyFgmHjMsnauAbSBcKtDVNLdWiX.get('mode')!='HYPER_LINK' else RfvzyFgmHjMsnauAbSBcKtDVNLdWeU
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.add_dir(RfvzyFgmHjMsnauAbSBcKtDVNLdWPq,sublabel='',img=RfvzyFgmHjMsnauAbSBcKtDVNLdWIq,infoLabels=RfvzyFgmHjMsnauAbSBcKtDVNLdWlP,isFolder=RfvzyFgmHjMsnauAbSBcKtDVNLdWil,params=RfvzyFgmHjMsnauAbSBcKtDVNLdWIU,isLink=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ)
  xbmcplugin.endOfDirectory(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT._addon_handle)
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.Save_Searched_List(RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ)
 def dp_Hyper_Link(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,args):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWlI =args.get('mode')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWli =args.get('ott')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWle =args.get('vidtype')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ=args.get('search_key')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWlp='-'
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWli=='wavve':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlo={'mode':'LOCAL_SEARCH','sType':'movie' if RfvzyFgmHjMsnauAbSBcKtDVNLdWle=='MOVIE' else 'vod','search_key':RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ,'page':'1',}
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlT=urllib.parse.urlencode(RfvzyFgmHjMsnauAbSBcKtDVNLdWlo)
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlp='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(RfvzyFgmHjMsnauAbSBcKtDVNLdWlT)
  elif RfvzyFgmHjMsnauAbSBcKtDVNLdWli=='tving':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlo={'mode':'LOCAL_SEARCH','stype':'movie' if RfvzyFgmHjMsnauAbSBcKtDVNLdWle=='MOVIE' else 'vod','search_key':RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ,'page':'1',}
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlT=urllib.parse.urlencode(RfvzyFgmHjMsnauAbSBcKtDVNLdWlo)
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlp='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(RfvzyFgmHjMsnauAbSBcKtDVNLdWlT)
  elif RfvzyFgmHjMsnauAbSBcKtDVNLdWli=='watcha':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlo={'mode':'LOCAL_SEARCH','search_key':RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ,'page':'1',}
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlT=urllib.parse.urlencode(RfvzyFgmHjMsnauAbSBcKtDVNLdWlo)
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlp='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(RfvzyFgmHjMsnauAbSBcKtDVNLdWlT)
  elif RfvzyFgmHjMsnauAbSBcKtDVNLdWli=='netflix':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlY=args.get('videoid')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlE=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.NF['SESSION']['nowGuid']
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWle=='TVSHOW':
    RfvzyFgmHjMsnauAbSBcKtDVNLdWlp='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(RfvzyFgmHjMsnauAbSBcKtDVNLdWlY)
   else:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWlp='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(RfvzyFgmHjMsnauAbSBcKtDVNLdWlY,RfvzyFgmHjMsnauAbSBcKtDVNLdWlE)
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.addon_log('ott_url ==> ( '+RfvzyFgmHjMsnauAbSBcKtDVNLdWlp+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(RfvzyFgmHjMsnauAbSBcKtDVNLdWlp)
 def dp_Nf_Search(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,args):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWlC =RfvzyFgmHjMsnauAbSBcKtDVNLdWeq(args.get('page'))
  RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ =args.get('search_key')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWiO=args.get('byReference')
  (RfvzyFgmHjMsnauAbSBcKtDVNLdWiG,RfvzyFgmHjMsnauAbSBcKtDVNLdWik,RfvzyFgmHjMsnauAbSBcKtDVNLdWiO)=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.SearchObj.Get_Search_Netflix(RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ,RfvzyFgmHjMsnauAbSBcKtDVNLdWlC,byReference=RfvzyFgmHjMsnauAbSBcKtDVNLdWiO)
  for RfvzyFgmHjMsnauAbSBcKtDVNLdWlx in RfvzyFgmHjMsnauAbSBcKtDVNLdWiG:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlY =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('videoid')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWle =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('vidtype')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPq =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('title')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlQ =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('mpaa')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlU =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('regularSynopsis')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlh =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('dpSupplemental')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlr=RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('sequiturEvidence')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlJ =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('thumbnail')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlG =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('year')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlk =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('duration')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlq =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('info_genre')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlO =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('director')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlw =RfvzyFgmHjMsnauAbSBcKtDVNLdWlx.get('cast')
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWle=='movie':
    RfvzyFgmHjMsnauAbSBcKtDVNLdWIG=' (%s)'%(RfvzyFgmHjMsnauAbSBcKtDVNLdWew(RfvzyFgmHjMsnauAbSBcKtDVNLdWlG))
   else:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWIG=''
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlX=''
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWlU:RfvzyFgmHjMsnauAbSBcKtDVNLdWlX=RfvzyFgmHjMsnauAbSBcKtDVNLdWlX+'\n\n'+RfvzyFgmHjMsnauAbSBcKtDVNLdWlU
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWlh :RfvzyFgmHjMsnauAbSBcKtDVNLdWlX=RfvzyFgmHjMsnauAbSBcKtDVNLdWlX+'\n\n'+RfvzyFgmHjMsnauAbSBcKtDVNLdWlh
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWlr:RfvzyFgmHjMsnauAbSBcKtDVNLdWlX=RfvzyFgmHjMsnauAbSBcKtDVNLdWlX+'\n\n'+RfvzyFgmHjMsnauAbSBcKtDVNLdWlr
   RfvzyFgmHjMsnauAbSBcKtDVNLdWlX=RfvzyFgmHjMsnauAbSBcKtDVNLdWlX.strip()
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIk={'mediatype':'tvshow' if RfvzyFgmHjMsnauAbSBcKtDVNLdWle=='show' else 'movie','title':RfvzyFgmHjMsnauAbSBcKtDVNLdWPq,'mpaa':RfvzyFgmHjMsnauAbSBcKtDVNLdWlQ,'plot':RfvzyFgmHjMsnauAbSBcKtDVNLdWlX,'duration':RfvzyFgmHjMsnauAbSBcKtDVNLdWlk,'genre':RfvzyFgmHjMsnauAbSBcKtDVNLdWlq,'director':RfvzyFgmHjMsnauAbSBcKtDVNLdWlO,'cast':RfvzyFgmHjMsnauAbSBcKtDVNLdWlw,'year':RfvzyFgmHjMsnauAbSBcKtDVNLdWlG,}
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIU={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if RfvzyFgmHjMsnauAbSBcKtDVNLdWle=='show' else 'MOVIE','videoid':RfvzyFgmHjMsnauAbSBcKtDVNLdWlY,}
   if RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.get_settings_makebookmark():
    RfvzyFgmHjMsnauAbSBcKtDVNLdWeP={'videoid':RfvzyFgmHjMsnauAbSBcKtDVNLdWlY,'vidtype':'tvshow' if RfvzyFgmHjMsnauAbSBcKtDVNLdWle=='show' else 'movie','vtitle':RfvzyFgmHjMsnauAbSBcKtDVNLdWPq+RfvzyFgmHjMsnauAbSBcKtDVNLdWIG,'vsubtitle':'','vinfo':RfvzyFgmHjMsnauAbSBcKtDVNLdWIk,'thumbnail':RfvzyFgmHjMsnauAbSBcKtDVNLdWlJ,}
    RfvzyFgmHjMsnauAbSBcKtDVNLdWeI=json.dumps(RfvzyFgmHjMsnauAbSBcKtDVNLdWeP)
    RfvzyFgmHjMsnauAbSBcKtDVNLdWeI=urllib.parse.quote(RfvzyFgmHjMsnauAbSBcKtDVNLdWeI)
    RfvzyFgmHjMsnauAbSBcKtDVNLdWei='RunPlugin(plugin://plugin.video.searchm/?mode=SET_BOOKMARK&bm_param=%s)'%(RfvzyFgmHjMsnauAbSBcKtDVNLdWeI)
    RfvzyFgmHjMsnauAbSBcKtDVNLdWIJ=[('(통합) 찜 영상에 추가',RfvzyFgmHjMsnauAbSBcKtDVNLdWei)]
   else:
    RfvzyFgmHjMsnauAbSBcKtDVNLdWIJ=RfvzyFgmHjMsnauAbSBcKtDVNLdWex
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.add_dir(RfvzyFgmHjMsnauAbSBcKtDVNLdWPq+RfvzyFgmHjMsnauAbSBcKtDVNLdWIG,sublabel=RfvzyFgmHjMsnauAbSBcKtDVNLdWex,img=RfvzyFgmHjMsnauAbSBcKtDVNLdWlJ,infoLabels=RfvzyFgmHjMsnauAbSBcKtDVNLdWIk,isFolder=RfvzyFgmHjMsnauAbSBcKtDVNLdWeU,params=RfvzyFgmHjMsnauAbSBcKtDVNLdWIU,isLink=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ,ContextMenu=RfvzyFgmHjMsnauAbSBcKtDVNLdWIJ)
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWik:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIU={}
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIU['mode'] ='NF_SEARCH' 
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIU['page'] =RfvzyFgmHjMsnauAbSBcKtDVNLdWew(RfvzyFgmHjMsnauAbSBcKtDVNLdWlC+1)
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIU['search_key']=RfvzyFgmHjMsnauAbSBcKtDVNLdWiJ
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIU['byReference']=RfvzyFgmHjMsnauAbSBcKtDVNLdWiO
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPq='[B]%s >>[/B]'%'다음 페이지'
   RfvzyFgmHjMsnauAbSBcKtDVNLdWel=RfvzyFgmHjMsnauAbSBcKtDVNLdWew(RfvzyFgmHjMsnauAbSBcKtDVNLdWlC+1)
   RfvzyFgmHjMsnauAbSBcKtDVNLdWIq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.add_dir(RfvzyFgmHjMsnauAbSBcKtDVNLdWPq,sublabel=RfvzyFgmHjMsnauAbSBcKtDVNLdWel,img=RfvzyFgmHjMsnauAbSBcKtDVNLdWIq,infoLabels=RfvzyFgmHjMsnauAbSBcKtDVNLdWex,isFolder=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ,params=RfvzyFgmHjMsnauAbSBcKtDVNLdWIU)
  xbmcplugin.setContent(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT._addon_handle,'movies')
  xbmcplugin.endOfDirectory(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT._addon_handle)
 def dp_Bookmark_Menu(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,args):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWlp='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(RfvzyFgmHjMsnauAbSBcKtDVNLdWlp)
 def dp_Set_Bookmark(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT,args):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWep=urllib.parse.unquote(args.get('bm_param'))
  RfvzyFgmHjMsnauAbSBcKtDVNLdWep=json.loads(RfvzyFgmHjMsnauAbSBcKtDVNLdWep)
  RfvzyFgmHjMsnauAbSBcKtDVNLdWlY =RfvzyFgmHjMsnauAbSBcKtDVNLdWep.get('videoid')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWle =RfvzyFgmHjMsnauAbSBcKtDVNLdWep.get('vidtype')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWeo =RfvzyFgmHjMsnauAbSBcKtDVNLdWep.get('vtitle')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWeT =RfvzyFgmHjMsnauAbSBcKtDVNLdWep.get('vsubtitle')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWeY =RfvzyFgmHjMsnauAbSBcKtDVNLdWep.get('vinfo')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWlJ =RfvzyFgmHjMsnauAbSBcKtDVNLdWep.get('thumbnail')
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ=xbmcgui.Dialog()
  RfvzyFgmHjMsnauAbSBcKtDVNLdWiP=RfvzyFgmHjMsnauAbSBcKtDVNLdWPQ.yesno(__language__(30917).encode('utf8'),RfvzyFgmHjMsnauAbSBcKtDVNLdWeo+' \n\n'+__language__(30918))
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWiP==RfvzyFgmHjMsnauAbSBcKtDVNLdWeU:return
  RfvzyFgmHjMsnauAbSBcKtDVNLdWeE={'indexinfo':{'ott':'netflix','videoid':RfvzyFgmHjMsnauAbSBcKtDVNLdWlY,'vidtype':RfvzyFgmHjMsnauAbSBcKtDVNLdWle,},'saveinfo':{'title':RfvzyFgmHjMsnauAbSBcKtDVNLdWeo,'subtitle':RfvzyFgmHjMsnauAbSBcKtDVNLdWeT,'thumbnail':RfvzyFgmHjMsnauAbSBcKtDVNLdWlJ,'infoLabels':RfvzyFgmHjMsnauAbSBcKtDVNLdWeY,},}
  RfvzyFgmHjMsnauAbSBcKtDVNLdWeI=json.dumps(RfvzyFgmHjMsnauAbSBcKtDVNLdWeE)
  RfvzyFgmHjMsnauAbSBcKtDVNLdWeI=urllib.parse.quote(RfvzyFgmHjMsnauAbSBcKtDVNLdWeI)
  RfvzyFgmHjMsnauAbSBcKtDVNLdWei='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(RfvzyFgmHjMsnauAbSBcKtDVNLdWeI)
  xbmc.executebuiltin(RfvzyFgmHjMsnauAbSBcKtDVNLdWei)
 def search_main(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT):
  RfvzyFgmHjMsnauAbSBcKtDVNLdWlI=RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.main_params.get('mode',RfvzyFgmHjMsnauAbSBcKtDVNLdWex)
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWlI=='NFLOGOUT':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.NF_logout()
   return
  elif RfvzyFgmHjMsnauAbSBcKtDVNLdWlI=='NFLOGIN':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.NF_login(showMessage=RfvzyFgmHjMsnauAbSBcKtDVNLdWeQ)
   return
  RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.option_check()
  if RfvzyFgmHjMsnauAbSBcKtDVNLdWlI is RfvzyFgmHjMsnauAbSBcKtDVNLdWex:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.dp_Main_List()
  elif RfvzyFgmHjMsnauAbSBcKtDVNLdWlI=='TOTAL_SEARCH':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.dp_Search_Group(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.main_params)
  elif RfvzyFgmHjMsnauAbSBcKtDVNLdWlI=='HYPER_LINK':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.dp_Hyper_Link(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.main_params)
  elif RfvzyFgmHjMsnauAbSBcKtDVNLdWlI=='NF_SEARCH':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.dp_Nf_Search(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.main_params)
  elif RfvzyFgmHjMsnauAbSBcKtDVNLdWlI=='TOTAL_HISTORY':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.dp_Search_History(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.main_params)
  elif RfvzyFgmHjMsnauAbSBcKtDVNLdWlI=='HISTORY_REMOVE':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.dp_History_Delete(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.main_params)
  elif RfvzyFgmHjMsnauAbSBcKtDVNLdWlI=='MENU_BOOKMARK':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.dp_Bookmark_Menu(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.main_params)
  elif RfvzyFgmHjMsnauAbSBcKtDVNLdWlI=='SET_BOOKMARK':
   RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.dp_Set_Bookmark(RfvzyFgmHjMsnauAbSBcKtDVNLdWPT.main_params)
  else:
   RfvzyFgmHjMsnauAbSBcKtDVNLdWex
# Created by pyminifier (https://github.com/liftoff/pyminifier)
