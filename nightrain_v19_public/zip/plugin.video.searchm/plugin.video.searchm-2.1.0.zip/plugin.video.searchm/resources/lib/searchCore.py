__author__="NightRain"
JgUKSlVftXudDBLsWRiFoyYmAbCMrT=object
JgUKSlVftXudDBLsWRiFoyYmAbCMrh=None
JgUKSlVftXudDBLsWRiFoyYmAbCMrz=False
JgUKSlVftXudDBLsWRiFoyYmAbCMrP=int
JgUKSlVftXudDBLsWRiFoyYmAbCMrc=str
JgUKSlVftXudDBLsWRiFoyYmAbCMrn=Exception
JgUKSlVftXudDBLsWRiFoyYmAbCMrI=print
JgUKSlVftXudDBLsWRiFoyYmAbCMrv=True
JgUKSlVftXudDBLsWRiFoyYmAbCMrE=open
JgUKSlVftXudDBLsWRiFoyYmAbCMrq=isinstance
JgUKSlVftXudDBLsWRiFoyYmAbCMrp=list
JgUKSlVftXudDBLsWRiFoyYmAbCMrN=dict
JgUKSlVftXudDBLsWRiFoyYmAbCMrj=range
JgUKSlVftXudDBLsWRiFoyYmAbCMrx=len
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
class JgUKSlVftXudDBLsWRiFoyYmAbCMOk(JgUKSlVftXudDBLsWRiFoyYmAbCMrT):
 def __init__(JgUKSlVftXudDBLsWRiFoyYmAbCMOH):
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Safari/537.36'
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.DEFAULT_HEADER ={'user-agent':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.USER_AGENT}
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_WAVVE ='https://apis.wavve.com'
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_TVING_SEARCH='https://search.tving.com'
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_TVING_IMG ='https://image.tving.com'
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_WATCHA ='https://api-mars.watcha.com'
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_NETFLIX ='https://www.netflix.com'
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.WAVVE_LIMIT =20 
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.TVING_LIMIT =30
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.WATCHA_LIMIT =30
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_LIMIT =20 
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.DERECTOR_LIMIT =4
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.CAST_LIMIT =10
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.GENRE_LIMIT =4
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.TVING_MOVIE_LITE=['2610061','2610161','261062']
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_HEADER={'user-agent':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND1 ='_342x192'
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND2 ='_665x375'
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_PORT ='_342x684'
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LOGO ='_550x124'
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF={}
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']={}
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']={}
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_ORIGINAL_COOKIE =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_SESSION_COOKIES1 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_SESSION_COOKIES2 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_SESSION_COOKIES3 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_SESSION_COOKIES4 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_SESSION_FULLTEXT1 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_SESSION_FULLTEXT2 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_SESSION_FULLTEXT3 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_SESSION_FULLTEXT4 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_CONTEXTJSON_FILE1 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_CONTEXTJSON_FILE2 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_CONTEXTJSON_FILE3 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_CONTEXTJSON_FILE4 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_FALCORJSON_FILE1 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_FALCORJSON_FILE2 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_FALCORJSON_FILE3 =''
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_FALCORJSON_FILE4 =''
 def callRequestCookies(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,jobtype,JgUKSlVftXudDBLsWRiFoyYmAbCMOz,payload=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,params=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,headers=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,cookies=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,redirects=JgUKSlVftXudDBLsWRiFoyYmAbCMrz):
  JgUKSlVftXudDBLsWRiFoyYmAbCMOQ=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.DEFAULT_HEADER
  if headers:JgUKSlVftXudDBLsWRiFoyYmAbCMOQ.update(headers)
  if jobtype=='Get':
   JgUKSlVftXudDBLsWRiFoyYmAbCMOr=requests.get(JgUKSlVftXudDBLsWRiFoyYmAbCMOz,params=params,headers=JgUKSlVftXudDBLsWRiFoyYmAbCMOQ,cookies=cookies,allow_redirects=redirects)
  else:
   JgUKSlVftXudDBLsWRiFoyYmAbCMOr=requests.post(JgUKSlVftXudDBLsWRiFoyYmAbCMOz,data=payload,params=params,headers=JgUKSlVftXudDBLsWRiFoyYmAbCMOQ,cookies=cookies,allow_redirects=redirects)
  return JgUKSlVftXudDBLsWRiFoyYmAbCMOr
 def GetNoCache(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,timetype=1,minutes=0):
  if timetype==1:
   ts=JgUKSlVftXudDBLsWRiFoyYmAbCMrP(time.time())
   mi=JgUKSlVftXudDBLsWRiFoyYmAbCMrP(minutes*60)
  else:
   ts=JgUKSlVftXudDBLsWRiFoyYmAbCMrP(time.time()*1000)
   mi=JgUKSlVftXudDBLsWRiFoyYmAbCMrP(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(JgUKSlVftXudDBLsWRiFoyYmAbCMOH):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,search_key,sType,page_int):
  JgUKSlVftXudDBLsWRiFoyYmAbCMOG=[]
  JgUKSlVftXudDBLsWRiFoyYmAbCMOT=JgUKSlVftXudDBLsWRiFoyYmAbCMOe=1
  JgUKSlVftXudDBLsWRiFoyYmAbCMOh=JgUKSlVftXudDBLsWRiFoyYmAbCMrz
  try:
   JgUKSlVftXudDBLsWRiFoyYmAbCMOz=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_WAVVE+'/cf/search/list.js'
   JgUKSlVftXudDBLsWRiFoyYmAbCMOP={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':JgUKSlVftXudDBLsWRiFoyYmAbCMrc((page_int-1)*JgUKSlVftXudDBLsWRiFoyYmAbCMOH.WAVVE_LIMIT),'limit':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.WAVVE_LIMIT,'orderby':'score'}
   JgUKSlVftXudDBLsWRiFoyYmAbCMOP.update(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.WAVVE_PARAMS)
   JgUKSlVftXudDBLsWRiFoyYmAbCMOc=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.callRequestCookies('Get',JgUKSlVftXudDBLsWRiFoyYmAbCMOz,payload=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,params=JgUKSlVftXudDBLsWRiFoyYmAbCMOP,headers=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,cookies=JgUKSlVftXudDBLsWRiFoyYmAbCMrh)
   JgUKSlVftXudDBLsWRiFoyYmAbCMOn=json.loads(JgUKSlVftXudDBLsWRiFoyYmAbCMOc.text)
   if not('celllist' in JgUKSlVftXudDBLsWRiFoyYmAbCMOn['cell_toplist']):return JgUKSlVftXudDBLsWRiFoyYmAbCMOG,JgUKSlVftXudDBLsWRiFoyYmAbCMOh
   JgUKSlVftXudDBLsWRiFoyYmAbCMOI=JgUKSlVftXudDBLsWRiFoyYmAbCMOn['cell_toplist']['celllist']
   for JgUKSlVftXudDBLsWRiFoyYmAbCMOv in JgUKSlVftXudDBLsWRiFoyYmAbCMOI:
    JgUKSlVftXudDBLsWRiFoyYmAbCMOE =JgUKSlVftXudDBLsWRiFoyYmAbCMOv['event_list'][1]['url']
    JgUKSlVftXudDBLsWRiFoyYmAbCMOq=urllib.parse.urlsplit(JgUKSlVftXudDBLsWRiFoyYmAbCMOE).query
    JgUKSlVftXudDBLsWRiFoyYmAbCMOp=JgUKSlVftXudDBLsWRiFoyYmAbCMOq[0:JgUKSlVftXudDBLsWRiFoyYmAbCMOq.find('=')]
    JgUKSlVftXudDBLsWRiFoyYmAbCMON=JgUKSlVftXudDBLsWRiFoyYmAbCMOq[JgUKSlVftXudDBLsWRiFoyYmAbCMOq.find('=')+1:]
    JgUKSlVftXudDBLsWRiFoyYmAbCMOp='TVSHOW' if JgUKSlVftXudDBLsWRiFoyYmAbCMOp=='programid' else 'MOVIE' 
    JgUKSlVftXudDBLsWRiFoyYmAbCMOj=JgUKSlVftXudDBLsWRiFoyYmAbCMOv['title_list'][0]['text']
    JgUKSlVftXudDBLsWRiFoyYmAbCMOx =JgUKSlVftXudDBLsWRiFoyYmAbCMOv['age']
    JgUKSlVftXudDBLsWRiFoyYmAbCMOa={'title':JgUKSlVftXudDBLsWRiFoyYmAbCMOj}
    if JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('age')!='21':
     JgUKSlVftXudDBLsWRiFoyYmAbCMOG.append(JgUKSlVftXudDBLsWRiFoyYmAbCMOa)
   JgUKSlVftXudDBLsWRiFoyYmAbCMOT=JgUKSlVftXudDBLsWRiFoyYmAbCMrP(JgUKSlVftXudDBLsWRiFoyYmAbCMOn['cell_toplist']['pagecount'])
   if JgUKSlVftXudDBLsWRiFoyYmAbCMOn['cell_toplist']['count']:JgUKSlVftXudDBLsWRiFoyYmAbCMOe =JgUKSlVftXudDBLsWRiFoyYmAbCMrP(JgUKSlVftXudDBLsWRiFoyYmAbCMOn['cell_toplist']['count'])
   else:JgUKSlVftXudDBLsWRiFoyYmAbCMOe=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.LIST_LIMIT
   JgUKSlVftXudDBLsWRiFoyYmAbCMOh=JgUKSlVftXudDBLsWRiFoyYmAbCMOT>JgUKSlVftXudDBLsWRiFoyYmAbCMOe
  except JgUKSlVftXudDBLsWRiFoyYmAbCMrn as exception:
   JgUKSlVftXudDBLsWRiFoyYmAbCMrI(exception)
  return JgUKSlVftXudDBLsWRiFoyYmAbCMOG,JgUKSlVftXudDBLsWRiFoyYmAbCMOh 
 def Get_Search_Tving(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,search_key,sType,page_int):
  JgUKSlVftXudDBLsWRiFoyYmAbCMOG=[]
  JgUKSlVftXudDBLsWRiFoyYmAbCMOh=JgUKSlVftXudDBLsWRiFoyYmAbCMrz
  try:
   JgUKSlVftXudDBLsWRiFoyYmAbCMkO ='/search/getSearch.jsp'
   JgUKSlVftXudDBLsWRiFoyYmAbCMkH={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':JgUKSlVftXudDBLsWRiFoyYmAbCMrc(page_int),'pageSize':JgUKSlVftXudDBLsWRiFoyYmAbCMrc(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.TVING_PARMAS.get('SCREENCODE'),'os':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.TVING_PARMAS.get('OSCODE'),'network':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':JgUKSlVftXudDBLsWRiFoyYmAbCMrc(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':JgUKSlVftXudDBLsWRiFoyYmAbCMrc(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':JgUKSlVftXudDBLsWRiFoyYmAbCMrc(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.GetNoCache(2))}
   JgUKSlVftXudDBLsWRiFoyYmAbCMOz=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_TVING_SEARCH+JgUKSlVftXudDBLsWRiFoyYmAbCMkO
   JgUKSlVftXudDBLsWRiFoyYmAbCMOc=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.callRequestCookies('Get',JgUKSlVftXudDBLsWRiFoyYmAbCMOz,payload=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,params=JgUKSlVftXudDBLsWRiFoyYmAbCMkH,headers=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,cookies=JgUKSlVftXudDBLsWRiFoyYmAbCMrh)
   JgUKSlVftXudDBLsWRiFoyYmAbCMkQ=json.loads(JgUKSlVftXudDBLsWRiFoyYmAbCMOc.text)
   if sType=='TVSHOW':
    if not('programRsb' in JgUKSlVftXudDBLsWRiFoyYmAbCMkQ):return JgUKSlVftXudDBLsWRiFoyYmAbCMOG,JgUKSlVftXudDBLsWRiFoyYmAbCMOh
    JgUKSlVftXudDBLsWRiFoyYmAbCMkr=JgUKSlVftXudDBLsWRiFoyYmAbCMkQ['programRsb']['dataList']
    JgUKSlVftXudDBLsWRiFoyYmAbCMkw =JgUKSlVftXudDBLsWRiFoyYmAbCMrP(JgUKSlVftXudDBLsWRiFoyYmAbCMkQ['programRsb']['count'])
    for JgUKSlVftXudDBLsWRiFoyYmAbCMOv in JgUKSlVftXudDBLsWRiFoyYmAbCMkr:
     JgUKSlVftXudDBLsWRiFoyYmAbCMkG=JgUKSlVftXudDBLsWRiFoyYmAbCMOv['mast_cd']
     JgUKSlVftXudDBLsWRiFoyYmAbCMOj =JgUKSlVftXudDBLsWRiFoyYmAbCMOv['mast_nm']
     JgUKSlVftXudDBLsWRiFoyYmAbCMkT=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_TVING_IMG+JgUKSlVftXudDBLsWRiFoyYmAbCMOv['web_url4']
     JgUKSlVftXudDBLsWRiFoyYmAbCMkh =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_TVING_IMG+JgUKSlVftXudDBLsWRiFoyYmAbCMOv['web_url']
     try:
      JgUKSlVftXudDBLsWRiFoyYmAbCMkz =[]
      JgUKSlVftXudDBLsWRiFoyYmAbCMkP=[]
      JgUKSlVftXudDBLsWRiFoyYmAbCMkc =[]
      JgUKSlVftXudDBLsWRiFoyYmAbCMkn =0
      JgUKSlVftXudDBLsWRiFoyYmAbCMkI =''
      JgUKSlVftXudDBLsWRiFoyYmAbCMkv =''
      JgUKSlVftXudDBLsWRiFoyYmAbCMkE =''
      if JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('actor') !='' and JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('actor') !='-':JgUKSlVftXudDBLsWRiFoyYmAbCMkz =JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('actor').split(',')
      if JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('director')!='' and JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('director')!='-':JgUKSlVftXudDBLsWRiFoyYmAbCMkP=JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('director').split(',')
      if JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('cate_nm')!='' and JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('cate_nm')!='-':JgUKSlVftXudDBLsWRiFoyYmAbCMkc =JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('cate_nm').split('/')
      if 'targetage' in JgUKSlVftXudDBLsWRiFoyYmAbCMOv:JgUKSlVftXudDBLsWRiFoyYmAbCMkI=JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('targetage')
      if 'broad_dt' in JgUKSlVftXudDBLsWRiFoyYmAbCMOv:
       JgUKSlVftXudDBLsWRiFoyYmAbCMkq=JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('broad_dt')
       JgUKSlVftXudDBLsWRiFoyYmAbCMkE='%s-%s-%s'%(JgUKSlVftXudDBLsWRiFoyYmAbCMkq[:4],JgUKSlVftXudDBLsWRiFoyYmAbCMkq[4:6],JgUKSlVftXudDBLsWRiFoyYmAbCMkq[6:])
       JgUKSlVftXudDBLsWRiFoyYmAbCMkv =JgUKSlVftXudDBLsWRiFoyYmAbCMkq[:4]
     except:
      JgUKSlVftXudDBLsWRiFoyYmAbCMrh
     JgUKSlVftXudDBLsWRiFoyYmAbCMOa={'title':JgUKSlVftXudDBLsWRiFoyYmAbCMOj,}
     JgUKSlVftXudDBLsWRiFoyYmAbCMOG.append(JgUKSlVftXudDBLsWRiFoyYmAbCMOa)
   else:
    if not('vodMVRsb' in JgUKSlVftXudDBLsWRiFoyYmAbCMkQ):return JgUKSlVftXudDBLsWRiFoyYmAbCMOG,JgUKSlVftXudDBLsWRiFoyYmAbCMOh
    JgUKSlVftXudDBLsWRiFoyYmAbCMkp=JgUKSlVftXudDBLsWRiFoyYmAbCMkQ['vodMVRsb']['dataList']
    JgUKSlVftXudDBLsWRiFoyYmAbCMkw =JgUKSlVftXudDBLsWRiFoyYmAbCMrP(JgUKSlVftXudDBLsWRiFoyYmAbCMkQ['vodMVRsb']['count'])
    JgUKSlVftXudDBLsWRiFoyYmAbCMrI(JgUKSlVftXudDBLsWRiFoyYmAbCMkw)
    for JgUKSlVftXudDBLsWRiFoyYmAbCMOv in JgUKSlVftXudDBLsWRiFoyYmAbCMkp:
     JgUKSlVftXudDBLsWRiFoyYmAbCMkG=JgUKSlVftXudDBLsWRiFoyYmAbCMOv['mast_cd']
     JgUKSlVftXudDBLsWRiFoyYmAbCMOj =JgUKSlVftXudDBLsWRiFoyYmAbCMOv['mast_nm'].strip()
     JgUKSlVftXudDBLsWRiFoyYmAbCMkT =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_TVING_IMG+JgUKSlVftXudDBLsWRiFoyYmAbCMOv['web_url']
     JgUKSlVftXudDBLsWRiFoyYmAbCMkh =JgUKSlVftXudDBLsWRiFoyYmAbCMkT
     JgUKSlVftXudDBLsWRiFoyYmAbCMkN=''
     try:
      JgUKSlVftXudDBLsWRiFoyYmAbCMkz =[]
      JgUKSlVftXudDBLsWRiFoyYmAbCMkP=[]
      JgUKSlVftXudDBLsWRiFoyYmAbCMkc =[]
      JgUKSlVftXudDBLsWRiFoyYmAbCMkn =0
      JgUKSlVftXudDBLsWRiFoyYmAbCMkI =''
      JgUKSlVftXudDBLsWRiFoyYmAbCMkv =''
      JgUKSlVftXudDBLsWRiFoyYmAbCMkE =''
      if JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('actor') !='' and JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('actor') !='-':JgUKSlVftXudDBLsWRiFoyYmAbCMkz =JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('actor').split(',')
      if JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('director')!='' and JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('director')!='-':JgUKSlVftXudDBLsWRiFoyYmAbCMkP=JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('director').split(',')
      if JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('cate_nm')!='' and JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('cate_nm')!='-':JgUKSlVftXudDBLsWRiFoyYmAbCMkc =JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('cate_nm').split('/')
      if JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('runtime_sec')!='':JgUKSlVftXudDBLsWRiFoyYmAbCMkn=JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('runtime_sec')
      if 'grade_nm' in JgUKSlVftXudDBLsWRiFoyYmAbCMOv:JgUKSlVftXudDBLsWRiFoyYmAbCMkI=JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('grade_nm')
      JgUKSlVftXudDBLsWRiFoyYmAbCMkj=''
      JgUKSlVftXudDBLsWRiFoyYmAbCMkq=JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('broad_dt')
      if JgUKSlVftXudDBLsWRiFoyYmAbCMkj!='':
       JgUKSlVftXudDBLsWRiFoyYmAbCMkE='%s-%s-%s'%(JgUKSlVftXudDBLsWRiFoyYmAbCMkq[:4],JgUKSlVftXudDBLsWRiFoyYmAbCMkq[4:6],JgUKSlVftXudDBLsWRiFoyYmAbCMkq[6:])
       JgUKSlVftXudDBLsWRiFoyYmAbCMkv =JgUKSlVftXudDBLsWRiFoyYmAbCMkq[:4]
     except:
      JgUKSlVftXudDBLsWRiFoyYmAbCMrh
     JgUKSlVftXudDBLsWRiFoyYmAbCMOa={'title':JgUKSlVftXudDBLsWRiFoyYmAbCMOj,}
     JgUKSlVftXudDBLsWRiFoyYmAbCMkx=JgUKSlVftXudDBLsWRiFoyYmAbCMrz
     for JgUKSlVftXudDBLsWRiFoyYmAbCMka in JgUKSlVftXudDBLsWRiFoyYmAbCMOv['bill']:
      if JgUKSlVftXudDBLsWRiFoyYmAbCMka in JgUKSlVftXudDBLsWRiFoyYmAbCMOH.TVING_MOVIE_LITE:
       JgUKSlVftXudDBLsWRiFoyYmAbCMkx=JgUKSlVftXudDBLsWRiFoyYmAbCMrv
       break
     if JgUKSlVftXudDBLsWRiFoyYmAbCMkx==JgUKSlVftXudDBLsWRiFoyYmAbCMrz: 
      JgUKSlVftXudDBLsWRiFoyYmAbCMOa['title']=JgUKSlVftXudDBLsWRiFoyYmAbCMOa['title']+' [개별구매]'
     JgUKSlVftXudDBLsWRiFoyYmAbCMOG.append(JgUKSlVftXudDBLsWRiFoyYmAbCMOa)
   if JgUKSlVftXudDBLsWRiFoyYmAbCMkw>(page_int*JgUKSlVftXudDBLsWRiFoyYmAbCMOH.TVING_LIMIT):JgUKSlVftXudDBLsWRiFoyYmAbCMOh=JgUKSlVftXudDBLsWRiFoyYmAbCMrv
  except JgUKSlVftXudDBLsWRiFoyYmAbCMrn as exception:
   JgUKSlVftXudDBLsWRiFoyYmAbCMrI(exception)
  return JgUKSlVftXudDBLsWRiFoyYmAbCMOG,JgUKSlVftXudDBLsWRiFoyYmAbCMOh
 def Get_Search_Watcha(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,search_key,page_int):
  JgUKSlVftXudDBLsWRiFoyYmAbCMOG=[]
  JgUKSlVftXudDBLsWRiFoyYmAbCMOh=JgUKSlVftXudDBLsWRiFoyYmAbCMrz
  try:
   JgUKSlVftXudDBLsWRiFoyYmAbCMOz=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_WATCHA+'/api/search.json'
   JgUKSlVftXudDBLsWRiFoyYmAbCMkH={'query':search_key,'page':JgUKSlVftXudDBLsWRiFoyYmAbCMrc(page_int),'per':JgUKSlVftXudDBLsWRiFoyYmAbCMrc(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.WATCHA_LIMIT),'exclude':'limited',}
   JgUKSlVftXudDBLsWRiFoyYmAbCMOc=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.callRequestCookies('Get',JgUKSlVftXudDBLsWRiFoyYmAbCMOz,payload=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,params=JgUKSlVftXudDBLsWRiFoyYmAbCMkH,headers=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.WATCHA_HEADER,cookies=JgUKSlVftXudDBLsWRiFoyYmAbCMrh)
   JgUKSlVftXudDBLsWRiFoyYmAbCMkQ=json.loads(JgUKSlVftXudDBLsWRiFoyYmAbCMOc.text)
   if not('results' in JgUKSlVftXudDBLsWRiFoyYmAbCMkQ):return JgUKSlVftXudDBLsWRiFoyYmAbCMOG,JgUKSlVftXudDBLsWRiFoyYmAbCMOh
   JgUKSlVftXudDBLsWRiFoyYmAbCMke=JgUKSlVftXudDBLsWRiFoyYmAbCMkQ['results']
   JgUKSlVftXudDBLsWRiFoyYmAbCMOh=JgUKSlVftXudDBLsWRiFoyYmAbCMkQ['meta']['has_next']
   for JgUKSlVftXudDBLsWRiFoyYmAbCMOv in JgUKSlVftXudDBLsWRiFoyYmAbCMke:
    JgUKSlVftXudDBLsWRiFoyYmAbCMHO =JgUKSlVftXudDBLsWRiFoyYmAbCMOv['code']
    JgUKSlVftXudDBLsWRiFoyYmAbCMHk=JgUKSlVftXudDBLsWRiFoyYmAbCMOv['content_type']
    JgUKSlVftXudDBLsWRiFoyYmAbCMHQ =JgUKSlVftXudDBLsWRiFoyYmAbCMOv['title']
    JgUKSlVftXudDBLsWRiFoyYmAbCMHr =JgUKSlVftXudDBLsWRiFoyYmAbCMOv['story']
    JgUKSlVftXudDBLsWRiFoyYmAbCMkT=JgUKSlVftXudDBLsWRiFoyYmAbCMkh=JgUKSlVftXudDBLsWRiFoyYmAbCMQx=''
    if JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('poster') !=JgUKSlVftXudDBLsWRiFoyYmAbCMrh:JgUKSlVftXudDBLsWRiFoyYmAbCMkT=JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('poster').get('original')
    if JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('stillcut')!=JgUKSlVftXudDBLsWRiFoyYmAbCMrh:JgUKSlVftXudDBLsWRiFoyYmAbCMkh =JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('stillcut').get('large')
    if JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('thumbnail')!=JgUKSlVftXudDBLsWRiFoyYmAbCMrh:JgUKSlVftXudDBLsWRiFoyYmAbCMQx=JgUKSlVftXudDBLsWRiFoyYmAbCMOv.get('thumbnail').get('large')
    if JgUKSlVftXudDBLsWRiFoyYmAbCMQx=='' :JgUKSlVftXudDBLsWRiFoyYmAbCMQx=JgUKSlVftXudDBLsWRiFoyYmAbCMkh
    JgUKSlVftXudDBLsWRiFoyYmAbCMHw={'thumb':JgUKSlVftXudDBLsWRiFoyYmAbCMkh,'poster':JgUKSlVftXudDBLsWRiFoyYmAbCMkT,'fanart':JgUKSlVftXudDBLsWRiFoyYmAbCMQx}
    JgUKSlVftXudDBLsWRiFoyYmAbCMkv =JgUKSlVftXudDBLsWRiFoyYmAbCMOv['year']
    JgUKSlVftXudDBLsWRiFoyYmAbCMHG =JgUKSlVftXudDBLsWRiFoyYmAbCMOv['film_rating_code']
    JgUKSlVftXudDBLsWRiFoyYmAbCMHT=JgUKSlVftXudDBLsWRiFoyYmAbCMOv['film_rating_short']
    JgUKSlVftXudDBLsWRiFoyYmAbCMHh =JgUKSlVftXudDBLsWRiFoyYmAbCMOv['film_rating_long']
    if JgUKSlVftXudDBLsWRiFoyYmAbCMHk=='movies':
     JgUKSlVftXudDBLsWRiFoyYmAbCMkn =JgUKSlVftXudDBLsWRiFoyYmAbCMOv['duration']
    else:
     JgUKSlVftXudDBLsWRiFoyYmAbCMkn ='0'
    JgUKSlVftXudDBLsWRiFoyYmAbCMOa={'title':JgUKSlVftXudDBLsWRiFoyYmAbCMHQ,}
    JgUKSlVftXudDBLsWRiFoyYmAbCMOG.append(JgUKSlVftXudDBLsWRiFoyYmAbCMOa)
  except JgUKSlVftXudDBLsWRiFoyYmAbCMrn as exception:
   JgUKSlVftXudDBLsWRiFoyYmAbCMrI(exception)
  return JgUKSlVftXudDBLsWRiFoyYmAbCMOG,JgUKSlVftXudDBLsWRiFoyYmAbCMOh
 def dic_To_jsonfile(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,filename,JgUKSlVftXudDBLsWRiFoyYmAbCMHz):
  if filename=='':return
  fp=JgUKSlVftXudDBLsWRiFoyYmAbCMrE(filename,'w',-1,'utf-8')
  json.dump(JgUKSlVftXudDBLsWRiFoyYmAbCMHz,fp,indent=4,ensure_ascii=JgUKSlVftXudDBLsWRiFoyYmAbCMrz)
  fp.close()
 def jsonfile_To_dic(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,filename):
  if filename=='':return JgUKSlVftXudDBLsWRiFoyYmAbCMrh
  try:
   fp=JgUKSlVftXudDBLsWRiFoyYmAbCMrE(filename,'r',-1,'utf-8')
   JgUKSlVftXudDBLsWRiFoyYmAbCMHc=json.load(fp)
   fp.close()
  except:
   JgUKSlVftXudDBLsWRiFoyYmAbCMHc={}
  return JgUKSlVftXudDBLsWRiFoyYmAbCMHc
 def tempFileSave(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,filename,resText):
  if filename=='':return
  fp=JgUKSlVftXudDBLsWRiFoyYmAbCMrE(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,filename):
  if filename=='':return
  try:
   fp=JgUKSlVftXudDBLsWRiFoyYmAbCMrE(filename,'r',-1,'utf-8')
   JgUKSlVftXudDBLsWRiFoyYmAbCMHc=fp.read()
   fp.close()
  except:
   JgUKSlVftXudDBLsWRiFoyYmAbCMHc=''
  return JgUKSlVftXudDBLsWRiFoyYmAbCMHc
 def Init_NF_Total(JgUKSlVftXudDBLsWRiFoyYmAbCMOH):
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF={}
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']={}
  JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']={}
 def make_NF_XnetflixHeaders(JgUKSlVftXudDBLsWRiFoyYmAbCMOH):
  JgUKSlVftXudDBLsWRiFoyYmAbCMHn={'x-netflix.browsername':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':JgUKSlVftXudDBLsWRiFoyYmAbCMrc(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['esnModel'],'x-netflix.esnprefix':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['nowGuid'],'x-netflix.uiversion':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return JgUKSlVftXudDBLsWRiFoyYmAbCMHn
 def make_NF_ApiParams(JgUKSlVftXudDBLsWRiFoyYmAbCMOH):
  JgUKSlVftXudDBLsWRiFoyYmAbCMOP={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['identifier']),}
  return JgUKSlVftXudDBLsWRiFoyYmAbCMOP
 def extract_json(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,content,name):
  JgUKSlVftXudDBLsWRiFoyYmAbCMHI=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  JgUKSlVftXudDBLsWRiFoyYmAbCMHv=JgUKSlVftXudDBLsWRiFoyYmAbCMrh
  JgUKSlVftXudDBLsWRiFoyYmAbCMHE=re.compile(JgUKSlVftXudDBLsWRiFoyYmAbCMHI.format(name),re.DOTALL).findall(content)
  JgUKSlVftXudDBLsWRiFoyYmAbCMHv=JgUKSlVftXudDBLsWRiFoyYmAbCMHE[0]
  JgUKSlVftXudDBLsWRiFoyYmAbCMHq=JgUKSlVftXudDBLsWRiFoyYmAbCMHv.replace('\\"','\\\\"') 
  JgUKSlVftXudDBLsWRiFoyYmAbCMHq=JgUKSlVftXudDBLsWRiFoyYmAbCMHq.replace('\\s','\\\\s') 
  JgUKSlVftXudDBLsWRiFoyYmAbCMHq=JgUKSlVftXudDBLsWRiFoyYmAbCMHq.replace('\\n','\\\\n') 
  JgUKSlVftXudDBLsWRiFoyYmAbCMHq=JgUKSlVftXudDBLsWRiFoyYmAbCMHq.replace('\\t','\\\\t') 
  JgUKSlVftXudDBLsWRiFoyYmAbCMHq=JgUKSlVftXudDBLsWRiFoyYmAbCMHq.encode().decode('unicode_escape') 
  JgUKSlVftXudDBLsWRiFoyYmAbCMHq=re.sub(r'\\(?!["])',r'\\\\',JgUKSlVftXudDBLsWRiFoyYmAbCMHq) 
  return json.loads(JgUKSlVftXudDBLsWRiFoyYmAbCMHq)
 def NF_makestr_paths(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,paths):
  JgUKSlVftXudDBLsWRiFoyYmAbCMHc=[]
  if JgUKSlVftXudDBLsWRiFoyYmAbCMrq(paths,JgUKSlVftXudDBLsWRiFoyYmAbCMrP):
   return '%d'%(paths)
  elif JgUKSlVftXudDBLsWRiFoyYmAbCMrq(paths,JgUKSlVftXudDBLsWRiFoyYmAbCMrc):
   return '"%s"'%(paths)
  for JgUKSlVftXudDBLsWRiFoyYmAbCMHp in paths:
   if JgUKSlVftXudDBLsWRiFoyYmAbCMrq(JgUKSlVftXudDBLsWRiFoyYmAbCMHp,JgUKSlVftXudDBLsWRiFoyYmAbCMrP):
    JgUKSlVftXudDBLsWRiFoyYmAbCMHc.append('%d'%(JgUKSlVftXudDBLsWRiFoyYmAbCMHp))
   elif JgUKSlVftXudDBLsWRiFoyYmAbCMrq(JgUKSlVftXudDBLsWRiFoyYmAbCMHp,JgUKSlVftXudDBLsWRiFoyYmAbCMrc):
    JgUKSlVftXudDBLsWRiFoyYmAbCMHc.append('"%s"'%(JgUKSlVftXudDBLsWRiFoyYmAbCMHp))
   elif JgUKSlVftXudDBLsWRiFoyYmAbCMrq(JgUKSlVftXudDBLsWRiFoyYmAbCMHp,JgUKSlVftXudDBLsWRiFoyYmAbCMrp):
    JgUKSlVftXudDBLsWRiFoyYmAbCMHc.append('[%s]'%(','.join(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_makestr_paths(JgUKSlVftXudDBLsWRiFoyYmAbCMHp))))
   elif JgUKSlVftXudDBLsWRiFoyYmAbCMrq(JgUKSlVftXudDBLsWRiFoyYmAbCMHp,JgUKSlVftXudDBLsWRiFoyYmAbCMrN):
    JgUKSlVftXudDBLsWRiFoyYmAbCMHN=''
    for JgUKSlVftXudDBLsWRiFoyYmAbCMHj,JgUKSlVftXudDBLsWRiFoyYmAbCMHx in JgUKSlVftXudDBLsWRiFoyYmAbCMHp.items():
     JgUKSlVftXudDBLsWRiFoyYmAbCMHN+='"%s":%s,'%(JgUKSlVftXudDBLsWRiFoyYmAbCMHj,JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_makestr_paths(JgUKSlVftXudDBLsWRiFoyYmAbCMHx))
    JgUKSlVftXudDBLsWRiFoyYmAbCMHc.append('{%s}'%(JgUKSlVftXudDBLsWRiFoyYmAbCMHN[:-1]))
  return JgUKSlVftXudDBLsWRiFoyYmAbCMHc
 def NF_Call_pathapi(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,JgUKSlVftXudDBLsWRiFoyYmAbCMQP,referer=''):
  JgUKSlVftXudDBLsWRiFoyYmAbCMHa='%s/nq/website/memberapi/%s/pathEvaluator'%(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_NETFLIX,JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['identifier'])
  JgUKSlVftXudDBLsWRiFoyYmAbCMHe={'path':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_makestr_paths(JgUKSlVftXudDBLsWRiFoyYmAbCMQP),'authURL':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']['authURL']}
  JgUKSlVftXudDBLsWRiFoyYmAbCMOP=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.make_NF_ApiParams()
  JgUKSlVftXudDBLsWRiFoyYmAbCMHn={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':JgUKSlVftXudDBLsWRiFoyYmAbCMHn['referer']=referer
  JgUKSlVftXudDBLsWRiFoyYmAbCMQO=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.make_NF_XnetflixHeaders()
  JgUKSlVftXudDBLsWRiFoyYmAbCMHn.update(JgUKSlVftXudDBLsWRiFoyYmAbCMQO)
  JgUKSlVftXudDBLsWRiFoyYmAbCMQk=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_Get_DefaultCookies()
  JgUKSlVftXudDBLsWRiFoyYmAbCMQk['profilesNewSession']='0'
  try:
   JgUKSlVftXudDBLsWRiFoyYmAbCMOc=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.callRequestCookies('Post',JgUKSlVftXudDBLsWRiFoyYmAbCMHa,payload=JgUKSlVftXudDBLsWRiFoyYmAbCMHe,params=JgUKSlVftXudDBLsWRiFoyYmAbCMOP,headers=JgUKSlVftXudDBLsWRiFoyYmAbCMHn,cookies=JgUKSlVftXudDBLsWRiFoyYmAbCMQk)
   return JgUKSlVftXudDBLsWRiFoyYmAbCMOc
  except JgUKSlVftXudDBLsWRiFoyYmAbCMrn as exception:
   JgUKSlVftXudDBLsWRiFoyYmAbCMrI(exception)
   return JgUKSlVftXudDBLsWRiFoyYmAbCMrh
 def Get_Search_Netflix(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,search_key,page_int,byReference=''):
  JgUKSlVftXudDBLsWRiFoyYmAbCMQH=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.DERECTOR_LIMIT
  JgUKSlVftXudDBLsWRiFoyYmAbCMQr =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.CAST_LIMIT
  JgUKSlVftXudDBLsWRiFoyYmAbCMQw =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.GENRE_LIMIT
  JgUKSlVftXudDBLsWRiFoyYmAbCMQG =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_LIMIT*(page_int-1)
  JgUKSlVftXudDBLsWRiFoyYmAbCMQT =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_LIMIT*page_int 
  JgUKSlVftXudDBLsWRiFoyYmAbCMQh="|%s"%(search_key)
  JgUKSlVftXudDBLsWRiFoyYmAbCMQz ='%s/search?%s'%(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   JgUKSlVftXudDBLsWRiFoyYmAbCMQP=[["search","byTerm",JgUKSlVftXudDBLsWRiFoyYmAbCMQh,"titles",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_LIMIT,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"summary"],["search","byTerm",JgUKSlVftXudDBLsWRiFoyYmAbCMQh,"titles",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_LIMIT,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",JgUKSlVftXudDBLsWRiFoyYmAbCMQh,"titles",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_LIMIT,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference","boxarts",[JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND2,JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_PORT],"jpg"],["search","byTerm",JgUKSlVftXudDBLsWRiFoyYmAbCMQh,"titles",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_LIMIT,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference","interestingMoment",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND1,"jpg"],["search","byTerm",JgUKSlVftXudDBLsWRiFoyYmAbCMQh,"titles",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_LIMIT,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference","storyArt",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND2,"jpg"],["search","byTerm",JgUKSlVftXudDBLsWRiFoyYmAbCMQh,"titles",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_LIMIT,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference",["cast","creators","directors"],{"from":0,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQH},["id","name"]],["search","byTerm",JgUKSlVftXudDBLsWRiFoyYmAbCMQh,"titles",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_LIMIT,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference","genres",{"from":0,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQw},["id","name"]],["search","byTerm",JgUKSlVftXudDBLsWRiFoyYmAbCMQh,"titles",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NETFLIX_LIMIT,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LOGO,"png"],]
  else:
   JgUKSlVftXudDBLsWRiFoyYmAbCMQP=[["search","byReference",byReference,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"summary"],["search","byReference",byReference,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference","boxarts",[JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND2,JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference","interestingMoment",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference","storyArt",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference",["cast","creators","directors"],{"from":0,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQH},["id","name"]],["search","byReference",byReference,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference","genres",{"from":0,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQw},["id","name"]],["search","byReference",byReference,{"from":JgUKSlVftXudDBLsWRiFoyYmAbCMQG,"to":JgUKSlVftXudDBLsWRiFoyYmAbCMQT},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LOGO,"png"],]
  try:
   JgUKSlVftXudDBLsWRiFoyYmAbCMOc=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_Call_pathapi(JgUKSlVftXudDBLsWRiFoyYmAbCMQP,JgUKSlVftXudDBLsWRiFoyYmAbCMQz)
   JgUKSlVftXudDBLsWRiFoyYmAbCMOn=json.loads(JgUKSlVftXudDBLsWRiFoyYmAbCMOc.text)
  except JgUKSlVftXudDBLsWRiFoyYmAbCMrn as exception:
   JgUKSlVftXudDBLsWRiFoyYmAbCMrI(exception)
  (JgUKSlVftXudDBLsWRiFoyYmAbCMOG,JgUKSlVftXudDBLsWRiFoyYmAbCMOh,byReference)=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.Search_Netflix_Make(JgUKSlVftXudDBLsWRiFoyYmAbCMOn)
  return JgUKSlVftXudDBLsWRiFoyYmAbCMOG,JgUKSlVftXudDBLsWRiFoyYmAbCMOh,byReference
 def Search_Netflix_Make(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,jsonSource):
  JgUKSlVftXudDBLsWRiFoyYmAbCMOG=[]
  JgUKSlVftXudDBLsWRiFoyYmAbCMOh =JgUKSlVftXudDBLsWRiFoyYmAbCMrz
  JgUKSlVftXudDBLsWRiFoyYmAbCMQc=''
  JgUKSlVftXudDBLsWRiFoyYmAbCMQn=jsonSource.get('paths')[0][1]
  if JgUKSlVftXudDBLsWRiFoyYmAbCMQn=='byTerm':
   JgUKSlVftXudDBLsWRiFoyYmAbCMQG =jsonSource['paths'][0][5]['from']
   JgUKSlVftXudDBLsWRiFoyYmAbCMQT =jsonSource['paths'][0][5]['to']
  else:
   JgUKSlVftXudDBLsWRiFoyYmAbCMQG =jsonSource['paths'][0][3]['from']
   JgUKSlVftXudDBLsWRiFoyYmAbCMQT =jsonSource['paths'][0][3]['to']
  JgUKSlVftXudDBLsWRiFoyYmAbCMQc=JgUKSlVftXudDBLsWRiFoyYmAbCMrp(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  JgUKSlVftXudDBLsWRiFoyYmAbCMQI=jsonSource.get('jsonGraph').get('search').get('byReference').get(JgUKSlVftXudDBLsWRiFoyYmAbCMQc)
  JgUKSlVftXudDBLsWRiFoyYmAbCMQv =jsonSource.get('jsonGraph').get('videos')
  JgUKSlVftXudDBLsWRiFoyYmAbCMQE=jsonSource.get('jsonGraph').get('person')
  JgUKSlVftXudDBLsWRiFoyYmAbCMQq=jsonSource.get('jsonGraph').get('genres')
  JgUKSlVftXudDBLsWRiFoyYmAbCMOh=JgUKSlVftXudDBLsWRiFoyYmAbCMrv if JgUKSlVftXudDBLsWRiFoyYmAbCMQI[JgUKSlVftXudDBLsWRiFoyYmAbCMrc(JgUKSlVftXudDBLsWRiFoyYmAbCMQT)]['reference']['$type']=='ref' else JgUKSlVftXudDBLsWRiFoyYmAbCMrz
  for JgUKSlVftXudDBLsWRiFoyYmAbCMQp in JgUKSlVftXudDBLsWRiFoyYmAbCMrj(JgUKSlVftXudDBLsWRiFoyYmAbCMQG,JgUKSlVftXudDBLsWRiFoyYmAbCMQT):
   if JgUKSlVftXudDBLsWRiFoyYmAbCMQI[JgUKSlVftXudDBLsWRiFoyYmAbCMrc(JgUKSlVftXudDBLsWRiFoyYmAbCMQp)]['reference']['$type']=='ref':
    JgUKSlVftXudDBLsWRiFoyYmAbCMON =JgUKSlVftXudDBLsWRiFoyYmAbCMQI[JgUKSlVftXudDBLsWRiFoyYmAbCMrc(JgUKSlVftXudDBLsWRiFoyYmAbCMQp)]['reference']['value'][1]
    JgUKSlVftXudDBLsWRiFoyYmAbCMQN=JgUKSlVftXudDBLsWRiFoyYmAbCMQv[JgUKSlVftXudDBLsWRiFoyYmAbCMON]
    JgUKSlVftXudDBLsWRiFoyYmAbCMHQ =JgUKSlVftXudDBLsWRiFoyYmAbCMQN['title']['value']
    if JgUKSlVftXudDBLsWRiFoyYmAbCMQN['availability']['value']['isPlayable']==JgUKSlVftXudDBLsWRiFoyYmAbCMrz:
     continue
    JgUKSlVftXudDBLsWRiFoyYmAbCMOp =JgUKSlVftXudDBLsWRiFoyYmAbCMQN['summary']['value']['type']
    JgUKSlVftXudDBLsWRiFoyYmAbCMkn =0 if JgUKSlVftXudDBLsWRiFoyYmAbCMOp!='movie' else JgUKSlVftXudDBLsWRiFoyYmAbCMQN['runtime']['value']
    if JgUKSlVftXudDBLsWRiFoyYmAbCMQN['sequiturEvidence']['value']['value']:
     JgUKSlVftXudDBLsWRiFoyYmAbCMQj=JgUKSlVftXudDBLsWRiFoyYmAbCMQN['sequiturEvidence']['value']['value']['text']
    else:
     JgUKSlVftXudDBLsWRiFoyYmAbCMQj=''
    JgUKSlVftXudDBLsWRiFoyYmAbCMkT =JgUKSlVftXudDBLsWRiFoyYmAbCMQN['boxarts'][JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_PORT]['jpg']['value']['url']
    JgUKSlVftXudDBLsWRiFoyYmAbCMQx =JgUKSlVftXudDBLsWRiFoyYmAbCMQN['boxarts'][JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND2]['jpg']['value']['url']
    JgUKSlVftXudDBLsWRiFoyYmAbCMkh=''
    if 'value' in JgUKSlVftXudDBLsWRiFoyYmAbCMQN['storyArt'][JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND2]['jpg']:
     JgUKSlVftXudDBLsWRiFoyYmAbCMkh =JgUKSlVftXudDBLsWRiFoyYmAbCMQN['storyArt'][JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND2]['jpg']['value']['url']
    if JgUKSlVftXudDBLsWRiFoyYmAbCMkh=='' and 'value' in JgUKSlVftXudDBLsWRiFoyYmAbCMQN['interestingMoment'][JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND1]['jpg']:
     JgUKSlVftXudDBLsWRiFoyYmAbCMkh =JgUKSlVftXudDBLsWRiFoyYmAbCMQN['interestingMoment'][JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LAND1]['jpg']['value']['url']
    JgUKSlVftXudDBLsWRiFoyYmAbCMkN=''
    if 'value' in JgUKSlVftXudDBLsWRiFoyYmAbCMQN['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LOGO]['png']:
     JgUKSlVftXudDBLsWRiFoyYmAbCMkN=JgUKSlVftXudDBLsWRiFoyYmAbCMQN['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][JgUKSlVftXudDBLsWRiFoyYmAbCMOH.ART_SIZE_LOGO]['png']['value']['url']
    JgUKSlVftXudDBLsWRiFoyYmAbCMkc =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_Subid_List(JgUKSlVftXudDBLsWRiFoyYmAbCMQN['genres'])
    for i in JgUKSlVftXudDBLsWRiFoyYmAbCMrj(JgUKSlVftXudDBLsWRiFoyYmAbCMrx(JgUKSlVftXudDBLsWRiFoyYmAbCMkc)):
     JgUKSlVftXudDBLsWRiFoyYmAbCMkc[i]=JgUKSlVftXudDBLsWRiFoyYmAbCMQq[JgUKSlVftXudDBLsWRiFoyYmAbCMkc[i]]['name']['value']
    JgUKSlVftXudDBLsWRiFoyYmAbCMkP=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_Subid_List(JgUKSlVftXudDBLsWRiFoyYmAbCMQN['directors'])
    JgUKSlVftXudDBLsWRiFoyYmAbCMQa =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_Subid_List(JgUKSlVftXudDBLsWRiFoyYmAbCMQN['creators'])
    JgUKSlVftXudDBLsWRiFoyYmAbCMkP.extend(JgUKSlVftXudDBLsWRiFoyYmAbCMQa)
    for i in JgUKSlVftXudDBLsWRiFoyYmAbCMrj(JgUKSlVftXudDBLsWRiFoyYmAbCMrx(JgUKSlVftXudDBLsWRiFoyYmAbCMkP)):
     JgUKSlVftXudDBLsWRiFoyYmAbCMkP[i]=JgUKSlVftXudDBLsWRiFoyYmAbCMQE[JgUKSlVftXudDBLsWRiFoyYmAbCMkP[i]]['name']['value']
    JgUKSlVftXudDBLsWRiFoyYmAbCMkz=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_Subid_List(JgUKSlVftXudDBLsWRiFoyYmAbCMQN['cast'])
    for i in JgUKSlVftXudDBLsWRiFoyYmAbCMrj(JgUKSlVftXudDBLsWRiFoyYmAbCMrx(JgUKSlVftXudDBLsWRiFoyYmAbCMkz)):
     JgUKSlVftXudDBLsWRiFoyYmAbCMkz[i]=JgUKSlVftXudDBLsWRiFoyYmAbCMQE[JgUKSlVftXudDBLsWRiFoyYmAbCMkz[i]]['name']['value']
    if 'maturityDescription' in JgUKSlVftXudDBLsWRiFoyYmAbCMQN['maturity']['value']['rating']:
     JgUKSlVftXudDBLsWRiFoyYmAbCMkI=JgUKSlVftXudDBLsWRiFoyYmAbCMQN['maturity']['value']['rating']['maturityDescription']
    JgUKSlVftXudDBLsWRiFoyYmAbCMOa={'videoid':JgUKSlVftXudDBLsWRiFoyYmAbCMON,'vidtype':JgUKSlVftXudDBLsWRiFoyYmAbCMOp,'title':JgUKSlVftXudDBLsWRiFoyYmAbCMHQ,'mpaa':JgUKSlVftXudDBLsWRiFoyYmAbCMkI,'regularSynopsis':JgUKSlVftXudDBLsWRiFoyYmAbCMQN['regularSynopsis']['value'],'dpSupplemental':JgUKSlVftXudDBLsWRiFoyYmAbCMQN['dpSupplementalMessage']['value'],'sequiturEvidence':JgUKSlVftXudDBLsWRiFoyYmAbCMQj,'thumbnail':{'poster':JgUKSlVftXudDBLsWRiFoyYmAbCMkT,'thumb':JgUKSlVftXudDBLsWRiFoyYmAbCMkh,'fanart':JgUKSlVftXudDBLsWRiFoyYmAbCMQx,'clearlogo':JgUKSlVftXudDBLsWRiFoyYmAbCMkN},'year':JgUKSlVftXudDBLsWRiFoyYmAbCMQN['releaseYear']['value'],'duration':JgUKSlVftXudDBLsWRiFoyYmAbCMkn,'info_genre':JgUKSlVftXudDBLsWRiFoyYmAbCMkc,'director':JgUKSlVftXudDBLsWRiFoyYmAbCMkP,'cast':JgUKSlVftXudDBLsWRiFoyYmAbCMkz,}
    JgUKSlVftXudDBLsWRiFoyYmAbCMOG.append(JgUKSlVftXudDBLsWRiFoyYmAbCMOa)
  return JgUKSlVftXudDBLsWRiFoyYmAbCMOG,JgUKSlVftXudDBLsWRiFoyYmAbCMOh,JgUKSlVftXudDBLsWRiFoyYmAbCMQc
 def NF_Subid_List(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,subJson):
  JgUKSlVftXudDBLsWRiFoyYmAbCMQe=[]
  try:
   for i in JgUKSlVftXudDBLsWRiFoyYmAbCMrj(JgUKSlVftXudDBLsWRiFoyYmAbCMrx(subJson)):
    if subJson.get(JgUKSlVftXudDBLsWRiFoyYmAbCMrc(i)).get('$type')!='ref':break
    JgUKSlVftXudDBLsWRiFoyYmAbCMrO=subJson.get(JgUKSlVftXudDBLsWRiFoyYmAbCMrc(i)).get('value')[1]
    JgUKSlVftXudDBLsWRiFoyYmAbCMQe.append(JgUKSlVftXudDBLsWRiFoyYmAbCMrO)
  except JgUKSlVftXudDBLsWRiFoyYmAbCMrn as exception:
   JgUKSlVftXudDBLsWRiFoyYmAbCMrI(exception)
  return JgUKSlVftXudDBLsWRiFoyYmAbCMQe
 def NF_CookieFile_Load(JgUKSlVftXudDBLsWRiFoyYmAbCMOH,cookie_filename):
  JgUKSlVftXudDBLsWRiFoyYmAbCMQk={}
  try:
   if os.path.isfile(cookie_filename)==JgUKSlVftXudDBLsWRiFoyYmAbCMrz:return{}
   JgUKSlVftXudDBLsWRiFoyYmAbCMrk=JgUKSlVftXudDBLsWRiFoyYmAbCMrE(cookie_filename,'rb',-1)
   JgUKSlVftXudDBLsWRiFoyYmAbCMrH =pickle.loads(JgUKSlVftXudDBLsWRiFoyYmAbCMrk.read())
   JgUKSlVftXudDBLsWRiFoyYmAbCMrk.close()
   for JgUKSlVftXudDBLsWRiFoyYmAbCMrQ in JgUKSlVftXudDBLsWRiFoyYmAbCMrH:
    JgUKSlVftXudDBLsWRiFoyYmAbCMQk[JgUKSlVftXudDBLsWRiFoyYmAbCMrQ.name]=JgUKSlVftXudDBLsWRiFoyYmAbCMrQ.value
  except:
   JgUKSlVftXudDBLsWRiFoyYmAbCMrI(exception) 
  return JgUKSlVftXudDBLsWRiFoyYmAbCMQk
 def NF_Get_DefaultCookies(JgUKSlVftXudDBLsWRiFoyYmAbCMOH):
  JgUKSlVftXudDBLsWRiFoyYmAbCMQk={}
  if JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['flwssn'] :JgUKSlVftXudDBLsWRiFoyYmAbCMQk['flwssn'] =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['flwssn']
  if JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['nfvdid'] :JgUKSlVftXudDBLsWRiFoyYmAbCMQk['nfvdid'] =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['nfvdid']
  if JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['SecureNetflixId']:JgUKSlVftXudDBLsWRiFoyYmAbCMQk['SecureNetflixId']=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['SecureNetflixId']
  if JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['NetflixId'] :JgUKSlVftXudDBLsWRiFoyYmAbCMQk['NetflixId'] =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['NetflixId']
  if JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['memclid'] :JgUKSlVftXudDBLsWRiFoyYmAbCMQk['memclid'] =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['memclid']
  if JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['clSharedContext']:JgUKSlVftXudDBLsWRiFoyYmAbCMQk['clSharedContext']=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['COOKIES']['clSharedContext']
  return JgUKSlVftXudDBLsWRiFoyYmAbCMQk
 def NF_Get_BaseSession(JgUKSlVftXudDBLsWRiFoyYmAbCMOH):
  try:
   JgUKSlVftXudDBLsWRiFoyYmAbCMOz=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.API_NETFLIX+'/browse' 
   JgUKSlVftXudDBLsWRiFoyYmAbCMQk=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_Get_DefaultCookies()
   JgUKSlVftXudDBLsWRiFoyYmAbCMOc=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.callRequestCookies('Get',JgUKSlVftXudDBLsWRiFoyYmAbCMOz,payload=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,params=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,headers=JgUKSlVftXudDBLsWRiFoyYmAbCMrh,cookies=JgUKSlVftXudDBLsWRiFoyYmAbCMQk)
   if JgUKSlVftXudDBLsWRiFoyYmAbCMOc.status_code!=200:
    JgUKSlVftXudDBLsWRiFoyYmAbCMrI('pass 1 status_code error')
    return JgUKSlVftXudDBLsWRiFoyYmAbCMrz
   JgUKSlVftXudDBLsWRiFoyYmAbCMrw =JgUKSlVftXudDBLsWRiFoyYmAbCMOH.extract_json(JgUKSlVftXudDBLsWRiFoyYmAbCMOc.text,'reactContext')
   JgUKSlVftXudDBLsWRiFoyYmAbCMrG=JgUKSlVftXudDBLsWRiFoyYmAbCMOH.extract_json(JgUKSlVftXudDBLsWRiFoyYmAbCMOc.text,'falcorCache')
   JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF['SESSION']={'mainGuid':JgUKSlVftXudDBLsWRiFoyYmAbCMrw['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':JgUKSlVftXudDBLsWRiFoyYmAbCMrw['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':JgUKSlVftXudDBLsWRiFoyYmAbCMrw['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':JgUKSlVftXudDBLsWRiFoyYmAbCMrw['models']['memberContext']['data']['userInfo']['esn'],'identifier':JgUKSlVftXudDBLsWRiFoyYmAbCMrw['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':JgUKSlVftXudDBLsWRiFoyYmAbCMrw['models']['abContext']['data']['headers'],}
   JgUKSlVftXudDBLsWRiFoyYmAbCMOH.dic_To_jsonfile(JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF_SESSION_COOKIES1,JgUKSlVftXudDBLsWRiFoyYmAbCMOH.NF)
  except JgUKSlVftXudDBLsWRiFoyYmAbCMrn as exception:
   JgUKSlVftXudDBLsWRiFoyYmAbCMrI('pass 1 error')
   JgUKSlVftXudDBLsWRiFoyYmAbCMrI(exception)
   return JgUKSlVftXudDBLsWRiFoyYmAbCMrz
  return JgUKSlVftXudDBLsWRiFoyYmAbCMrv
# Created by pyminifier (https://github.com/liftoff/pyminifier)
