__author__="NightRain"
urltVnSsHLIQTgNkDFGfdxeKAjJcma=object
urltVnSsHLIQTgNkDFGfdxeKAjJcmh=None
urltVnSsHLIQTgNkDFGfdxeKAjJcmp=False
urltVnSsHLIQTgNkDFGfdxeKAjJcmy=print
urltVnSsHLIQTgNkDFGfdxeKAjJcmw=str
urltVnSsHLIQTgNkDFGfdxeKAjJcvW=int
urltVnSsHLIQTgNkDFGfdxeKAjJcvb=Exception
urltVnSsHLIQTgNkDFGfdxeKAjJcvX=True
urltVnSsHLIQTgNkDFGfdxeKAjJcvR=open
urltVnSsHLIQTgNkDFGfdxeKAjJcvm=isinstance
urltVnSsHLIQTgNkDFGfdxeKAjJcvP=list
urltVnSsHLIQTgNkDFGfdxeKAjJcvo=dict
urltVnSsHLIQTgNkDFGfdxeKAjJcvz=range
urltVnSsHLIQTgNkDFGfdxeKAjJcvU=len
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class urltVnSsHLIQTgNkDFGfdxeKAjJcWb(urltVnSsHLIQTgNkDFGfdxeKAjJcma):
 def __init__(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36'
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.DEFAULT_HEADER ={'user-agent':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.USER_AGENT}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_WAVVE ='https://apis.wavve.com'
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_TVING_SEARCH='https://search.tving.com'
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_TVING_IMG ='https://image.tving.com'
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_WATCHA ='https://api-mars.watcha.com'
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX ='https://www.netflix.com'
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.WAVVE_LIMIT =20 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.TVING_LIMIT =30
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.WATCHA_LIMIT =30
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_LIMIT =20 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.DERECTOR_LIMIT =4
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.CAST_LIMIT =10
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.GENRE_LIMIT =4
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.TVING_MOVIE_LITE=['2610061','2610161','261062']
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_HEADER={'user-agent':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND1 ='_342x192'
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND2 ='_665x375'
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_PORT ='_342x684'
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LOGO ='_550x124'
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF={}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']={}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']={}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.Init_NF_Cookies()
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.Init_NF_Session()
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_COOKIES1 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_COOKIES2 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_COOKIES3 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_COOKIES4 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_FULLTEXT1 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_FULLTEXT2 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_FULLTEXT3 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_FULLTEXT4 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_CONTEXTJSON_FILE1 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_CONTEXTJSON_FILE2 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_CONTEXTJSON_FILE3 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_CONTEXTJSON_FILE4 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_FALCORJSON_FILE1 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_FALCORJSON_FILE2 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_FALCORJSON_FILE3 =''
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_FALCORJSON_FILE4 =''
 def callRequestCookies(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,jobtype,urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,params=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,redirects=urltVnSsHLIQTgNkDFGfdxeKAjJcmp):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWR=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.DEFAULT_HEADER
  if headers:urltVnSsHLIQTgNkDFGfdxeKAjJcWR.update(headers)
  if jobtype=='Get':
   urltVnSsHLIQTgNkDFGfdxeKAjJcWm=requests.get(urltVnSsHLIQTgNkDFGfdxeKAjJcWC,params=params,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcWR,cookies=cookies,allow_redirects=redirects)
  else:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWm=requests.post(urltVnSsHLIQTgNkDFGfdxeKAjJcWC,data=payload,params=params,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcWR,cookies=cookies,allow_redirects=redirects)
  return urltVnSsHLIQTgNkDFGfdxeKAjJcWm
 def callRequestCookies_NF(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,jobtype,urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,params=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,redirects=urltVnSsHLIQTgNkDFGfdxeKAjJcmp,addCookie=''):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWR=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_HEADER
  if headers:urltVnSsHLIQTgNkDFGfdxeKAjJcWR.update(headers)
  if jobtype=='Get':
   urltVnSsHLIQTgNkDFGfdxeKAjJcWm=requests.get(urltVnSsHLIQTgNkDFGfdxeKAjJcWC,params=params,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcWR,cookies=cookies,allow_redirects=redirects)
  else:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWm=requests.post(urltVnSsHLIQTgNkDFGfdxeKAjJcWC,data=payload,params=params,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcWR,cookies=cookies,allow_redirects=redirects)
  urltVnSsHLIQTgNkDFGfdxeKAjJcmy(urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcWm.status_code)+' - '+urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcWm.url))
  '''
  print(res.url )
  print(res.status_code )
  print(res.cookies )
  print(res.text )
  '''  
  try:
   if addCookie=='baseurl':
    if 'location' in urltVnSsHLIQTgNkDFGfdxeKAjJcWm.headers:
     urltVnSsHLIQTgNkDFGfdxeKAjJcWv=urllib.parse.urlsplit(urltVnSsHLIQTgNkDFGfdxeKAjJcWm.headers.get('location')).path
     urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['contryurl']=urltVnSsHLIQTgNkDFGfdxeKAjJcWv[1:3]
  except:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmh
  for urltVnSsHLIQTgNkDFGfdxeKAjJcWP in urltVnSsHLIQTgNkDFGfdxeKAjJcWm.cookies:
   if urltVnSsHLIQTgNkDFGfdxeKAjJcWP.name=='flwssn':
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['flwssn']['value'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWP.value
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['flwssn']['expires'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWP.expires
   elif urltVnSsHLIQTgNkDFGfdxeKAjJcWP.name=='nfvdid':
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['nfvdid']['value'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWP.value
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['nfvdid']['expires'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWP.expires
   elif urltVnSsHLIQTgNkDFGfdxeKAjJcWP.name=='SecureNetflixId':
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['SecureNetflixId']['value'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWP.value
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['SecureNetflixId']['expires'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWP.expires
   elif urltVnSsHLIQTgNkDFGfdxeKAjJcWP.name=='NetflixId':
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['NetflixId']['value'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWP.value
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['NetflixId']['expires'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWP.expires
   elif urltVnSsHLIQTgNkDFGfdxeKAjJcWP.name=='memclid':
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['memclid']['value'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWP.value
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['memclid']['expires'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWP.expires
   elif urltVnSsHLIQTgNkDFGfdxeKAjJcWP.name=='clSharedContext':
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['clSharedContext']['value'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWP.value
    urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['clSharedContext']['expires'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.GetNoCache(timetype=1,minutes=5)
  return urltVnSsHLIQTgNkDFGfdxeKAjJcWm
 def GetNoCache(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,timetype=1,minutes=0):
  if timetype==1:
   ts=urltVnSsHLIQTgNkDFGfdxeKAjJcvW(time.time())
   mi=urltVnSsHLIQTgNkDFGfdxeKAjJcvW(minutes*60)
  else:
   ts=urltVnSsHLIQTgNkDFGfdxeKAjJcvW(time.time()*1000)
   mi=urltVnSsHLIQTgNkDFGfdxeKAjJcvW(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,search_key,sType,page_int):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWz=[]
  urltVnSsHLIQTgNkDFGfdxeKAjJcWU=urltVnSsHLIQTgNkDFGfdxeKAjJcbX=1
  urltVnSsHLIQTgNkDFGfdxeKAjJcWY=urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_WAVVE+'/cf/search/list.js'
   urltVnSsHLIQTgNkDFGfdxeKAjJcWi={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':urltVnSsHLIQTgNkDFGfdxeKAjJcmw((page_int-1)*urltVnSsHLIQTgNkDFGfdxeKAjJcWX.WAVVE_LIMIT),'limit':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.WAVVE_LIMIT,'orderby':'score'}
   urltVnSsHLIQTgNkDFGfdxeKAjJcWi.update(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.WAVVE_PARAMS)
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.callRequestCookies('Get',urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,params=urltVnSsHLIQTgNkDFGfdxeKAjJcWi,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcmh)
   urltVnSsHLIQTgNkDFGfdxeKAjJcWq=json.loads(urltVnSsHLIQTgNkDFGfdxeKAjJcWM.text)
   if not('celllist' in urltVnSsHLIQTgNkDFGfdxeKAjJcWq['cell_toplist']):return urltVnSsHLIQTgNkDFGfdxeKAjJcWz,urltVnSsHLIQTgNkDFGfdxeKAjJcWY
   urltVnSsHLIQTgNkDFGfdxeKAjJcWE=urltVnSsHLIQTgNkDFGfdxeKAjJcWq['cell_toplist']['celllist']
   for urltVnSsHLIQTgNkDFGfdxeKAjJcWB in urltVnSsHLIQTgNkDFGfdxeKAjJcWE:
    urltVnSsHLIQTgNkDFGfdxeKAjJcWO =urltVnSsHLIQTgNkDFGfdxeKAjJcWB['event_list'][1]['url']
    urltVnSsHLIQTgNkDFGfdxeKAjJcWa=urllib.parse.urlsplit(urltVnSsHLIQTgNkDFGfdxeKAjJcWO).query
    urltVnSsHLIQTgNkDFGfdxeKAjJcWh=urltVnSsHLIQTgNkDFGfdxeKAjJcWa[0:urltVnSsHLIQTgNkDFGfdxeKAjJcWa.find('=')]
    urltVnSsHLIQTgNkDFGfdxeKAjJcWp=urltVnSsHLIQTgNkDFGfdxeKAjJcWa[urltVnSsHLIQTgNkDFGfdxeKAjJcWa.find('=')+1:]
    urltVnSsHLIQTgNkDFGfdxeKAjJcWh='TVSHOW' if urltVnSsHLIQTgNkDFGfdxeKAjJcWh=='programid' else 'MOVIE' 
    urltVnSsHLIQTgNkDFGfdxeKAjJcWy=urltVnSsHLIQTgNkDFGfdxeKAjJcWB['title_list'][0]['text']
    urltVnSsHLIQTgNkDFGfdxeKAjJcWw =urltVnSsHLIQTgNkDFGfdxeKAjJcWB['age']
    urltVnSsHLIQTgNkDFGfdxeKAjJcbW={'title':urltVnSsHLIQTgNkDFGfdxeKAjJcWy}
    if urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('age')!='21':
     urltVnSsHLIQTgNkDFGfdxeKAjJcWz.append(urltVnSsHLIQTgNkDFGfdxeKAjJcbW)
   urltVnSsHLIQTgNkDFGfdxeKAjJcWU=urltVnSsHLIQTgNkDFGfdxeKAjJcvW(urltVnSsHLIQTgNkDFGfdxeKAjJcWq['cell_toplist']['pagecount'])
   if urltVnSsHLIQTgNkDFGfdxeKAjJcWq['cell_toplist']['count']:urltVnSsHLIQTgNkDFGfdxeKAjJcbX =urltVnSsHLIQTgNkDFGfdxeKAjJcvW(urltVnSsHLIQTgNkDFGfdxeKAjJcWq['cell_toplist']['count'])
   else:urltVnSsHLIQTgNkDFGfdxeKAjJcbX=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.LIST_LIMIT
   urltVnSsHLIQTgNkDFGfdxeKAjJcWY=urltVnSsHLIQTgNkDFGfdxeKAjJcWU>urltVnSsHLIQTgNkDFGfdxeKAjJcbX
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
  return urltVnSsHLIQTgNkDFGfdxeKAjJcWz,urltVnSsHLIQTgNkDFGfdxeKAjJcWY 
 def Get_Search_Tving(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,search_key,sType,page_int):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWz=[]
  urltVnSsHLIQTgNkDFGfdxeKAjJcWY=urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcbR ='/search/getSearch.jsp'
   urltVnSsHLIQTgNkDFGfdxeKAjJcbm={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':urltVnSsHLIQTgNkDFGfdxeKAjJcmw(page_int),'pageSize':urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.TVING_PARMAS.get('SCREENCODE'),'os':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.TVING_PARMAS.get('OSCODE'),'network':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.GetNoCache(2))}
   urltVnSsHLIQTgNkDFGfdxeKAjJcWC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_TVING_SEARCH+urltVnSsHLIQTgNkDFGfdxeKAjJcbR
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.callRequestCookies('Get',urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,params=urltVnSsHLIQTgNkDFGfdxeKAjJcbm,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcmh)
   urltVnSsHLIQTgNkDFGfdxeKAjJcbv=json.loads(urltVnSsHLIQTgNkDFGfdxeKAjJcWM.text)
   if sType=='TVSHOW':
    if not('programRsb' in urltVnSsHLIQTgNkDFGfdxeKAjJcbv):return urltVnSsHLIQTgNkDFGfdxeKAjJcWz,urltVnSsHLIQTgNkDFGfdxeKAjJcWY
    urltVnSsHLIQTgNkDFGfdxeKAjJcbP=urltVnSsHLIQTgNkDFGfdxeKAjJcbv['programRsb']['dataList']
    urltVnSsHLIQTgNkDFGfdxeKAjJcbo =urltVnSsHLIQTgNkDFGfdxeKAjJcvW(urltVnSsHLIQTgNkDFGfdxeKAjJcbv['programRsb']['count'])
    for urltVnSsHLIQTgNkDFGfdxeKAjJcWB in urltVnSsHLIQTgNkDFGfdxeKAjJcbP:
     urltVnSsHLIQTgNkDFGfdxeKAjJcbz=urltVnSsHLIQTgNkDFGfdxeKAjJcWB['mast_cd']
     urltVnSsHLIQTgNkDFGfdxeKAjJcWy =urltVnSsHLIQTgNkDFGfdxeKAjJcWB['mast_nm']
     urltVnSsHLIQTgNkDFGfdxeKAjJcbU=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_TVING_IMG+urltVnSsHLIQTgNkDFGfdxeKAjJcWB['web_url4']
     urltVnSsHLIQTgNkDFGfdxeKAjJcbY =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_TVING_IMG+urltVnSsHLIQTgNkDFGfdxeKAjJcWB['web_url']
     try:
      urltVnSsHLIQTgNkDFGfdxeKAjJcbC =[]
      urltVnSsHLIQTgNkDFGfdxeKAjJcbi=[]
      urltVnSsHLIQTgNkDFGfdxeKAjJcbM =[]
      urltVnSsHLIQTgNkDFGfdxeKAjJcbq =0
      urltVnSsHLIQTgNkDFGfdxeKAjJcbE =''
      urltVnSsHLIQTgNkDFGfdxeKAjJcbB =''
      urltVnSsHLIQTgNkDFGfdxeKAjJcbO =''
      if urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('actor') !='' and urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('actor') !='-':urltVnSsHLIQTgNkDFGfdxeKAjJcbC =urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('actor').split(',')
      if urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('director')!='' and urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('director')!='-':urltVnSsHLIQTgNkDFGfdxeKAjJcbi=urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('director').split(',')
      if urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('cate_nm')!='' and urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('cate_nm')!='-':urltVnSsHLIQTgNkDFGfdxeKAjJcbM =urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('cate_nm').split('/')
      if 'targetage' in urltVnSsHLIQTgNkDFGfdxeKAjJcWB:urltVnSsHLIQTgNkDFGfdxeKAjJcbE=urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('targetage')
      if 'broad_dt' in urltVnSsHLIQTgNkDFGfdxeKAjJcWB:
       urltVnSsHLIQTgNkDFGfdxeKAjJcba=urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('broad_dt')
       urltVnSsHLIQTgNkDFGfdxeKAjJcbO='%s-%s-%s'%(urltVnSsHLIQTgNkDFGfdxeKAjJcba[:4],urltVnSsHLIQTgNkDFGfdxeKAjJcba[4:6],urltVnSsHLIQTgNkDFGfdxeKAjJcba[6:])
       urltVnSsHLIQTgNkDFGfdxeKAjJcbB =urltVnSsHLIQTgNkDFGfdxeKAjJcba[:4]
     except:
      urltVnSsHLIQTgNkDFGfdxeKAjJcmh
     urltVnSsHLIQTgNkDFGfdxeKAjJcbW={'title':urltVnSsHLIQTgNkDFGfdxeKAjJcWy,}
     urltVnSsHLIQTgNkDFGfdxeKAjJcWz.append(urltVnSsHLIQTgNkDFGfdxeKAjJcbW)
   else:
    if not('vodMVRsb' in urltVnSsHLIQTgNkDFGfdxeKAjJcbv):return urltVnSsHLIQTgNkDFGfdxeKAjJcWz,urltVnSsHLIQTgNkDFGfdxeKAjJcWY
    urltVnSsHLIQTgNkDFGfdxeKAjJcbh=urltVnSsHLIQTgNkDFGfdxeKAjJcbv['vodMVRsb']['dataList']
    urltVnSsHLIQTgNkDFGfdxeKAjJcbo =urltVnSsHLIQTgNkDFGfdxeKAjJcvW(urltVnSsHLIQTgNkDFGfdxeKAjJcbv['vodMVRsb']['count'])
    urltVnSsHLIQTgNkDFGfdxeKAjJcmy(urltVnSsHLIQTgNkDFGfdxeKAjJcbo)
    for urltVnSsHLIQTgNkDFGfdxeKAjJcWB in urltVnSsHLIQTgNkDFGfdxeKAjJcbh:
     urltVnSsHLIQTgNkDFGfdxeKAjJcbz=urltVnSsHLIQTgNkDFGfdxeKAjJcWB['mast_cd']
     urltVnSsHLIQTgNkDFGfdxeKAjJcWy =urltVnSsHLIQTgNkDFGfdxeKAjJcWB['mast_nm'].strip()
     urltVnSsHLIQTgNkDFGfdxeKAjJcbU =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_TVING_IMG+urltVnSsHLIQTgNkDFGfdxeKAjJcWB['web_url']
     urltVnSsHLIQTgNkDFGfdxeKAjJcbY =urltVnSsHLIQTgNkDFGfdxeKAjJcbU
     urltVnSsHLIQTgNkDFGfdxeKAjJcbp=''
     try:
      urltVnSsHLIQTgNkDFGfdxeKAjJcbC =[]
      urltVnSsHLIQTgNkDFGfdxeKAjJcbi=[]
      urltVnSsHLIQTgNkDFGfdxeKAjJcbM =[]
      urltVnSsHLIQTgNkDFGfdxeKAjJcbq =0
      urltVnSsHLIQTgNkDFGfdxeKAjJcbE =''
      urltVnSsHLIQTgNkDFGfdxeKAjJcbB =''
      urltVnSsHLIQTgNkDFGfdxeKAjJcbO =''
      if urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('actor') !='' and urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('actor') !='-':urltVnSsHLIQTgNkDFGfdxeKAjJcbC =urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('actor').split(',')
      if urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('director')!='' and urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('director')!='-':urltVnSsHLIQTgNkDFGfdxeKAjJcbi=urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('director').split(',')
      if urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('cate_nm')!='' and urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('cate_nm')!='-':urltVnSsHLIQTgNkDFGfdxeKAjJcbM =urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('cate_nm').split('/')
      if urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('runtime_sec')!='':urltVnSsHLIQTgNkDFGfdxeKAjJcbq=urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('runtime_sec')
      if 'grade_nm' in urltVnSsHLIQTgNkDFGfdxeKAjJcWB:urltVnSsHLIQTgNkDFGfdxeKAjJcbE=urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('grade_nm')
      urltVnSsHLIQTgNkDFGfdxeKAjJcby=''
      urltVnSsHLIQTgNkDFGfdxeKAjJcba=urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('broad_dt')
      if urltVnSsHLIQTgNkDFGfdxeKAjJcby!='':
       urltVnSsHLIQTgNkDFGfdxeKAjJcbO='%s-%s-%s'%(urltVnSsHLIQTgNkDFGfdxeKAjJcba[:4],urltVnSsHLIQTgNkDFGfdxeKAjJcba[4:6],urltVnSsHLIQTgNkDFGfdxeKAjJcba[6:])
       urltVnSsHLIQTgNkDFGfdxeKAjJcbB =urltVnSsHLIQTgNkDFGfdxeKAjJcba[:4]
     except:
      urltVnSsHLIQTgNkDFGfdxeKAjJcmh
     urltVnSsHLIQTgNkDFGfdxeKAjJcbW={'title':urltVnSsHLIQTgNkDFGfdxeKAjJcWy,}
     urltVnSsHLIQTgNkDFGfdxeKAjJcbw=urltVnSsHLIQTgNkDFGfdxeKAjJcmp
     for urltVnSsHLIQTgNkDFGfdxeKAjJcXW in urltVnSsHLIQTgNkDFGfdxeKAjJcWB['bill']:
      if urltVnSsHLIQTgNkDFGfdxeKAjJcXW in urltVnSsHLIQTgNkDFGfdxeKAjJcWX.TVING_MOVIE_LITE:
       urltVnSsHLIQTgNkDFGfdxeKAjJcbw=urltVnSsHLIQTgNkDFGfdxeKAjJcvX
       break
     if urltVnSsHLIQTgNkDFGfdxeKAjJcbw==urltVnSsHLIQTgNkDFGfdxeKAjJcmp: 
      urltVnSsHLIQTgNkDFGfdxeKAjJcbW['title']=urltVnSsHLIQTgNkDFGfdxeKAjJcbW['title']+' [개별구매]'
     urltVnSsHLIQTgNkDFGfdxeKAjJcWz.append(urltVnSsHLIQTgNkDFGfdxeKAjJcbW)
   if urltVnSsHLIQTgNkDFGfdxeKAjJcbo>(page_int*urltVnSsHLIQTgNkDFGfdxeKAjJcWX.TVING_LIMIT):urltVnSsHLIQTgNkDFGfdxeKAjJcWY=urltVnSsHLIQTgNkDFGfdxeKAjJcvX
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
  return urltVnSsHLIQTgNkDFGfdxeKAjJcWz,urltVnSsHLIQTgNkDFGfdxeKAjJcWY
 def Get_Search_Watcha(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,search_key,page_int):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWz=[]
  urltVnSsHLIQTgNkDFGfdxeKAjJcWY=urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_WATCHA+'/api/search.json'
   urltVnSsHLIQTgNkDFGfdxeKAjJcbm={'query':search_key,'page':urltVnSsHLIQTgNkDFGfdxeKAjJcmw(page_int),'per':urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.WATCHA_LIMIT),'exclude':'limited',}
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.callRequestCookies('Get',urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,params=urltVnSsHLIQTgNkDFGfdxeKAjJcbm,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.WATCHA_HEADER,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcmh)
   urltVnSsHLIQTgNkDFGfdxeKAjJcbv=json.loads(urltVnSsHLIQTgNkDFGfdxeKAjJcWM.text)
   if not('results' in urltVnSsHLIQTgNkDFGfdxeKAjJcbv):return urltVnSsHLIQTgNkDFGfdxeKAjJcWz,urltVnSsHLIQTgNkDFGfdxeKAjJcWY
   urltVnSsHLIQTgNkDFGfdxeKAjJcXb=urltVnSsHLIQTgNkDFGfdxeKAjJcbv['results']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWY=urltVnSsHLIQTgNkDFGfdxeKAjJcbv['meta']['has_next']
   for urltVnSsHLIQTgNkDFGfdxeKAjJcWB in urltVnSsHLIQTgNkDFGfdxeKAjJcXb:
    urltVnSsHLIQTgNkDFGfdxeKAjJcXR =urltVnSsHLIQTgNkDFGfdxeKAjJcWB['code']
    urltVnSsHLIQTgNkDFGfdxeKAjJcXm=urltVnSsHLIQTgNkDFGfdxeKAjJcWB['content_type']
    urltVnSsHLIQTgNkDFGfdxeKAjJcXv =urltVnSsHLIQTgNkDFGfdxeKAjJcWB['title']
    urltVnSsHLIQTgNkDFGfdxeKAjJcXP =urltVnSsHLIQTgNkDFGfdxeKAjJcWB['story']
    urltVnSsHLIQTgNkDFGfdxeKAjJcbU=urltVnSsHLIQTgNkDFGfdxeKAjJcbY=urltVnSsHLIQTgNkDFGfdxeKAjJcmq=''
    if urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('poster') !=urltVnSsHLIQTgNkDFGfdxeKAjJcmh:urltVnSsHLIQTgNkDFGfdxeKAjJcbU=urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('poster').get('original')
    if urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('stillcut')!=urltVnSsHLIQTgNkDFGfdxeKAjJcmh:urltVnSsHLIQTgNkDFGfdxeKAjJcbY =urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('stillcut').get('large')
    if urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('thumbnail')!=urltVnSsHLIQTgNkDFGfdxeKAjJcmh:urltVnSsHLIQTgNkDFGfdxeKAjJcmq=urltVnSsHLIQTgNkDFGfdxeKAjJcWB.get('thumbnail').get('large')
    if urltVnSsHLIQTgNkDFGfdxeKAjJcmq=='' :urltVnSsHLIQTgNkDFGfdxeKAjJcmq=urltVnSsHLIQTgNkDFGfdxeKAjJcbY
    urltVnSsHLIQTgNkDFGfdxeKAjJcXo={'thumb':urltVnSsHLIQTgNkDFGfdxeKAjJcbY,'poster':urltVnSsHLIQTgNkDFGfdxeKAjJcbU,'fanart':urltVnSsHLIQTgNkDFGfdxeKAjJcmq}
    urltVnSsHLIQTgNkDFGfdxeKAjJcbB =urltVnSsHLIQTgNkDFGfdxeKAjJcWB['year']
    urltVnSsHLIQTgNkDFGfdxeKAjJcXz =urltVnSsHLIQTgNkDFGfdxeKAjJcWB['film_rating_code']
    urltVnSsHLIQTgNkDFGfdxeKAjJcXU=urltVnSsHLIQTgNkDFGfdxeKAjJcWB['film_rating_short']
    urltVnSsHLIQTgNkDFGfdxeKAjJcXY =urltVnSsHLIQTgNkDFGfdxeKAjJcWB['film_rating_long']
    if urltVnSsHLIQTgNkDFGfdxeKAjJcXm=='movies':
     urltVnSsHLIQTgNkDFGfdxeKAjJcbq =urltVnSsHLIQTgNkDFGfdxeKAjJcWB['duration']
    else:
     urltVnSsHLIQTgNkDFGfdxeKAjJcbq ='0'
    urltVnSsHLIQTgNkDFGfdxeKAjJcbW={'title':urltVnSsHLIQTgNkDFGfdxeKAjJcXv,}
    urltVnSsHLIQTgNkDFGfdxeKAjJcWz.append(urltVnSsHLIQTgNkDFGfdxeKAjJcbW)
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
  return urltVnSsHLIQTgNkDFGfdxeKAjJcWz,urltVnSsHLIQTgNkDFGfdxeKAjJcWY
 def dic_To_jsonfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,filename,urltVnSsHLIQTgNkDFGfdxeKAjJcXC):
  if filename=='':return
  fp=urltVnSsHLIQTgNkDFGfdxeKAjJcvR(filename,'w',-1,'utf-8')
  json.dump(urltVnSsHLIQTgNkDFGfdxeKAjJcXC,fp,indent=4,ensure_ascii=urltVnSsHLIQTgNkDFGfdxeKAjJcmp)
  fp.close()
 def jsonfile_To_dic(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,filename):
  if filename=='':return urltVnSsHLIQTgNkDFGfdxeKAjJcmh
  try:
   fp=urltVnSsHLIQTgNkDFGfdxeKAjJcvR(filename,'r',-1,'utf-8')
   urltVnSsHLIQTgNkDFGfdxeKAjJcXM=json.load(fp)
   fp.close()
  except:
   urltVnSsHLIQTgNkDFGfdxeKAjJcXM={}
  return urltVnSsHLIQTgNkDFGfdxeKAjJcXM
 def tempFileSave(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,filename,resText):
  if filename=='':return
  fp=urltVnSsHLIQTgNkDFGfdxeKAjJcvR(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,filename):
  if filename=='':return
  try:
   fp=urltVnSsHLIQTgNkDFGfdxeKAjJcvR(filename,'r',-1,'utf-8')
   urltVnSsHLIQTgNkDFGfdxeKAjJcXM=fp.read()
   fp.close()
  except:
   urltVnSsHLIQTgNkDFGfdxeKAjJcXM=''
  return urltVnSsHLIQTgNkDFGfdxeKAjJcXM
 def Init_NF_Total(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF={}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']={}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']={}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.Init_NF_Cookies()
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.Init_NF_Session()
 def Init_NF_Cookies(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['lhpuuidh'] ={'keyname':'','value':'','expires':0}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['lhpuuidhT'] ={'keyname':'','value':'','expires':0}
 def Check_NF_CookieExp(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  urltVnSsHLIQTgNkDFGfdxeKAjJcXq=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.GetNoCache(timetype=1,minutes=0)
  if urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['flwssn']['expires'] <=urltVnSsHLIQTgNkDFGfdxeKAjJcXq:urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  if urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['nfvdid']['expires'] <=urltVnSsHLIQTgNkDFGfdxeKAjJcXq:urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  if urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['SecureNetflixId']['expires']<=urltVnSsHLIQTgNkDFGfdxeKAjJcXq:urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  if urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['NetflixId']['expires'] <=urltVnSsHLIQTgNkDFGfdxeKAjJcXq:urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  if urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['memclid']['expires'] <=urltVnSsHLIQTgNkDFGfdxeKAjJcXq:urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  if urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['clSharedContext']['expires']<=urltVnSsHLIQTgNkDFGfdxeKAjJcXq:urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
 def Init_NF_Session(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['account'] ={'nfid':'','nfpw':'','nfpfnum':0}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['membershipStatus']='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['esnModel'] ='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['username'] ='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['authURL'] ='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['mainGuid'] ='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['nowGuid'] ='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['abContext'] ='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['identifier'] ='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['contryurl'] ='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['countryCode'] ='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['countryIsoCode'] ='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['loco'] ='' 
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['limitdate'] =''
 def make_NF_DefaultCookies(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  urltVnSsHLIQTgNkDFGfdxeKAjJcXE={}
  if urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['flwssn']['value'] :urltVnSsHLIQTgNkDFGfdxeKAjJcXE['flwssn'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['flwssn']['value']
  if urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['nfvdid']['value'] :urltVnSsHLIQTgNkDFGfdxeKAjJcXE['nfvdid'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['nfvdid']['value']
  if urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['SecureNetflixId']['value']:urltVnSsHLIQTgNkDFGfdxeKAjJcXE['SecureNetflixId']=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['SecureNetflixId']['value']
  if urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['NetflixId']['value'] :urltVnSsHLIQTgNkDFGfdxeKAjJcXE['NetflixId'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['NetflixId']['value']
  if urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['memclid']['value'] :urltVnSsHLIQTgNkDFGfdxeKAjJcXE['memclid'] =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['memclid']['value']
  return urltVnSsHLIQTgNkDFGfdxeKAjJcXE
 def make_NF_XnetflixHeaders(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  urltVnSsHLIQTgNkDFGfdxeKAjJcXB={'x-netflix.browsername':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['esnModel'],'x-netflix.esnprefix':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['nowGuid'],'x-netflix.uiversion':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return urltVnSsHLIQTgNkDFGfdxeKAjJcXB
 def make_NF_ApiParams(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWi={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['identifier']),}
  return urltVnSsHLIQTgNkDFGfdxeKAjJcWi
 def extract_json(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,content,name):
  urltVnSsHLIQTgNkDFGfdxeKAjJcXO=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  urltVnSsHLIQTgNkDFGfdxeKAjJcXa=urltVnSsHLIQTgNkDFGfdxeKAjJcmh
  urltVnSsHLIQTgNkDFGfdxeKAjJcXh=re.compile(urltVnSsHLIQTgNkDFGfdxeKAjJcXO.format(name),re.DOTALL).findall(content)
  urltVnSsHLIQTgNkDFGfdxeKAjJcXa=urltVnSsHLIQTgNkDFGfdxeKAjJcXh[0]
  urltVnSsHLIQTgNkDFGfdxeKAjJcXp=urltVnSsHLIQTgNkDFGfdxeKAjJcXa.replace('\\"','\\\\"') 
  urltVnSsHLIQTgNkDFGfdxeKAjJcXp=urltVnSsHLIQTgNkDFGfdxeKAjJcXp.replace('\\s','\\\\s') 
  urltVnSsHLIQTgNkDFGfdxeKAjJcXp=urltVnSsHLIQTgNkDFGfdxeKAjJcXp.replace('\\n','\\\\n') 
  urltVnSsHLIQTgNkDFGfdxeKAjJcXp=urltVnSsHLIQTgNkDFGfdxeKAjJcXp.replace('\\t','\\\\t') 
  urltVnSsHLIQTgNkDFGfdxeKAjJcXp=urltVnSsHLIQTgNkDFGfdxeKAjJcXp.encode().decode('unicode_escape') 
  urltVnSsHLIQTgNkDFGfdxeKAjJcXp=re.sub(r'\\(?!["])',r'\\\\',urltVnSsHLIQTgNkDFGfdxeKAjJcXp) 
  return json.loads(urltVnSsHLIQTgNkDFGfdxeKAjJcXp)
 def Save_session_acount(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,urltVnSsHLIQTgNkDFGfdxeKAjJcXy,urltVnSsHLIQTgNkDFGfdxeKAjJcXw,urltVnSsHLIQTgNkDFGfdxeKAjJcRW):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['account']['nfid'] =base64.standard_b64encode(urltVnSsHLIQTgNkDFGfdxeKAjJcXy.encode()).decode('utf-8')
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['account']['nfpw'] =base64.standard_b64encode(urltVnSsHLIQTgNkDFGfdxeKAjJcXw.encode()).decode('utf-8')
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['account']['nfpfnum']=urltVnSsHLIQTgNkDFGfdxeKAjJcRW
 def Load_session_acount(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  urltVnSsHLIQTgNkDFGfdxeKAjJcXy =base64.standard_b64decode(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['account']['nfid']).decode('utf-8')
  urltVnSsHLIQTgNkDFGfdxeKAjJcXw =base64.standard_b64decode(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['account']['nfpw']).decode('utf-8')
  urltVnSsHLIQTgNkDFGfdxeKAjJcRW=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['account']['nfpfnum']
  return urltVnSsHLIQTgNkDFGfdxeKAjJcXy,urltVnSsHLIQTgNkDFGfdxeKAjJcXw,urltVnSsHLIQTgNkDFGfdxeKAjJcRW
 def Get_NF_BaseCookies(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX+'/login' 
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.callRequestCookies_NF('Get',urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,params=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,addCookie='baseurl')
   if urltVnSsHLIQTgNkDFGfdxeKAjJcWM.status_code!=302:
    urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 1-1 status_code error')
    return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 1-1 error')
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX+'/'+urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['contryurl']+'/login' 
   urltVnSsHLIQTgNkDFGfdxeKAjJcXE=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.make_NF_DefaultCookies()
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.callRequestCookies_NF('Get',urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,params=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcXE)
   if urltVnSsHLIQTgNkDFGfdxeKAjJcWM.status_code!=200:
    urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 1-2 status_code error')
    return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
   urltVnSsHLIQTgNkDFGfdxeKAjJcRb=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.extract_json(urltVnSsHLIQTgNkDFGfdxeKAjJcWM.text,'reactContext')
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.dic_To_jsonfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_CONTEXTJSON_FILE1,urltVnSsHLIQTgNkDFGfdxeKAjJcRb)
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['membershipStatus']=urltVnSsHLIQTgNkDFGfdxeKAjJcRb['models']['userInfo']['data']['membershipStatus']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['authURL'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRb['models']['userInfo']['data']['authURL']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['esnModel'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRb['models']['esnGeneratorModel']['data']['esn']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['abContext'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRb['models']['abContext']['data']['headers']
   urltVnSsHLIQTgNkDFGfdxeKAjJcRX=urltVnSsHLIQTgNkDFGfdxeKAjJcRb['models']['loginContext']['data']['geo']['requestCountry']['id']
   urltVnSsHLIQTgNkDFGfdxeKAjJcRm ='+82' 
   urltVnSsHLIQTgNkDFGfdxeKAjJcRv =urltVnSsHLIQTgNkDFGfdxeKAjJcRb['models']['countryCodes']['data']['codes']
   for urltVnSsHLIQTgNkDFGfdxeKAjJcRP in urltVnSsHLIQTgNkDFGfdxeKAjJcRv:
    if urltVnSsHLIQTgNkDFGfdxeKAjJcRP['id']==urltVnSsHLIQTgNkDFGfdxeKAjJcRX:
     urltVnSsHLIQTgNkDFGfdxeKAjJcRm='+'+urltVnSsHLIQTgNkDFGfdxeKAjJcRP['code']
     break
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['countryCode'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRm 
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['countryIsoCode']=urltVnSsHLIQTgNkDFGfdxeKAjJcRX 
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.dic_To_jsonfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_COOKIES1,urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF)
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 1-2 error')
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  return urltVnSsHLIQTgNkDFGfdxeKAjJcvX
 def Get_NF_BaseLogin(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,user_id,user_pw,user_pfnum):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWX.Save_session_acount(user_id,user_pw,user_pfnum)
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX+'/'+urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['contryurl']+'/login' 
   urltVnSsHLIQTgNkDFGfdxeKAjJcRo={'userLoginId':user_id,'password':user_pw,'rememberMe':'true','flow':'websiteSignUp','mode':'login','action':'loginAction','withFields':'rememberMe,nextPage,userLoginId,password,countryCode,countryIsoCode','authURL':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['authURL'],'nextPage':'','showPassword':'','countryCode':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['countryCode'],'countryIsoCode':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['countryIsoCode'],}
   urltVnSsHLIQTgNkDFGfdxeKAjJcXB={'referer':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX+'/'+urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['contryurl']+'/login'}
   urltVnSsHLIQTgNkDFGfdxeKAjJcXE=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.make_NF_DefaultCookies()
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.callRequestCookies_NF('Post',urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcRo,params=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcXB,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcXE)
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.tempFileSave(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_FULLTEXT2,urltVnSsHLIQTgNkDFGfdxeKAjJcWM.text)
   if urltVnSsHLIQTgNkDFGfdxeKAjJcWM.status_code!=302:
    urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 2-1 status_code error')
    return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 2-1 error')
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX+'/'+urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['contryurl']+'/' 
   urltVnSsHLIQTgNkDFGfdxeKAjJcXB={'referer':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX+'/'+urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['contryurl']+'/login'}
   urltVnSsHLIQTgNkDFGfdxeKAjJcXE=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.make_NF_DefaultCookies()
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.callRequestCookies_NF('Get',urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,params=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcXB,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcXE)
   if urltVnSsHLIQTgNkDFGfdxeKAjJcWM.status_code!=302:
    urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 2-2 status_code error')
    return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 2-2 error')
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX+'/browse' 
   urltVnSsHLIQTgNkDFGfdxeKAjJcXB={'referer':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX+'/'+urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['contryurl']+'/login'}
   urltVnSsHLIQTgNkDFGfdxeKAjJcXE=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.make_NF_DefaultCookies()
   urltVnSsHLIQTgNkDFGfdxeKAjJcXE['clSharedContext']=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['clSharedContext']['value']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.callRequestCookies_NF('Get',urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,params=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcXB,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcXE)
   if urltVnSsHLIQTgNkDFGfdxeKAjJcWM.status_code!=200:
    urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 2-3 status_code error')
    return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
   urltVnSsHLIQTgNkDFGfdxeKAjJcRz=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.extract_json(urltVnSsHLIQTgNkDFGfdxeKAjJcWM.text,'reactContext')
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.dic_To_jsonfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_CONTEXTJSON_FILE2,urltVnSsHLIQTgNkDFGfdxeKAjJcRz)
   urltVnSsHLIQTgNkDFGfdxeKAjJcRU=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.extract_json(urltVnSsHLIQTgNkDFGfdxeKAjJcWM.text,'falcorCache')
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.dic_To_jsonfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_FALCORJSON_FILE2,urltVnSsHLIQTgNkDFGfdxeKAjJcRU)
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 2-3 error')
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  urltVnSsHLIQTgNkDFGfdxeKAjJcRY=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.Get_NF_LoginData(urltVnSsHLIQTgNkDFGfdxeKAjJcRz,urltVnSsHLIQTgNkDFGfdxeKAjJcRU,user_pfnum)
  if urltVnSsHLIQTgNkDFGfdxeKAjJcRY==urltVnSsHLIQTgNkDFGfdxeKAjJcmp:
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmp 
  return urltVnSsHLIQTgNkDFGfdxeKAjJcvX
 def Get_NF_LoginData(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,urltVnSsHLIQTgNkDFGfdxeKAjJcRz,urltVnSsHLIQTgNkDFGfdxeKAjJcRU,user_pfnum):
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['membershipStatus']=urltVnSsHLIQTgNkDFGfdxeKAjJcRz['models']['userInfo']['data']['membershipStatus']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['username'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRz['models']['userInfo']['data']['name']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['authURL'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRz['models']['userInfo']['data']['authURL'] 
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['mainGuid'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRz['models']['userInfo']['data']['guid'] 
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['nowGuid'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRz['models']['userInfo']['data']['userGuid']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['esnModel'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRz['models']['esnGeneratorModel']['data']['esn']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['abContext'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRz['models']['abContext']['data']['headers']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['identifier'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRz['models']['serverDefs']['data']['BUILD_IDENTIFIER']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['nowGuid'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRU['profilesList'][urltVnSsHLIQTgNkDFGfdxeKAjJcmw(user_pfnum)]['value'][1]
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.dic_To_jsonfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_COOKIES2,urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF)
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 2-3-sub error')
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  return urltVnSsHLIQTgNkDFGfdxeKAjJcvX
 def Get_NF_ActivateProfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWC='%s/api/shakti/%s/profiles/switch'%(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX,urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['identifier'])
   urltVnSsHLIQTgNkDFGfdxeKAjJcWi={'switchProfileGuid':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['nowGuid'],'authURL':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['authURL'],'_':urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.GetNoCache(timetype=2,minutes=0)),}
   urltVnSsHLIQTgNkDFGfdxeKAjJcXB={'referer':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX+'/browse','accept':'*/*','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
   urltVnSsHLIQTgNkDFGfdxeKAjJcRC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.make_NF_XnetflixHeaders()
   urltVnSsHLIQTgNkDFGfdxeKAjJcRC['x-netflix.request.client.user.guid']=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['mainGuid']
   urltVnSsHLIQTgNkDFGfdxeKAjJcXB.update(urltVnSsHLIQTgNkDFGfdxeKAjJcRC)
   urltVnSsHLIQTgNkDFGfdxeKAjJcXE=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.make_NF_DefaultCookies()
   urltVnSsHLIQTgNkDFGfdxeKAjJcXE['clSharedContext']=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['clSharedContext']['value']
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.callRequestCookies_NF('Get',urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,params=urltVnSsHLIQTgNkDFGfdxeKAjJcWi,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcXB,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcXE)
   if urltVnSsHLIQTgNkDFGfdxeKAjJcWM.status_code!=200:
    urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 3 status_code error')
    return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.dic_To_jsonfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_COOKIES2,urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF)
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 3 error')
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  return urltVnSsHLIQTgNkDFGfdxeKAjJcvX
 def Get_NF_BrowseMain(urltVnSsHLIQTgNkDFGfdxeKAjJcWX):
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX+'/browse' 
   urltVnSsHLIQTgNkDFGfdxeKAjJcXB={'referer':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX+'/browse','sec-fetch-dest':'document','sec-fetch-mode':'navigate','sec-fetch-site':'same-origin','sec-fetch-user':'?1',}
   urltVnSsHLIQTgNkDFGfdxeKAjJcXE=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.make_NF_DefaultCookies()
   urltVnSsHLIQTgNkDFGfdxeKAjJcXE['clSharedContext']=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['clSharedContext']['value']
   urltVnSsHLIQTgNkDFGfdxeKAjJcXE['profilesNewSession']='0' 
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.callRequestCookies_NF('Get',urltVnSsHLIQTgNkDFGfdxeKAjJcWC,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,params=urltVnSsHLIQTgNkDFGfdxeKAjJcmh,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcXB,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcXE,addCookie='lhpuuidh')
   if urltVnSsHLIQTgNkDFGfdxeKAjJcWM.status_code!=200:
    urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 4-main status_code error')
    return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
   urltVnSsHLIQTgNkDFGfdxeKAjJcRz=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.extract_json(urltVnSsHLIQTgNkDFGfdxeKAjJcWM.text,'reactContext')
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.dic_To_jsonfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_CONTEXTJSON_FILE3,urltVnSsHLIQTgNkDFGfdxeKAjJcRz)
   urltVnSsHLIQTgNkDFGfdxeKAjJcRU=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.extract_json(urltVnSsHLIQTgNkDFGfdxeKAjJcWM.text,'falcorCache')
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.dic_To_jsonfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_FALCORJSON_FILE3,urltVnSsHLIQTgNkDFGfdxeKAjJcRU)
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 4-main error')
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  urltVnSsHLIQTgNkDFGfdxeKAjJcRY=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.Get_NF_BrowseSub(urltVnSsHLIQTgNkDFGfdxeKAjJcRz,urltVnSsHLIQTgNkDFGfdxeKAjJcRU)
  if urltVnSsHLIQTgNkDFGfdxeKAjJcRY==urltVnSsHLIQTgNkDFGfdxeKAjJcmp:
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmp 
  return urltVnSsHLIQTgNkDFGfdxeKAjJcvX
 def Get_NF_BrowseSub(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,urltVnSsHLIQTgNkDFGfdxeKAjJcRz,urltVnSsHLIQTgNkDFGfdxeKAjJcRU):
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcRi =urltVnSsHLIQTgNkDFGfdxeKAjJcRU['loco']['value'][1]
   urltVnSsHLIQTgNkDFGfdxeKAjJcRM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.GetNoCache(timetype=2,minutes=180)
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['loco'] =urltVnSsHLIQTgNkDFGfdxeKAjJcRi
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['lhpuuidh']={'keyname':'lhpuuidh-browse-%s'%(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['nowGuid']),'value':'%s%s'%('KR%3AKO-KR%3A',urltVnSsHLIQTgNkDFGfdxeKAjJcRi),'expires':urltVnSsHLIQTgNkDFGfdxeKAjJcvW(urltVnSsHLIQTgNkDFGfdxeKAjJcRM/1000)}
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['COOKIES']['lhpuuidhT']={'keyname':'lhpuuidh-browse-%s-T'%(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['nowGuid']),'value':urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcRM),'expires':urltVnSsHLIQTgNkDFGfdxeKAjJcvW(urltVnSsHLIQTgNkDFGfdxeKAjJcRM/1000)}
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.dic_To_jsonfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_SESSION_COOKIES3,urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF)
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy('pass 4-sub error')
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  return urltVnSsHLIQTgNkDFGfdxeKAjJcvX
 def NF_makestr_paths(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,paths):
  urltVnSsHLIQTgNkDFGfdxeKAjJcXM=[]
  if urltVnSsHLIQTgNkDFGfdxeKAjJcvm(paths,urltVnSsHLIQTgNkDFGfdxeKAjJcvW):
   return '%d'%(paths)
  elif urltVnSsHLIQTgNkDFGfdxeKAjJcvm(paths,urltVnSsHLIQTgNkDFGfdxeKAjJcmw):
   return '"%s"'%(paths)
  for urltVnSsHLIQTgNkDFGfdxeKAjJcRq in paths:
   if urltVnSsHLIQTgNkDFGfdxeKAjJcvm(urltVnSsHLIQTgNkDFGfdxeKAjJcRq,urltVnSsHLIQTgNkDFGfdxeKAjJcvW):
    urltVnSsHLIQTgNkDFGfdxeKAjJcXM.append('%d'%(urltVnSsHLIQTgNkDFGfdxeKAjJcRq))
   elif urltVnSsHLIQTgNkDFGfdxeKAjJcvm(urltVnSsHLIQTgNkDFGfdxeKAjJcRq,urltVnSsHLIQTgNkDFGfdxeKAjJcmw):
    urltVnSsHLIQTgNkDFGfdxeKAjJcXM.append('"%s"'%(urltVnSsHLIQTgNkDFGfdxeKAjJcRq))
   elif urltVnSsHLIQTgNkDFGfdxeKAjJcvm(urltVnSsHLIQTgNkDFGfdxeKAjJcRq,urltVnSsHLIQTgNkDFGfdxeKAjJcvP):
    urltVnSsHLIQTgNkDFGfdxeKAjJcXM.append('[%s]'%(','.join(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_makestr_paths(urltVnSsHLIQTgNkDFGfdxeKAjJcRq))))
   elif urltVnSsHLIQTgNkDFGfdxeKAjJcvm(urltVnSsHLIQTgNkDFGfdxeKAjJcRq,urltVnSsHLIQTgNkDFGfdxeKAjJcvo):
    urltVnSsHLIQTgNkDFGfdxeKAjJcRE=''
    for urltVnSsHLIQTgNkDFGfdxeKAjJcRB,urltVnSsHLIQTgNkDFGfdxeKAjJcRO in urltVnSsHLIQTgNkDFGfdxeKAjJcRq.items():
     urltVnSsHLIQTgNkDFGfdxeKAjJcRE+='"%s":%s,'%(urltVnSsHLIQTgNkDFGfdxeKAjJcRB,urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_makestr_paths(urltVnSsHLIQTgNkDFGfdxeKAjJcRO))
    urltVnSsHLIQTgNkDFGfdxeKAjJcXM.append('{%s}'%(urltVnSsHLIQTgNkDFGfdxeKAjJcRE[:-1]))
  return urltVnSsHLIQTgNkDFGfdxeKAjJcXM
 def NF_Call_pathapi(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,urltVnSsHLIQTgNkDFGfdxeKAjJcmR,referer=''):
  urltVnSsHLIQTgNkDFGfdxeKAjJcRa='%s/nq/website/memberapi/%s/pathEvaluator'%(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX,urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['identifier'])
  urltVnSsHLIQTgNkDFGfdxeKAjJcRo={'path':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_makestr_paths(urltVnSsHLIQTgNkDFGfdxeKAjJcmR),'authURL':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF['SESSION']['authURL']}
  urltVnSsHLIQTgNkDFGfdxeKAjJcWi=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.make_NF_ApiParams()
  urltVnSsHLIQTgNkDFGfdxeKAjJcXB={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':urltVnSsHLIQTgNkDFGfdxeKAjJcXB['referer']=referer
  urltVnSsHLIQTgNkDFGfdxeKAjJcRC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.make_NF_XnetflixHeaders()
  urltVnSsHLIQTgNkDFGfdxeKAjJcXB.update(urltVnSsHLIQTgNkDFGfdxeKAjJcRC)
  urltVnSsHLIQTgNkDFGfdxeKAjJcXE=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.make_NF_DefaultCookies()
  urltVnSsHLIQTgNkDFGfdxeKAjJcXE['profilesNewSession']='0'
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.callRequestCookies('Post',urltVnSsHLIQTgNkDFGfdxeKAjJcRa,payload=urltVnSsHLIQTgNkDFGfdxeKAjJcRo,params=urltVnSsHLIQTgNkDFGfdxeKAjJcWi,headers=urltVnSsHLIQTgNkDFGfdxeKAjJcXB,cookies=urltVnSsHLIQTgNkDFGfdxeKAjJcXE)
   return urltVnSsHLIQTgNkDFGfdxeKAjJcWM
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
   return urltVnSsHLIQTgNkDFGfdxeKAjJcmh
 def Get_Search_Netflix(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,search_key,page_int,byReference=''):
  urltVnSsHLIQTgNkDFGfdxeKAjJcRh=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.DERECTOR_LIMIT
  urltVnSsHLIQTgNkDFGfdxeKAjJcRp =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.CAST_LIMIT
  urltVnSsHLIQTgNkDFGfdxeKAjJcRy =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.GENRE_LIMIT
  urltVnSsHLIQTgNkDFGfdxeKAjJcRw =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_LIMIT*(page_int-1)
  urltVnSsHLIQTgNkDFGfdxeKAjJcmW =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_LIMIT*page_int 
  urltVnSsHLIQTgNkDFGfdxeKAjJcmb="|%s"%(search_key)
  urltVnSsHLIQTgNkDFGfdxeKAjJcmX ='%s/search?%s'%(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmR=[["search","byTerm",urltVnSsHLIQTgNkDFGfdxeKAjJcmb,"titles",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_LIMIT,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"summary"],["search","byTerm",urltVnSsHLIQTgNkDFGfdxeKAjJcmb,"titles",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_LIMIT,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",urltVnSsHLIQTgNkDFGfdxeKAjJcmb,"titles",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_LIMIT,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference","boxarts",[urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND2,urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_PORT],"jpg"],["search","byTerm",urltVnSsHLIQTgNkDFGfdxeKAjJcmb,"titles",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_LIMIT,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference","interestingMoment",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND1,"jpg"],["search","byTerm",urltVnSsHLIQTgNkDFGfdxeKAjJcmb,"titles",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_LIMIT,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference","storyArt",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND2,"jpg"],["search","byTerm",urltVnSsHLIQTgNkDFGfdxeKAjJcmb,"titles",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_LIMIT,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference",["cast","creators","directors"],{"from":0,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcRh},["id","name"]],["search","byTerm",urltVnSsHLIQTgNkDFGfdxeKAjJcmb,"titles",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_LIMIT,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference","genres",{"from":0,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcRy},["id","name"]],["search","byTerm",urltVnSsHLIQTgNkDFGfdxeKAjJcmb,"titles",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NETFLIX_LIMIT,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LOGO,"png"],]
  else:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmR=[["search","byReference",byReference,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"summary"],["search","byReference",byReference,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference","boxarts",[urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND2,urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference","interestingMoment",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference","storyArt",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference",["cast","creators","directors"],{"from":0,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcRh},["id","name"]],["search","byReference",byReference,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference","genres",{"from":0,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcRy},["id","name"]],["search","byReference",byReference,{"from":urltVnSsHLIQTgNkDFGfdxeKAjJcRw,"to":urltVnSsHLIQTgNkDFGfdxeKAjJcmW},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LOGO,"png"],]
  try:
   urltVnSsHLIQTgNkDFGfdxeKAjJcWM=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_Call_pathapi(urltVnSsHLIQTgNkDFGfdxeKAjJcmR,urltVnSsHLIQTgNkDFGfdxeKAjJcmX)
   urltVnSsHLIQTgNkDFGfdxeKAjJcWq=json.loads(urltVnSsHLIQTgNkDFGfdxeKAjJcWM.text)
   urltVnSsHLIQTgNkDFGfdxeKAjJcWX.dic_To_jsonfile(urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_CONTEXTJSON_FILE4,urltVnSsHLIQTgNkDFGfdxeKAjJcWq)
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
  (urltVnSsHLIQTgNkDFGfdxeKAjJcWz,urltVnSsHLIQTgNkDFGfdxeKAjJcWY,byReference)=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.Search_Netflix_Make(urltVnSsHLIQTgNkDFGfdxeKAjJcWq)
  return urltVnSsHLIQTgNkDFGfdxeKAjJcWz,urltVnSsHLIQTgNkDFGfdxeKAjJcWY,byReference
 def Search_Netflix_Make(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,jsonSource):
  urltVnSsHLIQTgNkDFGfdxeKAjJcWz=[]
  urltVnSsHLIQTgNkDFGfdxeKAjJcWY =urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  urltVnSsHLIQTgNkDFGfdxeKAjJcmv=''
  urltVnSsHLIQTgNkDFGfdxeKAjJcmP=jsonSource.get('paths')[0][1]
  if urltVnSsHLIQTgNkDFGfdxeKAjJcmP=='byTerm':
   urltVnSsHLIQTgNkDFGfdxeKAjJcRw =jsonSource['paths'][0][5]['from']
   urltVnSsHLIQTgNkDFGfdxeKAjJcmW =jsonSource['paths'][0][5]['to']
  else:
   urltVnSsHLIQTgNkDFGfdxeKAjJcRw =jsonSource['paths'][0][3]['from']
   urltVnSsHLIQTgNkDFGfdxeKAjJcmW =jsonSource['paths'][0][3]['to']
  urltVnSsHLIQTgNkDFGfdxeKAjJcmv=urltVnSsHLIQTgNkDFGfdxeKAjJcvP(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  urltVnSsHLIQTgNkDFGfdxeKAjJcmo=jsonSource.get('jsonGraph').get('search').get('byReference').get(urltVnSsHLIQTgNkDFGfdxeKAjJcmv)
  urltVnSsHLIQTgNkDFGfdxeKAjJcmz =jsonSource.get('jsonGraph').get('videos')
  urltVnSsHLIQTgNkDFGfdxeKAjJcmU=jsonSource.get('jsonGraph').get('person')
  urltVnSsHLIQTgNkDFGfdxeKAjJcmY=jsonSource.get('jsonGraph').get('genres')
  urltVnSsHLIQTgNkDFGfdxeKAjJcWY=urltVnSsHLIQTgNkDFGfdxeKAjJcvX if urltVnSsHLIQTgNkDFGfdxeKAjJcmo[urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcmW)]['reference']['$type']=='ref' else urltVnSsHLIQTgNkDFGfdxeKAjJcmp
  for urltVnSsHLIQTgNkDFGfdxeKAjJcmC in urltVnSsHLIQTgNkDFGfdxeKAjJcvz(urltVnSsHLIQTgNkDFGfdxeKAjJcRw,urltVnSsHLIQTgNkDFGfdxeKAjJcmW):
   if urltVnSsHLIQTgNkDFGfdxeKAjJcmo[urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcmC)]['reference']['$type']=='ref':
    urltVnSsHLIQTgNkDFGfdxeKAjJcWp =urltVnSsHLIQTgNkDFGfdxeKAjJcmo[urltVnSsHLIQTgNkDFGfdxeKAjJcmw(urltVnSsHLIQTgNkDFGfdxeKAjJcmC)]['reference']['value'][1]
    urltVnSsHLIQTgNkDFGfdxeKAjJcmi=urltVnSsHLIQTgNkDFGfdxeKAjJcmz[urltVnSsHLIQTgNkDFGfdxeKAjJcWp]
    urltVnSsHLIQTgNkDFGfdxeKAjJcXv =urltVnSsHLIQTgNkDFGfdxeKAjJcmi['title']['value']
    if urltVnSsHLIQTgNkDFGfdxeKAjJcmi['availability']['value']['isPlayable']==urltVnSsHLIQTgNkDFGfdxeKAjJcmp:
     continue
    urltVnSsHLIQTgNkDFGfdxeKAjJcWh =urltVnSsHLIQTgNkDFGfdxeKAjJcmi['summary']['value']['type']
    urltVnSsHLIQTgNkDFGfdxeKAjJcbq =0 if urltVnSsHLIQTgNkDFGfdxeKAjJcWh!='movie' else urltVnSsHLIQTgNkDFGfdxeKAjJcmi['runtime']['value']
    if urltVnSsHLIQTgNkDFGfdxeKAjJcmi['sequiturEvidence']['value']['value']:
     urltVnSsHLIQTgNkDFGfdxeKAjJcmM=urltVnSsHLIQTgNkDFGfdxeKAjJcmi['sequiturEvidence']['value']['value']['text']
    else:
     urltVnSsHLIQTgNkDFGfdxeKAjJcmM=''
    urltVnSsHLIQTgNkDFGfdxeKAjJcbU =urltVnSsHLIQTgNkDFGfdxeKAjJcmi['boxarts'][urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_PORT]['jpg']['value']['url']
    urltVnSsHLIQTgNkDFGfdxeKAjJcmq =urltVnSsHLIQTgNkDFGfdxeKAjJcmi['boxarts'][urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND2]['jpg']['value']['url']
    urltVnSsHLIQTgNkDFGfdxeKAjJcbY=''
    if 'value' in urltVnSsHLIQTgNkDFGfdxeKAjJcmi['storyArt'][urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND2]['jpg']:
     urltVnSsHLIQTgNkDFGfdxeKAjJcbY =urltVnSsHLIQTgNkDFGfdxeKAjJcmi['storyArt'][urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND2]['jpg']['value']['url']
    if urltVnSsHLIQTgNkDFGfdxeKAjJcbY=='' and 'value' in urltVnSsHLIQTgNkDFGfdxeKAjJcmi['interestingMoment'][urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND1]['jpg']:
     urltVnSsHLIQTgNkDFGfdxeKAjJcbY =urltVnSsHLIQTgNkDFGfdxeKAjJcmi['interestingMoment'][urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LAND1]['jpg']['value']['url']
    urltVnSsHLIQTgNkDFGfdxeKAjJcbp=''
    if 'value' in urltVnSsHLIQTgNkDFGfdxeKAjJcmi['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LOGO]['png']:
     urltVnSsHLIQTgNkDFGfdxeKAjJcbp=urltVnSsHLIQTgNkDFGfdxeKAjJcmi['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][urltVnSsHLIQTgNkDFGfdxeKAjJcWX.ART_SIZE_LOGO]['png']['value']['url']
    urltVnSsHLIQTgNkDFGfdxeKAjJcbM =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_Subid_List(urltVnSsHLIQTgNkDFGfdxeKAjJcmi['genres'])
    for i in urltVnSsHLIQTgNkDFGfdxeKAjJcvz(urltVnSsHLIQTgNkDFGfdxeKAjJcvU(urltVnSsHLIQTgNkDFGfdxeKAjJcbM)):
     urltVnSsHLIQTgNkDFGfdxeKAjJcbM[i]=urltVnSsHLIQTgNkDFGfdxeKAjJcmY[urltVnSsHLIQTgNkDFGfdxeKAjJcbM[i]]['name']['value']
    urltVnSsHLIQTgNkDFGfdxeKAjJcbi=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_Subid_List(urltVnSsHLIQTgNkDFGfdxeKAjJcmi['directors'])
    urltVnSsHLIQTgNkDFGfdxeKAjJcmE =urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_Subid_List(urltVnSsHLIQTgNkDFGfdxeKAjJcmi['creators'])
    urltVnSsHLIQTgNkDFGfdxeKAjJcbi.extend(urltVnSsHLIQTgNkDFGfdxeKAjJcmE)
    for i in urltVnSsHLIQTgNkDFGfdxeKAjJcvz(urltVnSsHLIQTgNkDFGfdxeKAjJcvU(urltVnSsHLIQTgNkDFGfdxeKAjJcbi)):
     urltVnSsHLIQTgNkDFGfdxeKAjJcbi[i]=urltVnSsHLIQTgNkDFGfdxeKAjJcmU[urltVnSsHLIQTgNkDFGfdxeKAjJcbi[i]]['name']['value']
    urltVnSsHLIQTgNkDFGfdxeKAjJcbC=urltVnSsHLIQTgNkDFGfdxeKAjJcWX.NF_Subid_List(urltVnSsHLIQTgNkDFGfdxeKAjJcmi['cast'])
    for i in urltVnSsHLIQTgNkDFGfdxeKAjJcvz(urltVnSsHLIQTgNkDFGfdxeKAjJcvU(urltVnSsHLIQTgNkDFGfdxeKAjJcbC)):
     urltVnSsHLIQTgNkDFGfdxeKAjJcbC[i]=urltVnSsHLIQTgNkDFGfdxeKAjJcmU[urltVnSsHLIQTgNkDFGfdxeKAjJcbC[i]]['name']['value']
    if 'maturityDescription' in urltVnSsHLIQTgNkDFGfdxeKAjJcmi['maturity']['value']['rating']:
     urltVnSsHLIQTgNkDFGfdxeKAjJcbE=urltVnSsHLIQTgNkDFGfdxeKAjJcmi['maturity']['value']['rating']['maturityDescription']
    urltVnSsHLIQTgNkDFGfdxeKAjJcbW={'videoid':urltVnSsHLIQTgNkDFGfdxeKAjJcWp,'vidtype':urltVnSsHLIQTgNkDFGfdxeKAjJcWh,'title':urltVnSsHLIQTgNkDFGfdxeKAjJcXv,'mpaa':urltVnSsHLIQTgNkDFGfdxeKAjJcbE,'regularSynopsis':urltVnSsHLIQTgNkDFGfdxeKAjJcmi['regularSynopsis']['value'],'dpSupplemental':urltVnSsHLIQTgNkDFGfdxeKAjJcmi['dpSupplementalMessage']['value'],'sequiturEvidence':urltVnSsHLIQTgNkDFGfdxeKAjJcmM,'thumbnail':{'poster':urltVnSsHLIQTgNkDFGfdxeKAjJcbU,'thumb':urltVnSsHLIQTgNkDFGfdxeKAjJcbY,'fanart':urltVnSsHLIQTgNkDFGfdxeKAjJcmq,'clearlogo':urltVnSsHLIQTgNkDFGfdxeKAjJcbp},'year':urltVnSsHLIQTgNkDFGfdxeKAjJcmi['releaseYear']['value'],'duration':urltVnSsHLIQTgNkDFGfdxeKAjJcbq,'info_genre':urltVnSsHLIQTgNkDFGfdxeKAjJcbM,'director':urltVnSsHLIQTgNkDFGfdxeKAjJcbi,'cast':urltVnSsHLIQTgNkDFGfdxeKAjJcbC,}
    urltVnSsHLIQTgNkDFGfdxeKAjJcWz.append(urltVnSsHLIQTgNkDFGfdxeKAjJcbW)
  return urltVnSsHLIQTgNkDFGfdxeKAjJcWz,urltVnSsHLIQTgNkDFGfdxeKAjJcWY,urltVnSsHLIQTgNkDFGfdxeKAjJcmv
 def NF_Subid_List(urltVnSsHLIQTgNkDFGfdxeKAjJcWX,subJson):
  urltVnSsHLIQTgNkDFGfdxeKAjJcmB=[]
  try:
   for i in urltVnSsHLIQTgNkDFGfdxeKAjJcvz(urltVnSsHLIQTgNkDFGfdxeKAjJcvU(subJson)):
    if subJson.get(urltVnSsHLIQTgNkDFGfdxeKAjJcmw(i)).get('$type')!='ref':break
    urltVnSsHLIQTgNkDFGfdxeKAjJcmO=subJson.get(urltVnSsHLIQTgNkDFGfdxeKAjJcmw(i)).get('value')[1]
    urltVnSsHLIQTgNkDFGfdxeKAjJcmB.append(urltVnSsHLIQTgNkDFGfdxeKAjJcmO)
  except urltVnSsHLIQTgNkDFGfdxeKAjJcvb as exception:
   urltVnSsHLIQTgNkDFGfdxeKAjJcmy(exception)
  return urltVnSsHLIQTgNkDFGfdxeKAjJcmB
# Created by pyminifier (https://github.com/liftoff/pyminifier)
