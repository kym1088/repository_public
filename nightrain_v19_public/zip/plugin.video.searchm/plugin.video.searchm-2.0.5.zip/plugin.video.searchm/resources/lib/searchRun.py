__author__="NightRain"
zDCyVAolpYvEFxiKbWsutILedaOUqj=object
zDCyVAolpYvEFxiKbWsutILedaOUqN=None
zDCyVAolpYvEFxiKbWsutILedaOUqf=True
zDCyVAolpYvEFxiKbWsutILedaOUqc=False
zDCyVAolpYvEFxiKbWsutILedaOUqJ=type
zDCyVAolpYvEFxiKbWsutILedaOUmT=dict
zDCyVAolpYvEFxiKbWsutILedaOUmP=open
zDCyVAolpYvEFxiKbWsutILedaOUmk=len
zDCyVAolpYvEFxiKbWsutILedaOUmn=Exception
zDCyVAolpYvEFxiKbWsutILedaOUmq=str
zDCyVAolpYvEFxiKbWsutILedaOUmh=int
zDCyVAolpYvEFxiKbWsutILedaOUmH=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
zDCyVAolpYvEFxiKbWsutILedaOUTk=[{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
zDCyVAolpYvEFxiKbWsutILedaOUTn={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},}
zDCyVAolpYvEFxiKbWsutILedaOUTq=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
zDCyVAolpYvEFxiKbWsutILedaOUTm =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class zDCyVAolpYvEFxiKbWsutILedaOUTP(zDCyVAolpYvEFxiKbWsutILedaOUqj):
 def __init__(zDCyVAolpYvEFxiKbWsutILedaOUTh,zDCyVAolpYvEFxiKbWsutILedaOUTH,zDCyVAolpYvEFxiKbWsutILedaOUTS,zDCyVAolpYvEFxiKbWsutILedaOUTw):
  zDCyVAolpYvEFxiKbWsutILedaOUTh._addon_url =zDCyVAolpYvEFxiKbWsutILedaOUTH
  zDCyVAolpYvEFxiKbWsutILedaOUTh._addon_handle=zDCyVAolpYvEFxiKbWsutILedaOUTS
  zDCyVAolpYvEFxiKbWsutILedaOUTh.main_params =zDCyVAolpYvEFxiKbWsutILedaOUTw
  zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj =urltVnSsHLIQTgNkDFGfdxeKAjJcWb() 
 def addon_noti(zDCyVAolpYvEFxiKbWsutILedaOUTh,sting):
  try:
   zDCyVAolpYvEFxiKbWsutILedaOUTG=xbmcgui.Dialog()
   zDCyVAolpYvEFxiKbWsutILedaOUTG.notification(__addonname__,sting)
  except:
   zDCyVAolpYvEFxiKbWsutILedaOUqN
 def addon_log(zDCyVAolpYvEFxiKbWsutILedaOUTh,string):
  try:
   zDCyVAolpYvEFxiKbWsutILedaOUTQ=string.encode('utf-8','ignore')
  except:
   zDCyVAolpYvEFxiKbWsutILedaOUTQ='addonException: addon_log'
  zDCyVAolpYvEFxiKbWsutILedaOUTr=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,zDCyVAolpYvEFxiKbWsutILedaOUTQ),level=zDCyVAolpYvEFxiKbWsutILedaOUTr)
 def get_keyboard_input(zDCyVAolpYvEFxiKbWsutILedaOUTh,zDCyVAolpYvEFxiKbWsutILedaOUTc):
  zDCyVAolpYvEFxiKbWsutILedaOUTB=zDCyVAolpYvEFxiKbWsutILedaOUqN
  kb=xbmc.Keyboard()
  kb.setHeading(zDCyVAolpYvEFxiKbWsutILedaOUTc)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   zDCyVAolpYvEFxiKbWsutILedaOUTB=kb.getText()
  return zDCyVAolpYvEFxiKbWsutILedaOUTB
 def get_settings_menubookmark(zDCyVAolpYvEFxiKbWsutILedaOUTh):
  zDCyVAolpYvEFxiKbWsutILedaOUTM=zDCyVAolpYvEFxiKbWsutILedaOUqf if __addon__.getSetting('menu_bookmark')=='true' else zDCyVAolpYvEFxiKbWsutILedaOUqc
  return(zDCyVAolpYvEFxiKbWsutILedaOUTM)
 def get_settings_makebookmark(zDCyVAolpYvEFxiKbWsutILedaOUTh):
  return zDCyVAolpYvEFxiKbWsutILedaOUqf if __addon__.getSetting('make_bookmark')=='true' else zDCyVAolpYvEFxiKbWsutILedaOUqc
 def get_settings_select_info(zDCyVAolpYvEFxiKbWsutILedaOUTh):
  zDCyVAolpYvEFxiKbWsutILedaOUTX=[]
  if __addon__.getSetting('netflixyn')=='true':zDCyVAolpYvEFxiKbWsutILedaOUTX.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':zDCyVAolpYvEFxiKbWsutILedaOUTX.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':zDCyVAolpYvEFxiKbWsutILedaOUTX.append('tving')
  if __addon__.getSetting('watchayn')=='true':zDCyVAolpYvEFxiKbWsutILedaOUTX.append('watcha')
  return zDCyVAolpYvEFxiKbWsutILedaOUTX
 def get_settings_netflix(zDCyVAolpYvEFxiKbWsutILedaOUTh):
  zDCyVAolpYvEFxiKbWsutILedaOUTR =__addon__.getSetting('nfid')
  zDCyVAolpYvEFxiKbWsutILedaOUTj =__addon__.getSetting('nfpw')
  zDCyVAolpYvEFxiKbWsutILedaOUTN=__addon__.getSetting('nf_profile')
  return(zDCyVAolpYvEFxiKbWsutILedaOUTR,zDCyVAolpYvEFxiKbWsutILedaOUTj,zDCyVAolpYvEFxiKbWsutILedaOUTN)
 def add_dir(zDCyVAolpYvEFxiKbWsutILedaOUTh,label,sublabel='',img='',infoLabels=zDCyVAolpYvEFxiKbWsutILedaOUqN,isFolder=zDCyVAolpYvEFxiKbWsutILedaOUqf,params='',isLink=zDCyVAolpYvEFxiKbWsutILedaOUqc,ContextMenu=zDCyVAolpYvEFxiKbWsutILedaOUqN):
  zDCyVAolpYvEFxiKbWsutILedaOUTf='%s?%s'%(zDCyVAolpYvEFxiKbWsutILedaOUTh._addon_url,urllib.parse.urlencode(params))
  if sublabel:zDCyVAolpYvEFxiKbWsutILedaOUTc='%s < %s >'%(label,sublabel)
  else: zDCyVAolpYvEFxiKbWsutILedaOUTc=label
  if not img:img='DefaultFolder.png'
  zDCyVAolpYvEFxiKbWsutILedaOUTJ=xbmcgui.ListItem(zDCyVAolpYvEFxiKbWsutILedaOUTc)
  if zDCyVAolpYvEFxiKbWsutILedaOUqJ(img)==zDCyVAolpYvEFxiKbWsutILedaOUmT:
   zDCyVAolpYvEFxiKbWsutILedaOUTJ.setArt(img)
  else:
   zDCyVAolpYvEFxiKbWsutILedaOUTJ.setArt({'thumb':img,'poster':img})
  if infoLabels:zDCyVAolpYvEFxiKbWsutILedaOUTJ.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   zDCyVAolpYvEFxiKbWsutILedaOUTJ.setProperty('IsPlayable','true')
  if ContextMenu:zDCyVAolpYvEFxiKbWsutILedaOUTJ.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(zDCyVAolpYvEFxiKbWsutILedaOUTh._addon_handle,zDCyVAolpYvEFxiKbWsutILedaOUTf,zDCyVAolpYvEFxiKbWsutILedaOUTJ,isFolder)
 def Load_Searched_List(zDCyVAolpYvEFxiKbWsutILedaOUTh):
  try:
   zDCyVAolpYvEFxiKbWsutILedaOUPT=zDCyVAolpYvEFxiKbWsutILedaOUTm
   fp=zDCyVAolpYvEFxiKbWsutILedaOUmP(zDCyVAolpYvEFxiKbWsutILedaOUPT,'r',-1,'utf-8')
   zDCyVAolpYvEFxiKbWsutILedaOUPk=fp.readlines()
   fp.close()
  except:
   zDCyVAolpYvEFxiKbWsutILedaOUPk=[]
  return zDCyVAolpYvEFxiKbWsutILedaOUPk
 def Save_Searched_List(zDCyVAolpYvEFxiKbWsutILedaOUTh,zDCyVAolpYvEFxiKbWsutILedaOUnP):
  try:
   zDCyVAolpYvEFxiKbWsutILedaOUPT=zDCyVAolpYvEFxiKbWsutILedaOUTm
   zDCyVAolpYvEFxiKbWsutILedaOUPn=zDCyVAolpYvEFxiKbWsutILedaOUTh.Load_Searched_List() 
   zDCyVAolpYvEFxiKbWsutILedaOUPq={'skey':zDCyVAolpYvEFxiKbWsutILedaOUnP.strip()}
   fp=zDCyVAolpYvEFxiKbWsutILedaOUmP(zDCyVAolpYvEFxiKbWsutILedaOUPT,'w',-1,'utf-8')
   zDCyVAolpYvEFxiKbWsutILedaOUPm=urllib.parse.urlencode(zDCyVAolpYvEFxiKbWsutILedaOUPq)
   zDCyVAolpYvEFxiKbWsutILedaOUPm=zDCyVAolpYvEFxiKbWsutILedaOUPm+'\n'
   fp.write(zDCyVAolpYvEFxiKbWsutILedaOUPm)
   zDCyVAolpYvEFxiKbWsutILedaOUPh=0
   for zDCyVAolpYvEFxiKbWsutILedaOUPH in zDCyVAolpYvEFxiKbWsutILedaOUPn:
    zDCyVAolpYvEFxiKbWsutILedaOUPS=zDCyVAolpYvEFxiKbWsutILedaOUmT(urllib.parse.parse_qsl(zDCyVAolpYvEFxiKbWsutILedaOUPH))
    zDCyVAolpYvEFxiKbWsutILedaOUPw=zDCyVAolpYvEFxiKbWsutILedaOUPq.get('skey').strip()
    zDCyVAolpYvEFxiKbWsutILedaOUPg=zDCyVAolpYvEFxiKbWsutILedaOUPS.get('skey').strip()
    if zDCyVAolpYvEFxiKbWsutILedaOUPw!=zDCyVAolpYvEFxiKbWsutILedaOUPg:
     fp.write(zDCyVAolpYvEFxiKbWsutILedaOUPH)
     zDCyVAolpYvEFxiKbWsutILedaOUPh+=1
     if zDCyVAolpYvEFxiKbWsutILedaOUPh>=50:break
   fp.close()
  except:
   zDCyVAolpYvEFxiKbWsutILedaOUqN
 def dp_Search_History(zDCyVAolpYvEFxiKbWsutILedaOUTh,args):
  zDCyVAolpYvEFxiKbWsutILedaOUPG=zDCyVAolpYvEFxiKbWsutILedaOUTh.Load_Searched_List()
  for zDCyVAolpYvEFxiKbWsutILedaOUPQ in zDCyVAolpYvEFxiKbWsutILedaOUPG:
   zDCyVAolpYvEFxiKbWsutILedaOUPr=zDCyVAolpYvEFxiKbWsutILedaOUmT(urllib.parse.parse_qsl(zDCyVAolpYvEFxiKbWsutILedaOUPQ))
   zDCyVAolpYvEFxiKbWsutILedaOUPB=zDCyVAolpYvEFxiKbWsutILedaOUPr.get('skey').strip()
   zDCyVAolpYvEFxiKbWsutILedaOUPM={'mode':'TOTAL_SEARCH','search_key':zDCyVAolpYvEFxiKbWsutILedaOUPB,}
   zDCyVAolpYvEFxiKbWsutILedaOUPX={'mode':'HISTORY_REMOVE','skey':zDCyVAolpYvEFxiKbWsutILedaOUPB,'delmode':'ONE',}
   zDCyVAolpYvEFxiKbWsutILedaOUPR=urllib.parse.urlencode(zDCyVAolpYvEFxiKbWsutILedaOUPX)
   zDCyVAolpYvEFxiKbWsutILedaOUPj=[('선택된 검색어 ( %s ) 삭제'%(zDCyVAolpYvEFxiKbWsutILedaOUPB),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(zDCyVAolpYvEFxiKbWsutILedaOUPR))]
   zDCyVAolpYvEFxiKbWsutILedaOUTh.add_dir(zDCyVAolpYvEFxiKbWsutILedaOUPB,sublabel='',img=zDCyVAolpYvEFxiKbWsutILedaOUqN,infoLabels=zDCyVAolpYvEFxiKbWsutILedaOUqN,isFolder=zDCyVAolpYvEFxiKbWsutILedaOUqf,params=zDCyVAolpYvEFxiKbWsutILedaOUPM,ContextMenu=zDCyVAolpYvEFxiKbWsutILedaOUPj)
  zDCyVAolpYvEFxiKbWsutILedaOUPf={'plot':'검색목록 전체를 삭제합니다.'}
  zDCyVAolpYvEFxiKbWsutILedaOUTc='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  zDCyVAolpYvEFxiKbWsutILedaOUPM={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  zDCyVAolpYvEFxiKbWsutILedaOUPc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  zDCyVAolpYvEFxiKbWsutILedaOUTh.add_dir(zDCyVAolpYvEFxiKbWsutILedaOUTc,sublabel='',img=zDCyVAolpYvEFxiKbWsutILedaOUPc,infoLabels=zDCyVAolpYvEFxiKbWsutILedaOUPf,isFolder=zDCyVAolpYvEFxiKbWsutILedaOUqc,params=zDCyVAolpYvEFxiKbWsutILedaOUPM,isLink=zDCyVAolpYvEFxiKbWsutILedaOUqf)
  xbmcplugin.endOfDirectory(zDCyVAolpYvEFxiKbWsutILedaOUTh._addon_handle,cacheToDisc=zDCyVAolpYvEFxiKbWsutILedaOUqc)
 def Delete_History_List(zDCyVAolpYvEFxiKbWsutILedaOUTh,zDCyVAolpYvEFxiKbWsutILedaOUPB,zDCyVAolpYvEFxiKbWsutILedaOUkP):
  if zDCyVAolpYvEFxiKbWsutILedaOUkP=='ALL':
   try:
    zDCyVAolpYvEFxiKbWsutILedaOUPT=zDCyVAolpYvEFxiKbWsutILedaOUTm
    fp=zDCyVAolpYvEFxiKbWsutILedaOUmP(zDCyVAolpYvEFxiKbWsutILedaOUPT,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    zDCyVAolpYvEFxiKbWsutILedaOUqN
  else:
   try:
    zDCyVAolpYvEFxiKbWsutILedaOUPT=zDCyVAolpYvEFxiKbWsutILedaOUTm
    zDCyVAolpYvEFxiKbWsutILedaOUPn=zDCyVAolpYvEFxiKbWsutILedaOUTh.Load_Searched_List() 
    fp=zDCyVAolpYvEFxiKbWsutILedaOUmP(zDCyVAolpYvEFxiKbWsutILedaOUPT,'w',-1,'utf-8')
    for zDCyVAolpYvEFxiKbWsutILedaOUPH in zDCyVAolpYvEFxiKbWsutILedaOUPn:
     zDCyVAolpYvEFxiKbWsutILedaOUPS=zDCyVAolpYvEFxiKbWsutILedaOUmT(urllib.parse.parse_qsl(zDCyVAolpYvEFxiKbWsutILedaOUPH))
     zDCyVAolpYvEFxiKbWsutILedaOUkT=zDCyVAolpYvEFxiKbWsutILedaOUPS.get('skey').strip()
     if zDCyVAolpYvEFxiKbWsutILedaOUPB!=zDCyVAolpYvEFxiKbWsutILedaOUkT:
      fp.write(zDCyVAolpYvEFxiKbWsutILedaOUPH)
    fp.close()
   except:
    zDCyVAolpYvEFxiKbWsutILedaOUqN
 def dp_History_Delete(zDCyVAolpYvEFxiKbWsutILedaOUTh,args):
  zDCyVAolpYvEFxiKbWsutILedaOUPB =args.get('skey') 
  zDCyVAolpYvEFxiKbWsutILedaOUkP=args.get('delmode')
  zDCyVAolpYvEFxiKbWsutILedaOUTG=xbmcgui.Dialog()
  if zDCyVAolpYvEFxiKbWsutILedaOUkP=='ALL':
   zDCyVAolpYvEFxiKbWsutILedaOUkn=zDCyVAolpYvEFxiKbWsutILedaOUTG.yesno(__language__(30913).encode('utf8'),__language__(30915).encode('utf8'))
  else:
   zDCyVAolpYvEFxiKbWsutILedaOUkn=zDCyVAolpYvEFxiKbWsutILedaOUTG.yesno(__language__(30914).encode('utf8'),__language__(30915).encode('utf8'))
  if zDCyVAolpYvEFxiKbWsutILedaOUkn==zDCyVAolpYvEFxiKbWsutILedaOUqc:sys.exit()
  zDCyVAolpYvEFxiKbWsutILedaOUTh.Delete_History_List(zDCyVAolpYvEFxiKbWsutILedaOUPB,zDCyVAolpYvEFxiKbWsutILedaOUkP)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(zDCyVAolpYvEFxiKbWsutILedaOUTh):
  zDCyVAolpYvEFxiKbWsutILedaOUTM=zDCyVAolpYvEFxiKbWsutILedaOUTh.get_settings_menubookmark()
  for zDCyVAolpYvEFxiKbWsutILedaOUkq in zDCyVAolpYvEFxiKbWsutILedaOUTk:
   zDCyVAolpYvEFxiKbWsutILedaOUTc=zDCyVAolpYvEFxiKbWsutILedaOUkq.get('title')
   zDCyVAolpYvEFxiKbWsutILedaOUPc=''
   if zDCyVAolpYvEFxiKbWsutILedaOUkq.get('mode')=='MENU_BOOKMARK' and zDCyVAolpYvEFxiKbWsutILedaOUTM==zDCyVAolpYvEFxiKbWsutILedaOUqc:continue
   zDCyVAolpYvEFxiKbWsutILedaOUPM={'mode':zDCyVAolpYvEFxiKbWsutILedaOUkq.get('mode')}
   if zDCyVAolpYvEFxiKbWsutILedaOUkq.get('mode')in['XXX','MENU_BOOKMARK']:
    zDCyVAolpYvEFxiKbWsutILedaOUkm=zDCyVAolpYvEFxiKbWsutILedaOUqc
    zDCyVAolpYvEFxiKbWsutILedaOUkh =zDCyVAolpYvEFxiKbWsutILedaOUqf
   else:
    zDCyVAolpYvEFxiKbWsutILedaOUkm=zDCyVAolpYvEFxiKbWsutILedaOUqf
    zDCyVAolpYvEFxiKbWsutILedaOUkh =zDCyVAolpYvEFxiKbWsutILedaOUqc
   if 'icon' in zDCyVAolpYvEFxiKbWsutILedaOUkq:zDCyVAolpYvEFxiKbWsutILedaOUPc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',zDCyVAolpYvEFxiKbWsutILedaOUkq.get('icon')) 
   zDCyVAolpYvEFxiKbWsutILedaOUTh.add_dir(zDCyVAolpYvEFxiKbWsutILedaOUTc,sublabel='',img=zDCyVAolpYvEFxiKbWsutILedaOUPc,infoLabels=zDCyVAolpYvEFxiKbWsutILedaOUqN,isFolder=zDCyVAolpYvEFxiKbWsutILedaOUkm,params=zDCyVAolpYvEFxiKbWsutILedaOUPM,isLink=zDCyVAolpYvEFxiKbWsutILedaOUkh)
  xbmcplugin.endOfDirectory(zDCyVAolpYvEFxiKbWsutILedaOUTh._addon_handle)
 def option_check(zDCyVAolpYvEFxiKbWsutILedaOUTh):
  zDCyVAolpYvEFxiKbWsutILedaOUTX=zDCyVAolpYvEFxiKbWsutILedaOUTh.get_settings_select_info()
  if zDCyVAolpYvEFxiKbWsutILedaOUmk(zDCyVAolpYvEFxiKbWsutILedaOUTX)==0:
   zDCyVAolpYvEFxiKbWsutILedaOUTG=xbmcgui.Dialog()
   zDCyVAolpYvEFxiKbWsutILedaOUkn=zDCyVAolpYvEFxiKbWsutILedaOUTG.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if zDCyVAolpYvEFxiKbWsutILedaOUkn==zDCyVAolpYvEFxiKbWsutILedaOUqf:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in zDCyVAolpYvEFxiKbWsutILedaOUTX:
   (zDCyVAolpYvEFxiKbWsutILedaOUkH,zDCyVAolpYvEFxiKbWsutILedaOUkS,zDCyVAolpYvEFxiKbWsutILedaOUkw)=zDCyVAolpYvEFxiKbWsutILedaOUTh.get_settings_netflix()
   if zDCyVAolpYvEFxiKbWsutILedaOUkH=='' or zDCyVAolpYvEFxiKbWsutILedaOUkS=='':
    zDCyVAolpYvEFxiKbWsutILedaOUTG=xbmcgui.Dialog()
    zDCyVAolpYvEFxiKbWsutILedaOUkn=zDCyVAolpYvEFxiKbWsutILedaOUTG.yesno(__language__(30902).encode('utf8'),__language__(30903).encode('utf8'))
    if zDCyVAolpYvEFxiKbWsutILedaOUkn==zDCyVAolpYvEFxiKbWsutILedaOUqf:
     __addon__.openSettings()
     sys.exit()
    else:
     sys.exit()
   if zDCyVAolpYvEFxiKbWsutILedaOUTh.NF_cookiefile_check()==zDCyVAolpYvEFxiKbWsutILedaOUqc:
    zDCyVAolpYvEFxiKbWsutILedaOUTG=xbmcgui.Dialog()
    zDCyVAolpYvEFxiKbWsutILedaOUkn=zDCyVAolpYvEFxiKbWsutILedaOUTG.yesno(__language__(30907).encode('utf8'),__language__(30916).encode('utf8'))
    if zDCyVAolpYvEFxiKbWsutILedaOUkn==zDCyVAolpYvEFxiKbWsutILedaOUqf:
     if zDCyVAolpYvEFxiKbWsutILedaOUTh.NF_login(inputCheck=zDCyVAolpYvEFxiKbWsutILedaOUqc)==zDCyVAolpYvEFxiKbWsutILedaOUqc:
      sys.exit()
    else:
     sys.exit()
 def NF_cookiefile_check(zDCyVAolpYvEFxiKbWsutILedaOUTh):
  zDCyVAolpYvEFxiKbWsutILedaOUkg={}
  try: 
   fp=zDCyVAolpYvEFxiKbWsutILedaOUmP(zDCyVAolpYvEFxiKbWsutILedaOUTq,'r',-1,'utf-8')
   zDCyVAolpYvEFxiKbWsutILedaOUkg= json.load(fp)
   fp.close()
  except zDCyVAolpYvEFxiKbWsutILedaOUmn as exception:
   return zDCyVAolpYvEFxiKbWsutILedaOUqc
  zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.NF=zDCyVAolpYvEFxiKbWsutILedaOUkg
  (zDCyVAolpYvEFxiKbWsutILedaOUkH,zDCyVAolpYvEFxiKbWsutILedaOUkS,zDCyVAolpYvEFxiKbWsutILedaOUkw)=zDCyVAolpYvEFxiKbWsutILedaOUTh.get_settings_netflix()
  (zDCyVAolpYvEFxiKbWsutILedaOUkG,zDCyVAolpYvEFxiKbWsutILedaOUkQ,zDCyVAolpYvEFxiKbWsutILedaOUkr)=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Load_session_acount()
  if zDCyVAolpYvEFxiKbWsutILedaOUkH!=zDCyVAolpYvEFxiKbWsutILedaOUkG or zDCyVAolpYvEFxiKbWsutILedaOUkS!=zDCyVAolpYvEFxiKbWsutILedaOUkQ or zDCyVAolpYvEFxiKbWsutILedaOUkw!=zDCyVAolpYvEFxiKbWsutILedaOUmq(zDCyVAolpYvEFxiKbWsutILedaOUkr):
   zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Init_NF_Total()
   return zDCyVAolpYvEFxiKbWsutILedaOUqc
  return zDCyVAolpYvEFxiKbWsutILedaOUqf
 def NF_login(zDCyVAolpYvEFxiKbWsutILedaOUTh,inputCheck=zDCyVAolpYvEFxiKbWsutILedaOUqf):
  (zDCyVAolpYvEFxiKbWsutILedaOUkB,zDCyVAolpYvEFxiKbWsutILedaOUkM,zDCyVAolpYvEFxiKbWsutILedaOUkX)=zDCyVAolpYvEFxiKbWsutILedaOUTh.get_settings_netflix()
  if inputCheck==zDCyVAolpYvEFxiKbWsutILedaOUqf:
   if zDCyVAolpYvEFxiKbWsutILedaOUkB=='' or zDCyVAolpYvEFxiKbWsutILedaOUkM=='':
    zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_noti(__language__(30902).encode('utf-8'))
    return zDCyVAolpYvEFxiKbWsutILedaOUqc
   zDCyVAolpYvEFxiKbWsutILedaOUTG=xbmcgui.Dialog()
   zDCyVAolpYvEFxiKbWsutILedaOUkn=zDCyVAolpYvEFxiKbWsutILedaOUTG.yesno(__language__(30911).encode('utf8'),__language__(30912).encode('utf8'))
   if zDCyVAolpYvEFxiKbWsutILedaOUkn==zDCyVAolpYvEFxiKbWsutILedaOUqc:
    return zDCyVAolpYvEFxiKbWsutILedaOUqc 
  zDCyVAolpYvEFxiKbWsutILedaOUkR=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_NF_BaseCookies()
  if zDCyVAolpYvEFxiKbWsutILedaOUkR:
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_log('pass1 ok!')
  else:
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_log('pass1 error!')
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_noti(__language__(30905).encode('utf-8'))
   return zDCyVAolpYvEFxiKbWsutILedaOUqc 
  zDCyVAolpYvEFxiKbWsutILedaOUkR=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_NF_BaseLogin(zDCyVAolpYvEFxiKbWsutILedaOUkB,zDCyVAolpYvEFxiKbWsutILedaOUkM,zDCyVAolpYvEFxiKbWsutILedaOUkX)
  if zDCyVAolpYvEFxiKbWsutILedaOUkR:
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_log('pass2 ok!')
  else:
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_log('pass2 error!')
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_noti(__language__(30905).encode('utf-8'))
   return zDCyVAolpYvEFxiKbWsutILedaOUqc 
  zDCyVAolpYvEFxiKbWsutILedaOUkR=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_NF_ActivateProfile()
  if zDCyVAolpYvEFxiKbWsutILedaOUkR:
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_log('pass3 ok!')
  else:
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_log('pass3 error!')
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_noti(__language__(30905).encode('utf-8'))
   return zDCyVAolpYvEFxiKbWsutILedaOUqc 
  zDCyVAolpYvEFxiKbWsutILedaOUkR=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_NF_BrowseMain()
  if zDCyVAolpYvEFxiKbWsutILedaOUkR:
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_log('pass4 ok!')
  else:
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_log('pass4 error!')
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_noti(__language__(30905).encode('utf-8'))
   return zDCyVAolpYvEFxiKbWsutILedaOUqc 
  zDCyVAolpYvEFxiKbWsutILedaOUkj =zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_Now_Datetime()
  zDCyVAolpYvEFxiKbWsutILedaOUkN=zDCyVAolpYvEFxiKbWsutILedaOUkj+datetime.timedelta(days=zDCyVAolpYvEFxiKbWsutILedaOUmh(__addon__.getSetting('cache_ttl')))
  zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.NF['SESSION']['limitdate']=zDCyVAolpYvEFxiKbWsutILedaOUkN.strftime('%Y-%m-%d')
  try: 
   fp=zDCyVAolpYvEFxiKbWsutILedaOUmP(zDCyVAolpYvEFxiKbWsutILedaOUTq,'w',-1,'utf-8')
   json.dump(zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.NF,fp,indent=4,ensure_ascii=zDCyVAolpYvEFxiKbWsutILedaOUqc)
   fp.close()
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_log('pass5 save ok!')
  except zDCyVAolpYvEFxiKbWsutILedaOUmn as exception:
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_log('pass5 save error!')
   zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_noti(__language__(30905).encode('utf-8'))
   return zDCyVAolpYvEFxiKbWsutILedaOUqc
  zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_noti(__language__(30904).encode('utf-8'))
  return zDCyVAolpYvEFxiKbWsutILedaOUqf
 def NF_logout(zDCyVAolpYvEFxiKbWsutILedaOUTh):
  zDCyVAolpYvEFxiKbWsutILedaOUTG=xbmcgui.Dialog()
  zDCyVAolpYvEFxiKbWsutILedaOUkn=zDCyVAolpYvEFxiKbWsutILedaOUTG.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if zDCyVAolpYvEFxiKbWsutILedaOUkn==zDCyVAolpYvEFxiKbWsutILedaOUqc:return 
  if os.path.isfile(zDCyVAolpYvEFxiKbWsutILedaOUTq):os.remove(zDCyVAolpYvEFxiKbWsutILedaOUTq)
  zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(zDCyVAolpYvEFxiKbWsutILedaOUTh,zDCyVAolpYvEFxiKbWsutILedaOUnk):
  zDCyVAolpYvEFxiKbWsutILedaOUkc=''
  zDCyVAolpYvEFxiKbWsutILedaOUkJ=7
  try:
   for i in zDCyVAolpYvEFxiKbWsutILedaOUmH(zDCyVAolpYvEFxiKbWsutILedaOUmk(zDCyVAolpYvEFxiKbWsutILedaOUnk)):
    if i>=zDCyVAolpYvEFxiKbWsutILedaOUkJ:
     zDCyVAolpYvEFxiKbWsutILedaOUkc=zDCyVAolpYvEFxiKbWsutILedaOUkc+'...'
     break
    zDCyVAolpYvEFxiKbWsutILedaOUkc=zDCyVAolpYvEFxiKbWsutILedaOUkc+zDCyVAolpYvEFxiKbWsutILedaOUnk[i]['title']+'\n'
  except:
   return ''
  return zDCyVAolpYvEFxiKbWsutILedaOUkc
 def dp_Search_Group(zDCyVAolpYvEFxiKbWsutILedaOUTh,args):
  zDCyVAolpYvEFxiKbWsutILedaOUTX =zDCyVAolpYvEFxiKbWsutILedaOUTh.get_settings_select_info()
  zDCyVAolpYvEFxiKbWsutILedaOUnT=[]
  if 'search_key' in args:
   zDCyVAolpYvEFxiKbWsutILedaOUnP=args.get('search_key')
  else:
   zDCyVAolpYvEFxiKbWsutILedaOUnP=zDCyVAolpYvEFxiKbWsutILedaOUTh.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not zDCyVAolpYvEFxiKbWsutILedaOUnP:
    xbmcplugin.endOfDirectory(zDCyVAolpYvEFxiKbWsutILedaOUTh._addon_handle)
    return
  if 'wavve' in zDCyVAolpYvEFxiKbWsutILedaOUTX:
   (zDCyVAolpYvEFxiKbWsutILedaOUnk,zDCyVAolpYvEFxiKbWsutILedaOUnq)=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_Search_Wavve(zDCyVAolpYvEFxiKbWsutILedaOUnP,'TVSHOW',1)
   if zDCyVAolpYvEFxiKbWsutILedaOUmk(zDCyVAolpYvEFxiKbWsutILedaOUnk)>0:
    zDCyVAolpYvEFxiKbWsutILedaOUnm={'sType':'wavve_tvshow','sList':zDCyVAolpYvEFxiKbWsutILedaOUTh.MakeText_FreeList(zDCyVAolpYvEFxiKbWsutILedaOUnk),}
    zDCyVAolpYvEFxiKbWsutILedaOUnT.append(zDCyVAolpYvEFxiKbWsutILedaOUnm)
   (zDCyVAolpYvEFxiKbWsutILedaOUnk,zDCyVAolpYvEFxiKbWsutILedaOUnq)=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_Search_Wavve(zDCyVAolpYvEFxiKbWsutILedaOUnP,'MOVIE',1)
   if zDCyVAolpYvEFxiKbWsutILedaOUmk(zDCyVAolpYvEFxiKbWsutILedaOUnk)>0:
    zDCyVAolpYvEFxiKbWsutILedaOUnm={'sType':'wavve_movie','sList':zDCyVAolpYvEFxiKbWsutILedaOUTh.MakeText_FreeList(zDCyVAolpYvEFxiKbWsutILedaOUnk),}
    zDCyVAolpYvEFxiKbWsutILedaOUnT.append(zDCyVAolpYvEFxiKbWsutILedaOUnm)
  if 'tving' in zDCyVAolpYvEFxiKbWsutILedaOUTX:
   (zDCyVAolpYvEFxiKbWsutILedaOUnk,zDCyVAolpYvEFxiKbWsutILedaOUnq)=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_Search_Tving(zDCyVAolpYvEFxiKbWsutILedaOUnP,'TVSHOW',1)
   if zDCyVAolpYvEFxiKbWsutILedaOUmk(zDCyVAolpYvEFxiKbWsutILedaOUnk)>0:
    zDCyVAolpYvEFxiKbWsutILedaOUnm={'sType':'tving_tvshow','sList':zDCyVAolpYvEFxiKbWsutILedaOUTh.MakeText_FreeList(zDCyVAolpYvEFxiKbWsutILedaOUnk),}
    zDCyVAolpYvEFxiKbWsutILedaOUnT.append(zDCyVAolpYvEFxiKbWsutILedaOUnm)
   (zDCyVAolpYvEFxiKbWsutILedaOUnk,zDCyVAolpYvEFxiKbWsutILedaOUnq)=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_Search_Tving(zDCyVAolpYvEFxiKbWsutILedaOUnP,'MOVIE',1)
   if zDCyVAolpYvEFxiKbWsutILedaOUmk(zDCyVAolpYvEFxiKbWsutILedaOUnk)>0:
    zDCyVAolpYvEFxiKbWsutILedaOUnm={'sType':'tving_movie','sList':zDCyVAolpYvEFxiKbWsutILedaOUTh.MakeText_FreeList(zDCyVAolpYvEFxiKbWsutILedaOUnk),}
    zDCyVAolpYvEFxiKbWsutILedaOUnT.append(zDCyVAolpYvEFxiKbWsutILedaOUnm)
  if 'watcha' in zDCyVAolpYvEFxiKbWsutILedaOUTX:
   (zDCyVAolpYvEFxiKbWsutILedaOUnk,zDCyVAolpYvEFxiKbWsutILedaOUnq)=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_Search_Watcha(zDCyVAolpYvEFxiKbWsutILedaOUnP,1)
   if zDCyVAolpYvEFxiKbWsutILedaOUmk(zDCyVAolpYvEFxiKbWsutILedaOUnk)>0:
    zDCyVAolpYvEFxiKbWsutILedaOUnm={'sType':'watcha_list','sList':zDCyVAolpYvEFxiKbWsutILedaOUTh.MakeText_FreeList(zDCyVAolpYvEFxiKbWsutILedaOUnk),}
    zDCyVAolpYvEFxiKbWsutILedaOUnT.append(zDCyVAolpYvEFxiKbWsutILedaOUnm)
  if 'netflix' in zDCyVAolpYvEFxiKbWsutILedaOUTX:
   try:
    (zDCyVAolpYvEFxiKbWsutILedaOUnk,zDCyVAolpYvEFxiKbWsutILedaOUnq,zDCyVAolpYvEFxiKbWsutILedaOUnh)=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_Search_Netflix(zDCyVAolpYvEFxiKbWsutILedaOUnP,1)
   except:
    zDCyVAolpYvEFxiKbWsutILedaOUnk=[]
    zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_noti(__language__(30919).encode('utf8'))
   if zDCyVAolpYvEFxiKbWsutILedaOUmk(zDCyVAolpYvEFxiKbWsutILedaOUnk)>0:
    zDCyVAolpYvEFxiKbWsutILedaOUnm={'sType':'netflix_list','sList':zDCyVAolpYvEFxiKbWsutILedaOUTh.MakeText_FreeList(zDCyVAolpYvEFxiKbWsutILedaOUnk),}
    zDCyVAolpYvEFxiKbWsutILedaOUnT.append(zDCyVAolpYvEFxiKbWsutILedaOUnm)
  for zDCyVAolpYvEFxiKbWsutILedaOUnH in zDCyVAolpYvEFxiKbWsutILedaOUnT:
   zDCyVAolpYvEFxiKbWsutILedaOUnS=zDCyVAolpYvEFxiKbWsutILedaOUTn[zDCyVAolpYvEFxiKbWsutILedaOUnH.get('sType')]
   zDCyVAolpYvEFxiKbWsutILedaOUnw={'plot':'검색어 : '+zDCyVAolpYvEFxiKbWsutILedaOUnP+'\n\n'+zDCyVAolpYvEFxiKbWsutILedaOUnH.get('sList')}
   zDCyVAolpYvEFxiKbWsutILedaOUTc=zDCyVAolpYvEFxiKbWsutILedaOUnS.get('title')
   zDCyVAolpYvEFxiKbWsutILedaOUPM={'mode':zDCyVAolpYvEFxiKbWsutILedaOUnS.get('mode'),'ott':zDCyVAolpYvEFxiKbWsutILedaOUnS.get('ott'),'vidtype':zDCyVAolpYvEFxiKbWsutILedaOUnS.get('vidtype'),'search_key':zDCyVAolpYvEFxiKbWsutILedaOUnP}
   if zDCyVAolpYvEFxiKbWsutILedaOUnS.get('ott')=='netflix':
    zDCyVAolpYvEFxiKbWsutILedaOUPM['page'] ='1'
    zDCyVAolpYvEFxiKbWsutILedaOUPM['byReference']='-'
   zDCyVAolpYvEFxiKbWsutILedaOUPc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',zDCyVAolpYvEFxiKbWsutILedaOUnS.get('icon'))
   zDCyVAolpYvEFxiKbWsutILedaOUkm=zDCyVAolpYvEFxiKbWsutILedaOUqf if zDCyVAolpYvEFxiKbWsutILedaOUnS.get('mode')!='HYPER_LINK' else zDCyVAolpYvEFxiKbWsutILedaOUqc
   zDCyVAolpYvEFxiKbWsutILedaOUTh.add_dir(zDCyVAolpYvEFxiKbWsutILedaOUTc,sublabel='',img=zDCyVAolpYvEFxiKbWsutILedaOUPc,infoLabels=zDCyVAolpYvEFxiKbWsutILedaOUnw,isFolder=zDCyVAolpYvEFxiKbWsutILedaOUkm,params=zDCyVAolpYvEFxiKbWsutILedaOUPM,isLink=zDCyVAolpYvEFxiKbWsutILedaOUqf)
  xbmcplugin.endOfDirectory(zDCyVAolpYvEFxiKbWsutILedaOUTh._addon_handle)
  zDCyVAolpYvEFxiKbWsutILedaOUTh.Save_Searched_List(zDCyVAolpYvEFxiKbWsutILedaOUnP)
 def dp_Hyper_Link(zDCyVAolpYvEFxiKbWsutILedaOUTh,args):
  zDCyVAolpYvEFxiKbWsutILedaOUng =args.get('mode')
  zDCyVAolpYvEFxiKbWsutILedaOUnG =args.get('ott')
  zDCyVAolpYvEFxiKbWsutILedaOUnQ =args.get('vidtype')
  zDCyVAolpYvEFxiKbWsutILedaOUnP=args.get('search_key')
  zDCyVAolpYvEFxiKbWsutILedaOUnr='-'
  if zDCyVAolpYvEFxiKbWsutILedaOUnG=='wavve':
   zDCyVAolpYvEFxiKbWsutILedaOUnB={'mode':'LOCAL_SEARCH','sType':'movie' if zDCyVAolpYvEFxiKbWsutILedaOUnQ=='MOVIE' else 'vod','search_key':zDCyVAolpYvEFxiKbWsutILedaOUnP,'page':'1',}
   zDCyVAolpYvEFxiKbWsutILedaOUnM=urllib.parse.urlencode(zDCyVAolpYvEFxiKbWsutILedaOUnB)
   zDCyVAolpYvEFxiKbWsutILedaOUnr='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(zDCyVAolpYvEFxiKbWsutILedaOUnM)
  elif zDCyVAolpYvEFxiKbWsutILedaOUnG=='tving':
   zDCyVAolpYvEFxiKbWsutILedaOUnB={'mode':'LOCAL_SEARCH','stype':'movie' if zDCyVAolpYvEFxiKbWsutILedaOUnQ=='MOVIE' else 'vod','search_key':zDCyVAolpYvEFxiKbWsutILedaOUnP,'page':'1',}
   zDCyVAolpYvEFxiKbWsutILedaOUnM=urllib.parse.urlencode(zDCyVAolpYvEFxiKbWsutILedaOUnB)
   zDCyVAolpYvEFxiKbWsutILedaOUnr='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(zDCyVAolpYvEFxiKbWsutILedaOUnM)
  elif zDCyVAolpYvEFxiKbWsutILedaOUnG=='watcha':
   zDCyVAolpYvEFxiKbWsutILedaOUnB={'mode':'LOCAL_SEARCH','search_key':zDCyVAolpYvEFxiKbWsutILedaOUnP,'page':'1',}
   zDCyVAolpYvEFxiKbWsutILedaOUnM=urllib.parse.urlencode(zDCyVAolpYvEFxiKbWsutILedaOUnB)
   zDCyVAolpYvEFxiKbWsutILedaOUnr='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(zDCyVAolpYvEFxiKbWsutILedaOUnM)
  elif zDCyVAolpYvEFxiKbWsutILedaOUnG=='netflix':
   zDCyVAolpYvEFxiKbWsutILedaOUnX=args.get('videoid')
   zDCyVAolpYvEFxiKbWsutILedaOUnR=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.NF['SESSION']['nowGuid']
   if zDCyVAolpYvEFxiKbWsutILedaOUnQ=='TVSHOW':
    zDCyVAolpYvEFxiKbWsutILedaOUnr='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(zDCyVAolpYvEFxiKbWsutILedaOUnX)
   else:
    zDCyVAolpYvEFxiKbWsutILedaOUnr='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(zDCyVAolpYvEFxiKbWsutILedaOUnX,zDCyVAolpYvEFxiKbWsutILedaOUnR)
  zDCyVAolpYvEFxiKbWsutILedaOUTh.addon_log('ott_url ==> ( '+zDCyVAolpYvEFxiKbWsutILedaOUnr+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(zDCyVAolpYvEFxiKbWsutILedaOUnr)
 def dp_Nf_Search(zDCyVAolpYvEFxiKbWsutILedaOUTh,args):
  zDCyVAolpYvEFxiKbWsutILedaOUnj =zDCyVAolpYvEFxiKbWsutILedaOUmh(args.get('page'))
  zDCyVAolpYvEFxiKbWsutILedaOUnP =args.get('search_key')
  zDCyVAolpYvEFxiKbWsutILedaOUnh=args.get('byReference')
  (zDCyVAolpYvEFxiKbWsutILedaOUnk,zDCyVAolpYvEFxiKbWsutILedaOUnq,zDCyVAolpYvEFxiKbWsutILedaOUnh)=zDCyVAolpYvEFxiKbWsutILedaOUTh.SearchObj.Get_Search_Netflix(zDCyVAolpYvEFxiKbWsutILedaOUnP,zDCyVAolpYvEFxiKbWsutILedaOUnj,byReference=zDCyVAolpYvEFxiKbWsutILedaOUnh)
  for zDCyVAolpYvEFxiKbWsutILedaOUnN in zDCyVAolpYvEFxiKbWsutILedaOUnk:
   zDCyVAolpYvEFxiKbWsutILedaOUnX =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('videoid')
   zDCyVAolpYvEFxiKbWsutILedaOUnQ =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('vidtype')
   zDCyVAolpYvEFxiKbWsutILedaOUTc =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('title')
   zDCyVAolpYvEFxiKbWsutILedaOUnf =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('mpaa')
   zDCyVAolpYvEFxiKbWsutILedaOUnc =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('regularSynopsis')
   zDCyVAolpYvEFxiKbWsutILedaOUnJ =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('dpSupplemental')
   zDCyVAolpYvEFxiKbWsutILedaOUqT=zDCyVAolpYvEFxiKbWsutILedaOUnN.get('sequiturEvidence')
   zDCyVAolpYvEFxiKbWsutILedaOUqP =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('thumbnail')
   zDCyVAolpYvEFxiKbWsutILedaOUqk =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('year')
   zDCyVAolpYvEFxiKbWsutILedaOUqn =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('duration')
   zDCyVAolpYvEFxiKbWsutILedaOUqm =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('info_genre')
   zDCyVAolpYvEFxiKbWsutILedaOUqh =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('director')
   zDCyVAolpYvEFxiKbWsutILedaOUqH =zDCyVAolpYvEFxiKbWsutILedaOUnN.get('cast')
   if zDCyVAolpYvEFxiKbWsutILedaOUnQ=='movie':
    zDCyVAolpYvEFxiKbWsutILedaOUPN=' (%s)'%(zDCyVAolpYvEFxiKbWsutILedaOUmq(zDCyVAolpYvEFxiKbWsutILedaOUqk))
   else:
    zDCyVAolpYvEFxiKbWsutILedaOUPN=''
   zDCyVAolpYvEFxiKbWsutILedaOUqS=''
   if zDCyVAolpYvEFxiKbWsutILedaOUnc:zDCyVAolpYvEFxiKbWsutILedaOUqS=zDCyVAolpYvEFxiKbWsutILedaOUqS+'\n\n'+zDCyVAolpYvEFxiKbWsutILedaOUnc
   if zDCyVAolpYvEFxiKbWsutILedaOUnJ :zDCyVAolpYvEFxiKbWsutILedaOUqS=zDCyVAolpYvEFxiKbWsutILedaOUqS+'\n\n'+zDCyVAolpYvEFxiKbWsutILedaOUnJ
   if zDCyVAolpYvEFxiKbWsutILedaOUqT:zDCyVAolpYvEFxiKbWsutILedaOUqS=zDCyVAolpYvEFxiKbWsutILedaOUqS+'\n\n'+zDCyVAolpYvEFxiKbWsutILedaOUqT
   zDCyVAolpYvEFxiKbWsutILedaOUqS=zDCyVAolpYvEFxiKbWsutILedaOUqS.strip()
   zDCyVAolpYvEFxiKbWsutILedaOUPf={'mediatype':'tvshow' if zDCyVAolpYvEFxiKbWsutILedaOUnQ=='show' else 'movie','title':zDCyVAolpYvEFxiKbWsutILedaOUTc,'mpaa':zDCyVAolpYvEFxiKbWsutILedaOUnf,'plot':zDCyVAolpYvEFxiKbWsutILedaOUqS,'duration':zDCyVAolpYvEFxiKbWsutILedaOUqn,'genre':zDCyVAolpYvEFxiKbWsutILedaOUqm,'director':zDCyVAolpYvEFxiKbWsutILedaOUqh,'cast':zDCyVAolpYvEFxiKbWsutILedaOUqH,'year':zDCyVAolpYvEFxiKbWsutILedaOUqk,}
   zDCyVAolpYvEFxiKbWsutILedaOUPM={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if zDCyVAolpYvEFxiKbWsutILedaOUnQ=='show' else 'MOVIE','videoid':zDCyVAolpYvEFxiKbWsutILedaOUnX,}
   if zDCyVAolpYvEFxiKbWsutILedaOUTh.get_settings_makebookmark():
    zDCyVAolpYvEFxiKbWsutILedaOUqw={'videoid':zDCyVAolpYvEFxiKbWsutILedaOUnX,'vidtype':'tvshow' if zDCyVAolpYvEFxiKbWsutILedaOUnQ=='show' else 'movie','vtitle':zDCyVAolpYvEFxiKbWsutILedaOUTc+zDCyVAolpYvEFxiKbWsutILedaOUPN,'vsubtitle':'','vinfo':zDCyVAolpYvEFxiKbWsutILedaOUPf,'thumbnail':zDCyVAolpYvEFxiKbWsutILedaOUqP,}
    zDCyVAolpYvEFxiKbWsutILedaOUqg=json.dumps(zDCyVAolpYvEFxiKbWsutILedaOUqw)
    zDCyVAolpYvEFxiKbWsutILedaOUqg=urllib.parse.quote(zDCyVAolpYvEFxiKbWsutILedaOUqg)
    zDCyVAolpYvEFxiKbWsutILedaOUqG='RunPlugin(plugin://plugin.video.searchm/?mode=SET_BOOKMARK&bm_param=%s)'%(zDCyVAolpYvEFxiKbWsutILedaOUqg)
    zDCyVAolpYvEFxiKbWsutILedaOUPj=[('(통합) 찜 영상에 추가',zDCyVAolpYvEFxiKbWsutILedaOUqG)]
   else:
    zDCyVAolpYvEFxiKbWsutILedaOUPj=zDCyVAolpYvEFxiKbWsutILedaOUqN
   zDCyVAolpYvEFxiKbWsutILedaOUTh.add_dir(zDCyVAolpYvEFxiKbWsutILedaOUTc+zDCyVAolpYvEFxiKbWsutILedaOUPN,sublabel=zDCyVAolpYvEFxiKbWsutILedaOUqN,img=zDCyVAolpYvEFxiKbWsutILedaOUqP,infoLabels=zDCyVAolpYvEFxiKbWsutILedaOUPf,isFolder=zDCyVAolpYvEFxiKbWsutILedaOUqc,params=zDCyVAolpYvEFxiKbWsutILedaOUPM,isLink=zDCyVAolpYvEFxiKbWsutILedaOUqf,ContextMenu=zDCyVAolpYvEFxiKbWsutILedaOUPj)
  if zDCyVAolpYvEFxiKbWsutILedaOUnq:
   zDCyVAolpYvEFxiKbWsutILedaOUPM={}
   zDCyVAolpYvEFxiKbWsutILedaOUPM['mode'] ='NF_SEARCH' 
   zDCyVAolpYvEFxiKbWsutILedaOUPM['page'] =zDCyVAolpYvEFxiKbWsutILedaOUmq(zDCyVAolpYvEFxiKbWsutILedaOUnj+1)
   zDCyVAolpYvEFxiKbWsutILedaOUPM['search_key']=zDCyVAolpYvEFxiKbWsutILedaOUnP
   zDCyVAolpYvEFxiKbWsutILedaOUPM['byReference']=zDCyVAolpYvEFxiKbWsutILedaOUnh
   zDCyVAolpYvEFxiKbWsutILedaOUTc='[B]%s >>[/B]'%'다음 페이지'
   zDCyVAolpYvEFxiKbWsutILedaOUqQ=zDCyVAolpYvEFxiKbWsutILedaOUmq(zDCyVAolpYvEFxiKbWsutILedaOUnj+1)
   zDCyVAolpYvEFxiKbWsutILedaOUPc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   zDCyVAolpYvEFxiKbWsutILedaOUTh.add_dir(zDCyVAolpYvEFxiKbWsutILedaOUTc,sublabel=zDCyVAolpYvEFxiKbWsutILedaOUqQ,img=zDCyVAolpYvEFxiKbWsutILedaOUPc,infoLabels=zDCyVAolpYvEFxiKbWsutILedaOUqN,isFolder=zDCyVAolpYvEFxiKbWsutILedaOUqf,params=zDCyVAolpYvEFxiKbWsutILedaOUPM)
  xbmcplugin.setContent(zDCyVAolpYvEFxiKbWsutILedaOUTh._addon_handle,'movies')
  xbmcplugin.endOfDirectory(zDCyVAolpYvEFxiKbWsutILedaOUTh._addon_handle)
 def dp_Bookmark_Menu(zDCyVAolpYvEFxiKbWsutILedaOUTh,args):
  zDCyVAolpYvEFxiKbWsutILedaOUnr='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(zDCyVAolpYvEFxiKbWsutILedaOUnr)
 def dp_Set_Bookmark(zDCyVAolpYvEFxiKbWsutILedaOUTh,args):
  zDCyVAolpYvEFxiKbWsutILedaOUqr=urllib.parse.unquote(args.get('bm_param'))
  zDCyVAolpYvEFxiKbWsutILedaOUqr=json.loads(zDCyVAolpYvEFxiKbWsutILedaOUqr)
  zDCyVAolpYvEFxiKbWsutILedaOUnX =zDCyVAolpYvEFxiKbWsutILedaOUqr.get('videoid')
  zDCyVAolpYvEFxiKbWsutILedaOUnQ =zDCyVAolpYvEFxiKbWsutILedaOUqr.get('vidtype')
  zDCyVAolpYvEFxiKbWsutILedaOUqB =zDCyVAolpYvEFxiKbWsutILedaOUqr.get('vtitle')
  zDCyVAolpYvEFxiKbWsutILedaOUqM =zDCyVAolpYvEFxiKbWsutILedaOUqr.get('vsubtitle')
  zDCyVAolpYvEFxiKbWsutILedaOUqX =zDCyVAolpYvEFxiKbWsutILedaOUqr.get('vinfo')
  zDCyVAolpYvEFxiKbWsutILedaOUqP =zDCyVAolpYvEFxiKbWsutILedaOUqr.get('thumbnail')
  zDCyVAolpYvEFxiKbWsutILedaOUTG=xbmcgui.Dialog()
  zDCyVAolpYvEFxiKbWsutILedaOUkn=zDCyVAolpYvEFxiKbWsutILedaOUTG.yesno(__language__(30917).encode('utf8'),zDCyVAolpYvEFxiKbWsutILedaOUqB+' \n\n'+__language__(30918))
  if zDCyVAolpYvEFxiKbWsutILedaOUkn==zDCyVAolpYvEFxiKbWsutILedaOUqc:return
  zDCyVAolpYvEFxiKbWsutILedaOUqR={'indexinfo':{'ott':'netflix','videoid':zDCyVAolpYvEFxiKbWsutILedaOUnX,'vidtype':zDCyVAolpYvEFxiKbWsutILedaOUnQ,},'saveinfo':{'title':zDCyVAolpYvEFxiKbWsutILedaOUqB,'subtitle':zDCyVAolpYvEFxiKbWsutILedaOUqM,'thumbnail':zDCyVAolpYvEFxiKbWsutILedaOUqP,'infoLabels':zDCyVAolpYvEFxiKbWsutILedaOUqX,},}
  zDCyVAolpYvEFxiKbWsutILedaOUqg=json.dumps(zDCyVAolpYvEFxiKbWsutILedaOUqR)
  zDCyVAolpYvEFxiKbWsutILedaOUqg=urllib.parse.quote(zDCyVAolpYvEFxiKbWsutILedaOUqg)
  zDCyVAolpYvEFxiKbWsutILedaOUqG='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(zDCyVAolpYvEFxiKbWsutILedaOUqg)
  xbmc.executebuiltin(zDCyVAolpYvEFxiKbWsutILedaOUqG)
 def search_main(zDCyVAolpYvEFxiKbWsutILedaOUTh):
  zDCyVAolpYvEFxiKbWsutILedaOUng=zDCyVAolpYvEFxiKbWsutILedaOUTh.main_params.get('mode',zDCyVAolpYvEFxiKbWsutILedaOUqN)
  if zDCyVAolpYvEFxiKbWsutILedaOUng=='NFLOGOUT':
   zDCyVAolpYvEFxiKbWsutILedaOUTh.NF_logout()
   return
  elif zDCyVAolpYvEFxiKbWsutILedaOUng=='NFLOGIN':
   zDCyVAolpYvEFxiKbWsutILedaOUTh.NF_login()
   return
  zDCyVAolpYvEFxiKbWsutILedaOUTh.option_check()
  if zDCyVAolpYvEFxiKbWsutILedaOUng is zDCyVAolpYvEFxiKbWsutILedaOUqN:
   zDCyVAolpYvEFxiKbWsutILedaOUTh.dp_Main_List()
  elif zDCyVAolpYvEFxiKbWsutILedaOUng=='TOTAL_SEARCH':
   zDCyVAolpYvEFxiKbWsutILedaOUTh.dp_Search_Group(zDCyVAolpYvEFxiKbWsutILedaOUTh.main_params)
  elif zDCyVAolpYvEFxiKbWsutILedaOUng=='HYPER_LINK':
   zDCyVAolpYvEFxiKbWsutILedaOUTh.dp_Hyper_Link(zDCyVAolpYvEFxiKbWsutILedaOUTh.main_params)
  elif zDCyVAolpYvEFxiKbWsutILedaOUng=='NF_SEARCH':
   zDCyVAolpYvEFxiKbWsutILedaOUTh.dp_Nf_Search(zDCyVAolpYvEFxiKbWsutILedaOUTh.main_params)
  elif zDCyVAolpYvEFxiKbWsutILedaOUng=='TOTAL_HISTORY':
   zDCyVAolpYvEFxiKbWsutILedaOUTh.dp_Search_History(zDCyVAolpYvEFxiKbWsutILedaOUTh.main_params)
  elif zDCyVAolpYvEFxiKbWsutILedaOUng=='HISTORY_REMOVE':
   zDCyVAolpYvEFxiKbWsutILedaOUTh.dp_History_Delete(zDCyVAolpYvEFxiKbWsutILedaOUTh.main_params)
  elif zDCyVAolpYvEFxiKbWsutILedaOUng=='MENU_BOOKMARK':
   zDCyVAolpYvEFxiKbWsutILedaOUTh.dp_Bookmark_Menu(zDCyVAolpYvEFxiKbWsutILedaOUTh.main_params)
  elif zDCyVAolpYvEFxiKbWsutILedaOUng=='SET_BOOKMARK':
   zDCyVAolpYvEFxiKbWsutILedaOUTh.dp_Set_Bookmark(zDCyVAolpYvEFxiKbWsutILedaOUTh.main_params)
  else:
   zDCyVAolpYvEFxiKbWsutILedaOUqN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
