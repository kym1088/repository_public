__author__="NightRain"
ztTrVSNCsKBqgcxbXRPopMWUeiYlHA=object
ztTrVSNCsKBqgcxbXRPopMWUeiYlHn=None
ztTrVSNCsKBqgcxbXRPopMWUeiYlHa=False
ztTrVSNCsKBqgcxbXRPopMWUeiYlHh=int
ztTrVSNCsKBqgcxbXRPopMWUeiYlHw=str
ztTrVSNCsKBqgcxbXRPopMWUeiYlHL=Exception
ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ=print
ztTrVSNCsKBqgcxbXRPopMWUeiYlHy=True
ztTrVSNCsKBqgcxbXRPopMWUeiYlHE=len
ztTrVSNCsKBqgcxbXRPopMWUeiYlHF=open
ztTrVSNCsKBqgcxbXRPopMWUeiYlHO=isinstance
ztTrVSNCsKBqgcxbXRPopMWUeiYlHj=list
ztTrVSNCsKBqgcxbXRPopMWUeiYlHD=dict
ztTrVSNCsKBqgcxbXRPopMWUeiYlHQ=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
class ztTrVSNCsKBqgcxbXRPopMWUeiYlfk(ztTrVSNCsKBqgcxbXRPopMWUeiYlHA):
 def __init__(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu):
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.DEFAULT_HEADER ={'user-agent':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.USER_AGENT}
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_WAVVE ='https://apis.wavve.com'
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_TVING_SEARCH='https://search.tving.com'
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_TVING_IMG ='https://image.tving.com'
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_WATCHA ='https://api-mars.watcha.com'
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_NETFLIX ='https://www.netflix.com'
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_COUPANG ='https://discover.coupangstreaming.com'
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.WAVVE_LIMIT =20 
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.TVING_LIMIT =30
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.WATCHA_LIMIT =30
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_LIMIT =20 
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.COUPANG_LIMIT =10 
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.DERECTOR_LIMIT =4
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.CAST_LIMIT =10
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.GENRE_LIMIT =4
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.TVING_MOVIE_LITE=['2610061','2610161','261062']
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_HEADER={'user-agent':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND1 ='_342x192'
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND2 ='_665x375'
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_PORT ='_342x684'
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LOGO ='_550x124'
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF={}
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']={}
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']={}
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.CP_ORIGINAL_COOKIE =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_ORIGINAL_COOKIE =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_SESSION_COOKIES1 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_SESSION_COOKIES2 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_SESSION_COOKIES3 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_SESSION_COOKIES4 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_SESSION_FULLTEXT1 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_SESSION_FULLTEXT2 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_SESSION_FULLTEXT3 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_SESSION_FULLTEXT4 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_CONTEXTJSON_FILE1 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_CONTEXTJSON_FILE2 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_CONTEXTJSON_FILE3 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_CONTEXTJSON_FILE4 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_FALCORJSON_FILE1 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_FALCORJSON_FILE2 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_FALCORJSON_FILE3 =''
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_FALCORJSON_FILE4 =''
 def callRequestCookies(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,jobtype,ztTrVSNCsKBqgcxbXRPopMWUeiYlfa,payload=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,params=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,headers=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,cookies=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,redirects=ztTrVSNCsKBqgcxbXRPopMWUeiYlHa):
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfd=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.DEFAULT_HEADER
  if headers:ztTrVSNCsKBqgcxbXRPopMWUeiYlfd.update(headers)
  if jobtype=='Get':
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfH=requests.get(ztTrVSNCsKBqgcxbXRPopMWUeiYlfa,params=params,headers=ztTrVSNCsKBqgcxbXRPopMWUeiYlfd,cookies=cookies,allow_redirects=redirects)
  else:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfH=requests.post(ztTrVSNCsKBqgcxbXRPopMWUeiYlfa,data=payload,params=params,headers=ztTrVSNCsKBqgcxbXRPopMWUeiYlfd,cookies=cookies,allow_redirects=redirects)
  return ztTrVSNCsKBqgcxbXRPopMWUeiYlfH
 def GetNoCache(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,timetype=1,minutes=0):
  if timetype==1:
   ts=ztTrVSNCsKBqgcxbXRPopMWUeiYlHh(time.time())
   mi=ztTrVSNCsKBqgcxbXRPopMWUeiYlHh(minutes*60)
  else:
   ts=ztTrVSNCsKBqgcxbXRPopMWUeiYlHh(time.time()*1000)
   mi=ztTrVSNCsKBqgcxbXRPopMWUeiYlHh(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,search_key,sType,page_int):
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfG=[]
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfA=ztTrVSNCsKBqgcxbXRPopMWUeiYlfv=1
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfn=ztTrVSNCsKBqgcxbXRPopMWUeiYlHa
  try:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfa=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_WAVVE+'/cf/search/list.js'
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfh={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':ztTrVSNCsKBqgcxbXRPopMWUeiYlHw((page_int-1)*ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.WAVVE_LIMIT),'limit':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.WAVVE_LIMIT,'orderby':'score'}
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfh.update(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.WAVVE_PARAMS)
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfw=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.callRequestCookies('Get',ztTrVSNCsKBqgcxbXRPopMWUeiYlfa,payload=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,params=ztTrVSNCsKBqgcxbXRPopMWUeiYlfh,headers=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,cookies=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn)
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfL=json.loads(ztTrVSNCsKBqgcxbXRPopMWUeiYlfw.text)
   if not('celllist' in ztTrVSNCsKBqgcxbXRPopMWUeiYlfL['cell_toplist']):return ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfJ=ztTrVSNCsKBqgcxbXRPopMWUeiYlfL['cell_toplist']['celllist']
   for ztTrVSNCsKBqgcxbXRPopMWUeiYlfy in ztTrVSNCsKBqgcxbXRPopMWUeiYlfJ:
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfE =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['event_list'][1]['url']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfF=urllib.parse.urlsplit(ztTrVSNCsKBqgcxbXRPopMWUeiYlfE).query
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfO=ztTrVSNCsKBqgcxbXRPopMWUeiYlfF[0:ztTrVSNCsKBqgcxbXRPopMWUeiYlfF.find('=')]
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfj=ztTrVSNCsKBqgcxbXRPopMWUeiYlfF[ztTrVSNCsKBqgcxbXRPopMWUeiYlfF.find('=')+1:]
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfO='TVSHOW' if ztTrVSNCsKBqgcxbXRPopMWUeiYlfO=='programid' else 'MOVIE' 
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfD=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['title_list'][0]['text']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfQ =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['age']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfI={'title':ztTrVSNCsKBqgcxbXRPopMWUeiYlfD}
    if ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('age')!='21':
     ztTrVSNCsKBqgcxbXRPopMWUeiYlfG.append(ztTrVSNCsKBqgcxbXRPopMWUeiYlfI)
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfA=ztTrVSNCsKBqgcxbXRPopMWUeiYlHh(ztTrVSNCsKBqgcxbXRPopMWUeiYlfL['cell_toplist']['pagecount'])
   if ztTrVSNCsKBqgcxbXRPopMWUeiYlfL['cell_toplist']['count']:ztTrVSNCsKBqgcxbXRPopMWUeiYlfv =ztTrVSNCsKBqgcxbXRPopMWUeiYlHh(ztTrVSNCsKBqgcxbXRPopMWUeiYlfL['cell_toplist']['count'])
   else:ztTrVSNCsKBqgcxbXRPopMWUeiYlfv=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.LIST_LIMIT
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfn=ztTrVSNCsKBqgcxbXRPopMWUeiYlfA>ztTrVSNCsKBqgcxbXRPopMWUeiYlfv
  except ztTrVSNCsKBqgcxbXRPopMWUeiYlHL as exception:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ(exception)
  return ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn 
 def Get_Search_Tving(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,search_key,sType,page_int):
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfG=[]
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfn=ztTrVSNCsKBqgcxbXRPopMWUeiYlHa
  try:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlkf ='/search/getSearch.jsp'
   ztTrVSNCsKBqgcxbXRPopMWUeiYlku={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(page_int),'pageSize':ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.TVING_PARMAS.get('SCREENCODE'),'os':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.TVING_PARMAS.get('OSCODE'),'network':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.GetNoCache(2))}
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfa=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_TVING_SEARCH+ztTrVSNCsKBqgcxbXRPopMWUeiYlkf
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfw=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.callRequestCookies('Get',ztTrVSNCsKBqgcxbXRPopMWUeiYlfa,payload=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,params=ztTrVSNCsKBqgcxbXRPopMWUeiYlku,headers=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,cookies=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn)
   ztTrVSNCsKBqgcxbXRPopMWUeiYlkd=json.loads(ztTrVSNCsKBqgcxbXRPopMWUeiYlfw.text)
   if sType=='TVSHOW':
    if not('programRsb' in ztTrVSNCsKBqgcxbXRPopMWUeiYlkd):return ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkH=ztTrVSNCsKBqgcxbXRPopMWUeiYlkd['programRsb']['dataList']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkm =ztTrVSNCsKBqgcxbXRPopMWUeiYlHh(ztTrVSNCsKBqgcxbXRPopMWUeiYlkd['programRsb']['count'])
    for ztTrVSNCsKBqgcxbXRPopMWUeiYlfy in ztTrVSNCsKBqgcxbXRPopMWUeiYlkH:
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkG=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['mast_cd']
     ztTrVSNCsKBqgcxbXRPopMWUeiYlfD =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['mast_nm']
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkA=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_TVING_IMG+ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['web_url4']
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkn =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_TVING_IMG+ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['web_url']
     try:
      ztTrVSNCsKBqgcxbXRPopMWUeiYlka =[]
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkh=[]
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkw =[]
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkL =0
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkJ =''
      ztTrVSNCsKBqgcxbXRPopMWUeiYlky =''
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkE =''
      if ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('actor') !='' and ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('actor') !='-':ztTrVSNCsKBqgcxbXRPopMWUeiYlka =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('actor').split(',')
      if ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('director')!='' and ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('director')!='-':ztTrVSNCsKBqgcxbXRPopMWUeiYlkh=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('director').split(',')
      if ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('cate_nm')!='' and ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('cate_nm')!='-':ztTrVSNCsKBqgcxbXRPopMWUeiYlkw =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('cate_nm').split('/')
      if 'targetage' in ztTrVSNCsKBqgcxbXRPopMWUeiYlfy:ztTrVSNCsKBqgcxbXRPopMWUeiYlkJ=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('targetage')
      if 'broad_dt' in ztTrVSNCsKBqgcxbXRPopMWUeiYlfy:
       ztTrVSNCsKBqgcxbXRPopMWUeiYlkF=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('broad_dt')
       ztTrVSNCsKBqgcxbXRPopMWUeiYlkE='%s-%s-%s'%(ztTrVSNCsKBqgcxbXRPopMWUeiYlkF[:4],ztTrVSNCsKBqgcxbXRPopMWUeiYlkF[4:6],ztTrVSNCsKBqgcxbXRPopMWUeiYlkF[6:])
       ztTrVSNCsKBqgcxbXRPopMWUeiYlky =ztTrVSNCsKBqgcxbXRPopMWUeiYlkF[:4]
     except:
      ztTrVSNCsKBqgcxbXRPopMWUeiYlHn
     ztTrVSNCsKBqgcxbXRPopMWUeiYlfI={'title':ztTrVSNCsKBqgcxbXRPopMWUeiYlfD,}
     ztTrVSNCsKBqgcxbXRPopMWUeiYlfG.append(ztTrVSNCsKBqgcxbXRPopMWUeiYlfI)
   else:
    if not('vodMVRsb' in ztTrVSNCsKBqgcxbXRPopMWUeiYlkd):return ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkO=ztTrVSNCsKBqgcxbXRPopMWUeiYlkd['vodMVRsb']['dataList']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkm =ztTrVSNCsKBqgcxbXRPopMWUeiYlHh(ztTrVSNCsKBqgcxbXRPopMWUeiYlkd['vodMVRsb']['count'])
    ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ(ztTrVSNCsKBqgcxbXRPopMWUeiYlkm)
    for ztTrVSNCsKBqgcxbXRPopMWUeiYlfy in ztTrVSNCsKBqgcxbXRPopMWUeiYlkO:
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkG=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['mast_cd']
     ztTrVSNCsKBqgcxbXRPopMWUeiYlfD =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['mast_nm'].strip()
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkA =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_TVING_IMG+ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['web_url']
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkn =ztTrVSNCsKBqgcxbXRPopMWUeiYlkA
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkj=''
     try:
      ztTrVSNCsKBqgcxbXRPopMWUeiYlka =[]
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkh=[]
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkw =[]
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkL =0
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkJ =''
      ztTrVSNCsKBqgcxbXRPopMWUeiYlky =''
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkE =''
      if ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('actor') !='' and ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('actor') !='-':ztTrVSNCsKBqgcxbXRPopMWUeiYlka =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('actor').split(',')
      if ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('director')!='' and ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('director')!='-':ztTrVSNCsKBqgcxbXRPopMWUeiYlkh=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('director').split(',')
      if ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('cate_nm')!='' and ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('cate_nm')!='-':ztTrVSNCsKBqgcxbXRPopMWUeiYlkw =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('cate_nm').split('/')
      if ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('runtime_sec')!='':ztTrVSNCsKBqgcxbXRPopMWUeiYlkL=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('runtime_sec')
      if 'grade_nm' in ztTrVSNCsKBqgcxbXRPopMWUeiYlfy:ztTrVSNCsKBqgcxbXRPopMWUeiYlkJ=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('grade_nm')
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkD=''
      ztTrVSNCsKBqgcxbXRPopMWUeiYlkF=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('broad_dt')
      if ztTrVSNCsKBqgcxbXRPopMWUeiYlkD!='':
       ztTrVSNCsKBqgcxbXRPopMWUeiYlkE='%s-%s-%s'%(ztTrVSNCsKBqgcxbXRPopMWUeiYlkF[:4],ztTrVSNCsKBqgcxbXRPopMWUeiYlkF[4:6],ztTrVSNCsKBqgcxbXRPopMWUeiYlkF[6:])
       ztTrVSNCsKBqgcxbXRPopMWUeiYlky =ztTrVSNCsKBqgcxbXRPopMWUeiYlkF[:4]
     except:
      ztTrVSNCsKBqgcxbXRPopMWUeiYlHn
     ztTrVSNCsKBqgcxbXRPopMWUeiYlfI={'title':ztTrVSNCsKBqgcxbXRPopMWUeiYlfD,}
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkQ=ztTrVSNCsKBqgcxbXRPopMWUeiYlHa
     for ztTrVSNCsKBqgcxbXRPopMWUeiYlkI in ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['bill']:
      if ztTrVSNCsKBqgcxbXRPopMWUeiYlkI in ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.TVING_MOVIE_LITE:
       ztTrVSNCsKBqgcxbXRPopMWUeiYlkQ=ztTrVSNCsKBqgcxbXRPopMWUeiYlHy
       break
     if ztTrVSNCsKBqgcxbXRPopMWUeiYlkQ==ztTrVSNCsKBqgcxbXRPopMWUeiYlHa: 
      ztTrVSNCsKBqgcxbXRPopMWUeiYlfI['title']=ztTrVSNCsKBqgcxbXRPopMWUeiYlfI['title']+' [개별구매]'
     ztTrVSNCsKBqgcxbXRPopMWUeiYlfG.append(ztTrVSNCsKBqgcxbXRPopMWUeiYlfI)
   if ztTrVSNCsKBqgcxbXRPopMWUeiYlkm>(page_int*ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.TVING_LIMIT):ztTrVSNCsKBqgcxbXRPopMWUeiYlfn=ztTrVSNCsKBqgcxbXRPopMWUeiYlHy
  except ztTrVSNCsKBqgcxbXRPopMWUeiYlHL as exception:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ(exception)
  return ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn
 def Get_Search_Watcha(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,search_key,page_int):
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfG=[]
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfn=ztTrVSNCsKBqgcxbXRPopMWUeiYlHa
  try:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfa=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_WATCHA+'/api/search.json'
   ztTrVSNCsKBqgcxbXRPopMWUeiYlku={'query':search_key,'page':ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(page_int),'per':ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.WATCHA_LIMIT),'exclude':'limited',}
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfw=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.callRequestCookies('Get',ztTrVSNCsKBqgcxbXRPopMWUeiYlfa,payload=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,params=ztTrVSNCsKBqgcxbXRPopMWUeiYlku,headers=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.WATCHA_HEADER,cookies=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn)
   ztTrVSNCsKBqgcxbXRPopMWUeiYlkd=json.loads(ztTrVSNCsKBqgcxbXRPopMWUeiYlfw.text)
   if not('results' in ztTrVSNCsKBqgcxbXRPopMWUeiYlkd):return ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn
   ztTrVSNCsKBqgcxbXRPopMWUeiYlkv=ztTrVSNCsKBqgcxbXRPopMWUeiYlkd['results']
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfn=ztTrVSNCsKBqgcxbXRPopMWUeiYlkd['meta']['has_next']
   for ztTrVSNCsKBqgcxbXRPopMWUeiYlfy in ztTrVSNCsKBqgcxbXRPopMWUeiYlkv:
    ztTrVSNCsKBqgcxbXRPopMWUeiYluf =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['code']
    ztTrVSNCsKBqgcxbXRPopMWUeiYluk=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['content_type']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlud =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['title']
    ztTrVSNCsKBqgcxbXRPopMWUeiYluH =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['story']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkA=ztTrVSNCsKBqgcxbXRPopMWUeiYlkn=ztTrVSNCsKBqgcxbXRPopMWUeiYldQ=''
    if ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('poster') !=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn:ztTrVSNCsKBqgcxbXRPopMWUeiYlkA=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('poster').get('original')
    if ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('stillcut')!=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn:ztTrVSNCsKBqgcxbXRPopMWUeiYlkn =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('stillcut').get('large')
    if ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('thumbnail')!=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn:ztTrVSNCsKBqgcxbXRPopMWUeiYldQ=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('thumbnail').get('large')
    if ztTrVSNCsKBqgcxbXRPopMWUeiYldQ=='' :ztTrVSNCsKBqgcxbXRPopMWUeiYldQ=ztTrVSNCsKBqgcxbXRPopMWUeiYlkn
    ztTrVSNCsKBqgcxbXRPopMWUeiYlum={'thumb':ztTrVSNCsKBqgcxbXRPopMWUeiYlkn,'poster':ztTrVSNCsKBqgcxbXRPopMWUeiYlkA,'fanart':ztTrVSNCsKBqgcxbXRPopMWUeiYldQ}
    ztTrVSNCsKBqgcxbXRPopMWUeiYlky =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['year']
    ztTrVSNCsKBqgcxbXRPopMWUeiYluG =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['film_rating_code']
    ztTrVSNCsKBqgcxbXRPopMWUeiYluA=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['film_rating_short']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlun =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['film_rating_long']
    if ztTrVSNCsKBqgcxbXRPopMWUeiYluk=='movies':
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkL =ztTrVSNCsKBqgcxbXRPopMWUeiYlfy['duration']
    else:
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkL ='0'
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfI={'title':ztTrVSNCsKBqgcxbXRPopMWUeiYlud,}
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfG.append(ztTrVSNCsKBqgcxbXRPopMWUeiYlfI)
  except ztTrVSNCsKBqgcxbXRPopMWUeiYlHL as exception:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ(exception)
  return ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn
 def Get_Search_Coupang(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,search_key,page_int):
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfG=[]
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfn=ztTrVSNCsKBqgcxbXRPopMWUeiYlHa
  try:
   CP=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.jsonfile_To_dic(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.CP_ORIGINAL_COOKIE)
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfa=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_COUPANG+'/v2/search' 
   ztTrVSNCsKBqgcxbXRPopMWUeiYlku={'query':search_key,'platform':'WEBCLIENT','page':ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(page_int),'perPage':ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.COUPANG_LIMIT),}
   ztTrVSNCsKBqgcxbXRPopMWUeiYlua={'x-membersrl':CP['SESSION']['member_srl'],'x-pcid':CP['SESSION']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfw=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.callRequestCookies('Get',ztTrVSNCsKBqgcxbXRPopMWUeiYlfa,payload=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,params=ztTrVSNCsKBqgcxbXRPopMWUeiYlku,headers=ztTrVSNCsKBqgcxbXRPopMWUeiYlua,cookies=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn)
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfL=json.loads(ztTrVSNCsKBqgcxbXRPopMWUeiYlfw.text)
   if ztTrVSNCsKBqgcxbXRPopMWUeiYlHE(ztTrVSNCsKBqgcxbXRPopMWUeiYlfL.get('data').get('data'))==0:return ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn
   for ztTrVSNCsKBqgcxbXRPopMWUeiYlfy in ztTrVSNCsKBqgcxbXRPopMWUeiYlfL.get('data').get('data'):
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfy=ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('data')
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfI={'title':ztTrVSNCsKBqgcxbXRPopMWUeiYlfy.get('title'),}
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfG.append(ztTrVSNCsKBqgcxbXRPopMWUeiYlfI)
   if ztTrVSNCsKBqgcxbXRPopMWUeiYlfL.get('pagination').get('totalPages')>page_int:
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfn=ztTrVSNCsKBqgcxbXRPopMWUeiYlHy
  except ztTrVSNCsKBqgcxbXRPopMWUeiYlHL as exception:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ(exception)
  return ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn
 def dic_To_jsonfile(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,filename,ztTrVSNCsKBqgcxbXRPopMWUeiYluh):
  if filename=='':return
  fp=ztTrVSNCsKBqgcxbXRPopMWUeiYlHF(filename,'w',-1,'utf-8')
  json.dump(ztTrVSNCsKBqgcxbXRPopMWUeiYluh,fp,indent=4,ensure_ascii=ztTrVSNCsKBqgcxbXRPopMWUeiYlHa)
  fp.close()
 def jsonfile_To_dic(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,filename):
  if filename=='':return ztTrVSNCsKBqgcxbXRPopMWUeiYlHn
  try:
   fp=ztTrVSNCsKBqgcxbXRPopMWUeiYlHF(filename,'r',-1,'utf-8')
   ztTrVSNCsKBqgcxbXRPopMWUeiYluL=json.load(fp)
   fp.close()
  except:
   ztTrVSNCsKBqgcxbXRPopMWUeiYluL={}
  return ztTrVSNCsKBqgcxbXRPopMWUeiYluL
 def tempFileSave(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,filename,resText):
  if filename=='':return
  fp=ztTrVSNCsKBqgcxbXRPopMWUeiYlHF(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,filename):
  if filename=='':return
  try:
   fp=ztTrVSNCsKBqgcxbXRPopMWUeiYlHF(filename,'r',-1,'utf-8')
   ztTrVSNCsKBqgcxbXRPopMWUeiYluL=fp.read()
   fp.close()
  except:
   ztTrVSNCsKBqgcxbXRPopMWUeiYluL=''
  return ztTrVSNCsKBqgcxbXRPopMWUeiYluL
 def Init_NF_Total(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu):
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF={}
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']={}
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']={}
 def make_NF_XnetflixHeaders(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu):
  ztTrVSNCsKBqgcxbXRPopMWUeiYlua={'x-netflix.browsername':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['esnModel'],'x-netflix.esnprefix':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['nowGuid'],'x-netflix.uiversion':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return ztTrVSNCsKBqgcxbXRPopMWUeiYlua
 def make_NF_ApiParams(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu):
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfh={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['identifier']),}
  return ztTrVSNCsKBqgcxbXRPopMWUeiYlfh
 def extract_json(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,content,name):
  ztTrVSNCsKBqgcxbXRPopMWUeiYluJ=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  ztTrVSNCsKBqgcxbXRPopMWUeiYluy=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn
  ztTrVSNCsKBqgcxbXRPopMWUeiYluE=re.compile(ztTrVSNCsKBqgcxbXRPopMWUeiYluJ.format(name),re.DOTALL).findall(content)
  ztTrVSNCsKBqgcxbXRPopMWUeiYluy=ztTrVSNCsKBqgcxbXRPopMWUeiYluE[0]
  ztTrVSNCsKBqgcxbXRPopMWUeiYluF=ztTrVSNCsKBqgcxbXRPopMWUeiYluy.replace('\\"','\\\\"') 
  ztTrVSNCsKBqgcxbXRPopMWUeiYluF=ztTrVSNCsKBqgcxbXRPopMWUeiYluF.replace('\\s','\\\\s') 
  ztTrVSNCsKBqgcxbXRPopMWUeiYluF=ztTrVSNCsKBqgcxbXRPopMWUeiYluF.replace('\\n','\\\\n') 
  ztTrVSNCsKBqgcxbXRPopMWUeiYluF=ztTrVSNCsKBqgcxbXRPopMWUeiYluF.replace('\\t','\\\\t') 
  ztTrVSNCsKBqgcxbXRPopMWUeiYluF=ztTrVSNCsKBqgcxbXRPopMWUeiYluF.encode().decode('unicode_escape') 
  ztTrVSNCsKBqgcxbXRPopMWUeiYluF=re.sub(r'\\(?!["])',r'\\\\',ztTrVSNCsKBqgcxbXRPopMWUeiYluF) 
  return json.loads(ztTrVSNCsKBqgcxbXRPopMWUeiYluF)
 def NF_makestr_paths(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,paths):
  ztTrVSNCsKBqgcxbXRPopMWUeiYluL=[]
  if ztTrVSNCsKBqgcxbXRPopMWUeiYlHO(paths,ztTrVSNCsKBqgcxbXRPopMWUeiYlHh):
   return '%d'%(paths)
  elif ztTrVSNCsKBqgcxbXRPopMWUeiYlHO(paths,ztTrVSNCsKBqgcxbXRPopMWUeiYlHw):
   return '"%s"'%(paths)
  for ztTrVSNCsKBqgcxbXRPopMWUeiYluO in paths:
   if ztTrVSNCsKBqgcxbXRPopMWUeiYlHO(ztTrVSNCsKBqgcxbXRPopMWUeiYluO,ztTrVSNCsKBqgcxbXRPopMWUeiYlHh):
    ztTrVSNCsKBqgcxbXRPopMWUeiYluL.append('%d'%(ztTrVSNCsKBqgcxbXRPopMWUeiYluO))
   elif ztTrVSNCsKBqgcxbXRPopMWUeiYlHO(ztTrVSNCsKBqgcxbXRPopMWUeiYluO,ztTrVSNCsKBqgcxbXRPopMWUeiYlHw):
    ztTrVSNCsKBqgcxbXRPopMWUeiYluL.append('"%s"'%(ztTrVSNCsKBqgcxbXRPopMWUeiYluO))
   elif ztTrVSNCsKBqgcxbXRPopMWUeiYlHO(ztTrVSNCsKBqgcxbXRPopMWUeiYluO,ztTrVSNCsKBqgcxbXRPopMWUeiYlHj):
    ztTrVSNCsKBqgcxbXRPopMWUeiYluL.append('[%s]'%(','.join(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_makestr_paths(ztTrVSNCsKBqgcxbXRPopMWUeiYluO))))
   elif ztTrVSNCsKBqgcxbXRPopMWUeiYlHO(ztTrVSNCsKBqgcxbXRPopMWUeiYluO,ztTrVSNCsKBqgcxbXRPopMWUeiYlHD):
    ztTrVSNCsKBqgcxbXRPopMWUeiYluj=''
    for ztTrVSNCsKBqgcxbXRPopMWUeiYluD,ztTrVSNCsKBqgcxbXRPopMWUeiYluQ in ztTrVSNCsKBqgcxbXRPopMWUeiYluO.items():
     ztTrVSNCsKBqgcxbXRPopMWUeiYluj+='"%s":%s,'%(ztTrVSNCsKBqgcxbXRPopMWUeiYluD,ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_makestr_paths(ztTrVSNCsKBqgcxbXRPopMWUeiYluQ))
    ztTrVSNCsKBqgcxbXRPopMWUeiYluL.append('{%s}'%(ztTrVSNCsKBqgcxbXRPopMWUeiYluj[:-1]))
  return ztTrVSNCsKBqgcxbXRPopMWUeiYluL
 def NF_Call_pathapi(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,ztTrVSNCsKBqgcxbXRPopMWUeiYldh,referer=''):
  ztTrVSNCsKBqgcxbXRPopMWUeiYluI='%s/nq/website/memberapi/%s/pathEvaluator'%(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_NETFLIX,ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['identifier'])
  ztTrVSNCsKBqgcxbXRPopMWUeiYluv={'path':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_makestr_paths(ztTrVSNCsKBqgcxbXRPopMWUeiYldh),'authURL':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']['authURL']}
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfh=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.make_NF_ApiParams()
  ztTrVSNCsKBqgcxbXRPopMWUeiYlua={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':ztTrVSNCsKBqgcxbXRPopMWUeiYlua['referer']=referer
  ztTrVSNCsKBqgcxbXRPopMWUeiYldf=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.make_NF_XnetflixHeaders()
  ztTrVSNCsKBqgcxbXRPopMWUeiYlua.update(ztTrVSNCsKBqgcxbXRPopMWUeiYldf)
  ztTrVSNCsKBqgcxbXRPopMWUeiYldk=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_Get_DefaultCookies()
  ztTrVSNCsKBqgcxbXRPopMWUeiYldk['profilesNewSession']='0'
  try:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfw=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.callRequestCookies('Post',ztTrVSNCsKBqgcxbXRPopMWUeiYluI,payload=ztTrVSNCsKBqgcxbXRPopMWUeiYluv,params=ztTrVSNCsKBqgcxbXRPopMWUeiYlfh,headers=ztTrVSNCsKBqgcxbXRPopMWUeiYlua,cookies=ztTrVSNCsKBqgcxbXRPopMWUeiYldk)
   return ztTrVSNCsKBqgcxbXRPopMWUeiYlfw
  except ztTrVSNCsKBqgcxbXRPopMWUeiYlHL as exception:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ(exception)
   return ztTrVSNCsKBqgcxbXRPopMWUeiYlHn
 def Get_Search_Netflix(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,search_key,page_int,byReference=''):
  ztTrVSNCsKBqgcxbXRPopMWUeiYldu=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.DERECTOR_LIMIT
  ztTrVSNCsKBqgcxbXRPopMWUeiYldH =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.CAST_LIMIT
  ztTrVSNCsKBqgcxbXRPopMWUeiYldm =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.GENRE_LIMIT
  ztTrVSNCsKBqgcxbXRPopMWUeiYldG =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_LIMIT*(page_int-1)
  ztTrVSNCsKBqgcxbXRPopMWUeiYldA =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_LIMIT*page_int 
  ztTrVSNCsKBqgcxbXRPopMWUeiYldn="|%s"%(search_key)
  ztTrVSNCsKBqgcxbXRPopMWUeiYlda ='%s/search?%s'%(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   ztTrVSNCsKBqgcxbXRPopMWUeiYldh=[["search","byTerm",ztTrVSNCsKBqgcxbXRPopMWUeiYldn,"titles",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_LIMIT,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"summary"],["search","byTerm",ztTrVSNCsKBqgcxbXRPopMWUeiYldn,"titles",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_LIMIT,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",ztTrVSNCsKBqgcxbXRPopMWUeiYldn,"titles",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_LIMIT,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference","boxarts",[ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND2,ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_PORT],"jpg"],["search","byTerm",ztTrVSNCsKBqgcxbXRPopMWUeiYldn,"titles",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_LIMIT,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference","interestingMoment",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND1,"jpg"],["search","byTerm",ztTrVSNCsKBqgcxbXRPopMWUeiYldn,"titles",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_LIMIT,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference","storyArt",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND2,"jpg"],["search","byTerm",ztTrVSNCsKBqgcxbXRPopMWUeiYldn,"titles",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_LIMIT,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference",["cast","creators","directors"],{"from":0,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldu},["id","name"]],["search","byTerm",ztTrVSNCsKBqgcxbXRPopMWUeiYldn,"titles",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_LIMIT,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference","genres",{"from":0,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldm},["id","name"]],["search","byTerm",ztTrVSNCsKBqgcxbXRPopMWUeiYldn,"titles",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NETFLIX_LIMIT,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LOGO,"png"],]
  else:
   ztTrVSNCsKBqgcxbXRPopMWUeiYldh=[["search","byReference",byReference,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"summary"],["search","byReference",byReference,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference","boxarts",[ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND2,ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference","interestingMoment",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference","storyArt",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference",["cast","creators","directors"],{"from":0,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldu},["id","name"]],["search","byReference",byReference,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference","genres",{"from":0,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldm},["id","name"]],["search","byReference",byReference,{"from":ztTrVSNCsKBqgcxbXRPopMWUeiYldG,"to":ztTrVSNCsKBqgcxbXRPopMWUeiYldA},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LOGO,"png"],]
  try:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfw=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_Call_pathapi(ztTrVSNCsKBqgcxbXRPopMWUeiYldh,ztTrVSNCsKBqgcxbXRPopMWUeiYlda)
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfL=json.loads(ztTrVSNCsKBqgcxbXRPopMWUeiYlfw.text)
  except ztTrVSNCsKBqgcxbXRPopMWUeiYlHL as exception:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ(exception)
  (ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn,byReference)=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.Search_Netflix_Make(ztTrVSNCsKBqgcxbXRPopMWUeiYlfL)
  return ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn,byReference
 def Search_Netflix_Make(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,jsonSource):
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfG=[]
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfn =ztTrVSNCsKBqgcxbXRPopMWUeiYlHa
  ztTrVSNCsKBqgcxbXRPopMWUeiYldw=''
  ztTrVSNCsKBqgcxbXRPopMWUeiYldL=jsonSource.get('paths')[0][1]
  if ztTrVSNCsKBqgcxbXRPopMWUeiYldL=='byTerm':
   ztTrVSNCsKBqgcxbXRPopMWUeiYldG =jsonSource['paths'][0][5]['from']
   ztTrVSNCsKBqgcxbXRPopMWUeiYldA =jsonSource['paths'][0][5]['to']
  else:
   ztTrVSNCsKBqgcxbXRPopMWUeiYldG =jsonSource['paths'][0][3]['from']
   ztTrVSNCsKBqgcxbXRPopMWUeiYldA =jsonSource['paths'][0][3]['to']
  ztTrVSNCsKBqgcxbXRPopMWUeiYldw=ztTrVSNCsKBqgcxbXRPopMWUeiYlHj(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  ztTrVSNCsKBqgcxbXRPopMWUeiYldJ=jsonSource.get('jsonGraph').get('search').get('byReference').get(ztTrVSNCsKBqgcxbXRPopMWUeiYldw)
  ztTrVSNCsKBqgcxbXRPopMWUeiYldy =jsonSource.get('jsonGraph').get('videos')
  ztTrVSNCsKBqgcxbXRPopMWUeiYldE=jsonSource.get('jsonGraph').get('person')
  ztTrVSNCsKBqgcxbXRPopMWUeiYldF=jsonSource.get('jsonGraph').get('genres')
  ztTrVSNCsKBqgcxbXRPopMWUeiYlfn=ztTrVSNCsKBqgcxbXRPopMWUeiYlHy if ztTrVSNCsKBqgcxbXRPopMWUeiYldJ[ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(ztTrVSNCsKBqgcxbXRPopMWUeiYldA)]['reference']['$type']=='ref' else ztTrVSNCsKBqgcxbXRPopMWUeiYlHa
  for ztTrVSNCsKBqgcxbXRPopMWUeiYldO in ztTrVSNCsKBqgcxbXRPopMWUeiYlHQ(ztTrVSNCsKBqgcxbXRPopMWUeiYldG,ztTrVSNCsKBqgcxbXRPopMWUeiYldA):
   if ztTrVSNCsKBqgcxbXRPopMWUeiYldJ[ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(ztTrVSNCsKBqgcxbXRPopMWUeiYldO)]['reference']['$type']=='ref':
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfj =ztTrVSNCsKBqgcxbXRPopMWUeiYldJ[ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(ztTrVSNCsKBqgcxbXRPopMWUeiYldO)]['reference']['value'][1]
    ztTrVSNCsKBqgcxbXRPopMWUeiYldj=ztTrVSNCsKBqgcxbXRPopMWUeiYldy[ztTrVSNCsKBqgcxbXRPopMWUeiYlfj]
    ztTrVSNCsKBqgcxbXRPopMWUeiYlud =ztTrVSNCsKBqgcxbXRPopMWUeiYldj['title']['value']
    if ztTrVSNCsKBqgcxbXRPopMWUeiYldj['availability']['value']['isPlayable']==ztTrVSNCsKBqgcxbXRPopMWUeiYlHa:
     continue
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfO =ztTrVSNCsKBqgcxbXRPopMWUeiYldj['summary']['value']['type']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkL =0 if ztTrVSNCsKBqgcxbXRPopMWUeiYlfO!='movie' else ztTrVSNCsKBqgcxbXRPopMWUeiYldj['runtime']['value']
    if ztTrVSNCsKBqgcxbXRPopMWUeiYldj['sequiturEvidence']['value']['value']:
     ztTrVSNCsKBqgcxbXRPopMWUeiYldD=ztTrVSNCsKBqgcxbXRPopMWUeiYldj['sequiturEvidence']['value']['value']['text']
    else:
     ztTrVSNCsKBqgcxbXRPopMWUeiYldD=''
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkA =ztTrVSNCsKBqgcxbXRPopMWUeiYldj['boxarts'][ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_PORT]['jpg']['value']['url']
    ztTrVSNCsKBqgcxbXRPopMWUeiYldQ =ztTrVSNCsKBqgcxbXRPopMWUeiYldj['boxarts'][ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND2]['jpg']['value']['url']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkn=''
    if 'value' in ztTrVSNCsKBqgcxbXRPopMWUeiYldj['storyArt'][ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND2]['jpg']:
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkn =ztTrVSNCsKBqgcxbXRPopMWUeiYldj['storyArt'][ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND2]['jpg']['value']['url']
    if ztTrVSNCsKBqgcxbXRPopMWUeiYlkn=='' and 'value' in ztTrVSNCsKBqgcxbXRPopMWUeiYldj['interestingMoment'][ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND1]['jpg']:
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkn =ztTrVSNCsKBqgcxbXRPopMWUeiYldj['interestingMoment'][ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LAND1]['jpg']['value']['url']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkj=''
    if 'value' in ztTrVSNCsKBqgcxbXRPopMWUeiYldj['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LOGO]['png']:
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkj=ztTrVSNCsKBqgcxbXRPopMWUeiYldj['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.ART_SIZE_LOGO]['png']['value']['url']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkw =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_Subid_List(ztTrVSNCsKBqgcxbXRPopMWUeiYldj['genres'])
    for i in ztTrVSNCsKBqgcxbXRPopMWUeiYlHQ(ztTrVSNCsKBqgcxbXRPopMWUeiYlHE(ztTrVSNCsKBqgcxbXRPopMWUeiYlkw)):
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkw[i]=ztTrVSNCsKBqgcxbXRPopMWUeiYldF[ztTrVSNCsKBqgcxbXRPopMWUeiYlkw[i]]['name']['value']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkh=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_Subid_List(ztTrVSNCsKBqgcxbXRPopMWUeiYldj['directors'])
    ztTrVSNCsKBqgcxbXRPopMWUeiYldI =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_Subid_List(ztTrVSNCsKBqgcxbXRPopMWUeiYldj['creators'])
    ztTrVSNCsKBqgcxbXRPopMWUeiYlkh.extend(ztTrVSNCsKBqgcxbXRPopMWUeiYldI)
    for i in ztTrVSNCsKBqgcxbXRPopMWUeiYlHQ(ztTrVSNCsKBqgcxbXRPopMWUeiYlHE(ztTrVSNCsKBqgcxbXRPopMWUeiYlkh)):
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkh[i]=ztTrVSNCsKBqgcxbXRPopMWUeiYldE[ztTrVSNCsKBqgcxbXRPopMWUeiYlkh[i]]['name']['value']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlka=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_Subid_List(ztTrVSNCsKBqgcxbXRPopMWUeiYldj['cast'])
    for i in ztTrVSNCsKBqgcxbXRPopMWUeiYlHQ(ztTrVSNCsKBqgcxbXRPopMWUeiYlHE(ztTrVSNCsKBqgcxbXRPopMWUeiYlka)):
     ztTrVSNCsKBqgcxbXRPopMWUeiYlka[i]=ztTrVSNCsKBqgcxbXRPopMWUeiYldE[ztTrVSNCsKBqgcxbXRPopMWUeiYlka[i]]['name']['value']
    if 'maturityDescription' in ztTrVSNCsKBqgcxbXRPopMWUeiYldj['maturity']['value']['rating']:
     ztTrVSNCsKBqgcxbXRPopMWUeiYlkJ=ztTrVSNCsKBqgcxbXRPopMWUeiYldj['maturity']['value']['rating']['maturityDescription']
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfI={'videoid':ztTrVSNCsKBqgcxbXRPopMWUeiYlfj,'vidtype':ztTrVSNCsKBqgcxbXRPopMWUeiYlfO,'title':ztTrVSNCsKBqgcxbXRPopMWUeiYlud,'mpaa':ztTrVSNCsKBqgcxbXRPopMWUeiYlkJ,'regularSynopsis':ztTrVSNCsKBqgcxbXRPopMWUeiYldj['regularSynopsis']['value'],'dpSupplemental':ztTrVSNCsKBqgcxbXRPopMWUeiYldj['dpSupplementalMessage']['value'],'sequiturEvidence':ztTrVSNCsKBqgcxbXRPopMWUeiYldD,'thumbnail':{'poster':ztTrVSNCsKBqgcxbXRPopMWUeiYlkA,'thumb':ztTrVSNCsKBqgcxbXRPopMWUeiYlkn,'fanart':ztTrVSNCsKBqgcxbXRPopMWUeiYldQ,'clearlogo':ztTrVSNCsKBqgcxbXRPopMWUeiYlkj},'year':ztTrVSNCsKBqgcxbXRPopMWUeiYldj['releaseYear']['value'],'duration':ztTrVSNCsKBqgcxbXRPopMWUeiYlkL,'info_genre':ztTrVSNCsKBqgcxbXRPopMWUeiYlkw,'director':ztTrVSNCsKBqgcxbXRPopMWUeiYlkh,'cast':ztTrVSNCsKBqgcxbXRPopMWUeiYlka,}
    ztTrVSNCsKBqgcxbXRPopMWUeiYlfG.append(ztTrVSNCsKBqgcxbXRPopMWUeiYlfI)
  return ztTrVSNCsKBqgcxbXRPopMWUeiYlfG,ztTrVSNCsKBqgcxbXRPopMWUeiYlfn,ztTrVSNCsKBqgcxbXRPopMWUeiYldw
 def NF_Subid_List(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,subJson):
  ztTrVSNCsKBqgcxbXRPopMWUeiYldv=[]
  try:
   for i in ztTrVSNCsKBqgcxbXRPopMWUeiYlHQ(ztTrVSNCsKBqgcxbXRPopMWUeiYlHE(subJson)):
    if subJson.get(ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(i)).get('$type')!='ref':break
    ztTrVSNCsKBqgcxbXRPopMWUeiYlHf=subJson.get(ztTrVSNCsKBqgcxbXRPopMWUeiYlHw(i)).get('value')[1]
    ztTrVSNCsKBqgcxbXRPopMWUeiYldv.append(ztTrVSNCsKBqgcxbXRPopMWUeiYlHf)
  except ztTrVSNCsKBqgcxbXRPopMWUeiYlHL as exception:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ(exception)
  return ztTrVSNCsKBqgcxbXRPopMWUeiYldv
 def NF_CookieFile_Load(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu,cookie_filename):
  ztTrVSNCsKBqgcxbXRPopMWUeiYldk={}
  try:
   if os.path.isfile(cookie_filename)==ztTrVSNCsKBqgcxbXRPopMWUeiYlHa:return{}
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHk=ztTrVSNCsKBqgcxbXRPopMWUeiYlHF(cookie_filename,'rb',-1)
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHu =pickle.loads(ztTrVSNCsKBqgcxbXRPopMWUeiYlHk.read())
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHk.close()
   for ztTrVSNCsKBqgcxbXRPopMWUeiYlHd in ztTrVSNCsKBqgcxbXRPopMWUeiYlHu:
    ztTrVSNCsKBqgcxbXRPopMWUeiYldk[ztTrVSNCsKBqgcxbXRPopMWUeiYlHd.name]=ztTrVSNCsKBqgcxbXRPopMWUeiYlHd.value
  except:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ(exception) 
  return ztTrVSNCsKBqgcxbXRPopMWUeiYldk
 def NF_Get_DefaultCookies(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu):
  ztTrVSNCsKBqgcxbXRPopMWUeiYldk={}
  if ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['flwssn'] :ztTrVSNCsKBqgcxbXRPopMWUeiYldk['flwssn'] =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['flwssn']
  if ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['nfvdid'] :ztTrVSNCsKBqgcxbXRPopMWUeiYldk['nfvdid'] =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['nfvdid']
  if ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['SecureNetflixId']:ztTrVSNCsKBqgcxbXRPopMWUeiYldk['SecureNetflixId']=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['SecureNetflixId']
  if ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['NetflixId'] :ztTrVSNCsKBqgcxbXRPopMWUeiYldk['NetflixId'] =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['NetflixId']
  if ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['memclid'] :ztTrVSNCsKBqgcxbXRPopMWUeiYldk['memclid'] =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['memclid']
  if ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['clSharedContext']:ztTrVSNCsKBqgcxbXRPopMWUeiYldk['clSharedContext']=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['COOKIES']['clSharedContext']
  return ztTrVSNCsKBqgcxbXRPopMWUeiYldk
 def NF_Get_BaseSession(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu):
  try:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfa=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.API_NETFLIX+'/browse' 
   ztTrVSNCsKBqgcxbXRPopMWUeiYldk=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_Get_DefaultCookies()
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfw=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.callRequestCookies('Get',ztTrVSNCsKBqgcxbXRPopMWUeiYlfa,payload=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,params=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,headers=ztTrVSNCsKBqgcxbXRPopMWUeiYlHn,cookies=ztTrVSNCsKBqgcxbXRPopMWUeiYldk)
   if ztTrVSNCsKBqgcxbXRPopMWUeiYlfw.status_code!=200:
    ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ('pass 1 status_code error')
    return ztTrVSNCsKBqgcxbXRPopMWUeiYlHa
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHm =ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.extract_json(ztTrVSNCsKBqgcxbXRPopMWUeiYlfw.text,'reactContext')
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHG=ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.extract_json(ztTrVSNCsKBqgcxbXRPopMWUeiYlfw.text,'falcorCache')
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF['SESSION']={'mainGuid':ztTrVSNCsKBqgcxbXRPopMWUeiYlHm['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':ztTrVSNCsKBqgcxbXRPopMWUeiYlHm['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':ztTrVSNCsKBqgcxbXRPopMWUeiYlHm['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':ztTrVSNCsKBqgcxbXRPopMWUeiYlHm['models']['memberContext']['data']['userInfo']['esn'],'identifier':ztTrVSNCsKBqgcxbXRPopMWUeiYlHm['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':ztTrVSNCsKBqgcxbXRPopMWUeiYlHm['models']['abContext']['data']['headers'],}
   ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.dic_To_jsonfile(ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF_SESSION_COOKIES1,ztTrVSNCsKBqgcxbXRPopMWUeiYlfu.NF)
  except ztTrVSNCsKBqgcxbXRPopMWUeiYlHL as exception:
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ('pass 1 error')
   ztTrVSNCsKBqgcxbXRPopMWUeiYlHJ(exception)
   return ztTrVSNCsKBqgcxbXRPopMWUeiYlHa
  return ztTrVSNCsKBqgcxbXRPopMWUeiYlHy
# Created by pyminifier (https://github.com/liftoff/pyminifier)
