__author__="NightRain"
LbYSNCuVnqsIdwmovxOAcjzDUBhGlF=object
LbYSNCuVnqsIdwmovxOAcjzDUBhGlr=None
LbYSNCuVnqsIdwmovxOAcjzDUBhGlp=True
LbYSNCuVnqsIdwmovxOAcjzDUBhGli=False
LbYSNCuVnqsIdwmovxOAcjzDUBhGlt=type
LbYSNCuVnqsIdwmovxOAcjzDUBhGly=dict
LbYSNCuVnqsIdwmovxOAcjzDUBhGlg=open
LbYSNCuVnqsIdwmovxOAcjzDUBhGlH=len
LbYSNCuVnqsIdwmovxOAcjzDUBhGlE=Exception
LbYSNCuVnqsIdwmovxOAcjzDUBhGlW=range
LbYSNCuVnqsIdwmovxOAcjzDUBhGlk=int
LbYSNCuVnqsIdwmovxOAcjzDUBhGlR=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
LbYSNCuVnqsIdwmovxOAcjzDUBhGef=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
LbYSNCuVnqsIdwmovxOAcjzDUBhGeX={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'HYPER_LINK','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},}
LbYSNCuVnqsIdwmovxOAcjzDUBhGel=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
LbYSNCuVnqsIdwmovxOAcjzDUBhGeM =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class LbYSNCuVnqsIdwmovxOAcjzDUBhGeT(LbYSNCuVnqsIdwmovxOAcjzDUBhGlF):
 def __init__(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,LbYSNCuVnqsIdwmovxOAcjzDUBhGeF,LbYSNCuVnqsIdwmovxOAcjzDUBhGer,LbYSNCuVnqsIdwmovxOAcjzDUBhGep):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ._addon_url =LbYSNCuVnqsIdwmovxOAcjzDUBhGeF
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ._addon_handle=LbYSNCuVnqsIdwmovxOAcjzDUBhGer
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.main_params =LbYSNCuVnqsIdwmovxOAcjzDUBhGep
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj =ztTrVSNCsKBqgcxbXRPopMWUeiYlfk() 
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
 def addon_noti(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,sting):
  try:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGet=xbmcgui.Dialog()
   LbYSNCuVnqsIdwmovxOAcjzDUBhGet.notification(__addonname__,sting)
  except:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGlr
 def addon_log(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,string):
  try:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGey=string.encode('utf-8','ignore')
  except:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGey='addonException: addon_log'
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeg=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,LbYSNCuVnqsIdwmovxOAcjzDUBhGey),level=LbYSNCuVnqsIdwmovxOAcjzDUBhGeg)
 def get_keyboard_input(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,LbYSNCuVnqsIdwmovxOAcjzDUBhGeR):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeH=LbYSNCuVnqsIdwmovxOAcjzDUBhGlr
  kb=xbmc.Keyboard()
  kb.setHeading(LbYSNCuVnqsIdwmovxOAcjzDUBhGeR)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeH=kb.getText()
  return LbYSNCuVnqsIdwmovxOAcjzDUBhGeH
 def get_settings_menubookmark(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeE=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp if __addon__.getSetting('menu_bookmark')=='true' else LbYSNCuVnqsIdwmovxOAcjzDUBhGli
  return(LbYSNCuVnqsIdwmovxOAcjzDUBhGeE)
 def get_settings_makebookmark(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ):
  return LbYSNCuVnqsIdwmovxOAcjzDUBhGlp if __addon__.getSetting('make_bookmark')=='true' else LbYSNCuVnqsIdwmovxOAcjzDUBhGli
 def get_settings_select_info(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeW=[]
  if __addon__.getSetting('netflixyn')=='true':LbYSNCuVnqsIdwmovxOAcjzDUBhGeW.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':LbYSNCuVnqsIdwmovxOAcjzDUBhGeW.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':LbYSNCuVnqsIdwmovxOAcjzDUBhGeW.append('tving')
  if __addon__.getSetting('watchayn')=='true':LbYSNCuVnqsIdwmovxOAcjzDUBhGeW.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':LbYSNCuVnqsIdwmovxOAcjzDUBhGeW.append('coupang')
  return LbYSNCuVnqsIdwmovxOAcjzDUBhGeW
 def add_dir(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,label,sublabel='',img='',infoLabels=LbYSNCuVnqsIdwmovxOAcjzDUBhGlr,isFolder=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp,params='',isLink=LbYSNCuVnqsIdwmovxOAcjzDUBhGli,ContextMenu=LbYSNCuVnqsIdwmovxOAcjzDUBhGlr):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGek='%s?%s'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ._addon_url,urllib.parse.urlencode(params))
  if sublabel:LbYSNCuVnqsIdwmovxOAcjzDUBhGeR='%s < %s >'%(label,sublabel)
  else: LbYSNCuVnqsIdwmovxOAcjzDUBhGeR=label
  if not img:img='DefaultFolder.png'
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeJ=xbmcgui.ListItem(LbYSNCuVnqsIdwmovxOAcjzDUBhGeR)
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGlt(img)==LbYSNCuVnqsIdwmovxOAcjzDUBhGly:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeJ.setArt(img)
  else:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeJ.setArt({'thumb':img,'poster':img})
  if infoLabels:LbYSNCuVnqsIdwmovxOAcjzDUBhGeJ.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeJ.setProperty('IsPlayable','true')
  if ContextMenu:LbYSNCuVnqsIdwmovxOAcjzDUBhGeJ.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ._addon_handle,LbYSNCuVnqsIdwmovxOAcjzDUBhGek,LbYSNCuVnqsIdwmovxOAcjzDUBhGeJ,isFolder)
 def Load_Searched_List(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ):
  try:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGea=LbYSNCuVnqsIdwmovxOAcjzDUBhGeM
   fp=LbYSNCuVnqsIdwmovxOAcjzDUBhGlg(LbYSNCuVnqsIdwmovxOAcjzDUBhGea,'r',-1,'utf-8')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeK=fp.readlines()
   fp.close()
  except:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeK=[]
  return LbYSNCuVnqsIdwmovxOAcjzDUBhGeK
 def Save_Searched_List(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,LbYSNCuVnqsIdwmovxOAcjzDUBhGfg):
  try:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGea=LbYSNCuVnqsIdwmovxOAcjzDUBhGeM
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeP=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.Load_Searched_List() 
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTe={'skey':LbYSNCuVnqsIdwmovxOAcjzDUBhGfg.strip()}
   fp=LbYSNCuVnqsIdwmovxOAcjzDUBhGlg(LbYSNCuVnqsIdwmovxOAcjzDUBhGea,'w',-1,'utf-8')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTf=urllib.parse.urlencode(LbYSNCuVnqsIdwmovxOAcjzDUBhGTe)
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTf=LbYSNCuVnqsIdwmovxOAcjzDUBhGTf+'\n'
   fp.write(LbYSNCuVnqsIdwmovxOAcjzDUBhGTf)
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTX=0
   for LbYSNCuVnqsIdwmovxOAcjzDUBhGTl in LbYSNCuVnqsIdwmovxOAcjzDUBhGeP:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGTM=LbYSNCuVnqsIdwmovxOAcjzDUBhGly(urllib.parse.parse_qsl(LbYSNCuVnqsIdwmovxOAcjzDUBhGTl))
    LbYSNCuVnqsIdwmovxOAcjzDUBhGTQ=LbYSNCuVnqsIdwmovxOAcjzDUBhGTe.get('skey').strip()
    LbYSNCuVnqsIdwmovxOAcjzDUBhGTF=LbYSNCuVnqsIdwmovxOAcjzDUBhGTM.get('skey').strip()
    if LbYSNCuVnqsIdwmovxOAcjzDUBhGTQ!=LbYSNCuVnqsIdwmovxOAcjzDUBhGTF:
     fp.write(LbYSNCuVnqsIdwmovxOAcjzDUBhGTl)
     LbYSNCuVnqsIdwmovxOAcjzDUBhGTX+=1
     if LbYSNCuVnqsIdwmovxOAcjzDUBhGTX>=50:break
   fp.close()
  except:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGlr
 def dp_Search_History(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,args):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGTr=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.Load_Searched_List()
  for LbYSNCuVnqsIdwmovxOAcjzDUBhGTp in LbYSNCuVnqsIdwmovxOAcjzDUBhGTr:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTi=LbYSNCuVnqsIdwmovxOAcjzDUBhGly(urllib.parse.parse_qsl(LbYSNCuVnqsIdwmovxOAcjzDUBhGTp))
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTt=LbYSNCuVnqsIdwmovxOAcjzDUBhGTi.get('skey').strip()
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTy={'mode':'TOTAL_SEARCH','search_key':LbYSNCuVnqsIdwmovxOAcjzDUBhGTt,}
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTg={'mode':'HISTORY_REMOVE','skey':LbYSNCuVnqsIdwmovxOAcjzDUBhGTt,'delmode':'ONE',}
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTH=urllib.parse.urlencode(LbYSNCuVnqsIdwmovxOAcjzDUBhGTg)
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTE=[('선택된 검색어 ( %s ) 삭제'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGTt),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGTH))]
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.add_dir(LbYSNCuVnqsIdwmovxOAcjzDUBhGTt,sublabel='',img=LbYSNCuVnqsIdwmovxOAcjzDUBhGlr,infoLabels=LbYSNCuVnqsIdwmovxOAcjzDUBhGlr,isFolder=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp,params=LbYSNCuVnqsIdwmovxOAcjzDUBhGTy,ContextMenu=LbYSNCuVnqsIdwmovxOAcjzDUBhGTE)
  LbYSNCuVnqsIdwmovxOAcjzDUBhGTk={'plot':'검색목록 전체를 삭제합니다.'}
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeR='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  LbYSNCuVnqsIdwmovxOAcjzDUBhGTy={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  LbYSNCuVnqsIdwmovxOAcjzDUBhGTR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.add_dir(LbYSNCuVnqsIdwmovxOAcjzDUBhGeR,sublabel='',img=LbYSNCuVnqsIdwmovxOAcjzDUBhGTR,infoLabels=LbYSNCuVnqsIdwmovxOAcjzDUBhGTk,isFolder=LbYSNCuVnqsIdwmovxOAcjzDUBhGli,params=LbYSNCuVnqsIdwmovxOAcjzDUBhGTy,isLink=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp)
  xbmcplugin.endOfDirectory(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ._addon_handle,cacheToDisc=LbYSNCuVnqsIdwmovxOAcjzDUBhGli)
 def Delete_History_List(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,LbYSNCuVnqsIdwmovxOAcjzDUBhGTt,LbYSNCuVnqsIdwmovxOAcjzDUBhGTK):
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGTK=='ALL':
   try:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGea=LbYSNCuVnqsIdwmovxOAcjzDUBhGeM
    fp=LbYSNCuVnqsIdwmovxOAcjzDUBhGlg(LbYSNCuVnqsIdwmovxOAcjzDUBhGea,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGlr
  else:
   try:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGea=LbYSNCuVnqsIdwmovxOAcjzDUBhGeM
    LbYSNCuVnqsIdwmovxOAcjzDUBhGeP=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.Load_Searched_List() 
    fp=LbYSNCuVnqsIdwmovxOAcjzDUBhGlg(LbYSNCuVnqsIdwmovxOAcjzDUBhGea,'w',-1,'utf-8')
    for LbYSNCuVnqsIdwmovxOAcjzDUBhGTl in LbYSNCuVnqsIdwmovxOAcjzDUBhGeP:
     LbYSNCuVnqsIdwmovxOAcjzDUBhGTM=LbYSNCuVnqsIdwmovxOAcjzDUBhGly(urllib.parse.parse_qsl(LbYSNCuVnqsIdwmovxOAcjzDUBhGTl))
     LbYSNCuVnqsIdwmovxOAcjzDUBhGTa=LbYSNCuVnqsIdwmovxOAcjzDUBhGTM.get('skey').strip()
     if LbYSNCuVnqsIdwmovxOAcjzDUBhGTt!=LbYSNCuVnqsIdwmovxOAcjzDUBhGTa:
      fp.write(LbYSNCuVnqsIdwmovxOAcjzDUBhGTl)
    fp.close()
   except:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGlr
 def dp_History_Delete(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,args):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGTt =args.get('skey') 
  LbYSNCuVnqsIdwmovxOAcjzDUBhGTK=args.get('delmode')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGet=xbmcgui.Dialog()
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGTK=='ALL':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTP=LbYSNCuVnqsIdwmovxOAcjzDUBhGet.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTP=LbYSNCuVnqsIdwmovxOAcjzDUBhGet.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGTP==LbYSNCuVnqsIdwmovxOAcjzDUBhGli:sys.exit()
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.Delete_History_List(LbYSNCuVnqsIdwmovxOAcjzDUBhGTt,LbYSNCuVnqsIdwmovxOAcjzDUBhGTK)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeE=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.get_settings_menubookmark()
  for LbYSNCuVnqsIdwmovxOAcjzDUBhGfe in LbYSNCuVnqsIdwmovxOAcjzDUBhGef:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeR=LbYSNCuVnqsIdwmovxOAcjzDUBhGfe.get('title')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTR=''
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGfe.get('mode')=='MENU_BOOKMARK' and LbYSNCuVnqsIdwmovxOAcjzDUBhGeE==LbYSNCuVnqsIdwmovxOAcjzDUBhGli:continue
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTy={'mode':LbYSNCuVnqsIdwmovxOAcjzDUBhGfe.get('mode')}
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGfe.get('mode')in['XXX','MENU_BOOKMARK']:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfT=LbYSNCuVnqsIdwmovxOAcjzDUBhGli
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfX =LbYSNCuVnqsIdwmovxOAcjzDUBhGlp
   else:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfT=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfX =LbYSNCuVnqsIdwmovxOAcjzDUBhGli
   if 'icon' in LbYSNCuVnqsIdwmovxOAcjzDUBhGfe:LbYSNCuVnqsIdwmovxOAcjzDUBhGTR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',LbYSNCuVnqsIdwmovxOAcjzDUBhGfe.get('icon')) 
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.add_dir(LbYSNCuVnqsIdwmovxOAcjzDUBhGeR,sublabel='',img=LbYSNCuVnqsIdwmovxOAcjzDUBhGTR,infoLabels=LbYSNCuVnqsIdwmovxOAcjzDUBhGlr,isFolder=LbYSNCuVnqsIdwmovxOAcjzDUBhGfT,params=LbYSNCuVnqsIdwmovxOAcjzDUBhGTy,isLink=LbYSNCuVnqsIdwmovxOAcjzDUBhGfX)
  xbmcplugin.endOfDirectory(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ._addon_handle,cacheToDisc=LbYSNCuVnqsIdwmovxOAcjzDUBhGli)
 def option_check(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeW=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.get_settings_select_info()
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGlH(LbYSNCuVnqsIdwmovxOAcjzDUBhGeW)==0:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGet=xbmcgui.Dialog()
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTP=LbYSNCuVnqsIdwmovxOAcjzDUBhGet.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGTP==LbYSNCuVnqsIdwmovxOAcjzDUBhGlp:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in LbYSNCuVnqsIdwmovxOAcjzDUBhGeW:
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.NF_cookiefile_check()==LbYSNCuVnqsIdwmovxOAcjzDUBhGli:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.NF_login(showMessage=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp)
 def NF_cookiefile_check(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfM={}
  try: 
   fp=LbYSNCuVnqsIdwmovxOAcjzDUBhGlg(LbYSNCuVnqsIdwmovxOAcjzDUBhGel,'r',-1,'utf-8')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGfM= json.load(fp)
   fp.close()
  except LbYSNCuVnqsIdwmovxOAcjzDUBhGlE as exception:
   return LbYSNCuVnqsIdwmovxOAcjzDUBhGli
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF=LbYSNCuVnqsIdwmovxOAcjzDUBhGfM
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfQ=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF_CookieFile_Load(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF_ORIGINAL_COOKIE)
  if(LbYSNCuVnqsIdwmovxOAcjzDUBhGfQ['NetflixId']!=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF['COOKIES']['NetflixId']or LbYSNCuVnqsIdwmovxOAcjzDUBhGfQ['SecureNetflixId']!=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF['COOKIES']['SecureNetflixId']or LbYSNCuVnqsIdwmovxOAcjzDUBhGfQ['flwssn']!=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF['COOKIES']['flwssn']or LbYSNCuVnqsIdwmovxOAcjzDUBhGfQ['memclid']!=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF['COOKIES']['memclid']or LbYSNCuVnqsIdwmovxOAcjzDUBhGfQ['nfvdid']!=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF['COOKIES']['nfvdid']):
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.Init_NF_Total()
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.NF_login(showMessage=LbYSNCuVnqsIdwmovxOAcjzDUBhGli)==LbYSNCuVnqsIdwmovxOAcjzDUBhGli:
    return LbYSNCuVnqsIdwmovxOAcjzDUBhGli
  return LbYSNCuVnqsIdwmovxOAcjzDUBhGlp
 def NF_login(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,showMessage=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp):
  if showMessage:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGet=xbmcgui.Dialog()
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTP=LbYSNCuVnqsIdwmovxOAcjzDUBhGet.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGTP==LbYSNCuVnqsIdwmovxOAcjzDUBhGli:
    return LbYSNCuVnqsIdwmovxOAcjzDUBhGli 
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF['COOKIES']=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF_CookieFile_Load(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF_ORIGINAL_COOKIE)
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfF=LbYSNCuVnqsIdwmovxOAcjzDUBhGli if LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF['COOKIES']=={}else LbYSNCuVnqsIdwmovxOAcjzDUBhGlp
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGfF:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_log('pass1 ok!')
  else:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_log('pass1 error!')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_noti(__language__(30905).encode('utf-8'))
   return LbYSNCuVnqsIdwmovxOAcjzDUBhGli 
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfF=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF_Get_BaseSession()
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGfF:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_log('pass2 ok!')
  else:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_log('pass2 error!')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_noti(__language__(30905).encode('utf-8'))
   return LbYSNCuVnqsIdwmovxOAcjzDUBhGli 
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfr =LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.Get_Now_Datetime()
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF['SESSION']['limitdate']=LbYSNCuVnqsIdwmovxOAcjzDUBhGfr.strftime('%Y-%m-%d')
  try: 
   fp=LbYSNCuVnqsIdwmovxOAcjzDUBhGlg(LbYSNCuVnqsIdwmovxOAcjzDUBhGel,'w',-1,'utf-8')
   json.dump(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF,fp,indent=4,ensure_ascii=LbYSNCuVnqsIdwmovxOAcjzDUBhGli)
   fp.close()
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_log('pass3 save ok!')
  except LbYSNCuVnqsIdwmovxOAcjzDUBhGlE as exception:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_log('pass3 save error!')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_noti(__language__(30905).encode('utf-8'))
   return LbYSNCuVnqsIdwmovxOAcjzDUBhGli
  if showMessage:LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_noti(__language__(30904).encode('utf-8'))
  return LbYSNCuVnqsIdwmovxOAcjzDUBhGlp
 def NF_logout(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGet=xbmcgui.Dialog()
  LbYSNCuVnqsIdwmovxOAcjzDUBhGTP=LbYSNCuVnqsIdwmovxOAcjzDUBhGet.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGTP==LbYSNCuVnqsIdwmovxOAcjzDUBhGli:return 
  if os.path.isfile(LbYSNCuVnqsIdwmovxOAcjzDUBhGel):os.remove(LbYSNCuVnqsIdwmovxOAcjzDUBhGel)
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,LbYSNCuVnqsIdwmovxOAcjzDUBhGfH):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfi=''
  LbYSNCuVnqsIdwmovxOAcjzDUBhGft=7
  try:
   for i in LbYSNCuVnqsIdwmovxOAcjzDUBhGlW(LbYSNCuVnqsIdwmovxOAcjzDUBhGlH(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH)):
    if i>=LbYSNCuVnqsIdwmovxOAcjzDUBhGft:
     LbYSNCuVnqsIdwmovxOAcjzDUBhGfi=LbYSNCuVnqsIdwmovxOAcjzDUBhGfi+'...'
     break
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfi=LbYSNCuVnqsIdwmovxOAcjzDUBhGfi+LbYSNCuVnqsIdwmovxOAcjzDUBhGfH[i]['title']+'\n'
  except:
   return ''
  return LbYSNCuVnqsIdwmovxOAcjzDUBhGfi
 def dp_Search_Group(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,args):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeW =LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.get_settings_select_info()
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfy=[]
  if 'search_key' in args:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGfg=args.get('search_key')
  else:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGfg=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not LbYSNCuVnqsIdwmovxOAcjzDUBhGfg:
    return
  if 'wavve' in LbYSNCuVnqsIdwmovxOAcjzDUBhGeW:
   (LbYSNCuVnqsIdwmovxOAcjzDUBhGfH,LbYSNCuVnqsIdwmovxOAcjzDUBhGfE)=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.Get_Search_Wavve(LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,'TVSHOW',1)
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGlH(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH)>0:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfW={'sType':'wavve_tvshow','sList':LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.MakeText_FreeList(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH),}
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfy.append(LbYSNCuVnqsIdwmovxOAcjzDUBhGfW)
   (LbYSNCuVnqsIdwmovxOAcjzDUBhGfH,LbYSNCuVnqsIdwmovxOAcjzDUBhGfE)=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.Get_Search_Wavve(LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,'MOVIE',1)
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGlH(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH)>0:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfW={'sType':'wavve_movie','sList':LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.MakeText_FreeList(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH),}
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfy.append(LbYSNCuVnqsIdwmovxOAcjzDUBhGfW)
  if 'tving' in LbYSNCuVnqsIdwmovxOAcjzDUBhGeW:
   (LbYSNCuVnqsIdwmovxOAcjzDUBhGfH,LbYSNCuVnqsIdwmovxOAcjzDUBhGfE)=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.Get_Search_Tving(LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,'TVSHOW',1)
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGlH(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH)>0:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfW={'sType':'tving_tvshow','sList':LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.MakeText_FreeList(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH),}
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfy.append(LbYSNCuVnqsIdwmovxOAcjzDUBhGfW)
   (LbYSNCuVnqsIdwmovxOAcjzDUBhGfH,LbYSNCuVnqsIdwmovxOAcjzDUBhGfE)=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.Get_Search_Tving(LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,'MOVIE',1)
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGlH(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH)>0:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfW={'sType':'tving_movie','sList':LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.MakeText_FreeList(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH),}
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfy.append(LbYSNCuVnqsIdwmovxOAcjzDUBhGfW)
  if 'watcha' in LbYSNCuVnqsIdwmovxOAcjzDUBhGeW:
   (LbYSNCuVnqsIdwmovxOAcjzDUBhGfH,LbYSNCuVnqsIdwmovxOAcjzDUBhGfE)=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.Get_Search_Watcha(LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,1)
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGlH(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH)>0:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfW={'sType':'watcha_list','sList':LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.MakeText_FreeList(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH),}
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfy.append(LbYSNCuVnqsIdwmovxOAcjzDUBhGfW)
  if 'coupang' in LbYSNCuVnqsIdwmovxOAcjzDUBhGeW:
   (LbYSNCuVnqsIdwmovxOAcjzDUBhGfH,LbYSNCuVnqsIdwmovxOAcjzDUBhGfE)=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.Get_Search_Coupang(LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,1)
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGlH(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH)>0:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfW={'sType':'coupang_list','sList':LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.MakeText_FreeList(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH),}
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfy.append(LbYSNCuVnqsIdwmovxOAcjzDUBhGfW)
  if 'netflix' in LbYSNCuVnqsIdwmovxOAcjzDUBhGeW:
   try:
    (LbYSNCuVnqsIdwmovxOAcjzDUBhGfH,LbYSNCuVnqsIdwmovxOAcjzDUBhGfE,LbYSNCuVnqsIdwmovxOAcjzDUBhGfk)=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.Get_Search_Netflix(LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,1)
   except:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfH=[]
    LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_noti(__language__(30919).encode('utf8'))
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGlH(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH)>0:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfW={'sType':'netflix_list','sList':LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.MakeText_FreeList(LbYSNCuVnqsIdwmovxOAcjzDUBhGfH),}
    LbYSNCuVnqsIdwmovxOAcjzDUBhGfy.append(LbYSNCuVnqsIdwmovxOAcjzDUBhGfW)
  for LbYSNCuVnqsIdwmovxOAcjzDUBhGfR in LbYSNCuVnqsIdwmovxOAcjzDUBhGfy:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGfJ=LbYSNCuVnqsIdwmovxOAcjzDUBhGeX[LbYSNCuVnqsIdwmovxOAcjzDUBhGfR.get('sType')]
   LbYSNCuVnqsIdwmovxOAcjzDUBhGfa={'plot':'검색어 : '+LbYSNCuVnqsIdwmovxOAcjzDUBhGfg+'\n\n'+LbYSNCuVnqsIdwmovxOAcjzDUBhGfR.get('sList')}
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeR=LbYSNCuVnqsIdwmovxOAcjzDUBhGfJ.get('title')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTy={'mode':LbYSNCuVnqsIdwmovxOAcjzDUBhGfJ.get('mode'),'ott':LbYSNCuVnqsIdwmovxOAcjzDUBhGfJ.get('ott'),'vidtype':LbYSNCuVnqsIdwmovxOAcjzDUBhGfJ.get('vidtype'),'search_key':LbYSNCuVnqsIdwmovxOAcjzDUBhGfg}
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGfJ.get('ott')=='netflix':
    LbYSNCuVnqsIdwmovxOAcjzDUBhGTy['page'] ='1'
    LbYSNCuVnqsIdwmovxOAcjzDUBhGTy['byReference']='-'
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',LbYSNCuVnqsIdwmovxOAcjzDUBhGfJ.get('icon'))
   LbYSNCuVnqsIdwmovxOAcjzDUBhGfT=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp if LbYSNCuVnqsIdwmovxOAcjzDUBhGfJ.get('mode')!='HYPER_LINK' else LbYSNCuVnqsIdwmovxOAcjzDUBhGli
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.add_dir(LbYSNCuVnqsIdwmovxOAcjzDUBhGeR,sublabel='',img=LbYSNCuVnqsIdwmovxOAcjzDUBhGTR,infoLabels=LbYSNCuVnqsIdwmovxOAcjzDUBhGfa,isFolder=LbYSNCuVnqsIdwmovxOAcjzDUBhGfT,params=LbYSNCuVnqsIdwmovxOAcjzDUBhGTy,isLink=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp)
  xbmcplugin.endOfDirectory(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ._addon_handle)
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.Save_Searched_List(LbYSNCuVnqsIdwmovxOAcjzDUBhGfg)
 def dp_Hyper_Link(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,args):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfK =args.get('mode')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfP =args.get('ott')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGXe =args.get('vidtype')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfg=args.get('search_key')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGXT='-'
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGfP=='wavve':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXf={'mode':'LOCAL_SEARCH','sType':'movie' if LbYSNCuVnqsIdwmovxOAcjzDUBhGXe=='MOVIE' else 'vod','search_key':LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,'page':'1',}
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXl=urllib.parse.urlencode(LbYSNCuVnqsIdwmovxOAcjzDUBhGXf)
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXT='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGXl)
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfP=='tving':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXf={'mode':'LOCAL_SEARCH','stype':'movie' if LbYSNCuVnqsIdwmovxOAcjzDUBhGXe=='MOVIE' else 'vod','search_key':LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,'page':'1',}
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXl=urllib.parse.urlencode(LbYSNCuVnqsIdwmovxOAcjzDUBhGXf)
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXT='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGXl)
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfP=='watcha':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXf={'mode':'LOCAL_SEARCH','search_key':LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,'page':'1',}
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXl=urllib.parse.urlencode(LbYSNCuVnqsIdwmovxOAcjzDUBhGXf)
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXT='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGXl)
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfP=='coupang':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXf={'mode':'LOCAL_SEARCH','search_key':LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,'page':'1',}
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXl=urllib.parse.urlencode(LbYSNCuVnqsIdwmovxOAcjzDUBhGXf)
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXT='ActivateWindow(10025,"plugin://plugin.video.coupangm/?%s",return)'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGXl)
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfP=='netflix':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXM=args.get('videoid')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXQ=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.NF['SESSION']['nowGuid']
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGXe=='TVSHOW':
    LbYSNCuVnqsIdwmovxOAcjzDUBhGXT='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGXM)
   else:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGXT='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGXM,LbYSNCuVnqsIdwmovxOAcjzDUBhGXQ)
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.addon_log('ott_url ==> ( '+LbYSNCuVnqsIdwmovxOAcjzDUBhGXT+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(LbYSNCuVnqsIdwmovxOAcjzDUBhGXT)
 def dp_Nf_Search(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,args):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGXF =LbYSNCuVnqsIdwmovxOAcjzDUBhGlk(args.get('page'))
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfg =args.get('search_key')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfk=args.get('byReference')
  (LbYSNCuVnqsIdwmovxOAcjzDUBhGfH,LbYSNCuVnqsIdwmovxOAcjzDUBhGfE,LbYSNCuVnqsIdwmovxOAcjzDUBhGfk)=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.SearchObj.Get_Search_Netflix(LbYSNCuVnqsIdwmovxOAcjzDUBhGfg,LbYSNCuVnqsIdwmovxOAcjzDUBhGXF,byReference=LbYSNCuVnqsIdwmovxOAcjzDUBhGfk)
  for LbYSNCuVnqsIdwmovxOAcjzDUBhGXr in LbYSNCuVnqsIdwmovxOAcjzDUBhGfH:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXM =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('videoid')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXe =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('vidtype')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeR =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('title')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXp =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('mpaa')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXi =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('regularSynopsis')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXt =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('dpSupplemental')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXy=LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('sequiturEvidence')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXg =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('thumbnail')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXH =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('year')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXE =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('duration')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXW =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('info_genre')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXk =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('director')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXR =LbYSNCuVnqsIdwmovxOAcjzDUBhGXr.get('cast')
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGXe=='movie':
    LbYSNCuVnqsIdwmovxOAcjzDUBhGTW=' (%s)'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGlR(LbYSNCuVnqsIdwmovxOAcjzDUBhGXH))
   else:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGTW=''
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXJ=''
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGXi:LbYSNCuVnqsIdwmovxOAcjzDUBhGXJ=LbYSNCuVnqsIdwmovxOAcjzDUBhGXJ+'\n\n'+LbYSNCuVnqsIdwmovxOAcjzDUBhGXi
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGXt :LbYSNCuVnqsIdwmovxOAcjzDUBhGXJ=LbYSNCuVnqsIdwmovxOAcjzDUBhGXJ+'\n\n'+LbYSNCuVnqsIdwmovxOAcjzDUBhGXt
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGXy:LbYSNCuVnqsIdwmovxOAcjzDUBhGXJ=LbYSNCuVnqsIdwmovxOAcjzDUBhGXJ+'\n\n'+LbYSNCuVnqsIdwmovxOAcjzDUBhGXy
   LbYSNCuVnqsIdwmovxOAcjzDUBhGXJ=LbYSNCuVnqsIdwmovxOAcjzDUBhGXJ.strip()
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTk={'mediatype':'tvshow' if LbYSNCuVnqsIdwmovxOAcjzDUBhGXe=='show' else 'movie','title':LbYSNCuVnqsIdwmovxOAcjzDUBhGeR,'mpaa':LbYSNCuVnqsIdwmovxOAcjzDUBhGXp,'plot':LbYSNCuVnqsIdwmovxOAcjzDUBhGXJ,'duration':LbYSNCuVnqsIdwmovxOAcjzDUBhGXE,'genre':LbYSNCuVnqsIdwmovxOAcjzDUBhGXW,'director':LbYSNCuVnqsIdwmovxOAcjzDUBhGXk,'cast':LbYSNCuVnqsIdwmovxOAcjzDUBhGXR,'year':LbYSNCuVnqsIdwmovxOAcjzDUBhGXH,}
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTy={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if LbYSNCuVnqsIdwmovxOAcjzDUBhGXe=='show' else 'MOVIE','videoid':LbYSNCuVnqsIdwmovxOAcjzDUBhGXM,}
   if LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.get_settings_makebookmark():
    LbYSNCuVnqsIdwmovxOAcjzDUBhGXa={'videoid':LbYSNCuVnqsIdwmovxOAcjzDUBhGXM,'vidtype':'tvshow' if LbYSNCuVnqsIdwmovxOAcjzDUBhGXe=='show' else 'movie','vtitle':LbYSNCuVnqsIdwmovxOAcjzDUBhGeR+LbYSNCuVnqsIdwmovxOAcjzDUBhGTW,'vsubtitle':'','vinfo':LbYSNCuVnqsIdwmovxOAcjzDUBhGTk,'thumbnail':LbYSNCuVnqsIdwmovxOAcjzDUBhGXg,}
    LbYSNCuVnqsIdwmovxOAcjzDUBhGXK=json.dumps(LbYSNCuVnqsIdwmovxOAcjzDUBhGXa)
    LbYSNCuVnqsIdwmovxOAcjzDUBhGXK=urllib.parse.quote(LbYSNCuVnqsIdwmovxOAcjzDUBhGXK)
    LbYSNCuVnqsIdwmovxOAcjzDUBhGXP='RunPlugin(plugin://plugin.video.searchm/?mode=SET_BOOKMARK&bm_param=%s)'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGXK)
    LbYSNCuVnqsIdwmovxOAcjzDUBhGTE=[('(통합) 찜 영상에 추가',LbYSNCuVnqsIdwmovxOAcjzDUBhGXP)]
   else:
    LbYSNCuVnqsIdwmovxOAcjzDUBhGTE=LbYSNCuVnqsIdwmovxOAcjzDUBhGlr
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.add_dir(LbYSNCuVnqsIdwmovxOAcjzDUBhGeR+LbYSNCuVnqsIdwmovxOAcjzDUBhGTW,sublabel=LbYSNCuVnqsIdwmovxOAcjzDUBhGlr,img=LbYSNCuVnqsIdwmovxOAcjzDUBhGXg,infoLabels=LbYSNCuVnqsIdwmovxOAcjzDUBhGTk,isFolder=LbYSNCuVnqsIdwmovxOAcjzDUBhGli,params=LbYSNCuVnqsIdwmovxOAcjzDUBhGTy,isLink=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp,ContextMenu=LbYSNCuVnqsIdwmovxOAcjzDUBhGTE)
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGfE:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTy={}
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTy['mode'] ='NF_SEARCH' 
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTy['page'] =LbYSNCuVnqsIdwmovxOAcjzDUBhGlR(LbYSNCuVnqsIdwmovxOAcjzDUBhGXF+1)
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTy['search_key']=LbYSNCuVnqsIdwmovxOAcjzDUBhGfg
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTy['byReference']=LbYSNCuVnqsIdwmovxOAcjzDUBhGfk
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeR='[B]%s >>[/B]'%'다음 페이지'
   LbYSNCuVnqsIdwmovxOAcjzDUBhGle=LbYSNCuVnqsIdwmovxOAcjzDUBhGlR(LbYSNCuVnqsIdwmovxOAcjzDUBhGXF+1)
   LbYSNCuVnqsIdwmovxOAcjzDUBhGTR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.add_dir(LbYSNCuVnqsIdwmovxOAcjzDUBhGeR,sublabel=LbYSNCuVnqsIdwmovxOAcjzDUBhGle,img=LbYSNCuVnqsIdwmovxOAcjzDUBhGTR,infoLabels=LbYSNCuVnqsIdwmovxOAcjzDUBhGlr,isFolder=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp,params=LbYSNCuVnqsIdwmovxOAcjzDUBhGTy)
  xbmcplugin.setContent(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ._addon_handle,'movies')
  xbmcplugin.endOfDirectory(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ._addon_handle)
 def dp_Bookmark_Menu(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,args):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGXT='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(LbYSNCuVnqsIdwmovxOAcjzDUBhGXT)
 def dp_Set_Bookmark(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ,args):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGlT=urllib.parse.unquote(args.get('bm_param'))
  LbYSNCuVnqsIdwmovxOAcjzDUBhGlT=json.loads(LbYSNCuVnqsIdwmovxOAcjzDUBhGlT)
  LbYSNCuVnqsIdwmovxOAcjzDUBhGXM =LbYSNCuVnqsIdwmovxOAcjzDUBhGlT.get('videoid')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGXe =LbYSNCuVnqsIdwmovxOAcjzDUBhGlT.get('vidtype')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGlf =LbYSNCuVnqsIdwmovxOAcjzDUBhGlT.get('vtitle')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGlX =LbYSNCuVnqsIdwmovxOAcjzDUBhGlT.get('vsubtitle')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGlM =LbYSNCuVnqsIdwmovxOAcjzDUBhGlT.get('vinfo')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGXg =LbYSNCuVnqsIdwmovxOAcjzDUBhGlT.get('thumbnail')
  LbYSNCuVnqsIdwmovxOAcjzDUBhGet=xbmcgui.Dialog()
  LbYSNCuVnqsIdwmovxOAcjzDUBhGTP=LbYSNCuVnqsIdwmovxOAcjzDUBhGet.yesno(__language__(30917).encode('utf8'),LbYSNCuVnqsIdwmovxOAcjzDUBhGlf+' \n\n'+__language__(30918))
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGTP==LbYSNCuVnqsIdwmovxOAcjzDUBhGli:return
  LbYSNCuVnqsIdwmovxOAcjzDUBhGlQ={'indexinfo':{'ott':'netflix','videoid':LbYSNCuVnqsIdwmovxOAcjzDUBhGXM,'vidtype':LbYSNCuVnqsIdwmovxOAcjzDUBhGXe,},'saveinfo':{'title':LbYSNCuVnqsIdwmovxOAcjzDUBhGlf,'subtitle':LbYSNCuVnqsIdwmovxOAcjzDUBhGlX,'thumbnail':LbYSNCuVnqsIdwmovxOAcjzDUBhGXg,'infoLabels':LbYSNCuVnqsIdwmovxOAcjzDUBhGlM,},}
  LbYSNCuVnqsIdwmovxOAcjzDUBhGXK=json.dumps(LbYSNCuVnqsIdwmovxOAcjzDUBhGlQ)
  LbYSNCuVnqsIdwmovxOAcjzDUBhGXK=urllib.parse.quote(LbYSNCuVnqsIdwmovxOAcjzDUBhGXK)
  LbYSNCuVnqsIdwmovxOAcjzDUBhGXP='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(LbYSNCuVnqsIdwmovxOAcjzDUBhGXK)
  xbmc.executebuiltin(LbYSNCuVnqsIdwmovxOAcjzDUBhGXP)
 def search_main(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ):
  LbYSNCuVnqsIdwmovxOAcjzDUBhGfK=LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.main_params.get('mode',LbYSNCuVnqsIdwmovxOAcjzDUBhGlr)
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGfK=='NFLOGOUT':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.NF_logout()
   return
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfK=='NFLOGIN':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.NF_login(showMessage=LbYSNCuVnqsIdwmovxOAcjzDUBhGlp)
   return
  LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.option_check()
  if LbYSNCuVnqsIdwmovxOAcjzDUBhGfK is LbYSNCuVnqsIdwmovxOAcjzDUBhGlr:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.dp_Main_List()
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfK=='TOTAL_SEARCH':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.dp_Search_Group(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.main_params)
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfK=='HYPER_LINK':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.dp_Hyper_Link(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.main_params)
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfK=='NF_SEARCH':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.dp_Nf_Search(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.main_params)
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfK=='TOTAL_HISTORY':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.dp_Search_History(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.main_params)
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfK=='HISTORY_REMOVE':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.dp_History_Delete(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.main_params)
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfK=='MENU_BOOKMARK':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.dp_Bookmark_Menu(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.main_params)
  elif LbYSNCuVnqsIdwmovxOAcjzDUBhGfK=='SET_BOOKMARK':
   LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.dp_Set_Bookmark(LbYSNCuVnqsIdwmovxOAcjzDUBhGeQ.main_params)
  else:
   LbYSNCuVnqsIdwmovxOAcjzDUBhGlr
# Created by pyminifier (https://github.com/liftoff/pyminifier)
