__author__="NightRain"
WHseVCckptqUiJQGgbRYlMLXzKmExN=object
WHseVCckptqUiJQGgbRYlMLXzKmExj=None
WHseVCckptqUiJQGgbRYlMLXzKmExI=True
WHseVCckptqUiJQGgbRYlMLXzKmExo=print
WHseVCckptqUiJQGgbRYlMLXzKmExT=str
WHseVCckptqUiJQGgbRYlMLXzKmExu=int
WHseVCckptqUiJQGgbRYlMLXzKmExr=False
WHseVCckptqUiJQGgbRYlMLXzKmEwd=Exception
WHseVCckptqUiJQGgbRYlMLXzKmEwh=len
WHseVCckptqUiJQGgbRYlMLXzKmEwB=open
WHseVCckptqUiJQGgbRYlMLXzKmEwa=type
WHseVCckptqUiJQGgbRYlMLXzKmEwx=list
WHseVCckptqUiJQGgbRYlMLXzKmEwf=isinstance
WHseVCckptqUiJQGgbRYlMLXzKmEwn=dict
WHseVCckptqUiJQGgbRYlMLXzKmEwS=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
import http.cookiejar
class WHseVCckptqUiJQGgbRYlMLXzKmEdh(WHseVCckptqUiJQGgbRYlMLXzKmExN):
 def __init__(WHseVCckptqUiJQGgbRYlMLXzKmEdB):
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_WAVVE ='https://apis.wavve.com'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_TVING_SEARCH='https://search.tving.com'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_TVING_IMG ='https://image.tving.com'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_WATCHA ='https://api-mars.watcha.com'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_NETFLIX ='https://www.netflix.com'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_COUPANG ='https://discover.coupangstreaming.com'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_PRIMEV ='https://www.primevideo.com'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.WAVVE_LIMIT =20 
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.TVING_LIMIT =30
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.WATCHA_LIMIT =30
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_LIMIT =20 
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.COUPANG_LIMIT =10 
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.DISNEY_LIMIT =10 
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.DERECTOR_LIMIT =4
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.CAST_LIMIT =10
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.GENRE_LIMIT =4
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.TVING_MOVIE_LITE=['2610061','2610161','261062']
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_HEADER={'user-agent':WHseVCckptqUiJQGgbRYlMLXzKmEdB.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND1 ='_342x192'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND2 ='_665x375'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_PORT ='_342x684'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LOGO ='_550x124'
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF={}
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']={}
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']={}
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ={}
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.HTTP_CLIENT=requests.Session()
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.CP_ORIGINAL_COOKIE =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.PV_ORIGINAL_COOKIE =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ_ORIGINAL_COOKIE =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_ORIGINAL_COOKIE =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_SESSION_COOKIES1 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_SESSION_COOKIES2 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_SESSION_COOKIES3 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_SESSION_COOKIES4 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_SESSION_FULLTEXT1 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_SESSION_FULLTEXT2 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_SESSION_FULLTEXT3 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_SESSION_FULLTEXT4 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_CONTEXTJSON_FILE1 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_CONTEXTJSON_FILE2 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_CONTEXTJSON_FILE3 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_CONTEXTJSON_FILE4 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_FALCORJSON_FILE1 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_FALCORJSON_FILE2 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_FALCORJSON_FILE3 =''
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_FALCORJSON_FILE4 =''
 '''
 def callRequestCookies(self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):
  #setHeader = {'user-agent' : self.USER_AGENT }
  setHeader = self.DEFAULT_HEADER
  if headers: setHeader.update(headers )
  if jobtype == 'Get': # Get/Post
   res = requests.get(url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  else:
   res = requests.post(url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  return res
 ''' 
 def Call_Request(WHseVCckptqUiJQGgbRYlMLXzKmEdB,WHseVCckptqUiJQGgbRYlMLXzKmEdP,payload=WHseVCckptqUiJQGgbRYlMLXzKmExj,json=WHseVCckptqUiJQGgbRYlMLXzKmExj,params=WHseVCckptqUiJQGgbRYlMLXzKmExj,headers=WHseVCckptqUiJQGgbRYlMLXzKmExj,cookies=WHseVCckptqUiJQGgbRYlMLXzKmExj,redirects=WHseVCckptqUiJQGgbRYlMLXzKmExI,method='-'):
  WHseVCckptqUiJQGgbRYlMLXzKmEda={'user-agent':WHseVCckptqUiJQGgbRYlMLXzKmEdB.USER_AGENT}
  if headers:WHseVCckptqUiJQGgbRYlMLXzKmEda.update(headers)
  if payload!=WHseVCckptqUiJQGgbRYlMLXzKmExj or method=='POST':
   WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.HTTP_CLIENT.post(url=WHseVCckptqUiJQGgbRYlMLXzKmEdP,data=payload,json=json,params=params,headers=WHseVCckptqUiJQGgbRYlMLXzKmEda,cookies=cookies,allow_redirects=redirects)
  else:
   WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.HTTP_CLIENT.get(url=WHseVCckptqUiJQGgbRYlMLXzKmEdP,params=params,headers=WHseVCckptqUiJQGgbRYlMLXzKmEda,cookies=cookies,allow_redirects=redirects)
  WHseVCckptqUiJQGgbRYlMLXzKmExo(WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmEdx.status_code)+' - '+WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmEdx.url))
  return WHseVCckptqUiJQGgbRYlMLXzKmEdx
 def GetNoCache(WHseVCckptqUiJQGgbRYlMLXzKmEdB,timetype=1,minutes=0):
  if timetype==1:
   ts=WHseVCckptqUiJQGgbRYlMLXzKmExu(time.time())
   mi=WHseVCckptqUiJQGgbRYlMLXzKmExu(minutes*60)
  else:
   ts=WHseVCckptqUiJQGgbRYlMLXzKmExu(time.time()*1000)
   mi=WHseVCckptqUiJQGgbRYlMLXzKmExu(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(WHseVCckptqUiJQGgbRYlMLXzKmEdB):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(WHseVCckptqUiJQGgbRYlMLXzKmEdB,search_key,sType,page_int):
  WHseVCckptqUiJQGgbRYlMLXzKmEdf=[]
  WHseVCckptqUiJQGgbRYlMLXzKmEdn=WHseVCckptqUiJQGgbRYlMLXzKmEdu=1
  WHseVCckptqUiJQGgbRYlMLXzKmEdS=WHseVCckptqUiJQGgbRYlMLXzKmExr
  try:
   WHseVCckptqUiJQGgbRYlMLXzKmEdP=WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_WAVVE+'/cf/search/list.js'
   WHseVCckptqUiJQGgbRYlMLXzKmEdv={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':WHseVCckptqUiJQGgbRYlMLXzKmExT((page_int-1)*WHseVCckptqUiJQGgbRYlMLXzKmEdB.WAVVE_LIMIT),'limit':WHseVCckptqUiJQGgbRYlMLXzKmEdB.WAVVE_LIMIT,'orderby':'score'}
   WHseVCckptqUiJQGgbRYlMLXzKmEdv.update(WHseVCckptqUiJQGgbRYlMLXzKmEdB.WAVVE_PARAMS)
   WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.Call_Request(WHseVCckptqUiJQGgbRYlMLXzKmEdP,payload=WHseVCckptqUiJQGgbRYlMLXzKmExj,params=WHseVCckptqUiJQGgbRYlMLXzKmEdv,headers=WHseVCckptqUiJQGgbRYlMLXzKmExj,cookies=WHseVCckptqUiJQGgbRYlMLXzKmExj,method='GET')
   WHseVCckptqUiJQGgbRYlMLXzKmEdD=json.loads(WHseVCckptqUiJQGgbRYlMLXzKmEdx.text)
   if not('celllist' in WHseVCckptqUiJQGgbRYlMLXzKmEdD['cell_toplist']):return WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS
   WHseVCckptqUiJQGgbRYlMLXzKmEdO=WHseVCckptqUiJQGgbRYlMLXzKmEdD['cell_toplist']['celllist']
   for WHseVCckptqUiJQGgbRYlMLXzKmEdA in WHseVCckptqUiJQGgbRYlMLXzKmEdO:
    WHseVCckptqUiJQGgbRYlMLXzKmEdy =WHseVCckptqUiJQGgbRYlMLXzKmEdA['event_list'][1]['url']
    WHseVCckptqUiJQGgbRYlMLXzKmEdF=urllib.parse.urlsplit(WHseVCckptqUiJQGgbRYlMLXzKmEdy).query
    WHseVCckptqUiJQGgbRYlMLXzKmEdN=WHseVCckptqUiJQGgbRYlMLXzKmEdF[0:WHseVCckptqUiJQGgbRYlMLXzKmEdF.find('=')]
    WHseVCckptqUiJQGgbRYlMLXzKmEdj=WHseVCckptqUiJQGgbRYlMLXzKmEdF[WHseVCckptqUiJQGgbRYlMLXzKmEdF.find('=')+1:]
    WHseVCckptqUiJQGgbRYlMLXzKmEdN='TVSHOW' if WHseVCckptqUiJQGgbRYlMLXzKmEdN=='programid' else 'MOVIE' 
    WHseVCckptqUiJQGgbRYlMLXzKmEdI=WHseVCckptqUiJQGgbRYlMLXzKmEdA['title_list'][0]['text']
    WHseVCckptqUiJQGgbRYlMLXzKmEdo =WHseVCckptqUiJQGgbRYlMLXzKmEdA['age']
    WHseVCckptqUiJQGgbRYlMLXzKmEdT={'title':WHseVCckptqUiJQGgbRYlMLXzKmEdI}
    if WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('age')!='21':
     WHseVCckptqUiJQGgbRYlMLXzKmEdf.append(WHseVCckptqUiJQGgbRYlMLXzKmEdT)
   WHseVCckptqUiJQGgbRYlMLXzKmEdn=WHseVCckptqUiJQGgbRYlMLXzKmExu(WHseVCckptqUiJQGgbRYlMLXzKmEdD['cell_toplist']['pagecount'])
   if WHseVCckptqUiJQGgbRYlMLXzKmEdD['cell_toplist']['count']:WHseVCckptqUiJQGgbRYlMLXzKmEdu =WHseVCckptqUiJQGgbRYlMLXzKmExu(WHseVCckptqUiJQGgbRYlMLXzKmEdD['cell_toplist']['count'])
   else:WHseVCckptqUiJQGgbRYlMLXzKmEdu=WHseVCckptqUiJQGgbRYlMLXzKmEdB.LIST_LIMIT
   WHseVCckptqUiJQGgbRYlMLXzKmEdS=WHseVCckptqUiJQGgbRYlMLXzKmEdn>WHseVCckptqUiJQGgbRYlMLXzKmEdu
  except WHseVCckptqUiJQGgbRYlMLXzKmEwd as exception:
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception)
  return WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS 
 def Get_Search_Tving(WHseVCckptqUiJQGgbRYlMLXzKmEdB,search_key,sType,page_int):
  WHseVCckptqUiJQGgbRYlMLXzKmEdf=[]
  WHseVCckptqUiJQGgbRYlMLXzKmEdS=WHseVCckptqUiJQGgbRYlMLXzKmExr
  try:
   WHseVCckptqUiJQGgbRYlMLXzKmEdr ='/search/getSearch.jsp'
   WHseVCckptqUiJQGgbRYlMLXzKmEhd={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':WHseVCckptqUiJQGgbRYlMLXzKmExT(page_int),'pageSize':WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmEdB.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':WHseVCckptqUiJQGgbRYlMLXzKmEdB.TVING_PARMAS.get('SCREENCODE'),'os':WHseVCckptqUiJQGgbRYlMLXzKmEdB.TVING_PARMAS.get('OSCODE'),'network':WHseVCckptqUiJQGgbRYlMLXzKmEdB.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmEdB.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmEdB.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmEdB.GetNoCache(2))}
   WHseVCckptqUiJQGgbRYlMLXzKmEdP=WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_TVING_SEARCH+WHseVCckptqUiJQGgbRYlMLXzKmEdr
   WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.Call_Request(WHseVCckptqUiJQGgbRYlMLXzKmEdP,payload=WHseVCckptqUiJQGgbRYlMLXzKmExj,params=WHseVCckptqUiJQGgbRYlMLXzKmEhd,headers=WHseVCckptqUiJQGgbRYlMLXzKmExj,cookies=WHseVCckptqUiJQGgbRYlMLXzKmExj,method='GET')
   WHseVCckptqUiJQGgbRYlMLXzKmEhB=json.loads(WHseVCckptqUiJQGgbRYlMLXzKmEdx.text)
   if sType=='TVSHOW':
    if not('programRsb' in WHseVCckptqUiJQGgbRYlMLXzKmEhB):return WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS
    WHseVCckptqUiJQGgbRYlMLXzKmEha=WHseVCckptqUiJQGgbRYlMLXzKmEhB['programRsb']['dataList']
    WHseVCckptqUiJQGgbRYlMLXzKmEhx =WHseVCckptqUiJQGgbRYlMLXzKmExu(WHseVCckptqUiJQGgbRYlMLXzKmEhB['programRsb']['count'])
    for WHseVCckptqUiJQGgbRYlMLXzKmEdA in WHseVCckptqUiJQGgbRYlMLXzKmEha:
     WHseVCckptqUiJQGgbRYlMLXzKmEhw=WHseVCckptqUiJQGgbRYlMLXzKmEdA['mast_cd']
     WHseVCckptqUiJQGgbRYlMLXzKmEdI =WHseVCckptqUiJQGgbRYlMLXzKmEdA['mast_nm']
     WHseVCckptqUiJQGgbRYlMLXzKmEhf=WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_TVING_IMG+WHseVCckptqUiJQGgbRYlMLXzKmEdA['web_url4']
     WHseVCckptqUiJQGgbRYlMLXzKmEhn =WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_TVING_IMG+WHseVCckptqUiJQGgbRYlMLXzKmEdA['web_url']
     try:
      WHseVCckptqUiJQGgbRYlMLXzKmEhS =[]
      WHseVCckptqUiJQGgbRYlMLXzKmEhP=[]
      WHseVCckptqUiJQGgbRYlMLXzKmEhv =[]
      WHseVCckptqUiJQGgbRYlMLXzKmEhD =0
      WHseVCckptqUiJQGgbRYlMLXzKmEhO =''
      WHseVCckptqUiJQGgbRYlMLXzKmEhA =''
      WHseVCckptqUiJQGgbRYlMLXzKmEhy =''
      if WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('actor') !='' and WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('actor') !='-':WHseVCckptqUiJQGgbRYlMLXzKmEhS =WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('actor').split(',')
      if WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('director')!='' and WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('director')!='-':WHseVCckptqUiJQGgbRYlMLXzKmEhP=WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('director').split(',')
      if WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('cate_nm')!='' and WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('cate_nm')!='-':WHseVCckptqUiJQGgbRYlMLXzKmEhv =WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('cate_nm').split('/')
      if 'targetage' in WHseVCckptqUiJQGgbRYlMLXzKmEdA:WHseVCckptqUiJQGgbRYlMLXzKmEhO=WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('targetage')
      if 'broad_dt' in WHseVCckptqUiJQGgbRYlMLXzKmEdA:
       WHseVCckptqUiJQGgbRYlMLXzKmEhF=WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('broad_dt')
       WHseVCckptqUiJQGgbRYlMLXzKmEhy='%s-%s-%s'%(WHseVCckptqUiJQGgbRYlMLXzKmEhF[:4],WHseVCckptqUiJQGgbRYlMLXzKmEhF[4:6],WHseVCckptqUiJQGgbRYlMLXzKmEhF[6:])
       WHseVCckptqUiJQGgbRYlMLXzKmEhA =WHseVCckptqUiJQGgbRYlMLXzKmEhF[:4]
     except:
      WHseVCckptqUiJQGgbRYlMLXzKmExj
     WHseVCckptqUiJQGgbRYlMLXzKmEdT={'title':WHseVCckptqUiJQGgbRYlMLXzKmEdI,}
     WHseVCckptqUiJQGgbRYlMLXzKmEdf.append(WHseVCckptqUiJQGgbRYlMLXzKmEdT)
   else:
    if not('vodMVRsb' in WHseVCckptqUiJQGgbRYlMLXzKmEhB):return WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS
    WHseVCckptqUiJQGgbRYlMLXzKmEhN=WHseVCckptqUiJQGgbRYlMLXzKmEhB['vodMVRsb']['dataList']
    WHseVCckptqUiJQGgbRYlMLXzKmEhx =WHseVCckptqUiJQGgbRYlMLXzKmExu(WHseVCckptqUiJQGgbRYlMLXzKmEhB['vodMVRsb']['count'])
    WHseVCckptqUiJQGgbRYlMLXzKmExo(WHseVCckptqUiJQGgbRYlMLXzKmEhx)
    for WHseVCckptqUiJQGgbRYlMLXzKmEdA in WHseVCckptqUiJQGgbRYlMLXzKmEhN:
     WHseVCckptqUiJQGgbRYlMLXzKmEhw=WHseVCckptqUiJQGgbRYlMLXzKmEdA['mast_cd']
     WHseVCckptqUiJQGgbRYlMLXzKmEdI =WHseVCckptqUiJQGgbRYlMLXzKmEdA['mast_nm'].strip()
     WHseVCckptqUiJQGgbRYlMLXzKmEhf =WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_TVING_IMG+WHseVCckptqUiJQGgbRYlMLXzKmEdA['web_url']
     WHseVCckptqUiJQGgbRYlMLXzKmEhn =WHseVCckptqUiJQGgbRYlMLXzKmEhf
     WHseVCckptqUiJQGgbRYlMLXzKmEhj=''
     try:
      WHseVCckptqUiJQGgbRYlMLXzKmEhS =[]
      WHseVCckptqUiJQGgbRYlMLXzKmEhP=[]
      WHseVCckptqUiJQGgbRYlMLXzKmEhv =[]
      WHseVCckptqUiJQGgbRYlMLXzKmEhD =0
      WHseVCckptqUiJQGgbRYlMLXzKmEhO =''
      WHseVCckptqUiJQGgbRYlMLXzKmEhA =''
      WHseVCckptqUiJQGgbRYlMLXzKmEhy =''
      if WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('actor') !='' and WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('actor') !='-':WHseVCckptqUiJQGgbRYlMLXzKmEhS =WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('actor').split(',')
      if WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('director')!='' and WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('director')!='-':WHseVCckptqUiJQGgbRYlMLXzKmEhP=WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('director').split(',')
      if WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('cate_nm')!='' and WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('cate_nm')!='-':WHseVCckptqUiJQGgbRYlMLXzKmEhv =WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('cate_nm').split('/')
      if WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('runtime_sec')!='':WHseVCckptqUiJQGgbRYlMLXzKmEhD=WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('runtime_sec')
      if 'grade_nm' in WHseVCckptqUiJQGgbRYlMLXzKmEdA:WHseVCckptqUiJQGgbRYlMLXzKmEhO=WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('grade_nm')
      WHseVCckptqUiJQGgbRYlMLXzKmEhI=''
      WHseVCckptqUiJQGgbRYlMLXzKmEhF=WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('broad_dt')
      if WHseVCckptqUiJQGgbRYlMLXzKmEhI!='':
       WHseVCckptqUiJQGgbRYlMLXzKmEhy='%s-%s-%s'%(WHseVCckptqUiJQGgbRYlMLXzKmEhF[:4],WHseVCckptqUiJQGgbRYlMLXzKmEhF[4:6],WHseVCckptqUiJQGgbRYlMLXzKmEhF[6:])
       WHseVCckptqUiJQGgbRYlMLXzKmEhA =WHseVCckptqUiJQGgbRYlMLXzKmEhF[:4]
     except:
      WHseVCckptqUiJQGgbRYlMLXzKmExj
     WHseVCckptqUiJQGgbRYlMLXzKmEdT={'title':WHseVCckptqUiJQGgbRYlMLXzKmEdI,}
     WHseVCckptqUiJQGgbRYlMLXzKmEho=WHseVCckptqUiJQGgbRYlMLXzKmExr
     for WHseVCckptqUiJQGgbRYlMLXzKmEhT in WHseVCckptqUiJQGgbRYlMLXzKmEdA['bill']:
      if WHseVCckptqUiJQGgbRYlMLXzKmEhT in WHseVCckptqUiJQGgbRYlMLXzKmEdB.TVING_MOVIE_LITE:
       WHseVCckptqUiJQGgbRYlMLXzKmEho=WHseVCckptqUiJQGgbRYlMLXzKmExI
       break
     if WHseVCckptqUiJQGgbRYlMLXzKmEho==WHseVCckptqUiJQGgbRYlMLXzKmExr: 
      WHseVCckptqUiJQGgbRYlMLXzKmEdT['title']=WHseVCckptqUiJQGgbRYlMLXzKmEdT['title']+' [개별구매]'
     WHseVCckptqUiJQGgbRYlMLXzKmEdf.append(WHseVCckptqUiJQGgbRYlMLXzKmEdT)
   if WHseVCckptqUiJQGgbRYlMLXzKmEhx>(page_int*WHseVCckptqUiJQGgbRYlMLXzKmEdB.TVING_LIMIT):WHseVCckptqUiJQGgbRYlMLXzKmEdS=WHseVCckptqUiJQGgbRYlMLXzKmExI
  except WHseVCckptqUiJQGgbRYlMLXzKmEwd as exception:
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception)
  return WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS
 def Get_Search_Watcha(WHseVCckptqUiJQGgbRYlMLXzKmEdB,search_key,page_int):
  WHseVCckptqUiJQGgbRYlMLXzKmEdf=[]
  WHseVCckptqUiJQGgbRYlMLXzKmEdS=WHseVCckptqUiJQGgbRYlMLXzKmExr
  try:
   WHseVCckptqUiJQGgbRYlMLXzKmEdP=WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_WATCHA+'/api/search.json'
   WHseVCckptqUiJQGgbRYlMLXzKmEhd={'query':search_key,'page':WHseVCckptqUiJQGgbRYlMLXzKmExT(page_int),'per':WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmEdB.WATCHA_LIMIT),'exclude':'limited',}
   WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.Call_Request(WHseVCckptqUiJQGgbRYlMLXzKmEdP,payload=WHseVCckptqUiJQGgbRYlMLXzKmExj,params=WHseVCckptqUiJQGgbRYlMLXzKmEhd,headers=WHseVCckptqUiJQGgbRYlMLXzKmEdB.WATCHA_HEADER,cookies=WHseVCckptqUiJQGgbRYlMLXzKmExj,method='GET')
   WHseVCckptqUiJQGgbRYlMLXzKmEhB=json.loads(WHseVCckptqUiJQGgbRYlMLXzKmEdx.text)
   if not('results' in WHseVCckptqUiJQGgbRYlMLXzKmEhB):return WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS
   WHseVCckptqUiJQGgbRYlMLXzKmEhu=WHseVCckptqUiJQGgbRYlMLXzKmEhB['results']
   WHseVCckptqUiJQGgbRYlMLXzKmEdS=WHseVCckptqUiJQGgbRYlMLXzKmEhB['meta']['has_next']
   for WHseVCckptqUiJQGgbRYlMLXzKmEdA in WHseVCckptqUiJQGgbRYlMLXzKmEhu:
    WHseVCckptqUiJQGgbRYlMLXzKmEhr =WHseVCckptqUiJQGgbRYlMLXzKmEdA['code']
    WHseVCckptqUiJQGgbRYlMLXzKmEBd=WHseVCckptqUiJQGgbRYlMLXzKmEdA['content_type']
    WHseVCckptqUiJQGgbRYlMLXzKmEBh =WHseVCckptqUiJQGgbRYlMLXzKmEdA['title']
    WHseVCckptqUiJQGgbRYlMLXzKmEBa =WHseVCckptqUiJQGgbRYlMLXzKmEdA['story']
    WHseVCckptqUiJQGgbRYlMLXzKmEhf=WHseVCckptqUiJQGgbRYlMLXzKmEhn=WHseVCckptqUiJQGgbRYlMLXzKmExS=''
    if WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('poster') !=WHseVCckptqUiJQGgbRYlMLXzKmExj:WHseVCckptqUiJQGgbRYlMLXzKmEhf=WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('poster').get('original')
    if WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('stillcut')!=WHseVCckptqUiJQGgbRYlMLXzKmExj:WHseVCckptqUiJQGgbRYlMLXzKmEhn =WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('stillcut').get('large')
    if WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('thumbnail')!=WHseVCckptqUiJQGgbRYlMLXzKmExj:WHseVCckptqUiJQGgbRYlMLXzKmExS=WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('thumbnail').get('large')
    if WHseVCckptqUiJQGgbRYlMLXzKmExS=='' :WHseVCckptqUiJQGgbRYlMLXzKmExS=WHseVCckptqUiJQGgbRYlMLXzKmEhn
    WHseVCckptqUiJQGgbRYlMLXzKmEBx={'thumb':WHseVCckptqUiJQGgbRYlMLXzKmEhn,'poster':WHseVCckptqUiJQGgbRYlMLXzKmEhf,'fanart':WHseVCckptqUiJQGgbRYlMLXzKmExS}
    WHseVCckptqUiJQGgbRYlMLXzKmEhA =WHseVCckptqUiJQGgbRYlMLXzKmEdA['year']
    WHseVCckptqUiJQGgbRYlMLXzKmEBw =WHseVCckptqUiJQGgbRYlMLXzKmEdA['film_rating_code']
    WHseVCckptqUiJQGgbRYlMLXzKmEBf=WHseVCckptqUiJQGgbRYlMLXzKmEdA['film_rating_short']
    WHseVCckptqUiJQGgbRYlMLXzKmEBn =WHseVCckptqUiJQGgbRYlMLXzKmEdA['film_rating_long']
    if WHseVCckptqUiJQGgbRYlMLXzKmEBd=='movies':
     WHseVCckptqUiJQGgbRYlMLXzKmEhD =WHseVCckptqUiJQGgbRYlMLXzKmEdA['duration']
    else:
     WHseVCckptqUiJQGgbRYlMLXzKmEhD ='0'
    WHseVCckptqUiJQGgbRYlMLXzKmEdT={'title':WHseVCckptqUiJQGgbRYlMLXzKmEBh,}
    WHseVCckptqUiJQGgbRYlMLXzKmEdf.append(WHseVCckptqUiJQGgbRYlMLXzKmEdT)
  except WHseVCckptqUiJQGgbRYlMLXzKmEwd as exception:
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception)
  return WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS
 def Get_Search_Coupang(WHseVCckptqUiJQGgbRYlMLXzKmEdB,search_key,page_int):
  WHseVCckptqUiJQGgbRYlMLXzKmEdf=[]
  WHseVCckptqUiJQGgbRYlMLXzKmEdS=WHseVCckptqUiJQGgbRYlMLXzKmExr
  try:
   CP=WHseVCckptqUiJQGgbRYlMLXzKmEdB.jsonfile_To_dic(WHseVCckptqUiJQGgbRYlMLXzKmEdB.CP_ORIGINAL_COOKIE)
   WHseVCckptqUiJQGgbRYlMLXzKmEdP=WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_COUPANG+'/v2/search' 
   WHseVCckptqUiJQGgbRYlMLXzKmEhd={'query':search_key,'platform':'WEBCLIENT','page':WHseVCckptqUiJQGgbRYlMLXzKmExT(page_int),'perPage':WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmEdB.COUPANG_LIMIT),}
   WHseVCckptqUiJQGgbRYlMLXzKmEBS={'x-membersrl':CP['SESSION']['member_srl'],'x-pcid':CP['SESSION']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.Call_Request(WHseVCckptqUiJQGgbRYlMLXzKmEdP,payload=WHseVCckptqUiJQGgbRYlMLXzKmExj,params=WHseVCckptqUiJQGgbRYlMLXzKmEhd,headers=WHseVCckptqUiJQGgbRYlMLXzKmEBS,cookies=WHseVCckptqUiJQGgbRYlMLXzKmExj,method='GET')
   WHseVCckptqUiJQGgbRYlMLXzKmEdD=json.loads(WHseVCckptqUiJQGgbRYlMLXzKmEdx.text)
   if WHseVCckptqUiJQGgbRYlMLXzKmEwh(WHseVCckptqUiJQGgbRYlMLXzKmEdD.get('data').get('data'))==0:return WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS
   for WHseVCckptqUiJQGgbRYlMLXzKmEdA in WHseVCckptqUiJQGgbRYlMLXzKmEdD.get('data').get('data'):
    WHseVCckptqUiJQGgbRYlMLXzKmEdA=WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('data')
    WHseVCckptqUiJQGgbRYlMLXzKmEdT={'title':WHseVCckptqUiJQGgbRYlMLXzKmEdA.get('title'),}
    WHseVCckptqUiJQGgbRYlMLXzKmEdf.append(WHseVCckptqUiJQGgbRYlMLXzKmEdT)
   if WHseVCckptqUiJQGgbRYlMLXzKmEdD.get('pagination').get('totalPages')>page_int:
    WHseVCckptqUiJQGgbRYlMLXzKmEdS=WHseVCckptqUiJQGgbRYlMLXzKmExI
  except WHseVCckptqUiJQGgbRYlMLXzKmEwd as exception:
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception)
  return WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS
 def Selenium_Cookies_Load(WHseVCckptqUiJQGgbRYlMLXzKmEdB,in_filename):
  fp=WHseVCckptqUiJQGgbRYlMLXzKmEwB(in_filename,'rb',-1)
  try:
   WHseVCckptqUiJQGgbRYlMLXzKmEBP=pickle.loads(fp.read())
   if WHseVCckptqUiJQGgbRYlMLXzKmEwa(WHseVCckptqUiJQGgbRYlMLXzKmEBP)==WHseVCckptqUiJQGgbRYlMLXzKmEwx:
    for WHseVCckptqUiJQGgbRYlMLXzKmEBv in WHseVCckptqUiJQGgbRYlMLXzKmEBP:
     WHseVCckptqUiJQGgbRYlMLXzKmEdB.HTTP_CLIENT.cookies.set_cookie(WHseVCckptqUiJQGgbRYlMLXzKmEdB.To_Cookielib(WHseVCckptqUiJQGgbRYlMLXzKmEBv)) 
   else:
    WHseVCckptqUiJQGgbRYlMLXzKmEdB.HTTP_CLIENT.cookies.update(WHseVCckptqUiJQGgbRYlMLXzKmEBP) 
  except WHseVCckptqUiJQGgbRYlMLXzKmEwd as exception:
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception)
  finally:
   fp.close()
 def To_Cookielib(WHseVCckptqUiJQGgbRYlMLXzKmEdB,selenium_cookie):
  return http.cookiejar.Cookie(version=0,name=selenium_cookie['name'],value=selenium_cookie['value'],port=WHseVCckptqUiJQGgbRYlMLXzKmExj,port_specified=WHseVCckptqUiJQGgbRYlMLXzKmExr,domain=selenium_cookie['domain'],domain_specified=WHseVCckptqUiJQGgbRYlMLXzKmExI,domain_initial_dot=WHseVCckptqUiJQGgbRYlMLXzKmExr,path=selenium_cookie['path'],path_specified=WHseVCckptqUiJQGgbRYlMLXzKmExI,secure=selenium_cookie['secure'],expires=selenium_cookie['expiry'],discard=WHseVCckptqUiJQGgbRYlMLXzKmExr,comment=WHseVCckptqUiJQGgbRYlMLXzKmExj,comment_url=WHseVCckptqUiJQGgbRYlMLXzKmExj,rest={'HttpOnly':selenium_cookie['httpOnly']},rfc2109=WHseVCckptqUiJQGgbRYlMLXzKmExr,)
 def Get_Search_Primev(WHseVCckptqUiJQGgbRYlMLXzKmEdB,search_key):
  WHseVCckptqUiJQGgbRYlMLXzKmEdf=[]
  try:
   WHseVCckptqUiJQGgbRYlMLXzKmEdB.Selenium_Cookies_Load(WHseVCckptqUiJQGgbRYlMLXzKmEdB.PV_ORIGINAL_COOKIE)
   WHseVCckptqUiJQGgbRYlMLXzKmEdP=WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_PRIMEV+'/search/ref=atv_nb_sr?phrase='+urllib.parse.quote_plus(search_key)+'&ie=UTF8'
   WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.Call_Request(WHseVCckptqUiJQGgbRYlMLXzKmEdP,params=WHseVCckptqUiJQGgbRYlMLXzKmExj,headers=WHseVCckptqUiJQGgbRYlMLXzKmExj,method='GET')
   if WHseVCckptqUiJQGgbRYlMLXzKmEdx.status_code!=200:return[]
   WHseVCckptqUiJQGgbRYlMLXzKmEBO='{"props":{"results"'
   WHseVCckptqUiJQGgbRYlMLXzKmEBA=r'<script type="text/template">\s*(.*?)\s*</script>'
   WHseVCckptqUiJQGgbRYlMLXzKmEBy=re.compile(WHseVCckptqUiJQGgbRYlMLXzKmEBA,re.DOTALL).findall(WHseVCckptqUiJQGgbRYlMLXzKmEdx.text)
   WHseVCckptqUiJQGgbRYlMLXzKmEBF='{}'
   for WHseVCckptqUiJQGgbRYlMLXzKmEBN in WHseVCckptqUiJQGgbRYlMLXzKmEBy:
    if WHseVCckptqUiJQGgbRYlMLXzKmEBO in WHseVCckptqUiJQGgbRYlMLXzKmEBN:
     WHseVCckptqUiJQGgbRYlMLXzKmEBF=WHseVCckptqUiJQGgbRYlMLXzKmEBN
     break
   WHseVCckptqUiJQGgbRYlMLXzKmEdD=json.loads(WHseVCckptqUiJQGgbRYlMLXzKmEBF)
   WHseVCckptqUiJQGgbRYlMLXzKmEBj=WHseVCckptqUiJQGgbRYlMLXzKmEdD.get('props').get('results').get('items')
   for WHseVCckptqUiJQGgbRYlMLXzKmEBI in WHseVCckptqUiJQGgbRYlMLXzKmEBj:
    if 'titleID' not in WHseVCckptqUiJQGgbRYlMLXzKmEBI:return[]
    WHseVCckptqUiJQGgbRYlMLXzKmEdT={'title':WHseVCckptqUiJQGgbRYlMLXzKmEBI.get('title').get('text'),}
    WHseVCckptqUiJQGgbRYlMLXzKmEdf.append(WHseVCckptqUiJQGgbRYlMLXzKmEdT)
  except WHseVCckptqUiJQGgbRYlMLXzKmEwd as exception:
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception)
  return WHseVCckptqUiJQGgbRYlMLXzKmEdf
 def Get_Search_Disney(WHseVCckptqUiJQGgbRYlMLXzKmEdB,search_key):
  WHseVCckptqUiJQGgbRYlMLXzKmEdf=[]
  WHseVCckptqUiJQGgbRYlMLXzKmEdP=WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['services']['content']['getSearchResults']['href']
  WHseVCckptqUiJQGgbRYlMLXzKmEBo={'apiVersion':'5.1','region':WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge','pageSize':WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmEdB.DISNEY_LIMIT),'query':search_key,}
  WHseVCckptqUiJQGgbRYlMLXzKmEdP=WHseVCckptqUiJQGgbRYlMLXzKmEdP.format(**WHseVCckptqUiJQGgbRYlMLXzKmEBo)
  WHseVCckptqUiJQGgbRYlMLXzKmEBS=WHseVCckptqUiJQGgbRYlMLXzKmEdB.make_DZ_Headers(accessToken=WHseVCckptqUiJQGgbRYlMLXzKmExI,Bearer=WHseVCckptqUiJQGgbRYlMLXzKmExI)
  WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.Call_Request(WHseVCckptqUiJQGgbRYlMLXzKmEdP,headers=WHseVCckptqUiJQGgbRYlMLXzKmEBS,method='GET')
  if WHseVCckptqUiJQGgbRYlMLXzKmEdx.status_code not in[200,201]:return[]
  WHseVCckptqUiJQGgbRYlMLXzKmEBT=WHseVCckptqUiJQGgbRYlMLXzKmEdx.json().get('data').get('search')
  for WHseVCckptqUiJQGgbRYlMLXzKmEBI in WHseVCckptqUiJQGgbRYlMLXzKmEBT.get('hits'):
   WHseVCckptqUiJQGgbRYlMLXzKmEBI=WHseVCckptqUiJQGgbRYlMLXzKmEBI.get('hit')
   if WHseVCckptqUiJQGgbRYlMLXzKmEBI.get('type')=='DmcSeries': 
    WHseVCckptqUiJQGgbRYlMLXzKmEBh =WHseVCckptqUiJQGgbRYlMLXzKmEBI.get('text').get('title').get('full').get('series').get('default').get('content')
   elif WHseVCckptqUiJQGgbRYlMLXzKmEBI.get('type')=='DmcVideo':
    WHseVCckptqUiJQGgbRYlMLXzKmEBh =WHseVCckptqUiJQGgbRYlMLXzKmEBI.get('text').get('title').get('full').get('program').get('default').get('content')
   elif WHseVCckptqUiJQGgbRYlMLXzKmEBI.get('type')=='StandardCollection':
    WHseVCckptqUiJQGgbRYlMLXzKmEBh =WHseVCckptqUiJQGgbRYlMLXzKmEBI.get('text').get('title').get('full').get('collection').get('default').get('content')
   else:
    return WHseVCckptqUiJQGgbRYlMLXzKmEdf
   WHseVCckptqUiJQGgbRYlMLXzKmEdT={'title':WHseVCckptqUiJQGgbRYlMLXzKmEBh,}
   WHseVCckptqUiJQGgbRYlMLXzKmEdf.append(WHseVCckptqUiJQGgbRYlMLXzKmEdT)
  return WHseVCckptqUiJQGgbRYlMLXzKmEdf
 def dic_To_jsonfile(WHseVCckptqUiJQGgbRYlMLXzKmEdB,filename,WHseVCckptqUiJQGgbRYlMLXzKmEBu):
  if filename=='':return
  fp=WHseVCckptqUiJQGgbRYlMLXzKmEwB(filename,'w',-1,'utf-8')
  json.dump(WHseVCckptqUiJQGgbRYlMLXzKmEBu,fp,indent=4,ensure_ascii=WHseVCckptqUiJQGgbRYlMLXzKmExr)
  fp.close()
 def jsonfile_To_dic(WHseVCckptqUiJQGgbRYlMLXzKmEdB,filename):
  if filename=='':return WHseVCckptqUiJQGgbRYlMLXzKmExj
  try:
   fp=WHseVCckptqUiJQGgbRYlMLXzKmEwB(filename,'r',-1,'utf-8')
   WHseVCckptqUiJQGgbRYlMLXzKmEad=json.load(fp)
   fp.close()
  except:
   WHseVCckptqUiJQGgbRYlMLXzKmEad={}
  return WHseVCckptqUiJQGgbRYlMLXzKmEad
 def tempFileSave(WHseVCckptqUiJQGgbRYlMLXzKmEdB,filename,resText):
  if filename=='':return
  fp=WHseVCckptqUiJQGgbRYlMLXzKmEwB(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(WHseVCckptqUiJQGgbRYlMLXzKmEdB,filename):
  if filename=='':return
  try:
   fp=WHseVCckptqUiJQGgbRYlMLXzKmEwB(filename,'r',-1,'utf-8')
   WHseVCckptqUiJQGgbRYlMLXzKmEad=fp.read()
   fp.close()
  except:
   WHseVCckptqUiJQGgbRYlMLXzKmEad=''
  return WHseVCckptqUiJQGgbRYlMLXzKmEad
 def make_DZ_Headers(WHseVCckptqUiJQGgbRYlMLXzKmEdB,accessToken=WHseVCckptqUiJQGgbRYlMLXzKmExI,Bearer=WHseVCckptqUiJQGgbRYlMLXzKmExr):
  if accessToken:
   WHseVCckptqUiJQGgbRYlMLXzKmEah=WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['account']['accessToken']
  else:
   WHseVCckptqUiJQGgbRYlMLXzKmEah=WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['headers']['clientApiKey']
  if Bearer:
   WHseVCckptqUiJQGgbRYlMLXzKmEah='Bearer {}'.format(WHseVCckptqUiJQGgbRYlMLXzKmEah)
  WHseVCckptqUiJQGgbRYlMLXzKmEBS={'authorization':WHseVCckptqUiJQGgbRYlMLXzKmEah,'x-application-version':WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['headers']['sdkAppVersion'],'x-bamsdk-client-id':WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['headers']['clientId'],'x-bamsdk-platform':'windows','x-bamsdk-version':WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['headers']['sdkVersion'],'x-dss-edge-accept':'vnd.dss.edge+json; version=2',}
  return WHseVCckptqUiJQGgbRYlMLXzKmEBS
 def DZ_ReToken(WHseVCckptqUiJQGgbRYlMLXzKmEdB):
  try:
   WHseVCckptqUiJQGgbRYlMLXzKmEdP =WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['services']['orchestration']['refreshToken']['href']
   WHseVCckptqUiJQGgbRYlMLXzKmEBS=WHseVCckptqUiJQGgbRYlMLXzKmEdB.make_DZ_Headers(accessToken=WHseVCckptqUiJQGgbRYlMLXzKmExr,Bearer=WHseVCckptqUiJQGgbRYlMLXzKmExr)
   WHseVCckptqUiJQGgbRYlMLXzKmEaB={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['account']['refreshToken'],}}}
   WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.Call_Request(WHseVCckptqUiJQGgbRYlMLXzKmEdP,json=WHseVCckptqUiJQGgbRYlMLXzKmEaB,headers=WHseVCckptqUiJQGgbRYlMLXzKmEBS,method='POST')
   if WHseVCckptqUiJQGgbRYlMLXzKmEdx.status_code not in[200,201]:return WHseVCckptqUiJQGgbRYlMLXzKmExr
   WHseVCckptqUiJQGgbRYlMLXzKmEBT=WHseVCckptqUiJQGgbRYlMLXzKmEdx.json()
   WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['account']['accessToken'] =WHseVCckptqUiJQGgbRYlMLXzKmEBT.get('extensions').get('sdk').get('token').get('accessToken')
   WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['account']['accessTokenType']=WHseVCckptqUiJQGgbRYlMLXzKmEBT.get('extensions').get('sdk').get('token').get('accessTokenType')
   WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['account']['refreshToken'] =WHseVCckptqUiJQGgbRYlMLXzKmEBT.get('extensions').get('sdk').get('token').get('refreshToken')
   WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['account']['token_limit'] =WHseVCckptqUiJQGgbRYlMLXzKmExu(time.time())+14400 
   WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['account']['deviceId'] =WHseVCckptqUiJQGgbRYlMLXzKmEBT.get('extensions').get('sdk').get('session').get('device').get('id')
   WHseVCckptqUiJQGgbRYlMLXzKmEdB.DZ['account']['sessionId'] =WHseVCckptqUiJQGgbRYlMLXzKmEBT.get('extensions').get('sdk').get('session').get('sessionId')
  except WHseVCckptqUiJQGgbRYlMLXzKmEwd as exception:
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception)
   return WHseVCckptqUiJQGgbRYlMLXzKmExr
  return WHseVCckptqUiJQGgbRYlMLXzKmExI
 def Init_NF_Total(WHseVCckptqUiJQGgbRYlMLXzKmEdB):
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF={}
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']={}
  WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']={}
 def make_NF_XnetflixHeaders(WHseVCckptqUiJQGgbRYlMLXzKmEdB):
  WHseVCckptqUiJQGgbRYlMLXzKmEBS={'x-netflix.browsername':WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['esnModel'],'x-netflix.esnprefix':WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['nowGuid'],'x-netflix.uiversion':WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return WHseVCckptqUiJQGgbRYlMLXzKmEBS
 def make_NF_ApiParams(WHseVCckptqUiJQGgbRYlMLXzKmEdB):
  WHseVCckptqUiJQGgbRYlMLXzKmEdv={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['identifier']),}
  return WHseVCckptqUiJQGgbRYlMLXzKmEdv
 def extract_json(WHseVCckptqUiJQGgbRYlMLXzKmEdB,content,name):
  WHseVCckptqUiJQGgbRYlMLXzKmEBA=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  WHseVCckptqUiJQGgbRYlMLXzKmEBF=WHseVCckptqUiJQGgbRYlMLXzKmExj
  WHseVCckptqUiJQGgbRYlMLXzKmEax=re.compile(WHseVCckptqUiJQGgbRYlMLXzKmEBA.format(name),re.DOTALL).findall(content)
  WHseVCckptqUiJQGgbRYlMLXzKmEBF=WHseVCckptqUiJQGgbRYlMLXzKmEax[0]
  WHseVCckptqUiJQGgbRYlMLXzKmEaw=WHseVCckptqUiJQGgbRYlMLXzKmEBF.replace('\\"','\\\\"') 
  WHseVCckptqUiJQGgbRYlMLXzKmEaw=WHseVCckptqUiJQGgbRYlMLXzKmEaw.replace('\\s','\\\\s') 
  WHseVCckptqUiJQGgbRYlMLXzKmEaw=WHseVCckptqUiJQGgbRYlMLXzKmEaw.replace('\\n','\\\\n') 
  WHseVCckptqUiJQGgbRYlMLXzKmEaw=WHseVCckptqUiJQGgbRYlMLXzKmEaw.replace('\\t','\\\\t') 
  WHseVCckptqUiJQGgbRYlMLXzKmEaw=WHseVCckptqUiJQGgbRYlMLXzKmEaw.encode().decode('unicode_escape') 
  WHseVCckptqUiJQGgbRYlMLXzKmEaw=re.sub(r'\\(?!["])',r'\\\\',WHseVCckptqUiJQGgbRYlMLXzKmEaw) 
  return json.loads(WHseVCckptqUiJQGgbRYlMLXzKmEaw)
 def NF_makestr_paths(WHseVCckptqUiJQGgbRYlMLXzKmEdB,paths):
  WHseVCckptqUiJQGgbRYlMLXzKmEad=[]
  if WHseVCckptqUiJQGgbRYlMLXzKmEwf(paths,WHseVCckptqUiJQGgbRYlMLXzKmExu):
   return '%d'%(paths)
  elif WHseVCckptqUiJQGgbRYlMLXzKmEwf(paths,WHseVCckptqUiJQGgbRYlMLXzKmExT):
   return '"%s"'%(paths)
  for WHseVCckptqUiJQGgbRYlMLXzKmEaf in paths:
   if WHseVCckptqUiJQGgbRYlMLXzKmEwf(WHseVCckptqUiJQGgbRYlMLXzKmEaf,WHseVCckptqUiJQGgbRYlMLXzKmExu):
    WHseVCckptqUiJQGgbRYlMLXzKmEad.append('%d'%(WHseVCckptqUiJQGgbRYlMLXzKmEaf))
   elif WHseVCckptqUiJQGgbRYlMLXzKmEwf(WHseVCckptqUiJQGgbRYlMLXzKmEaf,WHseVCckptqUiJQGgbRYlMLXzKmExT):
    WHseVCckptqUiJQGgbRYlMLXzKmEad.append('"%s"'%(WHseVCckptqUiJQGgbRYlMLXzKmEaf))
   elif WHseVCckptqUiJQGgbRYlMLXzKmEwf(WHseVCckptqUiJQGgbRYlMLXzKmEaf,WHseVCckptqUiJQGgbRYlMLXzKmEwx):
    WHseVCckptqUiJQGgbRYlMLXzKmEad.append('[%s]'%(','.join(WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_makestr_paths(WHseVCckptqUiJQGgbRYlMLXzKmEaf))))
   elif WHseVCckptqUiJQGgbRYlMLXzKmEwf(WHseVCckptqUiJQGgbRYlMLXzKmEaf,WHseVCckptqUiJQGgbRYlMLXzKmEwn):
    WHseVCckptqUiJQGgbRYlMLXzKmEan=''
    for WHseVCckptqUiJQGgbRYlMLXzKmEaS,WHseVCckptqUiJQGgbRYlMLXzKmEaP in WHseVCckptqUiJQGgbRYlMLXzKmEaf.items():
     WHseVCckptqUiJQGgbRYlMLXzKmEan+='"%s":%s,'%(WHseVCckptqUiJQGgbRYlMLXzKmEaS,WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_makestr_paths(WHseVCckptqUiJQGgbRYlMLXzKmEaP))
    WHseVCckptqUiJQGgbRYlMLXzKmEad.append('{%s}'%(WHseVCckptqUiJQGgbRYlMLXzKmEan[:-1]))
  return WHseVCckptqUiJQGgbRYlMLXzKmEad
 def NF_Call_pathapi(WHseVCckptqUiJQGgbRYlMLXzKmEdB,WHseVCckptqUiJQGgbRYlMLXzKmEaT,referer=''):
  WHseVCckptqUiJQGgbRYlMLXzKmEav='%s/nq/website/memberapi/%s/pathEvaluator'%(WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_NETFLIX,WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['identifier'])
  WHseVCckptqUiJQGgbRYlMLXzKmEaB={'path':WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_makestr_paths(WHseVCckptqUiJQGgbRYlMLXzKmEaT),'authURL':WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']['authURL']}
  WHseVCckptqUiJQGgbRYlMLXzKmEdv=WHseVCckptqUiJQGgbRYlMLXzKmEdB.make_NF_ApiParams()
  WHseVCckptqUiJQGgbRYlMLXzKmEBS={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':WHseVCckptqUiJQGgbRYlMLXzKmEBS['referer']=referer
  WHseVCckptqUiJQGgbRYlMLXzKmEaD=WHseVCckptqUiJQGgbRYlMLXzKmEdB.make_NF_XnetflixHeaders()
  WHseVCckptqUiJQGgbRYlMLXzKmEBS.update(WHseVCckptqUiJQGgbRYlMLXzKmEaD)
  WHseVCckptqUiJQGgbRYlMLXzKmEaO=WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_Get_DefaultCookies()
  WHseVCckptqUiJQGgbRYlMLXzKmEaO['profilesNewSession']='0'
  try:
   WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.Call_Request(WHseVCckptqUiJQGgbRYlMLXzKmEav,payload=WHseVCckptqUiJQGgbRYlMLXzKmEaB,params=WHseVCckptqUiJQGgbRYlMLXzKmEdv,headers=WHseVCckptqUiJQGgbRYlMLXzKmEBS,cookies=WHseVCckptqUiJQGgbRYlMLXzKmEaO,method='POST')
   return WHseVCckptqUiJQGgbRYlMLXzKmEdx
  except WHseVCckptqUiJQGgbRYlMLXzKmEwd as exception:
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception)
   return WHseVCckptqUiJQGgbRYlMLXzKmExj
 def Get_Search_Netflix(WHseVCckptqUiJQGgbRYlMLXzKmEdB,search_key,page_int,byReference=''):
  WHseVCckptqUiJQGgbRYlMLXzKmEaA=WHseVCckptqUiJQGgbRYlMLXzKmEdB.DERECTOR_LIMIT
  WHseVCckptqUiJQGgbRYlMLXzKmEay =WHseVCckptqUiJQGgbRYlMLXzKmEdB.CAST_LIMIT
  WHseVCckptqUiJQGgbRYlMLXzKmEaF =WHseVCckptqUiJQGgbRYlMLXzKmEdB.GENRE_LIMIT
  WHseVCckptqUiJQGgbRYlMLXzKmEaN =WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_LIMIT*(page_int-1)
  WHseVCckptqUiJQGgbRYlMLXzKmEaj =WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_LIMIT*page_int 
  WHseVCckptqUiJQGgbRYlMLXzKmEaI="|%s"%(search_key)
  WHseVCckptqUiJQGgbRYlMLXzKmEao ='%s/search?%s'%(WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   WHseVCckptqUiJQGgbRYlMLXzKmEaT=[["search","byTerm",WHseVCckptqUiJQGgbRYlMLXzKmEaI,"titles",WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_LIMIT,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"summary"],["search","byTerm",WHseVCckptqUiJQGgbRYlMLXzKmEaI,"titles",WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_LIMIT,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",WHseVCckptqUiJQGgbRYlMLXzKmEaI,"titles",WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_LIMIT,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference","boxarts",[WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND2,WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_PORT],"jpg"],["search","byTerm",WHseVCckptqUiJQGgbRYlMLXzKmEaI,"titles",WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_LIMIT,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference","interestingMoment",WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND1,"jpg"],["search","byTerm",WHseVCckptqUiJQGgbRYlMLXzKmEaI,"titles",WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_LIMIT,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference","storyArt",WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND2,"jpg"],["search","byTerm",WHseVCckptqUiJQGgbRYlMLXzKmEaI,"titles",WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_LIMIT,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference",["cast","creators","directors"],{"from":0,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaA},["id","name"]],["search","byTerm",WHseVCckptqUiJQGgbRYlMLXzKmEaI,"titles",WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_LIMIT,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference","genres",{"from":0,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaF},["id","name"]],["search","byTerm",WHseVCckptqUiJQGgbRYlMLXzKmEaI,"titles",WHseVCckptqUiJQGgbRYlMLXzKmEdB.NETFLIX_LIMIT,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LOGO,"png"],]
  else:
   WHseVCckptqUiJQGgbRYlMLXzKmEaT=[["search","byReference",byReference,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"summary"],["search","byReference",byReference,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference","boxarts",[WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND2,WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference","interestingMoment",WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference","storyArt",WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference",["cast","creators","directors"],{"from":0,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaA},["id","name"]],["search","byReference",byReference,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference","genres",{"from":0,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaF},["id","name"]],["search","byReference",byReference,{"from":WHseVCckptqUiJQGgbRYlMLXzKmEaN,"to":WHseVCckptqUiJQGgbRYlMLXzKmEaj},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LOGO,"png"],]
  try:
   WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_Call_pathapi(WHseVCckptqUiJQGgbRYlMLXzKmEaT,WHseVCckptqUiJQGgbRYlMLXzKmEao)
   WHseVCckptqUiJQGgbRYlMLXzKmEdD=json.loads(WHseVCckptqUiJQGgbRYlMLXzKmEdx.text)
  except WHseVCckptqUiJQGgbRYlMLXzKmEwd as exception:
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception)
  (WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS,byReference)=WHseVCckptqUiJQGgbRYlMLXzKmEdB.Search_Netflix_Make(WHseVCckptqUiJQGgbRYlMLXzKmEdD)
  return WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS,byReference
 def Search_Netflix_Make(WHseVCckptqUiJQGgbRYlMLXzKmEdB,jsonSource):
  WHseVCckptqUiJQGgbRYlMLXzKmEdf=[]
  WHseVCckptqUiJQGgbRYlMLXzKmEdS =WHseVCckptqUiJQGgbRYlMLXzKmExr
  WHseVCckptqUiJQGgbRYlMLXzKmEau=''
  WHseVCckptqUiJQGgbRYlMLXzKmEar=jsonSource.get('paths')[0][1]
  if WHseVCckptqUiJQGgbRYlMLXzKmEar=='byTerm':
   WHseVCckptqUiJQGgbRYlMLXzKmEaN =jsonSource['paths'][0][5]['from']
   WHseVCckptqUiJQGgbRYlMLXzKmEaj =jsonSource['paths'][0][5]['to']
  else:
   WHseVCckptqUiJQGgbRYlMLXzKmEaN =jsonSource['paths'][0][3]['from']
   WHseVCckptqUiJQGgbRYlMLXzKmEaj =jsonSource['paths'][0][3]['to']
  WHseVCckptqUiJQGgbRYlMLXzKmEau=WHseVCckptqUiJQGgbRYlMLXzKmEwx(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  WHseVCckptqUiJQGgbRYlMLXzKmExd=jsonSource.get('jsonGraph').get('search').get('byReference').get(WHseVCckptqUiJQGgbRYlMLXzKmEau)
  WHseVCckptqUiJQGgbRYlMLXzKmExh =jsonSource.get('jsonGraph').get('videos')
  WHseVCckptqUiJQGgbRYlMLXzKmExB=jsonSource.get('jsonGraph').get('person')
  WHseVCckptqUiJQGgbRYlMLXzKmExa=jsonSource.get('jsonGraph').get('genres')
  WHseVCckptqUiJQGgbRYlMLXzKmEdS=WHseVCckptqUiJQGgbRYlMLXzKmExI if WHseVCckptqUiJQGgbRYlMLXzKmExd[WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmEaj)]['reference']['$type']=='ref' else WHseVCckptqUiJQGgbRYlMLXzKmExr
  for WHseVCckptqUiJQGgbRYlMLXzKmExw in WHseVCckptqUiJQGgbRYlMLXzKmEwS(WHseVCckptqUiJQGgbRYlMLXzKmEaN,WHseVCckptqUiJQGgbRYlMLXzKmEaj):
   if WHseVCckptqUiJQGgbRYlMLXzKmExd[WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmExw)]['reference']['$type']=='ref':
    WHseVCckptqUiJQGgbRYlMLXzKmEdj =WHseVCckptqUiJQGgbRYlMLXzKmExd[WHseVCckptqUiJQGgbRYlMLXzKmExT(WHseVCckptqUiJQGgbRYlMLXzKmExw)]['reference']['value'][1]
    WHseVCckptqUiJQGgbRYlMLXzKmExf=WHseVCckptqUiJQGgbRYlMLXzKmExh[WHseVCckptqUiJQGgbRYlMLXzKmEdj]
    WHseVCckptqUiJQGgbRYlMLXzKmEBh =WHseVCckptqUiJQGgbRYlMLXzKmExf['title']['value']
    if WHseVCckptqUiJQGgbRYlMLXzKmExf['availability']['value']['isPlayable']==WHseVCckptqUiJQGgbRYlMLXzKmExr:
     continue
    WHseVCckptqUiJQGgbRYlMLXzKmEdN =WHseVCckptqUiJQGgbRYlMLXzKmExf['summary']['value']['type']
    WHseVCckptqUiJQGgbRYlMLXzKmEhD =0 if WHseVCckptqUiJQGgbRYlMLXzKmEdN!='movie' else WHseVCckptqUiJQGgbRYlMLXzKmExf['runtime']['value']
    if WHseVCckptqUiJQGgbRYlMLXzKmExf['sequiturEvidence']['value']['value']:
     WHseVCckptqUiJQGgbRYlMLXzKmExn=WHseVCckptqUiJQGgbRYlMLXzKmExf['sequiturEvidence']['value']['value']['text']
    else:
     WHseVCckptqUiJQGgbRYlMLXzKmExn=''
    WHseVCckptqUiJQGgbRYlMLXzKmEhf =WHseVCckptqUiJQGgbRYlMLXzKmExf['boxarts'][WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_PORT]['jpg']['value']['url']
    WHseVCckptqUiJQGgbRYlMLXzKmExS =WHseVCckptqUiJQGgbRYlMLXzKmExf['boxarts'][WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND2]['jpg']['value']['url']
    WHseVCckptqUiJQGgbRYlMLXzKmEhn=''
    if 'value' in WHseVCckptqUiJQGgbRYlMLXzKmExf['storyArt'][WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND2]['jpg']:
     WHseVCckptqUiJQGgbRYlMLXzKmEhn =WHseVCckptqUiJQGgbRYlMLXzKmExf['storyArt'][WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND2]['jpg']['value']['url']
    if WHseVCckptqUiJQGgbRYlMLXzKmEhn=='' and 'value' in WHseVCckptqUiJQGgbRYlMLXzKmExf['interestingMoment'][WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND1]['jpg']:
     WHseVCckptqUiJQGgbRYlMLXzKmEhn =WHseVCckptqUiJQGgbRYlMLXzKmExf['interestingMoment'][WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LAND1]['jpg']['value']['url']
    WHseVCckptqUiJQGgbRYlMLXzKmEhj=''
    if 'value' in WHseVCckptqUiJQGgbRYlMLXzKmExf['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LOGO]['png']:
     WHseVCckptqUiJQGgbRYlMLXzKmEhj=WHseVCckptqUiJQGgbRYlMLXzKmExf['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][WHseVCckptqUiJQGgbRYlMLXzKmEdB.ART_SIZE_LOGO]['png']['value']['url']
    WHseVCckptqUiJQGgbRYlMLXzKmEhv =WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_Subid_List(WHseVCckptqUiJQGgbRYlMLXzKmExf['genres'])
    for i in WHseVCckptqUiJQGgbRYlMLXzKmEwS(WHseVCckptqUiJQGgbRYlMLXzKmEwh(WHseVCckptqUiJQGgbRYlMLXzKmEhv)):
     WHseVCckptqUiJQGgbRYlMLXzKmEhv[i]=WHseVCckptqUiJQGgbRYlMLXzKmExa[WHseVCckptqUiJQGgbRYlMLXzKmEhv[i]]['name']['value']
    WHseVCckptqUiJQGgbRYlMLXzKmEhP=WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_Subid_List(WHseVCckptqUiJQGgbRYlMLXzKmExf['directors'])
    WHseVCckptqUiJQGgbRYlMLXzKmExP =WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_Subid_List(WHseVCckptqUiJQGgbRYlMLXzKmExf['creators'])
    WHseVCckptqUiJQGgbRYlMLXzKmEhP.extend(WHseVCckptqUiJQGgbRYlMLXzKmExP)
    for i in WHseVCckptqUiJQGgbRYlMLXzKmEwS(WHseVCckptqUiJQGgbRYlMLXzKmEwh(WHseVCckptqUiJQGgbRYlMLXzKmEhP)):
     WHseVCckptqUiJQGgbRYlMLXzKmEhP[i]=WHseVCckptqUiJQGgbRYlMLXzKmExB[WHseVCckptqUiJQGgbRYlMLXzKmEhP[i]]['name']['value']
    WHseVCckptqUiJQGgbRYlMLXzKmEhS=WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_Subid_List(WHseVCckptqUiJQGgbRYlMLXzKmExf['cast'])
    for i in WHseVCckptqUiJQGgbRYlMLXzKmEwS(WHseVCckptqUiJQGgbRYlMLXzKmEwh(WHseVCckptqUiJQGgbRYlMLXzKmEhS)):
     WHseVCckptqUiJQGgbRYlMLXzKmEhS[i]=WHseVCckptqUiJQGgbRYlMLXzKmExB[WHseVCckptqUiJQGgbRYlMLXzKmEhS[i]]['name']['value']
    if 'maturityDescription' in WHseVCckptqUiJQGgbRYlMLXzKmExf['maturity']['value']['rating']:
     WHseVCckptqUiJQGgbRYlMLXzKmEhO=WHseVCckptqUiJQGgbRYlMLXzKmExf['maturity']['value']['rating']['maturityDescription']
    WHseVCckptqUiJQGgbRYlMLXzKmEdT={'videoid':WHseVCckptqUiJQGgbRYlMLXzKmEdj,'vidtype':WHseVCckptqUiJQGgbRYlMLXzKmEdN,'title':WHseVCckptqUiJQGgbRYlMLXzKmEBh,'mpaa':WHseVCckptqUiJQGgbRYlMLXzKmEhO,'regularSynopsis':WHseVCckptqUiJQGgbRYlMLXzKmExf['regularSynopsis']['value'],'dpSupplemental':WHseVCckptqUiJQGgbRYlMLXzKmExf['dpSupplementalMessage']['value'],'sequiturEvidence':WHseVCckptqUiJQGgbRYlMLXzKmExn,'thumbnail':{'poster':WHseVCckptqUiJQGgbRYlMLXzKmEhf,'thumb':WHseVCckptqUiJQGgbRYlMLXzKmEhn,'fanart':WHseVCckptqUiJQGgbRYlMLXzKmExS,'clearlogo':WHseVCckptqUiJQGgbRYlMLXzKmEhj},'year':WHseVCckptqUiJQGgbRYlMLXzKmExf['releaseYear']['value'],'duration':WHseVCckptqUiJQGgbRYlMLXzKmEhD,'info_genre':WHseVCckptqUiJQGgbRYlMLXzKmEhv,'director':WHseVCckptqUiJQGgbRYlMLXzKmEhP,'cast':WHseVCckptqUiJQGgbRYlMLXzKmEhS,}
    WHseVCckptqUiJQGgbRYlMLXzKmEdf.append(WHseVCckptqUiJQGgbRYlMLXzKmEdT)
  return WHseVCckptqUiJQGgbRYlMLXzKmEdf,WHseVCckptqUiJQGgbRYlMLXzKmEdS,WHseVCckptqUiJQGgbRYlMLXzKmEau
 def NF_Subid_List(WHseVCckptqUiJQGgbRYlMLXzKmEdB,subJson):
  WHseVCckptqUiJQGgbRYlMLXzKmExv=[]
  try:
   for i in WHseVCckptqUiJQGgbRYlMLXzKmEwS(WHseVCckptqUiJQGgbRYlMLXzKmEwh(subJson)):
    if subJson.get(WHseVCckptqUiJQGgbRYlMLXzKmExT(i)).get('$type')!='ref':break
    WHseVCckptqUiJQGgbRYlMLXzKmExD=subJson.get(WHseVCckptqUiJQGgbRYlMLXzKmExT(i)).get('value')[1]
    WHseVCckptqUiJQGgbRYlMLXzKmExv.append(WHseVCckptqUiJQGgbRYlMLXzKmExD)
  except WHseVCckptqUiJQGgbRYlMLXzKmEwd as exception:
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception)
  return WHseVCckptqUiJQGgbRYlMLXzKmExv
 def NF_CookieFile_Load(WHseVCckptqUiJQGgbRYlMLXzKmEdB,cookie_filename):
  WHseVCckptqUiJQGgbRYlMLXzKmEaO={}
  try:
   if os.path.isfile(cookie_filename)==WHseVCckptqUiJQGgbRYlMLXzKmExr:return{}
   WHseVCckptqUiJQGgbRYlMLXzKmExO=WHseVCckptqUiJQGgbRYlMLXzKmEwB(cookie_filename,'rb',-1)
   WHseVCckptqUiJQGgbRYlMLXzKmExA =pickle.loads(WHseVCckptqUiJQGgbRYlMLXzKmExO.read())
   WHseVCckptqUiJQGgbRYlMLXzKmExO.close()
   for WHseVCckptqUiJQGgbRYlMLXzKmEBv in WHseVCckptqUiJQGgbRYlMLXzKmExA:
    WHseVCckptqUiJQGgbRYlMLXzKmEaO[WHseVCckptqUiJQGgbRYlMLXzKmEBv.name]=WHseVCckptqUiJQGgbRYlMLXzKmEBv.value
  except:
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception) 
  return WHseVCckptqUiJQGgbRYlMLXzKmEaO
 def NF_Get_DefaultCookies(WHseVCckptqUiJQGgbRYlMLXzKmEdB):
  WHseVCckptqUiJQGgbRYlMLXzKmEaO={}
  if WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['flwssn'] :WHseVCckptqUiJQGgbRYlMLXzKmEaO['flwssn'] =WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['flwssn']
  if WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['nfvdid'] :WHseVCckptqUiJQGgbRYlMLXzKmEaO['nfvdid'] =WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['nfvdid']
  if WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['SecureNetflixId']:WHseVCckptqUiJQGgbRYlMLXzKmEaO['SecureNetflixId']=WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['SecureNetflixId']
  if WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['NetflixId'] :WHseVCckptqUiJQGgbRYlMLXzKmEaO['NetflixId'] =WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['NetflixId']
  if WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['memclid'] :WHseVCckptqUiJQGgbRYlMLXzKmEaO['memclid'] =WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['memclid']
  if WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['clSharedContext']:WHseVCckptqUiJQGgbRYlMLXzKmEaO['clSharedContext']=WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['COOKIES']['clSharedContext']
  return WHseVCckptqUiJQGgbRYlMLXzKmEaO
 def NF_Get_BaseSession(WHseVCckptqUiJQGgbRYlMLXzKmEdB):
  try:
   WHseVCckptqUiJQGgbRYlMLXzKmEdP=WHseVCckptqUiJQGgbRYlMLXzKmEdB.API_NETFLIX+'/browse' 
   WHseVCckptqUiJQGgbRYlMLXzKmEaO=WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_Get_DefaultCookies()
   WHseVCckptqUiJQGgbRYlMLXzKmEdx=WHseVCckptqUiJQGgbRYlMLXzKmEdB.Call_Request(WHseVCckptqUiJQGgbRYlMLXzKmEdP,payload=WHseVCckptqUiJQGgbRYlMLXzKmExj,params=WHseVCckptqUiJQGgbRYlMLXzKmExj,headers=WHseVCckptqUiJQGgbRYlMLXzKmExj,cookies=WHseVCckptqUiJQGgbRYlMLXzKmEaO,method='GET')
   if WHseVCckptqUiJQGgbRYlMLXzKmEdx.status_code!=200:
    WHseVCckptqUiJQGgbRYlMLXzKmExo('pass 1 status_code error')
    return WHseVCckptqUiJQGgbRYlMLXzKmExr
   WHseVCckptqUiJQGgbRYlMLXzKmExy =WHseVCckptqUiJQGgbRYlMLXzKmEdB.extract_json(WHseVCckptqUiJQGgbRYlMLXzKmEdx.text,'reactContext')
   WHseVCckptqUiJQGgbRYlMLXzKmExF=WHseVCckptqUiJQGgbRYlMLXzKmEdB.extract_json(WHseVCckptqUiJQGgbRYlMLXzKmEdx.text,'falcorCache')
   WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF['SESSION']={'mainGuid':WHseVCckptqUiJQGgbRYlMLXzKmExy['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':WHseVCckptqUiJQGgbRYlMLXzKmExy['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':WHseVCckptqUiJQGgbRYlMLXzKmExy['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':WHseVCckptqUiJQGgbRYlMLXzKmExy['models']['memberContext']['data']['userInfo']['esn'],'identifier':WHseVCckptqUiJQGgbRYlMLXzKmExy['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':WHseVCckptqUiJQGgbRYlMLXzKmExy['models']['abContext']['data']['headers'],}
   WHseVCckptqUiJQGgbRYlMLXzKmEdB.dic_To_jsonfile(WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF_SESSION_COOKIES1,WHseVCckptqUiJQGgbRYlMLXzKmEdB.NF)
  except WHseVCckptqUiJQGgbRYlMLXzKmEwd as exception:
   WHseVCckptqUiJQGgbRYlMLXzKmExo('pass 1 error')
   WHseVCckptqUiJQGgbRYlMLXzKmExo(exception)
   return WHseVCckptqUiJQGgbRYlMLXzKmExr
  return WHseVCckptqUiJQGgbRYlMLXzKmExI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
