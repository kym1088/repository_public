__author__="NightRain"
RPScxOLhaldFCyUYIiKqWVbDkJjsMQ=object
RPScxOLhaldFCyUYIiKqWVbDkJjsME=None
RPScxOLhaldFCyUYIiKqWVbDkJjsMN=True
RPScxOLhaldFCyUYIiKqWVbDkJjsMo=False
RPScxOLhaldFCyUYIiKqWVbDkJjsMA=type
RPScxOLhaldFCyUYIiKqWVbDkJjsMw=dict
RPScxOLhaldFCyUYIiKqWVbDkJjsMe=open
RPScxOLhaldFCyUYIiKqWVbDkJjsMH=len
RPScxOLhaldFCyUYIiKqWVbDkJjsMt=Exception
RPScxOLhaldFCyUYIiKqWVbDkJjsMG=int
RPScxOLhaldFCyUYIiKqWVbDkJjsMu=range
RPScxOLhaldFCyUYIiKqWVbDkJjsMB=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
RPScxOLhaldFCyUYIiKqWVbDkJjsnX=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
RPScxOLhaldFCyUYIiKqWVbDkJjsnr={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'HYPER_LINK','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'HYPER_LINK','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'HYPER_LINK','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
RPScxOLhaldFCyUYIiKqWVbDkJjsnM=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
RPScxOLhaldFCyUYIiKqWVbDkJjsnz =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class RPScxOLhaldFCyUYIiKqWVbDkJjsnm(RPScxOLhaldFCyUYIiKqWVbDkJjsMQ):
 def __init__(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,RPScxOLhaldFCyUYIiKqWVbDkJjsnf,RPScxOLhaldFCyUYIiKqWVbDkJjsnp,RPScxOLhaldFCyUYIiKqWVbDkJjsng):
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv._addon_url =RPScxOLhaldFCyUYIiKqWVbDkJjsnf
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv._addon_handle=RPScxOLhaldFCyUYIiKqWVbDkJjsnp
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.main_params =RPScxOLhaldFCyUYIiKqWVbDkJjsng
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj =WHseVCckptqUiJQGgbRYlMLXzKmEdh() 
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_cookies.pk'))
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,sting):
  try:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnE=xbmcgui.Dialog()
   RPScxOLhaldFCyUYIiKqWVbDkJjsnE.notification(__addonname__,sting)
  except:
   RPScxOLhaldFCyUYIiKqWVbDkJjsME
 def addon_log(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,string):
  try:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnN=string.encode('utf-8','ignore')
  except:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnN='addonException: addon_log'
  RPScxOLhaldFCyUYIiKqWVbDkJjsno=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,RPScxOLhaldFCyUYIiKqWVbDkJjsnN),level=RPScxOLhaldFCyUYIiKqWVbDkJjsno)
 def get_keyboard_input(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,RPScxOLhaldFCyUYIiKqWVbDkJjsnu):
  RPScxOLhaldFCyUYIiKqWVbDkJjsnA=RPScxOLhaldFCyUYIiKqWVbDkJjsME
  kb=xbmc.Keyboard()
  kb.setHeading(RPScxOLhaldFCyUYIiKqWVbDkJjsnu)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   RPScxOLhaldFCyUYIiKqWVbDkJjsnA=kb.getText()
  return RPScxOLhaldFCyUYIiKqWVbDkJjsnA
 def get_settings_menubookmark(RPScxOLhaldFCyUYIiKqWVbDkJjsnv):
  RPScxOLhaldFCyUYIiKqWVbDkJjsnw=RPScxOLhaldFCyUYIiKqWVbDkJjsMN if __addon__.getSetting('menu_bookmark')=='true' else RPScxOLhaldFCyUYIiKqWVbDkJjsMo
  return(RPScxOLhaldFCyUYIiKqWVbDkJjsnw)
 def get_settings_makebookmark(RPScxOLhaldFCyUYIiKqWVbDkJjsnv):
  return RPScxOLhaldFCyUYIiKqWVbDkJjsMN if __addon__.getSetting('make_bookmark')=='true' else RPScxOLhaldFCyUYIiKqWVbDkJjsMo
 def get_settings_select_info(RPScxOLhaldFCyUYIiKqWVbDkJjsnv):
  RPScxOLhaldFCyUYIiKqWVbDkJjsne=[]
  if __addon__.getSetting('netflixyn')=='true':RPScxOLhaldFCyUYIiKqWVbDkJjsne.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':RPScxOLhaldFCyUYIiKqWVbDkJjsne.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':RPScxOLhaldFCyUYIiKqWVbDkJjsne.append('tving')
  if __addon__.getSetting('watchayn')=='true':RPScxOLhaldFCyUYIiKqWVbDkJjsne.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':RPScxOLhaldFCyUYIiKqWVbDkJjsne.append('coupang')
  if __addon__.getSetting('primevyn')=='true':RPScxOLhaldFCyUYIiKqWVbDkJjsne.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':RPScxOLhaldFCyUYIiKqWVbDkJjsne.append('disney')
  return RPScxOLhaldFCyUYIiKqWVbDkJjsne
 def add_dir(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,label,sublabel='',img='',infoLabels=RPScxOLhaldFCyUYIiKqWVbDkJjsME,isFolder=RPScxOLhaldFCyUYIiKqWVbDkJjsMN,params='',isLink=RPScxOLhaldFCyUYIiKqWVbDkJjsMo,ContextMenu=RPScxOLhaldFCyUYIiKqWVbDkJjsME):
  params={'mode':params.get('mode'),'values':params,}
  RPScxOLhaldFCyUYIiKqWVbDkJjsnt=json.dumps(params,separators=(',',':'))
  RPScxOLhaldFCyUYIiKqWVbDkJjsnt=base64.standard_b64encode(RPScxOLhaldFCyUYIiKqWVbDkJjsnt.encode()).decode('utf-8')
  RPScxOLhaldFCyUYIiKqWVbDkJjsnt=RPScxOLhaldFCyUYIiKqWVbDkJjsnt.replace('+','%2B')
  RPScxOLhaldFCyUYIiKqWVbDkJjsnG='%s?params=%s'%(RPScxOLhaldFCyUYIiKqWVbDkJjsnv._addon_url,RPScxOLhaldFCyUYIiKqWVbDkJjsnt)
  if sublabel and sublabel!='-':RPScxOLhaldFCyUYIiKqWVbDkJjsnu='%s < %s >'%(label,sublabel)
  else: RPScxOLhaldFCyUYIiKqWVbDkJjsnu=label
  if not img:img='DefaultFolder.png'
  RPScxOLhaldFCyUYIiKqWVbDkJjsnB=xbmcgui.ListItem(RPScxOLhaldFCyUYIiKqWVbDkJjsnu)
  if RPScxOLhaldFCyUYIiKqWVbDkJjsMA(img)==RPScxOLhaldFCyUYIiKqWVbDkJjsMw:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnB.setArt(img)
  else:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnB.setArt({'thumb':img,'poster':img})
  if infoLabels:RPScxOLhaldFCyUYIiKqWVbDkJjsnB.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnB.setProperty('IsPlayable','true')
  if ContextMenu:RPScxOLhaldFCyUYIiKqWVbDkJjsnB.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(RPScxOLhaldFCyUYIiKqWVbDkJjsnv._addon_handle,RPScxOLhaldFCyUYIiKqWVbDkJjsnG,RPScxOLhaldFCyUYIiKqWVbDkJjsnB,isFolder)
 def Load_Searched_List(RPScxOLhaldFCyUYIiKqWVbDkJjsnv):
  try:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnT=RPScxOLhaldFCyUYIiKqWVbDkJjsnz
   fp=RPScxOLhaldFCyUYIiKqWVbDkJjsMe(RPScxOLhaldFCyUYIiKqWVbDkJjsnT,'r',-1,'utf-8')
   RPScxOLhaldFCyUYIiKqWVbDkJjsmn=fp.readlines()
   fp.close()
  except:
   RPScxOLhaldFCyUYIiKqWVbDkJjsmn=[]
  return RPScxOLhaldFCyUYIiKqWVbDkJjsmn
 def Save_Searched_List(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,RPScxOLhaldFCyUYIiKqWVbDkJjsXA):
  try:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnT=RPScxOLhaldFCyUYIiKqWVbDkJjsnz
   RPScxOLhaldFCyUYIiKqWVbDkJjsmX=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.Load_Searched_List() 
   RPScxOLhaldFCyUYIiKqWVbDkJjsmr={'skey':RPScxOLhaldFCyUYIiKqWVbDkJjsXA.strip()}
   fp=RPScxOLhaldFCyUYIiKqWVbDkJjsMe(RPScxOLhaldFCyUYIiKqWVbDkJjsnT,'w',-1,'utf-8')
   RPScxOLhaldFCyUYIiKqWVbDkJjsmM=urllib.parse.urlencode(RPScxOLhaldFCyUYIiKqWVbDkJjsmr)
   RPScxOLhaldFCyUYIiKqWVbDkJjsmM=RPScxOLhaldFCyUYIiKqWVbDkJjsmM+'\n'
   fp.write(RPScxOLhaldFCyUYIiKqWVbDkJjsmM)
   RPScxOLhaldFCyUYIiKqWVbDkJjsmz=0
   for RPScxOLhaldFCyUYIiKqWVbDkJjsmv in RPScxOLhaldFCyUYIiKqWVbDkJjsmX:
    RPScxOLhaldFCyUYIiKqWVbDkJjsmf=RPScxOLhaldFCyUYIiKqWVbDkJjsMw(urllib.parse.parse_qsl(RPScxOLhaldFCyUYIiKqWVbDkJjsmv))
    RPScxOLhaldFCyUYIiKqWVbDkJjsmp=RPScxOLhaldFCyUYIiKqWVbDkJjsmr.get('skey').strip()
    RPScxOLhaldFCyUYIiKqWVbDkJjsmg=RPScxOLhaldFCyUYIiKqWVbDkJjsmf.get('skey').strip()
    if RPScxOLhaldFCyUYIiKqWVbDkJjsmp!=RPScxOLhaldFCyUYIiKqWVbDkJjsmg:
     fp.write(RPScxOLhaldFCyUYIiKqWVbDkJjsmv)
     RPScxOLhaldFCyUYIiKqWVbDkJjsmz+=1
     if RPScxOLhaldFCyUYIiKqWVbDkJjsmz>=50:break
   fp.close()
  except:
   RPScxOLhaldFCyUYIiKqWVbDkJjsME
 def dp_Search_History(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,args):
  RPScxOLhaldFCyUYIiKqWVbDkJjsmQ=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.Load_Searched_List()
  for RPScxOLhaldFCyUYIiKqWVbDkJjsmE in RPScxOLhaldFCyUYIiKqWVbDkJjsmQ:
   RPScxOLhaldFCyUYIiKqWVbDkJjsmN=RPScxOLhaldFCyUYIiKqWVbDkJjsMw(urllib.parse.parse_qsl(RPScxOLhaldFCyUYIiKqWVbDkJjsmE))
   RPScxOLhaldFCyUYIiKqWVbDkJjsmo=RPScxOLhaldFCyUYIiKqWVbDkJjsmN.get('skey').strip()
   RPScxOLhaldFCyUYIiKqWVbDkJjsnH={'mode':'TOTAL_SEARCH','search_key':RPScxOLhaldFCyUYIiKqWVbDkJjsmo,}
   RPScxOLhaldFCyUYIiKqWVbDkJjsmA={'mode':'HISTORY_REMOVE','skey':RPScxOLhaldFCyUYIiKqWVbDkJjsmo,'delmode':'ONE',}
   RPScxOLhaldFCyUYIiKqWVbDkJjsmw=urllib.parse.urlencode(RPScxOLhaldFCyUYIiKqWVbDkJjsmA)
   RPScxOLhaldFCyUYIiKqWVbDkJjsme=[('선택된 검색어 ( %s ) 삭제'%(RPScxOLhaldFCyUYIiKqWVbDkJjsmo),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(RPScxOLhaldFCyUYIiKqWVbDkJjsmw))]
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.add_dir(RPScxOLhaldFCyUYIiKqWVbDkJjsmo,sublabel='',img=RPScxOLhaldFCyUYIiKqWVbDkJjsME,infoLabels=RPScxOLhaldFCyUYIiKqWVbDkJjsME,isFolder=RPScxOLhaldFCyUYIiKqWVbDkJjsMN,params=RPScxOLhaldFCyUYIiKqWVbDkJjsnH,ContextMenu=RPScxOLhaldFCyUYIiKqWVbDkJjsme)
  RPScxOLhaldFCyUYIiKqWVbDkJjsmt={'plot':'검색목록 전체를 삭제합니다.'}
  RPScxOLhaldFCyUYIiKqWVbDkJjsnu='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  RPScxOLhaldFCyUYIiKqWVbDkJjsnH={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  RPScxOLhaldFCyUYIiKqWVbDkJjsmG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.add_dir(RPScxOLhaldFCyUYIiKqWVbDkJjsnu,sublabel='',img=RPScxOLhaldFCyUYIiKqWVbDkJjsmG,infoLabels=RPScxOLhaldFCyUYIiKqWVbDkJjsmt,isFolder=RPScxOLhaldFCyUYIiKqWVbDkJjsMo,params=RPScxOLhaldFCyUYIiKqWVbDkJjsnH,isLink=RPScxOLhaldFCyUYIiKqWVbDkJjsMN)
  xbmcplugin.endOfDirectory(RPScxOLhaldFCyUYIiKqWVbDkJjsnv._addon_handle,cacheToDisc=RPScxOLhaldFCyUYIiKqWVbDkJjsMo)
 def Delete_History_List(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,RPScxOLhaldFCyUYIiKqWVbDkJjsmo,RPScxOLhaldFCyUYIiKqWVbDkJjsmT):
  if RPScxOLhaldFCyUYIiKqWVbDkJjsmT=='ALL':
   try:
    RPScxOLhaldFCyUYIiKqWVbDkJjsnT=RPScxOLhaldFCyUYIiKqWVbDkJjsnz
    fp=RPScxOLhaldFCyUYIiKqWVbDkJjsMe(RPScxOLhaldFCyUYIiKqWVbDkJjsnT,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    RPScxOLhaldFCyUYIiKqWVbDkJjsME
  else:
   try:
    RPScxOLhaldFCyUYIiKqWVbDkJjsnT=RPScxOLhaldFCyUYIiKqWVbDkJjsnz
    RPScxOLhaldFCyUYIiKqWVbDkJjsmX=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.Load_Searched_List() 
    fp=RPScxOLhaldFCyUYIiKqWVbDkJjsMe(RPScxOLhaldFCyUYIiKqWVbDkJjsnT,'w',-1,'utf-8')
    for RPScxOLhaldFCyUYIiKqWVbDkJjsmv in RPScxOLhaldFCyUYIiKqWVbDkJjsmX:
     RPScxOLhaldFCyUYIiKqWVbDkJjsmf=RPScxOLhaldFCyUYIiKqWVbDkJjsMw(urllib.parse.parse_qsl(RPScxOLhaldFCyUYIiKqWVbDkJjsmv))
     RPScxOLhaldFCyUYIiKqWVbDkJjsmB=RPScxOLhaldFCyUYIiKqWVbDkJjsmf.get('skey').strip()
     if RPScxOLhaldFCyUYIiKqWVbDkJjsmo!=RPScxOLhaldFCyUYIiKqWVbDkJjsmB:
      fp.write(RPScxOLhaldFCyUYIiKqWVbDkJjsmv)
    fp.close()
   except:
    RPScxOLhaldFCyUYIiKqWVbDkJjsME
 def dp_History_Delete(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,args):
  RPScxOLhaldFCyUYIiKqWVbDkJjsmo =args.get('skey') 
  RPScxOLhaldFCyUYIiKqWVbDkJjsmT=args.get('delmode')
  RPScxOLhaldFCyUYIiKqWVbDkJjsnE=xbmcgui.Dialog()
  if RPScxOLhaldFCyUYIiKqWVbDkJjsmT=='ALL':
   RPScxOLhaldFCyUYIiKqWVbDkJjsXn=RPScxOLhaldFCyUYIiKqWVbDkJjsnE.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   RPScxOLhaldFCyUYIiKqWVbDkJjsXn=RPScxOLhaldFCyUYIiKqWVbDkJjsnE.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if RPScxOLhaldFCyUYIiKqWVbDkJjsXn==RPScxOLhaldFCyUYIiKqWVbDkJjsMo:sys.exit()
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.Delete_History_List(RPScxOLhaldFCyUYIiKqWVbDkJjsmo,RPScxOLhaldFCyUYIiKqWVbDkJjsmT)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(RPScxOLhaldFCyUYIiKqWVbDkJjsnv):
  RPScxOLhaldFCyUYIiKqWVbDkJjsnw=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.get_settings_menubookmark()
  for RPScxOLhaldFCyUYIiKqWVbDkJjsXm in RPScxOLhaldFCyUYIiKqWVbDkJjsnX:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnu=RPScxOLhaldFCyUYIiKqWVbDkJjsXm.get('title')
   RPScxOLhaldFCyUYIiKqWVbDkJjsmG=''
   if RPScxOLhaldFCyUYIiKqWVbDkJjsXm.get('mode')=='MENU_BOOKMARK' and RPScxOLhaldFCyUYIiKqWVbDkJjsnw==RPScxOLhaldFCyUYIiKqWVbDkJjsMo:continue
   RPScxOLhaldFCyUYIiKqWVbDkJjsnH={'mode':RPScxOLhaldFCyUYIiKqWVbDkJjsXm.get('mode')}
   if RPScxOLhaldFCyUYIiKqWVbDkJjsXm.get('mode')in['XXX','MENU_BOOKMARK']:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXr=RPScxOLhaldFCyUYIiKqWVbDkJjsMo
    RPScxOLhaldFCyUYIiKqWVbDkJjsXM =RPScxOLhaldFCyUYIiKqWVbDkJjsMN
   else:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXr=RPScxOLhaldFCyUYIiKqWVbDkJjsMN
    RPScxOLhaldFCyUYIiKqWVbDkJjsXM =RPScxOLhaldFCyUYIiKqWVbDkJjsMo
   if 'icon' in RPScxOLhaldFCyUYIiKqWVbDkJjsXm:RPScxOLhaldFCyUYIiKqWVbDkJjsmG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',RPScxOLhaldFCyUYIiKqWVbDkJjsXm.get('icon')) 
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.add_dir(RPScxOLhaldFCyUYIiKqWVbDkJjsnu,sublabel='',img=RPScxOLhaldFCyUYIiKqWVbDkJjsmG,infoLabels=RPScxOLhaldFCyUYIiKqWVbDkJjsME,isFolder=RPScxOLhaldFCyUYIiKqWVbDkJjsXr,params=RPScxOLhaldFCyUYIiKqWVbDkJjsnH,isLink=RPScxOLhaldFCyUYIiKqWVbDkJjsXM)
  xbmcplugin.endOfDirectory(RPScxOLhaldFCyUYIiKqWVbDkJjsnv._addon_handle,cacheToDisc=RPScxOLhaldFCyUYIiKqWVbDkJjsMo)
 def option_check(RPScxOLhaldFCyUYIiKqWVbDkJjsnv):
  RPScxOLhaldFCyUYIiKqWVbDkJjsne=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.get_settings_select_info()
  if RPScxOLhaldFCyUYIiKqWVbDkJjsMH(RPScxOLhaldFCyUYIiKqWVbDkJjsne)==0:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnE=xbmcgui.Dialog()
   RPScxOLhaldFCyUYIiKqWVbDkJjsXn=RPScxOLhaldFCyUYIiKqWVbDkJjsnE.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if RPScxOLhaldFCyUYIiKqWVbDkJjsXn==RPScxOLhaldFCyUYIiKqWVbDkJjsMN:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in RPScxOLhaldFCyUYIiKqWVbDkJjsne:
   if RPScxOLhaldFCyUYIiKqWVbDkJjsnv.NF_cookiefile_check()==RPScxOLhaldFCyUYIiKqWVbDkJjsMo:
    RPScxOLhaldFCyUYIiKqWVbDkJjsnv.NF_login(showMessage=RPScxOLhaldFCyUYIiKqWVbDkJjsMN)
  if 'disney' in RPScxOLhaldFCyUYIiKqWVbDkJjsne:
   if RPScxOLhaldFCyUYIiKqWVbDkJjsnv.DZ_cookiefile_check()==RPScxOLhaldFCyUYIiKqWVbDkJjsMo:
    RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.DZ={}
 def DZ_cookiefile_check(RPScxOLhaldFCyUYIiKqWVbDkJjsnv):
  RPScxOLhaldFCyUYIiKqWVbDkJjsXv={}
  try: 
   fp=RPScxOLhaldFCyUYIiKqWVbDkJjsMe(RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   RPScxOLhaldFCyUYIiKqWVbDkJjsXv= json.load(fp)
   fp.close()
  except RPScxOLhaldFCyUYIiKqWVbDkJjsMt as exception:
   return RPScxOLhaldFCyUYIiKqWVbDkJjsMo
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.DZ=RPScxOLhaldFCyUYIiKqWVbDkJjsXv
  if RPScxOLhaldFCyUYIiKqWVbDkJjsMG(time.time())>RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.DZ['account']['token_limit']:
   if RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.DZ_ReToken()==RPScxOLhaldFCyUYIiKqWVbDkJjsMo:
    RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_noti(__language__(30920).encode('utf-8'))
    return RPScxOLhaldFCyUYIiKqWVbDkJjsMo
   try: 
    fp=RPScxOLhaldFCyUYIiKqWVbDkJjsMe(RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.DZ,fp,indent=4,ensure_ascii=RPScxOLhaldFCyUYIiKqWVbDkJjsMo)
    fp.close()
   except RPScxOLhaldFCyUYIiKqWVbDkJjsMt as exception:
    return RPScxOLhaldFCyUYIiKqWVbDkJjsMo
  return RPScxOLhaldFCyUYIiKqWVbDkJjsMN
 def NF_cookiefile_check(RPScxOLhaldFCyUYIiKqWVbDkJjsnv):
  RPScxOLhaldFCyUYIiKqWVbDkJjsXv={}
  try: 
   fp=RPScxOLhaldFCyUYIiKqWVbDkJjsMe(RPScxOLhaldFCyUYIiKqWVbDkJjsnM,'r',-1,'utf-8')
   RPScxOLhaldFCyUYIiKqWVbDkJjsXv= json.load(fp)
   fp.close()
  except RPScxOLhaldFCyUYIiKqWVbDkJjsMt as exception:
   return RPScxOLhaldFCyUYIiKqWVbDkJjsMo
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF=RPScxOLhaldFCyUYIiKqWVbDkJjsXv
  RPScxOLhaldFCyUYIiKqWVbDkJjsXp=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF_CookieFile_Load(RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF_ORIGINAL_COOKIE)
  if(RPScxOLhaldFCyUYIiKqWVbDkJjsXp['NetflixId']!=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF['COOKIES']['NetflixId']or RPScxOLhaldFCyUYIiKqWVbDkJjsXp['SecureNetflixId']!=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF['COOKIES']['SecureNetflixId']or RPScxOLhaldFCyUYIiKqWVbDkJjsXp['flwssn']!=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF['COOKIES']['flwssn']or RPScxOLhaldFCyUYIiKqWVbDkJjsXp['memclid']!=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF['COOKIES']['memclid']or RPScxOLhaldFCyUYIiKqWVbDkJjsXp['nfvdid']!=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF['COOKIES']['nfvdid']):
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Init_NF_Total()
   if RPScxOLhaldFCyUYIiKqWVbDkJjsnv.NF_login(showMessage=RPScxOLhaldFCyUYIiKqWVbDkJjsMo)==RPScxOLhaldFCyUYIiKqWVbDkJjsMo:
    return RPScxOLhaldFCyUYIiKqWVbDkJjsMo
  return RPScxOLhaldFCyUYIiKqWVbDkJjsMN
 def NF_login(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,showMessage=RPScxOLhaldFCyUYIiKqWVbDkJjsMN):
  if showMessage:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnE=xbmcgui.Dialog()
   RPScxOLhaldFCyUYIiKqWVbDkJjsXn=RPScxOLhaldFCyUYIiKqWVbDkJjsnE.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if RPScxOLhaldFCyUYIiKqWVbDkJjsXn==RPScxOLhaldFCyUYIiKqWVbDkJjsMo:
    return RPScxOLhaldFCyUYIiKqWVbDkJjsMo 
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF['COOKIES']=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF_CookieFile_Load(RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF_ORIGINAL_COOKIE)
  RPScxOLhaldFCyUYIiKqWVbDkJjsXg=RPScxOLhaldFCyUYIiKqWVbDkJjsMo if RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF['COOKIES']=={}else RPScxOLhaldFCyUYIiKqWVbDkJjsMN
  if RPScxOLhaldFCyUYIiKqWVbDkJjsXg:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_log('pass1 ok!')
  else:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_log('pass1 error!')
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_noti(__language__(30905).encode('utf-8'))
   return RPScxOLhaldFCyUYIiKqWVbDkJjsMo 
  RPScxOLhaldFCyUYIiKqWVbDkJjsXg=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF_Get_BaseSession()
  if RPScxOLhaldFCyUYIiKqWVbDkJjsXg:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_log('pass2 ok!')
  else:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_log('pass2 error!')
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_noti(__language__(30905).encode('utf-8'))
   return RPScxOLhaldFCyUYIiKqWVbDkJjsMo 
  RPScxOLhaldFCyUYIiKqWVbDkJjsXQ =RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Get_Now_Datetime()
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF['SESSION']['limitdate']=RPScxOLhaldFCyUYIiKqWVbDkJjsXQ.strftime('%Y-%m-%d')
  try: 
   fp=RPScxOLhaldFCyUYIiKqWVbDkJjsMe(RPScxOLhaldFCyUYIiKqWVbDkJjsnM,'w',-1,'utf-8')
   json.dump(RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF,fp,indent=4,ensure_ascii=RPScxOLhaldFCyUYIiKqWVbDkJjsMo)
   fp.close()
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_log('pass3 save ok!')
  except RPScxOLhaldFCyUYIiKqWVbDkJjsMt as exception:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_log('pass3 save error!')
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_noti(__language__(30905).encode('utf-8'))
   return RPScxOLhaldFCyUYIiKqWVbDkJjsMo
  if showMessage:RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_noti(__language__(30904).encode('utf-8'))
  return RPScxOLhaldFCyUYIiKqWVbDkJjsMN
 def NF_logout(RPScxOLhaldFCyUYIiKqWVbDkJjsnv):
  RPScxOLhaldFCyUYIiKqWVbDkJjsnE=xbmcgui.Dialog()
  RPScxOLhaldFCyUYIiKqWVbDkJjsXn=RPScxOLhaldFCyUYIiKqWVbDkJjsnE.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if RPScxOLhaldFCyUYIiKqWVbDkJjsXn==RPScxOLhaldFCyUYIiKqWVbDkJjsMo:return 
  if os.path.isfile(RPScxOLhaldFCyUYIiKqWVbDkJjsnM):os.remove(RPScxOLhaldFCyUYIiKqWVbDkJjsnM)
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,RPScxOLhaldFCyUYIiKqWVbDkJjsXw):
  RPScxOLhaldFCyUYIiKqWVbDkJjsXE=''
  RPScxOLhaldFCyUYIiKqWVbDkJjsXN=7
  try:
   for i in RPScxOLhaldFCyUYIiKqWVbDkJjsMu(RPScxOLhaldFCyUYIiKqWVbDkJjsMH(RPScxOLhaldFCyUYIiKqWVbDkJjsXw)):
    if i>=RPScxOLhaldFCyUYIiKqWVbDkJjsXN:
     RPScxOLhaldFCyUYIiKqWVbDkJjsXE=RPScxOLhaldFCyUYIiKqWVbDkJjsXE+'...'
     break
    RPScxOLhaldFCyUYIiKqWVbDkJjsXE=RPScxOLhaldFCyUYIiKqWVbDkJjsXE+RPScxOLhaldFCyUYIiKqWVbDkJjsXw[i]['title']+'\n'
  except:
   return ''
  return RPScxOLhaldFCyUYIiKqWVbDkJjsXE
 def dp_Search_Group(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,args):
  RPScxOLhaldFCyUYIiKqWVbDkJjsne =RPScxOLhaldFCyUYIiKqWVbDkJjsnv.get_settings_select_info()
  RPScxOLhaldFCyUYIiKqWVbDkJjsXo=[]
  if 'search_key' in args:
   RPScxOLhaldFCyUYIiKqWVbDkJjsXA=args.get('search_key')
  else:
   RPScxOLhaldFCyUYIiKqWVbDkJjsXA=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not RPScxOLhaldFCyUYIiKqWVbDkJjsXA:
    return
  if 'wavve' in RPScxOLhaldFCyUYIiKqWVbDkJjsne:
   (RPScxOLhaldFCyUYIiKqWVbDkJjsXw,RPScxOLhaldFCyUYIiKqWVbDkJjsXe)=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Get_Search_Wavve(RPScxOLhaldFCyUYIiKqWVbDkJjsXA,'TVSHOW',1)
   if RPScxOLhaldFCyUYIiKqWVbDkJjsMH(RPScxOLhaldFCyUYIiKqWVbDkJjsXw)>0:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXH={'sType':'wavve_tvshow','sList':RPScxOLhaldFCyUYIiKqWVbDkJjsnv.MakeText_FreeList(RPScxOLhaldFCyUYIiKqWVbDkJjsXw),}
    RPScxOLhaldFCyUYIiKqWVbDkJjsXo.append(RPScxOLhaldFCyUYIiKqWVbDkJjsXH)
   (RPScxOLhaldFCyUYIiKqWVbDkJjsXw,RPScxOLhaldFCyUYIiKqWVbDkJjsXe)=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Get_Search_Wavve(RPScxOLhaldFCyUYIiKqWVbDkJjsXA,'MOVIE',1)
   if RPScxOLhaldFCyUYIiKqWVbDkJjsMH(RPScxOLhaldFCyUYIiKqWVbDkJjsXw)>0:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXH={'sType':'wavve_movie','sList':RPScxOLhaldFCyUYIiKqWVbDkJjsnv.MakeText_FreeList(RPScxOLhaldFCyUYIiKqWVbDkJjsXw),}
    RPScxOLhaldFCyUYIiKqWVbDkJjsXo.append(RPScxOLhaldFCyUYIiKqWVbDkJjsXH)
  if 'tving' in RPScxOLhaldFCyUYIiKqWVbDkJjsne:
   (RPScxOLhaldFCyUYIiKqWVbDkJjsXw,RPScxOLhaldFCyUYIiKqWVbDkJjsXe)=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Get_Search_Tving(RPScxOLhaldFCyUYIiKqWVbDkJjsXA,'TVSHOW',1)
   if RPScxOLhaldFCyUYIiKqWVbDkJjsMH(RPScxOLhaldFCyUYIiKqWVbDkJjsXw)>0:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXH={'sType':'tving_tvshow','sList':RPScxOLhaldFCyUYIiKqWVbDkJjsnv.MakeText_FreeList(RPScxOLhaldFCyUYIiKqWVbDkJjsXw),}
    RPScxOLhaldFCyUYIiKqWVbDkJjsXo.append(RPScxOLhaldFCyUYIiKqWVbDkJjsXH)
   (RPScxOLhaldFCyUYIiKqWVbDkJjsXw,RPScxOLhaldFCyUYIiKqWVbDkJjsXe)=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Get_Search_Tving(RPScxOLhaldFCyUYIiKqWVbDkJjsXA,'MOVIE',1)
   if RPScxOLhaldFCyUYIiKqWVbDkJjsMH(RPScxOLhaldFCyUYIiKqWVbDkJjsXw)>0:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXH={'sType':'tving_movie','sList':RPScxOLhaldFCyUYIiKqWVbDkJjsnv.MakeText_FreeList(RPScxOLhaldFCyUYIiKqWVbDkJjsXw),}
    RPScxOLhaldFCyUYIiKqWVbDkJjsXo.append(RPScxOLhaldFCyUYIiKqWVbDkJjsXH)
  if 'watcha' in RPScxOLhaldFCyUYIiKqWVbDkJjsne:
   (RPScxOLhaldFCyUYIiKqWVbDkJjsXw,RPScxOLhaldFCyUYIiKqWVbDkJjsXe)=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Get_Search_Watcha(RPScxOLhaldFCyUYIiKqWVbDkJjsXA,1)
   if RPScxOLhaldFCyUYIiKqWVbDkJjsMH(RPScxOLhaldFCyUYIiKqWVbDkJjsXw)>0:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXH={'sType':'watcha_list','sList':RPScxOLhaldFCyUYIiKqWVbDkJjsnv.MakeText_FreeList(RPScxOLhaldFCyUYIiKqWVbDkJjsXw),}
    RPScxOLhaldFCyUYIiKqWVbDkJjsXo.append(RPScxOLhaldFCyUYIiKqWVbDkJjsXH)
  if 'coupang' in RPScxOLhaldFCyUYIiKqWVbDkJjsne:
   (RPScxOLhaldFCyUYIiKqWVbDkJjsXw,RPScxOLhaldFCyUYIiKqWVbDkJjsXe)=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Get_Search_Coupang(RPScxOLhaldFCyUYIiKqWVbDkJjsXA,1)
   if RPScxOLhaldFCyUYIiKqWVbDkJjsMH(RPScxOLhaldFCyUYIiKqWVbDkJjsXw)>0:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXH={'sType':'coupang_list','sList':RPScxOLhaldFCyUYIiKqWVbDkJjsnv.MakeText_FreeList(RPScxOLhaldFCyUYIiKqWVbDkJjsXw),}
    RPScxOLhaldFCyUYIiKqWVbDkJjsXo.append(RPScxOLhaldFCyUYIiKqWVbDkJjsXH)
  if 'netflix' in RPScxOLhaldFCyUYIiKqWVbDkJjsne:
   try:
    (RPScxOLhaldFCyUYIiKqWVbDkJjsXw,RPScxOLhaldFCyUYIiKqWVbDkJjsXe,RPScxOLhaldFCyUYIiKqWVbDkJjsXt)=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Get_Search_Netflix(RPScxOLhaldFCyUYIiKqWVbDkJjsXA,1)
   except:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXw=[]
    RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_noti(__language__(30919).encode('utf8'))
   if RPScxOLhaldFCyUYIiKqWVbDkJjsMH(RPScxOLhaldFCyUYIiKqWVbDkJjsXw)>0:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXH={'sType':'netflix_list','sList':RPScxOLhaldFCyUYIiKqWVbDkJjsnv.MakeText_FreeList(RPScxOLhaldFCyUYIiKqWVbDkJjsXw),}
    RPScxOLhaldFCyUYIiKqWVbDkJjsXo.append(RPScxOLhaldFCyUYIiKqWVbDkJjsXH)
  if 'amazon' in RPScxOLhaldFCyUYIiKqWVbDkJjsne:
   (RPScxOLhaldFCyUYIiKqWVbDkJjsXw)=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Get_Search_Primev(RPScxOLhaldFCyUYIiKqWVbDkJjsXA)
   if RPScxOLhaldFCyUYIiKqWVbDkJjsMH(RPScxOLhaldFCyUYIiKqWVbDkJjsXw)>0:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXH={'sType':'primev_list','sList':RPScxOLhaldFCyUYIiKqWVbDkJjsnv.MakeText_FreeList(RPScxOLhaldFCyUYIiKqWVbDkJjsXw),}
    RPScxOLhaldFCyUYIiKqWVbDkJjsXo.append(RPScxOLhaldFCyUYIiKqWVbDkJjsXH)
  if 'disney' in RPScxOLhaldFCyUYIiKqWVbDkJjsne:
   try:
    (RPScxOLhaldFCyUYIiKqWVbDkJjsXw)=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Get_Search_Disney(RPScxOLhaldFCyUYIiKqWVbDkJjsXA)
   except:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXw=[]
    RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_noti(__language__(30921).encode('utf8'))
   if RPScxOLhaldFCyUYIiKqWVbDkJjsMH(RPScxOLhaldFCyUYIiKqWVbDkJjsXw)>0:
    RPScxOLhaldFCyUYIiKqWVbDkJjsXH={'sType':'disney_list','sList':RPScxOLhaldFCyUYIiKqWVbDkJjsnv.MakeText_FreeList(RPScxOLhaldFCyUYIiKqWVbDkJjsXw),}
    RPScxOLhaldFCyUYIiKqWVbDkJjsXo.append(RPScxOLhaldFCyUYIiKqWVbDkJjsXH)
  for RPScxOLhaldFCyUYIiKqWVbDkJjsXG in RPScxOLhaldFCyUYIiKqWVbDkJjsXo:
   RPScxOLhaldFCyUYIiKqWVbDkJjsXu=RPScxOLhaldFCyUYIiKqWVbDkJjsnr[RPScxOLhaldFCyUYIiKqWVbDkJjsXG.get('sType')]
   RPScxOLhaldFCyUYIiKqWVbDkJjsXB={'plot':'검색어 : '+RPScxOLhaldFCyUYIiKqWVbDkJjsXA+'\n\n'+RPScxOLhaldFCyUYIiKqWVbDkJjsXG.get('sList')}
   RPScxOLhaldFCyUYIiKqWVbDkJjsnu=RPScxOLhaldFCyUYIiKqWVbDkJjsXu.get('title')
   RPScxOLhaldFCyUYIiKqWVbDkJjsnH={'mode':RPScxOLhaldFCyUYIiKqWVbDkJjsXu.get('mode'),'ott':RPScxOLhaldFCyUYIiKqWVbDkJjsXu.get('ott'),'vidtype':RPScxOLhaldFCyUYIiKqWVbDkJjsXu.get('vidtype'),'search_key':RPScxOLhaldFCyUYIiKqWVbDkJjsXA}
   if RPScxOLhaldFCyUYIiKqWVbDkJjsXu.get('ott')=='netflix':
    RPScxOLhaldFCyUYIiKqWVbDkJjsnH['page'] ='1'
    RPScxOLhaldFCyUYIiKqWVbDkJjsnH['byReference']='-'
   RPScxOLhaldFCyUYIiKqWVbDkJjsmG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',RPScxOLhaldFCyUYIiKqWVbDkJjsXu.get('icon'))
   RPScxOLhaldFCyUYIiKqWVbDkJjsXr=RPScxOLhaldFCyUYIiKqWVbDkJjsMN if RPScxOLhaldFCyUYIiKqWVbDkJjsXu.get('mode')!='HYPER_LINK' else RPScxOLhaldFCyUYIiKqWVbDkJjsMo
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.add_dir(RPScxOLhaldFCyUYIiKqWVbDkJjsnu,sublabel='',img=RPScxOLhaldFCyUYIiKqWVbDkJjsmG,infoLabels=RPScxOLhaldFCyUYIiKqWVbDkJjsXB,isFolder=RPScxOLhaldFCyUYIiKqWVbDkJjsXr,params=RPScxOLhaldFCyUYIiKqWVbDkJjsnH,isLink=RPScxOLhaldFCyUYIiKqWVbDkJjsMN)
  xbmcplugin.endOfDirectory(RPScxOLhaldFCyUYIiKqWVbDkJjsnv._addon_handle)
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.Save_Searched_List(RPScxOLhaldFCyUYIiKqWVbDkJjsXA)
 def dp_Hyper_Link(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,args):
  RPScxOLhaldFCyUYIiKqWVbDkJjsXT =args.get('mode')
  RPScxOLhaldFCyUYIiKqWVbDkJjsrn =args.get('ott')
  RPScxOLhaldFCyUYIiKqWVbDkJjsrm =args.get('vidtype')
  RPScxOLhaldFCyUYIiKqWVbDkJjsXA=args.get('search_key')
  RPScxOLhaldFCyUYIiKqWVbDkJjsrX='-'
  if RPScxOLhaldFCyUYIiKqWVbDkJjsrn=='wavve':
   RPScxOLhaldFCyUYIiKqWVbDkJjsrM={'mode':'LOCAL_SEARCH','sType':'movie' if RPScxOLhaldFCyUYIiKqWVbDkJjsrm=='MOVIE' else 'vod','search_key':RPScxOLhaldFCyUYIiKqWVbDkJjsXA,'page':'1',}
   RPScxOLhaldFCyUYIiKqWVbDkJjsrz=urllib.parse.urlencode(RPScxOLhaldFCyUYIiKqWVbDkJjsrM)
   RPScxOLhaldFCyUYIiKqWVbDkJjsrX='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(RPScxOLhaldFCyUYIiKqWVbDkJjsrz)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsrn=='tving':
   RPScxOLhaldFCyUYIiKqWVbDkJjsrM={'mode':'LOCAL_SEARCH','stype':'movie' if RPScxOLhaldFCyUYIiKqWVbDkJjsrm=='MOVIE' else 'vod','search_key':RPScxOLhaldFCyUYIiKqWVbDkJjsXA,'page':'1',}
   RPScxOLhaldFCyUYIiKqWVbDkJjsrz=urllib.parse.urlencode(RPScxOLhaldFCyUYIiKqWVbDkJjsrM)
   RPScxOLhaldFCyUYIiKqWVbDkJjsrX='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(RPScxOLhaldFCyUYIiKqWVbDkJjsrz)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsrn=='watcha':
   RPScxOLhaldFCyUYIiKqWVbDkJjsrM={'mode':'LOCAL_SEARCH','search_key':RPScxOLhaldFCyUYIiKqWVbDkJjsXA,'page':'1',}
   RPScxOLhaldFCyUYIiKqWVbDkJjsrz=urllib.parse.urlencode(RPScxOLhaldFCyUYIiKqWVbDkJjsrM)
   RPScxOLhaldFCyUYIiKqWVbDkJjsrX='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(RPScxOLhaldFCyUYIiKqWVbDkJjsrz)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsrn=='coupang':
   RPScxOLhaldFCyUYIiKqWVbDkJjsrM={'mode':'LOCAL_SEARCH','search_key':RPScxOLhaldFCyUYIiKqWVbDkJjsXA,'page':'1',}
   RPScxOLhaldFCyUYIiKqWVbDkJjsrz=urllib.parse.urlencode(RPScxOLhaldFCyUYIiKqWVbDkJjsrM)
   RPScxOLhaldFCyUYIiKqWVbDkJjsrX='ActivateWindow(10025,"plugin://plugin.video.coupangm/?%s",return)'%(RPScxOLhaldFCyUYIiKqWVbDkJjsrz)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsrn=='netflix':
   RPScxOLhaldFCyUYIiKqWVbDkJjsrv=args.get('videoid')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrf=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.NF['SESSION']['nowGuid']
   if RPScxOLhaldFCyUYIiKqWVbDkJjsrm=='TVSHOW':
    RPScxOLhaldFCyUYIiKqWVbDkJjsrX='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(RPScxOLhaldFCyUYIiKqWVbDkJjsrv)
   else:
    RPScxOLhaldFCyUYIiKqWVbDkJjsrX='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(RPScxOLhaldFCyUYIiKqWVbDkJjsrv,RPScxOLhaldFCyUYIiKqWVbDkJjsrf)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsrn=='amazon':
   RPScxOLhaldFCyUYIiKqWVbDkJjsrM={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':RPScxOLhaldFCyUYIiKqWVbDkJjsXA,}}
   RPScxOLhaldFCyUYIiKqWVbDkJjsrz=json.dumps(RPScxOLhaldFCyUYIiKqWVbDkJjsrM,separators=(',',':'))
   RPScxOLhaldFCyUYIiKqWVbDkJjsrz=base64.standard_b64encode(RPScxOLhaldFCyUYIiKqWVbDkJjsrz.encode()).decode('utf-8')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrz=RPScxOLhaldFCyUYIiKqWVbDkJjsrz.replace('+','%2B')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrX='ActivateWindow(10025,"plugin://plugin.video.primevm/?params=%s",return)'%(RPScxOLhaldFCyUYIiKqWVbDkJjsrz)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsrn=='disney':
   RPScxOLhaldFCyUYIiKqWVbDkJjsrM={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':RPScxOLhaldFCyUYIiKqWVbDkJjsXA,}}
   RPScxOLhaldFCyUYIiKqWVbDkJjsrz=json.dumps(RPScxOLhaldFCyUYIiKqWVbDkJjsrM,separators=(',',':'))
   RPScxOLhaldFCyUYIiKqWVbDkJjsrz=base64.standard_b64encode(RPScxOLhaldFCyUYIiKqWVbDkJjsrz.encode()).decode('utf-8')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrz=RPScxOLhaldFCyUYIiKqWVbDkJjsrz.replace('+','%2B')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrX='ActivateWindow(10025,"plugin://plugin.video.disneym/?params=%s",return)'%(RPScxOLhaldFCyUYIiKqWVbDkJjsrz)
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.addon_log('ott_url ==> ( '+RPScxOLhaldFCyUYIiKqWVbDkJjsrX+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(RPScxOLhaldFCyUYIiKqWVbDkJjsrX)
 def dp_Nf_Search(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,args):
  RPScxOLhaldFCyUYIiKqWVbDkJjsrp =RPScxOLhaldFCyUYIiKqWVbDkJjsMG(args.get('page'))
  RPScxOLhaldFCyUYIiKqWVbDkJjsXA =args.get('search_key')
  RPScxOLhaldFCyUYIiKqWVbDkJjsXt=args.get('byReference')
  (RPScxOLhaldFCyUYIiKqWVbDkJjsXw,RPScxOLhaldFCyUYIiKqWVbDkJjsXe,RPScxOLhaldFCyUYIiKqWVbDkJjsXt)=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.SearchObj.Get_Search_Netflix(RPScxOLhaldFCyUYIiKqWVbDkJjsXA,RPScxOLhaldFCyUYIiKqWVbDkJjsrp,byReference=RPScxOLhaldFCyUYIiKqWVbDkJjsXt)
  for RPScxOLhaldFCyUYIiKqWVbDkJjsrg in RPScxOLhaldFCyUYIiKqWVbDkJjsXw:
   RPScxOLhaldFCyUYIiKqWVbDkJjsrv =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('videoid')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrm =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('vidtype')
   RPScxOLhaldFCyUYIiKqWVbDkJjsnu =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('title')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrQ =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('mpaa')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrE =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('regularSynopsis')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrN =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('dpSupplemental')
   RPScxOLhaldFCyUYIiKqWVbDkJjsro=RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('sequiturEvidence')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrA =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('thumbnail')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrw =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('year')
   RPScxOLhaldFCyUYIiKqWVbDkJjsre =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('duration')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrH =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('info_genre')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrt =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('director')
   RPScxOLhaldFCyUYIiKqWVbDkJjsrG =RPScxOLhaldFCyUYIiKqWVbDkJjsrg.get('cast')
   if RPScxOLhaldFCyUYIiKqWVbDkJjsrm=='movie':
    RPScxOLhaldFCyUYIiKqWVbDkJjsmH=' (%s)'%(RPScxOLhaldFCyUYIiKqWVbDkJjsMB(RPScxOLhaldFCyUYIiKqWVbDkJjsrw))
   else:
    RPScxOLhaldFCyUYIiKqWVbDkJjsmH=''
   RPScxOLhaldFCyUYIiKqWVbDkJjsru=''
   if RPScxOLhaldFCyUYIiKqWVbDkJjsrE:RPScxOLhaldFCyUYIiKqWVbDkJjsru=RPScxOLhaldFCyUYIiKqWVbDkJjsru+'\n\n'+RPScxOLhaldFCyUYIiKqWVbDkJjsrE
   if RPScxOLhaldFCyUYIiKqWVbDkJjsrN :RPScxOLhaldFCyUYIiKqWVbDkJjsru=RPScxOLhaldFCyUYIiKqWVbDkJjsru+'\n\n'+RPScxOLhaldFCyUYIiKqWVbDkJjsrN
   if RPScxOLhaldFCyUYIiKqWVbDkJjsro:RPScxOLhaldFCyUYIiKqWVbDkJjsru=RPScxOLhaldFCyUYIiKqWVbDkJjsru+'\n\n'+RPScxOLhaldFCyUYIiKqWVbDkJjsro
   RPScxOLhaldFCyUYIiKqWVbDkJjsru=RPScxOLhaldFCyUYIiKqWVbDkJjsru.strip()
   RPScxOLhaldFCyUYIiKqWVbDkJjsmt={'mediatype':'tvshow' if RPScxOLhaldFCyUYIiKqWVbDkJjsrm=='show' else 'movie','title':RPScxOLhaldFCyUYIiKqWVbDkJjsnu,'mpaa':RPScxOLhaldFCyUYIiKqWVbDkJjsrQ,'plot':RPScxOLhaldFCyUYIiKqWVbDkJjsru,'duration':RPScxOLhaldFCyUYIiKqWVbDkJjsre,'genre':RPScxOLhaldFCyUYIiKqWVbDkJjsrH,'director':RPScxOLhaldFCyUYIiKqWVbDkJjsrt,'cast':RPScxOLhaldFCyUYIiKqWVbDkJjsrG,'year':RPScxOLhaldFCyUYIiKqWVbDkJjsrw,}
   RPScxOLhaldFCyUYIiKqWVbDkJjsnH={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if RPScxOLhaldFCyUYIiKqWVbDkJjsrm=='show' else 'MOVIE','videoid':RPScxOLhaldFCyUYIiKqWVbDkJjsrv,}
   if RPScxOLhaldFCyUYIiKqWVbDkJjsnv.get_settings_makebookmark():
    RPScxOLhaldFCyUYIiKqWVbDkJjsrB={'mode':'SET_BOOKMARK','values':{'videoid':RPScxOLhaldFCyUYIiKqWVbDkJjsrv,'vidtype':'tvshow' if RPScxOLhaldFCyUYIiKqWVbDkJjsrm=='show' else 'movie','vtitle':RPScxOLhaldFCyUYIiKqWVbDkJjsnu+RPScxOLhaldFCyUYIiKqWVbDkJjsmH,'vsubtitle':'','vinfo':RPScxOLhaldFCyUYIiKqWVbDkJjsmt,'thumbnail':RPScxOLhaldFCyUYIiKqWVbDkJjsrA,}}
    RPScxOLhaldFCyUYIiKqWVbDkJjsrT=json.dumps(RPScxOLhaldFCyUYIiKqWVbDkJjsrB,separators=(',',':'))
    RPScxOLhaldFCyUYIiKqWVbDkJjsrT=base64.standard_b64encode(RPScxOLhaldFCyUYIiKqWVbDkJjsrT.encode()).decode('utf-8')
    RPScxOLhaldFCyUYIiKqWVbDkJjsrT=RPScxOLhaldFCyUYIiKqWVbDkJjsrT.replace('+','%2B')
    RPScxOLhaldFCyUYIiKqWVbDkJjsMn='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(RPScxOLhaldFCyUYIiKqWVbDkJjsrT)
    RPScxOLhaldFCyUYIiKqWVbDkJjsme=[('(통합) 찜 영상에 추가',RPScxOLhaldFCyUYIiKqWVbDkJjsMn)]
   else:
    RPScxOLhaldFCyUYIiKqWVbDkJjsme=RPScxOLhaldFCyUYIiKqWVbDkJjsME
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.add_dir(RPScxOLhaldFCyUYIiKqWVbDkJjsnu+RPScxOLhaldFCyUYIiKqWVbDkJjsmH,sublabel=RPScxOLhaldFCyUYIiKqWVbDkJjsME,img=RPScxOLhaldFCyUYIiKqWVbDkJjsrA,infoLabels=RPScxOLhaldFCyUYIiKqWVbDkJjsmt,isFolder=RPScxOLhaldFCyUYIiKqWVbDkJjsMo,params=RPScxOLhaldFCyUYIiKqWVbDkJjsnH,isLink=RPScxOLhaldFCyUYIiKqWVbDkJjsMN,ContextMenu=RPScxOLhaldFCyUYIiKqWVbDkJjsme)
  if RPScxOLhaldFCyUYIiKqWVbDkJjsXe:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnH={}
   RPScxOLhaldFCyUYIiKqWVbDkJjsnH['mode'] ='NF_SEARCH' 
   RPScxOLhaldFCyUYIiKqWVbDkJjsnH['page'] =RPScxOLhaldFCyUYIiKqWVbDkJjsMB(RPScxOLhaldFCyUYIiKqWVbDkJjsrp+1)
   RPScxOLhaldFCyUYIiKqWVbDkJjsnH['search_key']=RPScxOLhaldFCyUYIiKqWVbDkJjsXA
   RPScxOLhaldFCyUYIiKqWVbDkJjsnH['byReference']=RPScxOLhaldFCyUYIiKqWVbDkJjsXt
   RPScxOLhaldFCyUYIiKqWVbDkJjsnu='[B]%s >>[/B]'%'다음 페이지'
   RPScxOLhaldFCyUYIiKqWVbDkJjsMm=RPScxOLhaldFCyUYIiKqWVbDkJjsMB(RPScxOLhaldFCyUYIiKqWVbDkJjsrp+1)
   RPScxOLhaldFCyUYIiKqWVbDkJjsmG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.add_dir(RPScxOLhaldFCyUYIiKqWVbDkJjsnu,sublabel=RPScxOLhaldFCyUYIiKqWVbDkJjsMm,img=RPScxOLhaldFCyUYIiKqWVbDkJjsmG,infoLabels=RPScxOLhaldFCyUYIiKqWVbDkJjsME,isFolder=RPScxOLhaldFCyUYIiKqWVbDkJjsMN,params=RPScxOLhaldFCyUYIiKqWVbDkJjsnH)
  xbmcplugin.setContent(RPScxOLhaldFCyUYIiKqWVbDkJjsnv._addon_handle,'movies')
  xbmcplugin.endOfDirectory(RPScxOLhaldFCyUYIiKqWVbDkJjsnv._addon_handle)
 def dp_Bookmark_Menu(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,args):
  RPScxOLhaldFCyUYIiKqWVbDkJjsrX='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(RPScxOLhaldFCyUYIiKqWVbDkJjsrX)
 def dp_Set_Bookmark(RPScxOLhaldFCyUYIiKqWVbDkJjsnv,args):
  RPScxOLhaldFCyUYIiKqWVbDkJjsrv =args.get('videoid')
  RPScxOLhaldFCyUYIiKqWVbDkJjsrm =args.get('vidtype')
  RPScxOLhaldFCyUYIiKqWVbDkJjsMX =args.get('vtitle')
  RPScxOLhaldFCyUYIiKqWVbDkJjsMr =args.get('vsubtitle')
  RPScxOLhaldFCyUYIiKqWVbDkJjsMz =args.get('vinfo')
  RPScxOLhaldFCyUYIiKqWVbDkJjsrA =args.get('thumbnail')
  RPScxOLhaldFCyUYIiKqWVbDkJjsnE=xbmcgui.Dialog()
  RPScxOLhaldFCyUYIiKqWVbDkJjsXn=RPScxOLhaldFCyUYIiKqWVbDkJjsnE.yesno(__language__(30917).encode('utf8'),RPScxOLhaldFCyUYIiKqWVbDkJjsMX+' \n\n'+__language__(30918))
  if RPScxOLhaldFCyUYIiKqWVbDkJjsXn==RPScxOLhaldFCyUYIiKqWVbDkJjsMo:return
  RPScxOLhaldFCyUYIiKqWVbDkJjsMv={'indexinfo':{'ott':'netflix','videoid':RPScxOLhaldFCyUYIiKqWVbDkJjsrv,'vidtype':RPScxOLhaldFCyUYIiKqWVbDkJjsrm,},'saveinfo':{'title':RPScxOLhaldFCyUYIiKqWVbDkJjsMX,'subtitle':RPScxOLhaldFCyUYIiKqWVbDkJjsMr,'thumbnail':RPScxOLhaldFCyUYIiKqWVbDkJjsrA,'infoLabels':RPScxOLhaldFCyUYIiKqWVbDkJjsMz,},}
  RPScxOLhaldFCyUYIiKqWVbDkJjsnH={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':RPScxOLhaldFCyUYIiKqWVbDkJjsMv,}}
  RPScxOLhaldFCyUYIiKqWVbDkJjsnt=json.dumps(RPScxOLhaldFCyUYIiKqWVbDkJjsnH,separators=(',',':'))
  RPScxOLhaldFCyUYIiKqWVbDkJjsnt=base64.standard_b64encode(RPScxOLhaldFCyUYIiKqWVbDkJjsnt.encode()).decode('utf-8')
  RPScxOLhaldFCyUYIiKqWVbDkJjsnt=RPScxOLhaldFCyUYIiKqWVbDkJjsnt.replace('+','%2B')
  RPScxOLhaldFCyUYIiKqWVbDkJjsMn='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(RPScxOLhaldFCyUYIiKqWVbDkJjsnt)
  xbmc.executebuiltin(RPScxOLhaldFCyUYIiKqWVbDkJjsMn)
 def search_main(RPScxOLhaldFCyUYIiKqWVbDkJjsnv):
  RPScxOLhaldFCyUYIiKqWVbDkJjsMf=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.main_params.get('params')
  if RPScxOLhaldFCyUYIiKqWVbDkJjsMf:
   RPScxOLhaldFCyUYIiKqWVbDkJjsMp =base64.standard_b64decode(RPScxOLhaldFCyUYIiKqWVbDkJjsMf).decode('utf-8')
   RPScxOLhaldFCyUYIiKqWVbDkJjsMp =json.loads(RPScxOLhaldFCyUYIiKqWVbDkJjsMp)
   RPScxOLhaldFCyUYIiKqWVbDkJjsXT =RPScxOLhaldFCyUYIiKqWVbDkJjsMp.get('mode')
   RPScxOLhaldFCyUYIiKqWVbDkJjsMg =RPScxOLhaldFCyUYIiKqWVbDkJjsMp.get('values')
  else:
   RPScxOLhaldFCyUYIiKqWVbDkJjsXT=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.main_params.get('mode',RPScxOLhaldFCyUYIiKqWVbDkJjsME)
   RPScxOLhaldFCyUYIiKqWVbDkJjsMg=RPScxOLhaldFCyUYIiKqWVbDkJjsnv.main_params
  if RPScxOLhaldFCyUYIiKqWVbDkJjsXT=='NFLOGOUT':
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.NF_logout()
   return
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsXT=='NFLOGIN':
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.NF_login(showMessage=RPScxOLhaldFCyUYIiKqWVbDkJjsMN)
   return
  RPScxOLhaldFCyUYIiKqWVbDkJjsnv.option_check()
  if RPScxOLhaldFCyUYIiKqWVbDkJjsXT is RPScxOLhaldFCyUYIiKqWVbDkJjsME:
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.dp_Main_List()
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsXT=='TOTAL_SEARCH':
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.dp_Search_Group(RPScxOLhaldFCyUYIiKqWVbDkJjsMg)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsXT=='HYPER_LINK':
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.dp_Hyper_Link(RPScxOLhaldFCyUYIiKqWVbDkJjsMg)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsXT=='NF_SEARCH':
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.dp_Nf_Search(RPScxOLhaldFCyUYIiKqWVbDkJjsMg)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsXT=='TOTAL_HISTORY':
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.dp_Search_History(RPScxOLhaldFCyUYIiKqWVbDkJjsMg)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsXT=='HISTORY_REMOVE':
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.dp_History_Delete(RPScxOLhaldFCyUYIiKqWVbDkJjsMg)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsXT=='MENU_BOOKMARK':
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.dp_Bookmark_Menu(RPScxOLhaldFCyUYIiKqWVbDkJjsMg)
  elif RPScxOLhaldFCyUYIiKqWVbDkJjsXT=='SET_BOOKMARK':
   RPScxOLhaldFCyUYIiKqWVbDkJjsnv.dp_Set_Bookmark(RPScxOLhaldFCyUYIiKqWVbDkJjsMg)
  else:
   RPScxOLhaldFCyUYIiKqWVbDkJjsME
# Created by pyminifier (https://github.com/liftoff/pyminifier)
