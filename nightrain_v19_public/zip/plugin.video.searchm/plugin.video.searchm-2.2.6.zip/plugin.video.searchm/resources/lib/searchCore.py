__author__="NightRain"
jnAfmbzLckOeoshyWCwgDvEJlBYVIi=object
jnAfmbzLckOeoshyWCwgDvEJlBYVId=None
jnAfmbzLckOeoshyWCwgDvEJlBYVIS=True
jnAfmbzLckOeoshyWCwgDvEJlBYVIM=print
jnAfmbzLckOeoshyWCwgDvEJlBYVIp=str
jnAfmbzLckOeoshyWCwgDvEJlBYVIG=int
jnAfmbzLckOeoshyWCwgDvEJlBYVIT=False
jnAfmbzLckOeoshyWCwgDvEJlBYVIU=dict
jnAfmbzLckOeoshyWCwgDvEJlBYVIR=Exception
jnAfmbzLckOeoshyWCwgDvEJlBYVIH=len
jnAfmbzLckOeoshyWCwgDvEJlBYVIr=open
jnAfmbzLckOeoshyWCwgDvEJlBYVIu=type
jnAfmbzLckOeoshyWCwgDvEJlBYVIK=list
jnAfmbzLckOeoshyWCwgDvEJlBYVIQ=isinstance
jnAfmbzLckOeoshyWCwgDvEJlBYVIq=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
import http.cookiejar
class jnAfmbzLckOeoshyWCwgDvEJlBYVNP(jnAfmbzLckOeoshyWCwgDvEJlBYVIi):
 def __init__(jnAfmbzLckOeoshyWCwgDvEJlBYVNt):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_WAVVE ='https://apis.wavve.com'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_TVING_SEARCH='https://search-api.tving.com'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_TVING_IMG ='https://image.tving.com'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_WATCHA ='https://api-mars.watcha.com'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_NETFLIX ='https://www.netflix.com'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_COUPANG ='https://www.coupangplay.com'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_PRIMEV ='https://www.primevideo.com'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_DISNEY ='https://disney.api.edge.bamgrid.com/explore'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_DISNEY_VERSION ='v1.11'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.WAVVE_LIMIT =20 
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.TVING_LIMIT =30
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.WATCHA_LIMIT =30
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_LIMIT =20 
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.COUPANG_LIMIT =10 
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DISNEY_LIMIT =10 
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DERECTOR_LIMIT =4
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.CAST_LIMIT =10
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.GENRE_LIMIT =4
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.TVING_MOVIE_LITE=['2610061','2610161','261062']
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100','APIKEY':'1e7952d0917d6aab1f0293a063697610','TELECODE':'CSCD0900',}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_HEADER={'user-agent':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND1 ='_342x192'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND2 ='_665x375'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_PORT ='_342x684'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LOGO ='_550x124'
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF={}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['COOKIES']={}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']={}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ={}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.PV={}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.HTTP_CLIENT=requests.Session()
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.CP_ORIGINAL_COOKIE =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.PV_ORIGINAL_COOKIE =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ_ORIGINAL_COOKIE =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_ORIGINAL_COOKIE =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_SESSION_COOKIES1 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_SESSION_COOKIES2 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_SESSION_COOKIES3 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_SESSION_COOKIES4 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_SESSION_FULLTEXT1 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_SESSION_FULLTEXT2 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_SESSION_FULLTEXT3 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_SESSION_FULLTEXT4 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_CONTEXTJSON_FILE1 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_CONTEXTJSON_FILE2 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_CONTEXTJSON_FILE3 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_CONTEXTJSON_FILE4 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_FALCORJSON_FILE1 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_FALCORJSON_FILE2 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_FALCORJSON_FILE3 =''
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_FALCORJSON_FILE4 =''
 '''
 def callRequestCookies(self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):
  #setHeader = {'user-agent' : self.USER_AGENT }
  setHeader = self.DEFAULT_HEADER
  if headers: setHeader.update(headers )
  if jobtype == 'Get': # Get/Post
   res = requests.get(url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  else:
   res = requests.post(url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
  return res
 ''' 
 def Call_Request(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,jnAfmbzLckOeoshyWCwgDvEJlBYVNd,payload=jnAfmbzLckOeoshyWCwgDvEJlBYVId,json=jnAfmbzLckOeoshyWCwgDvEJlBYVId,params=jnAfmbzLckOeoshyWCwgDvEJlBYVId,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVId,cookies=jnAfmbzLckOeoshyWCwgDvEJlBYVId,redirects=jnAfmbzLckOeoshyWCwgDvEJlBYVIS,method='-'):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNX={'user-agent':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.USER_AGENT}
  if headers:jnAfmbzLckOeoshyWCwgDvEJlBYVNX.update(headers)
  if payload!=jnAfmbzLckOeoshyWCwgDvEJlBYVId or method=='POST':
   jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.HTTP_CLIENT.post(url=jnAfmbzLckOeoshyWCwgDvEJlBYVNd,data=payload,json=json,params=params,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVNX,cookies=cookies,allow_redirects=redirects)
  else:
   jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.HTTP_CLIENT.get(url=jnAfmbzLckOeoshyWCwgDvEJlBYVNd,params=params,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVNX,cookies=cookies,allow_redirects=redirects)
  jnAfmbzLckOeoshyWCwgDvEJlBYVIM(jnAfmbzLckOeoshyWCwgDvEJlBYVIp(jnAfmbzLckOeoshyWCwgDvEJlBYVNI.status_code)+' - '+jnAfmbzLckOeoshyWCwgDvEJlBYVIp(jnAfmbzLckOeoshyWCwgDvEJlBYVNI.url))
  return jnAfmbzLckOeoshyWCwgDvEJlBYVNI
 def GetNoCache(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,timetype=1,minutes=0):
  if timetype==1:
   ts=jnAfmbzLckOeoshyWCwgDvEJlBYVIG(time.time())
   mi=jnAfmbzLckOeoshyWCwgDvEJlBYVIG(minutes*60)
  else:
   ts=jnAfmbzLckOeoshyWCwgDvEJlBYVIG(time.time()*1000)
   mi=jnAfmbzLckOeoshyWCwgDvEJlBYVIG(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(jnAfmbzLckOeoshyWCwgDvEJlBYVNt):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,search_key,sType,page_int):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNF=[]
  jnAfmbzLckOeoshyWCwgDvEJlBYVNa=jnAfmbzLckOeoshyWCwgDvEJlBYVPt=1
  jnAfmbzLckOeoshyWCwgDvEJlBYVNi=jnAfmbzLckOeoshyWCwgDvEJlBYVIT
  try:
   jnAfmbzLckOeoshyWCwgDvEJlBYVNd=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_WAVVE+'/fz/search/band.js'
   jnAfmbzLckOeoshyWCwgDvEJlBYVNS={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':jnAfmbzLckOeoshyWCwgDvEJlBYVIp((page_int-1)*jnAfmbzLckOeoshyWCwgDvEJlBYVNt.WAVVE_LIMIT),'limit':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.WAVVE_LIMIT,'orderby':'score','mtype':'svod',}
   jnAfmbzLckOeoshyWCwgDvEJlBYVNS.update(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.WAVVE_PARAMS)
   jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.Call_Request(jnAfmbzLckOeoshyWCwgDvEJlBYVNd,payload=jnAfmbzLckOeoshyWCwgDvEJlBYVId,params=jnAfmbzLckOeoshyWCwgDvEJlBYVNS,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVId,cookies=jnAfmbzLckOeoshyWCwgDvEJlBYVId,method='GET')
   jnAfmbzLckOeoshyWCwgDvEJlBYVNM=json.loads(jnAfmbzLckOeoshyWCwgDvEJlBYVNI.text)
   if not('celllist' in jnAfmbzLckOeoshyWCwgDvEJlBYVNM['band']):return jnAfmbzLckOeoshyWCwgDvEJlBYVNF,jnAfmbzLckOeoshyWCwgDvEJlBYVNi
   jnAfmbzLckOeoshyWCwgDvEJlBYVNp=jnAfmbzLckOeoshyWCwgDvEJlBYVNM['band']['celllist']
   for jnAfmbzLckOeoshyWCwgDvEJlBYVNG in jnAfmbzLckOeoshyWCwgDvEJlBYVNp:
    jnAfmbzLckOeoshyWCwgDvEJlBYVNT =jnAfmbzLckOeoshyWCwgDvEJlBYVNG['event_list'][1]['url']
    jnAfmbzLckOeoshyWCwgDvEJlBYVNU=urllib.parse.urlsplit(jnAfmbzLckOeoshyWCwgDvEJlBYVNT).query
    jnAfmbzLckOeoshyWCwgDvEJlBYVNR=jnAfmbzLckOeoshyWCwgDvEJlBYVNU[0:jnAfmbzLckOeoshyWCwgDvEJlBYVNU.find('=')]
    jnAfmbzLckOeoshyWCwgDvEJlBYVNH=jnAfmbzLckOeoshyWCwgDvEJlBYVIU(urllib.parse.parse_qsl(jnAfmbzLckOeoshyWCwgDvEJlBYVNU))
    jnAfmbzLckOeoshyWCwgDvEJlBYVNr=jnAfmbzLckOeoshyWCwgDvEJlBYVNH.get(jnAfmbzLckOeoshyWCwgDvEJlBYVNR)
    jnAfmbzLckOeoshyWCwgDvEJlBYVNR='TVSHOW' if jnAfmbzLckOeoshyWCwgDvEJlBYVNR=='programid' else 'MOVIE' 
    jnAfmbzLckOeoshyWCwgDvEJlBYVNu=jnAfmbzLckOeoshyWCwgDvEJlBYVNG['title_list'][0]['text']
    jnAfmbzLckOeoshyWCwgDvEJlBYVNK =jnAfmbzLckOeoshyWCwgDvEJlBYVNG['age']
    jnAfmbzLckOeoshyWCwgDvEJlBYVNQ={'title':jnAfmbzLckOeoshyWCwgDvEJlBYVNu}
    jnAfmbzLckOeoshyWCwgDvEJlBYVNq=jnAfmbzLckOeoshyWCwgDvEJlBYVIT
    for jnAfmbzLckOeoshyWCwgDvEJlBYVPN in jnAfmbzLckOeoshyWCwgDvEJlBYVNG['bottom_taglist']:
     if jnAfmbzLckOeoshyWCwgDvEJlBYVPN=='won':
      jnAfmbzLckOeoshyWCwgDvEJlBYVNq=jnAfmbzLckOeoshyWCwgDvEJlBYVIS
      break
    if jnAfmbzLckOeoshyWCwgDvEJlBYVNq==jnAfmbzLckOeoshyWCwgDvEJlBYVIS: 
     jnAfmbzLckOeoshyWCwgDvEJlBYVNQ['title']=jnAfmbzLckOeoshyWCwgDvEJlBYVNQ['title']+' [개별구매]'
    if jnAfmbzLckOeoshyWCwgDvEJlBYVNG.get('age')!='21':
     jnAfmbzLckOeoshyWCwgDvEJlBYVNF.append(jnAfmbzLckOeoshyWCwgDvEJlBYVNQ)
   jnAfmbzLckOeoshyWCwgDvEJlBYVNa=jnAfmbzLckOeoshyWCwgDvEJlBYVIG(jnAfmbzLckOeoshyWCwgDvEJlBYVNM['band']['pagecount'])
   if jnAfmbzLckOeoshyWCwgDvEJlBYVNM['band']['count']:jnAfmbzLckOeoshyWCwgDvEJlBYVPt =jnAfmbzLckOeoshyWCwgDvEJlBYVIG(jnAfmbzLckOeoshyWCwgDvEJlBYVNM['band']['count'])
   else:jnAfmbzLckOeoshyWCwgDvEJlBYVPt=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.LIST_LIMIT
   jnAfmbzLckOeoshyWCwgDvEJlBYVNi=jnAfmbzLckOeoshyWCwgDvEJlBYVNa>jnAfmbzLckOeoshyWCwgDvEJlBYVPt
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception)
  return jnAfmbzLckOeoshyWCwgDvEJlBYVNF,jnAfmbzLckOeoshyWCwgDvEJlBYVNi 
 def Get_Search_Tving(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,search_key,sType,page_int):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNF=[]
  jnAfmbzLckOeoshyWCwgDvEJlBYVNi=jnAfmbzLckOeoshyWCwgDvEJlBYVIT
  try:
   if sType=='TVSHOW':
    jnAfmbzLckOeoshyWCwgDvEJlBYVNd ='https://gw.tving.com/bff/search/v2/more/content/series/search'
    jnAfmbzLckOeoshyWCwgDvEJlBYVPX='AI_SCH_SERIES'
   else:
    jnAfmbzLckOeoshyWCwgDvEJlBYVNd ='https://gw.tving.com/bff/search/v2/more/content/movie/search'
    jnAfmbzLckOeoshyWCwgDvEJlBYVPX='AI_SCH_MOVIE'
   jnAfmbzLckOeoshyWCwgDvEJlBYVNS={'keyword':search_key,'pageNo':jnAfmbzLckOeoshyWCwgDvEJlBYVIp(page_int),'pageSize':'20','bandComposeMethod':'MANUAL','bandCode':jnAfmbzLckOeoshyWCwgDvEJlBYVPX,'osCode':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.TVING_PARMAS['OSCODE'],'screenCode':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.TVING_PARMAS['SCREENCODE'],}
   jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.Call_Request(jnAfmbzLckOeoshyWCwgDvEJlBYVNd,payload=jnAfmbzLckOeoshyWCwgDvEJlBYVId,params=jnAfmbzLckOeoshyWCwgDvEJlBYVNS,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVId,cookies=jnAfmbzLckOeoshyWCwgDvEJlBYVId,method='GET')
   jnAfmbzLckOeoshyWCwgDvEJlBYVNM=json.loads(jnAfmbzLckOeoshyWCwgDvEJlBYVNI.text).get('data').get('bands')[0]
   for jnAfmbzLckOeoshyWCwgDvEJlBYVNG in jnAfmbzLckOeoshyWCwgDvEJlBYVNM['items']:
    if sType=='TVSHOW':
     jnAfmbzLckOeoshyWCwgDvEJlBYVNQ={'program':jnAfmbzLckOeoshyWCwgDvEJlBYVNG['code'],'title':jnAfmbzLckOeoshyWCwgDvEJlBYVNG['title'],'thumbnail':{'poster':jnAfmbzLckOeoshyWCwgDvEJlBYVNG['imageUrl']}}
    else:
     jnAfmbzLckOeoshyWCwgDvEJlBYVNQ={'movie':jnAfmbzLckOeoshyWCwgDvEJlBYVNG['code'],'title':jnAfmbzLckOeoshyWCwgDvEJlBYVNG['title'],'thumbnail':{'poster':jnAfmbzLckOeoshyWCwgDvEJlBYVNG['imageUrl']}}
    jnAfmbzLckOeoshyWCwgDvEJlBYVNF.append(jnAfmbzLckOeoshyWCwgDvEJlBYVNQ)
   if 'nextApiUrl' in jnAfmbzLckOeoshyWCwgDvEJlBYVNM:jnAfmbzLckOeoshyWCwgDvEJlBYVNi=jnAfmbzLckOeoshyWCwgDvEJlBYVIS
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception)
  return jnAfmbzLckOeoshyWCwgDvEJlBYVNF,jnAfmbzLckOeoshyWCwgDvEJlBYVNi
 def Get_Search_Watcha(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,search_key,page_int):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNF=[]
  jnAfmbzLckOeoshyWCwgDvEJlBYVNi=jnAfmbzLckOeoshyWCwgDvEJlBYVIT
  try:
   jnAfmbzLckOeoshyWCwgDvEJlBYVNd=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_WATCHA+'/api/search.json'
   jnAfmbzLckOeoshyWCwgDvEJlBYVPI={'query':search_key,'page':jnAfmbzLckOeoshyWCwgDvEJlBYVIp(page_int),'per':jnAfmbzLckOeoshyWCwgDvEJlBYVIp(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.WATCHA_LIMIT),'exclude':'limited',}
   jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.Call_Request(jnAfmbzLckOeoshyWCwgDvEJlBYVNd,payload=jnAfmbzLckOeoshyWCwgDvEJlBYVId,params=jnAfmbzLckOeoshyWCwgDvEJlBYVPI,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.WATCHA_HEADER,cookies=jnAfmbzLckOeoshyWCwgDvEJlBYVId,method='GET')
   jnAfmbzLckOeoshyWCwgDvEJlBYVPx=json.loads(jnAfmbzLckOeoshyWCwgDvEJlBYVNI.text)
   if not('results' in jnAfmbzLckOeoshyWCwgDvEJlBYVPx):return jnAfmbzLckOeoshyWCwgDvEJlBYVNF,jnAfmbzLckOeoshyWCwgDvEJlBYVNi
   jnAfmbzLckOeoshyWCwgDvEJlBYVPF=jnAfmbzLckOeoshyWCwgDvEJlBYVPx['results']
   jnAfmbzLckOeoshyWCwgDvEJlBYVNi=jnAfmbzLckOeoshyWCwgDvEJlBYVPx['meta']['has_next']
   for jnAfmbzLckOeoshyWCwgDvEJlBYVNG in jnAfmbzLckOeoshyWCwgDvEJlBYVPF:
    jnAfmbzLckOeoshyWCwgDvEJlBYVPa =jnAfmbzLckOeoshyWCwgDvEJlBYVNG['code']
    jnAfmbzLckOeoshyWCwgDvEJlBYVPi=jnAfmbzLckOeoshyWCwgDvEJlBYVNG['content_type']
    jnAfmbzLckOeoshyWCwgDvEJlBYVPd =jnAfmbzLckOeoshyWCwgDvEJlBYVNG['title']
    jnAfmbzLckOeoshyWCwgDvEJlBYVPS =jnAfmbzLckOeoshyWCwgDvEJlBYVNG['story']
    jnAfmbzLckOeoshyWCwgDvEJlBYVPM=jnAfmbzLckOeoshyWCwgDvEJlBYVXr=jnAfmbzLckOeoshyWCwgDvEJlBYVXH=''
    if jnAfmbzLckOeoshyWCwgDvEJlBYVNG.get('poster') !=jnAfmbzLckOeoshyWCwgDvEJlBYVId:jnAfmbzLckOeoshyWCwgDvEJlBYVPM=jnAfmbzLckOeoshyWCwgDvEJlBYVNG.get('poster').get('original')
    if jnAfmbzLckOeoshyWCwgDvEJlBYVNG.get('stillcut')!=jnAfmbzLckOeoshyWCwgDvEJlBYVId:jnAfmbzLckOeoshyWCwgDvEJlBYVXr =jnAfmbzLckOeoshyWCwgDvEJlBYVNG.get('stillcut').get('large')
    if jnAfmbzLckOeoshyWCwgDvEJlBYVNG.get('thumbnail')!=jnAfmbzLckOeoshyWCwgDvEJlBYVId:jnAfmbzLckOeoshyWCwgDvEJlBYVXH=jnAfmbzLckOeoshyWCwgDvEJlBYVNG.get('thumbnail').get('large')
    if jnAfmbzLckOeoshyWCwgDvEJlBYVXH=='' :jnAfmbzLckOeoshyWCwgDvEJlBYVXH=jnAfmbzLckOeoshyWCwgDvEJlBYVXr
    jnAfmbzLckOeoshyWCwgDvEJlBYVPp={'thumb':jnAfmbzLckOeoshyWCwgDvEJlBYVXr,'poster':jnAfmbzLckOeoshyWCwgDvEJlBYVPM,'fanart':jnAfmbzLckOeoshyWCwgDvEJlBYVXH}
    jnAfmbzLckOeoshyWCwgDvEJlBYVPG =jnAfmbzLckOeoshyWCwgDvEJlBYVNG['year']
    jnAfmbzLckOeoshyWCwgDvEJlBYVPT =jnAfmbzLckOeoshyWCwgDvEJlBYVNG['film_rating_code']
    jnAfmbzLckOeoshyWCwgDvEJlBYVPU=jnAfmbzLckOeoshyWCwgDvEJlBYVNG['film_rating_short']
    jnAfmbzLckOeoshyWCwgDvEJlBYVPR =jnAfmbzLckOeoshyWCwgDvEJlBYVNG['film_rating_long']
    if jnAfmbzLckOeoshyWCwgDvEJlBYVPi=='movies':
     jnAfmbzLckOeoshyWCwgDvEJlBYVPH =jnAfmbzLckOeoshyWCwgDvEJlBYVNG['duration']
    else:
     jnAfmbzLckOeoshyWCwgDvEJlBYVPH ='0'
    jnAfmbzLckOeoshyWCwgDvEJlBYVNQ={'title':jnAfmbzLckOeoshyWCwgDvEJlBYVPd,}
    jnAfmbzLckOeoshyWCwgDvEJlBYVNF.append(jnAfmbzLckOeoshyWCwgDvEJlBYVNQ)
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception)
  return jnAfmbzLckOeoshyWCwgDvEJlBYVNF,jnAfmbzLckOeoshyWCwgDvEJlBYVNi
 def Get_Search_Coupang(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,search_key,page_int):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNF=[]
  jnAfmbzLckOeoshyWCwgDvEJlBYVNi=jnAfmbzLckOeoshyWCwgDvEJlBYVIT
  try:
   CP=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.jsonfile_To_dic(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.CP_ORIGINAL_COOKIE)
   jnAfmbzLckOeoshyWCwgDvEJlBYVNd=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_COUPANG+'/api-discover/v3/search'
   jnAfmbzLckOeoshyWCwgDvEJlBYVNS={'query':search_key,'platform':'WEBCLIENT','page':jnAfmbzLckOeoshyWCwgDvEJlBYVIp(page_int),'perPage':'48','filterSearchGroupTypes':'','filterSearchGroupType':'TITLES-EVENT_LIVE-EVENT_CHANNELS','includeChannelContents':'true','includeSportsChannelContents':'true',}
   jnAfmbzLckOeoshyWCwgDvEJlBYVPr={'x-membersrl':CP['COOKIES']['member_srl'],'x-pcid':CP['COOKIES']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.Call_Request(jnAfmbzLckOeoshyWCwgDvEJlBYVNd,payload=jnAfmbzLckOeoshyWCwgDvEJlBYVId,params=jnAfmbzLckOeoshyWCwgDvEJlBYVNS,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVPr,cookies=jnAfmbzLckOeoshyWCwgDvEJlBYVId,method='GET')
   jnAfmbzLckOeoshyWCwgDvEJlBYVNM=json.loads(jnAfmbzLckOeoshyWCwgDvEJlBYVNI.text)
   if jnAfmbzLckOeoshyWCwgDvEJlBYVIH(jnAfmbzLckOeoshyWCwgDvEJlBYVNM.get('data').get('contents'))==0:return jnAfmbzLckOeoshyWCwgDvEJlBYVNF,jnAfmbzLckOeoshyWCwgDvEJlBYVNi
   for jnAfmbzLckOeoshyWCwgDvEJlBYVNG in jnAfmbzLckOeoshyWCwgDvEJlBYVNM.get('data').get('contents'):
    jnAfmbzLckOeoshyWCwgDvEJlBYVNQ={'title':jnAfmbzLckOeoshyWCwgDvEJlBYVNG.get('title'),}
    jnAfmbzLckOeoshyWCwgDvEJlBYVNF.append(jnAfmbzLckOeoshyWCwgDvEJlBYVNQ)
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception)
  return jnAfmbzLckOeoshyWCwgDvEJlBYVNF,jnAfmbzLckOeoshyWCwgDvEJlBYVNi
 def Selenium_Cookies_Load(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,in_filename):
  fp=jnAfmbzLckOeoshyWCwgDvEJlBYVIr(in_filename,'rb',-1)
  try:
   jnAfmbzLckOeoshyWCwgDvEJlBYVPu=pickle.loads(fp.read())
   if jnAfmbzLckOeoshyWCwgDvEJlBYVIu(jnAfmbzLckOeoshyWCwgDvEJlBYVPu)==jnAfmbzLckOeoshyWCwgDvEJlBYVIK:
    for jnAfmbzLckOeoshyWCwgDvEJlBYVPK in jnAfmbzLckOeoshyWCwgDvEJlBYVPu:
     jnAfmbzLckOeoshyWCwgDvEJlBYVNt.HTTP_CLIENT.cookies.set_cookie(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.To_Cookielib(jnAfmbzLckOeoshyWCwgDvEJlBYVPK)) 
   else:
    jnAfmbzLckOeoshyWCwgDvEJlBYVNt.HTTP_CLIENT.cookies.update(jnAfmbzLckOeoshyWCwgDvEJlBYVPu) 
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception)
  finally:
   fp.close()
 def To_Cookielib(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,selenium_cookie):
  return http.cookiejar.Cookie(version=0,name=selenium_cookie['name'],value=selenium_cookie['value'],port=jnAfmbzLckOeoshyWCwgDvEJlBYVId,port_specified=jnAfmbzLckOeoshyWCwgDvEJlBYVIT,domain=selenium_cookie['domain'],domain_specified=jnAfmbzLckOeoshyWCwgDvEJlBYVIS,domain_initial_dot=jnAfmbzLckOeoshyWCwgDvEJlBYVIT,path=selenium_cookie['path'],path_specified=jnAfmbzLckOeoshyWCwgDvEJlBYVIS,secure=selenium_cookie['secure'],expires=selenium_cookie['expiry'],discard=jnAfmbzLckOeoshyWCwgDvEJlBYVIT,comment=jnAfmbzLckOeoshyWCwgDvEJlBYVId,comment_url=jnAfmbzLckOeoshyWCwgDvEJlBYVId,rest={'HttpOnly':selenium_cookie['httpOnly']},rfc2109=jnAfmbzLckOeoshyWCwgDvEJlBYVIT,)
 def Get_Search_Primev(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,search_key):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNF=[]
  try:
   jnAfmbzLckOeoshyWCwgDvEJlBYVNt.PV=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.jsonfile_To_dic(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.PV_ORIGINAL_COOKIE)
   jnAfmbzLckOeoshyWCwgDvEJlBYVPq=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.PV['COOKIES']
   jnAfmbzLckOeoshyWCwgDvEJlBYVPr={'accept':'application/json','x-requested-with':'WebSPA',}
   jnAfmbzLckOeoshyWCwgDvEJlBYVtN ='dvWebSPAClientVersion=1.0.110699.0'
   jnAfmbzLckOeoshyWCwgDvEJlBYVNd='https://www.primevideo.com/region/fe/search/ref=atv_nb_sug?ie=UTF8&phrase={}&{}'.format(urllib.parse.quote_plus(search_key),jnAfmbzLckOeoshyWCwgDvEJlBYVtN)
   jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.Call_Request(jnAfmbzLckOeoshyWCwgDvEJlBYVNd,params=jnAfmbzLckOeoshyWCwgDvEJlBYVId,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVPr,cookies=jnAfmbzLckOeoshyWCwgDvEJlBYVPq,method='GET')
   if jnAfmbzLckOeoshyWCwgDvEJlBYVNI.status_code!=200:return[]
   jnAfmbzLckOeoshyWCwgDvEJlBYVtP=json.loads(jnAfmbzLckOeoshyWCwgDvEJlBYVNI.text)
   jnAfmbzLckOeoshyWCwgDvEJlBYVtP=jnAfmbzLckOeoshyWCwgDvEJlBYVtP['page'][0]['assembly']['body'][0]['props']['search']['containers'][0]
   jnAfmbzLckOeoshyWCwgDvEJlBYVtX=jnAfmbzLckOeoshyWCwgDvEJlBYVtP.get('entities')
   for jnAfmbzLckOeoshyWCwgDvEJlBYVtI in jnAfmbzLckOeoshyWCwgDvEJlBYVtX:
    if 'titleID' not in jnAfmbzLckOeoshyWCwgDvEJlBYVtI:return[]
    jnAfmbzLckOeoshyWCwgDvEJlBYVNQ={'title':jnAfmbzLckOeoshyWCwgDvEJlBYVtI.get('title'),}
    jnAfmbzLckOeoshyWCwgDvEJlBYVNF.append(jnAfmbzLckOeoshyWCwgDvEJlBYVNQ)
   '''
   TAG_RESULT = '{"props":{"containers"'
   JSON_REGEX = r'<script type="text/template">\s*(.*?)\s*</script>'
   text_array = re.compile(JSON_REGEX, re.DOTALL).findall(response.text )
   json_str = '{}'
   for cur_str in text_array:
    if TAG_RESULT in cur_str :
     json_str = cur_str
     break
   res_json = json.loads(json_str )
   self.dic_To_jsonfile(self.NF_CONTEXTJSON_FILE1, res_json ) #####
   # 검색 리스트 처리
   PORPS = res_json.get('props')
   for i_containers in PORPS.get('containers'):
    if i_containers.get('containerType') == 'Grid':
     ITEMS = i_containers.get('entities' )
     #OPTS  = i_containers                 
     break
   for i_item in ITEMS:
    if 'titleID' not in i_item: return [] # 검색시 리턴값 없을 때
    temp_list = {'title' : i_item.get('title'), }
    search_list.append(temp_list )
   '''   
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception)
  return jnAfmbzLckOeoshyWCwgDvEJlBYVNF
 def Get_Search_Disney(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,search_key):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNF=[]
  jnAfmbzLckOeoshyWCwgDvEJlBYVNd ='{}/{}/search'.format(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_DISNEY,jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_DISNEY_VERSION)
  jnAfmbzLckOeoshyWCwgDvEJlBYVPr=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.make_DZ_Headers(accessToken=jnAfmbzLckOeoshyWCwgDvEJlBYVIS,Bearer=jnAfmbzLckOeoshyWCwgDvEJlBYVIS)
  jnAfmbzLckOeoshyWCwgDvEJlBYVNS ={'query':search_key,}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.Call_Request(jnAfmbzLckOeoshyWCwgDvEJlBYVNd,params=jnAfmbzLckOeoshyWCwgDvEJlBYVNS,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVPr,cookies=jnAfmbzLckOeoshyWCwgDvEJlBYVId,method='GET')
  if jnAfmbzLckOeoshyWCwgDvEJlBYVNI.status_code not in[200,201]:return[]
  jnAfmbzLckOeoshyWCwgDvEJlBYVtx=jnAfmbzLckOeoshyWCwgDvEJlBYVNI.json().get('data').get('page').get('containers')
  for jnAfmbzLckOeoshyWCwgDvEJlBYVtI in jnAfmbzLckOeoshyWCwgDvEJlBYVtx[0]['items']:
   jnAfmbzLckOeoshyWCwgDvEJlBYVNQ={'title':jnAfmbzLckOeoshyWCwgDvEJlBYVtI['visuals']['title'],}
   jnAfmbzLckOeoshyWCwgDvEJlBYVNF.append(jnAfmbzLckOeoshyWCwgDvEJlBYVNQ)
  return jnAfmbzLckOeoshyWCwgDvEJlBYVNF
 def Get_Search_Disney_back(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,search_key):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNF=[]
  jnAfmbzLckOeoshyWCwgDvEJlBYVNd=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['services']['content']['getSearchResults']['href']
  jnAfmbzLckOeoshyWCwgDvEJlBYVtF={'apiVersion':'5.1','region':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['headers']['regionCode'],'kidsModeEnabled':'false','impliedMaturityRating':'1870','appLanguage':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['headers']['lang'][0:2],'partner':'disney','queryType':'ge','pageSize':jnAfmbzLckOeoshyWCwgDvEJlBYVIp(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DISNEY_LIMIT),'query':search_key,}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNd=jnAfmbzLckOeoshyWCwgDvEJlBYVNd.format(**jnAfmbzLckOeoshyWCwgDvEJlBYVtF)
  jnAfmbzLckOeoshyWCwgDvEJlBYVPr=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.make_DZ_Headers(accessToken=jnAfmbzLckOeoshyWCwgDvEJlBYVIS,Bearer=jnAfmbzLckOeoshyWCwgDvEJlBYVIS)
  jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.Call_Request(jnAfmbzLckOeoshyWCwgDvEJlBYVNd,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVPr,cookies=jnAfmbzLckOeoshyWCwgDvEJlBYVId,method='GET')
  if jnAfmbzLckOeoshyWCwgDvEJlBYVNI.status_code not in[200,201]:return[]
  jnAfmbzLckOeoshyWCwgDvEJlBYVtx=jnAfmbzLckOeoshyWCwgDvEJlBYVNI.json().get('data').get('search')
  for jnAfmbzLckOeoshyWCwgDvEJlBYVtI in jnAfmbzLckOeoshyWCwgDvEJlBYVtx.get('hits'):
   jnAfmbzLckOeoshyWCwgDvEJlBYVtI=jnAfmbzLckOeoshyWCwgDvEJlBYVtI.get('hit')
   if jnAfmbzLckOeoshyWCwgDvEJlBYVtI.get('type')=='DmcSeries': 
    jnAfmbzLckOeoshyWCwgDvEJlBYVPd =jnAfmbzLckOeoshyWCwgDvEJlBYVtI.get('text').get('title').get('full').get('series').get('default').get('content')
   elif jnAfmbzLckOeoshyWCwgDvEJlBYVtI.get('type')=='DmcVideo':
    jnAfmbzLckOeoshyWCwgDvEJlBYVPd =jnAfmbzLckOeoshyWCwgDvEJlBYVtI.get('text').get('title').get('full').get('program').get('default').get('content')
   elif jnAfmbzLckOeoshyWCwgDvEJlBYVtI.get('type')=='StandardCollection':
    jnAfmbzLckOeoshyWCwgDvEJlBYVPd =jnAfmbzLckOeoshyWCwgDvEJlBYVtI.get('text').get('title').get('full').get('collection').get('default').get('content')
   else:
    return jnAfmbzLckOeoshyWCwgDvEJlBYVNF
   jnAfmbzLckOeoshyWCwgDvEJlBYVNQ={'title':jnAfmbzLckOeoshyWCwgDvEJlBYVPd,}
   jnAfmbzLckOeoshyWCwgDvEJlBYVNF.append(jnAfmbzLckOeoshyWCwgDvEJlBYVNQ)
  return jnAfmbzLckOeoshyWCwgDvEJlBYVNF
 def dic_To_jsonfile(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,filename,jnAfmbzLckOeoshyWCwgDvEJlBYVta):
  if filename=='':return
  fp=jnAfmbzLckOeoshyWCwgDvEJlBYVIr(filename,'w',-1,'utf-8')
  json.dump(jnAfmbzLckOeoshyWCwgDvEJlBYVta,fp,indent=4,ensure_ascii=jnAfmbzLckOeoshyWCwgDvEJlBYVIT)
  fp.close()
 def jsonfile_To_dic(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,filename):
  if filename=='':return jnAfmbzLckOeoshyWCwgDvEJlBYVId
  try:
   fp=jnAfmbzLckOeoshyWCwgDvEJlBYVIr(filename,'r',-1,'utf-8')
   jnAfmbzLckOeoshyWCwgDvEJlBYVtd=json.load(fp)
   fp.close()
  except:
   jnAfmbzLckOeoshyWCwgDvEJlBYVtd={}
  return jnAfmbzLckOeoshyWCwgDvEJlBYVtd
 def tempFileSave(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,filename,resText):
  if filename=='':return
  fp=jnAfmbzLckOeoshyWCwgDvEJlBYVIr(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,filename):
  if filename=='':return
  try:
   fp=jnAfmbzLckOeoshyWCwgDvEJlBYVIr(filename,'r',-1,'utf-8')
   jnAfmbzLckOeoshyWCwgDvEJlBYVtd=fp.read()
   fp.close()
  except:
   jnAfmbzLckOeoshyWCwgDvEJlBYVtd=''
  return jnAfmbzLckOeoshyWCwgDvEJlBYVtd
 def make_DZ_Headers(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,accessToken=jnAfmbzLckOeoshyWCwgDvEJlBYVIS,Bearer=jnAfmbzLckOeoshyWCwgDvEJlBYVIT):
  if accessToken:
   jnAfmbzLckOeoshyWCwgDvEJlBYVtS=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['account']['accessToken']
  else:
   jnAfmbzLckOeoshyWCwgDvEJlBYVtS=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['headers']['clientApiKey']
  if Bearer:
   jnAfmbzLckOeoshyWCwgDvEJlBYVtS='Bearer {}'.format(jnAfmbzLckOeoshyWCwgDvEJlBYVtS)
  jnAfmbzLckOeoshyWCwgDvEJlBYVPr={'authorization':jnAfmbzLckOeoshyWCwgDvEJlBYVtS,'x-application-version':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['headers']['sdkAppVersion'],'x-bamsdk-client-id':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['headers']['clientId'],'x-bamsdk-platform':'javascript/windows/chrome','x-bamsdk-version':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['headers']['sdkVersion'],'x-dss-edge-accept':'vnd.dss.edge+json; version=2',}
  return jnAfmbzLckOeoshyWCwgDvEJlBYVPr
 def DZ_ReToken(jnAfmbzLckOeoshyWCwgDvEJlBYVNt):
  try:
   jnAfmbzLckOeoshyWCwgDvEJlBYVNd =jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['services']['orchestration']['refreshToken']['href']
   jnAfmbzLckOeoshyWCwgDvEJlBYVPr=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.make_DZ_Headers(accessToken=jnAfmbzLckOeoshyWCwgDvEJlBYVIT,Bearer=jnAfmbzLckOeoshyWCwgDvEJlBYVIT)
   jnAfmbzLckOeoshyWCwgDvEJlBYVtM={'query':'mutation refreshToken($input: RefreshTokenInput!) {\n            refreshToken(refreshToken: $input) {\n                activeSession {\n                    sessionId\n                }\n            }\n        }','variables':{'input':{'refreshToken':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['account']['refreshToken'],}}}
   jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.Call_Request(jnAfmbzLckOeoshyWCwgDvEJlBYVNd,json=jnAfmbzLckOeoshyWCwgDvEJlBYVtM,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVPr,cookies=jnAfmbzLckOeoshyWCwgDvEJlBYVId,method='POST')
   if jnAfmbzLckOeoshyWCwgDvEJlBYVNI.status_code not in[200,201]:return jnAfmbzLckOeoshyWCwgDvEJlBYVIT
   jnAfmbzLckOeoshyWCwgDvEJlBYVtx=jnAfmbzLckOeoshyWCwgDvEJlBYVNI.json()
   jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['account']['accessToken'] =jnAfmbzLckOeoshyWCwgDvEJlBYVtx.get('extensions').get('sdk').get('token').get('accessToken')
   jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['account']['accessTokenType']=jnAfmbzLckOeoshyWCwgDvEJlBYVtx.get('extensions').get('sdk').get('token').get('accessTokenType')
   jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['account']['refreshToken'] =jnAfmbzLckOeoshyWCwgDvEJlBYVtx.get('extensions').get('sdk').get('token').get('refreshToken')
   jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['account']['token_limit'] =jnAfmbzLckOeoshyWCwgDvEJlBYVIG(time.time())+14400 
   jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['account']['deviceId'] =jnAfmbzLckOeoshyWCwgDvEJlBYVtx.get('extensions').get('sdk').get('session').get('device').get('id')
   jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DZ['account']['sessionId'] =jnAfmbzLckOeoshyWCwgDvEJlBYVtx.get('extensions').get('sdk').get('session').get('sessionId')
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception)
   return jnAfmbzLckOeoshyWCwgDvEJlBYVIT
  return jnAfmbzLckOeoshyWCwgDvEJlBYVIS
 def Init_NF_Total(jnAfmbzLckOeoshyWCwgDvEJlBYVNt):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF={}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['COOKIES']={}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']={}
 def make_NF_XnetflixHeaders(jnAfmbzLckOeoshyWCwgDvEJlBYVNt):
  jnAfmbzLckOeoshyWCwgDvEJlBYVPr={'x-netflix.browsername':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':jnAfmbzLckOeoshyWCwgDvEJlBYVIp(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['esnModel'],'x-netflix.esnprefix':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['nowGuid'],'x-netflix.uiversion':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return jnAfmbzLckOeoshyWCwgDvEJlBYVPr
 def make_NF_ApiParams(jnAfmbzLckOeoshyWCwgDvEJlBYVNt):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNS={'avif':'false','webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','isTop10KidsSupported':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/mre/pathEvaluator',}
  return jnAfmbzLckOeoshyWCwgDvEJlBYVNS
 def extract_json(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,content,name):
  jnAfmbzLckOeoshyWCwgDvEJlBYVtp=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  jnAfmbzLckOeoshyWCwgDvEJlBYVtG=jnAfmbzLckOeoshyWCwgDvEJlBYVId
  jnAfmbzLckOeoshyWCwgDvEJlBYVtT=re.compile(jnAfmbzLckOeoshyWCwgDvEJlBYVtp.format(name),re.DOTALL).findall(content)
  jnAfmbzLckOeoshyWCwgDvEJlBYVtG=jnAfmbzLckOeoshyWCwgDvEJlBYVtT[0]
  jnAfmbzLckOeoshyWCwgDvEJlBYVtU=jnAfmbzLckOeoshyWCwgDvEJlBYVtG.replace('\\"','\\\\"') 
  jnAfmbzLckOeoshyWCwgDvEJlBYVtU=jnAfmbzLckOeoshyWCwgDvEJlBYVtU.replace('\\s','\\\\s') 
  jnAfmbzLckOeoshyWCwgDvEJlBYVtU=jnAfmbzLckOeoshyWCwgDvEJlBYVtU.replace('\\n','\\\\n') 
  jnAfmbzLckOeoshyWCwgDvEJlBYVtU=jnAfmbzLckOeoshyWCwgDvEJlBYVtU.replace('\\t','\\\\t') 
  jnAfmbzLckOeoshyWCwgDvEJlBYVtU=jnAfmbzLckOeoshyWCwgDvEJlBYVtU.encode().decode('unicode_escape') 
  jnAfmbzLckOeoshyWCwgDvEJlBYVtU=re.sub(r'\\(?!["])',r'\\\\',jnAfmbzLckOeoshyWCwgDvEJlBYVtU) 
  return json.loads(jnAfmbzLckOeoshyWCwgDvEJlBYVtU)
 def NF_makestr_paths(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,paths):
  jnAfmbzLckOeoshyWCwgDvEJlBYVtd=[]
  if jnAfmbzLckOeoshyWCwgDvEJlBYVIQ(paths,jnAfmbzLckOeoshyWCwgDvEJlBYVIG):
   return '%d'%(paths)
  elif jnAfmbzLckOeoshyWCwgDvEJlBYVIQ(paths,jnAfmbzLckOeoshyWCwgDvEJlBYVIp):
   return '"%s"'%(paths)
  for jnAfmbzLckOeoshyWCwgDvEJlBYVtR in paths:
   if jnAfmbzLckOeoshyWCwgDvEJlBYVIQ(jnAfmbzLckOeoshyWCwgDvEJlBYVtR,jnAfmbzLckOeoshyWCwgDvEJlBYVIG):
    jnAfmbzLckOeoshyWCwgDvEJlBYVtd.append('%d'%(jnAfmbzLckOeoshyWCwgDvEJlBYVtR))
   elif jnAfmbzLckOeoshyWCwgDvEJlBYVIQ(jnAfmbzLckOeoshyWCwgDvEJlBYVtR,jnAfmbzLckOeoshyWCwgDvEJlBYVIp):
    jnAfmbzLckOeoshyWCwgDvEJlBYVtd.append('"%s"'%(jnAfmbzLckOeoshyWCwgDvEJlBYVtR))
   elif jnAfmbzLckOeoshyWCwgDvEJlBYVIQ(jnAfmbzLckOeoshyWCwgDvEJlBYVtR,jnAfmbzLckOeoshyWCwgDvEJlBYVIK):
    jnAfmbzLckOeoshyWCwgDvEJlBYVtd.append('[%s]'%(','.join(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_makestr_paths(jnAfmbzLckOeoshyWCwgDvEJlBYVtR))))
   elif jnAfmbzLckOeoshyWCwgDvEJlBYVIQ(jnAfmbzLckOeoshyWCwgDvEJlBYVtR,jnAfmbzLckOeoshyWCwgDvEJlBYVIU):
    jnAfmbzLckOeoshyWCwgDvEJlBYVtH=''
    for jnAfmbzLckOeoshyWCwgDvEJlBYVtr,jnAfmbzLckOeoshyWCwgDvEJlBYVtu in jnAfmbzLckOeoshyWCwgDvEJlBYVtR.items():
     jnAfmbzLckOeoshyWCwgDvEJlBYVtH+='"%s":%s,'%(jnAfmbzLckOeoshyWCwgDvEJlBYVtr,jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_makestr_paths(jnAfmbzLckOeoshyWCwgDvEJlBYVtu))
    jnAfmbzLckOeoshyWCwgDvEJlBYVtd.append('{%s}'%(jnAfmbzLckOeoshyWCwgDvEJlBYVtH[:-1]))
  return jnAfmbzLckOeoshyWCwgDvEJlBYVtd
 def NF_Call_pathapi(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,jnAfmbzLckOeoshyWCwgDvEJlBYVXa,referer=''):
  jnAfmbzLckOeoshyWCwgDvEJlBYVtK='%s/nq/website/memberapi/%s/pathEvaluator'%(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_NETFLIX,jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['identifier'])
  jnAfmbzLckOeoshyWCwgDvEJlBYVtM={'path':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_makestr_paths(jnAfmbzLckOeoshyWCwgDvEJlBYVXa),'authURL':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']['authURL']}
  jnAfmbzLckOeoshyWCwgDvEJlBYVNS=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.make_NF_ApiParams()
  jnAfmbzLckOeoshyWCwgDvEJlBYVPr={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_NETFLIX,'sec-ch-ua':'"Google Chrome";v="101", "Not)A;Brand";v="8", "Chromium";v="101"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':jnAfmbzLckOeoshyWCwgDvEJlBYVPr['referer']=referer
  jnAfmbzLckOeoshyWCwgDvEJlBYVtQ=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.make_NF_XnetflixHeaders()
  jnAfmbzLckOeoshyWCwgDvEJlBYVPr.update(jnAfmbzLckOeoshyWCwgDvEJlBYVtQ)
  jnAfmbzLckOeoshyWCwgDvEJlBYVPq=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_Get_DefaultCookies()
  jnAfmbzLckOeoshyWCwgDvEJlBYVPq['profilesNewSession']='0'
  try:
   jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.Call_Request(jnAfmbzLckOeoshyWCwgDvEJlBYVtK,payload=jnAfmbzLckOeoshyWCwgDvEJlBYVtM,params=jnAfmbzLckOeoshyWCwgDvEJlBYVNS,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVPr,cookies=jnAfmbzLckOeoshyWCwgDvEJlBYVPq,method='POST')
   return jnAfmbzLckOeoshyWCwgDvEJlBYVNI
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception)
   return jnAfmbzLckOeoshyWCwgDvEJlBYVId
 def Get_Search_Netflix(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,search_key,page_int,byReference=''):
  jnAfmbzLckOeoshyWCwgDvEJlBYVtq=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.DERECTOR_LIMIT
  jnAfmbzLckOeoshyWCwgDvEJlBYVXN =jnAfmbzLckOeoshyWCwgDvEJlBYVNt.CAST_LIMIT
  jnAfmbzLckOeoshyWCwgDvEJlBYVXP =jnAfmbzLckOeoshyWCwgDvEJlBYVNt.GENRE_LIMIT
  jnAfmbzLckOeoshyWCwgDvEJlBYVXt =jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_LIMIT*(page_int-1)
  jnAfmbzLckOeoshyWCwgDvEJlBYVXI =jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_LIMIT*page_int 
  jnAfmbzLckOeoshyWCwgDvEJlBYVXx="|%s"%(search_key)
  jnAfmbzLckOeoshyWCwgDvEJlBYVXF ='%s/search?%s'%(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   jnAfmbzLckOeoshyWCwgDvEJlBYVXa=[["search","byTerm",jnAfmbzLckOeoshyWCwgDvEJlBYVXx,"titles",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_LIMIT,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"summary"],["search","byTerm",jnAfmbzLckOeoshyWCwgDvEJlBYVXx,"titles",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_LIMIT,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",jnAfmbzLckOeoshyWCwgDvEJlBYVXx,"titles",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_LIMIT,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference","boxarts",[jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND2,jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_PORT],"jpg"],["search","byTerm",jnAfmbzLckOeoshyWCwgDvEJlBYVXx,"titles",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_LIMIT,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference","interestingMoment",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND1,"jpg"],["search","byTerm",jnAfmbzLckOeoshyWCwgDvEJlBYVXx,"titles",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_LIMIT,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference","storyArt",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND2,"jpg"],["search","byTerm",jnAfmbzLckOeoshyWCwgDvEJlBYVXx,"titles",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_LIMIT,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference",["cast","creators","directors"],{"from":0,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVtq},["id","name"]],["search","byTerm",jnAfmbzLckOeoshyWCwgDvEJlBYVXx,"titles",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_LIMIT,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference","genres",{"from":0,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXP},["id","name"]],["search","byTerm",jnAfmbzLckOeoshyWCwgDvEJlBYVXx,"titles",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NETFLIX_LIMIT,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LOGO,"png"],]
  else:
   jnAfmbzLckOeoshyWCwgDvEJlBYVXa=[["search","byReference",byReference,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"summary"],["search","byReference",byReference,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference","boxarts",[jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND2,jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference","interestingMoment",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference","storyArt",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference",["cast","creators","directors"],{"from":0,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVtq},["id","name"]],["search","byReference",byReference,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference","genres",{"from":0,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXP},["id","name"]],["search","byReference",byReference,{"from":jnAfmbzLckOeoshyWCwgDvEJlBYVXt,"to":jnAfmbzLckOeoshyWCwgDvEJlBYVXI},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LOGO,"png"],]
  try:
   jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_Call_pathapi(jnAfmbzLckOeoshyWCwgDvEJlBYVXa,jnAfmbzLckOeoshyWCwgDvEJlBYVXF)
   jnAfmbzLckOeoshyWCwgDvEJlBYVNM=json.loads(jnAfmbzLckOeoshyWCwgDvEJlBYVNI.text)
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception)
  (jnAfmbzLckOeoshyWCwgDvEJlBYVNF,jnAfmbzLckOeoshyWCwgDvEJlBYVNi,byReference)=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.Search_Netflix_Make(jnAfmbzLckOeoshyWCwgDvEJlBYVNM)
  return jnAfmbzLckOeoshyWCwgDvEJlBYVNF,jnAfmbzLckOeoshyWCwgDvEJlBYVNi,byReference
 def Search_Netflix_Make(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,jsonSource):
  jnAfmbzLckOeoshyWCwgDvEJlBYVNF=[]
  jnAfmbzLckOeoshyWCwgDvEJlBYVNi =jnAfmbzLckOeoshyWCwgDvEJlBYVIT
  jnAfmbzLckOeoshyWCwgDvEJlBYVXi=''
  jnAfmbzLckOeoshyWCwgDvEJlBYVXd=jsonSource.get('paths')[0][1]
  if jnAfmbzLckOeoshyWCwgDvEJlBYVXd=='byTerm':
   jnAfmbzLckOeoshyWCwgDvEJlBYVXt =jsonSource['paths'][0][5]['from']
   jnAfmbzLckOeoshyWCwgDvEJlBYVXI =jsonSource['paths'][0][5]['to']
  else:
   jnAfmbzLckOeoshyWCwgDvEJlBYVXt =jsonSource['paths'][0][3]['from']
   jnAfmbzLckOeoshyWCwgDvEJlBYVXI =jsonSource['paths'][0][3]['to']
  jnAfmbzLckOeoshyWCwgDvEJlBYVXi=jnAfmbzLckOeoshyWCwgDvEJlBYVIK(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  jnAfmbzLckOeoshyWCwgDvEJlBYVXS=jsonSource.get('jsonGraph').get('search').get('byReference').get(jnAfmbzLckOeoshyWCwgDvEJlBYVXi)
  jnAfmbzLckOeoshyWCwgDvEJlBYVXM =jsonSource.get('jsonGraph').get('videos')
  jnAfmbzLckOeoshyWCwgDvEJlBYVXp=jsonSource.get('jsonGraph').get('person')
  jnAfmbzLckOeoshyWCwgDvEJlBYVXG=jsonSource.get('jsonGraph').get('genres')
  jnAfmbzLckOeoshyWCwgDvEJlBYVNi=jnAfmbzLckOeoshyWCwgDvEJlBYVIS if jnAfmbzLckOeoshyWCwgDvEJlBYVXS[jnAfmbzLckOeoshyWCwgDvEJlBYVIp(jnAfmbzLckOeoshyWCwgDvEJlBYVXI)]['reference']['$type']=='ref' else jnAfmbzLckOeoshyWCwgDvEJlBYVIT
  for jnAfmbzLckOeoshyWCwgDvEJlBYVXT in jnAfmbzLckOeoshyWCwgDvEJlBYVIq(jnAfmbzLckOeoshyWCwgDvEJlBYVXt,jnAfmbzLckOeoshyWCwgDvEJlBYVXI):
   if jnAfmbzLckOeoshyWCwgDvEJlBYVXS[jnAfmbzLckOeoshyWCwgDvEJlBYVIp(jnAfmbzLckOeoshyWCwgDvEJlBYVXT)]['reference']['$type']=='ref':
    jnAfmbzLckOeoshyWCwgDvEJlBYVNr =jnAfmbzLckOeoshyWCwgDvEJlBYVXS[jnAfmbzLckOeoshyWCwgDvEJlBYVIp(jnAfmbzLckOeoshyWCwgDvEJlBYVXT)]['reference']['value'][1]
    jnAfmbzLckOeoshyWCwgDvEJlBYVXU=jnAfmbzLckOeoshyWCwgDvEJlBYVXM[jnAfmbzLckOeoshyWCwgDvEJlBYVNr]
    jnAfmbzLckOeoshyWCwgDvEJlBYVPd =jnAfmbzLckOeoshyWCwgDvEJlBYVXU['title']['value']
    if jnAfmbzLckOeoshyWCwgDvEJlBYVXU['availability']['value']['isPlayable']==jnAfmbzLckOeoshyWCwgDvEJlBYVIT:
     continue
    jnAfmbzLckOeoshyWCwgDvEJlBYVNR =jnAfmbzLckOeoshyWCwgDvEJlBYVXU['summary']['value']['type']
    jnAfmbzLckOeoshyWCwgDvEJlBYVPH =0 if jnAfmbzLckOeoshyWCwgDvEJlBYVNR!='movie' else jnAfmbzLckOeoshyWCwgDvEJlBYVXU['runtime']['value']
    if jnAfmbzLckOeoshyWCwgDvEJlBYVXU['sequiturEvidence']['value']['value']:
     jnAfmbzLckOeoshyWCwgDvEJlBYVXR=jnAfmbzLckOeoshyWCwgDvEJlBYVXU['sequiturEvidence']['value']['value']['text']
    else:
     jnAfmbzLckOeoshyWCwgDvEJlBYVXR=''
    jnAfmbzLckOeoshyWCwgDvEJlBYVPM =jnAfmbzLckOeoshyWCwgDvEJlBYVXU['boxarts'][jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_PORT]['jpg']['value']['url']
    jnAfmbzLckOeoshyWCwgDvEJlBYVXH =jnAfmbzLckOeoshyWCwgDvEJlBYVXU['boxarts'][jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND2]['jpg']['value']['url']
    jnAfmbzLckOeoshyWCwgDvEJlBYVXr=''
    if 'value' in jnAfmbzLckOeoshyWCwgDvEJlBYVXU['storyArt'][jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND2]['jpg']:
     jnAfmbzLckOeoshyWCwgDvEJlBYVXr =jnAfmbzLckOeoshyWCwgDvEJlBYVXU['storyArt'][jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND2]['jpg']['value']['url']
    if jnAfmbzLckOeoshyWCwgDvEJlBYVXr=='' and 'value' in jnAfmbzLckOeoshyWCwgDvEJlBYVXU['interestingMoment'][jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND1]['jpg']:
     jnAfmbzLckOeoshyWCwgDvEJlBYVXr =jnAfmbzLckOeoshyWCwgDvEJlBYVXU['interestingMoment'][jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LAND1]['jpg']['value']['url']
    jnAfmbzLckOeoshyWCwgDvEJlBYVXu=''
    if 'value' in jnAfmbzLckOeoshyWCwgDvEJlBYVXU['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LOGO]['png']:
     jnAfmbzLckOeoshyWCwgDvEJlBYVXu=jnAfmbzLckOeoshyWCwgDvEJlBYVXU['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][jnAfmbzLckOeoshyWCwgDvEJlBYVNt.ART_SIZE_LOGO]['png']['value']['url']
    jnAfmbzLckOeoshyWCwgDvEJlBYVXK =jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_Subid_List(jnAfmbzLckOeoshyWCwgDvEJlBYVXU['genres'])
    for i in jnAfmbzLckOeoshyWCwgDvEJlBYVIq(jnAfmbzLckOeoshyWCwgDvEJlBYVIH(jnAfmbzLckOeoshyWCwgDvEJlBYVXK)):
     jnAfmbzLckOeoshyWCwgDvEJlBYVXK[i]=jnAfmbzLckOeoshyWCwgDvEJlBYVXG[jnAfmbzLckOeoshyWCwgDvEJlBYVXK[i]]['name']['value']
    jnAfmbzLckOeoshyWCwgDvEJlBYVXQ=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_Subid_List(jnAfmbzLckOeoshyWCwgDvEJlBYVXU['directors'])
    jnAfmbzLckOeoshyWCwgDvEJlBYVXq =jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_Subid_List(jnAfmbzLckOeoshyWCwgDvEJlBYVXU['creators'])
    jnAfmbzLckOeoshyWCwgDvEJlBYVXQ.extend(jnAfmbzLckOeoshyWCwgDvEJlBYVXq)
    for i in jnAfmbzLckOeoshyWCwgDvEJlBYVIq(jnAfmbzLckOeoshyWCwgDvEJlBYVIH(jnAfmbzLckOeoshyWCwgDvEJlBYVXQ)):
     jnAfmbzLckOeoshyWCwgDvEJlBYVXQ[i]=jnAfmbzLckOeoshyWCwgDvEJlBYVXp[jnAfmbzLckOeoshyWCwgDvEJlBYVXQ[i]]['name']['value']
    jnAfmbzLckOeoshyWCwgDvEJlBYVIN=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_Subid_List(jnAfmbzLckOeoshyWCwgDvEJlBYVXU['cast'])
    for i in jnAfmbzLckOeoshyWCwgDvEJlBYVIq(jnAfmbzLckOeoshyWCwgDvEJlBYVIH(jnAfmbzLckOeoshyWCwgDvEJlBYVIN)):
     jnAfmbzLckOeoshyWCwgDvEJlBYVIN[i]=jnAfmbzLckOeoshyWCwgDvEJlBYVXp[jnAfmbzLckOeoshyWCwgDvEJlBYVIN[i]]['name']['value']
    if 'maturityDescription' in jnAfmbzLckOeoshyWCwgDvEJlBYVXU['maturity']['value']['rating']:
     jnAfmbzLckOeoshyWCwgDvEJlBYVIP=jnAfmbzLckOeoshyWCwgDvEJlBYVXU['maturity']['value']['rating']['maturityDescription']
    jnAfmbzLckOeoshyWCwgDvEJlBYVNQ={'videoid':jnAfmbzLckOeoshyWCwgDvEJlBYVNr,'vidtype':jnAfmbzLckOeoshyWCwgDvEJlBYVNR,'title':jnAfmbzLckOeoshyWCwgDvEJlBYVPd,'mpaa':jnAfmbzLckOeoshyWCwgDvEJlBYVIP,'regularSynopsis':jnAfmbzLckOeoshyWCwgDvEJlBYVXU['regularSynopsis']['value'],'dpSupplemental':jnAfmbzLckOeoshyWCwgDvEJlBYVXU['dpSupplementalMessage']['value'],'sequiturEvidence':jnAfmbzLckOeoshyWCwgDvEJlBYVXR,'thumbnail':{'poster':jnAfmbzLckOeoshyWCwgDvEJlBYVPM,'thumb':jnAfmbzLckOeoshyWCwgDvEJlBYVXr,'fanart':jnAfmbzLckOeoshyWCwgDvEJlBYVXH,'clearlogo':jnAfmbzLckOeoshyWCwgDvEJlBYVXu},'year':jnAfmbzLckOeoshyWCwgDvEJlBYVXU['releaseYear']['value'],'duration':jnAfmbzLckOeoshyWCwgDvEJlBYVPH,'info_genre':jnAfmbzLckOeoshyWCwgDvEJlBYVXK,'director':jnAfmbzLckOeoshyWCwgDvEJlBYVXQ,'cast':jnAfmbzLckOeoshyWCwgDvEJlBYVIN,}
    jnAfmbzLckOeoshyWCwgDvEJlBYVNF.append(jnAfmbzLckOeoshyWCwgDvEJlBYVNQ)
  return jnAfmbzLckOeoshyWCwgDvEJlBYVNF,jnAfmbzLckOeoshyWCwgDvEJlBYVNi,jnAfmbzLckOeoshyWCwgDvEJlBYVXi
 def NF_Subid_List(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,subJson):
  jnAfmbzLckOeoshyWCwgDvEJlBYVIt=[]
  try:
   for i in jnAfmbzLckOeoshyWCwgDvEJlBYVIq(jnAfmbzLckOeoshyWCwgDvEJlBYVIH(subJson)):
    if subJson.get(jnAfmbzLckOeoshyWCwgDvEJlBYVIp(i)).get('$type')!='ref':break
    jnAfmbzLckOeoshyWCwgDvEJlBYVIX=subJson.get(jnAfmbzLckOeoshyWCwgDvEJlBYVIp(i)).get('value')[1]
    jnAfmbzLckOeoshyWCwgDvEJlBYVIt.append(jnAfmbzLckOeoshyWCwgDvEJlBYVIX)
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception)
  return jnAfmbzLckOeoshyWCwgDvEJlBYVIt
 def NF_CookieFile_Load(jnAfmbzLckOeoshyWCwgDvEJlBYVNt,cookie_filename):
  jnAfmbzLckOeoshyWCwgDvEJlBYVPq={}
  try:
   if os.path.isfile(cookie_filename)==jnAfmbzLckOeoshyWCwgDvEJlBYVIT:return{}
   jnAfmbzLckOeoshyWCwgDvEJlBYVIx=jnAfmbzLckOeoshyWCwgDvEJlBYVIr(cookie_filename,'rb',-1)
   jnAfmbzLckOeoshyWCwgDvEJlBYVIF =pickle.loads(jnAfmbzLckOeoshyWCwgDvEJlBYVIx.read())
   jnAfmbzLckOeoshyWCwgDvEJlBYVIx.close()
   for jnAfmbzLckOeoshyWCwgDvEJlBYVPK in jnAfmbzLckOeoshyWCwgDvEJlBYVIF:
    jnAfmbzLckOeoshyWCwgDvEJlBYVPq[jnAfmbzLckOeoshyWCwgDvEJlBYVPK.name]=jnAfmbzLckOeoshyWCwgDvEJlBYVPK.value
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception) 
  return jnAfmbzLckOeoshyWCwgDvEJlBYVPq
 def NF_Get_DefaultCookies(jnAfmbzLckOeoshyWCwgDvEJlBYVNt):
  jnAfmbzLckOeoshyWCwgDvEJlBYVPq={}
  if jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['COOKIES']['flwssn'] :jnAfmbzLckOeoshyWCwgDvEJlBYVPq['flwssn'] =jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['COOKIES']['flwssn']
  if jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['COOKIES']['nfvdid'] :jnAfmbzLckOeoshyWCwgDvEJlBYVPq['nfvdid'] =jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['COOKIES']['nfvdid']
  if jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['COOKIES']['SecureNetflixId']:jnAfmbzLckOeoshyWCwgDvEJlBYVPq['SecureNetflixId']=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['COOKIES']['SecureNetflixId']
  if jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['COOKIES']['NetflixId'] :jnAfmbzLckOeoshyWCwgDvEJlBYVPq['NetflixId'] =jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['COOKIES']['NetflixId']
  return jnAfmbzLckOeoshyWCwgDvEJlBYVPq
 def NF_Get_BaseSession(jnAfmbzLckOeoshyWCwgDvEJlBYVNt):
  try:
   jnAfmbzLckOeoshyWCwgDvEJlBYVNd=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.API_NETFLIX+'/browse' 
   jnAfmbzLckOeoshyWCwgDvEJlBYVPq=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_Get_DefaultCookies()
   jnAfmbzLckOeoshyWCwgDvEJlBYVNI=jnAfmbzLckOeoshyWCwgDvEJlBYVNt.Call_Request(jnAfmbzLckOeoshyWCwgDvEJlBYVNd,payload=jnAfmbzLckOeoshyWCwgDvEJlBYVId,params=jnAfmbzLckOeoshyWCwgDvEJlBYVId,headers=jnAfmbzLckOeoshyWCwgDvEJlBYVId,cookies=jnAfmbzLckOeoshyWCwgDvEJlBYVPq,method='GET')
   if jnAfmbzLckOeoshyWCwgDvEJlBYVNI.status_code!=200:
    jnAfmbzLckOeoshyWCwgDvEJlBYVIM('pass 1 status_code error')
    return jnAfmbzLckOeoshyWCwgDvEJlBYVIT
   jnAfmbzLckOeoshyWCwgDvEJlBYVIa =jnAfmbzLckOeoshyWCwgDvEJlBYVNt.extract_json(jnAfmbzLckOeoshyWCwgDvEJlBYVNI.text,'reactContext')
   jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF['SESSION']={'mainGuid':jnAfmbzLckOeoshyWCwgDvEJlBYVIa['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':jnAfmbzLckOeoshyWCwgDvEJlBYVIa['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':jnAfmbzLckOeoshyWCwgDvEJlBYVIa['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':jnAfmbzLckOeoshyWCwgDvEJlBYVIa['models']['memberContext']['data']['userInfo']['esn'],'identifier':jnAfmbzLckOeoshyWCwgDvEJlBYVIa['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':jnAfmbzLckOeoshyWCwgDvEJlBYVIa['models']['abContext']['data']['headers'],}
   jnAfmbzLckOeoshyWCwgDvEJlBYVNt.dic_To_jsonfile(jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF_SESSION_COOKIES1,jnAfmbzLckOeoshyWCwgDvEJlBYVNt.NF)
  except jnAfmbzLckOeoshyWCwgDvEJlBYVIR as exception:
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM('pass 1 error')
   jnAfmbzLckOeoshyWCwgDvEJlBYVIM(exception)
   return jnAfmbzLckOeoshyWCwgDvEJlBYVIT
  return jnAfmbzLckOeoshyWCwgDvEJlBYVIS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
