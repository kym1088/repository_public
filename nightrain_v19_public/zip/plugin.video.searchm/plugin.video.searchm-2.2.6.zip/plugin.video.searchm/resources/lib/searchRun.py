__author__="NightRain"
sxTqameFctEbPzfpBQLvdAujJWHiYX=object
sxTqameFctEbPzfpBQLvdAujJWHiYK=None
sxTqameFctEbPzfpBQLvdAujJWHiYR=True
sxTqameFctEbPzfpBQLvdAujJWHiYg=False
sxTqameFctEbPzfpBQLvdAujJWHiYN=type
sxTqameFctEbPzfpBQLvdAujJWHiYo=dict
sxTqameFctEbPzfpBQLvdAujJWHiYM=open
sxTqameFctEbPzfpBQLvdAujJWHiYr=len
sxTqameFctEbPzfpBQLvdAujJWHiYh=Exception
sxTqameFctEbPzfpBQLvdAujJWHikC=int
sxTqameFctEbPzfpBQLvdAujJWHikD=range
sxTqameFctEbPzfpBQLvdAujJWHikO=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
sxTqameFctEbPzfpBQLvdAujJWHiCO=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
sxTqameFctEbPzfpBQLvdAujJWHiCn={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
sxTqameFctEbPzfpBQLvdAujJWHiCY=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
sxTqameFctEbPzfpBQLvdAujJWHiCk =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class sxTqameFctEbPzfpBQLvdAujJWHiCD(sxTqameFctEbPzfpBQLvdAujJWHiYX):
 def __init__(sxTqameFctEbPzfpBQLvdAujJWHiCl,sxTqameFctEbPzfpBQLvdAujJWHiCI,sxTqameFctEbPzfpBQLvdAujJWHiCG,sxTqameFctEbPzfpBQLvdAujJWHiCU):
  sxTqameFctEbPzfpBQLvdAujJWHiCl._addon_url =sxTqameFctEbPzfpBQLvdAujJWHiCI
  sxTqameFctEbPzfpBQLvdAujJWHiCl._addon_handle=sxTqameFctEbPzfpBQLvdAujJWHiCG
  sxTqameFctEbPzfpBQLvdAujJWHiCl.main_params =sxTqameFctEbPzfpBQLvdAujJWHiCU
  sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj =jnAfmbzLckOeoshyWCwgDvEJlBYVNP() 
  sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_authinfo.json'))
  sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(sxTqameFctEbPzfpBQLvdAujJWHiCl,sting):
  try:
   sxTqameFctEbPzfpBQLvdAujJWHiCw=xbmcgui.Dialog()
   sxTqameFctEbPzfpBQLvdAujJWHiCw.notification(__addonname__,sting)
  except:
   sxTqameFctEbPzfpBQLvdAujJWHiYK
 def addon_log(sxTqameFctEbPzfpBQLvdAujJWHiCl,string):
  try:
   sxTqameFctEbPzfpBQLvdAujJWHiCV=string.encode('utf-8','ignore')
  except:
   sxTqameFctEbPzfpBQLvdAujJWHiCV='addonException: addon_log'
  sxTqameFctEbPzfpBQLvdAujJWHiCy=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,sxTqameFctEbPzfpBQLvdAujJWHiCV),level=sxTqameFctEbPzfpBQLvdAujJWHiCy)
 def get_keyboard_input(sxTqameFctEbPzfpBQLvdAujJWHiCl,sxTqameFctEbPzfpBQLvdAujJWHiCM):
  sxTqameFctEbPzfpBQLvdAujJWHiCX=sxTqameFctEbPzfpBQLvdAujJWHiYK
  kb=xbmc.Keyboard()
  kb.setHeading(sxTqameFctEbPzfpBQLvdAujJWHiCM)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   sxTqameFctEbPzfpBQLvdAujJWHiCX=kb.getText()
  return sxTqameFctEbPzfpBQLvdAujJWHiCX
 def get_settings_menubookmark(sxTqameFctEbPzfpBQLvdAujJWHiCl):
  sxTqameFctEbPzfpBQLvdAujJWHiCK=sxTqameFctEbPzfpBQLvdAujJWHiYR if __addon__.getSetting('menu_bookmark')=='true' else sxTqameFctEbPzfpBQLvdAujJWHiYg
  return(sxTqameFctEbPzfpBQLvdAujJWHiCK)
 def get_settings_makebookmark(sxTqameFctEbPzfpBQLvdAujJWHiCl):
  return sxTqameFctEbPzfpBQLvdAujJWHiYR if __addon__.getSetting('make_bookmark')=='true' else sxTqameFctEbPzfpBQLvdAujJWHiYg
 def get_settings_select_info(sxTqameFctEbPzfpBQLvdAujJWHiCl):
  sxTqameFctEbPzfpBQLvdAujJWHiCR=[]
  if __addon__.getSetting('netflixyn')=='true':sxTqameFctEbPzfpBQLvdAujJWHiCR.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':sxTqameFctEbPzfpBQLvdAujJWHiCR.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':sxTqameFctEbPzfpBQLvdAujJWHiCR.append('tving')
  if __addon__.getSetting('watchayn')=='true':sxTqameFctEbPzfpBQLvdAujJWHiCR.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':sxTqameFctEbPzfpBQLvdAujJWHiCR.append('coupang')
  if __addon__.getSetting('primevyn')=='true':sxTqameFctEbPzfpBQLvdAujJWHiCR.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':sxTqameFctEbPzfpBQLvdAujJWHiCR.append('disney')
  return sxTqameFctEbPzfpBQLvdAujJWHiCR
 def add_dir(sxTqameFctEbPzfpBQLvdAujJWHiCl,label,sublabel='',img='',infoLabels=sxTqameFctEbPzfpBQLvdAujJWHiYK,isFolder=sxTqameFctEbPzfpBQLvdAujJWHiYR,params='',isLink=sxTqameFctEbPzfpBQLvdAujJWHiYg,ContextMenu=sxTqameFctEbPzfpBQLvdAujJWHiYK,direct_url=sxTqameFctEbPzfpBQLvdAujJWHiYK):
  if direct_url:
   sxTqameFctEbPzfpBQLvdAujJWHiCg=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   sxTqameFctEbPzfpBQLvdAujJWHiCo=json.dumps(params,separators=(',',':'))
   sxTqameFctEbPzfpBQLvdAujJWHiCo=base64.standard_b64encode(sxTqameFctEbPzfpBQLvdAujJWHiCo.encode()).decode('utf-8')
   sxTqameFctEbPzfpBQLvdAujJWHiCo=sxTqameFctEbPzfpBQLvdAujJWHiCo.replace('+','%2B')
   sxTqameFctEbPzfpBQLvdAujJWHiCg='%s?params=%s'%(sxTqameFctEbPzfpBQLvdAujJWHiCl._addon_url,sxTqameFctEbPzfpBQLvdAujJWHiCo)
  if sublabel and sublabel!='-':sxTqameFctEbPzfpBQLvdAujJWHiCM='%s < %s >'%(label,sublabel)
  else: sxTqameFctEbPzfpBQLvdAujJWHiCM=label
  if not img:img='DefaultFolder.png'
  sxTqameFctEbPzfpBQLvdAujJWHiCr=xbmcgui.ListItem(sxTqameFctEbPzfpBQLvdAujJWHiCM)
  if sxTqameFctEbPzfpBQLvdAujJWHiYN(img)==sxTqameFctEbPzfpBQLvdAujJWHiYo:
   sxTqameFctEbPzfpBQLvdAujJWHiCr.setArt(img)
  else:
   sxTqameFctEbPzfpBQLvdAujJWHiCr.setArt({'thumb':img,'poster':img})
  if infoLabels:sxTqameFctEbPzfpBQLvdAujJWHiCr.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   sxTqameFctEbPzfpBQLvdAujJWHiCr.setProperty('IsPlayable','true')
  if ContextMenu:sxTqameFctEbPzfpBQLvdAujJWHiCr.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(sxTqameFctEbPzfpBQLvdAujJWHiCl._addon_handle,sxTqameFctEbPzfpBQLvdAujJWHiCg,sxTqameFctEbPzfpBQLvdAujJWHiCr,isFolder)
 def Load_Searched_List(sxTqameFctEbPzfpBQLvdAujJWHiCl):
  try:
   sxTqameFctEbPzfpBQLvdAujJWHiCh=sxTqameFctEbPzfpBQLvdAujJWHiCk
   fp=sxTqameFctEbPzfpBQLvdAujJWHiYM(sxTqameFctEbPzfpBQLvdAujJWHiCh,'r',-1,'utf-8')
   sxTqameFctEbPzfpBQLvdAujJWHiDC=fp.readlines()
   fp.close()
  except:
   sxTqameFctEbPzfpBQLvdAujJWHiDC=[]
  return sxTqameFctEbPzfpBQLvdAujJWHiDC
 def Save_Searched_List(sxTqameFctEbPzfpBQLvdAujJWHiCl,sxTqameFctEbPzfpBQLvdAujJWHiOg):
  try:
   sxTqameFctEbPzfpBQLvdAujJWHiCh=sxTqameFctEbPzfpBQLvdAujJWHiCk
   sxTqameFctEbPzfpBQLvdAujJWHiDO=sxTqameFctEbPzfpBQLvdAujJWHiCl.Load_Searched_List() 
   sxTqameFctEbPzfpBQLvdAujJWHiDn={'skey':sxTqameFctEbPzfpBQLvdAujJWHiOg.strip()}
   fp=sxTqameFctEbPzfpBQLvdAujJWHiYM(sxTqameFctEbPzfpBQLvdAujJWHiCh,'w',-1,'utf-8')
   sxTqameFctEbPzfpBQLvdAujJWHiDY=urllib.parse.urlencode(sxTqameFctEbPzfpBQLvdAujJWHiDn)
   sxTqameFctEbPzfpBQLvdAujJWHiDY=sxTqameFctEbPzfpBQLvdAujJWHiDY+'\n'
   fp.write(sxTqameFctEbPzfpBQLvdAujJWHiDY)
   sxTqameFctEbPzfpBQLvdAujJWHiDk=0
   for sxTqameFctEbPzfpBQLvdAujJWHiDl in sxTqameFctEbPzfpBQLvdAujJWHiDO:
    sxTqameFctEbPzfpBQLvdAujJWHiDI=sxTqameFctEbPzfpBQLvdAujJWHiYo(urllib.parse.parse_qsl(sxTqameFctEbPzfpBQLvdAujJWHiDl))
    sxTqameFctEbPzfpBQLvdAujJWHiDG=sxTqameFctEbPzfpBQLvdAujJWHiDn.get('skey').strip()
    sxTqameFctEbPzfpBQLvdAujJWHiDU=sxTqameFctEbPzfpBQLvdAujJWHiDI.get('skey').strip()
    if sxTqameFctEbPzfpBQLvdAujJWHiDG!=sxTqameFctEbPzfpBQLvdAujJWHiDU:
     fp.write(sxTqameFctEbPzfpBQLvdAujJWHiDl)
     sxTqameFctEbPzfpBQLvdAujJWHiDk+=1
     if sxTqameFctEbPzfpBQLvdAujJWHiDk>=50:break
   fp.close()
  except:
   sxTqameFctEbPzfpBQLvdAujJWHiYK
 def dp_Search_History(sxTqameFctEbPzfpBQLvdAujJWHiCl,args):
  sxTqameFctEbPzfpBQLvdAujJWHiDS=sxTqameFctEbPzfpBQLvdAujJWHiCl.Load_Searched_List()
  for sxTqameFctEbPzfpBQLvdAujJWHiDw in sxTqameFctEbPzfpBQLvdAujJWHiDS:
   sxTqameFctEbPzfpBQLvdAujJWHiDV=sxTqameFctEbPzfpBQLvdAujJWHiYo(urllib.parse.parse_qsl(sxTqameFctEbPzfpBQLvdAujJWHiDw))
   sxTqameFctEbPzfpBQLvdAujJWHiDy=sxTqameFctEbPzfpBQLvdAujJWHiDV.get('skey').strip()
   sxTqameFctEbPzfpBQLvdAujJWHiCN={'mode':'TOTAL_SEARCH','search_key':sxTqameFctEbPzfpBQLvdAujJWHiDy,}
   sxTqameFctEbPzfpBQLvdAujJWHiDX={'mode':'HISTORY_REMOVE','skey':sxTqameFctEbPzfpBQLvdAujJWHiDy,'delmode':'ONE',}
   sxTqameFctEbPzfpBQLvdAujJWHiDK=urllib.parse.urlencode(sxTqameFctEbPzfpBQLvdAujJWHiDX)
   sxTqameFctEbPzfpBQLvdAujJWHiDR=[('선택된 검색어 ( %s ) 삭제'%(sxTqameFctEbPzfpBQLvdAujJWHiDy),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(sxTqameFctEbPzfpBQLvdAujJWHiDK))]
   sxTqameFctEbPzfpBQLvdAujJWHiCl.add_dir(sxTqameFctEbPzfpBQLvdAujJWHiDy,sublabel='',img=sxTqameFctEbPzfpBQLvdAujJWHiYK,infoLabels=sxTqameFctEbPzfpBQLvdAujJWHiYK,isFolder=sxTqameFctEbPzfpBQLvdAujJWHiYR,params=sxTqameFctEbPzfpBQLvdAujJWHiCN,ContextMenu=sxTqameFctEbPzfpBQLvdAujJWHiDR)
  sxTqameFctEbPzfpBQLvdAujJWHiDN={'plot':'검색목록 전체를 삭제합니다.'}
  sxTqameFctEbPzfpBQLvdAujJWHiCM='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  sxTqameFctEbPzfpBQLvdAujJWHiCN={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  sxTqameFctEbPzfpBQLvdAujJWHiDo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  sxTqameFctEbPzfpBQLvdAujJWHiCl.add_dir(sxTqameFctEbPzfpBQLvdAujJWHiCM,sublabel='',img=sxTqameFctEbPzfpBQLvdAujJWHiDo,infoLabels=sxTqameFctEbPzfpBQLvdAujJWHiDN,isFolder=sxTqameFctEbPzfpBQLvdAujJWHiYg,params=sxTqameFctEbPzfpBQLvdAujJWHiCN,isLink=sxTqameFctEbPzfpBQLvdAujJWHiYR)
  xbmcplugin.endOfDirectory(sxTqameFctEbPzfpBQLvdAujJWHiCl._addon_handle,cacheToDisc=sxTqameFctEbPzfpBQLvdAujJWHiYg)
 def Delete_History_List(sxTqameFctEbPzfpBQLvdAujJWHiCl,sxTqameFctEbPzfpBQLvdAujJWHiDy,sxTqameFctEbPzfpBQLvdAujJWHiDh):
  if sxTqameFctEbPzfpBQLvdAujJWHiDh=='ALL':
   try:
    sxTqameFctEbPzfpBQLvdAujJWHiCh=sxTqameFctEbPzfpBQLvdAujJWHiCk
    fp=sxTqameFctEbPzfpBQLvdAujJWHiYM(sxTqameFctEbPzfpBQLvdAujJWHiCh,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    sxTqameFctEbPzfpBQLvdAujJWHiYK
  else:
   try:
    sxTqameFctEbPzfpBQLvdAujJWHiCh=sxTqameFctEbPzfpBQLvdAujJWHiCk
    sxTqameFctEbPzfpBQLvdAujJWHiDO=sxTqameFctEbPzfpBQLvdAujJWHiCl.Load_Searched_List() 
    fp=sxTqameFctEbPzfpBQLvdAujJWHiYM(sxTqameFctEbPzfpBQLvdAujJWHiCh,'w',-1,'utf-8')
    for sxTqameFctEbPzfpBQLvdAujJWHiDl in sxTqameFctEbPzfpBQLvdAujJWHiDO:
     sxTqameFctEbPzfpBQLvdAujJWHiDI=sxTqameFctEbPzfpBQLvdAujJWHiYo(urllib.parse.parse_qsl(sxTqameFctEbPzfpBQLvdAujJWHiDl))
     sxTqameFctEbPzfpBQLvdAujJWHiDr=sxTqameFctEbPzfpBQLvdAujJWHiDI.get('skey').strip()
     if sxTqameFctEbPzfpBQLvdAujJWHiDy!=sxTqameFctEbPzfpBQLvdAujJWHiDr:
      fp.write(sxTqameFctEbPzfpBQLvdAujJWHiDl)
    fp.close()
   except:
    sxTqameFctEbPzfpBQLvdAujJWHiYK
 def dp_History_Delete(sxTqameFctEbPzfpBQLvdAujJWHiCl,args):
  sxTqameFctEbPzfpBQLvdAujJWHiDy =args.get('skey') 
  sxTqameFctEbPzfpBQLvdAujJWHiDh=args.get('delmode')
  sxTqameFctEbPzfpBQLvdAujJWHiCw=xbmcgui.Dialog()
  if sxTqameFctEbPzfpBQLvdAujJWHiDh=='ALL':
   sxTqameFctEbPzfpBQLvdAujJWHiOC=sxTqameFctEbPzfpBQLvdAujJWHiCw.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   sxTqameFctEbPzfpBQLvdAujJWHiOC=sxTqameFctEbPzfpBQLvdAujJWHiCw.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if sxTqameFctEbPzfpBQLvdAujJWHiOC==sxTqameFctEbPzfpBQLvdAujJWHiYg:sys.exit()
  sxTqameFctEbPzfpBQLvdAujJWHiCl.Delete_History_List(sxTqameFctEbPzfpBQLvdAujJWHiDy,sxTqameFctEbPzfpBQLvdAujJWHiDh)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(sxTqameFctEbPzfpBQLvdAujJWHiCl):
  sxTqameFctEbPzfpBQLvdAujJWHiCK=sxTqameFctEbPzfpBQLvdAujJWHiCl.get_settings_menubookmark()
  for sxTqameFctEbPzfpBQLvdAujJWHiOD in sxTqameFctEbPzfpBQLvdAujJWHiCO:
   sxTqameFctEbPzfpBQLvdAujJWHiCM=sxTqameFctEbPzfpBQLvdAujJWHiOD.get('title')
   sxTqameFctEbPzfpBQLvdAujJWHiDo=''
   if sxTqameFctEbPzfpBQLvdAujJWHiOD.get('mode')=='MENU_BOOKMARK' and sxTqameFctEbPzfpBQLvdAujJWHiCK==sxTqameFctEbPzfpBQLvdAujJWHiYg:continue
   sxTqameFctEbPzfpBQLvdAujJWHiCN={'mode':sxTqameFctEbPzfpBQLvdAujJWHiOD.get('mode')}
   if sxTqameFctEbPzfpBQLvdAujJWHiOD.get('mode')in['XXX','MENU_BOOKMARK']:
    sxTqameFctEbPzfpBQLvdAujJWHiOn=sxTqameFctEbPzfpBQLvdAujJWHiYg
    sxTqameFctEbPzfpBQLvdAujJWHiOY =sxTqameFctEbPzfpBQLvdAujJWHiYR
   else:
    sxTqameFctEbPzfpBQLvdAujJWHiOn=sxTqameFctEbPzfpBQLvdAujJWHiYR
    sxTqameFctEbPzfpBQLvdAujJWHiOY =sxTqameFctEbPzfpBQLvdAujJWHiYg
   if 'icon' in sxTqameFctEbPzfpBQLvdAujJWHiOD:sxTqameFctEbPzfpBQLvdAujJWHiDo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',sxTqameFctEbPzfpBQLvdAujJWHiOD.get('icon')) 
   sxTqameFctEbPzfpBQLvdAujJWHiCl.add_dir(sxTqameFctEbPzfpBQLvdAujJWHiCM,sublabel='',img=sxTqameFctEbPzfpBQLvdAujJWHiDo,infoLabels=sxTqameFctEbPzfpBQLvdAujJWHiYK,isFolder=sxTqameFctEbPzfpBQLvdAujJWHiOn,params=sxTqameFctEbPzfpBQLvdAujJWHiCN,isLink=sxTqameFctEbPzfpBQLvdAujJWHiOY)
  xbmcplugin.endOfDirectory(sxTqameFctEbPzfpBQLvdAujJWHiCl._addon_handle,cacheToDisc=sxTqameFctEbPzfpBQLvdAujJWHiYg)
 def option_check(sxTqameFctEbPzfpBQLvdAujJWHiCl):
  sxTqameFctEbPzfpBQLvdAujJWHiCR=sxTqameFctEbPzfpBQLvdAujJWHiCl.get_settings_select_info()
  if sxTqameFctEbPzfpBQLvdAujJWHiYr(sxTqameFctEbPzfpBQLvdAujJWHiCR)==0:
   sxTqameFctEbPzfpBQLvdAujJWHiCw=xbmcgui.Dialog()
   sxTqameFctEbPzfpBQLvdAujJWHiOC=sxTqameFctEbPzfpBQLvdAujJWHiCw.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if sxTqameFctEbPzfpBQLvdAujJWHiOC==sxTqameFctEbPzfpBQLvdAujJWHiYR:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in sxTqameFctEbPzfpBQLvdAujJWHiCR:
   if sxTqameFctEbPzfpBQLvdAujJWHiCl.NF_cookiefile_check()==sxTqameFctEbPzfpBQLvdAujJWHiYg:
    sxTqameFctEbPzfpBQLvdAujJWHiCl.NF_login(showMessage=sxTqameFctEbPzfpBQLvdAujJWHiYR)
  if 'disney' in sxTqameFctEbPzfpBQLvdAujJWHiCR:
   if sxTqameFctEbPzfpBQLvdAujJWHiCl.DZ_cookiefile_check()==sxTqameFctEbPzfpBQLvdAujJWHiYg:
    sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.DZ={}
 def DZ_cookiefile_check(sxTqameFctEbPzfpBQLvdAujJWHiCl):
  sxTqameFctEbPzfpBQLvdAujJWHiOl={}
  try: 
   fp=sxTqameFctEbPzfpBQLvdAujJWHiYM(sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   sxTqameFctEbPzfpBQLvdAujJWHiOl= json.load(fp)
   fp.close()
  except sxTqameFctEbPzfpBQLvdAujJWHiYh as exception:
   return sxTqameFctEbPzfpBQLvdAujJWHiYg
  sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.DZ=sxTqameFctEbPzfpBQLvdAujJWHiOl
  if sxTqameFctEbPzfpBQLvdAujJWHikC(time.time())>sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.DZ['account']['token_limit']:
   if sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.DZ_ReToken()==sxTqameFctEbPzfpBQLvdAujJWHiYg:
    sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_noti(__language__(30920).encode('utf-8'))
    return sxTqameFctEbPzfpBQLvdAujJWHiYg
   try: 
    fp=sxTqameFctEbPzfpBQLvdAujJWHiYM(sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.DZ,fp,indent=4,ensure_ascii=sxTqameFctEbPzfpBQLvdAujJWHiYg)
    fp.close()
   except sxTqameFctEbPzfpBQLvdAujJWHiYh as exception:
    return sxTqameFctEbPzfpBQLvdAujJWHiYg
  return sxTqameFctEbPzfpBQLvdAujJWHiYR
 def NF_cookiefile_check(sxTqameFctEbPzfpBQLvdAujJWHiCl):
  sxTqameFctEbPzfpBQLvdAujJWHiOl={}
  try: 
   fp=sxTqameFctEbPzfpBQLvdAujJWHiYM(sxTqameFctEbPzfpBQLvdAujJWHiCY,'r',-1,'utf-8')
   sxTqameFctEbPzfpBQLvdAujJWHiOl= json.load(fp)
   fp.close()
  except sxTqameFctEbPzfpBQLvdAujJWHiYh as exception:
   return sxTqameFctEbPzfpBQLvdAujJWHiYg
  sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF=sxTqameFctEbPzfpBQLvdAujJWHiOl
  sxTqameFctEbPzfpBQLvdAujJWHiOG =sxTqameFctEbPzfpBQLvdAujJWHikC(sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  sxTqameFctEbPzfpBQLvdAujJWHiOU=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF['SESSION']['limitdate']
  sxTqameFctEbPzfpBQLvdAujJWHiOS =sxTqameFctEbPzfpBQLvdAujJWHikC(re.sub('-','',sxTqameFctEbPzfpBQLvdAujJWHiOU))
  if sxTqameFctEbPzfpBQLvdAujJWHiOS<sxTqameFctEbPzfpBQLvdAujJWHiOG:
   sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Init_NF_Total()
   if sxTqameFctEbPzfpBQLvdAujJWHiCl.NF_login(showMessage=sxTqameFctEbPzfpBQLvdAujJWHiYg)==sxTqameFctEbPzfpBQLvdAujJWHiYg:
    return sxTqameFctEbPzfpBQLvdAujJWHiYg
  sxTqameFctEbPzfpBQLvdAujJWHiOw=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF_CookieFile_Load(sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF_ORIGINAL_COOKIE)
  if(sxTqameFctEbPzfpBQLvdAujJWHiOw['NetflixId']!=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF['COOKIES']['NetflixId']or sxTqameFctEbPzfpBQLvdAujJWHiOw['SecureNetflixId']!=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF['COOKIES']['SecureNetflixId']or sxTqameFctEbPzfpBQLvdAujJWHiOw['flwssn']!=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF['COOKIES']['flwssn']or sxTqameFctEbPzfpBQLvdAujJWHiOw['nfvdid']!=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF['COOKIES']['nfvdid']):
   sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Init_NF_Total()
   if sxTqameFctEbPzfpBQLvdAujJWHiCl.NF_login(showMessage=sxTqameFctEbPzfpBQLvdAujJWHiYg)==sxTqameFctEbPzfpBQLvdAujJWHiYg:
    return sxTqameFctEbPzfpBQLvdAujJWHiYg
  return sxTqameFctEbPzfpBQLvdAujJWHiYR
 def NF_login(sxTqameFctEbPzfpBQLvdAujJWHiCl,showMessage=sxTqameFctEbPzfpBQLvdAujJWHiYR):
  if showMessage:
   sxTqameFctEbPzfpBQLvdAujJWHiCw=xbmcgui.Dialog()
   sxTqameFctEbPzfpBQLvdAujJWHiOC=sxTqameFctEbPzfpBQLvdAujJWHiCw.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if sxTqameFctEbPzfpBQLvdAujJWHiOC==sxTqameFctEbPzfpBQLvdAujJWHiYg:
    return sxTqameFctEbPzfpBQLvdAujJWHiYg 
  sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF['COOKIES']=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF_CookieFile_Load(sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF_ORIGINAL_COOKIE)
  sxTqameFctEbPzfpBQLvdAujJWHiOV=sxTqameFctEbPzfpBQLvdAujJWHiYg if sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF['COOKIES']=={}else sxTqameFctEbPzfpBQLvdAujJWHiYR
  if sxTqameFctEbPzfpBQLvdAujJWHiOV:
   sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_log('pass1 ok!')
  else:
   sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_log('pass1 error!')
   sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_noti(__language__(30905).encode('utf-8'))
   return sxTqameFctEbPzfpBQLvdAujJWHiYg 
  sxTqameFctEbPzfpBQLvdAujJWHiOV=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF_Get_BaseSession()
  if sxTqameFctEbPzfpBQLvdAujJWHiOV:
   sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_log('pass2 ok!')
  else:
   sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_log('pass2 error!')
   sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_noti(__language__(30905).encode('utf-8'))
   return sxTqameFctEbPzfpBQLvdAujJWHiYg 
  sxTqameFctEbPzfpBQLvdAujJWHiOy =sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Now_Datetime()
  sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF['SESSION']['limitdate']=sxTqameFctEbPzfpBQLvdAujJWHiOy.strftime('%Y-%m-%d')
  try: 
   fp=sxTqameFctEbPzfpBQLvdAujJWHiYM(sxTqameFctEbPzfpBQLvdAujJWHiCY,'w',-1,'utf-8')
   json.dump(sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF,fp,indent=4,ensure_ascii=sxTqameFctEbPzfpBQLvdAujJWHiYg)
   fp.close()
   sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_log('pass3 save ok!')
  except sxTqameFctEbPzfpBQLvdAujJWHiYh as exception:
   sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_log('pass3 save error!')
   sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_noti(__language__(30905).encode('utf-8'))
   return sxTqameFctEbPzfpBQLvdAujJWHiYg
  if showMessage:sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_noti(__language__(30904).encode('utf-8'))
  return sxTqameFctEbPzfpBQLvdAujJWHiYR
 def NF_logout(sxTqameFctEbPzfpBQLvdAujJWHiCl):
  sxTqameFctEbPzfpBQLvdAujJWHiCw=xbmcgui.Dialog()
  sxTqameFctEbPzfpBQLvdAujJWHiOC=sxTqameFctEbPzfpBQLvdAujJWHiCw.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if sxTqameFctEbPzfpBQLvdAujJWHiOC==sxTqameFctEbPzfpBQLvdAujJWHiYg:return 
  if os.path.isfile(sxTqameFctEbPzfpBQLvdAujJWHiCY):os.remove(sxTqameFctEbPzfpBQLvdAujJWHiCY)
  sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(sxTqameFctEbPzfpBQLvdAujJWHiCl,sxTqameFctEbPzfpBQLvdAujJWHiON):
  sxTqameFctEbPzfpBQLvdAujJWHiOX=''
  sxTqameFctEbPzfpBQLvdAujJWHiOK=7
  try:
   for i in sxTqameFctEbPzfpBQLvdAujJWHikD(sxTqameFctEbPzfpBQLvdAujJWHiYr(sxTqameFctEbPzfpBQLvdAujJWHiON)):
    if i>=sxTqameFctEbPzfpBQLvdAujJWHiOK:
     sxTqameFctEbPzfpBQLvdAujJWHiOX=sxTqameFctEbPzfpBQLvdAujJWHiOX+'...'
     break
    sxTqameFctEbPzfpBQLvdAujJWHiOX=sxTqameFctEbPzfpBQLvdAujJWHiOX+sxTqameFctEbPzfpBQLvdAujJWHiON[i]['title']+'\n'
  except:
   return ''
  return sxTqameFctEbPzfpBQLvdAujJWHiOX
 def dp_Search_Group(sxTqameFctEbPzfpBQLvdAujJWHiCl,args):
  sxTqameFctEbPzfpBQLvdAujJWHiCR =sxTqameFctEbPzfpBQLvdAujJWHiCl.get_settings_select_info()
  sxTqameFctEbPzfpBQLvdAujJWHiOR=[]
  if 'search_key' in args:
   sxTqameFctEbPzfpBQLvdAujJWHiOg=args.get('search_key')
  else:
   sxTqameFctEbPzfpBQLvdAujJWHiOg=sxTqameFctEbPzfpBQLvdAujJWHiCl.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not sxTqameFctEbPzfpBQLvdAujJWHiOg:
    return
  if 'wavve' in sxTqameFctEbPzfpBQLvdAujJWHiCR:
   (sxTqameFctEbPzfpBQLvdAujJWHiON,sxTqameFctEbPzfpBQLvdAujJWHiOo)=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Search_Wavve(sxTqameFctEbPzfpBQLvdAujJWHiOg,'TVSHOW',1)
   if sxTqameFctEbPzfpBQLvdAujJWHiYr(sxTqameFctEbPzfpBQLvdAujJWHiON)>0:
    sxTqameFctEbPzfpBQLvdAujJWHiOM={'sType':'wavve_tvshow','sList':sxTqameFctEbPzfpBQLvdAujJWHiCl.MakeText_FreeList(sxTqameFctEbPzfpBQLvdAujJWHiON),}
    sxTqameFctEbPzfpBQLvdAujJWHiOR.append(sxTqameFctEbPzfpBQLvdAujJWHiOM)
   (sxTqameFctEbPzfpBQLvdAujJWHiON,sxTqameFctEbPzfpBQLvdAujJWHiOo)=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Search_Wavve(sxTqameFctEbPzfpBQLvdAujJWHiOg,'MOVIE',1)
   if sxTqameFctEbPzfpBQLvdAujJWHiYr(sxTqameFctEbPzfpBQLvdAujJWHiON)>0:
    sxTqameFctEbPzfpBQLvdAujJWHiOM={'sType':'wavve_movie','sList':sxTqameFctEbPzfpBQLvdAujJWHiCl.MakeText_FreeList(sxTqameFctEbPzfpBQLvdAujJWHiON),}
    sxTqameFctEbPzfpBQLvdAujJWHiOR.append(sxTqameFctEbPzfpBQLvdAujJWHiOM)
  if 'tving' in sxTqameFctEbPzfpBQLvdAujJWHiCR:
   (sxTqameFctEbPzfpBQLvdAujJWHiON,sxTqameFctEbPzfpBQLvdAujJWHiOo)=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Search_Tving(sxTqameFctEbPzfpBQLvdAujJWHiOg,'TVSHOW',1)
   if sxTqameFctEbPzfpBQLvdAujJWHiYr(sxTqameFctEbPzfpBQLvdAujJWHiON)>0:
    sxTqameFctEbPzfpBQLvdAujJWHiOM={'sType':'tving_tvshow','sList':sxTqameFctEbPzfpBQLvdAujJWHiCl.MakeText_FreeList(sxTqameFctEbPzfpBQLvdAujJWHiON),}
    sxTqameFctEbPzfpBQLvdAujJWHiOR.append(sxTqameFctEbPzfpBQLvdAujJWHiOM)
   (sxTqameFctEbPzfpBQLvdAujJWHiON,sxTqameFctEbPzfpBQLvdAujJWHiOo)=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Search_Tving(sxTqameFctEbPzfpBQLvdAujJWHiOg,'MOVIE',1)
   if sxTqameFctEbPzfpBQLvdAujJWHiYr(sxTqameFctEbPzfpBQLvdAujJWHiON)>0:
    sxTqameFctEbPzfpBQLvdAujJWHiOM={'sType':'tving_movie','sList':sxTqameFctEbPzfpBQLvdAujJWHiCl.MakeText_FreeList(sxTqameFctEbPzfpBQLvdAujJWHiON),}
    sxTqameFctEbPzfpBQLvdAujJWHiOR.append(sxTqameFctEbPzfpBQLvdAujJWHiOM)
  if 'watcha' in sxTqameFctEbPzfpBQLvdAujJWHiCR:
   (sxTqameFctEbPzfpBQLvdAujJWHiON,sxTqameFctEbPzfpBQLvdAujJWHiOo)=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Search_Watcha(sxTqameFctEbPzfpBQLvdAujJWHiOg,1)
   if sxTqameFctEbPzfpBQLvdAujJWHiYr(sxTqameFctEbPzfpBQLvdAujJWHiON)>0:
    sxTqameFctEbPzfpBQLvdAujJWHiOM={'sType':'watcha_list','sList':sxTqameFctEbPzfpBQLvdAujJWHiCl.MakeText_FreeList(sxTqameFctEbPzfpBQLvdAujJWHiON),}
    sxTqameFctEbPzfpBQLvdAujJWHiOR.append(sxTqameFctEbPzfpBQLvdAujJWHiOM)
  if 'coupang' in sxTqameFctEbPzfpBQLvdAujJWHiCR:
   (sxTqameFctEbPzfpBQLvdAujJWHiON,sxTqameFctEbPzfpBQLvdAujJWHiOo)=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Search_Coupang(sxTqameFctEbPzfpBQLvdAujJWHiOg,1)
   if sxTqameFctEbPzfpBQLvdAujJWHiYr(sxTqameFctEbPzfpBQLvdAujJWHiON)>0:
    sxTqameFctEbPzfpBQLvdAujJWHiOM={'sType':'coupang_list','sList':sxTqameFctEbPzfpBQLvdAujJWHiCl.MakeText_FreeList(sxTqameFctEbPzfpBQLvdAujJWHiON),}
    sxTqameFctEbPzfpBQLvdAujJWHiOR.append(sxTqameFctEbPzfpBQLvdAujJWHiOM)
  if 'netflix' in sxTqameFctEbPzfpBQLvdAujJWHiCR:
   try:
    (sxTqameFctEbPzfpBQLvdAujJWHiON,sxTqameFctEbPzfpBQLvdAujJWHiOo,sxTqameFctEbPzfpBQLvdAujJWHiOr)=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Search_Netflix(sxTqameFctEbPzfpBQLvdAujJWHiOg,1)
   except:
    sxTqameFctEbPzfpBQLvdAujJWHiON=[]
    sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_noti(__language__(30919).encode('utf8'))
   if sxTqameFctEbPzfpBQLvdAujJWHiYr(sxTqameFctEbPzfpBQLvdAujJWHiON)>0:
    sxTqameFctEbPzfpBQLvdAujJWHiOM={'sType':'netflix_list','sList':sxTqameFctEbPzfpBQLvdAujJWHiCl.MakeText_FreeList(sxTqameFctEbPzfpBQLvdAujJWHiON),}
    sxTqameFctEbPzfpBQLvdAujJWHiOR.append(sxTqameFctEbPzfpBQLvdAujJWHiOM)
  if 'amazon' in sxTqameFctEbPzfpBQLvdAujJWHiCR:
   (sxTqameFctEbPzfpBQLvdAujJWHiON)=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Search_Primev(sxTqameFctEbPzfpBQLvdAujJWHiOg)
   if sxTqameFctEbPzfpBQLvdAujJWHiYr(sxTqameFctEbPzfpBQLvdAujJWHiON)>0:
    sxTqameFctEbPzfpBQLvdAujJWHiOM={'sType':'primev_list','sList':sxTqameFctEbPzfpBQLvdAujJWHiCl.MakeText_FreeList(sxTqameFctEbPzfpBQLvdAujJWHiON),}
    sxTqameFctEbPzfpBQLvdAujJWHiOR.append(sxTqameFctEbPzfpBQLvdAujJWHiOM)
  if 'disney' in sxTqameFctEbPzfpBQLvdAujJWHiCR:
   try:
    (sxTqameFctEbPzfpBQLvdAujJWHiON)=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Search_Disney(sxTqameFctEbPzfpBQLvdAujJWHiOg)
   except:
    sxTqameFctEbPzfpBQLvdAujJWHiON=[]
    sxTqameFctEbPzfpBQLvdAujJWHiCl.addon_noti(__language__(30921).encode('utf8'))
   if sxTqameFctEbPzfpBQLvdAujJWHiYr(sxTqameFctEbPzfpBQLvdAujJWHiON)>0:
    sxTqameFctEbPzfpBQLvdAujJWHiOM={'sType':'disney_list','sList':sxTqameFctEbPzfpBQLvdAujJWHiCl.MakeText_FreeList(sxTqameFctEbPzfpBQLvdAujJWHiON),}
    sxTqameFctEbPzfpBQLvdAujJWHiOR.append(sxTqameFctEbPzfpBQLvdAujJWHiOM)
  for sxTqameFctEbPzfpBQLvdAujJWHiOh in sxTqameFctEbPzfpBQLvdAujJWHiOR:
   sxTqameFctEbPzfpBQLvdAujJWHinC=sxTqameFctEbPzfpBQLvdAujJWHiCn[sxTqameFctEbPzfpBQLvdAujJWHiOh.get('sType')]
   sxTqameFctEbPzfpBQLvdAujJWHinD={'plot':'검색어 : '+sxTqameFctEbPzfpBQLvdAujJWHiOg+'\n\n'+sxTqameFctEbPzfpBQLvdAujJWHiOh.get('sList')}
   sxTqameFctEbPzfpBQLvdAujJWHiCM=sxTqameFctEbPzfpBQLvdAujJWHinC.get('title')
   sxTqameFctEbPzfpBQLvdAujJWHiCN={'mode':sxTqameFctEbPzfpBQLvdAujJWHinC.get('mode'),'ott':sxTqameFctEbPzfpBQLvdAujJWHinC.get('ott'),'vidtype':sxTqameFctEbPzfpBQLvdAujJWHinC.get('vidtype'),'search_key':sxTqameFctEbPzfpBQLvdAujJWHiOg}
   if sxTqameFctEbPzfpBQLvdAujJWHinC.get('ott')=='netflix':
    sxTqameFctEbPzfpBQLvdAujJWHinO=''
    sxTqameFctEbPzfpBQLvdAujJWHiCN['page'] ='1'
    sxTqameFctEbPzfpBQLvdAujJWHiCN['byReference']='-'
   else:
    sxTqameFctEbPzfpBQLvdAujJWHinO=sxTqameFctEbPzfpBQLvdAujJWHiCl.make_Hyper_Link(sxTqameFctEbPzfpBQLvdAujJWHiCN)
   sxTqameFctEbPzfpBQLvdAujJWHiDo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',sxTqameFctEbPzfpBQLvdAujJWHinC.get('icon'))
   sxTqameFctEbPzfpBQLvdAujJWHiCl.add_dir(sxTqameFctEbPzfpBQLvdAujJWHiCM,sublabel='',img=sxTqameFctEbPzfpBQLvdAujJWHiDo,infoLabels=sxTqameFctEbPzfpBQLvdAujJWHinD,isFolder=sxTqameFctEbPzfpBQLvdAujJWHiYR,params=sxTqameFctEbPzfpBQLvdAujJWHiCN,isLink=sxTqameFctEbPzfpBQLvdAujJWHiYg,direct_url=sxTqameFctEbPzfpBQLvdAujJWHinO)
  xbmcplugin.endOfDirectory(sxTqameFctEbPzfpBQLvdAujJWHiCl._addon_handle)
  sxTqameFctEbPzfpBQLvdAujJWHiCl.Save_Searched_List(sxTqameFctEbPzfpBQLvdAujJWHiOg)
 def make_Hyper_Link(sxTqameFctEbPzfpBQLvdAujJWHiCl,args):
  sxTqameFctEbPzfpBQLvdAujJWHinY =args.get('ott')
  sxTqameFctEbPzfpBQLvdAujJWHink =args.get('vidtype')
  sxTqameFctEbPzfpBQLvdAujJWHiOg=args.get('search_key')
  sxTqameFctEbPzfpBQLvdAujJWHinO='-'
  if sxTqameFctEbPzfpBQLvdAujJWHinY=='wavve':
   sxTqameFctEbPzfpBQLvdAujJWHinl={'mode':'LOCAL_SEARCH','sType':'movie' if sxTqameFctEbPzfpBQLvdAujJWHink=='MOVIE' else 'vod','search_key':sxTqameFctEbPzfpBQLvdAujJWHiOg,'page':'1',}
   sxTqameFctEbPzfpBQLvdAujJWHinI=urllib.parse.urlencode(sxTqameFctEbPzfpBQLvdAujJWHinl)
   sxTqameFctEbPzfpBQLvdAujJWHinO='plugin://plugin.video.wavvem/?'
   sxTqameFctEbPzfpBQLvdAujJWHinO+=sxTqameFctEbPzfpBQLvdAujJWHinI
  elif sxTqameFctEbPzfpBQLvdAujJWHinY=='tving':
   sxTqameFctEbPzfpBQLvdAujJWHinl={'mode':'LOCAL_SEARCH','stype':'movie' if sxTqameFctEbPzfpBQLvdAujJWHink=='MOVIE' else 'vod','search_key':sxTqameFctEbPzfpBQLvdAujJWHiOg,'page':'1',}
   sxTqameFctEbPzfpBQLvdAujJWHinI=urllib.parse.urlencode(sxTqameFctEbPzfpBQLvdAujJWHinl)
   sxTqameFctEbPzfpBQLvdAujJWHinO='plugin://plugin.video.tvingm/?'
   sxTqameFctEbPzfpBQLvdAujJWHinO+=sxTqameFctEbPzfpBQLvdAujJWHinI
  elif sxTqameFctEbPzfpBQLvdAujJWHinY=='watcha':
   sxTqameFctEbPzfpBQLvdAujJWHinl={'mode':'LOCAL_SEARCH','search_key':sxTqameFctEbPzfpBQLvdAujJWHiOg,'page':'1',}
   sxTqameFctEbPzfpBQLvdAujJWHinI=urllib.parse.urlencode(sxTqameFctEbPzfpBQLvdAujJWHinl)
   sxTqameFctEbPzfpBQLvdAujJWHinO='plugin://plugin.video.watcham/?'
   sxTqameFctEbPzfpBQLvdAujJWHinO+=sxTqameFctEbPzfpBQLvdAujJWHinI
  elif sxTqameFctEbPzfpBQLvdAujJWHinY=='coupang':
   sxTqameFctEbPzfpBQLvdAujJWHinl={'mode':'LOCAL_SEARCH','search_key':sxTqameFctEbPzfpBQLvdAujJWHiOg,'page':'1',}
   sxTqameFctEbPzfpBQLvdAujJWHinI=urllib.parse.urlencode(sxTqameFctEbPzfpBQLvdAujJWHinl)
   sxTqameFctEbPzfpBQLvdAujJWHinO='plugin://plugin.video.coupangm/?'
   sxTqameFctEbPzfpBQLvdAujJWHinO+=sxTqameFctEbPzfpBQLvdAujJWHinI
  elif sxTqameFctEbPzfpBQLvdAujJWHinY=='netflix':
   sxTqameFctEbPzfpBQLvdAujJWHinG=args.get('videoid')
   sxTqameFctEbPzfpBQLvdAujJWHinU=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.NF['SESSION']['nowGuid']
   if sxTqameFctEbPzfpBQLvdAujJWHink=='TVSHOW':
    sxTqameFctEbPzfpBQLvdAujJWHinO='plugin://plugin.video.netflix/directory/show/%s/'%(sxTqameFctEbPzfpBQLvdAujJWHinG)
   else:
    sxTqameFctEbPzfpBQLvdAujJWHinO='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(sxTqameFctEbPzfpBQLvdAujJWHinG,sxTqameFctEbPzfpBQLvdAujJWHinU)
  elif sxTqameFctEbPzfpBQLvdAujJWHinY=='amazon':
   sxTqameFctEbPzfpBQLvdAujJWHinl={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':sxTqameFctEbPzfpBQLvdAujJWHiOg,}}
   sxTqameFctEbPzfpBQLvdAujJWHinI=json.dumps(sxTqameFctEbPzfpBQLvdAujJWHinl,separators=(',',':'))
   sxTqameFctEbPzfpBQLvdAujJWHinI=base64.standard_b64encode(sxTqameFctEbPzfpBQLvdAujJWHinI.encode()).decode('utf-8')
   sxTqameFctEbPzfpBQLvdAujJWHinI=sxTqameFctEbPzfpBQLvdAujJWHinI.replace('+','%2B')
   sxTqameFctEbPzfpBQLvdAujJWHinO='plugin://plugin.video.primevm/?params='
   sxTqameFctEbPzfpBQLvdAujJWHinO+=sxTqameFctEbPzfpBQLvdAujJWHinI
  elif sxTqameFctEbPzfpBQLvdAujJWHinY=='disney':
   sxTqameFctEbPzfpBQLvdAujJWHinl={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':sxTqameFctEbPzfpBQLvdAujJWHiOg,}}
   sxTqameFctEbPzfpBQLvdAujJWHinI=json.dumps(sxTqameFctEbPzfpBQLvdAujJWHinl,separators=(',',':'))
   sxTqameFctEbPzfpBQLvdAujJWHinI=base64.standard_b64encode(sxTqameFctEbPzfpBQLvdAujJWHinI.encode()).decode('utf-8')
   sxTqameFctEbPzfpBQLvdAujJWHinI=sxTqameFctEbPzfpBQLvdAujJWHinI.replace('+','%2B')
   sxTqameFctEbPzfpBQLvdAujJWHinO='plugin://plugin.video.disneym/?params='
   sxTqameFctEbPzfpBQLvdAujJWHinO+=sxTqameFctEbPzfpBQLvdAujJWHinI
  return sxTqameFctEbPzfpBQLvdAujJWHinO
 def dp_Nf_Search(sxTqameFctEbPzfpBQLvdAujJWHiCl,args):
  sxTqameFctEbPzfpBQLvdAujJWHinS =sxTqameFctEbPzfpBQLvdAujJWHikC(args.get('page'))
  sxTqameFctEbPzfpBQLvdAujJWHiOg =args.get('search_key')
  sxTqameFctEbPzfpBQLvdAujJWHiOr=args.get('byReference')
  (sxTqameFctEbPzfpBQLvdAujJWHiON,sxTqameFctEbPzfpBQLvdAujJWHiOo,sxTqameFctEbPzfpBQLvdAujJWHiOr)=sxTqameFctEbPzfpBQLvdAujJWHiCl.SearchObj.Get_Search_Netflix(sxTqameFctEbPzfpBQLvdAujJWHiOg,sxTqameFctEbPzfpBQLvdAujJWHinS,byReference=sxTqameFctEbPzfpBQLvdAujJWHiOr)
  for sxTqameFctEbPzfpBQLvdAujJWHinw in sxTqameFctEbPzfpBQLvdAujJWHiON:
   sxTqameFctEbPzfpBQLvdAujJWHinG =sxTqameFctEbPzfpBQLvdAujJWHinw.get('videoid')
   sxTqameFctEbPzfpBQLvdAujJWHink =sxTqameFctEbPzfpBQLvdAujJWHinw.get('vidtype')
   sxTqameFctEbPzfpBQLvdAujJWHiCM =sxTqameFctEbPzfpBQLvdAujJWHinw.get('title')
   sxTqameFctEbPzfpBQLvdAujJWHinV =sxTqameFctEbPzfpBQLvdAujJWHinw.get('mpaa')
   sxTqameFctEbPzfpBQLvdAujJWHiny =sxTqameFctEbPzfpBQLvdAujJWHinw.get('regularSynopsis')
   sxTqameFctEbPzfpBQLvdAujJWHinX =sxTqameFctEbPzfpBQLvdAujJWHinw.get('dpSupplemental')
   sxTqameFctEbPzfpBQLvdAujJWHinK=sxTqameFctEbPzfpBQLvdAujJWHinw.get('sequiturEvidence')
   sxTqameFctEbPzfpBQLvdAujJWHinR =sxTqameFctEbPzfpBQLvdAujJWHinw.get('thumbnail')
   sxTqameFctEbPzfpBQLvdAujJWHing =sxTqameFctEbPzfpBQLvdAujJWHinw.get('year')
   sxTqameFctEbPzfpBQLvdAujJWHinN =sxTqameFctEbPzfpBQLvdAujJWHinw.get('duration')
   sxTqameFctEbPzfpBQLvdAujJWHino =sxTqameFctEbPzfpBQLvdAujJWHinw.get('info_genre')
   sxTqameFctEbPzfpBQLvdAujJWHinM =sxTqameFctEbPzfpBQLvdAujJWHinw.get('director')
   sxTqameFctEbPzfpBQLvdAujJWHinr =sxTqameFctEbPzfpBQLvdAujJWHinw.get('cast')
   if sxTqameFctEbPzfpBQLvdAujJWHink=='movie':
    sxTqameFctEbPzfpBQLvdAujJWHiDg=' (%s)'%(sxTqameFctEbPzfpBQLvdAujJWHikO(sxTqameFctEbPzfpBQLvdAujJWHing))
   else:
    sxTqameFctEbPzfpBQLvdAujJWHiDg=''
   sxTqameFctEbPzfpBQLvdAujJWHinh=''
   if sxTqameFctEbPzfpBQLvdAujJWHiny:sxTqameFctEbPzfpBQLvdAujJWHinh=sxTqameFctEbPzfpBQLvdAujJWHinh+'\n\n'+sxTqameFctEbPzfpBQLvdAujJWHiny
   if sxTqameFctEbPzfpBQLvdAujJWHinX :sxTqameFctEbPzfpBQLvdAujJWHinh=sxTqameFctEbPzfpBQLvdAujJWHinh+'\n\n'+sxTqameFctEbPzfpBQLvdAujJWHinX
   if sxTqameFctEbPzfpBQLvdAujJWHinK:sxTqameFctEbPzfpBQLvdAujJWHinh=sxTqameFctEbPzfpBQLvdAujJWHinh+'\n\n'+sxTqameFctEbPzfpBQLvdAujJWHinK
   sxTqameFctEbPzfpBQLvdAujJWHinh=sxTqameFctEbPzfpBQLvdAujJWHinh.strip()
   sxTqameFctEbPzfpBQLvdAujJWHiDN={'mediatype':'tvshow' if sxTqameFctEbPzfpBQLvdAujJWHink=='show' else 'movie','title':sxTqameFctEbPzfpBQLvdAujJWHiCM,'mpaa':sxTqameFctEbPzfpBQLvdAujJWHinV,'plot':sxTqameFctEbPzfpBQLvdAujJWHinh,'duration':sxTqameFctEbPzfpBQLvdAujJWHinN,'genre':sxTqameFctEbPzfpBQLvdAujJWHino,'director':sxTqameFctEbPzfpBQLvdAujJWHinM,'cast':sxTqameFctEbPzfpBQLvdAujJWHinr,'year':sxTqameFctEbPzfpBQLvdAujJWHing,}
   sxTqameFctEbPzfpBQLvdAujJWHiCN={'ott':'netflix','vidtype':'TVSHOW' if sxTqameFctEbPzfpBQLvdAujJWHink=='show' else 'MOVIE','videoid':sxTqameFctEbPzfpBQLvdAujJWHinG,}
   sxTqameFctEbPzfpBQLvdAujJWHinO=sxTqameFctEbPzfpBQLvdAujJWHiCl.make_Hyper_Link(sxTqameFctEbPzfpBQLvdAujJWHiCN)
   sxTqameFctEbPzfpBQLvdAujJWHiOn=sxTqameFctEbPzfpBQLvdAujJWHiYR if sxTqameFctEbPzfpBQLvdAujJWHink=='show' else sxTqameFctEbPzfpBQLvdAujJWHiYg
   if sxTqameFctEbPzfpBQLvdAujJWHiCl.get_settings_makebookmark():
    sxTqameFctEbPzfpBQLvdAujJWHiYC={'mode':'SET_BOOKMARK','values':{'videoid':sxTqameFctEbPzfpBQLvdAujJWHinG,'vidtype':'tvshow' if sxTqameFctEbPzfpBQLvdAujJWHink=='show' else 'movie','vtitle':sxTqameFctEbPzfpBQLvdAujJWHiCM+sxTqameFctEbPzfpBQLvdAujJWHiDg,'vsubtitle':'','vinfo':sxTqameFctEbPzfpBQLvdAujJWHiDN,'thumbnail':sxTqameFctEbPzfpBQLvdAujJWHinR,}}
    sxTqameFctEbPzfpBQLvdAujJWHiYD=json.dumps(sxTqameFctEbPzfpBQLvdAujJWHiYC,separators=(',',':'))
    sxTqameFctEbPzfpBQLvdAujJWHiYD=base64.standard_b64encode(sxTqameFctEbPzfpBQLvdAujJWHiYD.encode()).decode('utf-8')
    sxTqameFctEbPzfpBQLvdAujJWHiYD=sxTqameFctEbPzfpBQLvdAujJWHiYD.replace('+','%2B')
    sxTqameFctEbPzfpBQLvdAujJWHiYO='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(sxTqameFctEbPzfpBQLvdAujJWHiYD)
    sxTqameFctEbPzfpBQLvdAujJWHiDR=[('(통합) 찜 영상에 추가',sxTqameFctEbPzfpBQLvdAujJWHiYO)]
   else:
    sxTqameFctEbPzfpBQLvdAujJWHiDR=sxTqameFctEbPzfpBQLvdAujJWHiYK
   sxTqameFctEbPzfpBQLvdAujJWHiCl.add_dir(sxTqameFctEbPzfpBQLvdAujJWHiCM+sxTqameFctEbPzfpBQLvdAujJWHiDg,sublabel=sxTqameFctEbPzfpBQLvdAujJWHiYK,img=sxTqameFctEbPzfpBQLvdAujJWHinR,infoLabels=sxTqameFctEbPzfpBQLvdAujJWHiDN,isFolder=sxTqameFctEbPzfpBQLvdAujJWHiOn,params=sxTqameFctEbPzfpBQLvdAujJWHiCN,isLink=sxTqameFctEbPzfpBQLvdAujJWHiYg,ContextMenu=sxTqameFctEbPzfpBQLvdAujJWHiDR,direct_url=sxTqameFctEbPzfpBQLvdAujJWHinO)
  if sxTqameFctEbPzfpBQLvdAujJWHiOo:
   sxTqameFctEbPzfpBQLvdAujJWHiCN={}
   sxTqameFctEbPzfpBQLvdAujJWHiCN['mode'] ='NF_SEARCH' 
   sxTqameFctEbPzfpBQLvdAujJWHiCN['page'] =sxTqameFctEbPzfpBQLvdAujJWHikO(sxTqameFctEbPzfpBQLvdAujJWHinS+1)
   sxTqameFctEbPzfpBQLvdAujJWHiCN['search_key']=sxTqameFctEbPzfpBQLvdAujJWHiOg
   sxTqameFctEbPzfpBQLvdAujJWHiCN['byReference']=sxTqameFctEbPzfpBQLvdAujJWHiOr
   sxTqameFctEbPzfpBQLvdAujJWHiCM='[B]%s >>[/B]'%'다음 페이지'
   sxTqameFctEbPzfpBQLvdAujJWHiYn=sxTqameFctEbPzfpBQLvdAujJWHikO(sxTqameFctEbPzfpBQLvdAujJWHinS+1)
   sxTqameFctEbPzfpBQLvdAujJWHiDo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   sxTqameFctEbPzfpBQLvdAujJWHiCl.add_dir(sxTqameFctEbPzfpBQLvdAujJWHiCM,sublabel=sxTqameFctEbPzfpBQLvdAujJWHiYn,img=sxTqameFctEbPzfpBQLvdAujJWHiDo,infoLabels=sxTqameFctEbPzfpBQLvdAujJWHiYK,isFolder=sxTqameFctEbPzfpBQLvdAujJWHiYR,params=sxTqameFctEbPzfpBQLvdAujJWHiCN)
  xbmcplugin.setContent(sxTqameFctEbPzfpBQLvdAujJWHiCl._addon_handle,'movies')
  xbmcplugin.endOfDirectory(sxTqameFctEbPzfpBQLvdAujJWHiCl._addon_handle)
 def dp_Bookmark_Menu(sxTqameFctEbPzfpBQLvdAujJWHiCl,args):
  sxTqameFctEbPzfpBQLvdAujJWHiYk='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(sxTqameFctEbPzfpBQLvdAujJWHiYk)
 def dp_Set_Bookmark(sxTqameFctEbPzfpBQLvdAujJWHiCl,args):
  sxTqameFctEbPzfpBQLvdAujJWHinG =args.get('videoid')
  sxTqameFctEbPzfpBQLvdAujJWHink =args.get('vidtype')
  sxTqameFctEbPzfpBQLvdAujJWHiYl =args.get('vtitle')
  sxTqameFctEbPzfpBQLvdAujJWHiYI =args.get('vsubtitle')
  sxTqameFctEbPzfpBQLvdAujJWHiYG =args.get('vinfo')
  sxTqameFctEbPzfpBQLvdAujJWHinR =args.get('thumbnail')
  sxTqameFctEbPzfpBQLvdAujJWHiCw=xbmcgui.Dialog()
  sxTqameFctEbPzfpBQLvdAujJWHiOC=sxTqameFctEbPzfpBQLvdAujJWHiCw.yesno(__language__(30917).encode('utf8'),sxTqameFctEbPzfpBQLvdAujJWHiYl+' \n\n'+__language__(30918))
  if sxTqameFctEbPzfpBQLvdAujJWHiOC==sxTqameFctEbPzfpBQLvdAujJWHiYg:return
  sxTqameFctEbPzfpBQLvdAujJWHiYU={'indexinfo':{'ott':'netflix','videoid':sxTqameFctEbPzfpBQLvdAujJWHinG,'vidtype':sxTqameFctEbPzfpBQLvdAujJWHink,},'saveinfo':{'title':sxTqameFctEbPzfpBQLvdAujJWHiYl,'subtitle':sxTqameFctEbPzfpBQLvdAujJWHiYI,'thumbnail':sxTqameFctEbPzfpBQLvdAujJWHinR,'infoLabels':sxTqameFctEbPzfpBQLvdAujJWHiYG,},}
  sxTqameFctEbPzfpBQLvdAujJWHiCN={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':sxTqameFctEbPzfpBQLvdAujJWHiYU,}}
  sxTqameFctEbPzfpBQLvdAujJWHiCo=json.dumps(sxTqameFctEbPzfpBQLvdAujJWHiCN,separators=(',',':'))
  sxTqameFctEbPzfpBQLvdAujJWHiCo=base64.standard_b64encode(sxTqameFctEbPzfpBQLvdAujJWHiCo.encode()).decode('utf-8')
  sxTqameFctEbPzfpBQLvdAujJWHiCo=sxTqameFctEbPzfpBQLvdAujJWHiCo.replace('+','%2B')
  sxTqameFctEbPzfpBQLvdAujJWHiYO='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(sxTqameFctEbPzfpBQLvdAujJWHiCo)
  xbmc.executebuiltin(sxTqameFctEbPzfpBQLvdAujJWHiYO)
 def search_main(sxTqameFctEbPzfpBQLvdAujJWHiCl):
  sxTqameFctEbPzfpBQLvdAujJWHiYS=sxTqameFctEbPzfpBQLvdAujJWHiCl.main_params.get('params')
  if sxTqameFctEbPzfpBQLvdAujJWHiYS:
   sxTqameFctEbPzfpBQLvdAujJWHiYw =base64.standard_b64decode(sxTqameFctEbPzfpBQLvdAujJWHiYS).decode('utf-8')
   sxTqameFctEbPzfpBQLvdAujJWHiYw =json.loads(sxTqameFctEbPzfpBQLvdAujJWHiYw)
   sxTqameFctEbPzfpBQLvdAujJWHiYV =sxTqameFctEbPzfpBQLvdAujJWHiYw.get('mode')
   sxTqameFctEbPzfpBQLvdAujJWHiYy =sxTqameFctEbPzfpBQLvdAujJWHiYw.get('values')
  else:
   sxTqameFctEbPzfpBQLvdAujJWHiYV=sxTqameFctEbPzfpBQLvdAujJWHiCl.main_params.get('mode',sxTqameFctEbPzfpBQLvdAujJWHiYK)
   sxTqameFctEbPzfpBQLvdAujJWHiYy=sxTqameFctEbPzfpBQLvdAujJWHiCl.main_params
  if sxTqameFctEbPzfpBQLvdAujJWHiYV=='NFLOGOUT':
   sxTqameFctEbPzfpBQLvdAujJWHiCl.NF_logout()
   return
  elif sxTqameFctEbPzfpBQLvdAujJWHiYV=='NFLOGIN':
   sxTqameFctEbPzfpBQLvdAujJWHiCl.NF_login(showMessage=sxTqameFctEbPzfpBQLvdAujJWHiYR)
   return
  sxTqameFctEbPzfpBQLvdAujJWHiCl.option_check()
  if sxTqameFctEbPzfpBQLvdAujJWHiYV is sxTqameFctEbPzfpBQLvdAujJWHiYK:
   sxTqameFctEbPzfpBQLvdAujJWHiCl.dp_Main_List()
  elif sxTqameFctEbPzfpBQLvdAujJWHiYV=='TOTAL_SEARCH':
   sxTqameFctEbPzfpBQLvdAujJWHiCl.dp_Search_Group(sxTqameFctEbPzfpBQLvdAujJWHiYy)
  elif sxTqameFctEbPzfpBQLvdAujJWHiYV=='NF_SEARCH':
   sxTqameFctEbPzfpBQLvdAujJWHiCl.dp_Nf_Search(sxTqameFctEbPzfpBQLvdAujJWHiYy)
  elif sxTqameFctEbPzfpBQLvdAujJWHiYV=='TOTAL_HISTORY':
   sxTqameFctEbPzfpBQLvdAujJWHiCl.dp_Search_History(sxTqameFctEbPzfpBQLvdAujJWHiYy)
  elif sxTqameFctEbPzfpBQLvdAujJWHiYV=='HISTORY_REMOVE':
   sxTqameFctEbPzfpBQLvdAujJWHiCl.dp_History_Delete(sxTqameFctEbPzfpBQLvdAujJWHiYy)
  elif sxTqameFctEbPzfpBQLvdAujJWHiYV=='MENU_BOOKMARK':
   sxTqameFctEbPzfpBQLvdAujJWHiCl.dp_Bookmark_Menu(sxTqameFctEbPzfpBQLvdAujJWHiYy)
  elif sxTqameFctEbPzfpBQLvdAujJWHiYV=='SET_BOOKMARK':
   sxTqameFctEbPzfpBQLvdAujJWHiCl.dp_Set_Bookmark(sxTqameFctEbPzfpBQLvdAujJWHiYy)
  else:
   sxTqameFctEbPzfpBQLvdAujJWHiYK
# Created by pyminifier (https://github.com/liftoff/pyminifier)
