__author__="NightRain"
cVDBwgLMyQeqpRxSrJaOjKiTEYbIun=object
cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv=None
cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh=True
cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk=False
cVDBwgLMyQeqpRxSrJaOjKiTEYbIuG=type
cVDBwgLMyQeqpRxSrJaOjKiTEYbIus=dict
cVDBwgLMyQeqpRxSrJaOjKiTEYbIum=open
cVDBwgLMyQeqpRxSrJaOjKiTEYbIuz=len
cVDBwgLMyQeqpRxSrJaOjKiTEYbIut=Exception
cVDBwgLMyQeqpRxSrJaOjKiTEYbIuU=range
cVDBwgLMyQeqpRxSrJaOjKiTEYbIuC=int
cVDBwgLMyQeqpRxSrJaOjKiTEYbIuF=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
cVDBwgLMyQeqpRxSrJaOjKiTEYbINW=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
cVDBwgLMyQeqpRxSrJaOjKiTEYbINA={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'HYPER_LINK','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},}
cVDBwgLMyQeqpRxSrJaOjKiTEYbINu=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
cVDBwgLMyQeqpRxSrJaOjKiTEYbINP =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class cVDBwgLMyQeqpRxSrJaOjKiTEYbINX(cVDBwgLMyQeqpRxSrJaOjKiTEYbIun):
 def __init__(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,cVDBwgLMyQeqpRxSrJaOjKiTEYbINn,cVDBwgLMyQeqpRxSrJaOjKiTEYbINv,cVDBwgLMyQeqpRxSrJaOjKiTEYbINh):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH._addon_url =cVDBwgLMyQeqpRxSrJaOjKiTEYbINn
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH._addon_handle=cVDBwgLMyQeqpRxSrJaOjKiTEYbINv
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.main_params =cVDBwgLMyQeqpRxSrJaOjKiTEYbINh
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj =MfiUVAkcLEaHzFelOCIvuhGSyjqxbs() 
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
 def addon_noti(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,sting):
  try:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbING=xbmcgui.Dialog()
   cVDBwgLMyQeqpRxSrJaOjKiTEYbING.notification(__addonname__,sting)
  except:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv
 def addon_log(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,string):
  try:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINs=string.encode('utf-8','ignore')
  except:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINs='addonException: addon_log'
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINm=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,cVDBwgLMyQeqpRxSrJaOjKiTEYbINs),level=cVDBwgLMyQeqpRxSrJaOjKiTEYbINm)
 def get_keyboard_input(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,cVDBwgLMyQeqpRxSrJaOjKiTEYbINF):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINz=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv
  kb=xbmc.Keyboard()
  kb.setHeading(cVDBwgLMyQeqpRxSrJaOjKiTEYbINF)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINz=kb.getText()
  return cVDBwgLMyQeqpRxSrJaOjKiTEYbINz
 def get_settings_menubookmark(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINt=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh if __addon__.getSetting('menu_bookmark')=='true' else cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk
  return(cVDBwgLMyQeqpRxSrJaOjKiTEYbINt)
 def get_settings_makebookmark(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH):
  return cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh if __addon__.getSetting('make_bookmark')=='true' else cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk
 def get_settings_select_info(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINU=[]
  if __addon__.getSetting('netflixyn')=='true':cVDBwgLMyQeqpRxSrJaOjKiTEYbINU.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':cVDBwgLMyQeqpRxSrJaOjKiTEYbINU.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':cVDBwgLMyQeqpRxSrJaOjKiTEYbINU.append('tving')
  if __addon__.getSetting('watchayn')=='true':cVDBwgLMyQeqpRxSrJaOjKiTEYbINU.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':cVDBwgLMyQeqpRxSrJaOjKiTEYbINU.append('coupang')
  return cVDBwgLMyQeqpRxSrJaOjKiTEYbINU
 def add_dir(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,label,sublabel='',img='',infoLabels=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv,isFolder=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh,params='',isLink=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk,ContextMenu=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINC='%s?%s'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH._addon_url,urllib.parse.urlencode(params))
  if sublabel:cVDBwgLMyQeqpRxSrJaOjKiTEYbINF='%s < %s >'%(label,sublabel)
  else: cVDBwgLMyQeqpRxSrJaOjKiTEYbINF=label
  if not img:img='DefaultFolder.png'
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINl=xbmcgui.ListItem(cVDBwgLMyQeqpRxSrJaOjKiTEYbINF)
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIuG(img)==cVDBwgLMyQeqpRxSrJaOjKiTEYbIus:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINl.setArt(img)
  else:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINl.setArt({'thumb':img,'poster':img})
  if infoLabels:cVDBwgLMyQeqpRxSrJaOjKiTEYbINl.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINl.setProperty('IsPlayable','true')
  if ContextMenu:cVDBwgLMyQeqpRxSrJaOjKiTEYbINl.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH._addon_handle,cVDBwgLMyQeqpRxSrJaOjKiTEYbINC,cVDBwgLMyQeqpRxSrJaOjKiTEYbINl,isFolder)
 def Load_Searched_List(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH):
  try:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINo=cVDBwgLMyQeqpRxSrJaOjKiTEYbINP
   fp=cVDBwgLMyQeqpRxSrJaOjKiTEYbIum(cVDBwgLMyQeqpRxSrJaOjKiTEYbINo,'r',-1,'utf-8')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINf=fp.readlines()
   fp.close()
  except:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINf=[]
  return cVDBwgLMyQeqpRxSrJaOjKiTEYbINf
 def Save_Searched_List(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm):
  try:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINo=cVDBwgLMyQeqpRxSrJaOjKiTEYbINP
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINd=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.Load_Searched_List() 
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXN={'skey':cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm.strip()}
   fp=cVDBwgLMyQeqpRxSrJaOjKiTEYbIum(cVDBwgLMyQeqpRxSrJaOjKiTEYbINo,'w',-1,'utf-8')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXW=urllib.parse.urlencode(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXN)
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXW=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXW+'\n'
   fp.write(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXW)
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXA=0
   for cVDBwgLMyQeqpRxSrJaOjKiTEYbIXu in cVDBwgLMyQeqpRxSrJaOjKiTEYbINd:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIXP=cVDBwgLMyQeqpRxSrJaOjKiTEYbIus(urllib.parse.parse_qsl(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXu))
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIXH=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXN.get('skey').strip()
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIXn=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXP.get('skey').strip()
    if cVDBwgLMyQeqpRxSrJaOjKiTEYbIXH!=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXn:
     fp.write(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXu)
     cVDBwgLMyQeqpRxSrJaOjKiTEYbIXA+=1
     if cVDBwgLMyQeqpRxSrJaOjKiTEYbIXA>=50:break
   fp.close()
  except:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv
 def dp_Search_History(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,args):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIXv=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.Load_Searched_List()
  for cVDBwgLMyQeqpRxSrJaOjKiTEYbIXh in cVDBwgLMyQeqpRxSrJaOjKiTEYbIXv:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXk=cVDBwgLMyQeqpRxSrJaOjKiTEYbIus(urllib.parse.parse_qsl(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXh))
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXG=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXk.get('skey').strip()
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs={'mode':'TOTAL_SEARCH','search_key':cVDBwgLMyQeqpRxSrJaOjKiTEYbIXG,}
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXm={'mode':'HISTORY_REMOVE','skey':cVDBwgLMyQeqpRxSrJaOjKiTEYbIXG,'delmode':'ONE',}
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXz=urllib.parse.urlencode(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXm)
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXt=[('선택된 검색어 ( %s ) 삭제'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXG),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXz))]
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.add_dir(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXG,sublabel='',img=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv,infoLabels=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv,isFolder=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh,params=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs,ContextMenu=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXt)
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIXC={'plot':'검색목록 전체를 삭제합니다.'}
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINF='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIXF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.add_dir(cVDBwgLMyQeqpRxSrJaOjKiTEYbINF,sublabel='',img=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXF,infoLabels=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXC,isFolder=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk,params=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs,isLink=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh)
  xbmcplugin.endOfDirectory(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH._addon_handle,cacheToDisc=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk)
 def Delete_History_List(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,cVDBwgLMyQeqpRxSrJaOjKiTEYbIXG,cVDBwgLMyQeqpRxSrJaOjKiTEYbIXf):
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIXf=='ALL':
   try:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbINo=cVDBwgLMyQeqpRxSrJaOjKiTEYbINP
    fp=cVDBwgLMyQeqpRxSrJaOjKiTEYbIum(cVDBwgLMyQeqpRxSrJaOjKiTEYbINo,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv
  else:
   try:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbINo=cVDBwgLMyQeqpRxSrJaOjKiTEYbINP
    cVDBwgLMyQeqpRxSrJaOjKiTEYbINd=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.Load_Searched_List() 
    fp=cVDBwgLMyQeqpRxSrJaOjKiTEYbIum(cVDBwgLMyQeqpRxSrJaOjKiTEYbINo,'w',-1,'utf-8')
    for cVDBwgLMyQeqpRxSrJaOjKiTEYbIXu in cVDBwgLMyQeqpRxSrJaOjKiTEYbINd:
     cVDBwgLMyQeqpRxSrJaOjKiTEYbIXP=cVDBwgLMyQeqpRxSrJaOjKiTEYbIus(urllib.parse.parse_qsl(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXu))
     cVDBwgLMyQeqpRxSrJaOjKiTEYbIXo=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXP.get('skey').strip()
     if cVDBwgLMyQeqpRxSrJaOjKiTEYbIXG!=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXo:
      fp.write(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXu)
    fp.close()
   except:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv
 def dp_History_Delete(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,args):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIXG =args.get('skey') 
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIXf=args.get('delmode')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbING=xbmcgui.Dialog()
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIXf=='ALL':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXd=cVDBwgLMyQeqpRxSrJaOjKiTEYbING.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXd=cVDBwgLMyQeqpRxSrJaOjKiTEYbING.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIXd==cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk:sys.exit()
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.Delete_History_List(cVDBwgLMyQeqpRxSrJaOjKiTEYbIXG,cVDBwgLMyQeqpRxSrJaOjKiTEYbIXf)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINt=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.get_settings_menubookmark()
  for cVDBwgLMyQeqpRxSrJaOjKiTEYbIWN in cVDBwgLMyQeqpRxSrJaOjKiTEYbINW:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINF=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWN.get('title')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXF=''
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIWN.get('mode')=='MENU_BOOKMARK' and cVDBwgLMyQeqpRxSrJaOjKiTEYbINt==cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk:continue
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs={'mode':cVDBwgLMyQeqpRxSrJaOjKiTEYbIWN.get('mode')}
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIWN.get('mode')in['XXX','MENU_BOOKMARK']:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWX=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWA =cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh
   else:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWX=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWA =cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk
   if 'icon' in cVDBwgLMyQeqpRxSrJaOjKiTEYbIWN:cVDBwgLMyQeqpRxSrJaOjKiTEYbIXF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',cVDBwgLMyQeqpRxSrJaOjKiTEYbIWN.get('icon')) 
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.add_dir(cVDBwgLMyQeqpRxSrJaOjKiTEYbINF,sublabel='',img=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXF,infoLabels=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv,isFolder=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWX,params=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs,isLink=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWA)
  xbmcplugin.endOfDirectory(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH._addon_handle,cacheToDisc=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk)
 def option_check(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINU=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.get_settings_select_info()
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIuz(cVDBwgLMyQeqpRxSrJaOjKiTEYbINU)==0:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbING=xbmcgui.Dialog()
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXd=cVDBwgLMyQeqpRxSrJaOjKiTEYbING.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIXd==cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in cVDBwgLMyQeqpRxSrJaOjKiTEYbINU:
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.NF_cookiefile_check()==cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.NF_login(showMessage=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh)
 def NF_cookiefile_check(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWP={}
  try: 
   fp=cVDBwgLMyQeqpRxSrJaOjKiTEYbIum(cVDBwgLMyQeqpRxSrJaOjKiTEYbINu,'r',-1,'utf-8')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIWP= json.load(fp)
   fp.close()
  except cVDBwgLMyQeqpRxSrJaOjKiTEYbIut as exception:
   return cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWP
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWH=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF_CookieFile_Load(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF_ORIGINAL_COOKIE)
  if(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWH['NetflixId']!=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF['COOKIES']['NetflixId']or cVDBwgLMyQeqpRxSrJaOjKiTEYbIWH['SecureNetflixId']!=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF['COOKIES']['SecureNetflixId']or cVDBwgLMyQeqpRxSrJaOjKiTEYbIWH['flwssn']!=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF['COOKIES']['flwssn']or cVDBwgLMyQeqpRxSrJaOjKiTEYbIWH['memclid']!=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF['COOKIES']['memclid']or cVDBwgLMyQeqpRxSrJaOjKiTEYbIWH['nfvdid']!=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF['COOKIES']['nfvdid']):
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.Init_NF_Total()
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.NF_login(showMessage=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk)==cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk:
    return cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk
  return cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh
 def NF_login(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,showMessage=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh):
  if showMessage:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbING=xbmcgui.Dialog()
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXd=cVDBwgLMyQeqpRxSrJaOjKiTEYbING.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIXd==cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk:
    return cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk 
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF['COOKIES']=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF_CookieFile_Load(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF_ORIGINAL_COOKIE)
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWn=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk if cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF['COOKIES']=={}else cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIWn:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_log('pass1 ok!')
  else:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_log('pass1 error!')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_noti(__language__(30905).encode('utf-8'))
   return cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk 
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWn=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF_Get_BaseSession()
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIWn:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_log('pass2 ok!')
  else:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_log('pass2 error!')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_noti(__language__(30905).encode('utf-8'))
   return cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk 
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWv =cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.Get_Now_Datetime()
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF['SESSION']['limitdate']=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWv.strftime('%Y-%m-%d')
  try: 
   fp=cVDBwgLMyQeqpRxSrJaOjKiTEYbIum(cVDBwgLMyQeqpRxSrJaOjKiTEYbINu,'w',-1,'utf-8')
   json.dump(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF,fp,indent=4,ensure_ascii=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk)
   fp.close()
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_log('pass3 save ok!')
  except cVDBwgLMyQeqpRxSrJaOjKiTEYbIut as exception:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_log('pass3 save error!')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_noti(__language__(30905).encode('utf-8'))
   return cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk
  if showMessage:cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_noti(__language__(30904).encode('utf-8'))
  return cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh
 def NF_logout(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbING=xbmcgui.Dialog()
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIXd=cVDBwgLMyQeqpRxSrJaOjKiTEYbING.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIXd==cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk:return 
  if os.path.isfile(cVDBwgLMyQeqpRxSrJaOjKiTEYbINu):os.remove(cVDBwgLMyQeqpRxSrJaOjKiTEYbINu)
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWk=''
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWG=7
  try:
   for i in cVDBwgLMyQeqpRxSrJaOjKiTEYbIuU(cVDBwgLMyQeqpRxSrJaOjKiTEYbIuz(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz)):
    if i>=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWG:
     cVDBwgLMyQeqpRxSrJaOjKiTEYbIWk=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWk+'...'
     break
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWk=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWk+cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz[i]['title']+'\n'
  except:
   return ''
  return cVDBwgLMyQeqpRxSrJaOjKiTEYbIWk
 def dp_Search_Group(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,args):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINU =cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.get_settings_select_info()
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWs=[]
  if 'search_key' in args:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm=args.get('search_key')
  else:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm:
    return
  if 'wavve' in cVDBwgLMyQeqpRxSrJaOjKiTEYbINU:
   (cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWt)=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.Get_Search_Wavve(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,'TVSHOW',1)
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIuz(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz)>0:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU={'sType':'wavve_tvshow','sList':cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.MakeText_FreeList(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz),}
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWs.append(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU)
   (cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWt)=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.Get_Search_Wavve(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,'MOVIE',1)
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIuz(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz)>0:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU={'sType':'wavve_movie','sList':cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.MakeText_FreeList(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz),}
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWs.append(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU)
  if 'tving' in cVDBwgLMyQeqpRxSrJaOjKiTEYbINU:
   (cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWt)=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.Get_Search_Tving(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,'TVSHOW',1)
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIuz(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz)>0:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU={'sType':'tving_tvshow','sList':cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.MakeText_FreeList(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz),}
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWs.append(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU)
   (cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWt)=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.Get_Search_Tving(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,'MOVIE',1)
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIuz(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz)>0:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU={'sType':'tving_movie','sList':cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.MakeText_FreeList(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz),}
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWs.append(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU)
  if 'watcha' in cVDBwgLMyQeqpRxSrJaOjKiTEYbINU:
   (cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWt)=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.Get_Search_Watcha(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,1)
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIuz(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz)>0:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU={'sType':'watcha_list','sList':cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.MakeText_FreeList(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz),}
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWs.append(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU)
  if 'coupang' in cVDBwgLMyQeqpRxSrJaOjKiTEYbINU:
   (cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWt)=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.Get_Search_Coupang(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,1)
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIuz(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz)>0:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU={'sType':'coupang_list','sList':cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.MakeText_FreeList(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz),}
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWs.append(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU)
  if 'netflix' in cVDBwgLMyQeqpRxSrJaOjKiTEYbINU:
   try:
    (cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWt,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWC)=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.Get_Search_Netflix(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,1)
   except:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz=[]
    cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_noti(__language__(30919).encode('utf8'))
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIuz(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz)>0:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU={'sType':'netflix_list','sList':cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.MakeText_FreeList(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz),}
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIWs.append(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWU)
  for cVDBwgLMyQeqpRxSrJaOjKiTEYbIWF in cVDBwgLMyQeqpRxSrJaOjKiTEYbIWs:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIWl=cVDBwgLMyQeqpRxSrJaOjKiTEYbINA[cVDBwgLMyQeqpRxSrJaOjKiTEYbIWF.get('sType')]
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIWo={'plot':'검색어 : '+cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm+'\n\n'+cVDBwgLMyQeqpRxSrJaOjKiTEYbIWF.get('sList')}
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINF=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWl.get('title')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs={'mode':cVDBwgLMyQeqpRxSrJaOjKiTEYbIWl.get('mode'),'ott':cVDBwgLMyQeqpRxSrJaOjKiTEYbIWl.get('ott'),'vidtype':cVDBwgLMyQeqpRxSrJaOjKiTEYbIWl.get('vidtype'),'search_key':cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm}
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIWl.get('ott')=='netflix':
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs['page'] ='1'
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs['byReference']='-'
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',cVDBwgLMyQeqpRxSrJaOjKiTEYbIWl.get('icon'))
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIWX=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh if cVDBwgLMyQeqpRxSrJaOjKiTEYbIWl.get('mode')!='HYPER_LINK' else cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.add_dir(cVDBwgLMyQeqpRxSrJaOjKiTEYbINF,sublabel='',img=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXF,infoLabels=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWo,isFolder=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWX,params=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs,isLink=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh)
  xbmcplugin.endOfDirectory(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH._addon_handle)
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.Save_Searched_List(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm)
 def dp_Hyper_Link(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,args):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf =args.get('mode')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWd =args.get('ott')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIAN =args.get('vidtype')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm=args.get('search_key')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIAX='-'
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIWd=='wavve':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAW={'mode':'LOCAL_SEARCH','sType':'movie' if cVDBwgLMyQeqpRxSrJaOjKiTEYbIAN=='MOVIE' else 'vod','search_key':cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,'page':'1',}
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAu=urllib.parse.urlencode(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAW)
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAX='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAu)
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWd=='tving':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAW={'mode':'LOCAL_SEARCH','stype':'movie' if cVDBwgLMyQeqpRxSrJaOjKiTEYbIAN=='MOVIE' else 'vod','search_key':cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,'page':'1',}
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAu=urllib.parse.urlencode(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAW)
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAX='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAu)
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWd=='watcha':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAW={'mode':'LOCAL_SEARCH','search_key':cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,'page':'1',}
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAu=urllib.parse.urlencode(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAW)
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAX='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAu)
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWd=='coupang':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAW={'mode':'LOCAL_SEARCH','search_key':cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,'page':'1',}
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAu=urllib.parse.urlencode(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAW)
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAX='ActivateWindow(10025,"plugin://plugin.video.coupangm/?%s",return)'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAu)
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWd=='netflix':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAP=args.get('videoid')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAH=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.NF['SESSION']['nowGuid']
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIAN=='TVSHOW':
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIAX='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAP)
   else:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIAX='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAP,cVDBwgLMyQeqpRxSrJaOjKiTEYbIAH)
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.addon_log('ott_url ==> ( '+cVDBwgLMyQeqpRxSrJaOjKiTEYbIAX+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAX)
 def dp_Nf_Search(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,args):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIAn =cVDBwgLMyQeqpRxSrJaOjKiTEYbIuC(args.get('page'))
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm =args.get('search_key')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWC=args.get('byReference')
  (cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWt,cVDBwgLMyQeqpRxSrJaOjKiTEYbIWC)=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.SearchObj.Get_Search_Netflix(cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm,cVDBwgLMyQeqpRxSrJaOjKiTEYbIAn,byReference=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWC)
  for cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv in cVDBwgLMyQeqpRxSrJaOjKiTEYbIWz:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAP =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('videoid')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAN =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('vidtype')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINF =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('title')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAh =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('mpaa')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAk =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('regularSynopsis')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAG =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('dpSupplemental')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAs=cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('sequiturEvidence')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAm =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('thumbnail')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAz =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('year')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAt =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('duration')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAU =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('info_genre')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAC =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('director')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAF =cVDBwgLMyQeqpRxSrJaOjKiTEYbIAv.get('cast')
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIAN=='movie':
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIXU=' (%s)'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbIuF(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAz))
   else:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIXU=''
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAl=''
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIAk:cVDBwgLMyQeqpRxSrJaOjKiTEYbIAl=cVDBwgLMyQeqpRxSrJaOjKiTEYbIAl+'\n\n'+cVDBwgLMyQeqpRxSrJaOjKiTEYbIAk
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIAG :cVDBwgLMyQeqpRxSrJaOjKiTEYbIAl=cVDBwgLMyQeqpRxSrJaOjKiTEYbIAl+'\n\n'+cVDBwgLMyQeqpRxSrJaOjKiTEYbIAG
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbIAs:cVDBwgLMyQeqpRxSrJaOjKiTEYbIAl=cVDBwgLMyQeqpRxSrJaOjKiTEYbIAl+'\n\n'+cVDBwgLMyQeqpRxSrJaOjKiTEYbIAs
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIAl=cVDBwgLMyQeqpRxSrJaOjKiTEYbIAl.strip()
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXC={'mediatype':'tvshow' if cVDBwgLMyQeqpRxSrJaOjKiTEYbIAN=='show' else 'movie','title':cVDBwgLMyQeqpRxSrJaOjKiTEYbINF,'mpaa':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAh,'plot':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAl,'duration':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAt,'genre':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAU,'director':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAC,'cast':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAF,'year':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAz,}
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if cVDBwgLMyQeqpRxSrJaOjKiTEYbIAN=='show' else 'MOVIE','videoid':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAP,}
   if cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.get_settings_makebookmark():
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIAo={'videoid':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAP,'vidtype':'tvshow' if cVDBwgLMyQeqpRxSrJaOjKiTEYbIAN=='show' else 'movie','vtitle':cVDBwgLMyQeqpRxSrJaOjKiTEYbINF+cVDBwgLMyQeqpRxSrJaOjKiTEYbIXU,'vsubtitle':'','vinfo':cVDBwgLMyQeqpRxSrJaOjKiTEYbIXC,'thumbnail':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAm,}
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIAf=json.dumps(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAo)
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIAf=urllib.parse.quote(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAf)
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIAd='RunPlugin(plugin://plugin.video.searchm/?mode=SET_BOOKMARK&bm_param=%s)'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAf)
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIXt=[('(통합) 찜 영상에 추가',cVDBwgLMyQeqpRxSrJaOjKiTEYbIAd)]
   else:
    cVDBwgLMyQeqpRxSrJaOjKiTEYbIXt=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.add_dir(cVDBwgLMyQeqpRxSrJaOjKiTEYbINF+cVDBwgLMyQeqpRxSrJaOjKiTEYbIXU,sublabel=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv,img=cVDBwgLMyQeqpRxSrJaOjKiTEYbIAm,infoLabels=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXC,isFolder=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk,params=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs,isLink=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh,ContextMenu=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXt)
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIWt:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs={}
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs['mode'] ='NF_SEARCH' 
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs['page'] =cVDBwgLMyQeqpRxSrJaOjKiTEYbIuF(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAn+1)
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs['search_key']=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWm
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs['byReference']=cVDBwgLMyQeqpRxSrJaOjKiTEYbIWC
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINF='[B]%s >>[/B]'%'다음 페이지'
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIuN=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuF(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAn+1)
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIXF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.add_dir(cVDBwgLMyQeqpRxSrJaOjKiTEYbINF,sublabel=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuN,img=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXF,infoLabels=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv,isFolder=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh,params=cVDBwgLMyQeqpRxSrJaOjKiTEYbIXs)
  xbmcplugin.setContent(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH._addon_handle,'movies')
  xbmcplugin.endOfDirectory(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH._addon_handle)
 def dp_Bookmark_Menu(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,args):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIAX='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAX)
 def dp_Set_Bookmark(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH,args):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIuX=urllib.parse.unquote(args.get('bm_param'))
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIuX=json.loads(cVDBwgLMyQeqpRxSrJaOjKiTEYbIuX)
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIAP =cVDBwgLMyQeqpRxSrJaOjKiTEYbIuX.get('videoid')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIAN =cVDBwgLMyQeqpRxSrJaOjKiTEYbIuX.get('vidtype')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIuW =cVDBwgLMyQeqpRxSrJaOjKiTEYbIuX.get('vtitle')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIuA =cVDBwgLMyQeqpRxSrJaOjKiTEYbIuX.get('vsubtitle')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIuP =cVDBwgLMyQeqpRxSrJaOjKiTEYbIuX.get('vinfo')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIAm =cVDBwgLMyQeqpRxSrJaOjKiTEYbIuX.get('thumbnail')
  cVDBwgLMyQeqpRxSrJaOjKiTEYbING=xbmcgui.Dialog()
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIXd=cVDBwgLMyQeqpRxSrJaOjKiTEYbING.yesno(__language__(30917).encode('utf8'),cVDBwgLMyQeqpRxSrJaOjKiTEYbIuW+' \n\n'+__language__(30918))
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIXd==cVDBwgLMyQeqpRxSrJaOjKiTEYbIuk:return
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIuH={'indexinfo':{'ott':'netflix','videoid':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAP,'vidtype':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAN,},'saveinfo':{'title':cVDBwgLMyQeqpRxSrJaOjKiTEYbIuW,'subtitle':cVDBwgLMyQeqpRxSrJaOjKiTEYbIuA,'thumbnail':cVDBwgLMyQeqpRxSrJaOjKiTEYbIAm,'infoLabels':cVDBwgLMyQeqpRxSrJaOjKiTEYbIuP,},}
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIAf=json.dumps(cVDBwgLMyQeqpRxSrJaOjKiTEYbIuH)
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIAf=urllib.parse.quote(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAf)
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIAd='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAf)
  xbmc.executebuiltin(cVDBwgLMyQeqpRxSrJaOjKiTEYbIAd)
 def search_main(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH):
  cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf=cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.main_params.get('mode',cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv)
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf=='NFLOGOUT':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.NF_logout()
   return
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf=='NFLOGIN':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.NF_login(showMessage=cVDBwgLMyQeqpRxSrJaOjKiTEYbIuh)
   return
  cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.option_check()
  if cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf is cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.dp_Main_List()
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf=='TOTAL_SEARCH':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.dp_Search_Group(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.main_params)
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf=='HYPER_LINK':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.dp_Hyper_Link(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.main_params)
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf=='NF_SEARCH':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.dp_Nf_Search(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.main_params)
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf=='TOTAL_HISTORY':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.dp_Search_History(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.main_params)
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf=='HISTORY_REMOVE':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.dp_History_Delete(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.main_params)
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf=='MENU_BOOKMARK':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.dp_Bookmark_Menu(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.main_params)
  elif cVDBwgLMyQeqpRxSrJaOjKiTEYbIWf=='SET_BOOKMARK':
   cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.dp_Set_Bookmark(cVDBwgLMyQeqpRxSrJaOjKiTEYbINH.main_params)
  else:
   cVDBwgLMyQeqpRxSrJaOjKiTEYbIuv
# Created by pyminifier (https://github.com/liftoff/pyminifier)
