__author__="NightRain"
MfiUVAkcLEaHzFelOCIvuhGSyjqxRB=object
MfiUVAkcLEaHzFelOCIvuhGSyjqxRw=None
MfiUVAkcLEaHzFelOCIvuhGSyjqxRo=False
MfiUVAkcLEaHzFelOCIvuhGSyjqxRg=int
MfiUVAkcLEaHzFelOCIvuhGSyjqxRP=str
MfiUVAkcLEaHzFelOCIvuhGSyjqxRm=Exception
MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ=print
MfiUVAkcLEaHzFelOCIvuhGSyjqxRn=True
MfiUVAkcLEaHzFelOCIvuhGSyjqxRd=len
MfiUVAkcLEaHzFelOCIvuhGSyjqxRt=open
MfiUVAkcLEaHzFelOCIvuhGSyjqxRQ=isinstance
MfiUVAkcLEaHzFelOCIvuhGSyjqxRW=list
MfiUVAkcLEaHzFelOCIvuhGSyjqxRp=dict
MfiUVAkcLEaHzFelOCIvuhGSyjqxRr=range
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
import pickle
import os
class MfiUVAkcLEaHzFelOCIvuhGSyjqxbs(MfiUVAkcLEaHzFelOCIvuhGSyjqxRB):
 def __init__(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.DEFAULT_HEADER ={'user-agent':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.USER_AGENT}
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_WAVVE ='https://apis.wavve.com'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_TVING_SEARCH='https://search.tving.com'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_TVING_IMG ='https://image.tving.com'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_WATCHA ='https://api-mars.watcha.com'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_NETFLIX ='https://www.netflix.com'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_COUPANG ='https://discover.coupangstreaming.com'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.WAVVE_LIMIT =20 
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.TVING_LIMIT =30
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.WATCHA_LIMIT =30
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_LIMIT =20 
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.COUPANG_LIMIT =10 
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.DERECTOR_LIMIT =4
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.CAST_LIMIT =10
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.GENRE_LIMIT =4
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.TVING_MOVIE_LITE=['2610061','2610161','261062']
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_HEADER={'user-agent':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND1 ='_342x192'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND2 ='_665x375'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_PORT ='_342x684'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LOGO ='_550x124'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF={}
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']={}
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']={}
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.CP_ORIGINAL_COOKIE =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_ORIGINAL_COOKIE =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_SESSION_COOKIES1 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_SESSION_COOKIES2 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_SESSION_COOKIES3 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_SESSION_COOKIES4 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_SESSION_FULLTEXT1 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_SESSION_FULLTEXT2 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_SESSION_FULLTEXT3 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_SESSION_FULLTEXT4 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_CONTEXTJSON_FILE1 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_CONTEXTJSON_FILE2 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_CONTEXTJSON_FILE3 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_CONTEXTJSON_FILE4 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_FALCORJSON_FILE1 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_FALCORJSON_FILE2 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_FALCORJSON_FILE3 =''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_FALCORJSON_FILE4 =''
 def callRequestCookies(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,jobtype,MfiUVAkcLEaHzFelOCIvuhGSyjqxbo,payload=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,params=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,headers=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,cookies=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,redirects=MfiUVAkcLEaHzFelOCIvuhGSyjqxRo):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbK=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.DEFAULT_HEADER
  if headers:MfiUVAkcLEaHzFelOCIvuhGSyjqxbK.update(headers)
  if jobtype=='Get':
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbR=requests.get(MfiUVAkcLEaHzFelOCIvuhGSyjqxbo,params=params,headers=MfiUVAkcLEaHzFelOCIvuhGSyjqxbK,cookies=cookies,allow_redirects=redirects)
  else:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbR=requests.post(MfiUVAkcLEaHzFelOCIvuhGSyjqxbo,data=payload,params=params,headers=MfiUVAkcLEaHzFelOCIvuhGSyjqxbK,cookies=cookies,allow_redirects=redirects)
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxbR
 def GetNoCache(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,timetype=1,minutes=0):
  if timetype==1:
   ts=MfiUVAkcLEaHzFelOCIvuhGSyjqxRg(time.time())
   mi=MfiUVAkcLEaHzFelOCIvuhGSyjqxRg(minutes*60)
  else:
   ts=MfiUVAkcLEaHzFelOCIvuhGSyjqxRg(time.time()*1000)
   mi=MfiUVAkcLEaHzFelOCIvuhGSyjqxRg(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,search_key,sType,page_int):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbY=[]
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbB=MfiUVAkcLEaHzFelOCIvuhGSyjqxbD=1
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbw=MfiUVAkcLEaHzFelOCIvuhGSyjqxRo
  try:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbo=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_WAVVE+'/cf/search/list.js'
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbg={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':MfiUVAkcLEaHzFelOCIvuhGSyjqxRP((page_int-1)*MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.WAVVE_LIMIT),'limit':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.WAVVE_LIMIT,'orderby':'score'}
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbg.update(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.WAVVE_PARAMS)
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbP=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.callRequestCookies('Get',MfiUVAkcLEaHzFelOCIvuhGSyjqxbo,payload=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,params=MfiUVAkcLEaHzFelOCIvuhGSyjqxbg,headers=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,cookies=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw)
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbm=json.loads(MfiUVAkcLEaHzFelOCIvuhGSyjqxbP.text)
   if not('celllist' in MfiUVAkcLEaHzFelOCIvuhGSyjqxbm['cell_toplist']):return MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbJ=MfiUVAkcLEaHzFelOCIvuhGSyjqxbm['cell_toplist']['celllist']
   for MfiUVAkcLEaHzFelOCIvuhGSyjqxbn in MfiUVAkcLEaHzFelOCIvuhGSyjqxbJ:
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbd =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['event_list'][1]['url']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbt=urllib.parse.urlsplit(MfiUVAkcLEaHzFelOCIvuhGSyjqxbd).query
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbQ=MfiUVAkcLEaHzFelOCIvuhGSyjqxbt[0:MfiUVAkcLEaHzFelOCIvuhGSyjqxbt.find('=')]
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbW=MfiUVAkcLEaHzFelOCIvuhGSyjqxbt[MfiUVAkcLEaHzFelOCIvuhGSyjqxbt.find('=')+1:]
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbQ='TVSHOW' if MfiUVAkcLEaHzFelOCIvuhGSyjqxbQ=='programid' else 'MOVIE' 
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbp=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['title_list'][0]['text']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbr =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['age']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbN={'title':MfiUVAkcLEaHzFelOCIvuhGSyjqxbp}
    if MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('age')!='21':
     MfiUVAkcLEaHzFelOCIvuhGSyjqxbY.append(MfiUVAkcLEaHzFelOCIvuhGSyjqxbN)
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbB=MfiUVAkcLEaHzFelOCIvuhGSyjqxRg(MfiUVAkcLEaHzFelOCIvuhGSyjqxbm['cell_toplist']['pagecount'])
   if MfiUVAkcLEaHzFelOCIvuhGSyjqxbm['cell_toplist']['count']:MfiUVAkcLEaHzFelOCIvuhGSyjqxbD =MfiUVAkcLEaHzFelOCIvuhGSyjqxRg(MfiUVAkcLEaHzFelOCIvuhGSyjqxbm['cell_toplist']['count'])
   else:MfiUVAkcLEaHzFelOCIvuhGSyjqxbD=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.LIST_LIMIT
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbw=MfiUVAkcLEaHzFelOCIvuhGSyjqxbB>MfiUVAkcLEaHzFelOCIvuhGSyjqxbD
  except MfiUVAkcLEaHzFelOCIvuhGSyjqxRm as exception:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ(exception)
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw 
 def Get_Search_Tving(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,search_key,sType,page_int):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbY=[]
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbw=MfiUVAkcLEaHzFelOCIvuhGSyjqxRo
  try:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxsb ='/search/getSearch.jsp'
   MfiUVAkcLEaHzFelOCIvuhGSyjqxsT={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(page_int),'pageSize':MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.TVING_PARMAS.get('SCREENCODE'),'os':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.TVING_PARMAS.get('OSCODE'),'network':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.GetNoCache(2))}
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbo=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_TVING_SEARCH+MfiUVAkcLEaHzFelOCIvuhGSyjqxsb
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbP=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.callRequestCookies('Get',MfiUVAkcLEaHzFelOCIvuhGSyjqxbo,payload=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,params=MfiUVAkcLEaHzFelOCIvuhGSyjqxsT,headers=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,cookies=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw)
   MfiUVAkcLEaHzFelOCIvuhGSyjqxsK=json.loads(MfiUVAkcLEaHzFelOCIvuhGSyjqxbP.text)
   if sType=='TVSHOW':
    if not('programRsb' in MfiUVAkcLEaHzFelOCIvuhGSyjqxsK):return MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsR=MfiUVAkcLEaHzFelOCIvuhGSyjqxsK['programRsb']['dataList']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsX =MfiUVAkcLEaHzFelOCIvuhGSyjqxRg(MfiUVAkcLEaHzFelOCIvuhGSyjqxsK['programRsb']['count'])
    for MfiUVAkcLEaHzFelOCIvuhGSyjqxbn in MfiUVAkcLEaHzFelOCIvuhGSyjqxsR:
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsY=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['mast_cd']
     MfiUVAkcLEaHzFelOCIvuhGSyjqxbp =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['mast_nm']
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsB=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_TVING_IMG+MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['web_url4']
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsw =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_TVING_IMG+MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['web_url']
     try:
      MfiUVAkcLEaHzFelOCIvuhGSyjqxso =[]
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsg=[]
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsP =[]
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsm =0
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsJ =''
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsn =''
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsd =''
      if MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('actor') !='' and MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('actor') !='-':MfiUVAkcLEaHzFelOCIvuhGSyjqxso =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('actor').split(',')
      if MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('director')!='' and MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('director')!='-':MfiUVAkcLEaHzFelOCIvuhGSyjqxsg=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('director').split(',')
      if MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('cate_nm')!='' and MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('cate_nm')!='-':MfiUVAkcLEaHzFelOCIvuhGSyjqxsP =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('cate_nm').split('/')
      if 'targetage' in MfiUVAkcLEaHzFelOCIvuhGSyjqxbn:MfiUVAkcLEaHzFelOCIvuhGSyjqxsJ=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('targetage')
      if 'broad_dt' in MfiUVAkcLEaHzFelOCIvuhGSyjqxbn:
       MfiUVAkcLEaHzFelOCIvuhGSyjqxst=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('broad_dt')
       MfiUVAkcLEaHzFelOCIvuhGSyjqxsd='%s-%s-%s'%(MfiUVAkcLEaHzFelOCIvuhGSyjqxst[:4],MfiUVAkcLEaHzFelOCIvuhGSyjqxst[4:6],MfiUVAkcLEaHzFelOCIvuhGSyjqxst[6:])
       MfiUVAkcLEaHzFelOCIvuhGSyjqxsn =MfiUVAkcLEaHzFelOCIvuhGSyjqxst[:4]
     except:
      MfiUVAkcLEaHzFelOCIvuhGSyjqxRw
     MfiUVAkcLEaHzFelOCIvuhGSyjqxbN={'title':MfiUVAkcLEaHzFelOCIvuhGSyjqxbp,}
     MfiUVAkcLEaHzFelOCIvuhGSyjqxbY.append(MfiUVAkcLEaHzFelOCIvuhGSyjqxbN)
   else:
    if not('vodMVRsb' in MfiUVAkcLEaHzFelOCIvuhGSyjqxsK):return MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsQ=MfiUVAkcLEaHzFelOCIvuhGSyjqxsK['vodMVRsb']['dataList']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsX =MfiUVAkcLEaHzFelOCIvuhGSyjqxRg(MfiUVAkcLEaHzFelOCIvuhGSyjqxsK['vodMVRsb']['count'])
    MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ(MfiUVAkcLEaHzFelOCIvuhGSyjqxsX)
    for MfiUVAkcLEaHzFelOCIvuhGSyjqxbn in MfiUVAkcLEaHzFelOCIvuhGSyjqxsQ:
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsY=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['mast_cd']
     MfiUVAkcLEaHzFelOCIvuhGSyjqxbp =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['mast_nm'].strip()
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsB =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_TVING_IMG+MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['web_url']
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsw =MfiUVAkcLEaHzFelOCIvuhGSyjqxsB
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsW=''
     try:
      MfiUVAkcLEaHzFelOCIvuhGSyjqxso =[]
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsg=[]
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsP =[]
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsm =0
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsJ =''
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsn =''
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsd =''
      if MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('actor') !='' and MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('actor') !='-':MfiUVAkcLEaHzFelOCIvuhGSyjqxso =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('actor').split(',')
      if MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('director')!='' and MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('director')!='-':MfiUVAkcLEaHzFelOCIvuhGSyjqxsg=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('director').split(',')
      if MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('cate_nm')!='' and MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('cate_nm')!='-':MfiUVAkcLEaHzFelOCIvuhGSyjqxsP =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('cate_nm').split('/')
      if MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('runtime_sec')!='':MfiUVAkcLEaHzFelOCIvuhGSyjqxsm=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('runtime_sec')
      if 'grade_nm' in MfiUVAkcLEaHzFelOCIvuhGSyjqxbn:MfiUVAkcLEaHzFelOCIvuhGSyjqxsJ=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('grade_nm')
      MfiUVAkcLEaHzFelOCIvuhGSyjqxsp=''
      MfiUVAkcLEaHzFelOCIvuhGSyjqxst=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('broad_dt')
      if MfiUVAkcLEaHzFelOCIvuhGSyjqxsp!='':
       MfiUVAkcLEaHzFelOCIvuhGSyjqxsd='%s-%s-%s'%(MfiUVAkcLEaHzFelOCIvuhGSyjqxst[:4],MfiUVAkcLEaHzFelOCIvuhGSyjqxst[4:6],MfiUVAkcLEaHzFelOCIvuhGSyjqxst[6:])
       MfiUVAkcLEaHzFelOCIvuhGSyjqxsn =MfiUVAkcLEaHzFelOCIvuhGSyjqxst[:4]
     except:
      MfiUVAkcLEaHzFelOCIvuhGSyjqxRw
     MfiUVAkcLEaHzFelOCIvuhGSyjqxbN={'title':MfiUVAkcLEaHzFelOCIvuhGSyjqxbp,}
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsr=MfiUVAkcLEaHzFelOCIvuhGSyjqxRo
     for MfiUVAkcLEaHzFelOCIvuhGSyjqxsN in MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['bill']:
      if MfiUVAkcLEaHzFelOCIvuhGSyjqxsN in MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.TVING_MOVIE_LITE:
       MfiUVAkcLEaHzFelOCIvuhGSyjqxsr=MfiUVAkcLEaHzFelOCIvuhGSyjqxRn
       break
     if MfiUVAkcLEaHzFelOCIvuhGSyjqxsr==MfiUVAkcLEaHzFelOCIvuhGSyjqxRo: 
      MfiUVAkcLEaHzFelOCIvuhGSyjqxbN['title']=MfiUVAkcLEaHzFelOCIvuhGSyjqxbN['title']+' [개별구매]'
     MfiUVAkcLEaHzFelOCIvuhGSyjqxbY.append(MfiUVAkcLEaHzFelOCIvuhGSyjqxbN)
   if MfiUVAkcLEaHzFelOCIvuhGSyjqxsX>(page_int*MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.TVING_LIMIT):MfiUVAkcLEaHzFelOCIvuhGSyjqxbw=MfiUVAkcLEaHzFelOCIvuhGSyjqxRn
  except MfiUVAkcLEaHzFelOCIvuhGSyjqxRm as exception:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ(exception)
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw
 def Get_Search_Watcha(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,search_key,page_int):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbY=[]
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbw=MfiUVAkcLEaHzFelOCIvuhGSyjqxRo
  try:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbo=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_WATCHA+'/api/search.json'
   MfiUVAkcLEaHzFelOCIvuhGSyjqxsT={'query':search_key,'page':MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(page_int),'per':MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.WATCHA_LIMIT),'exclude':'limited',}
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbP=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.callRequestCookies('Get',MfiUVAkcLEaHzFelOCIvuhGSyjqxbo,payload=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,params=MfiUVAkcLEaHzFelOCIvuhGSyjqxsT,headers=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.WATCHA_HEADER,cookies=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw)
   MfiUVAkcLEaHzFelOCIvuhGSyjqxsK=json.loads(MfiUVAkcLEaHzFelOCIvuhGSyjqxbP.text)
   if not('results' in MfiUVAkcLEaHzFelOCIvuhGSyjqxsK):return MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw
   MfiUVAkcLEaHzFelOCIvuhGSyjqxsD=MfiUVAkcLEaHzFelOCIvuhGSyjqxsK['results']
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbw=MfiUVAkcLEaHzFelOCIvuhGSyjqxsK['meta']['has_next']
   for MfiUVAkcLEaHzFelOCIvuhGSyjqxbn in MfiUVAkcLEaHzFelOCIvuhGSyjqxsD:
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTb =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['code']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTs=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['content_type']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTK =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['title']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTR =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['story']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsB=MfiUVAkcLEaHzFelOCIvuhGSyjqxsw=MfiUVAkcLEaHzFelOCIvuhGSyjqxKr=''
    if MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('poster') !=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw:MfiUVAkcLEaHzFelOCIvuhGSyjqxsB=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('poster').get('original')
    if MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('stillcut')!=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw:MfiUVAkcLEaHzFelOCIvuhGSyjqxsw =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('stillcut').get('large')
    if MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('thumbnail')!=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw:MfiUVAkcLEaHzFelOCIvuhGSyjqxKr=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('thumbnail').get('large')
    if MfiUVAkcLEaHzFelOCIvuhGSyjqxKr=='' :MfiUVAkcLEaHzFelOCIvuhGSyjqxKr=MfiUVAkcLEaHzFelOCIvuhGSyjqxsw
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTX={'thumb':MfiUVAkcLEaHzFelOCIvuhGSyjqxsw,'poster':MfiUVAkcLEaHzFelOCIvuhGSyjqxsB,'fanart':MfiUVAkcLEaHzFelOCIvuhGSyjqxKr}
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsn =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['year']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTY =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['film_rating_code']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTB=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['film_rating_short']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTw =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['film_rating_long']
    if MfiUVAkcLEaHzFelOCIvuhGSyjqxTs=='movies':
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsm =MfiUVAkcLEaHzFelOCIvuhGSyjqxbn['duration']
    else:
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsm ='0'
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbN={'title':MfiUVAkcLEaHzFelOCIvuhGSyjqxTK,}
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbY.append(MfiUVAkcLEaHzFelOCIvuhGSyjqxbN)
  except MfiUVAkcLEaHzFelOCIvuhGSyjqxRm as exception:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ(exception)
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw
 def Get_Search_Coupang(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,search_key,page_int):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbY=[]
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbw=MfiUVAkcLEaHzFelOCIvuhGSyjqxRo
  try:
   CP=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.jsonfile_To_dic(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.CP_ORIGINAL_COOKIE)
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbo=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_COUPANG+'/v2/search' 
   MfiUVAkcLEaHzFelOCIvuhGSyjqxsT={'query':search_key,'platform':'WEBCLIENT','page':MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(page_int),'perPage':MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.COUPANG_LIMIT),}
   MfiUVAkcLEaHzFelOCIvuhGSyjqxTo={'x-membersrl':CP['SESSION']['member_srl'],'x-pcid':CP['SESSION']['PCID'],'x-profileid':CP['SESSION']['profileId'],}
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbP=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.callRequestCookies('Get',MfiUVAkcLEaHzFelOCIvuhGSyjqxbo,payload=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,params=MfiUVAkcLEaHzFelOCIvuhGSyjqxsT,headers=MfiUVAkcLEaHzFelOCIvuhGSyjqxTo,cookies=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw)
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbm=json.loads(MfiUVAkcLEaHzFelOCIvuhGSyjqxbP.text)
   if MfiUVAkcLEaHzFelOCIvuhGSyjqxRd(MfiUVAkcLEaHzFelOCIvuhGSyjqxbm.get('data').get('data'))==0:return MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw
   for MfiUVAkcLEaHzFelOCIvuhGSyjqxbn in MfiUVAkcLEaHzFelOCIvuhGSyjqxbm.get('data').get('data'):
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbn=MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('data')
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbN={'title':MfiUVAkcLEaHzFelOCIvuhGSyjqxbn.get('title'),}
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbY.append(MfiUVAkcLEaHzFelOCIvuhGSyjqxbN)
   if MfiUVAkcLEaHzFelOCIvuhGSyjqxbm.get('pagination').get('totalPages')>page_int:
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbw=MfiUVAkcLEaHzFelOCIvuhGSyjqxRn
  except MfiUVAkcLEaHzFelOCIvuhGSyjqxRm as exception:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ(exception)
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw
 def dic_To_jsonfile(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,filename,MfiUVAkcLEaHzFelOCIvuhGSyjqxTg):
  if filename=='':return
  fp=MfiUVAkcLEaHzFelOCIvuhGSyjqxRt(filename,'w',-1,'utf-8')
  json.dump(MfiUVAkcLEaHzFelOCIvuhGSyjqxTg,fp,indent=4,ensure_ascii=MfiUVAkcLEaHzFelOCIvuhGSyjqxRo)
  fp.close()
 def jsonfile_To_dic(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,filename):
  if filename=='':return MfiUVAkcLEaHzFelOCIvuhGSyjqxRw
  try:
   fp=MfiUVAkcLEaHzFelOCIvuhGSyjqxRt(filename,'r',-1,'utf-8')
   MfiUVAkcLEaHzFelOCIvuhGSyjqxTm=json.load(fp)
   fp.close()
  except:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxTm={}
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxTm
 def tempFileSave(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,filename,resText):
  if filename=='':return
  fp=MfiUVAkcLEaHzFelOCIvuhGSyjqxRt(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,filename):
  if filename=='':return
  try:
   fp=MfiUVAkcLEaHzFelOCIvuhGSyjqxRt(filename,'r',-1,'utf-8')
   MfiUVAkcLEaHzFelOCIvuhGSyjqxTm=fp.read()
   fp.close()
  except:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxTm=''
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxTm
 def Init_NF_Total(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF={}
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']={}
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']={}
 def make_NF_XnetflixHeaders(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTo={'x-netflix.browsername':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['esnModel'],'x-netflix.esnprefix':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['nowGuid'],'x-netflix.uiversion':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxTo
 def make_NF_ApiParams(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbg={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'true','hasVideoMerchInJaw':'true','persoInfoDensity':'false','infoDensityToggle':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','usePreviewModal':'true','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['identifier']),}
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxbg
 def extract_json(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,content,name):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTJ=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTn=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTd=re.compile(MfiUVAkcLEaHzFelOCIvuhGSyjqxTJ.format(name),re.DOTALL).findall(content)
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTn=MfiUVAkcLEaHzFelOCIvuhGSyjqxTd[0]
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTt=MfiUVAkcLEaHzFelOCIvuhGSyjqxTn.replace('\\"','\\\\"') 
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTt=MfiUVAkcLEaHzFelOCIvuhGSyjqxTt.replace('\\s','\\\\s') 
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTt=MfiUVAkcLEaHzFelOCIvuhGSyjqxTt.replace('\\n','\\\\n') 
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTt=MfiUVAkcLEaHzFelOCIvuhGSyjqxTt.replace('\\t','\\\\t') 
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTt=MfiUVAkcLEaHzFelOCIvuhGSyjqxTt.encode().decode('unicode_escape') 
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTt=re.sub(r'\\(?!["])',r'\\\\',MfiUVAkcLEaHzFelOCIvuhGSyjqxTt) 
  return json.loads(MfiUVAkcLEaHzFelOCIvuhGSyjqxTt)
 def NF_makestr_paths(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,paths):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTm=[]
  if MfiUVAkcLEaHzFelOCIvuhGSyjqxRQ(paths,MfiUVAkcLEaHzFelOCIvuhGSyjqxRg):
   return '%d'%(paths)
  elif MfiUVAkcLEaHzFelOCIvuhGSyjqxRQ(paths,MfiUVAkcLEaHzFelOCIvuhGSyjqxRP):
   return '"%s"'%(paths)
  for MfiUVAkcLEaHzFelOCIvuhGSyjqxTQ in paths:
   if MfiUVAkcLEaHzFelOCIvuhGSyjqxRQ(MfiUVAkcLEaHzFelOCIvuhGSyjqxTQ,MfiUVAkcLEaHzFelOCIvuhGSyjqxRg):
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTm.append('%d'%(MfiUVAkcLEaHzFelOCIvuhGSyjqxTQ))
   elif MfiUVAkcLEaHzFelOCIvuhGSyjqxRQ(MfiUVAkcLEaHzFelOCIvuhGSyjqxTQ,MfiUVAkcLEaHzFelOCIvuhGSyjqxRP):
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTm.append('"%s"'%(MfiUVAkcLEaHzFelOCIvuhGSyjqxTQ))
   elif MfiUVAkcLEaHzFelOCIvuhGSyjqxRQ(MfiUVAkcLEaHzFelOCIvuhGSyjqxTQ,MfiUVAkcLEaHzFelOCIvuhGSyjqxRW):
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTm.append('[%s]'%(','.join(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_makestr_paths(MfiUVAkcLEaHzFelOCIvuhGSyjqxTQ))))
   elif MfiUVAkcLEaHzFelOCIvuhGSyjqxRQ(MfiUVAkcLEaHzFelOCIvuhGSyjqxTQ,MfiUVAkcLEaHzFelOCIvuhGSyjqxRp):
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTW=''
    for MfiUVAkcLEaHzFelOCIvuhGSyjqxTp,MfiUVAkcLEaHzFelOCIvuhGSyjqxTr in MfiUVAkcLEaHzFelOCIvuhGSyjqxTQ.items():
     MfiUVAkcLEaHzFelOCIvuhGSyjqxTW+='"%s":%s,'%(MfiUVAkcLEaHzFelOCIvuhGSyjqxTp,MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_makestr_paths(MfiUVAkcLEaHzFelOCIvuhGSyjqxTr))
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTm.append('{%s}'%(MfiUVAkcLEaHzFelOCIvuhGSyjqxTW[:-1]))
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxTm
 def NF_Call_pathapi(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,MfiUVAkcLEaHzFelOCIvuhGSyjqxKg,referer=''):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTN='%s/nq/website/memberapi/%s/pathEvaluator'%(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_NETFLIX,MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['identifier'])
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTD={'path':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_makestr_paths(MfiUVAkcLEaHzFelOCIvuhGSyjqxKg),'authURL':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']['authURL']}
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbg=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.make_NF_ApiParams()
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTo={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':MfiUVAkcLEaHzFelOCIvuhGSyjqxTo['referer']=referer
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKb=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.make_NF_XnetflixHeaders()
  MfiUVAkcLEaHzFelOCIvuhGSyjqxTo.update(MfiUVAkcLEaHzFelOCIvuhGSyjqxKb)
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKs=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_Get_DefaultCookies()
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKs['profilesNewSession']='0'
  try:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbP=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.callRequestCookies('Post',MfiUVAkcLEaHzFelOCIvuhGSyjqxTN,payload=MfiUVAkcLEaHzFelOCIvuhGSyjqxTD,params=MfiUVAkcLEaHzFelOCIvuhGSyjqxbg,headers=MfiUVAkcLEaHzFelOCIvuhGSyjqxTo,cookies=MfiUVAkcLEaHzFelOCIvuhGSyjqxKs)
   return MfiUVAkcLEaHzFelOCIvuhGSyjqxbP
  except MfiUVAkcLEaHzFelOCIvuhGSyjqxRm as exception:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ(exception)
   return MfiUVAkcLEaHzFelOCIvuhGSyjqxRw
 def Get_Search_Netflix(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,search_key,page_int,byReference=''):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKT=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.DERECTOR_LIMIT
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKR =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.CAST_LIMIT
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKX =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.GENRE_LIMIT
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKY =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_LIMIT*(page_int-1)
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKB =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_LIMIT*page_int 
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKw="|%s"%(search_key)
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKo ='%s/search?%s'%(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxKg=[["search","byTerm",MfiUVAkcLEaHzFelOCIvuhGSyjqxKw,"titles",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_LIMIT,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"summary"],["search","byTerm",MfiUVAkcLEaHzFelOCIvuhGSyjqxKw,"titles",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_LIMIT,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",MfiUVAkcLEaHzFelOCIvuhGSyjqxKw,"titles",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_LIMIT,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference","boxarts",[MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND2,MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_PORT],"jpg"],["search","byTerm",MfiUVAkcLEaHzFelOCIvuhGSyjqxKw,"titles",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_LIMIT,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference","interestingMoment",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND1,"jpg"],["search","byTerm",MfiUVAkcLEaHzFelOCIvuhGSyjqxKw,"titles",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_LIMIT,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference","storyArt",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND2,"jpg"],["search","byTerm",MfiUVAkcLEaHzFelOCIvuhGSyjqxKw,"titles",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_LIMIT,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference",["cast","creators","directors"],{"from":0,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKT},["id","name"]],["search","byTerm",MfiUVAkcLEaHzFelOCIvuhGSyjqxKw,"titles",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_LIMIT,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference","genres",{"from":0,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKX},["id","name"]],["search","byTerm",MfiUVAkcLEaHzFelOCIvuhGSyjqxKw,"titles",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NETFLIX_LIMIT,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LOGO,"png"],]
  else:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxKg=[["search","byReference",byReference,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"summary"],["search","byReference",byReference,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference","boxarts",[MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND2,MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference","interestingMoment",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference","storyArt",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference",["cast","creators","directors"],{"from":0,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKT},["id","name"]],["search","byReference",byReference,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference","genres",{"from":0,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKX},["id","name"]],["search","byReference",byReference,{"from":MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,"to":MfiUVAkcLEaHzFelOCIvuhGSyjqxKB},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LOGO,"png"],]
  try:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbP=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_Call_pathapi(MfiUVAkcLEaHzFelOCIvuhGSyjqxKg,MfiUVAkcLEaHzFelOCIvuhGSyjqxKo)
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbm=json.loads(MfiUVAkcLEaHzFelOCIvuhGSyjqxbP.text)
  except MfiUVAkcLEaHzFelOCIvuhGSyjqxRm as exception:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ(exception)
  (MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw,byReference)=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.Search_Netflix_Make(MfiUVAkcLEaHzFelOCIvuhGSyjqxbm)
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw,byReference
 def Search_Netflix_Make(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,jsonSource):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbY=[]
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbw =MfiUVAkcLEaHzFelOCIvuhGSyjqxRo
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKP=''
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKm=jsonSource.get('paths')[0][1]
  if MfiUVAkcLEaHzFelOCIvuhGSyjqxKm=='byTerm':
   MfiUVAkcLEaHzFelOCIvuhGSyjqxKY =jsonSource['paths'][0][5]['from']
   MfiUVAkcLEaHzFelOCIvuhGSyjqxKB =jsonSource['paths'][0][5]['to']
  else:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxKY =jsonSource['paths'][0][3]['from']
   MfiUVAkcLEaHzFelOCIvuhGSyjqxKB =jsonSource['paths'][0][3]['to']
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKP=MfiUVAkcLEaHzFelOCIvuhGSyjqxRW(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKJ=jsonSource.get('jsonGraph').get('search').get('byReference').get(MfiUVAkcLEaHzFelOCIvuhGSyjqxKP)
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKn =jsonSource.get('jsonGraph').get('videos')
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKd=jsonSource.get('jsonGraph').get('person')
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKt=jsonSource.get('jsonGraph').get('genres')
  MfiUVAkcLEaHzFelOCIvuhGSyjqxbw=MfiUVAkcLEaHzFelOCIvuhGSyjqxRn if MfiUVAkcLEaHzFelOCIvuhGSyjqxKJ[MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(MfiUVAkcLEaHzFelOCIvuhGSyjqxKB)]['reference']['$type']=='ref' else MfiUVAkcLEaHzFelOCIvuhGSyjqxRo
  for MfiUVAkcLEaHzFelOCIvuhGSyjqxKQ in MfiUVAkcLEaHzFelOCIvuhGSyjqxRr(MfiUVAkcLEaHzFelOCIvuhGSyjqxKY,MfiUVAkcLEaHzFelOCIvuhGSyjqxKB):
   if MfiUVAkcLEaHzFelOCIvuhGSyjqxKJ[MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(MfiUVAkcLEaHzFelOCIvuhGSyjqxKQ)]['reference']['$type']=='ref':
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbW =MfiUVAkcLEaHzFelOCIvuhGSyjqxKJ[MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(MfiUVAkcLEaHzFelOCIvuhGSyjqxKQ)]['reference']['value'][1]
    MfiUVAkcLEaHzFelOCIvuhGSyjqxKW=MfiUVAkcLEaHzFelOCIvuhGSyjqxKn[MfiUVAkcLEaHzFelOCIvuhGSyjqxbW]
    MfiUVAkcLEaHzFelOCIvuhGSyjqxTK =MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['title']['value']
    if MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['availability']['value']['isPlayable']==MfiUVAkcLEaHzFelOCIvuhGSyjqxRo:
     continue
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbQ =MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['summary']['value']['type']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsm =0 if MfiUVAkcLEaHzFelOCIvuhGSyjqxbQ!='movie' else MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['runtime']['value']
    if MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['sequiturEvidence']['value']['value']:
     MfiUVAkcLEaHzFelOCIvuhGSyjqxKp=MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['sequiturEvidence']['value']['value']['text']
    else:
     MfiUVAkcLEaHzFelOCIvuhGSyjqxKp=''
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsB =MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['boxarts'][MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_PORT]['jpg']['value']['url']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxKr =MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['boxarts'][MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND2]['jpg']['value']['url']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsw=''
    if 'value' in MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['storyArt'][MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND2]['jpg']:
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsw =MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['storyArt'][MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND2]['jpg']['value']['url']
    if MfiUVAkcLEaHzFelOCIvuhGSyjqxsw=='' and 'value' in MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['interestingMoment'][MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND1]['jpg']:
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsw =MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['interestingMoment'][MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LAND1]['jpg']['value']['url']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsW=''
    if 'value' in MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LOGO]['png']:
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsW=MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.ART_SIZE_LOGO]['png']['value']['url']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsP =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_Subid_List(MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['genres'])
    for i in MfiUVAkcLEaHzFelOCIvuhGSyjqxRr(MfiUVAkcLEaHzFelOCIvuhGSyjqxRd(MfiUVAkcLEaHzFelOCIvuhGSyjqxsP)):
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsP[i]=MfiUVAkcLEaHzFelOCIvuhGSyjqxKt[MfiUVAkcLEaHzFelOCIvuhGSyjqxsP[i]]['name']['value']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsg=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_Subid_List(MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['directors'])
    MfiUVAkcLEaHzFelOCIvuhGSyjqxKN =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_Subid_List(MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['creators'])
    MfiUVAkcLEaHzFelOCIvuhGSyjqxsg.extend(MfiUVAkcLEaHzFelOCIvuhGSyjqxKN)
    for i in MfiUVAkcLEaHzFelOCIvuhGSyjqxRr(MfiUVAkcLEaHzFelOCIvuhGSyjqxRd(MfiUVAkcLEaHzFelOCIvuhGSyjqxsg)):
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsg[i]=MfiUVAkcLEaHzFelOCIvuhGSyjqxKd[MfiUVAkcLEaHzFelOCIvuhGSyjqxsg[i]]['name']['value']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxso=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_Subid_List(MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['cast'])
    for i in MfiUVAkcLEaHzFelOCIvuhGSyjqxRr(MfiUVAkcLEaHzFelOCIvuhGSyjqxRd(MfiUVAkcLEaHzFelOCIvuhGSyjqxso)):
     MfiUVAkcLEaHzFelOCIvuhGSyjqxso[i]=MfiUVAkcLEaHzFelOCIvuhGSyjqxKd[MfiUVAkcLEaHzFelOCIvuhGSyjqxso[i]]['name']['value']
    if 'maturityDescription' in MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['maturity']['value']['rating']:
     MfiUVAkcLEaHzFelOCIvuhGSyjqxsJ=MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['maturity']['value']['rating']['maturityDescription']
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbN={'videoid':MfiUVAkcLEaHzFelOCIvuhGSyjqxbW,'vidtype':MfiUVAkcLEaHzFelOCIvuhGSyjqxbQ,'title':MfiUVAkcLEaHzFelOCIvuhGSyjqxTK,'mpaa':MfiUVAkcLEaHzFelOCIvuhGSyjqxsJ,'regularSynopsis':MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['regularSynopsis']['value'],'dpSupplemental':MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['dpSupplementalMessage']['value'],'sequiturEvidence':MfiUVAkcLEaHzFelOCIvuhGSyjqxKp,'thumbnail':{'poster':MfiUVAkcLEaHzFelOCIvuhGSyjqxsB,'thumb':MfiUVAkcLEaHzFelOCIvuhGSyjqxsw,'fanart':MfiUVAkcLEaHzFelOCIvuhGSyjqxKr,'clearlogo':MfiUVAkcLEaHzFelOCIvuhGSyjqxsW},'year':MfiUVAkcLEaHzFelOCIvuhGSyjqxKW['releaseYear']['value'],'duration':MfiUVAkcLEaHzFelOCIvuhGSyjqxsm,'info_genre':MfiUVAkcLEaHzFelOCIvuhGSyjqxsP,'director':MfiUVAkcLEaHzFelOCIvuhGSyjqxsg,'cast':MfiUVAkcLEaHzFelOCIvuhGSyjqxso,}
    MfiUVAkcLEaHzFelOCIvuhGSyjqxbY.append(MfiUVAkcLEaHzFelOCIvuhGSyjqxbN)
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxbY,MfiUVAkcLEaHzFelOCIvuhGSyjqxbw,MfiUVAkcLEaHzFelOCIvuhGSyjqxKP
 def NF_Subid_List(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,subJson):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKD=[]
  try:
   for i in MfiUVAkcLEaHzFelOCIvuhGSyjqxRr(MfiUVAkcLEaHzFelOCIvuhGSyjqxRd(subJson)):
    if subJson.get(MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(i)).get('$type')!='ref':break
    MfiUVAkcLEaHzFelOCIvuhGSyjqxRb=subJson.get(MfiUVAkcLEaHzFelOCIvuhGSyjqxRP(i)).get('value')[1]
    MfiUVAkcLEaHzFelOCIvuhGSyjqxKD.append(MfiUVAkcLEaHzFelOCIvuhGSyjqxRb)
  except MfiUVAkcLEaHzFelOCIvuhGSyjqxRm as exception:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ(exception)
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxKD
 def NF_CookieFile_Load(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT,cookie_filename):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKs={}
  try:
   if os.path.isfile(cookie_filename)==MfiUVAkcLEaHzFelOCIvuhGSyjqxRo:return{}
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRs=MfiUVAkcLEaHzFelOCIvuhGSyjqxRt(cookie_filename,'rb',-1)
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRT =pickle.loads(MfiUVAkcLEaHzFelOCIvuhGSyjqxRs.read())
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRs.close()
   for MfiUVAkcLEaHzFelOCIvuhGSyjqxRK in MfiUVAkcLEaHzFelOCIvuhGSyjqxRT:
    MfiUVAkcLEaHzFelOCIvuhGSyjqxKs[MfiUVAkcLEaHzFelOCIvuhGSyjqxRK.name]=MfiUVAkcLEaHzFelOCIvuhGSyjqxRK.value
  except:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ(exception) 
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxKs
 def NF_Get_DefaultCookies(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT):
  MfiUVAkcLEaHzFelOCIvuhGSyjqxKs={}
  if MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['flwssn'] :MfiUVAkcLEaHzFelOCIvuhGSyjqxKs['flwssn'] =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['flwssn']
  if MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['nfvdid'] :MfiUVAkcLEaHzFelOCIvuhGSyjqxKs['nfvdid'] =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['nfvdid']
  if MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['SecureNetflixId']:MfiUVAkcLEaHzFelOCIvuhGSyjqxKs['SecureNetflixId']=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['SecureNetflixId']
  if MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['NetflixId'] :MfiUVAkcLEaHzFelOCIvuhGSyjqxKs['NetflixId'] =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['NetflixId']
  if MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['memclid'] :MfiUVAkcLEaHzFelOCIvuhGSyjqxKs['memclid'] =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['memclid']
  if MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['clSharedContext']:MfiUVAkcLEaHzFelOCIvuhGSyjqxKs['clSharedContext']=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['COOKIES']['clSharedContext']
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxKs
 def NF_Get_BaseSession(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT):
  try:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbo=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.API_NETFLIX+'/browse' 
   MfiUVAkcLEaHzFelOCIvuhGSyjqxKs=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_Get_DefaultCookies()
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbP=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.callRequestCookies('Get',MfiUVAkcLEaHzFelOCIvuhGSyjqxbo,payload=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,params=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,headers=MfiUVAkcLEaHzFelOCIvuhGSyjqxRw,cookies=MfiUVAkcLEaHzFelOCIvuhGSyjqxKs)
   if MfiUVAkcLEaHzFelOCIvuhGSyjqxbP.status_code!=200:
    MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ('pass 1 status_code error')
    return MfiUVAkcLEaHzFelOCIvuhGSyjqxRo
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRX =MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.extract_json(MfiUVAkcLEaHzFelOCIvuhGSyjqxbP.text,'reactContext')
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRY=MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.extract_json(MfiUVAkcLEaHzFelOCIvuhGSyjqxbP.text,'falcorCache')
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF['SESSION']={'mainGuid':MfiUVAkcLEaHzFelOCIvuhGSyjqxRX['models']['memberContext']['data']['userInfo']['guid'],'nowGuid':MfiUVAkcLEaHzFelOCIvuhGSyjqxRX['models']['memberContext']['data']['userInfo']['userGuid'],'authURL':MfiUVAkcLEaHzFelOCIvuhGSyjqxRX['models']['memberContext']['data']['userInfo']['authURL'],'esnModel':MfiUVAkcLEaHzFelOCIvuhGSyjqxRX['models']['memberContext']['data']['userInfo']['esn'],'identifier':MfiUVAkcLEaHzFelOCIvuhGSyjqxRX['models']['serverDefs']['data']['BUILD_IDENTIFIER'],'abContext':MfiUVAkcLEaHzFelOCIvuhGSyjqxRX['models']['abContext']['data']['headers'],}
   MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.dic_To_jsonfile(MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF_SESSION_COOKIES1,MfiUVAkcLEaHzFelOCIvuhGSyjqxbT.NF)
  except MfiUVAkcLEaHzFelOCIvuhGSyjqxRm as exception:
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ('pass 1 error')
   MfiUVAkcLEaHzFelOCIvuhGSyjqxRJ(exception)
   return MfiUVAkcLEaHzFelOCIvuhGSyjqxRo
  return MfiUVAkcLEaHzFelOCIvuhGSyjqxRn
# Created by pyminifier (https://github.com/liftoff/pyminifier)
