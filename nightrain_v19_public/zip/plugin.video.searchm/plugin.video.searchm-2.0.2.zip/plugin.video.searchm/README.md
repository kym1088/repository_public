# searchM-v19
 OTT 통합검색 애드온 for Kodi19 


## Version 2.0.2 (2021.03.07)
- 넷플릭스 검색 오류 수정

## Version 2.0.1 (2021.02.22)
- 넷플릭스 검색 오류 수정

## Version 2.0.0 (2021.02.17)
- Initial addon version

