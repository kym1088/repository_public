__author__="NightRain"
LXTAfMxeRzIESBiUjQygbqwJmWpKOa=object
LXTAfMxeRzIESBiUjQygbqwJmWpKOn=None
LXTAfMxeRzIESBiUjQygbqwJmWpKOu=False
LXTAfMxeRzIESBiUjQygbqwJmWpKOl=print
LXTAfMxeRzIESBiUjQygbqwJmWpKOG=str
LXTAfMxeRzIESBiUjQygbqwJmWpKOc=int
LXTAfMxeRzIESBiUjQygbqwJmWpKOh=Exception
LXTAfMxeRzIESBiUjQygbqwJmWpKOd=True
LXTAfMxeRzIESBiUjQygbqwJmWpKDk=open
LXTAfMxeRzIESBiUjQygbqwJmWpKDC=isinstance
LXTAfMxeRzIESBiUjQygbqwJmWpKDH=list
LXTAfMxeRzIESBiUjQygbqwJmWpKDt=dict
LXTAfMxeRzIESBiUjQygbqwJmWpKDO=range
LXTAfMxeRzIESBiUjQygbqwJmWpKDY=len
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class LXTAfMxeRzIESBiUjQygbqwJmWpKkC(LXTAfMxeRzIESBiUjQygbqwJmWpKOa):
 def __init__(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.DEFAULT_HEADER ={'user-agent':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.USER_AGENT}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_WAVVE ='https://apis.wavve.com'
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_TVING_SEARCH='https://search.tving.com'
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_TVING_IMG ='https://image.tving.com'
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_WATCHA ='https://api-mars.watcha.com'
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX ='https://www.netflix.com'
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.WAVVE_LIMIT =20 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.TVING_LIMIT =30
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.WATCHA_LIMIT =30
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_LIMIT =20 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.DERECTOR_LIMIT =4
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.CAST_LIMIT =10
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.GENRE_LIMIT =4
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.TVING_MOVIE_LITE=['2610061','2610161','261062']
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_HEADER={'user-agent':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND1 ='_342x192'
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND2 ='_665x375'
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_PORT ='_342x684'
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LOGO ='_550x124'
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF={}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']={}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']={}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.Init_NF_Cookies()
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.Init_NF_Session()
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_COOKIES1 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_COOKIES2 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_COOKIES3 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_COOKIES4 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_FULLTEXT1 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_FULLTEXT2 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_FULLTEXT3 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_FULLTEXT4 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_CONTEXTJSON_FILE1 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_CONTEXTJSON_FILE2 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_CONTEXTJSON_FILE3 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_CONTEXTJSON_FILE4 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_FALCORJSON_FILE1 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_FALCORJSON_FILE2 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_FALCORJSON_FILE3 =''
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_FALCORJSON_FILE4 =''
 def callRequestCookies(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,jobtype,LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,params=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,redirects=LXTAfMxeRzIESBiUjQygbqwJmWpKOu):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkt=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.DEFAULT_HEADER
  if headers:LXTAfMxeRzIESBiUjQygbqwJmWpKkt.update(headers)
  if jobtype=='Get':
   LXTAfMxeRzIESBiUjQygbqwJmWpKkO=requests.get(LXTAfMxeRzIESBiUjQygbqwJmWpKkv,params=params,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKkt,cookies=cookies,allow_redirects=redirects)
  else:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkO=requests.post(LXTAfMxeRzIESBiUjQygbqwJmWpKkv,data=payload,params=params,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKkt,cookies=cookies,allow_redirects=redirects)
  return LXTAfMxeRzIESBiUjQygbqwJmWpKkO
 def callRequestCookies_NF(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,jobtype,LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,params=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,redirects=LXTAfMxeRzIESBiUjQygbqwJmWpKOu,addCookie=''):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkt=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_HEADER
  if headers:LXTAfMxeRzIESBiUjQygbqwJmWpKkt.update(headers)
  if jobtype=='Get':
   LXTAfMxeRzIESBiUjQygbqwJmWpKkO=requests.get(LXTAfMxeRzIESBiUjQygbqwJmWpKkv,params=params,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKkt,cookies=cookies,allow_redirects=redirects)
  else:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkO=requests.post(LXTAfMxeRzIESBiUjQygbqwJmWpKkv,data=payload,params=params,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKkt,cookies=cookies,allow_redirects=redirects)
  LXTAfMxeRzIESBiUjQygbqwJmWpKOl(LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKkO.status_code)+' - '+LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKkO.url))
  '''
  print(res.url )
  print(res.status_code )
  print(res.cookies )
  print(res.text )
  '''  
  try:
   if addCookie=='baseurl':
    if 'location' in LXTAfMxeRzIESBiUjQygbqwJmWpKkO.headers:
     LXTAfMxeRzIESBiUjQygbqwJmWpKkD=urllib.parse.urlsplit(LXTAfMxeRzIESBiUjQygbqwJmWpKkO.headers.get('location')).path
     LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['contryurl']=LXTAfMxeRzIESBiUjQygbqwJmWpKkD[1:3]
  except:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOn
  for LXTAfMxeRzIESBiUjQygbqwJmWpKkY in LXTAfMxeRzIESBiUjQygbqwJmWpKkO.cookies:
   if LXTAfMxeRzIESBiUjQygbqwJmWpKkY.name=='flwssn':
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['flwssn']['value'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkY.value
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['flwssn']['expires'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkY.expires
   elif LXTAfMxeRzIESBiUjQygbqwJmWpKkY.name=='nfvdid':
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['nfvdid']['value'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkY.value
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['nfvdid']['expires'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkY.expires
   elif LXTAfMxeRzIESBiUjQygbqwJmWpKkY.name=='SecureNetflixId':
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['SecureNetflixId']['value'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkY.value
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['SecureNetflixId']['expires'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkY.expires
   elif LXTAfMxeRzIESBiUjQygbqwJmWpKkY.name=='NetflixId':
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['NetflixId']['value'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkY.value
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['NetflixId']['expires'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkY.expires
   elif LXTAfMxeRzIESBiUjQygbqwJmWpKkY.name=='memclid':
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['memclid']['value'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkY.value
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['memclid']['expires'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkY.expires
   elif LXTAfMxeRzIESBiUjQygbqwJmWpKkY.name=='clSharedContext':
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['clSharedContext']['value'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkY.value
    LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['clSharedContext']['expires'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.GetNoCache(timetype=1,minutes=5)
  return LXTAfMxeRzIESBiUjQygbqwJmWpKkO
 def GetNoCache(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,timetype=1,minutes=0):
  if timetype==1:
   ts=LXTAfMxeRzIESBiUjQygbqwJmWpKOc(time.time())
   mi=LXTAfMxeRzIESBiUjQygbqwJmWpKOc(minutes*60)
  else:
   ts=LXTAfMxeRzIESBiUjQygbqwJmWpKOc(time.time()*1000)
   mi=LXTAfMxeRzIESBiUjQygbqwJmWpKOc(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,search_key,sType,page_int):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkr=[]
  LXTAfMxeRzIESBiUjQygbqwJmWpKkV=LXTAfMxeRzIESBiUjQygbqwJmWpKCH=1
  LXTAfMxeRzIESBiUjQygbqwJmWpKkF=LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkv=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_WAVVE+'/cf/search/list.js'
   LXTAfMxeRzIESBiUjQygbqwJmWpKko={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':LXTAfMxeRzIESBiUjQygbqwJmWpKOG((page_int-1)*LXTAfMxeRzIESBiUjQygbqwJmWpKkH.WAVVE_LIMIT),'limit':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.WAVVE_LIMIT,'orderby':'score'}
   LXTAfMxeRzIESBiUjQygbqwJmWpKko.update(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.WAVVE_PARAMS)
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.callRequestCookies('Get',LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,params=LXTAfMxeRzIESBiUjQygbqwJmWpKko,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKOn)
   LXTAfMxeRzIESBiUjQygbqwJmWpKkP=json.loads(LXTAfMxeRzIESBiUjQygbqwJmWpKks.text)
   if not('celllist' in LXTAfMxeRzIESBiUjQygbqwJmWpKkP['cell_toplist']):return LXTAfMxeRzIESBiUjQygbqwJmWpKkr,LXTAfMxeRzIESBiUjQygbqwJmWpKkF
   LXTAfMxeRzIESBiUjQygbqwJmWpKka=LXTAfMxeRzIESBiUjQygbqwJmWpKkP['cell_toplist']['celllist']
   for LXTAfMxeRzIESBiUjQygbqwJmWpKkn in LXTAfMxeRzIESBiUjQygbqwJmWpKka:
    LXTAfMxeRzIESBiUjQygbqwJmWpKku =LXTAfMxeRzIESBiUjQygbqwJmWpKkn['event_list'][1]['url']
    LXTAfMxeRzIESBiUjQygbqwJmWpKkl=urllib.parse.urlsplit(LXTAfMxeRzIESBiUjQygbqwJmWpKku).query
    LXTAfMxeRzIESBiUjQygbqwJmWpKkG=LXTAfMxeRzIESBiUjQygbqwJmWpKkl[0:LXTAfMxeRzIESBiUjQygbqwJmWpKkl.find('=')]
    LXTAfMxeRzIESBiUjQygbqwJmWpKkc=LXTAfMxeRzIESBiUjQygbqwJmWpKkl[LXTAfMxeRzIESBiUjQygbqwJmWpKkl.find('=')+1:]
    LXTAfMxeRzIESBiUjQygbqwJmWpKkG='TVSHOW' if LXTAfMxeRzIESBiUjQygbqwJmWpKkG=='programid' else 'MOVIE' 
    LXTAfMxeRzIESBiUjQygbqwJmWpKkh=LXTAfMxeRzIESBiUjQygbqwJmWpKkn['title_list'][0]['text']
    LXTAfMxeRzIESBiUjQygbqwJmWpKkd =LXTAfMxeRzIESBiUjQygbqwJmWpKkn['age']
    LXTAfMxeRzIESBiUjQygbqwJmWpKCk={'title':LXTAfMxeRzIESBiUjQygbqwJmWpKkh}
    if LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('age')!='21':
     LXTAfMxeRzIESBiUjQygbqwJmWpKkr.append(LXTAfMxeRzIESBiUjQygbqwJmWpKCk)
   LXTAfMxeRzIESBiUjQygbqwJmWpKkV=LXTAfMxeRzIESBiUjQygbqwJmWpKOc(LXTAfMxeRzIESBiUjQygbqwJmWpKkP['cell_toplist']['pagecount'])
   if LXTAfMxeRzIESBiUjQygbqwJmWpKkP['cell_toplist']['count']:LXTAfMxeRzIESBiUjQygbqwJmWpKCH =LXTAfMxeRzIESBiUjQygbqwJmWpKOc(LXTAfMxeRzIESBiUjQygbqwJmWpKkP['cell_toplist']['count'])
   else:LXTAfMxeRzIESBiUjQygbqwJmWpKCH=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.LIST_LIMIT
   LXTAfMxeRzIESBiUjQygbqwJmWpKkF=LXTAfMxeRzIESBiUjQygbqwJmWpKkV>LXTAfMxeRzIESBiUjQygbqwJmWpKCH
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
  return LXTAfMxeRzIESBiUjQygbqwJmWpKkr,LXTAfMxeRzIESBiUjQygbqwJmWpKkF 
 def Get_Search_Tving(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,search_key,sType,page_int):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkr=[]
  LXTAfMxeRzIESBiUjQygbqwJmWpKkF=LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKCt ='/search/getSearch.jsp'
   LXTAfMxeRzIESBiUjQygbqwJmWpKCO={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':LXTAfMxeRzIESBiUjQygbqwJmWpKOG(page_int),'pageSize':LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.TVING_PARMAS.get('SCREENCODE'),'os':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.TVING_PARMAS.get('OSCODE'),'network':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.GetNoCache(2))}
   LXTAfMxeRzIESBiUjQygbqwJmWpKkv=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_TVING_SEARCH+LXTAfMxeRzIESBiUjQygbqwJmWpKCt
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.callRequestCookies('Get',LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,params=LXTAfMxeRzIESBiUjQygbqwJmWpKCO,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKOn)
   LXTAfMxeRzIESBiUjQygbqwJmWpKCD=json.loads(LXTAfMxeRzIESBiUjQygbqwJmWpKks.text)
   if sType=='TVSHOW':
    if not('programRsb' in LXTAfMxeRzIESBiUjQygbqwJmWpKCD):return LXTAfMxeRzIESBiUjQygbqwJmWpKkr,LXTAfMxeRzIESBiUjQygbqwJmWpKkF
    LXTAfMxeRzIESBiUjQygbqwJmWpKCY=LXTAfMxeRzIESBiUjQygbqwJmWpKCD['programRsb']['dataList']
    LXTAfMxeRzIESBiUjQygbqwJmWpKCN =LXTAfMxeRzIESBiUjQygbqwJmWpKOc(LXTAfMxeRzIESBiUjQygbqwJmWpKCD['programRsb']['count'])
    for LXTAfMxeRzIESBiUjQygbqwJmWpKkn in LXTAfMxeRzIESBiUjQygbqwJmWpKCY:
     LXTAfMxeRzIESBiUjQygbqwJmWpKCr=LXTAfMxeRzIESBiUjQygbqwJmWpKkn['mast_cd']
     LXTAfMxeRzIESBiUjQygbqwJmWpKkh =LXTAfMxeRzIESBiUjQygbqwJmWpKkn['mast_nm']
     LXTAfMxeRzIESBiUjQygbqwJmWpKCV=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_TVING_IMG+LXTAfMxeRzIESBiUjQygbqwJmWpKkn['web_url4']
     LXTAfMxeRzIESBiUjQygbqwJmWpKCF =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_TVING_IMG+LXTAfMxeRzIESBiUjQygbqwJmWpKkn['web_url']
     try:
      LXTAfMxeRzIESBiUjQygbqwJmWpKCv =[]
      LXTAfMxeRzIESBiUjQygbqwJmWpKCo=[]
      LXTAfMxeRzIESBiUjQygbqwJmWpKCs =[]
      LXTAfMxeRzIESBiUjQygbqwJmWpKCP =0
      LXTAfMxeRzIESBiUjQygbqwJmWpKCa =''
      LXTAfMxeRzIESBiUjQygbqwJmWpKCn =''
      LXTAfMxeRzIESBiUjQygbqwJmWpKCu =''
      if LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('actor') !='' and LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('actor') !='-':LXTAfMxeRzIESBiUjQygbqwJmWpKCv =LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('actor').split(',')
      if LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('director')!='' and LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('director')!='-':LXTAfMxeRzIESBiUjQygbqwJmWpKCo=LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('director').split(',')
      if LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('cate_nm')!='' and LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('cate_nm')!='-':LXTAfMxeRzIESBiUjQygbqwJmWpKCs =LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('cate_nm').split('/')
      if 'targetage' in LXTAfMxeRzIESBiUjQygbqwJmWpKkn:LXTAfMxeRzIESBiUjQygbqwJmWpKCa=LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('targetage')
      if 'broad_dt' in LXTAfMxeRzIESBiUjQygbqwJmWpKkn:
       LXTAfMxeRzIESBiUjQygbqwJmWpKCl=LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('broad_dt')
       LXTAfMxeRzIESBiUjQygbqwJmWpKCu='%s-%s-%s'%(LXTAfMxeRzIESBiUjQygbqwJmWpKCl[:4],LXTAfMxeRzIESBiUjQygbqwJmWpKCl[4:6],LXTAfMxeRzIESBiUjQygbqwJmWpKCl[6:])
       LXTAfMxeRzIESBiUjQygbqwJmWpKCn =LXTAfMxeRzIESBiUjQygbqwJmWpKCl[:4]
     except:
      LXTAfMxeRzIESBiUjQygbqwJmWpKOn
     LXTAfMxeRzIESBiUjQygbqwJmWpKCk={'title':LXTAfMxeRzIESBiUjQygbqwJmWpKkh,}
     LXTAfMxeRzIESBiUjQygbqwJmWpKkr.append(LXTAfMxeRzIESBiUjQygbqwJmWpKCk)
   else:
    if not('vodMVRsb' in LXTAfMxeRzIESBiUjQygbqwJmWpKCD):return LXTAfMxeRzIESBiUjQygbqwJmWpKkr,LXTAfMxeRzIESBiUjQygbqwJmWpKkF
    LXTAfMxeRzIESBiUjQygbqwJmWpKCG=LXTAfMxeRzIESBiUjQygbqwJmWpKCD['vodMVRsb']['dataList']
    LXTAfMxeRzIESBiUjQygbqwJmWpKCN =LXTAfMxeRzIESBiUjQygbqwJmWpKOc(LXTAfMxeRzIESBiUjQygbqwJmWpKCD['vodMVRsb']['count'])
    LXTAfMxeRzIESBiUjQygbqwJmWpKOl(LXTAfMxeRzIESBiUjQygbqwJmWpKCN)
    for LXTAfMxeRzIESBiUjQygbqwJmWpKkn in LXTAfMxeRzIESBiUjQygbqwJmWpKCG:
     LXTAfMxeRzIESBiUjQygbqwJmWpKCr=LXTAfMxeRzIESBiUjQygbqwJmWpKkn['mast_cd']
     LXTAfMxeRzIESBiUjQygbqwJmWpKkh =LXTAfMxeRzIESBiUjQygbqwJmWpKkn['mast_nm'].strip()
     LXTAfMxeRzIESBiUjQygbqwJmWpKCV =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_TVING_IMG+LXTAfMxeRzIESBiUjQygbqwJmWpKkn['web_url']
     LXTAfMxeRzIESBiUjQygbqwJmWpKCF =LXTAfMxeRzIESBiUjQygbqwJmWpKCV
     LXTAfMxeRzIESBiUjQygbqwJmWpKCc=''
     try:
      LXTAfMxeRzIESBiUjQygbqwJmWpKCv =[]
      LXTAfMxeRzIESBiUjQygbqwJmWpKCo=[]
      LXTAfMxeRzIESBiUjQygbqwJmWpKCs =[]
      LXTAfMxeRzIESBiUjQygbqwJmWpKCP =0
      LXTAfMxeRzIESBiUjQygbqwJmWpKCa =''
      LXTAfMxeRzIESBiUjQygbqwJmWpKCn =''
      LXTAfMxeRzIESBiUjQygbqwJmWpKCu =''
      if LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('actor') !='' and LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('actor') !='-':LXTAfMxeRzIESBiUjQygbqwJmWpKCv =LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('actor').split(',')
      if LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('director')!='' and LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('director')!='-':LXTAfMxeRzIESBiUjQygbqwJmWpKCo=LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('director').split(',')
      if LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('cate_nm')!='' and LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('cate_nm')!='-':LXTAfMxeRzIESBiUjQygbqwJmWpKCs =LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('cate_nm').split('/')
      if LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('runtime_sec')!='':LXTAfMxeRzIESBiUjQygbqwJmWpKCP=LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('runtime_sec')
      if 'grade_nm' in LXTAfMxeRzIESBiUjQygbqwJmWpKkn:LXTAfMxeRzIESBiUjQygbqwJmWpKCa=LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('grade_nm')
      LXTAfMxeRzIESBiUjQygbqwJmWpKCl=LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('broad_dt')
      if data_str!='':
       LXTAfMxeRzIESBiUjQygbqwJmWpKCu='%s-%s-%s'%(LXTAfMxeRzIESBiUjQygbqwJmWpKCl[:4],LXTAfMxeRzIESBiUjQygbqwJmWpKCl[4:6],LXTAfMxeRzIESBiUjQygbqwJmWpKCl[6:])
       LXTAfMxeRzIESBiUjQygbqwJmWpKCn =LXTAfMxeRzIESBiUjQygbqwJmWpKCl[:4]
     except:
      LXTAfMxeRzIESBiUjQygbqwJmWpKOn
     LXTAfMxeRzIESBiUjQygbqwJmWpKCk={'title':LXTAfMxeRzIESBiUjQygbqwJmWpKkh,}
     LXTAfMxeRzIESBiUjQygbqwJmWpKCh=LXTAfMxeRzIESBiUjQygbqwJmWpKOu
     for LXTAfMxeRzIESBiUjQygbqwJmWpKCd in LXTAfMxeRzIESBiUjQygbqwJmWpKkn['bill']:
      if LXTAfMxeRzIESBiUjQygbqwJmWpKCd in LXTAfMxeRzIESBiUjQygbqwJmWpKkH.TVING_MOVIE_LITE:
       LXTAfMxeRzIESBiUjQygbqwJmWpKCh=LXTAfMxeRzIESBiUjQygbqwJmWpKOd
       break
     if LXTAfMxeRzIESBiUjQygbqwJmWpKCh==LXTAfMxeRzIESBiUjQygbqwJmWpKOu: 
      LXTAfMxeRzIESBiUjQygbqwJmWpKCk['title']=LXTAfMxeRzIESBiUjQygbqwJmWpKCk['title']+' [개별구매]'
     LXTAfMxeRzIESBiUjQygbqwJmWpKkr.append(LXTAfMxeRzIESBiUjQygbqwJmWpKCk)
   if LXTAfMxeRzIESBiUjQygbqwJmWpKCN>(page_int*LXTAfMxeRzIESBiUjQygbqwJmWpKkH.TVING_LIMIT):LXTAfMxeRzIESBiUjQygbqwJmWpKkF=LXTAfMxeRzIESBiUjQygbqwJmWpKOd
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
  return LXTAfMxeRzIESBiUjQygbqwJmWpKkr,LXTAfMxeRzIESBiUjQygbqwJmWpKkF
 def Get_Search_Watcha(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,search_key,page_int):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkr=[]
  LXTAfMxeRzIESBiUjQygbqwJmWpKkF=LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkv=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_WATCHA+'/api/search.json'
   LXTAfMxeRzIESBiUjQygbqwJmWpKCO={'query':search_key,'page':LXTAfMxeRzIESBiUjQygbqwJmWpKOG(page_int),'per':LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.WATCHA_LIMIT),'exclude':'limited',}
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.callRequestCookies('Get',LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,params=LXTAfMxeRzIESBiUjQygbqwJmWpKCO,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.WATCHA_HEADER,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKOn)
   LXTAfMxeRzIESBiUjQygbqwJmWpKCD=json.loads(LXTAfMxeRzIESBiUjQygbqwJmWpKks.text)
   if not('results' in LXTAfMxeRzIESBiUjQygbqwJmWpKCD):return LXTAfMxeRzIESBiUjQygbqwJmWpKkr,LXTAfMxeRzIESBiUjQygbqwJmWpKkF
   LXTAfMxeRzIESBiUjQygbqwJmWpKHk=LXTAfMxeRzIESBiUjQygbqwJmWpKCD['results']
   LXTAfMxeRzIESBiUjQygbqwJmWpKkF=LXTAfMxeRzIESBiUjQygbqwJmWpKCD['meta']['has_next']
   for LXTAfMxeRzIESBiUjQygbqwJmWpKkn in LXTAfMxeRzIESBiUjQygbqwJmWpKHk:
    LXTAfMxeRzIESBiUjQygbqwJmWpKHC =LXTAfMxeRzIESBiUjQygbqwJmWpKkn['code']
    LXTAfMxeRzIESBiUjQygbqwJmWpKHt=LXTAfMxeRzIESBiUjQygbqwJmWpKkn['content_type']
    LXTAfMxeRzIESBiUjQygbqwJmWpKHO =LXTAfMxeRzIESBiUjQygbqwJmWpKkn['title']
    LXTAfMxeRzIESBiUjQygbqwJmWpKHD =LXTAfMxeRzIESBiUjQygbqwJmWpKkn['story']
    LXTAfMxeRzIESBiUjQygbqwJmWpKCV=LXTAfMxeRzIESBiUjQygbqwJmWpKCF=LXTAfMxeRzIESBiUjQygbqwJmWpKOv=''
    if LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('poster') !=LXTAfMxeRzIESBiUjQygbqwJmWpKOn:LXTAfMxeRzIESBiUjQygbqwJmWpKCV=LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('poster').get('original')
    if LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('stillcut')!=LXTAfMxeRzIESBiUjQygbqwJmWpKOn:LXTAfMxeRzIESBiUjQygbqwJmWpKCF =LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('stillcut').get('large')
    if LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('thumbnail')!=LXTAfMxeRzIESBiUjQygbqwJmWpKOn:LXTAfMxeRzIESBiUjQygbqwJmWpKOv=LXTAfMxeRzIESBiUjQygbqwJmWpKkn.get('thumbnail').get('large')
    if LXTAfMxeRzIESBiUjQygbqwJmWpKOv=='' :LXTAfMxeRzIESBiUjQygbqwJmWpKOv=LXTAfMxeRzIESBiUjQygbqwJmWpKCF
    LXTAfMxeRzIESBiUjQygbqwJmWpKHY={'thumb':LXTAfMxeRzIESBiUjQygbqwJmWpKCF,'poster':LXTAfMxeRzIESBiUjQygbqwJmWpKCV,'fanart':LXTAfMxeRzIESBiUjQygbqwJmWpKOv}
    LXTAfMxeRzIESBiUjQygbqwJmWpKCn =LXTAfMxeRzIESBiUjQygbqwJmWpKkn['year']
    LXTAfMxeRzIESBiUjQygbqwJmWpKHN =LXTAfMxeRzIESBiUjQygbqwJmWpKkn['film_rating_code']
    LXTAfMxeRzIESBiUjQygbqwJmWpKHr=LXTAfMxeRzIESBiUjQygbqwJmWpKkn['film_rating_short']
    LXTAfMxeRzIESBiUjQygbqwJmWpKHV =LXTAfMxeRzIESBiUjQygbqwJmWpKkn['film_rating_long']
    if LXTAfMxeRzIESBiUjQygbqwJmWpKHt=='movies':
     LXTAfMxeRzIESBiUjQygbqwJmWpKCP =LXTAfMxeRzIESBiUjQygbqwJmWpKkn['duration']
    else:
     LXTAfMxeRzIESBiUjQygbqwJmWpKCP ='0'
    LXTAfMxeRzIESBiUjQygbqwJmWpKCk={'title':LXTAfMxeRzIESBiUjQygbqwJmWpKHO,}
    LXTAfMxeRzIESBiUjQygbqwJmWpKkr.append(LXTAfMxeRzIESBiUjQygbqwJmWpKCk)
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
  return LXTAfMxeRzIESBiUjQygbqwJmWpKkr,LXTAfMxeRzIESBiUjQygbqwJmWpKkF
 def dic_To_jsonfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,filename,dic):
  if filename=='':return
  fp=LXTAfMxeRzIESBiUjQygbqwJmWpKDk(filename,'w',-1,'utf-8')
  json.dump(dic,fp)
  fp.close()
 def jsonfile_To_dic(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,filename):
  if filename=='':return LXTAfMxeRzIESBiUjQygbqwJmWpKOn
  try:
   fp=LXTAfMxeRzIESBiUjQygbqwJmWpKDk(filename,'r',-1,'utf-8')
   LXTAfMxeRzIESBiUjQygbqwJmWpKHF=json.load(fp)
   fp.close()
  except:
   LXTAfMxeRzIESBiUjQygbqwJmWpKHF={}
  return LXTAfMxeRzIESBiUjQygbqwJmWpKHF
 def tempFileSave(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,filename,resText):
  if filename=='':return
  fp=LXTAfMxeRzIESBiUjQygbqwJmWpKDk(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,filename):
  if filename=='':return
  try:
   fp=LXTAfMxeRzIESBiUjQygbqwJmWpKDk(filename,'r',-1,'utf-8')
   LXTAfMxeRzIESBiUjQygbqwJmWpKHF=fp.read()
   fp.close()
  except:
   LXTAfMxeRzIESBiUjQygbqwJmWpKHF=''
  return LXTAfMxeRzIESBiUjQygbqwJmWpKHF
 def Init_NF_Total(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF={}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']={}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']={}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.Init_NF_Cookies()
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.Init_NF_Session()
 def Init_NF_Cookies(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['lhpuuidh'] ={'keyname':'','value':'','expires':0}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['lhpuuidhT'] ={'keyname':'','value':'','expires':0}
 def Check_NF_CookieExp(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  LXTAfMxeRzIESBiUjQygbqwJmWpKHv=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.GetNoCache(timetype=1,minutes=0)
  if LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['flwssn']['expires'] <=LXTAfMxeRzIESBiUjQygbqwJmWpKHv:LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  if LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['nfvdid']['expires'] <=LXTAfMxeRzIESBiUjQygbqwJmWpKHv:LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  if LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['SecureNetflixId']['expires']<=LXTAfMxeRzIESBiUjQygbqwJmWpKHv:LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  if LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['NetflixId']['expires'] <=LXTAfMxeRzIESBiUjQygbqwJmWpKHv:LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  if LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['memclid']['expires'] <=LXTAfMxeRzIESBiUjQygbqwJmWpKHv:LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  if LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['clSharedContext']['expires']<=LXTAfMxeRzIESBiUjQygbqwJmWpKHv:LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
 def Init_NF_Session(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['account'] ={'nfid':'','nfpw':'','nfpfnum':0}
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['membershipStatus']='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['esnModel'] ='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['username'] ='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['authURL'] ='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['mainGuid'] ='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['nowGuid'] ='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['abContext'] ='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['identifier'] ='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['contryurl'] ='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['countryCode'] ='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['countryIsoCode'] ='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['loco'] ='' 
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['limitdate'] =''
 def make_NF_DefaultCookies(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  LXTAfMxeRzIESBiUjQygbqwJmWpKHo={}
  if LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['flwssn']['value'] :LXTAfMxeRzIESBiUjQygbqwJmWpKHo['flwssn'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['flwssn']['value']
  if LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['nfvdid']['value'] :LXTAfMxeRzIESBiUjQygbqwJmWpKHo['nfvdid'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['nfvdid']['value']
  if LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['SecureNetflixId']['value']:LXTAfMxeRzIESBiUjQygbqwJmWpKHo['SecureNetflixId']=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['SecureNetflixId']['value']
  if LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['NetflixId']['value'] :LXTAfMxeRzIESBiUjQygbqwJmWpKHo['NetflixId'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['NetflixId']['value']
  if LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['memclid']['value'] :LXTAfMxeRzIESBiUjQygbqwJmWpKHo['memclid'] =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['memclid']['value']
  return LXTAfMxeRzIESBiUjQygbqwJmWpKHo
 def make_NF_XnetflixHeaders(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  LXTAfMxeRzIESBiUjQygbqwJmWpKHs={'x-netflix.browsername':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['esnModel'],'x-netflix.esnprefix':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['nowGuid'],'x-netflix.uiversion':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return LXTAfMxeRzIESBiUjQygbqwJmWpKHs
 def make_NF_ApiParams(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  LXTAfMxeRzIESBiUjQygbqwJmWpKko={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'false','persoInfoDensity':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['identifier']),}
  return LXTAfMxeRzIESBiUjQygbqwJmWpKko
 def extract_json(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,content,name):
  LXTAfMxeRzIESBiUjQygbqwJmWpKHP=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  LXTAfMxeRzIESBiUjQygbqwJmWpKHa=LXTAfMxeRzIESBiUjQygbqwJmWpKOn
  LXTAfMxeRzIESBiUjQygbqwJmWpKHn=re.compile(LXTAfMxeRzIESBiUjQygbqwJmWpKHP.format(name),re.DOTALL).findall(content)
  LXTAfMxeRzIESBiUjQygbqwJmWpKHa=LXTAfMxeRzIESBiUjQygbqwJmWpKHn[0]
  LXTAfMxeRzIESBiUjQygbqwJmWpKHu=LXTAfMxeRzIESBiUjQygbqwJmWpKHa.replace('\\"','\\\\"') 
  LXTAfMxeRzIESBiUjQygbqwJmWpKHu=LXTAfMxeRzIESBiUjQygbqwJmWpKHu.replace('\\s','\\\\s') 
  LXTAfMxeRzIESBiUjQygbqwJmWpKHu=LXTAfMxeRzIESBiUjQygbqwJmWpKHu.replace('\\n','\\\\n') 
  LXTAfMxeRzIESBiUjQygbqwJmWpKHu=LXTAfMxeRzIESBiUjQygbqwJmWpKHu.replace('\\t','\\\\t') 
  LXTAfMxeRzIESBiUjQygbqwJmWpKHu=LXTAfMxeRzIESBiUjQygbqwJmWpKHu.encode().decode('unicode_escape') 
  LXTAfMxeRzIESBiUjQygbqwJmWpKHu=re.sub(r'\\(?!["])',r'\\\\',LXTAfMxeRzIESBiUjQygbqwJmWpKHu) 
  return json.loads(LXTAfMxeRzIESBiUjQygbqwJmWpKHu)
 def Save_session_acount(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,LXTAfMxeRzIESBiUjQygbqwJmWpKHl,LXTAfMxeRzIESBiUjQygbqwJmWpKHG,LXTAfMxeRzIESBiUjQygbqwJmWpKHc):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['account']['nfid'] =base64.standard_b64encode(LXTAfMxeRzIESBiUjQygbqwJmWpKHl.encode()).decode('utf-8')
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['account']['nfpw'] =base64.standard_b64encode(LXTAfMxeRzIESBiUjQygbqwJmWpKHG.encode()).decode('utf-8')
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['account']['nfpfnum']=LXTAfMxeRzIESBiUjQygbqwJmWpKHc
 def Load_session_acount(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  LXTAfMxeRzIESBiUjQygbqwJmWpKHl =base64.standard_b64decode(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['account']['nfid']).decode('utf-8')
  LXTAfMxeRzIESBiUjQygbqwJmWpKHG =base64.standard_b64decode(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['account']['nfpw']).decode('utf-8')
  LXTAfMxeRzIESBiUjQygbqwJmWpKHc=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['account']['nfpfnum']
  return LXTAfMxeRzIESBiUjQygbqwJmWpKHl,LXTAfMxeRzIESBiUjQygbqwJmWpKHG,LXTAfMxeRzIESBiUjQygbqwJmWpKHc
 def Get_NF_BaseCookies(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkv=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX+'/login' 
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.callRequestCookies_NF('Get',LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,params=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,addCookie='baseurl')
   if LXTAfMxeRzIESBiUjQygbqwJmWpKks.status_code!=302:
    LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 1-1 status_code error')
    return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 1-1 error')
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkv=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX+'/'+LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['contryurl']+'/login' 
   LXTAfMxeRzIESBiUjQygbqwJmWpKHo=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.make_NF_DefaultCookies()
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.callRequestCookies_NF('Get',LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,params=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKHo)
   if LXTAfMxeRzIESBiUjQygbqwJmWpKks.status_code!=200:
    LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 1-2 status_code error')
    return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
   LXTAfMxeRzIESBiUjQygbqwJmWpKHh=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.extract_json(LXTAfMxeRzIESBiUjQygbqwJmWpKks.text,'reactContext')
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.dic_To_jsonfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_CONTEXTJSON_FILE1,LXTAfMxeRzIESBiUjQygbqwJmWpKHh)
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['membershipStatus']=LXTAfMxeRzIESBiUjQygbqwJmWpKHh['models']['userInfo']['data']['membershipStatus']
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['authURL'] =LXTAfMxeRzIESBiUjQygbqwJmWpKHh['models']['userInfo']['data']['authURL']
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['esnModel'] =LXTAfMxeRzIESBiUjQygbqwJmWpKHh['models']['esnGeneratorModel']['data']['esn']
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['abContext'] =LXTAfMxeRzIESBiUjQygbqwJmWpKHh['models']['abContext']['data']['headers']
   LXTAfMxeRzIESBiUjQygbqwJmWpKHd=LXTAfMxeRzIESBiUjQygbqwJmWpKHh['models']['loginContext']['data']['geo']['requestCountry']['id']
   LXTAfMxeRzIESBiUjQygbqwJmWpKtk ='+82' 
   LXTAfMxeRzIESBiUjQygbqwJmWpKtC =LXTAfMxeRzIESBiUjQygbqwJmWpKHh['models']['countryCodes']['data']['codes']
   for LXTAfMxeRzIESBiUjQygbqwJmWpKtH in LXTAfMxeRzIESBiUjQygbqwJmWpKtC:
    if LXTAfMxeRzIESBiUjQygbqwJmWpKtH['id']==LXTAfMxeRzIESBiUjQygbqwJmWpKHd:
     LXTAfMxeRzIESBiUjQygbqwJmWpKtk='+'+LXTAfMxeRzIESBiUjQygbqwJmWpKtH['code']
     break
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['countryCode'] =LXTAfMxeRzIESBiUjQygbqwJmWpKtk 
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['countryIsoCode']=LXTAfMxeRzIESBiUjQygbqwJmWpKHd 
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.dic_To_jsonfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_COOKIES1,LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF)
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 1-2 error')
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  return LXTAfMxeRzIESBiUjQygbqwJmWpKOd
 def Get_NF_BaseLogin(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,user_id,user_pw,user_pfnum):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkH.Save_session_acount(user_id,user_pw,user_pfnum)
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkv=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX+'/'+LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['contryurl']+'/login' 
   LXTAfMxeRzIESBiUjQygbqwJmWpKtO={'userLoginId':user_id,'password':user_pw,'rememberMe':'true','flow':'websiteSignUp','mode':'login','action':'loginAction','withFields':'rememberMe,nextPage,userLoginId,password,countryCode,countryIsoCode','authURL':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['authURL'],'nextPage':'','showPassword':'','countryCode':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['countryCode'],'countryIsoCode':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['countryIsoCode'],}
   LXTAfMxeRzIESBiUjQygbqwJmWpKHs={'referer':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX+'/'+LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['contryurl']+'/login'}
   LXTAfMxeRzIESBiUjQygbqwJmWpKHo=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.make_NF_DefaultCookies()
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.callRequestCookies_NF('Post',LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKtO,params=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKHs,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKHo)
   if LXTAfMxeRzIESBiUjQygbqwJmWpKks.status_code!=302:
    LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 2-1 status_code error')
    return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 2-1 error')
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkv=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX+'/'+LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['contryurl']+'/' 
   LXTAfMxeRzIESBiUjQygbqwJmWpKHs={'referer':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX+'/'+LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['contryurl']+'/login'}
   LXTAfMxeRzIESBiUjQygbqwJmWpKHo=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.make_NF_DefaultCookies()
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.callRequestCookies_NF('Get',LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,params=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKHs,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKHo)
   if LXTAfMxeRzIESBiUjQygbqwJmWpKks.status_code!=302:
    LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 2-2 status_code error')
    return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 2-2 error')
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkv=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX+'/browse' 
   LXTAfMxeRzIESBiUjQygbqwJmWpKHs={'referer':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX+'/'+LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['contryurl']+'/login'}
   LXTAfMxeRzIESBiUjQygbqwJmWpKHo=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.make_NF_DefaultCookies()
   LXTAfMxeRzIESBiUjQygbqwJmWpKHo['clSharedContext']=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['clSharedContext']['value']
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.callRequestCookies_NF('Get',LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,params=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKHs,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKHo)
   if LXTAfMxeRzIESBiUjQygbqwJmWpKks.status_code!=200:
    LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 2-3 status_code error')
    return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
   LXTAfMxeRzIESBiUjQygbqwJmWpKtD=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.extract_json(LXTAfMxeRzIESBiUjQygbqwJmWpKks.text,'reactContext')
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.dic_To_jsonfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_CONTEXTJSON_FILE2,LXTAfMxeRzIESBiUjQygbqwJmWpKtD)
   LXTAfMxeRzIESBiUjQygbqwJmWpKtY=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.extract_json(LXTAfMxeRzIESBiUjQygbqwJmWpKks.text,'falcorCache')
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.dic_To_jsonfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_FALCORJSON_FILE2,LXTAfMxeRzIESBiUjQygbqwJmWpKtY)
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 2-3 error')
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  LXTAfMxeRzIESBiUjQygbqwJmWpKtN=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.Get_NF_LoginData(LXTAfMxeRzIESBiUjQygbqwJmWpKtD,LXTAfMxeRzIESBiUjQygbqwJmWpKtY,user_pfnum)
  if LXTAfMxeRzIESBiUjQygbqwJmWpKtN==LXTAfMxeRzIESBiUjQygbqwJmWpKOu:
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOu 
  return LXTAfMxeRzIESBiUjQygbqwJmWpKOd
 def Get_NF_LoginData(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,LXTAfMxeRzIESBiUjQygbqwJmWpKtD,LXTAfMxeRzIESBiUjQygbqwJmWpKtY,user_pfnum):
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['membershipStatus']=LXTAfMxeRzIESBiUjQygbqwJmWpKtD['models']['userInfo']['data']['membershipStatus']
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['username'] =LXTAfMxeRzIESBiUjQygbqwJmWpKtD['models']['userInfo']['data']['name']
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['authURL'] =LXTAfMxeRzIESBiUjQygbqwJmWpKtD['models']['userInfo']['data']['authURL'] 
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['mainGuid'] =LXTAfMxeRzIESBiUjQygbqwJmWpKtD['models']['userInfo']['data']['guid'] 
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['nowGuid'] =LXTAfMxeRzIESBiUjQygbqwJmWpKtD['models']['userInfo']['data']['userGuid']
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['esnModel'] =LXTAfMxeRzIESBiUjQygbqwJmWpKtD['models']['esnGeneratorModel']['data']['esn']
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['abContext'] =LXTAfMxeRzIESBiUjQygbqwJmWpKtD['models']['abContext']['data']['headers']
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['identifier'] =LXTAfMxeRzIESBiUjQygbqwJmWpKtD['models']['serverDefs']['data']['BUILD_IDENTIFIER']
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['nowGuid'] =LXTAfMxeRzIESBiUjQygbqwJmWpKtY['profilesList'][LXTAfMxeRzIESBiUjQygbqwJmWpKOG(user_pfnum)]['value'][1]
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.dic_To_jsonfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_COOKIES2,LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF)
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 2-3-sub error')
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  return LXTAfMxeRzIESBiUjQygbqwJmWpKOd
 def Get_NF_ActivateProfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkv='%s/api/shakti/%s/profiles/switch'%(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX,LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['identifier'])
   LXTAfMxeRzIESBiUjQygbqwJmWpKko={'switchProfileGuid':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['nowGuid'],'authURL':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['authURL'],'_':LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.GetNoCache(timetype=2,minutes=0)),}
   LXTAfMxeRzIESBiUjQygbqwJmWpKHs={'referer':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX+'/browse','accept':'*/*','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
   LXTAfMxeRzIESBiUjQygbqwJmWpKtr=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.make_NF_XnetflixHeaders()
   LXTAfMxeRzIESBiUjQygbqwJmWpKtr['x-netflix.request.client.user.guid']=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['mainGuid']
   LXTAfMxeRzIESBiUjQygbqwJmWpKHs.update(LXTAfMxeRzIESBiUjQygbqwJmWpKtr)
   LXTAfMxeRzIESBiUjQygbqwJmWpKHo=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.make_NF_DefaultCookies()
   LXTAfMxeRzIESBiUjQygbqwJmWpKHo['clSharedContext']=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['clSharedContext']['value']
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.callRequestCookies_NF('Get',LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,params=LXTAfMxeRzIESBiUjQygbqwJmWpKko,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKHs,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKHo)
   if LXTAfMxeRzIESBiUjQygbqwJmWpKks.status_code!=200:
    LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 3 status_code error')
    return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.dic_To_jsonfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_COOKIES2,LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF)
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 3 error')
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  return LXTAfMxeRzIESBiUjQygbqwJmWpKOd
 def Get_NF_BrowseMain(LXTAfMxeRzIESBiUjQygbqwJmWpKkH):
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKkv=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX+'/browse' 
   LXTAfMxeRzIESBiUjQygbqwJmWpKHs={'referer':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX+'/browse','sec-fetch-dest':'document','sec-fetch-mode':'navigate','sec-fetch-site':'same-origin','sec-fetch-user':'?1',}
   LXTAfMxeRzIESBiUjQygbqwJmWpKHo=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.make_NF_DefaultCookies()
   LXTAfMxeRzIESBiUjQygbqwJmWpKHo['clSharedContext']=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['clSharedContext']['value']
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.callRequestCookies_NF('Get',LXTAfMxeRzIESBiUjQygbqwJmWpKkv,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,params=LXTAfMxeRzIESBiUjQygbqwJmWpKOn,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKHs,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKHo,addCookie='lhpuuidh')
   if LXTAfMxeRzIESBiUjQygbqwJmWpKks.status_code!=200:
    LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 4-main status_code error')
    return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
   LXTAfMxeRzIESBiUjQygbqwJmWpKtD=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.extract_json(LXTAfMxeRzIESBiUjQygbqwJmWpKks.text,'reactContext')
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.dic_To_jsonfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_CONTEXTJSON_FILE3,LXTAfMxeRzIESBiUjQygbqwJmWpKtD)
   LXTAfMxeRzIESBiUjQygbqwJmWpKtY=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.extract_json(LXTAfMxeRzIESBiUjQygbqwJmWpKks.text,'falcorCache')
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.dic_To_jsonfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_FALCORJSON_FILE3,LXTAfMxeRzIESBiUjQygbqwJmWpKtY)
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 4-main error')
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  LXTAfMxeRzIESBiUjQygbqwJmWpKtN=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.Get_NF_BrowseSub(LXTAfMxeRzIESBiUjQygbqwJmWpKtD,LXTAfMxeRzIESBiUjQygbqwJmWpKtY)
  if LXTAfMxeRzIESBiUjQygbqwJmWpKtN==LXTAfMxeRzIESBiUjQygbqwJmWpKOu:
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOu 
  return LXTAfMxeRzIESBiUjQygbqwJmWpKOd
 def Get_NF_BrowseSub(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,LXTAfMxeRzIESBiUjQygbqwJmWpKtD,LXTAfMxeRzIESBiUjQygbqwJmWpKtY):
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKtV =LXTAfMxeRzIESBiUjQygbqwJmWpKtY['loco']['value'][1]
   LXTAfMxeRzIESBiUjQygbqwJmWpKtF=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.GetNoCache(timetype=2,minutes=180)
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['loco'] =LXTAfMxeRzIESBiUjQygbqwJmWpKtV
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['lhpuuidh']={'keyname':'lhpuuidh-browse-%s'%(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['nowGuid']),'value':'%s%s'%('KR%3AKO-KR%3A',LXTAfMxeRzIESBiUjQygbqwJmWpKtV),'expires':LXTAfMxeRzIESBiUjQygbqwJmWpKOc(LXTAfMxeRzIESBiUjQygbqwJmWpKtF/1000)}
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['lhpuuidhT']={'keyname':'lhpuuidh-browse-%s-T'%(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['nowGuid']),'value':LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKtF),'expires':LXTAfMxeRzIESBiUjQygbqwJmWpKOc(LXTAfMxeRzIESBiUjQygbqwJmWpKtF/1000)}
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.dic_To_jsonfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_SESSION_COOKIES3,LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF)
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl('pass 4-sub error')
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  return LXTAfMxeRzIESBiUjQygbqwJmWpKOd
 def NF_makestr_paths(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,paths):
  LXTAfMxeRzIESBiUjQygbqwJmWpKHF=[]
  if LXTAfMxeRzIESBiUjQygbqwJmWpKDC(paths,LXTAfMxeRzIESBiUjQygbqwJmWpKOc):
   return '%d'%(paths)
  elif LXTAfMxeRzIESBiUjQygbqwJmWpKDC(paths,LXTAfMxeRzIESBiUjQygbqwJmWpKOG):
   return '"%s"'%(paths)
  for LXTAfMxeRzIESBiUjQygbqwJmWpKtv in paths:
   if LXTAfMxeRzIESBiUjQygbqwJmWpKDC(LXTAfMxeRzIESBiUjQygbqwJmWpKtv,LXTAfMxeRzIESBiUjQygbqwJmWpKOc):
    LXTAfMxeRzIESBiUjQygbqwJmWpKHF.append('%d'%(LXTAfMxeRzIESBiUjQygbqwJmWpKtv))
   elif LXTAfMxeRzIESBiUjQygbqwJmWpKDC(LXTAfMxeRzIESBiUjQygbqwJmWpKtv,LXTAfMxeRzIESBiUjQygbqwJmWpKOG):
    LXTAfMxeRzIESBiUjQygbqwJmWpKHF.append('"%s"'%(LXTAfMxeRzIESBiUjQygbqwJmWpKtv))
   elif LXTAfMxeRzIESBiUjQygbqwJmWpKDC(LXTAfMxeRzIESBiUjQygbqwJmWpKtv,LXTAfMxeRzIESBiUjQygbqwJmWpKDH):
    LXTAfMxeRzIESBiUjQygbqwJmWpKHF.append('[%s]'%(','.join(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_makestr_paths(LXTAfMxeRzIESBiUjQygbqwJmWpKtv))))
   elif LXTAfMxeRzIESBiUjQygbqwJmWpKDC(LXTAfMxeRzIESBiUjQygbqwJmWpKtv,LXTAfMxeRzIESBiUjQygbqwJmWpKDt):
    LXTAfMxeRzIESBiUjQygbqwJmWpKto=''
    for LXTAfMxeRzIESBiUjQygbqwJmWpKts,LXTAfMxeRzIESBiUjQygbqwJmWpKtP in LXTAfMxeRzIESBiUjQygbqwJmWpKtv.items():
     LXTAfMxeRzIESBiUjQygbqwJmWpKto+='"%s":%s,'%(LXTAfMxeRzIESBiUjQygbqwJmWpKts,LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_makestr_paths(LXTAfMxeRzIESBiUjQygbqwJmWpKtP))
    LXTAfMxeRzIESBiUjQygbqwJmWpKHF.append('{%s}'%(LXTAfMxeRzIESBiUjQygbqwJmWpKto[:-1]))
  return LXTAfMxeRzIESBiUjQygbqwJmWpKHF
 def NF_Call_pathapi(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,LXTAfMxeRzIESBiUjQygbqwJmWpKOk,referer=''):
  LXTAfMxeRzIESBiUjQygbqwJmWpKta='%s/nq/website/memberapi/%s/pathEvaluator'%(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX,LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['identifier'])
  LXTAfMxeRzIESBiUjQygbqwJmWpKtO={'path':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_makestr_paths(LXTAfMxeRzIESBiUjQygbqwJmWpKOk),'authURL':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['SESSION']['authURL']}
  LXTAfMxeRzIESBiUjQygbqwJmWpKko=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.make_NF_ApiParams()
  LXTAfMxeRzIESBiUjQygbqwJmWpKHs={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':LXTAfMxeRzIESBiUjQygbqwJmWpKHs['referer']=referer
  LXTAfMxeRzIESBiUjQygbqwJmWpKtr=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.make_NF_XnetflixHeaders()
  LXTAfMxeRzIESBiUjQygbqwJmWpKHs.update(LXTAfMxeRzIESBiUjQygbqwJmWpKtr)
  LXTAfMxeRzIESBiUjQygbqwJmWpKHo=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.make_NF_DefaultCookies()
  LXTAfMxeRzIESBiUjQygbqwJmWpKHo[LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['lhpuuidh']['keyname']]=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['lhpuuidh']['value']
  LXTAfMxeRzIESBiUjQygbqwJmWpKHo[LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['lhpuuidhT']['keyname']]=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF['COOKIES']['lhpuuidhT']['value']
  LXTAfMxeRzIESBiUjQygbqwJmWpKHo['profilesNewSession']='0'
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.callRequestCookies('Post',LXTAfMxeRzIESBiUjQygbqwJmWpKta,payload=LXTAfMxeRzIESBiUjQygbqwJmWpKtO,params=LXTAfMxeRzIESBiUjQygbqwJmWpKko,headers=LXTAfMxeRzIESBiUjQygbqwJmWpKHs,cookies=LXTAfMxeRzIESBiUjQygbqwJmWpKHo)
   return LXTAfMxeRzIESBiUjQygbqwJmWpKks
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
   return LXTAfMxeRzIESBiUjQygbqwJmWpKOn
 def Get_Search_Netflix(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,search_key,page_int,byReference=''):
  LXTAfMxeRzIESBiUjQygbqwJmWpKtn=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.DERECTOR_LIMIT
  LXTAfMxeRzIESBiUjQygbqwJmWpKtu =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.CAST_LIMIT
  LXTAfMxeRzIESBiUjQygbqwJmWpKtl =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.GENRE_LIMIT
  LXTAfMxeRzIESBiUjQygbqwJmWpKtG =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_LIMIT*(page_int-1)
  LXTAfMxeRzIESBiUjQygbqwJmWpKtc =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_LIMIT*page_int 
  LXTAfMxeRzIESBiUjQygbqwJmWpKth="|%s"%(search_key)
  LXTAfMxeRzIESBiUjQygbqwJmWpKtd ='%s/search?%s'%(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOk=[["search","byTerm",LXTAfMxeRzIESBiUjQygbqwJmWpKth,"titles",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_LIMIT,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"summary"],["search","byTerm",LXTAfMxeRzIESBiUjQygbqwJmWpKth,"titles",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_LIMIT,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",LXTAfMxeRzIESBiUjQygbqwJmWpKth,"titles",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_LIMIT,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference","boxarts",[LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND2,LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_PORT],"jpg"],["search","byTerm",LXTAfMxeRzIESBiUjQygbqwJmWpKth,"titles",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_LIMIT,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference","interestingMoment",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND1,"jpg"],["search","byTerm",LXTAfMxeRzIESBiUjQygbqwJmWpKth,"titles",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_LIMIT,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference","storyArt",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND2,"jpg"],["search","byTerm",LXTAfMxeRzIESBiUjQygbqwJmWpKth,"titles",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_LIMIT,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference",["cast","creators","directors"],{"from":0,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtn},["id","name"]],["search","byTerm",LXTAfMxeRzIESBiUjQygbqwJmWpKth,"titles",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_LIMIT,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference","genres",{"from":0,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtl},["id","name"]],["search","byTerm",LXTAfMxeRzIESBiUjQygbqwJmWpKth,"titles",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NETFLIX_LIMIT,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LOGO,"png"],]
  else:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOk=[["search","byReference",byReference,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"summary"],["search","byReference",byReference,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference","boxarts",[LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND2,LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference","interestingMoment",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference","storyArt",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference",["cast","creators","directors"],{"from":0,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtn},["id","name"]],["search","byReference",byReference,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference","genres",{"from":0,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtl},["id","name"]],["search","byReference",byReference,{"from":LXTAfMxeRzIESBiUjQygbqwJmWpKtG,"to":LXTAfMxeRzIESBiUjQygbqwJmWpKtc},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LOGO,"png"],]
  try:
   LXTAfMxeRzIESBiUjQygbqwJmWpKks=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_Call_pathapi(LXTAfMxeRzIESBiUjQygbqwJmWpKOk,LXTAfMxeRzIESBiUjQygbqwJmWpKtd)
   LXTAfMxeRzIESBiUjQygbqwJmWpKkP=json.loads(LXTAfMxeRzIESBiUjQygbqwJmWpKks.text)
   LXTAfMxeRzIESBiUjQygbqwJmWpKkH.dic_To_jsonfile(LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_CONTEXTJSON_FILE4,LXTAfMxeRzIESBiUjQygbqwJmWpKkP)
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
  (LXTAfMxeRzIESBiUjQygbqwJmWpKkr,LXTAfMxeRzIESBiUjQygbqwJmWpKkF,byReference)=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.Search_Netflix_Make(LXTAfMxeRzIESBiUjQygbqwJmWpKkP)
  return LXTAfMxeRzIESBiUjQygbqwJmWpKkr,LXTAfMxeRzIESBiUjQygbqwJmWpKkF,byReference
 def Search_Netflix_Make(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,jsonSource):
  LXTAfMxeRzIESBiUjQygbqwJmWpKkr=[]
  LXTAfMxeRzIESBiUjQygbqwJmWpKkF =LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  LXTAfMxeRzIESBiUjQygbqwJmWpKOC=''
  LXTAfMxeRzIESBiUjQygbqwJmWpKOH=jsonSource.get('paths')[0][1]
  if LXTAfMxeRzIESBiUjQygbqwJmWpKOH=='byTerm':
   LXTAfMxeRzIESBiUjQygbqwJmWpKtG =jsonSource['paths'][0][5]['from']
   LXTAfMxeRzIESBiUjQygbqwJmWpKtc =jsonSource['paths'][0][5]['to']
  else:
   LXTAfMxeRzIESBiUjQygbqwJmWpKtG =jsonSource['paths'][0][3]['from']
   LXTAfMxeRzIESBiUjQygbqwJmWpKtc =jsonSource['paths'][0][3]['to']
  LXTAfMxeRzIESBiUjQygbqwJmWpKOC=LXTAfMxeRzIESBiUjQygbqwJmWpKDH(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  LXTAfMxeRzIESBiUjQygbqwJmWpKOt=jsonSource.get('jsonGraph').get('search').get('byReference').get(LXTAfMxeRzIESBiUjQygbqwJmWpKOC)
  LXTAfMxeRzIESBiUjQygbqwJmWpKOD =jsonSource.get('jsonGraph').get('videos')
  LXTAfMxeRzIESBiUjQygbqwJmWpKOY=jsonSource.get('jsonGraph').get('person')
  LXTAfMxeRzIESBiUjQygbqwJmWpKON=jsonSource.get('jsonGraph').get('genres')
  LXTAfMxeRzIESBiUjQygbqwJmWpKkF=LXTAfMxeRzIESBiUjQygbqwJmWpKOd if LXTAfMxeRzIESBiUjQygbqwJmWpKOt[LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKtc)]['reference']['$type']=='ref' else LXTAfMxeRzIESBiUjQygbqwJmWpKOu
  for LXTAfMxeRzIESBiUjQygbqwJmWpKOr in LXTAfMxeRzIESBiUjQygbqwJmWpKDO(LXTAfMxeRzIESBiUjQygbqwJmWpKtG,LXTAfMxeRzIESBiUjQygbqwJmWpKtc):
   if LXTAfMxeRzIESBiUjQygbqwJmWpKOt[LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKOr)]['reference']['$type']=='ref':
    LXTAfMxeRzIESBiUjQygbqwJmWpKkc =LXTAfMxeRzIESBiUjQygbqwJmWpKOt[LXTAfMxeRzIESBiUjQygbqwJmWpKOG(LXTAfMxeRzIESBiUjQygbqwJmWpKOr)]['reference']['value'][1]
    LXTAfMxeRzIESBiUjQygbqwJmWpKOV=LXTAfMxeRzIESBiUjQygbqwJmWpKOD[LXTAfMxeRzIESBiUjQygbqwJmWpKkc]
    LXTAfMxeRzIESBiUjQygbqwJmWpKHO =LXTAfMxeRzIESBiUjQygbqwJmWpKOV['title']['value']
    if LXTAfMxeRzIESBiUjQygbqwJmWpKOV['availability']['value']['isPlayable']==LXTAfMxeRzIESBiUjQygbqwJmWpKOu:
     continue
    LXTAfMxeRzIESBiUjQygbqwJmWpKkG =LXTAfMxeRzIESBiUjQygbqwJmWpKOV['summary']['value']['type']
    LXTAfMxeRzIESBiUjQygbqwJmWpKCP =0 if LXTAfMxeRzIESBiUjQygbqwJmWpKkG!='movie' else LXTAfMxeRzIESBiUjQygbqwJmWpKOV['runtime']['value']
    if LXTAfMxeRzIESBiUjQygbqwJmWpKOV['sequiturEvidence']['value']['value']:
     LXTAfMxeRzIESBiUjQygbqwJmWpKOF=LXTAfMxeRzIESBiUjQygbqwJmWpKOV['sequiturEvidence']['value']['value']['text']
    else:
     LXTAfMxeRzIESBiUjQygbqwJmWpKOF=''
    LXTAfMxeRzIESBiUjQygbqwJmWpKCV =LXTAfMxeRzIESBiUjQygbqwJmWpKOV['boxarts'][LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_PORT]['jpg']['value']['url']
    LXTAfMxeRzIESBiUjQygbqwJmWpKOv =LXTAfMxeRzIESBiUjQygbqwJmWpKOV['boxarts'][LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND2]['jpg']['value']['url']
    LXTAfMxeRzIESBiUjQygbqwJmWpKCF=''
    if 'value' in LXTAfMxeRzIESBiUjQygbqwJmWpKOV['storyArt'][LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND2]['jpg']:
     LXTAfMxeRzIESBiUjQygbqwJmWpKCF =LXTAfMxeRzIESBiUjQygbqwJmWpKOV['storyArt'][LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND2]['jpg']['value']['url']
    if LXTAfMxeRzIESBiUjQygbqwJmWpKCF=='' and 'value' in LXTAfMxeRzIESBiUjQygbqwJmWpKOV['interestingMoment'][LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND1]['jpg']:
     LXTAfMxeRzIESBiUjQygbqwJmWpKCF =LXTAfMxeRzIESBiUjQygbqwJmWpKOV['interestingMoment'][LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LAND1]['jpg']['value']['url']
    LXTAfMxeRzIESBiUjQygbqwJmWpKCc=''
    if 'value' in LXTAfMxeRzIESBiUjQygbqwJmWpKOV['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LOGO]['png']:
     LXTAfMxeRzIESBiUjQygbqwJmWpKCc=LXTAfMxeRzIESBiUjQygbqwJmWpKOV['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][LXTAfMxeRzIESBiUjQygbqwJmWpKkH.ART_SIZE_LOGO]['png']['value']['url']
    LXTAfMxeRzIESBiUjQygbqwJmWpKCs =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_Subid_List(LXTAfMxeRzIESBiUjQygbqwJmWpKOV['genres'])
    for i in LXTAfMxeRzIESBiUjQygbqwJmWpKDO(LXTAfMxeRzIESBiUjQygbqwJmWpKDY(LXTAfMxeRzIESBiUjQygbqwJmWpKCs)):
     LXTAfMxeRzIESBiUjQygbqwJmWpKCs[i]=LXTAfMxeRzIESBiUjQygbqwJmWpKON[LXTAfMxeRzIESBiUjQygbqwJmWpKCs[i]]['name']['value']
    LXTAfMxeRzIESBiUjQygbqwJmWpKCo=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_Subid_List(LXTAfMxeRzIESBiUjQygbqwJmWpKOV['directors'])
    LXTAfMxeRzIESBiUjQygbqwJmWpKOo =LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_Subid_List(LXTAfMxeRzIESBiUjQygbqwJmWpKOV['creators'])
    LXTAfMxeRzIESBiUjQygbqwJmWpKCo.extend(LXTAfMxeRzIESBiUjQygbqwJmWpKOo)
    for i in LXTAfMxeRzIESBiUjQygbqwJmWpKDO(LXTAfMxeRzIESBiUjQygbqwJmWpKDY(LXTAfMxeRzIESBiUjQygbqwJmWpKCo)):
     LXTAfMxeRzIESBiUjQygbqwJmWpKCo[i]=LXTAfMxeRzIESBiUjQygbqwJmWpKOY[LXTAfMxeRzIESBiUjQygbqwJmWpKCo[i]]['name']['value']
    LXTAfMxeRzIESBiUjQygbqwJmWpKCv=LXTAfMxeRzIESBiUjQygbqwJmWpKkH.NF_Subid_List(LXTAfMxeRzIESBiUjQygbqwJmWpKOV['cast'])
    for i in LXTAfMxeRzIESBiUjQygbqwJmWpKDO(LXTAfMxeRzIESBiUjQygbqwJmWpKDY(LXTAfMxeRzIESBiUjQygbqwJmWpKCv)):
     LXTAfMxeRzIESBiUjQygbqwJmWpKCv[i]=LXTAfMxeRzIESBiUjQygbqwJmWpKOY[LXTAfMxeRzIESBiUjQygbqwJmWpKCv[i]]['name']['value']
    if 'maturityDescription' in LXTAfMxeRzIESBiUjQygbqwJmWpKOV['maturity']['value']['rating']:
     LXTAfMxeRzIESBiUjQygbqwJmWpKCa=LXTAfMxeRzIESBiUjQygbqwJmWpKOV['maturity']['value']['rating']['maturityDescription']
    LXTAfMxeRzIESBiUjQygbqwJmWpKCk={'videoid':LXTAfMxeRzIESBiUjQygbqwJmWpKkc,'vidtype':LXTAfMxeRzIESBiUjQygbqwJmWpKkG,'title':LXTAfMxeRzIESBiUjQygbqwJmWpKHO,'mpaa':LXTAfMxeRzIESBiUjQygbqwJmWpKCa,'regularSynopsis':LXTAfMxeRzIESBiUjQygbqwJmWpKOV['regularSynopsis']['value'],'dpSupplemental':LXTAfMxeRzIESBiUjQygbqwJmWpKOV['dpSupplementalMessage']['value'],'sequiturEvidence':LXTAfMxeRzIESBiUjQygbqwJmWpKOF,'thumbnail':{'poster':LXTAfMxeRzIESBiUjQygbqwJmWpKCV,'thumb':LXTAfMxeRzIESBiUjQygbqwJmWpKCF,'fanart':LXTAfMxeRzIESBiUjQygbqwJmWpKOv,'clearlogo':LXTAfMxeRzIESBiUjQygbqwJmWpKCc},'year':LXTAfMxeRzIESBiUjQygbqwJmWpKOV['releaseYear']['value'],'duration':LXTAfMxeRzIESBiUjQygbqwJmWpKCP,'info_genre':LXTAfMxeRzIESBiUjQygbqwJmWpKCs,'director':LXTAfMxeRzIESBiUjQygbqwJmWpKCo,'cast':LXTAfMxeRzIESBiUjQygbqwJmWpKCv,}
    LXTAfMxeRzIESBiUjQygbqwJmWpKkr.append(LXTAfMxeRzIESBiUjQygbqwJmWpKCk)
  return LXTAfMxeRzIESBiUjQygbqwJmWpKkr,LXTAfMxeRzIESBiUjQygbqwJmWpKkF,LXTAfMxeRzIESBiUjQygbqwJmWpKOC
 def NF_Subid_List(LXTAfMxeRzIESBiUjQygbqwJmWpKkH,subJson):
  LXTAfMxeRzIESBiUjQygbqwJmWpKOs=[]
  try:
   for i in LXTAfMxeRzIESBiUjQygbqwJmWpKDO(LXTAfMxeRzIESBiUjQygbqwJmWpKDY(subJson)):
    if subJson.get(LXTAfMxeRzIESBiUjQygbqwJmWpKOG(i)).get('$type')!='ref':break
    LXTAfMxeRzIESBiUjQygbqwJmWpKOP=subJson.get(LXTAfMxeRzIESBiUjQygbqwJmWpKOG(i)).get('value')[1]
    LXTAfMxeRzIESBiUjQygbqwJmWpKOs.append(LXTAfMxeRzIESBiUjQygbqwJmWpKOP)
  except LXTAfMxeRzIESBiUjQygbqwJmWpKOh as exception:
   LXTAfMxeRzIESBiUjQygbqwJmWpKOl(exception)
  return LXTAfMxeRzIESBiUjQygbqwJmWpKOs
# Created by pyminifier (https://github.com/liftoff/pyminifier)
