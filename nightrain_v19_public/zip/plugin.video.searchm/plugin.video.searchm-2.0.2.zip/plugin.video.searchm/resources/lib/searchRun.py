__author__="NightRain"
uLWzVRpNYrGPBlCHvQAmwqJbijkans=object
uLWzVRpNYrGPBlCHvQAmwqJbijkanf=None
uLWzVRpNYrGPBlCHvQAmwqJbijkanX=True
uLWzVRpNYrGPBlCHvQAmwqJbijkanT=False
uLWzVRpNYrGPBlCHvQAmwqJbijkand=type
uLWzVRpNYrGPBlCHvQAmwqJbijkanI=dict
uLWzVRpNYrGPBlCHvQAmwqJbijkaco=open
uLWzVRpNYrGPBlCHvQAmwqJbijkacF=len
uLWzVRpNYrGPBlCHvQAmwqJbijkacy=Exception
uLWzVRpNYrGPBlCHvQAmwqJbijkacg=str
uLWzVRpNYrGPBlCHvQAmwqJbijkacn=int
uLWzVRpNYrGPBlCHvQAmwqJbijkact=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
uLWzVRpNYrGPBlCHvQAmwqJbijkaoy=[{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
uLWzVRpNYrGPBlCHvQAmwqJbijkaog={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},}
uLWzVRpNYrGPBlCHvQAmwqJbijkaon=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
uLWzVRpNYrGPBlCHvQAmwqJbijkaoc =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class uLWzVRpNYrGPBlCHvQAmwqJbijkaoF(uLWzVRpNYrGPBlCHvQAmwqJbijkans):
 def __init__(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,uLWzVRpNYrGPBlCHvQAmwqJbijkaoE,uLWzVRpNYrGPBlCHvQAmwqJbijkaoU,uLWzVRpNYrGPBlCHvQAmwqJbijkaoM):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot._addon_url =uLWzVRpNYrGPBlCHvQAmwqJbijkaoE
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot._addon_handle=uLWzVRpNYrGPBlCHvQAmwqJbijkaoU
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot.main_params =uLWzVRpNYrGPBlCHvQAmwqJbijkaoM
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj =LXTAfMxeRzIESBiUjQygbqwJmWpKkC() 
 def addon_noti(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,sting):
  try:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaoe=xbmcgui.Dialog()
   uLWzVRpNYrGPBlCHvQAmwqJbijkaoe.notification(__addonname__,sting)
  except:
   uLWzVRpNYrGPBlCHvQAmwqJbijkanf
 def addon_log(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,string):
  try:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaoK=string.encode('utf-8','ignore')
  except:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaoK='addonException: addon_log'
  uLWzVRpNYrGPBlCHvQAmwqJbijkaoD=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,uLWzVRpNYrGPBlCHvQAmwqJbijkaoK),level=uLWzVRpNYrGPBlCHvQAmwqJbijkaoD)
 def get_keyboard_input(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,uLWzVRpNYrGPBlCHvQAmwqJbijkaod):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaoS=uLWzVRpNYrGPBlCHvQAmwqJbijkanf
  kb=xbmc.Keyboard()
  kb.setHeading(uLWzVRpNYrGPBlCHvQAmwqJbijkaod)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   uLWzVRpNYrGPBlCHvQAmwqJbijkaoS=kb.getText()
  return uLWzVRpNYrGPBlCHvQAmwqJbijkaoS
 def get_settings_menubookmark(uLWzVRpNYrGPBlCHvQAmwqJbijkaot):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaox=uLWzVRpNYrGPBlCHvQAmwqJbijkanX if __addon__.getSetting('menu_bookmark')=='true' else uLWzVRpNYrGPBlCHvQAmwqJbijkanT
  return(uLWzVRpNYrGPBlCHvQAmwqJbijkaox)
 def get_settings_makebookmark(uLWzVRpNYrGPBlCHvQAmwqJbijkaot):
  return uLWzVRpNYrGPBlCHvQAmwqJbijkanX if __addon__.getSetting('make_bookmark')=='true' else uLWzVRpNYrGPBlCHvQAmwqJbijkanT
 def get_settings_select_info(uLWzVRpNYrGPBlCHvQAmwqJbijkaot):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaoO=[]
  if __addon__.getSetting('netflixyn')=='true':uLWzVRpNYrGPBlCHvQAmwqJbijkaoO.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':uLWzVRpNYrGPBlCHvQAmwqJbijkaoO.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':uLWzVRpNYrGPBlCHvQAmwqJbijkaoO.append('tving')
  if __addon__.getSetting('watchayn')=='true':uLWzVRpNYrGPBlCHvQAmwqJbijkaoO.append('watcha')
  return uLWzVRpNYrGPBlCHvQAmwqJbijkaoO
 def get_settings_netflix(uLWzVRpNYrGPBlCHvQAmwqJbijkaot):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaos =__addon__.getSetting('nfid')
  uLWzVRpNYrGPBlCHvQAmwqJbijkaof =__addon__.getSetting('nfpw')
  uLWzVRpNYrGPBlCHvQAmwqJbijkaoX=__addon__.getSetting('nf_profile')
  return(uLWzVRpNYrGPBlCHvQAmwqJbijkaos,uLWzVRpNYrGPBlCHvQAmwqJbijkaof,uLWzVRpNYrGPBlCHvQAmwqJbijkaoX)
 def add_dir(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,label,sublabel='',img='',infoLabels=uLWzVRpNYrGPBlCHvQAmwqJbijkanf,isFolder=uLWzVRpNYrGPBlCHvQAmwqJbijkanX,params='',isLink=uLWzVRpNYrGPBlCHvQAmwqJbijkanT,ContextMenu=uLWzVRpNYrGPBlCHvQAmwqJbijkanf):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaoT='%s?%s'%(uLWzVRpNYrGPBlCHvQAmwqJbijkaot._addon_url,urllib.parse.urlencode(params))
  if sublabel:uLWzVRpNYrGPBlCHvQAmwqJbijkaod='%s < %s >'%(label,sublabel)
  else: uLWzVRpNYrGPBlCHvQAmwqJbijkaod=label
  if not img:img='DefaultFolder.png'
  uLWzVRpNYrGPBlCHvQAmwqJbijkaoI=xbmcgui.ListItem(uLWzVRpNYrGPBlCHvQAmwqJbijkaod)
  if uLWzVRpNYrGPBlCHvQAmwqJbijkand(img)==uLWzVRpNYrGPBlCHvQAmwqJbijkanI:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaoI.setArt(img)
  else:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaoI.setArt({'thumb':img,'poster':img})
  if infoLabels:uLWzVRpNYrGPBlCHvQAmwqJbijkaoI.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaoI.setProperty('IsPlayable','true')
  if ContextMenu:uLWzVRpNYrGPBlCHvQAmwqJbijkaoI.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(uLWzVRpNYrGPBlCHvQAmwqJbijkaot._addon_handle,uLWzVRpNYrGPBlCHvQAmwqJbijkaoT,uLWzVRpNYrGPBlCHvQAmwqJbijkaoI,isFolder)
 def Load_Searched_List(uLWzVRpNYrGPBlCHvQAmwqJbijkaot):
  try:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFo=uLWzVRpNYrGPBlCHvQAmwqJbijkaoc
   fp=uLWzVRpNYrGPBlCHvQAmwqJbijkaco(uLWzVRpNYrGPBlCHvQAmwqJbijkaFo,'r',-1,'utf-8')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFy=fp.readlines()
   fp.close()
  except:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFy=[]
  return uLWzVRpNYrGPBlCHvQAmwqJbijkaFy
 def Save_Searched_List(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,uLWzVRpNYrGPBlCHvQAmwqJbijkago):
  try:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFo=uLWzVRpNYrGPBlCHvQAmwqJbijkaoc
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFg=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.Load_Searched_List() 
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFn={'skey':uLWzVRpNYrGPBlCHvQAmwqJbijkago.strip()}
   fp=uLWzVRpNYrGPBlCHvQAmwqJbijkaco(uLWzVRpNYrGPBlCHvQAmwqJbijkaFo,'w',-1,'utf-8')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFc=urllib.parse.urlencode(uLWzVRpNYrGPBlCHvQAmwqJbijkaFn)
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFc=uLWzVRpNYrGPBlCHvQAmwqJbijkaFc+'\n'
   fp.write(uLWzVRpNYrGPBlCHvQAmwqJbijkaFc)
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFt=0
   for uLWzVRpNYrGPBlCHvQAmwqJbijkaFE in uLWzVRpNYrGPBlCHvQAmwqJbijkaFg:
    uLWzVRpNYrGPBlCHvQAmwqJbijkaFU=uLWzVRpNYrGPBlCHvQAmwqJbijkanI(urllib.parse.parse_qsl(uLWzVRpNYrGPBlCHvQAmwqJbijkaFE))
    uLWzVRpNYrGPBlCHvQAmwqJbijkaFM=uLWzVRpNYrGPBlCHvQAmwqJbijkaFn.get('skey').strip()
    uLWzVRpNYrGPBlCHvQAmwqJbijkaFh=uLWzVRpNYrGPBlCHvQAmwqJbijkaFU.get('skey').strip()
    if uLWzVRpNYrGPBlCHvQAmwqJbijkaFM!=uLWzVRpNYrGPBlCHvQAmwqJbijkaFh:
     fp.write(uLWzVRpNYrGPBlCHvQAmwqJbijkaFE)
     uLWzVRpNYrGPBlCHvQAmwqJbijkaFt+=1
     if uLWzVRpNYrGPBlCHvQAmwqJbijkaFt>=50:break
   fp.close()
  except:
   uLWzVRpNYrGPBlCHvQAmwqJbijkanf
 def dp_Search_History(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,args):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaFe=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.Load_Searched_List()
  for uLWzVRpNYrGPBlCHvQAmwqJbijkaFK in uLWzVRpNYrGPBlCHvQAmwqJbijkaFe:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFD=uLWzVRpNYrGPBlCHvQAmwqJbijkanI(urllib.parse.parse_qsl(uLWzVRpNYrGPBlCHvQAmwqJbijkaFK))
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFS=uLWzVRpNYrGPBlCHvQAmwqJbijkaFD.get('skey').strip()
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFx={'mode':'TOTAL_SEARCH','search_key':uLWzVRpNYrGPBlCHvQAmwqJbijkaFS,}
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFO={'mode':'HISTORY_REMOVE','skey':uLWzVRpNYrGPBlCHvQAmwqJbijkaFS,'delmode':'ONE',}
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFs=urllib.parse.urlencode(uLWzVRpNYrGPBlCHvQAmwqJbijkaFO)
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFf=[('선택된 검색어 ( %s ) 삭제'%(uLWzVRpNYrGPBlCHvQAmwqJbijkaFS),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(uLWzVRpNYrGPBlCHvQAmwqJbijkaFs))]
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.add_dir(uLWzVRpNYrGPBlCHvQAmwqJbijkaFS,sublabel='',img=uLWzVRpNYrGPBlCHvQAmwqJbijkanf,infoLabels=uLWzVRpNYrGPBlCHvQAmwqJbijkanf,isFolder=uLWzVRpNYrGPBlCHvQAmwqJbijkanX,params=uLWzVRpNYrGPBlCHvQAmwqJbijkaFx,ContextMenu=uLWzVRpNYrGPBlCHvQAmwqJbijkaFf)
  uLWzVRpNYrGPBlCHvQAmwqJbijkaFT={'plot':'검색목록 전체를 삭제합니다.'}
  uLWzVRpNYrGPBlCHvQAmwqJbijkaod='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  uLWzVRpNYrGPBlCHvQAmwqJbijkaFx={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  uLWzVRpNYrGPBlCHvQAmwqJbijkaFd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot.add_dir(uLWzVRpNYrGPBlCHvQAmwqJbijkaod,sublabel='',img=uLWzVRpNYrGPBlCHvQAmwqJbijkaFd,infoLabels=uLWzVRpNYrGPBlCHvQAmwqJbijkaFT,isFolder=uLWzVRpNYrGPBlCHvQAmwqJbijkanT,params=uLWzVRpNYrGPBlCHvQAmwqJbijkaFx,isLink=uLWzVRpNYrGPBlCHvQAmwqJbijkanX)
  xbmcplugin.endOfDirectory(uLWzVRpNYrGPBlCHvQAmwqJbijkaot._addon_handle,cacheToDisc=uLWzVRpNYrGPBlCHvQAmwqJbijkanT)
 def Delete_History_List(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,uLWzVRpNYrGPBlCHvQAmwqJbijkaFS,uLWzVRpNYrGPBlCHvQAmwqJbijkayF):
  if uLWzVRpNYrGPBlCHvQAmwqJbijkayF=='ALL':
   try:
    uLWzVRpNYrGPBlCHvQAmwqJbijkaFo=uLWzVRpNYrGPBlCHvQAmwqJbijkaoc
    fp=uLWzVRpNYrGPBlCHvQAmwqJbijkaco(uLWzVRpNYrGPBlCHvQAmwqJbijkaFo,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    uLWzVRpNYrGPBlCHvQAmwqJbijkanf
  else:
   try:
    uLWzVRpNYrGPBlCHvQAmwqJbijkaFo=uLWzVRpNYrGPBlCHvQAmwqJbijkaoc
    uLWzVRpNYrGPBlCHvQAmwqJbijkaFg=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.Load_Searched_List() 
    fp=uLWzVRpNYrGPBlCHvQAmwqJbijkaco(uLWzVRpNYrGPBlCHvQAmwqJbijkaFo,'w',-1,'utf-8')
    for uLWzVRpNYrGPBlCHvQAmwqJbijkaFE in uLWzVRpNYrGPBlCHvQAmwqJbijkaFg:
     uLWzVRpNYrGPBlCHvQAmwqJbijkaFU=uLWzVRpNYrGPBlCHvQAmwqJbijkanI(urllib.parse.parse_qsl(uLWzVRpNYrGPBlCHvQAmwqJbijkaFE))
     uLWzVRpNYrGPBlCHvQAmwqJbijkayo=uLWzVRpNYrGPBlCHvQAmwqJbijkaFU.get('skey').strip()
     if uLWzVRpNYrGPBlCHvQAmwqJbijkaFS!=uLWzVRpNYrGPBlCHvQAmwqJbijkayo:
      fp.write(uLWzVRpNYrGPBlCHvQAmwqJbijkaFE)
    fp.close()
   except:
    uLWzVRpNYrGPBlCHvQAmwqJbijkanf
 def dp_History_Delete(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,args):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaFS =args.get('skey') 
  uLWzVRpNYrGPBlCHvQAmwqJbijkayF=args.get('delmode')
  uLWzVRpNYrGPBlCHvQAmwqJbijkaoe=xbmcgui.Dialog()
  if uLWzVRpNYrGPBlCHvQAmwqJbijkayF=='ALL':
   uLWzVRpNYrGPBlCHvQAmwqJbijkayg=uLWzVRpNYrGPBlCHvQAmwqJbijkaoe.yesno(__language__(30913).encode('utf8'),__language__(30915).encode('utf8'))
  else:
   uLWzVRpNYrGPBlCHvQAmwqJbijkayg=uLWzVRpNYrGPBlCHvQAmwqJbijkaoe.yesno(__language__(30914).encode('utf8'),__language__(30915).encode('utf8'))
  if uLWzVRpNYrGPBlCHvQAmwqJbijkayg==uLWzVRpNYrGPBlCHvQAmwqJbijkanT:sys.exit()
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot.Delete_History_List(uLWzVRpNYrGPBlCHvQAmwqJbijkaFS,uLWzVRpNYrGPBlCHvQAmwqJbijkayF)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(uLWzVRpNYrGPBlCHvQAmwqJbijkaot):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaox=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.get_settings_menubookmark()
  for uLWzVRpNYrGPBlCHvQAmwqJbijkayn in uLWzVRpNYrGPBlCHvQAmwqJbijkaoy:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaod=uLWzVRpNYrGPBlCHvQAmwqJbijkayn.get('title')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFd=''
   if uLWzVRpNYrGPBlCHvQAmwqJbijkayn.get('mode')=='MENU_BOOKMARK' and uLWzVRpNYrGPBlCHvQAmwqJbijkaox==uLWzVRpNYrGPBlCHvQAmwqJbijkanT:continue
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFx={'mode':uLWzVRpNYrGPBlCHvQAmwqJbijkayn.get('mode')}
   if uLWzVRpNYrGPBlCHvQAmwqJbijkayn.get('mode')in['XXX','MENU_BOOKMARK']:
    uLWzVRpNYrGPBlCHvQAmwqJbijkayc=uLWzVRpNYrGPBlCHvQAmwqJbijkanT
    uLWzVRpNYrGPBlCHvQAmwqJbijkayt =uLWzVRpNYrGPBlCHvQAmwqJbijkanX
   else:
    uLWzVRpNYrGPBlCHvQAmwqJbijkayc=uLWzVRpNYrGPBlCHvQAmwqJbijkanX
    uLWzVRpNYrGPBlCHvQAmwqJbijkayt =uLWzVRpNYrGPBlCHvQAmwqJbijkanT
   if 'icon' in uLWzVRpNYrGPBlCHvQAmwqJbijkayn:uLWzVRpNYrGPBlCHvQAmwqJbijkaFd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',uLWzVRpNYrGPBlCHvQAmwqJbijkayn.get('icon')) 
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.add_dir(uLWzVRpNYrGPBlCHvQAmwqJbijkaod,sublabel='',img=uLWzVRpNYrGPBlCHvQAmwqJbijkaFd,infoLabels=uLWzVRpNYrGPBlCHvQAmwqJbijkanf,isFolder=uLWzVRpNYrGPBlCHvQAmwqJbijkayc,params=uLWzVRpNYrGPBlCHvQAmwqJbijkaFx,isLink=uLWzVRpNYrGPBlCHvQAmwqJbijkayt)
  xbmcplugin.endOfDirectory(uLWzVRpNYrGPBlCHvQAmwqJbijkaot._addon_handle)
 def option_check(uLWzVRpNYrGPBlCHvQAmwqJbijkaot):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaoO=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.get_settings_select_info()
  if uLWzVRpNYrGPBlCHvQAmwqJbijkacF(uLWzVRpNYrGPBlCHvQAmwqJbijkaoO)==0:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaoe=xbmcgui.Dialog()
   uLWzVRpNYrGPBlCHvQAmwqJbijkayg=uLWzVRpNYrGPBlCHvQAmwqJbijkaoe.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if uLWzVRpNYrGPBlCHvQAmwqJbijkayg==uLWzVRpNYrGPBlCHvQAmwqJbijkanX:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in uLWzVRpNYrGPBlCHvQAmwqJbijkaoO:
   (uLWzVRpNYrGPBlCHvQAmwqJbijkayE,uLWzVRpNYrGPBlCHvQAmwqJbijkayU,uLWzVRpNYrGPBlCHvQAmwqJbijkayM)=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.get_settings_netflix()
   if uLWzVRpNYrGPBlCHvQAmwqJbijkayE=='' or uLWzVRpNYrGPBlCHvQAmwqJbijkayU=='':
    uLWzVRpNYrGPBlCHvQAmwqJbijkaoe=xbmcgui.Dialog()
    uLWzVRpNYrGPBlCHvQAmwqJbijkayg=uLWzVRpNYrGPBlCHvQAmwqJbijkaoe.yesno(__language__(30902).encode('utf8'),__language__(30903).encode('utf8'))
    if uLWzVRpNYrGPBlCHvQAmwqJbijkayg==uLWzVRpNYrGPBlCHvQAmwqJbijkanX:
     __addon__.openSettings()
     sys.exit()
    else:
     sys.exit()
   if uLWzVRpNYrGPBlCHvQAmwqJbijkaot.NF_cookiefile_check()==uLWzVRpNYrGPBlCHvQAmwqJbijkanT:
    uLWzVRpNYrGPBlCHvQAmwqJbijkaoe=xbmcgui.Dialog()
    uLWzVRpNYrGPBlCHvQAmwqJbijkayg=uLWzVRpNYrGPBlCHvQAmwqJbijkaoe.yesno(__language__(30907).encode('utf8'),__language__(30916).encode('utf8'))
    if uLWzVRpNYrGPBlCHvQAmwqJbijkayg==uLWzVRpNYrGPBlCHvQAmwqJbijkanX:
     if uLWzVRpNYrGPBlCHvQAmwqJbijkaot.NF_login(inputCheck=uLWzVRpNYrGPBlCHvQAmwqJbijkanT)==uLWzVRpNYrGPBlCHvQAmwqJbijkanT:
      sys.exit()
    else:
     sys.exit()
 def NF_cookiefile_check(uLWzVRpNYrGPBlCHvQAmwqJbijkaot):
  uLWzVRpNYrGPBlCHvQAmwqJbijkayh={}
  try: 
   fp=uLWzVRpNYrGPBlCHvQAmwqJbijkaco(uLWzVRpNYrGPBlCHvQAmwqJbijkaon,'r',-1,'utf-8')
   uLWzVRpNYrGPBlCHvQAmwqJbijkayh= json.load(fp)
   fp.close()
  except uLWzVRpNYrGPBlCHvQAmwqJbijkacy as exception:
   return uLWzVRpNYrGPBlCHvQAmwqJbijkanT
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.NF=uLWzVRpNYrGPBlCHvQAmwqJbijkayh
  (uLWzVRpNYrGPBlCHvQAmwqJbijkayE,uLWzVRpNYrGPBlCHvQAmwqJbijkayU,uLWzVRpNYrGPBlCHvQAmwqJbijkayM)=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.get_settings_netflix()
  (uLWzVRpNYrGPBlCHvQAmwqJbijkaye,uLWzVRpNYrGPBlCHvQAmwqJbijkayK,uLWzVRpNYrGPBlCHvQAmwqJbijkayD)=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Load_session_acount()
  if uLWzVRpNYrGPBlCHvQAmwqJbijkayE!=uLWzVRpNYrGPBlCHvQAmwqJbijkaye or uLWzVRpNYrGPBlCHvQAmwqJbijkayU!=uLWzVRpNYrGPBlCHvQAmwqJbijkayK or uLWzVRpNYrGPBlCHvQAmwqJbijkayM!=uLWzVRpNYrGPBlCHvQAmwqJbijkacg(uLWzVRpNYrGPBlCHvQAmwqJbijkayD):
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Init_NF_Total()
   return uLWzVRpNYrGPBlCHvQAmwqJbijkanT
  return uLWzVRpNYrGPBlCHvQAmwqJbijkanX
 def NF_login(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,inputCheck=uLWzVRpNYrGPBlCHvQAmwqJbijkanX):
  (uLWzVRpNYrGPBlCHvQAmwqJbijkayS,uLWzVRpNYrGPBlCHvQAmwqJbijkayx,uLWzVRpNYrGPBlCHvQAmwqJbijkayO)=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.get_settings_netflix()
  if inputCheck==uLWzVRpNYrGPBlCHvQAmwqJbijkanX:
   if uLWzVRpNYrGPBlCHvQAmwqJbijkayS=='' or uLWzVRpNYrGPBlCHvQAmwqJbijkayx=='':
    uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_noti(__language__(30902).encode('utf-8'))
    return uLWzVRpNYrGPBlCHvQAmwqJbijkanT
   uLWzVRpNYrGPBlCHvQAmwqJbijkaoe=xbmcgui.Dialog()
   uLWzVRpNYrGPBlCHvQAmwqJbijkayg=uLWzVRpNYrGPBlCHvQAmwqJbijkaoe.yesno(__language__(30911).encode('utf8'),__language__(30912).encode('utf8'))
   if uLWzVRpNYrGPBlCHvQAmwqJbijkayg==uLWzVRpNYrGPBlCHvQAmwqJbijkanT:
    return uLWzVRpNYrGPBlCHvQAmwqJbijkanT 
  uLWzVRpNYrGPBlCHvQAmwqJbijkays=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_NF_BaseCookies()
  if uLWzVRpNYrGPBlCHvQAmwqJbijkays:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_log('pass1 ok!')
  else:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_log('pass1 error!')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_noti(__language__(30905).encode('utf-8'))
   return uLWzVRpNYrGPBlCHvQAmwqJbijkanT 
  uLWzVRpNYrGPBlCHvQAmwqJbijkays=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_NF_BaseLogin(uLWzVRpNYrGPBlCHvQAmwqJbijkayS,uLWzVRpNYrGPBlCHvQAmwqJbijkayx,uLWzVRpNYrGPBlCHvQAmwqJbijkayO)
  if uLWzVRpNYrGPBlCHvQAmwqJbijkays:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_log('pass2 ok!')
  else:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_log('pass2 error!')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_noti(__language__(30905).encode('utf-8'))
   return uLWzVRpNYrGPBlCHvQAmwqJbijkanT 
  uLWzVRpNYrGPBlCHvQAmwqJbijkays=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_NF_ActivateProfile()
  if uLWzVRpNYrGPBlCHvQAmwqJbijkays:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_log('pass3 ok!')
  else:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_log('pass3 error!')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_noti(__language__(30905).encode('utf-8'))
   return uLWzVRpNYrGPBlCHvQAmwqJbijkanT 
  uLWzVRpNYrGPBlCHvQAmwqJbijkays=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_NF_BrowseMain()
  if uLWzVRpNYrGPBlCHvQAmwqJbijkays:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_log('pass4 ok!')
  else:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_log('pass4 error!')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_noti(__language__(30905).encode('utf-8'))
   return uLWzVRpNYrGPBlCHvQAmwqJbijkanT 
  uLWzVRpNYrGPBlCHvQAmwqJbijkayf =uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_Now_Datetime()
  uLWzVRpNYrGPBlCHvQAmwqJbijkayX=uLWzVRpNYrGPBlCHvQAmwqJbijkayf+datetime.timedelta(days=uLWzVRpNYrGPBlCHvQAmwqJbijkacn(__addon__.getSetting('cache_ttl')))
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.NF['SESSION']['limitdate']=uLWzVRpNYrGPBlCHvQAmwqJbijkayX.strftime('%Y-%m-%d')
  try: 
   fp=uLWzVRpNYrGPBlCHvQAmwqJbijkaco(uLWzVRpNYrGPBlCHvQAmwqJbijkaon,'w',-1,'utf-8')
   json.dump(uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.NF,fp)
   fp.close()
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_log('pass5 save ok!')
  except uLWzVRpNYrGPBlCHvQAmwqJbijkacy as exception:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_log('pass5 save error!')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_noti(__language__(30905).encode('utf-8'))
   return uLWzVRpNYrGPBlCHvQAmwqJbijkanT
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_noti(__language__(30904).encode('utf-8'))
  return uLWzVRpNYrGPBlCHvQAmwqJbijkanX
 def NF_logout(uLWzVRpNYrGPBlCHvQAmwqJbijkaot):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaoe=xbmcgui.Dialog()
  uLWzVRpNYrGPBlCHvQAmwqJbijkayg=uLWzVRpNYrGPBlCHvQAmwqJbijkaoe.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if uLWzVRpNYrGPBlCHvQAmwqJbijkayg==uLWzVRpNYrGPBlCHvQAmwqJbijkanT:return 
  if os.path.isfile(uLWzVRpNYrGPBlCHvQAmwqJbijkaon):os.remove(uLWzVRpNYrGPBlCHvQAmwqJbijkaon)
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,uLWzVRpNYrGPBlCHvQAmwqJbijkagF):
  uLWzVRpNYrGPBlCHvQAmwqJbijkayT=''
  uLWzVRpNYrGPBlCHvQAmwqJbijkayd=7
  try:
   for i in uLWzVRpNYrGPBlCHvQAmwqJbijkact(uLWzVRpNYrGPBlCHvQAmwqJbijkacF(uLWzVRpNYrGPBlCHvQAmwqJbijkagF)):
    if i>=uLWzVRpNYrGPBlCHvQAmwqJbijkayd:
     uLWzVRpNYrGPBlCHvQAmwqJbijkayT=uLWzVRpNYrGPBlCHvQAmwqJbijkayT+'...'
     break
    uLWzVRpNYrGPBlCHvQAmwqJbijkayT=uLWzVRpNYrGPBlCHvQAmwqJbijkayT+uLWzVRpNYrGPBlCHvQAmwqJbijkagF[i]['title']+'\n'
  except:
   return ''
  return uLWzVRpNYrGPBlCHvQAmwqJbijkayT
 def dp_Search_Group(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,args):
  uLWzVRpNYrGPBlCHvQAmwqJbijkaoO =uLWzVRpNYrGPBlCHvQAmwqJbijkaot.get_settings_select_info()
  uLWzVRpNYrGPBlCHvQAmwqJbijkayI=[]
  if 'search_key' in args:
   uLWzVRpNYrGPBlCHvQAmwqJbijkago=args.get('search_key')
  else:
   uLWzVRpNYrGPBlCHvQAmwqJbijkago=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not uLWzVRpNYrGPBlCHvQAmwqJbijkago:
    xbmcplugin.endOfDirectory(uLWzVRpNYrGPBlCHvQAmwqJbijkaot._addon_handle)
    return
  if 'wavve' in uLWzVRpNYrGPBlCHvQAmwqJbijkaoO:
   (uLWzVRpNYrGPBlCHvQAmwqJbijkagF,uLWzVRpNYrGPBlCHvQAmwqJbijkagy)=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_Search_Wavve(uLWzVRpNYrGPBlCHvQAmwqJbijkago,'TVSHOW',1)
   if uLWzVRpNYrGPBlCHvQAmwqJbijkacF(uLWzVRpNYrGPBlCHvQAmwqJbijkagF)>0:
    uLWzVRpNYrGPBlCHvQAmwqJbijkagn={'sType':'wavve_tvshow','sList':uLWzVRpNYrGPBlCHvQAmwqJbijkaot.MakeText_FreeList(uLWzVRpNYrGPBlCHvQAmwqJbijkagF),}
    uLWzVRpNYrGPBlCHvQAmwqJbijkayI.append(uLWzVRpNYrGPBlCHvQAmwqJbijkagn)
   (uLWzVRpNYrGPBlCHvQAmwqJbijkagF,uLWzVRpNYrGPBlCHvQAmwqJbijkagy)=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_Search_Wavve(uLWzVRpNYrGPBlCHvQAmwqJbijkago,'MOVIE',1)
   if uLWzVRpNYrGPBlCHvQAmwqJbijkacF(uLWzVRpNYrGPBlCHvQAmwqJbijkagF)>0:
    uLWzVRpNYrGPBlCHvQAmwqJbijkagn={'sType':'wavve_movie','sList':uLWzVRpNYrGPBlCHvQAmwqJbijkaot.MakeText_FreeList(uLWzVRpNYrGPBlCHvQAmwqJbijkagF),}
    uLWzVRpNYrGPBlCHvQAmwqJbijkayI.append(uLWzVRpNYrGPBlCHvQAmwqJbijkagn)
  if 'tving' in uLWzVRpNYrGPBlCHvQAmwqJbijkaoO:
   (uLWzVRpNYrGPBlCHvQAmwqJbijkagF,uLWzVRpNYrGPBlCHvQAmwqJbijkagy)=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_Search_Tving(uLWzVRpNYrGPBlCHvQAmwqJbijkago,'TVSHOW',1)
   if uLWzVRpNYrGPBlCHvQAmwqJbijkacF(uLWzVRpNYrGPBlCHvQAmwqJbijkagF)>0:
    uLWzVRpNYrGPBlCHvQAmwqJbijkagn={'sType':'tving_tvshow','sList':uLWzVRpNYrGPBlCHvQAmwqJbijkaot.MakeText_FreeList(uLWzVRpNYrGPBlCHvQAmwqJbijkagF),}
    uLWzVRpNYrGPBlCHvQAmwqJbijkayI.append(uLWzVRpNYrGPBlCHvQAmwqJbijkagn)
   (uLWzVRpNYrGPBlCHvQAmwqJbijkagF,uLWzVRpNYrGPBlCHvQAmwqJbijkagy)=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_Search_Tving(uLWzVRpNYrGPBlCHvQAmwqJbijkago,'MOVIE',1)
   if uLWzVRpNYrGPBlCHvQAmwqJbijkacF(uLWzVRpNYrGPBlCHvQAmwqJbijkagF)>0:
    uLWzVRpNYrGPBlCHvQAmwqJbijkagn={'sType':'tving_movie','sList':uLWzVRpNYrGPBlCHvQAmwqJbijkaot.MakeText_FreeList(uLWzVRpNYrGPBlCHvQAmwqJbijkagF),}
    uLWzVRpNYrGPBlCHvQAmwqJbijkayI.append(uLWzVRpNYrGPBlCHvQAmwqJbijkagn)
  if 'watcha' in uLWzVRpNYrGPBlCHvQAmwqJbijkaoO:
   (uLWzVRpNYrGPBlCHvQAmwqJbijkagF,uLWzVRpNYrGPBlCHvQAmwqJbijkagy)=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_Search_Watcha(uLWzVRpNYrGPBlCHvQAmwqJbijkago,1)
   if uLWzVRpNYrGPBlCHvQAmwqJbijkacF(uLWzVRpNYrGPBlCHvQAmwqJbijkagF)>0:
    uLWzVRpNYrGPBlCHvQAmwqJbijkagn={'sType':'watcha_list','sList':uLWzVRpNYrGPBlCHvQAmwqJbijkaot.MakeText_FreeList(uLWzVRpNYrGPBlCHvQAmwqJbijkagF),}
    uLWzVRpNYrGPBlCHvQAmwqJbijkayI.append(uLWzVRpNYrGPBlCHvQAmwqJbijkagn)
  if 'netflix' in uLWzVRpNYrGPBlCHvQAmwqJbijkaoO:
   (uLWzVRpNYrGPBlCHvQAmwqJbijkagF,uLWzVRpNYrGPBlCHvQAmwqJbijkagy,uLWzVRpNYrGPBlCHvQAmwqJbijkagc)=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_Search_Netflix(uLWzVRpNYrGPBlCHvQAmwqJbijkago,1)
   if uLWzVRpNYrGPBlCHvQAmwqJbijkacF(uLWzVRpNYrGPBlCHvQAmwqJbijkagF)>0:
    uLWzVRpNYrGPBlCHvQAmwqJbijkagn={'sType':'netflix_list','sList':uLWzVRpNYrGPBlCHvQAmwqJbijkaot.MakeText_FreeList(uLWzVRpNYrGPBlCHvQAmwqJbijkagF),}
    uLWzVRpNYrGPBlCHvQAmwqJbijkayI.append(uLWzVRpNYrGPBlCHvQAmwqJbijkagn)
  for uLWzVRpNYrGPBlCHvQAmwqJbijkagt in uLWzVRpNYrGPBlCHvQAmwqJbijkayI:
   uLWzVRpNYrGPBlCHvQAmwqJbijkagE=uLWzVRpNYrGPBlCHvQAmwqJbijkaog[uLWzVRpNYrGPBlCHvQAmwqJbijkagt.get('sType')]
   uLWzVRpNYrGPBlCHvQAmwqJbijkagU={'plot':'검색어 : '+uLWzVRpNYrGPBlCHvQAmwqJbijkago+'\n\n'+uLWzVRpNYrGPBlCHvQAmwqJbijkagt.get('sList')}
   uLWzVRpNYrGPBlCHvQAmwqJbijkaod=uLWzVRpNYrGPBlCHvQAmwqJbijkagE.get('title')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFx={'mode':uLWzVRpNYrGPBlCHvQAmwqJbijkagE.get('mode'),'ott':uLWzVRpNYrGPBlCHvQAmwqJbijkagE.get('ott'),'vidtype':uLWzVRpNYrGPBlCHvQAmwqJbijkagE.get('vidtype'),'search_key':uLWzVRpNYrGPBlCHvQAmwqJbijkago}
   if uLWzVRpNYrGPBlCHvQAmwqJbijkagE.get('ott')=='netflix':
    uLWzVRpNYrGPBlCHvQAmwqJbijkaFx['page'] ='1'
    uLWzVRpNYrGPBlCHvQAmwqJbijkaFx['byReference']='-'
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',uLWzVRpNYrGPBlCHvQAmwqJbijkagE.get('icon'))
   uLWzVRpNYrGPBlCHvQAmwqJbijkayc=uLWzVRpNYrGPBlCHvQAmwqJbijkanX if uLWzVRpNYrGPBlCHvQAmwqJbijkagE.get('mode')!='HYPER_LINK' else uLWzVRpNYrGPBlCHvQAmwqJbijkanT
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.add_dir(uLWzVRpNYrGPBlCHvQAmwqJbijkaod,sublabel='',img=uLWzVRpNYrGPBlCHvQAmwqJbijkaFd,infoLabels=uLWzVRpNYrGPBlCHvQAmwqJbijkagU,isFolder=uLWzVRpNYrGPBlCHvQAmwqJbijkayc,params=uLWzVRpNYrGPBlCHvQAmwqJbijkaFx,isLink=uLWzVRpNYrGPBlCHvQAmwqJbijkanX)
  xbmcplugin.endOfDirectory(uLWzVRpNYrGPBlCHvQAmwqJbijkaot._addon_handle)
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot.Save_Searched_List(uLWzVRpNYrGPBlCHvQAmwqJbijkago)
 def dp_Hyper_Link(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,args):
  uLWzVRpNYrGPBlCHvQAmwqJbijkagM =args.get('mode')
  uLWzVRpNYrGPBlCHvQAmwqJbijkagh =args.get('ott')
  uLWzVRpNYrGPBlCHvQAmwqJbijkage =args.get('vidtype')
  uLWzVRpNYrGPBlCHvQAmwqJbijkago=args.get('search_key')
  uLWzVRpNYrGPBlCHvQAmwqJbijkagK='-'
  if uLWzVRpNYrGPBlCHvQAmwqJbijkagh=='wavve':
   uLWzVRpNYrGPBlCHvQAmwqJbijkagD={'mode':'LOCAL_SEARCH','sType':'movie' if uLWzVRpNYrGPBlCHvQAmwqJbijkage=='MOVIE' else 'vod','search_key':uLWzVRpNYrGPBlCHvQAmwqJbijkago,'page':'1',}
   uLWzVRpNYrGPBlCHvQAmwqJbijkagS=urllib.parse.urlencode(uLWzVRpNYrGPBlCHvQAmwqJbijkagD)
   uLWzVRpNYrGPBlCHvQAmwqJbijkagK='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(uLWzVRpNYrGPBlCHvQAmwqJbijkagS)
  elif uLWzVRpNYrGPBlCHvQAmwqJbijkagh=='tving':
   uLWzVRpNYrGPBlCHvQAmwqJbijkagD={'mode':'LOCAL_SEARCH','stype':'movie' if uLWzVRpNYrGPBlCHvQAmwqJbijkage=='MOVIE' else 'vod','search_key':uLWzVRpNYrGPBlCHvQAmwqJbijkago,'page':'1',}
   uLWzVRpNYrGPBlCHvQAmwqJbijkagS=urllib.parse.urlencode(uLWzVRpNYrGPBlCHvQAmwqJbijkagD)
   uLWzVRpNYrGPBlCHvQAmwqJbijkagK='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(uLWzVRpNYrGPBlCHvQAmwqJbijkagS)
  elif uLWzVRpNYrGPBlCHvQAmwqJbijkagh=='watcha':
   uLWzVRpNYrGPBlCHvQAmwqJbijkagD={'mode':'LOCAL_SEARCH','search_key':uLWzVRpNYrGPBlCHvQAmwqJbijkago,'page':'1',}
   uLWzVRpNYrGPBlCHvQAmwqJbijkagS=urllib.parse.urlencode(uLWzVRpNYrGPBlCHvQAmwqJbijkagD)
   uLWzVRpNYrGPBlCHvQAmwqJbijkagK='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(uLWzVRpNYrGPBlCHvQAmwqJbijkagS)
  elif uLWzVRpNYrGPBlCHvQAmwqJbijkagh=='netflix':
   uLWzVRpNYrGPBlCHvQAmwqJbijkagx=args.get('videoid')
   uLWzVRpNYrGPBlCHvQAmwqJbijkagO=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.NF['SESSION']['nowGuid']
   if uLWzVRpNYrGPBlCHvQAmwqJbijkage=='TVSHOW':
    uLWzVRpNYrGPBlCHvQAmwqJbijkagK='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(uLWzVRpNYrGPBlCHvQAmwqJbijkagx)
   else:
    uLWzVRpNYrGPBlCHvQAmwqJbijkagK='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(uLWzVRpNYrGPBlCHvQAmwqJbijkagx,uLWzVRpNYrGPBlCHvQAmwqJbijkagO)
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot.addon_log('ott_url ==> ( '+uLWzVRpNYrGPBlCHvQAmwqJbijkagK+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(uLWzVRpNYrGPBlCHvQAmwqJbijkagK)
 def dp_Nf_Search(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,args):
  uLWzVRpNYrGPBlCHvQAmwqJbijkags =uLWzVRpNYrGPBlCHvQAmwqJbijkacn(args.get('page'))
  uLWzVRpNYrGPBlCHvQAmwqJbijkago =args.get('search_key')
  uLWzVRpNYrGPBlCHvQAmwqJbijkagc=args.get('byReference')
  (uLWzVRpNYrGPBlCHvQAmwqJbijkagF,uLWzVRpNYrGPBlCHvQAmwqJbijkagy,uLWzVRpNYrGPBlCHvQAmwqJbijkagc)=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.SearchObj.Get_Search_Netflix(uLWzVRpNYrGPBlCHvQAmwqJbijkago,uLWzVRpNYrGPBlCHvQAmwqJbijkags,byReference=uLWzVRpNYrGPBlCHvQAmwqJbijkagc)
  for uLWzVRpNYrGPBlCHvQAmwqJbijkagf in uLWzVRpNYrGPBlCHvQAmwqJbijkagF:
   uLWzVRpNYrGPBlCHvQAmwqJbijkagx =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('videoid')
   uLWzVRpNYrGPBlCHvQAmwqJbijkage =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('vidtype')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaod =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('title')
   uLWzVRpNYrGPBlCHvQAmwqJbijkagX =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('mpaa')
   uLWzVRpNYrGPBlCHvQAmwqJbijkagT =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('regularSynopsis')
   uLWzVRpNYrGPBlCHvQAmwqJbijkagd =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('dpSupplemental')
   uLWzVRpNYrGPBlCHvQAmwqJbijkagI=uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('sequiturEvidence')
   uLWzVRpNYrGPBlCHvQAmwqJbijkano =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('thumbnail')
   uLWzVRpNYrGPBlCHvQAmwqJbijkanF =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('year')
   uLWzVRpNYrGPBlCHvQAmwqJbijkany =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('duration')
   uLWzVRpNYrGPBlCHvQAmwqJbijkang =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('info_genre')
   uLWzVRpNYrGPBlCHvQAmwqJbijkanc =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('director')
   uLWzVRpNYrGPBlCHvQAmwqJbijkant =uLWzVRpNYrGPBlCHvQAmwqJbijkagf.get('cast')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFX=uLWzVRpNYrGPBlCHvQAmwqJbijkacg(uLWzVRpNYrGPBlCHvQAmwqJbijkanF)if uLWzVRpNYrGPBlCHvQAmwqJbijkage=='movie' else ''
   uLWzVRpNYrGPBlCHvQAmwqJbijkanE=''
   if uLWzVRpNYrGPBlCHvQAmwqJbijkagT:uLWzVRpNYrGPBlCHvQAmwqJbijkanE=uLWzVRpNYrGPBlCHvQAmwqJbijkanE+'\n\n'+uLWzVRpNYrGPBlCHvQAmwqJbijkagT
   if uLWzVRpNYrGPBlCHvQAmwqJbijkagd :uLWzVRpNYrGPBlCHvQAmwqJbijkanE=uLWzVRpNYrGPBlCHvQAmwqJbijkanE+'\n\n'+uLWzVRpNYrGPBlCHvQAmwqJbijkagd
   if uLWzVRpNYrGPBlCHvQAmwqJbijkagI:uLWzVRpNYrGPBlCHvQAmwqJbijkanE=uLWzVRpNYrGPBlCHvQAmwqJbijkanE+'\n\n'+uLWzVRpNYrGPBlCHvQAmwqJbijkagI
   uLWzVRpNYrGPBlCHvQAmwqJbijkanE=uLWzVRpNYrGPBlCHvQAmwqJbijkanE.strip()
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFT={'mediatype':'tvshow' if uLWzVRpNYrGPBlCHvQAmwqJbijkage=='show' else 'movie','title':uLWzVRpNYrGPBlCHvQAmwqJbijkaod,'mpaa':uLWzVRpNYrGPBlCHvQAmwqJbijkagX,'plot':uLWzVRpNYrGPBlCHvQAmwqJbijkanE,'duration':uLWzVRpNYrGPBlCHvQAmwqJbijkany,'genre':uLWzVRpNYrGPBlCHvQAmwqJbijkang,'director':uLWzVRpNYrGPBlCHvQAmwqJbijkanc,'cast':uLWzVRpNYrGPBlCHvQAmwqJbijkant,}
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFx={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if uLWzVRpNYrGPBlCHvQAmwqJbijkage=='show' else 'MOVIE','videoid':uLWzVRpNYrGPBlCHvQAmwqJbijkagx,}
   if uLWzVRpNYrGPBlCHvQAmwqJbijkaot.get_settings_makebookmark():
    uLWzVRpNYrGPBlCHvQAmwqJbijkanU={'videoid':uLWzVRpNYrGPBlCHvQAmwqJbijkagx,'vidtype':'tvshow' if uLWzVRpNYrGPBlCHvQAmwqJbijkage=='show' else 'movie','vtitle':uLWzVRpNYrGPBlCHvQAmwqJbijkaod,'vsubtitle':'','vinfo':uLWzVRpNYrGPBlCHvQAmwqJbijkaFT,'thumbnail':uLWzVRpNYrGPBlCHvQAmwqJbijkano,}
    uLWzVRpNYrGPBlCHvQAmwqJbijkanM=json.dumps(uLWzVRpNYrGPBlCHvQAmwqJbijkanU)
    uLWzVRpNYrGPBlCHvQAmwqJbijkanM=urllib.parse.quote(uLWzVRpNYrGPBlCHvQAmwqJbijkanM)
    uLWzVRpNYrGPBlCHvQAmwqJbijkanh='RunPlugin(plugin://plugin.video.searchm/?mode=SET_BOOKMARK&bm_param=%s)'%(uLWzVRpNYrGPBlCHvQAmwqJbijkanM)
    uLWzVRpNYrGPBlCHvQAmwqJbijkaFf=[('찜한 영상에 추가 (통합 bookmark mini)',uLWzVRpNYrGPBlCHvQAmwqJbijkanh)]
   else:
    uLWzVRpNYrGPBlCHvQAmwqJbijkaFf=uLWzVRpNYrGPBlCHvQAmwqJbijkanf
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.add_dir(uLWzVRpNYrGPBlCHvQAmwqJbijkaod,sublabel=uLWzVRpNYrGPBlCHvQAmwqJbijkaFX,img=uLWzVRpNYrGPBlCHvQAmwqJbijkano,infoLabels=uLWzVRpNYrGPBlCHvQAmwqJbijkaFT,isFolder=uLWzVRpNYrGPBlCHvQAmwqJbijkanT,params=uLWzVRpNYrGPBlCHvQAmwqJbijkaFx,isLink=uLWzVRpNYrGPBlCHvQAmwqJbijkanX,ContextMenu=uLWzVRpNYrGPBlCHvQAmwqJbijkaFf)
  if uLWzVRpNYrGPBlCHvQAmwqJbijkagy:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFx={}
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFx['mode'] ='NF_SEARCH' 
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFx['page'] =uLWzVRpNYrGPBlCHvQAmwqJbijkacg(uLWzVRpNYrGPBlCHvQAmwqJbijkags+1)
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFx['search_key']=uLWzVRpNYrGPBlCHvQAmwqJbijkago
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFx['byReference']=uLWzVRpNYrGPBlCHvQAmwqJbijkagc
   uLWzVRpNYrGPBlCHvQAmwqJbijkaod='[B]%s >>[/B]'%'다음 페이지'
   uLWzVRpNYrGPBlCHvQAmwqJbijkane=uLWzVRpNYrGPBlCHvQAmwqJbijkacg(uLWzVRpNYrGPBlCHvQAmwqJbijkags+1)
   uLWzVRpNYrGPBlCHvQAmwqJbijkaFd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.add_dir(uLWzVRpNYrGPBlCHvQAmwqJbijkaod,sublabel=uLWzVRpNYrGPBlCHvQAmwqJbijkane,img=uLWzVRpNYrGPBlCHvQAmwqJbijkaFd,infoLabels=uLWzVRpNYrGPBlCHvQAmwqJbijkanf,isFolder=uLWzVRpNYrGPBlCHvQAmwqJbijkanX,params=uLWzVRpNYrGPBlCHvQAmwqJbijkaFx)
  xbmcplugin.setContent(uLWzVRpNYrGPBlCHvQAmwqJbijkaot._addon_handle,'movies')
  xbmcplugin.endOfDirectory(uLWzVRpNYrGPBlCHvQAmwqJbijkaot._addon_handle)
 def dp_Bookmark_Menu(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,args):
  uLWzVRpNYrGPBlCHvQAmwqJbijkagK='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(uLWzVRpNYrGPBlCHvQAmwqJbijkagK)
 def dp_Set_Bookmark(uLWzVRpNYrGPBlCHvQAmwqJbijkaot,args):
  uLWzVRpNYrGPBlCHvQAmwqJbijkanK=urllib.parse.unquote(args.get('bm_param'))
  uLWzVRpNYrGPBlCHvQAmwqJbijkanK=json.loads(uLWzVRpNYrGPBlCHvQAmwqJbijkanK)
  uLWzVRpNYrGPBlCHvQAmwqJbijkagx =uLWzVRpNYrGPBlCHvQAmwqJbijkanK.get('videoid')
  uLWzVRpNYrGPBlCHvQAmwqJbijkage =uLWzVRpNYrGPBlCHvQAmwqJbijkanK.get('vidtype')
  uLWzVRpNYrGPBlCHvQAmwqJbijkanD =uLWzVRpNYrGPBlCHvQAmwqJbijkanK.get('vtitle')
  uLWzVRpNYrGPBlCHvQAmwqJbijkanS =uLWzVRpNYrGPBlCHvQAmwqJbijkanK.get('vsubtitle')
  uLWzVRpNYrGPBlCHvQAmwqJbijkanx =uLWzVRpNYrGPBlCHvQAmwqJbijkanK.get('vinfo')
  uLWzVRpNYrGPBlCHvQAmwqJbijkano =uLWzVRpNYrGPBlCHvQAmwqJbijkanK.get('thumbnail')
  uLWzVRpNYrGPBlCHvQAmwqJbijkaoe=xbmcgui.Dialog()
  uLWzVRpNYrGPBlCHvQAmwqJbijkayg=uLWzVRpNYrGPBlCHvQAmwqJbijkaoe.yesno(__language__(30917).encode('utf8'),uLWzVRpNYrGPBlCHvQAmwqJbijkanD+' \n\n'+__language__(30918))
  if uLWzVRpNYrGPBlCHvQAmwqJbijkayg==uLWzVRpNYrGPBlCHvQAmwqJbijkanT:return
  uLWzVRpNYrGPBlCHvQAmwqJbijkanO={'indexinfo':{'ott':'netflix','videoid':uLWzVRpNYrGPBlCHvQAmwqJbijkagx,'vidtype':uLWzVRpNYrGPBlCHvQAmwqJbijkage,},'saveinfo':{'title':uLWzVRpNYrGPBlCHvQAmwqJbijkanD,'subtitle':uLWzVRpNYrGPBlCHvQAmwqJbijkanS,'thumbnail':uLWzVRpNYrGPBlCHvQAmwqJbijkano,'infoLabels':uLWzVRpNYrGPBlCHvQAmwqJbijkanx,},}
  uLWzVRpNYrGPBlCHvQAmwqJbijkanM=json.dumps(uLWzVRpNYrGPBlCHvQAmwqJbijkanO)
  uLWzVRpNYrGPBlCHvQAmwqJbijkanM=urllib.parse.quote(uLWzVRpNYrGPBlCHvQAmwqJbijkanM)
  uLWzVRpNYrGPBlCHvQAmwqJbijkanh='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(uLWzVRpNYrGPBlCHvQAmwqJbijkanM)
  xbmc.executebuiltin(uLWzVRpNYrGPBlCHvQAmwqJbijkanh)
 def search_main(uLWzVRpNYrGPBlCHvQAmwqJbijkaot):
  uLWzVRpNYrGPBlCHvQAmwqJbijkagM=uLWzVRpNYrGPBlCHvQAmwqJbijkaot.main_params.get('mode',uLWzVRpNYrGPBlCHvQAmwqJbijkanf)
  if uLWzVRpNYrGPBlCHvQAmwqJbijkagM=='NFLOGOUT':
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.NF_logout()
   return
  elif uLWzVRpNYrGPBlCHvQAmwqJbijkagM=='NFLOGIN':
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.NF_login()
   return
  uLWzVRpNYrGPBlCHvQAmwqJbijkaot.option_check()
  if uLWzVRpNYrGPBlCHvQAmwqJbijkagM is uLWzVRpNYrGPBlCHvQAmwqJbijkanf:
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.dp_Main_List()
  elif uLWzVRpNYrGPBlCHvQAmwqJbijkagM=='TOTAL_SEARCH':
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.dp_Search_Group(uLWzVRpNYrGPBlCHvQAmwqJbijkaot.main_params)
  elif uLWzVRpNYrGPBlCHvQAmwqJbijkagM=='HYPER_LINK':
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.dp_Hyper_Link(uLWzVRpNYrGPBlCHvQAmwqJbijkaot.main_params)
  elif uLWzVRpNYrGPBlCHvQAmwqJbijkagM=='NF_SEARCH':
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.dp_Nf_Search(uLWzVRpNYrGPBlCHvQAmwqJbijkaot.main_params)
  elif uLWzVRpNYrGPBlCHvQAmwqJbijkagM=='TOTAL_HISTORY':
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.dp_Search_History(uLWzVRpNYrGPBlCHvQAmwqJbijkaot.main_params)
  elif uLWzVRpNYrGPBlCHvQAmwqJbijkagM=='HISTORY_REMOVE':
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.dp_History_Delete(uLWzVRpNYrGPBlCHvQAmwqJbijkaot.main_params)
  elif uLWzVRpNYrGPBlCHvQAmwqJbijkagM=='MENU_BOOKMARK':
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.dp_Bookmark_Menu(uLWzVRpNYrGPBlCHvQAmwqJbijkaot.main_params)
  elif uLWzVRpNYrGPBlCHvQAmwqJbijkagM=='SET_BOOKMARK':
   uLWzVRpNYrGPBlCHvQAmwqJbijkaot.dp_Set_Bookmark(uLWzVRpNYrGPBlCHvQAmwqJbijkaot.main_params)
  else:
   uLWzVRpNYrGPBlCHvQAmwqJbijkanf
# Created by pyminifier (https://github.com/liftoff/pyminifier)
