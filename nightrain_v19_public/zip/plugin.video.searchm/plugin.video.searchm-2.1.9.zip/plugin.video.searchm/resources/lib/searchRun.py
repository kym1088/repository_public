__author__="NightRain"
nPSHaYXODecEkstmgpwrfzdxWMUjVA=object
nPSHaYXODecEkstmgpwrfzdxWMUjVh=None
nPSHaYXODecEkstmgpwrfzdxWMUjVq=True
nPSHaYXODecEkstmgpwrfzdxWMUjVF=False
nPSHaYXODecEkstmgpwrfzdxWMUjVJ=type
nPSHaYXODecEkstmgpwrfzdxWMUjVL=dict
nPSHaYXODecEkstmgpwrfzdxWMUjVN=open
nPSHaYXODecEkstmgpwrfzdxWMUjVv=len
nPSHaYXODecEkstmgpwrfzdxWMUjVo=Exception
nPSHaYXODecEkstmgpwrfzdxWMUjGR=int
nPSHaYXODecEkstmgpwrfzdxWMUjGb=range
nPSHaYXODecEkstmgpwrfzdxWMUjGI=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
nPSHaYXODecEkstmgpwrfzdxWMUjRI=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
nPSHaYXODecEkstmgpwrfzdxWMUjRy={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
nPSHaYXODecEkstmgpwrfzdxWMUjRV=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
nPSHaYXODecEkstmgpwrfzdxWMUjRG =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class nPSHaYXODecEkstmgpwrfzdxWMUjRb(nPSHaYXODecEkstmgpwrfzdxWMUjVA):
 def __init__(nPSHaYXODecEkstmgpwrfzdxWMUjRi,nPSHaYXODecEkstmgpwrfzdxWMUjRT,nPSHaYXODecEkstmgpwrfzdxWMUjRC,nPSHaYXODecEkstmgpwrfzdxWMUjRl):
  nPSHaYXODecEkstmgpwrfzdxWMUjRi._addon_url =nPSHaYXODecEkstmgpwrfzdxWMUjRT
  nPSHaYXODecEkstmgpwrfzdxWMUjRi._addon_handle=nPSHaYXODecEkstmgpwrfzdxWMUjRC
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.main_params =nPSHaYXODecEkstmgpwrfzdxWMUjRl
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj =mhEoBuVckdJYibIfDxjOnFrpzXlCta() 
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_cookies.pk'))
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(nPSHaYXODecEkstmgpwrfzdxWMUjRi,sting):
  try:
   nPSHaYXODecEkstmgpwrfzdxWMUjRQ=xbmcgui.Dialog()
   nPSHaYXODecEkstmgpwrfzdxWMUjRQ.notification(__addonname__,sting)
  except:
   nPSHaYXODecEkstmgpwrfzdxWMUjVh
 def addon_log(nPSHaYXODecEkstmgpwrfzdxWMUjRi,string):
  try:
   nPSHaYXODecEkstmgpwrfzdxWMUjRK=string.encode('utf-8','ignore')
  except:
   nPSHaYXODecEkstmgpwrfzdxWMUjRK='addonException: addon_log'
  nPSHaYXODecEkstmgpwrfzdxWMUjRu=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,nPSHaYXODecEkstmgpwrfzdxWMUjRK),level=nPSHaYXODecEkstmgpwrfzdxWMUjRu)
 def get_keyboard_input(nPSHaYXODecEkstmgpwrfzdxWMUjRi,nPSHaYXODecEkstmgpwrfzdxWMUjRN):
  nPSHaYXODecEkstmgpwrfzdxWMUjRA=nPSHaYXODecEkstmgpwrfzdxWMUjVh
  kb=xbmc.Keyboard()
  kb.setHeading(nPSHaYXODecEkstmgpwrfzdxWMUjRN)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   nPSHaYXODecEkstmgpwrfzdxWMUjRA=kb.getText()
  return nPSHaYXODecEkstmgpwrfzdxWMUjRA
 def get_settings_menubookmark(nPSHaYXODecEkstmgpwrfzdxWMUjRi):
  nPSHaYXODecEkstmgpwrfzdxWMUjRh=nPSHaYXODecEkstmgpwrfzdxWMUjVq if __addon__.getSetting('menu_bookmark')=='true' else nPSHaYXODecEkstmgpwrfzdxWMUjVF
  return(nPSHaYXODecEkstmgpwrfzdxWMUjRh)
 def get_settings_makebookmark(nPSHaYXODecEkstmgpwrfzdxWMUjRi):
  return nPSHaYXODecEkstmgpwrfzdxWMUjVq if __addon__.getSetting('make_bookmark')=='true' else nPSHaYXODecEkstmgpwrfzdxWMUjVF
 def get_settings_select_info(nPSHaYXODecEkstmgpwrfzdxWMUjRi):
  nPSHaYXODecEkstmgpwrfzdxWMUjRq=[]
  if __addon__.getSetting('netflixyn')=='true':nPSHaYXODecEkstmgpwrfzdxWMUjRq.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':nPSHaYXODecEkstmgpwrfzdxWMUjRq.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':nPSHaYXODecEkstmgpwrfzdxWMUjRq.append('tving')
  if __addon__.getSetting('watchayn')=='true':nPSHaYXODecEkstmgpwrfzdxWMUjRq.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':nPSHaYXODecEkstmgpwrfzdxWMUjRq.append('coupang')
  if __addon__.getSetting('primevyn')=='true':nPSHaYXODecEkstmgpwrfzdxWMUjRq.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':nPSHaYXODecEkstmgpwrfzdxWMUjRq.append('disney')
  return nPSHaYXODecEkstmgpwrfzdxWMUjRq
 def add_dir(nPSHaYXODecEkstmgpwrfzdxWMUjRi,label,sublabel='',img='',infoLabels=nPSHaYXODecEkstmgpwrfzdxWMUjVh,isFolder=nPSHaYXODecEkstmgpwrfzdxWMUjVq,params='',isLink=nPSHaYXODecEkstmgpwrfzdxWMUjVF,ContextMenu=nPSHaYXODecEkstmgpwrfzdxWMUjVh,direct_url=nPSHaYXODecEkstmgpwrfzdxWMUjVh):
  if direct_url:
   nPSHaYXODecEkstmgpwrfzdxWMUjRF=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   nPSHaYXODecEkstmgpwrfzdxWMUjRL=json.dumps(params,separators=(',',':'))
   nPSHaYXODecEkstmgpwrfzdxWMUjRL=base64.standard_b64encode(nPSHaYXODecEkstmgpwrfzdxWMUjRL.encode()).decode('utf-8')
   nPSHaYXODecEkstmgpwrfzdxWMUjRL=nPSHaYXODecEkstmgpwrfzdxWMUjRL.replace('+','%2B')
   nPSHaYXODecEkstmgpwrfzdxWMUjRF='%s?params=%s'%(nPSHaYXODecEkstmgpwrfzdxWMUjRi._addon_url,nPSHaYXODecEkstmgpwrfzdxWMUjRL)
  if sublabel and sublabel!='-':nPSHaYXODecEkstmgpwrfzdxWMUjRN='%s < %s >'%(label,sublabel)
  else: nPSHaYXODecEkstmgpwrfzdxWMUjRN=label
  if not img:img='DefaultFolder.png'
  nPSHaYXODecEkstmgpwrfzdxWMUjRv=xbmcgui.ListItem(nPSHaYXODecEkstmgpwrfzdxWMUjRN)
  if nPSHaYXODecEkstmgpwrfzdxWMUjVJ(img)==nPSHaYXODecEkstmgpwrfzdxWMUjVL:
   nPSHaYXODecEkstmgpwrfzdxWMUjRv.setArt(img)
  else:
   nPSHaYXODecEkstmgpwrfzdxWMUjRv.setArt({'thumb':img,'poster':img})
  if infoLabels:nPSHaYXODecEkstmgpwrfzdxWMUjRv.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   nPSHaYXODecEkstmgpwrfzdxWMUjRv.setProperty('IsPlayable','true')
  if ContextMenu:nPSHaYXODecEkstmgpwrfzdxWMUjRv.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(nPSHaYXODecEkstmgpwrfzdxWMUjRi._addon_handle,nPSHaYXODecEkstmgpwrfzdxWMUjRF,nPSHaYXODecEkstmgpwrfzdxWMUjRv,isFolder)
 def Load_Searched_List(nPSHaYXODecEkstmgpwrfzdxWMUjRi):
  try:
   nPSHaYXODecEkstmgpwrfzdxWMUjRo=nPSHaYXODecEkstmgpwrfzdxWMUjRG
   fp=nPSHaYXODecEkstmgpwrfzdxWMUjVN(nPSHaYXODecEkstmgpwrfzdxWMUjRo,'r',-1,'utf-8')
   nPSHaYXODecEkstmgpwrfzdxWMUjbR=fp.readlines()
   fp.close()
  except:
   nPSHaYXODecEkstmgpwrfzdxWMUjbR=[]
  return nPSHaYXODecEkstmgpwrfzdxWMUjbR
 def Save_Searched_List(nPSHaYXODecEkstmgpwrfzdxWMUjRi,nPSHaYXODecEkstmgpwrfzdxWMUjIF):
  try:
   nPSHaYXODecEkstmgpwrfzdxWMUjRo=nPSHaYXODecEkstmgpwrfzdxWMUjRG
   nPSHaYXODecEkstmgpwrfzdxWMUjbI=nPSHaYXODecEkstmgpwrfzdxWMUjRi.Load_Searched_List() 
   nPSHaYXODecEkstmgpwrfzdxWMUjby={'skey':nPSHaYXODecEkstmgpwrfzdxWMUjIF.strip()}
   fp=nPSHaYXODecEkstmgpwrfzdxWMUjVN(nPSHaYXODecEkstmgpwrfzdxWMUjRo,'w',-1,'utf-8')
   nPSHaYXODecEkstmgpwrfzdxWMUjbV=urllib.parse.urlencode(nPSHaYXODecEkstmgpwrfzdxWMUjby)
   nPSHaYXODecEkstmgpwrfzdxWMUjbV=nPSHaYXODecEkstmgpwrfzdxWMUjbV+'\n'
   fp.write(nPSHaYXODecEkstmgpwrfzdxWMUjbV)
   nPSHaYXODecEkstmgpwrfzdxWMUjbG=0
   for nPSHaYXODecEkstmgpwrfzdxWMUjbi in nPSHaYXODecEkstmgpwrfzdxWMUjbI:
    nPSHaYXODecEkstmgpwrfzdxWMUjbT=nPSHaYXODecEkstmgpwrfzdxWMUjVL(urllib.parse.parse_qsl(nPSHaYXODecEkstmgpwrfzdxWMUjbi))
    nPSHaYXODecEkstmgpwrfzdxWMUjbC=nPSHaYXODecEkstmgpwrfzdxWMUjby.get('skey').strip()
    nPSHaYXODecEkstmgpwrfzdxWMUjbl=nPSHaYXODecEkstmgpwrfzdxWMUjbT.get('skey').strip()
    if nPSHaYXODecEkstmgpwrfzdxWMUjbC!=nPSHaYXODecEkstmgpwrfzdxWMUjbl:
     fp.write(nPSHaYXODecEkstmgpwrfzdxWMUjbi)
     nPSHaYXODecEkstmgpwrfzdxWMUjbG+=1
     if nPSHaYXODecEkstmgpwrfzdxWMUjbG>=50:break
   fp.close()
  except:
   nPSHaYXODecEkstmgpwrfzdxWMUjVh
 def dp_Search_History(nPSHaYXODecEkstmgpwrfzdxWMUjRi,args):
  nPSHaYXODecEkstmgpwrfzdxWMUjbB=nPSHaYXODecEkstmgpwrfzdxWMUjRi.Load_Searched_List()
  for nPSHaYXODecEkstmgpwrfzdxWMUjbQ in nPSHaYXODecEkstmgpwrfzdxWMUjbB:
   nPSHaYXODecEkstmgpwrfzdxWMUjbK=nPSHaYXODecEkstmgpwrfzdxWMUjVL(urllib.parse.parse_qsl(nPSHaYXODecEkstmgpwrfzdxWMUjbQ))
   nPSHaYXODecEkstmgpwrfzdxWMUjbu=nPSHaYXODecEkstmgpwrfzdxWMUjbK.get('skey').strip()
   nPSHaYXODecEkstmgpwrfzdxWMUjRJ={'mode':'TOTAL_SEARCH','search_key':nPSHaYXODecEkstmgpwrfzdxWMUjbu,}
   nPSHaYXODecEkstmgpwrfzdxWMUjbA={'mode':'HISTORY_REMOVE','skey':nPSHaYXODecEkstmgpwrfzdxWMUjbu,'delmode':'ONE',}
   nPSHaYXODecEkstmgpwrfzdxWMUjbh=urllib.parse.urlencode(nPSHaYXODecEkstmgpwrfzdxWMUjbA)
   nPSHaYXODecEkstmgpwrfzdxWMUjbq=[('선택된 검색어 ( %s ) 삭제'%(nPSHaYXODecEkstmgpwrfzdxWMUjbu),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(nPSHaYXODecEkstmgpwrfzdxWMUjbh))]
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.add_dir(nPSHaYXODecEkstmgpwrfzdxWMUjbu,sublabel='',img=nPSHaYXODecEkstmgpwrfzdxWMUjVh,infoLabels=nPSHaYXODecEkstmgpwrfzdxWMUjVh,isFolder=nPSHaYXODecEkstmgpwrfzdxWMUjVq,params=nPSHaYXODecEkstmgpwrfzdxWMUjRJ,ContextMenu=nPSHaYXODecEkstmgpwrfzdxWMUjbq)
  nPSHaYXODecEkstmgpwrfzdxWMUjbJ={'plot':'검색목록 전체를 삭제합니다.'}
  nPSHaYXODecEkstmgpwrfzdxWMUjRN='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  nPSHaYXODecEkstmgpwrfzdxWMUjRJ={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  nPSHaYXODecEkstmgpwrfzdxWMUjbL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.add_dir(nPSHaYXODecEkstmgpwrfzdxWMUjRN,sublabel='',img=nPSHaYXODecEkstmgpwrfzdxWMUjbL,infoLabels=nPSHaYXODecEkstmgpwrfzdxWMUjbJ,isFolder=nPSHaYXODecEkstmgpwrfzdxWMUjVF,params=nPSHaYXODecEkstmgpwrfzdxWMUjRJ,isLink=nPSHaYXODecEkstmgpwrfzdxWMUjVq)
  xbmcplugin.endOfDirectory(nPSHaYXODecEkstmgpwrfzdxWMUjRi._addon_handle,cacheToDisc=nPSHaYXODecEkstmgpwrfzdxWMUjVF)
 def Delete_History_List(nPSHaYXODecEkstmgpwrfzdxWMUjRi,nPSHaYXODecEkstmgpwrfzdxWMUjbu,nPSHaYXODecEkstmgpwrfzdxWMUjbo):
  if nPSHaYXODecEkstmgpwrfzdxWMUjbo=='ALL':
   try:
    nPSHaYXODecEkstmgpwrfzdxWMUjRo=nPSHaYXODecEkstmgpwrfzdxWMUjRG
    fp=nPSHaYXODecEkstmgpwrfzdxWMUjVN(nPSHaYXODecEkstmgpwrfzdxWMUjRo,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    nPSHaYXODecEkstmgpwrfzdxWMUjVh
  else:
   try:
    nPSHaYXODecEkstmgpwrfzdxWMUjRo=nPSHaYXODecEkstmgpwrfzdxWMUjRG
    nPSHaYXODecEkstmgpwrfzdxWMUjbI=nPSHaYXODecEkstmgpwrfzdxWMUjRi.Load_Searched_List() 
    fp=nPSHaYXODecEkstmgpwrfzdxWMUjVN(nPSHaYXODecEkstmgpwrfzdxWMUjRo,'w',-1,'utf-8')
    for nPSHaYXODecEkstmgpwrfzdxWMUjbi in nPSHaYXODecEkstmgpwrfzdxWMUjbI:
     nPSHaYXODecEkstmgpwrfzdxWMUjbT=nPSHaYXODecEkstmgpwrfzdxWMUjVL(urllib.parse.parse_qsl(nPSHaYXODecEkstmgpwrfzdxWMUjbi))
     nPSHaYXODecEkstmgpwrfzdxWMUjbv=nPSHaYXODecEkstmgpwrfzdxWMUjbT.get('skey').strip()
     if nPSHaYXODecEkstmgpwrfzdxWMUjbu!=nPSHaYXODecEkstmgpwrfzdxWMUjbv:
      fp.write(nPSHaYXODecEkstmgpwrfzdxWMUjbi)
    fp.close()
   except:
    nPSHaYXODecEkstmgpwrfzdxWMUjVh
 def dp_History_Delete(nPSHaYXODecEkstmgpwrfzdxWMUjRi,args):
  nPSHaYXODecEkstmgpwrfzdxWMUjbu =args.get('skey') 
  nPSHaYXODecEkstmgpwrfzdxWMUjbo=args.get('delmode')
  nPSHaYXODecEkstmgpwrfzdxWMUjRQ=xbmcgui.Dialog()
  if nPSHaYXODecEkstmgpwrfzdxWMUjbo=='ALL':
   nPSHaYXODecEkstmgpwrfzdxWMUjIR=nPSHaYXODecEkstmgpwrfzdxWMUjRQ.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   nPSHaYXODecEkstmgpwrfzdxWMUjIR=nPSHaYXODecEkstmgpwrfzdxWMUjRQ.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if nPSHaYXODecEkstmgpwrfzdxWMUjIR==nPSHaYXODecEkstmgpwrfzdxWMUjVF:sys.exit()
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.Delete_History_List(nPSHaYXODecEkstmgpwrfzdxWMUjbu,nPSHaYXODecEkstmgpwrfzdxWMUjbo)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(nPSHaYXODecEkstmgpwrfzdxWMUjRi):
  nPSHaYXODecEkstmgpwrfzdxWMUjRh=nPSHaYXODecEkstmgpwrfzdxWMUjRi.get_settings_menubookmark()
  for nPSHaYXODecEkstmgpwrfzdxWMUjIb in nPSHaYXODecEkstmgpwrfzdxWMUjRI:
   nPSHaYXODecEkstmgpwrfzdxWMUjRN=nPSHaYXODecEkstmgpwrfzdxWMUjIb.get('title')
   nPSHaYXODecEkstmgpwrfzdxWMUjbL=''
   if nPSHaYXODecEkstmgpwrfzdxWMUjIb.get('mode')=='MENU_BOOKMARK' and nPSHaYXODecEkstmgpwrfzdxWMUjRh==nPSHaYXODecEkstmgpwrfzdxWMUjVF:continue
   nPSHaYXODecEkstmgpwrfzdxWMUjRJ={'mode':nPSHaYXODecEkstmgpwrfzdxWMUjIb.get('mode')}
   if nPSHaYXODecEkstmgpwrfzdxWMUjIb.get('mode')in['XXX','MENU_BOOKMARK']:
    nPSHaYXODecEkstmgpwrfzdxWMUjIy=nPSHaYXODecEkstmgpwrfzdxWMUjVF
    nPSHaYXODecEkstmgpwrfzdxWMUjIV =nPSHaYXODecEkstmgpwrfzdxWMUjVq
   else:
    nPSHaYXODecEkstmgpwrfzdxWMUjIy=nPSHaYXODecEkstmgpwrfzdxWMUjVq
    nPSHaYXODecEkstmgpwrfzdxWMUjIV =nPSHaYXODecEkstmgpwrfzdxWMUjVF
   if 'icon' in nPSHaYXODecEkstmgpwrfzdxWMUjIb:nPSHaYXODecEkstmgpwrfzdxWMUjbL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',nPSHaYXODecEkstmgpwrfzdxWMUjIb.get('icon')) 
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.add_dir(nPSHaYXODecEkstmgpwrfzdxWMUjRN,sublabel='',img=nPSHaYXODecEkstmgpwrfzdxWMUjbL,infoLabels=nPSHaYXODecEkstmgpwrfzdxWMUjVh,isFolder=nPSHaYXODecEkstmgpwrfzdxWMUjIy,params=nPSHaYXODecEkstmgpwrfzdxWMUjRJ,isLink=nPSHaYXODecEkstmgpwrfzdxWMUjIV)
  xbmcplugin.endOfDirectory(nPSHaYXODecEkstmgpwrfzdxWMUjRi._addon_handle,cacheToDisc=nPSHaYXODecEkstmgpwrfzdxWMUjVF)
 def option_check(nPSHaYXODecEkstmgpwrfzdxWMUjRi):
  nPSHaYXODecEkstmgpwrfzdxWMUjRq=nPSHaYXODecEkstmgpwrfzdxWMUjRi.get_settings_select_info()
  if nPSHaYXODecEkstmgpwrfzdxWMUjVv(nPSHaYXODecEkstmgpwrfzdxWMUjRq)==0:
   nPSHaYXODecEkstmgpwrfzdxWMUjRQ=xbmcgui.Dialog()
   nPSHaYXODecEkstmgpwrfzdxWMUjIR=nPSHaYXODecEkstmgpwrfzdxWMUjRQ.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if nPSHaYXODecEkstmgpwrfzdxWMUjIR==nPSHaYXODecEkstmgpwrfzdxWMUjVq:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in nPSHaYXODecEkstmgpwrfzdxWMUjRq:
   if nPSHaYXODecEkstmgpwrfzdxWMUjRi.NF_cookiefile_check()==nPSHaYXODecEkstmgpwrfzdxWMUjVF:
    nPSHaYXODecEkstmgpwrfzdxWMUjRi.NF_login(showMessage=nPSHaYXODecEkstmgpwrfzdxWMUjVq)
  if 'disney' in nPSHaYXODecEkstmgpwrfzdxWMUjRq:
   if nPSHaYXODecEkstmgpwrfzdxWMUjRi.DZ_cookiefile_check()==nPSHaYXODecEkstmgpwrfzdxWMUjVF:
    nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.DZ={}
 def DZ_cookiefile_check(nPSHaYXODecEkstmgpwrfzdxWMUjRi):
  nPSHaYXODecEkstmgpwrfzdxWMUjIi={}
  try: 
   fp=nPSHaYXODecEkstmgpwrfzdxWMUjVN(nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   nPSHaYXODecEkstmgpwrfzdxWMUjIi= json.load(fp)
   fp.close()
  except nPSHaYXODecEkstmgpwrfzdxWMUjVo as exception:
   return nPSHaYXODecEkstmgpwrfzdxWMUjVF
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.DZ=nPSHaYXODecEkstmgpwrfzdxWMUjIi
  if nPSHaYXODecEkstmgpwrfzdxWMUjGR(time.time())>nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.DZ['account']['token_limit']:
   if nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.DZ_ReToken()==nPSHaYXODecEkstmgpwrfzdxWMUjVF:
    nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_noti(__language__(30920).encode('utf-8'))
    return nPSHaYXODecEkstmgpwrfzdxWMUjVF
   try: 
    fp=nPSHaYXODecEkstmgpwrfzdxWMUjVN(nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.DZ,fp,indent=4,ensure_ascii=nPSHaYXODecEkstmgpwrfzdxWMUjVF)
    fp.close()
   except nPSHaYXODecEkstmgpwrfzdxWMUjVo as exception:
    return nPSHaYXODecEkstmgpwrfzdxWMUjVF
  return nPSHaYXODecEkstmgpwrfzdxWMUjVq
 def NF_cookiefile_check(nPSHaYXODecEkstmgpwrfzdxWMUjRi):
  nPSHaYXODecEkstmgpwrfzdxWMUjIi={}
  try: 
   fp=nPSHaYXODecEkstmgpwrfzdxWMUjVN(nPSHaYXODecEkstmgpwrfzdxWMUjRV,'r',-1,'utf-8')
   nPSHaYXODecEkstmgpwrfzdxWMUjIi= json.load(fp)
   fp.close()
  except nPSHaYXODecEkstmgpwrfzdxWMUjVo as exception:
   return nPSHaYXODecEkstmgpwrfzdxWMUjVF
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF=nPSHaYXODecEkstmgpwrfzdxWMUjIi
  nPSHaYXODecEkstmgpwrfzdxWMUjIC =nPSHaYXODecEkstmgpwrfzdxWMUjGR(nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Now_Datetime().strftime('%Y%m%d'))
  nPSHaYXODecEkstmgpwrfzdxWMUjIl=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF['SESSION']['limitdate']
  nPSHaYXODecEkstmgpwrfzdxWMUjIB =nPSHaYXODecEkstmgpwrfzdxWMUjGR(re.sub('-','',nPSHaYXODecEkstmgpwrfzdxWMUjIl))
  if nPSHaYXODecEkstmgpwrfzdxWMUjIB<nPSHaYXODecEkstmgpwrfzdxWMUjIC:
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Init_NF_Total()
   if nPSHaYXODecEkstmgpwrfzdxWMUjRi.NF_login(showMessage=nPSHaYXODecEkstmgpwrfzdxWMUjVF)==nPSHaYXODecEkstmgpwrfzdxWMUjVF:
    return nPSHaYXODecEkstmgpwrfzdxWMUjVF
  nPSHaYXODecEkstmgpwrfzdxWMUjIQ=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF_CookieFile_Load(nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF_ORIGINAL_COOKIE)
  if(nPSHaYXODecEkstmgpwrfzdxWMUjIQ['NetflixId']!=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF['COOKIES']['NetflixId']or nPSHaYXODecEkstmgpwrfzdxWMUjIQ['SecureNetflixId']!=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF['COOKIES']['SecureNetflixId']or nPSHaYXODecEkstmgpwrfzdxWMUjIQ['flwssn']!=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF['COOKIES']['flwssn']or nPSHaYXODecEkstmgpwrfzdxWMUjIQ['memclid']!=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF['COOKIES']['memclid']or nPSHaYXODecEkstmgpwrfzdxWMUjIQ['nfvdid']!=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF['COOKIES']['nfvdid']):
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Init_NF_Total()
   if nPSHaYXODecEkstmgpwrfzdxWMUjRi.NF_login(showMessage=nPSHaYXODecEkstmgpwrfzdxWMUjVF)==nPSHaYXODecEkstmgpwrfzdxWMUjVF:
    return nPSHaYXODecEkstmgpwrfzdxWMUjVF
  return nPSHaYXODecEkstmgpwrfzdxWMUjVq
 def NF_login(nPSHaYXODecEkstmgpwrfzdxWMUjRi,showMessage=nPSHaYXODecEkstmgpwrfzdxWMUjVq):
  if showMessage:
   nPSHaYXODecEkstmgpwrfzdxWMUjRQ=xbmcgui.Dialog()
   nPSHaYXODecEkstmgpwrfzdxWMUjIR=nPSHaYXODecEkstmgpwrfzdxWMUjRQ.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if nPSHaYXODecEkstmgpwrfzdxWMUjIR==nPSHaYXODecEkstmgpwrfzdxWMUjVF:
    return nPSHaYXODecEkstmgpwrfzdxWMUjVF 
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF['COOKIES']=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF_CookieFile_Load(nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF_ORIGINAL_COOKIE)
  nPSHaYXODecEkstmgpwrfzdxWMUjIK=nPSHaYXODecEkstmgpwrfzdxWMUjVF if nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF['COOKIES']=={}else nPSHaYXODecEkstmgpwrfzdxWMUjVq
  if nPSHaYXODecEkstmgpwrfzdxWMUjIK:
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_log('pass1 ok!')
  else:
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_log('pass1 error!')
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_noti(__language__(30905).encode('utf-8'))
   return nPSHaYXODecEkstmgpwrfzdxWMUjVF 
  nPSHaYXODecEkstmgpwrfzdxWMUjIK=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF_Get_BaseSession()
  if nPSHaYXODecEkstmgpwrfzdxWMUjIK:
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_log('pass2 ok!')
  else:
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_log('pass2 error!')
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_noti(__language__(30905).encode('utf-8'))
   return nPSHaYXODecEkstmgpwrfzdxWMUjVF 
  nPSHaYXODecEkstmgpwrfzdxWMUjIu =nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Now_Datetime()
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF['SESSION']['limitdate']=nPSHaYXODecEkstmgpwrfzdxWMUjIu.strftime('%Y-%m-%d')
  try: 
   fp=nPSHaYXODecEkstmgpwrfzdxWMUjVN(nPSHaYXODecEkstmgpwrfzdxWMUjRV,'w',-1,'utf-8')
   json.dump(nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF,fp,indent=4,ensure_ascii=nPSHaYXODecEkstmgpwrfzdxWMUjVF)
   fp.close()
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_log('pass3 save ok!')
  except nPSHaYXODecEkstmgpwrfzdxWMUjVo as exception:
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_log('pass3 save error!')
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_noti(__language__(30905).encode('utf-8'))
   return nPSHaYXODecEkstmgpwrfzdxWMUjVF
  if showMessage:nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_noti(__language__(30904).encode('utf-8'))
  return nPSHaYXODecEkstmgpwrfzdxWMUjVq
 def NF_logout(nPSHaYXODecEkstmgpwrfzdxWMUjRi):
  nPSHaYXODecEkstmgpwrfzdxWMUjRQ=xbmcgui.Dialog()
  nPSHaYXODecEkstmgpwrfzdxWMUjIR=nPSHaYXODecEkstmgpwrfzdxWMUjRQ.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if nPSHaYXODecEkstmgpwrfzdxWMUjIR==nPSHaYXODecEkstmgpwrfzdxWMUjVF:return 
  if os.path.isfile(nPSHaYXODecEkstmgpwrfzdxWMUjRV):os.remove(nPSHaYXODecEkstmgpwrfzdxWMUjRV)
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(nPSHaYXODecEkstmgpwrfzdxWMUjRi,nPSHaYXODecEkstmgpwrfzdxWMUjIJ):
  nPSHaYXODecEkstmgpwrfzdxWMUjIA=''
  nPSHaYXODecEkstmgpwrfzdxWMUjIh=7
  try:
   for i in nPSHaYXODecEkstmgpwrfzdxWMUjGb(nPSHaYXODecEkstmgpwrfzdxWMUjVv(nPSHaYXODecEkstmgpwrfzdxWMUjIJ)):
    if i>=nPSHaYXODecEkstmgpwrfzdxWMUjIh:
     nPSHaYXODecEkstmgpwrfzdxWMUjIA=nPSHaYXODecEkstmgpwrfzdxWMUjIA+'...'
     break
    nPSHaYXODecEkstmgpwrfzdxWMUjIA=nPSHaYXODecEkstmgpwrfzdxWMUjIA+nPSHaYXODecEkstmgpwrfzdxWMUjIJ[i]['title']+'\n'
  except:
   return ''
  return nPSHaYXODecEkstmgpwrfzdxWMUjIA
 def dp_Search_Group(nPSHaYXODecEkstmgpwrfzdxWMUjRi,args):
  nPSHaYXODecEkstmgpwrfzdxWMUjRq =nPSHaYXODecEkstmgpwrfzdxWMUjRi.get_settings_select_info()
  nPSHaYXODecEkstmgpwrfzdxWMUjIq=[]
  if 'search_key' in args:
   nPSHaYXODecEkstmgpwrfzdxWMUjIF=args.get('search_key')
  else:
   nPSHaYXODecEkstmgpwrfzdxWMUjIF=nPSHaYXODecEkstmgpwrfzdxWMUjRi.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not nPSHaYXODecEkstmgpwrfzdxWMUjIF:
    return
  if 'wavve' in nPSHaYXODecEkstmgpwrfzdxWMUjRq:
   (nPSHaYXODecEkstmgpwrfzdxWMUjIJ,nPSHaYXODecEkstmgpwrfzdxWMUjIL)=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Search_Wavve(nPSHaYXODecEkstmgpwrfzdxWMUjIF,'TVSHOW',1)
   if nPSHaYXODecEkstmgpwrfzdxWMUjVv(nPSHaYXODecEkstmgpwrfzdxWMUjIJ)>0:
    nPSHaYXODecEkstmgpwrfzdxWMUjIN={'sType':'wavve_tvshow','sList':nPSHaYXODecEkstmgpwrfzdxWMUjRi.MakeText_FreeList(nPSHaYXODecEkstmgpwrfzdxWMUjIJ),}
    nPSHaYXODecEkstmgpwrfzdxWMUjIq.append(nPSHaYXODecEkstmgpwrfzdxWMUjIN)
   (nPSHaYXODecEkstmgpwrfzdxWMUjIJ,nPSHaYXODecEkstmgpwrfzdxWMUjIL)=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Search_Wavve(nPSHaYXODecEkstmgpwrfzdxWMUjIF,'MOVIE',1)
   if nPSHaYXODecEkstmgpwrfzdxWMUjVv(nPSHaYXODecEkstmgpwrfzdxWMUjIJ)>0:
    nPSHaYXODecEkstmgpwrfzdxWMUjIN={'sType':'wavve_movie','sList':nPSHaYXODecEkstmgpwrfzdxWMUjRi.MakeText_FreeList(nPSHaYXODecEkstmgpwrfzdxWMUjIJ),}
    nPSHaYXODecEkstmgpwrfzdxWMUjIq.append(nPSHaYXODecEkstmgpwrfzdxWMUjIN)
  if 'tving' in nPSHaYXODecEkstmgpwrfzdxWMUjRq:
   (nPSHaYXODecEkstmgpwrfzdxWMUjIJ,nPSHaYXODecEkstmgpwrfzdxWMUjIL)=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Search_Tving(nPSHaYXODecEkstmgpwrfzdxWMUjIF,'TVSHOW',1)
   if nPSHaYXODecEkstmgpwrfzdxWMUjVv(nPSHaYXODecEkstmgpwrfzdxWMUjIJ)>0:
    nPSHaYXODecEkstmgpwrfzdxWMUjIN={'sType':'tving_tvshow','sList':nPSHaYXODecEkstmgpwrfzdxWMUjRi.MakeText_FreeList(nPSHaYXODecEkstmgpwrfzdxWMUjIJ),}
    nPSHaYXODecEkstmgpwrfzdxWMUjIq.append(nPSHaYXODecEkstmgpwrfzdxWMUjIN)
   (nPSHaYXODecEkstmgpwrfzdxWMUjIJ,nPSHaYXODecEkstmgpwrfzdxWMUjIL)=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Search_Tving(nPSHaYXODecEkstmgpwrfzdxWMUjIF,'MOVIE',1)
   if nPSHaYXODecEkstmgpwrfzdxWMUjVv(nPSHaYXODecEkstmgpwrfzdxWMUjIJ)>0:
    nPSHaYXODecEkstmgpwrfzdxWMUjIN={'sType':'tving_movie','sList':nPSHaYXODecEkstmgpwrfzdxWMUjRi.MakeText_FreeList(nPSHaYXODecEkstmgpwrfzdxWMUjIJ),}
    nPSHaYXODecEkstmgpwrfzdxWMUjIq.append(nPSHaYXODecEkstmgpwrfzdxWMUjIN)
  if 'watcha' in nPSHaYXODecEkstmgpwrfzdxWMUjRq:
   (nPSHaYXODecEkstmgpwrfzdxWMUjIJ,nPSHaYXODecEkstmgpwrfzdxWMUjIL)=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Search_Watcha(nPSHaYXODecEkstmgpwrfzdxWMUjIF,1)
   if nPSHaYXODecEkstmgpwrfzdxWMUjVv(nPSHaYXODecEkstmgpwrfzdxWMUjIJ)>0:
    nPSHaYXODecEkstmgpwrfzdxWMUjIN={'sType':'watcha_list','sList':nPSHaYXODecEkstmgpwrfzdxWMUjRi.MakeText_FreeList(nPSHaYXODecEkstmgpwrfzdxWMUjIJ),}
    nPSHaYXODecEkstmgpwrfzdxWMUjIq.append(nPSHaYXODecEkstmgpwrfzdxWMUjIN)
  if 'coupang' in nPSHaYXODecEkstmgpwrfzdxWMUjRq:
   (nPSHaYXODecEkstmgpwrfzdxWMUjIJ,nPSHaYXODecEkstmgpwrfzdxWMUjIL)=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Search_Coupang(nPSHaYXODecEkstmgpwrfzdxWMUjIF,1)
   if nPSHaYXODecEkstmgpwrfzdxWMUjVv(nPSHaYXODecEkstmgpwrfzdxWMUjIJ)>0:
    nPSHaYXODecEkstmgpwrfzdxWMUjIN={'sType':'coupang_list','sList':nPSHaYXODecEkstmgpwrfzdxWMUjRi.MakeText_FreeList(nPSHaYXODecEkstmgpwrfzdxWMUjIJ),}
    nPSHaYXODecEkstmgpwrfzdxWMUjIq.append(nPSHaYXODecEkstmgpwrfzdxWMUjIN)
  if 'netflix' in nPSHaYXODecEkstmgpwrfzdxWMUjRq:
   try:
    (nPSHaYXODecEkstmgpwrfzdxWMUjIJ,nPSHaYXODecEkstmgpwrfzdxWMUjIL,nPSHaYXODecEkstmgpwrfzdxWMUjIv)=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Search_Netflix(nPSHaYXODecEkstmgpwrfzdxWMUjIF,1)
   except:
    nPSHaYXODecEkstmgpwrfzdxWMUjIJ=[]
    nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_noti(__language__(30919).encode('utf8'))
   if nPSHaYXODecEkstmgpwrfzdxWMUjVv(nPSHaYXODecEkstmgpwrfzdxWMUjIJ)>0:
    nPSHaYXODecEkstmgpwrfzdxWMUjIN={'sType':'netflix_list','sList':nPSHaYXODecEkstmgpwrfzdxWMUjRi.MakeText_FreeList(nPSHaYXODecEkstmgpwrfzdxWMUjIJ),}
    nPSHaYXODecEkstmgpwrfzdxWMUjIq.append(nPSHaYXODecEkstmgpwrfzdxWMUjIN)
  if 'amazon' in nPSHaYXODecEkstmgpwrfzdxWMUjRq:
   (nPSHaYXODecEkstmgpwrfzdxWMUjIJ)=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Search_Primev(nPSHaYXODecEkstmgpwrfzdxWMUjIF)
   if nPSHaYXODecEkstmgpwrfzdxWMUjVv(nPSHaYXODecEkstmgpwrfzdxWMUjIJ)>0:
    nPSHaYXODecEkstmgpwrfzdxWMUjIN={'sType':'primev_list','sList':nPSHaYXODecEkstmgpwrfzdxWMUjRi.MakeText_FreeList(nPSHaYXODecEkstmgpwrfzdxWMUjIJ),}
    nPSHaYXODecEkstmgpwrfzdxWMUjIq.append(nPSHaYXODecEkstmgpwrfzdxWMUjIN)
  if 'disney' in nPSHaYXODecEkstmgpwrfzdxWMUjRq:
   try:
    (nPSHaYXODecEkstmgpwrfzdxWMUjIJ)=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Search_Disney(nPSHaYXODecEkstmgpwrfzdxWMUjIF)
   except:
    nPSHaYXODecEkstmgpwrfzdxWMUjIJ=[]
    nPSHaYXODecEkstmgpwrfzdxWMUjRi.addon_noti(__language__(30921).encode('utf8'))
   if nPSHaYXODecEkstmgpwrfzdxWMUjVv(nPSHaYXODecEkstmgpwrfzdxWMUjIJ)>0:
    nPSHaYXODecEkstmgpwrfzdxWMUjIN={'sType':'disney_list','sList':nPSHaYXODecEkstmgpwrfzdxWMUjRi.MakeText_FreeList(nPSHaYXODecEkstmgpwrfzdxWMUjIJ),}
    nPSHaYXODecEkstmgpwrfzdxWMUjIq.append(nPSHaYXODecEkstmgpwrfzdxWMUjIN)
  for nPSHaYXODecEkstmgpwrfzdxWMUjIo in nPSHaYXODecEkstmgpwrfzdxWMUjIq:
   nPSHaYXODecEkstmgpwrfzdxWMUjyR=nPSHaYXODecEkstmgpwrfzdxWMUjRy[nPSHaYXODecEkstmgpwrfzdxWMUjIo.get('sType')]
   nPSHaYXODecEkstmgpwrfzdxWMUjyb={'plot':'검색어 : '+nPSHaYXODecEkstmgpwrfzdxWMUjIF+'\n\n'+nPSHaYXODecEkstmgpwrfzdxWMUjIo.get('sList')}
   nPSHaYXODecEkstmgpwrfzdxWMUjRN=nPSHaYXODecEkstmgpwrfzdxWMUjyR.get('title')
   nPSHaYXODecEkstmgpwrfzdxWMUjRJ={'mode':nPSHaYXODecEkstmgpwrfzdxWMUjyR.get('mode'),'ott':nPSHaYXODecEkstmgpwrfzdxWMUjyR.get('ott'),'vidtype':nPSHaYXODecEkstmgpwrfzdxWMUjyR.get('vidtype'),'search_key':nPSHaYXODecEkstmgpwrfzdxWMUjIF}
   if nPSHaYXODecEkstmgpwrfzdxWMUjyR.get('ott')=='netflix':
    nPSHaYXODecEkstmgpwrfzdxWMUjyI=''
    nPSHaYXODecEkstmgpwrfzdxWMUjRJ['page'] ='1'
    nPSHaYXODecEkstmgpwrfzdxWMUjRJ['byReference']='-'
   else:
    nPSHaYXODecEkstmgpwrfzdxWMUjyI=nPSHaYXODecEkstmgpwrfzdxWMUjRi.make_Hyper_Link(nPSHaYXODecEkstmgpwrfzdxWMUjRJ)
   nPSHaYXODecEkstmgpwrfzdxWMUjbL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',nPSHaYXODecEkstmgpwrfzdxWMUjyR.get('icon'))
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.add_dir(nPSHaYXODecEkstmgpwrfzdxWMUjRN,sublabel='',img=nPSHaYXODecEkstmgpwrfzdxWMUjbL,infoLabels=nPSHaYXODecEkstmgpwrfzdxWMUjyb,isFolder=nPSHaYXODecEkstmgpwrfzdxWMUjVq,params=nPSHaYXODecEkstmgpwrfzdxWMUjRJ,isLink=nPSHaYXODecEkstmgpwrfzdxWMUjVF,direct_url=nPSHaYXODecEkstmgpwrfzdxWMUjyI)
  xbmcplugin.endOfDirectory(nPSHaYXODecEkstmgpwrfzdxWMUjRi._addon_handle)
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.Save_Searched_List(nPSHaYXODecEkstmgpwrfzdxWMUjIF)
 def make_Hyper_Link(nPSHaYXODecEkstmgpwrfzdxWMUjRi,args):
  nPSHaYXODecEkstmgpwrfzdxWMUjyV =args.get('ott')
  nPSHaYXODecEkstmgpwrfzdxWMUjyG =args.get('vidtype')
  nPSHaYXODecEkstmgpwrfzdxWMUjIF=args.get('search_key')
  nPSHaYXODecEkstmgpwrfzdxWMUjyI='-'
  if nPSHaYXODecEkstmgpwrfzdxWMUjyV=='wavve':
   nPSHaYXODecEkstmgpwrfzdxWMUjyi={'mode':'LOCAL_SEARCH','sType':'movie' if nPSHaYXODecEkstmgpwrfzdxWMUjyG=='MOVIE' else 'vod','search_key':nPSHaYXODecEkstmgpwrfzdxWMUjIF,'page':'1',}
   nPSHaYXODecEkstmgpwrfzdxWMUjyT=urllib.parse.urlencode(nPSHaYXODecEkstmgpwrfzdxWMUjyi)
   nPSHaYXODecEkstmgpwrfzdxWMUjyI='plugin://plugin.video.wavvem/?'
   nPSHaYXODecEkstmgpwrfzdxWMUjyI+=nPSHaYXODecEkstmgpwrfzdxWMUjyT
  elif nPSHaYXODecEkstmgpwrfzdxWMUjyV=='tving':
   nPSHaYXODecEkstmgpwrfzdxWMUjyi={'mode':'LOCAL_SEARCH','stype':'movie' if nPSHaYXODecEkstmgpwrfzdxWMUjyG=='MOVIE' else 'vod','search_key':nPSHaYXODecEkstmgpwrfzdxWMUjIF,'page':'1',}
   nPSHaYXODecEkstmgpwrfzdxWMUjyT=urllib.parse.urlencode(nPSHaYXODecEkstmgpwrfzdxWMUjyi)
   nPSHaYXODecEkstmgpwrfzdxWMUjyI='plugin://plugin.video.tvingm/?'
   nPSHaYXODecEkstmgpwrfzdxWMUjyI+=nPSHaYXODecEkstmgpwrfzdxWMUjyT
  elif nPSHaYXODecEkstmgpwrfzdxWMUjyV=='watcha':
   nPSHaYXODecEkstmgpwrfzdxWMUjyi={'mode':'LOCAL_SEARCH','search_key':nPSHaYXODecEkstmgpwrfzdxWMUjIF,'page':'1',}
   nPSHaYXODecEkstmgpwrfzdxWMUjyT=urllib.parse.urlencode(nPSHaYXODecEkstmgpwrfzdxWMUjyi)
   nPSHaYXODecEkstmgpwrfzdxWMUjyI='plugin://plugin.video.watcham/?'
   nPSHaYXODecEkstmgpwrfzdxWMUjyI+=nPSHaYXODecEkstmgpwrfzdxWMUjyT
  elif nPSHaYXODecEkstmgpwrfzdxWMUjyV=='coupang':
   nPSHaYXODecEkstmgpwrfzdxWMUjyi={'mode':'LOCAL_SEARCH','search_key':nPSHaYXODecEkstmgpwrfzdxWMUjIF,'page':'1',}
   nPSHaYXODecEkstmgpwrfzdxWMUjyT=urllib.parse.urlencode(nPSHaYXODecEkstmgpwrfzdxWMUjyi)
   nPSHaYXODecEkstmgpwrfzdxWMUjyI='plugin://plugin.video.coupangm/?'
   nPSHaYXODecEkstmgpwrfzdxWMUjyI+=nPSHaYXODecEkstmgpwrfzdxWMUjyT
  elif nPSHaYXODecEkstmgpwrfzdxWMUjyV=='netflix':
   nPSHaYXODecEkstmgpwrfzdxWMUjyC=args.get('videoid')
   nPSHaYXODecEkstmgpwrfzdxWMUjyl=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.NF['SESSION']['nowGuid']
   if nPSHaYXODecEkstmgpwrfzdxWMUjyG=='TVSHOW':
    nPSHaYXODecEkstmgpwrfzdxWMUjyI='plugin://plugin.video.netflix/directory/show/%s/'%(nPSHaYXODecEkstmgpwrfzdxWMUjyC)
   else:
    nPSHaYXODecEkstmgpwrfzdxWMUjyI='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(nPSHaYXODecEkstmgpwrfzdxWMUjyC,nPSHaYXODecEkstmgpwrfzdxWMUjyl)
  elif nPSHaYXODecEkstmgpwrfzdxWMUjyV=='amazon':
   nPSHaYXODecEkstmgpwrfzdxWMUjyi={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':nPSHaYXODecEkstmgpwrfzdxWMUjIF,}}
   nPSHaYXODecEkstmgpwrfzdxWMUjyT=json.dumps(nPSHaYXODecEkstmgpwrfzdxWMUjyi,separators=(',',':'))
   nPSHaYXODecEkstmgpwrfzdxWMUjyT=base64.standard_b64encode(nPSHaYXODecEkstmgpwrfzdxWMUjyT.encode()).decode('utf-8')
   nPSHaYXODecEkstmgpwrfzdxWMUjyT=nPSHaYXODecEkstmgpwrfzdxWMUjyT.replace('+','%2B')
   nPSHaYXODecEkstmgpwrfzdxWMUjyI='plugin://plugin.video.primevm/?params='
   nPSHaYXODecEkstmgpwrfzdxWMUjyI+=nPSHaYXODecEkstmgpwrfzdxWMUjyT
  elif nPSHaYXODecEkstmgpwrfzdxWMUjyV=='disney':
   nPSHaYXODecEkstmgpwrfzdxWMUjyi={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':nPSHaYXODecEkstmgpwrfzdxWMUjIF,}}
   nPSHaYXODecEkstmgpwrfzdxWMUjyT=json.dumps(nPSHaYXODecEkstmgpwrfzdxWMUjyi,separators=(',',':'))
   nPSHaYXODecEkstmgpwrfzdxWMUjyT=base64.standard_b64encode(nPSHaYXODecEkstmgpwrfzdxWMUjyT.encode()).decode('utf-8')
   nPSHaYXODecEkstmgpwrfzdxWMUjyT=nPSHaYXODecEkstmgpwrfzdxWMUjyT.replace('+','%2B')
   nPSHaYXODecEkstmgpwrfzdxWMUjyI='plugin://plugin.video.disneym/?params='
   nPSHaYXODecEkstmgpwrfzdxWMUjyI+=nPSHaYXODecEkstmgpwrfzdxWMUjyT
  return nPSHaYXODecEkstmgpwrfzdxWMUjyI
 def dp_Nf_Search(nPSHaYXODecEkstmgpwrfzdxWMUjRi,args):
  nPSHaYXODecEkstmgpwrfzdxWMUjyB =nPSHaYXODecEkstmgpwrfzdxWMUjGR(args.get('page'))
  nPSHaYXODecEkstmgpwrfzdxWMUjIF =args.get('search_key')
  nPSHaYXODecEkstmgpwrfzdxWMUjIv=args.get('byReference')
  (nPSHaYXODecEkstmgpwrfzdxWMUjIJ,nPSHaYXODecEkstmgpwrfzdxWMUjIL,nPSHaYXODecEkstmgpwrfzdxWMUjIv)=nPSHaYXODecEkstmgpwrfzdxWMUjRi.SearchObj.Get_Search_Netflix(nPSHaYXODecEkstmgpwrfzdxWMUjIF,nPSHaYXODecEkstmgpwrfzdxWMUjyB,byReference=nPSHaYXODecEkstmgpwrfzdxWMUjIv)
  for nPSHaYXODecEkstmgpwrfzdxWMUjyQ in nPSHaYXODecEkstmgpwrfzdxWMUjIJ:
   nPSHaYXODecEkstmgpwrfzdxWMUjyC =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('videoid')
   nPSHaYXODecEkstmgpwrfzdxWMUjyG =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('vidtype')
   nPSHaYXODecEkstmgpwrfzdxWMUjRN =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('title')
   nPSHaYXODecEkstmgpwrfzdxWMUjyK =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('mpaa')
   nPSHaYXODecEkstmgpwrfzdxWMUjyu =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('regularSynopsis')
   nPSHaYXODecEkstmgpwrfzdxWMUjyA =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('dpSupplemental')
   nPSHaYXODecEkstmgpwrfzdxWMUjyh=nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('sequiturEvidence')
   nPSHaYXODecEkstmgpwrfzdxWMUjyq =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('thumbnail')
   nPSHaYXODecEkstmgpwrfzdxWMUjyF =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('year')
   nPSHaYXODecEkstmgpwrfzdxWMUjyJ =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('duration')
   nPSHaYXODecEkstmgpwrfzdxWMUjyL =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('info_genre')
   nPSHaYXODecEkstmgpwrfzdxWMUjyN =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('director')
   nPSHaYXODecEkstmgpwrfzdxWMUjyv =nPSHaYXODecEkstmgpwrfzdxWMUjyQ.get('cast')
   if nPSHaYXODecEkstmgpwrfzdxWMUjyG=='movie':
    nPSHaYXODecEkstmgpwrfzdxWMUjbF=' (%s)'%(nPSHaYXODecEkstmgpwrfzdxWMUjGI(nPSHaYXODecEkstmgpwrfzdxWMUjyF))
   else:
    nPSHaYXODecEkstmgpwrfzdxWMUjbF=''
   nPSHaYXODecEkstmgpwrfzdxWMUjyo=''
   if nPSHaYXODecEkstmgpwrfzdxWMUjyu:nPSHaYXODecEkstmgpwrfzdxWMUjyo=nPSHaYXODecEkstmgpwrfzdxWMUjyo+'\n\n'+nPSHaYXODecEkstmgpwrfzdxWMUjyu
   if nPSHaYXODecEkstmgpwrfzdxWMUjyA :nPSHaYXODecEkstmgpwrfzdxWMUjyo=nPSHaYXODecEkstmgpwrfzdxWMUjyo+'\n\n'+nPSHaYXODecEkstmgpwrfzdxWMUjyA
   if nPSHaYXODecEkstmgpwrfzdxWMUjyh:nPSHaYXODecEkstmgpwrfzdxWMUjyo=nPSHaYXODecEkstmgpwrfzdxWMUjyo+'\n\n'+nPSHaYXODecEkstmgpwrfzdxWMUjyh
   nPSHaYXODecEkstmgpwrfzdxWMUjyo=nPSHaYXODecEkstmgpwrfzdxWMUjyo.strip()
   nPSHaYXODecEkstmgpwrfzdxWMUjbJ={'mediatype':'tvshow' if nPSHaYXODecEkstmgpwrfzdxWMUjyG=='show' else 'movie','title':nPSHaYXODecEkstmgpwrfzdxWMUjRN,'mpaa':nPSHaYXODecEkstmgpwrfzdxWMUjyK,'plot':nPSHaYXODecEkstmgpwrfzdxWMUjyo,'duration':nPSHaYXODecEkstmgpwrfzdxWMUjyJ,'genre':nPSHaYXODecEkstmgpwrfzdxWMUjyL,'director':nPSHaYXODecEkstmgpwrfzdxWMUjyN,'cast':nPSHaYXODecEkstmgpwrfzdxWMUjyv,'year':nPSHaYXODecEkstmgpwrfzdxWMUjyF,}
   nPSHaYXODecEkstmgpwrfzdxWMUjRJ={'ott':'netflix','vidtype':'TVSHOW' if nPSHaYXODecEkstmgpwrfzdxWMUjyG=='show' else 'MOVIE','videoid':nPSHaYXODecEkstmgpwrfzdxWMUjyC,}
   nPSHaYXODecEkstmgpwrfzdxWMUjyI=nPSHaYXODecEkstmgpwrfzdxWMUjRi.make_Hyper_Link(nPSHaYXODecEkstmgpwrfzdxWMUjRJ)
   nPSHaYXODecEkstmgpwrfzdxWMUjIy=nPSHaYXODecEkstmgpwrfzdxWMUjVq if nPSHaYXODecEkstmgpwrfzdxWMUjyG=='show' else nPSHaYXODecEkstmgpwrfzdxWMUjVF
   if nPSHaYXODecEkstmgpwrfzdxWMUjRi.get_settings_makebookmark():
    nPSHaYXODecEkstmgpwrfzdxWMUjVR={'mode':'SET_BOOKMARK','values':{'videoid':nPSHaYXODecEkstmgpwrfzdxWMUjyC,'vidtype':'tvshow' if nPSHaYXODecEkstmgpwrfzdxWMUjyG=='show' else 'movie','vtitle':nPSHaYXODecEkstmgpwrfzdxWMUjRN+nPSHaYXODecEkstmgpwrfzdxWMUjbF,'vsubtitle':'','vinfo':nPSHaYXODecEkstmgpwrfzdxWMUjbJ,'thumbnail':nPSHaYXODecEkstmgpwrfzdxWMUjyq,}}
    nPSHaYXODecEkstmgpwrfzdxWMUjVb=json.dumps(nPSHaYXODecEkstmgpwrfzdxWMUjVR,separators=(',',':'))
    nPSHaYXODecEkstmgpwrfzdxWMUjVb=base64.standard_b64encode(nPSHaYXODecEkstmgpwrfzdxWMUjVb.encode()).decode('utf-8')
    nPSHaYXODecEkstmgpwrfzdxWMUjVb=nPSHaYXODecEkstmgpwrfzdxWMUjVb.replace('+','%2B')
    nPSHaYXODecEkstmgpwrfzdxWMUjVI='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(nPSHaYXODecEkstmgpwrfzdxWMUjVb)
    nPSHaYXODecEkstmgpwrfzdxWMUjbq=[('(통합) 찜 영상에 추가',nPSHaYXODecEkstmgpwrfzdxWMUjVI)]
   else:
    nPSHaYXODecEkstmgpwrfzdxWMUjbq=nPSHaYXODecEkstmgpwrfzdxWMUjVh
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.add_dir(nPSHaYXODecEkstmgpwrfzdxWMUjRN+nPSHaYXODecEkstmgpwrfzdxWMUjbF,sublabel=nPSHaYXODecEkstmgpwrfzdxWMUjVh,img=nPSHaYXODecEkstmgpwrfzdxWMUjyq,infoLabels=nPSHaYXODecEkstmgpwrfzdxWMUjbJ,isFolder=nPSHaYXODecEkstmgpwrfzdxWMUjIy,params=nPSHaYXODecEkstmgpwrfzdxWMUjRJ,isLink=nPSHaYXODecEkstmgpwrfzdxWMUjVF,ContextMenu=nPSHaYXODecEkstmgpwrfzdxWMUjbq,direct_url=nPSHaYXODecEkstmgpwrfzdxWMUjyI)
  if nPSHaYXODecEkstmgpwrfzdxWMUjIL:
   nPSHaYXODecEkstmgpwrfzdxWMUjRJ={}
   nPSHaYXODecEkstmgpwrfzdxWMUjRJ['mode'] ='NF_SEARCH' 
   nPSHaYXODecEkstmgpwrfzdxWMUjRJ['page'] =nPSHaYXODecEkstmgpwrfzdxWMUjGI(nPSHaYXODecEkstmgpwrfzdxWMUjyB+1)
   nPSHaYXODecEkstmgpwrfzdxWMUjRJ['search_key']=nPSHaYXODecEkstmgpwrfzdxWMUjIF
   nPSHaYXODecEkstmgpwrfzdxWMUjRJ['byReference']=nPSHaYXODecEkstmgpwrfzdxWMUjIv
   nPSHaYXODecEkstmgpwrfzdxWMUjRN='[B]%s >>[/B]'%'다음 페이지'
   nPSHaYXODecEkstmgpwrfzdxWMUjVy=nPSHaYXODecEkstmgpwrfzdxWMUjGI(nPSHaYXODecEkstmgpwrfzdxWMUjyB+1)
   nPSHaYXODecEkstmgpwrfzdxWMUjbL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.add_dir(nPSHaYXODecEkstmgpwrfzdxWMUjRN,sublabel=nPSHaYXODecEkstmgpwrfzdxWMUjVy,img=nPSHaYXODecEkstmgpwrfzdxWMUjbL,infoLabels=nPSHaYXODecEkstmgpwrfzdxWMUjVh,isFolder=nPSHaYXODecEkstmgpwrfzdxWMUjVq,params=nPSHaYXODecEkstmgpwrfzdxWMUjRJ)
  xbmcplugin.setContent(nPSHaYXODecEkstmgpwrfzdxWMUjRi._addon_handle,'movies')
  xbmcplugin.endOfDirectory(nPSHaYXODecEkstmgpwrfzdxWMUjRi._addon_handle)
 def dp_Bookmark_Menu(nPSHaYXODecEkstmgpwrfzdxWMUjRi,args):
  nPSHaYXODecEkstmgpwrfzdxWMUjVG='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(nPSHaYXODecEkstmgpwrfzdxWMUjVG)
 def dp_Set_Bookmark(nPSHaYXODecEkstmgpwrfzdxWMUjRi,args):
  nPSHaYXODecEkstmgpwrfzdxWMUjyC =args.get('videoid')
  nPSHaYXODecEkstmgpwrfzdxWMUjyG =args.get('vidtype')
  nPSHaYXODecEkstmgpwrfzdxWMUjVi =args.get('vtitle')
  nPSHaYXODecEkstmgpwrfzdxWMUjVT =args.get('vsubtitle')
  nPSHaYXODecEkstmgpwrfzdxWMUjVC =args.get('vinfo')
  nPSHaYXODecEkstmgpwrfzdxWMUjyq =args.get('thumbnail')
  nPSHaYXODecEkstmgpwrfzdxWMUjRQ=xbmcgui.Dialog()
  nPSHaYXODecEkstmgpwrfzdxWMUjIR=nPSHaYXODecEkstmgpwrfzdxWMUjRQ.yesno(__language__(30917).encode('utf8'),nPSHaYXODecEkstmgpwrfzdxWMUjVi+' \n\n'+__language__(30918))
  if nPSHaYXODecEkstmgpwrfzdxWMUjIR==nPSHaYXODecEkstmgpwrfzdxWMUjVF:return
  nPSHaYXODecEkstmgpwrfzdxWMUjVl={'indexinfo':{'ott':'netflix','videoid':nPSHaYXODecEkstmgpwrfzdxWMUjyC,'vidtype':nPSHaYXODecEkstmgpwrfzdxWMUjyG,},'saveinfo':{'title':nPSHaYXODecEkstmgpwrfzdxWMUjVi,'subtitle':nPSHaYXODecEkstmgpwrfzdxWMUjVT,'thumbnail':nPSHaYXODecEkstmgpwrfzdxWMUjyq,'infoLabels':nPSHaYXODecEkstmgpwrfzdxWMUjVC,},}
  nPSHaYXODecEkstmgpwrfzdxWMUjRJ={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':nPSHaYXODecEkstmgpwrfzdxWMUjVl,}}
  nPSHaYXODecEkstmgpwrfzdxWMUjRL=json.dumps(nPSHaYXODecEkstmgpwrfzdxWMUjRJ,separators=(',',':'))
  nPSHaYXODecEkstmgpwrfzdxWMUjRL=base64.standard_b64encode(nPSHaYXODecEkstmgpwrfzdxWMUjRL.encode()).decode('utf-8')
  nPSHaYXODecEkstmgpwrfzdxWMUjRL=nPSHaYXODecEkstmgpwrfzdxWMUjRL.replace('+','%2B')
  nPSHaYXODecEkstmgpwrfzdxWMUjVI='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(nPSHaYXODecEkstmgpwrfzdxWMUjRL)
  xbmc.executebuiltin(nPSHaYXODecEkstmgpwrfzdxWMUjVI)
 def search_main(nPSHaYXODecEkstmgpwrfzdxWMUjRi):
  nPSHaYXODecEkstmgpwrfzdxWMUjVB=nPSHaYXODecEkstmgpwrfzdxWMUjRi.main_params.get('params')
  if nPSHaYXODecEkstmgpwrfzdxWMUjVB:
   nPSHaYXODecEkstmgpwrfzdxWMUjVQ =base64.standard_b64decode(nPSHaYXODecEkstmgpwrfzdxWMUjVB).decode('utf-8')
   nPSHaYXODecEkstmgpwrfzdxWMUjVQ =json.loads(nPSHaYXODecEkstmgpwrfzdxWMUjVQ)
   nPSHaYXODecEkstmgpwrfzdxWMUjVK =nPSHaYXODecEkstmgpwrfzdxWMUjVQ.get('mode')
   nPSHaYXODecEkstmgpwrfzdxWMUjVu =nPSHaYXODecEkstmgpwrfzdxWMUjVQ.get('values')
  else:
   nPSHaYXODecEkstmgpwrfzdxWMUjVK=nPSHaYXODecEkstmgpwrfzdxWMUjRi.main_params.get('mode',nPSHaYXODecEkstmgpwrfzdxWMUjVh)
   nPSHaYXODecEkstmgpwrfzdxWMUjVu=nPSHaYXODecEkstmgpwrfzdxWMUjRi.main_params
  if nPSHaYXODecEkstmgpwrfzdxWMUjVK=='NFLOGOUT':
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.NF_logout()
   return
  elif nPSHaYXODecEkstmgpwrfzdxWMUjVK=='NFLOGIN':
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.NF_login(showMessage=nPSHaYXODecEkstmgpwrfzdxWMUjVq)
   return
  nPSHaYXODecEkstmgpwrfzdxWMUjRi.option_check()
  if nPSHaYXODecEkstmgpwrfzdxWMUjVK is nPSHaYXODecEkstmgpwrfzdxWMUjVh:
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.dp_Main_List()
  elif nPSHaYXODecEkstmgpwrfzdxWMUjVK=='TOTAL_SEARCH':
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.dp_Search_Group(nPSHaYXODecEkstmgpwrfzdxWMUjVu)
  elif nPSHaYXODecEkstmgpwrfzdxWMUjVK=='NF_SEARCH':
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.dp_Nf_Search(nPSHaYXODecEkstmgpwrfzdxWMUjVu)
  elif nPSHaYXODecEkstmgpwrfzdxWMUjVK=='TOTAL_HISTORY':
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.dp_Search_History(nPSHaYXODecEkstmgpwrfzdxWMUjVu)
  elif nPSHaYXODecEkstmgpwrfzdxWMUjVK=='HISTORY_REMOVE':
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.dp_History_Delete(nPSHaYXODecEkstmgpwrfzdxWMUjVu)
  elif nPSHaYXODecEkstmgpwrfzdxWMUjVK=='MENU_BOOKMARK':
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.dp_Bookmark_Menu(nPSHaYXODecEkstmgpwrfzdxWMUjVu)
  elif nPSHaYXODecEkstmgpwrfzdxWMUjVK=='SET_BOOKMARK':
   nPSHaYXODecEkstmgpwrfzdxWMUjRi.dp_Set_Bookmark(nPSHaYXODecEkstmgpwrfzdxWMUjVu)
  else:
   nPSHaYXODecEkstmgpwrfzdxWMUjVh
# Created by pyminifier (https://github.com/liftoff/pyminifier)
