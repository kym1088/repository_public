__author__="NightRain"
RUCnEBvKeohtqfxVsapFLNJdgrWDAS=object
RUCnEBvKeohtqfxVsapFLNJdgrWDAj=None
RUCnEBvKeohtqfxVsapFLNJdgrWDAM=False
RUCnEBvKeohtqfxVsapFLNJdgrWDAc=print
RUCnEBvKeohtqfxVsapFLNJdgrWDAI=str
RUCnEBvKeohtqfxVsapFLNJdgrWDAw=int
RUCnEBvKeohtqfxVsapFLNJdgrWDAO=Exception
RUCnEBvKeohtqfxVsapFLNJdgrWDAY=True
RUCnEBvKeohtqfxVsapFLNJdgrWDGm=open
RUCnEBvKeohtqfxVsapFLNJdgrWDGy=isinstance
RUCnEBvKeohtqfxVsapFLNJdgrWDGi=list
RUCnEBvKeohtqfxVsapFLNJdgrWDGb=dict
RUCnEBvKeohtqfxVsapFLNJdgrWDGA=range
RUCnEBvKeohtqfxVsapFLNJdgrWDGl=len
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class RUCnEBvKeohtqfxVsapFLNJdgrWDmy(RUCnEBvKeohtqfxVsapFLNJdgrWDAS):
 def __init__(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.DEFAULT_HEADER ={'user-agent':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.USER_AGENT}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_WAVVE ='https://apis.wavve.com'
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_TVING_SEARCH='https://search.tving.com'
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_TVING_IMG ='https://image.tving.com'
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_WATCHA ='https://api-mars.watcha.com'
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX ='https://www.netflix.com'
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.WAVVE_LIMIT =20 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.TVING_LIMIT =30
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.WATCHA_LIMIT =30
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_LIMIT =20 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.DERECTOR_LIMIT =4
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.CAST_LIMIT =10
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.GENRE_LIMIT =4
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.TVING_MOVIE_LITE=['2610061','2610161','261062']
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_HEADER={'user-agent':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND1 ='_342x192'
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND2 ='_665x375'
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_PORT ='_342x684'
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LOGO ='_550x124'
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF={}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']={}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']={}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.Init_NF_Cookies()
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.Init_NF_Session()
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_COOKIES1 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_COOKIES2 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_COOKIES3 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_COOKIES4 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_FULLTEXT1 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_FULLTEXT2 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_FULLTEXT3 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_FULLTEXT4 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_CONTEXTJSON_FILE1 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_CONTEXTJSON_FILE2 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_CONTEXTJSON_FILE3 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_CONTEXTJSON_FILE4 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_FALCORJSON_FILE1 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_FALCORJSON_FILE2 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_FALCORJSON_FILE3 =''
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_FALCORJSON_FILE4 =''
 def callRequestCookies(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,jobtype,RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,params=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,redirects=RUCnEBvKeohtqfxVsapFLNJdgrWDAM):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmb=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.DEFAULT_HEADER
  if headers:RUCnEBvKeohtqfxVsapFLNJdgrWDmb.update(headers)
  if jobtype=='Get':
   RUCnEBvKeohtqfxVsapFLNJdgrWDmA=requests.get(RUCnEBvKeohtqfxVsapFLNJdgrWDmH,params=params,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDmb,cookies=cookies,allow_redirects=redirects)
  else:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmA=requests.post(RUCnEBvKeohtqfxVsapFLNJdgrWDmH,data=payload,params=params,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDmb,cookies=cookies,allow_redirects=redirects)
  return RUCnEBvKeohtqfxVsapFLNJdgrWDmA
 def callRequestCookies_NF(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,jobtype,RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,params=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,redirects=RUCnEBvKeohtqfxVsapFLNJdgrWDAM,addCookie=''):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmb=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_HEADER
  if headers:RUCnEBvKeohtqfxVsapFLNJdgrWDmb.update(headers)
  if jobtype=='Get':
   RUCnEBvKeohtqfxVsapFLNJdgrWDmA=requests.get(RUCnEBvKeohtqfxVsapFLNJdgrWDmH,params=params,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDmb,cookies=cookies,allow_redirects=redirects)
  else:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmA=requests.post(RUCnEBvKeohtqfxVsapFLNJdgrWDmH,data=payload,params=params,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDmb,cookies=cookies,allow_redirects=redirects)
  RUCnEBvKeohtqfxVsapFLNJdgrWDAc(RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDmA.status_code)+' - '+RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDmA.url))
  '''
  print(res.url )
  print(res.status_code )
  print(res.cookies )
  print(res.text )
  '''  
  try:
   if addCookie=='baseurl':
    if 'location' in RUCnEBvKeohtqfxVsapFLNJdgrWDmA.headers:
     RUCnEBvKeohtqfxVsapFLNJdgrWDmG=urllib.parse.urlsplit(RUCnEBvKeohtqfxVsapFLNJdgrWDmA.headers.get('location')).path
     RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['contryurl']=RUCnEBvKeohtqfxVsapFLNJdgrWDmG[1:3]
  except:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAj
  for RUCnEBvKeohtqfxVsapFLNJdgrWDml in RUCnEBvKeohtqfxVsapFLNJdgrWDmA.cookies:
   if RUCnEBvKeohtqfxVsapFLNJdgrWDml.name=='flwssn':
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['flwssn']['value'] =RUCnEBvKeohtqfxVsapFLNJdgrWDml.value
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['flwssn']['expires'] =RUCnEBvKeohtqfxVsapFLNJdgrWDml.expires
   elif RUCnEBvKeohtqfxVsapFLNJdgrWDml.name=='nfvdid':
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['nfvdid']['value'] =RUCnEBvKeohtqfxVsapFLNJdgrWDml.value
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['nfvdid']['expires'] =RUCnEBvKeohtqfxVsapFLNJdgrWDml.expires
   elif RUCnEBvKeohtqfxVsapFLNJdgrWDml.name=='SecureNetflixId':
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['SecureNetflixId']['value'] =RUCnEBvKeohtqfxVsapFLNJdgrWDml.value
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['SecureNetflixId']['expires'] =RUCnEBvKeohtqfxVsapFLNJdgrWDml.expires
   elif RUCnEBvKeohtqfxVsapFLNJdgrWDml.name=='NetflixId':
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['NetflixId']['value'] =RUCnEBvKeohtqfxVsapFLNJdgrWDml.value
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['NetflixId']['expires'] =RUCnEBvKeohtqfxVsapFLNJdgrWDml.expires
   elif RUCnEBvKeohtqfxVsapFLNJdgrWDml.name=='memclid':
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['memclid']['value'] =RUCnEBvKeohtqfxVsapFLNJdgrWDml.value
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['memclid']['expires'] =RUCnEBvKeohtqfxVsapFLNJdgrWDml.expires
   elif RUCnEBvKeohtqfxVsapFLNJdgrWDml.name=='clSharedContext':
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['clSharedContext']['value'] =RUCnEBvKeohtqfxVsapFLNJdgrWDml.value
    RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['clSharedContext']['expires'] =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.GetNoCache(timetype=1,minutes=5)
  return RUCnEBvKeohtqfxVsapFLNJdgrWDmA
 def GetNoCache(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,timetype=1,minutes=0):
  if timetype==1:
   ts=RUCnEBvKeohtqfxVsapFLNJdgrWDAw(time.time())
   mi=RUCnEBvKeohtqfxVsapFLNJdgrWDAw(minutes*60)
  else:
   ts=RUCnEBvKeohtqfxVsapFLNJdgrWDAw(time.time()*1000)
   mi=RUCnEBvKeohtqfxVsapFLNJdgrWDAw(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,search_key,sType,page_int):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmX=[]
  RUCnEBvKeohtqfxVsapFLNJdgrWDmQ=RUCnEBvKeohtqfxVsapFLNJdgrWDyi=1
  RUCnEBvKeohtqfxVsapFLNJdgrWDmP=RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmH=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_WAVVE+'/cf/search/list.js'
   RUCnEBvKeohtqfxVsapFLNJdgrWDmk={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':RUCnEBvKeohtqfxVsapFLNJdgrWDAI((page_int-1)*RUCnEBvKeohtqfxVsapFLNJdgrWDmi.WAVVE_LIMIT),'limit':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.WAVVE_LIMIT,'orderby':'score'}
   RUCnEBvKeohtqfxVsapFLNJdgrWDmk.update(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.WAVVE_PARAMS)
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.callRequestCookies('Get',RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,params=RUCnEBvKeohtqfxVsapFLNJdgrWDmk,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDAj)
   RUCnEBvKeohtqfxVsapFLNJdgrWDmz=json.loads(RUCnEBvKeohtqfxVsapFLNJdgrWDmT.text)
   if not('celllist' in RUCnEBvKeohtqfxVsapFLNJdgrWDmz['cell_toplist']):return RUCnEBvKeohtqfxVsapFLNJdgrWDmX,RUCnEBvKeohtqfxVsapFLNJdgrWDmP
   RUCnEBvKeohtqfxVsapFLNJdgrWDmS=RUCnEBvKeohtqfxVsapFLNJdgrWDmz['cell_toplist']['celllist']
   for RUCnEBvKeohtqfxVsapFLNJdgrWDmj in RUCnEBvKeohtqfxVsapFLNJdgrWDmS:
    RUCnEBvKeohtqfxVsapFLNJdgrWDmM =RUCnEBvKeohtqfxVsapFLNJdgrWDmj['event_list'][1]['url']
    RUCnEBvKeohtqfxVsapFLNJdgrWDmc=urllib.parse.urlsplit(RUCnEBvKeohtqfxVsapFLNJdgrWDmM).query
    RUCnEBvKeohtqfxVsapFLNJdgrWDmI=RUCnEBvKeohtqfxVsapFLNJdgrWDmc[0:RUCnEBvKeohtqfxVsapFLNJdgrWDmc.find('=')]
    RUCnEBvKeohtqfxVsapFLNJdgrWDmw=RUCnEBvKeohtqfxVsapFLNJdgrWDmc[RUCnEBvKeohtqfxVsapFLNJdgrWDmc.find('=')+1:]
    RUCnEBvKeohtqfxVsapFLNJdgrWDmI='TVSHOW' if RUCnEBvKeohtqfxVsapFLNJdgrWDmI=='programid' else 'MOVIE' 
    RUCnEBvKeohtqfxVsapFLNJdgrWDmO=RUCnEBvKeohtqfxVsapFLNJdgrWDmj['title_list'][0]['text']
    RUCnEBvKeohtqfxVsapFLNJdgrWDmY =RUCnEBvKeohtqfxVsapFLNJdgrWDmj['age']
    RUCnEBvKeohtqfxVsapFLNJdgrWDym={'title':RUCnEBvKeohtqfxVsapFLNJdgrWDmO}
    if RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('age')!='21':
     RUCnEBvKeohtqfxVsapFLNJdgrWDmX.append(RUCnEBvKeohtqfxVsapFLNJdgrWDym)
   RUCnEBvKeohtqfxVsapFLNJdgrWDmQ=RUCnEBvKeohtqfxVsapFLNJdgrWDAw(RUCnEBvKeohtqfxVsapFLNJdgrWDmz['cell_toplist']['pagecount'])
   if RUCnEBvKeohtqfxVsapFLNJdgrWDmz['cell_toplist']['count']:RUCnEBvKeohtqfxVsapFLNJdgrWDyi =RUCnEBvKeohtqfxVsapFLNJdgrWDAw(RUCnEBvKeohtqfxVsapFLNJdgrWDmz['cell_toplist']['count'])
   else:RUCnEBvKeohtqfxVsapFLNJdgrWDyi=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.LIST_LIMIT
   RUCnEBvKeohtqfxVsapFLNJdgrWDmP=RUCnEBvKeohtqfxVsapFLNJdgrWDmQ>RUCnEBvKeohtqfxVsapFLNJdgrWDyi
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
  return RUCnEBvKeohtqfxVsapFLNJdgrWDmX,RUCnEBvKeohtqfxVsapFLNJdgrWDmP 
 def Get_Search_Tving(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,search_key,sType,page_int):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmX=[]
  RUCnEBvKeohtqfxVsapFLNJdgrWDmP=RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDyb ='/search/getSearch.jsp'
   RUCnEBvKeohtqfxVsapFLNJdgrWDyA={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':RUCnEBvKeohtqfxVsapFLNJdgrWDAI(page_int),'pageSize':RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.TVING_PARMAS.get('SCREENCODE'),'os':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.TVING_PARMAS.get('OSCODE'),'network':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.GetNoCache(2))}
   RUCnEBvKeohtqfxVsapFLNJdgrWDmH=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_TVING_SEARCH+RUCnEBvKeohtqfxVsapFLNJdgrWDyb
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.callRequestCookies('Get',RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,params=RUCnEBvKeohtqfxVsapFLNJdgrWDyA,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDAj)
   RUCnEBvKeohtqfxVsapFLNJdgrWDyG=json.loads(RUCnEBvKeohtqfxVsapFLNJdgrWDmT.text)
   if sType=='TVSHOW':
    if not('programRsb' in RUCnEBvKeohtqfxVsapFLNJdgrWDyG):return RUCnEBvKeohtqfxVsapFLNJdgrWDmX,RUCnEBvKeohtqfxVsapFLNJdgrWDmP
    RUCnEBvKeohtqfxVsapFLNJdgrWDyl=RUCnEBvKeohtqfxVsapFLNJdgrWDyG['programRsb']['dataList']
    RUCnEBvKeohtqfxVsapFLNJdgrWDyu =RUCnEBvKeohtqfxVsapFLNJdgrWDAw(RUCnEBvKeohtqfxVsapFLNJdgrWDyG['programRsb']['count'])
    for RUCnEBvKeohtqfxVsapFLNJdgrWDmj in RUCnEBvKeohtqfxVsapFLNJdgrWDyl:
     RUCnEBvKeohtqfxVsapFLNJdgrWDyX=RUCnEBvKeohtqfxVsapFLNJdgrWDmj['mast_cd']
     RUCnEBvKeohtqfxVsapFLNJdgrWDmO =RUCnEBvKeohtqfxVsapFLNJdgrWDmj['mast_nm']
     RUCnEBvKeohtqfxVsapFLNJdgrWDyQ=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_TVING_IMG+RUCnEBvKeohtqfxVsapFLNJdgrWDmj['web_url4']
     RUCnEBvKeohtqfxVsapFLNJdgrWDyP =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_TVING_IMG+RUCnEBvKeohtqfxVsapFLNJdgrWDmj['web_url']
     try:
      RUCnEBvKeohtqfxVsapFLNJdgrWDyH =[]
      RUCnEBvKeohtqfxVsapFLNJdgrWDyk=[]
      RUCnEBvKeohtqfxVsapFLNJdgrWDyT =[]
      RUCnEBvKeohtqfxVsapFLNJdgrWDyz =0
      RUCnEBvKeohtqfxVsapFLNJdgrWDyS =''
      RUCnEBvKeohtqfxVsapFLNJdgrWDyj =''
      RUCnEBvKeohtqfxVsapFLNJdgrWDyM =''
      if RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('actor') !='' and RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('actor') !='-':RUCnEBvKeohtqfxVsapFLNJdgrWDyH =RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('actor').split(',')
      if RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('director')!='' and RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('director')!='-':RUCnEBvKeohtqfxVsapFLNJdgrWDyk=RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('director').split(',')
      if RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('cate_nm')!='' and RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('cate_nm')!='-':RUCnEBvKeohtqfxVsapFLNJdgrWDyT =RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('cate_nm').split('/')
      if 'targetage' in RUCnEBvKeohtqfxVsapFLNJdgrWDmj:RUCnEBvKeohtqfxVsapFLNJdgrWDyS=RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('targetage')
      if 'broad_dt' in RUCnEBvKeohtqfxVsapFLNJdgrWDmj:
       RUCnEBvKeohtqfxVsapFLNJdgrWDyc=RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('broad_dt')
       RUCnEBvKeohtqfxVsapFLNJdgrWDyM='%s-%s-%s'%(RUCnEBvKeohtqfxVsapFLNJdgrWDyc[:4],RUCnEBvKeohtqfxVsapFLNJdgrWDyc[4:6],RUCnEBvKeohtqfxVsapFLNJdgrWDyc[6:])
       RUCnEBvKeohtqfxVsapFLNJdgrWDyj =RUCnEBvKeohtqfxVsapFLNJdgrWDyc[:4]
     except:
      RUCnEBvKeohtqfxVsapFLNJdgrWDAj
     RUCnEBvKeohtqfxVsapFLNJdgrWDym={'title':RUCnEBvKeohtqfxVsapFLNJdgrWDmO,}
     RUCnEBvKeohtqfxVsapFLNJdgrWDmX.append(RUCnEBvKeohtqfxVsapFLNJdgrWDym)
   else:
    if not('vodMVRsb' in RUCnEBvKeohtqfxVsapFLNJdgrWDyG):return RUCnEBvKeohtqfxVsapFLNJdgrWDmX,RUCnEBvKeohtqfxVsapFLNJdgrWDmP
    RUCnEBvKeohtqfxVsapFLNJdgrWDyI=RUCnEBvKeohtqfxVsapFLNJdgrWDyG['vodMVRsb']['dataList']
    RUCnEBvKeohtqfxVsapFLNJdgrWDyu =RUCnEBvKeohtqfxVsapFLNJdgrWDAw(RUCnEBvKeohtqfxVsapFLNJdgrWDyG['vodMVRsb']['count'])
    RUCnEBvKeohtqfxVsapFLNJdgrWDAc(RUCnEBvKeohtqfxVsapFLNJdgrWDyu)
    for RUCnEBvKeohtqfxVsapFLNJdgrWDmj in RUCnEBvKeohtqfxVsapFLNJdgrWDyI:
     RUCnEBvKeohtqfxVsapFLNJdgrWDyX=RUCnEBvKeohtqfxVsapFLNJdgrWDmj['mast_cd']
     RUCnEBvKeohtqfxVsapFLNJdgrWDmO =RUCnEBvKeohtqfxVsapFLNJdgrWDmj['mast_nm'].strip()
     RUCnEBvKeohtqfxVsapFLNJdgrWDyQ =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_TVING_IMG+RUCnEBvKeohtqfxVsapFLNJdgrWDmj['web_url']
     RUCnEBvKeohtqfxVsapFLNJdgrWDyP =RUCnEBvKeohtqfxVsapFLNJdgrWDyQ
     RUCnEBvKeohtqfxVsapFLNJdgrWDyw=''
     try:
      RUCnEBvKeohtqfxVsapFLNJdgrWDyH =[]
      RUCnEBvKeohtqfxVsapFLNJdgrWDyk=[]
      RUCnEBvKeohtqfxVsapFLNJdgrWDyT =[]
      RUCnEBvKeohtqfxVsapFLNJdgrWDyz =0
      RUCnEBvKeohtqfxVsapFLNJdgrWDyS =''
      RUCnEBvKeohtqfxVsapFLNJdgrWDyj =''
      RUCnEBvKeohtqfxVsapFLNJdgrWDyM =''
      if RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('actor') !='' and RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('actor') !='-':RUCnEBvKeohtqfxVsapFLNJdgrWDyH =RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('actor').split(',')
      if RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('director')!='' and RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('director')!='-':RUCnEBvKeohtqfxVsapFLNJdgrWDyk=RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('director').split(',')
      if RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('cate_nm')!='' and RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('cate_nm')!='-':RUCnEBvKeohtqfxVsapFLNJdgrWDyT =RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('cate_nm').split('/')
      if RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('runtime_sec')!='':RUCnEBvKeohtqfxVsapFLNJdgrWDyz=RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('runtime_sec')
      if 'grade_nm' in RUCnEBvKeohtqfxVsapFLNJdgrWDmj:RUCnEBvKeohtqfxVsapFLNJdgrWDyS=RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('grade_nm')
      RUCnEBvKeohtqfxVsapFLNJdgrWDyc=RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('broad_dt')
      if data_str!='':
       RUCnEBvKeohtqfxVsapFLNJdgrWDyM='%s-%s-%s'%(RUCnEBvKeohtqfxVsapFLNJdgrWDyc[:4],RUCnEBvKeohtqfxVsapFLNJdgrWDyc[4:6],RUCnEBvKeohtqfxVsapFLNJdgrWDyc[6:])
       RUCnEBvKeohtqfxVsapFLNJdgrWDyj =RUCnEBvKeohtqfxVsapFLNJdgrWDyc[:4]
     except:
      RUCnEBvKeohtqfxVsapFLNJdgrWDAj
     RUCnEBvKeohtqfxVsapFLNJdgrWDym={'title':RUCnEBvKeohtqfxVsapFLNJdgrWDmO,}
     RUCnEBvKeohtqfxVsapFLNJdgrWDyO=RUCnEBvKeohtqfxVsapFLNJdgrWDAM
     for RUCnEBvKeohtqfxVsapFLNJdgrWDyY in RUCnEBvKeohtqfxVsapFLNJdgrWDmj['bill']:
      if RUCnEBvKeohtqfxVsapFLNJdgrWDyY in RUCnEBvKeohtqfxVsapFLNJdgrWDmi.TVING_MOVIE_LITE:
       RUCnEBvKeohtqfxVsapFLNJdgrWDyO=RUCnEBvKeohtqfxVsapFLNJdgrWDAY
       break
     if RUCnEBvKeohtqfxVsapFLNJdgrWDyO==RUCnEBvKeohtqfxVsapFLNJdgrWDAM: 
      RUCnEBvKeohtqfxVsapFLNJdgrWDym['title']=RUCnEBvKeohtqfxVsapFLNJdgrWDym['title']+' [개별구매]'
     RUCnEBvKeohtqfxVsapFLNJdgrWDmX.append(RUCnEBvKeohtqfxVsapFLNJdgrWDym)
   if RUCnEBvKeohtqfxVsapFLNJdgrWDyu>(page_int*RUCnEBvKeohtqfxVsapFLNJdgrWDmi.TVING_LIMIT):RUCnEBvKeohtqfxVsapFLNJdgrWDmP=RUCnEBvKeohtqfxVsapFLNJdgrWDAY
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
  return RUCnEBvKeohtqfxVsapFLNJdgrWDmX,RUCnEBvKeohtqfxVsapFLNJdgrWDmP
 def Get_Search_Watcha(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,search_key,page_int):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmX=[]
  RUCnEBvKeohtqfxVsapFLNJdgrWDmP=RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmH=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_WATCHA+'/api/search.json'
   RUCnEBvKeohtqfxVsapFLNJdgrWDyA={'query':search_key,'page':RUCnEBvKeohtqfxVsapFLNJdgrWDAI(page_int),'per':RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.WATCHA_LIMIT),'exclude':'limited',}
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.callRequestCookies('Get',RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,params=RUCnEBvKeohtqfxVsapFLNJdgrWDyA,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.WATCHA_HEADER,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDAj)
   RUCnEBvKeohtqfxVsapFLNJdgrWDyG=json.loads(RUCnEBvKeohtqfxVsapFLNJdgrWDmT.text)
   if not('results' in RUCnEBvKeohtqfxVsapFLNJdgrWDyG):return RUCnEBvKeohtqfxVsapFLNJdgrWDmX,RUCnEBvKeohtqfxVsapFLNJdgrWDmP
   RUCnEBvKeohtqfxVsapFLNJdgrWDim=RUCnEBvKeohtqfxVsapFLNJdgrWDyG['results']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmP=RUCnEBvKeohtqfxVsapFLNJdgrWDyG['meta']['has_next']
   for RUCnEBvKeohtqfxVsapFLNJdgrWDmj in RUCnEBvKeohtqfxVsapFLNJdgrWDim:
    RUCnEBvKeohtqfxVsapFLNJdgrWDiy =RUCnEBvKeohtqfxVsapFLNJdgrWDmj['code']
    RUCnEBvKeohtqfxVsapFLNJdgrWDib=RUCnEBvKeohtqfxVsapFLNJdgrWDmj['content_type']
    RUCnEBvKeohtqfxVsapFLNJdgrWDiA =RUCnEBvKeohtqfxVsapFLNJdgrWDmj['title']
    RUCnEBvKeohtqfxVsapFLNJdgrWDiG =RUCnEBvKeohtqfxVsapFLNJdgrWDmj['story']
    RUCnEBvKeohtqfxVsapFLNJdgrWDyQ=RUCnEBvKeohtqfxVsapFLNJdgrWDyP=RUCnEBvKeohtqfxVsapFLNJdgrWDAH=''
    if RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('poster') !=RUCnEBvKeohtqfxVsapFLNJdgrWDAj:RUCnEBvKeohtqfxVsapFLNJdgrWDyQ=RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('poster').get('original')
    if RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('stillcut')!=RUCnEBvKeohtqfxVsapFLNJdgrWDAj:RUCnEBvKeohtqfxVsapFLNJdgrWDyP =RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('stillcut').get('large')
    if RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('thumbnail')!=RUCnEBvKeohtqfxVsapFLNJdgrWDAj:RUCnEBvKeohtqfxVsapFLNJdgrWDAH=RUCnEBvKeohtqfxVsapFLNJdgrWDmj.get('thumbnail').get('large')
    if RUCnEBvKeohtqfxVsapFLNJdgrWDAH=='' :RUCnEBvKeohtqfxVsapFLNJdgrWDAH=RUCnEBvKeohtqfxVsapFLNJdgrWDyP
    RUCnEBvKeohtqfxVsapFLNJdgrWDil={'thumb':RUCnEBvKeohtqfxVsapFLNJdgrWDyP,'poster':RUCnEBvKeohtqfxVsapFLNJdgrWDyQ,'fanart':RUCnEBvKeohtqfxVsapFLNJdgrWDAH}
    RUCnEBvKeohtqfxVsapFLNJdgrWDyj =RUCnEBvKeohtqfxVsapFLNJdgrWDmj['year']
    RUCnEBvKeohtqfxVsapFLNJdgrWDiu =RUCnEBvKeohtqfxVsapFLNJdgrWDmj['film_rating_code']
    RUCnEBvKeohtqfxVsapFLNJdgrWDiX=RUCnEBvKeohtqfxVsapFLNJdgrWDmj['film_rating_short']
    RUCnEBvKeohtqfxVsapFLNJdgrWDiQ =RUCnEBvKeohtqfxVsapFLNJdgrWDmj['film_rating_long']
    if RUCnEBvKeohtqfxVsapFLNJdgrWDib=='movies':
     RUCnEBvKeohtqfxVsapFLNJdgrWDyz =RUCnEBvKeohtqfxVsapFLNJdgrWDmj['duration']
    else:
     RUCnEBvKeohtqfxVsapFLNJdgrWDyz ='0'
    RUCnEBvKeohtqfxVsapFLNJdgrWDym={'title':RUCnEBvKeohtqfxVsapFLNJdgrWDiA,}
    RUCnEBvKeohtqfxVsapFLNJdgrWDmX.append(RUCnEBvKeohtqfxVsapFLNJdgrWDym)
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
  return RUCnEBvKeohtqfxVsapFLNJdgrWDmX,RUCnEBvKeohtqfxVsapFLNJdgrWDmP
 def dic_To_jsonfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,filename,dic):
  if filename=='':return
  fp=RUCnEBvKeohtqfxVsapFLNJdgrWDGm(filename,'w',-1,'utf-8')
  json.dump(dic,fp)
  fp.close()
 def jsonfile_To_dic(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,filename):
  if filename=='':return RUCnEBvKeohtqfxVsapFLNJdgrWDAj
  try:
   fp=RUCnEBvKeohtqfxVsapFLNJdgrWDGm(filename,'r',-1,'utf-8')
   RUCnEBvKeohtqfxVsapFLNJdgrWDiP=json.load(fp)
   fp.close()
  except:
   RUCnEBvKeohtqfxVsapFLNJdgrWDiP={}
  return RUCnEBvKeohtqfxVsapFLNJdgrWDiP
 def tempFileSave(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,filename,resText):
  if filename=='':return
  fp=RUCnEBvKeohtqfxVsapFLNJdgrWDGm(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,filename):
  if filename=='':return
  try:
   fp=RUCnEBvKeohtqfxVsapFLNJdgrWDGm(filename,'r',-1,'utf-8')
   RUCnEBvKeohtqfxVsapFLNJdgrWDiP=fp.read()
   fp.close()
  except:
   RUCnEBvKeohtqfxVsapFLNJdgrWDiP=''
  return RUCnEBvKeohtqfxVsapFLNJdgrWDiP
 def Init_NF_Total(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF={}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']={}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']={}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.Init_NF_Cookies()
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.Init_NF_Session()
 def Init_NF_Cookies(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['lhpuuidh'] ={'keyname':'','value':'','expires':0}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['lhpuuidhT'] ={'keyname':'','value':'','expires':0}
 def Check_NF_CookieExp(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  RUCnEBvKeohtqfxVsapFLNJdgrWDiH=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.GetNoCache(timetype=1,minutes=0)
  if RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['flwssn']['expires'] <=RUCnEBvKeohtqfxVsapFLNJdgrWDiH:RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  if RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['nfvdid']['expires'] <=RUCnEBvKeohtqfxVsapFLNJdgrWDiH:RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  if RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['SecureNetflixId']['expires']<=RUCnEBvKeohtqfxVsapFLNJdgrWDiH:RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  if RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['NetflixId']['expires'] <=RUCnEBvKeohtqfxVsapFLNJdgrWDiH:RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  if RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['memclid']['expires'] <=RUCnEBvKeohtqfxVsapFLNJdgrWDiH:RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  if RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['clSharedContext']['expires']<=RUCnEBvKeohtqfxVsapFLNJdgrWDiH:RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
 def Init_NF_Session(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['account'] ={'nfid':'','nfpw':'','nfpfnum':0}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['membershipStatus']='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['esnModel'] ='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['username'] ='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['authURL'] ='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['mainGuid'] ='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['nowGuid'] ='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['abContext'] ='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['identifier'] ='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['contryurl'] ='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['countryCode'] ='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['countryIsoCode'] ='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['loco'] ='' 
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['limitdate'] =''
 def make_NF_DefaultCookies(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  RUCnEBvKeohtqfxVsapFLNJdgrWDik={}
  if RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['flwssn']['value'] :RUCnEBvKeohtqfxVsapFLNJdgrWDik['flwssn'] =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['flwssn']['value']
  if RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['nfvdid']['value'] :RUCnEBvKeohtqfxVsapFLNJdgrWDik['nfvdid'] =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['nfvdid']['value']
  if RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['SecureNetflixId']['value']:RUCnEBvKeohtqfxVsapFLNJdgrWDik['SecureNetflixId']=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['SecureNetflixId']['value']
  if RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['NetflixId']['value'] :RUCnEBvKeohtqfxVsapFLNJdgrWDik['NetflixId'] =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['NetflixId']['value']
  if RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['memclid']['value'] :RUCnEBvKeohtqfxVsapFLNJdgrWDik['memclid'] =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['memclid']['value']
  return RUCnEBvKeohtqfxVsapFLNJdgrWDik
 def make_NF_XnetflixHeaders(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  RUCnEBvKeohtqfxVsapFLNJdgrWDiT={'x-netflix.browsername':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['esnModel'],'x-netflix.esnprefix':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['nowGuid'],'x-netflix.uiversion':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return RUCnEBvKeohtqfxVsapFLNJdgrWDiT
 def make_NF_ApiParams(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmk={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'false','persoInfoDensity':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['identifier']),}
  return RUCnEBvKeohtqfxVsapFLNJdgrWDmk
 def extract_json(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,content,name):
  RUCnEBvKeohtqfxVsapFLNJdgrWDiz=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  RUCnEBvKeohtqfxVsapFLNJdgrWDiS=RUCnEBvKeohtqfxVsapFLNJdgrWDAj
  RUCnEBvKeohtqfxVsapFLNJdgrWDij=re.compile(RUCnEBvKeohtqfxVsapFLNJdgrWDiz.format(name),re.DOTALL).findall(content)
  RUCnEBvKeohtqfxVsapFLNJdgrWDiS=RUCnEBvKeohtqfxVsapFLNJdgrWDij[0]
  RUCnEBvKeohtqfxVsapFLNJdgrWDiM=RUCnEBvKeohtqfxVsapFLNJdgrWDiS.replace('\\"','\\\\"') 
  RUCnEBvKeohtqfxVsapFLNJdgrWDiM=RUCnEBvKeohtqfxVsapFLNJdgrWDiM.replace('\\s','\\\\s') 
  RUCnEBvKeohtqfxVsapFLNJdgrWDiM=RUCnEBvKeohtqfxVsapFLNJdgrWDiM.replace('\\n','\\\\n') 
  RUCnEBvKeohtqfxVsapFLNJdgrWDiM=RUCnEBvKeohtqfxVsapFLNJdgrWDiM.replace('\\t','\\\\t') 
  RUCnEBvKeohtqfxVsapFLNJdgrWDiM=RUCnEBvKeohtqfxVsapFLNJdgrWDiM.encode().decode('unicode_escape') 
  RUCnEBvKeohtqfxVsapFLNJdgrWDiM=re.sub(r'\\(?!["])',r'\\\\',RUCnEBvKeohtqfxVsapFLNJdgrWDiM) 
  return json.loads(RUCnEBvKeohtqfxVsapFLNJdgrWDiM)
 def Save_session_acount(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,RUCnEBvKeohtqfxVsapFLNJdgrWDic,RUCnEBvKeohtqfxVsapFLNJdgrWDiI,RUCnEBvKeohtqfxVsapFLNJdgrWDiw):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['account']['nfid'] =base64.standard_b64encode(RUCnEBvKeohtqfxVsapFLNJdgrWDic.encode()).decode('utf-8')
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['account']['nfpw'] =base64.standard_b64encode(RUCnEBvKeohtqfxVsapFLNJdgrWDiI.encode()).decode('utf-8')
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['account']['nfpfnum']=RUCnEBvKeohtqfxVsapFLNJdgrWDiw
 def Load_session_acount(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  RUCnEBvKeohtqfxVsapFLNJdgrWDic =base64.standard_b64decode(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['account']['nfid']).decode('utf-8')
  RUCnEBvKeohtqfxVsapFLNJdgrWDiI =base64.standard_b64decode(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['account']['nfpw']).decode('utf-8')
  RUCnEBvKeohtqfxVsapFLNJdgrWDiw=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['account']['nfpfnum']
  return RUCnEBvKeohtqfxVsapFLNJdgrWDic,RUCnEBvKeohtqfxVsapFLNJdgrWDiI,RUCnEBvKeohtqfxVsapFLNJdgrWDiw
 def Get_NF_BaseCookies(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmH=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX+'/login' 
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.callRequestCookies_NF('Get',RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,params=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,addCookie='baseurl')
   if RUCnEBvKeohtqfxVsapFLNJdgrWDmT.status_code!=302:
    RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 1-1 status_code error')
    return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 1-1 error')
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmH=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX+'/'+RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['contryurl']+'/login' 
   RUCnEBvKeohtqfxVsapFLNJdgrWDik=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.make_NF_DefaultCookies()
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.callRequestCookies_NF('Get',RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,params=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDik)
   if RUCnEBvKeohtqfxVsapFLNJdgrWDmT.status_code!=200:
    RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 1-2 status_code error')
    return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
   RUCnEBvKeohtqfxVsapFLNJdgrWDiO=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.extract_json(RUCnEBvKeohtqfxVsapFLNJdgrWDmT.text,'reactContext')
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.dic_To_jsonfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_CONTEXTJSON_FILE1,RUCnEBvKeohtqfxVsapFLNJdgrWDiO)
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['membershipStatus']=RUCnEBvKeohtqfxVsapFLNJdgrWDiO['models']['userInfo']['data']['membershipStatus']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['authURL'] =RUCnEBvKeohtqfxVsapFLNJdgrWDiO['models']['userInfo']['data']['authURL']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['esnModel'] =RUCnEBvKeohtqfxVsapFLNJdgrWDiO['models']['esnGeneratorModel']['data']['esn']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['abContext'] =RUCnEBvKeohtqfxVsapFLNJdgrWDiO['models']['abContext']['data']['headers']
   RUCnEBvKeohtqfxVsapFLNJdgrWDiY=RUCnEBvKeohtqfxVsapFLNJdgrWDiO['models']['loginContext']['data']['geo']['requestCountry']['id']
   RUCnEBvKeohtqfxVsapFLNJdgrWDbm ='+82' 
   RUCnEBvKeohtqfxVsapFLNJdgrWDby =RUCnEBvKeohtqfxVsapFLNJdgrWDiO['models']['countryCodes']['data']['codes']
   for RUCnEBvKeohtqfxVsapFLNJdgrWDbi in RUCnEBvKeohtqfxVsapFLNJdgrWDby:
    if RUCnEBvKeohtqfxVsapFLNJdgrWDbi['id']==RUCnEBvKeohtqfxVsapFLNJdgrWDiY:
     RUCnEBvKeohtqfxVsapFLNJdgrWDbm='+'+RUCnEBvKeohtqfxVsapFLNJdgrWDbi['code']
     break
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['countryCode'] =RUCnEBvKeohtqfxVsapFLNJdgrWDbm 
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['countryIsoCode']=RUCnEBvKeohtqfxVsapFLNJdgrWDiY 
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.dic_To_jsonfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_COOKIES1,RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF)
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 1-2 error')
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  return RUCnEBvKeohtqfxVsapFLNJdgrWDAY
 def Get_NF_BaseLogin(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,user_id,user_pw,user_pfnum):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmi.Save_session_acount(user_id,user_pw,user_pfnum)
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmH=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX+'/'+RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['contryurl']+'/login' 
   RUCnEBvKeohtqfxVsapFLNJdgrWDbA={'userLoginId':user_id,'password':user_pw,'rememberMe':'true','flow':'websiteSignUp','mode':'login','action':'loginAction','withFields':'rememberMe,nextPage,userLoginId,password,countryCode,countryIsoCode','authURL':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['authURL'],'nextPage':'','showPassword':'','countryCode':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['countryCode'],'countryIsoCode':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['countryIsoCode'],}
   RUCnEBvKeohtqfxVsapFLNJdgrWDiT={'referer':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX+'/'+RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['contryurl']+'/login'}
   RUCnEBvKeohtqfxVsapFLNJdgrWDik=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.make_NF_DefaultCookies()
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.callRequestCookies_NF('Post',RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDbA,params=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDiT,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDik)
   if RUCnEBvKeohtqfxVsapFLNJdgrWDmT.status_code!=302:
    RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 2-1 status_code error')
    return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 2-1 error')
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmH=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX+'/'+RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['contryurl']+'/' 
   RUCnEBvKeohtqfxVsapFLNJdgrWDiT={'referer':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX+'/'+RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['contryurl']+'/login'}
   RUCnEBvKeohtqfxVsapFLNJdgrWDik=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.make_NF_DefaultCookies()
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.callRequestCookies_NF('Get',RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,params=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDiT,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDik)
   if RUCnEBvKeohtqfxVsapFLNJdgrWDmT.status_code!=302:
    RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 2-2 status_code error')
    return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 2-2 error')
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmH=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX+'/browse' 
   RUCnEBvKeohtqfxVsapFLNJdgrWDiT={'referer':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX+'/'+RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['contryurl']+'/login'}
   RUCnEBvKeohtqfxVsapFLNJdgrWDik=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.make_NF_DefaultCookies()
   RUCnEBvKeohtqfxVsapFLNJdgrWDik['clSharedContext']=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['clSharedContext']['value']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.callRequestCookies_NF('Get',RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,params=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDiT,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDik)
   if RUCnEBvKeohtqfxVsapFLNJdgrWDmT.status_code!=200:
    RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 2-3 status_code error')
    return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
   RUCnEBvKeohtqfxVsapFLNJdgrWDbG=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.extract_json(RUCnEBvKeohtqfxVsapFLNJdgrWDmT.text,'reactContext')
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.dic_To_jsonfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_CONTEXTJSON_FILE2,RUCnEBvKeohtqfxVsapFLNJdgrWDbG)
   RUCnEBvKeohtqfxVsapFLNJdgrWDbl=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.extract_json(RUCnEBvKeohtqfxVsapFLNJdgrWDmT.text,'falcorCache')
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.dic_To_jsonfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_FALCORJSON_FILE2,RUCnEBvKeohtqfxVsapFLNJdgrWDbl)
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 2-3 error')
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  RUCnEBvKeohtqfxVsapFLNJdgrWDbu=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.Get_NF_LoginData(RUCnEBvKeohtqfxVsapFLNJdgrWDbG,RUCnEBvKeohtqfxVsapFLNJdgrWDbl,user_pfnum)
  if RUCnEBvKeohtqfxVsapFLNJdgrWDbu==RUCnEBvKeohtqfxVsapFLNJdgrWDAM:
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAM 
  return RUCnEBvKeohtqfxVsapFLNJdgrWDAY
 def Get_NF_LoginData(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,RUCnEBvKeohtqfxVsapFLNJdgrWDbG,RUCnEBvKeohtqfxVsapFLNJdgrWDbl,user_pfnum):
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['membershipStatus']=RUCnEBvKeohtqfxVsapFLNJdgrWDbG['models']['userInfo']['data']['membershipStatus']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['username'] =RUCnEBvKeohtqfxVsapFLNJdgrWDbG['models']['userInfo']['data']['name']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['authURL'] =RUCnEBvKeohtqfxVsapFLNJdgrWDbG['models']['userInfo']['data']['authURL'] 
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['mainGuid'] =RUCnEBvKeohtqfxVsapFLNJdgrWDbG['models']['userInfo']['data']['guid'] 
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['nowGuid'] =RUCnEBvKeohtqfxVsapFLNJdgrWDbG['models']['userInfo']['data']['userGuid']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['esnModel'] =RUCnEBvKeohtqfxVsapFLNJdgrWDbG['models']['esnGeneratorModel']['data']['esn']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['abContext'] =RUCnEBvKeohtqfxVsapFLNJdgrWDbG['models']['abContext']['data']['headers']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['identifier'] =RUCnEBvKeohtqfxVsapFLNJdgrWDbG['models']['serverDefs']['data']['BUILD_IDENTIFIER']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['nowGuid'] =RUCnEBvKeohtqfxVsapFLNJdgrWDbl['profilesList'][RUCnEBvKeohtqfxVsapFLNJdgrWDAI(user_pfnum)]['value'][1]
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.dic_To_jsonfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_COOKIES2,RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF)
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 2-3-sub error')
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  return RUCnEBvKeohtqfxVsapFLNJdgrWDAY
 def Get_NF_ActivateProfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmH='%s/api/shakti/%s/profiles/switch'%(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX,RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['identifier'])
   RUCnEBvKeohtqfxVsapFLNJdgrWDmk={'switchProfileGuid':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['nowGuid'],'authURL':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['authURL'],'_':RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.GetNoCache(timetype=2,minutes=0)),}
   RUCnEBvKeohtqfxVsapFLNJdgrWDiT={'referer':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX+'/browse','accept':'*/*','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
   RUCnEBvKeohtqfxVsapFLNJdgrWDbX=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.make_NF_XnetflixHeaders()
   RUCnEBvKeohtqfxVsapFLNJdgrWDbX['x-netflix.request.client.user.guid']=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['mainGuid']
   RUCnEBvKeohtqfxVsapFLNJdgrWDiT.update(RUCnEBvKeohtqfxVsapFLNJdgrWDbX)
   RUCnEBvKeohtqfxVsapFLNJdgrWDik=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.make_NF_DefaultCookies()
   RUCnEBvKeohtqfxVsapFLNJdgrWDik['clSharedContext']=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['clSharedContext']['value']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.callRequestCookies_NF('Get',RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,params=RUCnEBvKeohtqfxVsapFLNJdgrWDmk,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDiT,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDik)
   if RUCnEBvKeohtqfxVsapFLNJdgrWDmT.status_code!=200:
    RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 3 status_code error')
    return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.dic_To_jsonfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_COOKIES2,RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF)
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 3 error')
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  return RUCnEBvKeohtqfxVsapFLNJdgrWDAY
 def Get_NF_BrowseMain(RUCnEBvKeohtqfxVsapFLNJdgrWDmi):
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmH=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX+'/browse' 
   RUCnEBvKeohtqfxVsapFLNJdgrWDiT={'referer':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX+'/browse','sec-fetch-dest':'document','sec-fetch-mode':'navigate','sec-fetch-site':'same-origin','sec-fetch-user':'?1',}
   RUCnEBvKeohtqfxVsapFLNJdgrWDik=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.make_NF_DefaultCookies()
   RUCnEBvKeohtqfxVsapFLNJdgrWDik['clSharedContext']=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['clSharedContext']['value']
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.callRequestCookies_NF('Get',RUCnEBvKeohtqfxVsapFLNJdgrWDmH,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,params=RUCnEBvKeohtqfxVsapFLNJdgrWDAj,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDiT,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDik,addCookie='lhpuuidh')
   if RUCnEBvKeohtqfxVsapFLNJdgrWDmT.status_code!=200:
    RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 4-main status_code error')
    return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
   RUCnEBvKeohtqfxVsapFLNJdgrWDbG=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.extract_json(RUCnEBvKeohtqfxVsapFLNJdgrWDmT.text,'reactContext')
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.dic_To_jsonfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_CONTEXTJSON_FILE3,RUCnEBvKeohtqfxVsapFLNJdgrWDbG)
   RUCnEBvKeohtqfxVsapFLNJdgrWDbl=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.extract_json(RUCnEBvKeohtqfxVsapFLNJdgrWDmT.text,'falcorCache')
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.dic_To_jsonfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_FALCORJSON_FILE3,RUCnEBvKeohtqfxVsapFLNJdgrWDbl)
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 4-main error')
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  RUCnEBvKeohtqfxVsapFLNJdgrWDbu=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.Get_NF_BrowseSub(RUCnEBvKeohtqfxVsapFLNJdgrWDbG,RUCnEBvKeohtqfxVsapFLNJdgrWDbl)
  if RUCnEBvKeohtqfxVsapFLNJdgrWDbu==RUCnEBvKeohtqfxVsapFLNJdgrWDAM:
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAM 
  return RUCnEBvKeohtqfxVsapFLNJdgrWDAY
 def Get_NF_BrowseSub(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,RUCnEBvKeohtqfxVsapFLNJdgrWDbG,RUCnEBvKeohtqfxVsapFLNJdgrWDbl):
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDbQ =RUCnEBvKeohtqfxVsapFLNJdgrWDbl['loco']['value'][1]
   RUCnEBvKeohtqfxVsapFLNJdgrWDbP=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.GetNoCache(timetype=2,minutes=180)
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['loco'] =RUCnEBvKeohtqfxVsapFLNJdgrWDbQ
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['lhpuuidh']={'keyname':'lhpuuidh-browse-%s'%(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['nowGuid']),'value':'%s%s'%('KR%3AKO-KR%3A',RUCnEBvKeohtqfxVsapFLNJdgrWDbQ),'expires':RUCnEBvKeohtqfxVsapFLNJdgrWDAw(RUCnEBvKeohtqfxVsapFLNJdgrWDbP/1000)}
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['lhpuuidhT']={'keyname':'lhpuuidh-browse-%s-T'%(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['nowGuid']),'value':RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDbP),'expires':RUCnEBvKeohtqfxVsapFLNJdgrWDAw(RUCnEBvKeohtqfxVsapFLNJdgrWDbP/1000)}
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.dic_To_jsonfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_SESSION_COOKIES3,RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF)
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc('pass 4-sub error')
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  return RUCnEBvKeohtqfxVsapFLNJdgrWDAY
 def NF_makestr_paths(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,paths):
  RUCnEBvKeohtqfxVsapFLNJdgrWDiP=[]
  if RUCnEBvKeohtqfxVsapFLNJdgrWDGy(paths,RUCnEBvKeohtqfxVsapFLNJdgrWDAw):
   return '%d'%(paths)
  elif RUCnEBvKeohtqfxVsapFLNJdgrWDGy(paths,RUCnEBvKeohtqfxVsapFLNJdgrWDAI):
   return '"%s"'%(paths)
  for RUCnEBvKeohtqfxVsapFLNJdgrWDbH in paths:
   if RUCnEBvKeohtqfxVsapFLNJdgrWDGy(RUCnEBvKeohtqfxVsapFLNJdgrWDbH,RUCnEBvKeohtqfxVsapFLNJdgrWDAw):
    RUCnEBvKeohtqfxVsapFLNJdgrWDiP.append('%d'%(RUCnEBvKeohtqfxVsapFLNJdgrWDbH))
   elif RUCnEBvKeohtqfxVsapFLNJdgrWDGy(RUCnEBvKeohtqfxVsapFLNJdgrWDbH,RUCnEBvKeohtqfxVsapFLNJdgrWDAI):
    RUCnEBvKeohtqfxVsapFLNJdgrWDiP.append('"%s"'%(RUCnEBvKeohtqfxVsapFLNJdgrWDbH))
   elif RUCnEBvKeohtqfxVsapFLNJdgrWDGy(RUCnEBvKeohtqfxVsapFLNJdgrWDbH,RUCnEBvKeohtqfxVsapFLNJdgrWDGi):
    RUCnEBvKeohtqfxVsapFLNJdgrWDiP.append('[%s]'%(','.join(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_makestr_paths(RUCnEBvKeohtqfxVsapFLNJdgrWDbH))))
   elif RUCnEBvKeohtqfxVsapFLNJdgrWDGy(RUCnEBvKeohtqfxVsapFLNJdgrWDbH,RUCnEBvKeohtqfxVsapFLNJdgrWDGb):
    RUCnEBvKeohtqfxVsapFLNJdgrWDbk=''
    for RUCnEBvKeohtqfxVsapFLNJdgrWDbT,RUCnEBvKeohtqfxVsapFLNJdgrWDbz in RUCnEBvKeohtqfxVsapFLNJdgrWDbH.items():
     RUCnEBvKeohtqfxVsapFLNJdgrWDbk+='"%s":%s,'%(RUCnEBvKeohtqfxVsapFLNJdgrWDbT,RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_makestr_paths(RUCnEBvKeohtqfxVsapFLNJdgrWDbz))
    RUCnEBvKeohtqfxVsapFLNJdgrWDiP.append('{%s}'%(RUCnEBvKeohtqfxVsapFLNJdgrWDbk[:-1]))
  return RUCnEBvKeohtqfxVsapFLNJdgrWDiP
 def NF_Call_pathapi(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,RUCnEBvKeohtqfxVsapFLNJdgrWDAm,referer=''):
  RUCnEBvKeohtqfxVsapFLNJdgrWDbS='%s/nq/website/memberapi/%s/pathEvaluator'%(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX,RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['identifier'])
  RUCnEBvKeohtqfxVsapFLNJdgrWDbA={'path':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_makestr_paths(RUCnEBvKeohtqfxVsapFLNJdgrWDAm),'authURL':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['SESSION']['authURL']}
  RUCnEBvKeohtqfxVsapFLNJdgrWDmk=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.make_NF_ApiParams()
  RUCnEBvKeohtqfxVsapFLNJdgrWDiT={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':RUCnEBvKeohtqfxVsapFLNJdgrWDiT['referer']=referer
  RUCnEBvKeohtqfxVsapFLNJdgrWDbX=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.make_NF_XnetflixHeaders()
  RUCnEBvKeohtqfxVsapFLNJdgrWDiT.update(RUCnEBvKeohtqfxVsapFLNJdgrWDbX)
  RUCnEBvKeohtqfxVsapFLNJdgrWDik=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.make_NF_DefaultCookies()
  RUCnEBvKeohtqfxVsapFLNJdgrWDik[RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['lhpuuidh']['keyname']]=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['lhpuuidh']['value']
  RUCnEBvKeohtqfxVsapFLNJdgrWDik[RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['lhpuuidhT']['keyname']]=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF['COOKIES']['lhpuuidhT']['value']
  RUCnEBvKeohtqfxVsapFLNJdgrWDik['profilesNewSession']='0'
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.callRequestCookies('Post',RUCnEBvKeohtqfxVsapFLNJdgrWDbS,payload=RUCnEBvKeohtqfxVsapFLNJdgrWDbA,params=RUCnEBvKeohtqfxVsapFLNJdgrWDmk,headers=RUCnEBvKeohtqfxVsapFLNJdgrWDiT,cookies=RUCnEBvKeohtqfxVsapFLNJdgrWDik)
   return RUCnEBvKeohtqfxVsapFLNJdgrWDmT
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
   return RUCnEBvKeohtqfxVsapFLNJdgrWDAj
 def Get_Search_Netflix(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,search_key,page_int,byReference=''):
  RUCnEBvKeohtqfxVsapFLNJdgrWDbj=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.DERECTOR_LIMIT
  RUCnEBvKeohtqfxVsapFLNJdgrWDbM =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.CAST_LIMIT
  RUCnEBvKeohtqfxVsapFLNJdgrWDbc =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.GENRE_LIMIT
  RUCnEBvKeohtqfxVsapFLNJdgrWDbI =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_LIMIT*(page_int-1)
  RUCnEBvKeohtqfxVsapFLNJdgrWDbw =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_LIMIT*page_int 
  RUCnEBvKeohtqfxVsapFLNJdgrWDbO="|%s"%(search_key)
  RUCnEBvKeohtqfxVsapFLNJdgrWDbY ='%s/search?%s'%(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAm=[["search","byTerm",RUCnEBvKeohtqfxVsapFLNJdgrWDbO,"titles",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_LIMIT,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"summary"],["search","byTerm",RUCnEBvKeohtqfxVsapFLNJdgrWDbO,"titles",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_LIMIT,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",RUCnEBvKeohtqfxVsapFLNJdgrWDbO,"titles",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_LIMIT,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference","boxarts",[RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND2,RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_PORT],"jpg"],["search","byTerm",RUCnEBvKeohtqfxVsapFLNJdgrWDbO,"titles",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_LIMIT,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference","interestingMoment",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND1,"jpg"],["search","byTerm",RUCnEBvKeohtqfxVsapFLNJdgrWDbO,"titles",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_LIMIT,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference","storyArt",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND2,"jpg"],["search","byTerm",RUCnEBvKeohtqfxVsapFLNJdgrWDbO,"titles",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_LIMIT,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference",["cast","creators","directors"],{"from":0,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbj},["id","name"]],["search","byTerm",RUCnEBvKeohtqfxVsapFLNJdgrWDbO,"titles",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_LIMIT,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference","genres",{"from":0,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbc},["id","name"]],["search","byTerm",RUCnEBvKeohtqfxVsapFLNJdgrWDbO,"titles",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NETFLIX_LIMIT,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LOGO,"png"],]
  else:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAm=[["search","byReference",byReference,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"summary"],["search","byReference",byReference,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference","boxarts",[RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND2,RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference","interestingMoment",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference","storyArt",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference",["cast","creators","directors"],{"from":0,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbj},["id","name"]],["search","byReference",byReference,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference","genres",{"from":0,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbc},["id","name"]],["search","byReference",byReference,{"from":RUCnEBvKeohtqfxVsapFLNJdgrWDbI,"to":RUCnEBvKeohtqfxVsapFLNJdgrWDbw},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LOGO,"png"],]
  try:
   RUCnEBvKeohtqfxVsapFLNJdgrWDmT=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_Call_pathapi(RUCnEBvKeohtqfxVsapFLNJdgrWDAm,RUCnEBvKeohtqfxVsapFLNJdgrWDbY)
   RUCnEBvKeohtqfxVsapFLNJdgrWDmz=json.loads(RUCnEBvKeohtqfxVsapFLNJdgrWDmT.text)
   RUCnEBvKeohtqfxVsapFLNJdgrWDmi.dic_To_jsonfile(RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_CONTEXTJSON_FILE4,RUCnEBvKeohtqfxVsapFLNJdgrWDmz)
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
  (RUCnEBvKeohtqfxVsapFLNJdgrWDmX,RUCnEBvKeohtqfxVsapFLNJdgrWDmP,byReference)=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.Search_Netflix_Make(RUCnEBvKeohtqfxVsapFLNJdgrWDmz)
  return RUCnEBvKeohtqfxVsapFLNJdgrWDmX,RUCnEBvKeohtqfxVsapFLNJdgrWDmP,byReference
 def Search_Netflix_Make(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,jsonSource):
  RUCnEBvKeohtqfxVsapFLNJdgrWDmX=[]
  RUCnEBvKeohtqfxVsapFLNJdgrWDmP =RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  RUCnEBvKeohtqfxVsapFLNJdgrWDAy=''
  RUCnEBvKeohtqfxVsapFLNJdgrWDAi=jsonSource.get('paths')[0][1]
  if RUCnEBvKeohtqfxVsapFLNJdgrWDAi=='byTerm':
   RUCnEBvKeohtqfxVsapFLNJdgrWDbI =jsonSource['paths'][0][5]['from']
   RUCnEBvKeohtqfxVsapFLNJdgrWDbw =jsonSource['paths'][0][5]['to']
  else:
   RUCnEBvKeohtqfxVsapFLNJdgrWDbI =jsonSource['paths'][0][3]['from']
   RUCnEBvKeohtqfxVsapFLNJdgrWDbw =jsonSource['paths'][0][3]['to']
  RUCnEBvKeohtqfxVsapFLNJdgrWDAy=RUCnEBvKeohtqfxVsapFLNJdgrWDGi(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  RUCnEBvKeohtqfxVsapFLNJdgrWDAb=jsonSource.get('jsonGraph').get('search').get('byReference').get(RUCnEBvKeohtqfxVsapFLNJdgrWDAy)
  RUCnEBvKeohtqfxVsapFLNJdgrWDAG =jsonSource.get('jsonGraph').get('videos')
  RUCnEBvKeohtqfxVsapFLNJdgrWDAl=jsonSource.get('jsonGraph').get('person')
  RUCnEBvKeohtqfxVsapFLNJdgrWDAu=jsonSource.get('jsonGraph').get('genres')
  RUCnEBvKeohtqfxVsapFLNJdgrWDmP=RUCnEBvKeohtqfxVsapFLNJdgrWDAY if RUCnEBvKeohtqfxVsapFLNJdgrWDAb[RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDbw)]['reference']['$type']=='ref' else RUCnEBvKeohtqfxVsapFLNJdgrWDAM
  for RUCnEBvKeohtqfxVsapFLNJdgrWDAX in RUCnEBvKeohtqfxVsapFLNJdgrWDGA(RUCnEBvKeohtqfxVsapFLNJdgrWDbI,RUCnEBvKeohtqfxVsapFLNJdgrWDbw):
   if RUCnEBvKeohtqfxVsapFLNJdgrWDAb[RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDAX)]['reference']['$type']=='ref':
    RUCnEBvKeohtqfxVsapFLNJdgrWDmw =RUCnEBvKeohtqfxVsapFLNJdgrWDAb[RUCnEBvKeohtqfxVsapFLNJdgrWDAI(RUCnEBvKeohtqfxVsapFLNJdgrWDAX)]['reference']['value'][1]
    RUCnEBvKeohtqfxVsapFLNJdgrWDAQ=RUCnEBvKeohtqfxVsapFLNJdgrWDAG[RUCnEBvKeohtqfxVsapFLNJdgrWDmw]
    RUCnEBvKeohtqfxVsapFLNJdgrWDiA =RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['title']['value']
    if RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['availability']['value']['isPlayable']==RUCnEBvKeohtqfxVsapFLNJdgrWDAM:
     continue
    RUCnEBvKeohtqfxVsapFLNJdgrWDmI =RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['summary']['value']['type']
    RUCnEBvKeohtqfxVsapFLNJdgrWDyz =0 if RUCnEBvKeohtqfxVsapFLNJdgrWDmI!='movie' else RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['runtime']['value']
    if RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['sequiturEvidence']['value']['value']:
     RUCnEBvKeohtqfxVsapFLNJdgrWDAP=RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['sequiturEvidence']['value']['value']['text']
    else:
     RUCnEBvKeohtqfxVsapFLNJdgrWDAP=''
    RUCnEBvKeohtqfxVsapFLNJdgrWDyQ =RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['boxarts'][RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_PORT]['jpg']['value']['url']
    RUCnEBvKeohtqfxVsapFLNJdgrWDAH =RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['boxarts'][RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND2]['jpg']['value']['url']
    RUCnEBvKeohtqfxVsapFLNJdgrWDyP=''
    if 'value' in RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['storyArt'][RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND2]['jpg']:
     RUCnEBvKeohtqfxVsapFLNJdgrWDyP =RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['storyArt'][RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND2]['jpg']['value']['url']
    if RUCnEBvKeohtqfxVsapFLNJdgrWDyP=='' and 'value' in RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['interestingMoment'][RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND1]['jpg']:
     RUCnEBvKeohtqfxVsapFLNJdgrWDyP =RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['interestingMoment'][RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LAND1]['jpg']['value']['url']
    RUCnEBvKeohtqfxVsapFLNJdgrWDyw=RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][RUCnEBvKeohtqfxVsapFLNJdgrWDmi.ART_SIZE_LOGO]['png']['value']['url']
    RUCnEBvKeohtqfxVsapFLNJdgrWDyT =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_Subid_List(RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['genres'])
    for i in RUCnEBvKeohtqfxVsapFLNJdgrWDGA(RUCnEBvKeohtqfxVsapFLNJdgrWDGl(RUCnEBvKeohtqfxVsapFLNJdgrWDyT)):
     RUCnEBvKeohtqfxVsapFLNJdgrWDyT[i]=RUCnEBvKeohtqfxVsapFLNJdgrWDAu[RUCnEBvKeohtqfxVsapFLNJdgrWDyT[i]]['name']['value']
    RUCnEBvKeohtqfxVsapFLNJdgrWDyk=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_Subid_List(RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['directors'])
    RUCnEBvKeohtqfxVsapFLNJdgrWDAk =RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_Subid_List(RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['creators'])
    RUCnEBvKeohtqfxVsapFLNJdgrWDyk.extend(RUCnEBvKeohtqfxVsapFLNJdgrWDAk)
    for i in RUCnEBvKeohtqfxVsapFLNJdgrWDGA(RUCnEBvKeohtqfxVsapFLNJdgrWDGl(RUCnEBvKeohtqfxVsapFLNJdgrWDyk)):
     RUCnEBvKeohtqfxVsapFLNJdgrWDyk[i]=RUCnEBvKeohtqfxVsapFLNJdgrWDAl[RUCnEBvKeohtqfxVsapFLNJdgrWDyk[i]]['name']['value']
    RUCnEBvKeohtqfxVsapFLNJdgrWDyH=RUCnEBvKeohtqfxVsapFLNJdgrWDmi.NF_Subid_List(RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['cast'])
    for i in RUCnEBvKeohtqfxVsapFLNJdgrWDGA(RUCnEBvKeohtqfxVsapFLNJdgrWDGl(RUCnEBvKeohtqfxVsapFLNJdgrWDyH)):
     RUCnEBvKeohtqfxVsapFLNJdgrWDyH[i]=RUCnEBvKeohtqfxVsapFLNJdgrWDAl[RUCnEBvKeohtqfxVsapFLNJdgrWDyH[i]]['name']['value']
    if 'maturityDescription' in RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['maturity']['value']['rating']:
     RUCnEBvKeohtqfxVsapFLNJdgrWDyS=RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['maturity']['value']['rating']['maturityDescription']
    RUCnEBvKeohtqfxVsapFLNJdgrWDym={'videoid':RUCnEBvKeohtqfxVsapFLNJdgrWDmw,'vidtype':RUCnEBvKeohtqfxVsapFLNJdgrWDmI,'title':RUCnEBvKeohtqfxVsapFLNJdgrWDiA,'mpaa':RUCnEBvKeohtqfxVsapFLNJdgrWDyS,'regularSynopsis':RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['regularSynopsis']['value'],'dpSupplemental':RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['dpSupplementalMessage']['value'],'sequiturEvidence':RUCnEBvKeohtqfxVsapFLNJdgrWDAP,'thumbnail':{'poster':RUCnEBvKeohtqfxVsapFLNJdgrWDyQ,'thumb':RUCnEBvKeohtqfxVsapFLNJdgrWDyP,'fanart':RUCnEBvKeohtqfxVsapFLNJdgrWDAH,'clearlogo':RUCnEBvKeohtqfxVsapFLNJdgrWDyw},'year':RUCnEBvKeohtqfxVsapFLNJdgrWDAQ['releaseYear']['value'],'duration':RUCnEBvKeohtqfxVsapFLNJdgrWDyz,'info_genre':RUCnEBvKeohtqfxVsapFLNJdgrWDyT,'director':RUCnEBvKeohtqfxVsapFLNJdgrWDyk,'cast':RUCnEBvKeohtqfxVsapFLNJdgrWDyH,}
    RUCnEBvKeohtqfxVsapFLNJdgrWDmX.append(RUCnEBvKeohtqfxVsapFLNJdgrWDym)
  return RUCnEBvKeohtqfxVsapFLNJdgrWDmX,RUCnEBvKeohtqfxVsapFLNJdgrWDmP,RUCnEBvKeohtqfxVsapFLNJdgrWDAy
 def NF_Subid_List(RUCnEBvKeohtqfxVsapFLNJdgrWDmi,subJson):
  RUCnEBvKeohtqfxVsapFLNJdgrWDAT=[]
  try:
   for i in RUCnEBvKeohtqfxVsapFLNJdgrWDGA(RUCnEBvKeohtqfxVsapFLNJdgrWDGl(subJson)):
    if subJson.get(RUCnEBvKeohtqfxVsapFLNJdgrWDAI(i)).get('$type')!='ref':break
    RUCnEBvKeohtqfxVsapFLNJdgrWDAz=subJson.get(RUCnEBvKeohtqfxVsapFLNJdgrWDAI(i)).get('value')[1]
    RUCnEBvKeohtqfxVsapFLNJdgrWDAT.append(RUCnEBvKeohtqfxVsapFLNJdgrWDAz)
  except RUCnEBvKeohtqfxVsapFLNJdgrWDAO as exception:
   RUCnEBvKeohtqfxVsapFLNJdgrWDAc(exception)
  return RUCnEBvKeohtqfxVsapFLNJdgrWDAT
# Created by pyminifier (https://github.com/liftoff/pyminifier)
