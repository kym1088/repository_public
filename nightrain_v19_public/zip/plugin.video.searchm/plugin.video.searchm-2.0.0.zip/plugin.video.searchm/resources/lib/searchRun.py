__author__="NightRain"
nYAbFVCusmfcoOpleNKavXJShRdrDk=object
nYAbFVCusmfcoOpleNKavXJShRdrDQ=None
nYAbFVCusmfcoOpleNKavXJShRdrDM=True
nYAbFVCusmfcoOpleNKavXJShRdrDg=False
nYAbFVCusmfcoOpleNKavXJShRdrDx=type
nYAbFVCusmfcoOpleNKavXJShRdrDw=dict
nYAbFVCusmfcoOpleNKavXJShRdrDz=open
nYAbFVCusmfcoOpleNKavXJShRdrDT=len
nYAbFVCusmfcoOpleNKavXJShRdrDy=Exception
nYAbFVCusmfcoOpleNKavXJShRdrDL=str
nYAbFVCusmfcoOpleNKavXJShRdrDE=int
nYAbFVCusmfcoOpleNKavXJShRdrDG=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
nYAbFVCusmfcoOpleNKavXJShRdrWP=[{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
nYAbFVCusmfcoOpleNKavXJShRdrWI={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},}
nYAbFVCusmfcoOpleNKavXJShRdrWD=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
nYAbFVCusmfcoOpleNKavXJShRdrWq =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class nYAbFVCusmfcoOpleNKavXJShRdrWB(nYAbFVCusmfcoOpleNKavXJShRdrDk):
 def __init__(nYAbFVCusmfcoOpleNKavXJShRdrWH,nYAbFVCusmfcoOpleNKavXJShRdrWU,nYAbFVCusmfcoOpleNKavXJShRdrWk,nYAbFVCusmfcoOpleNKavXJShRdrWQ):
  nYAbFVCusmfcoOpleNKavXJShRdrWH._addon_url =nYAbFVCusmfcoOpleNKavXJShRdrWU
  nYAbFVCusmfcoOpleNKavXJShRdrWH._addon_handle=nYAbFVCusmfcoOpleNKavXJShRdrWk
  nYAbFVCusmfcoOpleNKavXJShRdrWH.main_params =nYAbFVCusmfcoOpleNKavXJShRdrWQ
  nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj =RUCnEBvKeohtqfxVsapFLNJdgrWDmy() 
 def addon_noti(nYAbFVCusmfcoOpleNKavXJShRdrWH,sting):
  try:
   nYAbFVCusmfcoOpleNKavXJShRdrWg=xbmcgui.Dialog()
   nYAbFVCusmfcoOpleNKavXJShRdrWg.notification(__addonname__,sting)
  except:
   nYAbFVCusmfcoOpleNKavXJShRdrDQ
 def addon_log(nYAbFVCusmfcoOpleNKavXJShRdrWH,string):
  try:
   nYAbFVCusmfcoOpleNKavXJShRdrWx=string.encode('utf-8','ignore')
  except:
   nYAbFVCusmfcoOpleNKavXJShRdrWx='addonException: addon_log'
  nYAbFVCusmfcoOpleNKavXJShRdrWw=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,nYAbFVCusmfcoOpleNKavXJShRdrWx),level=nYAbFVCusmfcoOpleNKavXJShRdrWw)
 def get_keyboard_input(nYAbFVCusmfcoOpleNKavXJShRdrWH,nYAbFVCusmfcoOpleNKavXJShRdrWj):
  nYAbFVCusmfcoOpleNKavXJShRdrWz=nYAbFVCusmfcoOpleNKavXJShRdrDQ
  kb=xbmc.Keyboard()
  kb.setHeading(nYAbFVCusmfcoOpleNKavXJShRdrWj)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   nYAbFVCusmfcoOpleNKavXJShRdrWz=kb.getText()
  return nYAbFVCusmfcoOpleNKavXJShRdrWz
 def get_settings_select_info(nYAbFVCusmfcoOpleNKavXJShRdrWH):
  nYAbFVCusmfcoOpleNKavXJShRdrWT=[]
  if __addon__.getSetting('netflixyn')=='true':nYAbFVCusmfcoOpleNKavXJShRdrWT.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':nYAbFVCusmfcoOpleNKavXJShRdrWT.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':nYAbFVCusmfcoOpleNKavXJShRdrWT.append('tving')
  if __addon__.getSetting('watchayn')=='true':nYAbFVCusmfcoOpleNKavXJShRdrWT.append('watcha')
  return nYAbFVCusmfcoOpleNKavXJShRdrWT
 def get_settings_netflix(nYAbFVCusmfcoOpleNKavXJShRdrWH):
  nYAbFVCusmfcoOpleNKavXJShRdrWy =__addon__.getSetting('nfid')
  nYAbFVCusmfcoOpleNKavXJShRdrWL =__addon__.getSetting('nfpw')
  nYAbFVCusmfcoOpleNKavXJShRdrWE=__addon__.getSetting('nf_profile')
  return(nYAbFVCusmfcoOpleNKavXJShRdrWy,nYAbFVCusmfcoOpleNKavXJShRdrWL,nYAbFVCusmfcoOpleNKavXJShRdrWE)
 def add_dir(nYAbFVCusmfcoOpleNKavXJShRdrWH,label,sublabel='',img='',infoLabels=nYAbFVCusmfcoOpleNKavXJShRdrDQ,isFolder=nYAbFVCusmfcoOpleNKavXJShRdrDM,params='',isLink=nYAbFVCusmfcoOpleNKavXJShRdrDg,ContextMenu=nYAbFVCusmfcoOpleNKavXJShRdrDQ):
  nYAbFVCusmfcoOpleNKavXJShRdrWG='%s?%s'%(nYAbFVCusmfcoOpleNKavXJShRdrWH._addon_url,urllib.parse.urlencode(params))
  if sublabel:nYAbFVCusmfcoOpleNKavXJShRdrWj='%s < %s >'%(label,sublabel)
  else: nYAbFVCusmfcoOpleNKavXJShRdrWj=label
  if not img:img='DefaultFolder.png'
  nYAbFVCusmfcoOpleNKavXJShRdrWt=xbmcgui.ListItem(nYAbFVCusmfcoOpleNKavXJShRdrWj)
  if nYAbFVCusmfcoOpleNKavXJShRdrDx(img)==nYAbFVCusmfcoOpleNKavXJShRdrDw:
   nYAbFVCusmfcoOpleNKavXJShRdrWt.setArt(img)
  else:
   nYAbFVCusmfcoOpleNKavXJShRdrWt.setArt({'thumb':img,'poster':img})
  if infoLabels:nYAbFVCusmfcoOpleNKavXJShRdrWt.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   nYAbFVCusmfcoOpleNKavXJShRdrWt.setProperty('IsPlayable','true')
  if ContextMenu:nYAbFVCusmfcoOpleNKavXJShRdrWt.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(nYAbFVCusmfcoOpleNKavXJShRdrWH._addon_handle,nYAbFVCusmfcoOpleNKavXJShRdrWG,nYAbFVCusmfcoOpleNKavXJShRdrWt,isFolder)
 def Load_Searched_List(nYAbFVCusmfcoOpleNKavXJShRdrWH):
  try:
   nYAbFVCusmfcoOpleNKavXJShRdrWi=nYAbFVCusmfcoOpleNKavXJShRdrWq
   fp=nYAbFVCusmfcoOpleNKavXJShRdrDz(nYAbFVCusmfcoOpleNKavXJShRdrWi,'r',-1,'utf-8')
   nYAbFVCusmfcoOpleNKavXJShRdrBW=fp.readlines()
   fp.close()
  except:
   nYAbFVCusmfcoOpleNKavXJShRdrBW=[]
  return nYAbFVCusmfcoOpleNKavXJShRdrBW
 def Save_Searched_List(nYAbFVCusmfcoOpleNKavXJShRdrWH,nYAbFVCusmfcoOpleNKavXJShRdrPi):
  try:
   nYAbFVCusmfcoOpleNKavXJShRdrWi=nYAbFVCusmfcoOpleNKavXJShRdrWq
   nYAbFVCusmfcoOpleNKavXJShRdrBP=nYAbFVCusmfcoOpleNKavXJShRdrWH.Load_Searched_List() 
   nYAbFVCusmfcoOpleNKavXJShRdrBI={'skey':nYAbFVCusmfcoOpleNKavXJShRdrPi.strip()}
   fp=nYAbFVCusmfcoOpleNKavXJShRdrDz(nYAbFVCusmfcoOpleNKavXJShRdrWi,'w',-1,'utf-8')
   nYAbFVCusmfcoOpleNKavXJShRdrBD=urllib.parse.urlencode(nYAbFVCusmfcoOpleNKavXJShRdrBI)
   nYAbFVCusmfcoOpleNKavXJShRdrBD=nYAbFVCusmfcoOpleNKavXJShRdrBD+'\n'
   fp.write(nYAbFVCusmfcoOpleNKavXJShRdrBD)
   nYAbFVCusmfcoOpleNKavXJShRdrBq=0
   for nYAbFVCusmfcoOpleNKavXJShRdrBH in nYAbFVCusmfcoOpleNKavXJShRdrBP:
    nYAbFVCusmfcoOpleNKavXJShRdrBU=nYAbFVCusmfcoOpleNKavXJShRdrDw(urllib.parse.parse_qsl(nYAbFVCusmfcoOpleNKavXJShRdrBH))
    nYAbFVCusmfcoOpleNKavXJShRdrBk=nYAbFVCusmfcoOpleNKavXJShRdrBI.get('skey').strip()
    nYAbFVCusmfcoOpleNKavXJShRdrBQ=nYAbFVCusmfcoOpleNKavXJShRdrBU.get('skey').strip()
    if nYAbFVCusmfcoOpleNKavXJShRdrBk!=nYAbFVCusmfcoOpleNKavXJShRdrBQ:
     fp.write(nYAbFVCusmfcoOpleNKavXJShRdrBH)
     nYAbFVCusmfcoOpleNKavXJShRdrBq+=1
     if nYAbFVCusmfcoOpleNKavXJShRdrBq>=50:break
   fp.close()
  except:
   nYAbFVCusmfcoOpleNKavXJShRdrDQ
 def dp_Search_History(nYAbFVCusmfcoOpleNKavXJShRdrWH):
  nYAbFVCusmfcoOpleNKavXJShRdrBM=nYAbFVCusmfcoOpleNKavXJShRdrWH.Load_Searched_List()
  for nYAbFVCusmfcoOpleNKavXJShRdrBg in nYAbFVCusmfcoOpleNKavXJShRdrBM:
   nYAbFVCusmfcoOpleNKavXJShRdrBx=nYAbFVCusmfcoOpleNKavXJShRdrDw(urllib.parse.parse_qsl(nYAbFVCusmfcoOpleNKavXJShRdrBg))
   nYAbFVCusmfcoOpleNKavXJShRdrBw=nYAbFVCusmfcoOpleNKavXJShRdrBx.get('skey').strip()
   nYAbFVCusmfcoOpleNKavXJShRdrBz={'mode':'TOTAL_SEARCH','search_key':nYAbFVCusmfcoOpleNKavXJShRdrBw,}
   nYAbFVCusmfcoOpleNKavXJShRdrBT={'mode':'HISTORY_REMOVE','skey':nYAbFVCusmfcoOpleNKavXJShRdrBw,'delmode':'ONE',}
   nYAbFVCusmfcoOpleNKavXJShRdrBy=urllib.parse.urlencode(nYAbFVCusmfcoOpleNKavXJShRdrBT)
   nYAbFVCusmfcoOpleNKavXJShRdrBL=[('선택된 검색어 ( %s ) 삭제'%(nYAbFVCusmfcoOpleNKavXJShRdrBw),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(nYAbFVCusmfcoOpleNKavXJShRdrBy))]
   nYAbFVCusmfcoOpleNKavXJShRdrWH.add_dir(nYAbFVCusmfcoOpleNKavXJShRdrBw,sublabel='',img=nYAbFVCusmfcoOpleNKavXJShRdrDQ,infoLabels=nYAbFVCusmfcoOpleNKavXJShRdrDQ,isFolder=nYAbFVCusmfcoOpleNKavXJShRdrDM,params=nYAbFVCusmfcoOpleNKavXJShRdrBz,ContextMenu=nYAbFVCusmfcoOpleNKavXJShRdrBL)
  nYAbFVCusmfcoOpleNKavXJShRdrBG={'plot':'검색목록 전체를 삭제합니다.'}
  nYAbFVCusmfcoOpleNKavXJShRdrWj='*** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) ***'
  nYAbFVCusmfcoOpleNKavXJShRdrBz={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  nYAbFVCusmfcoOpleNKavXJShRdrBj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  nYAbFVCusmfcoOpleNKavXJShRdrWH.add_dir(nYAbFVCusmfcoOpleNKavXJShRdrWj,sublabel='',img=nYAbFVCusmfcoOpleNKavXJShRdrBj,infoLabels=nYAbFVCusmfcoOpleNKavXJShRdrBG,isFolder=nYAbFVCusmfcoOpleNKavXJShRdrDg,params=nYAbFVCusmfcoOpleNKavXJShRdrBz,isLink=nYAbFVCusmfcoOpleNKavXJShRdrDM)
  xbmcplugin.endOfDirectory(nYAbFVCusmfcoOpleNKavXJShRdrWH._addon_handle,cacheToDisc=nYAbFVCusmfcoOpleNKavXJShRdrDg)
 def Delete_History_List(nYAbFVCusmfcoOpleNKavXJShRdrWH,nYAbFVCusmfcoOpleNKavXJShRdrBw,nYAbFVCusmfcoOpleNKavXJShRdrPW):
  if nYAbFVCusmfcoOpleNKavXJShRdrPW=='ALL':
   try:
    nYAbFVCusmfcoOpleNKavXJShRdrWi=nYAbFVCusmfcoOpleNKavXJShRdrWq
    fp=nYAbFVCusmfcoOpleNKavXJShRdrDz(nYAbFVCusmfcoOpleNKavXJShRdrWi,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    nYAbFVCusmfcoOpleNKavXJShRdrDQ
  else:
   try:
    nYAbFVCusmfcoOpleNKavXJShRdrWi=nYAbFVCusmfcoOpleNKavXJShRdrWq
    nYAbFVCusmfcoOpleNKavXJShRdrBP=nYAbFVCusmfcoOpleNKavXJShRdrWH.Load_Searched_List() 
    fp=nYAbFVCusmfcoOpleNKavXJShRdrDz(nYAbFVCusmfcoOpleNKavXJShRdrWi,'w',-1,'utf-8')
    for nYAbFVCusmfcoOpleNKavXJShRdrBH in nYAbFVCusmfcoOpleNKavXJShRdrBP:
     nYAbFVCusmfcoOpleNKavXJShRdrBU=nYAbFVCusmfcoOpleNKavXJShRdrDw(urllib.parse.parse_qsl(nYAbFVCusmfcoOpleNKavXJShRdrBH))
     nYAbFVCusmfcoOpleNKavXJShRdrBi=nYAbFVCusmfcoOpleNKavXJShRdrBU.get('skey').strip()
     if nYAbFVCusmfcoOpleNKavXJShRdrBw!=nYAbFVCusmfcoOpleNKavXJShRdrBi:
      fp.write(nYAbFVCusmfcoOpleNKavXJShRdrBH)
    fp.close()
   except:
    nYAbFVCusmfcoOpleNKavXJShRdrDQ
 def dp_History_Delete(nYAbFVCusmfcoOpleNKavXJShRdrWH,args):
  nYAbFVCusmfcoOpleNKavXJShRdrBw =args.get('skey') 
  nYAbFVCusmfcoOpleNKavXJShRdrPW=args.get('delmode')
  nYAbFVCusmfcoOpleNKavXJShRdrWg=xbmcgui.Dialog()
  if nYAbFVCusmfcoOpleNKavXJShRdrPW=='ALL':
   nYAbFVCusmfcoOpleNKavXJShRdrPB=nYAbFVCusmfcoOpleNKavXJShRdrWg.yesno(__language__(30913).encode('utf8'),__language__(30915).encode('utf8'))
  else:
   nYAbFVCusmfcoOpleNKavXJShRdrPB=nYAbFVCusmfcoOpleNKavXJShRdrWg.yesno(__language__(30914).encode('utf8'),__language__(30915).encode('utf8'))
  if nYAbFVCusmfcoOpleNKavXJShRdrPB==nYAbFVCusmfcoOpleNKavXJShRdrDg:sys.exit()
  nYAbFVCusmfcoOpleNKavXJShRdrWH.Delete_History_List(nYAbFVCusmfcoOpleNKavXJShRdrBw,nYAbFVCusmfcoOpleNKavXJShRdrPW)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(nYAbFVCusmfcoOpleNKavXJShRdrWH):
  for nYAbFVCusmfcoOpleNKavXJShRdrPI in nYAbFVCusmfcoOpleNKavXJShRdrWP:
   nYAbFVCusmfcoOpleNKavXJShRdrWj=nYAbFVCusmfcoOpleNKavXJShRdrPI.get('title')
   nYAbFVCusmfcoOpleNKavXJShRdrBj=''
   nYAbFVCusmfcoOpleNKavXJShRdrBz={'mode':nYAbFVCusmfcoOpleNKavXJShRdrPI.get('mode')}
   if nYAbFVCusmfcoOpleNKavXJShRdrPI.get('mode')=='XXX':
    nYAbFVCusmfcoOpleNKavXJShRdrBz['mode']='XXX'
    nYAbFVCusmfcoOpleNKavXJShRdrPD=nYAbFVCusmfcoOpleNKavXJShRdrDg
    nYAbFVCusmfcoOpleNKavXJShRdrPq =nYAbFVCusmfcoOpleNKavXJShRdrDM
   else:
    if 'icon' in nYAbFVCusmfcoOpleNKavXJShRdrPI:
     nYAbFVCusmfcoOpleNKavXJShRdrBj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',nYAbFVCusmfcoOpleNKavXJShRdrPI.get('icon')) 
    nYAbFVCusmfcoOpleNKavXJShRdrPD=nYAbFVCusmfcoOpleNKavXJShRdrDM
    nYAbFVCusmfcoOpleNKavXJShRdrPq =nYAbFVCusmfcoOpleNKavXJShRdrDg
   nYAbFVCusmfcoOpleNKavXJShRdrWH.add_dir(nYAbFVCusmfcoOpleNKavXJShRdrWj,sublabel='',img=nYAbFVCusmfcoOpleNKavXJShRdrBj,infoLabels=nYAbFVCusmfcoOpleNKavXJShRdrDQ,isFolder=nYAbFVCusmfcoOpleNKavXJShRdrPD,params=nYAbFVCusmfcoOpleNKavXJShRdrBz,isLink=nYAbFVCusmfcoOpleNKavXJShRdrPq)
  if nYAbFVCusmfcoOpleNKavXJShRdrDT(nYAbFVCusmfcoOpleNKavXJShRdrWP)>0:xbmcplugin.endOfDirectory(nYAbFVCusmfcoOpleNKavXJShRdrWH._addon_handle)
 def option_check(nYAbFVCusmfcoOpleNKavXJShRdrWH):
  nYAbFVCusmfcoOpleNKavXJShRdrWT=nYAbFVCusmfcoOpleNKavXJShRdrWH.get_settings_select_info()
  if nYAbFVCusmfcoOpleNKavXJShRdrDT(nYAbFVCusmfcoOpleNKavXJShRdrWT)==0:
   nYAbFVCusmfcoOpleNKavXJShRdrWg=xbmcgui.Dialog()
   nYAbFVCusmfcoOpleNKavXJShRdrPB=nYAbFVCusmfcoOpleNKavXJShRdrWg.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if nYAbFVCusmfcoOpleNKavXJShRdrPB==nYAbFVCusmfcoOpleNKavXJShRdrDM:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in nYAbFVCusmfcoOpleNKavXJShRdrWT:
   (nYAbFVCusmfcoOpleNKavXJShRdrPH,nYAbFVCusmfcoOpleNKavXJShRdrPU,nYAbFVCusmfcoOpleNKavXJShRdrPk)=nYAbFVCusmfcoOpleNKavXJShRdrWH.get_settings_netflix()
   if nYAbFVCusmfcoOpleNKavXJShRdrPH=='' or nYAbFVCusmfcoOpleNKavXJShRdrPU=='':
    nYAbFVCusmfcoOpleNKavXJShRdrWg=xbmcgui.Dialog()
    nYAbFVCusmfcoOpleNKavXJShRdrPB=nYAbFVCusmfcoOpleNKavXJShRdrWg.yesno(__language__(30902).encode('utf8'),__language__(30903).encode('utf8'))
    if nYAbFVCusmfcoOpleNKavXJShRdrPB==nYAbFVCusmfcoOpleNKavXJShRdrDM:
     __addon__.openSettings()
     sys.exit()
    else:
     sys.exit()
   if nYAbFVCusmfcoOpleNKavXJShRdrWH.NF_cookiefile_check()==nYAbFVCusmfcoOpleNKavXJShRdrDg:
    nYAbFVCusmfcoOpleNKavXJShRdrWg=xbmcgui.Dialog()
    nYAbFVCusmfcoOpleNKavXJShRdrPB=nYAbFVCusmfcoOpleNKavXJShRdrWg.yesno(__language__(30907).encode('utf8'),__language__(30916).encode('utf8'))
    if nYAbFVCusmfcoOpleNKavXJShRdrPB==nYAbFVCusmfcoOpleNKavXJShRdrDM:
     if nYAbFVCusmfcoOpleNKavXJShRdrWH.NF_login(inputCheck=nYAbFVCusmfcoOpleNKavXJShRdrDg)==nYAbFVCusmfcoOpleNKavXJShRdrDg:
      sys.exit()
    else:
     sys.exit()
 def NF_cookiefile_check(nYAbFVCusmfcoOpleNKavXJShRdrWH):
  nYAbFVCusmfcoOpleNKavXJShRdrPQ={}
  try: 
   fp=nYAbFVCusmfcoOpleNKavXJShRdrDz(nYAbFVCusmfcoOpleNKavXJShRdrWD,'r',-1,'utf-8')
   nYAbFVCusmfcoOpleNKavXJShRdrPQ= json.load(fp)
   fp.close()
  except nYAbFVCusmfcoOpleNKavXJShRdrDy as exception:
   return nYAbFVCusmfcoOpleNKavXJShRdrDg
  nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.NF=nYAbFVCusmfcoOpleNKavXJShRdrPQ
  (nYAbFVCusmfcoOpleNKavXJShRdrPH,nYAbFVCusmfcoOpleNKavXJShRdrPU,nYAbFVCusmfcoOpleNKavXJShRdrPk)=nYAbFVCusmfcoOpleNKavXJShRdrWH.get_settings_netflix()
  (nYAbFVCusmfcoOpleNKavXJShRdrPM,nYAbFVCusmfcoOpleNKavXJShRdrPg,nYAbFVCusmfcoOpleNKavXJShRdrPx)=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Load_session_acount()
  if nYAbFVCusmfcoOpleNKavXJShRdrPH!=nYAbFVCusmfcoOpleNKavXJShRdrPM or nYAbFVCusmfcoOpleNKavXJShRdrPU!=nYAbFVCusmfcoOpleNKavXJShRdrPg or nYAbFVCusmfcoOpleNKavXJShRdrPk!=nYAbFVCusmfcoOpleNKavXJShRdrDL(nYAbFVCusmfcoOpleNKavXJShRdrPx):
   nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Init_NF_Total()
   return nYAbFVCusmfcoOpleNKavXJShRdrDg
  return nYAbFVCusmfcoOpleNKavXJShRdrDM
 def NF_login(nYAbFVCusmfcoOpleNKavXJShRdrWH,inputCheck=nYAbFVCusmfcoOpleNKavXJShRdrDM):
  (nYAbFVCusmfcoOpleNKavXJShRdrPw,nYAbFVCusmfcoOpleNKavXJShRdrPz,nYAbFVCusmfcoOpleNKavXJShRdrPT)=nYAbFVCusmfcoOpleNKavXJShRdrWH.get_settings_netflix()
  if inputCheck==nYAbFVCusmfcoOpleNKavXJShRdrDM:
   if nYAbFVCusmfcoOpleNKavXJShRdrPw=='' or nYAbFVCusmfcoOpleNKavXJShRdrPz=='':
    nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_noti(__language__(30902).encode('utf-8'))
    return nYAbFVCusmfcoOpleNKavXJShRdrDg
   nYAbFVCusmfcoOpleNKavXJShRdrWg=xbmcgui.Dialog()
   nYAbFVCusmfcoOpleNKavXJShRdrPB=nYAbFVCusmfcoOpleNKavXJShRdrWg.yesno(__language__(30911).encode('utf8'),__language__(30912).encode('utf8'))
   if nYAbFVCusmfcoOpleNKavXJShRdrPB==nYAbFVCusmfcoOpleNKavXJShRdrDg:
    return nYAbFVCusmfcoOpleNKavXJShRdrDg 
  nYAbFVCusmfcoOpleNKavXJShRdrPy=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_NF_BaseCookies()
  if nYAbFVCusmfcoOpleNKavXJShRdrPy:
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_log('pass1 ok!')
  else:
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_log('pass1 error!')
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_noti(__language__(30905).encode('utf-8'))
   return nYAbFVCusmfcoOpleNKavXJShRdrDg 
  nYAbFVCusmfcoOpleNKavXJShRdrPy=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_NF_BaseLogin(nYAbFVCusmfcoOpleNKavXJShRdrPw,nYAbFVCusmfcoOpleNKavXJShRdrPz,nYAbFVCusmfcoOpleNKavXJShRdrPT)
  if nYAbFVCusmfcoOpleNKavXJShRdrPy:
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_log('pass2 ok!')
  else:
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_log('pass2 error!')
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_noti(__language__(30905).encode('utf-8'))
   return nYAbFVCusmfcoOpleNKavXJShRdrDg 
  nYAbFVCusmfcoOpleNKavXJShRdrPy=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_NF_ActivateProfile()
  if nYAbFVCusmfcoOpleNKavXJShRdrPy:
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_log('pass3 ok!')
  else:
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_log('pass3 error!')
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_noti(__language__(30905).encode('utf-8'))
   return nYAbFVCusmfcoOpleNKavXJShRdrDg 
  nYAbFVCusmfcoOpleNKavXJShRdrPy=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_NF_BrowseMain()
  if nYAbFVCusmfcoOpleNKavXJShRdrPy:
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_log('pass4 ok!')
  else:
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_log('pass4 error!')
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_noti(__language__(30905).encode('utf-8'))
   return nYAbFVCusmfcoOpleNKavXJShRdrDg 
  nYAbFVCusmfcoOpleNKavXJShRdrPL =nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_Now_Datetime()
  nYAbFVCusmfcoOpleNKavXJShRdrPE=nYAbFVCusmfcoOpleNKavXJShRdrPL+datetime.timedelta(days=nYAbFVCusmfcoOpleNKavXJShRdrDE(__addon__.getSetting('cache_ttl')))
  nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.NF['SESSION']['limitdate']=nYAbFVCusmfcoOpleNKavXJShRdrPE.strftime('%Y-%m-%d')
  try: 
   fp=nYAbFVCusmfcoOpleNKavXJShRdrDz(nYAbFVCusmfcoOpleNKavXJShRdrWD,'w',-1,'utf-8')
   json.dump(nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.NF,fp)
   fp.close()
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_log('pass5 save ok!')
  except nYAbFVCusmfcoOpleNKavXJShRdrDy as exception:
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_log('pass5 save error!')
   nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_noti(__language__(30905).encode('utf-8'))
   return nYAbFVCusmfcoOpleNKavXJShRdrDg
  nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_noti(__language__(30904).encode('utf-8'))
  return nYAbFVCusmfcoOpleNKavXJShRdrDM
 def NF_logout(nYAbFVCusmfcoOpleNKavXJShRdrWH):
  nYAbFVCusmfcoOpleNKavXJShRdrWg=xbmcgui.Dialog()
  nYAbFVCusmfcoOpleNKavXJShRdrPB=nYAbFVCusmfcoOpleNKavXJShRdrWg.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if nYAbFVCusmfcoOpleNKavXJShRdrPB==nYAbFVCusmfcoOpleNKavXJShRdrDg:return 
  if os.path.isfile(nYAbFVCusmfcoOpleNKavXJShRdrWD):os.remove(nYAbFVCusmfcoOpleNKavXJShRdrWD)
  nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(nYAbFVCusmfcoOpleNKavXJShRdrWH,nYAbFVCusmfcoOpleNKavXJShRdrIW):
  nYAbFVCusmfcoOpleNKavXJShRdrPG=''
  nYAbFVCusmfcoOpleNKavXJShRdrPj=7
  try:
   for i in nYAbFVCusmfcoOpleNKavXJShRdrDG(nYAbFVCusmfcoOpleNKavXJShRdrDT(nYAbFVCusmfcoOpleNKavXJShRdrIW)):
    if i>=nYAbFVCusmfcoOpleNKavXJShRdrPj:
     nYAbFVCusmfcoOpleNKavXJShRdrPG=nYAbFVCusmfcoOpleNKavXJShRdrPG+'...'
     break
    nYAbFVCusmfcoOpleNKavXJShRdrPG=nYAbFVCusmfcoOpleNKavXJShRdrPG+nYAbFVCusmfcoOpleNKavXJShRdrIW[i]['title']+'\n'
  except:
   return ''
  return nYAbFVCusmfcoOpleNKavXJShRdrPG
 def dp_Search_Group(nYAbFVCusmfcoOpleNKavXJShRdrWH,args):
  nYAbFVCusmfcoOpleNKavXJShRdrWT =nYAbFVCusmfcoOpleNKavXJShRdrWH.get_settings_select_info()
  nYAbFVCusmfcoOpleNKavXJShRdrPt=[]
  if 'search_key' in args:
   nYAbFVCusmfcoOpleNKavXJShRdrPi=args.get('search_key')
  else:
   nYAbFVCusmfcoOpleNKavXJShRdrPi=nYAbFVCusmfcoOpleNKavXJShRdrWH.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not nYAbFVCusmfcoOpleNKavXJShRdrPi:
    xbmcplugin.endOfDirectory(nYAbFVCusmfcoOpleNKavXJShRdrWH._addon_handle)
    return
  if 'wavve' in nYAbFVCusmfcoOpleNKavXJShRdrWT:
   (nYAbFVCusmfcoOpleNKavXJShRdrIW,nYAbFVCusmfcoOpleNKavXJShRdrIB)=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_Search_Wavve(nYAbFVCusmfcoOpleNKavXJShRdrPi,'TVSHOW',1)
   if nYAbFVCusmfcoOpleNKavXJShRdrDT(nYAbFVCusmfcoOpleNKavXJShRdrIW)>0:
    nYAbFVCusmfcoOpleNKavXJShRdrIP={'sType':'wavve_tvshow','sList':nYAbFVCusmfcoOpleNKavXJShRdrWH.MakeText_FreeList(nYAbFVCusmfcoOpleNKavXJShRdrIW),}
    nYAbFVCusmfcoOpleNKavXJShRdrPt.append(nYAbFVCusmfcoOpleNKavXJShRdrIP)
   (nYAbFVCusmfcoOpleNKavXJShRdrIW,nYAbFVCusmfcoOpleNKavXJShRdrIB)=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_Search_Wavve(nYAbFVCusmfcoOpleNKavXJShRdrPi,'MOVIE',1)
   if nYAbFVCusmfcoOpleNKavXJShRdrDT(nYAbFVCusmfcoOpleNKavXJShRdrIW)>0:
    nYAbFVCusmfcoOpleNKavXJShRdrIP={'sType':'wavve_movie','sList':nYAbFVCusmfcoOpleNKavXJShRdrWH.MakeText_FreeList(nYAbFVCusmfcoOpleNKavXJShRdrIW),}
    nYAbFVCusmfcoOpleNKavXJShRdrPt.append(nYAbFVCusmfcoOpleNKavXJShRdrIP)
  if 'tving' in nYAbFVCusmfcoOpleNKavXJShRdrWT:
   (nYAbFVCusmfcoOpleNKavXJShRdrIW,nYAbFVCusmfcoOpleNKavXJShRdrIB)=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_Search_Tving(nYAbFVCusmfcoOpleNKavXJShRdrPi,'TVSHOW',1)
   if nYAbFVCusmfcoOpleNKavXJShRdrDT(nYAbFVCusmfcoOpleNKavXJShRdrIW)>0:
    nYAbFVCusmfcoOpleNKavXJShRdrIP={'sType':'tving_tvshow','sList':nYAbFVCusmfcoOpleNKavXJShRdrWH.MakeText_FreeList(nYAbFVCusmfcoOpleNKavXJShRdrIW),}
    nYAbFVCusmfcoOpleNKavXJShRdrPt.append(nYAbFVCusmfcoOpleNKavXJShRdrIP)
   (nYAbFVCusmfcoOpleNKavXJShRdrIW,nYAbFVCusmfcoOpleNKavXJShRdrIB)=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_Search_Tving(nYAbFVCusmfcoOpleNKavXJShRdrPi,'MOVIE',1)
   if nYAbFVCusmfcoOpleNKavXJShRdrDT(nYAbFVCusmfcoOpleNKavXJShRdrIW)>0:
    nYAbFVCusmfcoOpleNKavXJShRdrIP={'sType':'tving_movie','sList':nYAbFVCusmfcoOpleNKavXJShRdrWH.MakeText_FreeList(nYAbFVCusmfcoOpleNKavXJShRdrIW),}
    nYAbFVCusmfcoOpleNKavXJShRdrPt.append(nYAbFVCusmfcoOpleNKavXJShRdrIP)
  if 'watcha' in nYAbFVCusmfcoOpleNKavXJShRdrWT:
   (nYAbFVCusmfcoOpleNKavXJShRdrIW,nYAbFVCusmfcoOpleNKavXJShRdrIB)=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_Search_Watcha(nYAbFVCusmfcoOpleNKavXJShRdrPi,1)
   if nYAbFVCusmfcoOpleNKavXJShRdrDT(nYAbFVCusmfcoOpleNKavXJShRdrIW)>0:
    nYAbFVCusmfcoOpleNKavXJShRdrIP={'sType':'watcha_list','sList':nYAbFVCusmfcoOpleNKavXJShRdrWH.MakeText_FreeList(nYAbFVCusmfcoOpleNKavXJShRdrIW),}
    nYAbFVCusmfcoOpleNKavXJShRdrPt.append(nYAbFVCusmfcoOpleNKavXJShRdrIP)
  if 'netflix' in nYAbFVCusmfcoOpleNKavXJShRdrWT:
   (nYAbFVCusmfcoOpleNKavXJShRdrIW,nYAbFVCusmfcoOpleNKavXJShRdrIB,nYAbFVCusmfcoOpleNKavXJShRdrID)=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_Search_Netflix(nYAbFVCusmfcoOpleNKavXJShRdrPi,1)
   if nYAbFVCusmfcoOpleNKavXJShRdrDT(nYAbFVCusmfcoOpleNKavXJShRdrIW)>0:
    nYAbFVCusmfcoOpleNKavXJShRdrIP={'sType':'netflix_list','sList':nYAbFVCusmfcoOpleNKavXJShRdrWH.MakeText_FreeList(nYAbFVCusmfcoOpleNKavXJShRdrIW),}
    nYAbFVCusmfcoOpleNKavXJShRdrPt.append(nYAbFVCusmfcoOpleNKavXJShRdrIP)
  for nYAbFVCusmfcoOpleNKavXJShRdrIq in nYAbFVCusmfcoOpleNKavXJShRdrPt:
   nYAbFVCusmfcoOpleNKavXJShRdrIH=nYAbFVCusmfcoOpleNKavXJShRdrWI[nYAbFVCusmfcoOpleNKavXJShRdrIq.get('sType')]
   nYAbFVCusmfcoOpleNKavXJShRdrIU={'plot':'검색어 : '+nYAbFVCusmfcoOpleNKavXJShRdrPi+'\n\n'+nYAbFVCusmfcoOpleNKavXJShRdrIq.get('sList')}
   nYAbFVCusmfcoOpleNKavXJShRdrWj=nYAbFVCusmfcoOpleNKavXJShRdrIH.get('title')
   nYAbFVCusmfcoOpleNKavXJShRdrBz={'mode':nYAbFVCusmfcoOpleNKavXJShRdrIH.get('mode'),'ott':nYAbFVCusmfcoOpleNKavXJShRdrIH.get('ott'),'vidtype':nYAbFVCusmfcoOpleNKavXJShRdrIH.get('vidtype'),'search_key':nYAbFVCusmfcoOpleNKavXJShRdrPi}
   if nYAbFVCusmfcoOpleNKavXJShRdrIH.get('ott')=='netflix':
    nYAbFVCusmfcoOpleNKavXJShRdrBz['page'] ='1'
    nYAbFVCusmfcoOpleNKavXJShRdrBz['byReference']='-'
   nYAbFVCusmfcoOpleNKavXJShRdrBj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',nYAbFVCusmfcoOpleNKavXJShRdrIH.get('icon'))
   nYAbFVCusmfcoOpleNKavXJShRdrPD=nYAbFVCusmfcoOpleNKavXJShRdrDM if nYAbFVCusmfcoOpleNKavXJShRdrIH.get('mode')!='HYPER_LINK' else nYAbFVCusmfcoOpleNKavXJShRdrDg
   nYAbFVCusmfcoOpleNKavXJShRdrWH.add_dir(nYAbFVCusmfcoOpleNKavXJShRdrWj,sublabel='',img=nYAbFVCusmfcoOpleNKavXJShRdrBj,infoLabels=nYAbFVCusmfcoOpleNKavXJShRdrIU,isFolder=nYAbFVCusmfcoOpleNKavXJShRdrPD,params=nYAbFVCusmfcoOpleNKavXJShRdrBz,isLink=nYAbFVCusmfcoOpleNKavXJShRdrDM)
  xbmcplugin.endOfDirectory(nYAbFVCusmfcoOpleNKavXJShRdrWH._addon_handle)
  nYAbFVCusmfcoOpleNKavXJShRdrWH.Save_Searched_List(nYAbFVCusmfcoOpleNKavXJShRdrPi)
 def dp_Hyper_Link(nYAbFVCusmfcoOpleNKavXJShRdrWH,args):
  nYAbFVCusmfcoOpleNKavXJShRdrIk =args.get('mode')
  nYAbFVCusmfcoOpleNKavXJShRdrIQ =args.get('ott')
  nYAbFVCusmfcoOpleNKavXJShRdrIM =args.get('vidtype')
  nYAbFVCusmfcoOpleNKavXJShRdrPi=args.get('search_key')
  nYAbFVCusmfcoOpleNKavXJShRdrIg='-'
  if nYAbFVCusmfcoOpleNKavXJShRdrIQ=='wavve':
   nYAbFVCusmfcoOpleNKavXJShRdrIx={'mode':'LOCAL_SEARCH','sType':'movie' if nYAbFVCusmfcoOpleNKavXJShRdrIM=='MOVIE' else 'vod','search_key':nYAbFVCusmfcoOpleNKavXJShRdrPi,'page':'1',}
   nYAbFVCusmfcoOpleNKavXJShRdrIw=urllib.parse.urlencode(nYAbFVCusmfcoOpleNKavXJShRdrIx)
   nYAbFVCusmfcoOpleNKavXJShRdrIg='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(nYAbFVCusmfcoOpleNKavXJShRdrIw)
  elif nYAbFVCusmfcoOpleNKavXJShRdrIQ=='tving':
   nYAbFVCusmfcoOpleNKavXJShRdrIx={'mode':'LOCAL_SEARCH','stype':'movie' if nYAbFVCusmfcoOpleNKavXJShRdrIM=='MOVIE' else 'vod','search_key':nYAbFVCusmfcoOpleNKavXJShRdrPi,'page':'1',}
   nYAbFVCusmfcoOpleNKavXJShRdrIw=urllib.parse.urlencode(nYAbFVCusmfcoOpleNKavXJShRdrIx)
   nYAbFVCusmfcoOpleNKavXJShRdrIg='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(nYAbFVCusmfcoOpleNKavXJShRdrIw)
  elif nYAbFVCusmfcoOpleNKavXJShRdrIQ=='watcha':
   nYAbFVCusmfcoOpleNKavXJShRdrIx={'mode':'LOCAL_SEARCH','search_key':nYAbFVCusmfcoOpleNKavXJShRdrPi,'page':'1',}
   nYAbFVCusmfcoOpleNKavXJShRdrIw=urllib.parse.urlencode(nYAbFVCusmfcoOpleNKavXJShRdrIx)
   nYAbFVCusmfcoOpleNKavXJShRdrIg='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(nYAbFVCusmfcoOpleNKavXJShRdrIw)
  elif nYAbFVCusmfcoOpleNKavXJShRdrIQ=='netflix':
   nYAbFVCusmfcoOpleNKavXJShRdrIz=args.get('videoid')
   nYAbFVCusmfcoOpleNKavXJShRdrIT=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.NF['SESSION']['nowGuid']
   if nYAbFVCusmfcoOpleNKavXJShRdrIM=='TVSHOW':
    nYAbFVCusmfcoOpleNKavXJShRdrIg='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(nYAbFVCusmfcoOpleNKavXJShRdrIz)
   else:
    nYAbFVCusmfcoOpleNKavXJShRdrIg='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(nYAbFVCusmfcoOpleNKavXJShRdrIz,nYAbFVCusmfcoOpleNKavXJShRdrIT)
  nYAbFVCusmfcoOpleNKavXJShRdrWH.addon_log('ott_url ==> ( '+nYAbFVCusmfcoOpleNKavXJShRdrIg+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(nYAbFVCusmfcoOpleNKavXJShRdrIg)
 def dp_Nf_Search(nYAbFVCusmfcoOpleNKavXJShRdrWH,args):
  nYAbFVCusmfcoOpleNKavXJShRdrIy =nYAbFVCusmfcoOpleNKavXJShRdrDE(args.get('page'))
  nYAbFVCusmfcoOpleNKavXJShRdrPi =args.get('search_key')
  nYAbFVCusmfcoOpleNKavXJShRdrID=args.get('byReference')
  (nYAbFVCusmfcoOpleNKavXJShRdrIW,nYAbFVCusmfcoOpleNKavXJShRdrIB,nYAbFVCusmfcoOpleNKavXJShRdrID)=nYAbFVCusmfcoOpleNKavXJShRdrWH.SearchObj.Get_Search_Netflix(nYAbFVCusmfcoOpleNKavXJShRdrPi,nYAbFVCusmfcoOpleNKavXJShRdrIy,byReference=nYAbFVCusmfcoOpleNKavXJShRdrID)
  for nYAbFVCusmfcoOpleNKavXJShRdrIL in nYAbFVCusmfcoOpleNKavXJShRdrIW:
   nYAbFVCusmfcoOpleNKavXJShRdrIz =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('videoid')
   nYAbFVCusmfcoOpleNKavXJShRdrIM =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('vidtype')
   nYAbFVCusmfcoOpleNKavXJShRdrWj =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('title')
   nYAbFVCusmfcoOpleNKavXJShRdrIE =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('mpaa')
   nYAbFVCusmfcoOpleNKavXJShRdrIG =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('regularSynopsis')
   nYAbFVCusmfcoOpleNKavXJShRdrIj =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('dpSupplemental')
   nYAbFVCusmfcoOpleNKavXJShRdrIt=nYAbFVCusmfcoOpleNKavXJShRdrIL.get('sequiturEvidence')
   nYAbFVCusmfcoOpleNKavXJShRdrIi =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('thumbnail')
   nYAbFVCusmfcoOpleNKavXJShRdrDW =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('year')
   nYAbFVCusmfcoOpleNKavXJShRdrDB =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('duration')
   nYAbFVCusmfcoOpleNKavXJShRdrDP =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('info_genre')
   nYAbFVCusmfcoOpleNKavXJShRdrDI =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('director')
   nYAbFVCusmfcoOpleNKavXJShRdrDq =nYAbFVCusmfcoOpleNKavXJShRdrIL.get('cast')
   nYAbFVCusmfcoOpleNKavXJShRdrBE=nYAbFVCusmfcoOpleNKavXJShRdrDL(nYAbFVCusmfcoOpleNKavXJShRdrDW)if nYAbFVCusmfcoOpleNKavXJShRdrIM=='movie' else ''
   nYAbFVCusmfcoOpleNKavXJShRdrDH=''
   if nYAbFVCusmfcoOpleNKavXJShRdrIG:nYAbFVCusmfcoOpleNKavXJShRdrDH=nYAbFVCusmfcoOpleNKavXJShRdrDH+'\n\n'+nYAbFVCusmfcoOpleNKavXJShRdrIG
   if nYAbFVCusmfcoOpleNKavXJShRdrIj :nYAbFVCusmfcoOpleNKavXJShRdrDH=nYAbFVCusmfcoOpleNKavXJShRdrDH+'\n\n'+nYAbFVCusmfcoOpleNKavXJShRdrIj
   if nYAbFVCusmfcoOpleNKavXJShRdrIt:nYAbFVCusmfcoOpleNKavXJShRdrDH=nYAbFVCusmfcoOpleNKavXJShRdrDH+'\n\n'+nYAbFVCusmfcoOpleNKavXJShRdrIt
   nYAbFVCusmfcoOpleNKavXJShRdrDH=nYAbFVCusmfcoOpleNKavXJShRdrDH.strip()
   nYAbFVCusmfcoOpleNKavXJShRdrBG={'mediatype':'tvshow' if nYAbFVCusmfcoOpleNKavXJShRdrIM=='show' else 'movie','title':nYAbFVCusmfcoOpleNKavXJShRdrWj,'mpaa':nYAbFVCusmfcoOpleNKavXJShRdrIE,'plot':nYAbFVCusmfcoOpleNKavXJShRdrDH,'duration':nYAbFVCusmfcoOpleNKavXJShRdrDB,'genre':nYAbFVCusmfcoOpleNKavXJShRdrDP,'director':nYAbFVCusmfcoOpleNKavXJShRdrDI,'cast':nYAbFVCusmfcoOpleNKavXJShRdrDq,}
   nYAbFVCusmfcoOpleNKavXJShRdrBz={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if nYAbFVCusmfcoOpleNKavXJShRdrIM=='show' else 'MOVIE','videoid':nYAbFVCusmfcoOpleNKavXJShRdrIz,}
   nYAbFVCusmfcoOpleNKavXJShRdrWH.add_dir(nYAbFVCusmfcoOpleNKavXJShRdrWj,sublabel=nYAbFVCusmfcoOpleNKavXJShRdrBE,img=nYAbFVCusmfcoOpleNKavXJShRdrIi,infoLabels=nYAbFVCusmfcoOpleNKavXJShRdrBG,isFolder=nYAbFVCusmfcoOpleNKavXJShRdrDg,params=nYAbFVCusmfcoOpleNKavXJShRdrBz,isLink=nYAbFVCusmfcoOpleNKavXJShRdrDM)
  if nYAbFVCusmfcoOpleNKavXJShRdrIB:
   nYAbFVCusmfcoOpleNKavXJShRdrBz={}
   nYAbFVCusmfcoOpleNKavXJShRdrBz['mode'] ='NF_SEARCH' 
   nYAbFVCusmfcoOpleNKavXJShRdrBz['page'] =nYAbFVCusmfcoOpleNKavXJShRdrDL(nYAbFVCusmfcoOpleNKavXJShRdrIy+1)
   nYAbFVCusmfcoOpleNKavXJShRdrBz['search_key']=nYAbFVCusmfcoOpleNKavXJShRdrPi
   nYAbFVCusmfcoOpleNKavXJShRdrBz['byReference']=nYAbFVCusmfcoOpleNKavXJShRdrID
   nYAbFVCusmfcoOpleNKavXJShRdrWj='[B]%s >>[/B]'%'다음 페이지'
   nYAbFVCusmfcoOpleNKavXJShRdrDU=nYAbFVCusmfcoOpleNKavXJShRdrDL(nYAbFVCusmfcoOpleNKavXJShRdrIy+1)
   nYAbFVCusmfcoOpleNKavXJShRdrBj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nYAbFVCusmfcoOpleNKavXJShRdrWH.add_dir(nYAbFVCusmfcoOpleNKavXJShRdrWj,sublabel=nYAbFVCusmfcoOpleNKavXJShRdrDU,img=nYAbFVCusmfcoOpleNKavXJShRdrBj,infoLabels=nYAbFVCusmfcoOpleNKavXJShRdrDQ,isFolder=nYAbFVCusmfcoOpleNKavXJShRdrDM,params=nYAbFVCusmfcoOpleNKavXJShRdrBz)
  xbmcplugin.endOfDirectory(nYAbFVCusmfcoOpleNKavXJShRdrWH._addon_handle)
 def search_main(nYAbFVCusmfcoOpleNKavXJShRdrWH):
  nYAbFVCusmfcoOpleNKavXJShRdrIk=nYAbFVCusmfcoOpleNKavXJShRdrWH.main_params.get('mode',nYAbFVCusmfcoOpleNKavXJShRdrDQ)
  if nYAbFVCusmfcoOpleNKavXJShRdrIk=='NFLOGOUT':
   nYAbFVCusmfcoOpleNKavXJShRdrWH.NF_logout()
   return
  elif nYAbFVCusmfcoOpleNKavXJShRdrIk=='NFLOGIN':
   nYAbFVCusmfcoOpleNKavXJShRdrWH.NF_login()
   return
  nYAbFVCusmfcoOpleNKavXJShRdrWH.option_check()
  if nYAbFVCusmfcoOpleNKavXJShRdrIk is nYAbFVCusmfcoOpleNKavXJShRdrDQ:
   nYAbFVCusmfcoOpleNKavXJShRdrWH.dp_Main_List()
  elif nYAbFVCusmfcoOpleNKavXJShRdrIk=='TOTAL_SEARCH':
   nYAbFVCusmfcoOpleNKavXJShRdrWH.dp_Search_Group(nYAbFVCusmfcoOpleNKavXJShRdrWH.main_params)
  elif nYAbFVCusmfcoOpleNKavXJShRdrIk=='HYPER_LINK':
   nYAbFVCusmfcoOpleNKavXJShRdrWH.dp_Hyper_Link(nYAbFVCusmfcoOpleNKavXJShRdrWH.main_params)
  elif nYAbFVCusmfcoOpleNKavXJShRdrIk=='NF_SEARCH':
   nYAbFVCusmfcoOpleNKavXJShRdrWH.dp_Nf_Search(nYAbFVCusmfcoOpleNKavXJShRdrWH.main_params)
  elif nYAbFVCusmfcoOpleNKavXJShRdrIk=='TOTAL_HISTORY':
   nYAbFVCusmfcoOpleNKavXJShRdrWH.dp_Search_History()
  elif nYAbFVCusmfcoOpleNKavXJShRdrIk=='HISTORY_REMOVE':
   nYAbFVCusmfcoOpleNKavXJShRdrWH.dp_History_Delete(nYAbFVCusmfcoOpleNKavXJShRdrWH.main_params)
  else:
   nYAbFVCusmfcoOpleNKavXJShRdrDQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
