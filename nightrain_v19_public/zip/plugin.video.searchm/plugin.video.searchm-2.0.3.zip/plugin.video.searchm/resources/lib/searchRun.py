__author__="NightRain"
gHLbNyxBrlQOoaYjquVSmDUkAWwKRc=object
gHLbNyxBrlQOoaYjquVSmDUkAWwKRd=None
gHLbNyxBrlQOoaYjquVSmDUkAWwKRM=True
gHLbNyxBrlQOoaYjquVSmDUkAWwKRT=False
gHLbNyxBrlQOoaYjquVSmDUkAWwKRt=type
gHLbNyxBrlQOoaYjquVSmDUkAWwKRh=dict
gHLbNyxBrlQOoaYjquVSmDUkAWwKzp=open
gHLbNyxBrlQOoaYjquVSmDUkAWwKzv=len
gHLbNyxBrlQOoaYjquVSmDUkAWwKzf=Exception
gHLbNyxBrlQOoaYjquVSmDUkAWwKze=str
gHLbNyxBrlQOoaYjquVSmDUkAWwKzR=int
gHLbNyxBrlQOoaYjquVSmDUkAWwKzF=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
gHLbNyxBrlQOoaYjquVSmDUkAWwKpf=[{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
gHLbNyxBrlQOoaYjquVSmDUkAWwKpe={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},}
gHLbNyxBrlQOoaYjquVSmDUkAWwKpR=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
gHLbNyxBrlQOoaYjquVSmDUkAWwKpz =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class gHLbNyxBrlQOoaYjquVSmDUkAWwKpv(gHLbNyxBrlQOoaYjquVSmDUkAWwKRc):
 def __init__(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,gHLbNyxBrlQOoaYjquVSmDUkAWwKps,gHLbNyxBrlQOoaYjquVSmDUkAWwKpJ,gHLbNyxBrlQOoaYjquVSmDUkAWwKpE):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF._addon_url =gHLbNyxBrlQOoaYjquVSmDUkAWwKps
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF._addon_handle=gHLbNyxBrlQOoaYjquVSmDUkAWwKpJ
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.main_params =gHLbNyxBrlQOoaYjquVSmDUkAWwKpE
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj =LaqgmVDwkXNIfurnWOpAYjyEJeBHvS() 
 def addon_noti(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,sting):
  try:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpi=xbmcgui.Dialog()
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpi.notification(__addonname__,sting)
  except:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRd
 def addon_log(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,string):
  try:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpP=string.encode('utf-8','ignore')
  except:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpP='addonException: addon_log'
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpn=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,gHLbNyxBrlQOoaYjquVSmDUkAWwKpP),level=gHLbNyxBrlQOoaYjquVSmDUkAWwKpn)
 def get_keyboard_input(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,gHLbNyxBrlQOoaYjquVSmDUkAWwKpt):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpC=gHLbNyxBrlQOoaYjquVSmDUkAWwKRd
  kb=xbmc.Keyboard()
  kb.setHeading(gHLbNyxBrlQOoaYjquVSmDUkAWwKpt)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpC=kb.getText()
  return gHLbNyxBrlQOoaYjquVSmDUkAWwKpC
 def get_settings_menubookmark(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpG=gHLbNyxBrlQOoaYjquVSmDUkAWwKRM if __addon__.getSetting('menu_bookmark')=='true' else gHLbNyxBrlQOoaYjquVSmDUkAWwKRT
  return(gHLbNyxBrlQOoaYjquVSmDUkAWwKpG)
 def get_settings_makebookmark(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF):
  return gHLbNyxBrlQOoaYjquVSmDUkAWwKRM if __addon__.getSetting('make_bookmark')=='true' else gHLbNyxBrlQOoaYjquVSmDUkAWwKRT
 def get_settings_select_info(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpI=[]
  if __addon__.getSetting('netflixyn')=='true':gHLbNyxBrlQOoaYjquVSmDUkAWwKpI.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':gHLbNyxBrlQOoaYjquVSmDUkAWwKpI.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':gHLbNyxBrlQOoaYjquVSmDUkAWwKpI.append('tving')
  if __addon__.getSetting('watchayn')=='true':gHLbNyxBrlQOoaYjquVSmDUkAWwKpI.append('watcha')
  return gHLbNyxBrlQOoaYjquVSmDUkAWwKpI
 def get_settings_netflix(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpc =__addon__.getSetting('nfid')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpd =__addon__.getSetting('nfpw')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpM=__addon__.getSetting('nf_profile')
  return(gHLbNyxBrlQOoaYjquVSmDUkAWwKpc,gHLbNyxBrlQOoaYjquVSmDUkAWwKpd,gHLbNyxBrlQOoaYjquVSmDUkAWwKpM)
 def add_dir(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,label,sublabel='',img='',infoLabels=gHLbNyxBrlQOoaYjquVSmDUkAWwKRd,isFolder=gHLbNyxBrlQOoaYjquVSmDUkAWwKRM,params='',isLink=gHLbNyxBrlQOoaYjquVSmDUkAWwKRT,ContextMenu=gHLbNyxBrlQOoaYjquVSmDUkAWwKRd):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpT='%s?%s'%(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF._addon_url,urllib.parse.urlencode(params))
  if sublabel:gHLbNyxBrlQOoaYjquVSmDUkAWwKpt='%s < %s >'%(label,sublabel)
  else: gHLbNyxBrlQOoaYjquVSmDUkAWwKpt=label
  if not img:img='DefaultFolder.png'
  gHLbNyxBrlQOoaYjquVSmDUkAWwKph=xbmcgui.ListItem(gHLbNyxBrlQOoaYjquVSmDUkAWwKpt)
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKRt(img)==gHLbNyxBrlQOoaYjquVSmDUkAWwKRh:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKph.setArt(img)
  else:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKph.setArt({'thumb':img,'poster':img})
  if infoLabels:gHLbNyxBrlQOoaYjquVSmDUkAWwKph.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKph.setProperty('IsPlayable','true')
  if ContextMenu:gHLbNyxBrlQOoaYjquVSmDUkAWwKph.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF._addon_handle,gHLbNyxBrlQOoaYjquVSmDUkAWwKpT,gHLbNyxBrlQOoaYjquVSmDUkAWwKph,isFolder)
 def Load_Searched_List(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF):
  try:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvp=gHLbNyxBrlQOoaYjquVSmDUkAWwKpz
   fp=gHLbNyxBrlQOoaYjquVSmDUkAWwKzp(gHLbNyxBrlQOoaYjquVSmDUkAWwKvp,'r',-1,'utf-8')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvf=fp.readlines()
   fp.close()
  except:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvf=[]
  return gHLbNyxBrlQOoaYjquVSmDUkAWwKvf
 def Save_Searched_List(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,gHLbNyxBrlQOoaYjquVSmDUkAWwKep):
  try:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvp=gHLbNyxBrlQOoaYjquVSmDUkAWwKpz
   gHLbNyxBrlQOoaYjquVSmDUkAWwKve=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.Load_Searched_List() 
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvR={'skey':gHLbNyxBrlQOoaYjquVSmDUkAWwKep.strip()}
   fp=gHLbNyxBrlQOoaYjquVSmDUkAWwKzp(gHLbNyxBrlQOoaYjquVSmDUkAWwKvp,'w',-1,'utf-8')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvz=urllib.parse.urlencode(gHLbNyxBrlQOoaYjquVSmDUkAWwKvR)
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvz=gHLbNyxBrlQOoaYjquVSmDUkAWwKvz+'\n'
   fp.write(gHLbNyxBrlQOoaYjquVSmDUkAWwKvz)
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvF=0
   for gHLbNyxBrlQOoaYjquVSmDUkAWwKvs in gHLbNyxBrlQOoaYjquVSmDUkAWwKve:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKvJ=gHLbNyxBrlQOoaYjquVSmDUkAWwKRh(urllib.parse.parse_qsl(gHLbNyxBrlQOoaYjquVSmDUkAWwKvs))
    gHLbNyxBrlQOoaYjquVSmDUkAWwKvE=gHLbNyxBrlQOoaYjquVSmDUkAWwKvR.get('skey').strip()
    gHLbNyxBrlQOoaYjquVSmDUkAWwKvX=gHLbNyxBrlQOoaYjquVSmDUkAWwKvJ.get('skey').strip()
    if gHLbNyxBrlQOoaYjquVSmDUkAWwKvE!=gHLbNyxBrlQOoaYjquVSmDUkAWwKvX:
     fp.write(gHLbNyxBrlQOoaYjquVSmDUkAWwKvs)
     gHLbNyxBrlQOoaYjquVSmDUkAWwKvF+=1
     if gHLbNyxBrlQOoaYjquVSmDUkAWwKvF>=50:break
   fp.close()
  except:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRd
 def dp_Search_History(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,args):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKvi=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.Load_Searched_List()
  for gHLbNyxBrlQOoaYjquVSmDUkAWwKvP in gHLbNyxBrlQOoaYjquVSmDUkAWwKvi:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvn=gHLbNyxBrlQOoaYjquVSmDUkAWwKRh(urllib.parse.parse_qsl(gHLbNyxBrlQOoaYjquVSmDUkAWwKvP))
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvC=gHLbNyxBrlQOoaYjquVSmDUkAWwKvn.get('skey').strip()
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvG={'mode':'TOTAL_SEARCH','search_key':gHLbNyxBrlQOoaYjquVSmDUkAWwKvC,}
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvI={'mode':'HISTORY_REMOVE','skey':gHLbNyxBrlQOoaYjquVSmDUkAWwKvC,'delmode':'ONE',}
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvc=urllib.parse.urlencode(gHLbNyxBrlQOoaYjquVSmDUkAWwKvI)
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvd=[('선택된 검색어 ( %s ) 삭제'%(gHLbNyxBrlQOoaYjquVSmDUkAWwKvC),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(gHLbNyxBrlQOoaYjquVSmDUkAWwKvc))]
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.add_dir(gHLbNyxBrlQOoaYjquVSmDUkAWwKvC,sublabel='',img=gHLbNyxBrlQOoaYjquVSmDUkAWwKRd,infoLabels=gHLbNyxBrlQOoaYjquVSmDUkAWwKRd,isFolder=gHLbNyxBrlQOoaYjquVSmDUkAWwKRM,params=gHLbNyxBrlQOoaYjquVSmDUkAWwKvG,ContextMenu=gHLbNyxBrlQOoaYjquVSmDUkAWwKvd)
  gHLbNyxBrlQOoaYjquVSmDUkAWwKvT={'plot':'검색목록 전체를 삭제합니다.'}
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpt='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  gHLbNyxBrlQOoaYjquVSmDUkAWwKvG={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  gHLbNyxBrlQOoaYjquVSmDUkAWwKvt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.add_dir(gHLbNyxBrlQOoaYjquVSmDUkAWwKpt,sublabel='',img=gHLbNyxBrlQOoaYjquVSmDUkAWwKvt,infoLabels=gHLbNyxBrlQOoaYjquVSmDUkAWwKvT,isFolder=gHLbNyxBrlQOoaYjquVSmDUkAWwKRT,params=gHLbNyxBrlQOoaYjquVSmDUkAWwKvG,isLink=gHLbNyxBrlQOoaYjquVSmDUkAWwKRM)
  xbmcplugin.endOfDirectory(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF._addon_handle,cacheToDisc=gHLbNyxBrlQOoaYjquVSmDUkAWwKRT)
 def Delete_History_List(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,gHLbNyxBrlQOoaYjquVSmDUkAWwKvC,gHLbNyxBrlQOoaYjquVSmDUkAWwKfv):
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKfv=='ALL':
   try:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKvp=gHLbNyxBrlQOoaYjquVSmDUkAWwKpz
    fp=gHLbNyxBrlQOoaYjquVSmDUkAWwKzp(gHLbNyxBrlQOoaYjquVSmDUkAWwKvp,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKRd
  else:
   try:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKvp=gHLbNyxBrlQOoaYjquVSmDUkAWwKpz
    gHLbNyxBrlQOoaYjquVSmDUkAWwKve=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.Load_Searched_List() 
    fp=gHLbNyxBrlQOoaYjquVSmDUkAWwKzp(gHLbNyxBrlQOoaYjquVSmDUkAWwKvp,'w',-1,'utf-8')
    for gHLbNyxBrlQOoaYjquVSmDUkAWwKvs in gHLbNyxBrlQOoaYjquVSmDUkAWwKve:
     gHLbNyxBrlQOoaYjquVSmDUkAWwKvJ=gHLbNyxBrlQOoaYjquVSmDUkAWwKRh(urllib.parse.parse_qsl(gHLbNyxBrlQOoaYjquVSmDUkAWwKvs))
     gHLbNyxBrlQOoaYjquVSmDUkAWwKfp=gHLbNyxBrlQOoaYjquVSmDUkAWwKvJ.get('skey').strip()
     if gHLbNyxBrlQOoaYjquVSmDUkAWwKvC!=gHLbNyxBrlQOoaYjquVSmDUkAWwKfp:
      fp.write(gHLbNyxBrlQOoaYjquVSmDUkAWwKvs)
    fp.close()
   except:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKRd
 def dp_History_Delete(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,args):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKvC =args.get('skey') 
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfv=args.get('delmode')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpi=xbmcgui.Dialog()
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKfv=='ALL':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKfe=gHLbNyxBrlQOoaYjquVSmDUkAWwKpi.yesno(__language__(30913).encode('utf8'),__language__(30915).encode('utf8'))
  else:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKfe=gHLbNyxBrlQOoaYjquVSmDUkAWwKpi.yesno(__language__(30914).encode('utf8'),__language__(30915).encode('utf8'))
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKfe==gHLbNyxBrlQOoaYjquVSmDUkAWwKRT:sys.exit()
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.Delete_History_List(gHLbNyxBrlQOoaYjquVSmDUkAWwKvC,gHLbNyxBrlQOoaYjquVSmDUkAWwKfv)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpG=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.get_settings_menubookmark()
  for gHLbNyxBrlQOoaYjquVSmDUkAWwKfR in gHLbNyxBrlQOoaYjquVSmDUkAWwKpf:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpt=gHLbNyxBrlQOoaYjquVSmDUkAWwKfR.get('title')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvt=''
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKfR.get('mode')=='MENU_BOOKMARK' and gHLbNyxBrlQOoaYjquVSmDUkAWwKpG==gHLbNyxBrlQOoaYjquVSmDUkAWwKRT:continue
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvG={'mode':gHLbNyxBrlQOoaYjquVSmDUkAWwKfR.get('mode')}
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKfR.get('mode')in['XXX','MENU_BOOKMARK']:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfz=gHLbNyxBrlQOoaYjquVSmDUkAWwKRT
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfF =gHLbNyxBrlQOoaYjquVSmDUkAWwKRM
   else:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfz=gHLbNyxBrlQOoaYjquVSmDUkAWwKRM
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfF =gHLbNyxBrlQOoaYjquVSmDUkAWwKRT
   if 'icon' in gHLbNyxBrlQOoaYjquVSmDUkAWwKfR:gHLbNyxBrlQOoaYjquVSmDUkAWwKvt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',gHLbNyxBrlQOoaYjquVSmDUkAWwKfR.get('icon')) 
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.add_dir(gHLbNyxBrlQOoaYjquVSmDUkAWwKpt,sublabel='',img=gHLbNyxBrlQOoaYjquVSmDUkAWwKvt,infoLabels=gHLbNyxBrlQOoaYjquVSmDUkAWwKRd,isFolder=gHLbNyxBrlQOoaYjquVSmDUkAWwKfz,params=gHLbNyxBrlQOoaYjquVSmDUkAWwKvG,isLink=gHLbNyxBrlQOoaYjquVSmDUkAWwKfF)
  xbmcplugin.endOfDirectory(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF._addon_handle)
 def option_check(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpI=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.get_settings_select_info()
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKzv(gHLbNyxBrlQOoaYjquVSmDUkAWwKpI)==0:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpi=xbmcgui.Dialog()
   gHLbNyxBrlQOoaYjquVSmDUkAWwKfe=gHLbNyxBrlQOoaYjquVSmDUkAWwKpi.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKfe==gHLbNyxBrlQOoaYjquVSmDUkAWwKRM:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in gHLbNyxBrlQOoaYjquVSmDUkAWwKpI:
   (gHLbNyxBrlQOoaYjquVSmDUkAWwKfs,gHLbNyxBrlQOoaYjquVSmDUkAWwKfJ,gHLbNyxBrlQOoaYjquVSmDUkAWwKfE)=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.get_settings_netflix()
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKfs=='' or gHLbNyxBrlQOoaYjquVSmDUkAWwKfJ=='':
    gHLbNyxBrlQOoaYjquVSmDUkAWwKpi=xbmcgui.Dialog()
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfe=gHLbNyxBrlQOoaYjquVSmDUkAWwKpi.yesno(__language__(30902).encode('utf8'),__language__(30903).encode('utf8'))
    if gHLbNyxBrlQOoaYjquVSmDUkAWwKfe==gHLbNyxBrlQOoaYjquVSmDUkAWwKRM:
     __addon__.openSettings()
     sys.exit()
    else:
     sys.exit()
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.NF_cookiefile_check()==gHLbNyxBrlQOoaYjquVSmDUkAWwKRT:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKpi=xbmcgui.Dialog()
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfe=gHLbNyxBrlQOoaYjquVSmDUkAWwKpi.yesno(__language__(30907).encode('utf8'),__language__(30916).encode('utf8'))
    if gHLbNyxBrlQOoaYjquVSmDUkAWwKfe==gHLbNyxBrlQOoaYjquVSmDUkAWwKRM:
     if gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.NF_login(inputCheck=gHLbNyxBrlQOoaYjquVSmDUkAWwKRT)==gHLbNyxBrlQOoaYjquVSmDUkAWwKRT:
      sys.exit()
    else:
     sys.exit()
 def NF_cookiefile_check(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfX={}
  try: 
   fp=gHLbNyxBrlQOoaYjquVSmDUkAWwKzp(gHLbNyxBrlQOoaYjquVSmDUkAWwKpR,'r',-1,'utf-8')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKfX= json.load(fp)
   fp.close()
  except gHLbNyxBrlQOoaYjquVSmDUkAWwKzf as exception:
   return gHLbNyxBrlQOoaYjquVSmDUkAWwKRT
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.NF=gHLbNyxBrlQOoaYjquVSmDUkAWwKfX
  (gHLbNyxBrlQOoaYjquVSmDUkAWwKfs,gHLbNyxBrlQOoaYjquVSmDUkAWwKfJ,gHLbNyxBrlQOoaYjquVSmDUkAWwKfE)=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.get_settings_netflix()
  (gHLbNyxBrlQOoaYjquVSmDUkAWwKfi,gHLbNyxBrlQOoaYjquVSmDUkAWwKfP,gHLbNyxBrlQOoaYjquVSmDUkAWwKfn)=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Load_session_acount()
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKfs!=gHLbNyxBrlQOoaYjquVSmDUkAWwKfi or gHLbNyxBrlQOoaYjquVSmDUkAWwKfJ!=gHLbNyxBrlQOoaYjquVSmDUkAWwKfP or gHLbNyxBrlQOoaYjquVSmDUkAWwKfE!=gHLbNyxBrlQOoaYjquVSmDUkAWwKze(gHLbNyxBrlQOoaYjquVSmDUkAWwKfn):
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Init_NF_Total()
   return gHLbNyxBrlQOoaYjquVSmDUkAWwKRT
  return gHLbNyxBrlQOoaYjquVSmDUkAWwKRM
 def NF_login(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,inputCheck=gHLbNyxBrlQOoaYjquVSmDUkAWwKRM):
  (gHLbNyxBrlQOoaYjquVSmDUkAWwKfC,gHLbNyxBrlQOoaYjquVSmDUkAWwKfG,gHLbNyxBrlQOoaYjquVSmDUkAWwKfI)=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.get_settings_netflix()
  if inputCheck==gHLbNyxBrlQOoaYjquVSmDUkAWwKRM:
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKfC=='' or gHLbNyxBrlQOoaYjquVSmDUkAWwKfG=='':
    gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_noti(__language__(30902).encode('utf-8'))
    return gHLbNyxBrlQOoaYjquVSmDUkAWwKRT
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpi=xbmcgui.Dialog()
   gHLbNyxBrlQOoaYjquVSmDUkAWwKfe=gHLbNyxBrlQOoaYjquVSmDUkAWwKpi.yesno(__language__(30911).encode('utf8'),__language__(30912).encode('utf8'))
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKfe==gHLbNyxBrlQOoaYjquVSmDUkAWwKRT:
    return gHLbNyxBrlQOoaYjquVSmDUkAWwKRT 
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfc=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_NF_BaseCookies()
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKfc:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_log('pass1 ok!')
  else:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_log('pass1 error!')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_noti(__language__(30905).encode('utf-8'))
   return gHLbNyxBrlQOoaYjquVSmDUkAWwKRT 
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfc=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_NF_BaseLogin(gHLbNyxBrlQOoaYjquVSmDUkAWwKfC,gHLbNyxBrlQOoaYjquVSmDUkAWwKfG,gHLbNyxBrlQOoaYjquVSmDUkAWwKfI)
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKfc:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_log('pass2 ok!')
  else:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_log('pass2 error!')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_noti(__language__(30905).encode('utf-8'))
   return gHLbNyxBrlQOoaYjquVSmDUkAWwKRT 
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfc=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_NF_ActivateProfile()
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKfc:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_log('pass3 ok!')
  else:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_log('pass3 error!')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_noti(__language__(30905).encode('utf-8'))
   return gHLbNyxBrlQOoaYjquVSmDUkAWwKRT 
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfc=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_NF_BrowseMain()
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKfc:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_log('pass4 ok!')
  else:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_log('pass4 error!')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_noti(__language__(30905).encode('utf-8'))
   return gHLbNyxBrlQOoaYjquVSmDUkAWwKRT 
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfd =gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_Now_Datetime()
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfM=gHLbNyxBrlQOoaYjquVSmDUkAWwKfd+datetime.timedelta(days=gHLbNyxBrlQOoaYjquVSmDUkAWwKzR(__addon__.getSetting('cache_ttl')))
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.NF['SESSION']['limitdate']=gHLbNyxBrlQOoaYjquVSmDUkAWwKfM.strftime('%Y-%m-%d')
  try: 
   fp=gHLbNyxBrlQOoaYjquVSmDUkAWwKzp(gHLbNyxBrlQOoaYjquVSmDUkAWwKpR,'w',-1,'utf-8')
   json.dump(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.NF,fp)
   fp.close()
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_log('pass5 save ok!')
  except gHLbNyxBrlQOoaYjquVSmDUkAWwKzf as exception:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_log('pass5 save error!')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_noti(__language__(30905).encode('utf-8'))
   return gHLbNyxBrlQOoaYjquVSmDUkAWwKRT
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_noti(__language__(30904).encode('utf-8'))
  return gHLbNyxBrlQOoaYjquVSmDUkAWwKRM
 def NF_logout(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpi=xbmcgui.Dialog()
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfe=gHLbNyxBrlQOoaYjquVSmDUkAWwKpi.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKfe==gHLbNyxBrlQOoaYjquVSmDUkAWwKRT:return 
  if os.path.isfile(gHLbNyxBrlQOoaYjquVSmDUkAWwKpR):os.remove(gHLbNyxBrlQOoaYjquVSmDUkAWwKpR)
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,gHLbNyxBrlQOoaYjquVSmDUkAWwKev):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfT=''
  gHLbNyxBrlQOoaYjquVSmDUkAWwKft=7
  try:
   for i in gHLbNyxBrlQOoaYjquVSmDUkAWwKzF(gHLbNyxBrlQOoaYjquVSmDUkAWwKzv(gHLbNyxBrlQOoaYjquVSmDUkAWwKev)):
    if i>=gHLbNyxBrlQOoaYjquVSmDUkAWwKft:
     gHLbNyxBrlQOoaYjquVSmDUkAWwKfT=gHLbNyxBrlQOoaYjquVSmDUkAWwKfT+'...'
     break
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfT=gHLbNyxBrlQOoaYjquVSmDUkAWwKfT+gHLbNyxBrlQOoaYjquVSmDUkAWwKev[i]['title']+'\n'
  except:
   return ''
  return gHLbNyxBrlQOoaYjquVSmDUkAWwKfT
 def dp_Search_Group(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,args):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpI =gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.get_settings_select_info()
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfh=[]
  if 'search_key' in args:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKep=args.get('search_key')
  else:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKep=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not gHLbNyxBrlQOoaYjquVSmDUkAWwKep:
    xbmcplugin.endOfDirectory(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF._addon_handle)
    return
  if 'wavve' in gHLbNyxBrlQOoaYjquVSmDUkAWwKpI:
   (gHLbNyxBrlQOoaYjquVSmDUkAWwKev,gHLbNyxBrlQOoaYjquVSmDUkAWwKef)=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_Search_Wavve(gHLbNyxBrlQOoaYjquVSmDUkAWwKep,'TVSHOW',1)
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKzv(gHLbNyxBrlQOoaYjquVSmDUkAWwKev)>0:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKeR={'sType':'wavve_tvshow','sList':gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.MakeText_FreeList(gHLbNyxBrlQOoaYjquVSmDUkAWwKev),}
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfh.append(gHLbNyxBrlQOoaYjquVSmDUkAWwKeR)
   (gHLbNyxBrlQOoaYjquVSmDUkAWwKev,gHLbNyxBrlQOoaYjquVSmDUkAWwKef)=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_Search_Wavve(gHLbNyxBrlQOoaYjquVSmDUkAWwKep,'MOVIE',1)
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKzv(gHLbNyxBrlQOoaYjquVSmDUkAWwKev)>0:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKeR={'sType':'wavve_movie','sList':gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.MakeText_FreeList(gHLbNyxBrlQOoaYjquVSmDUkAWwKev),}
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfh.append(gHLbNyxBrlQOoaYjquVSmDUkAWwKeR)
  if 'tving' in gHLbNyxBrlQOoaYjquVSmDUkAWwKpI:
   (gHLbNyxBrlQOoaYjquVSmDUkAWwKev,gHLbNyxBrlQOoaYjquVSmDUkAWwKef)=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_Search_Tving(gHLbNyxBrlQOoaYjquVSmDUkAWwKep,'TVSHOW',1)
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKzv(gHLbNyxBrlQOoaYjquVSmDUkAWwKev)>0:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKeR={'sType':'tving_tvshow','sList':gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.MakeText_FreeList(gHLbNyxBrlQOoaYjquVSmDUkAWwKev),}
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfh.append(gHLbNyxBrlQOoaYjquVSmDUkAWwKeR)
   (gHLbNyxBrlQOoaYjquVSmDUkAWwKev,gHLbNyxBrlQOoaYjquVSmDUkAWwKef)=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_Search_Tving(gHLbNyxBrlQOoaYjquVSmDUkAWwKep,'MOVIE',1)
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKzv(gHLbNyxBrlQOoaYjquVSmDUkAWwKev)>0:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKeR={'sType':'tving_movie','sList':gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.MakeText_FreeList(gHLbNyxBrlQOoaYjquVSmDUkAWwKev),}
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfh.append(gHLbNyxBrlQOoaYjquVSmDUkAWwKeR)
  if 'watcha' in gHLbNyxBrlQOoaYjquVSmDUkAWwKpI:
   (gHLbNyxBrlQOoaYjquVSmDUkAWwKev,gHLbNyxBrlQOoaYjquVSmDUkAWwKef)=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_Search_Watcha(gHLbNyxBrlQOoaYjquVSmDUkAWwKep,1)
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKzv(gHLbNyxBrlQOoaYjquVSmDUkAWwKev)>0:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKeR={'sType':'watcha_list','sList':gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.MakeText_FreeList(gHLbNyxBrlQOoaYjquVSmDUkAWwKev),}
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfh.append(gHLbNyxBrlQOoaYjquVSmDUkAWwKeR)
  if 'netflix' in gHLbNyxBrlQOoaYjquVSmDUkAWwKpI:
   (gHLbNyxBrlQOoaYjquVSmDUkAWwKev,gHLbNyxBrlQOoaYjquVSmDUkAWwKef,gHLbNyxBrlQOoaYjquVSmDUkAWwKez)=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_Search_Netflix(gHLbNyxBrlQOoaYjquVSmDUkAWwKep,1)
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKzv(gHLbNyxBrlQOoaYjquVSmDUkAWwKev)>0:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKeR={'sType':'netflix_list','sList':gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.MakeText_FreeList(gHLbNyxBrlQOoaYjquVSmDUkAWwKev),}
    gHLbNyxBrlQOoaYjquVSmDUkAWwKfh.append(gHLbNyxBrlQOoaYjquVSmDUkAWwKeR)
  for gHLbNyxBrlQOoaYjquVSmDUkAWwKeF in gHLbNyxBrlQOoaYjquVSmDUkAWwKfh:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKes=gHLbNyxBrlQOoaYjquVSmDUkAWwKpe[gHLbNyxBrlQOoaYjquVSmDUkAWwKeF.get('sType')]
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeJ={'plot':'검색어 : '+gHLbNyxBrlQOoaYjquVSmDUkAWwKep+'\n\n'+gHLbNyxBrlQOoaYjquVSmDUkAWwKeF.get('sList')}
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpt=gHLbNyxBrlQOoaYjquVSmDUkAWwKes.get('title')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvG={'mode':gHLbNyxBrlQOoaYjquVSmDUkAWwKes.get('mode'),'ott':gHLbNyxBrlQOoaYjquVSmDUkAWwKes.get('ott'),'vidtype':gHLbNyxBrlQOoaYjquVSmDUkAWwKes.get('vidtype'),'search_key':gHLbNyxBrlQOoaYjquVSmDUkAWwKep}
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKes.get('ott')=='netflix':
    gHLbNyxBrlQOoaYjquVSmDUkAWwKvG['page'] ='1'
    gHLbNyxBrlQOoaYjquVSmDUkAWwKvG['byReference']='-'
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',gHLbNyxBrlQOoaYjquVSmDUkAWwKes.get('icon'))
   gHLbNyxBrlQOoaYjquVSmDUkAWwKfz=gHLbNyxBrlQOoaYjquVSmDUkAWwKRM if gHLbNyxBrlQOoaYjquVSmDUkAWwKes.get('mode')!='HYPER_LINK' else gHLbNyxBrlQOoaYjquVSmDUkAWwKRT
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.add_dir(gHLbNyxBrlQOoaYjquVSmDUkAWwKpt,sublabel='',img=gHLbNyxBrlQOoaYjquVSmDUkAWwKvt,infoLabels=gHLbNyxBrlQOoaYjquVSmDUkAWwKeJ,isFolder=gHLbNyxBrlQOoaYjquVSmDUkAWwKfz,params=gHLbNyxBrlQOoaYjquVSmDUkAWwKvG,isLink=gHLbNyxBrlQOoaYjquVSmDUkAWwKRM)
  xbmcplugin.endOfDirectory(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF._addon_handle)
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.Save_Searched_List(gHLbNyxBrlQOoaYjquVSmDUkAWwKep)
 def dp_Hyper_Link(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,args):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKeE =args.get('mode')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKeX =args.get('ott')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKei =args.get('vidtype')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKep=args.get('search_key')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKeP='-'
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKeX=='wavve':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKen={'mode':'LOCAL_SEARCH','sType':'movie' if gHLbNyxBrlQOoaYjquVSmDUkAWwKei=='MOVIE' else 'vod','search_key':gHLbNyxBrlQOoaYjquVSmDUkAWwKep,'page':'1',}
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeC=urllib.parse.urlencode(gHLbNyxBrlQOoaYjquVSmDUkAWwKen)
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeP='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(gHLbNyxBrlQOoaYjquVSmDUkAWwKeC)
  elif gHLbNyxBrlQOoaYjquVSmDUkAWwKeX=='tving':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKen={'mode':'LOCAL_SEARCH','stype':'movie' if gHLbNyxBrlQOoaYjquVSmDUkAWwKei=='MOVIE' else 'vod','search_key':gHLbNyxBrlQOoaYjquVSmDUkAWwKep,'page':'1',}
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeC=urllib.parse.urlencode(gHLbNyxBrlQOoaYjquVSmDUkAWwKen)
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeP='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(gHLbNyxBrlQOoaYjquVSmDUkAWwKeC)
  elif gHLbNyxBrlQOoaYjquVSmDUkAWwKeX=='watcha':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKen={'mode':'LOCAL_SEARCH','search_key':gHLbNyxBrlQOoaYjquVSmDUkAWwKep,'page':'1',}
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeC=urllib.parse.urlencode(gHLbNyxBrlQOoaYjquVSmDUkAWwKen)
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeP='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(gHLbNyxBrlQOoaYjquVSmDUkAWwKeC)
  elif gHLbNyxBrlQOoaYjquVSmDUkAWwKeX=='netflix':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeG=args.get('videoid')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeI=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.NF['SESSION']['nowGuid']
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKei=='TVSHOW':
    gHLbNyxBrlQOoaYjquVSmDUkAWwKeP='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(gHLbNyxBrlQOoaYjquVSmDUkAWwKeG)
   else:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKeP='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(gHLbNyxBrlQOoaYjquVSmDUkAWwKeG,gHLbNyxBrlQOoaYjquVSmDUkAWwKeI)
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.addon_log('ott_url ==> ( '+gHLbNyxBrlQOoaYjquVSmDUkAWwKeP+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(gHLbNyxBrlQOoaYjquVSmDUkAWwKeP)
 def dp_Nf_Search(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,args):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKec =gHLbNyxBrlQOoaYjquVSmDUkAWwKzR(args.get('page'))
  gHLbNyxBrlQOoaYjquVSmDUkAWwKep =args.get('search_key')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKez=args.get('byReference')
  (gHLbNyxBrlQOoaYjquVSmDUkAWwKev,gHLbNyxBrlQOoaYjquVSmDUkAWwKef,gHLbNyxBrlQOoaYjquVSmDUkAWwKez)=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.SearchObj.Get_Search_Netflix(gHLbNyxBrlQOoaYjquVSmDUkAWwKep,gHLbNyxBrlQOoaYjquVSmDUkAWwKec,byReference=gHLbNyxBrlQOoaYjquVSmDUkAWwKez)
  for gHLbNyxBrlQOoaYjquVSmDUkAWwKed in gHLbNyxBrlQOoaYjquVSmDUkAWwKev:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeG =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('videoid')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKei =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('vidtype')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpt =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('title')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeM =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('mpaa')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeT =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('regularSynopsis')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKet =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('dpSupplemental')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKeh=gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('sequiturEvidence')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRp =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('thumbnail')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRv =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('year')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRf =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('duration')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRe =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('info_genre')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRz =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('director')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRF =gHLbNyxBrlQOoaYjquVSmDUkAWwKed.get('cast')
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKei=='movie':
    gHLbNyxBrlQOoaYjquVSmDUkAWwKvM=' (%s)'%(gHLbNyxBrlQOoaYjquVSmDUkAWwKze(gHLbNyxBrlQOoaYjquVSmDUkAWwKRv))
   else:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKvM=''
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRs=''
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKeT:gHLbNyxBrlQOoaYjquVSmDUkAWwKRs=gHLbNyxBrlQOoaYjquVSmDUkAWwKRs+'\n\n'+gHLbNyxBrlQOoaYjquVSmDUkAWwKeT
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKet :gHLbNyxBrlQOoaYjquVSmDUkAWwKRs=gHLbNyxBrlQOoaYjquVSmDUkAWwKRs+'\n\n'+gHLbNyxBrlQOoaYjquVSmDUkAWwKet
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKeh:gHLbNyxBrlQOoaYjquVSmDUkAWwKRs=gHLbNyxBrlQOoaYjquVSmDUkAWwKRs+'\n\n'+gHLbNyxBrlQOoaYjquVSmDUkAWwKeh
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRs=gHLbNyxBrlQOoaYjquVSmDUkAWwKRs.strip()
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvT={'mediatype':'tvshow' if gHLbNyxBrlQOoaYjquVSmDUkAWwKei=='show' else 'movie','title':gHLbNyxBrlQOoaYjquVSmDUkAWwKpt,'mpaa':gHLbNyxBrlQOoaYjquVSmDUkAWwKeM,'plot':gHLbNyxBrlQOoaYjquVSmDUkAWwKRs,'duration':gHLbNyxBrlQOoaYjquVSmDUkAWwKRf,'genre':gHLbNyxBrlQOoaYjquVSmDUkAWwKRe,'director':gHLbNyxBrlQOoaYjquVSmDUkAWwKRz,'cast':gHLbNyxBrlQOoaYjquVSmDUkAWwKRF,'year':gHLbNyxBrlQOoaYjquVSmDUkAWwKRv,}
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvG={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if gHLbNyxBrlQOoaYjquVSmDUkAWwKei=='show' else 'MOVIE','videoid':gHLbNyxBrlQOoaYjquVSmDUkAWwKeG,}
   if gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.get_settings_makebookmark():
    gHLbNyxBrlQOoaYjquVSmDUkAWwKRJ={'videoid':gHLbNyxBrlQOoaYjquVSmDUkAWwKeG,'vidtype':'tvshow' if gHLbNyxBrlQOoaYjquVSmDUkAWwKei=='show' else 'movie','vtitle':gHLbNyxBrlQOoaYjquVSmDUkAWwKpt+gHLbNyxBrlQOoaYjquVSmDUkAWwKvM,'vsubtitle':'','vinfo':gHLbNyxBrlQOoaYjquVSmDUkAWwKvT,'thumbnail':gHLbNyxBrlQOoaYjquVSmDUkAWwKRp,}
    gHLbNyxBrlQOoaYjquVSmDUkAWwKRE=json.dumps(gHLbNyxBrlQOoaYjquVSmDUkAWwKRJ)
    gHLbNyxBrlQOoaYjquVSmDUkAWwKRE=urllib.parse.quote(gHLbNyxBrlQOoaYjquVSmDUkAWwKRE)
    gHLbNyxBrlQOoaYjquVSmDUkAWwKRX='RunPlugin(plugin://plugin.video.searchm/?mode=SET_BOOKMARK&bm_param=%s)'%(gHLbNyxBrlQOoaYjquVSmDUkAWwKRE)
    gHLbNyxBrlQOoaYjquVSmDUkAWwKvd=[('(통합) 찜 영상에 추가',gHLbNyxBrlQOoaYjquVSmDUkAWwKRX)]
   else:
    gHLbNyxBrlQOoaYjquVSmDUkAWwKvd=gHLbNyxBrlQOoaYjquVSmDUkAWwKRd
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.add_dir(gHLbNyxBrlQOoaYjquVSmDUkAWwKpt+gHLbNyxBrlQOoaYjquVSmDUkAWwKvM,sublabel=gHLbNyxBrlQOoaYjquVSmDUkAWwKRd,img=gHLbNyxBrlQOoaYjquVSmDUkAWwKRp,infoLabels=gHLbNyxBrlQOoaYjquVSmDUkAWwKvT,isFolder=gHLbNyxBrlQOoaYjquVSmDUkAWwKRT,params=gHLbNyxBrlQOoaYjquVSmDUkAWwKvG,isLink=gHLbNyxBrlQOoaYjquVSmDUkAWwKRM,ContextMenu=gHLbNyxBrlQOoaYjquVSmDUkAWwKvd)
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKef:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvG={}
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvG['mode'] ='NF_SEARCH' 
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvG['page'] =gHLbNyxBrlQOoaYjquVSmDUkAWwKze(gHLbNyxBrlQOoaYjquVSmDUkAWwKec+1)
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvG['search_key']=gHLbNyxBrlQOoaYjquVSmDUkAWwKep
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvG['byReference']=gHLbNyxBrlQOoaYjquVSmDUkAWwKez
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpt='[B]%s >>[/B]'%'다음 페이지'
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRi=gHLbNyxBrlQOoaYjquVSmDUkAWwKze(gHLbNyxBrlQOoaYjquVSmDUkAWwKec+1)
   gHLbNyxBrlQOoaYjquVSmDUkAWwKvt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.add_dir(gHLbNyxBrlQOoaYjquVSmDUkAWwKpt,sublabel=gHLbNyxBrlQOoaYjquVSmDUkAWwKRi,img=gHLbNyxBrlQOoaYjquVSmDUkAWwKvt,infoLabels=gHLbNyxBrlQOoaYjquVSmDUkAWwKRd,isFolder=gHLbNyxBrlQOoaYjquVSmDUkAWwKRM,params=gHLbNyxBrlQOoaYjquVSmDUkAWwKvG)
  xbmcplugin.setContent(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF._addon_handle,'movies')
  xbmcplugin.endOfDirectory(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF._addon_handle)
 def dp_Bookmark_Menu(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,args):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKeP='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(gHLbNyxBrlQOoaYjquVSmDUkAWwKeP)
 def dp_Set_Bookmark(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF,args):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKRP=urllib.parse.unquote(args.get('bm_param'))
  gHLbNyxBrlQOoaYjquVSmDUkAWwKRP=json.loads(gHLbNyxBrlQOoaYjquVSmDUkAWwKRP)
  gHLbNyxBrlQOoaYjquVSmDUkAWwKeG =gHLbNyxBrlQOoaYjquVSmDUkAWwKRP.get('videoid')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKei =gHLbNyxBrlQOoaYjquVSmDUkAWwKRP.get('vidtype')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKRn =gHLbNyxBrlQOoaYjquVSmDUkAWwKRP.get('vtitle')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKRC =gHLbNyxBrlQOoaYjquVSmDUkAWwKRP.get('vsubtitle')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKRG =gHLbNyxBrlQOoaYjquVSmDUkAWwKRP.get('vinfo')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKRp =gHLbNyxBrlQOoaYjquVSmDUkAWwKRP.get('thumbnail')
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpi=xbmcgui.Dialog()
  gHLbNyxBrlQOoaYjquVSmDUkAWwKfe=gHLbNyxBrlQOoaYjquVSmDUkAWwKpi.yesno(__language__(30917).encode('utf8'),gHLbNyxBrlQOoaYjquVSmDUkAWwKRn+' \n\n'+__language__(30918))
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKfe==gHLbNyxBrlQOoaYjquVSmDUkAWwKRT:return
  gHLbNyxBrlQOoaYjquVSmDUkAWwKRI={'indexinfo':{'ott':'netflix','videoid':gHLbNyxBrlQOoaYjquVSmDUkAWwKeG,'vidtype':gHLbNyxBrlQOoaYjquVSmDUkAWwKei,},'saveinfo':{'title':gHLbNyxBrlQOoaYjquVSmDUkAWwKRn,'subtitle':gHLbNyxBrlQOoaYjquVSmDUkAWwKRC,'thumbnail':gHLbNyxBrlQOoaYjquVSmDUkAWwKRp,'infoLabels':gHLbNyxBrlQOoaYjquVSmDUkAWwKRG,},}
  gHLbNyxBrlQOoaYjquVSmDUkAWwKRE=json.dumps(gHLbNyxBrlQOoaYjquVSmDUkAWwKRI)
  gHLbNyxBrlQOoaYjquVSmDUkAWwKRE=urllib.parse.quote(gHLbNyxBrlQOoaYjquVSmDUkAWwKRE)
  gHLbNyxBrlQOoaYjquVSmDUkAWwKRX='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(gHLbNyxBrlQOoaYjquVSmDUkAWwKRE)
  xbmc.executebuiltin(gHLbNyxBrlQOoaYjquVSmDUkAWwKRX)
 def search_main(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF):
  gHLbNyxBrlQOoaYjquVSmDUkAWwKeE=gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.main_params.get('mode',gHLbNyxBrlQOoaYjquVSmDUkAWwKRd)
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKeE=='NFLOGOUT':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.NF_logout()
   return
  elif gHLbNyxBrlQOoaYjquVSmDUkAWwKeE=='NFLOGIN':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.NF_login()
   return
  gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.option_check()
  if gHLbNyxBrlQOoaYjquVSmDUkAWwKeE is gHLbNyxBrlQOoaYjquVSmDUkAWwKRd:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.dp_Main_List()
  elif gHLbNyxBrlQOoaYjquVSmDUkAWwKeE=='TOTAL_SEARCH':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.dp_Search_Group(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.main_params)
  elif gHLbNyxBrlQOoaYjquVSmDUkAWwKeE=='HYPER_LINK':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.dp_Hyper_Link(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.main_params)
  elif gHLbNyxBrlQOoaYjquVSmDUkAWwKeE=='NF_SEARCH':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.dp_Nf_Search(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.main_params)
  elif gHLbNyxBrlQOoaYjquVSmDUkAWwKeE=='TOTAL_HISTORY':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.dp_Search_History(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.main_params)
  elif gHLbNyxBrlQOoaYjquVSmDUkAWwKeE=='HISTORY_REMOVE':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.dp_History_Delete(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.main_params)
  elif gHLbNyxBrlQOoaYjquVSmDUkAWwKeE=='MENU_BOOKMARK':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.dp_Bookmark_Menu(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.main_params)
  elif gHLbNyxBrlQOoaYjquVSmDUkAWwKeE=='SET_BOOKMARK':
   gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.dp_Set_Bookmark(gHLbNyxBrlQOoaYjquVSmDUkAWwKpF.main_params)
  else:
   gHLbNyxBrlQOoaYjquVSmDUkAWwKRd
# Created by pyminifier (https://github.com/liftoff/pyminifier)
