__author__="NightRain"
LaqgmVDwkXNIfurnWOpAYjyEJeBHRb=object
LaqgmVDwkXNIfurnWOpAYjyEJeBHRd=None
LaqgmVDwkXNIfurnWOpAYjyEJeBHRi=False
LaqgmVDwkXNIfurnWOpAYjyEJeBHRK=print
LaqgmVDwkXNIfurnWOpAYjyEJeBHRx=str
LaqgmVDwkXNIfurnWOpAYjyEJeBHRT=int
LaqgmVDwkXNIfurnWOpAYjyEJeBHRc=Exception
LaqgmVDwkXNIfurnWOpAYjyEJeBHRt=True
LaqgmVDwkXNIfurnWOpAYjyEJeBHsv=open
LaqgmVDwkXNIfurnWOpAYjyEJeBHsS=isinstance
LaqgmVDwkXNIfurnWOpAYjyEJeBHsz=list
LaqgmVDwkXNIfurnWOpAYjyEJeBHsP=dict
LaqgmVDwkXNIfurnWOpAYjyEJeBHsR=range
LaqgmVDwkXNIfurnWOpAYjyEJeBHsF=len
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class LaqgmVDwkXNIfurnWOpAYjyEJeBHvS(LaqgmVDwkXNIfurnWOpAYjyEJeBHRb):
 def __init__(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.DEFAULT_HEADER ={'user-agent':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.USER_AGENT}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_WAVVE ='https://apis.wavve.com'
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_TVING_SEARCH='https://search.tving.com'
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_TVING_IMG ='https://image.tving.com'
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_WATCHA ='https://api-mars.watcha.com'
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX ='https://www.netflix.com'
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.WAVVE_LIMIT =20 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.TVING_LIMIT =30
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.WATCHA_LIMIT =30
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_LIMIT =20 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.DERECTOR_LIMIT =4
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.CAST_LIMIT =10
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.GENRE_LIMIT =4
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.TVING_MOVIE_LITE=['2610061','2610161','261062']
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.WAVVE_PARAMS ={'APIKEY':'E5F3E0D30947AA5440556471321BB6D9','CREDENTIAL':'none','DEVICE':'pc','DRM':'wm','PARTNER':'pooq','POOQZONE':'none','REGION':'kor','TARGETAGE':'all',}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.TVING_PARMAS ={'NETWORKCODE':'CSND0900','OSCODE':'CSOD0900','SCREENCODE':'CSSD0100',}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.WATCHA_HEADER ={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0',}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_HEADER={'user-agent':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.USER_AGENT,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','accept-encoding':'gzip, deflate, br','accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7','cache-control':'no-cache','pragma':'no-cache','upgrade-insecure-requests':'1',}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND1 ='_342x192'
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND2 ='_665x375'
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_PORT ='_342x684'
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LOGO ='_550x124'
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF={}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']={}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']={}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.Init_NF_Cookies()
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.Init_NF_Session()
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_COOKIES1 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_COOKIES2 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_COOKIES3 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_COOKIES4 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_FULLTEXT1 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_FULLTEXT2 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_FULLTEXT3 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_FULLTEXT4 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_CONTEXTJSON_FILE1 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_CONTEXTJSON_FILE2 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_CONTEXTJSON_FILE3 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_CONTEXTJSON_FILE4 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_FALCORJSON_FILE1 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_FALCORJSON_FILE2 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_FALCORJSON_FILE3 =''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_FALCORJSON_FILE4 =''
 def callRequestCookies(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,jobtype,LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,redirects=LaqgmVDwkXNIfurnWOpAYjyEJeBHRi):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvP=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.DEFAULT_HEADER
  if headers:LaqgmVDwkXNIfurnWOpAYjyEJeBHvP.update(headers)
  if jobtype=='Get':
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvR=requests.get(LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,params=params,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHvP,cookies=cookies,allow_redirects=redirects)
  else:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvR=requests.post(LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,data=payload,params=params,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHvP,cookies=cookies,allow_redirects=redirects)
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHvR
 def callRequestCookies_NF(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,jobtype,LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,redirects=LaqgmVDwkXNIfurnWOpAYjyEJeBHRi,addCookie=''):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvP=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_HEADER
  if headers:LaqgmVDwkXNIfurnWOpAYjyEJeBHvP.update(headers)
  if jobtype=='Get':
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvR=requests.get(LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,params=params,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHvP,cookies=cookies,allow_redirects=redirects)
  else:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvR=requests.post(LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,data=payload,params=params,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHvP,cookies=cookies,allow_redirects=redirects)
  LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHvR.status_code)+' - '+LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHvR.url))
  '''
  print(res.url )
  print(res.status_code )
  print(res.cookies )
  print(res.text )
  '''  
  try:
   if addCookie=='baseurl':
    if 'location' in LaqgmVDwkXNIfurnWOpAYjyEJeBHvR.headers:
     LaqgmVDwkXNIfurnWOpAYjyEJeBHvs=urllib.parse.urlsplit(LaqgmVDwkXNIfurnWOpAYjyEJeBHvR.headers.get('location')).path
     LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['contryurl']=LaqgmVDwkXNIfurnWOpAYjyEJeBHvs[1:3]
  except:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRd
  for LaqgmVDwkXNIfurnWOpAYjyEJeBHvF in LaqgmVDwkXNIfurnWOpAYjyEJeBHvR.cookies:
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.name=='flwssn':
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['flwssn']['value'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.value
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['flwssn']['expires'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.expires
   elif LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.name=='nfvdid':
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['nfvdid']['value'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.value
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['nfvdid']['expires'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.expires
   elif LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.name=='SecureNetflixId':
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['SecureNetflixId']['value'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.value
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['SecureNetflixId']['expires'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.expires
   elif LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.name=='NetflixId':
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['NetflixId']['value'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.value
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['NetflixId']['expires'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.expires
   elif LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.name=='memclid':
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['memclid']['value'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.value
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['memclid']['expires'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.expires
   elif LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.name=='clSharedContext':
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['clSharedContext']['value'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvF.value
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['clSharedContext']['expires'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.GetNoCache(timetype=1,minutes=5)
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHvR
 def GetNoCache(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,timetype=1,minutes=0):
  if timetype==1:
   ts=LaqgmVDwkXNIfurnWOpAYjyEJeBHRT(time.time())
   mi=LaqgmVDwkXNIfurnWOpAYjyEJeBHRT(minutes*60)
  else:
   ts=LaqgmVDwkXNIfurnWOpAYjyEJeBHRT(time.time()*1000)
   mi=LaqgmVDwkXNIfurnWOpAYjyEJeBHRT(minutes*60*1000)
  if minutes!=0:
   ts+=mi
  return ts
 def Get_Now_Datetime(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Search_Wavve(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,search_key,sType,page_int):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvG=[]
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvM=LaqgmVDwkXNIfurnWOpAYjyEJeBHSz=1
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvl=LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_WAVVE+'/cf/search/list.js'
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvh={'type':'program' if sType=='TVSHOW' else 'movie','keyword':search_key,'offset':LaqgmVDwkXNIfurnWOpAYjyEJeBHRx((page_int-1)*LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.WAVVE_LIMIT),'limit':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.WAVVE_LIMIT,'orderby':'score'}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvh.update(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.WAVVE_PARAMS)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.callRequestCookies('Get',LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHvh,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvQ=json.loads(LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.text)
   if not('celllist' in LaqgmVDwkXNIfurnWOpAYjyEJeBHvQ['cell_toplist']):return LaqgmVDwkXNIfurnWOpAYjyEJeBHvG,LaqgmVDwkXNIfurnWOpAYjyEJeBHvl
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvb=LaqgmVDwkXNIfurnWOpAYjyEJeBHvQ['cell_toplist']['celllist']
   for LaqgmVDwkXNIfurnWOpAYjyEJeBHvd in LaqgmVDwkXNIfurnWOpAYjyEJeBHvb:
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvi =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['event_list'][1]['url']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvK=urllib.parse.urlsplit(LaqgmVDwkXNIfurnWOpAYjyEJeBHvi).query
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvx=LaqgmVDwkXNIfurnWOpAYjyEJeBHvK[0:LaqgmVDwkXNIfurnWOpAYjyEJeBHvK.find('=')]
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvT=LaqgmVDwkXNIfurnWOpAYjyEJeBHvK[LaqgmVDwkXNIfurnWOpAYjyEJeBHvK.find('=')+1:]
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvx='TVSHOW' if LaqgmVDwkXNIfurnWOpAYjyEJeBHvx=='programid' else 'MOVIE' 
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvc=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['title_list'][0]['text']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvt =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['age']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSv={'title':LaqgmVDwkXNIfurnWOpAYjyEJeBHvc}
    if LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('age')!='21':
     LaqgmVDwkXNIfurnWOpAYjyEJeBHvG.append(LaqgmVDwkXNIfurnWOpAYjyEJeBHSv)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvM=LaqgmVDwkXNIfurnWOpAYjyEJeBHRT(LaqgmVDwkXNIfurnWOpAYjyEJeBHvQ['cell_toplist']['pagecount'])
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHvQ['cell_toplist']['count']:LaqgmVDwkXNIfurnWOpAYjyEJeBHSz =LaqgmVDwkXNIfurnWOpAYjyEJeBHRT(LaqgmVDwkXNIfurnWOpAYjyEJeBHvQ['cell_toplist']['count'])
   else:LaqgmVDwkXNIfurnWOpAYjyEJeBHSz=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.LIST_LIMIT
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvl=LaqgmVDwkXNIfurnWOpAYjyEJeBHvM>LaqgmVDwkXNIfurnWOpAYjyEJeBHSz
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHvG,LaqgmVDwkXNIfurnWOpAYjyEJeBHvl 
 def Get_Search_Tving(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,search_key,sType,page_int):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvG=[]
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvl=LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHSP ='/search/getSearch.jsp'
   LaqgmVDwkXNIfurnWOpAYjyEJeBHSR={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if sType=='TVSHOW' else 'VODMV','pageNum':LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(page_int),'pageSize':LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.TVING_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.TVING_PARMAS.get('SCREENCODE'),'os':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.TVING_PARMAS.get('OSCODE'),'network':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.TVING_PARMAS.get('NETWORKCODE'),'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.TVING_LIMIT)if sType=='TVSHOW' else '','vodMVReqCnt':LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.TVING_LIMIT)if sType=='MOVIE' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.GetNoCache(2))}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_TVING_SEARCH+LaqgmVDwkXNIfurnWOpAYjyEJeBHSP
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.callRequestCookies('Get',LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHSR,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHSs=json.loads(LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.text)
   if sType=='TVSHOW':
    if not('programRsb' in LaqgmVDwkXNIfurnWOpAYjyEJeBHSs):return LaqgmVDwkXNIfurnWOpAYjyEJeBHvG,LaqgmVDwkXNIfurnWOpAYjyEJeBHvl
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSF=LaqgmVDwkXNIfurnWOpAYjyEJeBHSs['programRsb']['dataList']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSo =LaqgmVDwkXNIfurnWOpAYjyEJeBHRT(LaqgmVDwkXNIfurnWOpAYjyEJeBHSs['programRsb']['count'])
    for LaqgmVDwkXNIfurnWOpAYjyEJeBHvd in LaqgmVDwkXNIfurnWOpAYjyEJeBHSF:
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSG=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['mast_cd']
     LaqgmVDwkXNIfurnWOpAYjyEJeBHvc =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['mast_nm']
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSM=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_TVING_IMG+LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['web_url4']
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSl =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_TVING_IMG+LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['web_url']
     try:
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSU =[]
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSh=[]
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSC =[]
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSQ =0
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSb =''
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSd =''
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSi =''
      if LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('actor') !='' and LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('actor') !='-':LaqgmVDwkXNIfurnWOpAYjyEJeBHSU =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('actor').split(',')
      if LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('director')!='' and LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('director')!='-':LaqgmVDwkXNIfurnWOpAYjyEJeBHSh=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('director').split(',')
      if LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('cate_nm')!='' and LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('cate_nm')!='-':LaqgmVDwkXNIfurnWOpAYjyEJeBHSC =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('cate_nm').split('/')
      if 'targetage' in LaqgmVDwkXNIfurnWOpAYjyEJeBHvd:LaqgmVDwkXNIfurnWOpAYjyEJeBHSb=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('targetage')
      if 'broad_dt' in LaqgmVDwkXNIfurnWOpAYjyEJeBHvd:
       LaqgmVDwkXNIfurnWOpAYjyEJeBHSK=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('broad_dt')
       LaqgmVDwkXNIfurnWOpAYjyEJeBHSi='%s-%s-%s'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHSK[:4],LaqgmVDwkXNIfurnWOpAYjyEJeBHSK[4:6],LaqgmVDwkXNIfurnWOpAYjyEJeBHSK[6:])
       LaqgmVDwkXNIfurnWOpAYjyEJeBHSd =LaqgmVDwkXNIfurnWOpAYjyEJeBHSK[:4]
     except:
      LaqgmVDwkXNIfurnWOpAYjyEJeBHRd
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSv={'title':LaqgmVDwkXNIfurnWOpAYjyEJeBHvc,}
     LaqgmVDwkXNIfurnWOpAYjyEJeBHvG.append(LaqgmVDwkXNIfurnWOpAYjyEJeBHSv)
   else:
    if not('vodMVRsb' in LaqgmVDwkXNIfurnWOpAYjyEJeBHSs):return LaqgmVDwkXNIfurnWOpAYjyEJeBHvG,LaqgmVDwkXNIfurnWOpAYjyEJeBHvl
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSx=LaqgmVDwkXNIfurnWOpAYjyEJeBHSs['vodMVRsb']['dataList']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSo =LaqgmVDwkXNIfurnWOpAYjyEJeBHRT(LaqgmVDwkXNIfurnWOpAYjyEJeBHSs['vodMVRsb']['count'])
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(LaqgmVDwkXNIfurnWOpAYjyEJeBHSo)
    for LaqgmVDwkXNIfurnWOpAYjyEJeBHvd in LaqgmVDwkXNIfurnWOpAYjyEJeBHSx:
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSG=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['mast_cd']
     LaqgmVDwkXNIfurnWOpAYjyEJeBHvc =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['mast_nm'].strip()
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSM =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_TVING_IMG+LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['web_url']
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSl =LaqgmVDwkXNIfurnWOpAYjyEJeBHSM
     LaqgmVDwkXNIfurnWOpAYjyEJeBHST=''
     try:
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSU =[]
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSh=[]
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSC =[]
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSQ =0
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSb =''
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSd =''
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSi =''
      if LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('actor') !='' and LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('actor') !='-':LaqgmVDwkXNIfurnWOpAYjyEJeBHSU =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('actor').split(',')
      if LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('director')!='' and LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('director')!='-':LaqgmVDwkXNIfurnWOpAYjyEJeBHSh=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('director').split(',')
      if LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('cate_nm')!='' and LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('cate_nm')!='-':LaqgmVDwkXNIfurnWOpAYjyEJeBHSC =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('cate_nm').split('/')
      if LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('runtime_sec')!='':LaqgmVDwkXNIfurnWOpAYjyEJeBHSQ=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('runtime_sec')
      if 'grade_nm' in LaqgmVDwkXNIfurnWOpAYjyEJeBHvd:LaqgmVDwkXNIfurnWOpAYjyEJeBHSb=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('grade_nm')
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSK=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('broad_dt')
      if data_str!='':
       LaqgmVDwkXNIfurnWOpAYjyEJeBHSi='%s-%s-%s'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHSK[:4],LaqgmVDwkXNIfurnWOpAYjyEJeBHSK[4:6],LaqgmVDwkXNIfurnWOpAYjyEJeBHSK[6:])
       LaqgmVDwkXNIfurnWOpAYjyEJeBHSd =LaqgmVDwkXNIfurnWOpAYjyEJeBHSK[:4]
     except:
      LaqgmVDwkXNIfurnWOpAYjyEJeBHRd
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSv={'title':LaqgmVDwkXNIfurnWOpAYjyEJeBHvc,}
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSc=LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
     for LaqgmVDwkXNIfurnWOpAYjyEJeBHSt in LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['bill']:
      if LaqgmVDwkXNIfurnWOpAYjyEJeBHSt in LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.TVING_MOVIE_LITE:
       LaqgmVDwkXNIfurnWOpAYjyEJeBHSc=LaqgmVDwkXNIfurnWOpAYjyEJeBHRt
       break
     if LaqgmVDwkXNIfurnWOpAYjyEJeBHSc==LaqgmVDwkXNIfurnWOpAYjyEJeBHRi: 
      LaqgmVDwkXNIfurnWOpAYjyEJeBHSv['title']=LaqgmVDwkXNIfurnWOpAYjyEJeBHSv['title']+' [개별구매]'
     LaqgmVDwkXNIfurnWOpAYjyEJeBHvG.append(LaqgmVDwkXNIfurnWOpAYjyEJeBHSv)
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHSo>(page_int*LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.TVING_LIMIT):LaqgmVDwkXNIfurnWOpAYjyEJeBHvl=LaqgmVDwkXNIfurnWOpAYjyEJeBHRt
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHvG,LaqgmVDwkXNIfurnWOpAYjyEJeBHvl
 def Get_Search_Watcha(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,search_key,page_int):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvG=[]
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvl=LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_WATCHA+'/api/search.json'
   LaqgmVDwkXNIfurnWOpAYjyEJeBHSR={'query':search_key,'page':LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(page_int),'per':LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.WATCHA_LIMIT),'exclude':'limited',}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.callRequestCookies('Get',LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHSR,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.WATCHA_HEADER,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHSs=json.loads(LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.text)
   if not('results' in LaqgmVDwkXNIfurnWOpAYjyEJeBHSs):return LaqgmVDwkXNIfurnWOpAYjyEJeBHvG,LaqgmVDwkXNIfurnWOpAYjyEJeBHvl
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzv=LaqgmVDwkXNIfurnWOpAYjyEJeBHSs['results']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvl=LaqgmVDwkXNIfurnWOpAYjyEJeBHSs['meta']['has_next']
   for LaqgmVDwkXNIfurnWOpAYjyEJeBHvd in LaqgmVDwkXNIfurnWOpAYjyEJeBHzv:
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzS =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['code']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzP=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['content_type']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzR =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['title']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzs =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['story']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSM=LaqgmVDwkXNIfurnWOpAYjyEJeBHSl=LaqgmVDwkXNIfurnWOpAYjyEJeBHRU=''
    if LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('poster') !=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd:LaqgmVDwkXNIfurnWOpAYjyEJeBHSM=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('poster').get('original')
    if LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('stillcut')!=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd:LaqgmVDwkXNIfurnWOpAYjyEJeBHSl =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('stillcut').get('large')
    if LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('thumbnail')!=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd:LaqgmVDwkXNIfurnWOpAYjyEJeBHRU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd.get('thumbnail').get('large')
    if LaqgmVDwkXNIfurnWOpAYjyEJeBHRU=='' :LaqgmVDwkXNIfurnWOpAYjyEJeBHRU=LaqgmVDwkXNIfurnWOpAYjyEJeBHSl
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzF={'thumb':LaqgmVDwkXNIfurnWOpAYjyEJeBHSl,'poster':LaqgmVDwkXNIfurnWOpAYjyEJeBHSM,'fanart':LaqgmVDwkXNIfurnWOpAYjyEJeBHRU}
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSd =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['year']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzo =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['film_rating_code']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzG=LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['film_rating_short']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzM =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['film_rating_long']
    if LaqgmVDwkXNIfurnWOpAYjyEJeBHzP=='movies':
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSQ =LaqgmVDwkXNIfurnWOpAYjyEJeBHvd['duration']
    else:
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSQ ='0'
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSv={'title':LaqgmVDwkXNIfurnWOpAYjyEJeBHzR,}
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvG.append(LaqgmVDwkXNIfurnWOpAYjyEJeBHSv)
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHvG,LaqgmVDwkXNIfurnWOpAYjyEJeBHvl
 def dic_To_jsonfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,filename,dic):
  if filename=='':return
  fp=LaqgmVDwkXNIfurnWOpAYjyEJeBHsv(filename,'w',-1,'utf-8')
  json.dump(dic,fp)
  fp.close()
 def jsonfile_To_dic(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,filename):
  if filename=='':return LaqgmVDwkXNIfurnWOpAYjyEJeBHRd
  try:
   fp=LaqgmVDwkXNIfurnWOpAYjyEJeBHsv(filename,'r',-1,'utf-8')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzl=json.load(fp)
   fp.close()
  except:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzl={}
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHzl
 def tempFileSave(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,filename,resText):
  if filename=='':return
  fp=LaqgmVDwkXNIfurnWOpAYjyEJeBHsv(filename,'w',-1,'utf-8')
  fp.write(resText)
  fp.close()
 def tempFileLoad(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,filename):
  if filename=='':return
  try:
   fp=LaqgmVDwkXNIfurnWOpAYjyEJeBHsv(filename,'r',-1,'utf-8')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzl=fp.read()
   fp.close()
  except:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzl=''
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHzl
 def Init_NF_Total(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF={}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']={}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']={}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.Init_NF_Cookies()
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.Init_NF_Session()
 def Init_NF_Cookies(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['lhpuuidh'] ={'keyname':'','value':'','expires':0}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['lhpuuidhT'] ={'keyname':'','value':'','expires':0}
 def Check_NF_CookieExp(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.GetNoCache(timetype=1,minutes=0)
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['flwssn']['expires'] <=LaqgmVDwkXNIfurnWOpAYjyEJeBHzU:LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['flwssn'] ={'value':'','expires':0}
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['nfvdid']['expires'] <=LaqgmVDwkXNIfurnWOpAYjyEJeBHzU:LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['nfvdid'] ={'value':'','expires':0}
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['SecureNetflixId']['expires']<=LaqgmVDwkXNIfurnWOpAYjyEJeBHzU:LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['SecureNetflixId']={'value':'','expires':0}
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['NetflixId']['expires'] <=LaqgmVDwkXNIfurnWOpAYjyEJeBHzU:LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['NetflixId'] ={'value':'','expires':0}
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['memclid']['expires'] <=LaqgmVDwkXNIfurnWOpAYjyEJeBHzU:LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['memclid'] ={'value':'','expires':0}
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['clSharedContext']['expires']<=LaqgmVDwkXNIfurnWOpAYjyEJeBHzU:LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['clSharedContext']={'value':'','expires':0}
 def Init_NF_Session(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['account'] ={'nfid':'','nfpw':'','nfpfnum':0}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['membershipStatus']='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['esnModel'] ='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['username'] ='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['authURL'] ='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['mainGuid'] ='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['nowGuid'] ='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['abContext'] ='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['identifier'] ='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['contryurl'] ='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['countryCode'] ='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['countryIsoCode'] ='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['loco'] ='' 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['limitdate'] =''
 def make_NF_DefaultCookies(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzh={}
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['flwssn']['value'] :LaqgmVDwkXNIfurnWOpAYjyEJeBHzh['flwssn'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['flwssn']['value']
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['nfvdid']['value'] :LaqgmVDwkXNIfurnWOpAYjyEJeBHzh['nfvdid'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['nfvdid']['value']
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['SecureNetflixId']['value']:LaqgmVDwkXNIfurnWOpAYjyEJeBHzh['SecureNetflixId']=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['SecureNetflixId']['value']
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['NetflixId']['value'] :LaqgmVDwkXNIfurnWOpAYjyEJeBHzh['NetflixId'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['NetflixId']['value']
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['memclid']['value'] :LaqgmVDwkXNIfurnWOpAYjyEJeBHzh['memclid'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['memclid']['value']
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHzh
 def make_NF_XnetflixHeaders(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzC={'x-netflix.browsername':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['abContext']['X-Netflix.browserName'],'x-netflix.browserversion':LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['abContext']['X-Netflix.browserVersion']),'x-netflix.client.request.name':'ui/xhrUnclassified','x-netflix.clienttype':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['abContext']['X-Netflix.clientType'],'x-netflix.esn':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['esnModel'],'x-netflix.esnprefix':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['abContext']['X-Netflix.esnPrefix'],'x-netflix.osfullname':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['abContext']['X-Netflix.osFullName'],'x-netflix.osname':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['abContext']['X-Netflix.osName'],'x-netflix.osversion':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['abContext']['X-Netflix.osVersion'],'x-netflix.request.client.user.guid':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['nowGuid'],'x-netflix.uiversion':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['abContext']['X-Netflix.uiVersion'],}
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHzC
 def make_NF_ApiParams(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvh={'webp':'false','drmSystem':'widevine','isVolatileBillboardsEnabled':'true','routeAPIRequestsThroughFTL':'false','isTop10Supported':'true','categoryCraversEnabled':'true','hasVideoMerchInBob':'false','persoInfoDensity':'false','contextAwareImages':'true','enableMultiLanguageCatalog':'false','falcor_server':'0.1.0','withSize':'true','materialize':'true','original_path':'/shakti/%s/pathEvaluator'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['identifier']),}
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHvh
 def extract_json(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,content,name):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzQ=r'netflix\.{}\s*=\s*(.*?);\s*</script>'
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzb=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzd=re.compile(LaqgmVDwkXNIfurnWOpAYjyEJeBHzQ.format(name),re.DOTALL).findall(content)
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzb=LaqgmVDwkXNIfurnWOpAYjyEJeBHzd[0]
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzi=LaqgmVDwkXNIfurnWOpAYjyEJeBHzb.replace('\\"','\\\\"') 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzi=LaqgmVDwkXNIfurnWOpAYjyEJeBHzi.replace('\\s','\\\\s') 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzi=LaqgmVDwkXNIfurnWOpAYjyEJeBHzi.replace('\\n','\\\\n') 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzi=LaqgmVDwkXNIfurnWOpAYjyEJeBHzi.replace('\\t','\\\\t') 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzi=LaqgmVDwkXNIfurnWOpAYjyEJeBHzi.encode().decode('unicode_escape') 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzi=re.sub(r'\\(?!["])',r'\\\\',LaqgmVDwkXNIfurnWOpAYjyEJeBHzi) 
  return json.loads(LaqgmVDwkXNIfurnWOpAYjyEJeBHzi)
 def Save_session_acount(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,LaqgmVDwkXNIfurnWOpAYjyEJeBHzK,LaqgmVDwkXNIfurnWOpAYjyEJeBHzx,LaqgmVDwkXNIfurnWOpAYjyEJeBHzT):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['account']['nfid'] =base64.standard_b64encode(LaqgmVDwkXNIfurnWOpAYjyEJeBHzK.encode()).decode('utf-8')
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['account']['nfpw'] =base64.standard_b64encode(LaqgmVDwkXNIfurnWOpAYjyEJeBHzx.encode()).decode('utf-8')
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['account']['nfpfnum']=LaqgmVDwkXNIfurnWOpAYjyEJeBHzT
 def Load_session_acount(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzK =base64.standard_b64decode(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['account']['nfid']).decode('utf-8')
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzx =base64.standard_b64decode(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['account']['nfpw']).decode('utf-8')
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzT=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['account']['nfpfnum']
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHzK,LaqgmVDwkXNIfurnWOpAYjyEJeBHzx,LaqgmVDwkXNIfurnWOpAYjyEJeBHzT
 def Get_NF_BaseCookies(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX+'/login' 
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.callRequestCookies_NF('Get',LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,addCookie='baseurl')
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.status_code!=302:
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 1-1 status_code error')
    return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 1-1 error')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX+'/'+LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['contryurl']+'/login' 
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzh=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.make_NF_DefaultCookies()
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.callRequestCookies_NF('Get',LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHzh)
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.status_code!=200:
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 1-2 status_code error')
    return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzc=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.extract_json(LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.text,'reactContext')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.dic_To_jsonfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_CONTEXTJSON_FILE1,LaqgmVDwkXNIfurnWOpAYjyEJeBHzc)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['membershipStatus']=LaqgmVDwkXNIfurnWOpAYjyEJeBHzc['models']['userInfo']['data']['membershipStatus']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['authURL'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHzc['models']['userInfo']['data']['authURL']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['esnModel'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHzc['models']['esnGeneratorModel']['data']['esn']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['abContext'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHzc['models']['abContext']['data']['headers']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzt=LaqgmVDwkXNIfurnWOpAYjyEJeBHzc['models']['loginContext']['data']['geo']['requestCountry']['id']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPv ='+82' 
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPS =LaqgmVDwkXNIfurnWOpAYjyEJeBHzc['models']['countryCodes']['data']['codes']
   for LaqgmVDwkXNIfurnWOpAYjyEJeBHPz in LaqgmVDwkXNIfurnWOpAYjyEJeBHPS:
    if LaqgmVDwkXNIfurnWOpAYjyEJeBHPz['id']==LaqgmVDwkXNIfurnWOpAYjyEJeBHzt:
     LaqgmVDwkXNIfurnWOpAYjyEJeBHPv='+'+LaqgmVDwkXNIfurnWOpAYjyEJeBHPz['code']
     break
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['countryCode'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHPv 
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['countryIsoCode']=LaqgmVDwkXNIfurnWOpAYjyEJeBHzt 
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.dic_To_jsonfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_COOKIES1,LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF)
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 1-2 error')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHRt
 def Get_NF_BaseLogin(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,user_id,user_pw,user_pfnum):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.Save_session_acount(user_id,user_pw,user_pfnum)
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX+'/'+LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['contryurl']+'/login' 
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPR={'userLoginId':user_id,'password':user_pw,'rememberMe':'true','flow':'websiteSignUp','mode':'login','action':'loginAction','withFields':'rememberMe,nextPage,userLoginId,password,countryCode,countryIsoCode','authURL':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['authURL'],'nextPage':'','showPassword':'','countryCode':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['countryCode'],'countryIsoCode':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['countryIsoCode'],}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzC={'referer':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX+'/'+LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['contryurl']+'/login'}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzh=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.make_NF_DefaultCookies()
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.callRequestCookies_NF('Post',LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHPR,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHzC,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHzh)
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.status_code!=302:
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 2-1 status_code error')
    return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 2-1 error')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX+'/'+LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['contryurl']+'/' 
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzC={'referer':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX+'/'+LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['contryurl']+'/login'}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzh=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.make_NF_DefaultCookies()
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.callRequestCookies_NF('Get',LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHzC,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHzh)
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.status_code!=302:
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 2-2 status_code error')
    return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 2-2 error')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX+'/browse' 
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzC={'referer':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX+'/'+LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['contryurl']+'/login'}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzh=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.make_NF_DefaultCookies()
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzh['clSharedContext']=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['clSharedContext']['value']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.callRequestCookies_NF('Get',LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHzC,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHzh)
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.status_code!=200:
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 2-3 status_code error')
    return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPs=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.extract_json(LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.text,'reactContext')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.dic_To_jsonfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_CONTEXTJSON_FILE2,LaqgmVDwkXNIfurnWOpAYjyEJeBHPs)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPF=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.extract_json(LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.text,'falcorCache')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.dic_To_jsonfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_FALCORJSON_FILE2,LaqgmVDwkXNIfurnWOpAYjyEJeBHPF)
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 2-3 error')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPo=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.Get_NF_LoginData(LaqgmVDwkXNIfurnWOpAYjyEJeBHPs,LaqgmVDwkXNIfurnWOpAYjyEJeBHPF,user_pfnum)
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHPo==LaqgmVDwkXNIfurnWOpAYjyEJeBHRi:
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi 
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHRt
 def Get_NF_LoginData(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,LaqgmVDwkXNIfurnWOpAYjyEJeBHPs,LaqgmVDwkXNIfurnWOpAYjyEJeBHPF,user_pfnum):
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['membershipStatus']=LaqgmVDwkXNIfurnWOpAYjyEJeBHPs['models']['userInfo']['data']['membershipStatus']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['username'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHPs['models']['userInfo']['data']['name']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['authURL'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHPs['models']['userInfo']['data']['authURL'] 
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['mainGuid'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHPs['models']['userInfo']['data']['guid'] 
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['nowGuid'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHPs['models']['userInfo']['data']['userGuid']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['esnModel'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHPs['models']['esnGeneratorModel']['data']['esn']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['abContext'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHPs['models']['abContext']['data']['headers']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['identifier'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHPs['models']['serverDefs']['data']['BUILD_IDENTIFIER']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['nowGuid'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHPF['profilesList'][LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(user_pfnum)]['value'][1]
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.dic_To_jsonfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_COOKIES2,LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF)
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 2-3-sub error')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHRt
 def Get_NF_ActivateProfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvU='%s/api/shakti/%s/profiles/switch'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX,LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['identifier'])
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvh={'switchProfileGuid':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['nowGuid'],'authURL':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['authURL'],'_':LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.GetNoCache(timetype=2,minutes=0)),}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzC={'referer':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX+'/browse','accept':'*/*','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPG=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.make_NF_XnetflixHeaders()
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPG['x-netflix.request.client.user.guid']=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['mainGuid']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzC.update(LaqgmVDwkXNIfurnWOpAYjyEJeBHPG)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzh=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.make_NF_DefaultCookies()
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzh['clSharedContext']=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['clSharedContext']['value']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.callRequestCookies_NF('Get',LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHvh,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHzC,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHzh)
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.status_code!=200:
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 3 status_code error')
    return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.dic_To_jsonfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_COOKIES2,LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF)
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 3 error')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHRt
 def Get_NF_BrowseMain(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz):
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX+'/browse' 
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzC={'referer':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX+'/browse','sec-fetch-dest':'document','sec-fetch-mode':'navigate','sec-fetch-site':'same-origin','sec-fetch-user':'?1',}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzh=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.make_NF_DefaultCookies()
   LaqgmVDwkXNIfurnWOpAYjyEJeBHzh['clSharedContext']=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['clSharedContext']['value']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.callRequestCookies_NF('Get',LaqgmVDwkXNIfurnWOpAYjyEJeBHvU,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHRd,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHzC,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHzh,addCookie='lhpuuidh')
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.status_code!=200:
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 4-main status_code error')
    return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPs=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.extract_json(LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.text,'reactContext')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.dic_To_jsonfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_CONTEXTJSON_FILE3,LaqgmVDwkXNIfurnWOpAYjyEJeBHPs)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPF=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.extract_json(LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.text,'falcorCache')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.dic_To_jsonfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_FALCORJSON_FILE3,LaqgmVDwkXNIfurnWOpAYjyEJeBHPF)
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 4-main error')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPo=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.Get_NF_BrowseSub(LaqgmVDwkXNIfurnWOpAYjyEJeBHPs,LaqgmVDwkXNIfurnWOpAYjyEJeBHPF)
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHPo==LaqgmVDwkXNIfurnWOpAYjyEJeBHRi:
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi 
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHRt
 def Get_NF_BrowseSub(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,LaqgmVDwkXNIfurnWOpAYjyEJeBHPs,LaqgmVDwkXNIfurnWOpAYjyEJeBHPF):
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPM =LaqgmVDwkXNIfurnWOpAYjyEJeBHPF['loco']['value'][1]
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPl=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.GetNoCache(timetype=2,minutes=180)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['loco'] =LaqgmVDwkXNIfurnWOpAYjyEJeBHPM
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['lhpuuidh']={'keyname':'lhpuuidh-browse-%s'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['nowGuid']),'value':'%s%s'%('KR%3AKO-KR%3A',LaqgmVDwkXNIfurnWOpAYjyEJeBHPM),'expires':LaqgmVDwkXNIfurnWOpAYjyEJeBHRT(LaqgmVDwkXNIfurnWOpAYjyEJeBHPl/1000)}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['lhpuuidhT']={'keyname':'lhpuuidh-browse-%s-T'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['nowGuid']),'value':LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHPl),'expires':LaqgmVDwkXNIfurnWOpAYjyEJeBHRT(LaqgmVDwkXNIfurnWOpAYjyEJeBHPl/1000)}
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.dic_To_jsonfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_SESSION_COOKIES3,LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF)
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK('pass 4-sub error')
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHRt
 def NF_makestr_paths(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,paths):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzl=[]
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHsS(paths,LaqgmVDwkXNIfurnWOpAYjyEJeBHRT):
   return '%d'%(paths)
  elif LaqgmVDwkXNIfurnWOpAYjyEJeBHsS(paths,LaqgmVDwkXNIfurnWOpAYjyEJeBHRx):
   return '"%s"'%(paths)
  for LaqgmVDwkXNIfurnWOpAYjyEJeBHPU in paths:
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHsS(LaqgmVDwkXNIfurnWOpAYjyEJeBHPU,LaqgmVDwkXNIfurnWOpAYjyEJeBHRT):
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzl.append('%d'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHPU))
   elif LaqgmVDwkXNIfurnWOpAYjyEJeBHsS(LaqgmVDwkXNIfurnWOpAYjyEJeBHPU,LaqgmVDwkXNIfurnWOpAYjyEJeBHRx):
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzl.append('"%s"'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHPU))
   elif LaqgmVDwkXNIfurnWOpAYjyEJeBHsS(LaqgmVDwkXNIfurnWOpAYjyEJeBHPU,LaqgmVDwkXNIfurnWOpAYjyEJeBHsz):
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzl.append('[%s]'%(','.join(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_makestr_paths(LaqgmVDwkXNIfurnWOpAYjyEJeBHPU))))
   elif LaqgmVDwkXNIfurnWOpAYjyEJeBHsS(LaqgmVDwkXNIfurnWOpAYjyEJeBHPU,LaqgmVDwkXNIfurnWOpAYjyEJeBHsP):
    LaqgmVDwkXNIfurnWOpAYjyEJeBHPh=''
    for LaqgmVDwkXNIfurnWOpAYjyEJeBHPC,LaqgmVDwkXNIfurnWOpAYjyEJeBHPQ in LaqgmVDwkXNIfurnWOpAYjyEJeBHPU.items():
     LaqgmVDwkXNIfurnWOpAYjyEJeBHPh+='"%s":%s,'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHPC,LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_makestr_paths(LaqgmVDwkXNIfurnWOpAYjyEJeBHPQ))
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzl.append('{%s}'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHPh[:-1]))
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHzl
 def NF_Call_pathapi(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,LaqgmVDwkXNIfurnWOpAYjyEJeBHRv,referer=''):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPb='%s/nq/website/memberapi/%s/pathEvaluator'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX,LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['identifier'])
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPR={'path':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_makestr_paths(LaqgmVDwkXNIfurnWOpAYjyEJeBHRv),'authURL':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['SESSION']['authURL']}
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvh=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.make_NF_ApiParams()
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzC={'accept':'*/*','content-type':'application/x-www-form-urlencoded','origin':LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX,'sec-ch-ua':'"Chromium";v="88", "Google Chrome";v="88", ";Not A Brand";v="99"','sec-ch-ua-mobile':'?0','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin',}
  if referer!='':LaqgmVDwkXNIfurnWOpAYjyEJeBHzC['referer']=referer
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPG=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.make_NF_XnetflixHeaders()
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzC.update(LaqgmVDwkXNIfurnWOpAYjyEJeBHPG)
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzh=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.make_NF_DefaultCookies()
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzh[LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['lhpuuidh']['keyname']]=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['lhpuuidh']['value']
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzh[LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['lhpuuidhT']['keyname']]=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF['COOKIES']['lhpuuidhT']['value']
  LaqgmVDwkXNIfurnWOpAYjyEJeBHzh['profilesNewSession']='0'
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.callRequestCookies('Post',LaqgmVDwkXNIfurnWOpAYjyEJeBHPb,payload=LaqgmVDwkXNIfurnWOpAYjyEJeBHPR,params=LaqgmVDwkXNIfurnWOpAYjyEJeBHvh,headers=LaqgmVDwkXNIfurnWOpAYjyEJeBHzC,cookies=LaqgmVDwkXNIfurnWOpAYjyEJeBHzh)
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHvC
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
   return LaqgmVDwkXNIfurnWOpAYjyEJeBHRd
 def Get_Search_Netflix(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,search_key,page_int,byReference=''):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPd=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.DERECTOR_LIMIT
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPi =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.CAST_LIMIT
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPK =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.GENRE_LIMIT
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPx =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_LIMIT*(page_int-1)
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPT =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_LIMIT*page_int 
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPc="|%s"%(search_key)
  LaqgmVDwkXNIfurnWOpAYjyEJeBHPt ='%s/search?%s'%(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.API_NETFLIX,urllib.parse.urlencode({'q':search_key}))
  if byReference=='-' or page_int==1:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRv=[["search","byTerm",LaqgmVDwkXNIfurnWOpAYjyEJeBHPc,"titles",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_LIMIT,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"summary"],["search","byTerm",LaqgmVDwkXNIfurnWOpAYjyEJeBHPc,"titles",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_LIMIT,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byTerm",LaqgmVDwkXNIfurnWOpAYjyEJeBHPc,"titles",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_LIMIT,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference","boxarts",[LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND2,LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_PORT],"jpg"],["search","byTerm",LaqgmVDwkXNIfurnWOpAYjyEJeBHPc,"titles",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_LIMIT,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference","interestingMoment",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND1,"jpg"],["search","byTerm",LaqgmVDwkXNIfurnWOpAYjyEJeBHPc,"titles",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_LIMIT,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference","storyArt",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND2,"jpg"],["search","byTerm",LaqgmVDwkXNIfurnWOpAYjyEJeBHPc,"titles",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_LIMIT,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference",["cast","creators","directors"],{"from":0,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPd},["id","name"]],["search","byTerm",LaqgmVDwkXNIfurnWOpAYjyEJeBHPc,"titles",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_LIMIT,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference","genres",{"from":0,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPK},["id","name"]],["search","byTerm",LaqgmVDwkXNIfurnWOpAYjyEJeBHPc,"titles",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NETFLIX_LIMIT,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LOGO,"png"],]
  else:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRv=[["search","byReference",byReference,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"summary"],["search","byReference",byReference,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference",["title","summary","regularSynopsis","releaseYear","runtime","maturity","dpSupplementalMessage","sequiturEvidence","availability"]],["search","byReference",byReference,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference","boxarts",[LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND2,LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_PORT],"jpg"],["search","byReference",byReference,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference","interestingMoment",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND1,"jpg"],["search","byReference",byReference,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference","storyArt",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND2,"jpg"],["search","byReference",byReference,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference",["cast","creators","directors"],{"from":0,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPd},["id","name"]],["search","byReference",byReference,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference","genres",{"from":0,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPK},["id","name"]],["search","byReference",byReference,{"from":LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,"to":LaqgmVDwkXNIfurnWOpAYjyEJeBHPT},"reference","artWorkByType","LOGO_BRANDED_HORIZONTAL",LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LOGO,"png"],]
  try:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvC=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_Call_pathapi(LaqgmVDwkXNIfurnWOpAYjyEJeBHRv,LaqgmVDwkXNIfurnWOpAYjyEJeBHPt)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvQ=json.loads(LaqgmVDwkXNIfurnWOpAYjyEJeBHvC.text)
   LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.dic_To_jsonfile(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_CONTEXTJSON_FILE4,LaqgmVDwkXNIfurnWOpAYjyEJeBHvQ)
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
  (LaqgmVDwkXNIfurnWOpAYjyEJeBHvG,LaqgmVDwkXNIfurnWOpAYjyEJeBHvl,byReference)=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.Search_Netflix_Make(LaqgmVDwkXNIfurnWOpAYjyEJeBHvQ)
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHvG,LaqgmVDwkXNIfurnWOpAYjyEJeBHvl,byReference
 def Search_Netflix_Make(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,jsonSource):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvG=[]
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvl =LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  LaqgmVDwkXNIfurnWOpAYjyEJeBHRS=''
  LaqgmVDwkXNIfurnWOpAYjyEJeBHRz=jsonSource.get('paths')[0][1]
  if LaqgmVDwkXNIfurnWOpAYjyEJeBHRz=='byTerm':
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPx =jsonSource['paths'][0][5]['from']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPT =jsonSource['paths'][0][5]['to']
  else:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPx =jsonSource['paths'][0][3]['from']
   LaqgmVDwkXNIfurnWOpAYjyEJeBHPT =jsonSource['paths'][0][3]['to']
  LaqgmVDwkXNIfurnWOpAYjyEJeBHRS=LaqgmVDwkXNIfurnWOpAYjyEJeBHsz(jsonSource.get('jsonGraph').get('search').get('byReference').keys())[0]
  LaqgmVDwkXNIfurnWOpAYjyEJeBHRP=jsonSource.get('jsonGraph').get('search').get('byReference').get(LaqgmVDwkXNIfurnWOpAYjyEJeBHRS)
  LaqgmVDwkXNIfurnWOpAYjyEJeBHRs =jsonSource.get('jsonGraph').get('videos')
  LaqgmVDwkXNIfurnWOpAYjyEJeBHRF=jsonSource.get('jsonGraph').get('person')
  LaqgmVDwkXNIfurnWOpAYjyEJeBHRo=jsonSource.get('jsonGraph').get('genres')
  LaqgmVDwkXNIfurnWOpAYjyEJeBHvl=LaqgmVDwkXNIfurnWOpAYjyEJeBHRt if LaqgmVDwkXNIfurnWOpAYjyEJeBHRP[LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHPT)]['reference']['$type']=='ref' else LaqgmVDwkXNIfurnWOpAYjyEJeBHRi
  for LaqgmVDwkXNIfurnWOpAYjyEJeBHRG in LaqgmVDwkXNIfurnWOpAYjyEJeBHsR(LaqgmVDwkXNIfurnWOpAYjyEJeBHPx,LaqgmVDwkXNIfurnWOpAYjyEJeBHPT):
   if LaqgmVDwkXNIfurnWOpAYjyEJeBHRP[LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHRG)]['reference']['$type']=='ref':
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvT =LaqgmVDwkXNIfurnWOpAYjyEJeBHRP[LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(LaqgmVDwkXNIfurnWOpAYjyEJeBHRG)]['reference']['value'][1]
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRM=LaqgmVDwkXNIfurnWOpAYjyEJeBHRs[LaqgmVDwkXNIfurnWOpAYjyEJeBHvT]
    LaqgmVDwkXNIfurnWOpAYjyEJeBHzR =LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['title']['value']
    if LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['availability']['value']['isPlayable']==LaqgmVDwkXNIfurnWOpAYjyEJeBHRi:
     continue
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvx =LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['summary']['value']['type']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSQ =0 if LaqgmVDwkXNIfurnWOpAYjyEJeBHvx!='movie' else LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['runtime']['value']
    if LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['sequiturEvidence']['value']['value']:
     LaqgmVDwkXNIfurnWOpAYjyEJeBHRl=LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['sequiturEvidence']['value']['value']['text']
    else:
     LaqgmVDwkXNIfurnWOpAYjyEJeBHRl=''
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSM =LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['boxarts'][LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_PORT]['jpg']['value']['url']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRU =LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['boxarts'][LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND2]['jpg']['value']['url']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSl=''
    if 'value' in LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['storyArt'][LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND2]['jpg']:
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSl =LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['storyArt'][LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND2]['jpg']['value']['url']
    if LaqgmVDwkXNIfurnWOpAYjyEJeBHSl=='' and 'value' in LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['interestingMoment'][LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND1]['jpg']:
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSl =LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['interestingMoment'][LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LAND1]['jpg']['value']['url']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHST=''
    if 'value' in LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LOGO]['png']:
     LaqgmVDwkXNIfurnWOpAYjyEJeBHST=LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['artWorkByType']['LOGO_BRANDED_HORIZONTAL'][LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.ART_SIZE_LOGO]['png']['value']['url']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSC =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_Subid_List(LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['genres'])
    for i in LaqgmVDwkXNIfurnWOpAYjyEJeBHsR(LaqgmVDwkXNIfurnWOpAYjyEJeBHsF(LaqgmVDwkXNIfurnWOpAYjyEJeBHSC)):
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSC[i]=LaqgmVDwkXNIfurnWOpAYjyEJeBHRo[LaqgmVDwkXNIfurnWOpAYjyEJeBHSC[i]]['name']['value']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSh=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_Subid_List(LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['directors'])
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRh =LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_Subid_List(LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['creators'])
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSh.extend(LaqgmVDwkXNIfurnWOpAYjyEJeBHRh)
    for i in LaqgmVDwkXNIfurnWOpAYjyEJeBHsR(LaqgmVDwkXNIfurnWOpAYjyEJeBHsF(LaqgmVDwkXNIfurnWOpAYjyEJeBHSh)):
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSh[i]=LaqgmVDwkXNIfurnWOpAYjyEJeBHRF[LaqgmVDwkXNIfurnWOpAYjyEJeBHSh[i]]['name']['value']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSU=LaqgmVDwkXNIfurnWOpAYjyEJeBHvz.NF_Subid_List(LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['cast'])
    for i in LaqgmVDwkXNIfurnWOpAYjyEJeBHsR(LaqgmVDwkXNIfurnWOpAYjyEJeBHsF(LaqgmVDwkXNIfurnWOpAYjyEJeBHSU)):
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSU[i]=LaqgmVDwkXNIfurnWOpAYjyEJeBHRF[LaqgmVDwkXNIfurnWOpAYjyEJeBHSU[i]]['name']['value']
    if 'maturityDescription' in LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['maturity']['value']['rating']:
     LaqgmVDwkXNIfurnWOpAYjyEJeBHSb=LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['maturity']['value']['rating']['maturityDescription']
    LaqgmVDwkXNIfurnWOpAYjyEJeBHSv={'videoid':LaqgmVDwkXNIfurnWOpAYjyEJeBHvT,'vidtype':LaqgmVDwkXNIfurnWOpAYjyEJeBHvx,'title':LaqgmVDwkXNIfurnWOpAYjyEJeBHzR,'mpaa':LaqgmVDwkXNIfurnWOpAYjyEJeBHSb,'regularSynopsis':LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['regularSynopsis']['value'],'dpSupplemental':LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['dpSupplementalMessage']['value'],'sequiturEvidence':LaqgmVDwkXNIfurnWOpAYjyEJeBHRl,'thumbnail':{'poster':LaqgmVDwkXNIfurnWOpAYjyEJeBHSM,'thumb':LaqgmVDwkXNIfurnWOpAYjyEJeBHSl,'fanart':LaqgmVDwkXNIfurnWOpAYjyEJeBHRU,'clearlogo':LaqgmVDwkXNIfurnWOpAYjyEJeBHST},'year':LaqgmVDwkXNIfurnWOpAYjyEJeBHRM['releaseYear']['value'],'duration':LaqgmVDwkXNIfurnWOpAYjyEJeBHSQ,'info_genre':LaqgmVDwkXNIfurnWOpAYjyEJeBHSC,'director':LaqgmVDwkXNIfurnWOpAYjyEJeBHSh,'cast':LaqgmVDwkXNIfurnWOpAYjyEJeBHSU,}
    LaqgmVDwkXNIfurnWOpAYjyEJeBHvG.append(LaqgmVDwkXNIfurnWOpAYjyEJeBHSv)
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHvG,LaqgmVDwkXNIfurnWOpAYjyEJeBHvl,LaqgmVDwkXNIfurnWOpAYjyEJeBHRS
 def NF_Subid_List(LaqgmVDwkXNIfurnWOpAYjyEJeBHvz,subJson):
  LaqgmVDwkXNIfurnWOpAYjyEJeBHRC=[]
  try:
   for i in LaqgmVDwkXNIfurnWOpAYjyEJeBHsR(LaqgmVDwkXNIfurnWOpAYjyEJeBHsF(subJson)):
    if subJson.get(LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(i)).get('$type')!='ref':break
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRQ=subJson.get(LaqgmVDwkXNIfurnWOpAYjyEJeBHRx(i)).get('value')[1]
    LaqgmVDwkXNIfurnWOpAYjyEJeBHRC.append(LaqgmVDwkXNIfurnWOpAYjyEJeBHRQ)
  except LaqgmVDwkXNIfurnWOpAYjyEJeBHRc as exception:
   LaqgmVDwkXNIfurnWOpAYjyEJeBHRK(exception)
  return LaqgmVDwkXNIfurnWOpAYjyEJeBHRC
# Created by pyminifier (https://github.com/liftoff/pyminifier)
