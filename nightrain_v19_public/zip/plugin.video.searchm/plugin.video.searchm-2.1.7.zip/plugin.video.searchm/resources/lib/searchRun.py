__author__="NightRain"
xyXEBipNmAdhHKCswRSgOrVbkJLPjT=object
xyXEBipNmAdhHKCswRSgOrVbkJLPjn=None
xyXEBipNmAdhHKCswRSgOrVbkJLPjz=True
xyXEBipNmAdhHKCswRSgOrVbkJLPjF=False
xyXEBipNmAdhHKCswRSgOrVbkJLPjG=type
xyXEBipNmAdhHKCswRSgOrVbkJLPjc=dict
xyXEBipNmAdhHKCswRSgOrVbkJLPjI=open
xyXEBipNmAdhHKCswRSgOrVbkJLPjl=len
xyXEBipNmAdhHKCswRSgOrVbkJLPjD=Exception
xyXEBipNmAdhHKCswRSgOrVbkJLPjM=int
xyXEBipNmAdhHKCswRSgOrVbkJLPjt=range
xyXEBipNmAdhHKCswRSgOrVbkJLPjo=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
xyXEBipNmAdhHKCswRSgOrVbkJLPYv=[{'title':'통합검색 (웨이브,티빙,왓챠,쿠팡,넷플)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
xyXEBipNmAdhHKCswRSgOrVbkJLPYu={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'-','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'-','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'-','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'-','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'-','ott':'watcha','vidtype':'-','icon':'watcha.png'},'coupang_list':{'title':'쿠팡 (영화,시리즈)','mode':'-','ott':'coupang','vidtype':'-','icon':'coupang.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},'primev_list':{'title':'프라임비디오 (영화,시리즈)','mode':'-','ott':'amazon','vidtype':'-','icon':'primev.png'},'disney_list':{'title':'디즈니플러스 (영화,시리즈)','mode':'-','ott':'disney','vidtype':'-','icon':'disney.jpg'},}
xyXEBipNmAdhHKCswRSgOrVbkJLPYj=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
xyXEBipNmAdhHKCswRSgOrVbkJLPYf =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class xyXEBipNmAdhHKCswRSgOrVbkJLPYU(xyXEBipNmAdhHKCswRSgOrVbkJLPjT):
 def __init__(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,xyXEBipNmAdhHKCswRSgOrVbkJLPYa,xyXEBipNmAdhHKCswRSgOrVbkJLPYe,xyXEBipNmAdhHKCswRSgOrVbkJLPYq):
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ._addon_url =xyXEBipNmAdhHKCswRSgOrVbkJLPYa
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ._addon_handle=xyXEBipNmAdhHKCswRSgOrVbkJLPYe
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.main_params =xyXEBipNmAdhHKCswRSgOrVbkJLPYq
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj =XugjiwnfYRHCUeOhEmWMtQxLsaopqK() 
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.CP_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.coupangm','cp_cookies.json'))
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.PV_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.primevm','pv_cookies.pk'))
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.DZ_ORIGINAL_COOKIE=xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.disneym','dz_cookies.json'))
 def addon_noti(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,sting):
  try:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYT=xbmcgui.Dialog()
   xyXEBipNmAdhHKCswRSgOrVbkJLPYT.notification(__addonname__,sting)
  except:
   xyXEBipNmAdhHKCswRSgOrVbkJLPjn
 def addon_log(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,string):
  try:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYn=string.encode('utf-8','ignore')
  except:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYn='addonException: addon_log'
  xyXEBipNmAdhHKCswRSgOrVbkJLPYz=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,xyXEBipNmAdhHKCswRSgOrVbkJLPYn),level=xyXEBipNmAdhHKCswRSgOrVbkJLPYz)
 def get_keyboard_input(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,xyXEBipNmAdhHKCswRSgOrVbkJLPYM):
  xyXEBipNmAdhHKCswRSgOrVbkJLPYF=xyXEBipNmAdhHKCswRSgOrVbkJLPjn
  kb=xbmc.Keyboard()
  kb.setHeading(xyXEBipNmAdhHKCswRSgOrVbkJLPYM)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   xyXEBipNmAdhHKCswRSgOrVbkJLPYF=kb.getText()
  return xyXEBipNmAdhHKCswRSgOrVbkJLPYF
 def get_settings_menubookmark(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ):
  xyXEBipNmAdhHKCswRSgOrVbkJLPYG=xyXEBipNmAdhHKCswRSgOrVbkJLPjz if __addon__.getSetting('menu_bookmark')=='true' else xyXEBipNmAdhHKCswRSgOrVbkJLPjF
  return(xyXEBipNmAdhHKCswRSgOrVbkJLPYG)
 def get_settings_makebookmark(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ):
  return xyXEBipNmAdhHKCswRSgOrVbkJLPjz if __addon__.getSetting('make_bookmark')=='true' else xyXEBipNmAdhHKCswRSgOrVbkJLPjF
 def get_settings_select_info(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ):
  xyXEBipNmAdhHKCswRSgOrVbkJLPYc=[]
  if __addon__.getSetting('netflixyn')=='true':xyXEBipNmAdhHKCswRSgOrVbkJLPYc.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':xyXEBipNmAdhHKCswRSgOrVbkJLPYc.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':xyXEBipNmAdhHKCswRSgOrVbkJLPYc.append('tving')
  if __addon__.getSetting('watchayn')=='true':xyXEBipNmAdhHKCswRSgOrVbkJLPYc.append('watcha')
  if __addon__.getSetting('coupangyn')=='true':xyXEBipNmAdhHKCswRSgOrVbkJLPYc.append('coupang')
  if __addon__.getSetting('primevyn')=='true':xyXEBipNmAdhHKCswRSgOrVbkJLPYc.append('amazon')
  if __addon__.getSetting('disneyyn')=='true':xyXEBipNmAdhHKCswRSgOrVbkJLPYc.append('disney')
  return xyXEBipNmAdhHKCswRSgOrVbkJLPYc
 def add_dir(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,label,sublabel='',img='',infoLabels=xyXEBipNmAdhHKCswRSgOrVbkJLPjn,isFolder=xyXEBipNmAdhHKCswRSgOrVbkJLPjz,params='',isLink=xyXEBipNmAdhHKCswRSgOrVbkJLPjF,ContextMenu=xyXEBipNmAdhHKCswRSgOrVbkJLPjn,direct_url=xyXEBipNmAdhHKCswRSgOrVbkJLPjn):
  if direct_url:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYI=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   xyXEBipNmAdhHKCswRSgOrVbkJLPYD=json.dumps(params,separators=(',',':'))
   xyXEBipNmAdhHKCswRSgOrVbkJLPYD=base64.standard_b64encode(xyXEBipNmAdhHKCswRSgOrVbkJLPYD.encode()).decode('utf-8')
   xyXEBipNmAdhHKCswRSgOrVbkJLPYD=xyXEBipNmAdhHKCswRSgOrVbkJLPYD.replace('+','%2B')
   xyXEBipNmAdhHKCswRSgOrVbkJLPYI='%s?params=%s'%(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ._addon_url,xyXEBipNmAdhHKCswRSgOrVbkJLPYD)
  if sublabel and sublabel!='-':xyXEBipNmAdhHKCswRSgOrVbkJLPYM='%s < %s >'%(label,sublabel)
  else: xyXEBipNmAdhHKCswRSgOrVbkJLPYM=label
  if not img:img='DefaultFolder.png'
  xyXEBipNmAdhHKCswRSgOrVbkJLPYt=xbmcgui.ListItem(xyXEBipNmAdhHKCswRSgOrVbkJLPYM)
  if xyXEBipNmAdhHKCswRSgOrVbkJLPjG(img)==xyXEBipNmAdhHKCswRSgOrVbkJLPjc:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYt.setArt(img)
  else:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYt.setArt({'thumb':img,'poster':img})
  if infoLabels:xyXEBipNmAdhHKCswRSgOrVbkJLPYt.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYt.setProperty('IsPlayable','true')
  if ContextMenu:xyXEBipNmAdhHKCswRSgOrVbkJLPYt.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ._addon_handle,xyXEBipNmAdhHKCswRSgOrVbkJLPYI,xyXEBipNmAdhHKCswRSgOrVbkJLPYt,isFolder)
 def Load_Searched_List(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ):
  try:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYo=xyXEBipNmAdhHKCswRSgOrVbkJLPYf
   fp=xyXEBipNmAdhHKCswRSgOrVbkJLPjI(xyXEBipNmAdhHKCswRSgOrVbkJLPYo,'r',-1,'utf-8')
   xyXEBipNmAdhHKCswRSgOrVbkJLPUY=fp.readlines()
   fp.close()
  except:
   xyXEBipNmAdhHKCswRSgOrVbkJLPUY=[]
  return xyXEBipNmAdhHKCswRSgOrVbkJLPUY
 def Save_Searched_List(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,xyXEBipNmAdhHKCswRSgOrVbkJLPvF):
  try:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYo=xyXEBipNmAdhHKCswRSgOrVbkJLPYf
   xyXEBipNmAdhHKCswRSgOrVbkJLPUv=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.Load_Searched_List() 
   xyXEBipNmAdhHKCswRSgOrVbkJLPUu={'skey':xyXEBipNmAdhHKCswRSgOrVbkJLPvF.strip()}
   fp=xyXEBipNmAdhHKCswRSgOrVbkJLPjI(xyXEBipNmAdhHKCswRSgOrVbkJLPYo,'w',-1,'utf-8')
   xyXEBipNmAdhHKCswRSgOrVbkJLPUj=urllib.parse.urlencode(xyXEBipNmAdhHKCswRSgOrVbkJLPUu)
   xyXEBipNmAdhHKCswRSgOrVbkJLPUj=xyXEBipNmAdhHKCswRSgOrVbkJLPUj+'\n'
   fp.write(xyXEBipNmAdhHKCswRSgOrVbkJLPUj)
   xyXEBipNmAdhHKCswRSgOrVbkJLPUf=0
   for xyXEBipNmAdhHKCswRSgOrVbkJLPUQ in xyXEBipNmAdhHKCswRSgOrVbkJLPUv:
    xyXEBipNmAdhHKCswRSgOrVbkJLPUa=xyXEBipNmAdhHKCswRSgOrVbkJLPjc(urllib.parse.parse_qsl(xyXEBipNmAdhHKCswRSgOrVbkJLPUQ))
    xyXEBipNmAdhHKCswRSgOrVbkJLPUe=xyXEBipNmAdhHKCswRSgOrVbkJLPUu.get('skey').strip()
    xyXEBipNmAdhHKCswRSgOrVbkJLPUq=xyXEBipNmAdhHKCswRSgOrVbkJLPUa.get('skey').strip()
    if xyXEBipNmAdhHKCswRSgOrVbkJLPUe!=xyXEBipNmAdhHKCswRSgOrVbkJLPUq:
     fp.write(xyXEBipNmAdhHKCswRSgOrVbkJLPUQ)
     xyXEBipNmAdhHKCswRSgOrVbkJLPUf+=1
     if xyXEBipNmAdhHKCswRSgOrVbkJLPUf>=50:break
   fp.close()
  except:
   xyXEBipNmAdhHKCswRSgOrVbkJLPjn
 def dp_Search_History(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,args):
  xyXEBipNmAdhHKCswRSgOrVbkJLPUW=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.Load_Searched_List()
  for xyXEBipNmAdhHKCswRSgOrVbkJLPUT in xyXEBipNmAdhHKCswRSgOrVbkJLPUW:
   xyXEBipNmAdhHKCswRSgOrVbkJLPUn=xyXEBipNmAdhHKCswRSgOrVbkJLPjc(urllib.parse.parse_qsl(xyXEBipNmAdhHKCswRSgOrVbkJLPUT))
   xyXEBipNmAdhHKCswRSgOrVbkJLPUz=xyXEBipNmAdhHKCswRSgOrVbkJLPUn.get('skey').strip()
   xyXEBipNmAdhHKCswRSgOrVbkJLPYl={'mode':'TOTAL_SEARCH','search_key':xyXEBipNmAdhHKCswRSgOrVbkJLPUz,}
   xyXEBipNmAdhHKCswRSgOrVbkJLPUF={'mode':'HISTORY_REMOVE','skey':xyXEBipNmAdhHKCswRSgOrVbkJLPUz,'delmode':'ONE',}
   xyXEBipNmAdhHKCswRSgOrVbkJLPUG=urllib.parse.urlencode(xyXEBipNmAdhHKCswRSgOrVbkJLPUF)
   xyXEBipNmAdhHKCswRSgOrVbkJLPUc=[('선택된 검색어 ( %s ) 삭제'%(xyXEBipNmAdhHKCswRSgOrVbkJLPUz),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(xyXEBipNmAdhHKCswRSgOrVbkJLPUG))]
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.add_dir(xyXEBipNmAdhHKCswRSgOrVbkJLPUz,sublabel='',img=xyXEBipNmAdhHKCswRSgOrVbkJLPjn,infoLabels=xyXEBipNmAdhHKCswRSgOrVbkJLPjn,isFolder=xyXEBipNmAdhHKCswRSgOrVbkJLPjz,params=xyXEBipNmAdhHKCswRSgOrVbkJLPYl,ContextMenu=xyXEBipNmAdhHKCswRSgOrVbkJLPUc)
  xyXEBipNmAdhHKCswRSgOrVbkJLPUl={'plot':'검색목록 전체를 삭제합니다.'}
  xyXEBipNmAdhHKCswRSgOrVbkJLPYM='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  xyXEBipNmAdhHKCswRSgOrVbkJLPYl={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  xyXEBipNmAdhHKCswRSgOrVbkJLPUD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.add_dir(xyXEBipNmAdhHKCswRSgOrVbkJLPYM,sublabel='',img=xyXEBipNmAdhHKCswRSgOrVbkJLPUD,infoLabels=xyXEBipNmAdhHKCswRSgOrVbkJLPUl,isFolder=xyXEBipNmAdhHKCswRSgOrVbkJLPjF,params=xyXEBipNmAdhHKCswRSgOrVbkJLPYl,isLink=xyXEBipNmAdhHKCswRSgOrVbkJLPjz)
  xbmcplugin.endOfDirectory(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ._addon_handle,cacheToDisc=xyXEBipNmAdhHKCswRSgOrVbkJLPjF)
 def Delete_History_List(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,xyXEBipNmAdhHKCswRSgOrVbkJLPUz,xyXEBipNmAdhHKCswRSgOrVbkJLPUo):
  if xyXEBipNmAdhHKCswRSgOrVbkJLPUo=='ALL':
   try:
    xyXEBipNmAdhHKCswRSgOrVbkJLPYo=xyXEBipNmAdhHKCswRSgOrVbkJLPYf
    fp=xyXEBipNmAdhHKCswRSgOrVbkJLPjI(xyXEBipNmAdhHKCswRSgOrVbkJLPYo,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    xyXEBipNmAdhHKCswRSgOrVbkJLPjn
  else:
   try:
    xyXEBipNmAdhHKCswRSgOrVbkJLPYo=xyXEBipNmAdhHKCswRSgOrVbkJLPYf
    xyXEBipNmAdhHKCswRSgOrVbkJLPUv=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.Load_Searched_List() 
    fp=xyXEBipNmAdhHKCswRSgOrVbkJLPjI(xyXEBipNmAdhHKCswRSgOrVbkJLPYo,'w',-1,'utf-8')
    for xyXEBipNmAdhHKCswRSgOrVbkJLPUQ in xyXEBipNmAdhHKCswRSgOrVbkJLPUv:
     xyXEBipNmAdhHKCswRSgOrVbkJLPUa=xyXEBipNmAdhHKCswRSgOrVbkJLPjc(urllib.parse.parse_qsl(xyXEBipNmAdhHKCswRSgOrVbkJLPUQ))
     xyXEBipNmAdhHKCswRSgOrVbkJLPUt=xyXEBipNmAdhHKCswRSgOrVbkJLPUa.get('skey').strip()
     if xyXEBipNmAdhHKCswRSgOrVbkJLPUz!=xyXEBipNmAdhHKCswRSgOrVbkJLPUt:
      fp.write(xyXEBipNmAdhHKCswRSgOrVbkJLPUQ)
    fp.close()
   except:
    xyXEBipNmAdhHKCswRSgOrVbkJLPjn
 def dp_History_Delete(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,args):
  xyXEBipNmAdhHKCswRSgOrVbkJLPUz =args.get('skey') 
  xyXEBipNmAdhHKCswRSgOrVbkJLPUo=args.get('delmode')
  xyXEBipNmAdhHKCswRSgOrVbkJLPYT=xbmcgui.Dialog()
  if xyXEBipNmAdhHKCswRSgOrVbkJLPUo=='ALL':
   xyXEBipNmAdhHKCswRSgOrVbkJLPvY=xyXEBipNmAdhHKCswRSgOrVbkJLPYT.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   xyXEBipNmAdhHKCswRSgOrVbkJLPvY=xyXEBipNmAdhHKCswRSgOrVbkJLPYT.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if xyXEBipNmAdhHKCswRSgOrVbkJLPvY==xyXEBipNmAdhHKCswRSgOrVbkJLPjF:sys.exit()
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.Delete_History_List(xyXEBipNmAdhHKCswRSgOrVbkJLPUz,xyXEBipNmAdhHKCswRSgOrVbkJLPUo)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ):
  xyXEBipNmAdhHKCswRSgOrVbkJLPYG=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.get_settings_menubookmark()
  for xyXEBipNmAdhHKCswRSgOrVbkJLPvU in xyXEBipNmAdhHKCswRSgOrVbkJLPYv:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYM=xyXEBipNmAdhHKCswRSgOrVbkJLPvU.get('title')
   xyXEBipNmAdhHKCswRSgOrVbkJLPUD=''
   if xyXEBipNmAdhHKCswRSgOrVbkJLPvU.get('mode')=='MENU_BOOKMARK' and xyXEBipNmAdhHKCswRSgOrVbkJLPYG==xyXEBipNmAdhHKCswRSgOrVbkJLPjF:continue
   xyXEBipNmAdhHKCswRSgOrVbkJLPYl={'mode':xyXEBipNmAdhHKCswRSgOrVbkJLPvU.get('mode')}
   if xyXEBipNmAdhHKCswRSgOrVbkJLPvU.get('mode')in['XXX','MENU_BOOKMARK']:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvu=xyXEBipNmAdhHKCswRSgOrVbkJLPjF
    xyXEBipNmAdhHKCswRSgOrVbkJLPvj =xyXEBipNmAdhHKCswRSgOrVbkJLPjz
   else:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvu=xyXEBipNmAdhHKCswRSgOrVbkJLPjz
    xyXEBipNmAdhHKCswRSgOrVbkJLPvj =xyXEBipNmAdhHKCswRSgOrVbkJLPjF
   if 'icon' in xyXEBipNmAdhHKCswRSgOrVbkJLPvU:xyXEBipNmAdhHKCswRSgOrVbkJLPUD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',xyXEBipNmAdhHKCswRSgOrVbkJLPvU.get('icon')) 
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.add_dir(xyXEBipNmAdhHKCswRSgOrVbkJLPYM,sublabel='',img=xyXEBipNmAdhHKCswRSgOrVbkJLPUD,infoLabels=xyXEBipNmAdhHKCswRSgOrVbkJLPjn,isFolder=xyXEBipNmAdhHKCswRSgOrVbkJLPvu,params=xyXEBipNmAdhHKCswRSgOrVbkJLPYl,isLink=xyXEBipNmAdhHKCswRSgOrVbkJLPvj)
  xbmcplugin.endOfDirectory(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ._addon_handle,cacheToDisc=xyXEBipNmAdhHKCswRSgOrVbkJLPjF)
 def option_check(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ):
  xyXEBipNmAdhHKCswRSgOrVbkJLPYc=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.get_settings_select_info()
  if xyXEBipNmAdhHKCswRSgOrVbkJLPjl(xyXEBipNmAdhHKCswRSgOrVbkJLPYc)==0:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYT=xbmcgui.Dialog()
   xyXEBipNmAdhHKCswRSgOrVbkJLPvY=xyXEBipNmAdhHKCswRSgOrVbkJLPYT.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if xyXEBipNmAdhHKCswRSgOrVbkJLPvY==xyXEBipNmAdhHKCswRSgOrVbkJLPjz:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in xyXEBipNmAdhHKCswRSgOrVbkJLPYc:
   if xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.NF_cookiefile_check()==xyXEBipNmAdhHKCswRSgOrVbkJLPjF:
    xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.NF_login(showMessage=xyXEBipNmAdhHKCswRSgOrVbkJLPjz)
  if 'disney' in xyXEBipNmAdhHKCswRSgOrVbkJLPYc:
   if xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.DZ_cookiefile_check()==xyXEBipNmAdhHKCswRSgOrVbkJLPjF:
    xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.DZ={}
 def DZ_cookiefile_check(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ):
  xyXEBipNmAdhHKCswRSgOrVbkJLPvQ={}
  try: 
   fp=xyXEBipNmAdhHKCswRSgOrVbkJLPjI(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.DZ_ORIGINAL_COOKIE,'r',-1,'utf-8')
   xyXEBipNmAdhHKCswRSgOrVbkJLPvQ= json.load(fp)
   fp.close()
  except xyXEBipNmAdhHKCswRSgOrVbkJLPjD as exception:
   return xyXEBipNmAdhHKCswRSgOrVbkJLPjF
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.DZ=xyXEBipNmAdhHKCswRSgOrVbkJLPvQ
  if xyXEBipNmAdhHKCswRSgOrVbkJLPjM(time.time())>xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.DZ['account']['token_limit']:
   if xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.DZ_ReToken()==xyXEBipNmAdhHKCswRSgOrVbkJLPjF:
    xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_noti(__language__(30920).encode('utf-8'))
    return xyXEBipNmAdhHKCswRSgOrVbkJLPjF
   try: 
    fp=xyXEBipNmAdhHKCswRSgOrVbkJLPjI(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.DZ_ORIGINAL_COOKIE,'w',-1,'utf-8')
    json.dump(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.DZ,fp,indent=4,ensure_ascii=xyXEBipNmAdhHKCswRSgOrVbkJLPjF)
    fp.close()
   except xyXEBipNmAdhHKCswRSgOrVbkJLPjD as exception:
    return xyXEBipNmAdhHKCswRSgOrVbkJLPjF
  return xyXEBipNmAdhHKCswRSgOrVbkJLPjz
 def NF_cookiefile_check(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ):
  xyXEBipNmAdhHKCswRSgOrVbkJLPvQ={}
  try: 
   fp=xyXEBipNmAdhHKCswRSgOrVbkJLPjI(xyXEBipNmAdhHKCswRSgOrVbkJLPYj,'r',-1,'utf-8')
   xyXEBipNmAdhHKCswRSgOrVbkJLPvQ= json.load(fp)
   fp.close()
  except xyXEBipNmAdhHKCswRSgOrVbkJLPjD as exception:
   return xyXEBipNmAdhHKCswRSgOrVbkJLPjF
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF=xyXEBipNmAdhHKCswRSgOrVbkJLPvQ
  xyXEBipNmAdhHKCswRSgOrVbkJLPve=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF_CookieFile_Load(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF_ORIGINAL_COOKIE)
  if(xyXEBipNmAdhHKCswRSgOrVbkJLPve['NetflixId']!=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF['COOKIES']['NetflixId']or xyXEBipNmAdhHKCswRSgOrVbkJLPve['SecureNetflixId']!=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF['COOKIES']['SecureNetflixId']or xyXEBipNmAdhHKCswRSgOrVbkJLPve['flwssn']!=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF['COOKIES']['flwssn']or xyXEBipNmAdhHKCswRSgOrVbkJLPve['memclid']!=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF['COOKIES']['memclid']or xyXEBipNmAdhHKCswRSgOrVbkJLPve['nfvdid']!=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF['COOKIES']['nfvdid']):
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Init_NF_Total()
   if xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.NF_login(showMessage=xyXEBipNmAdhHKCswRSgOrVbkJLPjF)==xyXEBipNmAdhHKCswRSgOrVbkJLPjF:
    return xyXEBipNmAdhHKCswRSgOrVbkJLPjF
  return xyXEBipNmAdhHKCswRSgOrVbkJLPjz
 def NF_login(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,showMessage=xyXEBipNmAdhHKCswRSgOrVbkJLPjz):
  if showMessage:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYT=xbmcgui.Dialog()
   xyXEBipNmAdhHKCswRSgOrVbkJLPvY=xyXEBipNmAdhHKCswRSgOrVbkJLPYT.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if xyXEBipNmAdhHKCswRSgOrVbkJLPvY==xyXEBipNmAdhHKCswRSgOrVbkJLPjF:
    return xyXEBipNmAdhHKCswRSgOrVbkJLPjF 
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF['COOKIES']=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF_CookieFile_Load(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF_ORIGINAL_COOKIE)
  xyXEBipNmAdhHKCswRSgOrVbkJLPvq=xyXEBipNmAdhHKCswRSgOrVbkJLPjF if xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF['COOKIES']=={}else xyXEBipNmAdhHKCswRSgOrVbkJLPjz
  if xyXEBipNmAdhHKCswRSgOrVbkJLPvq:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_log('pass1 ok!')
  else:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_log('pass1 error!')
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_noti(__language__(30905).encode('utf-8'))
   return xyXEBipNmAdhHKCswRSgOrVbkJLPjF 
  xyXEBipNmAdhHKCswRSgOrVbkJLPvq=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF_Get_BaseSession()
  if xyXEBipNmAdhHKCswRSgOrVbkJLPvq:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_log('pass2 ok!')
  else:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_log('pass2 error!')
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_noti(__language__(30905).encode('utf-8'))
   return xyXEBipNmAdhHKCswRSgOrVbkJLPjF 
  xyXEBipNmAdhHKCswRSgOrVbkJLPvW =xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Get_Now_Datetime()
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF['SESSION']['limitdate']=xyXEBipNmAdhHKCswRSgOrVbkJLPvW.strftime('%Y-%m-%d')
  try: 
   fp=xyXEBipNmAdhHKCswRSgOrVbkJLPjI(xyXEBipNmAdhHKCswRSgOrVbkJLPYj,'w',-1,'utf-8')
   json.dump(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF,fp,indent=4,ensure_ascii=xyXEBipNmAdhHKCswRSgOrVbkJLPjF)
   fp.close()
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_log('pass3 save ok!')
  except xyXEBipNmAdhHKCswRSgOrVbkJLPjD as exception:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_log('pass3 save error!')
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_noti(__language__(30905).encode('utf-8'))
   return xyXEBipNmAdhHKCswRSgOrVbkJLPjF
  if showMessage:xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_noti(__language__(30904).encode('utf-8'))
  return xyXEBipNmAdhHKCswRSgOrVbkJLPjz
 def NF_logout(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ):
  xyXEBipNmAdhHKCswRSgOrVbkJLPYT=xbmcgui.Dialog()
  xyXEBipNmAdhHKCswRSgOrVbkJLPvY=xyXEBipNmAdhHKCswRSgOrVbkJLPYT.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if xyXEBipNmAdhHKCswRSgOrVbkJLPvY==xyXEBipNmAdhHKCswRSgOrVbkJLPjF:return 
  if os.path.isfile(xyXEBipNmAdhHKCswRSgOrVbkJLPYj):os.remove(xyXEBipNmAdhHKCswRSgOrVbkJLPYj)
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,xyXEBipNmAdhHKCswRSgOrVbkJLPvG):
  xyXEBipNmAdhHKCswRSgOrVbkJLPvT=''
  xyXEBipNmAdhHKCswRSgOrVbkJLPvn=7
  try:
   for i in xyXEBipNmAdhHKCswRSgOrVbkJLPjt(xyXEBipNmAdhHKCswRSgOrVbkJLPjl(xyXEBipNmAdhHKCswRSgOrVbkJLPvG)):
    if i>=xyXEBipNmAdhHKCswRSgOrVbkJLPvn:
     xyXEBipNmAdhHKCswRSgOrVbkJLPvT=xyXEBipNmAdhHKCswRSgOrVbkJLPvT+'...'
     break
    xyXEBipNmAdhHKCswRSgOrVbkJLPvT=xyXEBipNmAdhHKCswRSgOrVbkJLPvT+xyXEBipNmAdhHKCswRSgOrVbkJLPvG[i]['title']+'\n'
  except:
   return ''
  return xyXEBipNmAdhHKCswRSgOrVbkJLPvT
 def dp_Search_Group(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,args):
  xyXEBipNmAdhHKCswRSgOrVbkJLPYc =xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.get_settings_select_info()
  xyXEBipNmAdhHKCswRSgOrVbkJLPvz=[]
  if 'search_key' in args:
   xyXEBipNmAdhHKCswRSgOrVbkJLPvF=args.get('search_key')
  else:
   xyXEBipNmAdhHKCswRSgOrVbkJLPvF=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not xyXEBipNmAdhHKCswRSgOrVbkJLPvF:
    return
  if 'wavve' in xyXEBipNmAdhHKCswRSgOrVbkJLPYc:
   (xyXEBipNmAdhHKCswRSgOrVbkJLPvG,xyXEBipNmAdhHKCswRSgOrVbkJLPvc)=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Get_Search_Wavve(xyXEBipNmAdhHKCswRSgOrVbkJLPvF,'TVSHOW',1)
   if xyXEBipNmAdhHKCswRSgOrVbkJLPjl(xyXEBipNmAdhHKCswRSgOrVbkJLPvG)>0:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvI={'sType':'wavve_tvshow','sList':xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.MakeText_FreeList(xyXEBipNmAdhHKCswRSgOrVbkJLPvG),}
    xyXEBipNmAdhHKCswRSgOrVbkJLPvz.append(xyXEBipNmAdhHKCswRSgOrVbkJLPvI)
   (xyXEBipNmAdhHKCswRSgOrVbkJLPvG,xyXEBipNmAdhHKCswRSgOrVbkJLPvc)=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Get_Search_Wavve(xyXEBipNmAdhHKCswRSgOrVbkJLPvF,'MOVIE',1)
   if xyXEBipNmAdhHKCswRSgOrVbkJLPjl(xyXEBipNmAdhHKCswRSgOrVbkJLPvG)>0:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvI={'sType':'wavve_movie','sList':xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.MakeText_FreeList(xyXEBipNmAdhHKCswRSgOrVbkJLPvG),}
    xyXEBipNmAdhHKCswRSgOrVbkJLPvz.append(xyXEBipNmAdhHKCswRSgOrVbkJLPvI)
  if 'tving' in xyXEBipNmAdhHKCswRSgOrVbkJLPYc:
   (xyXEBipNmAdhHKCswRSgOrVbkJLPvG,xyXEBipNmAdhHKCswRSgOrVbkJLPvc)=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Get_Search_Tving(xyXEBipNmAdhHKCswRSgOrVbkJLPvF,'TVSHOW',1)
   if xyXEBipNmAdhHKCswRSgOrVbkJLPjl(xyXEBipNmAdhHKCswRSgOrVbkJLPvG)>0:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvI={'sType':'tving_tvshow','sList':xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.MakeText_FreeList(xyXEBipNmAdhHKCswRSgOrVbkJLPvG),}
    xyXEBipNmAdhHKCswRSgOrVbkJLPvz.append(xyXEBipNmAdhHKCswRSgOrVbkJLPvI)
   (xyXEBipNmAdhHKCswRSgOrVbkJLPvG,xyXEBipNmAdhHKCswRSgOrVbkJLPvc)=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Get_Search_Tving(xyXEBipNmAdhHKCswRSgOrVbkJLPvF,'MOVIE',1)
   if xyXEBipNmAdhHKCswRSgOrVbkJLPjl(xyXEBipNmAdhHKCswRSgOrVbkJLPvG)>0:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvI={'sType':'tving_movie','sList':xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.MakeText_FreeList(xyXEBipNmAdhHKCswRSgOrVbkJLPvG),}
    xyXEBipNmAdhHKCswRSgOrVbkJLPvz.append(xyXEBipNmAdhHKCswRSgOrVbkJLPvI)
  if 'watcha' in xyXEBipNmAdhHKCswRSgOrVbkJLPYc:
   (xyXEBipNmAdhHKCswRSgOrVbkJLPvG,xyXEBipNmAdhHKCswRSgOrVbkJLPvc)=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Get_Search_Watcha(xyXEBipNmAdhHKCswRSgOrVbkJLPvF,1)
   if xyXEBipNmAdhHKCswRSgOrVbkJLPjl(xyXEBipNmAdhHKCswRSgOrVbkJLPvG)>0:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvI={'sType':'watcha_list','sList':xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.MakeText_FreeList(xyXEBipNmAdhHKCswRSgOrVbkJLPvG),}
    xyXEBipNmAdhHKCswRSgOrVbkJLPvz.append(xyXEBipNmAdhHKCswRSgOrVbkJLPvI)
  if 'coupang' in xyXEBipNmAdhHKCswRSgOrVbkJLPYc:
   (xyXEBipNmAdhHKCswRSgOrVbkJLPvG,xyXEBipNmAdhHKCswRSgOrVbkJLPvc)=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Get_Search_Coupang(xyXEBipNmAdhHKCswRSgOrVbkJLPvF,1)
   if xyXEBipNmAdhHKCswRSgOrVbkJLPjl(xyXEBipNmAdhHKCswRSgOrVbkJLPvG)>0:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvI={'sType':'coupang_list','sList':xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.MakeText_FreeList(xyXEBipNmAdhHKCswRSgOrVbkJLPvG),}
    xyXEBipNmAdhHKCswRSgOrVbkJLPvz.append(xyXEBipNmAdhHKCswRSgOrVbkJLPvI)
  if 'netflix' in xyXEBipNmAdhHKCswRSgOrVbkJLPYc:
   try:
    (xyXEBipNmAdhHKCswRSgOrVbkJLPvG,xyXEBipNmAdhHKCswRSgOrVbkJLPvc,xyXEBipNmAdhHKCswRSgOrVbkJLPvl)=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Get_Search_Netflix(xyXEBipNmAdhHKCswRSgOrVbkJLPvF,1)
   except:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvG=[]
    xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_noti(__language__(30919).encode('utf8'))
   if xyXEBipNmAdhHKCswRSgOrVbkJLPjl(xyXEBipNmAdhHKCswRSgOrVbkJLPvG)>0:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvI={'sType':'netflix_list','sList':xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.MakeText_FreeList(xyXEBipNmAdhHKCswRSgOrVbkJLPvG),}
    xyXEBipNmAdhHKCswRSgOrVbkJLPvz.append(xyXEBipNmAdhHKCswRSgOrVbkJLPvI)
  if 'amazon' in xyXEBipNmAdhHKCswRSgOrVbkJLPYc:
   (xyXEBipNmAdhHKCswRSgOrVbkJLPvG)=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Get_Search_Primev(xyXEBipNmAdhHKCswRSgOrVbkJLPvF)
   if xyXEBipNmAdhHKCswRSgOrVbkJLPjl(xyXEBipNmAdhHKCswRSgOrVbkJLPvG)>0:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvI={'sType':'primev_list','sList':xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.MakeText_FreeList(xyXEBipNmAdhHKCswRSgOrVbkJLPvG),}
    xyXEBipNmAdhHKCswRSgOrVbkJLPvz.append(xyXEBipNmAdhHKCswRSgOrVbkJLPvI)
  if 'disney' in xyXEBipNmAdhHKCswRSgOrVbkJLPYc:
   try:
    (xyXEBipNmAdhHKCswRSgOrVbkJLPvG)=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Get_Search_Disney(xyXEBipNmAdhHKCswRSgOrVbkJLPvF)
   except:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvG=[]
    xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.addon_noti(__language__(30921).encode('utf8'))
   if xyXEBipNmAdhHKCswRSgOrVbkJLPjl(xyXEBipNmAdhHKCswRSgOrVbkJLPvG)>0:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvI={'sType':'disney_list','sList':xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.MakeText_FreeList(xyXEBipNmAdhHKCswRSgOrVbkJLPvG),}
    xyXEBipNmAdhHKCswRSgOrVbkJLPvz.append(xyXEBipNmAdhHKCswRSgOrVbkJLPvI)
  for xyXEBipNmAdhHKCswRSgOrVbkJLPvD in xyXEBipNmAdhHKCswRSgOrVbkJLPvz:
   xyXEBipNmAdhHKCswRSgOrVbkJLPvM=xyXEBipNmAdhHKCswRSgOrVbkJLPYu[xyXEBipNmAdhHKCswRSgOrVbkJLPvD.get('sType')]
   xyXEBipNmAdhHKCswRSgOrVbkJLPvt={'plot':'검색어 : '+xyXEBipNmAdhHKCswRSgOrVbkJLPvF+'\n\n'+xyXEBipNmAdhHKCswRSgOrVbkJLPvD.get('sList')}
   xyXEBipNmAdhHKCswRSgOrVbkJLPYM=xyXEBipNmAdhHKCswRSgOrVbkJLPvM.get('title')
   xyXEBipNmAdhHKCswRSgOrVbkJLPYl={'mode':xyXEBipNmAdhHKCswRSgOrVbkJLPvM.get('mode'),'ott':xyXEBipNmAdhHKCswRSgOrVbkJLPvM.get('ott'),'vidtype':xyXEBipNmAdhHKCswRSgOrVbkJLPvM.get('vidtype'),'search_key':xyXEBipNmAdhHKCswRSgOrVbkJLPvF}
   if xyXEBipNmAdhHKCswRSgOrVbkJLPvM.get('ott')=='netflix':
    xyXEBipNmAdhHKCswRSgOrVbkJLPvo=''
    xyXEBipNmAdhHKCswRSgOrVbkJLPYl['page'] ='1'
    xyXEBipNmAdhHKCswRSgOrVbkJLPYl['byReference']='-'
   else:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvo=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.make_Hyper_Link(xyXEBipNmAdhHKCswRSgOrVbkJLPYl)
   xyXEBipNmAdhHKCswRSgOrVbkJLPUD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',xyXEBipNmAdhHKCswRSgOrVbkJLPvM.get('icon'))
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.add_dir(xyXEBipNmAdhHKCswRSgOrVbkJLPYM,sublabel='',img=xyXEBipNmAdhHKCswRSgOrVbkJLPUD,infoLabels=xyXEBipNmAdhHKCswRSgOrVbkJLPvt,isFolder=xyXEBipNmAdhHKCswRSgOrVbkJLPjz,params=xyXEBipNmAdhHKCswRSgOrVbkJLPYl,isLink=xyXEBipNmAdhHKCswRSgOrVbkJLPjF,direct_url=xyXEBipNmAdhHKCswRSgOrVbkJLPvo)
  xbmcplugin.endOfDirectory(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ._addon_handle)
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.Save_Searched_List(xyXEBipNmAdhHKCswRSgOrVbkJLPvF)
 def make_Hyper_Link(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,args):
  xyXEBipNmAdhHKCswRSgOrVbkJLPuY =args.get('ott')
  xyXEBipNmAdhHKCswRSgOrVbkJLPuU =args.get('vidtype')
  xyXEBipNmAdhHKCswRSgOrVbkJLPvF=args.get('search_key')
  xyXEBipNmAdhHKCswRSgOrVbkJLPvo='-'
  if xyXEBipNmAdhHKCswRSgOrVbkJLPuY=='wavve':
   xyXEBipNmAdhHKCswRSgOrVbkJLPuv={'mode':'LOCAL_SEARCH','sType':'movie' if xyXEBipNmAdhHKCswRSgOrVbkJLPuU=='MOVIE' else 'vod','search_key':xyXEBipNmAdhHKCswRSgOrVbkJLPvF,'page':'1',}
   xyXEBipNmAdhHKCswRSgOrVbkJLPuj=urllib.parse.urlencode(xyXEBipNmAdhHKCswRSgOrVbkJLPuv)
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo='plugin://plugin.video.wavvem/?'
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo+=xyXEBipNmAdhHKCswRSgOrVbkJLPuj
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPuY=='tving':
   xyXEBipNmAdhHKCswRSgOrVbkJLPuv={'mode':'LOCAL_SEARCH','stype':'movie' if xyXEBipNmAdhHKCswRSgOrVbkJLPuU=='MOVIE' else 'vod','search_key':xyXEBipNmAdhHKCswRSgOrVbkJLPvF,'page':'1',}
   xyXEBipNmAdhHKCswRSgOrVbkJLPuj=urllib.parse.urlencode(xyXEBipNmAdhHKCswRSgOrVbkJLPuv)
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo='plugin://plugin.video.tvingm/?'
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo+=xyXEBipNmAdhHKCswRSgOrVbkJLPuj
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPuY=='watcha':
   xyXEBipNmAdhHKCswRSgOrVbkJLPuv={'mode':'LOCAL_SEARCH','search_key':xyXEBipNmAdhHKCswRSgOrVbkJLPvF,'page':'1',}
   xyXEBipNmAdhHKCswRSgOrVbkJLPuj=urllib.parse.urlencode(xyXEBipNmAdhHKCswRSgOrVbkJLPuv)
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo='plugin://plugin.video.watcham/?'
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo+=xyXEBipNmAdhHKCswRSgOrVbkJLPuj
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPuY=='coupang':
   xyXEBipNmAdhHKCswRSgOrVbkJLPuv={'mode':'LOCAL_SEARCH','search_key':xyXEBipNmAdhHKCswRSgOrVbkJLPvF,'page':'1',}
   xyXEBipNmAdhHKCswRSgOrVbkJLPuj=urllib.parse.urlencode(xyXEBipNmAdhHKCswRSgOrVbkJLPuv)
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo='plugin://plugin.video.coupangm/?'
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo+=xyXEBipNmAdhHKCswRSgOrVbkJLPuj
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPuY=='netflix':
   xyXEBipNmAdhHKCswRSgOrVbkJLPuf=args.get('videoid')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuQ=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.NF['SESSION']['nowGuid']
   if xyXEBipNmAdhHKCswRSgOrVbkJLPuU=='TVSHOW':
    xyXEBipNmAdhHKCswRSgOrVbkJLPvo='plugin://plugin.video.netflix/directory/show/%s/'%(xyXEBipNmAdhHKCswRSgOrVbkJLPuf)
   else:
    xyXEBipNmAdhHKCswRSgOrVbkJLPvo='plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s'%(xyXEBipNmAdhHKCswRSgOrVbkJLPuf,xyXEBipNmAdhHKCswRSgOrVbkJLPuQ)
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPuY=='amazon':
   xyXEBipNmAdhHKCswRSgOrVbkJLPuv={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':xyXEBipNmAdhHKCswRSgOrVbkJLPvF,}}
   xyXEBipNmAdhHKCswRSgOrVbkJLPuj=json.dumps(xyXEBipNmAdhHKCswRSgOrVbkJLPuv,separators=(',',':'))
   xyXEBipNmAdhHKCswRSgOrVbkJLPuj=base64.standard_b64encode(xyXEBipNmAdhHKCswRSgOrVbkJLPuj.encode()).decode('utf-8')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuj=xyXEBipNmAdhHKCswRSgOrVbkJLPuj.replace('+','%2B')
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo='plugin://plugin.video.primevm/?params='
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo+=xyXEBipNmAdhHKCswRSgOrVbkJLPuj
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPuY=='disney':
   xyXEBipNmAdhHKCswRSgOrVbkJLPuv={'mode':'LOCAL_SEARCH_LIST','values':{'search_key':xyXEBipNmAdhHKCswRSgOrVbkJLPvF,}}
   xyXEBipNmAdhHKCswRSgOrVbkJLPuj=json.dumps(xyXEBipNmAdhHKCswRSgOrVbkJLPuv,separators=(',',':'))
   xyXEBipNmAdhHKCswRSgOrVbkJLPuj=base64.standard_b64encode(xyXEBipNmAdhHKCswRSgOrVbkJLPuj.encode()).decode('utf-8')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuj=xyXEBipNmAdhHKCswRSgOrVbkJLPuj.replace('+','%2B')
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo='plugin://plugin.video.disneym/?params='
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo+=xyXEBipNmAdhHKCswRSgOrVbkJLPuj
  return xyXEBipNmAdhHKCswRSgOrVbkJLPvo
 def dp_Nf_Search(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,args):
  xyXEBipNmAdhHKCswRSgOrVbkJLPua =xyXEBipNmAdhHKCswRSgOrVbkJLPjM(args.get('page'))
  xyXEBipNmAdhHKCswRSgOrVbkJLPvF =args.get('search_key')
  xyXEBipNmAdhHKCswRSgOrVbkJLPvl=args.get('byReference')
  (xyXEBipNmAdhHKCswRSgOrVbkJLPvG,xyXEBipNmAdhHKCswRSgOrVbkJLPvc,xyXEBipNmAdhHKCswRSgOrVbkJLPvl)=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.SearchObj.Get_Search_Netflix(xyXEBipNmAdhHKCswRSgOrVbkJLPvF,xyXEBipNmAdhHKCswRSgOrVbkJLPua,byReference=xyXEBipNmAdhHKCswRSgOrVbkJLPvl)
  for xyXEBipNmAdhHKCswRSgOrVbkJLPue in xyXEBipNmAdhHKCswRSgOrVbkJLPvG:
   xyXEBipNmAdhHKCswRSgOrVbkJLPuf =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('videoid')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuU =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('vidtype')
   xyXEBipNmAdhHKCswRSgOrVbkJLPYM =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('title')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuq =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('mpaa')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuW =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('regularSynopsis')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuT =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('dpSupplemental')
   xyXEBipNmAdhHKCswRSgOrVbkJLPun=xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('sequiturEvidence')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuz =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('thumbnail')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuF =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('year')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuG =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('duration')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuc =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('info_genre')
   xyXEBipNmAdhHKCswRSgOrVbkJLPuI =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('director')
   xyXEBipNmAdhHKCswRSgOrVbkJLPul =xyXEBipNmAdhHKCswRSgOrVbkJLPue.get('cast')
   if xyXEBipNmAdhHKCswRSgOrVbkJLPuU=='movie':
    xyXEBipNmAdhHKCswRSgOrVbkJLPUI=' (%s)'%(xyXEBipNmAdhHKCswRSgOrVbkJLPjo(xyXEBipNmAdhHKCswRSgOrVbkJLPuF))
   else:
    xyXEBipNmAdhHKCswRSgOrVbkJLPUI=''
   xyXEBipNmAdhHKCswRSgOrVbkJLPuD=''
   if xyXEBipNmAdhHKCswRSgOrVbkJLPuW:xyXEBipNmAdhHKCswRSgOrVbkJLPuD=xyXEBipNmAdhHKCswRSgOrVbkJLPuD+'\n\n'+xyXEBipNmAdhHKCswRSgOrVbkJLPuW
   if xyXEBipNmAdhHKCswRSgOrVbkJLPuT :xyXEBipNmAdhHKCswRSgOrVbkJLPuD=xyXEBipNmAdhHKCswRSgOrVbkJLPuD+'\n\n'+xyXEBipNmAdhHKCswRSgOrVbkJLPuT
   if xyXEBipNmAdhHKCswRSgOrVbkJLPun:xyXEBipNmAdhHKCswRSgOrVbkJLPuD=xyXEBipNmAdhHKCswRSgOrVbkJLPuD+'\n\n'+xyXEBipNmAdhHKCswRSgOrVbkJLPun
   xyXEBipNmAdhHKCswRSgOrVbkJLPuD=xyXEBipNmAdhHKCswRSgOrVbkJLPuD.strip()
   xyXEBipNmAdhHKCswRSgOrVbkJLPUl={'mediatype':'tvshow' if xyXEBipNmAdhHKCswRSgOrVbkJLPuU=='show' else 'movie','title':xyXEBipNmAdhHKCswRSgOrVbkJLPYM,'mpaa':xyXEBipNmAdhHKCswRSgOrVbkJLPuq,'plot':xyXEBipNmAdhHKCswRSgOrVbkJLPuD,'duration':xyXEBipNmAdhHKCswRSgOrVbkJLPuG,'genre':xyXEBipNmAdhHKCswRSgOrVbkJLPuc,'director':xyXEBipNmAdhHKCswRSgOrVbkJLPuI,'cast':xyXEBipNmAdhHKCswRSgOrVbkJLPul,'year':xyXEBipNmAdhHKCswRSgOrVbkJLPuF,}
   xyXEBipNmAdhHKCswRSgOrVbkJLPYl={'ott':'netflix','vidtype':'TVSHOW' if xyXEBipNmAdhHKCswRSgOrVbkJLPuU=='show' else 'MOVIE','videoid':xyXEBipNmAdhHKCswRSgOrVbkJLPuf,}
   xyXEBipNmAdhHKCswRSgOrVbkJLPvo=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.make_Hyper_Link(xyXEBipNmAdhHKCswRSgOrVbkJLPYl)
   xyXEBipNmAdhHKCswRSgOrVbkJLPvu=xyXEBipNmAdhHKCswRSgOrVbkJLPjz if xyXEBipNmAdhHKCswRSgOrVbkJLPuU=='show' else xyXEBipNmAdhHKCswRSgOrVbkJLPjF
   if xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.get_settings_makebookmark():
    xyXEBipNmAdhHKCswRSgOrVbkJLPuM={'mode':'SET_BOOKMARK','values':{'videoid':xyXEBipNmAdhHKCswRSgOrVbkJLPuf,'vidtype':'tvshow' if xyXEBipNmAdhHKCswRSgOrVbkJLPuU=='show' else 'movie','vtitle':xyXEBipNmAdhHKCswRSgOrVbkJLPYM+xyXEBipNmAdhHKCswRSgOrVbkJLPUI,'vsubtitle':'','vinfo':xyXEBipNmAdhHKCswRSgOrVbkJLPUl,'thumbnail':xyXEBipNmAdhHKCswRSgOrVbkJLPuz,}}
    xyXEBipNmAdhHKCswRSgOrVbkJLPut=json.dumps(xyXEBipNmAdhHKCswRSgOrVbkJLPuM,separators=(',',':'))
    xyXEBipNmAdhHKCswRSgOrVbkJLPut=base64.standard_b64encode(xyXEBipNmAdhHKCswRSgOrVbkJLPut.encode()).decode('utf-8')
    xyXEBipNmAdhHKCswRSgOrVbkJLPut=xyXEBipNmAdhHKCswRSgOrVbkJLPut.replace('+','%2B')
    xyXEBipNmAdhHKCswRSgOrVbkJLPuo='RunPlugin(plugin://plugin.video.searchm/?params=%s)'%(xyXEBipNmAdhHKCswRSgOrVbkJLPut)
    xyXEBipNmAdhHKCswRSgOrVbkJLPUc=[('(통합) 찜 영상에 추가',xyXEBipNmAdhHKCswRSgOrVbkJLPuo)]
   else:
    xyXEBipNmAdhHKCswRSgOrVbkJLPUc=xyXEBipNmAdhHKCswRSgOrVbkJLPjn
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.add_dir(xyXEBipNmAdhHKCswRSgOrVbkJLPYM+xyXEBipNmAdhHKCswRSgOrVbkJLPUI,sublabel=xyXEBipNmAdhHKCswRSgOrVbkJLPjn,img=xyXEBipNmAdhHKCswRSgOrVbkJLPuz,infoLabels=xyXEBipNmAdhHKCswRSgOrVbkJLPUl,isFolder=xyXEBipNmAdhHKCswRSgOrVbkJLPvu,params=xyXEBipNmAdhHKCswRSgOrVbkJLPYl,isLink=xyXEBipNmAdhHKCswRSgOrVbkJLPjF,ContextMenu=xyXEBipNmAdhHKCswRSgOrVbkJLPUc,direct_url=xyXEBipNmAdhHKCswRSgOrVbkJLPvo)
  if xyXEBipNmAdhHKCswRSgOrVbkJLPvc:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYl={}
   xyXEBipNmAdhHKCswRSgOrVbkJLPYl['mode'] ='NF_SEARCH' 
   xyXEBipNmAdhHKCswRSgOrVbkJLPYl['page'] =xyXEBipNmAdhHKCswRSgOrVbkJLPjo(xyXEBipNmAdhHKCswRSgOrVbkJLPua+1)
   xyXEBipNmAdhHKCswRSgOrVbkJLPYl['search_key']=xyXEBipNmAdhHKCswRSgOrVbkJLPvF
   xyXEBipNmAdhHKCswRSgOrVbkJLPYl['byReference']=xyXEBipNmAdhHKCswRSgOrVbkJLPvl
   xyXEBipNmAdhHKCswRSgOrVbkJLPYM='[B]%s >>[/B]'%'다음 페이지'
   xyXEBipNmAdhHKCswRSgOrVbkJLPjY=xyXEBipNmAdhHKCswRSgOrVbkJLPjo(xyXEBipNmAdhHKCswRSgOrVbkJLPua+1)
   xyXEBipNmAdhHKCswRSgOrVbkJLPUD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.add_dir(xyXEBipNmAdhHKCswRSgOrVbkJLPYM,sublabel=xyXEBipNmAdhHKCswRSgOrVbkJLPjY,img=xyXEBipNmAdhHKCswRSgOrVbkJLPUD,infoLabels=xyXEBipNmAdhHKCswRSgOrVbkJLPjn,isFolder=xyXEBipNmAdhHKCswRSgOrVbkJLPjz,params=xyXEBipNmAdhHKCswRSgOrVbkJLPYl)
  xbmcplugin.setContent(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ._addon_handle,'movies')
  xbmcplugin.endOfDirectory(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ._addon_handle)
 def dp_Bookmark_Menu(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,args):
  xyXEBipNmAdhHKCswRSgOrVbkJLPjU='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(xyXEBipNmAdhHKCswRSgOrVbkJLPjU)
 def dp_Set_Bookmark(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ,args):
  xyXEBipNmAdhHKCswRSgOrVbkJLPuf =args.get('videoid')
  xyXEBipNmAdhHKCswRSgOrVbkJLPuU =args.get('vidtype')
  xyXEBipNmAdhHKCswRSgOrVbkJLPjv =args.get('vtitle')
  xyXEBipNmAdhHKCswRSgOrVbkJLPju =args.get('vsubtitle')
  xyXEBipNmAdhHKCswRSgOrVbkJLPjf =args.get('vinfo')
  xyXEBipNmAdhHKCswRSgOrVbkJLPuz =args.get('thumbnail')
  xyXEBipNmAdhHKCswRSgOrVbkJLPYT=xbmcgui.Dialog()
  xyXEBipNmAdhHKCswRSgOrVbkJLPvY=xyXEBipNmAdhHKCswRSgOrVbkJLPYT.yesno(__language__(30917).encode('utf8'),xyXEBipNmAdhHKCswRSgOrVbkJLPjv+' \n\n'+__language__(30918))
  if xyXEBipNmAdhHKCswRSgOrVbkJLPvY==xyXEBipNmAdhHKCswRSgOrVbkJLPjF:return
  xyXEBipNmAdhHKCswRSgOrVbkJLPjQ={'indexinfo':{'ott':'netflix','videoid':xyXEBipNmAdhHKCswRSgOrVbkJLPuf,'vidtype':xyXEBipNmAdhHKCswRSgOrVbkJLPuU,},'saveinfo':{'title':xyXEBipNmAdhHKCswRSgOrVbkJLPjv,'subtitle':xyXEBipNmAdhHKCswRSgOrVbkJLPju,'thumbnail':xyXEBipNmAdhHKCswRSgOrVbkJLPuz,'infoLabels':xyXEBipNmAdhHKCswRSgOrVbkJLPjf,},}
  xyXEBipNmAdhHKCswRSgOrVbkJLPYl={'mode':'SET_BOOKMARK','values':{'VIDEO_INFO':xyXEBipNmAdhHKCswRSgOrVbkJLPjQ,}}
  xyXEBipNmAdhHKCswRSgOrVbkJLPYD=json.dumps(xyXEBipNmAdhHKCswRSgOrVbkJLPYl,separators=(',',':'))
  xyXEBipNmAdhHKCswRSgOrVbkJLPYD=base64.standard_b64encode(xyXEBipNmAdhHKCswRSgOrVbkJLPYD.encode()).decode('utf-8')
  xyXEBipNmAdhHKCswRSgOrVbkJLPYD=xyXEBipNmAdhHKCswRSgOrVbkJLPYD.replace('+','%2B')
  xyXEBipNmAdhHKCswRSgOrVbkJLPuo='RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(xyXEBipNmAdhHKCswRSgOrVbkJLPYD)
  xbmc.executebuiltin(xyXEBipNmAdhHKCswRSgOrVbkJLPuo)
 def search_main(xyXEBipNmAdhHKCswRSgOrVbkJLPYQ):
  xyXEBipNmAdhHKCswRSgOrVbkJLPja=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.main_params.get('params')
  if xyXEBipNmAdhHKCswRSgOrVbkJLPja:
   xyXEBipNmAdhHKCswRSgOrVbkJLPje =base64.standard_b64decode(xyXEBipNmAdhHKCswRSgOrVbkJLPja).decode('utf-8')
   xyXEBipNmAdhHKCswRSgOrVbkJLPje =json.loads(xyXEBipNmAdhHKCswRSgOrVbkJLPje)
   xyXEBipNmAdhHKCswRSgOrVbkJLPjq =xyXEBipNmAdhHKCswRSgOrVbkJLPje.get('mode')
   xyXEBipNmAdhHKCswRSgOrVbkJLPjW =xyXEBipNmAdhHKCswRSgOrVbkJLPje.get('values')
  else:
   xyXEBipNmAdhHKCswRSgOrVbkJLPjq=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.main_params.get('mode',xyXEBipNmAdhHKCswRSgOrVbkJLPjn)
   xyXEBipNmAdhHKCswRSgOrVbkJLPjW=xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.main_params
  if xyXEBipNmAdhHKCswRSgOrVbkJLPjq=='NFLOGOUT':
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.NF_logout()
   return
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPjq=='NFLOGIN':
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.NF_login(showMessage=xyXEBipNmAdhHKCswRSgOrVbkJLPjz)
   return
  xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.option_check()
  if xyXEBipNmAdhHKCswRSgOrVbkJLPjq is xyXEBipNmAdhHKCswRSgOrVbkJLPjn:
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.dp_Main_List()
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPjq=='TOTAL_SEARCH':
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.dp_Search_Group(xyXEBipNmAdhHKCswRSgOrVbkJLPjW)
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPjq=='NF_SEARCH':
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.dp_Nf_Search(xyXEBipNmAdhHKCswRSgOrVbkJLPjW)
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPjq=='TOTAL_HISTORY':
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.dp_Search_History(xyXEBipNmAdhHKCswRSgOrVbkJLPjW)
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPjq=='HISTORY_REMOVE':
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.dp_History_Delete(xyXEBipNmAdhHKCswRSgOrVbkJLPjW)
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPjq=='MENU_BOOKMARK':
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.dp_Bookmark_Menu(xyXEBipNmAdhHKCswRSgOrVbkJLPjW)
  elif xyXEBipNmAdhHKCswRSgOrVbkJLPjq=='SET_BOOKMARK':
   xyXEBipNmAdhHKCswRSgOrVbkJLPYQ.dp_Set_Bookmark(xyXEBipNmAdhHKCswRSgOrVbkJLPjW)
  else:
   xyXEBipNmAdhHKCswRSgOrVbkJLPjn
# Created by pyminifier (https://github.com/liftoff/pyminifier)
