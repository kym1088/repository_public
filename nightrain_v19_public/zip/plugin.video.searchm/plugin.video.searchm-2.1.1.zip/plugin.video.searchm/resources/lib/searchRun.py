__author__="NightRain"
dEHIeJfGuilOKrgMCyPoVbaQAhpzRY=object
dEHIeJfGuilOKrgMCyPoVbaQAhpzRv=None
dEHIeJfGuilOKrgMCyPoVbaQAhpzRX=True
dEHIeJfGuilOKrgMCyPoVbaQAhpzRw=False
dEHIeJfGuilOKrgMCyPoVbaQAhpzRF=type
dEHIeJfGuilOKrgMCyPoVbaQAhpzRc=dict
dEHIeJfGuilOKrgMCyPoVbaQAhpzRk=open
dEHIeJfGuilOKrgMCyPoVbaQAhpzRx=len
dEHIeJfGuilOKrgMCyPoVbaQAhpzRm=Exception
dEHIeJfGuilOKrgMCyPoVbaQAhpzRs=range
dEHIeJfGuilOKrgMCyPoVbaQAhpzRn=int
dEHIeJfGuilOKrgMCyPoVbaQAhpzRq=str
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
dEHIeJfGuilOKrgMCyPoVbaQAhpzSj=[{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','icon':'search.png'},{'title':'검색기록','mode':'TOTAL_HISTORY','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','icon':'bookmark.png'},{'title':'-----------------','mode':'XXX'},{'title':'본 애드온은 검색기능 만을 제공합니다.','mode':'XXX'},{'title':'영상재생을 위해서는 개별(OTT) 애드온 설치가 필요합니다.','mode':'XXX'},]
dEHIeJfGuilOKrgMCyPoVbaQAhpzST={'wavve_tvshow':{'title':'웨이브 (VOD)','mode':'HYPER_LINK','ott':'wavve','vidtype':'TVSHOW','icon':'wavve.png'},'wavve_movie':{'title':'웨이브 (영화)','mode':'HYPER_LINK','ott':'wavve','vidtype':'MOVIE','icon':'wavve.png'},'tving_tvshow':{'title':'티빙 (VOD)','mode':'HYPER_LINK','ott':'tving','vidtype':'TVSHOW','icon':'tving.png'},'tving_movie':{'title':'티빙 (영화)','mode':'HYPER_LINK','ott':'tving','vidtype':'MOVIE','icon':'tving.png'},'watcha_list':{'title':'왓챠 (영화,시리즈)','mode':'HYPER_LINK','ott':'watcha','vidtype':'-','icon':'watcha.png'},'netflix_list':{'title':'넷플릭스 (영화,시리즈)','mode':'NF_SEARCH','ott':'netflix','vidtype':'-','icon':'netflix.png'},}
dEHIeJfGuilOKrgMCyPoVbaQAhpzSR =xbmcvfs.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.netflix','COOKIES'))
dEHIeJfGuilOKrgMCyPoVbaQAhpzSt=xbmcvfs.translatePath(os.path.join(__profile__,'nf_cookies.json'))
dEHIeJfGuilOKrgMCyPoVbaQAhpzSL =xbmcvfs.translatePath(os.path.join(__profile__,'searchedlist.txt'))
from searchCore import*
class dEHIeJfGuilOKrgMCyPoVbaQAhpzSU(dEHIeJfGuilOKrgMCyPoVbaQAhpzRY):
 def __init__(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,dEHIeJfGuilOKrgMCyPoVbaQAhpzSY,dEHIeJfGuilOKrgMCyPoVbaQAhpzSv,dEHIeJfGuilOKrgMCyPoVbaQAhpzSX):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW._addon_url =dEHIeJfGuilOKrgMCyPoVbaQAhpzSY
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW._addon_handle=dEHIeJfGuilOKrgMCyPoVbaQAhpzSv
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.main_params =dEHIeJfGuilOKrgMCyPoVbaQAhpzSX
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj =oltLFvNKcuVIQwDpzWXRTGHUdbmxEO() 
 def addon_noti(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,sting):
  try:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSF=xbmcgui.Dialog()
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSF.notification(__addonname__,sting)
  except:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzRv
 def addon_log(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,string):
  try:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSc=string.encode('utf-8','ignore')
  except:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSc='addonException: addon_log'
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSk=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,dEHIeJfGuilOKrgMCyPoVbaQAhpzSc),level=dEHIeJfGuilOKrgMCyPoVbaQAhpzSk)
 def get_keyboard_input(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,dEHIeJfGuilOKrgMCyPoVbaQAhpzSq):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSx=dEHIeJfGuilOKrgMCyPoVbaQAhpzRv
  kb=xbmc.Keyboard()
  kb.setHeading(dEHIeJfGuilOKrgMCyPoVbaQAhpzSq)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSx=kb.getText()
  return dEHIeJfGuilOKrgMCyPoVbaQAhpzSx
 def get_settings_menubookmark(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSm=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX if __addon__.getSetting('menu_bookmark')=='true' else dEHIeJfGuilOKrgMCyPoVbaQAhpzRw
  return(dEHIeJfGuilOKrgMCyPoVbaQAhpzSm)
 def get_settings_makebookmark(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW):
  return dEHIeJfGuilOKrgMCyPoVbaQAhpzRX if __addon__.getSetting('make_bookmark')=='true' else dEHIeJfGuilOKrgMCyPoVbaQAhpzRw
 def get_settings_select_info(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSs=[]
  if __addon__.getSetting('netflixyn')=='true':dEHIeJfGuilOKrgMCyPoVbaQAhpzSs.append('netflix')
  if __addon__.getSetting('wavveyn')=='true':dEHIeJfGuilOKrgMCyPoVbaQAhpzSs.append('wavve')
  if __addon__.getSetting('tvingyn')=='true':dEHIeJfGuilOKrgMCyPoVbaQAhpzSs.append('tving')
  if __addon__.getSetting('watchayn')=='true':dEHIeJfGuilOKrgMCyPoVbaQAhpzSs.append('watcha')
  return dEHIeJfGuilOKrgMCyPoVbaQAhpzSs
 def add_dir(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,label,sublabel='',img='',infoLabels=dEHIeJfGuilOKrgMCyPoVbaQAhpzRv,isFolder=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX,params='',isLink=dEHIeJfGuilOKrgMCyPoVbaQAhpzRw,ContextMenu=dEHIeJfGuilOKrgMCyPoVbaQAhpzRv):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSn='%s?%s'%(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW._addon_url,urllib.parse.urlencode(params))
  if sublabel:dEHIeJfGuilOKrgMCyPoVbaQAhpzSq='%s < %s >'%(label,sublabel)
  else: dEHIeJfGuilOKrgMCyPoVbaQAhpzSq=label
  if not img:img='DefaultFolder.png'
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSD=xbmcgui.ListItem(dEHIeJfGuilOKrgMCyPoVbaQAhpzSq)
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzRF(img)==dEHIeJfGuilOKrgMCyPoVbaQAhpzRc:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSD.setArt(img)
  else:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSD.setArt({'thumb':img,'poster':img})
  if infoLabels:dEHIeJfGuilOKrgMCyPoVbaQAhpzSD.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSD.setProperty('IsPlayable','true')
  if ContextMenu:dEHIeJfGuilOKrgMCyPoVbaQAhpzSD.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW._addon_handle,dEHIeJfGuilOKrgMCyPoVbaQAhpzSn,dEHIeJfGuilOKrgMCyPoVbaQAhpzSD,isFolder)
 def Load_Searched_List(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW):
  try:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSN=dEHIeJfGuilOKrgMCyPoVbaQAhpzSL
   fp=dEHIeJfGuilOKrgMCyPoVbaQAhpzRk(dEHIeJfGuilOKrgMCyPoVbaQAhpzSN,'r',-1,'utf-8')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSB=fp.readlines()
   fp.close()
  except:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSB=[]
  return dEHIeJfGuilOKrgMCyPoVbaQAhpzSB
 def Save_Searched_List(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,dEHIeJfGuilOKrgMCyPoVbaQAhpzjk):
  try:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSN=dEHIeJfGuilOKrgMCyPoVbaQAhpzSL
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUS=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.Load_Searched_List() 
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUj={'skey':dEHIeJfGuilOKrgMCyPoVbaQAhpzjk.strip()}
   fp=dEHIeJfGuilOKrgMCyPoVbaQAhpzRk(dEHIeJfGuilOKrgMCyPoVbaQAhpzSN,'w',-1,'utf-8')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUT=urllib.parse.urlencode(dEHIeJfGuilOKrgMCyPoVbaQAhpzUj)
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUT=dEHIeJfGuilOKrgMCyPoVbaQAhpzUT+'\n'
   fp.write(dEHIeJfGuilOKrgMCyPoVbaQAhpzUT)
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUR=0
   for dEHIeJfGuilOKrgMCyPoVbaQAhpzUt in dEHIeJfGuilOKrgMCyPoVbaQAhpzUS:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzUL=dEHIeJfGuilOKrgMCyPoVbaQAhpzRc(urllib.parse.parse_qsl(dEHIeJfGuilOKrgMCyPoVbaQAhpzUt))
    dEHIeJfGuilOKrgMCyPoVbaQAhpzUW=dEHIeJfGuilOKrgMCyPoVbaQAhpzUj.get('skey').strip()
    dEHIeJfGuilOKrgMCyPoVbaQAhpzUY=dEHIeJfGuilOKrgMCyPoVbaQAhpzUL.get('skey').strip()
    if dEHIeJfGuilOKrgMCyPoVbaQAhpzUW!=dEHIeJfGuilOKrgMCyPoVbaQAhpzUY:
     fp.write(dEHIeJfGuilOKrgMCyPoVbaQAhpzUt)
     dEHIeJfGuilOKrgMCyPoVbaQAhpzUR+=1
     if dEHIeJfGuilOKrgMCyPoVbaQAhpzUR>=50:break
   fp.close()
  except:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzRv
 def dp_Search_History(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,args):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzUv=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.Load_Searched_List()
  for dEHIeJfGuilOKrgMCyPoVbaQAhpzUX in dEHIeJfGuilOKrgMCyPoVbaQAhpzUv:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUw=dEHIeJfGuilOKrgMCyPoVbaQAhpzRc(urllib.parse.parse_qsl(dEHIeJfGuilOKrgMCyPoVbaQAhpzUX))
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUF=dEHIeJfGuilOKrgMCyPoVbaQAhpzUw.get('skey').strip()
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUc={'mode':'TOTAL_SEARCH','search_key':dEHIeJfGuilOKrgMCyPoVbaQAhpzUF,}
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUk={'mode':'HISTORY_REMOVE','skey':dEHIeJfGuilOKrgMCyPoVbaQAhpzUF,'delmode':'ONE',}
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUx=urllib.parse.urlencode(dEHIeJfGuilOKrgMCyPoVbaQAhpzUk)
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUm=[('선택된 검색어 ( %s ) 삭제'%(dEHIeJfGuilOKrgMCyPoVbaQAhpzUF),'RunPlugin(plugin://plugin.video.searchm/?%s)'%(dEHIeJfGuilOKrgMCyPoVbaQAhpzUx))]
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.add_dir(dEHIeJfGuilOKrgMCyPoVbaQAhpzUF,sublabel='',img=dEHIeJfGuilOKrgMCyPoVbaQAhpzRv,infoLabels=dEHIeJfGuilOKrgMCyPoVbaQAhpzRv,isFolder=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX,params=dEHIeJfGuilOKrgMCyPoVbaQAhpzUc,ContextMenu=dEHIeJfGuilOKrgMCyPoVbaQAhpzUm)
  dEHIeJfGuilOKrgMCyPoVbaQAhpzUn={'plot':'검색목록 전체를 삭제합니다.'}
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSq='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  dEHIeJfGuilOKrgMCyPoVbaQAhpzUc={'mode':'HISTORY_REMOVE','skey':'-','delmode':'ALL',}
  dEHIeJfGuilOKrgMCyPoVbaQAhpzUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.add_dir(dEHIeJfGuilOKrgMCyPoVbaQAhpzSq,sublabel='',img=dEHIeJfGuilOKrgMCyPoVbaQAhpzUq,infoLabels=dEHIeJfGuilOKrgMCyPoVbaQAhpzUn,isFolder=dEHIeJfGuilOKrgMCyPoVbaQAhpzRw,params=dEHIeJfGuilOKrgMCyPoVbaQAhpzUc,isLink=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX)
  xbmcplugin.endOfDirectory(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW._addon_handle,cacheToDisc=dEHIeJfGuilOKrgMCyPoVbaQAhpzRw)
 def Delete_History_List(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,dEHIeJfGuilOKrgMCyPoVbaQAhpzUF,dEHIeJfGuilOKrgMCyPoVbaQAhpzUB):
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzUB=='ALL':
   try:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzSN=dEHIeJfGuilOKrgMCyPoVbaQAhpzSL
    fp=dEHIeJfGuilOKrgMCyPoVbaQAhpzRk(dEHIeJfGuilOKrgMCyPoVbaQAhpzSN,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzRv
  else:
   try:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzSN=dEHIeJfGuilOKrgMCyPoVbaQAhpzSL
    dEHIeJfGuilOKrgMCyPoVbaQAhpzUS=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.Load_Searched_List() 
    fp=dEHIeJfGuilOKrgMCyPoVbaQAhpzRk(dEHIeJfGuilOKrgMCyPoVbaQAhpzSN,'w',-1,'utf-8')
    for dEHIeJfGuilOKrgMCyPoVbaQAhpzUt in dEHIeJfGuilOKrgMCyPoVbaQAhpzUS:
     dEHIeJfGuilOKrgMCyPoVbaQAhpzUL=dEHIeJfGuilOKrgMCyPoVbaQAhpzRc(urllib.parse.parse_qsl(dEHIeJfGuilOKrgMCyPoVbaQAhpzUt))
     dEHIeJfGuilOKrgMCyPoVbaQAhpzUN=dEHIeJfGuilOKrgMCyPoVbaQAhpzUL.get('skey').strip()
     if dEHIeJfGuilOKrgMCyPoVbaQAhpzUF!=dEHIeJfGuilOKrgMCyPoVbaQAhpzUN:
      fp.write(dEHIeJfGuilOKrgMCyPoVbaQAhpzUt)
    fp.close()
   except:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzRv
 def dp_History_Delete(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,args):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzUF =args.get('skey') 
  dEHIeJfGuilOKrgMCyPoVbaQAhpzUB=args.get('delmode')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSF=xbmcgui.Dialog()
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzUB=='ALL':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzjS=dEHIeJfGuilOKrgMCyPoVbaQAhpzSF.yesno(__language__(30913).encode('utf8'),__language__(30908).encode('utf8'))
  else:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzjS=dEHIeJfGuilOKrgMCyPoVbaQAhpzSF.yesno(__language__(30914).encode('utf8'),__language__(30908).encode('utf8'))
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzjS==dEHIeJfGuilOKrgMCyPoVbaQAhpzRw:sys.exit()
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.Delete_History_List(dEHIeJfGuilOKrgMCyPoVbaQAhpzUF,dEHIeJfGuilOKrgMCyPoVbaQAhpzUB)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Main_List(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSm=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.get_settings_menubookmark()
  for dEHIeJfGuilOKrgMCyPoVbaQAhpzjU in dEHIeJfGuilOKrgMCyPoVbaQAhpzSj:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSq=dEHIeJfGuilOKrgMCyPoVbaQAhpzjU.get('title')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUq=''
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzjU.get('mode')=='MENU_BOOKMARK' and dEHIeJfGuilOKrgMCyPoVbaQAhpzSm==dEHIeJfGuilOKrgMCyPoVbaQAhpzRw:continue
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUc={'mode':dEHIeJfGuilOKrgMCyPoVbaQAhpzjU.get('mode')}
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzjU.get('mode')in['XXX','MENU_BOOKMARK']:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjT=dEHIeJfGuilOKrgMCyPoVbaQAhpzRw
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjR =dEHIeJfGuilOKrgMCyPoVbaQAhpzRX
   else:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjT=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjR =dEHIeJfGuilOKrgMCyPoVbaQAhpzRw
   if 'icon' in dEHIeJfGuilOKrgMCyPoVbaQAhpzjU:dEHIeJfGuilOKrgMCyPoVbaQAhpzUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',dEHIeJfGuilOKrgMCyPoVbaQAhpzjU.get('icon')) 
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.add_dir(dEHIeJfGuilOKrgMCyPoVbaQAhpzSq,sublabel='',img=dEHIeJfGuilOKrgMCyPoVbaQAhpzUq,infoLabels=dEHIeJfGuilOKrgMCyPoVbaQAhpzRv,isFolder=dEHIeJfGuilOKrgMCyPoVbaQAhpzjT,params=dEHIeJfGuilOKrgMCyPoVbaQAhpzUc,isLink=dEHIeJfGuilOKrgMCyPoVbaQAhpzjR)
  xbmcplugin.endOfDirectory(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW._addon_handle,cacheToDisc=dEHIeJfGuilOKrgMCyPoVbaQAhpzRw)
 def option_check(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSs=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.get_settings_select_info()
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzRx(dEHIeJfGuilOKrgMCyPoVbaQAhpzSs)==0:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSF=xbmcgui.Dialog()
   dEHIeJfGuilOKrgMCyPoVbaQAhpzjS=dEHIeJfGuilOKrgMCyPoVbaQAhpzSF.yesno(__language__(30901).encode('utf8'),__language__(30903).encode('utf8'))
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzjS==dEHIeJfGuilOKrgMCyPoVbaQAhpzRX:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if 'netflix' in dEHIeJfGuilOKrgMCyPoVbaQAhpzSs:
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.NF_cookiefile_check()==dEHIeJfGuilOKrgMCyPoVbaQAhpzRw:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.NF_login(showMessage=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX)
 def NF_cookiefile_check(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjL={}
  try: 
   fp=dEHIeJfGuilOKrgMCyPoVbaQAhpzRk(dEHIeJfGuilOKrgMCyPoVbaQAhpzSt,'r',-1,'utf-8')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzjL= json.load(fp)
   fp.close()
  except dEHIeJfGuilOKrgMCyPoVbaQAhpzRm as exception:
   return dEHIeJfGuilOKrgMCyPoVbaQAhpzRw
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF=dEHIeJfGuilOKrgMCyPoVbaQAhpzjL
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjW=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF_CookieFile_Load(dEHIeJfGuilOKrgMCyPoVbaQAhpzSR)
  if(dEHIeJfGuilOKrgMCyPoVbaQAhpzjW['NetflixId']!=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF['COOKIES']['NetflixId']or dEHIeJfGuilOKrgMCyPoVbaQAhpzjW['SecureNetflixId']!=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF['COOKIES']['SecureNetflixId']or dEHIeJfGuilOKrgMCyPoVbaQAhpzjW['flwssn']!=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF['COOKIES']['flwssn']or dEHIeJfGuilOKrgMCyPoVbaQAhpzjW['memclid']!=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF['COOKIES']['memclid']or dEHIeJfGuilOKrgMCyPoVbaQAhpzjW['nfvdid']!=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF['COOKIES']['nfvdid']):
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.Init_NF_Total()
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.NF_login(showMessage=dEHIeJfGuilOKrgMCyPoVbaQAhpzRw)==dEHIeJfGuilOKrgMCyPoVbaQAhpzRw:
    return dEHIeJfGuilOKrgMCyPoVbaQAhpzRw
  return dEHIeJfGuilOKrgMCyPoVbaQAhpzRX
 def NF_login(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,showMessage=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX):
  if showMessage:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSF=xbmcgui.Dialog()
   dEHIeJfGuilOKrgMCyPoVbaQAhpzjS=dEHIeJfGuilOKrgMCyPoVbaQAhpzSF.yesno(__language__(30911).encode('utf8'),__language__(30916).encode('utf8'))
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzjS==dEHIeJfGuilOKrgMCyPoVbaQAhpzRw:
    return dEHIeJfGuilOKrgMCyPoVbaQAhpzRw 
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF['COOKIES']=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF_CookieFile_Load(dEHIeJfGuilOKrgMCyPoVbaQAhpzSR)
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjY=dEHIeJfGuilOKrgMCyPoVbaQAhpzRw if dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF['COOKIES']=={}else dEHIeJfGuilOKrgMCyPoVbaQAhpzRX
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzjY:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_log('pass1 ok!')
  else:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_log('pass1 error!')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_noti(__language__(30905).encode('utf-8'))
   return dEHIeJfGuilOKrgMCyPoVbaQAhpzRw 
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjY=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF_Get_BaseSession()
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzjY:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_log('pass2 ok!')
  else:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_log('pass2 error!')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_noti(__language__(30905).encode('utf-8'))
   return dEHIeJfGuilOKrgMCyPoVbaQAhpzRw 
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjv =dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.Get_Now_Datetime()
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF['SESSION']['limitdate']=dEHIeJfGuilOKrgMCyPoVbaQAhpzjv.strftime('%Y-%m-%d')
  try: 
   fp=dEHIeJfGuilOKrgMCyPoVbaQAhpzRk(dEHIeJfGuilOKrgMCyPoVbaQAhpzSt,'w',-1,'utf-8')
   json.dump(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF,fp,indent=4,ensure_ascii=dEHIeJfGuilOKrgMCyPoVbaQAhpzRw)
   fp.close()
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_log('pass3 save ok!')
  except dEHIeJfGuilOKrgMCyPoVbaQAhpzRm as exception:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_log('pass3 save error!')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_noti(__language__(30905).encode('utf-8'))
   return dEHIeJfGuilOKrgMCyPoVbaQAhpzRw
  if showMessage:dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_noti(__language__(30904).encode('utf-8'))
  return dEHIeJfGuilOKrgMCyPoVbaQAhpzRX
 def NF_logout(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSF=xbmcgui.Dialog()
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjS=dEHIeJfGuilOKrgMCyPoVbaQAhpzSF.yesno(__language__(30910).encode('utf8'),__language__(30908).encode('utf8'))
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzjS==dEHIeJfGuilOKrgMCyPoVbaQAhpzRw:return 
  if os.path.isfile(dEHIeJfGuilOKrgMCyPoVbaQAhpzSt):os.remove(dEHIeJfGuilOKrgMCyPoVbaQAhpzSt)
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_noti(__language__(30909).encode('utf-8'))
 def MakeText_FreeList(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,dEHIeJfGuilOKrgMCyPoVbaQAhpzjx):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjw=''
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjF=7
  try:
   for i in dEHIeJfGuilOKrgMCyPoVbaQAhpzRs(dEHIeJfGuilOKrgMCyPoVbaQAhpzRx(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx)):
    if i>=dEHIeJfGuilOKrgMCyPoVbaQAhpzjF:
     dEHIeJfGuilOKrgMCyPoVbaQAhpzjw=dEHIeJfGuilOKrgMCyPoVbaQAhpzjw+'...'
     break
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjw=dEHIeJfGuilOKrgMCyPoVbaQAhpzjw+dEHIeJfGuilOKrgMCyPoVbaQAhpzjx[i]['title']+'\n'
  except:
   return ''
  return dEHIeJfGuilOKrgMCyPoVbaQAhpzjw
 def dp_Search_Group(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,args):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSs =dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.get_settings_select_info()
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjc=[]
  if 'search_key' in args:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzjk=args.get('search_key')
  else:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzjk=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not dEHIeJfGuilOKrgMCyPoVbaQAhpzjk:
    xbmcplugin.endOfDirectory(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW._addon_handle)
    return
  if 'wavve' in dEHIeJfGuilOKrgMCyPoVbaQAhpzSs:
   (dEHIeJfGuilOKrgMCyPoVbaQAhpzjx,dEHIeJfGuilOKrgMCyPoVbaQAhpzjm)=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.Get_Search_Wavve(dEHIeJfGuilOKrgMCyPoVbaQAhpzjk,'TVSHOW',1)
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzRx(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx)>0:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjs={'sType':'wavve_tvshow','sList':dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.MakeText_FreeList(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx),}
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjc.append(dEHIeJfGuilOKrgMCyPoVbaQAhpzjs)
   (dEHIeJfGuilOKrgMCyPoVbaQAhpzjx,dEHIeJfGuilOKrgMCyPoVbaQAhpzjm)=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.Get_Search_Wavve(dEHIeJfGuilOKrgMCyPoVbaQAhpzjk,'MOVIE',1)
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzRx(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx)>0:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjs={'sType':'wavve_movie','sList':dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.MakeText_FreeList(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx),}
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjc.append(dEHIeJfGuilOKrgMCyPoVbaQAhpzjs)
  if 'tving' in dEHIeJfGuilOKrgMCyPoVbaQAhpzSs:
   (dEHIeJfGuilOKrgMCyPoVbaQAhpzjx,dEHIeJfGuilOKrgMCyPoVbaQAhpzjm)=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.Get_Search_Tving(dEHIeJfGuilOKrgMCyPoVbaQAhpzjk,'TVSHOW',1)
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzRx(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx)>0:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjs={'sType':'tving_tvshow','sList':dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.MakeText_FreeList(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx),}
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjc.append(dEHIeJfGuilOKrgMCyPoVbaQAhpzjs)
   (dEHIeJfGuilOKrgMCyPoVbaQAhpzjx,dEHIeJfGuilOKrgMCyPoVbaQAhpzjm)=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.Get_Search_Tving(dEHIeJfGuilOKrgMCyPoVbaQAhpzjk,'MOVIE',1)
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzRx(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx)>0:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjs={'sType':'tving_movie','sList':dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.MakeText_FreeList(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx),}
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjc.append(dEHIeJfGuilOKrgMCyPoVbaQAhpzjs)
  if 'watcha' in dEHIeJfGuilOKrgMCyPoVbaQAhpzSs:
   (dEHIeJfGuilOKrgMCyPoVbaQAhpzjx,dEHIeJfGuilOKrgMCyPoVbaQAhpzjm)=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.Get_Search_Watcha(dEHIeJfGuilOKrgMCyPoVbaQAhpzjk,1)
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzRx(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx)>0:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjs={'sType':'watcha_list','sList':dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.MakeText_FreeList(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx),}
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjc.append(dEHIeJfGuilOKrgMCyPoVbaQAhpzjs)
  if 'netflix' in dEHIeJfGuilOKrgMCyPoVbaQAhpzSs:
   try:
    (dEHIeJfGuilOKrgMCyPoVbaQAhpzjx,dEHIeJfGuilOKrgMCyPoVbaQAhpzjm,dEHIeJfGuilOKrgMCyPoVbaQAhpzjn)=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.Get_Search_Netflix(dEHIeJfGuilOKrgMCyPoVbaQAhpzjk,1)
   except:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjx=[]
    dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_noti(__language__(30919).encode('utf8'))
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzRx(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx)>0:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjs={'sType':'netflix_list','sList':dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.MakeText_FreeList(dEHIeJfGuilOKrgMCyPoVbaQAhpzjx),}
    dEHIeJfGuilOKrgMCyPoVbaQAhpzjc.append(dEHIeJfGuilOKrgMCyPoVbaQAhpzjs)
  for dEHIeJfGuilOKrgMCyPoVbaQAhpzjq in dEHIeJfGuilOKrgMCyPoVbaQAhpzjc:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzjD=dEHIeJfGuilOKrgMCyPoVbaQAhpzST[dEHIeJfGuilOKrgMCyPoVbaQAhpzjq.get('sType')]
   dEHIeJfGuilOKrgMCyPoVbaQAhpzjN={'plot':'검색어 : '+dEHIeJfGuilOKrgMCyPoVbaQAhpzjk+'\n\n'+dEHIeJfGuilOKrgMCyPoVbaQAhpzjq.get('sList')}
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSq=dEHIeJfGuilOKrgMCyPoVbaQAhpzjD.get('title')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUc={'mode':dEHIeJfGuilOKrgMCyPoVbaQAhpzjD.get('mode'),'ott':dEHIeJfGuilOKrgMCyPoVbaQAhpzjD.get('ott'),'vidtype':dEHIeJfGuilOKrgMCyPoVbaQAhpzjD.get('vidtype'),'search_key':dEHIeJfGuilOKrgMCyPoVbaQAhpzjk}
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzjD.get('ott')=='netflix':
    dEHIeJfGuilOKrgMCyPoVbaQAhpzUc['page'] ='1'
    dEHIeJfGuilOKrgMCyPoVbaQAhpzUc['byReference']='-'
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',dEHIeJfGuilOKrgMCyPoVbaQAhpzjD.get('icon'))
   dEHIeJfGuilOKrgMCyPoVbaQAhpzjT=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX if dEHIeJfGuilOKrgMCyPoVbaQAhpzjD.get('mode')!='HYPER_LINK' else dEHIeJfGuilOKrgMCyPoVbaQAhpzRw
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.add_dir(dEHIeJfGuilOKrgMCyPoVbaQAhpzSq,sublabel='',img=dEHIeJfGuilOKrgMCyPoVbaQAhpzUq,infoLabels=dEHIeJfGuilOKrgMCyPoVbaQAhpzjN,isFolder=dEHIeJfGuilOKrgMCyPoVbaQAhpzjT,params=dEHIeJfGuilOKrgMCyPoVbaQAhpzUc,isLink=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX)
  xbmcplugin.endOfDirectory(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW._addon_handle)
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.Save_Searched_List(dEHIeJfGuilOKrgMCyPoVbaQAhpzjk)
 def dp_Hyper_Link(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,args):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjB =args.get('mode')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzTS =args.get('ott')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzTU =args.get('vidtype')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjk=args.get('search_key')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzTj='-'
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzTS=='wavve':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTR={'mode':'LOCAL_SEARCH','sType':'movie' if dEHIeJfGuilOKrgMCyPoVbaQAhpzTU=='MOVIE' else 'vod','search_key':dEHIeJfGuilOKrgMCyPoVbaQAhpzjk,'page':'1',}
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTt=urllib.parse.urlencode(dEHIeJfGuilOKrgMCyPoVbaQAhpzTR)
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTj='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(dEHIeJfGuilOKrgMCyPoVbaQAhpzTt)
  elif dEHIeJfGuilOKrgMCyPoVbaQAhpzTS=='tving':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTR={'mode':'LOCAL_SEARCH','stype':'movie' if dEHIeJfGuilOKrgMCyPoVbaQAhpzTU=='MOVIE' else 'vod','search_key':dEHIeJfGuilOKrgMCyPoVbaQAhpzjk,'page':'1',}
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTt=urllib.parse.urlencode(dEHIeJfGuilOKrgMCyPoVbaQAhpzTR)
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTj='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(dEHIeJfGuilOKrgMCyPoVbaQAhpzTt)
  elif dEHIeJfGuilOKrgMCyPoVbaQAhpzTS=='watcha':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTR={'mode':'LOCAL_SEARCH','search_key':dEHIeJfGuilOKrgMCyPoVbaQAhpzjk,'page':'1',}
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTt=urllib.parse.urlencode(dEHIeJfGuilOKrgMCyPoVbaQAhpzTR)
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTj='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(dEHIeJfGuilOKrgMCyPoVbaQAhpzTt)
  elif dEHIeJfGuilOKrgMCyPoVbaQAhpzTS=='netflix':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTL=args.get('videoid')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTW=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.NF['SESSION']['nowGuid']
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzTU=='TVSHOW':
    dEHIeJfGuilOKrgMCyPoVbaQAhpzTj='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(dEHIeJfGuilOKrgMCyPoVbaQAhpzTL)
   else:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzTj='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/?profile_guid=%s")'%(dEHIeJfGuilOKrgMCyPoVbaQAhpzTL,dEHIeJfGuilOKrgMCyPoVbaQAhpzTW)
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.addon_log('ott_url ==> ( '+dEHIeJfGuilOKrgMCyPoVbaQAhpzTj+' )')
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(dEHIeJfGuilOKrgMCyPoVbaQAhpzTj)
 def dp_Nf_Search(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,args):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzTY =dEHIeJfGuilOKrgMCyPoVbaQAhpzRn(args.get('page'))
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjk =args.get('search_key')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjn=args.get('byReference')
  (dEHIeJfGuilOKrgMCyPoVbaQAhpzjx,dEHIeJfGuilOKrgMCyPoVbaQAhpzjm,dEHIeJfGuilOKrgMCyPoVbaQAhpzjn)=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.SearchObj.Get_Search_Netflix(dEHIeJfGuilOKrgMCyPoVbaQAhpzjk,dEHIeJfGuilOKrgMCyPoVbaQAhpzTY,byReference=dEHIeJfGuilOKrgMCyPoVbaQAhpzjn)
  for dEHIeJfGuilOKrgMCyPoVbaQAhpzTv in dEHIeJfGuilOKrgMCyPoVbaQAhpzjx:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTL =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('videoid')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTU =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('vidtype')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSq =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('title')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTX =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('mpaa')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTw =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('regularSynopsis')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTF =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('dpSupplemental')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTc=dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('sequiturEvidence')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTk =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('thumbnail')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTx =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('year')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTm =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('duration')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTs =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('info_genre')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTn =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('director')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTq =dEHIeJfGuilOKrgMCyPoVbaQAhpzTv.get('cast')
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzTU=='movie':
    dEHIeJfGuilOKrgMCyPoVbaQAhpzUs=' (%s)'%(dEHIeJfGuilOKrgMCyPoVbaQAhpzRq(dEHIeJfGuilOKrgMCyPoVbaQAhpzTx))
   else:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzUs=''
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTD=''
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzTw:dEHIeJfGuilOKrgMCyPoVbaQAhpzTD=dEHIeJfGuilOKrgMCyPoVbaQAhpzTD+'\n\n'+dEHIeJfGuilOKrgMCyPoVbaQAhpzTw
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzTF :dEHIeJfGuilOKrgMCyPoVbaQAhpzTD=dEHIeJfGuilOKrgMCyPoVbaQAhpzTD+'\n\n'+dEHIeJfGuilOKrgMCyPoVbaQAhpzTF
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzTc:dEHIeJfGuilOKrgMCyPoVbaQAhpzTD=dEHIeJfGuilOKrgMCyPoVbaQAhpzTD+'\n\n'+dEHIeJfGuilOKrgMCyPoVbaQAhpzTc
   dEHIeJfGuilOKrgMCyPoVbaQAhpzTD=dEHIeJfGuilOKrgMCyPoVbaQAhpzTD.strip()
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUn={'mediatype':'tvshow' if dEHIeJfGuilOKrgMCyPoVbaQAhpzTU=='show' else 'movie','title':dEHIeJfGuilOKrgMCyPoVbaQAhpzSq,'mpaa':dEHIeJfGuilOKrgMCyPoVbaQAhpzTX,'plot':dEHIeJfGuilOKrgMCyPoVbaQAhpzTD,'duration':dEHIeJfGuilOKrgMCyPoVbaQAhpzTm,'genre':dEHIeJfGuilOKrgMCyPoVbaQAhpzTs,'director':dEHIeJfGuilOKrgMCyPoVbaQAhpzTn,'cast':dEHIeJfGuilOKrgMCyPoVbaQAhpzTq,'year':dEHIeJfGuilOKrgMCyPoVbaQAhpzTx,}
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUc={'mode':'HYPER_LINK','ott':'netflix','vidtype':'TVSHOW' if dEHIeJfGuilOKrgMCyPoVbaQAhpzTU=='show' else 'MOVIE','videoid':dEHIeJfGuilOKrgMCyPoVbaQAhpzTL,}
   if dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.get_settings_makebookmark():
    dEHIeJfGuilOKrgMCyPoVbaQAhpzTN={'videoid':dEHIeJfGuilOKrgMCyPoVbaQAhpzTL,'vidtype':'tvshow' if dEHIeJfGuilOKrgMCyPoVbaQAhpzTU=='show' else 'movie','vtitle':dEHIeJfGuilOKrgMCyPoVbaQAhpzSq+dEHIeJfGuilOKrgMCyPoVbaQAhpzUs,'vsubtitle':'','vinfo':dEHIeJfGuilOKrgMCyPoVbaQAhpzUn,'thumbnail':dEHIeJfGuilOKrgMCyPoVbaQAhpzTk,}
    dEHIeJfGuilOKrgMCyPoVbaQAhpzTB=json.dumps(dEHIeJfGuilOKrgMCyPoVbaQAhpzTN)
    dEHIeJfGuilOKrgMCyPoVbaQAhpzTB=urllib.parse.quote(dEHIeJfGuilOKrgMCyPoVbaQAhpzTB)
    dEHIeJfGuilOKrgMCyPoVbaQAhpzRS='RunPlugin(plugin://plugin.video.searchm/?mode=SET_BOOKMARK&bm_param=%s)'%(dEHIeJfGuilOKrgMCyPoVbaQAhpzTB)
    dEHIeJfGuilOKrgMCyPoVbaQAhpzUm=[('(통합) 찜 영상에 추가',dEHIeJfGuilOKrgMCyPoVbaQAhpzRS)]
   else:
    dEHIeJfGuilOKrgMCyPoVbaQAhpzUm=dEHIeJfGuilOKrgMCyPoVbaQAhpzRv
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.add_dir(dEHIeJfGuilOKrgMCyPoVbaQAhpzSq+dEHIeJfGuilOKrgMCyPoVbaQAhpzUs,sublabel=dEHIeJfGuilOKrgMCyPoVbaQAhpzRv,img=dEHIeJfGuilOKrgMCyPoVbaQAhpzTk,infoLabels=dEHIeJfGuilOKrgMCyPoVbaQAhpzUn,isFolder=dEHIeJfGuilOKrgMCyPoVbaQAhpzRw,params=dEHIeJfGuilOKrgMCyPoVbaQAhpzUc,isLink=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX,ContextMenu=dEHIeJfGuilOKrgMCyPoVbaQAhpzUm)
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzjm:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUc={}
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUc['mode'] ='NF_SEARCH' 
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUc['page'] =dEHIeJfGuilOKrgMCyPoVbaQAhpzRq(dEHIeJfGuilOKrgMCyPoVbaQAhpzTY+1)
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUc['search_key']=dEHIeJfGuilOKrgMCyPoVbaQAhpzjk
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUc['byReference']=dEHIeJfGuilOKrgMCyPoVbaQAhpzjn
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSq='[B]%s >>[/B]'%'다음 페이지'
   dEHIeJfGuilOKrgMCyPoVbaQAhpzRU=dEHIeJfGuilOKrgMCyPoVbaQAhpzRq(dEHIeJfGuilOKrgMCyPoVbaQAhpzTY+1)
   dEHIeJfGuilOKrgMCyPoVbaQAhpzUq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.add_dir(dEHIeJfGuilOKrgMCyPoVbaQAhpzSq,sublabel=dEHIeJfGuilOKrgMCyPoVbaQAhpzRU,img=dEHIeJfGuilOKrgMCyPoVbaQAhpzUq,infoLabels=dEHIeJfGuilOKrgMCyPoVbaQAhpzRv,isFolder=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX,params=dEHIeJfGuilOKrgMCyPoVbaQAhpzUc)
  xbmcplugin.setContent(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW._addon_handle,'movies')
  xbmcplugin.endOfDirectory(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW._addon_handle)
 def dp_Bookmark_Menu(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,args):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzTj='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(dEHIeJfGuilOKrgMCyPoVbaQAhpzTj)
 def dp_Set_Bookmark(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW,args):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzRj=urllib.parse.unquote(args.get('bm_param'))
  dEHIeJfGuilOKrgMCyPoVbaQAhpzRj=json.loads(dEHIeJfGuilOKrgMCyPoVbaQAhpzRj)
  dEHIeJfGuilOKrgMCyPoVbaQAhpzTL =dEHIeJfGuilOKrgMCyPoVbaQAhpzRj.get('videoid')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzTU =dEHIeJfGuilOKrgMCyPoVbaQAhpzRj.get('vidtype')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzRT =dEHIeJfGuilOKrgMCyPoVbaQAhpzRj.get('vtitle')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzRt =dEHIeJfGuilOKrgMCyPoVbaQAhpzRj.get('vsubtitle')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzRL =dEHIeJfGuilOKrgMCyPoVbaQAhpzRj.get('vinfo')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzTk =dEHIeJfGuilOKrgMCyPoVbaQAhpzRj.get('thumbnail')
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSF=xbmcgui.Dialog()
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjS=dEHIeJfGuilOKrgMCyPoVbaQAhpzSF.yesno(__language__(30917).encode('utf8'),dEHIeJfGuilOKrgMCyPoVbaQAhpzRT+' \n\n'+__language__(30918))
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzjS==dEHIeJfGuilOKrgMCyPoVbaQAhpzRw:return
  dEHIeJfGuilOKrgMCyPoVbaQAhpzRW={'indexinfo':{'ott':'netflix','videoid':dEHIeJfGuilOKrgMCyPoVbaQAhpzTL,'vidtype':dEHIeJfGuilOKrgMCyPoVbaQAhpzTU,},'saveinfo':{'title':dEHIeJfGuilOKrgMCyPoVbaQAhpzRT,'subtitle':dEHIeJfGuilOKrgMCyPoVbaQAhpzRt,'thumbnail':dEHIeJfGuilOKrgMCyPoVbaQAhpzTk,'infoLabels':dEHIeJfGuilOKrgMCyPoVbaQAhpzRL,},}
  dEHIeJfGuilOKrgMCyPoVbaQAhpzTB=json.dumps(dEHIeJfGuilOKrgMCyPoVbaQAhpzRW)
  dEHIeJfGuilOKrgMCyPoVbaQAhpzTB=urllib.parse.quote(dEHIeJfGuilOKrgMCyPoVbaQAhpzTB)
  dEHIeJfGuilOKrgMCyPoVbaQAhpzRS='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(dEHIeJfGuilOKrgMCyPoVbaQAhpzTB)
  xbmc.executebuiltin(dEHIeJfGuilOKrgMCyPoVbaQAhpzRS)
 def search_main(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW):
  dEHIeJfGuilOKrgMCyPoVbaQAhpzjB=dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.main_params.get('mode',dEHIeJfGuilOKrgMCyPoVbaQAhpzRv)
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzjB=='NFLOGOUT':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.NF_logout()
   return
  elif dEHIeJfGuilOKrgMCyPoVbaQAhpzjB=='NFLOGIN':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.NF_login(showMessage=dEHIeJfGuilOKrgMCyPoVbaQAhpzRX)
   return
  dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.option_check()
  if dEHIeJfGuilOKrgMCyPoVbaQAhpzjB is dEHIeJfGuilOKrgMCyPoVbaQAhpzRv:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.dp_Main_List()
  elif dEHIeJfGuilOKrgMCyPoVbaQAhpzjB=='TOTAL_SEARCH':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.dp_Search_Group(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.main_params)
  elif dEHIeJfGuilOKrgMCyPoVbaQAhpzjB=='HYPER_LINK':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.dp_Hyper_Link(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.main_params)
  elif dEHIeJfGuilOKrgMCyPoVbaQAhpzjB=='NF_SEARCH':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.dp_Nf_Search(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.main_params)
  elif dEHIeJfGuilOKrgMCyPoVbaQAhpzjB=='TOTAL_HISTORY':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.dp_Search_History(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.main_params)
  elif dEHIeJfGuilOKrgMCyPoVbaQAhpzjB=='HISTORY_REMOVE':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.dp_History_Delete(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.main_params)
  elif dEHIeJfGuilOKrgMCyPoVbaQAhpzjB=='MENU_BOOKMARK':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.dp_Bookmark_Menu(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.main_params)
  elif dEHIeJfGuilOKrgMCyPoVbaQAhpzjB=='SET_BOOKMARK':
   dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.dp_Set_Bookmark(dEHIeJfGuilOKrgMCyPoVbaQAhpzSW.main_params)
  else:
   dEHIeJfGuilOKrgMCyPoVbaQAhpzRv
# Created by pyminifier (https://github.com/liftoff/pyminifier)
