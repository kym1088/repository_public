__author__="NightRain"
hCfORmMUuwSEYiHWNnjgxleQKIPzJq=object
hCfORmMUuwSEYiHWNnjgxleQKIPzJG=None
hCfORmMUuwSEYiHWNnjgxleQKIPzJB=False
hCfORmMUuwSEYiHWNnjgxleQKIPzJD=open
hCfORmMUuwSEYiHWNnjgxleQKIPzJc=True
hCfORmMUuwSEYiHWNnjgxleQKIPzJV=id
hCfORmMUuwSEYiHWNnjgxleQKIPzJF=str
hCfORmMUuwSEYiHWNnjgxleQKIPzXa=range
hCfORmMUuwSEYiHWNnjgxleQKIPzXp=Exception
hCfORmMUuwSEYiHWNnjgxleQKIPzXt=print
hCfORmMUuwSEYiHWNnjgxleQKIPzXy=int
hCfORmMUuwSEYiHWNnjgxleQKIPzXJ=len
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
import string
import random
class hCfORmMUuwSEYiHWNnjgxleQKIPzap(hCfORmMUuwSEYiHWNnjgxleQKIPzJq):
 def __init__(hCfORmMUuwSEYiHWNnjgxleQKIPzat):
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC ={}
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.Init_WC_Total()
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.MAIN_DOMAIN ='https://watcha.com'
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN ='https://api-mars.watcha.com'
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.EPISODE_LIMIT=20
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.SEARCH_LIMIT =30
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.USER_AGENT2 ='User-Agent: Dalvik/2.1.0 (Linux; U; Android 9; A95X_F3_Air Build/A95X_F3_AIR_M)/WatchaPlay-Android/1.10.34'
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.DEFAULT_HEADER={'user-agent':hCfORmMUuwSEYiHWNnjgxleQKIPzat.USER_AGENT}
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.KodiVersion=20
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC_SUBTITLE_VTT =''
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC_SUBTITLE_SRT =''
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC_COOKIE_FILENAME =''
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC_SEARCHEDC_FILENAME=''
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC_STREAM_FILENAME =''
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC_TEMP_JSONFILE_1 =''
 def Get_Base_Headers(hCfORmMUuwSEYiHWNnjgxleQKIPzat):
  hCfORmMUuwSEYiHWNnjgxleQKIPzay={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.3',}
  return hCfORmMUuwSEYiHWNnjgxleQKIPzay
 def Get_Base_Headers_v2(hCfORmMUuwSEYiHWNnjgxleQKIPzat):
  hCfORmMUuwSEYiHWNnjgxleQKIPzaJ ='1.10.35' 
  hCfORmMUuwSEYiHWNnjgxleQKIPzaX ='30' 
  hCfORmMUuwSEYiHWNnjgxleQKIPzaL ='NVIDIA SHIELD Android TV'
  hCfORmMUuwSEYiHWNnjgxleQKIPzas =base64.standard_b64encode((hCfORmMUuwSEYiHWNnjgxleQKIPzaL+'-'+hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['deviceId2']).encode()).decode('utf-8') 
  hCfORmMUuwSEYiHWNnjgxleQKIPzav ='1920x1080/2.0/320/xhdpi'
  hCfORmMUuwSEYiHWNnjgxleQKIPzao ='2596eb93-6e7f-4eba-925c-ddf783246860' 
  hCfORmMUuwSEYiHWNnjgxleQKIPzay={'X-WatchaPlay-Client-Device-Id':hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['deviceId1'],'X-WatchaPlay-Client-Device-Id2':hCfORmMUuwSEYiHWNnjgxleQKIPzas,'X-WatchaPlay-Client-Device-Name':hCfORmMUuwSEYiHWNnjgxleQKIPzaL,'X-WatchaPlay-Client-ADID':hCfORmMUuwSEYiHWNnjgxleQKIPzao,'X-WatchaPlay-Client':'WatchaPlay-Android','X-WatchaPlay-Client-Version':hCfORmMUuwSEYiHWNnjgxleQKIPzaJ,'X-WatchaPlay-Client-Subclass':'Normal','X-WatchaPlay-Client-Ui-Mode-Name':'television','X-WatchaPlay-Screen':hCfORmMUuwSEYiHWNnjgxleQKIPzav,'X-WatchaPlay-Network-Status':'wifi','X-WatchaPlay-Appsflyer-Device-ID':hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['flyerId'],'X-FROGRAMS-CLIENT':'Mars-Android-Box','X-FROGRAMS-APP-CODE':'mars','X-FROGRAMS-DEVICE-IDENTIFIER':hCfORmMUuwSEYiHWNnjgxleQKIPzas,'X-FROGRAMS-DEVICE-NAME':hCfORmMUuwSEYiHWNnjgxleQKIPzaL,'X-FROGRAMS-AD-ID':hCfORmMUuwSEYiHWNnjgxleQKIPzao,'X-FROGRAMS-APPSFLYER-DEVICE-ID':hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['flyerId'],'X-FROGRAMS-VERSION':hCfORmMUuwSEYiHWNnjgxleQKIPzaJ,'X-FROGRAMS-OS-VERSION':hCfORmMUuwSEYiHWNnjgxleQKIPzaX,'X-FROGRAMS-NETWORK-STATUS':'wifi','X-FROGRAMS-MARS-SCREEN':hCfORmMUuwSEYiHWNnjgxleQKIPzav,'X-FROGRAMS-MARS-UI-MODE':'television',}
  return hCfORmMUuwSEYiHWNnjgxleQKIPzay
 def Init_WC_Total(hCfORmMUuwSEYiHWNnjgxleQKIPzat):
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC={'account':{},'cookies':{'watcha_token':'','watcha_guit':'','watcha_guitv':'','watcha_usercd':'',},}
 def callRequestCookies(hCfORmMUuwSEYiHWNnjgxleQKIPzat,jobtype,hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,redirects=hCfORmMUuwSEYiHWNnjgxleQKIPzJB):
  hCfORmMUuwSEYiHWNnjgxleQKIPzar=hCfORmMUuwSEYiHWNnjgxleQKIPzat.DEFAULT_HEADER
  if headers:hCfORmMUuwSEYiHWNnjgxleQKIPzar.update(headers)
  if jobtype=='Get':
   hCfORmMUuwSEYiHWNnjgxleQKIPzaA=requests.get(hCfORmMUuwSEYiHWNnjgxleQKIPzpk,params=params,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzar,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   hCfORmMUuwSEYiHWNnjgxleQKIPzaA=requests.put(hCfORmMUuwSEYiHWNnjgxleQKIPzpk,data=payload,params=params,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzar,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Delete':
   hCfORmMUuwSEYiHWNnjgxleQKIPzaA=requests.delete(hCfORmMUuwSEYiHWNnjgxleQKIPzpk,params=params,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzar,cookies=cookies,allow_redirects=redirects)
  else:
   hCfORmMUuwSEYiHWNnjgxleQKIPzaA=requests.post(hCfORmMUuwSEYiHWNnjgxleQKIPzpk,data=payload,params=params,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzar,cookies=cookies,allow_redirects=redirects)
  return hCfORmMUuwSEYiHWNnjgxleQKIPzaA
 def JsonFile_Save(hCfORmMUuwSEYiHWNnjgxleQKIPzat,filename,hCfORmMUuwSEYiHWNnjgxleQKIPzaT):
  if filename=='':return hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  try:
   fp=hCfORmMUuwSEYiHWNnjgxleQKIPzJD(filename,'w',-1,'utf-8')
   json.dump(hCfORmMUuwSEYiHWNnjgxleQKIPzaT,fp,indent=4,ensure_ascii=hCfORmMUuwSEYiHWNnjgxleQKIPzJB)
   fp.close()
  except:
   return hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  return hCfORmMUuwSEYiHWNnjgxleQKIPzJc
 def JsonFile_Load(hCfORmMUuwSEYiHWNnjgxleQKIPzat,filename):
  if filename=='':return{}
  try:
   fp=hCfORmMUuwSEYiHWNnjgxleQKIPzJD(filename,'r',-1,'utf-8')
   hCfORmMUuwSEYiHWNnjgxleQKIPzad=json.load(fp)
   fp.close()
  except:
   return{}
  return hCfORmMUuwSEYiHWNnjgxleQKIPzad
 def Save_session_acount(hCfORmMUuwSEYiHWNnjgxleQKIPzat,hCfORmMUuwSEYiHWNnjgxleQKIPzab,hCfORmMUuwSEYiHWNnjgxleQKIPzaq,hCfORmMUuwSEYiHWNnjgxleQKIPzaG):
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['account']['wcid']=base64.standard_b64encode(hCfORmMUuwSEYiHWNnjgxleQKIPzab.encode()).decode('utf-8')
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['account']['wcpw']=base64.standard_b64encode(hCfORmMUuwSEYiHWNnjgxleQKIPzaq.encode()).decode('utf-8')
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['account']['wcpf']=hCfORmMUuwSEYiHWNnjgxleQKIPzaG 
 def Load_session_acount(hCfORmMUuwSEYiHWNnjgxleQKIPzat):
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzab=base64.standard_b64decode(hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['account']['wcid']).decode('utf-8')
   hCfORmMUuwSEYiHWNnjgxleQKIPzaq=base64.standard_b64decode(hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['account']['wcpw']).decode('utf-8')
   hCfORmMUuwSEYiHWNnjgxleQKIPzaG=hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['account']['wcpf']
  except:
   return '','',0
  return hCfORmMUuwSEYiHWNnjgxleQKIPzab,hCfORmMUuwSEYiHWNnjgxleQKIPzaq,hCfORmMUuwSEYiHWNnjgxleQKIPzaG
 def Get_DeviceID(hCfORmMUuwSEYiHWNnjgxleQKIPzat,hCfORmMUuwSEYiHWNnjgxleQKIPzJV,pf):
  import hashlib
  m1=hashlib.md5()
  m2=hashlib.md5()
  hCfORmMUuwSEYiHWNnjgxleQKIPzaB=hCfORmMUuwSEYiHWNnjgxleQKIPzJV+hCfORmMUuwSEYiHWNnjgxleQKIPzJF(pf)
  hCfORmMUuwSEYiHWNnjgxleQKIPzaD=hCfORmMUuwSEYiHWNnjgxleQKIPzJF(pf)+hCfORmMUuwSEYiHWNnjgxleQKIPzJV
  m1.update(hCfORmMUuwSEYiHWNnjgxleQKIPzaB.encode('utf-8'))
  m2.update(hCfORmMUuwSEYiHWNnjgxleQKIPzaD.encode('utf-8'))
  hCfORmMUuwSEYiHWNnjgxleQKIPzac=hCfORmMUuwSEYiHWNnjgxleQKIPzJF(m1.hexdigest())
  hCfORmMUuwSEYiHWNnjgxleQKIPzaV=hCfORmMUuwSEYiHWNnjgxleQKIPzJF(m2.hexdigest())
  hCfORmMUuwSEYiHWNnjgxleQKIPzaF=hCfORmMUuwSEYiHWNnjgxleQKIPzac[:16]
  hCfORmMUuwSEYiHWNnjgxleQKIPzpa='%s-%s-%s-%s-%s'%(hCfORmMUuwSEYiHWNnjgxleQKIPzaV[:8],hCfORmMUuwSEYiHWNnjgxleQKIPzaV[8:12],hCfORmMUuwSEYiHWNnjgxleQKIPzaV[12:16],hCfORmMUuwSEYiHWNnjgxleQKIPzaV[16:20],hCfORmMUuwSEYiHWNnjgxleQKIPzaV[20:])
  return hCfORmMUuwSEYiHWNnjgxleQKIPzaF,hCfORmMUuwSEYiHWNnjgxleQKIPzpa
 def make_Random_Intstr(hCfORmMUuwSEYiHWNnjgxleQKIPzat,size):
  hCfORmMUuwSEYiHWNnjgxleQKIPzpt=string.digits 
  hCfORmMUuwSEYiHWNnjgxleQKIPzpy=''
  for i in hCfORmMUuwSEYiHWNnjgxleQKIPzXa(size):
   hCfORmMUuwSEYiHWNnjgxleQKIPzpy+=random.choice(hCfORmMUuwSEYiHWNnjgxleQKIPzpt)
  return hCfORmMUuwSEYiHWNnjgxleQKIPzpy
 def makeDefaultCookies(hCfORmMUuwSEYiHWNnjgxleQKIPzat):
  hCfORmMUuwSEYiHWNnjgxleQKIPzpJ={'_s_guit':hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_guit'],'_guinness-premium_session':hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_token']}
  if hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_guitv']:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpJ['_s_guitv']=hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_guitv']
  return hCfORmMUuwSEYiHWNnjgxleQKIPzpJ
 def GetCredential(hCfORmMUuwSEYiHWNnjgxleQKIPzat,user_id,user_pw,user_pf):
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpX=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+'/api/session'
   hCfORmMUuwSEYiHWNnjgxleQKIPzpL={'email':user_id,'password':user_pw}
   hCfORmMUuwSEYiHWNnjgxleQKIPzps=hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpv={'accept':'application/vnd.frograms+json;version=4'}
   hCfORmMUuwSEYiHWNnjgxleQKIPzps.update(hCfORmMUuwSEYiHWNnjgxleQKIPzpv)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Post',hCfORmMUuwSEYiHWNnjgxleQKIPzpX,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzpL,params=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzJG)
   for hCfORmMUuwSEYiHWNnjgxleQKIPzpr in hCfORmMUuwSEYiHWNnjgxleQKIPzpo.cookies:
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpr.name=='_ale_session':
     hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_token']=hCfORmMUuwSEYiHWNnjgxleQKIPzpr.value
    elif hCfORmMUuwSEYiHWNnjgxleQKIPzpr.name=='_s_guit':
     hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_guit']=hCfORmMUuwSEYiHWNnjgxleQKIPzpr.value
   if hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_token']=='':
    hCfORmMUuwSEYiHWNnjgxleQKIPzat.Init_WC_Total()
    return hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
   hCfORmMUuwSEYiHWNnjgxleQKIPzat.Init_WC_Total()
   return hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  if hCfORmMUuwSEYiHWNnjgxleQKIPzat.GetProfilesList(user_pf)==hCfORmMUuwSEYiHWNnjgxleQKIPzJB:
   hCfORmMUuwSEYiHWNnjgxleQKIPzat.Init_WC_Total()
   return hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  if user_pf!=0:
   if hCfORmMUuwSEYiHWNnjgxleQKIPzat.GetProfilesConvert()==hCfORmMUuwSEYiHWNnjgxleQKIPzJB:
    hCfORmMUuwSEYiHWNnjgxleQKIPzat.Init_WC_Total()
    return hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  (hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['deviceId1'],hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['deviceId2'])=hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_DeviceID(user_id,user_pf)
  hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['flyerId']=hCfORmMUuwSEYiHWNnjgxleQKIPzJF(hCfORmMUuwSEYiHWNnjgxleQKIPzXy(time.time()*1000))+'-'+hCfORmMUuwSEYiHWNnjgxleQKIPzat.make_Random_Intstr(19)
  return hCfORmMUuwSEYiHWNnjgxleQKIPzJc
 def GetProfilesList(hCfORmMUuwSEYiHWNnjgxleQKIPzat,user_pf):
  hCfORmMUuwSEYiHWNnjgxleQKIPzpA=[]
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/groups/members'
   hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.MAIN_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
   hCfORmMUuwSEYiHWNnjgxleQKIPzps=hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpr=hCfORmMUuwSEYiHWNnjgxleQKIPzat.makeDefaultCookies()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzpr,redirects=hCfORmMUuwSEYiHWNnjgxleQKIPzJc)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpd=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpA.append(hCfORmMUuwSEYiHWNnjgxleQKIPzpd['naive_group']['chief_user']['code'])
   for hCfORmMUuwSEYiHWNnjgxleQKIPzpb in hCfORmMUuwSEYiHWNnjgxleQKIPzpd['naive_group']['valid_memberships']:
    hCfORmMUuwSEYiHWNnjgxleQKIPzpA.append(hCfORmMUuwSEYiHWNnjgxleQKIPzpb['user']['code'])
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(hCfORmMUuwSEYiHWNnjgxleQKIPzpA)
   hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_usercd']=hCfORmMUuwSEYiHWNnjgxleQKIPzpA[user_pf]
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
   hCfORmMUuwSEYiHWNnjgxleQKIPzat.Init_WC_Total()
   return hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  return hCfORmMUuwSEYiHWNnjgxleQKIPzJc
 def GetProfilesConvert(hCfORmMUuwSEYiHWNnjgxleQKIPzat):
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/users/'+hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_usercd']+'/convert'
   hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
   hCfORmMUuwSEYiHWNnjgxleQKIPzps =hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpr =hCfORmMUuwSEYiHWNnjgxleQKIPzat.makeDefaultCookies()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Put',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzpr)
   for hCfORmMUuwSEYiHWNnjgxleQKIPzpr in hCfORmMUuwSEYiHWNnjgxleQKIPzpo.cookies:
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpr.name=='_s_guitv':
     hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_guitv']=hCfORmMUuwSEYiHWNnjgxleQKIPzpr.value
    elif hCfORmMUuwSEYiHWNnjgxleQKIPzpr.name=='_guinness-premium_session':
     hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_token']=hCfORmMUuwSEYiHWNnjgxleQKIPzpr.value
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
   hCfORmMUuwSEYiHWNnjgxleQKIPzat.Init_WC_Total()
   return hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  return hCfORmMUuwSEYiHWNnjgxleQKIPzJc
 def GetSubGroupList(hCfORmMUuwSEYiHWNnjgxleQKIPzat,stype):
  hCfORmMUuwSEYiHWNnjgxleQKIPzpq=[]
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/categories.json'
   hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
   hCfORmMUuwSEYiHWNnjgxleQKIPzps =hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpr =hCfORmMUuwSEYiHWNnjgxleQKIPzat.makeDefaultCookies()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzpr)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpG=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
   if not('genres' in hCfORmMUuwSEYiHWNnjgxleQKIPzpG):return hCfORmMUuwSEYiHWNnjgxleQKIPzpq
   if stype=='genres':
    hCfORmMUuwSEYiHWNnjgxleQKIPzpB=hCfORmMUuwSEYiHWNnjgxleQKIPzpG['genres']
   else:
    hCfORmMUuwSEYiHWNnjgxleQKIPzpB=hCfORmMUuwSEYiHWNnjgxleQKIPzpG['tags']
   for hCfORmMUuwSEYiHWNnjgxleQKIPzpD in hCfORmMUuwSEYiHWNnjgxleQKIPzpB:
    hCfORmMUuwSEYiHWNnjgxleQKIPzpc=hCfORmMUuwSEYiHWNnjgxleQKIPzpD['name']
    hCfORmMUuwSEYiHWNnjgxleQKIPzpV =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['api_path']
    hCfORmMUuwSEYiHWNnjgxleQKIPzpF =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['entity']['id']
    hCfORmMUuwSEYiHWNnjgxleQKIPzta={'group_name':hCfORmMUuwSEYiHWNnjgxleQKIPzpc,'api_path':hCfORmMUuwSEYiHWNnjgxleQKIPzpV,'tag_id':hCfORmMUuwSEYiHWNnjgxleQKIPzJF(hCfORmMUuwSEYiHWNnjgxleQKIPzpF)}
    hCfORmMUuwSEYiHWNnjgxleQKIPzpq.append(hCfORmMUuwSEYiHWNnjgxleQKIPzta)
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
  return hCfORmMUuwSEYiHWNnjgxleQKIPzpq
 def GetCategoryList(hCfORmMUuwSEYiHWNnjgxleQKIPzat,stype,hCfORmMUuwSEYiHWNnjgxleQKIPzpF,hCfORmMUuwSEYiHWNnjgxleQKIPzpV,hCfORmMUuwSEYiHWNnjgxleQKIPzyT):
  hCfORmMUuwSEYiHWNnjgxleQKIPzpq=[]
  hCfORmMUuwSEYiHWNnjgxleQKIPztp=hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  hCfORmMUuwSEYiHWNnjgxleQKIPzty={}
  try:
   if 'categories' in hCfORmMUuwSEYiHWNnjgxleQKIPzpV:
    hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/tags'
    hCfORmMUuwSEYiHWNnjgxleQKIPzty['ids']=hCfORmMUuwSEYiHWNnjgxleQKIPzpF
   else: 
    hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/'+hCfORmMUuwSEYiHWNnjgxleQKIPzpV+'.json'
    if hCfORmMUuwSEYiHWNnjgxleQKIPzyT>1:
     hCfORmMUuwSEYiHWNnjgxleQKIPzty['page']=hCfORmMUuwSEYiHWNnjgxleQKIPzJF(hCfORmMUuwSEYiHWNnjgxleQKIPzyT)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
   hCfORmMUuwSEYiHWNnjgxleQKIPzps =hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpr =hCfORmMUuwSEYiHWNnjgxleQKIPzat.makeDefaultCookies()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzty,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzpr)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpG=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
   if not('contents' in hCfORmMUuwSEYiHWNnjgxleQKIPzpG):return hCfORmMUuwSEYiHWNnjgxleQKIPzpq,hCfORmMUuwSEYiHWNnjgxleQKIPztp
   hCfORmMUuwSEYiHWNnjgxleQKIPzpB=hCfORmMUuwSEYiHWNnjgxleQKIPzpG['contents']
   hCfORmMUuwSEYiHWNnjgxleQKIPztp=hCfORmMUuwSEYiHWNnjgxleQKIPzpG['meta']['has_next']
   for hCfORmMUuwSEYiHWNnjgxleQKIPzpD in hCfORmMUuwSEYiHWNnjgxleQKIPzpB:
    hCfORmMUuwSEYiHWNnjgxleQKIPztJ =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['code']
    hCfORmMUuwSEYiHWNnjgxleQKIPztX=hCfORmMUuwSEYiHWNnjgxleQKIPzpD['content_type']
    hCfORmMUuwSEYiHWNnjgxleQKIPztL =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['title']
    hCfORmMUuwSEYiHWNnjgxleQKIPzts =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['story']
    hCfORmMUuwSEYiHWNnjgxleQKIPztv =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['badge_text']
    hCfORmMUuwSEYiHWNnjgxleQKIPzto=hCfORmMUuwSEYiHWNnjgxleQKIPzJb=hCfORmMUuwSEYiHWNnjgxleQKIPzJd=''
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('poster') !=hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPzto=hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('poster').get('original')
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('stillcut')!=hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPzJb =hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('stillcut').get('large')
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('thumbnail')!=hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPzJd=hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('thumbnail').get('large')
    if hCfORmMUuwSEYiHWNnjgxleQKIPzJd=='' :hCfORmMUuwSEYiHWNnjgxleQKIPzJd=hCfORmMUuwSEYiHWNnjgxleQKIPzJb
    hCfORmMUuwSEYiHWNnjgxleQKIPztr={'thumb':hCfORmMUuwSEYiHWNnjgxleQKIPzJb,'poster':hCfORmMUuwSEYiHWNnjgxleQKIPzto,'fanart':hCfORmMUuwSEYiHWNnjgxleQKIPzJd}
    hCfORmMUuwSEYiHWNnjgxleQKIPztA =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['year']
    hCfORmMUuwSEYiHWNnjgxleQKIPztT =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['film_rating_code']
    hCfORmMUuwSEYiHWNnjgxleQKIPztk=hCfORmMUuwSEYiHWNnjgxleQKIPzpD['film_rating_short']
    hCfORmMUuwSEYiHWNnjgxleQKIPztd =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['film_rating_long']
    if hCfORmMUuwSEYiHWNnjgxleQKIPztX=='movies':
     hCfORmMUuwSEYiHWNnjgxleQKIPztb =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['duration']
    else:
     hCfORmMUuwSEYiHWNnjgxleQKIPztb ='0'
    hCfORmMUuwSEYiHWNnjgxleQKIPzta={'code':hCfORmMUuwSEYiHWNnjgxleQKIPztJ,'content_type':hCfORmMUuwSEYiHWNnjgxleQKIPztX,'title':hCfORmMUuwSEYiHWNnjgxleQKIPztL,'story':hCfORmMUuwSEYiHWNnjgxleQKIPzts,'thumbnail':hCfORmMUuwSEYiHWNnjgxleQKIPztr,'year':hCfORmMUuwSEYiHWNnjgxleQKIPztA,'film_rating_code':hCfORmMUuwSEYiHWNnjgxleQKIPztT,'film_rating_short':hCfORmMUuwSEYiHWNnjgxleQKIPztk,'film_rating_long':hCfORmMUuwSEYiHWNnjgxleQKIPztd,'duration':hCfORmMUuwSEYiHWNnjgxleQKIPztb,'badge':hCfORmMUuwSEYiHWNnjgxleQKIPztv,}
    hCfORmMUuwSEYiHWNnjgxleQKIPzpq.append(hCfORmMUuwSEYiHWNnjgxleQKIPzta)
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
  return hCfORmMUuwSEYiHWNnjgxleQKIPzpq,hCfORmMUuwSEYiHWNnjgxleQKIPztp
 def GetProgramInfo(hCfORmMUuwSEYiHWNnjgxleQKIPzat,program_code):
  hCfORmMUuwSEYiHWNnjgxleQKIPztq={}
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/contents/'+program_code
   hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
   hCfORmMUuwSEYiHWNnjgxleQKIPzps=hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzJG)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpG=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
   hCfORmMUuwSEYiHWNnjgxleQKIPztG=img_clearlogo=''
   hCfORmMUuwSEYiHWNnjgxleQKIPztG=hCfORmMUuwSEYiHWNnjgxleQKIPzpG.get('poster').get('original')
   if hCfORmMUuwSEYiHWNnjgxleQKIPzXJ(hCfORmMUuwSEYiHWNnjgxleQKIPzpG.get('title_logos'))>0:img_clearlogo=hCfORmMUuwSEYiHWNnjgxleQKIPzpG.get('title_logos')[0].get('src')
   hCfORmMUuwSEYiHWNnjgxleQKIPztq={'imgPoster':hCfORmMUuwSEYiHWNnjgxleQKIPztG,'imgClearlogo':img_clearlogo}
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
  return hCfORmMUuwSEYiHWNnjgxleQKIPztq
 def GetSeasonList(hCfORmMUuwSEYiHWNnjgxleQKIPzat,program_code):
  hCfORmMUuwSEYiHWNnjgxleQKIPztB=[]
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/aio_contents/'+program_code
   hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
   hCfORmMUuwSEYiHWNnjgxleQKIPzps =hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzJG)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpG=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
   if not('result' in hCfORmMUuwSEYiHWNnjgxleQKIPzpG):return hCfORmMUuwSEYiHWNnjgxleQKIPztB
   for hCfORmMUuwSEYiHWNnjgxleQKIPzpD in hCfORmMUuwSEYiHWNnjgxleQKIPzpG.get('result').get('seasons'):
    hCfORmMUuwSEYiHWNnjgxleQKIPztD =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['id']
    hCfORmMUuwSEYiHWNnjgxleQKIPztc =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['titles']['short']or hCfORmMUuwSEYiHWNnjgxleQKIPzpD['titles']['original']
    hCfORmMUuwSEYiHWNnjgxleQKIPzta={'seasonId':hCfORmMUuwSEYiHWNnjgxleQKIPztD,'seasonNm':hCfORmMUuwSEYiHWNnjgxleQKIPztc,}
    hCfORmMUuwSEYiHWNnjgxleQKIPztB.append(hCfORmMUuwSEYiHWNnjgxleQKIPzta)
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
  return hCfORmMUuwSEYiHWNnjgxleQKIPztB
 def GetEpisodoList(hCfORmMUuwSEYiHWNnjgxleQKIPzat,program_code,hCfORmMUuwSEYiHWNnjgxleQKIPzyT,orderby='asc'):
  hCfORmMUuwSEYiHWNnjgxleQKIPzpq=[]
  hCfORmMUuwSEYiHWNnjgxleQKIPztp=hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  hCfORmMUuwSEYiHWNnjgxleQKIPztV=''
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/contents/'+program_code+'/tv_episodes.json'
   hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
   hCfORmMUuwSEYiHWNnjgxleQKIPzty={'all':'true'}
   hCfORmMUuwSEYiHWNnjgxleQKIPzps =hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzty,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzJG)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpG=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
   if not('tv_episode_codes' in hCfORmMUuwSEYiHWNnjgxleQKIPzpG):return hCfORmMUuwSEYiHWNnjgxleQKIPzpq,hCfORmMUuwSEYiHWNnjgxleQKIPztp
   hCfORmMUuwSEYiHWNnjgxleQKIPzpB=hCfORmMUuwSEYiHWNnjgxleQKIPzpG['tv_episode_codes']
   hCfORmMUuwSEYiHWNnjgxleQKIPztF=hCfORmMUuwSEYiHWNnjgxleQKIPzXJ(hCfORmMUuwSEYiHWNnjgxleQKIPzpB)
   hCfORmMUuwSEYiHWNnjgxleQKIPzya =hCfORmMUuwSEYiHWNnjgxleQKIPzXy(hCfORmMUuwSEYiHWNnjgxleQKIPztF//(hCfORmMUuwSEYiHWNnjgxleQKIPzat.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    hCfORmMUuwSEYiHWNnjgxleQKIPzyp =(hCfORmMUuwSEYiHWNnjgxleQKIPztF-1)-((hCfORmMUuwSEYiHWNnjgxleQKIPzyT-1)*hCfORmMUuwSEYiHWNnjgxleQKIPzat.EPISODE_LIMIT)
   else:
    hCfORmMUuwSEYiHWNnjgxleQKIPzyp =(hCfORmMUuwSEYiHWNnjgxleQKIPzyT-1)*hCfORmMUuwSEYiHWNnjgxleQKIPzat.EPISODE_LIMIT
   for i in hCfORmMUuwSEYiHWNnjgxleQKIPzXa(hCfORmMUuwSEYiHWNnjgxleQKIPzat.EPISODE_LIMIT):
    if orderby=='desc':
     hCfORmMUuwSEYiHWNnjgxleQKIPzyt=hCfORmMUuwSEYiHWNnjgxleQKIPzyp-i
     if hCfORmMUuwSEYiHWNnjgxleQKIPzyt<0:break
    else:
     hCfORmMUuwSEYiHWNnjgxleQKIPzyt=hCfORmMUuwSEYiHWNnjgxleQKIPzyp+i
     if hCfORmMUuwSEYiHWNnjgxleQKIPzyt>=hCfORmMUuwSEYiHWNnjgxleQKIPztF:break
    if hCfORmMUuwSEYiHWNnjgxleQKIPztV!='':hCfORmMUuwSEYiHWNnjgxleQKIPztV+=','
    hCfORmMUuwSEYiHWNnjgxleQKIPztV+=hCfORmMUuwSEYiHWNnjgxleQKIPzpB[hCfORmMUuwSEYiHWNnjgxleQKIPzyt]
   if hCfORmMUuwSEYiHWNnjgxleQKIPzya>hCfORmMUuwSEYiHWNnjgxleQKIPzyT:hCfORmMUuwSEYiHWNnjgxleQKIPztp=hCfORmMUuwSEYiHWNnjgxleQKIPzJc
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
  hCfORmMUuwSEYiHWNnjgxleQKIPzyJ=hCfORmMUuwSEYiHWNnjgxleQKIPzat.GetProgramInfo(program_code)
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
   hCfORmMUuwSEYiHWNnjgxleQKIPzty={'codes':hCfORmMUuwSEYiHWNnjgxleQKIPztV}
   hCfORmMUuwSEYiHWNnjgxleQKIPzps =hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzty,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzJG)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpG=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
   if not('tv_episodes' in hCfORmMUuwSEYiHWNnjgxleQKIPzpG):return hCfORmMUuwSEYiHWNnjgxleQKIPzpq
   hCfORmMUuwSEYiHWNnjgxleQKIPzpB=hCfORmMUuwSEYiHWNnjgxleQKIPzpG['tv_episodes']
   for hCfORmMUuwSEYiHWNnjgxleQKIPzpD in hCfORmMUuwSEYiHWNnjgxleQKIPzpB:
    hCfORmMUuwSEYiHWNnjgxleQKIPztJ =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['code']
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpD['title']:
     hCfORmMUuwSEYiHWNnjgxleQKIPztL =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['title']
    else:
     hCfORmMUuwSEYiHWNnjgxleQKIPztL =''
    hCfORmMUuwSEYiHWNnjgxleQKIPzto=hCfORmMUuwSEYiHWNnjgxleQKIPzJb=hCfORmMUuwSEYiHWNnjgxleQKIPzJd=hCfORmMUuwSEYiHWNnjgxleQKIPzyX=''
    hCfORmMUuwSEYiHWNnjgxleQKIPzto =hCfORmMUuwSEYiHWNnjgxleQKIPzyJ.get('imgPoster')
    hCfORmMUuwSEYiHWNnjgxleQKIPzyX=hCfORmMUuwSEYiHWNnjgxleQKIPzyJ.get('imgClearlogo')
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('stillcut') !=hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPzJb =hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('stillcut').get('large')
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('tv_season_stillcut')!=hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPzJd=hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('tv_season_stillcut').get('large')
    hCfORmMUuwSEYiHWNnjgxleQKIPztr={'thumb':hCfORmMUuwSEYiHWNnjgxleQKIPzJb,'poster':hCfORmMUuwSEYiHWNnjgxleQKIPzto,'fanart':hCfORmMUuwSEYiHWNnjgxleQKIPzJd,'clearlogo':hCfORmMUuwSEYiHWNnjgxleQKIPzyX}
    hCfORmMUuwSEYiHWNnjgxleQKIPzyL =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['display_number']
    hCfORmMUuwSEYiHWNnjgxleQKIPzys=hCfORmMUuwSEYiHWNnjgxleQKIPzpD['tv_season_title']
    hCfORmMUuwSEYiHWNnjgxleQKIPztb =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['duration']
    try:
     hCfORmMUuwSEYiHWNnjgxleQKIPzyv=hCfORmMUuwSEYiHWNnjgxleQKIPzpD['episode_number']
    except:
     hCfORmMUuwSEYiHWNnjgxleQKIPzyv='0'
    hCfORmMUuwSEYiHWNnjgxleQKIPzta={'code':hCfORmMUuwSEYiHWNnjgxleQKIPztJ,'title':hCfORmMUuwSEYiHWNnjgxleQKIPztL,'thumbnail':hCfORmMUuwSEYiHWNnjgxleQKIPztr,'display_num':hCfORmMUuwSEYiHWNnjgxleQKIPzyL,'season_title':hCfORmMUuwSEYiHWNnjgxleQKIPzys,'duration':hCfORmMUuwSEYiHWNnjgxleQKIPztb,'episode_number':hCfORmMUuwSEYiHWNnjgxleQKIPzyv}
    hCfORmMUuwSEYiHWNnjgxleQKIPzpq.append(hCfORmMUuwSEYiHWNnjgxleQKIPzta)
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
  return hCfORmMUuwSEYiHWNnjgxleQKIPzpq,hCfORmMUuwSEYiHWNnjgxleQKIPztp
 def GetHomeList_bak(hCfORmMUuwSEYiHWNnjgxleQKIPzat):
  hCfORmMUuwSEYiHWNnjgxleQKIPzyo=[]
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/aio_browses/video/header'
   hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
   hCfORmMUuwSEYiHWNnjgxleQKIPzps=hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpJ=hCfORmMUuwSEYiHWNnjgxleQKIPzat.makeDefaultCookies()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzpJ)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpd=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
   if not('result' in hCfORmMUuwSEYiHWNnjgxleQKIPzpd):return hCfORmMUuwSEYiHWNnjgxleQKIPzyo
   hCfORmMUuwSEYiHWNnjgxleQKIPzpB=hCfORmMUuwSEYiHWNnjgxleQKIPzpd['result'][0]['cells']
   for hCfORmMUuwSEYiHWNnjgxleQKIPzpD in hCfORmMUuwSEYiHWNnjgxleQKIPzpB:
    hCfORmMUuwSEYiHWNnjgxleQKIPztX=hCfORmMUuwSEYiHWNnjgxleQKIPzpD['relations'][0]['type']
    hCfORmMUuwSEYiHWNnjgxleQKIPztL =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['title']
    hCfORmMUuwSEYiHWNnjgxleQKIPzyr =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['badge']
    hCfORmMUuwSEYiHWNnjgxleQKIPzyA =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['media']['fullhd']
    hCfORmMUuwSEYiHWNnjgxleQKIPztr ={'thumb':hCfORmMUuwSEYiHWNnjgxleQKIPzyA,'fanart':hCfORmMUuwSEYiHWNnjgxleQKIPzyA}
    hCfORmMUuwSEYiHWNnjgxleQKIPztJ =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['relations'][0]['id']
    hCfORmMUuwSEYiHWNnjgxleQKIPzta={'code':hCfORmMUuwSEYiHWNnjgxleQKIPztJ,'content_type':hCfORmMUuwSEYiHWNnjgxleQKIPztX,'title':hCfORmMUuwSEYiHWNnjgxleQKIPztL,'bedge':hCfORmMUuwSEYiHWNnjgxleQKIPzyr,'thumbnail':hCfORmMUuwSEYiHWNnjgxleQKIPztr}
    hCfORmMUuwSEYiHWNnjgxleQKIPzyo.append(hCfORmMUuwSEYiHWNnjgxleQKIPzta)
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
  return hCfORmMUuwSEYiHWNnjgxleQKIPzyo
 def GetHomeList(hCfORmMUuwSEYiHWNnjgxleQKIPzat):
  hCfORmMUuwSEYiHWNnjgxleQKIPzyo=[]
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/aio_browses/video/all'
   hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
   hCfORmMUuwSEYiHWNnjgxleQKIPzps=hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpJ=hCfORmMUuwSEYiHWNnjgxleQKIPzat.makeDefaultCookies()
   hCfORmMUuwSEYiHWNnjgxleQKIPzyT=1
   hCfORmMUuwSEYiHWNnjgxleQKIPztp=hCfORmMUuwSEYiHWNnjgxleQKIPzJc
   while hCfORmMUuwSEYiHWNnjgxleQKIPztp:
    hCfORmMUuwSEYiHWNnjgxleQKIPzay={'page':hCfORmMUuwSEYiHWNnjgxleQKIPzJF(hCfORmMUuwSEYiHWNnjgxleQKIPzyT)}
    hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzay,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzpJ)
    hCfORmMUuwSEYiHWNnjgxleQKIPzpd=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
    if not('result' in hCfORmMUuwSEYiHWNnjgxleQKIPzpd):return hCfORmMUuwSEYiHWNnjgxleQKIPzyo
    hCfORmMUuwSEYiHWNnjgxleQKIPzpB=hCfORmMUuwSEYiHWNnjgxleQKIPzpd['result']['items']
    for hCfORmMUuwSEYiHWNnjgxleQKIPzpD in hCfORmMUuwSEYiHWNnjgxleQKIPzpB:
     hCfORmMUuwSEYiHWNnjgxleQKIPztX=hCfORmMUuwSEYiHWNnjgxleQKIPzpD['type']
     if hCfORmMUuwSEYiHWNnjgxleQKIPztX in['custom_list']:
      hCfORmMUuwSEYiHWNnjgxleQKIPzta={'code':hCfORmMUuwSEYiHWNnjgxleQKIPzpD['relations'][0]['id'],'content_type':hCfORmMUuwSEYiHWNnjgxleQKIPzpD['relations'][0]['type'],'title':hCfORmMUuwSEYiHWNnjgxleQKIPzpD['title'],}
      hCfORmMUuwSEYiHWNnjgxleQKIPzyo.append(hCfORmMUuwSEYiHWNnjgxleQKIPzta)
    hCfORmMUuwSEYiHWNnjgxleQKIPzyT+=1
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpd['result']['next']==hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPztp=hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
  return hCfORmMUuwSEYiHWNnjgxleQKIPzyo
 def GetSearchList(hCfORmMUuwSEYiHWNnjgxleQKIPzat,search_key,hCfORmMUuwSEYiHWNnjgxleQKIPzyT):
  hCfORmMUuwSEYiHWNnjgxleQKIPzyk=[]
  hCfORmMUuwSEYiHWNnjgxleQKIPztp=hCfORmMUuwSEYiHWNnjgxleQKIPzJB
  try:
   hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/search.json'
   hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
   hCfORmMUuwSEYiHWNnjgxleQKIPzty={'query':search_key,'page':hCfORmMUuwSEYiHWNnjgxleQKIPzJF(hCfORmMUuwSEYiHWNnjgxleQKIPzyT),'per':hCfORmMUuwSEYiHWNnjgxleQKIPzJF(hCfORmMUuwSEYiHWNnjgxleQKIPzat.SEARCH_LIMIT),'exclude':'limited'}
   hCfORmMUuwSEYiHWNnjgxleQKIPzps=hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzty,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzJG)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpG=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
   if not('results' in hCfORmMUuwSEYiHWNnjgxleQKIPzpG):return hCfORmMUuwSEYiHWNnjgxleQKIPzyk,hCfORmMUuwSEYiHWNnjgxleQKIPztp
   hCfORmMUuwSEYiHWNnjgxleQKIPzpB=hCfORmMUuwSEYiHWNnjgxleQKIPzpG['results']
   hCfORmMUuwSEYiHWNnjgxleQKIPztp=hCfORmMUuwSEYiHWNnjgxleQKIPzpG['meta']['has_next']
   for hCfORmMUuwSEYiHWNnjgxleQKIPzpD in hCfORmMUuwSEYiHWNnjgxleQKIPzpB:
    hCfORmMUuwSEYiHWNnjgxleQKIPztJ =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['code']
    hCfORmMUuwSEYiHWNnjgxleQKIPztX=hCfORmMUuwSEYiHWNnjgxleQKIPzpD['content_type']
    hCfORmMUuwSEYiHWNnjgxleQKIPztL =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['title']
    hCfORmMUuwSEYiHWNnjgxleQKIPzts =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['story']
    hCfORmMUuwSEYiHWNnjgxleQKIPzto=hCfORmMUuwSEYiHWNnjgxleQKIPzJb=hCfORmMUuwSEYiHWNnjgxleQKIPzJd=''
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('poster') !=hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPzto=hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('poster').get('original')
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('stillcut')!=hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPzJb =hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('stillcut').get('large')
    if hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('thumbnail')!=hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPzJd=hCfORmMUuwSEYiHWNnjgxleQKIPzpD.get('thumbnail').get('large')
    if hCfORmMUuwSEYiHWNnjgxleQKIPzJd=='' :hCfORmMUuwSEYiHWNnjgxleQKIPzJd=hCfORmMUuwSEYiHWNnjgxleQKIPzJb
    hCfORmMUuwSEYiHWNnjgxleQKIPztr={'thumb':hCfORmMUuwSEYiHWNnjgxleQKIPzJb,'poster':hCfORmMUuwSEYiHWNnjgxleQKIPzto,'fanart':hCfORmMUuwSEYiHWNnjgxleQKIPzJd}
    hCfORmMUuwSEYiHWNnjgxleQKIPztA =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['year']
    hCfORmMUuwSEYiHWNnjgxleQKIPztT =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['film_rating_code']
    hCfORmMUuwSEYiHWNnjgxleQKIPztk=hCfORmMUuwSEYiHWNnjgxleQKIPzpD['film_rating_short']
    hCfORmMUuwSEYiHWNnjgxleQKIPztd =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['film_rating_long']
    if hCfORmMUuwSEYiHWNnjgxleQKIPztX=='movies':
     hCfORmMUuwSEYiHWNnjgxleQKIPztb =hCfORmMUuwSEYiHWNnjgxleQKIPzpD['duration']
    else:
     hCfORmMUuwSEYiHWNnjgxleQKIPztb ='0'
    hCfORmMUuwSEYiHWNnjgxleQKIPzta={'code':hCfORmMUuwSEYiHWNnjgxleQKIPztJ,'content_type':hCfORmMUuwSEYiHWNnjgxleQKIPztX,'title':hCfORmMUuwSEYiHWNnjgxleQKIPztL,'story':hCfORmMUuwSEYiHWNnjgxleQKIPzts,'thumbnail':hCfORmMUuwSEYiHWNnjgxleQKIPztr,'year':hCfORmMUuwSEYiHWNnjgxleQKIPztA,'film_rating_code':hCfORmMUuwSEYiHWNnjgxleQKIPztT,'film_rating_short':hCfORmMUuwSEYiHWNnjgxleQKIPztk,'film_rating_long':hCfORmMUuwSEYiHWNnjgxleQKIPztd,'duration':hCfORmMUuwSEYiHWNnjgxleQKIPztb}
    hCfORmMUuwSEYiHWNnjgxleQKIPzyk.append(hCfORmMUuwSEYiHWNnjgxleQKIPzta)
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
  return hCfORmMUuwSEYiHWNnjgxleQKIPzyk,hCfORmMUuwSEYiHWNnjgxleQKIPztp
 def DeleteContinueList(hCfORmMUuwSEYiHWNnjgxleQKIPzat,codeList):
  try:
   for hCfORmMUuwSEYiHWNnjgxleQKIPzyd in codeList:
    hCfORmMUuwSEYiHWNnjgxleQKIPzpT ='/api/watches/'+hCfORmMUuwSEYiHWNnjgxleQKIPzyd
    hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
    hCfORmMUuwSEYiHWNnjgxleQKIPzps =hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
    hCfORmMUuwSEYiHWNnjgxleQKIPzpr =hCfORmMUuwSEYiHWNnjgxleQKIPzat.makeDefaultCookies()
    hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Delete',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,params=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzpr)
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   hCfORmMUuwSEYiHWNnjgxleQKIPzXt(exception)
 def Get_Now_Datetime(hCfORmMUuwSEYiHWNnjgxleQKIPzat):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(hCfORmMUuwSEYiHWNnjgxleQKIPzat,movie_code,quality_str,proxyUse=hCfORmMUuwSEYiHWNnjgxleQKIPzJB,inScreen='BASE',inSound='2CH'):
  hCfORmMUuwSEYiHWNnjgxleQKIPzyq={'streamUrl':'','subtitleUrl':'','customdata':'',}
  try:
   if proxyUse:
    hCfORmMUuwSEYiHWNnjgxleQKIPzyG ='0' if inScreen=='BASE' and inSound=='2CH' else '3'
    hCfORmMUuwSEYiHWNnjgxleQKIPzyB='4' if inScreen=='VISION' else '1'
    hCfORmMUuwSEYiHWNnjgxleQKIPzyD ='0' if inSound!='ATMOS' else '1'
    hCfORmMUuwSEYiHWNnjgxleQKIPzXt('hCodec  = '+hCfORmMUuwSEYiHWNnjgxleQKIPzyG)
    hCfORmMUuwSEYiHWNnjgxleQKIPzXt('hScreen = '+hCfORmMUuwSEYiHWNnjgxleQKIPzyB)
    hCfORmMUuwSEYiHWNnjgxleQKIPzXt('hSound  = '+hCfORmMUuwSEYiHWNnjgxleQKIPzyD)
    hCfORmMUuwSEYiHWNnjgxleQKIPzpT='/api/watch/'+movie_code+'.json?localtracks=%5B%5D&player_v2=true'
    hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
    hCfORmMUuwSEYiHWNnjgxleQKIPzps=hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers_v2()
    hCfORmMUuwSEYiHWNnjgxleQKIPzpv={'X-FROGRAMS-MARS-CODEC-FLAG':hCfORmMUuwSEYiHWNnjgxleQKIPzyG,'X-WatchaPlay-Client-Codec-Flag':hCfORmMUuwSEYiHWNnjgxleQKIPzyG,'X-FROGRAMS-MARS-HDR-CAPABILITIES':hCfORmMUuwSEYiHWNnjgxleQKIPzyB,'X-WatchaPlay-Client-HDR-Capabilities':hCfORmMUuwSEYiHWNnjgxleQKIPzyB,'X-FROGRAMS-MARS-AUDIO-CAPABILITIES':hCfORmMUuwSEYiHWNnjgxleQKIPzyD,'X-WatchaPlay-Client-Audio-Capabilities':hCfORmMUuwSEYiHWNnjgxleQKIPzyD,}
    hCfORmMUuwSEYiHWNnjgxleQKIPzps.update(hCfORmMUuwSEYiHWNnjgxleQKIPzpv)
   else:
    hCfORmMUuwSEYiHWNnjgxleQKIPzpT='/api/watch/'+movie_code+'.json'
    hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+hCfORmMUuwSEYiHWNnjgxleQKIPzpT
    hCfORmMUuwSEYiHWNnjgxleQKIPzps=hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
    hCfORmMUuwSEYiHWNnjgxleQKIPzpv={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str,}
    hCfORmMUuwSEYiHWNnjgxleQKIPzps.update(hCfORmMUuwSEYiHWNnjgxleQKIPzpv)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpr=hCfORmMUuwSEYiHWNnjgxleQKIPzat.makeDefaultCookies()
   hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzpr)
   hCfORmMUuwSEYiHWNnjgxleQKIPzpG=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
   hCfORmMUuwSEYiHWNnjgxleQKIPzyq['streamUrl']=hCfORmMUuwSEYiHWNnjgxleQKIPzpG['streams'][0]['source']
   if hCfORmMUuwSEYiHWNnjgxleQKIPzyq['streamUrl']==hCfORmMUuwSEYiHWNnjgxleQKIPzJG:return hCfORmMUuwSEYiHWNnjgxleQKIPzyq
   if 'subtitles' in hCfORmMUuwSEYiHWNnjgxleQKIPzpG['streams'][0]:
    for hCfORmMUuwSEYiHWNnjgxleQKIPzyc in hCfORmMUuwSEYiHWNnjgxleQKIPzpG['streams'][0]['subtitles']:
     if hCfORmMUuwSEYiHWNnjgxleQKIPzyc['lang']=='ko':
      hCfORmMUuwSEYiHWNnjgxleQKIPzyq['subtitleUrl']=hCfORmMUuwSEYiHWNnjgxleQKIPzyc['url']
      break
   hCfORmMUuwSEYiHWNnjgxleQKIPzyV =hCfORmMUuwSEYiHWNnjgxleQKIPzpG['ping_payload']
   hCfORmMUuwSEYiHWNnjgxleQKIPzyF =hCfORmMUuwSEYiHWNnjgxleQKIPzat.WC['cookies']['watcha_usercd']
   hCfORmMUuwSEYiHWNnjgxleQKIPzJa={'merchant':'giitd_frograms','sessionId':hCfORmMUuwSEYiHWNnjgxleQKIPzyV,'userId':hCfORmMUuwSEYiHWNnjgxleQKIPzyF}
   hCfORmMUuwSEYiHWNnjgxleQKIPzJp=json.dumps(hCfORmMUuwSEYiHWNnjgxleQKIPzJa,separators=(",",":")).encode('UTF-8')
   hCfORmMUuwSEYiHWNnjgxleQKIPzyq['customdata']=base64.b64encode(hCfORmMUuwSEYiHWNnjgxleQKIPzJp)
  except hCfORmMUuwSEYiHWNnjgxleQKIPzXp as exception:
   return hCfORmMUuwSEYiHWNnjgxleQKIPzyq
  return hCfORmMUuwSEYiHWNnjgxleQKIPzyq
 def GetBookmarkInfo(hCfORmMUuwSEYiHWNnjgxleQKIPzat,videoid,vidtype):
  hCfORmMUuwSEYiHWNnjgxleQKIPzJt={'indexinfo':{'ott':'watcha','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  hCfORmMUuwSEYiHWNnjgxleQKIPzpk=hCfORmMUuwSEYiHWNnjgxleQKIPzat.API_DOMAIN+'/api/contents/'+videoid
  hCfORmMUuwSEYiHWNnjgxleQKIPzps=hCfORmMUuwSEYiHWNnjgxleQKIPzat.Get_Base_Headers()
  hCfORmMUuwSEYiHWNnjgxleQKIPzpo=hCfORmMUuwSEYiHWNnjgxleQKIPzat.callRequestCookies('Get',hCfORmMUuwSEYiHWNnjgxleQKIPzpk,payload=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,params=hCfORmMUuwSEYiHWNnjgxleQKIPzJG,headers=hCfORmMUuwSEYiHWNnjgxleQKIPzps,cookies=hCfORmMUuwSEYiHWNnjgxleQKIPzJG)
  hCfORmMUuwSEYiHWNnjgxleQKIPzpd=json.loads(hCfORmMUuwSEYiHWNnjgxleQKIPzpo.text)
  if not('title' in hCfORmMUuwSEYiHWNnjgxleQKIPzpd):return{}
  hCfORmMUuwSEYiHWNnjgxleQKIPzJy=hCfORmMUuwSEYiHWNnjgxleQKIPzpd
  hCfORmMUuwSEYiHWNnjgxleQKIPzXt(hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('duration'))
  hCfORmMUuwSEYiHWNnjgxleQKIPzJX=hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('title')
  hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['infoLabels']['title']=hCfORmMUuwSEYiHWNnjgxleQKIPzJX
  hCfORmMUuwSEYiHWNnjgxleQKIPzJX +=u'  (%s)'%(hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('year'))
  hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['title'] =hCfORmMUuwSEYiHWNnjgxleQKIPzJX
  hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['infoLabels']['mpaa'] =hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('film_rating_long')
  hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['infoLabels']['plot'] =hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('story').replace('<br>','\n')
  hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['infoLabels']['year'] =hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('year')
  if vidtype=='movie':
   hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['infoLabels']['duration']=hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('duration')
  hCfORmMUuwSEYiHWNnjgxleQKIPzJL=[]
  for hCfORmMUuwSEYiHWNnjgxleQKIPzJs in hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('actors'):
   hCfORmMUuwSEYiHWNnjgxleQKIPzJv =hCfORmMUuwSEYiHWNnjgxleQKIPzJs.get('name')
   hCfORmMUuwSEYiHWNnjgxleQKIPzJo='' if hCfORmMUuwSEYiHWNnjgxleQKIPzJs.get('photo')==hCfORmMUuwSEYiHWNnjgxleQKIPzJG else hCfORmMUuwSEYiHWNnjgxleQKIPzJs.get('photo').get('small')
   hCfORmMUuwSEYiHWNnjgxleQKIPzJL.append({'name':hCfORmMUuwSEYiHWNnjgxleQKIPzJv,'thumbnail':hCfORmMUuwSEYiHWNnjgxleQKIPzJo})
  if hCfORmMUuwSEYiHWNnjgxleQKIPzXJ(hCfORmMUuwSEYiHWNnjgxleQKIPzJL)>0:
   hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['infoLabels']['cast']=hCfORmMUuwSEYiHWNnjgxleQKIPzJL
  hCfORmMUuwSEYiHWNnjgxleQKIPzJr=[]
  for hCfORmMUuwSEYiHWNnjgxleQKIPzJA in hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('directors'):hCfORmMUuwSEYiHWNnjgxleQKIPzJr.append(hCfORmMUuwSEYiHWNnjgxleQKIPzJA.get('name'))
  if hCfORmMUuwSEYiHWNnjgxleQKIPzXJ(hCfORmMUuwSEYiHWNnjgxleQKIPzJr)>0:
   hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['infoLabels']['director']=hCfORmMUuwSEYiHWNnjgxleQKIPzJr
  hCfORmMUuwSEYiHWNnjgxleQKIPzJT=[]
  for hCfORmMUuwSEYiHWNnjgxleQKIPzJk in hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('genres'):hCfORmMUuwSEYiHWNnjgxleQKIPzJT.append(hCfORmMUuwSEYiHWNnjgxleQKIPzJk.get('name'))
  if hCfORmMUuwSEYiHWNnjgxleQKIPzXJ(hCfORmMUuwSEYiHWNnjgxleQKIPzJT)>0:
   hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['infoLabels']['genre']=hCfORmMUuwSEYiHWNnjgxleQKIPzJT
  hCfORmMUuwSEYiHWNnjgxleQKIPzto =''
  hCfORmMUuwSEYiHWNnjgxleQKIPzJd =''
  hCfORmMUuwSEYiHWNnjgxleQKIPzJb =''
  if hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('poster') !=hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPzto =hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('poster').get('original')
  if hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('thumbnail')!=hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPzJd =hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('thumbnail').get('large')
  if hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('stillcut')!=hCfORmMUuwSEYiHWNnjgxleQKIPzJG:hCfORmMUuwSEYiHWNnjgxleQKIPzJb =hCfORmMUuwSEYiHWNnjgxleQKIPzJy.get('stillcut').get('large')
  if hCfORmMUuwSEYiHWNnjgxleQKIPzJd=='':hCfORmMUuwSEYiHWNnjgxleQKIPzJd=hCfORmMUuwSEYiHWNnjgxleQKIPzJb
  hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['thumbnail']['poster']=hCfORmMUuwSEYiHWNnjgxleQKIPzto
  hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['thumbnail']['fanart']=hCfORmMUuwSEYiHWNnjgxleQKIPzJd
  hCfORmMUuwSEYiHWNnjgxleQKIPzJt['saveinfo']['thumbnail']['thumb']=hCfORmMUuwSEYiHWNnjgxleQKIPzJb
  return hCfORmMUuwSEYiHWNnjgxleQKIPzJt
# Created by pyminifier (https://github.com/liftoff/pyminifier)
