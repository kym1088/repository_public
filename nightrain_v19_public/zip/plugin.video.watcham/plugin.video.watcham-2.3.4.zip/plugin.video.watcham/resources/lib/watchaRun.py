__author__="NightRain"
jnbluXPrJKBdYcykaNCDsiLEoFHTWz=object
jnbluXPrJKBdYcykaNCDsiLEoFHTWe=None
jnbluXPrJKBdYcykaNCDsiLEoFHTWO=int
jnbluXPrJKBdYcykaNCDsiLEoFHTWx=True
jnbluXPrJKBdYcykaNCDsiLEoFHTWV=False
jnbluXPrJKBdYcykaNCDsiLEoFHTWh=type
jnbluXPrJKBdYcykaNCDsiLEoFHTWG=dict
jnbluXPrJKBdYcykaNCDsiLEoFHTWM=getattr
jnbluXPrJKBdYcykaNCDsiLEoFHTWS=list
jnbluXPrJKBdYcykaNCDsiLEoFHTWI=len
jnbluXPrJKBdYcykaNCDsiLEoFHTWg=range
jnbluXPrJKBdYcykaNCDsiLEoFHTWq=str
jnbluXPrJKBdYcykaNCDsiLEoFHTWU=open
from ast import Pass
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
jnbluXPrJKBdYcykaNCDsiLEoFHTfR=[{'title':'홈','mode':'HOME_GROUP','stype':'-','api_path':'-'},{'title':'오직 왓챠에서!','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/6100'},{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409'},{'title':'4K / HDR, ATOMOS 지원작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/3025'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest'},{'title':'장르별 둘러보기','mode':'SUB_GROUP','stype':'genres','api_path':'-'},{'title':'특징별 둘러보기','mode':'SUB_GROUP','stype':'tags','api_path':'-'},{'title':'이어보기 (시청이력)','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','icon':'bookmark.png'},]
jnbluXPrJKBdYcykaNCDsiLEoFHTfw=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
jnbluXPrJKBdYcykaNCDsiLEoFHTfQ={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
jnbluXPrJKBdYcykaNCDsiLEoFHTfm=40
jnbluXPrJKBdYcykaNCDsiLEoFHTfv =30
from watchaCore import*
class jnbluXPrJKBdYcykaNCDsiLEoFHTfA(jnbluXPrJKBdYcykaNCDsiLEoFHTWz):
 def __init__(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,jnbluXPrJKBdYcykaNCDsiLEoFHTft,jnbluXPrJKBdYcykaNCDsiLEoFHTfz,jnbluXPrJKBdYcykaNCDsiLEoFHTfe):
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_url =jnbluXPrJKBdYcykaNCDsiLEoFHTft
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle=jnbluXPrJKBdYcykaNCDsiLEoFHTfz
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params =jnbluXPrJKBdYcykaNCDsiLEoFHTfe
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj =hCfORmMUuwSEYiHWNnjgxleQKIPzap() 
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_SUBTITLE_VTT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_SUBTITLE_SRT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.srt'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_COOKIE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_SEARCHEDC_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wc_stream.mpd'))
 def addon_noti(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,sting):
  try:
   jnbluXPrJKBdYcykaNCDsiLEoFHTfx=xbmcgui.Dialog()
   jnbluXPrJKBdYcykaNCDsiLEoFHTfx.notification(__addonname__,sting)
  except:
   jnbluXPrJKBdYcykaNCDsiLEoFHTWe
 def addon_log(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,string):
  try:
   jnbluXPrJKBdYcykaNCDsiLEoFHTfV=string.encode('utf-8','ignore')
  except:
   jnbluXPrJKBdYcykaNCDsiLEoFHTfV='addonException: addon_log'
  jnbluXPrJKBdYcykaNCDsiLEoFHTfh=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,jnbluXPrJKBdYcykaNCDsiLEoFHTfV),level=jnbluXPrJKBdYcykaNCDsiLEoFHTfh)
 def get_keyboard_input(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,jnbluXPrJKBdYcykaNCDsiLEoFHTAG):
  jnbluXPrJKBdYcykaNCDsiLEoFHTfG=jnbluXPrJKBdYcykaNCDsiLEoFHTWe
  kb=xbmc.Keyboard()
  kb.setHeading(jnbluXPrJKBdYcykaNCDsiLEoFHTAG)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   jnbluXPrJKBdYcykaNCDsiLEoFHTfG=kb.getText()
  return jnbluXPrJKBdYcykaNCDsiLEoFHTfG
 def get_settings_account(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  jnbluXPrJKBdYcykaNCDsiLEoFHTfM =__addon__.getSetting('id')
  jnbluXPrJKBdYcykaNCDsiLEoFHTfS =__addon__.getSetting('pw')
  jnbluXPrJKBdYcykaNCDsiLEoFHTfI=jnbluXPrJKBdYcykaNCDsiLEoFHTWO(__addon__.getSetting('selected_profile'))
  return(jnbluXPrJKBdYcykaNCDsiLEoFHTfM,jnbluXPrJKBdYcykaNCDsiLEoFHTfS,jnbluXPrJKBdYcykaNCDsiLEoFHTfI)
 def get_settings_totalsearch(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  jnbluXPrJKBdYcykaNCDsiLEoFHTfg =jnbluXPrJKBdYcykaNCDsiLEoFHTWx if __addon__.getSetting('local_search')=='true' else jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  jnbluXPrJKBdYcykaNCDsiLEoFHTfq=jnbluXPrJKBdYcykaNCDsiLEoFHTWx if __addon__.getSetting('local_history')=='true' else jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  jnbluXPrJKBdYcykaNCDsiLEoFHTfU =jnbluXPrJKBdYcykaNCDsiLEoFHTWx if __addon__.getSetting('total_search')=='true' else jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  jnbluXPrJKBdYcykaNCDsiLEoFHTfp=jnbluXPrJKBdYcykaNCDsiLEoFHTWx if __addon__.getSetting('total_history')=='true' else jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  jnbluXPrJKBdYcykaNCDsiLEoFHTAf=jnbluXPrJKBdYcykaNCDsiLEoFHTWx if __addon__.getSetting('menu_bookmark')=='true' else jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  return(jnbluXPrJKBdYcykaNCDsiLEoFHTfg,jnbluXPrJKBdYcykaNCDsiLEoFHTfq,jnbluXPrJKBdYcykaNCDsiLEoFHTfU,jnbluXPrJKBdYcykaNCDsiLEoFHTfp,jnbluXPrJKBdYcykaNCDsiLEoFHTAf)
 def get_settings_makebookmark(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  return jnbluXPrJKBdYcykaNCDsiLEoFHTWx if __addon__.getSetting('make_bookmark')=='true' else jnbluXPrJKBdYcykaNCDsiLEoFHTWV
 def get_settings_proxyport(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  jnbluXPrJKBdYcykaNCDsiLEoFHTAR =jnbluXPrJKBdYcykaNCDsiLEoFHTWx if __addon__.getSetting('proxyYn')=='true' else jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  jnbluXPrJKBdYcykaNCDsiLEoFHTAw=jnbluXPrJKBdYcykaNCDsiLEoFHTWO(__addon__.getSetting('proxyPort'))
  return jnbluXPrJKBdYcykaNCDsiLEoFHTAR,jnbluXPrJKBdYcykaNCDsiLEoFHTAw
 def get_settings_playback(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  jnbluXPrJKBdYcykaNCDsiLEoFHTAQ=[3840,1920,1280]
  jnbluXPrJKBdYcykaNCDsiLEoFHTAm =['BASE','HDR','VISION']
  jnbluXPrJKBdYcykaNCDsiLEoFHTAv =['2CH','6CH','ATMOS']
  jnbluXPrJKBdYcykaNCDsiLEoFHTAW=jnbluXPrJKBdYcykaNCDsiLEoFHTWO(__addon__.getSetting('selected_quality'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTAt =jnbluXPrJKBdYcykaNCDsiLEoFHTWO(__addon__.getSetting('selected_screen'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTAz =jnbluXPrJKBdYcykaNCDsiLEoFHTWO(__addon__.getSetting('selected_sound'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTAe={'max_quality':jnbluXPrJKBdYcykaNCDsiLEoFHTAQ[jnbluXPrJKBdYcykaNCDsiLEoFHTAW],'sel_screen':jnbluXPrJKBdYcykaNCDsiLEoFHTAm[jnbluXPrJKBdYcykaNCDsiLEoFHTAt],'sel_sound':jnbluXPrJKBdYcykaNCDsiLEoFHTAv[jnbluXPrJKBdYcykaNCDsiLEoFHTAz],'streamFilename':jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_STREAM_FILENAME,}
  return jnbluXPrJKBdYcykaNCDsiLEoFHTAe
 def Base64_Encode(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,plaintext):
  return base64.standard_b64encode(plaintext.encode()).decode('utf-8')
 def Params_JsonToStr(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,paramJson):
  jnbluXPrJKBdYcykaNCDsiLEoFHTAO=json.dumps(paramJson,separators=(',',':'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTAO=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.Base64_Encode(jnbluXPrJKBdYcykaNCDsiLEoFHTAO)
  return jnbluXPrJKBdYcykaNCDsiLEoFHTAO
 def get_selQuality(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  try:
   jnbluXPrJKBdYcykaNCDsiLEoFHTAQ=['3840x2160/2.0/320/xhdpi','1920x1080/2.0/320/xhdpi','1280x720/2.0/320/xhdpi']
   jnbluXPrJKBdYcykaNCDsiLEoFHTAW=jnbluXPrJKBdYcykaNCDsiLEoFHTWO(__addon__.getSetting('selected_quality'))
   return jnbluXPrJKBdYcykaNCDsiLEoFHTAQ[jnbluXPrJKBdYcykaNCDsiLEoFHTAW]
  except:
   jnbluXPrJKBdYcykaNCDsiLEoFHTWe
  return 1080 
 def get_settings_direct_replay(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  jnbluXPrJKBdYcykaNCDsiLEoFHTAx=jnbluXPrJKBdYcykaNCDsiLEoFHTWO(__addon__.getSetting('direct_replay'))
  if jnbluXPrJKBdYcykaNCDsiLEoFHTAx==0:
   return jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  else:
   return jnbluXPrJKBdYcykaNCDsiLEoFHTWx
 def set_winEpisodeOrderby(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,jnbluXPrJKBdYcykaNCDsiLEoFHTAV):
  __addon__.setSetting('watcha_orderby',jnbluXPrJKBdYcykaNCDsiLEoFHTAV)
 def get_winEpisodeOrderby(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  jnbluXPrJKBdYcykaNCDsiLEoFHTAV=__addon__.getSetting('watcha_orderby')
  if jnbluXPrJKBdYcykaNCDsiLEoFHTAV in['',jnbluXPrJKBdYcykaNCDsiLEoFHTWe]:jnbluXPrJKBdYcykaNCDsiLEoFHTAV='asc'
  return jnbluXPrJKBdYcykaNCDsiLEoFHTAV
 def dp_setEpOrderby(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTAV =args.get('orderby')
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.set_winEpisodeOrderby(jnbluXPrJKBdYcykaNCDsiLEoFHTAV)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,label,sublabel='',img='',infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWx,params='',isLink=jnbluXPrJKBdYcykaNCDsiLEoFHTWV,ContextMenu=jnbluXPrJKBdYcykaNCDsiLEoFHTWe):
  jnbluXPrJKBdYcykaNCDsiLEoFHTAh='%s?%s'%(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_url,urllib.parse.urlencode(params))
  if sublabel:jnbluXPrJKBdYcykaNCDsiLEoFHTAG='%s < %s >'%(label,sublabel)
  else: jnbluXPrJKBdYcykaNCDsiLEoFHTAG=label
  if not img:img='DefaultFolder.png'
  jnbluXPrJKBdYcykaNCDsiLEoFHTAM=xbmcgui.ListItem(jnbluXPrJKBdYcykaNCDsiLEoFHTAG)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTWh(img)==jnbluXPrJKBdYcykaNCDsiLEoFHTWG:
   jnbluXPrJKBdYcykaNCDsiLEoFHTAM.setArt(img)
  else:
   jnbluXPrJKBdYcykaNCDsiLEoFHTAM.setArt({'thumb':img,'poster':img})
  if jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.KodiVersion>=20:
   if infoLabels:jnbluXPrJKBdYcykaNCDsiLEoFHTfW.Set_InfoTag(jnbluXPrJKBdYcykaNCDsiLEoFHTAM.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:jnbluXPrJKBdYcykaNCDsiLEoFHTAM.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   jnbluXPrJKBdYcykaNCDsiLEoFHTAM.setProperty('IsPlayable','true')
  if ContextMenu:jnbluXPrJKBdYcykaNCDsiLEoFHTAM.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,jnbluXPrJKBdYcykaNCDsiLEoFHTAh,jnbluXPrJKBdYcykaNCDsiLEoFHTAM,isFolder)
 def Set_InfoTag(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,video_InfoTag:xbmc.InfoTagVideo,jnbluXPrJKBdYcykaNCDsiLEoFHTRA):
  for jnbluXPrJKBdYcykaNCDsiLEoFHTAS,value in jnbluXPrJKBdYcykaNCDsiLEoFHTRA.items():
   if jnbluXPrJKBdYcykaNCDsiLEoFHTfQ[jnbluXPrJKBdYcykaNCDsiLEoFHTAS]['type']=='string':
    jnbluXPrJKBdYcykaNCDsiLEoFHTWM(video_InfoTag,jnbluXPrJKBdYcykaNCDsiLEoFHTfQ[jnbluXPrJKBdYcykaNCDsiLEoFHTAS]['func'])(value)
   elif jnbluXPrJKBdYcykaNCDsiLEoFHTfQ[jnbluXPrJKBdYcykaNCDsiLEoFHTAS]['type']=='int':
    if jnbluXPrJKBdYcykaNCDsiLEoFHTWh(value)==jnbluXPrJKBdYcykaNCDsiLEoFHTWO:
     jnbluXPrJKBdYcykaNCDsiLEoFHTAI=jnbluXPrJKBdYcykaNCDsiLEoFHTWO(value)
    else:
     jnbluXPrJKBdYcykaNCDsiLEoFHTAI=0
    jnbluXPrJKBdYcykaNCDsiLEoFHTWM(video_InfoTag,jnbluXPrJKBdYcykaNCDsiLEoFHTfQ[jnbluXPrJKBdYcykaNCDsiLEoFHTAS]['func'])(jnbluXPrJKBdYcykaNCDsiLEoFHTAI)
   elif jnbluXPrJKBdYcykaNCDsiLEoFHTfQ[jnbluXPrJKBdYcykaNCDsiLEoFHTAS]['type']=='actor':
    if value!=[]:
     jnbluXPrJKBdYcykaNCDsiLEoFHTWM(video_InfoTag,jnbluXPrJKBdYcykaNCDsiLEoFHTfQ[jnbluXPrJKBdYcykaNCDsiLEoFHTAS]['func'])([xbmc.Actor(name)for name in value])
   elif jnbluXPrJKBdYcykaNCDsiLEoFHTfQ[jnbluXPrJKBdYcykaNCDsiLEoFHTAS]['type']=='list':
    if jnbluXPrJKBdYcykaNCDsiLEoFHTWh(value)==jnbluXPrJKBdYcykaNCDsiLEoFHTWS:
     jnbluXPrJKBdYcykaNCDsiLEoFHTWM(video_InfoTag,jnbluXPrJKBdYcykaNCDsiLEoFHTfQ[jnbluXPrJKBdYcykaNCDsiLEoFHTAS]['func'])(value)
    else:
     jnbluXPrJKBdYcykaNCDsiLEoFHTWM(video_InfoTag,jnbluXPrJKBdYcykaNCDsiLEoFHTfQ[jnbluXPrJKBdYcykaNCDsiLEoFHTAS]['func'])([value])
 def dp_Main_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  (jnbluXPrJKBdYcykaNCDsiLEoFHTfg,jnbluXPrJKBdYcykaNCDsiLEoFHTfq,jnbluXPrJKBdYcykaNCDsiLEoFHTfU,jnbluXPrJKBdYcykaNCDsiLEoFHTfp,jnbluXPrJKBdYcykaNCDsiLEoFHTAf)=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_settings_totalsearch()
  for jnbluXPrJKBdYcykaNCDsiLEoFHTAg in jnbluXPrJKBdYcykaNCDsiLEoFHTfR:
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG=jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('title')
   jnbluXPrJKBdYcykaNCDsiLEoFHTAq=''
   if jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('mode')=='LOCAL_SEARCH' and jnbluXPrJKBdYcykaNCDsiLEoFHTfg ==jnbluXPrJKBdYcykaNCDsiLEoFHTWV:continue
   elif jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('mode')=='SEARCH_HISTORY' and jnbluXPrJKBdYcykaNCDsiLEoFHTfq==jnbluXPrJKBdYcykaNCDsiLEoFHTWV:continue
   elif jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('mode')=='TOTAL_SEARCH' and jnbluXPrJKBdYcykaNCDsiLEoFHTfU ==jnbluXPrJKBdYcykaNCDsiLEoFHTWV:continue
   elif jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('mode')=='TOTAL_HISTORY' and jnbluXPrJKBdYcykaNCDsiLEoFHTfp==jnbluXPrJKBdYcykaNCDsiLEoFHTWV:continue
   elif jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('mode')=='MENU_BOOKMARK' and jnbluXPrJKBdYcykaNCDsiLEoFHTAf==jnbluXPrJKBdYcykaNCDsiLEoFHTWV:continue
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('mode'),'stype':jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('stype'),'api_path':jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('api_path'),'page':'1','tag_id':'-',}
   if jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('mode')=='LOCAL_SEARCH':jnbluXPrJKBdYcykaNCDsiLEoFHTAU['historyyn']='Y' 
   if jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    jnbluXPrJKBdYcykaNCDsiLEoFHTAp=jnbluXPrJKBdYcykaNCDsiLEoFHTWV
    jnbluXPrJKBdYcykaNCDsiLEoFHTRf =jnbluXPrJKBdYcykaNCDsiLEoFHTWx
   else:
    jnbluXPrJKBdYcykaNCDsiLEoFHTAp=jnbluXPrJKBdYcykaNCDsiLEoFHTWx
    jnbluXPrJKBdYcykaNCDsiLEoFHTRf =jnbluXPrJKBdYcykaNCDsiLEoFHTWV
   jnbluXPrJKBdYcykaNCDsiLEoFHTRA={'title':jnbluXPrJKBdYcykaNCDsiLEoFHTAG,'plot':jnbluXPrJKBdYcykaNCDsiLEoFHTAG}
   if jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('mode')=='XXX':jnbluXPrJKBdYcykaNCDsiLEoFHTRA=jnbluXPrJKBdYcykaNCDsiLEoFHTWe
   if 'icon' in jnbluXPrJKBdYcykaNCDsiLEoFHTAg:jnbluXPrJKBdYcykaNCDsiLEoFHTAq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',jnbluXPrJKBdYcykaNCDsiLEoFHTAg.get('icon')) 
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel='',img=jnbluXPrJKBdYcykaNCDsiLEoFHTAq,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTRA,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTAp,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU,isLink=jnbluXPrJKBdYcykaNCDsiLEoFHTRf)
  xbmcplugin.endOfDirectory(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle)
 def login_main(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  (jnbluXPrJKBdYcykaNCDsiLEoFHTRQ,jnbluXPrJKBdYcykaNCDsiLEoFHTRm,jnbluXPrJKBdYcykaNCDsiLEoFHTRv)=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_settings_account()
  if not(jnbluXPrJKBdYcykaNCDsiLEoFHTRQ and jnbluXPrJKBdYcykaNCDsiLEoFHTRm):
   jnbluXPrJKBdYcykaNCDsiLEoFHTfx=xbmcgui.Dialog()
   jnbluXPrJKBdYcykaNCDsiLEoFHTRW=jnbluXPrJKBdYcykaNCDsiLEoFHTfx.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if jnbluXPrJKBdYcykaNCDsiLEoFHTRW==jnbluXPrJKBdYcykaNCDsiLEoFHTWx:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if jnbluXPrJKBdYcykaNCDsiLEoFHTfW.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   jnbluXPrJKBdYcykaNCDsiLEoFHTRt=0
   while jnbluXPrJKBdYcykaNCDsiLEoFHTWx:
    jnbluXPrJKBdYcykaNCDsiLEoFHTRt+=1
    time.sleep(0.05)
    if jnbluXPrJKBdYcykaNCDsiLEoFHTRt>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  jnbluXPrJKBdYcykaNCDsiLEoFHTRz=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.GetCredential(jnbluXPrJKBdYcykaNCDsiLEoFHTRQ,jnbluXPrJKBdYcykaNCDsiLEoFHTRm,jnbluXPrJKBdYcykaNCDsiLEoFHTRv)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTRz:jnbluXPrJKBdYcykaNCDsiLEoFHTfW.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
  if jnbluXPrJKBdYcykaNCDsiLEoFHTRz==jnbluXPrJKBdYcykaNCDsiLEoFHTWV:
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_HomeGroup_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTRe=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.GetHomeList()
  for jnbluXPrJKBdYcykaNCDsiLEoFHTRO in jnbluXPrJKBdYcykaNCDsiLEoFHTRe:
   jnbluXPrJKBdYcykaNCDsiLEoFHTRx =jnbluXPrJKBdYcykaNCDsiLEoFHTRO.get('code')
   jnbluXPrJKBdYcykaNCDsiLEoFHTRV=jnbluXPrJKBdYcykaNCDsiLEoFHTRO.get('content_type')
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG =jnbluXPrJKBdYcykaNCDsiLEoFHTRO.get('title')
   if jnbluXPrJKBdYcykaNCDsiLEoFHTRV=='staffmades':
    jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':'CATEGORY_LIST','api_path':'staffmades/'+jnbluXPrJKBdYcykaNCDsiLEoFHTRx,'page':'1',}
    jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,img=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWx,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU)
   else:
    jnbluXPrJKBdYcykaNCDsiLEoFHTRh
  xbmcplugin.endOfDirectory(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,cacheToDisc=jnbluXPrJKBdYcykaNCDsiLEoFHTWx)
 def dp_SubGroup_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTRM =args.get('stype')
  jnbluXPrJKBdYcykaNCDsiLEoFHTRS =jnbluXPrJKBdYcykaNCDsiLEoFHTWO(args.get('page'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTRI=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.GetSubGroupList(jnbluXPrJKBdYcykaNCDsiLEoFHTRM)
  jnbluXPrJKBdYcykaNCDsiLEoFHTRg=jnbluXPrJKBdYcykaNCDsiLEoFHTfm if jnbluXPrJKBdYcykaNCDsiLEoFHTRM=='genres' else jnbluXPrJKBdYcykaNCDsiLEoFHTfv
  jnbluXPrJKBdYcykaNCDsiLEoFHTRq=jnbluXPrJKBdYcykaNCDsiLEoFHTWI(jnbluXPrJKBdYcykaNCDsiLEoFHTRI)
  jnbluXPrJKBdYcykaNCDsiLEoFHTRU =jnbluXPrJKBdYcykaNCDsiLEoFHTWO(jnbluXPrJKBdYcykaNCDsiLEoFHTRq//(jnbluXPrJKBdYcykaNCDsiLEoFHTRg+1))+1
  jnbluXPrJKBdYcykaNCDsiLEoFHTRp =(jnbluXPrJKBdYcykaNCDsiLEoFHTRS-1)*jnbluXPrJKBdYcykaNCDsiLEoFHTRg
  for i in jnbluXPrJKBdYcykaNCDsiLEoFHTWg(jnbluXPrJKBdYcykaNCDsiLEoFHTRg):
   jnbluXPrJKBdYcykaNCDsiLEoFHTwf=jnbluXPrJKBdYcykaNCDsiLEoFHTRp+i
   if jnbluXPrJKBdYcykaNCDsiLEoFHTwf>=jnbluXPrJKBdYcykaNCDsiLEoFHTRq:break
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG =jnbluXPrJKBdYcykaNCDsiLEoFHTRI[jnbluXPrJKBdYcykaNCDsiLEoFHTwf].get('group_name')
   jnbluXPrJKBdYcykaNCDsiLEoFHTwA =jnbluXPrJKBdYcykaNCDsiLEoFHTRI[jnbluXPrJKBdYcykaNCDsiLEoFHTwf].get('api_path')
   jnbluXPrJKBdYcykaNCDsiLEoFHTwR =jnbluXPrJKBdYcykaNCDsiLEoFHTRI[jnbluXPrJKBdYcykaNCDsiLEoFHTwf].get('tag_id')
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':'CATEGORY_LIST','api_path':jnbluXPrJKBdYcykaNCDsiLEoFHTwA,'tag_id':jnbluXPrJKBdYcykaNCDsiLEoFHTwR,'stype':jnbluXPrJKBdYcykaNCDsiLEoFHTRM,'page':'1',}
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel='',img='',infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWx,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTRU>jnbluXPrJKBdYcykaNCDsiLEoFHTRS:
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={}
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['mode'] ='SUB_GROUP' 
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['stype'] =jnbluXPrJKBdYcykaNCDsiLEoFHTRM
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['api_path']=args.get('api_path')
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['page'] =jnbluXPrJKBdYcykaNCDsiLEoFHTWq(jnbluXPrJKBdYcykaNCDsiLEoFHTRS+1)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG='[B]%s >>[/B]'%'다음 페이지'
   jnbluXPrJKBdYcykaNCDsiLEoFHTwQ=jnbluXPrJKBdYcykaNCDsiLEoFHTWq(jnbluXPrJKBdYcykaNCDsiLEoFHTRS+1)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel=jnbluXPrJKBdYcykaNCDsiLEoFHTwQ,img=jnbluXPrJKBdYcykaNCDsiLEoFHTAq,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWx,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTWI(jnbluXPrJKBdYcykaNCDsiLEoFHTRI)>0:xbmcplugin.endOfDirectory(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,cacheToDisc=jnbluXPrJKBdYcykaNCDsiLEoFHTWx)
 def play_VIDEO(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTwm =args.get('movie_code')
  jnbluXPrJKBdYcykaNCDsiLEoFHTwv =args.get('season_code')
  jnbluXPrJKBdYcykaNCDsiLEoFHTAG =args.get('title')
  jnbluXPrJKBdYcykaNCDsiLEoFHTwW =args.get('thumbnail')
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.addon_log(jnbluXPrJKBdYcykaNCDsiLEoFHTwm+' - '+jnbluXPrJKBdYcykaNCDsiLEoFHTwv)
  jnbluXPrJKBdYcykaNCDsiLEoFHTwt =jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_selQuality()
  jnbluXPrJKBdYcykaNCDsiLEoFHTAR,jnbluXPrJKBdYcykaNCDsiLEoFHTAw=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_settings_proxyport()
  jnbluXPrJKBdYcykaNCDsiLEoFHTAe=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_settings_playback()
  jnbluXPrJKBdYcykaNCDsiLEoFHTwz=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.GetStreamingURL(jnbluXPrJKBdYcykaNCDsiLEoFHTwm,jnbluXPrJKBdYcykaNCDsiLEoFHTwt,proxyUse=jnbluXPrJKBdYcykaNCDsiLEoFHTAR,inScreen=jnbluXPrJKBdYcykaNCDsiLEoFHTAe['sel_screen'],inSound=jnbluXPrJKBdYcykaNCDsiLEoFHTAe['sel_sound'])
  if jnbluXPrJKBdYcykaNCDsiLEoFHTwz['streamUrl']=='':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.addon_noti(__language__(30908).encode('utf8'))
   return
  jnbluXPrJKBdYcykaNCDsiLEoFHTwe=jnbluXPrJKBdYcykaNCDsiLEoFHTwz['streamUrl']
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.addon_log(jnbluXPrJKBdYcykaNCDsiLEoFHTwe)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTAR:
   jnbluXPrJKBdYcykaNCDsiLEoFHTwO={'addon':'watcham','playOption':jnbluXPrJKBdYcykaNCDsiLEoFHTAe,}
   jnbluXPrJKBdYcykaNCDsiLEoFHTwO=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.Params_JsonToStr(jnbluXPrJKBdYcykaNCDsiLEoFHTwO)
   jnbluXPrJKBdYcykaNCDsiLEoFHTwe='http://127.0.0.1:{}/{}|proxy-mini={}'.format(jnbluXPrJKBdYcykaNCDsiLEoFHTAw,jnbluXPrJKBdYcykaNCDsiLEoFHTwe,jnbluXPrJKBdYcykaNCDsiLEoFHTwO)
  jnbluXPrJKBdYcykaNCDsiLEoFHTwx=xbmcgui.ListItem(path=jnbluXPrJKBdYcykaNCDsiLEoFHTwe)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTwz['customdata']:
   jnbluXPrJKBdYcykaNCDsiLEoFHTwV=jnbluXPrJKBdYcykaNCDsiLEoFHTwz['customdata']
   jnbluXPrJKBdYcykaNCDsiLEoFHTwh ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   jnbluXPrJKBdYcykaNCDsiLEoFHTwG ='mpd'
   jnbluXPrJKBdYcykaNCDsiLEoFHTwM ='com.widevine.alpha'
   jnbluXPrJKBdYcykaNCDsiLEoFHTwS =inputstreamhelper.Helper(jnbluXPrJKBdYcykaNCDsiLEoFHTwG,drm=jnbluXPrJKBdYcykaNCDsiLEoFHTwM)
   if jnbluXPrJKBdYcykaNCDsiLEoFHTwS.check_inputstream():
    jnbluXPrJKBdYcykaNCDsiLEoFHTwI={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+jnbluXPrJKBdYcykaNCDsiLEoFHTwm,'dt-custom-data':jnbluXPrJKBdYcykaNCDsiLEoFHTwV,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream',}
    jnbluXPrJKBdYcykaNCDsiLEoFHTwg=jnbluXPrJKBdYcykaNCDsiLEoFHTwh+'|'+urllib.parse.urlencode(jnbluXPrJKBdYcykaNCDsiLEoFHTwI)+'|R{SSM}|'
    jnbluXPrJKBdYcykaNCDsiLEoFHTfW.addon_log(jnbluXPrJKBdYcykaNCDsiLEoFHTwg)
    jnbluXPrJKBdYcykaNCDsiLEoFHTwx.setProperty('inputstream',jnbluXPrJKBdYcykaNCDsiLEoFHTwS.inputstream_addon)
    jnbluXPrJKBdYcykaNCDsiLEoFHTwx.setProperty('inputstream.adaptive.manifest_type',jnbluXPrJKBdYcykaNCDsiLEoFHTwG)
    jnbluXPrJKBdYcykaNCDsiLEoFHTwx.setProperty('inputstream.adaptive.license_type',jnbluXPrJKBdYcykaNCDsiLEoFHTwM)
    jnbluXPrJKBdYcykaNCDsiLEoFHTwx.setProperty('inputstream.adaptive.license_key',jnbluXPrJKBdYcykaNCDsiLEoFHTwg)
    jnbluXPrJKBdYcykaNCDsiLEoFHTwx.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.USER_AGENT))
  if jnbluXPrJKBdYcykaNCDsiLEoFHTwz['subtitleUrl']:
   try:
    f=jnbluXPrJKBdYcykaNCDsiLEoFHTWU(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_SUBTITLE_VTT,'w',-1,'utf-8')
    jnbluXPrJKBdYcykaNCDsiLEoFHTwq=requests.get(jnbluXPrJKBdYcykaNCDsiLEoFHTwz['subtitleUrl'])
    jnbluXPrJKBdYcykaNCDsiLEoFHTwU=jnbluXPrJKBdYcykaNCDsiLEoFHTwq.content.decode('utf-8') 
    for jnbluXPrJKBdYcykaNCDsiLEoFHTwp in jnbluXPrJKBdYcykaNCDsiLEoFHTwU.splitlines():
     jnbluXPrJKBdYcykaNCDsiLEoFHTQf=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',jnbluXPrJKBdYcykaNCDsiLEoFHTwp)
     f.write(jnbluXPrJKBdYcykaNCDsiLEoFHTQf+'\n')
    f.close()
    jnbluXPrJKBdYcykaNCDsiLEoFHTwx.setSubtitles([jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_SUBTITLE_VTT,jnbluXPrJKBdYcykaNCDsiLEoFHTwz['subtitleUrl']])
   except:
    jnbluXPrJKBdYcykaNCDsiLEoFHTwx.setSubtitles([jnbluXPrJKBdYcykaNCDsiLEoFHTwz['subtitleUrl']])
  xbmcplugin.setResolvedUrl(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,jnbluXPrJKBdYcykaNCDsiLEoFHTWx,jnbluXPrJKBdYcykaNCDsiLEoFHTwx)
  try:
   jnbluXPrJKBdYcykaNCDsiLEoFHTRM='movie' if jnbluXPrJKBdYcykaNCDsiLEoFHTwv=='-' else 'seasons'
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'code':jnbluXPrJKBdYcykaNCDsiLEoFHTwm if jnbluXPrJKBdYcykaNCDsiLEoFHTRM=='movie' else jnbluXPrJKBdYcykaNCDsiLEoFHTwv,'img':jnbluXPrJKBdYcykaNCDsiLEoFHTwW,'title':jnbluXPrJKBdYcykaNCDsiLEoFHTAG,'videoid':jnbluXPrJKBdYcykaNCDsiLEoFHTwm}
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.Save_Watched_List(jnbluXPrJKBdYcykaNCDsiLEoFHTRM,jnbluXPrJKBdYcykaNCDsiLEoFHTAU)
  except:
   jnbluXPrJKBdYcykaNCDsiLEoFHTWe
 def srtConvert(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,jnbluXPrJKBdYcykaNCDsiLEoFHTQR):
  jnbluXPrJKBdYcykaNCDsiLEoFHTQA=re.sub(r'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',jnbluXPrJKBdYcykaNCDsiLEoFHTQR)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQA=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',jnbluXPrJKBdYcykaNCDsiLEoFHTQA)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQA=re.sub(r'(\d\d).(\d\d\d) --> (\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',jnbluXPrJKBdYcykaNCDsiLEoFHTQA)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQA=re.sub(r'WEBVTT\n','',jnbluXPrJKBdYcykaNCDsiLEoFHTQA)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQA=re.sub(r'Kind:[ \-\w]+\n','',jnbluXPrJKBdYcykaNCDsiLEoFHTQA)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQA=re.sub(r'Language:[ \-\w]+\n','',jnbluXPrJKBdYcykaNCDsiLEoFHTQA)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQA=re.sub(r'<c[.\w\d]*>','',jnbluXPrJKBdYcykaNCDsiLEoFHTQA)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQA=re.sub(r'</c>','',jnbluXPrJKBdYcykaNCDsiLEoFHTQA)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQA=re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>','',jnbluXPrJKBdYcykaNCDsiLEoFHTQA)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQA=re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n','',jnbluXPrJKBdYcykaNCDsiLEoFHTQA)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQA=re.sub(r'Style:\n##\n','',jnbluXPrJKBdYcykaNCDsiLEoFHTQA)
  return jnbluXPrJKBdYcykaNCDsiLEoFHTQA
 def vtt_to_srt(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,vttFilename,srtFilename):
  try:
   f=jnbluXPrJKBdYcykaNCDsiLEoFHTWU(vttFilename,'r',-1,'utf-8')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQR=f.read()
   f.close()
   jnbluXPrJKBdYcykaNCDsiLEoFHTQw=''
   jnbluXPrJKBdYcykaNCDsiLEoFHTQw=jnbluXPrJKBdYcykaNCDsiLEoFHTQw+jnbluXPrJKBdYcykaNCDsiLEoFHTfW.srtConvert(jnbluXPrJKBdYcykaNCDsiLEoFHTQR)
   f=jnbluXPrJKBdYcykaNCDsiLEoFHTWU(srtFilename,'w',-1,'utf-8')
   f.writelines(jnbluXPrJKBdYcykaNCDsiLEoFHTWq(jnbluXPrJKBdYcykaNCDsiLEoFHTQw))
   f.close()
  except:
   return jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  return jnbluXPrJKBdYcykaNCDsiLEoFHTWx
 def dp_Category_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTRM =args.get('stype')
  jnbluXPrJKBdYcykaNCDsiLEoFHTwR =args.get('tag_id')
  jnbluXPrJKBdYcykaNCDsiLEoFHTwA=args.get('api_path')
  jnbluXPrJKBdYcykaNCDsiLEoFHTRS=jnbluXPrJKBdYcykaNCDsiLEoFHTWO(args.get('page'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTQm=[]
  jnbluXPrJKBdYcykaNCDsiLEoFHTQv,jnbluXPrJKBdYcykaNCDsiLEoFHTQW=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.GetCategoryList(jnbluXPrJKBdYcykaNCDsiLEoFHTRM,jnbluXPrJKBdYcykaNCDsiLEoFHTwR,jnbluXPrJKBdYcykaNCDsiLEoFHTwA,jnbluXPrJKBdYcykaNCDsiLEoFHTRS)
  for jnbluXPrJKBdYcykaNCDsiLEoFHTQt in jnbluXPrJKBdYcykaNCDsiLEoFHTQv:
   jnbluXPrJKBdYcykaNCDsiLEoFHTwm =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('code')
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('title')
   jnbluXPrJKBdYcykaNCDsiLEoFHTRV =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('content_type')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQz =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('story')
   jnbluXPrJKBdYcykaNCDsiLEoFHTwW =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('thumbnail')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQe =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('year')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQO =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('film_rating_code')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQx=jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('film_rating_short')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQV =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('film_rating_long')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQh =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('duration')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQG =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('badge')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQm.append(jnbluXPrJKBdYcykaNCDsiLEoFHTwm)
   if jnbluXPrJKBdYcykaNCDsiLEoFHTRV=='movies': 
    jnbluXPrJKBdYcykaNCDsiLEoFHTAp =jnbluXPrJKBdYcykaNCDsiLEoFHTWV
    jnbluXPrJKBdYcykaNCDsiLEoFHTQM ='MOVIE'
    jnbluXPrJKBdYcykaNCDsiLEoFHTwv='-'
    jnbluXPrJKBdYcykaNCDsiLEoFHTQS ='movie'
   else: 
    jnbluXPrJKBdYcykaNCDsiLEoFHTAp =jnbluXPrJKBdYcykaNCDsiLEoFHTWx
    jnbluXPrJKBdYcykaNCDsiLEoFHTQM ='SEASON'
    jnbluXPrJKBdYcykaNCDsiLEoFHTwv=jnbluXPrJKBdYcykaNCDsiLEoFHTwm
    jnbluXPrJKBdYcykaNCDsiLEoFHTQS ='tvshow' 
   jnbluXPrJKBdYcykaNCDsiLEoFHTQI={'mediatype':jnbluXPrJKBdYcykaNCDsiLEoFHTQS,'mpaa':jnbluXPrJKBdYcykaNCDsiLEoFHTQV,'title':jnbluXPrJKBdYcykaNCDsiLEoFHTAG,'year':jnbluXPrJKBdYcykaNCDsiLEoFHTQe,'duration':jnbluXPrJKBdYcykaNCDsiLEoFHTQh,'plot':jnbluXPrJKBdYcykaNCDsiLEoFHTQz,}
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG+='  (%s)'%(jnbluXPrJKBdYcykaNCDsiLEoFHTQe)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':jnbluXPrJKBdYcykaNCDsiLEoFHTQM,'movie_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwm,'page':'1','season_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwv,'title':jnbluXPrJKBdYcykaNCDsiLEoFHTAG,'thumbnail':jnbluXPrJKBdYcykaNCDsiLEoFHTwW,}
   jnbluXPrJKBdYcykaNCDsiLEoFHTQg=[]
   if jnbluXPrJKBdYcykaNCDsiLEoFHTwA=='users/me/watchings':
    jnbluXPrJKBdYcykaNCDsiLEoFHTQq={'codeList':[jnbluXPrJKBdYcykaNCDsiLEoFHTwm]}
    jnbluXPrJKBdYcykaNCDsiLEoFHTQU=json.dumps(jnbluXPrJKBdYcykaNCDsiLEoFHTQq)
    jnbluXPrJKBdYcykaNCDsiLEoFHTQU=urllib.parse.quote(jnbluXPrJKBdYcykaNCDsiLEoFHTQU)
    jnbluXPrJKBdYcykaNCDsiLEoFHTQp='RunPlugin(plugin://plugin.video.watcham/?mode=DELETE_CONTINUE&bm_param=%s)'%(jnbluXPrJKBdYcykaNCDsiLEoFHTQU)
    jnbluXPrJKBdYcykaNCDsiLEoFHTQg.append(('(선택영상) 이어보기에서 삭제',jnbluXPrJKBdYcykaNCDsiLEoFHTQp))
   if jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_settings_makebookmark():
    jnbluXPrJKBdYcykaNCDsiLEoFHTQq={'videoid':jnbluXPrJKBdYcykaNCDsiLEoFHTwm,'vidtype':'tvshow' if jnbluXPrJKBdYcykaNCDsiLEoFHTRV=='tv_seasons' else 'movie','vtitle':jnbluXPrJKBdYcykaNCDsiLEoFHTAG,'vsubtitle':'',}
    jnbluXPrJKBdYcykaNCDsiLEoFHTQU=json.dumps(jnbluXPrJKBdYcykaNCDsiLEoFHTQq)
    jnbluXPrJKBdYcykaNCDsiLEoFHTQU=urllib.parse.quote(jnbluXPrJKBdYcykaNCDsiLEoFHTQU)
    jnbluXPrJKBdYcykaNCDsiLEoFHTQp='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(jnbluXPrJKBdYcykaNCDsiLEoFHTQU)
    jnbluXPrJKBdYcykaNCDsiLEoFHTQg.append(('(통합) 찜 영상에 추가',jnbluXPrJKBdYcykaNCDsiLEoFHTQp))
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel=jnbluXPrJKBdYcykaNCDsiLEoFHTQG,img=jnbluXPrJKBdYcykaNCDsiLEoFHTwW,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTQI,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTAp,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU,ContextMenu=jnbluXPrJKBdYcykaNCDsiLEoFHTQg)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTwA=='users/me/watchings':
   jnbluXPrJKBdYcykaNCDsiLEoFHTQq={'codeList':jnbluXPrJKBdYcykaNCDsiLEoFHTQm}
   jnbluXPrJKBdYcykaNCDsiLEoFHTQU=json.dumps(jnbluXPrJKBdYcykaNCDsiLEoFHTQq,separators=(',',':'))
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.addon_log(jnbluXPrJKBdYcykaNCDsiLEoFHTQU)
   jnbluXPrJKBdYcykaNCDsiLEoFHTQU=urllib.parse.quote(jnbluXPrJKBdYcykaNCDsiLEoFHTQU)
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.addon_log(jnbluXPrJKBdYcykaNCDsiLEoFHTQU)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':'DELETE_CONTINUE','bm_param':jnbluXPrJKBdYcykaNCDsiLEoFHTQq,}
   jnbluXPrJKBdYcykaNCDsiLEoFHTQI={'plot':'이어보기 목록 전체를 삭제합니다.'}
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG='** 이어보기 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   jnbluXPrJKBdYcykaNCDsiLEoFHTAq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel='',img=jnbluXPrJKBdYcykaNCDsiLEoFHTAq,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTQI,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWV,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU,isLink=jnbluXPrJKBdYcykaNCDsiLEoFHTWx)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTQW:
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={}
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['mode'] ='CATEGORY_LIST'
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['stype'] =jnbluXPrJKBdYcykaNCDsiLEoFHTRM
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['tag_id'] =jnbluXPrJKBdYcykaNCDsiLEoFHTwR
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['api_path']=jnbluXPrJKBdYcykaNCDsiLEoFHTwA
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['page'] =jnbluXPrJKBdYcykaNCDsiLEoFHTWq(jnbluXPrJKBdYcykaNCDsiLEoFHTRS+1)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG='[B]%s >>[/B]'%'다음 페이지'
   jnbluXPrJKBdYcykaNCDsiLEoFHTwQ=jnbluXPrJKBdYcykaNCDsiLEoFHTWq(jnbluXPrJKBdYcykaNCDsiLEoFHTRS+1)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel=jnbluXPrJKBdYcykaNCDsiLEoFHTwQ,img=jnbluXPrJKBdYcykaNCDsiLEoFHTAq,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWx,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU)
  xbmcplugin.setContent(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,'movies')
  if jnbluXPrJKBdYcykaNCDsiLEoFHTWI(jnbluXPrJKBdYcykaNCDsiLEoFHTQv)>0:
   if jnbluXPrJKBdYcykaNCDsiLEoFHTwA=='arrivals/latest':
    xbmcplugin.endOfDirectory(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,cacheToDisc=jnbluXPrJKBdYcykaNCDsiLEoFHTWx)
   else:
    xbmcplugin.endOfDirectory(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,cacheToDisc=jnbluXPrJKBdYcykaNCDsiLEoFHTWV)
 def dp_Season_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTwv=args.get('season_code')
  jnbluXPrJKBdYcykaNCDsiLEoFHTwW =args.get('thumbnail')
  jnbluXPrJKBdYcykaNCDsiLEoFHTwW=json.loads(jnbluXPrJKBdYcykaNCDsiLEoFHTwW.replace('\'','"'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTmf=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.GetSeasonList(jnbluXPrJKBdYcykaNCDsiLEoFHTwv)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTWI(jnbluXPrJKBdYcykaNCDsiLEoFHTmf)>1:
   for jnbluXPrJKBdYcykaNCDsiLEoFHTmA in jnbluXPrJKBdYcykaNCDsiLEoFHTmf:
    jnbluXPrJKBdYcykaNCDsiLEoFHTmR=jnbluXPrJKBdYcykaNCDsiLEoFHTmA.get('seasonId')
    jnbluXPrJKBdYcykaNCDsiLEoFHTmw=jnbluXPrJKBdYcykaNCDsiLEoFHTmA.get('seasonNm')
    jnbluXPrJKBdYcykaNCDsiLEoFHTQI={'mediatype':'tvshow','title':jnbluXPrJKBdYcykaNCDsiLEoFHTmw,}
    jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':'EPISODE','movie_code':jnbluXPrJKBdYcykaNCDsiLEoFHTmR,'page':'1','season_code':jnbluXPrJKBdYcykaNCDsiLEoFHTmR,'title':jnbluXPrJKBdYcykaNCDsiLEoFHTmw,'thumbnail':jnbluXPrJKBdYcykaNCDsiLEoFHTwW,}
    jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTmw,sublabel=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,img=jnbluXPrJKBdYcykaNCDsiLEoFHTwW,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTQI,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWx,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU,ContextMenu=jnbluXPrJKBdYcykaNCDsiLEoFHTWe)
   xbmcplugin.setContent(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,cacheToDisc=jnbluXPrJKBdYcykaNCDsiLEoFHTWV)
  else:
   jnbluXPrJKBdYcykaNCDsiLEoFHTmQ={'movie_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwv,'page':'1','season_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwv,}
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Episode_List(jnbluXPrJKBdYcykaNCDsiLEoFHTmQ)
 def dp_Episode_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTmv=args.get('movie_code')
  jnbluXPrJKBdYcykaNCDsiLEoFHTRS =jnbluXPrJKBdYcykaNCDsiLEoFHTWO(args.get('page'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTwv =args.get('season_code')
  jnbluXPrJKBdYcykaNCDsiLEoFHTQv,jnbluXPrJKBdYcykaNCDsiLEoFHTQW=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.GetEpisodoList(jnbluXPrJKBdYcykaNCDsiLEoFHTmv,jnbluXPrJKBdYcykaNCDsiLEoFHTRS,orderby=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_winEpisodeOrderby())
  for jnbluXPrJKBdYcykaNCDsiLEoFHTQt in jnbluXPrJKBdYcykaNCDsiLEoFHTQv:
   jnbluXPrJKBdYcykaNCDsiLEoFHTwm =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('code')
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('title')
   jnbluXPrJKBdYcykaNCDsiLEoFHTwW =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('thumbnail')
   jnbluXPrJKBdYcykaNCDsiLEoFHTmW =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('display_num')
   jnbluXPrJKBdYcykaNCDsiLEoFHTmt =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('season_title')
   jnbluXPrJKBdYcykaNCDsiLEoFHTmz=jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('episode_number')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQh =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('duration')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQI={'mediatype':'episode','tvshowtitle':jnbluXPrJKBdYcykaNCDsiLEoFHTAG if jnbluXPrJKBdYcykaNCDsiLEoFHTAG!='' else jnbluXPrJKBdYcykaNCDsiLEoFHTmt,'title':'%s %s'%(jnbluXPrJKBdYcykaNCDsiLEoFHTmt,jnbluXPrJKBdYcykaNCDsiLEoFHTmW)if jnbluXPrJKBdYcykaNCDsiLEoFHTAG!='' else jnbluXPrJKBdYcykaNCDsiLEoFHTmW,'episode':jnbluXPrJKBdYcykaNCDsiLEoFHTmz,'duration':jnbluXPrJKBdYcykaNCDsiLEoFHTQh,'plot':'%s\n%s\n\n%s'%(jnbluXPrJKBdYcykaNCDsiLEoFHTmt,jnbluXPrJKBdYcykaNCDsiLEoFHTmW,jnbluXPrJKBdYcykaNCDsiLEoFHTAG)}
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG='(%s) %s'%(jnbluXPrJKBdYcykaNCDsiLEoFHTmW,jnbluXPrJKBdYcykaNCDsiLEoFHTAG)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':'MOVIE','movie_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwm,'season_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwv,'title':'%s < %s >'%(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,jnbluXPrJKBdYcykaNCDsiLEoFHTmt),'thumbnail':jnbluXPrJKBdYcykaNCDsiLEoFHTwW}
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel=jnbluXPrJKBdYcykaNCDsiLEoFHTmt,img=jnbluXPrJKBdYcykaNCDsiLEoFHTwW,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTQI,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWV,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTRS==1:
   jnbluXPrJKBdYcykaNCDsiLEoFHTQI={'plot':'정렬순서를 변경합니다.'}
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={}
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['mode'] ='ORDER_BY' 
   if jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_winEpisodeOrderby()=='desc':
    jnbluXPrJKBdYcykaNCDsiLEoFHTAG='정렬순서변경 : 최신화부터 -> 1회부터'
    jnbluXPrJKBdYcykaNCDsiLEoFHTAU['orderby']='asc'
   else:
    jnbluXPrJKBdYcykaNCDsiLEoFHTAG='정렬순서변경 : 1회부터 -> 최신화부터'
    jnbluXPrJKBdYcykaNCDsiLEoFHTAU['orderby']='desc'
   jnbluXPrJKBdYcykaNCDsiLEoFHTAq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel='',img=jnbluXPrJKBdYcykaNCDsiLEoFHTAq,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTQI,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWV,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU,isLink=jnbluXPrJKBdYcykaNCDsiLEoFHTWx)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTQW:
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['mode'] ='EPISODE' 
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['movie_code']=jnbluXPrJKBdYcykaNCDsiLEoFHTmv
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['page'] =jnbluXPrJKBdYcykaNCDsiLEoFHTWq(jnbluXPrJKBdYcykaNCDsiLEoFHTRS+1)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG='[B]%s >>[/B]'%'다음 페이지'
   jnbluXPrJKBdYcykaNCDsiLEoFHTwQ=jnbluXPrJKBdYcykaNCDsiLEoFHTWq(jnbluXPrJKBdYcykaNCDsiLEoFHTRS+1)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel=jnbluXPrJKBdYcykaNCDsiLEoFHTwQ,img=jnbluXPrJKBdYcykaNCDsiLEoFHTAq,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWx,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU)
  xbmcplugin.setContent(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,'episodes')
  if jnbluXPrJKBdYcykaNCDsiLEoFHTWI(jnbluXPrJKBdYcykaNCDsiLEoFHTQv)>0:xbmcplugin.endOfDirectory(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,cacheToDisc=jnbluXPrJKBdYcykaNCDsiLEoFHTWx)
 def dp_Search_History(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTme=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.Load_List_File('search')
  for jnbluXPrJKBdYcykaNCDsiLEoFHTmO in jnbluXPrJKBdYcykaNCDsiLEoFHTme:
   jnbluXPrJKBdYcykaNCDsiLEoFHTmx=jnbluXPrJKBdYcykaNCDsiLEoFHTWG(urllib.parse.parse_qsl(jnbluXPrJKBdYcykaNCDsiLEoFHTmO))
   jnbluXPrJKBdYcykaNCDsiLEoFHTmV=jnbluXPrJKBdYcykaNCDsiLEoFHTmx.get('skey').strip()
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':'LOCAL_SEARCH','search_key':jnbluXPrJKBdYcykaNCDsiLEoFHTmV,'page':'1','historyyn':'Y',}
   jnbluXPrJKBdYcykaNCDsiLEoFHTmh={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':jnbluXPrJKBdYcykaNCDsiLEoFHTmV,'vType':'-',}
   jnbluXPrJKBdYcykaNCDsiLEoFHTmG=urllib.parse.urlencode(jnbluXPrJKBdYcykaNCDsiLEoFHTmh)
   jnbluXPrJKBdYcykaNCDsiLEoFHTQg=[('선택된 검색어 ( %s ) 삭제'%(jnbluXPrJKBdYcykaNCDsiLEoFHTmV),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(jnbluXPrJKBdYcykaNCDsiLEoFHTmG))]
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTmV,sublabel='',img=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWx,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU,ContextMenu=jnbluXPrJKBdYcykaNCDsiLEoFHTQg)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQI={'plot':'검색목록 전체를 삭제합니다.'}
  jnbluXPrJKBdYcykaNCDsiLEoFHTAG='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  jnbluXPrJKBdYcykaNCDsiLEoFHTAq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel='',img=jnbluXPrJKBdYcykaNCDsiLEoFHTAq,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTQI,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWV,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU,isLink=jnbluXPrJKBdYcykaNCDsiLEoFHTWx)
  xbmcplugin.endOfDirectory(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,cacheToDisc=jnbluXPrJKBdYcykaNCDsiLEoFHTWV)
 def dp_Search_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTRS =jnbluXPrJKBdYcykaNCDsiLEoFHTWO(args.get('page'))
  if 'search_key' in args:
   jnbluXPrJKBdYcykaNCDsiLEoFHTmM=args.get('search_key')
  else:
   jnbluXPrJKBdYcykaNCDsiLEoFHTmM=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not jnbluXPrJKBdYcykaNCDsiLEoFHTmM:
    return
  jnbluXPrJKBdYcykaNCDsiLEoFHTQv,jnbluXPrJKBdYcykaNCDsiLEoFHTQW=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.GetSearchList(jnbluXPrJKBdYcykaNCDsiLEoFHTmM,jnbluXPrJKBdYcykaNCDsiLEoFHTRS)
  for jnbluXPrJKBdYcykaNCDsiLEoFHTQt in jnbluXPrJKBdYcykaNCDsiLEoFHTQv:
   jnbluXPrJKBdYcykaNCDsiLEoFHTwm =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('code')
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('title')
   jnbluXPrJKBdYcykaNCDsiLEoFHTRV=jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('content_type')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQz =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('story')
   jnbluXPrJKBdYcykaNCDsiLEoFHTwW =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('thumbnail')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQe =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('year')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQO =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('film_rating_code')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQx=jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('film_rating_short')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQV =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('film_rating_long')
   jnbluXPrJKBdYcykaNCDsiLEoFHTQh =jnbluXPrJKBdYcykaNCDsiLEoFHTQt.get('duration')
   if jnbluXPrJKBdYcykaNCDsiLEoFHTRV=='movies': 
    jnbluXPrJKBdYcykaNCDsiLEoFHTAp =jnbluXPrJKBdYcykaNCDsiLEoFHTWV
    jnbluXPrJKBdYcykaNCDsiLEoFHTQM ='MOVIE'
    jnbluXPrJKBdYcykaNCDsiLEoFHTRw =''
    jnbluXPrJKBdYcykaNCDsiLEoFHTwv='-'
    jnbluXPrJKBdYcykaNCDsiLEoFHTQS ='movie'
   else: 
    jnbluXPrJKBdYcykaNCDsiLEoFHTAp =jnbluXPrJKBdYcykaNCDsiLEoFHTWx
    jnbluXPrJKBdYcykaNCDsiLEoFHTQM ='SEASON'
    jnbluXPrJKBdYcykaNCDsiLEoFHTRw ='' 
    jnbluXPrJKBdYcykaNCDsiLEoFHTwv=jnbluXPrJKBdYcykaNCDsiLEoFHTwm
    jnbluXPrJKBdYcykaNCDsiLEoFHTQS ='tvshow' 
   jnbluXPrJKBdYcykaNCDsiLEoFHTQI={'mediatype':jnbluXPrJKBdYcykaNCDsiLEoFHTQS,'mpaa':jnbluXPrJKBdYcykaNCDsiLEoFHTQV,'title':jnbluXPrJKBdYcykaNCDsiLEoFHTAG,'year':jnbluXPrJKBdYcykaNCDsiLEoFHTQe,'duration':jnbluXPrJKBdYcykaNCDsiLEoFHTQh,'plot':jnbluXPrJKBdYcykaNCDsiLEoFHTQz}
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG+='  (%s)'%(jnbluXPrJKBdYcykaNCDsiLEoFHTQe)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':jnbluXPrJKBdYcykaNCDsiLEoFHTQM,'movie_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwm,'page':'1','season_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwv,'title':jnbluXPrJKBdYcykaNCDsiLEoFHTAG,'thumbnail':jnbluXPrJKBdYcykaNCDsiLEoFHTwW}
   if jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_settings_makebookmark():
    jnbluXPrJKBdYcykaNCDsiLEoFHTQq={'videoid':jnbluXPrJKBdYcykaNCDsiLEoFHTwm,'vidtype':'tvshow' if jnbluXPrJKBdYcykaNCDsiLEoFHTRV=='tv_seasons' else 'movie','vtitle':jnbluXPrJKBdYcykaNCDsiLEoFHTAG,'vsubtitle':'',}
    jnbluXPrJKBdYcykaNCDsiLEoFHTQU=json.dumps(jnbluXPrJKBdYcykaNCDsiLEoFHTQq)
    jnbluXPrJKBdYcykaNCDsiLEoFHTQU=urllib.parse.quote(jnbluXPrJKBdYcykaNCDsiLEoFHTQU)
    jnbluXPrJKBdYcykaNCDsiLEoFHTQp='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(jnbluXPrJKBdYcykaNCDsiLEoFHTQU)
    jnbluXPrJKBdYcykaNCDsiLEoFHTQg=[('(통합) 찜 영상에 추가',jnbluXPrJKBdYcykaNCDsiLEoFHTQp)]
   else:
    jnbluXPrJKBdYcykaNCDsiLEoFHTQg=jnbluXPrJKBdYcykaNCDsiLEoFHTWe
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel=jnbluXPrJKBdYcykaNCDsiLEoFHTRw,img=jnbluXPrJKBdYcykaNCDsiLEoFHTwW,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTQI,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTAp,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU,ContextMenu=jnbluXPrJKBdYcykaNCDsiLEoFHTQg)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTQW:
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={}
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['mode'] ='SEARCH'
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['search_key']=jnbluXPrJKBdYcykaNCDsiLEoFHTmM
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU['page'] =jnbluXPrJKBdYcykaNCDsiLEoFHTWq(jnbluXPrJKBdYcykaNCDsiLEoFHTRS+1)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG='[B]%s >>[/B]'%'다음 페이지'
   jnbluXPrJKBdYcykaNCDsiLEoFHTwQ=jnbluXPrJKBdYcykaNCDsiLEoFHTWq(jnbluXPrJKBdYcykaNCDsiLEoFHTRS+1)
   jnbluXPrJKBdYcykaNCDsiLEoFHTAq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel=jnbluXPrJKBdYcykaNCDsiLEoFHTwQ,img=jnbluXPrJKBdYcykaNCDsiLEoFHTAq,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWx,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU)
  xbmcplugin.setContent(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,'movies')
  xbmcplugin.endOfDirectory(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,cacheToDisc=jnbluXPrJKBdYcykaNCDsiLEoFHTWx)
  if args.get('historyyn')=='Y':jnbluXPrJKBdYcykaNCDsiLEoFHTfW.Save_Searched_List(jnbluXPrJKBdYcykaNCDsiLEoFHTmM)
 def dp_Delete_Continue(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTmS=urllib.parse.unquote(args.get('bm_param'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTmS=jnbluXPrJKBdYcykaNCDsiLEoFHTmS.replace('\'','"')
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.addon_log(jnbluXPrJKBdYcykaNCDsiLEoFHTmS)
  jnbluXPrJKBdYcykaNCDsiLEoFHTmS=json.loads(jnbluXPrJKBdYcykaNCDsiLEoFHTmS)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQm=jnbluXPrJKBdYcykaNCDsiLEoFHTmS.get('codeList')
  jnbluXPrJKBdYcykaNCDsiLEoFHTfx=xbmcgui.Dialog()
  jnbluXPrJKBdYcykaNCDsiLEoFHTRW=jnbluXPrJKBdYcykaNCDsiLEoFHTfx.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if jnbluXPrJKBdYcykaNCDsiLEoFHTRW==jnbluXPrJKBdYcykaNCDsiLEoFHTWV:sys.exit()
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.DeleteContinueList(jnbluXPrJKBdYcykaNCDsiLEoFHTQm)
  xbmc.executebuiltin("Container.Refresh")
 def dp_History_Remove(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTmI=args.get('delType')
  jnbluXPrJKBdYcykaNCDsiLEoFHTmg =args.get('sKey')
  jnbluXPrJKBdYcykaNCDsiLEoFHTmq =args.get('vType')
  jnbluXPrJKBdYcykaNCDsiLEoFHTfx=xbmcgui.Dialog()
  if jnbluXPrJKBdYcykaNCDsiLEoFHTmI=='SEARCH_ALL':
   jnbluXPrJKBdYcykaNCDsiLEoFHTRW=jnbluXPrJKBdYcykaNCDsiLEoFHTfx.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTmI=='SEARCH_ONE':
   jnbluXPrJKBdYcykaNCDsiLEoFHTRW=jnbluXPrJKBdYcykaNCDsiLEoFHTfx.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTmI=='WATCH_ALL':
   jnbluXPrJKBdYcykaNCDsiLEoFHTRW=jnbluXPrJKBdYcykaNCDsiLEoFHTfx.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTmI=='WATCH_ONE':
   jnbluXPrJKBdYcykaNCDsiLEoFHTRW=jnbluXPrJKBdYcykaNCDsiLEoFHTfx.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if jnbluXPrJKBdYcykaNCDsiLEoFHTRW==jnbluXPrJKBdYcykaNCDsiLEoFHTWV:sys.exit()
  if jnbluXPrJKBdYcykaNCDsiLEoFHTmI=='SEARCH_ALL':
   if os.path.isfile(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_SEARCHEDC_FILENAME):os.remove(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_SEARCHEDC_FILENAME)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTmI=='SEARCH_ONE':
   try:
    jnbluXPrJKBdYcykaNCDsiLEoFHTmU=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_SEARCHEDC_FILENAME
    jnbluXPrJKBdYcykaNCDsiLEoFHTmp=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.Load_List_File('search') 
    fp=jnbluXPrJKBdYcykaNCDsiLEoFHTWU(jnbluXPrJKBdYcykaNCDsiLEoFHTmU,'w',-1,'utf-8')
    for jnbluXPrJKBdYcykaNCDsiLEoFHTvf in jnbluXPrJKBdYcykaNCDsiLEoFHTmp:
     jnbluXPrJKBdYcykaNCDsiLEoFHTvA=jnbluXPrJKBdYcykaNCDsiLEoFHTWG(urllib.parse.parse_qsl(jnbluXPrJKBdYcykaNCDsiLEoFHTvf))
     jnbluXPrJKBdYcykaNCDsiLEoFHTvR=jnbluXPrJKBdYcykaNCDsiLEoFHTvA.get('skey').strip()
     if jnbluXPrJKBdYcykaNCDsiLEoFHTmg!=jnbluXPrJKBdYcykaNCDsiLEoFHTvR:
      fp.write(jnbluXPrJKBdYcykaNCDsiLEoFHTvf)
    fp.close()
   except:
    jnbluXPrJKBdYcykaNCDsiLEoFHTWe
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTmI=='WATCH_ALL':
   jnbluXPrJKBdYcykaNCDsiLEoFHTmU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%jnbluXPrJKBdYcykaNCDsiLEoFHTmq))
   if os.path.isfile(jnbluXPrJKBdYcykaNCDsiLEoFHTmU):os.remove(jnbluXPrJKBdYcykaNCDsiLEoFHTmU)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTmI=='WATCH_ONE':
   jnbluXPrJKBdYcykaNCDsiLEoFHTmU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%jnbluXPrJKBdYcykaNCDsiLEoFHTmq))
   try:
    jnbluXPrJKBdYcykaNCDsiLEoFHTmp=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.Load_List_File(jnbluXPrJKBdYcykaNCDsiLEoFHTmq) 
    fp=jnbluXPrJKBdYcykaNCDsiLEoFHTWU(jnbluXPrJKBdYcykaNCDsiLEoFHTmU,'w',-1,'utf-8')
    for jnbluXPrJKBdYcykaNCDsiLEoFHTvf in jnbluXPrJKBdYcykaNCDsiLEoFHTmp:
     jnbluXPrJKBdYcykaNCDsiLEoFHTvA=jnbluXPrJKBdYcykaNCDsiLEoFHTWG(urllib.parse.parse_qsl(jnbluXPrJKBdYcykaNCDsiLEoFHTvf))
     jnbluXPrJKBdYcykaNCDsiLEoFHTvR=jnbluXPrJKBdYcykaNCDsiLEoFHTvA.get('code').strip()
     if jnbluXPrJKBdYcykaNCDsiLEoFHTmg!=jnbluXPrJKBdYcykaNCDsiLEoFHTvR:
      fp.write(jnbluXPrJKBdYcykaNCDsiLEoFHTvf)
    fp.close()
   except:
    jnbluXPrJKBdYcykaNCDsiLEoFHTWe
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,jnbluXPrJKBdYcykaNCDsiLEoFHTRM): 
  try:
   if jnbluXPrJKBdYcykaNCDsiLEoFHTRM=='search':
    jnbluXPrJKBdYcykaNCDsiLEoFHTmU=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_SEARCHEDC_FILENAME
   elif jnbluXPrJKBdYcykaNCDsiLEoFHTRM in['seasons','movie']:
    jnbluXPrJKBdYcykaNCDsiLEoFHTmU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%jnbluXPrJKBdYcykaNCDsiLEoFHTRM))
   else:
    return[]
   fp=jnbluXPrJKBdYcykaNCDsiLEoFHTWU(jnbluXPrJKBdYcykaNCDsiLEoFHTmU,'r',-1,'utf-8')
   jnbluXPrJKBdYcykaNCDsiLEoFHTvw=fp.readlines()
   fp.close()
  except:
   jnbluXPrJKBdYcykaNCDsiLEoFHTvw=[]
  return jnbluXPrJKBdYcykaNCDsiLEoFHTvw
 def Save_Watched_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,jnbluXPrJKBdYcykaNCDsiLEoFHTRM,jnbluXPrJKBdYcykaNCDsiLEoFHTfe):
  try:
   jnbluXPrJKBdYcykaNCDsiLEoFHTvQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%jnbluXPrJKBdYcykaNCDsiLEoFHTRM))
   jnbluXPrJKBdYcykaNCDsiLEoFHTmp=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.Load_List_File(jnbluXPrJKBdYcykaNCDsiLEoFHTRM) 
   fp=jnbluXPrJKBdYcykaNCDsiLEoFHTWU(jnbluXPrJKBdYcykaNCDsiLEoFHTvQ,'w',-1,'utf-8')
   jnbluXPrJKBdYcykaNCDsiLEoFHTvm=urllib.parse.urlencode(jnbluXPrJKBdYcykaNCDsiLEoFHTfe)
   jnbluXPrJKBdYcykaNCDsiLEoFHTvm=jnbluXPrJKBdYcykaNCDsiLEoFHTvm+'\n'
   fp.write(jnbluXPrJKBdYcykaNCDsiLEoFHTvm)
   jnbluXPrJKBdYcykaNCDsiLEoFHTvW=0
   for jnbluXPrJKBdYcykaNCDsiLEoFHTvf in jnbluXPrJKBdYcykaNCDsiLEoFHTmp:
    jnbluXPrJKBdYcykaNCDsiLEoFHTvA=jnbluXPrJKBdYcykaNCDsiLEoFHTWG(urllib.parse.parse_qsl(jnbluXPrJKBdYcykaNCDsiLEoFHTvf))
    jnbluXPrJKBdYcykaNCDsiLEoFHTvt=jnbluXPrJKBdYcykaNCDsiLEoFHTfe.get('code').strip()
    jnbluXPrJKBdYcykaNCDsiLEoFHTvz=jnbluXPrJKBdYcykaNCDsiLEoFHTvA.get('code').strip()
    if jnbluXPrJKBdYcykaNCDsiLEoFHTRM=='seasons' and jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_settings_direct_replay()==jnbluXPrJKBdYcykaNCDsiLEoFHTWx:
     jnbluXPrJKBdYcykaNCDsiLEoFHTvt=jnbluXPrJKBdYcykaNCDsiLEoFHTfe.get('videoid').strip()
     jnbluXPrJKBdYcykaNCDsiLEoFHTvz=jnbluXPrJKBdYcykaNCDsiLEoFHTvA.get('videoid').strip()if jnbluXPrJKBdYcykaNCDsiLEoFHTvz!=jnbluXPrJKBdYcykaNCDsiLEoFHTWe else '-'
    if jnbluXPrJKBdYcykaNCDsiLEoFHTvt!=jnbluXPrJKBdYcykaNCDsiLEoFHTvz:
     fp.write(jnbluXPrJKBdYcykaNCDsiLEoFHTvf)
     jnbluXPrJKBdYcykaNCDsiLEoFHTvW+=1
     if jnbluXPrJKBdYcykaNCDsiLEoFHTvW>=50:break
   fp.close()
  except:
   jnbluXPrJKBdYcykaNCDsiLEoFHTWe
 def dp_Watch_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTRM =args.get('stype')
  jnbluXPrJKBdYcykaNCDsiLEoFHTAx=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_settings_direct_replay()
  if jnbluXPrJKBdYcykaNCDsiLEoFHTRM=='-':
   for jnbluXPrJKBdYcykaNCDsiLEoFHTve in jnbluXPrJKBdYcykaNCDsiLEoFHTfw:
    jnbluXPrJKBdYcykaNCDsiLEoFHTAG=jnbluXPrJKBdYcykaNCDsiLEoFHTve.get('title')
    jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':jnbluXPrJKBdYcykaNCDsiLEoFHTve.get('mode'),'stype':jnbluXPrJKBdYcykaNCDsiLEoFHTve.get('stype')}
    jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel='',img='',infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTWe,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWx,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU)
   if jnbluXPrJKBdYcykaNCDsiLEoFHTWI(jnbluXPrJKBdYcykaNCDsiLEoFHTfw)>0:xbmcplugin.endOfDirectory(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle)
  else:
   jnbluXPrJKBdYcykaNCDsiLEoFHTvO=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.Load_List_File(jnbluXPrJKBdYcykaNCDsiLEoFHTRM)
   for jnbluXPrJKBdYcykaNCDsiLEoFHTvx in jnbluXPrJKBdYcykaNCDsiLEoFHTvO:
    jnbluXPrJKBdYcykaNCDsiLEoFHTmx=jnbluXPrJKBdYcykaNCDsiLEoFHTWG(urllib.parse.parse_qsl(jnbluXPrJKBdYcykaNCDsiLEoFHTvx))
    jnbluXPrJKBdYcykaNCDsiLEoFHTwm=jnbluXPrJKBdYcykaNCDsiLEoFHTmx.get('code').strip()
    jnbluXPrJKBdYcykaNCDsiLEoFHTAG =jnbluXPrJKBdYcykaNCDsiLEoFHTmx.get('title').strip()
    jnbluXPrJKBdYcykaNCDsiLEoFHTwW =jnbluXPrJKBdYcykaNCDsiLEoFHTmx.get('img').strip()
    jnbluXPrJKBdYcykaNCDsiLEoFHTvV =jnbluXPrJKBdYcykaNCDsiLEoFHTmx.get('videoid').strip()
    try:
     jnbluXPrJKBdYcykaNCDsiLEoFHTwW=jnbluXPrJKBdYcykaNCDsiLEoFHTwW.replace('\'','\"')
     jnbluXPrJKBdYcykaNCDsiLEoFHTwW=json.loads(jnbluXPrJKBdYcykaNCDsiLEoFHTwW)
    except:
     jnbluXPrJKBdYcykaNCDsiLEoFHTWe
    jnbluXPrJKBdYcykaNCDsiLEoFHTQI={}
    jnbluXPrJKBdYcykaNCDsiLEoFHTQI['plot']=jnbluXPrJKBdYcykaNCDsiLEoFHTAG
    if jnbluXPrJKBdYcykaNCDsiLEoFHTRM=='movie':
     jnbluXPrJKBdYcykaNCDsiLEoFHTQI['mediatype']='movie'
     jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':'MOVIE','page':'1','movie_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwm,'season_code':'-','title':jnbluXPrJKBdYcykaNCDsiLEoFHTAG,'thumbnail':jnbluXPrJKBdYcykaNCDsiLEoFHTwW}
     jnbluXPrJKBdYcykaNCDsiLEoFHTAp=jnbluXPrJKBdYcykaNCDsiLEoFHTWV
    else:
     if jnbluXPrJKBdYcykaNCDsiLEoFHTAx==jnbluXPrJKBdYcykaNCDsiLEoFHTWV or jnbluXPrJKBdYcykaNCDsiLEoFHTvV==jnbluXPrJKBdYcykaNCDsiLEoFHTWe:
      jnbluXPrJKBdYcykaNCDsiLEoFHTQI['mediatype']='tvshow'
      jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':'EPISODE','page':'1','movie_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwm,'season_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwm,'title':jnbluXPrJKBdYcykaNCDsiLEoFHTAG,'thumbnail':jnbluXPrJKBdYcykaNCDsiLEoFHTwW}
      jnbluXPrJKBdYcykaNCDsiLEoFHTAp=jnbluXPrJKBdYcykaNCDsiLEoFHTWx
     else:
      jnbluXPrJKBdYcykaNCDsiLEoFHTQI['mediatype']='episode'
      jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':'MOVIE','movie_code':jnbluXPrJKBdYcykaNCDsiLEoFHTvV,'season_code':jnbluXPrJKBdYcykaNCDsiLEoFHTwm,'title':jnbluXPrJKBdYcykaNCDsiLEoFHTAG,'thumbnail':jnbluXPrJKBdYcykaNCDsiLEoFHTwW}
      jnbluXPrJKBdYcykaNCDsiLEoFHTAp=jnbluXPrJKBdYcykaNCDsiLEoFHTWV
    jnbluXPrJKBdYcykaNCDsiLEoFHTmh={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':jnbluXPrJKBdYcykaNCDsiLEoFHTwm,'vType':jnbluXPrJKBdYcykaNCDsiLEoFHTRM,}
    jnbluXPrJKBdYcykaNCDsiLEoFHTmG=urllib.parse.urlencode(jnbluXPrJKBdYcykaNCDsiLEoFHTmh)
    jnbluXPrJKBdYcykaNCDsiLEoFHTQg=[('선택된 시청이력 ( %s ) 삭제'%(jnbluXPrJKBdYcykaNCDsiLEoFHTAG),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(jnbluXPrJKBdYcykaNCDsiLEoFHTmG))]
    jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel='',img=jnbluXPrJKBdYcykaNCDsiLEoFHTwW,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTQI,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTAp,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU,ContextMenu=jnbluXPrJKBdYcykaNCDsiLEoFHTQg)
   jnbluXPrJKBdYcykaNCDsiLEoFHTQI={'plot':'시청목록을 삭제합니다.'}
   jnbluXPrJKBdYcykaNCDsiLEoFHTAG='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   jnbluXPrJKBdYcykaNCDsiLEoFHTAU={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':jnbluXPrJKBdYcykaNCDsiLEoFHTRM,}
   jnbluXPrJKBdYcykaNCDsiLEoFHTAq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.add_dir(jnbluXPrJKBdYcykaNCDsiLEoFHTAG,sublabel='',img=jnbluXPrJKBdYcykaNCDsiLEoFHTAq,infoLabels=jnbluXPrJKBdYcykaNCDsiLEoFHTQI,isFolder=jnbluXPrJKBdYcykaNCDsiLEoFHTWV,params=jnbluXPrJKBdYcykaNCDsiLEoFHTAU,isLink=jnbluXPrJKBdYcykaNCDsiLEoFHTWx)
   if jnbluXPrJKBdYcykaNCDsiLEoFHTRM=='movie':xbmcplugin.setContent(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,'movies')
   else:xbmcplugin.setContent(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(jnbluXPrJKBdYcykaNCDsiLEoFHTfW._addon_handle,cacheToDisc=jnbluXPrJKBdYcykaNCDsiLEoFHTWV)
 def Save_Searched_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,jnbluXPrJKBdYcykaNCDsiLEoFHTmM):
  try:
   jnbluXPrJKBdYcykaNCDsiLEoFHTvh=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_SEARCHEDC_FILENAME
   jnbluXPrJKBdYcykaNCDsiLEoFHTmp=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.Load_List_File('search') 
   jnbluXPrJKBdYcykaNCDsiLEoFHTvG={'skey':jnbluXPrJKBdYcykaNCDsiLEoFHTmM.strip()}
   fp=jnbluXPrJKBdYcykaNCDsiLEoFHTWU(jnbluXPrJKBdYcykaNCDsiLEoFHTvh,'w',-1,'utf-8')
   jnbluXPrJKBdYcykaNCDsiLEoFHTvm=urllib.parse.urlencode(jnbluXPrJKBdYcykaNCDsiLEoFHTvG)
   jnbluXPrJKBdYcykaNCDsiLEoFHTvm=jnbluXPrJKBdYcykaNCDsiLEoFHTvm+'\n'
   fp.write(jnbluXPrJKBdYcykaNCDsiLEoFHTvm)
   jnbluXPrJKBdYcykaNCDsiLEoFHTvW=0
   for jnbluXPrJKBdYcykaNCDsiLEoFHTvf in jnbluXPrJKBdYcykaNCDsiLEoFHTmp:
    jnbluXPrJKBdYcykaNCDsiLEoFHTvA=jnbluXPrJKBdYcykaNCDsiLEoFHTWG(urllib.parse.parse_qsl(jnbluXPrJKBdYcykaNCDsiLEoFHTvf))
    jnbluXPrJKBdYcykaNCDsiLEoFHTvt=jnbluXPrJKBdYcykaNCDsiLEoFHTvG.get('skey').strip()
    jnbluXPrJKBdYcykaNCDsiLEoFHTvz=jnbluXPrJKBdYcykaNCDsiLEoFHTvA.get('skey').strip()
    if jnbluXPrJKBdYcykaNCDsiLEoFHTvt!=jnbluXPrJKBdYcykaNCDsiLEoFHTvz:
     fp.write(jnbluXPrJKBdYcykaNCDsiLEoFHTvf)
     jnbluXPrJKBdYcykaNCDsiLEoFHTvW+=1
     if jnbluXPrJKBdYcykaNCDsiLEoFHTvW>=50:break
   fp.close()
  except:
   jnbluXPrJKBdYcykaNCDsiLEoFHTWe
 def logout(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  jnbluXPrJKBdYcykaNCDsiLEoFHTfx=xbmcgui.Dialog()
  jnbluXPrJKBdYcykaNCDsiLEoFHTRW=jnbluXPrJKBdYcykaNCDsiLEoFHTfx.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if jnbluXPrJKBdYcykaNCDsiLEoFHTRW==jnbluXPrJKBdYcykaNCDsiLEoFHTWV:sys.exit()
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.Init_WC_Total()
  if os.path.isfile(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_COOKIE_FILENAME):os.remove(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_COOKIE_FILENAME)
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  jnbluXPrJKBdYcykaNCDsiLEoFHTvM =jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.Get_Now_Datetime()
  jnbluXPrJKBdYcykaNCDsiLEoFHTvS=jnbluXPrJKBdYcykaNCDsiLEoFHTvM+datetime.timedelta(days=jnbluXPrJKBdYcykaNCDsiLEoFHTWO(__addon__.getSetting('cache_ttl')))
  (jnbluXPrJKBdYcykaNCDsiLEoFHTRQ,jnbluXPrJKBdYcykaNCDsiLEoFHTRm,jnbluXPrJKBdYcykaNCDsiLEoFHTRv)=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_settings_account()
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.Save_session_acount(jnbluXPrJKBdYcykaNCDsiLEoFHTRQ,jnbluXPrJKBdYcykaNCDsiLEoFHTRm,jnbluXPrJKBdYcykaNCDsiLEoFHTRv)
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC['account']['token_limit']=jnbluXPrJKBdYcykaNCDsiLEoFHTvS.strftime('%Y%m%d')
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.JsonFile_Save(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_COOKIE_FILENAME,jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC)
 def cookiefile_check(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.JsonFile_Load(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC_COOKIE_FILENAME)
  if 'account' not in jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC:
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.Init_WC_Total()
   return jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  if 'deviceId2' not in jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC['cookies']:
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.Init_WC_Total()
   return jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  (jnbluXPrJKBdYcykaNCDsiLEoFHTvI,jnbluXPrJKBdYcykaNCDsiLEoFHTvg,jnbluXPrJKBdYcykaNCDsiLEoFHTvq)=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.get_settings_account()
  (jnbluXPrJKBdYcykaNCDsiLEoFHTvU,jnbluXPrJKBdYcykaNCDsiLEoFHTvp,jnbluXPrJKBdYcykaNCDsiLEoFHTWf)=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.Load_session_acount()
  if jnbluXPrJKBdYcykaNCDsiLEoFHTvI!=jnbluXPrJKBdYcykaNCDsiLEoFHTvU or jnbluXPrJKBdYcykaNCDsiLEoFHTvg!=jnbluXPrJKBdYcykaNCDsiLEoFHTvp or jnbluXPrJKBdYcykaNCDsiLEoFHTvq!=jnbluXPrJKBdYcykaNCDsiLEoFHTWf:
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.Init_WC_Total()
   return jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  if jnbluXPrJKBdYcykaNCDsiLEoFHTWO(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))>jnbluXPrJKBdYcykaNCDsiLEoFHTWO(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.WC['account']['token_limit']):
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.Init_WC_Total()
   return jnbluXPrJKBdYcykaNCDsiLEoFHTWV
  return jnbluXPrJKBdYcykaNCDsiLEoFHTWx
 def dp_Global_Search(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTWA=args.get('mode')
  if jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='TOTAL_SEARCH':
   jnbluXPrJKBdYcykaNCDsiLEoFHTWR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   jnbluXPrJKBdYcykaNCDsiLEoFHTWR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(jnbluXPrJKBdYcykaNCDsiLEoFHTWR)
 def dp_Bookmark_Menu(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTWR='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(jnbluXPrJKBdYcykaNCDsiLEoFHTWR)
 def dp_Set_Bookmark(jnbluXPrJKBdYcykaNCDsiLEoFHTfW,args):
  jnbluXPrJKBdYcykaNCDsiLEoFHTmS=urllib.parse.unquote(args.get('bm_param'))
  jnbluXPrJKBdYcykaNCDsiLEoFHTmS=json.loads(jnbluXPrJKBdYcykaNCDsiLEoFHTmS)
  jnbluXPrJKBdYcykaNCDsiLEoFHTvV =jnbluXPrJKBdYcykaNCDsiLEoFHTmS.get('videoid')
  jnbluXPrJKBdYcykaNCDsiLEoFHTWw =jnbluXPrJKBdYcykaNCDsiLEoFHTmS.get('vidtype')
  jnbluXPrJKBdYcykaNCDsiLEoFHTWQ =jnbluXPrJKBdYcykaNCDsiLEoFHTmS.get('vtitle')
  jnbluXPrJKBdYcykaNCDsiLEoFHTWm =jnbluXPrJKBdYcykaNCDsiLEoFHTmS.get('vsubtitle')
  jnbluXPrJKBdYcykaNCDsiLEoFHTfx=xbmcgui.Dialog()
  jnbluXPrJKBdYcykaNCDsiLEoFHTRW=jnbluXPrJKBdYcykaNCDsiLEoFHTfx.yesno(__language__(30913).encode('utf8'),jnbluXPrJKBdYcykaNCDsiLEoFHTWQ+' \n\n'+__language__(30914))
  if jnbluXPrJKBdYcykaNCDsiLEoFHTRW==jnbluXPrJKBdYcykaNCDsiLEoFHTWV:return
  jnbluXPrJKBdYcykaNCDsiLEoFHTWv=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.GetBookmarkInfo(jnbluXPrJKBdYcykaNCDsiLEoFHTvV,jnbluXPrJKBdYcykaNCDsiLEoFHTWw)
  jnbluXPrJKBdYcykaNCDsiLEoFHTWt=json.dumps(jnbluXPrJKBdYcykaNCDsiLEoFHTWv)
  jnbluXPrJKBdYcykaNCDsiLEoFHTWt=urllib.parse.quote(jnbluXPrJKBdYcykaNCDsiLEoFHTWt)
  jnbluXPrJKBdYcykaNCDsiLEoFHTQp ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(jnbluXPrJKBdYcykaNCDsiLEoFHTWt)
  xbmc.executebuiltin(jnbluXPrJKBdYcykaNCDsiLEoFHTQp)
 def watcha_main(jnbluXPrJKBdYcykaNCDsiLEoFHTfW):
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.WatchaObj.KodiVersion=jnbluXPrJKBdYcykaNCDsiLEoFHTWO(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  jnbluXPrJKBdYcykaNCDsiLEoFHTWA=jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params.get('mode',jnbluXPrJKBdYcykaNCDsiLEoFHTWe)
  if jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='LOGOUT':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.logout()
   return
  jnbluXPrJKBdYcykaNCDsiLEoFHTfW.login_main()
  if jnbluXPrJKBdYcykaNCDsiLEoFHTWA is jnbluXPrJKBdYcykaNCDsiLEoFHTWe:
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Main_List()
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='HOME_GROUP':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_HomeGroup_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='SUB_GROUP':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_SubGroup_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='CATEGORY_LIST':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Category_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='SEASON':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Season_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='EPISODE':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Episode_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='ORDER_BY':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_setEpOrderby(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA in['SEARCH','LOCAL_SEARCH']:
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Search_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='MOVIE':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.play_VIDEO(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='WATCH':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Watch_List(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_History_Remove(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA in['TOTAL_SEARCH','TOTAL_HISTORY']:
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Global_Search(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='SEARCH_HISTORY':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Search_History(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='MENU_BOOKMARK':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Bookmark_Menu(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='SET_BOOKMARK':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Set_Bookmark(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  elif jnbluXPrJKBdYcykaNCDsiLEoFHTWA=='DELETE_CONTINUE':
   jnbluXPrJKBdYcykaNCDsiLEoFHTfW.dp_Delete_Continue(jnbluXPrJKBdYcykaNCDsiLEoFHTfW.main_params)
  else:
   jnbluXPrJKBdYcykaNCDsiLEoFHTWe
# Created by pyminifier (https://github.com/liftoff/pyminifier)
