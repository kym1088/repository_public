__author__="NightRain"
NzqQdpgTbeOMoYsKDFPUSLhxuliEHW=object
NzqQdpgTbeOMoYsKDFPUSLhxuliEHX=None
NzqQdpgTbeOMoYsKDFPUSLhxuliEHI=False
NzqQdpgTbeOMoYsKDFPUSLhxuliEtn=int
NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ=True
NzqQdpgTbeOMoYsKDFPUSLhxuliEtm=len
NzqQdpgTbeOMoYsKDFPUSLhxuliEtj=range
NzqQdpgTbeOMoYsKDFPUSLhxuliEtH=str
NzqQdpgTbeOMoYsKDFPUSLhxuliEtk=open
NzqQdpgTbeOMoYsKDFPUSLhxuliEta=dict
NzqQdpgTbeOMoYsKDFPUSLhxuliEtC=Exception
NzqQdpgTbeOMoYsKDFPUSLhxuliEtc=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
NzqQdpgTbeOMoYsKDFPUSLhxuliEnm=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'검색 (search)','mode':'SEARCH','stype':'-','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-'}]
NzqQdpgTbeOMoYsKDFPUSLhxuliEnj=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
NzqQdpgTbeOMoYsKDFPUSLhxuliEnH=40
NzqQdpgTbeOMoYsKDFPUSLhxuliEnt =20
NzqQdpgTbeOMoYsKDFPUSLhxuliEnk='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
NzqQdpgTbeOMoYsKDFPUSLhxuliEna =xbmc.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
NzqQdpgTbeOMoYsKDFPUSLhxuliEnC=xbmc.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class NzqQdpgTbeOMoYsKDFPUSLhxuliEnJ(NzqQdpgTbeOMoYsKDFPUSLhxuliEHW):
 def __init__(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,NzqQdpgTbeOMoYsKDFPUSLhxuliEny,NzqQdpgTbeOMoYsKDFPUSLhxuliEnG,NzqQdpgTbeOMoYsKDFPUSLhxuliEnv):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_url =NzqQdpgTbeOMoYsKDFPUSLhxuliEny
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_handle=NzqQdpgTbeOMoYsKDFPUSLhxuliEnG
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.main_params =NzqQdpgTbeOMoYsKDFPUSLhxuliEnv
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj =ykHuToFVgKfSrDvdlUJejpOIMxcENC() 
 def addon_noti(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,sting):
  try:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnB=xbmcgui.Dialog()
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnB.notification(__addonname__,sting)
  except:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHX
 def addon_log(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,string,isDebug=NzqQdpgTbeOMoYsKDFPUSLhxuliEHI):
  try:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnw=string.encode('utf-8','ignore')
  except:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnw='addonException: addon_log'
  if isDebug:NzqQdpgTbeOMoYsKDFPUSLhxuliEnR=xbmc.LOGDEBUG
  else:NzqQdpgTbeOMoYsKDFPUSLhxuliEnR=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,NzqQdpgTbeOMoYsKDFPUSLhxuliEnw),level=NzqQdpgTbeOMoYsKDFPUSLhxuliEnR)
 def get_keyboard_input(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,NzqQdpgTbeOMoYsKDFPUSLhxuliEJk):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnA=NzqQdpgTbeOMoYsKDFPUSLhxuliEHX
  kb=xbmc.Keyboard()
  kb.setHeading(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnA=kb.getText()
  return NzqQdpgTbeOMoYsKDFPUSLhxuliEnA
 def get_settings_login_info(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnr =__addon__.getSetting('id')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnf =__addon__.getSetting('pw')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnW=NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(__addon__.getSetting('selected_profile'))
  return(NzqQdpgTbeOMoYsKDFPUSLhxuliEnr,NzqQdpgTbeOMoYsKDFPUSLhxuliEnf,NzqQdpgTbeOMoYsKDFPUSLhxuliEnW)
 def get_selQuality(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  try:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnX=['3840x2160/1','1920x1080/1','1280x720/1']
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnI=NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(__addon__.getSetting('selected_quality'))
   return NzqQdpgTbeOMoYsKDFPUSLhxuliEnX[NzqQdpgTbeOMoYsKDFPUSLhxuliEnI]
  except:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHX
  return 1080 
 def get_settings_direct_replay(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJn=NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(__addon__.getSetting('direct_replay'))
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEJn==0:
   return NzqQdpgTbeOMoYsKDFPUSLhxuliEHI
  else:
   return NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ
 def set_winCredential(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,credential):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm=xbmcgui.Window(10000)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_LOGINTIME',NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm=xbmcgui.Window(10000)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJj={'watcha_token':NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.getProperty('WATCHA_M_TOKEN'),'watcha_guit':NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.getProperty('WATCHA_M_GUIT'),'watcha_guitv':NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.getProperty('WATCHA_M_GUITV'),'watcha_usercd':NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.getProperty('WATCHA_M_USERCD')}
  return NzqQdpgTbeOMoYsKDFPUSLhxuliEJj
 def set_winEpisodeOrderby(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,NzqQdpgTbeOMoYsKDFPUSLhxuliEJH):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm=xbmcgui.Window(10000)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_ORDERBY',NzqQdpgTbeOMoYsKDFPUSLhxuliEJH)
 def get_winEpisodeOrderby(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm=xbmcgui.Window(10000)
  return NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,args):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJH =args.get('orderby')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.set_winEpisodeOrderby(NzqQdpgTbeOMoYsKDFPUSLhxuliEJH)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,label,sublabel='',img='',infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEHX,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ,params=''):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJt='%s?%s'%(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_url,urllib.parse.urlencode(params))
  if sublabel:NzqQdpgTbeOMoYsKDFPUSLhxuliEJk='%s < %s >'%(label,sublabel)
  else: NzqQdpgTbeOMoYsKDFPUSLhxuliEJk=label
  if not img:img='DefaultFolder.png'
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJa=xbmcgui.ListItem(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJa.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:NzqQdpgTbeOMoYsKDFPUSLhxuliEJa.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:NzqQdpgTbeOMoYsKDFPUSLhxuliEJa.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_handle,NzqQdpgTbeOMoYsKDFPUSLhxuliEJt,NzqQdpgTbeOMoYsKDFPUSLhxuliEJa,isFolder)
 def dp_Main_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  for NzqQdpgTbeOMoYsKDFPUSLhxuliEJC in NzqQdpgTbeOMoYsKDFPUSLhxuliEnm:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJk=NzqQdpgTbeOMoYsKDFPUSLhxuliEJC.get('title')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={'mode':NzqQdpgTbeOMoYsKDFPUSLhxuliEJC.get('mode'),'stype':NzqQdpgTbeOMoYsKDFPUSLhxuliEJC.get('stype'),'api_path':NzqQdpgTbeOMoYsKDFPUSLhxuliEJC.get('api_path'),'page':'1','sort':NzqQdpgTbeOMoYsKDFPUSLhxuliEJC.get('sort'),'tag_id':'-'}
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEJC.get('mode')=='XXX':
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['mode']='XXX'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJy=NzqQdpgTbeOMoYsKDFPUSLhxuliEHI
   else:
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJy=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel='',img='',infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEHX,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEJy,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEtm(NzqQdpgTbeOMoYsKDFPUSLhxuliEnm)>0:xbmcplugin.endOfDirectory(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_handle)
 def login_main(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  (NzqQdpgTbeOMoYsKDFPUSLhxuliEJv,NzqQdpgTbeOMoYsKDFPUSLhxuliEJV,NzqQdpgTbeOMoYsKDFPUSLhxuliEJB)=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_settings_login_info()
  if not(NzqQdpgTbeOMoYsKDFPUSLhxuliEJv and NzqQdpgTbeOMoYsKDFPUSLhxuliEJV):
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnB=xbmcgui.Dialog()
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJw=NzqQdpgTbeOMoYsKDFPUSLhxuliEnB.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEJw==NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_winEpisodeOrderby()=='':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.set_winEpisodeOrderby('asc')
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.cookiefile_check():return
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJR =NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJA=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEJA==NzqQdpgTbeOMoYsKDFPUSLhxuliEHX or NzqQdpgTbeOMoYsKDFPUSLhxuliEJA=='':NzqQdpgTbeOMoYsKDFPUSLhxuliEJA=NzqQdpgTbeOMoYsKDFPUSLhxuliEtn('19000101')
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJr=0
   while NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ:
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJr+=1
    time.sleep(0.05)
    if NzqQdpgTbeOMoYsKDFPUSLhxuliEJA>=NzqQdpgTbeOMoYsKDFPUSLhxuliEJR:return
    if NzqQdpgTbeOMoYsKDFPUSLhxuliEJr>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEJA>=NzqQdpgTbeOMoYsKDFPUSLhxuliEJR:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.GetCredential(NzqQdpgTbeOMoYsKDFPUSLhxuliEJv,NzqQdpgTbeOMoYsKDFPUSLhxuliEJV,NzqQdpgTbeOMoYsKDFPUSLhxuliEJB):
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.set_winCredential(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.LoadCredential())
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,args):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.SaveCredential(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_winCredential())
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJf =args.get('stype')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJW =NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(args.get('page'))
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJX =args.get('sort')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJI=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.GetSubGroupList(NzqQdpgTbeOMoYsKDFPUSLhxuliEJf)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmn=NzqQdpgTbeOMoYsKDFPUSLhxuliEnH if NzqQdpgTbeOMoYsKDFPUSLhxuliEJf=='genres' else NzqQdpgTbeOMoYsKDFPUSLhxuliEnt
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmJ=NzqQdpgTbeOMoYsKDFPUSLhxuliEtm(NzqQdpgTbeOMoYsKDFPUSLhxuliEJI)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmj =NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(NzqQdpgTbeOMoYsKDFPUSLhxuliEmJ//(NzqQdpgTbeOMoYsKDFPUSLhxuliEmn+1))+1
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmH =(NzqQdpgTbeOMoYsKDFPUSLhxuliEJW-1)*NzqQdpgTbeOMoYsKDFPUSLhxuliEmn
  for i in NzqQdpgTbeOMoYsKDFPUSLhxuliEtj(NzqQdpgTbeOMoYsKDFPUSLhxuliEmn):
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmt=NzqQdpgTbeOMoYsKDFPUSLhxuliEmH+i
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEmt>=NzqQdpgTbeOMoYsKDFPUSLhxuliEmJ:break
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJk =NzqQdpgTbeOMoYsKDFPUSLhxuliEJI[NzqQdpgTbeOMoYsKDFPUSLhxuliEmt].get('group_name')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmk =NzqQdpgTbeOMoYsKDFPUSLhxuliEJI[NzqQdpgTbeOMoYsKDFPUSLhxuliEmt].get('api_path')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEma =NzqQdpgTbeOMoYsKDFPUSLhxuliEJI[NzqQdpgTbeOMoYsKDFPUSLhxuliEmt].get('tag_id')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={'mode':'CATEGORY_LIST','api_path':NzqQdpgTbeOMoYsKDFPUSLhxuliEmk,'tag_id':NzqQdpgTbeOMoYsKDFPUSLhxuliEma,'stype':NzqQdpgTbeOMoYsKDFPUSLhxuliEJf,'page':'1','sort':NzqQdpgTbeOMoYsKDFPUSLhxuliEJX}
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel='',img='',infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEHX,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEmj>NzqQdpgTbeOMoYsKDFPUSLhxuliEJW:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={}
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['mode'] ='SUB_GROUP' 
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['stype'] =NzqQdpgTbeOMoYsKDFPUSLhxuliEJf
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['api_path']=args.get('api_path')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['page'] =NzqQdpgTbeOMoYsKDFPUSLhxuliEtH(NzqQdpgTbeOMoYsKDFPUSLhxuliEJW+1)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['sort'] =NzqQdpgTbeOMoYsKDFPUSLhxuliEJX
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJk='[B]%s >>[/B]'%'다음 페이지'
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmC=NzqQdpgTbeOMoYsKDFPUSLhxuliEtH(NzqQdpgTbeOMoYsKDFPUSLhxuliEJW+1)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel=NzqQdpgTbeOMoYsKDFPUSLhxuliEmC,img='',infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEHX,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEtm(NzqQdpgTbeOMoYsKDFPUSLhxuliEJI)>0:xbmcplugin.endOfDirectory(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_handle,cacheToDisc=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ)
 def play_VIDEO(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,args):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.SaveCredential(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_winCredential())
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmc =args.get('movie_code')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmy =args.get('season_code')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJk =args.get('title')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmG =args.get('thumbnail')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmv =NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_selQuality()
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.addon_log(NzqQdpgTbeOMoYsKDFPUSLhxuliEmc+' - '+NzqQdpgTbeOMoYsKDFPUSLhxuliEmy,NzqQdpgTbeOMoYsKDFPUSLhxuliEHI)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmV,NzqQdpgTbeOMoYsKDFPUSLhxuliEmB,NzqQdpgTbeOMoYsKDFPUSLhxuliEmw=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.GetStreamingURL(NzqQdpgTbeOMoYsKDFPUSLhxuliEmc,NzqQdpgTbeOMoYsKDFPUSLhxuliEmv)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEmV=='':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.addon_noti(__language__(30908).encode('utf8'))
   return
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmR=NzqQdpgTbeOMoYsKDFPUSLhxuliEmV
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.addon_log(NzqQdpgTbeOMoYsKDFPUSLhxuliEmR,NzqQdpgTbeOMoYsKDFPUSLhxuliEHI)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmA=xbmcgui.ListItem(path=NzqQdpgTbeOMoYsKDFPUSLhxuliEmR)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEmw:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmr=NzqQdpgTbeOMoYsKDFPUSLhxuliEmw
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmf ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmW ='mpd'
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmX ='com.widevine.alpha'
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmI =inputstreamhelper.Helper(NzqQdpgTbeOMoYsKDFPUSLhxuliEmW,drm=NzqQdpgTbeOMoYsKDFPUSLhxuliEmX)
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEmI.check_inputstream():
    NzqQdpgTbeOMoYsKDFPUSLhxuliEjn={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+NzqQdpgTbeOMoYsKDFPUSLhxuliEmc,'dt-custom-data':NzqQdpgTbeOMoYsKDFPUSLhxuliEmr,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':NzqQdpgTbeOMoYsKDFPUSLhxuliEnk,'Content-Type':'application/octet-stream'}
    NzqQdpgTbeOMoYsKDFPUSLhxuliEjJ=NzqQdpgTbeOMoYsKDFPUSLhxuliEmf+'|'+urllib.parse.urlencode(NzqQdpgTbeOMoYsKDFPUSLhxuliEjn)+'|R{SSM}|'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.addon_log(NzqQdpgTbeOMoYsKDFPUSLhxuliEjJ)
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmA.setProperty('inputstream',NzqQdpgTbeOMoYsKDFPUSLhxuliEmI.inputstream_addon)
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmA.setProperty('inputstream.adaptive.manifest_type',NzqQdpgTbeOMoYsKDFPUSLhxuliEmW)
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmA.setProperty('inputstream.adaptive.license_type',NzqQdpgTbeOMoYsKDFPUSLhxuliEmX)
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmA.setProperty('inputstream.adaptive.license_key',NzqQdpgTbeOMoYsKDFPUSLhxuliEjJ)
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmA.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(NzqQdpgTbeOMoYsKDFPUSLhxuliEnk))
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEmB:
   try:
    f=NzqQdpgTbeOMoYsKDFPUSLhxuliEtk(NzqQdpgTbeOMoYsKDFPUSLhxuliEna,'w',-1,'utf-8')
    NzqQdpgTbeOMoYsKDFPUSLhxuliEjm=requests.get(NzqQdpgTbeOMoYsKDFPUSLhxuliEmB)
    NzqQdpgTbeOMoYsKDFPUSLhxuliEjH=NzqQdpgTbeOMoYsKDFPUSLhxuliEjm.content.decode('utf-8') 
    for NzqQdpgTbeOMoYsKDFPUSLhxuliEjt in NzqQdpgTbeOMoYsKDFPUSLhxuliEjH.splitlines():
     NzqQdpgTbeOMoYsKDFPUSLhxuliEjk=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',NzqQdpgTbeOMoYsKDFPUSLhxuliEjt)
     f.write(NzqQdpgTbeOMoYsKDFPUSLhxuliEjk+'\n')
    f.close()
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmA.setSubtitles([NzqQdpgTbeOMoYsKDFPUSLhxuliEna,NzqQdpgTbeOMoYsKDFPUSLhxuliEmB])
   except:
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmA.setSubtitles([NzqQdpgTbeOMoYsKDFPUSLhxuliEmB])
  xbmcplugin.setResolvedUrl(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_handle,NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ,NzqQdpgTbeOMoYsKDFPUSLhxuliEmA)
  try:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJf='movie' if NzqQdpgTbeOMoYsKDFPUSLhxuliEmy=='-' else 'seasons'
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={'code':NzqQdpgTbeOMoYsKDFPUSLhxuliEmc if NzqQdpgTbeOMoYsKDFPUSLhxuliEJf=='movie' else NzqQdpgTbeOMoYsKDFPUSLhxuliEmy,'img':NzqQdpgTbeOMoYsKDFPUSLhxuliEmG,'title':NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,'videoid':NzqQdpgTbeOMoYsKDFPUSLhxuliEmc}
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.Save_Watched_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEJf,NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
  except:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHX
 def dp_Category_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,args):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.SaveCredential(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_winCredential())
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJf =args.get('stype')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEma =args.get('tag_id')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmk=args.get('api_path')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJW=NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(args.get('page'))
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJX =args.get('sort')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEja,NzqQdpgTbeOMoYsKDFPUSLhxuliEjC=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.GetCategoryList(NzqQdpgTbeOMoYsKDFPUSLhxuliEJf,NzqQdpgTbeOMoYsKDFPUSLhxuliEma,NzqQdpgTbeOMoYsKDFPUSLhxuliEmk,NzqQdpgTbeOMoYsKDFPUSLhxuliEJW,NzqQdpgTbeOMoYsKDFPUSLhxuliEJX)
  for NzqQdpgTbeOMoYsKDFPUSLhxuliEjc in NzqQdpgTbeOMoYsKDFPUSLhxuliEja:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmc =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('code')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJk =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('title')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjy =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('content_type')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjG =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('story')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmG =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('thumbnail')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjv =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('year')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjV =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('film_rating_code')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjB=NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('film_rating_short')
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEjy=='movies': 
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJy=NzqQdpgTbeOMoYsKDFPUSLhxuliEHI
    NzqQdpgTbeOMoYsKDFPUSLhxuliEjw ='MOVIE'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJG=''
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmy='-'
   else: 
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJy=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ
    NzqQdpgTbeOMoYsKDFPUSLhxuliEjw ='EPISODE'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJG='Series'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmy=NzqQdpgTbeOMoYsKDFPUSLhxuliEmc
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjR=NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('info')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjR['plot']='%s (%s)\n년도 : %s\n\n%s'%(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,NzqQdpgTbeOMoYsKDFPUSLhxuliEjB,NzqQdpgTbeOMoYsKDFPUSLhxuliEjv,NzqQdpgTbeOMoYsKDFPUSLhxuliEjG)
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEjV>=19:
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJk+='  (%s년 - %s)'%(NzqQdpgTbeOMoYsKDFPUSLhxuliEjv,NzqQdpgTbeOMoYsKDFPUSLhxuliEtH(NzqQdpgTbeOMoYsKDFPUSLhxuliEjB))
   else:
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJk+='  (%s년)'%(NzqQdpgTbeOMoYsKDFPUSLhxuliEjv)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={'mode':NzqQdpgTbeOMoYsKDFPUSLhxuliEjw,'movie_code':NzqQdpgTbeOMoYsKDFPUSLhxuliEmc,'page':'1','season_code':NzqQdpgTbeOMoYsKDFPUSLhxuliEmy,'title':NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,'thumbnail':NzqQdpgTbeOMoYsKDFPUSLhxuliEmG}
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel=NzqQdpgTbeOMoYsKDFPUSLhxuliEJG,img=NzqQdpgTbeOMoYsKDFPUSLhxuliEmG,infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEjR,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEJy,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEjC:
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.GetCategoryList_morepage(NzqQdpgTbeOMoYsKDFPUSLhxuliEJf,NzqQdpgTbeOMoYsKDFPUSLhxuliEma,NzqQdpgTbeOMoYsKDFPUSLhxuliEmk,NzqQdpgTbeOMoYsKDFPUSLhxuliEJW+1,NzqQdpgTbeOMoYsKDFPUSLhxuliEJX):
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={}
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['mode'] ='CATEGORY_LIST'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['stype'] =NzqQdpgTbeOMoYsKDFPUSLhxuliEJf
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['tag_id'] =NzqQdpgTbeOMoYsKDFPUSLhxuliEma
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['api_path']=NzqQdpgTbeOMoYsKDFPUSLhxuliEmk
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['page'] =NzqQdpgTbeOMoYsKDFPUSLhxuliEtH(NzqQdpgTbeOMoYsKDFPUSLhxuliEJW+1)
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['sort'] =NzqQdpgTbeOMoYsKDFPUSLhxuliEJX
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJk='[B]%s >>[/B]'%'다음 페이지'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmC=NzqQdpgTbeOMoYsKDFPUSLhxuliEtH(NzqQdpgTbeOMoYsKDFPUSLhxuliEJW+1)
    NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel=NzqQdpgTbeOMoYsKDFPUSLhxuliEmC,img='',infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEHX,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEtm(NzqQdpgTbeOMoYsKDFPUSLhxuliEja)>0:
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEmk=='arrivals/latest':
    xbmcplugin.endOfDirectory(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_handle,cacheToDisc=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ)
   else:
    xbmcplugin.endOfDirectory(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_handle,cacheToDisc=NzqQdpgTbeOMoYsKDFPUSLhxuliEHI)
 def dp_Episode_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,args):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.SaveCredential(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_winCredential())
  NzqQdpgTbeOMoYsKDFPUSLhxuliEjr=args.get('movie_code')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJW =NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(args.get('page'))
  NzqQdpgTbeOMoYsKDFPUSLhxuliEmy =args.get('season_code')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEja,NzqQdpgTbeOMoYsKDFPUSLhxuliEjC=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.GetEpisodoList(NzqQdpgTbeOMoYsKDFPUSLhxuliEjr,NzqQdpgTbeOMoYsKDFPUSLhxuliEJW,orderby=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_winEpisodeOrderby())
  for NzqQdpgTbeOMoYsKDFPUSLhxuliEjc in NzqQdpgTbeOMoYsKDFPUSLhxuliEja:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmc =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('code')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJk =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('title')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmG =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('thumbnail')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjf =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('display_num')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjW=NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('season_title')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjR=NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('info')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjR['plot']='%s\n%s\n\n%s'%(NzqQdpgTbeOMoYsKDFPUSLhxuliEjW,NzqQdpgTbeOMoYsKDFPUSLhxuliEjf,NzqQdpgTbeOMoYsKDFPUSLhxuliEJk)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJk='(%s) %s'%(NzqQdpgTbeOMoYsKDFPUSLhxuliEjf,NzqQdpgTbeOMoYsKDFPUSLhxuliEJk)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={'mode':'MOVIE','movie_code':NzqQdpgTbeOMoYsKDFPUSLhxuliEmc,'season_code':NzqQdpgTbeOMoYsKDFPUSLhxuliEmy,'title':'%s < %s >'%(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,NzqQdpgTbeOMoYsKDFPUSLhxuliEjW),'thumbnail':NzqQdpgTbeOMoYsKDFPUSLhxuliEmG}
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel=NzqQdpgTbeOMoYsKDFPUSLhxuliEjW,img=NzqQdpgTbeOMoYsKDFPUSLhxuliEmG,infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEjR,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEHI,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEJW==1:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjR={'plot':'정렬순서를 변경합니다.'}
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={}
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['mode'] ='ORDER_BY' 
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_winEpisodeOrderby()=='desc':
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJk='정렬순서변경 : 최신화부터 -> 1회부터'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['orderby']='asc'
   else:
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJk='정렬순서변경 : 1회부터 -> 최신화부터'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['orderby']='desc'
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel='',img='',infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEjR,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEHI,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEjC:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['mode'] ='EPISODE' 
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['movie_code']=NzqQdpgTbeOMoYsKDFPUSLhxuliEjr
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['page'] =NzqQdpgTbeOMoYsKDFPUSLhxuliEtH(NzqQdpgTbeOMoYsKDFPUSLhxuliEJW+1)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJk='[B]%s >>[/B]'%'다음 페이지'
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmC=NzqQdpgTbeOMoYsKDFPUSLhxuliEtH(NzqQdpgTbeOMoYsKDFPUSLhxuliEJW+1)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel=NzqQdpgTbeOMoYsKDFPUSLhxuliEmC,img='',infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEHX,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEtm(NzqQdpgTbeOMoYsKDFPUSLhxuliEja)>0:xbmcplugin.endOfDirectory(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_handle,cacheToDisc=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ)
 def dp_Search_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,args):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.SaveCredential(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_winCredential())
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJW =NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(args.get('page'))
  if 'search_key' in args:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjX=args.get('search_key')
  else:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjX=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not NzqQdpgTbeOMoYsKDFPUSLhxuliEjX:return
  NzqQdpgTbeOMoYsKDFPUSLhxuliEja,NzqQdpgTbeOMoYsKDFPUSLhxuliEjC=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.GetSearchList(NzqQdpgTbeOMoYsKDFPUSLhxuliEjX,NzqQdpgTbeOMoYsKDFPUSLhxuliEJW)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEtm(NzqQdpgTbeOMoYsKDFPUSLhxuliEja)==0:return
  for NzqQdpgTbeOMoYsKDFPUSLhxuliEjc in NzqQdpgTbeOMoYsKDFPUSLhxuliEja:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmc =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('code')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJk =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('title')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjy=NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('content_type')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjG =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('story')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmG =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('thumbnail')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjv =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('year')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjV =NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('film_rating_code')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjB=NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('film_rating_short')
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEjy=='movies': 
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJy=NzqQdpgTbeOMoYsKDFPUSLhxuliEHI
    NzqQdpgTbeOMoYsKDFPUSLhxuliEjw ='MOVIE'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJG=''
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmy='-'
   else: 
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJy=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ
    NzqQdpgTbeOMoYsKDFPUSLhxuliEjw ='EPISODE'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJG='Series'
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmy=NzqQdpgTbeOMoYsKDFPUSLhxuliEmc
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjR=NzqQdpgTbeOMoYsKDFPUSLhxuliEjc.get('info')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjR['plot']='%s (%s)\n년도 : %s\n\n%s'%(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,NzqQdpgTbeOMoYsKDFPUSLhxuliEjB,NzqQdpgTbeOMoYsKDFPUSLhxuliEjv,NzqQdpgTbeOMoYsKDFPUSLhxuliEjG)
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEjV>=19:
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJk+='  (%s년 - %s)'%(NzqQdpgTbeOMoYsKDFPUSLhxuliEjv,NzqQdpgTbeOMoYsKDFPUSLhxuliEtH(NzqQdpgTbeOMoYsKDFPUSLhxuliEjB))
   else:
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJk+='  (%s년)'%(NzqQdpgTbeOMoYsKDFPUSLhxuliEjv)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={'mode':NzqQdpgTbeOMoYsKDFPUSLhxuliEjw,'movie_code':NzqQdpgTbeOMoYsKDFPUSLhxuliEmc,'page':'1','season_code':NzqQdpgTbeOMoYsKDFPUSLhxuliEmy,'title':NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,'thumbnail':NzqQdpgTbeOMoYsKDFPUSLhxuliEmG}
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel=NzqQdpgTbeOMoYsKDFPUSLhxuliEJG,img=NzqQdpgTbeOMoYsKDFPUSLhxuliEmG,infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEjR,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEJy,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEjC:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={}
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['mode'] ='SEARCH'
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['search_key']=NzqQdpgTbeOMoYsKDFPUSLhxuliEjX
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc['page'] =NzqQdpgTbeOMoYsKDFPUSLhxuliEtH(NzqQdpgTbeOMoYsKDFPUSLhxuliEJW+1)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJk='[B]%s >>[/B]'%'다음 페이지'
   NzqQdpgTbeOMoYsKDFPUSLhxuliEmC=NzqQdpgTbeOMoYsKDFPUSLhxuliEtH(NzqQdpgTbeOMoYsKDFPUSLhxuliEJW+1)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel=NzqQdpgTbeOMoYsKDFPUSLhxuliEmC,img='',infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEHX,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEtm(NzqQdpgTbeOMoYsKDFPUSLhxuliEja)>0:xbmcplugin.endOfDirectory(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_handle)
 def Delete_Watched_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,NzqQdpgTbeOMoYsKDFPUSLhxuliEJf):
  try:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjI=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NzqQdpgTbeOMoYsKDFPUSLhxuliEJf))
   fp=NzqQdpgTbeOMoYsKDFPUSLhxuliEtk(NzqQdpgTbeOMoYsKDFPUSLhxuliEjI,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHX
 def dp_WatchList_Delete(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,args):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJf=args.get('stype')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnB=xbmcgui.Dialog()
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJw=NzqQdpgTbeOMoYsKDFPUSLhxuliEnB.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEJw==NzqQdpgTbeOMoYsKDFPUSLhxuliEHI:sys.exit()
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.Delete_Watched_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEJf)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,NzqQdpgTbeOMoYsKDFPUSLhxuliEJf):
  try:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjI=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NzqQdpgTbeOMoYsKDFPUSLhxuliEJf))
   fp=NzqQdpgTbeOMoYsKDFPUSLhxuliEtk(NzqQdpgTbeOMoYsKDFPUSLhxuliEjI,'r',-1,'utf-8')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHn=fp.readlines()
   fp.close()
  except:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHn=[]
  return NzqQdpgTbeOMoYsKDFPUSLhxuliEHn
 def Save_Watched_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,NzqQdpgTbeOMoYsKDFPUSLhxuliEJf,NzqQdpgTbeOMoYsKDFPUSLhxuliEnv):
  try:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjI=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NzqQdpgTbeOMoYsKDFPUSLhxuliEJf))
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHJ=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.Load_Watched_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEJf) 
   fp=NzqQdpgTbeOMoYsKDFPUSLhxuliEtk(NzqQdpgTbeOMoYsKDFPUSLhxuliEjI,'w',-1,'utf-8')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHm=urllib.parse.urlencode(NzqQdpgTbeOMoYsKDFPUSLhxuliEnv)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHm=NzqQdpgTbeOMoYsKDFPUSLhxuliEHm+'\n'
   fp.write(NzqQdpgTbeOMoYsKDFPUSLhxuliEHm)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHj=0
   for NzqQdpgTbeOMoYsKDFPUSLhxuliEHt in NzqQdpgTbeOMoYsKDFPUSLhxuliEHJ:
    NzqQdpgTbeOMoYsKDFPUSLhxuliEHk=NzqQdpgTbeOMoYsKDFPUSLhxuliEta(urllib.parse.parse_qsl(NzqQdpgTbeOMoYsKDFPUSLhxuliEHt))
    NzqQdpgTbeOMoYsKDFPUSLhxuliEHa=NzqQdpgTbeOMoYsKDFPUSLhxuliEnv.get('code')
    NzqQdpgTbeOMoYsKDFPUSLhxuliEHC=NzqQdpgTbeOMoYsKDFPUSLhxuliEHk.get('code')
    if NzqQdpgTbeOMoYsKDFPUSLhxuliEJf=='seasons' and NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_settings_direct_replay()==NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ:
     NzqQdpgTbeOMoYsKDFPUSLhxuliEHa=NzqQdpgTbeOMoYsKDFPUSLhxuliEnv.get('videoid')
     NzqQdpgTbeOMoYsKDFPUSLhxuliEHC=NzqQdpgTbeOMoYsKDFPUSLhxuliEHk.get('videoid')if NzqQdpgTbeOMoYsKDFPUSLhxuliEHC!=NzqQdpgTbeOMoYsKDFPUSLhxuliEHX else '-'
    if NzqQdpgTbeOMoYsKDFPUSLhxuliEHa!=NzqQdpgTbeOMoYsKDFPUSLhxuliEHC:
     fp.write(NzqQdpgTbeOMoYsKDFPUSLhxuliEHt)
     NzqQdpgTbeOMoYsKDFPUSLhxuliEHj+=1
     if NzqQdpgTbeOMoYsKDFPUSLhxuliEHj>=50:break
   fp.close()
  except:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHX
 def dp_Watch_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc,args):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJf =args.get('stype')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJn=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.get_settings_direct_replay()
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEJf=='-':
   for NzqQdpgTbeOMoYsKDFPUSLhxuliEHc in NzqQdpgTbeOMoYsKDFPUSLhxuliEnj:
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJk=NzqQdpgTbeOMoYsKDFPUSLhxuliEHc.get('title')
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={'mode':NzqQdpgTbeOMoYsKDFPUSLhxuliEHc.get('mode'),'stype':NzqQdpgTbeOMoYsKDFPUSLhxuliEHc.get('stype')}
    NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel='',img='',infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEHX,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
   if NzqQdpgTbeOMoYsKDFPUSLhxuliEtm(NzqQdpgTbeOMoYsKDFPUSLhxuliEnj)>0:xbmcplugin.endOfDirectory(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_handle)
  else:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHy=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.Load_Watched_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEJf)
   for NzqQdpgTbeOMoYsKDFPUSLhxuliEHG in NzqQdpgTbeOMoYsKDFPUSLhxuliEHy:
    NzqQdpgTbeOMoYsKDFPUSLhxuliEHv=NzqQdpgTbeOMoYsKDFPUSLhxuliEta(urllib.parse.parse_qsl(NzqQdpgTbeOMoYsKDFPUSLhxuliEHG))
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmc=NzqQdpgTbeOMoYsKDFPUSLhxuliEHv.get('code')
    NzqQdpgTbeOMoYsKDFPUSLhxuliEJk =NzqQdpgTbeOMoYsKDFPUSLhxuliEHv.get('title')
    NzqQdpgTbeOMoYsKDFPUSLhxuliEmG =NzqQdpgTbeOMoYsKDFPUSLhxuliEHv.get('img')
    NzqQdpgTbeOMoYsKDFPUSLhxuliEHV =NzqQdpgTbeOMoYsKDFPUSLhxuliEHv.get('videoid')
    NzqQdpgTbeOMoYsKDFPUSLhxuliEjR={}
    NzqQdpgTbeOMoYsKDFPUSLhxuliEjR['plot']=NzqQdpgTbeOMoYsKDFPUSLhxuliEJk
    if NzqQdpgTbeOMoYsKDFPUSLhxuliEJf=='movie':
     NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={'mode':'MOVIE','page':'1','movie_code':NzqQdpgTbeOMoYsKDFPUSLhxuliEmc,'season_code':'-','title':NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,'thumbnail':NzqQdpgTbeOMoYsKDFPUSLhxuliEmG}
     NzqQdpgTbeOMoYsKDFPUSLhxuliEJy=NzqQdpgTbeOMoYsKDFPUSLhxuliEHI
    else:
     if NzqQdpgTbeOMoYsKDFPUSLhxuliEJn==NzqQdpgTbeOMoYsKDFPUSLhxuliEHI or NzqQdpgTbeOMoYsKDFPUSLhxuliEHV==NzqQdpgTbeOMoYsKDFPUSLhxuliEHX:
      NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={'mode':'EPISODE','page':'1','movie_code':NzqQdpgTbeOMoYsKDFPUSLhxuliEmc,'season_code':NzqQdpgTbeOMoYsKDFPUSLhxuliEmc,'title':NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,'thumbnail':NzqQdpgTbeOMoYsKDFPUSLhxuliEmG}
      NzqQdpgTbeOMoYsKDFPUSLhxuliEJy=NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ
     else:
      NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={'mode':'MOVIE','movie_code':NzqQdpgTbeOMoYsKDFPUSLhxuliEHV,'season_code':NzqQdpgTbeOMoYsKDFPUSLhxuliEmc,'title':NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,'thumbnail':NzqQdpgTbeOMoYsKDFPUSLhxuliEmG}
      NzqQdpgTbeOMoYsKDFPUSLhxuliEJy=NzqQdpgTbeOMoYsKDFPUSLhxuliEHI
    NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel='',img=NzqQdpgTbeOMoYsKDFPUSLhxuliEmG,infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEjR,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEJy,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
   NzqQdpgTbeOMoYsKDFPUSLhxuliEjR={'plot':'시청목록을 삭제합니다.'}
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJk='*** 시청목록 삭제 ***'
   NzqQdpgTbeOMoYsKDFPUSLhxuliEJc={'mode':'MYVIEW_REMOVE','stype':NzqQdpgTbeOMoYsKDFPUSLhxuliEJf}
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.add_dir(NzqQdpgTbeOMoYsKDFPUSLhxuliEJk,sublabel='',img='',infoLabels=NzqQdpgTbeOMoYsKDFPUSLhxuliEjR,isFolder=NzqQdpgTbeOMoYsKDFPUSLhxuliEHI,params=NzqQdpgTbeOMoYsKDFPUSLhxuliEJc)
   xbmcplugin.endOfDirectory(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc._addon_handle,cacheToDisc=NzqQdpgTbeOMoYsKDFPUSLhxuliEHI)
 def logout(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnB=xbmcgui.Dialog()
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJw=NzqQdpgTbeOMoYsKDFPUSLhxuliEnB.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEJw==NzqQdpgTbeOMoYsKDFPUSLhxuliEHI:sys.exit()
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.wininfo_clear()
  if os.path.isfile(NzqQdpgTbeOMoYsKDFPUSLhxuliEnC):os.remove(NzqQdpgTbeOMoYsKDFPUSLhxuliEnC)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm=xbmcgui.Window(10000)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_TOKEN','')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_GUIT','')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_GUITV','')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_USERCD','')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEHB =NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.Get_Now_Datetime()
  NzqQdpgTbeOMoYsKDFPUSLhxuliEHw=NzqQdpgTbeOMoYsKDFPUSLhxuliEHB+datetime.timedelta(days=NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(__addon__.getSetting('cache_ttl')))
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm=xbmcgui.Window(10000)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEHR={'watcha_token':NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.getProperty('WATCHA_M_TOKEN'),'watcha_guit':NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.getProperty('WATCHA_M_GUIT'),'watcha_guitv':NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.getProperty('WATCHA_M_GUITV'),'watcha_usercd':NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':NzqQdpgTbeOMoYsKDFPUSLhxuliEHw.strftime('%Y-%m-%d')}
  try: 
   fp=NzqQdpgTbeOMoYsKDFPUSLhxuliEtk(NzqQdpgTbeOMoYsKDFPUSLhxuliEnC,'w',-1,'utf-8')
   json.dump(NzqQdpgTbeOMoYsKDFPUSLhxuliEHR,fp)
   fp.close()
  except NzqQdpgTbeOMoYsKDFPUSLhxuliEtC as exception:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEtc(exception)
 def cookiefile_check(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEHR={}
  try: 
   fp=NzqQdpgTbeOMoYsKDFPUSLhxuliEtk(NzqQdpgTbeOMoYsKDFPUSLhxuliEnC,'r',-1,'utf-8')
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHR= json.load(fp)
   fp.close()
  except NzqQdpgTbeOMoYsKDFPUSLhxuliEtC as exception:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.wininfo_clear()
   return NzqQdpgTbeOMoYsKDFPUSLhxuliEHI
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJv =__addon__.getSetting('id')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJV =__addon__.getSetting('pw')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEHA =__addon__.getSetting('selected_profile')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_id']=base64.standard_b64decode(NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_id']).decode('utf-8')
  NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_pw']=base64.standard_b64decode(NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_pw']).decode('utf-8')
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEJv!=NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_id']or NzqQdpgTbeOMoYsKDFPUSLhxuliEJV!=NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_pw']or NzqQdpgTbeOMoYsKDFPUSLhxuliEHA!=NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_profile']:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.wininfo_clear()
   return NzqQdpgTbeOMoYsKDFPUSLhxuliEHI
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJR =NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  NzqQdpgTbeOMoYsKDFPUSLhxuliEHr=NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_limitdate']
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJA =NzqQdpgTbeOMoYsKDFPUSLhxuliEtn(re.sub('-','',NzqQdpgTbeOMoYsKDFPUSLhxuliEHr))
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEJA<NzqQdpgTbeOMoYsKDFPUSLhxuliEJR:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.wininfo_clear()
   return NzqQdpgTbeOMoYsKDFPUSLhxuliEHI
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm=xbmcgui.Window(10000)
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_TOKEN',NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_token'])
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_GUIT',NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_guit'])
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_GUITV',NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_guitv'])
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_USERCD',NzqQdpgTbeOMoYsKDFPUSLhxuliEHR['watcha_usercd'])
  NzqQdpgTbeOMoYsKDFPUSLhxuliEJm.setProperty('WATCHA_M_LOGINTIME',NzqQdpgTbeOMoYsKDFPUSLhxuliEHr)
  return NzqQdpgTbeOMoYsKDFPUSLhxuliEtJ
 def watcha_main(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc):
  NzqQdpgTbeOMoYsKDFPUSLhxuliEHf=NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.main_params.get('mode',NzqQdpgTbeOMoYsKDFPUSLhxuliEHX)
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEHf=='LOGOUT':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.logout()
   return
  NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.login_main()
  if NzqQdpgTbeOMoYsKDFPUSLhxuliEHf is NzqQdpgTbeOMoYsKDFPUSLhxuliEHX:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.dp_Main_List()
  elif NzqQdpgTbeOMoYsKDFPUSLhxuliEHf=='SUB_GROUP':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.dp_SubGroup_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.main_params)
  elif NzqQdpgTbeOMoYsKDFPUSLhxuliEHf=='CATEGORY_LIST':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.dp_Category_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.main_params)
  elif NzqQdpgTbeOMoYsKDFPUSLhxuliEHf=='EPISODE':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.dp_Episode_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.main_params)
  elif NzqQdpgTbeOMoYsKDFPUSLhxuliEHf=='ORDER_BY':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.dp_setEpOrderby(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.main_params)
  elif NzqQdpgTbeOMoYsKDFPUSLhxuliEHf=='SEARCH':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.dp_Search_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.main_params)
  elif NzqQdpgTbeOMoYsKDFPUSLhxuliEHf=='MOVIE':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.play_VIDEO(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.main_params)
  elif NzqQdpgTbeOMoYsKDFPUSLhxuliEHf=='WATCH':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.dp_Watch_List(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.main_params)
  elif NzqQdpgTbeOMoYsKDFPUSLhxuliEHf=='MYVIEW_REMOVE':
   NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.dp_WatchList_Delete(NzqQdpgTbeOMoYsKDFPUSLhxuliEnc.main_params)
  else:
   NzqQdpgTbeOMoYsKDFPUSLhxuliEHX
# Created by pyminifier (https://github.com/liftoff/pyminifier)
