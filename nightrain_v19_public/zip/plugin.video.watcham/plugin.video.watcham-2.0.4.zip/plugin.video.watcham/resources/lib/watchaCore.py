__author__="NightRain"
ykHuToFVgKfSrDvdlUJejpOIMxcELN=object
ykHuToFVgKfSrDvdlUJejpOIMxcELC=None
ykHuToFVgKfSrDvdlUJejpOIMxcELY=False
ykHuToFVgKfSrDvdlUJejpOIMxcELa=True
ykHuToFVgKfSrDvdlUJejpOIMxcELR=Exception
ykHuToFVgKfSrDvdlUJejpOIMxcELG=print
ykHuToFVgKfSrDvdlUJejpOIMxcELQ=str
ykHuToFVgKfSrDvdlUJejpOIMxcELW=len
ykHuToFVgKfSrDvdlUJejpOIMxcELs=int
ykHuToFVgKfSrDvdlUJejpOIMxcELt=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import base64
import requests
import datetime
ykHuToFVgKfSrDvdlUJejpOIMxcENY='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
class ykHuToFVgKfSrDvdlUJejpOIMxcENC(ykHuToFVgKfSrDvdlUJejpOIMxcELN):
 def __init__(ykHuToFVgKfSrDvdlUJejpOIMxcENL):
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_TOKEN ='' 
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUIT =''
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUITV =''
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_USERCD=''
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.API_DOMAIN ='https://play.watcha.net'
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.EPISODE_LIMIT=20
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.SEARCH_LIMIT =30
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.DEFAULT_HEADER={'user-agent':ykHuToFVgKfSrDvdlUJejpOIMxcENY,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(ykHuToFVgKfSrDvdlUJejpOIMxcENL,jobtype,ykHuToFVgKfSrDvdlUJejpOIMxcENn,payload=ykHuToFVgKfSrDvdlUJejpOIMxcELC,params=ykHuToFVgKfSrDvdlUJejpOIMxcELC,headers=ykHuToFVgKfSrDvdlUJejpOIMxcELC,cookies=ykHuToFVgKfSrDvdlUJejpOIMxcELC,redirects=ykHuToFVgKfSrDvdlUJejpOIMxcELY):
  ykHuToFVgKfSrDvdlUJejpOIMxcENa=ykHuToFVgKfSrDvdlUJejpOIMxcENL.DEFAULT_HEADER
  if headers:ykHuToFVgKfSrDvdlUJejpOIMxcENa.update(headers)
  if jobtype=='Get':
   ykHuToFVgKfSrDvdlUJejpOIMxcENR=requests.get(ykHuToFVgKfSrDvdlUJejpOIMxcENn,params=params,headers=ykHuToFVgKfSrDvdlUJejpOIMxcENa,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   ykHuToFVgKfSrDvdlUJejpOIMxcENR=requests.put(ykHuToFVgKfSrDvdlUJejpOIMxcENn,data=payload,params=params,headers=ykHuToFVgKfSrDvdlUJejpOIMxcENa,cookies=cookies,allow_redirects=redirects)
  else:
   ykHuToFVgKfSrDvdlUJejpOIMxcENR=requests.post(ykHuToFVgKfSrDvdlUJejpOIMxcENn,data=payload,params=params,headers=ykHuToFVgKfSrDvdlUJejpOIMxcENa,cookies=cookies,allow_redirects=redirects)
  return ykHuToFVgKfSrDvdlUJejpOIMxcENR
 def SaveCredential(ykHuToFVgKfSrDvdlUJejpOIMxcENL,ykHuToFVgKfSrDvdlUJejpOIMxcENG):
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_TOKEN =ykHuToFVgKfSrDvdlUJejpOIMxcENG.get('watcha_token')
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUIT =ykHuToFVgKfSrDvdlUJejpOIMxcENG.get('watcha_guit')
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUITV =ykHuToFVgKfSrDvdlUJejpOIMxcENG.get('watcha_guitv')
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_USERCD =ykHuToFVgKfSrDvdlUJejpOIMxcENG.get('watcha_usercd')
 def SaveCredential_usercd(ykHuToFVgKfSrDvdlUJejpOIMxcENL,ykHuToFVgKfSrDvdlUJejpOIMxcENQ):
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_USERCD=ykHuToFVgKfSrDvdlUJejpOIMxcENQ
 def SaveCredential_guitv(ykHuToFVgKfSrDvdlUJejpOIMxcENL,ykHuToFVgKfSrDvdlUJejpOIMxcENW,ykHuToFVgKfSrDvdlUJejpOIMxcENs):
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUITV=ykHuToFVgKfSrDvdlUJejpOIMxcENW
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_TOKEN=ykHuToFVgKfSrDvdlUJejpOIMxcENs 
 def ClearCredential(ykHuToFVgKfSrDvdlUJejpOIMxcENL):
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_TOKEN ='' 
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUIT =''
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUITV =''
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_USERCD=''
 def LoadCredential(ykHuToFVgKfSrDvdlUJejpOIMxcENL):
  ykHuToFVgKfSrDvdlUJejpOIMxcENG={'watcha_token':ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_TOKEN,'watcha_guit':ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUIT,'watcha_guitv':ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUITV,'watcha_usercd':ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_USERCD}
  return ykHuToFVgKfSrDvdlUJejpOIMxcENG
 def makeDefaultCookies(ykHuToFVgKfSrDvdlUJejpOIMxcENL):
  ykHuToFVgKfSrDvdlUJejpOIMxcENt={'_s_guit':ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUIT,'_guinness-premium_session':ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_TOKEN}
  if ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUITV:
   ykHuToFVgKfSrDvdlUJejpOIMxcENt['_s_guitv']=ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_GUITV
  return ykHuToFVgKfSrDvdlUJejpOIMxcENt
 def makeurl(ykHuToFVgKfSrDvdlUJejpOIMxcENL,domain,path,query1=ykHuToFVgKfSrDvdlUJejpOIMxcELC,query2=ykHuToFVgKfSrDvdlUJejpOIMxcELC):
  ykHuToFVgKfSrDvdlUJejpOIMxcENn=domain+path
  if query1:
   ykHuToFVgKfSrDvdlUJejpOIMxcENn+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   ykHuToFVgKfSrDvdlUJejpOIMxcENn+='&%s'%urllib.parse.urlencode(query2)
  return ykHuToFVgKfSrDvdlUJejpOIMxcENn
 def GetCredential(ykHuToFVgKfSrDvdlUJejpOIMxcENL,user_id,user_pw,user_pf):
  ykHuToFVgKfSrDvdlUJejpOIMxcENP=ykHuToFVgKfSrDvdlUJejpOIMxcELY
  ykHuToFVgKfSrDvdlUJejpOIMxcENz=ykHuToFVgKfSrDvdlUJejpOIMxcENB='-'
  try:
   ykHuToFVgKfSrDvdlUJejpOIMxcENw=ykHuToFVgKfSrDvdlUJejpOIMxcENL.API_DOMAIN+'/api/session'
   ykHuToFVgKfSrDvdlUJejpOIMxcENi={'email':user_id,'password':user_pw}
   ykHuToFVgKfSrDvdlUJejpOIMxcENq={'accept':'application/vnd.frograms+json;version=4'}
   ykHuToFVgKfSrDvdlUJejpOIMxcENb=ykHuToFVgKfSrDvdlUJejpOIMxcENL.callRequestCookies('Post',ykHuToFVgKfSrDvdlUJejpOIMxcENw,payload=ykHuToFVgKfSrDvdlUJejpOIMxcENi,params=ykHuToFVgKfSrDvdlUJejpOIMxcELC,headers=ykHuToFVgKfSrDvdlUJejpOIMxcENq,cookies=ykHuToFVgKfSrDvdlUJejpOIMxcELC)
   for ykHuToFVgKfSrDvdlUJejpOIMxcENX in ykHuToFVgKfSrDvdlUJejpOIMxcENb.cookies:
    if ykHuToFVgKfSrDvdlUJejpOIMxcENX.name=='_guinness-premium_session':
     ykHuToFVgKfSrDvdlUJejpOIMxcENB=ykHuToFVgKfSrDvdlUJejpOIMxcENX.value
    elif ykHuToFVgKfSrDvdlUJejpOIMxcENX.name=='_s_guit':
     ykHuToFVgKfSrDvdlUJejpOIMxcENz=ykHuToFVgKfSrDvdlUJejpOIMxcENX.value
   if ykHuToFVgKfSrDvdlUJejpOIMxcENB:ykHuToFVgKfSrDvdlUJejpOIMxcENP=ykHuToFVgKfSrDvdlUJejpOIMxcELa
  except ykHuToFVgKfSrDvdlUJejpOIMxcELR as exception:
   ykHuToFVgKfSrDvdlUJejpOIMxcELG(exception)
   ykHuToFVgKfSrDvdlUJejpOIMxcENz=ykHuToFVgKfSrDvdlUJejpOIMxcENB='' 
  ykHuToFVgKfSrDvdlUJejpOIMxcENG={'watcha_guit':ykHuToFVgKfSrDvdlUJejpOIMxcENz,'watcha_token':ykHuToFVgKfSrDvdlUJejpOIMxcENB,'watcha_guitv':'','watcha_usercd':''}
  ykHuToFVgKfSrDvdlUJejpOIMxcENL.SaveCredential(ykHuToFVgKfSrDvdlUJejpOIMxcENG)
  try:
   ykHuToFVgKfSrDvdlUJejpOIMxcENm=ykHuToFVgKfSrDvdlUJejpOIMxcENL.GetProfilesList()
   ykHuToFVgKfSrDvdlUJejpOIMxcECN =ykHuToFVgKfSrDvdlUJejpOIMxcENm[user_pf]
   ykHuToFVgKfSrDvdlUJejpOIMxcENL.SaveCredential_usercd(ykHuToFVgKfSrDvdlUJejpOIMxcECN)
  except ykHuToFVgKfSrDvdlUJejpOIMxcELR as exception:
   ykHuToFVgKfSrDvdlUJejpOIMxcELG(exception)
   ykHuToFVgKfSrDvdlUJejpOIMxcENL.ClearCredential()
   return ykHuToFVgKfSrDvdlUJejpOIMxcELY
  if user_pf!=0:
   ykHuToFVgKfSrDvdlUJejpOIMxcENW,ykHuToFVgKfSrDvdlUJejpOIMxcENs=ykHuToFVgKfSrDvdlUJejpOIMxcENL.GetProfilesConvert(ykHuToFVgKfSrDvdlUJejpOIMxcECN)
   ykHuToFVgKfSrDvdlUJejpOIMxcENL.SaveCredential_guitv(ykHuToFVgKfSrDvdlUJejpOIMxcENW,ykHuToFVgKfSrDvdlUJejpOIMxcENs)
  return ykHuToFVgKfSrDvdlUJejpOIMxcENP
 def GetSubGroupList(ykHuToFVgKfSrDvdlUJejpOIMxcENL,stype):
  ykHuToFVgKfSrDvdlUJejpOIMxcECY=[]
  try:
   ykHuToFVgKfSrDvdlUJejpOIMxcECL ='/api/categories.json'
   ykHuToFVgKfSrDvdlUJejpOIMxcENn=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeurl(ykHuToFVgKfSrDvdlUJejpOIMxcENL.API_DOMAIN,ykHuToFVgKfSrDvdlUJejpOIMxcECL)
   ykHuToFVgKfSrDvdlUJejpOIMxcENX=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeDefaultCookies()
   ykHuToFVgKfSrDvdlUJejpOIMxcENb=ykHuToFVgKfSrDvdlUJejpOIMxcENL.callRequestCookies('Get',ykHuToFVgKfSrDvdlUJejpOIMxcENn,payload=ykHuToFVgKfSrDvdlUJejpOIMxcELC,params=ykHuToFVgKfSrDvdlUJejpOIMxcELC,headers=ykHuToFVgKfSrDvdlUJejpOIMxcELC,cookies=ykHuToFVgKfSrDvdlUJejpOIMxcENX)
   ykHuToFVgKfSrDvdlUJejpOIMxcECa=json.loads(ykHuToFVgKfSrDvdlUJejpOIMxcENb.text)
   if not('genres' in ykHuToFVgKfSrDvdlUJejpOIMxcECa):return ykHuToFVgKfSrDvdlUJejpOIMxcECY
   if stype=='genres':
    ykHuToFVgKfSrDvdlUJejpOIMxcECR=ykHuToFVgKfSrDvdlUJejpOIMxcECa['genres']
   else:
    ykHuToFVgKfSrDvdlUJejpOIMxcECR=ykHuToFVgKfSrDvdlUJejpOIMxcECa['tags']
   for ykHuToFVgKfSrDvdlUJejpOIMxcECG in ykHuToFVgKfSrDvdlUJejpOIMxcECR:
    ykHuToFVgKfSrDvdlUJejpOIMxcECQ=ykHuToFVgKfSrDvdlUJejpOIMxcECG['name']
    ykHuToFVgKfSrDvdlUJejpOIMxcECW =ykHuToFVgKfSrDvdlUJejpOIMxcECG['api_path']
    ykHuToFVgKfSrDvdlUJejpOIMxcECs =ykHuToFVgKfSrDvdlUJejpOIMxcECG['entity']['id']
    ykHuToFVgKfSrDvdlUJejpOIMxcECt={'group_name':ykHuToFVgKfSrDvdlUJejpOIMxcECQ,'api_path':ykHuToFVgKfSrDvdlUJejpOIMxcECW,'tag_id':ykHuToFVgKfSrDvdlUJejpOIMxcELQ(ykHuToFVgKfSrDvdlUJejpOIMxcECs)}
    ykHuToFVgKfSrDvdlUJejpOIMxcECY.append(ykHuToFVgKfSrDvdlUJejpOIMxcECt)
  except ykHuToFVgKfSrDvdlUJejpOIMxcELR as exception:
   ykHuToFVgKfSrDvdlUJejpOIMxcELG(exception)
  return ykHuToFVgKfSrDvdlUJejpOIMxcECY
 def GetCategoryList(ykHuToFVgKfSrDvdlUJejpOIMxcENL,stype,ykHuToFVgKfSrDvdlUJejpOIMxcECs,ykHuToFVgKfSrDvdlUJejpOIMxcECW,page_int,in_sort):
  ykHuToFVgKfSrDvdlUJejpOIMxcECY=[]
  ykHuToFVgKfSrDvdlUJejpOIMxcECn=ykHuToFVgKfSrDvdlUJejpOIMxcELY
  ykHuToFVgKfSrDvdlUJejpOIMxcECA={}
  try:
   if 'categories' in ykHuToFVgKfSrDvdlUJejpOIMxcECW:
    ykHuToFVgKfSrDvdlUJejpOIMxcECL ='/api/categories/contents.json'
    if stype=='genres':
     ykHuToFVgKfSrDvdlUJejpOIMxcECA['genre']=ykHuToFVgKfSrDvdlUJejpOIMxcECs
    else:
     ykHuToFVgKfSrDvdlUJejpOIMxcECA['tag'] =ykHuToFVgKfSrDvdlUJejpOIMxcECs
    ykHuToFVgKfSrDvdlUJejpOIMxcECA['order']=in_sort 
    if page_int>1:
     ykHuToFVgKfSrDvdlUJejpOIMxcECA['page']=ykHuToFVgKfSrDvdlUJejpOIMxcELQ(page_int-1)
   else: 
    ykHuToFVgKfSrDvdlUJejpOIMxcECL ='/api/'+ykHuToFVgKfSrDvdlUJejpOIMxcECW+'.json'
    if page_int>1:
     ykHuToFVgKfSrDvdlUJejpOIMxcECA['page']=ykHuToFVgKfSrDvdlUJejpOIMxcELQ(page_int)
   ykHuToFVgKfSrDvdlUJejpOIMxcENn=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeurl(ykHuToFVgKfSrDvdlUJejpOIMxcENL.API_DOMAIN,ykHuToFVgKfSrDvdlUJejpOIMxcECL)
   ykHuToFVgKfSrDvdlUJejpOIMxcENX=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeDefaultCookies()
   ykHuToFVgKfSrDvdlUJejpOIMxcENb=ykHuToFVgKfSrDvdlUJejpOIMxcENL.callRequestCookies('Get',ykHuToFVgKfSrDvdlUJejpOIMxcENn,payload=ykHuToFVgKfSrDvdlUJejpOIMxcELC,params=ykHuToFVgKfSrDvdlUJejpOIMxcECA,headers=ykHuToFVgKfSrDvdlUJejpOIMxcELC,cookies=ykHuToFVgKfSrDvdlUJejpOIMxcENX)
   ykHuToFVgKfSrDvdlUJejpOIMxcECa=json.loads(ykHuToFVgKfSrDvdlUJejpOIMxcENb.text)
   if not('contents' in ykHuToFVgKfSrDvdlUJejpOIMxcECa):return ykHuToFVgKfSrDvdlUJejpOIMxcECY,ykHuToFVgKfSrDvdlUJejpOIMxcECn
   ykHuToFVgKfSrDvdlUJejpOIMxcECR=ykHuToFVgKfSrDvdlUJejpOIMxcECa['contents']
   ykHuToFVgKfSrDvdlUJejpOIMxcECn=ykHuToFVgKfSrDvdlUJejpOIMxcECa['meta']['has_next']
   for ykHuToFVgKfSrDvdlUJejpOIMxcECG in ykHuToFVgKfSrDvdlUJejpOIMxcECR:
    ykHuToFVgKfSrDvdlUJejpOIMxcECh =ykHuToFVgKfSrDvdlUJejpOIMxcECG['code']
    ykHuToFVgKfSrDvdlUJejpOIMxcECP=ykHuToFVgKfSrDvdlUJejpOIMxcECG['content_type']
    ykHuToFVgKfSrDvdlUJejpOIMxcECz =ykHuToFVgKfSrDvdlUJejpOIMxcECG['title']
    ykHuToFVgKfSrDvdlUJejpOIMxcECw =ykHuToFVgKfSrDvdlUJejpOIMxcECG['story']
    if ykHuToFVgKfSrDvdlUJejpOIMxcECG['thumbnail']!=ykHuToFVgKfSrDvdlUJejpOIMxcELC:
     ykHuToFVgKfSrDvdlUJejpOIMxcECi =ykHuToFVgKfSrDvdlUJejpOIMxcECG['thumbnail']['medium']
    else:
     ykHuToFVgKfSrDvdlUJejpOIMxcECi =ykHuToFVgKfSrDvdlUJejpOIMxcECG['stillcut']['medium']
    ykHuToFVgKfSrDvdlUJejpOIMxcECq =ykHuToFVgKfSrDvdlUJejpOIMxcECG['year']
    ykHuToFVgKfSrDvdlUJejpOIMxcECb =ykHuToFVgKfSrDvdlUJejpOIMxcECG['film_rating_code']
    ykHuToFVgKfSrDvdlUJejpOIMxcECX=ykHuToFVgKfSrDvdlUJejpOIMxcECG['film_rating_short']
    ykHuToFVgKfSrDvdlUJejpOIMxcECB={}
    ykHuToFVgKfSrDvdlUJejpOIMxcECB['mpaa']=ykHuToFVgKfSrDvdlUJejpOIMxcECG['film_rating_long']
    ykHuToFVgKfSrDvdlUJejpOIMxcECB['year']=ykHuToFVgKfSrDvdlUJejpOIMxcECG['year']
    ykHuToFVgKfSrDvdlUJejpOIMxcECB['title']=ykHuToFVgKfSrDvdlUJejpOIMxcECG['title']
    if ykHuToFVgKfSrDvdlUJejpOIMxcECP=='movies':
     ykHuToFVgKfSrDvdlUJejpOIMxcECB['mediatype']='movie' 
     ykHuToFVgKfSrDvdlUJejpOIMxcECB['duration']=ykHuToFVgKfSrDvdlUJejpOIMxcECG['duration']
    else:
     ykHuToFVgKfSrDvdlUJejpOIMxcECB['mediatype']='episode' 
    ykHuToFVgKfSrDvdlUJejpOIMxcECt={'code':ykHuToFVgKfSrDvdlUJejpOIMxcECh,'content_type':ykHuToFVgKfSrDvdlUJejpOIMxcECP,'title':ykHuToFVgKfSrDvdlUJejpOIMxcECz,'story':ykHuToFVgKfSrDvdlUJejpOIMxcECw,'thumbnail':ykHuToFVgKfSrDvdlUJejpOIMxcECi,'year':ykHuToFVgKfSrDvdlUJejpOIMxcECq,'film_rating_code':ykHuToFVgKfSrDvdlUJejpOIMxcECb,'film_rating_short':ykHuToFVgKfSrDvdlUJejpOIMxcECX,'info':ykHuToFVgKfSrDvdlUJejpOIMxcECB}
    ykHuToFVgKfSrDvdlUJejpOIMxcECY.append(ykHuToFVgKfSrDvdlUJejpOIMxcECt)
  except ykHuToFVgKfSrDvdlUJejpOIMxcELR as exception:
   ykHuToFVgKfSrDvdlUJejpOIMxcELG(exception)
  return ykHuToFVgKfSrDvdlUJejpOIMxcECY,ykHuToFVgKfSrDvdlUJejpOIMxcECn
 def GetCategoryList_morepage(ykHuToFVgKfSrDvdlUJejpOIMxcENL,stype,ykHuToFVgKfSrDvdlUJejpOIMxcECs,ykHuToFVgKfSrDvdlUJejpOIMxcECW,page_int,in_sort):
  ykHuToFVgKfSrDvdlUJejpOIMxcECn=ykHuToFVgKfSrDvdlUJejpOIMxcELY
  if not('categories' in ykHuToFVgKfSrDvdlUJejpOIMxcECW):return ykHuToFVgKfSrDvdlUJejpOIMxcELa
  try:
   ykHuToFVgKfSrDvdlUJejpOIMxcECL ='/api/categories/contents.json'
   ykHuToFVgKfSrDvdlUJejpOIMxcECA={}
   if stype=='genres':
    ykHuToFVgKfSrDvdlUJejpOIMxcECA['genre']=ykHuToFVgKfSrDvdlUJejpOIMxcECs
   else:
    ykHuToFVgKfSrDvdlUJejpOIMxcECA['tag'] =ykHuToFVgKfSrDvdlUJejpOIMxcECs
   ykHuToFVgKfSrDvdlUJejpOIMxcECA['order']=in_sort 
   if page_int>1:
    ykHuToFVgKfSrDvdlUJejpOIMxcECA['page']=ykHuToFVgKfSrDvdlUJejpOIMxcELQ(page_int-1)
   ykHuToFVgKfSrDvdlUJejpOIMxcENn=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeurl(ykHuToFVgKfSrDvdlUJejpOIMxcENL.API_DOMAIN,ykHuToFVgKfSrDvdlUJejpOIMxcECL)
   ykHuToFVgKfSrDvdlUJejpOIMxcENX=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeDefaultCookies()
   ykHuToFVgKfSrDvdlUJejpOIMxcENb=ykHuToFVgKfSrDvdlUJejpOIMxcENL.callRequestCookies('Get',ykHuToFVgKfSrDvdlUJejpOIMxcENn,payload=ykHuToFVgKfSrDvdlUJejpOIMxcELC,params=ykHuToFVgKfSrDvdlUJejpOIMxcECA,headers=ykHuToFVgKfSrDvdlUJejpOIMxcELC,cookies=ykHuToFVgKfSrDvdlUJejpOIMxcENX)
   ykHuToFVgKfSrDvdlUJejpOIMxcECa=json.loads(ykHuToFVgKfSrDvdlUJejpOIMxcENb.text)
   ykHuToFVgKfSrDvdlUJejpOIMxcECn=ykHuToFVgKfSrDvdlUJejpOIMxcECa['meta']['has_next']
  except ykHuToFVgKfSrDvdlUJejpOIMxcELR as exception:
   ykHuToFVgKfSrDvdlUJejpOIMxcELG(exception)
  return ykHuToFVgKfSrDvdlUJejpOIMxcECn
 def GetEpisodoList(ykHuToFVgKfSrDvdlUJejpOIMxcENL,program_code,page_int,orderby='asc'):
  ykHuToFVgKfSrDvdlUJejpOIMxcECY=[]
  ykHuToFVgKfSrDvdlUJejpOIMxcECn=ykHuToFVgKfSrDvdlUJejpOIMxcELY
  ykHuToFVgKfSrDvdlUJejpOIMxcECm=''
  try:
   ykHuToFVgKfSrDvdlUJejpOIMxcECL ='/api/contents/'+program_code+'/tv_episodes.json'
   ykHuToFVgKfSrDvdlUJejpOIMxcECA={'all':'true'}
   ykHuToFVgKfSrDvdlUJejpOIMxcENn=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeurl(ykHuToFVgKfSrDvdlUJejpOIMxcENL.API_DOMAIN,ykHuToFVgKfSrDvdlUJejpOIMxcECL)
   ykHuToFVgKfSrDvdlUJejpOIMxcENX=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeDefaultCookies()
   ykHuToFVgKfSrDvdlUJejpOIMxcENb=ykHuToFVgKfSrDvdlUJejpOIMxcENL.callRequestCookies('Get',ykHuToFVgKfSrDvdlUJejpOIMxcENn,payload=ykHuToFVgKfSrDvdlUJejpOIMxcELC,params=ykHuToFVgKfSrDvdlUJejpOIMxcECA,headers=ykHuToFVgKfSrDvdlUJejpOIMxcELC,cookies=ykHuToFVgKfSrDvdlUJejpOIMxcENX)
   ykHuToFVgKfSrDvdlUJejpOIMxcECa=json.loads(ykHuToFVgKfSrDvdlUJejpOIMxcENb.text)
   if not('tv_episode_codes' in ykHuToFVgKfSrDvdlUJejpOIMxcECa):return ykHuToFVgKfSrDvdlUJejpOIMxcECY,ykHuToFVgKfSrDvdlUJejpOIMxcECn
   ykHuToFVgKfSrDvdlUJejpOIMxcECR=ykHuToFVgKfSrDvdlUJejpOIMxcECa['tv_episode_codes']
   ykHuToFVgKfSrDvdlUJejpOIMxcEYN=ykHuToFVgKfSrDvdlUJejpOIMxcELW(ykHuToFVgKfSrDvdlUJejpOIMxcECR)
   ykHuToFVgKfSrDvdlUJejpOIMxcEYC =ykHuToFVgKfSrDvdlUJejpOIMxcELs(ykHuToFVgKfSrDvdlUJejpOIMxcEYN//(ykHuToFVgKfSrDvdlUJejpOIMxcENL.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    ykHuToFVgKfSrDvdlUJejpOIMxcEYL =(ykHuToFVgKfSrDvdlUJejpOIMxcEYN-1)-((page_int-1)*ykHuToFVgKfSrDvdlUJejpOIMxcENL.EPISODE_LIMIT)
   else:
    ykHuToFVgKfSrDvdlUJejpOIMxcEYL =(page_int-1)*ykHuToFVgKfSrDvdlUJejpOIMxcENL.EPISODE_LIMIT
   for i in ykHuToFVgKfSrDvdlUJejpOIMxcELt(ykHuToFVgKfSrDvdlUJejpOIMxcENL.EPISODE_LIMIT):
    if orderby=='desc':
     ykHuToFVgKfSrDvdlUJejpOIMxcEYa=ykHuToFVgKfSrDvdlUJejpOIMxcEYL-i
     if ykHuToFVgKfSrDvdlUJejpOIMxcEYa<0:break
    else:
     ykHuToFVgKfSrDvdlUJejpOIMxcEYa=ykHuToFVgKfSrDvdlUJejpOIMxcEYL+i
     if ykHuToFVgKfSrDvdlUJejpOIMxcEYa>=ykHuToFVgKfSrDvdlUJejpOIMxcEYN:break
    if ykHuToFVgKfSrDvdlUJejpOIMxcECm!='':ykHuToFVgKfSrDvdlUJejpOIMxcECm+=','
    ykHuToFVgKfSrDvdlUJejpOIMxcECm+=ykHuToFVgKfSrDvdlUJejpOIMxcECR[ykHuToFVgKfSrDvdlUJejpOIMxcEYa]
   if ykHuToFVgKfSrDvdlUJejpOIMxcEYC>page_int:ykHuToFVgKfSrDvdlUJejpOIMxcECn=ykHuToFVgKfSrDvdlUJejpOIMxcELa
  except ykHuToFVgKfSrDvdlUJejpOIMxcELR as exception:
   ykHuToFVgKfSrDvdlUJejpOIMxcELG(exception)
  try:
   ykHuToFVgKfSrDvdlUJejpOIMxcECA={'codes':ykHuToFVgKfSrDvdlUJejpOIMxcECm}
   ykHuToFVgKfSrDvdlUJejpOIMxcENn=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeurl(ykHuToFVgKfSrDvdlUJejpOIMxcENL.API_DOMAIN,ykHuToFVgKfSrDvdlUJejpOIMxcECL)
   ykHuToFVgKfSrDvdlUJejpOIMxcENX=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeDefaultCookies()
   ykHuToFVgKfSrDvdlUJejpOIMxcENb=ykHuToFVgKfSrDvdlUJejpOIMxcENL.callRequestCookies('Get',ykHuToFVgKfSrDvdlUJejpOIMxcENn,payload=ykHuToFVgKfSrDvdlUJejpOIMxcELC,params=ykHuToFVgKfSrDvdlUJejpOIMxcECA,headers=ykHuToFVgKfSrDvdlUJejpOIMxcELC,cookies=ykHuToFVgKfSrDvdlUJejpOIMxcENX)
   ykHuToFVgKfSrDvdlUJejpOIMxcECa=json.loads(ykHuToFVgKfSrDvdlUJejpOIMxcENb.text)
   if not('tv_episodes' in ykHuToFVgKfSrDvdlUJejpOIMxcECa):return ykHuToFVgKfSrDvdlUJejpOIMxcECY
   ykHuToFVgKfSrDvdlUJejpOIMxcECR=ykHuToFVgKfSrDvdlUJejpOIMxcECa['tv_episodes']
   for ykHuToFVgKfSrDvdlUJejpOIMxcECG in ykHuToFVgKfSrDvdlUJejpOIMxcECR:
    ykHuToFVgKfSrDvdlUJejpOIMxcECh =ykHuToFVgKfSrDvdlUJejpOIMxcECG['code']
    if ykHuToFVgKfSrDvdlUJejpOIMxcECG['title']:
     ykHuToFVgKfSrDvdlUJejpOIMxcECz =ykHuToFVgKfSrDvdlUJejpOIMxcECG['title']
    else:
     ykHuToFVgKfSrDvdlUJejpOIMxcECz =''
    ykHuToFVgKfSrDvdlUJejpOIMxcECi =ykHuToFVgKfSrDvdlUJejpOIMxcECG['stillcut']['medium']
    ykHuToFVgKfSrDvdlUJejpOIMxcEYR =ykHuToFVgKfSrDvdlUJejpOIMxcECG['display_number']
    ykHuToFVgKfSrDvdlUJejpOIMxcEYG=ykHuToFVgKfSrDvdlUJejpOIMxcECG['tv_season_title']
    ykHuToFVgKfSrDvdlUJejpOIMxcECB={}
    ykHuToFVgKfSrDvdlUJejpOIMxcECB['mediatype'] ='episode'
    ykHuToFVgKfSrDvdlUJejpOIMxcECB['tvshowtitle']=ykHuToFVgKfSrDvdlUJejpOIMxcECz if ykHuToFVgKfSrDvdlUJejpOIMxcECz else ykHuToFVgKfSrDvdlUJejpOIMxcEYG
    ykHuToFVgKfSrDvdlUJejpOIMxcECB['title'] ='%s %s'%(ykHuToFVgKfSrDvdlUJejpOIMxcEYG,ykHuToFVgKfSrDvdlUJejpOIMxcEYR)if ykHuToFVgKfSrDvdlUJejpOIMxcECz else ykHuToFVgKfSrDvdlUJejpOIMxcEYR
    ykHuToFVgKfSrDvdlUJejpOIMxcECB['duration'] =ykHuToFVgKfSrDvdlUJejpOIMxcECG['duration']
    try:
     ykHuToFVgKfSrDvdlUJejpOIMxcECB['episode']=ykHuToFVgKfSrDvdlUJejpOIMxcECG['episode_number']
    except:
     ykHuToFVgKfSrDvdlUJejpOIMxcELC
    ykHuToFVgKfSrDvdlUJejpOIMxcECt={'code':ykHuToFVgKfSrDvdlUJejpOIMxcECh,'title':ykHuToFVgKfSrDvdlUJejpOIMxcECz,'thumbnail':ykHuToFVgKfSrDvdlUJejpOIMxcECi,'display_num':ykHuToFVgKfSrDvdlUJejpOIMxcEYR,'season_title':ykHuToFVgKfSrDvdlUJejpOIMxcEYG,'info':ykHuToFVgKfSrDvdlUJejpOIMxcECB}
    ykHuToFVgKfSrDvdlUJejpOIMxcECY.append(ykHuToFVgKfSrDvdlUJejpOIMxcECt)
  except ykHuToFVgKfSrDvdlUJejpOIMxcELR as exception:
   ykHuToFVgKfSrDvdlUJejpOIMxcELG(exception)
  return ykHuToFVgKfSrDvdlUJejpOIMxcECY,ykHuToFVgKfSrDvdlUJejpOIMxcECn
 def GetSearchList(ykHuToFVgKfSrDvdlUJejpOIMxcENL,search_key,page_int):
  ykHuToFVgKfSrDvdlUJejpOIMxcEYQ=[]
  ykHuToFVgKfSrDvdlUJejpOIMxcECn=ykHuToFVgKfSrDvdlUJejpOIMxcELY
  try:
   ykHuToFVgKfSrDvdlUJejpOIMxcECL ='/api/search.json'
   ykHuToFVgKfSrDvdlUJejpOIMxcECA={'query':search_key,'page':ykHuToFVgKfSrDvdlUJejpOIMxcELQ(page_int),'per':ykHuToFVgKfSrDvdlUJejpOIMxcELQ(ykHuToFVgKfSrDvdlUJejpOIMxcENL.SEARCH_LIMIT),'exclude':'limited'}
   ykHuToFVgKfSrDvdlUJejpOIMxcENn=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeurl(ykHuToFVgKfSrDvdlUJejpOIMxcENL.API_DOMAIN,ykHuToFVgKfSrDvdlUJejpOIMxcECL)
   ykHuToFVgKfSrDvdlUJejpOIMxcENX=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeDefaultCookies()
   ykHuToFVgKfSrDvdlUJejpOIMxcENb=ykHuToFVgKfSrDvdlUJejpOIMxcENL.callRequestCookies('Get',ykHuToFVgKfSrDvdlUJejpOIMxcENn,payload=ykHuToFVgKfSrDvdlUJejpOIMxcELC,params=ykHuToFVgKfSrDvdlUJejpOIMxcECA,headers=ykHuToFVgKfSrDvdlUJejpOIMxcELC,cookies=ykHuToFVgKfSrDvdlUJejpOIMxcENX)
   ykHuToFVgKfSrDvdlUJejpOIMxcECa=json.loads(ykHuToFVgKfSrDvdlUJejpOIMxcENb.text)
   if not('results' in ykHuToFVgKfSrDvdlUJejpOIMxcECa):return ykHuToFVgKfSrDvdlUJejpOIMxcEYQ,ykHuToFVgKfSrDvdlUJejpOIMxcECn
   ykHuToFVgKfSrDvdlUJejpOIMxcECR=ykHuToFVgKfSrDvdlUJejpOIMxcECa['results']
   ykHuToFVgKfSrDvdlUJejpOIMxcECn=ykHuToFVgKfSrDvdlUJejpOIMxcECa['meta']['has_next']
   for ykHuToFVgKfSrDvdlUJejpOIMxcECG in ykHuToFVgKfSrDvdlUJejpOIMxcECR:
    ykHuToFVgKfSrDvdlUJejpOIMxcECh =ykHuToFVgKfSrDvdlUJejpOIMxcECG['code']
    ykHuToFVgKfSrDvdlUJejpOIMxcECP=ykHuToFVgKfSrDvdlUJejpOIMxcECG['content_type']
    ykHuToFVgKfSrDvdlUJejpOIMxcECz =ykHuToFVgKfSrDvdlUJejpOIMxcECG['title']
    ykHuToFVgKfSrDvdlUJejpOIMxcECw =ykHuToFVgKfSrDvdlUJejpOIMxcECG['story']
    if ykHuToFVgKfSrDvdlUJejpOIMxcECG['thumbnail']!=ykHuToFVgKfSrDvdlUJejpOIMxcELC:
     ykHuToFVgKfSrDvdlUJejpOIMxcECi =ykHuToFVgKfSrDvdlUJejpOIMxcECG['thumbnail']['medium']
    else:
     ykHuToFVgKfSrDvdlUJejpOIMxcECi =ykHuToFVgKfSrDvdlUJejpOIMxcECG['stillcut']['medium']
    ykHuToFVgKfSrDvdlUJejpOIMxcECq =ykHuToFVgKfSrDvdlUJejpOIMxcECG['year']
    ykHuToFVgKfSrDvdlUJejpOIMxcECb =ykHuToFVgKfSrDvdlUJejpOIMxcECG['film_rating_code']
    ykHuToFVgKfSrDvdlUJejpOIMxcECX=ykHuToFVgKfSrDvdlUJejpOIMxcECG['film_rating_short']
    ykHuToFVgKfSrDvdlUJejpOIMxcECB={}
    ykHuToFVgKfSrDvdlUJejpOIMxcECB['mpaa']=ykHuToFVgKfSrDvdlUJejpOIMxcECG['film_rating_long']
    ykHuToFVgKfSrDvdlUJejpOIMxcECB['year']=ykHuToFVgKfSrDvdlUJejpOIMxcECG['year']
    ykHuToFVgKfSrDvdlUJejpOIMxcECB['title']=ykHuToFVgKfSrDvdlUJejpOIMxcECG['title']
    if ykHuToFVgKfSrDvdlUJejpOIMxcECP=='movies':
     ykHuToFVgKfSrDvdlUJejpOIMxcECB['mediatype']='movie' 
     ykHuToFVgKfSrDvdlUJejpOIMxcECB['duration']=ykHuToFVgKfSrDvdlUJejpOIMxcECG['duration']
    else:
     ykHuToFVgKfSrDvdlUJejpOIMxcECB['mediatype']='episode' 
    ykHuToFVgKfSrDvdlUJejpOIMxcECt={'code':ykHuToFVgKfSrDvdlUJejpOIMxcECh,'content_type':ykHuToFVgKfSrDvdlUJejpOIMxcECP,'title':ykHuToFVgKfSrDvdlUJejpOIMxcECz,'story':ykHuToFVgKfSrDvdlUJejpOIMxcECw,'thumbnail':ykHuToFVgKfSrDvdlUJejpOIMxcECi,'year':ykHuToFVgKfSrDvdlUJejpOIMxcECq,'film_rating_code':ykHuToFVgKfSrDvdlUJejpOIMxcECb,'film_rating_short':ykHuToFVgKfSrDvdlUJejpOIMxcECX,'info':ykHuToFVgKfSrDvdlUJejpOIMxcECB}
    ykHuToFVgKfSrDvdlUJejpOIMxcEYQ.append(ykHuToFVgKfSrDvdlUJejpOIMxcECt)
  except ykHuToFVgKfSrDvdlUJejpOIMxcELR as exception:
   ykHuToFVgKfSrDvdlUJejpOIMxcELG(exception)
  return ykHuToFVgKfSrDvdlUJejpOIMxcEYQ,ykHuToFVgKfSrDvdlUJejpOIMxcECn
 def GetProfilesList(ykHuToFVgKfSrDvdlUJejpOIMxcENL):
  ykHuToFVgKfSrDvdlUJejpOIMxcENm=[]
  try:
   ykHuToFVgKfSrDvdlUJejpOIMxcECL ='/manage_profiles'
   ykHuToFVgKfSrDvdlUJejpOIMxcENn=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeurl(ykHuToFVgKfSrDvdlUJejpOIMxcENL.API_DOMAIN,ykHuToFVgKfSrDvdlUJejpOIMxcECL)
   ykHuToFVgKfSrDvdlUJejpOIMxcENX=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeDefaultCookies()
   ykHuToFVgKfSrDvdlUJejpOIMxcENb=ykHuToFVgKfSrDvdlUJejpOIMxcENL.callRequestCookies('Get',ykHuToFVgKfSrDvdlUJejpOIMxcENn,payload=ykHuToFVgKfSrDvdlUJejpOIMxcELC,params=ykHuToFVgKfSrDvdlUJejpOIMxcELC,headers=ykHuToFVgKfSrDvdlUJejpOIMxcELC,cookies=ykHuToFVgKfSrDvdlUJejpOIMxcENX,redirects=ykHuToFVgKfSrDvdlUJejpOIMxcELa)
   ykHuToFVgKfSrDvdlUJejpOIMxcEYW=ykHuToFVgKfSrDvdlUJejpOIMxcENb.text
   ykHuToFVgKfSrDvdlUJejpOIMxcEYs =re.findall('/api/users/me.{5000}',ykHuToFVgKfSrDvdlUJejpOIMxcEYW)[0]
   ykHuToFVgKfSrDvdlUJejpOIMxcEYs =ykHuToFVgKfSrDvdlUJejpOIMxcEYs.replace('&quot;','')
   ykHuToFVgKfSrDvdlUJejpOIMxcENm=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',ykHuToFVgKfSrDvdlUJejpOIMxcEYs)
   for i in ykHuToFVgKfSrDvdlUJejpOIMxcELt(ykHuToFVgKfSrDvdlUJejpOIMxcELW(ykHuToFVgKfSrDvdlUJejpOIMxcENm)):
    ykHuToFVgKfSrDvdlUJejpOIMxcEYt=ykHuToFVgKfSrDvdlUJejpOIMxcENm[i]
    ykHuToFVgKfSrDvdlUJejpOIMxcEYt =ykHuToFVgKfSrDvdlUJejpOIMxcEYt.split(':')[1]
    ykHuToFVgKfSrDvdlUJejpOIMxcENm[i]=ykHuToFVgKfSrDvdlUJejpOIMxcEYt.split(',')[0]
  except ykHuToFVgKfSrDvdlUJejpOIMxcELR as exception:
   ykHuToFVgKfSrDvdlUJejpOIMxcELG(exception)
  return ykHuToFVgKfSrDvdlUJejpOIMxcENm
 def GetProfilesConvert(ykHuToFVgKfSrDvdlUJejpOIMxcENL,ykHuToFVgKfSrDvdlUJejpOIMxcENQ):
  ykHuToFVgKfSrDvdlUJejpOIMxcEYn=''
  ykHuToFVgKfSrDvdlUJejpOIMxcEYA=''
  try:
   ykHuToFVgKfSrDvdlUJejpOIMxcECL ='/api/users/'+ykHuToFVgKfSrDvdlUJejpOIMxcENQ+'/convert'
   ykHuToFVgKfSrDvdlUJejpOIMxcENn=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeurl(ykHuToFVgKfSrDvdlUJejpOIMxcENL.API_DOMAIN,ykHuToFVgKfSrDvdlUJejpOIMxcECL)
   ykHuToFVgKfSrDvdlUJejpOIMxcENX=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeDefaultCookies()
   ykHuToFVgKfSrDvdlUJejpOIMxcENb=ykHuToFVgKfSrDvdlUJejpOIMxcENL.callRequestCookies('Put',ykHuToFVgKfSrDvdlUJejpOIMxcENn,payload=ykHuToFVgKfSrDvdlUJejpOIMxcELC,params=ykHuToFVgKfSrDvdlUJejpOIMxcELC,headers=ykHuToFVgKfSrDvdlUJejpOIMxcELC,cookies=ykHuToFVgKfSrDvdlUJejpOIMxcENX)
   for ykHuToFVgKfSrDvdlUJejpOIMxcENX in ykHuToFVgKfSrDvdlUJejpOIMxcENb.cookies:
    if ykHuToFVgKfSrDvdlUJejpOIMxcENX.name=='_s_guitv':
     ykHuToFVgKfSrDvdlUJejpOIMxcEYh=ykHuToFVgKfSrDvdlUJejpOIMxcENX.value
    elif ykHuToFVgKfSrDvdlUJejpOIMxcENX.name=='_guinness-premium_session':
     ykHuToFVgKfSrDvdlUJejpOIMxcENB=ykHuToFVgKfSrDvdlUJejpOIMxcENX.value
   if ykHuToFVgKfSrDvdlUJejpOIMxcEYh:
    ykHuToFVgKfSrDvdlUJejpOIMxcEYn=ykHuToFVgKfSrDvdlUJejpOIMxcEYh
   if ykHuToFVgKfSrDvdlUJejpOIMxcENB:
    ykHuToFVgKfSrDvdlUJejpOIMxcEYA=ykHuToFVgKfSrDvdlUJejpOIMxcENB
  except ykHuToFVgKfSrDvdlUJejpOIMxcELR as exception:
   ykHuToFVgKfSrDvdlUJejpOIMxcEYn=''
   ykHuToFVgKfSrDvdlUJejpOIMxcEYA=''
  return ykHuToFVgKfSrDvdlUJejpOIMxcEYn,ykHuToFVgKfSrDvdlUJejpOIMxcEYA
 def Get_Now_Datetime(ykHuToFVgKfSrDvdlUJejpOIMxcENL):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(ykHuToFVgKfSrDvdlUJejpOIMxcENL,movie_code,quality_str):
  ykHuToFVgKfSrDvdlUJejpOIMxcEYz=ykHuToFVgKfSrDvdlUJejpOIMxcEYi=ykHuToFVgKfSrDvdlUJejpOIMxcEYm=''
  try:
   ykHuToFVgKfSrDvdlUJejpOIMxcECL='/api/watch/'+movie_code+'.json'
   ykHuToFVgKfSrDvdlUJejpOIMxcENn=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeurl(ykHuToFVgKfSrDvdlUJejpOIMxcENL.API_DOMAIN,ykHuToFVgKfSrDvdlUJejpOIMxcECL)
   ykHuToFVgKfSrDvdlUJejpOIMxcENq={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   ykHuToFVgKfSrDvdlUJejpOIMxcENX=ykHuToFVgKfSrDvdlUJejpOIMxcENL.makeDefaultCookies()
   ykHuToFVgKfSrDvdlUJejpOIMxcENb=ykHuToFVgKfSrDvdlUJejpOIMxcENL.callRequestCookies('Get',ykHuToFVgKfSrDvdlUJejpOIMxcENn,payload=ykHuToFVgKfSrDvdlUJejpOIMxcELC,params=ykHuToFVgKfSrDvdlUJejpOIMxcELC,headers=ykHuToFVgKfSrDvdlUJejpOIMxcENq,cookies=ykHuToFVgKfSrDvdlUJejpOIMxcENX)
   ykHuToFVgKfSrDvdlUJejpOIMxcECa=json.loads(ykHuToFVgKfSrDvdlUJejpOIMxcENb.text)
   ykHuToFVgKfSrDvdlUJejpOIMxcEYz=ykHuToFVgKfSrDvdlUJejpOIMxcECa['streams'][0]['source']
   if ykHuToFVgKfSrDvdlUJejpOIMxcEYz==ykHuToFVgKfSrDvdlUJejpOIMxcELC:return(ykHuToFVgKfSrDvdlUJejpOIMxcEYz,ykHuToFVgKfSrDvdlUJejpOIMxcEYi,ykHuToFVgKfSrDvdlUJejpOIMxcEYm)
   if 'subtitles' in ykHuToFVgKfSrDvdlUJejpOIMxcECa['streams'][0]:
    for ykHuToFVgKfSrDvdlUJejpOIMxcEYw in ykHuToFVgKfSrDvdlUJejpOIMxcECa['streams'][0]['subtitles']:
     if ykHuToFVgKfSrDvdlUJejpOIMxcEYw['lang']=='ko':
      ykHuToFVgKfSrDvdlUJejpOIMxcEYi=ykHuToFVgKfSrDvdlUJejpOIMxcEYw['url']
      break
   ykHuToFVgKfSrDvdlUJejpOIMxcEYq =ykHuToFVgKfSrDvdlUJejpOIMxcECa['ping_payload']
   ykHuToFVgKfSrDvdlUJejpOIMxcEYb =ykHuToFVgKfSrDvdlUJejpOIMxcENL.WATCHA_USERCD
   ykHuToFVgKfSrDvdlUJejpOIMxcEYX={'merchant':'giitd_frograms','sessionId':ykHuToFVgKfSrDvdlUJejpOIMxcEYq,'userId':ykHuToFVgKfSrDvdlUJejpOIMxcEYb}
   ykHuToFVgKfSrDvdlUJejpOIMxcEYB=json.dumps(ykHuToFVgKfSrDvdlUJejpOIMxcEYX,separators=(",",":")).encode('UTF-8')
   ykHuToFVgKfSrDvdlUJejpOIMxcEYm=base64.b64encode(ykHuToFVgKfSrDvdlUJejpOIMxcEYB)
  except ykHuToFVgKfSrDvdlUJejpOIMxcELR as exception:
   return(ykHuToFVgKfSrDvdlUJejpOIMxcEYz,ykHuToFVgKfSrDvdlUJejpOIMxcEYi,ykHuToFVgKfSrDvdlUJejpOIMxcEYm)
  return(ykHuToFVgKfSrDvdlUJejpOIMxcEYz,ykHuToFVgKfSrDvdlUJejpOIMxcEYi,ykHuToFVgKfSrDvdlUJejpOIMxcEYm) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
