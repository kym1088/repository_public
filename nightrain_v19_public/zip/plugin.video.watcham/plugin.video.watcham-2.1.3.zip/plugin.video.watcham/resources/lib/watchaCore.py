__author__="NightRain"
rkdwbQnpaJYhGlWXEiNjHzsFyLueIC=object
rkdwbQnpaJYhGlWXEiNjHzsFyLueIS=None
rkdwbQnpaJYhGlWXEiNjHzsFyLueIq=False
rkdwbQnpaJYhGlWXEiNjHzsFyLueIc=True
rkdwbQnpaJYhGlWXEiNjHzsFyLueIo=Exception
rkdwbQnpaJYhGlWXEiNjHzsFyLueIA=print
rkdwbQnpaJYhGlWXEiNjHzsFyLueIt=str
rkdwbQnpaJYhGlWXEiNjHzsFyLueIR=len
rkdwbQnpaJYhGlWXEiNjHzsFyLueIT=int
rkdwbQnpaJYhGlWXEiNjHzsFyLueIv=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import base64
import requests
import datetime
class rkdwbQnpaJYhGlWXEiNjHzsFyLueOM(rkdwbQnpaJYhGlWXEiNjHzsFyLueIC):
 def __init__(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_TOKEN ='' 
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUIT =''
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUITV =''
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_USERCD=''
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.MAIN_DOMAIN ='https://watcha.com'
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.API_DOMAIN ='https://api-mars.watcha.com'
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.EPISODE_LIMIT=20
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.SEARCH_LIMIT =30
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.DEFAULT_HEADER={'user-agent':rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,jobtype,rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,redirects=rkdwbQnpaJYhGlWXEiNjHzsFyLueIq):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOI=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.DEFAULT_HEADER
  if headers:rkdwbQnpaJYhGlWXEiNjHzsFyLueOI.update(headers)
  if jobtype=='Get':
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOm=requests.get(rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,params=params,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueOI,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOm=requests.put(rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,data=payload,params=params,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueOI,cookies=cookies,allow_redirects=redirects)
  else:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOm=requests.post(rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,data=payload,params=params,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueOI,cookies=cookies,allow_redirects=redirects)
  return rkdwbQnpaJYhGlWXEiNjHzsFyLueOm
 def SaveCredential(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,rkdwbQnpaJYhGlWXEiNjHzsFyLueOC):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_TOKEN =rkdwbQnpaJYhGlWXEiNjHzsFyLueOC.get('watcha_token')
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUIT =rkdwbQnpaJYhGlWXEiNjHzsFyLueOC.get('watcha_guit')
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUITV =rkdwbQnpaJYhGlWXEiNjHzsFyLueOC.get('watcha_guitv')
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_USERCD =rkdwbQnpaJYhGlWXEiNjHzsFyLueOC.get('watcha_usercd')
 def SaveCredential_usercd(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,rkdwbQnpaJYhGlWXEiNjHzsFyLueOS):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_USERCD=rkdwbQnpaJYhGlWXEiNjHzsFyLueOS
 def SaveCredential_guitv(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,rkdwbQnpaJYhGlWXEiNjHzsFyLueOq,rkdwbQnpaJYhGlWXEiNjHzsFyLueOc):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUITV=rkdwbQnpaJYhGlWXEiNjHzsFyLueOq
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_TOKEN=rkdwbQnpaJYhGlWXEiNjHzsFyLueOc 
 def ClearCredential(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_TOKEN ='' 
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUIT =''
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUITV =''
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_USERCD=''
 def LoadCredential(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOC={'watcha_token':rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_TOKEN,'watcha_guit':rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUIT,'watcha_guitv':rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUITV,'watcha_usercd':rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_USERCD}
  return rkdwbQnpaJYhGlWXEiNjHzsFyLueOC
 def makeDefaultCookies(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOo={'_s_guit':rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUIT,'_guinness-premium_session':rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_TOKEN}
  if rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUITV:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOo['_s_guitv']=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_GUITV
  return rkdwbQnpaJYhGlWXEiNjHzsFyLueOo
 def GetCredential(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,user_id,user_pw,user_pf):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOA=rkdwbQnpaJYhGlWXEiNjHzsFyLueIq
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOt=rkdwbQnpaJYhGlWXEiNjHzsFyLueOf='-'
  try:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOR=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.API_DOMAIN+'/api/session'
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOT={'email':user_id,'password':user_pw}
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOv={'accept':'application/vnd.frograms+json;version=4'}
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOU=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.callRequestCookies('Post',rkdwbQnpaJYhGlWXEiNjHzsFyLueOR,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueOT,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueOv,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS)
   for rkdwbQnpaJYhGlWXEiNjHzsFyLueOV in rkdwbQnpaJYhGlWXEiNjHzsFyLueOU.cookies:
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueOV.name=='_guinness-premium_session':
     rkdwbQnpaJYhGlWXEiNjHzsFyLueOf=rkdwbQnpaJYhGlWXEiNjHzsFyLueOV.value
    elif rkdwbQnpaJYhGlWXEiNjHzsFyLueOV.name=='_s_guit':
     rkdwbQnpaJYhGlWXEiNjHzsFyLueOt=rkdwbQnpaJYhGlWXEiNjHzsFyLueOV.value
   if rkdwbQnpaJYhGlWXEiNjHzsFyLueOf:rkdwbQnpaJYhGlWXEiNjHzsFyLueOA=rkdwbQnpaJYhGlWXEiNjHzsFyLueIc
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIA(exception)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOt=rkdwbQnpaJYhGlWXEiNjHzsFyLueOf='' 
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOC={'watcha_guit':rkdwbQnpaJYhGlWXEiNjHzsFyLueOt,'watcha_token':rkdwbQnpaJYhGlWXEiNjHzsFyLueOf,'watcha_guitv':'','watcha_usercd':''}
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.SaveCredential(rkdwbQnpaJYhGlWXEiNjHzsFyLueOC)
  try:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOK=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.GetProfilesList()
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOD =rkdwbQnpaJYhGlWXEiNjHzsFyLueOK[user_pf]
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.SaveCredential_usercd(rkdwbQnpaJYhGlWXEiNjHzsFyLueOD)
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIA(exception)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.ClearCredential()
   return rkdwbQnpaJYhGlWXEiNjHzsFyLueIq
  if user_pf!=0:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOq,rkdwbQnpaJYhGlWXEiNjHzsFyLueOc=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.GetProfilesConvert(rkdwbQnpaJYhGlWXEiNjHzsFyLueOD)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.SaveCredential_guitv(rkdwbQnpaJYhGlWXEiNjHzsFyLueOq,rkdwbQnpaJYhGlWXEiNjHzsFyLueOc)
  return rkdwbQnpaJYhGlWXEiNjHzsFyLueOA
 def GetSubGroupList(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,stype):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOg=[]
  try:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOx ='/api/categories.json'
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOB=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.API_DOMAIN+rkdwbQnpaJYhGlWXEiNjHzsFyLueOx
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOU=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.callRequestCookies('Get',rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMO=json.loads(rkdwbQnpaJYhGlWXEiNjHzsFyLueOU.text)
   if not('genres' in rkdwbQnpaJYhGlWXEiNjHzsFyLueMO):return rkdwbQnpaJYhGlWXEiNjHzsFyLueOg
   if stype=='genres':
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMP=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['genres']
   else:
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMP=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['tags']
   for rkdwbQnpaJYhGlWXEiNjHzsFyLueMI in rkdwbQnpaJYhGlWXEiNjHzsFyLueMP:
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMm=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['name']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMC =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['api_path']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMS =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['entity']['id']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMq={'group_name':rkdwbQnpaJYhGlWXEiNjHzsFyLueMm,'api_path':rkdwbQnpaJYhGlWXEiNjHzsFyLueMC,'tag_id':rkdwbQnpaJYhGlWXEiNjHzsFyLueIt(rkdwbQnpaJYhGlWXEiNjHzsFyLueMS)}
    rkdwbQnpaJYhGlWXEiNjHzsFyLueOg.append(rkdwbQnpaJYhGlWXEiNjHzsFyLueMq)
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIA(exception)
  return rkdwbQnpaJYhGlWXEiNjHzsFyLueOg
 def GetCategoryList(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,stype,rkdwbQnpaJYhGlWXEiNjHzsFyLueMS,rkdwbQnpaJYhGlWXEiNjHzsFyLueMC,page_int,in_sort):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOg=[]
  rkdwbQnpaJYhGlWXEiNjHzsFyLueMc=rkdwbQnpaJYhGlWXEiNjHzsFyLueIq
  rkdwbQnpaJYhGlWXEiNjHzsFyLueMo={}
  try:
   if 'categories' in rkdwbQnpaJYhGlWXEiNjHzsFyLueMC:
    rkdwbQnpaJYhGlWXEiNjHzsFyLueOx ='/api/categories/contents.json'
    if stype=='genres':
     rkdwbQnpaJYhGlWXEiNjHzsFyLueMo['genre']=rkdwbQnpaJYhGlWXEiNjHzsFyLueMS
    else:
     rkdwbQnpaJYhGlWXEiNjHzsFyLueMo['tag'] =rkdwbQnpaJYhGlWXEiNjHzsFyLueMS
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMo['order']=in_sort 
    if page_int>1:
     rkdwbQnpaJYhGlWXEiNjHzsFyLueMo['page']=rkdwbQnpaJYhGlWXEiNjHzsFyLueIt(page_int-1)
   else: 
    rkdwbQnpaJYhGlWXEiNjHzsFyLueOx ='/api/'+rkdwbQnpaJYhGlWXEiNjHzsFyLueMC+'.json'
    if page_int>1:
     rkdwbQnpaJYhGlWXEiNjHzsFyLueMo['page']=rkdwbQnpaJYhGlWXEiNjHzsFyLueIt(page_int)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOB=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.API_DOMAIN+rkdwbQnpaJYhGlWXEiNjHzsFyLueOx
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOV=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.makeDefaultCookies()
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOU=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.callRequestCookies('Get',rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueMo,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueOV)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMO=json.loads(rkdwbQnpaJYhGlWXEiNjHzsFyLueOU.text)
   if not('contents' in rkdwbQnpaJYhGlWXEiNjHzsFyLueMO):return rkdwbQnpaJYhGlWXEiNjHzsFyLueOg,rkdwbQnpaJYhGlWXEiNjHzsFyLueMc
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMP=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['contents']
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMc=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['meta']['has_next']
   for rkdwbQnpaJYhGlWXEiNjHzsFyLueMI in rkdwbQnpaJYhGlWXEiNjHzsFyLueMP:
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMA =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['code']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMt=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['content_type']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMR =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['title']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMT =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['story']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMv=tmp_thumb=tmp_fanart=''
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('poster') !=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS:rkdwbQnpaJYhGlWXEiNjHzsFyLueMv=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('poster').get('original')
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('stillcut')!=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS:tmp_thumb =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('stillcut').get('large')
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('thumbnail')!=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS:tmp_fanart=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('thumbnail').get('large')
    if tmp_fanart=='' :tmp_fanart=tmp_thumb
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMU={'thumb':tmp_thumb,'poster':rkdwbQnpaJYhGlWXEiNjHzsFyLueMv,'fanart':tmp_fanart}
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMV =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['year']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMf =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['film_rating_code']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMK=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['film_rating_short']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMD =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['film_rating_long']
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueMt=='movies':
     rkdwbQnpaJYhGlWXEiNjHzsFyLueMg =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['duration']
    else:
     rkdwbQnpaJYhGlWXEiNjHzsFyLueMg ='0'
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMq={'code':rkdwbQnpaJYhGlWXEiNjHzsFyLueMA,'content_type':rkdwbQnpaJYhGlWXEiNjHzsFyLueMt,'title':rkdwbQnpaJYhGlWXEiNjHzsFyLueMR,'story':rkdwbQnpaJYhGlWXEiNjHzsFyLueMT,'thumbnail':rkdwbQnpaJYhGlWXEiNjHzsFyLueMU,'year':rkdwbQnpaJYhGlWXEiNjHzsFyLueMV,'film_rating_code':rkdwbQnpaJYhGlWXEiNjHzsFyLueMf,'film_rating_short':rkdwbQnpaJYhGlWXEiNjHzsFyLueMK,'film_rating_long':rkdwbQnpaJYhGlWXEiNjHzsFyLueMD,'duration':rkdwbQnpaJYhGlWXEiNjHzsFyLueMg}
    rkdwbQnpaJYhGlWXEiNjHzsFyLueOg.append(rkdwbQnpaJYhGlWXEiNjHzsFyLueMq)
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIA(exception)
  return rkdwbQnpaJYhGlWXEiNjHzsFyLueOg,rkdwbQnpaJYhGlWXEiNjHzsFyLueMc
 def GetCategoryList_morepage(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,stype,rkdwbQnpaJYhGlWXEiNjHzsFyLueMS,rkdwbQnpaJYhGlWXEiNjHzsFyLueMC,page_int,in_sort):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueMc=rkdwbQnpaJYhGlWXEiNjHzsFyLueIq
  if not('categories' in rkdwbQnpaJYhGlWXEiNjHzsFyLueMC):return rkdwbQnpaJYhGlWXEiNjHzsFyLueIc
  try:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOx ='/api/categories/contents.json'
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOB=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.API_DOMAIN+rkdwbQnpaJYhGlWXEiNjHzsFyLueOx
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMo={}
   if stype=='genres':
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMo['genre']=rkdwbQnpaJYhGlWXEiNjHzsFyLueMS
   else:
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMo['tag'] =rkdwbQnpaJYhGlWXEiNjHzsFyLueMS
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMo['order']=in_sort 
   if page_int>1:
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMo['page']=rkdwbQnpaJYhGlWXEiNjHzsFyLueIt(page_int-1)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOU=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.callRequestCookies('Get',rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueMo,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMO=json.loads(rkdwbQnpaJYhGlWXEiNjHzsFyLueOU.text)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMc=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['meta']['has_next']
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIA(exception)
  return rkdwbQnpaJYhGlWXEiNjHzsFyLueMc
 def GetProgramInfo(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,program_code):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueMx={}
  try:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOx ='/api/contents/'+program_code
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOB=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.API_DOMAIN+rkdwbQnpaJYhGlWXEiNjHzsFyLueOx
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOU=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.callRequestCookies('Get',rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMO=json.loads(rkdwbQnpaJYhGlWXEiNjHzsFyLueOU.text)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMB=img_clearlogo=''
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMB=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO.get('poster').get('original')
   if rkdwbQnpaJYhGlWXEiNjHzsFyLueIR(rkdwbQnpaJYhGlWXEiNjHzsFyLueMO.get('title_logos'))>0:img_clearlogo=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO.get('title_logos')[0].get('src')
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMx={'imgPoster':rkdwbQnpaJYhGlWXEiNjHzsFyLueMB,'imgClearlogo':img_clearlogo}
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIA(exception)
  return rkdwbQnpaJYhGlWXEiNjHzsFyLueMx
 def GetEpisodoList(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,program_code,page_int,orderby='asc'):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOg=[]
  rkdwbQnpaJYhGlWXEiNjHzsFyLueMc=rkdwbQnpaJYhGlWXEiNjHzsFyLueIq
  rkdwbQnpaJYhGlWXEiNjHzsFyLuePO=''
  try:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOx ='/api/contents/'+program_code+'/tv_episodes.json'
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOB=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.API_DOMAIN+rkdwbQnpaJYhGlWXEiNjHzsFyLueOx
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMo={'all':'true'}
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOU=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.callRequestCookies('Get',rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueMo,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMO=json.loads(rkdwbQnpaJYhGlWXEiNjHzsFyLueOU.text)
   if not('tv_episode_codes' in rkdwbQnpaJYhGlWXEiNjHzsFyLueMO):return rkdwbQnpaJYhGlWXEiNjHzsFyLueOg,rkdwbQnpaJYhGlWXEiNjHzsFyLueMc
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMP=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['tv_episode_codes']
   rkdwbQnpaJYhGlWXEiNjHzsFyLuePM=rkdwbQnpaJYhGlWXEiNjHzsFyLueIR(rkdwbQnpaJYhGlWXEiNjHzsFyLueMP)
   rkdwbQnpaJYhGlWXEiNjHzsFyLuePI =rkdwbQnpaJYhGlWXEiNjHzsFyLueIT(rkdwbQnpaJYhGlWXEiNjHzsFyLuePM//(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    rkdwbQnpaJYhGlWXEiNjHzsFyLuePm =(rkdwbQnpaJYhGlWXEiNjHzsFyLuePM-1)-((page_int-1)*rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.EPISODE_LIMIT)
   else:
    rkdwbQnpaJYhGlWXEiNjHzsFyLuePm =(page_int-1)*rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.EPISODE_LIMIT
   for i in rkdwbQnpaJYhGlWXEiNjHzsFyLueIv(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.EPISODE_LIMIT):
    if orderby=='desc':
     rkdwbQnpaJYhGlWXEiNjHzsFyLuePC=rkdwbQnpaJYhGlWXEiNjHzsFyLuePm-i
     if rkdwbQnpaJYhGlWXEiNjHzsFyLuePC<0:break
    else:
     rkdwbQnpaJYhGlWXEiNjHzsFyLuePC=rkdwbQnpaJYhGlWXEiNjHzsFyLuePm+i
     if rkdwbQnpaJYhGlWXEiNjHzsFyLuePC>=rkdwbQnpaJYhGlWXEiNjHzsFyLuePM:break
    if rkdwbQnpaJYhGlWXEiNjHzsFyLuePO!='':rkdwbQnpaJYhGlWXEiNjHzsFyLuePO+=','
    rkdwbQnpaJYhGlWXEiNjHzsFyLuePO+=rkdwbQnpaJYhGlWXEiNjHzsFyLueMP[rkdwbQnpaJYhGlWXEiNjHzsFyLuePC]
   if rkdwbQnpaJYhGlWXEiNjHzsFyLuePI>page_int:rkdwbQnpaJYhGlWXEiNjHzsFyLueMc=rkdwbQnpaJYhGlWXEiNjHzsFyLueIc
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIA(exception)
  rkdwbQnpaJYhGlWXEiNjHzsFyLuePS=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.GetProgramInfo(program_code)
  try:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOB=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.API_DOMAIN+rkdwbQnpaJYhGlWXEiNjHzsFyLueOx
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMo={'codes':rkdwbQnpaJYhGlWXEiNjHzsFyLuePO}
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOU=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.callRequestCookies('Get',rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueMo,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMO=json.loads(rkdwbQnpaJYhGlWXEiNjHzsFyLueOU.text)
   if not('tv_episodes' in rkdwbQnpaJYhGlWXEiNjHzsFyLueMO):return rkdwbQnpaJYhGlWXEiNjHzsFyLueOg
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMP=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['tv_episodes']
   for rkdwbQnpaJYhGlWXEiNjHzsFyLueMI in rkdwbQnpaJYhGlWXEiNjHzsFyLueMP:
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMA =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['code']
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['title']:
     rkdwbQnpaJYhGlWXEiNjHzsFyLueMR =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['title']
    else:
     rkdwbQnpaJYhGlWXEiNjHzsFyLueMR =''
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMv=tmp_thumb=tmp_fanart=rkdwbQnpaJYhGlWXEiNjHzsFyLuePq=''
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMv =rkdwbQnpaJYhGlWXEiNjHzsFyLuePS.get('imgPoster')
    rkdwbQnpaJYhGlWXEiNjHzsFyLuePq=rkdwbQnpaJYhGlWXEiNjHzsFyLuePS.get('imgClearlogo')
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('stillcut') !=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS:tmp_thumb =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('stillcut').get('large')
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('tv_season_stillcut')!=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS:tmp_fanart=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('tv_season_stillcut').get('large')
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMU={'thumb':tmp_thumb,'poster':rkdwbQnpaJYhGlWXEiNjHzsFyLueMv,'fanart':tmp_fanart,'clearlogo':rkdwbQnpaJYhGlWXEiNjHzsFyLuePq}
    rkdwbQnpaJYhGlWXEiNjHzsFyLuePc =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['display_number']
    rkdwbQnpaJYhGlWXEiNjHzsFyLuePo=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['tv_season_title']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMg =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['duration']
    try:
     rkdwbQnpaJYhGlWXEiNjHzsFyLuePA=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['episode_number']
    except:
     rkdwbQnpaJYhGlWXEiNjHzsFyLuePA='0'
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMq={'code':rkdwbQnpaJYhGlWXEiNjHzsFyLueMA,'title':rkdwbQnpaJYhGlWXEiNjHzsFyLueMR,'thumbnail':rkdwbQnpaJYhGlWXEiNjHzsFyLueMU,'display_num':rkdwbQnpaJYhGlWXEiNjHzsFyLuePc,'season_title':rkdwbQnpaJYhGlWXEiNjHzsFyLuePo,'duration':rkdwbQnpaJYhGlWXEiNjHzsFyLueMg,'episode_number':rkdwbQnpaJYhGlWXEiNjHzsFyLuePA}
    rkdwbQnpaJYhGlWXEiNjHzsFyLueOg.append(rkdwbQnpaJYhGlWXEiNjHzsFyLueMq)
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIA(exception)
  return rkdwbQnpaJYhGlWXEiNjHzsFyLueOg,rkdwbQnpaJYhGlWXEiNjHzsFyLueMc
 def GetSearchList(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,search_key,page_int):
  rkdwbQnpaJYhGlWXEiNjHzsFyLuePt=[]
  rkdwbQnpaJYhGlWXEiNjHzsFyLueMc=rkdwbQnpaJYhGlWXEiNjHzsFyLueIq
  try:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOx ='/api/search.json'
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOB=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.API_DOMAIN+rkdwbQnpaJYhGlWXEiNjHzsFyLueOx
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMo={'query':search_key,'page':rkdwbQnpaJYhGlWXEiNjHzsFyLueIt(page_int),'per':rkdwbQnpaJYhGlWXEiNjHzsFyLueIt(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.SEARCH_LIMIT),'exclude':'limited'}
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOU=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.callRequestCookies('Get',rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueMo,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMO=json.loads(rkdwbQnpaJYhGlWXEiNjHzsFyLueOU.text)
   if not('results' in rkdwbQnpaJYhGlWXEiNjHzsFyLueMO):return rkdwbQnpaJYhGlWXEiNjHzsFyLuePt,rkdwbQnpaJYhGlWXEiNjHzsFyLueMc
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMP=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['results']
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMc=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['meta']['has_next']
   for rkdwbQnpaJYhGlWXEiNjHzsFyLueMI in rkdwbQnpaJYhGlWXEiNjHzsFyLueMP:
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMA =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['code']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMt=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['content_type']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMR =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['title']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMT =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['story']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMv=tmp_thumb=tmp_fanart=''
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('poster') !=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS:rkdwbQnpaJYhGlWXEiNjHzsFyLueMv=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('poster').get('original')
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('stillcut')!=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS:tmp_thumb =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('stillcut').get('large')
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('thumbnail')!=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS:tmp_fanart=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI.get('thumbnail').get('large')
    if tmp_fanart=='' :tmp_fanart=tmp_thumb
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMU={'thumb':tmp_thumb,'poster':rkdwbQnpaJYhGlWXEiNjHzsFyLueMv,'fanart':tmp_fanart}
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMV =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['year']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMf =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['film_rating_code']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMK=rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['film_rating_short']
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMD =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['film_rating_long']
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueMt=='movies':
     rkdwbQnpaJYhGlWXEiNjHzsFyLueMg =rkdwbQnpaJYhGlWXEiNjHzsFyLueMI['duration']
    else:
     rkdwbQnpaJYhGlWXEiNjHzsFyLueMg ='0'
    rkdwbQnpaJYhGlWXEiNjHzsFyLueMq={'code':rkdwbQnpaJYhGlWXEiNjHzsFyLueMA,'content_type':rkdwbQnpaJYhGlWXEiNjHzsFyLueMt,'title':rkdwbQnpaJYhGlWXEiNjHzsFyLueMR,'story':rkdwbQnpaJYhGlWXEiNjHzsFyLueMT,'thumbnail':rkdwbQnpaJYhGlWXEiNjHzsFyLueMU,'year':rkdwbQnpaJYhGlWXEiNjHzsFyLueMV,'film_rating_code':rkdwbQnpaJYhGlWXEiNjHzsFyLueMf,'film_rating_short':rkdwbQnpaJYhGlWXEiNjHzsFyLueMK,'film_rating_long':rkdwbQnpaJYhGlWXEiNjHzsFyLueMD,'duration':rkdwbQnpaJYhGlWXEiNjHzsFyLueMg}
    rkdwbQnpaJYhGlWXEiNjHzsFyLuePt.append(rkdwbQnpaJYhGlWXEiNjHzsFyLueMq)
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIA(exception)
  return rkdwbQnpaJYhGlWXEiNjHzsFyLuePt,rkdwbQnpaJYhGlWXEiNjHzsFyLueMc
 def GetProfilesList(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP):
  rkdwbQnpaJYhGlWXEiNjHzsFyLueOK=[]
  try:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOx ='/manage_profiles'
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOB=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.MAIN_DOMAIN+rkdwbQnpaJYhGlWXEiNjHzsFyLueOx
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOV=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.makeDefaultCookies()
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOU=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.callRequestCookies('Get',rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueOV,redirects=rkdwbQnpaJYhGlWXEiNjHzsFyLueIc)
   rkdwbQnpaJYhGlWXEiNjHzsFyLuePR=rkdwbQnpaJYhGlWXEiNjHzsFyLueOU.text
   rkdwbQnpaJYhGlWXEiNjHzsFyLuePT =re.findall('/api/users/me.{5000}',rkdwbQnpaJYhGlWXEiNjHzsFyLuePR)[0]
   rkdwbQnpaJYhGlWXEiNjHzsFyLuePT =rkdwbQnpaJYhGlWXEiNjHzsFyLuePT.replace('&quot;','')
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOK=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',rkdwbQnpaJYhGlWXEiNjHzsFyLuePT)
   for i in rkdwbQnpaJYhGlWXEiNjHzsFyLueIv(rkdwbQnpaJYhGlWXEiNjHzsFyLueIR(rkdwbQnpaJYhGlWXEiNjHzsFyLueOK)):
    rkdwbQnpaJYhGlWXEiNjHzsFyLuePv=rkdwbQnpaJYhGlWXEiNjHzsFyLueOK[i]
    rkdwbQnpaJYhGlWXEiNjHzsFyLuePv =rkdwbQnpaJYhGlWXEiNjHzsFyLuePv.split(':')[1]
    rkdwbQnpaJYhGlWXEiNjHzsFyLueOK[i]=rkdwbQnpaJYhGlWXEiNjHzsFyLuePv.split(',')[0]
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIA(exception)
  return rkdwbQnpaJYhGlWXEiNjHzsFyLueOK
 def GetProfilesConvert(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,rkdwbQnpaJYhGlWXEiNjHzsFyLueOS):
  rkdwbQnpaJYhGlWXEiNjHzsFyLuePU=''
  rkdwbQnpaJYhGlWXEiNjHzsFyLuePV=''
  try:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOx ='/api/users/'+rkdwbQnpaJYhGlWXEiNjHzsFyLueOS+'/convert'
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOB=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.API_DOMAIN+rkdwbQnpaJYhGlWXEiNjHzsFyLueOx
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOV=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.makeDefaultCookies()
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOU=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.callRequestCookies('Put',rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueOV)
   for rkdwbQnpaJYhGlWXEiNjHzsFyLueOV in rkdwbQnpaJYhGlWXEiNjHzsFyLueOU.cookies:
    if rkdwbQnpaJYhGlWXEiNjHzsFyLueOV.name=='_s_guitv':
     rkdwbQnpaJYhGlWXEiNjHzsFyLuePf=rkdwbQnpaJYhGlWXEiNjHzsFyLueOV.value
    elif rkdwbQnpaJYhGlWXEiNjHzsFyLueOV.name=='_guinness-premium_session':
     rkdwbQnpaJYhGlWXEiNjHzsFyLueOf=rkdwbQnpaJYhGlWXEiNjHzsFyLueOV.value
   if rkdwbQnpaJYhGlWXEiNjHzsFyLuePf:
    rkdwbQnpaJYhGlWXEiNjHzsFyLuePU=rkdwbQnpaJYhGlWXEiNjHzsFyLuePf
   if rkdwbQnpaJYhGlWXEiNjHzsFyLueOf:
    rkdwbQnpaJYhGlWXEiNjHzsFyLuePV=rkdwbQnpaJYhGlWXEiNjHzsFyLueOf
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   rkdwbQnpaJYhGlWXEiNjHzsFyLuePU=''
   rkdwbQnpaJYhGlWXEiNjHzsFyLuePV=''
  return rkdwbQnpaJYhGlWXEiNjHzsFyLuePU,rkdwbQnpaJYhGlWXEiNjHzsFyLuePV
 def Get_Now_Datetime(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(rkdwbQnpaJYhGlWXEiNjHzsFyLueOP,movie_code,quality_str):
  rkdwbQnpaJYhGlWXEiNjHzsFyLuePD=rkdwbQnpaJYhGlWXEiNjHzsFyLuePx=rkdwbQnpaJYhGlWXEiNjHzsFyLueIm=''
  try:
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOx='/api/watch/'+movie_code+'.json'
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOB=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.API_DOMAIN+rkdwbQnpaJYhGlWXEiNjHzsFyLueOx
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOv={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOV=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.makeDefaultCookies()
   rkdwbQnpaJYhGlWXEiNjHzsFyLueOU=rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.callRequestCookies('Get',rkdwbQnpaJYhGlWXEiNjHzsFyLueOB,payload=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,params=rkdwbQnpaJYhGlWXEiNjHzsFyLueIS,headers=rkdwbQnpaJYhGlWXEiNjHzsFyLueOv,cookies=rkdwbQnpaJYhGlWXEiNjHzsFyLueOV)
   rkdwbQnpaJYhGlWXEiNjHzsFyLueMO=json.loads(rkdwbQnpaJYhGlWXEiNjHzsFyLueOU.text)
   rkdwbQnpaJYhGlWXEiNjHzsFyLuePD=rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['streams'][0]['source']
   if rkdwbQnpaJYhGlWXEiNjHzsFyLuePD==rkdwbQnpaJYhGlWXEiNjHzsFyLueIS:return(rkdwbQnpaJYhGlWXEiNjHzsFyLuePD,rkdwbQnpaJYhGlWXEiNjHzsFyLuePx,rkdwbQnpaJYhGlWXEiNjHzsFyLueIm)
   if 'subtitles' in rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['streams'][0]:
    for rkdwbQnpaJYhGlWXEiNjHzsFyLuePg in rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['streams'][0]['subtitles']:
     if rkdwbQnpaJYhGlWXEiNjHzsFyLuePg['lang']=='ko':
      rkdwbQnpaJYhGlWXEiNjHzsFyLuePx=rkdwbQnpaJYhGlWXEiNjHzsFyLuePg['url']
      break
   rkdwbQnpaJYhGlWXEiNjHzsFyLuePB =rkdwbQnpaJYhGlWXEiNjHzsFyLueMO['ping_payload']
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIO =rkdwbQnpaJYhGlWXEiNjHzsFyLueOP.WATCHA_USERCD
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIM={'merchant':'giitd_frograms','sessionId':rkdwbQnpaJYhGlWXEiNjHzsFyLuePB,'userId':rkdwbQnpaJYhGlWXEiNjHzsFyLueIO}
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIP=json.dumps(rkdwbQnpaJYhGlWXEiNjHzsFyLueIM,separators=(",",":")).encode('UTF-8')
   rkdwbQnpaJYhGlWXEiNjHzsFyLueIm=base64.b64encode(rkdwbQnpaJYhGlWXEiNjHzsFyLueIP)
  except rkdwbQnpaJYhGlWXEiNjHzsFyLueIo as exception:
   return(rkdwbQnpaJYhGlWXEiNjHzsFyLuePD,rkdwbQnpaJYhGlWXEiNjHzsFyLuePx,rkdwbQnpaJYhGlWXEiNjHzsFyLueIm)
  return(rkdwbQnpaJYhGlWXEiNjHzsFyLuePD,rkdwbQnpaJYhGlWXEiNjHzsFyLuePx,rkdwbQnpaJYhGlWXEiNjHzsFyLueIm) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
