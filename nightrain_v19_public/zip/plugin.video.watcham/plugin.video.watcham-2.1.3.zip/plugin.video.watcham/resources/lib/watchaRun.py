__author__="NightRain"
jTCnAMFWIwVqbDBlavPyRrgtJfeQiH=object
jTCnAMFWIwVqbDBlavPyRrgtJfeQik=None
jTCnAMFWIwVqbDBlavPyRrgtJfeQiE=int
jTCnAMFWIwVqbDBlavPyRrgtJfeQiG=False
jTCnAMFWIwVqbDBlavPyRrgtJfeQiL=True
jTCnAMFWIwVqbDBlavPyRrgtJfeQiX=type
jTCnAMFWIwVqbDBlavPyRrgtJfeQiO=dict
jTCnAMFWIwVqbDBlavPyRrgtJfeQip=len
jTCnAMFWIwVqbDBlavPyRrgtJfeQid=range
jTCnAMFWIwVqbDBlavPyRrgtJfeQiY=str
jTCnAMFWIwVqbDBlavPyRrgtJfeQiU=open
jTCnAMFWIwVqbDBlavPyRrgtJfeQiu=Exception
jTCnAMFWIwVqbDBlavPyRrgtJfeQiz=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
jTCnAMFWIwVqbDBlavPyRrgtJfeQHE=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'검색 (search)','mode':'SEARCH','stype':'-','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-'}]
jTCnAMFWIwVqbDBlavPyRrgtJfeQHG=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
jTCnAMFWIwVqbDBlavPyRrgtJfeQHL=40
jTCnAMFWIwVqbDBlavPyRrgtJfeQHi =20
jTCnAMFWIwVqbDBlavPyRrgtJfeQHX =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
jTCnAMFWIwVqbDBlavPyRrgtJfeQHO=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class jTCnAMFWIwVqbDBlavPyRrgtJfeQHk(jTCnAMFWIwVqbDBlavPyRrgtJfeQiH):
 def __init__(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,jTCnAMFWIwVqbDBlavPyRrgtJfeQHd,jTCnAMFWIwVqbDBlavPyRrgtJfeQHY,jTCnAMFWIwVqbDBlavPyRrgtJfeQHU):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_url =jTCnAMFWIwVqbDBlavPyRrgtJfeQHd
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_handle=jTCnAMFWIwVqbDBlavPyRrgtJfeQHY
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.main_params =jTCnAMFWIwVqbDBlavPyRrgtJfeQHU
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj =rkdwbQnpaJYhGlWXEiNjHzsFyLueOM() 
 def addon_noti(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,sting):
  try:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHz=xbmcgui.Dialog()
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHz.notification(__addonname__,sting)
  except:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQik
 def addon_log(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,string):
  try:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHc=string.encode('utf-8','ignore')
  except:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHc='addonException: addon_log'
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHN=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,jTCnAMFWIwVqbDBlavPyRrgtJfeQHc),level=jTCnAMFWIwVqbDBlavPyRrgtJfeQHN)
 def get_keyboard_input(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,jTCnAMFWIwVqbDBlavPyRrgtJfeQki):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHs=jTCnAMFWIwVqbDBlavPyRrgtJfeQik
  kb=xbmc.Keyboard()
  kb.setHeading(jTCnAMFWIwVqbDBlavPyRrgtJfeQki)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHs=kb.getText()
  return jTCnAMFWIwVqbDBlavPyRrgtJfeQHs
 def get_settings_login_info(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHK =__addon__.getSetting('id')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHx =__addon__.getSetting('pw')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHh=jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(__addon__.getSetting('selected_profile'))
  return(jTCnAMFWIwVqbDBlavPyRrgtJfeQHK,jTCnAMFWIwVqbDBlavPyRrgtJfeQHx,jTCnAMFWIwVqbDBlavPyRrgtJfeQHh)
 def get_selQuality(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  try:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHm=['3840x2160/1','1920x1080/1','1280x720/1']
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHS=jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(__addon__.getSetting('selected_quality'))
   return jTCnAMFWIwVqbDBlavPyRrgtJfeQHm[jTCnAMFWIwVqbDBlavPyRrgtJfeQHS]
  except:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQik
  return 1080 
 def get_settings_direct_replay(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHo=jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(__addon__.getSetting('direct_replay'))
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQHo==0:
   return jTCnAMFWIwVqbDBlavPyRrgtJfeQiG
  else:
   return jTCnAMFWIwVqbDBlavPyRrgtJfeQiL
 def set_winCredential(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,credential):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH=xbmcgui.Window(10000)
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_LOGINTIME',jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH=xbmcgui.Window(10000)
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkE={'watcha_token':jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.getProperty('WATCHA_M_TOKEN'),'watcha_guit':jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.getProperty('WATCHA_M_GUIT'),'watcha_guitv':jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.getProperty('WATCHA_M_GUITV'),'watcha_usercd':jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.getProperty('WATCHA_M_USERCD')}
  return jTCnAMFWIwVqbDBlavPyRrgtJfeQkE
 def set_winEpisodeOrderby(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,jTCnAMFWIwVqbDBlavPyRrgtJfeQkG):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH=xbmcgui.Window(10000)
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_ORDERBY',jTCnAMFWIwVqbDBlavPyRrgtJfeQkG)
 def get_winEpisodeOrderby(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH=xbmcgui.Window(10000)
  return jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,args):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkG =args.get('orderby')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.set_winEpisodeOrderby(jTCnAMFWIwVqbDBlavPyRrgtJfeQkG)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,label,sublabel='',img='',infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQik,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL,params=''):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkL='%s?%s'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_url,urllib.parse.urlencode(params))
  if sublabel:jTCnAMFWIwVqbDBlavPyRrgtJfeQki='%s < %s >'%(label,sublabel)
  else: jTCnAMFWIwVqbDBlavPyRrgtJfeQki=label
  if not img:img='DefaultFolder.png'
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkX=xbmcgui.ListItem(jTCnAMFWIwVqbDBlavPyRrgtJfeQki)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQiX(img)==jTCnAMFWIwVqbDBlavPyRrgtJfeQiO:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkX.setArt(img)
  else:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkX.setArt({'thumb':img,'poster':img})
  if infoLabels:jTCnAMFWIwVqbDBlavPyRrgtJfeQkX.setInfo('Video',infoLabels)
  if not isFolder:jTCnAMFWIwVqbDBlavPyRrgtJfeQkX.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_handle,jTCnAMFWIwVqbDBlavPyRrgtJfeQkL,jTCnAMFWIwVqbDBlavPyRrgtJfeQkX,isFolder)
 def dp_Main_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  for jTCnAMFWIwVqbDBlavPyRrgtJfeQkO in jTCnAMFWIwVqbDBlavPyRrgtJfeQHE:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQki=jTCnAMFWIwVqbDBlavPyRrgtJfeQkO.get('title')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={'mode':jTCnAMFWIwVqbDBlavPyRrgtJfeQkO.get('mode'),'stype':jTCnAMFWIwVqbDBlavPyRrgtJfeQkO.get('stype'),'api_path':jTCnAMFWIwVqbDBlavPyRrgtJfeQkO.get('api_path'),'page':'1','sort':jTCnAMFWIwVqbDBlavPyRrgtJfeQkO.get('sort'),'tag_id':'-'}
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQkO.get('mode')=='XXX':
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['mode']='XXX'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkd=jTCnAMFWIwVqbDBlavPyRrgtJfeQiG
   else:
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkd=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel='',img='',infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQik,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQkd,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQip(jTCnAMFWIwVqbDBlavPyRrgtJfeQHE)>0:xbmcplugin.endOfDirectory(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_handle)
 def login_main(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  (jTCnAMFWIwVqbDBlavPyRrgtJfeQkU,jTCnAMFWIwVqbDBlavPyRrgtJfeQku,jTCnAMFWIwVqbDBlavPyRrgtJfeQkz)=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_settings_login_info()
  if not(jTCnAMFWIwVqbDBlavPyRrgtJfeQkU and jTCnAMFWIwVqbDBlavPyRrgtJfeQku):
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHz=xbmcgui.Dialog()
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkc=jTCnAMFWIwVqbDBlavPyRrgtJfeQHz.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQkc==jTCnAMFWIwVqbDBlavPyRrgtJfeQiL:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_winEpisodeOrderby()=='':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.set_winEpisodeOrderby('asc')
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.cookiefile_check():return
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkN =jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  jTCnAMFWIwVqbDBlavPyRrgtJfeQks=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQks==jTCnAMFWIwVqbDBlavPyRrgtJfeQik or jTCnAMFWIwVqbDBlavPyRrgtJfeQks=='':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQks=jTCnAMFWIwVqbDBlavPyRrgtJfeQiE('19000101')
  else:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQks=jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(re.sub('-','',jTCnAMFWIwVqbDBlavPyRrgtJfeQks))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkK=0
   while jTCnAMFWIwVqbDBlavPyRrgtJfeQiL:
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkK+=1
    time.sleep(0.05)
    if jTCnAMFWIwVqbDBlavPyRrgtJfeQks>=jTCnAMFWIwVqbDBlavPyRrgtJfeQkN:return
    if jTCnAMFWIwVqbDBlavPyRrgtJfeQkK>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQks>=jTCnAMFWIwVqbDBlavPyRrgtJfeQkN:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.GetCredential(jTCnAMFWIwVqbDBlavPyRrgtJfeQkU,jTCnAMFWIwVqbDBlavPyRrgtJfeQku,jTCnAMFWIwVqbDBlavPyRrgtJfeQkz):
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.set_winCredential(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.LoadCredential())
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,args):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.SaveCredential(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_winCredential())
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkx =args.get('stype')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkh =jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(args.get('page'))
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkm =args.get('sort')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkS=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.GetSubGroupList(jTCnAMFWIwVqbDBlavPyRrgtJfeQkx)
  jTCnAMFWIwVqbDBlavPyRrgtJfeQko=jTCnAMFWIwVqbDBlavPyRrgtJfeQHL if jTCnAMFWIwVqbDBlavPyRrgtJfeQkx=='genres' else jTCnAMFWIwVqbDBlavPyRrgtJfeQHi
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEH=jTCnAMFWIwVqbDBlavPyRrgtJfeQip(jTCnAMFWIwVqbDBlavPyRrgtJfeQkS)
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEk =jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(jTCnAMFWIwVqbDBlavPyRrgtJfeQEH//(jTCnAMFWIwVqbDBlavPyRrgtJfeQko+1))+1
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEG =(jTCnAMFWIwVqbDBlavPyRrgtJfeQkh-1)*jTCnAMFWIwVqbDBlavPyRrgtJfeQko
  for i in jTCnAMFWIwVqbDBlavPyRrgtJfeQid(jTCnAMFWIwVqbDBlavPyRrgtJfeQko):
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEL=jTCnAMFWIwVqbDBlavPyRrgtJfeQEG+i
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQEL>=jTCnAMFWIwVqbDBlavPyRrgtJfeQEH:break
   jTCnAMFWIwVqbDBlavPyRrgtJfeQki =jTCnAMFWIwVqbDBlavPyRrgtJfeQkS[jTCnAMFWIwVqbDBlavPyRrgtJfeQEL].get('group_name')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEi =jTCnAMFWIwVqbDBlavPyRrgtJfeQkS[jTCnAMFWIwVqbDBlavPyRrgtJfeQEL].get('api_path')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEX =jTCnAMFWIwVqbDBlavPyRrgtJfeQkS[jTCnAMFWIwVqbDBlavPyRrgtJfeQEL].get('tag_id')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={'mode':'CATEGORY_LIST','api_path':jTCnAMFWIwVqbDBlavPyRrgtJfeQEi,'tag_id':jTCnAMFWIwVqbDBlavPyRrgtJfeQEX,'stype':jTCnAMFWIwVqbDBlavPyRrgtJfeQkx,'page':'1','sort':jTCnAMFWIwVqbDBlavPyRrgtJfeQkm}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel='',img='',infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQik,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQEk>jTCnAMFWIwVqbDBlavPyRrgtJfeQkh:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['mode'] ='SUB_GROUP' 
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['stype'] =jTCnAMFWIwVqbDBlavPyRrgtJfeQkx
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['api_path']=args.get('api_path')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['page'] =jTCnAMFWIwVqbDBlavPyRrgtJfeQiY(jTCnAMFWIwVqbDBlavPyRrgtJfeQkh+1)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['sort'] =jTCnAMFWIwVqbDBlavPyRrgtJfeQkm
   jTCnAMFWIwVqbDBlavPyRrgtJfeQki='[B]%s >>[/B]'%'다음 페이지'
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEO=jTCnAMFWIwVqbDBlavPyRrgtJfeQiY(jTCnAMFWIwVqbDBlavPyRrgtJfeQkh+1)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel=jTCnAMFWIwVqbDBlavPyRrgtJfeQEO,img='',infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQik,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQip(jTCnAMFWIwVqbDBlavPyRrgtJfeQkS)>0:xbmcplugin.endOfDirectory(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_handle,cacheToDisc=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL)
 def play_VIDEO(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,args):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.SaveCredential(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_winCredential())
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEp =args.get('movie_code')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEd =args.get('season_code')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQki =args.get('title')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEY =args.get('thumbnail')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEU =jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_selQuality()
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.addon_log(jTCnAMFWIwVqbDBlavPyRrgtJfeQEp+' - '+jTCnAMFWIwVqbDBlavPyRrgtJfeQEd)
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEu,jTCnAMFWIwVqbDBlavPyRrgtJfeQEz,jTCnAMFWIwVqbDBlavPyRrgtJfeQEc=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.GetStreamingURL(jTCnAMFWIwVqbDBlavPyRrgtJfeQEp,jTCnAMFWIwVqbDBlavPyRrgtJfeQEU)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQEu=='':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.addon_noti(__language__(30908).encode('utf8'))
   return
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEN=jTCnAMFWIwVqbDBlavPyRrgtJfeQEu
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.addon_log(jTCnAMFWIwVqbDBlavPyRrgtJfeQEN)
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEs=xbmcgui.ListItem(path=jTCnAMFWIwVqbDBlavPyRrgtJfeQEN)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQEc:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEK=jTCnAMFWIwVqbDBlavPyRrgtJfeQEc
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEx ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEh ='mpd'
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEm ='com.widevine.alpha'
   jTCnAMFWIwVqbDBlavPyRrgtJfeQES =inputstreamhelper.Helper(jTCnAMFWIwVqbDBlavPyRrgtJfeQEh,drm=jTCnAMFWIwVqbDBlavPyRrgtJfeQEm)
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQES.check_inputstream():
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEo={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+jTCnAMFWIwVqbDBlavPyRrgtJfeQEp,'dt-custom-data':jTCnAMFWIwVqbDBlavPyRrgtJfeQEK,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGH=jTCnAMFWIwVqbDBlavPyRrgtJfeQEx+'|'+urllib.parse.urlencode(jTCnAMFWIwVqbDBlavPyRrgtJfeQEo)+'|R{SSM}|'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.addon_log(jTCnAMFWIwVqbDBlavPyRrgtJfeQGH)
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEs.setProperty('inputstream',jTCnAMFWIwVqbDBlavPyRrgtJfeQES.inputstream_addon)
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEs.setProperty('inputstream.adaptive.manifest_type',jTCnAMFWIwVqbDBlavPyRrgtJfeQEh)
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEs.setProperty('inputstream.adaptive.license_type',jTCnAMFWIwVqbDBlavPyRrgtJfeQEm)
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEs.setProperty('inputstream.adaptive.license_key',jTCnAMFWIwVqbDBlavPyRrgtJfeQGH)
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEs.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.USER_AGENT))
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQEz:
   try:
    f=jTCnAMFWIwVqbDBlavPyRrgtJfeQiU(jTCnAMFWIwVqbDBlavPyRrgtJfeQHX,'w',-1,'utf-8')
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGk=requests.get(jTCnAMFWIwVqbDBlavPyRrgtJfeQEz)
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGE=jTCnAMFWIwVqbDBlavPyRrgtJfeQGk.content.decode('utf-8') 
    for jTCnAMFWIwVqbDBlavPyRrgtJfeQGL in jTCnAMFWIwVqbDBlavPyRrgtJfeQGE.splitlines():
     jTCnAMFWIwVqbDBlavPyRrgtJfeQGi=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',jTCnAMFWIwVqbDBlavPyRrgtJfeQGL)
     f.write(jTCnAMFWIwVqbDBlavPyRrgtJfeQGi+'\n')
    f.close()
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEs.setSubtitles([jTCnAMFWIwVqbDBlavPyRrgtJfeQHX,jTCnAMFWIwVqbDBlavPyRrgtJfeQEz])
   except:
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEs.setSubtitles([jTCnAMFWIwVqbDBlavPyRrgtJfeQEz])
  xbmcplugin.setResolvedUrl(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_handle,jTCnAMFWIwVqbDBlavPyRrgtJfeQiL,jTCnAMFWIwVqbDBlavPyRrgtJfeQEs)
  try:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkx='movie' if jTCnAMFWIwVqbDBlavPyRrgtJfeQEd=='-' else 'seasons'
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={'code':jTCnAMFWIwVqbDBlavPyRrgtJfeQEp if jTCnAMFWIwVqbDBlavPyRrgtJfeQkx=='movie' else jTCnAMFWIwVqbDBlavPyRrgtJfeQEd,'img':jTCnAMFWIwVqbDBlavPyRrgtJfeQEY,'title':jTCnAMFWIwVqbDBlavPyRrgtJfeQki,'videoid':jTCnAMFWIwVqbDBlavPyRrgtJfeQEp}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.Save_Watched_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQkx,jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
  except:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQik
 def dp_Category_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,args):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.SaveCredential(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_winCredential())
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkx =args.get('stype')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEX =args.get('tag_id')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEi=args.get('api_path')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkh=jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(args.get('page'))
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkm =args.get('sort')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQGX,jTCnAMFWIwVqbDBlavPyRrgtJfeQGO=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.GetCategoryList(jTCnAMFWIwVqbDBlavPyRrgtJfeQkx,jTCnAMFWIwVqbDBlavPyRrgtJfeQEX,jTCnAMFWIwVqbDBlavPyRrgtJfeQEi,jTCnAMFWIwVqbDBlavPyRrgtJfeQkh,jTCnAMFWIwVqbDBlavPyRrgtJfeQkm)
  for jTCnAMFWIwVqbDBlavPyRrgtJfeQGp in jTCnAMFWIwVqbDBlavPyRrgtJfeQGX:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEp =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('code')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQki =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('title')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGd =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('content_type')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGY =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('story')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEY =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('thumbnail')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGU =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('year')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGu =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('film_rating_code')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGz=jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('film_rating_short')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGc =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('film_rating_long')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGN =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('duration')
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQGd=='movies': 
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkd =jTCnAMFWIwVqbDBlavPyRrgtJfeQiG
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGs ='MOVIE'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkY =''
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEd='-'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGK ='movie'
   else: 
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkd =jTCnAMFWIwVqbDBlavPyRrgtJfeQiL
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGs ='EPISODE'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkY ='Series'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEd=jTCnAMFWIwVqbDBlavPyRrgtJfeQEp
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGK ='tvshow' 
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGx={'mediatype':jTCnAMFWIwVqbDBlavPyRrgtJfeQGK,'mpaa':jTCnAMFWIwVqbDBlavPyRrgtJfeQGc,'title':jTCnAMFWIwVqbDBlavPyRrgtJfeQki,'year':jTCnAMFWIwVqbDBlavPyRrgtJfeQGU,'duration':jTCnAMFWIwVqbDBlavPyRrgtJfeQGN,'plot':'%s (%s)\n년도 : %s\n\n%s'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,jTCnAMFWIwVqbDBlavPyRrgtJfeQGz,jTCnAMFWIwVqbDBlavPyRrgtJfeQGU,jTCnAMFWIwVqbDBlavPyRrgtJfeQGY)}
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQGu>=19:
    jTCnAMFWIwVqbDBlavPyRrgtJfeQki+='  (%s년 - %s)'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQGU,jTCnAMFWIwVqbDBlavPyRrgtJfeQiY(jTCnAMFWIwVqbDBlavPyRrgtJfeQGz))
   else:
    jTCnAMFWIwVqbDBlavPyRrgtJfeQki+='  (%s년)'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQGU)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={'mode':jTCnAMFWIwVqbDBlavPyRrgtJfeQGs,'movie_code':jTCnAMFWIwVqbDBlavPyRrgtJfeQEp,'page':'1','season_code':jTCnAMFWIwVqbDBlavPyRrgtJfeQEd,'title':jTCnAMFWIwVqbDBlavPyRrgtJfeQki,'thumbnail':jTCnAMFWIwVqbDBlavPyRrgtJfeQEY}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel=jTCnAMFWIwVqbDBlavPyRrgtJfeQkY,img=jTCnAMFWIwVqbDBlavPyRrgtJfeQEY,infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQGx,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQkd,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQGO:
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.GetCategoryList_morepage(jTCnAMFWIwVqbDBlavPyRrgtJfeQkx,jTCnAMFWIwVqbDBlavPyRrgtJfeQEX,jTCnAMFWIwVqbDBlavPyRrgtJfeQEi,jTCnAMFWIwVqbDBlavPyRrgtJfeQkh+1,jTCnAMFWIwVqbDBlavPyRrgtJfeQkm):
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={}
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['mode'] ='CATEGORY_LIST'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['stype'] =jTCnAMFWIwVqbDBlavPyRrgtJfeQkx
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['tag_id'] =jTCnAMFWIwVqbDBlavPyRrgtJfeQEX
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['api_path']=jTCnAMFWIwVqbDBlavPyRrgtJfeQEi
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['page'] =jTCnAMFWIwVqbDBlavPyRrgtJfeQiY(jTCnAMFWIwVqbDBlavPyRrgtJfeQkh+1)
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['sort'] =jTCnAMFWIwVqbDBlavPyRrgtJfeQkm
    jTCnAMFWIwVqbDBlavPyRrgtJfeQki='[B]%s >>[/B]'%'다음 페이지'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEO=jTCnAMFWIwVqbDBlavPyRrgtJfeQiY(jTCnAMFWIwVqbDBlavPyRrgtJfeQkh+1)
    jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel=jTCnAMFWIwVqbDBlavPyRrgtJfeQEO,img='',infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQik,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQip(jTCnAMFWIwVqbDBlavPyRrgtJfeQGX)>0:
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQEi=='arrivals/latest':
    xbmcplugin.endOfDirectory(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_handle,cacheToDisc=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL)
   else:
    xbmcplugin.endOfDirectory(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_handle,cacheToDisc=jTCnAMFWIwVqbDBlavPyRrgtJfeQiG)
 def dp_Episode_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,args):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.SaveCredential(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_winCredential())
  jTCnAMFWIwVqbDBlavPyRrgtJfeQGm=args.get('movie_code')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkh =jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(args.get('page'))
  jTCnAMFWIwVqbDBlavPyRrgtJfeQEd =args.get('season_code')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQGX,jTCnAMFWIwVqbDBlavPyRrgtJfeQGO=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.GetEpisodoList(jTCnAMFWIwVqbDBlavPyRrgtJfeQGm,jTCnAMFWIwVqbDBlavPyRrgtJfeQkh,orderby=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_winEpisodeOrderby())
  for jTCnAMFWIwVqbDBlavPyRrgtJfeQGp in jTCnAMFWIwVqbDBlavPyRrgtJfeQGX:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEp =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('code')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQki =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('title')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEY =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('thumbnail')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGS =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('display_num')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGo =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('season_title')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLH=jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('episode_number')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGN =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('duration')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGx={'mediatype':'episode','tvshowtitle':jTCnAMFWIwVqbDBlavPyRrgtJfeQki if jTCnAMFWIwVqbDBlavPyRrgtJfeQki!='' else jTCnAMFWIwVqbDBlavPyRrgtJfeQGo,'title':'%s %s'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQGo,jTCnAMFWIwVqbDBlavPyRrgtJfeQGS)if jTCnAMFWIwVqbDBlavPyRrgtJfeQki!='' else jTCnAMFWIwVqbDBlavPyRrgtJfeQGS,'episode':jTCnAMFWIwVqbDBlavPyRrgtJfeQLH,'duration':jTCnAMFWIwVqbDBlavPyRrgtJfeQGN,'plot':'%s\n%s\n\n%s'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQGo,jTCnAMFWIwVqbDBlavPyRrgtJfeQGS,jTCnAMFWIwVqbDBlavPyRrgtJfeQki)}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQki='(%s) %s'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQGS,jTCnAMFWIwVqbDBlavPyRrgtJfeQki)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={'mode':'MOVIE','movie_code':jTCnAMFWIwVqbDBlavPyRrgtJfeQEp,'season_code':jTCnAMFWIwVqbDBlavPyRrgtJfeQEd,'title':'%s < %s >'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,jTCnAMFWIwVqbDBlavPyRrgtJfeQGo),'thumbnail':jTCnAMFWIwVqbDBlavPyRrgtJfeQEY}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel=jTCnAMFWIwVqbDBlavPyRrgtJfeQGo,img=jTCnAMFWIwVqbDBlavPyRrgtJfeQEY,infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQGx,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQiG,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQkh==1:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGx={'plot':'정렬순서를 변경합니다.'}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['mode'] ='ORDER_BY' 
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_winEpisodeOrderby()=='desc':
    jTCnAMFWIwVqbDBlavPyRrgtJfeQki='정렬순서변경 : 최신화부터 -> 1회부터'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['orderby']='asc'
   else:
    jTCnAMFWIwVqbDBlavPyRrgtJfeQki='정렬순서변경 : 1회부터 -> 최신화부터'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['orderby']='desc'
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel='',img='',infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQGx,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQiG,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQGO:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['mode'] ='EPISODE' 
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['movie_code']=jTCnAMFWIwVqbDBlavPyRrgtJfeQGm
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['page'] =jTCnAMFWIwVqbDBlavPyRrgtJfeQiY(jTCnAMFWIwVqbDBlavPyRrgtJfeQkh+1)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQki='[B]%s >>[/B]'%'다음 페이지'
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEO=jTCnAMFWIwVqbDBlavPyRrgtJfeQiY(jTCnAMFWIwVqbDBlavPyRrgtJfeQkh+1)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel=jTCnAMFWIwVqbDBlavPyRrgtJfeQEO,img='',infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQik,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQip(jTCnAMFWIwVqbDBlavPyRrgtJfeQGX)>0:xbmcplugin.endOfDirectory(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_handle,cacheToDisc=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL)
 def dp_Search_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,args):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.SaveCredential(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_winCredential())
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkh =jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(args.get('page'))
  if 'search_key' in args:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLk=args.get('search_key')
  else:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLk=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not jTCnAMFWIwVqbDBlavPyRrgtJfeQLk:return
  jTCnAMFWIwVqbDBlavPyRrgtJfeQGX,jTCnAMFWIwVqbDBlavPyRrgtJfeQGO=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.GetSearchList(jTCnAMFWIwVqbDBlavPyRrgtJfeQLk,jTCnAMFWIwVqbDBlavPyRrgtJfeQkh)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQip(jTCnAMFWIwVqbDBlavPyRrgtJfeQGX)==0:return
  for jTCnAMFWIwVqbDBlavPyRrgtJfeQGp in jTCnAMFWIwVqbDBlavPyRrgtJfeQGX:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEp =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('code')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQki =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('title')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGd=jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('content_type')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGY =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('story')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEY =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('thumbnail')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGU =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('year')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGu =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('film_rating_code')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGz=jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('film_rating_short')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGc =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('film_rating_long')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGN =jTCnAMFWIwVqbDBlavPyRrgtJfeQGp.get('duration')
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQGd=='movies': 
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkd =jTCnAMFWIwVqbDBlavPyRrgtJfeQiG
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGs ='MOVIE'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkY =''
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEd='-'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGK ='movie'
   else: 
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkd =jTCnAMFWIwVqbDBlavPyRrgtJfeQiL
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGs ='EPISODE'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkY ='Series'
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEd=jTCnAMFWIwVqbDBlavPyRrgtJfeQEp
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGK ='tvshow' 
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGx={'mediatype':jTCnAMFWIwVqbDBlavPyRrgtJfeQGK,'mpaa':jTCnAMFWIwVqbDBlavPyRrgtJfeQGc,'title':jTCnAMFWIwVqbDBlavPyRrgtJfeQki,'year':jTCnAMFWIwVqbDBlavPyRrgtJfeQGU,'duration':jTCnAMFWIwVqbDBlavPyRrgtJfeQGN,'plot':'%s (%s)\n년도 : %s\n\n%s'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,jTCnAMFWIwVqbDBlavPyRrgtJfeQGz,jTCnAMFWIwVqbDBlavPyRrgtJfeQGU,jTCnAMFWIwVqbDBlavPyRrgtJfeQGY)}
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQGu>=19:
    jTCnAMFWIwVqbDBlavPyRrgtJfeQki+='  (%s년 - %s)'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQGU,jTCnAMFWIwVqbDBlavPyRrgtJfeQiY(jTCnAMFWIwVqbDBlavPyRrgtJfeQGz))
   else:
    jTCnAMFWIwVqbDBlavPyRrgtJfeQki+='  (%s년)'%(jTCnAMFWIwVqbDBlavPyRrgtJfeQGU)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={'mode':jTCnAMFWIwVqbDBlavPyRrgtJfeQGs,'movie_code':jTCnAMFWIwVqbDBlavPyRrgtJfeQEp,'page':'1','season_code':jTCnAMFWIwVqbDBlavPyRrgtJfeQEd,'title':jTCnAMFWIwVqbDBlavPyRrgtJfeQki,'thumbnail':jTCnAMFWIwVqbDBlavPyRrgtJfeQEY}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel=jTCnAMFWIwVqbDBlavPyRrgtJfeQkY,img=jTCnAMFWIwVqbDBlavPyRrgtJfeQEY,infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQGx,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQkd,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQGO:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['mode'] ='SEARCH'
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['search_key']=jTCnAMFWIwVqbDBlavPyRrgtJfeQLk
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp['page'] =jTCnAMFWIwVqbDBlavPyRrgtJfeQiY(jTCnAMFWIwVqbDBlavPyRrgtJfeQkh+1)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQki='[B]%s >>[/B]'%'다음 페이지'
   jTCnAMFWIwVqbDBlavPyRrgtJfeQEO=jTCnAMFWIwVqbDBlavPyRrgtJfeQiY(jTCnAMFWIwVqbDBlavPyRrgtJfeQkh+1)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel=jTCnAMFWIwVqbDBlavPyRrgtJfeQEO,img='',infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQik,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQip(jTCnAMFWIwVqbDBlavPyRrgtJfeQGX)>0:xbmcplugin.endOfDirectory(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_handle)
 def Delete_Watched_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,jTCnAMFWIwVqbDBlavPyRrgtJfeQkx):
  try:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%jTCnAMFWIwVqbDBlavPyRrgtJfeQkx))
   fp=jTCnAMFWIwVqbDBlavPyRrgtJfeQiU(jTCnAMFWIwVqbDBlavPyRrgtJfeQLE,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQik
 def dp_WatchList_Delete(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,args):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkx=args.get('stype')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHz=xbmcgui.Dialog()
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkc=jTCnAMFWIwVqbDBlavPyRrgtJfeQHz.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQkc==jTCnAMFWIwVqbDBlavPyRrgtJfeQiG:sys.exit()
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.Delete_Watched_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQkx)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,jTCnAMFWIwVqbDBlavPyRrgtJfeQkx):
  try:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%jTCnAMFWIwVqbDBlavPyRrgtJfeQkx))
   fp=jTCnAMFWIwVqbDBlavPyRrgtJfeQiU(jTCnAMFWIwVqbDBlavPyRrgtJfeQLE,'r',-1,'utf-8')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLG=fp.readlines()
   fp.close()
  except:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLG=[]
  return jTCnAMFWIwVqbDBlavPyRrgtJfeQLG
 def Save_Watched_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,jTCnAMFWIwVqbDBlavPyRrgtJfeQkx,jTCnAMFWIwVqbDBlavPyRrgtJfeQHU):
  try:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%jTCnAMFWIwVqbDBlavPyRrgtJfeQkx))
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLi=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.Load_Watched_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQkx) 
   fp=jTCnAMFWIwVqbDBlavPyRrgtJfeQiU(jTCnAMFWIwVqbDBlavPyRrgtJfeQLE,'w',-1,'utf-8')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLX=urllib.parse.urlencode(jTCnAMFWIwVqbDBlavPyRrgtJfeQHU)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLX=jTCnAMFWIwVqbDBlavPyRrgtJfeQLX+'\n'
   fp.write(jTCnAMFWIwVqbDBlavPyRrgtJfeQLX)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLO=0
   for jTCnAMFWIwVqbDBlavPyRrgtJfeQLp in jTCnAMFWIwVqbDBlavPyRrgtJfeQLi:
    jTCnAMFWIwVqbDBlavPyRrgtJfeQLd=jTCnAMFWIwVqbDBlavPyRrgtJfeQiO(urllib.parse.parse_qsl(jTCnAMFWIwVqbDBlavPyRrgtJfeQLp))
    jTCnAMFWIwVqbDBlavPyRrgtJfeQLY=jTCnAMFWIwVqbDBlavPyRrgtJfeQHU.get('code').strip()
    jTCnAMFWIwVqbDBlavPyRrgtJfeQLU=jTCnAMFWIwVqbDBlavPyRrgtJfeQLd.get('code').strip()
    if jTCnAMFWIwVqbDBlavPyRrgtJfeQkx=='seasons' and jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_settings_direct_replay()==jTCnAMFWIwVqbDBlavPyRrgtJfeQiL:
     jTCnAMFWIwVqbDBlavPyRrgtJfeQLY=jTCnAMFWIwVqbDBlavPyRrgtJfeQHU.get('videoid').strip()
     jTCnAMFWIwVqbDBlavPyRrgtJfeQLU=jTCnAMFWIwVqbDBlavPyRrgtJfeQLd.get('videoid').strip()if jTCnAMFWIwVqbDBlavPyRrgtJfeQLU!=jTCnAMFWIwVqbDBlavPyRrgtJfeQik else '-'
    if jTCnAMFWIwVqbDBlavPyRrgtJfeQLY!=jTCnAMFWIwVqbDBlavPyRrgtJfeQLU:
     fp.write(jTCnAMFWIwVqbDBlavPyRrgtJfeQLp)
     jTCnAMFWIwVqbDBlavPyRrgtJfeQLO+=1
     if jTCnAMFWIwVqbDBlavPyRrgtJfeQLO>=50:break
   fp.close()
  except:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQik
 def dp_Watch_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp,args):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkx =args.get('stype')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHo=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.get_settings_direct_replay()
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQkx=='-':
   for jTCnAMFWIwVqbDBlavPyRrgtJfeQLu in jTCnAMFWIwVqbDBlavPyRrgtJfeQHG:
    jTCnAMFWIwVqbDBlavPyRrgtJfeQki=jTCnAMFWIwVqbDBlavPyRrgtJfeQLu.get('title')
    jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={'mode':jTCnAMFWIwVqbDBlavPyRrgtJfeQLu.get('mode'),'stype':jTCnAMFWIwVqbDBlavPyRrgtJfeQLu.get('stype')}
    jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel='',img='',infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQik,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
   if jTCnAMFWIwVqbDBlavPyRrgtJfeQip(jTCnAMFWIwVqbDBlavPyRrgtJfeQHG)>0:xbmcplugin.endOfDirectory(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_handle)
  else:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLz=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.Load_Watched_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQkx)
   for jTCnAMFWIwVqbDBlavPyRrgtJfeQLc in jTCnAMFWIwVqbDBlavPyRrgtJfeQLz:
    jTCnAMFWIwVqbDBlavPyRrgtJfeQLN=jTCnAMFWIwVqbDBlavPyRrgtJfeQiO(urllib.parse.parse_qsl(jTCnAMFWIwVqbDBlavPyRrgtJfeQLc))
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEp=jTCnAMFWIwVqbDBlavPyRrgtJfeQLN.get('code').strip()
    jTCnAMFWIwVqbDBlavPyRrgtJfeQki =jTCnAMFWIwVqbDBlavPyRrgtJfeQLN.get('title').strip()
    jTCnAMFWIwVqbDBlavPyRrgtJfeQEY =jTCnAMFWIwVqbDBlavPyRrgtJfeQLN.get('img').strip()
    jTCnAMFWIwVqbDBlavPyRrgtJfeQLs =jTCnAMFWIwVqbDBlavPyRrgtJfeQLN.get('videoid').strip()
    try:
     jTCnAMFWIwVqbDBlavPyRrgtJfeQEY=jTCnAMFWIwVqbDBlavPyRrgtJfeQEY.replace('\'','\"')
     jTCnAMFWIwVqbDBlavPyRrgtJfeQEY=json.loads(jTCnAMFWIwVqbDBlavPyRrgtJfeQEY)
    except:
     jTCnAMFWIwVqbDBlavPyRrgtJfeQik
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGx={}
    jTCnAMFWIwVqbDBlavPyRrgtJfeQGx['plot']=jTCnAMFWIwVqbDBlavPyRrgtJfeQki
    if jTCnAMFWIwVqbDBlavPyRrgtJfeQkx=='movie':
     jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={'mode':'MOVIE','page':'1','movie_code':jTCnAMFWIwVqbDBlavPyRrgtJfeQEp,'season_code':'-','title':jTCnAMFWIwVqbDBlavPyRrgtJfeQki,'thumbnail':jTCnAMFWIwVqbDBlavPyRrgtJfeQEY}
     jTCnAMFWIwVqbDBlavPyRrgtJfeQkd=jTCnAMFWIwVqbDBlavPyRrgtJfeQiG
    else:
     if jTCnAMFWIwVqbDBlavPyRrgtJfeQHo==jTCnAMFWIwVqbDBlavPyRrgtJfeQiG or jTCnAMFWIwVqbDBlavPyRrgtJfeQLs==jTCnAMFWIwVqbDBlavPyRrgtJfeQik:
      jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={'mode':'EPISODE','page':'1','movie_code':jTCnAMFWIwVqbDBlavPyRrgtJfeQEp,'season_code':jTCnAMFWIwVqbDBlavPyRrgtJfeQEp,'title':jTCnAMFWIwVqbDBlavPyRrgtJfeQki,'thumbnail':jTCnAMFWIwVqbDBlavPyRrgtJfeQEY}
      jTCnAMFWIwVqbDBlavPyRrgtJfeQkd=jTCnAMFWIwVqbDBlavPyRrgtJfeQiL
     else:
      jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={'mode':'MOVIE','movie_code':jTCnAMFWIwVqbDBlavPyRrgtJfeQLs,'season_code':jTCnAMFWIwVqbDBlavPyRrgtJfeQEp,'title':jTCnAMFWIwVqbDBlavPyRrgtJfeQki,'thumbnail':jTCnAMFWIwVqbDBlavPyRrgtJfeQEY}
      jTCnAMFWIwVqbDBlavPyRrgtJfeQkd=jTCnAMFWIwVqbDBlavPyRrgtJfeQiG
    jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel='',img=jTCnAMFWIwVqbDBlavPyRrgtJfeQEY,infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQGx,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQkd,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
   jTCnAMFWIwVqbDBlavPyRrgtJfeQGx={'plot':'시청목록을 삭제합니다.'}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQki='*** 시청목록 삭제 ***'
   jTCnAMFWIwVqbDBlavPyRrgtJfeQkp={'mode':'MYVIEW_REMOVE','stype':jTCnAMFWIwVqbDBlavPyRrgtJfeQkx}
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.add_dir(jTCnAMFWIwVqbDBlavPyRrgtJfeQki,sublabel='',img='',infoLabels=jTCnAMFWIwVqbDBlavPyRrgtJfeQGx,isFolder=jTCnAMFWIwVqbDBlavPyRrgtJfeQiG,params=jTCnAMFWIwVqbDBlavPyRrgtJfeQkp)
   xbmcplugin.endOfDirectory(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp._addon_handle,cacheToDisc=jTCnAMFWIwVqbDBlavPyRrgtJfeQiG)
 def logout(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHz=xbmcgui.Dialog()
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkc=jTCnAMFWIwVqbDBlavPyRrgtJfeQHz.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQkc==jTCnAMFWIwVqbDBlavPyRrgtJfeQiG:sys.exit()
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.wininfo_clear()
  if os.path.isfile(jTCnAMFWIwVqbDBlavPyRrgtJfeQHO):os.remove(jTCnAMFWIwVqbDBlavPyRrgtJfeQHO)
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH=xbmcgui.Window(10000)
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_TOKEN','')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_GUIT','')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_GUITV','')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_USERCD','')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQLK =jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.Get_Now_Datetime()
  jTCnAMFWIwVqbDBlavPyRrgtJfeQLx=jTCnAMFWIwVqbDBlavPyRrgtJfeQLK+datetime.timedelta(days=jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(__addon__.getSetting('cache_ttl')))
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH=xbmcgui.Window(10000)
  jTCnAMFWIwVqbDBlavPyRrgtJfeQLh={'watcha_token':jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.getProperty('WATCHA_M_TOKEN'),'watcha_guit':jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.getProperty('WATCHA_M_GUIT'),'watcha_guitv':jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.getProperty('WATCHA_M_GUITV'),'watcha_usercd':jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':jTCnAMFWIwVqbDBlavPyRrgtJfeQLx.strftime('%Y-%m-%d')}
  try: 
   fp=jTCnAMFWIwVqbDBlavPyRrgtJfeQiU(jTCnAMFWIwVqbDBlavPyRrgtJfeQHO,'w',-1,'utf-8')
   json.dump(jTCnAMFWIwVqbDBlavPyRrgtJfeQLh,fp)
   fp.close()
  except jTCnAMFWIwVqbDBlavPyRrgtJfeQiu as exception:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQiz(exception)
 def cookiefile_check(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQLh={}
  try: 
   fp=jTCnAMFWIwVqbDBlavPyRrgtJfeQiU(jTCnAMFWIwVqbDBlavPyRrgtJfeQHO,'r',-1,'utf-8')
   jTCnAMFWIwVqbDBlavPyRrgtJfeQLh= json.load(fp)
   fp.close()
  except jTCnAMFWIwVqbDBlavPyRrgtJfeQiu as exception:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.wininfo_clear()
   return jTCnAMFWIwVqbDBlavPyRrgtJfeQiG
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkU =__addon__.getSetting('id')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQku =__addon__.getSetting('pw')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQLm =__addon__.getSetting('selected_profile')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_id']=base64.standard_b64decode(jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_id']).decode('utf-8')
  jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_pw']=base64.standard_b64decode(jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_pw']).decode('utf-8')
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQkU!=jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_id']or jTCnAMFWIwVqbDBlavPyRrgtJfeQku!=jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_pw']or jTCnAMFWIwVqbDBlavPyRrgtJfeQLm!=jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_profile']:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.wininfo_clear()
   return jTCnAMFWIwVqbDBlavPyRrgtJfeQiG
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkN =jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  jTCnAMFWIwVqbDBlavPyRrgtJfeQLS=jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_limitdate']
  jTCnAMFWIwVqbDBlavPyRrgtJfeQks =jTCnAMFWIwVqbDBlavPyRrgtJfeQiE(re.sub('-','',jTCnAMFWIwVqbDBlavPyRrgtJfeQLS))
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQks<jTCnAMFWIwVqbDBlavPyRrgtJfeQkN:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.wininfo_clear()
   return jTCnAMFWIwVqbDBlavPyRrgtJfeQiG
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH=xbmcgui.Window(10000)
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_TOKEN',jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_token'])
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_GUIT',jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_guit'])
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_GUITV',jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_guitv'])
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_USERCD',jTCnAMFWIwVqbDBlavPyRrgtJfeQLh['watcha_usercd'])
  jTCnAMFWIwVqbDBlavPyRrgtJfeQkH.setProperty('WATCHA_M_LOGINTIME',jTCnAMFWIwVqbDBlavPyRrgtJfeQLS)
  return jTCnAMFWIwVqbDBlavPyRrgtJfeQiL
 def watcha_main(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp):
  jTCnAMFWIwVqbDBlavPyRrgtJfeQLo=jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.main_params.get('mode',jTCnAMFWIwVqbDBlavPyRrgtJfeQik)
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQLo=='LOGOUT':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.logout()
   return
  jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.login_main()
  if jTCnAMFWIwVqbDBlavPyRrgtJfeQLo is jTCnAMFWIwVqbDBlavPyRrgtJfeQik:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.dp_Main_List()
  elif jTCnAMFWIwVqbDBlavPyRrgtJfeQLo=='SUB_GROUP':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.dp_SubGroup_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.main_params)
  elif jTCnAMFWIwVqbDBlavPyRrgtJfeQLo=='CATEGORY_LIST':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.dp_Category_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.main_params)
  elif jTCnAMFWIwVqbDBlavPyRrgtJfeQLo=='EPISODE':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.dp_Episode_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.main_params)
  elif jTCnAMFWIwVqbDBlavPyRrgtJfeQLo=='ORDER_BY':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.dp_setEpOrderby(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.main_params)
  elif jTCnAMFWIwVqbDBlavPyRrgtJfeQLo=='SEARCH':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.dp_Search_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.main_params)
  elif jTCnAMFWIwVqbDBlavPyRrgtJfeQLo=='MOVIE':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.play_VIDEO(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.main_params)
  elif jTCnAMFWIwVqbDBlavPyRrgtJfeQLo=='WATCH':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.dp_Watch_List(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.main_params)
  elif jTCnAMFWIwVqbDBlavPyRrgtJfeQLo=='MYVIEW_REMOVE':
   jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.dp_WatchList_Delete(jTCnAMFWIwVqbDBlavPyRrgtJfeQHp.main_params)
  else:
   jTCnAMFWIwVqbDBlavPyRrgtJfeQik
# Created by pyminifier (https://github.com/liftoff/pyminifier)
