__author__="NightRain"
IqvgKtwEiPTsYpzOWuDGbFlorQdhex=object
IqvgKtwEiPTsYpzOWuDGbFlorQdhey=None
IqvgKtwEiPTsYpzOWuDGbFlorQdheM=int
IqvgKtwEiPTsYpzOWuDGbFlorQdheR=False
IqvgKtwEiPTsYpzOWuDGbFlorQdhem=True
IqvgKtwEiPTsYpzOWuDGbFlorQdheV=len
IqvgKtwEiPTsYpzOWuDGbFlorQdhek=range
IqvgKtwEiPTsYpzOWuDGbFlorQdhea=str
IqvgKtwEiPTsYpzOWuDGbFlorQdheA=open
IqvgKtwEiPTsYpzOWuDGbFlorQdheU=dict
IqvgKtwEiPTsYpzOWuDGbFlorQdhef=Exception
IqvgKtwEiPTsYpzOWuDGbFlorQdheH=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
IqvgKtwEiPTsYpzOWuDGbFlorQdhxM=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'검색 (search)','mode':'SEARCH','stype':'-','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-'}]
IqvgKtwEiPTsYpzOWuDGbFlorQdhxR=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
IqvgKtwEiPTsYpzOWuDGbFlorQdhxm=40
IqvgKtwEiPTsYpzOWuDGbFlorQdhxe =20
IqvgKtwEiPTsYpzOWuDGbFlorQdhxV =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
IqvgKtwEiPTsYpzOWuDGbFlorQdhxk=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class IqvgKtwEiPTsYpzOWuDGbFlorQdhxy(IqvgKtwEiPTsYpzOWuDGbFlorQdhex):
 def __init__(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,IqvgKtwEiPTsYpzOWuDGbFlorQdhxA,IqvgKtwEiPTsYpzOWuDGbFlorQdhxU,IqvgKtwEiPTsYpzOWuDGbFlorQdhxf):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_url =IqvgKtwEiPTsYpzOWuDGbFlorQdhxA
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_handle=IqvgKtwEiPTsYpzOWuDGbFlorQdhxU
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.main_params =IqvgKtwEiPTsYpzOWuDGbFlorQdhxf
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj =zgXkQDRhJFGHfnAcVwyqUTEBOstKYW() 
 def addon_noti(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,sting):
  try:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxX=xbmcgui.Dialog()
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxX.notification(__addonname__,sting)
  except:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhey
 def addon_log(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,string):
  try:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxS=string.encode('utf-8','ignore')
  except:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxS='addonException: addon_log'
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxJ=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,IqvgKtwEiPTsYpzOWuDGbFlorQdhxS),level=IqvgKtwEiPTsYpzOWuDGbFlorQdhxJ)
 def get_keyboard_input(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,IqvgKtwEiPTsYpzOWuDGbFlorQdhye):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxC=IqvgKtwEiPTsYpzOWuDGbFlorQdhey
  kb=xbmc.Keyboard()
  kb.setHeading(IqvgKtwEiPTsYpzOWuDGbFlorQdhye)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxC=kb.getText()
  return IqvgKtwEiPTsYpzOWuDGbFlorQdhxC
 def get_settings_login_info(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxc =__addon__.getSetting('id')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxL =__addon__.getSetting('pw')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxN=IqvgKtwEiPTsYpzOWuDGbFlorQdheM(__addon__.getSetting('selected_profile'))
  return(IqvgKtwEiPTsYpzOWuDGbFlorQdhxc,IqvgKtwEiPTsYpzOWuDGbFlorQdhxL,IqvgKtwEiPTsYpzOWuDGbFlorQdhxN)
 def get_selQuality(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  try:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxj=['3840x2160/1','1920x1080/1','1280x720/1']
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxn=IqvgKtwEiPTsYpzOWuDGbFlorQdheM(__addon__.getSetting('selected_quality'))
   return IqvgKtwEiPTsYpzOWuDGbFlorQdhxj[IqvgKtwEiPTsYpzOWuDGbFlorQdhxn]
  except:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhey
  return 1080 
 def get_settings_direct_replay(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxB=IqvgKtwEiPTsYpzOWuDGbFlorQdheM(__addon__.getSetting('direct_replay'))
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhxB==0:
   return IqvgKtwEiPTsYpzOWuDGbFlorQdheR
  else:
   return IqvgKtwEiPTsYpzOWuDGbFlorQdhem
 def set_winCredential(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,credential):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx=xbmcgui.Window(10000)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_LOGINTIME',IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx=xbmcgui.Window(10000)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyM={'watcha_token':IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.getProperty('WATCHA_M_TOKEN'),'watcha_guit':IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.getProperty('WATCHA_M_GUIT'),'watcha_guitv':IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.getProperty('WATCHA_M_GUITV'),'watcha_usercd':IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.getProperty('WATCHA_M_USERCD')}
  return IqvgKtwEiPTsYpzOWuDGbFlorQdhyM
 def set_winEpisodeOrderby(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,IqvgKtwEiPTsYpzOWuDGbFlorQdhyR):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx=xbmcgui.Window(10000)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_ORDERBY',IqvgKtwEiPTsYpzOWuDGbFlorQdhyR)
 def get_winEpisodeOrderby(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx=xbmcgui.Window(10000)
  return IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,args):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyR =args.get('orderby')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.set_winEpisodeOrderby(IqvgKtwEiPTsYpzOWuDGbFlorQdhyR)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,label,sublabel='',img='',infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhey,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdhem,params=''):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhym='%s?%s'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_url,urllib.parse.urlencode(params))
  if sublabel:IqvgKtwEiPTsYpzOWuDGbFlorQdhye='%s < %s >'%(label,sublabel)
  else: IqvgKtwEiPTsYpzOWuDGbFlorQdhye=label
  if not img:img='DefaultFolder.png'
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyV=xbmcgui.ListItem(IqvgKtwEiPTsYpzOWuDGbFlorQdhye)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyV.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:IqvgKtwEiPTsYpzOWuDGbFlorQdhyV.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:IqvgKtwEiPTsYpzOWuDGbFlorQdhyV.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_handle,IqvgKtwEiPTsYpzOWuDGbFlorQdhym,IqvgKtwEiPTsYpzOWuDGbFlorQdhyV,isFolder)
 def dp_Main_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  for IqvgKtwEiPTsYpzOWuDGbFlorQdhyk in IqvgKtwEiPTsYpzOWuDGbFlorQdhxM:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhye=IqvgKtwEiPTsYpzOWuDGbFlorQdhyk.get('title')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya={'mode':IqvgKtwEiPTsYpzOWuDGbFlorQdhyk.get('mode'),'stype':IqvgKtwEiPTsYpzOWuDGbFlorQdhyk.get('stype'),'api_path':IqvgKtwEiPTsYpzOWuDGbFlorQdhyk.get('api_path'),'page':'1','sort':IqvgKtwEiPTsYpzOWuDGbFlorQdhyk.get('sort'),'tag_id':'-'}
   if IqvgKtwEiPTsYpzOWuDGbFlorQdhyk.get('mode')=='XXX':
    IqvgKtwEiPTsYpzOWuDGbFlorQdhya['mode']='XXX'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhyA=IqvgKtwEiPTsYpzOWuDGbFlorQdheR
   else:
    IqvgKtwEiPTsYpzOWuDGbFlorQdhyA=IqvgKtwEiPTsYpzOWuDGbFlorQdhem
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel='',img='',infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhey,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdhyA,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdheV(IqvgKtwEiPTsYpzOWuDGbFlorQdhxM)>0:xbmcplugin.endOfDirectory(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_handle)
 def login_main(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  (IqvgKtwEiPTsYpzOWuDGbFlorQdhyf,IqvgKtwEiPTsYpzOWuDGbFlorQdhyH,IqvgKtwEiPTsYpzOWuDGbFlorQdhyX)=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_settings_login_info()
  if not(IqvgKtwEiPTsYpzOWuDGbFlorQdhyf and IqvgKtwEiPTsYpzOWuDGbFlorQdhyH):
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxX=xbmcgui.Dialog()
   IqvgKtwEiPTsYpzOWuDGbFlorQdhyS=IqvgKtwEiPTsYpzOWuDGbFlorQdhxX.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if IqvgKtwEiPTsYpzOWuDGbFlorQdhyS==IqvgKtwEiPTsYpzOWuDGbFlorQdhem:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_winEpisodeOrderby()=='':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.set_winEpisodeOrderby('asc')
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.cookiefile_check():return
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyJ =IqvgKtwEiPTsYpzOWuDGbFlorQdheM(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyC=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhyC==IqvgKtwEiPTsYpzOWuDGbFlorQdhey or IqvgKtwEiPTsYpzOWuDGbFlorQdhyC=='':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhyC=IqvgKtwEiPTsYpzOWuDGbFlorQdheM('19000101')
  else:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhyC=IqvgKtwEiPTsYpzOWuDGbFlorQdheM(re.sub('-','',IqvgKtwEiPTsYpzOWuDGbFlorQdhyC))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhyc=0
   while IqvgKtwEiPTsYpzOWuDGbFlorQdhem:
    IqvgKtwEiPTsYpzOWuDGbFlorQdhyc+=1
    time.sleep(0.05)
    if IqvgKtwEiPTsYpzOWuDGbFlorQdhyC>=IqvgKtwEiPTsYpzOWuDGbFlorQdhyJ:return
    if IqvgKtwEiPTsYpzOWuDGbFlorQdhyc>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhyC>=IqvgKtwEiPTsYpzOWuDGbFlorQdhyJ:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.GetCredential(IqvgKtwEiPTsYpzOWuDGbFlorQdhyf,IqvgKtwEiPTsYpzOWuDGbFlorQdhyH,IqvgKtwEiPTsYpzOWuDGbFlorQdhyX):
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.set_winCredential(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.LoadCredential())
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,args):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.SaveCredential(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_winCredential())
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyL =args.get('stype')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyN =IqvgKtwEiPTsYpzOWuDGbFlorQdheM(args.get('page'))
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyj =args.get('sort')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyn=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.GetSubGroupList(IqvgKtwEiPTsYpzOWuDGbFlorQdhyL)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyB=IqvgKtwEiPTsYpzOWuDGbFlorQdhxm if IqvgKtwEiPTsYpzOWuDGbFlorQdhyL=='genres' else IqvgKtwEiPTsYpzOWuDGbFlorQdhxe
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMx=IqvgKtwEiPTsYpzOWuDGbFlorQdheV(IqvgKtwEiPTsYpzOWuDGbFlorQdhyn)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMy =IqvgKtwEiPTsYpzOWuDGbFlorQdheM(IqvgKtwEiPTsYpzOWuDGbFlorQdhMx//(IqvgKtwEiPTsYpzOWuDGbFlorQdhyB+1))+1
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMR =(IqvgKtwEiPTsYpzOWuDGbFlorQdhyN-1)*IqvgKtwEiPTsYpzOWuDGbFlorQdhyB
  for i in IqvgKtwEiPTsYpzOWuDGbFlorQdhek(IqvgKtwEiPTsYpzOWuDGbFlorQdhyB):
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMm=IqvgKtwEiPTsYpzOWuDGbFlorQdhMR+i
   if IqvgKtwEiPTsYpzOWuDGbFlorQdhMm>=IqvgKtwEiPTsYpzOWuDGbFlorQdhMx:break
   IqvgKtwEiPTsYpzOWuDGbFlorQdhye =IqvgKtwEiPTsYpzOWuDGbFlorQdhyn[IqvgKtwEiPTsYpzOWuDGbFlorQdhMm].get('group_name')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMe =IqvgKtwEiPTsYpzOWuDGbFlorQdhyn[IqvgKtwEiPTsYpzOWuDGbFlorQdhMm].get('api_path')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMV =IqvgKtwEiPTsYpzOWuDGbFlorQdhyn[IqvgKtwEiPTsYpzOWuDGbFlorQdhMm].get('tag_id')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya={'mode':'CATEGORY_LIST','api_path':IqvgKtwEiPTsYpzOWuDGbFlorQdhMe,'tag_id':IqvgKtwEiPTsYpzOWuDGbFlorQdhMV,'stype':IqvgKtwEiPTsYpzOWuDGbFlorQdhyL,'page':'1','sort':IqvgKtwEiPTsYpzOWuDGbFlorQdhyj}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel='',img='',infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhey,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdhem,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhMy>IqvgKtwEiPTsYpzOWuDGbFlorQdhyN:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya={}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['mode'] ='SUB_GROUP' 
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['stype'] =IqvgKtwEiPTsYpzOWuDGbFlorQdhyL
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['api_path']=args.get('api_path')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['page'] =IqvgKtwEiPTsYpzOWuDGbFlorQdhea(IqvgKtwEiPTsYpzOWuDGbFlorQdhyN+1)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['sort'] =IqvgKtwEiPTsYpzOWuDGbFlorQdhyj
   IqvgKtwEiPTsYpzOWuDGbFlorQdhye='[B]%s >>[/B]'%'다음 페이지'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMk=IqvgKtwEiPTsYpzOWuDGbFlorQdhea(IqvgKtwEiPTsYpzOWuDGbFlorQdhyN+1)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel=IqvgKtwEiPTsYpzOWuDGbFlorQdhMk,img='',infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhey,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdhem,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdheV(IqvgKtwEiPTsYpzOWuDGbFlorQdhyn)>0:xbmcplugin.endOfDirectory(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_handle,cacheToDisc=IqvgKtwEiPTsYpzOWuDGbFlorQdhem)
 def play_VIDEO(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,args):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.SaveCredential(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_winCredential())
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMa =args.get('movie_code')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMA =args.get('season_code')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhye =args.get('title')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMU =args.get('thumbnail')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMf =IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_selQuality()
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.addon_log(IqvgKtwEiPTsYpzOWuDGbFlorQdhMa+' - '+IqvgKtwEiPTsYpzOWuDGbFlorQdhMA)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMH,IqvgKtwEiPTsYpzOWuDGbFlorQdhMX,IqvgKtwEiPTsYpzOWuDGbFlorQdhMS=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.GetStreamingURL(IqvgKtwEiPTsYpzOWuDGbFlorQdhMa,IqvgKtwEiPTsYpzOWuDGbFlorQdhMf)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhMH=='':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.addon_noti(__language__(30908).encode('utf8'))
   return
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMJ=IqvgKtwEiPTsYpzOWuDGbFlorQdhMH
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.addon_log(IqvgKtwEiPTsYpzOWuDGbFlorQdhMJ)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMC=xbmcgui.ListItem(path=IqvgKtwEiPTsYpzOWuDGbFlorQdhMJ)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhMS:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMc=IqvgKtwEiPTsYpzOWuDGbFlorQdhMS
   IqvgKtwEiPTsYpzOWuDGbFlorQdhML ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMN ='mpd'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMj ='com.widevine.alpha'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMn =inputstreamhelper.Helper(IqvgKtwEiPTsYpzOWuDGbFlorQdhMN,drm=IqvgKtwEiPTsYpzOWuDGbFlorQdhMj)
   if IqvgKtwEiPTsYpzOWuDGbFlorQdhMn.check_inputstream():
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMB={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+IqvgKtwEiPTsYpzOWuDGbFlorQdhMa,'dt-custom-data':IqvgKtwEiPTsYpzOWuDGbFlorQdhMc,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRx=IqvgKtwEiPTsYpzOWuDGbFlorQdhML+'|'+urllib.parse.urlencode(IqvgKtwEiPTsYpzOWuDGbFlorQdhMB)+'|R{SSM}|'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.addon_log(IqvgKtwEiPTsYpzOWuDGbFlorQdhRx)
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMC.setProperty('inputstream',IqvgKtwEiPTsYpzOWuDGbFlorQdhMn.inputstream_addon)
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMC.setProperty('inputstream.adaptive.manifest_type',IqvgKtwEiPTsYpzOWuDGbFlorQdhMN)
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMC.setProperty('inputstream.adaptive.license_type',IqvgKtwEiPTsYpzOWuDGbFlorQdhMj)
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMC.setProperty('inputstream.adaptive.license_key',IqvgKtwEiPTsYpzOWuDGbFlorQdhRx)
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMC.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.USER_AGENT))
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhMX:
   try:
    f=IqvgKtwEiPTsYpzOWuDGbFlorQdheA(IqvgKtwEiPTsYpzOWuDGbFlorQdhxV,'w',-1,'utf-8')
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRy=requests.get(IqvgKtwEiPTsYpzOWuDGbFlorQdhMX)
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRM=IqvgKtwEiPTsYpzOWuDGbFlorQdhRy.content.decode('utf-8') 
    for IqvgKtwEiPTsYpzOWuDGbFlorQdhRm in IqvgKtwEiPTsYpzOWuDGbFlorQdhRM.splitlines():
     IqvgKtwEiPTsYpzOWuDGbFlorQdhRe=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',IqvgKtwEiPTsYpzOWuDGbFlorQdhRm)
     f.write(IqvgKtwEiPTsYpzOWuDGbFlorQdhRe+'\n')
    f.close()
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMC.setSubtitles([IqvgKtwEiPTsYpzOWuDGbFlorQdhxV,IqvgKtwEiPTsYpzOWuDGbFlorQdhMX])
   except:
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMC.setSubtitles([IqvgKtwEiPTsYpzOWuDGbFlorQdhMX])
  xbmcplugin.setResolvedUrl(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_handle,IqvgKtwEiPTsYpzOWuDGbFlorQdhem,IqvgKtwEiPTsYpzOWuDGbFlorQdhMC)
  try:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhyL='movie' if IqvgKtwEiPTsYpzOWuDGbFlorQdhMA=='-' else 'seasons'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya={'code':IqvgKtwEiPTsYpzOWuDGbFlorQdhMa if IqvgKtwEiPTsYpzOWuDGbFlorQdhyL=='movie' else IqvgKtwEiPTsYpzOWuDGbFlorQdhMA,'img':IqvgKtwEiPTsYpzOWuDGbFlorQdhMU,'title':IqvgKtwEiPTsYpzOWuDGbFlorQdhye,'videoid':IqvgKtwEiPTsYpzOWuDGbFlorQdhMa}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.Save_Watched_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhyL,IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
  except:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhey
 def dp_Category_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,args):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.SaveCredential(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_winCredential())
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyL =args.get('stype')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMV =args.get('tag_id')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMe=args.get('api_path')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyN=IqvgKtwEiPTsYpzOWuDGbFlorQdheM(args.get('page'))
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyj =args.get('sort')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhRV,IqvgKtwEiPTsYpzOWuDGbFlorQdhRk=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.GetCategoryList(IqvgKtwEiPTsYpzOWuDGbFlorQdhyL,IqvgKtwEiPTsYpzOWuDGbFlorQdhMV,IqvgKtwEiPTsYpzOWuDGbFlorQdhMe,IqvgKtwEiPTsYpzOWuDGbFlorQdhyN,IqvgKtwEiPTsYpzOWuDGbFlorQdhyj)
  for IqvgKtwEiPTsYpzOWuDGbFlorQdhRa in IqvgKtwEiPTsYpzOWuDGbFlorQdhRV:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMa =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('code')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhye =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('title')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRA =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('content_type')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRU =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('story')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMU =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('thumbnail')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRf =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('year')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRH =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('film_rating_code')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRX=IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('film_rating_short')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRS =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('film_rating_long')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRJ =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('duration')
   if IqvgKtwEiPTsYpzOWuDGbFlorQdhRA=='movies': 
    IqvgKtwEiPTsYpzOWuDGbFlorQdhyA =IqvgKtwEiPTsYpzOWuDGbFlorQdheR
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRC ='MOVIE'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhyU =''
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMA='-'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRc ='movie'
   else: 
    IqvgKtwEiPTsYpzOWuDGbFlorQdhyA =IqvgKtwEiPTsYpzOWuDGbFlorQdhem
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRC ='EPISODE'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhyU ='Series'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMA=IqvgKtwEiPTsYpzOWuDGbFlorQdhMa
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRc ='episode'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRL={'mediatype':IqvgKtwEiPTsYpzOWuDGbFlorQdhRc,'mpaa':IqvgKtwEiPTsYpzOWuDGbFlorQdhRS,'title':IqvgKtwEiPTsYpzOWuDGbFlorQdhye,'year':IqvgKtwEiPTsYpzOWuDGbFlorQdhRf,'duration':IqvgKtwEiPTsYpzOWuDGbFlorQdhRJ,'plot':'%s (%s)\n년도 : %s\n\n%s'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,IqvgKtwEiPTsYpzOWuDGbFlorQdhRX,IqvgKtwEiPTsYpzOWuDGbFlorQdhRf,IqvgKtwEiPTsYpzOWuDGbFlorQdhRU)}
   if IqvgKtwEiPTsYpzOWuDGbFlorQdhRH>=19:
    IqvgKtwEiPTsYpzOWuDGbFlorQdhye+='  (%s년 - %s)'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhRf,IqvgKtwEiPTsYpzOWuDGbFlorQdhea(IqvgKtwEiPTsYpzOWuDGbFlorQdhRX))
   else:
    IqvgKtwEiPTsYpzOWuDGbFlorQdhye+='  (%s년)'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhRf)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya={'mode':IqvgKtwEiPTsYpzOWuDGbFlorQdhRC,'movie_code':IqvgKtwEiPTsYpzOWuDGbFlorQdhMa,'page':'1','season_code':IqvgKtwEiPTsYpzOWuDGbFlorQdhMA,'title':IqvgKtwEiPTsYpzOWuDGbFlorQdhye,'thumbnail':IqvgKtwEiPTsYpzOWuDGbFlorQdhMU}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel=IqvgKtwEiPTsYpzOWuDGbFlorQdhyU,img=IqvgKtwEiPTsYpzOWuDGbFlorQdhMU,infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhRL,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdhyA,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhRk:
   if IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.GetCategoryList_morepage(IqvgKtwEiPTsYpzOWuDGbFlorQdhyL,IqvgKtwEiPTsYpzOWuDGbFlorQdhMV,IqvgKtwEiPTsYpzOWuDGbFlorQdhMe,IqvgKtwEiPTsYpzOWuDGbFlorQdhyN+1,IqvgKtwEiPTsYpzOWuDGbFlorQdhyj):
    IqvgKtwEiPTsYpzOWuDGbFlorQdhya={}
    IqvgKtwEiPTsYpzOWuDGbFlorQdhya['mode'] ='CATEGORY_LIST'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhya['stype'] =IqvgKtwEiPTsYpzOWuDGbFlorQdhyL
    IqvgKtwEiPTsYpzOWuDGbFlorQdhya['tag_id'] =IqvgKtwEiPTsYpzOWuDGbFlorQdhMV
    IqvgKtwEiPTsYpzOWuDGbFlorQdhya['api_path']=IqvgKtwEiPTsYpzOWuDGbFlorQdhMe
    IqvgKtwEiPTsYpzOWuDGbFlorQdhya['page'] =IqvgKtwEiPTsYpzOWuDGbFlorQdhea(IqvgKtwEiPTsYpzOWuDGbFlorQdhyN+1)
    IqvgKtwEiPTsYpzOWuDGbFlorQdhya['sort'] =IqvgKtwEiPTsYpzOWuDGbFlorQdhyj
    IqvgKtwEiPTsYpzOWuDGbFlorQdhye='[B]%s >>[/B]'%'다음 페이지'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMk=IqvgKtwEiPTsYpzOWuDGbFlorQdhea(IqvgKtwEiPTsYpzOWuDGbFlorQdhyN+1)
    IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel=IqvgKtwEiPTsYpzOWuDGbFlorQdhMk,img='',infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhey,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdhem,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdheV(IqvgKtwEiPTsYpzOWuDGbFlorQdhRV)>0:
   if IqvgKtwEiPTsYpzOWuDGbFlorQdhMe=='arrivals/latest':
    xbmcplugin.endOfDirectory(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_handle,cacheToDisc=IqvgKtwEiPTsYpzOWuDGbFlorQdhem)
   else:
    xbmcplugin.endOfDirectory(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_handle,cacheToDisc=IqvgKtwEiPTsYpzOWuDGbFlorQdheR)
 def dp_Episode_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,args):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.SaveCredential(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_winCredential())
  IqvgKtwEiPTsYpzOWuDGbFlorQdhRj=args.get('movie_code')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyN =IqvgKtwEiPTsYpzOWuDGbFlorQdheM(args.get('page'))
  IqvgKtwEiPTsYpzOWuDGbFlorQdhMA =args.get('season_code')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhRV,IqvgKtwEiPTsYpzOWuDGbFlorQdhRk=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.GetEpisodoList(IqvgKtwEiPTsYpzOWuDGbFlorQdhRj,IqvgKtwEiPTsYpzOWuDGbFlorQdhyN,orderby=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_winEpisodeOrderby())
  for IqvgKtwEiPTsYpzOWuDGbFlorQdhRa in IqvgKtwEiPTsYpzOWuDGbFlorQdhRV:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMa =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('code')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhye =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('title')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMU =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('thumbnail')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRn =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('display_num')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRB =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('season_title')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmx=IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('episode_number')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRJ =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('duration')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRL={'mediatype':'episode','tvshowtitle':IqvgKtwEiPTsYpzOWuDGbFlorQdhye if IqvgKtwEiPTsYpzOWuDGbFlorQdhye!='' else IqvgKtwEiPTsYpzOWuDGbFlorQdhRB,'title':'%s %s'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhRB,IqvgKtwEiPTsYpzOWuDGbFlorQdhRn)if IqvgKtwEiPTsYpzOWuDGbFlorQdhye!='' else IqvgKtwEiPTsYpzOWuDGbFlorQdhRn,'episode':IqvgKtwEiPTsYpzOWuDGbFlorQdhmx,'duration':IqvgKtwEiPTsYpzOWuDGbFlorQdhRJ,'plot':'%s\n%s\n\n%s'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhRB,IqvgKtwEiPTsYpzOWuDGbFlorQdhRn,IqvgKtwEiPTsYpzOWuDGbFlorQdhye)}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhye='(%s) %s'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhRn,IqvgKtwEiPTsYpzOWuDGbFlorQdhye)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya={'mode':'MOVIE','movie_code':IqvgKtwEiPTsYpzOWuDGbFlorQdhMa,'season_code':IqvgKtwEiPTsYpzOWuDGbFlorQdhMA,'title':'%s < %s >'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,IqvgKtwEiPTsYpzOWuDGbFlorQdhRB),'thumbnail':IqvgKtwEiPTsYpzOWuDGbFlorQdhMU}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel=IqvgKtwEiPTsYpzOWuDGbFlorQdhRB,img=IqvgKtwEiPTsYpzOWuDGbFlorQdhMU,infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhRL,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdheR,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhyN==1:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRL={'plot':'정렬순서를 변경합니다.'}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya={}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['mode'] ='ORDER_BY' 
   if IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_winEpisodeOrderby()=='desc':
    IqvgKtwEiPTsYpzOWuDGbFlorQdhye='정렬순서변경 : 최신화부터 -> 1회부터'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhya['orderby']='asc'
   else:
    IqvgKtwEiPTsYpzOWuDGbFlorQdhye='정렬순서변경 : 1회부터 -> 최신화부터'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhya['orderby']='desc'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel='',img='',infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhRL,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdheR,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhRk:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['mode'] ='EPISODE' 
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['movie_code']=IqvgKtwEiPTsYpzOWuDGbFlorQdhRj
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['page'] =IqvgKtwEiPTsYpzOWuDGbFlorQdhea(IqvgKtwEiPTsYpzOWuDGbFlorQdhyN+1)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhye='[B]%s >>[/B]'%'다음 페이지'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMk=IqvgKtwEiPTsYpzOWuDGbFlorQdhea(IqvgKtwEiPTsYpzOWuDGbFlorQdhyN+1)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel=IqvgKtwEiPTsYpzOWuDGbFlorQdhMk,img='',infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhey,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdhem,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdheV(IqvgKtwEiPTsYpzOWuDGbFlorQdhRV)>0:xbmcplugin.endOfDirectory(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_handle,cacheToDisc=IqvgKtwEiPTsYpzOWuDGbFlorQdhem)
 def dp_Search_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,args):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.SaveCredential(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_winCredential())
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyN =IqvgKtwEiPTsYpzOWuDGbFlorQdheM(args.get('page'))
  if 'search_key' in args:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmy=args.get('search_key')
  else:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmy=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not IqvgKtwEiPTsYpzOWuDGbFlorQdhmy:return
  IqvgKtwEiPTsYpzOWuDGbFlorQdhRV,IqvgKtwEiPTsYpzOWuDGbFlorQdhRk=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.GetSearchList(IqvgKtwEiPTsYpzOWuDGbFlorQdhmy,IqvgKtwEiPTsYpzOWuDGbFlorQdhyN)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdheV(IqvgKtwEiPTsYpzOWuDGbFlorQdhRV)==0:return
  for IqvgKtwEiPTsYpzOWuDGbFlorQdhRa in IqvgKtwEiPTsYpzOWuDGbFlorQdhRV:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMa =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('code')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhye =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('title')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRA=IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('content_type')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRU =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('story')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMU =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('thumbnail')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRf =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('year')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRH =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('film_rating_code')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRX=IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('film_rating_short')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRS =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('film_rating_long')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRJ =IqvgKtwEiPTsYpzOWuDGbFlorQdhRa.get('duration')
   if IqvgKtwEiPTsYpzOWuDGbFlorQdhRA=='movies': 
    IqvgKtwEiPTsYpzOWuDGbFlorQdhyA =IqvgKtwEiPTsYpzOWuDGbFlorQdheR
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRC ='MOVIE'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhyU =''
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMA='-'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRc ='movie'
   else: 
    IqvgKtwEiPTsYpzOWuDGbFlorQdhyA =IqvgKtwEiPTsYpzOWuDGbFlorQdhem
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRC ='EPISODE'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhyU ='Series'
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMA=IqvgKtwEiPTsYpzOWuDGbFlorQdhMa
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRc ='episode'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRL={'mediatype':IqvgKtwEiPTsYpzOWuDGbFlorQdhRc,'mpaa':IqvgKtwEiPTsYpzOWuDGbFlorQdhRS,'title':IqvgKtwEiPTsYpzOWuDGbFlorQdhye,'year':IqvgKtwEiPTsYpzOWuDGbFlorQdhRf,'duration':IqvgKtwEiPTsYpzOWuDGbFlorQdhRJ,'plot':'%s (%s)\n년도 : %s\n\n%s'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,IqvgKtwEiPTsYpzOWuDGbFlorQdhRX,IqvgKtwEiPTsYpzOWuDGbFlorQdhRf,IqvgKtwEiPTsYpzOWuDGbFlorQdhRU)}
   if IqvgKtwEiPTsYpzOWuDGbFlorQdhRH>=19:
    IqvgKtwEiPTsYpzOWuDGbFlorQdhye+='  (%s년 - %s)'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhRf,IqvgKtwEiPTsYpzOWuDGbFlorQdhea(IqvgKtwEiPTsYpzOWuDGbFlorQdhRX))
   else:
    IqvgKtwEiPTsYpzOWuDGbFlorQdhye+='  (%s년)'%(IqvgKtwEiPTsYpzOWuDGbFlorQdhRf)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya={'mode':IqvgKtwEiPTsYpzOWuDGbFlorQdhRC,'movie_code':IqvgKtwEiPTsYpzOWuDGbFlorQdhMa,'page':'1','season_code':IqvgKtwEiPTsYpzOWuDGbFlorQdhMA,'title':IqvgKtwEiPTsYpzOWuDGbFlorQdhye,'thumbnail':IqvgKtwEiPTsYpzOWuDGbFlorQdhMU}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel=IqvgKtwEiPTsYpzOWuDGbFlorQdhyU,img=IqvgKtwEiPTsYpzOWuDGbFlorQdhMU,infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhRL,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdhyA,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhRk:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya={}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['mode'] ='SEARCH'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['search_key']=IqvgKtwEiPTsYpzOWuDGbFlorQdhmy
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya['page'] =IqvgKtwEiPTsYpzOWuDGbFlorQdhea(IqvgKtwEiPTsYpzOWuDGbFlorQdhyN+1)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhye='[B]%s >>[/B]'%'다음 페이지'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhMk=IqvgKtwEiPTsYpzOWuDGbFlorQdhea(IqvgKtwEiPTsYpzOWuDGbFlorQdhyN+1)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel=IqvgKtwEiPTsYpzOWuDGbFlorQdhMk,img='',infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhey,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdhem,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdheV(IqvgKtwEiPTsYpzOWuDGbFlorQdhRV)>0:xbmcplugin.endOfDirectory(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_handle)
 def Delete_Watched_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,IqvgKtwEiPTsYpzOWuDGbFlorQdhyL):
  try:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IqvgKtwEiPTsYpzOWuDGbFlorQdhyL))
   fp=IqvgKtwEiPTsYpzOWuDGbFlorQdheA(IqvgKtwEiPTsYpzOWuDGbFlorQdhmM,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhey
 def dp_WatchList_Delete(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,args):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyL=args.get('stype')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxX=xbmcgui.Dialog()
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyS=IqvgKtwEiPTsYpzOWuDGbFlorQdhxX.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhyS==IqvgKtwEiPTsYpzOWuDGbFlorQdheR:sys.exit()
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.Delete_Watched_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhyL)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,IqvgKtwEiPTsYpzOWuDGbFlorQdhyL):
  try:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IqvgKtwEiPTsYpzOWuDGbFlorQdhyL))
   fp=IqvgKtwEiPTsYpzOWuDGbFlorQdheA(IqvgKtwEiPTsYpzOWuDGbFlorQdhmM,'r',-1,'utf-8')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmR=fp.readlines()
   fp.close()
  except:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmR=[]
  return IqvgKtwEiPTsYpzOWuDGbFlorQdhmR
 def Save_Watched_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,IqvgKtwEiPTsYpzOWuDGbFlorQdhyL,IqvgKtwEiPTsYpzOWuDGbFlorQdhxf):
  try:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IqvgKtwEiPTsYpzOWuDGbFlorQdhyL))
   IqvgKtwEiPTsYpzOWuDGbFlorQdhme=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.Load_Watched_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhyL) 
   fp=IqvgKtwEiPTsYpzOWuDGbFlorQdheA(IqvgKtwEiPTsYpzOWuDGbFlorQdhmM,'w',-1,'utf-8')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmV=urllib.parse.urlencode(IqvgKtwEiPTsYpzOWuDGbFlorQdhxf)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmV=IqvgKtwEiPTsYpzOWuDGbFlorQdhmV+'\n'
   fp.write(IqvgKtwEiPTsYpzOWuDGbFlorQdhmV)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmk=0
   for IqvgKtwEiPTsYpzOWuDGbFlorQdhma in IqvgKtwEiPTsYpzOWuDGbFlorQdhme:
    IqvgKtwEiPTsYpzOWuDGbFlorQdhmA=IqvgKtwEiPTsYpzOWuDGbFlorQdheU(urllib.parse.parse_qsl(IqvgKtwEiPTsYpzOWuDGbFlorQdhma))
    IqvgKtwEiPTsYpzOWuDGbFlorQdhmU=IqvgKtwEiPTsYpzOWuDGbFlorQdhxf.get('code').strip()
    IqvgKtwEiPTsYpzOWuDGbFlorQdhmf=IqvgKtwEiPTsYpzOWuDGbFlorQdhmA.get('code').strip()
    if IqvgKtwEiPTsYpzOWuDGbFlorQdhyL=='seasons' and IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_settings_direct_replay()==IqvgKtwEiPTsYpzOWuDGbFlorQdhem:
     IqvgKtwEiPTsYpzOWuDGbFlorQdhmU=IqvgKtwEiPTsYpzOWuDGbFlorQdhxf.get('videoid').strip()
     IqvgKtwEiPTsYpzOWuDGbFlorQdhmf=IqvgKtwEiPTsYpzOWuDGbFlorQdhmA.get('videoid').strip()if IqvgKtwEiPTsYpzOWuDGbFlorQdhmf!=IqvgKtwEiPTsYpzOWuDGbFlorQdhey else '-'
    if IqvgKtwEiPTsYpzOWuDGbFlorQdhmU!=IqvgKtwEiPTsYpzOWuDGbFlorQdhmf:
     fp.write(IqvgKtwEiPTsYpzOWuDGbFlorQdhma)
     IqvgKtwEiPTsYpzOWuDGbFlorQdhmk+=1
     if IqvgKtwEiPTsYpzOWuDGbFlorQdhmk>=50:break
   fp.close()
  except:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhey
 def dp_Watch_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa,args):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyL =args.get('stype')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxB=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.get_settings_direct_replay()
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhyL=='-':
   for IqvgKtwEiPTsYpzOWuDGbFlorQdhmH in IqvgKtwEiPTsYpzOWuDGbFlorQdhxR:
    IqvgKtwEiPTsYpzOWuDGbFlorQdhye=IqvgKtwEiPTsYpzOWuDGbFlorQdhmH.get('title')
    IqvgKtwEiPTsYpzOWuDGbFlorQdhya={'mode':IqvgKtwEiPTsYpzOWuDGbFlorQdhmH.get('mode'),'stype':IqvgKtwEiPTsYpzOWuDGbFlorQdhmH.get('stype')}
    IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel='',img='',infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhey,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdhem,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
   if IqvgKtwEiPTsYpzOWuDGbFlorQdheV(IqvgKtwEiPTsYpzOWuDGbFlorQdhxR)>0:xbmcplugin.endOfDirectory(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_handle)
  else:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmX=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.Load_Watched_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhyL)
   for IqvgKtwEiPTsYpzOWuDGbFlorQdhmS in IqvgKtwEiPTsYpzOWuDGbFlorQdhmX:
    IqvgKtwEiPTsYpzOWuDGbFlorQdhmJ=IqvgKtwEiPTsYpzOWuDGbFlorQdheU(urllib.parse.parse_qsl(IqvgKtwEiPTsYpzOWuDGbFlorQdhmS))
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMa=IqvgKtwEiPTsYpzOWuDGbFlorQdhmJ.get('code').strip()
    IqvgKtwEiPTsYpzOWuDGbFlorQdhye =IqvgKtwEiPTsYpzOWuDGbFlorQdhmJ.get('title').strip()
    IqvgKtwEiPTsYpzOWuDGbFlorQdhMU =IqvgKtwEiPTsYpzOWuDGbFlorQdhmJ.get('img').strip()
    IqvgKtwEiPTsYpzOWuDGbFlorQdhmC =IqvgKtwEiPTsYpzOWuDGbFlorQdhmJ.get('videoid').strip()
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRL={}
    IqvgKtwEiPTsYpzOWuDGbFlorQdhRL['plot']=IqvgKtwEiPTsYpzOWuDGbFlorQdhye
    if IqvgKtwEiPTsYpzOWuDGbFlorQdhyL=='movie':
     IqvgKtwEiPTsYpzOWuDGbFlorQdhya={'mode':'MOVIE','page':'1','movie_code':IqvgKtwEiPTsYpzOWuDGbFlorQdhMa,'season_code':'-','title':IqvgKtwEiPTsYpzOWuDGbFlorQdhye,'thumbnail':IqvgKtwEiPTsYpzOWuDGbFlorQdhMU}
     IqvgKtwEiPTsYpzOWuDGbFlorQdhyA=IqvgKtwEiPTsYpzOWuDGbFlorQdheR
    else:
     if IqvgKtwEiPTsYpzOWuDGbFlorQdhxB==IqvgKtwEiPTsYpzOWuDGbFlorQdheR or IqvgKtwEiPTsYpzOWuDGbFlorQdhmC==IqvgKtwEiPTsYpzOWuDGbFlorQdhey:
      IqvgKtwEiPTsYpzOWuDGbFlorQdhya={'mode':'EPISODE','page':'1','movie_code':IqvgKtwEiPTsYpzOWuDGbFlorQdhMa,'season_code':IqvgKtwEiPTsYpzOWuDGbFlorQdhMa,'title':IqvgKtwEiPTsYpzOWuDGbFlorQdhye,'thumbnail':IqvgKtwEiPTsYpzOWuDGbFlorQdhMU}
      IqvgKtwEiPTsYpzOWuDGbFlorQdhyA=IqvgKtwEiPTsYpzOWuDGbFlorQdhem
     else:
      IqvgKtwEiPTsYpzOWuDGbFlorQdhya={'mode':'MOVIE','movie_code':IqvgKtwEiPTsYpzOWuDGbFlorQdhmC,'season_code':IqvgKtwEiPTsYpzOWuDGbFlorQdhMa,'title':IqvgKtwEiPTsYpzOWuDGbFlorQdhye,'thumbnail':IqvgKtwEiPTsYpzOWuDGbFlorQdhMU}
      IqvgKtwEiPTsYpzOWuDGbFlorQdhyA=IqvgKtwEiPTsYpzOWuDGbFlorQdheR
    IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel='',img=IqvgKtwEiPTsYpzOWuDGbFlorQdhMU,infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhRL,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdhyA,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
   IqvgKtwEiPTsYpzOWuDGbFlorQdhRL={'plot':'시청목록을 삭제합니다.'}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhye='*** 시청목록 삭제 ***'
   IqvgKtwEiPTsYpzOWuDGbFlorQdhya={'mode':'MYVIEW_REMOVE','stype':IqvgKtwEiPTsYpzOWuDGbFlorQdhyL}
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.add_dir(IqvgKtwEiPTsYpzOWuDGbFlorQdhye,sublabel='',img='',infoLabels=IqvgKtwEiPTsYpzOWuDGbFlorQdhRL,isFolder=IqvgKtwEiPTsYpzOWuDGbFlorQdheR,params=IqvgKtwEiPTsYpzOWuDGbFlorQdhya)
   xbmcplugin.endOfDirectory(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa._addon_handle,cacheToDisc=IqvgKtwEiPTsYpzOWuDGbFlorQdheR)
 def logout(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxX=xbmcgui.Dialog()
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyS=IqvgKtwEiPTsYpzOWuDGbFlorQdhxX.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhyS==IqvgKtwEiPTsYpzOWuDGbFlorQdheR:sys.exit()
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.wininfo_clear()
  if os.path.isfile(IqvgKtwEiPTsYpzOWuDGbFlorQdhxk):os.remove(IqvgKtwEiPTsYpzOWuDGbFlorQdhxk)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx=xbmcgui.Window(10000)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_TOKEN','')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_GUIT','')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_GUITV','')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_USERCD','')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhmc =IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.Get_Now_Datetime()
  IqvgKtwEiPTsYpzOWuDGbFlorQdhmL=IqvgKtwEiPTsYpzOWuDGbFlorQdhmc+datetime.timedelta(days=IqvgKtwEiPTsYpzOWuDGbFlorQdheM(__addon__.getSetting('cache_ttl')))
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx=xbmcgui.Window(10000)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhmN={'watcha_token':IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.getProperty('WATCHA_M_TOKEN'),'watcha_guit':IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.getProperty('WATCHA_M_GUIT'),'watcha_guitv':IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.getProperty('WATCHA_M_GUITV'),'watcha_usercd':IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':IqvgKtwEiPTsYpzOWuDGbFlorQdhmL.strftime('%Y-%m-%d')}
  try: 
   fp=IqvgKtwEiPTsYpzOWuDGbFlorQdheA(IqvgKtwEiPTsYpzOWuDGbFlorQdhxk,'w',-1,'utf-8')
   json.dump(IqvgKtwEiPTsYpzOWuDGbFlorQdhmN,fp)
   fp.close()
  except IqvgKtwEiPTsYpzOWuDGbFlorQdhef as exception:
   IqvgKtwEiPTsYpzOWuDGbFlorQdheH(exception)
 def cookiefile_check(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhmN={}
  try: 
   fp=IqvgKtwEiPTsYpzOWuDGbFlorQdheA(IqvgKtwEiPTsYpzOWuDGbFlorQdhxk,'r',-1,'utf-8')
   IqvgKtwEiPTsYpzOWuDGbFlorQdhmN= json.load(fp)
   fp.close()
  except IqvgKtwEiPTsYpzOWuDGbFlorQdhef as exception:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.wininfo_clear()
   return IqvgKtwEiPTsYpzOWuDGbFlorQdheR
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyf =__addon__.getSetting('id')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyH =__addon__.getSetting('pw')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhmj =__addon__.getSetting('selected_profile')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_id']=base64.standard_b64decode(IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_id']).decode('utf-8')
  IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_pw']=base64.standard_b64decode(IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_pw']).decode('utf-8')
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhyf!=IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_id']or IqvgKtwEiPTsYpzOWuDGbFlorQdhyH!=IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_pw']or IqvgKtwEiPTsYpzOWuDGbFlorQdhmj!=IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_profile']:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.wininfo_clear()
   return IqvgKtwEiPTsYpzOWuDGbFlorQdheR
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyJ =IqvgKtwEiPTsYpzOWuDGbFlorQdheM(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  IqvgKtwEiPTsYpzOWuDGbFlorQdhmn=IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_limitdate']
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyC =IqvgKtwEiPTsYpzOWuDGbFlorQdheM(re.sub('-','',IqvgKtwEiPTsYpzOWuDGbFlorQdhmn))
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhyC<IqvgKtwEiPTsYpzOWuDGbFlorQdhyJ:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.wininfo_clear()
   return IqvgKtwEiPTsYpzOWuDGbFlorQdheR
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx=xbmcgui.Window(10000)
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_TOKEN',IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_token'])
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_GUIT',IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_guit'])
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_GUITV',IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_guitv'])
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_USERCD',IqvgKtwEiPTsYpzOWuDGbFlorQdhmN['watcha_usercd'])
  IqvgKtwEiPTsYpzOWuDGbFlorQdhyx.setProperty('WATCHA_M_LOGINTIME',IqvgKtwEiPTsYpzOWuDGbFlorQdhmn)
  return IqvgKtwEiPTsYpzOWuDGbFlorQdhem
 def watcha_main(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa):
  IqvgKtwEiPTsYpzOWuDGbFlorQdhmB=IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.main_params.get('mode',IqvgKtwEiPTsYpzOWuDGbFlorQdhey)
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhmB=='LOGOUT':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.logout()
   return
  IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.login_main()
  if IqvgKtwEiPTsYpzOWuDGbFlorQdhmB is IqvgKtwEiPTsYpzOWuDGbFlorQdhey:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.dp_Main_List()
  elif IqvgKtwEiPTsYpzOWuDGbFlorQdhmB=='SUB_GROUP':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.dp_SubGroup_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.main_params)
  elif IqvgKtwEiPTsYpzOWuDGbFlorQdhmB=='CATEGORY_LIST':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.dp_Category_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.main_params)
  elif IqvgKtwEiPTsYpzOWuDGbFlorQdhmB=='EPISODE':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.dp_Episode_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.main_params)
  elif IqvgKtwEiPTsYpzOWuDGbFlorQdhmB=='ORDER_BY':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.dp_setEpOrderby(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.main_params)
  elif IqvgKtwEiPTsYpzOWuDGbFlorQdhmB=='SEARCH':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.dp_Search_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.main_params)
  elif IqvgKtwEiPTsYpzOWuDGbFlorQdhmB=='MOVIE':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.play_VIDEO(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.main_params)
  elif IqvgKtwEiPTsYpzOWuDGbFlorQdhmB=='WATCH':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.dp_Watch_List(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.main_params)
  elif IqvgKtwEiPTsYpzOWuDGbFlorQdhmB=='MYVIEW_REMOVE':
   IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.dp_WatchList_Delete(IqvgKtwEiPTsYpzOWuDGbFlorQdhxa.main_params)
  else:
   IqvgKtwEiPTsYpzOWuDGbFlorQdhey
# Created by pyminifier (https://github.com/liftoff/pyminifier)
