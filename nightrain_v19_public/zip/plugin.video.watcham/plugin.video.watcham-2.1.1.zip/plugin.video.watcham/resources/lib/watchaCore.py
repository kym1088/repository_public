__author__="NightRain"
zgXkQDRhJFGHfnAcVwyqUTEBOstKdW=object
zgXkQDRhJFGHfnAcVwyqUTEBOstKdI=None
zgXkQDRhJFGHfnAcVwyqUTEBOstKdo=False
zgXkQDRhJFGHfnAcVwyqUTEBOstKdm=True
zgXkQDRhJFGHfnAcVwyqUTEBOstKdL=Exception
zgXkQDRhJFGHfnAcVwyqUTEBOstKdu=print
zgXkQDRhJFGHfnAcVwyqUTEBOstKdv=str
zgXkQDRhJFGHfnAcVwyqUTEBOstKdr=len
zgXkQDRhJFGHfnAcVwyqUTEBOstKdS=int
zgXkQDRhJFGHfnAcVwyqUTEBOstKdb=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import base64
import requests
import datetime
class zgXkQDRhJFGHfnAcVwyqUTEBOstKYW(zgXkQDRhJFGHfnAcVwyqUTEBOstKdW):
 def __init__(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_TOKEN ='' 
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUIT =''
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUITV =''
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_USERCD=''
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.API_DOMAIN ='https://api-mars.watcha.com'
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.EPISODE_LIMIT=20
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.SEARCH_LIMIT =30
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.DEFAULT_HEADER={'user-agent':zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,jobtype,zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,payload=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,params=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,cookies=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,redirects=zgXkQDRhJFGHfnAcVwyqUTEBOstKdo):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYd=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.DEFAULT_HEADER
  if headers:zgXkQDRhJFGHfnAcVwyqUTEBOstKYd.update(headers)
  if jobtype=='Get':
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYo=requests.get(zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,params=params,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKYd,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYo=requests.put(zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,data=payload,params=params,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKYd,cookies=cookies,allow_redirects=redirects)
  else:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYo=requests.post(zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,data=payload,params=params,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKYd,cookies=cookies,allow_redirects=redirects)
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKYo
 def SaveCredential(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,zgXkQDRhJFGHfnAcVwyqUTEBOstKYm):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_TOKEN =zgXkQDRhJFGHfnAcVwyqUTEBOstKYm.get('watcha_token')
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUIT =zgXkQDRhJFGHfnAcVwyqUTEBOstKYm.get('watcha_guit')
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUITV =zgXkQDRhJFGHfnAcVwyqUTEBOstKYm.get('watcha_guitv')
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_USERCD =zgXkQDRhJFGHfnAcVwyqUTEBOstKYm.get('watcha_usercd')
 def SaveCredential_usercd(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,zgXkQDRhJFGHfnAcVwyqUTEBOstKYL):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_USERCD=zgXkQDRhJFGHfnAcVwyqUTEBOstKYL
 def SaveCredential_guitv(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,zgXkQDRhJFGHfnAcVwyqUTEBOstKYu,zgXkQDRhJFGHfnAcVwyqUTEBOstKYv):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUITV=zgXkQDRhJFGHfnAcVwyqUTEBOstKYu
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_TOKEN=zgXkQDRhJFGHfnAcVwyqUTEBOstKYv 
 def ClearCredential(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_TOKEN ='' 
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUIT =''
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUITV =''
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_USERCD=''
 def LoadCredential(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYm={'watcha_token':zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_TOKEN,'watcha_guit':zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUIT,'watcha_guitv':zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUITV,'watcha_usercd':zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_USERCD}
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKYm
 def makeDefaultCookies(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYr={'_s_guit':zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUIT,'_guinness-premium_session':zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_TOKEN}
  if zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUITV:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYr['_s_guitv']=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_GUITV
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKYr
 def makeurl(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,domain,path,query1=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,query2=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYS=domain+path
  if query1:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYS+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYS+='&%s'%urllib.parse.urlencode(query2)
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKYS
 def GetCredential(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,user_id,user_pw,user_pf):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYN=zgXkQDRhJFGHfnAcVwyqUTEBOstKdo
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYx=zgXkQDRhJFGHfnAcVwyqUTEBOstKYP='-'
  try:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYC=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.API_DOMAIN+'/api/session'
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYM={'email':user_id,'password':user_pw}
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYi={'accept':'application/vnd.frograms+json;version=4'}
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYl=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.callRequestCookies('Post',zgXkQDRhJFGHfnAcVwyqUTEBOstKYC,payload=zgXkQDRhJFGHfnAcVwyqUTEBOstKYM,params=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKYi,cookies=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI)
   for zgXkQDRhJFGHfnAcVwyqUTEBOstKYp in zgXkQDRhJFGHfnAcVwyqUTEBOstKYl.cookies:
    if zgXkQDRhJFGHfnAcVwyqUTEBOstKYp.name=='_guinness-premium_session':
     zgXkQDRhJFGHfnAcVwyqUTEBOstKYP=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp.value
    elif zgXkQDRhJFGHfnAcVwyqUTEBOstKYp.name=='_s_guit':
     zgXkQDRhJFGHfnAcVwyqUTEBOstKYx=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp.value
   if zgXkQDRhJFGHfnAcVwyqUTEBOstKYP:zgXkQDRhJFGHfnAcVwyqUTEBOstKYN=zgXkQDRhJFGHfnAcVwyqUTEBOstKdm
  except zgXkQDRhJFGHfnAcVwyqUTEBOstKdL as exception:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKdu(exception)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYx=zgXkQDRhJFGHfnAcVwyqUTEBOstKYP='' 
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYm={'watcha_guit':zgXkQDRhJFGHfnAcVwyqUTEBOstKYx,'watcha_token':zgXkQDRhJFGHfnAcVwyqUTEBOstKYP,'watcha_guitv':'','watcha_usercd':''}
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.SaveCredential(zgXkQDRhJFGHfnAcVwyqUTEBOstKYm)
  try:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYj=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.GetProfilesList()
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYa =zgXkQDRhJFGHfnAcVwyqUTEBOstKYj[user_pf]
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.SaveCredential_usercd(zgXkQDRhJFGHfnAcVwyqUTEBOstKYa)
  except zgXkQDRhJFGHfnAcVwyqUTEBOstKdL as exception:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKdu(exception)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.ClearCredential()
   return zgXkQDRhJFGHfnAcVwyqUTEBOstKdo
  if user_pf!=0:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYu,zgXkQDRhJFGHfnAcVwyqUTEBOstKYv=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.GetProfilesConvert(zgXkQDRhJFGHfnAcVwyqUTEBOstKYa)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.SaveCredential_guitv(zgXkQDRhJFGHfnAcVwyqUTEBOstKYu,zgXkQDRhJFGHfnAcVwyqUTEBOstKYv)
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKYN
 def GetSubGroupList(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,stype):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKWY=[]
  try:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWI ='/api/categories.json'
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYS=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeurl(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.API_DOMAIN,zgXkQDRhJFGHfnAcVwyqUTEBOstKWI)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYp=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeDefaultCookies()
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYl=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.callRequestCookies('Get',zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,payload=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,params=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,cookies=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWd=json.loads(zgXkQDRhJFGHfnAcVwyqUTEBOstKYl.text)
   if not('genres' in zgXkQDRhJFGHfnAcVwyqUTEBOstKWd):return zgXkQDRhJFGHfnAcVwyqUTEBOstKWY
   if stype=='genres':
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWo=zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['genres']
   else:
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWo=zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['tags']
   for zgXkQDRhJFGHfnAcVwyqUTEBOstKWm in zgXkQDRhJFGHfnAcVwyqUTEBOstKWo:
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWL=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['name']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWu =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['api_path']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWv =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['entity']['id']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWr={'group_name':zgXkQDRhJFGHfnAcVwyqUTEBOstKWL,'api_path':zgXkQDRhJFGHfnAcVwyqUTEBOstKWu,'tag_id':zgXkQDRhJFGHfnAcVwyqUTEBOstKdv(zgXkQDRhJFGHfnAcVwyqUTEBOstKWv)}
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWY.append(zgXkQDRhJFGHfnAcVwyqUTEBOstKWr)
  except zgXkQDRhJFGHfnAcVwyqUTEBOstKdL as exception:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKdu(exception)
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKWY
 def GetCategoryList(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,stype,zgXkQDRhJFGHfnAcVwyqUTEBOstKWv,zgXkQDRhJFGHfnAcVwyqUTEBOstKWu,page_int,in_sort):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKWY=[]
  zgXkQDRhJFGHfnAcVwyqUTEBOstKWS=zgXkQDRhJFGHfnAcVwyqUTEBOstKdo
  zgXkQDRhJFGHfnAcVwyqUTEBOstKWb={}
  try:
   if 'categories' in zgXkQDRhJFGHfnAcVwyqUTEBOstKWu:
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWI ='/api/categories/contents.json'
    if stype=='genres':
     zgXkQDRhJFGHfnAcVwyqUTEBOstKWb['genre']=zgXkQDRhJFGHfnAcVwyqUTEBOstKWv
    else:
     zgXkQDRhJFGHfnAcVwyqUTEBOstKWb['tag'] =zgXkQDRhJFGHfnAcVwyqUTEBOstKWv
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWb['order']=in_sort 
    if page_int>1:
     zgXkQDRhJFGHfnAcVwyqUTEBOstKWb['page']=zgXkQDRhJFGHfnAcVwyqUTEBOstKdv(page_int-1)
   else: 
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWI ='/api/'+zgXkQDRhJFGHfnAcVwyqUTEBOstKWu+'.json'
    if page_int>1:
     zgXkQDRhJFGHfnAcVwyqUTEBOstKWb['page']=zgXkQDRhJFGHfnAcVwyqUTEBOstKdv(page_int)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYS=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeurl(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.API_DOMAIN,zgXkQDRhJFGHfnAcVwyqUTEBOstKWI)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYp=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeDefaultCookies()
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYl=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.callRequestCookies('Get',zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,payload=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,params=zgXkQDRhJFGHfnAcVwyqUTEBOstKWb,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,cookies=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWd=json.loads(zgXkQDRhJFGHfnAcVwyqUTEBOstKYl.text)
   if not('contents' in zgXkQDRhJFGHfnAcVwyqUTEBOstKWd):return zgXkQDRhJFGHfnAcVwyqUTEBOstKWY,zgXkQDRhJFGHfnAcVwyqUTEBOstKWS
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWo=zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['contents']
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWS=zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['meta']['has_next']
   for zgXkQDRhJFGHfnAcVwyqUTEBOstKWm in zgXkQDRhJFGHfnAcVwyqUTEBOstKWo:
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWe =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['code']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWN=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['content_type']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWx =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['title']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWC =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['story']
    if zgXkQDRhJFGHfnAcVwyqUTEBOstKWm.get('poster') !=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI:zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['poster']['medium']
    elif zgXkQDRhJFGHfnAcVwyqUTEBOstKWm.get('thumbnail')!=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI:zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['thumbnail']['medium']
    elif zgXkQDRhJFGHfnAcVwyqUTEBOstKWm.get('stillcut')!=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI:zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['stillcut']['medium']
    else: zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=''
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWi =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['year']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWl =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['film_rating_code']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWp=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['film_rating_short']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWP =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['film_rating_long']
    if zgXkQDRhJFGHfnAcVwyqUTEBOstKWN=='movies':
     zgXkQDRhJFGHfnAcVwyqUTEBOstKWj =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['duration']
    else:
     zgXkQDRhJFGHfnAcVwyqUTEBOstKWj ='0'
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWr={'code':zgXkQDRhJFGHfnAcVwyqUTEBOstKWe,'content_type':zgXkQDRhJFGHfnAcVwyqUTEBOstKWN,'title':zgXkQDRhJFGHfnAcVwyqUTEBOstKWx,'story':zgXkQDRhJFGHfnAcVwyqUTEBOstKWC,'thumbnail':zgXkQDRhJFGHfnAcVwyqUTEBOstKWM,'year':zgXkQDRhJFGHfnAcVwyqUTEBOstKWi,'film_rating_code':zgXkQDRhJFGHfnAcVwyqUTEBOstKWl,'film_rating_short':zgXkQDRhJFGHfnAcVwyqUTEBOstKWp,'film_rating_long':zgXkQDRhJFGHfnAcVwyqUTEBOstKWP,'duration':zgXkQDRhJFGHfnAcVwyqUTEBOstKWj}
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWY.append(zgXkQDRhJFGHfnAcVwyqUTEBOstKWr)
  except zgXkQDRhJFGHfnAcVwyqUTEBOstKdL as exception:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKdu(exception)
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKWY,zgXkQDRhJFGHfnAcVwyqUTEBOstKWS
 def GetCategoryList_morepage(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,stype,zgXkQDRhJFGHfnAcVwyqUTEBOstKWv,zgXkQDRhJFGHfnAcVwyqUTEBOstKWu,page_int,in_sort):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKWS=zgXkQDRhJFGHfnAcVwyqUTEBOstKdo
  if not('categories' in zgXkQDRhJFGHfnAcVwyqUTEBOstKWu):return zgXkQDRhJFGHfnAcVwyqUTEBOstKdm
  try:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWI ='/api/categories/contents.json'
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWb={}
   if stype=='genres':
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWb['genre']=zgXkQDRhJFGHfnAcVwyqUTEBOstKWv
   else:
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWb['tag'] =zgXkQDRhJFGHfnAcVwyqUTEBOstKWv
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWb['order']=in_sort 
   if page_int>1:
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWb['page']=zgXkQDRhJFGHfnAcVwyqUTEBOstKdv(page_int-1)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYS=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeurl(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.API_DOMAIN,zgXkQDRhJFGHfnAcVwyqUTEBOstKWI)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYp=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeDefaultCookies()
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYl=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.callRequestCookies('Get',zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,payload=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,params=zgXkQDRhJFGHfnAcVwyqUTEBOstKWb,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,cookies=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWd=json.loads(zgXkQDRhJFGHfnAcVwyqUTEBOstKYl.text)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWS=zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['meta']['has_next']
  except zgXkQDRhJFGHfnAcVwyqUTEBOstKdL as exception:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKdu(exception)
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKWS
 def GetEpisodoList(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,program_code,page_int,orderby='asc'):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKWY=[]
  zgXkQDRhJFGHfnAcVwyqUTEBOstKWS=zgXkQDRhJFGHfnAcVwyqUTEBOstKdo
  zgXkQDRhJFGHfnAcVwyqUTEBOstKWa=''
  try:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWI ='/api/contents/'+program_code+'/tv_episodes.json'
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWb={'all':'true'}
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYS=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeurl(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.API_DOMAIN,zgXkQDRhJFGHfnAcVwyqUTEBOstKWI)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYp=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeDefaultCookies()
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYl=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.callRequestCookies('Get',zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,payload=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,params=zgXkQDRhJFGHfnAcVwyqUTEBOstKWb,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,cookies=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWd=json.loads(zgXkQDRhJFGHfnAcVwyqUTEBOstKYl.text)
   if not('tv_episode_codes' in zgXkQDRhJFGHfnAcVwyqUTEBOstKWd):return zgXkQDRhJFGHfnAcVwyqUTEBOstKWY,zgXkQDRhJFGHfnAcVwyqUTEBOstKWS
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWo=zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['tv_episode_codes']
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIY=zgXkQDRhJFGHfnAcVwyqUTEBOstKdr(zgXkQDRhJFGHfnAcVwyqUTEBOstKWo)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIW =zgXkQDRhJFGHfnAcVwyqUTEBOstKdS(zgXkQDRhJFGHfnAcVwyqUTEBOstKIY//(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    zgXkQDRhJFGHfnAcVwyqUTEBOstKId =(zgXkQDRhJFGHfnAcVwyqUTEBOstKIY-1)-((page_int-1)*zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.EPISODE_LIMIT)
   else:
    zgXkQDRhJFGHfnAcVwyqUTEBOstKId =(page_int-1)*zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.EPISODE_LIMIT
   for i in zgXkQDRhJFGHfnAcVwyqUTEBOstKdb(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.EPISODE_LIMIT):
    if orderby=='desc':
     zgXkQDRhJFGHfnAcVwyqUTEBOstKIo=zgXkQDRhJFGHfnAcVwyqUTEBOstKId-i
     if zgXkQDRhJFGHfnAcVwyqUTEBOstKIo<0:break
    else:
     zgXkQDRhJFGHfnAcVwyqUTEBOstKIo=zgXkQDRhJFGHfnAcVwyqUTEBOstKId+i
     if zgXkQDRhJFGHfnAcVwyqUTEBOstKIo>=zgXkQDRhJFGHfnAcVwyqUTEBOstKIY:break
    if zgXkQDRhJFGHfnAcVwyqUTEBOstKWa!='':zgXkQDRhJFGHfnAcVwyqUTEBOstKWa+=','
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWa+=zgXkQDRhJFGHfnAcVwyqUTEBOstKWo[zgXkQDRhJFGHfnAcVwyqUTEBOstKIo]
   if zgXkQDRhJFGHfnAcVwyqUTEBOstKIW>page_int:zgXkQDRhJFGHfnAcVwyqUTEBOstKWS=zgXkQDRhJFGHfnAcVwyqUTEBOstKdm
  except zgXkQDRhJFGHfnAcVwyqUTEBOstKdL as exception:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKdu(exception)
  try:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWb={'codes':zgXkQDRhJFGHfnAcVwyqUTEBOstKWa}
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYS=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeurl(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.API_DOMAIN,zgXkQDRhJFGHfnAcVwyqUTEBOstKWI)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYp=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeDefaultCookies()
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYl=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.callRequestCookies('Get',zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,payload=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,params=zgXkQDRhJFGHfnAcVwyqUTEBOstKWb,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,cookies=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWd=json.loads(zgXkQDRhJFGHfnAcVwyqUTEBOstKYl.text)
   if not('tv_episodes' in zgXkQDRhJFGHfnAcVwyqUTEBOstKWd):return zgXkQDRhJFGHfnAcVwyqUTEBOstKWY
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWo=zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['tv_episodes']
   for zgXkQDRhJFGHfnAcVwyqUTEBOstKWm in zgXkQDRhJFGHfnAcVwyqUTEBOstKWo:
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWe =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['code']
    if zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['title']:
     zgXkQDRhJFGHfnAcVwyqUTEBOstKWx =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['title']
    else:
     zgXkQDRhJFGHfnAcVwyqUTEBOstKWx =''
    if zgXkQDRhJFGHfnAcVwyqUTEBOstKWm.get('poster') !=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI:zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['poster']['medium']
    elif zgXkQDRhJFGHfnAcVwyqUTEBOstKWm.get('thumbnail')!=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI:zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['thumbnail']['medium']
    elif zgXkQDRhJFGHfnAcVwyqUTEBOstKWm.get('stillcut')!=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI:zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['stillcut']['medium']
    else: zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=''
    zgXkQDRhJFGHfnAcVwyqUTEBOstKIm =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['display_number']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKIL=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['tv_season_title']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWj =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['duration']
    try:
     zgXkQDRhJFGHfnAcVwyqUTEBOstKIu=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['episode_number']
    except:
     zgXkQDRhJFGHfnAcVwyqUTEBOstKIu='0'
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWr={'code':zgXkQDRhJFGHfnAcVwyqUTEBOstKWe,'title':zgXkQDRhJFGHfnAcVwyqUTEBOstKWx,'thumbnail':zgXkQDRhJFGHfnAcVwyqUTEBOstKWM,'display_num':zgXkQDRhJFGHfnAcVwyqUTEBOstKIm,'season_title':zgXkQDRhJFGHfnAcVwyqUTEBOstKIL,'duration':zgXkQDRhJFGHfnAcVwyqUTEBOstKWj,'episode_number':zgXkQDRhJFGHfnAcVwyqUTEBOstKIu}
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWY.append(zgXkQDRhJFGHfnAcVwyqUTEBOstKWr)
  except zgXkQDRhJFGHfnAcVwyqUTEBOstKdL as exception:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKdu(exception)
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKWY,zgXkQDRhJFGHfnAcVwyqUTEBOstKWS
 def GetSearchList(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,search_key,page_int):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKIv=[]
  zgXkQDRhJFGHfnAcVwyqUTEBOstKWS=zgXkQDRhJFGHfnAcVwyqUTEBOstKdo
  try:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWI ='/api/search.json'
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWb={'query':search_key,'page':zgXkQDRhJFGHfnAcVwyqUTEBOstKdv(page_int),'per':zgXkQDRhJFGHfnAcVwyqUTEBOstKdv(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.SEARCH_LIMIT),'exclude':'limited'}
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYS=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeurl(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.API_DOMAIN,zgXkQDRhJFGHfnAcVwyqUTEBOstKWI)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYp=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeDefaultCookies()
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYl=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.callRequestCookies('Get',zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,payload=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,params=zgXkQDRhJFGHfnAcVwyqUTEBOstKWb,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,cookies=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWd=json.loads(zgXkQDRhJFGHfnAcVwyqUTEBOstKYl.text)
   if not('results' in zgXkQDRhJFGHfnAcVwyqUTEBOstKWd):return zgXkQDRhJFGHfnAcVwyqUTEBOstKIv,zgXkQDRhJFGHfnAcVwyqUTEBOstKWS
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWo=zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['results']
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWS=zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['meta']['has_next']
   for zgXkQDRhJFGHfnAcVwyqUTEBOstKWm in zgXkQDRhJFGHfnAcVwyqUTEBOstKWo:
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWe =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['code']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWN=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['content_type']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWx =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['title']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWC =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['story']
    if zgXkQDRhJFGHfnAcVwyqUTEBOstKWm.get('poster') !=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI:zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['poster']['medium']
    elif zgXkQDRhJFGHfnAcVwyqUTEBOstKWm.get('thumbnail')!=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI:zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['thumbnail']['medium']
    elif zgXkQDRhJFGHfnAcVwyqUTEBOstKWm.get('stillcut')!=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI:zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['stillcut']['medium']
    else: zgXkQDRhJFGHfnAcVwyqUTEBOstKWM=''
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWi =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['year']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWl =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['film_rating_code']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWp=zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['film_rating_short']
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWP =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['film_rating_long']
    if zgXkQDRhJFGHfnAcVwyqUTEBOstKWN=='movies':
     zgXkQDRhJFGHfnAcVwyqUTEBOstKWj =zgXkQDRhJFGHfnAcVwyqUTEBOstKWm['duration']
    else:
     zgXkQDRhJFGHfnAcVwyqUTEBOstKWj ='0'
    zgXkQDRhJFGHfnAcVwyqUTEBOstKWr={'code':zgXkQDRhJFGHfnAcVwyqUTEBOstKWe,'content_type':zgXkQDRhJFGHfnAcVwyqUTEBOstKWN,'title':zgXkQDRhJFGHfnAcVwyqUTEBOstKWx,'story':zgXkQDRhJFGHfnAcVwyqUTEBOstKWC,'thumbnail':zgXkQDRhJFGHfnAcVwyqUTEBOstKWM,'year':zgXkQDRhJFGHfnAcVwyqUTEBOstKWi,'film_rating_code':zgXkQDRhJFGHfnAcVwyqUTEBOstKWl,'film_rating_short':zgXkQDRhJFGHfnAcVwyqUTEBOstKWp,'film_rating_long':zgXkQDRhJFGHfnAcVwyqUTEBOstKWP,'duration':zgXkQDRhJFGHfnAcVwyqUTEBOstKWj}
    zgXkQDRhJFGHfnAcVwyqUTEBOstKIv.append(zgXkQDRhJFGHfnAcVwyqUTEBOstKWr)
  except zgXkQDRhJFGHfnAcVwyqUTEBOstKdL as exception:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKdu(exception)
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKIv,zgXkQDRhJFGHfnAcVwyqUTEBOstKWS
 def GetProfilesList(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKYj=[]
  try:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWI ='/manage_profiles'
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYS=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeurl(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.API_DOMAIN,zgXkQDRhJFGHfnAcVwyqUTEBOstKWI)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYp=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeDefaultCookies()
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYl=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.callRequestCookies('Get',zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,payload=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,params=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,cookies=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp,redirects=zgXkQDRhJFGHfnAcVwyqUTEBOstKdm)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIr=zgXkQDRhJFGHfnAcVwyqUTEBOstKYl.text
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIS =re.findall('/api/users/me.{5000}',zgXkQDRhJFGHfnAcVwyqUTEBOstKIr)[0]
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIS =zgXkQDRhJFGHfnAcVwyqUTEBOstKIS.replace('&quot;','')
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYj=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',zgXkQDRhJFGHfnAcVwyqUTEBOstKIS)
   for i in zgXkQDRhJFGHfnAcVwyqUTEBOstKdb(zgXkQDRhJFGHfnAcVwyqUTEBOstKdr(zgXkQDRhJFGHfnAcVwyqUTEBOstKYj)):
    zgXkQDRhJFGHfnAcVwyqUTEBOstKIb=zgXkQDRhJFGHfnAcVwyqUTEBOstKYj[i]
    zgXkQDRhJFGHfnAcVwyqUTEBOstKIb =zgXkQDRhJFGHfnAcVwyqUTEBOstKIb.split(':')[1]
    zgXkQDRhJFGHfnAcVwyqUTEBOstKYj[i]=zgXkQDRhJFGHfnAcVwyqUTEBOstKIb.split(',')[0]
  except zgXkQDRhJFGHfnAcVwyqUTEBOstKdL as exception:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKdu(exception)
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKYj
 def GetProfilesConvert(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,zgXkQDRhJFGHfnAcVwyqUTEBOstKYL):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKIe=''
  zgXkQDRhJFGHfnAcVwyqUTEBOstKIN=''
  try:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWI ='/api/users/'+zgXkQDRhJFGHfnAcVwyqUTEBOstKYL+'/convert'
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYS=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeurl(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.API_DOMAIN,zgXkQDRhJFGHfnAcVwyqUTEBOstKWI)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYp=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeDefaultCookies()
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYl=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.callRequestCookies('Put',zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,payload=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,params=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,cookies=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp)
   for zgXkQDRhJFGHfnAcVwyqUTEBOstKYp in zgXkQDRhJFGHfnAcVwyqUTEBOstKYl.cookies:
    if zgXkQDRhJFGHfnAcVwyqUTEBOstKYp.name=='_s_guitv':
     zgXkQDRhJFGHfnAcVwyqUTEBOstKIx=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp.value
    elif zgXkQDRhJFGHfnAcVwyqUTEBOstKYp.name=='_guinness-premium_session':
     zgXkQDRhJFGHfnAcVwyqUTEBOstKYP=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp.value
   if zgXkQDRhJFGHfnAcVwyqUTEBOstKIx:
    zgXkQDRhJFGHfnAcVwyqUTEBOstKIe=zgXkQDRhJFGHfnAcVwyqUTEBOstKIx
   if zgXkQDRhJFGHfnAcVwyqUTEBOstKYP:
    zgXkQDRhJFGHfnAcVwyqUTEBOstKIN=zgXkQDRhJFGHfnAcVwyqUTEBOstKYP
  except zgXkQDRhJFGHfnAcVwyqUTEBOstKdL as exception:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIe=''
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIN=''
  return zgXkQDRhJFGHfnAcVwyqUTEBOstKIe,zgXkQDRhJFGHfnAcVwyqUTEBOstKIN
 def Get_Now_Datetime(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI,movie_code,quality_str):
  zgXkQDRhJFGHfnAcVwyqUTEBOstKIM=zgXkQDRhJFGHfnAcVwyqUTEBOstKIl=zgXkQDRhJFGHfnAcVwyqUTEBOstKdY=''
  try:
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWI='/api/watch/'+movie_code+'.json'
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYS=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeurl(zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.API_DOMAIN,zgXkQDRhJFGHfnAcVwyqUTEBOstKWI)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYi={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYp=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.makeDefaultCookies()
   zgXkQDRhJFGHfnAcVwyqUTEBOstKYl=zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.callRequestCookies('Get',zgXkQDRhJFGHfnAcVwyqUTEBOstKYS,payload=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,params=zgXkQDRhJFGHfnAcVwyqUTEBOstKdI,headers=zgXkQDRhJFGHfnAcVwyqUTEBOstKYi,cookies=zgXkQDRhJFGHfnAcVwyqUTEBOstKYp)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKWd=json.loads(zgXkQDRhJFGHfnAcVwyqUTEBOstKYl.text)
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIM=zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['streams'][0]['source']
   if zgXkQDRhJFGHfnAcVwyqUTEBOstKIM==zgXkQDRhJFGHfnAcVwyqUTEBOstKdI:return(zgXkQDRhJFGHfnAcVwyqUTEBOstKIM,zgXkQDRhJFGHfnAcVwyqUTEBOstKIl,zgXkQDRhJFGHfnAcVwyqUTEBOstKdY)
   if 'subtitles' in zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['streams'][0]:
    for zgXkQDRhJFGHfnAcVwyqUTEBOstKIi in zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['streams'][0]['subtitles']:
     if zgXkQDRhJFGHfnAcVwyqUTEBOstKIi['lang']=='ko':
      zgXkQDRhJFGHfnAcVwyqUTEBOstKIl=zgXkQDRhJFGHfnAcVwyqUTEBOstKIi['url']
      break
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIp =zgXkQDRhJFGHfnAcVwyqUTEBOstKWd['ping_payload']
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIP =zgXkQDRhJFGHfnAcVwyqUTEBOstKYI.WATCHA_USERCD
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIj={'merchant':'giitd_frograms','sessionId':zgXkQDRhJFGHfnAcVwyqUTEBOstKIp,'userId':zgXkQDRhJFGHfnAcVwyqUTEBOstKIP}
   zgXkQDRhJFGHfnAcVwyqUTEBOstKIa=json.dumps(zgXkQDRhJFGHfnAcVwyqUTEBOstKIj,separators=(",",":")).encode('UTF-8')
   zgXkQDRhJFGHfnAcVwyqUTEBOstKdY=base64.b64encode(zgXkQDRhJFGHfnAcVwyqUTEBOstKIa)
  except zgXkQDRhJFGHfnAcVwyqUTEBOstKdL as exception:
   return(zgXkQDRhJFGHfnAcVwyqUTEBOstKIM,zgXkQDRhJFGHfnAcVwyqUTEBOstKIl,zgXkQDRhJFGHfnAcVwyqUTEBOstKdY)
  return(zgXkQDRhJFGHfnAcVwyqUTEBOstKIM,zgXkQDRhJFGHfnAcVwyqUTEBOstKIl,zgXkQDRhJFGHfnAcVwyqUTEBOstKdY) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
