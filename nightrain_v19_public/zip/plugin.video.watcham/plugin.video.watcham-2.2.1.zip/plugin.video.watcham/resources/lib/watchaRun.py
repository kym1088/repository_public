__author__="NightRain"
JFHPVqIUDWXNbuvTslOKtdyRSLmneQ=object
JFHPVqIUDWXNbuvTslOKtdyRSLmnec=None
JFHPVqIUDWXNbuvTslOKtdyRSLmnex=int
JFHPVqIUDWXNbuvTslOKtdyRSLmneA=True
JFHPVqIUDWXNbuvTslOKtdyRSLmneC=False
JFHPVqIUDWXNbuvTslOKtdyRSLmneh=type
JFHPVqIUDWXNbuvTslOKtdyRSLmneM=dict
JFHPVqIUDWXNbuvTslOKtdyRSLmneo=len
JFHPVqIUDWXNbuvTslOKtdyRSLmneY=range
JFHPVqIUDWXNbuvTslOKtdyRSLmnef=str
JFHPVqIUDWXNbuvTslOKtdyRSLmnez=open
JFHPVqIUDWXNbuvTslOKtdyRSLmnej=Exception
JFHPVqIUDWXNbuvTslOKtdyRSLmneE=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
JFHPVqIUDWXNbuvTslOKtdyRSLmnrk=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-','icon':'history.png'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','sort':'-','icon':'bookmark.png'}]
JFHPVqIUDWXNbuvTslOKtdyRSLmnra=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
JFHPVqIUDWXNbuvTslOKtdyRSLmnrp=40
JFHPVqIUDWXNbuvTslOKtdyRSLmnrB =20
JFHPVqIUDWXNbuvTslOKtdyRSLmnre =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
JFHPVqIUDWXNbuvTslOKtdyRSLmnrQ =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
JFHPVqIUDWXNbuvTslOKtdyRSLmnrc=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
from watchaCore import*
class JFHPVqIUDWXNbuvTslOKtdyRSLmnrG(JFHPVqIUDWXNbuvTslOKtdyRSLmneQ):
 def __init__(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,JFHPVqIUDWXNbuvTslOKtdyRSLmnrA,JFHPVqIUDWXNbuvTslOKtdyRSLmnrC,JFHPVqIUDWXNbuvTslOKtdyRSLmnrh):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_url =JFHPVqIUDWXNbuvTslOKtdyRSLmnrA
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle=JFHPVqIUDWXNbuvTslOKtdyRSLmnrC
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params =JFHPVqIUDWXNbuvTslOKtdyRSLmnrh
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj =ndFJgsYViWxpPMeAKQmjBbLDlHwIOr() 
 def addon_noti(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,sting):
  try:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnro=xbmcgui.Dialog()
   JFHPVqIUDWXNbuvTslOKtdyRSLmnro.notification(__addonname__,sting)
  except:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnec
 def addon_log(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,string):
  try:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrY=string.encode('utf-8','ignore')
  except:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrY='addonException: addon_log'
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrf=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,JFHPVqIUDWXNbuvTslOKtdyRSLmnrY),level=JFHPVqIUDWXNbuvTslOKtdyRSLmnrf)
 def get_keyboard_input(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,JFHPVqIUDWXNbuvTslOKtdyRSLmnGC):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrz=JFHPVqIUDWXNbuvTslOKtdyRSLmnec
  kb=xbmc.Keyboard()
  kb.setHeading(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrz=kb.getText()
  return JFHPVqIUDWXNbuvTslOKtdyRSLmnrz
 def get_settings_login_info(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrj =__addon__.getSetting('id')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrE =__addon__.getSetting('pw')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrw=JFHPVqIUDWXNbuvTslOKtdyRSLmnex(__addon__.getSetting('selected_profile'))
  return(JFHPVqIUDWXNbuvTslOKtdyRSLmnrj,JFHPVqIUDWXNbuvTslOKtdyRSLmnrE,JFHPVqIUDWXNbuvTslOKtdyRSLmnrw)
 def get_settings_totalsearch(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnri =JFHPVqIUDWXNbuvTslOKtdyRSLmneA if __addon__.getSetting('local_search')=='true' else JFHPVqIUDWXNbuvTslOKtdyRSLmneC
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrg=JFHPVqIUDWXNbuvTslOKtdyRSLmneA if __addon__.getSetting('local_history')=='true' else JFHPVqIUDWXNbuvTslOKtdyRSLmneC
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGr =JFHPVqIUDWXNbuvTslOKtdyRSLmneA if __addon__.getSetting('total_search')=='true' else JFHPVqIUDWXNbuvTslOKtdyRSLmneC
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGk=JFHPVqIUDWXNbuvTslOKtdyRSLmneA if __addon__.getSetting('total_history')=='true' else JFHPVqIUDWXNbuvTslOKtdyRSLmneC
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGa=JFHPVqIUDWXNbuvTslOKtdyRSLmneA if __addon__.getSetting('menu_bookmark')=='true' else JFHPVqIUDWXNbuvTslOKtdyRSLmneC
  return(JFHPVqIUDWXNbuvTslOKtdyRSLmnri,JFHPVqIUDWXNbuvTslOKtdyRSLmnrg,JFHPVqIUDWXNbuvTslOKtdyRSLmnGr,JFHPVqIUDWXNbuvTslOKtdyRSLmnGk,JFHPVqIUDWXNbuvTslOKtdyRSLmnGa)
 def get_settings_makebookmark(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  return JFHPVqIUDWXNbuvTslOKtdyRSLmneA if __addon__.getSetting('make_bookmark')=='true' else JFHPVqIUDWXNbuvTslOKtdyRSLmneC
 def get_selQuality(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  try:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGp=['3840x2160/1','1920x1080/1','1280x720/1']
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGB=JFHPVqIUDWXNbuvTslOKtdyRSLmnex(__addon__.getSetting('selected_quality'))
   return JFHPVqIUDWXNbuvTslOKtdyRSLmnGp[JFHPVqIUDWXNbuvTslOKtdyRSLmnGB]
  except:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnec
  return 1080 
 def get_settings_direct_replay(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGe=JFHPVqIUDWXNbuvTslOKtdyRSLmnex(__addon__.getSetting('direct_replay'))
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnGe==0:
   return JFHPVqIUDWXNbuvTslOKtdyRSLmneC
  else:
   return JFHPVqIUDWXNbuvTslOKtdyRSLmneA
 def set_winCredential(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,credential):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ=xbmcgui.Window(10000)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_LOGINTIME',JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ=xbmcgui.Window(10000)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGc={'watcha_token':JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.getProperty('WATCHA_M_TOKEN'),'watcha_guit':JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.getProperty('WATCHA_M_GUIT'),'watcha_guitv':JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.getProperty('WATCHA_M_GUITV'),'watcha_usercd':JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.getProperty('WATCHA_M_USERCD')}
  return JFHPVqIUDWXNbuvTslOKtdyRSLmnGc
 def set_winEpisodeOrderby(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,JFHPVqIUDWXNbuvTslOKtdyRSLmnGx):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ=xbmcgui.Window(10000)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_ORDERBY',JFHPVqIUDWXNbuvTslOKtdyRSLmnGx)
 def get_winEpisodeOrderby(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ=xbmcgui.Window(10000)
  return JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGx =args.get('orderby')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.set_winEpisodeOrderby(JFHPVqIUDWXNbuvTslOKtdyRSLmnGx)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,label,sublabel='',img='',infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnec,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneA,params='',isLink=JFHPVqIUDWXNbuvTslOKtdyRSLmneC,ContextMenu=JFHPVqIUDWXNbuvTslOKtdyRSLmnec):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGA='%s?%s'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_url,urllib.parse.urlencode(params))
  if sublabel:JFHPVqIUDWXNbuvTslOKtdyRSLmnGC='%s < %s >'%(label,sublabel)
  else: JFHPVqIUDWXNbuvTslOKtdyRSLmnGC=label
  if not img:img='DefaultFolder.png'
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGh=xbmcgui.ListItem(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC)
  if JFHPVqIUDWXNbuvTslOKtdyRSLmneh(img)==JFHPVqIUDWXNbuvTslOKtdyRSLmneM:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGh.setArt(img)
  else:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGh.setArt({'thumb':img,'poster':img})
  if infoLabels:JFHPVqIUDWXNbuvTslOKtdyRSLmnGh.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGh.setProperty('IsPlayable','true')
  if ContextMenu:JFHPVqIUDWXNbuvTslOKtdyRSLmnGh.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,JFHPVqIUDWXNbuvTslOKtdyRSLmnGA,JFHPVqIUDWXNbuvTslOKtdyRSLmnGh,isFolder)
 def dp_Main_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  (JFHPVqIUDWXNbuvTslOKtdyRSLmnri,JFHPVqIUDWXNbuvTslOKtdyRSLmnrg,JFHPVqIUDWXNbuvTslOKtdyRSLmnGr,JFHPVqIUDWXNbuvTslOKtdyRSLmnGk,JFHPVqIUDWXNbuvTslOKtdyRSLmnGa)=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_settings_totalsearch()
  for JFHPVqIUDWXNbuvTslOKtdyRSLmnGM in JFHPVqIUDWXNbuvTslOKtdyRSLmnrk:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC=JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('title')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGo=''
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('mode')=='LOCAL_SEARCH' and JFHPVqIUDWXNbuvTslOKtdyRSLmnri ==JFHPVqIUDWXNbuvTslOKtdyRSLmneC:continue
   elif JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('mode')=='SEARCH_HISTORY' and JFHPVqIUDWXNbuvTslOKtdyRSLmnrg==JFHPVqIUDWXNbuvTslOKtdyRSLmneC:continue
   elif JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('mode')=='TOTAL_SEARCH' and JFHPVqIUDWXNbuvTslOKtdyRSLmnGr ==JFHPVqIUDWXNbuvTslOKtdyRSLmneC:continue
   elif JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('mode')=='TOTAL_HISTORY' and JFHPVqIUDWXNbuvTslOKtdyRSLmnGk==JFHPVqIUDWXNbuvTslOKtdyRSLmneC:continue
   elif JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('mode')=='MENU_BOOKMARK' and JFHPVqIUDWXNbuvTslOKtdyRSLmnGa==JFHPVqIUDWXNbuvTslOKtdyRSLmneC:continue
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('mode'),'stype':JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('stype'),'api_path':JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('api_path'),'page':'1','sort':JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('sort'),'tag_id':'-'}
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('mode')=='LOCAL_SEARCH':JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['historyyn']='Y' 
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGf=JFHPVqIUDWXNbuvTslOKtdyRSLmneC
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGz =JFHPVqIUDWXNbuvTslOKtdyRSLmneA
   else:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGf=JFHPVqIUDWXNbuvTslOKtdyRSLmneA
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGz =JFHPVqIUDWXNbuvTslOKtdyRSLmneC
   if 'icon' in JFHPVqIUDWXNbuvTslOKtdyRSLmnGM:JFHPVqIUDWXNbuvTslOKtdyRSLmnGo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',JFHPVqIUDWXNbuvTslOKtdyRSLmnGM.get('icon')) 
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel='',img=JFHPVqIUDWXNbuvTslOKtdyRSLmnGo,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnec,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmnGf,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY,isLink=JFHPVqIUDWXNbuvTslOKtdyRSLmnGz)
  xbmcplugin.endOfDirectory(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle)
 def login_main(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  (JFHPVqIUDWXNbuvTslOKtdyRSLmnGE,JFHPVqIUDWXNbuvTslOKtdyRSLmnGw,JFHPVqIUDWXNbuvTslOKtdyRSLmnGi)=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_settings_login_info()
  if not(JFHPVqIUDWXNbuvTslOKtdyRSLmnGE and JFHPVqIUDWXNbuvTslOKtdyRSLmnGw):
   JFHPVqIUDWXNbuvTslOKtdyRSLmnro=xbmcgui.Dialog()
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGg=JFHPVqIUDWXNbuvTslOKtdyRSLmnro.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnGg==JFHPVqIUDWXNbuvTslOKtdyRSLmneA:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_winEpisodeOrderby()=='':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.set_winEpisodeOrderby('asc')
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.cookiefile_check():return
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkr =JFHPVqIUDWXNbuvTslOKtdyRSLmnex(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkG=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnkG==JFHPVqIUDWXNbuvTslOKtdyRSLmnec or JFHPVqIUDWXNbuvTslOKtdyRSLmnkG=='':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkG=JFHPVqIUDWXNbuvTslOKtdyRSLmnex('19000101')
  else:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkG=JFHPVqIUDWXNbuvTslOKtdyRSLmnex(re.sub('-','',JFHPVqIUDWXNbuvTslOKtdyRSLmnkG))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnka=0
   while JFHPVqIUDWXNbuvTslOKtdyRSLmneA:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnka+=1
    time.sleep(0.05)
    if JFHPVqIUDWXNbuvTslOKtdyRSLmnkG>=JFHPVqIUDWXNbuvTslOKtdyRSLmnkr:return
    if JFHPVqIUDWXNbuvTslOKtdyRSLmnka>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnkG>=JFHPVqIUDWXNbuvTslOKtdyRSLmnkr:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.GetCredential(JFHPVqIUDWXNbuvTslOKtdyRSLmnGE,JFHPVqIUDWXNbuvTslOKtdyRSLmnGw,JFHPVqIUDWXNbuvTslOKtdyRSLmnGi):
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.set_winCredential(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.LoadCredential())
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.SaveCredential(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_winCredential())
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkp =args.get('stype')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkB =JFHPVqIUDWXNbuvTslOKtdyRSLmnex(args.get('page'))
  JFHPVqIUDWXNbuvTslOKtdyRSLmnke =args.get('sort')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkQ=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.GetSubGroupList(JFHPVqIUDWXNbuvTslOKtdyRSLmnkp)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkc=JFHPVqIUDWXNbuvTslOKtdyRSLmnrp if JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=='genres' else JFHPVqIUDWXNbuvTslOKtdyRSLmnrB
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkx=JFHPVqIUDWXNbuvTslOKtdyRSLmneo(JFHPVqIUDWXNbuvTslOKtdyRSLmnkQ)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkA =JFHPVqIUDWXNbuvTslOKtdyRSLmnex(JFHPVqIUDWXNbuvTslOKtdyRSLmnkx//(JFHPVqIUDWXNbuvTslOKtdyRSLmnkc+1))+1
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkC =(JFHPVqIUDWXNbuvTslOKtdyRSLmnkB-1)*JFHPVqIUDWXNbuvTslOKtdyRSLmnkc
  for i in JFHPVqIUDWXNbuvTslOKtdyRSLmneY(JFHPVqIUDWXNbuvTslOKtdyRSLmnkc):
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkh=JFHPVqIUDWXNbuvTslOKtdyRSLmnkC+i
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnkh>=JFHPVqIUDWXNbuvTslOKtdyRSLmnkx:break
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC =JFHPVqIUDWXNbuvTslOKtdyRSLmnkQ[JFHPVqIUDWXNbuvTslOKtdyRSLmnkh].get('group_name')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkM =JFHPVqIUDWXNbuvTslOKtdyRSLmnkQ[JFHPVqIUDWXNbuvTslOKtdyRSLmnkh].get('api_path')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnko =JFHPVqIUDWXNbuvTslOKtdyRSLmnkQ[JFHPVqIUDWXNbuvTslOKtdyRSLmnkh].get('tag_id')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':'CATEGORY_LIST','api_path':JFHPVqIUDWXNbuvTslOKtdyRSLmnkM,'tag_id':JFHPVqIUDWXNbuvTslOKtdyRSLmnko,'stype':JFHPVqIUDWXNbuvTslOKtdyRSLmnkp,'page':'1','sort':JFHPVqIUDWXNbuvTslOKtdyRSLmnke}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel='',img='',infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnec,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneA,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY)
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnkA>JFHPVqIUDWXNbuvTslOKtdyRSLmnkB:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['mode'] ='SUB_GROUP' 
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['stype'] =JFHPVqIUDWXNbuvTslOKtdyRSLmnkp
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['api_path']=args.get('api_path')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['page'] =JFHPVqIUDWXNbuvTslOKtdyRSLmnef(JFHPVqIUDWXNbuvTslOKtdyRSLmnkB+1)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['sort'] =JFHPVqIUDWXNbuvTslOKtdyRSLmnke
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC='[B]%s >>[/B]'%'다음 페이지'
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkY=JFHPVqIUDWXNbuvTslOKtdyRSLmnef(JFHPVqIUDWXNbuvTslOKtdyRSLmnkB+1)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel=JFHPVqIUDWXNbuvTslOKtdyRSLmnkY,img=JFHPVqIUDWXNbuvTslOKtdyRSLmnGo,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnec,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneA,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY)
  if JFHPVqIUDWXNbuvTslOKtdyRSLmneo(JFHPVqIUDWXNbuvTslOKtdyRSLmnkQ)>0:xbmcplugin.endOfDirectory(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,cacheToDisc=JFHPVqIUDWXNbuvTslOKtdyRSLmneA)
 def play_VIDEO(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.SaveCredential(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_winCredential())
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkf =args.get('movie_code')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkz =args.get('season_code')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGC =args.get('title')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkj =args.get('thumbnail')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkE =JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_selQuality()
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.addon_log(JFHPVqIUDWXNbuvTslOKtdyRSLmnkf+' - '+JFHPVqIUDWXNbuvTslOKtdyRSLmnkz)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkw,JFHPVqIUDWXNbuvTslOKtdyRSLmnki,JFHPVqIUDWXNbuvTslOKtdyRSLmnkg=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.GetStreamingURL(JFHPVqIUDWXNbuvTslOKtdyRSLmnkf,JFHPVqIUDWXNbuvTslOKtdyRSLmnkE)
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnkw=='':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.addon_noti(__language__(30908).encode('utf8'))
   return
  JFHPVqIUDWXNbuvTslOKtdyRSLmnar=JFHPVqIUDWXNbuvTslOKtdyRSLmnkw
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.addon_log(JFHPVqIUDWXNbuvTslOKtdyRSLmnar)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnaG=xbmcgui.ListItem(path=JFHPVqIUDWXNbuvTslOKtdyRSLmnar)
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnkg:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnak=JFHPVqIUDWXNbuvTslOKtdyRSLmnkg
   JFHPVqIUDWXNbuvTslOKtdyRSLmnap ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   JFHPVqIUDWXNbuvTslOKtdyRSLmnaB ='mpd'
   JFHPVqIUDWXNbuvTslOKtdyRSLmnae ='com.widevine.alpha'
   JFHPVqIUDWXNbuvTslOKtdyRSLmnaQ =inputstreamhelper.Helper(JFHPVqIUDWXNbuvTslOKtdyRSLmnaB,drm=JFHPVqIUDWXNbuvTslOKtdyRSLmnae)
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnaQ.check_inputstream():
    JFHPVqIUDWXNbuvTslOKtdyRSLmnac={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+JFHPVqIUDWXNbuvTslOKtdyRSLmnkf,'dt-custom-data':JFHPVqIUDWXNbuvTslOKtdyRSLmnak,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    JFHPVqIUDWXNbuvTslOKtdyRSLmnax=JFHPVqIUDWXNbuvTslOKtdyRSLmnap+'|'+urllib.parse.urlencode(JFHPVqIUDWXNbuvTslOKtdyRSLmnac)+'|R{SSM}|'
    JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.addon_log(JFHPVqIUDWXNbuvTslOKtdyRSLmnax)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnaG.setProperty('inputstream',JFHPVqIUDWXNbuvTslOKtdyRSLmnaQ.inputstream_addon)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnaG.setProperty('inputstream.adaptive.manifest_type',JFHPVqIUDWXNbuvTslOKtdyRSLmnaB)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnaG.setProperty('inputstream.adaptive.license_type',JFHPVqIUDWXNbuvTslOKtdyRSLmnae)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnaG.setProperty('inputstream.adaptive.license_key',JFHPVqIUDWXNbuvTslOKtdyRSLmnax)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnaG.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.USER_AGENT))
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnki:
   try:
    f=JFHPVqIUDWXNbuvTslOKtdyRSLmnez(JFHPVqIUDWXNbuvTslOKtdyRSLmnre,'w',-1,'utf-8')
    JFHPVqIUDWXNbuvTslOKtdyRSLmnaA=requests.get(JFHPVqIUDWXNbuvTslOKtdyRSLmnki)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnaC=JFHPVqIUDWXNbuvTslOKtdyRSLmnaA.content.decode('utf-8') 
    for JFHPVqIUDWXNbuvTslOKtdyRSLmnah in JFHPVqIUDWXNbuvTslOKtdyRSLmnaC.splitlines():
     JFHPVqIUDWXNbuvTslOKtdyRSLmnaM=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',JFHPVqIUDWXNbuvTslOKtdyRSLmnah)
     f.write(JFHPVqIUDWXNbuvTslOKtdyRSLmnaM+'\n')
    f.close()
    JFHPVqIUDWXNbuvTslOKtdyRSLmnaG.setSubtitles([JFHPVqIUDWXNbuvTslOKtdyRSLmnre,JFHPVqIUDWXNbuvTslOKtdyRSLmnki])
   except:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnaG.setSubtitles([JFHPVqIUDWXNbuvTslOKtdyRSLmnki])
  xbmcplugin.setResolvedUrl(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,JFHPVqIUDWXNbuvTslOKtdyRSLmneA,JFHPVqIUDWXNbuvTslOKtdyRSLmnaG)
  try:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkp='movie' if JFHPVqIUDWXNbuvTslOKtdyRSLmnkz=='-' else 'seasons'
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'code':JFHPVqIUDWXNbuvTslOKtdyRSLmnkf if JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=='movie' else JFHPVqIUDWXNbuvTslOKtdyRSLmnkz,'img':JFHPVqIUDWXNbuvTslOKtdyRSLmnkj,'title':JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,'videoid':JFHPVqIUDWXNbuvTslOKtdyRSLmnkf}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.Save_Watched_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnkp,JFHPVqIUDWXNbuvTslOKtdyRSLmnGY)
  except:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnec
 def dp_Category_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.SaveCredential(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_winCredential())
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkp =args.get('stype')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnko =args.get('tag_id')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkM=args.get('api_path')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkB=JFHPVqIUDWXNbuvTslOKtdyRSLmnex(args.get('page'))
  JFHPVqIUDWXNbuvTslOKtdyRSLmnke =args.get('sort')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnao,JFHPVqIUDWXNbuvTslOKtdyRSLmnaY=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.GetCategoryList(JFHPVqIUDWXNbuvTslOKtdyRSLmnkp,JFHPVqIUDWXNbuvTslOKtdyRSLmnko,JFHPVqIUDWXNbuvTslOKtdyRSLmnkM,JFHPVqIUDWXNbuvTslOKtdyRSLmnkB,JFHPVqIUDWXNbuvTslOKtdyRSLmnke)
  for JFHPVqIUDWXNbuvTslOKtdyRSLmnaf in JFHPVqIUDWXNbuvTslOKtdyRSLmnao:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkf =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('code')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('title')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnaz =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('content_type')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnaj =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('story')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkj =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('thumbnail')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnaE =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('year')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnaw =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('film_rating_code')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnai=JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('film_rating_short')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnag =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('film_rating_long')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpr =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('duration')
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnaz=='movies': 
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGf =JFHPVqIUDWXNbuvTslOKtdyRSLmneC
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpG ='MOVIE'
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGj =''
    JFHPVqIUDWXNbuvTslOKtdyRSLmnkz='-'
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpk ='movie'
   else: 
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGf =JFHPVqIUDWXNbuvTslOKtdyRSLmneA
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpG ='EPISODE'
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGj ='' 
    JFHPVqIUDWXNbuvTslOKtdyRSLmnkz=JFHPVqIUDWXNbuvTslOKtdyRSLmnkf
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpk ='tvshow' 
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpa={'mediatype':JFHPVqIUDWXNbuvTslOKtdyRSLmnpk,'mpaa':JFHPVqIUDWXNbuvTslOKtdyRSLmnag,'title':JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,'year':JFHPVqIUDWXNbuvTslOKtdyRSLmnaE,'duration':JFHPVqIUDWXNbuvTslOKtdyRSLmnpr,'plot':JFHPVqIUDWXNbuvTslOKtdyRSLmnaj}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC+='  (%s)'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnaE)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':JFHPVqIUDWXNbuvTslOKtdyRSLmnpG,'movie_code':JFHPVqIUDWXNbuvTslOKtdyRSLmnkf,'page':'1','season_code':JFHPVqIUDWXNbuvTslOKtdyRSLmnkz,'title':JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,'thumbnail':JFHPVqIUDWXNbuvTslOKtdyRSLmnkj}
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_settings_makebookmark():
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpB={'videoid':JFHPVqIUDWXNbuvTslOKtdyRSLmnkf,'vidtype':'tvshow' if JFHPVqIUDWXNbuvTslOKtdyRSLmnaz=='tv_seasons' else 'movie','vtitle':JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,'vsubtitle':'',}
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpe=json.dumps(JFHPVqIUDWXNbuvTslOKtdyRSLmnpB)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpe=urllib.parse.quote(JFHPVqIUDWXNbuvTslOKtdyRSLmnpe)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpQ='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnpe)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpc=[('(통합) 찜 영상에 추가',JFHPVqIUDWXNbuvTslOKtdyRSLmnpQ)]
   else:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpc=JFHPVqIUDWXNbuvTslOKtdyRSLmnec
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel=JFHPVqIUDWXNbuvTslOKtdyRSLmnGj,img=JFHPVqIUDWXNbuvTslOKtdyRSLmnkj,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnpa,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmnGf,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY,ContextMenu=JFHPVqIUDWXNbuvTslOKtdyRSLmnpc)
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnaY:
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.GetCategoryList_morepage(JFHPVqIUDWXNbuvTslOKtdyRSLmnkp,JFHPVqIUDWXNbuvTslOKtdyRSLmnko,JFHPVqIUDWXNbuvTslOKtdyRSLmnkM,JFHPVqIUDWXNbuvTslOKtdyRSLmnkB+1,JFHPVqIUDWXNbuvTslOKtdyRSLmnke):
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={}
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['mode'] ='CATEGORY_LIST'
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['stype'] =JFHPVqIUDWXNbuvTslOKtdyRSLmnkp
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['tag_id'] =JFHPVqIUDWXNbuvTslOKtdyRSLmnko
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['api_path']=JFHPVqIUDWXNbuvTslOKtdyRSLmnkM
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['page'] =JFHPVqIUDWXNbuvTslOKtdyRSLmnef(JFHPVqIUDWXNbuvTslOKtdyRSLmnkB+1)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['sort'] =JFHPVqIUDWXNbuvTslOKtdyRSLmnke
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGC='[B]%s >>[/B]'%'다음 페이지'
    JFHPVqIUDWXNbuvTslOKtdyRSLmnkY=JFHPVqIUDWXNbuvTslOKtdyRSLmnef(JFHPVqIUDWXNbuvTslOKtdyRSLmnkB+1)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
    JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel=JFHPVqIUDWXNbuvTslOKtdyRSLmnkY,img=JFHPVqIUDWXNbuvTslOKtdyRSLmnGo,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnec,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneA,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY)
  xbmcplugin.setContent(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,'movies')
  if JFHPVqIUDWXNbuvTslOKtdyRSLmneo(JFHPVqIUDWXNbuvTslOKtdyRSLmnao)>0:
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnkM=='arrivals/latest':
    xbmcplugin.endOfDirectory(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,cacheToDisc=JFHPVqIUDWXNbuvTslOKtdyRSLmneA)
   else:
    xbmcplugin.endOfDirectory(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,cacheToDisc=JFHPVqIUDWXNbuvTslOKtdyRSLmneC)
 def dp_Episode_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.SaveCredential(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_winCredential())
  JFHPVqIUDWXNbuvTslOKtdyRSLmnpA=args.get('movie_code')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkB =JFHPVqIUDWXNbuvTslOKtdyRSLmnex(args.get('page'))
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkz =args.get('season_code')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnao,JFHPVqIUDWXNbuvTslOKtdyRSLmnaY=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.GetEpisodoList(JFHPVqIUDWXNbuvTslOKtdyRSLmnpA,JFHPVqIUDWXNbuvTslOKtdyRSLmnkB,orderby=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_winEpisodeOrderby())
  for JFHPVqIUDWXNbuvTslOKtdyRSLmnaf in JFHPVqIUDWXNbuvTslOKtdyRSLmnao:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkf =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('code')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('title')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkj =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('thumbnail')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpC =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('display_num')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnph =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('season_title')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpM=JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('episode_number')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpr =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('duration')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpa={'mediatype':'episode','tvshowtitle':JFHPVqIUDWXNbuvTslOKtdyRSLmnGC if JFHPVqIUDWXNbuvTslOKtdyRSLmnGC!='' else JFHPVqIUDWXNbuvTslOKtdyRSLmnph,'title':'%s %s'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnph,JFHPVqIUDWXNbuvTslOKtdyRSLmnpC)if JFHPVqIUDWXNbuvTslOKtdyRSLmnGC!='' else JFHPVqIUDWXNbuvTslOKtdyRSLmnpC,'episode':JFHPVqIUDWXNbuvTslOKtdyRSLmnpM,'duration':JFHPVqIUDWXNbuvTslOKtdyRSLmnpr,'plot':'%s\n%s\n\n%s'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnph,JFHPVqIUDWXNbuvTslOKtdyRSLmnpC,JFHPVqIUDWXNbuvTslOKtdyRSLmnGC)}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC='(%s) %s'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnpC,JFHPVqIUDWXNbuvTslOKtdyRSLmnGC)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':'MOVIE','movie_code':JFHPVqIUDWXNbuvTslOKtdyRSLmnkf,'season_code':JFHPVqIUDWXNbuvTslOKtdyRSLmnkz,'title':'%s < %s >'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,JFHPVqIUDWXNbuvTslOKtdyRSLmnph),'thumbnail':JFHPVqIUDWXNbuvTslOKtdyRSLmnkj}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel=JFHPVqIUDWXNbuvTslOKtdyRSLmnph,img=JFHPVqIUDWXNbuvTslOKtdyRSLmnkj,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnpa,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneC,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY)
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnkB==1:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpa={'plot':'정렬순서를 변경합니다.'}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['mode'] ='ORDER_BY' 
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_winEpisodeOrderby()=='desc':
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGC='정렬순서변경 : 최신화부터 -> 1회부터'
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['orderby']='asc'
   else:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGC='정렬순서변경 : 1회부터 -> 최신화부터'
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['orderby']='desc'
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel='',img=JFHPVqIUDWXNbuvTslOKtdyRSLmnGo,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnpa,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneC,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY,isLink=JFHPVqIUDWXNbuvTslOKtdyRSLmneA)
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnaY:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['mode'] ='EPISODE' 
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['movie_code']=JFHPVqIUDWXNbuvTslOKtdyRSLmnpA
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['page'] =JFHPVqIUDWXNbuvTslOKtdyRSLmnef(JFHPVqIUDWXNbuvTslOKtdyRSLmnkB+1)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC='[B]%s >>[/B]'%'다음 페이지'
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkY=JFHPVqIUDWXNbuvTslOKtdyRSLmnef(JFHPVqIUDWXNbuvTslOKtdyRSLmnkB+1)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel=JFHPVqIUDWXNbuvTslOKtdyRSLmnkY,img=JFHPVqIUDWXNbuvTslOKtdyRSLmnGo,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnec,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneA,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY)
  xbmcplugin.setContent(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,'episodes')
  if JFHPVqIUDWXNbuvTslOKtdyRSLmneo(JFHPVqIUDWXNbuvTslOKtdyRSLmnao)>0:xbmcplugin.endOfDirectory(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,cacheToDisc=JFHPVqIUDWXNbuvTslOKtdyRSLmneA)
 def dp_Search_History(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnpo=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.Load_List_File('search')
  for JFHPVqIUDWXNbuvTslOKtdyRSLmnpY in JFHPVqIUDWXNbuvTslOKtdyRSLmnpo:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpf=JFHPVqIUDWXNbuvTslOKtdyRSLmneM(urllib.parse.parse_qsl(JFHPVqIUDWXNbuvTslOKtdyRSLmnpY))
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpz=JFHPVqIUDWXNbuvTslOKtdyRSLmnpf.get('skey').strip()
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':'LOCAL_SEARCH','search_key':JFHPVqIUDWXNbuvTslOKtdyRSLmnpz,'page':'1','historyyn':'Y',}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpj={'mode':'SEARCH_REMOVE','stype':'ONE','skey':JFHPVqIUDWXNbuvTslOKtdyRSLmnpz,}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpE=urllib.parse.urlencode(JFHPVqIUDWXNbuvTslOKtdyRSLmnpj)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpc=[('선택된 검색어 ( %s ) 삭제'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnpz),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnpE))]
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnpz,sublabel='',img=JFHPVqIUDWXNbuvTslOKtdyRSLmnec,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnec,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneA,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY,ContextMenu=JFHPVqIUDWXNbuvTslOKtdyRSLmnpc)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnpa={'plot':'검색목록 전체를 삭제합니다.'}
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGC='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel='',img=JFHPVqIUDWXNbuvTslOKtdyRSLmnGo,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnpa,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneC,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY,isLink=JFHPVqIUDWXNbuvTslOKtdyRSLmneA)
  xbmcplugin.endOfDirectory(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,cacheToDisc=JFHPVqIUDWXNbuvTslOKtdyRSLmneC)
 def dp_Search_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.SaveCredential(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_winCredential())
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkB =JFHPVqIUDWXNbuvTslOKtdyRSLmnex(args.get('page'))
  if 'search_key' in args:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpw=args.get('search_key')
  else:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpw=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not JFHPVqIUDWXNbuvTslOKtdyRSLmnpw:
    xbmcplugin.endOfDirectory(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle)
    return
  JFHPVqIUDWXNbuvTslOKtdyRSLmnao,JFHPVqIUDWXNbuvTslOKtdyRSLmnaY=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.GetSearchList(JFHPVqIUDWXNbuvTslOKtdyRSLmnpw,JFHPVqIUDWXNbuvTslOKtdyRSLmnkB)
  for JFHPVqIUDWXNbuvTslOKtdyRSLmnaf in JFHPVqIUDWXNbuvTslOKtdyRSLmnao:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkf =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('code')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('title')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnaz=JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('content_type')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnaj =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('story')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkj =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('thumbnail')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnaE =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('year')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnaw =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('film_rating_code')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnai=JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('film_rating_short')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnag =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('film_rating_long')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpr =JFHPVqIUDWXNbuvTslOKtdyRSLmnaf.get('duration')
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnaz=='movies': 
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGf =JFHPVqIUDWXNbuvTslOKtdyRSLmneC
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpG ='MOVIE'
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGj =''
    JFHPVqIUDWXNbuvTslOKtdyRSLmnkz='-'
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpk ='movie'
   else: 
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGf =JFHPVqIUDWXNbuvTslOKtdyRSLmneA
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpG ='EPISODE'
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGj ='' 
    JFHPVqIUDWXNbuvTslOKtdyRSLmnkz=JFHPVqIUDWXNbuvTslOKtdyRSLmnkf
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpk ='tvshow' 
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpa={'mediatype':JFHPVqIUDWXNbuvTslOKtdyRSLmnpk,'mpaa':JFHPVqIUDWXNbuvTslOKtdyRSLmnag,'title':JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,'year':JFHPVqIUDWXNbuvTslOKtdyRSLmnaE,'duration':JFHPVqIUDWXNbuvTslOKtdyRSLmnpr,'plot':JFHPVqIUDWXNbuvTslOKtdyRSLmnaj}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC+='  (%s)'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnaE)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':JFHPVqIUDWXNbuvTslOKtdyRSLmnpG,'movie_code':JFHPVqIUDWXNbuvTslOKtdyRSLmnkf,'page':'1','season_code':JFHPVqIUDWXNbuvTslOKtdyRSLmnkz,'title':JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,'thumbnail':JFHPVqIUDWXNbuvTslOKtdyRSLmnkj}
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_settings_makebookmark():
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpB={'videoid':JFHPVqIUDWXNbuvTslOKtdyRSLmnkf,'vidtype':'tvshow' if JFHPVqIUDWXNbuvTslOKtdyRSLmnaz=='tv_seasons' else 'movie','vtitle':JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,'vsubtitle':'',}
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpe=json.dumps(JFHPVqIUDWXNbuvTslOKtdyRSLmnpB)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpe=urllib.parse.quote(JFHPVqIUDWXNbuvTslOKtdyRSLmnpe)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpQ='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(JFHPVqIUDWXNbuvTslOKtdyRSLmnpe)
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpc=[('(통합) 찜 영상에 추가',JFHPVqIUDWXNbuvTslOKtdyRSLmnpQ)]
   else:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpc=JFHPVqIUDWXNbuvTslOKtdyRSLmnec
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel=JFHPVqIUDWXNbuvTslOKtdyRSLmnGj,img=JFHPVqIUDWXNbuvTslOKtdyRSLmnkj,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnpa,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmnGf,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY,ContextMenu=JFHPVqIUDWXNbuvTslOKtdyRSLmnpc)
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnaY:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['mode'] ='SEARCH'
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['search_key']=JFHPVqIUDWXNbuvTslOKtdyRSLmnpw
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY['page'] =JFHPVqIUDWXNbuvTslOKtdyRSLmnef(JFHPVqIUDWXNbuvTslOKtdyRSLmnkB+1)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC='[B]%s >>[/B]'%'다음 페이지'
   JFHPVqIUDWXNbuvTslOKtdyRSLmnkY=JFHPVqIUDWXNbuvTslOKtdyRSLmnef(JFHPVqIUDWXNbuvTslOKtdyRSLmnkB+1)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel=JFHPVqIUDWXNbuvTslOKtdyRSLmnkY,img=JFHPVqIUDWXNbuvTslOKtdyRSLmnGo,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnec,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneA,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY)
  xbmcplugin.setContent(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,'movies')
  xbmcplugin.endOfDirectory(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,cacheToDisc=JFHPVqIUDWXNbuvTslOKtdyRSLmneC)
  if args.get('historyyn')=='Y':JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.Save_Searched_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnpw)
 def Delete_List_File(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,JFHPVqIUDWXNbuvTslOKtdyRSLmnkp,skey='-'):
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=='ALL':
   try:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpi=JFHPVqIUDWXNbuvTslOKtdyRSLmnrc
    fp=JFHPVqIUDWXNbuvTslOKtdyRSLmnez(JFHPVqIUDWXNbuvTslOKtdyRSLmnpi,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnec
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=='ONE':
   try:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpi=JFHPVqIUDWXNbuvTslOKtdyRSLmnrc
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpg=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.Load_List_File('search') 
    fp=JFHPVqIUDWXNbuvTslOKtdyRSLmnez(JFHPVqIUDWXNbuvTslOKtdyRSLmnpi,'w',-1,'utf-8')
    for JFHPVqIUDWXNbuvTslOKtdyRSLmnBr in JFHPVqIUDWXNbuvTslOKtdyRSLmnpg:
     JFHPVqIUDWXNbuvTslOKtdyRSLmnBG=JFHPVqIUDWXNbuvTslOKtdyRSLmneM(urllib.parse.parse_qsl(JFHPVqIUDWXNbuvTslOKtdyRSLmnBr))
     JFHPVqIUDWXNbuvTslOKtdyRSLmnBk=JFHPVqIUDWXNbuvTslOKtdyRSLmnBG.get('skey').strip()
     if skey!=JFHPVqIUDWXNbuvTslOKtdyRSLmnBk:
      fp.write(JFHPVqIUDWXNbuvTslOKtdyRSLmnBr)
    fp.close()
   except:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnec
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnkp in['seasons','movie']:
   try:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JFHPVqIUDWXNbuvTslOKtdyRSLmnkp))
    fp=JFHPVqIUDWXNbuvTslOKtdyRSLmnez(JFHPVqIUDWXNbuvTslOKtdyRSLmnpi,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnec
 def dp_Listfile_Delete(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=args.get('stype')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnpz =args.get('skey')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnro=xbmcgui.Dialog()
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=='ALL':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGg=JFHPVqIUDWXNbuvTslOKtdyRSLmnro.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=='ONE':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGg=JFHPVqIUDWXNbuvTslOKtdyRSLmnro.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnkp in['seasons','movie']:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGg=JFHPVqIUDWXNbuvTslOKtdyRSLmnro.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnGg==JFHPVqIUDWXNbuvTslOKtdyRSLmneC:sys.exit()
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.Delete_List_File(JFHPVqIUDWXNbuvTslOKtdyRSLmnkp,skey=JFHPVqIUDWXNbuvTslOKtdyRSLmnpz)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,JFHPVqIUDWXNbuvTslOKtdyRSLmnkp): 
  try:
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=='search':
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpi=JFHPVqIUDWXNbuvTslOKtdyRSLmnrc
   elif JFHPVqIUDWXNbuvTslOKtdyRSLmnkp in['seasons','movie']:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JFHPVqIUDWXNbuvTslOKtdyRSLmnkp))
   else:
    return[]
   fp=JFHPVqIUDWXNbuvTslOKtdyRSLmnez(JFHPVqIUDWXNbuvTslOKtdyRSLmnpi,'r',-1,'utf-8')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBa=fp.readlines()
   fp.close()
  except:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBa=[]
  return JFHPVqIUDWXNbuvTslOKtdyRSLmnBa
 def Save_Watched_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,JFHPVqIUDWXNbuvTslOKtdyRSLmnkp,JFHPVqIUDWXNbuvTslOKtdyRSLmnrh):
  try:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JFHPVqIUDWXNbuvTslOKtdyRSLmnkp))
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpg=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.Load_List_File(JFHPVqIUDWXNbuvTslOKtdyRSLmnkp) 
   fp=JFHPVqIUDWXNbuvTslOKtdyRSLmnez(JFHPVqIUDWXNbuvTslOKtdyRSLmnBp,'w',-1,'utf-8')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBe=urllib.parse.urlencode(JFHPVqIUDWXNbuvTslOKtdyRSLmnrh)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBe=JFHPVqIUDWXNbuvTslOKtdyRSLmnBe+'\n'
   fp.write(JFHPVqIUDWXNbuvTslOKtdyRSLmnBe)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBQ=0
   for JFHPVqIUDWXNbuvTslOKtdyRSLmnBr in JFHPVqIUDWXNbuvTslOKtdyRSLmnpg:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnBG=JFHPVqIUDWXNbuvTslOKtdyRSLmneM(urllib.parse.parse_qsl(JFHPVqIUDWXNbuvTslOKtdyRSLmnBr))
    JFHPVqIUDWXNbuvTslOKtdyRSLmnBc=JFHPVqIUDWXNbuvTslOKtdyRSLmnrh.get('code').strip()
    JFHPVqIUDWXNbuvTslOKtdyRSLmnBx=JFHPVqIUDWXNbuvTslOKtdyRSLmnBG.get('code').strip()
    if JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=='seasons' and JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_settings_direct_replay()==JFHPVqIUDWXNbuvTslOKtdyRSLmneA:
     JFHPVqIUDWXNbuvTslOKtdyRSLmnBc=JFHPVqIUDWXNbuvTslOKtdyRSLmnrh.get('videoid').strip()
     JFHPVqIUDWXNbuvTslOKtdyRSLmnBx=JFHPVqIUDWXNbuvTslOKtdyRSLmnBG.get('videoid').strip()if JFHPVqIUDWXNbuvTslOKtdyRSLmnBx!=JFHPVqIUDWXNbuvTslOKtdyRSLmnec else '-'
    if JFHPVqIUDWXNbuvTslOKtdyRSLmnBc!=JFHPVqIUDWXNbuvTslOKtdyRSLmnBx:
     fp.write(JFHPVqIUDWXNbuvTslOKtdyRSLmnBr)
     JFHPVqIUDWXNbuvTslOKtdyRSLmnBQ+=1
     if JFHPVqIUDWXNbuvTslOKtdyRSLmnBQ>=50:break
   fp.close()
  except:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnec
 def dp_Watch_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkp =args.get('stype')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGe=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.get_settings_direct_replay()
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=='-':
   for JFHPVqIUDWXNbuvTslOKtdyRSLmnBA in JFHPVqIUDWXNbuvTslOKtdyRSLmnra:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGC=JFHPVqIUDWXNbuvTslOKtdyRSLmnBA.get('title')
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':JFHPVqIUDWXNbuvTslOKtdyRSLmnBA.get('mode'),'stype':JFHPVqIUDWXNbuvTslOKtdyRSLmnBA.get('stype')}
    JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel='',img='',infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnec,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneA,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY)
   if JFHPVqIUDWXNbuvTslOKtdyRSLmneo(JFHPVqIUDWXNbuvTslOKtdyRSLmnra)>0:xbmcplugin.endOfDirectory(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle)
  else:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBC=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.Load_List_File(JFHPVqIUDWXNbuvTslOKtdyRSLmnkp)
   for JFHPVqIUDWXNbuvTslOKtdyRSLmnBh in JFHPVqIUDWXNbuvTslOKtdyRSLmnBC:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpf=JFHPVqIUDWXNbuvTslOKtdyRSLmneM(urllib.parse.parse_qsl(JFHPVqIUDWXNbuvTslOKtdyRSLmnBh))
    JFHPVqIUDWXNbuvTslOKtdyRSLmnkf=JFHPVqIUDWXNbuvTslOKtdyRSLmnpf.get('code').strip()
    JFHPVqIUDWXNbuvTslOKtdyRSLmnGC =JFHPVqIUDWXNbuvTslOKtdyRSLmnpf.get('title').strip()
    JFHPVqIUDWXNbuvTslOKtdyRSLmnkj =JFHPVqIUDWXNbuvTslOKtdyRSLmnpf.get('img').strip()
    JFHPVqIUDWXNbuvTslOKtdyRSLmnBM =JFHPVqIUDWXNbuvTslOKtdyRSLmnpf.get('videoid').strip()
    try:
     JFHPVqIUDWXNbuvTslOKtdyRSLmnkj=JFHPVqIUDWXNbuvTslOKtdyRSLmnkj.replace('\'','\"')
     JFHPVqIUDWXNbuvTslOKtdyRSLmnkj=json.loads(JFHPVqIUDWXNbuvTslOKtdyRSLmnkj)
    except:
     JFHPVqIUDWXNbuvTslOKtdyRSLmnec
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpa={}
    JFHPVqIUDWXNbuvTslOKtdyRSLmnpa['plot']=JFHPVqIUDWXNbuvTslOKtdyRSLmnGC
    if JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=='movie':
     JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':'MOVIE','page':'1','movie_code':JFHPVqIUDWXNbuvTslOKtdyRSLmnkf,'season_code':'-','title':JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,'thumbnail':JFHPVqIUDWXNbuvTslOKtdyRSLmnkj}
     JFHPVqIUDWXNbuvTslOKtdyRSLmnGf=JFHPVqIUDWXNbuvTslOKtdyRSLmneC
    else:
     if JFHPVqIUDWXNbuvTslOKtdyRSLmnGe==JFHPVqIUDWXNbuvTslOKtdyRSLmneC or JFHPVqIUDWXNbuvTslOKtdyRSLmnBM==JFHPVqIUDWXNbuvTslOKtdyRSLmnec:
      JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':'EPISODE','page':'1','movie_code':JFHPVqIUDWXNbuvTslOKtdyRSLmnkf,'season_code':JFHPVqIUDWXNbuvTslOKtdyRSLmnkf,'title':JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,'thumbnail':JFHPVqIUDWXNbuvTslOKtdyRSLmnkj}
      JFHPVqIUDWXNbuvTslOKtdyRSLmnGf=JFHPVqIUDWXNbuvTslOKtdyRSLmneA
     else:
      JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':'MOVIE','movie_code':JFHPVqIUDWXNbuvTslOKtdyRSLmnBM,'season_code':JFHPVqIUDWXNbuvTslOKtdyRSLmnkf,'title':JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,'thumbnail':JFHPVqIUDWXNbuvTslOKtdyRSLmnkj}
      JFHPVqIUDWXNbuvTslOKtdyRSLmnGf=JFHPVqIUDWXNbuvTslOKtdyRSLmneC
    JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel='',img=JFHPVqIUDWXNbuvTslOKtdyRSLmnkj,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnpa,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmnGf,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpa={'plot':'시청목록을 삭제합니다.'}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGC='*** 시청목록 삭제 ***'
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGY={'mode':'MYVIEW_REMOVE','stype':JFHPVqIUDWXNbuvTslOKtdyRSLmnkp,'skey':'-',}
   JFHPVqIUDWXNbuvTslOKtdyRSLmnGo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.add_dir(JFHPVqIUDWXNbuvTslOKtdyRSLmnGC,sublabel='',img=JFHPVqIUDWXNbuvTslOKtdyRSLmnGo,infoLabels=JFHPVqIUDWXNbuvTslOKtdyRSLmnpa,isFolder=JFHPVqIUDWXNbuvTslOKtdyRSLmneC,params=JFHPVqIUDWXNbuvTslOKtdyRSLmnGY,isLink=JFHPVqIUDWXNbuvTslOKtdyRSLmneA)
   if JFHPVqIUDWXNbuvTslOKtdyRSLmnkp=='movie':xbmcplugin.setContent(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,'movies')
   else:xbmcplugin.setContent(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx._addon_handle,cacheToDisc=JFHPVqIUDWXNbuvTslOKtdyRSLmneC)
 def Save_Searched_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,JFHPVqIUDWXNbuvTslOKtdyRSLmnpw):
  try:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBo=JFHPVqIUDWXNbuvTslOKtdyRSLmnrc
   JFHPVqIUDWXNbuvTslOKtdyRSLmnpg=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.Load_List_File('search') 
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBY={'skey':JFHPVqIUDWXNbuvTslOKtdyRSLmnpw.strip()}
   fp=JFHPVqIUDWXNbuvTslOKtdyRSLmnez(JFHPVqIUDWXNbuvTslOKtdyRSLmnBo,'w',-1,'utf-8')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBe=urllib.parse.urlencode(JFHPVqIUDWXNbuvTslOKtdyRSLmnBY)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBe=JFHPVqIUDWXNbuvTslOKtdyRSLmnBe+'\n'
   fp.write(JFHPVqIUDWXNbuvTslOKtdyRSLmnBe)
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBQ=0
   for JFHPVqIUDWXNbuvTslOKtdyRSLmnBr in JFHPVqIUDWXNbuvTslOKtdyRSLmnpg:
    JFHPVqIUDWXNbuvTslOKtdyRSLmnBG=JFHPVqIUDWXNbuvTslOKtdyRSLmneM(urllib.parse.parse_qsl(JFHPVqIUDWXNbuvTslOKtdyRSLmnBr))
    JFHPVqIUDWXNbuvTslOKtdyRSLmnBc=JFHPVqIUDWXNbuvTslOKtdyRSLmnBY.get('skey').strip()
    JFHPVqIUDWXNbuvTslOKtdyRSLmnBx=JFHPVqIUDWXNbuvTslOKtdyRSLmnBG.get('skey').strip()
    if JFHPVqIUDWXNbuvTslOKtdyRSLmnBc!=JFHPVqIUDWXNbuvTslOKtdyRSLmnBx:
     fp.write(JFHPVqIUDWXNbuvTslOKtdyRSLmnBr)
     JFHPVqIUDWXNbuvTslOKtdyRSLmnBQ+=1
     if JFHPVqIUDWXNbuvTslOKtdyRSLmnBQ>=50:break
   fp.close()
  except:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnec
 def logout(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnro=xbmcgui.Dialog()
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGg=JFHPVqIUDWXNbuvTslOKtdyRSLmnro.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnGg==JFHPVqIUDWXNbuvTslOKtdyRSLmneC:sys.exit()
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.wininfo_clear()
  if os.path.isfile(JFHPVqIUDWXNbuvTslOKtdyRSLmnrQ):os.remove(JFHPVqIUDWXNbuvTslOKtdyRSLmnrQ)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ=xbmcgui.Window(10000)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_TOKEN','')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_GUIT','')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_GUITV','')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_USERCD','')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBf =JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.Get_Now_Datetime()
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBz=JFHPVqIUDWXNbuvTslOKtdyRSLmnBf+datetime.timedelta(days=JFHPVqIUDWXNbuvTslOKtdyRSLmnex(__addon__.getSetting('cache_ttl')))
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ=xbmcgui.Window(10000)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBj={'watcha_token':JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.getProperty('WATCHA_M_TOKEN'),'watcha_guit':JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.getProperty('WATCHA_M_GUIT'),'watcha_guitv':JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.getProperty('WATCHA_M_GUITV'),'watcha_usercd':JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':JFHPVqIUDWXNbuvTslOKtdyRSLmnBz.strftime('%Y-%m-%d')}
  try: 
   fp=JFHPVqIUDWXNbuvTslOKtdyRSLmnez(JFHPVqIUDWXNbuvTslOKtdyRSLmnrQ,'w',-1,'utf-8')
   json.dump(JFHPVqIUDWXNbuvTslOKtdyRSLmnBj,fp)
   fp.close()
  except JFHPVqIUDWXNbuvTslOKtdyRSLmnej as exception:
   JFHPVqIUDWXNbuvTslOKtdyRSLmneE(exception)
 def cookiefile_check(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBj={}
  try: 
   fp=JFHPVqIUDWXNbuvTslOKtdyRSLmnez(JFHPVqIUDWXNbuvTslOKtdyRSLmnrQ,'r',-1,'utf-8')
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBj= json.load(fp)
   fp.close()
  except JFHPVqIUDWXNbuvTslOKtdyRSLmnej as exception:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.wininfo_clear()
   return JFHPVqIUDWXNbuvTslOKtdyRSLmneC
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGE =__addon__.getSetting('id')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGw =__addon__.getSetting('pw')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBE =__addon__.getSetting('selected_profile')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_id']=base64.standard_b64decode(JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_id']).decode('utf-8')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_pw']=base64.standard_b64decode(JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_pw']).decode('utf-8')
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnGE!=JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_id']or JFHPVqIUDWXNbuvTslOKtdyRSLmnGw!=JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_pw']or JFHPVqIUDWXNbuvTslOKtdyRSLmnBE!=JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_profile']:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.wininfo_clear()
   return JFHPVqIUDWXNbuvTslOKtdyRSLmneC
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkr =JFHPVqIUDWXNbuvTslOKtdyRSLmnex(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBw=JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_limitdate']
  JFHPVqIUDWXNbuvTslOKtdyRSLmnkG =JFHPVqIUDWXNbuvTslOKtdyRSLmnex(re.sub('-','',JFHPVqIUDWXNbuvTslOKtdyRSLmnBw))
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnkG<JFHPVqIUDWXNbuvTslOKtdyRSLmnkr:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.wininfo_clear()
   return JFHPVqIUDWXNbuvTslOKtdyRSLmneC
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ=xbmcgui.Window(10000)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_TOKEN',JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_token'])
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_GUIT',JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_guit'])
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_GUITV',JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_guitv'])
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_USERCD',JFHPVqIUDWXNbuvTslOKtdyRSLmnBj['watcha_usercd'])
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGQ.setProperty('WATCHA_M_LOGINTIME',JFHPVqIUDWXNbuvTslOKtdyRSLmnBw)
  return JFHPVqIUDWXNbuvTslOKtdyRSLmneA
 def dp_Global_Search(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=args.get('mode')
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=='TOTAL_SEARCH':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBg='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnBg='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(JFHPVqIUDWXNbuvTslOKtdyRSLmnBg)
 def dp_Bookmark_Menu(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBg='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(JFHPVqIUDWXNbuvTslOKtdyRSLmnBg)
 def dp_Set_Bookmark(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx,args):
  JFHPVqIUDWXNbuvTslOKtdyRSLmner=urllib.parse.unquote(args.get('bm_param'))
  JFHPVqIUDWXNbuvTslOKtdyRSLmner=json.loads(JFHPVqIUDWXNbuvTslOKtdyRSLmner)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBM =JFHPVqIUDWXNbuvTslOKtdyRSLmner.get('videoid')
  JFHPVqIUDWXNbuvTslOKtdyRSLmneG =JFHPVqIUDWXNbuvTslOKtdyRSLmner.get('vidtype')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnek =JFHPVqIUDWXNbuvTslOKtdyRSLmner.get('vtitle')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnea =JFHPVqIUDWXNbuvTslOKtdyRSLmner.get('vsubtitle')
  JFHPVqIUDWXNbuvTslOKtdyRSLmnro=xbmcgui.Dialog()
  JFHPVqIUDWXNbuvTslOKtdyRSLmnGg=JFHPVqIUDWXNbuvTslOKtdyRSLmnro.yesno(__language__(30913).encode('utf8'),JFHPVqIUDWXNbuvTslOKtdyRSLmnek+' \n\n'+__language__(30914))
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnGg==JFHPVqIUDWXNbuvTslOKtdyRSLmneC:return
  JFHPVqIUDWXNbuvTslOKtdyRSLmnep=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.WatchaObj.GetBookmarkInfo(JFHPVqIUDWXNbuvTslOKtdyRSLmnBM,JFHPVqIUDWXNbuvTslOKtdyRSLmneG)
  JFHPVqIUDWXNbuvTslOKtdyRSLmneB=json.dumps(JFHPVqIUDWXNbuvTslOKtdyRSLmnep)
  JFHPVqIUDWXNbuvTslOKtdyRSLmneB=urllib.parse.quote(JFHPVqIUDWXNbuvTslOKtdyRSLmneB)
  JFHPVqIUDWXNbuvTslOKtdyRSLmnpQ ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(JFHPVqIUDWXNbuvTslOKtdyRSLmneB)
  xbmc.executebuiltin(JFHPVqIUDWXNbuvTslOKtdyRSLmnpQ)
 def watcha_main(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx):
  JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params.get('mode',JFHPVqIUDWXNbuvTslOKtdyRSLmnec)
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=='LOGOUT':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.logout()
   return
  JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.login_main()
  if JFHPVqIUDWXNbuvTslOKtdyRSLmnBi is JFHPVqIUDWXNbuvTslOKtdyRSLmnec:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_Main_List()
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=='SUB_GROUP':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_SubGroup_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=='CATEGORY_LIST':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_Category_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=='EPISODE':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_Episode_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=='ORDER_BY':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_setEpOrderby(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi in['SEARCH','LOCAL_SEARCH']:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_Search_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=='MOVIE':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.play_VIDEO(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=='WATCH':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_Watch_List(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_Listfile_Delete(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi in['TOTAL_SEARCH','TOTAL_HISTORY']:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_Global_Search(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=='SEARCH_HISTORY':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_Search_History(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=='MENU_BOOKMARK':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_Bookmark_Menu(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  elif JFHPVqIUDWXNbuvTslOKtdyRSLmnBi=='SET_BOOKMARK':
   JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.dp_Set_Bookmark(JFHPVqIUDWXNbuvTslOKtdyRSLmnrx.main_params)
  else:
   JFHPVqIUDWXNbuvTslOKtdyRSLmnec
# Created by pyminifier (https://github.com/liftoff/pyminifier)
