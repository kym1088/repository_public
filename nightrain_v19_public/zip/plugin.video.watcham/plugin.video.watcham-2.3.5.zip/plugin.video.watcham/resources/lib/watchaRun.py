__author__="NightRain"
wXhecGJrYgaWHzDvEymAPNuntQKCix=object
wXhecGJrYgaWHzDvEymAPNuntQKCiq=None
wXhecGJrYgaWHzDvEymAPNuntQKCif=int
wXhecGJrYgaWHzDvEymAPNuntQKCio=True
wXhecGJrYgaWHzDvEymAPNuntQKCiB=False
wXhecGJrYgaWHzDvEymAPNuntQKCiS=type
wXhecGJrYgaWHzDvEymAPNuntQKCiL=dict
wXhecGJrYgaWHzDvEymAPNuntQKCiT=getattr
wXhecGJrYgaWHzDvEymAPNuntQKCil=list
wXhecGJrYgaWHzDvEymAPNuntQKCiI=len
wXhecGJrYgaWHzDvEymAPNuntQKCid=range
wXhecGJrYgaWHzDvEymAPNuntQKCik=str
wXhecGJrYgaWHzDvEymAPNuntQKCib=open
from ast import Pass
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
wXhecGJrYgaWHzDvEymAPNuntQKCRM=[{'title':'홈','mode':'HOME_GROUP','stype':'-','api_path':'-'},{'title':'오직 왓챠에서!','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/6100'},{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409'},{'title':'4K / HDR, ATOMOS 지원작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/3025'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest'},{'title':'장르별 둘러보기','mode':'SUB_GROUP','stype':'genres','api_path':'-'},{'title':'특징별 둘러보기','mode':'SUB_GROUP','stype':'tags','api_path':'-'},{'title':'이어보기 (시청이력)','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','icon':'bookmark.png'},]
wXhecGJrYgaWHzDvEymAPNuntQKCRs=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
wXhecGJrYgaWHzDvEymAPNuntQKCRF={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
wXhecGJrYgaWHzDvEymAPNuntQKCRj=40
wXhecGJrYgaWHzDvEymAPNuntQKCRV =30
from watchaCore import*
class wXhecGJrYgaWHzDvEymAPNuntQKCRU(wXhecGJrYgaWHzDvEymAPNuntQKCix):
 def __init__(wXhecGJrYgaWHzDvEymAPNuntQKCRi,wXhecGJrYgaWHzDvEymAPNuntQKCRO,wXhecGJrYgaWHzDvEymAPNuntQKCRx,wXhecGJrYgaWHzDvEymAPNuntQKCRq):
  wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_url =wXhecGJrYgaWHzDvEymAPNuntQKCRO
  wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle=wXhecGJrYgaWHzDvEymAPNuntQKCRx
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params =wXhecGJrYgaWHzDvEymAPNuntQKCRq
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj =rTqGAoykOQwfBEHDVcmuNjXdhliMnJ() 
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_SUBTITLE_VTT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_SUBTITLE_SRT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.srt'))
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_COOKIE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_SEARCHEDC_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wc_stream.mpd'))
 def addon_noti(wXhecGJrYgaWHzDvEymAPNuntQKCRi,sting):
  try:
   wXhecGJrYgaWHzDvEymAPNuntQKCRo=xbmcgui.Dialog()
   wXhecGJrYgaWHzDvEymAPNuntQKCRo.notification(__addonname__,sting)
  except:
   wXhecGJrYgaWHzDvEymAPNuntQKCiq
 def addon_log(wXhecGJrYgaWHzDvEymAPNuntQKCRi,string):
  try:
   wXhecGJrYgaWHzDvEymAPNuntQKCRB=string.encode('utf-8','ignore')
  except:
   wXhecGJrYgaWHzDvEymAPNuntQKCRB='addonException: addon_log'
  wXhecGJrYgaWHzDvEymAPNuntQKCRS=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,wXhecGJrYgaWHzDvEymAPNuntQKCRB),level=wXhecGJrYgaWHzDvEymAPNuntQKCRS)
 def get_keyboard_input(wXhecGJrYgaWHzDvEymAPNuntQKCRi,wXhecGJrYgaWHzDvEymAPNuntQKCUL):
  wXhecGJrYgaWHzDvEymAPNuntQKCRL=wXhecGJrYgaWHzDvEymAPNuntQKCiq
  kb=xbmc.Keyboard()
  kb.setHeading(wXhecGJrYgaWHzDvEymAPNuntQKCUL)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   wXhecGJrYgaWHzDvEymAPNuntQKCRL=kb.getText()
  return wXhecGJrYgaWHzDvEymAPNuntQKCRL
 def get_settings_account(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  wXhecGJrYgaWHzDvEymAPNuntQKCRT =__addon__.getSetting('id')
  wXhecGJrYgaWHzDvEymAPNuntQKCRl =__addon__.getSetting('pw')
  wXhecGJrYgaWHzDvEymAPNuntQKCRI=wXhecGJrYgaWHzDvEymAPNuntQKCif(__addon__.getSetting('selected_profile'))
  return(wXhecGJrYgaWHzDvEymAPNuntQKCRT,wXhecGJrYgaWHzDvEymAPNuntQKCRl,wXhecGJrYgaWHzDvEymAPNuntQKCRI)
 def get_settings_totalsearch(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  wXhecGJrYgaWHzDvEymAPNuntQKCRd =wXhecGJrYgaWHzDvEymAPNuntQKCio if __addon__.getSetting('local_search')=='true' else wXhecGJrYgaWHzDvEymAPNuntQKCiB
  wXhecGJrYgaWHzDvEymAPNuntQKCRk=wXhecGJrYgaWHzDvEymAPNuntQKCio if __addon__.getSetting('local_history')=='true' else wXhecGJrYgaWHzDvEymAPNuntQKCiB
  wXhecGJrYgaWHzDvEymAPNuntQKCRb =wXhecGJrYgaWHzDvEymAPNuntQKCio if __addon__.getSetting('total_search')=='true' else wXhecGJrYgaWHzDvEymAPNuntQKCiB
  wXhecGJrYgaWHzDvEymAPNuntQKCRp=wXhecGJrYgaWHzDvEymAPNuntQKCio if __addon__.getSetting('total_history')=='true' else wXhecGJrYgaWHzDvEymAPNuntQKCiB
  wXhecGJrYgaWHzDvEymAPNuntQKCUR=wXhecGJrYgaWHzDvEymAPNuntQKCio if __addon__.getSetting('menu_bookmark')=='true' else wXhecGJrYgaWHzDvEymAPNuntQKCiB
  return(wXhecGJrYgaWHzDvEymAPNuntQKCRd,wXhecGJrYgaWHzDvEymAPNuntQKCRk,wXhecGJrYgaWHzDvEymAPNuntQKCRb,wXhecGJrYgaWHzDvEymAPNuntQKCRp,wXhecGJrYgaWHzDvEymAPNuntQKCUR)
 def get_settings_makebookmark(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  return wXhecGJrYgaWHzDvEymAPNuntQKCio if __addon__.getSetting('make_bookmark')=='true' else wXhecGJrYgaWHzDvEymAPNuntQKCiB
 def get_settings_proxyport(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  wXhecGJrYgaWHzDvEymAPNuntQKCUM =wXhecGJrYgaWHzDvEymAPNuntQKCio if __addon__.getSetting('proxyYn')=='true' else wXhecGJrYgaWHzDvEymAPNuntQKCiB
  wXhecGJrYgaWHzDvEymAPNuntQKCUs=wXhecGJrYgaWHzDvEymAPNuntQKCif(__addon__.getSetting('proxyPort'))
  return wXhecGJrYgaWHzDvEymAPNuntQKCUM,wXhecGJrYgaWHzDvEymAPNuntQKCUs
 def get_settings_playback(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  wXhecGJrYgaWHzDvEymAPNuntQKCUF=[3840,1920,1280]
  wXhecGJrYgaWHzDvEymAPNuntQKCUj =['BASE','HDR','VISION']
  wXhecGJrYgaWHzDvEymAPNuntQKCUV =['2CH','6CH','ATMOS']
  wXhecGJrYgaWHzDvEymAPNuntQKCUi=wXhecGJrYgaWHzDvEymAPNuntQKCif(__addon__.getSetting('selected_quality'))
  wXhecGJrYgaWHzDvEymAPNuntQKCUO =wXhecGJrYgaWHzDvEymAPNuntQKCif(__addon__.getSetting('selected_screen'))
  wXhecGJrYgaWHzDvEymAPNuntQKCUx =wXhecGJrYgaWHzDvEymAPNuntQKCif(__addon__.getSetting('selected_sound'))
  wXhecGJrYgaWHzDvEymAPNuntQKCUq={'max_quality':wXhecGJrYgaWHzDvEymAPNuntQKCUF[wXhecGJrYgaWHzDvEymAPNuntQKCUi],'sel_screen':wXhecGJrYgaWHzDvEymAPNuntQKCUj[wXhecGJrYgaWHzDvEymAPNuntQKCUO],'sel_sound':wXhecGJrYgaWHzDvEymAPNuntQKCUV[wXhecGJrYgaWHzDvEymAPNuntQKCUx],'streamFilename':wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_STREAM_FILENAME,}
  return wXhecGJrYgaWHzDvEymAPNuntQKCUq
 def Base64_Encode(wXhecGJrYgaWHzDvEymAPNuntQKCRi,plaintext):
  return base64.standard_b64encode(plaintext.encode()).decode('utf-8')
 def Params_JsonToStr(wXhecGJrYgaWHzDvEymAPNuntQKCRi,paramJson):
  wXhecGJrYgaWHzDvEymAPNuntQKCUf=json.dumps(paramJson,separators=(',',':'))
  wXhecGJrYgaWHzDvEymAPNuntQKCUf=wXhecGJrYgaWHzDvEymAPNuntQKCRi.Base64_Encode(wXhecGJrYgaWHzDvEymAPNuntQKCUf)
  return wXhecGJrYgaWHzDvEymAPNuntQKCUf
 def get_selQuality(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  try:
   wXhecGJrYgaWHzDvEymAPNuntQKCUF=['3840x2160/2.0/320/xhdpi','1920x1080/2.0/320/xhdpi','1280x720/2.0/320/xhdpi']
   wXhecGJrYgaWHzDvEymAPNuntQKCUi=wXhecGJrYgaWHzDvEymAPNuntQKCif(__addon__.getSetting('selected_quality'))
   return wXhecGJrYgaWHzDvEymAPNuntQKCUF[wXhecGJrYgaWHzDvEymAPNuntQKCUi]
  except:
   wXhecGJrYgaWHzDvEymAPNuntQKCiq
  return 1080 
 def get_settings_direct_replay(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  wXhecGJrYgaWHzDvEymAPNuntQKCUo=wXhecGJrYgaWHzDvEymAPNuntQKCif(__addon__.getSetting('direct_replay'))
  if wXhecGJrYgaWHzDvEymAPNuntQKCUo==0:
   return wXhecGJrYgaWHzDvEymAPNuntQKCiB
  else:
   return wXhecGJrYgaWHzDvEymAPNuntQKCio
 def set_winEpisodeOrderby(wXhecGJrYgaWHzDvEymAPNuntQKCRi,wXhecGJrYgaWHzDvEymAPNuntQKCUB):
  __addon__.setSetting('watcha_orderby',wXhecGJrYgaWHzDvEymAPNuntQKCUB)
 def get_winEpisodeOrderby(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  wXhecGJrYgaWHzDvEymAPNuntQKCUB=__addon__.getSetting('watcha_orderby')
  if wXhecGJrYgaWHzDvEymAPNuntQKCUB in['',wXhecGJrYgaWHzDvEymAPNuntQKCiq]:wXhecGJrYgaWHzDvEymAPNuntQKCUB='asc'
  return wXhecGJrYgaWHzDvEymAPNuntQKCUB
 def dp_setEpOrderby(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCUB =args.get('orderby')
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.set_winEpisodeOrderby(wXhecGJrYgaWHzDvEymAPNuntQKCUB)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCRi,label,sublabel='',img='',infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCiq,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCio,params='',isLink=wXhecGJrYgaWHzDvEymAPNuntQKCiB,ContextMenu=wXhecGJrYgaWHzDvEymAPNuntQKCiq):
  wXhecGJrYgaWHzDvEymAPNuntQKCUS='%s?%s'%(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_url,urllib.parse.urlencode(params))
  if sublabel:wXhecGJrYgaWHzDvEymAPNuntQKCUL='%s < %s >'%(label,sublabel)
  else: wXhecGJrYgaWHzDvEymAPNuntQKCUL=label
  if not img:img='DefaultFolder.png'
  wXhecGJrYgaWHzDvEymAPNuntQKCUT=xbmcgui.ListItem(wXhecGJrYgaWHzDvEymAPNuntQKCUL)
  if wXhecGJrYgaWHzDvEymAPNuntQKCiS(img)==wXhecGJrYgaWHzDvEymAPNuntQKCiL:
   wXhecGJrYgaWHzDvEymAPNuntQKCUT.setArt(img)
  else:
   wXhecGJrYgaWHzDvEymAPNuntQKCUT.setArt({'thumb':img,'poster':img})
  if wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.KodiVersion>=20:
   if infoLabels:wXhecGJrYgaWHzDvEymAPNuntQKCRi.Set_InfoTag(wXhecGJrYgaWHzDvEymAPNuntQKCUT.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:wXhecGJrYgaWHzDvEymAPNuntQKCUT.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   wXhecGJrYgaWHzDvEymAPNuntQKCUT.setProperty('IsPlayable','true')
  if ContextMenu:wXhecGJrYgaWHzDvEymAPNuntQKCUT.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,wXhecGJrYgaWHzDvEymAPNuntQKCUS,wXhecGJrYgaWHzDvEymAPNuntQKCUT,isFolder)
 def Set_InfoTag(wXhecGJrYgaWHzDvEymAPNuntQKCRi,video_InfoTag:xbmc.InfoTagVideo,wXhecGJrYgaWHzDvEymAPNuntQKCMU):
  for wXhecGJrYgaWHzDvEymAPNuntQKCUl,value in wXhecGJrYgaWHzDvEymAPNuntQKCMU.items():
   if wXhecGJrYgaWHzDvEymAPNuntQKCRF[wXhecGJrYgaWHzDvEymAPNuntQKCUl]['type']=='string':
    wXhecGJrYgaWHzDvEymAPNuntQKCiT(video_InfoTag,wXhecGJrYgaWHzDvEymAPNuntQKCRF[wXhecGJrYgaWHzDvEymAPNuntQKCUl]['func'])(value)
   elif wXhecGJrYgaWHzDvEymAPNuntQKCRF[wXhecGJrYgaWHzDvEymAPNuntQKCUl]['type']=='int':
    if wXhecGJrYgaWHzDvEymAPNuntQKCiS(value)==wXhecGJrYgaWHzDvEymAPNuntQKCif:
     wXhecGJrYgaWHzDvEymAPNuntQKCUI=wXhecGJrYgaWHzDvEymAPNuntQKCif(value)
    else:
     wXhecGJrYgaWHzDvEymAPNuntQKCUI=0
    wXhecGJrYgaWHzDvEymAPNuntQKCiT(video_InfoTag,wXhecGJrYgaWHzDvEymAPNuntQKCRF[wXhecGJrYgaWHzDvEymAPNuntQKCUl]['func'])(wXhecGJrYgaWHzDvEymAPNuntQKCUI)
   elif wXhecGJrYgaWHzDvEymAPNuntQKCRF[wXhecGJrYgaWHzDvEymAPNuntQKCUl]['type']=='actor':
    if value!=[]:
     wXhecGJrYgaWHzDvEymAPNuntQKCiT(video_InfoTag,wXhecGJrYgaWHzDvEymAPNuntQKCRF[wXhecGJrYgaWHzDvEymAPNuntQKCUl]['func'])([xbmc.Actor(name)for name in value])
   elif wXhecGJrYgaWHzDvEymAPNuntQKCRF[wXhecGJrYgaWHzDvEymAPNuntQKCUl]['type']=='list':
    if wXhecGJrYgaWHzDvEymAPNuntQKCiS(value)==wXhecGJrYgaWHzDvEymAPNuntQKCil:
     wXhecGJrYgaWHzDvEymAPNuntQKCiT(video_InfoTag,wXhecGJrYgaWHzDvEymAPNuntQKCRF[wXhecGJrYgaWHzDvEymAPNuntQKCUl]['func'])(value)
    else:
     wXhecGJrYgaWHzDvEymAPNuntQKCiT(video_InfoTag,wXhecGJrYgaWHzDvEymAPNuntQKCRF[wXhecGJrYgaWHzDvEymAPNuntQKCUl]['func'])([value])
 def dp_Main_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  (wXhecGJrYgaWHzDvEymAPNuntQKCRd,wXhecGJrYgaWHzDvEymAPNuntQKCRk,wXhecGJrYgaWHzDvEymAPNuntQKCRb,wXhecGJrYgaWHzDvEymAPNuntQKCRp,wXhecGJrYgaWHzDvEymAPNuntQKCUR)=wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_settings_totalsearch()
  for wXhecGJrYgaWHzDvEymAPNuntQKCUd in wXhecGJrYgaWHzDvEymAPNuntQKCRM:
   wXhecGJrYgaWHzDvEymAPNuntQKCUL=wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('title')
   wXhecGJrYgaWHzDvEymAPNuntQKCUk=''
   if wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('mode')=='LOCAL_SEARCH' and wXhecGJrYgaWHzDvEymAPNuntQKCRd ==wXhecGJrYgaWHzDvEymAPNuntQKCiB:continue
   elif wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('mode')=='SEARCH_HISTORY' and wXhecGJrYgaWHzDvEymAPNuntQKCRk==wXhecGJrYgaWHzDvEymAPNuntQKCiB:continue
   elif wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('mode')=='TOTAL_SEARCH' and wXhecGJrYgaWHzDvEymAPNuntQKCRb ==wXhecGJrYgaWHzDvEymAPNuntQKCiB:continue
   elif wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('mode')=='TOTAL_HISTORY' and wXhecGJrYgaWHzDvEymAPNuntQKCRp==wXhecGJrYgaWHzDvEymAPNuntQKCiB:continue
   elif wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('mode')=='MENU_BOOKMARK' and wXhecGJrYgaWHzDvEymAPNuntQKCUR==wXhecGJrYgaWHzDvEymAPNuntQKCiB:continue
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('mode'),'stype':wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('stype'),'api_path':wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('api_path'),'page':'1','tag_id':'-',}
   if wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('mode')=='LOCAL_SEARCH':wXhecGJrYgaWHzDvEymAPNuntQKCUb['historyyn']='Y' 
   if wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    wXhecGJrYgaWHzDvEymAPNuntQKCUp=wXhecGJrYgaWHzDvEymAPNuntQKCiB
    wXhecGJrYgaWHzDvEymAPNuntQKCMR =wXhecGJrYgaWHzDvEymAPNuntQKCio
   else:
    wXhecGJrYgaWHzDvEymAPNuntQKCUp=wXhecGJrYgaWHzDvEymAPNuntQKCio
    wXhecGJrYgaWHzDvEymAPNuntQKCMR =wXhecGJrYgaWHzDvEymAPNuntQKCiB
   wXhecGJrYgaWHzDvEymAPNuntQKCMU={'title':wXhecGJrYgaWHzDvEymAPNuntQKCUL,'plot':wXhecGJrYgaWHzDvEymAPNuntQKCUL}
   if wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('mode')=='XXX':wXhecGJrYgaWHzDvEymAPNuntQKCMU=wXhecGJrYgaWHzDvEymAPNuntQKCiq
   if 'icon' in wXhecGJrYgaWHzDvEymAPNuntQKCUd:wXhecGJrYgaWHzDvEymAPNuntQKCUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',wXhecGJrYgaWHzDvEymAPNuntQKCUd.get('icon')) 
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel='',img=wXhecGJrYgaWHzDvEymAPNuntQKCUk,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCMU,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCUp,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb,isLink=wXhecGJrYgaWHzDvEymAPNuntQKCMR)
  xbmcplugin.endOfDirectory(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle)
 def login_main(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  (wXhecGJrYgaWHzDvEymAPNuntQKCMF,wXhecGJrYgaWHzDvEymAPNuntQKCMj,wXhecGJrYgaWHzDvEymAPNuntQKCMV)=wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_settings_account()
  if not(wXhecGJrYgaWHzDvEymAPNuntQKCMF and wXhecGJrYgaWHzDvEymAPNuntQKCMj):
   wXhecGJrYgaWHzDvEymAPNuntQKCRo=xbmcgui.Dialog()
   wXhecGJrYgaWHzDvEymAPNuntQKCMi=wXhecGJrYgaWHzDvEymAPNuntQKCRo.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if wXhecGJrYgaWHzDvEymAPNuntQKCMi==wXhecGJrYgaWHzDvEymAPNuntQKCio:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if wXhecGJrYgaWHzDvEymAPNuntQKCRi.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   wXhecGJrYgaWHzDvEymAPNuntQKCMO=0
   while wXhecGJrYgaWHzDvEymAPNuntQKCio:
    wXhecGJrYgaWHzDvEymAPNuntQKCMO+=1
    time.sleep(0.05)
    if wXhecGJrYgaWHzDvEymAPNuntQKCMO>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  wXhecGJrYgaWHzDvEymAPNuntQKCMx=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.GetCredential(wXhecGJrYgaWHzDvEymAPNuntQKCMF,wXhecGJrYgaWHzDvEymAPNuntQKCMj,wXhecGJrYgaWHzDvEymAPNuntQKCMV)
  if wXhecGJrYgaWHzDvEymAPNuntQKCMx:wXhecGJrYgaWHzDvEymAPNuntQKCRi.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
  if wXhecGJrYgaWHzDvEymAPNuntQKCMx==wXhecGJrYgaWHzDvEymAPNuntQKCiB:
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_HomeGroup_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCMq=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.GetHomeList()
  for wXhecGJrYgaWHzDvEymAPNuntQKCMf in wXhecGJrYgaWHzDvEymAPNuntQKCMq:
   wXhecGJrYgaWHzDvEymAPNuntQKCMo =wXhecGJrYgaWHzDvEymAPNuntQKCMf.get('code')
   wXhecGJrYgaWHzDvEymAPNuntQKCMB=wXhecGJrYgaWHzDvEymAPNuntQKCMf.get('content_type')
   wXhecGJrYgaWHzDvEymAPNuntQKCUL =wXhecGJrYgaWHzDvEymAPNuntQKCMf.get('title')
   if wXhecGJrYgaWHzDvEymAPNuntQKCMB=='staffmades':
    wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':'CATEGORY_LIST','api_path':'staffmades/'+wXhecGJrYgaWHzDvEymAPNuntQKCMo,'page':'1',}
    wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel=wXhecGJrYgaWHzDvEymAPNuntQKCiq,img=wXhecGJrYgaWHzDvEymAPNuntQKCiq,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCiq,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCio,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb)
   else:
    wXhecGJrYgaWHzDvEymAPNuntQKCMS
  xbmcplugin.endOfDirectory(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,cacheToDisc=wXhecGJrYgaWHzDvEymAPNuntQKCio)
 def dp_SubGroup_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCMT =args.get('stype')
  wXhecGJrYgaWHzDvEymAPNuntQKCMl =wXhecGJrYgaWHzDvEymAPNuntQKCif(args.get('page'))
  wXhecGJrYgaWHzDvEymAPNuntQKCMI=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.GetSubGroupList(wXhecGJrYgaWHzDvEymAPNuntQKCMT)
  wXhecGJrYgaWHzDvEymAPNuntQKCMd=wXhecGJrYgaWHzDvEymAPNuntQKCRj if wXhecGJrYgaWHzDvEymAPNuntQKCMT=='genres' else wXhecGJrYgaWHzDvEymAPNuntQKCRV
  wXhecGJrYgaWHzDvEymAPNuntQKCMk=wXhecGJrYgaWHzDvEymAPNuntQKCiI(wXhecGJrYgaWHzDvEymAPNuntQKCMI)
  wXhecGJrYgaWHzDvEymAPNuntQKCMb =wXhecGJrYgaWHzDvEymAPNuntQKCif(wXhecGJrYgaWHzDvEymAPNuntQKCMk//(wXhecGJrYgaWHzDvEymAPNuntQKCMd+1))+1
  wXhecGJrYgaWHzDvEymAPNuntQKCMp =(wXhecGJrYgaWHzDvEymAPNuntQKCMl-1)*wXhecGJrYgaWHzDvEymAPNuntQKCMd
  for i in wXhecGJrYgaWHzDvEymAPNuntQKCid(wXhecGJrYgaWHzDvEymAPNuntQKCMd):
   wXhecGJrYgaWHzDvEymAPNuntQKCsR=wXhecGJrYgaWHzDvEymAPNuntQKCMp+i
   if wXhecGJrYgaWHzDvEymAPNuntQKCsR>=wXhecGJrYgaWHzDvEymAPNuntQKCMk:break
   wXhecGJrYgaWHzDvEymAPNuntQKCUL =wXhecGJrYgaWHzDvEymAPNuntQKCMI[wXhecGJrYgaWHzDvEymAPNuntQKCsR].get('group_name')
   wXhecGJrYgaWHzDvEymAPNuntQKCsU =wXhecGJrYgaWHzDvEymAPNuntQKCMI[wXhecGJrYgaWHzDvEymAPNuntQKCsR].get('api_path')
   wXhecGJrYgaWHzDvEymAPNuntQKCsM =wXhecGJrYgaWHzDvEymAPNuntQKCMI[wXhecGJrYgaWHzDvEymAPNuntQKCsR].get('tag_id')
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':'CATEGORY_LIST','api_path':wXhecGJrYgaWHzDvEymAPNuntQKCsU,'tag_id':wXhecGJrYgaWHzDvEymAPNuntQKCsM,'stype':wXhecGJrYgaWHzDvEymAPNuntQKCMT,'page':'1',}
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel='',img='',infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCiq,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCio,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb)
  if wXhecGJrYgaWHzDvEymAPNuntQKCMb>wXhecGJrYgaWHzDvEymAPNuntQKCMl:
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={}
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['mode'] ='SUB_GROUP' 
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['stype'] =wXhecGJrYgaWHzDvEymAPNuntQKCMT
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['api_path']=args.get('api_path')
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['page'] =wXhecGJrYgaWHzDvEymAPNuntQKCik(wXhecGJrYgaWHzDvEymAPNuntQKCMl+1)
   wXhecGJrYgaWHzDvEymAPNuntQKCUL='[B]%s >>[/B]'%'다음 페이지'
   wXhecGJrYgaWHzDvEymAPNuntQKCsF=wXhecGJrYgaWHzDvEymAPNuntQKCik(wXhecGJrYgaWHzDvEymAPNuntQKCMl+1)
   wXhecGJrYgaWHzDvEymAPNuntQKCUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel=wXhecGJrYgaWHzDvEymAPNuntQKCsF,img=wXhecGJrYgaWHzDvEymAPNuntQKCUk,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCiq,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCio,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb)
  if wXhecGJrYgaWHzDvEymAPNuntQKCiI(wXhecGJrYgaWHzDvEymAPNuntQKCMI)>0:xbmcplugin.endOfDirectory(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,cacheToDisc=wXhecGJrYgaWHzDvEymAPNuntQKCio)
 def play_VIDEO(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCsj =args.get('movie_code')
  wXhecGJrYgaWHzDvEymAPNuntQKCsV =args.get('season_code')
  wXhecGJrYgaWHzDvEymAPNuntQKCUL =args.get('title')
  wXhecGJrYgaWHzDvEymAPNuntQKCsi =args.get('thumbnail')
  wXhecGJrYgaWHzDvEymAPNuntQKCsO =wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_selQuality()
  wXhecGJrYgaWHzDvEymAPNuntQKCUM,wXhecGJrYgaWHzDvEymAPNuntQKCUs=wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_settings_proxyport()
  wXhecGJrYgaWHzDvEymAPNuntQKCUq=wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_settings_playback()
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.addon_log('movie_code  : '+wXhecGJrYgaWHzDvEymAPNuntQKCsj)
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.addon_log('quality_str : '+wXhecGJrYgaWHzDvEymAPNuntQKCsO)
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.addon_log('playOption[sel_screen]  : '+wXhecGJrYgaWHzDvEymAPNuntQKCUq['sel_screen'])
  wXhecGJrYgaWHzDvEymAPNuntQKCsx=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.GetStreamingURL(wXhecGJrYgaWHzDvEymAPNuntQKCsj,wXhecGJrYgaWHzDvEymAPNuntQKCsO,proxyUse=wXhecGJrYgaWHzDvEymAPNuntQKCUM,inScreen=wXhecGJrYgaWHzDvEymAPNuntQKCUq['sel_screen'],inSound=wXhecGJrYgaWHzDvEymAPNuntQKCUq['sel_sound'])
  if wXhecGJrYgaWHzDvEymAPNuntQKCsx['streamUrl']=='':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.addon_noti(__language__(30908).encode('utf8'))
   return
  wXhecGJrYgaWHzDvEymAPNuntQKCsq=wXhecGJrYgaWHzDvEymAPNuntQKCsx['streamUrl']
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.addon_log(wXhecGJrYgaWHzDvEymAPNuntQKCsq)
  if wXhecGJrYgaWHzDvEymAPNuntQKCUM:
   wXhecGJrYgaWHzDvEymAPNuntQKCsf={'addon':'watcham','playOption':wXhecGJrYgaWHzDvEymAPNuntQKCUq,}
   wXhecGJrYgaWHzDvEymAPNuntQKCsf=wXhecGJrYgaWHzDvEymAPNuntQKCRi.Params_JsonToStr(wXhecGJrYgaWHzDvEymAPNuntQKCsf)
   wXhecGJrYgaWHzDvEymAPNuntQKCsq='http://127.0.0.1:{}/{}|proxy-mini={}'.format(wXhecGJrYgaWHzDvEymAPNuntQKCUs,wXhecGJrYgaWHzDvEymAPNuntQKCsq,wXhecGJrYgaWHzDvEymAPNuntQKCsf)
  wXhecGJrYgaWHzDvEymAPNuntQKCso=xbmcgui.ListItem(path=wXhecGJrYgaWHzDvEymAPNuntQKCsq)
  if wXhecGJrYgaWHzDvEymAPNuntQKCsx['customdata']:
   wXhecGJrYgaWHzDvEymAPNuntQKCsB=wXhecGJrYgaWHzDvEymAPNuntQKCsx['customdata']
   wXhecGJrYgaWHzDvEymAPNuntQKCsS ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   wXhecGJrYgaWHzDvEymAPNuntQKCsL ='mpd'
   wXhecGJrYgaWHzDvEymAPNuntQKCsT ='com.widevine.alpha'
   inputstreamhelper.Helper(wXhecGJrYgaWHzDvEymAPNuntQKCsL,drm=wXhecGJrYgaWHzDvEymAPNuntQKCsT).check_inputstream()
   wXhecGJrYgaWHzDvEymAPNuntQKCsI={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+wXhecGJrYgaWHzDvEymAPNuntQKCsj,'dt-custom-data':wXhecGJrYgaWHzDvEymAPNuntQKCsB,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream',}
   wXhecGJrYgaWHzDvEymAPNuntQKCsd=wXhecGJrYgaWHzDvEymAPNuntQKCsS+'|'+urllib.parse.urlencode(wXhecGJrYgaWHzDvEymAPNuntQKCsI)+'|R{SSM}|'
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.addon_log(wXhecGJrYgaWHzDvEymAPNuntQKCsd)
   wXhecGJrYgaWHzDvEymAPNuntQKCso.setProperty('inputstream','inputstream.adaptive')
   wXhecGJrYgaWHzDvEymAPNuntQKCso.setProperty('inputstream.adaptive.manifest_type',wXhecGJrYgaWHzDvEymAPNuntQKCsL)
   wXhecGJrYgaWHzDvEymAPNuntQKCso.setProperty('inputstream.adaptive.license_type',wXhecGJrYgaWHzDvEymAPNuntQKCsT)
   wXhecGJrYgaWHzDvEymAPNuntQKCso.setProperty('inputstream.adaptive.license_key',wXhecGJrYgaWHzDvEymAPNuntQKCsd)
   wXhecGJrYgaWHzDvEymAPNuntQKCso.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.USER_AGENT))
  if wXhecGJrYgaWHzDvEymAPNuntQKCsx['subtitleUrl']:
   try:
    f=wXhecGJrYgaWHzDvEymAPNuntQKCib(wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_SUBTITLE_VTT,'w',-1,'utf-8')
    wXhecGJrYgaWHzDvEymAPNuntQKCsk=requests.get(wXhecGJrYgaWHzDvEymAPNuntQKCsx['subtitleUrl'])
    wXhecGJrYgaWHzDvEymAPNuntQKCsb=wXhecGJrYgaWHzDvEymAPNuntQKCsk.content.decode('utf-8') 
    for wXhecGJrYgaWHzDvEymAPNuntQKCsp in wXhecGJrYgaWHzDvEymAPNuntQKCsb.splitlines():
     wXhecGJrYgaWHzDvEymAPNuntQKCFR=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',wXhecGJrYgaWHzDvEymAPNuntQKCsp)
     f.write(wXhecGJrYgaWHzDvEymAPNuntQKCFR+'\n')
    f.close()
    wXhecGJrYgaWHzDvEymAPNuntQKCso.setSubtitles([wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_SUBTITLE_VTT,wXhecGJrYgaWHzDvEymAPNuntQKCsx['subtitleUrl']])
   except:
    wXhecGJrYgaWHzDvEymAPNuntQKCso.setSubtitles([wXhecGJrYgaWHzDvEymAPNuntQKCsx['subtitleUrl']])
  xbmcplugin.setResolvedUrl(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,wXhecGJrYgaWHzDvEymAPNuntQKCio,wXhecGJrYgaWHzDvEymAPNuntQKCso)
  try:
   wXhecGJrYgaWHzDvEymAPNuntQKCMT='movie' if wXhecGJrYgaWHzDvEymAPNuntQKCsV=='-' else 'seasons'
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={'code':wXhecGJrYgaWHzDvEymAPNuntQKCsj if wXhecGJrYgaWHzDvEymAPNuntQKCMT=='movie' else wXhecGJrYgaWHzDvEymAPNuntQKCsV,'img':wXhecGJrYgaWHzDvEymAPNuntQKCsi,'title':wXhecGJrYgaWHzDvEymAPNuntQKCUL,'videoid':wXhecGJrYgaWHzDvEymAPNuntQKCsj}
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.Save_Watched_List(wXhecGJrYgaWHzDvEymAPNuntQKCMT,wXhecGJrYgaWHzDvEymAPNuntQKCUb)
  except:
   wXhecGJrYgaWHzDvEymAPNuntQKCiq
 def srtConvert(wXhecGJrYgaWHzDvEymAPNuntQKCRi,wXhecGJrYgaWHzDvEymAPNuntQKCFM):
  wXhecGJrYgaWHzDvEymAPNuntQKCFU=re.sub(r'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',wXhecGJrYgaWHzDvEymAPNuntQKCFM)
  wXhecGJrYgaWHzDvEymAPNuntQKCFU=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',wXhecGJrYgaWHzDvEymAPNuntQKCFU)
  wXhecGJrYgaWHzDvEymAPNuntQKCFU=re.sub(r'(\d\d).(\d\d\d) --> (\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',wXhecGJrYgaWHzDvEymAPNuntQKCFU)
  wXhecGJrYgaWHzDvEymAPNuntQKCFU=re.sub(r'WEBVTT\n','',wXhecGJrYgaWHzDvEymAPNuntQKCFU)
  wXhecGJrYgaWHzDvEymAPNuntQKCFU=re.sub(r'Kind:[ \-\w]+\n','',wXhecGJrYgaWHzDvEymAPNuntQKCFU)
  wXhecGJrYgaWHzDvEymAPNuntQKCFU=re.sub(r'Language:[ \-\w]+\n','',wXhecGJrYgaWHzDvEymAPNuntQKCFU)
  wXhecGJrYgaWHzDvEymAPNuntQKCFU=re.sub(r'<c[.\w\d]*>','',wXhecGJrYgaWHzDvEymAPNuntQKCFU)
  wXhecGJrYgaWHzDvEymAPNuntQKCFU=re.sub(r'</c>','',wXhecGJrYgaWHzDvEymAPNuntQKCFU)
  wXhecGJrYgaWHzDvEymAPNuntQKCFU=re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>','',wXhecGJrYgaWHzDvEymAPNuntQKCFU)
  wXhecGJrYgaWHzDvEymAPNuntQKCFU=re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n','',wXhecGJrYgaWHzDvEymAPNuntQKCFU)
  wXhecGJrYgaWHzDvEymAPNuntQKCFU=re.sub(r'Style:\n##\n','',wXhecGJrYgaWHzDvEymAPNuntQKCFU)
  return wXhecGJrYgaWHzDvEymAPNuntQKCFU
 def vtt_to_srt(wXhecGJrYgaWHzDvEymAPNuntQKCRi,vttFilename,srtFilename):
  try:
   f=wXhecGJrYgaWHzDvEymAPNuntQKCib(vttFilename,'r',-1,'utf-8')
   wXhecGJrYgaWHzDvEymAPNuntQKCFM=f.read()
   f.close()
   wXhecGJrYgaWHzDvEymAPNuntQKCFs=''
   wXhecGJrYgaWHzDvEymAPNuntQKCFs=wXhecGJrYgaWHzDvEymAPNuntQKCFs+wXhecGJrYgaWHzDvEymAPNuntQKCRi.srtConvert(wXhecGJrYgaWHzDvEymAPNuntQKCFM)
   f=wXhecGJrYgaWHzDvEymAPNuntQKCib(srtFilename,'w',-1,'utf-8')
   f.writelines(wXhecGJrYgaWHzDvEymAPNuntQKCik(wXhecGJrYgaWHzDvEymAPNuntQKCFs))
   f.close()
  except:
   return wXhecGJrYgaWHzDvEymAPNuntQKCiB
  return wXhecGJrYgaWHzDvEymAPNuntQKCio
 def dp_Category_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCMT =args.get('stype')
  wXhecGJrYgaWHzDvEymAPNuntQKCsM =args.get('tag_id')
  wXhecGJrYgaWHzDvEymAPNuntQKCsU=args.get('api_path')
  wXhecGJrYgaWHzDvEymAPNuntQKCMl=wXhecGJrYgaWHzDvEymAPNuntQKCif(args.get('page'))
  wXhecGJrYgaWHzDvEymAPNuntQKCFj=[]
  wXhecGJrYgaWHzDvEymAPNuntQKCFV,wXhecGJrYgaWHzDvEymAPNuntQKCFi=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.GetCategoryList(wXhecGJrYgaWHzDvEymAPNuntQKCMT,wXhecGJrYgaWHzDvEymAPNuntQKCsM,wXhecGJrYgaWHzDvEymAPNuntQKCsU,wXhecGJrYgaWHzDvEymAPNuntQKCMl)
  for wXhecGJrYgaWHzDvEymAPNuntQKCFO in wXhecGJrYgaWHzDvEymAPNuntQKCFV:
   wXhecGJrYgaWHzDvEymAPNuntQKCsj =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('code')
   wXhecGJrYgaWHzDvEymAPNuntQKCUL =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('title')
   wXhecGJrYgaWHzDvEymAPNuntQKCMB =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('content_type')
   wXhecGJrYgaWHzDvEymAPNuntQKCFx =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('story')
   wXhecGJrYgaWHzDvEymAPNuntQKCsi =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('thumbnail')
   wXhecGJrYgaWHzDvEymAPNuntQKCFq =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('year')
   wXhecGJrYgaWHzDvEymAPNuntQKCFf =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('film_rating_code')
   wXhecGJrYgaWHzDvEymAPNuntQKCFo=wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('film_rating_short')
   wXhecGJrYgaWHzDvEymAPNuntQKCFB =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('film_rating_long')
   wXhecGJrYgaWHzDvEymAPNuntQKCFS =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('duration')
   wXhecGJrYgaWHzDvEymAPNuntQKCFL =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('badge')
   wXhecGJrYgaWHzDvEymAPNuntQKCFj.append(wXhecGJrYgaWHzDvEymAPNuntQKCsj)
   if wXhecGJrYgaWHzDvEymAPNuntQKCMB=='movies': 
    wXhecGJrYgaWHzDvEymAPNuntQKCUp =wXhecGJrYgaWHzDvEymAPNuntQKCiB
    wXhecGJrYgaWHzDvEymAPNuntQKCFT ='MOVIE'
    wXhecGJrYgaWHzDvEymAPNuntQKCsV='-'
    wXhecGJrYgaWHzDvEymAPNuntQKCFl ='movie'
   else: 
    wXhecGJrYgaWHzDvEymAPNuntQKCUp =wXhecGJrYgaWHzDvEymAPNuntQKCio
    wXhecGJrYgaWHzDvEymAPNuntQKCFT ='SEASON'
    wXhecGJrYgaWHzDvEymAPNuntQKCsV=wXhecGJrYgaWHzDvEymAPNuntQKCsj
    wXhecGJrYgaWHzDvEymAPNuntQKCFl ='tvshow' 
   wXhecGJrYgaWHzDvEymAPNuntQKCFI={'mediatype':wXhecGJrYgaWHzDvEymAPNuntQKCFl,'mpaa':wXhecGJrYgaWHzDvEymAPNuntQKCFB,'title':wXhecGJrYgaWHzDvEymAPNuntQKCUL,'year':wXhecGJrYgaWHzDvEymAPNuntQKCFq,'duration':wXhecGJrYgaWHzDvEymAPNuntQKCFS,'plot':wXhecGJrYgaWHzDvEymAPNuntQKCFx,}
   wXhecGJrYgaWHzDvEymAPNuntQKCUL+='  (%s)'%(wXhecGJrYgaWHzDvEymAPNuntQKCFq)
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':wXhecGJrYgaWHzDvEymAPNuntQKCFT,'movie_code':wXhecGJrYgaWHzDvEymAPNuntQKCsj,'page':'1','season_code':wXhecGJrYgaWHzDvEymAPNuntQKCsV,'title':wXhecGJrYgaWHzDvEymAPNuntQKCUL,'thumbnail':wXhecGJrYgaWHzDvEymAPNuntQKCsi,}
   wXhecGJrYgaWHzDvEymAPNuntQKCFd=[]
   if wXhecGJrYgaWHzDvEymAPNuntQKCsU=='users/me/watchings':
    wXhecGJrYgaWHzDvEymAPNuntQKCFk={'codeList':[wXhecGJrYgaWHzDvEymAPNuntQKCsj]}
    wXhecGJrYgaWHzDvEymAPNuntQKCFb=json.dumps(wXhecGJrYgaWHzDvEymAPNuntQKCFk)
    wXhecGJrYgaWHzDvEymAPNuntQKCFb=urllib.parse.quote(wXhecGJrYgaWHzDvEymAPNuntQKCFb)
    wXhecGJrYgaWHzDvEymAPNuntQKCFp='RunPlugin(plugin://plugin.video.watcham/?mode=DELETE_CONTINUE&bm_param=%s)'%(wXhecGJrYgaWHzDvEymAPNuntQKCFb)
    wXhecGJrYgaWHzDvEymAPNuntQKCFd.append(('(선택영상) 이어보기에서 삭제',wXhecGJrYgaWHzDvEymAPNuntQKCFp))
   if wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_settings_makebookmark():
    wXhecGJrYgaWHzDvEymAPNuntQKCFk={'videoid':wXhecGJrYgaWHzDvEymAPNuntQKCsj,'vidtype':'tvshow' if wXhecGJrYgaWHzDvEymAPNuntQKCMB=='tv_seasons' else 'movie','vtitle':wXhecGJrYgaWHzDvEymAPNuntQKCUL,'vsubtitle':'',}
    wXhecGJrYgaWHzDvEymAPNuntQKCFb=json.dumps(wXhecGJrYgaWHzDvEymAPNuntQKCFk)
    wXhecGJrYgaWHzDvEymAPNuntQKCFb=urllib.parse.quote(wXhecGJrYgaWHzDvEymAPNuntQKCFb)
    wXhecGJrYgaWHzDvEymAPNuntQKCFp='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(wXhecGJrYgaWHzDvEymAPNuntQKCFb)
    wXhecGJrYgaWHzDvEymAPNuntQKCFd.append(('(통합) 찜 영상에 추가',wXhecGJrYgaWHzDvEymAPNuntQKCFp))
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel=wXhecGJrYgaWHzDvEymAPNuntQKCFL,img=wXhecGJrYgaWHzDvEymAPNuntQKCsi,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCFI,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCUp,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb,ContextMenu=wXhecGJrYgaWHzDvEymAPNuntQKCFd)
  if wXhecGJrYgaWHzDvEymAPNuntQKCsU=='users/me/watchings':
   wXhecGJrYgaWHzDvEymAPNuntQKCFk={'codeList':wXhecGJrYgaWHzDvEymAPNuntQKCFj}
   wXhecGJrYgaWHzDvEymAPNuntQKCFb=json.dumps(wXhecGJrYgaWHzDvEymAPNuntQKCFk,separators=(',',':'))
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.addon_log(wXhecGJrYgaWHzDvEymAPNuntQKCFb)
   wXhecGJrYgaWHzDvEymAPNuntQKCFb=urllib.parse.quote(wXhecGJrYgaWHzDvEymAPNuntQKCFb)
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.addon_log(wXhecGJrYgaWHzDvEymAPNuntQKCFb)
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':'DELETE_CONTINUE','bm_param':wXhecGJrYgaWHzDvEymAPNuntQKCFk,}
   wXhecGJrYgaWHzDvEymAPNuntQKCFI={'plot':'이어보기 목록 전체를 삭제합니다.'}
   wXhecGJrYgaWHzDvEymAPNuntQKCUL='** 이어보기 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   wXhecGJrYgaWHzDvEymAPNuntQKCUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel='',img=wXhecGJrYgaWHzDvEymAPNuntQKCUk,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCFI,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCiB,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb,isLink=wXhecGJrYgaWHzDvEymAPNuntQKCio)
  if wXhecGJrYgaWHzDvEymAPNuntQKCFi:
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={}
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['mode'] ='CATEGORY_LIST'
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['stype'] =wXhecGJrYgaWHzDvEymAPNuntQKCMT
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['tag_id'] =wXhecGJrYgaWHzDvEymAPNuntQKCsM
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['api_path']=wXhecGJrYgaWHzDvEymAPNuntQKCsU
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['page'] =wXhecGJrYgaWHzDvEymAPNuntQKCik(wXhecGJrYgaWHzDvEymAPNuntQKCMl+1)
   wXhecGJrYgaWHzDvEymAPNuntQKCUL='[B]%s >>[/B]'%'다음 페이지'
   wXhecGJrYgaWHzDvEymAPNuntQKCsF=wXhecGJrYgaWHzDvEymAPNuntQKCik(wXhecGJrYgaWHzDvEymAPNuntQKCMl+1)
   wXhecGJrYgaWHzDvEymAPNuntQKCUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel=wXhecGJrYgaWHzDvEymAPNuntQKCsF,img=wXhecGJrYgaWHzDvEymAPNuntQKCUk,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCiq,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCio,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb)
  xbmcplugin.setContent(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,'movies')
  if wXhecGJrYgaWHzDvEymAPNuntQKCiI(wXhecGJrYgaWHzDvEymAPNuntQKCFV)>0:
   if wXhecGJrYgaWHzDvEymAPNuntQKCsU=='arrivals/latest':
    xbmcplugin.endOfDirectory(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,cacheToDisc=wXhecGJrYgaWHzDvEymAPNuntQKCio)
   else:
    xbmcplugin.endOfDirectory(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,cacheToDisc=wXhecGJrYgaWHzDvEymAPNuntQKCiB)
 def dp_Season_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCsV=args.get('season_code')
  wXhecGJrYgaWHzDvEymAPNuntQKCsi =args.get('thumbnail')
  wXhecGJrYgaWHzDvEymAPNuntQKCsi=json.loads(wXhecGJrYgaWHzDvEymAPNuntQKCsi.replace('\'','"'))
  wXhecGJrYgaWHzDvEymAPNuntQKCjR=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.GetSeasonList(wXhecGJrYgaWHzDvEymAPNuntQKCsV)
  if wXhecGJrYgaWHzDvEymAPNuntQKCiI(wXhecGJrYgaWHzDvEymAPNuntQKCjR)>1:
   for wXhecGJrYgaWHzDvEymAPNuntQKCjU in wXhecGJrYgaWHzDvEymAPNuntQKCjR:
    wXhecGJrYgaWHzDvEymAPNuntQKCjM=wXhecGJrYgaWHzDvEymAPNuntQKCjU.get('seasonId')
    wXhecGJrYgaWHzDvEymAPNuntQKCjs=wXhecGJrYgaWHzDvEymAPNuntQKCjU.get('seasonNm')
    wXhecGJrYgaWHzDvEymAPNuntQKCFI={'mediatype':'tvshow','title':wXhecGJrYgaWHzDvEymAPNuntQKCjs,}
    wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':'EPISODE','movie_code':wXhecGJrYgaWHzDvEymAPNuntQKCjM,'page':'1','season_code':wXhecGJrYgaWHzDvEymAPNuntQKCjM,'title':wXhecGJrYgaWHzDvEymAPNuntQKCjs,'thumbnail':wXhecGJrYgaWHzDvEymAPNuntQKCsi,}
    wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCjs,sublabel=wXhecGJrYgaWHzDvEymAPNuntQKCiq,img=wXhecGJrYgaWHzDvEymAPNuntQKCsi,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCFI,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCio,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb,ContextMenu=wXhecGJrYgaWHzDvEymAPNuntQKCiq)
   xbmcplugin.setContent(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,cacheToDisc=wXhecGJrYgaWHzDvEymAPNuntQKCiB)
  else:
   wXhecGJrYgaWHzDvEymAPNuntQKCjF={'movie_code':wXhecGJrYgaWHzDvEymAPNuntQKCsV,'page':'1','season_code':wXhecGJrYgaWHzDvEymAPNuntQKCsV,}
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Episode_List(wXhecGJrYgaWHzDvEymAPNuntQKCjF)
 def dp_Episode_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCjV=args.get('movie_code')
  wXhecGJrYgaWHzDvEymAPNuntQKCMl =wXhecGJrYgaWHzDvEymAPNuntQKCif(args.get('page'))
  wXhecGJrYgaWHzDvEymAPNuntQKCsV =args.get('season_code')
  wXhecGJrYgaWHzDvEymAPNuntQKCFV,wXhecGJrYgaWHzDvEymAPNuntQKCFi=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.GetEpisodoList(wXhecGJrYgaWHzDvEymAPNuntQKCjV,wXhecGJrYgaWHzDvEymAPNuntQKCMl,orderby=wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_winEpisodeOrderby())
  for wXhecGJrYgaWHzDvEymAPNuntQKCFO in wXhecGJrYgaWHzDvEymAPNuntQKCFV:
   wXhecGJrYgaWHzDvEymAPNuntQKCsj =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('code')
   wXhecGJrYgaWHzDvEymAPNuntQKCUL =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('title')
   wXhecGJrYgaWHzDvEymAPNuntQKCsi =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('thumbnail')
   wXhecGJrYgaWHzDvEymAPNuntQKCji =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('display_num')
   wXhecGJrYgaWHzDvEymAPNuntQKCjO =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('season_title')
   wXhecGJrYgaWHzDvEymAPNuntQKCjx=wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('episode_number')
   wXhecGJrYgaWHzDvEymAPNuntQKCFS =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('duration')
   wXhecGJrYgaWHzDvEymAPNuntQKCFI={'mediatype':'episode','tvshowtitle':wXhecGJrYgaWHzDvEymAPNuntQKCUL if wXhecGJrYgaWHzDvEymAPNuntQKCUL!='' else wXhecGJrYgaWHzDvEymAPNuntQKCjO,'title':'%s %s'%(wXhecGJrYgaWHzDvEymAPNuntQKCjO,wXhecGJrYgaWHzDvEymAPNuntQKCji)if wXhecGJrYgaWHzDvEymAPNuntQKCUL!='' else wXhecGJrYgaWHzDvEymAPNuntQKCji,'episode':wXhecGJrYgaWHzDvEymAPNuntQKCjx,'duration':wXhecGJrYgaWHzDvEymAPNuntQKCFS,'plot':'%s\n%s\n\n%s'%(wXhecGJrYgaWHzDvEymAPNuntQKCjO,wXhecGJrYgaWHzDvEymAPNuntQKCji,wXhecGJrYgaWHzDvEymAPNuntQKCUL)}
   wXhecGJrYgaWHzDvEymAPNuntQKCUL='(%s) %s'%(wXhecGJrYgaWHzDvEymAPNuntQKCji,wXhecGJrYgaWHzDvEymAPNuntQKCUL)
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':'MOVIE','movie_code':wXhecGJrYgaWHzDvEymAPNuntQKCsj,'season_code':wXhecGJrYgaWHzDvEymAPNuntQKCsV,'title':'%s < %s >'%(wXhecGJrYgaWHzDvEymAPNuntQKCUL,wXhecGJrYgaWHzDvEymAPNuntQKCjO),'thumbnail':wXhecGJrYgaWHzDvEymAPNuntQKCsi}
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel=wXhecGJrYgaWHzDvEymAPNuntQKCjO,img=wXhecGJrYgaWHzDvEymAPNuntQKCsi,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCFI,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCiB,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb)
  if wXhecGJrYgaWHzDvEymAPNuntQKCMl==1:
   wXhecGJrYgaWHzDvEymAPNuntQKCFI={'plot':'정렬순서를 변경합니다.'}
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={}
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['mode'] ='ORDER_BY' 
   if wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_winEpisodeOrderby()=='desc':
    wXhecGJrYgaWHzDvEymAPNuntQKCUL='정렬순서변경 : 최신화부터 -> 1회부터'
    wXhecGJrYgaWHzDvEymAPNuntQKCUb['orderby']='asc'
   else:
    wXhecGJrYgaWHzDvEymAPNuntQKCUL='정렬순서변경 : 1회부터 -> 최신화부터'
    wXhecGJrYgaWHzDvEymAPNuntQKCUb['orderby']='desc'
   wXhecGJrYgaWHzDvEymAPNuntQKCUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel='',img=wXhecGJrYgaWHzDvEymAPNuntQKCUk,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCFI,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCiB,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb,isLink=wXhecGJrYgaWHzDvEymAPNuntQKCio)
  if wXhecGJrYgaWHzDvEymAPNuntQKCFi:
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['mode'] ='EPISODE' 
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['movie_code']=wXhecGJrYgaWHzDvEymAPNuntQKCjV
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['page'] =wXhecGJrYgaWHzDvEymAPNuntQKCik(wXhecGJrYgaWHzDvEymAPNuntQKCMl+1)
   wXhecGJrYgaWHzDvEymAPNuntQKCUL='[B]%s >>[/B]'%'다음 페이지'
   wXhecGJrYgaWHzDvEymAPNuntQKCsF=wXhecGJrYgaWHzDvEymAPNuntQKCik(wXhecGJrYgaWHzDvEymAPNuntQKCMl+1)
   wXhecGJrYgaWHzDvEymAPNuntQKCUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel=wXhecGJrYgaWHzDvEymAPNuntQKCsF,img=wXhecGJrYgaWHzDvEymAPNuntQKCUk,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCiq,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCio,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb)
  xbmcplugin.setContent(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,'episodes')
  if wXhecGJrYgaWHzDvEymAPNuntQKCiI(wXhecGJrYgaWHzDvEymAPNuntQKCFV)>0:xbmcplugin.endOfDirectory(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,cacheToDisc=wXhecGJrYgaWHzDvEymAPNuntQKCio)
 def dp_Search_History(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCjq=wXhecGJrYgaWHzDvEymAPNuntQKCRi.Load_List_File('search')
  for wXhecGJrYgaWHzDvEymAPNuntQKCjf in wXhecGJrYgaWHzDvEymAPNuntQKCjq:
   wXhecGJrYgaWHzDvEymAPNuntQKCjo=wXhecGJrYgaWHzDvEymAPNuntQKCiL(urllib.parse.parse_qsl(wXhecGJrYgaWHzDvEymAPNuntQKCjf))
   wXhecGJrYgaWHzDvEymAPNuntQKCjB=wXhecGJrYgaWHzDvEymAPNuntQKCjo.get('skey').strip()
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':'LOCAL_SEARCH','search_key':wXhecGJrYgaWHzDvEymAPNuntQKCjB,'page':'1','historyyn':'Y',}
   wXhecGJrYgaWHzDvEymAPNuntQKCjS={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':wXhecGJrYgaWHzDvEymAPNuntQKCjB,'vType':'-',}
   wXhecGJrYgaWHzDvEymAPNuntQKCjL=urllib.parse.urlencode(wXhecGJrYgaWHzDvEymAPNuntQKCjS)
   wXhecGJrYgaWHzDvEymAPNuntQKCFd=[('선택된 검색어 ( %s ) 삭제'%(wXhecGJrYgaWHzDvEymAPNuntQKCjB),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(wXhecGJrYgaWHzDvEymAPNuntQKCjL))]
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCjB,sublabel='',img=wXhecGJrYgaWHzDvEymAPNuntQKCiq,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCiq,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCio,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb,ContextMenu=wXhecGJrYgaWHzDvEymAPNuntQKCFd)
  wXhecGJrYgaWHzDvEymAPNuntQKCFI={'plot':'검색목록 전체를 삭제합니다.'}
  wXhecGJrYgaWHzDvEymAPNuntQKCUL='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  wXhecGJrYgaWHzDvEymAPNuntQKCUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel='',img=wXhecGJrYgaWHzDvEymAPNuntQKCUk,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCFI,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCiB,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb,isLink=wXhecGJrYgaWHzDvEymAPNuntQKCio)
  xbmcplugin.endOfDirectory(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,cacheToDisc=wXhecGJrYgaWHzDvEymAPNuntQKCiB)
 def dp_Search_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCMl =wXhecGJrYgaWHzDvEymAPNuntQKCif(args.get('page'))
  if 'search_key' in args:
   wXhecGJrYgaWHzDvEymAPNuntQKCjT=args.get('search_key')
  else:
   wXhecGJrYgaWHzDvEymAPNuntQKCjT=wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not wXhecGJrYgaWHzDvEymAPNuntQKCjT:
    return
  wXhecGJrYgaWHzDvEymAPNuntQKCFV,wXhecGJrYgaWHzDvEymAPNuntQKCFi=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.GetSearchList(wXhecGJrYgaWHzDvEymAPNuntQKCjT,wXhecGJrYgaWHzDvEymAPNuntQKCMl)
  for wXhecGJrYgaWHzDvEymAPNuntQKCFO in wXhecGJrYgaWHzDvEymAPNuntQKCFV:
   wXhecGJrYgaWHzDvEymAPNuntQKCsj =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('code')
   wXhecGJrYgaWHzDvEymAPNuntQKCUL =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('title')
   wXhecGJrYgaWHzDvEymAPNuntQKCMB=wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('content_type')
   wXhecGJrYgaWHzDvEymAPNuntQKCFx =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('story')
   wXhecGJrYgaWHzDvEymAPNuntQKCsi =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('thumbnail')
   wXhecGJrYgaWHzDvEymAPNuntQKCFq =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('year')
   wXhecGJrYgaWHzDvEymAPNuntQKCFf =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('film_rating_code')
   wXhecGJrYgaWHzDvEymAPNuntQKCFo=wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('film_rating_short')
   wXhecGJrYgaWHzDvEymAPNuntQKCFB =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('film_rating_long')
   wXhecGJrYgaWHzDvEymAPNuntQKCFS =wXhecGJrYgaWHzDvEymAPNuntQKCFO.get('duration')
   if wXhecGJrYgaWHzDvEymAPNuntQKCMB=='movies': 
    wXhecGJrYgaWHzDvEymAPNuntQKCUp =wXhecGJrYgaWHzDvEymAPNuntQKCiB
    wXhecGJrYgaWHzDvEymAPNuntQKCFT ='MOVIE'
    wXhecGJrYgaWHzDvEymAPNuntQKCMs =''
    wXhecGJrYgaWHzDvEymAPNuntQKCsV='-'
    wXhecGJrYgaWHzDvEymAPNuntQKCFl ='movie'
   else: 
    wXhecGJrYgaWHzDvEymAPNuntQKCUp =wXhecGJrYgaWHzDvEymAPNuntQKCio
    wXhecGJrYgaWHzDvEymAPNuntQKCFT ='SEASON'
    wXhecGJrYgaWHzDvEymAPNuntQKCMs ='' 
    wXhecGJrYgaWHzDvEymAPNuntQKCsV=wXhecGJrYgaWHzDvEymAPNuntQKCsj
    wXhecGJrYgaWHzDvEymAPNuntQKCFl ='tvshow' 
   wXhecGJrYgaWHzDvEymAPNuntQKCFI={'mediatype':wXhecGJrYgaWHzDvEymAPNuntQKCFl,'mpaa':wXhecGJrYgaWHzDvEymAPNuntQKCFB,'title':wXhecGJrYgaWHzDvEymAPNuntQKCUL,'year':wXhecGJrYgaWHzDvEymAPNuntQKCFq,'duration':wXhecGJrYgaWHzDvEymAPNuntQKCFS,'plot':wXhecGJrYgaWHzDvEymAPNuntQKCFx}
   wXhecGJrYgaWHzDvEymAPNuntQKCUL+='  (%s)'%(wXhecGJrYgaWHzDvEymAPNuntQKCFq)
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':wXhecGJrYgaWHzDvEymAPNuntQKCFT,'movie_code':wXhecGJrYgaWHzDvEymAPNuntQKCsj,'page':'1','season_code':wXhecGJrYgaWHzDvEymAPNuntQKCsV,'title':wXhecGJrYgaWHzDvEymAPNuntQKCUL,'thumbnail':wXhecGJrYgaWHzDvEymAPNuntQKCsi}
   if wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_settings_makebookmark():
    wXhecGJrYgaWHzDvEymAPNuntQKCFk={'videoid':wXhecGJrYgaWHzDvEymAPNuntQKCsj,'vidtype':'tvshow' if wXhecGJrYgaWHzDvEymAPNuntQKCMB=='tv_seasons' else 'movie','vtitle':wXhecGJrYgaWHzDvEymAPNuntQKCUL,'vsubtitle':'',}
    wXhecGJrYgaWHzDvEymAPNuntQKCFb=json.dumps(wXhecGJrYgaWHzDvEymAPNuntQKCFk)
    wXhecGJrYgaWHzDvEymAPNuntQKCFb=urllib.parse.quote(wXhecGJrYgaWHzDvEymAPNuntQKCFb)
    wXhecGJrYgaWHzDvEymAPNuntQKCFp='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(wXhecGJrYgaWHzDvEymAPNuntQKCFb)
    wXhecGJrYgaWHzDvEymAPNuntQKCFd=[('(통합) 찜 영상에 추가',wXhecGJrYgaWHzDvEymAPNuntQKCFp)]
   else:
    wXhecGJrYgaWHzDvEymAPNuntQKCFd=wXhecGJrYgaWHzDvEymAPNuntQKCiq
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel=wXhecGJrYgaWHzDvEymAPNuntQKCMs,img=wXhecGJrYgaWHzDvEymAPNuntQKCsi,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCFI,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCUp,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb,ContextMenu=wXhecGJrYgaWHzDvEymAPNuntQKCFd)
  if wXhecGJrYgaWHzDvEymAPNuntQKCFi:
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={}
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['mode'] ='SEARCH'
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['search_key']=wXhecGJrYgaWHzDvEymAPNuntQKCjT
   wXhecGJrYgaWHzDvEymAPNuntQKCUb['page'] =wXhecGJrYgaWHzDvEymAPNuntQKCik(wXhecGJrYgaWHzDvEymAPNuntQKCMl+1)
   wXhecGJrYgaWHzDvEymAPNuntQKCUL='[B]%s >>[/B]'%'다음 페이지'
   wXhecGJrYgaWHzDvEymAPNuntQKCsF=wXhecGJrYgaWHzDvEymAPNuntQKCik(wXhecGJrYgaWHzDvEymAPNuntQKCMl+1)
   wXhecGJrYgaWHzDvEymAPNuntQKCUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel=wXhecGJrYgaWHzDvEymAPNuntQKCsF,img=wXhecGJrYgaWHzDvEymAPNuntQKCUk,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCiq,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCio,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb)
  xbmcplugin.setContent(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,'movies')
  xbmcplugin.endOfDirectory(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,cacheToDisc=wXhecGJrYgaWHzDvEymAPNuntQKCio)
  if args.get('historyyn')=='Y':wXhecGJrYgaWHzDvEymAPNuntQKCRi.Save_Searched_List(wXhecGJrYgaWHzDvEymAPNuntQKCjT)
 def dp_Delete_Continue(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCjl=urllib.parse.unquote(args.get('bm_param'))
  wXhecGJrYgaWHzDvEymAPNuntQKCjl=wXhecGJrYgaWHzDvEymAPNuntQKCjl.replace('\'','"')
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.addon_log(wXhecGJrYgaWHzDvEymAPNuntQKCjl)
  wXhecGJrYgaWHzDvEymAPNuntQKCjl=json.loads(wXhecGJrYgaWHzDvEymAPNuntQKCjl)
  wXhecGJrYgaWHzDvEymAPNuntQKCFj=wXhecGJrYgaWHzDvEymAPNuntQKCjl.get('codeList')
  wXhecGJrYgaWHzDvEymAPNuntQKCRo=xbmcgui.Dialog()
  wXhecGJrYgaWHzDvEymAPNuntQKCMi=wXhecGJrYgaWHzDvEymAPNuntQKCRo.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if wXhecGJrYgaWHzDvEymAPNuntQKCMi==wXhecGJrYgaWHzDvEymAPNuntQKCiB:sys.exit()
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.DeleteContinueList(wXhecGJrYgaWHzDvEymAPNuntQKCFj)
  xbmc.executebuiltin("Container.Refresh")
 def dp_History_Remove(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCjI=args.get('delType')
  wXhecGJrYgaWHzDvEymAPNuntQKCjd =args.get('sKey')
  wXhecGJrYgaWHzDvEymAPNuntQKCjk =args.get('vType')
  wXhecGJrYgaWHzDvEymAPNuntQKCRo=xbmcgui.Dialog()
  if wXhecGJrYgaWHzDvEymAPNuntQKCjI=='SEARCH_ALL':
   wXhecGJrYgaWHzDvEymAPNuntQKCMi=wXhecGJrYgaWHzDvEymAPNuntQKCRo.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif wXhecGJrYgaWHzDvEymAPNuntQKCjI=='SEARCH_ONE':
   wXhecGJrYgaWHzDvEymAPNuntQKCMi=wXhecGJrYgaWHzDvEymAPNuntQKCRo.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif wXhecGJrYgaWHzDvEymAPNuntQKCjI=='WATCH_ALL':
   wXhecGJrYgaWHzDvEymAPNuntQKCMi=wXhecGJrYgaWHzDvEymAPNuntQKCRo.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif wXhecGJrYgaWHzDvEymAPNuntQKCjI=='WATCH_ONE':
   wXhecGJrYgaWHzDvEymAPNuntQKCMi=wXhecGJrYgaWHzDvEymAPNuntQKCRo.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if wXhecGJrYgaWHzDvEymAPNuntQKCMi==wXhecGJrYgaWHzDvEymAPNuntQKCiB:sys.exit()
  if wXhecGJrYgaWHzDvEymAPNuntQKCjI=='SEARCH_ALL':
   if os.path.isfile(wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_SEARCHEDC_FILENAME):os.remove(wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_SEARCHEDC_FILENAME)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCjI=='SEARCH_ONE':
   try:
    wXhecGJrYgaWHzDvEymAPNuntQKCjb=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_SEARCHEDC_FILENAME
    wXhecGJrYgaWHzDvEymAPNuntQKCjp=wXhecGJrYgaWHzDvEymAPNuntQKCRi.Load_List_File('search') 
    fp=wXhecGJrYgaWHzDvEymAPNuntQKCib(wXhecGJrYgaWHzDvEymAPNuntQKCjb,'w',-1,'utf-8')
    for wXhecGJrYgaWHzDvEymAPNuntQKCVR in wXhecGJrYgaWHzDvEymAPNuntQKCjp:
     wXhecGJrYgaWHzDvEymAPNuntQKCVU=wXhecGJrYgaWHzDvEymAPNuntQKCiL(urllib.parse.parse_qsl(wXhecGJrYgaWHzDvEymAPNuntQKCVR))
     wXhecGJrYgaWHzDvEymAPNuntQKCVM=wXhecGJrYgaWHzDvEymAPNuntQKCVU.get('skey').strip()
     if wXhecGJrYgaWHzDvEymAPNuntQKCjd!=wXhecGJrYgaWHzDvEymAPNuntQKCVM:
      fp.write(wXhecGJrYgaWHzDvEymAPNuntQKCVR)
    fp.close()
   except:
    wXhecGJrYgaWHzDvEymAPNuntQKCiq
  elif wXhecGJrYgaWHzDvEymAPNuntQKCjI=='WATCH_ALL':
   wXhecGJrYgaWHzDvEymAPNuntQKCjb=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wXhecGJrYgaWHzDvEymAPNuntQKCjk))
   if os.path.isfile(wXhecGJrYgaWHzDvEymAPNuntQKCjb):os.remove(wXhecGJrYgaWHzDvEymAPNuntQKCjb)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCjI=='WATCH_ONE':
   wXhecGJrYgaWHzDvEymAPNuntQKCjb=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wXhecGJrYgaWHzDvEymAPNuntQKCjk))
   try:
    wXhecGJrYgaWHzDvEymAPNuntQKCjp=wXhecGJrYgaWHzDvEymAPNuntQKCRi.Load_List_File(wXhecGJrYgaWHzDvEymAPNuntQKCjk) 
    fp=wXhecGJrYgaWHzDvEymAPNuntQKCib(wXhecGJrYgaWHzDvEymAPNuntQKCjb,'w',-1,'utf-8')
    for wXhecGJrYgaWHzDvEymAPNuntQKCVR in wXhecGJrYgaWHzDvEymAPNuntQKCjp:
     wXhecGJrYgaWHzDvEymAPNuntQKCVU=wXhecGJrYgaWHzDvEymAPNuntQKCiL(urllib.parse.parse_qsl(wXhecGJrYgaWHzDvEymAPNuntQKCVR))
     wXhecGJrYgaWHzDvEymAPNuntQKCVM=wXhecGJrYgaWHzDvEymAPNuntQKCVU.get('code').strip()
     if wXhecGJrYgaWHzDvEymAPNuntQKCjd!=wXhecGJrYgaWHzDvEymAPNuntQKCVM:
      fp.write(wXhecGJrYgaWHzDvEymAPNuntQKCVR)
    fp.close()
   except:
    wXhecGJrYgaWHzDvEymAPNuntQKCiq
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(wXhecGJrYgaWHzDvEymAPNuntQKCRi,wXhecGJrYgaWHzDvEymAPNuntQKCMT): 
  try:
   if wXhecGJrYgaWHzDvEymAPNuntQKCMT=='search':
    wXhecGJrYgaWHzDvEymAPNuntQKCjb=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_SEARCHEDC_FILENAME
   elif wXhecGJrYgaWHzDvEymAPNuntQKCMT in['seasons','movie']:
    wXhecGJrYgaWHzDvEymAPNuntQKCjb=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wXhecGJrYgaWHzDvEymAPNuntQKCMT))
   else:
    return[]
   fp=wXhecGJrYgaWHzDvEymAPNuntQKCib(wXhecGJrYgaWHzDvEymAPNuntQKCjb,'r',-1,'utf-8')
   wXhecGJrYgaWHzDvEymAPNuntQKCVs=fp.readlines()
   fp.close()
  except:
   wXhecGJrYgaWHzDvEymAPNuntQKCVs=[]
  return wXhecGJrYgaWHzDvEymAPNuntQKCVs
 def Save_Watched_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi,wXhecGJrYgaWHzDvEymAPNuntQKCMT,wXhecGJrYgaWHzDvEymAPNuntQKCRq):
  try:
   wXhecGJrYgaWHzDvEymAPNuntQKCVF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wXhecGJrYgaWHzDvEymAPNuntQKCMT))
   wXhecGJrYgaWHzDvEymAPNuntQKCjp=wXhecGJrYgaWHzDvEymAPNuntQKCRi.Load_List_File(wXhecGJrYgaWHzDvEymAPNuntQKCMT) 
   fp=wXhecGJrYgaWHzDvEymAPNuntQKCib(wXhecGJrYgaWHzDvEymAPNuntQKCVF,'w',-1,'utf-8')
   wXhecGJrYgaWHzDvEymAPNuntQKCVj=urllib.parse.urlencode(wXhecGJrYgaWHzDvEymAPNuntQKCRq)
   wXhecGJrYgaWHzDvEymAPNuntQKCVj=wXhecGJrYgaWHzDvEymAPNuntQKCVj+'\n'
   fp.write(wXhecGJrYgaWHzDvEymAPNuntQKCVj)
   wXhecGJrYgaWHzDvEymAPNuntQKCVi=0
   for wXhecGJrYgaWHzDvEymAPNuntQKCVR in wXhecGJrYgaWHzDvEymAPNuntQKCjp:
    wXhecGJrYgaWHzDvEymAPNuntQKCVU=wXhecGJrYgaWHzDvEymAPNuntQKCiL(urllib.parse.parse_qsl(wXhecGJrYgaWHzDvEymAPNuntQKCVR))
    wXhecGJrYgaWHzDvEymAPNuntQKCVO=wXhecGJrYgaWHzDvEymAPNuntQKCRq.get('code').strip()
    wXhecGJrYgaWHzDvEymAPNuntQKCVx=wXhecGJrYgaWHzDvEymAPNuntQKCVU.get('code').strip()
    if wXhecGJrYgaWHzDvEymAPNuntQKCMT=='seasons' and wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_settings_direct_replay()==wXhecGJrYgaWHzDvEymAPNuntQKCio:
     wXhecGJrYgaWHzDvEymAPNuntQKCVO=wXhecGJrYgaWHzDvEymAPNuntQKCRq.get('videoid').strip()
     wXhecGJrYgaWHzDvEymAPNuntQKCVx=wXhecGJrYgaWHzDvEymAPNuntQKCVU.get('videoid').strip()if wXhecGJrYgaWHzDvEymAPNuntQKCVx!=wXhecGJrYgaWHzDvEymAPNuntQKCiq else '-'
    if wXhecGJrYgaWHzDvEymAPNuntQKCVO!=wXhecGJrYgaWHzDvEymAPNuntQKCVx:
     fp.write(wXhecGJrYgaWHzDvEymAPNuntQKCVR)
     wXhecGJrYgaWHzDvEymAPNuntQKCVi+=1
     if wXhecGJrYgaWHzDvEymAPNuntQKCVi>=50:break
   fp.close()
  except:
   wXhecGJrYgaWHzDvEymAPNuntQKCiq
 def dp_Watch_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCMT =args.get('stype')
  wXhecGJrYgaWHzDvEymAPNuntQKCUo=wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_settings_direct_replay()
  if wXhecGJrYgaWHzDvEymAPNuntQKCMT=='-':
   for wXhecGJrYgaWHzDvEymAPNuntQKCVq in wXhecGJrYgaWHzDvEymAPNuntQKCRs:
    wXhecGJrYgaWHzDvEymAPNuntQKCUL=wXhecGJrYgaWHzDvEymAPNuntQKCVq.get('title')
    wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':wXhecGJrYgaWHzDvEymAPNuntQKCVq.get('mode'),'stype':wXhecGJrYgaWHzDvEymAPNuntQKCVq.get('stype')}
    wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel='',img='',infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCiq,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCio,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb)
   if wXhecGJrYgaWHzDvEymAPNuntQKCiI(wXhecGJrYgaWHzDvEymAPNuntQKCRs)>0:xbmcplugin.endOfDirectory(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle)
  else:
   wXhecGJrYgaWHzDvEymAPNuntQKCVf=wXhecGJrYgaWHzDvEymAPNuntQKCRi.Load_List_File(wXhecGJrYgaWHzDvEymAPNuntQKCMT)
   for wXhecGJrYgaWHzDvEymAPNuntQKCVo in wXhecGJrYgaWHzDvEymAPNuntQKCVf:
    wXhecGJrYgaWHzDvEymAPNuntQKCjo=wXhecGJrYgaWHzDvEymAPNuntQKCiL(urllib.parse.parse_qsl(wXhecGJrYgaWHzDvEymAPNuntQKCVo))
    wXhecGJrYgaWHzDvEymAPNuntQKCsj=wXhecGJrYgaWHzDvEymAPNuntQKCjo.get('code').strip()
    wXhecGJrYgaWHzDvEymAPNuntQKCUL =wXhecGJrYgaWHzDvEymAPNuntQKCjo.get('title').strip()
    wXhecGJrYgaWHzDvEymAPNuntQKCsi =wXhecGJrYgaWHzDvEymAPNuntQKCjo.get('img').strip()
    wXhecGJrYgaWHzDvEymAPNuntQKCVB =wXhecGJrYgaWHzDvEymAPNuntQKCjo.get('videoid').strip()
    try:
     wXhecGJrYgaWHzDvEymAPNuntQKCsi=wXhecGJrYgaWHzDvEymAPNuntQKCsi.replace('\'','\"')
     wXhecGJrYgaWHzDvEymAPNuntQKCsi=json.loads(wXhecGJrYgaWHzDvEymAPNuntQKCsi)
    except:
     wXhecGJrYgaWHzDvEymAPNuntQKCiq
    wXhecGJrYgaWHzDvEymAPNuntQKCFI={}
    wXhecGJrYgaWHzDvEymAPNuntQKCFI['plot']=wXhecGJrYgaWHzDvEymAPNuntQKCUL
    if wXhecGJrYgaWHzDvEymAPNuntQKCMT=='movie':
     wXhecGJrYgaWHzDvEymAPNuntQKCFI['mediatype']='movie'
     wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':'MOVIE','page':'1','movie_code':wXhecGJrYgaWHzDvEymAPNuntQKCsj,'season_code':'-','title':wXhecGJrYgaWHzDvEymAPNuntQKCUL,'thumbnail':wXhecGJrYgaWHzDvEymAPNuntQKCsi}
     wXhecGJrYgaWHzDvEymAPNuntQKCUp=wXhecGJrYgaWHzDvEymAPNuntQKCiB
    else:
     if wXhecGJrYgaWHzDvEymAPNuntQKCUo==wXhecGJrYgaWHzDvEymAPNuntQKCiB or wXhecGJrYgaWHzDvEymAPNuntQKCVB==wXhecGJrYgaWHzDvEymAPNuntQKCiq:
      wXhecGJrYgaWHzDvEymAPNuntQKCFI['mediatype']='tvshow'
      wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':'EPISODE','page':'1','movie_code':wXhecGJrYgaWHzDvEymAPNuntQKCsj,'season_code':wXhecGJrYgaWHzDvEymAPNuntQKCsj,'title':wXhecGJrYgaWHzDvEymAPNuntQKCUL,'thumbnail':wXhecGJrYgaWHzDvEymAPNuntQKCsi}
      wXhecGJrYgaWHzDvEymAPNuntQKCUp=wXhecGJrYgaWHzDvEymAPNuntQKCio
     else:
      wXhecGJrYgaWHzDvEymAPNuntQKCFI['mediatype']='episode'
      wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':'MOVIE','movie_code':wXhecGJrYgaWHzDvEymAPNuntQKCVB,'season_code':wXhecGJrYgaWHzDvEymAPNuntQKCsj,'title':wXhecGJrYgaWHzDvEymAPNuntQKCUL,'thumbnail':wXhecGJrYgaWHzDvEymAPNuntQKCsi}
      wXhecGJrYgaWHzDvEymAPNuntQKCUp=wXhecGJrYgaWHzDvEymAPNuntQKCiB
    wXhecGJrYgaWHzDvEymAPNuntQKCjS={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':wXhecGJrYgaWHzDvEymAPNuntQKCsj,'vType':wXhecGJrYgaWHzDvEymAPNuntQKCMT,}
    wXhecGJrYgaWHzDvEymAPNuntQKCjL=urllib.parse.urlencode(wXhecGJrYgaWHzDvEymAPNuntQKCjS)
    wXhecGJrYgaWHzDvEymAPNuntQKCFd=[('선택된 시청이력 ( %s ) 삭제'%(wXhecGJrYgaWHzDvEymAPNuntQKCUL),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(wXhecGJrYgaWHzDvEymAPNuntQKCjL))]
    wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel='',img=wXhecGJrYgaWHzDvEymAPNuntQKCsi,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCFI,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCUp,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb,ContextMenu=wXhecGJrYgaWHzDvEymAPNuntQKCFd)
   wXhecGJrYgaWHzDvEymAPNuntQKCFI={'plot':'시청목록을 삭제합니다.'}
   wXhecGJrYgaWHzDvEymAPNuntQKCUL='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   wXhecGJrYgaWHzDvEymAPNuntQKCUb={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':wXhecGJrYgaWHzDvEymAPNuntQKCMT,}
   wXhecGJrYgaWHzDvEymAPNuntQKCUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.add_dir(wXhecGJrYgaWHzDvEymAPNuntQKCUL,sublabel='',img=wXhecGJrYgaWHzDvEymAPNuntQKCUk,infoLabels=wXhecGJrYgaWHzDvEymAPNuntQKCFI,isFolder=wXhecGJrYgaWHzDvEymAPNuntQKCiB,params=wXhecGJrYgaWHzDvEymAPNuntQKCUb,isLink=wXhecGJrYgaWHzDvEymAPNuntQKCio)
   if wXhecGJrYgaWHzDvEymAPNuntQKCMT=='movie':xbmcplugin.setContent(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,'movies')
   else:xbmcplugin.setContent(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(wXhecGJrYgaWHzDvEymAPNuntQKCRi._addon_handle,cacheToDisc=wXhecGJrYgaWHzDvEymAPNuntQKCiB)
 def Save_Searched_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi,wXhecGJrYgaWHzDvEymAPNuntQKCjT):
  try:
   wXhecGJrYgaWHzDvEymAPNuntQKCVS=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_SEARCHEDC_FILENAME
   wXhecGJrYgaWHzDvEymAPNuntQKCjp=wXhecGJrYgaWHzDvEymAPNuntQKCRi.Load_List_File('search') 
   wXhecGJrYgaWHzDvEymAPNuntQKCVL={'skey':wXhecGJrYgaWHzDvEymAPNuntQKCjT.strip()}
   fp=wXhecGJrYgaWHzDvEymAPNuntQKCib(wXhecGJrYgaWHzDvEymAPNuntQKCVS,'w',-1,'utf-8')
   wXhecGJrYgaWHzDvEymAPNuntQKCVj=urllib.parse.urlencode(wXhecGJrYgaWHzDvEymAPNuntQKCVL)
   wXhecGJrYgaWHzDvEymAPNuntQKCVj=wXhecGJrYgaWHzDvEymAPNuntQKCVj+'\n'
   fp.write(wXhecGJrYgaWHzDvEymAPNuntQKCVj)
   wXhecGJrYgaWHzDvEymAPNuntQKCVi=0
   for wXhecGJrYgaWHzDvEymAPNuntQKCVR in wXhecGJrYgaWHzDvEymAPNuntQKCjp:
    wXhecGJrYgaWHzDvEymAPNuntQKCVU=wXhecGJrYgaWHzDvEymAPNuntQKCiL(urllib.parse.parse_qsl(wXhecGJrYgaWHzDvEymAPNuntQKCVR))
    wXhecGJrYgaWHzDvEymAPNuntQKCVO=wXhecGJrYgaWHzDvEymAPNuntQKCVL.get('skey').strip()
    wXhecGJrYgaWHzDvEymAPNuntQKCVx=wXhecGJrYgaWHzDvEymAPNuntQKCVU.get('skey').strip()
    if wXhecGJrYgaWHzDvEymAPNuntQKCVO!=wXhecGJrYgaWHzDvEymAPNuntQKCVx:
     fp.write(wXhecGJrYgaWHzDvEymAPNuntQKCVR)
     wXhecGJrYgaWHzDvEymAPNuntQKCVi+=1
     if wXhecGJrYgaWHzDvEymAPNuntQKCVi>=50:break
   fp.close()
  except:
   wXhecGJrYgaWHzDvEymAPNuntQKCiq
 def logout(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  wXhecGJrYgaWHzDvEymAPNuntQKCRo=xbmcgui.Dialog()
  wXhecGJrYgaWHzDvEymAPNuntQKCMi=wXhecGJrYgaWHzDvEymAPNuntQKCRo.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if wXhecGJrYgaWHzDvEymAPNuntQKCMi==wXhecGJrYgaWHzDvEymAPNuntQKCiB:sys.exit()
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.Init_WC_Total()
  if os.path.isfile(wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_COOKIE_FILENAME):os.remove(wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_COOKIE_FILENAME)
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  wXhecGJrYgaWHzDvEymAPNuntQKCVT =wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.Get_Now_Datetime()
  wXhecGJrYgaWHzDvEymAPNuntQKCVl=wXhecGJrYgaWHzDvEymAPNuntQKCVT+datetime.timedelta(days=wXhecGJrYgaWHzDvEymAPNuntQKCif(__addon__.getSetting('cache_ttl')))
  (wXhecGJrYgaWHzDvEymAPNuntQKCMF,wXhecGJrYgaWHzDvEymAPNuntQKCMj,wXhecGJrYgaWHzDvEymAPNuntQKCMV)=wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_settings_account()
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.Save_session_acount(wXhecGJrYgaWHzDvEymAPNuntQKCMF,wXhecGJrYgaWHzDvEymAPNuntQKCMj,wXhecGJrYgaWHzDvEymAPNuntQKCMV)
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC['account']['token_limit']=wXhecGJrYgaWHzDvEymAPNuntQKCVl.strftime('%Y%m%d')
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.JsonFile_Save(wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_COOKIE_FILENAME,wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC)
 def cookiefile_check(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.JsonFile_Load(wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC_COOKIE_FILENAME)
  if 'account' not in wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC:
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.Init_WC_Total()
   return wXhecGJrYgaWHzDvEymAPNuntQKCiB
  if 'deviceId2' not in wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC['cookies']:
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.Init_WC_Total()
   return wXhecGJrYgaWHzDvEymAPNuntQKCiB
  (wXhecGJrYgaWHzDvEymAPNuntQKCVI,wXhecGJrYgaWHzDvEymAPNuntQKCVd,wXhecGJrYgaWHzDvEymAPNuntQKCVk)=wXhecGJrYgaWHzDvEymAPNuntQKCRi.get_settings_account()
  (wXhecGJrYgaWHzDvEymAPNuntQKCVb,wXhecGJrYgaWHzDvEymAPNuntQKCVp,wXhecGJrYgaWHzDvEymAPNuntQKCiR)=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.Load_session_acount()
  if wXhecGJrYgaWHzDvEymAPNuntQKCVI!=wXhecGJrYgaWHzDvEymAPNuntQKCVb or wXhecGJrYgaWHzDvEymAPNuntQKCVd!=wXhecGJrYgaWHzDvEymAPNuntQKCVp or wXhecGJrYgaWHzDvEymAPNuntQKCVk!=wXhecGJrYgaWHzDvEymAPNuntQKCiR:
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.Init_WC_Total()
   return wXhecGJrYgaWHzDvEymAPNuntQKCiB
  if wXhecGJrYgaWHzDvEymAPNuntQKCif(wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))>wXhecGJrYgaWHzDvEymAPNuntQKCif(wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.WC['account']['token_limit']):
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.Init_WC_Total()
   return wXhecGJrYgaWHzDvEymAPNuntQKCiB
  return wXhecGJrYgaWHzDvEymAPNuntQKCio
 def dp_Global_Search(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCiU=args.get('mode')
  if wXhecGJrYgaWHzDvEymAPNuntQKCiU=='TOTAL_SEARCH':
   wXhecGJrYgaWHzDvEymAPNuntQKCiM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   wXhecGJrYgaWHzDvEymAPNuntQKCiM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(wXhecGJrYgaWHzDvEymAPNuntQKCiM)
 def dp_Bookmark_Menu(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCiM='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(wXhecGJrYgaWHzDvEymAPNuntQKCiM)
 def dp_Set_Bookmark(wXhecGJrYgaWHzDvEymAPNuntQKCRi,args):
  wXhecGJrYgaWHzDvEymAPNuntQKCjl=urllib.parse.unquote(args.get('bm_param'))
  wXhecGJrYgaWHzDvEymAPNuntQKCjl=json.loads(wXhecGJrYgaWHzDvEymAPNuntQKCjl)
  wXhecGJrYgaWHzDvEymAPNuntQKCVB =wXhecGJrYgaWHzDvEymAPNuntQKCjl.get('videoid')
  wXhecGJrYgaWHzDvEymAPNuntQKCis =wXhecGJrYgaWHzDvEymAPNuntQKCjl.get('vidtype')
  wXhecGJrYgaWHzDvEymAPNuntQKCiF =wXhecGJrYgaWHzDvEymAPNuntQKCjl.get('vtitle')
  wXhecGJrYgaWHzDvEymAPNuntQKCij =wXhecGJrYgaWHzDvEymAPNuntQKCjl.get('vsubtitle')
  wXhecGJrYgaWHzDvEymAPNuntQKCRo=xbmcgui.Dialog()
  wXhecGJrYgaWHzDvEymAPNuntQKCMi=wXhecGJrYgaWHzDvEymAPNuntQKCRo.yesno(__language__(30913).encode('utf8'),wXhecGJrYgaWHzDvEymAPNuntQKCiF+' \n\n'+__language__(30914))
  if wXhecGJrYgaWHzDvEymAPNuntQKCMi==wXhecGJrYgaWHzDvEymAPNuntQKCiB:return
  wXhecGJrYgaWHzDvEymAPNuntQKCiV=wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.GetBookmarkInfo(wXhecGJrYgaWHzDvEymAPNuntQKCVB,wXhecGJrYgaWHzDvEymAPNuntQKCis)
  wXhecGJrYgaWHzDvEymAPNuntQKCiO=json.dumps(wXhecGJrYgaWHzDvEymAPNuntQKCiV)
  wXhecGJrYgaWHzDvEymAPNuntQKCiO=urllib.parse.quote(wXhecGJrYgaWHzDvEymAPNuntQKCiO)
  wXhecGJrYgaWHzDvEymAPNuntQKCFp ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(wXhecGJrYgaWHzDvEymAPNuntQKCiO)
  xbmc.executebuiltin(wXhecGJrYgaWHzDvEymAPNuntQKCFp)
 def watcha_main(wXhecGJrYgaWHzDvEymAPNuntQKCRi):
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.WatchaObj.KodiVersion=wXhecGJrYgaWHzDvEymAPNuntQKCif(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  wXhecGJrYgaWHzDvEymAPNuntQKCiU=wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params.get('mode',wXhecGJrYgaWHzDvEymAPNuntQKCiq)
  if wXhecGJrYgaWHzDvEymAPNuntQKCiU=='LOGOUT':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.logout()
   return
  wXhecGJrYgaWHzDvEymAPNuntQKCRi.login_main()
  if wXhecGJrYgaWHzDvEymAPNuntQKCiU is wXhecGJrYgaWHzDvEymAPNuntQKCiq:
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Main_List()
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='HOME_GROUP':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_HomeGroup_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='SUB_GROUP':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_SubGroup_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='CATEGORY_LIST':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Category_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='SEASON':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Season_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='EPISODE':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Episode_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='ORDER_BY':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_setEpOrderby(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU in['SEARCH','LOCAL_SEARCH']:
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Search_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='MOVIE':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.play_VIDEO(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='WATCH':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Watch_List(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_History_Remove(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU in['TOTAL_SEARCH','TOTAL_HISTORY']:
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Global_Search(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='SEARCH_HISTORY':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Search_History(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='MENU_BOOKMARK':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Bookmark_Menu(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='SET_BOOKMARK':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Set_Bookmark(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  elif wXhecGJrYgaWHzDvEymAPNuntQKCiU=='DELETE_CONTINUE':
   wXhecGJrYgaWHzDvEymAPNuntQKCRi.dp_Delete_Continue(wXhecGJrYgaWHzDvEymAPNuntQKCRi.main_params)
  else:
   wXhecGJrYgaWHzDvEymAPNuntQKCiq
# Created by pyminifier (https://github.com/liftoff/pyminifier)
