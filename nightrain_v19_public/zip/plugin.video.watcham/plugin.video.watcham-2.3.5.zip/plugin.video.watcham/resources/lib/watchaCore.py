__author__="NightRain"
rTqGAoykOQwfBEHDVcmuNjXdhliMFR=object
rTqGAoykOQwfBEHDVcmuNjXdhliMFv=None
rTqGAoykOQwfBEHDVcmuNjXdhliMFp=False
rTqGAoykOQwfBEHDVcmuNjXdhliMFC=open
rTqGAoykOQwfBEHDVcmuNjXdhliMFL=True
rTqGAoykOQwfBEHDVcmuNjXdhliMFg=id
rTqGAoykOQwfBEHDVcmuNjXdhliMFW=str
rTqGAoykOQwfBEHDVcmuNjXdhliMPn=range
rTqGAoykOQwfBEHDVcmuNjXdhliMPJ=Exception
rTqGAoykOQwfBEHDVcmuNjXdhliMPI=print
rTqGAoykOQwfBEHDVcmuNjXdhliMPS=int
rTqGAoykOQwfBEHDVcmuNjXdhliMPF=len
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
import string
import random
class rTqGAoykOQwfBEHDVcmuNjXdhliMnJ(rTqGAoykOQwfBEHDVcmuNjXdhliMFR):
 def __init__(rTqGAoykOQwfBEHDVcmuNjXdhliMnI):
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC ={}
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Init_WC_Total()
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.MAIN_DOMAIN ='https://watcha.com'
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN ='https://api-mars.watcha.com'
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.EPISODE_LIMIT=20
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.SEARCH_LIMIT =30
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.USER_AGENT2 ='User-Agent: Dalvik/2.1.0 (Linux; U; Android 9; A95X_F3_Air Build/A95X_F3_AIR_M)/WatchaPlay-Android/1.10.34'
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.DEFAULT_HEADER={'user-agent':rTqGAoykOQwfBEHDVcmuNjXdhliMnI.USER_AGENT}
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.KodiVersion=20
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC_SUBTITLE_VTT =''
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC_SUBTITLE_SRT =''
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC_COOKIE_FILENAME =''
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC_SEARCHEDC_FILENAME=''
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC_STREAM_FILENAME =''
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC_TEMP_JSONFILE_1 =''
 def Get_Base_Headers(rTqGAoykOQwfBEHDVcmuNjXdhliMnI):
  rTqGAoykOQwfBEHDVcmuNjXdhliMnS={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.3',}
  return rTqGAoykOQwfBEHDVcmuNjXdhliMnS
 def Get_Base_Headers_v2(rTqGAoykOQwfBEHDVcmuNjXdhliMnI):
  rTqGAoykOQwfBEHDVcmuNjXdhliMnF ='1.10.35' 
  rTqGAoykOQwfBEHDVcmuNjXdhliMnP ='30' 
  rTqGAoykOQwfBEHDVcmuNjXdhliMnU ='NVIDIA SHIELD Android TV'
  rTqGAoykOQwfBEHDVcmuNjXdhliMnx =base64.standard_b64encode((rTqGAoykOQwfBEHDVcmuNjXdhliMnU+'-'+rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['deviceId2']).encode()).decode('utf-8') 
  rTqGAoykOQwfBEHDVcmuNjXdhliMnY ='1920x1080/2.0/320/xhdpi'
  rTqGAoykOQwfBEHDVcmuNjXdhliMna ='2596eb93-6e7f-4eba-925c-ddf783246860' 
  rTqGAoykOQwfBEHDVcmuNjXdhliMnS={'X-WatchaPlay-Client-Device-Id':rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['deviceId1'],'X-WatchaPlay-Client-Device-Id2':rTqGAoykOQwfBEHDVcmuNjXdhliMnx,'X-WatchaPlay-Client-Device-Name':rTqGAoykOQwfBEHDVcmuNjXdhliMnU,'X-WatchaPlay-Client-ADID':rTqGAoykOQwfBEHDVcmuNjXdhliMna,'X-WatchaPlay-Client':'WatchaPlay-Android','X-WatchaPlay-Client-Version':rTqGAoykOQwfBEHDVcmuNjXdhliMnF,'X-WatchaPlay-Client-Subclass':'Normal','X-WatchaPlay-Client-Ui-Mode-Name':'television','X-WatchaPlay-Screen':rTqGAoykOQwfBEHDVcmuNjXdhliMnY,'X-WatchaPlay-Network-Status':'wifi','X-WatchaPlay-Appsflyer-Device-ID':rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['flyerId'],'X-FROGRAMS-CLIENT':'Mars-Android-Box','X-FROGRAMS-APP-CODE':'mars','X-FROGRAMS-DEVICE-IDENTIFIER':rTqGAoykOQwfBEHDVcmuNjXdhliMnx,'X-FROGRAMS-DEVICE-NAME':rTqGAoykOQwfBEHDVcmuNjXdhliMnU,'X-FROGRAMS-AD-ID':rTqGAoykOQwfBEHDVcmuNjXdhliMna,'X-FROGRAMS-APPSFLYER-DEVICE-ID':rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['flyerId'],'X-FROGRAMS-VERSION':rTqGAoykOQwfBEHDVcmuNjXdhliMnF,'X-FROGRAMS-OS-VERSION':rTqGAoykOQwfBEHDVcmuNjXdhliMnP,'X-FROGRAMS-NETWORK-STATUS':'wifi','X-FROGRAMS-MARS-SCREEN':rTqGAoykOQwfBEHDVcmuNjXdhliMnY,'X-FROGRAMS-MARS-UI-MODE':'television',}
  return rTqGAoykOQwfBEHDVcmuNjXdhliMnS
 def Init_WC_Total(rTqGAoykOQwfBEHDVcmuNjXdhliMnI):
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC={'account':{},'cookies':{'watcha_token':'','watcha_guit':'','watcha_guitv':'','watcha_usercd':'',},}
 def callRequestCookies(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,jobtype,rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,redirects=rTqGAoykOQwfBEHDVcmuNjXdhliMFp):
  rTqGAoykOQwfBEHDVcmuNjXdhliMne=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.DEFAULT_HEADER
  if headers:rTqGAoykOQwfBEHDVcmuNjXdhliMne.update(headers)
  if jobtype=='Get':
   rTqGAoykOQwfBEHDVcmuNjXdhliMnb=requests.get(rTqGAoykOQwfBEHDVcmuNjXdhliMJz,params=params,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMne,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   rTqGAoykOQwfBEHDVcmuNjXdhliMnb=requests.put(rTqGAoykOQwfBEHDVcmuNjXdhliMJz,data=payload,params=params,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMne,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Delete':
   rTqGAoykOQwfBEHDVcmuNjXdhliMnb=requests.delete(rTqGAoykOQwfBEHDVcmuNjXdhliMJz,params=params,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMne,cookies=cookies,allow_redirects=redirects)
  else:
   rTqGAoykOQwfBEHDVcmuNjXdhliMnb=requests.post(rTqGAoykOQwfBEHDVcmuNjXdhliMJz,data=payload,params=params,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMne,cookies=cookies,allow_redirects=redirects)
  return rTqGAoykOQwfBEHDVcmuNjXdhliMnb
 def JsonFile_Save(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,filename,rTqGAoykOQwfBEHDVcmuNjXdhliMnt):
  if filename=='':return rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  try:
   fp=rTqGAoykOQwfBEHDVcmuNjXdhliMFC(filename,'w',-1,'utf-8')
   json.dump(rTqGAoykOQwfBEHDVcmuNjXdhliMnt,fp,indent=4,ensure_ascii=rTqGAoykOQwfBEHDVcmuNjXdhliMFp)
   fp.close()
  except:
   return rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  return rTqGAoykOQwfBEHDVcmuNjXdhliMFL
 def JsonFile_Load(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,filename):
  if filename=='':return{}
  try:
   fp=rTqGAoykOQwfBEHDVcmuNjXdhliMFC(filename,'r',-1,'utf-8')
   rTqGAoykOQwfBEHDVcmuNjXdhliMnK=json.load(fp)
   fp.close()
  except:
   return{}
  return rTqGAoykOQwfBEHDVcmuNjXdhliMnK
 def Save_session_acount(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,rTqGAoykOQwfBEHDVcmuNjXdhliMns,rTqGAoykOQwfBEHDVcmuNjXdhliMnR,rTqGAoykOQwfBEHDVcmuNjXdhliMnv):
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['account']['wcid']=base64.standard_b64encode(rTqGAoykOQwfBEHDVcmuNjXdhliMns.encode()).decode('utf-8')
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['account']['wcpw']=base64.standard_b64encode(rTqGAoykOQwfBEHDVcmuNjXdhliMnR.encode()).decode('utf-8')
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['account']['wcpf']=rTqGAoykOQwfBEHDVcmuNjXdhliMnv 
 def Load_session_acount(rTqGAoykOQwfBEHDVcmuNjXdhliMnI):
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMns=base64.standard_b64decode(rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['account']['wcid']).decode('utf-8')
   rTqGAoykOQwfBEHDVcmuNjXdhliMnR=base64.standard_b64decode(rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['account']['wcpw']).decode('utf-8')
   rTqGAoykOQwfBEHDVcmuNjXdhliMnv=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['account']['wcpf']
  except:
   return '','',0
  return rTqGAoykOQwfBEHDVcmuNjXdhliMns,rTqGAoykOQwfBEHDVcmuNjXdhliMnR,rTqGAoykOQwfBEHDVcmuNjXdhliMnv
 def Get_DeviceID(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,rTqGAoykOQwfBEHDVcmuNjXdhliMFg,pf):
  import hashlib
  m1=hashlib.md5()
  m2=hashlib.md5()
  rTqGAoykOQwfBEHDVcmuNjXdhliMnp=rTqGAoykOQwfBEHDVcmuNjXdhliMFg+rTqGAoykOQwfBEHDVcmuNjXdhliMFW(pf)
  rTqGAoykOQwfBEHDVcmuNjXdhliMnC=rTqGAoykOQwfBEHDVcmuNjXdhliMFW(pf)+rTqGAoykOQwfBEHDVcmuNjXdhliMFg
  m1.update(rTqGAoykOQwfBEHDVcmuNjXdhliMnp.encode('utf-8'))
  m2.update(rTqGAoykOQwfBEHDVcmuNjXdhliMnC.encode('utf-8'))
  rTqGAoykOQwfBEHDVcmuNjXdhliMnL=rTqGAoykOQwfBEHDVcmuNjXdhliMFW(m1.hexdigest())
  rTqGAoykOQwfBEHDVcmuNjXdhliMng=rTqGAoykOQwfBEHDVcmuNjXdhliMFW(m2.hexdigest())
  rTqGAoykOQwfBEHDVcmuNjXdhliMnW=rTqGAoykOQwfBEHDVcmuNjXdhliMnL[:16]
  rTqGAoykOQwfBEHDVcmuNjXdhliMJn='%s-%s-%s-%s-%s'%(rTqGAoykOQwfBEHDVcmuNjXdhliMng[:8],rTqGAoykOQwfBEHDVcmuNjXdhliMng[8:12],rTqGAoykOQwfBEHDVcmuNjXdhliMng[12:16],rTqGAoykOQwfBEHDVcmuNjXdhliMng[16:20],rTqGAoykOQwfBEHDVcmuNjXdhliMng[20:])
  return rTqGAoykOQwfBEHDVcmuNjXdhliMnW,rTqGAoykOQwfBEHDVcmuNjXdhliMJn
 def make_Random_Intstr(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,size):
  rTqGAoykOQwfBEHDVcmuNjXdhliMJI=string.digits 
  rTqGAoykOQwfBEHDVcmuNjXdhliMJS=''
  for i in rTqGAoykOQwfBEHDVcmuNjXdhliMPn(size):
   rTqGAoykOQwfBEHDVcmuNjXdhliMJS+=random.choice(rTqGAoykOQwfBEHDVcmuNjXdhliMJI)
  return rTqGAoykOQwfBEHDVcmuNjXdhliMJS
 def makeDefaultCookies(rTqGAoykOQwfBEHDVcmuNjXdhliMnI):
  rTqGAoykOQwfBEHDVcmuNjXdhliMJF={'_s_guit':rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_guit'],'_guinness-premium_session':rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_token']}
  if rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_guitv']:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJF['_s_guitv']=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_guitv']
  return rTqGAoykOQwfBEHDVcmuNjXdhliMJF
 def GetCredential(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,user_id,user_pw,user_pf):
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJP=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+'/api/session'
   rTqGAoykOQwfBEHDVcmuNjXdhliMJU={'email':user_id,'password':user_pw}
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJY={'accept':'application/vnd.frograms+json;version=4'}
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx.update(rTqGAoykOQwfBEHDVcmuNjXdhliMJY)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Post',rTqGAoykOQwfBEHDVcmuNjXdhliMJP,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMJU,params=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMFv)
   for rTqGAoykOQwfBEHDVcmuNjXdhliMJe in rTqGAoykOQwfBEHDVcmuNjXdhliMJa.cookies:
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJe.name=='_ale_session':
     rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_token']=rTqGAoykOQwfBEHDVcmuNjXdhliMJe.value
    elif rTqGAoykOQwfBEHDVcmuNjXdhliMJe.name=='_s_guit':
     rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_guit']=rTqGAoykOQwfBEHDVcmuNjXdhliMJe.value
   if rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_token']=='':
    rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Init_WC_Total()
    return rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
   rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Init_WC_Total()
   return rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  if rTqGAoykOQwfBEHDVcmuNjXdhliMnI.GetProfilesList(user_pf)==rTqGAoykOQwfBEHDVcmuNjXdhliMFp:
   rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Init_WC_Total()
   return rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  if user_pf!=0:
   if rTqGAoykOQwfBEHDVcmuNjXdhliMnI.GetProfilesConvert()==rTqGAoykOQwfBEHDVcmuNjXdhliMFp:
    rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Init_WC_Total()
    return rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  (rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['deviceId1'],rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['deviceId2'])=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_DeviceID(user_id,user_pf)
  rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['flyerId']=rTqGAoykOQwfBEHDVcmuNjXdhliMFW(rTqGAoykOQwfBEHDVcmuNjXdhliMPS(time.time()*1000))+'-'+rTqGAoykOQwfBEHDVcmuNjXdhliMnI.make_Random_Intstr(19)
  return rTqGAoykOQwfBEHDVcmuNjXdhliMFL
 def GetProfilesList(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,user_pf):
  rTqGAoykOQwfBEHDVcmuNjXdhliMJb=[]
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/groups/members'
   rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.MAIN_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJe=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.makeDefaultCookies()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMJe,redirects=rTqGAoykOQwfBEHDVcmuNjXdhliMFL)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJK=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJb.append(rTqGAoykOQwfBEHDVcmuNjXdhliMJK['naive_group']['chief_user']['code'])
   for rTqGAoykOQwfBEHDVcmuNjXdhliMJs in rTqGAoykOQwfBEHDVcmuNjXdhliMJK['naive_group']['valid_memberships']:
    rTqGAoykOQwfBEHDVcmuNjXdhliMJb.append(rTqGAoykOQwfBEHDVcmuNjXdhliMJs['user']['code'])
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(rTqGAoykOQwfBEHDVcmuNjXdhliMJb)
   rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_usercd']=rTqGAoykOQwfBEHDVcmuNjXdhliMJb[user_pf]
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
   rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Init_WC_Total()
   return rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  return rTqGAoykOQwfBEHDVcmuNjXdhliMFL
 def GetProfilesConvert(rTqGAoykOQwfBEHDVcmuNjXdhliMnI):
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/users/'+rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_usercd']+'/convert'
   rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJe =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.makeDefaultCookies()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Put',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMJe)
   for rTqGAoykOQwfBEHDVcmuNjXdhliMJe in rTqGAoykOQwfBEHDVcmuNjXdhliMJa.cookies:
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJe.name=='_s_guitv':
     rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_guitv']=rTqGAoykOQwfBEHDVcmuNjXdhliMJe.value
    elif rTqGAoykOQwfBEHDVcmuNjXdhliMJe.name=='_guinness-premium_session':
     rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_token']=rTqGAoykOQwfBEHDVcmuNjXdhliMJe.value
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
   rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Init_WC_Total()
   return rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  return rTqGAoykOQwfBEHDVcmuNjXdhliMFL
 def GetSubGroupList(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,stype):
  rTqGAoykOQwfBEHDVcmuNjXdhliMJR=[]
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/categories.json'
   rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJe =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.makeDefaultCookies()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMJe)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJv=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
   if not('genres' in rTqGAoykOQwfBEHDVcmuNjXdhliMJv):return rTqGAoykOQwfBEHDVcmuNjXdhliMJR
   if stype=='genres':
    rTqGAoykOQwfBEHDVcmuNjXdhliMJp=rTqGAoykOQwfBEHDVcmuNjXdhliMJv['genres']
   else:
    rTqGAoykOQwfBEHDVcmuNjXdhliMJp=rTqGAoykOQwfBEHDVcmuNjXdhliMJv['tags']
   for rTqGAoykOQwfBEHDVcmuNjXdhliMJC in rTqGAoykOQwfBEHDVcmuNjXdhliMJp:
    rTqGAoykOQwfBEHDVcmuNjXdhliMJL=rTqGAoykOQwfBEHDVcmuNjXdhliMJC['name']
    rTqGAoykOQwfBEHDVcmuNjXdhliMJg =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['api_path']
    rTqGAoykOQwfBEHDVcmuNjXdhliMJW =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['entity']['id']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIn={'group_name':rTqGAoykOQwfBEHDVcmuNjXdhliMJL,'api_path':rTqGAoykOQwfBEHDVcmuNjXdhliMJg,'tag_id':rTqGAoykOQwfBEHDVcmuNjXdhliMFW(rTqGAoykOQwfBEHDVcmuNjXdhliMJW)}
    rTqGAoykOQwfBEHDVcmuNjXdhliMJR.append(rTqGAoykOQwfBEHDVcmuNjXdhliMIn)
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
  return rTqGAoykOQwfBEHDVcmuNjXdhliMJR
 def GetCategoryList(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,stype,rTqGAoykOQwfBEHDVcmuNjXdhliMJW,rTqGAoykOQwfBEHDVcmuNjXdhliMJg,rTqGAoykOQwfBEHDVcmuNjXdhliMSt):
  rTqGAoykOQwfBEHDVcmuNjXdhliMJR=[]
  rTqGAoykOQwfBEHDVcmuNjXdhliMIJ=rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  rTqGAoykOQwfBEHDVcmuNjXdhliMIS={}
  try:
   if 'categories' in rTqGAoykOQwfBEHDVcmuNjXdhliMJg:
    rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/tags'
    rTqGAoykOQwfBEHDVcmuNjXdhliMIS['ids']=rTqGAoykOQwfBEHDVcmuNjXdhliMJW
   else: 
    rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/'+rTqGAoykOQwfBEHDVcmuNjXdhliMJg+'.json'
    if rTqGAoykOQwfBEHDVcmuNjXdhliMSt>1:
     rTqGAoykOQwfBEHDVcmuNjXdhliMIS['page']=rTqGAoykOQwfBEHDVcmuNjXdhliMFW(rTqGAoykOQwfBEHDVcmuNjXdhliMSt)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJe =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.makeDefaultCookies()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMIS,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMJe)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJv=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
   if not('contents' in rTqGAoykOQwfBEHDVcmuNjXdhliMJv):return rTqGAoykOQwfBEHDVcmuNjXdhliMJR,rTqGAoykOQwfBEHDVcmuNjXdhliMIJ
   rTqGAoykOQwfBEHDVcmuNjXdhliMJp=rTqGAoykOQwfBEHDVcmuNjXdhliMJv['contents']
   rTqGAoykOQwfBEHDVcmuNjXdhliMIJ=rTqGAoykOQwfBEHDVcmuNjXdhliMJv['meta']['has_next']
   for rTqGAoykOQwfBEHDVcmuNjXdhliMJC in rTqGAoykOQwfBEHDVcmuNjXdhliMJp:
    rTqGAoykOQwfBEHDVcmuNjXdhliMIF =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['code']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIP=rTqGAoykOQwfBEHDVcmuNjXdhliMJC['content_type']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIU =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['title']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIx =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['story']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIY =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['badge_text']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIa=rTqGAoykOQwfBEHDVcmuNjXdhliMFs=rTqGAoykOQwfBEHDVcmuNjXdhliMFK=''
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('poster') !=rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMIa=rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('poster').get('original')
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('stillcut')!=rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMFs =rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('stillcut').get('large')
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('thumbnail')!=rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMFK=rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('thumbnail').get('large')
    if rTqGAoykOQwfBEHDVcmuNjXdhliMFK=='' :rTqGAoykOQwfBEHDVcmuNjXdhliMFK=rTqGAoykOQwfBEHDVcmuNjXdhliMFs
    rTqGAoykOQwfBEHDVcmuNjXdhliMIe={'thumb':rTqGAoykOQwfBEHDVcmuNjXdhliMFs,'poster':rTqGAoykOQwfBEHDVcmuNjXdhliMIa,'fanart':rTqGAoykOQwfBEHDVcmuNjXdhliMFK}
    rTqGAoykOQwfBEHDVcmuNjXdhliMIb =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['year']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIt =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['film_rating_code']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIz=rTqGAoykOQwfBEHDVcmuNjXdhliMJC['film_rating_short']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIK =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['film_rating_long']
    if rTqGAoykOQwfBEHDVcmuNjXdhliMIP=='movies':
     rTqGAoykOQwfBEHDVcmuNjXdhliMIs =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['duration']
    else:
     rTqGAoykOQwfBEHDVcmuNjXdhliMIs ='0'
    rTqGAoykOQwfBEHDVcmuNjXdhliMIn={'code':rTqGAoykOQwfBEHDVcmuNjXdhliMIF,'content_type':rTqGAoykOQwfBEHDVcmuNjXdhliMIP,'title':rTqGAoykOQwfBEHDVcmuNjXdhliMIU,'story':rTqGAoykOQwfBEHDVcmuNjXdhliMIx,'thumbnail':rTqGAoykOQwfBEHDVcmuNjXdhliMIe,'year':rTqGAoykOQwfBEHDVcmuNjXdhliMIb,'film_rating_code':rTqGAoykOQwfBEHDVcmuNjXdhliMIt,'film_rating_short':rTqGAoykOQwfBEHDVcmuNjXdhliMIz,'film_rating_long':rTqGAoykOQwfBEHDVcmuNjXdhliMIK,'duration':rTqGAoykOQwfBEHDVcmuNjXdhliMIs,'badge':rTqGAoykOQwfBEHDVcmuNjXdhliMIY,}
    rTqGAoykOQwfBEHDVcmuNjXdhliMJR.append(rTqGAoykOQwfBEHDVcmuNjXdhliMIn)
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
  return rTqGAoykOQwfBEHDVcmuNjXdhliMJR,rTqGAoykOQwfBEHDVcmuNjXdhliMIJ
 def GetProgramInfo(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,program_code):
  rTqGAoykOQwfBEHDVcmuNjXdhliMIR={}
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/contents/'+program_code
   rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMFv)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJv=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
   rTqGAoykOQwfBEHDVcmuNjXdhliMIv=img_clearlogo=''
   rTqGAoykOQwfBEHDVcmuNjXdhliMIv=rTqGAoykOQwfBEHDVcmuNjXdhliMJv.get('poster').get('original')
   if rTqGAoykOQwfBEHDVcmuNjXdhliMPF(rTqGAoykOQwfBEHDVcmuNjXdhliMJv.get('title_logos'))>0:img_clearlogo=rTqGAoykOQwfBEHDVcmuNjXdhliMJv.get('title_logos')[0].get('src')
   rTqGAoykOQwfBEHDVcmuNjXdhliMIR={'imgPoster':rTqGAoykOQwfBEHDVcmuNjXdhliMIv,'imgClearlogo':img_clearlogo}
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
  return rTqGAoykOQwfBEHDVcmuNjXdhliMIR
 def GetSeasonList(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,program_code):
  rTqGAoykOQwfBEHDVcmuNjXdhliMIp=[]
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/aio_contents/'+program_code
   rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMFv)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJv=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
   if not('result' in rTqGAoykOQwfBEHDVcmuNjXdhliMJv):return rTqGAoykOQwfBEHDVcmuNjXdhliMIp
   for rTqGAoykOQwfBEHDVcmuNjXdhliMJC in rTqGAoykOQwfBEHDVcmuNjXdhliMJv.get('result').get('seasons'):
    rTqGAoykOQwfBEHDVcmuNjXdhliMIC =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['id']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIL =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['titles']['short']or rTqGAoykOQwfBEHDVcmuNjXdhliMJC['titles']['original']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIn={'seasonId':rTqGAoykOQwfBEHDVcmuNjXdhliMIC,'seasonNm':rTqGAoykOQwfBEHDVcmuNjXdhliMIL,}
    rTqGAoykOQwfBEHDVcmuNjXdhliMIp.append(rTqGAoykOQwfBEHDVcmuNjXdhliMIn)
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
  return rTqGAoykOQwfBEHDVcmuNjXdhliMIp
 def GetEpisodoList(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,program_code,rTqGAoykOQwfBEHDVcmuNjXdhliMSt,orderby='asc'):
  rTqGAoykOQwfBEHDVcmuNjXdhliMJR=[]
  rTqGAoykOQwfBEHDVcmuNjXdhliMIJ=rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  rTqGAoykOQwfBEHDVcmuNjXdhliMIg=''
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/contents/'+program_code+'/tv_episodes.json'
   rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
   rTqGAoykOQwfBEHDVcmuNjXdhliMIS={'all':'true'}
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMIS,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMFv)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJv=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
   if not('tv_episode_codes' in rTqGAoykOQwfBEHDVcmuNjXdhliMJv):return rTqGAoykOQwfBEHDVcmuNjXdhliMJR,rTqGAoykOQwfBEHDVcmuNjXdhliMIJ
   rTqGAoykOQwfBEHDVcmuNjXdhliMJp=rTqGAoykOQwfBEHDVcmuNjXdhliMJv['tv_episode_codes']
   rTqGAoykOQwfBEHDVcmuNjXdhliMIW=rTqGAoykOQwfBEHDVcmuNjXdhliMPF(rTqGAoykOQwfBEHDVcmuNjXdhliMJp)
   rTqGAoykOQwfBEHDVcmuNjXdhliMSn =rTqGAoykOQwfBEHDVcmuNjXdhliMPS(rTqGAoykOQwfBEHDVcmuNjXdhliMIW//(rTqGAoykOQwfBEHDVcmuNjXdhliMnI.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    rTqGAoykOQwfBEHDVcmuNjXdhliMSJ =(rTqGAoykOQwfBEHDVcmuNjXdhliMIW-1)-((rTqGAoykOQwfBEHDVcmuNjXdhliMSt-1)*rTqGAoykOQwfBEHDVcmuNjXdhliMnI.EPISODE_LIMIT)
   else:
    rTqGAoykOQwfBEHDVcmuNjXdhliMSJ =(rTqGAoykOQwfBEHDVcmuNjXdhliMSt-1)*rTqGAoykOQwfBEHDVcmuNjXdhliMnI.EPISODE_LIMIT
   for i in rTqGAoykOQwfBEHDVcmuNjXdhliMPn(rTqGAoykOQwfBEHDVcmuNjXdhliMnI.EPISODE_LIMIT):
    if orderby=='desc':
     rTqGAoykOQwfBEHDVcmuNjXdhliMSI=rTqGAoykOQwfBEHDVcmuNjXdhliMSJ-i
     if rTqGAoykOQwfBEHDVcmuNjXdhliMSI<0:break
    else:
     rTqGAoykOQwfBEHDVcmuNjXdhliMSI=rTqGAoykOQwfBEHDVcmuNjXdhliMSJ+i
     if rTqGAoykOQwfBEHDVcmuNjXdhliMSI>=rTqGAoykOQwfBEHDVcmuNjXdhliMIW:break
    if rTqGAoykOQwfBEHDVcmuNjXdhliMIg!='':rTqGAoykOQwfBEHDVcmuNjXdhliMIg+=','
    rTqGAoykOQwfBEHDVcmuNjXdhliMIg+=rTqGAoykOQwfBEHDVcmuNjXdhliMJp[rTqGAoykOQwfBEHDVcmuNjXdhliMSI]
   if rTqGAoykOQwfBEHDVcmuNjXdhliMSn>rTqGAoykOQwfBEHDVcmuNjXdhliMSt:rTqGAoykOQwfBEHDVcmuNjXdhliMIJ=rTqGAoykOQwfBEHDVcmuNjXdhliMFL
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
  rTqGAoykOQwfBEHDVcmuNjXdhliMSF=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.GetProgramInfo(program_code)
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
   rTqGAoykOQwfBEHDVcmuNjXdhliMIS={'codes':rTqGAoykOQwfBEHDVcmuNjXdhliMIg}
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMIS,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMFv)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJv=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
   if not('tv_episodes' in rTqGAoykOQwfBEHDVcmuNjXdhliMJv):return rTqGAoykOQwfBEHDVcmuNjXdhliMJR
   rTqGAoykOQwfBEHDVcmuNjXdhliMJp=rTqGAoykOQwfBEHDVcmuNjXdhliMJv['tv_episodes']
   for rTqGAoykOQwfBEHDVcmuNjXdhliMJC in rTqGAoykOQwfBEHDVcmuNjXdhliMJp:
    rTqGAoykOQwfBEHDVcmuNjXdhliMIF =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['code']
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJC['title']:
     rTqGAoykOQwfBEHDVcmuNjXdhliMIU =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['title']
    else:
     rTqGAoykOQwfBEHDVcmuNjXdhliMIU =''
    rTqGAoykOQwfBEHDVcmuNjXdhliMIa=rTqGAoykOQwfBEHDVcmuNjXdhliMFs=rTqGAoykOQwfBEHDVcmuNjXdhliMFK=rTqGAoykOQwfBEHDVcmuNjXdhliMSP=''
    rTqGAoykOQwfBEHDVcmuNjXdhliMIa =rTqGAoykOQwfBEHDVcmuNjXdhliMSF.get('imgPoster')
    rTqGAoykOQwfBEHDVcmuNjXdhliMSP=rTqGAoykOQwfBEHDVcmuNjXdhliMSF.get('imgClearlogo')
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('stillcut') !=rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMFs =rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('stillcut').get('large')
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('tv_season_stillcut')!=rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMFK=rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('tv_season_stillcut').get('large')
    rTqGAoykOQwfBEHDVcmuNjXdhliMIe={'thumb':rTqGAoykOQwfBEHDVcmuNjXdhliMFs,'poster':rTqGAoykOQwfBEHDVcmuNjXdhliMIa,'fanart':rTqGAoykOQwfBEHDVcmuNjXdhliMFK,'clearlogo':rTqGAoykOQwfBEHDVcmuNjXdhliMSP}
    rTqGAoykOQwfBEHDVcmuNjXdhliMSU =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['display_number']
    rTqGAoykOQwfBEHDVcmuNjXdhliMSx=rTqGAoykOQwfBEHDVcmuNjXdhliMJC['tv_season_title']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIs =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['duration']
    try:
     rTqGAoykOQwfBEHDVcmuNjXdhliMSY=rTqGAoykOQwfBEHDVcmuNjXdhliMJC['episode_number']
    except:
     rTqGAoykOQwfBEHDVcmuNjXdhliMSY='0'
    rTqGAoykOQwfBEHDVcmuNjXdhliMIn={'code':rTqGAoykOQwfBEHDVcmuNjXdhliMIF,'title':rTqGAoykOQwfBEHDVcmuNjXdhliMIU,'thumbnail':rTqGAoykOQwfBEHDVcmuNjXdhliMIe,'display_num':rTqGAoykOQwfBEHDVcmuNjXdhliMSU,'season_title':rTqGAoykOQwfBEHDVcmuNjXdhliMSx,'duration':rTqGAoykOQwfBEHDVcmuNjXdhliMIs,'episode_number':rTqGAoykOQwfBEHDVcmuNjXdhliMSY}
    rTqGAoykOQwfBEHDVcmuNjXdhliMJR.append(rTqGAoykOQwfBEHDVcmuNjXdhliMIn)
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
  return rTqGAoykOQwfBEHDVcmuNjXdhliMJR,rTqGAoykOQwfBEHDVcmuNjXdhliMIJ
 def GetHomeList_bak(rTqGAoykOQwfBEHDVcmuNjXdhliMnI):
  rTqGAoykOQwfBEHDVcmuNjXdhliMSa=[]
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/aio_browses/video/header'
   rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJF=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.makeDefaultCookies()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMJF)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJK=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
   if not('result' in rTqGAoykOQwfBEHDVcmuNjXdhliMJK):return rTqGAoykOQwfBEHDVcmuNjXdhliMSa
   rTqGAoykOQwfBEHDVcmuNjXdhliMJp=rTqGAoykOQwfBEHDVcmuNjXdhliMJK['result'][0]['cells']
   for rTqGAoykOQwfBEHDVcmuNjXdhliMJC in rTqGAoykOQwfBEHDVcmuNjXdhliMJp:
    rTqGAoykOQwfBEHDVcmuNjXdhliMIP=rTqGAoykOQwfBEHDVcmuNjXdhliMJC['relations'][0]['type']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIU =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['title']
    rTqGAoykOQwfBEHDVcmuNjXdhliMSe =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['badge']
    rTqGAoykOQwfBEHDVcmuNjXdhliMSb =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['media']['fullhd']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIe ={'thumb':rTqGAoykOQwfBEHDVcmuNjXdhliMSb,'fanart':rTqGAoykOQwfBEHDVcmuNjXdhliMSb}
    rTqGAoykOQwfBEHDVcmuNjXdhliMIF =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['relations'][0]['id']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIn={'code':rTqGAoykOQwfBEHDVcmuNjXdhliMIF,'content_type':rTqGAoykOQwfBEHDVcmuNjXdhliMIP,'title':rTqGAoykOQwfBEHDVcmuNjXdhliMIU,'bedge':rTqGAoykOQwfBEHDVcmuNjXdhliMSe,'thumbnail':rTqGAoykOQwfBEHDVcmuNjXdhliMIe}
    rTqGAoykOQwfBEHDVcmuNjXdhliMSa.append(rTqGAoykOQwfBEHDVcmuNjXdhliMIn)
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
  return rTqGAoykOQwfBEHDVcmuNjXdhliMSa
 def GetHomeList(rTqGAoykOQwfBEHDVcmuNjXdhliMnI):
  rTqGAoykOQwfBEHDVcmuNjXdhliMSa=[]
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/aio_browses/video/all'
   rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJF=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.makeDefaultCookies()
   rTqGAoykOQwfBEHDVcmuNjXdhliMSt=1
   rTqGAoykOQwfBEHDVcmuNjXdhliMIJ=rTqGAoykOQwfBEHDVcmuNjXdhliMFL
   while rTqGAoykOQwfBEHDVcmuNjXdhliMIJ:
    rTqGAoykOQwfBEHDVcmuNjXdhliMnS={'page':rTqGAoykOQwfBEHDVcmuNjXdhliMFW(rTqGAoykOQwfBEHDVcmuNjXdhliMSt)}
    rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMnS,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMJF)
    rTqGAoykOQwfBEHDVcmuNjXdhliMJK=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
    if not('result' in rTqGAoykOQwfBEHDVcmuNjXdhliMJK):return rTqGAoykOQwfBEHDVcmuNjXdhliMSa
    rTqGAoykOQwfBEHDVcmuNjXdhliMJp=rTqGAoykOQwfBEHDVcmuNjXdhliMJK['result']['items']
    for rTqGAoykOQwfBEHDVcmuNjXdhliMJC in rTqGAoykOQwfBEHDVcmuNjXdhliMJp:
     rTqGAoykOQwfBEHDVcmuNjXdhliMIP=rTqGAoykOQwfBEHDVcmuNjXdhliMJC['type']
     if rTqGAoykOQwfBEHDVcmuNjXdhliMIP in['custom_list']:
      rTqGAoykOQwfBEHDVcmuNjXdhliMIn={'code':rTqGAoykOQwfBEHDVcmuNjXdhliMJC['relations'][0]['id'],'content_type':rTqGAoykOQwfBEHDVcmuNjXdhliMJC['relations'][0]['type'],'title':rTqGAoykOQwfBEHDVcmuNjXdhliMJC['title'],}
      rTqGAoykOQwfBEHDVcmuNjXdhliMSa.append(rTqGAoykOQwfBEHDVcmuNjXdhliMIn)
    rTqGAoykOQwfBEHDVcmuNjXdhliMSt+=1
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJK['result']['next']==rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMIJ=rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
  return rTqGAoykOQwfBEHDVcmuNjXdhliMSa
 def GetSearchList(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,search_key,rTqGAoykOQwfBEHDVcmuNjXdhliMSt):
  rTqGAoykOQwfBEHDVcmuNjXdhliMSz=[]
  rTqGAoykOQwfBEHDVcmuNjXdhliMIJ=rTqGAoykOQwfBEHDVcmuNjXdhliMFp
  try:
   rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/search.json'
   rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
   rTqGAoykOQwfBEHDVcmuNjXdhliMIS={'query':search_key,'page':rTqGAoykOQwfBEHDVcmuNjXdhliMFW(rTqGAoykOQwfBEHDVcmuNjXdhliMSt),'per':rTqGAoykOQwfBEHDVcmuNjXdhliMFW(rTqGAoykOQwfBEHDVcmuNjXdhliMnI.SEARCH_LIMIT),'exclude':'limited'}
   rTqGAoykOQwfBEHDVcmuNjXdhliMJx=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMIS,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMFv)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJv=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
   if not('results' in rTqGAoykOQwfBEHDVcmuNjXdhliMJv):return rTqGAoykOQwfBEHDVcmuNjXdhliMSz,rTqGAoykOQwfBEHDVcmuNjXdhliMIJ
   rTqGAoykOQwfBEHDVcmuNjXdhliMJp=rTqGAoykOQwfBEHDVcmuNjXdhliMJv['results']
   rTqGAoykOQwfBEHDVcmuNjXdhliMIJ=rTqGAoykOQwfBEHDVcmuNjXdhliMJv['meta']['has_next']
   for rTqGAoykOQwfBEHDVcmuNjXdhliMJC in rTqGAoykOQwfBEHDVcmuNjXdhliMJp:
    rTqGAoykOQwfBEHDVcmuNjXdhliMIF =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['code']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIP=rTqGAoykOQwfBEHDVcmuNjXdhliMJC['content_type']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIU =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['title']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIx =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['story']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIa=rTqGAoykOQwfBEHDVcmuNjXdhliMFs=rTqGAoykOQwfBEHDVcmuNjXdhliMFK=''
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('poster') !=rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMIa=rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('poster').get('original')
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('stillcut')!=rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMFs =rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('stillcut').get('large')
    if rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('thumbnail')!=rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMFK=rTqGAoykOQwfBEHDVcmuNjXdhliMJC.get('thumbnail').get('large')
    if rTqGAoykOQwfBEHDVcmuNjXdhliMFK=='' :rTqGAoykOQwfBEHDVcmuNjXdhliMFK=rTqGAoykOQwfBEHDVcmuNjXdhliMFs
    rTqGAoykOQwfBEHDVcmuNjXdhliMIe={'thumb':rTqGAoykOQwfBEHDVcmuNjXdhliMFs,'poster':rTqGAoykOQwfBEHDVcmuNjXdhliMIa,'fanart':rTqGAoykOQwfBEHDVcmuNjXdhliMFK}
    rTqGAoykOQwfBEHDVcmuNjXdhliMIb =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['year']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIt =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['film_rating_code']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIz=rTqGAoykOQwfBEHDVcmuNjXdhliMJC['film_rating_short']
    rTqGAoykOQwfBEHDVcmuNjXdhliMIK =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['film_rating_long']
    if rTqGAoykOQwfBEHDVcmuNjXdhliMIP=='movies':
     rTqGAoykOQwfBEHDVcmuNjXdhliMIs =rTqGAoykOQwfBEHDVcmuNjXdhliMJC['duration']
    else:
     rTqGAoykOQwfBEHDVcmuNjXdhliMIs ='0'
    rTqGAoykOQwfBEHDVcmuNjXdhliMIn={'code':rTqGAoykOQwfBEHDVcmuNjXdhliMIF,'content_type':rTqGAoykOQwfBEHDVcmuNjXdhliMIP,'title':rTqGAoykOQwfBEHDVcmuNjXdhliMIU,'story':rTqGAoykOQwfBEHDVcmuNjXdhliMIx,'thumbnail':rTqGAoykOQwfBEHDVcmuNjXdhliMIe,'year':rTqGAoykOQwfBEHDVcmuNjXdhliMIb,'film_rating_code':rTqGAoykOQwfBEHDVcmuNjXdhliMIt,'film_rating_short':rTqGAoykOQwfBEHDVcmuNjXdhliMIz,'film_rating_long':rTqGAoykOQwfBEHDVcmuNjXdhliMIK,'duration':rTqGAoykOQwfBEHDVcmuNjXdhliMIs}
    rTqGAoykOQwfBEHDVcmuNjXdhliMSz.append(rTqGAoykOQwfBEHDVcmuNjXdhliMIn)
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
  return rTqGAoykOQwfBEHDVcmuNjXdhliMSz,rTqGAoykOQwfBEHDVcmuNjXdhliMIJ
 def DeleteContinueList(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,codeList):
  try:
   for rTqGAoykOQwfBEHDVcmuNjXdhliMSK in codeList:
    rTqGAoykOQwfBEHDVcmuNjXdhliMJt ='/api/watches/'+rTqGAoykOQwfBEHDVcmuNjXdhliMSK
    rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
    rTqGAoykOQwfBEHDVcmuNjXdhliMJx =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
    rTqGAoykOQwfBEHDVcmuNjXdhliMJe =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.makeDefaultCookies()
    rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Delete',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,params=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMJe)
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   rTqGAoykOQwfBEHDVcmuNjXdhliMPI(exception)
 def Get_Now_Datetime(rTqGAoykOQwfBEHDVcmuNjXdhliMnI):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,movie_code,quality_str,proxyUse=rTqGAoykOQwfBEHDVcmuNjXdhliMFp,inScreen='BASE',inSound='2CH'):
  rTqGAoykOQwfBEHDVcmuNjXdhliMSR={'streamUrl':'','subtitleUrl':'','customdata':'',}
  try:
   if proxyUse:
    rTqGAoykOQwfBEHDVcmuNjXdhliMSv ='0' if inScreen=='BASE' and inSound=='2CH' else '3'
    rTqGAoykOQwfBEHDVcmuNjXdhliMSp='4' if inScreen=='VISION' else '1'
    rTqGAoykOQwfBEHDVcmuNjXdhliMSC ='0' if inSound!='ATMOS' else '1'
    rTqGAoykOQwfBEHDVcmuNjXdhliMPI('hCodec  = '+rTqGAoykOQwfBEHDVcmuNjXdhliMSv)
    rTqGAoykOQwfBEHDVcmuNjXdhliMPI('hScreen = '+rTqGAoykOQwfBEHDVcmuNjXdhliMSp)
    rTqGAoykOQwfBEHDVcmuNjXdhliMPI('hSound  = '+rTqGAoykOQwfBEHDVcmuNjXdhliMSC)
    rTqGAoykOQwfBEHDVcmuNjXdhliMJt='/api/watch/'+movie_code+'.json?localtracks=%5B%5D&player_v2=true'
    rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
    rTqGAoykOQwfBEHDVcmuNjXdhliMJx=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers_v2()
    rTqGAoykOQwfBEHDVcmuNjXdhliMJY={'X-FROGRAMS-MARS-CODEC-FLAG':rTqGAoykOQwfBEHDVcmuNjXdhliMSv,'X-WatchaPlay-Client-Codec-Flag':rTqGAoykOQwfBEHDVcmuNjXdhliMSv,'X-FROGRAMS-MARS-HDR-CAPABILITIES':rTqGAoykOQwfBEHDVcmuNjXdhliMSp,'X-WatchaPlay-Client-HDR-Capabilities':rTqGAoykOQwfBEHDVcmuNjXdhliMSp,'X-FROGRAMS-MARS-AUDIO-CAPABILITIES':rTqGAoykOQwfBEHDVcmuNjXdhliMSC,'X-WatchaPlay-Client-Audio-Capabilities':rTqGAoykOQwfBEHDVcmuNjXdhliMSC,}
    rTqGAoykOQwfBEHDVcmuNjXdhliMJx.update(rTqGAoykOQwfBEHDVcmuNjXdhliMJY)
   else:
    rTqGAoykOQwfBEHDVcmuNjXdhliMJt='/api/watch/'+movie_code+'.json'
    rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+rTqGAoykOQwfBEHDVcmuNjXdhliMJt
    rTqGAoykOQwfBEHDVcmuNjXdhliMJx=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
    rTqGAoykOQwfBEHDVcmuNjXdhliMJY={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str,}
    rTqGAoykOQwfBEHDVcmuNjXdhliMJx.update(rTqGAoykOQwfBEHDVcmuNjXdhliMJY)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJe=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.makeDefaultCookies()
   rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMJe)
   rTqGAoykOQwfBEHDVcmuNjXdhliMJv=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
   rTqGAoykOQwfBEHDVcmuNjXdhliMSR['streamUrl']=rTqGAoykOQwfBEHDVcmuNjXdhliMJv['streams'][0]['source']
   if rTqGAoykOQwfBEHDVcmuNjXdhliMSR['streamUrl']==rTqGAoykOQwfBEHDVcmuNjXdhliMFv:return rTqGAoykOQwfBEHDVcmuNjXdhliMSR
   if 'subtitles' in rTqGAoykOQwfBEHDVcmuNjXdhliMJv['streams'][0]:
    for rTqGAoykOQwfBEHDVcmuNjXdhliMSL in rTqGAoykOQwfBEHDVcmuNjXdhliMJv['streams'][0]['subtitles']:
     if rTqGAoykOQwfBEHDVcmuNjXdhliMSL['lang']=='ko':
      rTqGAoykOQwfBEHDVcmuNjXdhliMSR['subtitleUrl']=rTqGAoykOQwfBEHDVcmuNjXdhliMSL['url']
      break
   rTqGAoykOQwfBEHDVcmuNjXdhliMSg =rTqGAoykOQwfBEHDVcmuNjXdhliMJv['ping_payload']
   rTqGAoykOQwfBEHDVcmuNjXdhliMSW =rTqGAoykOQwfBEHDVcmuNjXdhliMnI.WC['cookies']['watcha_usercd']
   rTqGAoykOQwfBEHDVcmuNjXdhliMFn={'merchant':'giitd_frograms','sessionId':rTqGAoykOQwfBEHDVcmuNjXdhliMSg,'userId':rTqGAoykOQwfBEHDVcmuNjXdhliMSW}
   rTqGAoykOQwfBEHDVcmuNjXdhliMFJ=json.dumps(rTqGAoykOQwfBEHDVcmuNjXdhliMFn,separators=(",",":")).encode('UTF-8')
   rTqGAoykOQwfBEHDVcmuNjXdhliMSR['customdata']=base64.b64encode(rTqGAoykOQwfBEHDVcmuNjXdhliMFJ)
  except rTqGAoykOQwfBEHDVcmuNjXdhliMPJ as exception:
   return rTqGAoykOQwfBEHDVcmuNjXdhliMSR
  return rTqGAoykOQwfBEHDVcmuNjXdhliMSR
 def GetBookmarkInfo(rTqGAoykOQwfBEHDVcmuNjXdhliMnI,videoid,vidtype):
  rTqGAoykOQwfBEHDVcmuNjXdhliMFI={'indexinfo':{'ott':'watcha','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  rTqGAoykOQwfBEHDVcmuNjXdhliMJz=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.API_DOMAIN+'/api/contents/'+videoid
  rTqGAoykOQwfBEHDVcmuNjXdhliMJx=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.Get_Base_Headers()
  rTqGAoykOQwfBEHDVcmuNjXdhliMJa=rTqGAoykOQwfBEHDVcmuNjXdhliMnI.callRequestCookies('Get',rTqGAoykOQwfBEHDVcmuNjXdhliMJz,payload=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,params=rTqGAoykOQwfBEHDVcmuNjXdhliMFv,headers=rTqGAoykOQwfBEHDVcmuNjXdhliMJx,cookies=rTqGAoykOQwfBEHDVcmuNjXdhliMFv)
  rTqGAoykOQwfBEHDVcmuNjXdhliMJK=json.loads(rTqGAoykOQwfBEHDVcmuNjXdhliMJa.text)
  if not('title' in rTqGAoykOQwfBEHDVcmuNjXdhliMJK):return{}
  rTqGAoykOQwfBEHDVcmuNjXdhliMFS=rTqGAoykOQwfBEHDVcmuNjXdhliMJK
  rTqGAoykOQwfBEHDVcmuNjXdhliMPI(rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('duration'))
  rTqGAoykOQwfBEHDVcmuNjXdhliMFP=rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('title')
  rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['infoLabels']['title']=rTqGAoykOQwfBEHDVcmuNjXdhliMFP
  rTqGAoykOQwfBEHDVcmuNjXdhliMFP +=u'  (%s)'%(rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('year'))
  rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['title'] =rTqGAoykOQwfBEHDVcmuNjXdhliMFP
  rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['infoLabels']['mpaa'] =rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('film_rating_long')
  rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['infoLabels']['plot'] =rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('story').replace('<br>','\n')
  rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['infoLabels']['year'] =rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('year')
  if vidtype=='movie':
   rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['infoLabels']['duration']=rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('duration')
  rTqGAoykOQwfBEHDVcmuNjXdhliMFU=[]
  for rTqGAoykOQwfBEHDVcmuNjXdhliMFx in rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('actors'):
   rTqGAoykOQwfBEHDVcmuNjXdhliMFY =rTqGAoykOQwfBEHDVcmuNjXdhliMFx.get('name')
   rTqGAoykOQwfBEHDVcmuNjXdhliMFa='' if rTqGAoykOQwfBEHDVcmuNjXdhliMFx.get('photo')==rTqGAoykOQwfBEHDVcmuNjXdhliMFv else rTqGAoykOQwfBEHDVcmuNjXdhliMFx.get('photo').get('small')
   rTqGAoykOQwfBEHDVcmuNjXdhliMFU.append({'name':rTqGAoykOQwfBEHDVcmuNjXdhliMFY,'thumbnail':rTqGAoykOQwfBEHDVcmuNjXdhliMFa})
  if rTqGAoykOQwfBEHDVcmuNjXdhliMPF(rTqGAoykOQwfBEHDVcmuNjXdhliMFU)>0:
   rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['infoLabels']['cast']=rTqGAoykOQwfBEHDVcmuNjXdhliMFU
  rTqGAoykOQwfBEHDVcmuNjXdhliMFe=[]
  for rTqGAoykOQwfBEHDVcmuNjXdhliMFb in rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('directors'):rTqGAoykOQwfBEHDVcmuNjXdhliMFe.append(rTqGAoykOQwfBEHDVcmuNjXdhliMFb.get('name'))
  if rTqGAoykOQwfBEHDVcmuNjXdhliMPF(rTqGAoykOQwfBEHDVcmuNjXdhliMFe)>0:
   rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['infoLabels']['director']=rTqGAoykOQwfBEHDVcmuNjXdhliMFe
  rTqGAoykOQwfBEHDVcmuNjXdhliMFt=[]
  for rTqGAoykOQwfBEHDVcmuNjXdhliMFz in rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('genres'):rTqGAoykOQwfBEHDVcmuNjXdhliMFt.append(rTqGAoykOQwfBEHDVcmuNjXdhliMFz.get('name'))
  if rTqGAoykOQwfBEHDVcmuNjXdhliMPF(rTqGAoykOQwfBEHDVcmuNjXdhliMFt)>0:
   rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['infoLabels']['genre']=rTqGAoykOQwfBEHDVcmuNjXdhliMFt
  rTqGAoykOQwfBEHDVcmuNjXdhliMIa =''
  rTqGAoykOQwfBEHDVcmuNjXdhliMFK =''
  rTqGAoykOQwfBEHDVcmuNjXdhliMFs =''
  if rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('poster') !=rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMIa =rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('poster').get('original')
  if rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('thumbnail')!=rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMFK =rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('thumbnail').get('large')
  if rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('stillcut')!=rTqGAoykOQwfBEHDVcmuNjXdhliMFv:rTqGAoykOQwfBEHDVcmuNjXdhliMFs =rTqGAoykOQwfBEHDVcmuNjXdhliMFS.get('stillcut').get('large')
  if rTqGAoykOQwfBEHDVcmuNjXdhliMFK=='':rTqGAoykOQwfBEHDVcmuNjXdhliMFK=rTqGAoykOQwfBEHDVcmuNjXdhliMFs
  rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['thumbnail']['poster']=rTqGAoykOQwfBEHDVcmuNjXdhliMIa
  rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['thumbnail']['fanart']=rTqGAoykOQwfBEHDVcmuNjXdhliMFK
  rTqGAoykOQwfBEHDVcmuNjXdhliMFI['saveinfo']['thumbnail']['thumb']=rTqGAoykOQwfBEHDVcmuNjXdhliMFs
  return rTqGAoykOQwfBEHDVcmuNjXdhliMFI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
