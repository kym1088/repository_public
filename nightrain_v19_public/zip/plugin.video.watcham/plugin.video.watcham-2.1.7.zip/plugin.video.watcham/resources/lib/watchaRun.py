__author__="NightRain"
NHYEiPtkVTIpvmuaRbGUxlQwFfzrqc=object
NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ=None
NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC=int
NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK=True
NHYEiPtkVTIpvmuaRbGUxlQwFfzreL=False
NHYEiPtkVTIpvmuaRbGUxlQwFfzreg=type
NHYEiPtkVTIpvmuaRbGUxlQwFfzrey=dict
NHYEiPtkVTIpvmuaRbGUxlQwFfzreA=len
NHYEiPtkVTIpvmuaRbGUxlQwFfzreS=range
NHYEiPtkVTIpvmuaRbGUxlQwFfzreq=str
NHYEiPtkVTIpvmuaRbGUxlQwFfzreO=open
NHYEiPtkVTIpvmuaRbGUxlQwFfzreX=Exception
NHYEiPtkVTIpvmuaRbGUxlQwFfzreW=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
NHYEiPtkVTIpvmuaRbGUxlQwFfzrLy=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-','icon':'history.png'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'}]
NHYEiPtkVTIpvmuaRbGUxlQwFfzrLA=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
NHYEiPtkVTIpvmuaRbGUxlQwFfzrLS=40
NHYEiPtkVTIpvmuaRbGUxlQwFfzrLq =20
NHYEiPtkVTIpvmuaRbGUxlQwFfzrLe =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
NHYEiPtkVTIpvmuaRbGUxlQwFfzrLO =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
NHYEiPtkVTIpvmuaRbGUxlQwFfzrLX=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
from watchaCore import*
class NHYEiPtkVTIpvmuaRbGUxlQwFfzrLg(NHYEiPtkVTIpvmuaRbGUxlQwFfzrqc):
 def __init__(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,NHYEiPtkVTIpvmuaRbGUxlQwFfzrLn,NHYEiPtkVTIpvmuaRbGUxlQwFfzrLd,NHYEiPtkVTIpvmuaRbGUxlQwFfzrLh):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_url =NHYEiPtkVTIpvmuaRbGUxlQwFfzrLn
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLd
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.main_params =NHYEiPtkVTIpvmuaRbGUxlQwFfzrLh
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj =bCYBDKHslJvRpGOwQgVTekAXrdqWfF() 
 def addon_noti(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,sting):
  try:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLs=xbmcgui.Dialog()
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLs.notification(__addonname__,sting)
  except:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ
 def addon_log(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,string):
  try:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLD=string.encode('utf-8','ignore')
  except:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLD='addonException: addon_log'
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLB=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,NHYEiPtkVTIpvmuaRbGUxlQwFfzrLD),level=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLB)
 def get_keyboard_input(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLo=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ
  kb=xbmc.Keyboard()
  kb.setHeading(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLo=kb.getText()
  return NHYEiPtkVTIpvmuaRbGUxlQwFfzrLo
 def get_settings_login_info(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLj =__addon__.getSetting('id')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLc =__addon__.getSetting('pw')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLJ=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(__addon__.getSetting('selected_profile'))
  return(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLj,NHYEiPtkVTIpvmuaRbGUxlQwFfzrLc,NHYEiPtkVTIpvmuaRbGUxlQwFfzrLJ)
 def get_settings_totalsearch(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLC =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK if __addon__.getSetting('local_search')=='true' else NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLK=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK if __addon__.getSetting('local_history')=='true' else NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgL =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK if __addon__.getSetting('total_search')=='true' else NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgy=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK if __addon__.getSetting('total_history')=='true' else NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
  return(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLC,NHYEiPtkVTIpvmuaRbGUxlQwFfzrLK,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgL,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgy)
 def get_selQuality(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  try:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgA=['3840x2160/1','1920x1080/1','1280x720/1']
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgS=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(__addon__.getSetting('selected_quality'))
   return NHYEiPtkVTIpvmuaRbGUxlQwFfzrgA[NHYEiPtkVTIpvmuaRbGUxlQwFfzrgS]
  except:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ
  return 1080 
 def get_settings_direct_replay(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgq=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(__addon__.getSetting('direct_replay'))
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrgq==0:
   return NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
  else:
   return NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK
 def set_winCredential(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,credential):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge=xbmcgui.Window(10000)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_LOGINTIME',NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge=xbmcgui.Window(10000)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgO={'watcha_token':NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.getProperty('WATCHA_M_TOKEN'),'watcha_guit':NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.getProperty('WATCHA_M_GUIT'),'watcha_guitv':NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.getProperty('WATCHA_M_GUITV'),'watcha_usercd':NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.getProperty('WATCHA_M_USERCD')}
  return NHYEiPtkVTIpvmuaRbGUxlQwFfzrgO
 def set_winEpisodeOrderby(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgX):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge=xbmcgui.Window(10000)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_ORDERBY',NHYEiPtkVTIpvmuaRbGUxlQwFfzrgX)
 def get_winEpisodeOrderby(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge=xbmcgui.Window(10000)
  return NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,args):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgX =args.get('orderby')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.set_winEpisodeOrderby(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgX)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,label,sublabel='',img='',infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK,params='',isLink=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL,ContextMenu=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgW='%s?%s'%(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_url,urllib.parse.urlencode(params))
  if sublabel:NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn='%s < %s >'%(label,sublabel)
  else: NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn=label
  if not img:img='DefaultFolder.png'
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgd=xbmcgui.ListItem(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzreg(img)==NHYEiPtkVTIpvmuaRbGUxlQwFfzrey:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgd.setArt(img)
  else:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgd.setArt({'thumb':img,'poster':img})
  if infoLabels:NHYEiPtkVTIpvmuaRbGUxlQwFfzrgd.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgd.setProperty('IsPlayable','true')
  if ContextMenu:NHYEiPtkVTIpvmuaRbGUxlQwFfzrgd.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgW,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgd,isFolder)
 def dp_Main_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  (NHYEiPtkVTIpvmuaRbGUxlQwFfzrLC,NHYEiPtkVTIpvmuaRbGUxlQwFfzrLK,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgL,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgy)=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_settings_totalsearch()
  for NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh in NHYEiPtkVTIpvmuaRbGUxlQwFfzrLy:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('title')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM=''
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('mode')=='LOCAL_SEARCH' and NHYEiPtkVTIpvmuaRbGUxlQwFfzrLC ==NHYEiPtkVTIpvmuaRbGUxlQwFfzreL:continue
   elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('mode')=='SEARCH_HISTORY' and NHYEiPtkVTIpvmuaRbGUxlQwFfzrLK==NHYEiPtkVTIpvmuaRbGUxlQwFfzreL:continue
   elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('mode')=='TOTAL_SEARCH' and NHYEiPtkVTIpvmuaRbGUxlQwFfzrgL ==NHYEiPtkVTIpvmuaRbGUxlQwFfzreL:continue
   elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('mode')=='TOTAL_HISTORY' and NHYEiPtkVTIpvmuaRbGUxlQwFfzrgy==NHYEiPtkVTIpvmuaRbGUxlQwFfzreL:continue
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('mode'),'stype':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('stype'),'api_path':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('api_path'),'page':'1','sort':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('sort'),'tag_id':'-'}
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('mode')=='LOCAL_SEARCH':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['historyyn']='Y' 
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY']:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgB =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK
   else:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgB =NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
   if 'icon' in NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh:NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',NHYEiPtkVTIpvmuaRbGUxlQwFfzrgh.get('icon')) 
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel='',img=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs,isLink=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgB)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzreA(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLy)>0:xbmcplugin.endOfDirectory(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle)
 def login_main(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  (NHYEiPtkVTIpvmuaRbGUxlQwFfzrgj,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgc,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgJ)=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_settings_login_info()
  if not(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgj and NHYEiPtkVTIpvmuaRbGUxlQwFfzrgc):
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLs=xbmcgui.Dialog()
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgC=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLs.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzrgC==NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_winEpisodeOrderby()=='':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.set_winEpisodeOrderby('asc')
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.cookiefile_check():return
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgK =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryL=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzryL==NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ or NHYEiPtkVTIpvmuaRbGUxlQwFfzryL=='':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryL=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC('19000101')
  else:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryL=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(re.sub('-','',NHYEiPtkVTIpvmuaRbGUxlQwFfzryL))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryg=0
   while NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzryg+=1
    time.sleep(0.05)
    if NHYEiPtkVTIpvmuaRbGUxlQwFfzryL>=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgK:return
    if NHYEiPtkVTIpvmuaRbGUxlQwFfzryg>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzryL>=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgK:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.GetCredential(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgj,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgc,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgJ):
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.set_winCredential(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.LoadCredential())
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,args):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.SaveCredential(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_winCredential())
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryA =args.get('stype')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryS =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(args.get('page'))
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryq =args.get('sort')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrye=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.GetSubGroupList(NHYEiPtkVTIpvmuaRbGUxlQwFfzryA)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryO=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLS if NHYEiPtkVTIpvmuaRbGUxlQwFfzryA=='genres' else NHYEiPtkVTIpvmuaRbGUxlQwFfzrLq
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryX=NHYEiPtkVTIpvmuaRbGUxlQwFfzreA(NHYEiPtkVTIpvmuaRbGUxlQwFfzrye)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryW =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(NHYEiPtkVTIpvmuaRbGUxlQwFfzryX//(NHYEiPtkVTIpvmuaRbGUxlQwFfzryO+1))+1
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryn =(NHYEiPtkVTIpvmuaRbGUxlQwFfzryS-1)*NHYEiPtkVTIpvmuaRbGUxlQwFfzryO
  for i in NHYEiPtkVTIpvmuaRbGUxlQwFfzreS(NHYEiPtkVTIpvmuaRbGUxlQwFfzryO):
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryd=NHYEiPtkVTIpvmuaRbGUxlQwFfzryn+i
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzryd>=NHYEiPtkVTIpvmuaRbGUxlQwFfzryX:break
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn =NHYEiPtkVTIpvmuaRbGUxlQwFfzrye[NHYEiPtkVTIpvmuaRbGUxlQwFfzryd].get('group_name')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryh =NHYEiPtkVTIpvmuaRbGUxlQwFfzrye[NHYEiPtkVTIpvmuaRbGUxlQwFfzryd].get('api_path')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryM =NHYEiPtkVTIpvmuaRbGUxlQwFfzrye[NHYEiPtkVTIpvmuaRbGUxlQwFfzryd].get('tag_id')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':'CATEGORY_LIST','api_path':NHYEiPtkVTIpvmuaRbGUxlQwFfzryh,'tag_id':NHYEiPtkVTIpvmuaRbGUxlQwFfzryM,'stype':NHYEiPtkVTIpvmuaRbGUxlQwFfzryA,'page':'1','sort':NHYEiPtkVTIpvmuaRbGUxlQwFfzryq}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel='',img='',infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzryW>NHYEiPtkVTIpvmuaRbGUxlQwFfzryS:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['mode'] ='SUB_GROUP' 
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['stype'] =NHYEiPtkVTIpvmuaRbGUxlQwFfzryA
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['api_path']=args.get('api_path')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['page'] =NHYEiPtkVTIpvmuaRbGUxlQwFfzreq(NHYEiPtkVTIpvmuaRbGUxlQwFfzryS+1)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['sort'] =NHYEiPtkVTIpvmuaRbGUxlQwFfzryq
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn='[B]%s >>[/B]'%'다음 페이지'
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrys=NHYEiPtkVTIpvmuaRbGUxlQwFfzreq(NHYEiPtkVTIpvmuaRbGUxlQwFfzryS+1)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel=NHYEiPtkVTIpvmuaRbGUxlQwFfzrys,img=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzreA(NHYEiPtkVTIpvmuaRbGUxlQwFfzrye)>0:xbmcplugin.endOfDirectory(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle,cacheToDisc=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK)
 def play_VIDEO(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,args):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.SaveCredential(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_winCredential())
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryD =args.get('movie_code')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryB =args.get('season_code')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn =args.get('title')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryo =args.get('thumbnail')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryj =NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_selQuality()
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.addon_log(NHYEiPtkVTIpvmuaRbGUxlQwFfzryD+' - '+NHYEiPtkVTIpvmuaRbGUxlQwFfzryB)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryc,NHYEiPtkVTIpvmuaRbGUxlQwFfzryJ,NHYEiPtkVTIpvmuaRbGUxlQwFfzryC=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.GetStreamingURL(NHYEiPtkVTIpvmuaRbGUxlQwFfzryD,NHYEiPtkVTIpvmuaRbGUxlQwFfzryj)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzryc=='':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.addon_noti(__language__(30908).encode('utf8'))
   return
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryK=NHYEiPtkVTIpvmuaRbGUxlQwFfzryc
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.addon_log(NHYEiPtkVTIpvmuaRbGUxlQwFfzryK)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrAL=xbmcgui.ListItem(path=NHYEiPtkVTIpvmuaRbGUxlQwFfzryK)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzryC:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAg=NHYEiPtkVTIpvmuaRbGUxlQwFfzryC
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAy ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAS ='mpd'
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAq ='com.widevine.alpha'
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAe =inputstreamhelper.Helper(NHYEiPtkVTIpvmuaRbGUxlQwFfzrAS,drm=NHYEiPtkVTIpvmuaRbGUxlQwFfzrAq)
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzrAe.check_inputstream():
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrAO={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+NHYEiPtkVTIpvmuaRbGUxlQwFfzryD,'dt-custom-data':NHYEiPtkVTIpvmuaRbGUxlQwFfzrAg,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrAX=NHYEiPtkVTIpvmuaRbGUxlQwFfzrAy+'|'+urllib.parse.urlencode(NHYEiPtkVTIpvmuaRbGUxlQwFfzrAO)+'|R{SSM}|'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.addon_log(NHYEiPtkVTIpvmuaRbGUxlQwFfzrAX)
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrAL.setProperty('inputstream',NHYEiPtkVTIpvmuaRbGUxlQwFfzrAe.inputstream_addon)
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrAL.setProperty('inputstream.adaptive.manifest_type',NHYEiPtkVTIpvmuaRbGUxlQwFfzrAS)
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrAL.setProperty('inputstream.adaptive.license_type',NHYEiPtkVTIpvmuaRbGUxlQwFfzrAq)
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrAL.setProperty('inputstream.adaptive.license_key',NHYEiPtkVTIpvmuaRbGUxlQwFfzrAX)
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrAL.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.USER_AGENT))
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzryJ:
   try:
    f=NHYEiPtkVTIpvmuaRbGUxlQwFfzreO(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLe,'w',-1,'utf-8')
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrAW=requests.get(NHYEiPtkVTIpvmuaRbGUxlQwFfzryJ)
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrAn=NHYEiPtkVTIpvmuaRbGUxlQwFfzrAW.content.decode('utf-8') 
    for NHYEiPtkVTIpvmuaRbGUxlQwFfzrAd in NHYEiPtkVTIpvmuaRbGUxlQwFfzrAn.splitlines():
     NHYEiPtkVTIpvmuaRbGUxlQwFfzrAh=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',NHYEiPtkVTIpvmuaRbGUxlQwFfzrAd)
     f.write(NHYEiPtkVTIpvmuaRbGUxlQwFfzrAh+'\n')
    f.close()
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrAL.setSubtitles([NHYEiPtkVTIpvmuaRbGUxlQwFfzrLe,NHYEiPtkVTIpvmuaRbGUxlQwFfzryJ])
   except:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrAL.setSubtitles([NHYEiPtkVTIpvmuaRbGUxlQwFfzryJ])
  xbmcplugin.setResolvedUrl(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle,NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK,NHYEiPtkVTIpvmuaRbGUxlQwFfzrAL)
  try:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryA='movie' if NHYEiPtkVTIpvmuaRbGUxlQwFfzryB=='-' else 'seasons'
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'code':NHYEiPtkVTIpvmuaRbGUxlQwFfzryD if NHYEiPtkVTIpvmuaRbGUxlQwFfzryA=='movie' else NHYEiPtkVTIpvmuaRbGUxlQwFfzryB,'img':NHYEiPtkVTIpvmuaRbGUxlQwFfzryo,'title':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,'videoid':NHYEiPtkVTIpvmuaRbGUxlQwFfzryD}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.Save_Watched_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzryA,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs)
  except:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ
 def dp_Category_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,args):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.SaveCredential(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_winCredential())
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryA =args.get('stype')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryM =args.get('tag_id')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryh=args.get('api_path')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryS=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(args.get('page'))
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryq =args.get('sort')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrAM,NHYEiPtkVTIpvmuaRbGUxlQwFfzrAs=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.GetCategoryList(NHYEiPtkVTIpvmuaRbGUxlQwFfzryA,NHYEiPtkVTIpvmuaRbGUxlQwFfzryM,NHYEiPtkVTIpvmuaRbGUxlQwFfzryh,NHYEiPtkVTIpvmuaRbGUxlQwFfzryS,NHYEiPtkVTIpvmuaRbGUxlQwFfzryq)
  for NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD in NHYEiPtkVTIpvmuaRbGUxlQwFfzrAM:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryD =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('code')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('title')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAB =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('content_type')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAo =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('story')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryo =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('thumbnail')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAj =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('year')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAc =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('film_rating_code')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAJ=NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('film_rating_short')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAC =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('film_rating_long')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAK =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('duration')
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzrAB=='movies': 
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD =NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSL ='MOVIE'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgo =''
    NHYEiPtkVTIpvmuaRbGUxlQwFfzryB='-'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSg ='movie'
   else: 
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSL ='EPISODE'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgo ='Series'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzryB=NHYEiPtkVTIpvmuaRbGUxlQwFfzryD
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSg ='tvshow' 
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy={'mediatype':NHYEiPtkVTIpvmuaRbGUxlQwFfzrSg,'mpaa':NHYEiPtkVTIpvmuaRbGUxlQwFfzrAC,'title':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,'year':NHYEiPtkVTIpvmuaRbGUxlQwFfzrAj,'duration':NHYEiPtkVTIpvmuaRbGUxlQwFfzrAK,'plot':NHYEiPtkVTIpvmuaRbGUxlQwFfzrAo}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn+='  (%s년 - %s)'%(NHYEiPtkVTIpvmuaRbGUxlQwFfzrAj,NHYEiPtkVTIpvmuaRbGUxlQwFfzreq(NHYEiPtkVTIpvmuaRbGUxlQwFfzrAJ))
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':NHYEiPtkVTIpvmuaRbGUxlQwFfzrSL,'movie_code':NHYEiPtkVTIpvmuaRbGUxlQwFfzryD,'page':'1','season_code':NHYEiPtkVTIpvmuaRbGUxlQwFfzryB,'title':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,'thumbnail':NHYEiPtkVTIpvmuaRbGUxlQwFfzryo}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgo,img=NHYEiPtkVTIpvmuaRbGUxlQwFfzryo,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrAs:
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.GetCategoryList_morepage(NHYEiPtkVTIpvmuaRbGUxlQwFfzryA,NHYEiPtkVTIpvmuaRbGUxlQwFfzryM,NHYEiPtkVTIpvmuaRbGUxlQwFfzryh,NHYEiPtkVTIpvmuaRbGUxlQwFfzryS+1,NHYEiPtkVTIpvmuaRbGUxlQwFfzryq):
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={}
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['mode'] ='CATEGORY_LIST'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['stype'] =NHYEiPtkVTIpvmuaRbGUxlQwFfzryA
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['tag_id'] =NHYEiPtkVTIpvmuaRbGUxlQwFfzryM
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['api_path']=NHYEiPtkVTIpvmuaRbGUxlQwFfzryh
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['page'] =NHYEiPtkVTIpvmuaRbGUxlQwFfzreq(NHYEiPtkVTIpvmuaRbGUxlQwFfzryS+1)
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['sort'] =NHYEiPtkVTIpvmuaRbGUxlQwFfzryq
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn='[B]%s >>[/B]'%'다음 페이지'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrys=NHYEiPtkVTIpvmuaRbGUxlQwFfzreq(NHYEiPtkVTIpvmuaRbGUxlQwFfzryS+1)
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel=NHYEiPtkVTIpvmuaRbGUxlQwFfzrys,img=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzreA(NHYEiPtkVTIpvmuaRbGUxlQwFfzrAM)>0:
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzryh=='arrivals/latest':
    xbmcplugin.endOfDirectory(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle,cacheToDisc=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK)
   else:
    xbmcplugin.endOfDirectory(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle,cacheToDisc=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL)
 def dp_Episode_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,args):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.SaveCredential(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_winCredential())
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrSq=args.get('movie_code')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryS =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(args.get('page'))
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryB =args.get('season_code')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrAM,NHYEiPtkVTIpvmuaRbGUxlQwFfzrAs=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.GetEpisodoList(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSq,NHYEiPtkVTIpvmuaRbGUxlQwFfzryS,orderby=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_winEpisodeOrderby())
  for NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD in NHYEiPtkVTIpvmuaRbGUxlQwFfzrAM:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryD =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('code')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('title')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryo =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('thumbnail')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSe =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('display_num')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSO =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('season_title')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSX=NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('episode_number')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAK =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('duration')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy={'mediatype':'episode','tvshowtitle':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn if NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn!='' else NHYEiPtkVTIpvmuaRbGUxlQwFfzrSO,'title':'%s %s'%(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSO,NHYEiPtkVTIpvmuaRbGUxlQwFfzrSe)if NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn!='' else NHYEiPtkVTIpvmuaRbGUxlQwFfzrSe,'episode':NHYEiPtkVTIpvmuaRbGUxlQwFfzrSX,'duration':NHYEiPtkVTIpvmuaRbGUxlQwFfzrAK,'plot':'%s\n%s\n\n%s'%(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSO,NHYEiPtkVTIpvmuaRbGUxlQwFfzrSe,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn)}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn='(%s) %s'%(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSe,NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':'MOVIE','movie_code':NHYEiPtkVTIpvmuaRbGUxlQwFfzryD,'season_code':NHYEiPtkVTIpvmuaRbGUxlQwFfzryB,'title':'%s < %s >'%(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,NHYEiPtkVTIpvmuaRbGUxlQwFfzrSO),'thumbnail':NHYEiPtkVTIpvmuaRbGUxlQwFfzryo}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSO,img=NHYEiPtkVTIpvmuaRbGUxlQwFfzryo,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzryS==1:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy={'plot':'정렬순서를 변경합니다.'}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['mode'] ='ORDER_BY' 
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_winEpisodeOrderby()=='desc':
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn='정렬순서변경 : 최신화부터 -> 1회부터'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['orderby']='asc'
   else:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn='정렬순서변경 : 1회부터 -> 최신화부터'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['orderby']='desc'
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel='',img=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs,isLink=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrAs:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['mode'] ='EPISODE' 
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['movie_code']=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSq
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['page'] =NHYEiPtkVTIpvmuaRbGUxlQwFfzreq(NHYEiPtkVTIpvmuaRbGUxlQwFfzryS+1)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn='[B]%s >>[/B]'%'다음 페이지'
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrys=NHYEiPtkVTIpvmuaRbGUxlQwFfzreq(NHYEiPtkVTIpvmuaRbGUxlQwFfzryS+1)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel=NHYEiPtkVTIpvmuaRbGUxlQwFfzrys,img=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzreA(NHYEiPtkVTIpvmuaRbGUxlQwFfzrAM)>0:xbmcplugin.endOfDirectory(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle,cacheToDisc=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK)
 def dp_Search_History(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrSW=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.Load_List_File('search')
  for NHYEiPtkVTIpvmuaRbGUxlQwFfzrSn in NHYEiPtkVTIpvmuaRbGUxlQwFfzrSW:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSd=NHYEiPtkVTIpvmuaRbGUxlQwFfzrey(urllib.parse.parse_qsl(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSn))
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSh=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSd.get('skey').strip()
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':'LOCAL_SEARCH','search_key':NHYEiPtkVTIpvmuaRbGUxlQwFfzrSh,'page':'1','historyyn':'Y',}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSM={'mode':'SEARCH_REMOVE','stype':'ONE','skey':NHYEiPtkVTIpvmuaRbGUxlQwFfzrSh,}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSs=urllib.parse.urlencode(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSM)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSD=[('선택된 검색어 ( %s ) 삭제'%(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSh),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSs))]
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSh,sublabel='',img=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs,ContextMenu=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSD)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy={'plot':'검색목록 전체를 삭제합니다.'}
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn='*** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) ***'
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel='',img=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs,isLink=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK)
  xbmcplugin.endOfDirectory(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle,cacheToDisc=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL)
 def dp_Search_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,args):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.SaveCredential(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_winCredential())
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryS =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(args.get('page'))
  if 'search_key' in args:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSB=args.get('search_key')
  else:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSB=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not NHYEiPtkVTIpvmuaRbGUxlQwFfzrSB:
    xbmcplugin.endOfDirectory(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle)
    return
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrAM,NHYEiPtkVTIpvmuaRbGUxlQwFfzrAs=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.GetSearchList(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSB,NHYEiPtkVTIpvmuaRbGUxlQwFfzryS)
  for NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD in NHYEiPtkVTIpvmuaRbGUxlQwFfzrAM:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryD =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('code')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('title')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAB=NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('content_type')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAo =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('story')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzryo =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('thumbnail')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAj =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('year')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAc =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('film_rating_code')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAJ=NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('film_rating_short')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAC =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('film_rating_long')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrAK =NHYEiPtkVTIpvmuaRbGUxlQwFfzrAD.get('duration')
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzrAB=='movies': 
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD =NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSL ='MOVIE'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgo =''
    NHYEiPtkVTIpvmuaRbGUxlQwFfzryB='-'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSg ='movie'
   else: 
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSL ='EPISODE'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgo ='Series'
    NHYEiPtkVTIpvmuaRbGUxlQwFfzryB=NHYEiPtkVTIpvmuaRbGUxlQwFfzryD
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSg ='tvshow' 
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy={'mediatype':NHYEiPtkVTIpvmuaRbGUxlQwFfzrSg,'mpaa':NHYEiPtkVTIpvmuaRbGUxlQwFfzrAC,'title':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,'year':NHYEiPtkVTIpvmuaRbGUxlQwFfzrAj,'duration':NHYEiPtkVTIpvmuaRbGUxlQwFfzrAK,'plot':NHYEiPtkVTIpvmuaRbGUxlQwFfzrAo}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn+='  (%s년 - %s)'%(NHYEiPtkVTIpvmuaRbGUxlQwFfzrAj,NHYEiPtkVTIpvmuaRbGUxlQwFfzreq(NHYEiPtkVTIpvmuaRbGUxlQwFfzrAJ))
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':NHYEiPtkVTIpvmuaRbGUxlQwFfzrSL,'movie_code':NHYEiPtkVTIpvmuaRbGUxlQwFfzryD,'page':'1','season_code':NHYEiPtkVTIpvmuaRbGUxlQwFfzryB,'title':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,'thumbnail':NHYEiPtkVTIpvmuaRbGUxlQwFfzryo}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgo,img=NHYEiPtkVTIpvmuaRbGUxlQwFfzryo,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrAs:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['mode'] ='SEARCH'
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['search_key']=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSB
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs['page'] =NHYEiPtkVTIpvmuaRbGUxlQwFfzreq(NHYEiPtkVTIpvmuaRbGUxlQwFfzryS+1)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn='[B]%s >>[/B]'%'다음 페이지'
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrys=NHYEiPtkVTIpvmuaRbGUxlQwFfzreq(NHYEiPtkVTIpvmuaRbGUxlQwFfzryS+1)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel=NHYEiPtkVTIpvmuaRbGUxlQwFfzrys,img=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs)
  xbmcplugin.endOfDirectory(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle,cacheToDisc=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL)
  if args.get('historyyn')=='Y':NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.Save_Searched_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSB)
 def Delete_List_File(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,NHYEiPtkVTIpvmuaRbGUxlQwFfzryA,skey='-'):
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzryA=='ALL':
   try:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSo=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLX
    fp=NHYEiPtkVTIpvmuaRbGUxlQwFfzreO(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSo,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzryA=='ONE':
   try:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSo=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLX
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSj=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.Load_List_File('search') 
    fp=NHYEiPtkVTIpvmuaRbGUxlQwFfzreO(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSo,'w',-1,'utf-8')
    for NHYEiPtkVTIpvmuaRbGUxlQwFfzrSc in NHYEiPtkVTIpvmuaRbGUxlQwFfzrSj:
     NHYEiPtkVTIpvmuaRbGUxlQwFfzrSJ=NHYEiPtkVTIpvmuaRbGUxlQwFfzrey(urllib.parse.parse_qsl(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSc))
     NHYEiPtkVTIpvmuaRbGUxlQwFfzrSC=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSJ.get('skey').strip()
     if skey!=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSC:
      fp.write(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSc)
    fp.close()
   except:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzryA in['seasons','movie']:
   try:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NHYEiPtkVTIpvmuaRbGUxlQwFfzryA))
    fp=NHYEiPtkVTIpvmuaRbGUxlQwFfzreO(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSo,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ
 def dp_Listfile_Delete(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,args):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryA=args.get('stype')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrSh =args.get('skey')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLs=xbmcgui.Dialog()
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzryA=='ALL':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgC=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLs.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzryA=='ONE':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgC=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLs.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzryA in['seasons','movie']:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgC=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLs.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrgC==NHYEiPtkVTIpvmuaRbGUxlQwFfzreL:sys.exit()
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.Delete_List_File(NHYEiPtkVTIpvmuaRbGUxlQwFfzryA,skey=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSh)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,NHYEiPtkVTIpvmuaRbGUxlQwFfzryA): 
  try:
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzryA=='search':
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSo=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLX
   elif NHYEiPtkVTIpvmuaRbGUxlQwFfzryA in['seasons','movie']:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NHYEiPtkVTIpvmuaRbGUxlQwFfzryA))
   else:
    return[]
   fp=NHYEiPtkVTIpvmuaRbGUxlQwFfzreO(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSo,'r',-1,'utf-8')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSK=fp.readlines()
   fp.close()
  except:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSK=[]
  return NHYEiPtkVTIpvmuaRbGUxlQwFfzrSK
 def Save_Watched_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,NHYEiPtkVTIpvmuaRbGUxlQwFfzryA,NHYEiPtkVTIpvmuaRbGUxlQwFfzrLh):
  try:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NHYEiPtkVTIpvmuaRbGUxlQwFfzryA))
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSj=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.Load_List_File(NHYEiPtkVTIpvmuaRbGUxlQwFfzryA) 
   fp=NHYEiPtkVTIpvmuaRbGUxlQwFfzreO(NHYEiPtkVTIpvmuaRbGUxlQwFfzrqL,'w',-1,'utf-8')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqg=urllib.parse.urlencode(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLh)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqg=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqg+'\n'
   fp.write(NHYEiPtkVTIpvmuaRbGUxlQwFfzrqg)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqy=0
   for NHYEiPtkVTIpvmuaRbGUxlQwFfzrSc in NHYEiPtkVTIpvmuaRbGUxlQwFfzrSj:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSJ=NHYEiPtkVTIpvmuaRbGUxlQwFfzrey(urllib.parse.parse_qsl(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSc))
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrqA=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLh.get('code').strip()
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrqS=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSJ.get('code').strip()
    if NHYEiPtkVTIpvmuaRbGUxlQwFfzryA=='seasons' and NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_settings_direct_replay()==NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK:
     NHYEiPtkVTIpvmuaRbGUxlQwFfzrqA=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLh.get('videoid').strip()
     NHYEiPtkVTIpvmuaRbGUxlQwFfzrqS=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSJ.get('videoid').strip()if NHYEiPtkVTIpvmuaRbGUxlQwFfzrqS!=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ else '-'
    if NHYEiPtkVTIpvmuaRbGUxlQwFfzrqA!=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqS:
     fp.write(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSc)
     NHYEiPtkVTIpvmuaRbGUxlQwFfzrqy+=1
     if NHYEiPtkVTIpvmuaRbGUxlQwFfzrqy>=50:break
   fp.close()
  except:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ
 def dp_Watch_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,args):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryA =args.get('stype')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgq=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.get_settings_direct_replay()
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzryA=='-':
   for NHYEiPtkVTIpvmuaRbGUxlQwFfzrqe in NHYEiPtkVTIpvmuaRbGUxlQwFfzrLA:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqe.get('title')
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':NHYEiPtkVTIpvmuaRbGUxlQwFfzrqe.get('mode'),'stype':NHYEiPtkVTIpvmuaRbGUxlQwFfzrqe.get('stype')}
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel='',img='',infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs)
   if NHYEiPtkVTIpvmuaRbGUxlQwFfzreA(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLA)>0:xbmcplugin.endOfDirectory(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle)
  else:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqO=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.Load_List_File(NHYEiPtkVTIpvmuaRbGUxlQwFfzryA)
   for NHYEiPtkVTIpvmuaRbGUxlQwFfzrqX in NHYEiPtkVTIpvmuaRbGUxlQwFfzrqO:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSd=NHYEiPtkVTIpvmuaRbGUxlQwFfzrey(urllib.parse.parse_qsl(NHYEiPtkVTIpvmuaRbGUxlQwFfzrqX))
    NHYEiPtkVTIpvmuaRbGUxlQwFfzryD=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSd.get('code').strip()
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn =NHYEiPtkVTIpvmuaRbGUxlQwFfzrSd.get('title').strip()
    NHYEiPtkVTIpvmuaRbGUxlQwFfzryo =NHYEiPtkVTIpvmuaRbGUxlQwFfzrSd.get('img').strip()
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrqW =NHYEiPtkVTIpvmuaRbGUxlQwFfzrSd.get('videoid').strip()
    try:
     NHYEiPtkVTIpvmuaRbGUxlQwFfzryo=NHYEiPtkVTIpvmuaRbGUxlQwFfzryo.replace('\'','\"')
     NHYEiPtkVTIpvmuaRbGUxlQwFfzryo=json.loads(NHYEiPtkVTIpvmuaRbGUxlQwFfzryo)
    except:
     NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy={}
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy['plot']=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn
    if NHYEiPtkVTIpvmuaRbGUxlQwFfzryA=='movie':
     NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':'MOVIE','page':'1','movie_code':NHYEiPtkVTIpvmuaRbGUxlQwFfzryD,'season_code':'-','title':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,'thumbnail':NHYEiPtkVTIpvmuaRbGUxlQwFfzryo}
     NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
    else:
     if NHYEiPtkVTIpvmuaRbGUxlQwFfzrgq==NHYEiPtkVTIpvmuaRbGUxlQwFfzreL or NHYEiPtkVTIpvmuaRbGUxlQwFfzrqW==NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ:
      NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':'EPISODE','page':'1','movie_code':NHYEiPtkVTIpvmuaRbGUxlQwFfzryD,'season_code':NHYEiPtkVTIpvmuaRbGUxlQwFfzryD,'title':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,'thumbnail':NHYEiPtkVTIpvmuaRbGUxlQwFfzryo}
      NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK
     else:
      NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':'MOVIE','movie_code':NHYEiPtkVTIpvmuaRbGUxlQwFfzrqW,'season_code':NHYEiPtkVTIpvmuaRbGUxlQwFfzryD,'title':NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,'thumbnail':NHYEiPtkVTIpvmuaRbGUxlQwFfzryo}
      NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel='',img=NHYEiPtkVTIpvmuaRbGUxlQwFfzryo,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgD,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy={'plot':'시청목록을 삭제합니다.'}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn='*** 시청목록 삭제 ***'
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs={'mode':'MYVIEW_REMOVE','stype':NHYEiPtkVTIpvmuaRbGUxlQwFfzryA,'skey':'-',}
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.add_dir(NHYEiPtkVTIpvmuaRbGUxlQwFfzrgn,sublabel='',img=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgM,infoLabels=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSy,isFolder=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL,params=NHYEiPtkVTIpvmuaRbGUxlQwFfzrgs,isLink=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK)
   xbmcplugin.endOfDirectory(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW._addon_handle,cacheToDisc=NHYEiPtkVTIpvmuaRbGUxlQwFfzreL)
 def Save_Searched_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,NHYEiPtkVTIpvmuaRbGUxlQwFfzrSB):
  try:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqn=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLX
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrSj=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.Load_List_File('search') 
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqd={'skey':NHYEiPtkVTIpvmuaRbGUxlQwFfzrSB.strip()}
   fp=NHYEiPtkVTIpvmuaRbGUxlQwFfzreO(NHYEiPtkVTIpvmuaRbGUxlQwFfzrqn,'w',-1,'utf-8')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqg=urllib.parse.urlencode(NHYEiPtkVTIpvmuaRbGUxlQwFfzrqd)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqg=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqg+'\n'
   fp.write(NHYEiPtkVTIpvmuaRbGUxlQwFfzrqg)
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqy=0
   for NHYEiPtkVTIpvmuaRbGUxlQwFfzrSc in NHYEiPtkVTIpvmuaRbGUxlQwFfzrSj:
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrSJ=NHYEiPtkVTIpvmuaRbGUxlQwFfzrey(urllib.parse.parse_qsl(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSc))
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrqA=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqd.get('skey').strip()
    NHYEiPtkVTIpvmuaRbGUxlQwFfzrqS=NHYEiPtkVTIpvmuaRbGUxlQwFfzrSJ.get('skey').strip()
    if NHYEiPtkVTIpvmuaRbGUxlQwFfzrqA!=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqS:
     fp.write(NHYEiPtkVTIpvmuaRbGUxlQwFfzrSc)
     NHYEiPtkVTIpvmuaRbGUxlQwFfzrqy+=1
     if NHYEiPtkVTIpvmuaRbGUxlQwFfzrqy>=50:break
   fp.close()
  except:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ
 def logout(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLs=xbmcgui.Dialog()
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgC=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLs.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrgC==NHYEiPtkVTIpvmuaRbGUxlQwFfzreL:sys.exit()
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.wininfo_clear()
  if os.path.isfile(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLO):os.remove(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLO)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge=xbmcgui.Window(10000)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_TOKEN','')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_GUIT','')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_GUITV','')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_USERCD','')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrqh =NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.Get_Now_Datetime()
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrqM=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqh+datetime.timedelta(days=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(__addon__.getSetting('cache_ttl')))
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge=xbmcgui.Window(10000)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs={'watcha_token':NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.getProperty('WATCHA_M_TOKEN'),'watcha_guit':NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.getProperty('WATCHA_M_GUIT'),'watcha_guitv':NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.getProperty('WATCHA_M_GUITV'),'watcha_usercd':NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':NHYEiPtkVTIpvmuaRbGUxlQwFfzrqM.strftime('%Y-%m-%d')}
  try: 
   fp=NHYEiPtkVTIpvmuaRbGUxlQwFfzreO(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLO,'w',-1,'utf-8')
   json.dump(NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs,fp)
   fp.close()
  except NHYEiPtkVTIpvmuaRbGUxlQwFfzreX as exception:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzreW(exception)
 def cookiefile_check(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs={}
  try: 
   fp=NHYEiPtkVTIpvmuaRbGUxlQwFfzreO(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLO,'r',-1,'utf-8')
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs= json.load(fp)
   fp.close()
  except NHYEiPtkVTIpvmuaRbGUxlQwFfzreX as exception:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.wininfo_clear()
   return NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgj =__addon__.getSetting('id')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgc =__addon__.getSetting('pw')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrqD =__addon__.getSetting('selected_profile')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_id']=base64.standard_b64decode(NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_id']).decode('utf-8')
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_pw']=base64.standard_b64decode(NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_pw']).decode('utf-8')
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrgj!=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_id']or NHYEiPtkVTIpvmuaRbGUxlQwFfzrgc!=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_pw']or NHYEiPtkVTIpvmuaRbGUxlQwFfzrqD!=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_profile']:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.wininfo_clear()
   return NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrgK =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrqB=NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_limitdate']
  NHYEiPtkVTIpvmuaRbGUxlQwFfzryL =NHYEiPtkVTIpvmuaRbGUxlQwFfzrqC(re.sub('-','',NHYEiPtkVTIpvmuaRbGUxlQwFfzrqB))
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzryL<NHYEiPtkVTIpvmuaRbGUxlQwFfzrgK:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.wininfo_clear()
   return NHYEiPtkVTIpvmuaRbGUxlQwFfzreL
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge=xbmcgui.Window(10000)
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_TOKEN',NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_token'])
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_GUIT',NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_guit'])
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_GUITV',NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_guitv'])
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_USERCD',NHYEiPtkVTIpvmuaRbGUxlQwFfzrqs['watcha_usercd'])
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrge.setProperty('WATCHA_M_LOGINTIME',NHYEiPtkVTIpvmuaRbGUxlQwFfzrqB)
  return NHYEiPtkVTIpvmuaRbGUxlQwFfzrqK
 def dp_Global_Search(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW,args):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo=args.get('mode')
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo=='TOTAL_SEARCH':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqj='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqj='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(NHYEiPtkVTIpvmuaRbGUxlQwFfzrqj)
 def watcha_main(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW):
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo=NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.main_params.get('mode',NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ)
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo=='LOGOUT':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.logout()
   return
  NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.login_main()
  if NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo is NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.dp_Main_List()
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo=='SUB_GROUP':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.dp_SubGroup_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.main_params)
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo=='CATEGORY_LIST':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.dp_Category_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.main_params)
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo=='EPISODE':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.dp_Episode_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.main_params)
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo=='ORDER_BY':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.dp_setEpOrderby(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.main_params)
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo in['SEARCH','LOCAL_SEARCH']:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.dp_Search_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.main_params)
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo=='MOVIE':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.play_VIDEO(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.main_params)
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo=='WATCH':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.dp_Watch_List(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.main_params)
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.dp_Listfile_Delete(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.main_params)
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo in['TOTAL_SEARCH','TOTAL_HISTORY']:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.dp_Global_Search(NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.main_params)
  elif NHYEiPtkVTIpvmuaRbGUxlQwFfzrqo=='SEARCH_HISTORY':
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrLW.dp_Search_History()
  else:
   NHYEiPtkVTIpvmuaRbGUxlQwFfzrqJ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
