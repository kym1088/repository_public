__author__="NightRain"
bCYBDKHslJvRpGOwQgVTekAXrdqWnP=object
bCYBDKHslJvRpGOwQgVTekAXrdqWnI=None
bCYBDKHslJvRpGOwQgVTekAXrdqWnU=False
bCYBDKHslJvRpGOwQgVTekAXrdqWnt=True
bCYBDKHslJvRpGOwQgVTekAXrdqWnu=Exception
bCYBDKHslJvRpGOwQgVTekAXrdqWni=print
bCYBDKHslJvRpGOwQgVTekAXrdqWnm=str
bCYBDKHslJvRpGOwQgVTekAXrdqWnM=len
bCYBDKHslJvRpGOwQgVTekAXrdqWnS=int
bCYBDKHslJvRpGOwQgVTekAXrdqWna=range
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
class bCYBDKHslJvRpGOwQgVTekAXrdqWfF(bCYBDKHslJvRpGOwQgVTekAXrdqWnP):
 def __init__(bCYBDKHslJvRpGOwQgVTekAXrdqWfx):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_TOKEN ='' 
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUIT =''
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUITV =''
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_USERCD=''
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.MAIN_DOMAIN ='https://watcha.com'
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.API_DOMAIN ='https://api-mars.watcha.com'
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.EPISODE_LIMIT=20
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.SEARCH_LIMIT =30
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.DEFAULT_HEADER={'user-agent':bCYBDKHslJvRpGOwQgVTekAXrdqWfx.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,jobtype,bCYBDKHslJvRpGOwQgVTekAXrdqWfj,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,params=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,redirects=bCYBDKHslJvRpGOwQgVTekAXrdqWnU):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfn=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.DEFAULT_HEADER
  if headers:bCYBDKHslJvRpGOwQgVTekAXrdqWfn.update(headers)
  if jobtype=='Get':
   bCYBDKHslJvRpGOwQgVTekAXrdqWfo=requests.get(bCYBDKHslJvRpGOwQgVTekAXrdqWfj,params=params,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWfn,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   bCYBDKHslJvRpGOwQgVTekAXrdqWfo=requests.put(bCYBDKHslJvRpGOwQgVTekAXrdqWfj,data=payload,params=params,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWfn,cookies=cookies,allow_redirects=redirects)
  else:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfo=requests.post(bCYBDKHslJvRpGOwQgVTekAXrdqWfj,data=payload,params=params,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWfn,cookies=cookies,allow_redirects=redirects)
  return bCYBDKHslJvRpGOwQgVTekAXrdqWfo
 def SaveCredential(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,bCYBDKHslJvRpGOwQgVTekAXrdqWfP):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_TOKEN =bCYBDKHslJvRpGOwQgVTekAXrdqWfP.get('watcha_token')
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUIT =bCYBDKHslJvRpGOwQgVTekAXrdqWfP.get('watcha_guit')
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUITV =bCYBDKHslJvRpGOwQgVTekAXrdqWfP.get('watcha_guitv')
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_USERCD =bCYBDKHslJvRpGOwQgVTekAXrdqWfP.get('watcha_usercd')
 def SaveCredential_usercd(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,bCYBDKHslJvRpGOwQgVTekAXrdqWfI):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_USERCD=bCYBDKHslJvRpGOwQgVTekAXrdqWfI
 def SaveCredential_guitv(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,bCYBDKHslJvRpGOwQgVTekAXrdqWfU,bCYBDKHslJvRpGOwQgVTekAXrdqWft):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUITV=bCYBDKHslJvRpGOwQgVTekAXrdqWfU
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_TOKEN=bCYBDKHslJvRpGOwQgVTekAXrdqWft 
 def ClearCredential(bCYBDKHslJvRpGOwQgVTekAXrdqWfx):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_TOKEN ='' 
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUIT =''
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUITV =''
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_USERCD=''
 def LoadCredential(bCYBDKHslJvRpGOwQgVTekAXrdqWfx):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfP={'watcha_token':bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_TOKEN,'watcha_guit':bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUIT,'watcha_guitv':bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUITV,'watcha_usercd':bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_USERCD}
  return bCYBDKHslJvRpGOwQgVTekAXrdqWfP
 def makeDefaultCookies(bCYBDKHslJvRpGOwQgVTekAXrdqWfx):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfu={'_s_guit':bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUIT,'_guinness-premium_session':bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_TOKEN}
  if bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUITV:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfu['_s_guitv']=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_GUITV
  return bCYBDKHslJvRpGOwQgVTekAXrdqWfu
 def GetCredential(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,user_id,user_pw,user_pf):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfi=bCYBDKHslJvRpGOwQgVTekAXrdqWnU
  bCYBDKHslJvRpGOwQgVTekAXrdqWfm=bCYBDKHslJvRpGOwQgVTekAXrdqWfL='-'
  try:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfM=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.API_DOMAIN+'/api/session'
   bCYBDKHslJvRpGOwQgVTekAXrdqWfS={'email':user_id,'password':user_pw}
   bCYBDKHslJvRpGOwQgVTekAXrdqWfa={'accept':'application/vnd.frograms+json;version=4'}
   bCYBDKHslJvRpGOwQgVTekAXrdqWfy=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.callRequestCookies('Post',bCYBDKHslJvRpGOwQgVTekAXrdqWfM,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWfS,params=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWfa,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWnI)
   for bCYBDKHslJvRpGOwQgVTekAXrdqWfN in bCYBDKHslJvRpGOwQgVTekAXrdqWfy.cookies:
    if bCYBDKHslJvRpGOwQgVTekAXrdqWfN.name=='_guinness-premium_session':
     bCYBDKHslJvRpGOwQgVTekAXrdqWfL=bCYBDKHslJvRpGOwQgVTekAXrdqWfN.value
    elif bCYBDKHslJvRpGOwQgVTekAXrdqWfN.name=='_s_guit':
     bCYBDKHslJvRpGOwQgVTekAXrdqWfm=bCYBDKHslJvRpGOwQgVTekAXrdqWfN.value
   if bCYBDKHslJvRpGOwQgVTekAXrdqWfL:bCYBDKHslJvRpGOwQgVTekAXrdqWfi=bCYBDKHslJvRpGOwQgVTekAXrdqWnt
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   bCYBDKHslJvRpGOwQgVTekAXrdqWni(exception)
   bCYBDKHslJvRpGOwQgVTekAXrdqWfm=bCYBDKHslJvRpGOwQgVTekAXrdqWfL='' 
  bCYBDKHslJvRpGOwQgVTekAXrdqWfP={'watcha_guit':bCYBDKHslJvRpGOwQgVTekAXrdqWfm,'watcha_token':bCYBDKHslJvRpGOwQgVTekAXrdqWfL,'watcha_guitv':'','watcha_usercd':''}
  bCYBDKHslJvRpGOwQgVTekAXrdqWfx.SaveCredential(bCYBDKHslJvRpGOwQgVTekAXrdqWfP)
  try:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfh=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.GetProfilesList()
   bCYBDKHslJvRpGOwQgVTekAXrdqWfc =bCYBDKHslJvRpGOwQgVTekAXrdqWfh[user_pf]
   bCYBDKHslJvRpGOwQgVTekAXrdqWfx.SaveCredential_usercd(bCYBDKHslJvRpGOwQgVTekAXrdqWfc)
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   bCYBDKHslJvRpGOwQgVTekAXrdqWni(exception)
   bCYBDKHslJvRpGOwQgVTekAXrdqWfx.ClearCredential()
   return bCYBDKHslJvRpGOwQgVTekAXrdqWnU
  if user_pf!=0:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfU,bCYBDKHslJvRpGOwQgVTekAXrdqWft=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.GetProfilesConvert(bCYBDKHslJvRpGOwQgVTekAXrdqWfc)
   bCYBDKHslJvRpGOwQgVTekAXrdqWfx.SaveCredential_guitv(bCYBDKHslJvRpGOwQgVTekAXrdqWfU,bCYBDKHslJvRpGOwQgVTekAXrdqWft)
  return bCYBDKHslJvRpGOwQgVTekAXrdqWfi
 def GetSubGroupList(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,stype):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfz=[]
  try:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfE ='/api/categories.json'
   bCYBDKHslJvRpGOwQgVTekAXrdqWfj=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.API_DOMAIN+bCYBDKHslJvRpGOwQgVTekAXrdqWfE
   bCYBDKHslJvRpGOwQgVTekAXrdqWfy=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.callRequestCookies('Get',bCYBDKHslJvRpGOwQgVTekAXrdqWfj,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,params=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWnI)
   bCYBDKHslJvRpGOwQgVTekAXrdqWFf=json.loads(bCYBDKHslJvRpGOwQgVTekAXrdqWfy.text)
   if not('genres' in bCYBDKHslJvRpGOwQgVTekAXrdqWFf):return bCYBDKHslJvRpGOwQgVTekAXrdqWfz
   if stype=='genres':
    bCYBDKHslJvRpGOwQgVTekAXrdqWFx=bCYBDKHslJvRpGOwQgVTekAXrdqWFf['genres']
   else:
    bCYBDKHslJvRpGOwQgVTekAXrdqWFx=bCYBDKHslJvRpGOwQgVTekAXrdqWFf['tags']
   for bCYBDKHslJvRpGOwQgVTekAXrdqWFn in bCYBDKHslJvRpGOwQgVTekAXrdqWFx:
    bCYBDKHslJvRpGOwQgVTekAXrdqWFo=bCYBDKHslJvRpGOwQgVTekAXrdqWFn['name']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFP =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['api_path']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFI =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['entity']['id']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFU={'group_name':bCYBDKHslJvRpGOwQgVTekAXrdqWFo,'api_path':bCYBDKHslJvRpGOwQgVTekAXrdqWFP,'tag_id':bCYBDKHslJvRpGOwQgVTekAXrdqWnm(bCYBDKHslJvRpGOwQgVTekAXrdqWFI)}
    bCYBDKHslJvRpGOwQgVTekAXrdqWfz.append(bCYBDKHslJvRpGOwQgVTekAXrdqWFU)
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   bCYBDKHslJvRpGOwQgVTekAXrdqWni(exception)
  return bCYBDKHslJvRpGOwQgVTekAXrdqWfz
 def GetCategoryList(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,stype,bCYBDKHslJvRpGOwQgVTekAXrdqWFI,bCYBDKHslJvRpGOwQgVTekAXrdqWFP,page_int,in_sort):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfz=[]
  bCYBDKHslJvRpGOwQgVTekAXrdqWFt=bCYBDKHslJvRpGOwQgVTekAXrdqWnU
  bCYBDKHslJvRpGOwQgVTekAXrdqWFu={}
  try:
   if 'categories' in bCYBDKHslJvRpGOwQgVTekAXrdqWFP:
    bCYBDKHslJvRpGOwQgVTekAXrdqWfE ='/api/categories/contents.json'
    if stype=='genres':
     bCYBDKHslJvRpGOwQgVTekAXrdqWFu['genre']=bCYBDKHslJvRpGOwQgVTekAXrdqWFI
    else:
     bCYBDKHslJvRpGOwQgVTekAXrdqWFu['tag'] =bCYBDKHslJvRpGOwQgVTekAXrdqWFI
    bCYBDKHslJvRpGOwQgVTekAXrdqWFu['order']=in_sort 
    if page_int>1:
     bCYBDKHslJvRpGOwQgVTekAXrdqWFu['page']=bCYBDKHslJvRpGOwQgVTekAXrdqWnm(page_int-1)
   else: 
    bCYBDKHslJvRpGOwQgVTekAXrdqWfE ='/api/'+bCYBDKHslJvRpGOwQgVTekAXrdqWFP+'.json'
    if page_int>1:
     bCYBDKHslJvRpGOwQgVTekAXrdqWFu['page']=bCYBDKHslJvRpGOwQgVTekAXrdqWnm(page_int)
   bCYBDKHslJvRpGOwQgVTekAXrdqWfj=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.API_DOMAIN+bCYBDKHslJvRpGOwQgVTekAXrdqWfE
   bCYBDKHslJvRpGOwQgVTekAXrdqWfN=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.makeDefaultCookies()
   bCYBDKHslJvRpGOwQgVTekAXrdqWfy=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.callRequestCookies('Get',bCYBDKHslJvRpGOwQgVTekAXrdqWfj,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,params=bCYBDKHslJvRpGOwQgVTekAXrdqWFu,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWfN)
   bCYBDKHslJvRpGOwQgVTekAXrdqWFf=json.loads(bCYBDKHslJvRpGOwQgVTekAXrdqWfy.text)
   if not('contents' in bCYBDKHslJvRpGOwQgVTekAXrdqWFf):return bCYBDKHslJvRpGOwQgVTekAXrdqWfz,bCYBDKHslJvRpGOwQgVTekAXrdqWFt
   bCYBDKHslJvRpGOwQgVTekAXrdqWFx=bCYBDKHslJvRpGOwQgVTekAXrdqWFf['contents']
   bCYBDKHslJvRpGOwQgVTekAXrdqWFt=bCYBDKHslJvRpGOwQgVTekAXrdqWFf['meta']['has_next']
   for bCYBDKHslJvRpGOwQgVTekAXrdqWFn in bCYBDKHslJvRpGOwQgVTekAXrdqWFx:
    bCYBDKHslJvRpGOwQgVTekAXrdqWFi =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['code']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFm=bCYBDKHslJvRpGOwQgVTekAXrdqWFn['content_type']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFM =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['title']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFS =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['story']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFa=tmp_thumb=tmp_fanart=''
    if bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('poster') !=bCYBDKHslJvRpGOwQgVTekAXrdqWnI:bCYBDKHslJvRpGOwQgVTekAXrdqWFa=bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('poster').get('original')
    if bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('stillcut')!=bCYBDKHslJvRpGOwQgVTekAXrdqWnI:tmp_thumb =bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('stillcut').get('large')
    if bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('thumbnail')!=bCYBDKHslJvRpGOwQgVTekAXrdqWnI:tmp_fanart=bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('thumbnail').get('large')
    if tmp_fanart=='' :tmp_fanart=tmp_thumb
    bCYBDKHslJvRpGOwQgVTekAXrdqWFy={'thumb':tmp_thumb,'poster':bCYBDKHslJvRpGOwQgVTekAXrdqWFa,'fanart':tmp_fanart}
    bCYBDKHslJvRpGOwQgVTekAXrdqWFN =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['year']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFL =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['film_rating_code']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFh=bCYBDKHslJvRpGOwQgVTekAXrdqWFn['film_rating_short']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFc =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['film_rating_long']
    if bCYBDKHslJvRpGOwQgVTekAXrdqWFm=='movies':
     bCYBDKHslJvRpGOwQgVTekAXrdqWFz =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['duration']
    else:
     bCYBDKHslJvRpGOwQgVTekAXrdqWFz ='0'
    bCYBDKHslJvRpGOwQgVTekAXrdqWFU={'code':bCYBDKHslJvRpGOwQgVTekAXrdqWFi,'content_type':bCYBDKHslJvRpGOwQgVTekAXrdqWFm,'title':bCYBDKHslJvRpGOwQgVTekAXrdqWFM,'story':bCYBDKHslJvRpGOwQgVTekAXrdqWFS,'thumbnail':bCYBDKHslJvRpGOwQgVTekAXrdqWFy,'year':bCYBDKHslJvRpGOwQgVTekAXrdqWFN,'film_rating_code':bCYBDKHslJvRpGOwQgVTekAXrdqWFL,'film_rating_short':bCYBDKHslJvRpGOwQgVTekAXrdqWFh,'film_rating_long':bCYBDKHslJvRpGOwQgVTekAXrdqWFc,'duration':bCYBDKHslJvRpGOwQgVTekAXrdqWFz}
    bCYBDKHslJvRpGOwQgVTekAXrdqWfz.append(bCYBDKHslJvRpGOwQgVTekAXrdqWFU)
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   bCYBDKHslJvRpGOwQgVTekAXrdqWni(exception)
  return bCYBDKHslJvRpGOwQgVTekAXrdqWfz,bCYBDKHslJvRpGOwQgVTekAXrdqWFt
 def GetCategoryList_morepage(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,stype,bCYBDKHslJvRpGOwQgVTekAXrdqWFI,bCYBDKHslJvRpGOwQgVTekAXrdqWFP,page_int,in_sort):
  bCYBDKHslJvRpGOwQgVTekAXrdqWFt=bCYBDKHslJvRpGOwQgVTekAXrdqWnU
  if not('categories' in bCYBDKHslJvRpGOwQgVTekAXrdqWFP):return bCYBDKHslJvRpGOwQgVTekAXrdqWnt
  try:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfE ='/api/categories/contents.json'
   bCYBDKHslJvRpGOwQgVTekAXrdqWfj=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.API_DOMAIN+bCYBDKHslJvRpGOwQgVTekAXrdqWfE
   bCYBDKHslJvRpGOwQgVTekAXrdqWFu={}
   if stype=='genres':
    bCYBDKHslJvRpGOwQgVTekAXrdqWFu['genre']=bCYBDKHslJvRpGOwQgVTekAXrdqWFI
   else:
    bCYBDKHslJvRpGOwQgVTekAXrdqWFu['tag'] =bCYBDKHslJvRpGOwQgVTekAXrdqWFI
   bCYBDKHslJvRpGOwQgVTekAXrdqWFu['order']=in_sort 
   if page_int>1:
    bCYBDKHslJvRpGOwQgVTekAXrdqWFu['page']=bCYBDKHslJvRpGOwQgVTekAXrdqWnm(page_int-1)
   bCYBDKHslJvRpGOwQgVTekAXrdqWfy=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.callRequestCookies('Get',bCYBDKHslJvRpGOwQgVTekAXrdqWfj,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,params=bCYBDKHslJvRpGOwQgVTekAXrdqWFu,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWnI)
   bCYBDKHslJvRpGOwQgVTekAXrdqWFf=json.loads(bCYBDKHslJvRpGOwQgVTekAXrdqWfy.text)
   bCYBDKHslJvRpGOwQgVTekAXrdqWFt=bCYBDKHslJvRpGOwQgVTekAXrdqWFf['meta']['has_next']
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   bCYBDKHslJvRpGOwQgVTekAXrdqWni(exception)
  return bCYBDKHslJvRpGOwQgVTekAXrdqWFt
 def GetProgramInfo(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,program_code):
  bCYBDKHslJvRpGOwQgVTekAXrdqWFE={}
  try:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfE ='/api/contents/'+program_code
   bCYBDKHslJvRpGOwQgVTekAXrdqWfj=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.API_DOMAIN+bCYBDKHslJvRpGOwQgVTekAXrdqWfE
   bCYBDKHslJvRpGOwQgVTekAXrdqWfy=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.callRequestCookies('Get',bCYBDKHslJvRpGOwQgVTekAXrdqWfj,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,params=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWnI)
   bCYBDKHslJvRpGOwQgVTekAXrdqWFf=json.loads(bCYBDKHslJvRpGOwQgVTekAXrdqWfy.text)
   bCYBDKHslJvRpGOwQgVTekAXrdqWFj=img_clearlogo=''
   bCYBDKHslJvRpGOwQgVTekAXrdqWFj=bCYBDKHslJvRpGOwQgVTekAXrdqWFf.get('poster').get('original')
   if bCYBDKHslJvRpGOwQgVTekAXrdqWnM(bCYBDKHslJvRpGOwQgVTekAXrdqWFf.get('title_logos'))>0:img_clearlogo=bCYBDKHslJvRpGOwQgVTekAXrdqWFf.get('title_logos')[0].get('src')
   bCYBDKHslJvRpGOwQgVTekAXrdqWFE={'imgPoster':bCYBDKHslJvRpGOwQgVTekAXrdqWFj,'imgClearlogo':img_clearlogo}
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   bCYBDKHslJvRpGOwQgVTekAXrdqWni(exception)
  return bCYBDKHslJvRpGOwQgVTekAXrdqWFE
 def GetEpisodoList(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,program_code,page_int,orderby='asc'):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfz=[]
  bCYBDKHslJvRpGOwQgVTekAXrdqWFt=bCYBDKHslJvRpGOwQgVTekAXrdqWnU
  bCYBDKHslJvRpGOwQgVTekAXrdqWxf=''
  try:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfE ='/api/contents/'+program_code+'/tv_episodes.json'
   bCYBDKHslJvRpGOwQgVTekAXrdqWfj=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.API_DOMAIN+bCYBDKHslJvRpGOwQgVTekAXrdqWfE
   bCYBDKHslJvRpGOwQgVTekAXrdqWFu={'all':'true'}
   bCYBDKHslJvRpGOwQgVTekAXrdqWfy=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.callRequestCookies('Get',bCYBDKHslJvRpGOwQgVTekAXrdqWfj,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,params=bCYBDKHslJvRpGOwQgVTekAXrdqWFu,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWnI)
   bCYBDKHslJvRpGOwQgVTekAXrdqWFf=json.loads(bCYBDKHslJvRpGOwQgVTekAXrdqWfy.text)
   if not('tv_episode_codes' in bCYBDKHslJvRpGOwQgVTekAXrdqWFf):return bCYBDKHslJvRpGOwQgVTekAXrdqWfz,bCYBDKHslJvRpGOwQgVTekAXrdqWFt
   bCYBDKHslJvRpGOwQgVTekAXrdqWFx=bCYBDKHslJvRpGOwQgVTekAXrdqWFf['tv_episode_codes']
   bCYBDKHslJvRpGOwQgVTekAXrdqWxF=bCYBDKHslJvRpGOwQgVTekAXrdqWnM(bCYBDKHslJvRpGOwQgVTekAXrdqWFx)
   bCYBDKHslJvRpGOwQgVTekAXrdqWxn =bCYBDKHslJvRpGOwQgVTekAXrdqWnS(bCYBDKHslJvRpGOwQgVTekAXrdqWxF//(bCYBDKHslJvRpGOwQgVTekAXrdqWfx.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    bCYBDKHslJvRpGOwQgVTekAXrdqWxo =(bCYBDKHslJvRpGOwQgVTekAXrdqWxF-1)-((page_int-1)*bCYBDKHslJvRpGOwQgVTekAXrdqWfx.EPISODE_LIMIT)
   else:
    bCYBDKHslJvRpGOwQgVTekAXrdqWxo =(page_int-1)*bCYBDKHslJvRpGOwQgVTekAXrdqWfx.EPISODE_LIMIT
   for i in bCYBDKHslJvRpGOwQgVTekAXrdqWna(bCYBDKHslJvRpGOwQgVTekAXrdqWfx.EPISODE_LIMIT):
    if orderby=='desc':
     bCYBDKHslJvRpGOwQgVTekAXrdqWxP=bCYBDKHslJvRpGOwQgVTekAXrdqWxo-i
     if bCYBDKHslJvRpGOwQgVTekAXrdqWxP<0:break
    else:
     bCYBDKHslJvRpGOwQgVTekAXrdqWxP=bCYBDKHslJvRpGOwQgVTekAXrdqWxo+i
     if bCYBDKHslJvRpGOwQgVTekAXrdqWxP>=bCYBDKHslJvRpGOwQgVTekAXrdqWxF:break
    if bCYBDKHslJvRpGOwQgVTekAXrdqWxf!='':bCYBDKHslJvRpGOwQgVTekAXrdqWxf+=','
    bCYBDKHslJvRpGOwQgVTekAXrdqWxf+=bCYBDKHslJvRpGOwQgVTekAXrdqWFx[bCYBDKHslJvRpGOwQgVTekAXrdqWxP]
   if bCYBDKHslJvRpGOwQgVTekAXrdqWxn>page_int:bCYBDKHslJvRpGOwQgVTekAXrdqWFt=bCYBDKHslJvRpGOwQgVTekAXrdqWnt
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   bCYBDKHslJvRpGOwQgVTekAXrdqWni(exception)
  bCYBDKHslJvRpGOwQgVTekAXrdqWxI=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.GetProgramInfo(program_code)
  try:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfj=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.API_DOMAIN+bCYBDKHslJvRpGOwQgVTekAXrdqWfE
   bCYBDKHslJvRpGOwQgVTekAXrdqWFu={'codes':bCYBDKHslJvRpGOwQgVTekAXrdqWxf}
   bCYBDKHslJvRpGOwQgVTekAXrdqWfy=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.callRequestCookies('Get',bCYBDKHslJvRpGOwQgVTekAXrdqWfj,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,params=bCYBDKHslJvRpGOwQgVTekAXrdqWFu,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWnI)
   bCYBDKHslJvRpGOwQgVTekAXrdqWFf=json.loads(bCYBDKHslJvRpGOwQgVTekAXrdqWfy.text)
   if not('tv_episodes' in bCYBDKHslJvRpGOwQgVTekAXrdqWFf):return bCYBDKHslJvRpGOwQgVTekAXrdqWfz
   bCYBDKHslJvRpGOwQgVTekAXrdqWFx=bCYBDKHslJvRpGOwQgVTekAXrdqWFf['tv_episodes']
   for bCYBDKHslJvRpGOwQgVTekAXrdqWFn in bCYBDKHslJvRpGOwQgVTekAXrdqWFx:
    bCYBDKHslJvRpGOwQgVTekAXrdqWFi =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['code']
    if bCYBDKHslJvRpGOwQgVTekAXrdqWFn['title']:
     bCYBDKHslJvRpGOwQgVTekAXrdqWFM =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['title']
    else:
     bCYBDKHslJvRpGOwQgVTekAXrdqWFM =''
    bCYBDKHslJvRpGOwQgVTekAXrdqWFa=tmp_thumb=tmp_fanart=bCYBDKHslJvRpGOwQgVTekAXrdqWxU=''
    bCYBDKHslJvRpGOwQgVTekAXrdqWFa =bCYBDKHslJvRpGOwQgVTekAXrdqWxI.get('imgPoster')
    bCYBDKHslJvRpGOwQgVTekAXrdqWxU=bCYBDKHslJvRpGOwQgVTekAXrdqWxI.get('imgClearlogo')
    if bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('stillcut') !=bCYBDKHslJvRpGOwQgVTekAXrdqWnI:tmp_thumb =bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('stillcut').get('large')
    if bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('tv_season_stillcut')!=bCYBDKHslJvRpGOwQgVTekAXrdqWnI:tmp_fanart=bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('tv_season_stillcut').get('large')
    bCYBDKHslJvRpGOwQgVTekAXrdqWFy={'thumb':tmp_thumb,'poster':bCYBDKHslJvRpGOwQgVTekAXrdqWFa,'fanart':tmp_fanart,'clearlogo':bCYBDKHslJvRpGOwQgVTekAXrdqWxU}
    bCYBDKHslJvRpGOwQgVTekAXrdqWxt =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['display_number']
    bCYBDKHslJvRpGOwQgVTekAXrdqWxu=bCYBDKHslJvRpGOwQgVTekAXrdqWFn['tv_season_title']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFz =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['duration']
    try:
     bCYBDKHslJvRpGOwQgVTekAXrdqWxi=bCYBDKHslJvRpGOwQgVTekAXrdqWFn['episode_number']
    except:
     bCYBDKHslJvRpGOwQgVTekAXrdqWxi='0'
    bCYBDKHslJvRpGOwQgVTekAXrdqWFU={'code':bCYBDKHslJvRpGOwQgVTekAXrdqWFi,'title':bCYBDKHslJvRpGOwQgVTekAXrdqWFM,'thumbnail':bCYBDKHslJvRpGOwQgVTekAXrdqWFy,'display_num':bCYBDKHslJvRpGOwQgVTekAXrdqWxt,'season_title':bCYBDKHslJvRpGOwQgVTekAXrdqWxu,'duration':bCYBDKHslJvRpGOwQgVTekAXrdqWFz,'episode_number':bCYBDKHslJvRpGOwQgVTekAXrdqWxi}
    bCYBDKHslJvRpGOwQgVTekAXrdqWfz.append(bCYBDKHslJvRpGOwQgVTekAXrdqWFU)
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   bCYBDKHslJvRpGOwQgVTekAXrdqWni(exception)
  return bCYBDKHslJvRpGOwQgVTekAXrdqWfz,bCYBDKHslJvRpGOwQgVTekAXrdqWFt
 def GetSearchList(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,search_key,page_int):
  bCYBDKHslJvRpGOwQgVTekAXrdqWxm=[]
  bCYBDKHslJvRpGOwQgVTekAXrdqWFt=bCYBDKHslJvRpGOwQgVTekAXrdqWnU
  try:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfE ='/api/search.json'
   bCYBDKHslJvRpGOwQgVTekAXrdqWfj=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.API_DOMAIN+bCYBDKHslJvRpGOwQgVTekAXrdqWfE
   bCYBDKHslJvRpGOwQgVTekAXrdqWFu={'query':search_key,'page':bCYBDKHslJvRpGOwQgVTekAXrdqWnm(page_int),'per':bCYBDKHslJvRpGOwQgVTekAXrdqWnm(bCYBDKHslJvRpGOwQgVTekAXrdqWfx.SEARCH_LIMIT),'exclude':'limited'}
   bCYBDKHslJvRpGOwQgVTekAXrdqWfy=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.callRequestCookies('Get',bCYBDKHslJvRpGOwQgVTekAXrdqWfj,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,params=bCYBDKHslJvRpGOwQgVTekAXrdqWFu,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWnI)
   bCYBDKHslJvRpGOwQgVTekAXrdqWFf=json.loads(bCYBDKHslJvRpGOwQgVTekAXrdqWfy.text)
   if not('results' in bCYBDKHslJvRpGOwQgVTekAXrdqWFf):return bCYBDKHslJvRpGOwQgVTekAXrdqWxm,bCYBDKHslJvRpGOwQgVTekAXrdqWFt
   bCYBDKHslJvRpGOwQgVTekAXrdqWFx=bCYBDKHslJvRpGOwQgVTekAXrdqWFf['results']
   bCYBDKHslJvRpGOwQgVTekAXrdqWFt=bCYBDKHslJvRpGOwQgVTekAXrdqWFf['meta']['has_next']
   for bCYBDKHslJvRpGOwQgVTekAXrdqWFn in bCYBDKHslJvRpGOwQgVTekAXrdqWFx:
    bCYBDKHslJvRpGOwQgVTekAXrdqWFi =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['code']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFm=bCYBDKHslJvRpGOwQgVTekAXrdqWFn['content_type']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFM =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['title']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFS =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['story']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFa=tmp_thumb=tmp_fanart=''
    if bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('poster') !=bCYBDKHslJvRpGOwQgVTekAXrdqWnI:bCYBDKHslJvRpGOwQgVTekAXrdqWFa=bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('poster').get('original')
    if bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('stillcut')!=bCYBDKHslJvRpGOwQgVTekAXrdqWnI:tmp_thumb =bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('stillcut').get('large')
    if bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('thumbnail')!=bCYBDKHslJvRpGOwQgVTekAXrdqWnI:tmp_fanart=bCYBDKHslJvRpGOwQgVTekAXrdqWFn.get('thumbnail').get('large')
    if tmp_fanart=='' :tmp_fanart=tmp_thumb
    bCYBDKHslJvRpGOwQgVTekAXrdqWFy={'thumb':tmp_thumb,'poster':bCYBDKHslJvRpGOwQgVTekAXrdqWFa,'fanart':tmp_fanart}
    bCYBDKHslJvRpGOwQgVTekAXrdqWFN =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['year']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFL =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['film_rating_code']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFh=bCYBDKHslJvRpGOwQgVTekAXrdqWFn['film_rating_short']
    bCYBDKHslJvRpGOwQgVTekAXrdqWFc =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['film_rating_long']
    if bCYBDKHslJvRpGOwQgVTekAXrdqWFm=='movies':
     bCYBDKHslJvRpGOwQgVTekAXrdqWFz =bCYBDKHslJvRpGOwQgVTekAXrdqWFn['duration']
    else:
     bCYBDKHslJvRpGOwQgVTekAXrdqWFz ='0'
    bCYBDKHslJvRpGOwQgVTekAXrdqWFU={'code':bCYBDKHslJvRpGOwQgVTekAXrdqWFi,'content_type':bCYBDKHslJvRpGOwQgVTekAXrdqWFm,'title':bCYBDKHslJvRpGOwQgVTekAXrdqWFM,'story':bCYBDKHslJvRpGOwQgVTekAXrdqWFS,'thumbnail':bCYBDKHslJvRpGOwQgVTekAXrdqWFy,'year':bCYBDKHslJvRpGOwQgVTekAXrdqWFN,'film_rating_code':bCYBDKHslJvRpGOwQgVTekAXrdqWFL,'film_rating_short':bCYBDKHslJvRpGOwQgVTekAXrdqWFh,'film_rating_long':bCYBDKHslJvRpGOwQgVTekAXrdqWFc,'duration':bCYBDKHslJvRpGOwQgVTekAXrdqWFz}
    bCYBDKHslJvRpGOwQgVTekAXrdqWxm.append(bCYBDKHslJvRpGOwQgVTekAXrdqWFU)
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   bCYBDKHslJvRpGOwQgVTekAXrdqWni(exception)
  return bCYBDKHslJvRpGOwQgVTekAXrdqWxm,bCYBDKHslJvRpGOwQgVTekAXrdqWFt
 def GetProfilesList(bCYBDKHslJvRpGOwQgVTekAXrdqWfx):
  bCYBDKHslJvRpGOwQgVTekAXrdqWfh=[]
  try:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfE ='/manage_profiles'
   bCYBDKHslJvRpGOwQgVTekAXrdqWfj=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.MAIN_DOMAIN+bCYBDKHslJvRpGOwQgVTekAXrdqWfE
   bCYBDKHslJvRpGOwQgVTekAXrdqWfN=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.makeDefaultCookies()
   bCYBDKHslJvRpGOwQgVTekAXrdqWfy=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.callRequestCookies('Get',bCYBDKHslJvRpGOwQgVTekAXrdqWfj,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,params=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWfN,redirects=bCYBDKHslJvRpGOwQgVTekAXrdqWnt)
   bCYBDKHslJvRpGOwQgVTekAXrdqWxM=bCYBDKHslJvRpGOwQgVTekAXrdqWfy.text
   bCYBDKHslJvRpGOwQgVTekAXrdqWxS =re.findall('/api/users/me.{5000}',bCYBDKHslJvRpGOwQgVTekAXrdqWxM)[0]
   bCYBDKHslJvRpGOwQgVTekAXrdqWxS =bCYBDKHslJvRpGOwQgVTekAXrdqWxS.replace('&quot;','')
   bCYBDKHslJvRpGOwQgVTekAXrdqWfh=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',bCYBDKHslJvRpGOwQgVTekAXrdqWxS)
   for i in bCYBDKHslJvRpGOwQgVTekAXrdqWna(bCYBDKHslJvRpGOwQgVTekAXrdqWnM(bCYBDKHslJvRpGOwQgVTekAXrdqWfh)):
    bCYBDKHslJvRpGOwQgVTekAXrdqWxa=bCYBDKHslJvRpGOwQgVTekAXrdqWfh[i]
    bCYBDKHslJvRpGOwQgVTekAXrdqWxa =bCYBDKHslJvRpGOwQgVTekAXrdqWxa.split(':')[1]
    bCYBDKHslJvRpGOwQgVTekAXrdqWfh[i]=bCYBDKHslJvRpGOwQgVTekAXrdqWxa.split(',')[0]
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   bCYBDKHslJvRpGOwQgVTekAXrdqWni(exception)
  return bCYBDKHslJvRpGOwQgVTekAXrdqWfh
 def GetProfilesConvert(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,bCYBDKHslJvRpGOwQgVTekAXrdqWfI):
  bCYBDKHslJvRpGOwQgVTekAXrdqWxy=''
  bCYBDKHslJvRpGOwQgVTekAXrdqWxN=''
  try:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfE ='/api/users/'+bCYBDKHslJvRpGOwQgVTekAXrdqWfI+'/convert'
   bCYBDKHslJvRpGOwQgVTekAXrdqWfj=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.API_DOMAIN+bCYBDKHslJvRpGOwQgVTekAXrdqWfE
   bCYBDKHslJvRpGOwQgVTekAXrdqWfN=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.makeDefaultCookies()
   bCYBDKHslJvRpGOwQgVTekAXrdqWfy=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.callRequestCookies('Put',bCYBDKHslJvRpGOwQgVTekAXrdqWfj,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,params=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWfN)
   for bCYBDKHslJvRpGOwQgVTekAXrdqWfN in bCYBDKHslJvRpGOwQgVTekAXrdqWfy.cookies:
    if bCYBDKHslJvRpGOwQgVTekAXrdqWfN.name=='_s_guitv':
     bCYBDKHslJvRpGOwQgVTekAXrdqWxL=bCYBDKHslJvRpGOwQgVTekAXrdqWfN.value
    elif bCYBDKHslJvRpGOwQgVTekAXrdqWfN.name=='_guinness-premium_session':
     bCYBDKHslJvRpGOwQgVTekAXrdqWfL=bCYBDKHslJvRpGOwQgVTekAXrdqWfN.value
   if bCYBDKHslJvRpGOwQgVTekAXrdqWxL:
    bCYBDKHslJvRpGOwQgVTekAXrdqWxy=bCYBDKHslJvRpGOwQgVTekAXrdqWxL
   if bCYBDKHslJvRpGOwQgVTekAXrdqWfL:
    bCYBDKHslJvRpGOwQgVTekAXrdqWxN=bCYBDKHslJvRpGOwQgVTekAXrdqWfL
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   bCYBDKHslJvRpGOwQgVTekAXrdqWxy=''
   bCYBDKHslJvRpGOwQgVTekAXrdqWxN=''
  return bCYBDKHslJvRpGOwQgVTekAXrdqWxy,bCYBDKHslJvRpGOwQgVTekAXrdqWxN
 def Get_Now_Datetime(bCYBDKHslJvRpGOwQgVTekAXrdqWfx):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(bCYBDKHslJvRpGOwQgVTekAXrdqWfx,movie_code,quality_str):
  bCYBDKHslJvRpGOwQgVTekAXrdqWxc=bCYBDKHslJvRpGOwQgVTekAXrdqWxE=bCYBDKHslJvRpGOwQgVTekAXrdqWno=''
  try:
   bCYBDKHslJvRpGOwQgVTekAXrdqWfE='/api/watch/'+movie_code+'.json'
   bCYBDKHslJvRpGOwQgVTekAXrdqWfj=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.API_DOMAIN+bCYBDKHslJvRpGOwQgVTekAXrdqWfE
   bCYBDKHslJvRpGOwQgVTekAXrdqWfa={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   bCYBDKHslJvRpGOwQgVTekAXrdqWfN=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.makeDefaultCookies()
   bCYBDKHslJvRpGOwQgVTekAXrdqWfy=bCYBDKHslJvRpGOwQgVTekAXrdqWfx.callRequestCookies('Get',bCYBDKHslJvRpGOwQgVTekAXrdqWfj,payload=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,params=bCYBDKHslJvRpGOwQgVTekAXrdqWnI,headers=bCYBDKHslJvRpGOwQgVTekAXrdqWfa,cookies=bCYBDKHslJvRpGOwQgVTekAXrdqWfN)
   bCYBDKHslJvRpGOwQgVTekAXrdqWFf=json.loads(bCYBDKHslJvRpGOwQgVTekAXrdqWfy.text)
   bCYBDKHslJvRpGOwQgVTekAXrdqWxc=bCYBDKHslJvRpGOwQgVTekAXrdqWFf['streams'][0]['source']
   if bCYBDKHslJvRpGOwQgVTekAXrdqWxc==bCYBDKHslJvRpGOwQgVTekAXrdqWnI:return(bCYBDKHslJvRpGOwQgVTekAXrdqWxc,bCYBDKHslJvRpGOwQgVTekAXrdqWxE,bCYBDKHslJvRpGOwQgVTekAXrdqWno)
   if 'subtitles' in bCYBDKHslJvRpGOwQgVTekAXrdqWFf['streams'][0]:
    for bCYBDKHslJvRpGOwQgVTekAXrdqWxz in bCYBDKHslJvRpGOwQgVTekAXrdqWFf['streams'][0]['subtitles']:
     if bCYBDKHslJvRpGOwQgVTekAXrdqWxz['lang']=='ko':
      bCYBDKHslJvRpGOwQgVTekAXrdqWxE=bCYBDKHslJvRpGOwQgVTekAXrdqWxz['url']
      break
   bCYBDKHslJvRpGOwQgVTekAXrdqWxj =bCYBDKHslJvRpGOwQgVTekAXrdqWFf['ping_payload']
   bCYBDKHslJvRpGOwQgVTekAXrdqWnf =bCYBDKHslJvRpGOwQgVTekAXrdqWfx.WATCHA_USERCD
   bCYBDKHslJvRpGOwQgVTekAXrdqWnF={'merchant':'giitd_frograms','sessionId':bCYBDKHslJvRpGOwQgVTekAXrdqWxj,'userId':bCYBDKHslJvRpGOwQgVTekAXrdqWnf}
   bCYBDKHslJvRpGOwQgVTekAXrdqWnx=json.dumps(bCYBDKHslJvRpGOwQgVTekAXrdqWnF,separators=(",",":")).encode('UTF-8')
   bCYBDKHslJvRpGOwQgVTekAXrdqWno=base64.b64encode(bCYBDKHslJvRpGOwQgVTekAXrdqWnx)
  except bCYBDKHslJvRpGOwQgVTekAXrdqWnu as exception:
   return(bCYBDKHslJvRpGOwQgVTekAXrdqWxc,bCYBDKHslJvRpGOwQgVTekAXrdqWxE,bCYBDKHslJvRpGOwQgVTekAXrdqWno)
  return(bCYBDKHslJvRpGOwQgVTekAXrdqWxc,bCYBDKHslJvRpGOwQgVTekAXrdqWxE,bCYBDKHslJvRpGOwQgVTekAXrdqWno) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
