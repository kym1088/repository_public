__author__="NightRain"
uxAQrEnXtFRIdiCkczglJqVbvBjPhT=object
uxAQrEnXtFRIdiCkczglJqVbvBjPhN=None
uxAQrEnXtFRIdiCkczglJqVbvBjPhW=False
uxAQrEnXtFRIdiCkczglJqVbvBjPhp=True
uxAQrEnXtFRIdiCkczglJqVbvBjPhw=Exception
uxAQrEnXtFRIdiCkczglJqVbvBjPha=print
uxAQrEnXtFRIdiCkczglJqVbvBjPho=str
uxAQrEnXtFRIdiCkczglJqVbvBjPhH=len
uxAQrEnXtFRIdiCkczglJqVbvBjPhY=int
uxAQrEnXtFRIdiCkczglJqVbvBjPhK=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import base64
import requests
import datetime
uxAQrEnXtFRIdiCkczglJqVbvBjPTW='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
class uxAQrEnXtFRIdiCkczglJqVbvBjPTN(uxAQrEnXtFRIdiCkczglJqVbvBjPhT):
 def __init__(uxAQrEnXtFRIdiCkczglJqVbvBjPTh):
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_TOKEN ='' 
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUIT =''
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUITV =''
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_USERCD=''
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.API_DOMAIN ='https://play.watcha.net'
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.EPISODE_LIMIT=20
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.SEARCH_LIMIT =30
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.DEFAULT_HEADER={'user-agent':uxAQrEnXtFRIdiCkczglJqVbvBjPTW,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,jobtype,uxAQrEnXtFRIdiCkczglJqVbvBjPTf,payload=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,params=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,cookies=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,redirects=uxAQrEnXtFRIdiCkczglJqVbvBjPhW):
  uxAQrEnXtFRIdiCkczglJqVbvBjPTp=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.DEFAULT_HEADER
  if headers:uxAQrEnXtFRIdiCkczglJqVbvBjPTp.update(headers)
  if jobtype=='Get':
   uxAQrEnXtFRIdiCkczglJqVbvBjPTw=requests.get(uxAQrEnXtFRIdiCkczglJqVbvBjPTf,params=params,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPTp,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   uxAQrEnXtFRIdiCkczglJqVbvBjPTw=requests.put(uxAQrEnXtFRIdiCkczglJqVbvBjPTf,data=payload,params=params,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPTp,cookies=cookies,allow_redirects=redirects)
  else:
   uxAQrEnXtFRIdiCkczglJqVbvBjPTw=requests.post(uxAQrEnXtFRIdiCkczglJqVbvBjPTf,data=payload,params=params,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPTp,cookies=cookies,allow_redirects=redirects)
  return uxAQrEnXtFRIdiCkczglJqVbvBjPTw
 def SaveCredential(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,uxAQrEnXtFRIdiCkczglJqVbvBjPTa):
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_TOKEN =uxAQrEnXtFRIdiCkczglJqVbvBjPTa.get('watcha_token')
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUIT =uxAQrEnXtFRIdiCkczglJqVbvBjPTa.get('watcha_guit')
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUITV =uxAQrEnXtFRIdiCkczglJqVbvBjPTa.get('watcha_guitv')
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_USERCD =uxAQrEnXtFRIdiCkczglJqVbvBjPTa.get('watcha_usercd')
 def SaveCredential_usercd(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,uxAQrEnXtFRIdiCkczglJqVbvBjPTo):
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_USERCD=uxAQrEnXtFRIdiCkczglJqVbvBjPTo
 def SaveCredential_guitv(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,uxAQrEnXtFRIdiCkczglJqVbvBjPTH,uxAQrEnXtFRIdiCkczglJqVbvBjPTY):
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUITV=uxAQrEnXtFRIdiCkczglJqVbvBjPTH
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_TOKEN=uxAQrEnXtFRIdiCkczglJqVbvBjPTY 
 def ClearCredential(uxAQrEnXtFRIdiCkczglJqVbvBjPTh):
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_TOKEN ='' 
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUIT =''
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUITV =''
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_USERCD=''
 def LoadCredential(uxAQrEnXtFRIdiCkczglJqVbvBjPTh):
  uxAQrEnXtFRIdiCkczglJqVbvBjPTa={'watcha_token':uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_TOKEN,'watcha_guit':uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUIT,'watcha_guitv':uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUITV,'watcha_usercd':uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_USERCD}
  return uxAQrEnXtFRIdiCkczglJqVbvBjPTa
 def makeDefaultCookies(uxAQrEnXtFRIdiCkczglJqVbvBjPTh):
  uxAQrEnXtFRIdiCkczglJqVbvBjPTK={'_s_guit':uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUIT,'_guinness-premium_session':uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_TOKEN}
  if uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUITV:
   uxAQrEnXtFRIdiCkczglJqVbvBjPTK['_s_guitv']=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_GUITV
  return uxAQrEnXtFRIdiCkczglJqVbvBjPTK
 def makeurl(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,domain,path,query1=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,query2=uxAQrEnXtFRIdiCkczglJqVbvBjPhN):
  uxAQrEnXtFRIdiCkczglJqVbvBjPTf=domain+path
  if query1:
   uxAQrEnXtFRIdiCkczglJqVbvBjPTf+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   uxAQrEnXtFRIdiCkczglJqVbvBjPTf+='&%s'%urllib.parse.urlencode(query2)
  return uxAQrEnXtFRIdiCkczglJqVbvBjPTf
 def GetCredential(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,user_id,user_pw,user_pf):
  uxAQrEnXtFRIdiCkczglJqVbvBjPTs=uxAQrEnXtFRIdiCkczglJqVbvBjPhW
  uxAQrEnXtFRIdiCkczglJqVbvBjPTG=uxAQrEnXtFRIdiCkczglJqVbvBjPTD='-'
  try:
   uxAQrEnXtFRIdiCkczglJqVbvBjPTM=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.API_DOMAIN+'/api/session'
   uxAQrEnXtFRIdiCkczglJqVbvBjPTm={'email':user_id,'password':user_pw}
   uxAQrEnXtFRIdiCkczglJqVbvBjPTU={'accept':'application/vnd.frograms+json;version=4'}
   uxAQrEnXtFRIdiCkczglJqVbvBjPTe=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.callRequestCookies('Post',uxAQrEnXtFRIdiCkczglJqVbvBjPTM,payload=uxAQrEnXtFRIdiCkczglJqVbvBjPTm,params=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPTU,cookies=uxAQrEnXtFRIdiCkczglJqVbvBjPhN)
   for uxAQrEnXtFRIdiCkczglJqVbvBjPTy in uxAQrEnXtFRIdiCkczglJqVbvBjPTe.cookies:
    if uxAQrEnXtFRIdiCkczglJqVbvBjPTy.name=='_guinness-premium_session':
     uxAQrEnXtFRIdiCkczglJqVbvBjPTD=uxAQrEnXtFRIdiCkczglJqVbvBjPTy.value
    elif uxAQrEnXtFRIdiCkczglJqVbvBjPTy.name=='_s_guit':
     uxAQrEnXtFRIdiCkczglJqVbvBjPTG=uxAQrEnXtFRIdiCkczglJqVbvBjPTy.value
   if uxAQrEnXtFRIdiCkczglJqVbvBjPTD:uxAQrEnXtFRIdiCkczglJqVbvBjPTs=uxAQrEnXtFRIdiCkczglJqVbvBjPhp
  except uxAQrEnXtFRIdiCkczglJqVbvBjPhw as exception:
   uxAQrEnXtFRIdiCkczglJqVbvBjPha(exception)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTG=uxAQrEnXtFRIdiCkczglJqVbvBjPTD='' 
  uxAQrEnXtFRIdiCkczglJqVbvBjPTa={'watcha_guit':uxAQrEnXtFRIdiCkczglJqVbvBjPTG,'watcha_token':uxAQrEnXtFRIdiCkczglJqVbvBjPTD,'watcha_guitv':'','watcha_usercd':''}
  uxAQrEnXtFRIdiCkczglJqVbvBjPTh.SaveCredential(uxAQrEnXtFRIdiCkczglJqVbvBjPTa)
  try:
   uxAQrEnXtFRIdiCkczglJqVbvBjPTL=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.GetProfilesList()
   uxAQrEnXtFRIdiCkczglJqVbvBjPNT =uxAQrEnXtFRIdiCkczglJqVbvBjPTL[user_pf]
   uxAQrEnXtFRIdiCkczglJqVbvBjPTh.SaveCredential_usercd(uxAQrEnXtFRIdiCkczglJqVbvBjPNT)
  except uxAQrEnXtFRIdiCkczglJqVbvBjPhw as exception:
   uxAQrEnXtFRIdiCkczglJqVbvBjPha(exception)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTh.ClearCredential()
   return uxAQrEnXtFRIdiCkczglJqVbvBjPhW
  if user_pf!=0:
   uxAQrEnXtFRIdiCkczglJqVbvBjPTH,uxAQrEnXtFRIdiCkczglJqVbvBjPTY=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.GetProfilesConvert(uxAQrEnXtFRIdiCkczglJqVbvBjPNT)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTh.SaveCredential_guitv(uxAQrEnXtFRIdiCkczglJqVbvBjPTH,uxAQrEnXtFRIdiCkczglJqVbvBjPTY)
  return uxAQrEnXtFRIdiCkczglJqVbvBjPTs
 def GetSubGroupList(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,stype):
  uxAQrEnXtFRIdiCkczglJqVbvBjPNW=[]
  try:
   uxAQrEnXtFRIdiCkczglJqVbvBjPNh ='/api/categories.json'
   uxAQrEnXtFRIdiCkczglJqVbvBjPTf=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeurl(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.API_DOMAIN,uxAQrEnXtFRIdiCkczglJqVbvBjPNh)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTy=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeDefaultCookies()
   uxAQrEnXtFRIdiCkczglJqVbvBjPTe=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.callRequestCookies('Get',uxAQrEnXtFRIdiCkczglJqVbvBjPTf,payload=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,params=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,cookies=uxAQrEnXtFRIdiCkczglJqVbvBjPTy)
   uxAQrEnXtFRIdiCkczglJqVbvBjPNp=json.loads(uxAQrEnXtFRIdiCkczglJqVbvBjPTe.text)
   if not('genres' in uxAQrEnXtFRIdiCkczglJqVbvBjPNp):return uxAQrEnXtFRIdiCkczglJqVbvBjPNW
   if stype=='genres':
    uxAQrEnXtFRIdiCkczglJqVbvBjPNw=uxAQrEnXtFRIdiCkczglJqVbvBjPNp['genres']
   else:
    uxAQrEnXtFRIdiCkczglJqVbvBjPNw=uxAQrEnXtFRIdiCkczglJqVbvBjPNp['tags']
   for uxAQrEnXtFRIdiCkczglJqVbvBjPNa in uxAQrEnXtFRIdiCkczglJqVbvBjPNw:
    uxAQrEnXtFRIdiCkczglJqVbvBjPNo=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['name']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNH =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['api_path']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNY =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['entity']['id']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNK={'group_name':uxAQrEnXtFRIdiCkczglJqVbvBjPNo,'api_path':uxAQrEnXtFRIdiCkczglJqVbvBjPNH,'tag_id':uxAQrEnXtFRIdiCkczglJqVbvBjPho(uxAQrEnXtFRIdiCkczglJqVbvBjPNY)}
    uxAQrEnXtFRIdiCkczglJqVbvBjPNW.append(uxAQrEnXtFRIdiCkczglJqVbvBjPNK)
  except uxAQrEnXtFRIdiCkczglJqVbvBjPhw as exception:
   uxAQrEnXtFRIdiCkczglJqVbvBjPha(exception)
  return uxAQrEnXtFRIdiCkczglJqVbvBjPNW
 def GetCategoryList(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,stype,uxAQrEnXtFRIdiCkczglJqVbvBjPNY,uxAQrEnXtFRIdiCkczglJqVbvBjPNH,page_int,in_sort):
  uxAQrEnXtFRIdiCkczglJqVbvBjPNW=[]
  uxAQrEnXtFRIdiCkczglJqVbvBjPNf=uxAQrEnXtFRIdiCkczglJqVbvBjPhW
  uxAQrEnXtFRIdiCkczglJqVbvBjPNO={}
  try:
   if 'categories' in uxAQrEnXtFRIdiCkczglJqVbvBjPNH:
    uxAQrEnXtFRIdiCkczglJqVbvBjPNh ='/api/categories/contents.json'
    if stype=='genres':
     uxAQrEnXtFRIdiCkczglJqVbvBjPNO['genre']=uxAQrEnXtFRIdiCkczglJqVbvBjPNY
    else:
     uxAQrEnXtFRIdiCkczglJqVbvBjPNO['tag'] =uxAQrEnXtFRIdiCkczglJqVbvBjPNY
    uxAQrEnXtFRIdiCkczglJqVbvBjPNO['order']=in_sort 
    if page_int>1:
     uxAQrEnXtFRIdiCkczglJqVbvBjPNO['page']=uxAQrEnXtFRIdiCkczglJqVbvBjPho(page_int-1)
   else: 
    uxAQrEnXtFRIdiCkczglJqVbvBjPNh ='/api/'+uxAQrEnXtFRIdiCkczglJqVbvBjPNH+'.json'
    if page_int>1:
     uxAQrEnXtFRIdiCkczglJqVbvBjPNO['page']=uxAQrEnXtFRIdiCkczglJqVbvBjPho(page_int)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTf=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeurl(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.API_DOMAIN,uxAQrEnXtFRIdiCkczglJqVbvBjPNh)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTy=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeDefaultCookies()
   uxAQrEnXtFRIdiCkczglJqVbvBjPTe=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.callRequestCookies('Get',uxAQrEnXtFRIdiCkczglJqVbvBjPTf,payload=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,params=uxAQrEnXtFRIdiCkczglJqVbvBjPNO,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,cookies=uxAQrEnXtFRIdiCkczglJqVbvBjPTy)
   uxAQrEnXtFRIdiCkczglJqVbvBjPNp=json.loads(uxAQrEnXtFRIdiCkczglJqVbvBjPTe.text)
   if not('contents' in uxAQrEnXtFRIdiCkczglJqVbvBjPNp):return uxAQrEnXtFRIdiCkczglJqVbvBjPNW,uxAQrEnXtFRIdiCkczglJqVbvBjPNf
   uxAQrEnXtFRIdiCkczglJqVbvBjPNw=uxAQrEnXtFRIdiCkczglJqVbvBjPNp['contents']
   uxAQrEnXtFRIdiCkczglJqVbvBjPNf=uxAQrEnXtFRIdiCkczglJqVbvBjPNp['meta']['has_next']
   for uxAQrEnXtFRIdiCkczglJqVbvBjPNa in uxAQrEnXtFRIdiCkczglJqVbvBjPNw:
    uxAQrEnXtFRIdiCkczglJqVbvBjPNS =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['code']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNs=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['content_type']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNG =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['title']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNM =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['story']
    if uxAQrEnXtFRIdiCkczglJqVbvBjPNa['thumbnail']!=uxAQrEnXtFRIdiCkczglJqVbvBjPhN:
     uxAQrEnXtFRIdiCkczglJqVbvBjPNm =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['thumbnail']['medium']
    else:
     uxAQrEnXtFRIdiCkczglJqVbvBjPNm =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['stillcut']['medium']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNU =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['year']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNe =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['film_rating_code']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNy=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['film_rating_short']
    uxAQrEnXtFRIdiCkczglJqVbvBjPND={}
    uxAQrEnXtFRIdiCkczglJqVbvBjPND['mpaa']=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['film_rating_long']
    uxAQrEnXtFRIdiCkczglJqVbvBjPND['year']=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['year']
    uxAQrEnXtFRIdiCkczglJqVbvBjPND['title']=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['title']
    if uxAQrEnXtFRIdiCkczglJqVbvBjPNs=='movies':
     uxAQrEnXtFRIdiCkczglJqVbvBjPND['mediatype']='movie' 
     uxAQrEnXtFRIdiCkczglJqVbvBjPND['duration']=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['duration']
    else:
     uxAQrEnXtFRIdiCkczglJqVbvBjPND['mediatype']='episode' 
    uxAQrEnXtFRIdiCkczglJqVbvBjPNK={'code':uxAQrEnXtFRIdiCkczglJqVbvBjPNS,'content_type':uxAQrEnXtFRIdiCkczglJqVbvBjPNs,'title':uxAQrEnXtFRIdiCkczglJqVbvBjPNG,'story':uxAQrEnXtFRIdiCkczglJqVbvBjPNM,'thumbnail':uxAQrEnXtFRIdiCkczglJqVbvBjPNm,'year':uxAQrEnXtFRIdiCkczglJqVbvBjPNU,'film_rating_code':uxAQrEnXtFRIdiCkczglJqVbvBjPNe,'film_rating_short':uxAQrEnXtFRIdiCkczglJqVbvBjPNy,'info':uxAQrEnXtFRIdiCkczglJqVbvBjPND}
    uxAQrEnXtFRIdiCkczglJqVbvBjPNW.append(uxAQrEnXtFRIdiCkczglJqVbvBjPNK)
  except uxAQrEnXtFRIdiCkczglJqVbvBjPhw as exception:
   uxAQrEnXtFRIdiCkczglJqVbvBjPha(exception)
  return uxAQrEnXtFRIdiCkczglJqVbvBjPNW,uxAQrEnXtFRIdiCkczglJqVbvBjPNf
 def GetCategoryList_morepage(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,stype,uxAQrEnXtFRIdiCkczglJqVbvBjPNY,uxAQrEnXtFRIdiCkczglJqVbvBjPNH,page_int,in_sort):
  uxAQrEnXtFRIdiCkczglJqVbvBjPNf=uxAQrEnXtFRIdiCkczglJqVbvBjPhW
  if not('categories' in uxAQrEnXtFRIdiCkczglJqVbvBjPNH):return uxAQrEnXtFRIdiCkczglJqVbvBjPhp
  try:
   uxAQrEnXtFRIdiCkczglJqVbvBjPNh ='/api/categories/contents.json'
   uxAQrEnXtFRIdiCkczglJqVbvBjPNO={}
   if stype=='genres':
    uxAQrEnXtFRIdiCkczglJqVbvBjPNO['genre']=uxAQrEnXtFRIdiCkczglJqVbvBjPNY
   else:
    uxAQrEnXtFRIdiCkczglJqVbvBjPNO['tag'] =uxAQrEnXtFRIdiCkczglJqVbvBjPNY
   uxAQrEnXtFRIdiCkczglJqVbvBjPNO['order']=in_sort 
   if page_int>1:
    uxAQrEnXtFRIdiCkczglJqVbvBjPNO['page']=uxAQrEnXtFRIdiCkczglJqVbvBjPho(page_int-1)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTf=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeurl(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.API_DOMAIN,uxAQrEnXtFRIdiCkczglJqVbvBjPNh)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTy=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeDefaultCookies()
   uxAQrEnXtFRIdiCkczglJqVbvBjPTe=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.callRequestCookies('Get',uxAQrEnXtFRIdiCkczglJqVbvBjPTf,payload=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,params=uxAQrEnXtFRIdiCkczglJqVbvBjPNO,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,cookies=uxAQrEnXtFRIdiCkczglJqVbvBjPTy)
   uxAQrEnXtFRIdiCkczglJqVbvBjPNp=json.loads(uxAQrEnXtFRIdiCkczglJqVbvBjPTe.text)
   uxAQrEnXtFRIdiCkczglJqVbvBjPNf=uxAQrEnXtFRIdiCkczglJqVbvBjPNp['meta']['has_next']
  except uxAQrEnXtFRIdiCkczglJqVbvBjPhw as exception:
   uxAQrEnXtFRIdiCkczglJqVbvBjPha(exception)
  return uxAQrEnXtFRIdiCkczglJqVbvBjPNf
 def GetEpisodoList(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,program_code,page_int,orderby='asc'):
  uxAQrEnXtFRIdiCkczglJqVbvBjPNW=[]
  uxAQrEnXtFRIdiCkczglJqVbvBjPNf=uxAQrEnXtFRIdiCkczglJqVbvBjPhW
  uxAQrEnXtFRIdiCkczglJqVbvBjPNL=''
  try:
   uxAQrEnXtFRIdiCkczglJqVbvBjPNh ='/api/contents/'+program_code+'/tv_episodes.json'
   uxAQrEnXtFRIdiCkczglJqVbvBjPNO={'all':'true'}
   uxAQrEnXtFRIdiCkczglJqVbvBjPTf=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeurl(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.API_DOMAIN,uxAQrEnXtFRIdiCkczglJqVbvBjPNh)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTy=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeDefaultCookies()
   uxAQrEnXtFRIdiCkczglJqVbvBjPTe=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.callRequestCookies('Get',uxAQrEnXtFRIdiCkczglJqVbvBjPTf,payload=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,params=uxAQrEnXtFRIdiCkczglJqVbvBjPNO,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,cookies=uxAQrEnXtFRIdiCkczglJqVbvBjPTy)
   uxAQrEnXtFRIdiCkczglJqVbvBjPNp=json.loads(uxAQrEnXtFRIdiCkczglJqVbvBjPTe.text)
   if not('tv_episode_codes' in uxAQrEnXtFRIdiCkczglJqVbvBjPNp):return uxAQrEnXtFRIdiCkczglJqVbvBjPNW,uxAQrEnXtFRIdiCkczglJqVbvBjPNf
   uxAQrEnXtFRIdiCkczglJqVbvBjPNw=uxAQrEnXtFRIdiCkczglJqVbvBjPNp['tv_episode_codes']
   uxAQrEnXtFRIdiCkczglJqVbvBjPWT=uxAQrEnXtFRIdiCkczglJqVbvBjPhH(uxAQrEnXtFRIdiCkczglJqVbvBjPNw)
   uxAQrEnXtFRIdiCkczglJqVbvBjPWN =uxAQrEnXtFRIdiCkczglJqVbvBjPhY(uxAQrEnXtFRIdiCkczglJqVbvBjPWT//(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    uxAQrEnXtFRIdiCkczglJqVbvBjPWh =(uxAQrEnXtFRIdiCkczglJqVbvBjPWT-1)-((page_int-1)*uxAQrEnXtFRIdiCkczglJqVbvBjPTh.EPISODE_LIMIT)
   else:
    uxAQrEnXtFRIdiCkczglJqVbvBjPWh =(page_int-1)*uxAQrEnXtFRIdiCkczglJqVbvBjPTh.EPISODE_LIMIT
   for i in uxAQrEnXtFRIdiCkczglJqVbvBjPhK(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.EPISODE_LIMIT):
    if orderby=='desc':
     uxAQrEnXtFRIdiCkczglJqVbvBjPWp=uxAQrEnXtFRIdiCkczglJqVbvBjPWh-i
     if uxAQrEnXtFRIdiCkczglJqVbvBjPWp<0:break
    else:
     uxAQrEnXtFRIdiCkczglJqVbvBjPWp=uxAQrEnXtFRIdiCkczglJqVbvBjPWh+i
     if uxAQrEnXtFRIdiCkczglJqVbvBjPWp>=uxAQrEnXtFRIdiCkczglJqVbvBjPWT:break
    if uxAQrEnXtFRIdiCkczglJqVbvBjPNL!='':uxAQrEnXtFRIdiCkczglJqVbvBjPNL+=','
    uxAQrEnXtFRIdiCkczglJqVbvBjPNL+=uxAQrEnXtFRIdiCkczglJqVbvBjPNw[uxAQrEnXtFRIdiCkczglJqVbvBjPWp]
   if uxAQrEnXtFRIdiCkczglJqVbvBjPWN>page_int:uxAQrEnXtFRIdiCkczglJqVbvBjPNf=uxAQrEnXtFRIdiCkczglJqVbvBjPhp
  except uxAQrEnXtFRIdiCkczglJqVbvBjPhw as exception:
   uxAQrEnXtFRIdiCkczglJqVbvBjPha(exception)
  try:
   uxAQrEnXtFRIdiCkczglJqVbvBjPNO={'codes':uxAQrEnXtFRIdiCkczglJqVbvBjPNL}
   uxAQrEnXtFRIdiCkczglJqVbvBjPTf=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeurl(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.API_DOMAIN,uxAQrEnXtFRIdiCkczglJqVbvBjPNh)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTy=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeDefaultCookies()
   uxAQrEnXtFRIdiCkczglJqVbvBjPTe=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.callRequestCookies('Get',uxAQrEnXtFRIdiCkczglJqVbvBjPTf,payload=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,params=uxAQrEnXtFRIdiCkczglJqVbvBjPNO,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,cookies=uxAQrEnXtFRIdiCkczglJqVbvBjPTy)
   uxAQrEnXtFRIdiCkczglJqVbvBjPNp=json.loads(uxAQrEnXtFRIdiCkczglJqVbvBjPTe.text)
   if not('tv_episodes' in uxAQrEnXtFRIdiCkczglJqVbvBjPNp):return uxAQrEnXtFRIdiCkczglJqVbvBjPNW
   uxAQrEnXtFRIdiCkczglJqVbvBjPNw=uxAQrEnXtFRIdiCkczglJqVbvBjPNp['tv_episodes']
   for uxAQrEnXtFRIdiCkczglJqVbvBjPNa in uxAQrEnXtFRIdiCkczglJqVbvBjPNw:
    uxAQrEnXtFRIdiCkczglJqVbvBjPNS =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['code']
    if uxAQrEnXtFRIdiCkczglJqVbvBjPNa['title']:
     uxAQrEnXtFRIdiCkczglJqVbvBjPNG =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['title']
    else:
     uxAQrEnXtFRIdiCkczglJqVbvBjPNG =''
    uxAQrEnXtFRIdiCkczglJqVbvBjPNm =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['stillcut']['medium']
    uxAQrEnXtFRIdiCkczglJqVbvBjPWw =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['display_number']
    uxAQrEnXtFRIdiCkczglJqVbvBjPWa=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['tv_season_title']
    uxAQrEnXtFRIdiCkczglJqVbvBjPND={}
    uxAQrEnXtFRIdiCkczglJqVbvBjPND['mediatype'] ='episode'
    uxAQrEnXtFRIdiCkczglJqVbvBjPND['tvshowtitle']=uxAQrEnXtFRIdiCkczglJqVbvBjPNG if uxAQrEnXtFRIdiCkczglJqVbvBjPNG else uxAQrEnXtFRIdiCkczglJqVbvBjPWa
    uxAQrEnXtFRIdiCkczglJqVbvBjPND['title'] ='%s %s'%(uxAQrEnXtFRIdiCkczglJqVbvBjPWa,uxAQrEnXtFRIdiCkczglJqVbvBjPWw)if uxAQrEnXtFRIdiCkczglJqVbvBjPNG else uxAQrEnXtFRIdiCkczglJqVbvBjPWw
    uxAQrEnXtFRIdiCkczglJqVbvBjPND['duration'] =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['duration']
    try:
     uxAQrEnXtFRIdiCkczglJqVbvBjPND['episode']=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['episode_number']
    except:
     uxAQrEnXtFRIdiCkczglJqVbvBjPhN
    uxAQrEnXtFRIdiCkczglJqVbvBjPNK={'code':uxAQrEnXtFRIdiCkczglJqVbvBjPNS,'title':uxAQrEnXtFRIdiCkczglJqVbvBjPNG,'thumbnail':uxAQrEnXtFRIdiCkczglJqVbvBjPNm,'display_num':uxAQrEnXtFRIdiCkczglJqVbvBjPWw,'season_title':uxAQrEnXtFRIdiCkczglJqVbvBjPWa,'info':uxAQrEnXtFRIdiCkczglJqVbvBjPND}
    uxAQrEnXtFRIdiCkczglJqVbvBjPNW.append(uxAQrEnXtFRIdiCkczglJqVbvBjPNK)
  except uxAQrEnXtFRIdiCkczglJqVbvBjPhw as exception:
   uxAQrEnXtFRIdiCkczglJqVbvBjPha(exception)
  return uxAQrEnXtFRIdiCkczglJqVbvBjPNW,uxAQrEnXtFRIdiCkczglJqVbvBjPNf
 def GetSearchList(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,search_key,page_int):
  uxAQrEnXtFRIdiCkczglJqVbvBjPWo=[]
  uxAQrEnXtFRIdiCkczglJqVbvBjPNf=uxAQrEnXtFRIdiCkczglJqVbvBjPhW
  try:
   uxAQrEnXtFRIdiCkczglJqVbvBjPNh ='/api/search.json'
   uxAQrEnXtFRIdiCkczglJqVbvBjPNO={'query':search_key,'page':uxAQrEnXtFRIdiCkczglJqVbvBjPho(page_int),'per':uxAQrEnXtFRIdiCkczglJqVbvBjPho(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.SEARCH_LIMIT),'exclude':'limited'}
   uxAQrEnXtFRIdiCkczglJqVbvBjPTf=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeurl(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.API_DOMAIN,uxAQrEnXtFRIdiCkczglJqVbvBjPNh)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTy=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeDefaultCookies()
   uxAQrEnXtFRIdiCkczglJqVbvBjPTe=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.callRequestCookies('Get',uxAQrEnXtFRIdiCkczglJqVbvBjPTf,payload=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,params=uxAQrEnXtFRIdiCkczglJqVbvBjPNO,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,cookies=uxAQrEnXtFRIdiCkczglJqVbvBjPTy)
   uxAQrEnXtFRIdiCkczglJqVbvBjPNp=json.loads(uxAQrEnXtFRIdiCkczglJqVbvBjPTe.text)
   if not('results' in uxAQrEnXtFRIdiCkczglJqVbvBjPNp):return uxAQrEnXtFRIdiCkczglJqVbvBjPWo,uxAQrEnXtFRIdiCkczglJqVbvBjPNf
   uxAQrEnXtFRIdiCkczglJqVbvBjPNw=uxAQrEnXtFRIdiCkczglJqVbvBjPNp['results']
   uxAQrEnXtFRIdiCkczglJqVbvBjPNf=uxAQrEnXtFRIdiCkczglJqVbvBjPNp['meta']['has_next']
   for uxAQrEnXtFRIdiCkczglJqVbvBjPNa in uxAQrEnXtFRIdiCkczglJqVbvBjPNw:
    uxAQrEnXtFRIdiCkczglJqVbvBjPNS =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['code']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNs=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['content_type']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNG =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['title']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNM =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['story']
    if uxAQrEnXtFRIdiCkczglJqVbvBjPNa['thumbnail']!=uxAQrEnXtFRIdiCkczglJqVbvBjPhN:
     uxAQrEnXtFRIdiCkczglJqVbvBjPNm =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['thumbnail']['medium']
    else:
     uxAQrEnXtFRIdiCkczglJqVbvBjPNm =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['stillcut']['medium']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNU =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['year']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNe =uxAQrEnXtFRIdiCkczglJqVbvBjPNa['film_rating_code']
    uxAQrEnXtFRIdiCkczglJqVbvBjPNy=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['film_rating_short']
    uxAQrEnXtFRIdiCkczglJqVbvBjPND={}
    uxAQrEnXtFRIdiCkczglJqVbvBjPND['mpaa']=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['film_rating_long']
    uxAQrEnXtFRIdiCkczglJqVbvBjPND['year']=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['year']
    uxAQrEnXtFRIdiCkczglJqVbvBjPND['title']=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['title']
    if uxAQrEnXtFRIdiCkczglJqVbvBjPNs=='movies':
     uxAQrEnXtFRIdiCkczglJqVbvBjPND['mediatype']='movie' 
     uxAQrEnXtFRIdiCkczglJqVbvBjPND['duration']=uxAQrEnXtFRIdiCkczglJqVbvBjPNa['duration']
    else:
     uxAQrEnXtFRIdiCkczglJqVbvBjPND['mediatype']='episode' 
    uxAQrEnXtFRIdiCkczglJqVbvBjPNK={'code':uxAQrEnXtFRIdiCkczglJqVbvBjPNS,'content_type':uxAQrEnXtFRIdiCkczglJqVbvBjPNs,'title':uxAQrEnXtFRIdiCkczglJqVbvBjPNG,'story':uxAQrEnXtFRIdiCkczglJqVbvBjPNM,'thumbnail':uxAQrEnXtFRIdiCkczglJqVbvBjPNm,'year':uxAQrEnXtFRIdiCkczglJqVbvBjPNU,'film_rating_code':uxAQrEnXtFRIdiCkczglJqVbvBjPNe,'film_rating_short':uxAQrEnXtFRIdiCkczglJqVbvBjPNy,'info':uxAQrEnXtFRIdiCkczglJqVbvBjPND}
    uxAQrEnXtFRIdiCkczglJqVbvBjPWo.append(uxAQrEnXtFRIdiCkczglJqVbvBjPNK)
  except uxAQrEnXtFRIdiCkczglJqVbvBjPhw as exception:
   uxAQrEnXtFRIdiCkczglJqVbvBjPha(exception)
  return uxAQrEnXtFRIdiCkczglJqVbvBjPWo,uxAQrEnXtFRIdiCkczglJqVbvBjPNf
 def GetProfilesList(uxAQrEnXtFRIdiCkczglJqVbvBjPTh):
  uxAQrEnXtFRIdiCkczglJqVbvBjPTL=[]
  try:
   uxAQrEnXtFRIdiCkczglJqVbvBjPNh ='/manage_profiles'
   uxAQrEnXtFRIdiCkczglJqVbvBjPTf=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeurl(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.API_DOMAIN,uxAQrEnXtFRIdiCkczglJqVbvBjPNh)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTy=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeDefaultCookies()
   uxAQrEnXtFRIdiCkczglJqVbvBjPTe=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.callRequestCookies('Get',uxAQrEnXtFRIdiCkczglJqVbvBjPTf,payload=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,params=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,cookies=uxAQrEnXtFRIdiCkczglJqVbvBjPTy,redirects=uxAQrEnXtFRIdiCkczglJqVbvBjPhp)
   uxAQrEnXtFRIdiCkczglJqVbvBjPWH=uxAQrEnXtFRIdiCkczglJqVbvBjPTe.text
   uxAQrEnXtFRIdiCkczglJqVbvBjPWY =re.findall('/api/users/me.{5000}',uxAQrEnXtFRIdiCkczglJqVbvBjPWH)[0]
   uxAQrEnXtFRIdiCkczglJqVbvBjPWY =uxAQrEnXtFRIdiCkczglJqVbvBjPWY.replace('&quot;','')
   uxAQrEnXtFRIdiCkczglJqVbvBjPTL=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',uxAQrEnXtFRIdiCkczglJqVbvBjPWY)
   for i in uxAQrEnXtFRIdiCkczglJqVbvBjPhK(uxAQrEnXtFRIdiCkczglJqVbvBjPhH(uxAQrEnXtFRIdiCkczglJqVbvBjPTL)):
    uxAQrEnXtFRIdiCkczglJqVbvBjPWK=uxAQrEnXtFRIdiCkczglJqVbvBjPTL[i]
    uxAQrEnXtFRIdiCkczglJqVbvBjPWK =uxAQrEnXtFRIdiCkczglJqVbvBjPWK.split(':')[1]
    uxAQrEnXtFRIdiCkczglJqVbvBjPTL[i]=uxAQrEnXtFRIdiCkczglJqVbvBjPWK.split(',')[0]
  except uxAQrEnXtFRIdiCkczglJqVbvBjPhw as exception:
   uxAQrEnXtFRIdiCkczglJqVbvBjPha(exception)
  return uxAQrEnXtFRIdiCkczglJqVbvBjPTL
 def GetProfilesConvert(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,uxAQrEnXtFRIdiCkczglJqVbvBjPTo):
  uxAQrEnXtFRIdiCkczglJqVbvBjPWf=''
  uxAQrEnXtFRIdiCkczglJqVbvBjPWO=''
  try:
   uxAQrEnXtFRIdiCkczglJqVbvBjPNh ='/api/users/'+uxAQrEnXtFRIdiCkczglJqVbvBjPTo+'/convert'
   uxAQrEnXtFRIdiCkczglJqVbvBjPTf=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeurl(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.API_DOMAIN,uxAQrEnXtFRIdiCkczglJqVbvBjPNh)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTy=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeDefaultCookies()
   uxAQrEnXtFRIdiCkczglJqVbvBjPTe=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.callRequestCookies('Put',uxAQrEnXtFRIdiCkczglJqVbvBjPTf,payload=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,params=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,cookies=uxAQrEnXtFRIdiCkczglJqVbvBjPTy)
   for uxAQrEnXtFRIdiCkczglJqVbvBjPTy in uxAQrEnXtFRIdiCkczglJqVbvBjPTe.cookies:
    if uxAQrEnXtFRIdiCkczglJqVbvBjPTy.name=='_s_guitv':
     uxAQrEnXtFRIdiCkczglJqVbvBjPWS=uxAQrEnXtFRIdiCkczglJqVbvBjPTy.value
    elif uxAQrEnXtFRIdiCkczglJqVbvBjPTy.name=='_guinness-premium_session':
     uxAQrEnXtFRIdiCkczglJqVbvBjPTD=uxAQrEnXtFRIdiCkczglJqVbvBjPTy.value
   if uxAQrEnXtFRIdiCkczglJqVbvBjPWS:
    uxAQrEnXtFRIdiCkczglJqVbvBjPWf=uxAQrEnXtFRIdiCkczglJqVbvBjPWS
   if uxAQrEnXtFRIdiCkczglJqVbvBjPTD:
    uxAQrEnXtFRIdiCkczglJqVbvBjPWO=uxAQrEnXtFRIdiCkczglJqVbvBjPTD
  except uxAQrEnXtFRIdiCkczglJqVbvBjPhw as exception:
   uxAQrEnXtFRIdiCkczglJqVbvBjPWf=''
   uxAQrEnXtFRIdiCkczglJqVbvBjPWO=''
  return uxAQrEnXtFRIdiCkczglJqVbvBjPWf,uxAQrEnXtFRIdiCkczglJqVbvBjPWO
 def Get_Now_Datetime(uxAQrEnXtFRIdiCkczglJqVbvBjPTh):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(uxAQrEnXtFRIdiCkczglJqVbvBjPTh,movie_code,quality_str):
  uxAQrEnXtFRIdiCkczglJqVbvBjPWG=uxAQrEnXtFRIdiCkczglJqVbvBjPWm=uxAQrEnXtFRIdiCkczglJqVbvBjPWL=''
  try:
   uxAQrEnXtFRIdiCkczglJqVbvBjPNh='/api/watch/'+movie_code+'.json'
   uxAQrEnXtFRIdiCkczglJqVbvBjPTf=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeurl(uxAQrEnXtFRIdiCkczglJqVbvBjPTh.API_DOMAIN,uxAQrEnXtFRIdiCkczglJqVbvBjPNh)
   uxAQrEnXtFRIdiCkczglJqVbvBjPTU={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   uxAQrEnXtFRIdiCkczglJqVbvBjPTy=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.makeDefaultCookies()
   uxAQrEnXtFRIdiCkczglJqVbvBjPTe=uxAQrEnXtFRIdiCkczglJqVbvBjPTh.callRequestCookies('Get',uxAQrEnXtFRIdiCkczglJqVbvBjPTf,payload=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,params=uxAQrEnXtFRIdiCkczglJqVbvBjPhN,headers=uxAQrEnXtFRIdiCkczglJqVbvBjPTU,cookies=uxAQrEnXtFRIdiCkczglJqVbvBjPTy)
   uxAQrEnXtFRIdiCkczglJqVbvBjPNp=json.loads(uxAQrEnXtFRIdiCkczglJqVbvBjPTe.text)
   uxAQrEnXtFRIdiCkczglJqVbvBjPWG=uxAQrEnXtFRIdiCkczglJqVbvBjPNp['streams'][0]['source']
   if uxAQrEnXtFRIdiCkczglJqVbvBjPWG==uxAQrEnXtFRIdiCkczglJqVbvBjPhN:return(uxAQrEnXtFRIdiCkczglJqVbvBjPWG,uxAQrEnXtFRIdiCkczglJqVbvBjPWm,uxAQrEnXtFRIdiCkczglJqVbvBjPWL)
   if 'subtitles' in uxAQrEnXtFRIdiCkczglJqVbvBjPNp['streams'][0]:
    for uxAQrEnXtFRIdiCkczglJqVbvBjPWM in uxAQrEnXtFRIdiCkczglJqVbvBjPNp['streams'][0]['subtitles']:
     if uxAQrEnXtFRIdiCkczglJqVbvBjPWM['lang']=='ko':
      uxAQrEnXtFRIdiCkczglJqVbvBjPWm=uxAQrEnXtFRIdiCkczglJqVbvBjPWM['url']
      break
   uxAQrEnXtFRIdiCkczglJqVbvBjPWU =uxAQrEnXtFRIdiCkczglJqVbvBjPNp['ping_payload']
   uxAQrEnXtFRIdiCkczglJqVbvBjPWe =uxAQrEnXtFRIdiCkczglJqVbvBjPTh.WATCHA_USERCD
   uxAQrEnXtFRIdiCkczglJqVbvBjPWy={'merchant':'giitd_frograms','sessionId':uxAQrEnXtFRIdiCkczglJqVbvBjPWU,'userId':uxAQrEnXtFRIdiCkczglJqVbvBjPWe}
   uxAQrEnXtFRIdiCkczglJqVbvBjPWD=json.dumps(uxAQrEnXtFRIdiCkczglJqVbvBjPWy,separators=(",",":")).encode('UTF-8')
   uxAQrEnXtFRIdiCkczglJqVbvBjPWL=base64.b64encode(uxAQrEnXtFRIdiCkczglJqVbvBjPWD)
  except uxAQrEnXtFRIdiCkczglJqVbvBjPhw as exception:
   return(uxAQrEnXtFRIdiCkczglJqVbvBjPWG,uxAQrEnXtFRIdiCkczglJqVbvBjPWm,uxAQrEnXtFRIdiCkczglJqVbvBjPWL)
  return(uxAQrEnXtFRIdiCkczglJqVbvBjPWG,uxAQrEnXtFRIdiCkczglJqVbvBjPWm,uxAQrEnXtFRIdiCkczglJqVbvBjPWL) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
