__author__="NightRain"
GTHqBmQMURhEtjyAwIrevLKXzklWus=object
GTHqBmQMURhEtjyAwIrevLKXzklWuf=None
GTHqBmQMURhEtjyAwIrevLKXzklWua=int
GTHqBmQMURhEtjyAwIrevLKXzklWDF=False
GTHqBmQMURhEtjyAwIrevLKXzklWDC=True
GTHqBmQMURhEtjyAwIrevLKXzklWDi=len
GTHqBmQMURhEtjyAwIrevLKXzklWDS=range
GTHqBmQMURhEtjyAwIrevLKXzklWDu=str
GTHqBmQMURhEtjyAwIrevLKXzklWDg=open
GTHqBmQMURhEtjyAwIrevLKXzklWDP=dict
GTHqBmQMURhEtjyAwIrevLKXzklWDN=Exception
GTHqBmQMURhEtjyAwIrevLKXzklWDb=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
GTHqBmQMURhEtjyAwIrevLKXzklWFi=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'검색 (search)','mode':'SEARCH','stype':'-','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-'}]
GTHqBmQMURhEtjyAwIrevLKXzklWFS=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
GTHqBmQMURhEtjyAwIrevLKXzklWFu=40
GTHqBmQMURhEtjyAwIrevLKXzklWFD =20
GTHqBmQMURhEtjyAwIrevLKXzklWFg='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
GTHqBmQMURhEtjyAwIrevLKXzklWFP =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
GTHqBmQMURhEtjyAwIrevLKXzklWFN=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class GTHqBmQMURhEtjyAwIrevLKXzklWFC(GTHqBmQMURhEtjyAwIrevLKXzklWus):
 def __init__(GTHqBmQMURhEtjyAwIrevLKXzklWFb,GTHqBmQMURhEtjyAwIrevLKXzklWFx,GTHqBmQMURhEtjyAwIrevLKXzklWFV,GTHqBmQMURhEtjyAwIrevLKXzklWFp):
  GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_url =GTHqBmQMURhEtjyAwIrevLKXzklWFx
  GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_handle=GTHqBmQMURhEtjyAwIrevLKXzklWFV
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.main_params =GTHqBmQMURhEtjyAwIrevLKXzklWFp
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj =uxAQrEnXtFRIdiCkczglJqVbvBjPTN() 
 def addon_noti(GTHqBmQMURhEtjyAwIrevLKXzklWFb,sting):
  try:
   GTHqBmQMURhEtjyAwIrevLKXzklWFJ=xbmcgui.Dialog()
   GTHqBmQMURhEtjyAwIrevLKXzklWFJ.notification(__addonname__,sting)
  except:
   GTHqBmQMURhEtjyAwIrevLKXzklWuf
 def addon_log(GTHqBmQMURhEtjyAwIrevLKXzklWFb,string):
  try:
   GTHqBmQMURhEtjyAwIrevLKXzklWFo=string.encode('utf-8','ignore')
  except:
   GTHqBmQMURhEtjyAwIrevLKXzklWFo='addonException: addon_log'
  GTHqBmQMURhEtjyAwIrevLKXzklWFY=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,GTHqBmQMURhEtjyAwIrevLKXzklWFo),level=GTHqBmQMURhEtjyAwIrevLKXzklWFY)
 def get_keyboard_input(GTHqBmQMURhEtjyAwIrevLKXzklWFb,GTHqBmQMURhEtjyAwIrevLKXzklWCg):
  GTHqBmQMURhEtjyAwIrevLKXzklWFc=GTHqBmQMURhEtjyAwIrevLKXzklWuf
  kb=xbmc.Keyboard()
  kb.setHeading(GTHqBmQMURhEtjyAwIrevLKXzklWCg)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   GTHqBmQMURhEtjyAwIrevLKXzklWFc=kb.getText()
  return GTHqBmQMURhEtjyAwIrevLKXzklWFc
 def get_settings_login_info(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  GTHqBmQMURhEtjyAwIrevLKXzklWFO =__addon__.getSetting('id')
  GTHqBmQMURhEtjyAwIrevLKXzklWFd =__addon__.getSetting('pw')
  GTHqBmQMURhEtjyAwIrevLKXzklWFs=GTHqBmQMURhEtjyAwIrevLKXzklWua(__addon__.getSetting('selected_profile'))
  return(GTHqBmQMURhEtjyAwIrevLKXzklWFO,GTHqBmQMURhEtjyAwIrevLKXzklWFd,GTHqBmQMURhEtjyAwIrevLKXzklWFs)
 def get_selQuality(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  try:
   GTHqBmQMURhEtjyAwIrevLKXzklWFf=['3840x2160/1','1920x1080/1','1280x720/1']
   GTHqBmQMURhEtjyAwIrevLKXzklWFa=GTHqBmQMURhEtjyAwIrevLKXzklWua(__addon__.getSetting('selected_quality'))
   return GTHqBmQMURhEtjyAwIrevLKXzklWFf[GTHqBmQMURhEtjyAwIrevLKXzklWFa]
  except:
   GTHqBmQMURhEtjyAwIrevLKXzklWuf
  return 1080 
 def get_settings_direct_replay(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  GTHqBmQMURhEtjyAwIrevLKXzklWCF=GTHqBmQMURhEtjyAwIrevLKXzklWua(__addon__.getSetting('direct_replay'))
  if GTHqBmQMURhEtjyAwIrevLKXzklWCF==0:
   return GTHqBmQMURhEtjyAwIrevLKXzklWDF
  else:
   return GTHqBmQMURhEtjyAwIrevLKXzklWDC
 def set_winCredential(GTHqBmQMURhEtjyAwIrevLKXzklWFb,credential):
  GTHqBmQMURhEtjyAwIrevLKXzklWCi=xbmcgui.Window(10000)
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_LOGINTIME',GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  GTHqBmQMURhEtjyAwIrevLKXzklWCi=xbmcgui.Window(10000)
  GTHqBmQMURhEtjyAwIrevLKXzklWCS={'watcha_token':GTHqBmQMURhEtjyAwIrevLKXzklWCi.getProperty('WATCHA_M_TOKEN'),'watcha_guit':GTHqBmQMURhEtjyAwIrevLKXzklWCi.getProperty('WATCHA_M_GUIT'),'watcha_guitv':GTHqBmQMURhEtjyAwIrevLKXzklWCi.getProperty('WATCHA_M_GUITV'),'watcha_usercd':GTHqBmQMURhEtjyAwIrevLKXzklWCi.getProperty('WATCHA_M_USERCD')}
  return GTHqBmQMURhEtjyAwIrevLKXzklWCS
 def set_winEpisodeOrderby(GTHqBmQMURhEtjyAwIrevLKXzklWFb,GTHqBmQMURhEtjyAwIrevLKXzklWCu):
  GTHqBmQMURhEtjyAwIrevLKXzklWCi=xbmcgui.Window(10000)
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_ORDERBY',GTHqBmQMURhEtjyAwIrevLKXzklWCu)
 def get_winEpisodeOrderby(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  GTHqBmQMURhEtjyAwIrevLKXzklWCi=xbmcgui.Window(10000)
  return GTHqBmQMURhEtjyAwIrevLKXzklWCi.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(GTHqBmQMURhEtjyAwIrevLKXzklWFb,args):
  GTHqBmQMURhEtjyAwIrevLKXzklWCu =args.get('orderby')
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.set_winEpisodeOrderby(GTHqBmQMURhEtjyAwIrevLKXzklWCu)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWFb,label,sublabel='',img='',infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWuf,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWDC,params=''):
  GTHqBmQMURhEtjyAwIrevLKXzklWCD='%s?%s'%(GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_url,urllib.parse.urlencode(params))
  if sublabel:GTHqBmQMURhEtjyAwIrevLKXzklWCg='%s < %s >'%(label,sublabel)
  else: GTHqBmQMURhEtjyAwIrevLKXzklWCg=label
  if not img:img='DefaultFolder.png'
  GTHqBmQMURhEtjyAwIrevLKXzklWCP=xbmcgui.ListItem(GTHqBmQMURhEtjyAwIrevLKXzklWCg)
  GTHqBmQMURhEtjyAwIrevLKXzklWCP.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:GTHqBmQMURhEtjyAwIrevLKXzklWCP.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:GTHqBmQMURhEtjyAwIrevLKXzklWCP.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_handle,GTHqBmQMURhEtjyAwIrevLKXzklWCD,GTHqBmQMURhEtjyAwIrevLKXzklWCP,isFolder)
 def dp_Main_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  for GTHqBmQMURhEtjyAwIrevLKXzklWCN in GTHqBmQMURhEtjyAwIrevLKXzklWFi:
   GTHqBmQMURhEtjyAwIrevLKXzklWCg=GTHqBmQMURhEtjyAwIrevLKXzklWCN.get('title')
   GTHqBmQMURhEtjyAwIrevLKXzklWCb={'mode':GTHqBmQMURhEtjyAwIrevLKXzklWCN.get('mode'),'stype':GTHqBmQMURhEtjyAwIrevLKXzklWCN.get('stype'),'api_path':GTHqBmQMURhEtjyAwIrevLKXzklWCN.get('api_path'),'page':'1','sort':GTHqBmQMURhEtjyAwIrevLKXzklWCN.get('sort'),'tag_id':'-'}
   if GTHqBmQMURhEtjyAwIrevLKXzklWCN.get('mode')=='XXX':
    GTHqBmQMURhEtjyAwIrevLKXzklWCb['mode']='XXX'
    GTHqBmQMURhEtjyAwIrevLKXzklWCx=GTHqBmQMURhEtjyAwIrevLKXzklWDF
   else:
    GTHqBmQMURhEtjyAwIrevLKXzklWCx=GTHqBmQMURhEtjyAwIrevLKXzklWDC
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel='',img='',infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWuf,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWCx,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
  if GTHqBmQMURhEtjyAwIrevLKXzklWDi(GTHqBmQMURhEtjyAwIrevLKXzklWFi)>0:xbmcplugin.endOfDirectory(GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_handle)
 def login_main(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  (GTHqBmQMURhEtjyAwIrevLKXzklWCp,GTHqBmQMURhEtjyAwIrevLKXzklWCn,GTHqBmQMURhEtjyAwIrevLKXzklWCJ)=GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_settings_login_info()
  if not(GTHqBmQMURhEtjyAwIrevLKXzklWCp and GTHqBmQMURhEtjyAwIrevLKXzklWCn):
   GTHqBmQMURhEtjyAwIrevLKXzklWFJ=xbmcgui.Dialog()
   GTHqBmQMURhEtjyAwIrevLKXzklWCo=GTHqBmQMURhEtjyAwIrevLKXzklWFJ.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if GTHqBmQMURhEtjyAwIrevLKXzklWCo==GTHqBmQMURhEtjyAwIrevLKXzklWDC:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_winEpisodeOrderby()=='':
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.set_winEpisodeOrderby('asc')
  if GTHqBmQMURhEtjyAwIrevLKXzklWFb.cookiefile_check():return
  GTHqBmQMURhEtjyAwIrevLKXzklWCY =GTHqBmQMURhEtjyAwIrevLKXzklWua(GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  GTHqBmQMURhEtjyAwIrevLKXzklWCc=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if GTHqBmQMURhEtjyAwIrevLKXzklWCc==GTHqBmQMURhEtjyAwIrevLKXzklWuf or GTHqBmQMURhEtjyAwIrevLKXzklWCc=='':
   GTHqBmQMURhEtjyAwIrevLKXzklWCc=GTHqBmQMURhEtjyAwIrevLKXzklWua('19000101')
  else:
   GTHqBmQMURhEtjyAwIrevLKXzklWCc=GTHqBmQMURhEtjyAwIrevLKXzklWua(re.sub('-','',GTHqBmQMURhEtjyAwIrevLKXzklWCc))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   GTHqBmQMURhEtjyAwIrevLKXzklWCO=0
   while GTHqBmQMURhEtjyAwIrevLKXzklWDC:
    GTHqBmQMURhEtjyAwIrevLKXzklWCO+=1
    time.sleep(0.05)
    if GTHqBmQMURhEtjyAwIrevLKXzklWCc>=GTHqBmQMURhEtjyAwIrevLKXzklWCY:return
    if GTHqBmQMURhEtjyAwIrevLKXzklWCO>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if GTHqBmQMURhEtjyAwIrevLKXzklWCc>=GTHqBmQMURhEtjyAwIrevLKXzklWCY:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.GetCredential(GTHqBmQMURhEtjyAwIrevLKXzklWCp,GTHqBmQMURhEtjyAwIrevLKXzklWCn,GTHqBmQMURhEtjyAwIrevLKXzklWCJ):
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.set_winCredential(GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.LoadCredential())
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb,args):
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.SaveCredential(GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_winCredential())
  GTHqBmQMURhEtjyAwIrevLKXzklWCd =args.get('stype')
  GTHqBmQMURhEtjyAwIrevLKXzklWCs =GTHqBmQMURhEtjyAwIrevLKXzklWua(args.get('page'))
  GTHqBmQMURhEtjyAwIrevLKXzklWCf =args.get('sort')
  GTHqBmQMURhEtjyAwIrevLKXzklWCa=GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.GetSubGroupList(GTHqBmQMURhEtjyAwIrevLKXzklWCd)
  GTHqBmQMURhEtjyAwIrevLKXzklWiF=GTHqBmQMURhEtjyAwIrevLKXzklWFu if GTHqBmQMURhEtjyAwIrevLKXzklWCd=='genres' else GTHqBmQMURhEtjyAwIrevLKXzklWFD
  GTHqBmQMURhEtjyAwIrevLKXzklWiC=GTHqBmQMURhEtjyAwIrevLKXzklWDi(GTHqBmQMURhEtjyAwIrevLKXzklWCa)
  GTHqBmQMURhEtjyAwIrevLKXzklWiS =GTHqBmQMURhEtjyAwIrevLKXzklWua(GTHqBmQMURhEtjyAwIrevLKXzklWiC//(GTHqBmQMURhEtjyAwIrevLKXzklWiF+1))+1
  GTHqBmQMURhEtjyAwIrevLKXzklWiu =(GTHqBmQMURhEtjyAwIrevLKXzklWCs-1)*GTHqBmQMURhEtjyAwIrevLKXzklWiF
  for i in GTHqBmQMURhEtjyAwIrevLKXzklWDS(GTHqBmQMURhEtjyAwIrevLKXzklWiF):
   GTHqBmQMURhEtjyAwIrevLKXzklWiD=GTHqBmQMURhEtjyAwIrevLKXzklWiu+i
   if GTHqBmQMURhEtjyAwIrevLKXzklWiD>=GTHqBmQMURhEtjyAwIrevLKXzklWiC:break
   GTHqBmQMURhEtjyAwIrevLKXzklWCg =GTHqBmQMURhEtjyAwIrevLKXzklWCa[GTHqBmQMURhEtjyAwIrevLKXzklWiD].get('group_name')
   GTHqBmQMURhEtjyAwIrevLKXzklWig =GTHqBmQMURhEtjyAwIrevLKXzklWCa[GTHqBmQMURhEtjyAwIrevLKXzklWiD].get('api_path')
   GTHqBmQMURhEtjyAwIrevLKXzklWiP =GTHqBmQMURhEtjyAwIrevLKXzklWCa[GTHqBmQMURhEtjyAwIrevLKXzklWiD].get('tag_id')
   GTHqBmQMURhEtjyAwIrevLKXzklWCb={'mode':'CATEGORY_LIST','api_path':GTHqBmQMURhEtjyAwIrevLKXzklWig,'tag_id':GTHqBmQMURhEtjyAwIrevLKXzklWiP,'stype':GTHqBmQMURhEtjyAwIrevLKXzklWCd,'page':'1','sort':GTHqBmQMURhEtjyAwIrevLKXzklWCf}
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel='',img='',infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWuf,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWDC,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
  if GTHqBmQMURhEtjyAwIrevLKXzklWiS>GTHqBmQMURhEtjyAwIrevLKXzklWCs:
   GTHqBmQMURhEtjyAwIrevLKXzklWCb={}
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['mode'] ='SUB_GROUP' 
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['stype'] =GTHqBmQMURhEtjyAwIrevLKXzklWCd
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['api_path']=args.get('api_path')
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['page'] =GTHqBmQMURhEtjyAwIrevLKXzklWDu(GTHqBmQMURhEtjyAwIrevLKXzklWCs+1)
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['sort'] =GTHqBmQMURhEtjyAwIrevLKXzklWCf
   GTHqBmQMURhEtjyAwIrevLKXzklWCg='[B]%s >>[/B]'%'다음 페이지'
   GTHqBmQMURhEtjyAwIrevLKXzklWiN=GTHqBmQMURhEtjyAwIrevLKXzklWDu(GTHqBmQMURhEtjyAwIrevLKXzklWCs+1)
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel=GTHqBmQMURhEtjyAwIrevLKXzklWiN,img='',infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWuf,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWDC,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
  if GTHqBmQMURhEtjyAwIrevLKXzklWDi(GTHqBmQMURhEtjyAwIrevLKXzklWCa)>0:xbmcplugin.endOfDirectory(GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_handle,cacheToDisc=GTHqBmQMURhEtjyAwIrevLKXzklWDC)
 def play_VIDEO(GTHqBmQMURhEtjyAwIrevLKXzklWFb,args):
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.SaveCredential(GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_winCredential())
  GTHqBmQMURhEtjyAwIrevLKXzklWib =args.get('movie_code')
  GTHqBmQMURhEtjyAwIrevLKXzklWix =args.get('season_code')
  GTHqBmQMURhEtjyAwIrevLKXzklWCg =args.get('title')
  GTHqBmQMURhEtjyAwIrevLKXzklWiV =args.get('thumbnail')
  GTHqBmQMURhEtjyAwIrevLKXzklWip =GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_selQuality()
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.addon_log(GTHqBmQMURhEtjyAwIrevLKXzklWib+' - '+GTHqBmQMURhEtjyAwIrevLKXzklWix)
  GTHqBmQMURhEtjyAwIrevLKXzklWin,GTHqBmQMURhEtjyAwIrevLKXzklWiJ,GTHqBmQMURhEtjyAwIrevLKXzklWio=GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.GetStreamingURL(GTHqBmQMURhEtjyAwIrevLKXzklWib,GTHqBmQMURhEtjyAwIrevLKXzklWip)
  if GTHqBmQMURhEtjyAwIrevLKXzklWin=='':
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.addon_noti(__language__(30908).encode('utf8'))
   return
  GTHqBmQMURhEtjyAwIrevLKXzklWiY=GTHqBmQMURhEtjyAwIrevLKXzklWin
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.addon_log(GTHqBmQMURhEtjyAwIrevLKXzklWiY)
  GTHqBmQMURhEtjyAwIrevLKXzklWic=xbmcgui.ListItem(path=GTHqBmQMURhEtjyAwIrevLKXzklWiY)
  if GTHqBmQMURhEtjyAwIrevLKXzklWio:
   GTHqBmQMURhEtjyAwIrevLKXzklWiO=GTHqBmQMURhEtjyAwIrevLKXzklWio
   GTHqBmQMURhEtjyAwIrevLKXzklWid ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   GTHqBmQMURhEtjyAwIrevLKXzklWis ='mpd'
   GTHqBmQMURhEtjyAwIrevLKXzklWif ='com.widevine.alpha'
   GTHqBmQMURhEtjyAwIrevLKXzklWia =inputstreamhelper.Helper(GTHqBmQMURhEtjyAwIrevLKXzklWis,drm=GTHqBmQMURhEtjyAwIrevLKXzklWif)
   if GTHqBmQMURhEtjyAwIrevLKXzklWia.check_inputstream():
    GTHqBmQMURhEtjyAwIrevLKXzklWSF={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+GTHqBmQMURhEtjyAwIrevLKXzklWib,'dt-custom-data':GTHqBmQMURhEtjyAwIrevLKXzklWiO,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':GTHqBmQMURhEtjyAwIrevLKXzklWFg,'Content-Type':'application/octet-stream'}
    GTHqBmQMURhEtjyAwIrevLKXzklWSC=GTHqBmQMURhEtjyAwIrevLKXzklWid+'|'+urllib.parse.urlencode(GTHqBmQMURhEtjyAwIrevLKXzklWSF)+'|R{SSM}|'
    GTHqBmQMURhEtjyAwIrevLKXzklWFb.addon_log(GTHqBmQMURhEtjyAwIrevLKXzklWSC)
    GTHqBmQMURhEtjyAwIrevLKXzklWic.setProperty('inputstream',GTHqBmQMURhEtjyAwIrevLKXzklWia.inputstream_addon)
    GTHqBmQMURhEtjyAwIrevLKXzklWic.setProperty('inputstream.adaptive.manifest_type',GTHqBmQMURhEtjyAwIrevLKXzklWis)
    GTHqBmQMURhEtjyAwIrevLKXzklWic.setProperty('inputstream.adaptive.license_type',GTHqBmQMURhEtjyAwIrevLKXzklWif)
    GTHqBmQMURhEtjyAwIrevLKXzklWic.setProperty('inputstream.adaptive.license_key',GTHqBmQMURhEtjyAwIrevLKXzklWSC)
    GTHqBmQMURhEtjyAwIrevLKXzklWic.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(GTHqBmQMURhEtjyAwIrevLKXzklWFg))
  if GTHqBmQMURhEtjyAwIrevLKXzklWiJ:
   try:
    f=GTHqBmQMURhEtjyAwIrevLKXzklWDg(GTHqBmQMURhEtjyAwIrevLKXzklWFP,'w',-1,'utf-8')
    GTHqBmQMURhEtjyAwIrevLKXzklWSi=requests.get(GTHqBmQMURhEtjyAwIrevLKXzklWiJ)
    GTHqBmQMURhEtjyAwIrevLKXzklWSu=GTHqBmQMURhEtjyAwIrevLKXzklWSi.content.decode('utf-8') 
    for GTHqBmQMURhEtjyAwIrevLKXzklWSD in GTHqBmQMURhEtjyAwIrevLKXzklWSu.splitlines():
     GTHqBmQMURhEtjyAwIrevLKXzklWSg=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',GTHqBmQMURhEtjyAwIrevLKXzklWSD)
     f.write(GTHqBmQMURhEtjyAwIrevLKXzklWSg+'\n')
    f.close()
    GTHqBmQMURhEtjyAwIrevLKXzklWic.setSubtitles([GTHqBmQMURhEtjyAwIrevLKXzklWFP,GTHqBmQMURhEtjyAwIrevLKXzklWiJ])
   except:
    GTHqBmQMURhEtjyAwIrevLKXzklWic.setSubtitles([GTHqBmQMURhEtjyAwIrevLKXzklWiJ])
  xbmcplugin.setResolvedUrl(GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_handle,GTHqBmQMURhEtjyAwIrevLKXzklWDC,GTHqBmQMURhEtjyAwIrevLKXzklWic)
  try:
   GTHqBmQMURhEtjyAwIrevLKXzklWCd='movie' if GTHqBmQMURhEtjyAwIrevLKXzklWix=='-' else 'seasons'
   GTHqBmQMURhEtjyAwIrevLKXzklWCb={'code':GTHqBmQMURhEtjyAwIrevLKXzklWib if GTHqBmQMURhEtjyAwIrevLKXzklWCd=='movie' else GTHqBmQMURhEtjyAwIrevLKXzklWix,'img':GTHqBmQMURhEtjyAwIrevLKXzklWiV,'title':GTHqBmQMURhEtjyAwIrevLKXzklWCg,'videoid':GTHqBmQMURhEtjyAwIrevLKXzklWib}
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.Save_Watched_List(GTHqBmQMURhEtjyAwIrevLKXzklWCd,GTHqBmQMURhEtjyAwIrevLKXzklWCb)
  except:
   GTHqBmQMURhEtjyAwIrevLKXzklWuf
 def dp_Category_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb,args):
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.SaveCredential(GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_winCredential())
  GTHqBmQMURhEtjyAwIrevLKXzklWCd =args.get('stype')
  GTHqBmQMURhEtjyAwIrevLKXzklWiP =args.get('tag_id')
  GTHqBmQMURhEtjyAwIrevLKXzklWig=args.get('api_path')
  GTHqBmQMURhEtjyAwIrevLKXzklWCs=GTHqBmQMURhEtjyAwIrevLKXzklWua(args.get('page'))
  GTHqBmQMURhEtjyAwIrevLKXzklWCf =args.get('sort')
  GTHqBmQMURhEtjyAwIrevLKXzklWSP,GTHqBmQMURhEtjyAwIrevLKXzklWSN=GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.GetCategoryList(GTHqBmQMURhEtjyAwIrevLKXzklWCd,GTHqBmQMURhEtjyAwIrevLKXzklWiP,GTHqBmQMURhEtjyAwIrevLKXzklWig,GTHqBmQMURhEtjyAwIrevLKXzklWCs,GTHqBmQMURhEtjyAwIrevLKXzklWCf)
  for GTHqBmQMURhEtjyAwIrevLKXzklWSb in GTHqBmQMURhEtjyAwIrevLKXzklWSP:
   GTHqBmQMURhEtjyAwIrevLKXzklWib =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('code')
   GTHqBmQMURhEtjyAwIrevLKXzklWCg =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('title')
   GTHqBmQMURhEtjyAwIrevLKXzklWSx =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('content_type')
   GTHqBmQMURhEtjyAwIrevLKXzklWSV =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('story')
   GTHqBmQMURhEtjyAwIrevLKXzklWiV =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('thumbnail')
   GTHqBmQMURhEtjyAwIrevLKXzklWSp =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('year')
   GTHqBmQMURhEtjyAwIrevLKXzklWSn =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('film_rating_code')
   GTHqBmQMURhEtjyAwIrevLKXzklWSJ=GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('film_rating_short')
   if GTHqBmQMURhEtjyAwIrevLKXzklWSx=='movies': 
    GTHqBmQMURhEtjyAwIrevLKXzklWCx=GTHqBmQMURhEtjyAwIrevLKXzklWDF
    GTHqBmQMURhEtjyAwIrevLKXzklWSo ='MOVIE'
    GTHqBmQMURhEtjyAwIrevLKXzklWCV=''
    GTHqBmQMURhEtjyAwIrevLKXzklWix='-'
   else: 
    GTHqBmQMURhEtjyAwIrevLKXzklWCx=GTHqBmQMURhEtjyAwIrevLKXzklWDC
    GTHqBmQMURhEtjyAwIrevLKXzklWSo ='EPISODE'
    GTHqBmQMURhEtjyAwIrevLKXzklWCV='Series'
    GTHqBmQMURhEtjyAwIrevLKXzklWix=GTHqBmQMURhEtjyAwIrevLKXzklWib
   GTHqBmQMURhEtjyAwIrevLKXzklWSY=GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('info')
   GTHqBmQMURhEtjyAwIrevLKXzklWSY['plot']='%s (%s)\n년도 : %s\n\n%s'%(GTHqBmQMURhEtjyAwIrevLKXzklWCg,GTHqBmQMURhEtjyAwIrevLKXzklWSJ,GTHqBmQMURhEtjyAwIrevLKXzklWSp,GTHqBmQMURhEtjyAwIrevLKXzklWSV)
   if GTHqBmQMURhEtjyAwIrevLKXzklWSn>=19:
    GTHqBmQMURhEtjyAwIrevLKXzklWCg+='  (%s년 - %s)'%(GTHqBmQMURhEtjyAwIrevLKXzklWSp,GTHqBmQMURhEtjyAwIrevLKXzklWDu(GTHqBmQMURhEtjyAwIrevLKXzklWSJ))
   else:
    GTHqBmQMURhEtjyAwIrevLKXzklWCg+='  (%s년)'%(GTHqBmQMURhEtjyAwIrevLKXzklWSp)
   GTHqBmQMURhEtjyAwIrevLKXzklWCb={'mode':GTHqBmQMURhEtjyAwIrevLKXzklWSo,'movie_code':GTHqBmQMURhEtjyAwIrevLKXzklWib,'page':'1','season_code':GTHqBmQMURhEtjyAwIrevLKXzklWix,'title':GTHqBmQMURhEtjyAwIrevLKXzklWCg,'thumbnail':GTHqBmQMURhEtjyAwIrevLKXzklWiV}
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel=GTHqBmQMURhEtjyAwIrevLKXzklWCV,img=GTHqBmQMURhEtjyAwIrevLKXzklWiV,infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWSY,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWCx,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
  if GTHqBmQMURhEtjyAwIrevLKXzklWSN:
   if GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.GetCategoryList_morepage(GTHqBmQMURhEtjyAwIrevLKXzklWCd,GTHqBmQMURhEtjyAwIrevLKXzklWiP,GTHqBmQMURhEtjyAwIrevLKXzklWig,GTHqBmQMURhEtjyAwIrevLKXzklWCs+1,GTHqBmQMURhEtjyAwIrevLKXzklWCf):
    GTHqBmQMURhEtjyAwIrevLKXzklWCb={}
    GTHqBmQMURhEtjyAwIrevLKXzklWCb['mode'] ='CATEGORY_LIST'
    GTHqBmQMURhEtjyAwIrevLKXzklWCb['stype'] =GTHqBmQMURhEtjyAwIrevLKXzklWCd
    GTHqBmQMURhEtjyAwIrevLKXzklWCb['tag_id'] =GTHqBmQMURhEtjyAwIrevLKXzklWiP
    GTHqBmQMURhEtjyAwIrevLKXzklWCb['api_path']=GTHqBmQMURhEtjyAwIrevLKXzklWig
    GTHqBmQMURhEtjyAwIrevLKXzklWCb['page'] =GTHqBmQMURhEtjyAwIrevLKXzklWDu(GTHqBmQMURhEtjyAwIrevLKXzklWCs+1)
    GTHqBmQMURhEtjyAwIrevLKXzklWCb['sort'] =GTHqBmQMURhEtjyAwIrevLKXzklWCf
    GTHqBmQMURhEtjyAwIrevLKXzklWCg='[B]%s >>[/B]'%'다음 페이지'
    GTHqBmQMURhEtjyAwIrevLKXzklWiN=GTHqBmQMURhEtjyAwIrevLKXzklWDu(GTHqBmQMURhEtjyAwIrevLKXzklWCs+1)
    GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel=GTHqBmQMURhEtjyAwIrevLKXzklWiN,img='',infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWuf,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWDC,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
  if GTHqBmQMURhEtjyAwIrevLKXzklWDi(GTHqBmQMURhEtjyAwIrevLKXzklWSP)>0:
   if GTHqBmQMURhEtjyAwIrevLKXzklWig=='arrivals/latest':
    xbmcplugin.endOfDirectory(GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_handle,cacheToDisc=GTHqBmQMURhEtjyAwIrevLKXzklWDC)
   else:
    xbmcplugin.endOfDirectory(GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_handle,cacheToDisc=GTHqBmQMURhEtjyAwIrevLKXzklWDF)
 def dp_Episode_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb,args):
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.SaveCredential(GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_winCredential())
  GTHqBmQMURhEtjyAwIrevLKXzklWSO=args.get('movie_code')
  GTHqBmQMURhEtjyAwIrevLKXzklWCs =GTHqBmQMURhEtjyAwIrevLKXzklWua(args.get('page'))
  GTHqBmQMURhEtjyAwIrevLKXzklWix =args.get('season_code')
  GTHqBmQMURhEtjyAwIrevLKXzklWSP,GTHqBmQMURhEtjyAwIrevLKXzklWSN=GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.GetEpisodoList(GTHqBmQMURhEtjyAwIrevLKXzklWSO,GTHqBmQMURhEtjyAwIrevLKXzklWCs,orderby=GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_winEpisodeOrderby())
  for GTHqBmQMURhEtjyAwIrevLKXzklWSb in GTHqBmQMURhEtjyAwIrevLKXzklWSP:
   GTHqBmQMURhEtjyAwIrevLKXzklWib =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('code')
   GTHqBmQMURhEtjyAwIrevLKXzklWCg =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('title')
   GTHqBmQMURhEtjyAwIrevLKXzklWiV =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('thumbnail')
   GTHqBmQMURhEtjyAwIrevLKXzklWSd =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('display_num')
   GTHqBmQMURhEtjyAwIrevLKXzklWSs=GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('season_title')
   GTHqBmQMURhEtjyAwIrevLKXzklWSY=GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('info')
   GTHqBmQMURhEtjyAwIrevLKXzklWSY['plot']='%s\n%s\n\n%s'%(GTHqBmQMURhEtjyAwIrevLKXzklWSs,GTHqBmQMURhEtjyAwIrevLKXzklWSd,GTHqBmQMURhEtjyAwIrevLKXzklWCg)
   GTHqBmQMURhEtjyAwIrevLKXzklWCg='(%s) %s'%(GTHqBmQMURhEtjyAwIrevLKXzklWSd,GTHqBmQMURhEtjyAwIrevLKXzklWCg)
   GTHqBmQMURhEtjyAwIrevLKXzklWCb={'mode':'MOVIE','movie_code':GTHqBmQMURhEtjyAwIrevLKXzklWib,'season_code':GTHqBmQMURhEtjyAwIrevLKXzklWix,'title':'%s < %s >'%(GTHqBmQMURhEtjyAwIrevLKXzklWCg,GTHqBmQMURhEtjyAwIrevLKXzklWSs),'thumbnail':GTHqBmQMURhEtjyAwIrevLKXzklWiV}
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel=GTHqBmQMURhEtjyAwIrevLKXzklWSs,img=GTHqBmQMURhEtjyAwIrevLKXzklWiV,infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWSY,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWDF,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
  if GTHqBmQMURhEtjyAwIrevLKXzklWCs==1:
   GTHqBmQMURhEtjyAwIrevLKXzklWSY={'plot':'정렬순서를 변경합니다.'}
   GTHqBmQMURhEtjyAwIrevLKXzklWCb={}
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['mode'] ='ORDER_BY' 
   if GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_winEpisodeOrderby()=='desc':
    GTHqBmQMURhEtjyAwIrevLKXzklWCg='정렬순서변경 : 최신화부터 -> 1회부터'
    GTHqBmQMURhEtjyAwIrevLKXzklWCb['orderby']='asc'
   else:
    GTHqBmQMURhEtjyAwIrevLKXzklWCg='정렬순서변경 : 1회부터 -> 최신화부터'
    GTHqBmQMURhEtjyAwIrevLKXzklWCb['orderby']='desc'
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel='',img='',infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWSY,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWDF,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
  if GTHqBmQMURhEtjyAwIrevLKXzklWSN:
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['mode'] ='EPISODE' 
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['movie_code']=GTHqBmQMURhEtjyAwIrevLKXzklWSO
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['page'] =GTHqBmQMURhEtjyAwIrevLKXzklWDu(GTHqBmQMURhEtjyAwIrevLKXzklWCs+1)
   GTHqBmQMURhEtjyAwIrevLKXzklWCg='[B]%s >>[/B]'%'다음 페이지'
   GTHqBmQMURhEtjyAwIrevLKXzklWiN=GTHqBmQMURhEtjyAwIrevLKXzklWDu(GTHqBmQMURhEtjyAwIrevLKXzklWCs+1)
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel=GTHqBmQMURhEtjyAwIrevLKXzklWiN,img='',infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWuf,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWDC,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
  if GTHqBmQMURhEtjyAwIrevLKXzklWDi(GTHqBmQMURhEtjyAwIrevLKXzklWSP)>0:xbmcplugin.endOfDirectory(GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_handle,cacheToDisc=GTHqBmQMURhEtjyAwIrevLKXzklWDC)
 def dp_Search_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb,args):
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.SaveCredential(GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_winCredential())
  GTHqBmQMURhEtjyAwIrevLKXzklWCs =GTHqBmQMURhEtjyAwIrevLKXzklWua(args.get('page'))
  if 'search_key' in args:
   GTHqBmQMURhEtjyAwIrevLKXzklWSf=args.get('search_key')
  else:
   GTHqBmQMURhEtjyAwIrevLKXzklWSf=GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not GTHqBmQMURhEtjyAwIrevLKXzklWSf:return
  GTHqBmQMURhEtjyAwIrevLKXzklWSP,GTHqBmQMURhEtjyAwIrevLKXzklWSN=GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.GetSearchList(GTHqBmQMURhEtjyAwIrevLKXzklWSf,GTHqBmQMURhEtjyAwIrevLKXzklWCs)
  if GTHqBmQMURhEtjyAwIrevLKXzklWDi(GTHqBmQMURhEtjyAwIrevLKXzklWSP)==0:return
  for GTHqBmQMURhEtjyAwIrevLKXzklWSb in GTHqBmQMURhEtjyAwIrevLKXzklWSP:
   GTHqBmQMURhEtjyAwIrevLKXzklWib =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('code')
   GTHqBmQMURhEtjyAwIrevLKXzklWCg =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('title')
   GTHqBmQMURhEtjyAwIrevLKXzklWSx=GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('content_type')
   GTHqBmQMURhEtjyAwIrevLKXzklWSV =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('story')
   GTHqBmQMURhEtjyAwIrevLKXzklWiV =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('thumbnail')
   GTHqBmQMURhEtjyAwIrevLKXzklWSp =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('year')
   GTHqBmQMURhEtjyAwIrevLKXzklWSn =GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('film_rating_code')
   GTHqBmQMURhEtjyAwIrevLKXzklWSJ=GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('film_rating_short')
   if GTHqBmQMURhEtjyAwIrevLKXzklWSx=='movies': 
    GTHqBmQMURhEtjyAwIrevLKXzklWCx=GTHqBmQMURhEtjyAwIrevLKXzklWDF
    GTHqBmQMURhEtjyAwIrevLKXzklWSo ='MOVIE'
    GTHqBmQMURhEtjyAwIrevLKXzklWCV=''
    GTHqBmQMURhEtjyAwIrevLKXzklWix='-'
   else: 
    GTHqBmQMURhEtjyAwIrevLKXzklWCx=GTHqBmQMURhEtjyAwIrevLKXzklWDC
    GTHqBmQMURhEtjyAwIrevLKXzklWSo ='EPISODE'
    GTHqBmQMURhEtjyAwIrevLKXzklWCV='Series'
    GTHqBmQMURhEtjyAwIrevLKXzklWix=GTHqBmQMURhEtjyAwIrevLKXzklWib
   GTHqBmQMURhEtjyAwIrevLKXzklWSY=GTHqBmQMURhEtjyAwIrevLKXzklWSb.get('info')
   GTHqBmQMURhEtjyAwIrevLKXzklWSY['plot']='%s (%s)\n년도 : %s\n\n%s'%(GTHqBmQMURhEtjyAwIrevLKXzklWCg,GTHqBmQMURhEtjyAwIrevLKXzklWSJ,GTHqBmQMURhEtjyAwIrevLKXzklWSp,GTHqBmQMURhEtjyAwIrevLKXzklWSV)
   if GTHqBmQMURhEtjyAwIrevLKXzklWSn>=19:
    GTHqBmQMURhEtjyAwIrevLKXzklWCg+='  (%s년 - %s)'%(GTHqBmQMURhEtjyAwIrevLKXzklWSp,GTHqBmQMURhEtjyAwIrevLKXzklWDu(GTHqBmQMURhEtjyAwIrevLKXzklWSJ))
   else:
    GTHqBmQMURhEtjyAwIrevLKXzklWCg+='  (%s년)'%(GTHqBmQMURhEtjyAwIrevLKXzklWSp)
   GTHqBmQMURhEtjyAwIrevLKXzklWCb={'mode':GTHqBmQMURhEtjyAwIrevLKXzklWSo,'movie_code':GTHqBmQMURhEtjyAwIrevLKXzklWib,'page':'1','season_code':GTHqBmQMURhEtjyAwIrevLKXzklWix,'title':GTHqBmQMURhEtjyAwIrevLKXzklWCg,'thumbnail':GTHqBmQMURhEtjyAwIrevLKXzklWiV}
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel=GTHqBmQMURhEtjyAwIrevLKXzklWCV,img=GTHqBmQMURhEtjyAwIrevLKXzklWiV,infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWSY,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWCx,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
  if GTHqBmQMURhEtjyAwIrevLKXzklWSN:
   GTHqBmQMURhEtjyAwIrevLKXzklWCb={}
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['mode'] ='SEARCH'
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['search_key']=GTHqBmQMURhEtjyAwIrevLKXzklWSf
   GTHqBmQMURhEtjyAwIrevLKXzklWCb['page'] =GTHqBmQMURhEtjyAwIrevLKXzklWDu(GTHqBmQMURhEtjyAwIrevLKXzklWCs+1)
   GTHqBmQMURhEtjyAwIrevLKXzklWCg='[B]%s >>[/B]'%'다음 페이지'
   GTHqBmQMURhEtjyAwIrevLKXzklWiN=GTHqBmQMURhEtjyAwIrevLKXzklWDu(GTHqBmQMURhEtjyAwIrevLKXzklWCs+1)
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel=GTHqBmQMURhEtjyAwIrevLKXzklWiN,img='',infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWuf,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWDC,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
  if GTHqBmQMURhEtjyAwIrevLKXzklWDi(GTHqBmQMURhEtjyAwIrevLKXzklWSP)>0:xbmcplugin.endOfDirectory(GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_handle)
 def Delete_Watched_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb,GTHqBmQMURhEtjyAwIrevLKXzklWCd):
  try:
   GTHqBmQMURhEtjyAwIrevLKXzklWSa=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GTHqBmQMURhEtjyAwIrevLKXzklWCd))
   fp=GTHqBmQMURhEtjyAwIrevLKXzklWDg(GTHqBmQMURhEtjyAwIrevLKXzklWSa,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   GTHqBmQMURhEtjyAwIrevLKXzklWuf
 def dp_WatchList_Delete(GTHqBmQMURhEtjyAwIrevLKXzklWFb,args):
  GTHqBmQMURhEtjyAwIrevLKXzklWCd=args.get('stype')
  GTHqBmQMURhEtjyAwIrevLKXzklWFJ=xbmcgui.Dialog()
  GTHqBmQMURhEtjyAwIrevLKXzklWCo=GTHqBmQMURhEtjyAwIrevLKXzklWFJ.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if GTHqBmQMURhEtjyAwIrevLKXzklWCo==GTHqBmQMURhEtjyAwIrevLKXzklWDF:sys.exit()
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.Delete_Watched_List(GTHqBmQMURhEtjyAwIrevLKXzklWCd)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb,GTHqBmQMURhEtjyAwIrevLKXzklWCd):
  try:
   GTHqBmQMURhEtjyAwIrevLKXzklWSa=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GTHqBmQMURhEtjyAwIrevLKXzklWCd))
   fp=GTHqBmQMURhEtjyAwIrevLKXzklWDg(GTHqBmQMURhEtjyAwIrevLKXzklWSa,'r',-1,'utf-8')
   GTHqBmQMURhEtjyAwIrevLKXzklWuF=fp.readlines()
   fp.close()
  except:
   GTHqBmQMURhEtjyAwIrevLKXzklWuF=[]
  return GTHqBmQMURhEtjyAwIrevLKXzklWuF
 def Save_Watched_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb,GTHqBmQMURhEtjyAwIrevLKXzklWCd,GTHqBmQMURhEtjyAwIrevLKXzklWFp):
  try:
   GTHqBmQMURhEtjyAwIrevLKXzklWSa=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GTHqBmQMURhEtjyAwIrevLKXzklWCd))
   GTHqBmQMURhEtjyAwIrevLKXzklWuC=GTHqBmQMURhEtjyAwIrevLKXzklWFb.Load_Watched_List(GTHqBmQMURhEtjyAwIrevLKXzklWCd) 
   fp=GTHqBmQMURhEtjyAwIrevLKXzklWDg(GTHqBmQMURhEtjyAwIrevLKXzklWSa,'w',-1,'utf-8')
   GTHqBmQMURhEtjyAwIrevLKXzklWui=urllib.parse.urlencode(GTHqBmQMURhEtjyAwIrevLKXzklWFp)
   GTHqBmQMURhEtjyAwIrevLKXzklWui=GTHqBmQMURhEtjyAwIrevLKXzklWui+'\n'
   fp.write(GTHqBmQMURhEtjyAwIrevLKXzklWui)
   GTHqBmQMURhEtjyAwIrevLKXzklWuS=0
   for GTHqBmQMURhEtjyAwIrevLKXzklWuD in GTHqBmQMURhEtjyAwIrevLKXzklWuC:
    GTHqBmQMURhEtjyAwIrevLKXzklWug=GTHqBmQMURhEtjyAwIrevLKXzklWDP(urllib.parse.parse_qsl(GTHqBmQMURhEtjyAwIrevLKXzklWuD))
    GTHqBmQMURhEtjyAwIrevLKXzklWuP=GTHqBmQMURhEtjyAwIrevLKXzklWFp.get('code')
    GTHqBmQMURhEtjyAwIrevLKXzklWuN=GTHqBmQMURhEtjyAwIrevLKXzklWug.get('code')
    if GTHqBmQMURhEtjyAwIrevLKXzklWCd=='seasons' and GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_settings_direct_replay()==GTHqBmQMURhEtjyAwIrevLKXzklWDC:
     GTHqBmQMURhEtjyAwIrevLKXzklWuP=GTHqBmQMURhEtjyAwIrevLKXzklWFp.get('videoid')
     GTHqBmQMURhEtjyAwIrevLKXzklWuN=GTHqBmQMURhEtjyAwIrevLKXzklWug.get('videoid')if GTHqBmQMURhEtjyAwIrevLKXzklWuN!=GTHqBmQMURhEtjyAwIrevLKXzklWuf else '-'
    if GTHqBmQMURhEtjyAwIrevLKXzklWuP!=GTHqBmQMURhEtjyAwIrevLKXzklWuN:
     fp.write(GTHqBmQMURhEtjyAwIrevLKXzklWuD)
     GTHqBmQMURhEtjyAwIrevLKXzklWuS+=1
     if GTHqBmQMURhEtjyAwIrevLKXzklWuS>=50:break
   fp.close()
  except:
   GTHqBmQMURhEtjyAwIrevLKXzklWuf
 def dp_Watch_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb,args):
  GTHqBmQMURhEtjyAwIrevLKXzklWCd =args.get('stype')
  GTHqBmQMURhEtjyAwIrevLKXzklWCF=GTHqBmQMURhEtjyAwIrevLKXzklWFb.get_settings_direct_replay()
  if GTHqBmQMURhEtjyAwIrevLKXzklWCd=='-':
   for GTHqBmQMURhEtjyAwIrevLKXzklWub in GTHqBmQMURhEtjyAwIrevLKXzklWFS:
    GTHqBmQMURhEtjyAwIrevLKXzklWCg=GTHqBmQMURhEtjyAwIrevLKXzklWub.get('title')
    GTHqBmQMURhEtjyAwIrevLKXzklWCb={'mode':GTHqBmQMURhEtjyAwIrevLKXzklWub.get('mode'),'stype':GTHqBmQMURhEtjyAwIrevLKXzklWub.get('stype')}
    GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel='',img='',infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWuf,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWDC,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
   if GTHqBmQMURhEtjyAwIrevLKXzklWDi(GTHqBmQMURhEtjyAwIrevLKXzklWFS)>0:xbmcplugin.endOfDirectory(GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_handle)
  else:
   GTHqBmQMURhEtjyAwIrevLKXzklWux=GTHqBmQMURhEtjyAwIrevLKXzklWFb.Load_Watched_List(GTHqBmQMURhEtjyAwIrevLKXzklWCd)
   for GTHqBmQMURhEtjyAwIrevLKXzklWuV in GTHqBmQMURhEtjyAwIrevLKXzklWux:
    GTHqBmQMURhEtjyAwIrevLKXzklWup=GTHqBmQMURhEtjyAwIrevLKXzklWDP(urllib.parse.parse_qsl(GTHqBmQMURhEtjyAwIrevLKXzklWuV))
    GTHqBmQMURhEtjyAwIrevLKXzklWib=GTHqBmQMURhEtjyAwIrevLKXzklWup.get('code')
    GTHqBmQMURhEtjyAwIrevLKXzklWCg =GTHqBmQMURhEtjyAwIrevLKXzklWup.get('title')
    GTHqBmQMURhEtjyAwIrevLKXzklWiV =GTHqBmQMURhEtjyAwIrevLKXzklWup.get('img')
    GTHqBmQMURhEtjyAwIrevLKXzklWun =GTHqBmQMURhEtjyAwIrevLKXzklWup.get('videoid')
    GTHqBmQMURhEtjyAwIrevLKXzklWSY={}
    GTHqBmQMURhEtjyAwIrevLKXzklWSY['plot']=GTHqBmQMURhEtjyAwIrevLKXzklWCg
    if GTHqBmQMURhEtjyAwIrevLKXzklWCd=='movie':
     GTHqBmQMURhEtjyAwIrevLKXzklWCb={'mode':'MOVIE','page':'1','movie_code':GTHqBmQMURhEtjyAwIrevLKXzklWib,'season_code':'-','title':GTHqBmQMURhEtjyAwIrevLKXzklWCg,'thumbnail':GTHqBmQMURhEtjyAwIrevLKXzklWiV}
     GTHqBmQMURhEtjyAwIrevLKXzklWCx=GTHqBmQMURhEtjyAwIrevLKXzklWDF
    else:
     if GTHqBmQMURhEtjyAwIrevLKXzklWCF==GTHqBmQMURhEtjyAwIrevLKXzklWDF or GTHqBmQMURhEtjyAwIrevLKXzklWun==GTHqBmQMURhEtjyAwIrevLKXzklWuf:
      GTHqBmQMURhEtjyAwIrevLKXzklWCb={'mode':'EPISODE','page':'1','movie_code':GTHqBmQMURhEtjyAwIrevLKXzklWib,'season_code':GTHqBmQMURhEtjyAwIrevLKXzklWib,'title':GTHqBmQMURhEtjyAwIrevLKXzklWCg,'thumbnail':GTHqBmQMURhEtjyAwIrevLKXzklWiV}
      GTHqBmQMURhEtjyAwIrevLKXzklWCx=GTHqBmQMURhEtjyAwIrevLKXzklWDC
     else:
      GTHqBmQMURhEtjyAwIrevLKXzklWCb={'mode':'MOVIE','movie_code':GTHqBmQMURhEtjyAwIrevLKXzklWun,'season_code':GTHqBmQMURhEtjyAwIrevLKXzklWib,'title':GTHqBmQMURhEtjyAwIrevLKXzklWCg,'thumbnail':GTHqBmQMURhEtjyAwIrevLKXzklWiV}
      GTHqBmQMURhEtjyAwIrevLKXzklWCx=GTHqBmQMURhEtjyAwIrevLKXzklWDF
    GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel='',img=GTHqBmQMURhEtjyAwIrevLKXzklWiV,infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWSY,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWCx,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
   GTHqBmQMURhEtjyAwIrevLKXzklWSY={'plot':'시청목록을 삭제합니다.'}
   GTHqBmQMURhEtjyAwIrevLKXzklWCg='*** 시청목록 삭제 ***'
   GTHqBmQMURhEtjyAwIrevLKXzklWCb={'mode':'MYVIEW_REMOVE','stype':GTHqBmQMURhEtjyAwIrevLKXzklWCd}
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.add_dir(GTHqBmQMURhEtjyAwIrevLKXzklWCg,sublabel='',img='',infoLabels=GTHqBmQMURhEtjyAwIrevLKXzklWSY,isFolder=GTHqBmQMURhEtjyAwIrevLKXzklWDF,params=GTHqBmQMURhEtjyAwIrevLKXzklWCb)
   xbmcplugin.endOfDirectory(GTHqBmQMURhEtjyAwIrevLKXzklWFb._addon_handle,cacheToDisc=GTHqBmQMURhEtjyAwIrevLKXzklWDF)
 def logout(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  GTHqBmQMURhEtjyAwIrevLKXzklWFJ=xbmcgui.Dialog()
  GTHqBmQMURhEtjyAwIrevLKXzklWCo=GTHqBmQMURhEtjyAwIrevLKXzklWFJ.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if GTHqBmQMURhEtjyAwIrevLKXzklWCo==GTHqBmQMURhEtjyAwIrevLKXzklWDF:sys.exit()
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.wininfo_clear()
  if os.path.isfile(GTHqBmQMURhEtjyAwIrevLKXzklWFN):os.remove(GTHqBmQMURhEtjyAwIrevLKXzklWFN)
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  GTHqBmQMURhEtjyAwIrevLKXzklWCi=xbmcgui.Window(10000)
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_TOKEN','')
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_GUIT','')
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_GUITV','')
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_USERCD','')
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  GTHqBmQMURhEtjyAwIrevLKXzklWuJ =GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.Get_Now_Datetime()
  GTHqBmQMURhEtjyAwIrevLKXzklWuo=GTHqBmQMURhEtjyAwIrevLKXzklWuJ+datetime.timedelta(days=GTHqBmQMURhEtjyAwIrevLKXzklWua(__addon__.getSetting('cache_ttl')))
  GTHqBmQMURhEtjyAwIrevLKXzklWCi=xbmcgui.Window(10000)
  GTHqBmQMURhEtjyAwIrevLKXzklWuY={'watcha_token':GTHqBmQMURhEtjyAwIrevLKXzklWCi.getProperty('WATCHA_M_TOKEN'),'watcha_guit':GTHqBmQMURhEtjyAwIrevLKXzklWCi.getProperty('WATCHA_M_GUIT'),'watcha_guitv':GTHqBmQMURhEtjyAwIrevLKXzklWCi.getProperty('WATCHA_M_GUITV'),'watcha_usercd':GTHqBmQMURhEtjyAwIrevLKXzklWCi.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':GTHqBmQMURhEtjyAwIrevLKXzklWuo.strftime('%Y-%m-%d')}
  try: 
   fp=GTHqBmQMURhEtjyAwIrevLKXzklWDg(GTHqBmQMURhEtjyAwIrevLKXzklWFN,'w',-1,'utf-8')
   json.dump(GTHqBmQMURhEtjyAwIrevLKXzklWuY,fp)
   fp.close()
  except GTHqBmQMURhEtjyAwIrevLKXzklWDN as exception:
   GTHqBmQMURhEtjyAwIrevLKXzklWDb(exception)
 def cookiefile_check(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  GTHqBmQMURhEtjyAwIrevLKXzklWuY={}
  try: 
   fp=GTHqBmQMURhEtjyAwIrevLKXzklWDg(GTHqBmQMURhEtjyAwIrevLKXzklWFN,'r',-1,'utf-8')
   GTHqBmQMURhEtjyAwIrevLKXzklWuY= json.load(fp)
   fp.close()
  except GTHqBmQMURhEtjyAwIrevLKXzklWDN as exception:
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.wininfo_clear()
   return GTHqBmQMURhEtjyAwIrevLKXzklWDF
  GTHqBmQMURhEtjyAwIrevLKXzklWCp =__addon__.getSetting('id')
  GTHqBmQMURhEtjyAwIrevLKXzklWCn =__addon__.getSetting('pw')
  GTHqBmQMURhEtjyAwIrevLKXzklWuc =__addon__.getSetting('selected_profile')
  GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_id']=base64.standard_b64decode(GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_id']).decode('utf-8')
  GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_pw']=base64.standard_b64decode(GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_pw']).decode('utf-8')
  if GTHqBmQMURhEtjyAwIrevLKXzklWCp!=GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_id']or GTHqBmQMURhEtjyAwIrevLKXzklWCn!=GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_pw']or GTHqBmQMURhEtjyAwIrevLKXzklWuc!=GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_profile']:
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.wininfo_clear()
   return GTHqBmQMURhEtjyAwIrevLKXzklWDF
  GTHqBmQMURhEtjyAwIrevLKXzklWCY =GTHqBmQMURhEtjyAwIrevLKXzklWua(GTHqBmQMURhEtjyAwIrevLKXzklWFb.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  GTHqBmQMURhEtjyAwIrevLKXzklWuO=GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_limitdate']
  GTHqBmQMURhEtjyAwIrevLKXzklWCc =GTHqBmQMURhEtjyAwIrevLKXzklWua(re.sub('-','',GTHqBmQMURhEtjyAwIrevLKXzklWuO))
  if GTHqBmQMURhEtjyAwIrevLKXzklWCc<GTHqBmQMURhEtjyAwIrevLKXzklWCY:
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.wininfo_clear()
   return GTHqBmQMURhEtjyAwIrevLKXzklWDF
  GTHqBmQMURhEtjyAwIrevLKXzklWCi=xbmcgui.Window(10000)
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_TOKEN',GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_token'])
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_GUIT',GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_guit'])
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_GUITV',GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_guitv'])
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_USERCD',GTHqBmQMURhEtjyAwIrevLKXzklWuY['watcha_usercd'])
  GTHqBmQMURhEtjyAwIrevLKXzklWCi.setProperty('WATCHA_M_LOGINTIME',GTHqBmQMURhEtjyAwIrevLKXzklWuO)
  return GTHqBmQMURhEtjyAwIrevLKXzklWDC
 def watcha_main(GTHqBmQMURhEtjyAwIrevLKXzklWFb):
  GTHqBmQMURhEtjyAwIrevLKXzklWud=GTHqBmQMURhEtjyAwIrevLKXzklWFb.main_params.get('mode',GTHqBmQMURhEtjyAwIrevLKXzklWuf)
  if GTHqBmQMURhEtjyAwIrevLKXzklWud=='LOGOUT':
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.logout()
   return
  GTHqBmQMURhEtjyAwIrevLKXzklWFb.login_main()
  if GTHqBmQMURhEtjyAwIrevLKXzklWud is GTHqBmQMURhEtjyAwIrevLKXzklWuf:
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.dp_Main_List()
  elif GTHqBmQMURhEtjyAwIrevLKXzklWud=='SUB_GROUP':
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.dp_SubGroup_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb.main_params)
  elif GTHqBmQMURhEtjyAwIrevLKXzklWud=='CATEGORY_LIST':
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.dp_Category_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb.main_params)
  elif GTHqBmQMURhEtjyAwIrevLKXzklWud=='EPISODE':
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.dp_Episode_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb.main_params)
  elif GTHqBmQMURhEtjyAwIrevLKXzklWud=='ORDER_BY':
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.dp_setEpOrderby(GTHqBmQMURhEtjyAwIrevLKXzklWFb.main_params)
  elif GTHqBmQMURhEtjyAwIrevLKXzklWud=='SEARCH':
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.dp_Search_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb.main_params)
  elif GTHqBmQMURhEtjyAwIrevLKXzklWud=='MOVIE':
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.play_VIDEO(GTHqBmQMURhEtjyAwIrevLKXzklWFb.main_params)
  elif GTHqBmQMURhEtjyAwIrevLKXzklWud=='WATCH':
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.dp_Watch_List(GTHqBmQMURhEtjyAwIrevLKXzklWFb.main_params)
  elif GTHqBmQMURhEtjyAwIrevLKXzklWud=='MYVIEW_REMOVE':
   GTHqBmQMURhEtjyAwIrevLKXzklWFb.dp_WatchList_Delete(GTHqBmQMURhEtjyAwIrevLKXzklWFb.main_params)
  else:
   GTHqBmQMURhEtjyAwIrevLKXzklWuf
# Created by pyminifier (https://github.com/liftoff/pyminifier)
