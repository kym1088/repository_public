__author__="NightRain"
MAEWYuQheFBiTNjmtsISJcOqvyCUHD=object
MAEWYuQheFBiTNjmtsISJcOqvyCUHG=None
MAEWYuQheFBiTNjmtsISJcOqvyCUHb=False
MAEWYuQheFBiTNjmtsISJcOqvyCUHw=True
MAEWYuQheFBiTNjmtsISJcOqvyCUPX=Exception
MAEWYuQheFBiTNjmtsISJcOqvyCUPr=print
MAEWYuQheFBiTNjmtsISJcOqvyCUPV=str
MAEWYuQheFBiTNjmtsISJcOqvyCUPH=len
MAEWYuQheFBiTNjmtsISJcOqvyCUPK=int
MAEWYuQheFBiTNjmtsISJcOqvyCUPd=range
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
class MAEWYuQheFBiTNjmtsISJcOqvyCUXr(MAEWYuQheFBiTNjmtsISJcOqvyCUHD):
 def __init__(MAEWYuQheFBiTNjmtsISJcOqvyCUXV):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_TOKEN ='' 
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUIT =''
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUITV =''
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_USERCD=''
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.MAIN_DOMAIN ='https://watcha.com'
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN ='https://api-mars.watcha.com'
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.EPISODE_LIMIT=20
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.SEARCH_LIMIT =30
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.DEFAULT_HEADER={'user-agent':MAEWYuQheFBiTNjmtsISJcOqvyCUXV.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,jobtype,MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,redirects=MAEWYuQheFBiTNjmtsISJcOqvyCUHb):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXH=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.DEFAULT_HEADER
  if headers:MAEWYuQheFBiTNjmtsISJcOqvyCUXH.update(headers)
  if jobtype=='Get':
   MAEWYuQheFBiTNjmtsISJcOqvyCUXP=requests.get(MAEWYuQheFBiTNjmtsISJcOqvyCUXw,params=params,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUXH,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   MAEWYuQheFBiTNjmtsISJcOqvyCUXP=requests.put(MAEWYuQheFBiTNjmtsISJcOqvyCUXw,data=payload,params=params,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUXH,cookies=cookies,allow_redirects=redirects)
  else:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXP=requests.post(MAEWYuQheFBiTNjmtsISJcOqvyCUXw,data=payload,params=params,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUXH,cookies=cookies,allow_redirects=redirects)
  return MAEWYuQheFBiTNjmtsISJcOqvyCUXP
 def SaveCredential(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,MAEWYuQheFBiTNjmtsISJcOqvyCUXK):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_TOKEN =MAEWYuQheFBiTNjmtsISJcOqvyCUXK.get('watcha_token')
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUIT =MAEWYuQheFBiTNjmtsISJcOqvyCUXK.get('watcha_guit')
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUITV =MAEWYuQheFBiTNjmtsISJcOqvyCUXK.get('watcha_guitv')
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_USERCD =MAEWYuQheFBiTNjmtsISJcOqvyCUXK.get('watcha_usercd')
 def SaveCredential_usercd(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,MAEWYuQheFBiTNjmtsISJcOqvyCUXd):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_USERCD=MAEWYuQheFBiTNjmtsISJcOqvyCUXd
 def SaveCredential_guitv(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,MAEWYuQheFBiTNjmtsISJcOqvyCUXx,MAEWYuQheFBiTNjmtsISJcOqvyCUXa):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUITV=MAEWYuQheFBiTNjmtsISJcOqvyCUXx
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_TOKEN=MAEWYuQheFBiTNjmtsISJcOqvyCUXa 
 def ClearCredential(MAEWYuQheFBiTNjmtsISJcOqvyCUXV):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_TOKEN ='' 
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUIT =''
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUITV =''
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_USERCD=''
 def LoadCredential(MAEWYuQheFBiTNjmtsISJcOqvyCUXV):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXK={'watcha_token':MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_TOKEN,'watcha_guit':MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUIT,'watcha_guitv':MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUITV,'watcha_usercd':MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_USERCD}
  return MAEWYuQheFBiTNjmtsISJcOqvyCUXK
 def makeDefaultCookies(MAEWYuQheFBiTNjmtsISJcOqvyCUXV):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXn={'_s_guit':MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUIT,'_guinness-premium_session':MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_TOKEN}
  if MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUITV:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXn['_s_guitv']=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_GUITV
  return MAEWYuQheFBiTNjmtsISJcOqvyCUXn
 def GetCredential(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,user_id,user_pw,user_pf):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXp=MAEWYuQheFBiTNjmtsISJcOqvyCUHb
  MAEWYuQheFBiTNjmtsISJcOqvyCUXR=MAEWYuQheFBiTNjmtsISJcOqvyCUXz='-'
  try:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXL=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN+'/api/session'
   MAEWYuQheFBiTNjmtsISJcOqvyCUXo={'email':user_id,'password':user_pw}
   MAEWYuQheFBiTNjmtsISJcOqvyCUXg={'accept':'application/vnd.frograms+json;version=4'}
   MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Post',MAEWYuQheFBiTNjmtsISJcOqvyCUXL,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUXo,params=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUXg,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUHG)
   for MAEWYuQheFBiTNjmtsISJcOqvyCUXl in MAEWYuQheFBiTNjmtsISJcOqvyCUXf.cookies:
    if MAEWYuQheFBiTNjmtsISJcOqvyCUXl.name=='_guinness-premium_session':
     MAEWYuQheFBiTNjmtsISJcOqvyCUXz=MAEWYuQheFBiTNjmtsISJcOqvyCUXl.value
    elif MAEWYuQheFBiTNjmtsISJcOqvyCUXl.name=='_s_guit':
     MAEWYuQheFBiTNjmtsISJcOqvyCUXR=MAEWYuQheFBiTNjmtsISJcOqvyCUXl.value
   if MAEWYuQheFBiTNjmtsISJcOqvyCUXz:MAEWYuQheFBiTNjmtsISJcOqvyCUXp=MAEWYuQheFBiTNjmtsISJcOqvyCUHw
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   MAEWYuQheFBiTNjmtsISJcOqvyCUPr(exception)
   MAEWYuQheFBiTNjmtsISJcOqvyCUXR=MAEWYuQheFBiTNjmtsISJcOqvyCUXz='' 
  MAEWYuQheFBiTNjmtsISJcOqvyCUXK={'watcha_guit':MAEWYuQheFBiTNjmtsISJcOqvyCUXR,'watcha_token':MAEWYuQheFBiTNjmtsISJcOqvyCUXz,'watcha_guitv':'','watcha_usercd':''}
  MAEWYuQheFBiTNjmtsISJcOqvyCUXV.SaveCredential(MAEWYuQheFBiTNjmtsISJcOqvyCUXK)
  try:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXk=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.GetProfilesList()
   MAEWYuQheFBiTNjmtsISJcOqvyCUPr(MAEWYuQheFBiTNjmtsISJcOqvyCUXk)
   MAEWYuQheFBiTNjmtsISJcOqvyCUXD =MAEWYuQheFBiTNjmtsISJcOqvyCUXk[user_pf]
   MAEWYuQheFBiTNjmtsISJcOqvyCUXV.SaveCredential_usercd(MAEWYuQheFBiTNjmtsISJcOqvyCUXD)
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   MAEWYuQheFBiTNjmtsISJcOqvyCUPr(exception)
   MAEWYuQheFBiTNjmtsISJcOqvyCUXV.ClearCredential()
   return MAEWYuQheFBiTNjmtsISJcOqvyCUHb
  if user_pf!=0:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXx,MAEWYuQheFBiTNjmtsISJcOqvyCUXa=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.GetProfilesConvert(MAEWYuQheFBiTNjmtsISJcOqvyCUXD)
   MAEWYuQheFBiTNjmtsISJcOqvyCUXV.SaveCredential_guitv(MAEWYuQheFBiTNjmtsISJcOqvyCUXx,MAEWYuQheFBiTNjmtsISJcOqvyCUXa)
  return MAEWYuQheFBiTNjmtsISJcOqvyCUXp
 def GetSubGroupList(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,stype):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXG=[]
  try:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXb ='/api/categories.json'
   MAEWYuQheFBiTNjmtsISJcOqvyCUXw=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN+MAEWYuQheFBiTNjmtsISJcOqvyCUXb
   MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Get',MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUHG)
   MAEWYuQheFBiTNjmtsISJcOqvyCUrX=json.loads(MAEWYuQheFBiTNjmtsISJcOqvyCUXf.text)
   if not('genres' in MAEWYuQheFBiTNjmtsISJcOqvyCUrX):return MAEWYuQheFBiTNjmtsISJcOqvyCUXG
   if stype=='genres':
    MAEWYuQheFBiTNjmtsISJcOqvyCUrV=MAEWYuQheFBiTNjmtsISJcOqvyCUrX['genres']
   else:
    MAEWYuQheFBiTNjmtsISJcOqvyCUrV=MAEWYuQheFBiTNjmtsISJcOqvyCUrX['tags']
   for MAEWYuQheFBiTNjmtsISJcOqvyCUrH in MAEWYuQheFBiTNjmtsISJcOqvyCUrV:
    MAEWYuQheFBiTNjmtsISJcOqvyCUrP=MAEWYuQheFBiTNjmtsISJcOqvyCUrH['name']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrK =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['api_path']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrd =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['entity']['id']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrx={'group_name':MAEWYuQheFBiTNjmtsISJcOqvyCUrP,'api_path':MAEWYuQheFBiTNjmtsISJcOqvyCUrK,'tag_id':MAEWYuQheFBiTNjmtsISJcOqvyCUPV(MAEWYuQheFBiTNjmtsISJcOqvyCUrd)}
    MAEWYuQheFBiTNjmtsISJcOqvyCUXG.append(MAEWYuQheFBiTNjmtsISJcOqvyCUrx)
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   MAEWYuQheFBiTNjmtsISJcOqvyCUPr(exception)
  return MAEWYuQheFBiTNjmtsISJcOqvyCUXG
 def GetCategoryList(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,stype,MAEWYuQheFBiTNjmtsISJcOqvyCUrd,MAEWYuQheFBiTNjmtsISJcOqvyCUrK,page_int,in_sort):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXG=[]
  MAEWYuQheFBiTNjmtsISJcOqvyCUra=MAEWYuQheFBiTNjmtsISJcOqvyCUHb
  MAEWYuQheFBiTNjmtsISJcOqvyCUrn={}
  try:
   if 'categories' in MAEWYuQheFBiTNjmtsISJcOqvyCUrK:
    MAEWYuQheFBiTNjmtsISJcOqvyCUXb ='/api/categories/contents.json'
    if stype=='genres':
     MAEWYuQheFBiTNjmtsISJcOqvyCUrn['genre']=MAEWYuQheFBiTNjmtsISJcOqvyCUrd
    else:
     MAEWYuQheFBiTNjmtsISJcOqvyCUrn['tag'] =MAEWYuQheFBiTNjmtsISJcOqvyCUrd
    MAEWYuQheFBiTNjmtsISJcOqvyCUrn['order']=in_sort 
    if page_int>1:
     MAEWYuQheFBiTNjmtsISJcOqvyCUrn['page']=MAEWYuQheFBiTNjmtsISJcOqvyCUPV(page_int-1)
   else: 
    MAEWYuQheFBiTNjmtsISJcOqvyCUXb ='/api/'+MAEWYuQheFBiTNjmtsISJcOqvyCUrK+'.json'
    if page_int>1:
     MAEWYuQheFBiTNjmtsISJcOqvyCUrn['page']=MAEWYuQheFBiTNjmtsISJcOqvyCUPV(page_int)
   MAEWYuQheFBiTNjmtsISJcOqvyCUXw=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN+MAEWYuQheFBiTNjmtsISJcOqvyCUXb
   MAEWYuQheFBiTNjmtsISJcOqvyCUXl=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.makeDefaultCookies()
   MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Get',MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUrn,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUXl)
   MAEWYuQheFBiTNjmtsISJcOqvyCUrX=json.loads(MAEWYuQheFBiTNjmtsISJcOqvyCUXf.text)
   if not('contents' in MAEWYuQheFBiTNjmtsISJcOqvyCUrX):return MAEWYuQheFBiTNjmtsISJcOqvyCUXG,MAEWYuQheFBiTNjmtsISJcOqvyCUra
   MAEWYuQheFBiTNjmtsISJcOqvyCUrV=MAEWYuQheFBiTNjmtsISJcOqvyCUrX['contents']
   MAEWYuQheFBiTNjmtsISJcOqvyCUra=MAEWYuQheFBiTNjmtsISJcOqvyCUrX['meta']['has_next']
   for MAEWYuQheFBiTNjmtsISJcOqvyCUrH in MAEWYuQheFBiTNjmtsISJcOqvyCUrV:
    MAEWYuQheFBiTNjmtsISJcOqvyCUrp =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['code']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrR=MAEWYuQheFBiTNjmtsISJcOqvyCUrH['content_type']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrL =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['title']
    MAEWYuQheFBiTNjmtsISJcOqvyCUro =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['story']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrg=MAEWYuQheFBiTNjmtsISJcOqvyCUHk=MAEWYuQheFBiTNjmtsISJcOqvyCUHz=''
    if MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('poster') !=MAEWYuQheFBiTNjmtsISJcOqvyCUHG:MAEWYuQheFBiTNjmtsISJcOqvyCUrg=MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('poster').get('original')
    if MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('stillcut')!=MAEWYuQheFBiTNjmtsISJcOqvyCUHG:MAEWYuQheFBiTNjmtsISJcOqvyCUHk =MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('stillcut').get('large')
    if MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('thumbnail')!=MAEWYuQheFBiTNjmtsISJcOqvyCUHG:MAEWYuQheFBiTNjmtsISJcOqvyCUHz=MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('thumbnail').get('large')
    if MAEWYuQheFBiTNjmtsISJcOqvyCUHz=='' :MAEWYuQheFBiTNjmtsISJcOqvyCUHz=MAEWYuQheFBiTNjmtsISJcOqvyCUHk
    MAEWYuQheFBiTNjmtsISJcOqvyCUrf={'thumb':MAEWYuQheFBiTNjmtsISJcOqvyCUHk,'poster':MAEWYuQheFBiTNjmtsISJcOqvyCUrg,'fanart':MAEWYuQheFBiTNjmtsISJcOqvyCUHz}
    MAEWYuQheFBiTNjmtsISJcOqvyCUrl =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['year']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrz =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['film_rating_code']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrk=MAEWYuQheFBiTNjmtsISJcOqvyCUrH['film_rating_short']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrD =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['film_rating_long']
    if MAEWYuQheFBiTNjmtsISJcOqvyCUrR=='movies':
     MAEWYuQheFBiTNjmtsISJcOqvyCUrG =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['duration']
    else:
     MAEWYuQheFBiTNjmtsISJcOqvyCUrG ='0'
    MAEWYuQheFBiTNjmtsISJcOqvyCUrx={'code':MAEWYuQheFBiTNjmtsISJcOqvyCUrp,'content_type':MAEWYuQheFBiTNjmtsISJcOqvyCUrR,'title':MAEWYuQheFBiTNjmtsISJcOqvyCUrL,'story':MAEWYuQheFBiTNjmtsISJcOqvyCUro,'thumbnail':MAEWYuQheFBiTNjmtsISJcOqvyCUrf,'year':MAEWYuQheFBiTNjmtsISJcOqvyCUrl,'film_rating_code':MAEWYuQheFBiTNjmtsISJcOqvyCUrz,'film_rating_short':MAEWYuQheFBiTNjmtsISJcOqvyCUrk,'film_rating_long':MAEWYuQheFBiTNjmtsISJcOqvyCUrD,'duration':MAEWYuQheFBiTNjmtsISJcOqvyCUrG}
    MAEWYuQheFBiTNjmtsISJcOqvyCUXG.append(MAEWYuQheFBiTNjmtsISJcOqvyCUrx)
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   MAEWYuQheFBiTNjmtsISJcOqvyCUPr(exception)
  return MAEWYuQheFBiTNjmtsISJcOqvyCUXG,MAEWYuQheFBiTNjmtsISJcOqvyCUra
 def GetCategoryList_morepage(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,stype,MAEWYuQheFBiTNjmtsISJcOqvyCUrd,MAEWYuQheFBiTNjmtsISJcOqvyCUrK,page_int,in_sort):
  MAEWYuQheFBiTNjmtsISJcOqvyCUra=MAEWYuQheFBiTNjmtsISJcOqvyCUHb
  if not('categories' in MAEWYuQheFBiTNjmtsISJcOqvyCUrK):return MAEWYuQheFBiTNjmtsISJcOqvyCUHw
  try:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXb ='/api/categories/contents.json'
   MAEWYuQheFBiTNjmtsISJcOqvyCUXw=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN+MAEWYuQheFBiTNjmtsISJcOqvyCUXb
   MAEWYuQheFBiTNjmtsISJcOqvyCUrn={}
   if stype=='genres':
    MAEWYuQheFBiTNjmtsISJcOqvyCUrn['genre']=MAEWYuQheFBiTNjmtsISJcOqvyCUrd
   else:
    MAEWYuQheFBiTNjmtsISJcOqvyCUrn['tag'] =MAEWYuQheFBiTNjmtsISJcOqvyCUrd
   MAEWYuQheFBiTNjmtsISJcOqvyCUrn['order']=in_sort 
   if page_int>1:
    MAEWYuQheFBiTNjmtsISJcOqvyCUrn['page']=MAEWYuQheFBiTNjmtsISJcOqvyCUPV(page_int-1)
   MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Get',MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUrn,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUHG)
   MAEWYuQheFBiTNjmtsISJcOqvyCUrX=json.loads(MAEWYuQheFBiTNjmtsISJcOqvyCUXf.text)
   MAEWYuQheFBiTNjmtsISJcOqvyCUra=MAEWYuQheFBiTNjmtsISJcOqvyCUrX['meta']['has_next']
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   MAEWYuQheFBiTNjmtsISJcOqvyCUPr(exception)
  return MAEWYuQheFBiTNjmtsISJcOqvyCUra
 def GetProgramInfo(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,program_code):
  MAEWYuQheFBiTNjmtsISJcOqvyCUrb={}
  try:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXb ='/api/contents/'+program_code
   MAEWYuQheFBiTNjmtsISJcOqvyCUXw=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN+MAEWYuQheFBiTNjmtsISJcOqvyCUXb
   MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Get',MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUHG)
   MAEWYuQheFBiTNjmtsISJcOqvyCUrX=json.loads(MAEWYuQheFBiTNjmtsISJcOqvyCUXf.text)
   MAEWYuQheFBiTNjmtsISJcOqvyCUrw=img_clearlogo=''
   MAEWYuQheFBiTNjmtsISJcOqvyCUrw=MAEWYuQheFBiTNjmtsISJcOqvyCUrX.get('poster').get('original')
   if MAEWYuQheFBiTNjmtsISJcOqvyCUPH(MAEWYuQheFBiTNjmtsISJcOqvyCUrX.get('title_logos'))>0:img_clearlogo=MAEWYuQheFBiTNjmtsISJcOqvyCUrX.get('title_logos')[0].get('src')
   MAEWYuQheFBiTNjmtsISJcOqvyCUrb={'imgPoster':MAEWYuQheFBiTNjmtsISJcOqvyCUrw,'imgClearlogo':img_clearlogo}
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   MAEWYuQheFBiTNjmtsISJcOqvyCUPr(exception)
  return MAEWYuQheFBiTNjmtsISJcOqvyCUrb
 def GetEpisodoList(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,program_code,page_int,orderby='asc'):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXG=[]
  MAEWYuQheFBiTNjmtsISJcOqvyCUra=MAEWYuQheFBiTNjmtsISJcOqvyCUHb
  MAEWYuQheFBiTNjmtsISJcOqvyCUVX=''
  try:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXb ='/api/contents/'+program_code+'/tv_episodes.json'
   MAEWYuQheFBiTNjmtsISJcOqvyCUXw=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN+MAEWYuQheFBiTNjmtsISJcOqvyCUXb
   MAEWYuQheFBiTNjmtsISJcOqvyCUrn={'all':'true'}
   MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Get',MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUrn,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUHG)
   MAEWYuQheFBiTNjmtsISJcOqvyCUrX=json.loads(MAEWYuQheFBiTNjmtsISJcOqvyCUXf.text)
   if not('tv_episode_codes' in MAEWYuQheFBiTNjmtsISJcOqvyCUrX):return MAEWYuQheFBiTNjmtsISJcOqvyCUXG,MAEWYuQheFBiTNjmtsISJcOqvyCUra
   MAEWYuQheFBiTNjmtsISJcOqvyCUrV=MAEWYuQheFBiTNjmtsISJcOqvyCUrX['tv_episode_codes']
   MAEWYuQheFBiTNjmtsISJcOqvyCUVr=MAEWYuQheFBiTNjmtsISJcOqvyCUPH(MAEWYuQheFBiTNjmtsISJcOqvyCUrV)
   MAEWYuQheFBiTNjmtsISJcOqvyCUVH =MAEWYuQheFBiTNjmtsISJcOqvyCUPK(MAEWYuQheFBiTNjmtsISJcOqvyCUVr//(MAEWYuQheFBiTNjmtsISJcOqvyCUXV.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    MAEWYuQheFBiTNjmtsISJcOqvyCUVP =(MAEWYuQheFBiTNjmtsISJcOqvyCUVr-1)-((page_int-1)*MAEWYuQheFBiTNjmtsISJcOqvyCUXV.EPISODE_LIMIT)
   else:
    MAEWYuQheFBiTNjmtsISJcOqvyCUVP =(page_int-1)*MAEWYuQheFBiTNjmtsISJcOqvyCUXV.EPISODE_LIMIT
   for i in MAEWYuQheFBiTNjmtsISJcOqvyCUPd(MAEWYuQheFBiTNjmtsISJcOqvyCUXV.EPISODE_LIMIT):
    if orderby=='desc':
     MAEWYuQheFBiTNjmtsISJcOqvyCUVK=MAEWYuQheFBiTNjmtsISJcOqvyCUVP-i
     if MAEWYuQheFBiTNjmtsISJcOqvyCUVK<0:break
    else:
     MAEWYuQheFBiTNjmtsISJcOqvyCUVK=MAEWYuQheFBiTNjmtsISJcOqvyCUVP+i
     if MAEWYuQheFBiTNjmtsISJcOqvyCUVK>=MAEWYuQheFBiTNjmtsISJcOqvyCUVr:break
    if MAEWYuQheFBiTNjmtsISJcOqvyCUVX!='':MAEWYuQheFBiTNjmtsISJcOqvyCUVX+=','
    MAEWYuQheFBiTNjmtsISJcOqvyCUVX+=MAEWYuQheFBiTNjmtsISJcOqvyCUrV[MAEWYuQheFBiTNjmtsISJcOqvyCUVK]
   if MAEWYuQheFBiTNjmtsISJcOqvyCUVH>page_int:MAEWYuQheFBiTNjmtsISJcOqvyCUra=MAEWYuQheFBiTNjmtsISJcOqvyCUHw
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   MAEWYuQheFBiTNjmtsISJcOqvyCUPr(exception)
  MAEWYuQheFBiTNjmtsISJcOqvyCUVd=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.GetProgramInfo(program_code)
  try:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXw=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN+MAEWYuQheFBiTNjmtsISJcOqvyCUXb
   MAEWYuQheFBiTNjmtsISJcOqvyCUrn={'codes':MAEWYuQheFBiTNjmtsISJcOqvyCUVX}
   MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Get',MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUrn,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUHG)
   MAEWYuQheFBiTNjmtsISJcOqvyCUrX=json.loads(MAEWYuQheFBiTNjmtsISJcOqvyCUXf.text)
   if not('tv_episodes' in MAEWYuQheFBiTNjmtsISJcOqvyCUrX):return MAEWYuQheFBiTNjmtsISJcOqvyCUXG
   MAEWYuQheFBiTNjmtsISJcOqvyCUrV=MAEWYuQheFBiTNjmtsISJcOqvyCUrX['tv_episodes']
   for MAEWYuQheFBiTNjmtsISJcOqvyCUrH in MAEWYuQheFBiTNjmtsISJcOqvyCUrV:
    MAEWYuQheFBiTNjmtsISJcOqvyCUrp =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['code']
    if MAEWYuQheFBiTNjmtsISJcOqvyCUrH['title']:
     MAEWYuQheFBiTNjmtsISJcOqvyCUrL =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['title']
    else:
     MAEWYuQheFBiTNjmtsISJcOqvyCUrL =''
    MAEWYuQheFBiTNjmtsISJcOqvyCUrg=MAEWYuQheFBiTNjmtsISJcOqvyCUHk=MAEWYuQheFBiTNjmtsISJcOqvyCUHz=MAEWYuQheFBiTNjmtsISJcOqvyCUVx=''
    MAEWYuQheFBiTNjmtsISJcOqvyCUrg =MAEWYuQheFBiTNjmtsISJcOqvyCUVd.get('imgPoster')
    MAEWYuQheFBiTNjmtsISJcOqvyCUVx=MAEWYuQheFBiTNjmtsISJcOqvyCUVd.get('imgClearlogo')
    if MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('stillcut') !=MAEWYuQheFBiTNjmtsISJcOqvyCUHG:MAEWYuQheFBiTNjmtsISJcOqvyCUHk =MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('stillcut').get('large')
    if MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('tv_season_stillcut')!=MAEWYuQheFBiTNjmtsISJcOqvyCUHG:MAEWYuQheFBiTNjmtsISJcOqvyCUHz=MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('tv_season_stillcut').get('large')
    MAEWYuQheFBiTNjmtsISJcOqvyCUrf={'thumb':MAEWYuQheFBiTNjmtsISJcOqvyCUHk,'poster':MAEWYuQheFBiTNjmtsISJcOqvyCUrg,'fanart':MAEWYuQheFBiTNjmtsISJcOqvyCUHz,'clearlogo':MAEWYuQheFBiTNjmtsISJcOqvyCUVx}
    MAEWYuQheFBiTNjmtsISJcOqvyCUVa =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['display_number']
    MAEWYuQheFBiTNjmtsISJcOqvyCUVn=MAEWYuQheFBiTNjmtsISJcOqvyCUrH['tv_season_title']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrG =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['duration']
    try:
     MAEWYuQheFBiTNjmtsISJcOqvyCUVp=MAEWYuQheFBiTNjmtsISJcOqvyCUrH['episode_number']
    except:
     MAEWYuQheFBiTNjmtsISJcOqvyCUVp='0'
    MAEWYuQheFBiTNjmtsISJcOqvyCUrx={'code':MAEWYuQheFBiTNjmtsISJcOqvyCUrp,'title':MAEWYuQheFBiTNjmtsISJcOqvyCUrL,'thumbnail':MAEWYuQheFBiTNjmtsISJcOqvyCUrf,'display_num':MAEWYuQheFBiTNjmtsISJcOqvyCUVa,'season_title':MAEWYuQheFBiTNjmtsISJcOqvyCUVn,'duration':MAEWYuQheFBiTNjmtsISJcOqvyCUrG,'episode_number':MAEWYuQheFBiTNjmtsISJcOqvyCUVp}
    MAEWYuQheFBiTNjmtsISJcOqvyCUXG.append(MAEWYuQheFBiTNjmtsISJcOqvyCUrx)
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   MAEWYuQheFBiTNjmtsISJcOqvyCUPr(exception)
  return MAEWYuQheFBiTNjmtsISJcOqvyCUXG,MAEWYuQheFBiTNjmtsISJcOqvyCUra
 def GetSearchList(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,search_key,page_int):
  MAEWYuQheFBiTNjmtsISJcOqvyCUVR=[]
  MAEWYuQheFBiTNjmtsISJcOqvyCUra=MAEWYuQheFBiTNjmtsISJcOqvyCUHb
  try:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXb ='/api/search.json'
   MAEWYuQheFBiTNjmtsISJcOqvyCUXw=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN+MAEWYuQheFBiTNjmtsISJcOqvyCUXb
   MAEWYuQheFBiTNjmtsISJcOqvyCUrn={'query':search_key,'page':MAEWYuQheFBiTNjmtsISJcOqvyCUPV(page_int),'per':MAEWYuQheFBiTNjmtsISJcOqvyCUPV(MAEWYuQheFBiTNjmtsISJcOqvyCUXV.SEARCH_LIMIT),'exclude':'limited'}
   MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Get',MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUrn,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUHG)
   MAEWYuQheFBiTNjmtsISJcOqvyCUrX=json.loads(MAEWYuQheFBiTNjmtsISJcOqvyCUXf.text)
   if not('results' in MAEWYuQheFBiTNjmtsISJcOqvyCUrX):return MAEWYuQheFBiTNjmtsISJcOqvyCUVR,MAEWYuQheFBiTNjmtsISJcOqvyCUra
   MAEWYuQheFBiTNjmtsISJcOqvyCUrV=MAEWYuQheFBiTNjmtsISJcOqvyCUrX['results']
   MAEWYuQheFBiTNjmtsISJcOqvyCUra=MAEWYuQheFBiTNjmtsISJcOqvyCUrX['meta']['has_next']
   for MAEWYuQheFBiTNjmtsISJcOqvyCUrH in MAEWYuQheFBiTNjmtsISJcOqvyCUrV:
    MAEWYuQheFBiTNjmtsISJcOqvyCUrp =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['code']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrR=MAEWYuQheFBiTNjmtsISJcOqvyCUrH['content_type']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrL =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['title']
    MAEWYuQheFBiTNjmtsISJcOqvyCUro =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['story']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrg=MAEWYuQheFBiTNjmtsISJcOqvyCUHk=MAEWYuQheFBiTNjmtsISJcOqvyCUHz=''
    if MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('poster') !=MAEWYuQheFBiTNjmtsISJcOqvyCUHG:MAEWYuQheFBiTNjmtsISJcOqvyCUrg=MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('poster').get('original')
    if MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('stillcut')!=MAEWYuQheFBiTNjmtsISJcOqvyCUHG:MAEWYuQheFBiTNjmtsISJcOqvyCUHk =MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('stillcut').get('large')
    if MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('thumbnail')!=MAEWYuQheFBiTNjmtsISJcOqvyCUHG:MAEWYuQheFBiTNjmtsISJcOqvyCUHz=MAEWYuQheFBiTNjmtsISJcOqvyCUrH.get('thumbnail').get('large')
    if MAEWYuQheFBiTNjmtsISJcOqvyCUHz=='' :MAEWYuQheFBiTNjmtsISJcOqvyCUHz=MAEWYuQheFBiTNjmtsISJcOqvyCUHk
    MAEWYuQheFBiTNjmtsISJcOqvyCUrf={'thumb':MAEWYuQheFBiTNjmtsISJcOqvyCUHk,'poster':MAEWYuQheFBiTNjmtsISJcOqvyCUrg,'fanart':MAEWYuQheFBiTNjmtsISJcOqvyCUHz}
    MAEWYuQheFBiTNjmtsISJcOqvyCUrl =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['year']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrz =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['film_rating_code']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrk=MAEWYuQheFBiTNjmtsISJcOqvyCUrH['film_rating_short']
    MAEWYuQheFBiTNjmtsISJcOqvyCUrD =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['film_rating_long']
    if MAEWYuQheFBiTNjmtsISJcOqvyCUrR=='movies':
     MAEWYuQheFBiTNjmtsISJcOqvyCUrG =MAEWYuQheFBiTNjmtsISJcOqvyCUrH['duration']
    else:
     MAEWYuQheFBiTNjmtsISJcOqvyCUrG ='0'
    MAEWYuQheFBiTNjmtsISJcOqvyCUrx={'code':MAEWYuQheFBiTNjmtsISJcOqvyCUrp,'content_type':MAEWYuQheFBiTNjmtsISJcOqvyCUrR,'title':MAEWYuQheFBiTNjmtsISJcOqvyCUrL,'story':MAEWYuQheFBiTNjmtsISJcOqvyCUro,'thumbnail':MAEWYuQheFBiTNjmtsISJcOqvyCUrf,'year':MAEWYuQheFBiTNjmtsISJcOqvyCUrl,'film_rating_code':MAEWYuQheFBiTNjmtsISJcOqvyCUrz,'film_rating_short':MAEWYuQheFBiTNjmtsISJcOqvyCUrk,'film_rating_long':MAEWYuQheFBiTNjmtsISJcOqvyCUrD,'duration':MAEWYuQheFBiTNjmtsISJcOqvyCUrG}
    MAEWYuQheFBiTNjmtsISJcOqvyCUVR.append(MAEWYuQheFBiTNjmtsISJcOqvyCUrx)
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   MAEWYuQheFBiTNjmtsISJcOqvyCUPr(exception)
  return MAEWYuQheFBiTNjmtsISJcOqvyCUVR,MAEWYuQheFBiTNjmtsISJcOqvyCUra
 def GetProfilesList(MAEWYuQheFBiTNjmtsISJcOqvyCUXV):
  MAEWYuQheFBiTNjmtsISJcOqvyCUXk=[]
  try:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXb ='/manage_profiles'
   MAEWYuQheFBiTNjmtsISJcOqvyCUXw=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.MAIN_DOMAIN+MAEWYuQheFBiTNjmtsISJcOqvyCUXb
   MAEWYuQheFBiTNjmtsISJcOqvyCUXl=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.makeDefaultCookies()
   MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Get',MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUXl,redirects=MAEWYuQheFBiTNjmtsISJcOqvyCUHw)
   MAEWYuQheFBiTNjmtsISJcOqvyCUVL=MAEWYuQheFBiTNjmtsISJcOqvyCUXf.text
   MAEWYuQheFBiTNjmtsISJcOqvyCUVo =re.findall('/api/users/me.{8000}',MAEWYuQheFBiTNjmtsISJcOqvyCUVL)[0]
   MAEWYuQheFBiTNjmtsISJcOqvyCUVo =MAEWYuQheFBiTNjmtsISJcOqvyCUVo.replace('&quot;','')
   MAEWYuQheFBiTNjmtsISJcOqvyCUXk=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',MAEWYuQheFBiTNjmtsISJcOqvyCUVo)
   for i in MAEWYuQheFBiTNjmtsISJcOqvyCUPd(MAEWYuQheFBiTNjmtsISJcOqvyCUPH(MAEWYuQheFBiTNjmtsISJcOqvyCUXk)):
    MAEWYuQheFBiTNjmtsISJcOqvyCUVg=MAEWYuQheFBiTNjmtsISJcOqvyCUXk[i]
    MAEWYuQheFBiTNjmtsISJcOqvyCUVg =MAEWYuQheFBiTNjmtsISJcOqvyCUVg.split(':')[1]
    MAEWYuQheFBiTNjmtsISJcOqvyCUXk[i]=MAEWYuQheFBiTNjmtsISJcOqvyCUVg.split(',')[0]
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   MAEWYuQheFBiTNjmtsISJcOqvyCUPr(exception)
  return MAEWYuQheFBiTNjmtsISJcOqvyCUXk
 def GetProfilesConvert(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,MAEWYuQheFBiTNjmtsISJcOqvyCUXd):
  MAEWYuQheFBiTNjmtsISJcOqvyCUVf=''
  MAEWYuQheFBiTNjmtsISJcOqvyCUVl=''
  try:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXb ='/api/users/'+MAEWYuQheFBiTNjmtsISJcOqvyCUXd+'/convert'
   MAEWYuQheFBiTNjmtsISJcOqvyCUXw=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN+MAEWYuQheFBiTNjmtsISJcOqvyCUXb
   MAEWYuQheFBiTNjmtsISJcOqvyCUXl=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.makeDefaultCookies()
   MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Put',MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUXl)
   for MAEWYuQheFBiTNjmtsISJcOqvyCUXl in MAEWYuQheFBiTNjmtsISJcOqvyCUXf.cookies:
    if MAEWYuQheFBiTNjmtsISJcOqvyCUXl.name=='_s_guitv':
     MAEWYuQheFBiTNjmtsISJcOqvyCUVz=MAEWYuQheFBiTNjmtsISJcOqvyCUXl.value
    elif MAEWYuQheFBiTNjmtsISJcOqvyCUXl.name=='_guinness-premium_session':
     MAEWYuQheFBiTNjmtsISJcOqvyCUXz=MAEWYuQheFBiTNjmtsISJcOqvyCUXl.value
   if MAEWYuQheFBiTNjmtsISJcOqvyCUVz:
    MAEWYuQheFBiTNjmtsISJcOqvyCUVf=MAEWYuQheFBiTNjmtsISJcOqvyCUVz
   if MAEWYuQheFBiTNjmtsISJcOqvyCUXz:
    MAEWYuQheFBiTNjmtsISJcOqvyCUVl=MAEWYuQheFBiTNjmtsISJcOqvyCUXz
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   MAEWYuQheFBiTNjmtsISJcOqvyCUVf=''
   MAEWYuQheFBiTNjmtsISJcOqvyCUVl=''
  return MAEWYuQheFBiTNjmtsISJcOqvyCUVf,MAEWYuQheFBiTNjmtsISJcOqvyCUVl
 def Get_Now_Datetime(MAEWYuQheFBiTNjmtsISJcOqvyCUXV):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,movie_code,quality_str):
  MAEWYuQheFBiTNjmtsISJcOqvyCUVD=MAEWYuQheFBiTNjmtsISJcOqvyCUVb=MAEWYuQheFBiTNjmtsISJcOqvyCUHP=''
  try:
   MAEWYuQheFBiTNjmtsISJcOqvyCUXb='/api/watch/'+movie_code+'.json'
   MAEWYuQheFBiTNjmtsISJcOqvyCUXw=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN+MAEWYuQheFBiTNjmtsISJcOqvyCUXb
   MAEWYuQheFBiTNjmtsISJcOqvyCUXg={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   MAEWYuQheFBiTNjmtsISJcOqvyCUXl=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.makeDefaultCookies()
   MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Get',MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUXg,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUXl)
   MAEWYuQheFBiTNjmtsISJcOqvyCUrX=json.loads(MAEWYuQheFBiTNjmtsISJcOqvyCUXf.text)
   MAEWYuQheFBiTNjmtsISJcOqvyCUVD=MAEWYuQheFBiTNjmtsISJcOqvyCUrX['streams'][0]['source']
   if MAEWYuQheFBiTNjmtsISJcOqvyCUVD==MAEWYuQheFBiTNjmtsISJcOqvyCUHG:return(MAEWYuQheFBiTNjmtsISJcOqvyCUVD,MAEWYuQheFBiTNjmtsISJcOqvyCUVb,MAEWYuQheFBiTNjmtsISJcOqvyCUHP)
   if 'subtitles' in MAEWYuQheFBiTNjmtsISJcOqvyCUrX['streams'][0]:
    for MAEWYuQheFBiTNjmtsISJcOqvyCUVG in MAEWYuQheFBiTNjmtsISJcOqvyCUrX['streams'][0]['subtitles']:
     if MAEWYuQheFBiTNjmtsISJcOqvyCUVG['lang']=='ko':
      MAEWYuQheFBiTNjmtsISJcOqvyCUVb=MAEWYuQheFBiTNjmtsISJcOqvyCUVG['url']
      break
   MAEWYuQheFBiTNjmtsISJcOqvyCUVw =MAEWYuQheFBiTNjmtsISJcOqvyCUrX['ping_payload']
   MAEWYuQheFBiTNjmtsISJcOqvyCUHX =MAEWYuQheFBiTNjmtsISJcOqvyCUXV.WATCHA_USERCD
   MAEWYuQheFBiTNjmtsISJcOqvyCUHr={'merchant':'giitd_frograms','sessionId':MAEWYuQheFBiTNjmtsISJcOqvyCUVw,'userId':MAEWYuQheFBiTNjmtsISJcOqvyCUHX}
   MAEWYuQheFBiTNjmtsISJcOqvyCUHV=json.dumps(MAEWYuQheFBiTNjmtsISJcOqvyCUHr,separators=(",",":")).encode('UTF-8')
   MAEWYuQheFBiTNjmtsISJcOqvyCUHP=base64.b64encode(MAEWYuQheFBiTNjmtsISJcOqvyCUHV)
  except MAEWYuQheFBiTNjmtsISJcOqvyCUPX as exception:
   return(MAEWYuQheFBiTNjmtsISJcOqvyCUVD,MAEWYuQheFBiTNjmtsISJcOqvyCUVb,MAEWYuQheFBiTNjmtsISJcOqvyCUHP)
  return(MAEWYuQheFBiTNjmtsISJcOqvyCUVD,MAEWYuQheFBiTNjmtsISJcOqvyCUVb,MAEWYuQheFBiTNjmtsISJcOqvyCUHP) 
 def GetBookmarkInfo(MAEWYuQheFBiTNjmtsISJcOqvyCUXV,videoid,vidtype):
  MAEWYuQheFBiTNjmtsISJcOqvyCUHK={'indexinfo':{'ott':'watcha','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  MAEWYuQheFBiTNjmtsISJcOqvyCUXw=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.API_DOMAIN+'/api/contents/'+videoid
  MAEWYuQheFBiTNjmtsISJcOqvyCUXf=MAEWYuQheFBiTNjmtsISJcOqvyCUXV.callRequestCookies('Get',MAEWYuQheFBiTNjmtsISJcOqvyCUXw,payload=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,params=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,headers=MAEWYuQheFBiTNjmtsISJcOqvyCUHG,cookies=MAEWYuQheFBiTNjmtsISJcOqvyCUHG)
  MAEWYuQheFBiTNjmtsISJcOqvyCUHd=json.loads(MAEWYuQheFBiTNjmtsISJcOqvyCUXf.text)
  if not('title' in MAEWYuQheFBiTNjmtsISJcOqvyCUHd):return{}
  MAEWYuQheFBiTNjmtsISJcOqvyCUHx=MAEWYuQheFBiTNjmtsISJcOqvyCUHd
  MAEWYuQheFBiTNjmtsISJcOqvyCUPr(MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('duration'))
  MAEWYuQheFBiTNjmtsISJcOqvyCUHa=MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('title')
  MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['infoLabels']['title']=MAEWYuQheFBiTNjmtsISJcOqvyCUHa
  MAEWYuQheFBiTNjmtsISJcOqvyCUHa +=u'  (%s)'%(MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('year'))
  MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['title'] =MAEWYuQheFBiTNjmtsISJcOqvyCUHa
  MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['infoLabels']['mpaa'] =MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('film_rating_long')
  MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['infoLabels']['plot'] =MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('story').replace('<br>','\n')
  MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['infoLabels']['year'] =MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('year')
  if vidtype=='movie':
   MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['infoLabels']['duration']=MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('duration')
  MAEWYuQheFBiTNjmtsISJcOqvyCUHn=[]
  for MAEWYuQheFBiTNjmtsISJcOqvyCUHp in MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('actors'):
   MAEWYuQheFBiTNjmtsISJcOqvyCUHR =MAEWYuQheFBiTNjmtsISJcOqvyCUHp.get('name')
   MAEWYuQheFBiTNjmtsISJcOqvyCUHL='' if MAEWYuQheFBiTNjmtsISJcOqvyCUHp.get('photo')==MAEWYuQheFBiTNjmtsISJcOqvyCUHG else MAEWYuQheFBiTNjmtsISJcOqvyCUHp.get('photo').get('small')
   MAEWYuQheFBiTNjmtsISJcOqvyCUHn.append({'name':MAEWYuQheFBiTNjmtsISJcOqvyCUHR,'thumbnail':MAEWYuQheFBiTNjmtsISJcOqvyCUHL})
  if MAEWYuQheFBiTNjmtsISJcOqvyCUPH(MAEWYuQheFBiTNjmtsISJcOqvyCUHn)>0:
   MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['infoLabels']['cast']=MAEWYuQheFBiTNjmtsISJcOqvyCUHn
  MAEWYuQheFBiTNjmtsISJcOqvyCUHo=[]
  for MAEWYuQheFBiTNjmtsISJcOqvyCUHg in MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('directors'):MAEWYuQheFBiTNjmtsISJcOqvyCUHo.append(MAEWYuQheFBiTNjmtsISJcOqvyCUHg.get('name'))
  if MAEWYuQheFBiTNjmtsISJcOqvyCUPH(MAEWYuQheFBiTNjmtsISJcOqvyCUHo)>0:
   MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['infoLabels']['director']=MAEWYuQheFBiTNjmtsISJcOqvyCUHo
  MAEWYuQheFBiTNjmtsISJcOqvyCUHf=[]
  for MAEWYuQheFBiTNjmtsISJcOqvyCUHl in MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('genres'):MAEWYuQheFBiTNjmtsISJcOqvyCUHf.append(MAEWYuQheFBiTNjmtsISJcOqvyCUHl.get('name'))
  if MAEWYuQheFBiTNjmtsISJcOqvyCUPH(MAEWYuQheFBiTNjmtsISJcOqvyCUHf)>0:
   MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['infoLabels']['genre']=MAEWYuQheFBiTNjmtsISJcOqvyCUHf
  MAEWYuQheFBiTNjmtsISJcOqvyCUrg =''
  MAEWYuQheFBiTNjmtsISJcOqvyCUHz =''
  MAEWYuQheFBiTNjmtsISJcOqvyCUHk =''
  if MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('poster') !=MAEWYuQheFBiTNjmtsISJcOqvyCUHG:MAEWYuQheFBiTNjmtsISJcOqvyCUrg =MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('poster').get('original')
  if MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('thumbnail')!=MAEWYuQheFBiTNjmtsISJcOqvyCUHG:MAEWYuQheFBiTNjmtsISJcOqvyCUHz =MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('thumbnail').get('large')
  if MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('stillcut')!=MAEWYuQheFBiTNjmtsISJcOqvyCUHG:MAEWYuQheFBiTNjmtsISJcOqvyCUHk =MAEWYuQheFBiTNjmtsISJcOqvyCUHx.get('stillcut').get('large')
  if MAEWYuQheFBiTNjmtsISJcOqvyCUHz=='':MAEWYuQheFBiTNjmtsISJcOqvyCUHz=MAEWYuQheFBiTNjmtsISJcOqvyCUHk
  MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['thumbnail']['poster']=MAEWYuQheFBiTNjmtsISJcOqvyCUrg
  MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['thumbnail']['fanart']=MAEWYuQheFBiTNjmtsISJcOqvyCUHz
  MAEWYuQheFBiTNjmtsISJcOqvyCUHK['saveinfo']['thumbnail']['thumb']=MAEWYuQheFBiTNjmtsISJcOqvyCUHk
  return MAEWYuQheFBiTNjmtsISJcOqvyCUHK
# Created by pyminifier (https://github.com/liftoff/pyminifier)
