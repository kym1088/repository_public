__author__="NightRain"
IpiXMJgfCzbDdPVoSrnlWQNBULheqa=object
IpiXMJgfCzbDdPVoSrnlWQNBULheqk=None
IpiXMJgfCzbDdPVoSrnlWQNBULheqR=int
IpiXMJgfCzbDdPVoSrnlWQNBULheqA=True
IpiXMJgfCzbDdPVoSrnlWQNBULheqt=False
IpiXMJgfCzbDdPVoSrnlWQNBULheqO=type
IpiXMJgfCzbDdPVoSrnlWQNBULheqx=dict
IpiXMJgfCzbDdPVoSrnlWQNBULheqG=len
IpiXMJgfCzbDdPVoSrnlWQNBULheqE=range
IpiXMJgfCzbDdPVoSrnlWQNBULheqw=str
IpiXMJgfCzbDdPVoSrnlWQNBULheqH=open
IpiXMJgfCzbDdPVoSrnlWQNBULheqY=Exception
IpiXMJgfCzbDdPVoSrnlWQNBULheuT=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
IpiXMJgfCzbDdPVoSrnlWQNBULheTK=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-','icon':'history.png'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','sort':'-','icon':'bookmark.png'}]
IpiXMJgfCzbDdPVoSrnlWQNBULheTv=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
IpiXMJgfCzbDdPVoSrnlWQNBULheTF=40
IpiXMJgfCzbDdPVoSrnlWQNBULheTc =20
IpiXMJgfCzbDdPVoSrnlWQNBULheTq =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
IpiXMJgfCzbDdPVoSrnlWQNBULheTu =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.srt'))
IpiXMJgfCzbDdPVoSrnlWQNBULheTs =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
IpiXMJgfCzbDdPVoSrnlWQNBULheTm=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
from watchaCore import*
class IpiXMJgfCzbDdPVoSrnlWQNBULheTy(IpiXMJgfCzbDdPVoSrnlWQNBULheqa):
 def __init__(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,IpiXMJgfCzbDdPVoSrnlWQNBULheTa,IpiXMJgfCzbDdPVoSrnlWQNBULheTk,IpiXMJgfCzbDdPVoSrnlWQNBULheTR):
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_url =IpiXMJgfCzbDdPVoSrnlWQNBULheTa
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle=IpiXMJgfCzbDdPVoSrnlWQNBULheTk
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params =IpiXMJgfCzbDdPVoSrnlWQNBULheTR
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj =MAEWYuQheFBiTNjmtsISJcOqvyCUXr() 
 def addon_noti(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,sting):
  try:
   IpiXMJgfCzbDdPVoSrnlWQNBULheTt=xbmcgui.Dialog()
   IpiXMJgfCzbDdPVoSrnlWQNBULheTt.notification(__addonname__,sting)
  except:
   IpiXMJgfCzbDdPVoSrnlWQNBULheqk
 def addon_log(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,string):
  try:
   IpiXMJgfCzbDdPVoSrnlWQNBULheTO=string.encode('utf-8','ignore')
  except:
   IpiXMJgfCzbDdPVoSrnlWQNBULheTO='addonException: addon_log'
  IpiXMJgfCzbDdPVoSrnlWQNBULheTx=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,IpiXMJgfCzbDdPVoSrnlWQNBULheTO),level=IpiXMJgfCzbDdPVoSrnlWQNBULheTx)
 def get_keyboard_input(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,IpiXMJgfCzbDdPVoSrnlWQNBULheyk):
  IpiXMJgfCzbDdPVoSrnlWQNBULheTG=IpiXMJgfCzbDdPVoSrnlWQNBULheqk
  kb=xbmc.Keyboard()
  kb.setHeading(IpiXMJgfCzbDdPVoSrnlWQNBULheyk)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   IpiXMJgfCzbDdPVoSrnlWQNBULheTG=kb.getText()
  return IpiXMJgfCzbDdPVoSrnlWQNBULheTG
 def get_settings_login_info(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  IpiXMJgfCzbDdPVoSrnlWQNBULheTE =__addon__.getSetting('id')
  IpiXMJgfCzbDdPVoSrnlWQNBULheTw =__addon__.getSetting('pw')
  IpiXMJgfCzbDdPVoSrnlWQNBULheTH=IpiXMJgfCzbDdPVoSrnlWQNBULheqR(__addon__.getSetting('selected_profile'))
  return(IpiXMJgfCzbDdPVoSrnlWQNBULheTE,IpiXMJgfCzbDdPVoSrnlWQNBULheTw,IpiXMJgfCzbDdPVoSrnlWQNBULheTH)
 def get_settings_totalsearch(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  IpiXMJgfCzbDdPVoSrnlWQNBULheTY =IpiXMJgfCzbDdPVoSrnlWQNBULheqA if __addon__.getSetting('local_search')=='true' else IpiXMJgfCzbDdPVoSrnlWQNBULheqt
  IpiXMJgfCzbDdPVoSrnlWQNBULheyT=IpiXMJgfCzbDdPVoSrnlWQNBULheqA if __addon__.getSetting('local_history')=='true' else IpiXMJgfCzbDdPVoSrnlWQNBULheqt
  IpiXMJgfCzbDdPVoSrnlWQNBULheyK =IpiXMJgfCzbDdPVoSrnlWQNBULheqA if __addon__.getSetting('total_search')=='true' else IpiXMJgfCzbDdPVoSrnlWQNBULheqt
  IpiXMJgfCzbDdPVoSrnlWQNBULheyv=IpiXMJgfCzbDdPVoSrnlWQNBULheqA if __addon__.getSetting('total_history')=='true' else IpiXMJgfCzbDdPVoSrnlWQNBULheqt
  IpiXMJgfCzbDdPVoSrnlWQNBULheyF=IpiXMJgfCzbDdPVoSrnlWQNBULheqA if __addon__.getSetting('menu_bookmark')=='true' else IpiXMJgfCzbDdPVoSrnlWQNBULheqt
  return(IpiXMJgfCzbDdPVoSrnlWQNBULheTY,IpiXMJgfCzbDdPVoSrnlWQNBULheyT,IpiXMJgfCzbDdPVoSrnlWQNBULheyK,IpiXMJgfCzbDdPVoSrnlWQNBULheyv,IpiXMJgfCzbDdPVoSrnlWQNBULheyF)
 def get_settings_makebookmark(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  return IpiXMJgfCzbDdPVoSrnlWQNBULheqA if __addon__.getSetting('make_bookmark')=='true' else IpiXMJgfCzbDdPVoSrnlWQNBULheqt
 def get_selQuality(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  try:
   IpiXMJgfCzbDdPVoSrnlWQNBULheyc=['3840x2160/1','1920x1080/1','1280x720/1']
   IpiXMJgfCzbDdPVoSrnlWQNBULheyq=IpiXMJgfCzbDdPVoSrnlWQNBULheqR(__addon__.getSetting('selected_quality'))
   return IpiXMJgfCzbDdPVoSrnlWQNBULheyc[IpiXMJgfCzbDdPVoSrnlWQNBULheyq]
  except:
   IpiXMJgfCzbDdPVoSrnlWQNBULheqk
  return 1080 
 def get_settings_direct_replay(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  IpiXMJgfCzbDdPVoSrnlWQNBULheyu=IpiXMJgfCzbDdPVoSrnlWQNBULheqR(__addon__.getSetting('direct_replay'))
  if IpiXMJgfCzbDdPVoSrnlWQNBULheyu==0:
   return IpiXMJgfCzbDdPVoSrnlWQNBULheqt
  else:
   return IpiXMJgfCzbDdPVoSrnlWQNBULheqA
 def set_winCredential(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,credential):
  IpiXMJgfCzbDdPVoSrnlWQNBULheys=xbmcgui.Window(10000)
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_LOGINTIME',IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  IpiXMJgfCzbDdPVoSrnlWQNBULheys=xbmcgui.Window(10000)
  IpiXMJgfCzbDdPVoSrnlWQNBULheym={'watcha_token':IpiXMJgfCzbDdPVoSrnlWQNBULheys.getProperty('WATCHA_M_TOKEN'),'watcha_guit':IpiXMJgfCzbDdPVoSrnlWQNBULheys.getProperty('WATCHA_M_GUIT'),'watcha_guitv':IpiXMJgfCzbDdPVoSrnlWQNBULheys.getProperty('WATCHA_M_GUITV'),'watcha_usercd':IpiXMJgfCzbDdPVoSrnlWQNBULheys.getProperty('WATCHA_M_USERCD')}
  return IpiXMJgfCzbDdPVoSrnlWQNBULheym
 def set_winEpisodeOrderby(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,IpiXMJgfCzbDdPVoSrnlWQNBULheyj):
  IpiXMJgfCzbDdPVoSrnlWQNBULheys=xbmcgui.Window(10000)
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_ORDERBY',IpiXMJgfCzbDdPVoSrnlWQNBULheyj)
 def get_winEpisodeOrderby(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  IpiXMJgfCzbDdPVoSrnlWQNBULheys=xbmcgui.Window(10000)
  return IpiXMJgfCzbDdPVoSrnlWQNBULheys.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheyj =args.get('orderby')
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.set_winEpisodeOrderby(IpiXMJgfCzbDdPVoSrnlWQNBULheyj)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,label,sublabel='',img='',infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheqk,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqA,params='',isLink=IpiXMJgfCzbDdPVoSrnlWQNBULheqt,ContextMenu=IpiXMJgfCzbDdPVoSrnlWQNBULheqk):
  IpiXMJgfCzbDdPVoSrnlWQNBULheya='%s?%s'%(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_url,urllib.parse.urlencode(params))
  if sublabel:IpiXMJgfCzbDdPVoSrnlWQNBULheyk='%s < %s >'%(label,sublabel)
  else: IpiXMJgfCzbDdPVoSrnlWQNBULheyk=label
  if not img:img='DefaultFolder.png'
  IpiXMJgfCzbDdPVoSrnlWQNBULheyR=xbmcgui.ListItem(IpiXMJgfCzbDdPVoSrnlWQNBULheyk)
  if IpiXMJgfCzbDdPVoSrnlWQNBULheqO(img)==IpiXMJgfCzbDdPVoSrnlWQNBULheqx:
   IpiXMJgfCzbDdPVoSrnlWQNBULheyR.setArt(img)
  else:
   IpiXMJgfCzbDdPVoSrnlWQNBULheyR.setArt({'thumb':img,'poster':img})
  if infoLabels:IpiXMJgfCzbDdPVoSrnlWQNBULheyR.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   IpiXMJgfCzbDdPVoSrnlWQNBULheyR.setProperty('IsPlayable','true')
  if ContextMenu:IpiXMJgfCzbDdPVoSrnlWQNBULheyR.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,IpiXMJgfCzbDdPVoSrnlWQNBULheya,IpiXMJgfCzbDdPVoSrnlWQNBULheyR,isFolder)
 def dp_Main_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  (IpiXMJgfCzbDdPVoSrnlWQNBULheTY,IpiXMJgfCzbDdPVoSrnlWQNBULheyT,IpiXMJgfCzbDdPVoSrnlWQNBULheyK,IpiXMJgfCzbDdPVoSrnlWQNBULheyv,IpiXMJgfCzbDdPVoSrnlWQNBULheyF)=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_settings_totalsearch()
  for IpiXMJgfCzbDdPVoSrnlWQNBULheyA in IpiXMJgfCzbDdPVoSrnlWQNBULheTK:
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk=IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('title')
   IpiXMJgfCzbDdPVoSrnlWQNBULheyt=''
   if IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('mode')=='LOCAL_SEARCH' and IpiXMJgfCzbDdPVoSrnlWQNBULheTY ==IpiXMJgfCzbDdPVoSrnlWQNBULheqt:continue
   elif IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('mode')=='SEARCH_HISTORY' and IpiXMJgfCzbDdPVoSrnlWQNBULheyT==IpiXMJgfCzbDdPVoSrnlWQNBULheqt:continue
   elif IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('mode')=='TOTAL_SEARCH' and IpiXMJgfCzbDdPVoSrnlWQNBULheyK ==IpiXMJgfCzbDdPVoSrnlWQNBULheqt:continue
   elif IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('mode')=='TOTAL_HISTORY' and IpiXMJgfCzbDdPVoSrnlWQNBULheyv==IpiXMJgfCzbDdPVoSrnlWQNBULheqt:continue
   elif IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('mode')=='MENU_BOOKMARK' and IpiXMJgfCzbDdPVoSrnlWQNBULheyF==IpiXMJgfCzbDdPVoSrnlWQNBULheqt:continue
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('mode'),'stype':IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('stype'),'api_path':IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('api_path'),'page':'1','sort':IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('sort'),'tag_id':'-'}
   if IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('mode')=='LOCAL_SEARCH':IpiXMJgfCzbDdPVoSrnlWQNBULheyO['historyyn']='Y' 
   if IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    IpiXMJgfCzbDdPVoSrnlWQNBULheyx=IpiXMJgfCzbDdPVoSrnlWQNBULheqt
    IpiXMJgfCzbDdPVoSrnlWQNBULheyG =IpiXMJgfCzbDdPVoSrnlWQNBULheqA
   else:
    IpiXMJgfCzbDdPVoSrnlWQNBULheyx=IpiXMJgfCzbDdPVoSrnlWQNBULheqA
    IpiXMJgfCzbDdPVoSrnlWQNBULheyG =IpiXMJgfCzbDdPVoSrnlWQNBULheqt
   if 'icon' in IpiXMJgfCzbDdPVoSrnlWQNBULheyA:IpiXMJgfCzbDdPVoSrnlWQNBULheyt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',IpiXMJgfCzbDdPVoSrnlWQNBULheyA.get('icon')) 
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel='',img=IpiXMJgfCzbDdPVoSrnlWQNBULheyt,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheqk,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheyx,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO,isLink=IpiXMJgfCzbDdPVoSrnlWQNBULheyG)
  xbmcplugin.endOfDirectory(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle)
 def login_main(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  (IpiXMJgfCzbDdPVoSrnlWQNBULheyw,IpiXMJgfCzbDdPVoSrnlWQNBULheyH,IpiXMJgfCzbDdPVoSrnlWQNBULheyY)=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_settings_login_info()
  if not(IpiXMJgfCzbDdPVoSrnlWQNBULheyw and IpiXMJgfCzbDdPVoSrnlWQNBULheyH):
   IpiXMJgfCzbDdPVoSrnlWQNBULheTt=xbmcgui.Dialog()
   IpiXMJgfCzbDdPVoSrnlWQNBULheKT=IpiXMJgfCzbDdPVoSrnlWQNBULheTt.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if IpiXMJgfCzbDdPVoSrnlWQNBULheKT==IpiXMJgfCzbDdPVoSrnlWQNBULheqA:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_winEpisodeOrderby()=='':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.set_winEpisodeOrderby('asc')
  if IpiXMJgfCzbDdPVoSrnlWQNBULheTj.cookiefile_check():return
  IpiXMJgfCzbDdPVoSrnlWQNBULheKy =IpiXMJgfCzbDdPVoSrnlWQNBULheqR(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  IpiXMJgfCzbDdPVoSrnlWQNBULheKv=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKv==IpiXMJgfCzbDdPVoSrnlWQNBULheqk or IpiXMJgfCzbDdPVoSrnlWQNBULheKv=='':
   IpiXMJgfCzbDdPVoSrnlWQNBULheKv=IpiXMJgfCzbDdPVoSrnlWQNBULheqR('19000101')
  else:
   IpiXMJgfCzbDdPVoSrnlWQNBULheKv=IpiXMJgfCzbDdPVoSrnlWQNBULheqR(re.sub('-','',IpiXMJgfCzbDdPVoSrnlWQNBULheKv))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   IpiXMJgfCzbDdPVoSrnlWQNBULheKF=0
   while IpiXMJgfCzbDdPVoSrnlWQNBULheqA:
    IpiXMJgfCzbDdPVoSrnlWQNBULheKF+=1
    time.sleep(0.05)
    if IpiXMJgfCzbDdPVoSrnlWQNBULheKv>=IpiXMJgfCzbDdPVoSrnlWQNBULheKy:return
    if IpiXMJgfCzbDdPVoSrnlWQNBULheKF>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKv>=IpiXMJgfCzbDdPVoSrnlWQNBULheKy:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.GetCredential(IpiXMJgfCzbDdPVoSrnlWQNBULheyw,IpiXMJgfCzbDdPVoSrnlWQNBULheyH,IpiXMJgfCzbDdPVoSrnlWQNBULheyY):
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.set_winCredential(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.LoadCredential())
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.SaveCredential(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_winCredential())
  IpiXMJgfCzbDdPVoSrnlWQNBULheKc =args.get('stype')
  IpiXMJgfCzbDdPVoSrnlWQNBULheKq =IpiXMJgfCzbDdPVoSrnlWQNBULheqR(args.get('page'))
  IpiXMJgfCzbDdPVoSrnlWQNBULheKu =args.get('sort')
  IpiXMJgfCzbDdPVoSrnlWQNBULheKs=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.GetSubGroupList(IpiXMJgfCzbDdPVoSrnlWQNBULheKc)
  IpiXMJgfCzbDdPVoSrnlWQNBULheKm=IpiXMJgfCzbDdPVoSrnlWQNBULheTF if IpiXMJgfCzbDdPVoSrnlWQNBULheKc=='genres' else IpiXMJgfCzbDdPVoSrnlWQNBULheTc
  IpiXMJgfCzbDdPVoSrnlWQNBULheKj=IpiXMJgfCzbDdPVoSrnlWQNBULheqG(IpiXMJgfCzbDdPVoSrnlWQNBULheKs)
  IpiXMJgfCzbDdPVoSrnlWQNBULheKa =IpiXMJgfCzbDdPVoSrnlWQNBULheqR(IpiXMJgfCzbDdPVoSrnlWQNBULheKj//(IpiXMJgfCzbDdPVoSrnlWQNBULheKm+1))+1
  IpiXMJgfCzbDdPVoSrnlWQNBULheKk =(IpiXMJgfCzbDdPVoSrnlWQNBULheKq-1)*IpiXMJgfCzbDdPVoSrnlWQNBULheKm
  for i in IpiXMJgfCzbDdPVoSrnlWQNBULheqE(IpiXMJgfCzbDdPVoSrnlWQNBULheKm):
   IpiXMJgfCzbDdPVoSrnlWQNBULheKR=IpiXMJgfCzbDdPVoSrnlWQNBULheKk+i
   if IpiXMJgfCzbDdPVoSrnlWQNBULheKR>=IpiXMJgfCzbDdPVoSrnlWQNBULheKj:break
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk =IpiXMJgfCzbDdPVoSrnlWQNBULheKs[IpiXMJgfCzbDdPVoSrnlWQNBULheKR].get('group_name')
   IpiXMJgfCzbDdPVoSrnlWQNBULheKA =IpiXMJgfCzbDdPVoSrnlWQNBULheKs[IpiXMJgfCzbDdPVoSrnlWQNBULheKR].get('api_path')
   IpiXMJgfCzbDdPVoSrnlWQNBULheKt =IpiXMJgfCzbDdPVoSrnlWQNBULheKs[IpiXMJgfCzbDdPVoSrnlWQNBULheKR].get('tag_id')
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':'CATEGORY_LIST','api_path':IpiXMJgfCzbDdPVoSrnlWQNBULheKA,'tag_id':IpiXMJgfCzbDdPVoSrnlWQNBULheKt,'stype':IpiXMJgfCzbDdPVoSrnlWQNBULheKc,'page':'1','sort':IpiXMJgfCzbDdPVoSrnlWQNBULheKu}
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel='',img='',infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheqk,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqA,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO)
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKa>IpiXMJgfCzbDdPVoSrnlWQNBULheKq:
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO={}
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['mode'] ='SUB_GROUP' 
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['stype'] =IpiXMJgfCzbDdPVoSrnlWQNBULheKc
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['api_path']=args.get('api_path')
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['page'] =IpiXMJgfCzbDdPVoSrnlWQNBULheqw(IpiXMJgfCzbDdPVoSrnlWQNBULheKq+1)
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['sort'] =IpiXMJgfCzbDdPVoSrnlWQNBULheKu
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk='[B]%s >>[/B]'%'다음 페이지'
   IpiXMJgfCzbDdPVoSrnlWQNBULheKO=IpiXMJgfCzbDdPVoSrnlWQNBULheqw(IpiXMJgfCzbDdPVoSrnlWQNBULheKq+1)
   IpiXMJgfCzbDdPVoSrnlWQNBULheyt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel=IpiXMJgfCzbDdPVoSrnlWQNBULheKO,img=IpiXMJgfCzbDdPVoSrnlWQNBULheyt,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheqk,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqA,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO)
  if IpiXMJgfCzbDdPVoSrnlWQNBULheqG(IpiXMJgfCzbDdPVoSrnlWQNBULheKs)>0:xbmcplugin.endOfDirectory(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,cacheToDisc=IpiXMJgfCzbDdPVoSrnlWQNBULheqA)
 def play_VIDEO(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.SaveCredential(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_winCredential())
  IpiXMJgfCzbDdPVoSrnlWQNBULheKx =args.get('movie_code')
  IpiXMJgfCzbDdPVoSrnlWQNBULheKG =args.get('season_code')
  IpiXMJgfCzbDdPVoSrnlWQNBULheyk =args.get('title')
  IpiXMJgfCzbDdPVoSrnlWQNBULheKE =args.get('thumbnail')
  IpiXMJgfCzbDdPVoSrnlWQNBULheKw =IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_selQuality()
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.addon_log(IpiXMJgfCzbDdPVoSrnlWQNBULheKx+' - '+IpiXMJgfCzbDdPVoSrnlWQNBULheKG)
  IpiXMJgfCzbDdPVoSrnlWQNBULheKH,IpiXMJgfCzbDdPVoSrnlWQNBULheKY,IpiXMJgfCzbDdPVoSrnlWQNBULhevT=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.GetStreamingURL(IpiXMJgfCzbDdPVoSrnlWQNBULheKx,IpiXMJgfCzbDdPVoSrnlWQNBULheKw)
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKH=='':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.addon_noti(__language__(30908).encode('utf8'))
   return
  IpiXMJgfCzbDdPVoSrnlWQNBULhevy=IpiXMJgfCzbDdPVoSrnlWQNBULheKH
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.addon_log(IpiXMJgfCzbDdPVoSrnlWQNBULhevy)
  IpiXMJgfCzbDdPVoSrnlWQNBULhevK=xbmcgui.ListItem(path=IpiXMJgfCzbDdPVoSrnlWQNBULhevy)
  if IpiXMJgfCzbDdPVoSrnlWQNBULhevT:
   IpiXMJgfCzbDdPVoSrnlWQNBULhevF=IpiXMJgfCzbDdPVoSrnlWQNBULhevT
   IpiXMJgfCzbDdPVoSrnlWQNBULhevc ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   IpiXMJgfCzbDdPVoSrnlWQNBULhevq ='mpd'
   IpiXMJgfCzbDdPVoSrnlWQNBULhevu ='com.widevine.alpha'
   IpiXMJgfCzbDdPVoSrnlWQNBULhevs =inputstreamhelper.Helper(IpiXMJgfCzbDdPVoSrnlWQNBULhevq,drm=IpiXMJgfCzbDdPVoSrnlWQNBULhevu)
   if IpiXMJgfCzbDdPVoSrnlWQNBULhevs.check_inputstream():
    IpiXMJgfCzbDdPVoSrnlWQNBULhevm={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+IpiXMJgfCzbDdPVoSrnlWQNBULheKx,'dt-custom-data':IpiXMJgfCzbDdPVoSrnlWQNBULhevF,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    IpiXMJgfCzbDdPVoSrnlWQNBULhevj=IpiXMJgfCzbDdPVoSrnlWQNBULhevc+'|'+urllib.parse.urlencode(IpiXMJgfCzbDdPVoSrnlWQNBULhevm)+'|R{SSM}|'
    IpiXMJgfCzbDdPVoSrnlWQNBULheTj.addon_log(IpiXMJgfCzbDdPVoSrnlWQNBULhevj)
    IpiXMJgfCzbDdPVoSrnlWQNBULhevK.setProperty('inputstream',IpiXMJgfCzbDdPVoSrnlWQNBULhevs.inputstream_addon)
    IpiXMJgfCzbDdPVoSrnlWQNBULhevK.setProperty('inputstream.adaptive.manifest_type',IpiXMJgfCzbDdPVoSrnlWQNBULhevq)
    IpiXMJgfCzbDdPVoSrnlWQNBULhevK.setProperty('inputstream.adaptive.license_type',IpiXMJgfCzbDdPVoSrnlWQNBULhevu)
    IpiXMJgfCzbDdPVoSrnlWQNBULhevK.setProperty('inputstream.adaptive.license_key',IpiXMJgfCzbDdPVoSrnlWQNBULhevj)
    IpiXMJgfCzbDdPVoSrnlWQNBULhevK.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.USER_AGENT))
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKY:
   try:
    f=IpiXMJgfCzbDdPVoSrnlWQNBULheqH(IpiXMJgfCzbDdPVoSrnlWQNBULheTq,'w',-1,'utf-8')
    IpiXMJgfCzbDdPVoSrnlWQNBULheva=requests.get(IpiXMJgfCzbDdPVoSrnlWQNBULheKY)
    IpiXMJgfCzbDdPVoSrnlWQNBULhevk=IpiXMJgfCzbDdPVoSrnlWQNBULheva.content.decode('utf-8') 
    for IpiXMJgfCzbDdPVoSrnlWQNBULhevR in IpiXMJgfCzbDdPVoSrnlWQNBULhevk.splitlines():
     IpiXMJgfCzbDdPVoSrnlWQNBULhevA=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',IpiXMJgfCzbDdPVoSrnlWQNBULhevR)
     f.write(IpiXMJgfCzbDdPVoSrnlWQNBULhevA+'\n')
    f.close()
    IpiXMJgfCzbDdPVoSrnlWQNBULhevK.setSubtitles([IpiXMJgfCzbDdPVoSrnlWQNBULheTq,IpiXMJgfCzbDdPVoSrnlWQNBULheKY])
   except:
    IpiXMJgfCzbDdPVoSrnlWQNBULhevK.setSubtitles([IpiXMJgfCzbDdPVoSrnlWQNBULheKY])
  xbmcplugin.setResolvedUrl(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,IpiXMJgfCzbDdPVoSrnlWQNBULheqA,IpiXMJgfCzbDdPVoSrnlWQNBULhevK)
  try:
   IpiXMJgfCzbDdPVoSrnlWQNBULheKc='movie' if IpiXMJgfCzbDdPVoSrnlWQNBULheKG=='-' else 'seasons'
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'code':IpiXMJgfCzbDdPVoSrnlWQNBULheKx if IpiXMJgfCzbDdPVoSrnlWQNBULheKc=='movie' else IpiXMJgfCzbDdPVoSrnlWQNBULheKG,'img':IpiXMJgfCzbDdPVoSrnlWQNBULheKE,'title':IpiXMJgfCzbDdPVoSrnlWQNBULheyk,'videoid':IpiXMJgfCzbDdPVoSrnlWQNBULheKx}
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.Save_Watched_List(IpiXMJgfCzbDdPVoSrnlWQNBULheKc,IpiXMJgfCzbDdPVoSrnlWQNBULheyO)
  except:
   IpiXMJgfCzbDdPVoSrnlWQNBULheqk
 def srtConvert(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,IpiXMJgfCzbDdPVoSrnlWQNBULhevO):
  IpiXMJgfCzbDdPVoSrnlWQNBULhevt=re.sub(r'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',IpiXMJgfCzbDdPVoSrnlWQNBULhevO)
  IpiXMJgfCzbDdPVoSrnlWQNBULhevt=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',IpiXMJgfCzbDdPVoSrnlWQNBULhevt)
  IpiXMJgfCzbDdPVoSrnlWQNBULhevt=re.sub(r'(\d\d).(\d\d\d) --> (\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',IpiXMJgfCzbDdPVoSrnlWQNBULhevt)
  IpiXMJgfCzbDdPVoSrnlWQNBULhevt=re.sub(r'WEBVTT\n','',IpiXMJgfCzbDdPVoSrnlWQNBULhevt)
  IpiXMJgfCzbDdPVoSrnlWQNBULhevt=re.sub(r'Kind:[ \-\w]+\n','',IpiXMJgfCzbDdPVoSrnlWQNBULhevt)
  IpiXMJgfCzbDdPVoSrnlWQNBULhevt=re.sub(r'Language:[ \-\w]+\n','',IpiXMJgfCzbDdPVoSrnlWQNBULhevt)
  IpiXMJgfCzbDdPVoSrnlWQNBULhevt=re.sub(r'<c[.\w\d]*>','',IpiXMJgfCzbDdPVoSrnlWQNBULhevt)
  IpiXMJgfCzbDdPVoSrnlWQNBULhevt=re.sub(r'</c>','',IpiXMJgfCzbDdPVoSrnlWQNBULhevt)
  IpiXMJgfCzbDdPVoSrnlWQNBULhevt=re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>','',IpiXMJgfCzbDdPVoSrnlWQNBULhevt)
  IpiXMJgfCzbDdPVoSrnlWQNBULhevt=re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n','',IpiXMJgfCzbDdPVoSrnlWQNBULhevt)
  IpiXMJgfCzbDdPVoSrnlWQNBULhevt=re.sub(r'Style:\n##\n','',IpiXMJgfCzbDdPVoSrnlWQNBULhevt)
  return IpiXMJgfCzbDdPVoSrnlWQNBULhevt
 def vtt_to_srt(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,vttFilename,srtFilename):
  try:
   f=IpiXMJgfCzbDdPVoSrnlWQNBULheqH(vttFilename,'r',-1,'utf-8')
   IpiXMJgfCzbDdPVoSrnlWQNBULhevO=f.read()
   f.close()
   IpiXMJgfCzbDdPVoSrnlWQNBULhevx=''
   IpiXMJgfCzbDdPVoSrnlWQNBULhevx=IpiXMJgfCzbDdPVoSrnlWQNBULhevx+IpiXMJgfCzbDdPVoSrnlWQNBULheTj.srtConvert(IpiXMJgfCzbDdPVoSrnlWQNBULhevO)
   f=IpiXMJgfCzbDdPVoSrnlWQNBULheqH(srtFilename,'w',-1,'utf-8')
   f.writelines(IpiXMJgfCzbDdPVoSrnlWQNBULheqw(IpiXMJgfCzbDdPVoSrnlWQNBULhevx))
   f.close()
  except:
   return IpiXMJgfCzbDdPVoSrnlWQNBULheqt
  return IpiXMJgfCzbDdPVoSrnlWQNBULheqA
 def dp_Category_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.SaveCredential(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_winCredential())
  IpiXMJgfCzbDdPVoSrnlWQNBULheKc =args.get('stype')
  IpiXMJgfCzbDdPVoSrnlWQNBULheKt =args.get('tag_id')
  IpiXMJgfCzbDdPVoSrnlWQNBULheKA=args.get('api_path')
  IpiXMJgfCzbDdPVoSrnlWQNBULheKq=IpiXMJgfCzbDdPVoSrnlWQNBULheqR(args.get('page'))
  IpiXMJgfCzbDdPVoSrnlWQNBULheKu =args.get('sort')
  IpiXMJgfCzbDdPVoSrnlWQNBULhevG,IpiXMJgfCzbDdPVoSrnlWQNBULhevE=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.GetCategoryList(IpiXMJgfCzbDdPVoSrnlWQNBULheKc,IpiXMJgfCzbDdPVoSrnlWQNBULheKt,IpiXMJgfCzbDdPVoSrnlWQNBULheKA,IpiXMJgfCzbDdPVoSrnlWQNBULheKq,IpiXMJgfCzbDdPVoSrnlWQNBULheKu)
  for IpiXMJgfCzbDdPVoSrnlWQNBULhevw in IpiXMJgfCzbDdPVoSrnlWQNBULhevG:
   IpiXMJgfCzbDdPVoSrnlWQNBULheKx =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('code')
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('title')
   IpiXMJgfCzbDdPVoSrnlWQNBULhevH =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('content_type')
   IpiXMJgfCzbDdPVoSrnlWQNBULhevY =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('story')
   IpiXMJgfCzbDdPVoSrnlWQNBULheKE =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('thumbnail')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFT =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('year')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFy =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('film_rating_code')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFK=IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('film_rating_short')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFv =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('film_rating_long')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFc =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('duration')
   if IpiXMJgfCzbDdPVoSrnlWQNBULhevH=='movies': 
    IpiXMJgfCzbDdPVoSrnlWQNBULheyx =IpiXMJgfCzbDdPVoSrnlWQNBULheqt
    IpiXMJgfCzbDdPVoSrnlWQNBULheFq ='MOVIE'
    IpiXMJgfCzbDdPVoSrnlWQNBULheyE =''
    IpiXMJgfCzbDdPVoSrnlWQNBULheKG='-'
    IpiXMJgfCzbDdPVoSrnlWQNBULheFu ='movie'
   else: 
    IpiXMJgfCzbDdPVoSrnlWQNBULheyx =IpiXMJgfCzbDdPVoSrnlWQNBULheqA
    IpiXMJgfCzbDdPVoSrnlWQNBULheFq ='EPISODE'
    IpiXMJgfCzbDdPVoSrnlWQNBULheyE ='' 
    IpiXMJgfCzbDdPVoSrnlWQNBULheKG=IpiXMJgfCzbDdPVoSrnlWQNBULheKx
    IpiXMJgfCzbDdPVoSrnlWQNBULheFu ='tvshow' 
   IpiXMJgfCzbDdPVoSrnlWQNBULheFs={'mediatype':IpiXMJgfCzbDdPVoSrnlWQNBULheFu,'mpaa':IpiXMJgfCzbDdPVoSrnlWQNBULheFv,'title':IpiXMJgfCzbDdPVoSrnlWQNBULheyk,'year':IpiXMJgfCzbDdPVoSrnlWQNBULheFT,'duration':IpiXMJgfCzbDdPVoSrnlWQNBULheFc,'plot':IpiXMJgfCzbDdPVoSrnlWQNBULhevY}
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk+='  (%s)'%(IpiXMJgfCzbDdPVoSrnlWQNBULheFT)
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':IpiXMJgfCzbDdPVoSrnlWQNBULheFq,'movie_code':IpiXMJgfCzbDdPVoSrnlWQNBULheKx,'page':'1','season_code':IpiXMJgfCzbDdPVoSrnlWQNBULheKG,'title':IpiXMJgfCzbDdPVoSrnlWQNBULheyk,'thumbnail':IpiXMJgfCzbDdPVoSrnlWQNBULheKE}
   if IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_settings_makebookmark():
    IpiXMJgfCzbDdPVoSrnlWQNBULheFm={'videoid':IpiXMJgfCzbDdPVoSrnlWQNBULheKx,'vidtype':'tvshow' if IpiXMJgfCzbDdPVoSrnlWQNBULhevH=='tv_seasons' else 'movie','vtitle':IpiXMJgfCzbDdPVoSrnlWQNBULheyk,'vsubtitle':'',}
    IpiXMJgfCzbDdPVoSrnlWQNBULheFj=json.dumps(IpiXMJgfCzbDdPVoSrnlWQNBULheFm)
    IpiXMJgfCzbDdPVoSrnlWQNBULheFj=urllib.parse.quote(IpiXMJgfCzbDdPVoSrnlWQNBULheFj)
    IpiXMJgfCzbDdPVoSrnlWQNBULheFa='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(IpiXMJgfCzbDdPVoSrnlWQNBULheFj)
    IpiXMJgfCzbDdPVoSrnlWQNBULheFk=[('(통합) 찜 영상에 추가',IpiXMJgfCzbDdPVoSrnlWQNBULheFa)]
   else:
    IpiXMJgfCzbDdPVoSrnlWQNBULheFk=IpiXMJgfCzbDdPVoSrnlWQNBULheqk
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel=IpiXMJgfCzbDdPVoSrnlWQNBULheyE,img=IpiXMJgfCzbDdPVoSrnlWQNBULheKE,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheFs,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheyx,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO,ContextMenu=IpiXMJgfCzbDdPVoSrnlWQNBULheFk)
  if IpiXMJgfCzbDdPVoSrnlWQNBULhevE:
   if IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.GetCategoryList_morepage(IpiXMJgfCzbDdPVoSrnlWQNBULheKc,IpiXMJgfCzbDdPVoSrnlWQNBULheKt,IpiXMJgfCzbDdPVoSrnlWQNBULheKA,IpiXMJgfCzbDdPVoSrnlWQNBULheKq+1,IpiXMJgfCzbDdPVoSrnlWQNBULheKu):
    IpiXMJgfCzbDdPVoSrnlWQNBULheyO={}
    IpiXMJgfCzbDdPVoSrnlWQNBULheyO['mode'] ='CATEGORY_LIST'
    IpiXMJgfCzbDdPVoSrnlWQNBULheyO['stype'] =IpiXMJgfCzbDdPVoSrnlWQNBULheKc
    IpiXMJgfCzbDdPVoSrnlWQNBULheyO['tag_id'] =IpiXMJgfCzbDdPVoSrnlWQNBULheKt
    IpiXMJgfCzbDdPVoSrnlWQNBULheyO['api_path']=IpiXMJgfCzbDdPVoSrnlWQNBULheKA
    IpiXMJgfCzbDdPVoSrnlWQNBULheyO['page'] =IpiXMJgfCzbDdPVoSrnlWQNBULheqw(IpiXMJgfCzbDdPVoSrnlWQNBULheKq+1)
    IpiXMJgfCzbDdPVoSrnlWQNBULheyO['sort'] =IpiXMJgfCzbDdPVoSrnlWQNBULheKu
    IpiXMJgfCzbDdPVoSrnlWQNBULheyk='[B]%s >>[/B]'%'다음 페이지'
    IpiXMJgfCzbDdPVoSrnlWQNBULheKO=IpiXMJgfCzbDdPVoSrnlWQNBULheqw(IpiXMJgfCzbDdPVoSrnlWQNBULheKq+1)
    IpiXMJgfCzbDdPVoSrnlWQNBULheyt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
    IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel=IpiXMJgfCzbDdPVoSrnlWQNBULheKO,img=IpiXMJgfCzbDdPVoSrnlWQNBULheyt,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheqk,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqA,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO)
  xbmcplugin.setContent(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,'movies')
  if IpiXMJgfCzbDdPVoSrnlWQNBULheqG(IpiXMJgfCzbDdPVoSrnlWQNBULhevG)>0:
   if IpiXMJgfCzbDdPVoSrnlWQNBULheKA=='arrivals/latest':
    xbmcplugin.endOfDirectory(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,cacheToDisc=IpiXMJgfCzbDdPVoSrnlWQNBULheqA)
   else:
    xbmcplugin.endOfDirectory(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,cacheToDisc=IpiXMJgfCzbDdPVoSrnlWQNBULheqt)
 def dp_Episode_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.SaveCredential(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_winCredential())
  IpiXMJgfCzbDdPVoSrnlWQNBULheFA=args.get('movie_code')
  IpiXMJgfCzbDdPVoSrnlWQNBULheKq =IpiXMJgfCzbDdPVoSrnlWQNBULheqR(args.get('page'))
  IpiXMJgfCzbDdPVoSrnlWQNBULheKG =args.get('season_code')
  IpiXMJgfCzbDdPVoSrnlWQNBULhevG,IpiXMJgfCzbDdPVoSrnlWQNBULhevE=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.GetEpisodoList(IpiXMJgfCzbDdPVoSrnlWQNBULheFA,IpiXMJgfCzbDdPVoSrnlWQNBULheKq,orderby=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_winEpisodeOrderby())
  for IpiXMJgfCzbDdPVoSrnlWQNBULhevw in IpiXMJgfCzbDdPVoSrnlWQNBULhevG:
   IpiXMJgfCzbDdPVoSrnlWQNBULheKx =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('code')
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('title')
   IpiXMJgfCzbDdPVoSrnlWQNBULheKE =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('thumbnail')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFt =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('display_num')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFO =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('season_title')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFx=IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('episode_number')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFc =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('duration')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFs={'mediatype':'episode','tvshowtitle':IpiXMJgfCzbDdPVoSrnlWQNBULheyk if IpiXMJgfCzbDdPVoSrnlWQNBULheyk!='' else IpiXMJgfCzbDdPVoSrnlWQNBULheFO,'title':'%s %s'%(IpiXMJgfCzbDdPVoSrnlWQNBULheFO,IpiXMJgfCzbDdPVoSrnlWQNBULheFt)if IpiXMJgfCzbDdPVoSrnlWQNBULheyk!='' else IpiXMJgfCzbDdPVoSrnlWQNBULheFt,'episode':IpiXMJgfCzbDdPVoSrnlWQNBULheFx,'duration':IpiXMJgfCzbDdPVoSrnlWQNBULheFc,'plot':'%s\n%s\n\n%s'%(IpiXMJgfCzbDdPVoSrnlWQNBULheFO,IpiXMJgfCzbDdPVoSrnlWQNBULheFt,IpiXMJgfCzbDdPVoSrnlWQNBULheyk)}
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk='(%s) %s'%(IpiXMJgfCzbDdPVoSrnlWQNBULheFt,IpiXMJgfCzbDdPVoSrnlWQNBULheyk)
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':'MOVIE','movie_code':IpiXMJgfCzbDdPVoSrnlWQNBULheKx,'season_code':IpiXMJgfCzbDdPVoSrnlWQNBULheKG,'title':'%s < %s >'%(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,IpiXMJgfCzbDdPVoSrnlWQNBULheFO),'thumbnail':IpiXMJgfCzbDdPVoSrnlWQNBULheKE}
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel=IpiXMJgfCzbDdPVoSrnlWQNBULheFO,img=IpiXMJgfCzbDdPVoSrnlWQNBULheKE,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheFs,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqt,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO)
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKq==1:
   IpiXMJgfCzbDdPVoSrnlWQNBULheFs={'plot':'정렬순서를 변경합니다.'}
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO={}
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['mode'] ='ORDER_BY' 
   if IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_winEpisodeOrderby()=='desc':
    IpiXMJgfCzbDdPVoSrnlWQNBULheyk='정렬순서변경 : 최신화부터 -> 1회부터'
    IpiXMJgfCzbDdPVoSrnlWQNBULheyO['orderby']='asc'
   else:
    IpiXMJgfCzbDdPVoSrnlWQNBULheyk='정렬순서변경 : 1회부터 -> 최신화부터'
    IpiXMJgfCzbDdPVoSrnlWQNBULheyO['orderby']='desc'
   IpiXMJgfCzbDdPVoSrnlWQNBULheyt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel='',img=IpiXMJgfCzbDdPVoSrnlWQNBULheyt,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheFs,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqt,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO,isLink=IpiXMJgfCzbDdPVoSrnlWQNBULheqA)
  if IpiXMJgfCzbDdPVoSrnlWQNBULhevE:
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['mode'] ='EPISODE' 
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['movie_code']=IpiXMJgfCzbDdPVoSrnlWQNBULheFA
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['page'] =IpiXMJgfCzbDdPVoSrnlWQNBULheqw(IpiXMJgfCzbDdPVoSrnlWQNBULheKq+1)
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk='[B]%s >>[/B]'%'다음 페이지'
   IpiXMJgfCzbDdPVoSrnlWQNBULheKO=IpiXMJgfCzbDdPVoSrnlWQNBULheqw(IpiXMJgfCzbDdPVoSrnlWQNBULheKq+1)
   IpiXMJgfCzbDdPVoSrnlWQNBULheyt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel=IpiXMJgfCzbDdPVoSrnlWQNBULheKO,img=IpiXMJgfCzbDdPVoSrnlWQNBULheyt,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheqk,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqA,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO)
  xbmcplugin.setContent(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,'episodes')
  if IpiXMJgfCzbDdPVoSrnlWQNBULheqG(IpiXMJgfCzbDdPVoSrnlWQNBULhevG)>0:xbmcplugin.endOfDirectory(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,cacheToDisc=IpiXMJgfCzbDdPVoSrnlWQNBULheqA)
 def dp_Search_History(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheFG=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.Load_List_File('search')
  for IpiXMJgfCzbDdPVoSrnlWQNBULheFE in IpiXMJgfCzbDdPVoSrnlWQNBULheFG:
   IpiXMJgfCzbDdPVoSrnlWQNBULheFw=IpiXMJgfCzbDdPVoSrnlWQNBULheqx(urllib.parse.parse_qsl(IpiXMJgfCzbDdPVoSrnlWQNBULheFE))
   IpiXMJgfCzbDdPVoSrnlWQNBULheFH=IpiXMJgfCzbDdPVoSrnlWQNBULheFw.get('skey').strip()
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':'LOCAL_SEARCH','search_key':IpiXMJgfCzbDdPVoSrnlWQNBULheFH,'page':'1','historyyn':'Y',}
   IpiXMJgfCzbDdPVoSrnlWQNBULheFY={'mode':'SEARCH_REMOVE','stype':'ONE','skey':IpiXMJgfCzbDdPVoSrnlWQNBULheFH,}
   IpiXMJgfCzbDdPVoSrnlWQNBULhecT=urllib.parse.urlencode(IpiXMJgfCzbDdPVoSrnlWQNBULheFY)
   IpiXMJgfCzbDdPVoSrnlWQNBULheFk=[('선택된 검색어 ( %s ) 삭제'%(IpiXMJgfCzbDdPVoSrnlWQNBULheFH),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(IpiXMJgfCzbDdPVoSrnlWQNBULhecT))]
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheFH,sublabel='',img=IpiXMJgfCzbDdPVoSrnlWQNBULheqk,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheqk,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqA,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO,ContextMenu=IpiXMJgfCzbDdPVoSrnlWQNBULheFk)
  IpiXMJgfCzbDdPVoSrnlWQNBULheFs={'plot':'검색목록 전체를 삭제합니다.'}
  IpiXMJgfCzbDdPVoSrnlWQNBULheyk='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  IpiXMJgfCzbDdPVoSrnlWQNBULheyt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel='',img=IpiXMJgfCzbDdPVoSrnlWQNBULheyt,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheFs,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqt,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO,isLink=IpiXMJgfCzbDdPVoSrnlWQNBULheqA)
  xbmcplugin.endOfDirectory(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,cacheToDisc=IpiXMJgfCzbDdPVoSrnlWQNBULheqt)
 def dp_Search_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.SaveCredential(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_winCredential())
  IpiXMJgfCzbDdPVoSrnlWQNBULheKq =IpiXMJgfCzbDdPVoSrnlWQNBULheqR(args.get('page'))
  if 'search_key' in args:
   IpiXMJgfCzbDdPVoSrnlWQNBULhecy=args.get('search_key')
  else:
   IpiXMJgfCzbDdPVoSrnlWQNBULhecy=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not IpiXMJgfCzbDdPVoSrnlWQNBULhecy:
    return
  IpiXMJgfCzbDdPVoSrnlWQNBULhevG,IpiXMJgfCzbDdPVoSrnlWQNBULhevE=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.GetSearchList(IpiXMJgfCzbDdPVoSrnlWQNBULhecy,IpiXMJgfCzbDdPVoSrnlWQNBULheKq)
  for IpiXMJgfCzbDdPVoSrnlWQNBULhevw in IpiXMJgfCzbDdPVoSrnlWQNBULhevG:
   IpiXMJgfCzbDdPVoSrnlWQNBULheKx =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('code')
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('title')
   IpiXMJgfCzbDdPVoSrnlWQNBULhevH=IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('content_type')
   IpiXMJgfCzbDdPVoSrnlWQNBULhevY =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('story')
   IpiXMJgfCzbDdPVoSrnlWQNBULheKE =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('thumbnail')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFT =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('year')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFy =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('film_rating_code')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFK=IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('film_rating_short')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFv =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('film_rating_long')
   IpiXMJgfCzbDdPVoSrnlWQNBULheFc =IpiXMJgfCzbDdPVoSrnlWQNBULhevw.get('duration')
   if IpiXMJgfCzbDdPVoSrnlWQNBULhevH=='movies': 
    IpiXMJgfCzbDdPVoSrnlWQNBULheyx =IpiXMJgfCzbDdPVoSrnlWQNBULheqt
    IpiXMJgfCzbDdPVoSrnlWQNBULheFq ='MOVIE'
    IpiXMJgfCzbDdPVoSrnlWQNBULheyE =''
    IpiXMJgfCzbDdPVoSrnlWQNBULheKG='-'
    IpiXMJgfCzbDdPVoSrnlWQNBULheFu ='movie'
   else: 
    IpiXMJgfCzbDdPVoSrnlWQNBULheyx =IpiXMJgfCzbDdPVoSrnlWQNBULheqA
    IpiXMJgfCzbDdPVoSrnlWQNBULheFq ='EPISODE'
    IpiXMJgfCzbDdPVoSrnlWQNBULheyE ='' 
    IpiXMJgfCzbDdPVoSrnlWQNBULheKG=IpiXMJgfCzbDdPVoSrnlWQNBULheKx
    IpiXMJgfCzbDdPVoSrnlWQNBULheFu ='tvshow' 
   IpiXMJgfCzbDdPVoSrnlWQNBULheFs={'mediatype':IpiXMJgfCzbDdPVoSrnlWQNBULheFu,'mpaa':IpiXMJgfCzbDdPVoSrnlWQNBULheFv,'title':IpiXMJgfCzbDdPVoSrnlWQNBULheyk,'year':IpiXMJgfCzbDdPVoSrnlWQNBULheFT,'duration':IpiXMJgfCzbDdPVoSrnlWQNBULheFc,'plot':IpiXMJgfCzbDdPVoSrnlWQNBULhevY}
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk+='  (%s)'%(IpiXMJgfCzbDdPVoSrnlWQNBULheFT)
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':IpiXMJgfCzbDdPVoSrnlWQNBULheFq,'movie_code':IpiXMJgfCzbDdPVoSrnlWQNBULheKx,'page':'1','season_code':IpiXMJgfCzbDdPVoSrnlWQNBULheKG,'title':IpiXMJgfCzbDdPVoSrnlWQNBULheyk,'thumbnail':IpiXMJgfCzbDdPVoSrnlWQNBULheKE}
   if IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_settings_makebookmark():
    IpiXMJgfCzbDdPVoSrnlWQNBULheFm={'videoid':IpiXMJgfCzbDdPVoSrnlWQNBULheKx,'vidtype':'tvshow' if IpiXMJgfCzbDdPVoSrnlWQNBULhevH=='tv_seasons' else 'movie','vtitle':IpiXMJgfCzbDdPVoSrnlWQNBULheyk,'vsubtitle':'',}
    IpiXMJgfCzbDdPVoSrnlWQNBULheFj=json.dumps(IpiXMJgfCzbDdPVoSrnlWQNBULheFm)
    IpiXMJgfCzbDdPVoSrnlWQNBULheFj=urllib.parse.quote(IpiXMJgfCzbDdPVoSrnlWQNBULheFj)
    IpiXMJgfCzbDdPVoSrnlWQNBULheFa='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(IpiXMJgfCzbDdPVoSrnlWQNBULheFj)
    IpiXMJgfCzbDdPVoSrnlWQNBULheFk=[('(통합) 찜 영상에 추가',IpiXMJgfCzbDdPVoSrnlWQNBULheFa)]
   else:
    IpiXMJgfCzbDdPVoSrnlWQNBULheFk=IpiXMJgfCzbDdPVoSrnlWQNBULheqk
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel=IpiXMJgfCzbDdPVoSrnlWQNBULheyE,img=IpiXMJgfCzbDdPVoSrnlWQNBULheKE,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheFs,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheyx,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO,ContextMenu=IpiXMJgfCzbDdPVoSrnlWQNBULheFk)
  if IpiXMJgfCzbDdPVoSrnlWQNBULhevE:
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO={}
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['mode'] ='SEARCH'
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['search_key']=IpiXMJgfCzbDdPVoSrnlWQNBULhecy
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO['page'] =IpiXMJgfCzbDdPVoSrnlWQNBULheqw(IpiXMJgfCzbDdPVoSrnlWQNBULheKq+1)
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk='[B]%s >>[/B]'%'다음 페이지'
   IpiXMJgfCzbDdPVoSrnlWQNBULheKO=IpiXMJgfCzbDdPVoSrnlWQNBULheqw(IpiXMJgfCzbDdPVoSrnlWQNBULheKq+1)
   IpiXMJgfCzbDdPVoSrnlWQNBULheyt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel=IpiXMJgfCzbDdPVoSrnlWQNBULheKO,img=IpiXMJgfCzbDdPVoSrnlWQNBULheyt,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheqk,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqA,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO)
  xbmcplugin.setContent(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,'movies')
  xbmcplugin.endOfDirectory(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,cacheToDisc=IpiXMJgfCzbDdPVoSrnlWQNBULheqA)
  if args.get('historyyn')=='Y':IpiXMJgfCzbDdPVoSrnlWQNBULheTj.Save_Searched_List(IpiXMJgfCzbDdPVoSrnlWQNBULhecy)
 def Delete_List_File(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,IpiXMJgfCzbDdPVoSrnlWQNBULheKc,skey='-'):
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKc=='ALL':
   try:
    IpiXMJgfCzbDdPVoSrnlWQNBULhecK=IpiXMJgfCzbDdPVoSrnlWQNBULheTm
    fp=IpiXMJgfCzbDdPVoSrnlWQNBULheqH(IpiXMJgfCzbDdPVoSrnlWQNBULhecK,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    IpiXMJgfCzbDdPVoSrnlWQNBULheqk
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheKc=='ONE':
   try:
    IpiXMJgfCzbDdPVoSrnlWQNBULhecK=IpiXMJgfCzbDdPVoSrnlWQNBULheTm
    IpiXMJgfCzbDdPVoSrnlWQNBULhecv=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.Load_List_File('search') 
    fp=IpiXMJgfCzbDdPVoSrnlWQNBULheqH(IpiXMJgfCzbDdPVoSrnlWQNBULhecK,'w',-1,'utf-8')
    for IpiXMJgfCzbDdPVoSrnlWQNBULhecF in IpiXMJgfCzbDdPVoSrnlWQNBULhecv:
     IpiXMJgfCzbDdPVoSrnlWQNBULhecq=IpiXMJgfCzbDdPVoSrnlWQNBULheqx(urllib.parse.parse_qsl(IpiXMJgfCzbDdPVoSrnlWQNBULhecF))
     IpiXMJgfCzbDdPVoSrnlWQNBULhecu=IpiXMJgfCzbDdPVoSrnlWQNBULhecq.get('skey').strip()
     if skey!=IpiXMJgfCzbDdPVoSrnlWQNBULhecu:
      fp.write(IpiXMJgfCzbDdPVoSrnlWQNBULhecF)
    fp.close()
   except:
    IpiXMJgfCzbDdPVoSrnlWQNBULheqk
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheKc in['seasons','movie']:
   try:
    IpiXMJgfCzbDdPVoSrnlWQNBULhecK=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IpiXMJgfCzbDdPVoSrnlWQNBULheKc))
    fp=IpiXMJgfCzbDdPVoSrnlWQNBULheqH(IpiXMJgfCzbDdPVoSrnlWQNBULhecK,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    IpiXMJgfCzbDdPVoSrnlWQNBULheqk
 def dp_Listfile_Delete(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheKc=args.get('stype')
  IpiXMJgfCzbDdPVoSrnlWQNBULheFH =args.get('skey')
  IpiXMJgfCzbDdPVoSrnlWQNBULheTt=xbmcgui.Dialog()
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKc=='ALL':
   IpiXMJgfCzbDdPVoSrnlWQNBULheKT=IpiXMJgfCzbDdPVoSrnlWQNBULheTt.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheKc=='ONE':
   IpiXMJgfCzbDdPVoSrnlWQNBULheKT=IpiXMJgfCzbDdPVoSrnlWQNBULheTt.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheKc in['seasons','movie']:
   IpiXMJgfCzbDdPVoSrnlWQNBULheKT=IpiXMJgfCzbDdPVoSrnlWQNBULheTt.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKT==IpiXMJgfCzbDdPVoSrnlWQNBULheqt:sys.exit()
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.Delete_List_File(IpiXMJgfCzbDdPVoSrnlWQNBULheKc,skey=IpiXMJgfCzbDdPVoSrnlWQNBULheFH)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,IpiXMJgfCzbDdPVoSrnlWQNBULheKc): 
  try:
   if IpiXMJgfCzbDdPVoSrnlWQNBULheKc=='search':
    IpiXMJgfCzbDdPVoSrnlWQNBULhecK=IpiXMJgfCzbDdPVoSrnlWQNBULheTm
   elif IpiXMJgfCzbDdPVoSrnlWQNBULheKc in['seasons','movie']:
    IpiXMJgfCzbDdPVoSrnlWQNBULhecK=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IpiXMJgfCzbDdPVoSrnlWQNBULheKc))
   else:
    return[]
   fp=IpiXMJgfCzbDdPVoSrnlWQNBULheqH(IpiXMJgfCzbDdPVoSrnlWQNBULhecK,'r',-1,'utf-8')
   IpiXMJgfCzbDdPVoSrnlWQNBULhecs=fp.readlines()
   fp.close()
  except:
   IpiXMJgfCzbDdPVoSrnlWQNBULhecs=[]
  return IpiXMJgfCzbDdPVoSrnlWQNBULhecs
 def Save_Watched_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,IpiXMJgfCzbDdPVoSrnlWQNBULheKc,IpiXMJgfCzbDdPVoSrnlWQNBULheTR):
  try:
   IpiXMJgfCzbDdPVoSrnlWQNBULhecm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IpiXMJgfCzbDdPVoSrnlWQNBULheKc))
   IpiXMJgfCzbDdPVoSrnlWQNBULhecv=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.Load_List_File(IpiXMJgfCzbDdPVoSrnlWQNBULheKc) 
   fp=IpiXMJgfCzbDdPVoSrnlWQNBULheqH(IpiXMJgfCzbDdPVoSrnlWQNBULhecm,'w',-1,'utf-8')
   IpiXMJgfCzbDdPVoSrnlWQNBULhecj=urllib.parse.urlencode(IpiXMJgfCzbDdPVoSrnlWQNBULheTR)
   IpiXMJgfCzbDdPVoSrnlWQNBULhecj=IpiXMJgfCzbDdPVoSrnlWQNBULhecj+'\n'
   fp.write(IpiXMJgfCzbDdPVoSrnlWQNBULhecj)
   IpiXMJgfCzbDdPVoSrnlWQNBULheca=0
   for IpiXMJgfCzbDdPVoSrnlWQNBULhecF in IpiXMJgfCzbDdPVoSrnlWQNBULhecv:
    IpiXMJgfCzbDdPVoSrnlWQNBULhecq=IpiXMJgfCzbDdPVoSrnlWQNBULheqx(urllib.parse.parse_qsl(IpiXMJgfCzbDdPVoSrnlWQNBULhecF))
    IpiXMJgfCzbDdPVoSrnlWQNBULheck=IpiXMJgfCzbDdPVoSrnlWQNBULheTR.get('code').strip()
    IpiXMJgfCzbDdPVoSrnlWQNBULhecR=IpiXMJgfCzbDdPVoSrnlWQNBULhecq.get('code').strip()
    if IpiXMJgfCzbDdPVoSrnlWQNBULheKc=='seasons' and IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_settings_direct_replay()==IpiXMJgfCzbDdPVoSrnlWQNBULheqA:
     IpiXMJgfCzbDdPVoSrnlWQNBULheck=IpiXMJgfCzbDdPVoSrnlWQNBULheTR.get('videoid').strip()
     IpiXMJgfCzbDdPVoSrnlWQNBULhecR=IpiXMJgfCzbDdPVoSrnlWQNBULhecq.get('videoid').strip()if IpiXMJgfCzbDdPVoSrnlWQNBULhecR!=IpiXMJgfCzbDdPVoSrnlWQNBULheqk else '-'
    if IpiXMJgfCzbDdPVoSrnlWQNBULheck!=IpiXMJgfCzbDdPVoSrnlWQNBULhecR:
     fp.write(IpiXMJgfCzbDdPVoSrnlWQNBULhecF)
     IpiXMJgfCzbDdPVoSrnlWQNBULheca+=1
     if IpiXMJgfCzbDdPVoSrnlWQNBULheca>=50:break
   fp.close()
  except:
   IpiXMJgfCzbDdPVoSrnlWQNBULheqk
 def dp_Watch_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheKc =args.get('stype')
  IpiXMJgfCzbDdPVoSrnlWQNBULheyu=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.get_settings_direct_replay()
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKc=='-':
   for IpiXMJgfCzbDdPVoSrnlWQNBULhecA in IpiXMJgfCzbDdPVoSrnlWQNBULheTv:
    IpiXMJgfCzbDdPVoSrnlWQNBULheyk=IpiXMJgfCzbDdPVoSrnlWQNBULhecA.get('title')
    IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':IpiXMJgfCzbDdPVoSrnlWQNBULhecA.get('mode'),'stype':IpiXMJgfCzbDdPVoSrnlWQNBULhecA.get('stype')}
    IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel='',img='',infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheqk,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqA,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO)
   if IpiXMJgfCzbDdPVoSrnlWQNBULheqG(IpiXMJgfCzbDdPVoSrnlWQNBULheTv)>0:xbmcplugin.endOfDirectory(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle)
  else:
   IpiXMJgfCzbDdPVoSrnlWQNBULhect=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.Load_List_File(IpiXMJgfCzbDdPVoSrnlWQNBULheKc)
   for IpiXMJgfCzbDdPVoSrnlWQNBULhecO in IpiXMJgfCzbDdPVoSrnlWQNBULhect:
    IpiXMJgfCzbDdPVoSrnlWQNBULheFw=IpiXMJgfCzbDdPVoSrnlWQNBULheqx(urllib.parse.parse_qsl(IpiXMJgfCzbDdPVoSrnlWQNBULhecO))
    IpiXMJgfCzbDdPVoSrnlWQNBULheKx=IpiXMJgfCzbDdPVoSrnlWQNBULheFw.get('code').strip()
    IpiXMJgfCzbDdPVoSrnlWQNBULheyk =IpiXMJgfCzbDdPVoSrnlWQNBULheFw.get('title').strip()
    IpiXMJgfCzbDdPVoSrnlWQNBULheKE =IpiXMJgfCzbDdPVoSrnlWQNBULheFw.get('img').strip()
    IpiXMJgfCzbDdPVoSrnlWQNBULhecx =IpiXMJgfCzbDdPVoSrnlWQNBULheFw.get('videoid').strip()
    try:
     IpiXMJgfCzbDdPVoSrnlWQNBULheKE=IpiXMJgfCzbDdPVoSrnlWQNBULheKE.replace('\'','\"')
     IpiXMJgfCzbDdPVoSrnlWQNBULheKE=json.loads(IpiXMJgfCzbDdPVoSrnlWQNBULheKE)
    except:
     IpiXMJgfCzbDdPVoSrnlWQNBULheqk
    IpiXMJgfCzbDdPVoSrnlWQNBULheFs={}
    IpiXMJgfCzbDdPVoSrnlWQNBULheFs['plot']=IpiXMJgfCzbDdPVoSrnlWQNBULheyk
    if IpiXMJgfCzbDdPVoSrnlWQNBULheKc=='movie':
     IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':'MOVIE','page':'1','movie_code':IpiXMJgfCzbDdPVoSrnlWQNBULheKx,'season_code':'-','title':IpiXMJgfCzbDdPVoSrnlWQNBULheyk,'thumbnail':IpiXMJgfCzbDdPVoSrnlWQNBULheKE}
     IpiXMJgfCzbDdPVoSrnlWQNBULheyx=IpiXMJgfCzbDdPVoSrnlWQNBULheqt
    else:
     if IpiXMJgfCzbDdPVoSrnlWQNBULheyu==IpiXMJgfCzbDdPVoSrnlWQNBULheqt or IpiXMJgfCzbDdPVoSrnlWQNBULhecx==IpiXMJgfCzbDdPVoSrnlWQNBULheqk:
      IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':'EPISODE','page':'1','movie_code':IpiXMJgfCzbDdPVoSrnlWQNBULheKx,'season_code':IpiXMJgfCzbDdPVoSrnlWQNBULheKx,'title':IpiXMJgfCzbDdPVoSrnlWQNBULheyk,'thumbnail':IpiXMJgfCzbDdPVoSrnlWQNBULheKE}
      IpiXMJgfCzbDdPVoSrnlWQNBULheyx=IpiXMJgfCzbDdPVoSrnlWQNBULheqA
     else:
      IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':'MOVIE','movie_code':IpiXMJgfCzbDdPVoSrnlWQNBULhecx,'season_code':IpiXMJgfCzbDdPVoSrnlWQNBULheKx,'title':IpiXMJgfCzbDdPVoSrnlWQNBULheyk,'thumbnail':IpiXMJgfCzbDdPVoSrnlWQNBULheKE}
      IpiXMJgfCzbDdPVoSrnlWQNBULheyx=IpiXMJgfCzbDdPVoSrnlWQNBULheqt
    IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel='',img=IpiXMJgfCzbDdPVoSrnlWQNBULheKE,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheFs,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheyx,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO)
   IpiXMJgfCzbDdPVoSrnlWQNBULheFs={'plot':'시청목록을 삭제합니다.'}
   IpiXMJgfCzbDdPVoSrnlWQNBULheyk='*** 시청목록 삭제 ***'
   IpiXMJgfCzbDdPVoSrnlWQNBULheyO={'mode':'MYVIEW_REMOVE','stype':IpiXMJgfCzbDdPVoSrnlWQNBULheKc,'skey':'-',}
   IpiXMJgfCzbDdPVoSrnlWQNBULheyt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.add_dir(IpiXMJgfCzbDdPVoSrnlWQNBULheyk,sublabel='',img=IpiXMJgfCzbDdPVoSrnlWQNBULheyt,infoLabels=IpiXMJgfCzbDdPVoSrnlWQNBULheFs,isFolder=IpiXMJgfCzbDdPVoSrnlWQNBULheqt,params=IpiXMJgfCzbDdPVoSrnlWQNBULheyO,isLink=IpiXMJgfCzbDdPVoSrnlWQNBULheqA)
   if IpiXMJgfCzbDdPVoSrnlWQNBULheKc=='movie':xbmcplugin.setContent(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,'movies')
   else:xbmcplugin.setContent(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(IpiXMJgfCzbDdPVoSrnlWQNBULheTj._addon_handle,cacheToDisc=IpiXMJgfCzbDdPVoSrnlWQNBULheqt)
 def Save_Searched_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,IpiXMJgfCzbDdPVoSrnlWQNBULhecy):
  try:
   IpiXMJgfCzbDdPVoSrnlWQNBULhecG=IpiXMJgfCzbDdPVoSrnlWQNBULheTm
   IpiXMJgfCzbDdPVoSrnlWQNBULhecv=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.Load_List_File('search') 
   IpiXMJgfCzbDdPVoSrnlWQNBULhecE={'skey':IpiXMJgfCzbDdPVoSrnlWQNBULhecy.strip()}
   fp=IpiXMJgfCzbDdPVoSrnlWQNBULheqH(IpiXMJgfCzbDdPVoSrnlWQNBULhecG,'w',-1,'utf-8')
   IpiXMJgfCzbDdPVoSrnlWQNBULhecj=urllib.parse.urlencode(IpiXMJgfCzbDdPVoSrnlWQNBULhecE)
   IpiXMJgfCzbDdPVoSrnlWQNBULhecj=IpiXMJgfCzbDdPVoSrnlWQNBULhecj+'\n'
   fp.write(IpiXMJgfCzbDdPVoSrnlWQNBULhecj)
   IpiXMJgfCzbDdPVoSrnlWQNBULheca=0
   for IpiXMJgfCzbDdPVoSrnlWQNBULhecF in IpiXMJgfCzbDdPVoSrnlWQNBULhecv:
    IpiXMJgfCzbDdPVoSrnlWQNBULhecq=IpiXMJgfCzbDdPVoSrnlWQNBULheqx(urllib.parse.parse_qsl(IpiXMJgfCzbDdPVoSrnlWQNBULhecF))
    IpiXMJgfCzbDdPVoSrnlWQNBULheck=IpiXMJgfCzbDdPVoSrnlWQNBULhecE.get('skey').strip()
    IpiXMJgfCzbDdPVoSrnlWQNBULhecR=IpiXMJgfCzbDdPVoSrnlWQNBULhecq.get('skey').strip()
    if IpiXMJgfCzbDdPVoSrnlWQNBULheck!=IpiXMJgfCzbDdPVoSrnlWQNBULhecR:
     fp.write(IpiXMJgfCzbDdPVoSrnlWQNBULhecF)
     IpiXMJgfCzbDdPVoSrnlWQNBULheca+=1
     if IpiXMJgfCzbDdPVoSrnlWQNBULheca>=50:break
   fp.close()
  except:
   IpiXMJgfCzbDdPVoSrnlWQNBULheqk
 def logout(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  IpiXMJgfCzbDdPVoSrnlWQNBULheTt=xbmcgui.Dialog()
  IpiXMJgfCzbDdPVoSrnlWQNBULheKT=IpiXMJgfCzbDdPVoSrnlWQNBULheTt.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKT==IpiXMJgfCzbDdPVoSrnlWQNBULheqt:sys.exit()
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.wininfo_clear()
  if os.path.isfile(IpiXMJgfCzbDdPVoSrnlWQNBULheTs):os.remove(IpiXMJgfCzbDdPVoSrnlWQNBULheTs)
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  IpiXMJgfCzbDdPVoSrnlWQNBULheys=xbmcgui.Window(10000)
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_TOKEN','')
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_GUIT','')
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_GUITV','')
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_USERCD','')
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  IpiXMJgfCzbDdPVoSrnlWQNBULhecw =IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.Get_Now_Datetime()
  IpiXMJgfCzbDdPVoSrnlWQNBULhecH=IpiXMJgfCzbDdPVoSrnlWQNBULhecw+datetime.timedelta(days=IpiXMJgfCzbDdPVoSrnlWQNBULheqR(__addon__.getSetting('cache_ttl')))
  IpiXMJgfCzbDdPVoSrnlWQNBULheys=xbmcgui.Window(10000)
  IpiXMJgfCzbDdPVoSrnlWQNBULhecY={'watcha_token':IpiXMJgfCzbDdPVoSrnlWQNBULheys.getProperty('WATCHA_M_TOKEN'),'watcha_guit':IpiXMJgfCzbDdPVoSrnlWQNBULheys.getProperty('WATCHA_M_GUIT'),'watcha_guitv':IpiXMJgfCzbDdPVoSrnlWQNBULheys.getProperty('WATCHA_M_GUITV'),'watcha_usercd':IpiXMJgfCzbDdPVoSrnlWQNBULheys.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':IpiXMJgfCzbDdPVoSrnlWQNBULhecH.strftime('%Y-%m-%d')}
  try: 
   fp=IpiXMJgfCzbDdPVoSrnlWQNBULheqH(IpiXMJgfCzbDdPVoSrnlWQNBULheTs,'w',-1,'utf-8')
   json.dump(IpiXMJgfCzbDdPVoSrnlWQNBULhecY,fp)
   fp.close()
  except IpiXMJgfCzbDdPVoSrnlWQNBULheqY as exception:
   IpiXMJgfCzbDdPVoSrnlWQNBULheuT(exception)
 def cookiefile_check(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  IpiXMJgfCzbDdPVoSrnlWQNBULhecY={}
  try: 
   fp=IpiXMJgfCzbDdPVoSrnlWQNBULheqH(IpiXMJgfCzbDdPVoSrnlWQNBULheTs,'r',-1,'utf-8')
   IpiXMJgfCzbDdPVoSrnlWQNBULhecY= json.load(fp)
   fp.close()
  except IpiXMJgfCzbDdPVoSrnlWQNBULheqY as exception:
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.wininfo_clear()
   return IpiXMJgfCzbDdPVoSrnlWQNBULheqt
  IpiXMJgfCzbDdPVoSrnlWQNBULheyw =__addon__.getSetting('id')
  IpiXMJgfCzbDdPVoSrnlWQNBULheyH =__addon__.getSetting('pw')
  IpiXMJgfCzbDdPVoSrnlWQNBULheqT =__addon__.getSetting('selected_profile')
  IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_id']=base64.standard_b64decode(IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_id']).decode('utf-8')
  IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_pw']=base64.standard_b64decode(IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_pw']).decode('utf-8')
  if IpiXMJgfCzbDdPVoSrnlWQNBULheyw!=IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_id']or IpiXMJgfCzbDdPVoSrnlWQNBULheyH!=IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_pw']or IpiXMJgfCzbDdPVoSrnlWQNBULheqT!=IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_profile']:
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.wininfo_clear()
   return IpiXMJgfCzbDdPVoSrnlWQNBULheqt
  IpiXMJgfCzbDdPVoSrnlWQNBULheKy =IpiXMJgfCzbDdPVoSrnlWQNBULheqR(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  IpiXMJgfCzbDdPVoSrnlWQNBULheqy=IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_limitdate']
  IpiXMJgfCzbDdPVoSrnlWQNBULheKv =IpiXMJgfCzbDdPVoSrnlWQNBULheqR(re.sub('-','',IpiXMJgfCzbDdPVoSrnlWQNBULheqy))
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKv<IpiXMJgfCzbDdPVoSrnlWQNBULheKy:
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.wininfo_clear()
   return IpiXMJgfCzbDdPVoSrnlWQNBULheqt
  IpiXMJgfCzbDdPVoSrnlWQNBULheys=xbmcgui.Window(10000)
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_TOKEN',IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_token'])
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_GUIT',IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_guit'])
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_GUITV',IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_guitv'])
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_USERCD',IpiXMJgfCzbDdPVoSrnlWQNBULhecY['watcha_usercd'])
  IpiXMJgfCzbDdPVoSrnlWQNBULheys.setProperty('WATCHA_M_LOGINTIME',IpiXMJgfCzbDdPVoSrnlWQNBULheqy)
  return IpiXMJgfCzbDdPVoSrnlWQNBULheqA
 def dp_Global_Search(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheqK=args.get('mode')
  if IpiXMJgfCzbDdPVoSrnlWQNBULheqK=='TOTAL_SEARCH':
   IpiXMJgfCzbDdPVoSrnlWQNBULheqv='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   IpiXMJgfCzbDdPVoSrnlWQNBULheqv='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(IpiXMJgfCzbDdPVoSrnlWQNBULheqv)
 def dp_Bookmark_Menu(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheqv='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(IpiXMJgfCzbDdPVoSrnlWQNBULheqv)
 def dp_Set_Bookmark(IpiXMJgfCzbDdPVoSrnlWQNBULheTj,args):
  IpiXMJgfCzbDdPVoSrnlWQNBULheqF=urllib.parse.unquote(args.get('bm_param'))
  IpiXMJgfCzbDdPVoSrnlWQNBULheqF=json.loads(IpiXMJgfCzbDdPVoSrnlWQNBULheqF)
  IpiXMJgfCzbDdPVoSrnlWQNBULhecx =IpiXMJgfCzbDdPVoSrnlWQNBULheqF.get('videoid')
  IpiXMJgfCzbDdPVoSrnlWQNBULheqc =IpiXMJgfCzbDdPVoSrnlWQNBULheqF.get('vidtype')
  IpiXMJgfCzbDdPVoSrnlWQNBULhequ =IpiXMJgfCzbDdPVoSrnlWQNBULheqF.get('vtitle')
  IpiXMJgfCzbDdPVoSrnlWQNBULheqs =IpiXMJgfCzbDdPVoSrnlWQNBULheqF.get('vsubtitle')
  IpiXMJgfCzbDdPVoSrnlWQNBULheTt=xbmcgui.Dialog()
  IpiXMJgfCzbDdPVoSrnlWQNBULheKT=IpiXMJgfCzbDdPVoSrnlWQNBULheTt.yesno(__language__(30913).encode('utf8'),IpiXMJgfCzbDdPVoSrnlWQNBULhequ+' \n\n'+__language__(30914))
  if IpiXMJgfCzbDdPVoSrnlWQNBULheKT==IpiXMJgfCzbDdPVoSrnlWQNBULheqt:return
  IpiXMJgfCzbDdPVoSrnlWQNBULheqm=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.WatchaObj.GetBookmarkInfo(IpiXMJgfCzbDdPVoSrnlWQNBULhecx,IpiXMJgfCzbDdPVoSrnlWQNBULheqc)
  IpiXMJgfCzbDdPVoSrnlWQNBULheqj=json.dumps(IpiXMJgfCzbDdPVoSrnlWQNBULheqm)
  IpiXMJgfCzbDdPVoSrnlWQNBULheqj=urllib.parse.quote(IpiXMJgfCzbDdPVoSrnlWQNBULheqj)
  IpiXMJgfCzbDdPVoSrnlWQNBULheFa ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(IpiXMJgfCzbDdPVoSrnlWQNBULheqj)
  xbmc.executebuiltin(IpiXMJgfCzbDdPVoSrnlWQNBULheFa)
 def watcha_main(IpiXMJgfCzbDdPVoSrnlWQNBULheTj):
  IpiXMJgfCzbDdPVoSrnlWQNBULheqK=IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params.get('mode',IpiXMJgfCzbDdPVoSrnlWQNBULheqk)
  if IpiXMJgfCzbDdPVoSrnlWQNBULheqK=='LOGOUT':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.logout()
   return
  IpiXMJgfCzbDdPVoSrnlWQNBULheTj.login_main()
  if IpiXMJgfCzbDdPVoSrnlWQNBULheqK is IpiXMJgfCzbDdPVoSrnlWQNBULheqk:
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_Main_List()
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK=='SUB_GROUP':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_SubGroup_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK=='CATEGORY_LIST':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_Category_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK=='EPISODE':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_Episode_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK=='ORDER_BY':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_setEpOrderby(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK in['SEARCH','LOCAL_SEARCH']:
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_Search_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK=='MOVIE':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.play_VIDEO(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK=='WATCH':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_Watch_List(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_Listfile_Delete(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK in['TOTAL_SEARCH','TOTAL_HISTORY']:
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_Global_Search(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK=='SEARCH_HISTORY':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_Search_History(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK=='MENU_BOOKMARK':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_Bookmark_Menu(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  elif IpiXMJgfCzbDdPVoSrnlWQNBULheqK=='SET_BOOKMARK':
   IpiXMJgfCzbDdPVoSrnlWQNBULheTj.dp_Set_Bookmark(IpiXMJgfCzbDdPVoSrnlWQNBULheTj.main_params)
  else:
   IpiXMJgfCzbDdPVoSrnlWQNBULheqk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
