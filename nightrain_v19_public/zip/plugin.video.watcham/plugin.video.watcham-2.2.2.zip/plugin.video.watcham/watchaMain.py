__author__="NightRain"
xzEPSeagBdIwXlMQTRqcJWovGLpKVm=int
import os
import sys
import xbmcaddon,xbmcvfs
import urllib
__cwd__=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
__lib__=os.path.join(__cwd__,'resources','lib')
sys.path.append(__lib__)
from watchaRun import*
def get_params():
 p=urllib.parse.parse_qs(sys.argv[2][1:])
 for i in p.keys():
  p[i]=p[i][0]
 return p
xzEPSeagBdIwXlMQTRqcJWovGLpKVC=IpiXMJgfCzbDdPVoSrnlWQNBULheTy(sys.argv[0],xzEPSeagBdIwXlMQTRqcJWovGLpKVm(sys.argv[1]),get_params()) 
xzEPSeagBdIwXlMQTRqcJWovGLpKVC.watcha_main()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
