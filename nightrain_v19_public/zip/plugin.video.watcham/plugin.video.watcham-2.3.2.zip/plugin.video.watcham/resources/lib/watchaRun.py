__author__="NightRain"
wlIEpYTJxvztCXjUgdyLGVDNmrAkcB=object
wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ=None
wlIEpYTJxvztCXjUgdyLGVDNmrAkcM=int
wlIEpYTJxvztCXjUgdyLGVDNmrAkcK=True
wlIEpYTJxvztCXjUgdyLGVDNmrAkcR=False
wlIEpYTJxvztCXjUgdyLGVDNmrAkcH=type
wlIEpYTJxvztCXjUgdyLGVDNmrAkcS=dict
wlIEpYTJxvztCXjUgdyLGVDNmrAkcf=len
wlIEpYTJxvztCXjUgdyLGVDNmrAkcF=range
wlIEpYTJxvztCXjUgdyLGVDNmrAkcu=str
wlIEpYTJxvztCXjUgdyLGVDNmrAkch=open
from ast import Pass
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
wlIEpYTJxvztCXjUgdyLGVDNmrAksW=[{'title':'홈','mode':'HOME_GROUP','stype':'-','api_path':'-'},{'title':'오직 왓챠에서!','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/6100'},{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410'},{'title':'4K / HDR, ATOMOS 지원작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/3025'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest'},{'title':'장르별 둘러보기','mode':'SUB_GROUP','stype':'genres','api_path':'-'},{'title':'특징별 둘러보기','mode':'SUB_GROUP','stype':'tags','api_path':'-'},{'title':'이어보기 (시청이력)','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','icon':'bookmark.png'},]
wlIEpYTJxvztCXjUgdyLGVDNmrAksi=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
wlIEpYTJxvztCXjUgdyLGVDNmrAkso=40
wlIEpYTJxvztCXjUgdyLGVDNmrAksB =30
from watchaCore import*
class wlIEpYTJxvztCXjUgdyLGVDNmrAkse(wlIEpYTJxvztCXjUgdyLGVDNmrAkcB):
 def __init__(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,wlIEpYTJxvztCXjUgdyLGVDNmrAksc,wlIEpYTJxvztCXjUgdyLGVDNmrAksM,wlIEpYTJxvztCXjUgdyLGVDNmrAksK):
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_url =wlIEpYTJxvztCXjUgdyLGVDNmrAksc
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle=wlIEpYTJxvztCXjUgdyLGVDNmrAksM
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params =wlIEpYTJxvztCXjUgdyLGVDNmrAksK
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj =UMIKLwOelbivYygXDamcWCArpSHfBq() 
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_SUBTITLE_VTT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_SUBTITLE_SRT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.srt'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_COOKIE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_SEARCHEDC_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wc_stream.mpd'))
 def addon_noti(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,sting):
  try:
   wlIEpYTJxvztCXjUgdyLGVDNmrAksH=xbmcgui.Dialog()
   wlIEpYTJxvztCXjUgdyLGVDNmrAksH.notification(__addonname__,sting)
  except:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ
 def addon_log(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,string):
  try:
   wlIEpYTJxvztCXjUgdyLGVDNmrAksS=string.encode('utf-8','ignore')
  except:
   wlIEpYTJxvztCXjUgdyLGVDNmrAksS='addonException: addon_log'
  wlIEpYTJxvztCXjUgdyLGVDNmrAksf=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,wlIEpYTJxvztCXjUgdyLGVDNmrAksS),level=wlIEpYTJxvztCXjUgdyLGVDNmrAksf)
 def get_keyboard_input(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,wlIEpYTJxvztCXjUgdyLGVDNmrAkeF):
  wlIEpYTJxvztCXjUgdyLGVDNmrAksF=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ
  kb=xbmc.Keyboard()
  kb.setHeading(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   wlIEpYTJxvztCXjUgdyLGVDNmrAksF=kb.getText()
  return wlIEpYTJxvztCXjUgdyLGVDNmrAksF
 def get_settings_account(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  wlIEpYTJxvztCXjUgdyLGVDNmrAksu =__addon__.getSetting('id')
  wlIEpYTJxvztCXjUgdyLGVDNmrAksh =__addon__.getSetting('pw')
  wlIEpYTJxvztCXjUgdyLGVDNmrAksn=wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(__addon__.getSetting('selected_profile'))
  return(wlIEpYTJxvztCXjUgdyLGVDNmrAksu,wlIEpYTJxvztCXjUgdyLGVDNmrAksh,wlIEpYTJxvztCXjUgdyLGVDNmrAksn)
 def get_settings_totalsearch(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  wlIEpYTJxvztCXjUgdyLGVDNmrAksb =wlIEpYTJxvztCXjUgdyLGVDNmrAkcK if __addon__.getSetting('local_search')=='true' else wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  wlIEpYTJxvztCXjUgdyLGVDNmrAksa=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK if __addon__.getSetting('local_history')=='true' else wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  wlIEpYTJxvztCXjUgdyLGVDNmrAksq =wlIEpYTJxvztCXjUgdyLGVDNmrAkcK if __addon__.getSetting('total_search')=='true' else wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  wlIEpYTJxvztCXjUgdyLGVDNmrAksP=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK if __addon__.getSetting('total_history')=='true' else wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  wlIEpYTJxvztCXjUgdyLGVDNmrAksO=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK if __addon__.getSetting('menu_bookmark')=='true' else wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  return(wlIEpYTJxvztCXjUgdyLGVDNmrAksb,wlIEpYTJxvztCXjUgdyLGVDNmrAksa,wlIEpYTJxvztCXjUgdyLGVDNmrAksq,wlIEpYTJxvztCXjUgdyLGVDNmrAksP,wlIEpYTJxvztCXjUgdyLGVDNmrAksO)
 def get_settings_makebookmark(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  return wlIEpYTJxvztCXjUgdyLGVDNmrAkcK if __addon__.getSetting('make_bookmark')=='true' else wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
 def get_settings_proxyport(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkes =wlIEpYTJxvztCXjUgdyLGVDNmrAkcK if __addon__.getSetting('proxyYn')=='true' else wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeW=wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(__addon__.getSetting('proxyPort'))
  return wlIEpYTJxvztCXjUgdyLGVDNmrAkes,wlIEpYTJxvztCXjUgdyLGVDNmrAkeW
 def get_settings_playback(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkei=[3840,1920,1280]
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeo =['BASE','HDR','VISION']
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeB =['2CH','6CH','ATMOS']
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeQ=wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(__addon__.getSetting('selected_quality'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAkec =wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(__addon__.getSetting('selected_screen'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeM =wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(__addon__.getSetting('selected_sound'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeK={'max_quality':wlIEpYTJxvztCXjUgdyLGVDNmrAkei[wlIEpYTJxvztCXjUgdyLGVDNmrAkeQ],'sel_screen':wlIEpYTJxvztCXjUgdyLGVDNmrAkeo[wlIEpYTJxvztCXjUgdyLGVDNmrAkec],'sel_sound':wlIEpYTJxvztCXjUgdyLGVDNmrAkeB[wlIEpYTJxvztCXjUgdyLGVDNmrAkeM],'streamFilename':wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_STREAM_FILENAME,}
  return wlIEpYTJxvztCXjUgdyLGVDNmrAkeK
 def Base64_Encode(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,plaintext):
  return base64.standard_b64encode(plaintext.encode()).decode('utf-8')
 def Params_JsonToStr(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,paramJson):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeR=json.dumps(paramJson,separators=(',',':'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeR=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.Base64_Encode(wlIEpYTJxvztCXjUgdyLGVDNmrAkeR)
  return wlIEpYTJxvztCXjUgdyLGVDNmrAkeR
 def get_selQuality(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  try:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkei=['3840x2160/2.0/320/xhdpi','1920x1080/2.0/320/xhdpi','1280x720/2.0/320/xhdpi']
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeQ=wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(__addon__.getSetting('selected_quality'))
   return wlIEpYTJxvztCXjUgdyLGVDNmrAkei[wlIEpYTJxvztCXjUgdyLGVDNmrAkeQ]
  except:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ
  return 1080 
 def get_settings_direct_replay(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeH=wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(__addon__.getSetting('direct_replay'))
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkeH==0:
   return wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  else:
   return wlIEpYTJxvztCXjUgdyLGVDNmrAkcK
 def set_winEpisodeOrderby(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,wlIEpYTJxvztCXjUgdyLGVDNmrAkeS):
  __addon__.setSetting('watcha_orderby',wlIEpYTJxvztCXjUgdyLGVDNmrAkeS)
 def get_winEpisodeOrderby(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeS=__addon__.getSetting('watcha_orderby')
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkeS in['',wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ]:wlIEpYTJxvztCXjUgdyLGVDNmrAkeS='asc'
  return wlIEpYTJxvztCXjUgdyLGVDNmrAkeS
 def dp_setEpOrderby(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeS =args.get('orderby')
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.set_winEpisodeOrderby(wlIEpYTJxvztCXjUgdyLGVDNmrAkeS)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,label,sublabel='',img='',infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,params='',isLink=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR,ContextMenu=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkef='%s?%s'%(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_url,urllib.parse.urlencode(params))
  if sublabel:wlIEpYTJxvztCXjUgdyLGVDNmrAkeF='%s < %s >'%(label,sublabel)
  else: wlIEpYTJxvztCXjUgdyLGVDNmrAkeF=label
  if not img:img='DefaultFolder.png'
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeu=xbmcgui.ListItem(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkcH(img)==wlIEpYTJxvztCXjUgdyLGVDNmrAkcS:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeu.setArt(img)
  else:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeu.setArt({'thumb':img,'poster':img})
  if infoLabels:wlIEpYTJxvztCXjUgdyLGVDNmrAkeu.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeu.setProperty('IsPlayable','true')
  if ContextMenu:wlIEpYTJxvztCXjUgdyLGVDNmrAkeu.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,wlIEpYTJxvztCXjUgdyLGVDNmrAkef,wlIEpYTJxvztCXjUgdyLGVDNmrAkeu,isFolder)
 def dp_Main_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  (wlIEpYTJxvztCXjUgdyLGVDNmrAksb,wlIEpYTJxvztCXjUgdyLGVDNmrAksa,wlIEpYTJxvztCXjUgdyLGVDNmrAksq,wlIEpYTJxvztCXjUgdyLGVDNmrAksP,wlIEpYTJxvztCXjUgdyLGVDNmrAksO)=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_settings_totalsearch()
  for wlIEpYTJxvztCXjUgdyLGVDNmrAkeh in wlIEpYTJxvztCXjUgdyLGVDNmrAksW:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF=wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('title')
   wlIEpYTJxvztCXjUgdyLGVDNmrAken=''
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('mode')=='LOCAL_SEARCH' and wlIEpYTJxvztCXjUgdyLGVDNmrAksb ==wlIEpYTJxvztCXjUgdyLGVDNmrAkcR:continue
   elif wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('mode')=='SEARCH_HISTORY' and wlIEpYTJxvztCXjUgdyLGVDNmrAksa==wlIEpYTJxvztCXjUgdyLGVDNmrAkcR:continue
   elif wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('mode')=='TOTAL_SEARCH' and wlIEpYTJxvztCXjUgdyLGVDNmrAksq ==wlIEpYTJxvztCXjUgdyLGVDNmrAkcR:continue
   elif wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('mode')=='TOTAL_HISTORY' and wlIEpYTJxvztCXjUgdyLGVDNmrAksP==wlIEpYTJxvztCXjUgdyLGVDNmrAkcR:continue
   elif wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('mode')=='MENU_BOOKMARK' and wlIEpYTJxvztCXjUgdyLGVDNmrAksO==wlIEpYTJxvztCXjUgdyLGVDNmrAkcR:continue
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('mode'),'stype':wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('stype'),'api_path':wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('api_path'),'page':'1','tag_id':'-',}
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('mode')=='LOCAL_SEARCH':wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['historyyn']='Y' 
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkea=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeq =wlIEpYTJxvztCXjUgdyLGVDNmrAkcK
   else:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkea=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeq =wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
   if 'icon' in wlIEpYTJxvztCXjUgdyLGVDNmrAkeh:wlIEpYTJxvztCXjUgdyLGVDNmrAken=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',wlIEpYTJxvztCXjUgdyLGVDNmrAkeh.get('icon')) 
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel='',img=wlIEpYTJxvztCXjUgdyLGVDNmrAken,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkea,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb,isLink=wlIEpYTJxvztCXjUgdyLGVDNmrAkeq)
  xbmcplugin.endOfDirectory(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle)
 def login_main(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  (wlIEpYTJxvztCXjUgdyLGVDNmrAkeO,wlIEpYTJxvztCXjUgdyLGVDNmrAkWs,wlIEpYTJxvztCXjUgdyLGVDNmrAkWe)=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_settings_account()
  if not(wlIEpYTJxvztCXjUgdyLGVDNmrAkeO and wlIEpYTJxvztCXjUgdyLGVDNmrAkWs):
   wlIEpYTJxvztCXjUgdyLGVDNmrAksH=xbmcgui.Dialog()
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWi=wlIEpYTJxvztCXjUgdyLGVDNmrAksH.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkWi==wlIEpYTJxvztCXjUgdyLGVDNmrAkcK:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWo=0
   while wlIEpYTJxvztCXjUgdyLGVDNmrAkcK:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkWo+=1
    time.sleep(0.05)
    if wlIEpYTJxvztCXjUgdyLGVDNmrAkWo>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWB=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.GetCredential(wlIEpYTJxvztCXjUgdyLGVDNmrAkeO,wlIEpYTJxvztCXjUgdyLGVDNmrAkWs,wlIEpYTJxvztCXjUgdyLGVDNmrAkWe)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkWB:wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkWB==wlIEpYTJxvztCXjUgdyLGVDNmrAkcR:
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_HomeGroup_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWQ=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.GetHomeList()
  for wlIEpYTJxvztCXjUgdyLGVDNmrAkWc in wlIEpYTJxvztCXjUgdyLGVDNmrAkWQ:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWM =wlIEpYTJxvztCXjUgdyLGVDNmrAkWc.get('code')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWK=wlIEpYTJxvztCXjUgdyLGVDNmrAkWc.get('content_type')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF =wlIEpYTJxvztCXjUgdyLGVDNmrAkWc.get('title')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWR =wlIEpYTJxvztCXjUgdyLGVDNmrAkWc.get('bedge')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWH =wlIEpYTJxvztCXjUgdyLGVDNmrAkWc.get('thumbnail')
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkWK=='staffmades':
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'CATEGORY_LIST','api_path':'staffmades/'+wlIEpYTJxvztCXjUgdyLGVDNmrAkWM,'page':'1',}
    wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel=wlIEpYTJxvztCXjUgdyLGVDNmrAkWR,img=wlIEpYTJxvztCXjUgdyLGVDNmrAkWH,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb)
   elif wlIEpYTJxvztCXjUgdyLGVDNmrAkWK=='contents':
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'EPISODE','movie_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkWM,'page':'1','season_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkWM,'title':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,'thumbnail':wlIEpYTJxvztCXjUgdyLGVDNmrAkWH,}
    wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel=wlIEpYTJxvztCXjUgdyLGVDNmrAkWR,img=wlIEpYTJxvztCXjUgdyLGVDNmrAkWH,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb)
   else:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkWS
  xbmcplugin.endOfDirectory(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,cacheToDisc=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK)
 def dp_SubGroup_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWF =args.get('stype')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWu =wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(args.get('page'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWh=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.GetSubGroupList(wlIEpYTJxvztCXjUgdyLGVDNmrAkWF)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWn=wlIEpYTJxvztCXjUgdyLGVDNmrAkso if wlIEpYTJxvztCXjUgdyLGVDNmrAkWF=='genres' else wlIEpYTJxvztCXjUgdyLGVDNmrAksB
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWb=wlIEpYTJxvztCXjUgdyLGVDNmrAkcf(wlIEpYTJxvztCXjUgdyLGVDNmrAkWh)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWa =wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(wlIEpYTJxvztCXjUgdyLGVDNmrAkWb//(wlIEpYTJxvztCXjUgdyLGVDNmrAkWn+1))+1
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWq =(wlIEpYTJxvztCXjUgdyLGVDNmrAkWu-1)*wlIEpYTJxvztCXjUgdyLGVDNmrAkWn
  for i in wlIEpYTJxvztCXjUgdyLGVDNmrAkcF(wlIEpYTJxvztCXjUgdyLGVDNmrAkWn):
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWP=wlIEpYTJxvztCXjUgdyLGVDNmrAkWq+i
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkWP>=wlIEpYTJxvztCXjUgdyLGVDNmrAkWb:break
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF =wlIEpYTJxvztCXjUgdyLGVDNmrAkWh[wlIEpYTJxvztCXjUgdyLGVDNmrAkWP].get('group_name')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWO =wlIEpYTJxvztCXjUgdyLGVDNmrAkWh[wlIEpYTJxvztCXjUgdyLGVDNmrAkWP].get('api_path')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkis =wlIEpYTJxvztCXjUgdyLGVDNmrAkWh[wlIEpYTJxvztCXjUgdyLGVDNmrAkWP].get('tag_id')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'CATEGORY_LIST','api_path':wlIEpYTJxvztCXjUgdyLGVDNmrAkWO,'tag_id':wlIEpYTJxvztCXjUgdyLGVDNmrAkis,'stype':wlIEpYTJxvztCXjUgdyLGVDNmrAkWF,'page':'1',}
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel='',img='',infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkWa>wlIEpYTJxvztCXjUgdyLGVDNmrAkWu:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['mode'] ='SUB_GROUP' 
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['stype'] =wlIEpYTJxvztCXjUgdyLGVDNmrAkWF
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['api_path']=args.get('api_path')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['page'] =wlIEpYTJxvztCXjUgdyLGVDNmrAkcu(wlIEpYTJxvztCXjUgdyLGVDNmrAkWu+1)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF='[B]%s >>[/B]'%'다음 페이지'
   wlIEpYTJxvztCXjUgdyLGVDNmrAkie=wlIEpYTJxvztCXjUgdyLGVDNmrAkcu(wlIEpYTJxvztCXjUgdyLGVDNmrAkWu+1)
   wlIEpYTJxvztCXjUgdyLGVDNmrAken=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel=wlIEpYTJxvztCXjUgdyLGVDNmrAkie,img=wlIEpYTJxvztCXjUgdyLGVDNmrAken,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkcf(wlIEpYTJxvztCXjUgdyLGVDNmrAkWh)>0:xbmcplugin.endOfDirectory(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,cacheToDisc=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK)
 def play_VIDEO(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiW =args.get('movie_code')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkio =args.get('season_code')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeF =args.get('title')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWH =args.get('thumbnail')
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.addon_log(wlIEpYTJxvztCXjUgdyLGVDNmrAkiW+' - '+wlIEpYTJxvztCXjUgdyLGVDNmrAkio)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiB =wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_selQuality()
  wlIEpYTJxvztCXjUgdyLGVDNmrAkes,wlIEpYTJxvztCXjUgdyLGVDNmrAkeW=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_settings_proxyport()
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeK=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_settings_playback()
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiQ=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.GetStreamingURL(wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,wlIEpYTJxvztCXjUgdyLGVDNmrAkiB,proxyUse=wlIEpYTJxvztCXjUgdyLGVDNmrAkes,inScreen=wlIEpYTJxvztCXjUgdyLGVDNmrAkeK['sel_screen'],inSound=wlIEpYTJxvztCXjUgdyLGVDNmrAkeK['sel_sound'])
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkiQ['streamUrl']=='':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.addon_noti(__language__(30908).encode('utf8'))
   return
  wlIEpYTJxvztCXjUgdyLGVDNmrAkic=wlIEpYTJxvztCXjUgdyLGVDNmrAkiQ['streamUrl']
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.addon_log(wlIEpYTJxvztCXjUgdyLGVDNmrAkic)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkes:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkiM={'addon':'watcham','playOption':wlIEpYTJxvztCXjUgdyLGVDNmrAkeK,}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkiM=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.Params_JsonToStr(wlIEpYTJxvztCXjUgdyLGVDNmrAkiM)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkic='http://127.0.0.1:{}/{}|proxy-mini={}'.format(wlIEpYTJxvztCXjUgdyLGVDNmrAkeW,wlIEpYTJxvztCXjUgdyLGVDNmrAkic,wlIEpYTJxvztCXjUgdyLGVDNmrAkiM)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiK=xbmcgui.ListItem(path=wlIEpYTJxvztCXjUgdyLGVDNmrAkic)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkiQ['customdata']:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkiR=wlIEpYTJxvztCXjUgdyLGVDNmrAkiQ['customdata']
   wlIEpYTJxvztCXjUgdyLGVDNmrAkiH ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   wlIEpYTJxvztCXjUgdyLGVDNmrAkiS ='mpd'
   wlIEpYTJxvztCXjUgdyLGVDNmrAkif ='com.widevine.alpha'
   wlIEpYTJxvztCXjUgdyLGVDNmrAkiF =inputstreamhelper.Helper(wlIEpYTJxvztCXjUgdyLGVDNmrAkiS,drm=wlIEpYTJxvztCXjUgdyLGVDNmrAkif)
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkiF.check_inputstream():
    wlIEpYTJxvztCXjUgdyLGVDNmrAkiu={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,'dt-custom-data':wlIEpYTJxvztCXjUgdyLGVDNmrAkiR,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream',}
    wlIEpYTJxvztCXjUgdyLGVDNmrAkih=wlIEpYTJxvztCXjUgdyLGVDNmrAkiH+'|'+urllib.parse.urlencode(wlIEpYTJxvztCXjUgdyLGVDNmrAkiu)+'|R{SSM}|'
    wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.addon_log(wlIEpYTJxvztCXjUgdyLGVDNmrAkih)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkiK.setProperty('inputstream',wlIEpYTJxvztCXjUgdyLGVDNmrAkiF.inputstream_addon)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkiK.setProperty('inputstream.adaptive.manifest_type',wlIEpYTJxvztCXjUgdyLGVDNmrAkiS)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkiK.setProperty('inputstream.adaptive.license_type',wlIEpYTJxvztCXjUgdyLGVDNmrAkif)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkiK.setProperty('inputstream.adaptive.license_key',wlIEpYTJxvztCXjUgdyLGVDNmrAkih)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkiK.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.USER_AGENT))
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkiQ['subtitleUrl']:
   try:
    f=wlIEpYTJxvztCXjUgdyLGVDNmrAkch(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_SUBTITLE_VTT,'w',-1,'utf-8')
    wlIEpYTJxvztCXjUgdyLGVDNmrAkin=requests.get(wlIEpYTJxvztCXjUgdyLGVDNmrAkiQ['subtitleUrl'])
    wlIEpYTJxvztCXjUgdyLGVDNmrAkib=wlIEpYTJxvztCXjUgdyLGVDNmrAkin.content.decode('utf-8') 
    for wlIEpYTJxvztCXjUgdyLGVDNmrAkia in wlIEpYTJxvztCXjUgdyLGVDNmrAkib.splitlines():
     wlIEpYTJxvztCXjUgdyLGVDNmrAkiq=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',wlIEpYTJxvztCXjUgdyLGVDNmrAkia)
     f.write(wlIEpYTJxvztCXjUgdyLGVDNmrAkiq+'\n')
    f.close()
    wlIEpYTJxvztCXjUgdyLGVDNmrAkiK.setSubtitles([wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_SUBTITLE_VTT,wlIEpYTJxvztCXjUgdyLGVDNmrAkiQ['subtitleUrl']])
   except:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkiK.setSubtitles([wlIEpYTJxvztCXjUgdyLGVDNmrAkiQ['subtitleUrl']])
  xbmcplugin.setResolvedUrl(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,wlIEpYTJxvztCXjUgdyLGVDNmrAkiK)
  try:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWF='movie' if wlIEpYTJxvztCXjUgdyLGVDNmrAkio=='-' else 'seasons'
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'code':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW if wlIEpYTJxvztCXjUgdyLGVDNmrAkWF=='movie' else wlIEpYTJxvztCXjUgdyLGVDNmrAkio,'img':wlIEpYTJxvztCXjUgdyLGVDNmrAkWH,'title':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,'videoid':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW}
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.Save_Watched_List(wlIEpYTJxvztCXjUgdyLGVDNmrAkWF,wlIEpYTJxvztCXjUgdyLGVDNmrAkeb)
  except:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ
 def srtConvert(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,wlIEpYTJxvztCXjUgdyLGVDNmrAkiO):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiP=re.sub(r'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',wlIEpYTJxvztCXjUgdyLGVDNmrAkiO)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiP=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',wlIEpYTJxvztCXjUgdyLGVDNmrAkiP)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiP=re.sub(r'(\d\d).(\d\d\d) --> (\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',wlIEpYTJxvztCXjUgdyLGVDNmrAkiP)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiP=re.sub(r'WEBVTT\n','',wlIEpYTJxvztCXjUgdyLGVDNmrAkiP)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiP=re.sub(r'Kind:[ \-\w]+\n','',wlIEpYTJxvztCXjUgdyLGVDNmrAkiP)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiP=re.sub(r'Language:[ \-\w]+\n','',wlIEpYTJxvztCXjUgdyLGVDNmrAkiP)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiP=re.sub(r'<c[.\w\d]*>','',wlIEpYTJxvztCXjUgdyLGVDNmrAkiP)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiP=re.sub(r'</c>','',wlIEpYTJxvztCXjUgdyLGVDNmrAkiP)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiP=re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>','',wlIEpYTJxvztCXjUgdyLGVDNmrAkiP)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiP=re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n','',wlIEpYTJxvztCXjUgdyLGVDNmrAkiP)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkiP=re.sub(r'Style:\n##\n','',wlIEpYTJxvztCXjUgdyLGVDNmrAkiP)
  return wlIEpYTJxvztCXjUgdyLGVDNmrAkiP
 def vtt_to_srt(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,vttFilename,srtFilename):
  try:
   f=wlIEpYTJxvztCXjUgdyLGVDNmrAkch(vttFilename,'r',-1,'utf-8')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkiO=f.read()
   f.close()
   wlIEpYTJxvztCXjUgdyLGVDNmrAkos=''
   wlIEpYTJxvztCXjUgdyLGVDNmrAkos=wlIEpYTJxvztCXjUgdyLGVDNmrAkos+wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.srtConvert(wlIEpYTJxvztCXjUgdyLGVDNmrAkiO)
   f=wlIEpYTJxvztCXjUgdyLGVDNmrAkch(srtFilename,'w',-1,'utf-8')
   f.writelines(wlIEpYTJxvztCXjUgdyLGVDNmrAkcu(wlIEpYTJxvztCXjUgdyLGVDNmrAkos))
   f.close()
  except:
   return wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  return wlIEpYTJxvztCXjUgdyLGVDNmrAkcK
 def dp_Category_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWF =args.get('stype')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkis =args.get('tag_id')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWO=args.get('api_path')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWu=wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(args.get('page'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAkoe=[]
  wlIEpYTJxvztCXjUgdyLGVDNmrAkoW,wlIEpYTJxvztCXjUgdyLGVDNmrAkoi=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.GetCategoryList(wlIEpYTJxvztCXjUgdyLGVDNmrAkWF,wlIEpYTJxvztCXjUgdyLGVDNmrAkis,wlIEpYTJxvztCXjUgdyLGVDNmrAkWO,wlIEpYTJxvztCXjUgdyLGVDNmrAkWu)
  for wlIEpYTJxvztCXjUgdyLGVDNmrAkoB in wlIEpYTJxvztCXjUgdyLGVDNmrAkoW:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkiW =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('code')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('title')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWK =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('content_type')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoQ =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('story')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWH =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('thumbnail')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoc =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('year')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoM =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('film_rating_code')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoK=wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('film_rating_short')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoR =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('film_rating_long')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoH =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('duration')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoS =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('badge')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoe.append(wlIEpYTJxvztCXjUgdyLGVDNmrAkiW)
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkWK=='movies': 
    wlIEpYTJxvztCXjUgdyLGVDNmrAkea =wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
    wlIEpYTJxvztCXjUgdyLGVDNmrAkof ='MOVIE'
    wlIEpYTJxvztCXjUgdyLGVDNmrAkio='-'
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoF ='movie'
   else: 
    wlIEpYTJxvztCXjUgdyLGVDNmrAkea =wlIEpYTJxvztCXjUgdyLGVDNmrAkcK
    wlIEpYTJxvztCXjUgdyLGVDNmrAkof ='SEASON'
    wlIEpYTJxvztCXjUgdyLGVDNmrAkio=wlIEpYTJxvztCXjUgdyLGVDNmrAkiW
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoF ='tvshow' 
   wlIEpYTJxvztCXjUgdyLGVDNmrAkou={'mediatype':wlIEpYTJxvztCXjUgdyLGVDNmrAkoF,'mpaa':wlIEpYTJxvztCXjUgdyLGVDNmrAkoR,'title':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,'year':wlIEpYTJxvztCXjUgdyLGVDNmrAkoc,'duration':wlIEpYTJxvztCXjUgdyLGVDNmrAkoH,'plot':wlIEpYTJxvztCXjUgdyLGVDNmrAkoQ,}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF+='  (%s)'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkoc)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':wlIEpYTJxvztCXjUgdyLGVDNmrAkof,'movie_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,'page':'1','season_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkio,'title':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,'thumbnail':wlIEpYTJxvztCXjUgdyLGVDNmrAkWH,}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoh=[]
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkWO=='users/me/watchings':
    wlIEpYTJxvztCXjUgdyLGVDNmrAkon={'codeList':[wlIEpYTJxvztCXjUgdyLGVDNmrAkiW]}
    wlIEpYTJxvztCXjUgdyLGVDNmrAkob=json.dumps(wlIEpYTJxvztCXjUgdyLGVDNmrAkon)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkob=urllib.parse.quote(wlIEpYTJxvztCXjUgdyLGVDNmrAkob)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoa='RunPlugin(plugin://plugin.video.watcham/?mode=DELETE_CONTINUE&bm_param=%s)'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkob)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoh.append(('(선택영상) 이어보기에서 삭제',wlIEpYTJxvztCXjUgdyLGVDNmrAkoa))
   if wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_settings_makebookmark():
    wlIEpYTJxvztCXjUgdyLGVDNmrAkon={'videoid':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,'vidtype':'tvshow' if wlIEpYTJxvztCXjUgdyLGVDNmrAkWK=='tv_seasons' else 'movie','vtitle':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,'vsubtitle':'',}
    wlIEpYTJxvztCXjUgdyLGVDNmrAkob=json.dumps(wlIEpYTJxvztCXjUgdyLGVDNmrAkon)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkob=urllib.parse.quote(wlIEpYTJxvztCXjUgdyLGVDNmrAkob)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoa='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkob)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoh.append(('(통합) 찜 영상에 추가',wlIEpYTJxvztCXjUgdyLGVDNmrAkoa))
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel=wlIEpYTJxvztCXjUgdyLGVDNmrAkoS,img=wlIEpYTJxvztCXjUgdyLGVDNmrAkWH,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkou,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkea,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb,ContextMenu=wlIEpYTJxvztCXjUgdyLGVDNmrAkoh)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkWO=='users/me/watchings':
   wlIEpYTJxvztCXjUgdyLGVDNmrAkon={'codeList':wlIEpYTJxvztCXjUgdyLGVDNmrAkoe}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkob=json.dumps(wlIEpYTJxvztCXjUgdyLGVDNmrAkon,separators=(',',':'))
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.addon_log(wlIEpYTJxvztCXjUgdyLGVDNmrAkob)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkob=urllib.parse.quote(wlIEpYTJxvztCXjUgdyLGVDNmrAkob)
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.addon_log(wlIEpYTJxvztCXjUgdyLGVDNmrAkob)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'DELETE_CONTINUE','bm_param':wlIEpYTJxvztCXjUgdyLGVDNmrAkon,}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkou={'plot':'이어보기 목록 전체를 삭제합니다.'}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF='** 이어보기 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   wlIEpYTJxvztCXjUgdyLGVDNmrAken=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel='',img=wlIEpYTJxvztCXjUgdyLGVDNmrAken,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkou,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb,isLink=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkoi:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['mode'] ='CATEGORY_LIST'
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['stype'] =wlIEpYTJxvztCXjUgdyLGVDNmrAkWF
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['tag_id'] =wlIEpYTJxvztCXjUgdyLGVDNmrAkis
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['api_path']=wlIEpYTJxvztCXjUgdyLGVDNmrAkWO
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['page'] =wlIEpYTJxvztCXjUgdyLGVDNmrAkcu(wlIEpYTJxvztCXjUgdyLGVDNmrAkWu+1)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF='[B]%s >>[/B]'%'다음 페이지'
   wlIEpYTJxvztCXjUgdyLGVDNmrAkie=wlIEpYTJxvztCXjUgdyLGVDNmrAkcu(wlIEpYTJxvztCXjUgdyLGVDNmrAkWu+1)
   wlIEpYTJxvztCXjUgdyLGVDNmrAken=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel=wlIEpYTJxvztCXjUgdyLGVDNmrAkie,img=wlIEpYTJxvztCXjUgdyLGVDNmrAken,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb)
  xbmcplugin.setContent(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,'movies')
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkcf(wlIEpYTJxvztCXjUgdyLGVDNmrAkoW)>0:
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkWO=='arrivals/latest':
    xbmcplugin.endOfDirectory(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,cacheToDisc=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK)
   else:
    xbmcplugin.endOfDirectory(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,cacheToDisc=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR)
 def dp_Season_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkio=args.get('season_code')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWH =args.get('thumbnail')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWH=json.loads(wlIEpYTJxvztCXjUgdyLGVDNmrAkWH.replace('\'','"'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAkoq=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.GetSeasonList(wlIEpYTJxvztCXjUgdyLGVDNmrAkio)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkcf(wlIEpYTJxvztCXjUgdyLGVDNmrAkoq)>1:
   for wlIEpYTJxvztCXjUgdyLGVDNmrAkoP in wlIEpYTJxvztCXjUgdyLGVDNmrAkoq:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoO=wlIEpYTJxvztCXjUgdyLGVDNmrAkoP.get('seasonId')
    wlIEpYTJxvztCXjUgdyLGVDNmrAkBs=wlIEpYTJxvztCXjUgdyLGVDNmrAkoP.get('seasonNm')
    wlIEpYTJxvztCXjUgdyLGVDNmrAkou={'mediatype':'tvshow','title':wlIEpYTJxvztCXjUgdyLGVDNmrAkBs,}
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'EPISODE','movie_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkoO,'page':'1','season_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkoO,'title':wlIEpYTJxvztCXjUgdyLGVDNmrAkBs,'thumbnail':wlIEpYTJxvztCXjUgdyLGVDNmrAkWH,}
    wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkBs,sublabel=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,img=wlIEpYTJxvztCXjUgdyLGVDNmrAkWH,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkou,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb,ContextMenu=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ)
   xbmcplugin.setContent(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,cacheToDisc=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR)
  else:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBe={'movie_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkio,'page':'1','season_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkio,}
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Episode_List(wlIEpYTJxvztCXjUgdyLGVDNmrAkBe)
 def dp_Episode_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkBW=args.get('movie_code')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWu =wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(args.get('page'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAkio =args.get('season_code')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkoW,wlIEpYTJxvztCXjUgdyLGVDNmrAkoi=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.GetEpisodoList(wlIEpYTJxvztCXjUgdyLGVDNmrAkBW,wlIEpYTJxvztCXjUgdyLGVDNmrAkWu,orderby=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_winEpisodeOrderby())
  for wlIEpYTJxvztCXjUgdyLGVDNmrAkoB in wlIEpYTJxvztCXjUgdyLGVDNmrAkoW:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkiW =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('code')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('title')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWH =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('thumbnail')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBi =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('display_num')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBo =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('season_title')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBQ=wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('episode_number')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoH =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('duration')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkou={'mediatype':'episode','tvshowtitle':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF if wlIEpYTJxvztCXjUgdyLGVDNmrAkeF!='' else wlIEpYTJxvztCXjUgdyLGVDNmrAkBo,'title':'%s %s'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkBo,wlIEpYTJxvztCXjUgdyLGVDNmrAkBi)if wlIEpYTJxvztCXjUgdyLGVDNmrAkeF!='' else wlIEpYTJxvztCXjUgdyLGVDNmrAkBi,'episode':wlIEpYTJxvztCXjUgdyLGVDNmrAkBQ,'duration':wlIEpYTJxvztCXjUgdyLGVDNmrAkoH,'plot':'%s\n%s\n\n%s'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkBo,wlIEpYTJxvztCXjUgdyLGVDNmrAkBi,wlIEpYTJxvztCXjUgdyLGVDNmrAkeF)}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF='(%s) %s'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkBi,wlIEpYTJxvztCXjUgdyLGVDNmrAkeF)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'MOVIE','movie_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,'season_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkio,'title':'%s < %s >'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,wlIEpYTJxvztCXjUgdyLGVDNmrAkBo),'thumbnail':wlIEpYTJxvztCXjUgdyLGVDNmrAkWH}
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel=wlIEpYTJxvztCXjUgdyLGVDNmrAkBo,img=wlIEpYTJxvztCXjUgdyLGVDNmrAkWH,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkou,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkWu==1:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkou={'plot':'정렬순서를 변경합니다.'}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['mode'] ='ORDER_BY' 
   if wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_winEpisodeOrderby()=='desc':
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeF='정렬순서변경 : 최신화부터 -> 1회부터'
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['orderby']='asc'
   else:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeF='정렬순서변경 : 1회부터 -> 최신화부터'
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['orderby']='desc'
   wlIEpYTJxvztCXjUgdyLGVDNmrAken=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel='',img=wlIEpYTJxvztCXjUgdyLGVDNmrAken,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkou,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb,isLink=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkoi:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['mode'] ='EPISODE' 
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['movie_code']=wlIEpYTJxvztCXjUgdyLGVDNmrAkBW
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['page'] =wlIEpYTJxvztCXjUgdyLGVDNmrAkcu(wlIEpYTJxvztCXjUgdyLGVDNmrAkWu+1)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF='[B]%s >>[/B]'%'다음 페이지'
   wlIEpYTJxvztCXjUgdyLGVDNmrAkie=wlIEpYTJxvztCXjUgdyLGVDNmrAkcu(wlIEpYTJxvztCXjUgdyLGVDNmrAkWu+1)
   wlIEpYTJxvztCXjUgdyLGVDNmrAken=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel=wlIEpYTJxvztCXjUgdyLGVDNmrAkie,img=wlIEpYTJxvztCXjUgdyLGVDNmrAken,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb)
  xbmcplugin.setContent(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,'episodes')
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkcf(wlIEpYTJxvztCXjUgdyLGVDNmrAkoW)>0:xbmcplugin.endOfDirectory(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,cacheToDisc=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK)
 def dp_Search_History(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkBc=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.Load_List_File('search')
  for wlIEpYTJxvztCXjUgdyLGVDNmrAkBM in wlIEpYTJxvztCXjUgdyLGVDNmrAkBc:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBK=wlIEpYTJxvztCXjUgdyLGVDNmrAkcS(urllib.parse.parse_qsl(wlIEpYTJxvztCXjUgdyLGVDNmrAkBM))
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBR=wlIEpYTJxvztCXjUgdyLGVDNmrAkBK.get('skey').strip()
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'LOCAL_SEARCH','search_key':wlIEpYTJxvztCXjUgdyLGVDNmrAkBR,'page':'1','historyyn':'Y',}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBH={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':wlIEpYTJxvztCXjUgdyLGVDNmrAkBR,'vType':'-',}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBS=urllib.parse.urlencode(wlIEpYTJxvztCXjUgdyLGVDNmrAkBH)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoh=[('선택된 검색어 ( %s ) 삭제'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkBR),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkBS))]
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkBR,sublabel='',img=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb,ContextMenu=wlIEpYTJxvztCXjUgdyLGVDNmrAkoh)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkou={'plot':'검색목록 전체를 삭제합니다.'}
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeF='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  wlIEpYTJxvztCXjUgdyLGVDNmrAken=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel='',img=wlIEpYTJxvztCXjUgdyLGVDNmrAken,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkou,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb,isLink=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK)
  xbmcplugin.endOfDirectory(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,cacheToDisc=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR)
 def dp_Search_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWu =wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(args.get('page'))
  if 'search_key' in args:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBf=args.get('search_key')
  else:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBf=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not wlIEpYTJxvztCXjUgdyLGVDNmrAkBf:
    return
  wlIEpYTJxvztCXjUgdyLGVDNmrAkoW,wlIEpYTJxvztCXjUgdyLGVDNmrAkoi=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.GetSearchList(wlIEpYTJxvztCXjUgdyLGVDNmrAkBf,wlIEpYTJxvztCXjUgdyLGVDNmrAkWu)
  for wlIEpYTJxvztCXjUgdyLGVDNmrAkoB in wlIEpYTJxvztCXjUgdyLGVDNmrAkoW:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkiW =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('code')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('title')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWK=wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('content_type')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoQ =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('story')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWH =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('thumbnail')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoc =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('year')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoM =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('film_rating_code')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoK=wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('film_rating_short')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoR =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('film_rating_long')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkoH =wlIEpYTJxvztCXjUgdyLGVDNmrAkoB.get('duration')
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkWK=='movies': 
    wlIEpYTJxvztCXjUgdyLGVDNmrAkea =wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
    wlIEpYTJxvztCXjUgdyLGVDNmrAkof ='MOVIE'
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeP =''
    wlIEpYTJxvztCXjUgdyLGVDNmrAkio='-'
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoF ='movie'
   else: 
    wlIEpYTJxvztCXjUgdyLGVDNmrAkea =wlIEpYTJxvztCXjUgdyLGVDNmrAkcK
    wlIEpYTJxvztCXjUgdyLGVDNmrAkof ='SEASON'
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeP ='' 
    wlIEpYTJxvztCXjUgdyLGVDNmrAkio=wlIEpYTJxvztCXjUgdyLGVDNmrAkiW
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoF ='tvshow' 
   wlIEpYTJxvztCXjUgdyLGVDNmrAkou={'mediatype':wlIEpYTJxvztCXjUgdyLGVDNmrAkoF,'mpaa':wlIEpYTJxvztCXjUgdyLGVDNmrAkoR,'title':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,'year':wlIEpYTJxvztCXjUgdyLGVDNmrAkoc,'duration':wlIEpYTJxvztCXjUgdyLGVDNmrAkoH,'plot':wlIEpYTJxvztCXjUgdyLGVDNmrAkoQ}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF+='  (%s)'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkoc)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':wlIEpYTJxvztCXjUgdyLGVDNmrAkof,'movie_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,'page':'1','season_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkio,'title':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,'thumbnail':wlIEpYTJxvztCXjUgdyLGVDNmrAkWH}
   if wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_settings_makebookmark():
    wlIEpYTJxvztCXjUgdyLGVDNmrAkon={'videoid':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,'vidtype':'tvshow' if wlIEpYTJxvztCXjUgdyLGVDNmrAkWK=='tv_seasons' else 'movie','vtitle':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,'vsubtitle':'',}
    wlIEpYTJxvztCXjUgdyLGVDNmrAkob=json.dumps(wlIEpYTJxvztCXjUgdyLGVDNmrAkon)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkob=urllib.parse.quote(wlIEpYTJxvztCXjUgdyLGVDNmrAkob)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoa='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkob)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoh=[('(통합) 찜 영상에 추가',wlIEpYTJxvztCXjUgdyLGVDNmrAkoa)]
   else:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoh=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel=wlIEpYTJxvztCXjUgdyLGVDNmrAkeP,img=wlIEpYTJxvztCXjUgdyLGVDNmrAkWH,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkou,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkea,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb,ContextMenu=wlIEpYTJxvztCXjUgdyLGVDNmrAkoh)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkoi:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['mode'] ='SEARCH'
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['search_key']=wlIEpYTJxvztCXjUgdyLGVDNmrAkBf
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb['page'] =wlIEpYTJxvztCXjUgdyLGVDNmrAkcu(wlIEpYTJxvztCXjUgdyLGVDNmrAkWu+1)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF='[B]%s >>[/B]'%'다음 페이지'
   wlIEpYTJxvztCXjUgdyLGVDNmrAkie=wlIEpYTJxvztCXjUgdyLGVDNmrAkcu(wlIEpYTJxvztCXjUgdyLGVDNmrAkWu+1)
   wlIEpYTJxvztCXjUgdyLGVDNmrAken=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel=wlIEpYTJxvztCXjUgdyLGVDNmrAkie,img=wlIEpYTJxvztCXjUgdyLGVDNmrAken,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb)
  xbmcplugin.setContent(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,'movies')
  xbmcplugin.endOfDirectory(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,cacheToDisc=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK)
  if args.get('historyyn')=='Y':wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.Save_Searched_List(wlIEpYTJxvztCXjUgdyLGVDNmrAkBf)
 def dp_Delete_Continue(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkBF=urllib.parse.unquote(args.get('bm_param'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAkBF=wlIEpYTJxvztCXjUgdyLGVDNmrAkBF.replace('\'','"')
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.addon_log(wlIEpYTJxvztCXjUgdyLGVDNmrAkBF)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkBF=json.loads(wlIEpYTJxvztCXjUgdyLGVDNmrAkBF)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkoe=wlIEpYTJxvztCXjUgdyLGVDNmrAkBF.get('codeList')
  wlIEpYTJxvztCXjUgdyLGVDNmrAksH=xbmcgui.Dialog()
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWi=wlIEpYTJxvztCXjUgdyLGVDNmrAksH.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkWi==wlIEpYTJxvztCXjUgdyLGVDNmrAkcR:sys.exit()
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.DeleteContinueList(wlIEpYTJxvztCXjUgdyLGVDNmrAkoe)
  xbmc.executebuiltin("Container.Refresh")
 def dp_History_Remove(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkBu=args.get('delType')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkBh =args.get('sKey')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkBn =args.get('vType')
  wlIEpYTJxvztCXjUgdyLGVDNmrAksH=xbmcgui.Dialog()
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkBu=='SEARCH_ALL':
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWi=wlIEpYTJxvztCXjUgdyLGVDNmrAksH.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkBu=='SEARCH_ONE':
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWi=wlIEpYTJxvztCXjUgdyLGVDNmrAksH.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkBu=='WATCH_ALL':
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWi=wlIEpYTJxvztCXjUgdyLGVDNmrAksH.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkBu=='WATCH_ONE':
   wlIEpYTJxvztCXjUgdyLGVDNmrAkWi=wlIEpYTJxvztCXjUgdyLGVDNmrAksH.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkWi==wlIEpYTJxvztCXjUgdyLGVDNmrAkcR:sys.exit()
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkBu=='SEARCH_ALL':
   if os.path.isfile(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_SEARCHEDC_FILENAME):os.remove(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_SEARCHEDC_FILENAME)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkBu=='SEARCH_ONE':
   try:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkBb=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_SEARCHEDC_FILENAME
    wlIEpYTJxvztCXjUgdyLGVDNmrAkBa=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.Load_List_File('search') 
    fp=wlIEpYTJxvztCXjUgdyLGVDNmrAkch(wlIEpYTJxvztCXjUgdyLGVDNmrAkBb,'w',-1,'utf-8')
    for wlIEpYTJxvztCXjUgdyLGVDNmrAkBq in wlIEpYTJxvztCXjUgdyLGVDNmrAkBa:
     wlIEpYTJxvztCXjUgdyLGVDNmrAkBP=wlIEpYTJxvztCXjUgdyLGVDNmrAkcS(urllib.parse.parse_qsl(wlIEpYTJxvztCXjUgdyLGVDNmrAkBq))
     wlIEpYTJxvztCXjUgdyLGVDNmrAkBO=wlIEpYTJxvztCXjUgdyLGVDNmrAkBP.get('skey').strip()
     if wlIEpYTJxvztCXjUgdyLGVDNmrAkBh!=wlIEpYTJxvztCXjUgdyLGVDNmrAkBO:
      fp.write(wlIEpYTJxvztCXjUgdyLGVDNmrAkBq)
    fp.close()
   except:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkBu=='WATCH_ALL':
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBb=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wlIEpYTJxvztCXjUgdyLGVDNmrAkBn))
   if os.path.isfile(wlIEpYTJxvztCXjUgdyLGVDNmrAkBb):os.remove(wlIEpYTJxvztCXjUgdyLGVDNmrAkBb)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkBu=='WATCH_ONE':
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBb=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wlIEpYTJxvztCXjUgdyLGVDNmrAkBn))
   try:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkBa=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.Load_List_File(wlIEpYTJxvztCXjUgdyLGVDNmrAkBn) 
    fp=wlIEpYTJxvztCXjUgdyLGVDNmrAkch(wlIEpYTJxvztCXjUgdyLGVDNmrAkBb,'w',-1,'utf-8')
    for wlIEpYTJxvztCXjUgdyLGVDNmrAkBq in wlIEpYTJxvztCXjUgdyLGVDNmrAkBa:
     wlIEpYTJxvztCXjUgdyLGVDNmrAkBP=wlIEpYTJxvztCXjUgdyLGVDNmrAkcS(urllib.parse.parse_qsl(wlIEpYTJxvztCXjUgdyLGVDNmrAkBq))
     wlIEpYTJxvztCXjUgdyLGVDNmrAkBO=wlIEpYTJxvztCXjUgdyLGVDNmrAkBP.get('code').strip()
     if wlIEpYTJxvztCXjUgdyLGVDNmrAkBh!=wlIEpYTJxvztCXjUgdyLGVDNmrAkBO:
      fp.write(wlIEpYTJxvztCXjUgdyLGVDNmrAkBq)
    fp.close()
   except:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,wlIEpYTJxvztCXjUgdyLGVDNmrAkWF): 
  try:
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkWF=='search':
    wlIEpYTJxvztCXjUgdyLGVDNmrAkBb=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_SEARCHEDC_FILENAME
   elif wlIEpYTJxvztCXjUgdyLGVDNmrAkWF in['seasons','movie']:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkBb=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wlIEpYTJxvztCXjUgdyLGVDNmrAkWF))
   else:
    return[]
   fp=wlIEpYTJxvztCXjUgdyLGVDNmrAkch(wlIEpYTJxvztCXjUgdyLGVDNmrAkBb,'r',-1,'utf-8')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQs=fp.readlines()
   fp.close()
  except:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQs=[]
  return wlIEpYTJxvztCXjUgdyLGVDNmrAkQs
 def Save_Watched_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,wlIEpYTJxvztCXjUgdyLGVDNmrAkWF,wlIEpYTJxvztCXjUgdyLGVDNmrAksK):
  try:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQe=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wlIEpYTJxvztCXjUgdyLGVDNmrAkWF))
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBa=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.Load_List_File(wlIEpYTJxvztCXjUgdyLGVDNmrAkWF) 
   fp=wlIEpYTJxvztCXjUgdyLGVDNmrAkch(wlIEpYTJxvztCXjUgdyLGVDNmrAkQe,'w',-1,'utf-8')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQW=urllib.parse.urlencode(wlIEpYTJxvztCXjUgdyLGVDNmrAksK)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQW=wlIEpYTJxvztCXjUgdyLGVDNmrAkQW+'\n'
   fp.write(wlIEpYTJxvztCXjUgdyLGVDNmrAkQW)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQi=0
   for wlIEpYTJxvztCXjUgdyLGVDNmrAkBq in wlIEpYTJxvztCXjUgdyLGVDNmrAkBa:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkBP=wlIEpYTJxvztCXjUgdyLGVDNmrAkcS(urllib.parse.parse_qsl(wlIEpYTJxvztCXjUgdyLGVDNmrAkBq))
    wlIEpYTJxvztCXjUgdyLGVDNmrAkQo=wlIEpYTJxvztCXjUgdyLGVDNmrAksK.get('code').strip()
    wlIEpYTJxvztCXjUgdyLGVDNmrAkQB=wlIEpYTJxvztCXjUgdyLGVDNmrAkBP.get('code').strip()
    if wlIEpYTJxvztCXjUgdyLGVDNmrAkWF=='seasons' and wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_settings_direct_replay()==wlIEpYTJxvztCXjUgdyLGVDNmrAkcK:
     wlIEpYTJxvztCXjUgdyLGVDNmrAkQo=wlIEpYTJxvztCXjUgdyLGVDNmrAksK.get('videoid').strip()
     wlIEpYTJxvztCXjUgdyLGVDNmrAkQB=wlIEpYTJxvztCXjUgdyLGVDNmrAkBP.get('videoid').strip()if wlIEpYTJxvztCXjUgdyLGVDNmrAkQB!=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ else '-'
    if wlIEpYTJxvztCXjUgdyLGVDNmrAkQo!=wlIEpYTJxvztCXjUgdyLGVDNmrAkQB:
     fp.write(wlIEpYTJxvztCXjUgdyLGVDNmrAkBq)
     wlIEpYTJxvztCXjUgdyLGVDNmrAkQi+=1
     if wlIEpYTJxvztCXjUgdyLGVDNmrAkQi>=50:break
   fp.close()
  except:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ
 def dp_Watch_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWF =args.get('stype')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkeH=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_settings_direct_replay()
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkWF=='-':
   for wlIEpYTJxvztCXjUgdyLGVDNmrAkQc in wlIEpYTJxvztCXjUgdyLGVDNmrAksi:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeF=wlIEpYTJxvztCXjUgdyLGVDNmrAkQc.get('title')
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':wlIEpYTJxvztCXjUgdyLGVDNmrAkQc.get('mode'),'stype':wlIEpYTJxvztCXjUgdyLGVDNmrAkQc.get('stype')}
    wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel='',img='',infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb)
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkcf(wlIEpYTJxvztCXjUgdyLGVDNmrAksi)>0:xbmcplugin.endOfDirectory(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle)
  else:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQM=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.Load_List_File(wlIEpYTJxvztCXjUgdyLGVDNmrAkWF)
   for wlIEpYTJxvztCXjUgdyLGVDNmrAkQK in wlIEpYTJxvztCXjUgdyLGVDNmrAkQM:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkBK=wlIEpYTJxvztCXjUgdyLGVDNmrAkcS(urllib.parse.parse_qsl(wlIEpYTJxvztCXjUgdyLGVDNmrAkQK))
    wlIEpYTJxvztCXjUgdyLGVDNmrAkiW=wlIEpYTJxvztCXjUgdyLGVDNmrAkBK.get('code').strip()
    wlIEpYTJxvztCXjUgdyLGVDNmrAkeF =wlIEpYTJxvztCXjUgdyLGVDNmrAkBK.get('title').strip()
    wlIEpYTJxvztCXjUgdyLGVDNmrAkWH =wlIEpYTJxvztCXjUgdyLGVDNmrAkBK.get('img').strip()
    wlIEpYTJxvztCXjUgdyLGVDNmrAkQR =wlIEpYTJxvztCXjUgdyLGVDNmrAkBK.get('videoid').strip()
    try:
     wlIEpYTJxvztCXjUgdyLGVDNmrAkWH=wlIEpYTJxvztCXjUgdyLGVDNmrAkWH.replace('\'','\"')
     wlIEpYTJxvztCXjUgdyLGVDNmrAkWH=json.loads(wlIEpYTJxvztCXjUgdyLGVDNmrAkWH)
    except:
     wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ
    wlIEpYTJxvztCXjUgdyLGVDNmrAkou={}
    wlIEpYTJxvztCXjUgdyLGVDNmrAkou['plot']=wlIEpYTJxvztCXjUgdyLGVDNmrAkeF
    if wlIEpYTJxvztCXjUgdyLGVDNmrAkWF=='movie':
     wlIEpYTJxvztCXjUgdyLGVDNmrAkou['mediatype']='movie'
     wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'MOVIE','page':'1','movie_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,'season_code':'-','title':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,'thumbnail':wlIEpYTJxvztCXjUgdyLGVDNmrAkWH}
     wlIEpYTJxvztCXjUgdyLGVDNmrAkea=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
    else:
     if wlIEpYTJxvztCXjUgdyLGVDNmrAkeH==wlIEpYTJxvztCXjUgdyLGVDNmrAkcR or wlIEpYTJxvztCXjUgdyLGVDNmrAkQR==wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ:
      wlIEpYTJxvztCXjUgdyLGVDNmrAkou['mediatype']='tvshow'
      wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'EPISODE','page':'1','movie_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,'season_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,'title':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,'thumbnail':wlIEpYTJxvztCXjUgdyLGVDNmrAkWH}
      wlIEpYTJxvztCXjUgdyLGVDNmrAkea=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK
     else:
      wlIEpYTJxvztCXjUgdyLGVDNmrAkou['mediatype']='episode'
      wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'MOVIE','movie_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkQR,'season_code':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,'title':wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,'thumbnail':wlIEpYTJxvztCXjUgdyLGVDNmrAkWH}
      wlIEpYTJxvztCXjUgdyLGVDNmrAkea=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
    wlIEpYTJxvztCXjUgdyLGVDNmrAkBH={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':wlIEpYTJxvztCXjUgdyLGVDNmrAkiW,'vType':wlIEpYTJxvztCXjUgdyLGVDNmrAkWF,}
    wlIEpYTJxvztCXjUgdyLGVDNmrAkBS=urllib.parse.urlencode(wlIEpYTJxvztCXjUgdyLGVDNmrAkBH)
    wlIEpYTJxvztCXjUgdyLGVDNmrAkoh=[('선택된 시청이력 ( %s ) 삭제'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkBS))]
    wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel='',img=wlIEpYTJxvztCXjUgdyLGVDNmrAkWH,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkou,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkea,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb,ContextMenu=wlIEpYTJxvztCXjUgdyLGVDNmrAkoh)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkou={'plot':'시청목록을 삭제합니다.'}
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeF='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   wlIEpYTJxvztCXjUgdyLGVDNmrAkeb={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':wlIEpYTJxvztCXjUgdyLGVDNmrAkWF,}
   wlIEpYTJxvztCXjUgdyLGVDNmrAken=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.add_dir(wlIEpYTJxvztCXjUgdyLGVDNmrAkeF,sublabel='',img=wlIEpYTJxvztCXjUgdyLGVDNmrAken,infoLabels=wlIEpYTJxvztCXjUgdyLGVDNmrAkou,isFolder=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR,params=wlIEpYTJxvztCXjUgdyLGVDNmrAkeb,isLink=wlIEpYTJxvztCXjUgdyLGVDNmrAkcK)
   if wlIEpYTJxvztCXjUgdyLGVDNmrAkWF=='movie':xbmcplugin.setContent(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,'movies')
   else:xbmcplugin.setContent(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ._addon_handle,cacheToDisc=wlIEpYTJxvztCXjUgdyLGVDNmrAkcR)
 def Save_Searched_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,wlIEpYTJxvztCXjUgdyLGVDNmrAkBf):
  try:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQH=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_SEARCHEDC_FILENAME
   wlIEpYTJxvztCXjUgdyLGVDNmrAkBa=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.Load_List_File('search') 
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQS={'skey':wlIEpYTJxvztCXjUgdyLGVDNmrAkBf.strip()}
   fp=wlIEpYTJxvztCXjUgdyLGVDNmrAkch(wlIEpYTJxvztCXjUgdyLGVDNmrAkQH,'w',-1,'utf-8')
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQW=urllib.parse.urlencode(wlIEpYTJxvztCXjUgdyLGVDNmrAkQS)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQW=wlIEpYTJxvztCXjUgdyLGVDNmrAkQW+'\n'
   fp.write(wlIEpYTJxvztCXjUgdyLGVDNmrAkQW)
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQi=0
   for wlIEpYTJxvztCXjUgdyLGVDNmrAkBq in wlIEpYTJxvztCXjUgdyLGVDNmrAkBa:
    wlIEpYTJxvztCXjUgdyLGVDNmrAkBP=wlIEpYTJxvztCXjUgdyLGVDNmrAkcS(urllib.parse.parse_qsl(wlIEpYTJxvztCXjUgdyLGVDNmrAkBq))
    wlIEpYTJxvztCXjUgdyLGVDNmrAkQo=wlIEpYTJxvztCXjUgdyLGVDNmrAkQS.get('skey').strip()
    wlIEpYTJxvztCXjUgdyLGVDNmrAkQB=wlIEpYTJxvztCXjUgdyLGVDNmrAkBP.get('skey').strip()
    if wlIEpYTJxvztCXjUgdyLGVDNmrAkQo!=wlIEpYTJxvztCXjUgdyLGVDNmrAkQB:
     fp.write(wlIEpYTJxvztCXjUgdyLGVDNmrAkBq)
     wlIEpYTJxvztCXjUgdyLGVDNmrAkQi+=1
     if wlIEpYTJxvztCXjUgdyLGVDNmrAkQi>=50:break
   fp.close()
  except:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ
 def logout(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  wlIEpYTJxvztCXjUgdyLGVDNmrAksH=xbmcgui.Dialog()
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWi=wlIEpYTJxvztCXjUgdyLGVDNmrAksH.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkWi==wlIEpYTJxvztCXjUgdyLGVDNmrAkcR:sys.exit()
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.Init_WC_Total()
  if os.path.isfile(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_COOKIE_FILENAME):os.remove(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_COOKIE_FILENAME)
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkQf =wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.Get_Now_Datetime()
  wlIEpYTJxvztCXjUgdyLGVDNmrAkQF=wlIEpYTJxvztCXjUgdyLGVDNmrAkQf+datetime.timedelta(days=wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(__addon__.getSetting('cache_ttl')))
  (wlIEpYTJxvztCXjUgdyLGVDNmrAkeO,wlIEpYTJxvztCXjUgdyLGVDNmrAkWs,wlIEpYTJxvztCXjUgdyLGVDNmrAkWe)=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_settings_account()
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.Save_session_acount(wlIEpYTJxvztCXjUgdyLGVDNmrAkeO,wlIEpYTJxvztCXjUgdyLGVDNmrAkWs,wlIEpYTJxvztCXjUgdyLGVDNmrAkWe)
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC['account']['token_limit']=wlIEpYTJxvztCXjUgdyLGVDNmrAkQF.strftime('%Y%m%d')
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.JsonFile_Save(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_COOKIE_FILENAME,wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC)
 def cookiefile_check(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.JsonFile_Load(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC_COOKIE_FILENAME)
  if 'account' not in wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC:
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.Init_WC_Total()
   return wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  if 'deviceId2' not in wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC['cookies']:
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.Init_WC_Total()
   return wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  (wlIEpYTJxvztCXjUgdyLGVDNmrAkQu,wlIEpYTJxvztCXjUgdyLGVDNmrAkQh,wlIEpYTJxvztCXjUgdyLGVDNmrAkQn)=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.get_settings_account()
  (wlIEpYTJxvztCXjUgdyLGVDNmrAkQb,wlIEpYTJxvztCXjUgdyLGVDNmrAkQa,wlIEpYTJxvztCXjUgdyLGVDNmrAkQq)=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.Load_session_acount()
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkQu!=wlIEpYTJxvztCXjUgdyLGVDNmrAkQb or wlIEpYTJxvztCXjUgdyLGVDNmrAkQh!=wlIEpYTJxvztCXjUgdyLGVDNmrAkQa or wlIEpYTJxvztCXjUgdyLGVDNmrAkQn!=wlIEpYTJxvztCXjUgdyLGVDNmrAkQq:
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.Init_WC_Total()
   return wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))>wlIEpYTJxvztCXjUgdyLGVDNmrAkcM(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.WC['account']['token_limit']):
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.Init_WC_Total()
   return wlIEpYTJxvztCXjUgdyLGVDNmrAkcR
  return wlIEpYTJxvztCXjUgdyLGVDNmrAkcK
 def dp_Global_Search(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=args.get('mode')
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='TOTAL_SEARCH':
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkQO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(wlIEpYTJxvztCXjUgdyLGVDNmrAkQO)
 def dp_Bookmark_Menu(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkQO='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(wlIEpYTJxvztCXjUgdyLGVDNmrAkQO)
 def dp_Set_Bookmark(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ,args):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkBF=urllib.parse.unquote(args.get('bm_param'))
  wlIEpYTJxvztCXjUgdyLGVDNmrAkBF=json.loads(wlIEpYTJxvztCXjUgdyLGVDNmrAkBF)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkQR =wlIEpYTJxvztCXjUgdyLGVDNmrAkBF.get('videoid')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkcs =wlIEpYTJxvztCXjUgdyLGVDNmrAkBF.get('vidtype')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkce =wlIEpYTJxvztCXjUgdyLGVDNmrAkBF.get('vtitle')
  wlIEpYTJxvztCXjUgdyLGVDNmrAkcW =wlIEpYTJxvztCXjUgdyLGVDNmrAkBF.get('vsubtitle')
  wlIEpYTJxvztCXjUgdyLGVDNmrAksH=xbmcgui.Dialog()
  wlIEpYTJxvztCXjUgdyLGVDNmrAkWi=wlIEpYTJxvztCXjUgdyLGVDNmrAksH.yesno(__language__(30913).encode('utf8'),wlIEpYTJxvztCXjUgdyLGVDNmrAkce+' \n\n'+__language__(30914))
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkWi==wlIEpYTJxvztCXjUgdyLGVDNmrAkcR:return
  wlIEpYTJxvztCXjUgdyLGVDNmrAkci=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.WatchaObj.GetBookmarkInfo(wlIEpYTJxvztCXjUgdyLGVDNmrAkQR,wlIEpYTJxvztCXjUgdyLGVDNmrAkcs)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkco=json.dumps(wlIEpYTJxvztCXjUgdyLGVDNmrAkci)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkco=urllib.parse.quote(wlIEpYTJxvztCXjUgdyLGVDNmrAkco)
  wlIEpYTJxvztCXjUgdyLGVDNmrAkoa ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(wlIEpYTJxvztCXjUgdyLGVDNmrAkco)
  xbmc.executebuiltin(wlIEpYTJxvztCXjUgdyLGVDNmrAkoa)
 def watcha_main(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ):
  wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params.get('mode',wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ)
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='LOGOUT':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.logout()
   return
  wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.login_main()
  if wlIEpYTJxvztCXjUgdyLGVDNmrAkQP is wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ:
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Main_List()
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='HOME_GROUP':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_HomeGroup_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='SUB_GROUP':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_SubGroup_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='CATEGORY_LIST':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Category_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='SEASON':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Season_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='EPISODE':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Episode_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='ORDER_BY':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_setEpOrderby(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP in['SEARCH','LOCAL_SEARCH']:
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Search_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='MOVIE':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.play_VIDEO(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='WATCH':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Watch_List(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_History_Remove(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP in['TOTAL_SEARCH','TOTAL_HISTORY']:
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Global_Search(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='SEARCH_HISTORY':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Search_History(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='MENU_BOOKMARK':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Bookmark_Menu(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='SET_BOOKMARK':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Set_Bookmark(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  elif wlIEpYTJxvztCXjUgdyLGVDNmrAkQP=='DELETE_CONTINUE':
   wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.dp_Delete_Continue(wlIEpYTJxvztCXjUgdyLGVDNmrAksQ.main_params)
  else:
   wlIEpYTJxvztCXjUgdyLGVDNmrAkcQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
