__author__="NightRain"
UMIKLwOelbivYygXDamcWCArpSHfsu=object
UMIKLwOelbivYygXDamcWCArpSHfsz=None
UMIKLwOelbivYygXDamcWCArpSHfsT=False
UMIKLwOelbivYygXDamcWCArpSHfsQ=open
UMIKLwOelbivYygXDamcWCArpSHfst=True
UMIKLwOelbivYygXDamcWCArpSHfsx=id
UMIKLwOelbivYygXDamcWCArpSHfsN=str
UMIKLwOelbivYygXDamcWCArpSHfsn=range
UMIKLwOelbivYygXDamcWCArpSHfPB=Exception
UMIKLwOelbivYygXDamcWCArpSHfPq=print
UMIKLwOelbivYygXDamcWCArpSHfPR=int
UMIKLwOelbivYygXDamcWCArpSHfPE=len
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
import string
import random
class UMIKLwOelbivYygXDamcWCArpSHfBq(UMIKLwOelbivYygXDamcWCArpSHfsu):
 def __init__(UMIKLwOelbivYygXDamcWCArpSHfBR):
  UMIKLwOelbivYygXDamcWCArpSHfBR.WC ={}
  UMIKLwOelbivYygXDamcWCArpSHfBR.Init_WC_Total()
  UMIKLwOelbivYygXDamcWCArpSHfBR.MAIN_DOMAIN ='https://watcha.com'
  UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN ='https://api-mars.watcha.com'
  UMIKLwOelbivYygXDamcWCArpSHfBR.EPISODE_LIMIT=20
  UMIKLwOelbivYygXDamcWCArpSHfBR.SEARCH_LIMIT =30
  UMIKLwOelbivYygXDamcWCArpSHfBR.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36'
  UMIKLwOelbivYygXDamcWCArpSHfBR.USER_AGENT2 ='User-Agent: Dalvik/2.1.0 (Linux; U; Android 9; A95X_F3_Air Build/A95X_F3_AIR_M)/WatchaPlay-Android/1.10.34'
  UMIKLwOelbivYygXDamcWCArpSHfBR.DEFAULT_HEADER={'user-agent':UMIKLwOelbivYygXDamcWCArpSHfBR.USER_AGENT}
  UMIKLwOelbivYygXDamcWCArpSHfBR.WC_SUBTITLE_VTT =''
  UMIKLwOelbivYygXDamcWCArpSHfBR.WC_SUBTITLE_SRT =''
  UMIKLwOelbivYygXDamcWCArpSHfBR.WC_COOKIE_FILENAME =''
  UMIKLwOelbivYygXDamcWCArpSHfBR.WC_SEARCHEDC_FILENAME=''
  UMIKLwOelbivYygXDamcWCArpSHfBR.WC_STREAM_FILENAME =''
 def Get_Base_Headers(UMIKLwOelbivYygXDamcWCArpSHfBR):
  UMIKLwOelbivYygXDamcWCArpSHfBE={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.3',}
  return UMIKLwOelbivYygXDamcWCArpSHfBE
 def Get_Base_Headers_v2(UMIKLwOelbivYygXDamcWCArpSHfBR):
  UMIKLwOelbivYygXDamcWCArpSHfBs ='1.10.35' 
  UMIKLwOelbivYygXDamcWCArpSHfBP ='30' 
  UMIKLwOelbivYygXDamcWCArpSHfBG ='NVIDIA SHIELD Android TV'
  UMIKLwOelbivYygXDamcWCArpSHfBJ =base64.standard_b64encode((UMIKLwOelbivYygXDamcWCArpSHfBG+'-'+UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['deviceId2']).encode()).decode('utf-8') 
  UMIKLwOelbivYygXDamcWCArpSHfBV ='1920x1080/2.0/320/xhdpi'
  UMIKLwOelbivYygXDamcWCArpSHfBj ='2596eb93-6e7f-4eba-925c-ddf783246860' 
  UMIKLwOelbivYygXDamcWCArpSHfBE={'X-WatchaPlay-Client-Device-Id':UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['deviceId1'],'X-WatchaPlay-Client-Device-Id2':UMIKLwOelbivYygXDamcWCArpSHfBJ,'X-WatchaPlay-Client-Device-Name':UMIKLwOelbivYygXDamcWCArpSHfBG,'X-WatchaPlay-Client-ADID':UMIKLwOelbivYygXDamcWCArpSHfBj,'X-WatchaPlay-Client':'WatchaPlay-Android','X-WatchaPlay-Client-Version':UMIKLwOelbivYygXDamcWCArpSHfBs,'X-WatchaPlay-Client-Subclass':'Normal','X-WatchaPlay-Client-Ui-Mode-Name':'television','X-WatchaPlay-Screen':UMIKLwOelbivYygXDamcWCArpSHfBV,'X-WatchaPlay-Network-Status':'wifi','X-WatchaPlay-Appsflyer-Device-ID':UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['flyerId'],'X-FROGRAMS-CLIENT':'Mars-Android-Box','X-FROGRAMS-APP-CODE':'mars','X-FROGRAMS-DEVICE-IDENTIFIER':UMIKLwOelbivYygXDamcWCArpSHfBJ,'X-FROGRAMS-DEVICE-NAME':UMIKLwOelbivYygXDamcWCArpSHfBG,'X-FROGRAMS-AD-ID':UMIKLwOelbivYygXDamcWCArpSHfBj,'X-FROGRAMS-APPSFLYER-DEVICE-ID':UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['flyerId'],'X-FROGRAMS-VERSION':UMIKLwOelbivYygXDamcWCArpSHfBs,'X-FROGRAMS-OS-VERSION':UMIKLwOelbivYygXDamcWCArpSHfBP,'X-FROGRAMS-NETWORK-STATUS':'wifi','X-FROGRAMS-MARS-SCREEN':UMIKLwOelbivYygXDamcWCArpSHfBV,'X-FROGRAMS-MARS-UI-MODE':'television',}
  return UMIKLwOelbivYygXDamcWCArpSHfBE
 def Init_WC_Total(UMIKLwOelbivYygXDamcWCArpSHfBR):
  UMIKLwOelbivYygXDamcWCArpSHfBR.WC={'account':{},'cookies':{'watcha_token':'','watcha_guit':'','watcha_guitv':'','watcha_usercd':'',},}
 def callRequestCookies(UMIKLwOelbivYygXDamcWCArpSHfBR,jobtype,UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfsz,headers=UMIKLwOelbivYygXDamcWCArpSHfsz,cookies=UMIKLwOelbivYygXDamcWCArpSHfsz,redirects=UMIKLwOelbivYygXDamcWCArpSHfsT):
  UMIKLwOelbivYygXDamcWCArpSHfBk=UMIKLwOelbivYygXDamcWCArpSHfBR.DEFAULT_HEADER
  if headers:UMIKLwOelbivYygXDamcWCArpSHfBk.update(headers)
  if jobtype=='Get':
   UMIKLwOelbivYygXDamcWCArpSHfBo=requests.get(UMIKLwOelbivYygXDamcWCArpSHfqh,params=params,headers=UMIKLwOelbivYygXDamcWCArpSHfBk,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   UMIKLwOelbivYygXDamcWCArpSHfBo=requests.put(UMIKLwOelbivYygXDamcWCArpSHfqh,data=payload,params=params,headers=UMIKLwOelbivYygXDamcWCArpSHfBk,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Delete':
   UMIKLwOelbivYygXDamcWCArpSHfBo=requests.delete(UMIKLwOelbivYygXDamcWCArpSHfqh,params=params,headers=UMIKLwOelbivYygXDamcWCArpSHfBk,cookies=cookies,allow_redirects=redirects)
  else:
   UMIKLwOelbivYygXDamcWCArpSHfBo=requests.post(UMIKLwOelbivYygXDamcWCArpSHfqh,data=payload,params=params,headers=UMIKLwOelbivYygXDamcWCArpSHfBk,cookies=cookies,allow_redirects=redirects)
  return UMIKLwOelbivYygXDamcWCArpSHfBo
 def JsonFile_Save(UMIKLwOelbivYygXDamcWCArpSHfBR,filename,UMIKLwOelbivYygXDamcWCArpSHfBF):
  if filename=='':return UMIKLwOelbivYygXDamcWCArpSHfsT
  try:
   fp=UMIKLwOelbivYygXDamcWCArpSHfsQ(filename,'w',-1,'utf-8')
   json.dump(UMIKLwOelbivYygXDamcWCArpSHfBF,fp,indent=4,ensure_ascii=UMIKLwOelbivYygXDamcWCArpSHfsT)
   fp.close()
  except:
   return UMIKLwOelbivYygXDamcWCArpSHfsT
  return UMIKLwOelbivYygXDamcWCArpSHfst
 def JsonFile_Load(UMIKLwOelbivYygXDamcWCArpSHfBR,filename):
  if filename=='':return{}
  try:
   fp=UMIKLwOelbivYygXDamcWCArpSHfsQ(filename,'r',-1,'utf-8')
   UMIKLwOelbivYygXDamcWCArpSHfBd=json.load(fp)
   fp.close()
  except:
   return{}
  return UMIKLwOelbivYygXDamcWCArpSHfBd
 def Save_session_acount(UMIKLwOelbivYygXDamcWCArpSHfBR,UMIKLwOelbivYygXDamcWCArpSHfBu,UMIKLwOelbivYygXDamcWCArpSHfBz,UMIKLwOelbivYygXDamcWCArpSHfBT):
  UMIKLwOelbivYygXDamcWCArpSHfBR.WC['account']['wcid']=base64.standard_b64encode(UMIKLwOelbivYygXDamcWCArpSHfBu.encode()).decode('utf-8')
  UMIKLwOelbivYygXDamcWCArpSHfBR.WC['account']['wcpw']=base64.standard_b64encode(UMIKLwOelbivYygXDamcWCArpSHfBz.encode()).decode('utf-8')
  UMIKLwOelbivYygXDamcWCArpSHfBR.WC['account']['wcpf']=UMIKLwOelbivYygXDamcWCArpSHfBT 
 def Load_session_acount(UMIKLwOelbivYygXDamcWCArpSHfBR):
  try:
   UMIKLwOelbivYygXDamcWCArpSHfBu=base64.standard_b64decode(UMIKLwOelbivYygXDamcWCArpSHfBR.WC['account']['wcid']).decode('utf-8')
   UMIKLwOelbivYygXDamcWCArpSHfBz=base64.standard_b64decode(UMIKLwOelbivYygXDamcWCArpSHfBR.WC['account']['wcpw']).decode('utf-8')
   UMIKLwOelbivYygXDamcWCArpSHfBT=UMIKLwOelbivYygXDamcWCArpSHfBR.WC['account']['wcpf']
  except:
   return '','',0
  return UMIKLwOelbivYygXDamcWCArpSHfBu,UMIKLwOelbivYygXDamcWCArpSHfBz,UMIKLwOelbivYygXDamcWCArpSHfBT
 def Get_DeviceID(UMIKLwOelbivYygXDamcWCArpSHfBR,UMIKLwOelbivYygXDamcWCArpSHfsx,pf):
  import hashlib
  m1=hashlib.md5()
  m2=hashlib.md5()
  UMIKLwOelbivYygXDamcWCArpSHfBQ=UMIKLwOelbivYygXDamcWCArpSHfsx+UMIKLwOelbivYygXDamcWCArpSHfsN(pf)
  UMIKLwOelbivYygXDamcWCArpSHfBt=UMIKLwOelbivYygXDamcWCArpSHfsN(pf)+UMIKLwOelbivYygXDamcWCArpSHfsx
  m1.update(UMIKLwOelbivYygXDamcWCArpSHfBQ.encode('utf-8'))
  m2.update(UMIKLwOelbivYygXDamcWCArpSHfBt.encode('utf-8'))
  UMIKLwOelbivYygXDamcWCArpSHfBx=UMIKLwOelbivYygXDamcWCArpSHfsN(m1.hexdigest())
  UMIKLwOelbivYygXDamcWCArpSHfBN=UMIKLwOelbivYygXDamcWCArpSHfsN(m2.hexdigest())
  UMIKLwOelbivYygXDamcWCArpSHfBn=UMIKLwOelbivYygXDamcWCArpSHfBx[:16]
  UMIKLwOelbivYygXDamcWCArpSHfqB='%s-%s-%s-%s-%s'%(UMIKLwOelbivYygXDamcWCArpSHfBN[:8],UMIKLwOelbivYygXDamcWCArpSHfBN[8:12],UMIKLwOelbivYygXDamcWCArpSHfBN[12:16],UMIKLwOelbivYygXDamcWCArpSHfBN[16:20],UMIKLwOelbivYygXDamcWCArpSHfBN[20:])
  return UMIKLwOelbivYygXDamcWCArpSHfBn,UMIKLwOelbivYygXDamcWCArpSHfqB
 def make_Random_Intstr(UMIKLwOelbivYygXDamcWCArpSHfBR,size):
  UMIKLwOelbivYygXDamcWCArpSHfqR=string.digits 
  UMIKLwOelbivYygXDamcWCArpSHfqE=''
  for i in UMIKLwOelbivYygXDamcWCArpSHfsn(size):
   UMIKLwOelbivYygXDamcWCArpSHfqE+=random.choice(UMIKLwOelbivYygXDamcWCArpSHfqR)
  return UMIKLwOelbivYygXDamcWCArpSHfqE
 def makeDefaultCookies(UMIKLwOelbivYygXDamcWCArpSHfBR):
  UMIKLwOelbivYygXDamcWCArpSHfqs={'_s_guit':UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_guit'],'_guinness-premium_session':UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_token']}
  if UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_guitv']:
   UMIKLwOelbivYygXDamcWCArpSHfqs['_s_guitv']=UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_guitv']
  return UMIKLwOelbivYygXDamcWCArpSHfqs
 def GetCredential(UMIKLwOelbivYygXDamcWCArpSHfBR,user_id,user_pw,user_pf):
  try:
   UMIKLwOelbivYygXDamcWCArpSHfqP=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+'/api/session'
   UMIKLwOelbivYygXDamcWCArpSHfqG={'email':user_id,'password':user_pw}
   UMIKLwOelbivYygXDamcWCArpSHfqJ=UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
   UMIKLwOelbivYygXDamcWCArpSHfqV={'accept':'application/vnd.frograms+json;version=4'}
   UMIKLwOelbivYygXDamcWCArpSHfqJ.update(UMIKLwOelbivYygXDamcWCArpSHfqV)
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Post',UMIKLwOelbivYygXDamcWCArpSHfqP,payload=UMIKLwOelbivYygXDamcWCArpSHfqG,params=UMIKLwOelbivYygXDamcWCArpSHfsz,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfsz)
   for UMIKLwOelbivYygXDamcWCArpSHfqk in UMIKLwOelbivYygXDamcWCArpSHfqj.cookies:
    if UMIKLwOelbivYygXDamcWCArpSHfqk.name=='_ale_session':
     UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_token']=UMIKLwOelbivYygXDamcWCArpSHfqk.value
    elif UMIKLwOelbivYygXDamcWCArpSHfqk.name=='_s_guit':
     UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_guit']=UMIKLwOelbivYygXDamcWCArpSHfqk.value
   if UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_token']=='':
    UMIKLwOelbivYygXDamcWCArpSHfBR.Init_WC_Total()
    return UMIKLwOelbivYygXDamcWCArpSHfsT
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
   UMIKLwOelbivYygXDamcWCArpSHfBR.Init_WC_Total()
   return UMIKLwOelbivYygXDamcWCArpSHfsT
  if UMIKLwOelbivYygXDamcWCArpSHfBR.GetProfilesList(user_pf)==UMIKLwOelbivYygXDamcWCArpSHfsT:
   UMIKLwOelbivYygXDamcWCArpSHfBR.Init_WC_Total()
   return UMIKLwOelbivYygXDamcWCArpSHfsT
  if user_pf!=0:
   if UMIKLwOelbivYygXDamcWCArpSHfBR.GetProfilesConvert()==UMIKLwOelbivYygXDamcWCArpSHfsT:
    UMIKLwOelbivYygXDamcWCArpSHfBR.Init_WC_Total()
    return UMIKLwOelbivYygXDamcWCArpSHfsT
  (UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['deviceId1'],UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['deviceId2'])=UMIKLwOelbivYygXDamcWCArpSHfBR.Get_DeviceID(user_id,user_pf)
  UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['flyerId']=UMIKLwOelbivYygXDamcWCArpSHfsN(UMIKLwOelbivYygXDamcWCArpSHfPR(time.time()*1000))+'-'+UMIKLwOelbivYygXDamcWCArpSHfBR.make_Random_Intstr(19)
  return UMIKLwOelbivYygXDamcWCArpSHfst
 def GetProfilesList(UMIKLwOelbivYygXDamcWCArpSHfBR,user_pf):
  UMIKLwOelbivYygXDamcWCArpSHfqo=[]
  try:
   UMIKLwOelbivYygXDamcWCArpSHfqF ='/api/groups/members'
   UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.MAIN_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
   UMIKLwOelbivYygXDamcWCArpSHfqJ=UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
   UMIKLwOelbivYygXDamcWCArpSHfqk=UMIKLwOelbivYygXDamcWCArpSHfBR.makeDefaultCookies()
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Get',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfsz,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfqk,redirects=UMIKLwOelbivYygXDamcWCArpSHfst)
   UMIKLwOelbivYygXDamcWCArpSHfqd=json.loads(UMIKLwOelbivYygXDamcWCArpSHfqj.text)
   UMIKLwOelbivYygXDamcWCArpSHfqo.append(UMIKLwOelbivYygXDamcWCArpSHfqd['naive_group']['chief_user']['code'])
   for UMIKLwOelbivYygXDamcWCArpSHfqu in UMIKLwOelbivYygXDamcWCArpSHfqd['naive_group']['valid_memberships']:
    UMIKLwOelbivYygXDamcWCArpSHfqo.append(UMIKLwOelbivYygXDamcWCArpSHfqu['user']['code'])
   UMIKLwOelbivYygXDamcWCArpSHfPq(UMIKLwOelbivYygXDamcWCArpSHfqo)
   UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_usercd']=UMIKLwOelbivYygXDamcWCArpSHfqo[user_pf]
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
   UMIKLwOelbivYygXDamcWCArpSHfBR.Init_WC_Total()
   return UMIKLwOelbivYygXDamcWCArpSHfsT
  return UMIKLwOelbivYygXDamcWCArpSHfst
 def GetProfilesConvert(UMIKLwOelbivYygXDamcWCArpSHfBR):
  try:
   UMIKLwOelbivYygXDamcWCArpSHfqF ='/api/users/'+UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_usercd']+'/convert'
   UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
   UMIKLwOelbivYygXDamcWCArpSHfqJ =UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
   UMIKLwOelbivYygXDamcWCArpSHfqk =UMIKLwOelbivYygXDamcWCArpSHfBR.makeDefaultCookies()
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Put',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfsz,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfqk)
   for UMIKLwOelbivYygXDamcWCArpSHfqk in UMIKLwOelbivYygXDamcWCArpSHfqj.cookies:
    if UMIKLwOelbivYygXDamcWCArpSHfqk.name=='_s_guitv':
     UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_guitv']=UMIKLwOelbivYygXDamcWCArpSHfqk.value
    elif UMIKLwOelbivYygXDamcWCArpSHfqk.name=='_guinness-premium_session':
     UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_token']=UMIKLwOelbivYygXDamcWCArpSHfqk.value
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
   UMIKLwOelbivYygXDamcWCArpSHfBR.Init_WC_Total()
   return UMIKLwOelbivYygXDamcWCArpSHfsT
  return UMIKLwOelbivYygXDamcWCArpSHfst
 def GetSubGroupList(UMIKLwOelbivYygXDamcWCArpSHfBR,stype):
  UMIKLwOelbivYygXDamcWCArpSHfqz=[]
  try:
   UMIKLwOelbivYygXDamcWCArpSHfqF ='/api/categories.json'
   UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
   UMIKLwOelbivYygXDamcWCArpSHfqJ =UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
   UMIKLwOelbivYygXDamcWCArpSHfqk =UMIKLwOelbivYygXDamcWCArpSHfBR.makeDefaultCookies()
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Get',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfsz,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfqk)
   UMIKLwOelbivYygXDamcWCArpSHfqT=json.loads(UMIKLwOelbivYygXDamcWCArpSHfqj.text)
   if not('genres' in UMIKLwOelbivYygXDamcWCArpSHfqT):return UMIKLwOelbivYygXDamcWCArpSHfqz
   if stype=='genres':
    UMIKLwOelbivYygXDamcWCArpSHfqQ=UMIKLwOelbivYygXDamcWCArpSHfqT['genres']
   else:
    UMIKLwOelbivYygXDamcWCArpSHfqQ=UMIKLwOelbivYygXDamcWCArpSHfqT['tags']
   for UMIKLwOelbivYygXDamcWCArpSHfqt in UMIKLwOelbivYygXDamcWCArpSHfqQ:
    UMIKLwOelbivYygXDamcWCArpSHfqx=UMIKLwOelbivYygXDamcWCArpSHfqt['name']
    UMIKLwOelbivYygXDamcWCArpSHfqN =UMIKLwOelbivYygXDamcWCArpSHfqt['api_path']
    UMIKLwOelbivYygXDamcWCArpSHfqn =UMIKLwOelbivYygXDamcWCArpSHfqt['entity']['id']
    UMIKLwOelbivYygXDamcWCArpSHfRB={'group_name':UMIKLwOelbivYygXDamcWCArpSHfqx,'api_path':UMIKLwOelbivYygXDamcWCArpSHfqN,'tag_id':UMIKLwOelbivYygXDamcWCArpSHfsN(UMIKLwOelbivYygXDamcWCArpSHfqn)}
    UMIKLwOelbivYygXDamcWCArpSHfqz.append(UMIKLwOelbivYygXDamcWCArpSHfRB)
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
  return UMIKLwOelbivYygXDamcWCArpSHfqz
 def GetCategoryList(UMIKLwOelbivYygXDamcWCArpSHfBR,stype,UMIKLwOelbivYygXDamcWCArpSHfqn,UMIKLwOelbivYygXDamcWCArpSHfqN,page_int):
  UMIKLwOelbivYygXDamcWCArpSHfqz=[]
  UMIKLwOelbivYygXDamcWCArpSHfRq=UMIKLwOelbivYygXDamcWCArpSHfsT
  UMIKLwOelbivYygXDamcWCArpSHfRE={}
  try:
   if 'categories' in UMIKLwOelbivYygXDamcWCArpSHfqN:
    UMIKLwOelbivYygXDamcWCArpSHfqF ='/api/tags'
    UMIKLwOelbivYygXDamcWCArpSHfRE['ids']=UMIKLwOelbivYygXDamcWCArpSHfqn
   else: 
    UMIKLwOelbivYygXDamcWCArpSHfqF ='/api/'+UMIKLwOelbivYygXDamcWCArpSHfqN+'.json'
    if page_int>1:
     UMIKLwOelbivYygXDamcWCArpSHfRE['page']=UMIKLwOelbivYygXDamcWCArpSHfsN(page_int)
   UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
   UMIKLwOelbivYygXDamcWCArpSHfqJ =UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
   UMIKLwOelbivYygXDamcWCArpSHfqk =UMIKLwOelbivYygXDamcWCArpSHfBR.makeDefaultCookies()
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Get',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfRE,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfqk)
   UMIKLwOelbivYygXDamcWCArpSHfqT=json.loads(UMIKLwOelbivYygXDamcWCArpSHfqj.text)
   if not('contents' in UMIKLwOelbivYygXDamcWCArpSHfqT):return UMIKLwOelbivYygXDamcWCArpSHfqz,UMIKLwOelbivYygXDamcWCArpSHfRq
   UMIKLwOelbivYygXDamcWCArpSHfqQ=UMIKLwOelbivYygXDamcWCArpSHfqT['contents']
   UMIKLwOelbivYygXDamcWCArpSHfRq=UMIKLwOelbivYygXDamcWCArpSHfqT['meta']['has_next']
   for UMIKLwOelbivYygXDamcWCArpSHfqt in UMIKLwOelbivYygXDamcWCArpSHfqQ:
    UMIKLwOelbivYygXDamcWCArpSHfRs =UMIKLwOelbivYygXDamcWCArpSHfqt['code']
    UMIKLwOelbivYygXDamcWCArpSHfRP=UMIKLwOelbivYygXDamcWCArpSHfqt['content_type']
    UMIKLwOelbivYygXDamcWCArpSHfRG =UMIKLwOelbivYygXDamcWCArpSHfqt['title']
    UMIKLwOelbivYygXDamcWCArpSHfRJ =UMIKLwOelbivYygXDamcWCArpSHfqt['story']
    UMIKLwOelbivYygXDamcWCArpSHfRV =UMIKLwOelbivYygXDamcWCArpSHfqt['badge_text']
    UMIKLwOelbivYygXDamcWCArpSHfRj=UMIKLwOelbivYygXDamcWCArpSHfsd=UMIKLwOelbivYygXDamcWCArpSHfsh=''
    if UMIKLwOelbivYygXDamcWCArpSHfqt.get('poster') !=UMIKLwOelbivYygXDamcWCArpSHfsz:UMIKLwOelbivYygXDamcWCArpSHfRj=UMIKLwOelbivYygXDamcWCArpSHfqt.get('poster').get('original')
    if UMIKLwOelbivYygXDamcWCArpSHfqt.get('stillcut')!=UMIKLwOelbivYygXDamcWCArpSHfsz:UMIKLwOelbivYygXDamcWCArpSHfsd =UMIKLwOelbivYygXDamcWCArpSHfqt.get('stillcut').get('large')
    if UMIKLwOelbivYygXDamcWCArpSHfqt.get('thumbnail')!=UMIKLwOelbivYygXDamcWCArpSHfsz:UMIKLwOelbivYygXDamcWCArpSHfsh=UMIKLwOelbivYygXDamcWCArpSHfqt.get('thumbnail').get('large')
    if UMIKLwOelbivYygXDamcWCArpSHfsh=='' :UMIKLwOelbivYygXDamcWCArpSHfsh=UMIKLwOelbivYygXDamcWCArpSHfsd
    UMIKLwOelbivYygXDamcWCArpSHfRk={'thumb':UMIKLwOelbivYygXDamcWCArpSHfsd,'poster':UMIKLwOelbivYygXDamcWCArpSHfRj,'fanart':UMIKLwOelbivYygXDamcWCArpSHfsh}
    UMIKLwOelbivYygXDamcWCArpSHfRo =UMIKLwOelbivYygXDamcWCArpSHfqt['year']
    UMIKLwOelbivYygXDamcWCArpSHfRF =UMIKLwOelbivYygXDamcWCArpSHfqt['film_rating_code']
    UMIKLwOelbivYygXDamcWCArpSHfRh=UMIKLwOelbivYygXDamcWCArpSHfqt['film_rating_short']
    UMIKLwOelbivYygXDamcWCArpSHfRd =UMIKLwOelbivYygXDamcWCArpSHfqt['film_rating_long']
    if UMIKLwOelbivYygXDamcWCArpSHfRP=='movies':
     UMIKLwOelbivYygXDamcWCArpSHfRu =UMIKLwOelbivYygXDamcWCArpSHfqt['duration']
    else:
     UMIKLwOelbivYygXDamcWCArpSHfRu ='0'
    UMIKLwOelbivYygXDamcWCArpSHfRB={'code':UMIKLwOelbivYygXDamcWCArpSHfRs,'content_type':UMIKLwOelbivYygXDamcWCArpSHfRP,'title':UMIKLwOelbivYygXDamcWCArpSHfRG,'story':UMIKLwOelbivYygXDamcWCArpSHfRJ,'thumbnail':UMIKLwOelbivYygXDamcWCArpSHfRk,'year':UMIKLwOelbivYygXDamcWCArpSHfRo,'film_rating_code':UMIKLwOelbivYygXDamcWCArpSHfRF,'film_rating_short':UMIKLwOelbivYygXDamcWCArpSHfRh,'film_rating_long':UMIKLwOelbivYygXDamcWCArpSHfRd,'duration':UMIKLwOelbivYygXDamcWCArpSHfRu,'badge':UMIKLwOelbivYygXDamcWCArpSHfRV,}
    UMIKLwOelbivYygXDamcWCArpSHfqz.append(UMIKLwOelbivYygXDamcWCArpSHfRB)
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
  return UMIKLwOelbivYygXDamcWCArpSHfqz,UMIKLwOelbivYygXDamcWCArpSHfRq
 def GetProgramInfo(UMIKLwOelbivYygXDamcWCArpSHfBR,program_code):
  UMIKLwOelbivYygXDamcWCArpSHfRz={}
  try:
   UMIKLwOelbivYygXDamcWCArpSHfqF ='/api/contents/'+program_code
   UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
   UMIKLwOelbivYygXDamcWCArpSHfqJ=UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Get',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfsz,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfsz)
   UMIKLwOelbivYygXDamcWCArpSHfqT=json.loads(UMIKLwOelbivYygXDamcWCArpSHfqj.text)
   UMIKLwOelbivYygXDamcWCArpSHfRT=img_clearlogo=''
   UMIKLwOelbivYygXDamcWCArpSHfRT=UMIKLwOelbivYygXDamcWCArpSHfqT.get('poster').get('original')
   if UMIKLwOelbivYygXDamcWCArpSHfPE(UMIKLwOelbivYygXDamcWCArpSHfqT.get('title_logos'))>0:img_clearlogo=UMIKLwOelbivYygXDamcWCArpSHfqT.get('title_logos')[0].get('src')
   UMIKLwOelbivYygXDamcWCArpSHfRz={'imgPoster':UMIKLwOelbivYygXDamcWCArpSHfRT,'imgClearlogo':img_clearlogo}
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
  return UMIKLwOelbivYygXDamcWCArpSHfRz
 def GetSeasonList(UMIKLwOelbivYygXDamcWCArpSHfBR,program_code):
  UMIKLwOelbivYygXDamcWCArpSHfRQ=[]
  try:
   UMIKLwOelbivYygXDamcWCArpSHfqF ='/api/aio_contents/'+program_code
   UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
   UMIKLwOelbivYygXDamcWCArpSHfqJ =UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Get',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfsz,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfsz)
   UMIKLwOelbivYygXDamcWCArpSHfqT=json.loads(UMIKLwOelbivYygXDamcWCArpSHfqj.text)
   if not('result' in UMIKLwOelbivYygXDamcWCArpSHfqT):return UMIKLwOelbivYygXDamcWCArpSHfRQ
   for UMIKLwOelbivYygXDamcWCArpSHfqt in UMIKLwOelbivYygXDamcWCArpSHfqT.get('result').get('seasons'):
    UMIKLwOelbivYygXDamcWCArpSHfRt =UMIKLwOelbivYygXDamcWCArpSHfqt['id']
    UMIKLwOelbivYygXDamcWCArpSHfRx =UMIKLwOelbivYygXDamcWCArpSHfqt['titles']['short']or UMIKLwOelbivYygXDamcWCArpSHfqt['titles']['original']
    UMIKLwOelbivYygXDamcWCArpSHfRB={'seasonId':UMIKLwOelbivYygXDamcWCArpSHfRt,'seasonNm':UMIKLwOelbivYygXDamcWCArpSHfRx,}
    UMIKLwOelbivYygXDamcWCArpSHfRQ.append(UMIKLwOelbivYygXDamcWCArpSHfRB)
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
  return UMIKLwOelbivYygXDamcWCArpSHfRQ
 def GetEpisodoList(UMIKLwOelbivYygXDamcWCArpSHfBR,program_code,page_int,orderby='asc'):
  UMIKLwOelbivYygXDamcWCArpSHfqz=[]
  UMIKLwOelbivYygXDamcWCArpSHfRq=UMIKLwOelbivYygXDamcWCArpSHfsT
  UMIKLwOelbivYygXDamcWCArpSHfRN=''
  try:
   UMIKLwOelbivYygXDamcWCArpSHfqF ='/api/contents/'+program_code+'/tv_episodes.json'
   UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
   UMIKLwOelbivYygXDamcWCArpSHfRE={'all':'true'}
   UMIKLwOelbivYygXDamcWCArpSHfqJ =UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Get',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfRE,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfsz)
   UMIKLwOelbivYygXDamcWCArpSHfqT=json.loads(UMIKLwOelbivYygXDamcWCArpSHfqj.text)
   if not('tv_episode_codes' in UMIKLwOelbivYygXDamcWCArpSHfqT):return UMIKLwOelbivYygXDamcWCArpSHfqz,UMIKLwOelbivYygXDamcWCArpSHfRq
   UMIKLwOelbivYygXDamcWCArpSHfqQ=UMIKLwOelbivYygXDamcWCArpSHfqT['tv_episode_codes']
   UMIKLwOelbivYygXDamcWCArpSHfRn=UMIKLwOelbivYygXDamcWCArpSHfPE(UMIKLwOelbivYygXDamcWCArpSHfqQ)
   UMIKLwOelbivYygXDamcWCArpSHfEB =UMIKLwOelbivYygXDamcWCArpSHfPR(UMIKLwOelbivYygXDamcWCArpSHfRn//(UMIKLwOelbivYygXDamcWCArpSHfBR.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    UMIKLwOelbivYygXDamcWCArpSHfEq =(UMIKLwOelbivYygXDamcWCArpSHfRn-1)-((page_int-1)*UMIKLwOelbivYygXDamcWCArpSHfBR.EPISODE_LIMIT)
   else:
    UMIKLwOelbivYygXDamcWCArpSHfEq =(page_int-1)*UMIKLwOelbivYygXDamcWCArpSHfBR.EPISODE_LIMIT
   for i in UMIKLwOelbivYygXDamcWCArpSHfsn(UMIKLwOelbivYygXDamcWCArpSHfBR.EPISODE_LIMIT):
    if orderby=='desc':
     UMIKLwOelbivYygXDamcWCArpSHfER=UMIKLwOelbivYygXDamcWCArpSHfEq-i
     if UMIKLwOelbivYygXDamcWCArpSHfER<0:break
    else:
     UMIKLwOelbivYygXDamcWCArpSHfER=UMIKLwOelbivYygXDamcWCArpSHfEq+i
     if UMIKLwOelbivYygXDamcWCArpSHfER>=UMIKLwOelbivYygXDamcWCArpSHfRn:break
    if UMIKLwOelbivYygXDamcWCArpSHfRN!='':UMIKLwOelbivYygXDamcWCArpSHfRN+=','
    UMIKLwOelbivYygXDamcWCArpSHfRN+=UMIKLwOelbivYygXDamcWCArpSHfqQ[UMIKLwOelbivYygXDamcWCArpSHfER]
   if UMIKLwOelbivYygXDamcWCArpSHfEB>page_int:UMIKLwOelbivYygXDamcWCArpSHfRq=UMIKLwOelbivYygXDamcWCArpSHfst
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
  UMIKLwOelbivYygXDamcWCArpSHfEs=UMIKLwOelbivYygXDamcWCArpSHfBR.GetProgramInfo(program_code)
  try:
   UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
   UMIKLwOelbivYygXDamcWCArpSHfRE={'codes':UMIKLwOelbivYygXDamcWCArpSHfRN}
   UMIKLwOelbivYygXDamcWCArpSHfqJ =UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Get',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfRE,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfsz)
   UMIKLwOelbivYygXDamcWCArpSHfqT=json.loads(UMIKLwOelbivYygXDamcWCArpSHfqj.text)
   if not('tv_episodes' in UMIKLwOelbivYygXDamcWCArpSHfqT):return UMIKLwOelbivYygXDamcWCArpSHfqz
   UMIKLwOelbivYygXDamcWCArpSHfqQ=UMIKLwOelbivYygXDamcWCArpSHfqT['tv_episodes']
   for UMIKLwOelbivYygXDamcWCArpSHfqt in UMIKLwOelbivYygXDamcWCArpSHfqQ:
    UMIKLwOelbivYygXDamcWCArpSHfRs =UMIKLwOelbivYygXDamcWCArpSHfqt['code']
    if UMIKLwOelbivYygXDamcWCArpSHfqt['title']:
     UMIKLwOelbivYygXDamcWCArpSHfRG =UMIKLwOelbivYygXDamcWCArpSHfqt['title']
    else:
     UMIKLwOelbivYygXDamcWCArpSHfRG =''
    UMIKLwOelbivYygXDamcWCArpSHfRj=UMIKLwOelbivYygXDamcWCArpSHfsd=UMIKLwOelbivYygXDamcWCArpSHfsh=UMIKLwOelbivYygXDamcWCArpSHfEP=''
    UMIKLwOelbivYygXDamcWCArpSHfRj =UMIKLwOelbivYygXDamcWCArpSHfEs.get('imgPoster')
    UMIKLwOelbivYygXDamcWCArpSHfEP=UMIKLwOelbivYygXDamcWCArpSHfEs.get('imgClearlogo')
    if UMIKLwOelbivYygXDamcWCArpSHfqt.get('stillcut') !=UMIKLwOelbivYygXDamcWCArpSHfsz:UMIKLwOelbivYygXDamcWCArpSHfsd =UMIKLwOelbivYygXDamcWCArpSHfqt.get('stillcut').get('large')
    if UMIKLwOelbivYygXDamcWCArpSHfqt.get('tv_season_stillcut')!=UMIKLwOelbivYygXDamcWCArpSHfsz:UMIKLwOelbivYygXDamcWCArpSHfsh=UMIKLwOelbivYygXDamcWCArpSHfqt.get('tv_season_stillcut').get('large')
    UMIKLwOelbivYygXDamcWCArpSHfRk={'thumb':UMIKLwOelbivYygXDamcWCArpSHfsd,'poster':UMIKLwOelbivYygXDamcWCArpSHfRj,'fanart':UMIKLwOelbivYygXDamcWCArpSHfsh,'clearlogo':UMIKLwOelbivYygXDamcWCArpSHfEP}
    UMIKLwOelbivYygXDamcWCArpSHfEG =UMIKLwOelbivYygXDamcWCArpSHfqt['display_number']
    UMIKLwOelbivYygXDamcWCArpSHfEJ=UMIKLwOelbivYygXDamcWCArpSHfqt['tv_season_title']
    UMIKLwOelbivYygXDamcWCArpSHfRu =UMIKLwOelbivYygXDamcWCArpSHfqt['duration']
    try:
     UMIKLwOelbivYygXDamcWCArpSHfEV=UMIKLwOelbivYygXDamcWCArpSHfqt['episode_number']
    except:
     UMIKLwOelbivYygXDamcWCArpSHfEV='0'
    UMIKLwOelbivYygXDamcWCArpSHfRB={'code':UMIKLwOelbivYygXDamcWCArpSHfRs,'title':UMIKLwOelbivYygXDamcWCArpSHfRG,'thumbnail':UMIKLwOelbivYygXDamcWCArpSHfRk,'display_num':UMIKLwOelbivYygXDamcWCArpSHfEG,'season_title':UMIKLwOelbivYygXDamcWCArpSHfEJ,'duration':UMIKLwOelbivYygXDamcWCArpSHfRu,'episode_number':UMIKLwOelbivYygXDamcWCArpSHfEV}
    UMIKLwOelbivYygXDamcWCArpSHfqz.append(UMIKLwOelbivYygXDamcWCArpSHfRB)
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
  return UMIKLwOelbivYygXDamcWCArpSHfqz,UMIKLwOelbivYygXDamcWCArpSHfRq
 def GetHomeList(UMIKLwOelbivYygXDamcWCArpSHfBR):
  UMIKLwOelbivYygXDamcWCArpSHfEj=[]
  try:
   UMIKLwOelbivYygXDamcWCArpSHfqF ='/api/aio_browses/video/header'
   UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
   UMIKLwOelbivYygXDamcWCArpSHfqJ=UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
   UMIKLwOelbivYygXDamcWCArpSHfqs=UMIKLwOelbivYygXDamcWCArpSHfBR.makeDefaultCookies()
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Get',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfsz,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfqs)
   UMIKLwOelbivYygXDamcWCArpSHfqd=json.loads(UMIKLwOelbivYygXDamcWCArpSHfqj.text)
   if not('result' in UMIKLwOelbivYygXDamcWCArpSHfqd):return UMIKLwOelbivYygXDamcWCArpSHfEj
   UMIKLwOelbivYygXDamcWCArpSHfqQ=UMIKLwOelbivYygXDamcWCArpSHfqd['result'][0]['cells']
   for UMIKLwOelbivYygXDamcWCArpSHfqt in UMIKLwOelbivYygXDamcWCArpSHfqQ:
    UMIKLwOelbivYygXDamcWCArpSHfRP=UMIKLwOelbivYygXDamcWCArpSHfqt['relations'][0]['type']
    UMIKLwOelbivYygXDamcWCArpSHfRG =UMIKLwOelbivYygXDamcWCArpSHfqt['title']
    UMIKLwOelbivYygXDamcWCArpSHfEk =UMIKLwOelbivYygXDamcWCArpSHfqt['badge']
    UMIKLwOelbivYygXDamcWCArpSHfEo =UMIKLwOelbivYygXDamcWCArpSHfqt['media']['fullhd']
    UMIKLwOelbivYygXDamcWCArpSHfRk ={'thumb':UMIKLwOelbivYygXDamcWCArpSHfEo,'fanart':UMIKLwOelbivYygXDamcWCArpSHfEo}
    UMIKLwOelbivYygXDamcWCArpSHfRs =UMIKLwOelbivYygXDamcWCArpSHfqt['relations'][0]['id']
    UMIKLwOelbivYygXDamcWCArpSHfRB={'code':UMIKLwOelbivYygXDamcWCArpSHfRs,'content_type':UMIKLwOelbivYygXDamcWCArpSHfRP,'title':UMIKLwOelbivYygXDamcWCArpSHfRG,'bedge':UMIKLwOelbivYygXDamcWCArpSHfEk,'thumbnail':UMIKLwOelbivYygXDamcWCArpSHfRk}
    UMIKLwOelbivYygXDamcWCArpSHfEj.append(UMIKLwOelbivYygXDamcWCArpSHfRB)
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
  return UMIKLwOelbivYygXDamcWCArpSHfEj
 def GetSearchList(UMIKLwOelbivYygXDamcWCArpSHfBR,search_key,page_int):
  UMIKLwOelbivYygXDamcWCArpSHfEF=[]
  UMIKLwOelbivYygXDamcWCArpSHfRq=UMIKLwOelbivYygXDamcWCArpSHfsT
  try:
   UMIKLwOelbivYygXDamcWCArpSHfqF ='/api/search.json'
   UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
   UMIKLwOelbivYygXDamcWCArpSHfRE={'query':search_key,'page':UMIKLwOelbivYygXDamcWCArpSHfsN(page_int),'per':UMIKLwOelbivYygXDamcWCArpSHfsN(UMIKLwOelbivYygXDamcWCArpSHfBR.SEARCH_LIMIT),'exclude':'limited'}
   UMIKLwOelbivYygXDamcWCArpSHfqJ=UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Get',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfRE,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfsz)
   UMIKLwOelbivYygXDamcWCArpSHfqT=json.loads(UMIKLwOelbivYygXDamcWCArpSHfqj.text)
   if not('results' in UMIKLwOelbivYygXDamcWCArpSHfqT):return UMIKLwOelbivYygXDamcWCArpSHfEF,UMIKLwOelbivYygXDamcWCArpSHfRq
   UMIKLwOelbivYygXDamcWCArpSHfqQ=UMIKLwOelbivYygXDamcWCArpSHfqT['results']
   UMIKLwOelbivYygXDamcWCArpSHfRq=UMIKLwOelbivYygXDamcWCArpSHfqT['meta']['has_next']
   for UMIKLwOelbivYygXDamcWCArpSHfqt in UMIKLwOelbivYygXDamcWCArpSHfqQ:
    UMIKLwOelbivYygXDamcWCArpSHfRs =UMIKLwOelbivYygXDamcWCArpSHfqt['code']
    UMIKLwOelbivYygXDamcWCArpSHfRP=UMIKLwOelbivYygXDamcWCArpSHfqt['content_type']
    UMIKLwOelbivYygXDamcWCArpSHfRG =UMIKLwOelbivYygXDamcWCArpSHfqt['title']
    UMIKLwOelbivYygXDamcWCArpSHfRJ =UMIKLwOelbivYygXDamcWCArpSHfqt['story']
    UMIKLwOelbivYygXDamcWCArpSHfRj=UMIKLwOelbivYygXDamcWCArpSHfsd=UMIKLwOelbivYygXDamcWCArpSHfsh=''
    if UMIKLwOelbivYygXDamcWCArpSHfqt.get('poster') !=UMIKLwOelbivYygXDamcWCArpSHfsz:UMIKLwOelbivYygXDamcWCArpSHfRj=UMIKLwOelbivYygXDamcWCArpSHfqt.get('poster').get('original')
    if UMIKLwOelbivYygXDamcWCArpSHfqt.get('stillcut')!=UMIKLwOelbivYygXDamcWCArpSHfsz:UMIKLwOelbivYygXDamcWCArpSHfsd =UMIKLwOelbivYygXDamcWCArpSHfqt.get('stillcut').get('large')
    if UMIKLwOelbivYygXDamcWCArpSHfqt.get('thumbnail')!=UMIKLwOelbivYygXDamcWCArpSHfsz:UMIKLwOelbivYygXDamcWCArpSHfsh=UMIKLwOelbivYygXDamcWCArpSHfqt.get('thumbnail').get('large')
    if UMIKLwOelbivYygXDamcWCArpSHfsh=='' :UMIKLwOelbivYygXDamcWCArpSHfsh=UMIKLwOelbivYygXDamcWCArpSHfsd
    UMIKLwOelbivYygXDamcWCArpSHfRk={'thumb':UMIKLwOelbivYygXDamcWCArpSHfsd,'poster':UMIKLwOelbivYygXDamcWCArpSHfRj,'fanart':UMIKLwOelbivYygXDamcWCArpSHfsh}
    UMIKLwOelbivYygXDamcWCArpSHfRo =UMIKLwOelbivYygXDamcWCArpSHfqt['year']
    UMIKLwOelbivYygXDamcWCArpSHfRF =UMIKLwOelbivYygXDamcWCArpSHfqt['film_rating_code']
    UMIKLwOelbivYygXDamcWCArpSHfRh=UMIKLwOelbivYygXDamcWCArpSHfqt['film_rating_short']
    UMIKLwOelbivYygXDamcWCArpSHfRd =UMIKLwOelbivYygXDamcWCArpSHfqt['film_rating_long']
    if UMIKLwOelbivYygXDamcWCArpSHfRP=='movies':
     UMIKLwOelbivYygXDamcWCArpSHfRu =UMIKLwOelbivYygXDamcWCArpSHfqt['duration']
    else:
     UMIKLwOelbivYygXDamcWCArpSHfRu ='0'
    UMIKLwOelbivYygXDamcWCArpSHfRB={'code':UMIKLwOelbivYygXDamcWCArpSHfRs,'content_type':UMIKLwOelbivYygXDamcWCArpSHfRP,'title':UMIKLwOelbivYygXDamcWCArpSHfRG,'story':UMIKLwOelbivYygXDamcWCArpSHfRJ,'thumbnail':UMIKLwOelbivYygXDamcWCArpSHfRk,'year':UMIKLwOelbivYygXDamcWCArpSHfRo,'film_rating_code':UMIKLwOelbivYygXDamcWCArpSHfRF,'film_rating_short':UMIKLwOelbivYygXDamcWCArpSHfRh,'film_rating_long':UMIKLwOelbivYygXDamcWCArpSHfRd,'duration':UMIKLwOelbivYygXDamcWCArpSHfRu}
    UMIKLwOelbivYygXDamcWCArpSHfEF.append(UMIKLwOelbivYygXDamcWCArpSHfRB)
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
  return UMIKLwOelbivYygXDamcWCArpSHfEF,UMIKLwOelbivYygXDamcWCArpSHfRq
 def DeleteContinueList(UMIKLwOelbivYygXDamcWCArpSHfBR,codeList):
  try:
   for UMIKLwOelbivYygXDamcWCArpSHfEh in codeList:
    UMIKLwOelbivYygXDamcWCArpSHfqF ='/api/watches/'+UMIKLwOelbivYygXDamcWCArpSHfEh
    UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
    UMIKLwOelbivYygXDamcWCArpSHfqJ =UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
    UMIKLwOelbivYygXDamcWCArpSHfqk =UMIKLwOelbivYygXDamcWCArpSHfBR.makeDefaultCookies()
    UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Delete',UMIKLwOelbivYygXDamcWCArpSHfqh,params=UMIKLwOelbivYygXDamcWCArpSHfsz,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfqk)
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   UMIKLwOelbivYygXDamcWCArpSHfPq(exception)
 def Get_Now_Datetime(UMIKLwOelbivYygXDamcWCArpSHfBR):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(UMIKLwOelbivYygXDamcWCArpSHfBR,movie_code,quality_str,proxyUse=UMIKLwOelbivYygXDamcWCArpSHfsT,inScreen='BASE',inSound='2CH'):
  UMIKLwOelbivYygXDamcWCArpSHfEu={'streamUrl':'','subtitleUrl':'','customdata':'',}
  try:
   if proxyUse:
    UMIKLwOelbivYygXDamcWCArpSHfEz ='0' if inScreen=='BASE' and inSound=='2CH' else '3'
    UMIKLwOelbivYygXDamcWCArpSHfET='4' if inScreen=='VISION' else '1'
    UMIKLwOelbivYygXDamcWCArpSHfEQ ='0' if inSound!='ATMOS' else '1'
    UMIKLwOelbivYygXDamcWCArpSHfPq('hCodec  = '+UMIKLwOelbivYygXDamcWCArpSHfEz)
    UMIKLwOelbivYygXDamcWCArpSHfPq('hScreen = '+UMIKLwOelbivYygXDamcWCArpSHfET)
    UMIKLwOelbivYygXDamcWCArpSHfPq('hSound  = '+UMIKLwOelbivYygXDamcWCArpSHfEQ)
    UMIKLwOelbivYygXDamcWCArpSHfqF='/api/watch/'+movie_code+'.json?localtracks=%5B%5D&player_v2=true'
    UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
    UMIKLwOelbivYygXDamcWCArpSHfqJ=UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers_v2()
    UMIKLwOelbivYygXDamcWCArpSHfqV={'X-FROGRAMS-MARS-CODEC-FLAG':UMIKLwOelbivYygXDamcWCArpSHfEz,'X-WatchaPlay-Client-Codec-Flag':UMIKLwOelbivYygXDamcWCArpSHfEz,'X-FROGRAMS-MARS-HDR-CAPABILITIES':UMIKLwOelbivYygXDamcWCArpSHfET,'X-WatchaPlay-Client-HDR-Capabilities':UMIKLwOelbivYygXDamcWCArpSHfET,'X-FROGRAMS-MARS-AUDIO-CAPABILITIES':UMIKLwOelbivYygXDamcWCArpSHfEQ,'X-WatchaPlay-Client-Audio-Capabilities':UMIKLwOelbivYygXDamcWCArpSHfEQ,}
    UMIKLwOelbivYygXDamcWCArpSHfqJ.update(UMIKLwOelbivYygXDamcWCArpSHfqV)
   else:
    UMIKLwOelbivYygXDamcWCArpSHfqF='/api/watch/'+movie_code+'.json'
    UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+UMIKLwOelbivYygXDamcWCArpSHfqF
    UMIKLwOelbivYygXDamcWCArpSHfqJ=UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
    UMIKLwOelbivYygXDamcWCArpSHfqV={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str,}
    UMIKLwOelbivYygXDamcWCArpSHfqJ.update(UMIKLwOelbivYygXDamcWCArpSHfqV)
   UMIKLwOelbivYygXDamcWCArpSHfqk=UMIKLwOelbivYygXDamcWCArpSHfBR.makeDefaultCookies()
   UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Get',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfsz,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfqk)
   UMIKLwOelbivYygXDamcWCArpSHfqT=json.loads(UMIKLwOelbivYygXDamcWCArpSHfqj.text)
   UMIKLwOelbivYygXDamcWCArpSHfEu['streamUrl']=UMIKLwOelbivYygXDamcWCArpSHfqT['streams'][0]['source']
   if UMIKLwOelbivYygXDamcWCArpSHfEu['streamUrl']==UMIKLwOelbivYygXDamcWCArpSHfsz:return UMIKLwOelbivYygXDamcWCArpSHfEu
   if 'subtitles' in UMIKLwOelbivYygXDamcWCArpSHfqT['streams'][0]:
    for UMIKLwOelbivYygXDamcWCArpSHfEt in UMIKLwOelbivYygXDamcWCArpSHfqT['streams'][0]['subtitles']:
     if UMIKLwOelbivYygXDamcWCArpSHfEt['lang']=='ko':
      UMIKLwOelbivYygXDamcWCArpSHfEu['subtitleUrl']=UMIKLwOelbivYygXDamcWCArpSHfEt['url']
      break
   UMIKLwOelbivYygXDamcWCArpSHfEx =UMIKLwOelbivYygXDamcWCArpSHfqT['ping_payload']
   UMIKLwOelbivYygXDamcWCArpSHfEN =UMIKLwOelbivYygXDamcWCArpSHfBR.WC['cookies']['watcha_usercd']
   UMIKLwOelbivYygXDamcWCArpSHfEn={'merchant':'giitd_frograms','sessionId':UMIKLwOelbivYygXDamcWCArpSHfEx,'userId':UMIKLwOelbivYygXDamcWCArpSHfEN}
   UMIKLwOelbivYygXDamcWCArpSHfsB=json.dumps(UMIKLwOelbivYygXDamcWCArpSHfEn,separators=(",",":")).encode('UTF-8')
   UMIKLwOelbivYygXDamcWCArpSHfEu['customdata']=base64.b64encode(UMIKLwOelbivYygXDamcWCArpSHfsB)
  except UMIKLwOelbivYygXDamcWCArpSHfPB as exception:
   return UMIKLwOelbivYygXDamcWCArpSHfEu
  return UMIKLwOelbivYygXDamcWCArpSHfEu
 def GetBookmarkInfo(UMIKLwOelbivYygXDamcWCArpSHfBR,videoid,vidtype):
  UMIKLwOelbivYygXDamcWCArpSHfsq={'indexinfo':{'ott':'watcha','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  UMIKLwOelbivYygXDamcWCArpSHfqh=UMIKLwOelbivYygXDamcWCArpSHfBR.API_DOMAIN+'/api/contents/'+videoid
  UMIKLwOelbivYygXDamcWCArpSHfqJ=UMIKLwOelbivYygXDamcWCArpSHfBR.Get_Base_Headers()
  UMIKLwOelbivYygXDamcWCArpSHfqj=UMIKLwOelbivYygXDamcWCArpSHfBR.callRequestCookies('Get',UMIKLwOelbivYygXDamcWCArpSHfqh,payload=UMIKLwOelbivYygXDamcWCArpSHfsz,params=UMIKLwOelbivYygXDamcWCArpSHfsz,headers=UMIKLwOelbivYygXDamcWCArpSHfqJ,cookies=UMIKLwOelbivYygXDamcWCArpSHfsz)
  UMIKLwOelbivYygXDamcWCArpSHfqd=json.loads(UMIKLwOelbivYygXDamcWCArpSHfqj.text)
  if not('title' in UMIKLwOelbivYygXDamcWCArpSHfqd):return{}
  UMIKLwOelbivYygXDamcWCArpSHfsR=UMIKLwOelbivYygXDamcWCArpSHfqd
  UMIKLwOelbivYygXDamcWCArpSHfPq(UMIKLwOelbivYygXDamcWCArpSHfsR.get('duration'))
  UMIKLwOelbivYygXDamcWCArpSHfsE=UMIKLwOelbivYygXDamcWCArpSHfsR.get('title')
  UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['infoLabels']['title']=UMIKLwOelbivYygXDamcWCArpSHfsE
  UMIKLwOelbivYygXDamcWCArpSHfsE +=u'  (%s)'%(UMIKLwOelbivYygXDamcWCArpSHfsR.get('year'))
  UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['title'] =UMIKLwOelbivYygXDamcWCArpSHfsE
  UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['infoLabels']['mpaa'] =UMIKLwOelbivYygXDamcWCArpSHfsR.get('film_rating_long')
  UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['infoLabels']['plot'] =UMIKLwOelbivYygXDamcWCArpSHfsR.get('story').replace('<br>','\n')
  UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['infoLabels']['year'] =UMIKLwOelbivYygXDamcWCArpSHfsR.get('year')
  if vidtype=='movie':
   UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['infoLabels']['duration']=UMIKLwOelbivYygXDamcWCArpSHfsR.get('duration')
  UMIKLwOelbivYygXDamcWCArpSHfsP=[]
  for UMIKLwOelbivYygXDamcWCArpSHfsG in UMIKLwOelbivYygXDamcWCArpSHfsR.get('actors'):
   UMIKLwOelbivYygXDamcWCArpSHfsJ =UMIKLwOelbivYygXDamcWCArpSHfsG.get('name')
   UMIKLwOelbivYygXDamcWCArpSHfsV='' if UMIKLwOelbivYygXDamcWCArpSHfsG.get('photo')==UMIKLwOelbivYygXDamcWCArpSHfsz else UMIKLwOelbivYygXDamcWCArpSHfsG.get('photo').get('small')
   UMIKLwOelbivYygXDamcWCArpSHfsP.append({'name':UMIKLwOelbivYygXDamcWCArpSHfsJ,'thumbnail':UMIKLwOelbivYygXDamcWCArpSHfsV})
  if UMIKLwOelbivYygXDamcWCArpSHfPE(UMIKLwOelbivYygXDamcWCArpSHfsP)>0:
   UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['infoLabels']['cast']=UMIKLwOelbivYygXDamcWCArpSHfsP
  UMIKLwOelbivYygXDamcWCArpSHfsj=[]
  for UMIKLwOelbivYygXDamcWCArpSHfsk in UMIKLwOelbivYygXDamcWCArpSHfsR.get('directors'):UMIKLwOelbivYygXDamcWCArpSHfsj.append(UMIKLwOelbivYygXDamcWCArpSHfsk.get('name'))
  if UMIKLwOelbivYygXDamcWCArpSHfPE(UMIKLwOelbivYygXDamcWCArpSHfsj)>0:
   UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['infoLabels']['director']=UMIKLwOelbivYygXDamcWCArpSHfsj
  UMIKLwOelbivYygXDamcWCArpSHfso=[]
  for UMIKLwOelbivYygXDamcWCArpSHfsF in UMIKLwOelbivYygXDamcWCArpSHfsR.get('genres'):UMIKLwOelbivYygXDamcWCArpSHfso.append(UMIKLwOelbivYygXDamcWCArpSHfsF.get('name'))
  if UMIKLwOelbivYygXDamcWCArpSHfPE(UMIKLwOelbivYygXDamcWCArpSHfso)>0:
   UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['infoLabels']['genre']=UMIKLwOelbivYygXDamcWCArpSHfso
  UMIKLwOelbivYygXDamcWCArpSHfRj =''
  UMIKLwOelbivYygXDamcWCArpSHfsh =''
  UMIKLwOelbivYygXDamcWCArpSHfsd =''
  if UMIKLwOelbivYygXDamcWCArpSHfsR.get('poster') !=UMIKLwOelbivYygXDamcWCArpSHfsz:UMIKLwOelbivYygXDamcWCArpSHfRj =UMIKLwOelbivYygXDamcWCArpSHfsR.get('poster').get('original')
  if UMIKLwOelbivYygXDamcWCArpSHfsR.get('thumbnail')!=UMIKLwOelbivYygXDamcWCArpSHfsz:UMIKLwOelbivYygXDamcWCArpSHfsh =UMIKLwOelbivYygXDamcWCArpSHfsR.get('thumbnail').get('large')
  if UMIKLwOelbivYygXDamcWCArpSHfsR.get('stillcut')!=UMIKLwOelbivYygXDamcWCArpSHfsz:UMIKLwOelbivYygXDamcWCArpSHfsd =UMIKLwOelbivYygXDamcWCArpSHfsR.get('stillcut').get('large')
  if UMIKLwOelbivYygXDamcWCArpSHfsh=='':UMIKLwOelbivYygXDamcWCArpSHfsh=UMIKLwOelbivYygXDamcWCArpSHfsd
  UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['thumbnail']['poster']=UMIKLwOelbivYygXDamcWCArpSHfRj
  UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['thumbnail']['fanart']=UMIKLwOelbivYygXDamcWCArpSHfsh
  UMIKLwOelbivYygXDamcWCArpSHfsq['saveinfo']['thumbnail']['thumb']=UMIKLwOelbivYygXDamcWCArpSHfsd
  return UMIKLwOelbivYygXDamcWCArpSHfsq
# Created by pyminifier (https://github.com/liftoff/pyminifier)
