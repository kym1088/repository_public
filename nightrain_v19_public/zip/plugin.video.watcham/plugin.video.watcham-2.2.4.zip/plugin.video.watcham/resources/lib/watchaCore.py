__author__="NightRain"
RPJODXioqCynscaILdwHWEGzmtuFeV=object
RPJODXioqCynscaILdwHWEGzmtuFel=None
RPJODXioqCynscaILdwHWEGzmtuFer=False
RPJODXioqCynscaILdwHWEGzmtuFeQ=open
RPJODXioqCynscaILdwHWEGzmtuFMj=True
RPJODXioqCynscaILdwHWEGzmtuFMS=Exception
RPJODXioqCynscaILdwHWEGzmtuFMT=print
RPJODXioqCynscaILdwHWEGzmtuFMe=range
RPJODXioqCynscaILdwHWEGzmtuFMB=len
RPJODXioqCynscaILdwHWEGzmtuFMK=str
RPJODXioqCynscaILdwHWEGzmtuFMA=int
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
class RPJODXioqCynscaILdwHWEGzmtuFjS(RPJODXioqCynscaILdwHWEGzmtuFeV):
 def __init__(RPJODXioqCynscaILdwHWEGzmtuFjT):
  RPJODXioqCynscaILdwHWEGzmtuFjT.WC ={}
  RPJODXioqCynscaILdwHWEGzmtuFjT.Init_WC_Total()
  RPJODXioqCynscaILdwHWEGzmtuFjT.MAIN_DOMAIN ='https://watcha.com'
  RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN ='https://api-mars.watcha.com'
  RPJODXioqCynscaILdwHWEGzmtuFjT.EPISODE_LIMIT=20
  RPJODXioqCynscaILdwHWEGzmtuFjT.SEARCH_LIMIT =30
  RPJODXioqCynscaILdwHWEGzmtuFjT.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36'
  RPJODXioqCynscaILdwHWEGzmtuFjT.DEFAULT_HEADER={'user-agent':RPJODXioqCynscaILdwHWEGzmtuFjT.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.3',}
 def Init_WC_Total(RPJODXioqCynscaILdwHWEGzmtuFjT):
  RPJODXioqCynscaILdwHWEGzmtuFjT.WC={'account':{},'cookies':{'watcha_token':'','watcha_guit':'','watcha_guitv':'','watcha_usercd':'',},}
 def callRequestCookies(RPJODXioqCynscaILdwHWEGzmtuFjT,jobtype,RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFel,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFel,redirects=RPJODXioqCynscaILdwHWEGzmtuFer):
  RPJODXioqCynscaILdwHWEGzmtuFje=RPJODXioqCynscaILdwHWEGzmtuFjT.DEFAULT_HEADER
  if headers:RPJODXioqCynscaILdwHWEGzmtuFje.update(headers)
  if jobtype=='Get':
   RPJODXioqCynscaILdwHWEGzmtuFjM=requests.get(RPJODXioqCynscaILdwHWEGzmtuFjV,params=params,headers=RPJODXioqCynscaILdwHWEGzmtuFje,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   RPJODXioqCynscaILdwHWEGzmtuFjM=requests.put(RPJODXioqCynscaILdwHWEGzmtuFjV,data=payload,params=params,headers=RPJODXioqCynscaILdwHWEGzmtuFje,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Delete':
   RPJODXioqCynscaILdwHWEGzmtuFjM=requests.delete(RPJODXioqCynscaILdwHWEGzmtuFjV,params=params,headers=RPJODXioqCynscaILdwHWEGzmtuFje,cookies=cookies,allow_redirects=redirects)
  else:
   RPJODXioqCynscaILdwHWEGzmtuFjM=requests.post(RPJODXioqCynscaILdwHWEGzmtuFjV,data=payload,params=params,headers=RPJODXioqCynscaILdwHWEGzmtuFje,cookies=cookies,allow_redirects=redirects)
  return RPJODXioqCynscaILdwHWEGzmtuFjM
 def JsonFile_Save(RPJODXioqCynscaILdwHWEGzmtuFjT,filename,RPJODXioqCynscaILdwHWEGzmtuFjB):
  if filename=='':return RPJODXioqCynscaILdwHWEGzmtuFer
  try:
   fp=RPJODXioqCynscaILdwHWEGzmtuFeQ(filename,'w',-1,'utf-8')
   json.dump(RPJODXioqCynscaILdwHWEGzmtuFjB,fp,indent=4,ensure_ascii=RPJODXioqCynscaILdwHWEGzmtuFer)
   fp.close()
  except:
   return RPJODXioqCynscaILdwHWEGzmtuFer
  return RPJODXioqCynscaILdwHWEGzmtuFMj
 def JsonFile_Load(RPJODXioqCynscaILdwHWEGzmtuFjT,filename):
  if filename=='':return{}
  try:
   fp=RPJODXioqCynscaILdwHWEGzmtuFeQ(filename,'r',-1,'utf-8')
   RPJODXioqCynscaILdwHWEGzmtuFjA=json.load(fp)
   fp.close()
  except:
   return{}
  return RPJODXioqCynscaILdwHWEGzmtuFjA
 def Save_session_acount(RPJODXioqCynscaILdwHWEGzmtuFjT,RPJODXioqCynscaILdwHWEGzmtuFjb,RPJODXioqCynscaILdwHWEGzmtuFjN,RPJODXioqCynscaILdwHWEGzmtuFjk):
  RPJODXioqCynscaILdwHWEGzmtuFjT.WC['account']['wcid']=base64.standard_b64encode(RPJODXioqCynscaILdwHWEGzmtuFjb.encode()).decode('utf-8')
  RPJODXioqCynscaILdwHWEGzmtuFjT.WC['account']['wcpw']=base64.standard_b64encode(RPJODXioqCynscaILdwHWEGzmtuFjN.encode()).decode('utf-8')
  RPJODXioqCynscaILdwHWEGzmtuFjT.WC['account']['wcpf']=RPJODXioqCynscaILdwHWEGzmtuFjk 
 def Load_session_acount(RPJODXioqCynscaILdwHWEGzmtuFjT):
  try:
   RPJODXioqCynscaILdwHWEGzmtuFjb=base64.standard_b64decode(RPJODXioqCynscaILdwHWEGzmtuFjT.WC['account']['wcid']).decode('utf-8')
   RPJODXioqCynscaILdwHWEGzmtuFjN=base64.standard_b64decode(RPJODXioqCynscaILdwHWEGzmtuFjT.WC['account']['wcpw']).decode('utf-8')
   RPJODXioqCynscaILdwHWEGzmtuFjk=RPJODXioqCynscaILdwHWEGzmtuFjT.WC['account']['wcpf']
  except:
   return '','',0
  return RPJODXioqCynscaILdwHWEGzmtuFjb,RPJODXioqCynscaILdwHWEGzmtuFjN,RPJODXioqCynscaILdwHWEGzmtuFjk
 def makeDefaultCookies(RPJODXioqCynscaILdwHWEGzmtuFjT):
  RPJODXioqCynscaILdwHWEGzmtuFjv={'_s_guit':RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_guit'],'_guinness-premium_session':RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_token']}
  if RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_guitv']:
   RPJODXioqCynscaILdwHWEGzmtuFjv['_s_guitv']=RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_guitv']
  return RPJODXioqCynscaILdwHWEGzmtuFjv
 def GetCredential(RPJODXioqCynscaILdwHWEGzmtuFjT,user_id,user_pw,user_pf):
  try:
   RPJODXioqCynscaILdwHWEGzmtuFjh=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+'/api/session'
   RPJODXioqCynscaILdwHWEGzmtuFjU={'email':user_id,'password':user_pw}
   RPJODXioqCynscaILdwHWEGzmtuFjp={'accept':'application/vnd.frograms+json;version=4'}
   RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Post',RPJODXioqCynscaILdwHWEGzmtuFjh,payload=RPJODXioqCynscaILdwHWEGzmtuFjU,params=RPJODXioqCynscaILdwHWEGzmtuFel,headers=RPJODXioqCynscaILdwHWEGzmtuFjp,cookies=RPJODXioqCynscaILdwHWEGzmtuFel)
   for RPJODXioqCynscaILdwHWEGzmtuFjx in RPJODXioqCynscaILdwHWEGzmtuFjY.cookies:
    if RPJODXioqCynscaILdwHWEGzmtuFjx.name=='_guinness-premium_session':
     RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_token']=RPJODXioqCynscaILdwHWEGzmtuFjx.value
    elif RPJODXioqCynscaILdwHWEGzmtuFjx.name=='_s_guit':
     RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_guit']=RPJODXioqCynscaILdwHWEGzmtuFjx.value
   if RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_token']=='':
    RPJODXioqCynscaILdwHWEGzmtuFjT.Init_WC_Total()
    return RPJODXioqCynscaILdwHWEGzmtuFer
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   RPJODXioqCynscaILdwHWEGzmtuFMT(exception)
   RPJODXioqCynscaILdwHWEGzmtuFjT.Init_WC_Total()
   return RPJODXioqCynscaILdwHWEGzmtuFer
  if RPJODXioqCynscaILdwHWEGzmtuFjT.GetProfilesList(user_pf)==RPJODXioqCynscaILdwHWEGzmtuFer:
   RPJODXioqCynscaILdwHWEGzmtuFjT.Init_WC_Total()
   return RPJODXioqCynscaILdwHWEGzmtuFer
  if user_pf!=0:
   if RPJODXioqCynscaILdwHWEGzmtuFjT.GetProfilesConvert()==RPJODXioqCynscaILdwHWEGzmtuFer:
    RPJODXioqCynscaILdwHWEGzmtuFjT.Init_WC_Total()
    return RPJODXioqCynscaILdwHWEGzmtuFer
  return RPJODXioqCynscaILdwHWEGzmtuFMj
 def GetProfilesList(RPJODXioqCynscaILdwHWEGzmtuFjT,user_pf):
  RPJODXioqCynscaILdwHWEGzmtuFjf=[]
  try:
   RPJODXioqCynscaILdwHWEGzmtuFjg ='/manage_profiles'
   RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.MAIN_DOMAIN+RPJODXioqCynscaILdwHWEGzmtuFjg
   RPJODXioqCynscaILdwHWEGzmtuFjx=RPJODXioqCynscaILdwHWEGzmtuFjT.makeDefaultCookies()
   RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Get',RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFel,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFjx,redirects=RPJODXioqCynscaILdwHWEGzmtuFMj)
   RPJODXioqCynscaILdwHWEGzmtuFjl=RPJODXioqCynscaILdwHWEGzmtuFjY.text
   RPJODXioqCynscaILdwHWEGzmtuFjr =re.findall('/api/users/me.{8000}',RPJODXioqCynscaILdwHWEGzmtuFjl)[0]
   RPJODXioqCynscaILdwHWEGzmtuFjr =RPJODXioqCynscaILdwHWEGzmtuFjr.replace('&quot;','')
   RPJODXioqCynscaILdwHWEGzmtuFjf=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',RPJODXioqCynscaILdwHWEGzmtuFjr)
   for i in RPJODXioqCynscaILdwHWEGzmtuFMe(RPJODXioqCynscaILdwHWEGzmtuFMB(RPJODXioqCynscaILdwHWEGzmtuFjf)):
    RPJODXioqCynscaILdwHWEGzmtuFjQ=RPJODXioqCynscaILdwHWEGzmtuFjf[i]
    RPJODXioqCynscaILdwHWEGzmtuFjQ =RPJODXioqCynscaILdwHWEGzmtuFjQ.split(':')[1]
    RPJODXioqCynscaILdwHWEGzmtuFjf[i]=RPJODXioqCynscaILdwHWEGzmtuFjQ.split(',')[0]
   RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_usercd']=RPJODXioqCynscaILdwHWEGzmtuFjf[user_pf]
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   RPJODXioqCynscaILdwHWEGzmtuFMT(exception)
   RPJODXioqCynscaILdwHWEGzmtuFjT.Init_WC_Total()
   return RPJODXioqCynscaILdwHWEGzmtuFer
  return RPJODXioqCynscaILdwHWEGzmtuFMj
 def GetProfilesConvert(RPJODXioqCynscaILdwHWEGzmtuFjT):
  try:
   RPJODXioqCynscaILdwHWEGzmtuFjg ='/api/users/'+RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_usercd']+'/convert'
   RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+RPJODXioqCynscaILdwHWEGzmtuFjg
   RPJODXioqCynscaILdwHWEGzmtuFjx=RPJODXioqCynscaILdwHWEGzmtuFjT.makeDefaultCookies()
   RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Put',RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFel,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFjx)
   for RPJODXioqCynscaILdwHWEGzmtuFjx in RPJODXioqCynscaILdwHWEGzmtuFjY.cookies:
    if RPJODXioqCynscaILdwHWEGzmtuFjx.name=='_s_guitv':
     RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_guitv']=RPJODXioqCynscaILdwHWEGzmtuFjx.value
    elif RPJODXioqCynscaILdwHWEGzmtuFjx.name=='_guinness-premium_session':
     RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_token']=RPJODXioqCynscaILdwHWEGzmtuFjx.value
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   RPJODXioqCynscaILdwHWEGzmtuFMT(exception)
   RPJODXioqCynscaILdwHWEGzmtuFjT.Init_WC_Total()
   return RPJODXioqCynscaILdwHWEGzmtuFer
  return RPJODXioqCynscaILdwHWEGzmtuFMj
 def GetSubGroupList(RPJODXioqCynscaILdwHWEGzmtuFjT,stype):
  RPJODXioqCynscaILdwHWEGzmtuFSj=[]
  try:
   RPJODXioqCynscaILdwHWEGzmtuFjg ='/api/categories.json'
   RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+RPJODXioqCynscaILdwHWEGzmtuFjg
   RPJODXioqCynscaILdwHWEGzmtuFjx=RPJODXioqCynscaILdwHWEGzmtuFjT.makeDefaultCookies()
   RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Get',RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFel,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFjx)
   RPJODXioqCynscaILdwHWEGzmtuFST=json.loads(RPJODXioqCynscaILdwHWEGzmtuFjY.text)
   if not('genres' in RPJODXioqCynscaILdwHWEGzmtuFST):return RPJODXioqCynscaILdwHWEGzmtuFSj
   if stype=='genres':
    RPJODXioqCynscaILdwHWEGzmtuFSe=RPJODXioqCynscaILdwHWEGzmtuFST['genres']
   else:
    RPJODXioqCynscaILdwHWEGzmtuFSe=RPJODXioqCynscaILdwHWEGzmtuFST['tags']
   for RPJODXioqCynscaILdwHWEGzmtuFSM in RPJODXioqCynscaILdwHWEGzmtuFSe:
    RPJODXioqCynscaILdwHWEGzmtuFSB=RPJODXioqCynscaILdwHWEGzmtuFSM['name']
    RPJODXioqCynscaILdwHWEGzmtuFSK =RPJODXioqCynscaILdwHWEGzmtuFSM['api_path']
    RPJODXioqCynscaILdwHWEGzmtuFSA =RPJODXioqCynscaILdwHWEGzmtuFSM['entity']['id']
    RPJODXioqCynscaILdwHWEGzmtuFSb={'group_name':RPJODXioqCynscaILdwHWEGzmtuFSB,'api_path':RPJODXioqCynscaILdwHWEGzmtuFSK,'tag_id':RPJODXioqCynscaILdwHWEGzmtuFMK(RPJODXioqCynscaILdwHWEGzmtuFSA)}
    RPJODXioqCynscaILdwHWEGzmtuFSj.append(RPJODXioqCynscaILdwHWEGzmtuFSb)
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   RPJODXioqCynscaILdwHWEGzmtuFMT(exception)
  return RPJODXioqCynscaILdwHWEGzmtuFSj
 def GetCategoryList(RPJODXioqCynscaILdwHWEGzmtuFjT,stype,RPJODXioqCynscaILdwHWEGzmtuFSA,RPJODXioqCynscaILdwHWEGzmtuFSK,page_int):
  RPJODXioqCynscaILdwHWEGzmtuFSj=[]
  RPJODXioqCynscaILdwHWEGzmtuFSN=RPJODXioqCynscaILdwHWEGzmtuFer
  RPJODXioqCynscaILdwHWEGzmtuFSk={}
  try:
   if 'categories' in RPJODXioqCynscaILdwHWEGzmtuFSK:
    RPJODXioqCynscaILdwHWEGzmtuFjg ='/api/tags'
    RPJODXioqCynscaILdwHWEGzmtuFSk['ids']=RPJODXioqCynscaILdwHWEGzmtuFSA
   else: 
    RPJODXioqCynscaILdwHWEGzmtuFjg ='/api/'+RPJODXioqCynscaILdwHWEGzmtuFSK+'.json'
    if page_int>1:
     RPJODXioqCynscaILdwHWEGzmtuFSk['page']=RPJODXioqCynscaILdwHWEGzmtuFMK(page_int)
   RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+RPJODXioqCynscaILdwHWEGzmtuFjg
   RPJODXioqCynscaILdwHWEGzmtuFjx=RPJODXioqCynscaILdwHWEGzmtuFjT.makeDefaultCookies()
   RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Get',RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFSk,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFjx)
   RPJODXioqCynscaILdwHWEGzmtuFST=json.loads(RPJODXioqCynscaILdwHWEGzmtuFjY.text)
   if not('contents' in RPJODXioqCynscaILdwHWEGzmtuFST):return RPJODXioqCynscaILdwHWEGzmtuFSj,RPJODXioqCynscaILdwHWEGzmtuFSN
   RPJODXioqCynscaILdwHWEGzmtuFSe=RPJODXioqCynscaILdwHWEGzmtuFST['contents']
   RPJODXioqCynscaILdwHWEGzmtuFSN=RPJODXioqCynscaILdwHWEGzmtuFST['meta']['has_next']
   for RPJODXioqCynscaILdwHWEGzmtuFSM in RPJODXioqCynscaILdwHWEGzmtuFSe:
    RPJODXioqCynscaILdwHWEGzmtuFSv =RPJODXioqCynscaILdwHWEGzmtuFSM['code']
    RPJODXioqCynscaILdwHWEGzmtuFSh=RPJODXioqCynscaILdwHWEGzmtuFSM['content_type']
    RPJODXioqCynscaILdwHWEGzmtuFSU =RPJODXioqCynscaILdwHWEGzmtuFSM['title']
    RPJODXioqCynscaILdwHWEGzmtuFSp =RPJODXioqCynscaILdwHWEGzmtuFSM['story']
    RPJODXioqCynscaILdwHWEGzmtuFSY =RPJODXioqCynscaILdwHWEGzmtuFSM['badge_text']
    RPJODXioqCynscaILdwHWEGzmtuFSx=RPJODXioqCynscaILdwHWEGzmtuFeg=RPJODXioqCynscaILdwHWEGzmtuFef=''
    if RPJODXioqCynscaILdwHWEGzmtuFSM.get('poster') !=RPJODXioqCynscaILdwHWEGzmtuFel:RPJODXioqCynscaILdwHWEGzmtuFSx=RPJODXioqCynscaILdwHWEGzmtuFSM.get('poster').get('original')
    if RPJODXioqCynscaILdwHWEGzmtuFSM.get('stillcut')!=RPJODXioqCynscaILdwHWEGzmtuFel:RPJODXioqCynscaILdwHWEGzmtuFeg =RPJODXioqCynscaILdwHWEGzmtuFSM.get('stillcut').get('large')
    if RPJODXioqCynscaILdwHWEGzmtuFSM.get('thumbnail')!=RPJODXioqCynscaILdwHWEGzmtuFel:RPJODXioqCynscaILdwHWEGzmtuFef=RPJODXioqCynscaILdwHWEGzmtuFSM.get('thumbnail').get('large')
    if RPJODXioqCynscaILdwHWEGzmtuFef=='' :RPJODXioqCynscaILdwHWEGzmtuFef=RPJODXioqCynscaILdwHWEGzmtuFeg
    RPJODXioqCynscaILdwHWEGzmtuFSf={'thumb':RPJODXioqCynscaILdwHWEGzmtuFeg,'poster':RPJODXioqCynscaILdwHWEGzmtuFSx,'fanart':RPJODXioqCynscaILdwHWEGzmtuFef}
    RPJODXioqCynscaILdwHWEGzmtuFSg =RPJODXioqCynscaILdwHWEGzmtuFSM['year']
    RPJODXioqCynscaILdwHWEGzmtuFSV =RPJODXioqCynscaILdwHWEGzmtuFSM['film_rating_code']
    RPJODXioqCynscaILdwHWEGzmtuFSl=RPJODXioqCynscaILdwHWEGzmtuFSM['film_rating_short']
    RPJODXioqCynscaILdwHWEGzmtuFSr =RPJODXioqCynscaILdwHWEGzmtuFSM['film_rating_long']
    if RPJODXioqCynscaILdwHWEGzmtuFSh=='movies':
     RPJODXioqCynscaILdwHWEGzmtuFSQ =RPJODXioqCynscaILdwHWEGzmtuFSM['duration']
    else:
     RPJODXioqCynscaILdwHWEGzmtuFSQ ='0'
    RPJODXioqCynscaILdwHWEGzmtuFSb={'code':RPJODXioqCynscaILdwHWEGzmtuFSv,'content_type':RPJODXioqCynscaILdwHWEGzmtuFSh,'title':RPJODXioqCynscaILdwHWEGzmtuFSU,'story':RPJODXioqCynscaILdwHWEGzmtuFSp,'thumbnail':RPJODXioqCynscaILdwHWEGzmtuFSf,'year':RPJODXioqCynscaILdwHWEGzmtuFSg,'film_rating_code':RPJODXioqCynscaILdwHWEGzmtuFSV,'film_rating_short':RPJODXioqCynscaILdwHWEGzmtuFSl,'film_rating_long':RPJODXioqCynscaILdwHWEGzmtuFSr,'duration':RPJODXioqCynscaILdwHWEGzmtuFSQ,'badge':RPJODXioqCynscaILdwHWEGzmtuFSY,}
    RPJODXioqCynscaILdwHWEGzmtuFSj.append(RPJODXioqCynscaILdwHWEGzmtuFSb)
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   RPJODXioqCynscaILdwHWEGzmtuFMT(exception)
  return RPJODXioqCynscaILdwHWEGzmtuFSj,RPJODXioqCynscaILdwHWEGzmtuFSN
 def GetProgramInfo(RPJODXioqCynscaILdwHWEGzmtuFjT,program_code):
  RPJODXioqCynscaILdwHWEGzmtuFTj={}
  try:
   RPJODXioqCynscaILdwHWEGzmtuFjg ='/api/contents/'+program_code
   RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+RPJODXioqCynscaILdwHWEGzmtuFjg
   RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Get',RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFel,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFel)
   RPJODXioqCynscaILdwHWEGzmtuFST=json.loads(RPJODXioqCynscaILdwHWEGzmtuFjY.text)
   RPJODXioqCynscaILdwHWEGzmtuFTS=img_clearlogo=''
   RPJODXioqCynscaILdwHWEGzmtuFTS=RPJODXioqCynscaILdwHWEGzmtuFST.get('poster').get('original')
   if RPJODXioqCynscaILdwHWEGzmtuFMB(RPJODXioqCynscaILdwHWEGzmtuFST.get('title_logos'))>0:img_clearlogo=RPJODXioqCynscaILdwHWEGzmtuFST.get('title_logos')[0].get('src')
   RPJODXioqCynscaILdwHWEGzmtuFTj={'imgPoster':RPJODXioqCynscaILdwHWEGzmtuFTS,'imgClearlogo':img_clearlogo}
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   RPJODXioqCynscaILdwHWEGzmtuFMT(exception)
  return RPJODXioqCynscaILdwHWEGzmtuFTj
 def GetEpisodoList(RPJODXioqCynscaILdwHWEGzmtuFjT,program_code,page_int,orderby='asc'):
  RPJODXioqCynscaILdwHWEGzmtuFSj=[]
  RPJODXioqCynscaILdwHWEGzmtuFSN=RPJODXioqCynscaILdwHWEGzmtuFer
  RPJODXioqCynscaILdwHWEGzmtuFTe=''
  try:
   RPJODXioqCynscaILdwHWEGzmtuFjg ='/api/contents/'+program_code+'/tv_episodes.json'
   RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+RPJODXioqCynscaILdwHWEGzmtuFjg
   RPJODXioqCynscaILdwHWEGzmtuFSk={'all':'true'}
   RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Get',RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFSk,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFel)
   RPJODXioqCynscaILdwHWEGzmtuFST=json.loads(RPJODXioqCynscaILdwHWEGzmtuFjY.text)
   if not('tv_episode_codes' in RPJODXioqCynscaILdwHWEGzmtuFST):return RPJODXioqCynscaILdwHWEGzmtuFSj,RPJODXioqCynscaILdwHWEGzmtuFSN
   RPJODXioqCynscaILdwHWEGzmtuFSe=RPJODXioqCynscaILdwHWEGzmtuFST['tv_episode_codes']
   RPJODXioqCynscaILdwHWEGzmtuFTM=RPJODXioqCynscaILdwHWEGzmtuFMB(RPJODXioqCynscaILdwHWEGzmtuFSe)
   RPJODXioqCynscaILdwHWEGzmtuFTB =RPJODXioqCynscaILdwHWEGzmtuFMA(RPJODXioqCynscaILdwHWEGzmtuFTM//(RPJODXioqCynscaILdwHWEGzmtuFjT.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    RPJODXioqCynscaILdwHWEGzmtuFTK =(RPJODXioqCynscaILdwHWEGzmtuFTM-1)-((page_int-1)*RPJODXioqCynscaILdwHWEGzmtuFjT.EPISODE_LIMIT)
   else:
    RPJODXioqCynscaILdwHWEGzmtuFTK =(page_int-1)*RPJODXioqCynscaILdwHWEGzmtuFjT.EPISODE_LIMIT
   for i in RPJODXioqCynscaILdwHWEGzmtuFMe(RPJODXioqCynscaILdwHWEGzmtuFjT.EPISODE_LIMIT):
    if orderby=='desc':
     RPJODXioqCynscaILdwHWEGzmtuFTA=RPJODXioqCynscaILdwHWEGzmtuFTK-i
     if RPJODXioqCynscaILdwHWEGzmtuFTA<0:break
    else:
     RPJODXioqCynscaILdwHWEGzmtuFTA=RPJODXioqCynscaILdwHWEGzmtuFTK+i
     if RPJODXioqCynscaILdwHWEGzmtuFTA>=RPJODXioqCynscaILdwHWEGzmtuFTM:break
    if RPJODXioqCynscaILdwHWEGzmtuFTe!='':RPJODXioqCynscaILdwHWEGzmtuFTe+=','
    RPJODXioqCynscaILdwHWEGzmtuFTe+=RPJODXioqCynscaILdwHWEGzmtuFSe[RPJODXioqCynscaILdwHWEGzmtuFTA]
   if RPJODXioqCynscaILdwHWEGzmtuFTB>page_int:RPJODXioqCynscaILdwHWEGzmtuFSN=RPJODXioqCynscaILdwHWEGzmtuFMj
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   RPJODXioqCynscaILdwHWEGzmtuFMT(exception)
  RPJODXioqCynscaILdwHWEGzmtuFTb=RPJODXioqCynscaILdwHWEGzmtuFjT.GetProgramInfo(program_code)
  try:
   RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+RPJODXioqCynscaILdwHWEGzmtuFjg
   RPJODXioqCynscaILdwHWEGzmtuFSk={'codes':RPJODXioqCynscaILdwHWEGzmtuFTe}
   RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Get',RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFSk,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFel)
   RPJODXioqCynscaILdwHWEGzmtuFST=json.loads(RPJODXioqCynscaILdwHWEGzmtuFjY.text)
   if not('tv_episodes' in RPJODXioqCynscaILdwHWEGzmtuFST):return RPJODXioqCynscaILdwHWEGzmtuFSj
   RPJODXioqCynscaILdwHWEGzmtuFSe=RPJODXioqCynscaILdwHWEGzmtuFST['tv_episodes']
   for RPJODXioqCynscaILdwHWEGzmtuFSM in RPJODXioqCynscaILdwHWEGzmtuFSe:
    RPJODXioqCynscaILdwHWEGzmtuFSv =RPJODXioqCynscaILdwHWEGzmtuFSM['code']
    if RPJODXioqCynscaILdwHWEGzmtuFSM['title']:
     RPJODXioqCynscaILdwHWEGzmtuFSU =RPJODXioqCynscaILdwHWEGzmtuFSM['title']
    else:
     RPJODXioqCynscaILdwHWEGzmtuFSU =''
    RPJODXioqCynscaILdwHWEGzmtuFSx=RPJODXioqCynscaILdwHWEGzmtuFeg=RPJODXioqCynscaILdwHWEGzmtuFef=RPJODXioqCynscaILdwHWEGzmtuFTN=''
    RPJODXioqCynscaILdwHWEGzmtuFSx =RPJODXioqCynscaILdwHWEGzmtuFTb.get('imgPoster')
    RPJODXioqCynscaILdwHWEGzmtuFTN=RPJODXioqCynscaILdwHWEGzmtuFTb.get('imgClearlogo')
    if RPJODXioqCynscaILdwHWEGzmtuFSM.get('stillcut') !=RPJODXioqCynscaILdwHWEGzmtuFel:RPJODXioqCynscaILdwHWEGzmtuFeg =RPJODXioqCynscaILdwHWEGzmtuFSM.get('stillcut').get('large')
    if RPJODXioqCynscaILdwHWEGzmtuFSM.get('tv_season_stillcut')!=RPJODXioqCynscaILdwHWEGzmtuFel:RPJODXioqCynscaILdwHWEGzmtuFef=RPJODXioqCynscaILdwHWEGzmtuFSM.get('tv_season_stillcut').get('large')
    RPJODXioqCynscaILdwHWEGzmtuFSf={'thumb':RPJODXioqCynscaILdwHWEGzmtuFeg,'poster':RPJODXioqCynscaILdwHWEGzmtuFSx,'fanart':RPJODXioqCynscaILdwHWEGzmtuFef,'clearlogo':RPJODXioqCynscaILdwHWEGzmtuFTN}
    RPJODXioqCynscaILdwHWEGzmtuFTk =RPJODXioqCynscaILdwHWEGzmtuFSM['display_number']
    RPJODXioqCynscaILdwHWEGzmtuFTv=RPJODXioqCynscaILdwHWEGzmtuFSM['tv_season_title']
    RPJODXioqCynscaILdwHWEGzmtuFSQ =RPJODXioqCynscaILdwHWEGzmtuFSM['duration']
    try:
     RPJODXioqCynscaILdwHWEGzmtuFTh=RPJODXioqCynscaILdwHWEGzmtuFSM['episode_number']
    except:
     RPJODXioqCynscaILdwHWEGzmtuFTh='0'
    RPJODXioqCynscaILdwHWEGzmtuFSb={'code':RPJODXioqCynscaILdwHWEGzmtuFSv,'title':RPJODXioqCynscaILdwHWEGzmtuFSU,'thumbnail':RPJODXioqCynscaILdwHWEGzmtuFSf,'display_num':RPJODXioqCynscaILdwHWEGzmtuFTk,'season_title':RPJODXioqCynscaILdwHWEGzmtuFTv,'duration':RPJODXioqCynscaILdwHWEGzmtuFSQ,'episode_number':RPJODXioqCynscaILdwHWEGzmtuFTh}
    RPJODXioqCynscaILdwHWEGzmtuFSj.append(RPJODXioqCynscaILdwHWEGzmtuFSb)
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   RPJODXioqCynscaILdwHWEGzmtuFMT(exception)
  return RPJODXioqCynscaILdwHWEGzmtuFSj,RPJODXioqCynscaILdwHWEGzmtuFSN
 def GetHomeList(RPJODXioqCynscaILdwHWEGzmtuFjT):
  RPJODXioqCynscaILdwHWEGzmtuFTU=[]
  try:
   RPJODXioqCynscaILdwHWEGzmtuFjg ='/api/aio_browses/video/header'
   RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+RPJODXioqCynscaILdwHWEGzmtuFjg
   RPJODXioqCynscaILdwHWEGzmtuFjv=RPJODXioqCynscaILdwHWEGzmtuFjT.makeDefaultCookies()
   RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Get',RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFel,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFjv)
   RPJODXioqCynscaILdwHWEGzmtuFTp=json.loads(RPJODXioqCynscaILdwHWEGzmtuFjY.text)
   if not('result' in RPJODXioqCynscaILdwHWEGzmtuFTp):return RPJODXioqCynscaILdwHWEGzmtuFTU
   RPJODXioqCynscaILdwHWEGzmtuFSe=RPJODXioqCynscaILdwHWEGzmtuFTp['result'][0]['cells']
   for RPJODXioqCynscaILdwHWEGzmtuFSM in RPJODXioqCynscaILdwHWEGzmtuFSe:
    RPJODXioqCynscaILdwHWEGzmtuFSh=RPJODXioqCynscaILdwHWEGzmtuFSM['relations'][0]['type']
    RPJODXioqCynscaILdwHWEGzmtuFSU =RPJODXioqCynscaILdwHWEGzmtuFSM['title']
    RPJODXioqCynscaILdwHWEGzmtuFTY =RPJODXioqCynscaILdwHWEGzmtuFSM['badge']
    RPJODXioqCynscaILdwHWEGzmtuFTx =RPJODXioqCynscaILdwHWEGzmtuFSM['media']['fullhd']
    RPJODXioqCynscaILdwHWEGzmtuFSf ={'thumb':RPJODXioqCynscaILdwHWEGzmtuFTx,'fanart':RPJODXioqCynscaILdwHWEGzmtuFTx}
    RPJODXioqCynscaILdwHWEGzmtuFSv =RPJODXioqCynscaILdwHWEGzmtuFSM['relations'][0]['id']
    RPJODXioqCynscaILdwHWEGzmtuFSb={'code':RPJODXioqCynscaILdwHWEGzmtuFSv,'content_type':RPJODXioqCynscaILdwHWEGzmtuFSh,'title':RPJODXioqCynscaILdwHWEGzmtuFSU,'bedge':RPJODXioqCynscaILdwHWEGzmtuFTY,'thumbnail':RPJODXioqCynscaILdwHWEGzmtuFSf}
    RPJODXioqCynscaILdwHWEGzmtuFTU.append(RPJODXioqCynscaILdwHWEGzmtuFSb)
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   RPJODXioqCynscaILdwHWEGzmtuFMT(exception)
  return RPJODXioqCynscaILdwHWEGzmtuFTU
 def GetSearchList(RPJODXioqCynscaILdwHWEGzmtuFjT,search_key,page_int):
  RPJODXioqCynscaILdwHWEGzmtuFTf=[]
  RPJODXioqCynscaILdwHWEGzmtuFSN=RPJODXioqCynscaILdwHWEGzmtuFer
  try:
   RPJODXioqCynscaILdwHWEGzmtuFjg ='/api/search.json'
   RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+RPJODXioqCynscaILdwHWEGzmtuFjg
   RPJODXioqCynscaILdwHWEGzmtuFSk={'query':search_key,'page':RPJODXioqCynscaILdwHWEGzmtuFMK(page_int),'per':RPJODXioqCynscaILdwHWEGzmtuFMK(RPJODXioqCynscaILdwHWEGzmtuFjT.SEARCH_LIMIT),'exclude':'limited'}
   RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Get',RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFSk,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFel)
   RPJODXioqCynscaILdwHWEGzmtuFST=json.loads(RPJODXioqCynscaILdwHWEGzmtuFjY.text)
   if not('results' in RPJODXioqCynscaILdwHWEGzmtuFST):return RPJODXioqCynscaILdwHWEGzmtuFTf,RPJODXioqCynscaILdwHWEGzmtuFSN
   RPJODXioqCynscaILdwHWEGzmtuFSe=RPJODXioqCynscaILdwHWEGzmtuFST['results']
   RPJODXioqCynscaILdwHWEGzmtuFSN=RPJODXioqCynscaILdwHWEGzmtuFST['meta']['has_next']
   for RPJODXioqCynscaILdwHWEGzmtuFSM in RPJODXioqCynscaILdwHWEGzmtuFSe:
    RPJODXioqCynscaILdwHWEGzmtuFSv =RPJODXioqCynscaILdwHWEGzmtuFSM['code']
    RPJODXioqCynscaILdwHWEGzmtuFSh=RPJODXioqCynscaILdwHWEGzmtuFSM['content_type']
    RPJODXioqCynscaILdwHWEGzmtuFSU =RPJODXioqCynscaILdwHWEGzmtuFSM['title']
    RPJODXioqCynscaILdwHWEGzmtuFSp =RPJODXioqCynscaILdwHWEGzmtuFSM['story']
    RPJODXioqCynscaILdwHWEGzmtuFSx=RPJODXioqCynscaILdwHWEGzmtuFeg=RPJODXioqCynscaILdwHWEGzmtuFef=''
    if RPJODXioqCynscaILdwHWEGzmtuFSM.get('poster') !=RPJODXioqCynscaILdwHWEGzmtuFel:RPJODXioqCynscaILdwHWEGzmtuFSx=RPJODXioqCynscaILdwHWEGzmtuFSM.get('poster').get('original')
    if RPJODXioqCynscaILdwHWEGzmtuFSM.get('stillcut')!=RPJODXioqCynscaILdwHWEGzmtuFel:RPJODXioqCynscaILdwHWEGzmtuFeg =RPJODXioqCynscaILdwHWEGzmtuFSM.get('stillcut').get('large')
    if RPJODXioqCynscaILdwHWEGzmtuFSM.get('thumbnail')!=RPJODXioqCynscaILdwHWEGzmtuFel:RPJODXioqCynscaILdwHWEGzmtuFef=RPJODXioqCynscaILdwHWEGzmtuFSM.get('thumbnail').get('large')
    if RPJODXioqCynscaILdwHWEGzmtuFef=='' :RPJODXioqCynscaILdwHWEGzmtuFef=RPJODXioqCynscaILdwHWEGzmtuFeg
    RPJODXioqCynscaILdwHWEGzmtuFSf={'thumb':RPJODXioqCynscaILdwHWEGzmtuFeg,'poster':RPJODXioqCynscaILdwHWEGzmtuFSx,'fanart':RPJODXioqCynscaILdwHWEGzmtuFef}
    RPJODXioqCynscaILdwHWEGzmtuFSg =RPJODXioqCynscaILdwHWEGzmtuFSM['year']
    RPJODXioqCynscaILdwHWEGzmtuFSV =RPJODXioqCynscaILdwHWEGzmtuFSM['film_rating_code']
    RPJODXioqCynscaILdwHWEGzmtuFSl=RPJODXioqCynscaILdwHWEGzmtuFSM['film_rating_short']
    RPJODXioqCynscaILdwHWEGzmtuFSr =RPJODXioqCynscaILdwHWEGzmtuFSM['film_rating_long']
    if RPJODXioqCynscaILdwHWEGzmtuFSh=='movies':
     RPJODXioqCynscaILdwHWEGzmtuFSQ =RPJODXioqCynscaILdwHWEGzmtuFSM['duration']
    else:
     RPJODXioqCynscaILdwHWEGzmtuFSQ ='0'
    RPJODXioqCynscaILdwHWEGzmtuFSb={'code':RPJODXioqCynscaILdwHWEGzmtuFSv,'content_type':RPJODXioqCynscaILdwHWEGzmtuFSh,'title':RPJODXioqCynscaILdwHWEGzmtuFSU,'story':RPJODXioqCynscaILdwHWEGzmtuFSp,'thumbnail':RPJODXioqCynscaILdwHWEGzmtuFSf,'year':RPJODXioqCynscaILdwHWEGzmtuFSg,'film_rating_code':RPJODXioqCynscaILdwHWEGzmtuFSV,'film_rating_short':RPJODXioqCynscaILdwHWEGzmtuFSl,'film_rating_long':RPJODXioqCynscaILdwHWEGzmtuFSr,'duration':RPJODXioqCynscaILdwHWEGzmtuFSQ}
    RPJODXioqCynscaILdwHWEGzmtuFTf.append(RPJODXioqCynscaILdwHWEGzmtuFSb)
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   RPJODXioqCynscaILdwHWEGzmtuFMT(exception)
  return RPJODXioqCynscaILdwHWEGzmtuFTf,RPJODXioqCynscaILdwHWEGzmtuFSN
 def DeleteContinueList(RPJODXioqCynscaILdwHWEGzmtuFjT,codeList):
  try:
   for RPJODXioqCynscaILdwHWEGzmtuFTg in codeList:
    RPJODXioqCynscaILdwHWEGzmtuFjg ='/api/watches/'+RPJODXioqCynscaILdwHWEGzmtuFTg
    RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+RPJODXioqCynscaILdwHWEGzmtuFjg
    RPJODXioqCynscaILdwHWEGzmtuFjx=RPJODXioqCynscaILdwHWEGzmtuFjT.makeDefaultCookies()
    RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Delete',RPJODXioqCynscaILdwHWEGzmtuFjV,params=RPJODXioqCynscaILdwHWEGzmtuFel,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFjx)
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   RPJODXioqCynscaILdwHWEGzmtuFMT(exception)
 def Get_Now_Datetime(RPJODXioqCynscaILdwHWEGzmtuFjT):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(RPJODXioqCynscaILdwHWEGzmtuFjT,movie_code,quality_str):
  RPJODXioqCynscaILdwHWEGzmtuFTl=RPJODXioqCynscaILdwHWEGzmtuFTQ=RPJODXioqCynscaILdwHWEGzmtuFeB=''
  try:
   RPJODXioqCynscaILdwHWEGzmtuFjg='/api/watch/'+movie_code+'.json'
   RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+RPJODXioqCynscaILdwHWEGzmtuFjg
   RPJODXioqCynscaILdwHWEGzmtuFjp={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   RPJODXioqCynscaILdwHWEGzmtuFjx=RPJODXioqCynscaILdwHWEGzmtuFjT.makeDefaultCookies()
   RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Get',RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFel,headers=RPJODXioqCynscaILdwHWEGzmtuFjp,cookies=RPJODXioqCynscaILdwHWEGzmtuFjx)
   RPJODXioqCynscaILdwHWEGzmtuFST=json.loads(RPJODXioqCynscaILdwHWEGzmtuFjY.text)
   RPJODXioqCynscaILdwHWEGzmtuFTl=RPJODXioqCynscaILdwHWEGzmtuFST['streams'][0]['source']
   if RPJODXioqCynscaILdwHWEGzmtuFTl==RPJODXioqCynscaILdwHWEGzmtuFel:return(RPJODXioqCynscaILdwHWEGzmtuFTl,RPJODXioqCynscaILdwHWEGzmtuFTQ,RPJODXioqCynscaILdwHWEGzmtuFeB)
   if 'subtitles' in RPJODXioqCynscaILdwHWEGzmtuFST['streams'][0]:
    for RPJODXioqCynscaILdwHWEGzmtuFTr in RPJODXioqCynscaILdwHWEGzmtuFST['streams'][0]['subtitles']:
     if RPJODXioqCynscaILdwHWEGzmtuFTr['lang']=='ko':
      RPJODXioqCynscaILdwHWEGzmtuFTQ=RPJODXioqCynscaILdwHWEGzmtuFTr['url']
      break
   RPJODXioqCynscaILdwHWEGzmtuFej =RPJODXioqCynscaILdwHWEGzmtuFST['ping_payload']
   RPJODXioqCynscaILdwHWEGzmtuFeS =RPJODXioqCynscaILdwHWEGzmtuFjT.WC['cookies']['watcha_usercd']
   RPJODXioqCynscaILdwHWEGzmtuFeT={'merchant':'giitd_frograms','sessionId':RPJODXioqCynscaILdwHWEGzmtuFej,'userId':RPJODXioqCynscaILdwHWEGzmtuFeS}
   RPJODXioqCynscaILdwHWEGzmtuFeM=json.dumps(RPJODXioqCynscaILdwHWEGzmtuFeT,separators=(",",":")).encode('UTF-8')
   RPJODXioqCynscaILdwHWEGzmtuFeB=base64.b64encode(RPJODXioqCynscaILdwHWEGzmtuFeM)
  except RPJODXioqCynscaILdwHWEGzmtuFMS as exception:
   return(RPJODXioqCynscaILdwHWEGzmtuFTl,RPJODXioqCynscaILdwHWEGzmtuFTQ,RPJODXioqCynscaILdwHWEGzmtuFeB)
  return(RPJODXioqCynscaILdwHWEGzmtuFTl,RPJODXioqCynscaILdwHWEGzmtuFTQ,RPJODXioqCynscaILdwHWEGzmtuFeB) 
 def GetBookmarkInfo(RPJODXioqCynscaILdwHWEGzmtuFjT,videoid,vidtype):
  RPJODXioqCynscaILdwHWEGzmtuFeK={'indexinfo':{'ott':'watcha','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  RPJODXioqCynscaILdwHWEGzmtuFjV=RPJODXioqCynscaILdwHWEGzmtuFjT.API_DOMAIN+'/api/contents/'+videoid
  RPJODXioqCynscaILdwHWEGzmtuFjY=RPJODXioqCynscaILdwHWEGzmtuFjT.callRequestCookies('Get',RPJODXioqCynscaILdwHWEGzmtuFjV,payload=RPJODXioqCynscaILdwHWEGzmtuFel,params=RPJODXioqCynscaILdwHWEGzmtuFel,headers=RPJODXioqCynscaILdwHWEGzmtuFel,cookies=RPJODXioqCynscaILdwHWEGzmtuFel)
  RPJODXioqCynscaILdwHWEGzmtuFTp=json.loads(RPJODXioqCynscaILdwHWEGzmtuFjY.text)
  if not('title' in RPJODXioqCynscaILdwHWEGzmtuFTp):return{}
  RPJODXioqCynscaILdwHWEGzmtuFeA=RPJODXioqCynscaILdwHWEGzmtuFTp
  RPJODXioqCynscaILdwHWEGzmtuFMT(RPJODXioqCynscaILdwHWEGzmtuFeA.get('duration'))
  RPJODXioqCynscaILdwHWEGzmtuFeb=RPJODXioqCynscaILdwHWEGzmtuFeA.get('title')
  RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['infoLabels']['title']=RPJODXioqCynscaILdwHWEGzmtuFeb
  RPJODXioqCynscaILdwHWEGzmtuFeb +=u'  (%s)'%(RPJODXioqCynscaILdwHWEGzmtuFeA.get('year'))
  RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['title'] =RPJODXioqCynscaILdwHWEGzmtuFeb
  RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['infoLabels']['mpaa'] =RPJODXioqCynscaILdwHWEGzmtuFeA.get('film_rating_long')
  RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['infoLabels']['plot'] =RPJODXioqCynscaILdwHWEGzmtuFeA.get('story').replace('<br>','\n')
  RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['infoLabels']['year'] =RPJODXioqCynscaILdwHWEGzmtuFeA.get('year')
  if vidtype=='movie':
   RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['infoLabels']['duration']=RPJODXioqCynscaILdwHWEGzmtuFeA.get('duration')
  RPJODXioqCynscaILdwHWEGzmtuFeN=[]
  for RPJODXioqCynscaILdwHWEGzmtuFek in RPJODXioqCynscaILdwHWEGzmtuFeA.get('actors'):
   RPJODXioqCynscaILdwHWEGzmtuFev =RPJODXioqCynscaILdwHWEGzmtuFek.get('name')
   RPJODXioqCynscaILdwHWEGzmtuFeh='' if RPJODXioqCynscaILdwHWEGzmtuFek.get('photo')==RPJODXioqCynscaILdwHWEGzmtuFel else RPJODXioqCynscaILdwHWEGzmtuFek.get('photo').get('small')
   RPJODXioqCynscaILdwHWEGzmtuFeN.append({'name':RPJODXioqCynscaILdwHWEGzmtuFev,'thumbnail':RPJODXioqCynscaILdwHWEGzmtuFeh})
  if RPJODXioqCynscaILdwHWEGzmtuFMB(RPJODXioqCynscaILdwHWEGzmtuFeN)>0:
   RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['infoLabels']['cast']=RPJODXioqCynscaILdwHWEGzmtuFeN
  RPJODXioqCynscaILdwHWEGzmtuFeU=[]
  for RPJODXioqCynscaILdwHWEGzmtuFep in RPJODXioqCynscaILdwHWEGzmtuFeA.get('directors'):RPJODXioqCynscaILdwHWEGzmtuFeU.append(RPJODXioqCynscaILdwHWEGzmtuFep.get('name'))
  if RPJODXioqCynscaILdwHWEGzmtuFMB(RPJODXioqCynscaILdwHWEGzmtuFeU)>0:
   RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['infoLabels']['director']=RPJODXioqCynscaILdwHWEGzmtuFeU
  RPJODXioqCynscaILdwHWEGzmtuFeY=[]
  for RPJODXioqCynscaILdwHWEGzmtuFex in RPJODXioqCynscaILdwHWEGzmtuFeA.get('genres'):RPJODXioqCynscaILdwHWEGzmtuFeY.append(RPJODXioqCynscaILdwHWEGzmtuFex.get('name'))
  if RPJODXioqCynscaILdwHWEGzmtuFMB(RPJODXioqCynscaILdwHWEGzmtuFeY)>0:
   RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['infoLabels']['genre']=RPJODXioqCynscaILdwHWEGzmtuFeY
  RPJODXioqCynscaILdwHWEGzmtuFSx =''
  RPJODXioqCynscaILdwHWEGzmtuFef =''
  RPJODXioqCynscaILdwHWEGzmtuFeg =''
  if RPJODXioqCynscaILdwHWEGzmtuFeA.get('poster') !=RPJODXioqCynscaILdwHWEGzmtuFel:RPJODXioqCynscaILdwHWEGzmtuFSx =RPJODXioqCynscaILdwHWEGzmtuFeA.get('poster').get('original')
  if RPJODXioqCynscaILdwHWEGzmtuFeA.get('thumbnail')!=RPJODXioqCynscaILdwHWEGzmtuFel:RPJODXioqCynscaILdwHWEGzmtuFef =RPJODXioqCynscaILdwHWEGzmtuFeA.get('thumbnail').get('large')
  if RPJODXioqCynscaILdwHWEGzmtuFeA.get('stillcut')!=RPJODXioqCynscaILdwHWEGzmtuFel:RPJODXioqCynscaILdwHWEGzmtuFeg =RPJODXioqCynscaILdwHWEGzmtuFeA.get('stillcut').get('large')
  if RPJODXioqCynscaILdwHWEGzmtuFef=='':RPJODXioqCynscaILdwHWEGzmtuFef=RPJODXioqCynscaILdwHWEGzmtuFeg
  RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['thumbnail']['poster']=RPJODXioqCynscaILdwHWEGzmtuFSx
  RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['thumbnail']['fanart']=RPJODXioqCynscaILdwHWEGzmtuFef
  RPJODXioqCynscaILdwHWEGzmtuFeK['saveinfo']['thumbnail']['thumb']=RPJODXioqCynscaILdwHWEGzmtuFeg
  return RPJODXioqCynscaILdwHWEGzmtuFeK
# Created by pyminifier (https://github.com/liftoff/pyminifier)
