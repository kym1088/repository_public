__author__="NightRain"
FMazfsypbAGHuLDRxQNhlEtBSTVIoj=object
FMazfsypbAGHuLDRxQNhlEtBSTVIon=None
FMazfsypbAGHuLDRxQNhlEtBSTVIoP=int
FMazfsypbAGHuLDRxQNhlEtBSTVIOe=True
FMazfsypbAGHuLDRxQNhlEtBSTVIOv=False
FMazfsypbAGHuLDRxQNhlEtBSTVIOm=type
FMazfsypbAGHuLDRxQNhlEtBSTVIOw=dict
FMazfsypbAGHuLDRxQNhlEtBSTVIOU=len
FMazfsypbAGHuLDRxQNhlEtBSTVIOk=range
FMazfsypbAGHuLDRxQNhlEtBSTVIOo=str
FMazfsypbAGHuLDRxQNhlEtBSTVIOW=open
from ast import Pass
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
FMazfsypbAGHuLDRxQNhlEtBSTVIem=[{'title':'홈','mode':'HOME_GROUP','stype':'-','api_path':'-'},{'title':'오직 왓챠에서!','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/6100'},{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest'},{'title':'장르별 둘러보기','mode':'SUB_GROUP','stype':'genres','api_path':'-'},{'title':'특징별 둘러보기','mode':'SUB_GROUP','stype':'tags','api_path':'-'},{'title':'이어보기 (시청이력)','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','icon':'bookmark.png'},]
FMazfsypbAGHuLDRxQNhlEtBSTVIew=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
FMazfsypbAGHuLDRxQNhlEtBSTVIeU=40
FMazfsypbAGHuLDRxQNhlEtBSTVIek =30
FMazfsypbAGHuLDRxQNhlEtBSTVIeo =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
FMazfsypbAGHuLDRxQNhlEtBSTVIeO =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.srt'))
FMazfsypbAGHuLDRxQNhlEtBSTVIeW =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
FMazfsypbAGHuLDRxQNhlEtBSTVIeY=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
from watchaCore import*
class FMazfsypbAGHuLDRxQNhlEtBSTVIev(FMazfsypbAGHuLDRxQNhlEtBSTVIoj):
 def __init__(FMazfsypbAGHuLDRxQNhlEtBSTVIer,FMazfsypbAGHuLDRxQNhlEtBSTVIeq,FMazfsypbAGHuLDRxQNhlEtBSTVIeK,FMazfsypbAGHuLDRxQNhlEtBSTVIec):
  FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_url =FMazfsypbAGHuLDRxQNhlEtBSTVIeq
  FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle=FMazfsypbAGHuLDRxQNhlEtBSTVIeK
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params =FMazfsypbAGHuLDRxQNhlEtBSTVIec
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj =RPJODXioqCynscaILdwHWEGzmtuFjS() 
 def addon_noti(FMazfsypbAGHuLDRxQNhlEtBSTVIer,sting):
  try:
   FMazfsypbAGHuLDRxQNhlEtBSTVIeJ=xbmcgui.Dialog()
   FMazfsypbAGHuLDRxQNhlEtBSTVIeJ.notification(__addonname__,sting)
  except:
   FMazfsypbAGHuLDRxQNhlEtBSTVIon
 def addon_log(FMazfsypbAGHuLDRxQNhlEtBSTVIer,string):
  try:
   FMazfsypbAGHuLDRxQNhlEtBSTVIed=string.encode('utf-8','ignore')
  except:
   FMazfsypbAGHuLDRxQNhlEtBSTVIed='addonException: addon_log'
  FMazfsypbAGHuLDRxQNhlEtBSTVIeC=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,FMazfsypbAGHuLDRxQNhlEtBSTVIed),level=FMazfsypbAGHuLDRxQNhlEtBSTVIeC)
 def get_keyboard_input(FMazfsypbAGHuLDRxQNhlEtBSTVIer,FMazfsypbAGHuLDRxQNhlEtBSTVIvr):
  FMazfsypbAGHuLDRxQNhlEtBSTVIeX=FMazfsypbAGHuLDRxQNhlEtBSTVIon
  kb=xbmc.Keyboard()
  kb.setHeading(FMazfsypbAGHuLDRxQNhlEtBSTVIvr)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   FMazfsypbAGHuLDRxQNhlEtBSTVIeX=kb.getText()
  return FMazfsypbAGHuLDRxQNhlEtBSTVIeX
 def get_settings_account(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  FMazfsypbAGHuLDRxQNhlEtBSTVIeg =__addon__.getSetting('id')
  FMazfsypbAGHuLDRxQNhlEtBSTVIej =__addon__.getSetting('pw')
  FMazfsypbAGHuLDRxQNhlEtBSTVIen=FMazfsypbAGHuLDRxQNhlEtBSTVIoP(__addon__.getSetting('selected_profile'))
  return(FMazfsypbAGHuLDRxQNhlEtBSTVIeg,FMazfsypbAGHuLDRxQNhlEtBSTVIej,FMazfsypbAGHuLDRxQNhlEtBSTVIen)
 def get_settings_totalsearch(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  FMazfsypbAGHuLDRxQNhlEtBSTVIeP =FMazfsypbAGHuLDRxQNhlEtBSTVIOe if __addon__.getSetting('local_search')=='true' else FMazfsypbAGHuLDRxQNhlEtBSTVIOv
  FMazfsypbAGHuLDRxQNhlEtBSTVIve=FMazfsypbAGHuLDRxQNhlEtBSTVIOe if __addon__.getSetting('local_history')=='true' else FMazfsypbAGHuLDRxQNhlEtBSTVIOv
  FMazfsypbAGHuLDRxQNhlEtBSTVIvm =FMazfsypbAGHuLDRxQNhlEtBSTVIOe if __addon__.getSetting('total_search')=='true' else FMazfsypbAGHuLDRxQNhlEtBSTVIOv
  FMazfsypbAGHuLDRxQNhlEtBSTVIvw=FMazfsypbAGHuLDRxQNhlEtBSTVIOe if __addon__.getSetting('total_history')=='true' else FMazfsypbAGHuLDRxQNhlEtBSTVIOv
  FMazfsypbAGHuLDRxQNhlEtBSTVIvU=FMazfsypbAGHuLDRxQNhlEtBSTVIOe if __addon__.getSetting('menu_bookmark')=='true' else FMazfsypbAGHuLDRxQNhlEtBSTVIOv
  return(FMazfsypbAGHuLDRxQNhlEtBSTVIeP,FMazfsypbAGHuLDRxQNhlEtBSTVIve,FMazfsypbAGHuLDRxQNhlEtBSTVIvm,FMazfsypbAGHuLDRxQNhlEtBSTVIvw,FMazfsypbAGHuLDRxQNhlEtBSTVIvU)
 def get_settings_makebookmark(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  return FMazfsypbAGHuLDRxQNhlEtBSTVIOe if __addon__.getSetting('make_bookmark')=='true' else FMazfsypbAGHuLDRxQNhlEtBSTVIOv
 def get_selQuality(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  try:
   FMazfsypbAGHuLDRxQNhlEtBSTVIvk=['3840x2160/1','1920x1080/1','1280x720/1']
   FMazfsypbAGHuLDRxQNhlEtBSTVIvo=FMazfsypbAGHuLDRxQNhlEtBSTVIoP(__addon__.getSetting('selected_quality'))
   return FMazfsypbAGHuLDRxQNhlEtBSTVIvk[FMazfsypbAGHuLDRxQNhlEtBSTVIvo]
  except:
   FMazfsypbAGHuLDRxQNhlEtBSTVIon
  return 1080 
 def get_settings_direct_replay(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  FMazfsypbAGHuLDRxQNhlEtBSTVIvO=FMazfsypbAGHuLDRxQNhlEtBSTVIoP(__addon__.getSetting('direct_replay'))
  if FMazfsypbAGHuLDRxQNhlEtBSTVIvO==0:
   return FMazfsypbAGHuLDRxQNhlEtBSTVIOv
  else:
   return FMazfsypbAGHuLDRxQNhlEtBSTVIOe
 def set_winEpisodeOrderby(FMazfsypbAGHuLDRxQNhlEtBSTVIer,FMazfsypbAGHuLDRxQNhlEtBSTVIvW):
  __addon__.setSetting('watcha_orderby',FMazfsypbAGHuLDRxQNhlEtBSTVIvW)
 def get_winEpisodeOrderby(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  FMazfsypbAGHuLDRxQNhlEtBSTVIvW=__addon__.getSetting('watcha_orderby')
  if FMazfsypbAGHuLDRxQNhlEtBSTVIvW in['',FMazfsypbAGHuLDRxQNhlEtBSTVIon]:FMazfsypbAGHuLDRxQNhlEtBSTVIvW='asc'
  return FMazfsypbAGHuLDRxQNhlEtBSTVIvW
 def dp_setEpOrderby(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVIvW =args.get('orderby')
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.set_winEpisodeOrderby(FMazfsypbAGHuLDRxQNhlEtBSTVIvW)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIer,label,sublabel='',img='',infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIon,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOe,params='',isLink=FMazfsypbAGHuLDRxQNhlEtBSTVIOv,ContextMenu=FMazfsypbAGHuLDRxQNhlEtBSTVIon):
  FMazfsypbAGHuLDRxQNhlEtBSTVIvY='%s?%s'%(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_url,urllib.parse.urlencode(params))
  if sublabel:FMazfsypbAGHuLDRxQNhlEtBSTVIvr='%s < %s >'%(label,sublabel)
  else: FMazfsypbAGHuLDRxQNhlEtBSTVIvr=label
  if not img:img='DefaultFolder.png'
  FMazfsypbAGHuLDRxQNhlEtBSTVIvq=xbmcgui.ListItem(FMazfsypbAGHuLDRxQNhlEtBSTVIvr)
  if FMazfsypbAGHuLDRxQNhlEtBSTVIOm(img)==FMazfsypbAGHuLDRxQNhlEtBSTVIOw:
   FMazfsypbAGHuLDRxQNhlEtBSTVIvq.setArt(img)
  else:
   FMazfsypbAGHuLDRxQNhlEtBSTVIvq.setArt({'thumb':img,'poster':img})
  if infoLabels:FMazfsypbAGHuLDRxQNhlEtBSTVIvq.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   FMazfsypbAGHuLDRxQNhlEtBSTVIvq.setProperty('IsPlayable','true')
  if ContextMenu:FMazfsypbAGHuLDRxQNhlEtBSTVIvq.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,FMazfsypbAGHuLDRxQNhlEtBSTVIvY,FMazfsypbAGHuLDRxQNhlEtBSTVIvq,isFolder)
 def dp_Main_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  (FMazfsypbAGHuLDRxQNhlEtBSTVIeP,FMazfsypbAGHuLDRxQNhlEtBSTVIve,FMazfsypbAGHuLDRxQNhlEtBSTVIvm,FMazfsypbAGHuLDRxQNhlEtBSTVIvw,FMazfsypbAGHuLDRxQNhlEtBSTVIvU)=FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_settings_totalsearch()
  for FMazfsypbAGHuLDRxQNhlEtBSTVIvK in FMazfsypbAGHuLDRxQNhlEtBSTVIem:
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr=FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('title')
   FMazfsypbAGHuLDRxQNhlEtBSTVIvc=''
   if FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('mode')=='LOCAL_SEARCH' and FMazfsypbAGHuLDRxQNhlEtBSTVIeP ==FMazfsypbAGHuLDRxQNhlEtBSTVIOv:continue
   elif FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('mode')=='SEARCH_HISTORY' and FMazfsypbAGHuLDRxQNhlEtBSTVIve==FMazfsypbAGHuLDRxQNhlEtBSTVIOv:continue
   elif FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('mode')=='TOTAL_SEARCH' and FMazfsypbAGHuLDRxQNhlEtBSTVIvm ==FMazfsypbAGHuLDRxQNhlEtBSTVIOv:continue
   elif FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('mode')=='TOTAL_HISTORY' and FMazfsypbAGHuLDRxQNhlEtBSTVIvw==FMazfsypbAGHuLDRxQNhlEtBSTVIOv:continue
   elif FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('mode')=='MENU_BOOKMARK' and FMazfsypbAGHuLDRxQNhlEtBSTVIvU==FMazfsypbAGHuLDRxQNhlEtBSTVIOv:continue
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('mode'),'stype':FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('stype'),'api_path':FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('api_path'),'page':'1','tag_id':'-',}
   if FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('mode')=='LOCAL_SEARCH':FMazfsypbAGHuLDRxQNhlEtBSTVIvi['historyyn']='Y' 
   if FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    FMazfsypbAGHuLDRxQNhlEtBSTVIvJ=FMazfsypbAGHuLDRxQNhlEtBSTVIOv
    FMazfsypbAGHuLDRxQNhlEtBSTVIvd =FMazfsypbAGHuLDRxQNhlEtBSTVIOe
   else:
    FMazfsypbAGHuLDRxQNhlEtBSTVIvJ=FMazfsypbAGHuLDRxQNhlEtBSTVIOe
    FMazfsypbAGHuLDRxQNhlEtBSTVIvd =FMazfsypbAGHuLDRxQNhlEtBSTVIOv
   if 'icon' in FMazfsypbAGHuLDRxQNhlEtBSTVIvK:FMazfsypbAGHuLDRxQNhlEtBSTVIvc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',FMazfsypbAGHuLDRxQNhlEtBSTVIvK.get('icon')) 
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel='',img=FMazfsypbAGHuLDRxQNhlEtBSTVIvc,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIon,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIvJ,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi,isLink=FMazfsypbAGHuLDRxQNhlEtBSTVIvd)
  xbmcplugin.endOfDirectory(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle)
 def login_main(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  (FMazfsypbAGHuLDRxQNhlEtBSTVIvX,FMazfsypbAGHuLDRxQNhlEtBSTVIvg,FMazfsypbAGHuLDRxQNhlEtBSTVIvj)=FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_settings_account()
  if not(FMazfsypbAGHuLDRxQNhlEtBSTVIvX and FMazfsypbAGHuLDRxQNhlEtBSTVIvg):
   FMazfsypbAGHuLDRxQNhlEtBSTVIeJ=xbmcgui.Dialog()
   FMazfsypbAGHuLDRxQNhlEtBSTVIvn=FMazfsypbAGHuLDRxQNhlEtBSTVIeJ.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if FMazfsypbAGHuLDRxQNhlEtBSTVIvn==FMazfsypbAGHuLDRxQNhlEtBSTVIOe:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if FMazfsypbAGHuLDRxQNhlEtBSTVIer.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   FMazfsypbAGHuLDRxQNhlEtBSTVIvP=0
   while FMazfsypbAGHuLDRxQNhlEtBSTVIOe:
    FMazfsypbAGHuLDRxQNhlEtBSTVIvP+=1
    time.sleep(0.05)
    if FMazfsypbAGHuLDRxQNhlEtBSTVIvP>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  FMazfsypbAGHuLDRxQNhlEtBSTVIme=FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.GetCredential(FMazfsypbAGHuLDRxQNhlEtBSTVIvX,FMazfsypbAGHuLDRxQNhlEtBSTVIvg,FMazfsypbAGHuLDRxQNhlEtBSTVIvj)
  if FMazfsypbAGHuLDRxQNhlEtBSTVIme:FMazfsypbAGHuLDRxQNhlEtBSTVIer.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
  if FMazfsypbAGHuLDRxQNhlEtBSTVIme==FMazfsypbAGHuLDRxQNhlEtBSTVIOv:
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_HomeGroup_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVImv=FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.GetHomeList()
  for FMazfsypbAGHuLDRxQNhlEtBSTVImw in FMazfsypbAGHuLDRxQNhlEtBSTVImv:
   FMazfsypbAGHuLDRxQNhlEtBSTVImU =FMazfsypbAGHuLDRxQNhlEtBSTVImw.get('code')
   FMazfsypbAGHuLDRxQNhlEtBSTVImk=FMazfsypbAGHuLDRxQNhlEtBSTVImw.get('content_type')
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr =FMazfsypbAGHuLDRxQNhlEtBSTVImw.get('title')
   FMazfsypbAGHuLDRxQNhlEtBSTVImo =FMazfsypbAGHuLDRxQNhlEtBSTVImw.get('bedge')
   FMazfsypbAGHuLDRxQNhlEtBSTVImO =FMazfsypbAGHuLDRxQNhlEtBSTVImw.get('thumbnail')
   if FMazfsypbAGHuLDRxQNhlEtBSTVImk=='staffmades':
    FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':'CATEGORY_LIST','api_path':'staffmades/'+FMazfsypbAGHuLDRxQNhlEtBSTVImU,'page':'1',}
    FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel=FMazfsypbAGHuLDRxQNhlEtBSTVImo,img=FMazfsypbAGHuLDRxQNhlEtBSTVImO,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIon,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOe,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi)
   elif FMazfsypbAGHuLDRxQNhlEtBSTVImk=='contents':
    FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':'EPISODE','movie_code':FMazfsypbAGHuLDRxQNhlEtBSTVImU,'page':'1','season_code':FMazfsypbAGHuLDRxQNhlEtBSTVImU,'title':FMazfsypbAGHuLDRxQNhlEtBSTVIvr,'thumbnail':FMazfsypbAGHuLDRxQNhlEtBSTVImO,}
    FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel=FMazfsypbAGHuLDRxQNhlEtBSTVImo,img=FMazfsypbAGHuLDRxQNhlEtBSTVImO,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIon,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOe,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi)
   else:
    FMazfsypbAGHuLDRxQNhlEtBSTVImW
  xbmcplugin.endOfDirectory(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,cacheToDisc=FMazfsypbAGHuLDRxQNhlEtBSTVIOe)
 def dp_SubGroup_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVImr =args.get('stype')
  FMazfsypbAGHuLDRxQNhlEtBSTVImq =FMazfsypbAGHuLDRxQNhlEtBSTVIoP(args.get('page'))
  FMazfsypbAGHuLDRxQNhlEtBSTVImK=FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.GetSubGroupList(FMazfsypbAGHuLDRxQNhlEtBSTVImr)
  FMazfsypbAGHuLDRxQNhlEtBSTVImc=FMazfsypbAGHuLDRxQNhlEtBSTVIeU if FMazfsypbAGHuLDRxQNhlEtBSTVImr=='genres' else FMazfsypbAGHuLDRxQNhlEtBSTVIek
  FMazfsypbAGHuLDRxQNhlEtBSTVImi=FMazfsypbAGHuLDRxQNhlEtBSTVIOU(FMazfsypbAGHuLDRxQNhlEtBSTVImK)
  FMazfsypbAGHuLDRxQNhlEtBSTVImJ =FMazfsypbAGHuLDRxQNhlEtBSTVIoP(FMazfsypbAGHuLDRxQNhlEtBSTVImi//(FMazfsypbAGHuLDRxQNhlEtBSTVImc+1))+1
  FMazfsypbAGHuLDRxQNhlEtBSTVImd =(FMazfsypbAGHuLDRxQNhlEtBSTVImq-1)*FMazfsypbAGHuLDRxQNhlEtBSTVImc
  for i in FMazfsypbAGHuLDRxQNhlEtBSTVIOk(FMazfsypbAGHuLDRxQNhlEtBSTVImc):
   FMazfsypbAGHuLDRxQNhlEtBSTVImC=FMazfsypbAGHuLDRxQNhlEtBSTVImd+i
   if FMazfsypbAGHuLDRxQNhlEtBSTVImC>=FMazfsypbAGHuLDRxQNhlEtBSTVImi:break
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr =FMazfsypbAGHuLDRxQNhlEtBSTVImK[FMazfsypbAGHuLDRxQNhlEtBSTVImC].get('group_name')
   FMazfsypbAGHuLDRxQNhlEtBSTVImX =FMazfsypbAGHuLDRxQNhlEtBSTVImK[FMazfsypbAGHuLDRxQNhlEtBSTVImC].get('api_path')
   FMazfsypbAGHuLDRxQNhlEtBSTVImg =FMazfsypbAGHuLDRxQNhlEtBSTVImK[FMazfsypbAGHuLDRxQNhlEtBSTVImC].get('tag_id')
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':'CATEGORY_LIST','api_path':FMazfsypbAGHuLDRxQNhlEtBSTVImX,'tag_id':FMazfsypbAGHuLDRxQNhlEtBSTVImg,'stype':FMazfsypbAGHuLDRxQNhlEtBSTVImr,'page':'1',}
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel='',img='',infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIon,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOe,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi)
  if FMazfsypbAGHuLDRxQNhlEtBSTVImJ>FMazfsypbAGHuLDRxQNhlEtBSTVImq:
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={}
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['mode'] ='SUB_GROUP' 
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['stype'] =FMazfsypbAGHuLDRxQNhlEtBSTVImr
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['api_path']=args.get('api_path')
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['page'] =FMazfsypbAGHuLDRxQNhlEtBSTVIOo(FMazfsypbAGHuLDRxQNhlEtBSTVImq+1)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr='[B]%s >>[/B]'%'다음 페이지'
   FMazfsypbAGHuLDRxQNhlEtBSTVImj=FMazfsypbAGHuLDRxQNhlEtBSTVIOo(FMazfsypbAGHuLDRxQNhlEtBSTVImq+1)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel=FMazfsypbAGHuLDRxQNhlEtBSTVImj,img=FMazfsypbAGHuLDRxQNhlEtBSTVIvc,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIon,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOe,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi)
  if FMazfsypbAGHuLDRxQNhlEtBSTVIOU(FMazfsypbAGHuLDRxQNhlEtBSTVImK)>0:xbmcplugin.endOfDirectory(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,cacheToDisc=FMazfsypbAGHuLDRxQNhlEtBSTVIOe)
 def play_VIDEO(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVImn =args.get('movie_code')
  FMazfsypbAGHuLDRxQNhlEtBSTVImP =args.get('season_code')
  FMazfsypbAGHuLDRxQNhlEtBSTVIvr =args.get('title')
  FMazfsypbAGHuLDRxQNhlEtBSTVImO =args.get('thumbnail')
  FMazfsypbAGHuLDRxQNhlEtBSTVIwe =FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_selQuality()
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.addon_log(FMazfsypbAGHuLDRxQNhlEtBSTVImn+' - '+FMazfsypbAGHuLDRxQNhlEtBSTVImP)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwv,FMazfsypbAGHuLDRxQNhlEtBSTVIwm,FMazfsypbAGHuLDRxQNhlEtBSTVIwU=FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.GetStreamingURL(FMazfsypbAGHuLDRxQNhlEtBSTVImn,FMazfsypbAGHuLDRxQNhlEtBSTVIwe)
  if FMazfsypbAGHuLDRxQNhlEtBSTVIwv=='':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.addon_noti(__language__(30908).encode('utf8'))
   return
  FMazfsypbAGHuLDRxQNhlEtBSTVIwk=FMazfsypbAGHuLDRxQNhlEtBSTVIwv
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.addon_log(FMazfsypbAGHuLDRxQNhlEtBSTVIwk)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwo=xbmcgui.ListItem(path=FMazfsypbAGHuLDRxQNhlEtBSTVIwk)
  if FMazfsypbAGHuLDRxQNhlEtBSTVIwU:
   FMazfsypbAGHuLDRxQNhlEtBSTVIwO=FMazfsypbAGHuLDRxQNhlEtBSTVIwU
   FMazfsypbAGHuLDRxQNhlEtBSTVIwW ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   FMazfsypbAGHuLDRxQNhlEtBSTVIwY ='mpd'
   FMazfsypbAGHuLDRxQNhlEtBSTVIwr ='com.widevine.alpha'
   FMazfsypbAGHuLDRxQNhlEtBSTVIwq =inputstreamhelper.Helper(FMazfsypbAGHuLDRxQNhlEtBSTVIwY,drm=FMazfsypbAGHuLDRxQNhlEtBSTVIwr)
   if FMazfsypbAGHuLDRxQNhlEtBSTVIwq.check_inputstream():
    FMazfsypbAGHuLDRxQNhlEtBSTVIwK={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+FMazfsypbAGHuLDRxQNhlEtBSTVImn,'dt-custom-data':FMazfsypbAGHuLDRxQNhlEtBSTVIwO,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    FMazfsypbAGHuLDRxQNhlEtBSTVIwc=FMazfsypbAGHuLDRxQNhlEtBSTVIwW+'|'+urllib.parse.urlencode(FMazfsypbAGHuLDRxQNhlEtBSTVIwK)+'|R{SSM}|'
    FMazfsypbAGHuLDRxQNhlEtBSTVIer.addon_log(FMazfsypbAGHuLDRxQNhlEtBSTVIwc)
    FMazfsypbAGHuLDRxQNhlEtBSTVIwo.setProperty('inputstream',FMazfsypbAGHuLDRxQNhlEtBSTVIwq.inputstream_addon)
    FMazfsypbAGHuLDRxQNhlEtBSTVIwo.setProperty('inputstream.adaptive.manifest_type',FMazfsypbAGHuLDRxQNhlEtBSTVIwY)
    FMazfsypbAGHuLDRxQNhlEtBSTVIwo.setProperty('inputstream.adaptive.license_type',FMazfsypbAGHuLDRxQNhlEtBSTVIwr)
    FMazfsypbAGHuLDRxQNhlEtBSTVIwo.setProperty('inputstream.adaptive.license_key',FMazfsypbAGHuLDRxQNhlEtBSTVIwc)
    FMazfsypbAGHuLDRxQNhlEtBSTVIwo.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.USER_AGENT))
  if FMazfsypbAGHuLDRxQNhlEtBSTVIwm:
   try:
    f=FMazfsypbAGHuLDRxQNhlEtBSTVIOW(FMazfsypbAGHuLDRxQNhlEtBSTVIeo,'w',-1,'utf-8')
    FMazfsypbAGHuLDRxQNhlEtBSTVIwi=requests.get(FMazfsypbAGHuLDRxQNhlEtBSTVIwm)
    FMazfsypbAGHuLDRxQNhlEtBSTVIwJ=FMazfsypbAGHuLDRxQNhlEtBSTVIwi.content.decode('utf-8') 
    for FMazfsypbAGHuLDRxQNhlEtBSTVIwd in FMazfsypbAGHuLDRxQNhlEtBSTVIwJ.splitlines():
     FMazfsypbAGHuLDRxQNhlEtBSTVIwC=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',FMazfsypbAGHuLDRxQNhlEtBSTVIwd)
     f.write(FMazfsypbAGHuLDRxQNhlEtBSTVIwC+'\n')
    f.close()
    FMazfsypbAGHuLDRxQNhlEtBSTVIwo.setSubtitles([FMazfsypbAGHuLDRxQNhlEtBSTVIeo,FMazfsypbAGHuLDRxQNhlEtBSTVIwm])
   except:
    FMazfsypbAGHuLDRxQNhlEtBSTVIwo.setSubtitles([FMazfsypbAGHuLDRxQNhlEtBSTVIwm])
  xbmcplugin.setResolvedUrl(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,FMazfsypbAGHuLDRxQNhlEtBSTVIOe,FMazfsypbAGHuLDRxQNhlEtBSTVIwo)
 def srtConvert(FMazfsypbAGHuLDRxQNhlEtBSTVIer,FMazfsypbAGHuLDRxQNhlEtBSTVIwg):
  FMazfsypbAGHuLDRxQNhlEtBSTVIwX=re.sub(r'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',FMazfsypbAGHuLDRxQNhlEtBSTVIwg)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwX=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',FMazfsypbAGHuLDRxQNhlEtBSTVIwX)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwX=re.sub(r'(\d\d).(\d\d\d) --> (\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',FMazfsypbAGHuLDRxQNhlEtBSTVIwX)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwX=re.sub(r'WEBVTT\n','',FMazfsypbAGHuLDRxQNhlEtBSTVIwX)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwX=re.sub(r'Kind:[ \-\w]+\n','',FMazfsypbAGHuLDRxQNhlEtBSTVIwX)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwX=re.sub(r'Language:[ \-\w]+\n','',FMazfsypbAGHuLDRxQNhlEtBSTVIwX)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwX=re.sub(r'<c[.\w\d]*>','',FMazfsypbAGHuLDRxQNhlEtBSTVIwX)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwX=re.sub(r'</c>','',FMazfsypbAGHuLDRxQNhlEtBSTVIwX)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwX=re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>','',FMazfsypbAGHuLDRxQNhlEtBSTVIwX)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwX=re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n','',FMazfsypbAGHuLDRxQNhlEtBSTVIwX)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwX=re.sub(r'Style:\n##\n','',FMazfsypbAGHuLDRxQNhlEtBSTVIwX)
  return FMazfsypbAGHuLDRxQNhlEtBSTVIwX
 def vtt_to_srt(FMazfsypbAGHuLDRxQNhlEtBSTVIer,vttFilename,srtFilename):
  try:
   f=FMazfsypbAGHuLDRxQNhlEtBSTVIOW(vttFilename,'r',-1,'utf-8')
   FMazfsypbAGHuLDRxQNhlEtBSTVIwg=f.read()
   f.close()
   FMazfsypbAGHuLDRxQNhlEtBSTVIwj=''
   FMazfsypbAGHuLDRxQNhlEtBSTVIwj=FMazfsypbAGHuLDRxQNhlEtBSTVIwj+FMazfsypbAGHuLDRxQNhlEtBSTVIer.srtConvert(FMazfsypbAGHuLDRxQNhlEtBSTVIwg)
   f=FMazfsypbAGHuLDRxQNhlEtBSTVIOW(srtFilename,'w',-1,'utf-8')
   f.writelines(FMazfsypbAGHuLDRxQNhlEtBSTVIOo(FMazfsypbAGHuLDRxQNhlEtBSTVIwj))
   f.close()
  except:
   return FMazfsypbAGHuLDRxQNhlEtBSTVIOv
  return FMazfsypbAGHuLDRxQNhlEtBSTVIOe
 def dp_Category_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVImr =args.get('stype')
  FMazfsypbAGHuLDRxQNhlEtBSTVImg =args.get('tag_id')
  FMazfsypbAGHuLDRxQNhlEtBSTVImX=args.get('api_path')
  FMazfsypbAGHuLDRxQNhlEtBSTVImq=FMazfsypbAGHuLDRxQNhlEtBSTVIoP(args.get('page'))
  FMazfsypbAGHuLDRxQNhlEtBSTVIwn=[]
  FMazfsypbAGHuLDRxQNhlEtBSTVIwP,FMazfsypbAGHuLDRxQNhlEtBSTVIUe=FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.GetCategoryList(FMazfsypbAGHuLDRxQNhlEtBSTVImr,FMazfsypbAGHuLDRxQNhlEtBSTVImg,FMazfsypbAGHuLDRxQNhlEtBSTVImX,FMazfsypbAGHuLDRxQNhlEtBSTVImq)
  for FMazfsypbAGHuLDRxQNhlEtBSTVIUv in FMazfsypbAGHuLDRxQNhlEtBSTVIwP:
   FMazfsypbAGHuLDRxQNhlEtBSTVImn =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('code')
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('title')
   FMazfsypbAGHuLDRxQNhlEtBSTVImk =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('content_type')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUm =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('story')
   FMazfsypbAGHuLDRxQNhlEtBSTVImO =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('thumbnail')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUw =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('year')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUk =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('film_rating_code')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUo=FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('film_rating_short')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUO =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('film_rating_long')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUW =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('duration')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUY =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('badge')
   FMazfsypbAGHuLDRxQNhlEtBSTVIwn.append(FMazfsypbAGHuLDRxQNhlEtBSTVImn)
   if FMazfsypbAGHuLDRxQNhlEtBSTVImk=='movies': 
    FMazfsypbAGHuLDRxQNhlEtBSTVIvJ =FMazfsypbAGHuLDRxQNhlEtBSTVIOv
    FMazfsypbAGHuLDRxQNhlEtBSTVIUr ='MOVIE'
    FMazfsypbAGHuLDRxQNhlEtBSTVImP='-'
    FMazfsypbAGHuLDRxQNhlEtBSTVIUq ='movie'
   else: 
    FMazfsypbAGHuLDRxQNhlEtBSTVIvJ =FMazfsypbAGHuLDRxQNhlEtBSTVIOe
    FMazfsypbAGHuLDRxQNhlEtBSTVIUr ='EPISODE'
    FMazfsypbAGHuLDRxQNhlEtBSTVImP=FMazfsypbAGHuLDRxQNhlEtBSTVImn
    FMazfsypbAGHuLDRxQNhlEtBSTVIUq ='tvshow' 
   FMazfsypbAGHuLDRxQNhlEtBSTVIUK={'mediatype':FMazfsypbAGHuLDRxQNhlEtBSTVIUq,'mpaa':FMazfsypbAGHuLDRxQNhlEtBSTVIUO,'title':FMazfsypbAGHuLDRxQNhlEtBSTVIvr,'year':FMazfsypbAGHuLDRxQNhlEtBSTVIUw,'duration':FMazfsypbAGHuLDRxQNhlEtBSTVIUW,'plot':FMazfsypbAGHuLDRxQNhlEtBSTVIUm}
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr+='  (%s)'%(FMazfsypbAGHuLDRxQNhlEtBSTVIUw)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':FMazfsypbAGHuLDRxQNhlEtBSTVIUr,'movie_code':FMazfsypbAGHuLDRxQNhlEtBSTVImn,'page':'1','season_code':FMazfsypbAGHuLDRxQNhlEtBSTVImP,'title':FMazfsypbAGHuLDRxQNhlEtBSTVIvr,'thumbnail':FMazfsypbAGHuLDRxQNhlEtBSTVImO}
   FMazfsypbAGHuLDRxQNhlEtBSTVIUc=[]
   if FMazfsypbAGHuLDRxQNhlEtBSTVImX=='users/me/watchings':
    FMazfsypbAGHuLDRxQNhlEtBSTVIUi={'codeList':[FMazfsypbAGHuLDRxQNhlEtBSTVImn]}
    FMazfsypbAGHuLDRxQNhlEtBSTVIUJ=json.dumps(FMazfsypbAGHuLDRxQNhlEtBSTVIUi)
    FMazfsypbAGHuLDRxQNhlEtBSTVIUJ=urllib.parse.quote(FMazfsypbAGHuLDRxQNhlEtBSTVIUJ)
    FMazfsypbAGHuLDRxQNhlEtBSTVIUd='RunPlugin(plugin://plugin.video.watcham/?mode=DELETE_CONTINUE&bm_param=%s)'%(FMazfsypbAGHuLDRxQNhlEtBSTVIUJ)
    FMazfsypbAGHuLDRxQNhlEtBSTVIUc.append(('(선택영상) 이어보기에서 삭제',FMazfsypbAGHuLDRxQNhlEtBSTVIUd))
   if FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_settings_makebookmark():
    FMazfsypbAGHuLDRxQNhlEtBSTVIUi={'videoid':FMazfsypbAGHuLDRxQNhlEtBSTVImn,'vidtype':'tvshow' if FMazfsypbAGHuLDRxQNhlEtBSTVImk=='tv_seasons' else 'movie','vtitle':FMazfsypbAGHuLDRxQNhlEtBSTVIvr,'vsubtitle':'',}
    FMazfsypbAGHuLDRxQNhlEtBSTVIUJ=json.dumps(FMazfsypbAGHuLDRxQNhlEtBSTVIUi)
    FMazfsypbAGHuLDRxQNhlEtBSTVIUJ=urllib.parse.quote(FMazfsypbAGHuLDRxQNhlEtBSTVIUJ)
    FMazfsypbAGHuLDRxQNhlEtBSTVIUd='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(FMazfsypbAGHuLDRxQNhlEtBSTVIUJ)
    FMazfsypbAGHuLDRxQNhlEtBSTVIUc.append(('(통합) 찜 영상에 추가',FMazfsypbAGHuLDRxQNhlEtBSTVIUd))
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel=FMazfsypbAGHuLDRxQNhlEtBSTVIUY,img=FMazfsypbAGHuLDRxQNhlEtBSTVImO,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIUK,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIvJ,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi,ContextMenu=FMazfsypbAGHuLDRxQNhlEtBSTVIUc)
  if FMazfsypbAGHuLDRxQNhlEtBSTVImX=='users/me/watchings':
   FMazfsypbAGHuLDRxQNhlEtBSTVIUi={'codeList':FMazfsypbAGHuLDRxQNhlEtBSTVIwn}
   FMazfsypbAGHuLDRxQNhlEtBSTVIUJ=json.dumps(FMazfsypbAGHuLDRxQNhlEtBSTVIUi,separators=(',',':'))
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.addon_log(FMazfsypbAGHuLDRxQNhlEtBSTVIUJ)
   FMazfsypbAGHuLDRxQNhlEtBSTVIUJ=urllib.parse.quote(FMazfsypbAGHuLDRxQNhlEtBSTVIUJ)
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.addon_log(FMazfsypbAGHuLDRxQNhlEtBSTVIUJ)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':'DELETE_CONTINUE','bm_param':FMazfsypbAGHuLDRxQNhlEtBSTVIUi,}
   FMazfsypbAGHuLDRxQNhlEtBSTVIUK={'plot':'이어보기 목록 전체를 삭제합니다.'}
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr='** 이어보기 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   FMazfsypbAGHuLDRxQNhlEtBSTVIvc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel='',img=FMazfsypbAGHuLDRxQNhlEtBSTVIvc,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIUK,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOv,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi,isLink=FMazfsypbAGHuLDRxQNhlEtBSTVIOe)
  if FMazfsypbAGHuLDRxQNhlEtBSTVIUe:
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={}
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['mode'] ='CATEGORY_LIST'
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['stype'] =FMazfsypbAGHuLDRxQNhlEtBSTVImr
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['tag_id'] =FMazfsypbAGHuLDRxQNhlEtBSTVImg
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['api_path']=FMazfsypbAGHuLDRxQNhlEtBSTVImX
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['page'] =FMazfsypbAGHuLDRxQNhlEtBSTVIOo(FMazfsypbAGHuLDRxQNhlEtBSTVImq+1)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr='[B]%s >>[/B]'%'다음 페이지'
   FMazfsypbAGHuLDRxQNhlEtBSTVImj=FMazfsypbAGHuLDRxQNhlEtBSTVIOo(FMazfsypbAGHuLDRxQNhlEtBSTVImq+1)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel=FMazfsypbAGHuLDRxQNhlEtBSTVImj,img=FMazfsypbAGHuLDRxQNhlEtBSTVIvc,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIon,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOe,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi)
  xbmcplugin.setContent(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,'movies')
  if FMazfsypbAGHuLDRxQNhlEtBSTVIOU(FMazfsypbAGHuLDRxQNhlEtBSTVIwP)>0:
   if FMazfsypbAGHuLDRxQNhlEtBSTVImX=='arrivals/latest':
    xbmcplugin.endOfDirectory(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,cacheToDisc=FMazfsypbAGHuLDRxQNhlEtBSTVIOe)
   else:
    xbmcplugin.endOfDirectory(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,cacheToDisc=FMazfsypbAGHuLDRxQNhlEtBSTVIOv)
 def dp_Episode_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVIUC=args.get('movie_code')
  FMazfsypbAGHuLDRxQNhlEtBSTVImq =FMazfsypbAGHuLDRxQNhlEtBSTVIoP(args.get('page'))
  FMazfsypbAGHuLDRxQNhlEtBSTVImP =args.get('season_code')
  FMazfsypbAGHuLDRxQNhlEtBSTVIwP,FMazfsypbAGHuLDRxQNhlEtBSTVIUe=FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.GetEpisodoList(FMazfsypbAGHuLDRxQNhlEtBSTVIUC,FMazfsypbAGHuLDRxQNhlEtBSTVImq,orderby=FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_winEpisodeOrderby())
  for FMazfsypbAGHuLDRxQNhlEtBSTVIUv in FMazfsypbAGHuLDRxQNhlEtBSTVIwP:
   FMazfsypbAGHuLDRxQNhlEtBSTVImn =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('code')
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('title')
   FMazfsypbAGHuLDRxQNhlEtBSTVImO =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('thumbnail')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUX =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('display_num')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUg =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('season_title')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUj=FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('episode_number')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUW =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('duration')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUK={'mediatype':'episode','tvshowtitle':FMazfsypbAGHuLDRxQNhlEtBSTVIvr if FMazfsypbAGHuLDRxQNhlEtBSTVIvr!='' else FMazfsypbAGHuLDRxQNhlEtBSTVIUg,'title':'%s %s'%(FMazfsypbAGHuLDRxQNhlEtBSTVIUg,FMazfsypbAGHuLDRxQNhlEtBSTVIUX)if FMazfsypbAGHuLDRxQNhlEtBSTVIvr!='' else FMazfsypbAGHuLDRxQNhlEtBSTVIUX,'episode':FMazfsypbAGHuLDRxQNhlEtBSTVIUj,'duration':FMazfsypbAGHuLDRxQNhlEtBSTVIUW,'plot':'%s\n%s\n\n%s'%(FMazfsypbAGHuLDRxQNhlEtBSTVIUg,FMazfsypbAGHuLDRxQNhlEtBSTVIUX,FMazfsypbAGHuLDRxQNhlEtBSTVIvr)}
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr='(%s) %s'%(FMazfsypbAGHuLDRxQNhlEtBSTVIUX,FMazfsypbAGHuLDRxQNhlEtBSTVIvr)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':'MOVIE','movie_code':FMazfsypbAGHuLDRxQNhlEtBSTVImn,'season_code':FMazfsypbAGHuLDRxQNhlEtBSTVImP,'title':'%s < %s >'%(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,FMazfsypbAGHuLDRxQNhlEtBSTVIUg),'thumbnail':FMazfsypbAGHuLDRxQNhlEtBSTVImO}
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel=FMazfsypbAGHuLDRxQNhlEtBSTVIUg,img=FMazfsypbAGHuLDRxQNhlEtBSTVImO,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIUK,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOv,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi)
  if FMazfsypbAGHuLDRxQNhlEtBSTVImq==1:
   FMazfsypbAGHuLDRxQNhlEtBSTVIUK={'plot':'정렬순서를 변경합니다.'}
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={}
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['mode'] ='ORDER_BY' 
   if FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_winEpisodeOrderby()=='desc':
    FMazfsypbAGHuLDRxQNhlEtBSTVIvr='정렬순서변경 : 최신화부터 -> 1회부터'
    FMazfsypbAGHuLDRxQNhlEtBSTVIvi['orderby']='asc'
   else:
    FMazfsypbAGHuLDRxQNhlEtBSTVIvr='정렬순서변경 : 1회부터 -> 최신화부터'
    FMazfsypbAGHuLDRxQNhlEtBSTVIvi['orderby']='desc'
   FMazfsypbAGHuLDRxQNhlEtBSTVIvc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel='',img=FMazfsypbAGHuLDRxQNhlEtBSTVIvc,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIUK,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOv,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi,isLink=FMazfsypbAGHuLDRxQNhlEtBSTVIOe)
  if FMazfsypbAGHuLDRxQNhlEtBSTVIUe:
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['mode'] ='EPISODE' 
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['movie_code']=FMazfsypbAGHuLDRxQNhlEtBSTVIUC
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['page'] =FMazfsypbAGHuLDRxQNhlEtBSTVIOo(FMazfsypbAGHuLDRxQNhlEtBSTVImq+1)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr='[B]%s >>[/B]'%'다음 페이지'
   FMazfsypbAGHuLDRxQNhlEtBSTVImj=FMazfsypbAGHuLDRxQNhlEtBSTVIOo(FMazfsypbAGHuLDRxQNhlEtBSTVImq+1)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel=FMazfsypbAGHuLDRxQNhlEtBSTVImj,img=FMazfsypbAGHuLDRxQNhlEtBSTVIvc,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIon,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOe,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi)
  xbmcplugin.setContent(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,'episodes')
  if FMazfsypbAGHuLDRxQNhlEtBSTVIOU(FMazfsypbAGHuLDRxQNhlEtBSTVIwP)>0:xbmcplugin.endOfDirectory(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,cacheToDisc=FMazfsypbAGHuLDRxQNhlEtBSTVIOe)
 def dp_Search_History(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVIUn=FMazfsypbAGHuLDRxQNhlEtBSTVIer.Load_List_File('search')
  for FMazfsypbAGHuLDRxQNhlEtBSTVIUP in FMazfsypbAGHuLDRxQNhlEtBSTVIUn:
   FMazfsypbAGHuLDRxQNhlEtBSTVIke=FMazfsypbAGHuLDRxQNhlEtBSTVIOw(urllib.parse.parse_qsl(FMazfsypbAGHuLDRxQNhlEtBSTVIUP))
   FMazfsypbAGHuLDRxQNhlEtBSTVIkv=FMazfsypbAGHuLDRxQNhlEtBSTVIke.get('skey').strip()
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':'LOCAL_SEARCH','search_key':FMazfsypbAGHuLDRxQNhlEtBSTVIkv,'page':'1','historyyn':'Y',}
   FMazfsypbAGHuLDRxQNhlEtBSTVIkm={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':FMazfsypbAGHuLDRxQNhlEtBSTVIkv,'vType':'-',}
   FMazfsypbAGHuLDRxQNhlEtBSTVIkw=urllib.parse.urlencode(FMazfsypbAGHuLDRxQNhlEtBSTVIkm)
   FMazfsypbAGHuLDRxQNhlEtBSTVIUc=[('선택된 검색어 ( %s ) 삭제'%(FMazfsypbAGHuLDRxQNhlEtBSTVIkv),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(FMazfsypbAGHuLDRxQNhlEtBSTVIkw))]
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIkv,sublabel='',img=FMazfsypbAGHuLDRxQNhlEtBSTVIon,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIon,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOe,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi,ContextMenu=FMazfsypbAGHuLDRxQNhlEtBSTVIUc)
  FMazfsypbAGHuLDRxQNhlEtBSTVIUK={'plot':'검색목록 전체를 삭제합니다.'}
  FMazfsypbAGHuLDRxQNhlEtBSTVIvr='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  FMazfsypbAGHuLDRxQNhlEtBSTVIvc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel='',img=FMazfsypbAGHuLDRxQNhlEtBSTVIvc,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIUK,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOv,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi,isLink=FMazfsypbAGHuLDRxQNhlEtBSTVIOe)
  xbmcplugin.endOfDirectory(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,cacheToDisc=FMazfsypbAGHuLDRxQNhlEtBSTVIOv)
 def dp_Search_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVImq =FMazfsypbAGHuLDRxQNhlEtBSTVIoP(args.get('page'))
  if 'search_key' in args:
   FMazfsypbAGHuLDRxQNhlEtBSTVIkU=args.get('search_key')
  else:
   FMazfsypbAGHuLDRxQNhlEtBSTVIkU=FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not FMazfsypbAGHuLDRxQNhlEtBSTVIkU:
    return
  FMazfsypbAGHuLDRxQNhlEtBSTVIwP,FMazfsypbAGHuLDRxQNhlEtBSTVIUe=FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.GetSearchList(FMazfsypbAGHuLDRxQNhlEtBSTVIkU,FMazfsypbAGHuLDRxQNhlEtBSTVImq)
  for FMazfsypbAGHuLDRxQNhlEtBSTVIUv in FMazfsypbAGHuLDRxQNhlEtBSTVIwP:
   FMazfsypbAGHuLDRxQNhlEtBSTVImn =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('code')
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('title')
   FMazfsypbAGHuLDRxQNhlEtBSTVImk=FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('content_type')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUm =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('story')
   FMazfsypbAGHuLDRxQNhlEtBSTVImO =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('thumbnail')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUw =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('year')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUk =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('film_rating_code')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUo=FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('film_rating_short')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUO =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('film_rating_long')
   FMazfsypbAGHuLDRxQNhlEtBSTVIUW =FMazfsypbAGHuLDRxQNhlEtBSTVIUv.get('duration')
   if FMazfsypbAGHuLDRxQNhlEtBSTVImk=='movies': 
    FMazfsypbAGHuLDRxQNhlEtBSTVIvJ =FMazfsypbAGHuLDRxQNhlEtBSTVIOv
    FMazfsypbAGHuLDRxQNhlEtBSTVIUr ='MOVIE'
    FMazfsypbAGHuLDRxQNhlEtBSTVIvC =''
    FMazfsypbAGHuLDRxQNhlEtBSTVImP='-'
    FMazfsypbAGHuLDRxQNhlEtBSTVIUq ='movie'
   else: 
    FMazfsypbAGHuLDRxQNhlEtBSTVIvJ =FMazfsypbAGHuLDRxQNhlEtBSTVIOe
    FMazfsypbAGHuLDRxQNhlEtBSTVIUr ='EPISODE'
    FMazfsypbAGHuLDRxQNhlEtBSTVIvC ='' 
    FMazfsypbAGHuLDRxQNhlEtBSTVImP=FMazfsypbAGHuLDRxQNhlEtBSTVImn
    FMazfsypbAGHuLDRxQNhlEtBSTVIUq ='tvshow' 
   FMazfsypbAGHuLDRxQNhlEtBSTVIUK={'mediatype':FMazfsypbAGHuLDRxQNhlEtBSTVIUq,'mpaa':FMazfsypbAGHuLDRxQNhlEtBSTVIUO,'title':FMazfsypbAGHuLDRxQNhlEtBSTVIvr,'year':FMazfsypbAGHuLDRxQNhlEtBSTVIUw,'duration':FMazfsypbAGHuLDRxQNhlEtBSTVIUW,'plot':FMazfsypbAGHuLDRxQNhlEtBSTVIUm}
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr+='  (%s)'%(FMazfsypbAGHuLDRxQNhlEtBSTVIUw)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':FMazfsypbAGHuLDRxQNhlEtBSTVIUr,'movie_code':FMazfsypbAGHuLDRxQNhlEtBSTVImn,'page':'1','season_code':FMazfsypbAGHuLDRxQNhlEtBSTVImP,'title':FMazfsypbAGHuLDRxQNhlEtBSTVIvr,'thumbnail':FMazfsypbAGHuLDRxQNhlEtBSTVImO}
   if FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_settings_makebookmark():
    FMazfsypbAGHuLDRxQNhlEtBSTVIUi={'videoid':FMazfsypbAGHuLDRxQNhlEtBSTVImn,'vidtype':'tvshow' if FMazfsypbAGHuLDRxQNhlEtBSTVImk=='tv_seasons' else 'movie','vtitle':FMazfsypbAGHuLDRxQNhlEtBSTVIvr,'vsubtitle':'',}
    FMazfsypbAGHuLDRxQNhlEtBSTVIUJ=json.dumps(FMazfsypbAGHuLDRxQNhlEtBSTVIUi)
    FMazfsypbAGHuLDRxQNhlEtBSTVIUJ=urllib.parse.quote(FMazfsypbAGHuLDRxQNhlEtBSTVIUJ)
    FMazfsypbAGHuLDRxQNhlEtBSTVIUd='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(FMazfsypbAGHuLDRxQNhlEtBSTVIUJ)
    FMazfsypbAGHuLDRxQNhlEtBSTVIUc=[('(통합) 찜 영상에 추가',FMazfsypbAGHuLDRxQNhlEtBSTVIUd)]
   else:
    FMazfsypbAGHuLDRxQNhlEtBSTVIUc=FMazfsypbAGHuLDRxQNhlEtBSTVIon
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel=FMazfsypbAGHuLDRxQNhlEtBSTVIvC,img=FMazfsypbAGHuLDRxQNhlEtBSTVImO,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIUK,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIvJ,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi,ContextMenu=FMazfsypbAGHuLDRxQNhlEtBSTVIUc)
  if FMazfsypbAGHuLDRxQNhlEtBSTVIUe:
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={}
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['mode'] ='SEARCH'
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['search_key']=FMazfsypbAGHuLDRxQNhlEtBSTVIkU
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi['page'] =FMazfsypbAGHuLDRxQNhlEtBSTVIOo(FMazfsypbAGHuLDRxQNhlEtBSTVImq+1)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr='[B]%s >>[/B]'%'다음 페이지'
   FMazfsypbAGHuLDRxQNhlEtBSTVImj=FMazfsypbAGHuLDRxQNhlEtBSTVIOo(FMazfsypbAGHuLDRxQNhlEtBSTVImq+1)
   FMazfsypbAGHuLDRxQNhlEtBSTVIvc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel=FMazfsypbAGHuLDRxQNhlEtBSTVImj,img=FMazfsypbAGHuLDRxQNhlEtBSTVIvc,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIon,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOe,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi)
  xbmcplugin.setContent(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,'movies')
  xbmcplugin.endOfDirectory(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,cacheToDisc=FMazfsypbAGHuLDRxQNhlEtBSTVIOe)
  if args.get('historyyn')=='Y':FMazfsypbAGHuLDRxQNhlEtBSTVIer.Save_Searched_List(FMazfsypbAGHuLDRxQNhlEtBSTVIkU)
 def dp_Delete_Continue(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVIko=urllib.parse.unquote(args.get('bm_param'))
  FMazfsypbAGHuLDRxQNhlEtBSTVIko=FMazfsypbAGHuLDRxQNhlEtBSTVIko.replace('\'','"')
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.addon_log(FMazfsypbAGHuLDRxQNhlEtBSTVIko)
  FMazfsypbAGHuLDRxQNhlEtBSTVIko=json.loads(FMazfsypbAGHuLDRxQNhlEtBSTVIko)
  FMazfsypbAGHuLDRxQNhlEtBSTVIwn=FMazfsypbAGHuLDRxQNhlEtBSTVIko.get('codeList')
  FMazfsypbAGHuLDRxQNhlEtBSTVIeJ=xbmcgui.Dialog()
  FMazfsypbAGHuLDRxQNhlEtBSTVIvn=FMazfsypbAGHuLDRxQNhlEtBSTVIeJ.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if FMazfsypbAGHuLDRxQNhlEtBSTVIvn==FMazfsypbAGHuLDRxQNhlEtBSTVIOv:sys.exit()
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.DeleteContinueList(FMazfsypbAGHuLDRxQNhlEtBSTVIwn)
  xbmc.executebuiltin("Container.Refresh")
 def dp_History_Remove(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVIkO=args.get('delType')
  FMazfsypbAGHuLDRxQNhlEtBSTVIkW =args.get('sKey')
  FMazfsypbAGHuLDRxQNhlEtBSTVIkY =args.get('vType')
  FMazfsypbAGHuLDRxQNhlEtBSTVIeJ=xbmcgui.Dialog()
  if FMazfsypbAGHuLDRxQNhlEtBSTVIkO=='SEARCH_ALL':
   FMazfsypbAGHuLDRxQNhlEtBSTVIvn=FMazfsypbAGHuLDRxQNhlEtBSTVIeJ.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIkO=='SEARCH_ONE':
   FMazfsypbAGHuLDRxQNhlEtBSTVIvn=FMazfsypbAGHuLDRxQNhlEtBSTVIeJ.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIkO=='WATCH_ALL':
   FMazfsypbAGHuLDRxQNhlEtBSTVIvn=FMazfsypbAGHuLDRxQNhlEtBSTVIeJ.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIkO=='WATCH_ONE':
   FMazfsypbAGHuLDRxQNhlEtBSTVIvn=FMazfsypbAGHuLDRxQNhlEtBSTVIeJ.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if FMazfsypbAGHuLDRxQNhlEtBSTVIvn==FMazfsypbAGHuLDRxQNhlEtBSTVIOv:sys.exit()
  if FMazfsypbAGHuLDRxQNhlEtBSTVIkO=='SEARCH_ALL':
   if os.path.isfile(FMazfsypbAGHuLDRxQNhlEtBSTVIeY):os.remove(FMazfsypbAGHuLDRxQNhlEtBSTVIeY)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIkO=='SEARCH_ONE':
   try:
    FMazfsypbAGHuLDRxQNhlEtBSTVIkr=FMazfsypbAGHuLDRxQNhlEtBSTVIeY
    FMazfsypbAGHuLDRxQNhlEtBSTVIkq=FMazfsypbAGHuLDRxQNhlEtBSTVIer.Load_List_File('search') 
    fp=FMazfsypbAGHuLDRxQNhlEtBSTVIOW(FMazfsypbAGHuLDRxQNhlEtBSTVIkr,'w',-1,'utf-8')
    for FMazfsypbAGHuLDRxQNhlEtBSTVIkK in FMazfsypbAGHuLDRxQNhlEtBSTVIkq:
     FMazfsypbAGHuLDRxQNhlEtBSTVIkc=FMazfsypbAGHuLDRxQNhlEtBSTVIOw(urllib.parse.parse_qsl(FMazfsypbAGHuLDRxQNhlEtBSTVIkK))
     FMazfsypbAGHuLDRxQNhlEtBSTVIki=FMazfsypbAGHuLDRxQNhlEtBSTVIkc.get('skey').strip()
     if FMazfsypbAGHuLDRxQNhlEtBSTVIkW!=FMazfsypbAGHuLDRxQNhlEtBSTVIki:
      fp.write(FMazfsypbAGHuLDRxQNhlEtBSTVIkK)
    fp.close()
   except:
    FMazfsypbAGHuLDRxQNhlEtBSTVIon
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIkO=='WATCH_ALL':
   FMazfsypbAGHuLDRxQNhlEtBSTVIkr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FMazfsypbAGHuLDRxQNhlEtBSTVIkY))
   if os.path.isfile(FMazfsypbAGHuLDRxQNhlEtBSTVIkr):os.remove(FMazfsypbAGHuLDRxQNhlEtBSTVIkr)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIkO=='WATCH_ONE':
   FMazfsypbAGHuLDRxQNhlEtBSTVIkr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FMazfsypbAGHuLDRxQNhlEtBSTVIkY))
   try:
    FMazfsypbAGHuLDRxQNhlEtBSTVIkq=FMazfsypbAGHuLDRxQNhlEtBSTVIer.Load_List_File(FMazfsypbAGHuLDRxQNhlEtBSTVIkY) 
    fp=FMazfsypbAGHuLDRxQNhlEtBSTVIOW(FMazfsypbAGHuLDRxQNhlEtBSTVIkr,'w',-1,'utf-8')
    for FMazfsypbAGHuLDRxQNhlEtBSTVIkK in FMazfsypbAGHuLDRxQNhlEtBSTVIkq:
     FMazfsypbAGHuLDRxQNhlEtBSTVIkc=FMazfsypbAGHuLDRxQNhlEtBSTVIOw(urllib.parse.parse_qsl(FMazfsypbAGHuLDRxQNhlEtBSTVIkK))
     FMazfsypbAGHuLDRxQNhlEtBSTVIki=FMazfsypbAGHuLDRxQNhlEtBSTVIkc.get('code').strip()
     if FMazfsypbAGHuLDRxQNhlEtBSTVIkW!=FMazfsypbAGHuLDRxQNhlEtBSTVIki:
      fp.write(FMazfsypbAGHuLDRxQNhlEtBSTVIkK)
    fp.close()
   except:
    FMazfsypbAGHuLDRxQNhlEtBSTVIon
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(FMazfsypbAGHuLDRxQNhlEtBSTVIer,FMazfsypbAGHuLDRxQNhlEtBSTVImr): 
  try:
   if FMazfsypbAGHuLDRxQNhlEtBSTVImr=='search':
    FMazfsypbAGHuLDRxQNhlEtBSTVIkr=FMazfsypbAGHuLDRxQNhlEtBSTVIeY
   elif FMazfsypbAGHuLDRxQNhlEtBSTVImr in['seasons','movie']:
    FMazfsypbAGHuLDRxQNhlEtBSTVIkr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FMazfsypbAGHuLDRxQNhlEtBSTVImr))
   else:
    return[]
   fp=FMazfsypbAGHuLDRxQNhlEtBSTVIOW(FMazfsypbAGHuLDRxQNhlEtBSTVIkr,'r',-1,'utf-8')
   FMazfsypbAGHuLDRxQNhlEtBSTVIkJ=fp.readlines()
   fp.close()
  except:
   FMazfsypbAGHuLDRxQNhlEtBSTVIkJ=[]
  return FMazfsypbAGHuLDRxQNhlEtBSTVIkJ
 def Save_Watched_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer,FMazfsypbAGHuLDRxQNhlEtBSTVImr,FMazfsypbAGHuLDRxQNhlEtBSTVIec):
  try:
   FMazfsypbAGHuLDRxQNhlEtBSTVIkd=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FMazfsypbAGHuLDRxQNhlEtBSTVImr))
   FMazfsypbAGHuLDRxQNhlEtBSTVIkq=FMazfsypbAGHuLDRxQNhlEtBSTVIer.Load_List_File(FMazfsypbAGHuLDRxQNhlEtBSTVImr) 
   fp=FMazfsypbAGHuLDRxQNhlEtBSTVIOW(FMazfsypbAGHuLDRxQNhlEtBSTVIkd,'w',-1,'utf-8')
   FMazfsypbAGHuLDRxQNhlEtBSTVIkC=urllib.parse.urlencode(FMazfsypbAGHuLDRxQNhlEtBSTVIec)
   FMazfsypbAGHuLDRxQNhlEtBSTVIkC=FMazfsypbAGHuLDRxQNhlEtBSTVIkC+'\n'
   fp.write(FMazfsypbAGHuLDRxQNhlEtBSTVIkC)
   FMazfsypbAGHuLDRxQNhlEtBSTVIkX=0
   for FMazfsypbAGHuLDRxQNhlEtBSTVIkK in FMazfsypbAGHuLDRxQNhlEtBSTVIkq:
    FMazfsypbAGHuLDRxQNhlEtBSTVIkc=FMazfsypbAGHuLDRxQNhlEtBSTVIOw(urllib.parse.parse_qsl(FMazfsypbAGHuLDRxQNhlEtBSTVIkK))
    FMazfsypbAGHuLDRxQNhlEtBSTVIkg=FMazfsypbAGHuLDRxQNhlEtBSTVIec.get('code').strip()
    FMazfsypbAGHuLDRxQNhlEtBSTVIkj=FMazfsypbAGHuLDRxQNhlEtBSTVIkc.get('code').strip()
    if FMazfsypbAGHuLDRxQNhlEtBSTVImr=='seasons' and FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_settings_direct_replay()==FMazfsypbAGHuLDRxQNhlEtBSTVIOe:
     FMazfsypbAGHuLDRxQNhlEtBSTVIkg=FMazfsypbAGHuLDRxQNhlEtBSTVIec.get('videoid').strip()
     FMazfsypbAGHuLDRxQNhlEtBSTVIkj=FMazfsypbAGHuLDRxQNhlEtBSTVIkc.get('videoid').strip()if FMazfsypbAGHuLDRxQNhlEtBSTVIkj!=FMazfsypbAGHuLDRxQNhlEtBSTVIon else '-'
    if FMazfsypbAGHuLDRxQNhlEtBSTVIkg!=FMazfsypbAGHuLDRxQNhlEtBSTVIkj:
     fp.write(FMazfsypbAGHuLDRxQNhlEtBSTVIkK)
     FMazfsypbAGHuLDRxQNhlEtBSTVIkX+=1
     if FMazfsypbAGHuLDRxQNhlEtBSTVIkX>=50:break
   fp.close()
  except:
   FMazfsypbAGHuLDRxQNhlEtBSTVIon
 def dp_Watch_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVImr =args.get('stype')
  FMazfsypbAGHuLDRxQNhlEtBSTVIvO=FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_settings_direct_replay()
  if FMazfsypbAGHuLDRxQNhlEtBSTVImr=='-':
   for FMazfsypbAGHuLDRxQNhlEtBSTVIkn in FMazfsypbAGHuLDRxQNhlEtBSTVIew:
    FMazfsypbAGHuLDRxQNhlEtBSTVIvr=FMazfsypbAGHuLDRxQNhlEtBSTVIkn.get('title')
    FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':FMazfsypbAGHuLDRxQNhlEtBSTVIkn.get('mode'),'stype':FMazfsypbAGHuLDRxQNhlEtBSTVIkn.get('stype')}
    FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel='',img='',infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIon,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOe,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi)
   if FMazfsypbAGHuLDRxQNhlEtBSTVIOU(FMazfsypbAGHuLDRxQNhlEtBSTVIew)>0:xbmcplugin.endOfDirectory(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle)
  else:
   FMazfsypbAGHuLDRxQNhlEtBSTVIkP=FMazfsypbAGHuLDRxQNhlEtBSTVIer.Load_List_File(FMazfsypbAGHuLDRxQNhlEtBSTVImr)
   for FMazfsypbAGHuLDRxQNhlEtBSTVIoe in FMazfsypbAGHuLDRxQNhlEtBSTVIkP:
    FMazfsypbAGHuLDRxQNhlEtBSTVIke=FMazfsypbAGHuLDRxQNhlEtBSTVIOw(urllib.parse.parse_qsl(FMazfsypbAGHuLDRxQNhlEtBSTVIoe))
    FMazfsypbAGHuLDRxQNhlEtBSTVImn=FMazfsypbAGHuLDRxQNhlEtBSTVIke.get('code').strip()
    FMazfsypbAGHuLDRxQNhlEtBSTVIvr =FMazfsypbAGHuLDRxQNhlEtBSTVIke.get('title').strip()
    FMazfsypbAGHuLDRxQNhlEtBSTVImO =FMazfsypbAGHuLDRxQNhlEtBSTVIke.get('img').strip()
    FMazfsypbAGHuLDRxQNhlEtBSTVIov =FMazfsypbAGHuLDRxQNhlEtBSTVIke.get('videoid').strip()
    try:
     FMazfsypbAGHuLDRxQNhlEtBSTVImO=FMazfsypbAGHuLDRxQNhlEtBSTVImO.replace('\'','\"')
     FMazfsypbAGHuLDRxQNhlEtBSTVImO=json.loads(FMazfsypbAGHuLDRxQNhlEtBSTVImO)
    except:
     FMazfsypbAGHuLDRxQNhlEtBSTVIon
    FMazfsypbAGHuLDRxQNhlEtBSTVIUK={}
    FMazfsypbAGHuLDRxQNhlEtBSTVIUK['plot']=FMazfsypbAGHuLDRxQNhlEtBSTVIvr
    if FMazfsypbAGHuLDRxQNhlEtBSTVImr=='movie':
     FMazfsypbAGHuLDRxQNhlEtBSTVIUK['mediatype']='movie'
     FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':'MOVIE','page':'1','movie_code':FMazfsypbAGHuLDRxQNhlEtBSTVImn,'season_code':'-','title':FMazfsypbAGHuLDRxQNhlEtBSTVIvr,'thumbnail':FMazfsypbAGHuLDRxQNhlEtBSTVImO}
     FMazfsypbAGHuLDRxQNhlEtBSTVIvJ=FMazfsypbAGHuLDRxQNhlEtBSTVIOv
    else:
     if FMazfsypbAGHuLDRxQNhlEtBSTVIvO==FMazfsypbAGHuLDRxQNhlEtBSTVIOv or FMazfsypbAGHuLDRxQNhlEtBSTVIov==FMazfsypbAGHuLDRxQNhlEtBSTVIon:
      FMazfsypbAGHuLDRxQNhlEtBSTVIUK['mediatype']='tvshow'
      FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':'EPISODE','page':'1','movie_code':FMazfsypbAGHuLDRxQNhlEtBSTVImn,'season_code':FMazfsypbAGHuLDRxQNhlEtBSTVImn,'title':FMazfsypbAGHuLDRxQNhlEtBSTVIvr,'thumbnail':FMazfsypbAGHuLDRxQNhlEtBSTVImO}
      FMazfsypbAGHuLDRxQNhlEtBSTVIvJ=FMazfsypbAGHuLDRxQNhlEtBSTVIOe
     else:
      FMazfsypbAGHuLDRxQNhlEtBSTVIUK['mediatype']='episode'
      FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':'MOVIE','movie_code':FMazfsypbAGHuLDRxQNhlEtBSTVIov,'season_code':FMazfsypbAGHuLDRxQNhlEtBSTVImn,'title':FMazfsypbAGHuLDRxQNhlEtBSTVIvr,'thumbnail':FMazfsypbAGHuLDRxQNhlEtBSTVImO}
      FMazfsypbAGHuLDRxQNhlEtBSTVIvJ=FMazfsypbAGHuLDRxQNhlEtBSTVIOv
    FMazfsypbAGHuLDRxQNhlEtBSTVIkm={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':FMazfsypbAGHuLDRxQNhlEtBSTVImn,'vType':FMazfsypbAGHuLDRxQNhlEtBSTVImr,}
    FMazfsypbAGHuLDRxQNhlEtBSTVIkw=urllib.parse.urlencode(FMazfsypbAGHuLDRxQNhlEtBSTVIkm)
    FMazfsypbAGHuLDRxQNhlEtBSTVIUc=[('선택된 시청이력 ( %s ) 삭제'%(FMazfsypbAGHuLDRxQNhlEtBSTVIvr),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(FMazfsypbAGHuLDRxQNhlEtBSTVIkw))]
    FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel='',img=FMazfsypbAGHuLDRxQNhlEtBSTVImO,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIUK,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIvJ,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi,ContextMenu=FMazfsypbAGHuLDRxQNhlEtBSTVIUc)
   FMazfsypbAGHuLDRxQNhlEtBSTVIUK={'plot':'시청목록을 삭제합니다.'}
   FMazfsypbAGHuLDRxQNhlEtBSTVIvr='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   FMazfsypbAGHuLDRxQNhlEtBSTVIvi={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':FMazfsypbAGHuLDRxQNhlEtBSTVImr,}
   FMazfsypbAGHuLDRxQNhlEtBSTVIvc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.add_dir(FMazfsypbAGHuLDRxQNhlEtBSTVIvr,sublabel='',img=FMazfsypbAGHuLDRxQNhlEtBSTVIvc,infoLabels=FMazfsypbAGHuLDRxQNhlEtBSTVIUK,isFolder=FMazfsypbAGHuLDRxQNhlEtBSTVIOv,params=FMazfsypbAGHuLDRxQNhlEtBSTVIvi,isLink=FMazfsypbAGHuLDRxQNhlEtBSTVIOe)
   if FMazfsypbAGHuLDRxQNhlEtBSTVImr=='movie':xbmcplugin.setContent(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,'movies')
   else:xbmcplugin.setContent(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(FMazfsypbAGHuLDRxQNhlEtBSTVIer._addon_handle,cacheToDisc=FMazfsypbAGHuLDRxQNhlEtBSTVIOv)
 def Save_Searched_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer,FMazfsypbAGHuLDRxQNhlEtBSTVIkU):
  try:
   FMazfsypbAGHuLDRxQNhlEtBSTVIom=FMazfsypbAGHuLDRxQNhlEtBSTVIeY
   FMazfsypbAGHuLDRxQNhlEtBSTVIkq=FMazfsypbAGHuLDRxQNhlEtBSTVIer.Load_List_File('search') 
   FMazfsypbAGHuLDRxQNhlEtBSTVIow={'skey':FMazfsypbAGHuLDRxQNhlEtBSTVIkU.strip()}
   fp=FMazfsypbAGHuLDRxQNhlEtBSTVIOW(FMazfsypbAGHuLDRxQNhlEtBSTVIom,'w',-1,'utf-8')
   FMazfsypbAGHuLDRxQNhlEtBSTVIkC=urllib.parse.urlencode(FMazfsypbAGHuLDRxQNhlEtBSTVIow)
   FMazfsypbAGHuLDRxQNhlEtBSTVIkC=FMazfsypbAGHuLDRxQNhlEtBSTVIkC+'\n'
   fp.write(FMazfsypbAGHuLDRxQNhlEtBSTVIkC)
   FMazfsypbAGHuLDRxQNhlEtBSTVIkX=0
   for FMazfsypbAGHuLDRxQNhlEtBSTVIkK in FMazfsypbAGHuLDRxQNhlEtBSTVIkq:
    FMazfsypbAGHuLDRxQNhlEtBSTVIkc=FMazfsypbAGHuLDRxQNhlEtBSTVIOw(urllib.parse.parse_qsl(FMazfsypbAGHuLDRxQNhlEtBSTVIkK))
    FMazfsypbAGHuLDRxQNhlEtBSTVIkg=FMazfsypbAGHuLDRxQNhlEtBSTVIow.get('skey').strip()
    FMazfsypbAGHuLDRxQNhlEtBSTVIkj=FMazfsypbAGHuLDRxQNhlEtBSTVIkc.get('skey').strip()
    if FMazfsypbAGHuLDRxQNhlEtBSTVIkg!=FMazfsypbAGHuLDRxQNhlEtBSTVIkj:
     fp.write(FMazfsypbAGHuLDRxQNhlEtBSTVIkK)
     FMazfsypbAGHuLDRxQNhlEtBSTVIkX+=1
     if FMazfsypbAGHuLDRxQNhlEtBSTVIkX>=50:break
   fp.close()
  except:
   FMazfsypbAGHuLDRxQNhlEtBSTVIon
 def logout(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  FMazfsypbAGHuLDRxQNhlEtBSTVIeJ=xbmcgui.Dialog()
  FMazfsypbAGHuLDRxQNhlEtBSTVIvn=FMazfsypbAGHuLDRxQNhlEtBSTVIeJ.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if FMazfsypbAGHuLDRxQNhlEtBSTVIvn==FMazfsypbAGHuLDRxQNhlEtBSTVIOv:sys.exit()
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.Init_WC_Total()
  if os.path.isfile(FMazfsypbAGHuLDRxQNhlEtBSTVIeW):os.remove(FMazfsypbAGHuLDRxQNhlEtBSTVIeW)
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  FMazfsypbAGHuLDRxQNhlEtBSTVIoU =FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.Get_Now_Datetime()
  FMazfsypbAGHuLDRxQNhlEtBSTVIok=FMazfsypbAGHuLDRxQNhlEtBSTVIoU+datetime.timedelta(days=FMazfsypbAGHuLDRxQNhlEtBSTVIoP(__addon__.getSetting('cache_ttl')))
  (FMazfsypbAGHuLDRxQNhlEtBSTVIvX,FMazfsypbAGHuLDRxQNhlEtBSTVIvg,FMazfsypbAGHuLDRxQNhlEtBSTVIvj)=FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_settings_account()
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.Save_session_acount(FMazfsypbAGHuLDRxQNhlEtBSTVIvX,FMazfsypbAGHuLDRxQNhlEtBSTVIvg,FMazfsypbAGHuLDRxQNhlEtBSTVIvj)
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.WC['account']['token_limit']=FMazfsypbAGHuLDRxQNhlEtBSTVIok.strftime('%Y%m%d')
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.JsonFile_Save(FMazfsypbAGHuLDRxQNhlEtBSTVIeW,FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.WC)
 def cookiefile_check(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.WC=FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.JsonFile_Load(FMazfsypbAGHuLDRxQNhlEtBSTVIeW)
  if 'account' not in FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.WC:
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.Init_WC_Total()
   return FMazfsypbAGHuLDRxQNhlEtBSTVIOv
  (FMazfsypbAGHuLDRxQNhlEtBSTVIoO,FMazfsypbAGHuLDRxQNhlEtBSTVIoW,FMazfsypbAGHuLDRxQNhlEtBSTVIoY)=FMazfsypbAGHuLDRxQNhlEtBSTVIer.get_settings_account()
  (FMazfsypbAGHuLDRxQNhlEtBSTVIor,FMazfsypbAGHuLDRxQNhlEtBSTVIoq,FMazfsypbAGHuLDRxQNhlEtBSTVIoK)=FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.Load_session_acount()
  if FMazfsypbAGHuLDRxQNhlEtBSTVIoO!=FMazfsypbAGHuLDRxQNhlEtBSTVIor or FMazfsypbAGHuLDRxQNhlEtBSTVIoW!=FMazfsypbAGHuLDRxQNhlEtBSTVIoq or FMazfsypbAGHuLDRxQNhlEtBSTVIoY!=FMazfsypbAGHuLDRxQNhlEtBSTVIoK:
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.Init_WC_Total()
   return FMazfsypbAGHuLDRxQNhlEtBSTVIOv
  if FMazfsypbAGHuLDRxQNhlEtBSTVIoP(FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))>FMazfsypbAGHuLDRxQNhlEtBSTVIoP(FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.WC['account']['token_limit']):
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.Init_WC_Total()
   return FMazfsypbAGHuLDRxQNhlEtBSTVIOv
  return FMazfsypbAGHuLDRxQNhlEtBSTVIOe
 def dp_Global_Search(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVIoc=args.get('mode')
  if FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='TOTAL_SEARCH':
   FMazfsypbAGHuLDRxQNhlEtBSTVIoi='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   FMazfsypbAGHuLDRxQNhlEtBSTVIoi='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FMazfsypbAGHuLDRxQNhlEtBSTVIoi)
 def dp_Bookmark_Menu(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVIoi='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FMazfsypbAGHuLDRxQNhlEtBSTVIoi)
 def dp_Set_Bookmark(FMazfsypbAGHuLDRxQNhlEtBSTVIer,args):
  FMazfsypbAGHuLDRxQNhlEtBSTVIko=urllib.parse.unquote(args.get('bm_param'))
  FMazfsypbAGHuLDRxQNhlEtBSTVIko=json.loads(FMazfsypbAGHuLDRxQNhlEtBSTVIko)
  FMazfsypbAGHuLDRxQNhlEtBSTVIov =FMazfsypbAGHuLDRxQNhlEtBSTVIko.get('videoid')
  FMazfsypbAGHuLDRxQNhlEtBSTVIoJ =FMazfsypbAGHuLDRxQNhlEtBSTVIko.get('vidtype')
  FMazfsypbAGHuLDRxQNhlEtBSTVIod =FMazfsypbAGHuLDRxQNhlEtBSTVIko.get('vtitle')
  FMazfsypbAGHuLDRxQNhlEtBSTVIoC =FMazfsypbAGHuLDRxQNhlEtBSTVIko.get('vsubtitle')
  FMazfsypbAGHuLDRxQNhlEtBSTVIeJ=xbmcgui.Dialog()
  FMazfsypbAGHuLDRxQNhlEtBSTVIvn=FMazfsypbAGHuLDRxQNhlEtBSTVIeJ.yesno(__language__(30913).encode('utf8'),FMazfsypbAGHuLDRxQNhlEtBSTVIod+' \n\n'+__language__(30914))
  if FMazfsypbAGHuLDRxQNhlEtBSTVIvn==FMazfsypbAGHuLDRxQNhlEtBSTVIOv:return
  FMazfsypbAGHuLDRxQNhlEtBSTVIoX=FMazfsypbAGHuLDRxQNhlEtBSTVIer.WatchaObj.GetBookmarkInfo(FMazfsypbAGHuLDRxQNhlEtBSTVIov,FMazfsypbAGHuLDRxQNhlEtBSTVIoJ)
  FMazfsypbAGHuLDRxQNhlEtBSTVIog=json.dumps(FMazfsypbAGHuLDRxQNhlEtBSTVIoX)
  FMazfsypbAGHuLDRxQNhlEtBSTVIog=urllib.parse.quote(FMazfsypbAGHuLDRxQNhlEtBSTVIog)
  FMazfsypbAGHuLDRxQNhlEtBSTVIUd ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(FMazfsypbAGHuLDRxQNhlEtBSTVIog)
  xbmc.executebuiltin(FMazfsypbAGHuLDRxQNhlEtBSTVIUd)
 def watcha_main(FMazfsypbAGHuLDRxQNhlEtBSTVIer):
  FMazfsypbAGHuLDRxQNhlEtBSTVIoc=FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params.get('mode',FMazfsypbAGHuLDRxQNhlEtBSTVIon)
  if FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='LOGOUT':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.logout()
   return
  FMazfsypbAGHuLDRxQNhlEtBSTVIer.login_main()
  if FMazfsypbAGHuLDRxQNhlEtBSTVIoc is FMazfsypbAGHuLDRxQNhlEtBSTVIon:
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_Main_List()
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='HOME_GROUP':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_HomeGroup_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='SUB_GROUP':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_SubGroup_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='CATEGORY_LIST':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_Category_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='EPISODE':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_Episode_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='ORDER_BY':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_setEpOrderby(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc in['SEARCH','LOCAL_SEARCH']:
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_Search_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='MOVIE':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.play_VIDEO(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='WATCH':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_Watch_List(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_History_Remove(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc in['TOTAL_SEARCH','TOTAL_HISTORY']:
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_Global_Search(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='SEARCH_HISTORY':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_Search_History(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='MENU_BOOKMARK':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_Bookmark_Menu(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='SET_BOOKMARK':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_Set_Bookmark(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  elif FMazfsypbAGHuLDRxQNhlEtBSTVIoc=='DELETE_CONTINUE':
   FMazfsypbAGHuLDRxQNhlEtBSTVIer.dp_Delete_Continue(FMazfsypbAGHuLDRxQNhlEtBSTVIer.main_params)
  else:
   FMazfsypbAGHuLDRxQNhlEtBSTVIon
# Created by pyminifier (https://github.com/liftoff/pyminifier)
