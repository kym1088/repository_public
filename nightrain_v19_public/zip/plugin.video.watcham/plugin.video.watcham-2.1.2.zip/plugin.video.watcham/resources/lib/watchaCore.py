__author__="NightRain"
ScAWsoHlgKxuRyvFGhCmwafYIDjpLM=object
ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ=None
ScAWsoHlgKxuRyvFGhCmwafYIDjpLr=False
ScAWsoHlgKxuRyvFGhCmwafYIDjpLV=True
ScAWsoHlgKxuRyvFGhCmwafYIDjpLB=Exception
ScAWsoHlgKxuRyvFGhCmwafYIDjpLO=print
ScAWsoHlgKxuRyvFGhCmwafYIDjpLq=str
ScAWsoHlgKxuRyvFGhCmwafYIDjpLX=len
ScAWsoHlgKxuRyvFGhCmwafYIDjpLT=int
ScAWsoHlgKxuRyvFGhCmwafYIDjpLP=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import base64
import requests
import datetime
class ScAWsoHlgKxuRyvFGhCmwafYIDjpJM(ScAWsoHlgKxuRyvFGhCmwafYIDjpLM):
 def __init__(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_TOKEN ='' 
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUIT =''
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUITV =''
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_USERCD=''
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.MAIN_DOMAIN ='https://watcha.com'
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.API_DOMAIN ='https://api-mars.watcha.com'
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.EPISODE_LIMIT=20
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.SEARCH_LIMIT =30
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.DEFAULT_HEADER={'user-agent':ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,jobtype,ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,payload=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,params=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,cookies=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,redirects=ScAWsoHlgKxuRyvFGhCmwafYIDjpLr):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJL=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.DEFAULT_HEADER
  if headers:ScAWsoHlgKxuRyvFGhCmwafYIDjpJL.update(headers)
  if jobtype=='Get':
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJr=requests.get(ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,params=params,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpJL,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJr=requests.put(ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,data=payload,params=params,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpJL,cookies=cookies,allow_redirects=redirects)
  else:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJr=requests.post(ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,data=payload,params=params,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpJL,cookies=cookies,allow_redirects=redirects)
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpJr
 def SaveCredential(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,ScAWsoHlgKxuRyvFGhCmwafYIDjpJV):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_TOKEN =ScAWsoHlgKxuRyvFGhCmwafYIDjpJV.get('watcha_token')
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUIT =ScAWsoHlgKxuRyvFGhCmwafYIDjpJV.get('watcha_guit')
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUITV =ScAWsoHlgKxuRyvFGhCmwafYIDjpJV.get('watcha_guitv')
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_USERCD =ScAWsoHlgKxuRyvFGhCmwafYIDjpJV.get('watcha_usercd')
 def SaveCredential_usercd(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,ScAWsoHlgKxuRyvFGhCmwafYIDjpJB):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_USERCD=ScAWsoHlgKxuRyvFGhCmwafYIDjpJB
 def SaveCredential_guitv(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,ScAWsoHlgKxuRyvFGhCmwafYIDjpJO,ScAWsoHlgKxuRyvFGhCmwafYIDjpJq):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUITV=ScAWsoHlgKxuRyvFGhCmwafYIDjpJO
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_TOKEN=ScAWsoHlgKxuRyvFGhCmwafYIDjpJq 
 def ClearCredential(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_TOKEN ='' 
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUIT =''
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUITV =''
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_USERCD=''
 def LoadCredential(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJV={'watcha_token':ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_TOKEN,'watcha_guit':ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUIT,'watcha_guitv':ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUITV,'watcha_usercd':ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_USERCD}
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpJV
 def makeDefaultCookies(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJX={'_s_guit':ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUIT,'_guinness-premium_session':ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_TOKEN}
  if ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUITV:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJX['_s_guitv']=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_GUITV
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpJX
 def makeurl(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,domain,path,query1=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,query2=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJT=domain+path
  if query1:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJT+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJT+='&%s'%urllib.parse.urlencode(query2)
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpJT
 def GetCredential(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,user_id,user_pw,user_pf):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJz=ScAWsoHlgKxuRyvFGhCmwafYIDjpLr
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJk=ScAWsoHlgKxuRyvFGhCmwafYIDjpJi='-'
  try:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJE=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.API_DOMAIN+'/api/session'
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJN={'email':user_id,'password':user_pw}
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJt={'accept':'application/vnd.frograms+json;version=4'}
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJe=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.callRequestCookies('Post',ScAWsoHlgKxuRyvFGhCmwafYIDjpJE,payload=ScAWsoHlgKxuRyvFGhCmwafYIDjpJN,params=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpJt,cookies=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ)
   for ScAWsoHlgKxuRyvFGhCmwafYIDjpJn in ScAWsoHlgKxuRyvFGhCmwafYIDjpJe.cookies:
    if ScAWsoHlgKxuRyvFGhCmwafYIDjpJn.name=='_guinness-premium_session':
     ScAWsoHlgKxuRyvFGhCmwafYIDjpJi=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn.value
    elif ScAWsoHlgKxuRyvFGhCmwafYIDjpJn.name=='_s_guit':
     ScAWsoHlgKxuRyvFGhCmwafYIDjpJk=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn.value
   if ScAWsoHlgKxuRyvFGhCmwafYIDjpJi:ScAWsoHlgKxuRyvFGhCmwafYIDjpJz=ScAWsoHlgKxuRyvFGhCmwafYIDjpLV
  except ScAWsoHlgKxuRyvFGhCmwafYIDjpLB as exception:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpLO(exception)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJk=ScAWsoHlgKxuRyvFGhCmwafYIDjpJi='' 
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJV={'watcha_guit':ScAWsoHlgKxuRyvFGhCmwafYIDjpJk,'watcha_token':ScAWsoHlgKxuRyvFGhCmwafYIDjpJi,'watcha_guitv':'','watcha_usercd':''}
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.SaveCredential(ScAWsoHlgKxuRyvFGhCmwafYIDjpJV)
  try:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJd=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.GetProfilesList()
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJU =ScAWsoHlgKxuRyvFGhCmwafYIDjpJd[user_pf]
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.SaveCredential_usercd(ScAWsoHlgKxuRyvFGhCmwafYIDjpJU)
  except ScAWsoHlgKxuRyvFGhCmwafYIDjpLB as exception:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpLO(exception)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.ClearCredential()
   return ScAWsoHlgKxuRyvFGhCmwafYIDjpLr
  if user_pf!=0:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJO,ScAWsoHlgKxuRyvFGhCmwafYIDjpJq=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.GetProfilesConvert(ScAWsoHlgKxuRyvFGhCmwafYIDjpJU)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.SaveCredential_guitv(ScAWsoHlgKxuRyvFGhCmwafYIDjpJO,ScAWsoHlgKxuRyvFGhCmwafYIDjpJq)
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpJz
 def GetSubGroupList(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,stype):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ=[]
  try:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ ='/api/categories.json'
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJT=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeurl(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.API_DOMAIN,ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJn=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeDefaultCookies()
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJe=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.callRequestCookies('Get',ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,payload=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,params=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,cookies=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpML=json.loads(ScAWsoHlgKxuRyvFGhCmwafYIDjpJe.text)
   if not('genres' in ScAWsoHlgKxuRyvFGhCmwafYIDjpML):return ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ
   if stype=='genres':
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMr=ScAWsoHlgKxuRyvFGhCmwafYIDjpML['genres']
   else:
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMr=ScAWsoHlgKxuRyvFGhCmwafYIDjpML['tags']
   for ScAWsoHlgKxuRyvFGhCmwafYIDjpMV in ScAWsoHlgKxuRyvFGhCmwafYIDjpMr:
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMB=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['name']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMO =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['api_path']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMq =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['entity']['id']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMX={'group_name':ScAWsoHlgKxuRyvFGhCmwafYIDjpMB,'api_path':ScAWsoHlgKxuRyvFGhCmwafYIDjpMO,'tag_id':ScAWsoHlgKxuRyvFGhCmwafYIDjpLq(ScAWsoHlgKxuRyvFGhCmwafYIDjpMq)}
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ.append(ScAWsoHlgKxuRyvFGhCmwafYIDjpMX)
  except ScAWsoHlgKxuRyvFGhCmwafYIDjpLB as exception:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpLO(exception)
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ
 def GetCategoryList(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,stype,ScAWsoHlgKxuRyvFGhCmwafYIDjpMq,ScAWsoHlgKxuRyvFGhCmwafYIDjpMO,page_int,in_sort):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ=[]
  ScAWsoHlgKxuRyvFGhCmwafYIDjpMT=ScAWsoHlgKxuRyvFGhCmwafYIDjpLr
  ScAWsoHlgKxuRyvFGhCmwafYIDjpMP={}
  try:
   if 'categories' in ScAWsoHlgKxuRyvFGhCmwafYIDjpMO:
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ ='/api/categories/contents.json'
    if stype=='genres':
     ScAWsoHlgKxuRyvFGhCmwafYIDjpMP['genre']=ScAWsoHlgKxuRyvFGhCmwafYIDjpMq
    else:
     ScAWsoHlgKxuRyvFGhCmwafYIDjpMP['tag'] =ScAWsoHlgKxuRyvFGhCmwafYIDjpMq
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMP['order']=in_sort 
    if page_int>1:
     ScAWsoHlgKxuRyvFGhCmwafYIDjpMP['page']=ScAWsoHlgKxuRyvFGhCmwafYIDjpLq(page_int-1)
   else: 
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ ='/api/'+ScAWsoHlgKxuRyvFGhCmwafYIDjpMO+'.json'
    if page_int>1:
     ScAWsoHlgKxuRyvFGhCmwafYIDjpMP['page']=ScAWsoHlgKxuRyvFGhCmwafYIDjpLq(page_int)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJT=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeurl(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.API_DOMAIN,ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJn=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeDefaultCookies()
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJe=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.callRequestCookies('Get',ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,payload=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,params=ScAWsoHlgKxuRyvFGhCmwafYIDjpMP,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,cookies=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpML=json.loads(ScAWsoHlgKxuRyvFGhCmwafYIDjpJe.text)
   if not('contents' in ScAWsoHlgKxuRyvFGhCmwafYIDjpML):return ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ,ScAWsoHlgKxuRyvFGhCmwafYIDjpMT
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMr=ScAWsoHlgKxuRyvFGhCmwafYIDjpML['contents']
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMT=ScAWsoHlgKxuRyvFGhCmwafYIDjpML['meta']['has_next']
   for ScAWsoHlgKxuRyvFGhCmwafYIDjpMV in ScAWsoHlgKxuRyvFGhCmwafYIDjpMr:
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMb =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['code']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMz=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['content_type']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMk =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['title']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpME =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['story']
    if ScAWsoHlgKxuRyvFGhCmwafYIDjpMV.get('poster') !=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ:ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['poster']['medium']
    elif ScAWsoHlgKxuRyvFGhCmwafYIDjpMV.get('thumbnail')!=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ:ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['thumbnail']['medium']
    elif ScAWsoHlgKxuRyvFGhCmwafYIDjpMV.get('stillcut')!=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ:ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['stillcut']['medium']
    else: ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=''
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMt =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['year']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMe =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['film_rating_code']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMn=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['film_rating_short']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMi =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['film_rating_long']
    if ScAWsoHlgKxuRyvFGhCmwafYIDjpMz=='movies':
     ScAWsoHlgKxuRyvFGhCmwafYIDjpMd =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['duration']
    else:
     ScAWsoHlgKxuRyvFGhCmwafYIDjpMd ='0'
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMX={'code':ScAWsoHlgKxuRyvFGhCmwafYIDjpMb,'content_type':ScAWsoHlgKxuRyvFGhCmwafYIDjpMz,'title':ScAWsoHlgKxuRyvFGhCmwafYIDjpMk,'story':ScAWsoHlgKxuRyvFGhCmwafYIDjpME,'thumbnail':ScAWsoHlgKxuRyvFGhCmwafYIDjpMN,'year':ScAWsoHlgKxuRyvFGhCmwafYIDjpMt,'film_rating_code':ScAWsoHlgKxuRyvFGhCmwafYIDjpMe,'film_rating_short':ScAWsoHlgKxuRyvFGhCmwafYIDjpMn,'film_rating_long':ScAWsoHlgKxuRyvFGhCmwafYIDjpMi,'duration':ScAWsoHlgKxuRyvFGhCmwafYIDjpMd}
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ.append(ScAWsoHlgKxuRyvFGhCmwafYIDjpMX)
  except ScAWsoHlgKxuRyvFGhCmwafYIDjpLB as exception:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpLO(exception)
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ,ScAWsoHlgKxuRyvFGhCmwafYIDjpMT
 def GetCategoryList_morepage(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,stype,ScAWsoHlgKxuRyvFGhCmwafYIDjpMq,ScAWsoHlgKxuRyvFGhCmwafYIDjpMO,page_int,in_sort):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpMT=ScAWsoHlgKxuRyvFGhCmwafYIDjpLr
  if not('categories' in ScAWsoHlgKxuRyvFGhCmwafYIDjpMO):return ScAWsoHlgKxuRyvFGhCmwafYIDjpLV
  try:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ ='/api/categories/contents.json'
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMP={}
   if stype=='genres':
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMP['genre']=ScAWsoHlgKxuRyvFGhCmwafYIDjpMq
   else:
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMP['tag'] =ScAWsoHlgKxuRyvFGhCmwafYIDjpMq
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMP['order']=in_sort 
   if page_int>1:
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMP['page']=ScAWsoHlgKxuRyvFGhCmwafYIDjpLq(page_int-1)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJT=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeurl(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.API_DOMAIN,ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJn=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeDefaultCookies()
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJe=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.callRequestCookies('Get',ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,payload=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,params=ScAWsoHlgKxuRyvFGhCmwafYIDjpMP,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,cookies=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpML=json.loads(ScAWsoHlgKxuRyvFGhCmwafYIDjpJe.text)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMT=ScAWsoHlgKxuRyvFGhCmwafYIDjpML['meta']['has_next']
  except ScAWsoHlgKxuRyvFGhCmwafYIDjpLB as exception:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpLO(exception)
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpMT
 def GetEpisodoList(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,program_code,page_int,orderby='asc'):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ=[]
  ScAWsoHlgKxuRyvFGhCmwafYIDjpMT=ScAWsoHlgKxuRyvFGhCmwafYIDjpLr
  ScAWsoHlgKxuRyvFGhCmwafYIDjpMU=''
  try:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ ='/api/contents/'+program_code+'/tv_episodes.json'
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMP={'all':'true'}
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJT=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeurl(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.API_DOMAIN,ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJn=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeDefaultCookies()
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJe=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.callRequestCookies('Get',ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,payload=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,params=ScAWsoHlgKxuRyvFGhCmwafYIDjpMP,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,cookies=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpML=json.loads(ScAWsoHlgKxuRyvFGhCmwafYIDjpJe.text)
   if not('tv_episode_codes' in ScAWsoHlgKxuRyvFGhCmwafYIDjpML):return ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ,ScAWsoHlgKxuRyvFGhCmwafYIDjpMT
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMr=ScAWsoHlgKxuRyvFGhCmwafYIDjpML['tv_episode_codes']
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQJ=ScAWsoHlgKxuRyvFGhCmwafYIDjpLX(ScAWsoHlgKxuRyvFGhCmwafYIDjpMr)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQM =ScAWsoHlgKxuRyvFGhCmwafYIDjpLT(ScAWsoHlgKxuRyvFGhCmwafYIDjpQJ//(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    ScAWsoHlgKxuRyvFGhCmwafYIDjpQL =(ScAWsoHlgKxuRyvFGhCmwafYIDjpQJ-1)-((page_int-1)*ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.EPISODE_LIMIT)
   else:
    ScAWsoHlgKxuRyvFGhCmwafYIDjpQL =(page_int-1)*ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.EPISODE_LIMIT
   for i in ScAWsoHlgKxuRyvFGhCmwafYIDjpLP(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.EPISODE_LIMIT):
    if orderby=='desc':
     ScAWsoHlgKxuRyvFGhCmwafYIDjpQr=ScAWsoHlgKxuRyvFGhCmwafYIDjpQL-i
     if ScAWsoHlgKxuRyvFGhCmwafYIDjpQr<0:break
    else:
     ScAWsoHlgKxuRyvFGhCmwafYIDjpQr=ScAWsoHlgKxuRyvFGhCmwafYIDjpQL+i
     if ScAWsoHlgKxuRyvFGhCmwafYIDjpQr>=ScAWsoHlgKxuRyvFGhCmwafYIDjpQJ:break
    if ScAWsoHlgKxuRyvFGhCmwafYIDjpMU!='':ScAWsoHlgKxuRyvFGhCmwafYIDjpMU+=','
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMU+=ScAWsoHlgKxuRyvFGhCmwafYIDjpMr[ScAWsoHlgKxuRyvFGhCmwafYIDjpQr]
   if ScAWsoHlgKxuRyvFGhCmwafYIDjpQM>page_int:ScAWsoHlgKxuRyvFGhCmwafYIDjpMT=ScAWsoHlgKxuRyvFGhCmwafYIDjpLV
  except ScAWsoHlgKxuRyvFGhCmwafYIDjpLB as exception:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpLO(exception)
  try:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMP={'codes':ScAWsoHlgKxuRyvFGhCmwafYIDjpMU}
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJT=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeurl(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.API_DOMAIN,ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJn=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeDefaultCookies()
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJe=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.callRequestCookies('Get',ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,payload=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,params=ScAWsoHlgKxuRyvFGhCmwafYIDjpMP,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,cookies=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpML=json.loads(ScAWsoHlgKxuRyvFGhCmwafYIDjpJe.text)
   if not('tv_episodes' in ScAWsoHlgKxuRyvFGhCmwafYIDjpML):return ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMr=ScAWsoHlgKxuRyvFGhCmwafYIDjpML['tv_episodes']
   for ScAWsoHlgKxuRyvFGhCmwafYIDjpMV in ScAWsoHlgKxuRyvFGhCmwafYIDjpMr:
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMb =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['code']
    if ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['title']:
     ScAWsoHlgKxuRyvFGhCmwafYIDjpMk =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['title']
    else:
     ScAWsoHlgKxuRyvFGhCmwafYIDjpMk =''
    if ScAWsoHlgKxuRyvFGhCmwafYIDjpMV.get('poster') !=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ:ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['poster']['medium']
    elif ScAWsoHlgKxuRyvFGhCmwafYIDjpMV.get('thumbnail')!=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ:ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['thumbnail']['medium']
    elif ScAWsoHlgKxuRyvFGhCmwafYIDjpMV.get('stillcut')!=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ:ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['stillcut']['medium']
    else: ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=''
    ScAWsoHlgKxuRyvFGhCmwafYIDjpQV =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['display_number']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpQB=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['tv_season_title']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMd =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['duration']
    try:
     ScAWsoHlgKxuRyvFGhCmwafYIDjpQO=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['episode_number']
    except:
     ScAWsoHlgKxuRyvFGhCmwafYIDjpQO='0'
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMX={'code':ScAWsoHlgKxuRyvFGhCmwafYIDjpMb,'title':ScAWsoHlgKxuRyvFGhCmwafYIDjpMk,'thumbnail':ScAWsoHlgKxuRyvFGhCmwafYIDjpMN,'display_num':ScAWsoHlgKxuRyvFGhCmwafYIDjpQV,'season_title':ScAWsoHlgKxuRyvFGhCmwafYIDjpQB,'duration':ScAWsoHlgKxuRyvFGhCmwafYIDjpMd,'episode_number':ScAWsoHlgKxuRyvFGhCmwafYIDjpQO}
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ.append(ScAWsoHlgKxuRyvFGhCmwafYIDjpMX)
  except ScAWsoHlgKxuRyvFGhCmwafYIDjpLB as exception:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpLO(exception)
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpMJ,ScAWsoHlgKxuRyvFGhCmwafYIDjpMT
 def GetSearchList(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,search_key,page_int):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpQq=[]
  ScAWsoHlgKxuRyvFGhCmwafYIDjpMT=ScAWsoHlgKxuRyvFGhCmwafYIDjpLr
  try:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ ='/api/search.json'
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMP={'query':search_key,'page':ScAWsoHlgKxuRyvFGhCmwafYIDjpLq(page_int),'per':ScAWsoHlgKxuRyvFGhCmwafYIDjpLq(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.SEARCH_LIMIT),'exclude':'limited'}
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJT=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeurl(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.API_DOMAIN,ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJn=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeDefaultCookies()
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJe=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.callRequestCookies('Get',ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,payload=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,params=ScAWsoHlgKxuRyvFGhCmwafYIDjpMP,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,cookies=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpML=json.loads(ScAWsoHlgKxuRyvFGhCmwafYIDjpJe.text)
   if not('results' in ScAWsoHlgKxuRyvFGhCmwafYIDjpML):return ScAWsoHlgKxuRyvFGhCmwafYIDjpQq,ScAWsoHlgKxuRyvFGhCmwafYIDjpMT
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMr=ScAWsoHlgKxuRyvFGhCmwafYIDjpML['results']
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMT=ScAWsoHlgKxuRyvFGhCmwafYIDjpML['meta']['has_next']
   for ScAWsoHlgKxuRyvFGhCmwafYIDjpMV in ScAWsoHlgKxuRyvFGhCmwafYIDjpMr:
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMb =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['code']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMz=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['content_type']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMk =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['title']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpME =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['story']
    if ScAWsoHlgKxuRyvFGhCmwafYIDjpMV.get('poster') !=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ:ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['poster']['medium']
    elif ScAWsoHlgKxuRyvFGhCmwafYIDjpMV.get('thumbnail')!=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ:ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['thumbnail']['medium']
    elif ScAWsoHlgKxuRyvFGhCmwafYIDjpMV.get('stillcut')!=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ:ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['stillcut']['medium']
    else: ScAWsoHlgKxuRyvFGhCmwafYIDjpMN=''
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMt =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['year']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMe =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['film_rating_code']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMn=ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['film_rating_short']
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMi =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['film_rating_long']
    if ScAWsoHlgKxuRyvFGhCmwafYIDjpMz=='movies':
     ScAWsoHlgKxuRyvFGhCmwafYIDjpMd =ScAWsoHlgKxuRyvFGhCmwafYIDjpMV['duration']
    else:
     ScAWsoHlgKxuRyvFGhCmwafYIDjpMd ='0'
    ScAWsoHlgKxuRyvFGhCmwafYIDjpMX={'code':ScAWsoHlgKxuRyvFGhCmwafYIDjpMb,'content_type':ScAWsoHlgKxuRyvFGhCmwafYIDjpMz,'title':ScAWsoHlgKxuRyvFGhCmwafYIDjpMk,'story':ScAWsoHlgKxuRyvFGhCmwafYIDjpME,'thumbnail':ScAWsoHlgKxuRyvFGhCmwafYIDjpMN,'year':ScAWsoHlgKxuRyvFGhCmwafYIDjpMt,'film_rating_code':ScAWsoHlgKxuRyvFGhCmwafYIDjpMe,'film_rating_short':ScAWsoHlgKxuRyvFGhCmwafYIDjpMn,'film_rating_long':ScAWsoHlgKxuRyvFGhCmwafYIDjpMi,'duration':ScAWsoHlgKxuRyvFGhCmwafYIDjpMd}
    ScAWsoHlgKxuRyvFGhCmwafYIDjpQq.append(ScAWsoHlgKxuRyvFGhCmwafYIDjpMX)
  except ScAWsoHlgKxuRyvFGhCmwafYIDjpLB as exception:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpLO(exception)
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpQq,ScAWsoHlgKxuRyvFGhCmwafYIDjpMT
 def GetProfilesList(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpJd=[]
  try:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ ='/manage_profiles'
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJT=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeurl(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.MAIN_DOMAIN,ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJn=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeDefaultCookies()
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJe=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.callRequestCookies('Get',ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,payload=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,params=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,cookies=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn,redirects=ScAWsoHlgKxuRyvFGhCmwafYIDjpLV)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQX=ScAWsoHlgKxuRyvFGhCmwafYIDjpJe.text
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQT =re.findall('/api/users/me.{5000}',ScAWsoHlgKxuRyvFGhCmwafYIDjpQX)[0]
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQT =ScAWsoHlgKxuRyvFGhCmwafYIDjpQT.replace('&quot;','')
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJd=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',ScAWsoHlgKxuRyvFGhCmwafYIDjpQT)
   for i in ScAWsoHlgKxuRyvFGhCmwafYIDjpLP(ScAWsoHlgKxuRyvFGhCmwafYIDjpLX(ScAWsoHlgKxuRyvFGhCmwafYIDjpJd)):
    ScAWsoHlgKxuRyvFGhCmwafYIDjpQP=ScAWsoHlgKxuRyvFGhCmwafYIDjpJd[i]
    ScAWsoHlgKxuRyvFGhCmwafYIDjpQP =ScAWsoHlgKxuRyvFGhCmwafYIDjpQP.split(':')[1]
    ScAWsoHlgKxuRyvFGhCmwafYIDjpJd[i]=ScAWsoHlgKxuRyvFGhCmwafYIDjpQP.split(',')[0]
  except ScAWsoHlgKxuRyvFGhCmwafYIDjpLB as exception:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpLO(exception)
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpJd
 def GetProfilesConvert(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,ScAWsoHlgKxuRyvFGhCmwafYIDjpJB):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpQb=''
  ScAWsoHlgKxuRyvFGhCmwafYIDjpQz=''
  try:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ ='/api/users/'+ScAWsoHlgKxuRyvFGhCmwafYIDjpJB+'/convert'
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJT=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeurl(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.API_DOMAIN,ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJn=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeDefaultCookies()
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJe=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.callRequestCookies('Put',ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,payload=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,params=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,cookies=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn)
   for ScAWsoHlgKxuRyvFGhCmwafYIDjpJn in ScAWsoHlgKxuRyvFGhCmwafYIDjpJe.cookies:
    if ScAWsoHlgKxuRyvFGhCmwafYIDjpJn.name=='_s_guitv':
     ScAWsoHlgKxuRyvFGhCmwafYIDjpQk=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn.value
    elif ScAWsoHlgKxuRyvFGhCmwafYIDjpJn.name=='_guinness-premium_session':
     ScAWsoHlgKxuRyvFGhCmwafYIDjpJi=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn.value
   if ScAWsoHlgKxuRyvFGhCmwafYIDjpQk:
    ScAWsoHlgKxuRyvFGhCmwafYIDjpQb=ScAWsoHlgKxuRyvFGhCmwafYIDjpQk
   if ScAWsoHlgKxuRyvFGhCmwafYIDjpJi:
    ScAWsoHlgKxuRyvFGhCmwafYIDjpQz=ScAWsoHlgKxuRyvFGhCmwafYIDjpJi
  except ScAWsoHlgKxuRyvFGhCmwafYIDjpLB as exception:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQb=''
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQz=''
  return ScAWsoHlgKxuRyvFGhCmwafYIDjpQb,ScAWsoHlgKxuRyvFGhCmwafYIDjpQz
 def Get_Now_Datetime(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ,movie_code,quality_str):
  ScAWsoHlgKxuRyvFGhCmwafYIDjpQN=ScAWsoHlgKxuRyvFGhCmwafYIDjpQe=ScAWsoHlgKxuRyvFGhCmwafYIDjpLJ=''
  try:
   ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ='/api/watch/'+movie_code+'.json'
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJT=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeurl(ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.API_DOMAIN,ScAWsoHlgKxuRyvFGhCmwafYIDjpMQ)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJt={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJn=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.makeDefaultCookies()
   ScAWsoHlgKxuRyvFGhCmwafYIDjpJe=ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.callRequestCookies('Get',ScAWsoHlgKxuRyvFGhCmwafYIDjpJT,payload=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,params=ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ,headers=ScAWsoHlgKxuRyvFGhCmwafYIDjpJt,cookies=ScAWsoHlgKxuRyvFGhCmwafYIDjpJn)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpML=json.loads(ScAWsoHlgKxuRyvFGhCmwafYIDjpJe.text)
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQN=ScAWsoHlgKxuRyvFGhCmwafYIDjpML['streams'][0]['source']
   if ScAWsoHlgKxuRyvFGhCmwafYIDjpQN==ScAWsoHlgKxuRyvFGhCmwafYIDjpLQ:return(ScAWsoHlgKxuRyvFGhCmwafYIDjpQN,ScAWsoHlgKxuRyvFGhCmwafYIDjpQe,ScAWsoHlgKxuRyvFGhCmwafYIDjpLJ)
   if 'subtitles' in ScAWsoHlgKxuRyvFGhCmwafYIDjpML['streams'][0]:
    for ScAWsoHlgKxuRyvFGhCmwafYIDjpQt in ScAWsoHlgKxuRyvFGhCmwafYIDjpML['streams'][0]['subtitles']:
     if ScAWsoHlgKxuRyvFGhCmwafYIDjpQt['lang']=='ko':
      ScAWsoHlgKxuRyvFGhCmwafYIDjpQe=ScAWsoHlgKxuRyvFGhCmwafYIDjpQt['url']
      break
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQn =ScAWsoHlgKxuRyvFGhCmwafYIDjpML['ping_payload']
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQi =ScAWsoHlgKxuRyvFGhCmwafYIDjpJQ.WATCHA_USERCD
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQd={'merchant':'giitd_frograms','sessionId':ScAWsoHlgKxuRyvFGhCmwafYIDjpQn,'userId':ScAWsoHlgKxuRyvFGhCmwafYIDjpQi}
   ScAWsoHlgKxuRyvFGhCmwafYIDjpQU=json.dumps(ScAWsoHlgKxuRyvFGhCmwafYIDjpQd,separators=(",",":")).encode('UTF-8')
   ScAWsoHlgKxuRyvFGhCmwafYIDjpLJ=base64.b64encode(ScAWsoHlgKxuRyvFGhCmwafYIDjpQU)
  except ScAWsoHlgKxuRyvFGhCmwafYIDjpLB as exception:
   return(ScAWsoHlgKxuRyvFGhCmwafYIDjpQN,ScAWsoHlgKxuRyvFGhCmwafYIDjpQe,ScAWsoHlgKxuRyvFGhCmwafYIDjpLJ)
  return(ScAWsoHlgKxuRyvFGhCmwafYIDjpQN,ScAWsoHlgKxuRyvFGhCmwafYIDjpQe,ScAWsoHlgKxuRyvFGhCmwafYIDjpLJ) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
