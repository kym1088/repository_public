__author__="NightRain"
ahNKPeMbQpszvXiOjxofHVlSTEdAyG=object
ahNKPeMbQpszvXiOjxofHVlSTEdAyB=None
ahNKPeMbQpszvXiOjxofHVlSTEdAym=int
ahNKPeMbQpszvXiOjxofHVlSTEdAyJ=False
ahNKPeMbQpszvXiOjxofHVlSTEdAyD=True
ahNKPeMbQpszvXiOjxofHVlSTEdAyw=len
ahNKPeMbQpszvXiOjxofHVlSTEdAyF=range
ahNKPeMbQpszvXiOjxofHVlSTEdAyr=str
ahNKPeMbQpszvXiOjxofHVlSTEdAyI=open
ahNKPeMbQpszvXiOjxofHVlSTEdAyk=dict
ahNKPeMbQpszvXiOjxofHVlSTEdAyt=Exception
ahNKPeMbQpszvXiOjxofHVlSTEdAyR=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
ahNKPeMbQpszvXiOjxofHVlSTEdAGm=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'검색 (search)','mode':'SEARCH','stype':'-','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-'}]
ahNKPeMbQpszvXiOjxofHVlSTEdAGJ=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
ahNKPeMbQpszvXiOjxofHVlSTEdAGD=40
ahNKPeMbQpszvXiOjxofHVlSTEdAGy =20
ahNKPeMbQpszvXiOjxofHVlSTEdAGw =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
ahNKPeMbQpszvXiOjxofHVlSTEdAGF=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class ahNKPeMbQpszvXiOjxofHVlSTEdAGB(ahNKPeMbQpszvXiOjxofHVlSTEdAyG):
 def __init__(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,ahNKPeMbQpszvXiOjxofHVlSTEdAGI,ahNKPeMbQpszvXiOjxofHVlSTEdAGk,ahNKPeMbQpszvXiOjxofHVlSTEdAGt):
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_url =ahNKPeMbQpszvXiOjxofHVlSTEdAGI
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_handle=ahNKPeMbQpszvXiOjxofHVlSTEdAGk
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.main_params =ahNKPeMbQpszvXiOjxofHVlSTEdAGt
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj =ScAWsoHlgKxuRyvFGhCmwafYIDjpJM() 
 def addon_noti(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,sting):
  try:
   ahNKPeMbQpszvXiOjxofHVlSTEdAGY=xbmcgui.Dialog()
   ahNKPeMbQpszvXiOjxofHVlSTEdAGY.notification(__addonname__,sting)
  except:
   ahNKPeMbQpszvXiOjxofHVlSTEdAyB
 def addon_log(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,string):
  try:
   ahNKPeMbQpszvXiOjxofHVlSTEdAGW=string.encode('utf-8','ignore')
  except:
   ahNKPeMbQpszvXiOjxofHVlSTEdAGW='addonException: addon_log'
  ahNKPeMbQpszvXiOjxofHVlSTEdAGg=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,ahNKPeMbQpszvXiOjxofHVlSTEdAGW),level=ahNKPeMbQpszvXiOjxofHVlSTEdAGg)
 def get_keyboard_input(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,ahNKPeMbQpszvXiOjxofHVlSTEdABy):
  ahNKPeMbQpszvXiOjxofHVlSTEdAGc=ahNKPeMbQpszvXiOjxofHVlSTEdAyB
  kb=xbmc.Keyboard()
  kb.setHeading(ahNKPeMbQpszvXiOjxofHVlSTEdABy)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   ahNKPeMbQpszvXiOjxofHVlSTEdAGc=kb.getText()
  return ahNKPeMbQpszvXiOjxofHVlSTEdAGc
 def get_settings_login_info(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  ahNKPeMbQpszvXiOjxofHVlSTEdAGC =__addon__.getSetting('id')
  ahNKPeMbQpszvXiOjxofHVlSTEdAGq =__addon__.getSetting('pw')
  ahNKPeMbQpszvXiOjxofHVlSTEdAGU=ahNKPeMbQpszvXiOjxofHVlSTEdAym(__addon__.getSetting('selected_profile'))
  return(ahNKPeMbQpszvXiOjxofHVlSTEdAGC,ahNKPeMbQpszvXiOjxofHVlSTEdAGq,ahNKPeMbQpszvXiOjxofHVlSTEdAGU)
 def get_selQuality(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  try:
   ahNKPeMbQpszvXiOjxofHVlSTEdAGu=['3840x2160/1','1920x1080/1','1280x720/1']
   ahNKPeMbQpszvXiOjxofHVlSTEdAGL=ahNKPeMbQpszvXiOjxofHVlSTEdAym(__addon__.getSetting('selected_quality'))
   return ahNKPeMbQpszvXiOjxofHVlSTEdAGu[ahNKPeMbQpszvXiOjxofHVlSTEdAGL]
  except:
   ahNKPeMbQpszvXiOjxofHVlSTEdAyB
  return 1080 
 def get_settings_direct_replay(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  ahNKPeMbQpszvXiOjxofHVlSTEdAGn=ahNKPeMbQpszvXiOjxofHVlSTEdAym(__addon__.getSetting('direct_replay'))
  if ahNKPeMbQpszvXiOjxofHVlSTEdAGn==0:
   return ahNKPeMbQpszvXiOjxofHVlSTEdAyJ
  else:
   return ahNKPeMbQpszvXiOjxofHVlSTEdAyD
 def set_winCredential(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,credential):
  ahNKPeMbQpszvXiOjxofHVlSTEdABG=xbmcgui.Window(10000)
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_LOGINTIME',ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  ahNKPeMbQpszvXiOjxofHVlSTEdABG=xbmcgui.Window(10000)
  ahNKPeMbQpszvXiOjxofHVlSTEdABm={'watcha_token':ahNKPeMbQpszvXiOjxofHVlSTEdABG.getProperty('WATCHA_M_TOKEN'),'watcha_guit':ahNKPeMbQpszvXiOjxofHVlSTEdABG.getProperty('WATCHA_M_GUIT'),'watcha_guitv':ahNKPeMbQpszvXiOjxofHVlSTEdABG.getProperty('WATCHA_M_GUITV'),'watcha_usercd':ahNKPeMbQpszvXiOjxofHVlSTEdABG.getProperty('WATCHA_M_USERCD')}
  return ahNKPeMbQpszvXiOjxofHVlSTEdABm
 def set_winEpisodeOrderby(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,ahNKPeMbQpszvXiOjxofHVlSTEdABJ):
  ahNKPeMbQpszvXiOjxofHVlSTEdABG=xbmcgui.Window(10000)
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_ORDERBY',ahNKPeMbQpszvXiOjxofHVlSTEdABJ)
 def get_winEpisodeOrderby(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  ahNKPeMbQpszvXiOjxofHVlSTEdABG=xbmcgui.Window(10000)
  return ahNKPeMbQpszvXiOjxofHVlSTEdABG.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,args):
  ahNKPeMbQpszvXiOjxofHVlSTEdABJ =args.get('orderby')
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.set_winEpisodeOrderby(ahNKPeMbQpszvXiOjxofHVlSTEdABJ)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,label,sublabel='',img='',infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAyB,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdAyD,params=''):
  ahNKPeMbQpszvXiOjxofHVlSTEdABD='%s?%s'%(ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_url,urllib.parse.urlencode(params))
  if sublabel:ahNKPeMbQpszvXiOjxofHVlSTEdABy='%s < %s >'%(label,sublabel)
  else: ahNKPeMbQpszvXiOjxofHVlSTEdABy=label
  if not img:img='DefaultFolder.png'
  ahNKPeMbQpszvXiOjxofHVlSTEdABw=xbmcgui.ListItem(ahNKPeMbQpszvXiOjxofHVlSTEdABy)
  ahNKPeMbQpszvXiOjxofHVlSTEdABw.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:ahNKPeMbQpszvXiOjxofHVlSTEdABw.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:ahNKPeMbQpszvXiOjxofHVlSTEdABw.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_handle,ahNKPeMbQpszvXiOjxofHVlSTEdABD,ahNKPeMbQpszvXiOjxofHVlSTEdABw,isFolder)
 def dp_Main_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  for ahNKPeMbQpszvXiOjxofHVlSTEdABF in ahNKPeMbQpszvXiOjxofHVlSTEdAGm:
   ahNKPeMbQpszvXiOjxofHVlSTEdABy=ahNKPeMbQpszvXiOjxofHVlSTEdABF.get('title')
   ahNKPeMbQpszvXiOjxofHVlSTEdABr={'mode':ahNKPeMbQpszvXiOjxofHVlSTEdABF.get('mode'),'stype':ahNKPeMbQpszvXiOjxofHVlSTEdABF.get('stype'),'api_path':ahNKPeMbQpszvXiOjxofHVlSTEdABF.get('api_path'),'page':'1','sort':ahNKPeMbQpszvXiOjxofHVlSTEdABF.get('sort'),'tag_id':'-'}
   if ahNKPeMbQpszvXiOjxofHVlSTEdABF.get('mode')=='XXX':
    ahNKPeMbQpszvXiOjxofHVlSTEdABr['mode']='XXX'
    ahNKPeMbQpszvXiOjxofHVlSTEdABI=ahNKPeMbQpszvXiOjxofHVlSTEdAyJ
   else:
    ahNKPeMbQpszvXiOjxofHVlSTEdABI=ahNKPeMbQpszvXiOjxofHVlSTEdAyD
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel='',img='',infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAyB,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdABI,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAyw(ahNKPeMbQpszvXiOjxofHVlSTEdAGm)>0:xbmcplugin.endOfDirectory(ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_handle)
 def login_main(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  (ahNKPeMbQpszvXiOjxofHVlSTEdABt,ahNKPeMbQpszvXiOjxofHVlSTEdABR,ahNKPeMbQpszvXiOjxofHVlSTEdABY)=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_settings_login_info()
  if not(ahNKPeMbQpszvXiOjxofHVlSTEdABt and ahNKPeMbQpszvXiOjxofHVlSTEdABR):
   ahNKPeMbQpszvXiOjxofHVlSTEdAGY=xbmcgui.Dialog()
   ahNKPeMbQpszvXiOjxofHVlSTEdABW=ahNKPeMbQpszvXiOjxofHVlSTEdAGY.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if ahNKPeMbQpszvXiOjxofHVlSTEdABW==ahNKPeMbQpszvXiOjxofHVlSTEdAyD:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_winEpisodeOrderby()=='':
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.set_winEpisodeOrderby('asc')
  if ahNKPeMbQpszvXiOjxofHVlSTEdAGr.cookiefile_check():return
  ahNKPeMbQpszvXiOjxofHVlSTEdABg =ahNKPeMbQpszvXiOjxofHVlSTEdAym(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  ahNKPeMbQpszvXiOjxofHVlSTEdABc=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if ahNKPeMbQpszvXiOjxofHVlSTEdABc==ahNKPeMbQpszvXiOjxofHVlSTEdAyB or ahNKPeMbQpszvXiOjxofHVlSTEdABc=='':
   ahNKPeMbQpszvXiOjxofHVlSTEdABc=ahNKPeMbQpszvXiOjxofHVlSTEdAym('19000101')
  else:
   ahNKPeMbQpszvXiOjxofHVlSTEdABc=ahNKPeMbQpszvXiOjxofHVlSTEdAym(re.sub('-','',ahNKPeMbQpszvXiOjxofHVlSTEdABc))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   ahNKPeMbQpszvXiOjxofHVlSTEdABC=0
   while ahNKPeMbQpszvXiOjxofHVlSTEdAyD:
    ahNKPeMbQpszvXiOjxofHVlSTEdABC+=1
    time.sleep(0.05)
    if ahNKPeMbQpszvXiOjxofHVlSTEdABc>=ahNKPeMbQpszvXiOjxofHVlSTEdABg:return
    if ahNKPeMbQpszvXiOjxofHVlSTEdABC>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if ahNKPeMbQpszvXiOjxofHVlSTEdABc>=ahNKPeMbQpszvXiOjxofHVlSTEdABg:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.GetCredential(ahNKPeMbQpszvXiOjxofHVlSTEdABt,ahNKPeMbQpszvXiOjxofHVlSTEdABR,ahNKPeMbQpszvXiOjxofHVlSTEdABY):
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.set_winCredential(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.LoadCredential())
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,args):
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.SaveCredential(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_winCredential())
  ahNKPeMbQpszvXiOjxofHVlSTEdABq =args.get('stype')
  ahNKPeMbQpszvXiOjxofHVlSTEdABU =ahNKPeMbQpszvXiOjxofHVlSTEdAym(args.get('page'))
  ahNKPeMbQpszvXiOjxofHVlSTEdABu =args.get('sort')
  ahNKPeMbQpszvXiOjxofHVlSTEdABL=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.GetSubGroupList(ahNKPeMbQpszvXiOjxofHVlSTEdABq)
  ahNKPeMbQpszvXiOjxofHVlSTEdABn=ahNKPeMbQpszvXiOjxofHVlSTEdAGD if ahNKPeMbQpszvXiOjxofHVlSTEdABq=='genres' else ahNKPeMbQpszvXiOjxofHVlSTEdAGy
  ahNKPeMbQpszvXiOjxofHVlSTEdAmG=ahNKPeMbQpszvXiOjxofHVlSTEdAyw(ahNKPeMbQpszvXiOjxofHVlSTEdABL)
  ahNKPeMbQpszvXiOjxofHVlSTEdAmB =ahNKPeMbQpszvXiOjxofHVlSTEdAym(ahNKPeMbQpszvXiOjxofHVlSTEdAmG//(ahNKPeMbQpszvXiOjxofHVlSTEdABn+1))+1
  ahNKPeMbQpszvXiOjxofHVlSTEdAmJ =(ahNKPeMbQpszvXiOjxofHVlSTEdABU-1)*ahNKPeMbQpszvXiOjxofHVlSTEdABn
  for i in ahNKPeMbQpszvXiOjxofHVlSTEdAyF(ahNKPeMbQpszvXiOjxofHVlSTEdABn):
   ahNKPeMbQpszvXiOjxofHVlSTEdAmD=ahNKPeMbQpszvXiOjxofHVlSTEdAmJ+i
   if ahNKPeMbQpszvXiOjxofHVlSTEdAmD>=ahNKPeMbQpszvXiOjxofHVlSTEdAmG:break
   ahNKPeMbQpszvXiOjxofHVlSTEdABy =ahNKPeMbQpszvXiOjxofHVlSTEdABL[ahNKPeMbQpszvXiOjxofHVlSTEdAmD].get('group_name')
   ahNKPeMbQpszvXiOjxofHVlSTEdAmy =ahNKPeMbQpszvXiOjxofHVlSTEdABL[ahNKPeMbQpszvXiOjxofHVlSTEdAmD].get('api_path')
   ahNKPeMbQpszvXiOjxofHVlSTEdAmw =ahNKPeMbQpszvXiOjxofHVlSTEdABL[ahNKPeMbQpszvXiOjxofHVlSTEdAmD].get('tag_id')
   ahNKPeMbQpszvXiOjxofHVlSTEdABr={'mode':'CATEGORY_LIST','api_path':ahNKPeMbQpszvXiOjxofHVlSTEdAmy,'tag_id':ahNKPeMbQpszvXiOjxofHVlSTEdAmw,'stype':ahNKPeMbQpszvXiOjxofHVlSTEdABq,'page':'1','sort':ahNKPeMbQpszvXiOjxofHVlSTEdABu}
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel='',img='',infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAyB,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdAyD,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAmB>ahNKPeMbQpszvXiOjxofHVlSTEdABU:
   ahNKPeMbQpszvXiOjxofHVlSTEdABr={}
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['mode'] ='SUB_GROUP' 
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['stype'] =ahNKPeMbQpszvXiOjxofHVlSTEdABq
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['api_path']=args.get('api_path')
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['page'] =ahNKPeMbQpszvXiOjxofHVlSTEdAyr(ahNKPeMbQpszvXiOjxofHVlSTEdABU+1)
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['sort'] =ahNKPeMbQpszvXiOjxofHVlSTEdABu
   ahNKPeMbQpszvXiOjxofHVlSTEdABy='[B]%s >>[/B]'%'다음 페이지'
   ahNKPeMbQpszvXiOjxofHVlSTEdAmF=ahNKPeMbQpszvXiOjxofHVlSTEdAyr(ahNKPeMbQpszvXiOjxofHVlSTEdABU+1)
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel=ahNKPeMbQpszvXiOjxofHVlSTEdAmF,img='',infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAyB,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdAyD,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAyw(ahNKPeMbQpszvXiOjxofHVlSTEdABL)>0:xbmcplugin.endOfDirectory(ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_handle,cacheToDisc=ahNKPeMbQpszvXiOjxofHVlSTEdAyD)
 def play_VIDEO(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,args):
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.SaveCredential(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_winCredential())
  ahNKPeMbQpszvXiOjxofHVlSTEdAmr =args.get('movie_code')
  ahNKPeMbQpszvXiOjxofHVlSTEdAmI =args.get('season_code')
  ahNKPeMbQpszvXiOjxofHVlSTEdABy =args.get('title')
  ahNKPeMbQpszvXiOjxofHVlSTEdAmk =args.get('thumbnail')
  ahNKPeMbQpszvXiOjxofHVlSTEdAmt =ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_selQuality()
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.addon_log(ahNKPeMbQpszvXiOjxofHVlSTEdAmr+' - '+ahNKPeMbQpszvXiOjxofHVlSTEdAmI)
  ahNKPeMbQpszvXiOjxofHVlSTEdAmR,ahNKPeMbQpszvXiOjxofHVlSTEdAmY,ahNKPeMbQpszvXiOjxofHVlSTEdAmW=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.GetStreamingURL(ahNKPeMbQpszvXiOjxofHVlSTEdAmr,ahNKPeMbQpszvXiOjxofHVlSTEdAmt)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAmR=='':
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.addon_noti(__language__(30908).encode('utf8'))
   return
  ahNKPeMbQpszvXiOjxofHVlSTEdAmg=ahNKPeMbQpszvXiOjxofHVlSTEdAmR
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.addon_log(ahNKPeMbQpszvXiOjxofHVlSTEdAmg)
  ahNKPeMbQpszvXiOjxofHVlSTEdAmc=xbmcgui.ListItem(path=ahNKPeMbQpszvXiOjxofHVlSTEdAmg)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAmW:
   ahNKPeMbQpszvXiOjxofHVlSTEdAmC=ahNKPeMbQpszvXiOjxofHVlSTEdAmW
   ahNKPeMbQpszvXiOjxofHVlSTEdAmq ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   ahNKPeMbQpszvXiOjxofHVlSTEdAmU ='mpd'
   ahNKPeMbQpszvXiOjxofHVlSTEdAmu ='com.widevine.alpha'
   ahNKPeMbQpszvXiOjxofHVlSTEdAmL =inputstreamhelper.Helper(ahNKPeMbQpszvXiOjxofHVlSTEdAmU,drm=ahNKPeMbQpszvXiOjxofHVlSTEdAmu)
   if ahNKPeMbQpszvXiOjxofHVlSTEdAmL.check_inputstream():
    ahNKPeMbQpszvXiOjxofHVlSTEdAmn={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+ahNKPeMbQpszvXiOjxofHVlSTEdAmr,'dt-custom-data':ahNKPeMbQpszvXiOjxofHVlSTEdAmC,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    ahNKPeMbQpszvXiOjxofHVlSTEdAJG=ahNKPeMbQpszvXiOjxofHVlSTEdAmq+'|'+urllib.parse.urlencode(ahNKPeMbQpszvXiOjxofHVlSTEdAmn)+'|R{SSM}|'
    ahNKPeMbQpszvXiOjxofHVlSTEdAGr.addon_log(ahNKPeMbQpszvXiOjxofHVlSTEdAJG)
    ahNKPeMbQpszvXiOjxofHVlSTEdAmc.setProperty('inputstream',ahNKPeMbQpszvXiOjxofHVlSTEdAmL.inputstream_addon)
    ahNKPeMbQpszvXiOjxofHVlSTEdAmc.setProperty('inputstream.adaptive.manifest_type',ahNKPeMbQpszvXiOjxofHVlSTEdAmU)
    ahNKPeMbQpszvXiOjxofHVlSTEdAmc.setProperty('inputstream.adaptive.license_type',ahNKPeMbQpszvXiOjxofHVlSTEdAmu)
    ahNKPeMbQpszvXiOjxofHVlSTEdAmc.setProperty('inputstream.adaptive.license_key',ahNKPeMbQpszvXiOjxofHVlSTEdAJG)
    ahNKPeMbQpszvXiOjxofHVlSTEdAmc.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.USER_AGENT))
  if ahNKPeMbQpszvXiOjxofHVlSTEdAmY:
   try:
    f=ahNKPeMbQpszvXiOjxofHVlSTEdAyI(ahNKPeMbQpszvXiOjxofHVlSTEdAGw,'w',-1,'utf-8')
    ahNKPeMbQpszvXiOjxofHVlSTEdAJB=requests.get(ahNKPeMbQpszvXiOjxofHVlSTEdAmY)
    ahNKPeMbQpszvXiOjxofHVlSTEdAJm=ahNKPeMbQpszvXiOjxofHVlSTEdAJB.content.decode('utf-8') 
    for ahNKPeMbQpszvXiOjxofHVlSTEdAJD in ahNKPeMbQpszvXiOjxofHVlSTEdAJm.splitlines():
     ahNKPeMbQpszvXiOjxofHVlSTEdAJy=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',ahNKPeMbQpszvXiOjxofHVlSTEdAJD)
     f.write(ahNKPeMbQpszvXiOjxofHVlSTEdAJy+'\n')
    f.close()
    ahNKPeMbQpszvXiOjxofHVlSTEdAmc.setSubtitles([ahNKPeMbQpszvXiOjxofHVlSTEdAGw,ahNKPeMbQpszvXiOjxofHVlSTEdAmY])
   except:
    ahNKPeMbQpszvXiOjxofHVlSTEdAmc.setSubtitles([ahNKPeMbQpszvXiOjxofHVlSTEdAmY])
  xbmcplugin.setResolvedUrl(ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_handle,ahNKPeMbQpszvXiOjxofHVlSTEdAyD,ahNKPeMbQpszvXiOjxofHVlSTEdAmc)
  try:
   ahNKPeMbQpszvXiOjxofHVlSTEdABq='movie' if ahNKPeMbQpszvXiOjxofHVlSTEdAmI=='-' else 'seasons'
   ahNKPeMbQpszvXiOjxofHVlSTEdABr={'code':ahNKPeMbQpszvXiOjxofHVlSTEdAmr if ahNKPeMbQpszvXiOjxofHVlSTEdABq=='movie' else ahNKPeMbQpszvXiOjxofHVlSTEdAmI,'img':ahNKPeMbQpszvXiOjxofHVlSTEdAmk,'title':ahNKPeMbQpszvXiOjxofHVlSTEdABy,'videoid':ahNKPeMbQpszvXiOjxofHVlSTEdAmr}
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.Save_Watched_List(ahNKPeMbQpszvXiOjxofHVlSTEdABq,ahNKPeMbQpszvXiOjxofHVlSTEdABr)
  except:
   ahNKPeMbQpszvXiOjxofHVlSTEdAyB
 def dp_Category_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,args):
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.SaveCredential(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_winCredential())
  ahNKPeMbQpszvXiOjxofHVlSTEdABq =args.get('stype')
  ahNKPeMbQpszvXiOjxofHVlSTEdAmw =args.get('tag_id')
  ahNKPeMbQpszvXiOjxofHVlSTEdAmy=args.get('api_path')
  ahNKPeMbQpszvXiOjxofHVlSTEdABU=ahNKPeMbQpszvXiOjxofHVlSTEdAym(args.get('page'))
  ahNKPeMbQpszvXiOjxofHVlSTEdABu =args.get('sort')
  ahNKPeMbQpszvXiOjxofHVlSTEdAJw,ahNKPeMbQpszvXiOjxofHVlSTEdAJF=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.GetCategoryList(ahNKPeMbQpszvXiOjxofHVlSTEdABq,ahNKPeMbQpszvXiOjxofHVlSTEdAmw,ahNKPeMbQpszvXiOjxofHVlSTEdAmy,ahNKPeMbQpszvXiOjxofHVlSTEdABU,ahNKPeMbQpszvXiOjxofHVlSTEdABu)
  for ahNKPeMbQpszvXiOjxofHVlSTEdAJr in ahNKPeMbQpszvXiOjxofHVlSTEdAJw:
   ahNKPeMbQpszvXiOjxofHVlSTEdAmr =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('code')
   ahNKPeMbQpszvXiOjxofHVlSTEdABy =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('title')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJI =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('content_type')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJk =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('story')
   ahNKPeMbQpszvXiOjxofHVlSTEdAmk =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('thumbnail')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJt =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('year')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJR =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('film_rating_code')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJY=ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('film_rating_short')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJW =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('film_rating_long')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJg =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('duration')
   if ahNKPeMbQpszvXiOjxofHVlSTEdAJI=='movies': 
    ahNKPeMbQpszvXiOjxofHVlSTEdABI =ahNKPeMbQpszvXiOjxofHVlSTEdAyJ
    ahNKPeMbQpszvXiOjxofHVlSTEdAJc ='MOVIE'
    ahNKPeMbQpszvXiOjxofHVlSTEdABk =''
    ahNKPeMbQpszvXiOjxofHVlSTEdAmI='-'
    ahNKPeMbQpszvXiOjxofHVlSTEdAJC ='movie'
   else: 
    ahNKPeMbQpszvXiOjxofHVlSTEdABI =ahNKPeMbQpszvXiOjxofHVlSTEdAyD
    ahNKPeMbQpszvXiOjxofHVlSTEdAJc ='EPISODE'
    ahNKPeMbQpszvXiOjxofHVlSTEdABk ='Series'
    ahNKPeMbQpszvXiOjxofHVlSTEdAmI=ahNKPeMbQpszvXiOjxofHVlSTEdAmr
    ahNKPeMbQpszvXiOjxofHVlSTEdAJC ='episode'
   ahNKPeMbQpszvXiOjxofHVlSTEdAJq={'mediatype':ahNKPeMbQpszvXiOjxofHVlSTEdAJC,'mpaa':ahNKPeMbQpszvXiOjxofHVlSTEdAJW,'title':ahNKPeMbQpszvXiOjxofHVlSTEdABy,'year':ahNKPeMbQpszvXiOjxofHVlSTEdAJt,'duration':ahNKPeMbQpszvXiOjxofHVlSTEdAJg,'plot':'%s (%s)\n년도 : %s\n\n%s'%(ahNKPeMbQpszvXiOjxofHVlSTEdABy,ahNKPeMbQpszvXiOjxofHVlSTEdAJY,ahNKPeMbQpszvXiOjxofHVlSTEdAJt,ahNKPeMbQpszvXiOjxofHVlSTEdAJk)}
   if ahNKPeMbQpszvXiOjxofHVlSTEdAJR>=19:
    ahNKPeMbQpszvXiOjxofHVlSTEdABy+='  (%s년 - %s)'%(ahNKPeMbQpszvXiOjxofHVlSTEdAJt,ahNKPeMbQpszvXiOjxofHVlSTEdAyr(ahNKPeMbQpszvXiOjxofHVlSTEdAJY))
   else:
    ahNKPeMbQpszvXiOjxofHVlSTEdABy+='  (%s년)'%(ahNKPeMbQpszvXiOjxofHVlSTEdAJt)
   ahNKPeMbQpszvXiOjxofHVlSTEdABr={'mode':ahNKPeMbQpszvXiOjxofHVlSTEdAJc,'movie_code':ahNKPeMbQpszvXiOjxofHVlSTEdAmr,'page':'1','season_code':ahNKPeMbQpszvXiOjxofHVlSTEdAmI,'title':ahNKPeMbQpszvXiOjxofHVlSTEdABy,'thumbnail':ahNKPeMbQpszvXiOjxofHVlSTEdAmk}
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel=ahNKPeMbQpszvXiOjxofHVlSTEdABk,img=ahNKPeMbQpszvXiOjxofHVlSTEdAmk,infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAJq,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdABI,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAJF:
   if ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.GetCategoryList_morepage(ahNKPeMbQpszvXiOjxofHVlSTEdABq,ahNKPeMbQpszvXiOjxofHVlSTEdAmw,ahNKPeMbQpszvXiOjxofHVlSTEdAmy,ahNKPeMbQpszvXiOjxofHVlSTEdABU+1,ahNKPeMbQpszvXiOjxofHVlSTEdABu):
    ahNKPeMbQpszvXiOjxofHVlSTEdABr={}
    ahNKPeMbQpszvXiOjxofHVlSTEdABr['mode'] ='CATEGORY_LIST'
    ahNKPeMbQpszvXiOjxofHVlSTEdABr['stype'] =ahNKPeMbQpszvXiOjxofHVlSTEdABq
    ahNKPeMbQpszvXiOjxofHVlSTEdABr['tag_id'] =ahNKPeMbQpszvXiOjxofHVlSTEdAmw
    ahNKPeMbQpszvXiOjxofHVlSTEdABr['api_path']=ahNKPeMbQpszvXiOjxofHVlSTEdAmy
    ahNKPeMbQpszvXiOjxofHVlSTEdABr['page'] =ahNKPeMbQpszvXiOjxofHVlSTEdAyr(ahNKPeMbQpszvXiOjxofHVlSTEdABU+1)
    ahNKPeMbQpszvXiOjxofHVlSTEdABr['sort'] =ahNKPeMbQpszvXiOjxofHVlSTEdABu
    ahNKPeMbQpszvXiOjxofHVlSTEdABy='[B]%s >>[/B]'%'다음 페이지'
    ahNKPeMbQpszvXiOjxofHVlSTEdAmF=ahNKPeMbQpszvXiOjxofHVlSTEdAyr(ahNKPeMbQpszvXiOjxofHVlSTEdABU+1)
    ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel=ahNKPeMbQpszvXiOjxofHVlSTEdAmF,img='',infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAyB,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdAyD,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAyw(ahNKPeMbQpszvXiOjxofHVlSTEdAJw)>0:
   if ahNKPeMbQpszvXiOjxofHVlSTEdAmy=='arrivals/latest':
    xbmcplugin.endOfDirectory(ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_handle,cacheToDisc=ahNKPeMbQpszvXiOjxofHVlSTEdAyD)
   else:
    xbmcplugin.endOfDirectory(ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_handle,cacheToDisc=ahNKPeMbQpszvXiOjxofHVlSTEdAyJ)
 def dp_Episode_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,args):
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.SaveCredential(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_winCredential())
  ahNKPeMbQpszvXiOjxofHVlSTEdAJu=args.get('movie_code')
  ahNKPeMbQpszvXiOjxofHVlSTEdABU =ahNKPeMbQpszvXiOjxofHVlSTEdAym(args.get('page'))
  ahNKPeMbQpszvXiOjxofHVlSTEdAmI =args.get('season_code')
  ahNKPeMbQpszvXiOjxofHVlSTEdAJw,ahNKPeMbQpszvXiOjxofHVlSTEdAJF=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.GetEpisodoList(ahNKPeMbQpszvXiOjxofHVlSTEdAJu,ahNKPeMbQpszvXiOjxofHVlSTEdABU,orderby=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_winEpisodeOrderby())
  for ahNKPeMbQpszvXiOjxofHVlSTEdAJr in ahNKPeMbQpszvXiOjxofHVlSTEdAJw:
   ahNKPeMbQpszvXiOjxofHVlSTEdAmr =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('code')
   ahNKPeMbQpszvXiOjxofHVlSTEdABy =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('title')
   ahNKPeMbQpszvXiOjxofHVlSTEdAmk =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('thumbnail')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJL =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('display_num')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJn =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('season_title')
   ahNKPeMbQpszvXiOjxofHVlSTEdADG=ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('episode_number')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJg =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('duration')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJq={'mediatype':'episode','tvshowtitle':ahNKPeMbQpszvXiOjxofHVlSTEdABy if ahNKPeMbQpszvXiOjxofHVlSTEdABy!='' else ahNKPeMbQpszvXiOjxofHVlSTEdAJn,'title':'%s %s'%(ahNKPeMbQpszvXiOjxofHVlSTEdAJn,ahNKPeMbQpszvXiOjxofHVlSTEdAJL)if ahNKPeMbQpszvXiOjxofHVlSTEdABy!='' else ahNKPeMbQpszvXiOjxofHVlSTEdAJL,'episode':ahNKPeMbQpszvXiOjxofHVlSTEdADG,'duration':ahNKPeMbQpszvXiOjxofHVlSTEdAJg,'plot':'%s\n%s\n\n%s'%(ahNKPeMbQpszvXiOjxofHVlSTEdAJn,ahNKPeMbQpszvXiOjxofHVlSTEdAJL,ahNKPeMbQpszvXiOjxofHVlSTEdABy)}
   ahNKPeMbQpszvXiOjxofHVlSTEdABy='(%s) %s'%(ahNKPeMbQpszvXiOjxofHVlSTEdAJL,ahNKPeMbQpszvXiOjxofHVlSTEdABy)
   ahNKPeMbQpszvXiOjxofHVlSTEdABr={'mode':'MOVIE','movie_code':ahNKPeMbQpszvXiOjxofHVlSTEdAmr,'season_code':ahNKPeMbQpszvXiOjxofHVlSTEdAmI,'title':'%s < %s >'%(ahNKPeMbQpszvXiOjxofHVlSTEdABy,ahNKPeMbQpszvXiOjxofHVlSTEdAJn),'thumbnail':ahNKPeMbQpszvXiOjxofHVlSTEdAmk}
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel=ahNKPeMbQpszvXiOjxofHVlSTEdAJn,img=ahNKPeMbQpszvXiOjxofHVlSTEdAmk,infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAJq,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdAyJ,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
  if ahNKPeMbQpszvXiOjxofHVlSTEdABU==1:
   ahNKPeMbQpszvXiOjxofHVlSTEdAJq={'plot':'정렬순서를 변경합니다.'}
   ahNKPeMbQpszvXiOjxofHVlSTEdABr={}
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['mode'] ='ORDER_BY' 
   if ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_winEpisodeOrderby()=='desc':
    ahNKPeMbQpszvXiOjxofHVlSTEdABy='정렬순서변경 : 최신화부터 -> 1회부터'
    ahNKPeMbQpszvXiOjxofHVlSTEdABr['orderby']='asc'
   else:
    ahNKPeMbQpszvXiOjxofHVlSTEdABy='정렬순서변경 : 1회부터 -> 최신화부터'
    ahNKPeMbQpszvXiOjxofHVlSTEdABr['orderby']='desc'
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel='',img='',infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAJq,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdAyJ,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAJF:
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['mode'] ='EPISODE' 
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['movie_code']=ahNKPeMbQpszvXiOjxofHVlSTEdAJu
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['page'] =ahNKPeMbQpszvXiOjxofHVlSTEdAyr(ahNKPeMbQpszvXiOjxofHVlSTEdABU+1)
   ahNKPeMbQpszvXiOjxofHVlSTEdABy='[B]%s >>[/B]'%'다음 페이지'
   ahNKPeMbQpszvXiOjxofHVlSTEdAmF=ahNKPeMbQpszvXiOjxofHVlSTEdAyr(ahNKPeMbQpszvXiOjxofHVlSTEdABU+1)
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel=ahNKPeMbQpszvXiOjxofHVlSTEdAmF,img='',infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAyB,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdAyD,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAyw(ahNKPeMbQpszvXiOjxofHVlSTEdAJw)>0:xbmcplugin.endOfDirectory(ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_handle,cacheToDisc=ahNKPeMbQpszvXiOjxofHVlSTEdAyD)
 def dp_Search_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,args):
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.SaveCredential(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_winCredential())
  ahNKPeMbQpszvXiOjxofHVlSTEdABU =ahNKPeMbQpszvXiOjxofHVlSTEdAym(args.get('page'))
  if 'search_key' in args:
   ahNKPeMbQpszvXiOjxofHVlSTEdADB=args.get('search_key')
  else:
   ahNKPeMbQpszvXiOjxofHVlSTEdADB=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not ahNKPeMbQpszvXiOjxofHVlSTEdADB:return
  ahNKPeMbQpszvXiOjxofHVlSTEdAJw,ahNKPeMbQpszvXiOjxofHVlSTEdAJF=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.GetSearchList(ahNKPeMbQpszvXiOjxofHVlSTEdADB,ahNKPeMbQpszvXiOjxofHVlSTEdABU)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAyw(ahNKPeMbQpszvXiOjxofHVlSTEdAJw)==0:return
  for ahNKPeMbQpszvXiOjxofHVlSTEdAJr in ahNKPeMbQpszvXiOjxofHVlSTEdAJw:
   ahNKPeMbQpszvXiOjxofHVlSTEdAmr =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('code')
   ahNKPeMbQpszvXiOjxofHVlSTEdABy =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('title')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJI=ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('content_type')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJk =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('story')
   ahNKPeMbQpszvXiOjxofHVlSTEdAmk =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('thumbnail')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJt =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('year')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJR =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('film_rating_code')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJY=ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('film_rating_short')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJW =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('film_rating_long')
   ahNKPeMbQpszvXiOjxofHVlSTEdAJg =ahNKPeMbQpszvXiOjxofHVlSTEdAJr.get('duration')
   if ahNKPeMbQpszvXiOjxofHVlSTEdAJI=='movies': 
    ahNKPeMbQpszvXiOjxofHVlSTEdABI =ahNKPeMbQpszvXiOjxofHVlSTEdAyJ
    ahNKPeMbQpszvXiOjxofHVlSTEdAJc ='MOVIE'
    ahNKPeMbQpszvXiOjxofHVlSTEdABk =''
    ahNKPeMbQpszvXiOjxofHVlSTEdAmI='-'
    ahNKPeMbQpszvXiOjxofHVlSTEdAJC ='movie'
   else: 
    ahNKPeMbQpszvXiOjxofHVlSTEdABI =ahNKPeMbQpszvXiOjxofHVlSTEdAyD
    ahNKPeMbQpszvXiOjxofHVlSTEdAJc ='EPISODE'
    ahNKPeMbQpszvXiOjxofHVlSTEdABk ='Series'
    ahNKPeMbQpszvXiOjxofHVlSTEdAmI=ahNKPeMbQpszvXiOjxofHVlSTEdAmr
    ahNKPeMbQpszvXiOjxofHVlSTEdAJC ='episode'
   ahNKPeMbQpszvXiOjxofHVlSTEdAJq={'mediatype':ahNKPeMbQpszvXiOjxofHVlSTEdAJC,'mpaa':ahNKPeMbQpszvXiOjxofHVlSTEdAJW,'title':ahNKPeMbQpszvXiOjxofHVlSTEdABy,'year':ahNKPeMbQpszvXiOjxofHVlSTEdAJt,'duration':ahNKPeMbQpszvXiOjxofHVlSTEdAJg,'plot':'%s (%s)\n년도 : %s\n\n%s'%(ahNKPeMbQpszvXiOjxofHVlSTEdABy,ahNKPeMbQpszvXiOjxofHVlSTEdAJY,ahNKPeMbQpszvXiOjxofHVlSTEdAJt,ahNKPeMbQpszvXiOjxofHVlSTEdAJk)}
   if ahNKPeMbQpszvXiOjxofHVlSTEdAJR>=19:
    ahNKPeMbQpszvXiOjxofHVlSTEdABy+='  (%s년 - %s)'%(ahNKPeMbQpszvXiOjxofHVlSTEdAJt,ahNKPeMbQpszvXiOjxofHVlSTEdAyr(ahNKPeMbQpszvXiOjxofHVlSTEdAJY))
   else:
    ahNKPeMbQpszvXiOjxofHVlSTEdABy+='  (%s년)'%(ahNKPeMbQpszvXiOjxofHVlSTEdAJt)
   ahNKPeMbQpszvXiOjxofHVlSTEdABr={'mode':ahNKPeMbQpszvXiOjxofHVlSTEdAJc,'movie_code':ahNKPeMbQpszvXiOjxofHVlSTEdAmr,'page':'1','season_code':ahNKPeMbQpszvXiOjxofHVlSTEdAmI,'title':ahNKPeMbQpszvXiOjxofHVlSTEdABy,'thumbnail':ahNKPeMbQpszvXiOjxofHVlSTEdAmk}
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel=ahNKPeMbQpszvXiOjxofHVlSTEdABk,img=ahNKPeMbQpszvXiOjxofHVlSTEdAmk,infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAJq,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdABI,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAJF:
   ahNKPeMbQpszvXiOjxofHVlSTEdABr={}
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['mode'] ='SEARCH'
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['search_key']=ahNKPeMbQpszvXiOjxofHVlSTEdADB
   ahNKPeMbQpszvXiOjxofHVlSTEdABr['page'] =ahNKPeMbQpszvXiOjxofHVlSTEdAyr(ahNKPeMbQpszvXiOjxofHVlSTEdABU+1)
   ahNKPeMbQpszvXiOjxofHVlSTEdABy='[B]%s >>[/B]'%'다음 페이지'
   ahNKPeMbQpszvXiOjxofHVlSTEdAmF=ahNKPeMbQpszvXiOjxofHVlSTEdAyr(ahNKPeMbQpszvXiOjxofHVlSTEdABU+1)
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel=ahNKPeMbQpszvXiOjxofHVlSTEdAmF,img='',infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAyB,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdAyD,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
  if ahNKPeMbQpszvXiOjxofHVlSTEdAyw(ahNKPeMbQpszvXiOjxofHVlSTEdAJw)>0:xbmcplugin.endOfDirectory(ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_handle)
 def Delete_Watched_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,ahNKPeMbQpszvXiOjxofHVlSTEdABq):
  try:
   ahNKPeMbQpszvXiOjxofHVlSTEdADm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ahNKPeMbQpszvXiOjxofHVlSTEdABq))
   fp=ahNKPeMbQpszvXiOjxofHVlSTEdAyI(ahNKPeMbQpszvXiOjxofHVlSTEdADm,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   ahNKPeMbQpszvXiOjxofHVlSTEdAyB
 def dp_WatchList_Delete(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,args):
  ahNKPeMbQpszvXiOjxofHVlSTEdABq=args.get('stype')
  ahNKPeMbQpszvXiOjxofHVlSTEdAGY=xbmcgui.Dialog()
  ahNKPeMbQpszvXiOjxofHVlSTEdABW=ahNKPeMbQpszvXiOjxofHVlSTEdAGY.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if ahNKPeMbQpszvXiOjxofHVlSTEdABW==ahNKPeMbQpszvXiOjxofHVlSTEdAyJ:sys.exit()
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.Delete_Watched_List(ahNKPeMbQpszvXiOjxofHVlSTEdABq)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,ahNKPeMbQpszvXiOjxofHVlSTEdABq):
  try:
   ahNKPeMbQpszvXiOjxofHVlSTEdADm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ahNKPeMbQpszvXiOjxofHVlSTEdABq))
   fp=ahNKPeMbQpszvXiOjxofHVlSTEdAyI(ahNKPeMbQpszvXiOjxofHVlSTEdADm,'r',-1,'utf-8')
   ahNKPeMbQpszvXiOjxofHVlSTEdADJ=fp.readlines()
   fp.close()
  except:
   ahNKPeMbQpszvXiOjxofHVlSTEdADJ=[]
  return ahNKPeMbQpszvXiOjxofHVlSTEdADJ
 def Save_Watched_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,ahNKPeMbQpszvXiOjxofHVlSTEdABq,ahNKPeMbQpszvXiOjxofHVlSTEdAGt):
  try:
   ahNKPeMbQpszvXiOjxofHVlSTEdADm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ahNKPeMbQpszvXiOjxofHVlSTEdABq))
   ahNKPeMbQpszvXiOjxofHVlSTEdADy=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.Load_Watched_List(ahNKPeMbQpszvXiOjxofHVlSTEdABq) 
   fp=ahNKPeMbQpszvXiOjxofHVlSTEdAyI(ahNKPeMbQpszvXiOjxofHVlSTEdADm,'w',-1,'utf-8')
   ahNKPeMbQpszvXiOjxofHVlSTEdADw=urllib.parse.urlencode(ahNKPeMbQpszvXiOjxofHVlSTEdAGt)
   ahNKPeMbQpszvXiOjxofHVlSTEdADw=ahNKPeMbQpszvXiOjxofHVlSTEdADw+'\n'
   fp.write(ahNKPeMbQpszvXiOjxofHVlSTEdADw)
   ahNKPeMbQpszvXiOjxofHVlSTEdADF=0
   for ahNKPeMbQpszvXiOjxofHVlSTEdADr in ahNKPeMbQpszvXiOjxofHVlSTEdADy:
    ahNKPeMbQpszvXiOjxofHVlSTEdADI=ahNKPeMbQpszvXiOjxofHVlSTEdAyk(urllib.parse.parse_qsl(ahNKPeMbQpszvXiOjxofHVlSTEdADr))
    ahNKPeMbQpszvXiOjxofHVlSTEdADk=ahNKPeMbQpszvXiOjxofHVlSTEdAGt.get('code').strip()
    ahNKPeMbQpszvXiOjxofHVlSTEdADt=ahNKPeMbQpszvXiOjxofHVlSTEdADI.get('code').strip()
    if ahNKPeMbQpszvXiOjxofHVlSTEdABq=='seasons' and ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_settings_direct_replay()==ahNKPeMbQpszvXiOjxofHVlSTEdAyD:
     ahNKPeMbQpszvXiOjxofHVlSTEdADk=ahNKPeMbQpszvXiOjxofHVlSTEdAGt.get('videoid').strip()
     ahNKPeMbQpszvXiOjxofHVlSTEdADt=ahNKPeMbQpszvXiOjxofHVlSTEdADI.get('videoid').strip()if ahNKPeMbQpszvXiOjxofHVlSTEdADt!=ahNKPeMbQpszvXiOjxofHVlSTEdAyB else '-'
    if ahNKPeMbQpszvXiOjxofHVlSTEdADk!=ahNKPeMbQpszvXiOjxofHVlSTEdADt:
     fp.write(ahNKPeMbQpszvXiOjxofHVlSTEdADr)
     ahNKPeMbQpszvXiOjxofHVlSTEdADF+=1
     if ahNKPeMbQpszvXiOjxofHVlSTEdADF>=50:break
   fp.close()
  except:
   ahNKPeMbQpszvXiOjxofHVlSTEdAyB
 def dp_Watch_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr,args):
  ahNKPeMbQpszvXiOjxofHVlSTEdABq =args.get('stype')
  ahNKPeMbQpszvXiOjxofHVlSTEdAGn=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.get_settings_direct_replay()
  if ahNKPeMbQpszvXiOjxofHVlSTEdABq=='-':
   for ahNKPeMbQpszvXiOjxofHVlSTEdADR in ahNKPeMbQpszvXiOjxofHVlSTEdAGJ:
    ahNKPeMbQpszvXiOjxofHVlSTEdABy=ahNKPeMbQpszvXiOjxofHVlSTEdADR.get('title')
    ahNKPeMbQpszvXiOjxofHVlSTEdABr={'mode':ahNKPeMbQpszvXiOjxofHVlSTEdADR.get('mode'),'stype':ahNKPeMbQpszvXiOjxofHVlSTEdADR.get('stype')}
    ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel='',img='',infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAyB,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdAyD,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
   if ahNKPeMbQpszvXiOjxofHVlSTEdAyw(ahNKPeMbQpszvXiOjxofHVlSTEdAGJ)>0:xbmcplugin.endOfDirectory(ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_handle)
  else:
   ahNKPeMbQpszvXiOjxofHVlSTEdADY=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.Load_Watched_List(ahNKPeMbQpszvXiOjxofHVlSTEdABq)
   for ahNKPeMbQpszvXiOjxofHVlSTEdADW in ahNKPeMbQpszvXiOjxofHVlSTEdADY:
    ahNKPeMbQpszvXiOjxofHVlSTEdADg=ahNKPeMbQpszvXiOjxofHVlSTEdAyk(urllib.parse.parse_qsl(ahNKPeMbQpszvXiOjxofHVlSTEdADW))
    ahNKPeMbQpszvXiOjxofHVlSTEdAmr=ahNKPeMbQpszvXiOjxofHVlSTEdADg.get('code').strip()
    ahNKPeMbQpszvXiOjxofHVlSTEdABy =ahNKPeMbQpszvXiOjxofHVlSTEdADg.get('title').strip()
    ahNKPeMbQpszvXiOjxofHVlSTEdAmk =ahNKPeMbQpszvXiOjxofHVlSTEdADg.get('img').strip()
    ahNKPeMbQpszvXiOjxofHVlSTEdADc =ahNKPeMbQpszvXiOjxofHVlSTEdADg.get('videoid').strip()
    ahNKPeMbQpszvXiOjxofHVlSTEdAJq={}
    ahNKPeMbQpszvXiOjxofHVlSTEdAJq['plot']=ahNKPeMbQpszvXiOjxofHVlSTEdABy
    if ahNKPeMbQpszvXiOjxofHVlSTEdABq=='movie':
     ahNKPeMbQpszvXiOjxofHVlSTEdABr={'mode':'MOVIE','page':'1','movie_code':ahNKPeMbQpszvXiOjxofHVlSTEdAmr,'season_code':'-','title':ahNKPeMbQpszvXiOjxofHVlSTEdABy,'thumbnail':ahNKPeMbQpszvXiOjxofHVlSTEdAmk}
     ahNKPeMbQpszvXiOjxofHVlSTEdABI=ahNKPeMbQpszvXiOjxofHVlSTEdAyJ
    else:
     if ahNKPeMbQpszvXiOjxofHVlSTEdAGn==ahNKPeMbQpszvXiOjxofHVlSTEdAyJ or ahNKPeMbQpszvXiOjxofHVlSTEdADc==ahNKPeMbQpszvXiOjxofHVlSTEdAyB:
      ahNKPeMbQpszvXiOjxofHVlSTEdABr={'mode':'EPISODE','page':'1','movie_code':ahNKPeMbQpszvXiOjxofHVlSTEdAmr,'season_code':ahNKPeMbQpszvXiOjxofHVlSTEdAmr,'title':ahNKPeMbQpszvXiOjxofHVlSTEdABy,'thumbnail':ahNKPeMbQpszvXiOjxofHVlSTEdAmk}
      ahNKPeMbQpszvXiOjxofHVlSTEdABI=ahNKPeMbQpszvXiOjxofHVlSTEdAyD
     else:
      ahNKPeMbQpszvXiOjxofHVlSTEdABr={'mode':'MOVIE','movie_code':ahNKPeMbQpszvXiOjxofHVlSTEdADc,'season_code':ahNKPeMbQpszvXiOjxofHVlSTEdAmr,'title':ahNKPeMbQpszvXiOjxofHVlSTEdABy,'thumbnail':ahNKPeMbQpszvXiOjxofHVlSTEdAmk}
      ahNKPeMbQpszvXiOjxofHVlSTEdABI=ahNKPeMbQpszvXiOjxofHVlSTEdAyJ
    ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel='',img=ahNKPeMbQpszvXiOjxofHVlSTEdAmk,infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAJq,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdABI,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
   ahNKPeMbQpszvXiOjxofHVlSTEdAJq={'plot':'시청목록을 삭제합니다.'}
   ahNKPeMbQpszvXiOjxofHVlSTEdABy='*** 시청목록 삭제 ***'
   ahNKPeMbQpszvXiOjxofHVlSTEdABr={'mode':'MYVIEW_REMOVE','stype':ahNKPeMbQpszvXiOjxofHVlSTEdABq}
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.add_dir(ahNKPeMbQpszvXiOjxofHVlSTEdABy,sublabel='',img='',infoLabels=ahNKPeMbQpszvXiOjxofHVlSTEdAJq,isFolder=ahNKPeMbQpszvXiOjxofHVlSTEdAyJ,params=ahNKPeMbQpszvXiOjxofHVlSTEdABr)
   xbmcplugin.endOfDirectory(ahNKPeMbQpszvXiOjxofHVlSTEdAGr._addon_handle,cacheToDisc=ahNKPeMbQpszvXiOjxofHVlSTEdAyJ)
 def logout(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  ahNKPeMbQpszvXiOjxofHVlSTEdAGY=xbmcgui.Dialog()
  ahNKPeMbQpszvXiOjxofHVlSTEdABW=ahNKPeMbQpszvXiOjxofHVlSTEdAGY.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if ahNKPeMbQpszvXiOjxofHVlSTEdABW==ahNKPeMbQpszvXiOjxofHVlSTEdAyJ:sys.exit()
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.wininfo_clear()
  if os.path.isfile(ahNKPeMbQpszvXiOjxofHVlSTEdAGF):os.remove(ahNKPeMbQpszvXiOjxofHVlSTEdAGF)
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  ahNKPeMbQpszvXiOjxofHVlSTEdABG=xbmcgui.Window(10000)
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_TOKEN','')
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_GUIT','')
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_GUITV','')
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_USERCD','')
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  ahNKPeMbQpszvXiOjxofHVlSTEdADC =ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.Get_Now_Datetime()
  ahNKPeMbQpszvXiOjxofHVlSTEdADq=ahNKPeMbQpszvXiOjxofHVlSTEdADC+datetime.timedelta(days=ahNKPeMbQpszvXiOjxofHVlSTEdAym(__addon__.getSetting('cache_ttl')))
  ahNKPeMbQpszvXiOjxofHVlSTEdABG=xbmcgui.Window(10000)
  ahNKPeMbQpszvXiOjxofHVlSTEdADU={'watcha_token':ahNKPeMbQpszvXiOjxofHVlSTEdABG.getProperty('WATCHA_M_TOKEN'),'watcha_guit':ahNKPeMbQpszvXiOjxofHVlSTEdABG.getProperty('WATCHA_M_GUIT'),'watcha_guitv':ahNKPeMbQpszvXiOjxofHVlSTEdABG.getProperty('WATCHA_M_GUITV'),'watcha_usercd':ahNKPeMbQpszvXiOjxofHVlSTEdABG.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':ahNKPeMbQpszvXiOjxofHVlSTEdADq.strftime('%Y-%m-%d')}
  try: 
   fp=ahNKPeMbQpszvXiOjxofHVlSTEdAyI(ahNKPeMbQpszvXiOjxofHVlSTEdAGF,'w',-1,'utf-8')
   json.dump(ahNKPeMbQpszvXiOjxofHVlSTEdADU,fp)
   fp.close()
  except ahNKPeMbQpszvXiOjxofHVlSTEdAyt as exception:
   ahNKPeMbQpszvXiOjxofHVlSTEdAyR(exception)
 def cookiefile_check(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  ahNKPeMbQpszvXiOjxofHVlSTEdADU={}
  try: 
   fp=ahNKPeMbQpszvXiOjxofHVlSTEdAyI(ahNKPeMbQpszvXiOjxofHVlSTEdAGF,'r',-1,'utf-8')
   ahNKPeMbQpszvXiOjxofHVlSTEdADU= json.load(fp)
   fp.close()
  except ahNKPeMbQpszvXiOjxofHVlSTEdAyt as exception:
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.wininfo_clear()
   return ahNKPeMbQpszvXiOjxofHVlSTEdAyJ
  ahNKPeMbQpszvXiOjxofHVlSTEdABt =__addon__.getSetting('id')
  ahNKPeMbQpszvXiOjxofHVlSTEdABR =__addon__.getSetting('pw')
  ahNKPeMbQpszvXiOjxofHVlSTEdADu =__addon__.getSetting('selected_profile')
  ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_id']=base64.standard_b64decode(ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_id']).decode('utf-8')
  ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_pw']=base64.standard_b64decode(ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_pw']).decode('utf-8')
  if ahNKPeMbQpszvXiOjxofHVlSTEdABt!=ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_id']or ahNKPeMbQpszvXiOjxofHVlSTEdABR!=ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_pw']or ahNKPeMbQpszvXiOjxofHVlSTEdADu!=ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_profile']:
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.wininfo_clear()
   return ahNKPeMbQpszvXiOjxofHVlSTEdAyJ
  ahNKPeMbQpszvXiOjxofHVlSTEdABg =ahNKPeMbQpszvXiOjxofHVlSTEdAym(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  ahNKPeMbQpszvXiOjxofHVlSTEdADL=ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_limitdate']
  ahNKPeMbQpszvXiOjxofHVlSTEdABc =ahNKPeMbQpszvXiOjxofHVlSTEdAym(re.sub('-','',ahNKPeMbQpszvXiOjxofHVlSTEdADL))
  if ahNKPeMbQpszvXiOjxofHVlSTEdABc<ahNKPeMbQpszvXiOjxofHVlSTEdABg:
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.wininfo_clear()
   return ahNKPeMbQpszvXiOjxofHVlSTEdAyJ
  ahNKPeMbQpszvXiOjxofHVlSTEdABG=xbmcgui.Window(10000)
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_TOKEN',ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_token'])
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_GUIT',ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_guit'])
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_GUITV',ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_guitv'])
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_USERCD',ahNKPeMbQpszvXiOjxofHVlSTEdADU['watcha_usercd'])
  ahNKPeMbQpszvXiOjxofHVlSTEdABG.setProperty('WATCHA_M_LOGINTIME',ahNKPeMbQpszvXiOjxofHVlSTEdADL)
  return ahNKPeMbQpszvXiOjxofHVlSTEdAyD
 def watcha_main(ahNKPeMbQpszvXiOjxofHVlSTEdAGr):
  ahNKPeMbQpszvXiOjxofHVlSTEdADn=ahNKPeMbQpszvXiOjxofHVlSTEdAGr.main_params.get('mode',ahNKPeMbQpszvXiOjxofHVlSTEdAyB)
  if ahNKPeMbQpszvXiOjxofHVlSTEdADn=='LOGOUT':
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.logout()
   return
  ahNKPeMbQpszvXiOjxofHVlSTEdAGr.login_main()
  if ahNKPeMbQpszvXiOjxofHVlSTEdADn is ahNKPeMbQpszvXiOjxofHVlSTEdAyB:
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.dp_Main_List()
  elif ahNKPeMbQpszvXiOjxofHVlSTEdADn=='SUB_GROUP':
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.dp_SubGroup_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.main_params)
  elif ahNKPeMbQpszvXiOjxofHVlSTEdADn=='CATEGORY_LIST':
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.dp_Category_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.main_params)
  elif ahNKPeMbQpszvXiOjxofHVlSTEdADn=='EPISODE':
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.dp_Episode_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.main_params)
  elif ahNKPeMbQpszvXiOjxofHVlSTEdADn=='ORDER_BY':
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.dp_setEpOrderby(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.main_params)
  elif ahNKPeMbQpszvXiOjxofHVlSTEdADn=='SEARCH':
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.dp_Search_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.main_params)
  elif ahNKPeMbQpszvXiOjxofHVlSTEdADn=='MOVIE':
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.play_VIDEO(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.main_params)
  elif ahNKPeMbQpszvXiOjxofHVlSTEdADn=='WATCH':
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.dp_Watch_List(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.main_params)
  elif ahNKPeMbQpszvXiOjxofHVlSTEdADn=='MYVIEW_REMOVE':
   ahNKPeMbQpszvXiOjxofHVlSTEdAGr.dp_WatchList_Delete(ahNKPeMbQpszvXiOjxofHVlSTEdAGr.main_params)
  else:
   ahNKPeMbQpszvXiOjxofHVlSTEdAyB
# Created by pyminifier (https://github.com/liftoff/pyminifier)
