__author__="NightRain"
vLpSXVndRxiTPUIMYQWlDmNHAqFswc=object
vLpSXVndRxiTPUIMYQWlDmNHAqFswz=None
vLpSXVndRxiTPUIMYQWlDmNHAqFswk=int
vLpSXVndRxiTPUIMYQWlDmNHAqFsGe=False
vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ=True
vLpSXVndRxiTPUIMYQWlDmNHAqFsGK=len
vLpSXVndRxiTPUIMYQWlDmNHAqFsGt=range
vLpSXVndRxiTPUIMYQWlDmNHAqFsGw=str
vLpSXVndRxiTPUIMYQWlDmNHAqFsGu=open
vLpSXVndRxiTPUIMYQWlDmNHAqFsGE=dict
vLpSXVndRxiTPUIMYQWlDmNHAqFsGh=Exception
vLpSXVndRxiTPUIMYQWlDmNHAqFsGO=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
vLpSXVndRxiTPUIMYQWlDmNHAqFseK=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'검색 (search)','mode':'SEARCH','stype':'-','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-'}]
vLpSXVndRxiTPUIMYQWlDmNHAqFset=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
vLpSXVndRxiTPUIMYQWlDmNHAqFsew=40
vLpSXVndRxiTPUIMYQWlDmNHAqFseG =20
vLpSXVndRxiTPUIMYQWlDmNHAqFseu='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
vLpSXVndRxiTPUIMYQWlDmNHAqFseE =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
vLpSXVndRxiTPUIMYQWlDmNHAqFseh=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class vLpSXVndRxiTPUIMYQWlDmNHAqFseJ(vLpSXVndRxiTPUIMYQWlDmNHAqFswc):
 def __init__(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,vLpSXVndRxiTPUIMYQWlDmNHAqFsej,vLpSXVndRxiTPUIMYQWlDmNHAqFseB,vLpSXVndRxiTPUIMYQWlDmNHAqFsea):
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_url =vLpSXVndRxiTPUIMYQWlDmNHAqFsej
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_handle=vLpSXVndRxiTPUIMYQWlDmNHAqFseB
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.main_params =vLpSXVndRxiTPUIMYQWlDmNHAqFsea
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj =YubxFwIWAkTsULrdaqGfJnElpCPNye() 
 def addon_noti(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,sting):
  try:
   vLpSXVndRxiTPUIMYQWlDmNHAqFseg=xbmcgui.Dialog()
   vLpSXVndRxiTPUIMYQWlDmNHAqFseg.notification(__addonname__,sting)
  except:
   vLpSXVndRxiTPUIMYQWlDmNHAqFswz
 def addon_log(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,string):
  try:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsey=string.encode('utf-8','ignore')
  except:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsey='addonException: addon_log'
  vLpSXVndRxiTPUIMYQWlDmNHAqFsef=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,vLpSXVndRxiTPUIMYQWlDmNHAqFsey),level=vLpSXVndRxiTPUIMYQWlDmNHAqFsef)
 def get_keyboard_input(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,vLpSXVndRxiTPUIMYQWlDmNHAqFsJu):
  vLpSXVndRxiTPUIMYQWlDmNHAqFser=vLpSXVndRxiTPUIMYQWlDmNHAqFswz
  kb=xbmc.Keyboard()
  kb.setHeading(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   vLpSXVndRxiTPUIMYQWlDmNHAqFser=kb.getText()
  return vLpSXVndRxiTPUIMYQWlDmNHAqFser
 def get_settings_login_info(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  vLpSXVndRxiTPUIMYQWlDmNHAqFseo =__addon__.getSetting('id')
  vLpSXVndRxiTPUIMYQWlDmNHAqFseb =__addon__.getSetting('pw')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsec=vLpSXVndRxiTPUIMYQWlDmNHAqFswk(__addon__.getSetting('selected_profile'))
  return(vLpSXVndRxiTPUIMYQWlDmNHAqFseo,vLpSXVndRxiTPUIMYQWlDmNHAqFseb,vLpSXVndRxiTPUIMYQWlDmNHAqFsec)
 def get_selQuality(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  try:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsez=['3840x2160/1','1920x1080/1','1280x720/1']
   vLpSXVndRxiTPUIMYQWlDmNHAqFsek=vLpSXVndRxiTPUIMYQWlDmNHAqFswk(__addon__.getSetting('selected_quality'))
   return vLpSXVndRxiTPUIMYQWlDmNHAqFsez[vLpSXVndRxiTPUIMYQWlDmNHAqFsek]
  except:
   vLpSXVndRxiTPUIMYQWlDmNHAqFswz
  return 1080 
 def get_settings_direct_replay(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJe=vLpSXVndRxiTPUIMYQWlDmNHAqFswk(__addon__.getSetting('direct_replay'))
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsJe==0:
   return vLpSXVndRxiTPUIMYQWlDmNHAqFsGe
  else:
   return vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ
 def set_winCredential(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,credential):
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK=xbmcgui.Window(10000)
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_LOGINTIME',vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK=xbmcgui.Window(10000)
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJt={'watcha_token':vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.getProperty('WATCHA_M_TOKEN'),'watcha_guit':vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.getProperty('WATCHA_M_GUIT'),'watcha_guitv':vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.getProperty('WATCHA_M_GUITV'),'watcha_usercd':vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.getProperty('WATCHA_M_USERCD')}
  return vLpSXVndRxiTPUIMYQWlDmNHAqFsJt
 def set_winEpisodeOrderby(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,vLpSXVndRxiTPUIMYQWlDmNHAqFsJw):
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK=xbmcgui.Window(10000)
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_ORDERBY',vLpSXVndRxiTPUIMYQWlDmNHAqFsJw)
 def get_winEpisodeOrderby(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK=xbmcgui.Window(10000)
  return vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,args):
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJw =args.get('orderby')
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.set_winEpisodeOrderby(vLpSXVndRxiTPUIMYQWlDmNHAqFsJw)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,label,sublabel='',img='',infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFswz,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ,params=''):
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJG='%s?%s'%(vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_url,urllib.parse.urlencode(params))
  if sublabel:vLpSXVndRxiTPUIMYQWlDmNHAqFsJu='%s < %s >'%(label,sublabel)
  else: vLpSXVndRxiTPUIMYQWlDmNHAqFsJu=label
  if not img:img='DefaultFolder.png'
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJE=xbmcgui.ListItem(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu)
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJE.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:vLpSXVndRxiTPUIMYQWlDmNHAqFsJE.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:vLpSXVndRxiTPUIMYQWlDmNHAqFsJE.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_handle,vLpSXVndRxiTPUIMYQWlDmNHAqFsJG,vLpSXVndRxiTPUIMYQWlDmNHAqFsJE,isFolder)
 def dp_Main_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  for vLpSXVndRxiTPUIMYQWlDmNHAqFsJh in vLpSXVndRxiTPUIMYQWlDmNHAqFseK:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJu=vLpSXVndRxiTPUIMYQWlDmNHAqFsJh.get('title')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={'mode':vLpSXVndRxiTPUIMYQWlDmNHAqFsJh.get('mode'),'stype':vLpSXVndRxiTPUIMYQWlDmNHAqFsJh.get('stype'),'api_path':vLpSXVndRxiTPUIMYQWlDmNHAqFsJh.get('api_path'),'page':'1','sort':vLpSXVndRxiTPUIMYQWlDmNHAqFsJh.get('sort'),'tag_id':'-'}
   if vLpSXVndRxiTPUIMYQWlDmNHAqFsJh.get('mode')=='XXX':
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['mode']='XXX'
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJj=vLpSXVndRxiTPUIMYQWlDmNHAqFsGe
   else:
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJj=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel='',img='',infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFswz,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsJj,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsGK(vLpSXVndRxiTPUIMYQWlDmNHAqFseK)>0:xbmcplugin.endOfDirectory(vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_handle)
 def login_main(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  (vLpSXVndRxiTPUIMYQWlDmNHAqFsJa,vLpSXVndRxiTPUIMYQWlDmNHAqFsJC,vLpSXVndRxiTPUIMYQWlDmNHAqFsJg)=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_settings_login_info()
  if not(vLpSXVndRxiTPUIMYQWlDmNHAqFsJa and vLpSXVndRxiTPUIMYQWlDmNHAqFsJC):
   vLpSXVndRxiTPUIMYQWlDmNHAqFseg=xbmcgui.Dialog()
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJy=vLpSXVndRxiTPUIMYQWlDmNHAqFseg.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if vLpSXVndRxiTPUIMYQWlDmNHAqFsJy==vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_winEpisodeOrderby()=='':
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.set_winEpisodeOrderby('asc')
  if vLpSXVndRxiTPUIMYQWlDmNHAqFseO.cookiefile_check():return
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJf =vLpSXVndRxiTPUIMYQWlDmNHAqFswk(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJr=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsJr==vLpSXVndRxiTPUIMYQWlDmNHAqFswz or vLpSXVndRxiTPUIMYQWlDmNHAqFsJr=='':
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJr=vLpSXVndRxiTPUIMYQWlDmNHAqFswk('19000101')
  else:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJr=vLpSXVndRxiTPUIMYQWlDmNHAqFswk(re.sub('-','',vLpSXVndRxiTPUIMYQWlDmNHAqFsJr))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJo=0
   while vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ:
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJo+=1
    time.sleep(0.05)
    if vLpSXVndRxiTPUIMYQWlDmNHAqFsJr>=vLpSXVndRxiTPUIMYQWlDmNHAqFsJf:return
    if vLpSXVndRxiTPUIMYQWlDmNHAqFsJo>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsJr>=vLpSXVndRxiTPUIMYQWlDmNHAqFsJf:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.GetCredential(vLpSXVndRxiTPUIMYQWlDmNHAqFsJa,vLpSXVndRxiTPUIMYQWlDmNHAqFsJC,vLpSXVndRxiTPUIMYQWlDmNHAqFsJg):
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.set_winCredential(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.LoadCredential())
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,args):
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.SaveCredential(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_winCredential())
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJb =args.get('stype')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJc =vLpSXVndRxiTPUIMYQWlDmNHAqFswk(args.get('page'))
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJz =args.get('sort')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJk=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.GetSubGroupList(vLpSXVndRxiTPUIMYQWlDmNHAqFsJb)
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKe=vLpSXVndRxiTPUIMYQWlDmNHAqFsew if vLpSXVndRxiTPUIMYQWlDmNHAqFsJb=='genres' else vLpSXVndRxiTPUIMYQWlDmNHAqFseG
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKJ=vLpSXVndRxiTPUIMYQWlDmNHAqFsGK(vLpSXVndRxiTPUIMYQWlDmNHAqFsJk)
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKt =vLpSXVndRxiTPUIMYQWlDmNHAqFswk(vLpSXVndRxiTPUIMYQWlDmNHAqFsKJ//(vLpSXVndRxiTPUIMYQWlDmNHAqFsKe+1))+1
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKw =(vLpSXVndRxiTPUIMYQWlDmNHAqFsJc-1)*vLpSXVndRxiTPUIMYQWlDmNHAqFsKe
  for i in vLpSXVndRxiTPUIMYQWlDmNHAqFsGt(vLpSXVndRxiTPUIMYQWlDmNHAqFsKe):
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKG=vLpSXVndRxiTPUIMYQWlDmNHAqFsKw+i
   if vLpSXVndRxiTPUIMYQWlDmNHAqFsKG>=vLpSXVndRxiTPUIMYQWlDmNHAqFsKJ:break
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJu =vLpSXVndRxiTPUIMYQWlDmNHAqFsJk[vLpSXVndRxiTPUIMYQWlDmNHAqFsKG].get('group_name')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKu =vLpSXVndRxiTPUIMYQWlDmNHAqFsJk[vLpSXVndRxiTPUIMYQWlDmNHAqFsKG].get('api_path')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKE =vLpSXVndRxiTPUIMYQWlDmNHAqFsJk[vLpSXVndRxiTPUIMYQWlDmNHAqFsKG].get('tag_id')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={'mode':'CATEGORY_LIST','api_path':vLpSXVndRxiTPUIMYQWlDmNHAqFsKu,'tag_id':vLpSXVndRxiTPUIMYQWlDmNHAqFsKE,'stype':vLpSXVndRxiTPUIMYQWlDmNHAqFsJb,'page':'1','sort':vLpSXVndRxiTPUIMYQWlDmNHAqFsJz}
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel='',img='',infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFswz,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsKt>vLpSXVndRxiTPUIMYQWlDmNHAqFsJc:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={}
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['mode'] ='SUB_GROUP' 
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['stype'] =vLpSXVndRxiTPUIMYQWlDmNHAqFsJb
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['api_path']=args.get('api_path')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['page'] =vLpSXVndRxiTPUIMYQWlDmNHAqFsGw(vLpSXVndRxiTPUIMYQWlDmNHAqFsJc+1)
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['sort'] =vLpSXVndRxiTPUIMYQWlDmNHAqFsJz
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJu='[B]%s >>[/B]'%'다음 페이지'
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKh=vLpSXVndRxiTPUIMYQWlDmNHAqFsGw(vLpSXVndRxiTPUIMYQWlDmNHAqFsJc+1)
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel=vLpSXVndRxiTPUIMYQWlDmNHAqFsKh,img='',infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFswz,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsGK(vLpSXVndRxiTPUIMYQWlDmNHAqFsJk)>0:xbmcplugin.endOfDirectory(vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_handle,cacheToDisc=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ)
 def play_VIDEO(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,args):
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.SaveCredential(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_winCredential())
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKO =args.get('movie_code')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKj =args.get('season_code')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJu =args.get('title')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKB =args.get('thumbnail')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKa =vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_selQuality()
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.addon_log(vLpSXVndRxiTPUIMYQWlDmNHAqFsKO+' - '+vLpSXVndRxiTPUIMYQWlDmNHAqFsKj)
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKC,vLpSXVndRxiTPUIMYQWlDmNHAqFsKg,vLpSXVndRxiTPUIMYQWlDmNHAqFsKy=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.GetStreamingURL(vLpSXVndRxiTPUIMYQWlDmNHAqFsKO,vLpSXVndRxiTPUIMYQWlDmNHAqFsKa)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsKC=='':
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.addon_noti(__language__(30908).encode('utf8'))
   return
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKf=vLpSXVndRxiTPUIMYQWlDmNHAqFsKC
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.addon_log(vLpSXVndRxiTPUIMYQWlDmNHAqFsKf)
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKr=xbmcgui.ListItem(path=vLpSXVndRxiTPUIMYQWlDmNHAqFsKf)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsKy:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKo=vLpSXVndRxiTPUIMYQWlDmNHAqFsKy
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKb ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKc ='mpd'
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKz ='com.widevine.alpha'
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKk =inputstreamhelper.Helper(vLpSXVndRxiTPUIMYQWlDmNHAqFsKc,drm=vLpSXVndRxiTPUIMYQWlDmNHAqFsKz)
   if vLpSXVndRxiTPUIMYQWlDmNHAqFsKk.check_inputstream():
    vLpSXVndRxiTPUIMYQWlDmNHAqFste={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+vLpSXVndRxiTPUIMYQWlDmNHAqFsKO,'dt-custom-data':vLpSXVndRxiTPUIMYQWlDmNHAqFsKo,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':vLpSXVndRxiTPUIMYQWlDmNHAqFseu,'Content-Type':'application/octet-stream'}
    vLpSXVndRxiTPUIMYQWlDmNHAqFstJ=vLpSXVndRxiTPUIMYQWlDmNHAqFsKb+'|'+urllib.parse.urlencode(vLpSXVndRxiTPUIMYQWlDmNHAqFste)+'|R{SSM}|'
    vLpSXVndRxiTPUIMYQWlDmNHAqFseO.addon_log(vLpSXVndRxiTPUIMYQWlDmNHAqFstJ)
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKr.setProperty('inputstream',vLpSXVndRxiTPUIMYQWlDmNHAqFsKk.inputstream_addon)
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKr.setProperty('inputstream.adaptive.manifest_type',vLpSXVndRxiTPUIMYQWlDmNHAqFsKc)
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKr.setProperty('inputstream.adaptive.license_type',vLpSXVndRxiTPUIMYQWlDmNHAqFsKz)
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKr.setProperty('inputstream.adaptive.license_key',vLpSXVndRxiTPUIMYQWlDmNHAqFstJ)
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKr.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(vLpSXVndRxiTPUIMYQWlDmNHAqFseu))
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsKg:
   try:
    f=vLpSXVndRxiTPUIMYQWlDmNHAqFsGu(vLpSXVndRxiTPUIMYQWlDmNHAqFseE,'w',-1,'utf-8')
    vLpSXVndRxiTPUIMYQWlDmNHAqFstK=requests.get(vLpSXVndRxiTPUIMYQWlDmNHAqFsKg)
    vLpSXVndRxiTPUIMYQWlDmNHAqFstw=vLpSXVndRxiTPUIMYQWlDmNHAqFstK.content.decode('utf-8') 
    for vLpSXVndRxiTPUIMYQWlDmNHAqFstG in vLpSXVndRxiTPUIMYQWlDmNHAqFstw.splitlines():
     vLpSXVndRxiTPUIMYQWlDmNHAqFstu=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',vLpSXVndRxiTPUIMYQWlDmNHAqFstG)
     f.write(vLpSXVndRxiTPUIMYQWlDmNHAqFstu+'\n')
    f.close()
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKr.setSubtitles([vLpSXVndRxiTPUIMYQWlDmNHAqFseE,vLpSXVndRxiTPUIMYQWlDmNHAqFsKg])
   except:
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKr.setSubtitles([vLpSXVndRxiTPUIMYQWlDmNHAqFsKg])
  xbmcplugin.setResolvedUrl(vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_handle,vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ,vLpSXVndRxiTPUIMYQWlDmNHAqFsKr)
  try:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJb='movie' if vLpSXVndRxiTPUIMYQWlDmNHAqFsKj=='-' else 'seasons'
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={'code':vLpSXVndRxiTPUIMYQWlDmNHAqFsKO if vLpSXVndRxiTPUIMYQWlDmNHAqFsJb=='movie' else vLpSXVndRxiTPUIMYQWlDmNHAqFsKj,'img':vLpSXVndRxiTPUIMYQWlDmNHAqFsKB,'title':vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,'videoid':vLpSXVndRxiTPUIMYQWlDmNHAqFsKO}
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.Save_Watched_List(vLpSXVndRxiTPUIMYQWlDmNHAqFsJb,vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
  except:
   vLpSXVndRxiTPUIMYQWlDmNHAqFswz
 def dp_Category_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,args):
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.SaveCredential(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_winCredential())
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJb =args.get('stype')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKE =args.get('tag_id')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKu=args.get('api_path')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJc=vLpSXVndRxiTPUIMYQWlDmNHAqFswk(args.get('page'))
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJz =args.get('sort')
  vLpSXVndRxiTPUIMYQWlDmNHAqFstE,vLpSXVndRxiTPUIMYQWlDmNHAqFsth=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.GetCategoryList(vLpSXVndRxiTPUIMYQWlDmNHAqFsJb,vLpSXVndRxiTPUIMYQWlDmNHAqFsKE,vLpSXVndRxiTPUIMYQWlDmNHAqFsKu,vLpSXVndRxiTPUIMYQWlDmNHAqFsJc,vLpSXVndRxiTPUIMYQWlDmNHAqFsJz)
  for vLpSXVndRxiTPUIMYQWlDmNHAqFstO in vLpSXVndRxiTPUIMYQWlDmNHAqFstE:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKO =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('code')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJu =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('title')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstj =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('content_type')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstB =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('story')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKB =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('thumbnail')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsta =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('year')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstC =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('film_rating_code')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstg=vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('film_rating_short')
   if vLpSXVndRxiTPUIMYQWlDmNHAqFstj=='movies': 
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJj=vLpSXVndRxiTPUIMYQWlDmNHAqFsGe
    vLpSXVndRxiTPUIMYQWlDmNHAqFsty ='MOVIE'
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJB=''
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKj='-'
   else: 
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJj=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ
    vLpSXVndRxiTPUIMYQWlDmNHAqFsty ='EPISODE'
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJB='Series'
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKj=vLpSXVndRxiTPUIMYQWlDmNHAqFsKO
   vLpSXVndRxiTPUIMYQWlDmNHAqFstf=vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('info')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstf['plot']='%s (%s)\n년도 : %s\n\n%s'%(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,vLpSXVndRxiTPUIMYQWlDmNHAqFstg,vLpSXVndRxiTPUIMYQWlDmNHAqFsta,vLpSXVndRxiTPUIMYQWlDmNHAqFstB)
   if vLpSXVndRxiTPUIMYQWlDmNHAqFstC>=19:
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJu+='  (%s년 - %s)'%(vLpSXVndRxiTPUIMYQWlDmNHAqFsta,vLpSXVndRxiTPUIMYQWlDmNHAqFsGw(vLpSXVndRxiTPUIMYQWlDmNHAqFstg))
   else:
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJu+='  (%s년)'%(vLpSXVndRxiTPUIMYQWlDmNHAqFsta)
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={'mode':vLpSXVndRxiTPUIMYQWlDmNHAqFsty,'movie_code':vLpSXVndRxiTPUIMYQWlDmNHAqFsKO,'page':'1','season_code':vLpSXVndRxiTPUIMYQWlDmNHAqFsKj,'title':vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,'thumbnail':vLpSXVndRxiTPUIMYQWlDmNHAqFsKB}
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel=vLpSXVndRxiTPUIMYQWlDmNHAqFsJB,img=vLpSXVndRxiTPUIMYQWlDmNHAqFsKB,infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFstf,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsJj,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsth:
   if vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.GetCategoryList_morepage(vLpSXVndRxiTPUIMYQWlDmNHAqFsJb,vLpSXVndRxiTPUIMYQWlDmNHAqFsKE,vLpSXVndRxiTPUIMYQWlDmNHAqFsKu,vLpSXVndRxiTPUIMYQWlDmNHAqFsJc+1,vLpSXVndRxiTPUIMYQWlDmNHAqFsJz):
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={}
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['mode'] ='CATEGORY_LIST'
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['stype'] =vLpSXVndRxiTPUIMYQWlDmNHAqFsJb
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['tag_id'] =vLpSXVndRxiTPUIMYQWlDmNHAqFsKE
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['api_path']=vLpSXVndRxiTPUIMYQWlDmNHAqFsKu
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['page'] =vLpSXVndRxiTPUIMYQWlDmNHAqFsGw(vLpSXVndRxiTPUIMYQWlDmNHAqFsJc+1)
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['sort'] =vLpSXVndRxiTPUIMYQWlDmNHAqFsJz
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJu='[B]%s >>[/B]'%'다음 페이지'
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKh=vLpSXVndRxiTPUIMYQWlDmNHAqFsGw(vLpSXVndRxiTPUIMYQWlDmNHAqFsJc+1)
    vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel=vLpSXVndRxiTPUIMYQWlDmNHAqFsKh,img='',infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFswz,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsGK(vLpSXVndRxiTPUIMYQWlDmNHAqFstE)>0:
   if vLpSXVndRxiTPUIMYQWlDmNHAqFsKu=='arrivals/latest':
    xbmcplugin.endOfDirectory(vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_handle,cacheToDisc=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ)
   else:
    xbmcplugin.endOfDirectory(vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_handle,cacheToDisc=vLpSXVndRxiTPUIMYQWlDmNHAqFsGe)
 def dp_Episode_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,args):
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.SaveCredential(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_winCredential())
  vLpSXVndRxiTPUIMYQWlDmNHAqFsto=args.get('movie_code')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJc =vLpSXVndRxiTPUIMYQWlDmNHAqFswk(args.get('page'))
  vLpSXVndRxiTPUIMYQWlDmNHAqFsKj =args.get('season_code')
  vLpSXVndRxiTPUIMYQWlDmNHAqFstE,vLpSXVndRxiTPUIMYQWlDmNHAqFsth=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.GetEpisodoList(vLpSXVndRxiTPUIMYQWlDmNHAqFsto,vLpSXVndRxiTPUIMYQWlDmNHAqFsJc,orderby=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_winEpisodeOrderby())
  for vLpSXVndRxiTPUIMYQWlDmNHAqFstO in vLpSXVndRxiTPUIMYQWlDmNHAqFstE:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKO =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('code')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJu =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('title')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKB =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('thumbnail')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstb =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('display_num')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstc=vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('season_title')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstf=vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('info')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstf['plot']='%s\n%s\n\n%s'%(vLpSXVndRxiTPUIMYQWlDmNHAqFstc,vLpSXVndRxiTPUIMYQWlDmNHAqFstb,vLpSXVndRxiTPUIMYQWlDmNHAqFsJu)
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJu='(%s) %s'%(vLpSXVndRxiTPUIMYQWlDmNHAqFstb,vLpSXVndRxiTPUIMYQWlDmNHAqFsJu)
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={'mode':'MOVIE','movie_code':vLpSXVndRxiTPUIMYQWlDmNHAqFsKO,'season_code':vLpSXVndRxiTPUIMYQWlDmNHAqFsKj,'title':'%s < %s >'%(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,vLpSXVndRxiTPUIMYQWlDmNHAqFstc),'thumbnail':vLpSXVndRxiTPUIMYQWlDmNHAqFsKB}
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel=vLpSXVndRxiTPUIMYQWlDmNHAqFstc,img=vLpSXVndRxiTPUIMYQWlDmNHAqFsKB,infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFstf,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsGe,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsJc==1:
   vLpSXVndRxiTPUIMYQWlDmNHAqFstf={'plot':'정렬순서를 변경합니다.'}
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={}
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['mode'] ='ORDER_BY' 
   if vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_winEpisodeOrderby()=='desc':
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJu='정렬순서변경 : 최신화부터 -> 1회부터'
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['orderby']='asc'
   else:
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJu='정렬순서변경 : 1회부터 -> 최신화부터'
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['orderby']='desc'
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel='',img='',infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFstf,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsGe,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsth:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['mode'] ='EPISODE' 
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['movie_code']=vLpSXVndRxiTPUIMYQWlDmNHAqFsto
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['page'] =vLpSXVndRxiTPUIMYQWlDmNHAqFsGw(vLpSXVndRxiTPUIMYQWlDmNHAqFsJc+1)
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJu='[B]%s >>[/B]'%'다음 페이지'
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKh=vLpSXVndRxiTPUIMYQWlDmNHAqFsGw(vLpSXVndRxiTPUIMYQWlDmNHAqFsJc+1)
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel=vLpSXVndRxiTPUIMYQWlDmNHAqFsKh,img='',infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFswz,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsGK(vLpSXVndRxiTPUIMYQWlDmNHAqFstE)>0:xbmcplugin.endOfDirectory(vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_handle,cacheToDisc=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ)
 def dp_Search_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,args):
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.SaveCredential(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_winCredential())
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJc =vLpSXVndRxiTPUIMYQWlDmNHAqFswk(args.get('page'))
  if 'search_key' in args:
   vLpSXVndRxiTPUIMYQWlDmNHAqFstz=args.get('search_key')
  else:
   vLpSXVndRxiTPUIMYQWlDmNHAqFstz=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not vLpSXVndRxiTPUIMYQWlDmNHAqFstz:return
  vLpSXVndRxiTPUIMYQWlDmNHAqFstE,vLpSXVndRxiTPUIMYQWlDmNHAqFsth=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.GetSearchList(vLpSXVndRxiTPUIMYQWlDmNHAqFstz,vLpSXVndRxiTPUIMYQWlDmNHAqFsJc)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsGK(vLpSXVndRxiTPUIMYQWlDmNHAqFstE)==0:return
  for vLpSXVndRxiTPUIMYQWlDmNHAqFstO in vLpSXVndRxiTPUIMYQWlDmNHAqFstE:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKO =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('code')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJu =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('title')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstj=vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('content_type')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstB =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('story')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKB =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('thumbnail')
   vLpSXVndRxiTPUIMYQWlDmNHAqFsta =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('year')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstC =vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('film_rating_code')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstg=vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('film_rating_short')
   if vLpSXVndRxiTPUIMYQWlDmNHAqFstj=='movies': 
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJj=vLpSXVndRxiTPUIMYQWlDmNHAqFsGe
    vLpSXVndRxiTPUIMYQWlDmNHAqFsty ='MOVIE'
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJB=''
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKj='-'
   else: 
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJj=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ
    vLpSXVndRxiTPUIMYQWlDmNHAqFsty ='EPISODE'
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJB='Series'
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKj=vLpSXVndRxiTPUIMYQWlDmNHAqFsKO
   vLpSXVndRxiTPUIMYQWlDmNHAqFstf=vLpSXVndRxiTPUIMYQWlDmNHAqFstO.get('info')
   vLpSXVndRxiTPUIMYQWlDmNHAqFstf['plot']='%s (%s)\n년도 : %s\n\n%s'%(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,vLpSXVndRxiTPUIMYQWlDmNHAqFstg,vLpSXVndRxiTPUIMYQWlDmNHAqFsta,vLpSXVndRxiTPUIMYQWlDmNHAqFstB)
   if vLpSXVndRxiTPUIMYQWlDmNHAqFstC>=19:
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJu+='  (%s년 - %s)'%(vLpSXVndRxiTPUIMYQWlDmNHAqFsta,vLpSXVndRxiTPUIMYQWlDmNHAqFsGw(vLpSXVndRxiTPUIMYQWlDmNHAqFstg))
   else:
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJu+='  (%s년)'%(vLpSXVndRxiTPUIMYQWlDmNHAqFsta)
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={'mode':vLpSXVndRxiTPUIMYQWlDmNHAqFsty,'movie_code':vLpSXVndRxiTPUIMYQWlDmNHAqFsKO,'page':'1','season_code':vLpSXVndRxiTPUIMYQWlDmNHAqFsKj,'title':vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,'thumbnail':vLpSXVndRxiTPUIMYQWlDmNHAqFsKB}
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel=vLpSXVndRxiTPUIMYQWlDmNHAqFsJB,img=vLpSXVndRxiTPUIMYQWlDmNHAqFsKB,infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFstf,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsJj,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsth:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={}
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['mode'] ='SEARCH'
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['search_key']=vLpSXVndRxiTPUIMYQWlDmNHAqFstz
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO['page'] =vLpSXVndRxiTPUIMYQWlDmNHAqFsGw(vLpSXVndRxiTPUIMYQWlDmNHAqFsJc+1)
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJu='[B]%s >>[/B]'%'다음 페이지'
   vLpSXVndRxiTPUIMYQWlDmNHAqFsKh=vLpSXVndRxiTPUIMYQWlDmNHAqFsGw(vLpSXVndRxiTPUIMYQWlDmNHAqFsJc+1)
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel=vLpSXVndRxiTPUIMYQWlDmNHAqFsKh,img='',infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFswz,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsGK(vLpSXVndRxiTPUIMYQWlDmNHAqFstE)>0:xbmcplugin.endOfDirectory(vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_handle)
 def Delete_Watched_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,vLpSXVndRxiTPUIMYQWlDmNHAqFsJb):
  try:
   vLpSXVndRxiTPUIMYQWlDmNHAqFstk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vLpSXVndRxiTPUIMYQWlDmNHAqFsJb))
   fp=vLpSXVndRxiTPUIMYQWlDmNHAqFsGu(vLpSXVndRxiTPUIMYQWlDmNHAqFstk,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   vLpSXVndRxiTPUIMYQWlDmNHAqFswz
 def dp_WatchList_Delete(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,args):
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJb=args.get('stype')
  vLpSXVndRxiTPUIMYQWlDmNHAqFseg=xbmcgui.Dialog()
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJy=vLpSXVndRxiTPUIMYQWlDmNHAqFseg.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsJy==vLpSXVndRxiTPUIMYQWlDmNHAqFsGe:sys.exit()
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.Delete_Watched_List(vLpSXVndRxiTPUIMYQWlDmNHAqFsJb)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,vLpSXVndRxiTPUIMYQWlDmNHAqFsJb):
  try:
   vLpSXVndRxiTPUIMYQWlDmNHAqFstk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vLpSXVndRxiTPUIMYQWlDmNHAqFsJb))
   fp=vLpSXVndRxiTPUIMYQWlDmNHAqFsGu(vLpSXVndRxiTPUIMYQWlDmNHAqFstk,'r',-1,'utf-8')
   vLpSXVndRxiTPUIMYQWlDmNHAqFswe=fp.readlines()
   fp.close()
  except:
   vLpSXVndRxiTPUIMYQWlDmNHAqFswe=[]
  return vLpSXVndRxiTPUIMYQWlDmNHAqFswe
 def Save_Watched_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,vLpSXVndRxiTPUIMYQWlDmNHAqFsJb,vLpSXVndRxiTPUIMYQWlDmNHAqFsea):
  try:
   vLpSXVndRxiTPUIMYQWlDmNHAqFstk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vLpSXVndRxiTPUIMYQWlDmNHAqFsJb))
   vLpSXVndRxiTPUIMYQWlDmNHAqFswJ=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.Load_Watched_List(vLpSXVndRxiTPUIMYQWlDmNHAqFsJb) 
   fp=vLpSXVndRxiTPUIMYQWlDmNHAqFsGu(vLpSXVndRxiTPUIMYQWlDmNHAqFstk,'w',-1,'utf-8')
   vLpSXVndRxiTPUIMYQWlDmNHAqFswK=urllib.parse.urlencode(vLpSXVndRxiTPUIMYQWlDmNHAqFsea)
   vLpSXVndRxiTPUIMYQWlDmNHAqFswK=vLpSXVndRxiTPUIMYQWlDmNHAqFswK+'\n'
   fp.write(vLpSXVndRxiTPUIMYQWlDmNHAqFswK)
   vLpSXVndRxiTPUIMYQWlDmNHAqFswt=0
   for vLpSXVndRxiTPUIMYQWlDmNHAqFswG in vLpSXVndRxiTPUIMYQWlDmNHAqFswJ:
    vLpSXVndRxiTPUIMYQWlDmNHAqFswu=vLpSXVndRxiTPUIMYQWlDmNHAqFsGE(urllib.parse.parse_qsl(vLpSXVndRxiTPUIMYQWlDmNHAqFswG))
    vLpSXVndRxiTPUIMYQWlDmNHAqFswE=vLpSXVndRxiTPUIMYQWlDmNHAqFsea.get('code').strip()
    vLpSXVndRxiTPUIMYQWlDmNHAqFswh=vLpSXVndRxiTPUIMYQWlDmNHAqFswu.get('code').strip()
    if vLpSXVndRxiTPUIMYQWlDmNHAqFsJb=='seasons' and vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_settings_direct_replay()==vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ:
     vLpSXVndRxiTPUIMYQWlDmNHAqFswE=vLpSXVndRxiTPUIMYQWlDmNHAqFsea.get('videoid').strip()
     vLpSXVndRxiTPUIMYQWlDmNHAqFswh=vLpSXVndRxiTPUIMYQWlDmNHAqFswu.get('videoid').strip()if vLpSXVndRxiTPUIMYQWlDmNHAqFswh!=vLpSXVndRxiTPUIMYQWlDmNHAqFswz else '-'
    if vLpSXVndRxiTPUIMYQWlDmNHAqFswE!=vLpSXVndRxiTPUIMYQWlDmNHAqFswh:
     fp.write(vLpSXVndRxiTPUIMYQWlDmNHAqFswG)
     vLpSXVndRxiTPUIMYQWlDmNHAqFswt+=1
     if vLpSXVndRxiTPUIMYQWlDmNHAqFswt>=50:break
   fp.close()
  except:
   vLpSXVndRxiTPUIMYQWlDmNHAqFswz
 def dp_Watch_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO,args):
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJb =args.get('stype')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJe=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.get_settings_direct_replay()
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsJb=='-':
   for vLpSXVndRxiTPUIMYQWlDmNHAqFswO in vLpSXVndRxiTPUIMYQWlDmNHAqFset:
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJu=vLpSXVndRxiTPUIMYQWlDmNHAqFswO.get('title')
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={'mode':vLpSXVndRxiTPUIMYQWlDmNHAqFswO.get('mode'),'stype':vLpSXVndRxiTPUIMYQWlDmNHAqFswO.get('stype')}
    vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel='',img='',infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFswz,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
   if vLpSXVndRxiTPUIMYQWlDmNHAqFsGK(vLpSXVndRxiTPUIMYQWlDmNHAqFset)>0:xbmcplugin.endOfDirectory(vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_handle)
  else:
   vLpSXVndRxiTPUIMYQWlDmNHAqFswj=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.Load_Watched_List(vLpSXVndRxiTPUIMYQWlDmNHAqFsJb)
   for vLpSXVndRxiTPUIMYQWlDmNHAqFswB in vLpSXVndRxiTPUIMYQWlDmNHAqFswj:
    vLpSXVndRxiTPUIMYQWlDmNHAqFswa=vLpSXVndRxiTPUIMYQWlDmNHAqFsGE(urllib.parse.parse_qsl(vLpSXVndRxiTPUIMYQWlDmNHAqFswB))
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKO=vLpSXVndRxiTPUIMYQWlDmNHAqFswa.get('code').strip()
    vLpSXVndRxiTPUIMYQWlDmNHAqFsJu =vLpSXVndRxiTPUIMYQWlDmNHAqFswa.get('title').strip()
    vLpSXVndRxiTPUIMYQWlDmNHAqFsKB =vLpSXVndRxiTPUIMYQWlDmNHAqFswa.get('img').strip()
    vLpSXVndRxiTPUIMYQWlDmNHAqFswC =vLpSXVndRxiTPUIMYQWlDmNHAqFswa.get('videoid').strip()
    vLpSXVndRxiTPUIMYQWlDmNHAqFstf={}
    vLpSXVndRxiTPUIMYQWlDmNHAqFstf['plot']=vLpSXVndRxiTPUIMYQWlDmNHAqFsJu
    if vLpSXVndRxiTPUIMYQWlDmNHAqFsJb=='movie':
     vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={'mode':'MOVIE','page':'1','movie_code':vLpSXVndRxiTPUIMYQWlDmNHAqFsKO,'season_code':'-','title':vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,'thumbnail':vLpSXVndRxiTPUIMYQWlDmNHAqFsKB}
     vLpSXVndRxiTPUIMYQWlDmNHAqFsJj=vLpSXVndRxiTPUIMYQWlDmNHAqFsGe
    else:
     if vLpSXVndRxiTPUIMYQWlDmNHAqFsJe==vLpSXVndRxiTPUIMYQWlDmNHAqFsGe or vLpSXVndRxiTPUIMYQWlDmNHAqFswC==vLpSXVndRxiTPUIMYQWlDmNHAqFswz:
      vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={'mode':'EPISODE','page':'1','movie_code':vLpSXVndRxiTPUIMYQWlDmNHAqFsKO,'season_code':vLpSXVndRxiTPUIMYQWlDmNHAqFsKO,'title':vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,'thumbnail':vLpSXVndRxiTPUIMYQWlDmNHAqFsKB}
      vLpSXVndRxiTPUIMYQWlDmNHAqFsJj=vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ
     else:
      vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={'mode':'MOVIE','movie_code':vLpSXVndRxiTPUIMYQWlDmNHAqFswC,'season_code':vLpSXVndRxiTPUIMYQWlDmNHAqFsKO,'title':vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,'thumbnail':vLpSXVndRxiTPUIMYQWlDmNHAqFsKB}
      vLpSXVndRxiTPUIMYQWlDmNHAqFsJj=vLpSXVndRxiTPUIMYQWlDmNHAqFsGe
    vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel='',img=vLpSXVndRxiTPUIMYQWlDmNHAqFsKB,infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFstf,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsJj,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
   vLpSXVndRxiTPUIMYQWlDmNHAqFstf={'plot':'시청목록을 삭제합니다.'}
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJu='*** 시청목록 삭제 ***'
   vLpSXVndRxiTPUIMYQWlDmNHAqFsJO={'mode':'MYVIEW_REMOVE','stype':vLpSXVndRxiTPUIMYQWlDmNHAqFsJb}
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.add_dir(vLpSXVndRxiTPUIMYQWlDmNHAqFsJu,sublabel='',img='',infoLabels=vLpSXVndRxiTPUIMYQWlDmNHAqFstf,isFolder=vLpSXVndRxiTPUIMYQWlDmNHAqFsGe,params=vLpSXVndRxiTPUIMYQWlDmNHAqFsJO)
   xbmcplugin.endOfDirectory(vLpSXVndRxiTPUIMYQWlDmNHAqFseO._addon_handle,cacheToDisc=vLpSXVndRxiTPUIMYQWlDmNHAqFsGe)
 def logout(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  vLpSXVndRxiTPUIMYQWlDmNHAqFseg=xbmcgui.Dialog()
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJy=vLpSXVndRxiTPUIMYQWlDmNHAqFseg.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsJy==vLpSXVndRxiTPUIMYQWlDmNHAqFsGe:sys.exit()
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.wininfo_clear()
  if os.path.isfile(vLpSXVndRxiTPUIMYQWlDmNHAqFseh):os.remove(vLpSXVndRxiTPUIMYQWlDmNHAqFseh)
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK=xbmcgui.Window(10000)
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_TOKEN','')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_GUIT','')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_GUITV','')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_USERCD','')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  vLpSXVndRxiTPUIMYQWlDmNHAqFswg =vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.Get_Now_Datetime()
  vLpSXVndRxiTPUIMYQWlDmNHAqFswy=vLpSXVndRxiTPUIMYQWlDmNHAqFswg+datetime.timedelta(days=vLpSXVndRxiTPUIMYQWlDmNHAqFswk(__addon__.getSetting('cache_ttl')))
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK=xbmcgui.Window(10000)
  vLpSXVndRxiTPUIMYQWlDmNHAqFswf={'watcha_token':vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.getProperty('WATCHA_M_TOKEN'),'watcha_guit':vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.getProperty('WATCHA_M_GUIT'),'watcha_guitv':vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.getProperty('WATCHA_M_GUITV'),'watcha_usercd':vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':vLpSXVndRxiTPUIMYQWlDmNHAqFswy.strftime('%Y-%m-%d')}
  try: 
   fp=vLpSXVndRxiTPUIMYQWlDmNHAqFsGu(vLpSXVndRxiTPUIMYQWlDmNHAqFseh,'w',-1,'utf-8')
   json.dump(vLpSXVndRxiTPUIMYQWlDmNHAqFswf,fp)
   fp.close()
  except vLpSXVndRxiTPUIMYQWlDmNHAqFsGh as exception:
   vLpSXVndRxiTPUIMYQWlDmNHAqFsGO(exception)
 def cookiefile_check(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  vLpSXVndRxiTPUIMYQWlDmNHAqFswf={}
  try: 
   fp=vLpSXVndRxiTPUIMYQWlDmNHAqFsGu(vLpSXVndRxiTPUIMYQWlDmNHAqFseh,'r',-1,'utf-8')
   vLpSXVndRxiTPUIMYQWlDmNHAqFswf= json.load(fp)
   fp.close()
  except vLpSXVndRxiTPUIMYQWlDmNHAqFsGh as exception:
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.wininfo_clear()
   return vLpSXVndRxiTPUIMYQWlDmNHAqFsGe
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJa =__addon__.getSetting('id')
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJC =__addon__.getSetting('pw')
  vLpSXVndRxiTPUIMYQWlDmNHAqFswr =__addon__.getSetting('selected_profile')
  vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_id']=base64.standard_b64decode(vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_id']).decode('utf-8')
  vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_pw']=base64.standard_b64decode(vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_pw']).decode('utf-8')
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsJa!=vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_id']or vLpSXVndRxiTPUIMYQWlDmNHAqFsJC!=vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_pw']or vLpSXVndRxiTPUIMYQWlDmNHAqFswr!=vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_profile']:
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.wininfo_clear()
   return vLpSXVndRxiTPUIMYQWlDmNHAqFsGe
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJf =vLpSXVndRxiTPUIMYQWlDmNHAqFswk(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  vLpSXVndRxiTPUIMYQWlDmNHAqFswo=vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_limitdate']
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJr =vLpSXVndRxiTPUIMYQWlDmNHAqFswk(re.sub('-','',vLpSXVndRxiTPUIMYQWlDmNHAqFswo))
  if vLpSXVndRxiTPUIMYQWlDmNHAqFsJr<vLpSXVndRxiTPUIMYQWlDmNHAqFsJf:
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.wininfo_clear()
   return vLpSXVndRxiTPUIMYQWlDmNHAqFsGe
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK=xbmcgui.Window(10000)
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_TOKEN',vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_token'])
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_GUIT',vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_guit'])
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_GUITV',vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_guitv'])
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_USERCD',vLpSXVndRxiTPUIMYQWlDmNHAqFswf['watcha_usercd'])
  vLpSXVndRxiTPUIMYQWlDmNHAqFsJK.setProperty('WATCHA_M_LOGINTIME',vLpSXVndRxiTPUIMYQWlDmNHAqFswo)
  return vLpSXVndRxiTPUIMYQWlDmNHAqFsGJ
 def watcha_main(vLpSXVndRxiTPUIMYQWlDmNHAqFseO):
  vLpSXVndRxiTPUIMYQWlDmNHAqFswb=vLpSXVndRxiTPUIMYQWlDmNHAqFseO.main_params.get('mode',vLpSXVndRxiTPUIMYQWlDmNHAqFswz)
  if vLpSXVndRxiTPUIMYQWlDmNHAqFswb=='LOGOUT':
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.logout()
   return
  vLpSXVndRxiTPUIMYQWlDmNHAqFseO.login_main()
  if vLpSXVndRxiTPUIMYQWlDmNHAqFswb is vLpSXVndRxiTPUIMYQWlDmNHAqFswz:
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.dp_Main_List()
  elif vLpSXVndRxiTPUIMYQWlDmNHAqFswb=='SUB_GROUP':
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.dp_SubGroup_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.main_params)
  elif vLpSXVndRxiTPUIMYQWlDmNHAqFswb=='CATEGORY_LIST':
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.dp_Category_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.main_params)
  elif vLpSXVndRxiTPUIMYQWlDmNHAqFswb=='EPISODE':
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.dp_Episode_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.main_params)
  elif vLpSXVndRxiTPUIMYQWlDmNHAqFswb=='ORDER_BY':
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.dp_setEpOrderby(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.main_params)
  elif vLpSXVndRxiTPUIMYQWlDmNHAqFswb=='SEARCH':
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.dp_Search_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.main_params)
  elif vLpSXVndRxiTPUIMYQWlDmNHAqFswb=='MOVIE':
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.play_VIDEO(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.main_params)
  elif vLpSXVndRxiTPUIMYQWlDmNHAqFswb=='WATCH':
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.dp_Watch_List(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.main_params)
  elif vLpSXVndRxiTPUIMYQWlDmNHAqFswb=='MYVIEW_REMOVE':
   vLpSXVndRxiTPUIMYQWlDmNHAqFseO.dp_WatchList_Delete(vLpSXVndRxiTPUIMYQWlDmNHAqFseO.main_params)
  else:
   vLpSXVndRxiTPUIMYQWlDmNHAqFswz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
