__author__="NightRain"
YubxFwIWAkTsULrdaqGfJnElpCPNVy=object
YubxFwIWAkTsULrdaqGfJnElpCPNVe=None
YubxFwIWAkTsULrdaqGfJnElpCPNVh=False
YubxFwIWAkTsULrdaqGfJnElpCPNVX=True
YubxFwIWAkTsULrdaqGfJnElpCPNVc=Exception
YubxFwIWAkTsULrdaqGfJnElpCPNVj=print
YubxFwIWAkTsULrdaqGfJnElpCPNVM=str
YubxFwIWAkTsULrdaqGfJnElpCPNVQ=len
YubxFwIWAkTsULrdaqGfJnElpCPNVt=int
YubxFwIWAkTsULrdaqGfJnElpCPNVS=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import base64
import requests
import datetime
YubxFwIWAkTsULrdaqGfJnElpCPNyh='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
class YubxFwIWAkTsULrdaqGfJnElpCPNye(YubxFwIWAkTsULrdaqGfJnElpCPNVy):
 def __init__(YubxFwIWAkTsULrdaqGfJnElpCPNyV):
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_TOKEN ='' 
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUIT =''
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUITV =''
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_USERCD=''
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.API_DOMAIN ='https://play.watcha.net'
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.EPISODE_LIMIT=20
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.SEARCH_LIMIT =30
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.DEFAULT_HEADER={'user-agent':YubxFwIWAkTsULrdaqGfJnElpCPNyh,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(YubxFwIWAkTsULrdaqGfJnElpCPNyV,jobtype,YubxFwIWAkTsULrdaqGfJnElpCPNyz,payload=YubxFwIWAkTsULrdaqGfJnElpCPNVe,params=YubxFwIWAkTsULrdaqGfJnElpCPNVe,headers=YubxFwIWAkTsULrdaqGfJnElpCPNVe,cookies=YubxFwIWAkTsULrdaqGfJnElpCPNVe,redirects=YubxFwIWAkTsULrdaqGfJnElpCPNVh):
  YubxFwIWAkTsULrdaqGfJnElpCPNyX=YubxFwIWAkTsULrdaqGfJnElpCPNyV.DEFAULT_HEADER
  if headers:YubxFwIWAkTsULrdaqGfJnElpCPNyX.update(headers)
  if jobtype=='Get':
   YubxFwIWAkTsULrdaqGfJnElpCPNyc=requests.get(YubxFwIWAkTsULrdaqGfJnElpCPNyz,params=params,headers=YubxFwIWAkTsULrdaqGfJnElpCPNyX,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   YubxFwIWAkTsULrdaqGfJnElpCPNyc=requests.put(YubxFwIWAkTsULrdaqGfJnElpCPNyz,data=payload,params=params,headers=YubxFwIWAkTsULrdaqGfJnElpCPNyX,cookies=cookies,allow_redirects=redirects)
  else:
   YubxFwIWAkTsULrdaqGfJnElpCPNyc=requests.post(YubxFwIWAkTsULrdaqGfJnElpCPNyz,data=payload,params=params,headers=YubxFwIWAkTsULrdaqGfJnElpCPNyX,cookies=cookies,allow_redirects=redirects)
  return YubxFwIWAkTsULrdaqGfJnElpCPNyc
 def SaveCredential(YubxFwIWAkTsULrdaqGfJnElpCPNyV,YubxFwIWAkTsULrdaqGfJnElpCPNyj):
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_TOKEN =YubxFwIWAkTsULrdaqGfJnElpCPNyj.get('watcha_token')
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUIT =YubxFwIWAkTsULrdaqGfJnElpCPNyj.get('watcha_guit')
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUITV =YubxFwIWAkTsULrdaqGfJnElpCPNyj.get('watcha_guitv')
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_USERCD =YubxFwIWAkTsULrdaqGfJnElpCPNyj.get('watcha_usercd')
 def SaveCredential_usercd(YubxFwIWAkTsULrdaqGfJnElpCPNyV,YubxFwIWAkTsULrdaqGfJnElpCPNyM):
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_USERCD=YubxFwIWAkTsULrdaqGfJnElpCPNyM
 def SaveCredential_guitv(YubxFwIWAkTsULrdaqGfJnElpCPNyV,YubxFwIWAkTsULrdaqGfJnElpCPNyQ,YubxFwIWAkTsULrdaqGfJnElpCPNyt):
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUITV=YubxFwIWAkTsULrdaqGfJnElpCPNyQ
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_TOKEN=YubxFwIWAkTsULrdaqGfJnElpCPNyt 
 def ClearCredential(YubxFwIWAkTsULrdaqGfJnElpCPNyV):
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_TOKEN ='' 
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUIT =''
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUITV =''
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_USERCD=''
 def LoadCredential(YubxFwIWAkTsULrdaqGfJnElpCPNyV):
  YubxFwIWAkTsULrdaqGfJnElpCPNyj={'watcha_token':YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_TOKEN,'watcha_guit':YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUIT,'watcha_guitv':YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUITV,'watcha_usercd':YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_USERCD}
  return YubxFwIWAkTsULrdaqGfJnElpCPNyj
 def makeDefaultCookies(YubxFwIWAkTsULrdaqGfJnElpCPNyV):
  YubxFwIWAkTsULrdaqGfJnElpCPNyS={'_s_guit':YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUIT,'_guinness-premium_session':YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_TOKEN}
  if YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUITV:
   YubxFwIWAkTsULrdaqGfJnElpCPNyS['_s_guitv']=YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_GUITV
  return YubxFwIWAkTsULrdaqGfJnElpCPNyS
 def makeurl(YubxFwIWAkTsULrdaqGfJnElpCPNyV,domain,path,query1=YubxFwIWAkTsULrdaqGfJnElpCPNVe,query2=YubxFwIWAkTsULrdaqGfJnElpCPNVe):
  YubxFwIWAkTsULrdaqGfJnElpCPNyz=domain+path
  if query1:
   YubxFwIWAkTsULrdaqGfJnElpCPNyz+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   YubxFwIWAkTsULrdaqGfJnElpCPNyz+='&%s'%urllib.parse.urlencode(query2)
  return YubxFwIWAkTsULrdaqGfJnElpCPNyz
 def GetCredential(YubxFwIWAkTsULrdaqGfJnElpCPNyV,user_id,user_pw,user_pf):
  YubxFwIWAkTsULrdaqGfJnElpCPNyg=YubxFwIWAkTsULrdaqGfJnElpCPNVh
  YubxFwIWAkTsULrdaqGfJnElpCPNyR=YubxFwIWAkTsULrdaqGfJnElpCPNyB='-'
  try:
   YubxFwIWAkTsULrdaqGfJnElpCPNyi=YubxFwIWAkTsULrdaqGfJnElpCPNyV.API_DOMAIN+'/api/session'
   YubxFwIWAkTsULrdaqGfJnElpCPNyo={'email':user_id,'password':user_pw}
   YubxFwIWAkTsULrdaqGfJnElpCPNyK={'accept':'application/vnd.frograms+json;version=4'}
   YubxFwIWAkTsULrdaqGfJnElpCPNym=YubxFwIWAkTsULrdaqGfJnElpCPNyV.callRequestCookies('Post',YubxFwIWAkTsULrdaqGfJnElpCPNyi,payload=YubxFwIWAkTsULrdaqGfJnElpCPNyo,params=YubxFwIWAkTsULrdaqGfJnElpCPNVe,headers=YubxFwIWAkTsULrdaqGfJnElpCPNyK,cookies=YubxFwIWAkTsULrdaqGfJnElpCPNVe)
   for YubxFwIWAkTsULrdaqGfJnElpCPNyD in YubxFwIWAkTsULrdaqGfJnElpCPNym.cookies:
    if YubxFwIWAkTsULrdaqGfJnElpCPNyD.name=='_guinness-premium_session':
     YubxFwIWAkTsULrdaqGfJnElpCPNyB=YubxFwIWAkTsULrdaqGfJnElpCPNyD.value
    elif YubxFwIWAkTsULrdaqGfJnElpCPNyD.name=='_s_guit':
     YubxFwIWAkTsULrdaqGfJnElpCPNyR=YubxFwIWAkTsULrdaqGfJnElpCPNyD.value
   if YubxFwIWAkTsULrdaqGfJnElpCPNyB:YubxFwIWAkTsULrdaqGfJnElpCPNyg=YubxFwIWAkTsULrdaqGfJnElpCPNVX
  except YubxFwIWAkTsULrdaqGfJnElpCPNVc as exception:
   YubxFwIWAkTsULrdaqGfJnElpCPNVj(exception)
   YubxFwIWAkTsULrdaqGfJnElpCPNyR=YubxFwIWAkTsULrdaqGfJnElpCPNyB='' 
  YubxFwIWAkTsULrdaqGfJnElpCPNyj={'watcha_guit':YubxFwIWAkTsULrdaqGfJnElpCPNyR,'watcha_token':YubxFwIWAkTsULrdaqGfJnElpCPNyB,'watcha_guitv':'','watcha_usercd':''}
  YubxFwIWAkTsULrdaqGfJnElpCPNyV.SaveCredential(YubxFwIWAkTsULrdaqGfJnElpCPNyj)
  try:
   YubxFwIWAkTsULrdaqGfJnElpCPNyH=YubxFwIWAkTsULrdaqGfJnElpCPNyV.GetProfilesList()
   YubxFwIWAkTsULrdaqGfJnElpCPNey =YubxFwIWAkTsULrdaqGfJnElpCPNyH[user_pf]
   YubxFwIWAkTsULrdaqGfJnElpCPNyV.SaveCredential_usercd(YubxFwIWAkTsULrdaqGfJnElpCPNey)
  except YubxFwIWAkTsULrdaqGfJnElpCPNVc as exception:
   YubxFwIWAkTsULrdaqGfJnElpCPNVj(exception)
   YubxFwIWAkTsULrdaqGfJnElpCPNyV.ClearCredential()
   return YubxFwIWAkTsULrdaqGfJnElpCPNVh
  if user_pf!=0:
   YubxFwIWAkTsULrdaqGfJnElpCPNyQ,YubxFwIWAkTsULrdaqGfJnElpCPNyt=YubxFwIWAkTsULrdaqGfJnElpCPNyV.GetProfilesConvert(YubxFwIWAkTsULrdaqGfJnElpCPNey)
   YubxFwIWAkTsULrdaqGfJnElpCPNyV.SaveCredential_guitv(YubxFwIWAkTsULrdaqGfJnElpCPNyQ,YubxFwIWAkTsULrdaqGfJnElpCPNyt)
  return YubxFwIWAkTsULrdaqGfJnElpCPNyg
 def GetSubGroupList(YubxFwIWAkTsULrdaqGfJnElpCPNyV,stype):
  YubxFwIWAkTsULrdaqGfJnElpCPNeh=[]
  try:
   YubxFwIWAkTsULrdaqGfJnElpCPNeV ='/api/categories.json'
   YubxFwIWAkTsULrdaqGfJnElpCPNyz=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeurl(YubxFwIWAkTsULrdaqGfJnElpCPNyV.API_DOMAIN,YubxFwIWAkTsULrdaqGfJnElpCPNeV)
   YubxFwIWAkTsULrdaqGfJnElpCPNyD=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeDefaultCookies()
   YubxFwIWAkTsULrdaqGfJnElpCPNym=YubxFwIWAkTsULrdaqGfJnElpCPNyV.callRequestCookies('Get',YubxFwIWAkTsULrdaqGfJnElpCPNyz,payload=YubxFwIWAkTsULrdaqGfJnElpCPNVe,params=YubxFwIWAkTsULrdaqGfJnElpCPNVe,headers=YubxFwIWAkTsULrdaqGfJnElpCPNVe,cookies=YubxFwIWAkTsULrdaqGfJnElpCPNyD)
   YubxFwIWAkTsULrdaqGfJnElpCPNeX=json.loads(YubxFwIWAkTsULrdaqGfJnElpCPNym.text)
   if not('genres' in YubxFwIWAkTsULrdaqGfJnElpCPNeX):return YubxFwIWAkTsULrdaqGfJnElpCPNeh
   if stype=='genres':
    YubxFwIWAkTsULrdaqGfJnElpCPNec=YubxFwIWAkTsULrdaqGfJnElpCPNeX['genres']
   else:
    YubxFwIWAkTsULrdaqGfJnElpCPNec=YubxFwIWAkTsULrdaqGfJnElpCPNeX['tags']
   for YubxFwIWAkTsULrdaqGfJnElpCPNej in YubxFwIWAkTsULrdaqGfJnElpCPNec:
    YubxFwIWAkTsULrdaqGfJnElpCPNeM=YubxFwIWAkTsULrdaqGfJnElpCPNej['name']
    YubxFwIWAkTsULrdaqGfJnElpCPNeQ =YubxFwIWAkTsULrdaqGfJnElpCPNej['api_path']
    YubxFwIWAkTsULrdaqGfJnElpCPNet =YubxFwIWAkTsULrdaqGfJnElpCPNej['entity']['id']
    YubxFwIWAkTsULrdaqGfJnElpCPNeS={'group_name':YubxFwIWAkTsULrdaqGfJnElpCPNeM,'api_path':YubxFwIWAkTsULrdaqGfJnElpCPNeQ,'tag_id':YubxFwIWAkTsULrdaqGfJnElpCPNVM(YubxFwIWAkTsULrdaqGfJnElpCPNet)}
    YubxFwIWAkTsULrdaqGfJnElpCPNeh.append(YubxFwIWAkTsULrdaqGfJnElpCPNeS)
  except YubxFwIWAkTsULrdaqGfJnElpCPNVc as exception:
   YubxFwIWAkTsULrdaqGfJnElpCPNVj(exception)
  return YubxFwIWAkTsULrdaqGfJnElpCPNeh
 def GetCategoryList(YubxFwIWAkTsULrdaqGfJnElpCPNyV,stype,YubxFwIWAkTsULrdaqGfJnElpCPNet,YubxFwIWAkTsULrdaqGfJnElpCPNeQ,page_int,in_sort):
  YubxFwIWAkTsULrdaqGfJnElpCPNeh=[]
  YubxFwIWAkTsULrdaqGfJnElpCPNez=YubxFwIWAkTsULrdaqGfJnElpCPNVh
  YubxFwIWAkTsULrdaqGfJnElpCPNev={}
  try:
   if 'categories' in YubxFwIWAkTsULrdaqGfJnElpCPNeQ:
    YubxFwIWAkTsULrdaqGfJnElpCPNeV ='/api/categories/contents.json'
    if stype=='genres':
     YubxFwIWAkTsULrdaqGfJnElpCPNev['genre']=YubxFwIWAkTsULrdaqGfJnElpCPNet
    else:
     YubxFwIWAkTsULrdaqGfJnElpCPNev['tag'] =YubxFwIWAkTsULrdaqGfJnElpCPNet
    YubxFwIWAkTsULrdaqGfJnElpCPNev['order']=in_sort 
    if page_int>1:
     YubxFwIWAkTsULrdaqGfJnElpCPNev['page']=YubxFwIWAkTsULrdaqGfJnElpCPNVM(page_int-1)
   else: 
    YubxFwIWAkTsULrdaqGfJnElpCPNeV ='/api/'+YubxFwIWAkTsULrdaqGfJnElpCPNeQ+'.json'
    if page_int>1:
     YubxFwIWAkTsULrdaqGfJnElpCPNev['page']=YubxFwIWAkTsULrdaqGfJnElpCPNVM(page_int)
   YubxFwIWAkTsULrdaqGfJnElpCPNyz=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeurl(YubxFwIWAkTsULrdaqGfJnElpCPNyV.API_DOMAIN,YubxFwIWAkTsULrdaqGfJnElpCPNeV)
   YubxFwIWAkTsULrdaqGfJnElpCPNyD=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeDefaultCookies()
   YubxFwIWAkTsULrdaqGfJnElpCPNym=YubxFwIWAkTsULrdaqGfJnElpCPNyV.callRequestCookies('Get',YubxFwIWAkTsULrdaqGfJnElpCPNyz,payload=YubxFwIWAkTsULrdaqGfJnElpCPNVe,params=YubxFwIWAkTsULrdaqGfJnElpCPNev,headers=YubxFwIWAkTsULrdaqGfJnElpCPNVe,cookies=YubxFwIWAkTsULrdaqGfJnElpCPNyD)
   YubxFwIWAkTsULrdaqGfJnElpCPNeX=json.loads(YubxFwIWAkTsULrdaqGfJnElpCPNym.text)
   if not('contents' in YubxFwIWAkTsULrdaqGfJnElpCPNeX):return YubxFwIWAkTsULrdaqGfJnElpCPNeh,YubxFwIWAkTsULrdaqGfJnElpCPNez
   YubxFwIWAkTsULrdaqGfJnElpCPNec=YubxFwIWAkTsULrdaqGfJnElpCPNeX['contents']
   YubxFwIWAkTsULrdaqGfJnElpCPNez=YubxFwIWAkTsULrdaqGfJnElpCPNeX['meta']['has_next']
   for YubxFwIWAkTsULrdaqGfJnElpCPNej in YubxFwIWAkTsULrdaqGfJnElpCPNec:
    YubxFwIWAkTsULrdaqGfJnElpCPNeO =YubxFwIWAkTsULrdaqGfJnElpCPNej['code']
    YubxFwIWAkTsULrdaqGfJnElpCPNeg=YubxFwIWAkTsULrdaqGfJnElpCPNej['content_type']
    YubxFwIWAkTsULrdaqGfJnElpCPNeR =YubxFwIWAkTsULrdaqGfJnElpCPNej['title']
    YubxFwIWAkTsULrdaqGfJnElpCPNei =YubxFwIWAkTsULrdaqGfJnElpCPNej['story']
    if YubxFwIWAkTsULrdaqGfJnElpCPNej['thumbnail']!=YubxFwIWAkTsULrdaqGfJnElpCPNVe:
     YubxFwIWAkTsULrdaqGfJnElpCPNeo =YubxFwIWAkTsULrdaqGfJnElpCPNej['thumbnail']['medium']
    else:
     YubxFwIWAkTsULrdaqGfJnElpCPNeo =YubxFwIWAkTsULrdaqGfJnElpCPNej['stillcut']['medium']
    YubxFwIWAkTsULrdaqGfJnElpCPNeK =YubxFwIWAkTsULrdaqGfJnElpCPNej['year']
    YubxFwIWAkTsULrdaqGfJnElpCPNem =YubxFwIWAkTsULrdaqGfJnElpCPNej['film_rating_code']
    YubxFwIWAkTsULrdaqGfJnElpCPNeD=YubxFwIWAkTsULrdaqGfJnElpCPNej['film_rating_short']
    YubxFwIWAkTsULrdaqGfJnElpCPNeB={}
    YubxFwIWAkTsULrdaqGfJnElpCPNeB['mpaa']=YubxFwIWAkTsULrdaqGfJnElpCPNej['film_rating_long']
    YubxFwIWAkTsULrdaqGfJnElpCPNeB['year']=YubxFwIWAkTsULrdaqGfJnElpCPNej['year']
    YubxFwIWAkTsULrdaqGfJnElpCPNeB['title']=YubxFwIWAkTsULrdaqGfJnElpCPNej['title']
    if YubxFwIWAkTsULrdaqGfJnElpCPNeg=='movies':
     YubxFwIWAkTsULrdaqGfJnElpCPNeB['mediatype']='movie' 
     YubxFwIWAkTsULrdaqGfJnElpCPNeB['duration']=YubxFwIWAkTsULrdaqGfJnElpCPNej['duration']
    else:
     YubxFwIWAkTsULrdaqGfJnElpCPNeB['mediatype']='episode' 
    YubxFwIWAkTsULrdaqGfJnElpCPNeS={'code':YubxFwIWAkTsULrdaqGfJnElpCPNeO,'content_type':YubxFwIWAkTsULrdaqGfJnElpCPNeg,'title':YubxFwIWAkTsULrdaqGfJnElpCPNeR,'story':YubxFwIWAkTsULrdaqGfJnElpCPNei,'thumbnail':YubxFwIWAkTsULrdaqGfJnElpCPNeo,'year':YubxFwIWAkTsULrdaqGfJnElpCPNeK,'film_rating_code':YubxFwIWAkTsULrdaqGfJnElpCPNem,'film_rating_short':YubxFwIWAkTsULrdaqGfJnElpCPNeD,'info':YubxFwIWAkTsULrdaqGfJnElpCPNeB}
    YubxFwIWAkTsULrdaqGfJnElpCPNeh.append(YubxFwIWAkTsULrdaqGfJnElpCPNeS)
  except YubxFwIWAkTsULrdaqGfJnElpCPNVc as exception:
   YubxFwIWAkTsULrdaqGfJnElpCPNVj(exception)
  return YubxFwIWAkTsULrdaqGfJnElpCPNeh,YubxFwIWAkTsULrdaqGfJnElpCPNez
 def GetCategoryList_morepage(YubxFwIWAkTsULrdaqGfJnElpCPNyV,stype,YubxFwIWAkTsULrdaqGfJnElpCPNet,YubxFwIWAkTsULrdaqGfJnElpCPNeQ,page_int,in_sort):
  YubxFwIWAkTsULrdaqGfJnElpCPNez=YubxFwIWAkTsULrdaqGfJnElpCPNVh
  if not('categories' in YubxFwIWAkTsULrdaqGfJnElpCPNeQ):return YubxFwIWAkTsULrdaqGfJnElpCPNVX
  try:
   YubxFwIWAkTsULrdaqGfJnElpCPNeV ='/api/categories/contents.json'
   YubxFwIWAkTsULrdaqGfJnElpCPNev={}
   if stype=='genres':
    YubxFwIWAkTsULrdaqGfJnElpCPNev['genre']=YubxFwIWAkTsULrdaqGfJnElpCPNet
   else:
    YubxFwIWAkTsULrdaqGfJnElpCPNev['tag'] =YubxFwIWAkTsULrdaqGfJnElpCPNet
   YubxFwIWAkTsULrdaqGfJnElpCPNev['order']=in_sort 
   if page_int>1:
    YubxFwIWAkTsULrdaqGfJnElpCPNev['page']=YubxFwIWAkTsULrdaqGfJnElpCPNVM(page_int-1)
   YubxFwIWAkTsULrdaqGfJnElpCPNyz=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeurl(YubxFwIWAkTsULrdaqGfJnElpCPNyV.API_DOMAIN,YubxFwIWAkTsULrdaqGfJnElpCPNeV)
   YubxFwIWAkTsULrdaqGfJnElpCPNyD=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeDefaultCookies()
   YubxFwIWAkTsULrdaqGfJnElpCPNym=YubxFwIWAkTsULrdaqGfJnElpCPNyV.callRequestCookies('Get',YubxFwIWAkTsULrdaqGfJnElpCPNyz,payload=YubxFwIWAkTsULrdaqGfJnElpCPNVe,params=YubxFwIWAkTsULrdaqGfJnElpCPNev,headers=YubxFwIWAkTsULrdaqGfJnElpCPNVe,cookies=YubxFwIWAkTsULrdaqGfJnElpCPNyD)
   YubxFwIWAkTsULrdaqGfJnElpCPNeX=json.loads(YubxFwIWAkTsULrdaqGfJnElpCPNym.text)
   YubxFwIWAkTsULrdaqGfJnElpCPNez=YubxFwIWAkTsULrdaqGfJnElpCPNeX['meta']['has_next']
  except YubxFwIWAkTsULrdaqGfJnElpCPNVc as exception:
   YubxFwIWAkTsULrdaqGfJnElpCPNVj(exception)
  return YubxFwIWAkTsULrdaqGfJnElpCPNez
 def GetEpisodoList(YubxFwIWAkTsULrdaqGfJnElpCPNyV,program_code,page_int,orderby='asc'):
  YubxFwIWAkTsULrdaqGfJnElpCPNeh=[]
  YubxFwIWAkTsULrdaqGfJnElpCPNez=YubxFwIWAkTsULrdaqGfJnElpCPNVh
  YubxFwIWAkTsULrdaqGfJnElpCPNeH=''
  try:
   YubxFwIWAkTsULrdaqGfJnElpCPNeV ='/api/contents/'+program_code+'/tv_episodes.json'
   YubxFwIWAkTsULrdaqGfJnElpCPNev={'all':'true'}
   YubxFwIWAkTsULrdaqGfJnElpCPNyz=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeurl(YubxFwIWAkTsULrdaqGfJnElpCPNyV.API_DOMAIN,YubxFwIWAkTsULrdaqGfJnElpCPNeV)
   YubxFwIWAkTsULrdaqGfJnElpCPNyD=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeDefaultCookies()
   YubxFwIWAkTsULrdaqGfJnElpCPNym=YubxFwIWAkTsULrdaqGfJnElpCPNyV.callRequestCookies('Get',YubxFwIWAkTsULrdaqGfJnElpCPNyz,payload=YubxFwIWAkTsULrdaqGfJnElpCPNVe,params=YubxFwIWAkTsULrdaqGfJnElpCPNev,headers=YubxFwIWAkTsULrdaqGfJnElpCPNVe,cookies=YubxFwIWAkTsULrdaqGfJnElpCPNyD)
   YubxFwIWAkTsULrdaqGfJnElpCPNeX=json.loads(YubxFwIWAkTsULrdaqGfJnElpCPNym.text)
   if not('tv_episode_codes' in YubxFwIWAkTsULrdaqGfJnElpCPNeX):return YubxFwIWAkTsULrdaqGfJnElpCPNeh,YubxFwIWAkTsULrdaqGfJnElpCPNez
   YubxFwIWAkTsULrdaqGfJnElpCPNec=YubxFwIWAkTsULrdaqGfJnElpCPNeX['tv_episode_codes']
   YubxFwIWAkTsULrdaqGfJnElpCPNhy=YubxFwIWAkTsULrdaqGfJnElpCPNVQ(YubxFwIWAkTsULrdaqGfJnElpCPNec)
   YubxFwIWAkTsULrdaqGfJnElpCPNhe =YubxFwIWAkTsULrdaqGfJnElpCPNVt(YubxFwIWAkTsULrdaqGfJnElpCPNhy//(YubxFwIWAkTsULrdaqGfJnElpCPNyV.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    YubxFwIWAkTsULrdaqGfJnElpCPNhV =(YubxFwIWAkTsULrdaqGfJnElpCPNhy-1)-((page_int-1)*YubxFwIWAkTsULrdaqGfJnElpCPNyV.EPISODE_LIMIT)
   else:
    YubxFwIWAkTsULrdaqGfJnElpCPNhV =(page_int-1)*YubxFwIWAkTsULrdaqGfJnElpCPNyV.EPISODE_LIMIT
   for i in YubxFwIWAkTsULrdaqGfJnElpCPNVS(YubxFwIWAkTsULrdaqGfJnElpCPNyV.EPISODE_LIMIT):
    if orderby=='desc':
     YubxFwIWAkTsULrdaqGfJnElpCPNhX=YubxFwIWAkTsULrdaqGfJnElpCPNhV-i
     if YubxFwIWAkTsULrdaqGfJnElpCPNhX<0:break
    else:
     YubxFwIWAkTsULrdaqGfJnElpCPNhX=YubxFwIWAkTsULrdaqGfJnElpCPNhV+i
     if YubxFwIWAkTsULrdaqGfJnElpCPNhX>=YubxFwIWAkTsULrdaqGfJnElpCPNhy:break
    if YubxFwIWAkTsULrdaqGfJnElpCPNeH!='':YubxFwIWAkTsULrdaqGfJnElpCPNeH+=','
    YubxFwIWAkTsULrdaqGfJnElpCPNeH+=YubxFwIWAkTsULrdaqGfJnElpCPNec[YubxFwIWAkTsULrdaqGfJnElpCPNhX]
   if YubxFwIWAkTsULrdaqGfJnElpCPNhe>page_int:YubxFwIWAkTsULrdaqGfJnElpCPNez=YubxFwIWAkTsULrdaqGfJnElpCPNVX
  except YubxFwIWAkTsULrdaqGfJnElpCPNVc as exception:
   YubxFwIWAkTsULrdaqGfJnElpCPNVj(exception)
  try:
   YubxFwIWAkTsULrdaqGfJnElpCPNev={'codes':YubxFwIWAkTsULrdaqGfJnElpCPNeH}
   YubxFwIWAkTsULrdaqGfJnElpCPNyz=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeurl(YubxFwIWAkTsULrdaqGfJnElpCPNyV.API_DOMAIN,YubxFwIWAkTsULrdaqGfJnElpCPNeV)
   YubxFwIWAkTsULrdaqGfJnElpCPNyD=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeDefaultCookies()
   YubxFwIWAkTsULrdaqGfJnElpCPNym=YubxFwIWAkTsULrdaqGfJnElpCPNyV.callRequestCookies('Get',YubxFwIWAkTsULrdaqGfJnElpCPNyz,payload=YubxFwIWAkTsULrdaqGfJnElpCPNVe,params=YubxFwIWAkTsULrdaqGfJnElpCPNev,headers=YubxFwIWAkTsULrdaqGfJnElpCPNVe,cookies=YubxFwIWAkTsULrdaqGfJnElpCPNyD)
   YubxFwIWAkTsULrdaqGfJnElpCPNeX=json.loads(YubxFwIWAkTsULrdaqGfJnElpCPNym.text)
   if not('tv_episodes' in YubxFwIWAkTsULrdaqGfJnElpCPNeX):return YubxFwIWAkTsULrdaqGfJnElpCPNeh
   YubxFwIWAkTsULrdaqGfJnElpCPNec=YubxFwIWAkTsULrdaqGfJnElpCPNeX['tv_episodes']
   for YubxFwIWAkTsULrdaqGfJnElpCPNej in YubxFwIWAkTsULrdaqGfJnElpCPNec:
    YubxFwIWAkTsULrdaqGfJnElpCPNeO =YubxFwIWAkTsULrdaqGfJnElpCPNej['code']
    if YubxFwIWAkTsULrdaqGfJnElpCPNej['title']:
     YubxFwIWAkTsULrdaqGfJnElpCPNeR =YubxFwIWAkTsULrdaqGfJnElpCPNej['title']
    else:
     YubxFwIWAkTsULrdaqGfJnElpCPNeR =''
    YubxFwIWAkTsULrdaqGfJnElpCPNeo =YubxFwIWAkTsULrdaqGfJnElpCPNej['stillcut']['medium']
    YubxFwIWAkTsULrdaqGfJnElpCPNhc =YubxFwIWAkTsULrdaqGfJnElpCPNej['display_number']
    YubxFwIWAkTsULrdaqGfJnElpCPNhj=YubxFwIWAkTsULrdaqGfJnElpCPNej['tv_season_title']
    YubxFwIWAkTsULrdaqGfJnElpCPNeB={}
    YubxFwIWAkTsULrdaqGfJnElpCPNeB['mediatype'] ='episode'
    YubxFwIWAkTsULrdaqGfJnElpCPNeB['tvshowtitle']=YubxFwIWAkTsULrdaqGfJnElpCPNeR if YubxFwIWAkTsULrdaqGfJnElpCPNeR else YubxFwIWAkTsULrdaqGfJnElpCPNhj
    YubxFwIWAkTsULrdaqGfJnElpCPNeB['title'] ='%s %s'%(YubxFwIWAkTsULrdaqGfJnElpCPNhj,YubxFwIWAkTsULrdaqGfJnElpCPNhc)if YubxFwIWAkTsULrdaqGfJnElpCPNeR else YubxFwIWAkTsULrdaqGfJnElpCPNhc
    YubxFwIWAkTsULrdaqGfJnElpCPNeB['duration'] =YubxFwIWAkTsULrdaqGfJnElpCPNej['duration']
    try:
     YubxFwIWAkTsULrdaqGfJnElpCPNeB['episode']=YubxFwIWAkTsULrdaqGfJnElpCPNej['episode_number']
    except:
     YubxFwIWAkTsULrdaqGfJnElpCPNVe
    YubxFwIWAkTsULrdaqGfJnElpCPNeS={'code':YubxFwIWAkTsULrdaqGfJnElpCPNeO,'title':YubxFwIWAkTsULrdaqGfJnElpCPNeR,'thumbnail':YubxFwIWAkTsULrdaqGfJnElpCPNeo,'display_num':YubxFwIWAkTsULrdaqGfJnElpCPNhc,'season_title':YubxFwIWAkTsULrdaqGfJnElpCPNhj,'info':YubxFwIWAkTsULrdaqGfJnElpCPNeB}
    YubxFwIWAkTsULrdaqGfJnElpCPNeh.append(YubxFwIWAkTsULrdaqGfJnElpCPNeS)
  except YubxFwIWAkTsULrdaqGfJnElpCPNVc as exception:
   YubxFwIWAkTsULrdaqGfJnElpCPNVj(exception)
  return YubxFwIWAkTsULrdaqGfJnElpCPNeh,YubxFwIWAkTsULrdaqGfJnElpCPNez
 def GetSearchList(YubxFwIWAkTsULrdaqGfJnElpCPNyV,search_key,page_int):
  YubxFwIWAkTsULrdaqGfJnElpCPNhM=[]
  YubxFwIWAkTsULrdaqGfJnElpCPNez=YubxFwIWAkTsULrdaqGfJnElpCPNVh
  try:
   YubxFwIWAkTsULrdaqGfJnElpCPNeV ='/api/search.json'
   YubxFwIWAkTsULrdaqGfJnElpCPNev={'query':search_key,'page':YubxFwIWAkTsULrdaqGfJnElpCPNVM(page_int),'per':YubxFwIWAkTsULrdaqGfJnElpCPNVM(YubxFwIWAkTsULrdaqGfJnElpCPNyV.SEARCH_LIMIT),'exclude':'limited'}
   YubxFwIWAkTsULrdaqGfJnElpCPNyz=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeurl(YubxFwIWAkTsULrdaqGfJnElpCPNyV.API_DOMAIN,YubxFwIWAkTsULrdaqGfJnElpCPNeV)
   YubxFwIWAkTsULrdaqGfJnElpCPNyD=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeDefaultCookies()
   YubxFwIWAkTsULrdaqGfJnElpCPNym=YubxFwIWAkTsULrdaqGfJnElpCPNyV.callRequestCookies('Get',YubxFwIWAkTsULrdaqGfJnElpCPNyz,payload=YubxFwIWAkTsULrdaqGfJnElpCPNVe,params=YubxFwIWAkTsULrdaqGfJnElpCPNev,headers=YubxFwIWAkTsULrdaqGfJnElpCPNVe,cookies=YubxFwIWAkTsULrdaqGfJnElpCPNyD)
   YubxFwIWAkTsULrdaqGfJnElpCPNeX=json.loads(YubxFwIWAkTsULrdaqGfJnElpCPNym.text)
   if not('results' in YubxFwIWAkTsULrdaqGfJnElpCPNeX):return YubxFwIWAkTsULrdaqGfJnElpCPNhM,YubxFwIWAkTsULrdaqGfJnElpCPNez
   YubxFwIWAkTsULrdaqGfJnElpCPNec=YubxFwIWAkTsULrdaqGfJnElpCPNeX['results']
   YubxFwIWAkTsULrdaqGfJnElpCPNez=YubxFwIWAkTsULrdaqGfJnElpCPNeX['meta']['has_next']
   for YubxFwIWAkTsULrdaqGfJnElpCPNej in YubxFwIWAkTsULrdaqGfJnElpCPNec:
    YubxFwIWAkTsULrdaqGfJnElpCPNeO =YubxFwIWAkTsULrdaqGfJnElpCPNej['code']
    YubxFwIWAkTsULrdaqGfJnElpCPNeg=YubxFwIWAkTsULrdaqGfJnElpCPNej['content_type']
    YubxFwIWAkTsULrdaqGfJnElpCPNeR =YubxFwIWAkTsULrdaqGfJnElpCPNej['title']
    YubxFwIWAkTsULrdaqGfJnElpCPNei =YubxFwIWAkTsULrdaqGfJnElpCPNej['story']
    if YubxFwIWAkTsULrdaqGfJnElpCPNej['thumbnail']!=YubxFwIWAkTsULrdaqGfJnElpCPNVe:
     YubxFwIWAkTsULrdaqGfJnElpCPNeo =YubxFwIWAkTsULrdaqGfJnElpCPNej['thumbnail']['medium']
    else:
     YubxFwIWAkTsULrdaqGfJnElpCPNeo =YubxFwIWAkTsULrdaqGfJnElpCPNej['stillcut']['medium']
    YubxFwIWAkTsULrdaqGfJnElpCPNeK =YubxFwIWAkTsULrdaqGfJnElpCPNej['year']
    YubxFwIWAkTsULrdaqGfJnElpCPNem =YubxFwIWAkTsULrdaqGfJnElpCPNej['film_rating_code']
    YubxFwIWAkTsULrdaqGfJnElpCPNeD=YubxFwIWAkTsULrdaqGfJnElpCPNej['film_rating_short']
    YubxFwIWAkTsULrdaqGfJnElpCPNeB={}
    YubxFwIWAkTsULrdaqGfJnElpCPNeB['mpaa']=YubxFwIWAkTsULrdaqGfJnElpCPNej['film_rating_long']
    YubxFwIWAkTsULrdaqGfJnElpCPNeB['year']=YubxFwIWAkTsULrdaqGfJnElpCPNej['year']
    YubxFwIWAkTsULrdaqGfJnElpCPNeB['title']=YubxFwIWAkTsULrdaqGfJnElpCPNej['title']
    if YubxFwIWAkTsULrdaqGfJnElpCPNeg=='movies':
     YubxFwIWAkTsULrdaqGfJnElpCPNeB['mediatype']='movie' 
     YubxFwIWAkTsULrdaqGfJnElpCPNeB['duration']=YubxFwIWAkTsULrdaqGfJnElpCPNej['duration']
    else:
     YubxFwIWAkTsULrdaqGfJnElpCPNeB['mediatype']='episode' 
    YubxFwIWAkTsULrdaqGfJnElpCPNeS={'code':YubxFwIWAkTsULrdaqGfJnElpCPNeO,'content_type':YubxFwIWAkTsULrdaqGfJnElpCPNeg,'title':YubxFwIWAkTsULrdaqGfJnElpCPNeR,'story':YubxFwIWAkTsULrdaqGfJnElpCPNei,'thumbnail':YubxFwIWAkTsULrdaqGfJnElpCPNeo,'year':YubxFwIWAkTsULrdaqGfJnElpCPNeK,'film_rating_code':YubxFwIWAkTsULrdaqGfJnElpCPNem,'film_rating_short':YubxFwIWAkTsULrdaqGfJnElpCPNeD,'info':YubxFwIWAkTsULrdaqGfJnElpCPNeB}
    YubxFwIWAkTsULrdaqGfJnElpCPNhM.append(YubxFwIWAkTsULrdaqGfJnElpCPNeS)
  except YubxFwIWAkTsULrdaqGfJnElpCPNVc as exception:
   YubxFwIWAkTsULrdaqGfJnElpCPNVj(exception)
  return YubxFwIWAkTsULrdaqGfJnElpCPNhM,YubxFwIWAkTsULrdaqGfJnElpCPNez
 def GetProfilesList(YubxFwIWAkTsULrdaqGfJnElpCPNyV):
  YubxFwIWAkTsULrdaqGfJnElpCPNyH=[]
  try:
   YubxFwIWAkTsULrdaqGfJnElpCPNeV ='/manage_profiles'
   YubxFwIWAkTsULrdaqGfJnElpCPNyz=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeurl(YubxFwIWAkTsULrdaqGfJnElpCPNyV.API_DOMAIN,YubxFwIWAkTsULrdaqGfJnElpCPNeV)
   YubxFwIWAkTsULrdaqGfJnElpCPNyD=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeDefaultCookies()
   YubxFwIWAkTsULrdaqGfJnElpCPNym=YubxFwIWAkTsULrdaqGfJnElpCPNyV.callRequestCookies('Get',YubxFwIWAkTsULrdaqGfJnElpCPNyz,payload=YubxFwIWAkTsULrdaqGfJnElpCPNVe,params=YubxFwIWAkTsULrdaqGfJnElpCPNVe,headers=YubxFwIWAkTsULrdaqGfJnElpCPNVe,cookies=YubxFwIWAkTsULrdaqGfJnElpCPNyD,redirects=YubxFwIWAkTsULrdaqGfJnElpCPNVX)
   YubxFwIWAkTsULrdaqGfJnElpCPNhQ=YubxFwIWAkTsULrdaqGfJnElpCPNym.text
   YubxFwIWAkTsULrdaqGfJnElpCPNht =re.findall('/api/users/me.{5000}',YubxFwIWAkTsULrdaqGfJnElpCPNhQ)[0]
   YubxFwIWAkTsULrdaqGfJnElpCPNht =YubxFwIWAkTsULrdaqGfJnElpCPNht.replace('&quot;','')
   YubxFwIWAkTsULrdaqGfJnElpCPNyH=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',YubxFwIWAkTsULrdaqGfJnElpCPNht)
   for i in YubxFwIWAkTsULrdaqGfJnElpCPNVS(YubxFwIWAkTsULrdaqGfJnElpCPNVQ(YubxFwIWAkTsULrdaqGfJnElpCPNyH)):
    YubxFwIWAkTsULrdaqGfJnElpCPNhS=YubxFwIWAkTsULrdaqGfJnElpCPNyH[i]
    YubxFwIWAkTsULrdaqGfJnElpCPNhS =YubxFwIWAkTsULrdaqGfJnElpCPNhS.split(':')[1]
    YubxFwIWAkTsULrdaqGfJnElpCPNyH[i]=YubxFwIWAkTsULrdaqGfJnElpCPNhS.split(',')[0]
  except YubxFwIWAkTsULrdaqGfJnElpCPNVc as exception:
   YubxFwIWAkTsULrdaqGfJnElpCPNVj(exception)
  return YubxFwIWAkTsULrdaqGfJnElpCPNyH
 def GetProfilesConvert(YubxFwIWAkTsULrdaqGfJnElpCPNyV,YubxFwIWAkTsULrdaqGfJnElpCPNyM):
  YubxFwIWAkTsULrdaqGfJnElpCPNhz=''
  YubxFwIWAkTsULrdaqGfJnElpCPNhv=''
  try:
   YubxFwIWAkTsULrdaqGfJnElpCPNeV ='/api/users/'+YubxFwIWAkTsULrdaqGfJnElpCPNyM+'/convert'
   YubxFwIWAkTsULrdaqGfJnElpCPNyz=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeurl(YubxFwIWAkTsULrdaqGfJnElpCPNyV.API_DOMAIN,YubxFwIWAkTsULrdaqGfJnElpCPNeV)
   YubxFwIWAkTsULrdaqGfJnElpCPNyD=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeDefaultCookies()
   YubxFwIWAkTsULrdaqGfJnElpCPNym=YubxFwIWAkTsULrdaqGfJnElpCPNyV.callRequestCookies('Put',YubxFwIWAkTsULrdaqGfJnElpCPNyz,payload=YubxFwIWAkTsULrdaqGfJnElpCPNVe,params=YubxFwIWAkTsULrdaqGfJnElpCPNVe,headers=YubxFwIWAkTsULrdaqGfJnElpCPNVe,cookies=YubxFwIWAkTsULrdaqGfJnElpCPNyD)
   for YubxFwIWAkTsULrdaqGfJnElpCPNyD in YubxFwIWAkTsULrdaqGfJnElpCPNym.cookies:
    if YubxFwIWAkTsULrdaqGfJnElpCPNyD.name=='_s_guitv':
     YubxFwIWAkTsULrdaqGfJnElpCPNhO=YubxFwIWAkTsULrdaqGfJnElpCPNyD.value
    elif YubxFwIWAkTsULrdaqGfJnElpCPNyD.name=='_guinness-premium_session':
     YubxFwIWAkTsULrdaqGfJnElpCPNyB=YubxFwIWAkTsULrdaqGfJnElpCPNyD.value
   if YubxFwIWAkTsULrdaqGfJnElpCPNhO:
    YubxFwIWAkTsULrdaqGfJnElpCPNhz=YubxFwIWAkTsULrdaqGfJnElpCPNhO
   if YubxFwIWAkTsULrdaqGfJnElpCPNyB:
    YubxFwIWAkTsULrdaqGfJnElpCPNhv=YubxFwIWAkTsULrdaqGfJnElpCPNyB
  except YubxFwIWAkTsULrdaqGfJnElpCPNVc as exception:
   YubxFwIWAkTsULrdaqGfJnElpCPNhz=''
   YubxFwIWAkTsULrdaqGfJnElpCPNhv=''
  return YubxFwIWAkTsULrdaqGfJnElpCPNhz,YubxFwIWAkTsULrdaqGfJnElpCPNhv
 def Get_Now_Datetime(YubxFwIWAkTsULrdaqGfJnElpCPNyV):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(YubxFwIWAkTsULrdaqGfJnElpCPNyV,movie_code,quality_str):
  YubxFwIWAkTsULrdaqGfJnElpCPNhR=YubxFwIWAkTsULrdaqGfJnElpCPNho=YubxFwIWAkTsULrdaqGfJnElpCPNhH=''
  try:
   YubxFwIWAkTsULrdaqGfJnElpCPNeV='/api/watch/'+movie_code+'.json'
   YubxFwIWAkTsULrdaqGfJnElpCPNyz=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeurl(YubxFwIWAkTsULrdaqGfJnElpCPNyV.API_DOMAIN,YubxFwIWAkTsULrdaqGfJnElpCPNeV)
   YubxFwIWAkTsULrdaqGfJnElpCPNyK={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   YubxFwIWAkTsULrdaqGfJnElpCPNyD=YubxFwIWAkTsULrdaqGfJnElpCPNyV.makeDefaultCookies()
   YubxFwIWAkTsULrdaqGfJnElpCPNym=YubxFwIWAkTsULrdaqGfJnElpCPNyV.callRequestCookies('Get',YubxFwIWAkTsULrdaqGfJnElpCPNyz,payload=YubxFwIWAkTsULrdaqGfJnElpCPNVe,params=YubxFwIWAkTsULrdaqGfJnElpCPNVe,headers=YubxFwIWAkTsULrdaqGfJnElpCPNyK,cookies=YubxFwIWAkTsULrdaqGfJnElpCPNyD)
   YubxFwIWAkTsULrdaqGfJnElpCPNeX=json.loads(YubxFwIWAkTsULrdaqGfJnElpCPNym.text)
   YubxFwIWAkTsULrdaqGfJnElpCPNhR=YubxFwIWAkTsULrdaqGfJnElpCPNeX['streams'][0]['source']
   if YubxFwIWAkTsULrdaqGfJnElpCPNhR==YubxFwIWAkTsULrdaqGfJnElpCPNVe:return(YubxFwIWAkTsULrdaqGfJnElpCPNhR,YubxFwIWAkTsULrdaqGfJnElpCPNho,YubxFwIWAkTsULrdaqGfJnElpCPNhH)
   if 'subtitles' in YubxFwIWAkTsULrdaqGfJnElpCPNeX['streams'][0]:
    for YubxFwIWAkTsULrdaqGfJnElpCPNhi in YubxFwIWAkTsULrdaqGfJnElpCPNeX['streams'][0]['subtitles']:
     if YubxFwIWAkTsULrdaqGfJnElpCPNhi['lang']=='ko':
      YubxFwIWAkTsULrdaqGfJnElpCPNho=YubxFwIWAkTsULrdaqGfJnElpCPNhi['url']
      break
   YubxFwIWAkTsULrdaqGfJnElpCPNhK =YubxFwIWAkTsULrdaqGfJnElpCPNeX['ping_payload']
   YubxFwIWAkTsULrdaqGfJnElpCPNhm =YubxFwIWAkTsULrdaqGfJnElpCPNyV.WATCHA_USERCD
   YubxFwIWAkTsULrdaqGfJnElpCPNhD={'merchant':'giitd_frograms','sessionId':YubxFwIWAkTsULrdaqGfJnElpCPNhK,'userId':YubxFwIWAkTsULrdaqGfJnElpCPNhm}
   YubxFwIWAkTsULrdaqGfJnElpCPNhB=json.dumps(YubxFwIWAkTsULrdaqGfJnElpCPNhD,separators=(",",":")).encode('UTF-8')
   YubxFwIWAkTsULrdaqGfJnElpCPNhH=base64.b64encode(YubxFwIWAkTsULrdaqGfJnElpCPNhB)
  except YubxFwIWAkTsULrdaqGfJnElpCPNVc as exception:
   return(YubxFwIWAkTsULrdaqGfJnElpCPNhR,YubxFwIWAkTsULrdaqGfJnElpCPNho,YubxFwIWAkTsULrdaqGfJnElpCPNhH)
  return(YubxFwIWAkTsULrdaqGfJnElpCPNhR,YubxFwIWAkTsULrdaqGfJnElpCPNho,YubxFwIWAkTsULrdaqGfJnElpCPNhH) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
