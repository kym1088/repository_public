__author__="NightRain"
RXyDlcdmfYrqHsUSJoWhgOkFzVAnvp=object
RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC=None
RXyDlcdmfYrqHsUSJoWhgOkFzVAntb=False
RXyDlcdmfYrqHsUSJoWhgOkFzVAntE=int
RXyDlcdmfYrqHsUSJoWhgOkFzVAntI=True
RXyDlcdmfYrqHsUSJoWhgOkFzVAntT=len
RXyDlcdmfYrqHsUSJoWhgOkFzVAntv=range
RXyDlcdmfYrqHsUSJoWhgOkFzVAntL=str
RXyDlcdmfYrqHsUSJoWhgOkFzVAntx=open
RXyDlcdmfYrqHsUSJoWhgOkFzVAnte=dict
RXyDlcdmfYrqHsUSJoWhgOkFzVAntQ=Exception
RXyDlcdmfYrqHsUSJoWhgOkFzVAntN=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
RXyDlcdmfYrqHsUSJoWhgOkFzVAnbI=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'검색 (search)','mode':'SEARCH','stype':'-','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-'}]
RXyDlcdmfYrqHsUSJoWhgOkFzVAnbT=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
RXyDlcdmfYrqHsUSJoWhgOkFzVAnbv=40
RXyDlcdmfYrqHsUSJoWhgOkFzVAnbt =20
RXyDlcdmfYrqHsUSJoWhgOkFzVAnbL='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
RXyDlcdmfYrqHsUSJoWhgOkFzVAnbx =xbmc.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
RXyDlcdmfYrqHsUSJoWhgOkFzVAnbe=xbmc.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class RXyDlcdmfYrqHsUSJoWhgOkFzVAnbE(RXyDlcdmfYrqHsUSJoWhgOkFzVAnvp):
 def __init__(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,RXyDlcdmfYrqHsUSJoWhgOkFzVAnbN,RXyDlcdmfYrqHsUSJoWhgOkFzVAnbK,RXyDlcdmfYrqHsUSJoWhgOkFzVAnbj):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_url =RXyDlcdmfYrqHsUSJoWhgOkFzVAnbN
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_handle=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbK
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.main_params =RXyDlcdmfYrqHsUSJoWhgOkFzVAnbj
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj =LphJxOsAYDkCwuvoNGrKiBeTgnRFaW() 
 def addon_noti(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,sting):
  try:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbG=xbmcgui.Dialog()
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbG.notification(__addonname__,sting)
  except:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC
 def addon_log(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,string,isDebug=RXyDlcdmfYrqHsUSJoWhgOkFzVAntb):
  try:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbM=string.encode('utf-8','ignore')
  except:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbM='addonException: addon_log'
  if isDebug:RXyDlcdmfYrqHsUSJoWhgOkFzVAnbu=xbmc.LOGDEBUG
  else:RXyDlcdmfYrqHsUSJoWhgOkFzVAnbu=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,RXyDlcdmfYrqHsUSJoWhgOkFzVAnbM),level=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbu)
 def get_keyboard_input(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbP=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC
  kb=xbmc.Keyboard()
  kb.setHeading(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbP=kb.getText()
  return RXyDlcdmfYrqHsUSJoWhgOkFzVAnbP
 def get_settings_login_info(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbw =__addon__.getSetting('id')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbB =__addon__.getSetting('pw')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbi=RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(__addon__.getSetting('selected_profile'))
  return(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbw,RXyDlcdmfYrqHsUSJoWhgOkFzVAnbB,RXyDlcdmfYrqHsUSJoWhgOkFzVAnbi)
 def get_selQuality(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  try:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbp=['3840x2160/1','1920x1080/1','1280x720/1']
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbC=RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(__addon__.getSetting('selected_quality'))
   return RXyDlcdmfYrqHsUSJoWhgOkFzVAnbp[RXyDlcdmfYrqHsUSJoWhgOkFzVAnbC]
  except:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC
  return 1080 
 def get_settings_direct_replay(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEb=RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(__addon__.getSetting('direct_replay'))
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEb==0:
   return RXyDlcdmfYrqHsUSJoWhgOkFzVAntb
  else:
   return RXyDlcdmfYrqHsUSJoWhgOkFzVAntI
 def set_winCredential(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,credential):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI=xbmcgui.Window(10000)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_LOGINTIME',RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI=xbmcgui.Window(10000)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnET={'watcha_token':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.getProperty('WATCHA_M_TOKEN'),'watcha_guit':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.getProperty('WATCHA_M_GUIT'),'watcha_guitv':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.getProperty('WATCHA_M_GUITV'),'watcha_usercd':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.getProperty('WATCHA_M_USERCD')}
  return RXyDlcdmfYrqHsUSJoWhgOkFzVAnET
 def set_winEpisodeOrderby(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEv):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI=xbmcgui.Window(10000)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_ORDERBY',RXyDlcdmfYrqHsUSJoWhgOkFzVAnEv)
 def get_winEpisodeOrderby(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI=xbmcgui.Window(10000)
  return RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,args):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEv =args.get('orderby')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.set_winEpisodeOrderby(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEv)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,label,sublabel='',img='',infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI,params=''):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEt='%s?%s'%(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_url,urllib.parse.urlencode(params))
  if sublabel:RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL='%s < %s >'%(label,sublabel)
  else: RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL=label
  if not img:img='DefaultFolder.png'
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEx=xbmcgui.ListItem(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEx.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:RXyDlcdmfYrqHsUSJoWhgOkFzVAnEx.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:RXyDlcdmfYrqHsUSJoWhgOkFzVAnEx.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_handle,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEt,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEx,isFolder)
 def dp_Main_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  for RXyDlcdmfYrqHsUSJoWhgOkFzVAnEe in RXyDlcdmfYrqHsUSJoWhgOkFzVAnbI:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEe.get('title')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={'mode':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEe.get('mode'),'stype':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEe.get('stype'),'api_path':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEe.get('api_path'),'page':'1','sort':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEe.get('sort'),'tag_id':'-'}
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEe.get('mode')=='XXX':
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['mode']='XXX'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN=RXyDlcdmfYrqHsUSJoWhgOkFzVAntb
   else:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel='',img='',infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAntT(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbI)>0:xbmcplugin.endOfDirectory(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_handle)
 def login_main(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  (RXyDlcdmfYrqHsUSJoWhgOkFzVAnEj,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEa,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEG)=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_settings_login_info()
  if not(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEj and RXyDlcdmfYrqHsUSJoWhgOkFzVAnEa):
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbG=xbmcgui.Dialog()
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEM=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbG.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEM==RXyDlcdmfYrqHsUSJoWhgOkFzVAntI:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_winEpisodeOrderby()=='':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.set_winEpisodeOrderby('asc')
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.cookiefile_check():return
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEu =RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEP=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEP==RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC or RXyDlcdmfYrqHsUSJoWhgOkFzVAnEP=='':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEP=RXyDlcdmfYrqHsUSJoWhgOkFzVAntE('19000101')
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEw=0
   while RXyDlcdmfYrqHsUSJoWhgOkFzVAntI:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEw+=1
    time.sleep(0.05)
    if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEP>=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEu:return
    if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEw>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEP>=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEu:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.GetCredential(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEj,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEa,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEG):
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.set_winCredential(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.LoadCredential())
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,args):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.SaveCredential(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_winCredential())
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB =args.get('stype')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi =RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(args.get('page'))
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEp =args.get('sort')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEC=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.GetSubGroupList(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIb=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbv if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB=='genres' else RXyDlcdmfYrqHsUSJoWhgOkFzVAnbt
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIE=RXyDlcdmfYrqHsUSJoWhgOkFzVAntT(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEC)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIT =RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(RXyDlcdmfYrqHsUSJoWhgOkFzVAnIE//(RXyDlcdmfYrqHsUSJoWhgOkFzVAnIb+1))+1
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIv =(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi-1)*RXyDlcdmfYrqHsUSJoWhgOkFzVAnIb
  for i in RXyDlcdmfYrqHsUSJoWhgOkFzVAntv(RXyDlcdmfYrqHsUSJoWhgOkFzVAnIb):
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIt=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIv+i
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAnIt>=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIE:break
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL =RXyDlcdmfYrqHsUSJoWhgOkFzVAnEC[RXyDlcdmfYrqHsUSJoWhgOkFzVAnIt].get('group_name')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIL =RXyDlcdmfYrqHsUSJoWhgOkFzVAnEC[RXyDlcdmfYrqHsUSJoWhgOkFzVAnIt].get('api_path')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIx =RXyDlcdmfYrqHsUSJoWhgOkFzVAnEC[RXyDlcdmfYrqHsUSJoWhgOkFzVAnIt].get('tag_id')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={'mode':'CATEGORY_LIST','api_path':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIL,'tag_id':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIx,'stype':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB,'page':'1','sort':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEp}
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel='',img='',infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnIT>RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={}
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['mode'] ='SUB_GROUP' 
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['stype'] =RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['api_path']=args.get('api_path')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['page'] =RXyDlcdmfYrqHsUSJoWhgOkFzVAntL(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi+1)
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['sort'] =RXyDlcdmfYrqHsUSJoWhgOkFzVAnEp
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL='[B]%s >>[/B]'%'다음 페이지'
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIe=RXyDlcdmfYrqHsUSJoWhgOkFzVAntL(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi+1)
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIe,img='',infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAntT(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEC)>0:xbmcplugin.endOfDirectory(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_handle,cacheToDisc=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI)
 def play_VIDEO(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,args):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.SaveCredential(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_winCredential())
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ =args.get('movie_code')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN =args.get('season_code')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL =args.get('title')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK =args.get('thumbnail')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIj =RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_selQuality()
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.addon_log(RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ+' - '+RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN,RXyDlcdmfYrqHsUSJoWhgOkFzVAntb)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIa,RXyDlcdmfYrqHsUSJoWhgOkFzVAnIG,RXyDlcdmfYrqHsUSJoWhgOkFzVAnIM=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.GetStreamingURL(RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ,RXyDlcdmfYrqHsUSJoWhgOkFzVAnIj)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnIa=='':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.addon_noti(__language__(30908).encode('utf8'))
   return
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIu=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIa
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.addon_log(RXyDlcdmfYrqHsUSJoWhgOkFzVAnIu,RXyDlcdmfYrqHsUSJoWhgOkFzVAntb)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIP=xbmcgui.ListItem(path=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIu)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnIM:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIw=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIM
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIB ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIi ='mpd'
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIp ='com.widevine.alpha'
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIC =inputstreamhelper.Helper(RXyDlcdmfYrqHsUSJoWhgOkFzVAnIi,drm=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIp)
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAnIC.check_inputstream():
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnTb={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ,'dt-custom-data':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIw,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':RXyDlcdmfYrqHsUSJoWhgOkFzVAnbL,'Content-Type':'application/octet-stream'}
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnTE=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIB+'|'+urllib.parse.urlencode(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTb)+'|R{SSM}|'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.addon_log(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTE)
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIP.setProperty('inputstream',RXyDlcdmfYrqHsUSJoWhgOkFzVAnIC.inputstream_addon)
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIP.setProperty('inputstream.adaptive.manifest_type',RXyDlcdmfYrqHsUSJoWhgOkFzVAnIi)
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIP.setProperty('inputstream.adaptive.license_type',RXyDlcdmfYrqHsUSJoWhgOkFzVAnIp)
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIP.setProperty('inputstream.adaptive.license_key',RXyDlcdmfYrqHsUSJoWhgOkFzVAnTE)
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIP.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbL))
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnIG:
   try:
    f=RXyDlcdmfYrqHsUSJoWhgOkFzVAntx(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbx,'w',-1,'utf-8')
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnTI=requests.get(RXyDlcdmfYrqHsUSJoWhgOkFzVAnIG)
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnTv=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTI.content.decode('utf-8') 
    for RXyDlcdmfYrqHsUSJoWhgOkFzVAnTt in RXyDlcdmfYrqHsUSJoWhgOkFzVAnTv.splitlines():
     RXyDlcdmfYrqHsUSJoWhgOkFzVAnTL=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',RXyDlcdmfYrqHsUSJoWhgOkFzVAnTt)
     f.write(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTL+'\n')
    f.close()
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIP.setSubtitles([RXyDlcdmfYrqHsUSJoWhgOkFzVAnbx,RXyDlcdmfYrqHsUSJoWhgOkFzVAnIG])
   except:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIP.setSubtitles([RXyDlcdmfYrqHsUSJoWhgOkFzVAnIG])
  xbmcplugin.setResolvedUrl(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_handle,RXyDlcdmfYrqHsUSJoWhgOkFzVAntI,RXyDlcdmfYrqHsUSJoWhgOkFzVAnIP)
  try:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB='movie' if RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN=='-' else 'seasons'
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={'code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB=='movie' else RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN,'img':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK,'title':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,'videoid':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ}
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.Save_Watched_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
  except:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC
 def dp_Category_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,args):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.SaveCredential(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_winCredential())
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB =args.get('stype')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIx =args.get('tag_id')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIL=args.get('api_path')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi=RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(args.get('page'))
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEp =args.get('sort')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnTx,RXyDlcdmfYrqHsUSJoWhgOkFzVAnTe=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.GetCategoryList(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB,RXyDlcdmfYrqHsUSJoWhgOkFzVAnIx,RXyDlcdmfYrqHsUSJoWhgOkFzVAnIL,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEp)
  for RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ in RXyDlcdmfYrqHsUSJoWhgOkFzVAnTx:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('code')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('title')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTN =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('content_type')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTK =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('story')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('thumbnail')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTj =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('year')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTa =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('film_rating_code')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTG=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('film_rating_short')
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAnTN=='movies': 
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN=RXyDlcdmfYrqHsUSJoWhgOkFzVAntb
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnTM ='MOVIE'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEK=''
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN='-'
   else: 
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnTM ='EPISODE'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEK='Series'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('info')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu['plot']='%s (%s)\n년도 : %s\n\n%s'%(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,RXyDlcdmfYrqHsUSJoWhgOkFzVAnTG,RXyDlcdmfYrqHsUSJoWhgOkFzVAnTj,RXyDlcdmfYrqHsUSJoWhgOkFzVAnTK)
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAnTa>=19:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL+='  (%s년 - %s)'%(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTj,RXyDlcdmfYrqHsUSJoWhgOkFzVAntL(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTG))
   else:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL+='  (%s년)'%(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTj)
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={'mode':RXyDlcdmfYrqHsUSJoWhgOkFzVAnTM,'movie_code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ,'page':'1','season_code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN,'title':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,'thumbnail':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK}
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEK,img=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK,infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnTe:
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.GetCategoryList_morepage(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB,RXyDlcdmfYrqHsUSJoWhgOkFzVAnIx,RXyDlcdmfYrqHsUSJoWhgOkFzVAnIL,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi+1,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEp):
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={}
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['mode'] ='CATEGORY_LIST'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['stype'] =RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['tag_id'] =RXyDlcdmfYrqHsUSJoWhgOkFzVAnIx
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['api_path']=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIL
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['page'] =RXyDlcdmfYrqHsUSJoWhgOkFzVAntL(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi+1)
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['sort'] =RXyDlcdmfYrqHsUSJoWhgOkFzVAnEp
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL='[B]%s >>[/B]'%'다음 페이지'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIe=RXyDlcdmfYrqHsUSJoWhgOkFzVAntL(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi+1)
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIe,img='',infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAntT(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTx)>0:
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAnIL=='arrivals/latest':
    xbmcplugin.endOfDirectory(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_handle,cacheToDisc=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI)
   else:
    xbmcplugin.endOfDirectory(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_handle,cacheToDisc=RXyDlcdmfYrqHsUSJoWhgOkFzVAntb)
 def dp_Episode_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,args):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.SaveCredential(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_winCredential())
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnTw=args.get('movie_code')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi =RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(args.get('page'))
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN =args.get('season_code')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnTx,RXyDlcdmfYrqHsUSJoWhgOkFzVAnTe=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.GetEpisodoList(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTw,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi,orderby=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_winEpisodeOrderby())
  for RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ in RXyDlcdmfYrqHsUSJoWhgOkFzVAnTx:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('code')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('title')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('thumbnail')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTB =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('display_num')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTi=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('season_title')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('info')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu['plot']='%s\n%s\n\n%s'%(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTi,RXyDlcdmfYrqHsUSJoWhgOkFzVAnTB,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL)
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL='(%s) %s'%(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTB,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL)
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={'mode':'MOVIE','movie_code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ,'season_code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN,'title':'%s < %s >'%(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,RXyDlcdmfYrqHsUSJoWhgOkFzVAnTi),'thumbnail':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK}
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTi,img=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK,infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAntb,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi==1:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu={'plot':'정렬순서를 변경합니다.'}
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={}
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['mode'] ='ORDER_BY' 
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_winEpisodeOrderby()=='desc':
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL='정렬순서변경 : 최신화부터 -> 1회부터'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['orderby']='asc'
   else:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL='정렬순서변경 : 1회부터 -> 최신화부터'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['orderby']='desc'
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel='',img='',infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAntb,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnTe:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['mode'] ='EPISODE' 
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['movie_code']=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTw
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['page'] =RXyDlcdmfYrqHsUSJoWhgOkFzVAntL(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi+1)
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL='[B]%s >>[/B]'%'다음 페이지'
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIe=RXyDlcdmfYrqHsUSJoWhgOkFzVAntL(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi+1)
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIe,img='',infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAntT(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTx)>0:xbmcplugin.endOfDirectory(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_handle,cacheToDisc=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI)
 def dp_Search_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,args):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.SaveCredential(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_winCredential())
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi =RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(args.get('page'))
  if 'search_key' in args:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTp=args.get('search_key')
  else:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTp=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not RXyDlcdmfYrqHsUSJoWhgOkFzVAnTp:return
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnTx,RXyDlcdmfYrqHsUSJoWhgOkFzVAnTe=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.GetSearchList(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTp,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAntT(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTx)==0:return
  for RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ in RXyDlcdmfYrqHsUSJoWhgOkFzVAnTx:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('code')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('title')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTN=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('content_type')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTK =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('story')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('thumbnail')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTj =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('year')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTa =RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('film_rating_code')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTG=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('film_rating_short')
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAnTN=='movies': 
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN=RXyDlcdmfYrqHsUSJoWhgOkFzVAntb
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnTM ='MOVIE'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEK=''
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN='-'
   else: 
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnTM ='EPISODE'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEK='Series'
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTQ.get('info')
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu['plot']='%s (%s)\n년도 : %s\n\n%s'%(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,RXyDlcdmfYrqHsUSJoWhgOkFzVAnTG,RXyDlcdmfYrqHsUSJoWhgOkFzVAnTj,RXyDlcdmfYrqHsUSJoWhgOkFzVAnTK)
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAnTa>=19:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL+='  (%s년 - %s)'%(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTj,RXyDlcdmfYrqHsUSJoWhgOkFzVAntL(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTG))
   else:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL+='  (%s년)'%(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTj)
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={'mode':RXyDlcdmfYrqHsUSJoWhgOkFzVAnTM,'movie_code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ,'page':'1','season_code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIN,'title':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,'thumbnail':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK}
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEK,img=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK,infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnTe:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={}
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['mode'] ='SEARCH'
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['search_key']=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTp
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ['page'] =RXyDlcdmfYrqHsUSJoWhgOkFzVAntL(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi+1)
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL='[B]%s >>[/B]'%'다음 페이지'
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnIe=RXyDlcdmfYrqHsUSJoWhgOkFzVAntL(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEi+1)
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIe,img='',infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAntT(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTx)>0:xbmcplugin.endOfDirectory(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_handle)
 def Delete_Watched_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB):
  try:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTC=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB))
   with RXyDlcdmfYrqHsUSJoWhgOkFzVAntx(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTC,'w',-1,'utf-8')as fp:
    fp.write('')
  except:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC
 def dp_WatchList_Delete(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,args):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB=args.get('stype')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbG=xbmcgui.Dialog()
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEM=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbG.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEM==RXyDlcdmfYrqHsUSJoWhgOkFzVAntb:sys.exit()
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.Delete_Watched_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB):
  try:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTC=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB))
   with RXyDlcdmfYrqHsUSJoWhgOkFzVAntx(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTC,'r',-1,'utf-8')as fp:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnvb=fp.readlines()
  except:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnvb=[]
  return RXyDlcdmfYrqHsUSJoWhgOkFzVAnvb
 def Save_Watched_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB,RXyDlcdmfYrqHsUSJoWhgOkFzVAnbj):
  try:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTC=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB))
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnvE=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.Load_Watched_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB) 
   with RXyDlcdmfYrqHsUSJoWhgOkFzVAntx(RXyDlcdmfYrqHsUSJoWhgOkFzVAnTC,'w',-1,'utf-8')as fp:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnvI=urllib.parse.urlencode(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbj)
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnvI=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvI+'\n'
    fp.write(RXyDlcdmfYrqHsUSJoWhgOkFzVAnvI)
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnvT=0
    for RXyDlcdmfYrqHsUSJoWhgOkFzVAnvt in RXyDlcdmfYrqHsUSJoWhgOkFzVAnvE:
     RXyDlcdmfYrqHsUSJoWhgOkFzVAnvL=RXyDlcdmfYrqHsUSJoWhgOkFzVAnte(urllib.parse.parse_qsl(RXyDlcdmfYrqHsUSJoWhgOkFzVAnvt))
     RXyDlcdmfYrqHsUSJoWhgOkFzVAnvx=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbj.get('code')
     RXyDlcdmfYrqHsUSJoWhgOkFzVAnve=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvL.get('code')
     if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB=='seasons' and RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_settings_direct_replay()==RXyDlcdmfYrqHsUSJoWhgOkFzVAntI:
      RXyDlcdmfYrqHsUSJoWhgOkFzVAnvx=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbj.get('videoid')
      RXyDlcdmfYrqHsUSJoWhgOkFzVAnve=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvL.get('videoid')if RXyDlcdmfYrqHsUSJoWhgOkFzVAnve!=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC else '-'
     if RXyDlcdmfYrqHsUSJoWhgOkFzVAnvx!=RXyDlcdmfYrqHsUSJoWhgOkFzVAnve:
      fp.write(RXyDlcdmfYrqHsUSJoWhgOkFzVAnvt)
      RXyDlcdmfYrqHsUSJoWhgOkFzVAnvT+=1
      if RXyDlcdmfYrqHsUSJoWhgOkFzVAnvT>=50:break
  except:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC
 def dp_Watch_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ,args):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB =args.get('stype')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEb=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.get_settings_direct_replay()
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB=='-':
   for RXyDlcdmfYrqHsUSJoWhgOkFzVAnvQ in RXyDlcdmfYrqHsUSJoWhgOkFzVAnbT:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvQ.get('title')
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={'mode':RXyDlcdmfYrqHsUSJoWhgOkFzVAnvQ.get('mode'),'stype':RXyDlcdmfYrqHsUSJoWhgOkFzVAnvQ.get('stype')}
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel='',img='',infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
   if RXyDlcdmfYrqHsUSJoWhgOkFzVAntT(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbT)>0:xbmcplugin.endOfDirectory(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_handle)
  else:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnvN=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.Load_Watched_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB)
   for RXyDlcdmfYrqHsUSJoWhgOkFzVAnvK in RXyDlcdmfYrqHsUSJoWhgOkFzVAnvN:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnvj=RXyDlcdmfYrqHsUSJoWhgOkFzVAnte(urllib.parse.parse_qsl(RXyDlcdmfYrqHsUSJoWhgOkFzVAnvK))
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvj.get('code')
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL =RXyDlcdmfYrqHsUSJoWhgOkFzVAnvj.get('title')
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK =RXyDlcdmfYrqHsUSJoWhgOkFzVAnvj.get('img')
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnva =RXyDlcdmfYrqHsUSJoWhgOkFzVAnvj.get('videoid')
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu={}
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu['plot']=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL
    if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB=='movie':
     RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={'mode':'MOVIE','page':'1','movie_code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ,'season_code':'-','title':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,'thumbnail':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK}
     RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN=RXyDlcdmfYrqHsUSJoWhgOkFzVAntb
    else:
     if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEb==RXyDlcdmfYrqHsUSJoWhgOkFzVAntb or RXyDlcdmfYrqHsUSJoWhgOkFzVAnva==RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC:
      RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={'mode':'EPISODE','page':'1','movie_code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ,'season_code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ,'title':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,'thumbnail':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK}
      RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN=RXyDlcdmfYrqHsUSJoWhgOkFzVAntI
     else:
      RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={'mode':'MOVIE','movie_code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnva,'season_code':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIQ,'title':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,'thumbnail':RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK}
      RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN=RXyDlcdmfYrqHsUSJoWhgOkFzVAntb
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel='',img=RXyDlcdmfYrqHsUSJoWhgOkFzVAnIK,infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEN,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu={'plot':'시청목록을 삭제합니다.'}
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL='*** 시청목록 삭제 ***'
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ={'mode':'MYVIEW_REMOVE','stype':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEB}
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.add_dir(RXyDlcdmfYrqHsUSJoWhgOkFzVAnEL,sublabel='',img='',infoLabels=RXyDlcdmfYrqHsUSJoWhgOkFzVAnTu,isFolder=RXyDlcdmfYrqHsUSJoWhgOkFzVAntb,params=RXyDlcdmfYrqHsUSJoWhgOkFzVAnEQ)
   xbmcplugin.endOfDirectory(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ._addon_handle,cacheToDisc=RXyDlcdmfYrqHsUSJoWhgOkFzVAntb)
 def logout(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbG=xbmcgui.Dialog()
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEM=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbG.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEM==RXyDlcdmfYrqHsUSJoWhgOkFzVAntb:sys.exit()
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.wininfo_clear()
  if os.path.isfile(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbe):os.remove(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbe)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI=xbmcgui.Window(10000)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_TOKEN','')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_GUIT','')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_GUITV','')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_USERCD','')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnvG =RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.Get_Now_Datetime()
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnvM=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvG+datetime.timedelta(days=RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(__addon__.getSetting('cache_ttl')))
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI=xbmcgui.Window(10000)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu={'watcha_token':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.getProperty('WATCHA_M_TOKEN'),'watcha_guit':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.getProperty('WATCHA_M_GUIT'),'watcha_guitv':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.getProperty('WATCHA_M_GUITV'),'watcha_usercd':RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':RXyDlcdmfYrqHsUSJoWhgOkFzVAnvM.strftime('%Y-%m-%d')}
  try: 
   with RXyDlcdmfYrqHsUSJoWhgOkFzVAntx(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbe,'w',-1,'utf-8')as fp:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnvP.dump(RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu,fp)
  except RXyDlcdmfYrqHsUSJoWhgOkFzVAntQ as exception:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAntN(exception)
 def cookiefile_check(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu={}
  try: 
   with RXyDlcdmfYrqHsUSJoWhgOkFzVAntx(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbe,'r',-1,'utf-8')as fp:
    RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu= RXyDlcdmfYrqHsUSJoWhgOkFzVAnvP.load(fp)
  except RXyDlcdmfYrqHsUSJoWhgOkFzVAntQ as exception:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.wininfo_clear()
   return RXyDlcdmfYrqHsUSJoWhgOkFzVAntb
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEj =__addon__.getSetting('id')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEa =__addon__.getSetting('pw')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnvw =__addon__.getSetting('selected_profile')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_id']=base64.standard_b64decode(RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_id']).decode('utf-8')
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_pw']=base64.standard_b64decode(RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_pw']).decode('utf-8')
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEj!=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_id']or RXyDlcdmfYrqHsUSJoWhgOkFzVAnEa!=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_pw']or RXyDlcdmfYrqHsUSJoWhgOkFzVAnvw!=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_profile']:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.wininfo_clear()
   return RXyDlcdmfYrqHsUSJoWhgOkFzVAntb
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEu =RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnvB=RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_limitdate']
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEP =RXyDlcdmfYrqHsUSJoWhgOkFzVAntE(re.sub('-','',RXyDlcdmfYrqHsUSJoWhgOkFzVAnvB))
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnEP<RXyDlcdmfYrqHsUSJoWhgOkFzVAnEu:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.wininfo_clear()
   return RXyDlcdmfYrqHsUSJoWhgOkFzVAntb
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI=xbmcgui.Window(10000)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_TOKEN',RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_token'])
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_GUIT',RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_guit'])
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_GUITV',RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_guitv'])
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_USERCD',RXyDlcdmfYrqHsUSJoWhgOkFzVAnvu['watcha_usercd'])
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnEI.setProperty('WATCHA_M_LOGINTIME',RXyDlcdmfYrqHsUSJoWhgOkFzVAnvB)
  return RXyDlcdmfYrqHsUSJoWhgOkFzVAntI
 def watcha_main(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ):
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnvi=RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.main_params.get('mode',RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC)
  RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.login_main()
  if RXyDlcdmfYrqHsUSJoWhgOkFzVAnvi is RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.dp_Main_List()
  elif RXyDlcdmfYrqHsUSJoWhgOkFzVAnvi=='SUB_GROUP':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.dp_SubGroup_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.main_params)
  elif RXyDlcdmfYrqHsUSJoWhgOkFzVAnvi=='CATEGORY_LIST':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.dp_Category_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.main_params)
  elif RXyDlcdmfYrqHsUSJoWhgOkFzVAnvi=='EPISODE':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.dp_Episode_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.main_params)
  elif RXyDlcdmfYrqHsUSJoWhgOkFzVAnvi=='ORDER_BY':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.dp_setEpOrderby(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.main_params)
  elif RXyDlcdmfYrqHsUSJoWhgOkFzVAnvi=='SEARCH':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.dp_Search_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.main_params)
  elif RXyDlcdmfYrqHsUSJoWhgOkFzVAnvi=='MOVIE':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.play_VIDEO(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.main_params)
   time.sleep(0.1)
  elif RXyDlcdmfYrqHsUSJoWhgOkFzVAnvi=='WATCH':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.dp_Watch_List(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.main_params)
  elif RXyDlcdmfYrqHsUSJoWhgOkFzVAnvi=='MYVIEW_REMOVE':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.dp_WatchList_Delete(RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.main_params)
  elif RXyDlcdmfYrqHsUSJoWhgOkFzVAnvi=='LOGOUT':
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnbQ.logout()
  else:
   RXyDlcdmfYrqHsUSJoWhgOkFzVAnvC
# Created by pyminifier (https://github.com/liftoff/pyminifier)
