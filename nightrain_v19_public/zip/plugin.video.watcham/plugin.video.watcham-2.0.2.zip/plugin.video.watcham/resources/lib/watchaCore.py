__author__="NightRain"
LphJxOsAYDkCwuvoNGrKiBeTgnRFIa=object
LphJxOsAYDkCwuvoNGrKiBeTgnRFIW=None
LphJxOsAYDkCwuvoNGrKiBeTgnRFIb=False
LphJxOsAYDkCwuvoNGrKiBeTgnRFIH=True
LphJxOsAYDkCwuvoNGrKiBeTgnRFIV=Exception
LphJxOsAYDkCwuvoNGrKiBeTgnRFId=str
LphJxOsAYDkCwuvoNGrKiBeTgnRFIc=print
LphJxOsAYDkCwuvoNGrKiBeTgnRFIz=len
LphJxOsAYDkCwuvoNGrKiBeTgnRFIf=int
LphJxOsAYDkCwuvoNGrKiBeTgnRFIM=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import base64
import requests
import datetime
LphJxOsAYDkCwuvoNGrKiBeTgnRFab='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
class LphJxOsAYDkCwuvoNGrKiBeTgnRFaW(LphJxOsAYDkCwuvoNGrKiBeTgnRFIa):
 def __init__(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_TOKEN ='' 
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUIT =''
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUITV =''
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_USERCD=''
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.API_DOMAIN ='https://play.watcha.net'
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.EPISODE_LIMIT=20
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.SEARCH_LIMIT =30
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.DEFAULT_HEADER={'user-agent':LphJxOsAYDkCwuvoNGrKiBeTgnRFab,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,jobtype,LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,payload=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,params=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,cookies=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,redirects=LphJxOsAYDkCwuvoNGrKiBeTgnRFIb):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaH=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.DEFAULT_HEADER
  if headers:LphJxOsAYDkCwuvoNGrKiBeTgnRFaH.update(headers)
  if jobtype=='Get':
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaV=requests.get(LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,params=params,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFaH,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaV=requests.put(LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,data=payload,params=params,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFaH,cookies=cookies,allow_redirects=redirects)
  else:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaV=requests.post(LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,data=payload,params=params,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFaH,cookies=cookies,allow_redirects=redirects)
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFaV
 def SaveCredential(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,LphJxOsAYDkCwuvoNGrKiBeTgnRFad):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_TOKEN =LphJxOsAYDkCwuvoNGrKiBeTgnRFad.get('watcha_token')
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUIT =LphJxOsAYDkCwuvoNGrKiBeTgnRFad.get('watcha_guit')
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUITV =LphJxOsAYDkCwuvoNGrKiBeTgnRFad.get('watcha_guitv')
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_USERCD =LphJxOsAYDkCwuvoNGrKiBeTgnRFad.get('watcha_usercd')
 def SaveCredential_usercd(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,LphJxOsAYDkCwuvoNGrKiBeTgnRFac):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_USERCD=LphJxOsAYDkCwuvoNGrKiBeTgnRFac
 def SaveCredential_guitv(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,LphJxOsAYDkCwuvoNGrKiBeTgnRFaz,LphJxOsAYDkCwuvoNGrKiBeTgnRFaf):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUITV=LphJxOsAYDkCwuvoNGrKiBeTgnRFaz
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_TOKEN=LphJxOsAYDkCwuvoNGrKiBeTgnRFaf 
 def ClearCredential(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_TOKEN ='' 
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUIT =''
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUITV =''
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_USERCD=''
 def LoadCredential(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFad={'watcha_token':LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_TOKEN,'watcha_guit':LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUIT,'watcha_guitv':LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUITV,'watcha_usercd':LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_USERCD}
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFad
 def makeDefaultCookies(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaM={'_s_guit':LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUIT,'_guinness-premium_session':LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_TOKEN}
  if LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUITV:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaM['_s_guitv']=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_GUITV
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFaM
 def makeurl(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,domain,path,query1=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,query2=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaq=domain+path
  if query1:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaq+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaq+='&%s'%urllib.parse.urlencode(query2)
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFaq
 def GetCredential(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,user_id,user_pw,user_pf):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaQ=LphJxOsAYDkCwuvoNGrKiBeTgnRFIb
  LphJxOsAYDkCwuvoNGrKiBeTgnRFam=LphJxOsAYDkCwuvoNGrKiBeTgnRFay='-'
  try:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaU=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.API_DOMAIN+'/api/session'
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaP={'email':user_id,'password':user_pw}
   LphJxOsAYDkCwuvoNGrKiBeTgnRFal={'accept':'application/vnd.frograms+json;version=4'}
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaj=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.callRequestCookies('Post',LphJxOsAYDkCwuvoNGrKiBeTgnRFaU,payload=LphJxOsAYDkCwuvoNGrKiBeTgnRFaP,params=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFal,cookies=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW)
   for LphJxOsAYDkCwuvoNGrKiBeTgnRFaE in LphJxOsAYDkCwuvoNGrKiBeTgnRFaj.cookies:
    if LphJxOsAYDkCwuvoNGrKiBeTgnRFaE.name=='_guinness-premium_session':
     LphJxOsAYDkCwuvoNGrKiBeTgnRFay=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE.value
    elif LphJxOsAYDkCwuvoNGrKiBeTgnRFaE.name=='_s_guit':
     LphJxOsAYDkCwuvoNGrKiBeTgnRFam=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE.value
   if LphJxOsAYDkCwuvoNGrKiBeTgnRFay:LphJxOsAYDkCwuvoNGrKiBeTgnRFaQ=LphJxOsAYDkCwuvoNGrKiBeTgnRFIH
  except LphJxOsAYDkCwuvoNGrKiBeTgnRFIV as exception:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFam=LphJxOsAYDkCwuvoNGrKiBeTgnRFay='' 
  LphJxOsAYDkCwuvoNGrKiBeTgnRFad={'watcha_guit':LphJxOsAYDkCwuvoNGrKiBeTgnRFam,'watcha_token':LphJxOsAYDkCwuvoNGrKiBeTgnRFay,'watcha_guitv':'','watcha_usercd':''}
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.SaveCredential(LphJxOsAYDkCwuvoNGrKiBeTgnRFad)
  try:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaS=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.GetProfilesList()
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWa =LphJxOsAYDkCwuvoNGrKiBeTgnRFaS[user_pf]
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.SaveCredential_usercd(LphJxOsAYDkCwuvoNGrKiBeTgnRFWa)
  except LphJxOsAYDkCwuvoNGrKiBeTgnRFIV as exception:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.ClearCredential()
   return LphJxOsAYDkCwuvoNGrKiBeTgnRFIb
  if user_pf!=0:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaz,LphJxOsAYDkCwuvoNGrKiBeTgnRFaf=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.GetProfilesConvert(LphJxOsAYDkCwuvoNGrKiBeTgnRFWa)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.SaveCredential_guitv(LphJxOsAYDkCwuvoNGrKiBeTgnRFaz,LphJxOsAYDkCwuvoNGrKiBeTgnRFaf)
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFaQ
 def GetSubGroupList(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,stype):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFWb=[]
  try:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWI ='/api/categories.json'
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaq=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeurl(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.API_DOMAIN,LphJxOsAYDkCwuvoNGrKiBeTgnRFWI)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaE=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeDefaultCookies()
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaj=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.callRequestCookies('Get',LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,payload=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,params=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,cookies=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWH=json.loads(LphJxOsAYDkCwuvoNGrKiBeTgnRFaj.text)
   if not('genres' in LphJxOsAYDkCwuvoNGrKiBeTgnRFWH):return LphJxOsAYDkCwuvoNGrKiBeTgnRFWb
   if stype=='genres':
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWV=LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['genres']
   else:
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWV=LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['tags']
   for LphJxOsAYDkCwuvoNGrKiBeTgnRFWd in LphJxOsAYDkCwuvoNGrKiBeTgnRFWV:
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWc=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['name']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWz =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['api_path']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWf =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['entity']['id']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWM={'group_name':LphJxOsAYDkCwuvoNGrKiBeTgnRFWc,'api_path':LphJxOsAYDkCwuvoNGrKiBeTgnRFWz,'tag_id':LphJxOsAYDkCwuvoNGrKiBeTgnRFId(LphJxOsAYDkCwuvoNGrKiBeTgnRFWf)}
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWb.append(LphJxOsAYDkCwuvoNGrKiBeTgnRFWM)
  except LphJxOsAYDkCwuvoNGrKiBeTgnRFIV as exception:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFIc(exception)
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFWb
 def GetCategoryList(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,stype,LphJxOsAYDkCwuvoNGrKiBeTgnRFWf,LphJxOsAYDkCwuvoNGrKiBeTgnRFWz,page_int,in_sort):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFWb=[]
  LphJxOsAYDkCwuvoNGrKiBeTgnRFWq=LphJxOsAYDkCwuvoNGrKiBeTgnRFIb
  LphJxOsAYDkCwuvoNGrKiBeTgnRFWt={}
  try:
   if 'categories' in LphJxOsAYDkCwuvoNGrKiBeTgnRFWz:
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWI ='/api/categories/contents.json'
    if stype=='genres':
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWt['genre']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWf
    else:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWt['tag'] =LphJxOsAYDkCwuvoNGrKiBeTgnRFWf
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWt['order']=in_sort 
    if page_int>1:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWt['page']=LphJxOsAYDkCwuvoNGrKiBeTgnRFId(page_int-1)
   else: 
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWI ='/api/'+LphJxOsAYDkCwuvoNGrKiBeTgnRFWz+'.json'
    if page_int>1:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWt['page']=LphJxOsAYDkCwuvoNGrKiBeTgnRFId(page_int)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaq=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeurl(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.API_DOMAIN,LphJxOsAYDkCwuvoNGrKiBeTgnRFWI)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaE=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeDefaultCookies()
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaj=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.callRequestCookies('Get',LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,payload=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,params=LphJxOsAYDkCwuvoNGrKiBeTgnRFWt,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,cookies=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWH=json.loads(LphJxOsAYDkCwuvoNGrKiBeTgnRFaj.text)
   if not('contents' in LphJxOsAYDkCwuvoNGrKiBeTgnRFWH):return LphJxOsAYDkCwuvoNGrKiBeTgnRFWb,LphJxOsAYDkCwuvoNGrKiBeTgnRFWq
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWV=LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['contents']
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWq=LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['meta']['has_next']
   for LphJxOsAYDkCwuvoNGrKiBeTgnRFWd in LphJxOsAYDkCwuvoNGrKiBeTgnRFWV:
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWX =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['code']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWQ=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['content_type']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWm =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['title']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWU =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['story']
    if LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['thumbnail']!=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWP =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['thumbnail']['medium']
    else:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWP =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['stillcut']['medium']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWl =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['year']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWj =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['film_rating_code']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWE=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['film_rating_short']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy={}
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['mpaa']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['film_rating_long']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['year']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['year']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['title']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['title']
    if LphJxOsAYDkCwuvoNGrKiBeTgnRFWQ=='movies':
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['mediatype']='movie' 
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['duration']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['duration']
    else:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['mediatype']='episode' 
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWM={'code':LphJxOsAYDkCwuvoNGrKiBeTgnRFWX,'content_type':LphJxOsAYDkCwuvoNGrKiBeTgnRFWQ,'title':LphJxOsAYDkCwuvoNGrKiBeTgnRFWm,'story':LphJxOsAYDkCwuvoNGrKiBeTgnRFWU,'thumbnail':LphJxOsAYDkCwuvoNGrKiBeTgnRFWP,'year':LphJxOsAYDkCwuvoNGrKiBeTgnRFWl,'film_rating_code':LphJxOsAYDkCwuvoNGrKiBeTgnRFWj,'film_rating_short':LphJxOsAYDkCwuvoNGrKiBeTgnRFWE,'info':LphJxOsAYDkCwuvoNGrKiBeTgnRFWy}
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWb.append(LphJxOsAYDkCwuvoNGrKiBeTgnRFWM)
  except LphJxOsAYDkCwuvoNGrKiBeTgnRFIV as exception:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFIc(exception)
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFWb,LphJxOsAYDkCwuvoNGrKiBeTgnRFWq
 def GetCategoryList_morepage(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,stype,LphJxOsAYDkCwuvoNGrKiBeTgnRFWf,LphJxOsAYDkCwuvoNGrKiBeTgnRFWz,page_int,in_sort):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFWq=LphJxOsAYDkCwuvoNGrKiBeTgnRFIb
  if not('categories' in LphJxOsAYDkCwuvoNGrKiBeTgnRFWz):return LphJxOsAYDkCwuvoNGrKiBeTgnRFIH
  try:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWI ='/api/categories/contents.json'
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWt={}
   if stype=='genres':
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWt['genre']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWf
   else:
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWt['tag'] =LphJxOsAYDkCwuvoNGrKiBeTgnRFWf
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWt['order']=in_sort 
   if page_int>1:
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWt['page']=LphJxOsAYDkCwuvoNGrKiBeTgnRFId(page_int-1)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaq=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeurl(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.API_DOMAIN,LphJxOsAYDkCwuvoNGrKiBeTgnRFWI)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaE=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeDefaultCookies()
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaj=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.callRequestCookies('Get',LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,payload=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,params=LphJxOsAYDkCwuvoNGrKiBeTgnRFWt,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,cookies=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWH=json.loads(LphJxOsAYDkCwuvoNGrKiBeTgnRFaj.text)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWq=LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['meta']['has_next']
  except LphJxOsAYDkCwuvoNGrKiBeTgnRFIV as exception:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFIc(exception)
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFWq
 def GetEpisodoList(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,program_code,page_int,orderby='asc'):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFWb=[]
  LphJxOsAYDkCwuvoNGrKiBeTgnRFWq=LphJxOsAYDkCwuvoNGrKiBeTgnRFIb
  LphJxOsAYDkCwuvoNGrKiBeTgnRFWS=''
  try:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWI ='/api/contents/'+program_code+'/tv_episodes.json'
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWt={'all':'true'}
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaq=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeurl(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.API_DOMAIN,LphJxOsAYDkCwuvoNGrKiBeTgnRFWI)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaE=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeDefaultCookies()
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaj=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.callRequestCookies('Get',LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,payload=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,params=LphJxOsAYDkCwuvoNGrKiBeTgnRFWt,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,cookies=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWH=json.loads(LphJxOsAYDkCwuvoNGrKiBeTgnRFaj.text)
   if not('tv_episode_codes' in LphJxOsAYDkCwuvoNGrKiBeTgnRFWH):return LphJxOsAYDkCwuvoNGrKiBeTgnRFWb,LphJxOsAYDkCwuvoNGrKiBeTgnRFWq
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWV=LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['tv_episode_codes']
   LphJxOsAYDkCwuvoNGrKiBeTgnRFba=LphJxOsAYDkCwuvoNGrKiBeTgnRFIz(LphJxOsAYDkCwuvoNGrKiBeTgnRFWV)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFbW =LphJxOsAYDkCwuvoNGrKiBeTgnRFIf(LphJxOsAYDkCwuvoNGrKiBeTgnRFba//(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    LphJxOsAYDkCwuvoNGrKiBeTgnRFbI =(LphJxOsAYDkCwuvoNGrKiBeTgnRFba-1)-((page_int-1)*LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.EPISODE_LIMIT)
   else:
    LphJxOsAYDkCwuvoNGrKiBeTgnRFbI =(page_int-1)*LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.EPISODE_LIMIT
   for i in LphJxOsAYDkCwuvoNGrKiBeTgnRFIM(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.EPISODE_LIMIT):
    if orderby=='desc':
     LphJxOsAYDkCwuvoNGrKiBeTgnRFbH=LphJxOsAYDkCwuvoNGrKiBeTgnRFbI-i
     if LphJxOsAYDkCwuvoNGrKiBeTgnRFbH<0:break
    else:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFbH=LphJxOsAYDkCwuvoNGrKiBeTgnRFbI+i
     if LphJxOsAYDkCwuvoNGrKiBeTgnRFbH>=LphJxOsAYDkCwuvoNGrKiBeTgnRFba:break
    if LphJxOsAYDkCwuvoNGrKiBeTgnRFWS!='':LphJxOsAYDkCwuvoNGrKiBeTgnRFWS+=','
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWS+=LphJxOsAYDkCwuvoNGrKiBeTgnRFWV[LphJxOsAYDkCwuvoNGrKiBeTgnRFbH]
   if LphJxOsAYDkCwuvoNGrKiBeTgnRFbW>page_int:LphJxOsAYDkCwuvoNGrKiBeTgnRFWq=LphJxOsAYDkCwuvoNGrKiBeTgnRFIH
  except LphJxOsAYDkCwuvoNGrKiBeTgnRFIV as exception:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFIc(exception)
  try:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWt={'codes':LphJxOsAYDkCwuvoNGrKiBeTgnRFWS}
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaq=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeurl(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.API_DOMAIN,LphJxOsAYDkCwuvoNGrKiBeTgnRFWI)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaE=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeDefaultCookies()
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaj=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.callRequestCookies('Get',LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,payload=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,params=LphJxOsAYDkCwuvoNGrKiBeTgnRFWt,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,cookies=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWH=json.loads(LphJxOsAYDkCwuvoNGrKiBeTgnRFaj.text)
   if not('tv_episodes' in LphJxOsAYDkCwuvoNGrKiBeTgnRFWH):return LphJxOsAYDkCwuvoNGrKiBeTgnRFWb
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWV=LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['tv_episodes']
   for LphJxOsAYDkCwuvoNGrKiBeTgnRFWd in LphJxOsAYDkCwuvoNGrKiBeTgnRFWV:
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWX =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['code']
    if LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['title']:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWm =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['title']
    else:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWm =''
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWP =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['stillcut']['medium']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFbV =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['display_number']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFbd=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['tv_season_title']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy={}
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['mediatype'] ='episode'
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['tvshowtitle']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWm if LphJxOsAYDkCwuvoNGrKiBeTgnRFWm else LphJxOsAYDkCwuvoNGrKiBeTgnRFbd
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['title'] ='%s %s'%(LphJxOsAYDkCwuvoNGrKiBeTgnRFbd,LphJxOsAYDkCwuvoNGrKiBeTgnRFbV)if LphJxOsAYDkCwuvoNGrKiBeTgnRFWm else LphJxOsAYDkCwuvoNGrKiBeTgnRFbV
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['duration'] =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['duration']
    try:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['episode']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['episode_number']
    except:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFIW
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWM={'code':LphJxOsAYDkCwuvoNGrKiBeTgnRFWX,'title':LphJxOsAYDkCwuvoNGrKiBeTgnRFWm,'thumbnail':LphJxOsAYDkCwuvoNGrKiBeTgnRFWP,'display_num':LphJxOsAYDkCwuvoNGrKiBeTgnRFbV,'season_title':LphJxOsAYDkCwuvoNGrKiBeTgnRFbd,'info':LphJxOsAYDkCwuvoNGrKiBeTgnRFWy}
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWb.append(LphJxOsAYDkCwuvoNGrKiBeTgnRFWM)
  except LphJxOsAYDkCwuvoNGrKiBeTgnRFIV as exception:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFIc(exception)
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFWb,LphJxOsAYDkCwuvoNGrKiBeTgnRFWq
 def GetSearchList(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,search_key,page_int):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFbc=[]
  LphJxOsAYDkCwuvoNGrKiBeTgnRFWq=LphJxOsAYDkCwuvoNGrKiBeTgnRFIb
  try:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWI ='/api/search.json'
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWt={'query':search_key,'page':LphJxOsAYDkCwuvoNGrKiBeTgnRFId(page_int),'per':LphJxOsAYDkCwuvoNGrKiBeTgnRFId(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.SEARCH_LIMIT),'exclude':'limited'}
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaq=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeurl(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.API_DOMAIN,LphJxOsAYDkCwuvoNGrKiBeTgnRFWI)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaE=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeDefaultCookies()
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaj=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.callRequestCookies('Get',LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,payload=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,params=LphJxOsAYDkCwuvoNGrKiBeTgnRFWt,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,cookies=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWH=json.loads(LphJxOsAYDkCwuvoNGrKiBeTgnRFaj.text)
   if not('results' in LphJxOsAYDkCwuvoNGrKiBeTgnRFWH):return LphJxOsAYDkCwuvoNGrKiBeTgnRFbc,LphJxOsAYDkCwuvoNGrKiBeTgnRFWq
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWV=LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['results']
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWq=LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['meta']['has_next']
   for LphJxOsAYDkCwuvoNGrKiBeTgnRFWd in LphJxOsAYDkCwuvoNGrKiBeTgnRFWV:
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWX =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['code']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWQ=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['content_type']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWm =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['title']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWU =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['story']
    if LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['thumbnail']!=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWP =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['thumbnail']['medium']
    else:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWP =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['stillcut']['medium']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWl =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['year']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWj =LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['film_rating_code']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWE=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['film_rating_short']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy={}
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['mpaa']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['film_rating_long']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['year']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['year']
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['title']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['title']
    if LphJxOsAYDkCwuvoNGrKiBeTgnRFWQ=='movies':
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['mediatype']='movie' 
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['duration']=LphJxOsAYDkCwuvoNGrKiBeTgnRFWd['duration']
    else:
     LphJxOsAYDkCwuvoNGrKiBeTgnRFWy['mediatype']='episode' 
    LphJxOsAYDkCwuvoNGrKiBeTgnRFWM={'code':LphJxOsAYDkCwuvoNGrKiBeTgnRFWX,'content_type':LphJxOsAYDkCwuvoNGrKiBeTgnRFWQ,'title':LphJxOsAYDkCwuvoNGrKiBeTgnRFWm,'story':LphJxOsAYDkCwuvoNGrKiBeTgnRFWU,'thumbnail':LphJxOsAYDkCwuvoNGrKiBeTgnRFWP,'year':LphJxOsAYDkCwuvoNGrKiBeTgnRFWl,'film_rating_code':LphJxOsAYDkCwuvoNGrKiBeTgnRFWj,'film_rating_short':LphJxOsAYDkCwuvoNGrKiBeTgnRFWE,'info':LphJxOsAYDkCwuvoNGrKiBeTgnRFWy}
    LphJxOsAYDkCwuvoNGrKiBeTgnRFbc.append(LphJxOsAYDkCwuvoNGrKiBeTgnRFWM)
  except LphJxOsAYDkCwuvoNGrKiBeTgnRFIV as exception:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFIc(exception)
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFbc,LphJxOsAYDkCwuvoNGrKiBeTgnRFWq
 def GetProfilesList(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFaS=[]
  try:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWI ='/manage_profiles'
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaq=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeurl(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.API_DOMAIN,LphJxOsAYDkCwuvoNGrKiBeTgnRFWI)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaE=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeDefaultCookies()
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaj=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.callRequestCookies('Get',LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,payload=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,params=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,cookies=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFbz=LphJxOsAYDkCwuvoNGrKiBeTgnRFaj.text
   LphJxOsAYDkCwuvoNGrKiBeTgnRFbf =re.findall('/api/users/me.{5000}',LphJxOsAYDkCwuvoNGrKiBeTgnRFbz)[0]
   LphJxOsAYDkCwuvoNGrKiBeTgnRFbf =LphJxOsAYDkCwuvoNGrKiBeTgnRFbf.replace('&quot;','')
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaS=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',LphJxOsAYDkCwuvoNGrKiBeTgnRFbf)
   for i in LphJxOsAYDkCwuvoNGrKiBeTgnRFIM(LphJxOsAYDkCwuvoNGrKiBeTgnRFIz(LphJxOsAYDkCwuvoNGrKiBeTgnRFaS)):
    LphJxOsAYDkCwuvoNGrKiBeTgnRFbM=LphJxOsAYDkCwuvoNGrKiBeTgnRFaS[i]
    LphJxOsAYDkCwuvoNGrKiBeTgnRFbM =LphJxOsAYDkCwuvoNGrKiBeTgnRFbM.split(':')[1]
    LphJxOsAYDkCwuvoNGrKiBeTgnRFaS[i]=LphJxOsAYDkCwuvoNGrKiBeTgnRFbM.split(',')[0]
  except LphJxOsAYDkCwuvoNGrKiBeTgnRFIV as exception:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFIc(exception)
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFaS
 def GetProfilesConvert(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,LphJxOsAYDkCwuvoNGrKiBeTgnRFac):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFbq=''
  LphJxOsAYDkCwuvoNGrKiBeTgnRFbt=''
  try:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWI ='/api/users/'+LphJxOsAYDkCwuvoNGrKiBeTgnRFac+'/convert'
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaq=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeurl(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.API_DOMAIN,LphJxOsAYDkCwuvoNGrKiBeTgnRFWI)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaE=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeDefaultCookies()
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaj=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.callRequestCookies('Put',LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,payload=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,params=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,cookies=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE)
   for LphJxOsAYDkCwuvoNGrKiBeTgnRFaE in LphJxOsAYDkCwuvoNGrKiBeTgnRFaj.cookies:
    if LphJxOsAYDkCwuvoNGrKiBeTgnRFaE.name=='_s_guitv':
     LphJxOsAYDkCwuvoNGrKiBeTgnRFbX=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE.value
    elif LphJxOsAYDkCwuvoNGrKiBeTgnRFaE.name=='_guinness-premium_session':
     LphJxOsAYDkCwuvoNGrKiBeTgnRFay=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE.value
   if LphJxOsAYDkCwuvoNGrKiBeTgnRFbX:
    LphJxOsAYDkCwuvoNGrKiBeTgnRFbq=LphJxOsAYDkCwuvoNGrKiBeTgnRFbX
   if LphJxOsAYDkCwuvoNGrKiBeTgnRFay:
    LphJxOsAYDkCwuvoNGrKiBeTgnRFbt=LphJxOsAYDkCwuvoNGrKiBeTgnRFay
  except LphJxOsAYDkCwuvoNGrKiBeTgnRFIV as exception:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFbq=''
   LphJxOsAYDkCwuvoNGrKiBeTgnRFbt=''
  return LphJxOsAYDkCwuvoNGrKiBeTgnRFbq,LphJxOsAYDkCwuvoNGrKiBeTgnRFbt
 def Get_Now_Datetime(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI,movie_code,quality_str):
  LphJxOsAYDkCwuvoNGrKiBeTgnRFbm=LphJxOsAYDkCwuvoNGrKiBeTgnRFbP=LphJxOsAYDkCwuvoNGrKiBeTgnRFbS=''
  try:
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWI='/api/watch/'+movie_code+'.json'
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaq=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeurl(LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.API_DOMAIN,LphJxOsAYDkCwuvoNGrKiBeTgnRFWI)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFal={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaE=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.makeDefaultCookies()
   LphJxOsAYDkCwuvoNGrKiBeTgnRFaj=LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.callRequestCookies('Get',LphJxOsAYDkCwuvoNGrKiBeTgnRFaq,payload=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,params=LphJxOsAYDkCwuvoNGrKiBeTgnRFIW,headers=LphJxOsAYDkCwuvoNGrKiBeTgnRFal,cookies=LphJxOsAYDkCwuvoNGrKiBeTgnRFaE)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFWH=json.loads(LphJxOsAYDkCwuvoNGrKiBeTgnRFaj.text)
   LphJxOsAYDkCwuvoNGrKiBeTgnRFbm=LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['streams'][0]['source']
   if LphJxOsAYDkCwuvoNGrKiBeTgnRFbm==LphJxOsAYDkCwuvoNGrKiBeTgnRFIW:return(LphJxOsAYDkCwuvoNGrKiBeTgnRFbm,LphJxOsAYDkCwuvoNGrKiBeTgnRFbP,LphJxOsAYDkCwuvoNGrKiBeTgnRFbS)
   if 'subtitles' in LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['streams'][0]:
    for LphJxOsAYDkCwuvoNGrKiBeTgnRFbU in LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['streams'][0]['subtitles']:
     if LphJxOsAYDkCwuvoNGrKiBeTgnRFbU['lang']=='ko':
      LphJxOsAYDkCwuvoNGrKiBeTgnRFbP=LphJxOsAYDkCwuvoNGrKiBeTgnRFbU['url']
      break
   LphJxOsAYDkCwuvoNGrKiBeTgnRFbl =LphJxOsAYDkCwuvoNGrKiBeTgnRFWH['ping_payload']
   LphJxOsAYDkCwuvoNGrKiBeTgnRFbj =LphJxOsAYDkCwuvoNGrKiBeTgnRFaI.WATCHA_USERCD
   LphJxOsAYDkCwuvoNGrKiBeTgnRFbE={'merchant':'giitd_frograms','sessionId':LphJxOsAYDkCwuvoNGrKiBeTgnRFbl,'userId':LphJxOsAYDkCwuvoNGrKiBeTgnRFbj}
   LphJxOsAYDkCwuvoNGrKiBeTgnRFby=json.dumps(LphJxOsAYDkCwuvoNGrKiBeTgnRFbE,separators=(",",":")).encode('UTF-8')
   LphJxOsAYDkCwuvoNGrKiBeTgnRFbS=base64.b64encode(LphJxOsAYDkCwuvoNGrKiBeTgnRFby)
  except LphJxOsAYDkCwuvoNGrKiBeTgnRFIV as exception:
   return(LphJxOsAYDkCwuvoNGrKiBeTgnRFbm,LphJxOsAYDkCwuvoNGrKiBeTgnRFbP,LphJxOsAYDkCwuvoNGrKiBeTgnRFbS)
  return(LphJxOsAYDkCwuvoNGrKiBeTgnRFbm,LphJxOsAYDkCwuvoNGrKiBeTgnRFbP,LphJxOsAYDkCwuvoNGrKiBeTgnRFbS) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
