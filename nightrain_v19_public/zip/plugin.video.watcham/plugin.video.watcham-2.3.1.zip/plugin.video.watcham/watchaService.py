__author__="NightRain"
BGQpPFkDYSLOhKsIyovunUciNmrWjH=int
import xbmc,xbmcaddon,xbmcvfs
import os
import sys
BGQpPFkDYSLOhKsIyovunUciNmrWjb=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
BGQpPFkDYSLOhKsIyovunUciNmrWjz =os.path.join(BGQpPFkDYSLOhKsIyovunUciNmrWjb,'resources','lib')
sys.path.append(BGQpPFkDYSLOhKsIyovunUciNmrWjz)
from watchaProxy import*
BGQpPFkDYSLOhKsIyovunUciNmrWjV=xbmc.Monitor()
BGQpPFkDYSLOhKsIyovunUciNmrWjw=LROEXFtjKrqGwmWiSYAQyfuMNhoges()
xbmc.sleep(3000)
BGQpPFkDYSLOhKsIyovunUciNmrWjw.PORT=BGQpPFkDYSLOhKsIyovunUciNmrWjH(xbmcaddon.Addon().getSetting('proxyPort'))
BGQpPFkDYSLOhKsIyovunUciNmrWjw.start()
while not BGQpPFkDYSLOhKsIyovunUciNmrWjV.abortRequested():
 if BGQpPFkDYSLOhKsIyovunUciNmrWjV.waitForAbort(60):
  break
BGQpPFkDYSLOhKsIyovunUciNmrWjw.stop()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
