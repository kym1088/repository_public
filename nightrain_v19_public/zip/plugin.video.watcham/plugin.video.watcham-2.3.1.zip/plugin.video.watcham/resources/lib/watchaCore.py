__author__="NightRain"
LXjMaPWOkJbuNynsSKehlfVBvCDIFz=object
LXjMaPWOkJbuNynsSKehlfVBvCDIFY=None
LXjMaPWOkJbuNynsSKehlfVBvCDIFT=False
LXjMaPWOkJbuNynsSKehlfVBvCDIFx=open
LXjMaPWOkJbuNynsSKehlfVBvCDIFU=True
LXjMaPWOkJbuNynsSKehlfVBvCDIFQ=id
LXjMaPWOkJbuNynsSKehlfVBvCDIoH=str
LXjMaPWOkJbuNynsSKehlfVBvCDIoc=range
LXjMaPWOkJbuNynsSKehlfVBvCDIod=Exception
LXjMaPWOkJbuNynsSKehlfVBvCDIoG=print
LXjMaPWOkJbuNynsSKehlfVBvCDIoF=int
LXjMaPWOkJbuNynsSKehlfVBvCDIog=len
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
import string
import random
class LXjMaPWOkJbuNynsSKehlfVBvCDIHc(LXjMaPWOkJbuNynsSKehlfVBvCDIFz):
 def __init__(LXjMaPWOkJbuNynsSKehlfVBvCDIHd):
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC ={}
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Init_WC_Total()
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.MAIN_DOMAIN ='https://watcha.com'
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN ='https://api-mars.watcha.com'
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.EPISODE_LIMIT=20
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.SEARCH_LIMIT =30
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36'
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.USER_AGENT2 ='User-Agent: Dalvik/2.1.0 (Linux; U; Android 9; A95X_F3_Air Build/A95X_F3_AIR_M)/WatchaPlay-Android/1.10.34'
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.DEFAULT_HEADER={'user-agent':LXjMaPWOkJbuNynsSKehlfVBvCDIHd.USER_AGENT}
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC_SUBTITLE_VTT =''
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC_SUBTITLE_SRT =''
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC_COOKIE_FILENAME =''
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC_SEARCHEDC_FILENAME=''
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC_STREAM_FILENAME =''
 def Get_Base_Headers(LXjMaPWOkJbuNynsSKehlfVBvCDIHd):
  LXjMaPWOkJbuNynsSKehlfVBvCDIHG={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.3',}
  return LXjMaPWOkJbuNynsSKehlfVBvCDIHG
 def Get_Base_Headers_v2(LXjMaPWOkJbuNynsSKehlfVBvCDIHd):
  LXjMaPWOkJbuNynsSKehlfVBvCDIHF ='1.10.35' 
  LXjMaPWOkJbuNynsSKehlfVBvCDIHo ='30' 
  LXjMaPWOkJbuNynsSKehlfVBvCDIHg ='NVIDIA SHIELD Android TV'
  LXjMaPWOkJbuNynsSKehlfVBvCDIHr =base64.standard_b64encode((LXjMaPWOkJbuNynsSKehlfVBvCDIHg+'-'+LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['deviceId2']).encode()).decode('utf-8') 
  LXjMaPWOkJbuNynsSKehlfVBvCDIHE ='1920x1080/2.0/320/xhdpi'
  LXjMaPWOkJbuNynsSKehlfVBvCDIHq ='2596eb93-6e7f-4eba-925c-ddf783246860' 
  LXjMaPWOkJbuNynsSKehlfVBvCDIHG={'X-WatchaPlay-Client-Device-Id':LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['deviceId1'],'X-WatchaPlay-Client-Device-Id2':LXjMaPWOkJbuNynsSKehlfVBvCDIHr,'X-WatchaPlay-Client-Device-Name':LXjMaPWOkJbuNynsSKehlfVBvCDIHg,'X-WatchaPlay-Client-ADID':LXjMaPWOkJbuNynsSKehlfVBvCDIHq,'X-WatchaPlay-Client':'WatchaPlay-Android','X-WatchaPlay-Client-Version':LXjMaPWOkJbuNynsSKehlfVBvCDIHF,'X-WatchaPlay-Client-Subclass':'Normal','X-WatchaPlay-Client-Ui-Mode-Name':'television','X-WatchaPlay-Screen':LXjMaPWOkJbuNynsSKehlfVBvCDIHE,'X-WatchaPlay-Network-Status':'wifi','X-WatchaPlay-Appsflyer-Device-ID':LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['flyerId'],'X-FROGRAMS-CLIENT':'Mars-Android-Box','X-FROGRAMS-APP-CODE':'mars','X-FROGRAMS-DEVICE-IDENTIFIER':LXjMaPWOkJbuNynsSKehlfVBvCDIHr,'X-FROGRAMS-DEVICE-NAME':LXjMaPWOkJbuNynsSKehlfVBvCDIHg,'X-FROGRAMS-AD-ID':LXjMaPWOkJbuNynsSKehlfVBvCDIHq,'X-FROGRAMS-APPSFLYER-DEVICE-ID':LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['flyerId'],'X-FROGRAMS-VERSION':LXjMaPWOkJbuNynsSKehlfVBvCDIHF,'X-FROGRAMS-OS-VERSION':LXjMaPWOkJbuNynsSKehlfVBvCDIHo,'X-FROGRAMS-NETWORK-STATUS':'wifi','X-FROGRAMS-MARS-SCREEN':LXjMaPWOkJbuNynsSKehlfVBvCDIHE,'X-FROGRAMS-MARS-UI-MODE':'television',}
  return LXjMaPWOkJbuNynsSKehlfVBvCDIHG
 def Init_WC_Total(LXjMaPWOkJbuNynsSKehlfVBvCDIHd):
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC={'account':{},'cookies':{'watcha_token':'','watcha_guit':'','watcha_guitv':'','watcha_usercd':'',},}
 def callRequestCookies(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,jobtype,LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,redirects=LXjMaPWOkJbuNynsSKehlfVBvCDIFT):
  LXjMaPWOkJbuNynsSKehlfVBvCDIHm=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.DEFAULT_HEADER
  if headers:LXjMaPWOkJbuNynsSKehlfVBvCDIHm.update(headers)
  if jobtype=='Get':
   LXjMaPWOkJbuNynsSKehlfVBvCDIHp=requests.get(LXjMaPWOkJbuNynsSKehlfVBvCDIcA,params=params,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIHm,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   LXjMaPWOkJbuNynsSKehlfVBvCDIHp=requests.put(LXjMaPWOkJbuNynsSKehlfVBvCDIcA,data=payload,params=params,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIHm,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Delete':
   LXjMaPWOkJbuNynsSKehlfVBvCDIHp=requests.delete(LXjMaPWOkJbuNynsSKehlfVBvCDIcA,params=params,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIHm,cookies=cookies,allow_redirects=redirects)
  else:
   LXjMaPWOkJbuNynsSKehlfVBvCDIHp=requests.post(LXjMaPWOkJbuNynsSKehlfVBvCDIcA,data=payload,params=params,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIHm,cookies=cookies,allow_redirects=redirects)
  return LXjMaPWOkJbuNynsSKehlfVBvCDIHp
 def JsonFile_Save(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,filename,LXjMaPWOkJbuNynsSKehlfVBvCDIHw):
  if filename=='':return LXjMaPWOkJbuNynsSKehlfVBvCDIFT
  try:
   fp=LXjMaPWOkJbuNynsSKehlfVBvCDIFx(filename,'w',-1,'utf-8')
   json.dump(LXjMaPWOkJbuNynsSKehlfVBvCDIHw,fp,indent=4,ensure_ascii=LXjMaPWOkJbuNynsSKehlfVBvCDIFT)
   fp.close()
  except:
   return LXjMaPWOkJbuNynsSKehlfVBvCDIFT
  return LXjMaPWOkJbuNynsSKehlfVBvCDIFU
 def JsonFile_Load(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,filename):
  if filename=='':return{}
  try:
   fp=LXjMaPWOkJbuNynsSKehlfVBvCDIFx(filename,'r',-1,'utf-8')
   LXjMaPWOkJbuNynsSKehlfVBvCDIHt=json.load(fp)
   fp.close()
  except:
   return{}
  return LXjMaPWOkJbuNynsSKehlfVBvCDIHt
 def Save_session_acount(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,LXjMaPWOkJbuNynsSKehlfVBvCDIHi,LXjMaPWOkJbuNynsSKehlfVBvCDIHR,LXjMaPWOkJbuNynsSKehlfVBvCDIHz):
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['account']['wcid']=base64.standard_b64encode(LXjMaPWOkJbuNynsSKehlfVBvCDIHi.encode()).decode('utf-8')
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['account']['wcpw']=base64.standard_b64encode(LXjMaPWOkJbuNynsSKehlfVBvCDIHR.encode()).decode('utf-8')
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['account']['wcpf']=LXjMaPWOkJbuNynsSKehlfVBvCDIHz 
 def Load_session_acount(LXjMaPWOkJbuNynsSKehlfVBvCDIHd):
  try:
   LXjMaPWOkJbuNynsSKehlfVBvCDIHi=base64.standard_b64decode(LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['account']['wcid']).decode('utf-8')
   LXjMaPWOkJbuNynsSKehlfVBvCDIHR=base64.standard_b64decode(LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['account']['wcpw']).decode('utf-8')
   LXjMaPWOkJbuNynsSKehlfVBvCDIHz=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['account']['wcpf']
  except:
   return '','',0
  return LXjMaPWOkJbuNynsSKehlfVBvCDIHi,LXjMaPWOkJbuNynsSKehlfVBvCDIHR,LXjMaPWOkJbuNynsSKehlfVBvCDIHz
 def Get_DeviceID(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,LXjMaPWOkJbuNynsSKehlfVBvCDIFQ,pf):
  import hashlib
  m1=hashlib.md5()
  m2=hashlib.md5()
  LXjMaPWOkJbuNynsSKehlfVBvCDIHY=LXjMaPWOkJbuNynsSKehlfVBvCDIFQ+LXjMaPWOkJbuNynsSKehlfVBvCDIoH(pf)
  LXjMaPWOkJbuNynsSKehlfVBvCDIHT=LXjMaPWOkJbuNynsSKehlfVBvCDIoH(pf)+LXjMaPWOkJbuNynsSKehlfVBvCDIFQ
  m1.update(LXjMaPWOkJbuNynsSKehlfVBvCDIHY.encode('utf-8'))
  m2.update(LXjMaPWOkJbuNynsSKehlfVBvCDIHT.encode('utf-8'))
  LXjMaPWOkJbuNynsSKehlfVBvCDIHx=LXjMaPWOkJbuNynsSKehlfVBvCDIoH(m1.hexdigest())
  LXjMaPWOkJbuNynsSKehlfVBvCDIHU=LXjMaPWOkJbuNynsSKehlfVBvCDIoH(m2.hexdigest())
  LXjMaPWOkJbuNynsSKehlfVBvCDIHQ=LXjMaPWOkJbuNynsSKehlfVBvCDIHx[:16]
  LXjMaPWOkJbuNynsSKehlfVBvCDIcH='%s-%s-%s-%s-%s'%(LXjMaPWOkJbuNynsSKehlfVBvCDIHU[:8],LXjMaPWOkJbuNynsSKehlfVBvCDIHU[8:12],LXjMaPWOkJbuNynsSKehlfVBvCDIHU[12:16],LXjMaPWOkJbuNynsSKehlfVBvCDIHU[16:20],LXjMaPWOkJbuNynsSKehlfVBvCDIHU[20:])
  return LXjMaPWOkJbuNynsSKehlfVBvCDIHQ,LXjMaPWOkJbuNynsSKehlfVBvCDIcH
 def make_Random_Intstr(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,size):
  LXjMaPWOkJbuNynsSKehlfVBvCDIcd=string.digits 
  LXjMaPWOkJbuNynsSKehlfVBvCDIcG=''
  for i in LXjMaPWOkJbuNynsSKehlfVBvCDIoc(size):
   LXjMaPWOkJbuNynsSKehlfVBvCDIcG+=random.choice(LXjMaPWOkJbuNynsSKehlfVBvCDIcd)
  return LXjMaPWOkJbuNynsSKehlfVBvCDIcG
 def makeDefaultCookies(LXjMaPWOkJbuNynsSKehlfVBvCDIHd):
  LXjMaPWOkJbuNynsSKehlfVBvCDIcF={'_s_guit':LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_guit'],'_guinness-premium_session':LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_token']}
  if LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_guitv']:
   LXjMaPWOkJbuNynsSKehlfVBvCDIcF['_s_guitv']=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_guitv']
  return LXjMaPWOkJbuNynsSKehlfVBvCDIcF
 def GetCredential(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,user_id,user_pw,user_pf):
  try:
   LXjMaPWOkJbuNynsSKehlfVBvCDIco=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+'/api/session'
   LXjMaPWOkJbuNynsSKehlfVBvCDIcg={'email':user_id,'password':user_pw}
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcE={'accept':'application/vnd.frograms+json;version=4'}
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr.update(LXjMaPWOkJbuNynsSKehlfVBvCDIcE)
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Post',LXjMaPWOkJbuNynsSKehlfVBvCDIco,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIcg,params=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIFY)
   for LXjMaPWOkJbuNynsSKehlfVBvCDIcm in LXjMaPWOkJbuNynsSKehlfVBvCDIcq.cookies:
    if LXjMaPWOkJbuNynsSKehlfVBvCDIcm.name=='_ale_session':
     LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_token']=LXjMaPWOkJbuNynsSKehlfVBvCDIcm.value
    elif LXjMaPWOkJbuNynsSKehlfVBvCDIcm.name=='_s_guit':
     LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_guit']=LXjMaPWOkJbuNynsSKehlfVBvCDIcm.value
   if LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_token']=='':
    LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Init_WC_Total()
    return LXjMaPWOkJbuNynsSKehlfVBvCDIFT
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
   LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Init_WC_Total()
   return LXjMaPWOkJbuNynsSKehlfVBvCDIFT
  if LXjMaPWOkJbuNynsSKehlfVBvCDIHd.GetProfilesList(user_pf)==LXjMaPWOkJbuNynsSKehlfVBvCDIFT:
   LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Init_WC_Total()
   return LXjMaPWOkJbuNynsSKehlfVBvCDIFT
  if user_pf!=0:
   if LXjMaPWOkJbuNynsSKehlfVBvCDIHd.GetProfilesConvert()==LXjMaPWOkJbuNynsSKehlfVBvCDIFT:
    LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Init_WC_Total()
    return LXjMaPWOkJbuNynsSKehlfVBvCDIFT
  (LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['deviceId1'],LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['deviceId2'])=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_DeviceID(user_id,user_pf)
  LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['flyerId']=LXjMaPWOkJbuNynsSKehlfVBvCDIoH(LXjMaPWOkJbuNynsSKehlfVBvCDIoF(time.time()*1000))+'-'+LXjMaPWOkJbuNynsSKehlfVBvCDIHd.make_Random_Intstr(19)
  return LXjMaPWOkJbuNynsSKehlfVBvCDIFU
 def GetProfilesList(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,user_pf):
  LXjMaPWOkJbuNynsSKehlfVBvCDIcp=[]
  try:
   LXjMaPWOkJbuNynsSKehlfVBvCDIcw ='/manage_profiles'
   LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.MAIN_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcm=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.makeDefaultCookies()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Get',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIcm,redirects=LXjMaPWOkJbuNynsSKehlfVBvCDIFU)
   LXjMaPWOkJbuNynsSKehlfVBvCDIct=LXjMaPWOkJbuNynsSKehlfVBvCDIcq.text
   LXjMaPWOkJbuNynsSKehlfVBvCDIci =re.findall('/api/users/me.{8000}',LXjMaPWOkJbuNynsSKehlfVBvCDIct)[0]
   LXjMaPWOkJbuNynsSKehlfVBvCDIci =LXjMaPWOkJbuNynsSKehlfVBvCDIci.replace('&quot;','')
   LXjMaPWOkJbuNynsSKehlfVBvCDIcp=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',LXjMaPWOkJbuNynsSKehlfVBvCDIci)
   for i in LXjMaPWOkJbuNynsSKehlfVBvCDIoc(LXjMaPWOkJbuNynsSKehlfVBvCDIog(LXjMaPWOkJbuNynsSKehlfVBvCDIcp)):
    LXjMaPWOkJbuNynsSKehlfVBvCDIcR=LXjMaPWOkJbuNynsSKehlfVBvCDIcp[i]
    LXjMaPWOkJbuNynsSKehlfVBvCDIcR =LXjMaPWOkJbuNynsSKehlfVBvCDIcR.split(':')[1]
    LXjMaPWOkJbuNynsSKehlfVBvCDIcp[i]=LXjMaPWOkJbuNynsSKehlfVBvCDIcR.split(',')[0]
   LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_usercd']=LXjMaPWOkJbuNynsSKehlfVBvCDIcp[user_pf]
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
   LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Init_WC_Total()
   return LXjMaPWOkJbuNynsSKehlfVBvCDIFT
  return LXjMaPWOkJbuNynsSKehlfVBvCDIFU
 def GetProfilesConvert(LXjMaPWOkJbuNynsSKehlfVBvCDIHd):
  try:
   LXjMaPWOkJbuNynsSKehlfVBvCDIcw ='/api/users/'+LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_usercd']+'/convert'
   LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcm =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.makeDefaultCookies()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Put',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIcm)
   for LXjMaPWOkJbuNynsSKehlfVBvCDIcm in LXjMaPWOkJbuNynsSKehlfVBvCDIcq.cookies:
    if LXjMaPWOkJbuNynsSKehlfVBvCDIcm.name=='_s_guitv':
     LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_guitv']=LXjMaPWOkJbuNynsSKehlfVBvCDIcm.value
    elif LXjMaPWOkJbuNynsSKehlfVBvCDIcm.name=='_guinness-premium_session':
     LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_token']=LXjMaPWOkJbuNynsSKehlfVBvCDIcm.value
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
   LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Init_WC_Total()
   return LXjMaPWOkJbuNynsSKehlfVBvCDIFT
  return LXjMaPWOkJbuNynsSKehlfVBvCDIFU
 def GetSubGroupList(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,stype):
  LXjMaPWOkJbuNynsSKehlfVBvCDIcz=[]
  try:
   LXjMaPWOkJbuNynsSKehlfVBvCDIcw ='/api/categories.json'
   LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcm =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.makeDefaultCookies()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Get',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIcm)
   LXjMaPWOkJbuNynsSKehlfVBvCDIcY=json.loads(LXjMaPWOkJbuNynsSKehlfVBvCDIcq.text)
   if not('genres' in LXjMaPWOkJbuNynsSKehlfVBvCDIcY):return LXjMaPWOkJbuNynsSKehlfVBvCDIcz
   if stype=='genres':
    LXjMaPWOkJbuNynsSKehlfVBvCDIcT=LXjMaPWOkJbuNynsSKehlfVBvCDIcY['genres']
   else:
    LXjMaPWOkJbuNynsSKehlfVBvCDIcT=LXjMaPWOkJbuNynsSKehlfVBvCDIcY['tags']
   for LXjMaPWOkJbuNynsSKehlfVBvCDIcx in LXjMaPWOkJbuNynsSKehlfVBvCDIcT:
    LXjMaPWOkJbuNynsSKehlfVBvCDIcU=LXjMaPWOkJbuNynsSKehlfVBvCDIcx['name']
    LXjMaPWOkJbuNynsSKehlfVBvCDIcQ =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['api_path']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdH =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['entity']['id']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdc={'group_name':LXjMaPWOkJbuNynsSKehlfVBvCDIcU,'api_path':LXjMaPWOkJbuNynsSKehlfVBvCDIcQ,'tag_id':LXjMaPWOkJbuNynsSKehlfVBvCDIoH(LXjMaPWOkJbuNynsSKehlfVBvCDIdH)}
    LXjMaPWOkJbuNynsSKehlfVBvCDIcz.append(LXjMaPWOkJbuNynsSKehlfVBvCDIdc)
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
  return LXjMaPWOkJbuNynsSKehlfVBvCDIcz
 def GetCategoryList(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,stype,LXjMaPWOkJbuNynsSKehlfVBvCDIdH,LXjMaPWOkJbuNynsSKehlfVBvCDIcQ,page_int):
  LXjMaPWOkJbuNynsSKehlfVBvCDIcz=[]
  LXjMaPWOkJbuNynsSKehlfVBvCDIdG=LXjMaPWOkJbuNynsSKehlfVBvCDIFT
  LXjMaPWOkJbuNynsSKehlfVBvCDIdF={}
  try:
   if 'categories' in LXjMaPWOkJbuNynsSKehlfVBvCDIcQ:
    LXjMaPWOkJbuNynsSKehlfVBvCDIcw ='/api/tags'
    LXjMaPWOkJbuNynsSKehlfVBvCDIdF['ids']=LXjMaPWOkJbuNynsSKehlfVBvCDIdH
   else: 
    LXjMaPWOkJbuNynsSKehlfVBvCDIcw ='/api/'+LXjMaPWOkJbuNynsSKehlfVBvCDIcQ+'.json'
    if page_int>1:
     LXjMaPWOkJbuNynsSKehlfVBvCDIdF['page']=LXjMaPWOkJbuNynsSKehlfVBvCDIoH(page_int)
   LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcm =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.makeDefaultCookies()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Get',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIdF,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIcm)
   LXjMaPWOkJbuNynsSKehlfVBvCDIcY=json.loads(LXjMaPWOkJbuNynsSKehlfVBvCDIcq.text)
   if not('contents' in LXjMaPWOkJbuNynsSKehlfVBvCDIcY):return LXjMaPWOkJbuNynsSKehlfVBvCDIcz,LXjMaPWOkJbuNynsSKehlfVBvCDIdG
   LXjMaPWOkJbuNynsSKehlfVBvCDIcT=LXjMaPWOkJbuNynsSKehlfVBvCDIcY['contents']
   LXjMaPWOkJbuNynsSKehlfVBvCDIdG=LXjMaPWOkJbuNynsSKehlfVBvCDIcY['meta']['has_next']
   for LXjMaPWOkJbuNynsSKehlfVBvCDIcx in LXjMaPWOkJbuNynsSKehlfVBvCDIcT:
    LXjMaPWOkJbuNynsSKehlfVBvCDIdo =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['code']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdg=LXjMaPWOkJbuNynsSKehlfVBvCDIcx['content_type']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdr =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['title']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdE =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['story']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdq =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['badge_text']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdm=LXjMaPWOkJbuNynsSKehlfVBvCDIFR=LXjMaPWOkJbuNynsSKehlfVBvCDIFi=''
    if LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('poster') !=LXjMaPWOkJbuNynsSKehlfVBvCDIFY:LXjMaPWOkJbuNynsSKehlfVBvCDIdm=LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('poster').get('original')
    if LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('stillcut')!=LXjMaPWOkJbuNynsSKehlfVBvCDIFY:LXjMaPWOkJbuNynsSKehlfVBvCDIFR =LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('stillcut').get('large')
    if LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('thumbnail')!=LXjMaPWOkJbuNynsSKehlfVBvCDIFY:LXjMaPWOkJbuNynsSKehlfVBvCDIFi=LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('thumbnail').get('large')
    if LXjMaPWOkJbuNynsSKehlfVBvCDIFi=='' :LXjMaPWOkJbuNynsSKehlfVBvCDIFi=LXjMaPWOkJbuNynsSKehlfVBvCDIFR
    LXjMaPWOkJbuNynsSKehlfVBvCDIdp={'thumb':LXjMaPWOkJbuNynsSKehlfVBvCDIFR,'poster':LXjMaPWOkJbuNynsSKehlfVBvCDIdm,'fanart':LXjMaPWOkJbuNynsSKehlfVBvCDIFi}
    LXjMaPWOkJbuNynsSKehlfVBvCDIdw =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['year']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdA =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['film_rating_code']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdt=LXjMaPWOkJbuNynsSKehlfVBvCDIcx['film_rating_short']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdi =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['film_rating_long']
    if LXjMaPWOkJbuNynsSKehlfVBvCDIdg=='movies':
     LXjMaPWOkJbuNynsSKehlfVBvCDIdR =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['duration']
    else:
     LXjMaPWOkJbuNynsSKehlfVBvCDIdR ='0'
    LXjMaPWOkJbuNynsSKehlfVBvCDIdc={'code':LXjMaPWOkJbuNynsSKehlfVBvCDIdo,'content_type':LXjMaPWOkJbuNynsSKehlfVBvCDIdg,'title':LXjMaPWOkJbuNynsSKehlfVBvCDIdr,'story':LXjMaPWOkJbuNynsSKehlfVBvCDIdE,'thumbnail':LXjMaPWOkJbuNynsSKehlfVBvCDIdp,'year':LXjMaPWOkJbuNynsSKehlfVBvCDIdw,'film_rating_code':LXjMaPWOkJbuNynsSKehlfVBvCDIdA,'film_rating_short':LXjMaPWOkJbuNynsSKehlfVBvCDIdt,'film_rating_long':LXjMaPWOkJbuNynsSKehlfVBvCDIdi,'duration':LXjMaPWOkJbuNynsSKehlfVBvCDIdR,'badge':LXjMaPWOkJbuNynsSKehlfVBvCDIdq,}
    LXjMaPWOkJbuNynsSKehlfVBvCDIcz.append(LXjMaPWOkJbuNynsSKehlfVBvCDIdc)
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
  return LXjMaPWOkJbuNynsSKehlfVBvCDIcz,LXjMaPWOkJbuNynsSKehlfVBvCDIdG
 def GetProgramInfo(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,program_code):
  LXjMaPWOkJbuNynsSKehlfVBvCDIdz={}
  try:
   LXjMaPWOkJbuNynsSKehlfVBvCDIcw ='/api/contents/'+program_code
   LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Get',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIFY)
   LXjMaPWOkJbuNynsSKehlfVBvCDIcY=json.loads(LXjMaPWOkJbuNynsSKehlfVBvCDIcq.text)
   LXjMaPWOkJbuNynsSKehlfVBvCDIdY=img_clearlogo=''
   LXjMaPWOkJbuNynsSKehlfVBvCDIdY=LXjMaPWOkJbuNynsSKehlfVBvCDIcY.get('poster').get('original')
   if LXjMaPWOkJbuNynsSKehlfVBvCDIog(LXjMaPWOkJbuNynsSKehlfVBvCDIcY.get('title_logos'))>0:img_clearlogo=LXjMaPWOkJbuNynsSKehlfVBvCDIcY.get('title_logos')[0].get('src')
   LXjMaPWOkJbuNynsSKehlfVBvCDIdz={'imgPoster':LXjMaPWOkJbuNynsSKehlfVBvCDIdY,'imgClearlogo':img_clearlogo}
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
  return LXjMaPWOkJbuNynsSKehlfVBvCDIdz
 def GetSeasonList(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,program_code):
  LXjMaPWOkJbuNynsSKehlfVBvCDIdT=[]
  try:
   LXjMaPWOkJbuNynsSKehlfVBvCDIcw ='/api/aio_contents/'+program_code
   LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Get',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIFY)
   LXjMaPWOkJbuNynsSKehlfVBvCDIcY=json.loads(LXjMaPWOkJbuNynsSKehlfVBvCDIcq.text)
   if not('result' in LXjMaPWOkJbuNynsSKehlfVBvCDIcY):return LXjMaPWOkJbuNynsSKehlfVBvCDIdT
   for LXjMaPWOkJbuNynsSKehlfVBvCDIcx in LXjMaPWOkJbuNynsSKehlfVBvCDIcY.get('result').get('seasons'):
    LXjMaPWOkJbuNynsSKehlfVBvCDIdx =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['id']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdU =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['titles']['short']or LXjMaPWOkJbuNynsSKehlfVBvCDIcx['titles']['original']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdc={'seasonId':LXjMaPWOkJbuNynsSKehlfVBvCDIdx,'seasonNm':LXjMaPWOkJbuNynsSKehlfVBvCDIdU,}
    LXjMaPWOkJbuNynsSKehlfVBvCDIdT.append(LXjMaPWOkJbuNynsSKehlfVBvCDIdc)
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
  return LXjMaPWOkJbuNynsSKehlfVBvCDIdT
 def GetEpisodoList(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,program_code,page_int,orderby='asc'):
  LXjMaPWOkJbuNynsSKehlfVBvCDIcz=[]
  LXjMaPWOkJbuNynsSKehlfVBvCDIdG=LXjMaPWOkJbuNynsSKehlfVBvCDIFT
  LXjMaPWOkJbuNynsSKehlfVBvCDIdQ=''
  try:
   LXjMaPWOkJbuNynsSKehlfVBvCDIcw ='/api/contents/'+program_code+'/tv_episodes.json'
   LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
   LXjMaPWOkJbuNynsSKehlfVBvCDIdF={'all':'true'}
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Get',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIdF,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIFY)
   LXjMaPWOkJbuNynsSKehlfVBvCDIcY=json.loads(LXjMaPWOkJbuNynsSKehlfVBvCDIcq.text)
   if not('tv_episode_codes' in LXjMaPWOkJbuNynsSKehlfVBvCDIcY):return LXjMaPWOkJbuNynsSKehlfVBvCDIcz,LXjMaPWOkJbuNynsSKehlfVBvCDIdG
   LXjMaPWOkJbuNynsSKehlfVBvCDIcT=LXjMaPWOkJbuNynsSKehlfVBvCDIcY['tv_episode_codes']
   LXjMaPWOkJbuNynsSKehlfVBvCDIGH=LXjMaPWOkJbuNynsSKehlfVBvCDIog(LXjMaPWOkJbuNynsSKehlfVBvCDIcT)
   LXjMaPWOkJbuNynsSKehlfVBvCDIGc =LXjMaPWOkJbuNynsSKehlfVBvCDIoF(LXjMaPWOkJbuNynsSKehlfVBvCDIGH//(LXjMaPWOkJbuNynsSKehlfVBvCDIHd.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    LXjMaPWOkJbuNynsSKehlfVBvCDIGd =(LXjMaPWOkJbuNynsSKehlfVBvCDIGH-1)-((page_int-1)*LXjMaPWOkJbuNynsSKehlfVBvCDIHd.EPISODE_LIMIT)
   else:
    LXjMaPWOkJbuNynsSKehlfVBvCDIGd =(page_int-1)*LXjMaPWOkJbuNynsSKehlfVBvCDIHd.EPISODE_LIMIT
   for i in LXjMaPWOkJbuNynsSKehlfVBvCDIoc(LXjMaPWOkJbuNynsSKehlfVBvCDIHd.EPISODE_LIMIT):
    if orderby=='desc':
     LXjMaPWOkJbuNynsSKehlfVBvCDIGF=LXjMaPWOkJbuNynsSKehlfVBvCDIGd-i
     if LXjMaPWOkJbuNynsSKehlfVBvCDIGF<0:break
    else:
     LXjMaPWOkJbuNynsSKehlfVBvCDIGF=LXjMaPWOkJbuNynsSKehlfVBvCDIGd+i
     if LXjMaPWOkJbuNynsSKehlfVBvCDIGF>=LXjMaPWOkJbuNynsSKehlfVBvCDIGH:break
    if LXjMaPWOkJbuNynsSKehlfVBvCDIdQ!='':LXjMaPWOkJbuNynsSKehlfVBvCDIdQ+=','
    LXjMaPWOkJbuNynsSKehlfVBvCDIdQ+=LXjMaPWOkJbuNynsSKehlfVBvCDIcT[LXjMaPWOkJbuNynsSKehlfVBvCDIGF]
   if LXjMaPWOkJbuNynsSKehlfVBvCDIGc>page_int:LXjMaPWOkJbuNynsSKehlfVBvCDIdG=LXjMaPWOkJbuNynsSKehlfVBvCDIFU
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
  LXjMaPWOkJbuNynsSKehlfVBvCDIGo=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.GetProgramInfo(program_code)
  try:
   LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
   LXjMaPWOkJbuNynsSKehlfVBvCDIdF={'codes':LXjMaPWOkJbuNynsSKehlfVBvCDIdQ}
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Get',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIdF,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIFY)
   LXjMaPWOkJbuNynsSKehlfVBvCDIcY=json.loads(LXjMaPWOkJbuNynsSKehlfVBvCDIcq.text)
   if not('tv_episodes' in LXjMaPWOkJbuNynsSKehlfVBvCDIcY):return LXjMaPWOkJbuNynsSKehlfVBvCDIcz
   LXjMaPWOkJbuNynsSKehlfVBvCDIcT=LXjMaPWOkJbuNynsSKehlfVBvCDIcY['tv_episodes']
   for LXjMaPWOkJbuNynsSKehlfVBvCDIcx in LXjMaPWOkJbuNynsSKehlfVBvCDIcT:
    LXjMaPWOkJbuNynsSKehlfVBvCDIdo =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['code']
    if LXjMaPWOkJbuNynsSKehlfVBvCDIcx['title']:
     LXjMaPWOkJbuNynsSKehlfVBvCDIdr =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['title']
    else:
     LXjMaPWOkJbuNynsSKehlfVBvCDIdr =''
    LXjMaPWOkJbuNynsSKehlfVBvCDIdm=LXjMaPWOkJbuNynsSKehlfVBvCDIFR=LXjMaPWOkJbuNynsSKehlfVBvCDIFi=LXjMaPWOkJbuNynsSKehlfVBvCDIGg=''
    LXjMaPWOkJbuNynsSKehlfVBvCDIdm =LXjMaPWOkJbuNynsSKehlfVBvCDIGo.get('imgPoster')
    LXjMaPWOkJbuNynsSKehlfVBvCDIGg=LXjMaPWOkJbuNynsSKehlfVBvCDIGo.get('imgClearlogo')
    if LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('stillcut') !=LXjMaPWOkJbuNynsSKehlfVBvCDIFY:LXjMaPWOkJbuNynsSKehlfVBvCDIFR =LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('stillcut').get('large')
    if LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('tv_season_stillcut')!=LXjMaPWOkJbuNynsSKehlfVBvCDIFY:LXjMaPWOkJbuNynsSKehlfVBvCDIFi=LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('tv_season_stillcut').get('large')
    LXjMaPWOkJbuNynsSKehlfVBvCDIdp={'thumb':LXjMaPWOkJbuNynsSKehlfVBvCDIFR,'poster':LXjMaPWOkJbuNynsSKehlfVBvCDIdm,'fanart':LXjMaPWOkJbuNynsSKehlfVBvCDIFi,'clearlogo':LXjMaPWOkJbuNynsSKehlfVBvCDIGg}
    LXjMaPWOkJbuNynsSKehlfVBvCDIGr =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['display_number']
    LXjMaPWOkJbuNynsSKehlfVBvCDIGE=LXjMaPWOkJbuNynsSKehlfVBvCDIcx['tv_season_title']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdR =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['duration']
    try:
     LXjMaPWOkJbuNynsSKehlfVBvCDIGq=LXjMaPWOkJbuNynsSKehlfVBvCDIcx['episode_number']
    except:
     LXjMaPWOkJbuNynsSKehlfVBvCDIGq='0'
    LXjMaPWOkJbuNynsSKehlfVBvCDIdc={'code':LXjMaPWOkJbuNynsSKehlfVBvCDIdo,'title':LXjMaPWOkJbuNynsSKehlfVBvCDIdr,'thumbnail':LXjMaPWOkJbuNynsSKehlfVBvCDIdp,'display_num':LXjMaPWOkJbuNynsSKehlfVBvCDIGr,'season_title':LXjMaPWOkJbuNynsSKehlfVBvCDIGE,'duration':LXjMaPWOkJbuNynsSKehlfVBvCDIdR,'episode_number':LXjMaPWOkJbuNynsSKehlfVBvCDIGq}
    LXjMaPWOkJbuNynsSKehlfVBvCDIcz.append(LXjMaPWOkJbuNynsSKehlfVBvCDIdc)
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
  return LXjMaPWOkJbuNynsSKehlfVBvCDIcz,LXjMaPWOkJbuNynsSKehlfVBvCDIdG
 def GetHomeList(LXjMaPWOkJbuNynsSKehlfVBvCDIHd):
  LXjMaPWOkJbuNynsSKehlfVBvCDIGm=[]
  try:
   LXjMaPWOkJbuNynsSKehlfVBvCDIcw ='/api/aio_browses/video/header'
   LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcF=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.makeDefaultCookies()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Get',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIcF)
   LXjMaPWOkJbuNynsSKehlfVBvCDIGp=json.loads(LXjMaPWOkJbuNynsSKehlfVBvCDIcq.text)
   if not('result' in LXjMaPWOkJbuNynsSKehlfVBvCDIGp):return LXjMaPWOkJbuNynsSKehlfVBvCDIGm
   LXjMaPWOkJbuNynsSKehlfVBvCDIcT=LXjMaPWOkJbuNynsSKehlfVBvCDIGp['result'][0]['cells']
   for LXjMaPWOkJbuNynsSKehlfVBvCDIcx in LXjMaPWOkJbuNynsSKehlfVBvCDIcT:
    LXjMaPWOkJbuNynsSKehlfVBvCDIdg=LXjMaPWOkJbuNynsSKehlfVBvCDIcx['relations'][0]['type']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdr =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['title']
    LXjMaPWOkJbuNynsSKehlfVBvCDIGw =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['badge']
    LXjMaPWOkJbuNynsSKehlfVBvCDIGA =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['media']['fullhd']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdp ={'thumb':LXjMaPWOkJbuNynsSKehlfVBvCDIGA,'fanart':LXjMaPWOkJbuNynsSKehlfVBvCDIGA}
    LXjMaPWOkJbuNynsSKehlfVBvCDIdo =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['relations'][0]['id']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdc={'code':LXjMaPWOkJbuNynsSKehlfVBvCDIdo,'content_type':LXjMaPWOkJbuNynsSKehlfVBvCDIdg,'title':LXjMaPWOkJbuNynsSKehlfVBvCDIdr,'bedge':LXjMaPWOkJbuNynsSKehlfVBvCDIGw,'thumbnail':LXjMaPWOkJbuNynsSKehlfVBvCDIdp}
    LXjMaPWOkJbuNynsSKehlfVBvCDIGm.append(LXjMaPWOkJbuNynsSKehlfVBvCDIdc)
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
  return LXjMaPWOkJbuNynsSKehlfVBvCDIGm
 def GetSearchList(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,search_key,page_int):
  LXjMaPWOkJbuNynsSKehlfVBvCDIGt=[]
  LXjMaPWOkJbuNynsSKehlfVBvCDIdG=LXjMaPWOkJbuNynsSKehlfVBvCDIFT
  try:
   LXjMaPWOkJbuNynsSKehlfVBvCDIcw ='/api/search.json'
   LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
   LXjMaPWOkJbuNynsSKehlfVBvCDIdF={'query':search_key,'page':LXjMaPWOkJbuNynsSKehlfVBvCDIoH(page_int),'per':LXjMaPWOkJbuNynsSKehlfVBvCDIoH(LXjMaPWOkJbuNynsSKehlfVBvCDIHd.SEARCH_LIMIT),'exclude':'limited'}
   LXjMaPWOkJbuNynsSKehlfVBvCDIcr=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Get',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIdF,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIFY)
   LXjMaPWOkJbuNynsSKehlfVBvCDIcY=json.loads(LXjMaPWOkJbuNynsSKehlfVBvCDIcq.text)
   if not('results' in LXjMaPWOkJbuNynsSKehlfVBvCDIcY):return LXjMaPWOkJbuNynsSKehlfVBvCDIGt,LXjMaPWOkJbuNynsSKehlfVBvCDIdG
   LXjMaPWOkJbuNynsSKehlfVBvCDIcT=LXjMaPWOkJbuNynsSKehlfVBvCDIcY['results']
   LXjMaPWOkJbuNynsSKehlfVBvCDIdG=LXjMaPWOkJbuNynsSKehlfVBvCDIcY['meta']['has_next']
   for LXjMaPWOkJbuNynsSKehlfVBvCDIcx in LXjMaPWOkJbuNynsSKehlfVBvCDIcT:
    LXjMaPWOkJbuNynsSKehlfVBvCDIdo =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['code']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdg=LXjMaPWOkJbuNynsSKehlfVBvCDIcx['content_type']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdr =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['title']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdE =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['story']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdm=LXjMaPWOkJbuNynsSKehlfVBvCDIFR=LXjMaPWOkJbuNynsSKehlfVBvCDIFi=''
    if LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('poster') !=LXjMaPWOkJbuNynsSKehlfVBvCDIFY:LXjMaPWOkJbuNynsSKehlfVBvCDIdm=LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('poster').get('original')
    if LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('stillcut')!=LXjMaPWOkJbuNynsSKehlfVBvCDIFY:LXjMaPWOkJbuNynsSKehlfVBvCDIFR =LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('stillcut').get('large')
    if LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('thumbnail')!=LXjMaPWOkJbuNynsSKehlfVBvCDIFY:LXjMaPWOkJbuNynsSKehlfVBvCDIFi=LXjMaPWOkJbuNynsSKehlfVBvCDIcx.get('thumbnail').get('large')
    if LXjMaPWOkJbuNynsSKehlfVBvCDIFi=='' :LXjMaPWOkJbuNynsSKehlfVBvCDIFi=LXjMaPWOkJbuNynsSKehlfVBvCDIFR
    LXjMaPWOkJbuNynsSKehlfVBvCDIdp={'thumb':LXjMaPWOkJbuNynsSKehlfVBvCDIFR,'poster':LXjMaPWOkJbuNynsSKehlfVBvCDIdm,'fanart':LXjMaPWOkJbuNynsSKehlfVBvCDIFi}
    LXjMaPWOkJbuNynsSKehlfVBvCDIdw =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['year']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdA =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['film_rating_code']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdt=LXjMaPWOkJbuNynsSKehlfVBvCDIcx['film_rating_short']
    LXjMaPWOkJbuNynsSKehlfVBvCDIdi =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['film_rating_long']
    if LXjMaPWOkJbuNynsSKehlfVBvCDIdg=='movies':
     LXjMaPWOkJbuNynsSKehlfVBvCDIdR =LXjMaPWOkJbuNynsSKehlfVBvCDIcx['duration']
    else:
     LXjMaPWOkJbuNynsSKehlfVBvCDIdR ='0'
    LXjMaPWOkJbuNynsSKehlfVBvCDIdc={'code':LXjMaPWOkJbuNynsSKehlfVBvCDIdo,'content_type':LXjMaPWOkJbuNynsSKehlfVBvCDIdg,'title':LXjMaPWOkJbuNynsSKehlfVBvCDIdr,'story':LXjMaPWOkJbuNynsSKehlfVBvCDIdE,'thumbnail':LXjMaPWOkJbuNynsSKehlfVBvCDIdp,'year':LXjMaPWOkJbuNynsSKehlfVBvCDIdw,'film_rating_code':LXjMaPWOkJbuNynsSKehlfVBvCDIdA,'film_rating_short':LXjMaPWOkJbuNynsSKehlfVBvCDIdt,'film_rating_long':LXjMaPWOkJbuNynsSKehlfVBvCDIdi,'duration':LXjMaPWOkJbuNynsSKehlfVBvCDIdR}
    LXjMaPWOkJbuNynsSKehlfVBvCDIGt.append(LXjMaPWOkJbuNynsSKehlfVBvCDIdc)
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
  return LXjMaPWOkJbuNynsSKehlfVBvCDIGt,LXjMaPWOkJbuNynsSKehlfVBvCDIdG
 def DeleteContinueList(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,codeList):
  try:
   for LXjMaPWOkJbuNynsSKehlfVBvCDIGi in codeList:
    LXjMaPWOkJbuNynsSKehlfVBvCDIcw ='/api/watches/'+LXjMaPWOkJbuNynsSKehlfVBvCDIGi
    LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
    LXjMaPWOkJbuNynsSKehlfVBvCDIcr =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
    LXjMaPWOkJbuNynsSKehlfVBvCDIcm =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.makeDefaultCookies()
    LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Delete',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,params=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIcm)
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   LXjMaPWOkJbuNynsSKehlfVBvCDIoG(exception)
 def Get_Now_Datetime(LXjMaPWOkJbuNynsSKehlfVBvCDIHd):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,movie_code,quality_str,proxyUse=LXjMaPWOkJbuNynsSKehlfVBvCDIFT,inScreen='BASE',inSound='2CH'):
  LXjMaPWOkJbuNynsSKehlfVBvCDIGz={'streamUrl':'','subtitleUrl':'','customdata':'',}
  try:
   if proxyUse:
    LXjMaPWOkJbuNynsSKehlfVBvCDIGY ='0' if inScreen=='BASE' and inSound=='2CH' else '3'
    LXjMaPWOkJbuNynsSKehlfVBvCDIGT='4' if inScreen=='VISION' else '1'
    LXjMaPWOkJbuNynsSKehlfVBvCDIGx ='0' if inSound!='ATMOS' else '1'
    LXjMaPWOkJbuNynsSKehlfVBvCDIoG('hCodec  = '+LXjMaPWOkJbuNynsSKehlfVBvCDIGY)
    LXjMaPWOkJbuNynsSKehlfVBvCDIoG('hScreen = '+LXjMaPWOkJbuNynsSKehlfVBvCDIGT)
    LXjMaPWOkJbuNynsSKehlfVBvCDIoG('hSound  = '+LXjMaPWOkJbuNynsSKehlfVBvCDIGx)
    LXjMaPWOkJbuNynsSKehlfVBvCDIcw='/api/watch/'+movie_code+'.json?localtracks=%5B%5D&player_v2=true'
    LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
    LXjMaPWOkJbuNynsSKehlfVBvCDIcr=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers_v2()
    LXjMaPWOkJbuNynsSKehlfVBvCDIcE={'X-FROGRAMS-MARS-CODEC-FLAG':LXjMaPWOkJbuNynsSKehlfVBvCDIGY,'X-WatchaPlay-Client-Codec-Flag':LXjMaPWOkJbuNynsSKehlfVBvCDIGY,'X-FROGRAMS-MARS-HDR-CAPABILITIES':LXjMaPWOkJbuNynsSKehlfVBvCDIGT,'X-WatchaPlay-Client-HDR-Capabilities':LXjMaPWOkJbuNynsSKehlfVBvCDIGT,'X-FROGRAMS-MARS-AUDIO-CAPABILITIES':LXjMaPWOkJbuNynsSKehlfVBvCDIGx,'X-WatchaPlay-Client-Audio-Capabilities':LXjMaPWOkJbuNynsSKehlfVBvCDIGx,}
    LXjMaPWOkJbuNynsSKehlfVBvCDIcr.update(LXjMaPWOkJbuNynsSKehlfVBvCDIcE)
   else:
    LXjMaPWOkJbuNynsSKehlfVBvCDIcw='/api/watch/'+movie_code+'.json'
    LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+LXjMaPWOkJbuNynsSKehlfVBvCDIcw
    LXjMaPWOkJbuNynsSKehlfVBvCDIcr=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
    LXjMaPWOkJbuNynsSKehlfVBvCDIcE={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str,}
    LXjMaPWOkJbuNynsSKehlfVBvCDIcr.update(LXjMaPWOkJbuNynsSKehlfVBvCDIcE)
   LXjMaPWOkJbuNynsSKehlfVBvCDIcm=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.makeDefaultCookies()
   LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Get',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIcm)
   LXjMaPWOkJbuNynsSKehlfVBvCDIcY=json.loads(LXjMaPWOkJbuNynsSKehlfVBvCDIcq.text)
   LXjMaPWOkJbuNynsSKehlfVBvCDIGz['streamUrl']=LXjMaPWOkJbuNynsSKehlfVBvCDIcY['streams'][0]['source']
   if LXjMaPWOkJbuNynsSKehlfVBvCDIGz['streamUrl']==LXjMaPWOkJbuNynsSKehlfVBvCDIFY:return LXjMaPWOkJbuNynsSKehlfVBvCDIGz
   if 'subtitles' in LXjMaPWOkJbuNynsSKehlfVBvCDIcY['streams'][0]:
    for LXjMaPWOkJbuNynsSKehlfVBvCDIGU in LXjMaPWOkJbuNynsSKehlfVBvCDIcY['streams'][0]['subtitles']:
     if LXjMaPWOkJbuNynsSKehlfVBvCDIGU['lang']=='ko':
      LXjMaPWOkJbuNynsSKehlfVBvCDIGz['subtitleUrl']=LXjMaPWOkJbuNynsSKehlfVBvCDIGU['url']
      break
   LXjMaPWOkJbuNynsSKehlfVBvCDIGQ =LXjMaPWOkJbuNynsSKehlfVBvCDIcY['ping_payload']
   LXjMaPWOkJbuNynsSKehlfVBvCDIFH =LXjMaPWOkJbuNynsSKehlfVBvCDIHd.WC['cookies']['watcha_usercd']
   LXjMaPWOkJbuNynsSKehlfVBvCDIFc={'merchant':'giitd_frograms','sessionId':LXjMaPWOkJbuNynsSKehlfVBvCDIGQ,'userId':LXjMaPWOkJbuNynsSKehlfVBvCDIFH}
   LXjMaPWOkJbuNynsSKehlfVBvCDIFd=json.dumps(LXjMaPWOkJbuNynsSKehlfVBvCDIFc,separators=(",",":")).encode('UTF-8')
   LXjMaPWOkJbuNynsSKehlfVBvCDIGz['customdata']=base64.b64encode(LXjMaPWOkJbuNynsSKehlfVBvCDIFd)
  except LXjMaPWOkJbuNynsSKehlfVBvCDIod as exception:
   return LXjMaPWOkJbuNynsSKehlfVBvCDIGz
  return LXjMaPWOkJbuNynsSKehlfVBvCDIGz
 def GetBookmarkInfo(LXjMaPWOkJbuNynsSKehlfVBvCDIHd,videoid,vidtype):
  LXjMaPWOkJbuNynsSKehlfVBvCDIFG={'indexinfo':{'ott':'watcha','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  LXjMaPWOkJbuNynsSKehlfVBvCDIcA=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.API_DOMAIN+'/api/contents/'+videoid
  LXjMaPWOkJbuNynsSKehlfVBvCDIcr=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.Get_Base_Headers()
  LXjMaPWOkJbuNynsSKehlfVBvCDIcq=LXjMaPWOkJbuNynsSKehlfVBvCDIHd.callRequestCookies('Get',LXjMaPWOkJbuNynsSKehlfVBvCDIcA,payload=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,params=LXjMaPWOkJbuNynsSKehlfVBvCDIFY,headers=LXjMaPWOkJbuNynsSKehlfVBvCDIcr,cookies=LXjMaPWOkJbuNynsSKehlfVBvCDIFY)
  LXjMaPWOkJbuNynsSKehlfVBvCDIGp=json.loads(LXjMaPWOkJbuNynsSKehlfVBvCDIcq.text)
  if not('title' in LXjMaPWOkJbuNynsSKehlfVBvCDIGp):return{}
  LXjMaPWOkJbuNynsSKehlfVBvCDIFo=LXjMaPWOkJbuNynsSKehlfVBvCDIGp
  LXjMaPWOkJbuNynsSKehlfVBvCDIoG(LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('duration'))
  LXjMaPWOkJbuNynsSKehlfVBvCDIFg=LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('title')
  LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['infoLabels']['title']=LXjMaPWOkJbuNynsSKehlfVBvCDIFg
  LXjMaPWOkJbuNynsSKehlfVBvCDIFg +=u'  (%s)'%(LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('year'))
  LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['title'] =LXjMaPWOkJbuNynsSKehlfVBvCDIFg
  LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['infoLabels']['mpaa'] =LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('film_rating_long')
  LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['infoLabels']['plot'] =LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('story').replace('<br>','\n')
  LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['infoLabels']['year'] =LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('year')
  if vidtype=='movie':
   LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['infoLabels']['duration']=LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('duration')
  LXjMaPWOkJbuNynsSKehlfVBvCDIFr=[]
  for LXjMaPWOkJbuNynsSKehlfVBvCDIFE in LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('actors'):
   LXjMaPWOkJbuNynsSKehlfVBvCDIFq =LXjMaPWOkJbuNynsSKehlfVBvCDIFE.get('name')
   LXjMaPWOkJbuNynsSKehlfVBvCDIFm='' if LXjMaPWOkJbuNynsSKehlfVBvCDIFE.get('photo')==LXjMaPWOkJbuNynsSKehlfVBvCDIFY else LXjMaPWOkJbuNynsSKehlfVBvCDIFE.get('photo').get('small')
   LXjMaPWOkJbuNynsSKehlfVBvCDIFr.append({'name':LXjMaPWOkJbuNynsSKehlfVBvCDIFq,'thumbnail':LXjMaPWOkJbuNynsSKehlfVBvCDIFm})
  if LXjMaPWOkJbuNynsSKehlfVBvCDIog(LXjMaPWOkJbuNynsSKehlfVBvCDIFr)>0:
   LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['infoLabels']['cast']=LXjMaPWOkJbuNynsSKehlfVBvCDIFr
  LXjMaPWOkJbuNynsSKehlfVBvCDIFp=[]
  for LXjMaPWOkJbuNynsSKehlfVBvCDIFw in LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('directors'):LXjMaPWOkJbuNynsSKehlfVBvCDIFp.append(LXjMaPWOkJbuNynsSKehlfVBvCDIFw.get('name'))
  if LXjMaPWOkJbuNynsSKehlfVBvCDIog(LXjMaPWOkJbuNynsSKehlfVBvCDIFp)>0:
   LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['infoLabels']['director']=LXjMaPWOkJbuNynsSKehlfVBvCDIFp
  LXjMaPWOkJbuNynsSKehlfVBvCDIFA=[]
  for LXjMaPWOkJbuNynsSKehlfVBvCDIFt in LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('genres'):LXjMaPWOkJbuNynsSKehlfVBvCDIFA.append(LXjMaPWOkJbuNynsSKehlfVBvCDIFt.get('name'))
  if LXjMaPWOkJbuNynsSKehlfVBvCDIog(LXjMaPWOkJbuNynsSKehlfVBvCDIFA)>0:
   LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['infoLabels']['genre']=LXjMaPWOkJbuNynsSKehlfVBvCDIFA
  LXjMaPWOkJbuNynsSKehlfVBvCDIdm =''
  LXjMaPWOkJbuNynsSKehlfVBvCDIFi =''
  LXjMaPWOkJbuNynsSKehlfVBvCDIFR =''
  if LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('poster') !=LXjMaPWOkJbuNynsSKehlfVBvCDIFY:LXjMaPWOkJbuNynsSKehlfVBvCDIdm =LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('poster').get('original')
  if LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('thumbnail')!=LXjMaPWOkJbuNynsSKehlfVBvCDIFY:LXjMaPWOkJbuNynsSKehlfVBvCDIFi =LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('thumbnail').get('large')
  if LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('stillcut')!=LXjMaPWOkJbuNynsSKehlfVBvCDIFY:LXjMaPWOkJbuNynsSKehlfVBvCDIFR =LXjMaPWOkJbuNynsSKehlfVBvCDIFo.get('stillcut').get('large')
  if LXjMaPWOkJbuNynsSKehlfVBvCDIFi=='':LXjMaPWOkJbuNynsSKehlfVBvCDIFi=LXjMaPWOkJbuNynsSKehlfVBvCDIFR
  LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['thumbnail']['poster']=LXjMaPWOkJbuNynsSKehlfVBvCDIdm
  LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['thumbnail']['fanart']=LXjMaPWOkJbuNynsSKehlfVBvCDIFi
  LXjMaPWOkJbuNynsSKehlfVBvCDIFG['saveinfo']['thumbnail']['thumb']=LXjMaPWOkJbuNynsSKehlfVBvCDIFR
  return LXjMaPWOkJbuNynsSKehlfVBvCDIFG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
