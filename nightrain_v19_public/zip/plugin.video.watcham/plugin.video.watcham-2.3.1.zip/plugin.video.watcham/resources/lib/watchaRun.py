__author__="NightRain"
mIQYtvkRXSAweKoxjuWBCrgMysOlFp=object
mIQYtvkRXSAweKoxjuWBCrgMysOlFJ=None
mIQYtvkRXSAweKoxjuWBCrgMysOlFE=int
mIQYtvkRXSAweKoxjuWBCrgMysOlFN=True
mIQYtvkRXSAweKoxjuWBCrgMysOlFG=False
mIQYtvkRXSAweKoxjuWBCrgMysOlFc=type
mIQYtvkRXSAweKoxjuWBCrgMysOlFa=dict
mIQYtvkRXSAweKoxjuWBCrgMysOlFL=len
mIQYtvkRXSAweKoxjuWBCrgMysOlFP=range
mIQYtvkRXSAweKoxjuWBCrgMysOlFh=str
mIQYtvkRXSAweKoxjuWBCrgMysOlFV=open
from ast import Pass
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
mIQYtvkRXSAweKoxjuWBCrgMysOlUb=[{'title':'홈','mode':'HOME_GROUP','stype':'-','api_path':'-'},{'title':'오직 왓챠에서!','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/6100'},{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410'},{'title':'4K / HDR, ATOMOS 지원작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/3025'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest'},{'title':'장르별 둘러보기','mode':'SUB_GROUP','stype':'genres','api_path':'-'},{'title':'특징별 둘러보기','mode':'SUB_GROUP','stype':'tags','api_path':'-'},{'title':'이어보기 (시청이력)','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','icon':'bookmark.png'},]
mIQYtvkRXSAweKoxjuWBCrgMysOlUd=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
mIQYtvkRXSAweKoxjuWBCrgMysOlUq=40
mIQYtvkRXSAweKoxjuWBCrgMysOlUp =30
from watchaCore import*
class mIQYtvkRXSAweKoxjuWBCrgMysOlUD(mIQYtvkRXSAweKoxjuWBCrgMysOlFp):
 def __init__(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,mIQYtvkRXSAweKoxjuWBCrgMysOlUF,mIQYtvkRXSAweKoxjuWBCrgMysOlUE,mIQYtvkRXSAweKoxjuWBCrgMysOlUN):
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_url =mIQYtvkRXSAweKoxjuWBCrgMysOlUF
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle=mIQYtvkRXSAweKoxjuWBCrgMysOlUE
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params =mIQYtvkRXSAweKoxjuWBCrgMysOlUN
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj =LXjMaPWOkJbuNynsSKehlfVBvCDIHc() 
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_SUBTITLE_VTT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_SUBTITLE_SRT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.srt'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_COOKIE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_SEARCHEDC_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wc_stream.mpd'))
 def addon_noti(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,sting):
  try:
   mIQYtvkRXSAweKoxjuWBCrgMysOlUc=xbmcgui.Dialog()
   mIQYtvkRXSAweKoxjuWBCrgMysOlUc.notification(__addonname__,sting)
  except:
   mIQYtvkRXSAweKoxjuWBCrgMysOlFJ
 def addon_log(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,string):
  try:
   mIQYtvkRXSAweKoxjuWBCrgMysOlUa=string.encode('utf-8','ignore')
  except:
   mIQYtvkRXSAweKoxjuWBCrgMysOlUa='addonException: addon_log'
  mIQYtvkRXSAweKoxjuWBCrgMysOlUL=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,mIQYtvkRXSAweKoxjuWBCrgMysOlUa),level=mIQYtvkRXSAweKoxjuWBCrgMysOlUL)
 def get_keyboard_input(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,mIQYtvkRXSAweKoxjuWBCrgMysOlDP):
  mIQYtvkRXSAweKoxjuWBCrgMysOlUP=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ
  kb=xbmc.Keyboard()
  kb.setHeading(mIQYtvkRXSAweKoxjuWBCrgMysOlDP)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   mIQYtvkRXSAweKoxjuWBCrgMysOlUP=kb.getText()
  return mIQYtvkRXSAweKoxjuWBCrgMysOlUP
 def get_settings_account(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  mIQYtvkRXSAweKoxjuWBCrgMysOlUh =__addon__.getSetting('id')
  mIQYtvkRXSAweKoxjuWBCrgMysOlUV =__addon__.getSetting('pw')
  mIQYtvkRXSAweKoxjuWBCrgMysOlUT=mIQYtvkRXSAweKoxjuWBCrgMysOlFE(__addon__.getSetting('selected_profile'))
  return(mIQYtvkRXSAweKoxjuWBCrgMysOlUh,mIQYtvkRXSAweKoxjuWBCrgMysOlUV,mIQYtvkRXSAweKoxjuWBCrgMysOlUT)
 def get_settings_totalsearch(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  mIQYtvkRXSAweKoxjuWBCrgMysOlUz =mIQYtvkRXSAweKoxjuWBCrgMysOlFN if __addon__.getSetting('local_search')=='true' else mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  mIQYtvkRXSAweKoxjuWBCrgMysOlUf=mIQYtvkRXSAweKoxjuWBCrgMysOlFN if __addon__.getSetting('local_history')=='true' else mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  mIQYtvkRXSAweKoxjuWBCrgMysOlUi =mIQYtvkRXSAweKoxjuWBCrgMysOlFN if __addon__.getSetting('total_search')=='true' else mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  mIQYtvkRXSAweKoxjuWBCrgMysOlUH=mIQYtvkRXSAweKoxjuWBCrgMysOlFN if __addon__.getSetting('total_history')=='true' else mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  mIQYtvkRXSAweKoxjuWBCrgMysOlUn=mIQYtvkRXSAweKoxjuWBCrgMysOlFN if __addon__.getSetting('menu_bookmark')=='true' else mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  return(mIQYtvkRXSAweKoxjuWBCrgMysOlUz,mIQYtvkRXSAweKoxjuWBCrgMysOlUf,mIQYtvkRXSAweKoxjuWBCrgMysOlUi,mIQYtvkRXSAweKoxjuWBCrgMysOlUH,mIQYtvkRXSAweKoxjuWBCrgMysOlUn)
 def get_settings_makebookmark(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  return mIQYtvkRXSAweKoxjuWBCrgMysOlFN if __addon__.getSetting('make_bookmark')=='true' else mIQYtvkRXSAweKoxjuWBCrgMysOlFG
 def get_settings_proxyport(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  mIQYtvkRXSAweKoxjuWBCrgMysOlDU =mIQYtvkRXSAweKoxjuWBCrgMysOlFN if __addon__.getSetting('proxyYn')=='true' else mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  mIQYtvkRXSAweKoxjuWBCrgMysOlDb=mIQYtvkRXSAweKoxjuWBCrgMysOlFE(__addon__.getSetting('proxyPort'))
  return mIQYtvkRXSAweKoxjuWBCrgMysOlDU,mIQYtvkRXSAweKoxjuWBCrgMysOlDb
 def get_settings_playback(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  mIQYtvkRXSAweKoxjuWBCrgMysOlDd=[3840,1920,1280]
  mIQYtvkRXSAweKoxjuWBCrgMysOlDq =['BASE','HDR','VISION']
  mIQYtvkRXSAweKoxjuWBCrgMysOlDp =['2CH','6CH','ATMOS']
  mIQYtvkRXSAweKoxjuWBCrgMysOlDJ=mIQYtvkRXSAweKoxjuWBCrgMysOlFE(__addon__.getSetting('selected_quality'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlDF =mIQYtvkRXSAweKoxjuWBCrgMysOlFE(__addon__.getSetting('selected_screen'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlDE =mIQYtvkRXSAweKoxjuWBCrgMysOlFE(__addon__.getSetting('selected_sound'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlDN={'max_quality':mIQYtvkRXSAweKoxjuWBCrgMysOlDd[mIQYtvkRXSAweKoxjuWBCrgMysOlDJ],'sel_screen':mIQYtvkRXSAweKoxjuWBCrgMysOlDq[mIQYtvkRXSAweKoxjuWBCrgMysOlDF],'sel_sound':mIQYtvkRXSAweKoxjuWBCrgMysOlDp[mIQYtvkRXSAweKoxjuWBCrgMysOlDE],'streamFilename':mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_STREAM_FILENAME,}
  return mIQYtvkRXSAweKoxjuWBCrgMysOlDN
 def Base64_Encode(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,plaintext):
  return base64.standard_b64encode(plaintext.encode()).decode('utf-8')
 def Params_JsonToStr(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,paramJson):
  mIQYtvkRXSAweKoxjuWBCrgMysOlDG=json.dumps(paramJson,separators=(',',':'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlDG=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.Base64_Encode(mIQYtvkRXSAweKoxjuWBCrgMysOlDG)
  return mIQYtvkRXSAweKoxjuWBCrgMysOlDG
 def get_selQuality(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  try:
   mIQYtvkRXSAweKoxjuWBCrgMysOlDd=['3840x2160/2.0/320/xhdpi','1920x1080/2.0/320/xhdpi','1280x720/2.0/320/xhdpi']
   mIQYtvkRXSAweKoxjuWBCrgMysOlDJ=mIQYtvkRXSAweKoxjuWBCrgMysOlFE(__addon__.getSetting('selected_quality'))
   return mIQYtvkRXSAweKoxjuWBCrgMysOlDd[mIQYtvkRXSAweKoxjuWBCrgMysOlDJ]
  except:
   mIQYtvkRXSAweKoxjuWBCrgMysOlFJ
  return 1080 
 def get_settings_direct_replay(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  mIQYtvkRXSAweKoxjuWBCrgMysOlDc=mIQYtvkRXSAweKoxjuWBCrgMysOlFE(__addon__.getSetting('direct_replay'))
  if mIQYtvkRXSAweKoxjuWBCrgMysOlDc==0:
   return mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  else:
   return mIQYtvkRXSAweKoxjuWBCrgMysOlFN
 def set_winEpisodeOrderby(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,mIQYtvkRXSAweKoxjuWBCrgMysOlDa):
  __addon__.setSetting('watcha_orderby',mIQYtvkRXSAweKoxjuWBCrgMysOlDa)
 def get_winEpisodeOrderby(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  mIQYtvkRXSAweKoxjuWBCrgMysOlDa=__addon__.getSetting('watcha_orderby')
  if mIQYtvkRXSAweKoxjuWBCrgMysOlDa in['',mIQYtvkRXSAweKoxjuWBCrgMysOlFJ]:mIQYtvkRXSAweKoxjuWBCrgMysOlDa='asc'
  return mIQYtvkRXSAweKoxjuWBCrgMysOlDa
 def dp_setEpOrderby(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlDa =args.get('orderby')
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.set_winEpisodeOrderby(mIQYtvkRXSAweKoxjuWBCrgMysOlDa)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,label,sublabel='',img='',infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFN,params='',isLink=mIQYtvkRXSAweKoxjuWBCrgMysOlFG,ContextMenu=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ):
  mIQYtvkRXSAweKoxjuWBCrgMysOlDL='%s?%s'%(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_url,urllib.parse.urlencode(params))
  if sublabel:mIQYtvkRXSAweKoxjuWBCrgMysOlDP='%s < %s >'%(label,sublabel)
  else: mIQYtvkRXSAweKoxjuWBCrgMysOlDP=label
  if not img:img='DefaultFolder.png'
  mIQYtvkRXSAweKoxjuWBCrgMysOlDh=xbmcgui.ListItem(mIQYtvkRXSAweKoxjuWBCrgMysOlDP)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlFc(img)==mIQYtvkRXSAweKoxjuWBCrgMysOlFa:
   mIQYtvkRXSAweKoxjuWBCrgMysOlDh.setArt(img)
  else:
   mIQYtvkRXSAweKoxjuWBCrgMysOlDh.setArt({'thumb':img,'poster':img})
  if infoLabels:mIQYtvkRXSAweKoxjuWBCrgMysOlDh.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   mIQYtvkRXSAweKoxjuWBCrgMysOlDh.setProperty('IsPlayable','true')
  if ContextMenu:mIQYtvkRXSAweKoxjuWBCrgMysOlDh.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,mIQYtvkRXSAweKoxjuWBCrgMysOlDL,mIQYtvkRXSAweKoxjuWBCrgMysOlDh,isFolder)
 def dp_Main_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  (mIQYtvkRXSAweKoxjuWBCrgMysOlUz,mIQYtvkRXSAweKoxjuWBCrgMysOlUf,mIQYtvkRXSAweKoxjuWBCrgMysOlUi,mIQYtvkRXSAweKoxjuWBCrgMysOlUH,mIQYtvkRXSAweKoxjuWBCrgMysOlUn)=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_settings_totalsearch()
  for mIQYtvkRXSAweKoxjuWBCrgMysOlDV in mIQYtvkRXSAweKoxjuWBCrgMysOlUb:
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP=mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('title')
   mIQYtvkRXSAweKoxjuWBCrgMysOlDT=''
   if mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('mode')=='LOCAL_SEARCH' and mIQYtvkRXSAweKoxjuWBCrgMysOlUz ==mIQYtvkRXSAweKoxjuWBCrgMysOlFG:continue
   elif mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('mode')=='SEARCH_HISTORY' and mIQYtvkRXSAweKoxjuWBCrgMysOlUf==mIQYtvkRXSAweKoxjuWBCrgMysOlFG:continue
   elif mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('mode')=='TOTAL_SEARCH' and mIQYtvkRXSAweKoxjuWBCrgMysOlUi ==mIQYtvkRXSAweKoxjuWBCrgMysOlFG:continue
   elif mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('mode')=='TOTAL_HISTORY' and mIQYtvkRXSAweKoxjuWBCrgMysOlUH==mIQYtvkRXSAweKoxjuWBCrgMysOlFG:continue
   elif mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('mode')=='MENU_BOOKMARK' and mIQYtvkRXSAweKoxjuWBCrgMysOlUn==mIQYtvkRXSAweKoxjuWBCrgMysOlFG:continue
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('mode'),'stype':mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('stype'),'api_path':mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('api_path'),'page':'1','tag_id':'-',}
   if mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('mode')=='LOCAL_SEARCH':mIQYtvkRXSAweKoxjuWBCrgMysOlDz['historyyn']='Y' 
   if mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    mIQYtvkRXSAweKoxjuWBCrgMysOlDf=mIQYtvkRXSAweKoxjuWBCrgMysOlFG
    mIQYtvkRXSAweKoxjuWBCrgMysOlDi =mIQYtvkRXSAweKoxjuWBCrgMysOlFN
   else:
    mIQYtvkRXSAweKoxjuWBCrgMysOlDf=mIQYtvkRXSAweKoxjuWBCrgMysOlFN
    mIQYtvkRXSAweKoxjuWBCrgMysOlDi =mIQYtvkRXSAweKoxjuWBCrgMysOlFG
   if 'icon' in mIQYtvkRXSAweKoxjuWBCrgMysOlDV:mIQYtvkRXSAweKoxjuWBCrgMysOlDT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',mIQYtvkRXSAweKoxjuWBCrgMysOlDV.get('icon')) 
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel='',img=mIQYtvkRXSAweKoxjuWBCrgMysOlDT,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlDf,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz,isLink=mIQYtvkRXSAweKoxjuWBCrgMysOlDi)
  xbmcplugin.endOfDirectory(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle)
 def login_main(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  (mIQYtvkRXSAweKoxjuWBCrgMysOlDn,mIQYtvkRXSAweKoxjuWBCrgMysOlbU,mIQYtvkRXSAweKoxjuWBCrgMysOlbD)=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_settings_account()
  if not(mIQYtvkRXSAweKoxjuWBCrgMysOlDn and mIQYtvkRXSAweKoxjuWBCrgMysOlbU):
   mIQYtvkRXSAweKoxjuWBCrgMysOlUc=xbmcgui.Dialog()
   mIQYtvkRXSAweKoxjuWBCrgMysOlbd=mIQYtvkRXSAweKoxjuWBCrgMysOlUc.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if mIQYtvkRXSAweKoxjuWBCrgMysOlbd==mIQYtvkRXSAweKoxjuWBCrgMysOlFN:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   mIQYtvkRXSAweKoxjuWBCrgMysOlbq=0
   while mIQYtvkRXSAweKoxjuWBCrgMysOlFN:
    mIQYtvkRXSAweKoxjuWBCrgMysOlbq+=1
    time.sleep(0.05)
    if mIQYtvkRXSAweKoxjuWBCrgMysOlbq>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  mIQYtvkRXSAweKoxjuWBCrgMysOlbp=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.GetCredential(mIQYtvkRXSAweKoxjuWBCrgMysOlDn,mIQYtvkRXSAweKoxjuWBCrgMysOlbU,mIQYtvkRXSAweKoxjuWBCrgMysOlbD)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlbp:mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
  if mIQYtvkRXSAweKoxjuWBCrgMysOlbp==mIQYtvkRXSAweKoxjuWBCrgMysOlFG:
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_HomeGroup_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlbJ=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.GetHomeList()
  for mIQYtvkRXSAweKoxjuWBCrgMysOlbF in mIQYtvkRXSAweKoxjuWBCrgMysOlbJ:
   mIQYtvkRXSAweKoxjuWBCrgMysOlbE =mIQYtvkRXSAweKoxjuWBCrgMysOlbF.get('code')
   mIQYtvkRXSAweKoxjuWBCrgMysOlbN=mIQYtvkRXSAweKoxjuWBCrgMysOlbF.get('content_type')
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP =mIQYtvkRXSAweKoxjuWBCrgMysOlbF.get('title')
   mIQYtvkRXSAweKoxjuWBCrgMysOlbG =mIQYtvkRXSAweKoxjuWBCrgMysOlbF.get('bedge')
   mIQYtvkRXSAweKoxjuWBCrgMysOlbc =mIQYtvkRXSAweKoxjuWBCrgMysOlbF.get('thumbnail')
   if mIQYtvkRXSAweKoxjuWBCrgMysOlbN=='staffmades':
    mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'CATEGORY_LIST','api_path':'staffmades/'+mIQYtvkRXSAweKoxjuWBCrgMysOlbE,'page':'1',}
    mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel=mIQYtvkRXSAweKoxjuWBCrgMysOlbG,img=mIQYtvkRXSAweKoxjuWBCrgMysOlbc,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFN,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz)
   elif mIQYtvkRXSAweKoxjuWBCrgMysOlbN=='contents':
    mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'EPISODE','movie_code':mIQYtvkRXSAweKoxjuWBCrgMysOlbE,'page':'1','season_code':mIQYtvkRXSAweKoxjuWBCrgMysOlbE,'title':mIQYtvkRXSAweKoxjuWBCrgMysOlDP,'thumbnail':mIQYtvkRXSAweKoxjuWBCrgMysOlbc,}
    mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel=mIQYtvkRXSAweKoxjuWBCrgMysOlbG,img=mIQYtvkRXSAweKoxjuWBCrgMysOlbc,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFN,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz)
   else:
    mIQYtvkRXSAweKoxjuWBCrgMysOlba
  xbmcplugin.endOfDirectory(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,cacheToDisc=mIQYtvkRXSAweKoxjuWBCrgMysOlFN)
 def dp_SubGroup_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlbP =args.get('stype')
  mIQYtvkRXSAweKoxjuWBCrgMysOlbh =mIQYtvkRXSAweKoxjuWBCrgMysOlFE(args.get('page'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlbV=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.GetSubGroupList(mIQYtvkRXSAweKoxjuWBCrgMysOlbP)
  mIQYtvkRXSAweKoxjuWBCrgMysOlbT=mIQYtvkRXSAweKoxjuWBCrgMysOlUq if mIQYtvkRXSAweKoxjuWBCrgMysOlbP=='genres' else mIQYtvkRXSAweKoxjuWBCrgMysOlUp
  mIQYtvkRXSAweKoxjuWBCrgMysOlbz=mIQYtvkRXSAweKoxjuWBCrgMysOlFL(mIQYtvkRXSAweKoxjuWBCrgMysOlbV)
  mIQYtvkRXSAweKoxjuWBCrgMysOlbf =mIQYtvkRXSAweKoxjuWBCrgMysOlFE(mIQYtvkRXSAweKoxjuWBCrgMysOlbz//(mIQYtvkRXSAweKoxjuWBCrgMysOlbT+1))+1
  mIQYtvkRXSAweKoxjuWBCrgMysOlbi =(mIQYtvkRXSAweKoxjuWBCrgMysOlbh-1)*mIQYtvkRXSAweKoxjuWBCrgMysOlbT
  for i in mIQYtvkRXSAweKoxjuWBCrgMysOlFP(mIQYtvkRXSAweKoxjuWBCrgMysOlbT):
   mIQYtvkRXSAweKoxjuWBCrgMysOlbH=mIQYtvkRXSAweKoxjuWBCrgMysOlbi+i
   if mIQYtvkRXSAweKoxjuWBCrgMysOlbH>=mIQYtvkRXSAweKoxjuWBCrgMysOlbz:break
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP =mIQYtvkRXSAweKoxjuWBCrgMysOlbV[mIQYtvkRXSAweKoxjuWBCrgMysOlbH].get('group_name')
   mIQYtvkRXSAweKoxjuWBCrgMysOlbn =mIQYtvkRXSAweKoxjuWBCrgMysOlbV[mIQYtvkRXSAweKoxjuWBCrgMysOlbH].get('api_path')
   mIQYtvkRXSAweKoxjuWBCrgMysOldU =mIQYtvkRXSAweKoxjuWBCrgMysOlbV[mIQYtvkRXSAweKoxjuWBCrgMysOlbH].get('tag_id')
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'CATEGORY_LIST','api_path':mIQYtvkRXSAweKoxjuWBCrgMysOlbn,'tag_id':mIQYtvkRXSAweKoxjuWBCrgMysOldU,'stype':mIQYtvkRXSAweKoxjuWBCrgMysOlbP,'page':'1',}
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel='',img='',infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFN,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlbf>mIQYtvkRXSAweKoxjuWBCrgMysOlbh:
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={}
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['mode'] ='SUB_GROUP' 
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['stype'] =mIQYtvkRXSAweKoxjuWBCrgMysOlbP
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['api_path']=args.get('api_path')
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['page'] =mIQYtvkRXSAweKoxjuWBCrgMysOlFh(mIQYtvkRXSAweKoxjuWBCrgMysOlbh+1)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP='[B]%s >>[/B]'%'다음 페이지'
   mIQYtvkRXSAweKoxjuWBCrgMysOldD=mIQYtvkRXSAweKoxjuWBCrgMysOlFh(mIQYtvkRXSAweKoxjuWBCrgMysOlbh+1)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel=mIQYtvkRXSAweKoxjuWBCrgMysOldD,img=mIQYtvkRXSAweKoxjuWBCrgMysOlDT,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFN,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlFL(mIQYtvkRXSAweKoxjuWBCrgMysOlbV)>0:xbmcplugin.endOfDirectory(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,cacheToDisc=mIQYtvkRXSAweKoxjuWBCrgMysOlFN)
 def play_VIDEO(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOldb =args.get('movie_code')
  mIQYtvkRXSAweKoxjuWBCrgMysOldq =args.get('season_code')
  mIQYtvkRXSAweKoxjuWBCrgMysOlDP =args.get('title')
  mIQYtvkRXSAweKoxjuWBCrgMysOlbc =args.get('thumbnail')
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.addon_log(mIQYtvkRXSAweKoxjuWBCrgMysOldb+' - '+mIQYtvkRXSAweKoxjuWBCrgMysOldq)
  mIQYtvkRXSAweKoxjuWBCrgMysOldp =mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_selQuality()
  mIQYtvkRXSAweKoxjuWBCrgMysOlDU,mIQYtvkRXSAweKoxjuWBCrgMysOlDb=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_settings_proxyport()
  mIQYtvkRXSAweKoxjuWBCrgMysOlDN=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_settings_playback()
  mIQYtvkRXSAweKoxjuWBCrgMysOldJ=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.GetStreamingURL(mIQYtvkRXSAweKoxjuWBCrgMysOldb,mIQYtvkRXSAweKoxjuWBCrgMysOldp,proxyUse=mIQYtvkRXSAweKoxjuWBCrgMysOlDU,inScreen=mIQYtvkRXSAweKoxjuWBCrgMysOlDN['sel_screen'],inSound=mIQYtvkRXSAweKoxjuWBCrgMysOlDN['sel_sound'])
  if mIQYtvkRXSAweKoxjuWBCrgMysOldJ['streamUrl']=='':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.addon_noti(__language__(30908).encode('utf8'))
   return
  mIQYtvkRXSAweKoxjuWBCrgMysOldF=mIQYtvkRXSAweKoxjuWBCrgMysOldJ['streamUrl']
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.addon_log(mIQYtvkRXSAweKoxjuWBCrgMysOldF)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlDU:
   mIQYtvkRXSAweKoxjuWBCrgMysOldE={'addon':'watcham','playOption':mIQYtvkRXSAweKoxjuWBCrgMysOlDN,}
   mIQYtvkRXSAweKoxjuWBCrgMysOldE=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.Params_JsonToStr(mIQYtvkRXSAweKoxjuWBCrgMysOldE)
   mIQYtvkRXSAweKoxjuWBCrgMysOldF='http://127.0.0.1:{}/{}|proxy-mini={}'.format(mIQYtvkRXSAweKoxjuWBCrgMysOlDb,mIQYtvkRXSAweKoxjuWBCrgMysOldF,mIQYtvkRXSAweKoxjuWBCrgMysOldE)
  mIQYtvkRXSAweKoxjuWBCrgMysOldN=xbmcgui.ListItem(path=mIQYtvkRXSAweKoxjuWBCrgMysOldF)
  if mIQYtvkRXSAweKoxjuWBCrgMysOldJ['customdata']:
   mIQYtvkRXSAweKoxjuWBCrgMysOldG=mIQYtvkRXSAweKoxjuWBCrgMysOldJ['customdata']
   mIQYtvkRXSAweKoxjuWBCrgMysOldc ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   mIQYtvkRXSAweKoxjuWBCrgMysOlda ='mpd'
   mIQYtvkRXSAweKoxjuWBCrgMysOldL ='com.widevine.alpha'
   mIQYtvkRXSAweKoxjuWBCrgMysOldP =inputstreamhelper.Helper(mIQYtvkRXSAweKoxjuWBCrgMysOlda,drm=mIQYtvkRXSAweKoxjuWBCrgMysOldL)
   if mIQYtvkRXSAweKoxjuWBCrgMysOldP.check_inputstream():
    mIQYtvkRXSAweKoxjuWBCrgMysOldh={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+mIQYtvkRXSAweKoxjuWBCrgMysOldb,'dt-custom-data':mIQYtvkRXSAweKoxjuWBCrgMysOldG,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream',}
    mIQYtvkRXSAweKoxjuWBCrgMysOldV=mIQYtvkRXSAweKoxjuWBCrgMysOldc+'|'+urllib.parse.urlencode(mIQYtvkRXSAweKoxjuWBCrgMysOldh)+'|R{SSM}|'
    mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.addon_log(mIQYtvkRXSAweKoxjuWBCrgMysOldV)
    mIQYtvkRXSAweKoxjuWBCrgMysOldN.setProperty('inputstream',mIQYtvkRXSAweKoxjuWBCrgMysOldP.inputstream_addon)
    mIQYtvkRXSAweKoxjuWBCrgMysOldN.setProperty('inputstream.adaptive.manifest_type',mIQYtvkRXSAweKoxjuWBCrgMysOlda)
    mIQYtvkRXSAweKoxjuWBCrgMysOldN.setProperty('inputstream.adaptive.license_type',mIQYtvkRXSAweKoxjuWBCrgMysOldL)
    mIQYtvkRXSAweKoxjuWBCrgMysOldN.setProperty('inputstream.adaptive.license_key',mIQYtvkRXSAweKoxjuWBCrgMysOldV)
    mIQYtvkRXSAweKoxjuWBCrgMysOldN.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.USER_AGENT))
  if mIQYtvkRXSAweKoxjuWBCrgMysOldJ['subtitleUrl']:
   try:
    f=mIQYtvkRXSAweKoxjuWBCrgMysOlFV(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_SUBTITLE_VTT,'w',-1,'utf-8')
    mIQYtvkRXSAweKoxjuWBCrgMysOldT=requests.get(mIQYtvkRXSAweKoxjuWBCrgMysOldJ['subtitleUrl'])
    mIQYtvkRXSAweKoxjuWBCrgMysOldz=mIQYtvkRXSAweKoxjuWBCrgMysOldT.content.decode('utf-8') 
    for mIQYtvkRXSAweKoxjuWBCrgMysOldf in mIQYtvkRXSAweKoxjuWBCrgMysOldz.splitlines():
     mIQYtvkRXSAweKoxjuWBCrgMysOldi=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',mIQYtvkRXSAweKoxjuWBCrgMysOldf)
     f.write(mIQYtvkRXSAweKoxjuWBCrgMysOldi+'\n')
    f.close()
    mIQYtvkRXSAweKoxjuWBCrgMysOldN.setSubtitles([mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_SUBTITLE_VTT,mIQYtvkRXSAweKoxjuWBCrgMysOldJ['subtitleUrl']])
   except:
    mIQYtvkRXSAweKoxjuWBCrgMysOldN.setSubtitles([mIQYtvkRXSAweKoxjuWBCrgMysOldJ['subtitleUrl']])
  xbmcplugin.setResolvedUrl(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,mIQYtvkRXSAweKoxjuWBCrgMysOlFN,mIQYtvkRXSAweKoxjuWBCrgMysOldN)
  try:
   mIQYtvkRXSAweKoxjuWBCrgMysOlbP='movie' if mIQYtvkRXSAweKoxjuWBCrgMysOldq=='-' else 'seasons'
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'code':mIQYtvkRXSAweKoxjuWBCrgMysOldb if mIQYtvkRXSAweKoxjuWBCrgMysOlbP=='movie' else mIQYtvkRXSAweKoxjuWBCrgMysOldq,'img':mIQYtvkRXSAweKoxjuWBCrgMysOlbc,'title':mIQYtvkRXSAweKoxjuWBCrgMysOlDP,'videoid':mIQYtvkRXSAweKoxjuWBCrgMysOldb}
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.Save_Watched_List(mIQYtvkRXSAweKoxjuWBCrgMysOlbP,mIQYtvkRXSAweKoxjuWBCrgMysOlDz)
  except:
   mIQYtvkRXSAweKoxjuWBCrgMysOlFJ
 def srtConvert(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,mIQYtvkRXSAweKoxjuWBCrgMysOldn):
  mIQYtvkRXSAweKoxjuWBCrgMysOldH=re.sub(r'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',mIQYtvkRXSAweKoxjuWBCrgMysOldn)
  mIQYtvkRXSAweKoxjuWBCrgMysOldH=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',mIQYtvkRXSAweKoxjuWBCrgMysOldH)
  mIQYtvkRXSAweKoxjuWBCrgMysOldH=re.sub(r'(\d\d).(\d\d\d) --> (\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',mIQYtvkRXSAweKoxjuWBCrgMysOldH)
  mIQYtvkRXSAweKoxjuWBCrgMysOldH=re.sub(r'WEBVTT\n','',mIQYtvkRXSAweKoxjuWBCrgMysOldH)
  mIQYtvkRXSAweKoxjuWBCrgMysOldH=re.sub(r'Kind:[ \-\w]+\n','',mIQYtvkRXSAweKoxjuWBCrgMysOldH)
  mIQYtvkRXSAweKoxjuWBCrgMysOldH=re.sub(r'Language:[ \-\w]+\n','',mIQYtvkRXSAweKoxjuWBCrgMysOldH)
  mIQYtvkRXSAweKoxjuWBCrgMysOldH=re.sub(r'<c[.\w\d]*>','',mIQYtvkRXSAweKoxjuWBCrgMysOldH)
  mIQYtvkRXSAweKoxjuWBCrgMysOldH=re.sub(r'</c>','',mIQYtvkRXSAweKoxjuWBCrgMysOldH)
  mIQYtvkRXSAweKoxjuWBCrgMysOldH=re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>','',mIQYtvkRXSAweKoxjuWBCrgMysOldH)
  mIQYtvkRXSAweKoxjuWBCrgMysOldH=re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n','',mIQYtvkRXSAweKoxjuWBCrgMysOldH)
  mIQYtvkRXSAweKoxjuWBCrgMysOldH=re.sub(r'Style:\n##\n','',mIQYtvkRXSAweKoxjuWBCrgMysOldH)
  return mIQYtvkRXSAweKoxjuWBCrgMysOldH
 def vtt_to_srt(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,vttFilename,srtFilename):
  try:
   f=mIQYtvkRXSAweKoxjuWBCrgMysOlFV(vttFilename,'r',-1,'utf-8')
   mIQYtvkRXSAweKoxjuWBCrgMysOldn=f.read()
   f.close()
   mIQYtvkRXSAweKoxjuWBCrgMysOlqU=''
   mIQYtvkRXSAweKoxjuWBCrgMysOlqU=mIQYtvkRXSAweKoxjuWBCrgMysOlqU+mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.srtConvert(mIQYtvkRXSAweKoxjuWBCrgMysOldn)
   f=mIQYtvkRXSAweKoxjuWBCrgMysOlFV(srtFilename,'w',-1,'utf-8')
   f.writelines(mIQYtvkRXSAweKoxjuWBCrgMysOlFh(mIQYtvkRXSAweKoxjuWBCrgMysOlqU))
   f.close()
  except:
   return mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  return mIQYtvkRXSAweKoxjuWBCrgMysOlFN
 def dp_Category_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlbP =args.get('stype')
  mIQYtvkRXSAweKoxjuWBCrgMysOldU =args.get('tag_id')
  mIQYtvkRXSAweKoxjuWBCrgMysOlbn=args.get('api_path')
  mIQYtvkRXSAweKoxjuWBCrgMysOlbh=mIQYtvkRXSAweKoxjuWBCrgMysOlFE(args.get('page'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlqD=[]
  mIQYtvkRXSAweKoxjuWBCrgMysOlqb,mIQYtvkRXSAweKoxjuWBCrgMysOlqd=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.GetCategoryList(mIQYtvkRXSAweKoxjuWBCrgMysOlbP,mIQYtvkRXSAweKoxjuWBCrgMysOldU,mIQYtvkRXSAweKoxjuWBCrgMysOlbn,mIQYtvkRXSAweKoxjuWBCrgMysOlbh)
  for mIQYtvkRXSAweKoxjuWBCrgMysOlqp in mIQYtvkRXSAweKoxjuWBCrgMysOlqb:
   mIQYtvkRXSAweKoxjuWBCrgMysOldb =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('code')
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('title')
   mIQYtvkRXSAweKoxjuWBCrgMysOlbN =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('content_type')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqJ =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('story')
   mIQYtvkRXSAweKoxjuWBCrgMysOlbc =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('thumbnail')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqF =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('year')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqE =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('film_rating_code')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqN=mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('film_rating_short')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqG =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('film_rating_long')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqc =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('duration')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqa =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('badge')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqD.append(mIQYtvkRXSAweKoxjuWBCrgMysOldb)
   if mIQYtvkRXSAweKoxjuWBCrgMysOlbN=='movies': 
    mIQYtvkRXSAweKoxjuWBCrgMysOlDf =mIQYtvkRXSAweKoxjuWBCrgMysOlFG
    mIQYtvkRXSAweKoxjuWBCrgMysOlqL ='MOVIE'
    mIQYtvkRXSAweKoxjuWBCrgMysOldq='-'
    mIQYtvkRXSAweKoxjuWBCrgMysOlqP ='movie'
   else: 
    mIQYtvkRXSAweKoxjuWBCrgMysOlDf =mIQYtvkRXSAweKoxjuWBCrgMysOlFN
    mIQYtvkRXSAweKoxjuWBCrgMysOlqL ='SEASON'
    mIQYtvkRXSAweKoxjuWBCrgMysOldq=mIQYtvkRXSAweKoxjuWBCrgMysOldb
    mIQYtvkRXSAweKoxjuWBCrgMysOlqP ='tvshow' 
   mIQYtvkRXSAweKoxjuWBCrgMysOlqh={'mediatype':mIQYtvkRXSAweKoxjuWBCrgMysOlqP,'mpaa':mIQYtvkRXSAweKoxjuWBCrgMysOlqG,'title':mIQYtvkRXSAweKoxjuWBCrgMysOlDP,'year':mIQYtvkRXSAweKoxjuWBCrgMysOlqF,'duration':mIQYtvkRXSAweKoxjuWBCrgMysOlqc,'plot':mIQYtvkRXSAweKoxjuWBCrgMysOlqJ,}
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP+='  (%s)'%(mIQYtvkRXSAweKoxjuWBCrgMysOlqF)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':mIQYtvkRXSAweKoxjuWBCrgMysOlqL,'movie_code':mIQYtvkRXSAweKoxjuWBCrgMysOldb,'page':'1','season_code':mIQYtvkRXSAweKoxjuWBCrgMysOldq,'title':mIQYtvkRXSAweKoxjuWBCrgMysOlDP,'thumbnail':mIQYtvkRXSAweKoxjuWBCrgMysOlbc,}
   mIQYtvkRXSAweKoxjuWBCrgMysOlqV=[]
   if mIQYtvkRXSAweKoxjuWBCrgMysOlbn=='users/me/watchings':
    mIQYtvkRXSAweKoxjuWBCrgMysOlqT={'codeList':[mIQYtvkRXSAweKoxjuWBCrgMysOldb]}
    mIQYtvkRXSAweKoxjuWBCrgMysOlqz=json.dumps(mIQYtvkRXSAweKoxjuWBCrgMysOlqT)
    mIQYtvkRXSAweKoxjuWBCrgMysOlqz=urllib.parse.quote(mIQYtvkRXSAweKoxjuWBCrgMysOlqz)
    mIQYtvkRXSAweKoxjuWBCrgMysOlqf='RunPlugin(plugin://plugin.video.watcham/?mode=DELETE_CONTINUE&bm_param=%s)'%(mIQYtvkRXSAweKoxjuWBCrgMysOlqz)
    mIQYtvkRXSAweKoxjuWBCrgMysOlqV.append(('(선택영상) 이어보기에서 삭제',mIQYtvkRXSAweKoxjuWBCrgMysOlqf))
   if mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_settings_makebookmark():
    mIQYtvkRXSAweKoxjuWBCrgMysOlqT={'videoid':mIQYtvkRXSAweKoxjuWBCrgMysOldb,'vidtype':'tvshow' if mIQYtvkRXSAweKoxjuWBCrgMysOlbN=='tv_seasons' else 'movie','vtitle':mIQYtvkRXSAweKoxjuWBCrgMysOlDP,'vsubtitle':'',}
    mIQYtvkRXSAweKoxjuWBCrgMysOlqz=json.dumps(mIQYtvkRXSAweKoxjuWBCrgMysOlqT)
    mIQYtvkRXSAweKoxjuWBCrgMysOlqz=urllib.parse.quote(mIQYtvkRXSAweKoxjuWBCrgMysOlqz)
    mIQYtvkRXSAweKoxjuWBCrgMysOlqf='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(mIQYtvkRXSAweKoxjuWBCrgMysOlqz)
    mIQYtvkRXSAweKoxjuWBCrgMysOlqV.append(('(통합) 찜 영상에 추가',mIQYtvkRXSAweKoxjuWBCrgMysOlqf))
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel=mIQYtvkRXSAweKoxjuWBCrgMysOlqa,img=mIQYtvkRXSAweKoxjuWBCrgMysOlbc,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlqh,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlDf,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz,ContextMenu=mIQYtvkRXSAweKoxjuWBCrgMysOlqV)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlbn=='users/me/watchings':
   mIQYtvkRXSAweKoxjuWBCrgMysOlqT={'codeList':mIQYtvkRXSAweKoxjuWBCrgMysOlqD}
   mIQYtvkRXSAweKoxjuWBCrgMysOlqz=json.dumps(mIQYtvkRXSAweKoxjuWBCrgMysOlqT,separators=(',',':'))
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.addon_log(mIQYtvkRXSAweKoxjuWBCrgMysOlqz)
   mIQYtvkRXSAweKoxjuWBCrgMysOlqz=urllib.parse.quote(mIQYtvkRXSAweKoxjuWBCrgMysOlqz)
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.addon_log(mIQYtvkRXSAweKoxjuWBCrgMysOlqz)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'DELETE_CONTINUE','bm_param':mIQYtvkRXSAweKoxjuWBCrgMysOlqT,}
   mIQYtvkRXSAweKoxjuWBCrgMysOlqh={'plot':'이어보기 목록 전체를 삭제합니다.'}
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP='** 이어보기 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   mIQYtvkRXSAweKoxjuWBCrgMysOlDT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel='',img=mIQYtvkRXSAweKoxjuWBCrgMysOlDT,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlqh,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFG,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz,isLink=mIQYtvkRXSAweKoxjuWBCrgMysOlFN)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlqd:
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={}
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['mode'] ='CATEGORY_LIST'
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['stype'] =mIQYtvkRXSAweKoxjuWBCrgMysOlbP
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['tag_id'] =mIQYtvkRXSAweKoxjuWBCrgMysOldU
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['api_path']=mIQYtvkRXSAweKoxjuWBCrgMysOlbn
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['page'] =mIQYtvkRXSAweKoxjuWBCrgMysOlFh(mIQYtvkRXSAweKoxjuWBCrgMysOlbh+1)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP='[B]%s >>[/B]'%'다음 페이지'
   mIQYtvkRXSAweKoxjuWBCrgMysOldD=mIQYtvkRXSAweKoxjuWBCrgMysOlFh(mIQYtvkRXSAweKoxjuWBCrgMysOlbh+1)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel=mIQYtvkRXSAweKoxjuWBCrgMysOldD,img=mIQYtvkRXSAweKoxjuWBCrgMysOlDT,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFN,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz)
  xbmcplugin.setContent(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,'movies')
  if mIQYtvkRXSAweKoxjuWBCrgMysOlFL(mIQYtvkRXSAweKoxjuWBCrgMysOlqb)>0:
   if mIQYtvkRXSAweKoxjuWBCrgMysOlbn=='arrivals/latest':
    xbmcplugin.endOfDirectory(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,cacheToDisc=mIQYtvkRXSAweKoxjuWBCrgMysOlFN)
   else:
    xbmcplugin.endOfDirectory(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,cacheToDisc=mIQYtvkRXSAweKoxjuWBCrgMysOlFG)
 def dp_Season_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOldq=args.get('season_code')
  mIQYtvkRXSAweKoxjuWBCrgMysOlbc =args.get('thumbnail')
  mIQYtvkRXSAweKoxjuWBCrgMysOlbc=json.loads(mIQYtvkRXSAweKoxjuWBCrgMysOlbc.replace('\'','"'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlqi=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.GetSeasonList(mIQYtvkRXSAweKoxjuWBCrgMysOldq)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlFL(mIQYtvkRXSAweKoxjuWBCrgMysOlqi)>1:
   for mIQYtvkRXSAweKoxjuWBCrgMysOlqH in mIQYtvkRXSAweKoxjuWBCrgMysOlqi:
    mIQYtvkRXSAweKoxjuWBCrgMysOlqn=mIQYtvkRXSAweKoxjuWBCrgMysOlqH.get('seasonId')
    mIQYtvkRXSAweKoxjuWBCrgMysOlpU=mIQYtvkRXSAweKoxjuWBCrgMysOlqH.get('seasonNm')
    mIQYtvkRXSAweKoxjuWBCrgMysOlqh={'mediatype':'tvshow','title':mIQYtvkRXSAweKoxjuWBCrgMysOlpU,}
    mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'EPISODE','movie_code':mIQYtvkRXSAweKoxjuWBCrgMysOlqn,'page':'1','season_code':mIQYtvkRXSAweKoxjuWBCrgMysOlqn,'title':mIQYtvkRXSAweKoxjuWBCrgMysOlpU,'thumbnail':mIQYtvkRXSAweKoxjuWBCrgMysOlbc,}
    mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlpU,sublabel=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,img=mIQYtvkRXSAweKoxjuWBCrgMysOlbc,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlqh,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFN,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz,ContextMenu=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ)
   xbmcplugin.setContent(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,cacheToDisc=mIQYtvkRXSAweKoxjuWBCrgMysOlFG)
  else:
   mIQYtvkRXSAweKoxjuWBCrgMysOlpD={'movie_code':mIQYtvkRXSAweKoxjuWBCrgMysOldq,'page':'1','season_code':mIQYtvkRXSAweKoxjuWBCrgMysOldq,}
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Episode_List(mIQYtvkRXSAweKoxjuWBCrgMysOlpD)
 def dp_Episode_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlpb=args.get('movie_code')
  mIQYtvkRXSAweKoxjuWBCrgMysOlbh =mIQYtvkRXSAweKoxjuWBCrgMysOlFE(args.get('page'))
  mIQYtvkRXSAweKoxjuWBCrgMysOldq =args.get('season_code')
  mIQYtvkRXSAweKoxjuWBCrgMysOlqb,mIQYtvkRXSAweKoxjuWBCrgMysOlqd=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.GetEpisodoList(mIQYtvkRXSAweKoxjuWBCrgMysOlpb,mIQYtvkRXSAweKoxjuWBCrgMysOlbh,orderby=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_winEpisodeOrderby())
  for mIQYtvkRXSAweKoxjuWBCrgMysOlqp in mIQYtvkRXSAweKoxjuWBCrgMysOlqb:
   mIQYtvkRXSAweKoxjuWBCrgMysOldb =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('code')
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('title')
   mIQYtvkRXSAweKoxjuWBCrgMysOlbc =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('thumbnail')
   mIQYtvkRXSAweKoxjuWBCrgMysOlpd =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('display_num')
   mIQYtvkRXSAweKoxjuWBCrgMysOlpq =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('season_title')
   mIQYtvkRXSAweKoxjuWBCrgMysOlpJ=mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('episode_number')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqc =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('duration')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqh={'mediatype':'episode','tvshowtitle':mIQYtvkRXSAweKoxjuWBCrgMysOlDP if mIQYtvkRXSAweKoxjuWBCrgMysOlDP!='' else mIQYtvkRXSAweKoxjuWBCrgMysOlpq,'title':'%s %s'%(mIQYtvkRXSAweKoxjuWBCrgMysOlpq,mIQYtvkRXSAweKoxjuWBCrgMysOlpd)if mIQYtvkRXSAweKoxjuWBCrgMysOlDP!='' else mIQYtvkRXSAweKoxjuWBCrgMysOlpd,'episode':mIQYtvkRXSAweKoxjuWBCrgMysOlpJ,'duration':mIQYtvkRXSAweKoxjuWBCrgMysOlqc,'plot':'%s\n%s\n\n%s'%(mIQYtvkRXSAweKoxjuWBCrgMysOlpq,mIQYtvkRXSAweKoxjuWBCrgMysOlpd,mIQYtvkRXSAweKoxjuWBCrgMysOlDP)}
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP='(%s) %s'%(mIQYtvkRXSAweKoxjuWBCrgMysOlpd,mIQYtvkRXSAweKoxjuWBCrgMysOlDP)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'MOVIE','movie_code':mIQYtvkRXSAweKoxjuWBCrgMysOldb,'season_code':mIQYtvkRXSAweKoxjuWBCrgMysOldq,'title':'%s < %s >'%(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,mIQYtvkRXSAweKoxjuWBCrgMysOlpq),'thumbnail':mIQYtvkRXSAweKoxjuWBCrgMysOlbc}
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel=mIQYtvkRXSAweKoxjuWBCrgMysOlpq,img=mIQYtvkRXSAweKoxjuWBCrgMysOlbc,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlqh,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFG,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlbh==1:
   mIQYtvkRXSAweKoxjuWBCrgMysOlqh={'plot':'정렬순서를 변경합니다.'}
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={}
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['mode'] ='ORDER_BY' 
   if mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_winEpisodeOrderby()=='desc':
    mIQYtvkRXSAweKoxjuWBCrgMysOlDP='정렬순서변경 : 최신화부터 -> 1회부터'
    mIQYtvkRXSAweKoxjuWBCrgMysOlDz['orderby']='asc'
   else:
    mIQYtvkRXSAweKoxjuWBCrgMysOlDP='정렬순서변경 : 1회부터 -> 최신화부터'
    mIQYtvkRXSAweKoxjuWBCrgMysOlDz['orderby']='desc'
   mIQYtvkRXSAweKoxjuWBCrgMysOlDT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel='',img=mIQYtvkRXSAweKoxjuWBCrgMysOlDT,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlqh,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFG,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz,isLink=mIQYtvkRXSAweKoxjuWBCrgMysOlFN)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlqd:
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['mode'] ='EPISODE' 
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['movie_code']=mIQYtvkRXSAweKoxjuWBCrgMysOlpb
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['page'] =mIQYtvkRXSAweKoxjuWBCrgMysOlFh(mIQYtvkRXSAweKoxjuWBCrgMysOlbh+1)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP='[B]%s >>[/B]'%'다음 페이지'
   mIQYtvkRXSAweKoxjuWBCrgMysOldD=mIQYtvkRXSAweKoxjuWBCrgMysOlFh(mIQYtvkRXSAweKoxjuWBCrgMysOlbh+1)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel=mIQYtvkRXSAweKoxjuWBCrgMysOldD,img=mIQYtvkRXSAweKoxjuWBCrgMysOlDT,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFN,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz)
  xbmcplugin.setContent(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,'episodes')
  if mIQYtvkRXSAweKoxjuWBCrgMysOlFL(mIQYtvkRXSAweKoxjuWBCrgMysOlqb)>0:xbmcplugin.endOfDirectory(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,cacheToDisc=mIQYtvkRXSAweKoxjuWBCrgMysOlFN)
 def dp_Search_History(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlpF=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.Load_List_File('search')
  for mIQYtvkRXSAweKoxjuWBCrgMysOlpE in mIQYtvkRXSAweKoxjuWBCrgMysOlpF:
   mIQYtvkRXSAweKoxjuWBCrgMysOlpN=mIQYtvkRXSAweKoxjuWBCrgMysOlFa(urllib.parse.parse_qsl(mIQYtvkRXSAweKoxjuWBCrgMysOlpE))
   mIQYtvkRXSAweKoxjuWBCrgMysOlpG=mIQYtvkRXSAweKoxjuWBCrgMysOlpN.get('skey').strip()
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'LOCAL_SEARCH','search_key':mIQYtvkRXSAweKoxjuWBCrgMysOlpG,'page':'1','historyyn':'Y',}
   mIQYtvkRXSAweKoxjuWBCrgMysOlpc={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':mIQYtvkRXSAweKoxjuWBCrgMysOlpG,'vType':'-',}
   mIQYtvkRXSAweKoxjuWBCrgMysOlpa=urllib.parse.urlencode(mIQYtvkRXSAweKoxjuWBCrgMysOlpc)
   mIQYtvkRXSAweKoxjuWBCrgMysOlqV=[('선택된 검색어 ( %s ) 삭제'%(mIQYtvkRXSAweKoxjuWBCrgMysOlpG),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(mIQYtvkRXSAweKoxjuWBCrgMysOlpa))]
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlpG,sublabel='',img=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFN,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz,ContextMenu=mIQYtvkRXSAweKoxjuWBCrgMysOlqV)
  mIQYtvkRXSAweKoxjuWBCrgMysOlqh={'plot':'검색목록 전체를 삭제합니다.'}
  mIQYtvkRXSAweKoxjuWBCrgMysOlDP='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  mIQYtvkRXSAweKoxjuWBCrgMysOlDT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel='',img=mIQYtvkRXSAweKoxjuWBCrgMysOlDT,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlqh,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFG,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz,isLink=mIQYtvkRXSAweKoxjuWBCrgMysOlFN)
  xbmcplugin.endOfDirectory(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,cacheToDisc=mIQYtvkRXSAweKoxjuWBCrgMysOlFG)
 def dp_Search_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlbh =mIQYtvkRXSAweKoxjuWBCrgMysOlFE(args.get('page'))
  if 'search_key' in args:
   mIQYtvkRXSAweKoxjuWBCrgMysOlpL=args.get('search_key')
  else:
   mIQYtvkRXSAweKoxjuWBCrgMysOlpL=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not mIQYtvkRXSAweKoxjuWBCrgMysOlpL:
    return
  mIQYtvkRXSAweKoxjuWBCrgMysOlqb,mIQYtvkRXSAweKoxjuWBCrgMysOlqd=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.GetSearchList(mIQYtvkRXSAweKoxjuWBCrgMysOlpL,mIQYtvkRXSAweKoxjuWBCrgMysOlbh)
  for mIQYtvkRXSAweKoxjuWBCrgMysOlqp in mIQYtvkRXSAweKoxjuWBCrgMysOlqb:
   mIQYtvkRXSAweKoxjuWBCrgMysOldb =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('code')
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('title')
   mIQYtvkRXSAweKoxjuWBCrgMysOlbN=mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('content_type')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqJ =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('story')
   mIQYtvkRXSAweKoxjuWBCrgMysOlbc =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('thumbnail')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqF =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('year')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqE =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('film_rating_code')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqN=mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('film_rating_short')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqG =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('film_rating_long')
   mIQYtvkRXSAweKoxjuWBCrgMysOlqc =mIQYtvkRXSAweKoxjuWBCrgMysOlqp.get('duration')
   if mIQYtvkRXSAweKoxjuWBCrgMysOlbN=='movies': 
    mIQYtvkRXSAweKoxjuWBCrgMysOlDf =mIQYtvkRXSAweKoxjuWBCrgMysOlFG
    mIQYtvkRXSAweKoxjuWBCrgMysOlqL ='MOVIE'
    mIQYtvkRXSAweKoxjuWBCrgMysOlDH =''
    mIQYtvkRXSAweKoxjuWBCrgMysOldq='-'
    mIQYtvkRXSAweKoxjuWBCrgMysOlqP ='movie'
   else: 
    mIQYtvkRXSAweKoxjuWBCrgMysOlDf =mIQYtvkRXSAweKoxjuWBCrgMysOlFN
    mIQYtvkRXSAweKoxjuWBCrgMysOlqL ='SEASON'
    mIQYtvkRXSAweKoxjuWBCrgMysOlDH ='' 
    mIQYtvkRXSAweKoxjuWBCrgMysOldq=mIQYtvkRXSAweKoxjuWBCrgMysOldb
    mIQYtvkRXSAweKoxjuWBCrgMysOlqP ='tvshow' 
   mIQYtvkRXSAweKoxjuWBCrgMysOlqh={'mediatype':mIQYtvkRXSAweKoxjuWBCrgMysOlqP,'mpaa':mIQYtvkRXSAweKoxjuWBCrgMysOlqG,'title':mIQYtvkRXSAweKoxjuWBCrgMysOlDP,'year':mIQYtvkRXSAweKoxjuWBCrgMysOlqF,'duration':mIQYtvkRXSAweKoxjuWBCrgMysOlqc,'plot':mIQYtvkRXSAweKoxjuWBCrgMysOlqJ}
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP+='  (%s)'%(mIQYtvkRXSAweKoxjuWBCrgMysOlqF)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':mIQYtvkRXSAweKoxjuWBCrgMysOlqL,'movie_code':mIQYtvkRXSAweKoxjuWBCrgMysOldb,'page':'1','season_code':mIQYtvkRXSAweKoxjuWBCrgMysOldq,'title':mIQYtvkRXSAweKoxjuWBCrgMysOlDP,'thumbnail':mIQYtvkRXSAweKoxjuWBCrgMysOlbc}
   if mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_settings_makebookmark():
    mIQYtvkRXSAweKoxjuWBCrgMysOlqT={'videoid':mIQYtvkRXSAweKoxjuWBCrgMysOldb,'vidtype':'tvshow' if mIQYtvkRXSAweKoxjuWBCrgMysOlbN=='tv_seasons' else 'movie','vtitle':mIQYtvkRXSAweKoxjuWBCrgMysOlDP,'vsubtitle':'',}
    mIQYtvkRXSAweKoxjuWBCrgMysOlqz=json.dumps(mIQYtvkRXSAweKoxjuWBCrgMysOlqT)
    mIQYtvkRXSAweKoxjuWBCrgMysOlqz=urllib.parse.quote(mIQYtvkRXSAweKoxjuWBCrgMysOlqz)
    mIQYtvkRXSAweKoxjuWBCrgMysOlqf='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(mIQYtvkRXSAweKoxjuWBCrgMysOlqz)
    mIQYtvkRXSAweKoxjuWBCrgMysOlqV=[('(통합) 찜 영상에 추가',mIQYtvkRXSAweKoxjuWBCrgMysOlqf)]
   else:
    mIQYtvkRXSAweKoxjuWBCrgMysOlqV=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel=mIQYtvkRXSAweKoxjuWBCrgMysOlDH,img=mIQYtvkRXSAweKoxjuWBCrgMysOlbc,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlqh,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlDf,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz,ContextMenu=mIQYtvkRXSAweKoxjuWBCrgMysOlqV)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlqd:
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={}
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['mode'] ='SEARCH'
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['search_key']=mIQYtvkRXSAweKoxjuWBCrgMysOlpL
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz['page'] =mIQYtvkRXSAweKoxjuWBCrgMysOlFh(mIQYtvkRXSAweKoxjuWBCrgMysOlbh+1)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP='[B]%s >>[/B]'%'다음 페이지'
   mIQYtvkRXSAweKoxjuWBCrgMysOldD=mIQYtvkRXSAweKoxjuWBCrgMysOlFh(mIQYtvkRXSAweKoxjuWBCrgMysOlbh+1)
   mIQYtvkRXSAweKoxjuWBCrgMysOlDT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel=mIQYtvkRXSAweKoxjuWBCrgMysOldD,img=mIQYtvkRXSAweKoxjuWBCrgMysOlDT,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFN,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz)
  xbmcplugin.setContent(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,'movies')
  xbmcplugin.endOfDirectory(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,cacheToDisc=mIQYtvkRXSAweKoxjuWBCrgMysOlFN)
  if args.get('historyyn')=='Y':mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.Save_Searched_List(mIQYtvkRXSAweKoxjuWBCrgMysOlpL)
 def dp_Delete_Continue(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlpP=urllib.parse.unquote(args.get('bm_param'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlpP=mIQYtvkRXSAweKoxjuWBCrgMysOlpP.replace('\'','"')
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.addon_log(mIQYtvkRXSAweKoxjuWBCrgMysOlpP)
  mIQYtvkRXSAweKoxjuWBCrgMysOlpP=json.loads(mIQYtvkRXSAweKoxjuWBCrgMysOlpP)
  mIQYtvkRXSAweKoxjuWBCrgMysOlqD=mIQYtvkRXSAweKoxjuWBCrgMysOlpP.get('codeList')
  mIQYtvkRXSAweKoxjuWBCrgMysOlUc=xbmcgui.Dialog()
  mIQYtvkRXSAweKoxjuWBCrgMysOlbd=mIQYtvkRXSAweKoxjuWBCrgMysOlUc.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if mIQYtvkRXSAweKoxjuWBCrgMysOlbd==mIQYtvkRXSAweKoxjuWBCrgMysOlFG:sys.exit()
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.DeleteContinueList(mIQYtvkRXSAweKoxjuWBCrgMysOlqD)
  xbmc.executebuiltin("Container.Refresh")
 def dp_History_Remove(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlph=args.get('delType')
  mIQYtvkRXSAweKoxjuWBCrgMysOlpV =args.get('sKey')
  mIQYtvkRXSAweKoxjuWBCrgMysOlpT =args.get('vType')
  mIQYtvkRXSAweKoxjuWBCrgMysOlUc=xbmcgui.Dialog()
  if mIQYtvkRXSAweKoxjuWBCrgMysOlph=='SEARCH_ALL':
   mIQYtvkRXSAweKoxjuWBCrgMysOlbd=mIQYtvkRXSAweKoxjuWBCrgMysOlUc.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlph=='SEARCH_ONE':
   mIQYtvkRXSAweKoxjuWBCrgMysOlbd=mIQYtvkRXSAweKoxjuWBCrgMysOlUc.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlph=='WATCH_ALL':
   mIQYtvkRXSAweKoxjuWBCrgMysOlbd=mIQYtvkRXSAweKoxjuWBCrgMysOlUc.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlph=='WATCH_ONE':
   mIQYtvkRXSAweKoxjuWBCrgMysOlbd=mIQYtvkRXSAweKoxjuWBCrgMysOlUc.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if mIQYtvkRXSAweKoxjuWBCrgMysOlbd==mIQYtvkRXSAweKoxjuWBCrgMysOlFG:sys.exit()
  if mIQYtvkRXSAweKoxjuWBCrgMysOlph=='SEARCH_ALL':
   if os.path.isfile(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_SEARCHEDC_FILENAME):os.remove(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_SEARCHEDC_FILENAME)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlph=='SEARCH_ONE':
   try:
    mIQYtvkRXSAweKoxjuWBCrgMysOlpz=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_SEARCHEDC_FILENAME
    mIQYtvkRXSAweKoxjuWBCrgMysOlpf=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.Load_List_File('search') 
    fp=mIQYtvkRXSAweKoxjuWBCrgMysOlFV(mIQYtvkRXSAweKoxjuWBCrgMysOlpz,'w',-1,'utf-8')
    for mIQYtvkRXSAweKoxjuWBCrgMysOlpi in mIQYtvkRXSAweKoxjuWBCrgMysOlpf:
     mIQYtvkRXSAweKoxjuWBCrgMysOlpH=mIQYtvkRXSAweKoxjuWBCrgMysOlFa(urllib.parse.parse_qsl(mIQYtvkRXSAweKoxjuWBCrgMysOlpi))
     mIQYtvkRXSAweKoxjuWBCrgMysOlpn=mIQYtvkRXSAweKoxjuWBCrgMysOlpH.get('skey').strip()
     if mIQYtvkRXSAweKoxjuWBCrgMysOlpV!=mIQYtvkRXSAweKoxjuWBCrgMysOlpn:
      fp.write(mIQYtvkRXSAweKoxjuWBCrgMysOlpi)
    fp.close()
   except:
    mIQYtvkRXSAweKoxjuWBCrgMysOlFJ
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlph=='WATCH_ALL':
   mIQYtvkRXSAweKoxjuWBCrgMysOlpz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mIQYtvkRXSAweKoxjuWBCrgMysOlpT))
   if os.path.isfile(mIQYtvkRXSAweKoxjuWBCrgMysOlpz):os.remove(mIQYtvkRXSAweKoxjuWBCrgMysOlpz)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlph=='WATCH_ONE':
   mIQYtvkRXSAweKoxjuWBCrgMysOlpz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mIQYtvkRXSAweKoxjuWBCrgMysOlpT))
   try:
    mIQYtvkRXSAweKoxjuWBCrgMysOlpf=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.Load_List_File(mIQYtvkRXSAweKoxjuWBCrgMysOlpT) 
    fp=mIQYtvkRXSAweKoxjuWBCrgMysOlFV(mIQYtvkRXSAweKoxjuWBCrgMysOlpz,'w',-1,'utf-8')
    for mIQYtvkRXSAweKoxjuWBCrgMysOlpi in mIQYtvkRXSAweKoxjuWBCrgMysOlpf:
     mIQYtvkRXSAweKoxjuWBCrgMysOlpH=mIQYtvkRXSAweKoxjuWBCrgMysOlFa(urllib.parse.parse_qsl(mIQYtvkRXSAweKoxjuWBCrgMysOlpi))
     mIQYtvkRXSAweKoxjuWBCrgMysOlpn=mIQYtvkRXSAweKoxjuWBCrgMysOlpH.get('code').strip()
     if mIQYtvkRXSAweKoxjuWBCrgMysOlpV!=mIQYtvkRXSAweKoxjuWBCrgMysOlpn:
      fp.write(mIQYtvkRXSAweKoxjuWBCrgMysOlpi)
    fp.close()
   except:
    mIQYtvkRXSAweKoxjuWBCrgMysOlFJ
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,mIQYtvkRXSAweKoxjuWBCrgMysOlbP): 
  try:
   if mIQYtvkRXSAweKoxjuWBCrgMysOlbP=='search':
    mIQYtvkRXSAweKoxjuWBCrgMysOlpz=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_SEARCHEDC_FILENAME
   elif mIQYtvkRXSAweKoxjuWBCrgMysOlbP in['seasons','movie']:
    mIQYtvkRXSAweKoxjuWBCrgMysOlpz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mIQYtvkRXSAweKoxjuWBCrgMysOlbP))
   else:
    return[]
   fp=mIQYtvkRXSAweKoxjuWBCrgMysOlFV(mIQYtvkRXSAweKoxjuWBCrgMysOlpz,'r',-1,'utf-8')
   mIQYtvkRXSAweKoxjuWBCrgMysOlJU=fp.readlines()
   fp.close()
  except:
   mIQYtvkRXSAweKoxjuWBCrgMysOlJU=[]
  return mIQYtvkRXSAweKoxjuWBCrgMysOlJU
 def Save_Watched_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,mIQYtvkRXSAweKoxjuWBCrgMysOlbP,mIQYtvkRXSAweKoxjuWBCrgMysOlUN):
  try:
   mIQYtvkRXSAweKoxjuWBCrgMysOlJD=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%mIQYtvkRXSAweKoxjuWBCrgMysOlbP))
   mIQYtvkRXSAweKoxjuWBCrgMysOlpf=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.Load_List_File(mIQYtvkRXSAweKoxjuWBCrgMysOlbP) 
   fp=mIQYtvkRXSAweKoxjuWBCrgMysOlFV(mIQYtvkRXSAweKoxjuWBCrgMysOlJD,'w',-1,'utf-8')
   mIQYtvkRXSAweKoxjuWBCrgMysOlJb=urllib.parse.urlencode(mIQYtvkRXSAweKoxjuWBCrgMysOlUN)
   mIQYtvkRXSAweKoxjuWBCrgMysOlJb=mIQYtvkRXSAweKoxjuWBCrgMysOlJb+'\n'
   fp.write(mIQYtvkRXSAweKoxjuWBCrgMysOlJb)
   mIQYtvkRXSAweKoxjuWBCrgMysOlJd=0
   for mIQYtvkRXSAweKoxjuWBCrgMysOlpi in mIQYtvkRXSAweKoxjuWBCrgMysOlpf:
    mIQYtvkRXSAweKoxjuWBCrgMysOlpH=mIQYtvkRXSAweKoxjuWBCrgMysOlFa(urllib.parse.parse_qsl(mIQYtvkRXSAweKoxjuWBCrgMysOlpi))
    mIQYtvkRXSAweKoxjuWBCrgMysOlJq=mIQYtvkRXSAweKoxjuWBCrgMysOlUN.get('code').strip()
    mIQYtvkRXSAweKoxjuWBCrgMysOlJp=mIQYtvkRXSAweKoxjuWBCrgMysOlpH.get('code').strip()
    if mIQYtvkRXSAweKoxjuWBCrgMysOlbP=='seasons' and mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_settings_direct_replay()==mIQYtvkRXSAweKoxjuWBCrgMysOlFN:
     mIQYtvkRXSAweKoxjuWBCrgMysOlJq=mIQYtvkRXSAweKoxjuWBCrgMysOlUN.get('videoid').strip()
     mIQYtvkRXSAweKoxjuWBCrgMysOlJp=mIQYtvkRXSAweKoxjuWBCrgMysOlpH.get('videoid').strip()if mIQYtvkRXSAweKoxjuWBCrgMysOlJp!=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ else '-'
    if mIQYtvkRXSAweKoxjuWBCrgMysOlJq!=mIQYtvkRXSAweKoxjuWBCrgMysOlJp:
     fp.write(mIQYtvkRXSAweKoxjuWBCrgMysOlpi)
     mIQYtvkRXSAweKoxjuWBCrgMysOlJd+=1
     if mIQYtvkRXSAweKoxjuWBCrgMysOlJd>=50:break
   fp.close()
  except:
   mIQYtvkRXSAweKoxjuWBCrgMysOlFJ
 def dp_Watch_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlbP =args.get('stype')
  mIQYtvkRXSAweKoxjuWBCrgMysOlDc=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_settings_direct_replay()
  if mIQYtvkRXSAweKoxjuWBCrgMysOlbP=='-':
   for mIQYtvkRXSAweKoxjuWBCrgMysOlJF in mIQYtvkRXSAweKoxjuWBCrgMysOlUd:
    mIQYtvkRXSAweKoxjuWBCrgMysOlDP=mIQYtvkRXSAweKoxjuWBCrgMysOlJF.get('title')
    mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':mIQYtvkRXSAweKoxjuWBCrgMysOlJF.get('mode'),'stype':mIQYtvkRXSAweKoxjuWBCrgMysOlJF.get('stype')}
    mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel='',img='',infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlFJ,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFN,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz)
   if mIQYtvkRXSAweKoxjuWBCrgMysOlFL(mIQYtvkRXSAweKoxjuWBCrgMysOlUd)>0:xbmcplugin.endOfDirectory(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle)
  else:
   mIQYtvkRXSAweKoxjuWBCrgMysOlJE=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.Load_List_File(mIQYtvkRXSAweKoxjuWBCrgMysOlbP)
   for mIQYtvkRXSAweKoxjuWBCrgMysOlJN in mIQYtvkRXSAweKoxjuWBCrgMysOlJE:
    mIQYtvkRXSAweKoxjuWBCrgMysOlpN=mIQYtvkRXSAweKoxjuWBCrgMysOlFa(urllib.parse.parse_qsl(mIQYtvkRXSAweKoxjuWBCrgMysOlJN))
    mIQYtvkRXSAweKoxjuWBCrgMysOldb=mIQYtvkRXSAweKoxjuWBCrgMysOlpN.get('code').strip()
    mIQYtvkRXSAweKoxjuWBCrgMysOlDP =mIQYtvkRXSAweKoxjuWBCrgMysOlpN.get('title').strip()
    mIQYtvkRXSAweKoxjuWBCrgMysOlbc =mIQYtvkRXSAweKoxjuWBCrgMysOlpN.get('img').strip()
    mIQYtvkRXSAweKoxjuWBCrgMysOlJG =mIQYtvkRXSAweKoxjuWBCrgMysOlpN.get('videoid').strip()
    try:
     mIQYtvkRXSAweKoxjuWBCrgMysOlbc=mIQYtvkRXSAweKoxjuWBCrgMysOlbc.replace('\'','\"')
     mIQYtvkRXSAweKoxjuWBCrgMysOlbc=json.loads(mIQYtvkRXSAweKoxjuWBCrgMysOlbc)
    except:
     mIQYtvkRXSAweKoxjuWBCrgMysOlFJ
    mIQYtvkRXSAweKoxjuWBCrgMysOlqh={}
    mIQYtvkRXSAweKoxjuWBCrgMysOlqh['plot']=mIQYtvkRXSAweKoxjuWBCrgMysOlDP
    if mIQYtvkRXSAweKoxjuWBCrgMysOlbP=='movie':
     mIQYtvkRXSAweKoxjuWBCrgMysOlqh['mediatype']='movie'
     mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'MOVIE','page':'1','movie_code':mIQYtvkRXSAweKoxjuWBCrgMysOldb,'season_code':'-','title':mIQYtvkRXSAweKoxjuWBCrgMysOlDP,'thumbnail':mIQYtvkRXSAweKoxjuWBCrgMysOlbc}
     mIQYtvkRXSAweKoxjuWBCrgMysOlDf=mIQYtvkRXSAweKoxjuWBCrgMysOlFG
    else:
     if mIQYtvkRXSAweKoxjuWBCrgMysOlDc==mIQYtvkRXSAweKoxjuWBCrgMysOlFG or mIQYtvkRXSAweKoxjuWBCrgMysOlJG==mIQYtvkRXSAweKoxjuWBCrgMysOlFJ:
      mIQYtvkRXSAweKoxjuWBCrgMysOlqh['mediatype']='tvshow'
      mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'EPISODE','page':'1','movie_code':mIQYtvkRXSAweKoxjuWBCrgMysOldb,'season_code':mIQYtvkRXSAweKoxjuWBCrgMysOldb,'title':mIQYtvkRXSAweKoxjuWBCrgMysOlDP,'thumbnail':mIQYtvkRXSAweKoxjuWBCrgMysOlbc}
      mIQYtvkRXSAweKoxjuWBCrgMysOlDf=mIQYtvkRXSAweKoxjuWBCrgMysOlFN
     else:
      mIQYtvkRXSAweKoxjuWBCrgMysOlqh['mediatype']='episode'
      mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'MOVIE','movie_code':mIQYtvkRXSAweKoxjuWBCrgMysOlJG,'season_code':mIQYtvkRXSAweKoxjuWBCrgMysOldb,'title':mIQYtvkRXSAweKoxjuWBCrgMysOlDP,'thumbnail':mIQYtvkRXSAweKoxjuWBCrgMysOlbc}
      mIQYtvkRXSAweKoxjuWBCrgMysOlDf=mIQYtvkRXSAweKoxjuWBCrgMysOlFG
    mIQYtvkRXSAweKoxjuWBCrgMysOlpc={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':mIQYtvkRXSAweKoxjuWBCrgMysOldb,'vType':mIQYtvkRXSAweKoxjuWBCrgMysOlbP,}
    mIQYtvkRXSAweKoxjuWBCrgMysOlpa=urllib.parse.urlencode(mIQYtvkRXSAweKoxjuWBCrgMysOlpc)
    mIQYtvkRXSAweKoxjuWBCrgMysOlqV=[('선택된 시청이력 ( %s ) 삭제'%(mIQYtvkRXSAweKoxjuWBCrgMysOlDP),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(mIQYtvkRXSAweKoxjuWBCrgMysOlpa))]
    mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel='',img=mIQYtvkRXSAweKoxjuWBCrgMysOlbc,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlqh,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlDf,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz,ContextMenu=mIQYtvkRXSAweKoxjuWBCrgMysOlqV)
   mIQYtvkRXSAweKoxjuWBCrgMysOlqh={'plot':'시청목록을 삭제합니다.'}
   mIQYtvkRXSAweKoxjuWBCrgMysOlDP='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   mIQYtvkRXSAweKoxjuWBCrgMysOlDz={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':mIQYtvkRXSAweKoxjuWBCrgMysOlbP,}
   mIQYtvkRXSAweKoxjuWBCrgMysOlDT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.add_dir(mIQYtvkRXSAweKoxjuWBCrgMysOlDP,sublabel='',img=mIQYtvkRXSAweKoxjuWBCrgMysOlDT,infoLabels=mIQYtvkRXSAweKoxjuWBCrgMysOlqh,isFolder=mIQYtvkRXSAweKoxjuWBCrgMysOlFG,params=mIQYtvkRXSAweKoxjuWBCrgMysOlDz,isLink=mIQYtvkRXSAweKoxjuWBCrgMysOlFN)
   if mIQYtvkRXSAweKoxjuWBCrgMysOlbP=='movie':xbmcplugin.setContent(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,'movies')
   else:xbmcplugin.setContent(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ._addon_handle,cacheToDisc=mIQYtvkRXSAweKoxjuWBCrgMysOlFG)
 def Save_Searched_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,mIQYtvkRXSAweKoxjuWBCrgMysOlpL):
  try:
   mIQYtvkRXSAweKoxjuWBCrgMysOlJc=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_SEARCHEDC_FILENAME
   mIQYtvkRXSAweKoxjuWBCrgMysOlpf=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.Load_List_File('search') 
   mIQYtvkRXSAweKoxjuWBCrgMysOlJa={'skey':mIQYtvkRXSAweKoxjuWBCrgMysOlpL.strip()}
   fp=mIQYtvkRXSAweKoxjuWBCrgMysOlFV(mIQYtvkRXSAweKoxjuWBCrgMysOlJc,'w',-1,'utf-8')
   mIQYtvkRXSAweKoxjuWBCrgMysOlJb=urllib.parse.urlencode(mIQYtvkRXSAweKoxjuWBCrgMysOlJa)
   mIQYtvkRXSAweKoxjuWBCrgMysOlJb=mIQYtvkRXSAweKoxjuWBCrgMysOlJb+'\n'
   fp.write(mIQYtvkRXSAweKoxjuWBCrgMysOlJb)
   mIQYtvkRXSAweKoxjuWBCrgMysOlJd=0
   for mIQYtvkRXSAweKoxjuWBCrgMysOlpi in mIQYtvkRXSAweKoxjuWBCrgMysOlpf:
    mIQYtvkRXSAweKoxjuWBCrgMysOlpH=mIQYtvkRXSAweKoxjuWBCrgMysOlFa(urllib.parse.parse_qsl(mIQYtvkRXSAweKoxjuWBCrgMysOlpi))
    mIQYtvkRXSAweKoxjuWBCrgMysOlJq=mIQYtvkRXSAweKoxjuWBCrgMysOlJa.get('skey').strip()
    mIQYtvkRXSAweKoxjuWBCrgMysOlJp=mIQYtvkRXSAweKoxjuWBCrgMysOlpH.get('skey').strip()
    if mIQYtvkRXSAweKoxjuWBCrgMysOlJq!=mIQYtvkRXSAweKoxjuWBCrgMysOlJp:
     fp.write(mIQYtvkRXSAweKoxjuWBCrgMysOlpi)
     mIQYtvkRXSAweKoxjuWBCrgMysOlJd+=1
     if mIQYtvkRXSAweKoxjuWBCrgMysOlJd>=50:break
   fp.close()
  except:
   mIQYtvkRXSAweKoxjuWBCrgMysOlFJ
 def logout(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  mIQYtvkRXSAweKoxjuWBCrgMysOlUc=xbmcgui.Dialog()
  mIQYtvkRXSAweKoxjuWBCrgMysOlbd=mIQYtvkRXSAweKoxjuWBCrgMysOlUc.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if mIQYtvkRXSAweKoxjuWBCrgMysOlbd==mIQYtvkRXSAweKoxjuWBCrgMysOlFG:sys.exit()
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.Init_WC_Total()
  if os.path.isfile(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_COOKIE_FILENAME):os.remove(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_COOKIE_FILENAME)
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  mIQYtvkRXSAweKoxjuWBCrgMysOlJL =mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.Get_Now_Datetime()
  mIQYtvkRXSAweKoxjuWBCrgMysOlJP=mIQYtvkRXSAweKoxjuWBCrgMysOlJL+datetime.timedelta(days=mIQYtvkRXSAweKoxjuWBCrgMysOlFE(__addon__.getSetting('cache_ttl')))
  (mIQYtvkRXSAweKoxjuWBCrgMysOlDn,mIQYtvkRXSAweKoxjuWBCrgMysOlbU,mIQYtvkRXSAweKoxjuWBCrgMysOlbD)=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_settings_account()
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.Save_session_acount(mIQYtvkRXSAweKoxjuWBCrgMysOlDn,mIQYtvkRXSAweKoxjuWBCrgMysOlbU,mIQYtvkRXSAweKoxjuWBCrgMysOlbD)
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC['account']['token_limit']=mIQYtvkRXSAweKoxjuWBCrgMysOlJP.strftime('%Y%m%d')
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.JsonFile_Save(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_COOKIE_FILENAME,mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC)
 def cookiefile_check(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.JsonFile_Load(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC_COOKIE_FILENAME)
  if 'account' not in mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC:
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.Init_WC_Total()
   return mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  if 'deviceId2' not in mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC['cookies']:
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.Init_WC_Total()
   return mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  (mIQYtvkRXSAweKoxjuWBCrgMysOlJh,mIQYtvkRXSAweKoxjuWBCrgMysOlJV,mIQYtvkRXSAweKoxjuWBCrgMysOlJT)=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.get_settings_account()
  (mIQYtvkRXSAweKoxjuWBCrgMysOlJz,mIQYtvkRXSAweKoxjuWBCrgMysOlJf,mIQYtvkRXSAweKoxjuWBCrgMysOlJi)=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.Load_session_acount()
  if mIQYtvkRXSAweKoxjuWBCrgMysOlJh!=mIQYtvkRXSAweKoxjuWBCrgMysOlJz or mIQYtvkRXSAweKoxjuWBCrgMysOlJV!=mIQYtvkRXSAweKoxjuWBCrgMysOlJf or mIQYtvkRXSAweKoxjuWBCrgMysOlJT!=mIQYtvkRXSAweKoxjuWBCrgMysOlJi:
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.Init_WC_Total()
   return mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  if mIQYtvkRXSAweKoxjuWBCrgMysOlFE(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))>mIQYtvkRXSAweKoxjuWBCrgMysOlFE(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.WC['account']['token_limit']):
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.Init_WC_Total()
   return mIQYtvkRXSAweKoxjuWBCrgMysOlFG
  return mIQYtvkRXSAweKoxjuWBCrgMysOlFN
 def dp_Global_Search(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlJH=args.get('mode')
  if mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='TOTAL_SEARCH':
   mIQYtvkRXSAweKoxjuWBCrgMysOlJn='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   mIQYtvkRXSAweKoxjuWBCrgMysOlJn='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(mIQYtvkRXSAweKoxjuWBCrgMysOlJn)
 def dp_Bookmark_Menu(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlJn='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(mIQYtvkRXSAweKoxjuWBCrgMysOlJn)
 def dp_Set_Bookmark(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ,args):
  mIQYtvkRXSAweKoxjuWBCrgMysOlpP=urllib.parse.unquote(args.get('bm_param'))
  mIQYtvkRXSAweKoxjuWBCrgMysOlpP=json.loads(mIQYtvkRXSAweKoxjuWBCrgMysOlpP)
  mIQYtvkRXSAweKoxjuWBCrgMysOlJG =mIQYtvkRXSAweKoxjuWBCrgMysOlpP.get('videoid')
  mIQYtvkRXSAweKoxjuWBCrgMysOlFU =mIQYtvkRXSAweKoxjuWBCrgMysOlpP.get('vidtype')
  mIQYtvkRXSAweKoxjuWBCrgMysOlFD =mIQYtvkRXSAweKoxjuWBCrgMysOlpP.get('vtitle')
  mIQYtvkRXSAweKoxjuWBCrgMysOlFb =mIQYtvkRXSAweKoxjuWBCrgMysOlpP.get('vsubtitle')
  mIQYtvkRXSAweKoxjuWBCrgMysOlUc=xbmcgui.Dialog()
  mIQYtvkRXSAweKoxjuWBCrgMysOlbd=mIQYtvkRXSAweKoxjuWBCrgMysOlUc.yesno(__language__(30913).encode('utf8'),mIQYtvkRXSAweKoxjuWBCrgMysOlFD+' \n\n'+__language__(30914))
  if mIQYtvkRXSAweKoxjuWBCrgMysOlbd==mIQYtvkRXSAweKoxjuWBCrgMysOlFG:return
  mIQYtvkRXSAweKoxjuWBCrgMysOlFd=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.WatchaObj.GetBookmarkInfo(mIQYtvkRXSAweKoxjuWBCrgMysOlJG,mIQYtvkRXSAweKoxjuWBCrgMysOlFU)
  mIQYtvkRXSAweKoxjuWBCrgMysOlFq=json.dumps(mIQYtvkRXSAweKoxjuWBCrgMysOlFd)
  mIQYtvkRXSAweKoxjuWBCrgMysOlFq=urllib.parse.quote(mIQYtvkRXSAweKoxjuWBCrgMysOlFq)
  mIQYtvkRXSAweKoxjuWBCrgMysOlqf ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(mIQYtvkRXSAweKoxjuWBCrgMysOlFq)
  xbmc.executebuiltin(mIQYtvkRXSAweKoxjuWBCrgMysOlqf)
 def watcha_main(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ):
  mIQYtvkRXSAweKoxjuWBCrgMysOlJH=mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params.get('mode',mIQYtvkRXSAweKoxjuWBCrgMysOlFJ)
  if mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='LOGOUT':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.logout()
   return
  mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.login_main()
  if mIQYtvkRXSAweKoxjuWBCrgMysOlJH is mIQYtvkRXSAweKoxjuWBCrgMysOlFJ:
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Main_List()
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='HOME_GROUP':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_HomeGroup_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='SUB_GROUP':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_SubGroup_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='CATEGORY_LIST':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Category_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='SEASON':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Season_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='EPISODE':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Episode_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='ORDER_BY':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_setEpOrderby(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH in['SEARCH','LOCAL_SEARCH']:
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Search_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='MOVIE':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.play_VIDEO(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='WATCH':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Watch_List(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_History_Remove(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH in['TOTAL_SEARCH','TOTAL_HISTORY']:
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Global_Search(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='SEARCH_HISTORY':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Search_History(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='MENU_BOOKMARK':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Bookmark_Menu(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='SET_BOOKMARK':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Set_Bookmark(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  elif mIQYtvkRXSAweKoxjuWBCrgMysOlJH=='DELETE_CONTINUE':
   mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.dp_Delete_Continue(mIQYtvkRXSAweKoxjuWBCrgMysOlUJ.main_params)
  else:
   mIQYtvkRXSAweKoxjuWBCrgMysOlFJ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
