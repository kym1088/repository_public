import threading
LROEXFtjKrqGwmWiSYAQyfuMNhogcx=IOError
LROEXFtjKrqGwmWiSYAQyfuMNhogse=OSError
LROEXFtjKrqGwmWiSYAQyfuMNhogsc=dict
LROEXFtjKrqGwmWiSYAQyfuMNhogsP=print
LROEXFtjKrqGwmWiSYAQyfuMNhogsz=len
LROEXFtjKrqGwmWiSYAQyfuMNhogsl=int
LROEXFtjKrqGwmWiSYAQyfuMNhogsD=None
LROEXFtjKrqGwmWiSYAQyfuMNhogsd=Exception
LROEXFtjKrqGwmWiSYAQyfuMNhogsa=False
LROEXFtjKrqGwmWiSYAQyfuMNhogsp=True
LROEXFtjKrqGwmWiSYAQyfuMNhogsv=list
LROEXFtjKrqGwmWiSYAQyfuMNhogsn=str
LROEXFtjKrqGwmWiSYAQyfuMNhogsH=open
LROEXFtjKrqGwmWiSYAQyfuMNhogsI=object
from http.server import HTTPServer,BaseHTTPRequestHandler
import requests
import urllib
import json
import base64
import re
import xml.etree.ElementTree as ET
import io
import os
import xml.dom.minidom
LROEXFtjKrqGwmWiSYAQyfuMNhogeP =['proxy-mini','host','referer','upgrade']
LROEXFtjKrqGwmWiSYAQyfuMNhogez=['date','server','set-cookie','keep-alive','connection','transfer-encoding','content-encoding','content-length']
LROEXFtjKrqGwmWiSYAQyfuMNhogel={'-':0,'2CH':1,'6CH':2,'ATMOS':3,}
class LROEXFtjKrqGwmWiSYAQyfuMNhogcJ(BaseHTTPRequestHandler):
 def __init__(LROEXFtjKrqGwmWiSYAQyfuMNhogeD,request,client_address,server):
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.HTTP_CLIENT=requests.Session()
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO ={}
  try:
   BaseHTTPRequestHandler.__init__(LROEXFtjKrqGwmWiSYAQyfuMNhogeD,request,client_address,server)
  except(LROEXFtjKrqGwmWiSYAQyfuMNhogcx,LROEXFtjKrqGwmWiSYAQyfuMNhogse)as e:
   pass
 def Make_Header(LROEXFtjKrqGwmWiSYAQyfuMNhogeD,header_exceptList=[]):
  LROEXFtjKrqGwmWiSYAQyfuMNhoged={}
  header_exceptList.extend(LROEXFtjKrqGwmWiSYAQyfuMNhogeP)
  for LROEXFtjKrqGwmWiSYAQyfuMNhogea,value in LROEXFtjKrqGwmWiSYAQyfuMNhogsc(LROEXFtjKrqGwmWiSYAQyfuMNhogeD.headers).items():
   if LROEXFtjKrqGwmWiSYAQyfuMNhogea.lower()not in header_exceptList:
    LROEXFtjKrqGwmWiSYAQyfuMNhoged[LROEXFtjKrqGwmWiSYAQyfuMNhogea.lower()]=value
  return LROEXFtjKrqGwmWiSYAQyfuMNhoged
 def Make_NewUrl(LROEXFtjKrqGwmWiSYAQyfuMNhogeD,scheme,netloc,path,params='',query='',fragemnt=''):
  LROEXFtjKrqGwmWiSYAQyfuMNhogep=(scheme,netloc,path,params,query,fragemnt)
  return urllib.parse.urlunparse(LROEXFtjKrqGwmWiSYAQyfuMNhogep)
 def Send_BlankImage(LROEXFtjKrqGwmWiSYAQyfuMNhogeD):
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.send_response(200)
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.send_header('Content-Type','image/x-icon')
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.send_header('Content-Length',0)
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.end_headers()
 def Send_ErrorPage(LROEXFtjKrqGwmWiSYAQyfuMNhogeD):
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.send_response(200)
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.send_header('Content-Type','text/html; charset=UTF-8')
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.end_headers()
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.wfile.write('request error!'.encode('utf-8'))
 def Parse_BaseRequest(LROEXFtjKrqGwmWiSYAQyfuMNhogeD):
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO={}
  try:
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['url'] =LROEXFtjKrqGwmWiSYAQyfuMNhogeD.path.strip('/')
   LROEXFtjKrqGwmWiSYAQyfuMNhogev=LROEXFtjKrqGwmWiSYAQyfuMNhogsc(LROEXFtjKrqGwmWiSYAQyfuMNhogeD.headers).get('proxy-mini')
   if LROEXFtjKrqGwmWiSYAQyfuMNhogev:
    LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['addon']=json.loads(base64.standard_b64decode(LROEXFtjKrqGwmWiSYAQyfuMNhogev).decode('utf-8'))
   else:
    LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['addon']={}
   LROEXFtjKrqGwmWiSYAQyfuMNhogsP(LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['addon'])
   LROEXFtjKrqGwmWiSYAQyfuMNhogen=urllib.parse.urlparse(LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['url']) 
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['scheme'] =LROEXFtjKrqGwmWiSYAQyfuMNhogen.scheme
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['netloc'] =LROEXFtjKrqGwmWiSYAQyfuMNhogen.netloc
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['path'] =LROEXFtjKrqGwmWiSYAQyfuMNhogen.path.strip('/').split('/')
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['last_path']=LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['path'][LROEXFtjKrqGwmWiSYAQyfuMNhogsz(LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['path'])-1]
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['query'] =LROEXFtjKrqGwmWiSYAQyfuMNhogsc(urllib.parse.parse_qsl(LROEXFtjKrqGwmWiSYAQyfuMNhogen.query))
   LROEXFtjKrqGwmWiSYAQyfuMNhogeH=LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['last_path'].split('.')
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['last_type']=LROEXFtjKrqGwmWiSYAQyfuMNhogeH[LROEXFtjKrqGwmWiSYAQyfuMNhogsz(LROEXFtjKrqGwmWiSYAQyfuMNhogeH)-1]
   LROEXFtjKrqGwmWiSYAQyfuMNhogeI=LROEXFtjKrqGwmWiSYAQyfuMNhogsl(LROEXFtjKrqGwmWiSYAQyfuMNhogeD.headers.get('content-length',0))
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['postData']=LROEXFtjKrqGwmWiSYAQyfuMNhogeD.rfile.read(LROEXFtjKrqGwmWiSYAQyfuMNhogeI)if LROEXFtjKrqGwmWiSYAQyfuMNhogeI else LROEXFtjKrqGwmWiSYAQyfuMNhogsD
  except LROEXFtjKrqGwmWiSYAQyfuMNhogsd as e:
   LROEXFtjKrqGwmWiSYAQyfuMNhogsP(LROEXFtjKrqGwmWiSYAQyfuMNhogsd)
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO={}
   return LROEXFtjKrqGwmWiSYAQyfuMNhogsa
  return LROEXFtjKrqGwmWiSYAQyfuMNhogsp
 def Output_Headers(LROEXFtjKrqGwmWiSYAQyfuMNhogeD,LROEXFtjKrqGwmWiSYAQyfuMNhogeC):
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.send_response(LROEXFtjKrqGwmWiSYAQyfuMNhogeC.status_code)
  for LROEXFtjKrqGwmWiSYAQyfuMNhogeT in LROEXFtjKrqGwmWiSYAQyfuMNhogsv(LROEXFtjKrqGwmWiSYAQyfuMNhogeC.headers.items()):
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.send_header(LROEXFtjKrqGwmWiSYAQyfuMNhogeT[0],LROEXFtjKrqGwmWiSYAQyfuMNhogeT[1])
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.end_headers()
 def Output_Response(LROEXFtjKrqGwmWiSYAQyfuMNhogeD,LROEXFtjKrqGwmWiSYAQyfuMNhogeC,res_data=LROEXFtjKrqGwmWiSYAQyfuMNhogsD,header_exceptList=[]):
  for LROEXFtjKrqGwmWiSYAQyfuMNhogeT in LROEXFtjKrqGwmWiSYAQyfuMNhogsv(LROEXFtjKrqGwmWiSYAQyfuMNhogeC.headers.items()):
   if LROEXFtjKrqGwmWiSYAQyfuMNhogeT[0].lower()in LROEXFtjKrqGwmWiSYAQyfuMNhogez or LROEXFtjKrqGwmWiSYAQyfuMNhogeT[0].lower()in header_exceptList:
    LROEXFtjKrqGwmWiSYAQyfuMNhogeC.headers.pop(LROEXFtjKrqGwmWiSYAQyfuMNhogeT[0],LROEXFtjKrqGwmWiSYAQyfuMNhogsD)
  if res_data:
   LROEXFtjKrqGwmWiSYAQyfuMNhogeV=res_data.encode('utf-8')
   LROEXFtjKrqGwmWiSYAQyfuMNhogeC.headers['content-length'] =LROEXFtjKrqGwmWiSYAQyfuMNhogsn(LROEXFtjKrqGwmWiSYAQyfuMNhogsz(LROEXFtjKrqGwmWiSYAQyfuMNhogeV))
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Output_Headers(LROEXFtjKrqGwmWiSYAQyfuMNhogeC)
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.wfile.write(LROEXFtjKrqGwmWiSYAQyfuMNhogeV)
  else:
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Output_Headers(LROEXFtjKrqGwmWiSYAQyfuMNhogeC)
   for LROEXFtjKrqGwmWiSYAQyfuMNhogeU in LROEXFtjKrqGwmWiSYAQyfuMNhogeC.iter_content(1048576):
    try:
     LROEXFtjKrqGwmWiSYAQyfuMNhogeD.wfile.write(LROEXFtjKrqGwmWiSYAQyfuMNhogeU)
    except LROEXFtjKrqGwmWiSYAQyfuMNhogsd as e:
     LROEXFtjKrqGwmWiSYAQyfuMNhogsP(e)
     break
 def do_HEAD(LROEXFtjKrqGwmWiSYAQyfuMNhogeD):
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.send_response(200)
 def do_POST(LROEXFtjKrqGwmWiSYAQyfuMNhogeD):
  if LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Parse_BaseRequest()==LROEXFtjKrqGwmWiSYAQyfuMNhogsa:
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.send_response(404)
   return 
  try:
   LROEXFtjKrqGwmWiSYAQyfuMNhogeC=requests.post(url=LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['url'],headers=LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Make_Header(),data=LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['postData'],stream=LROEXFtjKrqGwmWiSYAQyfuMNhogsp)
  except LROEXFtjKrqGwmWiSYAQyfuMNhogsd as exception:
   LROEXFtjKrqGwmWiSYAQyfuMNhogsP(exception)
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Send_ErrorPage()
   return
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Output_Response(LROEXFtjKrqGwmWiSYAQyfuMNhogeC,res_data=LROEXFtjKrqGwmWiSYAQyfuMNhogsD,header_exceptList=[])
 def do_GET(LROEXFtjKrqGwmWiSYAQyfuMNhogeD):
  if LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Parse_BaseRequest()==LROEXFtjKrqGwmWiSYAQyfuMNhogsa:
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.send_response(404)
   return 
  if LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['last_path'].lower()=='favicon.ico':
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Send_BlankImage()
   return 
  if LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['scheme'].lower()not in['http','https']:
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.send_response(404)
   return 
  try:
   LROEXFtjKrqGwmWiSYAQyfuMNhogeC=requests.get(url=LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['url'],headers=LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Make_Header(),stream=LROEXFtjKrqGwmWiSYAQyfuMNhogsp)
  except LROEXFtjKrqGwmWiSYAQyfuMNhogsd as exception:
   LROEXFtjKrqGwmWiSYAQyfuMNhogsP(exception)
   LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Send_ErrorPage()
   return
  LROEXFtjKrqGwmWiSYAQyfuMNhogeJ=LROEXFtjKrqGwmWiSYAQyfuMNhogsD
  if LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['last_type'].lower()in['mpd']and LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO.get('addon').get('addon')=='watcham':
   LROEXFtjKrqGwmWiSYAQyfuMNhogeB=LROEXFtjKrqGwmWiSYAQyfuMNhogeC.content.decode('utf-8')
   LROEXFtjKrqGwmWiSYAQyfuMNhogeJ=LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Watcha_Parse_mpd(LROEXFtjKrqGwmWiSYAQyfuMNhogeB)
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.Output_Response(LROEXFtjKrqGwmWiSYAQyfuMNhogeC,LROEXFtjKrqGwmWiSYAQyfuMNhogeJ,header_exceptList=[])
 def Watcha_Parse_mpd(LROEXFtjKrqGwmWiSYAQyfuMNhogeD,LROEXFtjKrqGwmWiSYAQyfuMNhogeB):
  LROEXFtjKrqGwmWiSYAQyfuMNhogek={'width':0,'bandwidth':0,}
  LROEXFtjKrqGwmWiSYAQyfuMNhogex=0
  LROEXFtjKrqGwmWiSYAQyfuMNhogce=LROEXFtjKrqGwmWiSYAQyfuMNhogel[LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['addon']['playOption']['sel_sound']] 
  LROEXFtjKrqGwmWiSYAQyfuMNhogcs =ET.ElementTree(ET.fromstring(LROEXFtjKrqGwmWiSYAQyfuMNhogeB))
  LROEXFtjKrqGwmWiSYAQyfuMNhogcP =LROEXFtjKrqGwmWiSYAQyfuMNhogcs.getroot()
  LROEXFtjKrqGwmWiSYAQyfuMNhogcz=re.match(r'\{.*\}',LROEXFtjKrqGwmWiSYAQyfuMNhogcP.tag)[0]
  LROEXFtjKrqGwmWiSYAQyfuMNhogcl=LROEXFtjKrqGwmWiSYAQyfuMNhogsc([node for _,node in ET.iterparse(io.StringIO(LROEXFtjKrqGwmWiSYAQyfuMNhogeB),events=['start-ns'])])
  for LROEXFtjKrqGwmWiSYAQyfuMNhogea,value in LROEXFtjKrqGwmWiSYAQyfuMNhogcl.items():
   ET.register_namespace(LROEXFtjKrqGwmWiSYAQyfuMNhogea,value)
  LROEXFtjKrqGwmWiSYAQyfuMNhogcD=LROEXFtjKrqGwmWiSYAQyfuMNhogcP.find(LROEXFtjKrqGwmWiSYAQyfuMNhogcz+'Period')
  for LROEXFtjKrqGwmWiSYAQyfuMNhogcd in LROEXFtjKrqGwmWiSYAQyfuMNhogcD.findall(LROEXFtjKrqGwmWiSYAQyfuMNhogcz+'AdaptationSet'):
   if LROEXFtjKrqGwmWiSYAQyfuMNhogcd.attrib.get('contentType')=='text':
    LROEXFtjKrqGwmWiSYAQyfuMNhogcD.remove(LROEXFtjKrqGwmWiSYAQyfuMNhogcd)
    continue
   if LROEXFtjKrqGwmWiSYAQyfuMNhogcd.attrib.get('contentType')=='video':
    for LROEXFtjKrqGwmWiSYAQyfuMNhogca in LROEXFtjKrqGwmWiSYAQyfuMNhogcd.findall(LROEXFtjKrqGwmWiSYAQyfuMNhogcz+'Representation'):
     LROEXFtjKrqGwmWiSYAQyfuMNhogcp =LROEXFtjKrqGwmWiSYAQyfuMNhogsl(LROEXFtjKrqGwmWiSYAQyfuMNhogca.attrib.get('width'))
     LROEXFtjKrqGwmWiSYAQyfuMNhogcv=LROEXFtjKrqGwmWiSYAQyfuMNhogsl(LROEXFtjKrqGwmWiSYAQyfuMNhogca.attrib.get('bandwidth'))
     if LROEXFtjKrqGwmWiSYAQyfuMNhogek['width']<=LROEXFtjKrqGwmWiSYAQyfuMNhogcp and LROEXFtjKrqGwmWiSYAQyfuMNhogcp<=LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['addon']['playOption']['max_quality']:
      if LROEXFtjKrqGwmWiSYAQyfuMNhogek['bandwidth']<LROEXFtjKrqGwmWiSYAQyfuMNhogcv:
       LROEXFtjKrqGwmWiSYAQyfuMNhogek['width'] =LROEXFtjKrqGwmWiSYAQyfuMNhogcp
       LROEXFtjKrqGwmWiSYAQyfuMNhogek['bandwidth']=LROEXFtjKrqGwmWiSYAQyfuMNhogcv
   if LROEXFtjKrqGwmWiSYAQyfuMNhogcd.attrib.get('contentType')=='audio':
    for LROEXFtjKrqGwmWiSYAQyfuMNhogca in LROEXFtjKrqGwmWiSYAQyfuMNhogcd.findall(LROEXFtjKrqGwmWiSYAQyfuMNhogcz+'Representation'):
     LROEXFtjKrqGwmWiSYAQyfuMNhogcn=LROEXFtjKrqGwmWiSYAQyfuMNhogel[LROEXFtjKrqGwmWiSYAQyfuMNhogeD.getAudioAdaptInfo(LROEXFtjKrqGwmWiSYAQyfuMNhogcz,LROEXFtjKrqGwmWiSYAQyfuMNhogca)]
     if LROEXFtjKrqGwmWiSYAQyfuMNhogex<LROEXFtjKrqGwmWiSYAQyfuMNhogcn and LROEXFtjKrqGwmWiSYAQyfuMNhogcn<=LROEXFtjKrqGwmWiSYAQyfuMNhogce:
      LROEXFtjKrqGwmWiSYAQyfuMNhogex=LROEXFtjKrqGwmWiSYAQyfuMNhogcn
  LROEXFtjKrqGwmWiSYAQyfuMNhogsP(LROEXFtjKrqGwmWiSYAQyfuMNhogex)
  for LROEXFtjKrqGwmWiSYAQyfuMNhogcd in LROEXFtjKrqGwmWiSYAQyfuMNhogcD.findall(LROEXFtjKrqGwmWiSYAQyfuMNhogcz+'AdaptationSet'):
   if LROEXFtjKrqGwmWiSYAQyfuMNhogcd.attrib.get('contentType')=='video':
    for LROEXFtjKrqGwmWiSYAQyfuMNhogca in LROEXFtjKrqGwmWiSYAQyfuMNhogcd.findall(LROEXFtjKrqGwmWiSYAQyfuMNhogcz+'Representation'):
     LROEXFtjKrqGwmWiSYAQyfuMNhogcp =LROEXFtjKrqGwmWiSYAQyfuMNhogsl(LROEXFtjKrqGwmWiSYAQyfuMNhogca.attrib.get('width'))
     LROEXFtjKrqGwmWiSYAQyfuMNhogcv=LROEXFtjKrqGwmWiSYAQyfuMNhogsl(LROEXFtjKrqGwmWiSYAQyfuMNhogca.attrib.get('bandwidth'))
     if LROEXFtjKrqGwmWiSYAQyfuMNhogek['width']!=LROEXFtjKrqGwmWiSYAQyfuMNhogcp or LROEXFtjKrqGwmWiSYAQyfuMNhogek['bandwidth']!=LROEXFtjKrqGwmWiSYAQyfuMNhogcv:
      LROEXFtjKrqGwmWiSYAQyfuMNhogcd.remove(LROEXFtjKrqGwmWiSYAQyfuMNhogca)
   if LROEXFtjKrqGwmWiSYAQyfuMNhogcd.attrib.get('contentType')=='audio':
    for LROEXFtjKrqGwmWiSYAQyfuMNhogca in LROEXFtjKrqGwmWiSYAQyfuMNhogcd.findall(LROEXFtjKrqGwmWiSYAQyfuMNhogcz+'Representation'):
     LROEXFtjKrqGwmWiSYAQyfuMNhogcn=LROEXFtjKrqGwmWiSYAQyfuMNhogel[LROEXFtjKrqGwmWiSYAQyfuMNhogeD.getAudioAdaptInfo(LROEXFtjKrqGwmWiSYAQyfuMNhogcz,LROEXFtjKrqGwmWiSYAQyfuMNhogca)]
     if LROEXFtjKrqGwmWiSYAQyfuMNhogex!=LROEXFtjKrqGwmWiSYAQyfuMNhogcn:
      LROEXFtjKrqGwmWiSYAQyfuMNhogcd.remove(LROEXFtjKrqGwmWiSYAQyfuMNhogca)
  LROEXFtjKrqGwmWiSYAQyfuMNhogsP(LROEXFtjKrqGwmWiSYAQyfuMNhogek)
  LROEXFtjKrqGwmWiSYAQyfuMNhogcH=ET.tostring(LROEXFtjKrqGwmWiSYAQyfuMNhogcP).decode('utf-8')
  LROEXFtjKrqGwmWiSYAQyfuMNhogcH=xml.dom.minidom.parseString(LROEXFtjKrqGwmWiSYAQyfuMNhogcH)
  LROEXFtjKrqGwmWiSYAQyfuMNhogcH=LROEXFtjKrqGwmWiSYAQyfuMNhogcH.toprettyxml(indent="  ") 
  try:
   LROEXFtjKrqGwmWiSYAQyfuMNhogcI=LROEXFtjKrqGwmWiSYAQyfuMNhogeD.REQ_INFO['addon']['playOption']['streamFilename']
   fp=LROEXFtjKrqGwmWiSYAQyfuMNhogsH(LROEXFtjKrqGwmWiSYAQyfuMNhogcI,'w',-1,'utf-8')
   fp.write(LROEXFtjKrqGwmWiSYAQyfuMNhogcH)
   fp.close()
  except LROEXFtjKrqGwmWiSYAQyfuMNhogsd as exception:
   pass
  return LROEXFtjKrqGwmWiSYAQyfuMNhogcH
 def getAudioAdaptInfo(LROEXFtjKrqGwmWiSYAQyfuMNhogeD,LROEXFtjKrqGwmWiSYAQyfuMNhogcz,adaptNode):
  if adaptNode.attrib.get('codecs').startswith('ec-3'):return 'ATMOS'
  LROEXFtjKrqGwmWiSYAQyfuMNhogcT=adaptNode.find(LROEXFtjKrqGwmWiSYAQyfuMNhogcz+'AudioChannelConfiguration')
  if LROEXFtjKrqGwmWiSYAQyfuMNhogcT.attrib.get('value')=='2':return '2CH'
  elif LROEXFtjKrqGwmWiSYAQyfuMNhogcT.attrib.get('value')=='6':return '6CH'
  return '-'
 def indent(LROEXFtjKrqGwmWiSYAQyfuMNhogeD,LROEXFtjKrqGwmWiSYAQyfuMNhogcC,level=0):
  i="\n"+level*"  "
  if LROEXFtjKrqGwmWiSYAQyfuMNhogsz(LROEXFtjKrqGwmWiSYAQyfuMNhogcC):
   if not LROEXFtjKrqGwmWiSYAQyfuMNhogcC.text or not LROEXFtjKrqGwmWiSYAQyfuMNhogcC.text.strip():
    LROEXFtjKrqGwmWiSYAQyfuMNhogcC.text=i+"  "
   if not LROEXFtjKrqGwmWiSYAQyfuMNhogcC.tail or not LROEXFtjKrqGwmWiSYAQyfuMNhogcC.tail.strip():
    LROEXFtjKrqGwmWiSYAQyfuMNhogcC.tail=i
   for LROEXFtjKrqGwmWiSYAQyfuMNhogcC in LROEXFtjKrqGwmWiSYAQyfuMNhogcC:
    LROEXFtjKrqGwmWiSYAQyfuMNhogeD.indent(LROEXFtjKrqGwmWiSYAQyfuMNhogcC,level+1)
   if not LROEXFtjKrqGwmWiSYAQyfuMNhogcC.tail or not LROEXFtjKrqGwmWiSYAQyfuMNhogcC.tail.strip():
    LROEXFtjKrqGwmWiSYAQyfuMNhogcC.tail=i
  else:
   if level and(not LROEXFtjKrqGwmWiSYAQyfuMNhogcC.tail or not LROEXFtjKrqGwmWiSYAQyfuMNhogcC.tail.strip()):
    LROEXFtjKrqGwmWiSYAQyfuMNhogcC.tail=i
 def _gzip(LROEXFtjKrqGwmWiSYAQyfuMNhogeD,data=LROEXFtjKrqGwmWiSYAQyfuMNhogsD):
  from io import BytesIO
  from gzip import GzipFile
  LROEXFtjKrqGwmWiSYAQyfuMNhogcV=BytesIO()
  f=GzipFile(fileobj=LROEXFtjKrqGwmWiSYAQyfuMNhogcV,mode='w',compresslevel=5)
  f.write(data)
  f.close()
  return LROEXFtjKrqGwmWiSYAQyfuMNhogcV.getvalue()
class LROEXFtjKrqGwmWiSYAQyfuMNhoges(LROEXFtjKrqGwmWiSYAQyfuMNhogsI):
 def __init__(LROEXFtjKrqGwmWiSYAQyfuMNhogeD):
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.started=LROEXFtjKrqGwmWiSYAQyfuMNhogsa
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.PORT=LROEXFtjKrqGwmWiSYAQyfuMNhogsD
 def start(LROEXFtjKrqGwmWiSYAQyfuMNhogeD):
  if LROEXFtjKrqGwmWiSYAQyfuMNhogeD.started:return
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD._server=HTTPServer(('0.0.0.0',LROEXFtjKrqGwmWiSYAQyfuMNhogeD.PORT),LROEXFtjKrqGwmWiSYAQyfuMNhogcJ)
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD._httpd_thread=threading.Thread(target=LROEXFtjKrqGwmWiSYAQyfuMNhogeD._server.serve_forever)
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD._httpd_thread.start()
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.started=LROEXFtjKrqGwmWiSYAQyfuMNhogsp
 def stop(LROEXFtjKrqGwmWiSYAQyfuMNhogeD):
  if not LROEXFtjKrqGwmWiSYAQyfuMNhogeD.started:return
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD._server.shutdown()
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD._server.server_close()
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD._server.socket.close()
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD._httpd_thread.join()
  LROEXFtjKrqGwmWiSYAQyfuMNhogeD.started=LROEXFtjKrqGwmWiSYAQyfuMNhogsa
if __name__=="__main__":
 LROEXFtjKrqGwmWiSYAQyfuMNhogcb=9999
 LROEXFtjKrqGwmWiSYAQyfuMNhogck=HTTPServer(('0.0.0.0',LROEXFtjKrqGwmWiSYAQyfuMNhogcb),LROEXFtjKrqGwmWiSYAQyfuMNhogcJ)
 LROEXFtjKrqGwmWiSYAQyfuMNhogsP(f'Server running on port : {TEST_PORT}')
 LROEXFtjKrqGwmWiSYAQyfuMNhogck.serve_forever()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
