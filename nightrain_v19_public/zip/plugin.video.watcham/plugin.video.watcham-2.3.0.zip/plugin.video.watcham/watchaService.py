__author__="NightRain"
WVdCbtJngIHjmMiLlqsODrePUAKTpw=int
import xbmc,xbmcaddon,xbmcvfs
import os
import sys
WVdCbtJngIHjmMiLlqsODrePUAKTpv=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
WVdCbtJngIHjmMiLlqsODrePUAKTpR =os.path.join(WVdCbtJngIHjmMiLlqsODrePUAKTpv,'resources','lib')
sys.path.append(WVdCbtJngIHjmMiLlqsODrePUAKTpR)
from watchaProxy import*
WVdCbtJngIHjmMiLlqsODrePUAKTpf=xbmc.Monitor()
WVdCbtJngIHjmMiLlqsODrePUAKTpB=HnmRfJNIBPjGSEzAgLwtupKCFcMlhq()
xbmc.sleep(3000)
WVdCbtJngIHjmMiLlqsODrePUAKTpB.PORT=WVdCbtJngIHjmMiLlqsODrePUAKTpw(xbmcaddon.Addon().getSetting('proxyPort'))
WVdCbtJngIHjmMiLlqsODrePUAKTpB.start()
while not WVdCbtJngIHjmMiLlqsODrePUAKTpf.abortRequested():
 if WVdCbtJngIHjmMiLlqsODrePUAKTpf.waitForAbort(60):
  break
WVdCbtJngIHjmMiLlqsODrePUAKTpB.stop()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
