__author__="NightRain"
gSpHcwFmARzGtIBUoTNaXhkdvufrLi=object
gSpHcwFmARzGtIBUoTNaXhkdvufrLn=None
gSpHcwFmARzGtIBUoTNaXhkdvufrLO=False
gSpHcwFmARzGtIBUoTNaXhkdvufrLJ=open
gSpHcwFmARzGtIBUoTNaXhkdvufrLQ=True
gSpHcwFmARzGtIBUoTNaXhkdvufrLY=id
gSpHcwFmARzGtIBUoTNaXhkdvufrMD=str
gSpHcwFmARzGtIBUoTNaXhkdvufrMy=range
gSpHcwFmARzGtIBUoTNaXhkdvufrMK=Exception
gSpHcwFmARzGtIBUoTNaXhkdvufrMq=print
gSpHcwFmARzGtIBUoTNaXhkdvufrML=int
gSpHcwFmARzGtIBUoTNaXhkdvufrMx=len
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
import string
import random
class gSpHcwFmARzGtIBUoTNaXhkdvufrDy(gSpHcwFmARzGtIBUoTNaXhkdvufrLi):
 def __init__(gSpHcwFmARzGtIBUoTNaXhkdvufrDK):
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC ={}
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Init_WC_Total()
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.MAIN_DOMAIN ='https://watcha.com'
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN ='https://api-mars.watcha.com'
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.EPISODE_LIMIT=20
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.SEARCH_LIMIT =30
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36'
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.USER_AGENT2 ='User-Agent: Dalvik/2.1.0 (Linux; U; Android 9; A95X_F3_Air Build/A95X_F3_AIR_M)/WatchaPlay-Android/1.10.34'
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.DEFAULT_HEADER={'user-agent':gSpHcwFmARzGtIBUoTNaXhkdvufrDK.USER_AGENT}
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC_SUBTITLE_VTT =''
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC_SUBTITLE_SRT =''
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC_COOKIE_FILENAME =''
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC_SEARCHEDC_FILENAME=''
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC_STREAM_FILENAME =''
 def Get_Base_Headers(gSpHcwFmARzGtIBUoTNaXhkdvufrDK):
  gSpHcwFmARzGtIBUoTNaXhkdvufrDq={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.3',}
  return gSpHcwFmARzGtIBUoTNaXhkdvufrDq
 def Get_Base_Headers_v2(gSpHcwFmARzGtIBUoTNaXhkdvufrDK):
  gSpHcwFmARzGtIBUoTNaXhkdvufrDL ='1.10.35' 
  gSpHcwFmARzGtIBUoTNaXhkdvufrDM ='30' 
  gSpHcwFmARzGtIBUoTNaXhkdvufrDx ='NVIDIA SHIELD Android TV'
  gSpHcwFmARzGtIBUoTNaXhkdvufrDj =base64.standard_b64encode((gSpHcwFmARzGtIBUoTNaXhkdvufrDx+'-'+gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['deviceId2']).encode()).decode('utf-8') 
  gSpHcwFmARzGtIBUoTNaXhkdvufrDW ='1920x1080/2.0/320/xhdpi'
  gSpHcwFmARzGtIBUoTNaXhkdvufrDl ='2596eb93-6e7f-4eba-925c-ddf783246860' 
  gSpHcwFmARzGtIBUoTNaXhkdvufrDq={'X-WatchaPlay-Client-Device-Id':gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['deviceId1'],'X-WatchaPlay-Client-Device-Id2':gSpHcwFmARzGtIBUoTNaXhkdvufrDj,'X-WatchaPlay-Client-Device-Name':gSpHcwFmARzGtIBUoTNaXhkdvufrDx,'X-WatchaPlay-Client-ADID':gSpHcwFmARzGtIBUoTNaXhkdvufrDl,'X-WatchaPlay-Client':'WatchaPlay-Android','X-WatchaPlay-Client-Version':gSpHcwFmARzGtIBUoTNaXhkdvufrDL,'X-WatchaPlay-Client-Subclass':'Normal','X-WatchaPlay-Client-Ui-Mode-Name':'television','X-WatchaPlay-Screen':gSpHcwFmARzGtIBUoTNaXhkdvufrDW,'X-WatchaPlay-Network-Status':'wifi','X-WatchaPlay-Appsflyer-Device-ID':gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['flyerId'],'X-FROGRAMS-CLIENT':'Mars-Android-Box','X-FROGRAMS-APP-CODE':'mars','X-FROGRAMS-DEVICE-IDENTIFIER':gSpHcwFmARzGtIBUoTNaXhkdvufrDj,'X-FROGRAMS-DEVICE-NAME':gSpHcwFmARzGtIBUoTNaXhkdvufrDx,'X-FROGRAMS-AD-ID':gSpHcwFmARzGtIBUoTNaXhkdvufrDl,'X-FROGRAMS-APPSFLYER-DEVICE-ID':gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['flyerId'],'X-FROGRAMS-VERSION':gSpHcwFmARzGtIBUoTNaXhkdvufrDL,'X-FROGRAMS-OS-VERSION':gSpHcwFmARzGtIBUoTNaXhkdvufrDM,'X-FROGRAMS-NETWORK-STATUS':'wifi','X-FROGRAMS-MARS-SCREEN':gSpHcwFmARzGtIBUoTNaXhkdvufrDW,'X-FROGRAMS-MARS-UI-MODE':'television',}
  return gSpHcwFmARzGtIBUoTNaXhkdvufrDq
 def Init_WC_Total(gSpHcwFmARzGtIBUoTNaXhkdvufrDK):
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC={'account':{},'cookies':{'watcha_token':'','watcha_guit':'','watcha_guitv':'','watcha_usercd':'',},}
 def callRequestCookies(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,jobtype,gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,headers=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,redirects=gSpHcwFmARzGtIBUoTNaXhkdvufrLO):
  gSpHcwFmARzGtIBUoTNaXhkdvufrDC=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.DEFAULT_HEADER
  if headers:gSpHcwFmARzGtIBUoTNaXhkdvufrDC.update(headers)
  if jobtype=='Get':
   gSpHcwFmARzGtIBUoTNaXhkdvufrDb=requests.get(gSpHcwFmARzGtIBUoTNaXhkdvufrys,params=params,headers=gSpHcwFmARzGtIBUoTNaXhkdvufrDC,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   gSpHcwFmARzGtIBUoTNaXhkdvufrDb=requests.put(gSpHcwFmARzGtIBUoTNaXhkdvufrys,data=payload,params=params,headers=gSpHcwFmARzGtIBUoTNaXhkdvufrDC,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Delete':
   gSpHcwFmARzGtIBUoTNaXhkdvufrDb=requests.delete(gSpHcwFmARzGtIBUoTNaXhkdvufrys,params=params,headers=gSpHcwFmARzGtIBUoTNaXhkdvufrDC,cookies=cookies,allow_redirects=redirects)
  else:
   gSpHcwFmARzGtIBUoTNaXhkdvufrDb=requests.post(gSpHcwFmARzGtIBUoTNaXhkdvufrys,data=payload,params=params,headers=gSpHcwFmARzGtIBUoTNaXhkdvufrDC,cookies=cookies,allow_redirects=redirects)
  return gSpHcwFmARzGtIBUoTNaXhkdvufrDb
 def JsonFile_Save(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,filename,gSpHcwFmARzGtIBUoTNaXhkdvufrDV):
  if filename=='':return gSpHcwFmARzGtIBUoTNaXhkdvufrLO
  try:
   fp=gSpHcwFmARzGtIBUoTNaXhkdvufrLJ(filename,'w',-1,'utf-8')
   json.dump(gSpHcwFmARzGtIBUoTNaXhkdvufrDV,fp,indent=4,ensure_ascii=gSpHcwFmARzGtIBUoTNaXhkdvufrLO)
   fp.close()
  except:
   return gSpHcwFmARzGtIBUoTNaXhkdvufrLO
  return gSpHcwFmARzGtIBUoTNaXhkdvufrLQ
 def JsonFile_Load(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,filename):
  if filename=='':return{}
  try:
   fp=gSpHcwFmARzGtIBUoTNaXhkdvufrLJ(filename,'r',-1,'utf-8')
   gSpHcwFmARzGtIBUoTNaXhkdvufrDP=json.load(fp)
   fp.close()
  except:
   return{}
  return gSpHcwFmARzGtIBUoTNaXhkdvufrDP
 def Save_session_acount(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,gSpHcwFmARzGtIBUoTNaXhkdvufrDE,gSpHcwFmARzGtIBUoTNaXhkdvufrDe,gSpHcwFmARzGtIBUoTNaXhkdvufrDi):
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['account']['wcid']=base64.standard_b64encode(gSpHcwFmARzGtIBUoTNaXhkdvufrDE.encode()).decode('utf-8')
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['account']['wcpw']=base64.standard_b64encode(gSpHcwFmARzGtIBUoTNaXhkdvufrDe.encode()).decode('utf-8')
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['account']['wcpf']=gSpHcwFmARzGtIBUoTNaXhkdvufrDi 
 def Load_session_acount(gSpHcwFmARzGtIBUoTNaXhkdvufrDK):
  try:
   gSpHcwFmARzGtIBUoTNaXhkdvufrDE=base64.standard_b64decode(gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['account']['wcid']).decode('utf-8')
   gSpHcwFmARzGtIBUoTNaXhkdvufrDe=base64.standard_b64decode(gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['account']['wcpw']).decode('utf-8')
   gSpHcwFmARzGtIBUoTNaXhkdvufrDi=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['account']['wcpf']
  except:
   return '','',0
  return gSpHcwFmARzGtIBUoTNaXhkdvufrDE,gSpHcwFmARzGtIBUoTNaXhkdvufrDe,gSpHcwFmARzGtIBUoTNaXhkdvufrDi
 def Get_DeviceID(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,gSpHcwFmARzGtIBUoTNaXhkdvufrLY,pf):
  import hashlib
  m1=hashlib.md5()
  m2=hashlib.md5()
  gSpHcwFmARzGtIBUoTNaXhkdvufrDn=gSpHcwFmARzGtIBUoTNaXhkdvufrLY+gSpHcwFmARzGtIBUoTNaXhkdvufrMD(pf)
  gSpHcwFmARzGtIBUoTNaXhkdvufrDO=gSpHcwFmARzGtIBUoTNaXhkdvufrMD(pf)+gSpHcwFmARzGtIBUoTNaXhkdvufrLY
  m1.update(gSpHcwFmARzGtIBUoTNaXhkdvufrDn.encode('utf-8'))
  m2.update(gSpHcwFmARzGtIBUoTNaXhkdvufrDO.encode('utf-8'))
  gSpHcwFmARzGtIBUoTNaXhkdvufrDJ=gSpHcwFmARzGtIBUoTNaXhkdvufrMD(m1.hexdigest())
  gSpHcwFmARzGtIBUoTNaXhkdvufrDQ=gSpHcwFmARzGtIBUoTNaXhkdvufrMD(m2.hexdigest())
  gSpHcwFmARzGtIBUoTNaXhkdvufrDY=gSpHcwFmARzGtIBUoTNaXhkdvufrDJ[:16]
  gSpHcwFmARzGtIBUoTNaXhkdvufryD='%s-%s-%s-%s-%s'%(gSpHcwFmARzGtIBUoTNaXhkdvufrDQ[:8],gSpHcwFmARzGtIBUoTNaXhkdvufrDQ[8:12],gSpHcwFmARzGtIBUoTNaXhkdvufrDQ[12:16],gSpHcwFmARzGtIBUoTNaXhkdvufrDQ[16:20],gSpHcwFmARzGtIBUoTNaXhkdvufrDQ[20:])
  return gSpHcwFmARzGtIBUoTNaXhkdvufrDY,gSpHcwFmARzGtIBUoTNaXhkdvufryD
 def make_Random_Intstr(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,size):
  gSpHcwFmARzGtIBUoTNaXhkdvufryK=string.digits 
  gSpHcwFmARzGtIBUoTNaXhkdvufryq=''
  for i in gSpHcwFmARzGtIBUoTNaXhkdvufrMy(size):
   gSpHcwFmARzGtIBUoTNaXhkdvufryq+=random.choice(gSpHcwFmARzGtIBUoTNaXhkdvufryK)
  return gSpHcwFmARzGtIBUoTNaXhkdvufryq
 def makeDefaultCookies(gSpHcwFmARzGtIBUoTNaXhkdvufrDK):
  gSpHcwFmARzGtIBUoTNaXhkdvufryL={'_s_guit':gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_guit'],'_guinness-premium_session':gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_token']}
  if gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_guitv']:
   gSpHcwFmARzGtIBUoTNaXhkdvufryL['_s_guitv']=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_guitv']
  return gSpHcwFmARzGtIBUoTNaXhkdvufryL
 def GetCredential(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,user_id,user_pw,user_pf):
  try:
   gSpHcwFmARzGtIBUoTNaXhkdvufryM=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+'/api/session'
   gSpHcwFmARzGtIBUoTNaXhkdvufryx={'email':user_id,'password':user_pw}
   gSpHcwFmARzGtIBUoTNaXhkdvufryj=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
   gSpHcwFmARzGtIBUoTNaXhkdvufryW={'accept':'application/vnd.frograms+json;version=4'}
   gSpHcwFmARzGtIBUoTNaXhkdvufryj.update(gSpHcwFmARzGtIBUoTNaXhkdvufryW)
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Post',gSpHcwFmARzGtIBUoTNaXhkdvufryM,payload=gSpHcwFmARzGtIBUoTNaXhkdvufryx,params=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufrLn)
   for gSpHcwFmARzGtIBUoTNaXhkdvufryC in gSpHcwFmARzGtIBUoTNaXhkdvufryl.cookies:
    if gSpHcwFmARzGtIBUoTNaXhkdvufryC.name=='_guinness-premium_session':
     gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_token']=gSpHcwFmARzGtIBUoTNaXhkdvufryC.value
    elif gSpHcwFmARzGtIBUoTNaXhkdvufryC.name=='_s_guit':
     gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_guit']=gSpHcwFmARzGtIBUoTNaXhkdvufryC.value
   if gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_token']=='':
    gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Init_WC_Total()
    return gSpHcwFmARzGtIBUoTNaXhkdvufrLO
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
   gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Init_WC_Total()
   return gSpHcwFmARzGtIBUoTNaXhkdvufrLO
  if gSpHcwFmARzGtIBUoTNaXhkdvufrDK.GetProfilesList(user_pf)==gSpHcwFmARzGtIBUoTNaXhkdvufrLO:
   gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Init_WC_Total()
   return gSpHcwFmARzGtIBUoTNaXhkdvufrLO
  if user_pf!=0:
   if gSpHcwFmARzGtIBUoTNaXhkdvufrDK.GetProfilesConvert()==gSpHcwFmARzGtIBUoTNaXhkdvufrLO:
    gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Init_WC_Total()
    return gSpHcwFmARzGtIBUoTNaXhkdvufrLO
  (gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['deviceId1'],gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['deviceId2'])=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_DeviceID(user_id,user_pf)
  gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['flyerId']=gSpHcwFmARzGtIBUoTNaXhkdvufrMD(gSpHcwFmARzGtIBUoTNaXhkdvufrML(time.time()*1000))+'-'+gSpHcwFmARzGtIBUoTNaXhkdvufrDK.make_Random_Intstr(19)
  return gSpHcwFmARzGtIBUoTNaXhkdvufrLQ
 def GetProfilesList(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,user_pf):
  gSpHcwFmARzGtIBUoTNaXhkdvufryb=[]
  try:
   gSpHcwFmARzGtIBUoTNaXhkdvufryV ='/manage_profiles'
   gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.MAIN_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
   gSpHcwFmARzGtIBUoTNaXhkdvufryj=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
   gSpHcwFmARzGtIBUoTNaXhkdvufryC=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.makeDefaultCookies()
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Get',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufryC,redirects=gSpHcwFmARzGtIBUoTNaXhkdvufrLQ)
   gSpHcwFmARzGtIBUoTNaXhkdvufryP=gSpHcwFmARzGtIBUoTNaXhkdvufryl.text
   gSpHcwFmARzGtIBUoTNaXhkdvufryE =re.findall('/api/users/me.{8000}',gSpHcwFmARzGtIBUoTNaXhkdvufryP)[0]
   gSpHcwFmARzGtIBUoTNaXhkdvufryE =gSpHcwFmARzGtIBUoTNaXhkdvufryE.replace('&quot;','')
   gSpHcwFmARzGtIBUoTNaXhkdvufryb=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',gSpHcwFmARzGtIBUoTNaXhkdvufryE)
   for i in gSpHcwFmARzGtIBUoTNaXhkdvufrMy(gSpHcwFmARzGtIBUoTNaXhkdvufrMx(gSpHcwFmARzGtIBUoTNaXhkdvufryb)):
    gSpHcwFmARzGtIBUoTNaXhkdvufrye=gSpHcwFmARzGtIBUoTNaXhkdvufryb[i]
    gSpHcwFmARzGtIBUoTNaXhkdvufrye =gSpHcwFmARzGtIBUoTNaXhkdvufrye.split(':')[1]
    gSpHcwFmARzGtIBUoTNaXhkdvufryb[i]=gSpHcwFmARzGtIBUoTNaXhkdvufrye.split(',')[0]
   gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_usercd']=gSpHcwFmARzGtIBUoTNaXhkdvufryb[user_pf]
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
   gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Init_WC_Total()
   return gSpHcwFmARzGtIBUoTNaXhkdvufrLO
  return gSpHcwFmARzGtIBUoTNaXhkdvufrLQ
 def GetProfilesConvert(gSpHcwFmARzGtIBUoTNaXhkdvufrDK):
  try:
   gSpHcwFmARzGtIBUoTNaXhkdvufryV ='/api/users/'+gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_usercd']+'/convert'
   gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
   gSpHcwFmARzGtIBUoTNaXhkdvufryj =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
   gSpHcwFmARzGtIBUoTNaXhkdvufryC =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.makeDefaultCookies()
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Put',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufryC)
   for gSpHcwFmARzGtIBUoTNaXhkdvufryC in gSpHcwFmARzGtIBUoTNaXhkdvufryl.cookies:
    if gSpHcwFmARzGtIBUoTNaXhkdvufryC.name=='_s_guitv':
     gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_guitv']=gSpHcwFmARzGtIBUoTNaXhkdvufryC.value
    elif gSpHcwFmARzGtIBUoTNaXhkdvufryC.name=='_guinness-premium_session':
     gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_token']=gSpHcwFmARzGtIBUoTNaXhkdvufryC.value
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
   gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Init_WC_Total()
   return gSpHcwFmARzGtIBUoTNaXhkdvufrLO
  return gSpHcwFmARzGtIBUoTNaXhkdvufrLQ
 def GetSubGroupList(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,stype):
  gSpHcwFmARzGtIBUoTNaXhkdvufryi=[]
  try:
   gSpHcwFmARzGtIBUoTNaXhkdvufryV ='/api/categories.json'
   gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
   gSpHcwFmARzGtIBUoTNaXhkdvufryj =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
   gSpHcwFmARzGtIBUoTNaXhkdvufryC =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.makeDefaultCookies()
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Get',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufryC)
   gSpHcwFmARzGtIBUoTNaXhkdvufryn=json.loads(gSpHcwFmARzGtIBUoTNaXhkdvufryl.text)
   if not('genres' in gSpHcwFmARzGtIBUoTNaXhkdvufryn):return gSpHcwFmARzGtIBUoTNaXhkdvufryi
   if stype=='genres':
    gSpHcwFmARzGtIBUoTNaXhkdvufryO=gSpHcwFmARzGtIBUoTNaXhkdvufryn['genres']
   else:
    gSpHcwFmARzGtIBUoTNaXhkdvufryO=gSpHcwFmARzGtIBUoTNaXhkdvufryn['tags']
   for gSpHcwFmARzGtIBUoTNaXhkdvufryJ in gSpHcwFmARzGtIBUoTNaXhkdvufryO:
    gSpHcwFmARzGtIBUoTNaXhkdvufryQ=gSpHcwFmARzGtIBUoTNaXhkdvufryJ['name']
    gSpHcwFmARzGtIBUoTNaXhkdvufryY =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['api_path']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKD =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['entity']['id']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKy={'group_name':gSpHcwFmARzGtIBUoTNaXhkdvufryQ,'api_path':gSpHcwFmARzGtIBUoTNaXhkdvufryY,'tag_id':gSpHcwFmARzGtIBUoTNaXhkdvufrMD(gSpHcwFmARzGtIBUoTNaXhkdvufrKD)}
    gSpHcwFmARzGtIBUoTNaXhkdvufryi.append(gSpHcwFmARzGtIBUoTNaXhkdvufrKy)
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
  return gSpHcwFmARzGtIBUoTNaXhkdvufryi
 def GetCategoryList(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,stype,gSpHcwFmARzGtIBUoTNaXhkdvufrKD,gSpHcwFmARzGtIBUoTNaXhkdvufryY,page_int):
  gSpHcwFmARzGtIBUoTNaXhkdvufryi=[]
  gSpHcwFmARzGtIBUoTNaXhkdvufrKq=gSpHcwFmARzGtIBUoTNaXhkdvufrLO
  gSpHcwFmARzGtIBUoTNaXhkdvufrKL={}
  try:
   if 'categories' in gSpHcwFmARzGtIBUoTNaXhkdvufryY:
    gSpHcwFmARzGtIBUoTNaXhkdvufryV ='/api/tags'
    gSpHcwFmARzGtIBUoTNaXhkdvufrKL['ids']=gSpHcwFmARzGtIBUoTNaXhkdvufrKD
   else: 
    gSpHcwFmARzGtIBUoTNaXhkdvufryV ='/api/'+gSpHcwFmARzGtIBUoTNaXhkdvufryY+'.json'
    if page_int>1:
     gSpHcwFmARzGtIBUoTNaXhkdvufrKL['page']=gSpHcwFmARzGtIBUoTNaXhkdvufrMD(page_int)
   gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
   gSpHcwFmARzGtIBUoTNaXhkdvufryj =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
   gSpHcwFmARzGtIBUoTNaXhkdvufryC =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.makeDefaultCookies()
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Get',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrKL,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufryC)
   gSpHcwFmARzGtIBUoTNaXhkdvufryn=json.loads(gSpHcwFmARzGtIBUoTNaXhkdvufryl.text)
   if not('contents' in gSpHcwFmARzGtIBUoTNaXhkdvufryn):return gSpHcwFmARzGtIBUoTNaXhkdvufryi,gSpHcwFmARzGtIBUoTNaXhkdvufrKq
   gSpHcwFmARzGtIBUoTNaXhkdvufryO=gSpHcwFmARzGtIBUoTNaXhkdvufryn['contents']
   gSpHcwFmARzGtIBUoTNaXhkdvufrKq=gSpHcwFmARzGtIBUoTNaXhkdvufryn['meta']['has_next']
   for gSpHcwFmARzGtIBUoTNaXhkdvufryJ in gSpHcwFmARzGtIBUoTNaXhkdvufryO:
    gSpHcwFmARzGtIBUoTNaXhkdvufrKM =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['code']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKx=gSpHcwFmARzGtIBUoTNaXhkdvufryJ['content_type']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKj =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['title']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKW =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['story']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKl =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['badge_text']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKC=gSpHcwFmARzGtIBUoTNaXhkdvufrLe=gSpHcwFmARzGtIBUoTNaXhkdvufrLE=''
    if gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('poster') !=gSpHcwFmARzGtIBUoTNaXhkdvufrLn:gSpHcwFmARzGtIBUoTNaXhkdvufrKC=gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('poster').get('original')
    if gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('stillcut')!=gSpHcwFmARzGtIBUoTNaXhkdvufrLn:gSpHcwFmARzGtIBUoTNaXhkdvufrLe =gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('stillcut').get('large')
    if gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('thumbnail')!=gSpHcwFmARzGtIBUoTNaXhkdvufrLn:gSpHcwFmARzGtIBUoTNaXhkdvufrLE=gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('thumbnail').get('large')
    if gSpHcwFmARzGtIBUoTNaXhkdvufrLE=='' :gSpHcwFmARzGtIBUoTNaXhkdvufrLE=gSpHcwFmARzGtIBUoTNaXhkdvufrLe
    gSpHcwFmARzGtIBUoTNaXhkdvufrKb={'thumb':gSpHcwFmARzGtIBUoTNaXhkdvufrLe,'poster':gSpHcwFmARzGtIBUoTNaXhkdvufrKC,'fanart':gSpHcwFmARzGtIBUoTNaXhkdvufrLE}
    gSpHcwFmARzGtIBUoTNaXhkdvufrKV =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['year']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKs =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['film_rating_code']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKP=gSpHcwFmARzGtIBUoTNaXhkdvufryJ['film_rating_short']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKE =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['film_rating_long']
    if gSpHcwFmARzGtIBUoTNaXhkdvufrKx=='movies':
     gSpHcwFmARzGtIBUoTNaXhkdvufrKe =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['duration']
    else:
     gSpHcwFmARzGtIBUoTNaXhkdvufrKe ='0'
    gSpHcwFmARzGtIBUoTNaXhkdvufrKy={'code':gSpHcwFmARzGtIBUoTNaXhkdvufrKM,'content_type':gSpHcwFmARzGtIBUoTNaXhkdvufrKx,'title':gSpHcwFmARzGtIBUoTNaXhkdvufrKj,'story':gSpHcwFmARzGtIBUoTNaXhkdvufrKW,'thumbnail':gSpHcwFmARzGtIBUoTNaXhkdvufrKb,'year':gSpHcwFmARzGtIBUoTNaXhkdvufrKV,'film_rating_code':gSpHcwFmARzGtIBUoTNaXhkdvufrKs,'film_rating_short':gSpHcwFmARzGtIBUoTNaXhkdvufrKP,'film_rating_long':gSpHcwFmARzGtIBUoTNaXhkdvufrKE,'duration':gSpHcwFmARzGtIBUoTNaXhkdvufrKe,'badge':gSpHcwFmARzGtIBUoTNaXhkdvufrKl,}
    gSpHcwFmARzGtIBUoTNaXhkdvufryi.append(gSpHcwFmARzGtIBUoTNaXhkdvufrKy)
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
  return gSpHcwFmARzGtIBUoTNaXhkdvufryi,gSpHcwFmARzGtIBUoTNaXhkdvufrKq
 def GetProgramInfo(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,program_code):
  gSpHcwFmARzGtIBUoTNaXhkdvufrKi={}
  try:
   gSpHcwFmARzGtIBUoTNaXhkdvufryV ='/api/contents/'+program_code
   gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
   gSpHcwFmARzGtIBUoTNaXhkdvufryj=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Get',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufrLn)
   gSpHcwFmARzGtIBUoTNaXhkdvufryn=json.loads(gSpHcwFmARzGtIBUoTNaXhkdvufryl.text)
   gSpHcwFmARzGtIBUoTNaXhkdvufrKn=img_clearlogo=''
   gSpHcwFmARzGtIBUoTNaXhkdvufrKn=gSpHcwFmARzGtIBUoTNaXhkdvufryn.get('poster').get('original')
   if gSpHcwFmARzGtIBUoTNaXhkdvufrMx(gSpHcwFmARzGtIBUoTNaXhkdvufryn.get('title_logos'))>0:img_clearlogo=gSpHcwFmARzGtIBUoTNaXhkdvufryn.get('title_logos')[0].get('src')
   gSpHcwFmARzGtIBUoTNaXhkdvufrKi={'imgPoster':gSpHcwFmARzGtIBUoTNaXhkdvufrKn,'imgClearlogo':img_clearlogo}
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
  return gSpHcwFmARzGtIBUoTNaXhkdvufrKi
 def GetSeasonList(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,program_code):
  gSpHcwFmARzGtIBUoTNaXhkdvufrKO=[]
  try:
   gSpHcwFmARzGtIBUoTNaXhkdvufryV ='/api/aio_contents/'+program_code
   gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
   gSpHcwFmARzGtIBUoTNaXhkdvufryj =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Get',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufrLn)
   gSpHcwFmARzGtIBUoTNaXhkdvufryn=json.loads(gSpHcwFmARzGtIBUoTNaXhkdvufryl.text)
   if not('result' in gSpHcwFmARzGtIBUoTNaXhkdvufryn):return gSpHcwFmARzGtIBUoTNaXhkdvufrKO
   for gSpHcwFmARzGtIBUoTNaXhkdvufryJ in gSpHcwFmARzGtIBUoTNaXhkdvufryn.get('result').get('seasons'):
    gSpHcwFmARzGtIBUoTNaXhkdvufrKJ =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['id']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKQ =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['titles']['short']or gSpHcwFmARzGtIBUoTNaXhkdvufryJ['titles']['original']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKy={'seasonId':gSpHcwFmARzGtIBUoTNaXhkdvufrKJ,'seasonNm':gSpHcwFmARzGtIBUoTNaXhkdvufrKQ,}
    gSpHcwFmARzGtIBUoTNaXhkdvufrKO.append(gSpHcwFmARzGtIBUoTNaXhkdvufrKy)
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
  return gSpHcwFmARzGtIBUoTNaXhkdvufrKO
 def GetEpisodoList(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,program_code,page_int,orderby='asc'):
  gSpHcwFmARzGtIBUoTNaXhkdvufryi=[]
  gSpHcwFmARzGtIBUoTNaXhkdvufrKq=gSpHcwFmARzGtIBUoTNaXhkdvufrLO
  gSpHcwFmARzGtIBUoTNaXhkdvufrKY=''
  try:
   gSpHcwFmARzGtIBUoTNaXhkdvufryV ='/api/contents/'+program_code+'/tv_episodes.json'
   gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
   gSpHcwFmARzGtIBUoTNaXhkdvufrKL={'all':'true'}
   gSpHcwFmARzGtIBUoTNaXhkdvufryj =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Get',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrKL,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufrLn)
   gSpHcwFmARzGtIBUoTNaXhkdvufryn=json.loads(gSpHcwFmARzGtIBUoTNaXhkdvufryl.text)
   if not('tv_episode_codes' in gSpHcwFmARzGtIBUoTNaXhkdvufryn):return gSpHcwFmARzGtIBUoTNaXhkdvufryi,gSpHcwFmARzGtIBUoTNaXhkdvufrKq
   gSpHcwFmARzGtIBUoTNaXhkdvufryO=gSpHcwFmARzGtIBUoTNaXhkdvufryn['tv_episode_codes']
   gSpHcwFmARzGtIBUoTNaXhkdvufrqD=gSpHcwFmARzGtIBUoTNaXhkdvufrMx(gSpHcwFmARzGtIBUoTNaXhkdvufryO)
   gSpHcwFmARzGtIBUoTNaXhkdvufrqy =gSpHcwFmARzGtIBUoTNaXhkdvufrML(gSpHcwFmARzGtIBUoTNaXhkdvufrqD//(gSpHcwFmARzGtIBUoTNaXhkdvufrDK.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    gSpHcwFmARzGtIBUoTNaXhkdvufrqK =(gSpHcwFmARzGtIBUoTNaXhkdvufrqD-1)-((page_int-1)*gSpHcwFmARzGtIBUoTNaXhkdvufrDK.EPISODE_LIMIT)
   else:
    gSpHcwFmARzGtIBUoTNaXhkdvufrqK =(page_int-1)*gSpHcwFmARzGtIBUoTNaXhkdvufrDK.EPISODE_LIMIT
   for i in gSpHcwFmARzGtIBUoTNaXhkdvufrMy(gSpHcwFmARzGtIBUoTNaXhkdvufrDK.EPISODE_LIMIT):
    if orderby=='desc':
     gSpHcwFmARzGtIBUoTNaXhkdvufrqL=gSpHcwFmARzGtIBUoTNaXhkdvufrqK-i
     if gSpHcwFmARzGtIBUoTNaXhkdvufrqL<0:break
    else:
     gSpHcwFmARzGtIBUoTNaXhkdvufrqL=gSpHcwFmARzGtIBUoTNaXhkdvufrqK+i
     if gSpHcwFmARzGtIBUoTNaXhkdvufrqL>=gSpHcwFmARzGtIBUoTNaXhkdvufrqD:break
    if gSpHcwFmARzGtIBUoTNaXhkdvufrKY!='':gSpHcwFmARzGtIBUoTNaXhkdvufrKY+=','
    gSpHcwFmARzGtIBUoTNaXhkdvufrKY+=gSpHcwFmARzGtIBUoTNaXhkdvufryO[gSpHcwFmARzGtIBUoTNaXhkdvufrqL]
   if gSpHcwFmARzGtIBUoTNaXhkdvufrqy>page_int:gSpHcwFmARzGtIBUoTNaXhkdvufrKq=gSpHcwFmARzGtIBUoTNaXhkdvufrLQ
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
  gSpHcwFmARzGtIBUoTNaXhkdvufrqM=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.GetProgramInfo(program_code)
  try:
   gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
   gSpHcwFmARzGtIBUoTNaXhkdvufrKL={'codes':gSpHcwFmARzGtIBUoTNaXhkdvufrKY}
   gSpHcwFmARzGtIBUoTNaXhkdvufryj =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Get',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrKL,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufrLn)
   gSpHcwFmARzGtIBUoTNaXhkdvufryn=json.loads(gSpHcwFmARzGtIBUoTNaXhkdvufryl.text)
   if not('tv_episodes' in gSpHcwFmARzGtIBUoTNaXhkdvufryn):return gSpHcwFmARzGtIBUoTNaXhkdvufryi
   gSpHcwFmARzGtIBUoTNaXhkdvufryO=gSpHcwFmARzGtIBUoTNaXhkdvufryn['tv_episodes']
   for gSpHcwFmARzGtIBUoTNaXhkdvufryJ in gSpHcwFmARzGtIBUoTNaXhkdvufryO:
    gSpHcwFmARzGtIBUoTNaXhkdvufrKM =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['code']
    if gSpHcwFmARzGtIBUoTNaXhkdvufryJ['title']:
     gSpHcwFmARzGtIBUoTNaXhkdvufrKj =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['title']
    else:
     gSpHcwFmARzGtIBUoTNaXhkdvufrKj =''
    gSpHcwFmARzGtIBUoTNaXhkdvufrKC=gSpHcwFmARzGtIBUoTNaXhkdvufrLe=gSpHcwFmARzGtIBUoTNaXhkdvufrLE=gSpHcwFmARzGtIBUoTNaXhkdvufrqx=''
    gSpHcwFmARzGtIBUoTNaXhkdvufrKC =gSpHcwFmARzGtIBUoTNaXhkdvufrqM.get('imgPoster')
    gSpHcwFmARzGtIBUoTNaXhkdvufrqx=gSpHcwFmARzGtIBUoTNaXhkdvufrqM.get('imgClearlogo')
    if gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('stillcut') !=gSpHcwFmARzGtIBUoTNaXhkdvufrLn:gSpHcwFmARzGtIBUoTNaXhkdvufrLe =gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('stillcut').get('large')
    if gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('tv_season_stillcut')!=gSpHcwFmARzGtIBUoTNaXhkdvufrLn:gSpHcwFmARzGtIBUoTNaXhkdvufrLE=gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('tv_season_stillcut').get('large')
    gSpHcwFmARzGtIBUoTNaXhkdvufrKb={'thumb':gSpHcwFmARzGtIBUoTNaXhkdvufrLe,'poster':gSpHcwFmARzGtIBUoTNaXhkdvufrKC,'fanart':gSpHcwFmARzGtIBUoTNaXhkdvufrLE,'clearlogo':gSpHcwFmARzGtIBUoTNaXhkdvufrqx}
    gSpHcwFmARzGtIBUoTNaXhkdvufrqj =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['display_number']
    gSpHcwFmARzGtIBUoTNaXhkdvufrqW=gSpHcwFmARzGtIBUoTNaXhkdvufryJ['tv_season_title']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKe =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['duration']
    try:
     gSpHcwFmARzGtIBUoTNaXhkdvufrql=gSpHcwFmARzGtIBUoTNaXhkdvufryJ['episode_number']
    except:
     gSpHcwFmARzGtIBUoTNaXhkdvufrql='0'
    gSpHcwFmARzGtIBUoTNaXhkdvufrKy={'code':gSpHcwFmARzGtIBUoTNaXhkdvufrKM,'title':gSpHcwFmARzGtIBUoTNaXhkdvufrKj,'thumbnail':gSpHcwFmARzGtIBUoTNaXhkdvufrKb,'display_num':gSpHcwFmARzGtIBUoTNaXhkdvufrqj,'season_title':gSpHcwFmARzGtIBUoTNaXhkdvufrqW,'duration':gSpHcwFmARzGtIBUoTNaXhkdvufrKe,'episode_number':gSpHcwFmARzGtIBUoTNaXhkdvufrql}
    gSpHcwFmARzGtIBUoTNaXhkdvufryi.append(gSpHcwFmARzGtIBUoTNaXhkdvufrKy)
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
  return gSpHcwFmARzGtIBUoTNaXhkdvufryi,gSpHcwFmARzGtIBUoTNaXhkdvufrKq
 def GetHomeList(gSpHcwFmARzGtIBUoTNaXhkdvufrDK):
  gSpHcwFmARzGtIBUoTNaXhkdvufrqC=[]
  try:
   gSpHcwFmARzGtIBUoTNaXhkdvufryV ='/api/aio_browses/video/header'
   gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
   gSpHcwFmARzGtIBUoTNaXhkdvufryj=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
   gSpHcwFmARzGtIBUoTNaXhkdvufryL=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.makeDefaultCookies()
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Get',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufryL)
   gSpHcwFmARzGtIBUoTNaXhkdvufrqb=json.loads(gSpHcwFmARzGtIBUoTNaXhkdvufryl.text)
   if not('result' in gSpHcwFmARzGtIBUoTNaXhkdvufrqb):return gSpHcwFmARzGtIBUoTNaXhkdvufrqC
   gSpHcwFmARzGtIBUoTNaXhkdvufryO=gSpHcwFmARzGtIBUoTNaXhkdvufrqb['result'][0]['cells']
   for gSpHcwFmARzGtIBUoTNaXhkdvufryJ in gSpHcwFmARzGtIBUoTNaXhkdvufryO:
    gSpHcwFmARzGtIBUoTNaXhkdvufrKx=gSpHcwFmARzGtIBUoTNaXhkdvufryJ['relations'][0]['type']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKj =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['title']
    gSpHcwFmARzGtIBUoTNaXhkdvufrqV =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['badge']
    gSpHcwFmARzGtIBUoTNaXhkdvufrqs =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['media']['fullhd']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKb ={'thumb':gSpHcwFmARzGtIBUoTNaXhkdvufrqs,'fanart':gSpHcwFmARzGtIBUoTNaXhkdvufrqs}
    gSpHcwFmARzGtIBUoTNaXhkdvufrKM =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['relations'][0]['id']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKy={'code':gSpHcwFmARzGtIBUoTNaXhkdvufrKM,'content_type':gSpHcwFmARzGtIBUoTNaXhkdvufrKx,'title':gSpHcwFmARzGtIBUoTNaXhkdvufrKj,'bedge':gSpHcwFmARzGtIBUoTNaXhkdvufrqV,'thumbnail':gSpHcwFmARzGtIBUoTNaXhkdvufrKb}
    gSpHcwFmARzGtIBUoTNaXhkdvufrqC.append(gSpHcwFmARzGtIBUoTNaXhkdvufrKy)
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
  return gSpHcwFmARzGtIBUoTNaXhkdvufrqC
 def GetSearchList(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,search_key,page_int):
  gSpHcwFmARzGtIBUoTNaXhkdvufrqP=[]
  gSpHcwFmARzGtIBUoTNaXhkdvufrKq=gSpHcwFmARzGtIBUoTNaXhkdvufrLO
  try:
   gSpHcwFmARzGtIBUoTNaXhkdvufryV ='/api/search.json'
   gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
   gSpHcwFmARzGtIBUoTNaXhkdvufrKL={'query':search_key,'page':gSpHcwFmARzGtIBUoTNaXhkdvufrMD(page_int),'per':gSpHcwFmARzGtIBUoTNaXhkdvufrMD(gSpHcwFmARzGtIBUoTNaXhkdvufrDK.SEARCH_LIMIT),'exclude':'limited'}
   gSpHcwFmARzGtIBUoTNaXhkdvufryj=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Get',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrKL,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufrLn)
   gSpHcwFmARzGtIBUoTNaXhkdvufryn=json.loads(gSpHcwFmARzGtIBUoTNaXhkdvufryl.text)
   if not('results' in gSpHcwFmARzGtIBUoTNaXhkdvufryn):return gSpHcwFmARzGtIBUoTNaXhkdvufrqP,gSpHcwFmARzGtIBUoTNaXhkdvufrKq
   gSpHcwFmARzGtIBUoTNaXhkdvufryO=gSpHcwFmARzGtIBUoTNaXhkdvufryn['results']
   gSpHcwFmARzGtIBUoTNaXhkdvufrKq=gSpHcwFmARzGtIBUoTNaXhkdvufryn['meta']['has_next']
   for gSpHcwFmARzGtIBUoTNaXhkdvufryJ in gSpHcwFmARzGtIBUoTNaXhkdvufryO:
    gSpHcwFmARzGtIBUoTNaXhkdvufrKM =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['code']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKx=gSpHcwFmARzGtIBUoTNaXhkdvufryJ['content_type']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKj =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['title']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKW =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['story']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKC=gSpHcwFmARzGtIBUoTNaXhkdvufrLe=gSpHcwFmARzGtIBUoTNaXhkdvufrLE=''
    if gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('poster') !=gSpHcwFmARzGtIBUoTNaXhkdvufrLn:gSpHcwFmARzGtIBUoTNaXhkdvufrKC=gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('poster').get('original')
    if gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('stillcut')!=gSpHcwFmARzGtIBUoTNaXhkdvufrLn:gSpHcwFmARzGtIBUoTNaXhkdvufrLe =gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('stillcut').get('large')
    if gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('thumbnail')!=gSpHcwFmARzGtIBUoTNaXhkdvufrLn:gSpHcwFmARzGtIBUoTNaXhkdvufrLE=gSpHcwFmARzGtIBUoTNaXhkdvufryJ.get('thumbnail').get('large')
    if gSpHcwFmARzGtIBUoTNaXhkdvufrLE=='' :gSpHcwFmARzGtIBUoTNaXhkdvufrLE=gSpHcwFmARzGtIBUoTNaXhkdvufrLe
    gSpHcwFmARzGtIBUoTNaXhkdvufrKb={'thumb':gSpHcwFmARzGtIBUoTNaXhkdvufrLe,'poster':gSpHcwFmARzGtIBUoTNaXhkdvufrKC,'fanart':gSpHcwFmARzGtIBUoTNaXhkdvufrLE}
    gSpHcwFmARzGtIBUoTNaXhkdvufrKV =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['year']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKs =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['film_rating_code']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKP=gSpHcwFmARzGtIBUoTNaXhkdvufryJ['film_rating_short']
    gSpHcwFmARzGtIBUoTNaXhkdvufrKE =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['film_rating_long']
    if gSpHcwFmARzGtIBUoTNaXhkdvufrKx=='movies':
     gSpHcwFmARzGtIBUoTNaXhkdvufrKe =gSpHcwFmARzGtIBUoTNaXhkdvufryJ['duration']
    else:
     gSpHcwFmARzGtIBUoTNaXhkdvufrKe ='0'
    gSpHcwFmARzGtIBUoTNaXhkdvufrKy={'code':gSpHcwFmARzGtIBUoTNaXhkdvufrKM,'content_type':gSpHcwFmARzGtIBUoTNaXhkdvufrKx,'title':gSpHcwFmARzGtIBUoTNaXhkdvufrKj,'story':gSpHcwFmARzGtIBUoTNaXhkdvufrKW,'thumbnail':gSpHcwFmARzGtIBUoTNaXhkdvufrKb,'year':gSpHcwFmARzGtIBUoTNaXhkdvufrKV,'film_rating_code':gSpHcwFmARzGtIBUoTNaXhkdvufrKs,'film_rating_short':gSpHcwFmARzGtIBUoTNaXhkdvufrKP,'film_rating_long':gSpHcwFmARzGtIBUoTNaXhkdvufrKE,'duration':gSpHcwFmARzGtIBUoTNaXhkdvufrKe}
    gSpHcwFmARzGtIBUoTNaXhkdvufrqP.append(gSpHcwFmARzGtIBUoTNaXhkdvufrKy)
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
  return gSpHcwFmARzGtIBUoTNaXhkdvufrqP,gSpHcwFmARzGtIBUoTNaXhkdvufrKq
 def DeleteContinueList(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,codeList):
  try:
   for gSpHcwFmARzGtIBUoTNaXhkdvufrqE in codeList:
    gSpHcwFmARzGtIBUoTNaXhkdvufryV ='/api/watches/'+gSpHcwFmARzGtIBUoTNaXhkdvufrqE
    gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
    gSpHcwFmARzGtIBUoTNaXhkdvufryj =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
    gSpHcwFmARzGtIBUoTNaXhkdvufryC =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.makeDefaultCookies()
    gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Delete',gSpHcwFmARzGtIBUoTNaXhkdvufrys,params=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufryC)
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   gSpHcwFmARzGtIBUoTNaXhkdvufrMq(exception)
 def Get_Now_Datetime(gSpHcwFmARzGtIBUoTNaXhkdvufrDK):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,movie_code,quality_str,proxyUse=gSpHcwFmARzGtIBUoTNaXhkdvufrLO,inScreen='BASE',inSound='2CH'):
  gSpHcwFmARzGtIBUoTNaXhkdvufrqi={'streamUrl':'','subtitleUrl':'','customdata':'',}
  try:
   if proxyUse:
    gSpHcwFmARzGtIBUoTNaXhkdvufrqn ='0' if inScreen=='BASE' and inSound=='2CH' else '3'
    gSpHcwFmARzGtIBUoTNaXhkdvufrqO='4' if inScreen=='VISION' else '1'
    gSpHcwFmARzGtIBUoTNaXhkdvufrqJ ='0' if inSound!='ATMOS' else '1'
    gSpHcwFmARzGtIBUoTNaXhkdvufrMq('hCodec  = '+gSpHcwFmARzGtIBUoTNaXhkdvufrqn)
    gSpHcwFmARzGtIBUoTNaXhkdvufrMq('hScreen = '+gSpHcwFmARzGtIBUoTNaXhkdvufrqO)
    gSpHcwFmARzGtIBUoTNaXhkdvufrMq('hSound  = '+gSpHcwFmARzGtIBUoTNaXhkdvufrqJ)
    gSpHcwFmARzGtIBUoTNaXhkdvufryV='/api/watch/'+movie_code+'.json?localtracks=%5B%5D&player_v2=true'
    gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
    gSpHcwFmARzGtIBUoTNaXhkdvufryj=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers_v2()
    gSpHcwFmARzGtIBUoTNaXhkdvufryW={'X-FROGRAMS-MARS-CODEC-FLAG':gSpHcwFmARzGtIBUoTNaXhkdvufrqn,'X-WatchaPlay-Client-Codec-Flag':gSpHcwFmARzGtIBUoTNaXhkdvufrqn,'X-FROGRAMS-MARS-HDR-CAPABILITIES':gSpHcwFmARzGtIBUoTNaXhkdvufrqO,'X-WatchaPlay-Client-HDR-Capabilities':gSpHcwFmARzGtIBUoTNaXhkdvufrqO,'X-FROGRAMS-MARS-AUDIO-CAPABILITIES':gSpHcwFmARzGtIBUoTNaXhkdvufrqJ,'X-WatchaPlay-Client-Audio-Capabilities':gSpHcwFmARzGtIBUoTNaXhkdvufrqJ,}
    gSpHcwFmARzGtIBUoTNaXhkdvufryj.update(gSpHcwFmARzGtIBUoTNaXhkdvufryW)
   else:
    gSpHcwFmARzGtIBUoTNaXhkdvufryV='/api/watch/'+movie_code+'.json'
    gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+gSpHcwFmARzGtIBUoTNaXhkdvufryV
    gSpHcwFmARzGtIBUoTNaXhkdvufryj=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
    gSpHcwFmARzGtIBUoTNaXhkdvufryW={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str,}
    gSpHcwFmARzGtIBUoTNaXhkdvufryj.update(gSpHcwFmARzGtIBUoTNaXhkdvufryW)
   gSpHcwFmARzGtIBUoTNaXhkdvufryC=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.makeDefaultCookies()
   gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Get',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufryC)
   gSpHcwFmARzGtIBUoTNaXhkdvufryn=json.loads(gSpHcwFmARzGtIBUoTNaXhkdvufryl.text)
   gSpHcwFmARzGtIBUoTNaXhkdvufrqi['streamUrl']=gSpHcwFmARzGtIBUoTNaXhkdvufryn['streams'][0]['source']
   if gSpHcwFmARzGtIBUoTNaXhkdvufrqi['streamUrl']==gSpHcwFmARzGtIBUoTNaXhkdvufrLn:return gSpHcwFmARzGtIBUoTNaXhkdvufrqi
   if 'subtitles' in gSpHcwFmARzGtIBUoTNaXhkdvufryn['streams'][0]:
    for gSpHcwFmARzGtIBUoTNaXhkdvufrqQ in gSpHcwFmARzGtIBUoTNaXhkdvufryn['streams'][0]['subtitles']:
     if gSpHcwFmARzGtIBUoTNaXhkdvufrqQ['lang']=='ko':
      gSpHcwFmARzGtIBUoTNaXhkdvufrqi['subtitleUrl']=gSpHcwFmARzGtIBUoTNaXhkdvufrqQ['url']
      break
   gSpHcwFmARzGtIBUoTNaXhkdvufrqY =gSpHcwFmARzGtIBUoTNaXhkdvufryn['ping_payload']
   gSpHcwFmARzGtIBUoTNaXhkdvufrLD =gSpHcwFmARzGtIBUoTNaXhkdvufrDK.WC['cookies']['watcha_usercd']
   gSpHcwFmARzGtIBUoTNaXhkdvufrLy={'merchant':'giitd_frograms','sessionId':gSpHcwFmARzGtIBUoTNaXhkdvufrqY,'userId':gSpHcwFmARzGtIBUoTNaXhkdvufrLD}
   gSpHcwFmARzGtIBUoTNaXhkdvufrLK=json.dumps(gSpHcwFmARzGtIBUoTNaXhkdvufrLy,separators=(",",":")).encode('UTF-8')
   gSpHcwFmARzGtIBUoTNaXhkdvufrqi['customdata']=base64.b64encode(gSpHcwFmARzGtIBUoTNaXhkdvufrLK)
  except gSpHcwFmARzGtIBUoTNaXhkdvufrMK as exception:
   return gSpHcwFmARzGtIBUoTNaXhkdvufrqi
  return gSpHcwFmARzGtIBUoTNaXhkdvufrqi
 def GetBookmarkInfo(gSpHcwFmARzGtIBUoTNaXhkdvufrDK,videoid,vidtype):
  gSpHcwFmARzGtIBUoTNaXhkdvufrLq={'indexinfo':{'ott':'watcha','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  gSpHcwFmARzGtIBUoTNaXhkdvufrys=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.API_DOMAIN+'/api/contents/'+videoid
  gSpHcwFmARzGtIBUoTNaXhkdvufryj=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.Get_Base_Headers()
  gSpHcwFmARzGtIBUoTNaXhkdvufryl=gSpHcwFmARzGtIBUoTNaXhkdvufrDK.callRequestCookies('Get',gSpHcwFmARzGtIBUoTNaXhkdvufrys,payload=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,params=gSpHcwFmARzGtIBUoTNaXhkdvufrLn,headers=gSpHcwFmARzGtIBUoTNaXhkdvufryj,cookies=gSpHcwFmARzGtIBUoTNaXhkdvufrLn)
  gSpHcwFmARzGtIBUoTNaXhkdvufrqb=json.loads(gSpHcwFmARzGtIBUoTNaXhkdvufryl.text)
  if not('title' in gSpHcwFmARzGtIBUoTNaXhkdvufrqb):return{}
  gSpHcwFmARzGtIBUoTNaXhkdvufrLM=gSpHcwFmARzGtIBUoTNaXhkdvufrqb
  gSpHcwFmARzGtIBUoTNaXhkdvufrMq(gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('duration'))
  gSpHcwFmARzGtIBUoTNaXhkdvufrLx=gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('title')
  gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['infoLabels']['title']=gSpHcwFmARzGtIBUoTNaXhkdvufrLx
  gSpHcwFmARzGtIBUoTNaXhkdvufrLx +=u'  (%s)'%(gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('year'))
  gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['title'] =gSpHcwFmARzGtIBUoTNaXhkdvufrLx
  gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['infoLabels']['mpaa'] =gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('film_rating_long')
  gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['infoLabels']['plot'] =gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('story').replace('<br>','\n')
  gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['infoLabels']['year'] =gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('year')
  if vidtype=='movie':
   gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['infoLabels']['duration']=gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('duration')
  gSpHcwFmARzGtIBUoTNaXhkdvufrLj=[]
  for gSpHcwFmARzGtIBUoTNaXhkdvufrLW in gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('actors'):
   gSpHcwFmARzGtIBUoTNaXhkdvufrLl =gSpHcwFmARzGtIBUoTNaXhkdvufrLW.get('name')
   gSpHcwFmARzGtIBUoTNaXhkdvufrLC='' if gSpHcwFmARzGtIBUoTNaXhkdvufrLW.get('photo')==gSpHcwFmARzGtIBUoTNaXhkdvufrLn else gSpHcwFmARzGtIBUoTNaXhkdvufrLW.get('photo').get('small')
   gSpHcwFmARzGtIBUoTNaXhkdvufrLj.append({'name':gSpHcwFmARzGtIBUoTNaXhkdvufrLl,'thumbnail':gSpHcwFmARzGtIBUoTNaXhkdvufrLC})
  if gSpHcwFmARzGtIBUoTNaXhkdvufrMx(gSpHcwFmARzGtIBUoTNaXhkdvufrLj)>0:
   gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['infoLabels']['cast']=gSpHcwFmARzGtIBUoTNaXhkdvufrLj
  gSpHcwFmARzGtIBUoTNaXhkdvufrLb=[]
  for gSpHcwFmARzGtIBUoTNaXhkdvufrLV in gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('directors'):gSpHcwFmARzGtIBUoTNaXhkdvufrLb.append(gSpHcwFmARzGtIBUoTNaXhkdvufrLV.get('name'))
  if gSpHcwFmARzGtIBUoTNaXhkdvufrMx(gSpHcwFmARzGtIBUoTNaXhkdvufrLb)>0:
   gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['infoLabels']['director']=gSpHcwFmARzGtIBUoTNaXhkdvufrLb
  gSpHcwFmARzGtIBUoTNaXhkdvufrLs=[]
  for gSpHcwFmARzGtIBUoTNaXhkdvufrLP in gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('genres'):gSpHcwFmARzGtIBUoTNaXhkdvufrLs.append(gSpHcwFmARzGtIBUoTNaXhkdvufrLP.get('name'))
  if gSpHcwFmARzGtIBUoTNaXhkdvufrMx(gSpHcwFmARzGtIBUoTNaXhkdvufrLs)>0:
   gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['infoLabels']['genre']=gSpHcwFmARzGtIBUoTNaXhkdvufrLs
  gSpHcwFmARzGtIBUoTNaXhkdvufrKC =''
  gSpHcwFmARzGtIBUoTNaXhkdvufrLE =''
  gSpHcwFmARzGtIBUoTNaXhkdvufrLe =''
  if gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('poster') !=gSpHcwFmARzGtIBUoTNaXhkdvufrLn:gSpHcwFmARzGtIBUoTNaXhkdvufrKC =gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('poster').get('original')
  if gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('thumbnail')!=gSpHcwFmARzGtIBUoTNaXhkdvufrLn:gSpHcwFmARzGtIBUoTNaXhkdvufrLE =gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('thumbnail').get('large')
  if gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('stillcut')!=gSpHcwFmARzGtIBUoTNaXhkdvufrLn:gSpHcwFmARzGtIBUoTNaXhkdvufrLe =gSpHcwFmARzGtIBUoTNaXhkdvufrLM.get('stillcut').get('large')
  if gSpHcwFmARzGtIBUoTNaXhkdvufrLE=='':gSpHcwFmARzGtIBUoTNaXhkdvufrLE=gSpHcwFmARzGtIBUoTNaXhkdvufrLe
  gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['thumbnail']['poster']=gSpHcwFmARzGtIBUoTNaXhkdvufrKC
  gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['thumbnail']['fanart']=gSpHcwFmARzGtIBUoTNaXhkdvufrLE
  gSpHcwFmARzGtIBUoTNaXhkdvufrLq['saveinfo']['thumbnail']['thumb']=gSpHcwFmARzGtIBUoTNaXhkdvufrLe
  return gSpHcwFmARzGtIBUoTNaXhkdvufrLq
# Created by pyminifier (https://github.com/liftoff/pyminifier)
