__author__="NightRain"
JOCUSKLMEqQABPWybIjRhvXkrDgYsd=object
JOCUSKLMEqQABPWybIjRhvXkrDgYsn=None
JOCUSKLMEqQABPWybIjRhvXkrDgYse=int
JOCUSKLMEqQABPWybIjRhvXkrDgYsz=True
JOCUSKLMEqQABPWybIjRhvXkrDgYsx=False
JOCUSKLMEqQABPWybIjRhvXkrDgYsN=type
JOCUSKLMEqQABPWybIjRhvXkrDgYsp=dict
JOCUSKLMEqQABPWybIjRhvXkrDgYsw=len
JOCUSKLMEqQABPWybIjRhvXkrDgYsc=range
JOCUSKLMEqQABPWybIjRhvXkrDgYst=str
JOCUSKLMEqQABPWybIjRhvXkrDgYso=open
from ast import Pass
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
JOCUSKLMEqQABPWybIjRhvXkrDgYfH=[{'title':'홈','mode':'HOME_GROUP','stype':'-','api_path':'-'},{'title':'오직 왓챠에서!','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/6100'},{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410'},{'title':'4K / HDR, ATOMOS 지원작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/3025'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest'},{'title':'장르별 둘러보기','mode':'SUB_GROUP','stype':'genres','api_path':'-'},{'title':'특징별 둘러보기','mode':'SUB_GROUP','stype':'tags','api_path':'-'},{'title':'이어보기 (시청이력)','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','icon':'bookmark.png'},]
JOCUSKLMEqQABPWybIjRhvXkrDgYfa=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
JOCUSKLMEqQABPWybIjRhvXkrDgYfG=40
JOCUSKLMEqQABPWybIjRhvXkrDgYfd =30
from watchaCore import*
class JOCUSKLMEqQABPWybIjRhvXkrDgYfV(JOCUSKLMEqQABPWybIjRhvXkrDgYsd):
 def __init__(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,JOCUSKLMEqQABPWybIjRhvXkrDgYfs,JOCUSKLMEqQABPWybIjRhvXkrDgYfe,JOCUSKLMEqQABPWybIjRhvXkrDgYfz):
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_url =JOCUSKLMEqQABPWybIjRhvXkrDgYfs
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle=JOCUSKLMEqQABPWybIjRhvXkrDgYfe
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params =JOCUSKLMEqQABPWybIjRhvXkrDgYfz
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj =gSpHcwFmARzGtIBUoTNaXhkdvufrDy() 
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_SUBTITLE_VTT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_SUBTITLE_SRT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.srt'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_COOKIE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_SEARCHEDC_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wc_stream.mpd'))
 def addon_noti(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,sting):
  try:
   JOCUSKLMEqQABPWybIjRhvXkrDgYfN=xbmcgui.Dialog()
   JOCUSKLMEqQABPWybIjRhvXkrDgYfN.notification(__addonname__,sting)
  except:
   JOCUSKLMEqQABPWybIjRhvXkrDgYsn
 def addon_log(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,string):
  try:
   JOCUSKLMEqQABPWybIjRhvXkrDgYfp=string.encode('utf-8','ignore')
  except:
   JOCUSKLMEqQABPWybIjRhvXkrDgYfp='addonException: addon_log'
  JOCUSKLMEqQABPWybIjRhvXkrDgYfw=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,JOCUSKLMEqQABPWybIjRhvXkrDgYfp),level=JOCUSKLMEqQABPWybIjRhvXkrDgYfw)
 def get_keyboard_input(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,JOCUSKLMEqQABPWybIjRhvXkrDgYVc):
  JOCUSKLMEqQABPWybIjRhvXkrDgYfc=JOCUSKLMEqQABPWybIjRhvXkrDgYsn
  kb=xbmc.Keyboard()
  kb.setHeading(JOCUSKLMEqQABPWybIjRhvXkrDgYVc)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   JOCUSKLMEqQABPWybIjRhvXkrDgYfc=kb.getText()
  return JOCUSKLMEqQABPWybIjRhvXkrDgYfc
 def get_settings_account(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  JOCUSKLMEqQABPWybIjRhvXkrDgYft =__addon__.getSetting('id')
  JOCUSKLMEqQABPWybIjRhvXkrDgYfo =__addon__.getSetting('pw')
  JOCUSKLMEqQABPWybIjRhvXkrDgYfT=JOCUSKLMEqQABPWybIjRhvXkrDgYse(__addon__.getSetting('selected_profile'))
  return(JOCUSKLMEqQABPWybIjRhvXkrDgYft,JOCUSKLMEqQABPWybIjRhvXkrDgYfo,JOCUSKLMEqQABPWybIjRhvXkrDgYfT)
 def get_settings_totalsearch(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  JOCUSKLMEqQABPWybIjRhvXkrDgYfl =JOCUSKLMEqQABPWybIjRhvXkrDgYsz if __addon__.getSetting('local_search')=='true' else JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  JOCUSKLMEqQABPWybIjRhvXkrDgYfi=JOCUSKLMEqQABPWybIjRhvXkrDgYsz if __addon__.getSetting('local_history')=='true' else JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  JOCUSKLMEqQABPWybIjRhvXkrDgYfm =JOCUSKLMEqQABPWybIjRhvXkrDgYsz if __addon__.getSetting('total_search')=='true' else JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  JOCUSKLMEqQABPWybIjRhvXkrDgYfF=JOCUSKLMEqQABPWybIjRhvXkrDgYsz if __addon__.getSetting('total_history')=='true' else JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  JOCUSKLMEqQABPWybIjRhvXkrDgYfu=JOCUSKLMEqQABPWybIjRhvXkrDgYsz if __addon__.getSetting('menu_bookmark')=='true' else JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  return(JOCUSKLMEqQABPWybIjRhvXkrDgYfl,JOCUSKLMEqQABPWybIjRhvXkrDgYfi,JOCUSKLMEqQABPWybIjRhvXkrDgYfm,JOCUSKLMEqQABPWybIjRhvXkrDgYfF,JOCUSKLMEqQABPWybIjRhvXkrDgYfu)
 def get_settings_makebookmark(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  return JOCUSKLMEqQABPWybIjRhvXkrDgYsz if __addon__.getSetting('make_bookmark')=='true' else JOCUSKLMEqQABPWybIjRhvXkrDgYsx
 def get_settings_proxyport(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  JOCUSKLMEqQABPWybIjRhvXkrDgYVf =JOCUSKLMEqQABPWybIjRhvXkrDgYsz if __addon__.getSetting('proxyYn')=='true' else JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  JOCUSKLMEqQABPWybIjRhvXkrDgYVH=JOCUSKLMEqQABPWybIjRhvXkrDgYse(__addon__.getSetting('proxyPort'))
  return JOCUSKLMEqQABPWybIjRhvXkrDgYVf,JOCUSKLMEqQABPWybIjRhvXkrDgYVH
 def get_settings_playback(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  JOCUSKLMEqQABPWybIjRhvXkrDgYVa=[3840,1920,1280]
  JOCUSKLMEqQABPWybIjRhvXkrDgYVG =['BASE','HDR','VISION']
  JOCUSKLMEqQABPWybIjRhvXkrDgYVd =['2CH','6CH','ATMOS']
  JOCUSKLMEqQABPWybIjRhvXkrDgYVn=JOCUSKLMEqQABPWybIjRhvXkrDgYse(__addon__.getSetting('selected_quality'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYVs =JOCUSKLMEqQABPWybIjRhvXkrDgYse(__addon__.getSetting('selected_screen'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYVe =JOCUSKLMEqQABPWybIjRhvXkrDgYse(__addon__.getSetting('selected_sound'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYVz={'max_quality':JOCUSKLMEqQABPWybIjRhvXkrDgYVa[JOCUSKLMEqQABPWybIjRhvXkrDgYVn],'sel_screen':JOCUSKLMEqQABPWybIjRhvXkrDgYVG[JOCUSKLMEqQABPWybIjRhvXkrDgYVs],'sel_sound':JOCUSKLMEqQABPWybIjRhvXkrDgYVd[JOCUSKLMEqQABPWybIjRhvXkrDgYVe],'streamFilename':JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_STREAM_FILENAME,}
  return JOCUSKLMEqQABPWybIjRhvXkrDgYVz
 def Base64_Encode(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,plaintext):
  return base64.standard_b64encode(plaintext.encode()).decode('utf-8')
 def Params_JsonToStr(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,paramJson):
  JOCUSKLMEqQABPWybIjRhvXkrDgYVx=json.dumps(paramJson,separators=(',',':'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYVx=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.Base64_Encode(JOCUSKLMEqQABPWybIjRhvXkrDgYVx)
  return JOCUSKLMEqQABPWybIjRhvXkrDgYVx
 def get_selQuality(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  try:
   JOCUSKLMEqQABPWybIjRhvXkrDgYVa=['3840x2160/2.0/320/xhdpi','1920x1080/2.0/320/xhdpi','1280x720/2.0/320/xhdpi']
   JOCUSKLMEqQABPWybIjRhvXkrDgYVn=JOCUSKLMEqQABPWybIjRhvXkrDgYse(__addon__.getSetting('selected_quality'))
   return JOCUSKLMEqQABPWybIjRhvXkrDgYVa[JOCUSKLMEqQABPWybIjRhvXkrDgYVn]
  except:
   JOCUSKLMEqQABPWybIjRhvXkrDgYsn
  return 1080 
 def get_settings_direct_replay(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  JOCUSKLMEqQABPWybIjRhvXkrDgYVN=JOCUSKLMEqQABPWybIjRhvXkrDgYse(__addon__.getSetting('direct_replay'))
  if JOCUSKLMEqQABPWybIjRhvXkrDgYVN==0:
   return JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  else:
   return JOCUSKLMEqQABPWybIjRhvXkrDgYsz
 def set_winEpisodeOrderby(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,JOCUSKLMEqQABPWybIjRhvXkrDgYVp):
  __addon__.setSetting('watcha_orderby',JOCUSKLMEqQABPWybIjRhvXkrDgYVp)
 def get_winEpisodeOrderby(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  JOCUSKLMEqQABPWybIjRhvXkrDgYVp=__addon__.getSetting('watcha_orderby')
  if JOCUSKLMEqQABPWybIjRhvXkrDgYVp in['',JOCUSKLMEqQABPWybIjRhvXkrDgYsn]:JOCUSKLMEqQABPWybIjRhvXkrDgYVp='asc'
  return JOCUSKLMEqQABPWybIjRhvXkrDgYVp
 def dp_setEpOrderby(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYVp =args.get('orderby')
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.set_winEpisodeOrderby(JOCUSKLMEqQABPWybIjRhvXkrDgYVp)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,label,sublabel='',img='',infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsz,params='',isLink=JOCUSKLMEqQABPWybIjRhvXkrDgYsx,ContextMenu=JOCUSKLMEqQABPWybIjRhvXkrDgYsn):
  JOCUSKLMEqQABPWybIjRhvXkrDgYVw='%s?%s'%(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_url,urllib.parse.urlencode(params))
  if sublabel:JOCUSKLMEqQABPWybIjRhvXkrDgYVc='%s < %s >'%(label,sublabel)
  else: JOCUSKLMEqQABPWybIjRhvXkrDgYVc=label
  if not img:img='DefaultFolder.png'
  JOCUSKLMEqQABPWybIjRhvXkrDgYVt=xbmcgui.ListItem(JOCUSKLMEqQABPWybIjRhvXkrDgYVc)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYsN(img)==JOCUSKLMEqQABPWybIjRhvXkrDgYsp:
   JOCUSKLMEqQABPWybIjRhvXkrDgYVt.setArt(img)
  else:
   JOCUSKLMEqQABPWybIjRhvXkrDgYVt.setArt({'thumb':img,'poster':img})
  if infoLabels:JOCUSKLMEqQABPWybIjRhvXkrDgYVt.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   JOCUSKLMEqQABPWybIjRhvXkrDgYVt.setProperty('IsPlayable','true')
  if ContextMenu:JOCUSKLMEqQABPWybIjRhvXkrDgYVt.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,JOCUSKLMEqQABPWybIjRhvXkrDgYVw,JOCUSKLMEqQABPWybIjRhvXkrDgYVt,isFolder)
 def dp_Main_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  (JOCUSKLMEqQABPWybIjRhvXkrDgYfl,JOCUSKLMEqQABPWybIjRhvXkrDgYfi,JOCUSKLMEqQABPWybIjRhvXkrDgYfm,JOCUSKLMEqQABPWybIjRhvXkrDgYfF,JOCUSKLMEqQABPWybIjRhvXkrDgYfu)=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_settings_totalsearch()
  for JOCUSKLMEqQABPWybIjRhvXkrDgYVo in JOCUSKLMEqQABPWybIjRhvXkrDgYfH:
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc=JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('title')
   JOCUSKLMEqQABPWybIjRhvXkrDgYVT=''
   if JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('mode')=='LOCAL_SEARCH' and JOCUSKLMEqQABPWybIjRhvXkrDgYfl ==JOCUSKLMEqQABPWybIjRhvXkrDgYsx:continue
   elif JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('mode')=='SEARCH_HISTORY' and JOCUSKLMEqQABPWybIjRhvXkrDgYfi==JOCUSKLMEqQABPWybIjRhvXkrDgYsx:continue
   elif JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('mode')=='TOTAL_SEARCH' and JOCUSKLMEqQABPWybIjRhvXkrDgYfm ==JOCUSKLMEqQABPWybIjRhvXkrDgYsx:continue
   elif JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('mode')=='TOTAL_HISTORY' and JOCUSKLMEqQABPWybIjRhvXkrDgYfF==JOCUSKLMEqQABPWybIjRhvXkrDgYsx:continue
   elif JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('mode')=='MENU_BOOKMARK' and JOCUSKLMEqQABPWybIjRhvXkrDgYfu==JOCUSKLMEqQABPWybIjRhvXkrDgYsx:continue
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('mode'),'stype':JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('stype'),'api_path':JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('api_path'),'page':'1','tag_id':'-',}
   if JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('mode')=='LOCAL_SEARCH':JOCUSKLMEqQABPWybIjRhvXkrDgYVl['historyyn']='Y' 
   if JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    JOCUSKLMEqQABPWybIjRhvXkrDgYVi=JOCUSKLMEqQABPWybIjRhvXkrDgYsx
    JOCUSKLMEqQABPWybIjRhvXkrDgYVm =JOCUSKLMEqQABPWybIjRhvXkrDgYsz
   else:
    JOCUSKLMEqQABPWybIjRhvXkrDgYVi=JOCUSKLMEqQABPWybIjRhvXkrDgYsz
    JOCUSKLMEqQABPWybIjRhvXkrDgYVm =JOCUSKLMEqQABPWybIjRhvXkrDgYsx
   if 'icon' in JOCUSKLMEqQABPWybIjRhvXkrDgYVo:JOCUSKLMEqQABPWybIjRhvXkrDgYVT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',JOCUSKLMEqQABPWybIjRhvXkrDgYVo.get('icon')) 
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel='',img=JOCUSKLMEqQABPWybIjRhvXkrDgYVT,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYVi,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl,isLink=JOCUSKLMEqQABPWybIjRhvXkrDgYVm)
  xbmcplugin.endOfDirectory(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle)
 def login_main(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  (JOCUSKLMEqQABPWybIjRhvXkrDgYVu,JOCUSKLMEqQABPWybIjRhvXkrDgYHf,JOCUSKLMEqQABPWybIjRhvXkrDgYHV)=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_settings_account()
  if not(JOCUSKLMEqQABPWybIjRhvXkrDgYVu and JOCUSKLMEqQABPWybIjRhvXkrDgYHf):
   JOCUSKLMEqQABPWybIjRhvXkrDgYfN=xbmcgui.Dialog()
   JOCUSKLMEqQABPWybIjRhvXkrDgYHa=JOCUSKLMEqQABPWybIjRhvXkrDgYfN.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if JOCUSKLMEqQABPWybIjRhvXkrDgYHa==JOCUSKLMEqQABPWybIjRhvXkrDgYsz:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if JOCUSKLMEqQABPWybIjRhvXkrDgYfn.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   JOCUSKLMEqQABPWybIjRhvXkrDgYHG=0
   while JOCUSKLMEqQABPWybIjRhvXkrDgYsz:
    JOCUSKLMEqQABPWybIjRhvXkrDgYHG+=1
    time.sleep(0.05)
    if JOCUSKLMEqQABPWybIjRhvXkrDgYHG>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  JOCUSKLMEqQABPWybIjRhvXkrDgYHd=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.GetCredential(JOCUSKLMEqQABPWybIjRhvXkrDgYVu,JOCUSKLMEqQABPWybIjRhvXkrDgYHf,JOCUSKLMEqQABPWybIjRhvXkrDgYHV)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYHd:JOCUSKLMEqQABPWybIjRhvXkrDgYfn.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
  if JOCUSKLMEqQABPWybIjRhvXkrDgYHd==JOCUSKLMEqQABPWybIjRhvXkrDgYsx:
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_HomeGroup_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYHn=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.GetHomeList()
  for JOCUSKLMEqQABPWybIjRhvXkrDgYHs in JOCUSKLMEqQABPWybIjRhvXkrDgYHn:
   JOCUSKLMEqQABPWybIjRhvXkrDgYHe =JOCUSKLMEqQABPWybIjRhvXkrDgYHs.get('code')
   JOCUSKLMEqQABPWybIjRhvXkrDgYHz=JOCUSKLMEqQABPWybIjRhvXkrDgYHs.get('content_type')
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc =JOCUSKLMEqQABPWybIjRhvXkrDgYHs.get('title')
   JOCUSKLMEqQABPWybIjRhvXkrDgYHx =JOCUSKLMEqQABPWybIjRhvXkrDgYHs.get('bedge')
   JOCUSKLMEqQABPWybIjRhvXkrDgYHN =JOCUSKLMEqQABPWybIjRhvXkrDgYHs.get('thumbnail')
   if JOCUSKLMEqQABPWybIjRhvXkrDgYHz=='staffmades':
    JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'CATEGORY_LIST','api_path':'staffmades/'+JOCUSKLMEqQABPWybIjRhvXkrDgYHe,'page':'1',}
    JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel=JOCUSKLMEqQABPWybIjRhvXkrDgYHx,img=JOCUSKLMEqQABPWybIjRhvXkrDgYHN,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsz,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl)
   elif JOCUSKLMEqQABPWybIjRhvXkrDgYHz=='contents':
    JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'EPISODE','movie_code':JOCUSKLMEqQABPWybIjRhvXkrDgYHe,'page':'1','season_code':JOCUSKLMEqQABPWybIjRhvXkrDgYHe,'title':JOCUSKLMEqQABPWybIjRhvXkrDgYVc,'thumbnail':JOCUSKLMEqQABPWybIjRhvXkrDgYHN,}
    JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel=JOCUSKLMEqQABPWybIjRhvXkrDgYHx,img=JOCUSKLMEqQABPWybIjRhvXkrDgYHN,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsz,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl)
   else:
    JOCUSKLMEqQABPWybIjRhvXkrDgYHp
  xbmcplugin.endOfDirectory(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,cacheToDisc=JOCUSKLMEqQABPWybIjRhvXkrDgYsz)
 def dp_SubGroup_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYHc =args.get('stype')
  JOCUSKLMEqQABPWybIjRhvXkrDgYHt =JOCUSKLMEqQABPWybIjRhvXkrDgYse(args.get('page'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYHo=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.GetSubGroupList(JOCUSKLMEqQABPWybIjRhvXkrDgYHc)
  JOCUSKLMEqQABPWybIjRhvXkrDgYHT=JOCUSKLMEqQABPWybIjRhvXkrDgYfG if JOCUSKLMEqQABPWybIjRhvXkrDgYHc=='genres' else JOCUSKLMEqQABPWybIjRhvXkrDgYfd
  JOCUSKLMEqQABPWybIjRhvXkrDgYHl=JOCUSKLMEqQABPWybIjRhvXkrDgYsw(JOCUSKLMEqQABPWybIjRhvXkrDgYHo)
  JOCUSKLMEqQABPWybIjRhvXkrDgYHi =JOCUSKLMEqQABPWybIjRhvXkrDgYse(JOCUSKLMEqQABPWybIjRhvXkrDgYHl//(JOCUSKLMEqQABPWybIjRhvXkrDgYHT+1))+1
  JOCUSKLMEqQABPWybIjRhvXkrDgYHm =(JOCUSKLMEqQABPWybIjRhvXkrDgYHt-1)*JOCUSKLMEqQABPWybIjRhvXkrDgYHT
  for i in JOCUSKLMEqQABPWybIjRhvXkrDgYsc(JOCUSKLMEqQABPWybIjRhvXkrDgYHT):
   JOCUSKLMEqQABPWybIjRhvXkrDgYHF=JOCUSKLMEqQABPWybIjRhvXkrDgYHm+i
   if JOCUSKLMEqQABPWybIjRhvXkrDgYHF>=JOCUSKLMEqQABPWybIjRhvXkrDgYHl:break
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc =JOCUSKLMEqQABPWybIjRhvXkrDgYHo[JOCUSKLMEqQABPWybIjRhvXkrDgYHF].get('group_name')
   JOCUSKLMEqQABPWybIjRhvXkrDgYHu =JOCUSKLMEqQABPWybIjRhvXkrDgYHo[JOCUSKLMEqQABPWybIjRhvXkrDgYHF].get('api_path')
   JOCUSKLMEqQABPWybIjRhvXkrDgYaf =JOCUSKLMEqQABPWybIjRhvXkrDgYHo[JOCUSKLMEqQABPWybIjRhvXkrDgYHF].get('tag_id')
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'CATEGORY_LIST','api_path':JOCUSKLMEqQABPWybIjRhvXkrDgYHu,'tag_id':JOCUSKLMEqQABPWybIjRhvXkrDgYaf,'stype':JOCUSKLMEqQABPWybIjRhvXkrDgYHc,'page':'1',}
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel='',img='',infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsz,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYHi>JOCUSKLMEqQABPWybIjRhvXkrDgYHt:
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={}
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['mode'] ='SUB_GROUP' 
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['stype'] =JOCUSKLMEqQABPWybIjRhvXkrDgYHc
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['api_path']=args.get('api_path')
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['page'] =JOCUSKLMEqQABPWybIjRhvXkrDgYst(JOCUSKLMEqQABPWybIjRhvXkrDgYHt+1)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc='[B]%s >>[/B]'%'다음 페이지'
   JOCUSKLMEqQABPWybIjRhvXkrDgYaV=JOCUSKLMEqQABPWybIjRhvXkrDgYst(JOCUSKLMEqQABPWybIjRhvXkrDgYHt+1)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel=JOCUSKLMEqQABPWybIjRhvXkrDgYaV,img=JOCUSKLMEqQABPWybIjRhvXkrDgYVT,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsz,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYsw(JOCUSKLMEqQABPWybIjRhvXkrDgYHo)>0:xbmcplugin.endOfDirectory(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,cacheToDisc=JOCUSKLMEqQABPWybIjRhvXkrDgYsz)
 def play_VIDEO(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYaH =args.get('movie_code')
  JOCUSKLMEqQABPWybIjRhvXkrDgYaG =args.get('season_code')
  JOCUSKLMEqQABPWybIjRhvXkrDgYVc =args.get('title')
  JOCUSKLMEqQABPWybIjRhvXkrDgYHN =args.get('thumbnail')
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.addon_log(JOCUSKLMEqQABPWybIjRhvXkrDgYaH+' - '+JOCUSKLMEqQABPWybIjRhvXkrDgYaG)
  JOCUSKLMEqQABPWybIjRhvXkrDgYad =JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_selQuality()
  JOCUSKLMEqQABPWybIjRhvXkrDgYVf,JOCUSKLMEqQABPWybIjRhvXkrDgYVH=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_settings_proxyport()
  JOCUSKLMEqQABPWybIjRhvXkrDgYVz=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_settings_playback()
  JOCUSKLMEqQABPWybIjRhvXkrDgYan=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.GetStreamingURL(JOCUSKLMEqQABPWybIjRhvXkrDgYaH,JOCUSKLMEqQABPWybIjRhvXkrDgYad,proxyUse=JOCUSKLMEqQABPWybIjRhvXkrDgYVf,inScreen=JOCUSKLMEqQABPWybIjRhvXkrDgYVz['sel_screen'],inSound=JOCUSKLMEqQABPWybIjRhvXkrDgYVz['sel_sound'])
  if JOCUSKLMEqQABPWybIjRhvXkrDgYan['streamUrl']=='':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.addon_noti(__language__(30908).encode('utf8'))
   return
  JOCUSKLMEqQABPWybIjRhvXkrDgYas=JOCUSKLMEqQABPWybIjRhvXkrDgYan['streamUrl']
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.addon_log(JOCUSKLMEqQABPWybIjRhvXkrDgYas)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYVf:
   JOCUSKLMEqQABPWybIjRhvXkrDgYae={'addon':'watcham','playOption':JOCUSKLMEqQABPWybIjRhvXkrDgYVz,}
   JOCUSKLMEqQABPWybIjRhvXkrDgYae=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.Params_JsonToStr(JOCUSKLMEqQABPWybIjRhvXkrDgYae)
   JOCUSKLMEqQABPWybIjRhvXkrDgYas='http://127.0.0.1:{}/{}|proxy-mini={}'.format(JOCUSKLMEqQABPWybIjRhvXkrDgYVH,JOCUSKLMEqQABPWybIjRhvXkrDgYas,JOCUSKLMEqQABPWybIjRhvXkrDgYae)
  JOCUSKLMEqQABPWybIjRhvXkrDgYaz=xbmcgui.ListItem(path=JOCUSKLMEqQABPWybIjRhvXkrDgYas)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYan['customdata']:
   JOCUSKLMEqQABPWybIjRhvXkrDgYax=JOCUSKLMEqQABPWybIjRhvXkrDgYan['customdata']
   JOCUSKLMEqQABPWybIjRhvXkrDgYaN ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   JOCUSKLMEqQABPWybIjRhvXkrDgYap ='mpd'
   JOCUSKLMEqQABPWybIjRhvXkrDgYaw ='com.widevine.alpha'
   JOCUSKLMEqQABPWybIjRhvXkrDgYac =inputstreamhelper.Helper(JOCUSKLMEqQABPWybIjRhvXkrDgYap,drm=JOCUSKLMEqQABPWybIjRhvXkrDgYaw)
   if JOCUSKLMEqQABPWybIjRhvXkrDgYac.check_inputstream():
    JOCUSKLMEqQABPWybIjRhvXkrDgYat={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+JOCUSKLMEqQABPWybIjRhvXkrDgYaH,'dt-custom-data':JOCUSKLMEqQABPWybIjRhvXkrDgYax,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream',}
    JOCUSKLMEqQABPWybIjRhvXkrDgYao=JOCUSKLMEqQABPWybIjRhvXkrDgYaN+'|'+urllib.parse.urlencode(JOCUSKLMEqQABPWybIjRhvXkrDgYat)+'|R{SSM}|'
    JOCUSKLMEqQABPWybIjRhvXkrDgYfn.addon_log(JOCUSKLMEqQABPWybIjRhvXkrDgYao)
    JOCUSKLMEqQABPWybIjRhvXkrDgYaz.setProperty('inputstream',JOCUSKLMEqQABPWybIjRhvXkrDgYac.inputstream_addon)
    JOCUSKLMEqQABPWybIjRhvXkrDgYaz.setProperty('inputstream.adaptive.manifest_type',JOCUSKLMEqQABPWybIjRhvXkrDgYap)
    JOCUSKLMEqQABPWybIjRhvXkrDgYaz.setProperty('inputstream.adaptive.license_type',JOCUSKLMEqQABPWybIjRhvXkrDgYaw)
    JOCUSKLMEqQABPWybIjRhvXkrDgYaz.setProperty('inputstream.adaptive.license_key',JOCUSKLMEqQABPWybIjRhvXkrDgYao)
    JOCUSKLMEqQABPWybIjRhvXkrDgYaz.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.USER_AGENT))
  if JOCUSKLMEqQABPWybIjRhvXkrDgYan['subtitleUrl']:
   try:
    f=JOCUSKLMEqQABPWybIjRhvXkrDgYso(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_SUBTITLE_VTT,'w',-1,'utf-8')
    JOCUSKLMEqQABPWybIjRhvXkrDgYaT=requests.get(JOCUSKLMEqQABPWybIjRhvXkrDgYan['subtitleUrl'])
    JOCUSKLMEqQABPWybIjRhvXkrDgYal=JOCUSKLMEqQABPWybIjRhvXkrDgYaT.content.decode('utf-8') 
    for JOCUSKLMEqQABPWybIjRhvXkrDgYai in JOCUSKLMEqQABPWybIjRhvXkrDgYal.splitlines():
     JOCUSKLMEqQABPWybIjRhvXkrDgYam=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',JOCUSKLMEqQABPWybIjRhvXkrDgYai)
     f.write(JOCUSKLMEqQABPWybIjRhvXkrDgYam+'\n')
    f.close()
    JOCUSKLMEqQABPWybIjRhvXkrDgYaz.setSubtitles([JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_SUBTITLE_VTT,JOCUSKLMEqQABPWybIjRhvXkrDgYan['subtitleUrl']])
   except:
    JOCUSKLMEqQABPWybIjRhvXkrDgYaz.setSubtitles([JOCUSKLMEqQABPWybIjRhvXkrDgYan['subtitleUrl']])
  xbmcplugin.setResolvedUrl(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,JOCUSKLMEqQABPWybIjRhvXkrDgYsz,JOCUSKLMEqQABPWybIjRhvXkrDgYaz)
  try:
   JOCUSKLMEqQABPWybIjRhvXkrDgYHc='movie' if JOCUSKLMEqQABPWybIjRhvXkrDgYaG=='-' else 'seasons'
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'code':JOCUSKLMEqQABPWybIjRhvXkrDgYaH if JOCUSKLMEqQABPWybIjRhvXkrDgYHc=='movie' else JOCUSKLMEqQABPWybIjRhvXkrDgYaG,'img':JOCUSKLMEqQABPWybIjRhvXkrDgYHN,'title':JOCUSKLMEqQABPWybIjRhvXkrDgYVc,'videoid':JOCUSKLMEqQABPWybIjRhvXkrDgYaH}
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.Save_Watched_List(JOCUSKLMEqQABPWybIjRhvXkrDgYHc,JOCUSKLMEqQABPWybIjRhvXkrDgYVl)
  except:
   JOCUSKLMEqQABPWybIjRhvXkrDgYsn
 def srtConvert(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,JOCUSKLMEqQABPWybIjRhvXkrDgYau):
  JOCUSKLMEqQABPWybIjRhvXkrDgYaF=re.sub(r'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',JOCUSKLMEqQABPWybIjRhvXkrDgYau)
  JOCUSKLMEqQABPWybIjRhvXkrDgYaF=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',JOCUSKLMEqQABPWybIjRhvXkrDgYaF)
  JOCUSKLMEqQABPWybIjRhvXkrDgYaF=re.sub(r'(\d\d).(\d\d\d) --> (\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',JOCUSKLMEqQABPWybIjRhvXkrDgYaF)
  JOCUSKLMEqQABPWybIjRhvXkrDgYaF=re.sub(r'WEBVTT\n','',JOCUSKLMEqQABPWybIjRhvXkrDgYaF)
  JOCUSKLMEqQABPWybIjRhvXkrDgYaF=re.sub(r'Kind:[ \-\w]+\n','',JOCUSKLMEqQABPWybIjRhvXkrDgYaF)
  JOCUSKLMEqQABPWybIjRhvXkrDgYaF=re.sub(r'Language:[ \-\w]+\n','',JOCUSKLMEqQABPWybIjRhvXkrDgYaF)
  JOCUSKLMEqQABPWybIjRhvXkrDgYaF=re.sub(r'<c[.\w\d]*>','',JOCUSKLMEqQABPWybIjRhvXkrDgYaF)
  JOCUSKLMEqQABPWybIjRhvXkrDgYaF=re.sub(r'</c>','',JOCUSKLMEqQABPWybIjRhvXkrDgYaF)
  JOCUSKLMEqQABPWybIjRhvXkrDgYaF=re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>','',JOCUSKLMEqQABPWybIjRhvXkrDgYaF)
  JOCUSKLMEqQABPWybIjRhvXkrDgYaF=re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n','',JOCUSKLMEqQABPWybIjRhvXkrDgYaF)
  JOCUSKLMEqQABPWybIjRhvXkrDgYaF=re.sub(r'Style:\n##\n','',JOCUSKLMEqQABPWybIjRhvXkrDgYaF)
  return JOCUSKLMEqQABPWybIjRhvXkrDgYaF
 def vtt_to_srt(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,vttFilename,srtFilename):
  try:
   f=JOCUSKLMEqQABPWybIjRhvXkrDgYso(vttFilename,'r',-1,'utf-8')
   JOCUSKLMEqQABPWybIjRhvXkrDgYau=f.read()
   f.close()
   JOCUSKLMEqQABPWybIjRhvXkrDgYGf=''
   JOCUSKLMEqQABPWybIjRhvXkrDgYGf=JOCUSKLMEqQABPWybIjRhvXkrDgYGf+JOCUSKLMEqQABPWybIjRhvXkrDgYfn.srtConvert(JOCUSKLMEqQABPWybIjRhvXkrDgYau)
   f=JOCUSKLMEqQABPWybIjRhvXkrDgYso(srtFilename,'w',-1,'utf-8')
   f.writelines(JOCUSKLMEqQABPWybIjRhvXkrDgYst(JOCUSKLMEqQABPWybIjRhvXkrDgYGf))
   f.close()
  except:
   return JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  return JOCUSKLMEqQABPWybIjRhvXkrDgYsz
 def dp_Category_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYHc =args.get('stype')
  JOCUSKLMEqQABPWybIjRhvXkrDgYaf =args.get('tag_id')
  JOCUSKLMEqQABPWybIjRhvXkrDgYHu=args.get('api_path')
  JOCUSKLMEqQABPWybIjRhvXkrDgYHt=JOCUSKLMEqQABPWybIjRhvXkrDgYse(args.get('page'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYGV=[]
  JOCUSKLMEqQABPWybIjRhvXkrDgYGH,JOCUSKLMEqQABPWybIjRhvXkrDgYGa=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.GetCategoryList(JOCUSKLMEqQABPWybIjRhvXkrDgYHc,JOCUSKLMEqQABPWybIjRhvXkrDgYaf,JOCUSKLMEqQABPWybIjRhvXkrDgYHu,JOCUSKLMEqQABPWybIjRhvXkrDgYHt)
  for JOCUSKLMEqQABPWybIjRhvXkrDgYGd in JOCUSKLMEqQABPWybIjRhvXkrDgYGH:
   JOCUSKLMEqQABPWybIjRhvXkrDgYaH =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('code')
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('title')
   JOCUSKLMEqQABPWybIjRhvXkrDgYHz =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('content_type')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGn =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('story')
   JOCUSKLMEqQABPWybIjRhvXkrDgYHN =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('thumbnail')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGs =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('year')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGe =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('film_rating_code')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGz=JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('film_rating_short')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGx =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('film_rating_long')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGN =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('duration')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGp =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('badge')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGV.append(JOCUSKLMEqQABPWybIjRhvXkrDgYaH)
   if JOCUSKLMEqQABPWybIjRhvXkrDgYHz=='movies': 
    JOCUSKLMEqQABPWybIjRhvXkrDgYVi =JOCUSKLMEqQABPWybIjRhvXkrDgYsx
    JOCUSKLMEqQABPWybIjRhvXkrDgYGw ='MOVIE'
    JOCUSKLMEqQABPWybIjRhvXkrDgYaG='-'
    JOCUSKLMEqQABPWybIjRhvXkrDgYGc ='movie'
   else: 
    JOCUSKLMEqQABPWybIjRhvXkrDgYVi =JOCUSKLMEqQABPWybIjRhvXkrDgYsz
    JOCUSKLMEqQABPWybIjRhvXkrDgYGw ='SEASON'
    JOCUSKLMEqQABPWybIjRhvXkrDgYaG=JOCUSKLMEqQABPWybIjRhvXkrDgYaH
    JOCUSKLMEqQABPWybIjRhvXkrDgYGc ='tvshow' 
   JOCUSKLMEqQABPWybIjRhvXkrDgYGt={'mediatype':JOCUSKLMEqQABPWybIjRhvXkrDgYGc,'mpaa':JOCUSKLMEqQABPWybIjRhvXkrDgYGx,'title':JOCUSKLMEqQABPWybIjRhvXkrDgYVc,'year':JOCUSKLMEqQABPWybIjRhvXkrDgYGs,'duration':JOCUSKLMEqQABPWybIjRhvXkrDgYGN,'plot':JOCUSKLMEqQABPWybIjRhvXkrDgYGn,}
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc+='  (%s)'%(JOCUSKLMEqQABPWybIjRhvXkrDgYGs)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':JOCUSKLMEqQABPWybIjRhvXkrDgYGw,'movie_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaH,'page':'1','season_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaG,'title':JOCUSKLMEqQABPWybIjRhvXkrDgYVc,'thumbnail':JOCUSKLMEqQABPWybIjRhvXkrDgYHN,}
   JOCUSKLMEqQABPWybIjRhvXkrDgYGo=[]
   if JOCUSKLMEqQABPWybIjRhvXkrDgYHu=='users/me/watchings':
    JOCUSKLMEqQABPWybIjRhvXkrDgYGT={'codeList':[JOCUSKLMEqQABPWybIjRhvXkrDgYaH]}
    JOCUSKLMEqQABPWybIjRhvXkrDgYGl=json.dumps(JOCUSKLMEqQABPWybIjRhvXkrDgYGT)
    JOCUSKLMEqQABPWybIjRhvXkrDgYGl=urllib.parse.quote(JOCUSKLMEqQABPWybIjRhvXkrDgYGl)
    JOCUSKLMEqQABPWybIjRhvXkrDgYGi='RunPlugin(plugin://plugin.video.watcham/?mode=DELETE_CONTINUE&bm_param=%s)'%(JOCUSKLMEqQABPWybIjRhvXkrDgYGl)
    JOCUSKLMEqQABPWybIjRhvXkrDgYGo.append(('(선택영상) 이어보기에서 삭제',JOCUSKLMEqQABPWybIjRhvXkrDgYGi))
   if JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_settings_makebookmark():
    JOCUSKLMEqQABPWybIjRhvXkrDgYGT={'videoid':JOCUSKLMEqQABPWybIjRhvXkrDgYaH,'vidtype':'tvshow' if JOCUSKLMEqQABPWybIjRhvXkrDgYHz=='tv_seasons' else 'movie','vtitle':JOCUSKLMEqQABPWybIjRhvXkrDgYVc,'vsubtitle':'',}
    JOCUSKLMEqQABPWybIjRhvXkrDgYGl=json.dumps(JOCUSKLMEqQABPWybIjRhvXkrDgYGT)
    JOCUSKLMEqQABPWybIjRhvXkrDgYGl=urllib.parse.quote(JOCUSKLMEqQABPWybIjRhvXkrDgYGl)
    JOCUSKLMEqQABPWybIjRhvXkrDgYGi='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(JOCUSKLMEqQABPWybIjRhvXkrDgYGl)
    JOCUSKLMEqQABPWybIjRhvXkrDgYGo.append(('(통합) 찜 영상에 추가',JOCUSKLMEqQABPWybIjRhvXkrDgYGi))
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel=JOCUSKLMEqQABPWybIjRhvXkrDgYGp,img=JOCUSKLMEqQABPWybIjRhvXkrDgYHN,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYGt,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYVi,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl,ContextMenu=JOCUSKLMEqQABPWybIjRhvXkrDgYGo)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYHu=='users/me/watchings':
   JOCUSKLMEqQABPWybIjRhvXkrDgYGT={'codeList':JOCUSKLMEqQABPWybIjRhvXkrDgYGV}
   JOCUSKLMEqQABPWybIjRhvXkrDgYGl=json.dumps(JOCUSKLMEqQABPWybIjRhvXkrDgYGT,separators=(',',':'))
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.addon_log(JOCUSKLMEqQABPWybIjRhvXkrDgYGl)
   JOCUSKLMEqQABPWybIjRhvXkrDgYGl=urllib.parse.quote(JOCUSKLMEqQABPWybIjRhvXkrDgYGl)
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.addon_log(JOCUSKLMEqQABPWybIjRhvXkrDgYGl)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'DELETE_CONTINUE','bm_param':JOCUSKLMEqQABPWybIjRhvXkrDgYGT,}
   JOCUSKLMEqQABPWybIjRhvXkrDgYGt={'plot':'이어보기 목록 전체를 삭제합니다.'}
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc='** 이어보기 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   JOCUSKLMEqQABPWybIjRhvXkrDgYVT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel='',img=JOCUSKLMEqQABPWybIjRhvXkrDgYVT,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYGt,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsx,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl,isLink=JOCUSKLMEqQABPWybIjRhvXkrDgYsz)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYGa:
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={}
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['mode'] ='CATEGORY_LIST'
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['stype'] =JOCUSKLMEqQABPWybIjRhvXkrDgYHc
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['tag_id'] =JOCUSKLMEqQABPWybIjRhvXkrDgYaf
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['api_path']=JOCUSKLMEqQABPWybIjRhvXkrDgYHu
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['page'] =JOCUSKLMEqQABPWybIjRhvXkrDgYst(JOCUSKLMEqQABPWybIjRhvXkrDgYHt+1)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc='[B]%s >>[/B]'%'다음 페이지'
   JOCUSKLMEqQABPWybIjRhvXkrDgYaV=JOCUSKLMEqQABPWybIjRhvXkrDgYst(JOCUSKLMEqQABPWybIjRhvXkrDgYHt+1)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel=JOCUSKLMEqQABPWybIjRhvXkrDgYaV,img=JOCUSKLMEqQABPWybIjRhvXkrDgYVT,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsz,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl)
  xbmcplugin.setContent(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,'movies')
  if JOCUSKLMEqQABPWybIjRhvXkrDgYsw(JOCUSKLMEqQABPWybIjRhvXkrDgYGH)>0:
   if JOCUSKLMEqQABPWybIjRhvXkrDgYHu=='arrivals/latest':
    xbmcplugin.endOfDirectory(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,cacheToDisc=JOCUSKLMEqQABPWybIjRhvXkrDgYsz)
   else:
    xbmcplugin.endOfDirectory(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,cacheToDisc=JOCUSKLMEqQABPWybIjRhvXkrDgYsx)
 def dp_Season_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYaG=args.get('season_code')
  JOCUSKLMEqQABPWybIjRhvXkrDgYHN =args.get('thumbnail')
  JOCUSKLMEqQABPWybIjRhvXkrDgYHN=json.loads(JOCUSKLMEqQABPWybIjRhvXkrDgYHN.replace('\'','"'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYGm=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.GetSeasonList(JOCUSKLMEqQABPWybIjRhvXkrDgYaG)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYsw(JOCUSKLMEqQABPWybIjRhvXkrDgYGm)>1:
   for JOCUSKLMEqQABPWybIjRhvXkrDgYGF in JOCUSKLMEqQABPWybIjRhvXkrDgYGm:
    JOCUSKLMEqQABPWybIjRhvXkrDgYGu=JOCUSKLMEqQABPWybIjRhvXkrDgYGF.get('seasonId')
    JOCUSKLMEqQABPWybIjRhvXkrDgYdf=JOCUSKLMEqQABPWybIjRhvXkrDgYGF.get('seasonNm')
    JOCUSKLMEqQABPWybIjRhvXkrDgYGt={'mediatype':'tvshow','title':JOCUSKLMEqQABPWybIjRhvXkrDgYdf,}
    JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'EPISODE','movie_code':JOCUSKLMEqQABPWybIjRhvXkrDgYGu,'page':'1','season_code':JOCUSKLMEqQABPWybIjRhvXkrDgYGu,'title':JOCUSKLMEqQABPWybIjRhvXkrDgYdf,'thumbnail':JOCUSKLMEqQABPWybIjRhvXkrDgYHN,}
    JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYdf,sublabel=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,img=JOCUSKLMEqQABPWybIjRhvXkrDgYHN,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYGt,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsz,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl,ContextMenu=JOCUSKLMEqQABPWybIjRhvXkrDgYsn)
   xbmcplugin.setContent(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,cacheToDisc=JOCUSKLMEqQABPWybIjRhvXkrDgYsx)
  else:
   JOCUSKLMEqQABPWybIjRhvXkrDgYdV={'movie_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaG,'page':'1','season_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaG,}
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Episode_List(JOCUSKLMEqQABPWybIjRhvXkrDgYdV)
 def dp_Episode_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYdH=args.get('movie_code')
  JOCUSKLMEqQABPWybIjRhvXkrDgYHt =JOCUSKLMEqQABPWybIjRhvXkrDgYse(args.get('page'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYaG =args.get('season_code')
  JOCUSKLMEqQABPWybIjRhvXkrDgYGH,JOCUSKLMEqQABPWybIjRhvXkrDgYGa=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.GetEpisodoList(JOCUSKLMEqQABPWybIjRhvXkrDgYdH,JOCUSKLMEqQABPWybIjRhvXkrDgYHt,orderby=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_winEpisodeOrderby())
  for JOCUSKLMEqQABPWybIjRhvXkrDgYGd in JOCUSKLMEqQABPWybIjRhvXkrDgYGH:
   JOCUSKLMEqQABPWybIjRhvXkrDgYaH =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('code')
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('title')
   JOCUSKLMEqQABPWybIjRhvXkrDgYHN =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('thumbnail')
   JOCUSKLMEqQABPWybIjRhvXkrDgYda =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('display_num')
   JOCUSKLMEqQABPWybIjRhvXkrDgYdG =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('season_title')
   JOCUSKLMEqQABPWybIjRhvXkrDgYdn=JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('episode_number')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGN =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('duration')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGt={'mediatype':'episode','tvshowtitle':JOCUSKLMEqQABPWybIjRhvXkrDgYVc if JOCUSKLMEqQABPWybIjRhvXkrDgYVc!='' else JOCUSKLMEqQABPWybIjRhvXkrDgYdG,'title':'%s %s'%(JOCUSKLMEqQABPWybIjRhvXkrDgYdG,JOCUSKLMEqQABPWybIjRhvXkrDgYda)if JOCUSKLMEqQABPWybIjRhvXkrDgYVc!='' else JOCUSKLMEqQABPWybIjRhvXkrDgYda,'episode':JOCUSKLMEqQABPWybIjRhvXkrDgYdn,'duration':JOCUSKLMEqQABPWybIjRhvXkrDgYGN,'plot':'%s\n%s\n\n%s'%(JOCUSKLMEqQABPWybIjRhvXkrDgYdG,JOCUSKLMEqQABPWybIjRhvXkrDgYda,JOCUSKLMEqQABPWybIjRhvXkrDgYVc)}
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc='(%s) %s'%(JOCUSKLMEqQABPWybIjRhvXkrDgYda,JOCUSKLMEqQABPWybIjRhvXkrDgYVc)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'MOVIE','movie_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaH,'season_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaG,'title':'%s < %s >'%(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,JOCUSKLMEqQABPWybIjRhvXkrDgYdG),'thumbnail':JOCUSKLMEqQABPWybIjRhvXkrDgYHN}
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel=JOCUSKLMEqQABPWybIjRhvXkrDgYdG,img=JOCUSKLMEqQABPWybIjRhvXkrDgYHN,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYGt,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsx,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYHt==1:
   JOCUSKLMEqQABPWybIjRhvXkrDgYGt={'plot':'정렬순서를 변경합니다.'}
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={}
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['mode'] ='ORDER_BY' 
   if JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_winEpisodeOrderby()=='desc':
    JOCUSKLMEqQABPWybIjRhvXkrDgYVc='정렬순서변경 : 최신화부터 -> 1회부터'
    JOCUSKLMEqQABPWybIjRhvXkrDgYVl['orderby']='asc'
   else:
    JOCUSKLMEqQABPWybIjRhvXkrDgYVc='정렬순서변경 : 1회부터 -> 최신화부터'
    JOCUSKLMEqQABPWybIjRhvXkrDgYVl['orderby']='desc'
   JOCUSKLMEqQABPWybIjRhvXkrDgYVT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel='',img=JOCUSKLMEqQABPWybIjRhvXkrDgYVT,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYGt,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsx,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl,isLink=JOCUSKLMEqQABPWybIjRhvXkrDgYsz)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYGa:
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['mode'] ='EPISODE' 
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['movie_code']=JOCUSKLMEqQABPWybIjRhvXkrDgYdH
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['page'] =JOCUSKLMEqQABPWybIjRhvXkrDgYst(JOCUSKLMEqQABPWybIjRhvXkrDgYHt+1)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc='[B]%s >>[/B]'%'다음 페이지'
   JOCUSKLMEqQABPWybIjRhvXkrDgYaV=JOCUSKLMEqQABPWybIjRhvXkrDgYst(JOCUSKLMEqQABPWybIjRhvXkrDgYHt+1)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel=JOCUSKLMEqQABPWybIjRhvXkrDgYaV,img=JOCUSKLMEqQABPWybIjRhvXkrDgYVT,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsz,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl)
  xbmcplugin.setContent(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,'episodes')
  if JOCUSKLMEqQABPWybIjRhvXkrDgYsw(JOCUSKLMEqQABPWybIjRhvXkrDgYGH)>0:xbmcplugin.endOfDirectory(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,cacheToDisc=JOCUSKLMEqQABPWybIjRhvXkrDgYsz)
 def dp_Search_History(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYds=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.Load_List_File('search')
  for JOCUSKLMEqQABPWybIjRhvXkrDgYde in JOCUSKLMEqQABPWybIjRhvXkrDgYds:
   JOCUSKLMEqQABPWybIjRhvXkrDgYdz=JOCUSKLMEqQABPWybIjRhvXkrDgYsp(urllib.parse.parse_qsl(JOCUSKLMEqQABPWybIjRhvXkrDgYde))
   JOCUSKLMEqQABPWybIjRhvXkrDgYdx=JOCUSKLMEqQABPWybIjRhvXkrDgYdz.get('skey').strip()
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'LOCAL_SEARCH','search_key':JOCUSKLMEqQABPWybIjRhvXkrDgYdx,'page':'1','historyyn':'Y',}
   JOCUSKLMEqQABPWybIjRhvXkrDgYdN={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':JOCUSKLMEqQABPWybIjRhvXkrDgYdx,'vType':'-',}
   JOCUSKLMEqQABPWybIjRhvXkrDgYdp=urllib.parse.urlencode(JOCUSKLMEqQABPWybIjRhvXkrDgYdN)
   JOCUSKLMEqQABPWybIjRhvXkrDgYGo=[('선택된 검색어 ( %s ) 삭제'%(JOCUSKLMEqQABPWybIjRhvXkrDgYdx),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(JOCUSKLMEqQABPWybIjRhvXkrDgYdp))]
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYdx,sublabel='',img=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsz,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl,ContextMenu=JOCUSKLMEqQABPWybIjRhvXkrDgYGo)
  JOCUSKLMEqQABPWybIjRhvXkrDgYGt={'plot':'검색목록 전체를 삭제합니다.'}
  JOCUSKLMEqQABPWybIjRhvXkrDgYVc='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  JOCUSKLMEqQABPWybIjRhvXkrDgYVT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel='',img=JOCUSKLMEqQABPWybIjRhvXkrDgYVT,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYGt,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsx,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl,isLink=JOCUSKLMEqQABPWybIjRhvXkrDgYsz)
  xbmcplugin.endOfDirectory(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,cacheToDisc=JOCUSKLMEqQABPWybIjRhvXkrDgYsx)
 def dp_Search_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYHt =JOCUSKLMEqQABPWybIjRhvXkrDgYse(args.get('page'))
  if 'search_key' in args:
   JOCUSKLMEqQABPWybIjRhvXkrDgYdw=args.get('search_key')
  else:
   JOCUSKLMEqQABPWybIjRhvXkrDgYdw=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not JOCUSKLMEqQABPWybIjRhvXkrDgYdw:
    return
  JOCUSKLMEqQABPWybIjRhvXkrDgYGH,JOCUSKLMEqQABPWybIjRhvXkrDgYGa=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.GetSearchList(JOCUSKLMEqQABPWybIjRhvXkrDgYdw,JOCUSKLMEqQABPWybIjRhvXkrDgYHt)
  for JOCUSKLMEqQABPWybIjRhvXkrDgYGd in JOCUSKLMEqQABPWybIjRhvXkrDgYGH:
   JOCUSKLMEqQABPWybIjRhvXkrDgYaH =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('code')
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('title')
   JOCUSKLMEqQABPWybIjRhvXkrDgYHz=JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('content_type')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGn =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('story')
   JOCUSKLMEqQABPWybIjRhvXkrDgYHN =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('thumbnail')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGs =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('year')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGe =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('film_rating_code')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGz=JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('film_rating_short')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGx =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('film_rating_long')
   JOCUSKLMEqQABPWybIjRhvXkrDgYGN =JOCUSKLMEqQABPWybIjRhvXkrDgYGd.get('duration')
   if JOCUSKLMEqQABPWybIjRhvXkrDgYHz=='movies': 
    JOCUSKLMEqQABPWybIjRhvXkrDgYVi =JOCUSKLMEqQABPWybIjRhvXkrDgYsx
    JOCUSKLMEqQABPWybIjRhvXkrDgYGw ='MOVIE'
    JOCUSKLMEqQABPWybIjRhvXkrDgYVF =''
    JOCUSKLMEqQABPWybIjRhvXkrDgYaG='-'
    JOCUSKLMEqQABPWybIjRhvXkrDgYGc ='movie'
   else: 
    JOCUSKLMEqQABPWybIjRhvXkrDgYVi =JOCUSKLMEqQABPWybIjRhvXkrDgYsz
    JOCUSKLMEqQABPWybIjRhvXkrDgYGw ='SEASON'
    JOCUSKLMEqQABPWybIjRhvXkrDgYVF ='' 
    JOCUSKLMEqQABPWybIjRhvXkrDgYaG=JOCUSKLMEqQABPWybIjRhvXkrDgYaH
    JOCUSKLMEqQABPWybIjRhvXkrDgYGc ='tvshow' 
   JOCUSKLMEqQABPWybIjRhvXkrDgYGt={'mediatype':JOCUSKLMEqQABPWybIjRhvXkrDgYGc,'mpaa':JOCUSKLMEqQABPWybIjRhvXkrDgYGx,'title':JOCUSKLMEqQABPWybIjRhvXkrDgYVc,'year':JOCUSKLMEqQABPWybIjRhvXkrDgYGs,'duration':JOCUSKLMEqQABPWybIjRhvXkrDgYGN,'plot':JOCUSKLMEqQABPWybIjRhvXkrDgYGn}
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc+='  (%s)'%(JOCUSKLMEqQABPWybIjRhvXkrDgYGs)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':JOCUSKLMEqQABPWybIjRhvXkrDgYGw,'movie_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaH,'page':'1','season_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaG,'title':JOCUSKLMEqQABPWybIjRhvXkrDgYVc,'thumbnail':JOCUSKLMEqQABPWybIjRhvXkrDgYHN}
   if JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_settings_makebookmark():
    JOCUSKLMEqQABPWybIjRhvXkrDgYGT={'videoid':JOCUSKLMEqQABPWybIjRhvXkrDgYaH,'vidtype':'tvshow' if JOCUSKLMEqQABPWybIjRhvXkrDgYHz=='tv_seasons' else 'movie','vtitle':JOCUSKLMEqQABPWybIjRhvXkrDgYVc,'vsubtitle':'',}
    JOCUSKLMEqQABPWybIjRhvXkrDgYGl=json.dumps(JOCUSKLMEqQABPWybIjRhvXkrDgYGT)
    JOCUSKLMEqQABPWybIjRhvXkrDgYGl=urllib.parse.quote(JOCUSKLMEqQABPWybIjRhvXkrDgYGl)
    JOCUSKLMEqQABPWybIjRhvXkrDgYGi='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(JOCUSKLMEqQABPWybIjRhvXkrDgYGl)
    JOCUSKLMEqQABPWybIjRhvXkrDgYGo=[('(통합) 찜 영상에 추가',JOCUSKLMEqQABPWybIjRhvXkrDgYGi)]
   else:
    JOCUSKLMEqQABPWybIjRhvXkrDgYGo=JOCUSKLMEqQABPWybIjRhvXkrDgYsn
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel=JOCUSKLMEqQABPWybIjRhvXkrDgYVF,img=JOCUSKLMEqQABPWybIjRhvXkrDgYHN,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYGt,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYVi,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl,ContextMenu=JOCUSKLMEqQABPWybIjRhvXkrDgYGo)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYGa:
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={}
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['mode'] ='SEARCH'
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['search_key']=JOCUSKLMEqQABPWybIjRhvXkrDgYdw
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl['page'] =JOCUSKLMEqQABPWybIjRhvXkrDgYst(JOCUSKLMEqQABPWybIjRhvXkrDgYHt+1)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc='[B]%s >>[/B]'%'다음 페이지'
   JOCUSKLMEqQABPWybIjRhvXkrDgYaV=JOCUSKLMEqQABPWybIjRhvXkrDgYst(JOCUSKLMEqQABPWybIjRhvXkrDgYHt+1)
   JOCUSKLMEqQABPWybIjRhvXkrDgYVT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel=JOCUSKLMEqQABPWybIjRhvXkrDgYaV,img=JOCUSKLMEqQABPWybIjRhvXkrDgYVT,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsz,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl)
  xbmcplugin.setContent(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,'movies')
  xbmcplugin.endOfDirectory(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,cacheToDisc=JOCUSKLMEqQABPWybIjRhvXkrDgYsz)
  if args.get('historyyn')=='Y':JOCUSKLMEqQABPWybIjRhvXkrDgYfn.Save_Searched_List(JOCUSKLMEqQABPWybIjRhvXkrDgYdw)
 def dp_Delete_Continue(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYdc=urllib.parse.unquote(args.get('bm_param'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYdc=JOCUSKLMEqQABPWybIjRhvXkrDgYdc.replace('\'','"')
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.addon_log(JOCUSKLMEqQABPWybIjRhvXkrDgYdc)
  JOCUSKLMEqQABPWybIjRhvXkrDgYdc=json.loads(JOCUSKLMEqQABPWybIjRhvXkrDgYdc)
  JOCUSKLMEqQABPWybIjRhvXkrDgYGV=JOCUSKLMEqQABPWybIjRhvXkrDgYdc.get('codeList')
  JOCUSKLMEqQABPWybIjRhvXkrDgYfN=xbmcgui.Dialog()
  JOCUSKLMEqQABPWybIjRhvXkrDgYHa=JOCUSKLMEqQABPWybIjRhvXkrDgYfN.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if JOCUSKLMEqQABPWybIjRhvXkrDgYHa==JOCUSKLMEqQABPWybIjRhvXkrDgYsx:sys.exit()
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.DeleteContinueList(JOCUSKLMEqQABPWybIjRhvXkrDgYGV)
  xbmc.executebuiltin("Container.Refresh")
 def dp_History_Remove(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYdt=args.get('delType')
  JOCUSKLMEqQABPWybIjRhvXkrDgYdo =args.get('sKey')
  JOCUSKLMEqQABPWybIjRhvXkrDgYdT =args.get('vType')
  JOCUSKLMEqQABPWybIjRhvXkrDgYfN=xbmcgui.Dialog()
  if JOCUSKLMEqQABPWybIjRhvXkrDgYdt=='SEARCH_ALL':
   JOCUSKLMEqQABPWybIjRhvXkrDgYHa=JOCUSKLMEqQABPWybIjRhvXkrDgYfN.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYdt=='SEARCH_ONE':
   JOCUSKLMEqQABPWybIjRhvXkrDgYHa=JOCUSKLMEqQABPWybIjRhvXkrDgYfN.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYdt=='WATCH_ALL':
   JOCUSKLMEqQABPWybIjRhvXkrDgYHa=JOCUSKLMEqQABPWybIjRhvXkrDgYfN.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYdt=='WATCH_ONE':
   JOCUSKLMEqQABPWybIjRhvXkrDgYHa=JOCUSKLMEqQABPWybIjRhvXkrDgYfN.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if JOCUSKLMEqQABPWybIjRhvXkrDgYHa==JOCUSKLMEqQABPWybIjRhvXkrDgYsx:sys.exit()
  if JOCUSKLMEqQABPWybIjRhvXkrDgYdt=='SEARCH_ALL':
   if os.path.isfile(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_SEARCHEDC_FILENAME):os.remove(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_SEARCHEDC_FILENAME)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYdt=='SEARCH_ONE':
   try:
    JOCUSKLMEqQABPWybIjRhvXkrDgYdl=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_SEARCHEDC_FILENAME
    JOCUSKLMEqQABPWybIjRhvXkrDgYdi=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.Load_List_File('search') 
    fp=JOCUSKLMEqQABPWybIjRhvXkrDgYso(JOCUSKLMEqQABPWybIjRhvXkrDgYdl,'w',-1,'utf-8')
    for JOCUSKLMEqQABPWybIjRhvXkrDgYdm in JOCUSKLMEqQABPWybIjRhvXkrDgYdi:
     JOCUSKLMEqQABPWybIjRhvXkrDgYdF=JOCUSKLMEqQABPWybIjRhvXkrDgYsp(urllib.parse.parse_qsl(JOCUSKLMEqQABPWybIjRhvXkrDgYdm))
     JOCUSKLMEqQABPWybIjRhvXkrDgYdu=JOCUSKLMEqQABPWybIjRhvXkrDgYdF.get('skey').strip()
     if JOCUSKLMEqQABPWybIjRhvXkrDgYdo!=JOCUSKLMEqQABPWybIjRhvXkrDgYdu:
      fp.write(JOCUSKLMEqQABPWybIjRhvXkrDgYdm)
    fp.close()
   except:
    JOCUSKLMEqQABPWybIjRhvXkrDgYsn
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYdt=='WATCH_ALL':
   JOCUSKLMEqQABPWybIjRhvXkrDgYdl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JOCUSKLMEqQABPWybIjRhvXkrDgYdT))
   if os.path.isfile(JOCUSKLMEqQABPWybIjRhvXkrDgYdl):os.remove(JOCUSKLMEqQABPWybIjRhvXkrDgYdl)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYdt=='WATCH_ONE':
   JOCUSKLMEqQABPWybIjRhvXkrDgYdl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JOCUSKLMEqQABPWybIjRhvXkrDgYdT))
   try:
    JOCUSKLMEqQABPWybIjRhvXkrDgYdi=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.Load_List_File(JOCUSKLMEqQABPWybIjRhvXkrDgYdT) 
    fp=JOCUSKLMEqQABPWybIjRhvXkrDgYso(JOCUSKLMEqQABPWybIjRhvXkrDgYdl,'w',-1,'utf-8')
    for JOCUSKLMEqQABPWybIjRhvXkrDgYdm in JOCUSKLMEqQABPWybIjRhvXkrDgYdi:
     JOCUSKLMEqQABPWybIjRhvXkrDgYdF=JOCUSKLMEqQABPWybIjRhvXkrDgYsp(urllib.parse.parse_qsl(JOCUSKLMEqQABPWybIjRhvXkrDgYdm))
     JOCUSKLMEqQABPWybIjRhvXkrDgYdu=JOCUSKLMEqQABPWybIjRhvXkrDgYdF.get('code').strip()
     if JOCUSKLMEqQABPWybIjRhvXkrDgYdo!=JOCUSKLMEqQABPWybIjRhvXkrDgYdu:
      fp.write(JOCUSKLMEqQABPWybIjRhvXkrDgYdm)
    fp.close()
   except:
    JOCUSKLMEqQABPWybIjRhvXkrDgYsn
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,JOCUSKLMEqQABPWybIjRhvXkrDgYHc): 
  try:
   if JOCUSKLMEqQABPWybIjRhvXkrDgYHc=='search':
    JOCUSKLMEqQABPWybIjRhvXkrDgYdl=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_SEARCHEDC_FILENAME
   elif JOCUSKLMEqQABPWybIjRhvXkrDgYHc in['seasons','movie']:
    JOCUSKLMEqQABPWybIjRhvXkrDgYdl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JOCUSKLMEqQABPWybIjRhvXkrDgYHc))
   else:
    return[]
   fp=JOCUSKLMEqQABPWybIjRhvXkrDgYso(JOCUSKLMEqQABPWybIjRhvXkrDgYdl,'r',-1,'utf-8')
   JOCUSKLMEqQABPWybIjRhvXkrDgYnf=fp.readlines()
   fp.close()
  except:
   JOCUSKLMEqQABPWybIjRhvXkrDgYnf=[]
  return JOCUSKLMEqQABPWybIjRhvXkrDgYnf
 def Save_Watched_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,JOCUSKLMEqQABPWybIjRhvXkrDgYHc,JOCUSKLMEqQABPWybIjRhvXkrDgYfz):
  try:
   JOCUSKLMEqQABPWybIjRhvXkrDgYnV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%JOCUSKLMEqQABPWybIjRhvXkrDgYHc))
   JOCUSKLMEqQABPWybIjRhvXkrDgYdi=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.Load_List_File(JOCUSKLMEqQABPWybIjRhvXkrDgYHc) 
   fp=JOCUSKLMEqQABPWybIjRhvXkrDgYso(JOCUSKLMEqQABPWybIjRhvXkrDgYnV,'w',-1,'utf-8')
   JOCUSKLMEqQABPWybIjRhvXkrDgYnH=urllib.parse.urlencode(JOCUSKLMEqQABPWybIjRhvXkrDgYfz)
   JOCUSKLMEqQABPWybIjRhvXkrDgYnH=JOCUSKLMEqQABPWybIjRhvXkrDgYnH+'\n'
   fp.write(JOCUSKLMEqQABPWybIjRhvXkrDgYnH)
   JOCUSKLMEqQABPWybIjRhvXkrDgYna=0
   for JOCUSKLMEqQABPWybIjRhvXkrDgYdm in JOCUSKLMEqQABPWybIjRhvXkrDgYdi:
    JOCUSKLMEqQABPWybIjRhvXkrDgYdF=JOCUSKLMEqQABPWybIjRhvXkrDgYsp(urllib.parse.parse_qsl(JOCUSKLMEqQABPWybIjRhvXkrDgYdm))
    JOCUSKLMEqQABPWybIjRhvXkrDgYnG=JOCUSKLMEqQABPWybIjRhvXkrDgYfz.get('code').strip()
    JOCUSKLMEqQABPWybIjRhvXkrDgYnd=JOCUSKLMEqQABPWybIjRhvXkrDgYdF.get('code').strip()
    if JOCUSKLMEqQABPWybIjRhvXkrDgYHc=='seasons' and JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_settings_direct_replay()==JOCUSKLMEqQABPWybIjRhvXkrDgYsz:
     JOCUSKLMEqQABPWybIjRhvXkrDgYnG=JOCUSKLMEqQABPWybIjRhvXkrDgYfz.get('videoid').strip()
     JOCUSKLMEqQABPWybIjRhvXkrDgYnd=JOCUSKLMEqQABPWybIjRhvXkrDgYdF.get('videoid').strip()if JOCUSKLMEqQABPWybIjRhvXkrDgYnd!=JOCUSKLMEqQABPWybIjRhvXkrDgYsn else '-'
    if JOCUSKLMEqQABPWybIjRhvXkrDgYnG!=JOCUSKLMEqQABPWybIjRhvXkrDgYnd:
     fp.write(JOCUSKLMEqQABPWybIjRhvXkrDgYdm)
     JOCUSKLMEqQABPWybIjRhvXkrDgYna+=1
     if JOCUSKLMEqQABPWybIjRhvXkrDgYna>=50:break
   fp.close()
  except:
   JOCUSKLMEqQABPWybIjRhvXkrDgYsn
 def dp_Watch_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYHc =args.get('stype')
  JOCUSKLMEqQABPWybIjRhvXkrDgYVN=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_settings_direct_replay()
  if JOCUSKLMEqQABPWybIjRhvXkrDgYHc=='-':
   for JOCUSKLMEqQABPWybIjRhvXkrDgYns in JOCUSKLMEqQABPWybIjRhvXkrDgYfa:
    JOCUSKLMEqQABPWybIjRhvXkrDgYVc=JOCUSKLMEqQABPWybIjRhvXkrDgYns.get('title')
    JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':JOCUSKLMEqQABPWybIjRhvXkrDgYns.get('mode'),'stype':JOCUSKLMEqQABPWybIjRhvXkrDgYns.get('stype')}
    JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel='',img='',infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYsn,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsz,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl)
   if JOCUSKLMEqQABPWybIjRhvXkrDgYsw(JOCUSKLMEqQABPWybIjRhvXkrDgYfa)>0:xbmcplugin.endOfDirectory(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle)
  else:
   JOCUSKLMEqQABPWybIjRhvXkrDgYne=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.Load_List_File(JOCUSKLMEqQABPWybIjRhvXkrDgYHc)
   for JOCUSKLMEqQABPWybIjRhvXkrDgYnz in JOCUSKLMEqQABPWybIjRhvXkrDgYne:
    JOCUSKLMEqQABPWybIjRhvXkrDgYdz=JOCUSKLMEqQABPWybIjRhvXkrDgYsp(urllib.parse.parse_qsl(JOCUSKLMEqQABPWybIjRhvXkrDgYnz))
    JOCUSKLMEqQABPWybIjRhvXkrDgYaH=JOCUSKLMEqQABPWybIjRhvXkrDgYdz.get('code').strip()
    JOCUSKLMEqQABPWybIjRhvXkrDgYVc =JOCUSKLMEqQABPWybIjRhvXkrDgYdz.get('title').strip()
    JOCUSKLMEqQABPWybIjRhvXkrDgYHN =JOCUSKLMEqQABPWybIjRhvXkrDgYdz.get('img').strip()
    JOCUSKLMEqQABPWybIjRhvXkrDgYnx =JOCUSKLMEqQABPWybIjRhvXkrDgYdz.get('videoid').strip()
    try:
     JOCUSKLMEqQABPWybIjRhvXkrDgYHN=JOCUSKLMEqQABPWybIjRhvXkrDgYHN.replace('\'','\"')
     JOCUSKLMEqQABPWybIjRhvXkrDgYHN=json.loads(JOCUSKLMEqQABPWybIjRhvXkrDgYHN)
    except:
     JOCUSKLMEqQABPWybIjRhvXkrDgYsn
    JOCUSKLMEqQABPWybIjRhvXkrDgYGt={}
    JOCUSKLMEqQABPWybIjRhvXkrDgYGt['plot']=JOCUSKLMEqQABPWybIjRhvXkrDgYVc
    if JOCUSKLMEqQABPWybIjRhvXkrDgYHc=='movie':
     JOCUSKLMEqQABPWybIjRhvXkrDgYGt['mediatype']='movie'
     JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'MOVIE','page':'1','movie_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaH,'season_code':'-','title':JOCUSKLMEqQABPWybIjRhvXkrDgYVc,'thumbnail':JOCUSKLMEqQABPWybIjRhvXkrDgYHN}
     JOCUSKLMEqQABPWybIjRhvXkrDgYVi=JOCUSKLMEqQABPWybIjRhvXkrDgYsx
    else:
     if JOCUSKLMEqQABPWybIjRhvXkrDgYVN==JOCUSKLMEqQABPWybIjRhvXkrDgYsx or JOCUSKLMEqQABPWybIjRhvXkrDgYnx==JOCUSKLMEqQABPWybIjRhvXkrDgYsn:
      JOCUSKLMEqQABPWybIjRhvXkrDgYGt['mediatype']='tvshow'
      JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'EPISODE','page':'1','movie_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaH,'season_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaH,'title':JOCUSKLMEqQABPWybIjRhvXkrDgYVc,'thumbnail':JOCUSKLMEqQABPWybIjRhvXkrDgYHN}
      JOCUSKLMEqQABPWybIjRhvXkrDgYVi=JOCUSKLMEqQABPWybIjRhvXkrDgYsz
     else:
      JOCUSKLMEqQABPWybIjRhvXkrDgYGt['mediatype']='episode'
      JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'MOVIE','movie_code':JOCUSKLMEqQABPWybIjRhvXkrDgYnx,'season_code':JOCUSKLMEqQABPWybIjRhvXkrDgYaH,'title':JOCUSKLMEqQABPWybIjRhvXkrDgYVc,'thumbnail':JOCUSKLMEqQABPWybIjRhvXkrDgYHN}
      JOCUSKLMEqQABPWybIjRhvXkrDgYVi=JOCUSKLMEqQABPWybIjRhvXkrDgYsx
    JOCUSKLMEqQABPWybIjRhvXkrDgYdN={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':JOCUSKLMEqQABPWybIjRhvXkrDgYaH,'vType':JOCUSKLMEqQABPWybIjRhvXkrDgYHc,}
    JOCUSKLMEqQABPWybIjRhvXkrDgYdp=urllib.parse.urlencode(JOCUSKLMEqQABPWybIjRhvXkrDgYdN)
    JOCUSKLMEqQABPWybIjRhvXkrDgYGo=[('선택된 시청이력 ( %s ) 삭제'%(JOCUSKLMEqQABPWybIjRhvXkrDgYVc),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(JOCUSKLMEqQABPWybIjRhvXkrDgYdp))]
    JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel='',img=JOCUSKLMEqQABPWybIjRhvXkrDgYHN,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYGt,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYVi,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl,ContextMenu=JOCUSKLMEqQABPWybIjRhvXkrDgYGo)
   JOCUSKLMEqQABPWybIjRhvXkrDgYGt={'plot':'시청목록을 삭제합니다.'}
   JOCUSKLMEqQABPWybIjRhvXkrDgYVc='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   JOCUSKLMEqQABPWybIjRhvXkrDgYVl={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':JOCUSKLMEqQABPWybIjRhvXkrDgYHc,}
   JOCUSKLMEqQABPWybIjRhvXkrDgYVT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.add_dir(JOCUSKLMEqQABPWybIjRhvXkrDgYVc,sublabel='',img=JOCUSKLMEqQABPWybIjRhvXkrDgYVT,infoLabels=JOCUSKLMEqQABPWybIjRhvXkrDgYGt,isFolder=JOCUSKLMEqQABPWybIjRhvXkrDgYsx,params=JOCUSKLMEqQABPWybIjRhvXkrDgYVl,isLink=JOCUSKLMEqQABPWybIjRhvXkrDgYsz)
   if JOCUSKLMEqQABPWybIjRhvXkrDgYHc=='movie':xbmcplugin.setContent(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,'movies')
   else:xbmcplugin.setContent(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(JOCUSKLMEqQABPWybIjRhvXkrDgYfn._addon_handle,cacheToDisc=JOCUSKLMEqQABPWybIjRhvXkrDgYsx)
 def Save_Searched_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,JOCUSKLMEqQABPWybIjRhvXkrDgYdw):
  try:
   JOCUSKLMEqQABPWybIjRhvXkrDgYnN=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_SEARCHEDC_FILENAME
   JOCUSKLMEqQABPWybIjRhvXkrDgYdi=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.Load_List_File('search') 
   JOCUSKLMEqQABPWybIjRhvXkrDgYnp={'skey':JOCUSKLMEqQABPWybIjRhvXkrDgYdw.strip()}
   fp=JOCUSKLMEqQABPWybIjRhvXkrDgYso(JOCUSKLMEqQABPWybIjRhvXkrDgYnN,'w',-1,'utf-8')
   JOCUSKLMEqQABPWybIjRhvXkrDgYnH=urllib.parse.urlencode(JOCUSKLMEqQABPWybIjRhvXkrDgYnp)
   JOCUSKLMEqQABPWybIjRhvXkrDgYnH=JOCUSKLMEqQABPWybIjRhvXkrDgYnH+'\n'
   fp.write(JOCUSKLMEqQABPWybIjRhvXkrDgYnH)
   JOCUSKLMEqQABPWybIjRhvXkrDgYna=0
   for JOCUSKLMEqQABPWybIjRhvXkrDgYdm in JOCUSKLMEqQABPWybIjRhvXkrDgYdi:
    JOCUSKLMEqQABPWybIjRhvXkrDgYdF=JOCUSKLMEqQABPWybIjRhvXkrDgYsp(urllib.parse.parse_qsl(JOCUSKLMEqQABPWybIjRhvXkrDgYdm))
    JOCUSKLMEqQABPWybIjRhvXkrDgYnG=JOCUSKLMEqQABPWybIjRhvXkrDgYnp.get('skey').strip()
    JOCUSKLMEqQABPWybIjRhvXkrDgYnd=JOCUSKLMEqQABPWybIjRhvXkrDgYdF.get('skey').strip()
    if JOCUSKLMEqQABPWybIjRhvXkrDgYnG!=JOCUSKLMEqQABPWybIjRhvXkrDgYnd:
     fp.write(JOCUSKLMEqQABPWybIjRhvXkrDgYdm)
     JOCUSKLMEqQABPWybIjRhvXkrDgYna+=1
     if JOCUSKLMEqQABPWybIjRhvXkrDgYna>=50:break
   fp.close()
  except:
   JOCUSKLMEqQABPWybIjRhvXkrDgYsn
 def logout(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  JOCUSKLMEqQABPWybIjRhvXkrDgYfN=xbmcgui.Dialog()
  JOCUSKLMEqQABPWybIjRhvXkrDgYHa=JOCUSKLMEqQABPWybIjRhvXkrDgYfN.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if JOCUSKLMEqQABPWybIjRhvXkrDgYHa==JOCUSKLMEqQABPWybIjRhvXkrDgYsx:sys.exit()
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.Init_WC_Total()
  if os.path.isfile(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_COOKIE_FILENAME):os.remove(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_COOKIE_FILENAME)
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  JOCUSKLMEqQABPWybIjRhvXkrDgYnw =JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.Get_Now_Datetime()
  JOCUSKLMEqQABPWybIjRhvXkrDgYnc=JOCUSKLMEqQABPWybIjRhvXkrDgYnw+datetime.timedelta(days=JOCUSKLMEqQABPWybIjRhvXkrDgYse(__addon__.getSetting('cache_ttl')))
  (JOCUSKLMEqQABPWybIjRhvXkrDgYVu,JOCUSKLMEqQABPWybIjRhvXkrDgYHf,JOCUSKLMEqQABPWybIjRhvXkrDgYHV)=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_settings_account()
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.Save_session_acount(JOCUSKLMEqQABPWybIjRhvXkrDgYVu,JOCUSKLMEqQABPWybIjRhvXkrDgYHf,JOCUSKLMEqQABPWybIjRhvXkrDgYHV)
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC['account']['token_limit']=JOCUSKLMEqQABPWybIjRhvXkrDgYnc.strftime('%Y%m%d')
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.JsonFile_Save(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_COOKIE_FILENAME,JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC)
 def cookiefile_check(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.JsonFile_Load(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC_COOKIE_FILENAME)
  if 'account' not in JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC:
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.Init_WC_Total()
   return JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  if 'deviceId2' not in JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC['cookies']:
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.Init_WC_Total()
   return JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  (JOCUSKLMEqQABPWybIjRhvXkrDgYnt,JOCUSKLMEqQABPWybIjRhvXkrDgYno,JOCUSKLMEqQABPWybIjRhvXkrDgYnT)=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.get_settings_account()
  (JOCUSKLMEqQABPWybIjRhvXkrDgYnl,JOCUSKLMEqQABPWybIjRhvXkrDgYni,JOCUSKLMEqQABPWybIjRhvXkrDgYnm)=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.Load_session_acount()
  if JOCUSKLMEqQABPWybIjRhvXkrDgYnt!=JOCUSKLMEqQABPWybIjRhvXkrDgYnl or JOCUSKLMEqQABPWybIjRhvXkrDgYno!=JOCUSKLMEqQABPWybIjRhvXkrDgYni or JOCUSKLMEqQABPWybIjRhvXkrDgYnT!=JOCUSKLMEqQABPWybIjRhvXkrDgYnm:
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.Init_WC_Total()
   return JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  if JOCUSKLMEqQABPWybIjRhvXkrDgYse(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))>JOCUSKLMEqQABPWybIjRhvXkrDgYse(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.WC['account']['token_limit']):
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.Init_WC_Total()
   return JOCUSKLMEqQABPWybIjRhvXkrDgYsx
  return JOCUSKLMEqQABPWybIjRhvXkrDgYsz
 def dp_Global_Search(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYnF=args.get('mode')
  if JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='TOTAL_SEARCH':
   JOCUSKLMEqQABPWybIjRhvXkrDgYnu='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   JOCUSKLMEqQABPWybIjRhvXkrDgYnu='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(JOCUSKLMEqQABPWybIjRhvXkrDgYnu)
 def dp_Bookmark_Menu(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYnu='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(JOCUSKLMEqQABPWybIjRhvXkrDgYnu)
 def dp_Set_Bookmark(JOCUSKLMEqQABPWybIjRhvXkrDgYfn,args):
  JOCUSKLMEqQABPWybIjRhvXkrDgYdc=urllib.parse.unquote(args.get('bm_param'))
  JOCUSKLMEqQABPWybIjRhvXkrDgYdc=json.loads(JOCUSKLMEqQABPWybIjRhvXkrDgYdc)
  JOCUSKLMEqQABPWybIjRhvXkrDgYnx =JOCUSKLMEqQABPWybIjRhvXkrDgYdc.get('videoid')
  JOCUSKLMEqQABPWybIjRhvXkrDgYsf =JOCUSKLMEqQABPWybIjRhvXkrDgYdc.get('vidtype')
  JOCUSKLMEqQABPWybIjRhvXkrDgYsV =JOCUSKLMEqQABPWybIjRhvXkrDgYdc.get('vtitle')
  JOCUSKLMEqQABPWybIjRhvXkrDgYsH =JOCUSKLMEqQABPWybIjRhvXkrDgYdc.get('vsubtitle')
  JOCUSKLMEqQABPWybIjRhvXkrDgYfN=xbmcgui.Dialog()
  JOCUSKLMEqQABPWybIjRhvXkrDgYHa=JOCUSKLMEqQABPWybIjRhvXkrDgYfN.yesno(__language__(30913).encode('utf8'),JOCUSKLMEqQABPWybIjRhvXkrDgYsV+' \n\n'+__language__(30914))
  if JOCUSKLMEqQABPWybIjRhvXkrDgYHa==JOCUSKLMEqQABPWybIjRhvXkrDgYsx:return
  JOCUSKLMEqQABPWybIjRhvXkrDgYsa=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.WatchaObj.GetBookmarkInfo(JOCUSKLMEqQABPWybIjRhvXkrDgYnx,JOCUSKLMEqQABPWybIjRhvXkrDgYsf)
  JOCUSKLMEqQABPWybIjRhvXkrDgYsG=json.dumps(JOCUSKLMEqQABPWybIjRhvXkrDgYsa)
  JOCUSKLMEqQABPWybIjRhvXkrDgYsG=urllib.parse.quote(JOCUSKLMEqQABPWybIjRhvXkrDgYsG)
  JOCUSKLMEqQABPWybIjRhvXkrDgYGi ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(JOCUSKLMEqQABPWybIjRhvXkrDgYsG)
  xbmc.executebuiltin(JOCUSKLMEqQABPWybIjRhvXkrDgYGi)
 def watcha_main(JOCUSKLMEqQABPWybIjRhvXkrDgYfn):
  JOCUSKLMEqQABPWybIjRhvXkrDgYnF=JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params.get('mode',JOCUSKLMEqQABPWybIjRhvXkrDgYsn)
  if JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='LOGOUT':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.logout()
   return
  JOCUSKLMEqQABPWybIjRhvXkrDgYfn.login_main()
  if JOCUSKLMEqQABPWybIjRhvXkrDgYnF is JOCUSKLMEqQABPWybIjRhvXkrDgYsn:
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Main_List()
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='HOME_GROUP':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_HomeGroup_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='SUB_GROUP':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_SubGroup_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='CATEGORY_LIST':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Category_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='SEASON':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Season_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='EPISODE':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Episode_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='ORDER_BY':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_setEpOrderby(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF in['SEARCH','LOCAL_SEARCH']:
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Search_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='MOVIE':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.play_VIDEO(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='WATCH':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Watch_List(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_History_Remove(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF in['TOTAL_SEARCH','TOTAL_HISTORY']:
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Global_Search(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='SEARCH_HISTORY':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Search_History(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='MENU_BOOKMARK':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Bookmark_Menu(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='SET_BOOKMARK':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Set_Bookmark(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  elif JOCUSKLMEqQABPWybIjRhvXkrDgYnF=='DELETE_CONTINUE':
   JOCUSKLMEqQABPWybIjRhvXkrDgYfn.dp_Delete_Continue(JOCUSKLMEqQABPWybIjRhvXkrDgYfn.main_params)
  else:
   JOCUSKLMEqQABPWybIjRhvXkrDgYsn
# Created by pyminifier (https://github.com/liftoff/pyminifier)
