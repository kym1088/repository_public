import threading
HnmRfJNIBPjGSEzAgLwtupKCFcMlrV=IOError
HnmRfJNIBPjGSEzAgLwtupKCFcMlqh=OSError
HnmRfJNIBPjGSEzAgLwtupKCFcMlqr=dict
HnmRfJNIBPjGSEzAgLwtupKCFcMlqd=print
HnmRfJNIBPjGSEzAgLwtupKCFcMlqQ=len
HnmRfJNIBPjGSEzAgLwtupKCFcMlqa=int
HnmRfJNIBPjGSEzAgLwtupKCFcMlqi=None
HnmRfJNIBPjGSEzAgLwtupKCFcMlqY=Exception
HnmRfJNIBPjGSEzAgLwtupKCFcMlqv=False
HnmRfJNIBPjGSEzAgLwtupKCFcMlqo=True
HnmRfJNIBPjGSEzAgLwtupKCFcMlqs=list
HnmRfJNIBPjGSEzAgLwtupKCFcMlqy=str
HnmRfJNIBPjGSEzAgLwtupKCFcMlqD=open
HnmRfJNIBPjGSEzAgLwtupKCFcMlqX=object
from http.server import HTTPServer,BaseHTTPRequestHandler
import requests
import urllib
import json
import base64
import re
import xml.etree.ElementTree as ET
import io
import os
import xml.dom.minidom
HnmRfJNIBPjGSEzAgLwtupKCFcMlhd =['proxy-mini','host','referer','upgrade']
HnmRfJNIBPjGSEzAgLwtupKCFcMlhQ=['date','server','set-cookie','keep-alive','connection','transfer-encoding','content-encoding','content-length']
HnmRfJNIBPjGSEzAgLwtupKCFcMlha={'-':0,'2CH':1,'6CH':2,'ATMOS':3,}
class HnmRfJNIBPjGSEzAgLwtupKCFcMlrb(BaseHTTPRequestHandler):
 def __init__(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi,request,client_address,server):
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.HTTP_CLIENT=requests.Session()
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO ={}
  try:
   BaseHTTPRequestHandler.__init__(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi,request,client_address,server)
  except(HnmRfJNIBPjGSEzAgLwtupKCFcMlrV,HnmRfJNIBPjGSEzAgLwtupKCFcMlqh)as e:
   pass
 def Make_Header(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi,header_exceptList=[]):
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhY={}
  header_exceptList.extend(HnmRfJNIBPjGSEzAgLwtupKCFcMlhd)
  for HnmRfJNIBPjGSEzAgLwtupKCFcMlhv,value in HnmRfJNIBPjGSEzAgLwtupKCFcMlqr(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.headers).items():
   if HnmRfJNIBPjGSEzAgLwtupKCFcMlhv.lower()not in header_exceptList:
    HnmRfJNIBPjGSEzAgLwtupKCFcMlhY[HnmRfJNIBPjGSEzAgLwtupKCFcMlhv.lower()]=value
  return HnmRfJNIBPjGSEzAgLwtupKCFcMlhY
 def Make_NewUrl(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi,scheme,netloc,path,params='',query='',fragemnt=''):
  HnmRfJNIBPjGSEzAgLwtupKCFcMlho=(scheme,netloc,path,params,query,fragemnt)
  return urllib.parse.urlunparse(HnmRfJNIBPjGSEzAgLwtupKCFcMlho)
 def Send_BlankImage(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi):
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.send_response(200)
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.send_header('Content-Type','image/x-icon')
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.send_header('Content-Length',0)
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.end_headers()
 def Send_ErrorPage(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi):
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.send_response(200)
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.send_header('Content-Type','text/html; charset=UTF-8')
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.end_headers()
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.wfile.write('request error!'.encode('utf-8'))
 def Parse_BaseRequest(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi):
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO={}
  try:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['url'] =HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.path.strip('/')
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhs=HnmRfJNIBPjGSEzAgLwtupKCFcMlqr(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.headers).get('proxy-mini')
   if HnmRfJNIBPjGSEzAgLwtupKCFcMlhs:
    HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['addon']=json.loads(base64.standard_b64decode(HnmRfJNIBPjGSEzAgLwtupKCFcMlhs).decode('utf-8'))
   else:
    HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['addon']={}
   HnmRfJNIBPjGSEzAgLwtupKCFcMlqd(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['addon'])
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhy=urllib.parse.urlparse(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['url']) 
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['scheme'] =HnmRfJNIBPjGSEzAgLwtupKCFcMlhy.scheme
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['netloc'] =HnmRfJNIBPjGSEzAgLwtupKCFcMlhy.netloc
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['path'] =HnmRfJNIBPjGSEzAgLwtupKCFcMlhy.path.strip('/').split('/')
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['last_path']=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['path'][HnmRfJNIBPjGSEzAgLwtupKCFcMlqQ(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['path'])-1]
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['query'] =HnmRfJNIBPjGSEzAgLwtupKCFcMlqr(urllib.parse.parse_qsl(HnmRfJNIBPjGSEzAgLwtupKCFcMlhy.query))
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhD=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['last_path'].split('.')
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['last_type']=HnmRfJNIBPjGSEzAgLwtupKCFcMlhD[HnmRfJNIBPjGSEzAgLwtupKCFcMlqQ(HnmRfJNIBPjGSEzAgLwtupKCFcMlhD)-1]
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhX=HnmRfJNIBPjGSEzAgLwtupKCFcMlqa(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.headers.get('content-length',0))
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['postData']=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.rfile.read(HnmRfJNIBPjGSEzAgLwtupKCFcMlhX)if HnmRfJNIBPjGSEzAgLwtupKCFcMlhX else HnmRfJNIBPjGSEzAgLwtupKCFcMlqi
  except HnmRfJNIBPjGSEzAgLwtupKCFcMlqY as e:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlqd(HnmRfJNIBPjGSEzAgLwtupKCFcMlqY)
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO={}
   return HnmRfJNIBPjGSEzAgLwtupKCFcMlqv
  return HnmRfJNIBPjGSEzAgLwtupKCFcMlqo
 def Output_Headers(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi,HnmRfJNIBPjGSEzAgLwtupKCFcMlhk):
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.send_response(HnmRfJNIBPjGSEzAgLwtupKCFcMlhk.status_code)
  for HnmRfJNIBPjGSEzAgLwtupKCFcMlhT in HnmRfJNIBPjGSEzAgLwtupKCFcMlqs(HnmRfJNIBPjGSEzAgLwtupKCFcMlhk.headers.items()):
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.send_header(HnmRfJNIBPjGSEzAgLwtupKCFcMlhT[0],HnmRfJNIBPjGSEzAgLwtupKCFcMlhT[1])
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.end_headers()
 def Output_Response(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi,HnmRfJNIBPjGSEzAgLwtupKCFcMlhk,res_data=HnmRfJNIBPjGSEzAgLwtupKCFcMlqi,header_exceptList=[]):
  for HnmRfJNIBPjGSEzAgLwtupKCFcMlhT in HnmRfJNIBPjGSEzAgLwtupKCFcMlqs(HnmRfJNIBPjGSEzAgLwtupKCFcMlhk.headers.items()):
   if HnmRfJNIBPjGSEzAgLwtupKCFcMlhT[0].lower()in HnmRfJNIBPjGSEzAgLwtupKCFcMlhQ or HnmRfJNIBPjGSEzAgLwtupKCFcMlhT[0].lower()in header_exceptList:
    HnmRfJNIBPjGSEzAgLwtupKCFcMlhk.headers.pop(HnmRfJNIBPjGSEzAgLwtupKCFcMlhT[0],HnmRfJNIBPjGSEzAgLwtupKCFcMlqi)
  if res_data:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhe=res_data.encode('utf-8')
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhk.headers['content-length'] =HnmRfJNIBPjGSEzAgLwtupKCFcMlqy(HnmRfJNIBPjGSEzAgLwtupKCFcMlqQ(HnmRfJNIBPjGSEzAgLwtupKCFcMlhe))
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Output_Headers(HnmRfJNIBPjGSEzAgLwtupKCFcMlhk)
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.wfile.write(HnmRfJNIBPjGSEzAgLwtupKCFcMlhe)
  else:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Output_Headers(HnmRfJNIBPjGSEzAgLwtupKCFcMlhk)
   for HnmRfJNIBPjGSEzAgLwtupKCFcMlhO in HnmRfJNIBPjGSEzAgLwtupKCFcMlhk.iter_content(1048576):
    try:
     HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.wfile.write(HnmRfJNIBPjGSEzAgLwtupKCFcMlhO)
    except HnmRfJNIBPjGSEzAgLwtupKCFcMlqY as e:
     HnmRfJNIBPjGSEzAgLwtupKCFcMlqd(e)
     break
 def do_HEAD(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi):
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.send_response(200)
 def do_POST(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi):
  if HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Parse_BaseRequest()==HnmRfJNIBPjGSEzAgLwtupKCFcMlqv:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.send_response(404)
   return 
  try:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhk=requests.post(url=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['url'],headers=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Make_Header(),data=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['postData'],stream=HnmRfJNIBPjGSEzAgLwtupKCFcMlqo)
  except HnmRfJNIBPjGSEzAgLwtupKCFcMlqY as exception:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlqd(exception)
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Send_ErrorPage()
   return
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Output_Response(HnmRfJNIBPjGSEzAgLwtupKCFcMlhk,res_data=HnmRfJNIBPjGSEzAgLwtupKCFcMlqi,header_exceptList=[])
 def do_GET(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi):
  if HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Parse_BaseRequest()==HnmRfJNIBPjGSEzAgLwtupKCFcMlqv:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.send_response(404)
   return 
  if HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['last_path'].lower()=='favicon.ico':
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Send_BlankImage()
   return 
  if HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['scheme'].lower()not in['http','https']:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.send_response(404)
   return 
  try:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhk=requests.get(url=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['url'],headers=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Make_Header(),stream=HnmRfJNIBPjGSEzAgLwtupKCFcMlqo)
  except HnmRfJNIBPjGSEzAgLwtupKCFcMlqY as exception:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlqd(exception)
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Send_ErrorPage()
   return
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhb=HnmRfJNIBPjGSEzAgLwtupKCFcMlqi
  if HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['last_type'].lower()in['mpd']and HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO.get('addon').get('addon')=='watcham':
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhW=HnmRfJNIBPjGSEzAgLwtupKCFcMlhk.content.decode('utf-8')
   HnmRfJNIBPjGSEzAgLwtupKCFcMlhb=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Watcha_Parse_mpd(HnmRfJNIBPjGSEzAgLwtupKCFcMlhW)
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.Output_Response(HnmRfJNIBPjGSEzAgLwtupKCFcMlhk,HnmRfJNIBPjGSEzAgLwtupKCFcMlhb,header_exceptList=[])
 def Watcha_Parse_mpd(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi,HnmRfJNIBPjGSEzAgLwtupKCFcMlhW):
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhU={'width':0,'bandwidth':0,}
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhV=0
  HnmRfJNIBPjGSEzAgLwtupKCFcMlrh=HnmRfJNIBPjGSEzAgLwtupKCFcMlha[HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['addon']['playOption']['sel_sound']] 
  HnmRfJNIBPjGSEzAgLwtupKCFcMlrq =ET.ElementTree(ET.fromstring(HnmRfJNIBPjGSEzAgLwtupKCFcMlhW))
  HnmRfJNIBPjGSEzAgLwtupKCFcMlrd =HnmRfJNIBPjGSEzAgLwtupKCFcMlrq.getroot()
  HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ=re.match(r'\{.*\}',HnmRfJNIBPjGSEzAgLwtupKCFcMlrd.tag)[0]
  HnmRfJNIBPjGSEzAgLwtupKCFcMlra=HnmRfJNIBPjGSEzAgLwtupKCFcMlqr([node for _,node in ET.iterparse(io.StringIO(HnmRfJNIBPjGSEzAgLwtupKCFcMlhW),events=['start-ns'])])
  for HnmRfJNIBPjGSEzAgLwtupKCFcMlhv,value in HnmRfJNIBPjGSEzAgLwtupKCFcMlra.items():
   ET.register_namespace(HnmRfJNIBPjGSEzAgLwtupKCFcMlhv,value)
  HnmRfJNIBPjGSEzAgLwtupKCFcMlri=HnmRfJNIBPjGSEzAgLwtupKCFcMlrd.find(HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ+'Period')
  for HnmRfJNIBPjGSEzAgLwtupKCFcMlrY in HnmRfJNIBPjGSEzAgLwtupKCFcMlri.findall(HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ+'AdaptationSet'):
   if HnmRfJNIBPjGSEzAgLwtupKCFcMlrY.attrib.get('contentType')=='text':
    HnmRfJNIBPjGSEzAgLwtupKCFcMlri.remove(HnmRfJNIBPjGSEzAgLwtupKCFcMlrY)
    continue
   if HnmRfJNIBPjGSEzAgLwtupKCFcMlrY.attrib.get('contentType')=='video':
    for HnmRfJNIBPjGSEzAgLwtupKCFcMlrv in HnmRfJNIBPjGSEzAgLwtupKCFcMlrY.findall(HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ+'Representation'):
     HnmRfJNIBPjGSEzAgLwtupKCFcMlro =HnmRfJNIBPjGSEzAgLwtupKCFcMlqa(HnmRfJNIBPjGSEzAgLwtupKCFcMlrv.attrib.get('width'))
     HnmRfJNIBPjGSEzAgLwtupKCFcMlrs=HnmRfJNIBPjGSEzAgLwtupKCFcMlqa(HnmRfJNIBPjGSEzAgLwtupKCFcMlrv.attrib.get('bandwidth'))
     if HnmRfJNIBPjGSEzAgLwtupKCFcMlhU['width']<=HnmRfJNIBPjGSEzAgLwtupKCFcMlro and HnmRfJNIBPjGSEzAgLwtupKCFcMlro<=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['addon']['playOption']['max_quality']:
      if HnmRfJNIBPjGSEzAgLwtupKCFcMlhU['bandwidth']<HnmRfJNIBPjGSEzAgLwtupKCFcMlrs:
       HnmRfJNIBPjGSEzAgLwtupKCFcMlhU['width'] =HnmRfJNIBPjGSEzAgLwtupKCFcMlro
       HnmRfJNIBPjGSEzAgLwtupKCFcMlhU['bandwidth']=HnmRfJNIBPjGSEzAgLwtupKCFcMlrs
   if HnmRfJNIBPjGSEzAgLwtupKCFcMlrY.attrib.get('contentType')=='audio':
    for HnmRfJNIBPjGSEzAgLwtupKCFcMlrv in HnmRfJNIBPjGSEzAgLwtupKCFcMlrY.findall(HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ+'Representation'):
     HnmRfJNIBPjGSEzAgLwtupKCFcMlry=HnmRfJNIBPjGSEzAgLwtupKCFcMlha[HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.getAudioAdaptInfo(HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ,HnmRfJNIBPjGSEzAgLwtupKCFcMlrv)]
     if HnmRfJNIBPjGSEzAgLwtupKCFcMlhV<HnmRfJNIBPjGSEzAgLwtupKCFcMlry and HnmRfJNIBPjGSEzAgLwtupKCFcMlry<=HnmRfJNIBPjGSEzAgLwtupKCFcMlrh:
      HnmRfJNIBPjGSEzAgLwtupKCFcMlhV=HnmRfJNIBPjGSEzAgLwtupKCFcMlry
  HnmRfJNIBPjGSEzAgLwtupKCFcMlqd(HnmRfJNIBPjGSEzAgLwtupKCFcMlhV)
  for HnmRfJNIBPjGSEzAgLwtupKCFcMlrY in HnmRfJNIBPjGSEzAgLwtupKCFcMlri.findall(HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ+'AdaptationSet'):
   if HnmRfJNIBPjGSEzAgLwtupKCFcMlrY.attrib.get('contentType')=='video':
    for HnmRfJNIBPjGSEzAgLwtupKCFcMlrv in HnmRfJNIBPjGSEzAgLwtupKCFcMlrY.findall(HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ+'Representation'):
     HnmRfJNIBPjGSEzAgLwtupKCFcMlro =HnmRfJNIBPjGSEzAgLwtupKCFcMlqa(HnmRfJNIBPjGSEzAgLwtupKCFcMlrv.attrib.get('width'))
     HnmRfJNIBPjGSEzAgLwtupKCFcMlrs=HnmRfJNIBPjGSEzAgLwtupKCFcMlqa(HnmRfJNIBPjGSEzAgLwtupKCFcMlrv.attrib.get('bandwidth'))
     if HnmRfJNIBPjGSEzAgLwtupKCFcMlhU['width']!=HnmRfJNIBPjGSEzAgLwtupKCFcMlro or HnmRfJNIBPjGSEzAgLwtupKCFcMlhU['bandwidth']!=HnmRfJNIBPjGSEzAgLwtupKCFcMlrs:
      HnmRfJNIBPjGSEzAgLwtupKCFcMlrY.remove(HnmRfJNIBPjGSEzAgLwtupKCFcMlrv)
   if HnmRfJNIBPjGSEzAgLwtupKCFcMlrY.attrib.get('contentType')=='audio':
    for HnmRfJNIBPjGSEzAgLwtupKCFcMlrv in HnmRfJNIBPjGSEzAgLwtupKCFcMlrY.findall(HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ+'Representation'):
     HnmRfJNIBPjGSEzAgLwtupKCFcMlry=HnmRfJNIBPjGSEzAgLwtupKCFcMlha[HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.getAudioAdaptInfo(HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ,HnmRfJNIBPjGSEzAgLwtupKCFcMlrv)]
     if HnmRfJNIBPjGSEzAgLwtupKCFcMlhV!=HnmRfJNIBPjGSEzAgLwtupKCFcMlry:
      HnmRfJNIBPjGSEzAgLwtupKCFcMlrY.remove(HnmRfJNIBPjGSEzAgLwtupKCFcMlrv)
  HnmRfJNIBPjGSEzAgLwtupKCFcMlqd(HnmRfJNIBPjGSEzAgLwtupKCFcMlhU)
  HnmRfJNIBPjGSEzAgLwtupKCFcMlrD=ET.tostring(HnmRfJNIBPjGSEzAgLwtupKCFcMlrd).decode('utf-8')
  HnmRfJNIBPjGSEzAgLwtupKCFcMlrD=xml.dom.minidom.parseString(HnmRfJNIBPjGSEzAgLwtupKCFcMlrD)
  HnmRfJNIBPjGSEzAgLwtupKCFcMlrD=HnmRfJNIBPjGSEzAgLwtupKCFcMlrD.toprettyxml(indent="  ") 
  try:
   HnmRfJNIBPjGSEzAgLwtupKCFcMlrX=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.REQ_INFO['addon']['playOption']['streamFilename']
   fp=HnmRfJNIBPjGSEzAgLwtupKCFcMlqD(HnmRfJNIBPjGSEzAgLwtupKCFcMlrX,'w',-1,'utf-8')
   fp.write(HnmRfJNIBPjGSEzAgLwtupKCFcMlrD)
   fp.close()
  except HnmRfJNIBPjGSEzAgLwtupKCFcMlqY as exception:
   pass
  return HnmRfJNIBPjGSEzAgLwtupKCFcMlrD
 def getAudioAdaptInfo(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi,HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ,adaptNode):
  if adaptNode.attrib.get('codecs').startswith('ec-3'):return 'ATMOS'
  HnmRfJNIBPjGSEzAgLwtupKCFcMlrT=adaptNode.find(HnmRfJNIBPjGSEzAgLwtupKCFcMlrQ+'AudioChannelConfiguration')
  if HnmRfJNIBPjGSEzAgLwtupKCFcMlrT.attrib.get('value')=='2':return '2CH'
  elif HnmRfJNIBPjGSEzAgLwtupKCFcMlrT.attrib.get('value')=='6':return '6CH'
  return '-'
 def indent(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi,HnmRfJNIBPjGSEzAgLwtupKCFcMlrk,level=0):
  i="\n"+level*"  "
  if HnmRfJNIBPjGSEzAgLwtupKCFcMlqQ(HnmRfJNIBPjGSEzAgLwtupKCFcMlrk):
   if not HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.text or not HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.text.strip():
    HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.text=i+"  "
   if not HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.tail or not HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.tail.strip():
    HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.tail=i
   for HnmRfJNIBPjGSEzAgLwtupKCFcMlrk in HnmRfJNIBPjGSEzAgLwtupKCFcMlrk:
    HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.indent(HnmRfJNIBPjGSEzAgLwtupKCFcMlrk,level+1)
   if not HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.tail or not HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.tail.strip():
    HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.tail=i
  else:
   if level and(not HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.tail or not HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.tail.strip()):
    HnmRfJNIBPjGSEzAgLwtupKCFcMlrk.tail=i
 def _gzip(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi,data=HnmRfJNIBPjGSEzAgLwtupKCFcMlqi):
  from io import BytesIO
  from gzip import GzipFile
  HnmRfJNIBPjGSEzAgLwtupKCFcMlre=BytesIO()
  f=GzipFile(fileobj=HnmRfJNIBPjGSEzAgLwtupKCFcMlre,mode='w',compresslevel=5)
  f.write(data)
  f.close()
  return HnmRfJNIBPjGSEzAgLwtupKCFcMlre.getvalue()
class HnmRfJNIBPjGSEzAgLwtupKCFcMlhq(HnmRfJNIBPjGSEzAgLwtupKCFcMlqX):
 def __init__(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi):
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.started=HnmRfJNIBPjGSEzAgLwtupKCFcMlqv
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.PORT=HnmRfJNIBPjGSEzAgLwtupKCFcMlqi
 def start(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi):
  if HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.started:return
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi._server=HTTPServer(('0.0.0.0',HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.PORT),HnmRfJNIBPjGSEzAgLwtupKCFcMlrb)
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi._httpd_thread=threading.Thread(target=HnmRfJNIBPjGSEzAgLwtupKCFcMlhi._server.serve_forever)
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi._httpd_thread.start()
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.started=HnmRfJNIBPjGSEzAgLwtupKCFcMlqo
 def stop(HnmRfJNIBPjGSEzAgLwtupKCFcMlhi):
  if not HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.started:return
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi._server.shutdown()
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi._server.server_close()
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi._server.socket.close()
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi._httpd_thread.join()
  HnmRfJNIBPjGSEzAgLwtupKCFcMlhi.started=HnmRfJNIBPjGSEzAgLwtupKCFcMlqv
if __name__=="__main__":
 HnmRfJNIBPjGSEzAgLwtupKCFcMlrx=9999
 HnmRfJNIBPjGSEzAgLwtupKCFcMlrU=HTTPServer(('0.0.0.0',HnmRfJNIBPjGSEzAgLwtupKCFcMlrx),HnmRfJNIBPjGSEzAgLwtupKCFcMlrb)
 HnmRfJNIBPjGSEzAgLwtupKCFcMlqd(f'Server running on port : {TEST_PORT}')
 HnmRfJNIBPjGSEzAgLwtupKCFcMlrU.serve_forever()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
