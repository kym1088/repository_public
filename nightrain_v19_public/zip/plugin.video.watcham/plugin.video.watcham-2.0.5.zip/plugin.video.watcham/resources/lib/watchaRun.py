__author__="NightRain"
KEXFjnTeRJyOpodwBgAUItYuLaNQSv=object
KEXFjnTeRJyOpodwBgAUItYuLaNQSW=None
KEXFjnTeRJyOpodwBgAUItYuLaNQSm=int
KEXFjnTeRJyOpodwBgAUItYuLaNQVG=False
KEXFjnTeRJyOpodwBgAUItYuLaNQVM=True
KEXFjnTeRJyOpodwBgAUItYuLaNQVh=len
KEXFjnTeRJyOpodwBgAUItYuLaNQVk=range
KEXFjnTeRJyOpodwBgAUItYuLaNQVS=str
KEXFjnTeRJyOpodwBgAUItYuLaNQVz=open
KEXFjnTeRJyOpodwBgAUItYuLaNQVi=dict
KEXFjnTeRJyOpodwBgAUItYuLaNQVs=Exception
KEXFjnTeRJyOpodwBgAUItYuLaNQVD=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
KEXFjnTeRJyOpodwBgAUItYuLaNQGh=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'검색 (search)','mode':'SEARCH','stype':'-','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-'}]
KEXFjnTeRJyOpodwBgAUItYuLaNQGk=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
KEXFjnTeRJyOpodwBgAUItYuLaNQGS=40
KEXFjnTeRJyOpodwBgAUItYuLaNQGV =20
KEXFjnTeRJyOpodwBgAUItYuLaNQGz='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
KEXFjnTeRJyOpodwBgAUItYuLaNQGi =xbmc.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
KEXFjnTeRJyOpodwBgAUItYuLaNQGs=xbmc.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class KEXFjnTeRJyOpodwBgAUItYuLaNQGM(KEXFjnTeRJyOpodwBgAUItYuLaNQSv):
 def __init__(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,KEXFjnTeRJyOpodwBgAUItYuLaNQGC,KEXFjnTeRJyOpodwBgAUItYuLaNQGl,KEXFjnTeRJyOpodwBgAUItYuLaNQGq):
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_url =KEXFjnTeRJyOpodwBgAUItYuLaNQGC
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_handle=KEXFjnTeRJyOpodwBgAUItYuLaNQGl
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.main_params =KEXFjnTeRJyOpodwBgAUItYuLaNQGq
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj =axXdzuOgtifyvKhVMwJUNHeFEDkLlQ() 
 def addon_noti(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,sting):
  try:
   KEXFjnTeRJyOpodwBgAUItYuLaNQGc=xbmcgui.Dialog()
   KEXFjnTeRJyOpodwBgAUItYuLaNQGc.notification(__addonname__,sting)
  except:
   KEXFjnTeRJyOpodwBgAUItYuLaNQSW
 def addon_log(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,string):
  try:
   KEXFjnTeRJyOpodwBgAUItYuLaNQGx=string.encode('utf-8','ignore')
  except:
   KEXFjnTeRJyOpodwBgAUItYuLaNQGx='addonException: addon_log'
  KEXFjnTeRJyOpodwBgAUItYuLaNQGb=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,KEXFjnTeRJyOpodwBgAUItYuLaNQGx),level=KEXFjnTeRJyOpodwBgAUItYuLaNQGb)
 def get_keyboard_input(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,KEXFjnTeRJyOpodwBgAUItYuLaNQMz):
  KEXFjnTeRJyOpodwBgAUItYuLaNQGf=KEXFjnTeRJyOpodwBgAUItYuLaNQSW
  kb=xbmc.Keyboard()
  kb.setHeading(KEXFjnTeRJyOpodwBgAUItYuLaNQMz)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   KEXFjnTeRJyOpodwBgAUItYuLaNQGf=kb.getText()
  return KEXFjnTeRJyOpodwBgAUItYuLaNQGf
 def get_settings_login_info(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  KEXFjnTeRJyOpodwBgAUItYuLaNQGr =__addon__.getSetting('id')
  KEXFjnTeRJyOpodwBgAUItYuLaNQGP =__addon__.getSetting('pw')
  KEXFjnTeRJyOpodwBgAUItYuLaNQGv=KEXFjnTeRJyOpodwBgAUItYuLaNQSm(__addon__.getSetting('selected_profile'))
  return(KEXFjnTeRJyOpodwBgAUItYuLaNQGr,KEXFjnTeRJyOpodwBgAUItYuLaNQGP,KEXFjnTeRJyOpodwBgAUItYuLaNQGv)
 def get_selQuality(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  try:
   KEXFjnTeRJyOpodwBgAUItYuLaNQGW=['3840x2160/1','1920x1080/1','1280x720/1']
   KEXFjnTeRJyOpodwBgAUItYuLaNQGm=KEXFjnTeRJyOpodwBgAUItYuLaNQSm(__addon__.getSetting('selected_quality'))
   return KEXFjnTeRJyOpodwBgAUItYuLaNQGW[KEXFjnTeRJyOpodwBgAUItYuLaNQGm]
  except:
   KEXFjnTeRJyOpodwBgAUItYuLaNQSW
  return 1080 
 def get_settings_direct_replay(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  KEXFjnTeRJyOpodwBgAUItYuLaNQMG=KEXFjnTeRJyOpodwBgAUItYuLaNQSm(__addon__.getSetting('direct_replay'))
  if KEXFjnTeRJyOpodwBgAUItYuLaNQMG==0:
   return KEXFjnTeRJyOpodwBgAUItYuLaNQVG
  else:
   return KEXFjnTeRJyOpodwBgAUItYuLaNQVM
 def set_winCredential(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,credential):
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh=xbmcgui.Window(10000)
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_LOGINTIME',KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh=xbmcgui.Window(10000)
  KEXFjnTeRJyOpodwBgAUItYuLaNQMk={'watcha_token':KEXFjnTeRJyOpodwBgAUItYuLaNQMh.getProperty('WATCHA_M_TOKEN'),'watcha_guit':KEXFjnTeRJyOpodwBgAUItYuLaNQMh.getProperty('WATCHA_M_GUIT'),'watcha_guitv':KEXFjnTeRJyOpodwBgAUItYuLaNQMh.getProperty('WATCHA_M_GUITV'),'watcha_usercd':KEXFjnTeRJyOpodwBgAUItYuLaNQMh.getProperty('WATCHA_M_USERCD')}
  return KEXFjnTeRJyOpodwBgAUItYuLaNQMk
 def set_winEpisodeOrderby(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,KEXFjnTeRJyOpodwBgAUItYuLaNQMS):
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh=xbmcgui.Window(10000)
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_ORDERBY',KEXFjnTeRJyOpodwBgAUItYuLaNQMS)
 def get_winEpisodeOrderby(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh=xbmcgui.Window(10000)
  return KEXFjnTeRJyOpodwBgAUItYuLaNQMh.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,args):
  KEXFjnTeRJyOpodwBgAUItYuLaNQMS =args.get('orderby')
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.set_winEpisodeOrderby(KEXFjnTeRJyOpodwBgAUItYuLaNQMS)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,label,sublabel='',img='',infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQSW,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQVM,params=''):
  KEXFjnTeRJyOpodwBgAUItYuLaNQMV='%s?%s'%(KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_url,urllib.parse.urlencode(params))
  if sublabel:KEXFjnTeRJyOpodwBgAUItYuLaNQMz='%s < %s >'%(label,sublabel)
  else: KEXFjnTeRJyOpodwBgAUItYuLaNQMz=label
  if not img:img='DefaultFolder.png'
  KEXFjnTeRJyOpodwBgAUItYuLaNQMi=xbmcgui.ListItem(KEXFjnTeRJyOpodwBgAUItYuLaNQMz)
  KEXFjnTeRJyOpodwBgAUItYuLaNQMi.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:KEXFjnTeRJyOpodwBgAUItYuLaNQMi.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:KEXFjnTeRJyOpodwBgAUItYuLaNQMi.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_handle,KEXFjnTeRJyOpodwBgAUItYuLaNQMV,KEXFjnTeRJyOpodwBgAUItYuLaNQMi,isFolder)
 def dp_Main_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  for KEXFjnTeRJyOpodwBgAUItYuLaNQMs in KEXFjnTeRJyOpodwBgAUItYuLaNQGh:
   KEXFjnTeRJyOpodwBgAUItYuLaNQMz=KEXFjnTeRJyOpodwBgAUItYuLaNQMs.get('title')
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD={'mode':KEXFjnTeRJyOpodwBgAUItYuLaNQMs.get('mode'),'stype':KEXFjnTeRJyOpodwBgAUItYuLaNQMs.get('stype'),'api_path':KEXFjnTeRJyOpodwBgAUItYuLaNQMs.get('api_path'),'page':'1','sort':KEXFjnTeRJyOpodwBgAUItYuLaNQMs.get('sort'),'tag_id':'-'}
   if KEXFjnTeRJyOpodwBgAUItYuLaNQMs.get('mode')=='XXX':
    KEXFjnTeRJyOpodwBgAUItYuLaNQMD['mode']='XXX'
    KEXFjnTeRJyOpodwBgAUItYuLaNQMC=KEXFjnTeRJyOpodwBgAUItYuLaNQVG
   else:
    KEXFjnTeRJyOpodwBgAUItYuLaNQMC=KEXFjnTeRJyOpodwBgAUItYuLaNQVM
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel='',img='',infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQSW,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQMC,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQVh(KEXFjnTeRJyOpodwBgAUItYuLaNQGh)>0:xbmcplugin.endOfDirectory(KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_handle)
 def login_main(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  (KEXFjnTeRJyOpodwBgAUItYuLaNQMq,KEXFjnTeRJyOpodwBgAUItYuLaNQMH,KEXFjnTeRJyOpodwBgAUItYuLaNQMc)=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_settings_login_info()
  if not(KEXFjnTeRJyOpodwBgAUItYuLaNQMq and KEXFjnTeRJyOpodwBgAUItYuLaNQMH):
   KEXFjnTeRJyOpodwBgAUItYuLaNQGc=xbmcgui.Dialog()
   KEXFjnTeRJyOpodwBgAUItYuLaNQMx=KEXFjnTeRJyOpodwBgAUItYuLaNQGc.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if KEXFjnTeRJyOpodwBgAUItYuLaNQMx==KEXFjnTeRJyOpodwBgAUItYuLaNQVM:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_winEpisodeOrderby()=='':
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.set_winEpisodeOrderby('asc')
  if KEXFjnTeRJyOpodwBgAUItYuLaNQGD.cookiefile_check():return
  KEXFjnTeRJyOpodwBgAUItYuLaNQMb =KEXFjnTeRJyOpodwBgAUItYuLaNQSm(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  KEXFjnTeRJyOpodwBgAUItYuLaNQMf=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if KEXFjnTeRJyOpodwBgAUItYuLaNQMf==KEXFjnTeRJyOpodwBgAUItYuLaNQSW or KEXFjnTeRJyOpodwBgAUItYuLaNQMf=='':
   KEXFjnTeRJyOpodwBgAUItYuLaNQMf=KEXFjnTeRJyOpodwBgAUItYuLaNQSm('19000101')
  else:
   KEXFjnTeRJyOpodwBgAUItYuLaNQMf=KEXFjnTeRJyOpodwBgAUItYuLaNQSm(re.sub('-','',KEXFjnTeRJyOpodwBgAUItYuLaNQMf))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   KEXFjnTeRJyOpodwBgAUItYuLaNQMr=0
   while KEXFjnTeRJyOpodwBgAUItYuLaNQVM:
    KEXFjnTeRJyOpodwBgAUItYuLaNQMr+=1
    time.sleep(0.05)
    if KEXFjnTeRJyOpodwBgAUItYuLaNQMf>=KEXFjnTeRJyOpodwBgAUItYuLaNQMb:return
    if KEXFjnTeRJyOpodwBgAUItYuLaNQMr>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if KEXFjnTeRJyOpodwBgAUItYuLaNQMf>=KEXFjnTeRJyOpodwBgAUItYuLaNQMb:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.GetCredential(KEXFjnTeRJyOpodwBgAUItYuLaNQMq,KEXFjnTeRJyOpodwBgAUItYuLaNQMH,KEXFjnTeRJyOpodwBgAUItYuLaNQMc):
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.set_winCredential(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.LoadCredential())
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,args):
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.SaveCredential(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_winCredential())
  KEXFjnTeRJyOpodwBgAUItYuLaNQMP =args.get('stype')
  KEXFjnTeRJyOpodwBgAUItYuLaNQMv =KEXFjnTeRJyOpodwBgAUItYuLaNQSm(args.get('page'))
  KEXFjnTeRJyOpodwBgAUItYuLaNQMW =args.get('sort')
  KEXFjnTeRJyOpodwBgAUItYuLaNQMm=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.GetSubGroupList(KEXFjnTeRJyOpodwBgAUItYuLaNQMP)
  KEXFjnTeRJyOpodwBgAUItYuLaNQhG=KEXFjnTeRJyOpodwBgAUItYuLaNQGS if KEXFjnTeRJyOpodwBgAUItYuLaNQMP=='genres' else KEXFjnTeRJyOpodwBgAUItYuLaNQGV
  KEXFjnTeRJyOpodwBgAUItYuLaNQhM=KEXFjnTeRJyOpodwBgAUItYuLaNQVh(KEXFjnTeRJyOpodwBgAUItYuLaNQMm)
  KEXFjnTeRJyOpodwBgAUItYuLaNQhk =KEXFjnTeRJyOpodwBgAUItYuLaNQSm(KEXFjnTeRJyOpodwBgAUItYuLaNQhM//(KEXFjnTeRJyOpodwBgAUItYuLaNQhG+1))+1
  KEXFjnTeRJyOpodwBgAUItYuLaNQhS =(KEXFjnTeRJyOpodwBgAUItYuLaNQMv-1)*KEXFjnTeRJyOpodwBgAUItYuLaNQhG
  for i in KEXFjnTeRJyOpodwBgAUItYuLaNQVk(KEXFjnTeRJyOpodwBgAUItYuLaNQhG):
   KEXFjnTeRJyOpodwBgAUItYuLaNQhV=KEXFjnTeRJyOpodwBgAUItYuLaNQhS+i
   if KEXFjnTeRJyOpodwBgAUItYuLaNQhV>=KEXFjnTeRJyOpodwBgAUItYuLaNQhM:break
   KEXFjnTeRJyOpodwBgAUItYuLaNQMz =KEXFjnTeRJyOpodwBgAUItYuLaNQMm[KEXFjnTeRJyOpodwBgAUItYuLaNQhV].get('group_name')
   KEXFjnTeRJyOpodwBgAUItYuLaNQhz =KEXFjnTeRJyOpodwBgAUItYuLaNQMm[KEXFjnTeRJyOpodwBgAUItYuLaNQhV].get('api_path')
   KEXFjnTeRJyOpodwBgAUItYuLaNQhi =KEXFjnTeRJyOpodwBgAUItYuLaNQMm[KEXFjnTeRJyOpodwBgAUItYuLaNQhV].get('tag_id')
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD={'mode':'CATEGORY_LIST','api_path':KEXFjnTeRJyOpodwBgAUItYuLaNQhz,'tag_id':KEXFjnTeRJyOpodwBgAUItYuLaNQhi,'stype':KEXFjnTeRJyOpodwBgAUItYuLaNQMP,'page':'1','sort':KEXFjnTeRJyOpodwBgAUItYuLaNQMW}
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel='',img='',infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQSW,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQVM,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQhk>KEXFjnTeRJyOpodwBgAUItYuLaNQMv:
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD={}
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['mode'] ='SUB_GROUP' 
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['stype'] =KEXFjnTeRJyOpodwBgAUItYuLaNQMP
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['api_path']=args.get('api_path')
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['page'] =KEXFjnTeRJyOpodwBgAUItYuLaNQVS(KEXFjnTeRJyOpodwBgAUItYuLaNQMv+1)
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['sort'] =KEXFjnTeRJyOpodwBgAUItYuLaNQMW
   KEXFjnTeRJyOpodwBgAUItYuLaNQMz='[B]%s >>[/B]'%'다음 페이지'
   KEXFjnTeRJyOpodwBgAUItYuLaNQhs=KEXFjnTeRJyOpodwBgAUItYuLaNQVS(KEXFjnTeRJyOpodwBgAUItYuLaNQMv+1)
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel=KEXFjnTeRJyOpodwBgAUItYuLaNQhs,img='',infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQSW,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQVM,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQVh(KEXFjnTeRJyOpodwBgAUItYuLaNQMm)>0:xbmcplugin.endOfDirectory(KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_handle,cacheToDisc=KEXFjnTeRJyOpodwBgAUItYuLaNQVM)
 def play_VIDEO(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,args):
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.SaveCredential(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_winCredential())
  KEXFjnTeRJyOpodwBgAUItYuLaNQhD =args.get('movie_code')
  KEXFjnTeRJyOpodwBgAUItYuLaNQhC =args.get('season_code')
  KEXFjnTeRJyOpodwBgAUItYuLaNQMz =args.get('title')
  KEXFjnTeRJyOpodwBgAUItYuLaNQhl =args.get('thumbnail')
  KEXFjnTeRJyOpodwBgAUItYuLaNQhq =KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_selQuality()
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.addon_log(KEXFjnTeRJyOpodwBgAUItYuLaNQhD+' - '+KEXFjnTeRJyOpodwBgAUItYuLaNQhC)
  KEXFjnTeRJyOpodwBgAUItYuLaNQhH,KEXFjnTeRJyOpodwBgAUItYuLaNQhc,KEXFjnTeRJyOpodwBgAUItYuLaNQhx=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.GetStreamingURL(KEXFjnTeRJyOpodwBgAUItYuLaNQhD,KEXFjnTeRJyOpodwBgAUItYuLaNQhq)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQhH=='':
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.addon_noti(__language__(30908).encode('utf8'))
   return
  KEXFjnTeRJyOpodwBgAUItYuLaNQhb=KEXFjnTeRJyOpodwBgAUItYuLaNQhH
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.addon_log(KEXFjnTeRJyOpodwBgAUItYuLaNQhb)
  KEXFjnTeRJyOpodwBgAUItYuLaNQhf=xbmcgui.ListItem(path=KEXFjnTeRJyOpodwBgAUItYuLaNQhb)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQhx:
   KEXFjnTeRJyOpodwBgAUItYuLaNQhr=KEXFjnTeRJyOpodwBgAUItYuLaNQhx
   KEXFjnTeRJyOpodwBgAUItYuLaNQhP ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   KEXFjnTeRJyOpodwBgAUItYuLaNQhv ='mpd'
   KEXFjnTeRJyOpodwBgAUItYuLaNQhW ='com.widevine.alpha'
   KEXFjnTeRJyOpodwBgAUItYuLaNQhm =inputstreamhelper.Helper(KEXFjnTeRJyOpodwBgAUItYuLaNQhv,drm=KEXFjnTeRJyOpodwBgAUItYuLaNQhW)
   if KEXFjnTeRJyOpodwBgAUItYuLaNQhm.check_inputstream():
    KEXFjnTeRJyOpodwBgAUItYuLaNQkG={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+KEXFjnTeRJyOpodwBgAUItYuLaNQhD,'dt-custom-data':KEXFjnTeRJyOpodwBgAUItYuLaNQhr,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':KEXFjnTeRJyOpodwBgAUItYuLaNQGz,'Content-Type':'application/octet-stream'}
    KEXFjnTeRJyOpodwBgAUItYuLaNQkM=KEXFjnTeRJyOpodwBgAUItYuLaNQhP+'|'+urllib.parse.urlencode(KEXFjnTeRJyOpodwBgAUItYuLaNQkG)+'|R{SSM}|'
    KEXFjnTeRJyOpodwBgAUItYuLaNQGD.addon_log(KEXFjnTeRJyOpodwBgAUItYuLaNQkM)
    KEXFjnTeRJyOpodwBgAUItYuLaNQhf.setProperty('inputstream',KEXFjnTeRJyOpodwBgAUItYuLaNQhm.inputstream_addon)
    KEXFjnTeRJyOpodwBgAUItYuLaNQhf.setProperty('inputstream.adaptive.manifest_type',KEXFjnTeRJyOpodwBgAUItYuLaNQhv)
    KEXFjnTeRJyOpodwBgAUItYuLaNQhf.setProperty('inputstream.adaptive.license_type',KEXFjnTeRJyOpodwBgAUItYuLaNQhW)
    KEXFjnTeRJyOpodwBgAUItYuLaNQhf.setProperty('inputstream.adaptive.license_key',KEXFjnTeRJyOpodwBgAUItYuLaNQkM)
    KEXFjnTeRJyOpodwBgAUItYuLaNQhf.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(KEXFjnTeRJyOpodwBgAUItYuLaNQGz))
  if KEXFjnTeRJyOpodwBgAUItYuLaNQhc:
   try:
    f=KEXFjnTeRJyOpodwBgAUItYuLaNQVz(KEXFjnTeRJyOpodwBgAUItYuLaNQGi,'w',-1,'utf-8')
    KEXFjnTeRJyOpodwBgAUItYuLaNQkh=requests.get(KEXFjnTeRJyOpodwBgAUItYuLaNQhc)
    KEXFjnTeRJyOpodwBgAUItYuLaNQkS=KEXFjnTeRJyOpodwBgAUItYuLaNQkh.content.decode('utf-8') 
    for KEXFjnTeRJyOpodwBgAUItYuLaNQkV in KEXFjnTeRJyOpodwBgAUItYuLaNQkS.splitlines():
     KEXFjnTeRJyOpodwBgAUItYuLaNQkz=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',KEXFjnTeRJyOpodwBgAUItYuLaNQkV)
     f.write(KEXFjnTeRJyOpodwBgAUItYuLaNQkz+'\n')
    f.close()
    KEXFjnTeRJyOpodwBgAUItYuLaNQhf.setSubtitles([KEXFjnTeRJyOpodwBgAUItYuLaNQGi,KEXFjnTeRJyOpodwBgAUItYuLaNQhc])
   except:
    KEXFjnTeRJyOpodwBgAUItYuLaNQhf.setSubtitles([KEXFjnTeRJyOpodwBgAUItYuLaNQhc])
  xbmcplugin.setResolvedUrl(KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_handle,KEXFjnTeRJyOpodwBgAUItYuLaNQVM,KEXFjnTeRJyOpodwBgAUItYuLaNQhf)
  try:
   KEXFjnTeRJyOpodwBgAUItYuLaNQMP='movie' if KEXFjnTeRJyOpodwBgAUItYuLaNQhC=='-' else 'seasons'
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD={'code':KEXFjnTeRJyOpodwBgAUItYuLaNQhD if KEXFjnTeRJyOpodwBgAUItYuLaNQMP=='movie' else KEXFjnTeRJyOpodwBgAUItYuLaNQhC,'img':KEXFjnTeRJyOpodwBgAUItYuLaNQhl,'title':KEXFjnTeRJyOpodwBgAUItYuLaNQMz,'videoid':KEXFjnTeRJyOpodwBgAUItYuLaNQhD}
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.Save_Watched_List(KEXFjnTeRJyOpodwBgAUItYuLaNQMP,KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
  except:
   KEXFjnTeRJyOpodwBgAUItYuLaNQSW
 def dp_Category_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,args):
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.SaveCredential(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_winCredential())
  KEXFjnTeRJyOpodwBgAUItYuLaNQMP =args.get('stype')
  KEXFjnTeRJyOpodwBgAUItYuLaNQhi =args.get('tag_id')
  KEXFjnTeRJyOpodwBgAUItYuLaNQhz=args.get('api_path')
  KEXFjnTeRJyOpodwBgAUItYuLaNQMv=KEXFjnTeRJyOpodwBgAUItYuLaNQSm(args.get('page'))
  KEXFjnTeRJyOpodwBgAUItYuLaNQMW =args.get('sort')
  KEXFjnTeRJyOpodwBgAUItYuLaNQki,KEXFjnTeRJyOpodwBgAUItYuLaNQks=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.GetCategoryList(KEXFjnTeRJyOpodwBgAUItYuLaNQMP,KEXFjnTeRJyOpodwBgAUItYuLaNQhi,KEXFjnTeRJyOpodwBgAUItYuLaNQhz,KEXFjnTeRJyOpodwBgAUItYuLaNQMv,KEXFjnTeRJyOpodwBgAUItYuLaNQMW)
  for KEXFjnTeRJyOpodwBgAUItYuLaNQkD in KEXFjnTeRJyOpodwBgAUItYuLaNQki:
   KEXFjnTeRJyOpodwBgAUItYuLaNQhD =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('code')
   KEXFjnTeRJyOpodwBgAUItYuLaNQMz =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('title')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkC =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('content_type')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkl =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('story')
   KEXFjnTeRJyOpodwBgAUItYuLaNQhl =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('thumbnail')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkq =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('year')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkH =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('film_rating_code')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkc=KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('film_rating_short')
   if KEXFjnTeRJyOpodwBgAUItYuLaNQkC=='movies': 
    KEXFjnTeRJyOpodwBgAUItYuLaNQMC=KEXFjnTeRJyOpodwBgAUItYuLaNQVG
    KEXFjnTeRJyOpodwBgAUItYuLaNQkx ='MOVIE'
    KEXFjnTeRJyOpodwBgAUItYuLaNQMl=''
    KEXFjnTeRJyOpodwBgAUItYuLaNQhC='-'
   else: 
    KEXFjnTeRJyOpodwBgAUItYuLaNQMC=KEXFjnTeRJyOpodwBgAUItYuLaNQVM
    KEXFjnTeRJyOpodwBgAUItYuLaNQkx ='EPISODE'
    KEXFjnTeRJyOpodwBgAUItYuLaNQMl='Series'
    KEXFjnTeRJyOpodwBgAUItYuLaNQhC=KEXFjnTeRJyOpodwBgAUItYuLaNQhD
   KEXFjnTeRJyOpodwBgAUItYuLaNQkb=KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('info')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkb['plot']='%s (%s)\n년도 : %s\n\n%s'%(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,KEXFjnTeRJyOpodwBgAUItYuLaNQkc,KEXFjnTeRJyOpodwBgAUItYuLaNQkq,KEXFjnTeRJyOpodwBgAUItYuLaNQkl)
   if KEXFjnTeRJyOpodwBgAUItYuLaNQkH>=19:
    KEXFjnTeRJyOpodwBgAUItYuLaNQMz+='  (%s년 - %s)'%(KEXFjnTeRJyOpodwBgAUItYuLaNQkq,KEXFjnTeRJyOpodwBgAUItYuLaNQVS(KEXFjnTeRJyOpodwBgAUItYuLaNQkc))
   else:
    KEXFjnTeRJyOpodwBgAUItYuLaNQMz+='  (%s년)'%(KEXFjnTeRJyOpodwBgAUItYuLaNQkq)
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD={'mode':KEXFjnTeRJyOpodwBgAUItYuLaNQkx,'movie_code':KEXFjnTeRJyOpodwBgAUItYuLaNQhD,'page':'1','season_code':KEXFjnTeRJyOpodwBgAUItYuLaNQhC,'title':KEXFjnTeRJyOpodwBgAUItYuLaNQMz,'thumbnail':KEXFjnTeRJyOpodwBgAUItYuLaNQhl}
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel=KEXFjnTeRJyOpodwBgAUItYuLaNQMl,img=KEXFjnTeRJyOpodwBgAUItYuLaNQhl,infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQkb,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQMC,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQks:
   if KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.GetCategoryList_morepage(KEXFjnTeRJyOpodwBgAUItYuLaNQMP,KEXFjnTeRJyOpodwBgAUItYuLaNQhi,KEXFjnTeRJyOpodwBgAUItYuLaNQhz,KEXFjnTeRJyOpodwBgAUItYuLaNQMv+1,KEXFjnTeRJyOpodwBgAUItYuLaNQMW):
    KEXFjnTeRJyOpodwBgAUItYuLaNQMD={}
    KEXFjnTeRJyOpodwBgAUItYuLaNQMD['mode'] ='CATEGORY_LIST'
    KEXFjnTeRJyOpodwBgAUItYuLaNQMD['stype'] =KEXFjnTeRJyOpodwBgAUItYuLaNQMP
    KEXFjnTeRJyOpodwBgAUItYuLaNQMD['tag_id'] =KEXFjnTeRJyOpodwBgAUItYuLaNQhi
    KEXFjnTeRJyOpodwBgAUItYuLaNQMD['api_path']=KEXFjnTeRJyOpodwBgAUItYuLaNQhz
    KEXFjnTeRJyOpodwBgAUItYuLaNQMD['page'] =KEXFjnTeRJyOpodwBgAUItYuLaNQVS(KEXFjnTeRJyOpodwBgAUItYuLaNQMv+1)
    KEXFjnTeRJyOpodwBgAUItYuLaNQMD['sort'] =KEXFjnTeRJyOpodwBgAUItYuLaNQMW
    KEXFjnTeRJyOpodwBgAUItYuLaNQMz='[B]%s >>[/B]'%'다음 페이지'
    KEXFjnTeRJyOpodwBgAUItYuLaNQhs=KEXFjnTeRJyOpodwBgAUItYuLaNQVS(KEXFjnTeRJyOpodwBgAUItYuLaNQMv+1)
    KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel=KEXFjnTeRJyOpodwBgAUItYuLaNQhs,img='',infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQSW,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQVM,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQVh(KEXFjnTeRJyOpodwBgAUItYuLaNQki)>0:
   if KEXFjnTeRJyOpodwBgAUItYuLaNQhz=='arrivals/latest':
    xbmcplugin.endOfDirectory(KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_handle,cacheToDisc=KEXFjnTeRJyOpodwBgAUItYuLaNQVM)
   else:
    xbmcplugin.endOfDirectory(KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_handle,cacheToDisc=KEXFjnTeRJyOpodwBgAUItYuLaNQVG)
 def dp_Episode_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,args):
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.SaveCredential(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_winCredential())
  KEXFjnTeRJyOpodwBgAUItYuLaNQkr=args.get('movie_code')
  KEXFjnTeRJyOpodwBgAUItYuLaNQMv =KEXFjnTeRJyOpodwBgAUItYuLaNQSm(args.get('page'))
  KEXFjnTeRJyOpodwBgAUItYuLaNQhC =args.get('season_code')
  KEXFjnTeRJyOpodwBgAUItYuLaNQki,KEXFjnTeRJyOpodwBgAUItYuLaNQks=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.GetEpisodoList(KEXFjnTeRJyOpodwBgAUItYuLaNQkr,KEXFjnTeRJyOpodwBgAUItYuLaNQMv,orderby=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_winEpisodeOrderby())
  for KEXFjnTeRJyOpodwBgAUItYuLaNQkD in KEXFjnTeRJyOpodwBgAUItYuLaNQki:
   KEXFjnTeRJyOpodwBgAUItYuLaNQhD =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('code')
   KEXFjnTeRJyOpodwBgAUItYuLaNQMz =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('title')
   KEXFjnTeRJyOpodwBgAUItYuLaNQhl =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('thumbnail')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkP =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('display_num')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkv=KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('season_title')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkb=KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('info')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkb['plot']='%s\n%s\n\n%s'%(KEXFjnTeRJyOpodwBgAUItYuLaNQkv,KEXFjnTeRJyOpodwBgAUItYuLaNQkP,KEXFjnTeRJyOpodwBgAUItYuLaNQMz)
   KEXFjnTeRJyOpodwBgAUItYuLaNQMz='(%s) %s'%(KEXFjnTeRJyOpodwBgAUItYuLaNQkP,KEXFjnTeRJyOpodwBgAUItYuLaNQMz)
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD={'mode':'MOVIE','movie_code':KEXFjnTeRJyOpodwBgAUItYuLaNQhD,'season_code':KEXFjnTeRJyOpodwBgAUItYuLaNQhC,'title':'%s < %s >'%(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,KEXFjnTeRJyOpodwBgAUItYuLaNQkv),'thumbnail':KEXFjnTeRJyOpodwBgAUItYuLaNQhl}
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel=KEXFjnTeRJyOpodwBgAUItYuLaNQkv,img=KEXFjnTeRJyOpodwBgAUItYuLaNQhl,infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQkb,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQVG,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQMv==1:
   KEXFjnTeRJyOpodwBgAUItYuLaNQkb={'plot':'정렬순서를 변경합니다.'}
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD={}
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['mode'] ='ORDER_BY' 
   if KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_winEpisodeOrderby()=='desc':
    KEXFjnTeRJyOpodwBgAUItYuLaNQMz='정렬순서변경 : 최신화부터 -> 1회부터'
    KEXFjnTeRJyOpodwBgAUItYuLaNQMD['orderby']='asc'
   else:
    KEXFjnTeRJyOpodwBgAUItYuLaNQMz='정렬순서변경 : 1회부터 -> 최신화부터'
    KEXFjnTeRJyOpodwBgAUItYuLaNQMD['orderby']='desc'
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel='',img='',infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQkb,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQVG,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQks:
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['mode'] ='EPISODE' 
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['movie_code']=KEXFjnTeRJyOpodwBgAUItYuLaNQkr
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['page'] =KEXFjnTeRJyOpodwBgAUItYuLaNQVS(KEXFjnTeRJyOpodwBgAUItYuLaNQMv+1)
   KEXFjnTeRJyOpodwBgAUItYuLaNQMz='[B]%s >>[/B]'%'다음 페이지'
   KEXFjnTeRJyOpodwBgAUItYuLaNQhs=KEXFjnTeRJyOpodwBgAUItYuLaNQVS(KEXFjnTeRJyOpodwBgAUItYuLaNQMv+1)
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel=KEXFjnTeRJyOpodwBgAUItYuLaNQhs,img='',infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQSW,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQVM,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQVh(KEXFjnTeRJyOpodwBgAUItYuLaNQki)>0:xbmcplugin.endOfDirectory(KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_handle,cacheToDisc=KEXFjnTeRJyOpodwBgAUItYuLaNQVM)
 def dp_Search_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,args):
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.SaveCredential(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_winCredential())
  KEXFjnTeRJyOpodwBgAUItYuLaNQMv =KEXFjnTeRJyOpodwBgAUItYuLaNQSm(args.get('page'))
  if 'search_key' in args:
   KEXFjnTeRJyOpodwBgAUItYuLaNQkW=args.get('search_key')
  else:
   KEXFjnTeRJyOpodwBgAUItYuLaNQkW=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not KEXFjnTeRJyOpodwBgAUItYuLaNQkW:return
  KEXFjnTeRJyOpodwBgAUItYuLaNQki,KEXFjnTeRJyOpodwBgAUItYuLaNQks=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.GetSearchList(KEXFjnTeRJyOpodwBgAUItYuLaNQkW,KEXFjnTeRJyOpodwBgAUItYuLaNQMv)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQVh(KEXFjnTeRJyOpodwBgAUItYuLaNQki)==0:return
  for KEXFjnTeRJyOpodwBgAUItYuLaNQkD in KEXFjnTeRJyOpodwBgAUItYuLaNQki:
   KEXFjnTeRJyOpodwBgAUItYuLaNQhD =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('code')
   KEXFjnTeRJyOpodwBgAUItYuLaNQMz =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('title')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkC=KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('content_type')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkl =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('story')
   KEXFjnTeRJyOpodwBgAUItYuLaNQhl =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('thumbnail')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkq =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('year')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkH =KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('film_rating_code')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkc=KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('film_rating_short')
   if KEXFjnTeRJyOpodwBgAUItYuLaNQkC=='movies': 
    KEXFjnTeRJyOpodwBgAUItYuLaNQMC=KEXFjnTeRJyOpodwBgAUItYuLaNQVG
    KEXFjnTeRJyOpodwBgAUItYuLaNQkx ='MOVIE'
    KEXFjnTeRJyOpodwBgAUItYuLaNQMl=''
    KEXFjnTeRJyOpodwBgAUItYuLaNQhC='-'
   else: 
    KEXFjnTeRJyOpodwBgAUItYuLaNQMC=KEXFjnTeRJyOpodwBgAUItYuLaNQVM
    KEXFjnTeRJyOpodwBgAUItYuLaNQkx ='EPISODE'
    KEXFjnTeRJyOpodwBgAUItYuLaNQMl='Series'
    KEXFjnTeRJyOpodwBgAUItYuLaNQhC=KEXFjnTeRJyOpodwBgAUItYuLaNQhD
   KEXFjnTeRJyOpodwBgAUItYuLaNQkb=KEXFjnTeRJyOpodwBgAUItYuLaNQkD.get('info')
   KEXFjnTeRJyOpodwBgAUItYuLaNQkb['plot']='%s (%s)\n년도 : %s\n\n%s'%(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,KEXFjnTeRJyOpodwBgAUItYuLaNQkc,KEXFjnTeRJyOpodwBgAUItYuLaNQkq,KEXFjnTeRJyOpodwBgAUItYuLaNQkl)
   if KEXFjnTeRJyOpodwBgAUItYuLaNQkH>=19:
    KEXFjnTeRJyOpodwBgAUItYuLaNQMz+='  (%s년 - %s)'%(KEXFjnTeRJyOpodwBgAUItYuLaNQkq,KEXFjnTeRJyOpodwBgAUItYuLaNQVS(KEXFjnTeRJyOpodwBgAUItYuLaNQkc))
   else:
    KEXFjnTeRJyOpodwBgAUItYuLaNQMz+='  (%s년)'%(KEXFjnTeRJyOpodwBgAUItYuLaNQkq)
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD={'mode':KEXFjnTeRJyOpodwBgAUItYuLaNQkx,'movie_code':KEXFjnTeRJyOpodwBgAUItYuLaNQhD,'page':'1','season_code':KEXFjnTeRJyOpodwBgAUItYuLaNQhC,'title':KEXFjnTeRJyOpodwBgAUItYuLaNQMz,'thumbnail':KEXFjnTeRJyOpodwBgAUItYuLaNQhl}
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel=KEXFjnTeRJyOpodwBgAUItYuLaNQMl,img=KEXFjnTeRJyOpodwBgAUItYuLaNQhl,infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQkb,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQMC,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQks:
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD={}
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['mode'] ='SEARCH'
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['search_key']=KEXFjnTeRJyOpodwBgAUItYuLaNQkW
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD['page'] =KEXFjnTeRJyOpodwBgAUItYuLaNQVS(KEXFjnTeRJyOpodwBgAUItYuLaNQMv+1)
   KEXFjnTeRJyOpodwBgAUItYuLaNQMz='[B]%s >>[/B]'%'다음 페이지'
   KEXFjnTeRJyOpodwBgAUItYuLaNQhs=KEXFjnTeRJyOpodwBgAUItYuLaNQVS(KEXFjnTeRJyOpodwBgAUItYuLaNQMv+1)
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel=KEXFjnTeRJyOpodwBgAUItYuLaNQhs,img='',infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQSW,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQVM,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQVh(KEXFjnTeRJyOpodwBgAUItYuLaNQki)>0:xbmcplugin.endOfDirectory(KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_handle)
 def Delete_Watched_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,KEXFjnTeRJyOpodwBgAUItYuLaNQMP):
  try:
   KEXFjnTeRJyOpodwBgAUItYuLaNQkm=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%KEXFjnTeRJyOpodwBgAUItYuLaNQMP))
   fp=KEXFjnTeRJyOpodwBgAUItYuLaNQVz(KEXFjnTeRJyOpodwBgAUItYuLaNQkm,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   KEXFjnTeRJyOpodwBgAUItYuLaNQSW
 def dp_WatchList_Delete(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,args):
  KEXFjnTeRJyOpodwBgAUItYuLaNQMP=args.get('stype')
  KEXFjnTeRJyOpodwBgAUItYuLaNQGc=xbmcgui.Dialog()
  KEXFjnTeRJyOpodwBgAUItYuLaNQMx=KEXFjnTeRJyOpodwBgAUItYuLaNQGc.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if KEXFjnTeRJyOpodwBgAUItYuLaNQMx==KEXFjnTeRJyOpodwBgAUItYuLaNQVG:sys.exit()
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.Delete_Watched_List(KEXFjnTeRJyOpodwBgAUItYuLaNQMP)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,KEXFjnTeRJyOpodwBgAUItYuLaNQMP):
  try:
   KEXFjnTeRJyOpodwBgAUItYuLaNQkm=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%KEXFjnTeRJyOpodwBgAUItYuLaNQMP))
   fp=KEXFjnTeRJyOpodwBgAUItYuLaNQVz(KEXFjnTeRJyOpodwBgAUItYuLaNQkm,'r',-1,'utf-8')
   KEXFjnTeRJyOpodwBgAUItYuLaNQSG=fp.readlines()
   fp.close()
  except:
   KEXFjnTeRJyOpodwBgAUItYuLaNQSG=[]
  return KEXFjnTeRJyOpodwBgAUItYuLaNQSG
 def Save_Watched_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,KEXFjnTeRJyOpodwBgAUItYuLaNQMP,KEXFjnTeRJyOpodwBgAUItYuLaNQGq):
  try:
   KEXFjnTeRJyOpodwBgAUItYuLaNQkm=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%KEXFjnTeRJyOpodwBgAUItYuLaNQMP))
   KEXFjnTeRJyOpodwBgAUItYuLaNQSM=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.Load_Watched_List(KEXFjnTeRJyOpodwBgAUItYuLaNQMP) 
   fp=KEXFjnTeRJyOpodwBgAUItYuLaNQVz(KEXFjnTeRJyOpodwBgAUItYuLaNQkm,'w',-1,'utf-8')
   KEXFjnTeRJyOpodwBgAUItYuLaNQSh=urllib.parse.urlencode(KEXFjnTeRJyOpodwBgAUItYuLaNQGq)
   KEXFjnTeRJyOpodwBgAUItYuLaNQSh=KEXFjnTeRJyOpodwBgAUItYuLaNQSh+'\n'
   fp.write(KEXFjnTeRJyOpodwBgAUItYuLaNQSh)
   KEXFjnTeRJyOpodwBgAUItYuLaNQSk=0
   for KEXFjnTeRJyOpodwBgAUItYuLaNQSV in KEXFjnTeRJyOpodwBgAUItYuLaNQSM:
    KEXFjnTeRJyOpodwBgAUItYuLaNQSz=KEXFjnTeRJyOpodwBgAUItYuLaNQVi(urllib.parse.parse_qsl(KEXFjnTeRJyOpodwBgAUItYuLaNQSV))
    KEXFjnTeRJyOpodwBgAUItYuLaNQSi=KEXFjnTeRJyOpodwBgAUItYuLaNQGq.get('code')
    KEXFjnTeRJyOpodwBgAUItYuLaNQSs=KEXFjnTeRJyOpodwBgAUItYuLaNQSz.get('code')
    if KEXFjnTeRJyOpodwBgAUItYuLaNQMP=='seasons' and KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_settings_direct_replay()==KEXFjnTeRJyOpodwBgAUItYuLaNQVM:
     KEXFjnTeRJyOpodwBgAUItYuLaNQSi=KEXFjnTeRJyOpodwBgAUItYuLaNQGq.get('videoid')
     KEXFjnTeRJyOpodwBgAUItYuLaNQSs=KEXFjnTeRJyOpodwBgAUItYuLaNQSz.get('videoid')if KEXFjnTeRJyOpodwBgAUItYuLaNQSs!=KEXFjnTeRJyOpodwBgAUItYuLaNQSW else '-'
    if KEXFjnTeRJyOpodwBgAUItYuLaNQSi!=KEXFjnTeRJyOpodwBgAUItYuLaNQSs:
     fp.write(KEXFjnTeRJyOpodwBgAUItYuLaNQSV)
     KEXFjnTeRJyOpodwBgAUItYuLaNQSk+=1
     if KEXFjnTeRJyOpodwBgAUItYuLaNQSk>=50:break
   fp.close()
  except:
   KEXFjnTeRJyOpodwBgAUItYuLaNQSW
 def dp_Watch_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD,args):
  KEXFjnTeRJyOpodwBgAUItYuLaNQMP =args.get('stype')
  KEXFjnTeRJyOpodwBgAUItYuLaNQMG=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.get_settings_direct_replay()
  if KEXFjnTeRJyOpodwBgAUItYuLaNQMP=='-':
   for KEXFjnTeRJyOpodwBgAUItYuLaNQSD in KEXFjnTeRJyOpodwBgAUItYuLaNQGk:
    KEXFjnTeRJyOpodwBgAUItYuLaNQMz=KEXFjnTeRJyOpodwBgAUItYuLaNQSD.get('title')
    KEXFjnTeRJyOpodwBgAUItYuLaNQMD={'mode':KEXFjnTeRJyOpodwBgAUItYuLaNQSD.get('mode'),'stype':KEXFjnTeRJyOpodwBgAUItYuLaNQSD.get('stype')}
    KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel='',img='',infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQSW,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQVM,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
   if KEXFjnTeRJyOpodwBgAUItYuLaNQVh(KEXFjnTeRJyOpodwBgAUItYuLaNQGk)>0:xbmcplugin.endOfDirectory(KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_handle)
  else:
   KEXFjnTeRJyOpodwBgAUItYuLaNQSC=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.Load_Watched_List(KEXFjnTeRJyOpodwBgAUItYuLaNQMP)
   for KEXFjnTeRJyOpodwBgAUItYuLaNQSl in KEXFjnTeRJyOpodwBgAUItYuLaNQSC:
    KEXFjnTeRJyOpodwBgAUItYuLaNQSq=KEXFjnTeRJyOpodwBgAUItYuLaNQVi(urllib.parse.parse_qsl(KEXFjnTeRJyOpodwBgAUItYuLaNQSl))
    KEXFjnTeRJyOpodwBgAUItYuLaNQhD=KEXFjnTeRJyOpodwBgAUItYuLaNQSq.get('code')
    KEXFjnTeRJyOpodwBgAUItYuLaNQMz =KEXFjnTeRJyOpodwBgAUItYuLaNQSq.get('title')
    KEXFjnTeRJyOpodwBgAUItYuLaNQhl =KEXFjnTeRJyOpodwBgAUItYuLaNQSq.get('img')
    KEXFjnTeRJyOpodwBgAUItYuLaNQSH =KEXFjnTeRJyOpodwBgAUItYuLaNQSq.get('videoid')
    KEXFjnTeRJyOpodwBgAUItYuLaNQkb={}
    KEXFjnTeRJyOpodwBgAUItYuLaNQkb['plot']=KEXFjnTeRJyOpodwBgAUItYuLaNQMz
    if KEXFjnTeRJyOpodwBgAUItYuLaNQMP=='movie':
     KEXFjnTeRJyOpodwBgAUItYuLaNQMD={'mode':'MOVIE','page':'1','movie_code':KEXFjnTeRJyOpodwBgAUItYuLaNQhD,'season_code':'-','title':KEXFjnTeRJyOpodwBgAUItYuLaNQMz,'thumbnail':KEXFjnTeRJyOpodwBgAUItYuLaNQhl}
     KEXFjnTeRJyOpodwBgAUItYuLaNQMC=KEXFjnTeRJyOpodwBgAUItYuLaNQVG
    else:
     if KEXFjnTeRJyOpodwBgAUItYuLaNQMG==KEXFjnTeRJyOpodwBgAUItYuLaNQVG or KEXFjnTeRJyOpodwBgAUItYuLaNQSH==KEXFjnTeRJyOpodwBgAUItYuLaNQSW:
      KEXFjnTeRJyOpodwBgAUItYuLaNQMD={'mode':'EPISODE','page':'1','movie_code':KEXFjnTeRJyOpodwBgAUItYuLaNQhD,'season_code':KEXFjnTeRJyOpodwBgAUItYuLaNQhD,'title':KEXFjnTeRJyOpodwBgAUItYuLaNQMz,'thumbnail':KEXFjnTeRJyOpodwBgAUItYuLaNQhl}
      KEXFjnTeRJyOpodwBgAUItYuLaNQMC=KEXFjnTeRJyOpodwBgAUItYuLaNQVM
     else:
      KEXFjnTeRJyOpodwBgAUItYuLaNQMD={'mode':'MOVIE','movie_code':KEXFjnTeRJyOpodwBgAUItYuLaNQSH,'season_code':KEXFjnTeRJyOpodwBgAUItYuLaNQhD,'title':KEXFjnTeRJyOpodwBgAUItYuLaNQMz,'thumbnail':KEXFjnTeRJyOpodwBgAUItYuLaNQhl}
      KEXFjnTeRJyOpodwBgAUItYuLaNQMC=KEXFjnTeRJyOpodwBgAUItYuLaNQVG
    KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel='',img=KEXFjnTeRJyOpodwBgAUItYuLaNQhl,infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQkb,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQMC,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
   KEXFjnTeRJyOpodwBgAUItYuLaNQkb={'plot':'시청목록을 삭제합니다.'}
   KEXFjnTeRJyOpodwBgAUItYuLaNQMz='*** 시청목록 삭제 ***'
   KEXFjnTeRJyOpodwBgAUItYuLaNQMD={'mode':'MYVIEW_REMOVE','stype':KEXFjnTeRJyOpodwBgAUItYuLaNQMP}
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.add_dir(KEXFjnTeRJyOpodwBgAUItYuLaNQMz,sublabel='',img='',infoLabels=KEXFjnTeRJyOpodwBgAUItYuLaNQkb,isFolder=KEXFjnTeRJyOpodwBgAUItYuLaNQVG,params=KEXFjnTeRJyOpodwBgAUItYuLaNQMD)
   xbmcplugin.endOfDirectory(KEXFjnTeRJyOpodwBgAUItYuLaNQGD._addon_handle,cacheToDisc=KEXFjnTeRJyOpodwBgAUItYuLaNQVG)
 def logout(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  KEXFjnTeRJyOpodwBgAUItYuLaNQGc=xbmcgui.Dialog()
  KEXFjnTeRJyOpodwBgAUItYuLaNQMx=KEXFjnTeRJyOpodwBgAUItYuLaNQGc.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if KEXFjnTeRJyOpodwBgAUItYuLaNQMx==KEXFjnTeRJyOpodwBgAUItYuLaNQVG:sys.exit()
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.wininfo_clear()
  if os.path.isfile(KEXFjnTeRJyOpodwBgAUItYuLaNQGs):os.remove(KEXFjnTeRJyOpodwBgAUItYuLaNQGs)
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh=xbmcgui.Window(10000)
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_TOKEN','')
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_GUIT','')
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_GUITV','')
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_USERCD','')
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  KEXFjnTeRJyOpodwBgAUItYuLaNQSc =KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.Get_Now_Datetime()
  KEXFjnTeRJyOpodwBgAUItYuLaNQSx=KEXFjnTeRJyOpodwBgAUItYuLaNQSc+datetime.timedelta(days=KEXFjnTeRJyOpodwBgAUItYuLaNQSm(__addon__.getSetting('cache_ttl')))
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh=xbmcgui.Window(10000)
  KEXFjnTeRJyOpodwBgAUItYuLaNQSb={'watcha_token':KEXFjnTeRJyOpodwBgAUItYuLaNQMh.getProperty('WATCHA_M_TOKEN'),'watcha_guit':KEXFjnTeRJyOpodwBgAUItYuLaNQMh.getProperty('WATCHA_M_GUIT'),'watcha_guitv':KEXFjnTeRJyOpodwBgAUItYuLaNQMh.getProperty('WATCHA_M_GUITV'),'watcha_usercd':KEXFjnTeRJyOpodwBgAUItYuLaNQMh.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':KEXFjnTeRJyOpodwBgAUItYuLaNQSx.strftime('%Y-%m-%d')}
  try: 
   fp=KEXFjnTeRJyOpodwBgAUItYuLaNQVz(KEXFjnTeRJyOpodwBgAUItYuLaNQGs,'w',-1,'utf-8')
   json.dump(KEXFjnTeRJyOpodwBgAUItYuLaNQSb,fp)
   fp.close()
  except KEXFjnTeRJyOpodwBgAUItYuLaNQVs as exception:
   KEXFjnTeRJyOpodwBgAUItYuLaNQVD(exception)
 def cookiefile_check(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  KEXFjnTeRJyOpodwBgAUItYuLaNQSb={}
  try: 
   fp=KEXFjnTeRJyOpodwBgAUItYuLaNQVz(KEXFjnTeRJyOpodwBgAUItYuLaNQGs,'r',-1,'utf-8')
   KEXFjnTeRJyOpodwBgAUItYuLaNQSb= json.load(fp)
   fp.close()
  except KEXFjnTeRJyOpodwBgAUItYuLaNQVs as exception:
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.wininfo_clear()
   return KEXFjnTeRJyOpodwBgAUItYuLaNQVG
  KEXFjnTeRJyOpodwBgAUItYuLaNQMq =__addon__.getSetting('id')
  KEXFjnTeRJyOpodwBgAUItYuLaNQMH =__addon__.getSetting('pw')
  KEXFjnTeRJyOpodwBgAUItYuLaNQSf =__addon__.getSetting('selected_profile')
  KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_id']=base64.standard_b64decode(KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_id']).decode('utf-8')
  KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_pw']=base64.standard_b64decode(KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_pw']).decode('utf-8')
  if KEXFjnTeRJyOpodwBgAUItYuLaNQMq!=KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_id']or KEXFjnTeRJyOpodwBgAUItYuLaNQMH!=KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_pw']or KEXFjnTeRJyOpodwBgAUItYuLaNQSf!=KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_profile']:
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.wininfo_clear()
   return KEXFjnTeRJyOpodwBgAUItYuLaNQVG
  KEXFjnTeRJyOpodwBgAUItYuLaNQMb =KEXFjnTeRJyOpodwBgAUItYuLaNQSm(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  KEXFjnTeRJyOpodwBgAUItYuLaNQSr=KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_limitdate']
  KEXFjnTeRJyOpodwBgAUItYuLaNQMf =KEXFjnTeRJyOpodwBgAUItYuLaNQSm(re.sub('-','',KEXFjnTeRJyOpodwBgAUItYuLaNQSr))
  if KEXFjnTeRJyOpodwBgAUItYuLaNQMf<KEXFjnTeRJyOpodwBgAUItYuLaNQMb:
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.wininfo_clear()
   return KEXFjnTeRJyOpodwBgAUItYuLaNQVG
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh=xbmcgui.Window(10000)
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_TOKEN',KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_token'])
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_GUIT',KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_guit'])
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_GUITV',KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_guitv'])
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_USERCD',KEXFjnTeRJyOpodwBgAUItYuLaNQSb['watcha_usercd'])
  KEXFjnTeRJyOpodwBgAUItYuLaNQMh.setProperty('WATCHA_M_LOGINTIME',KEXFjnTeRJyOpodwBgAUItYuLaNQSr)
  return KEXFjnTeRJyOpodwBgAUItYuLaNQVM
 def watcha_main(KEXFjnTeRJyOpodwBgAUItYuLaNQGD):
  KEXFjnTeRJyOpodwBgAUItYuLaNQSP=KEXFjnTeRJyOpodwBgAUItYuLaNQGD.main_params.get('mode',KEXFjnTeRJyOpodwBgAUItYuLaNQSW)
  if KEXFjnTeRJyOpodwBgAUItYuLaNQSP=='LOGOUT':
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.logout()
   return
  KEXFjnTeRJyOpodwBgAUItYuLaNQGD.login_main()
  if KEXFjnTeRJyOpodwBgAUItYuLaNQSP is KEXFjnTeRJyOpodwBgAUItYuLaNQSW:
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.dp_Main_List()
  elif KEXFjnTeRJyOpodwBgAUItYuLaNQSP=='SUB_GROUP':
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.dp_SubGroup_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.main_params)
  elif KEXFjnTeRJyOpodwBgAUItYuLaNQSP=='CATEGORY_LIST':
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.dp_Category_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.main_params)
  elif KEXFjnTeRJyOpodwBgAUItYuLaNQSP=='EPISODE':
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.dp_Episode_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.main_params)
  elif KEXFjnTeRJyOpodwBgAUItYuLaNQSP=='ORDER_BY':
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.dp_setEpOrderby(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.main_params)
  elif KEXFjnTeRJyOpodwBgAUItYuLaNQSP=='SEARCH':
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.dp_Search_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.main_params)
  elif KEXFjnTeRJyOpodwBgAUItYuLaNQSP=='MOVIE':
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.play_VIDEO(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.main_params)
  elif KEXFjnTeRJyOpodwBgAUItYuLaNQSP=='WATCH':
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.dp_Watch_List(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.main_params)
  elif KEXFjnTeRJyOpodwBgAUItYuLaNQSP=='MYVIEW_REMOVE':
   KEXFjnTeRJyOpodwBgAUItYuLaNQGD.dp_WatchList_Delete(KEXFjnTeRJyOpodwBgAUItYuLaNQGD.main_params)
  else:
   KEXFjnTeRJyOpodwBgAUItYuLaNQSW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
