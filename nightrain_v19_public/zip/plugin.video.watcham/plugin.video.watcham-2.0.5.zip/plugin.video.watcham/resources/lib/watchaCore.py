__author__="NightRain"
axXdzuOgtifyvKhVMwJUNHeFEDkLjl=object
axXdzuOgtifyvKhVMwJUNHeFEDkLjQ=None
axXdzuOgtifyvKhVMwJUNHeFEDkLjc=False
axXdzuOgtifyvKhVMwJUNHeFEDkLjn=True
axXdzuOgtifyvKhVMwJUNHeFEDkLjG=Exception
axXdzuOgtifyvKhVMwJUNHeFEDkLjA=print
axXdzuOgtifyvKhVMwJUNHeFEDkLjB=str
axXdzuOgtifyvKhVMwJUNHeFEDkLjm=len
axXdzuOgtifyvKhVMwJUNHeFEDkLjR=int
axXdzuOgtifyvKhVMwJUNHeFEDkLjp=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import base64
import requests
import datetime
axXdzuOgtifyvKhVMwJUNHeFEDkLlc='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
class axXdzuOgtifyvKhVMwJUNHeFEDkLlQ(axXdzuOgtifyvKhVMwJUNHeFEDkLjl):
 def __init__(axXdzuOgtifyvKhVMwJUNHeFEDkLlj):
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_TOKEN ='' 
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUIT =''
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUITV =''
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_USERCD=''
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.API_DOMAIN ='https://play.watcha.net'
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.EPISODE_LIMIT=20
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.SEARCH_LIMIT =30
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.DEFAULT_HEADER={'user-agent':axXdzuOgtifyvKhVMwJUNHeFEDkLlc,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,jobtype,axXdzuOgtifyvKhVMwJUNHeFEDkLlW,payload=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,params=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,cookies=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,redirects=axXdzuOgtifyvKhVMwJUNHeFEDkLjc):
  axXdzuOgtifyvKhVMwJUNHeFEDkLln=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.DEFAULT_HEADER
  if headers:axXdzuOgtifyvKhVMwJUNHeFEDkLln.update(headers)
  if jobtype=='Get':
   axXdzuOgtifyvKhVMwJUNHeFEDkLlG=requests.get(axXdzuOgtifyvKhVMwJUNHeFEDkLlW,params=params,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLln,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   axXdzuOgtifyvKhVMwJUNHeFEDkLlG=requests.put(axXdzuOgtifyvKhVMwJUNHeFEDkLlW,data=payload,params=params,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLln,cookies=cookies,allow_redirects=redirects)
  else:
   axXdzuOgtifyvKhVMwJUNHeFEDkLlG=requests.post(axXdzuOgtifyvKhVMwJUNHeFEDkLlW,data=payload,params=params,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLln,cookies=cookies,allow_redirects=redirects)
  return axXdzuOgtifyvKhVMwJUNHeFEDkLlG
 def SaveCredential(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,axXdzuOgtifyvKhVMwJUNHeFEDkLlA):
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_TOKEN =axXdzuOgtifyvKhVMwJUNHeFEDkLlA.get('watcha_token')
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUIT =axXdzuOgtifyvKhVMwJUNHeFEDkLlA.get('watcha_guit')
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUITV =axXdzuOgtifyvKhVMwJUNHeFEDkLlA.get('watcha_guitv')
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_USERCD =axXdzuOgtifyvKhVMwJUNHeFEDkLlA.get('watcha_usercd')
 def SaveCredential_usercd(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,axXdzuOgtifyvKhVMwJUNHeFEDkLlB):
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_USERCD=axXdzuOgtifyvKhVMwJUNHeFEDkLlB
 def SaveCredential_guitv(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,axXdzuOgtifyvKhVMwJUNHeFEDkLlm,axXdzuOgtifyvKhVMwJUNHeFEDkLlR):
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUITV=axXdzuOgtifyvKhVMwJUNHeFEDkLlm
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_TOKEN=axXdzuOgtifyvKhVMwJUNHeFEDkLlR 
 def ClearCredential(axXdzuOgtifyvKhVMwJUNHeFEDkLlj):
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_TOKEN ='' 
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUIT =''
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUITV =''
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_USERCD=''
 def LoadCredential(axXdzuOgtifyvKhVMwJUNHeFEDkLlj):
  axXdzuOgtifyvKhVMwJUNHeFEDkLlA={'watcha_token':axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_TOKEN,'watcha_guit':axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUIT,'watcha_guitv':axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUITV,'watcha_usercd':axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_USERCD}
  return axXdzuOgtifyvKhVMwJUNHeFEDkLlA
 def makeDefaultCookies(axXdzuOgtifyvKhVMwJUNHeFEDkLlj):
  axXdzuOgtifyvKhVMwJUNHeFEDkLlp={'_s_guit':axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUIT,'_guinness-premium_session':axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_TOKEN}
  if axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUITV:
   axXdzuOgtifyvKhVMwJUNHeFEDkLlp['_s_guitv']=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_GUITV
  return axXdzuOgtifyvKhVMwJUNHeFEDkLlp
 def makeurl(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,domain,path,query1=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,query2=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ):
  axXdzuOgtifyvKhVMwJUNHeFEDkLlW=domain+path
  if query1:
   axXdzuOgtifyvKhVMwJUNHeFEDkLlW+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   axXdzuOgtifyvKhVMwJUNHeFEDkLlW+='&%s'%urllib.parse.urlencode(query2)
  return axXdzuOgtifyvKhVMwJUNHeFEDkLlW
 def GetCredential(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,user_id,user_pw,user_pf):
  axXdzuOgtifyvKhVMwJUNHeFEDkLlP=axXdzuOgtifyvKhVMwJUNHeFEDkLjc
  axXdzuOgtifyvKhVMwJUNHeFEDkLlb=axXdzuOgtifyvKhVMwJUNHeFEDkLlo='-'
  try:
   axXdzuOgtifyvKhVMwJUNHeFEDkLlq=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.API_DOMAIN+'/api/session'
   axXdzuOgtifyvKhVMwJUNHeFEDkLlr={'email':user_id,'password':user_pw}
   axXdzuOgtifyvKhVMwJUNHeFEDkLlI={'accept':'application/vnd.frograms+json;version=4'}
   axXdzuOgtifyvKhVMwJUNHeFEDkLlT=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.callRequestCookies('Post',axXdzuOgtifyvKhVMwJUNHeFEDkLlq,payload=axXdzuOgtifyvKhVMwJUNHeFEDkLlr,params=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLlI,cookies=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ)
   for axXdzuOgtifyvKhVMwJUNHeFEDkLlY in axXdzuOgtifyvKhVMwJUNHeFEDkLlT.cookies:
    if axXdzuOgtifyvKhVMwJUNHeFEDkLlY.name=='_guinness-premium_session':
     axXdzuOgtifyvKhVMwJUNHeFEDkLlo=axXdzuOgtifyvKhVMwJUNHeFEDkLlY.value
    elif axXdzuOgtifyvKhVMwJUNHeFEDkLlY.name=='_s_guit':
     axXdzuOgtifyvKhVMwJUNHeFEDkLlb=axXdzuOgtifyvKhVMwJUNHeFEDkLlY.value
   if axXdzuOgtifyvKhVMwJUNHeFEDkLlo:axXdzuOgtifyvKhVMwJUNHeFEDkLlP=axXdzuOgtifyvKhVMwJUNHeFEDkLjn
  except axXdzuOgtifyvKhVMwJUNHeFEDkLjG as exception:
   axXdzuOgtifyvKhVMwJUNHeFEDkLjA(exception)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlb=axXdzuOgtifyvKhVMwJUNHeFEDkLlo='' 
  axXdzuOgtifyvKhVMwJUNHeFEDkLlA={'watcha_guit':axXdzuOgtifyvKhVMwJUNHeFEDkLlb,'watcha_token':axXdzuOgtifyvKhVMwJUNHeFEDkLlo,'watcha_guitv':'','watcha_usercd':''}
  axXdzuOgtifyvKhVMwJUNHeFEDkLlj.SaveCredential(axXdzuOgtifyvKhVMwJUNHeFEDkLlA)
  try:
   axXdzuOgtifyvKhVMwJUNHeFEDkLlS=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.GetProfilesList()
   axXdzuOgtifyvKhVMwJUNHeFEDkLQl =axXdzuOgtifyvKhVMwJUNHeFEDkLlS[user_pf]
   axXdzuOgtifyvKhVMwJUNHeFEDkLlj.SaveCredential_usercd(axXdzuOgtifyvKhVMwJUNHeFEDkLQl)
  except axXdzuOgtifyvKhVMwJUNHeFEDkLjG as exception:
   axXdzuOgtifyvKhVMwJUNHeFEDkLjA(exception)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlj.ClearCredential()
   return axXdzuOgtifyvKhVMwJUNHeFEDkLjc
  if user_pf!=0:
   axXdzuOgtifyvKhVMwJUNHeFEDkLlm,axXdzuOgtifyvKhVMwJUNHeFEDkLlR=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.GetProfilesConvert(axXdzuOgtifyvKhVMwJUNHeFEDkLQl)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlj.SaveCredential_guitv(axXdzuOgtifyvKhVMwJUNHeFEDkLlm,axXdzuOgtifyvKhVMwJUNHeFEDkLlR)
  return axXdzuOgtifyvKhVMwJUNHeFEDkLlP
 def GetSubGroupList(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,stype):
  axXdzuOgtifyvKhVMwJUNHeFEDkLQc=[]
  try:
   axXdzuOgtifyvKhVMwJUNHeFEDkLQj ='/api/categories.json'
   axXdzuOgtifyvKhVMwJUNHeFEDkLlW=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeurl(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.API_DOMAIN,axXdzuOgtifyvKhVMwJUNHeFEDkLQj)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlY=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeDefaultCookies()
   axXdzuOgtifyvKhVMwJUNHeFEDkLlT=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.callRequestCookies('Get',axXdzuOgtifyvKhVMwJUNHeFEDkLlW,payload=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,params=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,cookies=axXdzuOgtifyvKhVMwJUNHeFEDkLlY)
   axXdzuOgtifyvKhVMwJUNHeFEDkLQn=json.loads(axXdzuOgtifyvKhVMwJUNHeFEDkLlT.text)
   if not('genres' in axXdzuOgtifyvKhVMwJUNHeFEDkLQn):return axXdzuOgtifyvKhVMwJUNHeFEDkLQc
   if stype=='genres':
    axXdzuOgtifyvKhVMwJUNHeFEDkLQG=axXdzuOgtifyvKhVMwJUNHeFEDkLQn['genres']
   else:
    axXdzuOgtifyvKhVMwJUNHeFEDkLQG=axXdzuOgtifyvKhVMwJUNHeFEDkLQn['tags']
   for axXdzuOgtifyvKhVMwJUNHeFEDkLQA in axXdzuOgtifyvKhVMwJUNHeFEDkLQG:
    axXdzuOgtifyvKhVMwJUNHeFEDkLQB=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['name']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQm =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['api_path']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQR =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['entity']['id']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQp={'group_name':axXdzuOgtifyvKhVMwJUNHeFEDkLQB,'api_path':axXdzuOgtifyvKhVMwJUNHeFEDkLQm,'tag_id':axXdzuOgtifyvKhVMwJUNHeFEDkLjB(axXdzuOgtifyvKhVMwJUNHeFEDkLQR)}
    axXdzuOgtifyvKhVMwJUNHeFEDkLQc.append(axXdzuOgtifyvKhVMwJUNHeFEDkLQp)
  except axXdzuOgtifyvKhVMwJUNHeFEDkLjG as exception:
   axXdzuOgtifyvKhVMwJUNHeFEDkLjA(exception)
  return axXdzuOgtifyvKhVMwJUNHeFEDkLQc
 def GetCategoryList(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,stype,axXdzuOgtifyvKhVMwJUNHeFEDkLQR,axXdzuOgtifyvKhVMwJUNHeFEDkLQm,page_int,in_sort):
  axXdzuOgtifyvKhVMwJUNHeFEDkLQc=[]
  axXdzuOgtifyvKhVMwJUNHeFEDkLQW=axXdzuOgtifyvKhVMwJUNHeFEDkLjc
  axXdzuOgtifyvKhVMwJUNHeFEDkLQs={}
  try:
   if 'categories' in axXdzuOgtifyvKhVMwJUNHeFEDkLQm:
    axXdzuOgtifyvKhVMwJUNHeFEDkLQj ='/api/categories/contents.json'
    if stype=='genres':
     axXdzuOgtifyvKhVMwJUNHeFEDkLQs['genre']=axXdzuOgtifyvKhVMwJUNHeFEDkLQR
    else:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQs['tag'] =axXdzuOgtifyvKhVMwJUNHeFEDkLQR
    axXdzuOgtifyvKhVMwJUNHeFEDkLQs['order']=in_sort 
    if page_int>1:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQs['page']=axXdzuOgtifyvKhVMwJUNHeFEDkLjB(page_int-1)
   else: 
    axXdzuOgtifyvKhVMwJUNHeFEDkLQj ='/api/'+axXdzuOgtifyvKhVMwJUNHeFEDkLQm+'.json'
    if page_int>1:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQs['page']=axXdzuOgtifyvKhVMwJUNHeFEDkLjB(page_int)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlW=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeurl(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.API_DOMAIN,axXdzuOgtifyvKhVMwJUNHeFEDkLQj)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlY=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeDefaultCookies()
   axXdzuOgtifyvKhVMwJUNHeFEDkLlT=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.callRequestCookies('Get',axXdzuOgtifyvKhVMwJUNHeFEDkLlW,payload=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,params=axXdzuOgtifyvKhVMwJUNHeFEDkLQs,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,cookies=axXdzuOgtifyvKhVMwJUNHeFEDkLlY)
   axXdzuOgtifyvKhVMwJUNHeFEDkLQn=json.loads(axXdzuOgtifyvKhVMwJUNHeFEDkLlT.text)
   if not('contents' in axXdzuOgtifyvKhVMwJUNHeFEDkLQn):return axXdzuOgtifyvKhVMwJUNHeFEDkLQc,axXdzuOgtifyvKhVMwJUNHeFEDkLQW
   axXdzuOgtifyvKhVMwJUNHeFEDkLQG=axXdzuOgtifyvKhVMwJUNHeFEDkLQn['contents']
   axXdzuOgtifyvKhVMwJUNHeFEDkLQW=axXdzuOgtifyvKhVMwJUNHeFEDkLQn['meta']['has_next']
   for axXdzuOgtifyvKhVMwJUNHeFEDkLQA in axXdzuOgtifyvKhVMwJUNHeFEDkLQG:
    axXdzuOgtifyvKhVMwJUNHeFEDkLQC =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['code']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQP=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['content_type']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQb =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['title']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQq =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['story']
    if axXdzuOgtifyvKhVMwJUNHeFEDkLQA['thumbnail']!=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQr =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['thumbnail']['medium']
    else:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQr =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['stillcut']['medium']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQI =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['year']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQT =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['film_rating_code']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQY=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['film_rating_short']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo={}
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo['mpaa']=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['film_rating_long']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo['year']=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['year']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo['title']=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['title']
    if axXdzuOgtifyvKhVMwJUNHeFEDkLQP=='movies':
     axXdzuOgtifyvKhVMwJUNHeFEDkLQo['mediatype']='movie' 
     axXdzuOgtifyvKhVMwJUNHeFEDkLQo['duration']=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['duration']
    else:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQo['mediatype']='episode' 
    axXdzuOgtifyvKhVMwJUNHeFEDkLQp={'code':axXdzuOgtifyvKhVMwJUNHeFEDkLQC,'content_type':axXdzuOgtifyvKhVMwJUNHeFEDkLQP,'title':axXdzuOgtifyvKhVMwJUNHeFEDkLQb,'story':axXdzuOgtifyvKhVMwJUNHeFEDkLQq,'thumbnail':axXdzuOgtifyvKhVMwJUNHeFEDkLQr,'year':axXdzuOgtifyvKhVMwJUNHeFEDkLQI,'film_rating_code':axXdzuOgtifyvKhVMwJUNHeFEDkLQT,'film_rating_short':axXdzuOgtifyvKhVMwJUNHeFEDkLQY,'info':axXdzuOgtifyvKhVMwJUNHeFEDkLQo}
    axXdzuOgtifyvKhVMwJUNHeFEDkLQc.append(axXdzuOgtifyvKhVMwJUNHeFEDkLQp)
  except axXdzuOgtifyvKhVMwJUNHeFEDkLjG as exception:
   axXdzuOgtifyvKhVMwJUNHeFEDkLjA(exception)
  return axXdzuOgtifyvKhVMwJUNHeFEDkLQc,axXdzuOgtifyvKhVMwJUNHeFEDkLQW
 def GetCategoryList_morepage(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,stype,axXdzuOgtifyvKhVMwJUNHeFEDkLQR,axXdzuOgtifyvKhVMwJUNHeFEDkLQm,page_int,in_sort):
  axXdzuOgtifyvKhVMwJUNHeFEDkLQW=axXdzuOgtifyvKhVMwJUNHeFEDkLjc
  if not('categories' in axXdzuOgtifyvKhVMwJUNHeFEDkLQm):return axXdzuOgtifyvKhVMwJUNHeFEDkLjn
  try:
   axXdzuOgtifyvKhVMwJUNHeFEDkLQj ='/api/categories/contents.json'
   axXdzuOgtifyvKhVMwJUNHeFEDkLQs={}
   if stype=='genres':
    axXdzuOgtifyvKhVMwJUNHeFEDkLQs['genre']=axXdzuOgtifyvKhVMwJUNHeFEDkLQR
   else:
    axXdzuOgtifyvKhVMwJUNHeFEDkLQs['tag'] =axXdzuOgtifyvKhVMwJUNHeFEDkLQR
   axXdzuOgtifyvKhVMwJUNHeFEDkLQs['order']=in_sort 
   if page_int>1:
    axXdzuOgtifyvKhVMwJUNHeFEDkLQs['page']=axXdzuOgtifyvKhVMwJUNHeFEDkLjB(page_int-1)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlW=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeurl(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.API_DOMAIN,axXdzuOgtifyvKhVMwJUNHeFEDkLQj)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlY=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeDefaultCookies()
   axXdzuOgtifyvKhVMwJUNHeFEDkLlT=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.callRequestCookies('Get',axXdzuOgtifyvKhVMwJUNHeFEDkLlW,payload=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,params=axXdzuOgtifyvKhVMwJUNHeFEDkLQs,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,cookies=axXdzuOgtifyvKhVMwJUNHeFEDkLlY)
   axXdzuOgtifyvKhVMwJUNHeFEDkLQn=json.loads(axXdzuOgtifyvKhVMwJUNHeFEDkLlT.text)
   axXdzuOgtifyvKhVMwJUNHeFEDkLQW=axXdzuOgtifyvKhVMwJUNHeFEDkLQn['meta']['has_next']
  except axXdzuOgtifyvKhVMwJUNHeFEDkLjG as exception:
   axXdzuOgtifyvKhVMwJUNHeFEDkLjA(exception)
  return axXdzuOgtifyvKhVMwJUNHeFEDkLQW
 def GetEpisodoList(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,program_code,page_int,orderby='asc'):
  axXdzuOgtifyvKhVMwJUNHeFEDkLQc=[]
  axXdzuOgtifyvKhVMwJUNHeFEDkLQW=axXdzuOgtifyvKhVMwJUNHeFEDkLjc
  axXdzuOgtifyvKhVMwJUNHeFEDkLQS=''
  try:
   axXdzuOgtifyvKhVMwJUNHeFEDkLQj ='/api/contents/'+program_code+'/tv_episodes.json'
   axXdzuOgtifyvKhVMwJUNHeFEDkLQs={'all':'true'}
   axXdzuOgtifyvKhVMwJUNHeFEDkLlW=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeurl(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.API_DOMAIN,axXdzuOgtifyvKhVMwJUNHeFEDkLQj)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlY=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeDefaultCookies()
   axXdzuOgtifyvKhVMwJUNHeFEDkLlT=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.callRequestCookies('Get',axXdzuOgtifyvKhVMwJUNHeFEDkLlW,payload=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,params=axXdzuOgtifyvKhVMwJUNHeFEDkLQs,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,cookies=axXdzuOgtifyvKhVMwJUNHeFEDkLlY)
   axXdzuOgtifyvKhVMwJUNHeFEDkLQn=json.loads(axXdzuOgtifyvKhVMwJUNHeFEDkLlT.text)
   if not('tv_episode_codes' in axXdzuOgtifyvKhVMwJUNHeFEDkLQn):return axXdzuOgtifyvKhVMwJUNHeFEDkLQc,axXdzuOgtifyvKhVMwJUNHeFEDkLQW
   axXdzuOgtifyvKhVMwJUNHeFEDkLQG=axXdzuOgtifyvKhVMwJUNHeFEDkLQn['tv_episode_codes']
   axXdzuOgtifyvKhVMwJUNHeFEDkLcl=axXdzuOgtifyvKhVMwJUNHeFEDkLjm(axXdzuOgtifyvKhVMwJUNHeFEDkLQG)
   axXdzuOgtifyvKhVMwJUNHeFEDkLcQ =axXdzuOgtifyvKhVMwJUNHeFEDkLjR(axXdzuOgtifyvKhVMwJUNHeFEDkLcl//(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    axXdzuOgtifyvKhVMwJUNHeFEDkLcj =(axXdzuOgtifyvKhVMwJUNHeFEDkLcl-1)-((page_int-1)*axXdzuOgtifyvKhVMwJUNHeFEDkLlj.EPISODE_LIMIT)
   else:
    axXdzuOgtifyvKhVMwJUNHeFEDkLcj =(page_int-1)*axXdzuOgtifyvKhVMwJUNHeFEDkLlj.EPISODE_LIMIT
   for i in axXdzuOgtifyvKhVMwJUNHeFEDkLjp(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.EPISODE_LIMIT):
    if orderby=='desc':
     axXdzuOgtifyvKhVMwJUNHeFEDkLcn=axXdzuOgtifyvKhVMwJUNHeFEDkLcj-i
     if axXdzuOgtifyvKhVMwJUNHeFEDkLcn<0:break
    else:
     axXdzuOgtifyvKhVMwJUNHeFEDkLcn=axXdzuOgtifyvKhVMwJUNHeFEDkLcj+i
     if axXdzuOgtifyvKhVMwJUNHeFEDkLcn>=axXdzuOgtifyvKhVMwJUNHeFEDkLcl:break
    if axXdzuOgtifyvKhVMwJUNHeFEDkLQS!='':axXdzuOgtifyvKhVMwJUNHeFEDkLQS+=','
    axXdzuOgtifyvKhVMwJUNHeFEDkLQS+=axXdzuOgtifyvKhVMwJUNHeFEDkLQG[axXdzuOgtifyvKhVMwJUNHeFEDkLcn]
   if axXdzuOgtifyvKhVMwJUNHeFEDkLcQ>page_int:axXdzuOgtifyvKhVMwJUNHeFEDkLQW=axXdzuOgtifyvKhVMwJUNHeFEDkLjn
  except axXdzuOgtifyvKhVMwJUNHeFEDkLjG as exception:
   axXdzuOgtifyvKhVMwJUNHeFEDkLjA(exception)
  try:
   axXdzuOgtifyvKhVMwJUNHeFEDkLQs={'codes':axXdzuOgtifyvKhVMwJUNHeFEDkLQS}
   axXdzuOgtifyvKhVMwJUNHeFEDkLlW=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeurl(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.API_DOMAIN,axXdzuOgtifyvKhVMwJUNHeFEDkLQj)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlY=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeDefaultCookies()
   axXdzuOgtifyvKhVMwJUNHeFEDkLlT=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.callRequestCookies('Get',axXdzuOgtifyvKhVMwJUNHeFEDkLlW,payload=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,params=axXdzuOgtifyvKhVMwJUNHeFEDkLQs,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,cookies=axXdzuOgtifyvKhVMwJUNHeFEDkLlY)
   axXdzuOgtifyvKhVMwJUNHeFEDkLQn=json.loads(axXdzuOgtifyvKhVMwJUNHeFEDkLlT.text)
   if not('tv_episodes' in axXdzuOgtifyvKhVMwJUNHeFEDkLQn):return axXdzuOgtifyvKhVMwJUNHeFEDkLQc
   axXdzuOgtifyvKhVMwJUNHeFEDkLQG=axXdzuOgtifyvKhVMwJUNHeFEDkLQn['tv_episodes']
   for axXdzuOgtifyvKhVMwJUNHeFEDkLQA in axXdzuOgtifyvKhVMwJUNHeFEDkLQG:
    axXdzuOgtifyvKhVMwJUNHeFEDkLQC =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['code']
    if axXdzuOgtifyvKhVMwJUNHeFEDkLQA['title']:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQb =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['title']
    else:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQb =''
    axXdzuOgtifyvKhVMwJUNHeFEDkLQr =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['stillcut']['medium']
    axXdzuOgtifyvKhVMwJUNHeFEDkLcG =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['display_number']
    axXdzuOgtifyvKhVMwJUNHeFEDkLcA=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['tv_season_title']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo={}
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo['mediatype'] ='episode'
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo['tvshowtitle']=axXdzuOgtifyvKhVMwJUNHeFEDkLQb if axXdzuOgtifyvKhVMwJUNHeFEDkLQb else axXdzuOgtifyvKhVMwJUNHeFEDkLcA
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo['title'] ='%s %s'%(axXdzuOgtifyvKhVMwJUNHeFEDkLcA,axXdzuOgtifyvKhVMwJUNHeFEDkLcG)if axXdzuOgtifyvKhVMwJUNHeFEDkLQb else axXdzuOgtifyvKhVMwJUNHeFEDkLcG
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo['duration'] =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['duration']
    try:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQo['episode']=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['episode_number']
    except:
     axXdzuOgtifyvKhVMwJUNHeFEDkLjQ
    axXdzuOgtifyvKhVMwJUNHeFEDkLQp={'code':axXdzuOgtifyvKhVMwJUNHeFEDkLQC,'title':axXdzuOgtifyvKhVMwJUNHeFEDkLQb,'thumbnail':axXdzuOgtifyvKhVMwJUNHeFEDkLQr,'display_num':axXdzuOgtifyvKhVMwJUNHeFEDkLcG,'season_title':axXdzuOgtifyvKhVMwJUNHeFEDkLcA,'info':axXdzuOgtifyvKhVMwJUNHeFEDkLQo}
    axXdzuOgtifyvKhVMwJUNHeFEDkLQc.append(axXdzuOgtifyvKhVMwJUNHeFEDkLQp)
  except axXdzuOgtifyvKhVMwJUNHeFEDkLjG as exception:
   axXdzuOgtifyvKhVMwJUNHeFEDkLjA(exception)
  return axXdzuOgtifyvKhVMwJUNHeFEDkLQc,axXdzuOgtifyvKhVMwJUNHeFEDkLQW
 def GetSearchList(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,search_key,page_int):
  axXdzuOgtifyvKhVMwJUNHeFEDkLcB=[]
  axXdzuOgtifyvKhVMwJUNHeFEDkLQW=axXdzuOgtifyvKhVMwJUNHeFEDkLjc
  try:
   axXdzuOgtifyvKhVMwJUNHeFEDkLQj ='/api/search.json'
   axXdzuOgtifyvKhVMwJUNHeFEDkLQs={'query':search_key,'page':axXdzuOgtifyvKhVMwJUNHeFEDkLjB(page_int),'per':axXdzuOgtifyvKhVMwJUNHeFEDkLjB(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.SEARCH_LIMIT),'exclude':'limited'}
   axXdzuOgtifyvKhVMwJUNHeFEDkLlW=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeurl(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.API_DOMAIN,axXdzuOgtifyvKhVMwJUNHeFEDkLQj)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlY=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeDefaultCookies()
   axXdzuOgtifyvKhVMwJUNHeFEDkLlT=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.callRequestCookies('Get',axXdzuOgtifyvKhVMwJUNHeFEDkLlW,payload=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,params=axXdzuOgtifyvKhVMwJUNHeFEDkLQs,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,cookies=axXdzuOgtifyvKhVMwJUNHeFEDkLlY)
   axXdzuOgtifyvKhVMwJUNHeFEDkLQn=json.loads(axXdzuOgtifyvKhVMwJUNHeFEDkLlT.text)
   if not('results' in axXdzuOgtifyvKhVMwJUNHeFEDkLQn):return axXdzuOgtifyvKhVMwJUNHeFEDkLcB,axXdzuOgtifyvKhVMwJUNHeFEDkLQW
   axXdzuOgtifyvKhVMwJUNHeFEDkLQG=axXdzuOgtifyvKhVMwJUNHeFEDkLQn['results']
   axXdzuOgtifyvKhVMwJUNHeFEDkLQW=axXdzuOgtifyvKhVMwJUNHeFEDkLQn['meta']['has_next']
   for axXdzuOgtifyvKhVMwJUNHeFEDkLQA in axXdzuOgtifyvKhVMwJUNHeFEDkLQG:
    axXdzuOgtifyvKhVMwJUNHeFEDkLQC =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['code']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQP=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['content_type']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQb =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['title']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQq =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['story']
    if axXdzuOgtifyvKhVMwJUNHeFEDkLQA['thumbnail']!=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQr =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['thumbnail']['medium']
    else:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQr =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['stillcut']['medium']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQI =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['year']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQT =axXdzuOgtifyvKhVMwJUNHeFEDkLQA['film_rating_code']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQY=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['film_rating_short']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo={}
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo['mpaa']=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['film_rating_long']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo['year']=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['year']
    axXdzuOgtifyvKhVMwJUNHeFEDkLQo['title']=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['title']
    if axXdzuOgtifyvKhVMwJUNHeFEDkLQP=='movies':
     axXdzuOgtifyvKhVMwJUNHeFEDkLQo['mediatype']='movie' 
     axXdzuOgtifyvKhVMwJUNHeFEDkLQo['duration']=axXdzuOgtifyvKhVMwJUNHeFEDkLQA['duration']
    else:
     axXdzuOgtifyvKhVMwJUNHeFEDkLQo['mediatype']='episode' 
    axXdzuOgtifyvKhVMwJUNHeFEDkLQp={'code':axXdzuOgtifyvKhVMwJUNHeFEDkLQC,'content_type':axXdzuOgtifyvKhVMwJUNHeFEDkLQP,'title':axXdzuOgtifyvKhVMwJUNHeFEDkLQb,'story':axXdzuOgtifyvKhVMwJUNHeFEDkLQq,'thumbnail':axXdzuOgtifyvKhVMwJUNHeFEDkLQr,'year':axXdzuOgtifyvKhVMwJUNHeFEDkLQI,'film_rating_code':axXdzuOgtifyvKhVMwJUNHeFEDkLQT,'film_rating_short':axXdzuOgtifyvKhVMwJUNHeFEDkLQY,'info':axXdzuOgtifyvKhVMwJUNHeFEDkLQo}
    axXdzuOgtifyvKhVMwJUNHeFEDkLcB.append(axXdzuOgtifyvKhVMwJUNHeFEDkLQp)
  except axXdzuOgtifyvKhVMwJUNHeFEDkLjG as exception:
   axXdzuOgtifyvKhVMwJUNHeFEDkLjA(exception)
  return axXdzuOgtifyvKhVMwJUNHeFEDkLcB,axXdzuOgtifyvKhVMwJUNHeFEDkLQW
 def GetProfilesList(axXdzuOgtifyvKhVMwJUNHeFEDkLlj):
  axXdzuOgtifyvKhVMwJUNHeFEDkLlS=[]
  try:
   axXdzuOgtifyvKhVMwJUNHeFEDkLQj ='/manage_profiles'
   axXdzuOgtifyvKhVMwJUNHeFEDkLlW=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeurl(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.API_DOMAIN,axXdzuOgtifyvKhVMwJUNHeFEDkLQj)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlY=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeDefaultCookies()
   axXdzuOgtifyvKhVMwJUNHeFEDkLlT=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.callRequestCookies('Get',axXdzuOgtifyvKhVMwJUNHeFEDkLlW,payload=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,params=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,cookies=axXdzuOgtifyvKhVMwJUNHeFEDkLlY,redirects=axXdzuOgtifyvKhVMwJUNHeFEDkLjn)
   axXdzuOgtifyvKhVMwJUNHeFEDkLcm=axXdzuOgtifyvKhVMwJUNHeFEDkLlT.text
   axXdzuOgtifyvKhVMwJUNHeFEDkLcR =re.findall('/api/users/me.{5000}',axXdzuOgtifyvKhVMwJUNHeFEDkLcm)[0]
   axXdzuOgtifyvKhVMwJUNHeFEDkLcR =axXdzuOgtifyvKhVMwJUNHeFEDkLcR.replace('&quot;','')
   axXdzuOgtifyvKhVMwJUNHeFEDkLlS=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',axXdzuOgtifyvKhVMwJUNHeFEDkLcR)
   for i in axXdzuOgtifyvKhVMwJUNHeFEDkLjp(axXdzuOgtifyvKhVMwJUNHeFEDkLjm(axXdzuOgtifyvKhVMwJUNHeFEDkLlS)):
    axXdzuOgtifyvKhVMwJUNHeFEDkLcp=axXdzuOgtifyvKhVMwJUNHeFEDkLlS[i]
    axXdzuOgtifyvKhVMwJUNHeFEDkLcp =axXdzuOgtifyvKhVMwJUNHeFEDkLcp.split(':')[1]
    axXdzuOgtifyvKhVMwJUNHeFEDkLlS[i]=axXdzuOgtifyvKhVMwJUNHeFEDkLcp.split(',')[0]
  except axXdzuOgtifyvKhVMwJUNHeFEDkLjG as exception:
   axXdzuOgtifyvKhVMwJUNHeFEDkLjA(exception)
  return axXdzuOgtifyvKhVMwJUNHeFEDkLlS
 def GetProfilesConvert(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,axXdzuOgtifyvKhVMwJUNHeFEDkLlB):
  axXdzuOgtifyvKhVMwJUNHeFEDkLcW=''
  axXdzuOgtifyvKhVMwJUNHeFEDkLcs=''
  try:
   axXdzuOgtifyvKhVMwJUNHeFEDkLQj ='/api/users/'+axXdzuOgtifyvKhVMwJUNHeFEDkLlB+'/convert'
   axXdzuOgtifyvKhVMwJUNHeFEDkLlW=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeurl(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.API_DOMAIN,axXdzuOgtifyvKhVMwJUNHeFEDkLQj)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlY=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeDefaultCookies()
   axXdzuOgtifyvKhVMwJUNHeFEDkLlT=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.callRequestCookies('Put',axXdzuOgtifyvKhVMwJUNHeFEDkLlW,payload=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,params=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,cookies=axXdzuOgtifyvKhVMwJUNHeFEDkLlY)
   for axXdzuOgtifyvKhVMwJUNHeFEDkLlY in axXdzuOgtifyvKhVMwJUNHeFEDkLlT.cookies:
    if axXdzuOgtifyvKhVMwJUNHeFEDkLlY.name=='_s_guitv':
     axXdzuOgtifyvKhVMwJUNHeFEDkLcC=axXdzuOgtifyvKhVMwJUNHeFEDkLlY.value
    elif axXdzuOgtifyvKhVMwJUNHeFEDkLlY.name=='_guinness-premium_session':
     axXdzuOgtifyvKhVMwJUNHeFEDkLlo=axXdzuOgtifyvKhVMwJUNHeFEDkLlY.value
   if axXdzuOgtifyvKhVMwJUNHeFEDkLcC:
    axXdzuOgtifyvKhVMwJUNHeFEDkLcW=axXdzuOgtifyvKhVMwJUNHeFEDkLcC
   if axXdzuOgtifyvKhVMwJUNHeFEDkLlo:
    axXdzuOgtifyvKhVMwJUNHeFEDkLcs=axXdzuOgtifyvKhVMwJUNHeFEDkLlo
  except axXdzuOgtifyvKhVMwJUNHeFEDkLjG as exception:
   axXdzuOgtifyvKhVMwJUNHeFEDkLcW=''
   axXdzuOgtifyvKhVMwJUNHeFEDkLcs=''
  return axXdzuOgtifyvKhVMwJUNHeFEDkLcW,axXdzuOgtifyvKhVMwJUNHeFEDkLcs
 def Get_Now_Datetime(axXdzuOgtifyvKhVMwJUNHeFEDkLlj):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(axXdzuOgtifyvKhVMwJUNHeFEDkLlj,movie_code,quality_str):
  axXdzuOgtifyvKhVMwJUNHeFEDkLcb=axXdzuOgtifyvKhVMwJUNHeFEDkLcr=axXdzuOgtifyvKhVMwJUNHeFEDkLcS=''
  try:
   axXdzuOgtifyvKhVMwJUNHeFEDkLQj='/api/watch/'+movie_code+'.json'
   axXdzuOgtifyvKhVMwJUNHeFEDkLlW=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeurl(axXdzuOgtifyvKhVMwJUNHeFEDkLlj.API_DOMAIN,axXdzuOgtifyvKhVMwJUNHeFEDkLQj)
   axXdzuOgtifyvKhVMwJUNHeFEDkLlI={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   axXdzuOgtifyvKhVMwJUNHeFEDkLlY=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.makeDefaultCookies()
   axXdzuOgtifyvKhVMwJUNHeFEDkLlT=axXdzuOgtifyvKhVMwJUNHeFEDkLlj.callRequestCookies('Get',axXdzuOgtifyvKhVMwJUNHeFEDkLlW,payload=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,params=axXdzuOgtifyvKhVMwJUNHeFEDkLjQ,headers=axXdzuOgtifyvKhVMwJUNHeFEDkLlI,cookies=axXdzuOgtifyvKhVMwJUNHeFEDkLlY)
   axXdzuOgtifyvKhVMwJUNHeFEDkLQn=json.loads(axXdzuOgtifyvKhVMwJUNHeFEDkLlT.text)
   axXdzuOgtifyvKhVMwJUNHeFEDkLcb=axXdzuOgtifyvKhVMwJUNHeFEDkLQn['streams'][0]['source']
   if axXdzuOgtifyvKhVMwJUNHeFEDkLcb==axXdzuOgtifyvKhVMwJUNHeFEDkLjQ:return(axXdzuOgtifyvKhVMwJUNHeFEDkLcb,axXdzuOgtifyvKhVMwJUNHeFEDkLcr,axXdzuOgtifyvKhVMwJUNHeFEDkLcS)
   if 'subtitles' in axXdzuOgtifyvKhVMwJUNHeFEDkLQn['streams'][0]:
    for axXdzuOgtifyvKhVMwJUNHeFEDkLcq in axXdzuOgtifyvKhVMwJUNHeFEDkLQn['streams'][0]['subtitles']:
     if axXdzuOgtifyvKhVMwJUNHeFEDkLcq['lang']=='ko':
      axXdzuOgtifyvKhVMwJUNHeFEDkLcr=axXdzuOgtifyvKhVMwJUNHeFEDkLcq['url']
      break
   axXdzuOgtifyvKhVMwJUNHeFEDkLcI =axXdzuOgtifyvKhVMwJUNHeFEDkLQn['ping_payload']
   axXdzuOgtifyvKhVMwJUNHeFEDkLcT =axXdzuOgtifyvKhVMwJUNHeFEDkLlj.WATCHA_USERCD
   axXdzuOgtifyvKhVMwJUNHeFEDkLcY={'merchant':'giitd_frograms','sessionId':axXdzuOgtifyvKhVMwJUNHeFEDkLcI,'userId':axXdzuOgtifyvKhVMwJUNHeFEDkLcT}
   axXdzuOgtifyvKhVMwJUNHeFEDkLco=json.dumps(axXdzuOgtifyvKhVMwJUNHeFEDkLcY,separators=(",",":")).encode('UTF-8')
   axXdzuOgtifyvKhVMwJUNHeFEDkLcS=base64.b64encode(axXdzuOgtifyvKhVMwJUNHeFEDkLco)
  except axXdzuOgtifyvKhVMwJUNHeFEDkLjG as exception:
   return(axXdzuOgtifyvKhVMwJUNHeFEDkLcb,axXdzuOgtifyvKhVMwJUNHeFEDkLcr,axXdzuOgtifyvKhVMwJUNHeFEDkLcS)
  return(axXdzuOgtifyvKhVMwJUNHeFEDkLcb,axXdzuOgtifyvKhVMwJUNHeFEDkLcr,axXdzuOgtifyvKhVMwJUNHeFEDkLcS) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
