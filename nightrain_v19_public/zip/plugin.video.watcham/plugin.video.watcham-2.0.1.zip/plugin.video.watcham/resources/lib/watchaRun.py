__author__="NightRain"
qFQNvdMypYTXrOCfsJLUwltmHVcinb=object
qFQNvdMypYTXrOCfsJLUwltmHVcinI=None
qFQNvdMypYTXrOCfsJLUwltmHVcixB=False
qFQNvdMypYTXrOCfsJLUwltmHVcixK=int
qFQNvdMypYTXrOCfsJLUwltmHVcixg=True
qFQNvdMypYTXrOCfsJLUwltmHVcixA=len
qFQNvdMypYTXrOCfsJLUwltmHVcixn=range
qFQNvdMypYTXrOCfsJLUwltmHVcixD=str
qFQNvdMypYTXrOCfsJLUwltmHVcixh=open
qFQNvdMypYTXrOCfsJLUwltmHVcixW=dict
qFQNvdMypYTXrOCfsJLUwltmHVcixG=Exception
qFQNvdMypYTXrOCfsJLUwltmHVcixa=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
qFQNvdMypYTXrOCfsJLUwltmHVciBg=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'검색 (search)','mode':'SEARCH','stype':'-','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-'}]
qFQNvdMypYTXrOCfsJLUwltmHVciBA=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
qFQNvdMypYTXrOCfsJLUwltmHVciBn=40
qFQNvdMypYTXrOCfsJLUwltmHVciBx =20
qFQNvdMypYTXrOCfsJLUwltmHVciBD='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
qFQNvdMypYTXrOCfsJLUwltmHVciBh =xbmc.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
qFQNvdMypYTXrOCfsJLUwltmHVciBW=xbmc.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class qFQNvdMypYTXrOCfsJLUwltmHVciBK(qFQNvdMypYTXrOCfsJLUwltmHVcinb):
 def __init__(qFQNvdMypYTXrOCfsJLUwltmHVciBG,qFQNvdMypYTXrOCfsJLUwltmHVciBa,qFQNvdMypYTXrOCfsJLUwltmHVciBu,qFQNvdMypYTXrOCfsJLUwltmHVciBo):
  qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_url =qFQNvdMypYTXrOCfsJLUwltmHVciBa
  qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_handle=qFQNvdMypYTXrOCfsJLUwltmHVciBu
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.main_params =qFQNvdMypYTXrOCfsJLUwltmHVciBo
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj =nybBduxJYQjfpMHsLOUolgRCqNAkrc() 
 def addon_noti(qFQNvdMypYTXrOCfsJLUwltmHVciBG,sting):
  try:
   qFQNvdMypYTXrOCfsJLUwltmHVciBz=xbmcgui.Dialog()
   qFQNvdMypYTXrOCfsJLUwltmHVciBz.notification(__addonname__,sting)
  except:
   qFQNvdMypYTXrOCfsJLUwltmHVcinI
 def addon_log(qFQNvdMypYTXrOCfsJLUwltmHVciBG,string,isDebug=qFQNvdMypYTXrOCfsJLUwltmHVcixB):
  try:
   qFQNvdMypYTXrOCfsJLUwltmHVciBE=string.encode('utf-8','ignore')
  except:
   qFQNvdMypYTXrOCfsJLUwltmHVciBE='addonException: addon_log'
  if isDebug:qFQNvdMypYTXrOCfsJLUwltmHVciBR=xbmc.LOGDEBUG
  else:qFQNvdMypYTXrOCfsJLUwltmHVciBR=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,qFQNvdMypYTXrOCfsJLUwltmHVciBE),level=qFQNvdMypYTXrOCfsJLUwltmHVciBR)
 def get_keyboard_input(qFQNvdMypYTXrOCfsJLUwltmHVciBG,qFQNvdMypYTXrOCfsJLUwltmHVciKD):
  qFQNvdMypYTXrOCfsJLUwltmHVciBP=qFQNvdMypYTXrOCfsJLUwltmHVcinI
  kb=xbmc.Keyboard()
  kb.setHeading(qFQNvdMypYTXrOCfsJLUwltmHVciKD)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   qFQNvdMypYTXrOCfsJLUwltmHVciBP=kb.getText()
  return qFQNvdMypYTXrOCfsJLUwltmHVciBP
 def get_settings_login_info(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  qFQNvdMypYTXrOCfsJLUwltmHVciBj =__addon__.getSetting('id')
  qFQNvdMypYTXrOCfsJLUwltmHVciBk =__addon__.getSetting('pw')
  qFQNvdMypYTXrOCfsJLUwltmHVciBS=qFQNvdMypYTXrOCfsJLUwltmHVcixK(__addon__.getSetting('selected_profile'))
  return(qFQNvdMypYTXrOCfsJLUwltmHVciBj,qFQNvdMypYTXrOCfsJLUwltmHVciBk,qFQNvdMypYTXrOCfsJLUwltmHVciBS)
 def get_selQuality(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  try:
   qFQNvdMypYTXrOCfsJLUwltmHVciBb=['3840x2160/1','1920x1080/1','1280x720/1']
   qFQNvdMypYTXrOCfsJLUwltmHVciBI=qFQNvdMypYTXrOCfsJLUwltmHVcixK(__addon__.getSetting('selected_quality'))
   return qFQNvdMypYTXrOCfsJLUwltmHVciBb[qFQNvdMypYTXrOCfsJLUwltmHVciBI]
  except:
   qFQNvdMypYTXrOCfsJLUwltmHVcinI
  return 1080 
 def get_settings_direct_replay(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  qFQNvdMypYTXrOCfsJLUwltmHVciKB=qFQNvdMypYTXrOCfsJLUwltmHVcixK(__addon__.getSetting('direct_replay'))
  if qFQNvdMypYTXrOCfsJLUwltmHVciKB==0:
   return qFQNvdMypYTXrOCfsJLUwltmHVcixB
  else:
   return qFQNvdMypYTXrOCfsJLUwltmHVcixg
 def set_winCredential(qFQNvdMypYTXrOCfsJLUwltmHVciBG,credential):
  qFQNvdMypYTXrOCfsJLUwltmHVciKg=xbmcgui.Window(10000)
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_LOGINTIME',datetime.datetime.now().strftime('%Y-%m-%d'))
 def get_winCredential(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  qFQNvdMypYTXrOCfsJLUwltmHVciKg=xbmcgui.Window(10000)
  qFQNvdMypYTXrOCfsJLUwltmHVciKA={'watcha_token':qFQNvdMypYTXrOCfsJLUwltmHVciKg.getProperty('WATCHA_M_TOKEN'),'watcha_guit':qFQNvdMypYTXrOCfsJLUwltmHVciKg.getProperty('WATCHA_M_GUIT'),'watcha_guitv':qFQNvdMypYTXrOCfsJLUwltmHVciKg.getProperty('WATCHA_M_GUITV'),'watcha_usercd':qFQNvdMypYTXrOCfsJLUwltmHVciKg.getProperty('WATCHA_M_USERCD')}
  return qFQNvdMypYTXrOCfsJLUwltmHVciKA
 def set_winEpisodeOrderby(qFQNvdMypYTXrOCfsJLUwltmHVciBG,qFQNvdMypYTXrOCfsJLUwltmHVciKn):
  qFQNvdMypYTXrOCfsJLUwltmHVciKg=xbmcgui.Window(10000)
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_ORDERBY',qFQNvdMypYTXrOCfsJLUwltmHVciKn)
 def get_winEpisodeOrderby(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  qFQNvdMypYTXrOCfsJLUwltmHVciKg=xbmcgui.Window(10000)
  return qFQNvdMypYTXrOCfsJLUwltmHVciKg.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(qFQNvdMypYTXrOCfsJLUwltmHVciBG,args):
  qFQNvdMypYTXrOCfsJLUwltmHVciKn =args.get('orderby')
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.set_winEpisodeOrderby(qFQNvdMypYTXrOCfsJLUwltmHVciKn)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciBG,label,sublabel='',img='',infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVcinI,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVcixg,params=''):
  qFQNvdMypYTXrOCfsJLUwltmHVciKx='%s?%s'%(qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_url,urllib.parse.urlencode(params))
  if sublabel:qFQNvdMypYTXrOCfsJLUwltmHVciKD='%s < %s >'%(label,sublabel)
  else: qFQNvdMypYTXrOCfsJLUwltmHVciKD=label
  if not img:img='DefaultFolder.png'
  qFQNvdMypYTXrOCfsJLUwltmHVciKh=xbmcgui.ListItem(qFQNvdMypYTXrOCfsJLUwltmHVciKD)
  qFQNvdMypYTXrOCfsJLUwltmHVciKh.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:qFQNvdMypYTXrOCfsJLUwltmHVciKh.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:qFQNvdMypYTXrOCfsJLUwltmHVciKh.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_handle,qFQNvdMypYTXrOCfsJLUwltmHVciKx,qFQNvdMypYTXrOCfsJLUwltmHVciKh,isFolder)
 def dp_Main_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  for qFQNvdMypYTXrOCfsJLUwltmHVciKW in qFQNvdMypYTXrOCfsJLUwltmHVciBg:
   qFQNvdMypYTXrOCfsJLUwltmHVciKD=qFQNvdMypYTXrOCfsJLUwltmHVciKW.get('title')
   qFQNvdMypYTXrOCfsJLUwltmHVciKG={'mode':qFQNvdMypYTXrOCfsJLUwltmHVciKW.get('mode'),'stype':qFQNvdMypYTXrOCfsJLUwltmHVciKW.get('stype'),'api_path':qFQNvdMypYTXrOCfsJLUwltmHVciKW.get('api_path'),'page':'1','sort':qFQNvdMypYTXrOCfsJLUwltmHVciKW.get('sort'),'tag_id':'-'}
   if qFQNvdMypYTXrOCfsJLUwltmHVciKW.get('mode')=='XXX':
    qFQNvdMypYTXrOCfsJLUwltmHVciKG['mode']='XXX'
    qFQNvdMypYTXrOCfsJLUwltmHVciKa=qFQNvdMypYTXrOCfsJLUwltmHVcixB
   else:
    qFQNvdMypYTXrOCfsJLUwltmHVciKa=qFQNvdMypYTXrOCfsJLUwltmHVcixg
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel='',img='',infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVcinI,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVciKa,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
  if qFQNvdMypYTXrOCfsJLUwltmHVcixA(qFQNvdMypYTXrOCfsJLUwltmHVciBg)>0:xbmcplugin.endOfDirectory(qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_handle)
 def login_main(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  (qFQNvdMypYTXrOCfsJLUwltmHVciKo,qFQNvdMypYTXrOCfsJLUwltmHVciKe,qFQNvdMypYTXrOCfsJLUwltmHVciKz)=qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_settings_login_info()
  if not(qFQNvdMypYTXrOCfsJLUwltmHVciKo and qFQNvdMypYTXrOCfsJLUwltmHVciKe):
   qFQNvdMypYTXrOCfsJLUwltmHVciBz=xbmcgui.Dialog()
   qFQNvdMypYTXrOCfsJLUwltmHVciKE=qFQNvdMypYTXrOCfsJLUwltmHVciBz.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if qFQNvdMypYTXrOCfsJLUwltmHVciKE==qFQNvdMypYTXrOCfsJLUwltmHVcixg:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_winEpisodeOrderby()=='':
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.set_winEpisodeOrderby('asc')
  if qFQNvdMypYTXrOCfsJLUwltmHVciBG.cookiefile_check():return
  qFQNvdMypYTXrOCfsJLUwltmHVciKR =qFQNvdMypYTXrOCfsJLUwltmHVcixK(datetime.datetime.now().strftime('%Y%m%d'))
  qFQNvdMypYTXrOCfsJLUwltmHVciKP=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if qFQNvdMypYTXrOCfsJLUwltmHVciKP==qFQNvdMypYTXrOCfsJLUwltmHVcinI or qFQNvdMypYTXrOCfsJLUwltmHVciKP=='':qFQNvdMypYTXrOCfsJLUwltmHVciKP=qFQNvdMypYTXrOCfsJLUwltmHVcixK('19000101')
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   qFQNvdMypYTXrOCfsJLUwltmHVciKj=0
   while qFQNvdMypYTXrOCfsJLUwltmHVcixg:
    qFQNvdMypYTXrOCfsJLUwltmHVciKj+=1
    time.sleep(0.05)
    if qFQNvdMypYTXrOCfsJLUwltmHVciKP>=qFQNvdMypYTXrOCfsJLUwltmHVciKR:return
    if qFQNvdMypYTXrOCfsJLUwltmHVciKj>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if qFQNvdMypYTXrOCfsJLUwltmHVciKP>=qFQNvdMypYTXrOCfsJLUwltmHVciKR:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.GetCredential(qFQNvdMypYTXrOCfsJLUwltmHVciKo,qFQNvdMypYTXrOCfsJLUwltmHVciKe,qFQNvdMypYTXrOCfsJLUwltmHVciKz):
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.set_winCredential(qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.LoadCredential())
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG,args):
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.SaveCredential(qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_winCredential())
  qFQNvdMypYTXrOCfsJLUwltmHVciKk =args.get('stype')
  qFQNvdMypYTXrOCfsJLUwltmHVciKS =qFQNvdMypYTXrOCfsJLUwltmHVcixK(args.get('page'))
  qFQNvdMypYTXrOCfsJLUwltmHVciKb =args.get('sort')
  qFQNvdMypYTXrOCfsJLUwltmHVciKI=qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.GetSubGroupList(qFQNvdMypYTXrOCfsJLUwltmHVciKk)
  qFQNvdMypYTXrOCfsJLUwltmHVcigB=qFQNvdMypYTXrOCfsJLUwltmHVciBn if qFQNvdMypYTXrOCfsJLUwltmHVciKk=='genres' else qFQNvdMypYTXrOCfsJLUwltmHVciBx
  qFQNvdMypYTXrOCfsJLUwltmHVcigK=qFQNvdMypYTXrOCfsJLUwltmHVcixA(qFQNvdMypYTXrOCfsJLUwltmHVciKI)
  qFQNvdMypYTXrOCfsJLUwltmHVcigA =qFQNvdMypYTXrOCfsJLUwltmHVcixK(qFQNvdMypYTXrOCfsJLUwltmHVcigK//(qFQNvdMypYTXrOCfsJLUwltmHVcigB+1))+1
  qFQNvdMypYTXrOCfsJLUwltmHVcign =(qFQNvdMypYTXrOCfsJLUwltmHVciKS-1)*qFQNvdMypYTXrOCfsJLUwltmHVcigB
  for i in qFQNvdMypYTXrOCfsJLUwltmHVcixn(qFQNvdMypYTXrOCfsJLUwltmHVcigB):
   qFQNvdMypYTXrOCfsJLUwltmHVcigx=qFQNvdMypYTXrOCfsJLUwltmHVcign+i
   if qFQNvdMypYTXrOCfsJLUwltmHVcigx>=qFQNvdMypYTXrOCfsJLUwltmHVcigK:break
   qFQNvdMypYTXrOCfsJLUwltmHVciKD =qFQNvdMypYTXrOCfsJLUwltmHVciKI[qFQNvdMypYTXrOCfsJLUwltmHVcigx].get('group_name')
   qFQNvdMypYTXrOCfsJLUwltmHVcigD =qFQNvdMypYTXrOCfsJLUwltmHVciKI[qFQNvdMypYTXrOCfsJLUwltmHVcigx].get('api_path')
   qFQNvdMypYTXrOCfsJLUwltmHVcigh =qFQNvdMypYTXrOCfsJLUwltmHVciKI[qFQNvdMypYTXrOCfsJLUwltmHVcigx].get('tag_id')
   qFQNvdMypYTXrOCfsJLUwltmHVciKG={'mode':'CATEGORY_LIST','api_path':qFQNvdMypYTXrOCfsJLUwltmHVcigD,'tag_id':qFQNvdMypYTXrOCfsJLUwltmHVcigh,'stype':qFQNvdMypYTXrOCfsJLUwltmHVciKk,'page':'1','sort':qFQNvdMypYTXrOCfsJLUwltmHVciKb}
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel='',img='',infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVcinI,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVcixg,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
  if qFQNvdMypYTXrOCfsJLUwltmHVcigA>qFQNvdMypYTXrOCfsJLUwltmHVciKS:
   qFQNvdMypYTXrOCfsJLUwltmHVciKG={}
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['mode'] ='SUB_GROUP' 
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['stype'] =qFQNvdMypYTXrOCfsJLUwltmHVciKk
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['api_path']=args.get('api_path')
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['page'] =qFQNvdMypYTXrOCfsJLUwltmHVcixD(qFQNvdMypYTXrOCfsJLUwltmHVciKS+1)
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['sort'] =qFQNvdMypYTXrOCfsJLUwltmHVciKb
   qFQNvdMypYTXrOCfsJLUwltmHVciKD='[B]%s >>[/B]'%'다음 페이지'
   qFQNvdMypYTXrOCfsJLUwltmHVcigW=qFQNvdMypYTXrOCfsJLUwltmHVcixD(qFQNvdMypYTXrOCfsJLUwltmHVciKS+1)
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel=qFQNvdMypYTXrOCfsJLUwltmHVcigW,img='',infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVcinI,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVcixg,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
  if qFQNvdMypYTXrOCfsJLUwltmHVcixA(qFQNvdMypYTXrOCfsJLUwltmHVciKI)>0:xbmcplugin.endOfDirectory(qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_handle,cacheToDisc=qFQNvdMypYTXrOCfsJLUwltmHVcixg)
 def play_VIDEO(qFQNvdMypYTXrOCfsJLUwltmHVciBG,args):
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.SaveCredential(qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_winCredential())
  qFQNvdMypYTXrOCfsJLUwltmHVcigG =args.get('movie_code')
  qFQNvdMypYTXrOCfsJLUwltmHVciga =args.get('season_code')
  qFQNvdMypYTXrOCfsJLUwltmHVciKD =args.get('title')
  qFQNvdMypYTXrOCfsJLUwltmHVcigu =args.get('thumbnail')
  qFQNvdMypYTXrOCfsJLUwltmHVcigo =qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_selQuality()
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.addon_log(qFQNvdMypYTXrOCfsJLUwltmHVcigG+' - '+qFQNvdMypYTXrOCfsJLUwltmHVciga,qFQNvdMypYTXrOCfsJLUwltmHVcixB)
  qFQNvdMypYTXrOCfsJLUwltmHVcige,qFQNvdMypYTXrOCfsJLUwltmHVcigz,qFQNvdMypYTXrOCfsJLUwltmHVcigE=qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.GetStreamingURL(qFQNvdMypYTXrOCfsJLUwltmHVcigG,qFQNvdMypYTXrOCfsJLUwltmHVcigo)
  if qFQNvdMypYTXrOCfsJLUwltmHVcige=='':
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.addon_noti(__language__(30908).encode('utf8'))
   return
  qFQNvdMypYTXrOCfsJLUwltmHVcigR=qFQNvdMypYTXrOCfsJLUwltmHVcige
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.addon_log(qFQNvdMypYTXrOCfsJLUwltmHVcigR,qFQNvdMypYTXrOCfsJLUwltmHVcixB)
  qFQNvdMypYTXrOCfsJLUwltmHVcigP=xbmcgui.ListItem(path=qFQNvdMypYTXrOCfsJLUwltmHVcigR)
  if qFQNvdMypYTXrOCfsJLUwltmHVcigE:
   qFQNvdMypYTXrOCfsJLUwltmHVcigj=qFQNvdMypYTXrOCfsJLUwltmHVcigE
   qFQNvdMypYTXrOCfsJLUwltmHVcigk ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   qFQNvdMypYTXrOCfsJLUwltmHVcigS ='mpd'
   qFQNvdMypYTXrOCfsJLUwltmHVcigb ='com.widevine.alpha'
   qFQNvdMypYTXrOCfsJLUwltmHVcigI =inputstreamhelper.Helper(qFQNvdMypYTXrOCfsJLUwltmHVcigS,drm=qFQNvdMypYTXrOCfsJLUwltmHVcigb)
   if qFQNvdMypYTXrOCfsJLUwltmHVcigI.check_inputstream():
    qFQNvdMypYTXrOCfsJLUwltmHVciAB={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+qFQNvdMypYTXrOCfsJLUwltmHVcigG,'dt-custom-data':qFQNvdMypYTXrOCfsJLUwltmHVcigj,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':qFQNvdMypYTXrOCfsJLUwltmHVciBD,'Content-Type':'application/octet-stream'}
    qFQNvdMypYTXrOCfsJLUwltmHVciAK=qFQNvdMypYTXrOCfsJLUwltmHVcigk+'|'+urllib.parse.urlencode(qFQNvdMypYTXrOCfsJLUwltmHVciAB)+'|R{SSM}|'
    qFQNvdMypYTXrOCfsJLUwltmHVciBG.addon_log(qFQNvdMypYTXrOCfsJLUwltmHVciAK)
    qFQNvdMypYTXrOCfsJLUwltmHVcigP.setProperty('inputstream',qFQNvdMypYTXrOCfsJLUwltmHVcigI.inputstream_addon)
    qFQNvdMypYTXrOCfsJLUwltmHVcigP.setProperty('inputstream.adaptive.manifest_type',qFQNvdMypYTXrOCfsJLUwltmHVcigS)
    qFQNvdMypYTXrOCfsJLUwltmHVcigP.setProperty('inputstream.adaptive.license_type',qFQNvdMypYTXrOCfsJLUwltmHVcigb)
    qFQNvdMypYTXrOCfsJLUwltmHVcigP.setProperty('inputstream.adaptive.license_key',qFQNvdMypYTXrOCfsJLUwltmHVciAK)
    qFQNvdMypYTXrOCfsJLUwltmHVcigP.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(qFQNvdMypYTXrOCfsJLUwltmHVciBD))
  if qFQNvdMypYTXrOCfsJLUwltmHVcigz:
   try:
    f=qFQNvdMypYTXrOCfsJLUwltmHVcixh(qFQNvdMypYTXrOCfsJLUwltmHVciBh,'w',-1,'utf-8')
    qFQNvdMypYTXrOCfsJLUwltmHVciAg=requests.get(qFQNvdMypYTXrOCfsJLUwltmHVcigz)
    qFQNvdMypYTXrOCfsJLUwltmHVciAn=qFQNvdMypYTXrOCfsJLUwltmHVciAg.content.decode('utf-8') 
    for qFQNvdMypYTXrOCfsJLUwltmHVciAx in qFQNvdMypYTXrOCfsJLUwltmHVciAn.splitlines():
     qFQNvdMypYTXrOCfsJLUwltmHVciAD=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',qFQNvdMypYTXrOCfsJLUwltmHVciAx)
     f.write(qFQNvdMypYTXrOCfsJLUwltmHVciAD+'\n')
    f.close()
    qFQNvdMypYTXrOCfsJLUwltmHVcigP.setSubtitles([qFQNvdMypYTXrOCfsJLUwltmHVciBh,qFQNvdMypYTXrOCfsJLUwltmHVcigz])
   except:
    qFQNvdMypYTXrOCfsJLUwltmHVcigP.setSubtitles([qFQNvdMypYTXrOCfsJLUwltmHVcigz])
  xbmcplugin.setResolvedUrl(qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_handle,qFQNvdMypYTXrOCfsJLUwltmHVcixg,qFQNvdMypYTXrOCfsJLUwltmHVcigP)
  try:
   qFQNvdMypYTXrOCfsJLUwltmHVciKk='movie' if qFQNvdMypYTXrOCfsJLUwltmHVciga=='-' else 'seasons'
   qFQNvdMypYTXrOCfsJLUwltmHVciKG={'code':qFQNvdMypYTXrOCfsJLUwltmHVcigG if qFQNvdMypYTXrOCfsJLUwltmHVciKk=='movie' else qFQNvdMypYTXrOCfsJLUwltmHVciga,'img':qFQNvdMypYTXrOCfsJLUwltmHVcigu,'title':qFQNvdMypYTXrOCfsJLUwltmHVciKD,'videoid':qFQNvdMypYTXrOCfsJLUwltmHVcigG}
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.Save_Watched_List(qFQNvdMypYTXrOCfsJLUwltmHVciKk,qFQNvdMypYTXrOCfsJLUwltmHVciKG)
  except:
   qFQNvdMypYTXrOCfsJLUwltmHVcinI
 def dp_Category_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG,args):
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.SaveCredential(qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_winCredential())
  qFQNvdMypYTXrOCfsJLUwltmHVciKk =args.get('stype')
  qFQNvdMypYTXrOCfsJLUwltmHVcigh =args.get('tag_id')
  qFQNvdMypYTXrOCfsJLUwltmHVcigD=args.get('api_path')
  qFQNvdMypYTXrOCfsJLUwltmHVciKS=qFQNvdMypYTXrOCfsJLUwltmHVcixK(args.get('page'))
  qFQNvdMypYTXrOCfsJLUwltmHVciKb =args.get('sort')
  qFQNvdMypYTXrOCfsJLUwltmHVciAh,qFQNvdMypYTXrOCfsJLUwltmHVciAW=qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.GetCategoryList(qFQNvdMypYTXrOCfsJLUwltmHVciKk,qFQNvdMypYTXrOCfsJLUwltmHVcigh,qFQNvdMypYTXrOCfsJLUwltmHVcigD,qFQNvdMypYTXrOCfsJLUwltmHVciKS,qFQNvdMypYTXrOCfsJLUwltmHVciKb)
  for qFQNvdMypYTXrOCfsJLUwltmHVciAG in qFQNvdMypYTXrOCfsJLUwltmHVciAh:
   qFQNvdMypYTXrOCfsJLUwltmHVcigG =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('code')
   qFQNvdMypYTXrOCfsJLUwltmHVciKD =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('title')
   qFQNvdMypYTXrOCfsJLUwltmHVciAa =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('content_type')
   qFQNvdMypYTXrOCfsJLUwltmHVciAu =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('story')
   qFQNvdMypYTXrOCfsJLUwltmHVcigu =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('thumbnail')
   qFQNvdMypYTXrOCfsJLUwltmHVciAo =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('year')
   qFQNvdMypYTXrOCfsJLUwltmHVciAe =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('film_rating_code')
   qFQNvdMypYTXrOCfsJLUwltmHVciAz=qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('film_rating_short')
   if qFQNvdMypYTXrOCfsJLUwltmHVciAa=='movies': 
    qFQNvdMypYTXrOCfsJLUwltmHVciKa=qFQNvdMypYTXrOCfsJLUwltmHVcixB
    qFQNvdMypYTXrOCfsJLUwltmHVciAE ='MOVIE'
    qFQNvdMypYTXrOCfsJLUwltmHVciKu=''
    qFQNvdMypYTXrOCfsJLUwltmHVciga='-'
   else: 
    qFQNvdMypYTXrOCfsJLUwltmHVciKa=qFQNvdMypYTXrOCfsJLUwltmHVcixg
    qFQNvdMypYTXrOCfsJLUwltmHVciAE ='EPISODE'
    qFQNvdMypYTXrOCfsJLUwltmHVciKu='Series'
    qFQNvdMypYTXrOCfsJLUwltmHVciga=qFQNvdMypYTXrOCfsJLUwltmHVcigG
   qFQNvdMypYTXrOCfsJLUwltmHVciAR=qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('info')
   qFQNvdMypYTXrOCfsJLUwltmHVciAR['plot']='%s (%s)\n년도 : %s\n\n%s'%(qFQNvdMypYTXrOCfsJLUwltmHVciKD,qFQNvdMypYTXrOCfsJLUwltmHVciAz,qFQNvdMypYTXrOCfsJLUwltmHVciAo,qFQNvdMypYTXrOCfsJLUwltmHVciAu)
   if qFQNvdMypYTXrOCfsJLUwltmHVciAe>=19:
    qFQNvdMypYTXrOCfsJLUwltmHVciKD+='  (%s년 - %s)'%(qFQNvdMypYTXrOCfsJLUwltmHVciAo,qFQNvdMypYTXrOCfsJLUwltmHVcixD(qFQNvdMypYTXrOCfsJLUwltmHVciAz))
   else:
    qFQNvdMypYTXrOCfsJLUwltmHVciKD+='  (%s년)'%(qFQNvdMypYTXrOCfsJLUwltmHVciAo)
   qFQNvdMypYTXrOCfsJLUwltmHVciKG={'mode':qFQNvdMypYTXrOCfsJLUwltmHVciAE,'movie_code':qFQNvdMypYTXrOCfsJLUwltmHVcigG,'page':'1','season_code':qFQNvdMypYTXrOCfsJLUwltmHVciga,'title':qFQNvdMypYTXrOCfsJLUwltmHVciKD,'thumbnail':qFQNvdMypYTXrOCfsJLUwltmHVcigu}
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel=qFQNvdMypYTXrOCfsJLUwltmHVciKu,img=qFQNvdMypYTXrOCfsJLUwltmHVcigu,infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVciAR,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVciKa,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
  if qFQNvdMypYTXrOCfsJLUwltmHVciAW:
   if qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.GetCategoryList_morepage(qFQNvdMypYTXrOCfsJLUwltmHVciKk,qFQNvdMypYTXrOCfsJLUwltmHVcigh,qFQNvdMypYTXrOCfsJLUwltmHVcigD,qFQNvdMypYTXrOCfsJLUwltmHVciKS+1,qFQNvdMypYTXrOCfsJLUwltmHVciKb):
    qFQNvdMypYTXrOCfsJLUwltmHVciKG={}
    qFQNvdMypYTXrOCfsJLUwltmHVciKG['mode'] ='CATEGORY_LIST'
    qFQNvdMypYTXrOCfsJLUwltmHVciKG['stype'] =qFQNvdMypYTXrOCfsJLUwltmHVciKk
    qFQNvdMypYTXrOCfsJLUwltmHVciKG['tag_id'] =qFQNvdMypYTXrOCfsJLUwltmHVcigh
    qFQNvdMypYTXrOCfsJLUwltmHVciKG['api_path']=qFQNvdMypYTXrOCfsJLUwltmHVcigD
    qFQNvdMypYTXrOCfsJLUwltmHVciKG['page'] =qFQNvdMypYTXrOCfsJLUwltmHVcixD(qFQNvdMypYTXrOCfsJLUwltmHVciKS+1)
    qFQNvdMypYTXrOCfsJLUwltmHVciKG['sort'] =qFQNvdMypYTXrOCfsJLUwltmHVciKb
    qFQNvdMypYTXrOCfsJLUwltmHVciKD='[B]%s >>[/B]'%'다음 페이지'
    qFQNvdMypYTXrOCfsJLUwltmHVcigW=qFQNvdMypYTXrOCfsJLUwltmHVcixD(qFQNvdMypYTXrOCfsJLUwltmHVciKS+1)
    qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel=qFQNvdMypYTXrOCfsJLUwltmHVcigW,img='',infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVcinI,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVcixg,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
  if qFQNvdMypYTXrOCfsJLUwltmHVcixA(qFQNvdMypYTXrOCfsJLUwltmHVciAh)>0:
   if qFQNvdMypYTXrOCfsJLUwltmHVcigD=='arrivals/latest':
    xbmcplugin.endOfDirectory(qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_handle,cacheToDisc=qFQNvdMypYTXrOCfsJLUwltmHVcixg)
   else:
    xbmcplugin.endOfDirectory(qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_handle,cacheToDisc=qFQNvdMypYTXrOCfsJLUwltmHVcixB)
 def dp_Episode_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG,args):
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.SaveCredential(qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_winCredential())
  qFQNvdMypYTXrOCfsJLUwltmHVciAj=args.get('movie_code')
  qFQNvdMypYTXrOCfsJLUwltmHVciKS =qFQNvdMypYTXrOCfsJLUwltmHVcixK(args.get('page'))
  qFQNvdMypYTXrOCfsJLUwltmHVciga =args.get('season_code')
  qFQNvdMypYTXrOCfsJLUwltmHVciAh,qFQNvdMypYTXrOCfsJLUwltmHVciAW=qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.GetEpisodoList(qFQNvdMypYTXrOCfsJLUwltmHVciAj,qFQNvdMypYTXrOCfsJLUwltmHVciKS,orderby=qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_winEpisodeOrderby())
  for qFQNvdMypYTXrOCfsJLUwltmHVciAG in qFQNvdMypYTXrOCfsJLUwltmHVciAh:
   qFQNvdMypYTXrOCfsJLUwltmHVcigG =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('code')
   qFQNvdMypYTXrOCfsJLUwltmHVciKD =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('title')
   qFQNvdMypYTXrOCfsJLUwltmHVcigu =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('thumbnail')
   qFQNvdMypYTXrOCfsJLUwltmHVciAk =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('display_num')
   qFQNvdMypYTXrOCfsJLUwltmHVciAS=qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('season_title')
   qFQNvdMypYTXrOCfsJLUwltmHVciAR=qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('info')
   qFQNvdMypYTXrOCfsJLUwltmHVciAR['plot']='%s\n%s\n\n%s'%(qFQNvdMypYTXrOCfsJLUwltmHVciAS,qFQNvdMypYTXrOCfsJLUwltmHVciAk,qFQNvdMypYTXrOCfsJLUwltmHVciKD)
   qFQNvdMypYTXrOCfsJLUwltmHVciKD='(%s) %s'%(qFQNvdMypYTXrOCfsJLUwltmHVciAk,qFQNvdMypYTXrOCfsJLUwltmHVciKD)
   qFQNvdMypYTXrOCfsJLUwltmHVciKG={'mode':'MOVIE','movie_code':qFQNvdMypYTXrOCfsJLUwltmHVcigG,'season_code':qFQNvdMypYTXrOCfsJLUwltmHVciga,'title':'%s < %s >'%(qFQNvdMypYTXrOCfsJLUwltmHVciKD,qFQNvdMypYTXrOCfsJLUwltmHVciAS),'thumbnail':qFQNvdMypYTXrOCfsJLUwltmHVcigu}
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel=qFQNvdMypYTXrOCfsJLUwltmHVciAS,img=qFQNvdMypYTXrOCfsJLUwltmHVcigu,infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVciAR,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVcixB,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
  if qFQNvdMypYTXrOCfsJLUwltmHVciKS==1:
   qFQNvdMypYTXrOCfsJLUwltmHVciAR={'plot':'정렬순서를 변경합니다.'}
   qFQNvdMypYTXrOCfsJLUwltmHVciKG={}
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['mode'] ='ORDER_BY' 
   if qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_winEpisodeOrderby()=='desc':
    qFQNvdMypYTXrOCfsJLUwltmHVciKD='정렬순서변경 : 최신화부터 -> 1회부터'
    qFQNvdMypYTXrOCfsJLUwltmHVciKG['orderby']='asc'
   else:
    qFQNvdMypYTXrOCfsJLUwltmHVciKD='정렬순서변경 : 1회부터 -> 최신화부터'
    qFQNvdMypYTXrOCfsJLUwltmHVciKG['orderby']='desc'
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel='',img='',infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVciAR,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVcixB,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
  if qFQNvdMypYTXrOCfsJLUwltmHVciAW:
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['mode'] ='EPISODE' 
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['movie_code']=qFQNvdMypYTXrOCfsJLUwltmHVciAj
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['page'] =qFQNvdMypYTXrOCfsJLUwltmHVcixD(qFQNvdMypYTXrOCfsJLUwltmHVciKS+1)
   qFQNvdMypYTXrOCfsJLUwltmHVciKD='[B]%s >>[/B]'%'다음 페이지'
   qFQNvdMypYTXrOCfsJLUwltmHVcigW=qFQNvdMypYTXrOCfsJLUwltmHVcixD(qFQNvdMypYTXrOCfsJLUwltmHVciKS+1)
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel=qFQNvdMypYTXrOCfsJLUwltmHVcigW,img='',infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVcinI,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVcixg,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
  if qFQNvdMypYTXrOCfsJLUwltmHVcixA(qFQNvdMypYTXrOCfsJLUwltmHVciAh)>0:xbmcplugin.endOfDirectory(qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_handle,cacheToDisc=qFQNvdMypYTXrOCfsJLUwltmHVcixg)
 def dp_Search_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG,args):
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.SaveCredential(qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_winCredential())
  qFQNvdMypYTXrOCfsJLUwltmHVciKS =qFQNvdMypYTXrOCfsJLUwltmHVcixK(args.get('page'))
  if 'search_key' in args:
   qFQNvdMypYTXrOCfsJLUwltmHVciAb=args.get('search_key')
  else:
   qFQNvdMypYTXrOCfsJLUwltmHVciAb=qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not qFQNvdMypYTXrOCfsJLUwltmHVciAb:return
  qFQNvdMypYTXrOCfsJLUwltmHVciAh,qFQNvdMypYTXrOCfsJLUwltmHVciAW=qFQNvdMypYTXrOCfsJLUwltmHVciBG.WatchaObj.GetSearchList(qFQNvdMypYTXrOCfsJLUwltmHVciAb,qFQNvdMypYTXrOCfsJLUwltmHVciKS)
  if qFQNvdMypYTXrOCfsJLUwltmHVcixA(qFQNvdMypYTXrOCfsJLUwltmHVciAh)==0:return
  for qFQNvdMypYTXrOCfsJLUwltmHVciAG in qFQNvdMypYTXrOCfsJLUwltmHVciAh:
   qFQNvdMypYTXrOCfsJLUwltmHVcigG =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('code')
   qFQNvdMypYTXrOCfsJLUwltmHVciKD =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('title')
   qFQNvdMypYTXrOCfsJLUwltmHVciAa=qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('content_type')
   qFQNvdMypYTXrOCfsJLUwltmHVciAu =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('story')
   qFQNvdMypYTXrOCfsJLUwltmHVcigu =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('thumbnail')
   qFQNvdMypYTXrOCfsJLUwltmHVciAo =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('year')
   qFQNvdMypYTXrOCfsJLUwltmHVciAe =qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('film_rating_code')
   qFQNvdMypYTXrOCfsJLUwltmHVciAz=qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('film_rating_short')
   if qFQNvdMypYTXrOCfsJLUwltmHVciAa=='movies': 
    qFQNvdMypYTXrOCfsJLUwltmHVciKa=qFQNvdMypYTXrOCfsJLUwltmHVcixB
    qFQNvdMypYTXrOCfsJLUwltmHVciAE ='MOVIE'
    qFQNvdMypYTXrOCfsJLUwltmHVciKu=''
    qFQNvdMypYTXrOCfsJLUwltmHVciga='-'
   else: 
    qFQNvdMypYTXrOCfsJLUwltmHVciKa=qFQNvdMypYTXrOCfsJLUwltmHVcixg
    qFQNvdMypYTXrOCfsJLUwltmHVciAE ='EPISODE'
    qFQNvdMypYTXrOCfsJLUwltmHVciKu='Series'
    qFQNvdMypYTXrOCfsJLUwltmHVciga=qFQNvdMypYTXrOCfsJLUwltmHVcigG
   qFQNvdMypYTXrOCfsJLUwltmHVciAR=qFQNvdMypYTXrOCfsJLUwltmHVciAG.get('info')
   qFQNvdMypYTXrOCfsJLUwltmHVciAR['plot']='%s (%s)\n년도 : %s\n\n%s'%(qFQNvdMypYTXrOCfsJLUwltmHVciKD,qFQNvdMypYTXrOCfsJLUwltmHVciAz,qFQNvdMypYTXrOCfsJLUwltmHVciAo,qFQNvdMypYTXrOCfsJLUwltmHVciAu)
   if qFQNvdMypYTXrOCfsJLUwltmHVciAe>=19:
    qFQNvdMypYTXrOCfsJLUwltmHVciKD+='  (%s년 - %s)'%(qFQNvdMypYTXrOCfsJLUwltmHVciAo,qFQNvdMypYTXrOCfsJLUwltmHVcixD(qFQNvdMypYTXrOCfsJLUwltmHVciAz))
   else:
    qFQNvdMypYTXrOCfsJLUwltmHVciKD+='  (%s년)'%(qFQNvdMypYTXrOCfsJLUwltmHVciAo)
   qFQNvdMypYTXrOCfsJLUwltmHVciKG={'mode':qFQNvdMypYTXrOCfsJLUwltmHVciAE,'movie_code':qFQNvdMypYTXrOCfsJLUwltmHVcigG,'page':'1','season_code':qFQNvdMypYTXrOCfsJLUwltmHVciga,'title':qFQNvdMypYTXrOCfsJLUwltmHVciKD,'thumbnail':qFQNvdMypYTXrOCfsJLUwltmHVcigu}
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel=qFQNvdMypYTXrOCfsJLUwltmHVciKu,img=qFQNvdMypYTXrOCfsJLUwltmHVcigu,infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVciAR,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVciKa,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
  if qFQNvdMypYTXrOCfsJLUwltmHVciAW:
   qFQNvdMypYTXrOCfsJLUwltmHVciKG={}
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['mode'] ='SEARCH'
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['search_key']=qFQNvdMypYTXrOCfsJLUwltmHVciAb
   qFQNvdMypYTXrOCfsJLUwltmHVciKG['page'] =qFQNvdMypYTXrOCfsJLUwltmHVcixD(qFQNvdMypYTXrOCfsJLUwltmHVciKS+1)
   qFQNvdMypYTXrOCfsJLUwltmHVciKD='[B]%s >>[/B]'%'다음 페이지'
   qFQNvdMypYTXrOCfsJLUwltmHVcigW=qFQNvdMypYTXrOCfsJLUwltmHVcixD(qFQNvdMypYTXrOCfsJLUwltmHVciKS+1)
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel=qFQNvdMypYTXrOCfsJLUwltmHVcigW,img='',infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVcinI,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVcixg,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
  if qFQNvdMypYTXrOCfsJLUwltmHVcixA(qFQNvdMypYTXrOCfsJLUwltmHVciAh)>0:xbmcplugin.endOfDirectory(qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_handle)
 def Delete_Watched_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG,qFQNvdMypYTXrOCfsJLUwltmHVciKk):
  try:
   qFQNvdMypYTXrOCfsJLUwltmHVciAI=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qFQNvdMypYTXrOCfsJLUwltmHVciKk))
   with qFQNvdMypYTXrOCfsJLUwltmHVcixh(qFQNvdMypYTXrOCfsJLUwltmHVciAI,'w',-1,'utf-8')as fp:
    fp.write('')
  except:
   qFQNvdMypYTXrOCfsJLUwltmHVcinI
 def dp_WatchList_Delete(qFQNvdMypYTXrOCfsJLUwltmHVciBG,args):
  qFQNvdMypYTXrOCfsJLUwltmHVciKk=args.get('stype')
  qFQNvdMypYTXrOCfsJLUwltmHVciBz=xbmcgui.Dialog()
  qFQNvdMypYTXrOCfsJLUwltmHVciKE=qFQNvdMypYTXrOCfsJLUwltmHVciBz.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if qFQNvdMypYTXrOCfsJLUwltmHVciKE==qFQNvdMypYTXrOCfsJLUwltmHVcixB:sys.exit()
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.Delete_Watched_List(qFQNvdMypYTXrOCfsJLUwltmHVciKk)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG,qFQNvdMypYTXrOCfsJLUwltmHVciKk):
  try:
   qFQNvdMypYTXrOCfsJLUwltmHVciAI=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qFQNvdMypYTXrOCfsJLUwltmHVciKk))
   with qFQNvdMypYTXrOCfsJLUwltmHVcixh(qFQNvdMypYTXrOCfsJLUwltmHVciAI,'r',-1,'utf-8')as fp:
    qFQNvdMypYTXrOCfsJLUwltmHVcinB=fp.readlines()
  except:
   qFQNvdMypYTXrOCfsJLUwltmHVcinB=[]
  return qFQNvdMypYTXrOCfsJLUwltmHVcinB
 def Save_Watched_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG,qFQNvdMypYTXrOCfsJLUwltmHVciKk,qFQNvdMypYTXrOCfsJLUwltmHVciBo):
  try:
   qFQNvdMypYTXrOCfsJLUwltmHVciAI=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qFQNvdMypYTXrOCfsJLUwltmHVciKk))
   qFQNvdMypYTXrOCfsJLUwltmHVcinK=qFQNvdMypYTXrOCfsJLUwltmHVciBG.Load_Watched_List(qFQNvdMypYTXrOCfsJLUwltmHVciKk) 
   with qFQNvdMypYTXrOCfsJLUwltmHVcixh(qFQNvdMypYTXrOCfsJLUwltmHVciAI,'w',-1,'utf-8')as fp:
    qFQNvdMypYTXrOCfsJLUwltmHVcing=urllib.parse.urlencode(qFQNvdMypYTXrOCfsJLUwltmHVciBo)
    qFQNvdMypYTXrOCfsJLUwltmHVcing=qFQNvdMypYTXrOCfsJLUwltmHVcing+'\n'
    fp.write(qFQNvdMypYTXrOCfsJLUwltmHVcing)
    qFQNvdMypYTXrOCfsJLUwltmHVcinA=0
    for qFQNvdMypYTXrOCfsJLUwltmHVcinx in qFQNvdMypYTXrOCfsJLUwltmHVcinK:
     qFQNvdMypYTXrOCfsJLUwltmHVcinD=qFQNvdMypYTXrOCfsJLUwltmHVcixW(urllib.parse.parse_qsl(qFQNvdMypYTXrOCfsJLUwltmHVcinx))
     qFQNvdMypYTXrOCfsJLUwltmHVcinh=qFQNvdMypYTXrOCfsJLUwltmHVciBo.get('code')
     qFQNvdMypYTXrOCfsJLUwltmHVcinW=qFQNvdMypYTXrOCfsJLUwltmHVcinD.get('code')
     if qFQNvdMypYTXrOCfsJLUwltmHVciKk=='seasons' and qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_settings_direct_replay()==qFQNvdMypYTXrOCfsJLUwltmHVcixg:
      qFQNvdMypYTXrOCfsJLUwltmHVcinh=qFQNvdMypYTXrOCfsJLUwltmHVciBo.get('videoid')
      qFQNvdMypYTXrOCfsJLUwltmHVcinW=qFQNvdMypYTXrOCfsJLUwltmHVcinD.get('videoid')if qFQNvdMypYTXrOCfsJLUwltmHVcinW!=qFQNvdMypYTXrOCfsJLUwltmHVcinI else '-'
     if qFQNvdMypYTXrOCfsJLUwltmHVcinh!=qFQNvdMypYTXrOCfsJLUwltmHVcinW:
      fp.write(qFQNvdMypYTXrOCfsJLUwltmHVcinx)
      qFQNvdMypYTXrOCfsJLUwltmHVcinA+=1
      if qFQNvdMypYTXrOCfsJLUwltmHVcinA>=50:break
  except:
   qFQNvdMypYTXrOCfsJLUwltmHVcinI
 def dp_Watch_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG,args):
  qFQNvdMypYTXrOCfsJLUwltmHVciKk =args.get('stype')
  qFQNvdMypYTXrOCfsJLUwltmHVciKB=qFQNvdMypYTXrOCfsJLUwltmHVciBG.get_settings_direct_replay()
  if qFQNvdMypYTXrOCfsJLUwltmHVciKk=='-':
   for qFQNvdMypYTXrOCfsJLUwltmHVcinG in qFQNvdMypYTXrOCfsJLUwltmHVciBA:
    qFQNvdMypYTXrOCfsJLUwltmHVciKD=qFQNvdMypYTXrOCfsJLUwltmHVcinG.get('title')
    qFQNvdMypYTXrOCfsJLUwltmHVciKG={'mode':qFQNvdMypYTXrOCfsJLUwltmHVcinG.get('mode'),'stype':qFQNvdMypYTXrOCfsJLUwltmHVcinG.get('stype')}
    qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel='',img='',infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVcinI,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVcixg,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
   if qFQNvdMypYTXrOCfsJLUwltmHVcixA(qFQNvdMypYTXrOCfsJLUwltmHVciBA)>0:xbmcplugin.endOfDirectory(qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_handle)
  else:
   qFQNvdMypYTXrOCfsJLUwltmHVcina=qFQNvdMypYTXrOCfsJLUwltmHVciBG.Load_Watched_List(qFQNvdMypYTXrOCfsJLUwltmHVciKk)
   for qFQNvdMypYTXrOCfsJLUwltmHVcinu in qFQNvdMypYTXrOCfsJLUwltmHVcina:
    qFQNvdMypYTXrOCfsJLUwltmHVcino=qFQNvdMypYTXrOCfsJLUwltmHVcixW(urllib.parse.parse_qsl(qFQNvdMypYTXrOCfsJLUwltmHVcinu))
    qFQNvdMypYTXrOCfsJLUwltmHVcigG=qFQNvdMypYTXrOCfsJLUwltmHVcino.get('code')
    qFQNvdMypYTXrOCfsJLUwltmHVciKD =qFQNvdMypYTXrOCfsJLUwltmHVcino.get('title')
    qFQNvdMypYTXrOCfsJLUwltmHVcigu =qFQNvdMypYTXrOCfsJLUwltmHVcino.get('img')
    qFQNvdMypYTXrOCfsJLUwltmHVcine =qFQNvdMypYTXrOCfsJLUwltmHVcino.get('videoid')
    qFQNvdMypYTXrOCfsJLUwltmHVciAR={}
    qFQNvdMypYTXrOCfsJLUwltmHVciAR['plot']=qFQNvdMypYTXrOCfsJLUwltmHVciKD
    if qFQNvdMypYTXrOCfsJLUwltmHVciKk=='movie':
     qFQNvdMypYTXrOCfsJLUwltmHVciKG={'mode':'MOVIE','page':'1','movie_code':qFQNvdMypYTXrOCfsJLUwltmHVcigG,'season_code':'-','title':qFQNvdMypYTXrOCfsJLUwltmHVciKD,'thumbnail':qFQNvdMypYTXrOCfsJLUwltmHVcigu}
     qFQNvdMypYTXrOCfsJLUwltmHVciKa=qFQNvdMypYTXrOCfsJLUwltmHVcixB
    else:
     if qFQNvdMypYTXrOCfsJLUwltmHVciKB==qFQNvdMypYTXrOCfsJLUwltmHVcixB or qFQNvdMypYTXrOCfsJLUwltmHVcine==qFQNvdMypYTXrOCfsJLUwltmHVcinI:
      qFQNvdMypYTXrOCfsJLUwltmHVciKG={'mode':'EPISODE','page':'1','movie_code':qFQNvdMypYTXrOCfsJLUwltmHVcigG,'season_code':qFQNvdMypYTXrOCfsJLUwltmHVcigG,'title':qFQNvdMypYTXrOCfsJLUwltmHVciKD,'thumbnail':qFQNvdMypYTXrOCfsJLUwltmHVcigu}
      qFQNvdMypYTXrOCfsJLUwltmHVciKa=qFQNvdMypYTXrOCfsJLUwltmHVcixg
     else:
      qFQNvdMypYTXrOCfsJLUwltmHVciKG={'mode':'MOVIE','movie_code':qFQNvdMypYTXrOCfsJLUwltmHVcine,'season_code':qFQNvdMypYTXrOCfsJLUwltmHVcigG,'title':qFQNvdMypYTXrOCfsJLUwltmHVciKD,'thumbnail':qFQNvdMypYTXrOCfsJLUwltmHVcigu}
      qFQNvdMypYTXrOCfsJLUwltmHVciKa=qFQNvdMypYTXrOCfsJLUwltmHVcixB
    qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel='',img=qFQNvdMypYTXrOCfsJLUwltmHVcigu,infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVciAR,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVciKa,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
   qFQNvdMypYTXrOCfsJLUwltmHVciAR={'plot':'시청목록을 삭제합니다.'}
   qFQNvdMypYTXrOCfsJLUwltmHVciKD='*** 시청목록 삭제 ***'
   qFQNvdMypYTXrOCfsJLUwltmHVciKG={'mode':'MYVIEW_REMOVE','stype':qFQNvdMypYTXrOCfsJLUwltmHVciKk}
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.add_dir(qFQNvdMypYTXrOCfsJLUwltmHVciKD,sublabel='',img='',infoLabels=qFQNvdMypYTXrOCfsJLUwltmHVciAR,isFolder=qFQNvdMypYTXrOCfsJLUwltmHVcixB,params=qFQNvdMypYTXrOCfsJLUwltmHVciKG)
   xbmcplugin.endOfDirectory(qFQNvdMypYTXrOCfsJLUwltmHVciBG._addon_handle,cacheToDisc=qFQNvdMypYTXrOCfsJLUwltmHVcixB)
 def logout(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  qFQNvdMypYTXrOCfsJLUwltmHVciBz=xbmcgui.Dialog()
  qFQNvdMypYTXrOCfsJLUwltmHVciKE=qFQNvdMypYTXrOCfsJLUwltmHVciBz.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if qFQNvdMypYTXrOCfsJLUwltmHVciKE==qFQNvdMypYTXrOCfsJLUwltmHVcixB:sys.exit()
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.wininfo_clear()
  if os.path.isfile(qFQNvdMypYTXrOCfsJLUwltmHVciBW):os.remove(qFQNvdMypYTXrOCfsJLUwltmHVciBW)
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  qFQNvdMypYTXrOCfsJLUwltmHVciKg=xbmcgui.Window(10000)
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_TOKEN','')
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_GUIT','')
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_GUITV','')
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_USERCD','')
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  qFQNvdMypYTXrOCfsJLUwltmHVcinz =datetime.datetime.now()
  qFQNvdMypYTXrOCfsJLUwltmHVcinE=qFQNvdMypYTXrOCfsJLUwltmHVcinz+datetime.timedelta(days=qFQNvdMypYTXrOCfsJLUwltmHVcixK(__addon__.getSetting('cache_ttl')))
  qFQNvdMypYTXrOCfsJLUwltmHVciKg=xbmcgui.Window(10000)
  qFQNvdMypYTXrOCfsJLUwltmHVcinR={'watcha_token':qFQNvdMypYTXrOCfsJLUwltmHVciKg.getProperty('WATCHA_M_TOKEN'),'watcha_guit':qFQNvdMypYTXrOCfsJLUwltmHVciKg.getProperty('WATCHA_M_GUIT'),'watcha_guitv':qFQNvdMypYTXrOCfsJLUwltmHVciKg.getProperty('WATCHA_M_GUITV'),'watcha_usercd':qFQNvdMypYTXrOCfsJLUwltmHVciKg.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':qFQNvdMypYTXrOCfsJLUwltmHVcinE.strftime('%Y-%m-%d')}
  try: 
   with qFQNvdMypYTXrOCfsJLUwltmHVcixh(qFQNvdMypYTXrOCfsJLUwltmHVciBW,'w',-1,'utf-8')as fp:
    qFQNvdMypYTXrOCfsJLUwltmHVcinP.dump(qFQNvdMypYTXrOCfsJLUwltmHVcinR,fp)
  except qFQNvdMypYTXrOCfsJLUwltmHVcixG as exception:
   qFQNvdMypYTXrOCfsJLUwltmHVcixa(exception)
 def cookiefile_check(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  qFQNvdMypYTXrOCfsJLUwltmHVcinR={}
  try: 
   with qFQNvdMypYTXrOCfsJLUwltmHVcixh(qFQNvdMypYTXrOCfsJLUwltmHVciBW,'r',-1,'utf-8')as fp:
    qFQNvdMypYTXrOCfsJLUwltmHVcinR= qFQNvdMypYTXrOCfsJLUwltmHVcinP.load(fp)
  except qFQNvdMypYTXrOCfsJLUwltmHVcixG as exception:
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.wininfo_clear()
   return qFQNvdMypYTXrOCfsJLUwltmHVcixB
  qFQNvdMypYTXrOCfsJLUwltmHVciKo =__addon__.getSetting('id')
  qFQNvdMypYTXrOCfsJLUwltmHVciKe =__addon__.getSetting('pw')
  qFQNvdMypYTXrOCfsJLUwltmHVcinj =__addon__.getSetting('selected_profile')
  qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_id']=base64.standard_b64decode(qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_id']).decode('utf-8')
  qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_pw']=base64.standard_b64decode(qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_pw']).decode('utf-8')
  if qFQNvdMypYTXrOCfsJLUwltmHVciKo!=qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_id']or qFQNvdMypYTXrOCfsJLUwltmHVciKe!=qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_pw']or qFQNvdMypYTXrOCfsJLUwltmHVcinj!=qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_profile']:
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.wininfo_clear()
   return qFQNvdMypYTXrOCfsJLUwltmHVcixB
  qFQNvdMypYTXrOCfsJLUwltmHVciKR =qFQNvdMypYTXrOCfsJLUwltmHVcixK(datetime.datetime.now().strftime('%Y%m%d'))
  qFQNvdMypYTXrOCfsJLUwltmHVcink=qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_limitdate']
  qFQNvdMypYTXrOCfsJLUwltmHVciKP =qFQNvdMypYTXrOCfsJLUwltmHVcixK(re.sub('-','',qFQNvdMypYTXrOCfsJLUwltmHVcink))
  if qFQNvdMypYTXrOCfsJLUwltmHVciKP<qFQNvdMypYTXrOCfsJLUwltmHVciKR:
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.wininfo_clear()
   return qFQNvdMypYTXrOCfsJLUwltmHVcixB
  qFQNvdMypYTXrOCfsJLUwltmHVciKg=xbmcgui.Window(10000)
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_TOKEN',qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_token'])
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_GUIT',qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_guit'])
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_GUITV',qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_guitv'])
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_USERCD',qFQNvdMypYTXrOCfsJLUwltmHVcinR['watcha_usercd'])
  qFQNvdMypYTXrOCfsJLUwltmHVciKg.setProperty('WATCHA_M_LOGINTIME',qFQNvdMypYTXrOCfsJLUwltmHVcink)
  return qFQNvdMypYTXrOCfsJLUwltmHVcixg
 def watcha_main(qFQNvdMypYTXrOCfsJLUwltmHVciBG):
  qFQNvdMypYTXrOCfsJLUwltmHVcinS=qFQNvdMypYTXrOCfsJLUwltmHVciBG.main_params.get('mode',qFQNvdMypYTXrOCfsJLUwltmHVcinI)
  qFQNvdMypYTXrOCfsJLUwltmHVciBG.login_main()
  if qFQNvdMypYTXrOCfsJLUwltmHVcinS is qFQNvdMypYTXrOCfsJLUwltmHVcinI:
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.dp_Main_List()
  elif qFQNvdMypYTXrOCfsJLUwltmHVcinS=='SUB_GROUP':
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.dp_SubGroup_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG.main_params)
  elif qFQNvdMypYTXrOCfsJLUwltmHVcinS=='CATEGORY_LIST':
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.dp_Category_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG.main_params)
  elif qFQNvdMypYTXrOCfsJLUwltmHVcinS=='EPISODE':
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.dp_Episode_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG.main_params)
  elif qFQNvdMypYTXrOCfsJLUwltmHVcinS=='ORDER_BY':
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.dp_setEpOrderby(qFQNvdMypYTXrOCfsJLUwltmHVciBG.main_params)
  elif qFQNvdMypYTXrOCfsJLUwltmHVcinS=='SEARCH':
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.dp_Search_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG.main_params)
  elif qFQNvdMypYTXrOCfsJLUwltmHVcinS=='MOVIE':
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.play_VIDEO(qFQNvdMypYTXrOCfsJLUwltmHVciBG.main_params)
   time.sleep(0.1)
  elif qFQNvdMypYTXrOCfsJLUwltmHVcinS=='WATCH':
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.dp_Watch_List(qFQNvdMypYTXrOCfsJLUwltmHVciBG.main_params)
  elif qFQNvdMypYTXrOCfsJLUwltmHVcinS=='MYVIEW_REMOVE':
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.dp_WatchList_Delete(qFQNvdMypYTXrOCfsJLUwltmHVciBG.main_params)
  elif qFQNvdMypYTXrOCfsJLUwltmHVcinS=='LOGOUT':
   qFQNvdMypYTXrOCfsJLUwltmHVciBG.logout()
  else:
   qFQNvdMypYTXrOCfsJLUwltmHVcinI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
