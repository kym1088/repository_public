__author__="NightRain"
nybBduxJYQjfpMHsLOUolgRCqNAkzi=object
nybBduxJYQjfpMHsLOUolgRCqNAkhr=None
nybBduxJYQjfpMHsLOUolgRCqNAkhc=False
nybBduxJYQjfpMHsLOUolgRCqNAkhz=True
nybBduxJYQjfpMHsLOUolgRCqNAkhK=Exception
nybBduxJYQjfpMHsLOUolgRCqNAkhm=str
nybBduxJYQjfpMHsLOUolgRCqNAkhT=print
nybBduxJYQjfpMHsLOUolgRCqNAkhW=len
nybBduxJYQjfpMHsLOUolgRCqNAkhX=int
nybBduxJYQjfpMHsLOUolgRCqNAkhF=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import base64
import requests
nybBduxJYQjfpMHsLOUolgRCqNAkrz='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
class nybBduxJYQjfpMHsLOUolgRCqNAkrc(nybBduxJYQjfpMHsLOUolgRCqNAkzi):
 def __init__(nybBduxJYQjfpMHsLOUolgRCqNAkrh):
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_TOKEN ='' 
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUIT =''
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUITV =''
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_USERCD=''
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.API_DOMAIN ='https://play.watcha.net'
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.EPISODE_LIMIT=20
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.SEARCH_LIMIT =30
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.DEFAULT_HEADER={'user-agent':nybBduxJYQjfpMHsLOUolgRCqNAkrz,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(nybBduxJYQjfpMHsLOUolgRCqNAkrh,jobtype,nybBduxJYQjfpMHsLOUolgRCqNAkrE,payload=nybBduxJYQjfpMHsLOUolgRCqNAkhr,params=nybBduxJYQjfpMHsLOUolgRCqNAkhr,headers=nybBduxJYQjfpMHsLOUolgRCqNAkhr,cookies=nybBduxJYQjfpMHsLOUolgRCqNAkhr,redirects=nybBduxJYQjfpMHsLOUolgRCqNAkhc):
  nybBduxJYQjfpMHsLOUolgRCqNAkrK=nybBduxJYQjfpMHsLOUolgRCqNAkrh.DEFAULT_HEADER
  if headers:nybBduxJYQjfpMHsLOUolgRCqNAkrK.update(headers)
  if jobtype=='Get':
   nybBduxJYQjfpMHsLOUolgRCqNAkrm=requests.get(nybBduxJYQjfpMHsLOUolgRCqNAkrE,params=params,headers=nybBduxJYQjfpMHsLOUolgRCqNAkrK,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   nybBduxJYQjfpMHsLOUolgRCqNAkrm=requests.put(nybBduxJYQjfpMHsLOUolgRCqNAkrE,data=payload,params=params,headers=nybBduxJYQjfpMHsLOUolgRCqNAkrK,cookies=cookies,allow_redirects=redirects)
  else:
   nybBduxJYQjfpMHsLOUolgRCqNAkrm=requests.post(nybBduxJYQjfpMHsLOUolgRCqNAkrE,data=payload,params=params,headers=nybBduxJYQjfpMHsLOUolgRCqNAkrK,cookies=cookies,allow_redirects=redirects)
  return nybBduxJYQjfpMHsLOUolgRCqNAkrm
 def SaveCredential(nybBduxJYQjfpMHsLOUolgRCqNAkrh,nybBduxJYQjfpMHsLOUolgRCqNAkrT):
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_TOKEN =nybBduxJYQjfpMHsLOUolgRCqNAkrT.get('watcha_token')
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUIT =nybBduxJYQjfpMHsLOUolgRCqNAkrT.get('watcha_guit')
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUITV =nybBduxJYQjfpMHsLOUolgRCqNAkrT.get('watcha_guitv')
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_USERCD =nybBduxJYQjfpMHsLOUolgRCqNAkrT.get('watcha_usercd')
 def SaveCredential_usercd(nybBduxJYQjfpMHsLOUolgRCqNAkrh,nybBduxJYQjfpMHsLOUolgRCqNAkrW):
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_USERCD=nybBduxJYQjfpMHsLOUolgRCqNAkrW
 def SaveCredential_guitv(nybBduxJYQjfpMHsLOUolgRCqNAkrh,nybBduxJYQjfpMHsLOUolgRCqNAkrX,nybBduxJYQjfpMHsLOUolgRCqNAkrF):
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUITV=nybBduxJYQjfpMHsLOUolgRCqNAkrX
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_TOKEN=nybBduxJYQjfpMHsLOUolgRCqNAkrF 
 def ClearCredential(nybBduxJYQjfpMHsLOUolgRCqNAkrh):
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_TOKEN ='' 
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUIT =''
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUITV =''
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_USERCD=''
 def LoadCredential(nybBduxJYQjfpMHsLOUolgRCqNAkrh):
  nybBduxJYQjfpMHsLOUolgRCqNAkrT={'watcha_token':nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_TOKEN,'watcha_guit':nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUIT,'watcha_guitv':nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUITV,'watcha_usercd':nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_USERCD}
  return nybBduxJYQjfpMHsLOUolgRCqNAkrT
 def makeDefaultCookies(nybBduxJYQjfpMHsLOUolgRCqNAkrh):
  nybBduxJYQjfpMHsLOUolgRCqNAkre={'_s_guit':nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUIT,'_guinness-premium_session':nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_TOKEN}
  if nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUITV:
   nybBduxJYQjfpMHsLOUolgRCqNAkre['_s_guitv']=nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_GUITV
  return nybBduxJYQjfpMHsLOUolgRCqNAkre
 def makeurl(nybBduxJYQjfpMHsLOUolgRCqNAkrh,domain,path,query1=nybBduxJYQjfpMHsLOUolgRCqNAkhr,query2=nybBduxJYQjfpMHsLOUolgRCqNAkhr):
  nybBduxJYQjfpMHsLOUolgRCqNAkrE=domain+path
  if query1:
   nybBduxJYQjfpMHsLOUolgRCqNAkrE+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   nybBduxJYQjfpMHsLOUolgRCqNAkrE+='&%s'%urllib.parse.urlencode(query2)
  return nybBduxJYQjfpMHsLOUolgRCqNAkrE
 def GetCredential(nybBduxJYQjfpMHsLOUolgRCqNAkrh,user_id,user_pw,user_pf):
  nybBduxJYQjfpMHsLOUolgRCqNAkrw=nybBduxJYQjfpMHsLOUolgRCqNAkhc
  nybBduxJYQjfpMHsLOUolgRCqNAkrD=nybBduxJYQjfpMHsLOUolgRCqNAkrG='-'
  try:
   nybBduxJYQjfpMHsLOUolgRCqNAkrI=nybBduxJYQjfpMHsLOUolgRCqNAkrh.API_DOMAIN+'/api/session'
   nybBduxJYQjfpMHsLOUolgRCqNAkrv={'email':user_id,'password':user_pw}
   nybBduxJYQjfpMHsLOUolgRCqNAkrS={'accept':'application/vnd.frograms+json;version=4'}
   nybBduxJYQjfpMHsLOUolgRCqNAkrV=nybBduxJYQjfpMHsLOUolgRCqNAkrh.callRequestCookies('Post',nybBduxJYQjfpMHsLOUolgRCqNAkrI,payload=nybBduxJYQjfpMHsLOUolgRCqNAkrv,params=nybBduxJYQjfpMHsLOUolgRCqNAkhr,headers=nybBduxJYQjfpMHsLOUolgRCqNAkrS,cookies=nybBduxJYQjfpMHsLOUolgRCqNAkhr)
   for nybBduxJYQjfpMHsLOUolgRCqNAkrt in nybBduxJYQjfpMHsLOUolgRCqNAkrV.cookies:
    if nybBduxJYQjfpMHsLOUolgRCqNAkrt.name=='_guinness-premium_session':
     nybBduxJYQjfpMHsLOUolgRCqNAkrG=nybBduxJYQjfpMHsLOUolgRCqNAkrt.value
    elif nybBduxJYQjfpMHsLOUolgRCqNAkrt.name=='_s_guit':
     nybBduxJYQjfpMHsLOUolgRCqNAkrD=nybBduxJYQjfpMHsLOUolgRCqNAkrt.value
   if nybBduxJYQjfpMHsLOUolgRCqNAkrG:nybBduxJYQjfpMHsLOUolgRCqNAkrw=nybBduxJYQjfpMHsLOUolgRCqNAkhz
  except nybBduxJYQjfpMHsLOUolgRCqNAkhK as exception:
   nybBduxJYQjfpMHsLOUolgRCqNAkrD=nybBduxJYQjfpMHsLOUolgRCqNAkrG='' 
  nybBduxJYQjfpMHsLOUolgRCqNAkrT={'watcha_guit':nybBduxJYQjfpMHsLOUolgRCqNAkrD,'watcha_token':nybBduxJYQjfpMHsLOUolgRCqNAkrG,'watcha_guitv':'','watcha_usercd':''}
  nybBduxJYQjfpMHsLOUolgRCqNAkrh.SaveCredential(nybBduxJYQjfpMHsLOUolgRCqNAkrT)
  try:
   nybBduxJYQjfpMHsLOUolgRCqNAkri=nybBduxJYQjfpMHsLOUolgRCqNAkrh.GetProfilesList()
   nybBduxJYQjfpMHsLOUolgRCqNAkcr =nybBduxJYQjfpMHsLOUolgRCqNAkri[user_pf]
   nybBduxJYQjfpMHsLOUolgRCqNAkrh.SaveCredential_usercd(nybBduxJYQjfpMHsLOUolgRCqNAkcr)
  except nybBduxJYQjfpMHsLOUolgRCqNAkhK as exception:
   nybBduxJYQjfpMHsLOUolgRCqNAkrh.ClearCredential()
   return nybBduxJYQjfpMHsLOUolgRCqNAkhc
  if user_pf!=0:
   nybBduxJYQjfpMHsLOUolgRCqNAkrX,nybBduxJYQjfpMHsLOUolgRCqNAkrF=nybBduxJYQjfpMHsLOUolgRCqNAkrh.GetProfilesConvert(nybBduxJYQjfpMHsLOUolgRCqNAkcr)
   nybBduxJYQjfpMHsLOUolgRCqNAkrh.SaveCredential_guitv(nybBduxJYQjfpMHsLOUolgRCqNAkrX,nybBduxJYQjfpMHsLOUolgRCqNAkrF)
  return nybBduxJYQjfpMHsLOUolgRCqNAkrw
 def GetSubGroupList(nybBduxJYQjfpMHsLOUolgRCqNAkrh,stype):
  nybBduxJYQjfpMHsLOUolgRCqNAkcz=[]
  try:
   nybBduxJYQjfpMHsLOUolgRCqNAkch ='/api/categories.json'
   nybBduxJYQjfpMHsLOUolgRCqNAkrE=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeurl(nybBduxJYQjfpMHsLOUolgRCqNAkrh.API_DOMAIN,nybBduxJYQjfpMHsLOUolgRCqNAkch)
   nybBduxJYQjfpMHsLOUolgRCqNAkrt=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeDefaultCookies()
   nybBduxJYQjfpMHsLOUolgRCqNAkrV=nybBduxJYQjfpMHsLOUolgRCqNAkrh.callRequestCookies('Get',nybBduxJYQjfpMHsLOUolgRCqNAkrE,payload=nybBduxJYQjfpMHsLOUolgRCqNAkhr,params=nybBduxJYQjfpMHsLOUolgRCqNAkhr,headers=nybBduxJYQjfpMHsLOUolgRCqNAkhr,cookies=nybBduxJYQjfpMHsLOUolgRCqNAkrt)
   nybBduxJYQjfpMHsLOUolgRCqNAkcK=json.loads(nybBduxJYQjfpMHsLOUolgRCqNAkrV.text)
   if not('genres' in nybBduxJYQjfpMHsLOUolgRCqNAkcK):return nybBduxJYQjfpMHsLOUolgRCqNAkcz
   if stype=='genres':
    nybBduxJYQjfpMHsLOUolgRCqNAkcm=nybBduxJYQjfpMHsLOUolgRCqNAkcK['genres']
   else:
    nybBduxJYQjfpMHsLOUolgRCqNAkcm=nybBduxJYQjfpMHsLOUolgRCqNAkcK['tags']
   for nybBduxJYQjfpMHsLOUolgRCqNAkcT in nybBduxJYQjfpMHsLOUolgRCqNAkcm:
    nybBduxJYQjfpMHsLOUolgRCqNAkcW=nybBduxJYQjfpMHsLOUolgRCqNAkcT['name']
    nybBduxJYQjfpMHsLOUolgRCqNAkcX =nybBduxJYQjfpMHsLOUolgRCqNAkcT['api_path']
    nybBduxJYQjfpMHsLOUolgRCqNAkcF =nybBduxJYQjfpMHsLOUolgRCqNAkcT['entity']['id']
    nybBduxJYQjfpMHsLOUolgRCqNAkce={'group_name':nybBduxJYQjfpMHsLOUolgRCqNAkcW,'api_path':nybBduxJYQjfpMHsLOUolgRCqNAkcX,'tag_id':nybBduxJYQjfpMHsLOUolgRCqNAkhm(nybBduxJYQjfpMHsLOUolgRCqNAkcF)}
    nybBduxJYQjfpMHsLOUolgRCqNAkcz.append(nybBduxJYQjfpMHsLOUolgRCqNAkce)
  except nybBduxJYQjfpMHsLOUolgRCqNAkhK as exception:
   nybBduxJYQjfpMHsLOUolgRCqNAkhT(exception)
  return nybBduxJYQjfpMHsLOUolgRCqNAkcz
 def GetCategoryList(nybBduxJYQjfpMHsLOUolgRCqNAkrh,stype,nybBduxJYQjfpMHsLOUolgRCqNAkcF,nybBduxJYQjfpMHsLOUolgRCqNAkcX,page_int,in_sort):
  nybBduxJYQjfpMHsLOUolgRCqNAkcz=[]
  nybBduxJYQjfpMHsLOUolgRCqNAkcE=nybBduxJYQjfpMHsLOUolgRCqNAkhc
  nybBduxJYQjfpMHsLOUolgRCqNAkca={}
  try:
   if 'categories' in nybBduxJYQjfpMHsLOUolgRCqNAkcX:
    nybBduxJYQjfpMHsLOUolgRCqNAkch ='/api/categories/contents.json'
    if stype=='genres':
     nybBduxJYQjfpMHsLOUolgRCqNAkca['genre']=nybBduxJYQjfpMHsLOUolgRCqNAkcF
    else:
     nybBduxJYQjfpMHsLOUolgRCqNAkca['tag'] =nybBduxJYQjfpMHsLOUolgRCqNAkcF
    nybBduxJYQjfpMHsLOUolgRCqNAkca['order']=in_sort 
    if page_int>1:
     nybBduxJYQjfpMHsLOUolgRCqNAkca['page']=nybBduxJYQjfpMHsLOUolgRCqNAkhm(page_int-1)
   else: 
    nybBduxJYQjfpMHsLOUolgRCqNAkch ='/api/'+nybBduxJYQjfpMHsLOUolgRCqNAkcX+'.json'
    if page_int>1:
     nybBduxJYQjfpMHsLOUolgRCqNAkca['page']=nybBduxJYQjfpMHsLOUolgRCqNAkhm(page_int)
   nybBduxJYQjfpMHsLOUolgRCqNAkrE=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeurl(nybBduxJYQjfpMHsLOUolgRCqNAkrh.API_DOMAIN,nybBduxJYQjfpMHsLOUolgRCqNAkch)
   nybBduxJYQjfpMHsLOUolgRCqNAkrt=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeDefaultCookies()
   nybBduxJYQjfpMHsLOUolgRCqNAkrV=nybBduxJYQjfpMHsLOUolgRCqNAkrh.callRequestCookies('Get',nybBduxJYQjfpMHsLOUolgRCqNAkrE,payload=nybBduxJYQjfpMHsLOUolgRCqNAkhr,params=nybBduxJYQjfpMHsLOUolgRCqNAkca,headers=nybBduxJYQjfpMHsLOUolgRCqNAkhr,cookies=nybBduxJYQjfpMHsLOUolgRCqNAkrt)
   nybBduxJYQjfpMHsLOUolgRCqNAkcK=json.loads(nybBduxJYQjfpMHsLOUolgRCqNAkrV.text)
   if not('contents' in nybBduxJYQjfpMHsLOUolgRCqNAkcK):return nybBduxJYQjfpMHsLOUolgRCqNAkcz,nybBduxJYQjfpMHsLOUolgRCqNAkcE
   nybBduxJYQjfpMHsLOUolgRCqNAkcm=nybBduxJYQjfpMHsLOUolgRCqNAkcK['contents']
   nybBduxJYQjfpMHsLOUolgRCqNAkcE=nybBduxJYQjfpMHsLOUolgRCqNAkcK['meta']['has_next']
   for nybBduxJYQjfpMHsLOUolgRCqNAkcT in nybBduxJYQjfpMHsLOUolgRCqNAkcm:
    nybBduxJYQjfpMHsLOUolgRCqNAkcP =nybBduxJYQjfpMHsLOUolgRCqNAkcT['code']
    nybBduxJYQjfpMHsLOUolgRCqNAkcw=nybBduxJYQjfpMHsLOUolgRCqNAkcT['content_type']
    nybBduxJYQjfpMHsLOUolgRCqNAkcD =nybBduxJYQjfpMHsLOUolgRCqNAkcT['title']
    nybBduxJYQjfpMHsLOUolgRCqNAkcI =nybBduxJYQjfpMHsLOUolgRCqNAkcT['story']
    if nybBduxJYQjfpMHsLOUolgRCqNAkcT['thumbnail']!=nybBduxJYQjfpMHsLOUolgRCqNAkhr:
     nybBduxJYQjfpMHsLOUolgRCqNAkcv =nybBduxJYQjfpMHsLOUolgRCqNAkcT['thumbnail']['medium']
    else:
     nybBduxJYQjfpMHsLOUolgRCqNAkcv =nybBduxJYQjfpMHsLOUolgRCqNAkcT['stillcut']['medium']
    nybBduxJYQjfpMHsLOUolgRCqNAkcS =nybBduxJYQjfpMHsLOUolgRCqNAkcT['year']
    nybBduxJYQjfpMHsLOUolgRCqNAkcV =nybBduxJYQjfpMHsLOUolgRCqNAkcT['film_rating_code']
    nybBduxJYQjfpMHsLOUolgRCqNAkct=nybBduxJYQjfpMHsLOUolgRCqNAkcT['film_rating_short']
    nybBduxJYQjfpMHsLOUolgRCqNAkcG={}
    nybBduxJYQjfpMHsLOUolgRCqNAkcG['mpaa']=nybBduxJYQjfpMHsLOUolgRCqNAkcT['film_rating_long']
    nybBduxJYQjfpMHsLOUolgRCqNAkcG['year']=nybBduxJYQjfpMHsLOUolgRCqNAkcT['year']
    nybBduxJYQjfpMHsLOUolgRCqNAkcG['title']=nybBduxJYQjfpMHsLOUolgRCqNAkcT['title']
    if nybBduxJYQjfpMHsLOUolgRCqNAkcw=='movies':
     nybBduxJYQjfpMHsLOUolgRCqNAkcG['mediatype']='movie' 
     nybBduxJYQjfpMHsLOUolgRCqNAkcG['duration']=nybBduxJYQjfpMHsLOUolgRCqNAkcT['duration']
    else:
     nybBduxJYQjfpMHsLOUolgRCqNAkcG['mediatype']='episode' 
    nybBduxJYQjfpMHsLOUolgRCqNAkce={'code':nybBduxJYQjfpMHsLOUolgRCqNAkcP,'content_type':nybBduxJYQjfpMHsLOUolgRCqNAkcw,'title':nybBduxJYQjfpMHsLOUolgRCqNAkcD,'story':nybBduxJYQjfpMHsLOUolgRCqNAkcI,'thumbnail':nybBduxJYQjfpMHsLOUolgRCqNAkcv,'year':nybBduxJYQjfpMHsLOUolgRCqNAkcS,'film_rating_code':nybBduxJYQjfpMHsLOUolgRCqNAkcV,'film_rating_short':nybBduxJYQjfpMHsLOUolgRCqNAkct,'info':nybBduxJYQjfpMHsLOUolgRCqNAkcG}
    nybBduxJYQjfpMHsLOUolgRCqNAkcz.append(nybBduxJYQjfpMHsLOUolgRCqNAkce)
  except nybBduxJYQjfpMHsLOUolgRCqNAkhK as exception:
   nybBduxJYQjfpMHsLOUolgRCqNAkhT(exception)
  return nybBduxJYQjfpMHsLOUolgRCqNAkcz,nybBduxJYQjfpMHsLOUolgRCqNAkcE
 def GetCategoryList_morepage(nybBduxJYQjfpMHsLOUolgRCqNAkrh,stype,nybBduxJYQjfpMHsLOUolgRCqNAkcF,nybBduxJYQjfpMHsLOUolgRCqNAkcX,page_int,in_sort):
  nybBduxJYQjfpMHsLOUolgRCqNAkcE=nybBduxJYQjfpMHsLOUolgRCqNAkhc
  if not('categories' in nybBduxJYQjfpMHsLOUolgRCqNAkcX):return nybBduxJYQjfpMHsLOUolgRCqNAkhz
  try:
   nybBduxJYQjfpMHsLOUolgRCqNAkch ='/api/categories/contents.json'
   nybBduxJYQjfpMHsLOUolgRCqNAkca={}
   if stype=='genres':
    nybBduxJYQjfpMHsLOUolgRCqNAkca['genre']=nybBduxJYQjfpMHsLOUolgRCqNAkcF
   else:
    nybBduxJYQjfpMHsLOUolgRCqNAkca['tag'] =nybBduxJYQjfpMHsLOUolgRCqNAkcF
   nybBduxJYQjfpMHsLOUolgRCqNAkca['order']=in_sort 
   if page_int>1:
    nybBduxJYQjfpMHsLOUolgRCqNAkca['page']=nybBduxJYQjfpMHsLOUolgRCqNAkhm(page_int-1)
   nybBduxJYQjfpMHsLOUolgRCqNAkrE=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeurl(nybBduxJYQjfpMHsLOUolgRCqNAkrh.API_DOMAIN,nybBduxJYQjfpMHsLOUolgRCqNAkch)
   nybBduxJYQjfpMHsLOUolgRCqNAkrt=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeDefaultCookies()
   nybBduxJYQjfpMHsLOUolgRCqNAkrV=nybBduxJYQjfpMHsLOUolgRCqNAkrh.callRequestCookies('Get',nybBduxJYQjfpMHsLOUolgRCqNAkrE,payload=nybBduxJYQjfpMHsLOUolgRCqNAkhr,params=nybBduxJYQjfpMHsLOUolgRCqNAkca,headers=nybBduxJYQjfpMHsLOUolgRCqNAkhr,cookies=nybBduxJYQjfpMHsLOUolgRCqNAkrt)
   nybBduxJYQjfpMHsLOUolgRCqNAkcK=json.loads(nybBduxJYQjfpMHsLOUolgRCqNAkrV.text)
   nybBduxJYQjfpMHsLOUolgRCqNAkcE=nybBduxJYQjfpMHsLOUolgRCqNAkcK['meta']['has_next']
  except nybBduxJYQjfpMHsLOUolgRCqNAkhK as exception:
   nybBduxJYQjfpMHsLOUolgRCqNAkhT(exception)
  return nybBduxJYQjfpMHsLOUolgRCqNAkcE
 def GetEpisodoList(nybBduxJYQjfpMHsLOUolgRCqNAkrh,program_code,page_int,orderby='asc'):
  nybBduxJYQjfpMHsLOUolgRCqNAkcz=[]
  nybBduxJYQjfpMHsLOUolgRCqNAkcE=nybBduxJYQjfpMHsLOUolgRCqNAkhc
  nybBduxJYQjfpMHsLOUolgRCqNAkci=''
  try:
   nybBduxJYQjfpMHsLOUolgRCqNAkch ='/api/contents/'+program_code+'/tv_episodes.json'
   nybBduxJYQjfpMHsLOUolgRCqNAkca={'all':'true'}
   nybBduxJYQjfpMHsLOUolgRCqNAkrE=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeurl(nybBduxJYQjfpMHsLOUolgRCqNAkrh.API_DOMAIN,nybBduxJYQjfpMHsLOUolgRCqNAkch)
   nybBduxJYQjfpMHsLOUolgRCqNAkrt=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeDefaultCookies()
   nybBduxJYQjfpMHsLOUolgRCqNAkrV=nybBduxJYQjfpMHsLOUolgRCqNAkrh.callRequestCookies('Get',nybBduxJYQjfpMHsLOUolgRCqNAkrE,payload=nybBduxJYQjfpMHsLOUolgRCqNAkhr,params=nybBduxJYQjfpMHsLOUolgRCqNAkca,headers=nybBduxJYQjfpMHsLOUolgRCqNAkhr,cookies=nybBduxJYQjfpMHsLOUolgRCqNAkrt)
   nybBduxJYQjfpMHsLOUolgRCqNAkcK=json.loads(nybBduxJYQjfpMHsLOUolgRCqNAkrV.text)
   if not('tv_episode_codes' in nybBduxJYQjfpMHsLOUolgRCqNAkcK):return nybBduxJYQjfpMHsLOUolgRCqNAkcz,nybBduxJYQjfpMHsLOUolgRCqNAkcE
   nybBduxJYQjfpMHsLOUolgRCqNAkcm=nybBduxJYQjfpMHsLOUolgRCqNAkcK['tv_episode_codes']
   nybBduxJYQjfpMHsLOUolgRCqNAkzr=nybBduxJYQjfpMHsLOUolgRCqNAkhW(nybBduxJYQjfpMHsLOUolgRCqNAkcm)
   nybBduxJYQjfpMHsLOUolgRCqNAkzc =nybBduxJYQjfpMHsLOUolgRCqNAkhX(nybBduxJYQjfpMHsLOUolgRCqNAkzr//(nybBduxJYQjfpMHsLOUolgRCqNAkrh.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    nybBduxJYQjfpMHsLOUolgRCqNAkzh =(nybBduxJYQjfpMHsLOUolgRCqNAkzr-1)-((page_int-1)*nybBduxJYQjfpMHsLOUolgRCqNAkrh.EPISODE_LIMIT)
   else:
    nybBduxJYQjfpMHsLOUolgRCqNAkzh =(page_int-1)*nybBduxJYQjfpMHsLOUolgRCqNAkrh.EPISODE_LIMIT
   for i in nybBduxJYQjfpMHsLOUolgRCqNAkhF(nybBduxJYQjfpMHsLOUolgRCqNAkrh.EPISODE_LIMIT):
    if orderby=='desc':
     nybBduxJYQjfpMHsLOUolgRCqNAkzK=nybBduxJYQjfpMHsLOUolgRCqNAkzh-i
     if nybBduxJYQjfpMHsLOUolgRCqNAkzK<0:break
    else:
     nybBduxJYQjfpMHsLOUolgRCqNAkzK=nybBduxJYQjfpMHsLOUolgRCqNAkzh+i
     if nybBduxJYQjfpMHsLOUolgRCqNAkzK>=nybBduxJYQjfpMHsLOUolgRCqNAkzr:break
    if nybBduxJYQjfpMHsLOUolgRCqNAkci!='':nybBduxJYQjfpMHsLOUolgRCqNAkci+=','
    nybBduxJYQjfpMHsLOUolgRCqNAkci+=nybBduxJYQjfpMHsLOUolgRCqNAkcm[nybBduxJYQjfpMHsLOUolgRCqNAkzK]
   if nybBduxJYQjfpMHsLOUolgRCqNAkzc>page_int:nybBduxJYQjfpMHsLOUolgRCqNAkcE=nybBduxJYQjfpMHsLOUolgRCqNAkhz
  except nybBduxJYQjfpMHsLOUolgRCqNAkhK as exception:
   nybBduxJYQjfpMHsLOUolgRCqNAkhT(exception)
  try:
   nybBduxJYQjfpMHsLOUolgRCqNAkca={'codes':nybBduxJYQjfpMHsLOUolgRCqNAkci}
   nybBduxJYQjfpMHsLOUolgRCqNAkrE=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeurl(nybBduxJYQjfpMHsLOUolgRCqNAkrh.API_DOMAIN,nybBduxJYQjfpMHsLOUolgRCqNAkch)
   nybBduxJYQjfpMHsLOUolgRCqNAkrt=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeDefaultCookies()
   nybBduxJYQjfpMHsLOUolgRCqNAkrV=nybBduxJYQjfpMHsLOUolgRCqNAkrh.callRequestCookies('Get',nybBduxJYQjfpMHsLOUolgRCqNAkrE,payload=nybBduxJYQjfpMHsLOUolgRCqNAkhr,params=nybBduxJYQjfpMHsLOUolgRCqNAkca,headers=nybBduxJYQjfpMHsLOUolgRCqNAkhr,cookies=nybBduxJYQjfpMHsLOUolgRCqNAkrt)
   nybBduxJYQjfpMHsLOUolgRCqNAkcK=json.loads(nybBduxJYQjfpMHsLOUolgRCqNAkrV.text)
   if not('tv_episodes' in nybBduxJYQjfpMHsLOUolgRCqNAkcK):return nybBduxJYQjfpMHsLOUolgRCqNAkcz
   nybBduxJYQjfpMHsLOUolgRCqNAkcm=nybBduxJYQjfpMHsLOUolgRCqNAkcK['tv_episodes']
   for nybBduxJYQjfpMHsLOUolgRCqNAkcT in nybBduxJYQjfpMHsLOUolgRCqNAkcm:
    nybBduxJYQjfpMHsLOUolgRCqNAkcP =nybBduxJYQjfpMHsLOUolgRCqNAkcT['code']
    if nybBduxJYQjfpMHsLOUolgRCqNAkcT['title']:
     nybBduxJYQjfpMHsLOUolgRCqNAkcD =nybBduxJYQjfpMHsLOUolgRCqNAkcT['title']
    else:
     nybBduxJYQjfpMHsLOUolgRCqNAkcD =''
    nybBduxJYQjfpMHsLOUolgRCqNAkcv =nybBduxJYQjfpMHsLOUolgRCqNAkcT['stillcut']['medium']
    nybBduxJYQjfpMHsLOUolgRCqNAkzm =nybBduxJYQjfpMHsLOUolgRCqNAkcT['display_number']
    nybBduxJYQjfpMHsLOUolgRCqNAkzT=nybBduxJYQjfpMHsLOUolgRCqNAkcT['tv_season_title']
    nybBduxJYQjfpMHsLOUolgRCqNAkcG={}
    nybBduxJYQjfpMHsLOUolgRCqNAkcG['mediatype'] ='episode'
    nybBduxJYQjfpMHsLOUolgRCqNAkcG['tvshowtitle']=nybBduxJYQjfpMHsLOUolgRCqNAkcD if nybBduxJYQjfpMHsLOUolgRCqNAkcD else nybBduxJYQjfpMHsLOUolgRCqNAkzT
    nybBduxJYQjfpMHsLOUolgRCqNAkcG['title'] ='%s %s'%(nybBduxJYQjfpMHsLOUolgRCqNAkzT,nybBduxJYQjfpMHsLOUolgRCqNAkzm)if nybBduxJYQjfpMHsLOUolgRCqNAkcD else nybBduxJYQjfpMHsLOUolgRCqNAkzm
    nybBduxJYQjfpMHsLOUolgRCqNAkcG['duration'] =nybBduxJYQjfpMHsLOUolgRCqNAkcT['duration']
    try:
     nybBduxJYQjfpMHsLOUolgRCqNAkcG['episode']=nybBduxJYQjfpMHsLOUolgRCqNAkcT['episode_number']
    except:
     nybBduxJYQjfpMHsLOUolgRCqNAkhr
    nybBduxJYQjfpMHsLOUolgRCqNAkce={'code':nybBduxJYQjfpMHsLOUolgRCqNAkcP,'title':nybBduxJYQjfpMHsLOUolgRCqNAkcD,'thumbnail':nybBduxJYQjfpMHsLOUolgRCqNAkcv,'display_num':nybBduxJYQjfpMHsLOUolgRCqNAkzm,'season_title':nybBduxJYQjfpMHsLOUolgRCqNAkzT,'info':nybBduxJYQjfpMHsLOUolgRCqNAkcG}
    nybBduxJYQjfpMHsLOUolgRCqNAkcz.append(nybBduxJYQjfpMHsLOUolgRCqNAkce)
  except nybBduxJYQjfpMHsLOUolgRCqNAkhK as exception:
   nybBduxJYQjfpMHsLOUolgRCqNAkhT(exception)
  return nybBduxJYQjfpMHsLOUolgRCqNAkcz,nybBduxJYQjfpMHsLOUolgRCqNAkcE
 def GetSearchList(nybBduxJYQjfpMHsLOUolgRCqNAkrh,search_key,page_int):
  nybBduxJYQjfpMHsLOUolgRCqNAkzW=[]
  nybBduxJYQjfpMHsLOUolgRCqNAkcE=nybBduxJYQjfpMHsLOUolgRCqNAkhc
  try:
   nybBduxJYQjfpMHsLOUolgRCqNAkch ='/api/search.json'
   nybBduxJYQjfpMHsLOUolgRCqNAkca={'query':search_key,'page':nybBduxJYQjfpMHsLOUolgRCqNAkhm(page_int),'per':nybBduxJYQjfpMHsLOUolgRCqNAkhm(nybBduxJYQjfpMHsLOUolgRCqNAkrh.SEARCH_LIMIT),'exclude':'limited'}
   nybBduxJYQjfpMHsLOUolgRCqNAkrE=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeurl(nybBduxJYQjfpMHsLOUolgRCqNAkrh.API_DOMAIN,nybBduxJYQjfpMHsLOUolgRCqNAkch)
   nybBduxJYQjfpMHsLOUolgRCqNAkrt=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeDefaultCookies()
   nybBduxJYQjfpMHsLOUolgRCqNAkrV=nybBduxJYQjfpMHsLOUolgRCqNAkrh.callRequestCookies('Get',nybBduxJYQjfpMHsLOUolgRCqNAkrE,payload=nybBduxJYQjfpMHsLOUolgRCqNAkhr,params=nybBduxJYQjfpMHsLOUolgRCqNAkca,headers=nybBduxJYQjfpMHsLOUolgRCqNAkhr,cookies=nybBduxJYQjfpMHsLOUolgRCqNAkrt)
   nybBduxJYQjfpMHsLOUolgRCqNAkcK=json.loads(nybBduxJYQjfpMHsLOUolgRCqNAkrV.text)
   if not('results' in nybBduxJYQjfpMHsLOUolgRCqNAkcK):return nybBduxJYQjfpMHsLOUolgRCqNAkzW,nybBduxJYQjfpMHsLOUolgRCqNAkcE
   nybBduxJYQjfpMHsLOUolgRCqNAkcm=nybBduxJYQjfpMHsLOUolgRCqNAkcK['results']
   nybBduxJYQjfpMHsLOUolgRCqNAkcE=nybBduxJYQjfpMHsLOUolgRCqNAkcK['meta']['has_next']
   for nybBduxJYQjfpMHsLOUolgRCqNAkcT in nybBduxJYQjfpMHsLOUolgRCqNAkcm:
    nybBduxJYQjfpMHsLOUolgRCqNAkcP =nybBduxJYQjfpMHsLOUolgRCqNAkcT['code']
    nybBduxJYQjfpMHsLOUolgRCqNAkcw=nybBduxJYQjfpMHsLOUolgRCqNAkcT['content_type']
    nybBduxJYQjfpMHsLOUolgRCqNAkcD =nybBduxJYQjfpMHsLOUolgRCqNAkcT['title']
    nybBduxJYQjfpMHsLOUolgRCqNAkcI =nybBduxJYQjfpMHsLOUolgRCqNAkcT['story']
    if nybBduxJYQjfpMHsLOUolgRCqNAkcT['thumbnail']!=nybBduxJYQjfpMHsLOUolgRCqNAkhr:
     nybBduxJYQjfpMHsLOUolgRCqNAkcv =nybBduxJYQjfpMHsLOUolgRCqNAkcT['thumbnail']['medium']
    else:
     nybBduxJYQjfpMHsLOUolgRCqNAkcv =nybBduxJYQjfpMHsLOUolgRCqNAkcT['stillcut']['medium']
    nybBduxJYQjfpMHsLOUolgRCqNAkcS =nybBduxJYQjfpMHsLOUolgRCqNAkcT['year']
    nybBduxJYQjfpMHsLOUolgRCqNAkcV =nybBduxJYQjfpMHsLOUolgRCqNAkcT['film_rating_code']
    nybBduxJYQjfpMHsLOUolgRCqNAkct=nybBduxJYQjfpMHsLOUolgRCqNAkcT['film_rating_short']
    nybBduxJYQjfpMHsLOUolgRCqNAkcG={}
    nybBduxJYQjfpMHsLOUolgRCqNAkcG['mpaa']=nybBduxJYQjfpMHsLOUolgRCqNAkcT['film_rating_long']
    nybBduxJYQjfpMHsLOUolgRCqNAkcG['year']=nybBduxJYQjfpMHsLOUolgRCqNAkcT['year']
    nybBduxJYQjfpMHsLOUolgRCqNAkcG['title']=nybBduxJYQjfpMHsLOUolgRCqNAkcT['title']
    if nybBduxJYQjfpMHsLOUolgRCqNAkcw=='movies':
     nybBduxJYQjfpMHsLOUolgRCqNAkcG['mediatype']='movie' 
     nybBduxJYQjfpMHsLOUolgRCqNAkcG['duration']=nybBduxJYQjfpMHsLOUolgRCqNAkcT['duration']
    else:
     nybBduxJYQjfpMHsLOUolgRCqNAkcG['mediatype']='episode' 
    nybBduxJYQjfpMHsLOUolgRCqNAkce={'code':nybBduxJYQjfpMHsLOUolgRCqNAkcP,'content_type':nybBduxJYQjfpMHsLOUolgRCqNAkcw,'title':nybBduxJYQjfpMHsLOUolgRCqNAkcD,'story':nybBduxJYQjfpMHsLOUolgRCqNAkcI,'thumbnail':nybBduxJYQjfpMHsLOUolgRCqNAkcv,'year':nybBduxJYQjfpMHsLOUolgRCqNAkcS,'film_rating_code':nybBduxJYQjfpMHsLOUolgRCqNAkcV,'film_rating_short':nybBduxJYQjfpMHsLOUolgRCqNAkct,'info':nybBduxJYQjfpMHsLOUolgRCqNAkcG}
    nybBduxJYQjfpMHsLOUolgRCqNAkzW.append(nybBduxJYQjfpMHsLOUolgRCqNAkce)
  except nybBduxJYQjfpMHsLOUolgRCqNAkhK as exception:
   nybBduxJYQjfpMHsLOUolgRCqNAkhT(exception)
  return nybBduxJYQjfpMHsLOUolgRCqNAkzW,nybBduxJYQjfpMHsLOUolgRCqNAkcE
 def GetProfilesList(nybBduxJYQjfpMHsLOUolgRCqNAkrh):
  nybBduxJYQjfpMHsLOUolgRCqNAkri=[]
  try:
   nybBduxJYQjfpMHsLOUolgRCqNAkch ='/manage_profiles'
   nybBduxJYQjfpMHsLOUolgRCqNAkrE=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeurl(nybBduxJYQjfpMHsLOUolgRCqNAkrh.API_DOMAIN,nybBduxJYQjfpMHsLOUolgRCqNAkch)
   nybBduxJYQjfpMHsLOUolgRCqNAkrt=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeDefaultCookies()
   nybBduxJYQjfpMHsLOUolgRCqNAkrV=nybBduxJYQjfpMHsLOUolgRCqNAkrh.callRequestCookies('Get',nybBduxJYQjfpMHsLOUolgRCqNAkrE,payload=nybBduxJYQjfpMHsLOUolgRCqNAkhr,params=nybBduxJYQjfpMHsLOUolgRCqNAkhr,headers=nybBduxJYQjfpMHsLOUolgRCqNAkhr,cookies=nybBduxJYQjfpMHsLOUolgRCqNAkrt)
   nybBduxJYQjfpMHsLOUolgRCqNAkzX=nybBduxJYQjfpMHsLOUolgRCqNAkrV.text
   nybBduxJYQjfpMHsLOUolgRCqNAkzF =re.findall('/api/users/me.{5000}',nybBduxJYQjfpMHsLOUolgRCqNAkzX)[0]
   nybBduxJYQjfpMHsLOUolgRCqNAkzF =nybBduxJYQjfpMHsLOUolgRCqNAkzF.replace('&quot;','')
   nybBduxJYQjfpMHsLOUolgRCqNAkri=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',nybBduxJYQjfpMHsLOUolgRCqNAkzF)
   for i in nybBduxJYQjfpMHsLOUolgRCqNAkhF(nybBduxJYQjfpMHsLOUolgRCqNAkhW(nybBduxJYQjfpMHsLOUolgRCqNAkri)):
    nybBduxJYQjfpMHsLOUolgRCqNAkze=nybBduxJYQjfpMHsLOUolgRCqNAkri[i]
    nybBduxJYQjfpMHsLOUolgRCqNAkze =nybBduxJYQjfpMHsLOUolgRCqNAkze.split(':')[1]
    nybBduxJYQjfpMHsLOUolgRCqNAkri[i]=nybBduxJYQjfpMHsLOUolgRCqNAkze.split(',')[0]
  except nybBduxJYQjfpMHsLOUolgRCqNAkhK as exception:
   nybBduxJYQjfpMHsLOUolgRCqNAkhT(exception)
  return nybBduxJYQjfpMHsLOUolgRCqNAkri
 def GetProfilesConvert(nybBduxJYQjfpMHsLOUolgRCqNAkrh,nybBduxJYQjfpMHsLOUolgRCqNAkrW):
  nybBduxJYQjfpMHsLOUolgRCqNAkzE=''
  nybBduxJYQjfpMHsLOUolgRCqNAkza=''
  try:
   nybBduxJYQjfpMHsLOUolgRCqNAkch ='/api/users/'+nybBduxJYQjfpMHsLOUolgRCqNAkrW+'/convert'
   nybBduxJYQjfpMHsLOUolgRCqNAkrE=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeurl(nybBduxJYQjfpMHsLOUolgRCqNAkrh.API_DOMAIN,nybBduxJYQjfpMHsLOUolgRCqNAkch)
   nybBduxJYQjfpMHsLOUolgRCqNAkrt=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeDefaultCookies()
   nybBduxJYQjfpMHsLOUolgRCqNAkrV=nybBduxJYQjfpMHsLOUolgRCqNAkrh.callRequestCookies('Put',nybBduxJYQjfpMHsLOUolgRCqNAkrE,payload=nybBduxJYQjfpMHsLOUolgRCqNAkhr,params=nybBduxJYQjfpMHsLOUolgRCqNAkhr,headers=nybBduxJYQjfpMHsLOUolgRCqNAkhr,cookies=nybBduxJYQjfpMHsLOUolgRCqNAkrt)
   for nybBduxJYQjfpMHsLOUolgRCqNAkrt in nybBduxJYQjfpMHsLOUolgRCqNAkrV.cookies:
    if nybBduxJYQjfpMHsLOUolgRCqNAkrt.name=='_s_guitv':
     nybBduxJYQjfpMHsLOUolgRCqNAkzP=nybBduxJYQjfpMHsLOUolgRCqNAkrt.value
    elif nybBduxJYQjfpMHsLOUolgRCqNAkrt.name=='_guinness-premium_session':
     nybBduxJYQjfpMHsLOUolgRCqNAkrG=nybBduxJYQjfpMHsLOUolgRCqNAkrt.value
   if nybBduxJYQjfpMHsLOUolgRCqNAkzP:
    nybBduxJYQjfpMHsLOUolgRCqNAkzE=nybBduxJYQjfpMHsLOUolgRCqNAkzP
   if nybBduxJYQjfpMHsLOUolgRCqNAkrG:
    nybBduxJYQjfpMHsLOUolgRCqNAkza=nybBduxJYQjfpMHsLOUolgRCqNAkrG
  except nybBduxJYQjfpMHsLOUolgRCqNAkhK as exception:
   nybBduxJYQjfpMHsLOUolgRCqNAkzE=''
   nybBduxJYQjfpMHsLOUolgRCqNAkza=''
  return nybBduxJYQjfpMHsLOUolgRCqNAkzE,nybBduxJYQjfpMHsLOUolgRCqNAkza
 def GetStreamingURL(nybBduxJYQjfpMHsLOUolgRCqNAkrh,movie_code,quality_str):
  nybBduxJYQjfpMHsLOUolgRCqNAkzw=nybBduxJYQjfpMHsLOUolgRCqNAkzI=nybBduxJYQjfpMHsLOUolgRCqNAkzG=''
  try:
   nybBduxJYQjfpMHsLOUolgRCqNAkch='/api/watch/'+movie_code+'.json'
   nybBduxJYQjfpMHsLOUolgRCqNAkrE=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeurl(nybBduxJYQjfpMHsLOUolgRCqNAkrh.API_DOMAIN,nybBduxJYQjfpMHsLOUolgRCqNAkch)
   nybBduxJYQjfpMHsLOUolgRCqNAkrS={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   nybBduxJYQjfpMHsLOUolgRCqNAkrt=nybBduxJYQjfpMHsLOUolgRCqNAkrh.makeDefaultCookies()
   nybBduxJYQjfpMHsLOUolgRCqNAkrV=nybBduxJYQjfpMHsLOUolgRCqNAkrh.callRequestCookies('Get',nybBduxJYQjfpMHsLOUolgRCqNAkrE,payload=nybBduxJYQjfpMHsLOUolgRCqNAkhr,params=nybBduxJYQjfpMHsLOUolgRCqNAkhr,headers=nybBduxJYQjfpMHsLOUolgRCqNAkrS,cookies=nybBduxJYQjfpMHsLOUolgRCqNAkrt)
   nybBduxJYQjfpMHsLOUolgRCqNAkcK=json.loads(nybBduxJYQjfpMHsLOUolgRCqNAkrV.text)
   nybBduxJYQjfpMHsLOUolgRCqNAkzw=nybBduxJYQjfpMHsLOUolgRCqNAkcK['streams'][0]['source']
   if nybBduxJYQjfpMHsLOUolgRCqNAkzw==nybBduxJYQjfpMHsLOUolgRCqNAkhr:return(nybBduxJYQjfpMHsLOUolgRCqNAkzw,nybBduxJYQjfpMHsLOUolgRCqNAkzI,nybBduxJYQjfpMHsLOUolgRCqNAkzG)
   if 'subtitles' in nybBduxJYQjfpMHsLOUolgRCqNAkcK['streams'][0]:
    for nybBduxJYQjfpMHsLOUolgRCqNAkzD in nybBduxJYQjfpMHsLOUolgRCqNAkcK['streams'][0]['subtitles']:
     if nybBduxJYQjfpMHsLOUolgRCqNAkzD['lang']=='ko':
      nybBduxJYQjfpMHsLOUolgRCqNAkzI=nybBduxJYQjfpMHsLOUolgRCqNAkzD['url']
      break
   nybBduxJYQjfpMHsLOUolgRCqNAkzv =nybBduxJYQjfpMHsLOUolgRCqNAkcK['ping_payload']
   nybBduxJYQjfpMHsLOUolgRCqNAkzS =nybBduxJYQjfpMHsLOUolgRCqNAkrh.WATCHA_USERCD
   nybBduxJYQjfpMHsLOUolgRCqNAkzV={'merchant':'giitd_frograms','sessionId':nybBduxJYQjfpMHsLOUolgRCqNAkzv,'userId':nybBduxJYQjfpMHsLOUolgRCqNAkzS}
   nybBduxJYQjfpMHsLOUolgRCqNAkzt=json.dumps(nybBduxJYQjfpMHsLOUolgRCqNAkzV,separators=(",",":")).encode('UTF-8')
   nybBduxJYQjfpMHsLOUolgRCqNAkzG=base64.b64encode(nybBduxJYQjfpMHsLOUolgRCqNAkzt)
  except nybBduxJYQjfpMHsLOUolgRCqNAkhK as exception:
   return(nybBduxJYQjfpMHsLOUolgRCqNAkzw,nybBduxJYQjfpMHsLOUolgRCqNAkzI,nybBduxJYQjfpMHsLOUolgRCqNAkzG)
  return(nybBduxJYQjfpMHsLOUolgRCqNAkzw,nybBduxJYQjfpMHsLOUolgRCqNAkzI,nybBduxJYQjfpMHsLOUolgRCqNAkzG) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
