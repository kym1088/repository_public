__author__="NightRain"
zFJyYbUPjMQkDuItWOdlwNeasSvfxV=object
zFJyYbUPjMQkDuItWOdlwNeasSvfqL=None
zFJyYbUPjMQkDuItWOdlwNeasSvfqi=False
zFJyYbUPjMQkDuItWOdlwNeasSvfqx=True
zFJyYbUPjMQkDuItWOdlwNeasSvfqG=Exception
zFJyYbUPjMQkDuItWOdlwNeasSvfqp=str
zFJyYbUPjMQkDuItWOdlwNeasSvfqC=print
zFJyYbUPjMQkDuItWOdlwNeasSvfqc=len
zFJyYbUPjMQkDuItWOdlwNeasSvfqA=int
zFJyYbUPjMQkDuItWOdlwNeasSvfqo=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import base64
import requests
zFJyYbUPjMQkDuItWOdlwNeasSvfLx='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
class zFJyYbUPjMQkDuItWOdlwNeasSvfLi(zFJyYbUPjMQkDuItWOdlwNeasSvfxV):
 def __init__(zFJyYbUPjMQkDuItWOdlwNeasSvfLq):
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_TOKEN ='' 
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUIT =''
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUITV =''
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_USERCD=''
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.API_DOMAIN ='https://play.watcha.net'
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.EPISODE_LIMIT=20
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.SEARCH_LIMIT =30
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.DEFAULT_HEADER={'user-agent':zFJyYbUPjMQkDuItWOdlwNeasSvfLx,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,jobtype,zFJyYbUPjMQkDuItWOdlwNeasSvfLX,payload=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,params=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,cookies=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,redirects=zFJyYbUPjMQkDuItWOdlwNeasSvfqi):
  zFJyYbUPjMQkDuItWOdlwNeasSvfLG=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.DEFAULT_HEADER
  if headers:zFJyYbUPjMQkDuItWOdlwNeasSvfLG.update(headers)
  if jobtype=='Get':
   zFJyYbUPjMQkDuItWOdlwNeasSvfLp=requests.get(zFJyYbUPjMQkDuItWOdlwNeasSvfLX,params=params,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfLG,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   zFJyYbUPjMQkDuItWOdlwNeasSvfLp=requests.put(zFJyYbUPjMQkDuItWOdlwNeasSvfLX,data=payload,params=params,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfLG,cookies=cookies,allow_redirects=redirects)
  else:
   zFJyYbUPjMQkDuItWOdlwNeasSvfLp=requests.post(zFJyYbUPjMQkDuItWOdlwNeasSvfLX,data=payload,params=params,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfLG,cookies=cookies,allow_redirects=redirects)
  return zFJyYbUPjMQkDuItWOdlwNeasSvfLp
 def SaveCredential(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,zFJyYbUPjMQkDuItWOdlwNeasSvfLC):
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_TOKEN =zFJyYbUPjMQkDuItWOdlwNeasSvfLC.get('watcha_token')
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUIT =zFJyYbUPjMQkDuItWOdlwNeasSvfLC.get('watcha_guit')
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUITV =zFJyYbUPjMQkDuItWOdlwNeasSvfLC.get('watcha_guitv')
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_USERCD =zFJyYbUPjMQkDuItWOdlwNeasSvfLC.get('watcha_usercd')
 def SaveCredential_usercd(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,zFJyYbUPjMQkDuItWOdlwNeasSvfLc):
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_USERCD=zFJyYbUPjMQkDuItWOdlwNeasSvfLc
 def SaveCredential_guitv(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,zFJyYbUPjMQkDuItWOdlwNeasSvfLA,zFJyYbUPjMQkDuItWOdlwNeasSvfLo):
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUITV=zFJyYbUPjMQkDuItWOdlwNeasSvfLA
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_TOKEN=zFJyYbUPjMQkDuItWOdlwNeasSvfLo 
 def ClearCredential(zFJyYbUPjMQkDuItWOdlwNeasSvfLq):
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_TOKEN ='' 
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUIT =''
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUITV =''
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_USERCD=''
 def LoadCredential(zFJyYbUPjMQkDuItWOdlwNeasSvfLq):
  zFJyYbUPjMQkDuItWOdlwNeasSvfLC={'watcha_token':zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_TOKEN,'watcha_guit':zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUIT,'watcha_guitv':zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUITV,'watcha_usercd':zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_USERCD}
  return zFJyYbUPjMQkDuItWOdlwNeasSvfLC
 def makeDefaultCookies(zFJyYbUPjMQkDuItWOdlwNeasSvfLq):
  zFJyYbUPjMQkDuItWOdlwNeasSvfLT={'_s_guit':zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUIT,'_guinness-premium_session':zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_TOKEN}
  if zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUITV:
   zFJyYbUPjMQkDuItWOdlwNeasSvfLT['_s_guitv']=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_GUITV
  return zFJyYbUPjMQkDuItWOdlwNeasSvfLT
 def makeurl(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,domain,path,query1=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,query2=zFJyYbUPjMQkDuItWOdlwNeasSvfqL):
  zFJyYbUPjMQkDuItWOdlwNeasSvfLX=domain+path
  if query1:
   zFJyYbUPjMQkDuItWOdlwNeasSvfLX+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   zFJyYbUPjMQkDuItWOdlwNeasSvfLX+='&%s'%urllib.parse.urlencode(query2)
  return zFJyYbUPjMQkDuItWOdlwNeasSvfLX
 def GetCredential(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,user_id,user_pw,user_pf):
  zFJyYbUPjMQkDuItWOdlwNeasSvfLm=zFJyYbUPjMQkDuItWOdlwNeasSvfqi
  zFJyYbUPjMQkDuItWOdlwNeasSvfLr=zFJyYbUPjMQkDuItWOdlwNeasSvfLK='-'
  try:
   zFJyYbUPjMQkDuItWOdlwNeasSvfLh=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.API_DOMAIN+'/api/session'
   zFJyYbUPjMQkDuItWOdlwNeasSvfLH={'email':user_id,'password':user_pw}
   zFJyYbUPjMQkDuItWOdlwNeasSvfLg={'accept':'application/vnd.frograms+json;version=4'}
   zFJyYbUPjMQkDuItWOdlwNeasSvfLE=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.callRequestCookies('Post',zFJyYbUPjMQkDuItWOdlwNeasSvfLh,payload=zFJyYbUPjMQkDuItWOdlwNeasSvfLH,params=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfLg,cookies=zFJyYbUPjMQkDuItWOdlwNeasSvfqL)
   for zFJyYbUPjMQkDuItWOdlwNeasSvfLB in zFJyYbUPjMQkDuItWOdlwNeasSvfLE.cookies:
    if zFJyYbUPjMQkDuItWOdlwNeasSvfLB.name=='_guinness-premium_session':
     zFJyYbUPjMQkDuItWOdlwNeasSvfLK=zFJyYbUPjMQkDuItWOdlwNeasSvfLB.value
    elif zFJyYbUPjMQkDuItWOdlwNeasSvfLB.name=='_s_guit':
     zFJyYbUPjMQkDuItWOdlwNeasSvfLr=zFJyYbUPjMQkDuItWOdlwNeasSvfLB.value
   if zFJyYbUPjMQkDuItWOdlwNeasSvfLK:zFJyYbUPjMQkDuItWOdlwNeasSvfLm=zFJyYbUPjMQkDuItWOdlwNeasSvfqx
  except zFJyYbUPjMQkDuItWOdlwNeasSvfqG as exception:
   zFJyYbUPjMQkDuItWOdlwNeasSvfLr=zFJyYbUPjMQkDuItWOdlwNeasSvfLK='' 
  zFJyYbUPjMQkDuItWOdlwNeasSvfLC={'watcha_guit':zFJyYbUPjMQkDuItWOdlwNeasSvfLr,'watcha_token':zFJyYbUPjMQkDuItWOdlwNeasSvfLK,'watcha_guitv':'','watcha_usercd':''}
  zFJyYbUPjMQkDuItWOdlwNeasSvfLq.SaveCredential(zFJyYbUPjMQkDuItWOdlwNeasSvfLC)
  try:
   zFJyYbUPjMQkDuItWOdlwNeasSvfLV=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.GetProfilesList()
   zFJyYbUPjMQkDuItWOdlwNeasSvfiL =zFJyYbUPjMQkDuItWOdlwNeasSvfLV[user_pf]
   zFJyYbUPjMQkDuItWOdlwNeasSvfLq.SaveCredential_usercd(zFJyYbUPjMQkDuItWOdlwNeasSvfiL)
  except zFJyYbUPjMQkDuItWOdlwNeasSvfqG as exception:
   zFJyYbUPjMQkDuItWOdlwNeasSvfLq.ClearCredential()
   return zFJyYbUPjMQkDuItWOdlwNeasSvfqi
  if user_pf!=0:
   zFJyYbUPjMQkDuItWOdlwNeasSvfLA,zFJyYbUPjMQkDuItWOdlwNeasSvfLo=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.GetProfilesConvert(zFJyYbUPjMQkDuItWOdlwNeasSvfiL)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLq.SaveCredential_guitv(zFJyYbUPjMQkDuItWOdlwNeasSvfLA,zFJyYbUPjMQkDuItWOdlwNeasSvfLo)
  return zFJyYbUPjMQkDuItWOdlwNeasSvfLm
 def GetSubGroupList(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,stype):
  zFJyYbUPjMQkDuItWOdlwNeasSvfix=[]
  try:
   zFJyYbUPjMQkDuItWOdlwNeasSvfiq ='/api/categories.json'
   zFJyYbUPjMQkDuItWOdlwNeasSvfLX=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeurl(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.API_DOMAIN,zFJyYbUPjMQkDuItWOdlwNeasSvfiq)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLB=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeDefaultCookies()
   zFJyYbUPjMQkDuItWOdlwNeasSvfLE=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.callRequestCookies('Get',zFJyYbUPjMQkDuItWOdlwNeasSvfLX,payload=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,params=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,cookies=zFJyYbUPjMQkDuItWOdlwNeasSvfLB)
   zFJyYbUPjMQkDuItWOdlwNeasSvfiG=json.loads(zFJyYbUPjMQkDuItWOdlwNeasSvfLE.text)
   if not('genres' in zFJyYbUPjMQkDuItWOdlwNeasSvfiG):return zFJyYbUPjMQkDuItWOdlwNeasSvfix
   if stype=='genres':
    zFJyYbUPjMQkDuItWOdlwNeasSvfip=zFJyYbUPjMQkDuItWOdlwNeasSvfiG['genres']
   else:
    zFJyYbUPjMQkDuItWOdlwNeasSvfip=zFJyYbUPjMQkDuItWOdlwNeasSvfiG['tags']
   for zFJyYbUPjMQkDuItWOdlwNeasSvfiC in zFJyYbUPjMQkDuItWOdlwNeasSvfip:
    zFJyYbUPjMQkDuItWOdlwNeasSvfic=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['name']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiA =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['api_path']
    zFJyYbUPjMQkDuItWOdlwNeasSvfio =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['entity']['id']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiT={'group_name':zFJyYbUPjMQkDuItWOdlwNeasSvfic,'api_path':zFJyYbUPjMQkDuItWOdlwNeasSvfiA,'tag_id':zFJyYbUPjMQkDuItWOdlwNeasSvfqp(zFJyYbUPjMQkDuItWOdlwNeasSvfio)}
    zFJyYbUPjMQkDuItWOdlwNeasSvfix.append(zFJyYbUPjMQkDuItWOdlwNeasSvfiT)
  except zFJyYbUPjMQkDuItWOdlwNeasSvfqG as exception:
   zFJyYbUPjMQkDuItWOdlwNeasSvfqC(exception)
  return zFJyYbUPjMQkDuItWOdlwNeasSvfix
 def GetCategoryList(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,stype,zFJyYbUPjMQkDuItWOdlwNeasSvfio,zFJyYbUPjMQkDuItWOdlwNeasSvfiA,page_int,in_sort):
  zFJyYbUPjMQkDuItWOdlwNeasSvfix=[]
  zFJyYbUPjMQkDuItWOdlwNeasSvfiX=zFJyYbUPjMQkDuItWOdlwNeasSvfqi
  zFJyYbUPjMQkDuItWOdlwNeasSvfin={}
  try:
   if 'categories' in zFJyYbUPjMQkDuItWOdlwNeasSvfiA:
    zFJyYbUPjMQkDuItWOdlwNeasSvfiq ='/api/categories/contents.json'
    if stype=='genres':
     zFJyYbUPjMQkDuItWOdlwNeasSvfin['genre']=zFJyYbUPjMQkDuItWOdlwNeasSvfio
    else:
     zFJyYbUPjMQkDuItWOdlwNeasSvfin['tag'] =zFJyYbUPjMQkDuItWOdlwNeasSvfio
    zFJyYbUPjMQkDuItWOdlwNeasSvfin['order']=in_sort 
    if page_int>1:
     zFJyYbUPjMQkDuItWOdlwNeasSvfin['page']=zFJyYbUPjMQkDuItWOdlwNeasSvfqp(page_int-1)
   else: 
    zFJyYbUPjMQkDuItWOdlwNeasSvfiq ='/api/'+zFJyYbUPjMQkDuItWOdlwNeasSvfiA+'.json'
    if page_int>1:
     zFJyYbUPjMQkDuItWOdlwNeasSvfin['page']=zFJyYbUPjMQkDuItWOdlwNeasSvfqp(page_int)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLX=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeurl(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.API_DOMAIN,zFJyYbUPjMQkDuItWOdlwNeasSvfiq)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLB=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeDefaultCookies()
   zFJyYbUPjMQkDuItWOdlwNeasSvfLE=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.callRequestCookies('Get',zFJyYbUPjMQkDuItWOdlwNeasSvfLX,payload=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,params=zFJyYbUPjMQkDuItWOdlwNeasSvfin,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,cookies=zFJyYbUPjMQkDuItWOdlwNeasSvfLB)
   zFJyYbUPjMQkDuItWOdlwNeasSvfiG=json.loads(zFJyYbUPjMQkDuItWOdlwNeasSvfLE.text)
   if not('contents' in zFJyYbUPjMQkDuItWOdlwNeasSvfiG):return zFJyYbUPjMQkDuItWOdlwNeasSvfix,zFJyYbUPjMQkDuItWOdlwNeasSvfiX
   zFJyYbUPjMQkDuItWOdlwNeasSvfip=zFJyYbUPjMQkDuItWOdlwNeasSvfiG['contents']
   zFJyYbUPjMQkDuItWOdlwNeasSvfiX=zFJyYbUPjMQkDuItWOdlwNeasSvfiG['meta']['has_next']
   for zFJyYbUPjMQkDuItWOdlwNeasSvfiC in zFJyYbUPjMQkDuItWOdlwNeasSvfip:
    zFJyYbUPjMQkDuItWOdlwNeasSvfiR =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['code']
    zFJyYbUPjMQkDuItWOdlwNeasSvfim=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['content_type']
    zFJyYbUPjMQkDuItWOdlwNeasSvfir =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['title']
    zFJyYbUPjMQkDuItWOdlwNeasSvfih =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['story']
    if zFJyYbUPjMQkDuItWOdlwNeasSvfiC['thumbnail']!=zFJyYbUPjMQkDuItWOdlwNeasSvfqL:
     zFJyYbUPjMQkDuItWOdlwNeasSvfiH =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['thumbnail']['medium']
    else:
     zFJyYbUPjMQkDuItWOdlwNeasSvfiH =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['stillcut']['medium']
    zFJyYbUPjMQkDuItWOdlwNeasSvfig =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['year']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiE =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['film_rating_code']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiB=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['film_rating_short']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK={}
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK['mpaa']=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['film_rating_long']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK['year']=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['year']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK['title']=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['title']
    if zFJyYbUPjMQkDuItWOdlwNeasSvfim=='movies':
     zFJyYbUPjMQkDuItWOdlwNeasSvfiK['mediatype']='movie' 
     zFJyYbUPjMQkDuItWOdlwNeasSvfiK['duration']=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['duration']
    else:
     zFJyYbUPjMQkDuItWOdlwNeasSvfiK['mediatype']='episode' 
    zFJyYbUPjMQkDuItWOdlwNeasSvfiT={'code':zFJyYbUPjMQkDuItWOdlwNeasSvfiR,'content_type':zFJyYbUPjMQkDuItWOdlwNeasSvfim,'title':zFJyYbUPjMQkDuItWOdlwNeasSvfir,'story':zFJyYbUPjMQkDuItWOdlwNeasSvfih,'thumbnail':zFJyYbUPjMQkDuItWOdlwNeasSvfiH,'year':zFJyYbUPjMQkDuItWOdlwNeasSvfig,'film_rating_code':zFJyYbUPjMQkDuItWOdlwNeasSvfiE,'film_rating_short':zFJyYbUPjMQkDuItWOdlwNeasSvfiB,'info':zFJyYbUPjMQkDuItWOdlwNeasSvfiK}
    zFJyYbUPjMQkDuItWOdlwNeasSvfix.append(zFJyYbUPjMQkDuItWOdlwNeasSvfiT)
  except zFJyYbUPjMQkDuItWOdlwNeasSvfqG as exception:
   zFJyYbUPjMQkDuItWOdlwNeasSvfqC(exception)
  return zFJyYbUPjMQkDuItWOdlwNeasSvfix,zFJyYbUPjMQkDuItWOdlwNeasSvfiX
 def GetCategoryList_morepage(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,stype,zFJyYbUPjMQkDuItWOdlwNeasSvfio,zFJyYbUPjMQkDuItWOdlwNeasSvfiA,page_int,in_sort):
  zFJyYbUPjMQkDuItWOdlwNeasSvfiX=zFJyYbUPjMQkDuItWOdlwNeasSvfqi
  if not('categories' in zFJyYbUPjMQkDuItWOdlwNeasSvfiA):return zFJyYbUPjMQkDuItWOdlwNeasSvfqx
  try:
   zFJyYbUPjMQkDuItWOdlwNeasSvfiq ='/api/categories/contents.json'
   zFJyYbUPjMQkDuItWOdlwNeasSvfin={}
   if stype=='genres':
    zFJyYbUPjMQkDuItWOdlwNeasSvfin['genre']=zFJyYbUPjMQkDuItWOdlwNeasSvfio
   else:
    zFJyYbUPjMQkDuItWOdlwNeasSvfin['tag'] =zFJyYbUPjMQkDuItWOdlwNeasSvfio
   zFJyYbUPjMQkDuItWOdlwNeasSvfin['order']=in_sort 
   if page_int>1:
    zFJyYbUPjMQkDuItWOdlwNeasSvfin['page']=zFJyYbUPjMQkDuItWOdlwNeasSvfqp(page_int-1)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLX=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeurl(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.API_DOMAIN,zFJyYbUPjMQkDuItWOdlwNeasSvfiq)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLB=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeDefaultCookies()
   zFJyYbUPjMQkDuItWOdlwNeasSvfLE=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.callRequestCookies('Get',zFJyYbUPjMQkDuItWOdlwNeasSvfLX,payload=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,params=zFJyYbUPjMQkDuItWOdlwNeasSvfin,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,cookies=zFJyYbUPjMQkDuItWOdlwNeasSvfLB)
   zFJyYbUPjMQkDuItWOdlwNeasSvfiG=json.loads(zFJyYbUPjMQkDuItWOdlwNeasSvfLE.text)
   zFJyYbUPjMQkDuItWOdlwNeasSvfiX=zFJyYbUPjMQkDuItWOdlwNeasSvfiG['meta']['has_next']
  except zFJyYbUPjMQkDuItWOdlwNeasSvfqG as exception:
   zFJyYbUPjMQkDuItWOdlwNeasSvfqC(exception)
  return zFJyYbUPjMQkDuItWOdlwNeasSvfiX
 def GetEpisodoList(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,program_code,page_int,orderby='asc'):
  zFJyYbUPjMQkDuItWOdlwNeasSvfix=[]
  zFJyYbUPjMQkDuItWOdlwNeasSvfiX=zFJyYbUPjMQkDuItWOdlwNeasSvfqi
  zFJyYbUPjMQkDuItWOdlwNeasSvfiV=''
  try:
   zFJyYbUPjMQkDuItWOdlwNeasSvfiq ='/api/contents/'+program_code+'/tv_episodes.json'
   zFJyYbUPjMQkDuItWOdlwNeasSvfin={'all':'true'}
   zFJyYbUPjMQkDuItWOdlwNeasSvfLX=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeurl(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.API_DOMAIN,zFJyYbUPjMQkDuItWOdlwNeasSvfiq)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLB=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeDefaultCookies()
   zFJyYbUPjMQkDuItWOdlwNeasSvfLE=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.callRequestCookies('Get',zFJyYbUPjMQkDuItWOdlwNeasSvfLX,payload=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,params=zFJyYbUPjMQkDuItWOdlwNeasSvfin,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,cookies=zFJyYbUPjMQkDuItWOdlwNeasSvfLB)
   zFJyYbUPjMQkDuItWOdlwNeasSvfiG=json.loads(zFJyYbUPjMQkDuItWOdlwNeasSvfLE.text)
   if not('tv_episode_codes' in zFJyYbUPjMQkDuItWOdlwNeasSvfiG):return zFJyYbUPjMQkDuItWOdlwNeasSvfix,zFJyYbUPjMQkDuItWOdlwNeasSvfiX
   zFJyYbUPjMQkDuItWOdlwNeasSvfip=zFJyYbUPjMQkDuItWOdlwNeasSvfiG['tv_episode_codes']
   zFJyYbUPjMQkDuItWOdlwNeasSvfxL=zFJyYbUPjMQkDuItWOdlwNeasSvfqc(zFJyYbUPjMQkDuItWOdlwNeasSvfip)
   zFJyYbUPjMQkDuItWOdlwNeasSvfxi =zFJyYbUPjMQkDuItWOdlwNeasSvfqA(zFJyYbUPjMQkDuItWOdlwNeasSvfxL//(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    zFJyYbUPjMQkDuItWOdlwNeasSvfxq =(zFJyYbUPjMQkDuItWOdlwNeasSvfxL-1)-((page_int-1)*zFJyYbUPjMQkDuItWOdlwNeasSvfLq.EPISODE_LIMIT)
   else:
    zFJyYbUPjMQkDuItWOdlwNeasSvfxq =(page_int-1)*zFJyYbUPjMQkDuItWOdlwNeasSvfLq.EPISODE_LIMIT
   for i in zFJyYbUPjMQkDuItWOdlwNeasSvfqo(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.EPISODE_LIMIT):
    if orderby=='desc':
     zFJyYbUPjMQkDuItWOdlwNeasSvfxG=zFJyYbUPjMQkDuItWOdlwNeasSvfxq-i
     if zFJyYbUPjMQkDuItWOdlwNeasSvfxG<0:break
    else:
     zFJyYbUPjMQkDuItWOdlwNeasSvfxG=zFJyYbUPjMQkDuItWOdlwNeasSvfxq+i
     if zFJyYbUPjMQkDuItWOdlwNeasSvfxG>=zFJyYbUPjMQkDuItWOdlwNeasSvfxL:break
    if zFJyYbUPjMQkDuItWOdlwNeasSvfiV!='':zFJyYbUPjMQkDuItWOdlwNeasSvfiV+=','
    zFJyYbUPjMQkDuItWOdlwNeasSvfiV+=zFJyYbUPjMQkDuItWOdlwNeasSvfip[zFJyYbUPjMQkDuItWOdlwNeasSvfxG]
   if zFJyYbUPjMQkDuItWOdlwNeasSvfxi>page_int:zFJyYbUPjMQkDuItWOdlwNeasSvfiX=zFJyYbUPjMQkDuItWOdlwNeasSvfqx
  except zFJyYbUPjMQkDuItWOdlwNeasSvfqG as exception:
   zFJyYbUPjMQkDuItWOdlwNeasSvfqC(exception)
  try:
   zFJyYbUPjMQkDuItWOdlwNeasSvfin={'codes':zFJyYbUPjMQkDuItWOdlwNeasSvfiV}
   zFJyYbUPjMQkDuItWOdlwNeasSvfLX=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeurl(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.API_DOMAIN,zFJyYbUPjMQkDuItWOdlwNeasSvfiq)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLB=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeDefaultCookies()
   zFJyYbUPjMQkDuItWOdlwNeasSvfLE=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.callRequestCookies('Get',zFJyYbUPjMQkDuItWOdlwNeasSvfLX,payload=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,params=zFJyYbUPjMQkDuItWOdlwNeasSvfin,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,cookies=zFJyYbUPjMQkDuItWOdlwNeasSvfLB)
   zFJyYbUPjMQkDuItWOdlwNeasSvfiG=json.loads(zFJyYbUPjMQkDuItWOdlwNeasSvfLE.text)
   if not('tv_episodes' in zFJyYbUPjMQkDuItWOdlwNeasSvfiG):return zFJyYbUPjMQkDuItWOdlwNeasSvfix
   zFJyYbUPjMQkDuItWOdlwNeasSvfip=zFJyYbUPjMQkDuItWOdlwNeasSvfiG['tv_episodes']
   for zFJyYbUPjMQkDuItWOdlwNeasSvfiC in zFJyYbUPjMQkDuItWOdlwNeasSvfip:
    zFJyYbUPjMQkDuItWOdlwNeasSvfiR =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['code']
    if zFJyYbUPjMQkDuItWOdlwNeasSvfiC['title']:
     zFJyYbUPjMQkDuItWOdlwNeasSvfir =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['title']
    else:
     zFJyYbUPjMQkDuItWOdlwNeasSvfir =''
    zFJyYbUPjMQkDuItWOdlwNeasSvfiH =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['stillcut']['medium']
    zFJyYbUPjMQkDuItWOdlwNeasSvfxp =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['display_number']
    zFJyYbUPjMQkDuItWOdlwNeasSvfxC=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['tv_season_title']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK={}
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK['mediatype'] ='episode'
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK['tvshowtitle']=zFJyYbUPjMQkDuItWOdlwNeasSvfir if zFJyYbUPjMQkDuItWOdlwNeasSvfir else zFJyYbUPjMQkDuItWOdlwNeasSvfxC
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK['title'] ='%s %s'%(zFJyYbUPjMQkDuItWOdlwNeasSvfxC,zFJyYbUPjMQkDuItWOdlwNeasSvfxp)if zFJyYbUPjMQkDuItWOdlwNeasSvfir else zFJyYbUPjMQkDuItWOdlwNeasSvfxp
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK['duration'] =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['duration']
    try:
     zFJyYbUPjMQkDuItWOdlwNeasSvfiK['episode']=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['episode_number']
    except:
     zFJyYbUPjMQkDuItWOdlwNeasSvfqL
    zFJyYbUPjMQkDuItWOdlwNeasSvfiT={'code':zFJyYbUPjMQkDuItWOdlwNeasSvfiR,'title':zFJyYbUPjMQkDuItWOdlwNeasSvfir,'thumbnail':zFJyYbUPjMQkDuItWOdlwNeasSvfiH,'display_num':zFJyYbUPjMQkDuItWOdlwNeasSvfxp,'season_title':zFJyYbUPjMQkDuItWOdlwNeasSvfxC,'info':zFJyYbUPjMQkDuItWOdlwNeasSvfiK}
    zFJyYbUPjMQkDuItWOdlwNeasSvfix.append(zFJyYbUPjMQkDuItWOdlwNeasSvfiT)
  except zFJyYbUPjMQkDuItWOdlwNeasSvfqG as exception:
   zFJyYbUPjMQkDuItWOdlwNeasSvfqC(exception)
  return zFJyYbUPjMQkDuItWOdlwNeasSvfix,zFJyYbUPjMQkDuItWOdlwNeasSvfiX
 def GetSearchList(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,search_key,page_int):
  zFJyYbUPjMQkDuItWOdlwNeasSvfxc=[]
  zFJyYbUPjMQkDuItWOdlwNeasSvfiX=zFJyYbUPjMQkDuItWOdlwNeasSvfqi
  try:
   zFJyYbUPjMQkDuItWOdlwNeasSvfiq ='/api/search.json'
   zFJyYbUPjMQkDuItWOdlwNeasSvfin={'query':search_key,'page':zFJyYbUPjMQkDuItWOdlwNeasSvfqp(page_int),'per':zFJyYbUPjMQkDuItWOdlwNeasSvfqp(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.SEARCH_LIMIT),'exclude':'limited'}
   zFJyYbUPjMQkDuItWOdlwNeasSvfLX=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeurl(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.API_DOMAIN,zFJyYbUPjMQkDuItWOdlwNeasSvfiq)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLB=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeDefaultCookies()
   zFJyYbUPjMQkDuItWOdlwNeasSvfLE=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.callRequestCookies('Get',zFJyYbUPjMQkDuItWOdlwNeasSvfLX,payload=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,params=zFJyYbUPjMQkDuItWOdlwNeasSvfin,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,cookies=zFJyYbUPjMQkDuItWOdlwNeasSvfLB)
   zFJyYbUPjMQkDuItWOdlwNeasSvfiG=json.loads(zFJyYbUPjMQkDuItWOdlwNeasSvfLE.text)
   if not('results' in zFJyYbUPjMQkDuItWOdlwNeasSvfiG):return zFJyYbUPjMQkDuItWOdlwNeasSvfxc,zFJyYbUPjMQkDuItWOdlwNeasSvfiX
   zFJyYbUPjMQkDuItWOdlwNeasSvfip=zFJyYbUPjMQkDuItWOdlwNeasSvfiG['results']
   zFJyYbUPjMQkDuItWOdlwNeasSvfiX=zFJyYbUPjMQkDuItWOdlwNeasSvfiG['meta']['has_next']
   for zFJyYbUPjMQkDuItWOdlwNeasSvfiC in zFJyYbUPjMQkDuItWOdlwNeasSvfip:
    zFJyYbUPjMQkDuItWOdlwNeasSvfiR =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['code']
    zFJyYbUPjMQkDuItWOdlwNeasSvfim=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['content_type']
    zFJyYbUPjMQkDuItWOdlwNeasSvfir =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['title']
    zFJyYbUPjMQkDuItWOdlwNeasSvfih =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['story']
    if zFJyYbUPjMQkDuItWOdlwNeasSvfiC['thumbnail']!=zFJyYbUPjMQkDuItWOdlwNeasSvfqL:
     zFJyYbUPjMQkDuItWOdlwNeasSvfiH =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['thumbnail']['medium']
    else:
     zFJyYbUPjMQkDuItWOdlwNeasSvfiH =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['stillcut']['medium']
    zFJyYbUPjMQkDuItWOdlwNeasSvfig =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['year']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiE =zFJyYbUPjMQkDuItWOdlwNeasSvfiC['film_rating_code']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiB=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['film_rating_short']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK={}
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK['mpaa']=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['film_rating_long']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK['year']=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['year']
    zFJyYbUPjMQkDuItWOdlwNeasSvfiK['title']=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['title']
    if zFJyYbUPjMQkDuItWOdlwNeasSvfim=='movies':
     zFJyYbUPjMQkDuItWOdlwNeasSvfiK['mediatype']='movie' 
     zFJyYbUPjMQkDuItWOdlwNeasSvfiK['duration']=zFJyYbUPjMQkDuItWOdlwNeasSvfiC['duration']
    else:
     zFJyYbUPjMQkDuItWOdlwNeasSvfiK['mediatype']='episode' 
    zFJyYbUPjMQkDuItWOdlwNeasSvfiT={'code':zFJyYbUPjMQkDuItWOdlwNeasSvfiR,'content_type':zFJyYbUPjMQkDuItWOdlwNeasSvfim,'title':zFJyYbUPjMQkDuItWOdlwNeasSvfir,'story':zFJyYbUPjMQkDuItWOdlwNeasSvfih,'thumbnail':zFJyYbUPjMQkDuItWOdlwNeasSvfiH,'year':zFJyYbUPjMQkDuItWOdlwNeasSvfig,'film_rating_code':zFJyYbUPjMQkDuItWOdlwNeasSvfiE,'film_rating_short':zFJyYbUPjMQkDuItWOdlwNeasSvfiB,'info':zFJyYbUPjMQkDuItWOdlwNeasSvfiK}
    zFJyYbUPjMQkDuItWOdlwNeasSvfxc.append(zFJyYbUPjMQkDuItWOdlwNeasSvfiT)
  except zFJyYbUPjMQkDuItWOdlwNeasSvfqG as exception:
   zFJyYbUPjMQkDuItWOdlwNeasSvfqC(exception)
  return zFJyYbUPjMQkDuItWOdlwNeasSvfxc,zFJyYbUPjMQkDuItWOdlwNeasSvfiX
 def GetProfilesList(zFJyYbUPjMQkDuItWOdlwNeasSvfLq):
  zFJyYbUPjMQkDuItWOdlwNeasSvfLV=[]
  try:
   zFJyYbUPjMQkDuItWOdlwNeasSvfiq ='/manage_profiles'
   zFJyYbUPjMQkDuItWOdlwNeasSvfLX=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeurl(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.API_DOMAIN,zFJyYbUPjMQkDuItWOdlwNeasSvfiq)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLB=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeDefaultCookies()
   zFJyYbUPjMQkDuItWOdlwNeasSvfLE=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.callRequestCookies('Get',zFJyYbUPjMQkDuItWOdlwNeasSvfLX,payload=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,params=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,cookies=zFJyYbUPjMQkDuItWOdlwNeasSvfLB)
   zFJyYbUPjMQkDuItWOdlwNeasSvfxA=zFJyYbUPjMQkDuItWOdlwNeasSvfLE.text
   zFJyYbUPjMQkDuItWOdlwNeasSvfxo =re.findall('/api/users/me.{5000}',zFJyYbUPjMQkDuItWOdlwNeasSvfxA)[0]
   zFJyYbUPjMQkDuItWOdlwNeasSvfxo =zFJyYbUPjMQkDuItWOdlwNeasSvfxo.replace('&quot;','')
   zFJyYbUPjMQkDuItWOdlwNeasSvfLV=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',zFJyYbUPjMQkDuItWOdlwNeasSvfxo)
   for i in zFJyYbUPjMQkDuItWOdlwNeasSvfqo(zFJyYbUPjMQkDuItWOdlwNeasSvfqc(zFJyYbUPjMQkDuItWOdlwNeasSvfLV)):
    zFJyYbUPjMQkDuItWOdlwNeasSvfxT=zFJyYbUPjMQkDuItWOdlwNeasSvfLV[i]
    zFJyYbUPjMQkDuItWOdlwNeasSvfxT =zFJyYbUPjMQkDuItWOdlwNeasSvfxT.split(':')[1]
    zFJyYbUPjMQkDuItWOdlwNeasSvfLV[i]=zFJyYbUPjMQkDuItWOdlwNeasSvfxT.split(',')[0]
  except zFJyYbUPjMQkDuItWOdlwNeasSvfqG as exception:
   zFJyYbUPjMQkDuItWOdlwNeasSvfqC(exception)
  return zFJyYbUPjMQkDuItWOdlwNeasSvfLV
 def GetProfilesConvert(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,zFJyYbUPjMQkDuItWOdlwNeasSvfLc):
  zFJyYbUPjMQkDuItWOdlwNeasSvfxX=''
  zFJyYbUPjMQkDuItWOdlwNeasSvfxn=''
  try:
   zFJyYbUPjMQkDuItWOdlwNeasSvfiq ='/api/users/'+zFJyYbUPjMQkDuItWOdlwNeasSvfLc+'/convert'
   zFJyYbUPjMQkDuItWOdlwNeasSvfLX=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeurl(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.API_DOMAIN,zFJyYbUPjMQkDuItWOdlwNeasSvfiq)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLB=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeDefaultCookies()
   zFJyYbUPjMQkDuItWOdlwNeasSvfLE=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.callRequestCookies('Put',zFJyYbUPjMQkDuItWOdlwNeasSvfLX,payload=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,params=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,cookies=zFJyYbUPjMQkDuItWOdlwNeasSvfLB)
   for zFJyYbUPjMQkDuItWOdlwNeasSvfLB in zFJyYbUPjMQkDuItWOdlwNeasSvfLE.cookies:
    if zFJyYbUPjMQkDuItWOdlwNeasSvfLB.name=='_s_guitv':
     zFJyYbUPjMQkDuItWOdlwNeasSvfxR=zFJyYbUPjMQkDuItWOdlwNeasSvfLB.value
    elif zFJyYbUPjMQkDuItWOdlwNeasSvfLB.name=='_guinness-premium_session':
     zFJyYbUPjMQkDuItWOdlwNeasSvfLK=zFJyYbUPjMQkDuItWOdlwNeasSvfLB.value
   if zFJyYbUPjMQkDuItWOdlwNeasSvfxR:
    zFJyYbUPjMQkDuItWOdlwNeasSvfxX=zFJyYbUPjMQkDuItWOdlwNeasSvfxR
   if zFJyYbUPjMQkDuItWOdlwNeasSvfLK:
    zFJyYbUPjMQkDuItWOdlwNeasSvfxn=zFJyYbUPjMQkDuItWOdlwNeasSvfLK
  except zFJyYbUPjMQkDuItWOdlwNeasSvfqG as exception:
   zFJyYbUPjMQkDuItWOdlwNeasSvfxX=''
   zFJyYbUPjMQkDuItWOdlwNeasSvfxn=''
  return zFJyYbUPjMQkDuItWOdlwNeasSvfxX,zFJyYbUPjMQkDuItWOdlwNeasSvfxn
 def GetStreamingURL(zFJyYbUPjMQkDuItWOdlwNeasSvfLq,movie_code,quality_str):
  zFJyYbUPjMQkDuItWOdlwNeasSvfxm=zFJyYbUPjMQkDuItWOdlwNeasSvfxh=zFJyYbUPjMQkDuItWOdlwNeasSvfxK=''
  try:
   zFJyYbUPjMQkDuItWOdlwNeasSvfiq='/api/watch/'+movie_code+'.json'
   zFJyYbUPjMQkDuItWOdlwNeasSvfLX=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeurl(zFJyYbUPjMQkDuItWOdlwNeasSvfLq.API_DOMAIN,zFJyYbUPjMQkDuItWOdlwNeasSvfiq)
   zFJyYbUPjMQkDuItWOdlwNeasSvfLg={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   zFJyYbUPjMQkDuItWOdlwNeasSvfLB=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.makeDefaultCookies()
   zFJyYbUPjMQkDuItWOdlwNeasSvfLE=zFJyYbUPjMQkDuItWOdlwNeasSvfLq.callRequestCookies('Get',zFJyYbUPjMQkDuItWOdlwNeasSvfLX,payload=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,params=zFJyYbUPjMQkDuItWOdlwNeasSvfqL,headers=zFJyYbUPjMQkDuItWOdlwNeasSvfLg,cookies=zFJyYbUPjMQkDuItWOdlwNeasSvfLB)
   zFJyYbUPjMQkDuItWOdlwNeasSvfiG=json.loads(zFJyYbUPjMQkDuItWOdlwNeasSvfLE.text)
   zFJyYbUPjMQkDuItWOdlwNeasSvfxm=zFJyYbUPjMQkDuItWOdlwNeasSvfiG['streams'][0]['source']
   if zFJyYbUPjMQkDuItWOdlwNeasSvfxm==zFJyYbUPjMQkDuItWOdlwNeasSvfqL:return(zFJyYbUPjMQkDuItWOdlwNeasSvfxm,zFJyYbUPjMQkDuItWOdlwNeasSvfxh,zFJyYbUPjMQkDuItWOdlwNeasSvfxK)
   if 'subtitles' in zFJyYbUPjMQkDuItWOdlwNeasSvfiG['streams'][0]:
    for zFJyYbUPjMQkDuItWOdlwNeasSvfxr in zFJyYbUPjMQkDuItWOdlwNeasSvfiG['streams'][0]['subtitles']:
     if zFJyYbUPjMQkDuItWOdlwNeasSvfxr['lang']=='ko':
      zFJyYbUPjMQkDuItWOdlwNeasSvfxh=zFJyYbUPjMQkDuItWOdlwNeasSvfxr['url']
      break
   zFJyYbUPjMQkDuItWOdlwNeasSvfxH =zFJyYbUPjMQkDuItWOdlwNeasSvfiG['ping_payload']
   zFJyYbUPjMQkDuItWOdlwNeasSvfxg =zFJyYbUPjMQkDuItWOdlwNeasSvfLq.WATCHA_USERCD
   zFJyYbUPjMQkDuItWOdlwNeasSvfxE={'merchant':'giitd_frograms','sessionId':zFJyYbUPjMQkDuItWOdlwNeasSvfxH,'userId':zFJyYbUPjMQkDuItWOdlwNeasSvfxg}
   zFJyYbUPjMQkDuItWOdlwNeasSvfxB=json.dumps(zFJyYbUPjMQkDuItWOdlwNeasSvfxE,separators=(",",":")).encode('UTF-8')
   zFJyYbUPjMQkDuItWOdlwNeasSvfxK=base64.b64encode(zFJyYbUPjMQkDuItWOdlwNeasSvfxB)
  except zFJyYbUPjMQkDuItWOdlwNeasSvfqG as exception:
   return(zFJyYbUPjMQkDuItWOdlwNeasSvfxm,zFJyYbUPjMQkDuItWOdlwNeasSvfxh,zFJyYbUPjMQkDuItWOdlwNeasSvfxK)
  return(zFJyYbUPjMQkDuItWOdlwNeasSvfxm,zFJyYbUPjMQkDuItWOdlwNeasSvfxh,zFJyYbUPjMQkDuItWOdlwNeasSvfxK) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
