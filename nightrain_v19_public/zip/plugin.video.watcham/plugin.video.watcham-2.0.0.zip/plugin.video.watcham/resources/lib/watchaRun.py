__author__="NightRain"
NCErWbimXMIxLltqJdOYyDhokgTFsK=object
NCErWbimXMIxLltqJdOYyDhokgTFsH=None
NCErWbimXMIxLltqJdOYyDhokgTFpc=False
NCErWbimXMIxLltqJdOYyDhokgTFpf=int
NCErWbimXMIxLltqJdOYyDhokgTFpG=True
NCErWbimXMIxLltqJdOYyDhokgTFpV=len
NCErWbimXMIxLltqJdOYyDhokgTFps=TypeError
NCErWbimXMIxLltqJdOYyDhokgTFpu=range
NCErWbimXMIxLltqJdOYyDhokgTFpR=str
NCErWbimXMIxLltqJdOYyDhokgTFpv=open
NCErWbimXMIxLltqJdOYyDhokgTFpj=dict
NCErWbimXMIxLltqJdOYyDhokgTFpa=Exception
NCErWbimXMIxLltqJdOYyDhokgTFpe=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
NCErWbimXMIxLltqJdOYyDhokgTFcG=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'검색 (search)','mode':'SEARCH','stype':'-','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-'}]
NCErWbimXMIxLltqJdOYyDhokgTFcV=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
NCErWbimXMIxLltqJdOYyDhokgTFcs=40
NCErWbimXMIxLltqJdOYyDhokgTFcp =20
NCErWbimXMIxLltqJdOYyDhokgTFcu='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
NCErWbimXMIxLltqJdOYyDhokgTFcR =xbmc.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
NCErWbimXMIxLltqJdOYyDhokgTFcv=xbmc.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class NCErWbimXMIxLltqJdOYyDhokgTFcf(NCErWbimXMIxLltqJdOYyDhokgTFsK):
 def __init__(NCErWbimXMIxLltqJdOYyDhokgTFcj,NCErWbimXMIxLltqJdOYyDhokgTFca,NCErWbimXMIxLltqJdOYyDhokgTFce,NCErWbimXMIxLltqJdOYyDhokgTFcB):
  NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_url =NCErWbimXMIxLltqJdOYyDhokgTFca
  NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_handle=NCErWbimXMIxLltqJdOYyDhokgTFce
  NCErWbimXMIxLltqJdOYyDhokgTFcj.main_params =NCErWbimXMIxLltqJdOYyDhokgTFcB
  NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj =zFJyYbUPjMQkDuItWOdlwNeasSvfLi() 
 def addon_noti(NCErWbimXMIxLltqJdOYyDhokgTFcj,sting):
  try:
   NCErWbimXMIxLltqJdOYyDhokgTFcn=xbmcgui.Dialog()
   NCErWbimXMIxLltqJdOYyDhokgTFcn.notification(__addonname__,sting)
  except:
   NCErWbimXMIxLltqJdOYyDhokgTFsH
 def addon_log(NCErWbimXMIxLltqJdOYyDhokgTFcj,string,isDebug=NCErWbimXMIxLltqJdOYyDhokgTFpc):
  try:
   NCErWbimXMIxLltqJdOYyDhokgTFcz=string.encode('utf-8','ignore')
  except:
   NCErWbimXMIxLltqJdOYyDhokgTFcz='addonException: addon_log'
  if isDebug:NCErWbimXMIxLltqJdOYyDhokgTFcQ=xbmc.LOGDEBUG
  else:NCErWbimXMIxLltqJdOYyDhokgTFcQ=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,NCErWbimXMIxLltqJdOYyDhokgTFcz),level=NCErWbimXMIxLltqJdOYyDhokgTFcQ)
 def get_keyboard_input(NCErWbimXMIxLltqJdOYyDhokgTFcj,NCErWbimXMIxLltqJdOYyDhokgTFfu):
  NCErWbimXMIxLltqJdOYyDhokgTFcw=NCErWbimXMIxLltqJdOYyDhokgTFsH
  kb=xbmc.Keyboard()
  kb.setHeading(NCErWbimXMIxLltqJdOYyDhokgTFfu)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   NCErWbimXMIxLltqJdOYyDhokgTFcw=kb.getText()
  return NCErWbimXMIxLltqJdOYyDhokgTFcw
 def get_settings_login_info(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  NCErWbimXMIxLltqJdOYyDhokgTFcU =__addon__.getSetting('id')
  NCErWbimXMIxLltqJdOYyDhokgTFcP =__addon__.getSetting('pw')
  NCErWbimXMIxLltqJdOYyDhokgTFcA=NCErWbimXMIxLltqJdOYyDhokgTFpf(__addon__.getSetting('selected_profile'))
  return(NCErWbimXMIxLltqJdOYyDhokgTFcU,NCErWbimXMIxLltqJdOYyDhokgTFcP,NCErWbimXMIxLltqJdOYyDhokgTFcA)
 def get_selQuality(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  try:
   NCErWbimXMIxLltqJdOYyDhokgTFcK=['3840x2160/1','1920x1080/1','1280x720/1']
   NCErWbimXMIxLltqJdOYyDhokgTFcH=NCErWbimXMIxLltqJdOYyDhokgTFpf(__addon__.getSetting('selected_quality'))
   return NCErWbimXMIxLltqJdOYyDhokgTFcK[NCErWbimXMIxLltqJdOYyDhokgTFcH]
  except:
   NCErWbimXMIxLltqJdOYyDhokgTFsH
  return 1080 
 def get_settings_direct_replay(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  NCErWbimXMIxLltqJdOYyDhokgTFfc=NCErWbimXMIxLltqJdOYyDhokgTFpf(__addon__.getSetting('direct_replay'))
  if NCErWbimXMIxLltqJdOYyDhokgTFfc==0:
   return NCErWbimXMIxLltqJdOYyDhokgTFpc
  else:
   return NCErWbimXMIxLltqJdOYyDhokgTFpG
 def set_winCredential(NCErWbimXMIxLltqJdOYyDhokgTFcj,credential):
  NCErWbimXMIxLltqJdOYyDhokgTFfG=xbmcgui.Window(10000)
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_LOGINTIME',datetime.datetime.now().strftime('%Y-%m-%d'))
 def get_winCredential(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  NCErWbimXMIxLltqJdOYyDhokgTFfG=xbmcgui.Window(10000)
  NCErWbimXMIxLltqJdOYyDhokgTFfV={'watcha_token':NCErWbimXMIxLltqJdOYyDhokgTFfG.getProperty('WATCHA_M_TOKEN'),'watcha_guit':NCErWbimXMIxLltqJdOYyDhokgTFfG.getProperty('WATCHA_M_GUIT'),'watcha_guitv':NCErWbimXMIxLltqJdOYyDhokgTFfG.getProperty('WATCHA_M_GUITV'),'watcha_usercd':NCErWbimXMIxLltqJdOYyDhokgTFfG.getProperty('WATCHA_M_USERCD')}
  return NCErWbimXMIxLltqJdOYyDhokgTFfV
 def set_winEpisodeOrderby(NCErWbimXMIxLltqJdOYyDhokgTFcj,NCErWbimXMIxLltqJdOYyDhokgTFfs):
  NCErWbimXMIxLltqJdOYyDhokgTFfG=xbmcgui.Window(10000)
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_ORDERBY',NCErWbimXMIxLltqJdOYyDhokgTFfs)
 def get_winEpisodeOrderby(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  NCErWbimXMIxLltqJdOYyDhokgTFfG=xbmcgui.Window(10000)
  return NCErWbimXMIxLltqJdOYyDhokgTFfG.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(NCErWbimXMIxLltqJdOYyDhokgTFcj,args):
  NCErWbimXMIxLltqJdOYyDhokgTFfs =args.get('orderby')
  NCErWbimXMIxLltqJdOYyDhokgTFcj.set_winEpisodeOrderby(NCErWbimXMIxLltqJdOYyDhokgTFfs)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(NCErWbimXMIxLltqJdOYyDhokgTFcj,label,sublabel='',img='',infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFsH,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFpG,params=''):
  NCErWbimXMIxLltqJdOYyDhokgTFfp='%s?%s'%(NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_url,urllib.parse.urlencode(params))
  if sublabel:NCErWbimXMIxLltqJdOYyDhokgTFfu='%s < %s >'%(label,sublabel)
  else: NCErWbimXMIxLltqJdOYyDhokgTFfu=label
  if not img:img='DefaultFolder.png'
  NCErWbimXMIxLltqJdOYyDhokgTFfR=xbmcgui.ListItem(NCErWbimXMIxLltqJdOYyDhokgTFfu)
  NCErWbimXMIxLltqJdOYyDhokgTFfR.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:NCErWbimXMIxLltqJdOYyDhokgTFfR.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:NCErWbimXMIxLltqJdOYyDhokgTFfR.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_handle,NCErWbimXMIxLltqJdOYyDhokgTFfp,NCErWbimXMIxLltqJdOYyDhokgTFfR,isFolder)
 def dp_Main_List(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  for NCErWbimXMIxLltqJdOYyDhokgTFfv in NCErWbimXMIxLltqJdOYyDhokgTFcG:
   NCErWbimXMIxLltqJdOYyDhokgTFfu=NCErWbimXMIxLltqJdOYyDhokgTFfv.get('title')
   NCErWbimXMIxLltqJdOYyDhokgTFfj={'mode':NCErWbimXMIxLltqJdOYyDhokgTFfv.get('mode'),'stype':NCErWbimXMIxLltqJdOYyDhokgTFfv.get('stype'),'api_path':NCErWbimXMIxLltqJdOYyDhokgTFfv.get('api_path'),'page':'1','sort':NCErWbimXMIxLltqJdOYyDhokgTFfv.get('sort'),'tag_id':'-'}
   if NCErWbimXMIxLltqJdOYyDhokgTFfv.get('mode')=='XXX':
    NCErWbimXMIxLltqJdOYyDhokgTFfj['mode']='XXX'
    NCErWbimXMIxLltqJdOYyDhokgTFfa=NCErWbimXMIxLltqJdOYyDhokgTFpc
   else:
    NCErWbimXMIxLltqJdOYyDhokgTFfa=NCErWbimXMIxLltqJdOYyDhokgTFpG
   NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel='',img='',infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFsH,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFfa,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
  if NCErWbimXMIxLltqJdOYyDhokgTFpV(NCErWbimXMIxLltqJdOYyDhokgTFcG)>0:xbmcplugin.endOfDirectory(NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_handle)
 def login_main(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  (NCErWbimXMIxLltqJdOYyDhokgTFfB,NCErWbimXMIxLltqJdOYyDhokgTFfS,NCErWbimXMIxLltqJdOYyDhokgTFfn)=NCErWbimXMIxLltqJdOYyDhokgTFcj.get_settings_login_info()
  if not(NCErWbimXMIxLltqJdOYyDhokgTFfB and NCErWbimXMIxLltqJdOYyDhokgTFfS):
   NCErWbimXMIxLltqJdOYyDhokgTFcn=xbmcgui.Dialog()
   NCErWbimXMIxLltqJdOYyDhokgTFfz=NCErWbimXMIxLltqJdOYyDhokgTFcn.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if NCErWbimXMIxLltqJdOYyDhokgTFfz==NCErWbimXMIxLltqJdOYyDhokgTFpG:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if NCErWbimXMIxLltqJdOYyDhokgTFcj.get_winEpisodeOrderby()=='':
   NCErWbimXMIxLltqJdOYyDhokgTFcj.set_winEpisodeOrderby('asc')
  if NCErWbimXMIxLltqJdOYyDhokgTFcj.cookiefile_check():return
  NCErWbimXMIxLltqJdOYyDhokgTFfQ =datetime.datetime.now().date()
  NCErWbimXMIxLltqJdOYyDhokgTFfw=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if NCErWbimXMIxLltqJdOYyDhokgTFfw==NCErWbimXMIxLltqJdOYyDhokgTFsH or NCErWbimXMIxLltqJdOYyDhokgTFfw=='':NCErWbimXMIxLltqJdOYyDhokgTFfw='1900-01-01'
  try:
   NCErWbimXMIxLltqJdOYyDhokgTFfw=datetime.datetime.strptime(NCErWbimXMIxLltqJdOYyDhokgTFfw,'%Y-%m-%d').date()
  except NCErWbimXMIxLltqJdOYyDhokgTFps:
   NCErWbimXMIxLltqJdOYyDhokgTFfw=datetime.datetime(*(time.strptime(NCErWbimXMIxLltqJdOYyDhokgTFfw,'%Y-%m-%d')[0:6])).date()
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   NCErWbimXMIxLltqJdOYyDhokgTFfU=0
   while NCErWbimXMIxLltqJdOYyDhokgTFpG:
    NCErWbimXMIxLltqJdOYyDhokgTFfU+=1
    time.sleep(0.05)
    if NCErWbimXMIxLltqJdOYyDhokgTFfw>=NCErWbimXMIxLltqJdOYyDhokgTFfQ:return
    if NCErWbimXMIxLltqJdOYyDhokgTFfU>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if NCErWbimXMIxLltqJdOYyDhokgTFfw>=NCErWbimXMIxLltqJdOYyDhokgTFfQ:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.GetCredential(NCErWbimXMIxLltqJdOYyDhokgTFfB,NCErWbimXMIxLltqJdOYyDhokgTFfS,NCErWbimXMIxLltqJdOYyDhokgTFfn):
   NCErWbimXMIxLltqJdOYyDhokgTFcj.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  NCErWbimXMIxLltqJdOYyDhokgTFcj.set_winCredential(NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.LoadCredential())
  NCErWbimXMIxLltqJdOYyDhokgTFcj.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(NCErWbimXMIxLltqJdOYyDhokgTFcj,args):
  NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.SaveCredential(NCErWbimXMIxLltqJdOYyDhokgTFcj.get_winCredential())
  NCErWbimXMIxLltqJdOYyDhokgTFfP =args.get('stype')
  NCErWbimXMIxLltqJdOYyDhokgTFfA =NCErWbimXMIxLltqJdOYyDhokgTFpf(args.get('page'))
  NCErWbimXMIxLltqJdOYyDhokgTFfK =args.get('sort')
  NCErWbimXMIxLltqJdOYyDhokgTFfH=NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.GetSubGroupList(NCErWbimXMIxLltqJdOYyDhokgTFfP)
  NCErWbimXMIxLltqJdOYyDhokgTFGc=NCErWbimXMIxLltqJdOYyDhokgTFcs if NCErWbimXMIxLltqJdOYyDhokgTFfP=='genres' else NCErWbimXMIxLltqJdOYyDhokgTFcp
  NCErWbimXMIxLltqJdOYyDhokgTFGf=NCErWbimXMIxLltqJdOYyDhokgTFpV(NCErWbimXMIxLltqJdOYyDhokgTFfH)
  NCErWbimXMIxLltqJdOYyDhokgTFGV =NCErWbimXMIxLltqJdOYyDhokgTFpf(NCErWbimXMIxLltqJdOYyDhokgTFGf//(NCErWbimXMIxLltqJdOYyDhokgTFGc+1))+1
  NCErWbimXMIxLltqJdOYyDhokgTFGs =(NCErWbimXMIxLltqJdOYyDhokgTFfA-1)*NCErWbimXMIxLltqJdOYyDhokgTFGc
  for i in NCErWbimXMIxLltqJdOYyDhokgTFpu(NCErWbimXMIxLltqJdOYyDhokgTFGc):
   NCErWbimXMIxLltqJdOYyDhokgTFGp=NCErWbimXMIxLltqJdOYyDhokgTFGs+i
   if NCErWbimXMIxLltqJdOYyDhokgTFGp>=NCErWbimXMIxLltqJdOYyDhokgTFGf:break
   NCErWbimXMIxLltqJdOYyDhokgTFfu =NCErWbimXMIxLltqJdOYyDhokgTFfH[NCErWbimXMIxLltqJdOYyDhokgTFGp].get('group_name')
   NCErWbimXMIxLltqJdOYyDhokgTFGu =NCErWbimXMIxLltqJdOYyDhokgTFfH[NCErWbimXMIxLltqJdOYyDhokgTFGp].get('api_path')
   NCErWbimXMIxLltqJdOYyDhokgTFGR =NCErWbimXMIxLltqJdOYyDhokgTFfH[NCErWbimXMIxLltqJdOYyDhokgTFGp].get('tag_id')
   NCErWbimXMIxLltqJdOYyDhokgTFfj={'mode':'CATEGORY_LIST','api_path':NCErWbimXMIxLltqJdOYyDhokgTFGu,'tag_id':NCErWbimXMIxLltqJdOYyDhokgTFGR,'stype':NCErWbimXMIxLltqJdOYyDhokgTFfP,'page':'1','sort':NCErWbimXMIxLltqJdOYyDhokgTFfK}
   NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel='',img='',infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFsH,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFpG,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
  if NCErWbimXMIxLltqJdOYyDhokgTFGV>NCErWbimXMIxLltqJdOYyDhokgTFfA:
   NCErWbimXMIxLltqJdOYyDhokgTFfj={}
   NCErWbimXMIxLltqJdOYyDhokgTFfj['mode'] ='SUB_GROUP' 
   NCErWbimXMIxLltqJdOYyDhokgTFfj['stype'] =NCErWbimXMIxLltqJdOYyDhokgTFfP
   NCErWbimXMIxLltqJdOYyDhokgTFfj['api_path']=args.get('api_path')
   NCErWbimXMIxLltqJdOYyDhokgTFfj['page'] =NCErWbimXMIxLltqJdOYyDhokgTFpR(NCErWbimXMIxLltqJdOYyDhokgTFfA+1)
   NCErWbimXMIxLltqJdOYyDhokgTFfj['sort'] =NCErWbimXMIxLltqJdOYyDhokgTFfK
   NCErWbimXMIxLltqJdOYyDhokgTFfu='[B]%s >>[/B]'%'다음 페이지'
   NCErWbimXMIxLltqJdOYyDhokgTFGv=NCErWbimXMIxLltqJdOYyDhokgTFpR(NCErWbimXMIxLltqJdOYyDhokgTFfA+1)
   NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel=NCErWbimXMIxLltqJdOYyDhokgTFGv,img='',infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFsH,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFpG,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
  if NCErWbimXMIxLltqJdOYyDhokgTFpV(NCErWbimXMIxLltqJdOYyDhokgTFfH)>0:xbmcplugin.endOfDirectory(NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_handle,cacheToDisc=NCErWbimXMIxLltqJdOYyDhokgTFpG)
 def play_VIDEO(NCErWbimXMIxLltqJdOYyDhokgTFcj,args):
  NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.SaveCredential(NCErWbimXMIxLltqJdOYyDhokgTFcj.get_winCredential())
  NCErWbimXMIxLltqJdOYyDhokgTFGj =args.get('movie_code')
  NCErWbimXMIxLltqJdOYyDhokgTFGa =args.get('season_code')
  NCErWbimXMIxLltqJdOYyDhokgTFfu =args.get('title')
  NCErWbimXMIxLltqJdOYyDhokgTFGe =args.get('thumbnail')
  NCErWbimXMIxLltqJdOYyDhokgTFGB =NCErWbimXMIxLltqJdOYyDhokgTFcj.get_selQuality()
  NCErWbimXMIxLltqJdOYyDhokgTFcj.addon_log(NCErWbimXMIxLltqJdOYyDhokgTFGj+' - '+NCErWbimXMIxLltqJdOYyDhokgTFGa,NCErWbimXMIxLltqJdOYyDhokgTFpc)
  NCErWbimXMIxLltqJdOYyDhokgTFGS,NCErWbimXMIxLltqJdOYyDhokgTFGn,NCErWbimXMIxLltqJdOYyDhokgTFGz=NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.GetStreamingURL(NCErWbimXMIxLltqJdOYyDhokgTFGj,NCErWbimXMIxLltqJdOYyDhokgTFGB)
  if NCErWbimXMIxLltqJdOYyDhokgTFGS=='':
   NCErWbimXMIxLltqJdOYyDhokgTFcj.addon_noti(__language__(30908).encode('utf8'))
   return
  NCErWbimXMIxLltqJdOYyDhokgTFGQ=NCErWbimXMIxLltqJdOYyDhokgTFGS
  NCErWbimXMIxLltqJdOYyDhokgTFcj.addon_log(NCErWbimXMIxLltqJdOYyDhokgTFGQ,NCErWbimXMIxLltqJdOYyDhokgTFpc)
  NCErWbimXMIxLltqJdOYyDhokgTFGw=xbmcgui.ListItem(path=NCErWbimXMIxLltqJdOYyDhokgTFGQ)
  if NCErWbimXMIxLltqJdOYyDhokgTFGz:
   NCErWbimXMIxLltqJdOYyDhokgTFGU=NCErWbimXMIxLltqJdOYyDhokgTFGz
   NCErWbimXMIxLltqJdOYyDhokgTFGP ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   NCErWbimXMIxLltqJdOYyDhokgTFGA ='mpd'
   NCErWbimXMIxLltqJdOYyDhokgTFGK ='com.widevine.alpha'
   NCErWbimXMIxLltqJdOYyDhokgTFGH =inputstreamhelper.Helper(NCErWbimXMIxLltqJdOYyDhokgTFGA,drm=NCErWbimXMIxLltqJdOYyDhokgTFGK)
   if NCErWbimXMIxLltqJdOYyDhokgTFGH.check_inputstream():
    NCErWbimXMIxLltqJdOYyDhokgTFVc={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+NCErWbimXMIxLltqJdOYyDhokgTFGj,'dt-custom-data':NCErWbimXMIxLltqJdOYyDhokgTFGU,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':NCErWbimXMIxLltqJdOYyDhokgTFcu,'Content-Type':'application/octet-stream'}
    NCErWbimXMIxLltqJdOYyDhokgTFVf=NCErWbimXMIxLltqJdOYyDhokgTFGP+'|'+urllib.parse.urlencode(NCErWbimXMIxLltqJdOYyDhokgTFVc)+'|R{SSM}|'
    NCErWbimXMIxLltqJdOYyDhokgTFcj.addon_log(NCErWbimXMIxLltqJdOYyDhokgTFVf)
    NCErWbimXMIxLltqJdOYyDhokgTFGw.setProperty('inputstream',NCErWbimXMIxLltqJdOYyDhokgTFGH.inputstream_addon)
    NCErWbimXMIxLltqJdOYyDhokgTFGw.setProperty('inputstream.adaptive.manifest_type',NCErWbimXMIxLltqJdOYyDhokgTFGA)
    NCErWbimXMIxLltqJdOYyDhokgTFGw.setProperty('inputstream.adaptive.license_type',NCErWbimXMIxLltqJdOYyDhokgTFGK)
    NCErWbimXMIxLltqJdOYyDhokgTFGw.setProperty('inputstream.adaptive.license_key',NCErWbimXMIxLltqJdOYyDhokgTFVf)
    NCErWbimXMIxLltqJdOYyDhokgTFGw.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(NCErWbimXMIxLltqJdOYyDhokgTFcu))
  if NCErWbimXMIxLltqJdOYyDhokgTFGn:
   try:
    f=NCErWbimXMIxLltqJdOYyDhokgTFpv(NCErWbimXMIxLltqJdOYyDhokgTFcR,'w',-1,'utf-8')
    NCErWbimXMIxLltqJdOYyDhokgTFVG=requests.get(NCErWbimXMIxLltqJdOYyDhokgTFGn)
    NCErWbimXMIxLltqJdOYyDhokgTFVs=NCErWbimXMIxLltqJdOYyDhokgTFVG.content.decode('utf-8') 
    for NCErWbimXMIxLltqJdOYyDhokgTFVp in NCErWbimXMIxLltqJdOYyDhokgTFVs.splitlines():
     NCErWbimXMIxLltqJdOYyDhokgTFVu=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',NCErWbimXMIxLltqJdOYyDhokgTFVp)
     f.write(NCErWbimXMIxLltqJdOYyDhokgTFVu+'\n')
    f.close()
    NCErWbimXMIxLltqJdOYyDhokgTFGw.setSubtitles([NCErWbimXMIxLltqJdOYyDhokgTFcR,NCErWbimXMIxLltqJdOYyDhokgTFGn])
   except:
    NCErWbimXMIxLltqJdOYyDhokgTFGw.setSubtitles([NCErWbimXMIxLltqJdOYyDhokgTFGn])
  xbmcplugin.setResolvedUrl(NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_handle,NCErWbimXMIxLltqJdOYyDhokgTFpG,NCErWbimXMIxLltqJdOYyDhokgTFGw)
  try:
   NCErWbimXMIxLltqJdOYyDhokgTFfP='movie' if NCErWbimXMIxLltqJdOYyDhokgTFGa=='-' else 'seasons'
   NCErWbimXMIxLltqJdOYyDhokgTFfj={'code':NCErWbimXMIxLltqJdOYyDhokgTFGj if NCErWbimXMIxLltqJdOYyDhokgTFfP=='movie' else NCErWbimXMIxLltqJdOYyDhokgTFGa,'img':NCErWbimXMIxLltqJdOYyDhokgTFGe,'title':NCErWbimXMIxLltqJdOYyDhokgTFfu,'videoid':NCErWbimXMIxLltqJdOYyDhokgTFGj}
   NCErWbimXMIxLltqJdOYyDhokgTFcj.Save_Watched_List(NCErWbimXMIxLltqJdOYyDhokgTFfP,NCErWbimXMIxLltqJdOYyDhokgTFfj)
  except:
   NCErWbimXMIxLltqJdOYyDhokgTFsH
 def dp_Category_List(NCErWbimXMIxLltqJdOYyDhokgTFcj,args):
  NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.SaveCredential(NCErWbimXMIxLltqJdOYyDhokgTFcj.get_winCredential())
  NCErWbimXMIxLltqJdOYyDhokgTFfP =args.get('stype')
  NCErWbimXMIxLltqJdOYyDhokgTFGR =args.get('tag_id')
  NCErWbimXMIxLltqJdOYyDhokgTFGu=args.get('api_path')
  NCErWbimXMIxLltqJdOYyDhokgTFfA=NCErWbimXMIxLltqJdOYyDhokgTFpf(args.get('page'))
  NCErWbimXMIxLltqJdOYyDhokgTFfK =args.get('sort')
  NCErWbimXMIxLltqJdOYyDhokgTFVR,NCErWbimXMIxLltqJdOYyDhokgTFVv=NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.GetCategoryList(NCErWbimXMIxLltqJdOYyDhokgTFfP,NCErWbimXMIxLltqJdOYyDhokgTFGR,NCErWbimXMIxLltqJdOYyDhokgTFGu,NCErWbimXMIxLltqJdOYyDhokgTFfA,NCErWbimXMIxLltqJdOYyDhokgTFfK)
  for NCErWbimXMIxLltqJdOYyDhokgTFVj in NCErWbimXMIxLltqJdOYyDhokgTFVR:
   NCErWbimXMIxLltqJdOYyDhokgTFGj =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('code')
   NCErWbimXMIxLltqJdOYyDhokgTFfu =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('title')
   NCErWbimXMIxLltqJdOYyDhokgTFVa =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('content_type')
   NCErWbimXMIxLltqJdOYyDhokgTFVe =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('story')
   NCErWbimXMIxLltqJdOYyDhokgTFGe =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('thumbnail')
   NCErWbimXMIxLltqJdOYyDhokgTFVB =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('year')
   NCErWbimXMIxLltqJdOYyDhokgTFVS =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('film_rating_code')
   NCErWbimXMIxLltqJdOYyDhokgTFVn=NCErWbimXMIxLltqJdOYyDhokgTFVj.get('film_rating_short')
   if NCErWbimXMIxLltqJdOYyDhokgTFVa=='movies': 
    NCErWbimXMIxLltqJdOYyDhokgTFfa=NCErWbimXMIxLltqJdOYyDhokgTFpc
    NCErWbimXMIxLltqJdOYyDhokgTFVz ='MOVIE'
    NCErWbimXMIxLltqJdOYyDhokgTFfe=''
    NCErWbimXMIxLltqJdOYyDhokgTFGa='-'
   else: 
    NCErWbimXMIxLltqJdOYyDhokgTFfa=NCErWbimXMIxLltqJdOYyDhokgTFpG
    NCErWbimXMIxLltqJdOYyDhokgTFVz ='EPISODE'
    NCErWbimXMIxLltqJdOYyDhokgTFfe='Series'
    NCErWbimXMIxLltqJdOYyDhokgTFGa=NCErWbimXMIxLltqJdOYyDhokgTFGj
   NCErWbimXMIxLltqJdOYyDhokgTFVQ=NCErWbimXMIxLltqJdOYyDhokgTFVj.get('info')
   NCErWbimXMIxLltqJdOYyDhokgTFVQ['plot']='%s (%s)\n년도 : %s\n\n%s'%(NCErWbimXMIxLltqJdOYyDhokgTFfu,NCErWbimXMIxLltqJdOYyDhokgTFVn,NCErWbimXMIxLltqJdOYyDhokgTFVB,NCErWbimXMIxLltqJdOYyDhokgTFVe)
   if NCErWbimXMIxLltqJdOYyDhokgTFVS>=19:
    NCErWbimXMIxLltqJdOYyDhokgTFfu+='  (%s년 - %s)'%(NCErWbimXMIxLltqJdOYyDhokgTFVB,NCErWbimXMIxLltqJdOYyDhokgTFpR(NCErWbimXMIxLltqJdOYyDhokgTFVn))
   else:
    NCErWbimXMIxLltqJdOYyDhokgTFfu+='  (%s년)'%(NCErWbimXMIxLltqJdOYyDhokgTFVB)
   NCErWbimXMIxLltqJdOYyDhokgTFfj={'mode':NCErWbimXMIxLltqJdOYyDhokgTFVz,'movie_code':NCErWbimXMIxLltqJdOYyDhokgTFGj,'page':'1','season_code':NCErWbimXMIxLltqJdOYyDhokgTFGa,'title':NCErWbimXMIxLltqJdOYyDhokgTFfu,'thumbnail':NCErWbimXMIxLltqJdOYyDhokgTFGe}
   NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel=NCErWbimXMIxLltqJdOYyDhokgTFfe,img=NCErWbimXMIxLltqJdOYyDhokgTFGe,infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFVQ,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFfa,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
  if NCErWbimXMIxLltqJdOYyDhokgTFVv:
   if NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.GetCategoryList_morepage(NCErWbimXMIxLltqJdOYyDhokgTFfP,NCErWbimXMIxLltqJdOYyDhokgTFGR,NCErWbimXMIxLltqJdOYyDhokgTFGu,NCErWbimXMIxLltqJdOYyDhokgTFfA+1,NCErWbimXMIxLltqJdOYyDhokgTFfK):
    NCErWbimXMIxLltqJdOYyDhokgTFfj={}
    NCErWbimXMIxLltqJdOYyDhokgTFfj['mode'] ='CATEGORY_LIST'
    NCErWbimXMIxLltqJdOYyDhokgTFfj['stype'] =NCErWbimXMIxLltqJdOYyDhokgTFfP
    NCErWbimXMIxLltqJdOYyDhokgTFfj['tag_id'] =NCErWbimXMIxLltqJdOYyDhokgTFGR
    NCErWbimXMIxLltqJdOYyDhokgTFfj['api_path']=NCErWbimXMIxLltqJdOYyDhokgTFGu
    NCErWbimXMIxLltqJdOYyDhokgTFfj['page'] =NCErWbimXMIxLltqJdOYyDhokgTFpR(NCErWbimXMIxLltqJdOYyDhokgTFfA+1)
    NCErWbimXMIxLltqJdOYyDhokgTFfj['sort'] =NCErWbimXMIxLltqJdOYyDhokgTFfK
    NCErWbimXMIxLltqJdOYyDhokgTFfu='[B]%s >>[/B]'%'다음 페이지'
    NCErWbimXMIxLltqJdOYyDhokgTFGv=NCErWbimXMIxLltqJdOYyDhokgTFpR(NCErWbimXMIxLltqJdOYyDhokgTFfA+1)
    NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel=NCErWbimXMIxLltqJdOYyDhokgTFGv,img='',infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFsH,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFpG,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
  if NCErWbimXMIxLltqJdOYyDhokgTFpV(NCErWbimXMIxLltqJdOYyDhokgTFVR)>0:
   if NCErWbimXMIxLltqJdOYyDhokgTFGu=='arrivals/latest':
    xbmcplugin.endOfDirectory(NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_handle,cacheToDisc=NCErWbimXMIxLltqJdOYyDhokgTFpG)
   else:
    xbmcplugin.endOfDirectory(NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_handle,cacheToDisc=NCErWbimXMIxLltqJdOYyDhokgTFpc)
 def dp_Episode_List(NCErWbimXMIxLltqJdOYyDhokgTFcj,args):
  NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.SaveCredential(NCErWbimXMIxLltqJdOYyDhokgTFcj.get_winCredential())
  NCErWbimXMIxLltqJdOYyDhokgTFVU=args.get('movie_code')
  NCErWbimXMIxLltqJdOYyDhokgTFfA =NCErWbimXMIxLltqJdOYyDhokgTFpf(args.get('page'))
  NCErWbimXMIxLltqJdOYyDhokgTFGa =args.get('season_code')
  NCErWbimXMIxLltqJdOYyDhokgTFVR,NCErWbimXMIxLltqJdOYyDhokgTFVv=NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.GetEpisodoList(NCErWbimXMIxLltqJdOYyDhokgTFVU,NCErWbimXMIxLltqJdOYyDhokgTFfA,orderby=NCErWbimXMIxLltqJdOYyDhokgTFcj.get_winEpisodeOrderby())
  for NCErWbimXMIxLltqJdOYyDhokgTFVj in NCErWbimXMIxLltqJdOYyDhokgTFVR:
   NCErWbimXMIxLltqJdOYyDhokgTFGj =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('code')
   NCErWbimXMIxLltqJdOYyDhokgTFfu =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('title')
   NCErWbimXMIxLltqJdOYyDhokgTFGe =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('thumbnail')
   NCErWbimXMIxLltqJdOYyDhokgTFVP =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('display_num')
   NCErWbimXMIxLltqJdOYyDhokgTFVA=NCErWbimXMIxLltqJdOYyDhokgTFVj.get('season_title')
   NCErWbimXMIxLltqJdOYyDhokgTFVQ=NCErWbimXMIxLltqJdOYyDhokgTFVj.get('info')
   NCErWbimXMIxLltqJdOYyDhokgTFVQ['plot']='%s\n%s\n\n%s'%(NCErWbimXMIxLltqJdOYyDhokgTFVA,NCErWbimXMIxLltqJdOYyDhokgTFVP,NCErWbimXMIxLltqJdOYyDhokgTFfu)
   NCErWbimXMIxLltqJdOYyDhokgTFfu='(%s) %s'%(NCErWbimXMIxLltqJdOYyDhokgTFVP,NCErWbimXMIxLltqJdOYyDhokgTFfu)
   NCErWbimXMIxLltqJdOYyDhokgTFfj={'mode':'MOVIE','movie_code':NCErWbimXMIxLltqJdOYyDhokgTFGj,'season_code':NCErWbimXMIxLltqJdOYyDhokgTFGa,'title':'%s < %s >'%(NCErWbimXMIxLltqJdOYyDhokgTFfu,NCErWbimXMIxLltqJdOYyDhokgTFVA),'thumbnail':NCErWbimXMIxLltqJdOYyDhokgTFGe}
   NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel=NCErWbimXMIxLltqJdOYyDhokgTFVA,img=NCErWbimXMIxLltqJdOYyDhokgTFGe,infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFVQ,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFpc,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
  if NCErWbimXMIxLltqJdOYyDhokgTFfA==1:
   NCErWbimXMIxLltqJdOYyDhokgTFVQ={'plot':'정렬순서를 변경합니다.'}
   NCErWbimXMIxLltqJdOYyDhokgTFfj={}
   NCErWbimXMIxLltqJdOYyDhokgTFfj['mode'] ='ORDER_BY' 
   if NCErWbimXMIxLltqJdOYyDhokgTFcj.get_winEpisodeOrderby()=='desc':
    NCErWbimXMIxLltqJdOYyDhokgTFfu='정렬순서변경 : 최신화부터 -> 1회부터'
    NCErWbimXMIxLltqJdOYyDhokgTFfj['orderby']='asc'
   else:
    NCErWbimXMIxLltqJdOYyDhokgTFfu='정렬순서변경 : 1회부터 -> 최신화부터'
    NCErWbimXMIxLltqJdOYyDhokgTFfj['orderby']='desc'
   NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel='',img='',infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFVQ,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFpc,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
  if NCErWbimXMIxLltqJdOYyDhokgTFVv:
   NCErWbimXMIxLltqJdOYyDhokgTFfj['mode'] ='EPISODE' 
   NCErWbimXMIxLltqJdOYyDhokgTFfj['movie_code']=NCErWbimXMIxLltqJdOYyDhokgTFVU
   NCErWbimXMIxLltqJdOYyDhokgTFfj['page'] =NCErWbimXMIxLltqJdOYyDhokgTFpR(NCErWbimXMIxLltqJdOYyDhokgTFfA+1)
   NCErWbimXMIxLltqJdOYyDhokgTFfu='[B]%s >>[/B]'%'다음 페이지'
   NCErWbimXMIxLltqJdOYyDhokgTFGv=NCErWbimXMIxLltqJdOYyDhokgTFpR(NCErWbimXMIxLltqJdOYyDhokgTFfA+1)
   NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel=NCErWbimXMIxLltqJdOYyDhokgTFGv,img='',infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFsH,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFpG,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
  if NCErWbimXMIxLltqJdOYyDhokgTFpV(NCErWbimXMIxLltqJdOYyDhokgTFVR)>0:xbmcplugin.endOfDirectory(NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_handle,cacheToDisc=NCErWbimXMIxLltqJdOYyDhokgTFpG)
 def dp_Search_List(NCErWbimXMIxLltqJdOYyDhokgTFcj,args):
  NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.SaveCredential(NCErWbimXMIxLltqJdOYyDhokgTFcj.get_winCredential())
  NCErWbimXMIxLltqJdOYyDhokgTFfA =NCErWbimXMIxLltqJdOYyDhokgTFpf(args.get('page'))
  if 'search_key' in args:
   NCErWbimXMIxLltqJdOYyDhokgTFVK=args.get('search_key')
  else:
   NCErWbimXMIxLltqJdOYyDhokgTFVK=NCErWbimXMIxLltqJdOYyDhokgTFcj.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not NCErWbimXMIxLltqJdOYyDhokgTFVK:return
  NCErWbimXMIxLltqJdOYyDhokgTFVR,NCErWbimXMIxLltqJdOYyDhokgTFVv=NCErWbimXMIxLltqJdOYyDhokgTFcj.WatchaObj.GetSearchList(NCErWbimXMIxLltqJdOYyDhokgTFVK,NCErWbimXMIxLltqJdOYyDhokgTFfA)
  if NCErWbimXMIxLltqJdOYyDhokgTFpV(NCErWbimXMIxLltqJdOYyDhokgTFVR)==0:return
  for NCErWbimXMIxLltqJdOYyDhokgTFVj in NCErWbimXMIxLltqJdOYyDhokgTFVR:
   NCErWbimXMIxLltqJdOYyDhokgTFGj =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('code')
   NCErWbimXMIxLltqJdOYyDhokgTFfu =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('title')
   NCErWbimXMIxLltqJdOYyDhokgTFVa=NCErWbimXMIxLltqJdOYyDhokgTFVj.get('content_type')
   NCErWbimXMIxLltqJdOYyDhokgTFVe =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('story')
   NCErWbimXMIxLltqJdOYyDhokgTFGe =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('thumbnail')
   NCErWbimXMIxLltqJdOYyDhokgTFVB =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('year')
   NCErWbimXMIxLltqJdOYyDhokgTFVS =NCErWbimXMIxLltqJdOYyDhokgTFVj.get('film_rating_code')
   NCErWbimXMIxLltqJdOYyDhokgTFVn=NCErWbimXMIxLltqJdOYyDhokgTFVj.get('film_rating_short')
   if NCErWbimXMIxLltqJdOYyDhokgTFVa=='movies': 
    NCErWbimXMIxLltqJdOYyDhokgTFfa=NCErWbimXMIxLltqJdOYyDhokgTFpc
    NCErWbimXMIxLltqJdOYyDhokgTFVz ='MOVIE'
    NCErWbimXMIxLltqJdOYyDhokgTFfe=''
    NCErWbimXMIxLltqJdOYyDhokgTFGa='-'
   else: 
    NCErWbimXMIxLltqJdOYyDhokgTFfa=NCErWbimXMIxLltqJdOYyDhokgTFpG
    NCErWbimXMIxLltqJdOYyDhokgTFVz ='EPISODE'
    NCErWbimXMIxLltqJdOYyDhokgTFfe='Series'
    NCErWbimXMIxLltqJdOYyDhokgTFGa=NCErWbimXMIxLltqJdOYyDhokgTFGj
   NCErWbimXMIxLltqJdOYyDhokgTFVQ=NCErWbimXMIxLltqJdOYyDhokgTFVj.get('info')
   NCErWbimXMIxLltqJdOYyDhokgTFVQ['plot']='%s (%s)\n년도 : %s\n\n%s'%(NCErWbimXMIxLltqJdOYyDhokgTFfu,NCErWbimXMIxLltqJdOYyDhokgTFVn,NCErWbimXMIxLltqJdOYyDhokgTFVB,NCErWbimXMIxLltqJdOYyDhokgTFVe)
   if NCErWbimXMIxLltqJdOYyDhokgTFVS>=19:
    NCErWbimXMIxLltqJdOYyDhokgTFfu+='  (%s년 - %s)'%(NCErWbimXMIxLltqJdOYyDhokgTFVB,NCErWbimXMIxLltqJdOYyDhokgTFpR(NCErWbimXMIxLltqJdOYyDhokgTFVn))
   else:
    NCErWbimXMIxLltqJdOYyDhokgTFfu+='  (%s년)'%(NCErWbimXMIxLltqJdOYyDhokgTFVB)
   NCErWbimXMIxLltqJdOYyDhokgTFfj={'mode':NCErWbimXMIxLltqJdOYyDhokgTFVz,'movie_code':NCErWbimXMIxLltqJdOYyDhokgTFGj,'page':'1','season_code':NCErWbimXMIxLltqJdOYyDhokgTFGa,'title':NCErWbimXMIxLltqJdOYyDhokgTFfu,'thumbnail':NCErWbimXMIxLltqJdOYyDhokgTFGe}
   NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel=NCErWbimXMIxLltqJdOYyDhokgTFfe,img=NCErWbimXMIxLltqJdOYyDhokgTFGe,infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFVQ,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFfa,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
  if NCErWbimXMIxLltqJdOYyDhokgTFVv:
   NCErWbimXMIxLltqJdOYyDhokgTFfj={}
   NCErWbimXMIxLltqJdOYyDhokgTFfj['mode'] ='SEARCH'
   NCErWbimXMIxLltqJdOYyDhokgTFfj['search_key']=NCErWbimXMIxLltqJdOYyDhokgTFVK
   NCErWbimXMIxLltqJdOYyDhokgTFfj['page'] =NCErWbimXMIxLltqJdOYyDhokgTFpR(NCErWbimXMIxLltqJdOYyDhokgTFfA+1)
   NCErWbimXMIxLltqJdOYyDhokgTFfu='[B]%s >>[/B]'%'다음 페이지'
   NCErWbimXMIxLltqJdOYyDhokgTFGv=NCErWbimXMIxLltqJdOYyDhokgTFpR(NCErWbimXMIxLltqJdOYyDhokgTFfA+1)
   NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel=NCErWbimXMIxLltqJdOYyDhokgTFGv,img='',infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFsH,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFpG,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
  if NCErWbimXMIxLltqJdOYyDhokgTFpV(NCErWbimXMIxLltqJdOYyDhokgTFVR)>0:xbmcplugin.endOfDirectory(NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_handle)
 def Delete_Watched_List(NCErWbimXMIxLltqJdOYyDhokgTFcj,NCErWbimXMIxLltqJdOYyDhokgTFfP):
  try:
   NCErWbimXMIxLltqJdOYyDhokgTFVH=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NCErWbimXMIxLltqJdOYyDhokgTFfP))
   with NCErWbimXMIxLltqJdOYyDhokgTFpv(NCErWbimXMIxLltqJdOYyDhokgTFVH,'w',-1,'utf-8')as fp:
    fp.write('')
  except:
   NCErWbimXMIxLltqJdOYyDhokgTFsH
 def dp_WatchList_Delete(NCErWbimXMIxLltqJdOYyDhokgTFcj,args):
  NCErWbimXMIxLltqJdOYyDhokgTFfP=args.get('stype')
  NCErWbimXMIxLltqJdOYyDhokgTFcn=xbmcgui.Dialog()
  NCErWbimXMIxLltqJdOYyDhokgTFfz=NCErWbimXMIxLltqJdOYyDhokgTFcn.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if NCErWbimXMIxLltqJdOYyDhokgTFfz==NCErWbimXMIxLltqJdOYyDhokgTFpc:sys.exit()
  NCErWbimXMIxLltqJdOYyDhokgTFcj.Delete_Watched_List(NCErWbimXMIxLltqJdOYyDhokgTFfP)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(NCErWbimXMIxLltqJdOYyDhokgTFcj,NCErWbimXMIxLltqJdOYyDhokgTFfP):
  try:
   NCErWbimXMIxLltqJdOYyDhokgTFVH=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NCErWbimXMIxLltqJdOYyDhokgTFfP))
   with NCErWbimXMIxLltqJdOYyDhokgTFpv(NCErWbimXMIxLltqJdOYyDhokgTFVH,'r',-1,'utf-8')as fp:
    NCErWbimXMIxLltqJdOYyDhokgTFsc=fp.readlines()
  except:
   NCErWbimXMIxLltqJdOYyDhokgTFsc=[]
  return NCErWbimXMIxLltqJdOYyDhokgTFsc
 def Save_Watched_List(NCErWbimXMIxLltqJdOYyDhokgTFcj,NCErWbimXMIxLltqJdOYyDhokgTFfP,NCErWbimXMIxLltqJdOYyDhokgTFcB):
  try:
   NCErWbimXMIxLltqJdOYyDhokgTFVH=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%NCErWbimXMIxLltqJdOYyDhokgTFfP))
   NCErWbimXMIxLltqJdOYyDhokgTFsf=NCErWbimXMIxLltqJdOYyDhokgTFcj.Load_Watched_List(NCErWbimXMIxLltqJdOYyDhokgTFfP) 
   with NCErWbimXMIxLltqJdOYyDhokgTFpv(NCErWbimXMIxLltqJdOYyDhokgTFVH,'w',-1,'utf-8')as fp:
    NCErWbimXMIxLltqJdOYyDhokgTFsG=urllib.parse.urlencode(NCErWbimXMIxLltqJdOYyDhokgTFcB)
    NCErWbimXMIxLltqJdOYyDhokgTFsG=NCErWbimXMIxLltqJdOYyDhokgTFsG+'\n'
    fp.write(NCErWbimXMIxLltqJdOYyDhokgTFsG)
    NCErWbimXMIxLltqJdOYyDhokgTFsV=0
    for NCErWbimXMIxLltqJdOYyDhokgTFsp in NCErWbimXMIxLltqJdOYyDhokgTFsf:
     NCErWbimXMIxLltqJdOYyDhokgTFsu=NCErWbimXMIxLltqJdOYyDhokgTFpj(urllib.parse.parse_qsl(NCErWbimXMIxLltqJdOYyDhokgTFsp))
     NCErWbimXMIxLltqJdOYyDhokgTFsR=NCErWbimXMIxLltqJdOYyDhokgTFcB.get('code')
     NCErWbimXMIxLltqJdOYyDhokgTFsv=NCErWbimXMIxLltqJdOYyDhokgTFsu.get('code')
     if NCErWbimXMIxLltqJdOYyDhokgTFfP=='seasons' and NCErWbimXMIxLltqJdOYyDhokgTFcj.get_settings_direct_replay()==NCErWbimXMIxLltqJdOYyDhokgTFpG:
      NCErWbimXMIxLltqJdOYyDhokgTFsR=NCErWbimXMIxLltqJdOYyDhokgTFcB.get('videoid')
      NCErWbimXMIxLltqJdOYyDhokgTFsv=NCErWbimXMIxLltqJdOYyDhokgTFsu.get('videoid')if NCErWbimXMIxLltqJdOYyDhokgTFsv!=NCErWbimXMIxLltqJdOYyDhokgTFsH else '-'
     if NCErWbimXMIxLltqJdOYyDhokgTFsR!=NCErWbimXMIxLltqJdOYyDhokgTFsv:
      fp.write(NCErWbimXMIxLltqJdOYyDhokgTFsp)
      NCErWbimXMIxLltqJdOYyDhokgTFsV+=1
      if NCErWbimXMIxLltqJdOYyDhokgTFsV>=50:break
  except:
   NCErWbimXMIxLltqJdOYyDhokgTFsH
 def dp_Watch_List(NCErWbimXMIxLltqJdOYyDhokgTFcj,args):
  NCErWbimXMIxLltqJdOYyDhokgTFfP =args.get('stype')
  NCErWbimXMIxLltqJdOYyDhokgTFfc=NCErWbimXMIxLltqJdOYyDhokgTFcj.get_settings_direct_replay()
  if NCErWbimXMIxLltqJdOYyDhokgTFfP=='-':
   for NCErWbimXMIxLltqJdOYyDhokgTFsj in NCErWbimXMIxLltqJdOYyDhokgTFcV:
    NCErWbimXMIxLltqJdOYyDhokgTFfu=NCErWbimXMIxLltqJdOYyDhokgTFsj.get('title')
    NCErWbimXMIxLltqJdOYyDhokgTFfj={'mode':NCErWbimXMIxLltqJdOYyDhokgTFsj.get('mode'),'stype':NCErWbimXMIxLltqJdOYyDhokgTFsj.get('stype')}
    NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel='',img='',infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFsH,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFpG,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
   if NCErWbimXMIxLltqJdOYyDhokgTFpV(NCErWbimXMIxLltqJdOYyDhokgTFcV)>0:xbmcplugin.endOfDirectory(NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_handle)
  else:
   NCErWbimXMIxLltqJdOYyDhokgTFsa=NCErWbimXMIxLltqJdOYyDhokgTFcj.Load_Watched_List(NCErWbimXMIxLltqJdOYyDhokgTFfP)
   for NCErWbimXMIxLltqJdOYyDhokgTFse in NCErWbimXMIxLltqJdOYyDhokgTFsa:
    NCErWbimXMIxLltqJdOYyDhokgTFsB=NCErWbimXMIxLltqJdOYyDhokgTFpj(urllib.parse.parse_qsl(NCErWbimXMIxLltqJdOYyDhokgTFse))
    NCErWbimXMIxLltqJdOYyDhokgTFGj=NCErWbimXMIxLltqJdOYyDhokgTFsB.get('code')
    NCErWbimXMIxLltqJdOYyDhokgTFfu =NCErWbimXMIxLltqJdOYyDhokgTFsB.get('title')
    NCErWbimXMIxLltqJdOYyDhokgTFGe =NCErWbimXMIxLltqJdOYyDhokgTFsB.get('img')
    NCErWbimXMIxLltqJdOYyDhokgTFsS =NCErWbimXMIxLltqJdOYyDhokgTFsB.get('videoid')
    NCErWbimXMIxLltqJdOYyDhokgTFVQ={}
    NCErWbimXMIxLltqJdOYyDhokgTFVQ['plot']=NCErWbimXMIxLltqJdOYyDhokgTFfu
    if NCErWbimXMIxLltqJdOYyDhokgTFfP=='movie':
     NCErWbimXMIxLltqJdOYyDhokgTFfj={'mode':'MOVIE','page':'1','movie_code':NCErWbimXMIxLltqJdOYyDhokgTFGj,'season_code':'-','title':NCErWbimXMIxLltqJdOYyDhokgTFfu,'thumbnail':NCErWbimXMIxLltqJdOYyDhokgTFGe}
     NCErWbimXMIxLltqJdOYyDhokgTFfa=NCErWbimXMIxLltqJdOYyDhokgTFpc
    else:
     if NCErWbimXMIxLltqJdOYyDhokgTFfc==NCErWbimXMIxLltqJdOYyDhokgTFpc or NCErWbimXMIxLltqJdOYyDhokgTFsS==NCErWbimXMIxLltqJdOYyDhokgTFsH:
      NCErWbimXMIxLltqJdOYyDhokgTFfj={'mode':'EPISODE','page':'1','movie_code':NCErWbimXMIxLltqJdOYyDhokgTFGj,'season_code':NCErWbimXMIxLltqJdOYyDhokgTFGj,'title':NCErWbimXMIxLltqJdOYyDhokgTFfu,'thumbnail':NCErWbimXMIxLltqJdOYyDhokgTFGe}
      NCErWbimXMIxLltqJdOYyDhokgTFfa=NCErWbimXMIxLltqJdOYyDhokgTFpG
     else:
      NCErWbimXMIxLltqJdOYyDhokgTFfj={'mode':'MOVIE','movie_code':NCErWbimXMIxLltqJdOYyDhokgTFsS,'season_code':NCErWbimXMIxLltqJdOYyDhokgTFGj,'title':NCErWbimXMIxLltqJdOYyDhokgTFfu,'thumbnail':NCErWbimXMIxLltqJdOYyDhokgTFGe}
      NCErWbimXMIxLltqJdOYyDhokgTFfa=NCErWbimXMIxLltqJdOYyDhokgTFpc
    NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel='',img=NCErWbimXMIxLltqJdOYyDhokgTFGe,infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFVQ,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFfa,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
   NCErWbimXMIxLltqJdOYyDhokgTFVQ={'plot':'시청목록을 삭제합니다.'}
   NCErWbimXMIxLltqJdOYyDhokgTFfu='*** 시청목록 삭제 ***'
   NCErWbimXMIxLltqJdOYyDhokgTFfj={'mode':'MYVIEW_REMOVE','stype':NCErWbimXMIxLltqJdOYyDhokgTFfP}
   NCErWbimXMIxLltqJdOYyDhokgTFcj.add_dir(NCErWbimXMIxLltqJdOYyDhokgTFfu,sublabel='',img='',infoLabels=NCErWbimXMIxLltqJdOYyDhokgTFVQ,isFolder=NCErWbimXMIxLltqJdOYyDhokgTFpc,params=NCErWbimXMIxLltqJdOYyDhokgTFfj)
   xbmcplugin.endOfDirectory(NCErWbimXMIxLltqJdOYyDhokgTFcj._addon_handle,cacheToDisc=NCErWbimXMIxLltqJdOYyDhokgTFpc)
 def logout(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  NCErWbimXMIxLltqJdOYyDhokgTFcn=xbmcgui.Dialog()
  NCErWbimXMIxLltqJdOYyDhokgTFfz=NCErWbimXMIxLltqJdOYyDhokgTFcn.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if NCErWbimXMIxLltqJdOYyDhokgTFfz==NCErWbimXMIxLltqJdOYyDhokgTFpc:sys.exit()
  NCErWbimXMIxLltqJdOYyDhokgTFcj.wininfo_clear()
  if os.path.isfile(NCErWbimXMIxLltqJdOYyDhokgTFcv):os.remove(NCErWbimXMIxLltqJdOYyDhokgTFcv)
  NCErWbimXMIxLltqJdOYyDhokgTFcj.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  NCErWbimXMIxLltqJdOYyDhokgTFfG=xbmcgui.Window(10000)
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_TOKEN','')
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_GUIT','')
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_GUITV','')
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_USERCD','')
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  NCErWbimXMIxLltqJdOYyDhokgTFsn =datetime.datetime.now()
  NCErWbimXMIxLltqJdOYyDhokgTFsz=NCErWbimXMIxLltqJdOYyDhokgTFsn+datetime.timedelta(days=NCErWbimXMIxLltqJdOYyDhokgTFpf(__addon__.getSetting('cache_ttl')))
  NCErWbimXMIxLltqJdOYyDhokgTFfG=xbmcgui.Window(10000)
  NCErWbimXMIxLltqJdOYyDhokgTFsQ={'watcha_token':NCErWbimXMIxLltqJdOYyDhokgTFfG.getProperty('WATCHA_M_TOKEN'),'watcha_guit':NCErWbimXMIxLltqJdOYyDhokgTFfG.getProperty('WATCHA_M_GUIT'),'watcha_guitv':NCErWbimXMIxLltqJdOYyDhokgTFfG.getProperty('WATCHA_M_GUITV'),'watcha_usercd':NCErWbimXMIxLltqJdOYyDhokgTFfG.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':NCErWbimXMIxLltqJdOYyDhokgTFsz.strftime('%Y-%m-%d')}
  try: 
   with NCErWbimXMIxLltqJdOYyDhokgTFpv(NCErWbimXMIxLltqJdOYyDhokgTFcv,'w',-1,'utf-8')as fp:
    NCErWbimXMIxLltqJdOYyDhokgTFsw.dump(NCErWbimXMIxLltqJdOYyDhokgTFsQ,fp)
  except NCErWbimXMIxLltqJdOYyDhokgTFpa as exception:
   NCErWbimXMIxLltqJdOYyDhokgTFpe(exception)
 def cookiefile_check(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  NCErWbimXMIxLltqJdOYyDhokgTFsQ={}
  try: 
   with NCErWbimXMIxLltqJdOYyDhokgTFpv(NCErWbimXMIxLltqJdOYyDhokgTFcv,'r',-1,'utf-8')as fp:
    NCErWbimXMIxLltqJdOYyDhokgTFsQ= NCErWbimXMIxLltqJdOYyDhokgTFsw.load(fp)
  except NCErWbimXMIxLltqJdOYyDhokgTFpa as exception:
   NCErWbimXMIxLltqJdOYyDhokgTFcj.wininfo_clear()
   return NCErWbimXMIxLltqJdOYyDhokgTFpc
  NCErWbimXMIxLltqJdOYyDhokgTFfB =__addon__.getSetting('id')
  NCErWbimXMIxLltqJdOYyDhokgTFfS =__addon__.getSetting('pw')
  NCErWbimXMIxLltqJdOYyDhokgTFsU =__addon__.getSetting('selected_profile')
  NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_id']=base64.standard_b64decode(NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_id']).decode('utf-8')
  NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_pw']=base64.standard_b64decode(NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_pw']).decode('utf-8')
  if NCErWbimXMIxLltqJdOYyDhokgTFfB!=NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_id']or NCErWbimXMIxLltqJdOYyDhokgTFfS!=NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_pw']or NCErWbimXMIxLltqJdOYyDhokgTFsU!=NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_profile']:
   NCErWbimXMIxLltqJdOYyDhokgTFcj.wininfo_clear()
   return NCErWbimXMIxLltqJdOYyDhokgTFpc
  NCErWbimXMIxLltqJdOYyDhokgTFfQ =datetime.datetime.now().date()
  NCErWbimXMIxLltqJdOYyDhokgTFsP =NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_limitdate']
  try:
   NCErWbimXMIxLltqJdOYyDhokgTFfw=datetime.datetime.strptime(NCErWbimXMIxLltqJdOYyDhokgTFsP,'%Y-%m-%d').date()
  except NCErWbimXMIxLltqJdOYyDhokgTFps:
   NCErWbimXMIxLltqJdOYyDhokgTFfw=datetime.datetime(*(time.strptime(NCErWbimXMIxLltqJdOYyDhokgTFsP,'%Y-%m-%d')[0:6])).date()
  if NCErWbimXMIxLltqJdOYyDhokgTFfw<NCErWbimXMIxLltqJdOYyDhokgTFfQ:
   NCErWbimXMIxLltqJdOYyDhokgTFcj.wininfo_clear()
   return NCErWbimXMIxLltqJdOYyDhokgTFpc
  NCErWbimXMIxLltqJdOYyDhokgTFfG=xbmcgui.Window(10000)
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_TOKEN',NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_token'])
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_GUIT',NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_guit'])
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_GUITV',NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_guitv'])
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_USERCD',NCErWbimXMIxLltqJdOYyDhokgTFsQ['watcha_usercd'])
  NCErWbimXMIxLltqJdOYyDhokgTFfG.setProperty('WATCHA_M_LOGINTIME',NCErWbimXMIxLltqJdOYyDhokgTFsP)
  return NCErWbimXMIxLltqJdOYyDhokgTFpG
 def watcha_main(NCErWbimXMIxLltqJdOYyDhokgTFcj):
  NCErWbimXMIxLltqJdOYyDhokgTFsA=NCErWbimXMIxLltqJdOYyDhokgTFcj.main_params.get('mode',NCErWbimXMIxLltqJdOYyDhokgTFsH)
  NCErWbimXMIxLltqJdOYyDhokgTFcj.login_main()
  if NCErWbimXMIxLltqJdOYyDhokgTFsA is NCErWbimXMIxLltqJdOYyDhokgTFsH:
   NCErWbimXMIxLltqJdOYyDhokgTFcj.dp_Main_List()
  elif NCErWbimXMIxLltqJdOYyDhokgTFsA=='SUB_GROUP':
   NCErWbimXMIxLltqJdOYyDhokgTFcj.dp_SubGroup_List(NCErWbimXMIxLltqJdOYyDhokgTFcj.main_params)
  elif NCErWbimXMIxLltqJdOYyDhokgTFsA=='CATEGORY_LIST':
   NCErWbimXMIxLltqJdOYyDhokgTFcj.dp_Category_List(NCErWbimXMIxLltqJdOYyDhokgTFcj.main_params)
  elif NCErWbimXMIxLltqJdOYyDhokgTFsA=='EPISODE':
   NCErWbimXMIxLltqJdOYyDhokgTFcj.dp_Episode_List(NCErWbimXMIxLltqJdOYyDhokgTFcj.main_params)
  elif NCErWbimXMIxLltqJdOYyDhokgTFsA=='ORDER_BY':
   NCErWbimXMIxLltqJdOYyDhokgTFcj.dp_setEpOrderby(NCErWbimXMIxLltqJdOYyDhokgTFcj.main_params)
  elif NCErWbimXMIxLltqJdOYyDhokgTFsA=='SEARCH':
   NCErWbimXMIxLltqJdOYyDhokgTFcj.dp_Search_List(NCErWbimXMIxLltqJdOYyDhokgTFcj.main_params)
  elif NCErWbimXMIxLltqJdOYyDhokgTFsA=='MOVIE':
   NCErWbimXMIxLltqJdOYyDhokgTFcj.play_VIDEO(NCErWbimXMIxLltqJdOYyDhokgTFcj.main_params)
   time.sleep(0.1)
  elif NCErWbimXMIxLltqJdOYyDhokgTFsA=='WATCH':
   NCErWbimXMIxLltqJdOYyDhokgTFcj.dp_Watch_List(NCErWbimXMIxLltqJdOYyDhokgTFcj.main_params)
  elif NCErWbimXMIxLltqJdOYyDhokgTFsA=='MYVIEW_REMOVE':
   NCErWbimXMIxLltqJdOYyDhokgTFcj.dp_WatchList_Delete(NCErWbimXMIxLltqJdOYyDhokgTFcj.main_params)
  elif NCErWbimXMIxLltqJdOYyDhokgTFsA=='LOGOUT':
   NCErWbimXMIxLltqJdOYyDhokgTFcj.logout()
  else:
   NCErWbimXMIxLltqJdOYyDhokgTFsH
# Created by pyminifier (https://github.com/liftoff/pyminifier)
