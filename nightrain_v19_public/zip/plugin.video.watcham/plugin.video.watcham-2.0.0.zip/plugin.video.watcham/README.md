# watchaM-v19
 왓챠 애드온 for Kodi19

- 해상도는 1080p, 720p만 적용됩니다.

- 1080p 적용안될시 조치방법
1. inputstream.adaptive 애드온에서 스트림설정 비디오수동 선택
2. 영화 재생화면에서  비디오설정->화질 변경후 다시 재생하세요



## Version 2.0.0 (2020.10.01)
- python3(kodi 19) 전환
