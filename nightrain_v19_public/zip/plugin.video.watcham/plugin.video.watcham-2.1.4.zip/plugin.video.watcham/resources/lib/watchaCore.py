__author__="NightRain"
zRGmQflWopgEOxjBXtucKIVnHSqrvk=object
zRGmQflWopgEOxjBXtucKIVnHSqrve=None
zRGmQflWopgEOxjBXtucKIVnHSqrvD=False
zRGmQflWopgEOxjBXtucKIVnHSqrvh=True
zRGmQflWopgEOxjBXtucKIVnHSqrvP=Exception
zRGmQflWopgEOxjBXtucKIVnHSqrvs=print
zRGmQflWopgEOxjBXtucKIVnHSqrvY=str
zRGmQflWopgEOxjBXtucKIVnHSqrvA=len
zRGmQflWopgEOxjBXtucKIVnHSqrvM=int
zRGmQflWopgEOxjBXtucKIVnHSqrvL=range
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
class zRGmQflWopgEOxjBXtucKIVnHSqrbC(zRGmQflWopgEOxjBXtucKIVnHSqrvk):
 def __init__(zRGmQflWopgEOxjBXtucKIVnHSqrbT):
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_TOKEN ='' 
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUIT =''
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUITV =''
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_USERCD=''
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.MAIN_DOMAIN ='https://watcha.com'
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.API_DOMAIN ='https://api-mars.watcha.com'
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.EPISODE_LIMIT=20
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.SEARCH_LIMIT =30
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.DEFAULT_HEADER={'user-agent':zRGmQflWopgEOxjBXtucKIVnHSqrbT.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(zRGmQflWopgEOxjBXtucKIVnHSqrbT,jobtype,zRGmQflWopgEOxjBXtucKIVnHSqrbN,payload=zRGmQflWopgEOxjBXtucKIVnHSqrve,params=zRGmQflWopgEOxjBXtucKIVnHSqrve,headers=zRGmQflWopgEOxjBXtucKIVnHSqrve,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrve,redirects=zRGmQflWopgEOxjBXtucKIVnHSqrvD):
  zRGmQflWopgEOxjBXtucKIVnHSqrbv=zRGmQflWopgEOxjBXtucKIVnHSqrbT.DEFAULT_HEADER
  if headers:zRGmQflWopgEOxjBXtucKIVnHSqrbv.update(headers)
  if jobtype=='Get':
   zRGmQflWopgEOxjBXtucKIVnHSqrbU=requests.get(zRGmQflWopgEOxjBXtucKIVnHSqrbN,params=params,headers=zRGmQflWopgEOxjBXtucKIVnHSqrbv,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   zRGmQflWopgEOxjBXtucKIVnHSqrbU=requests.put(zRGmQflWopgEOxjBXtucKIVnHSqrbN,data=payload,params=params,headers=zRGmQflWopgEOxjBXtucKIVnHSqrbv,cookies=cookies,allow_redirects=redirects)
  else:
   zRGmQflWopgEOxjBXtucKIVnHSqrbU=requests.post(zRGmQflWopgEOxjBXtucKIVnHSqrbN,data=payload,params=params,headers=zRGmQflWopgEOxjBXtucKIVnHSqrbv,cookies=cookies,allow_redirects=redirects)
  return zRGmQflWopgEOxjBXtucKIVnHSqrbU
 def SaveCredential(zRGmQflWopgEOxjBXtucKIVnHSqrbT,zRGmQflWopgEOxjBXtucKIVnHSqrbk):
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_TOKEN =zRGmQflWopgEOxjBXtucKIVnHSqrbk.get('watcha_token')
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUIT =zRGmQflWopgEOxjBXtucKIVnHSqrbk.get('watcha_guit')
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUITV =zRGmQflWopgEOxjBXtucKIVnHSqrbk.get('watcha_guitv')
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_USERCD =zRGmQflWopgEOxjBXtucKIVnHSqrbk.get('watcha_usercd')
 def SaveCredential_usercd(zRGmQflWopgEOxjBXtucKIVnHSqrbT,zRGmQflWopgEOxjBXtucKIVnHSqrbe):
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_USERCD=zRGmQflWopgEOxjBXtucKIVnHSqrbe
 def SaveCredential_guitv(zRGmQflWopgEOxjBXtucKIVnHSqrbT,zRGmQflWopgEOxjBXtucKIVnHSqrbD,zRGmQflWopgEOxjBXtucKIVnHSqrbh):
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUITV=zRGmQflWopgEOxjBXtucKIVnHSqrbD
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_TOKEN=zRGmQflWopgEOxjBXtucKIVnHSqrbh 
 def ClearCredential(zRGmQflWopgEOxjBXtucKIVnHSqrbT):
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_TOKEN ='' 
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUIT =''
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUITV =''
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_USERCD=''
 def LoadCredential(zRGmQflWopgEOxjBXtucKIVnHSqrbT):
  zRGmQflWopgEOxjBXtucKIVnHSqrbk={'watcha_token':zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_TOKEN,'watcha_guit':zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUIT,'watcha_guitv':zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUITV,'watcha_usercd':zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_USERCD}
  return zRGmQflWopgEOxjBXtucKIVnHSqrbk
 def makeDefaultCookies(zRGmQflWopgEOxjBXtucKIVnHSqrbT):
  zRGmQflWopgEOxjBXtucKIVnHSqrbP={'_s_guit':zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUIT,'_guinness-premium_session':zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_TOKEN}
  if zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUITV:
   zRGmQflWopgEOxjBXtucKIVnHSqrbP['_s_guitv']=zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_GUITV
  return zRGmQflWopgEOxjBXtucKIVnHSqrbP
 def GetCredential(zRGmQflWopgEOxjBXtucKIVnHSqrbT,user_id,user_pw,user_pf):
  zRGmQflWopgEOxjBXtucKIVnHSqrbs=zRGmQflWopgEOxjBXtucKIVnHSqrvD
  zRGmQflWopgEOxjBXtucKIVnHSqrbY=zRGmQflWopgEOxjBXtucKIVnHSqrbd='-'
  try:
   zRGmQflWopgEOxjBXtucKIVnHSqrbA=zRGmQflWopgEOxjBXtucKIVnHSqrbT.API_DOMAIN+'/api/session'
   zRGmQflWopgEOxjBXtucKIVnHSqrbM={'email':user_id,'password':user_pw}
   zRGmQflWopgEOxjBXtucKIVnHSqrbL={'accept':'application/vnd.frograms+json;version=4'}
   zRGmQflWopgEOxjBXtucKIVnHSqrbF=zRGmQflWopgEOxjBXtucKIVnHSqrbT.callRequestCookies('Post',zRGmQflWopgEOxjBXtucKIVnHSqrbA,payload=zRGmQflWopgEOxjBXtucKIVnHSqrbM,params=zRGmQflWopgEOxjBXtucKIVnHSqrve,headers=zRGmQflWopgEOxjBXtucKIVnHSqrbL,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrve)
   for zRGmQflWopgEOxjBXtucKIVnHSqrbi in zRGmQflWopgEOxjBXtucKIVnHSqrbF.cookies:
    if zRGmQflWopgEOxjBXtucKIVnHSqrbi.name=='_guinness-premium_session':
     zRGmQflWopgEOxjBXtucKIVnHSqrbd=zRGmQflWopgEOxjBXtucKIVnHSqrbi.value
    elif zRGmQflWopgEOxjBXtucKIVnHSqrbi.name=='_s_guit':
     zRGmQflWopgEOxjBXtucKIVnHSqrbY=zRGmQflWopgEOxjBXtucKIVnHSqrbi.value
   if zRGmQflWopgEOxjBXtucKIVnHSqrbd:zRGmQflWopgEOxjBXtucKIVnHSqrbs=zRGmQflWopgEOxjBXtucKIVnHSqrvh
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   zRGmQflWopgEOxjBXtucKIVnHSqrvs(exception)
   zRGmQflWopgEOxjBXtucKIVnHSqrbY=zRGmQflWopgEOxjBXtucKIVnHSqrbd='' 
  zRGmQflWopgEOxjBXtucKIVnHSqrbk={'watcha_guit':zRGmQflWopgEOxjBXtucKIVnHSqrbY,'watcha_token':zRGmQflWopgEOxjBXtucKIVnHSqrbd,'watcha_guitv':'','watcha_usercd':''}
  zRGmQflWopgEOxjBXtucKIVnHSqrbT.SaveCredential(zRGmQflWopgEOxjBXtucKIVnHSqrbk)
  try:
   zRGmQflWopgEOxjBXtucKIVnHSqrba=zRGmQflWopgEOxjBXtucKIVnHSqrbT.GetProfilesList()
   zRGmQflWopgEOxjBXtucKIVnHSqrbJ =zRGmQflWopgEOxjBXtucKIVnHSqrba[user_pf]
   zRGmQflWopgEOxjBXtucKIVnHSqrbT.SaveCredential_usercd(zRGmQflWopgEOxjBXtucKIVnHSqrbJ)
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   zRGmQflWopgEOxjBXtucKIVnHSqrvs(exception)
   zRGmQflWopgEOxjBXtucKIVnHSqrbT.ClearCredential()
   return zRGmQflWopgEOxjBXtucKIVnHSqrvD
  if user_pf!=0:
   zRGmQflWopgEOxjBXtucKIVnHSqrbD,zRGmQflWopgEOxjBXtucKIVnHSqrbh=zRGmQflWopgEOxjBXtucKIVnHSqrbT.GetProfilesConvert(zRGmQflWopgEOxjBXtucKIVnHSqrbJ)
   zRGmQflWopgEOxjBXtucKIVnHSqrbT.SaveCredential_guitv(zRGmQflWopgEOxjBXtucKIVnHSqrbD,zRGmQflWopgEOxjBXtucKIVnHSqrbh)
  return zRGmQflWopgEOxjBXtucKIVnHSqrbs
 def GetSubGroupList(zRGmQflWopgEOxjBXtucKIVnHSqrbT,stype):
  zRGmQflWopgEOxjBXtucKIVnHSqrbw=[]
  try:
   zRGmQflWopgEOxjBXtucKIVnHSqrby ='/api/categories.json'
   zRGmQflWopgEOxjBXtucKIVnHSqrbN=zRGmQflWopgEOxjBXtucKIVnHSqrbT.API_DOMAIN+zRGmQflWopgEOxjBXtucKIVnHSqrby
   zRGmQflWopgEOxjBXtucKIVnHSqrbF=zRGmQflWopgEOxjBXtucKIVnHSqrbT.callRequestCookies('Get',zRGmQflWopgEOxjBXtucKIVnHSqrbN,payload=zRGmQflWopgEOxjBXtucKIVnHSqrve,params=zRGmQflWopgEOxjBXtucKIVnHSqrve,headers=zRGmQflWopgEOxjBXtucKIVnHSqrve,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrve)
   zRGmQflWopgEOxjBXtucKIVnHSqrCb=json.loads(zRGmQflWopgEOxjBXtucKIVnHSqrbF.text)
   if not('genres' in zRGmQflWopgEOxjBXtucKIVnHSqrCb):return zRGmQflWopgEOxjBXtucKIVnHSqrbw
   if stype=='genres':
    zRGmQflWopgEOxjBXtucKIVnHSqrCT=zRGmQflWopgEOxjBXtucKIVnHSqrCb['genres']
   else:
    zRGmQflWopgEOxjBXtucKIVnHSqrCT=zRGmQflWopgEOxjBXtucKIVnHSqrCb['tags']
   for zRGmQflWopgEOxjBXtucKIVnHSqrCv in zRGmQflWopgEOxjBXtucKIVnHSqrCT:
    zRGmQflWopgEOxjBXtucKIVnHSqrCU=zRGmQflWopgEOxjBXtucKIVnHSqrCv['name']
    zRGmQflWopgEOxjBXtucKIVnHSqrCk =zRGmQflWopgEOxjBXtucKIVnHSqrCv['api_path']
    zRGmQflWopgEOxjBXtucKIVnHSqrCe =zRGmQflWopgEOxjBXtucKIVnHSqrCv['entity']['id']
    zRGmQflWopgEOxjBXtucKIVnHSqrCD={'group_name':zRGmQflWopgEOxjBXtucKIVnHSqrCU,'api_path':zRGmQflWopgEOxjBXtucKIVnHSqrCk,'tag_id':zRGmQflWopgEOxjBXtucKIVnHSqrvY(zRGmQflWopgEOxjBXtucKIVnHSqrCe)}
    zRGmQflWopgEOxjBXtucKIVnHSqrbw.append(zRGmQflWopgEOxjBXtucKIVnHSqrCD)
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   zRGmQflWopgEOxjBXtucKIVnHSqrvs(exception)
  return zRGmQflWopgEOxjBXtucKIVnHSqrbw
 def GetCategoryList(zRGmQflWopgEOxjBXtucKIVnHSqrbT,stype,zRGmQflWopgEOxjBXtucKIVnHSqrCe,zRGmQflWopgEOxjBXtucKIVnHSqrCk,page_int,in_sort):
  zRGmQflWopgEOxjBXtucKIVnHSqrbw=[]
  zRGmQflWopgEOxjBXtucKIVnHSqrCh=zRGmQflWopgEOxjBXtucKIVnHSqrvD
  zRGmQflWopgEOxjBXtucKIVnHSqrCP={}
  try:
   if 'categories' in zRGmQflWopgEOxjBXtucKIVnHSqrCk:
    zRGmQflWopgEOxjBXtucKIVnHSqrby ='/api/categories/contents.json'
    if stype=='genres':
     zRGmQflWopgEOxjBXtucKIVnHSqrCP['genre']=zRGmQflWopgEOxjBXtucKIVnHSqrCe
    else:
     zRGmQflWopgEOxjBXtucKIVnHSqrCP['tag'] =zRGmQflWopgEOxjBXtucKIVnHSqrCe
    zRGmQflWopgEOxjBXtucKIVnHSqrCP['order']=in_sort 
    if page_int>1:
     zRGmQflWopgEOxjBXtucKIVnHSqrCP['page']=zRGmQflWopgEOxjBXtucKIVnHSqrvY(page_int-1)
   else: 
    zRGmQflWopgEOxjBXtucKIVnHSqrby ='/api/'+zRGmQflWopgEOxjBXtucKIVnHSqrCk+'.json'
    if page_int>1:
     zRGmQflWopgEOxjBXtucKIVnHSqrCP['page']=zRGmQflWopgEOxjBXtucKIVnHSqrvY(page_int)
   zRGmQflWopgEOxjBXtucKIVnHSqrbN=zRGmQflWopgEOxjBXtucKIVnHSqrbT.API_DOMAIN+zRGmQflWopgEOxjBXtucKIVnHSqrby
   zRGmQflWopgEOxjBXtucKIVnHSqrbi=zRGmQflWopgEOxjBXtucKIVnHSqrbT.makeDefaultCookies()
   zRGmQflWopgEOxjBXtucKIVnHSqrbF=zRGmQflWopgEOxjBXtucKIVnHSqrbT.callRequestCookies('Get',zRGmQflWopgEOxjBXtucKIVnHSqrbN,payload=zRGmQflWopgEOxjBXtucKIVnHSqrve,params=zRGmQflWopgEOxjBXtucKIVnHSqrCP,headers=zRGmQflWopgEOxjBXtucKIVnHSqrve,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrbi)
   zRGmQflWopgEOxjBXtucKIVnHSqrCb=json.loads(zRGmQflWopgEOxjBXtucKIVnHSqrbF.text)
   if not('contents' in zRGmQflWopgEOxjBXtucKIVnHSqrCb):return zRGmQflWopgEOxjBXtucKIVnHSqrbw,zRGmQflWopgEOxjBXtucKIVnHSqrCh
   zRGmQflWopgEOxjBXtucKIVnHSqrCT=zRGmQflWopgEOxjBXtucKIVnHSqrCb['contents']
   zRGmQflWopgEOxjBXtucKIVnHSqrCh=zRGmQflWopgEOxjBXtucKIVnHSqrCb['meta']['has_next']
   for zRGmQflWopgEOxjBXtucKIVnHSqrCv in zRGmQflWopgEOxjBXtucKIVnHSqrCT:
    zRGmQflWopgEOxjBXtucKIVnHSqrCs =zRGmQflWopgEOxjBXtucKIVnHSqrCv['code']
    zRGmQflWopgEOxjBXtucKIVnHSqrCY=zRGmQflWopgEOxjBXtucKIVnHSqrCv['content_type']
    zRGmQflWopgEOxjBXtucKIVnHSqrCA =zRGmQflWopgEOxjBXtucKIVnHSqrCv['title']
    zRGmQflWopgEOxjBXtucKIVnHSqrCM =zRGmQflWopgEOxjBXtucKIVnHSqrCv['story']
    zRGmQflWopgEOxjBXtucKIVnHSqrCL=tmp_thumb=tmp_fanart=''
    if zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('poster') !=zRGmQflWopgEOxjBXtucKIVnHSqrve:zRGmQflWopgEOxjBXtucKIVnHSqrCL=zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('poster').get('original')
    if zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('stillcut')!=zRGmQflWopgEOxjBXtucKIVnHSqrve:tmp_thumb =zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('stillcut').get('large')
    if zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('thumbnail')!=zRGmQflWopgEOxjBXtucKIVnHSqrve:tmp_fanart=zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('thumbnail').get('large')
    if tmp_fanart=='' :tmp_fanart=tmp_thumb
    zRGmQflWopgEOxjBXtucKIVnHSqrCF={'thumb':tmp_thumb,'poster':zRGmQflWopgEOxjBXtucKIVnHSqrCL,'fanart':tmp_fanart}
    zRGmQflWopgEOxjBXtucKIVnHSqrCi =zRGmQflWopgEOxjBXtucKIVnHSqrCv['year']
    zRGmQflWopgEOxjBXtucKIVnHSqrCd =zRGmQflWopgEOxjBXtucKIVnHSqrCv['film_rating_code']
    zRGmQflWopgEOxjBXtucKIVnHSqrCa=zRGmQflWopgEOxjBXtucKIVnHSqrCv['film_rating_short']
    zRGmQflWopgEOxjBXtucKIVnHSqrCJ =zRGmQflWopgEOxjBXtucKIVnHSqrCv['film_rating_long']
    if zRGmQflWopgEOxjBXtucKIVnHSqrCY=='movies':
     zRGmQflWopgEOxjBXtucKIVnHSqrCw =zRGmQflWopgEOxjBXtucKIVnHSqrCv['duration']
    else:
     zRGmQflWopgEOxjBXtucKIVnHSqrCw ='0'
    zRGmQflWopgEOxjBXtucKIVnHSqrCD={'code':zRGmQflWopgEOxjBXtucKIVnHSqrCs,'content_type':zRGmQflWopgEOxjBXtucKIVnHSqrCY,'title':zRGmQflWopgEOxjBXtucKIVnHSqrCA,'story':zRGmQflWopgEOxjBXtucKIVnHSqrCM,'thumbnail':zRGmQflWopgEOxjBXtucKIVnHSqrCF,'year':zRGmQflWopgEOxjBXtucKIVnHSqrCi,'film_rating_code':zRGmQflWopgEOxjBXtucKIVnHSqrCd,'film_rating_short':zRGmQflWopgEOxjBXtucKIVnHSqrCa,'film_rating_long':zRGmQflWopgEOxjBXtucKIVnHSqrCJ,'duration':zRGmQflWopgEOxjBXtucKIVnHSqrCw}
    zRGmQflWopgEOxjBXtucKIVnHSqrbw.append(zRGmQflWopgEOxjBXtucKIVnHSqrCD)
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   zRGmQflWopgEOxjBXtucKIVnHSqrvs(exception)
  return zRGmQflWopgEOxjBXtucKIVnHSqrbw,zRGmQflWopgEOxjBXtucKIVnHSqrCh
 def GetCategoryList_morepage(zRGmQflWopgEOxjBXtucKIVnHSqrbT,stype,zRGmQflWopgEOxjBXtucKIVnHSqrCe,zRGmQflWopgEOxjBXtucKIVnHSqrCk,page_int,in_sort):
  zRGmQflWopgEOxjBXtucKIVnHSqrCh=zRGmQflWopgEOxjBXtucKIVnHSqrvD
  if not('categories' in zRGmQflWopgEOxjBXtucKIVnHSqrCk):return zRGmQflWopgEOxjBXtucKIVnHSqrvh
  try:
   zRGmQflWopgEOxjBXtucKIVnHSqrby ='/api/categories/contents.json'
   zRGmQflWopgEOxjBXtucKIVnHSqrbN=zRGmQflWopgEOxjBXtucKIVnHSqrbT.API_DOMAIN+zRGmQflWopgEOxjBXtucKIVnHSqrby
   zRGmQflWopgEOxjBXtucKIVnHSqrCP={}
   if stype=='genres':
    zRGmQflWopgEOxjBXtucKIVnHSqrCP['genre']=zRGmQflWopgEOxjBXtucKIVnHSqrCe
   else:
    zRGmQflWopgEOxjBXtucKIVnHSqrCP['tag'] =zRGmQflWopgEOxjBXtucKIVnHSqrCe
   zRGmQflWopgEOxjBXtucKIVnHSqrCP['order']=in_sort 
   if page_int>1:
    zRGmQflWopgEOxjBXtucKIVnHSqrCP['page']=zRGmQflWopgEOxjBXtucKIVnHSqrvY(page_int-1)
   zRGmQflWopgEOxjBXtucKIVnHSqrbF=zRGmQflWopgEOxjBXtucKIVnHSqrbT.callRequestCookies('Get',zRGmQflWopgEOxjBXtucKIVnHSqrbN,payload=zRGmQflWopgEOxjBXtucKIVnHSqrve,params=zRGmQflWopgEOxjBXtucKIVnHSqrCP,headers=zRGmQflWopgEOxjBXtucKIVnHSqrve,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrve)
   zRGmQflWopgEOxjBXtucKIVnHSqrCb=json.loads(zRGmQflWopgEOxjBXtucKIVnHSqrbF.text)
   zRGmQflWopgEOxjBXtucKIVnHSqrCh=zRGmQflWopgEOxjBXtucKIVnHSqrCb['meta']['has_next']
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   zRGmQflWopgEOxjBXtucKIVnHSqrvs(exception)
  return zRGmQflWopgEOxjBXtucKIVnHSqrCh
 def GetProgramInfo(zRGmQflWopgEOxjBXtucKIVnHSqrbT,program_code):
  zRGmQflWopgEOxjBXtucKIVnHSqrCy={}
  try:
   zRGmQflWopgEOxjBXtucKIVnHSqrby ='/api/contents/'+program_code
   zRGmQflWopgEOxjBXtucKIVnHSqrbN=zRGmQflWopgEOxjBXtucKIVnHSqrbT.API_DOMAIN+zRGmQflWopgEOxjBXtucKIVnHSqrby
   zRGmQflWopgEOxjBXtucKIVnHSqrbF=zRGmQflWopgEOxjBXtucKIVnHSqrbT.callRequestCookies('Get',zRGmQflWopgEOxjBXtucKIVnHSqrbN,payload=zRGmQflWopgEOxjBXtucKIVnHSqrve,params=zRGmQflWopgEOxjBXtucKIVnHSqrve,headers=zRGmQflWopgEOxjBXtucKIVnHSqrve,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrve)
   zRGmQflWopgEOxjBXtucKIVnHSqrCb=json.loads(zRGmQflWopgEOxjBXtucKIVnHSqrbF.text)
   zRGmQflWopgEOxjBXtucKIVnHSqrCN=img_clearlogo=''
   zRGmQflWopgEOxjBXtucKIVnHSqrCN=zRGmQflWopgEOxjBXtucKIVnHSqrCb.get('poster').get('original')
   if zRGmQflWopgEOxjBXtucKIVnHSqrvA(zRGmQflWopgEOxjBXtucKIVnHSqrCb.get('title_logos'))>0:img_clearlogo=zRGmQflWopgEOxjBXtucKIVnHSqrCb.get('title_logos')[0].get('src')
   zRGmQflWopgEOxjBXtucKIVnHSqrCy={'imgPoster':zRGmQflWopgEOxjBXtucKIVnHSqrCN,'imgClearlogo':img_clearlogo}
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   zRGmQflWopgEOxjBXtucKIVnHSqrvs(exception)
  return zRGmQflWopgEOxjBXtucKIVnHSqrCy
 def GetEpisodoList(zRGmQflWopgEOxjBXtucKIVnHSqrbT,program_code,page_int,orderby='asc'):
  zRGmQflWopgEOxjBXtucKIVnHSqrbw=[]
  zRGmQflWopgEOxjBXtucKIVnHSqrCh=zRGmQflWopgEOxjBXtucKIVnHSqrvD
  zRGmQflWopgEOxjBXtucKIVnHSqrTb=''
  try:
   zRGmQflWopgEOxjBXtucKIVnHSqrby ='/api/contents/'+program_code+'/tv_episodes.json'
   zRGmQflWopgEOxjBXtucKIVnHSqrbN=zRGmQflWopgEOxjBXtucKIVnHSqrbT.API_DOMAIN+zRGmQflWopgEOxjBXtucKIVnHSqrby
   zRGmQflWopgEOxjBXtucKIVnHSqrCP={'all':'true'}
   zRGmQflWopgEOxjBXtucKIVnHSqrbF=zRGmQflWopgEOxjBXtucKIVnHSqrbT.callRequestCookies('Get',zRGmQflWopgEOxjBXtucKIVnHSqrbN,payload=zRGmQflWopgEOxjBXtucKIVnHSqrve,params=zRGmQflWopgEOxjBXtucKIVnHSqrCP,headers=zRGmQflWopgEOxjBXtucKIVnHSqrve,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrve)
   zRGmQflWopgEOxjBXtucKIVnHSqrCb=json.loads(zRGmQflWopgEOxjBXtucKIVnHSqrbF.text)
   if not('tv_episode_codes' in zRGmQflWopgEOxjBXtucKIVnHSqrCb):return zRGmQflWopgEOxjBXtucKIVnHSqrbw,zRGmQflWopgEOxjBXtucKIVnHSqrCh
   zRGmQflWopgEOxjBXtucKIVnHSqrCT=zRGmQflWopgEOxjBXtucKIVnHSqrCb['tv_episode_codes']
   zRGmQflWopgEOxjBXtucKIVnHSqrTC=zRGmQflWopgEOxjBXtucKIVnHSqrvA(zRGmQflWopgEOxjBXtucKIVnHSqrCT)
   zRGmQflWopgEOxjBXtucKIVnHSqrTv =zRGmQflWopgEOxjBXtucKIVnHSqrvM(zRGmQflWopgEOxjBXtucKIVnHSqrTC//(zRGmQflWopgEOxjBXtucKIVnHSqrbT.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    zRGmQflWopgEOxjBXtucKIVnHSqrTU =(zRGmQflWopgEOxjBXtucKIVnHSqrTC-1)-((page_int-1)*zRGmQflWopgEOxjBXtucKIVnHSqrbT.EPISODE_LIMIT)
   else:
    zRGmQflWopgEOxjBXtucKIVnHSqrTU =(page_int-1)*zRGmQflWopgEOxjBXtucKIVnHSqrbT.EPISODE_LIMIT
   for i in zRGmQflWopgEOxjBXtucKIVnHSqrvL(zRGmQflWopgEOxjBXtucKIVnHSqrbT.EPISODE_LIMIT):
    if orderby=='desc':
     zRGmQflWopgEOxjBXtucKIVnHSqrTk=zRGmQflWopgEOxjBXtucKIVnHSqrTU-i
     if zRGmQflWopgEOxjBXtucKIVnHSqrTk<0:break
    else:
     zRGmQflWopgEOxjBXtucKIVnHSqrTk=zRGmQflWopgEOxjBXtucKIVnHSqrTU+i
     if zRGmQflWopgEOxjBXtucKIVnHSqrTk>=zRGmQflWopgEOxjBXtucKIVnHSqrTC:break
    if zRGmQflWopgEOxjBXtucKIVnHSqrTb!='':zRGmQflWopgEOxjBXtucKIVnHSqrTb+=','
    zRGmQflWopgEOxjBXtucKIVnHSqrTb+=zRGmQflWopgEOxjBXtucKIVnHSqrCT[zRGmQflWopgEOxjBXtucKIVnHSqrTk]
   if zRGmQflWopgEOxjBXtucKIVnHSqrTv>page_int:zRGmQflWopgEOxjBXtucKIVnHSqrCh=zRGmQflWopgEOxjBXtucKIVnHSqrvh
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   zRGmQflWopgEOxjBXtucKIVnHSqrvs(exception)
  zRGmQflWopgEOxjBXtucKIVnHSqrTe=zRGmQflWopgEOxjBXtucKIVnHSqrbT.GetProgramInfo(program_code)
  try:
   zRGmQflWopgEOxjBXtucKIVnHSqrbN=zRGmQflWopgEOxjBXtucKIVnHSqrbT.API_DOMAIN+zRGmQflWopgEOxjBXtucKIVnHSqrby
   zRGmQflWopgEOxjBXtucKIVnHSqrCP={'codes':zRGmQflWopgEOxjBXtucKIVnHSqrTb}
   zRGmQflWopgEOxjBXtucKIVnHSqrbF=zRGmQflWopgEOxjBXtucKIVnHSqrbT.callRequestCookies('Get',zRGmQflWopgEOxjBXtucKIVnHSqrbN,payload=zRGmQflWopgEOxjBXtucKIVnHSqrve,params=zRGmQflWopgEOxjBXtucKIVnHSqrCP,headers=zRGmQflWopgEOxjBXtucKIVnHSqrve,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrve)
   zRGmQflWopgEOxjBXtucKIVnHSqrCb=json.loads(zRGmQflWopgEOxjBXtucKIVnHSqrbF.text)
   if not('tv_episodes' in zRGmQflWopgEOxjBXtucKIVnHSqrCb):return zRGmQflWopgEOxjBXtucKIVnHSqrbw
   zRGmQflWopgEOxjBXtucKIVnHSqrCT=zRGmQflWopgEOxjBXtucKIVnHSqrCb['tv_episodes']
   for zRGmQflWopgEOxjBXtucKIVnHSqrCv in zRGmQflWopgEOxjBXtucKIVnHSqrCT:
    zRGmQflWopgEOxjBXtucKIVnHSqrCs =zRGmQflWopgEOxjBXtucKIVnHSqrCv['code']
    if zRGmQflWopgEOxjBXtucKIVnHSqrCv['title']:
     zRGmQflWopgEOxjBXtucKIVnHSqrCA =zRGmQflWopgEOxjBXtucKIVnHSqrCv['title']
    else:
     zRGmQflWopgEOxjBXtucKIVnHSqrCA =''
    zRGmQflWopgEOxjBXtucKIVnHSqrCL=tmp_thumb=tmp_fanart=zRGmQflWopgEOxjBXtucKIVnHSqrTD=''
    zRGmQflWopgEOxjBXtucKIVnHSqrCL =zRGmQflWopgEOxjBXtucKIVnHSqrTe.get('imgPoster')
    zRGmQflWopgEOxjBXtucKIVnHSqrTD=zRGmQflWopgEOxjBXtucKIVnHSqrTe.get('imgClearlogo')
    if zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('stillcut') !=zRGmQflWopgEOxjBXtucKIVnHSqrve:tmp_thumb =zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('stillcut').get('large')
    if zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('tv_season_stillcut')!=zRGmQflWopgEOxjBXtucKIVnHSqrve:tmp_fanart=zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('tv_season_stillcut').get('large')
    zRGmQflWopgEOxjBXtucKIVnHSqrCF={'thumb':tmp_thumb,'poster':zRGmQflWopgEOxjBXtucKIVnHSqrCL,'fanart':tmp_fanart,'clearlogo':zRGmQflWopgEOxjBXtucKIVnHSqrTD}
    zRGmQflWopgEOxjBXtucKIVnHSqrTh =zRGmQflWopgEOxjBXtucKIVnHSqrCv['display_number']
    zRGmQflWopgEOxjBXtucKIVnHSqrTP=zRGmQflWopgEOxjBXtucKIVnHSqrCv['tv_season_title']
    zRGmQflWopgEOxjBXtucKIVnHSqrCw =zRGmQflWopgEOxjBXtucKIVnHSqrCv['duration']
    try:
     zRGmQflWopgEOxjBXtucKIVnHSqrTs=zRGmQflWopgEOxjBXtucKIVnHSqrCv['episode_number']
    except:
     zRGmQflWopgEOxjBXtucKIVnHSqrTs='0'
    zRGmQflWopgEOxjBXtucKIVnHSqrCD={'code':zRGmQflWopgEOxjBXtucKIVnHSqrCs,'title':zRGmQflWopgEOxjBXtucKIVnHSqrCA,'thumbnail':zRGmQflWopgEOxjBXtucKIVnHSqrCF,'display_num':zRGmQflWopgEOxjBXtucKIVnHSqrTh,'season_title':zRGmQflWopgEOxjBXtucKIVnHSqrTP,'duration':zRGmQflWopgEOxjBXtucKIVnHSqrCw,'episode_number':zRGmQflWopgEOxjBXtucKIVnHSqrTs}
    zRGmQflWopgEOxjBXtucKIVnHSqrbw.append(zRGmQflWopgEOxjBXtucKIVnHSqrCD)
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   zRGmQflWopgEOxjBXtucKIVnHSqrvs(exception)
  return zRGmQflWopgEOxjBXtucKIVnHSqrbw,zRGmQflWopgEOxjBXtucKIVnHSqrCh
 def GetSearchList(zRGmQflWopgEOxjBXtucKIVnHSqrbT,search_key,page_int):
  zRGmQflWopgEOxjBXtucKIVnHSqrTY=[]
  zRGmQflWopgEOxjBXtucKIVnHSqrCh=zRGmQflWopgEOxjBXtucKIVnHSqrvD
  try:
   zRGmQflWopgEOxjBXtucKIVnHSqrby ='/api/search.json'
   zRGmQflWopgEOxjBXtucKIVnHSqrbN=zRGmQflWopgEOxjBXtucKIVnHSqrbT.API_DOMAIN+zRGmQflWopgEOxjBXtucKIVnHSqrby
   zRGmQflWopgEOxjBXtucKIVnHSqrCP={'query':search_key,'page':zRGmQflWopgEOxjBXtucKIVnHSqrvY(page_int),'per':zRGmQflWopgEOxjBXtucKIVnHSqrvY(zRGmQflWopgEOxjBXtucKIVnHSqrbT.SEARCH_LIMIT),'exclude':'limited'}
   zRGmQflWopgEOxjBXtucKIVnHSqrbF=zRGmQflWopgEOxjBXtucKIVnHSqrbT.callRequestCookies('Get',zRGmQflWopgEOxjBXtucKIVnHSqrbN,payload=zRGmQflWopgEOxjBXtucKIVnHSqrve,params=zRGmQflWopgEOxjBXtucKIVnHSqrCP,headers=zRGmQflWopgEOxjBXtucKIVnHSqrve,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrve)
   zRGmQflWopgEOxjBXtucKIVnHSqrCb=json.loads(zRGmQflWopgEOxjBXtucKIVnHSqrbF.text)
   if not('results' in zRGmQflWopgEOxjBXtucKIVnHSqrCb):return zRGmQflWopgEOxjBXtucKIVnHSqrTY,zRGmQflWopgEOxjBXtucKIVnHSqrCh
   zRGmQflWopgEOxjBXtucKIVnHSqrCT=zRGmQflWopgEOxjBXtucKIVnHSqrCb['results']
   zRGmQflWopgEOxjBXtucKIVnHSqrCh=zRGmQflWopgEOxjBXtucKIVnHSqrCb['meta']['has_next']
   for zRGmQflWopgEOxjBXtucKIVnHSqrCv in zRGmQflWopgEOxjBXtucKIVnHSqrCT:
    zRGmQflWopgEOxjBXtucKIVnHSqrCs =zRGmQflWopgEOxjBXtucKIVnHSqrCv['code']
    zRGmQflWopgEOxjBXtucKIVnHSqrCY=zRGmQflWopgEOxjBXtucKIVnHSqrCv['content_type']
    zRGmQflWopgEOxjBXtucKIVnHSqrCA =zRGmQflWopgEOxjBXtucKIVnHSqrCv['title']
    zRGmQflWopgEOxjBXtucKIVnHSqrCM =zRGmQflWopgEOxjBXtucKIVnHSqrCv['story']
    zRGmQflWopgEOxjBXtucKIVnHSqrCL=tmp_thumb=tmp_fanart=''
    if zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('poster') !=zRGmQflWopgEOxjBXtucKIVnHSqrve:zRGmQflWopgEOxjBXtucKIVnHSqrCL=zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('poster').get('original')
    if zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('stillcut')!=zRGmQflWopgEOxjBXtucKIVnHSqrve:tmp_thumb =zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('stillcut').get('large')
    if zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('thumbnail')!=zRGmQflWopgEOxjBXtucKIVnHSqrve:tmp_fanart=zRGmQflWopgEOxjBXtucKIVnHSqrCv.get('thumbnail').get('large')
    if tmp_fanart=='' :tmp_fanart=tmp_thumb
    zRGmQflWopgEOxjBXtucKIVnHSqrCF={'thumb':tmp_thumb,'poster':zRGmQflWopgEOxjBXtucKIVnHSqrCL,'fanart':tmp_fanart}
    zRGmQflWopgEOxjBXtucKIVnHSqrCi =zRGmQflWopgEOxjBXtucKIVnHSqrCv['year']
    zRGmQflWopgEOxjBXtucKIVnHSqrCd =zRGmQflWopgEOxjBXtucKIVnHSqrCv['film_rating_code']
    zRGmQflWopgEOxjBXtucKIVnHSqrCa=zRGmQflWopgEOxjBXtucKIVnHSqrCv['film_rating_short']
    zRGmQflWopgEOxjBXtucKIVnHSqrCJ =zRGmQflWopgEOxjBXtucKIVnHSqrCv['film_rating_long']
    if zRGmQflWopgEOxjBXtucKIVnHSqrCY=='movies':
     zRGmQflWopgEOxjBXtucKIVnHSqrCw =zRGmQflWopgEOxjBXtucKIVnHSqrCv['duration']
    else:
     zRGmQflWopgEOxjBXtucKIVnHSqrCw ='0'
    zRGmQflWopgEOxjBXtucKIVnHSqrCD={'code':zRGmQflWopgEOxjBXtucKIVnHSqrCs,'content_type':zRGmQflWopgEOxjBXtucKIVnHSqrCY,'title':zRGmQflWopgEOxjBXtucKIVnHSqrCA,'story':zRGmQflWopgEOxjBXtucKIVnHSqrCM,'thumbnail':zRGmQflWopgEOxjBXtucKIVnHSqrCF,'year':zRGmQflWopgEOxjBXtucKIVnHSqrCi,'film_rating_code':zRGmQflWopgEOxjBXtucKIVnHSqrCd,'film_rating_short':zRGmQflWopgEOxjBXtucKIVnHSqrCa,'film_rating_long':zRGmQflWopgEOxjBXtucKIVnHSqrCJ,'duration':zRGmQflWopgEOxjBXtucKIVnHSqrCw}
    zRGmQflWopgEOxjBXtucKIVnHSqrTY.append(zRGmQflWopgEOxjBXtucKIVnHSqrCD)
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   zRGmQflWopgEOxjBXtucKIVnHSqrvs(exception)
  return zRGmQflWopgEOxjBXtucKIVnHSqrTY,zRGmQflWopgEOxjBXtucKIVnHSqrCh
 def GetProfilesList(zRGmQflWopgEOxjBXtucKIVnHSqrbT):
  zRGmQflWopgEOxjBXtucKIVnHSqrba=[]
  try:
   zRGmQflWopgEOxjBXtucKIVnHSqrby ='/manage_profiles'
   zRGmQflWopgEOxjBXtucKIVnHSqrbN=zRGmQflWopgEOxjBXtucKIVnHSqrbT.MAIN_DOMAIN+zRGmQflWopgEOxjBXtucKIVnHSqrby
   zRGmQflWopgEOxjBXtucKIVnHSqrbi=zRGmQflWopgEOxjBXtucKIVnHSqrbT.makeDefaultCookies()
   zRGmQflWopgEOxjBXtucKIVnHSqrbF=zRGmQflWopgEOxjBXtucKIVnHSqrbT.callRequestCookies('Get',zRGmQflWopgEOxjBXtucKIVnHSqrbN,payload=zRGmQflWopgEOxjBXtucKIVnHSqrve,params=zRGmQflWopgEOxjBXtucKIVnHSqrve,headers=zRGmQflWopgEOxjBXtucKIVnHSqrve,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrbi,redirects=zRGmQflWopgEOxjBXtucKIVnHSqrvh)
   zRGmQflWopgEOxjBXtucKIVnHSqrTA=zRGmQflWopgEOxjBXtucKIVnHSqrbF.text
   zRGmQflWopgEOxjBXtucKIVnHSqrTM =re.findall('/api/users/me.{5000}',zRGmQflWopgEOxjBXtucKIVnHSqrTA)[0]
   zRGmQflWopgEOxjBXtucKIVnHSqrTM =zRGmQflWopgEOxjBXtucKIVnHSqrTM.replace('&quot;','')
   zRGmQflWopgEOxjBXtucKIVnHSqrba=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',zRGmQflWopgEOxjBXtucKIVnHSqrTM)
   for i in zRGmQflWopgEOxjBXtucKIVnHSqrvL(zRGmQflWopgEOxjBXtucKIVnHSqrvA(zRGmQflWopgEOxjBXtucKIVnHSqrba)):
    zRGmQflWopgEOxjBXtucKIVnHSqrTL=zRGmQflWopgEOxjBXtucKIVnHSqrba[i]
    zRGmQflWopgEOxjBXtucKIVnHSqrTL =zRGmQflWopgEOxjBXtucKIVnHSqrTL.split(':')[1]
    zRGmQflWopgEOxjBXtucKIVnHSqrba[i]=zRGmQflWopgEOxjBXtucKIVnHSqrTL.split(',')[0]
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   zRGmQflWopgEOxjBXtucKIVnHSqrvs(exception)
  return zRGmQflWopgEOxjBXtucKIVnHSqrba
 def GetProfilesConvert(zRGmQflWopgEOxjBXtucKIVnHSqrbT,zRGmQflWopgEOxjBXtucKIVnHSqrbe):
  zRGmQflWopgEOxjBXtucKIVnHSqrTF=''
  zRGmQflWopgEOxjBXtucKIVnHSqrTi=''
  try:
   zRGmQflWopgEOxjBXtucKIVnHSqrby ='/api/users/'+zRGmQflWopgEOxjBXtucKIVnHSqrbe+'/convert'
   zRGmQflWopgEOxjBXtucKIVnHSqrbN=zRGmQflWopgEOxjBXtucKIVnHSqrbT.API_DOMAIN+zRGmQflWopgEOxjBXtucKIVnHSqrby
   zRGmQflWopgEOxjBXtucKIVnHSqrbi=zRGmQflWopgEOxjBXtucKIVnHSqrbT.makeDefaultCookies()
   zRGmQflWopgEOxjBXtucKIVnHSqrbF=zRGmQflWopgEOxjBXtucKIVnHSqrbT.callRequestCookies('Put',zRGmQflWopgEOxjBXtucKIVnHSqrbN,payload=zRGmQflWopgEOxjBXtucKIVnHSqrve,params=zRGmQflWopgEOxjBXtucKIVnHSqrve,headers=zRGmQflWopgEOxjBXtucKIVnHSqrve,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrbi)
   for zRGmQflWopgEOxjBXtucKIVnHSqrbi in zRGmQflWopgEOxjBXtucKIVnHSqrbF.cookies:
    if zRGmQflWopgEOxjBXtucKIVnHSqrbi.name=='_s_guitv':
     zRGmQflWopgEOxjBXtucKIVnHSqrTd=zRGmQflWopgEOxjBXtucKIVnHSqrbi.value
    elif zRGmQflWopgEOxjBXtucKIVnHSqrbi.name=='_guinness-premium_session':
     zRGmQflWopgEOxjBXtucKIVnHSqrbd=zRGmQflWopgEOxjBXtucKIVnHSqrbi.value
   if zRGmQflWopgEOxjBXtucKIVnHSqrTd:
    zRGmQflWopgEOxjBXtucKIVnHSqrTF=zRGmQflWopgEOxjBXtucKIVnHSqrTd
   if zRGmQflWopgEOxjBXtucKIVnHSqrbd:
    zRGmQflWopgEOxjBXtucKIVnHSqrTi=zRGmQflWopgEOxjBXtucKIVnHSqrbd
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   zRGmQflWopgEOxjBXtucKIVnHSqrTF=''
   zRGmQflWopgEOxjBXtucKIVnHSqrTi=''
  return zRGmQflWopgEOxjBXtucKIVnHSqrTF,zRGmQflWopgEOxjBXtucKIVnHSqrTi
 def Get_Now_Datetime(zRGmQflWopgEOxjBXtucKIVnHSqrbT):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(zRGmQflWopgEOxjBXtucKIVnHSqrbT,movie_code,quality_str):
  zRGmQflWopgEOxjBXtucKIVnHSqrTJ=zRGmQflWopgEOxjBXtucKIVnHSqrTy=zRGmQflWopgEOxjBXtucKIVnHSqrvU=''
  try:
   zRGmQflWopgEOxjBXtucKIVnHSqrby='/api/watch/'+movie_code+'.json'
   zRGmQflWopgEOxjBXtucKIVnHSqrbN=zRGmQflWopgEOxjBXtucKIVnHSqrbT.API_DOMAIN+zRGmQflWopgEOxjBXtucKIVnHSqrby
   zRGmQflWopgEOxjBXtucKIVnHSqrbL={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   zRGmQflWopgEOxjBXtucKIVnHSqrbi=zRGmQflWopgEOxjBXtucKIVnHSqrbT.makeDefaultCookies()
   zRGmQflWopgEOxjBXtucKIVnHSqrbF=zRGmQflWopgEOxjBXtucKIVnHSqrbT.callRequestCookies('Get',zRGmQflWopgEOxjBXtucKIVnHSqrbN,payload=zRGmQflWopgEOxjBXtucKIVnHSqrve,params=zRGmQflWopgEOxjBXtucKIVnHSqrve,headers=zRGmQflWopgEOxjBXtucKIVnHSqrbL,cookies=zRGmQflWopgEOxjBXtucKIVnHSqrbi)
   zRGmQflWopgEOxjBXtucKIVnHSqrCb=json.loads(zRGmQflWopgEOxjBXtucKIVnHSqrbF.text)
   zRGmQflWopgEOxjBXtucKIVnHSqrTJ=zRGmQflWopgEOxjBXtucKIVnHSqrCb['streams'][0]['source']
   if zRGmQflWopgEOxjBXtucKIVnHSqrTJ==zRGmQflWopgEOxjBXtucKIVnHSqrve:return(zRGmQflWopgEOxjBXtucKIVnHSqrTJ,zRGmQflWopgEOxjBXtucKIVnHSqrTy,zRGmQflWopgEOxjBXtucKIVnHSqrvU)
   if 'subtitles' in zRGmQflWopgEOxjBXtucKIVnHSqrCb['streams'][0]:
    for zRGmQflWopgEOxjBXtucKIVnHSqrTw in zRGmQflWopgEOxjBXtucKIVnHSqrCb['streams'][0]['subtitles']:
     if zRGmQflWopgEOxjBXtucKIVnHSqrTw['lang']=='ko':
      zRGmQflWopgEOxjBXtucKIVnHSqrTy=zRGmQflWopgEOxjBXtucKIVnHSqrTw['url']
      break
   zRGmQflWopgEOxjBXtucKIVnHSqrTN =zRGmQflWopgEOxjBXtucKIVnHSqrCb['ping_payload']
   zRGmQflWopgEOxjBXtucKIVnHSqrvb =zRGmQflWopgEOxjBXtucKIVnHSqrbT.WATCHA_USERCD
   zRGmQflWopgEOxjBXtucKIVnHSqrvC={'merchant':'giitd_frograms','sessionId':zRGmQflWopgEOxjBXtucKIVnHSqrTN,'userId':zRGmQflWopgEOxjBXtucKIVnHSqrvb}
   zRGmQflWopgEOxjBXtucKIVnHSqrvT=json.dumps(zRGmQflWopgEOxjBXtucKIVnHSqrvC,separators=(",",":")).encode('UTF-8')
   zRGmQflWopgEOxjBXtucKIVnHSqrvU=base64.b64encode(zRGmQflWopgEOxjBXtucKIVnHSqrvT)
  except zRGmQflWopgEOxjBXtucKIVnHSqrvP as exception:
   return(zRGmQflWopgEOxjBXtucKIVnHSqrTJ,zRGmQflWopgEOxjBXtucKIVnHSqrTy,zRGmQflWopgEOxjBXtucKIVnHSqrvU)
  return(zRGmQflWopgEOxjBXtucKIVnHSqrTJ,zRGmQflWopgEOxjBXtucKIVnHSqrTy,zRGmQflWopgEOxjBXtucKIVnHSqrvU) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
