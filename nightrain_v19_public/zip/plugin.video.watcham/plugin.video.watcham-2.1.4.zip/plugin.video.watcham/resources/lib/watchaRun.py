__author__="NightRain"
eHScgzCoIsRLGUEDQFlPivYMVAnbBj=object
eHScgzCoIsRLGUEDQFlPivYMVAnbBh=None
eHScgzCoIsRLGUEDQFlPivYMVAnbBa=int
eHScgzCoIsRLGUEDQFlPivYMVAnbBK=True
eHScgzCoIsRLGUEDQFlPivYMVAnbBd=False
eHScgzCoIsRLGUEDQFlPivYMVAnbBf=type
eHScgzCoIsRLGUEDQFlPivYMVAnbBx=dict
eHScgzCoIsRLGUEDQFlPivYMVAnbBm=len
eHScgzCoIsRLGUEDQFlPivYMVAnbBw=range
eHScgzCoIsRLGUEDQFlPivYMVAnbBq=str
eHScgzCoIsRLGUEDQFlPivYMVAnbBO=open
eHScgzCoIsRLGUEDQFlPivYMVAnbBN=Exception
eHScgzCoIsRLGUEDQFlPivYMVAnbBX=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
eHScgzCoIsRLGUEDQFlPivYMVAnbkt=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-','icon':'history.png'},{'title':'검색 (왓챠)','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'통합검색 이력','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'}]
eHScgzCoIsRLGUEDQFlPivYMVAnbkr=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
eHScgzCoIsRLGUEDQFlPivYMVAnbku=40
eHScgzCoIsRLGUEDQFlPivYMVAnbkB =20
eHScgzCoIsRLGUEDQFlPivYMVAnbkT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
eHScgzCoIsRLGUEDQFlPivYMVAnbkj=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class eHScgzCoIsRLGUEDQFlPivYMVAnbkp(eHScgzCoIsRLGUEDQFlPivYMVAnbBj):
 def __init__(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,eHScgzCoIsRLGUEDQFlPivYMVAnbka,eHScgzCoIsRLGUEDQFlPivYMVAnbkK,eHScgzCoIsRLGUEDQFlPivYMVAnbkd):
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_url =eHScgzCoIsRLGUEDQFlPivYMVAnbka
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle=eHScgzCoIsRLGUEDQFlPivYMVAnbkK
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.main_params =eHScgzCoIsRLGUEDQFlPivYMVAnbkd
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj =zRGmQflWopgEOxjBXtucKIVnHSqrbC() 
 def addon_noti(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,sting):
  try:
   eHScgzCoIsRLGUEDQFlPivYMVAnbkx=xbmcgui.Dialog()
   eHScgzCoIsRLGUEDQFlPivYMVAnbkx.notification(__addonname__,sting)
  except:
   eHScgzCoIsRLGUEDQFlPivYMVAnbBh
 def addon_log(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,string):
  try:
   eHScgzCoIsRLGUEDQFlPivYMVAnbkm=string.encode('utf-8','ignore')
  except:
   eHScgzCoIsRLGUEDQFlPivYMVAnbkm='addonException: addon_log'
  eHScgzCoIsRLGUEDQFlPivYMVAnbkw=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,eHScgzCoIsRLGUEDQFlPivYMVAnbkm),level=eHScgzCoIsRLGUEDQFlPivYMVAnbkw)
 def get_keyboard_input(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,eHScgzCoIsRLGUEDQFlPivYMVAnbph):
  eHScgzCoIsRLGUEDQFlPivYMVAnbkq=eHScgzCoIsRLGUEDQFlPivYMVAnbBh
  kb=xbmc.Keyboard()
  kb.setHeading(eHScgzCoIsRLGUEDQFlPivYMVAnbph)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   eHScgzCoIsRLGUEDQFlPivYMVAnbkq=kb.getText()
  return eHScgzCoIsRLGUEDQFlPivYMVAnbkq
 def get_settings_login_info(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  eHScgzCoIsRLGUEDQFlPivYMVAnbkO =__addon__.getSetting('id')
  eHScgzCoIsRLGUEDQFlPivYMVAnbkN =__addon__.getSetting('pw')
  eHScgzCoIsRLGUEDQFlPivYMVAnbkX=eHScgzCoIsRLGUEDQFlPivYMVAnbBa(__addon__.getSetting('selected_profile'))
  return(eHScgzCoIsRLGUEDQFlPivYMVAnbkO,eHScgzCoIsRLGUEDQFlPivYMVAnbkN,eHScgzCoIsRLGUEDQFlPivYMVAnbkX)
 def get_settings_totalsearch(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  eHScgzCoIsRLGUEDQFlPivYMVAnbky =eHScgzCoIsRLGUEDQFlPivYMVAnbBK if __addon__.getSetting('local_search')=='true' else eHScgzCoIsRLGUEDQFlPivYMVAnbBd
  eHScgzCoIsRLGUEDQFlPivYMVAnbkW =eHScgzCoIsRLGUEDQFlPivYMVAnbBK if __addon__.getSetting('total_search')=='true' else eHScgzCoIsRLGUEDQFlPivYMVAnbBd
  eHScgzCoIsRLGUEDQFlPivYMVAnbkJ=eHScgzCoIsRLGUEDQFlPivYMVAnbBK if __addon__.getSetting('total_history')=='true' else eHScgzCoIsRLGUEDQFlPivYMVAnbBd
  return(eHScgzCoIsRLGUEDQFlPivYMVAnbky,eHScgzCoIsRLGUEDQFlPivYMVAnbkW,eHScgzCoIsRLGUEDQFlPivYMVAnbkJ)
 def get_selQuality(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  try:
   eHScgzCoIsRLGUEDQFlPivYMVAnbpk=['3840x2160/1','1920x1080/1','1280x720/1']
   eHScgzCoIsRLGUEDQFlPivYMVAnbpt=eHScgzCoIsRLGUEDQFlPivYMVAnbBa(__addon__.getSetting('selected_quality'))
   return eHScgzCoIsRLGUEDQFlPivYMVAnbpk[eHScgzCoIsRLGUEDQFlPivYMVAnbpt]
  except:
   eHScgzCoIsRLGUEDQFlPivYMVAnbBh
  return 1080 
 def get_settings_direct_replay(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  eHScgzCoIsRLGUEDQFlPivYMVAnbpr=eHScgzCoIsRLGUEDQFlPivYMVAnbBa(__addon__.getSetting('direct_replay'))
  if eHScgzCoIsRLGUEDQFlPivYMVAnbpr==0:
   return eHScgzCoIsRLGUEDQFlPivYMVAnbBd
  else:
   return eHScgzCoIsRLGUEDQFlPivYMVAnbBK
 def set_winCredential(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,credential):
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu=xbmcgui.Window(10000)
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_LOGINTIME',eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu=xbmcgui.Window(10000)
  eHScgzCoIsRLGUEDQFlPivYMVAnbpB={'watcha_token':eHScgzCoIsRLGUEDQFlPivYMVAnbpu.getProperty('WATCHA_M_TOKEN'),'watcha_guit':eHScgzCoIsRLGUEDQFlPivYMVAnbpu.getProperty('WATCHA_M_GUIT'),'watcha_guitv':eHScgzCoIsRLGUEDQFlPivYMVAnbpu.getProperty('WATCHA_M_GUITV'),'watcha_usercd':eHScgzCoIsRLGUEDQFlPivYMVAnbpu.getProperty('WATCHA_M_USERCD')}
  return eHScgzCoIsRLGUEDQFlPivYMVAnbpB
 def set_winEpisodeOrderby(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,eHScgzCoIsRLGUEDQFlPivYMVAnbpT):
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu=xbmcgui.Window(10000)
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_ORDERBY',eHScgzCoIsRLGUEDQFlPivYMVAnbpT)
 def get_winEpisodeOrderby(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu=xbmcgui.Window(10000)
  return eHScgzCoIsRLGUEDQFlPivYMVAnbpu.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,args):
  eHScgzCoIsRLGUEDQFlPivYMVAnbpT =args.get('orderby')
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.set_winEpisodeOrderby(eHScgzCoIsRLGUEDQFlPivYMVAnbpT)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,label,sublabel='',img='',infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbBh,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbBK,params='',isLink=eHScgzCoIsRLGUEDQFlPivYMVAnbBd,ContextMenu=eHScgzCoIsRLGUEDQFlPivYMVAnbBh):
  eHScgzCoIsRLGUEDQFlPivYMVAnbpj='%s?%s'%(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_url,urllib.parse.urlencode(params))
  if sublabel:eHScgzCoIsRLGUEDQFlPivYMVAnbph='%s < %s >'%(label,sublabel)
  else: eHScgzCoIsRLGUEDQFlPivYMVAnbph=label
  if not img:img='DefaultFolder.png'
  eHScgzCoIsRLGUEDQFlPivYMVAnbpa=xbmcgui.ListItem(eHScgzCoIsRLGUEDQFlPivYMVAnbph)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbBf(img)==eHScgzCoIsRLGUEDQFlPivYMVAnbBx:
   eHScgzCoIsRLGUEDQFlPivYMVAnbpa.setArt(img)
  else:
   eHScgzCoIsRLGUEDQFlPivYMVAnbpa.setArt({'thumb':img,'poster':img})
  if infoLabels:eHScgzCoIsRLGUEDQFlPivYMVAnbpa.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   eHScgzCoIsRLGUEDQFlPivYMVAnbpa.setProperty('IsPlayable','true')
  if ContextMenu:eHScgzCoIsRLGUEDQFlPivYMVAnbpa.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle,eHScgzCoIsRLGUEDQFlPivYMVAnbpj,eHScgzCoIsRLGUEDQFlPivYMVAnbpa,isFolder)
 def dp_Main_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  (eHScgzCoIsRLGUEDQFlPivYMVAnbky,eHScgzCoIsRLGUEDQFlPivYMVAnbkW,eHScgzCoIsRLGUEDQFlPivYMVAnbkJ)=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_settings_totalsearch()
  for eHScgzCoIsRLGUEDQFlPivYMVAnbpK in eHScgzCoIsRLGUEDQFlPivYMVAnbkt:
   eHScgzCoIsRLGUEDQFlPivYMVAnbph=eHScgzCoIsRLGUEDQFlPivYMVAnbpK.get('title')
   eHScgzCoIsRLGUEDQFlPivYMVAnbpd=''
   if eHScgzCoIsRLGUEDQFlPivYMVAnbpK.get('mode')=='LOCAL_SEARCH' and eHScgzCoIsRLGUEDQFlPivYMVAnbky ==eHScgzCoIsRLGUEDQFlPivYMVAnbBd:continue
   elif eHScgzCoIsRLGUEDQFlPivYMVAnbpK.get('mode')=='TOTAL_SEARCH' and eHScgzCoIsRLGUEDQFlPivYMVAnbkW ==eHScgzCoIsRLGUEDQFlPivYMVAnbBd:continue
   elif eHScgzCoIsRLGUEDQFlPivYMVAnbpK.get('mode')=='TOTAL_HISTORY' and eHScgzCoIsRLGUEDQFlPivYMVAnbkJ==eHScgzCoIsRLGUEDQFlPivYMVAnbBd:continue
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf={'mode':eHScgzCoIsRLGUEDQFlPivYMVAnbpK.get('mode'),'stype':eHScgzCoIsRLGUEDQFlPivYMVAnbpK.get('stype'),'api_path':eHScgzCoIsRLGUEDQFlPivYMVAnbpK.get('api_path'),'page':'1','sort':eHScgzCoIsRLGUEDQFlPivYMVAnbpK.get('sort'),'tag_id':'-'}
   if eHScgzCoIsRLGUEDQFlPivYMVAnbpK.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY']:
    eHScgzCoIsRLGUEDQFlPivYMVAnbpx=eHScgzCoIsRLGUEDQFlPivYMVAnbBd
    eHScgzCoIsRLGUEDQFlPivYMVAnbpm =eHScgzCoIsRLGUEDQFlPivYMVAnbBK
   else:
    eHScgzCoIsRLGUEDQFlPivYMVAnbpx=eHScgzCoIsRLGUEDQFlPivYMVAnbBK
    eHScgzCoIsRLGUEDQFlPivYMVAnbpm =eHScgzCoIsRLGUEDQFlPivYMVAnbBd
   if 'icon' in eHScgzCoIsRLGUEDQFlPivYMVAnbpK:eHScgzCoIsRLGUEDQFlPivYMVAnbpd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',eHScgzCoIsRLGUEDQFlPivYMVAnbpK.get('icon')) 
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel='',img=eHScgzCoIsRLGUEDQFlPivYMVAnbpd,infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbBh,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbpx,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf,isLink=eHScgzCoIsRLGUEDQFlPivYMVAnbpm)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbBm(eHScgzCoIsRLGUEDQFlPivYMVAnbkt)>0:xbmcplugin.endOfDirectory(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle)
 def login_main(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  (eHScgzCoIsRLGUEDQFlPivYMVAnbpq,eHScgzCoIsRLGUEDQFlPivYMVAnbpO,eHScgzCoIsRLGUEDQFlPivYMVAnbpN)=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_settings_login_info()
  if not(eHScgzCoIsRLGUEDQFlPivYMVAnbpq and eHScgzCoIsRLGUEDQFlPivYMVAnbpO):
   eHScgzCoIsRLGUEDQFlPivYMVAnbkx=xbmcgui.Dialog()
   eHScgzCoIsRLGUEDQFlPivYMVAnbpX=eHScgzCoIsRLGUEDQFlPivYMVAnbkx.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if eHScgzCoIsRLGUEDQFlPivYMVAnbpX==eHScgzCoIsRLGUEDQFlPivYMVAnbBK:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_winEpisodeOrderby()=='':
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.set_winEpisodeOrderby('asc')
  if eHScgzCoIsRLGUEDQFlPivYMVAnbkh.cookiefile_check():return
  eHScgzCoIsRLGUEDQFlPivYMVAnbpy =eHScgzCoIsRLGUEDQFlPivYMVAnbBa(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  eHScgzCoIsRLGUEDQFlPivYMVAnbpW=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if eHScgzCoIsRLGUEDQFlPivYMVAnbpW==eHScgzCoIsRLGUEDQFlPivYMVAnbBh or eHScgzCoIsRLGUEDQFlPivYMVAnbpW=='':
   eHScgzCoIsRLGUEDQFlPivYMVAnbpW=eHScgzCoIsRLGUEDQFlPivYMVAnbBa('19000101')
  else:
   eHScgzCoIsRLGUEDQFlPivYMVAnbpW=eHScgzCoIsRLGUEDQFlPivYMVAnbBa(re.sub('-','',eHScgzCoIsRLGUEDQFlPivYMVAnbpW))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   eHScgzCoIsRLGUEDQFlPivYMVAnbpJ=0
   while eHScgzCoIsRLGUEDQFlPivYMVAnbBK:
    eHScgzCoIsRLGUEDQFlPivYMVAnbpJ+=1
    time.sleep(0.05)
    if eHScgzCoIsRLGUEDQFlPivYMVAnbpW>=eHScgzCoIsRLGUEDQFlPivYMVAnbpy:return
    if eHScgzCoIsRLGUEDQFlPivYMVAnbpJ>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if eHScgzCoIsRLGUEDQFlPivYMVAnbpW>=eHScgzCoIsRLGUEDQFlPivYMVAnbpy:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.GetCredential(eHScgzCoIsRLGUEDQFlPivYMVAnbpq,eHScgzCoIsRLGUEDQFlPivYMVAnbpO,eHScgzCoIsRLGUEDQFlPivYMVAnbpN):
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.set_winCredential(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.LoadCredential())
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,args):
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.SaveCredential(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_winCredential())
  eHScgzCoIsRLGUEDQFlPivYMVAnbtk =args.get('stype')
  eHScgzCoIsRLGUEDQFlPivYMVAnbtp =eHScgzCoIsRLGUEDQFlPivYMVAnbBa(args.get('page'))
  eHScgzCoIsRLGUEDQFlPivYMVAnbtr =args.get('sort')
  eHScgzCoIsRLGUEDQFlPivYMVAnbtu=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.GetSubGroupList(eHScgzCoIsRLGUEDQFlPivYMVAnbtk)
  eHScgzCoIsRLGUEDQFlPivYMVAnbtB=eHScgzCoIsRLGUEDQFlPivYMVAnbku if eHScgzCoIsRLGUEDQFlPivYMVAnbtk=='genres' else eHScgzCoIsRLGUEDQFlPivYMVAnbkB
  eHScgzCoIsRLGUEDQFlPivYMVAnbtT=eHScgzCoIsRLGUEDQFlPivYMVAnbBm(eHScgzCoIsRLGUEDQFlPivYMVAnbtu)
  eHScgzCoIsRLGUEDQFlPivYMVAnbtj =eHScgzCoIsRLGUEDQFlPivYMVAnbBa(eHScgzCoIsRLGUEDQFlPivYMVAnbtT//(eHScgzCoIsRLGUEDQFlPivYMVAnbtB+1))+1
  eHScgzCoIsRLGUEDQFlPivYMVAnbth =(eHScgzCoIsRLGUEDQFlPivYMVAnbtp-1)*eHScgzCoIsRLGUEDQFlPivYMVAnbtB
  for i in eHScgzCoIsRLGUEDQFlPivYMVAnbBw(eHScgzCoIsRLGUEDQFlPivYMVAnbtB):
   eHScgzCoIsRLGUEDQFlPivYMVAnbta=eHScgzCoIsRLGUEDQFlPivYMVAnbth+i
   if eHScgzCoIsRLGUEDQFlPivYMVAnbta>=eHScgzCoIsRLGUEDQFlPivYMVAnbtT:break
   eHScgzCoIsRLGUEDQFlPivYMVAnbph =eHScgzCoIsRLGUEDQFlPivYMVAnbtu[eHScgzCoIsRLGUEDQFlPivYMVAnbta].get('group_name')
   eHScgzCoIsRLGUEDQFlPivYMVAnbtK =eHScgzCoIsRLGUEDQFlPivYMVAnbtu[eHScgzCoIsRLGUEDQFlPivYMVAnbta].get('api_path')
   eHScgzCoIsRLGUEDQFlPivYMVAnbtd =eHScgzCoIsRLGUEDQFlPivYMVAnbtu[eHScgzCoIsRLGUEDQFlPivYMVAnbta].get('tag_id')
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf={'mode':'CATEGORY_LIST','api_path':eHScgzCoIsRLGUEDQFlPivYMVAnbtK,'tag_id':eHScgzCoIsRLGUEDQFlPivYMVAnbtd,'stype':eHScgzCoIsRLGUEDQFlPivYMVAnbtk,'page':'1','sort':eHScgzCoIsRLGUEDQFlPivYMVAnbtr}
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel='',img='',infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbBh,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbBK,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbtj>eHScgzCoIsRLGUEDQFlPivYMVAnbtp:
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf={}
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['mode'] ='SUB_GROUP' 
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['stype'] =eHScgzCoIsRLGUEDQFlPivYMVAnbtk
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['api_path']=args.get('api_path')
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['page'] =eHScgzCoIsRLGUEDQFlPivYMVAnbBq(eHScgzCoIsRLGUEDQFlPivYMVAnbtp+1)
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['sort'] =eHScgzCoIsRLGUEDQFlPivYMVAnbtr
   eHScgzCoIsRLGUEDQFlPivYMVAnbph='[B]%s >>[/B]'%'다음 페이지'
   eHScgzCoIsRLGUEDQFlPivYMVAnbtf=eHScgzCoIsRLGUEDQFlPivYMVAnbBq(eHScgzCoIsRLGUEDQFlPivYMVAnbtp+1)
   eHScgzCoIsRLGUEDQFlPivYMVAnbpd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel=eHScgzCoIsRLGUEDQFlPivYMVAnbtf,img=eHScgzCoIsRLGUEDQFlPivYMVAnbpd,infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbBh,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbBK,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbBm(eHScgzCoIsRLGUEDQFlPivYMVAnbtu)>0:xbmcplugin.endOfDirectory(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle,cacheToDisc=eHScgzCoIsRLGUEDQFlPivYMVAnbBK)
 def play_VIDEO(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,args):
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.SaveCredential(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_winCredential())
  eHScgzCoIsRLGUEDQFlPivYMVAnbtx =args.get('movie_code')
  eHScgzCoIsRLGUEDQFlPivYMVAnbtm =args.get('season_code')
  eHScgzCoIsRLGUEDQFlPivYMVAnbph =args.get('title')
  eHScgzCoIsRLGUEDQFlPivYMVAnbtw =args.get('thumbnail')
  eHScgzCoIsRLGUEDQFlPivYMVAnbtq =eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_selQuality()
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.addon_log(eHScgzCoIsRLGUEDQFlPivYMVAnbtx+' - '+eHScgzCoIsRLGUEDQFlPivYMVAnbtm)
  eHScgzCoIsRLGUEDQFlPivYMVAnbtO,eHScgzCoIsRLGUEDQFlPivYMVAnbtN,eHScgzCoIsRLGUEDQFlPivYMVAnbtX=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.GetStreamingURL(eHScgzCoIsRLGUEDQFlPivYMVAnbtx,eHScgzCoIsRLGUEDQFlPivYMVAnbtq)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbtO=='':
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.addon_noti(__language__(30908).encode('utf8'))
   return
  eHScgzCoIsRLGUEDQFlPivYMVAnbty=eHScgzCoIsRLGUEDQFlPivYMVAnbtO
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.addon_log(eHScgzCoIsRLGUEDQFlPivYMVAnbty)
  eHScgzCoIsRLGUEDQFlPivYMVAnbtW=xbmcgui.ListItem(path=eHScgzCoIsRLGUEDQFlPivYMVAnbty)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbtX:
   eHScgzCoIsRLGUEDQFlPivYMVAnbtJ=eHScgzCoIsRLGUEDQFlPivYMVAnbtX
   eHScgzCoIsRLGUEDQFlPivYMVAnbrk ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   eHScgzCoIsRLGUEDQFlPivYMVAnbrp ='mpd'
   eHScgzCoIsRLGUEDQFlPivYMVAnbrt ='com.widevine.alpha'
   eHScgzCoIsRLGUEDQFlPivYMVAnbru =inputstreamhelper.Helper(eHScgzCoIsRLGUEDQFlPivYMVAnbrp,drm=eHScgzCoIsRLGUEDQFlPivYMVAnbrt)
   if eHScgzCoIsRLGUEDQFlPivYMVAnbru.check_inputstream():
    eHScgzCoIsRLGUEDQFlPivYMVAnbrB={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+eHScgzCoIsRLGUEDQFlPivYMVAnbtx,'dt-custom-data':eHScgzCoIsRLGUEDQFlPivYMVAnbtJ,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    eHScgzCoIsRLGUEDQFlPivYMVAnbrT=eHScgzCoIsRLGUEDQFlPivYMVAnbrk+'|'+urllib.parse.urlencode(eHScgzCoIsRLGUEDQFlPivYMVAnbrB)+'|R{SSM}|'
    eHScgzCoIsRLGUEDQFlPivYMVAnbkh.addon_log(eHScgzCoIsRLGUEDQFlPivYMVAnbrT)
    eHScgzCoIsRLGUEDQFlPivYMVAnbtW.setProperty('inputstream',eHScgzCoIsRLGUEDQFlPivYMVAnbru.inputstream_addon)
    eHScgzCoIsRLGUEDQFlPivYMVAnbtW.setProperty('inputstream.adaptive.manifest_type',eHScgzCoIsRLGUEDQFlPivYMVAnbrp)
    eHScgzCoIsRLGUEDQFlPivYMVAnbtW.setProperty('inputstream.adaptive.license_type',eHScgzCoIsRLGUEDQFlPivYMVAnbrt)
    eHScgzCoIsRLGUEDQFlPivYMVAnbtW.setProperty('inputstream.adaptive.license_key',eHScgzCoIsRLGUEDQFlPivYMVAnbrT)
    eHScgzCoIsRLGUEDQFlPivYMVAnbtW.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.USER_AGENT))
  if eHScgzCoIsRLGUEDQFlPivYMVAnbtN:
   try:
    f=eHScgzCoIsRLGUEDQFlPivYMVAnbBO(eHScgzCoIsRLGUEDQFlPivYMVAnbkT,'w',-1,'utf-8')
    eHScgzCoIsRLGUEDQFlPivYMVAnbrj=requests.get(eHScgzCoIsRLGUEDQFlPivYMVAnbtN)
    eHScgzCoIsRLGUEDQFlPivYMVAnbrh=eHScgzCoIsRLGUEDQFlPivYMVAnbrj.content.decode('utf-8') 
    for eHScgzCoIsRLGUEDQFlPivYMVAnbra in eHScgzCoIsRLGUEDQFlPivYMVAnbrh.splitlines():
     eHScgzCoIsRLGUEDQFlPivYMVAnbrK=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',eHScgzCoIsRLGUEDQFlPivYMVAnbra)
     f.write(eHScgzCoIsRLGUEDQFlPivYMVAnbrK+'\n')
    f.close()
    eHScgzCoIsRLGUEDQFlPivYMVAnbtW.setSubtitles([eHScgzCoIsRLGUEDQFlPivYMVAnbkT,eHScgzCoIsRLGUEDQFlPivYMVAnbtN])
   except:
    eHScgzCoIsRLGUEDQFlPivYMVAnbtW.setSubtitles([eHScgzCoIsRLGUEDQFlPivYMVAnbtN])
  xbmcplugin.setResolvedUrl(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle,eHScgzCoIsRLGUEDQFlPivYMVAnbBK,eHScgzCoIsRLGUEDQFlPivYMVAnbtW)
  try:
   eHScgzCoIsRLGUEDQFlPivYMVAnbtk='movie' if eHScgzCoIsRLGUEDQFlPivYMVAnbtm=='-' else 'seasons'
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf={'code':eHScgzCoIsRLGUEDQFlPivYMVAnbtx if eHScgzCoIsRLGUEDQFlPivYMVAnbtk=='movie' else eHScgzCoIsRLGUEDQFlPivYMVAnbtm,'img':eHScgzCoIsRLGUEDQFlPivYMVAnbtw,'title':eHScgzCoIsRLGUEDQFlPivYMVAnbph,'videoid':eHScgzCoIsRLGUEDQFlPivYMVAnbtx}
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.Save_Watched_List(eHScgzCoIsRLGUEDQFlPivYMVAnbtk,eHScgzCoIsRLGUEDQFlPivYMVAnbpf)
  except:
   eHScgzCoIsRLGUEDQFlPivYMVAnbBh
 def dp_Category_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,args):
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.SaveCredential(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_winCredential())
  eHScgzCoIsRLGUEDQFlPivYMVAnbtk =args.get('stype')
  eHScgzCoIsRLGUEDQFlPivYMVAnbtd =args.get('tag_id')
  eHScgzCoIsRLGUEDQFlPivYMVAnbtK=args.get('api_path')
  eHScgzCoIsRLGUEDQFlPivYMVAnbtp=eHScgzCoIsRLGUEDQFlPivYMVAnbBa(args.get('page'))
  eHScgzCoIsRLGUEDQFlPivYMVAnbtr =args.get('sort')
  eHScgzCoIsRLGUEDQFlPivYMVAnbrd,eHScgzCoIsRLGUEDQFlPivYMVAnbrf=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.GetCategoryList(eHScgzCoIsRLGUEDQFlPivYMVAnbtk,eHScgzCoIsRLGUEDQFlPivYMVAnbtd,eHScgzCoIsRLGUEDQFlPivYMVAnbtK,eHScgzCoIsRLGUEDQFlPivYMVAnbtp,eHScgzCoIsRLGUEDQFlPivYMVAnbtr)
  for eHScgzCoIsRLGUEDQFlPivYMVAnbrx in eHScgzCoIsRLGUEDQFlPivYMVAnbrd:
   eHScgzCoIsRLGUEDQFlPivYMVAnbtx =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('code')
   eHScgzCoIsRLGUEDQFlPivYMVAnbph =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('title')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrm =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('content_type')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrw =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('story')
   eHScgzCoIsRLGUEDQFlPivYMVAnbtw =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('thumbnail')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrq =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('year')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrO =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('film_rating_code')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrN=eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('film_rating_short')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrX =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('film_rating_long')
   eHScgzCoIsRLGUEDQFlPivYMVAnbry =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('duration')
   if eHScgzCoIsRLGUEDQFlPivYMVAnbrm=='movies': 
    eHScgzCoIsRLGUEDQFlPivYMVAnbpx =eHScgzCoIsRLGUEDQFlPivYMVAnbBd
    eHScgzCoIsRLGUEDQFlPivYMVAnbrW ='MOVIE'
    eHScgzCoIsRLGUEDQFlPivYMVAnbpw =''
    eHScgzCoIsRLGUEDQFlPivYMVAnbtm='-'
    eHScgzCoIsRLGUEDQFlPivYMVAnbrJ ='movie'
   else: 
    eHScgzCoIsRLGUEDQFlPivYMVAnbpx =eHScgzCoIsRLGUEDQFlPivYMVAnbBK
    eHScgzCoIsRLGUEDQFlPivYMVAnbrW ='EPISODE'
    eHScgzCoIsRLGUEDQFlPivYMVAnbpw ='Series'
    eHScgzCoIsRLGUEDQFlPivYMVAnbtm=eHScgzCoIsRLGUEDQFlPivYMVAnbtx
    eHScgzCoIsRLGUEDQFlPivYMVAnbrJ ='tvshow' 
   eHScgzCoIsRLGUEDQFlPivYMVAnbuk={'mediatype':eHScgzCoIsRLGUEDQFlPivYMVAnbrJ,'mpaa':eHScgzCoIsRLGUEDQFlPivYMVAnbrX,'title':eHScgzCoIsRLGUEDQFlPivYMVAnbph,'year':eHScgzCoIsRLGUEDQFlPivYMVAnbrq,'duration':eHScgzCoIsRLGUEDQFlPivYMVAnbry,'plot':'%s (%s)\n년도 : %s\n\n%s'%(eHScgzCoIsRLGUEDQFlPivYMVAnbph,eHScgzCoIsRLGUEDQFlPivYMVAnbrN,eHScgzCoIsRLGUEDQFlPivYMVAnbrq,eHScgzCoIsRLGUEDQFlPivYMVAnbrw)}
   if eHScgzCoIsRLGUEDQFlPivYMVAnbrO>=19:
    eHScgzCoIsRLGUEDQFlPivYMVAnbph+='  (%s년 - %s)'%(eHScgzCoIsRLGUEDQFlPivYMVAnbrq,eHScgzCoIsRLGUEDQFlPivYMVAnbBq(eHScgzCoIsRLGUEDQFlPivYMVAnbrN))
   else:
    eHScgzCoIsRLGUEDQFlPivYMVAnbph+='  (%s년)'%(eHScgzCoIsRLGUEDQFlPivYMVAnbrq)
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf={'mode':eHScgzCoIsRLGUEDQFlPivYMVAnbrW,'movie_code':eHScgzCoIsRLGUEDQFlPivYMVAnbtx,'page':'1','season_code':eHScgzCoIsRLGUEDQFlPivYMVAnbtm,'title':eHScgzCoIsRLGUEDQFlPivYMVAnbph,'thumbnail':eHScgzCoIsRLGUEDQFlPivYMVAnbtw}
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel=eHScgzCoIsRLGUEDQFlPivYMVAnbpw,img=eHScgzCoIsRLGUEDQFlPivYMVAnbtw,infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbuk,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbpx,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbrf:
   if eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.GetCategoryList_morepage(eHScgzCoIsRLGUEDQFlPivYMVAnbtk,eHScgzCoIsRLGUEDQFlPivYMVAnbtd,eHScgzCoIsRLGUEDQFlPivYMVAnbtK,eHScgzCoIsRLGUEDQFlPivYMVAnbtp+1,eHScgzCoIsRLGUEDQFlPivYMVAnbtr):
    eHScgzCoIsRLGUEDQFlPivYMVAnbpf={}
    eHScgzCoIsRLGUEDQFlPivYMVAnbpf['mode'] ='CATEGORY_LIST'
    eHScgzCoIsRLGUEDQFlPivYMVAnbpf['stype'] =eHScgzCoIsRLGUEDQFlPivYMVAnbtk
    eHScgzCoIsRLGUEDQFlPivYMVAnbpf['tag_id'] =eHScgzCoIsRLGUEDQFlPivYMVAnbtd
    eHScgzCoIsRLGUEDQFlPivYMVAnbpf['api_path']=eHScgzCoIsRLGUEDQFlPivYMVAnbtK
    eHScgzCoIsRLGUEDQFlPivYMVAnbpf['page'] =eHScgzCoIsRLGUEDQFlPivYMVAnbBq(eHScgzCoIsRLGUEDQFlPivYMVAnbtp+1)
    eHScgzCoIsRLGUEDQFlPivYMVAnbpf['sort'] =eHScgzCoIsRLGUEDQFlPivYMVAnbtr
    eHScgzCoIsRLGUEDQFlPivYMVAnbph='[B]%s >>[/B]'%'다음 페이지'
    eHScgzCoIsRLGUEDQFlPivYMVAnbtf=eHScgzCoIsRLGUEDQFlPivYMVAnbBq(eHScgzCoIsRLGUEDQFlPivYMVAnbtp+1)
    eHScgzCoIsRLGUEDQFlPivYMVAnbpd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
    eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel=eHScgzCoIsRLGUEDQFlPivYMVAnbtf,img=eHScgzCoIsRLGUEDQFlPivYMVAnbpd,infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbBh,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbBK,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbBm(eHScgzCoIsRLGUEDQFlPivYMVAnbrd)>0:
   if eHScgzCoIsRLGUEDQFlPivYMVAnbtK=='arrivals/latest':
    xbmcplugin.endOfDirectory(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle,cacheToDisc=eHScgzCoIsRLGUEDQFlPivYMVAnbBK)
   else:
    xbmcplugin.endOfDirectory(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle,cacheToDisc=eHScgzCoIsRLGUEDQFlPivYMVAnbBd)
 def dp_Episode_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,args):
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.SaveCredential(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_winCredential())
  eHScgzCoIsRLGUEDQFlPivYMVAnbut=args.get('movie_code')
  eHScgzCoIsRLGUEDQFlPivYMVAnbtp =eHScgzCoIsRLGUEDQFlPivYMVAnbBa(args.get('page'))
  eHScgzCoIsRLGUEDQFlPivYMVAnbtm =args.get('season_code')
  eHScgzCoIsRLGUEDQFlPivYMVAnbrd,eHScgzCoIsRLGUEDQFlPivYMVAnbrf=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.GetEpisodoList(eHScgzCoIsRLGUEDQFlPivYMVAnbut,eHScgzCoIsRLGUEDQFlPivYMVAnbtp,orderby=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_winEpisodeOrderby())
  for eHScgzCoIsRLGUEDQFlPivYMVAnbrx in eHScgzCoIsRLGUEDQFlPivYMVAnbrd:
   eHScgzCoIsRLGUEDQFlPivYMVAnbtx =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('code')
   eHScgzCoIsRLGUEDQFlPivYMVAnbph =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('title')
   eHScgzCoIsRLGUEDQFlPivYMVAnbtw =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('thumbnail')
   eHScgzCoIsRLGUEDQFlPivYMVAnbur =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('display_num')
   eHScgzCoIsRLGUEDQFlPivYMVAnbuB =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('season_title')
   eHScgzCoIsRLGUEDQFlPivYMVAnbuT=eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('episode_number')
   eHScgzCoIsRLGUEDQFlPivYMVAnbry =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('duration')
   eHScgzCoIsRLGUEDQFlPivYMVAnbuk={'mediatype':'episode','tvshowtitle':eHScgzCoIsRLGUEDQFlPivYMVAnbph if eHScgzCoIsRLGUEDQFlPivYMVAnbph!='' else eHScgzCoIsRLGUEDQFlPivYMVAnbuB,'title':'%s %s'%(eHScgzCoIsRLGUEDQFlPivYMVAnbuB,eHScgzCoIsRLGUEDQFlPivYMVAnbur)if eHScgzCoIsRLGUEDQFlPivYMVAnbph!='' else eHScgzCoIsRLGUEDQFlPivYMVAnbur,'episode':eHScgzCoIsRLGUEDQFlPivYMVAnbuT,'duration':eHScgzCoIsRLGUEDQFlPivYMVAnbry,'plot':'%s\n%s\n\n%s'%(eHScgzCoIsRLGUEDQFlPivYMVAnbuB,eHScgzCoIsRLGUEDQFlPivYMVAnbur,eHScgzCoIsRLGUEDQFlPivYMVAnbph)}
   eHScgzCoIsRLGUEDQFlPivYMVAnbph='(%s) %s'%(eHScgzCoIsRLGUEDQFlPivYMVAnbur,eHScgzCoIsRLGUEDQFlPivYMVAnbph)
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf={'mode':'MOVIE','movie_code':eHScgzCoIsRLGUEDQFlPivYMVAnbtx,'season_code':eHScgzCoIsRLGUEDQFlPivYMVAnbtm,'title':'%s < %s >'%(eHScgzCoIsRLGUEDQFlPivYMVAnbph,eHScgzCoIsRLGUEDQFlPivYMVAnbuB),'thumbnail':eHScgzCoIsRLGUEDQFlPivYMVAnbtw}
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel=eHScgzCoIsRLGUEDQFlPivYMVAnbuB,img=eHScgzCoIsRLGUEDQFlPivYMVAnbtw,infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbuk,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbBd,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbtp==1:
   eHScgzCoIsRLGUEDQFlPivYMVAnbuk={'plot':'정렬순서를 변경합니다.'}
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf={}
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['mode'] ='ORDER_BY' 
   if eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_winEpisodeOrderby()=='desc':
    eHScgzCoIsRLGUEDQFlPivYMVAnbph='정렬순서변경 : 최신화부터 -> 1회부터'
    eHScgzCoIsRLGUEDQFlPivYMVAnbpf['orderby']='asc'
   else:
    eHScgzCoIsRLGUEDQFlPivYMVAnbph='정렬순서변경 : 1회부터 -> 최신화부터'
    eHScgzCoIsRLGUEDQFlPivYMVAnbpf['orderby']='desc'
   eHScgzCoIsRLGUEDQFlPivYMVAnbpd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel='',img=eHScgzCoIsRLGUEDQFlPivYMVAnbpd,infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbuk,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbBd,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf,isLink=eHScgzCoIsRLGUEDQFlPivYMVAnbBK)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbrf:
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['mode'] ='EPISODE' 
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['movie_code']=eHScgzCoIsRLGUEDQFlPivYMVAnbut
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['page'] =eHScgzCoIsRLGUEDQFlPivYMVAnbBq(eHScgzCoIsRLGUEDQFlPivYMVAnbtp+1)
   eHScgzCoIsRLGUEDQFlPivYMVAnbph='[B]%s >>[/B]'%'다음 페이지'
   eHScgzCoIsRLGUEDQFlPivYMVAnbtf=eHScgzCoIsRLGUEDQFlPivYMVAnbBq(eHScgzCoIsRLGUEDQFlPivYMVAnbtp+1)
   eHScgzCoIsRLGUEDQFlPivYMVAnbpd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel=eHScgzCoIsRLGUEDQFlPivYMVAnbtf,img=eHScgzCoIsRLGUEDQFlPivYMVAnbpd,infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbBh,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbBK,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbBm(eHScgzCoIsRLGUEDQFlPivYMVAnbrd)>0:xbmcplugin.endOfDirectory(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle,cacheToDisc=eHScgzCoIsRLGUEDQFlPivYMVAnbBK)
 def dp_Search_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,args):
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.SaveCredential(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_winCredential())
  eHScgzCoIsRLGUEDQFlPivYMVAnbtp =eHScgzCoIsRLGUEDQFlPivYMVAnbBa(args.get('page'))
  if 'search_key' in args:
   eHScgzCoIsRLGUEDQFlPivYMVAnbuj=args.get('search_key')
  else:
   eHScgzCoIsRLGUEDQFlPivYMVAnbuj=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not eHScgzCoIsRLGUEDQFlPivYMVAnbuj:
    xbmcplugin.endOfDirectory(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle)
    return
  eHScgzCoIsRLGUEDQFlPivYMVAnbrd,eHScgzCoIsRLGUEDQFlPivYMVAnbrf=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.GetSearchList(eHScgzCoIsRLGUEDQFlPivYMVAnbuj,eHScgzCoIsRLGUEDQFlPivYMVAnbtp)
  for eHScgzCoIsRLGUEDQFlPivYMVAnbrx in eHScgzCoIsRLGUEDQFlPivYMVAnbrd:
   eHScgzCoIsRLGUEDQFlPivYMVAnbtx =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('code')
   eHScgzCoIsRLGUEDQFlPivYMVAnbph =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('title')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrm=eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('content_type')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrw =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('story')
   eHScgzCoIsRLGUEDQFlPivYMVAnbtw =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('thumbnail')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrq =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('year')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrO =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('film_rating_code')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrN=eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('film_rating_short')
   eHScgzCoIsRLGUEDQFlPivYMVAnbrX =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('film_rating_long')
   eHScgzCoIsRLGUEDQFlPivYMVAnbry =eHScgzCoIsRLGUEDQFlPivYMVAnbrx.get('duration')
   if eHScgzCoIsRLGUEDQFlPivYMVAnbrm=='movies': 
    eHScgzCoIsRLGUEDQFlPivYMVAnbpx =eHScgzCoIsRLGUEDQFlPivYMVAnbBd
    eHScgzCoIsRLGUEDQFlPivYMVAnbrW ='MOVIE'
    eHScgzCoIsRLGUEDQFlPivYMVAnbpw =''
    eHScgzCoIsRLGUEDQFlPivYMVAnbtm='-'
    eHScgzCoIsRLGUEDQFlPivYMVAnbrJ ='movie'
   else: 
    eHScgzCoIsRLGUEDQFlPivYMVAnbpx =eHScgzCoIsRLGUEDQFlPivYMVAnbBK
    eHScgzCoIsRLGUEDQFlPivYMVAnbrW ='EPISODE'
    eHScgzCoIsRLGUEDQFlPivYMVAnbpw ='Series'
    eHScgzCoIsRLGUEDQFlPivYMVAnbtm=eHScgzCoIsRLGUEDQFlPivYMVAnbtx
    eHScgzCoIsRLGUEDQFlPivYMVAnbrJ ='tvshow' 
   eHScgzCoIsRLGUEDQFlPivYMVAnbuk={'mediatype':eHScgzCoIsRLGUEDQFlPivYMVAnbrJ,'mpaa':eHScgzCoIsRLGUEDQFlPivYMVAnbrX,'title':eHScgzCoIsRLGUEDQFlPivYMVAnbph,'year':eHScgzCoIsRLGUEDQFlPivYMVAnbrq,'duration':eHScgzCoIsRLGUEDQFlPivYMVAnbry,'plot':'%s (%s)\n년도 : %s\n\n%s'%(eHScgzCoIsRLGUEDQFlPivYMVAnbph,eHScgzCoIsRLGUEDQFlPivYMVAnbrN,eHScgzCoIsRLGUEDQFlPivYMVAnbrq,eHScgzCoIsRLGUEDQFlPivYMVAnbrw)}
   if eHScgzCoIsRLGUEDQFlPivYMVAnbrO>=19:
    eHScgzCoIsRLGUEDQFlPivYMVAnbph+='  (%s년 - %s)'%(eHScgzCoIsRLGUEDQFlPivYMVAnbrq,eHScgzCoIsRLGUEDQFlPivYMVAnbBq(eHScgzCoIsRLGUEDQFlPivYMVAnbrN))
   else:
    eHScgzCoIsRLGUEDQFlPivYMVAnbph+='  (%s년)'%(eHScgzCoIsRLGUEDQFlPivYMVAnbrq)
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf={'mode':eHScgzCoIsRLGUEDQFlPivYMVAnbrW,'movie_code':eHScgzCoIsRLGUEDQFlPivYMVAnbtx,'page':'1','season_code':eHScgzCoIsRLGUEDQFlPivYMVAnbtm,'title':eHScgzCoIsRLGUEDQFlPivYMVAnbph,'thumbnail':eHScgzCoIsRLGUEDQFlPivYMVAnbtw}
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel=eHScgzCoIsRLGUEDQFlPivYMVAnbpw,img=eHScgzCoIsRLGUEDQFlPivYMVAnbtw,infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbuk,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbpx,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbrf:
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf={}
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['mode'] ='SEARCH'
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['search_key']=eHScgzCoIsRLGUEDQFlPivYMVAnbuj
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf['page'] =eHScgzCoIsRLGUEDQFlPivYMVAnbBq(eHScgzCoIsRLGUEDQFlPivYMVAnbtp+1)
   eHScgzCoIsRLGUEDQFlPivYMVAnbph='[B]%s >>[/B]'%'다음 페이지'
   eHScgzCoIsRLGUEDQFlPivYMVAnbtf=eHScgzCoIsRLGUEDQFlPivYMVAnbBq(eHScgzCoIsRLGUEDQFlPivYMVAnbtp+1)
   eHScgzCoIsRLGUEDQFlPivYMVAnbpd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel=eHScgzCoIsRLGUEDQFlPivYMVAnbtf,img=eHScgzCoIsRLGUEDQFlPivYMVAnbpd,infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbBh,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbBK,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf)
  xbmcplugin.endOfDirectory(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle)
 def Delete_Watched_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,eHScgzCoIsRLGUEDQFlPivYMVAnbtk):
  try:
   eHScgzCoIsRLGUEDQFlPivYMVAnbuh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eHScgzCoIsRLGUEDQFlPivYMVAnbtk))
   fp=eHScgzCoIsRLGUEDQFlPivYMVAnbBO(eHScgzCoIsRLGUEDQFlPivYMVAnbuh,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   eHScgzCoIsRLGUEDQFlPivYMVAnbBh
 def dp_WatchList_Delete(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,args):
  eHScgzCoIsRLGUEDQFlPivYMVAnbtk=args.get('stype')
  eHScgzCoIsRLGUEDQFlPivYMVAnbkx=xbmcgui.Dialog()
  eHScgzCoIsRLGUEDQFlPivYMVAnbpX=eHScgzCoIsRLGUEDQFlPivYMVAnbkx.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if eHScgzCoIsRLGUEDQFlPivYMVAnbpX==eHScgzCoIsRLGUEDQFlPivYMVAnbBd:sys.exit()
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.Delete_Watched_List(eHScgzCoIsRLGUEDQFlPivYMVAnbtk)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,eHScgzCoIsRLGUEDQFlPivYMVAnbtk):
  try:
   eHScgzCoIsRLGUEDQFlPivYMVAnbuh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eHScgzCoIsRLGUEDQFlPivYMVAnbtk))
   fp=eHScgzCoIsRLGUEDQFlPivYMVAnbBO(eHScgzCoIsRLGUEDQFlPivYMVAnbuh,'r',-1,'utf-8')
   eHScgzCoIsRLGUEDQFlPivYMVAnbua=fp.readlines()
   fp.close()
  except:
   eHScgzCoIsRLGUEDQFlPivYMVAnbua=[]
  return eHScgzCoIsRLGUEDQFlPivYMVAnbua
 def Save_Watched_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,eHScgzCoIsRLGUEDQFlPivYMVAnbtk,eHScgzCoIsRLGUEDQFlPivYMVAnbkd):
  try:
   eHScgzCoIsRLGUEDQFlPivYMVAnbuh=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eHScgzCoIsRLGUEDQFlPivYMVAnbtk))
   eHScgzCoIsRLGUEDQFlPivYMVAnbuK=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.Load_Watched_List(eHScgzCoIsRLGUEDQFlPivYMVAnbtk) 
   fp=eHScgzCoIsRLGUEDQFlPivYMVAnbBO(eHScgzCoIsRLGUEDQFlPivYMVAnbuh,'w',-1,'utf-8')
   eHScgzCoIsRLGUEDQFlPivYMVAnbud=urllib.parse.urlencode(eHScgzCoIsRLGUEDQFlPivYMVAnbkd)
   eHScgzCoIsRLGUEDQFlPivYMVAnbud=eHScgzCoIsRLGUEDQFlPivYMVAnbud+'\n'
   fp.write(eHScgzCoIsRLGUEDQFlPivYMVAnbud)
   eHScgzCoIsRLGUEDQFlPivYMVAnbuf=0
   for eHScgzCoIsRLGUEDQFlPivYMVAnbux in eHScgzCoIsRLGUEDQFlPivYMVAnbuK:
    eHScgzCoIsRLGUEDQFlPivYMVAnbum=eHScgzCoIsRLGUEDQFlPivYMVAnbBx(urllib.parse.parse_qsl(eHScgzCoIsRLGUEDQFlPivYMVAnbux))
    eHScgzCoIsRLGUEDQFlPivYMVAnbuw=eHScgzCoIsRLGUEDQFlPivYMVAnbkd.get('code').strip()
    eHScgzCoIsRLGUEDQFlPivYMVAnbuq=eHScgzCoIsRLGUEDQFlPivYMVAnbum.get('code').strip()
    if eHScgzCoIsRLGUEDQFlPivYMVAnbtk=='seasons' and eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_settings_direct_replay()==eHScgzCoIsRLGUEDQFlPivYMVAnbBK:
     eHScgzCoIsRLGUEDQFlPivYMVAnbuw=eHScgzCoIsRLGUEDQFlPivYMVAnbkd.get('videoid').strip()
     eHScgzCoIsRLGUEDQFlPivYMVAnbuq=eHScgzCoIsRLGUEDQFlPivYMVAnbum.get('videoid').strip()if eHScgzCoIsRLGUEDQFlPivYMVAnbuq!=eHScgzCoIsRLGUEDQFlPivYMVAnbBh else '-'
    if eHScgzCoIsRLGUEDQFlPivYMVAnbuw!=eHScgzCoIsRLGUEDQFlPivYMVAnbuq:
     fp.write(eHScgzCoIsRLGUEDQFlPivYMVAnbux)
     eHScgzCoIsRLGUEDQFlPivYMVAnbuf+=1
     if eHScgzCoIsRLGUEDQFlPivYMVAnbuf>=50:break
   fp.close()
  except:
   eHScgzCoIsRLGUEDQFlPivYMVAnbBh
 def dp_Watch_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,args):
  eHScgzCoIsRLGUEDQFlPivYMVAnbtk =args.get('stype')
  eHScgzCoIsRLGUEDQFlPivYMVAnbpr=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.get_settings_direct_replay()
  if eHScgzCoIsRLGUEDQFlPivYMVAnbtk=='-':
   for eHScgzCoIsRLGUEDQFlPivYMVAnbuO in eHScgzCoIsRLGUEDQFlPivYMVAnbkr:
    eHScgzCoIsRLGUEDQFlPivYMVAnbph=eHScgzCoIsRLGUEDQFlPivYMVAnbuO.get('title')
    eHScgzCoIsRLGUEDQFlPivYMVAnbpf={'mode':eHScgzCoIsRLGUEDQFlPivYMVAnbuO.get('mode'),'stype':eHScgzCoIsRLGUEDQFlPivYMVAnbuO.get('stype')}
    eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel='',img='',infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbBh,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbBK,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf)
   if eHScgzCoIsRLGUEDQFlPivYMVAnbBm(eHScgzCoIsRLGUEDQFlPivYMVAnbkr)>0:xbmcplugin.endOfDirectory(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle)
  else:
   eHScgzCoIsRLGUEDQFlPivYMVAnbuN=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.Load_Watched_List(eHScgzCoIsRLGUEDQFlPivYMVAnbtk)
   for eHScgzCoIsRLGUEDQFlPivYMVAnbuX in eHScgzCoIsRLGUEDQFlPivYMVAnbuN:
    eHScgzCoIsRLGUEDQFlPivYMVAnbuy=eHScgzCoIsRLGUEDQFlPivYMVAnbBx(urllib.parse.parse_qsl(eHScgzCoIsRLGUEDQFlPivYMVAnbuX))
    eHScgzCoIsRLGUEDQFlPivYMVAnbtx=eHScgzCoIsRLGUEDQFlPivYMVAnbuy.get('code').strip()
    eHScgzCoIsRLGUEDQFlPivYMVAnbph =eHScgzCoIsRLGUEDQFlPivYMVAnbuy.get('title').strip()
    eHScgzCoIsRLGUEDQFlPivYMVAnbtw =eHScgzCoIsRLGUEDQFlPivYMVAnbuy.get('img').strip()
    eHScgzCoIsRLGUEDQFlPivYMVAnbuW =eHScgzCoIsRLGUEDQFlPivYMVAnbuy.get('videoid').strip()
    try:
     eHScgzCoIsRLGUEDQFlPivYMVAnbtw=eHScgzCoIsRLGUEDQFlPivYMVAnbtw.replace('\'','\"')
     eHScgzCoIsRLGUEDQFlPivYMVAnbtw=json.loads(eHScgzCoIsRLGUEDQFlPivYMVAnbtw)
    except:
     eHScgzCoIsRLGUEDQFlPivYMVAnbBh
    eHScgzCoIsRLGUEDQFlPivYMVAnbuk={}
    eHScgzCoIsRLGUEDQFlPivYMVAnbuk['plot']=eHScgzCoIsRLGUEDQFlPivYMVAnbph
    if eHScgzCoIsRLGUEDQFlPivYMVAnbtk=='movie':
     eHScgzCoIsRLGUEDQFlPivYMVAnbpf={'mode':'MOVIE','page':'1','movie_code':eHScgzCoIsRLGUEDQFlPivYMVAnbtx,'season_code':'-','title':eHScgzCoIsRLGUEDQFlPivYMVAnbph,'thumbnail':eHScgzCoIsRLGUEDQFlPivYMVAnbtw}
     eHScgzCoIsRLGUEDQFlPivYMVAnbpx=eHScgzCoIsRLGUEDQFlPivYMVAnbBd
    else:
     if eHScgzCoIsRLGUEDQFlPivYMVAnbpr==eHScgzCoIsRLGUEDQFlPivYMVAnbBd or eHScgzCoIsRLGUEDQFlPivYMVAnbuW==eHScgzCoIsRLGUEDQFlPivYMVAnbBh:
      eHScgzCoIsRLGUEDQFlPivYMVAnbpf={'mode':'EPISODE','page':'1','movie_code':eHScgzCoIsRLGUEDQFlPivYMVAnbtx,'season_code':eHScgzCoIsRLGUEDQFlPivYMVAnbtx,'title':eHScgzCoIsRLGUEDQFlPivYMVAnbph,'thumbnail':eHScgzCoIsRLGUEDQFlPivYMVAnbtw}
      eHScgzCoIsRLGUEDQFlPivYMVAnbpx=eHScgzCoIsRLGUEDQFlPivYMVAnbBK
     else:
      eHScgzCoIsRLGUEDQFlPivYMVAnbpf={'mode':'MOVIE','movie_code':eHScgzCoIsRLGUEDQFlPivYMVAnbuW,'season_code':eHScgzCoIsRLGUEDQFlPivYMVAnbtx,'title':eHScgzCoIsRLGUEDQFlPivYMVAnbph,'thumbnail':eHScgzCoIsRLGUEDQFlPivYMVAnbtw}
      eHScgzCoIsRLGUEDQFlPivYMVAnbpx=eHScgzCoIsRLGUEDQFlPivYMVAnbBd
    eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel='',img=eHScgzCoIsRLGUEDQFlPivYMVAnbtw,infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbuk,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbpx,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf)
   eHScgzCoIsRLGUEDQFlPivYMVAnbuk={'plot':'시청목록을 삭제합니다.'}
   eHScgzCoIsRLGUEDQFlPivYMVAnbph='*** 시청목록 삭제 ***'
   eHScgzCoIsRLGUEDQFlPivYMVAnbpf={'mode':'MYVIEW_REMOVE','stype':eHScgzCoIsRLGUEDQFlPivYMVAnbtk}
   eHScgzCoIsRLGUEDQFlPivYMVAnbpd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.add_dir(eHScgzCoIsRLGUEDQFlPivYMVAnbph,sublabel='',img=eHScgzCoIsRLGUEDQFlPivYMVAnbpd,infoLabels=eHScgzCoIsRLGUEDQFlPivYMVAnbuk,isFolder=eHScgzCoIsRLGUEDQFlPivYMVAnbBd,params=eHScgzCoIsRLGUEDQFlPivYMVAnbpf,isLink=eHScgzCoIsRLGUEDQFlPivYMVAnbBK)
   xbmcplugin.endOfDirectory(eHScgzCoIsRLGUEDQFlPivYMVAnbkh._addon_handle,cacheToDisc=eHScgzCoIsRLGUEDQFlPivYMVAnbBd)
 def logout(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  eHScgzCoIsRLGUEDQFlPivYMVAnbkx=xbmcgui.Dialog()
  eHScgzCoIsRLGUEDQFlPivYMVAnbpX=eHScgzCoIsRLGUEDQFlPivYMVAnbkx.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if eHScgzCoIsRLGUEDQFlPivYMVAnbpX==eHScgzCoIsRLGUEDQFlPivYMVAnbBd:sys.exit()
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.wininfo_clear()
  if os.path.isfile(eHScgzCoIsRLGUEDQFlPivYMVAnbkj):os.remove(eHScgzCoIsRLGUEDQFlPivYMVAnbkj)
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu=xbmcgui.Window(10000)
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_TOKEN','')
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_GUIT','')
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_GUITV','')
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_USERCD','')
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  eHScgzCoIsRLGUEDQFlPivYMVAnbuJ =eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.Get_Now_Datetime()
  eHScgzCoIsRLGUEDQFlPivYMVAnbBk=eHScgzCoIsRLGUEDQFlPivYMVAnbuJ+datetime.timedelta(days=eHScgzCoIsRLGUEDQFlPivYMVAnbBa(__addon__.getSetting('cache_ttl')))
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu=xbmcgui.Window(10000)
  eHScgzCoIsRLGUEDQFlPivYMVAnbBp={'watcha_token':eHScgzCoIsRLGUEDQFlPivYMVAnbpu.getProperty('WATCHA_M_TOKEN'),'watcha_guit':eHScgzCoIsRLGUEDQFlPivYMVAnbpu.getProperty('WATCHA_M_GUIT'),'watcha_guitv':eHScgzCoIsRLGUEDQFlPivYMVAnbpu.getProperty('WATCHA_M_GUITV'),'watcha_usercd':eHScgzCoIsRLGUEDQFlPivYMVAnbpu.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':eHScgzCoIsRLGUEDQFlPivYMVAnbBk.strftime('%Y-%m-%d')}
  try: 
   fp=eHScgzCoIsRLGUEDQFlPivYMVAnbBO(eHScgzCoIsRLGUEDQFlPivYMVAnbkj,'w',-1,'utf-8')
   json.dump(eHScgzCoIsRLGUEDQFlPivYMVAnbBp,fp)
   fp.close()
  except eHScgzCoIsRLGUEDQFlPivYMVAnbBN as exception:
   eHScgzCoIsRLGUEDQFlPivYMVAnbBX(exception)
 def cookiefile_check(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  eHScgzCoIsRLGUEDQFlPivYMVAnbBp={}
  try: 
   fp=eHScgzCoIsRLGUEDQFlPivYMVAnbBO(eHScgzCoIsRLGUEDQFlPivYMVAnbkj,'r',-1,'utf-8')
   eHScgzCoIsRLGUEDQFlPivYMVAnbBp= json.load(fp)
   fp.close()
  except eHScgzCoIsRLGUEDQFlPivYMVAnbBN as exception:
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.wininfo_clear()
   return eHScgzCoIsRLGUEDQFlPivYMVAnbBd
  eHScgzCoIsRLGUEDQFlPivYMVAnbpq =__addon__.getSetting('id')
  eHScgzCoIsRLGUEDQFlPivYMVAnbpO =__addon__.getSetting('pw')
  eHScgzCoIsRLGUEDQFlPivYMVAnbBt =__addon__.getSetting('selected_profile')
  eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_id']=base64.standard_b64decode(eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_id']).decode('utf-8')
  eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_pw']=base64.standard_b64decode(eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_pw']).decode('utf-8')
  if eHScgzCoIsRLGUEDQFlPivYMVAnbpq!=eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_id']or eHScgzCoIsRLGUEDQFlPivYMVAnbpO!=eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_pw']or eHScgzCoIsRLGUEDQFlPivYMVAnbBt!=eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_profile']:
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.wininfo_clear()
   return eHScgzCoIsRLGUEDQFlPivYMVAnbBd
  eHScgzCoIsRLGUEDQFlPivYMVAnbpy =eHScgzCoIsRLGUEDQFlPivYMVAnbBa(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  eHScgzCoIsRLGUEDQFlPivYMVAnbBr=eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_limitdate']
  eHScgzCoIsRLGUEDQFlPivYMVAnbpW =eHScgzCoIsRLGUEDQFlPivYMVAnbBa(re.sub('-','',eHScgzCoIsRLGUEDQFlPivYMVAnbBr))
  if eHScgzCoIsRLGUEDQFlPivYMVAnbpW<eHScgzCoIsRLGUEDQFlPivYMVAnbpy:
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.wininfo_clear()
   return eHScgzCoIsRLGUEDQFlPivYMVAnbBd
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu=xbmcgui.Window(10000)
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_TOKEN',eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_token'])
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_GUIT',eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_guit'])
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_GUITV',eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_guitv'])
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_USERCD',eHScgzCoIsRLGUEDQFlPivYMVAnbBp['watcha_usercd'])
  eHScgzCoIsRLGUEDQFlPivYMVAnbpu.setProperty('WATCHA_M_LOGINTIME',eHScgzCoIsRLGUEDQFlPivYMVAnbBr)
  return eHScgzCoIsRLGUEDQFlPivYMVAnbBK
 def dp_Global_Search(eHScgzCoIsRLGUEDQFlPivYMVAnbkh,args):
  eHScgzCoIsRLGUEDQFlPivYMVAnbBu=args.get('mode')
  if eHScgzCoIsRLGUEDQFlPivYMVAnbBu=='TOTAL_SEARCH':
   eHScgzCoIsRLGUEDQFlPivYMVAnbBT='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   eHScgzCoIsRLGUEDQFlPivYMVAnbBT='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(eHScgzCoIsRLGUEDQFlPivYMVAnbBT)
 def watcha_main(eHScgzCoIsRLGUEDQFlPivYMVAnbkh):
  eHScgzCoIsRLGUEDQFlPivYMVAnbBu=eHScgzCoIsRLGUEDQFlPivYMVAnbkh.main_params.get('mode',eHScgzCoIsRLGUEDQFlPivYMVAnbBh)
  if eHScgzCoIsRLGUEDQFlPivYMVAnbBu=='LOGOUT':
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.logout()
   return
  eHScgzCoIsRLGUEDQFlPivYMVAnbkh.login_main()
  if eHScgzCoIsRLGUEDQFlPivYMVAnbBu is eHScgzCoIsRLGUEDQFlPivYMVAnbBh:
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.dp_Main_List()
  elif eHScgzCoIsRLGUEDQFlPivYMVAnbBu=='SUB_GROUP':
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.dp_SubGroup_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.main_params)
  elif eHScgzCoIsRLGUEDQFlPivYMVAnbBu=='CATEGORY_LIST':
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.dp_Category_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.main_params)
  elif eHScgzCoIsRLGUEDQFlPivYMVAnbBu=='EPISODE':
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.dp_Episode_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.main_params)
  elif eHScgzCoIsRLGUEDQFlPivYMVAnbBu=='ORDER_BY':
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.dp_setEpOrderby(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.main_params)
  elif eHScgzCoIsRLGUEDQFlPivYMVAnbBu in['SEARCH','LOCAL_SEARCH']:
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.dp_Search_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.main_params)
  elif eHScgzCoIsRLGUEDQFlPivYMVAnbBu=='MOVIE':
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.play_VIDEO(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.main_params)
  elif eHScgzCoIsRLGUEDQFlPivYMVAnbBu=='WATCH':
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.dp_Watch_List(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.main_params)
  elif eHScgzCoIsRLGUEDQFlPivYMVAnbBu=='MYVIEW_REMOVE':
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.dp_WatchList_Delete(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.main_params)
  elif eHScgzCoIsRLGUEDQFlPivYMVAnbBu in['TOTAL_SEARCH','TOTAL_HISTORY']:
   eHScgzCoIsRLGUEDQFlPivYMVAnbkh.dp_Global_Search(eHScgzCoIsRLGUEDQFlPivYMVAnbkh.main_params)
  else:
   eHScgzCoIsRLGUEDQFlPivYMVAnbBh
# Created by pyminifier (https://github.com/liftoff/pyminifier)
