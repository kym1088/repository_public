# watchaM-v19
 왓챠 애드온 for Kodi19

###
# kodi19용은 저장소를 통해서만 업데이트 됩니다.
* [Korea OTT Package for Kodi 18 (public)-18.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v18_public.zip)
* [Korea OTT Package for Kodi 19 (public)-19.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v19_public.zip)
###


# 공통
- 해상도는 1080p, 720p만 적용됩니다.

- 1080p 적용안될시 조치방법
1. inputstream.adaptive 애드온에서 스트림설정 비디오수동 선택
2. 영화 재생화면에서  비디오설정->화질 변경후 다시 재생하세요


## Version 2.1.4 (2021.02.11)
- 통합검색 추가

## Version 2.1.3 (2021.01.13)
- 썸네일, 포스터

## Version 2.1.2 (2020.11.27)
- 로그인오류 수정

## Version 2.1.1 (2020.11.26)
- 썸네일

## Version 2.1.0 (2020.11.01)
- 코드정리

## Version 2.0.6 (2020.10.20)
- kodi update 대응

## Version 2.0.5 (2020.10.08)
- alpha_2 오류 수정

## Version 2.0.4 (2020.09.24)
- 오류수정

## Version 2.0.3 (2020.09.16)
- 재접속 오류수정

## Version 2.0.2 (2020.09.09)
- timezone

## Version 2.0.1 (2020.09.08)
- 특정스킨 오류 수정

## Version 2.0.0 (2020.08.29)
- python3(kodi 19) 전환

