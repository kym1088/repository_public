__author__="NightRain"
fdGczUeqshkiyKWRHLTMNJSPojurBF=object
fdGczUeqshkiyKWRHLTMNJSPojurBm=None
fdGczUeqshkiyKWRHLTMNJSPojurBX=False
fdGczUeqshkiyKWRHLTMNJSPojurBA=True
fdGczUeqshkiyKWRHLTMNJSPojurBE=Exception
fdGczUeqshkiyKWRHLTMNJSPojurBv=print
fdGczUeqshkiyKWRHLTMNJSPojurBC=str
fdGczUeqshkiyKWRHLTMNJSPojurBp=len
fdGczUeqshkiyKWRHLTMNJSPojurBb=int
fdGczUeqshkiyKWRHLTMNJSPojurBI=range
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
class fdGczUeqshkiyKWRHLTMNJSPojurna(fdGczUeqshkiyKWRHLTMNJSPojurBF):
 def __init__(fdGczUeqshkiyKWRHLTMNJSPojurnV):
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_TOKEN ='' 
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUIT =''
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUITV =''
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_USERCD=''
  fdGczUeqshkiyKWRHLTMNJSPojurnV.MAIN_DOMAIN ='https://watcha.com'
  fdGczUeqshkiyKWRHLTMNJSPojurnV.API_DOMAIN ='https://api-mars.watcha.com'
  fdGczUeqshkiyKWRHLTMNJSPojurnV.EPISODE_LIMIT=20
  fdGczUeqshkiyKWRHLTMNJSPojurnV.SEARCH_LIMIT =30
  fdGczUeqshkiyKWRHLTMNJSPojurnV.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  fdGczUeqshkiyKWRHLTMNJSPojurnV.DEFAULT_HEADER={'user-agent':fdGczUeqshkiyKWRHLTMNJSPojurnV.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(fdGczUeqshkiyKWRHLTMNJSPojurnV,jobtype,fdGczUeqshkiyKWRHLTMNJSPojurnD,payload=fdGczUeqshkiyKWRHLTMNJSPojurBm,params=fdGczUeqshkiyKWRHLTMNJSPojurBm,headers=fdGczUeqshkiyKWRHLTMNJSPojurBm,cookies=fdGczUeqshkiyKWRHLTMNJSPojurBm,redirects=fdGczUeqshkiyKWRHLTMNJSPojurBX):
  fdGczUeqshkiyKWRHLTMNJSPojurnB=fdGczUeqshkiyKWRHLTMNJSPojurnV.DEFAULT_HEADER
  if headers:fdGczUeqshkiyKWRHLTMNJSPojurnB.update(headers)
  if jobtype=='Get':
   fdGczUeqshkiyKWRHLTMNJSPojurnt=requests.get(fdGczUeqshkiyKWRHLTMNJSPojurnD,params=params,headers=fdGczUeqshkiyKWRHLTMNJSPojurnB,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   fdGczUeqshkiyKWRHLTMNJSPojurnt=requests.put(fdGczUeqshkiyKWRHLTMNJSPojurnD,data=payload,params=params,headers=fdGczUeqshkiyKWRHLTMNJSPojurnB,cookies=cookies,allow_redirects=redirects)
  else:
   fdGczUeqshkiyKWRHLTMNJSPojurnt=requests.post(fdGczUeqshkiyKWRHLTMNJSPojurnD,data=payload,params=params,headers=fdGczUeqshkiyKWRHLTMNJSPojurnB,cookies=cookies,allow_redirects=redirects)
  return fdGczUeqshkiyKWRHLTMNJSPojurnt
 def SaveCredential(fdGczUeqshkiyKWRHLTMNJSPojurnV,fdGczUeqshkiyKWRHLTMNJSPojurnF):
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_TOKEN =fdGczUeqshkiyKWRHLTMNJSPojurnF.get('watcha_token')
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUIT =fdGczUeqshkiyKWRHLTMNJSPojurnF.get('watcha_guit')
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUITV =fdGczUeqshkiyKWRHLTMNJSPojurnF.get('watcha_guitv')
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_USERCD =fdGczUeqshkiyKWRHLTMNJSPojurnF.get('watcha_usercd')
 def SaveCredential_usercd(fdGczUeqshkiyKWRHLTMNJSPojurnV,fdGczUeqshkiyKWRHLTMNJSPojurnm):
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_USERCD=fdGczUeqshkiyKWRHLTMNJSPojurnm
 def SaveCredential_guitv(fdGczUeqshkiyKWRHLTMNJSPojurnV,fdGczUeqshkiyKWRHLTMNJSPojurnX,fdGczUeqshkiyKWRHLTMNJSPojurnA):
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUITV=fdGczUeqshkiyKWRHLTMNJSPojurnX
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_TOKEN=fdGczUeqshkiyKWRHLTMNJSPojurnA 
 def ClearCredential(fdGczUeqshkiyKWRHLTMNJSPojurnV):
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_TOKEN ='' 
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUIT =''
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUITV =''
  fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_USERCD=''
 def LoadCredential(fdGczUeqshkiyKWRHLTMNJSPojurnV):
  fdGczUeqshkiyKWRHLTMNJSPojurnF={'watcha_token':fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_TOKEN,'watcha_guit':fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUIT,'watcha_guitv':fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUITV,'watcha_usercd':fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_USERCD}
  return fdGczUeqshkiyKWRHLTMNJSPojurnF
 def makeDefaultCookies(fdGczUeqshkiyKWRHLTMNJSPojurnV):
  fdGczUeqshkiyKWRHLTMNJSPojurnE={'_s_guit':fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUIT,'_guinness-premium_session':fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_TOKEN}
  if fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUITV:
   fdGczUeqshkiyKWRHLTMNJSPojurnE['_s_guitv']=fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_GUITV
  return fdGczUeqshkiyKWRHLTMNJSPojurnE
 def GetCredential(fdGczUeqshkiyKWRHLTMNJSPojurnV,user_id,user_pw,user_pf):
  fdGczUeqshkiyKWRHLTMNJSPojurnv=fdGczUeqshkiyKWRHLTMNJSPojurBX
  fdGczUeqshkiyKWRHLTMNJSPojurnC=fdGczUeqshkiyKWRHLTMNJSPojurnY='-'
  try:
   fdGczUeqshkiyKWRHLTMNJSPojurnp=fdGczUeqshkiyKWRHLTMNJSPojurnV.API_DOMAIN+'/api/session'
   fdGczUeqshkiyKWRHLTMNJSPojurnb={'email':user_id,'password':user_pw}
   fdGczUeqshkiyKWRHLTMNJSPojurnI={'accept':'application/vnd.frograms+json;version=4'}
   fdGczUeqshkiyKWRHLTMNJSPojurnx=fdGczUeqshkiyKWRHLTMNJSPojurnV.callRequestCookies('Post',fdGczUeqshkiyKWRHLTMNJSPojurnp,payload=fdGczUeqshkiyKWRHLTMNJSPojurnb,params=fdGczUeqshkiyKWRHLTMNJSPojurBm,headers=fdGczUeqshkiyKWRHLTMNJSPojurnI,cookies=fdGczUeqshkiyKWRHLTMNJSPojurBm)
   for fdGczUeqshkiyKWRHLTMNJSPojurng in fdGczUeqshkiyKWRHLTMNJSPojurnx.cookies:
    if fdGczUeqshkiyKWRHLTMNJSPojurng.name=='_guinness-premium_session':
     fdGczUeqshkiyKWRHLTMNJSPojurnY=fdGczUeqshkiyKWRHLTMNJSPojurng.value
    elif fdGczUeqshkiyKWRHLTMNJSPojurng.name=='_s_guit':
     fdGczUeqshkiyKWRHLTMNJSPojurnC=fdGczUeqshkiyKWRHLTMNJSPojurng.value
   if fdGczUeqshkiyKWRHLTMNJSPojurnY:fdGczUeqshkiyKWRHLTMNJSPojurnv=fdGczUeqshkiyKWRHLTMNJSPojurBA
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   fdGczUeqshkiyKWRHLTMNJSPojurBv(exception)
   fdGczUeqshkiyKWRHLTMNJSPojurnC=fdGczUeqshkiyKWRHLTMNJSPojurnY='' 
  fdGczUeqshkiyKWRHLTMNJSPojurnF={'watcha_guit':fdGczUeqshkiyKWRHLTMNJSPojurnC,'watcha_token':fdGczUeqshkiyKWRHLTMNJSPojurnY,'watcha_guitv':'','watcha_usercd':''}
  fdGczUeqshkiyKWRHLTMNJSPojurnV.SaveCredential(fdGczUeqshkiyKWRHLTMNJSPojurnF)
  try:
   fdGczUeqshkiyKWRHLTMNJSPojurnw=fdGczUeqshkiyKWRHLTMNJSPojurnV.GetProfilesList()
   fdGczUeqshkiyKWRHLTMNJSPojurnQ =fdGczUeqshkiyKWRHLTMNJSPojurnw[user_pf]
   fdGczUeqshkiyKWRHLTMNJSPojurnV.SaveCredential_usercd(fdGczUeqshkiyKWRHLTMNJSPojurnQ)
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   fdGczUeqshkiyKWRHLTMNJSPojurBv(exception)
   fdGczUeqshkiyKWRHLTMNJSPojurnV.ClearCredential()
   return fdGczUeqshkiyKWRHLTMNJSPojurBX
  if user_pf!=0:
   fdGczUeqshkiyKWRHLTMNJSPojurnX,fdGczUeqshkiyKWRHLTMNJSPojurnA=fdGczUeqshkiyKWRHLTMNJSPojurnV.GetProfilesConvert(fdGczUeqshkiyKWRHLTMNJSPojurnQ)
   fdGczUeqshkiyKWRHLTMNJSPojurnV.SaveCredential_guitv(fdGczUeqshkiyKWRHLTMNJSPojurnX,fdGczUeqshkiyKWRHLTMNJSPojurnA)
  return fdGczUeqshkiyKWRHLTMNJSPojurnv
 def GetSubGroupList(fdGczUeqshkiyKWRHLTMNJSPojurnV,stype):
  fdGczUeqshkiyKWRHLTMNJSPojurnl=[]
  try:
   fdGczUeqshkiyKWRHLTMNJSPojurnO ='/api/categories.json'
   fdGczUeqshkiyKWRHLTMNJSPojurnD=fdGczUeqshkiyKWRHLTMNJSPojurnV.API_DOMAIN+fdGczUeqshkiyKWRHLTMNJSPojurnO
   fdGczUeqshkiyKWRHLTMNJSPojurnx=fdGczUeqshkiyKWRHLTMNJSPojurnV.callRequestCookies('Get',fdGczUeqshkiyKWRHLTMNJSPojurnD,payload=fdGczUeqshkiyKWRHLTMNJSPojurBm,params=fdGczUeqshkiyKWRHLTMNJSPojurBm,headers=fdGczUeqshkiyKWRHLTMNJSPojurBm,cookies=fdGczUeqshkiyKWRHLTMNJSPojurBm)
   fdGczUeqshkiyKWRHLTMNJSPojuran=json.loads(fdGczUeqshkiyKWRHLTMNJSPojurnx.text)
   if not('genres' in fdGczUeqshkiyKWRHLTMNJSPojuran):return fdGczUeqshkiyKWRHLTMNJSPojurnl
   if stype=='genres':
    fdGczUeqshkiyKWRHLTMNJSPojuraV=fdGczUeqshkiyKWRHLTMNJSPojuran['genres']
   else:
    fdGczUeqshkiyKWRHLTMNJSPojuraV=fdGczUeqshkiyKWRHLTMNJSPojuran['tags']
   for fdGczUeqshkiyKWRHLTMNJSPojuraB in fdGczUeqshkiyKWRHLTMNJSPojuraV:
    fdGczUeqshkiyKWRHLTMNJSPojurat=fdGczUeqshkiyKWRHLTMNJSPojuraB['name']
    fdGczUeqshkiyKWRHLTMNJSPojuraF =fdGczUeqshkiyKWRHLTMNJSPojuraB['api_path']
    fdGczUeqshkiyKWRHLTMNJSPojuram =fdGczUeqshkiyKWRHLTMNJSPojuraB['entity']['id']
    fdGczUeqshkiyKWRHLTMNJSPojuraX={'group_name':fdGczUeqshkiyKWRHLTMNJSPojurat,'api_path':fdGczUeqshkiyKWRHLTMNJSPojuraF,'tag_id':fdGczUeqshkiyKWRHLTMNJSPojurBC(fdGczUeqshkiyKWRHLTMNJSPojuram)}
    fdGczUeqshkiyKWRHLTMNJSPojurnl.append(fdGczUeqshkiyKWRHLTMNJSPojuraX)
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   fdGczUeqshkiyKWRHLTMNJSPojurBv(exception)
  return fdGczUeqshkiyKWRHLTMNJSPojurnl
 def GetCategoryList(fdGczUeqshkiyKWRHLTMNJSPojurnV,stype,fdGczUeqshkiyKWRHLTMNJSPojuram,fdGczUeqshkiyKWRHLTMNJSPojuraF,page_int,in_sort):
  fdGczUeqshkiyKWRHLTMNJSPojurnl=[]
  fdGczUeqshkiyKWRHLTMNJSPojuraA=fdGczUeqshkiyKWRHLTMNJSPojurBX
  fdGczUeqshkiyKWRHLTMNJSPojuraE={}
  try:
   if 'categories' in fdGczUeqshkiyKWRHLTMNJSPojuraF:
    fdGczUeqshkiyKWRHLTMNJSPojurnO ='/api/categories/contents.json'
    if stype=='genres':
     fdGczUeqshkiyKWRHLTMNJSPojuraE['genre']=fdGczUeqshkiyKWRHLTMNJSPojuram
    else:
     fdGczUeqshkiyKWRHLTMNJSPojuraE['tag'] =fdGczUeqshkiyKWRHLTMNJSPojuram
    fdGczUeqshkiyKWRHLTMNJSPojuraE['order']=in_sort 
    if page_int>1:
     fdGczUeqshkiyKWRHLTMNJSPojuraE['page']=fdGczUeqshkiyKWRHLTMNJSPojurBC(page_int-1)
   else: 
    fdGczUeqshkiyKWRHLTMNJSPojurnO ='/api/'+fdGczUeqshkiyKWRHLTMNJSPojuraF+'.json'
    if page_int>1:
     fdGczUeqshkiyKWRHLTMNJSPojuraE['page']=fdGczUeqshkiyKWRHLTMNJSPojurBC(page_int)
   fdGczUeqshkiyKWRHLTMNJSPojurnD=fdGczUeqshkiyKWRHLTMNJSPojurnV.API_DOMAIN+fdGczUeqshkiyKWRHLTMNJSPojurnO
   fdGczUeqshkiyKWRHLTMNJSPojurng=fdGczUeqshkiyKWRHLTMNJSPojurnV.makeDefaultCookies()
   fdGczUeqshkiyKWRHLTMNJSPojurnx=fdGczUeqshkiyKWRHLTMNJSPojurnV.callRequestCookies('Get',fdGczUeqshkiyKWRHLTMNJSPojurnD,payload=fdGczUeqshkiyKWRHLTMNJSPojurBm,params=fdGczUeqshkiyKWRHLTMNJSPojuraE,headers=fdGczUeqshkiyKWRHLTMNJSPojurBm,cookies=fdGczUeqshkiyKWRHLTMNJSPojurng)
   fdGczUeqshkiyKWRHLTMNJSPojuran=json.loads(fdGczUeqshkiyKWRHLTMNJSPojurnx.text)
   if not('contents' in fdGczUeqshkiyKWRHLTMNJSPojuran):return fdGczUeqshkiyKWRHLTMNJSPojurnl,fdGczUeqshkiyKWRHLTMNJSPojuraA
   fdGczUeqshkiyKWRHLTMNJSPojuraV=fdGczUeqshkiyKWRHLTMNJSPojuran['contents']
   fdGczUeqshkiyKWRHLTMNJSPojuraA=fdGczUeqshkiyKWRHLTMNJSPojuran['meta']['has_next']
   for fdGczUeqshkiyKWRHLTMNJSPojuraB in fdGczUeqshkiyKWRHLTMNJSPojuraV:
    fdGczUeqshkiyKWRHLTMNJSPojurav =fdGczUeqshkiyKWRHLTMNJSPojuraB['code']
    fdGczUeqshkiyKWRHLTMNJSPojuraC=fdGczUeqshkiyKWRHLTMNJSPojuraB['content_type']
    fdGczUeqshkiyKWRHLTMNJSPojurap =fdGczUeqshkiyKWRHLTMNJSPojuraB['title']
    fdGczUeqshkiyKWRHLTMNJSPojurab =fdGczUeqshkiyKWRHLTMNJSPojuraB['story']
    fdGczUeqshkiyKWRHLTMNJSPojuraI=tmp_thumb=tmp_fanart=''
    if fdGczUeqshkiyKWRHLTMNJSPojuraB.get('poster') !=fdGczUeqshkiyKWRHLTMNJSPojurBm:fdGczUeqshkiyKWRHLTMNJSPojuraI=fdGczUeqshkiyKWRHLTMNJSPojuraB.get('poster').get('original')
    if fdGczUeqshkiyKWRHLTMNJSPojuraB.get('stillcut')!=fdGczUeqshkiyKWRHLTMNJSPojurBm:tmp_thumb =fdGczUeqshkiyKWRHLTMNJSPojuraB.get('stillcut').get('large')
    if fdGczUeqshkiyKWRHLTMNJSPojuraB.get('thumbnail')!=fdGczUeqshkiyKWRHLTMNJSPojurBm:tmp_fanart=fdGczUeqshkiyKWRHLTMNJSPojuraB.get('thumbnail').get('large')
    if tmp_fanart=='' :tmp_fanart=tmp_thumb
    fdGczUeqshkiyKWRHLTMNJSPojurax={'thumb':tmp_thumb,'poster':fdGczUeqshkiyKWRHLTMNJSPojuraI,'fanart':tmp_fanart}
    fdGczUeqshkiyKWRHLTMNJSPojurag =fdGczUeqshkiyKWRHLTMNJSPojuraB['year']
    fdGczUeqshkiyKWRHLTMNJSPojuraY =fdGczUeqshkiyKWRHLTMNJSPojuraB['film_rating_code']
    fdGczUeqshkiyKWRHLTMNJSPojuraw=fdGczUeqshkiyKWRHLTMNJSPojuraB['film_rating_short']
    fdGczUeqshkiyKWRHLTMNJSPojuraQ =fdGczUeqshkiyKWRHLTMNJSPojuraB['film_rating_long']
    if fdGczUeqshkiyKWRHLTMNJSPojuraC=='movies':
     fdGczUeqshkiyKWRHLTMNJSPojural =fdGczUeqshkiyKWRHLTMNJSPojuraB['duration']
    else:
     fdGczUeqshkiyKWRHLTMNJSPojural ='0'
    fdGczUeqshkiyKWRHLTMNJSPojuraX={'code':fdGczUeqshkiyKWRHLTMNJSPojurav,'content_type':fdGczUeqshkiyKWRHLTMNJSPojuraC,'title':fdGczUeqshkiyKWRHLTMNJSPojurap,'story':fdGczUeqshkiyKWRHLTMNJSPojurab,'thumbnail':fdGczUeqshkiyKWRHLTMNJSPojurax,'year':fdGczUeqshkiyKWRHLTMNJSPojurag,'film_rating_code':fdGczUeqshkiyKWRHLTMNJSPojuraY,'film_rating_short':fdGczUeqshkiyKWRHLTMNJSPojuraw,'film_rating_long':fdGczUeqshkiyKWRHLTMNJSPojuraQ,'duration':fdGczUeqshkiyKWRHLTMNJSPojural}
    fdGczUeqshkiyKWRHLTMNJSPojurnl.append(fdGczUeqshkiyKWRHLTMNJSPojuraX)
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   fdGczUeqshkiyKWRHLTMNJSPojurBv(exception)
  return fdGczUeqshkiyKWRHLTMNJSPojurnl,fdGczUeqshkiyKWRHLTMNJSPojuraA
 def GetCategoryList_morepage(fdGczUeqshkiyKWRHLTMNJSPojurnV,stype,fdGczUeqshkiyKWRHLTMNJSPojuram,fdGczUeqshkiyKWRHLTMNJSPojuraF,page_int,in_sort):
  fdGczUeqshkiyKWRHLTMNJSPojuraA=fdGczUeqshkiyKWRHLTMNJSPojurBX
  if not('categories' in fdGczUeqshkiyKWRHLTMNJSPojuraF):return fdGczUeqshkiyKWRHLTMNJSPojurBA
  try:
   fdGczUeqshkiyKWRHLTMNJSPojurnO ='/api/categories/contents.json'
   fdGczUeqshkiyKWRHLTMNJSPojurnD=fdGczUeqshkiyKWRHLTMNJSPojurnV.API_DOMAIN+fdGczUeqshkiyKWRHLTMNJSPojurnO
   fdGczUeqshkiyKWRHLTMNJSPojuraE={}
   if stype=='genres':
    fdGczUeqshkiyKWRHLTMNJSPojuraE['genre']=fdGczUeqshkiyKWRHLTMNJSPojuram
   else:
    fdGczUeqshkiyKWRHLTMNJSPojuraE['tag'] =fdGczUeqshkiyKWRHLTMNJSPojuram
   fdGczUeqshkiyKWRHLTMNJSPojuraE['order']=in_sort 
   if page_int>1:
    fdGczUeqshkiyKWRHLTMNJSPojuraE['page']=fdGczUeqshkiyKWRHLTMNJSPojurBC(page_int-1)
   fdGczUeqshkiyKWRHLTMNJSPojurnx=fdGczUeqshkiyKWRHLTMNJSPojurnV.callRequestCookies('Get',fdGczUeqshkiyKWRHLTMNJSPojurnD,payload=fdGczUeqshkiyKWRHLTMNJSPojurBm,params=fdGczUeqshkiyKWRHLTMNJSPojuraE,headers=fdGczUeqshkiyKWRHLTMNJSPojurBm,cookies=fdGczUeqshkiyKWRHLTMNJSPojurBm)
   fdGczUeqshkiyKWRHLTMNJSPojuran=json.loads(fdGczUeqshkiyKWRHLTMNJSPojurnx.text)
   fdGczUeqshkiyKWRHLTMNJSPojuraA=fdGczUeqshkiyKWRHLTMNJSPojuran['meta']['has_next']
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   fdGczUeqshkiyKWRHLTMNJSPojurBv(exception)
  return fdGczUeqshkiyKWRHLTMNJSPojuraA
 def GetProgramInfo(fdGczUeqshkiyKWRHLTMNJSPojurnV,program_code):
  fdGczUeqshkiyKWRHLTMNJSPojuraO={}
  try:
   fdGczUeqshkiyKWRHLTMNJSPojurnO ='/api/contents/'+program_code
   fdGczUeqshkiyKWRHLTMNJSPojurnD=fdGczUeqshkiyKWRHLTMNJSPojurnV.API_DOMAIN+fdGczUeqshkiyKWRHLTMNJSPojurnO
   fdGczUeqshkiyKWRHLTMNJSPojurnx=fdGczUeqshkiyKWRHLTMNJSPojurnV.callRequestCookies('Get',fdGczUeqshkiyKWRHLTMNJSPojurnD,payload=fdGczUeqshkiyKWRHLTMNJSPojurBm,params=fdGczUeqshkiyKWRHLTMNJSPojurBm,headers=fdGczUeqshkiyKWRHLTMNJSPojurBm,cookies=fdGczUeqshkiyKWRHLTMNJSPojurBm)
   fdGczUeqshkiyKWRHLTMNJSPojuran=json.loads(fdGczUeqshkiyKWRHLTMNJSPojurnx.text)
   fdGczUeqshkiyKWRHLTMNJSPojuraD=img_clearlogo=''
   fdGczUeqshkiyKWRHLTMNJSPojuraD=fdGczUeqshkiyKWRHLTMNJSPojuran.get('poster').get('original')
   if fdGczUeqshkiyKWRHLTMNJSPojurBp(fdGczUeqshkiyKWRHLTMNJSPojuran.get('title_logos'))>0:img_clearlogo=fdGczUeqshkiyKWRHLTMNJSPojuran.get('title_logos')[0].get('src')
   fdGczUeqshkiyKWRHLTMNJSPojuraO={'imgPoster':fdGczUeqshkiyKWRHLTMNJSPojuraD,'imgClearlogo':img_clearlogo}
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   fdGczUeqshkiyKWRHLTMNJSPojurBv(exception)
  return fdGczUeqshkiyKWRHLTMNJSPojuraO
 def GetEpisodoList(fdGczUeqshkiyKWRHLTMNJSPojurnV,program_code,page_int,orderby='asc'):
  fdGczUeqshkiyKWRHLTMNJSPojurnl=[]
  fdGczUeqshkiyKWRHLTMNJSPojuraA=fdGczUeqshkiyKWRHLTMNJSPojurBX
  fdGczUeqshkiyKWRHLTMNJSPojurVn=''
  try:
   fdGczUeqshkiyKWRHLTMNJSPojurnO ='/api/contents/'+program_code+'/tv_episodes.json'
   fdGczUeqshkiyKWRHLTMNJSPojurnD=fdGczUeqshkiyKWRHLTMNJSPojurnV.API_DOMAIN+fdGczUeqshkiyKWRHLTMNJSPojurnO
   fdGczUeqshkiyKWRHLTMNJSPojuraE={'all':'true'}
   fdGczUeqshkiyKWRHLTMNJSPojurnx=fdGczUeqshkiyKWRHLTMNJSPojurnV.callRequestCookies('Get',fdGczUeqshkiyKWRHLTMNJSPojurnD,payload=fdGczUeqshkiyKWRHLTMNJSPojurBm,params=fdGczUeqshkiyKWRHLTMNJSPojuraE,headers=fdGczUeqshkiyKWRHLTMNJSPojurBm,cookies=fdGczUeqshkiyKWRHLTMNJSPojurBm)
   fdGczUeqshkiyKWRHLTMNJSPojuran=json.loads(fdGczUeqshkiyKWRHLTMNJSPojurnx.text)
   if not('tv_episode_codes' in fdGczUeqshkiyKWRHLTMNJSPojuran):return fdGczUeqshkiyKWRHLTMNJSPojurnl,fdGczUeqshkiyKWRHLTMNJSPojuraA
   fdGczUeqshkiyKWRHLTMNJSPojuraV=fdGczUeqshkiyKWRHLTMNJSPojuran['tv_episode_codes']
   fdGczUeqshkiyKWRHLTMNJSPojurVa=fdGczUeqshkiyKWRHLTMNJSPojurBp(fdGczUeqshkiyKWRHLTMNJSPojuraV)
   fdGczUeqshkiyKWRHLTMNJSPojurVB =fdGczUeqshkiyKWRHLTMNJSPojurBb(fdGczUeqshkiyKWRHLTMNJSPojurVa//(fdGczUeqshkiyKWRHLTMNJSPojurnV.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    fdGczUeqshkiyKWRHLTMNJSPojurVt =(fdGczUeqshkiyKWRHLTMNJSPojurVa-1)-((page_int-1)*fdGczUeqshkiyKWRHLTMNJSPojurnV.EPISODE_LIMIT)
   else:
    fdGczUeqshkiyKWRHLTMNJSPojurVt =(page_int-1)*fdGczUeqshkiyKWRHLTMNJSPojurnV.EPISODE_LIMIT
   for i in fdGczUeqshkiyKWRHLTMNJSPojurBI(fdGczUeqshkiyKWRHLTMNJSPojurnV.EPISODE_LIMIT):
    if orderby=='desc':
     fdGczUeqshkiyKWRHLTMNJSPojurVF=fdGczUeqshkiyKWRHLTMNJSPojurVt-i
     if fdGczUeqshkiyKWRHLTMNJSPojurVF<0:break
    else:
     fdGczUeqshkiyKWRHLTMNJSPojurVF=fdGczUeqshkiyKWRHLTMNJSPojurVt+i
     if fdGczUeqshkiyKWRHLTMNJSPojurVF>=fdGczUeqshkiyKWRHLTMNJSPojurVa:break
    if fdGczUeqshkiyKWRHLTMNJSPojurVn!='':fdGczUeqshkiyKWRHLTMNJSPojurVn+=','
    fdGczUeqshkiyKWRHLTMNJSPojurVn+=fdGczUeqshkiyKWRHLTMNJSPojuraV[fdGczUeqshkiyKWRHLTMNJSPojurVF]
   if fdGczUeqshkiyKWRHLTMNJSPojurVB>page_int:fdGczUeqshkiyKWRHLTMNJSPojuraA=fdGczUeqshkiyKWRHLTMNJSPojurBA
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   fdGczUeqshkiyKWRHLTMNJSPojurBv(exception)
  fdGczUeqshkiyKWRHLTMNJSPojurVm=fdGczUeqshkiyKWRHLTMNJSPojurnV.GetProgramInfo(program_code)
  try:
   fdGczUeqshkiyKWRHLTMNJSPojurnD=fdGczUeqshkiyKWRHLTMNJSPojurnV.API_DOMAIN+fdGczUeqshkiyKWRHLTMNJSPojurnO
   fdGczUeqshkiyKWRHLTMNJSPojuraE={'codes':fdGczUeqshkiyKWRHLTMNJSPojurVn}
   fdGczUeqshkiyKWRHLTMNJSPojurnx=fdGczUeqshkiyKWRHLTMNJSPojurnV.callRequestCookies('Get',fdGczUeqshkiyKWRHLTMNJSPojurnD,payload=fdGczUeqshkiyKWRHLTMNJSPojurBm,params=fdGczUeqshkiyKWRHLTMNJSPojuraE,headers=fdGczUeqshkiyKWRHLTMNJSPojurBm,cookies=fdGczUeqshkiyKWRHLTMNJSPojurBm)
   fdGczUeqshkiyKWRHLTMNJSPojuran=json.loads(fdGczUeqshkiyKWRHLTMNJSPojurnx.text)
   if not('tv_episodes' in fdGczUeqshkiyKWRHLTMNJSPojuran):return fdGczUeqshkiyKWRHLTMNJSPojurnl
   fdGczUeqshkiyKWRHLTMNJSPojuraV=fdGczUeqshkiyKWRHLTMNJSPojuran['tv_episodes']
   for fdGczUeqshkiyKWRHLTMNJSPojuraB in fdGczUeqshkiyKWRHLTMNJSPojuraV:
    fdGczUeqshkiyKWRHLTMNJSPojurav =fdGczUeqshkiyKWRHLTMNJSPojuraB['code']
    if fdGczUeqshkiyKWRHLTMNJSPojuraB['title']:
     fdGczUeqshkiyKWRHLTMNJSPojurap =fdGczUeqshkiyKWRHLTMNJSPojuraB['title']
    else:
     fdGczUeqshkiyKWRHLTMNJSPojurap =''
    fdGczUeqshkiyKWRHLTMNJSPojuraI=tmp_thumb=tmp_fanart=fdGczUeqshkiyKWRHLTMNJSPojurVX=''
    fdGczUeqshkiyKWRHLTMNJSPojuraI =fdGczUeqshkiyKWRHLTMNJSPojurVm.get('imgPoster')
    fdGczUeqshkiyKWRHLTMNJSPojurVX=fdGczUeqshkiyKWRHLTMNJSPojurVm.get('imgClearlogo')
    if fdGczUeqshkiyKWRHLTMNJSPojuraB.get('stillcut') !=fdGczUeqshkiyKWRHLTMNJSPojurBm:tmp_thumb =fdGczUeqshkiyKWRHLTMNJSPojuraB.get('stillcut').get('large')
    if fdGczUeqshkiyKWRHLTMNJSPojuraB.get('tv_season_stillcut')!=fdGczUeqshkiyKWRHLTMNJSPojurBm:tmp_fanart=fdGczUeqshkiyKWRHLTMNJSPojuraB.get('tv_season_stillcut').get('large')
    fdGczUeqshkiyKWRHLTMNJSPojurax={'thumb':tmp_thumb,'poster':fdGczUeqshkiyKWRHLTMNJSPojuraI,'fanart':tmp_fanart,'clearlogo':fdGczUeqshkiyKWRHLTMNJSPojurVX}
    fdGczUeqshkiyKWRHLTMNJSPojurVA =fdGczUeqshkiyKWRHLTMNJSPojuraB['display_number']
    fdGczUeqshkiyKWRHLTMNJSPojurVE=fdGczUeqshkiyKWRHLTMNJSPojuraB['tv_season_title']
    fdGczUeqshkiyKWRHLTMNJSPojural =fdGczUeqshkiyKWRHLTMNJSPojuraB['duration']
    try:
     fdGczUeqshkiyKWRHLTMNJSPojurVv=fdGczUeqshkiyKWRHLTMNJSPojuraB['episode_number']
    except:
     fdGczUeqshkiyKWRHLTMNJSPojurVv='0'
    fdGczUeqshkiyKWRHLTMNJSPojuraX={'code':fdGczUeqshkiyKWRHLTMNJSPojurav,'title':fdGczUeqshkiyKWRHLTMNJSPojurap,'thumbnail':fdGczUeqshkiyKWRHLTMNJSPojurax,'display_num':fdGczUeqshkiyKWRHLTMNJSPojurVA,'season_title':fdGczUeqshkiyKWRHLTMNJSPojurVE,'duration':fdGczUeqshkiyKWRHLTMNJSPojural,'episode_number':fdGczUeqshkiyKWRHLTMNJSPojurVv}
    fdGczUeqshkiyKWRHLTMNJSPojurnl.append(fdGczUeqshkiyKWRHLTMNJSPojuraX)
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   fdGczUeqshkiyKWRHLTMNJSPojurBv(exception)
  return fdGczUeqshkiyKWRHLTMNJSPojurnl,fdGczUeqshkiyKWRHLTMNJSPojuraA
 def GetSearchList(fdGczUeqshkiyKWRHLTMNJSPojurnV,search_key,page_int):
  fdGczUeqshkiyKWRHLTMNJSPojurVC=[]
  fdGczUeqshkiyKWRHLTMNJSPojuraA=fdGczUeqshkiyKWRHLTMNJSPojurBX
  try:
   fdGczUeqshkiyKWRHLTMNJSPojurnO ='/api/search.json'
   fdGczUeqshkiyKWRHLTMNJSPojurnD=fdGczUeqshkiyKWRHLTMNJSPojurnV.API_DOMAIN+fdGczUeqshkiyKWRHLTMNJSPojurnO
   fdGczUeqshkiyKWRHLTMNJSPojuraE={'query':search_key,'page':fdGczUeqshkiyKWRHLTMNJSPojurBC(page_int),'per':fdGczUeqshkiyKWRHLTMNJSPojurBC(fdGczUeqshkiyKWRHLTMNJSPojurnV.SEARCH_LIMIT),'exclude':'limited'}
   fdGczUeqshkiyKWRHLTMNJSPojurnx=fdGczUeqshkiyKWRHLTMNJSPojurnV.callRequestCookies('Get',fdGczUeqshkiyKWRHLTMNJSPojurnD,payload=fdGczUeqshkiyKWRHLTMNJSPojurBm,params=fdGczUeqshkiyKWRHLTMNJSPojuraE,headers=fdGczUeqshkiyKWRHLTMNJSPojurBm,cookies=fdGczUeqshkiyKWRHLTMNJSPojurBm)
   fdGczUeqshkiyKWRHLTMNJSPojuran=json.loads(fdGczUeqshkiyKWRHLTMNJSPojurnx.text)
   if not('results' in fdGczUeqshkiyKWRHLTMNJSPojuran):return fdGczUeqshkiyKWRHLTMNJSPojurVC,fdGczUeqshkiyKWRHLTMNJSPojuraA
   fdGczUeqshkiyKWRHLTMNJSPojuraV=fdGczUeqshkiyKWRHLTMNJSPojuran['results']
   fdGczUeqshkiyKWRHLTMNJSPojuraA=fdGczUeqshkiyKWRHLTMNJSPojuran['meta']['has_next']
   for fdGczUeqshkiyKWRHLTMNJSPojuraB in fdGczUeqshkiyKWRHLTMNJSPojuraV:
    fdGczUeqshkiyKWRHLTMNJSPojurav =fdGczUeqshkiyKWRHLTMNJSPojuraB['code']
    fdGczUeqshkiyKWRHLTMNJSPojuraC=fdGczUeqshkiyKWRHLTMNJSPojuraB['content_type']
    fdGczUeqshkiyKWRHLTMNJSPojurap =fdGczUeqshkiyKWRHLTMNJSPojuraB['title']
    fdGczUeqshkiyKWRHLTMNJSPojurab =fdGczUeqshkiyKWRHLTMNJSPojuraB['story']
    fdGczUeqshkiyKWRHLTMNJSPojuraI=tmp_thumb=tmp_fanart=''
    if fdGczUeqshkiyKWRHLTMNJSPojuraB.get('poster') !=fdGczUeqshkiyKWRHLTMNJSPojurBm:fdGczUeqshkiyKWRHLTMNJSPojuraI=fdGczUeqshkiyKWRHLTMNJSPojuraB.get('poster').get('original')
    if fdGczUeqshkiyKWRHLTMNJSPojuraB.get('stillcut')!=fdGczUeqshkiyKWRHLTMNJSPojurBm:tmp_thumb =fdGczUeqshkiyKWRHLTMNJSPojuraB.get('stillcut').get('large')
    if fdGczUeqshkiyKWRHLTMNJSPojuraB.get('thumbnail')!=fdGczUeqshkiyKWRHLTMNJSPojurBm:tmp_fanart=fdGczUeqshkiyKWRHLTMNJSPojuraB.get('thumbnail').get('large')
    if tmp_fanart=='' :tmp_fanart=tmp_thumb
    fdGczUeqshkiyKWRHLTMNJSPojurax={'thumb':tmp_thumb,'poster':fdGczUeqshkiyKWRHLTMNJSPojuraI,'fanart':tmp_fanart}
    fdGczUeqshkiyKWRHLTMNJSPojurag =fdGczUeqshkiyKWRHLTMNJSPojuraB['year']
    fdGczUeqshkiyKWRHLTMNJSPojuraY =fdGczUeqshkiyKWRHLTMNJSPojuraB['film_rating_code']
    fdGczUeqshkiyKWRHLTMNJSPojuraw=fdGczUeqshkiyKWRHLTMNJSPojuraB['film_rating_short']
    fdGczUeqshkiyKWRHLTMNJSPojuraQ =fdGczUeqshkiyKWRHLTMNJSPojuraB['film_rating_long']
    if fdGczUeqshkiyKWRHLTMNJSPojuraC=='movies':
     fdGczUeqshkiyKWRHLTMNJSPojural =fdGczUeqshkiyKWRHLTMNJSPojuraB['duration']
    else:
     fdGczUeqshkiyKWRHLTMNJSPojural ='0'
    fdGczUeqshkiyKWRHLTMNJSPojuraX={'code':fdGczUeqshkiyKWRHLTMNJSPojurav,'content_type':fdGczUeqshkiyKWRHLTMNJSPojuraC,'title':fdGczUeqshkiyKWRHLTMNJSPojurap,'story':fdGczUeqshkiyKWRHLTMNJSPojurab,'thumbnail':fdGczUeqshkiyKWRHLTMNJSPojurax,'year':fdGczUeqshkiyKWRHLTMNJSPojurag,'film_rating_code':fdGczUeqshkiyKWRHLTMNJSPojuraY,'film_rating_short':fdGczUeqshkiyKWRHLTMNJSPojuraw,'film_rating_long':fdGczUeqshkiyKWRHLTMNJSPojuraQ,'duration':fdGczUeqshkiyKWRHLTMNJSPojural}
    fdGczUeqshkiyKWRHLTMNJSPojurVC.append(fdGczUeqshkiyKWRHLTMNJSPojuraX)
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   fdGczUeqshkiyKWRHLTMNJSPojurBv(exception)
  return fdGczUeqshkiyKWRHLTMNJSPojurVC,fdGczUeqshkiyKWRHLTMNJSPojuraA
 def GetProfilesList(fdGczUeqshkiyKWRHLTMNJSPojurnV):
  fdGczUeqshkiyKWRHLTMNJSPojurnw=[]
  try:
   fdGczUeqshkiyKWRHLTMNJSPojurnO ='/manage_profiles'
   fdGczUeqshkiyKWRHLTMNJSPojurnD=fdGczUeqshkiyKWRHLTMNJSPojurnV.MAIN_DOMAIN+fdGczUeqshkiyKWRHLTMNJSPojurnO
   fdGczUeqshkiyKWRHLTMNJSPojurng=fdGczUeqshkiyKWRHLTMNJSPojurnV.makeDefaultCookies()
   fdGczUeqshkiyKWRHLTMNJSPojurnx=fdGczUeqshkiyKWRHLTMNJSPojurnV.callRequestCookies('Get',fdGczUeqshkiyKWRHLTMNJSPojurnD,payload=fdGczUeqshkiyKWRHLTMNJSPojurBm,params=fdGczUeqshkiyKWRHLTMNJSPojurBm,headers=fdGczUeqshkiyKWRHLTMNJSPojurBm,cookies=fdGczUeqshkiyKWRHLTMNJSPojurng,redirects=fdGczUeqshkiyKWRHLTMNJSPojurBA)
   fdGczUeqshkiyKWRHLTMNJSPojurVp=fdGczUeqshkiyKWRHLTMNJSPojurnx.text
   fdGczUeqshkiyKWRHLTMNJSPojurVb =re.findall('/api/users/me.{5000}',fdGczUeqshkiyKWRHLTMNJSPojurVp)[0]
   fdGczUeqshkiyKWRHLTMNJSPojurVb =fdGczUeqshkiyKWRHLTMNJSPojurVb.replace('&quot;','')
   fdGczUeqshkiyKWRHLTMNJSPojurnw=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',fdGczUeqshkiyKWRHLTMNJSPojurVb)
   for i in fdGczUeqshkiyKWRHLTMNJSPojurBI(fdGczUeqshkiyKWRHLTMNJSPojurBp(fdGczUeqshkiyKWRHLTMNJSPojurnw)):
    fdGczUeqshkiyKWRHLTMNJSPojurVI=fdGczUeqshkiyKWRHLTMNJSPojurnw[i]
    fdGczUeqshkiyKWRHLTMNJSPojurVI =fdGczUeqshkiyKWRHLTMNJSPojurVI.split(':')[1]
    fdGczUeqshkiyKWRHLTMNJSPojurnw[i]=fdGczUeqshkiyKWRHLTMNJSPojurVI.split(',')[0]
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   fdGczUeqshkiyKWRHLTMNJSPojurBv(exception)
  return fdGczUeqshkiyKWRHLTMNJSPojurnw
 def GetProfilesConvert(fdGczUeqshkiyKWRHLTMNJSPojurnV,fdGczUeqshkiyKWRHLTMNJSPojurnm):
  fdGczUeqshkiyKWRHLTMNJSPojurVx=''
  fdGczUeqshkiyKWRHLTMNJSPojurVg=''
  try:
   fdGczUeqshkiyKWRHLTMNJSPojurnO ='/api/users/'+fdGczUeqshkiyKWRHLTMNJSPojurnm+'/convert'
   fdGczUeqshkiyKWRHLTMNJSPojurnD=fdGczUeqshkiyKWRHLTMNJSPojurnV.API_DOMAIN+fdGczUeqshkiyKWRHLTMNJSPojurnO
   fdGczUeqshkiyKWRHLTMNJSPojurng=fdGczUeqshkiyKWRHLTMNJSPojurnV.makeDefaultCookies()
   fdGczUeqshkiyKWRHLTMNJSPojurnx=fdGczUeqshkiyKWRHLTMNJSPojurnV.callRequestCookies('Put',fdGczUeqshkiyKWRHLTMNJSPojurnD,payload=fdGczUeqshkiyKWRHLTMNJSPojurBm,params=fdGczUeqshkiyKWRHLTMNJSPojurBm,headers=fdGczUeqshkiyKWRHLTMNJSPojurBm,cookies=fdGczUeqshkiyKWRHLTMNJSPojurng)
   for fdGczUeqshkiyKWRHLTMNJSPojurng in fdGczUeqshkiyKWRHLTMNJSPojurnx.cookies:
    if fdGczUeqshkiyKWRHLTMNJSPojurng.name=='_s_guitv':
     fdGczUeqshkiyKWRHLTMNJSPojurVY=fdGczUeqshkiyKWRHLTMNJSPojurng.value
    elif fdGczUeqshkiyKWRHLTMNJSPojurng.name=='_guinness-premium_session':
     fdGczUeqshkiyKWRHLTMNJSPojurnY=fdGczUeqshkiyKWRHLTMNJSPojurng.value
   if fdGczUeqshkiyKWRHLTMNJSPojurVY:
    fdGczUeqshkiyKWRHLTMNJSPojurVx=fdGczUeqshkiyKWRHLTMNJSPojurVY
   if fdGczUeqshkiyKWRHLTMNJSPojurnY:
    fdGczUeqshkiyKWRHLTMNJSPojurVg=fdGczUeqshkiyKWRHLTMNJSPojurnY
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   fdGczUeqshkiyKWRHLTMNJSPojurVx=''
   fdGczUeqshkiyKWRHLTMNJSPojurVg=''
  return fdGczUeqshkiyKWRHLTMNJSPojurVx,fdGczUeqshkiyKWRHLTMNJSPojurVg
 def Get_Now_Datetime(fdGczUeqshkiyKWRHLTMNJSPojurnV):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(fdGczUeqshkiyKWRHLTMNJSPojurnV,movie_code,quality_str):
  fdGczUeqshkiyKWRHLTMNJSPojurVQ=fdGczUeqshkiyKWRHLTMNJSPojurVO=fdGczUeqshkiyKWRHLTMNJSPojurBt=''
  try:
   fdGczUeqshkiyKWRHLTMNJSPojurnO='/api/watch/'+movie_code+'.json'
   fdGczUeqshkiyKWRHLTMNJSPojurnD=fdGczUeqshkiyKWRHLTMNJSPojurnV.API_DOMAIN+fdGczUeqshkiyKWRHLTMNJSPojurnO
   fdGczUeqshkiyKWRHLTMNJSPojurnI={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   fdGczUeqshkiyKWRHLTMNJSPojurng=fdGczUeqshkiyKWRHLTMNJSPojurnV.makeDefaultCookies()
   fdGczUeqshkiyKWRHLTMNJSPojurnx=fdGczUeqshkiyKWRHLTMNJSPojurnV.callRequestCookies('Get',fdGczUeqshkiyKWRHLTMNJSPojurnD,payload=fdGczUeqshkiyKWRHLTMNJSPojurBm,params=fdGczUeqshkiyKWRHLTMNJSPojurBm,headers=fdGczUeqshkiyKWRHLTMNJSPojurnI,cookies=fdGczUeqshkiyKWRHLTMNJSPojurng)
   fdGczUeqshkiyKWRHLTMNJSPojuran=json.loads(fdGczUeqshkiyKWRHLTMNJSPojurnx.text)
   fdGczUeqshkiyKWRHLTMNJSPojurVQ=fdGczUeqshkiyKWRHLTMNJSPojuran['streams'][0]['source']
   if fdGczUeqshkiyKWRHLTMNJSPojurVQ==fdGczUeqshkiyKWRHLTMNJSPojurBm:return(fdGczUeqshkiyKWRHLTMNJSPojurVQ,fdGczUeqshkiyKWRHLTMNJSPojurVO,fdGczUeqshkiyKWRHLTMNJSPojurBt)
   if 'subtitles' in fdGczUeqshkiyKWRHLTMNJSPojuran['streams'][0]:
    for fdGczUeqshkiyKWRHLTMNJSPojurVl in fdGczUeqshkiyKWRHLTMNJSPojuran['streams'][0]['subtitles']:
     if fdGczUeqshkiyKWRHLTMNJSPojurVl['lang']=='ko':
      fdGczUeqshkiyKWRHLTMNJSPojurVO=fdGczUeqshkiyKWRHLTMNJSPojurVl['url']
      break
   fdGczUeqshkiyKWRHLTMNJSPojurVD =fdGczUeqshkiyKWRHLTMNJSPojuran['ping_payload']
   fdGczUeqshkiyKWRHLTMNJSPojurBn =fdGczUeqshkiyKWRHLTMNJSPojurnV.WATCHA_USERCD
   fdGczUeqshkiyKWRHLTMNJSPojurBa={'merchant':'giitd_frograms','sessionId':fdGczUeqshkiyKWRHLTMNJSPojurVD,'userId':fdGczUeqshkiyKWRHLTMNJSPojurBn}
   fdGczUeqshkiyKWRHLTMNJSPojurBV=json.dumps(fdGczUeqshkiyKWRHLTMNJSPojurBa,separators=(",",":")).encode('UTF-8')
   fdGczUeqshkiyKWRHLTMNJSPojurBt=base64.b64encode(fdGczUeqshkiyKWRHLTMNJSPojurBV)
  except fdGczUeqshkiyKWRHLTMNJSPojurBE as exception:
   return(fdGczUeqshkiyKWRHLTMNJSPojurVQ,fdGczUeqshkiyKWRHLTMNJSPojurVO,fdGczUeqshkiyKWRHLTMNJSPojurBt)
  return(fdGczUeqshkiyKWRHLTMNJSPojurVQ,fdGczUeqshkiyKWRHLTMNJSPojurVO,fdGczUeqshkiyKWRHLTMNJSPojurBt) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
