__author__="NightRain"
YKnucEvgPjyxbAWzqNCXJOfdrhSVRe=object
YKnucEvgPjyxbAWzqNCXJOfdrhSVRL=None
YKnucEvgPjyxbAWzqNCXJOfdrhSVRi=int
YKnucEvgPjyxbAWzqNCXJOfdrhSVRI=True
YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ=False
YKnucEvgPjyxbAWzqNCXJOfdrhSVRl=type
YKnucEvgPjyxbAWzqNCXJOfdrhSVRp=dict
YKnucEvgPjyxbAWzqNCXJOfdrhSVRw=len
YKnucEvgPjyxbAWzqNCXJOfdrhSVRD=range
YKnucEvgPjyxbAWzqNCXJOfdrhSVRT=str
YKnucEvgPjyxbAWzqNCXJOfdrhSVRB=open
YKnucEvgPjyxbAWzqNCXJOfdrhSVRF=Exception
YKnucEvgPjyxbAWzqNCXJOfdrhSVRk=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
YKnucEvgPjyxbAWzqNCXJOfdrhSVGm=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-','icon':'history.png'},{'title':'검색 (왓챠)','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'통합검색 이력','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'}]
YKnucEvgPjyxbAWzqNCXJOfdrhSVGs=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
YKnucEvgPjyxbAWzqNCXJOfdrhSVGa=40
YKnucEvgPjyxbAWzqNCXJOfdrhSVGR =20
YKnucEvgPjyxbAWzqNCXJOfdrhSVGM =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
YKnucEvgPjyxbAWzqNCXJOfdrhSVGe=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class YKnucEvgPjyxbAWzqNCXJOfdrhSVGo(YKnucEvgPjyxbAWzqNCXJOfdrhSVRe):
 def __init__(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,YKnucEvgPjyxbAWzqNCXJOfdrhSVGi,YKnucEvgPjyxbAWzqNCXJOfdrhSVGI,YKnucEvgPjyxbAWzqNCXJOfdrhSVGQ):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_url =YKnucEvgPjyxbAWzqNCXJOfdrhSVGi
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle=YKnucEvgPjyxbAWzqNCXJOfdrhSVGI
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.main_params =YKnucEvgPjyxbAWzqNCXJOfdrhSVGQ
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj =fdGczUeqshkiyKWRHLTMNJSPojurna() 
 def addon_noti(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,sting):
  try:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGp=xbmcgui.Dialog()
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGp.notification(__addonname__,sting)
  except:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVRL
 def addon_log(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,string):
  try:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGw=string.encode('utf-8','ignore')
  except:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGw='addonException: addon_log'
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGD=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,YKnucEvgPjyxbAWzqNCXJOfdrhSVGw),level=YKnucEvgPjyxbAWzqNCXJOfdrhSVGD)
 def get_keyboard_input(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,YKnucEvgPjyxbAWzqNCXJOfdrhSVoL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGT=YKnucEvgPjyxbAWzqNCXJOfdrhSVRL
  kb=xbmc.Keyboard()
  kb.setHeading(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGT=kb.getText()
  return YKnucEvgPjyxbAWzqNCXJOfdrhSVGT
 def get_settings_login_info(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGB =__addon__.getSetting('id')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGF =__addon__.getSetting('pw')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGk=YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(__addon__.getSetting('selected_profile'))
  return(YKnucEvgPjyxbAWzqNCXJOfdrhSVGB,YKnucEvgPjyxbAWzqNCXJOfdrhSVGF,YKnucEvgPjyxbAWzqNCXJOfdrhSVGk)
 def get_settings_totalsearch(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGH =YKnucEvgPjyxbAWzqNCXJOfdrhSVRI if __addon__.getSetting('local_search')=='true' else YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGU =YKnucEvgPjyxbAWzqNCXJOfdrhSVRI if __addon__.getSetting('total_search')=='true' else YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGt=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI if __addon__.getSetting('total_history')=='true' else YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
  return(YKnucEvgPjyxbAWzqNCXJOfdrhSVGH,YKnucEvgPjyxbAWzqNCXJOfdrhSVGU,YKnucEvgPjyxbAWzqNCXJOfdrhSVGt)
 def get_selQuality(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  try:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoG=['3840x2160/1','1920x1080/1','1280x720/1']
   YKnucEvgPjyxbAWzqNCXJOfdrhSVom=YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(__addon__.getSetting('selected_quality'))
   return YKnucEvgPjyxbAWzqNCXJOfdrhSVoG[YKnucEvgPjyxbAWzqNCXJOfdrhSVom]
  except:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVRL
  return 1080 
 def get_settings_direct_replay(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVos=YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(__addon__.getSetting('direct_replay'))
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVos==0:
   return YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
  else:
   return YKnucEvgPjyxbAWzqNCXJOfdrhSVRI
 def set_winCredential(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,credential):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa=xbmcgui.Window(10000)
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_LOGINTIME',YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa=xbmcgui.Window(10000)
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoR={'watcha_token':YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.getProperty('WATCHA_M_TOKEN'),'watcha_guit':YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.getProperty('WATCHA_M_GUIT'),'watcha_guitv':YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.getProperty('WATCHA_M_GUITV'),'watcha_usercd':YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.getProperty('WATCHA_M_USERCD')}
  return YKnucEvgPjyxbAWzqNCXJOfdrhSVoR
 def set_winEpisodeOrderby(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,YKnucEvgPjyxbAWzqNCXJOfdrhSVoM):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa=xbmcgui.Window(10000)
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_ORDERBY',YKnucEvgPjyxbAWzqNCXJOfdrhSVoM)
 def get_winEpisodeOrderby(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa=xbmcgui.Window(10000)
  return YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,args):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoM =args.get('orderby')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.set_winEpisodeOrderby(YKnucEvgPjyxbAWzqNCXJOfdrhSVoM)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,label,sublabel='',img='',infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVRL,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI,params='',isLink=YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ,ContextMenu=YKnucEvgPjyxbAWzqNCXJOfdrhSVRL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoe='%s?%s'%(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_url,urllib.parse.urlencode(params))
  if sublabel:YKnucEvgPjyxbAWzqNCXJOfdrhSVoL='%s < %s >'%(label,sublabel)
  else: YKnucEvgPjyxbAWzqNCXJOfdrhSVoL=label
  if not img:img='DefaultFolder.png'
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoi=xbmcgui.ListItem(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVRl(img)==YKnucEvgPjyxbAWzqNCXJOfdrhSVRp:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoi.setArt(img)
  else:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoi.setArt({'thumb':img,'poster':img})
  if infoLabels:YKnucEvgPjyxbAWzqNCXJOfdrhSVoi.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoi.setProperty('IsPlayable','true')
  if ContextMenu:YKnucEvgPjyxbAWzqNCXJOfdrhSVoi.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle,YKnucEvgPjyxbAWzqNCXJOfdrhSVoe,YKnucEvgPjyxbAWzqNCXJOfdrhSVoi,isFolder)
 def dp_Main_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  (YKnucEvgPjyxbAWzqNCXJOfdrhSVGH,YKnucEvgPjyxbAWzqNCXJOfdrhSVGU,YKnucEvgPjyxbAWzqNCXJOfdrhSVGt)=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_settings_totalsearch()
  for YKnucEvgPjyxbAWzqNCXJOfdrhSVoI in YKnucEvgPjyxbAWzqNCXJOfdrhSVGm:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL=YKnucEvgPjyxbAWzqNCXJOfdrhSVoI.get('title')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ=''
   if YKnucEvgPjyxbAWzqNCXJOfdrhSVoI.get('mode')=='LOCAL_SEARCH' and YKnucEvgPjyxbAWzqNCXJOfdrhSVGH ==YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ:continue
   elif YKnucEvgPjyxbAWzqNCXJOfdrhSVoI.get('mode')=='TOTAL_SEARCH' and YKnucEvgPjyxbAWzqNCXJOfdrhSVGU ==YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ:continue
   elif YKnucEvgPjyxbAWzqNCXJOfdrhSVoI.get('mode')=='TOTAL_HISTORY' and YKnucEvgPjyxbAWzqNCXJOfdrhSVGt==YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ:continue
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol={'mode':YKnucEvgPjyxbAWzqNCXJOfdrhSVoI.get('mode'),'stype':YKnucEvgPjyxbAWzqNCXJOfdrhSVoI.get('stype'),'api_path':YKnucEvgPjyxbAWzqNCXJOfdrhSVoI.get('api_path'),'page':'1','sort':YKnucEvgPjyxbAWzqNCXJOfdrhSVoI.get('sort'),'tag_id':'-'}
   if YKnucEvgPjyxbAWzqNCXJOfdrhSVoI.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY']:
    YKnucEvgPjyxbAWzqNCXJOfdrhSVop=YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
    YKnucEvgPjyxbAWzqNCXJOfdrhSVow =YKnucEvgPjyxbAWzqNCXJOfdrhSVRI
   else:
    YKnucEvgPjyxbAWzqNCXJOfdrhSVop=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI
    YKnucEvgPjyxbAWzqNCXJOfdrhSVow =YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
   if 'icon' in YKnucEvgPjyxbAWzqNCXJOfdrhSVoI:YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',YKnucEvgPjyxbAWzqNCXJOfdrhSVoI.get('icon')) 
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel='',img=YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ,infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVRL,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVop,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol,isLink=YKnucEvgPjyxbAWzqNCXJOfdrhSVow)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVRw(YKnucEvgPjyxbAWzqNCXJOfdrhSVGm)>0:xbmcplugin.endOfDirectory(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle)
 def login_main(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  (YKnucEvgPjyxbAWzqNCXJOfdrhSVoT,YKnucEvgPjyxbAWzqNCXJOfdrhSVoB,YKnucEvgPjyxbAWzqNCXJOfdrhSVoF)=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_settings_login_info()
  if not(YKnucEvgPjyxbAWzqNCXJOfdrhSVoT and YKnucEvgPjyxbAWzqNCXJOfdrhSVoB):
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGp=xbmcgui.Dialog()
   YKnucEvgPjyxbAWzqNCXJOfdrhSVok=YKnucEvgPjyxbAWzqNCXJOfdrhSVGp.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if YKnucEvgPjyxbAWzqNCXJOfdrhSVok==YKnucEvgPjyxbAWzqNCXJOfdrhSVRI:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_winEpisodeOrderby()=='':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.set_winEpisodeOrderby('asc')
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.cookiefile_check():return
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoH =YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoU=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVoU==YKnucEvgPjyxbAWzqNCXJOfdrhSVRL or YKnucEvgPjyxbAWzqNCXJOfdrhSVoU=='':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoU=YKnucEvgPjyxbAWzqNCXJOfdrhSVRi('19000101')
  else:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoU=YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(re.sub('-','',YKnucEvgPjyxbAWzqNCXJOfdrhSVoU))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVot=0
   while YKnucEvgPjyxbAWzqNCXJOfdrhSVRI:
    YKnucEvgPjyxbAWzqNCXJOfdrhSVot+=1
    time.sleep(0.05)
    if YKnucEvgPjyxbAWzqNCXJOfdrhSVoU>=YKnucEvgPjyxbAWzqNCXJOfdrhSVoH:return
    if YKnucEvgPjyxbAWzqNCXJOfdrhSVot>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVoU>=YKnucEvgPjyxbAWzqNCXJOfdrhSVoH:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.GetCredential(YKnucEvgPjyxbAWzqNCXJOfdrhSVoT,YKnucEvgPjyxbAWzqNCXJOfdrhSVoB,YKnucEvgPjyxbAWzqNCXJOfdrhSVoF):
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.set_winCredential(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.LoadCredential())
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,args):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.SaveCredential(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_winCredential())
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmG =args.get('stype')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmo =YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(args.get('page'))
  YKnucEvgPjyxbAWzqNCXJOfdrhSVms =args.get('sort')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVma=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.GetSubGroupList(YKnucEvgPjyxbAWzqNCXJOfdrhSVmG)
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmR=YKnucEvgPjyxbAWzqNCXJOfdrhSVGa if YKnucEvgPjyxbAWzqNCXJOfdrhSVmG=='genres' else YKnucEvgPjyxbAWzqNCXJOfdrhSVGR
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmM=YKnucEvgPjyxbAWzqNCXJOfdrhSVRw(YKnucEvgPjyxbAWzqNCXJOfdrhSVma)
  YKnucEvgPjyxbAWzqNCXJOfdrhSVme =YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(YKnucEvgPjyxbAWzqNCXJOfdrhSVmM//(YKnucEvgPjyxbAWzqNCXJOfdrhSVmR+1))+1
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmL =(YKnucEvgPjyxbAWzqNCXJOfdrhSVmo-1)*YKnucEvgPjyxbAWzqNCXJOfdrhSVmR
  for i in YKnucEvgPjyxbAWzqNCXJOfdrhSVRD(YKnucEvgPjyxbAWzqNCXJOfdrhSVmR):
   YKnucEvgPjyxbAWzqNCXJOfdrhSVmi=YKnucEvgPjyxbAWzqNCXJOfdrhSVmL+i
   if YKnucEvgPjyxbAWzqNCXJOfdrhSVmi>=YKnucEvgPjyxbAWzqNCXJOfdrhSVmM:break
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL =YKnucEvgPjyxbAWzqNCXJOfdrhSVma[YKnucEvgPjyxbAWzqNCXJOfdrhSVmi].get('group_name')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVmI =YKnucEvgPjyxbAWzqNCXJOfdrhSVma[YKnucEvgPjyxbAWzqNCXJOfdrhSVmi].get('api_path')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVmQ =YKnucEvgPjyxbAWzqNCXJOfdrhSVma[YKnucEvgPjyxbAWzqNCXJOfdrhSVmi].get('tag_id')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol={'mode':'CATEGORY_LIST','api_path':YKnucEvgPjyxbAWzqNCXJOfdrhSVmI,'tag_id':YKnucEvgPjyxbAWzqNCXJOfdrhSVmQ,'stype':YKnucEvgPjyxbAWzqNCXJOfdrhSVmG,'page':'1','sort':YKnucEvgPjyxbAWzqNCXJOfdrhSVms}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel='',img='',infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVRL,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVme>YKnucEvgPjyxbAWzqNCXJOfdrhSVmo:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol={}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['mode'] ='SUB_GROUP' 
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['stype'] =YKnucEvgPjyxbAWzqNCXJOfdrhSVmG
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['api_path']=args.get('api_path')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['page'] =YKnucEvgPjyxbAWzqNCXJOfdrhSVRT(YKnucEvgPjyxbAWzqNCXJOfdrhSVmo+1)
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['sort'] =YKnucEvgPjyxbAWzqNCXJOfdrhSVms
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL='[B]%s >>[/B]'%'다음 페이지'
   YKnucEvgPjyxbAWzqNCXJOfdrhSVml=YKnucEvgPjyxbAWzqNCXJOfdrhSVRT(YKnucEvgPjyxbAWzqNCXJOfdrhSVmo+1)
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel=YKnucEvgPjyxbAWzqNCXJOfdrhSVml,img=YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ,infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVRL,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVRw(YKnucEvgPjyxbAWzqNCXJOfdrhSVma)>0:xbmcplugin.endOfDirectory(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle,cacheToDisc=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI)
 def play_VIDEO(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,args):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.SaveCredential(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_winCredential())
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmp =args.get('movie_code')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmw =args.get('season_code')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoL =args.get('title')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmD =args.get('thumbnail')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmT =YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_selQuality()
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.addon_log(YKnucEvgPjyxbAWzqNCXJOfdrhSVmp+' - '+YKnucEvgPjyxbAWzqNCXJOfdrhSVmw)
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmB,YKnucEvgPjyxbAWzqNCXJOfdrhSVmF,YKnucEvgPjyxbAWzqNCXJOfdrhSVmk=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.GetStreamingURL(YKnucEvgPjyxbAWzqNCXJOfdrhSVmp,YKnucEvgPjyxbAWzqNCXJOfdrhSVmT)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVmB=='':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.addon_noti(__language__(30908).encode('utf8'))
   return
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmH=YKnucEvgPjyxbAWzqNCXJOfdrhSVmB
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.addon_log(YKnucEvgPjyxbAWzqNCXJOfdrhSVmH)
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmU=xbmcgui.ListItem(path=YKnucEvgPjyxbAWzqNCXJOfdrhSVmH)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVmk:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVmt=YKnucEvgPjyxbAWzqNCXJOfdrhSVmk
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsG ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   YKnucEvgPjyxbAWzqNCXJOfdrhSVso ='mpd'
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsm ='com.widevine.alpha'
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsa =inputstreamhelper.Helper(YKnucEvgPjyxbAWzqNCXJOfdrhSVso,drm=YKnucEvgPjyxbAWzqNCXJOfdrhSVsm)
   if YKnucEvgPjyxbAWzqNCXJOfdrhSVsa.check_inputstream():
    YKnucEvgPjyxbAWzqNCXJOfdrhSVsR={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+YKnucEvgPjyxbAWzqNCXJOfdrhSVmp,'dt-custom-data':YKnucEvgPjyxbAWzqNCXJOfdrhSVmt,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    YKnucEvgPjyxbAWzqNCXJOfdrhSVsM=YKnucEvgPjyxbAWzqNCXJOfdrhSVsG+'|'+urllib.parse.urlencode(YKnucEvgPjyxbAWzqNCXJOfdrhSVsR)+'|R{SSM}|'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.addon_log(YKnucEvgPjyxbAWzqNCXJOfdrhSVsM)
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmU.setProperty('inputstream',YKnucEvgPjyxbAWzqNCXJOfdrhSVsa.inputstream_addon)
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmU.setProperty('inputstream.adaptive.manifest_type',YKnucEvgPjyxbAWzqNCXJOfdrhSVso)
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmU.setProperty('inputstream.adaptive.license_type',YKnucEvgPjyxbAWzqNCXJOfdrhSVsm)
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmU.setProperty('inputstream.adaptive.license_key',YKnucEvgPjyxbAWzqNCXJOfdrhSVsM)
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmU.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.USER_AGENT))
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVmF:
   try:
    f=YKnucEvgPjyxbAWzqNCXJOfdrhSVRB(YKnucEvgPjyxbAWzqNCXJOfdrhSVGM,'w',-1,'utf-8')
    YKnucEvgPjyxbAWzqNCXJOfdrhSVse=requests.get(YKnucEvgPjyxbAWzqNCXJOfdrhSVmF)
    YKnucEvgPjyxbAWzqNCXJOfdrhSVsL=YKnucEvgPjyxbAWzqNCXJOfdrhSVse.content.decode('utf-8') 
    for YKnucEvgPjyxbAWzqNCXJOfdrhSVsi in YKnucEvgPjyxbAWzqNCXJOfdrhSVsL.splitlines():
     YKnucEvgPjyxbAWzqNCXJOfdrhSVsI=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',YKnucEvgPjyxbAWzqNCXJOfdrhSVsi)
     f.write(YKnucEvgPjyxbAWzqNCXJOfdrhSVsI+'\n')
    f.close()
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmU.setSubtitles([YKnucEvgPjyxbAWzqNCXJOfdrhSVGM,YKnucEvgPjyxbAWzqNCXJOfdrhSVmF])
   except:
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmU.setSubtitles([YKnucEvgPjyxbAWzqNCXJOfdrhSVmF])
  xbmcplugin.setResolvedUrl(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle,YKnucEvgPjyxbAWzqNCXJOfdrhSVRI,YKnucEvgPjyxbAWzqNCXJOfdrhSVmU)
  try:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVmG='movie' if YKnucEvgPjyxbAWzqNCXJOfdrhSVmw=='-' else 'seasons'
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol={'code':YKnucEvgPjyxbAWzqNCXJOfdrhSVmp if YKnucEvgPjyxbAWzqNCXJOfdrhSVmG=='movie' else YKnucEvgPjyxbAWzqNCXJOfdrhSVmw,'img':YKnucEvgPjyxbAWzqNCXJOfdrhSVmD,'title':YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,'videoid':YKnucEvgPjyxbAWzqNCXJOfdrhSVmp}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.Save_Watched_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVmG,YKnucEvgPjyxbAWzqNCXJOfdrhSVol)
  except:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVRL
 def dp_Category_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,args):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.SaveCredential(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_winCredential())
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmG =args.get('stype')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmQ =args.get('tag_id')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmI=args.get('api_path')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmo=YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(args.get('page'))
  YKnucEvgPjyxbAWzqNCXJOfdrhSVms =args.get('sort')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVsQ,YKnucEvgPjyxbAWzqNCXJOfdrhSVsl=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.GetCategoryList(YKnucEvgPjyxbAWzqNCXJOfdrhSVmG,YKnucEvgPjyxbAWzqNCXJOfdrhSVmQ,YKnucEvgPjyxbAWzqNCXJOfdrhSVmI,YKnucEvgPjyxbAWzqNCXJOfdrhSVmo,YKnucEvgPjyxbAWzqNCXJOfdrhSVms)
  for YKnucEvgPjyxbAWzqNCXJOfdrhSVsp in YKnucEvgPjyxbAWzqNCXJOfdrhSVsQ:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVmp =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('code')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('title')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsw =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('content_type')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsD =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('story')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVmD =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('thumbnail')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsT =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('year')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsB =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('film_rating_code')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsF=YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('film_rating_short')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsk =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('film_rating_long')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsH =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('duration')
   if YKnucEvgPjyxbAWzqNCXJOfdrhSVsw=='movies': 
    YKnucEvgPjyxbAWzqNCXJOfdrhSVop =YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
    YKnucEvgPjyxbAWzqNCXJOfdrhSVsU ='MOVIE'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVoD =''
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmw='-'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVst ='movie'
   else: 
    YKnucEvgPjyxbAWzqNCXJOfdrhSVop =YKnucEvgPjyxbAWzqNCXJOfdrhSVRI
    YKnucEvgPjyxbAWzqNCXJOfdrhSVsU ='EPISODE'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVoD ='Series'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmw=YKnucEvgPjyxbAWzqNCXJOfdrhSVmp
    YKnucEvgPjyxbAWzqNCXJOfdrhSVst ='tvshow' 
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaG={'mediatype':YKnucEvgPjyxbAWzqNCXJOfdrhSVst,'mpaa':YKnucEvgPjyxbAWzqNCXJOfdrhSVsk,'title':YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,'year':YKnucEvgPjyxbAWzqNCXJOfdrhSVsT,'duration':YKnucEvgPjyxbAWzqNCXJOfdrhSVsH,'plot':YKnucEvgPjyxbAWzqNCXJOfdrhSVsD}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL+='  (%s년 - %s)'%(YKnucEvgPjyxbAWzqNCXJOfdrhSVsT,YKnucEvgPjyxbAWzqNCXJOfdrhSVRT(YKnucEvgPjyxbAWzqNCXJOfdrhSVsF))
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol={'mode':YKnucEvgPjyxbAWzqNCXJOfdrhSVsU,'movie_code':YKnucEvgPjyxbAWzqNCXJOfdrhSVmp,'page':'1','season_code':YKnucEvgPjyxbAWzqNCXJOfdrhSVmw,'title':YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,'thumbnail':YKnucEvgPjyxbAWzqNCXJOfdrhSVmD}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel=YKnucEvgPjyxbAWzqNCXJOfdrhSVoD,img=YKnucEvgPjyxbAWzqNCXJOfdrhSVmD,infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVaG,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVop,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVsl:
   if YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.GetCategoryList_morepage(YKnucEvgPjyxbAWzqNCXJOfdrhSVmG,YKnucEvgPjyxbAWzqNCXJOfdrhSVmQ,YKnucEvgPjyxbAWzqNCXJOfdrhSVmI,YKnucEvgPjyxbAWzqNCXJOfdrhSVmo+1,YKnucEvgPjyxbAWzqNCXJOfdrhSVms):
    YKnucEvgPjyxbAWzqNCXJOfdrhSVol={}
    YKnucEvgPjyxbAWzqNCXJOfdrhSVol['mode'] ='CATEGORY_LIST'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVol['stype'] =YKnucEvgPjyxbAWzqNCXJOfdrhSVmG
    YKnucEvgPjyxbAWzqNCXJOfdrhSVol['tag_id'] =YKnucEvgPjyxbAWzqNCXJOfdrhSVmQ
    YKnucEvgPjyxbAWzqNCXJOfdrhSVol['api_path']=YKnucEvgPjyxbAWzqNCXJOfdrhSVmI
    YKnucEvgPjyxbAWzqNCXJOfdrhSVol['page'] =YKnucEvgPjyxbAWzqNCXJOfdrhSVRT(YKnucEvgPjyxbAWzqNCXJOfdrhSVmo+1)
    YKnucEvgPjyxbAWzqNCXJOfdrhSVol['sort'] =YKnucEvgPjyxbAWzqNCXJOfdrhSVms
    YKnucEvgPjyxbAWzqNCXJOfdrhSVoL='[B]%s >>[/B]'%'다음 페이지'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVml=YKnucEvgPjyxbAWzqNCXJOfdrhSVRT(YKnucEvgPjyxbAWzqNCXJOfdrhSVmo+1)
    YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
    YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel=YKnucEvgPjyxbAWzqNCXJOfdrhSVml,img=YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ,infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVRL,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVRw(YKnucEvgPjyxbAWzqNCXJOfdrhSVsQ)>0:
   if YKnucEvgPjyxbAWzqNCXJOfdrhSVmI=='arrivals/latest':
    xbmcplugin.endOfDirectory(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle,cacheToDisc=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI)
   else:
    xbmcplugin.endOfDirectory(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle,cacheToDisc=YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ)
 def dp_Episode_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,args):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.SaveCredential(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_winCredential())
  YKnucEvgPjyxbAWzqNCXJOfdrhSVam=args.get('movie_code')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmo =YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(args.get('page'))
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmw =args.get('season_code')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVsQ,YKnucEvgPjyxbAWzqNCXJOfdrhSVsl=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.GetEpisodoList(YKnucEvgPjyxbAWzqNCXJOfdrhSVam,YKnucEvgPjyxbAWzqNCXJOfdrhSVmo,orderby=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_winEpisodeOrderby())
  for YKnucEvgPjyxbAWzqNCXJOfdrhSVsp in YKnucEvgPjyxbAWzqNCXJOfdrhSVsQ:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVmp =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('code')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('title')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVmD =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('thumbnail')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVas =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('display_num')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaR =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('season_title')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaM=YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('episode_number')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsH =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('duration')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaG={'mediatype':'episode','tvshowtitle':YKnucEvgPjyxbAWzqNCXJOfdrhSVoL if YKnucEvgPjyxbAWzqNCXJOfdrhSVoL!='' else YKnucEvgPjyxbAWzqNCXJOfdrhSVaR,'title':'%s %s'%(YKnucEvgPjyxbAWzqNCXJOfdrhSVaR,YKnucEvgPjyxbAWzqNCXJOfdrhSVas)if YKnucEvgPjyxbAWzqNCXJOfdrhSVoL!='' else YKnucEvgPjyxbAWzqNCXJOfdrhSVas,'episode':YKnucEvgPjyxbAWzqNCXJOfdrhSVaM,'duration':YKnucEvgPjyxbAWzqNCXJOfdrhSVsH,'plot':'%s\n%s\n\n%s'%(YKnucEvgPjyxbAWzqNCXJOfdrhSVaR,YKnucEvgPjyxbAWzqNCXJOfdrhSVas,YKnucEvgPjyxbAWzqNCXJOfdrhSVoL)}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL='(%s) %s'%(YKnucEvgPjyxbAWzqNCXJOfdrhSVas,YKnucEvgPjyxbAWzqNCXJOfdrhSVoL)
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol={'mode':'MOVIE','movie_code':YKnucEvgPjyxbAWzqNCXJOfdrhSVmp,'season_code':YKnucEvgPjyxbAWzqNCXJOfdrhSVmw,'title':'%s < %s >'%(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,YKnucEvgPjyxbAWzqNCXJOfdrhSVaR),'thumbnail':YKnucEvgPjyxbAWzqNCXJOfdrhSVmD}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel=YKnucEvgPjyxbAWzqNCXJOfdrhSVaR,img=YKnucEvgPjyxbAWzqNCXJOfdrhSVmD,infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVaG,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVmo==1:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaG={'plot':'정렬순서를 변경합니다.'}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol={}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['mode'] ='ORDER_BY' 
   if YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_winEpisodeOrderby()=='desc':
    YKnucEvgPjyxbAWzqNCXJOfdrhSVoL='정렬순서변경 : 최신화부터 -> 1회부터'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVol['orderby']='asc'
   else:
    YKnucEvgPjyxbAWzqNCXJOfdrhSVoL='정렬순서변경 : 1회부터 -> 최신화부터'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVol['orderby']='desc'
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel='',img=YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ,infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVaG,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol,isLink=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVsl:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['mode'] ='EPISODE' 
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['movie_code']=YKnucEvgPjyxbAWzqNCXJOfdrhSVam
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['page'] =YKnucEvgPjyxbAWzqNCXJOfdrhSVRT(YKnucEvgPjyxbAWzqNCXJOfdrhSVmo+1)
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL='[B]%s >>[/B]'%'다음 페이지'
   YKnucEvgPjyxbAWzqNCXJOfdrhSVml=YKnucEvgPjyxbAWzqNCXJOfdrhSVRT(YKnucEvgPjyxbAWzqNCXJOfdrhSVmo+1)
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel=YKnucEvgPjyxbAWzqNCXJOfdrhSVml,img=YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ,infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVRL,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVRw(YKnucEvgPjyxbAWzqNCXJOfdrhSVsQ)>0:xbmcplugin.endOfDirectory(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle,cacheToDisc=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI)
 def dp_Search_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,args):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.SaveCredential(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_winCredential())
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmo =YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(args.get('page'))
  if 'search_key' in args:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVae=args.get('search_key')
  else:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVae=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not YKnucEvgPjyxbAWzqNCXJOfdrhSVae:
    xbmcplugin.endOfDirectory(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle)
    return
  YKnucEvgPjyxbAWzqNCXJOfdrhSVsQ,YKnucEvgPjyxbAWzqNCXJOfdrhSVsl=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.GetSearchList(YKnucEvgPjyxbAWzqNCXJOfdrhSVae,YKnucEvgPjyxbAWzqNCXJOfdrhSVmo)
  for YKnucEvgPjyxbAWzqNCXJOfdrhSVsp in YKnucEvgPjyxbAWzqNCXJOfdrhSVsQ:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVmp =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('code')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('title')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsw=YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('content_type')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsD =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('story')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVmD =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('thumbnail')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsT =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('year')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsB =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('film_rating_code')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsF=YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('film_rating_short')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsk =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('film_rating_long')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVsH =YKnucEvgPjyxbAWzqNCXJOfdrhSVsp.get('duration')
   if YKnucEvgPjyxbAWzqNCXJOfdrhSVsw=='movies': 
    YKnucEvgPjyxbAWzqNCXJOfdrhSVop =YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
    YKnucEvgPjyxbAWzqNCXJOfdrhSVsU ='MOVIE'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVoD =''
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmw='-'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVst ='movie'
   else: 
    YKnucEvgPjyxbAWzqNCXJOfdrhSVop =YKnucEvgPjyxbAWzqNCXJOfdrhSVRI
    YKnucEvgPjyxbAWzqNCXJOfdrhSVsU ='EPISODE'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVoD ='Series'
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmw=YKnucEvgPjyxbAWzqNCXJOfdrhSVmp
    YKnucEvgPjyxbAWzqNCXJOfdrhSVst ='tvshow' 
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaG={'mediatype':YKnucEvgPjyxbAWzqNCXJOfdrhSVst,'mpaa':YKnucEvgPjyxbAWzqNCXJOfdrhSVsk,'title':YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,'year':YKnucEvgPjyxbAWzqNCXJOfdrhSVsT,'duration':YKnucEvgPjyxbAWzqNCXJOfdrhSVsH,'plot':YKnucEvgPjyxbAWzqNCXJOfdrhSVsD}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL+='  (%s년 - %s)'%(YKnucEvgPjyxbAWzqNCXJOfdrhSVsT,YKnucEvgPjyxbAWzqNCXJOfdrhSVRT(YKnucEvgPjyxbAWzqNCXJOfdrhSVsF))
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol={'mode':YKnucEvgPjyxbAWzqNCXJOfdrhSVsU,'movie_code':YKnucEvgPjyxbAWzqNCXJOfdrhSVmp,'page':'1','season_code':YKnucEvgPjyxbAWzqNCXJOfdrhSVmw,'title':YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,'thumbnail':YKnucEvgPjyxbAWzqNCXJOfdrhSVmD}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel=YKnucEvgPjyxbAWzqNCXJOfdrhSVoD,img=YKnucEvgPjyxbAWzqNCXJOfdrhSVmD,infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVaG,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVop,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVsl:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol={}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['mode'] ='SEARCH'
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['search_key']=YKnucEvgPjyxbAWzqNCXJOfdrhSVae
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol['page'] =YKnucEvgPjyxbAWzqNCXJOfdrhSVRT(YKnucEvgPjyxbAWzqNCXJOfdrhSVmo+1)
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL='[B]%s >>[/B]'%'다음 페이지'
   YKnucEvgPjyxbAWzqNCXJOfdrhSVml=YKnucEvgPjyxbAWzqNCXJOfdrhSVRT(YKnucEvgPjyxbAWzqNCXJOfdrhSVmo+1)
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel=YKnucEvgPjyxbAWzqNCXJOfdrhSVml,img=YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ,infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVRL,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol)
  xbmcplugin.endOfDirectory(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle,cacheToDisc=YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ)
 def Delete_Watched_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,YKnucEvgPjyxbAWzqNCXJOfdrhSVmG):
  try:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%YKnucEvgPjyxbAWzqNCXJOfdrhSVmG))
   fp=YKnucEvgPjyxbAWzqNCXJOfdrhSVRB(YKnucEvgPjyxbAWzqNCXJOfdrhSVaL,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVRL
 def dp_WatchList_Delete(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,args):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmG=args.get('stype')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGp=xbmcgui.Dialog()
  YKnucEvgPjyxbAWzqNCXJOfdrhSVok=YKnucEvgPjyxbAWzqNCXJOfdrhSVGp.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVok==YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ:sys.exit()
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.Delete_Watched_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVmG)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,YKnucEvgPjyxbAWzqNCXJOfdrhSVmG):
  try:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%YKnucEvgPjyxbAWzqNCXJOfdrhSVmG))
   fp=YKnucEvgPjyxbAWzqNCXJOfdrhSVRB(YKnucEvgPjyxbAWzqNCXJOfdrhSVaL,'r',-1,'utf-8')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVai=fp.readlines()
   fp.close()
  except:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVai=[]
  return YKnucEvgPjyxbAWzqNCXJOfdrhSVai
 def Save_Watched_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,YKnucEvgPjyxbAWzqNCXJOfdrhSVmG,YKnucEvgPjyxbAWzqNCXJOfdrhSVGQ):
  try:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%YKnucEvgPjyxbAWzqNCXJOfdrhSVmG))
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaI=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.Load_Watched_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVmG) 
   fp=YKnucEvgPjyxbAWzqNCXJOfdrhSVRB(YKnucEvgPjyxbAWzqNCXJOfdrhSVaL,'w',-1,'utf-8')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaQ=urllib.parse.urlencode(YKnucEvgPjyxbAWzqNCXJOfdrhSVGQ)
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaQ=YKnucEvgPjyxbAWzqNCXJOfdrhSVaQ+'\n'
   fp.write(YKnucEvgPjyxbAWzqNCXJOfdrhSVaQ)
   YKnucEvgPjyxbAWzqNCXJOfdrhSVal=0
   for YKnucEvgPjyxbAWzqNCXJOfdrhSVap in YKnucEvgPjyxbAWzqNCXJOfdrhSVaI:
    YKnucEvgPjyxbAWzqNCXJOfdrhSVaw=YKnucEvgPjyxbAWzqNCXJOfdrhSVRp(urllib.parse.parse_qsl(YKnucEvgPjyxbAWzqNCXJOfdrhSVap))
    YKnucEvgPjyxbAWzqNCXJOfdrhSVaD=YKnucEvgPjyxbAWzqNCXJOfdrhSVGQ.get('code').strip()
    YKnucEvgPjyxbAWzqNCXJOfdrhSVaT=YKnucEvgPjyxbAWzqNCXJOfdrhSVaw.get('code').strip()
    if YKnucEvgPjyxbAWzqNCXJOfdrhSVmG=='seasons' and YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_settings_direct_replay()==YKnucEvgPjyxbAWzqNCXJOfdrhSVRI:
     YKnucEvgPjyxbAWzqNCXJOfdrhSVaD=YKnucEvgPjyxbAWzqNCXJOfdrhSVGQ.get('videoid').strip()
     YKnucEvgPjyxbAWzqNCXJOfdrhSVaT=YKnucEvgPjyxbAWzqNCXJOfdrhSVaw.get('videoid').strip()if YKnucEvgPjyxbAWzqNCXJOfdrhSVaT!=YKnucEvgPjyxbAWzqNCXJOfdrhSVRL else '-'
    if YKnucEvgPjyxbAWzqNCXJOfdrhSVaD!=YKnucEvgPjyxbAWzqNCXJOfdrhSVaT:
     fp.write(YKnucEvgPjyxbAWzqNCXJOfdrhSVap)
     YKnucEvgPjyxbAWzqNCXJOfdrhSVal+=1
     if YKnucEvgPjyxbAWzqNCXJOfdrhSVal>=50:break
   fp.close()
  except:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVRL
 def dp_Watch_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,args):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVmG =args.get('stype')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVos=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.get_settings_direct_replay()
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVmG=='-':
   for YKnucEvgPjyxbAWzqNCXJOfdrhSVaB in YKnucEvgPjyxbAWzqNCXJOfdrhSVGs:
    YKnucEvgPjyxbAWzqNCXJOfdrhSVoL=YKnucEvgPjyxbAWzqNCXJOfdrhSVaB.get('title')
    YKnucEvgPjyxbAWzqNCXJOfdrhSVol={'mode':YKnucEvgPjyxbAWzqNCXJOfdrhSVaB.get('mode'),'stype':YKnucEvgPjyxbAWzqNCXJOfdrhSVaB.get('stype')}
    YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel='',img='',infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVRL,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol)
   if YKnucEvgPjyxbAWzqNCXJOfdrhSVRw(YKnucEvgPjyxbAWzqNCXJOfdrhSVGs)>0:xbmcplugin.endOfDirectory(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle)
  else:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaF=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.Load_Watched_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVmG)
   for YKnucEvgPjyxbAWzqNCXJOfdrhSVak in YKnucEvgPjyxbAWzqNCXJOfdrhSVaF:
    YKnucEvgPjyxbAWzqNCXJOfdrhSVaH=YKnucEvgPjyxbAWzqNCXJOfdrhSVRp(urllib.parse.parse_qsl(YKnucEvgPjyxbAWzqNCXJOfdrhSVak))
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmp=YKnucEvgPjyxbAWzqNCXJOfdrhSVaH.get('code').strip()
    YKnucEvgPjyxbAWzqNCXJOfdrhSVoL =YKnucEvgPjyxbAWzqNCXJOfdrhSVaH.get('title').strip()
    YKnucEvgPjyxbAWzqNCXJOfdrhSVmD =YKnucEvgPjyxbAWzqNCXJOfdrhSVaH.get('img').strip()
    YKnucEvgPjyxbAWzqNCXJOfdrhSVaU =YKnucEvgPjyxbAWzqNCXJOfdrhSVaH.get('videoid').strip()
    try:
     YKnucEvgPjyxbAWzqNCXJOfdrhSVmD=YKnucEvgPjyxbAWzqNCXJOfdrhSVmD.replace('\'','\"')
     YKnucEvgPjyxbAWzqNCXJOfdrhSVmD=json.loads(YKnucEvgPjyxbAWzqNCXJOfdrhSVmD)
    except:
     YKnucEvgPjyxbAWzqNCXJOfdrhSVRL
    YKnucEvgPjyxbAWzqNCXJOfdrhSVaG={}
    YKnucEvgPjyxbAWzqNCXJOfdrhSVaG['plot']=YKnucEvgPjyxbAWzqNCXJOfdrhSVoL
    if YKnucEvgPjyxbAWzqNCXJOfdrhSVmG=='movie':
     YKnucEvgPjyxbAWzqNCXJOfdrhSVol={'mode':'MOVIE','page':'1','movie_code':YKnucEvgPjyxbAWzqNCXJOfdrhSVmp,'season_code':'-','title':YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,'thumbnail':YKnucEvgPjyxbAWzqNCXJOfdrhSVmD}
     YKnucEvgPjyxbAWzqNCXJOfdrhSVop=YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
    else:
     if YKnucEvgPjyxbAWzqNCXJOfdrhSVos==YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ or YKnucEvgPjyxbAWzqNCXJOfdrhSVaU==YKnucEvgPjyxbAWzqNCXJOfdrhSVRL:
      YKnucEvgPjyxbAWzqNCXJOfdrhSVol={'mode':'EPISODE','page':'1','movie_code':YKnucEvgPjyxbAWzqNCXJOfdrhSVmp,'season_code':YKnucEvgPjyxbAWzqNCXJOfdrhSVmp,'title':YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,'thumbnail':YKnucEvgPjyxbAWzqNCXJOfdrhSVmD}
      YKnucEvgPjyxbAWzqNCXJOfdrhSVop=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI
     else:
      YKnucEvgPjyxbAWzqNCXJOfdrhSVol={'mode':'MOVIE','movie_code':YKnucEvgPjyxbAWzqNCXJOfdrhSVaU,'season_code':YKnucEvgPjyxbAWzqNCXJOfdrhSVmp,'title':YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,'thumbnail':YKnucEvgPjyxbAWzqNCXJOfdrhSVmD}
      YKnucEvgPjyxbAWzqNCXJOfdrhSVop=YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
    YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel='',img=YKnucEvgPjyxbAWzqNCXJOfdrhSVmD,infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVaG,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVop,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol)
   YKnucEvgPjyxbAWzqNCXJOfdrhSVaG={'plot':'시청목록을 삭제합니다.'}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoL='*** 시청목록 삭제 ***'
   YKnucEvgPjyxbAWzqNCXJOfdrhSVol={'mode':'MYVIEW_REMOVE','stype':YKnucEvgPjyxbAWzqNCXJOfdrhSVmG}
   YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.add_dir(YKnucEvgPjyxbAWzqNCXJOfdrhSVoL,sublabel='',img=YKnucEvgPjyxbAWzqNCXJOfdrhSVoQ,infoLabels=YKnucEvgPjyxbAWzqNCXJOfdrhSVaG,isFolder=YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ,params=YKnucEvgPjyxbAWzqNCXJOfdrhSVol,isLink=YKnucEvgPjyxbAWzqNCXJOfdrhSVRI)
   xbmcplugin.endOfDirectory(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL._addon_handle,cacheToDisc=YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ)
 def logout(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGp=xbmcgui.Dialog()
  YKnucEvgPjyxbAWzqNCXJOfdrhSVok=YKnucEvgPjyxbAWzqNCXJOfdrhSVGp.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVok==YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ:sys.exit()
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.wininfo_clear()
  if os.path.isfile(YKnucEvgPjyxbAWzqNCXJOfdrhSVGe):os.remove(YKnucEvgPjyxbAWzqNCXJOfdrhSVGe)
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa=xbmcgui.Window(10000)
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_TOKEN','')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_GUIT','')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_GUITV','')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_USERCD','')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVat =YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.Get_Now_Datetime()
  YKnucEvgPjyxbAWzqNCXJOfdrhSVRG=YKnucEvgPjyxbAWzqNCXJOfdrhSVat+datetime.timedelta(days=YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(__addon__.getSetting('cache_ttl')))
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa=xbmcgui.Window(10000)
  YKnucEvgPjyxbAWzqNCXJOfdrhSVRo={'watcha_token':YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.getProperty('WATCHA_M_TOKEN'),'watcha_guit':YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.getProperty('WATCHA_M_GUIT'),'watcha_guitv':YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.getProperty('WATCHA_M_GUITV'),'watcha_usercd':YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':YKnucEvgPjyxbAWzqNCXJOfdrhSVRG.strftime('%Y-%m-%d')}
  try: 
   fp=YKnucEvgPjyxbAWzqNCXJOfdrhSVRB(YKnucEvgPjyxbAWzqNCXJOfdrhSVGe,'w',-1,'utf-8')
   json.dump(YKnucEvgPjyxbAWzqNCXJOfdrhSVRo,fp)
   fp.close()
  except YKnucEvgPjyxbAWzqNCXJOfdrhSVRF as exception:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVRk(exception)
 def cookiefile_check(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVRo={}
  try: 
   fp=YKnucEvgPjyxbAWzqNCXJOfdrhSVRB(YKnucEvgPjyxbAWzqNCXJOfdrhSVGe,'r',-1,'utf-8')
   YKnucEvgPjyxbAWzqNCXJOfdrhSVRo= json.load(fp)
   fp.close()
  except YKnucEvgPjyxbAWzqNCXJOfdrhSVRF as exception:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.wininfo_clear()
   return YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoT =__addon__.getSetting('id')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoB =__addon__.getSetting('pw')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVRm =__addon__.getSetting('selected_profile')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_id']=base64.standard_b64decode(YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_id']).decode('utf-8')
  YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_pw']=base64.standard_b64decode(YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_pw']).decode('utf-8')
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVoT!=YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_id']or YKnucEvgPjyxbAWzqNCXJOfdrhSVoB!=YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_pw']or YKnucEvgPjyxbAWzqNCXJOfdrhSVRm!=YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_profile']:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.wininfo_clear()
   return YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoH =YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  YKnucEvgPjyxbAWzqNCXJOfdrhSVRs=YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_limitdate']
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoU =YKnucEvgPjyxbAWzqNCXJOfdrhSVRi(re.sub('-','',YKnucEvgPjyxbAWzqNCXJOfdrhSVRs))
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVoU<YKnucEvgPjyxbAWzqNCXJOfdrhSVoH:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.wininfo_clear()
   return YKnucEvgPjyxbAWzqNCXJOfdrhSVRQ
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa=xbmcgui.Window(10000)
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_TOKEN',YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_token'])
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_GUIT',YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_guit'])
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_GUITV',YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_guitv'])
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_USERCD',YKnucEvgPjyxbAWzqNCXJOfdrhSVRo['watcha_usercd'])
  YKnucEvgPjyxbAWzqNCXJOfdrhSVoa.setProperty('WATCHA_M_LOGINTIME',YKnucEvgPjyxbAWzqNCXJOfdrhSVRs)
  return YKnucEvgPjyxbAWzqNCXJOfdrhSVRI
 def dp_Global_Search(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL,args):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVRa=args.get('mode')
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVRa=='TOTAL_SEARCH':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVRM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVRM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(YKnucEvgPjyxbAWzqNCXJOfdrhSVRM)
 def watcha_main(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL):
  YKnucEvgPjyxbAWzqNCXJOfdrhSVRa=YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.main_params.get('mode',YKnucEvgPjyxbAWzqNCXJOfdrhSVRL)
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVRa=='LOGOUT':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.logout()
   return
  YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.login_main()
  if YKnucEvgPjyxbAWzqNCXJOfdrhSVRa is YKnucEvgPjyxbAWzqNCXJOfdrhSVRL:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.dp_Main_List()
  elif YKnucEvgPjyxbAWzqNCXJOfdrhSVRa=='SUB_GROUP':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.dp_SubGroup_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.main_params)
  elif YKnucEvgPjyxbAWzqNCXJOfdrhSVRa=='CATEGORY_LIST':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.dp_Category_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.main_params)
  elif YKnucEvgPjyxbAWzqNCXJOfdrhSVRa=='EPISODE':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.dp_Episode_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.main_params)
  elif YKnucEvgPjyxbAWzqNCXJOfdrhSVRa=='ORDER_BY':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.dp_setEpOrderby(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.main_params)
  elif YKnucEvgPjyxbAWzqNCXJOfdrhSVRa in['SEARCH','LOCAL_SEARCH']:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.dp_Search_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.main_params)
  elif YKnucEvgPjyxbAWzqNCXJOfdrhSVRa=='MOVIE':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.play_VIDEO(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.main_params)
  elif YKnucEvgPjyxbAWzqNCXJOfdrhSVRa=='WATCH':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.dp_Watch_List(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.main_params)
  elif YKnucEvgPjyxbAWzqNCXJOfdrhSVRa=='MYVIEW_REMOVE':
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.dp_WatchList_Delete(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.main_params)
  elif YKnucEvgPjyxbAWzqNCXJOfdrhSVRa in['TOTAL_SEARCH','TOTAL_HISTORY']:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.dp_Global_Search(YKnucEvgPjyxbAWzqNCXJOfdrhSVGL.main_params)
  else:
   YKnucEvgPjyxbAWzqNCXJOfdrhSVRL
# Created by pyminifier (https://github.com/liftoff/pyminifier)
