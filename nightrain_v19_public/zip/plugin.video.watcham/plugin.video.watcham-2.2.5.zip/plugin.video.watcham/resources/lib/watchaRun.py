__author__="NightRain"
FhLPSCsqunXxRcVOWKYmtGMoQkzilv=object
FhLPSCsqunXxRcVOWKYmtGMoQkzilB=None
FhLPSCsqunXxRcVOWKYmtGMoQkzilA=int
FhLPSCsqunXxRcVOWKYmtGMoQkzilw=True
FhLPSCsqunXxRcVOWKYmtGMoQkzilb=False
FhLPSCsqunXxRcVOWKYmtGMoQkzilg=type
FhLPSCsqunXxRcVOWKYmtGMoQkzilE=dict
FhLPSCsqunXxRcVOWKYmtGMoQkzilU=len
FhLPSCsqunXxRcVOWKYmtGMoQkzilT=range
FhLPSCsqunXxRcVOWKYmtGMoQkzilJ=str
FhLPSCsqunXxRcVOWKYmtGMoQkzilj=open
from ast import Pass
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
FhLPSCsqunXxRcVOWKYmtGMoQkziev=[{'title':'홈','mode':'HOME_GROUP','stype':'-','api_path':'-'},{'title':'오직 왓챠에서!','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/6100'},{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest'},{'title':'장르별 둘러보기','mode':'SUB_GROUP','stype':'genres','api_path':'-'},{'title':'특징별 둘러보기','mode':'SUB_GROUP','stype':'tags','api_path':'-'},{'title':'이어보기 (시청이력)','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','icon':'bookmark.png'},]
FhLPSCsqunXxRcVOWKYmtGMoQkzieB=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
FhLPSCsqunXxRcVOWKYmtGMoQkzieA=40
FhLPSCsqunXxRcVOWKYmtGMoQkziew =30
FhLPSCsqunXxRcVOWKYmtGMoQkzieb =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
FhLPSCsqunXxRcVOWKYmtGMoQkziel =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.srt'))
FhLPSCsqunXxRcVOWKYmtGMoQkzieg =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
FhLPSCsqunXxRcVOWKYmtGMoQkzieE=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
from watchaCore import*
class FhLPSCsqunXxRcVOWKYmtGMoQkzied(FhLPSCsqunXxRcVOWKYmtGMoQkzilv):
 def __init__(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,FhLPSCsqunXxRcVOWKYmtGMoQkzieT,FhLPSCsqunXxRcVOWKYmtGMoQkzieJ,FhLPSCsqunXxRcVOWKYmtGMoQkziej):
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_url =FhLPSCsqunXxRcVOWKYmtGMoQkzieT
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle=FhLPSCsqunXxRcVOWKYmtGMoQkzieJ
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params =FhLPSCsqunXxRcVOWKYmtGMoQkziej
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj =JgkWPmpxYDbLHanXUutoSFeyIcrMlB() 
 def addon_noti(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,sting):
  try:
   FhLPSCsqunXxRcVOWKYmtGMoQkzieN=xbmcgui.Dialog()
   FhLPSCsqunXxRcVOWKYmtGMoQkzieN.notification(__addonname__,sting)
  except:
   FhLPSCsqunXxRcVOWKYmtGMoQkzilB
 def addon_log(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,string):
  try:
   FhLPSCsqunXxRcVOWKYmtGMoQkziea=string.encode('utf-8','ignore')
  except:
   FhLPSCsqunXxRcVOWKYmtGMoQkziea='addonException: addon_log'
  FhLPSCsqunXxRcVOWKYmtGMoQkzief=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,FhLPSCsqunXxRcVOWKYmtGMoQkziea),level=FhLPSCsqunXxRcVOWKYmtGMoQkzief)
 def get_keyboard_input(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,FhLPSCsqunXxRcVOWKYmtGMoQkzidU):
  FhLPSCsqunXxRcVOWKYmtGMoQkziep=FhLPSCsqunXxRcVOWKYmtGMoQkzilB
  kb=xbmc.Keyboard()
  kb.setHeading(FhLPSCsqunXxRcVOWKYmtGMoQkzidU)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   FhLPSCsqunXxRcVOWKYmtGMoQkziep=kb.getText()
  return FhLPSCsqunXxRcVOWKYmtGMoQkziep
 def get_settings_account(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  FhLPSCsqunXxRcVOWKYmtGMoQkziey =__addon__.getSetting('id')
  FhLPSCsqunXxRcVOWKYmtGMoQkzieD =__addon__.getSetting('pw')
  FhLPSCsqunXxRcVOWKYmtGMoQkzieH=FhLPSCsqunXxRcVOWKYmtGMoQkzilA(__addon__.getSetting('selected_profile'))
  return(FhLPSCsqunXxRcVOWKYmtGMoQkziey,FhLPSCsqunXxRcVOWKYmtGMoQkzieD,FhLPSCsqunXxRcVOWKYmtGMoQkzieH)
 def get_settings_totalsearch(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  FhLPSCsqunXxRcVOWKYmtGMoQkzieI =FhLPSCsqunXxRcVOWKYmtGMoQkzilw if __addon__.getSetting('local_search')=='true' else FhLPSCsqunXxRcVOWKYmtGMoQkzilb
  FhLPSCsqunXxRcVOWKYmtGMoQkzide=FhLPSCsqunXxRcVOWKYmtGMoQkzilw if __addon__.getSetting('local_history')=='true' else FhLPSCsqunXxRcVOWKYmtGMoQkzilb
  FhLPSCsqunXxRcVOWKYmtGMoQkzidv =FhLPSCsqunXxRcVOWKYmtGMoQkzilw if __addon__.getSetting('total_search')=='true' else FhLPSCsqunXxRcVOWKYmtGMoQkzilb
  FhLPSCsqunXxRcVOWKYmtGMoQkzidB=FhLPSCsqunXxRcVOWKYmtGMoQkzilw if __addon__.getSetting('total_history')=='true' else FhLPSCsqunXxRcVOWKYmtGMoQkzilb
  FhLPSCsqunXxRcVOWKYmtGMoQkzidA=FhLPSCsqunXxRcVOWKYmtGMoQkzilw if __addon__.getSetting('menu_bookmark')=='true' else FhLPSCsqunXxRcVOWKYmtGMoQkzilb
  return(FhLPSCsqunXxRcVOWKYmtGMoQkzieI,FhLPSCsqunXxRcVOWKYmtGMoQkzide,FhLPSCsqunXxRcVOWKYmtGMoQkzidv,FhLPSCsqunXxRcVOWKYmtGMoQkzidB,FhLPSCsqunXxRcVOWKYmtGMoQkzidA)
 def get_settings_makebookmark(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  return FhLPSCsqunXxRcVOWKYmtGMoQkzilw if __addon__.getSetting('make_bookmark')=='true' else FhLPSCsqunXxRcVOWKYmtGMoQkzilb
 def get_selQuality(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  try:
   FhLPSCsqunXxRcVOWKYmtGMoQkzidw=['3840x2160/1','1920x1080/1','1280x720/1']
   FhLPSCsqunXxRcVOWKYmtGMoQkzidb=FhLPSCsqunXxRcVOWKYmtGMoQkzilA(__addon__.getSetting('selected_quality'))
   return FhLPSCsqunXxRcVOWKYmtGMoQkzidw[FhLPSCsqunXxRcVOWKYmtGMoQkzidb]
  except:
   FhLPSCsqunXxRcVOWKYmtGMoQkzilB
  return 1080 
 def get_settings_direct_replay(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  FhLPSCsqunXxRcVOWKYmtGMoQkzidl=FhLPSCsqunXxRcVOWKYmtGMoQkzilA(__addon__.getSetting('direct_replay'))
  if FhLPSCsqunXxRcVOWKYmtGMoQkzidl==0:
   return FhLPSCsqunXxRcVOWKYmtGMoQkzilb
  else:
   return FhLPSCsqunXxRcVOWKYmtGMoQkzilw
 def set_winEpisodeOrderby(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,FhLPSCsqunXxRcVOWKYmtGMoQkzidg):
  __addon__.setSetting('watcha_orderby',FhLPSCsqunXxRcVOWKYmtGMoQkzidg)
 def get_winEpisodeOrderby(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  FhLPSCsqunXxRcVOWKYmtGMoQkzidg=__addon__.getSetting('watcha_orderby')
  if FhLPSCsqunXxRcVOWKYmtGMoQkzidg in['',FhLPSCsqunXxRcVOWKYmtGMoQkzilB]:FhLPSCsqunXxRcVOWKYmtGMoQkzidg='asc'
  return FhLPSCsqunXxRcVOWKYmtGMoQkzidg
 def dp_setEpOrderby(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkzidg =args.get('orderby')
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.set_winEpisodeOrderby(FhLPSCsqunXxRcVOWKYmtGMoQkzidg)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,label,sublabel='',img='',infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilw,params='',isLink=FhLPSCsqunXxRcVOWKYmtGMoQkzilb,ContextMenu=FhLPSCsqunXxRcVOWKYmtGMoQkzilB):
  FhLPSCsqunXxRcVOWKYmtGMoQkzidE='%s?%s'%(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_url,urllib.parse.urlencode(params))
  if sublabel:FhLPSCsqunXxRcVOWKYmtGMoQkzidU='%s < %s >'%(label,sublabel)
  else: FhLPSCsqunXxRcVOWKYmtGMoQkzidU=label
  if not img:img='DefaultFolder.png'
  FhLPSCsqunXxRcVOWKYmtGMoQkzidT=xbmcgui.ListItem(FhLPSCsqunXxRcVOWKYmtGMoQkzidU)
  if FhLPSCsqunXxRcVOWKYmtGMoQkzilg(img)==FhLPSCsqunXxRcVOWKYmtGMoQkzilE:
   FhLPSCsqunXxRcVOWKYmtGMoQkzidT.setArt(img)
  else:
   FhLPSCsqunXxRcVOWKYmtGMoQkzidT.setArt({'thumb':img,'poster':img})
  if infoLabels:FhLPSCsqunXxRcVOWKYmtGMoQkzidT.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   FhLPSCsqunXxRcVOWKYmtGMoQkzidT.setProperty('IsPlayable','true')
  if ContextMenu:FhLPSCsqunXxRcVOWKYmtGMoQkzidT.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,FhLPSCsqunXxRcVOWKYmtGMoQkzidE,FhLPSCsqunXxRcVOWKYmtGMoQkzidT,isFolder)
 def dp_Main_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  (FhLPSCsqunXxRcVOWKYmtGMoQkzieI,FhLPSCsqunXxRcVOWKYmtGMoQkzide,FhLPSCsqunXxRcVOWKYmtGMoQkzidv,FhLPSCsqunXxRcVOWKYmtGMoQkzidB,FhLPSCsqunXxRcVOWKYmtGMoQkzidA)=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_settings_totalsearch()
  for FhLPSCsqunXxRcVOWKYmtGMoQkzidJ in FhLPSCsqunXxRcVOWKYmtGMoQkziev:
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU=FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('title')
   FhLPSCsqunXxRcVOWKYmtGMoQkzidj=''
   if FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('mode')=='LOCAL_SEARCH' and FhLPSCsqunXxRcVOWKYmtGMoQkzieI ==FhLPSCsqunXxRcVOWKYmtGMoQkzilb:continue
   elif FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('mode')=='SEARCH_HISTORY' and FhLPSCsqunXxRcVOWKYmtGMoQkzide==FhLPSCsqunXxRcVOWKYmtGMoQkzilb:continue
   elif FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('mode')=='TOTAL_SEARCH' and FhLPSCsqunXxRcVOWKYmtGMoQkzidv ==FhLPSCsqunXxRcVOWKYmtGMoQkzilb:continue
   elif FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('mode')=='TOTAL_HISTORY' and FhLPSCsqunXxRcVOWKYmtGMoQkzidB==FhLPSCsqunXxRcVOWKYmtGMoQkzilb:continue
   elif FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('mode')=='MENU_BOOKMARK' and FhLPSCsqunXxRcVOWKYmtGMoQkzidA==FhLPSCsqunXxRcVOWKYmtGMoQkzilb:continue
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('mode'),'stype':FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('stype'),'api_path':FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('api_path'),'page':'1','tag_id':'-',}
   if FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('mode')=='LOCAL_SEARCH':FhLPSCsqunXxRcVOWKYmtGMoQkzidr['historyyn']='Y' 
   if FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    FhLPSCsqunXxRcVOWKYmtGMoQkzidN=FhLPSCsqunXxRcVOWKYmtGMoQkzilb
    FhLPSCsqunXxRcVOWKYmtGMoQkzida =FhLPSCsqunXxRcVOWKYmtGMoQkzilw
   else:
    FhLPSCsqunXxRcVOWKYmtGMoQkzidN=FhLPSCsqunXxRcVOWKYmtGMoQkzilw
    FhLPSCsqunXxRcVOWKYmtGMoQkzida =FhLPSCsqunXxRcVOWKYmtGMoQkzilb
   if 'icon' in FhLPSCsqunXxRcVOWKYmtGMoQkzidJ:FhLPSCsqunXxRcVOWKYmtGMoQkzidj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',FhLPSCsqunXxRcVOWKYmtGMoQkzidJ.get('icon')) 
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel='',img=FhLPSCsqunXxRcVOWKYmtGMoQkzidj,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzidN,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr,isLink=FhLPSCsqunXxRcVOWKYmtGMoQkzida)
  xbmcplugin.endOfDirectory(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle)
 def login_main(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  (FhLPSCsqunXxRcVOWKYmtGMoQkzidp,FhLPSCsqunXxRcVOWKYmtGMoQkzidy,FhLPSCsqunXxRcVOWKYmtGMoQkzidD)=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_settings_account()
  if not(FhLPSCsqunXxRcVOWKYmtGMoQkzidp and FhLPSCsqunXxRcVOWKYmtGMoQkzidy):
   FhLPSCsqunXxRcVOWKYmtGMoQkzieN=xbmcgui.Dialog()
   FhLPSCsqunXxRcVOWKYmtGMoQkzidH=FhLPSCsqunXxRcVOWKYmtGMoQkzieN.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if FhLPSCsqunXxRcVOWKYmtGMoQkzidH==FhLPSCsqunXxRcVOWKYmtGMoQkzilw:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if FhLPSCsqunXxRcVOWKYmtGMoQkzieU.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   FhLPSCsqunXxRcVOWKYmtGMoQkzidI=0
   while FhLPSCsqunXxRcVOWKYmtGMoQkzilw:
    FhLPSCsqunXxRcVOWKYmtGMoQkzidI+=1
    time.sleep(0.05)
    if FhLPSCsqunXxRcVOWKYmtGMoQkzidI>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  FhLPSCsqunXxRcVOWKYmtGMoQkzive=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.GetCredential(FhLPSCsqunXxRcVOWKYmtGMoQkzidp,FhLPSCsqunXxRcVOWKYmtGMoQkzidy,FhLPSCsqunXxRcVOWKYmtGMoQkzidD)
  if FhLPSCsqunXxRcVOWKYmtGMoQkzive:FhLPSCsqunXxRcVOWKYmtGMoQkzieU.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
  if FhLPSCsqunXxRcVOWKYmtGMoQkzive==FhLPSCsqunXxRcVOWKYmtGMoQkzilb:
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_HomeGroup_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkzivd=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.GetHomeList()
  for FhLPSCsqunXxRcVOWKYmtGMoQkzivB in FhLPSCsqunXxRcVOWKYmtGMoQkzivd:
   FhLPSCsqunXxRcVOWKYmtGMoQkzivA =FhLPSCsqunXxRcVOWKYmtGMoQkzivB.get('code')
   FhLPSCsqunXxRcVOWKYmtGMoQkzivw=FhLPSCsqunXxRcVOWKYmtGMoQkzivB.get('content_type')
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU =FhLPSCsqunXxRcVOWKYmtGMoQkzivB.get('title')
   FhLPSCsqunXxRcVOWKYmtGMoQkzivb =FhLPSCsqunXxRcVOWKYmtGMoQkzivB.get('bedge')
   FhLPSCsqunXxRcVOWKYmtGMoQkzivl =FhLPSCsqunXxRcVOWKYmtGMoQkzivB.get('thumbnail')
   if FhLPSCsqunXxRcVOWKYmtGMoQkzivw=='staffmades':
    FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'CATEGORY_LIST','api_path':'staffmades/'+FhLPSCsqunXxRcVOWKYmtGMoQkzivA,'page':'1',}
    FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel=FhLPSCsqunXxRcVOWKYmtGMoQkzivb,img=FhLPSCsqunXxRcVOWKYmtGMoQkzivl,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilw,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr)
   elif FhLPSCsqunXxRcVOWKYmtGMoQkzivw=='contents':
    FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'EPISODE','movie_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivA,'page':'1','season_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivA,'title':FhLPSCsqunXxRcVOWKYmtGMoQkzidU,'thumbnail':FhLPSCsqunXxRcVOWKYmtGMoQkzivl,}
    FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel=FhLPSCsqunXxRcVOWKYmtGMoQkzivb,img=FhLPSCsqunXxRcVOWKYmtGMoQkzivl,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilw,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr)
   else:
    FhLPSCsqunXxRcVOWKYmtGMoQkzivg
  xbmcplugin.endOfDirectory(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,cacheToDisc=FhLPSCsqunXxRcVOWKYmtGMoQkzilw)
 def dp_SubGroup_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkzivU =args.get('stype')
  FhLPSCsqunXxRcVOWKYmtGMoQkzivT =FhLPSCsqunXxRcVOWKYmtGMoQkzilA(args.get('page'))
  FhLPSCsqunXxRcVOWKYmtGMoQkzivJ=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.GetSubGroupList(FhLPSCsqunXxRcVOWKYmtGMoQkzivU)
  FhLPSCsqunXxRcVOWKYmtGMoQkzivj=FhLPSCsqunXxRcVOWKYmtGMoQkzieA if FhLPSCsqunXxRcVOWKYmtGMoQkzivU=='genres' else FhLPSCsqunXxRcVOWKYmtGMoQkziew
  FhLPSCsqunXxRcVOWKYmtGMoQkzivr=FhLPSCsqunXxRcVOWKYmtGMoQkzilU(FhLPSCsqunXxRcVOWKYmtGMoQkzivJ)
  FhLPSCsqunXxRcVOWKYmtGMoQkzivN =FhLPSCsqunXxRcVOWKYmtGMoQkzilA(FhLPSCsqunXxRcVOWKYmtGMoQkzivr//(FhLPSCsqunXxRcVOWKYmtGMoQkzivj+1))+1
  FhLPSCsqunXxRcVOWKYmtGMoQkziva =(FhLPSCsqunXxRcVOWKYmtGMoQkzivT-1)*FhLPSCsqunXxRcVOWKYmtGMoQkzivj
  for i in FhLPSCsqunXxRcVOWKYmtGMoQkzilT(FhLPSCsqunXxRcVOWKYmtGMoQkzivj):
   FhLPSCsqunXxRcVOWKYmtGMoQkzivf=FhLPSCsqunXxRcVOWKYmtGMoQkziva+i
   if FhLPSCsqunXxRcVOWKYmtGMoQkzivf>=FhLPSCsqunXxRcVOWKYmtGMoQkzivr:break
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU =FhLPSCsqunXxRcVOWKYmtGMoQkzivJ[FhLPSCsqunXxRcVOWKYmtGMoQkzivf].get('group_name')
   FhLPSCsqunXxRcVOWKYmtGMoQkzivp =FhLPSCsqunXxRcVOWKYmtGMoQkzivJ[FhLPSCsqunXxRcVOWKYmtGMoQkzivf].get('api_path')
   FhLPSCsqunXxRcVOWKYmtGMoQkzivy =FhLPSCsqunXxRcVOWKYmtGMoQkzivJ[FhLPSCsqunXxRcVOWKYmtGMoQkzivf].get('tag_id')
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'CATEGORY_LIST','api_path':FhLPSCsqunXxRcVOWKYmtGMoQkzivp,'tag_id':FhLPSCsqunXxRcVOWKYmtGMoQkzivy,'stype':FhLPSCsqunXxRcVOWKYmtGMoQkzivU,'page':'1',}
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel='',img='',infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilw,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr)
  if FhLPSCsqunXxRcVOWKYmtGMoQkzivN>FhLPSCsqunXxRcVOWKYmtGMoQkzivT:
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={}
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['mode'] ='SUB_GROUP' 
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['stype'] =FhLPSCsqunXxRcVOWKYmtGMoQkzivU
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['api_path']=args.get('api_path')
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['page'] =FhLPSCsqunXxRcVOWKYmtGMoQkzilJ(FhLPSCsqunXxRcVOWKYmtGMoQkzivT+1)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU='[B]%s >>[/B]'%'다음 페이지'
   FhLPSCsqunXxRcVOWKYmtGMoQkzivD=FhLPSCsqunXxRcVOWKYmtGMoQkzilJ(FhLPSCsqunXxRcVOWKYmtGMoQkzivT+1)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel=FhLPSCsqunXxRcVOWKYmtGMoQkzivD,img=FhLPSCsqunXxRcVOWKYmtGMoQkzidj,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilw,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr)
  if FhLPSCsqunXxRcVOWKYmtGMoQkzilU(FhLPSCsqunXxRcVOWKYmtGMoQkzivJ)>0:xbmcplugin.endOfDirectory(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,cacheToDisc=FhLPSCsqunXxRcVOWKYmtGMoQkzilw)
 def play_VIDEO(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkzivH =args.get('movie_code')
  FhLPSCsqunXxRcVOWKYmtGMoQkzivI =args.get('season_code')
  FhLPSCsqunXxRcVOWKYmtGMoQkzidU =args.get('title')
  FhLPSCsqunXxRcVOWKYmtGMoQkzivl =args.get('thumbnail')
  FhLPSCsqunXxRcVOWKYmtGMoQkziBe =FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_selQuality()
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.addon_log(FhLPSCsqunXxRcVOWKYmtGMoQkzivH+' - '+FhLPSCsqunXxRcVOWKYmtGMoQkzivI)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBd,FhLPSCsqunXxRcVOWKYmtGMoQkziBv,FhLPSCsqunXxRcVOWKYmtGMoQkziBA=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.GetStreamingURL(FhLPSCsqunXxRcVOWKYmtGMoQkzivH,FhLPSCsqunXxRcVOWKYmtGMoQkziBe)
  if FhLPSCsqunXxRcVOWKYmtGMoQkziBd=='':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.addon_noti(__language__(30908).encode('utf8'))
   return
  FhLPSCsqunXxRcVOWKYmtGMoQkziBw=FhLPSCsqunXxRcVOWKYmtGMoQkziBd
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.addon_log(FhLPSCsqunXxRcVOWKYmtGMoQkziBw)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBb=xbmcgui.ListItem(path=FhLPSCsqunXxRcVOWKYmtGMoQkziBw)
  if FhLPSCsqunXxRcVOWKYmtGMoQkziBA:
   FhLPSCsqunXxRcVOWKYmtGMoQkziBl=FhLPSCsqunXxRcVOWKYmtGMoQkziBA
   FhLPSCsqunXxRcVOWKYmtGMoQkziBg ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   FhLPSCsqunXxRcVOWKYmtGMoQkziBE ='mpd'
   FhLPSCsqunXxRcVOWKYmtGMoQkziBU ='com.widevine.alpha'
   FhLPSCsqunXxRcVOWKYmtGMoQkziBT =inputstreamhelper.Helper(FhLPSCsqunXxRcVOWKYmtGMoQkziBE,drm=FhLPSCsqunXxRcVOWKYmtGMoQkziBU)
   if FhLPSCsqunXxRcVOWKYmtGMoQkziBT.check_inputstream():
    FhLPSCsqunXxRcVOWKYmtGMoQkziBJ={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+FhLPSCsqunXxRcVOWKYmtGMoQkzivH,'dt-custom-data':FhLPSCsqunXxRcVOWKYmtGMoQkziBl,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    FhLPSCsqunXxRcVOWKYmtGMoQkziBj=FhLPSCsqunXxRcVOWKYmtGMoQkziBg+'|'+urllib.parse.urlencode(FhLPSCsqunXxRcVOWKYmtGMoQkziBJ)+'|R{SSM}|'
    FhLPSCsqunXxRcVOWKYmtGMoQkzieU.addon_log(FhLPSCsqunXxRcVOWKYmtGMoQkziBj)
    FhLPSCsqunXxRcVOWKYmtGMoQkziBb.setProperty('inputstream',FhLPSCsqunXxRcVOWKYmtGMoQkziBT.inputstream_addon)
    FhLPSCsqunXxRcVOWKYmtGMoQkziBb.setProperty('inputstream.adaptive.manifest_type',FhLPSCsqunXxRcVOWKYmtGMoQkziBE)
    FhLPSCsqunXxRcVOWKYmtGMoQkziBb.setProperty('inputstream.adaptive.license_type',FhLPSCsqunXxRcVOWKYmtGMoQkziBU)
    FhLPSCsqunXxRcVOWKYmtGMoQkziBb.setProperty('inputstream.adaptive.license_key',FhLPSCsqunXxRcVOWKYmtGMoQkziBj)
    FhLPSCsqunXxRcVOWKYmtGMoQkziBb.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.USER_AGENT))
  if FhLPSCsqunXxRcVOWKYmtGMoQkziBv:
   try:
    f=FhLPSCsqunXxRcVOWKYmtGMoQkzilj(FhLPSCsqunXxRcVOWKYmtGMoQkzieb,'w',-1,'utf-8')
    FhLPSCsqunXxRcVOWKYmtGMoQkziBr=requests.get(FhLPSCsqunXxRcVOWKYmtGMoQkziBv)
    FhLPSCsqunXxRcVOWKYmtGMoQkziBN=FhLPSCsqunXxRcVOWKYmtGMoQkziBr.content.decode('utf-8') 
    for FhLPSCsqunXxRcVOWKYmtGMoQkziBa in FhLPSCsqunXxRcVOWKYmtGMoQkziBN.splitlines():
     FhLPSCsqunXxRcVOWKYmtGMoQkziBf=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',FhLPSCsqunXxRcVOWKYmtGMoQkziBa)
     f.write(FhLPSCsqunXxRcVOWKYmtGMoQkziBf+'\n')
    f.close()
    FhLPSCsqunXxRcVOWKYmtGMoQkziBb.setSubtitles([FhLPSCsqunXxRcVOWKYmtGMoQkzieb,FhLPSCsqunXxRcVOWKYmtGMoQkziBv])
   except:
    FhLPSCsqunXxRcVOWKYmtGMoQkziBb.setSubtitles([FhLPSCsqunXxRcVOWKYmtGMoQkziBv])
  xbmcplugin.setResolvedUrl(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,FhLPSCsqunXxRcVOWKYmtGMoQkzilw,FhLPSCsqunXxRcVOWKYmtGMoQkziBb)
  try:
   FhLPSCsqunXxRcVOWKYmtGMoQkzivU='movie' if FhLPSCsqunXxRcVOWKYmtGMoQkzivI=='-' else 'seasons'
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'code':FhLPSCsqunXxRcVOWKYmtGMoQkzivH if FhLPSCsqunXxRcVOWKYmtGMoQkzivU=='movie' else FhLPSCsqunXxRcVOWKYmtGMoQkzivI,'img':FhLPSCsqunXxRcVOWKYmtGMoQkzivl,'title':FhLPSCsqunXxRcVOWKYmtGMoQkzidU,'videoid':FhLPSCsqunXxRcVOWKYmtGMoQkzivH}
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.Save_Watched_List(FhLPSCsqunXxRcVOWKYmtGMoQkzivU,FhLPSCsqunXxRcVOWKYmtGMoQkzidr)
  except:
   FhLPSCsqunXxRcVOWKYmtGMoQkzilB
 def srtConvert(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,FhLPSCsqunXxRcVOWKYmtGMoQkziBy):
  FhLPSCsqunXxRcVOWKYmtGMoQkziBp=re.sub(r'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',FhLPSCsqunXxRcVOWKYmtGMoQkziBy)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBp=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',FhLPSCsqunXxRcVOWKYmtGMoQkziBp)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBp=re.sub(r'(\d\d).(\d\d\d) --> (\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',FhLPSCsqunXxRcVOWKYmtGMoQkziBp)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBp=re.sub(r'WEBVTT\n','',FhLPSCsqunXxRcVOWKYmtGMoQkziBp)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBp=re.sub(r'Kind:[ \-\w]+\n','',FhLPSCsqunXxRcVOWKYmtGMoQkziBp)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBp=re.sub(r'Language:[ \-\w]+\n','',FhLPSCsqunXxRcVOWKYmtGMoQkziBp)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBp=re.sub(r'<c[.\w\d]*>','',FhLPSCsqunXxRcVOWKYmtGMoQkziBp)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBp=re.sub(r'</c>','',FhLPSCsqunXxRcVOWKYmtGMoQkziBp)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBp=re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>','',FhLPSCsqunXxRcVOWKYmtGMoQkziBp)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBp=re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n','',FhLPSCsqunXxRcVOWKYmtGMoQkziBp)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBp=re.sub(r'Style:\n##\n','',FhLPSCsqunXxRcVOWKYmtGMoQkziBp)
  return FhLPSCsqunXxRcVOWKYmtGMoQkziBp
 def vtt_to_srt(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,vttFilename,srtFilename):
  try:
   f=FhLPSCsqunXxRcVOWKYmtGMoQkzilj(vttFilename,'r',-1,'utf-8')
   FhLPSCsqunXxRcVOWKYmtGMoQkziBy=f.read()
   f.close()
   FhLPSCsqunXxRcVOWKYmtGMoQkziBD=''
   FhLPSCsqunXxRcVOWKYmtGMoQkziBD=FhLPSCsqunXxRcVOWKYmtGMoQkziBD+FhLPSCsqunXxRcVOWKYmtGMoQkzieU.srtConvert(FhLPSCsqunXxRcVOWKYmtGMoQkziBy)
   f=FhLPSCsqunXxRcVOWKYmtGMoQkzilj(srtFilename,'w',-1,'utf-8')
   f.writelines(FhLPSCsqunXxRcVOWKYmtGMoQkzilJ(FhLPSCsqunXxRcVOWKYmtGMoQkziBD))
   f.close()
  except:
   return FhLPSCsqunXxRcVOWKYmtGMoQkzilb
  return FhLPSCsqunXxRcVOWKYmtGMoQkzilw
 def dp_Category_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkzivU =args.get('stype')
  FhLPSCsqunXxRcVOWKYmtGMoQkzivy =args.get('tag_id')
  FhLPSCsqunXxRcVOWKYmtGMoQkzivp=args.get('api_path')
  FhLPSCsqunXxRcVOWKYmtGMoQkzivT=FhLPSCsqunXxRcVOWKYmtGMoQkzilA(args.get('page'))
  FhLPSCsqunXxRcVOWKYmtGMoQkziBH=[]
  FhLPSCsqunXxRcVOWKYmtGMoQkziBI,FhLPSCsqunXxRcVOWKYmtGMoQkziAe=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.GetCategoryList(FhLPSCsqunXxRcVOWKYmtGMoQkzivU,FhLPSCsqunXxRcVOWKYmtGMoQkzivy,FhLPSCsqunXxRcVOWKYmtGMoQkzivp,FhLPSCsqunXxRcVOWKYmtGMoQkzivT)
  for FhLPSCsqunXxRcVOWKYmtGMoQkziAd in FhLPSCsqunXxRcVOWKYmtGMoQkziBI:
   FhLPSCsqunXxRcVOWKYmtGMoQkzivH =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('code')
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('title')
   FhLPSCsqunXxRcVOWKYmtGMoQkzivw =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('content_type')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAv =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('story')
   FhLPSCsqunXxRcVOWKYmtGMoQkzivl =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('thumbnail')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAB =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('year')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAw =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('film_rating_code')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAb=FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('film_rating_short')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAl =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('film_rating_long')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAg =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('duration')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAE =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('badge')
   FhLPSCsqunXxRcVOWKYmtGMoQkziBH.append(FhLPSCsqunXxRcVOWKYmtGMoQkzivH)
   if FhLPSCsqunXxRcVOWKYmtGMoQkzivw=='movies': 
    FhLPSCsqunXxRcVOWKYmtGMoQkzidN =FhLPSCsqunXxRcVOWKYmtGMoQkzilb
    FhLPSCsqunXxRcVOWKYmtGMoQkziAU ='MOVIE'
    FhLPSCsqunXxRcVOWKYmtGMoQkzivI='-'
    FhLPSCsqunXxRcVOWKYmtGMoQkziAT ='movie'
   else: 
    FhLPSCsqunXxRcVOWKYmtGMoQkzidN =FhLPSCsqunXxRcVOWKYmtGMoQkzilw
    FhLPSCsqunXxRcVOWKYmtGMoQkziAU ='SEASON'
    FhLPSCsqunXxRcVOWKYmtGMoQkzivI=FhLPSCsqunXxRcVOWKYmtGMoQkzivH
    FhLPSCsqunXxRcVOWKYmtGMoQkziAT ='tvshow' 
   FhLPSCsqunXxRcVOWKYmtGMoQkziAJ={'mediatype':FhLPSCsqunXxRcVOWKYmtGMoQkziAT,'mpaa':FhLPSCsqunXxRcVOWKYmtGMoQkziAl,'title':FhLPSCsqunXxRcVOWKYmtGMoQkzidU,'year':FhLPSCsqunXxRcVOWKYmtGMoQkziAB,'duration':FhLPSCsqunXxRcVOWKYmtGMoQkziAg,'plot':FhLPSCsqunXxRcVOWKYmtGMoQkziAv,}
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU+='  (%s)'%(FhLPSCsqunXxRcVOWKYmtGMoQkziAB)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':FhLPSCsqunXxRcVOWKYmtGMoQkziAU,'movie_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivH,'page':'1','season_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivI,'title':FhLPSCsqunXxRcVOWKYmtGMoQkzidU,'thumbnail':FhLPSCsqunXxRcVOWKYmtGMoQkzivl,}
   FhLPSCsqunXxRcVOWKYmtGMoQkziAj=[]
   if FhLPSCsqunXxRcVOWKYmtGMoQkzivp=='users/me/watchings':
    FhLPSCsqunXxRcVOWKYmtGMoQkziAr={'codeList':[FhLPSCsqunXxRcVOWKYmtGMoQkzivH]}
    FhLPSCsqunXxRcVOWKYmtGMoQkziAN=json.dumps(FhLPSCsqunXxRcVOWKYmtGMoQkziAr)
    FhLPSCsqunXxRcVOWKYmtGMoQkziAN=urllib.parse.quote(FhLPSCsqunXxRcVOWKYmtGMoQkziAN)
    FhLPSCsqunXxRcVOWKYmtGMoQkziAa='RunPlugin(plugin://plugin.video.watcham/?mode=DELETE_CONTINUE&bm_param=%s)'%(FhLPSCsqunXxRcVOWKYmtGMoQkziAN)
    FhLPSCsqunXxRcVOWKYmtGMoQkziAj.append(('(선택영상) 이어보기에서 삭제',FhLPSCsqunXxRcVOWKYmtGMoQkziAa))
   if FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_settings_makebookmark():
    FhLPSCsqunXxRcVOWKYmtGMoQkziAr={'videoid':FhLPSCsqunXxRcVOWKYmtGMoQkzivH,'vidtype':'tvshow' if FhLPSCsqunXxRcVOWKYmtGMoQkzivw=='tv_seasons' else 'movie','vtitle':FhLPSCsqunXxRcVOWKYmtGMoQkzidU,'vsubtitle':'',}
    FhLPSCsqunXxRcVOWKYmtGMoQkziAN=json.dumps(FhLPSCsqunXxRcVOWKYmtGMoQkziAr)
    FhLPSCsqunXxRcVOWKYmtGMoQkziAN=urllib.parse.quote(FhLPSCsqunXxRcVOWKYmtGMoQkziAN)
    FhLPSCsqunXxRcVOWKYmtGMoQkziAa='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(FhLPSCsqunXxRcVOWKYmtGMoQkziAN)
    FhLPSCsqunXxRcVOWKYmtGMoQkziAj.append(('(통합) 찜 영상에 추가',FhLPSCsqunXxRcVOWKYmtGMoQkziAa))
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel=FhLPSCsqunXxRcVOWKYmtGMoQkziAE,img=FhLPSCsqunXxRcVOWKYmtGMoQkzivl,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkziAJ,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzidN,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr,ContextMenu=FhLPSCsqunXxRcVOWKYmtGMoQkziAj)
  if FhLPSCsqunXxRcVOWKYmtGMoQkzivp=='users/me/watchings':
   FhLPSCsqunXxRcVOWKYmtGMoQkziAr={'codeList':FhLPSCsqunXxRcVOWKYmtGMoQkziBH}
   FhLPSCsqunXxRcVOWKYmtGMoQkziAN=json.dumps(FhLPSCsqunXxRcVOWKYmtGMoQkziAr,separators=(',',':'))
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.addon_log(FhLPSCsqunXxRcVOWKYmtGMoQkziAN)
   FhLPSCsqunXxRcVOWKYmtGMoQkziAN=urllib.parse.quote(FhLPSCsqunXxRcVOWKYmtGMoQkziAN)
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.addon_log(FhLPSCsqunXxRcVOWKYmtGMoQkziAN)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'DELETE_CONTINUE','bm_param':FhLPSCsqunXxRcVOWKYmtGMoQkziAr,}
   FhLPSCsqunXxRcVOWKYmtGMoQkziAJ={'plot':'이어보기 목록 전체를 삭제합니다.'}
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU='** 이어보기 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   FhLPSCsqunXxRcVOWKYmtGMoQkzidj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel='',img=FhLPSCsqunXxRcVOWKYmtGMoQkzidj,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkziAJ,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilb,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr,isLink=FhLPSCsqunXxRcVOWKYmtGMoQkzilw)
  if FhLPSCsqunXxRcVOWKYmtGMoQkziAe:
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={}
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['mode'] ='CATEGORY_LIST'
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['stype'] =FhLPSCsqunXxRcVOWKYmtGMoQkzivU
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['tag_id'] =FhLPSCsqunXxRcVOWKYmtGMoQkzivy
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['api_path']=FhLPSCsqunXxRcVOWKYmtGMoQkzivp
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['page'] =FhLPSCsqunXxRcVOWKYmtGMoQkzilJ(FhLPSCsqunXxRcVOWKYmtGMoQkzivT+1)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU='[B]%s >>[/B]'%'다음 페이지'
   FhLPSCsqunXxRcVOWKYmtGMoQkzivD=FhLPSCsqunXxRcVOWKYmtGMoQkzilJ(FhLPSCsqunXxRcVOWKYmtGMoQkzivT+1)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel=FhLPSCsqunXxRcVOWKYmtGMoQkzivD,img=FhLPSCsqunXxRcVOWKYmtGMoQkzidj,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilw,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr)
  xbmcplugin.setContent(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,'movies')
  if FhLPSCsqunXxRcVOWKYmtGMoQkzilU(FhLPSCsqunXxRcVOWKYmtGMoQkziBI)>0:
   if FhLPSCsqunXxRcVOWKYmtGMoQkzivp=='arrivals/latest':
    xbmcplugin.endOfDirectory(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,cacheToDisc=FhLPSCsqunXxRcVOWKYmtGMoQkzilw)
   else:
    xbmcplugin.endOfDirectory(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,cacheToDisc=FhLPSCsqunXxRcVOWKYmtGMoQkzilb)
 def dp_Season_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkzivI=args.get('season_code')
  FhLPSCsqunXxRcVOWKYmtGMoQkzivl =args.get('thumbnail')
  FhLPSCsqunXxRcVOWKYmtGMoQkzivl=json.loads(FhLPSCsqunXxRcVOWKYmtGMoQkzivl.replace('\'','"'))
  FhLPSCsqunXxRcVOWKYmtGMoQkziAf=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.GetSeasonList(FhLPSCsqunXxRcVOWKYmtGMoQkzivI)
  if FhLPSCsqunXxRcVOWKYmtGMoQkzilU(FhLPSCsqunXxRcVOWKYmtGMoQkziAf)>1:
   for FhLPSCsqunXxRcVOWKYmtGMoQkziAp in FhLPSCsqunXxRcVOWKYmtGMoQkziAf:
    FhLPSCsqunXxRcVOWKYmtGMoQkziAy=FhLPSCsqunXxRcVOWKYmtGMoQkziAp.get('seasonId')
    FhLPSCsqunXxRcVOWKYmtGMoQkziAD=FhLPSCsqunXxRcVOWKYmtGMoQkziAp.get('seasonNm')
    FhLPSCsqunXxRcVOWKYmtGMoQkziAJ={'mediatype':'tvshow','title':FhLPSCsqunXxRcVOWKYmtGMoQkziAD,}
    FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'EPISODE','movie_code':FhLPSCsqunXxRcVOWKYmtGMoQkziAy,'page':'1','season_code':FhLPSCsqunXxRcVOWKYmtGMoQkziAy,'title':FhLPSCsqunXxRcVOWKYmtGMoQkziAD,'thumbnail':FhLPSCsqunXxRcVOWKYmtGMoQkzivl,}
    FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkziAD,sublabel=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,img=FhLPSCsqunXxRcVOWKYmtGMoQkzivl,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkziAJ,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilw,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr,ContextMenu=FhLPSCsqunXxRcVOWKYmtGMoQkzilB)
   xbmcplugin.setContent(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,cacheToDisc=FhLPSCsqunXxRcVOWKYmtGMoQkzilb)
  else:
   FhLPSCsqunXxRcVOWKYmtGMoQkziAH={'movie_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivI,'page':'1','season_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivI,}
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Episode_List(FhLPSCsqunXxRcVOWKYmtGMoQkziAH)
 def dp_Episode_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkziAI=args.get('movie_code')
  FhLPSCsqunXxRcVOWKYmtGMoQkzivT =FhLPSCsqunXxRcVOWKYmtGMoQkzilA(args.get('page'))
  FhLPSCsqunXxRcVOWKYmtGMoQkzivI =args.get('season_code')
  FhLPSCsqunXxRcVOWKYmtGMoQkziBI,FhLPSCsqunXxRcVOWKYmtGMoQkziAe=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.GetEpisodoList(FhLPSCsqunXxRcVOWKYmtGMoQkziAI,FhLPSCsqunXxRcVOWKYmtGMoQkzivT,orderby=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_winEpisodeOrderby())
  for FhLPSCsqunXxRcVOWKYmtGMoQkziAd in FhLPSCsqunXxRcVOWKYmtGMoQkziBI:
   FhLPSCsqunXxRcVOWKYmtGMoQkzivH =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('code')
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('title')
   FhLPSCsqunXxRcVOWKYmtGMoQkzivl =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('thumbnail')
   FhLPSCsqunXxRcVOWKYmtGMoQkziwe =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('display_num')
   FhLPSCsqunXxRcVOWKYmtGMoQkziwd =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('season_title')
   FhLPSCsqunXxRcVOWKYmtGMoQkziwv=FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('episode_number')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAg =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('duration')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAJ={'mediatype':'episode','tvshowtitle':FhLPSCsqunXxRcVOWKYmtGMoQkzidU if FhLPSCsqunXxRcVOWKYmtGMoQkzidU!='' else FhLPSCsqunXxRcVOWKYmtGMoQkziwd,'title':'%s %s'%(FhLPSCsqunXxRcVOWKYmtGMoQkziwd,FhLPSCsqunXxRcVOWKYmtGMoQkziwe)if FhLPSCsqunXxRcVOWKYmtGMoQkzidU!='' else FhLPSCsqunXxRcVOWKYmtGMoQkziwe,'episode':FhLPSCsqunXxRcVOWKYmtGMoQkziwv,'duration':FhLPSCsqunXxRcVOWKYmtGMoQkziAg,'plot':'%s\n%s\n\n%s'%(FhLPSCsqunXxRcVOWKYmtGMoQkziwd,FhLPSCsqunXxRcVOWKYmtGMoQkziwe,FhLPSCsqunXxRcVOWKYmtGMoQkzidU)}
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU='(%s) %s'%(FhLPSCsqunXxRcVOWKYmtGMoQkziwe,FhLPSCsqunXxRcVOWKYmtGMoQkzidU)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'MOVIE','movie_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivH,'season_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivI,'title':'%s < %s >'%(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,FhLPSCsqunXxRcVOWKYmtGMoQkziwd),'thumbnail':FhLPSCsqunXxRcVOWKYmtGMoQkzivl}
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel=FhLPSCsqunXxRcVOWKYmtGMoQkziwd,img=FhLPSCsqunXxRcVOWKYmtGMoQkzivl,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkziAJ,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilb,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr)
  if FhLPSCsqunXxRcVOWKYmtGMoQkzivT==1:
   FhLPSCsqunXxRcVOWKYmtGMoQkziAJ={'plot':'정렬순서를 변경합니다.'}
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={}
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['mode'] ='ORDER_BY' 
   if FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_winEpisodeOrderby()=='desc':
    FhLPSCsqunXxRcVOWKYmtGMoQkzidU='정렬순서변경 : 최신화부터 -> 1회부터'
    FhLPSCsqunXxRcVOWKYmtGMoQkzidr['orderby']='asc'
   else:
    FhLPSCsqunXxRcVOWKYmtGMoQkzidU='정렬순서변경 : 1회부터 -> 최신화부터'
    FhLPSCsqunXxRcVOWKYmtGMoQkzidr['orderby']='desc'
   FhLPSCsqunXxRcVOWKYmtGMoQkzidj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel='',img=FhLPSCsqunXxRcVOWKYmtGMoQkzidj,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkziAJ,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilb,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr,isLink=FhLPSCsqunXxRcVOWKYmtGMoQkzilw)
  if FhLPSCsqunXxRcVOWKYmtGMoQkziAe:
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['mode'] ='EPISODE' 
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['movie_code']=FhLPSCsqunXxRcVOWKYmtGMoQkziAI
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['page'] =FhLPSCsqunXxRcVOWKYmtGMoQkzilJ(FhLPSCsqunXxRcVOWKYmtGMoQkzivT+1)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU='[B]%s >>[/B]'%'다음 페이지'
   FhLPSCsqunXxRcVOWKYmtGMoQkzivD=FhLPSCsqunXxRcVOWKYmtGMoQkzilJ(FhLPSCsqunXxRcVOWKYmtGMoQkzivT+1)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel=FhLPSCsqunXxRcVOWKYmtGMoQkzivD,img=FhLPSCsqunXxRcVOWKYmtGMoQkzidj,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilw,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr)
  xbmcplugin.setContent(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,'episodes')
  if FhLPSCsqunXxRcVOWKYmtGMoQkzilU(FhLPSCsqunXxRcVOWKYmtGMoQkziBI)>0:xbmcplugin.endOfDirectory(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,cacheToDisc=FhLPSCsqunXxRcVOWKYmtGMoQkzilw)
 def dp_Search_History(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkziwB=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.Load_List_File('search')
  for FhLPSCsqunXxRcVOWKYmtGMoQkziwA in FhLPSCsqunXxRcVOWKYmtGMoQkziwB:
   FhLPSCsqunXxRcVOWKYmtGMoQkziwb=FhLPSCsqunXxRcVOWKYmtGMoQkzilE(urllib.parse.parse_qsl(FhLPSCsqunXxRcVOWKYmtGMoQkziwA))
   FhLPSCsqunXxRcVOWKYmtGMoQkziwl=FhLPSCsqunXxRcVOWKYmtGMoQkziwb.get('skey').strip()
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'LOCAL_SEARCH','search_key':FhLPSCsqunXxRcVOWKYmtGMoQkziwl,'page':'1','historyyn':'Y',}
   FhLPSCsqunXxRcVOWKYmtGMoQkziwg={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':FhLPSCsqunXxRcVOWKYmtGMoQkziwl,'vType':'-',}
   FhLPSCsqunXxRcVOWKYmtGMoQkziwE=urllib.parse.urlencode(FhLPSCsqunXxRcVOWKYmtGMoQkziwg)
   FhLPSCsqunXxRcVOWKYmtGMoQkziAj=[('선택된 검색어 ( %s ) 삭제'%(FhLPSCsqunXxRcVOWKYmtGMoQkziwl),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(FhLPSCsqunXxRcVOWKYmtGMoQkziwE))]
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkziwl,sublabel='',img=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilw,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr,ContextMenu=FhLPSCsqunXxRcVOWKYmtGMoQkziAj)
  FhLPSCsqunXxRcVOWKYmtGMoQkziAJ={'plot':'검색목록 전체를 삭제합니다.'}
  FhLPSCsqunXxRcVOWKYmtGMoQkzidU='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  FhLPSCsqunXxRcVOWKYmtGMoQkzidj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel='',img=FhLPSCsqunXxRcVOWKYmtGMoQkzidj,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkziAJ,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilb,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr,isLink=FhLPSCsqunXxRcVOWKYmtGMoQkzilw)
  xbmcplugin.endOfDirectory(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,cacheToDisc=FhLPSCsqunXxRcVOWKYmtGMoQkzilb)
 def dp_Search_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkzivT =FhLPSCsqunXxRcVOWKYmtGMoQkzilA(args.get('page'))
  if 'search_key' in args:
   FhLPSCsqunXxRcVOWKYmtGMoQkziwU=args.get('search_key')
  else:
   FhLPSCsqunXxRcVOWKYmtGMoQkziwU=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not FhLPSCsqunXxRcVOWKYmtGMoQkziwU:
    return
  FhLPSCsqunXxRcVOWKYmtGMoQkziBI,FhLPSCsqunXxRcVOWKYmtGMoQkziAe=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.GetSearchList(FhLPSCsqunXxRcVOWKYmtGMoQkziwU,FhLPSCsqunXxRcVOWKYmtGMoQkzivT)
  for FhLPSCsqunXxRcVOWKYmtGMoQkziAd in FhLPSCsqunXxRcVOWKYmtGMoQkziBI:
   FhLPSCsqunXxRcVOWKYmtGMoQkzivH =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('code')
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('title')
   FhLPSCsqunXxRcVOWKYmtGMoQkzivw=FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('content_type')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAv =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('story')
   FhLPSCsqunXxRcVOWKYmtGMoQkzivl =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('thumbnail')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAB =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('year')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAw =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('film_rating_code')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAb=FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('film_rating_short')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAl =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('film_rating_long')
   FhLPSCsqunXxRcVOWKYmtGMoQkziAg =FhLPSCsqunXxRcVOWKYmtGMoQkziAd.get('duration')
   if FhLPSCsqunXxRcVOWKYmtGMoQkzivw=='movies': 
    FhLPSCsqunXxRcVOWKYmtGMoQkzidN =FhLPSCsqunXxRcVOWKYmtGMoQkzilb
    FhLPSCsqunXxRcVOWKYmtGMoQkziAU ='MOVIE'
    FhLPSCsqunXxRcVOWKYmtGMoQkzidf =''
    FhLPSCsqunXxRcVOWKYmtGMoQkzivI='-'
    FhLPSCsqunXxRcVOWKYmtGMoQkziAT ='movie'
   else: 
    FhLPSCsqunXxRcVOWKYmtGMoQkzidN =FhLPSCsqunXxRcVOWKYmtGMoQkzilw
    FhLPSCsqunXxRcVOWKYmtGMoQkziAU ='SEASON'
    FhLPSCsqunXxRcVOWKYmtGMoQkzidf ='' 
    FhLPSCsqunXxRcVOWKYmtGMoQkzivI=FhLPSCsqunXxRcVOWKYmtGMoQkzivH
    FhLPSCsqunXxRcVOWKYmtGMoQkziAT ='tvshow' 
   FhLPSCsqunXxRcVOWKYmtGMoQkziAJ={'mediatype':FhLPSCsqunXxRcVOWKYmtGMoQkziAT,'mpaa':FhLPSCsqunXxRcVOWKYmtGMoQkziAl,'title':FhLPSCsqunXxRcVOWKYmtGMoQkzidU,'year':FhLPSCsqunXxRcVOWKYmtGMoQkziAB,'duration':FhLPSCsqunXxRcVOWKYmtGMoQkziAg,'plot':FhLPSCsqunXxRcVOWKYmtGMoQkziAv}
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU+='  (%s)'%(FhLPSCsqunXxRcVOWKYmtGMoQkziAB)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':FhLPSCsqunXxRcVOWKYmtGMoQkziAU,'movie_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivH,'page':'1','season_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivI,'title':FhLPSCsqunXxRcVOWKYmtGMoQkzidU,'thumbnail':FhLPSCsqunXxRcVOWKYmtGMoQkzivl}
   if FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_settings_makebookmark():
    FhLPSCsqunXxRcVOWKYmtGMoQkziAr={'videoid':FhLPSCsqunXxRcVOWKYmtGMoQkzivH,'vidtype':'tvshow' if FhLPSCsqunXxRcVOWKYmtGMoQkzivw=='tv_seasons' else 'movie','vtitle':FhLPSCsqunXxRcVOWKYmtGMoQkzidU,'vsubtitle':'',}
    FhLPSCsqunXxRcVOWKYmtGMoQkziAN=json.dumps(FhLPSCsqunXxRcVOWKYmtGMoQkziAr)
    FhLPSCsqunXxRcVOWKYmtGMoQkziAN=urllib.parse.quote(FhLPSCsqunXxRcVOWKYmtGMoQkziAN)
    FhLPSCsqunXxRcVOWKYmtGMoQkziAa='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(FhLPSCsqunXxRcVOWKYmtGMoQkziAN)
    FhLPSCsqunXxRcVOWKYmtGMoQkziAj=[('(통합) 찜 영상에 추가',FhLPSCsqunXxRcVOWKYmtGMoQkziAa)]
   else:
    FhLPSCsqunXxRcVOWKYmtGMoQkziAj=FhLPSCsqunXxRcVOWKYmtGMoQkzilB
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel=FhLPSCsqunXxRcVOWKYmtGMoQkzidf,img=FhLPSCsqunXxRcVOWKYmtGMoQkzivl,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkziAJ,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzidN,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr,ContextMenu=FhLPSCsqunXxRcVOWKYmtGMoQkziAj)
  if FhLPSCsqunXxRcVOWKYmtGMoQkziAe:
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={}
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['mode'] ='SEARCH'
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['search_key']=FhLPSCsqunXxRcVOWKYmtGMoQkziwU
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr['page'] =FhLPSCsqunXxRcVOWKYmtGMoQkzilJ(FhLPSCsqunXxRcVOWKYmtGMoQkzivT+1)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU='[B]%s >>[/B]'%'다음 페이지'
   FhLPSCsqunXxRcVOWKYmtGMoQkzivD=FhLPSCsqunXxRcVOWKYmtGMoQkzilJ(FhLPSCsqunXxRcVOWKYmtGMoQkzivT+1)
   FhLPSCsqunXxRcVOWKYmtGMoQkzidj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel=FhLPSCsqunXxRcVOWKYmtGMoQkzivD,img=FhLPSCsqunXxRcVOWKYmtGMoQkzidj,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilw,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr)
  xbmcplugin.setContent(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,'movies')
  xbmcplugin.endOfDirectory(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,cacheToDisc=FhLPSCsqunXxRcVOWKYmtGMoQkzilw)
  if args.get('historyyn')=='Y':FhLPSCsqunXxRcVOWKYmtGMoQkzieU.Save_Searched_List(FhLPSCsqunXxRcVOWKYmtGMoQkziwU)
 def dp_Delete_Continue(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkziwT=urllib.parse.unquote(args.get('bm_param'))
  FhLPSCsqunXxRcVOWKYmtGMoQkziwT=FhLPSCsqunXxRcVOWKYmtGMoQkziwT.replace('\'','"')
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.addon_log(FhLPSCsqunXxRcVOWKYmtGMoQkziwT)
  FhLPSCsqunXxRcVOWKYmtGMoQkziwT=json.loads(FhLPSCsqunXxRcVOWKYmtGMoQkziwT)
  FhLPSCsqunXxRcVOWKYmtGMoQkziBH=FhLPSCsqunXxRcVOWKYmtGMoQkziwT.get('codeList')
  FhLPSCsqunXxRcVOWKYmtGMoQkzieN=xbmcgui.Dialog()
  FhLPSCsqunXxRcVOWKYmtGMoQkzidH=FhLPSCsqunXxRcVOWKYmtGMoQkzieN.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if FhLPSCsqunXxRcVOWKYmtGMoQkzidH==FhLPSCsqunXxRcVOWKYmtGMoQkzilb:sys.exit()
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.DeleteContinueList(FhLPSCsqunXxRcVOWKYmtGMoQkziBH)
  xbmc.executebuiltin("Container.Refresh")
 def dp_History_Remove(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkziwJ=args.get('delType')
  FhLPSCsqunXxRcVOWKYmtGMoQkziwj =args.get('sKey')
  FhLPSCsqunXxRcVOWKYmtGMoQkziwr =args.get('vType')
  FhLPSCsqunXxRcVOWKYmtGMoQkzieN=xbmcgui.Dialog()
  if FhLPSCsqunXxRcVOWKYmtGMoQkziwJ=='SEARCH_ALL':
   FhLPSCsqunXxRcVOWKYmtGMoQkzidH=FhLPSCsqunXxRcVOWKYmtGMoQkzieN.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif FhLPSCsqunXxRcVOWKYmtGMoQkziwJ=='SEARCH_ONE':
   FhLPSCsqunXxRcVOWKYmtGMoQkzidH=FhLPSCsqunXxRcVOWKYmtGMoQkzieN.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif FhLPSCsqunXxRcVOWKYmtGMoQkziwJ=='WATCH_ALL':
   FhLPSCsqunXxRcVOWKYmtGMoQkzidH=FhLPSCsqunXxRcVOWKYmtGMoQkzieN.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif FhLPSCsqunXxRcVOWKYmtGMoQkziwJ=='WATCH_ONE':
   FhLPSCsqunXxRcVOWKYmtGMoQkzidH=FhLPSCsqunXxRcVOWKYmtGMoQkzieN.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if FhLPSCsqunXxRcVOWKYmtGMoQkzidH==FhLPSCsqunXxRcVOWKYmtGMoQkzilb:sys.exit()
  if FhLPSCsqunXxRcVOWKYmtGMoQkziwJ=='SEARCH_ALL':
   if os.path.isfile(FhLPSCsqunXxRcVOWKYmtGMoQkzieE):os.remove(FhLPSCsqunXxRcVOWKYmtGMoQkzieE)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkziwJ=='SEARCH_ONE':
   try:
    FhLPSCsqunXxRcVOWKYmtGMoQkziwN=FhLPSCsqunXxRcVOWKYmtGMoQkzieE
    FhLPSCsqunXxRcVOWKYmtGMoQkziwa=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.Load_List_File('search') 
    fp=FhLPSCsqunXxRcVOWKYmtGMoQkzilj(FhLPSCsqunXxRcVOWKYmtGMoQkziwN,'w',-1,'utf-8')
    for FhLPSCsqunXxRcVOWKYmtGMoQkziwf in FhLPSCsqunXxRcVOWKYmtGMoQkziwa:
     FhLPSCsqunXxRcVOWKYmtGMoQkziwp=FhLPSCsqunXxRcVOWKYmtGMoQkzilE(urllib.parse.parse_qsl(FhLPSCsqunXxRcVOWKYmtGMoQkziwf))
     FhLPSCsqunXxRcVOWKYmtGMoQkziwy=FhLPSCsqunXxRcVOWKYmtGMoQkziwp.get('skey').strip()
     if FhLPSCsqunXxRcVOWKYmtGMoQkziwj!=FhLPSCsqunXxRcVOWKYmtGMoQkziwy:
      fp.write(FhLPSCsqunXxRcVOWKYmtGMoQkziwf)
    fp.close()
   except:
    FhLPSCsqunXxRcVOWKYmtGMoQkzilB
  elif FhLPSCsqunXxRcVOWKYmtGMoQkziwJ=='WATCH_ALL':
   FhLPSCsqunXxRcVOWKYmtGMoQkziwN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FhLPSCsqunXxRcVOWKYmtGMoQkziwr))
   if os.path.isfile(FhLPSCsqunXxRcVOWKYmtGMoQkziwN):os.remove(FhLPSCsqunXxRcVOWKYmtGMoQkziwN)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkziwJ=='WATCH_ONE':
   FhLPSCsqunXxRcVOWKYmtGMoQkziwN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FhLPSCsqunXxRcVOWKYmtGMoQkziwr))
   try:
    FhLPSCsqunXxRcVOWKYmtGMoQkziwa=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.Load_List_File(FhLPSCsqunXxRcVOWKYmtGMoQkziwr) 
    fp=FhLPSCsqunXxRcVOWKYmtGMoQkzilj(FhLPSCsqunXxRcVOWKYmtGMoQkziwN,'w',-1,'utf-8')
    for FhLPSCsqunXxRcVOWKYmtGMoQkziwf in FhLPSCsqunXxRcVOWKYmtGMoQkziwa:
     FhLPSCsqunXxRcVOWKYmtGMoQkziwp=FhLPSCsqunXxRcVOWKYmtGMoQkzilE(urllib.parse.parse_qsl(FhLPSCsqunXxRcVOWKYmtGMoQkziwf))
     FhLPSCsqunXxRcVOWKYmtGMoQkziwy=FhLPSCsqunXxRcVOWKYmtGMoQkziwp.get('code').strip()
     if FhLPSCsqunXxRcVOWKYmtGMoQkziwj!=FhLPSCsqunXxRcVOWKYmtGMoQkziwy:
      fp.write(FhLPSCsqunXxRcVOWKYmtGMoQkziwf)
    fp.close()
   except:
    FhLPSCsqunXxRcVOWKYmtGMoQkzilB
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,FhLPSCsqunXxRcVOWKYmtGMoQkzivU): 
  try:
   if FhLPSCsqunXxRcVOWKYmtGMoQkzivU=='search':
    FhLPSCsqunXxRcVOWKYmtGMoQkziwN=FhLPSCsqunXxRcVOWKYmtGMoQkzieE
   elif FhLPSCsqunXxRcVOWKYmtGMoQkzivU in['seasons','movie']:
    FhLPSCsqunXxRcVOWKYmtGMoQkziwN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FhLPSCsqunXxRcVOWKYmtGMoQkzivU))
   else:
    return[]
   fp=FhLPSCsqunXxRcVOWKYmtGMoQkzilj(FhLPSCsqunXxRcVOWKYmtGMoQkziwN,'r',-1,'utf-8')
   FhLPSCsqunXxRcVOWKYmtGMoQkziwD=fp.readlines()
   fp.close()
  except:
   FhLPSCsqunXxRcVOWKYmtGMoQkziwD=[]
  return FhLPSCsqunXxRcVOWKYmtGMoQkziwD
 def Save_Watched_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,FhLPSCsqunXxRcVOWKYmtGMoQkzivU,FhLPSCsqunXxRcVOWKYmtGMoQkziej):
  try:
   FhLPSCsqunXxRcVOWKYmtGMoQkziwH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FhLPSCsqunXxRcVOWKYmtGMoQkzivU))
   FhLPSCsqunXxRcVOWKYmtGMoQkziwa=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.Load_List_File(FhLPSCsqunXxRcVOWKYmtGMoQkzivU) 
   fp=FhLPSCsqunXxRcVOWKYmtGMoQkzilj(FhLPSCsqunXxRcVOWKYmtGMoQkziwH,'w',-1,'utf-8')
   FhLPSCsqunXxRcVOWKYmtGMoQkziwI=urllib.parse.urlencode(FhLPSCsqunXxRcVOWKYmtGMoQkziej)
   FhLPSCsqunXxRcVOWKYmtGMoQkziwI=FhLPSCsqunXxRcVOWKYmtGMoQkziwI+'\n'
   fp.write(FhLPSCsqunXxRcVOWKYmtGMoQkziwI)
   FhLPSCsqunXxRcVOWKYmtGMoQkzibe=0
   for FhLPSCsqunXxRcVOWKYmtGMoQkziwf in FhLPSCsqunXxRcVOWKYmtGMoQkziwa:
    FhLPSCsqunXxRcVOWKYmtGMoQkziwp=FhLPSCsqunXxRcVOWKYmtGMoQkzilE(urllib.parse.parse_qsl(FhLPSCsqunXxRcVOWKYmtGMoQkziwf))
    FhLPSCsqunXxRcVOWKYmtGMoQkzibd=FhLPSCsqunXxRcVOWKYmtGMoQkziej.get('code').strip()
    FhLPSCsqunXxRcVOWKYmtGMoQkzibv=FhLPSCsqunXxRcVOWKYmtGMoQkziwp.get('code').strip()
    if FhLPSCsqunXxRcVOWKYmtGMoQkzivU=='seasons' and FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_settings_direct_replay()==FhLPSCsqunXxRcVOWKYmtGMoQkzilw:
     FhLPSCsqunXxRcVOWKYmtGMoQkzibd=FhLPSCsqunXxRcVOWKYmtGMoQkziej.get('videoid').strip()
     FhLPSCsqunXxRcVOWKYmtGMoQkzibv=FhLPSCsqunXxRcVOWKYmtGMoQkziwp.get('videoid').strip()if FhLPSCsqunXxRcVOWKYmtGMoQkzibv!=FhLPSCsqunXxRcVOWKYmtGMoQkzilB else '-'
    if FhLPSCsqunXxRcVOWKYmtGMoQkzibd!=FhLPSCsqunXxRcVOWKYmtGMoQkzibv:
     fp.write(FhLPSCsqunXxRcVOWKYmtGMoQkziwf)
     FhLPSCsqunXxRcVOWKYmtGMoQkzibe+=1
     if FhLPSCsqunXxRcVOWKYmtGMoQkzibe>=50:break
   fp.close()
  except:
   FhLPSCsqunXxRcVOWKYmtGMoQkzilB
 def dp_Watch_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkzivU =args.get('stype')
  FhLPSCsqunXxRcVOWKYmtGMoQkzidl=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_settings_direct_replay()
  if FhLPSCsqunXxRcVOWKYmtGMoQkzivU=='-':
   for FhLPSCsqunXxRcVOWKYmtGMoQkzibB in FhLPSCsqunXxRcVOWKYmtGMoQkzieB:
    FhLPSCsqunXxRcVOWKYmtGMoQkzidU=FhLPSCsqunXxRcVOWKYmtGMoQkzibB.get('title')
    FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':FhLPSCsqunXxRcVOWKYmtGMoQkzibB.get('mode'),'stype':FhLPSCsqunXxRcVOWKYmtGMoQkzibB.get('stype')}
    FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel='',img='',infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkzilB,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilw,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr)
   if FhLPSCsqunXxRcVOWKYmtGMoQkzilU(FhLPSCsqunXxRcVOWKYmtGMoQkzieB)>0:xbmcplugin.endOfDirectory(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle)
  else:
   FhLPSCsqunXxRcVOWKYmtGMoQkzibA=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.Load_List_File(FhLPSCsqunXxRcVOWKYmtGMoQkzivU)
   for FhLPSCsqunXxRcVOWKYmtGMoQkzibw in FhLPSCsqunXxRcVOWKYmtGMoQkzibA:
    FhLPSCsqunXxRcVOWKYmtGMoQkziwb=FhLPSCsqunXxRcVOWKYmtGMoQkzilE(urllib.parse.parse_qsl(FhLPSCsqunXxRcVOWKYmtGMoQkzibw))
    FhLPSCsqunXxRcVOWKYmtGMoQkzivH=FhLPSCsqunXxRcVOWKYmtGMoQkziwb.get('code').strip()
    FhLPSCsqunXxRcVOWKYmtGMoQkzidU =FhLPSCsqunXxRcVOWKYmtGMoQkziwb.get('title').strip()
    FhLPSCsqunXxRcVOWKYmtGMoQkzivl =FhLPSCsqunXxRcVOWKYmtGMoQkziwb.get('img').strip()
    FhLPSCsqunXxRcVOWKYmtGMoQkzibl =FhLPSCsqunXxRcVOWKYmtGMoQkziwb.get('videoid').strip()
    try:
     FhLPSCsqunXxRcVOWKYmtGMoQkzivl=FhLPSCsqunXxRcVOWKYmtGMoQkzivl.replace('\'','\"')
     FhLPSCsqunXxRcVOWKYmtGMoQkzivl=json.loads(FhLPSCsqunXxRcVOWKYmtGMoQkzivl)
    except:
     FhLPSCsqunXxRcVOWKYmtGMoQkzilB
    FhLPSCsqunXxRcVOWKYmtGMoQkziAJ={}
    FhLPSCsqunXxRcVOWKYmtGMoQkziAJ['plot']=FhLPSCsqunXxRcVOWKYmtGMoQkzidU
    if FhLPSCsqunXxRcVOWKYmtGMoQkzivU=='movie':
     FhLPSCsqunXxRcVOWKYmtGMoQkziAJ['mediatype']='movie'
     FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'MOVIE','page':'1','movie_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivH,'season_code':'-','title':FhLPSCsqunXxRcVOWKYmtGMoQkzidU,'thumbnail':FhLPSCsqunXxRcVOWKYmtGMoQkzivl}
     FhLPSCsqunXxRcVOWKYmtGMoQkzidN=FhLPSCsqunXxRcVOWKYmtGMoQkzilb
    else:
     if FhLPSCsqunXxRcVOWKYmtGMoQkzidl==FhLPSCsqunXxRcVOWKYmtGMoQkzilb or FhLPSCsqunXxRcVOWKYmtGMoQkzibl==FhLPSCsqunXxRcVOWKYmtGMoQkzilB:
      FhLPSCsqunXxRcVOWKYmtGMoQkziAJ['mediatype']='tvshow'
      FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'EPISODE','page':'1','movie_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivH,'season_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivH,'title':FhLPSCsqunXxRcVOWKYmtGMoQkzidU,'thumbnail':FhLPSCsqunXxRcVOWKYmtGMoQkzivl}
      FhLPSCsqunXxRcVOWKYmtGMoQkzidN=FhLPSCsqunXxRcVOWKYmtGMoQkzilw
     else:
      FhLPSCsqunXxRcVOWKYmtGMoQkziAJ['mediatype']='episode'
      FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'MOVIE','movie_code':FhLPSCsqunXxRcVOWKYmtGMoQkzibl,'season_code':FhLPSCsqunXxRcVOWKYmtGMoQkzivH,'title':FhLPSCsqunXxRcVOWKYmtGMoQkzidU,'thumbnail':FhLPSCsqunXxRcVOWKYmtGMoQkzivl}
      FhLPSCsqunXxRcVOWKYmtGMoQkzidN=FhLPSCsqunXxRcVOWKYmtGMoQkzilb
    FhLPSCsqunXxRcVOWKYmtGMoQkziwg={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':FhLPSCsqunXxRcVOWKYmtGMoQkzivH,'vType':FhLPSCsqunXxRcVOWKYmtGMoQkzivU,}
    FhLPSCsqunXxRcVOWKYmtGMoQkziwE=urllib.parse.urlencode(FhLPSCsqunXxRcVOWKYmtGMoQkziwg)
    FhLPSCsqunXxRcVOWKYmtGMoQkziAj=[('선택된 시청이력 ( %s ) 삭제'%(FhLPSCsqunXxRcVOWKYmtGMoQkzidU),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(FhLPSCsqunXxRcVOWKYmtGMoQkziwE))]
    FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel='',img=FhLPSCsqunXxRcVOWKYmtGMoQkzivl,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkziAJ,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzidN,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr,ContextMenu=FhLPSCsqunXxRcVOWKYmtGMoQkziAj)
   FhLPSCsqunXxRcVOWKYmtGMoQkziAJ={'plot':'시청목록을 삭제합니다.'}
   FhLPSCsqunXxRcVOWKYmtGMoQkzidU='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   FhLPSCsqunXxRcVOWKYmtGMoQkzidr={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':FhLPSCsqunXxRcVOWKYmtGMoQkzivU,}
   FhLPSCsqunXxRcVOWKYmtGMoQkzidj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.add_dir(FhLPSCsqunXxRcVOWKYmtGMoQkzidU,sublabel='',img=FhLPSCsqunXxRcVOWKYmtGMoQkzidj,infoLabels=FhLPSCsqunXxRcVOWKYmtGMoQkziAJ,isFolder=FhLPSCsqunXxRcVOWKYmtGMoQkzilb,params=FhLPSCsqunXxRcVOWKYmtGMoQkzidr,isLink=FhLPSCsqunXxRcVOWKYmtGMoQkzilw)
   if FhLPSCsqunXxRcVOWKYmtGMoQkzivU=='movie':xbmcplugin.setContent(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,'movies')
   else:xbmcplugin.setContent(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(FhLPSCsqunXxRcVOWKYmtGMoQkzieU._addon_handle,cacheToDisc=FhLPSCsqunXxRcVOWKYmtGMoQkzilb)
 def Save_Searched_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,FhLPSCsqunXxRcVOWKYmtGMoQkziwU):
  try:
   FhLPSCsqunXxRcVOWKYmtGMoQkzibg=FhLPSCsqunXxRcVOWKYmtGMoQkzieE
   FhLPSCsqunXxRcVOWKYmtGMoQkziwa=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.Load_List_File('search') 
   FhLPSCsqunXxRcVOWKYmtGMoQkzibE={'skey':FhLPSCsqunXxRcVOWKYmtGMoQkziwU.strip()}
   fp=FhLPSCsqunXxRcVOWKYmtGMoQkzilj(FhLPSCsqunXxRcVOWKYmtGMoQkzibg,'w',-1,'utf-8')
   FhLPSCsqunXxRcVOWKYmtGMoQkziwI=urllib.parse.urlencode(FhLPSCsqunXxRcVOWKYmtGMoQkzibE)
   FhLPSCsqunXxRcVOWKYmtGMoQkziwI=FhLPSCsqunXxRcVOWKYmtGMoQkziwI+'\n'
   fp.write(FhLPSCsqunXxRcVOWKYmtGMoQkziwI)
   FhLPSCsqunXxRcVOWKYmtGMoQkzibe=0
   for FhLPSCsqunXxRcVOWKYmtGMoQkziwf in FhLPSCsqunXxRcVOWKYmtGMoQkziwa:
    FhLPSCsqunXxRcVOWKYmtGMoQkziwp=FhLPSCsqunXxRcVOWKYmtGMoQkzilE(urllib.parse.parse_qsl(FhLPSCsqunXxRcVOWKYmtGMoQkziwf))
    FhLPSCsqunXxRcVOWKYmtGMoQkzibd=FhLPSCsqunXxRcVOWKYmtGMoQkzibE.get('skey').strip()
    FhLPSCsqunXxRcVOWKYmtGMoQkzibv=FhLPSCsqunXxRcVOWKYmtGMoQkziwp.get('skey').strip()
    if FhLPSCsqunXxRcVOWKYmtGMoQkzibd!=FhLPSCsqunXxRcVOWKYmtGMoQkzibv:
     fp.write(FhLPSCsqunXxRcVOWKYmtGMoQkziwf)
     FhLPSCsqunXxRcVOWKYmtGMoQkzibe+=1
     if FhLPSCsqunXxRcVOWKYmtGMoQkzibe>=50:break
   fp.close()
  except:
   FhLPSCsqunXxRcVOWKYmtGMoQkzilB
 def logout(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  FhLPSCsqunXxRcVOWKYmtGMoQkzieN=xbmcgui.Dialog()
  FhLPSCsqunXxRcVOWKYmtGMoQkzidH=FhLPSCsqunXxRcVOWKYmtGMoQkzieN.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if FhLPSCsqunXxRcVOWKYmtGMoQkzidH==FhLPSCsqunXxRcVOWKYmtGMoQkzilb:sys.exit()
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.Init_WC_Total()
  if os.path.isfile(FhLPSCsqunXxRcVOWKYmtGMoQkzieg):os.remove(FhLPSCsqunXxRcVOWKYmtGMoQkzieg)
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  FhLPSCsqunXxRcVOWKYmtGMoQkzibU =FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.Get_Now_Datetime()
  FhLPSCsqunXxRcVOWKYmtGMoQkzibT=FhLPSCsqunXxRcVOWKYmtGMoQkzibU+datetime.timedelta(days=FhLPSCsqunXxRcVOWKYmtGMoQkzilA(__addon__.getSetting('cache_ttl')))
  (FhLPSCsqunXxRcVOWKYmtGMoQkzidp,FhLPSCsqunXxRcVOWKYmtGMoQkzidy,FhLPSCsqunXxRcVOWKYmtGMoQkzidD)=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_settings_account()
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.Save_session_acount(FhLPSCsqunXxRcVOWKYmtGMoQkzidp,FhLPSCsqunXxRcVOWKYmtGMoQkzidy,FhLPSCsqunXxRcVOWKYmtGMoQkzidD)
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.WC['account']['token_limit']=FhLPSCsqunXxRcVOWKYmtGMoQkzibT.strftime('%Y%m%d')
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.JsonFile_Save(FhLPSCsqunXxRcVOWKYmtGMoQkzieg,FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.WC)
 def cookiefile_check(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.WC=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.JsonFile_Load(FhLPSCsqunXxRcVOWKYmtGMoQkzieg)
  if 'account' not in FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.WC:
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.Init_WC_Total()
   return FhLPSCsqunXxRcVOWKYmtGMoQkzilb
  (FhLPSCsqunXxRcVOWKYmtGMoQkzibJ,FhLPSCsqunXxRcVOWKYmtGMoQkzibj,FhLPSCsqunXxRcVOWKYmtGMoQkzibr)=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.get_settings_account()
  (FhLPSCsqunXxRcVOWKYmtGMoQkzibN,FhLPSCsqunXxRcVOWKYmtGMoQkziba,FhLPSCsqunXxRcVOWKYmtGMoQkzibf)=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.Load_session_acount()
  if FhLPSCsqunXxRcVOWKYmtGMoQkzibJ!=FhLPSCsqunXxRcVOWKYmtGMoQkzibN or FhLPSCsqunXxRcVOWKYmtGMoQkzibj!=FhLPSCsqunXxRcVOWKYmtGMoQkziba or FhLPSCsqunXxRcVOWKYmtGMoQkzibr!=FhLPSCsqunXxRcVOWKYmtGMoQkzibf:
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.Init_WC_Total()
   return FhLPSCsqunXxRcVOWKYmtGMoQkzilb
  if FhLPSCsqunXxRcVOWKYmtGMoQkzilA(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))>FhLPSCsqunXxRcVOWKYmtGMoQkzilA(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.WC['account']['token_limit']):
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.Init_WC_Total()
   return FhLPSCsqunXxRcVOWKYmtGMoQkzilb
  return FhLPSCsqunXxRcVOWKYmtGMoQkzilw
 def dp_Global_Search(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkzibp=args.get('mode')
  if FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='TOTAL_SEARCH':
   FhLPSCsqunXxRcVOWKYmtGMoQkziby='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   FhLPSCsqunXxRcVOWKYmtGMoQkziby='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FhLPSCsqunXxRcVOWKYmtGMoQkziby)
 def dp_Bookmark_Menu(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkziby='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FhLPSCsqunXxRcVOWKYmtGMoQkziby)
 def dp_Set_Bookmark(FhLPSCsqunXxRcVOWKYmtGMoQkzieU,args):
  FhLPSCsqunXxRcVOWKYmtGMoQkziwT=urllib.parse.unquote(args.get('bm_param'))
  FhLPSCsqunXxRcVOWKYmtGMoQkziwT=json.loads(FhLPSCsqunXxRcVOWKYmtGMoQkziwT)
  FhLPSCsqunXxRcVOWKYmtGMoQkzibl =FhLPSCsqunXxRcVOWKYmtGMoQkziwT.get('videoid')
  FhLPSCsqunXxRcVOWKYmtGMoQkzibD =FhLPSCsqunXxRcVOWKYmtGMoQkziwT.get('vidtype')
  FhLPSCsqunXxRcVOWKYmtGMoQkzibH =FhLPSCsqunXxRcVOWKYmtGMoQkziwT.get('vtitle')
  FhLPSCsqunXxRcVOWKYmtGMoQkzibI =FhLPSCsqunXxRcVOWKYmtGMoQkziwT.get('vsubtitle')
  FhLPSCsqunXxRcVOWKYmtGMoQkzieN=xbmcgui.Dialog()
  FhLPSCsqunXxRcVOWKYmtGMoQkzidH=FhLPSCsqunXxRcVOWKYmtGMoQkzieN.yesno(__language__(30913).encode('utf8'),FhLPSCsqunXxRcVOWKYmtGMoQkzibH+' \n\n'+__language__(30914))
  if FhLPSCsqunXxRcVOWKYmtGMoQkzidH==FhLPSCsqunXxRcVOWKYmtGMoQkzilb:return
  FhLPSCsqunXxRcVOWKYmtGMoQkzile=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.WatchaObj.GetBookmarkInfo(FhLPSCsqunXxRcVOWKYmtGMoQkzibl,FhLPSCsqunXxRcVOWKYmtGMoQkzibD)
  FhLPSCsqunXxRcVOWKYmtGMoQkzild=json.dumps(FhLPSCsqunXxRcVOWKYmtGMoQkzile)
  FhLPSCsqunXxRcVOWKYmtGMoQkzild=urllib.parse.quote(FhLPSCsqunXxRcVOWKYmtGMoQkzild)
  FhLPSCsqunXxRcVOWKYmtGMoQkziAa ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(FhLPSCsqunXxRcVOWKYmtGMoQkzild)
  xbmc.executebuiltin(FhLPSCsqunXxRcVOWKYmtGMoQkziAa)
 def watcha_main(FhLPSCsqunXxRcVOWKYmtGMoQkzieU):
  FhLPSCsqunXxRcVOWKYmtGMoQkzibp=FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params.get('mode',FhLPSCsqunXxRcVOWKYmtGMoQkzilB)
  if FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='LOGOUT':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.logout()
   return
  FhLPSCsqunXxRcVOWKYmtGMoQkzieU.login_main()
  if FhLPSCsqunXxRcVOWKYmtGMoQkzibp is FhLPSCsqunXxRcVOWKYmtGMoQkzilB:
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Main_List()
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='HOME_GROUP':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_HomeGroup_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='SUB_GROUP':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_SubGroup_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='CATEGORY_LIST':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Category_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='SEASON':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Season_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='EPISODE':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Episode_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='ORDER_BY':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_setEpOrderby(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp in['SEARCH','LOCAL_SEARCH']:
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Search_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='MOVIE':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.play_VIDEO(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='WATCH':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Watch_List(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_History_Remove(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp in['TOTAL_SEARCH','TOTAL_HISTORY']:
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Global_Search(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='SEARCH_HISTORY':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Search_History(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='MENU_BOOKMARK':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Bookmark_Menu(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='SET_BOOKMARK':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Set_Bookmark(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  elif FhLPSCsqunXxRcVOWKYmtGMoQkzibp=='DELETE_CONTINUE':
   FhLPSCsqunXxRcVOWKYmtGMoQkzieU.dp_Delete_Continue(FhLPSCsqunXxRcVOWKYmtGMoQkzieU.main_params)
  else:
   FhLPSCsqunXxRcVOWKYmtGMoQkzilB
# Created by pyminifier (https://github.com/liftoff/pyminifier)
