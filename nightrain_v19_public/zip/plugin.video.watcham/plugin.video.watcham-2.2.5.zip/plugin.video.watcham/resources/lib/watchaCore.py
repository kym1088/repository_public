__author__="NightRain"
JgkWPmpxYDbLHanXUutoSFeyIcrMiE=object
JgkWPmpxYDbLHanXUutoSFeyIcrMVl=None
JgkWPmpxYDbLHanXUutoSFeyIcrMVB=False
JgkWPmpxYDbLHanXUutoSFeyIcrMVj=open
JgkWPmpxYDbLHanXUutoSFeyIcrMVi=True
JgkWPmpxYDbLHanXUutoSFeyIcrMVN=Exception
JgkWPmpxYDbLHanXUutoSFeyIcrMVT=print
JgkWPmpxYDbLHanXUutoSFeyIcrMVs=range
JgkWPmpxYDbLHanXUutoSFeyIcrMVA=len
JgkWPmpxYDbLHanXUutoSFeyIcrMVK=str
JgkWPmpxYDbLHanXUutoSFeyIcrMVf=int
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
class JgkWPmpxYDbLHanXUutoSFeyIcrMlB(JgkWPmpxYDbLHanXUutoSFeyIcrMiE):
 def __init__(JgkWPmpxYDbLHanXUutoSFeyIcrMlj):
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC ={}
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.Init_WC_Total()
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.MAIN_DOMAIN ='https://watcha.com'
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN ='https://api-mars.watcha.com'
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.EPISODE_LIMIT=20
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.SEARCH_LIMIT =30
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36'
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.DEFAULT_HEADER={'user-agent':JgkWPmpxYDbLHanXUutoSFeyIcrMlj.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.3',}
 def Init_WC_Total(JgkWPmpxYDbLHanXUutoSFeyIcrMlj):
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC={'account':{},'cookies':{'watcha_token':'','watcha_guit':'','watcha_guitv':'','watcha_usercd':'',},}
 def callRequestCookies(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,jobtype,JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,redirects=JgkWPmpxYDbLHanXUutoSFeyIcrMVB):
  JgkWPmpxYDbLHanXUutoSFeyIcrMli=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.DEFAULT_HEADER
  if headers:JgkWPmpxYDbLHanXUutoSFeyIcrMli.update(headers)
  if jobtype=='Get':
   JgkWPmpxYDbLHanXUutoSFeyIcrMlV=requests.get(JgkWPmpxYDbLHanXUutoSFeyIcrMlw,params=params,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMli,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   JgkWPmpxYDbLHanXUutoSFeyIcrMlV=requests.put(JgkWPmpxYDbLHanXUutoSFeyIcrMlw,data=payload,params=params,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMli,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Delete':
   JgkWPmpxYDbLHanXUutoSFeyIcrMlV=requests.delete(JgkWPmpxYDbLHanXUutoSFeyIcrMlw,params=params,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMli,cookies=cookies,allow_redirects=redirects)
  else:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlV=requests.post(JgkWPmpxYDbLHanXUutoSFeyIcrMlw,data=payload,params=params,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMli,cookies=cookies,allow_redirects=redirects)
  return JgkWPmpxYDbLHanXUutoSFeyIcrMlV
 def JsonFile_Save(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,filename,JgkWPmpxYDbLHanXUutoSFeyIcrMlN):
  if filename=='':return JgkWPmpxYDbLHanXUutoSFeyIcrMVB
  try:
   fp=JgkWPmpxYDbLHanXUutoSFeyIcrMVj(filename,'w',-1,'utf-8')
   json.dump(JgkWPmpxYDbLHanXUutoSFeyIcrMlN,fp,indent=4,ensure_ascii=JgkWPmpxYDbLHanXUutoSFeyIcrMVB)
   fp.close()
  except:
   return JgkWPmpxYDbLHanXUutoSFeyIcrMVB
  return JgkWPmpxYDbLHanXUutoSFeyIcrMVi
 def JsonFile_Load(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,filename):
  if filename=='':return{}
  try:
   fp=JgkWPmpxYDbLHanXUutoSFeyIcrMVj(filename,'r',-1,'utf-8')
   JgkWPmpxYDbLHanXUutoSFeyIcrMls=json.load(fp)
   fp.close()
  except:
   return{}
  return JgkWPmpxYDbLHanXUutoSFeyIcrMls
 def Save_session_acount(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,JgkWPmpxYDbLHanXUutoSFeyIcrMlA,JgkWPmpxYDbLHanXUutoSFeyIcrMlK,JgkWPmpxYDbLHanXUutoSFeyIcrMlf):
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['account']['wcid']=base64.standard_b64encode(JgkWPmpxYDbLHanXUutoSFeyIcrMlA.encode()).decode('utf-8')
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['account']['wcpw']=base64.standard_b64encode(JgkWPmpxYDbLHanXUutoSFeyIcrMlK.encode()).decode('utf-8')
  JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['account']['wcpf']=JgkWPmpxYDbLHanXUutoSFeyIcrMlf 
 def Load_session_acount(JgkWPmpxYDbLHanXUutoSFeyIcrMlj):
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlA=base64.standard_b64decode(JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['account']['wcid']).decode('utf-8')
   JgkWPmpxYDbLHanXUutoSFeyIcrMlK=base64.standard_b64decode(JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['account']['wcpw']).decode('utf-8')
   JgkWPmpxYDbLHanXUutoSFeyIcrMlf=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['account']['wcpf']
  except:
   return '','',0
  return JgkWPmpxYDbLHanXUutoSFeyIcrMlA,JgkWPmpxYDbLHanXUutoSFeyIcrMlK,JgkWPmpxYDbLHanXUutoSFeyIcrMlf
 def makeDefaultCookies(JgkWPmpxYDbLHanXUutoSFeyIcrMlj):
  JgkWPmpxYDbLHanXUutoSFeyIcrMlQ={'_s_guit':JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_guit'],'_guinness-premium_session':JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_token']}
  if JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_guitv']:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlQ['_s_guitv']=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_guitv']
  return JgkWPmpxYDbLHanXUutoSFeyIcrMlQ
 def GetCredential(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,user_id,user_pw,user_pf):
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlq=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+'/api/session'
   JgkWPmpxYDbLHanXUutoSFeyIcrMlG={'email':user_id,'password':user_pw}
   JgkWPmpxYDbLHanXUutoSFeyIcrMlO={'accept':'application/vnd.frograms+json;version=4'}
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Post',JgkWPmpxYDbLHanXUutoSFeyIcrMlq,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMlG,params=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMlO,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMVl)
   for JgkWPmpxYDbLHanXUutoSFeyIcrMld in JgkWPmpxYDbLHanXUutoSFeyIcrMlh.cookies:
    if JgkWPmpxYDbLHanXUutoSFeyIcrMld.name=='_guinness-premium_session':
     JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_token']=JgkWPmpxYDbLHanXUutoSFeyIcrMld.value
    elif JgkWPmpxYDbLHanXUutoSFeyIcrMld.name=='_s_guit':
     JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_guit']=JgkWPmpxYDbLHanXUutoSFeyIcrMld.value
   if JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_token']=='':
    JgkWPmpxYDbLHanXUutoSFeyIcrMlj.Init_WC_Total()
    return JgkWPmpxYDbLHanXUutoSFeyIcrMVB
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
   JgkWPmpxYDbLHanXUutoSFeyIcrMlj.Init_WC_Total()
   return JgkWPmpxYDbLHanXUutoSFeyIcrMVB
  if JgkWPmpxYDbLHanXUutoSFeyIcrMlj.GetProfilesList(user_pf)==JgkWPmpxYDbLHanXUutoSFeyIcrMVB:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlj.Init_WC_Total()
   return JgkWPmpxYDbLHanXUutoSFeyIcrMVB
  if user_pf!=0:
   if JgkWPmpxYDbLHanXUutoSFeyIcrMlj.GetProfilesConvert()==JgkWPmpxYDbLHanXUutoSFeyIcrMVB:
    JgkWPmpxYDbLHanXUutoSFeyIcrMlj.Init_WC_Total()
    return JgkWPmpxYDbLHanXUutoSFeyIcrMVB
  return JgkWPmpxYDbLHanXUutoSFeyIcrMVi
 def GetProfilesList(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,user_pf):
  JgkWPmpxYDbLHanXUutoSFeyIcrMlR=[]
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlC ='/manage_profiles'
   JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.MAIN_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
   JgkWPmpxYDbLHanXUutoSFeyIcrMld=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.makeDefaultCookies()
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Get',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMld,redirects=JgkWPmpxYDbLHanXUutoSFeyIcrMVi)
   JgkWPmpxYDbLHanXUutoSFeyIcrMlz=JgkWPmpxYDbLHanXUutoSFeyIcrMlh.text
   JgkWPmpxYDbLHanXUutoSFeyIcrMlv =re.findall('/api/users/me.{8000}',JgkWPmpxYDbLHanXUutoSFeyIcrMlz)[0]
   JgkWPmpxYDbLHanXUutoSFeyIcrMlv =JgkWPmpxYDbLHanXUutoSFeyIcrMlv.replace('&quot;','')
   JgkWPmpxYDbLHanXUutoSFeyIcrMlR=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',JgkWPmpxYDbLHanXUutoSFeyIcrMlv)
   for i in JgkWPmpxYDbLHanXUutoSFeyIcrMVs(JgkWPmpxYDbLHanXUutoSFeyIcrMVA(JgkWPmpxYDbLHanXUutoSFeyIcrMlR)):
    JgkWPmpxYDbLHanXUutoSFeyIcrMlE=JgkWPmpxYDbLHanXUutoSFeyIcrMlR[i]
    JgkWPmpxYDbLHanXUutoSFeyIcrMlE =JgkWPmpxYDbLHanXUutoSFeyIcrMlE.split(':')[1]
    JgkWPmpxYDbLHanXUutoSFeyIcrMlR[i]=JgkWPmpxYDbLHanXUutoSFeyIcrMlE.split(',')[0]
   JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_usercd']=JgkWPmpxYDbLHanXUutoSFeyIcrMlR[user_pf]
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
   JgkWPmpxYDbLHanXUutoSFeyIcrMlj.Init_WC_Total()
   return JgkWPmpxYDbLHanXUutoSFeyIcrMVB
  return JgkWPmpxYDbLHanXUutoSFeyIcrMVi
 def GetProfilesConvert(JgkWPmpxYDbLHanXUutoSFeyIcrMlj):
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlC ='/api/users/'+JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_usercd']+'/convert'
   JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
   JgkWPmpxYDbLHanXUutoSFeyIcrMld=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.makeDefaultCookies()
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Put',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMld)
   for JgkWPmpxYDbLHanXUutoSFeyIcrMld in JgkWPmpxYDbLHanXUutoSFeyIcrMlh.cookies:
    if JgkWPmpxYDbLHanXUutoSFeyIcrMld.name=='_s_guitv':
     JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_guitv']=JgkWPmpxYDbLHanXUutoSFeyIcrMld.value
    elif JgkWPmpxYDbLHanXUutoSFeyIcrMld.name=='_guinness-premium_session':
     JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_token']=JgkWPmpxYDbLHanXUutoSFeyIcrMld.value
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
   JgkWPmpxYDbLHanXUutoSFeyIcrMlj.Init_WC_Total()
   return JgkWPmpxYDbLHanXUutoSFeyIcrMVB
  return JgkWPmpxYDbLHanXUutoSFeyIcrMVi
 def GetSubGroupList(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,stype):
  JgkWPmpxYDbLHanXUutoSFeyIcrMBl=[]
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlC ='/api/categories.json'
   JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
   JgkWPmpxYDbLHanXUutoSFeyIcrMld=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.makeDefaultCookies()
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Get',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMld)
   JgkWPmpxYDbLHanXUutoSFeyIcrMBj=json.loads(JgkWPmpxYDbLHanXUutoSFeyIcrMlh.text)
   if not('genres' in JgkWPmpxYDbLHanXUutoSFeyIcrMBj):return JgkWPmpxYDbLHanXUutoSFeyIcrMBl
   if stype=='genres':
    JgkWPmpxYDbLHanXUutoSFeyIcrMBi=JgkWPmpxYDbLHanXUutoSFeyIcrMBj['genres']
   else:
    JgkWPmpxYDbLHanXUutoSFeyIcrMBi=JgkWPmpxYDbLHanXUutoSFeyIcrMBj['tags']
   for JgkWPmpxYDbLHanXUutoSFeyIcrMBV in JgkWPmpxYDbLHanXUutoSFeyIcrMBi:
    JgkWPmpxYDbLHanXUutoSFeyIcrMBN=JgkWPmpxYDbLHanXUutoSFeyIcrMBV['name']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBT =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['api_path']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBs =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['entity']['id']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBA={'group_name':JgkWPmpxYDbLHanXUutoSFeyIcrMBN,'api_path':JgkWPmpxYDbLHanXUutoSFeyIcrMBT,'tag_id':JgkWPmpxYDbLHanXUutoSFeyIcrMVK(JgkWPmpxYDbLHanXUutoSFeyIcrMBs)}
    JgkWPmpxYDbLHanXUutoSFeyIcrMBl.append(JgkWPmpxYDbLHanXUutoSFeyIcrMBA)
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
  return JgkWPmpxYDbLHanXUutoSFeyIcrMBl
 def GetCategoryList(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,stype,JgkWPmpxYDbLHanXUutoSFeyIcrMBs,JgkWPmpxYDbLHanXUutoSFeyIcrMBT,page_int):
  JgkWPmpxYDbLHanXUutoSFeyIcrMBl=[]
  JgkWPmpxYDbLHanXUutoSFeyIcrMBK=JgkWPmpxYDbLHanXUutoSFeyIcrMVB
  JgkWPmpxYDbLHanXUutoSFeyIcrMBf={}
  try:
   if 'categories' in JgkWPmpxYDbLHanXUutoSFeyIcrMBT:
    JgkWPmpxYDbLHanXUutoSFeyIcrMlC ='/api/tags'
    JgkWPmpxYDbLHanXUutoSFeyIcrMBf['ids']=JgkWPmpxYDbLHanXUutoSFeyIcrMBs
   else: 
    JgkWPmpxYDbLHanXUutoSFeyIcrMlC ='/api/'+JgkWPmpxYDbLHanXUutoSFeyIcrMBT+'.json'
    if page_int>1:
     JgkWPmpxYDbLHanXUutoSFeyIcrMBf['page']=JgkWPmpxYDbLHanXUutoSFeyIcrMVK(page_int)
   JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
   JgkWPmpxYDbLHanXUutoSFeyIcrMld=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.makeDefaultCookies()
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Get',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMBf,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMld)
   JgkWPmpxYDbLHanXUutoSFeyIcrMBj=json.loads(JgkWPmpxYDbLHanXUutoSFeyIcrMlh.text)
   if not('contents' in JgkWPmpxYDbLHanXUutoSFeyIcrMBj):return JgkWPmpxYDbLHanXUutoSFeyIcrMBl,JgkWPmpxYDbLHanXUutoSFeyIcrMBK
   JgkWPmpxYDbLHanXUutoSFeyIcrMBi=JgkWPmpxYDbLHanXUutoSFeyIcrMBj['contents']
   JgkWPmpxYDbLHanXUutoSFeyIcrMBK=JgkWPmpxYDbLHanXUutoSFeyIcrMBj['meta']['has_next']
   for JgkWPmpxYDbLHanXUutoSFeyIcrMBV in JgkWPmpxYDbLHanXUutoSFeyIcrMBi:
    JgkWPmpxYDbLHanXUutoSFeyIcrMBQ =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['code']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBq=JgkWPmpxYDbLHanXUutoSFeyIcrMBV['content_type']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBG =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['title']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBO =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['story']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBh =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['badge_text']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBd=JgkWPmpxYDbLHanXUutoSFeyIcrMiv=JgkWPmpxYDbLHanXUutoSFeyIcrMiz=''
    if JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('poster') !=JgkWPmpxYDbLHanXUutoSFeyIcrMVl:JgkWPmpxYDbLHanXUutoSFeyIcrMBd=JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('poster').get('original')
    if JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('stillcut')!=JgkWPmpxYDbLHanXUutoSFeyIcrMVl:JgkWPmpxYDbLHanXUutoSFeyIcrMiv =JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('stillcut').get('large')
    if JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('thumbnail')!=JgkWPmpxYDbLHanXUutoSFeyIcrMVl:JgkWPmpxYDbLHanXUutoSFeyIcrMiz=JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('thumbnail').get('large')
    if JgkWPmpxYDbLHanXUutoSFeyIcrMiz=='' :JgkWPmpxYDbLHanXUutoSFeyIcrMiz=JgkWPmpxYDbLHanXUutoSFeyIcrMiv
    JgkWPmpxYDbLHanXUutoSFeyIcrMBR={'thumb':JgkWPmpxYDbLHanXUutoSFeyIcrMiv,'poster':JgkWPmpxYDbLHanXUutoSFeyIcrMBd,'fanart':JgkWPmpxYDbLHanXUutoSFeyIcrMiz}
    JgkWPmpxYDbLHanXUutoSFeyIcrMBC =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['year']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBw =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['film_rating_code']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBz=JgkWPmpxYDbLHanXUutoSFeyIcrMBV['film_rating_short']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBv =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['film_rating_long']
    if JgkWPmpxYDbLHanXUutoSFeyIcrMBq=='movies':
     JgkWPmpxYDbLHanXUutoSFeyIcrMBE =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['duration']
    else:
     JgkWPmpxYDbLHanXUutoSFeyIcrMBE ='0'
    JgkWPmpxYDbLHanXUutoSFeyIcrMBA={'code':JgkWPmpxYDbLHanXUutoSFeyIcrMBQ,'content_type':JgkWPmpxYDbLHanXUutoSFeyIcrMBq,'title':JgkWPmpxYDbLHanXUutoSFeyIcrMBG,'story':JgkWPmpxYDbLHanXUutoSFeyIcrMBO,'thumbnail':JgkWPmpxYDbLHanXUutoSFeyIcrMBR,'year':JgkWPmpxYDbLHanXUutoSFeyIcrMBC,'film_rating_code':JgkWPmpxYDbLHanXUutoSFeyIcrMBw,'film_rating_short':JgkWPmpxYDbLHanXUutoSFeyIcrMBz,'film_rating_long':JgkWPmpxYDbLHanXUutoSFeyIcrMBv,'duration':JgkWPmpxYDbLHanXUutoSFeyIcrMBE,'badge':JgkWPmpxYDbLHanXUutoSFeyIcrMBh,}
    JgkWPmpxYDbLHanXUutoSFeyIcrMBl.append(JgkWPmpxYDbLHanXUutoSFeyIcrMBA)
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
  return JgkWPmpxYDbLHanXUutoSFeyIcrMBl,JgkWPmpxYDbLHanXUutoSFeyIcrMBK
 def GetProgramInfo(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,program_code):
  JgkWPmpxYDbLHanXUutoSFeyIcrMjl={}
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlC ='/api/contents/'+program_code
   JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Get',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMVl)
   JgkWPmpxYDbLHanXUutoSFeyIcrMBj=json.loads(JgkWPmpxYDbLHanXUutoSFeyIcrMlh.text)
   JgkWPmpxYDbLHanXUutoSFeyIcrMjB=img_clearlogo=''
   JgkWPmpxYDbLHanXUutoSFeyIcrMjB=JgkWPmpxYDbLHanXUutoSFeyIcrMBj.get('poster').get('original')
   if JgkWPmpxYDbLHanXUutoSFeyIcrMVA(JgkWPmpxYDbLHanXUutoSFeyIcrMBj.get('title_logos'))>0:img_clearlogo=JgkWPmpxYDbLHanXUutoSFeyIcrMBj.get('title_logos')[0].get('src')
   JgkWPmpxYDbLHanXUutoSFeyIcrMjl={'imgPoster':JgkWPmpxYDbLHanXUutoSFeyIcrMjB,'imgClearlogo':img_clearlogo}
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
  return JgkWPmpxYDbLHanXUutoSFeyIcrMjl
 def GetSeasonList(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,program_code):
  JgkWPmpxYDbLHanXUutoSFeyIcrMji=[]
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlC ='/api/aio_contents/'+program_code
   JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Get',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMVl)
   JgkWPmpxYDbLHanXUutoSFeyIcrMBj=json.loads(JgkWPmpxYDbLHanXUutoSFeyIcrMlh.text)
   if not('result' in JgkWPmpxYDbLHanXUutoSFeyIcrMBj):return JgkWPmpxYDbLHanXUutoSFeyIcrMji
   for JgkWPmpxYDbLHanXUutoSFeyIcrMBV in JgkWPmpxYDbLHanXUutoSFeyIcrMBj.get('result').get('seasons'):
    JgkWPmpxYDbLHanXUutoSFeyIcrMjV =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['id']
    JgkWPmpxYDbLHanXUutoSFeyIcrMjN =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['titles']['short']or JgkWPmpxYDbLHanXUutoSFeyIcrMBV['titles']['original']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBA={'seasonId':JgkWPmpxYDbLHanXUutoSFeyIcrMjV,'seasonNm':JgkWPmpxYDbLHanXUutoSFeyIcrMjN,}
    JgkWPmpxYDbLHanXUutoSFeyIcrMji.append(JgkWPmpxYDbLHanXUutoSFeyIcrMBA)
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
  return JgkWPmpxYDbLHanXUutoSFeyIcrMji
 def GetEpisodoList(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,program_code,page_int,orderby='asc'):
  JgkWPmpxYDbLHanXUutoSFeyIcrMBl=[]
  JgkWPmpxYDbLHanXUutoSFeyIcrMBK=JgkWPmpxYDbLHanXUutoSFeyIcrMVB
  JgkWPmpxYDbLHanXUutoSFeyIcrMjT=''
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlC ='/api/contents/'+program_code+'/tv_episodes.json'
   JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
   JgkWPmpxYDbLHanXUutoSFeyIcrMBf={'all':'true'}
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Get',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMBf,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMVl)
   JgkWPmpxYDbLHanXUutoSFeyIcrMBj=json.loads(JgkWPmpxYDbLHanXUutoSFeyIcrMlh.text)
   if not('tv_episode_codes' in JgkWPmpxYDbLHanXUutoSFeyIcrMBj):return JgkWPmpxYDbLHanXUutoSFeyIcrMBl,JgkWPmpxYDbLHanXUutoSFeyIcrMBK
   JgkWPmpxYDbLHanXUutoSFeyIcrMBi=JgkWPmpxYDbLHanXUutoSFeyIcrMBj['tv_episode_codes']
   JgkWPmpxYDbLHanXUutoSFeyIcrMjs=JgkWPmpxYDbLHanXUutoSFeyIcrMVA(JgkWPmpxYDbLHanXUutoSFeyIcrMBi)
   JgkWPmpxYDbLHanXUutoSFeyIcrMjA =JgkWPmpxYDbLHanXUutoSFeyIcrMVf(JgkWPmpxYDbLHanXUutoSFeyIcrMjs//(JgkWPmpxYDbLHanXUutoSFeyIcrMlj.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    JgkWPmpxYDbLHanXUutoSFeyIcrMjK =(JgkWPmpxYDbLHanXUutoSFeyIcrMjs-1)-((page_int-1)*JgkWPmpxYDbLHanXUutoSFeyIcrMlj.EPISODE_LIMIT)
   else:
    JgkWPmpxYDbLHanXUutoSFeyIcrMjK =(page_int-1)*JgkWPmpxYDbLHanXUutoSFeyIcrMlj.EPISODE_LIMIT
   for i in JgkWPmpxYDbLHanXUutoSFeyIcrMVs(JgkWPmpxYDbLHanXUutoSFeyIcrMlj.EPISODE_LIMIT):
    if orderby=='desc':
     JgkWPmpxYDbLHanXUutoSFeyIcrMjf=JgkWPmpxYDbLHanXUutoSFeyIcrMjK-i
     if JgkWPmpxYDbLHanXUutoSFeyIcrMjf<0:break
    else:
     JgkWPmpxYDbLHanXUutoSFeyIcrMjf=JgkWPmpxYDbLHanXUutoSFeyIcrMjK+i
     if JgkWPmpxYDbLHanXUutoSFeyIcrMjf>=JgkWPmpxYDbLHanXUutoSFeyIcrMjs:break
    if JgkWPmpxYDbLHanXUutoSFeyIcrMjT!='':JgkWPmpxYDbLHanXUutoSFeyIcrMjT+=','
    JgkWPmpxYDbLHanXUutoSFeyIcrMjT+=JgkWPmpxYDbLHanXUutoSFeyIcrMBi[JgkWPmpxYDbLHanXUutoSFeyIcrMjf]
   if JgkWPmpxYDbLHanXUutoSFeyIcrMjA>page_int:JgkWPmpxYDbLHanXUutoSFeyIcrMBK=JgkWPmpxYDbLHanXUutoSFeyIcrMVi
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
  JgkWPmpxYDbLHanXUutoSFeyIcrMjQ=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.GetProgramInfo(program_code)
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
   JgkWPmpxYDbLHanXUutoSFeyIcrMBf={'codes':JgkWPmpxYDbLHanXUutoSFeyIcrMjT}
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Get',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMBf,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMVl)
   JgkWPmpxYDbLHanXUutoSFeyIcrMBj=json.loads(JgkWPmpxYDbLHanXUutoSFeyIcrMlh.text)
   if not('tv_episodes' in JgkWPmpxYDbLHanXUutoSFeyIcrMBj):return JgkWPmpxYDbLHanXUutoSFeyIcrMBl
   JgkWPmpxYDbLHanXUutoSFeyIcrMBi=JgkWPmpxYDbLHanXUutoSFeyIcrMBj['tv_episodes']
   for JgkWPmpxYDbLHanXUutoSFeyIcrMBV in JgkWPmpxYDbLHanXUutoSFeyIcrMBi:
    JgkWPmpxYDbLHanXUutoSFeyIcrMBQ =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['code']
    if JgkWPmpxYDbLHanXUutoSFeyIcrMBV['title']:
     JgkWPmpxYDbLHanXUutoSFeyIcrMBG =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['title']
    else:
     JgkWPmpxYDbLHanXUutoSFeyIcrMBG =''
    JgkWPmpxYDbLHanXUutoSFeyIcrMBd=JgkWPmpxYDbLHanXUutoSFeyIcrMiv=JgkWPmpxYDbLHanXUutoSFeyIcrMiz=JgkWPmpxYDbLHanXUutoSFeyIcrMjq=''
    JgkWPmpxYDbLHanXUutoSFeyIcrMBd =JgkWPmpxYDbLHanXUutoSFeyIcrMjQ.get('imgPoster')
    JgkWPmpxYDbLHanXUutoSFeyIcrMjq=JgkWPmpxYDbLHanXUutoSFeyIcrMjQ.get('imgClearlogo')
    if JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('stillcut') !=JgkWPmpxYDbLHanXUutoSFeyIcrMVl:JgkWPmpxYDbLHanXUutoSFeyIcrMiv =JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('stillcut').get('large')
    if JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('tv_season_stillcut')!=JgkWPmpxYDbLHanXUutoSFeyIcrMVl:JgkWPmpxYDbLHanXUutoSFeyIcrMiz=JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('tv_season_stillcut').get('large')
    JgkWPmpxYDbLHanXUutoSFeyIcrMBR={'thumb':JgkWPmpxYDbLHanXUutoSFeyIcrMiv,'poster':JgkWPmpxYDbLHanXUutoSFeyIcrMBd,'fanart':JgkWPmpxYDbLHanXUutoSFeyIcrMiz,'clearlogo':JgkWPmpxYDbLHanXUutoSFeyIcrMjq}
    JgkWPmpxYDbLHanXUutoSFeyIcrMjG =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['display_number']
    JgkWPmpxYDbLHanXUutoSFeyIcrMjO=JgkWPmpxYDbLHanXUutoSFeyIcrMBV['tv_season_title']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBE =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['duration']
    try:
     JgkWPmpxYDbLHanXUutoSFeyIcrMjh=JgkWPmpxYDbLHanXUutoSFeyIcrMBV['episode_number']
    except:
     JgkWPmpxYDbLHanXUutoSFeyIcrMjh='0'
    JgkWPmpxYDbLHanXUutoSFeyIcrMBA={'code':JgkWPmpxYDbLHanXUutoSFeyIcrMBQ,'title':JgkWPmpxYDbLHanXUutoSFeyIcrMBG,'thumbnail':JgkWPmpxYDbLHanXUutoSFeyIcrMBR,'display_num':JgkWPmpxYDbLHanXUutoSFeyIcrMjG,'season_title':JgkWPmpxYDbLHanXUutoSFeyIcrMjO,'duration':JgkWPmpxYDbLHanXUutoSFeyIcrMBE,'episode_number':JgkWPmpxYDbLHanXUutoSFeyIcrMjh}
    JgkWPmpxYDbLHanXUutoSFeyIcrMBl.append(JgkWPmpxYDbLHanXUutoSFeyIcrMBA)
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
  return JgkWPmpxYDbLHanXUutoSFeyIcrMBl,JgkWPmpxYDbLHanXUutoSFeyIcrMBK
 def GetHomeList(JgkWPmpxYDbLHanXUutoSFeyIcrMlj):
  JgkWPmpxYDbLHanXUutoSFeyIcrMjd=[]
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlC ='/api/aio_browses/video/header'
   JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
   JgkWPmpxYDbLHanXUutoSFeyIcrMlQ=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.makeDefaultCookies()
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Get',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMlQ)
   JgkWPmpxYDbLHanXUutoSFeyIcrMjR=json.loads(JgkWPmpxYDbLHanXUutoSFeyIcrMlh.text)
   if not('result' in JgkWPmpxYDbLHanXUutoSFeyIcrMjR):return JgkWPmpxYDbLHanXUutoSFeyIcrMjd
   JgkWPmpxYDbLHanXUutoSFeyIcrMBi=JgkWPmpxYDbLHanXUutoSFeyIcrMjR['result'][0]['cells']
   for JgkWPmpxYDbLHanXUutoSFeyIcrMBV in JgkWPmpxYDbLHanXUutoSFeyIcrMBi:
    JgkWPmpxYDbLHanXUutoSFeyIcrMBq=JgkWPmpxYDbLHanXUutoSFeyIcrMBV['relations'][0]['type']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBG =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['title']
    JgkWPmpxYDbLHanXUutoSFeyIcrMjC =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['badge']
    JgkWPmpxYDbLHanXUutoSFeyIcrMjw =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['media']['fullhd']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBR ={'thumb':JgkWPmpxYDbLHanXUutoSFeyIcrMjw,'fanart':JgkWPmpxYDbLHanXUutoSFeyIcrMjw}
    JgkWPmpxYDbLHanXUutoSFeyIcrMBQ =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['relations'][0]['id']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBA={'code':JgkWPmpxYDbLHanXUutoSFeyIcrMBQ,'content_type':JgkWPmpxYDbLHanXUutoSFeyIcrMBq,'title':JgkWPmpxYDbLHanXUutoSFeyIcrMBG,'bedge':JgkWPmpxYDbLHanXUutoSFeyIcrMjC,'thumbnail':JgkWPmpxYDbLHanXUutoSFeyIcrMBR}
    JgkWPmpxYDbLHanXUutoSFeyIcrMjd.append(JgkWPmpxYDbLHanXUutoSFeyIcrMBA)
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
  return JgkWPmpxYDbLHanXUutoSFeyIcrMjd
 def GetSearchList(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,search_key,page_int):
  JgkWPmpxYDbLHanXUutoSFeyIcrMjz=[]
  JgkWPmpxYDbLHanXUutoSFeyIcrMBK=JgkWPmpxYDbLHanXUutoSFeyIcrMVB
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlC ='/api/search.json'
   JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
   JgkWPmpxYDbLHanXUutoSFeyIcrMBf={'query':search_key,'page':JgkWPmpxYDbLHanXUutoSFeyIcrMVK(page_int),'per':JgkWPmpxYDbLHanXUutoSFeyIcrMVK(JgkWPmpxYDbLHanXUutoSFeyIcrMlj.SEARCH_LIMIT),'exclude':'limited'}
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Get',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMBf,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMVl)
   JgkWPmpxYDbLHanXUutoSFeyIcrMBj=json.loads(JgkWPmpxYDbLHanXUutoSFeyIcrMlh.text)
   if not('results' in JgkWPmpxYDbLHanXUutoSFeyIcrMBj):return JgkWPmpxYDbLHanXUutoSFeyIcrMjz,JgkWPmpxYDbLHanXUutoSFeyIcrMBK
   JgkWPmpxYDbLHanXUutoSFeyIcrMBi=JgkWPmpxYDbLHanXUutoSFeyIcrMBj['results']
   JgkWPmpxYDbLHanXUutoSFeyIcrMBK=JgkWPmpxYDbLHanXUutoSFeyIcrMBj['meta']['has_next']
   for JgkWPmpxYDbLHanXUutoSFeyIcrMBV in JgkWPmpxYDbLHanXUutoSFeyIcrMBi:
    JgkWPmpxYDbLHanXUutoSFeyIcrMBQ =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['code']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBq=JgkWPmpxYDbLHanXUutoSFeyIcrMBV['content_type']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBG =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['title']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBO =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['story']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBd=JgkWPmpxYDbLHanXUutoSFeyIcrMiv=JgkWPmpxYDbLHanXUutoSFeyIcrMiz=''
    if JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('poster') !=JgkWPmpxYDbLHanXUutoSFeyIcrMVl:JgkWPmpxYDbLHanXUutoSFeyIcrMBd=JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('poster').get('original')
    if JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('stillcut')!=JgkWPmpxYDbLHanXUutoSFeyIcrMVl:JgkWPmpxYDbLHanXUutoSFeyIcrMiv =JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('stillcut').get('large')
    if JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('thumbnail')!=JgkWPmpxYDbLHanXUutoSFeyIcrMVl:JgkWPmpxYDbLHanXUutoSFeyIcrMiz=JgkWPmpxYDbLHanXUutoSFeyIcrMBV.get('thumbnail').get('large')
    if JgkWPmpxYDbLHanXUutoSFeyIcrMiz=='' :JgkWPmpxYDbLHanXUutoSFeyIcrMiz=JgkWPmpxYDbLHanXUutoSFeyIcrMiv
    JgkWPmpxYDbLHanXUutoSFeyIcrMBR={'thumb':JgkWPmpxYDbLHanXUutoSFeyIcrMiv,'poster':JgkWPmpxYDbLHanXUutoSFeyIcrMBd,'fanart':JgkWPmpxYDbLHanXUutoSFeyIcrMiz}
    JgkWPmpxYDbLHanXUutoSFeyIcrMBC =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['year']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBw =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['film_rating_code']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBz=JgkWPmpxYDbLHanXUutoSFeyIcrMBV['film_rating_short']
    JgkWPmpxYDbLHanXUutoSFeyIcrMBv =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['film_rating_long']
    if JgkWPmpxYDbLHanXUutoSFeyIcrMBq=='movies':
     JgkWPmpxYDbLHanXUutoSFeyIcrMBE =JgkWPmpxYDbLHanXUutoSFeyIcrMBV['duration']
    else:
     JgkWPmpxYDbLHanXUutoSFeyIcrMBE ='0'
    JgkWPmpxYDbLHanXUutoSFeyIcrMBA={'code':JgkWPmpxYDbLHanXUutoSFeyIcrMBQ,'content_type':JgkWPmpxYDbLHanXUutoSFeyIcrMBq,'title':JgkWPmpxYDbLHanXUutoSFeyIcrMBG,'story':JgkWPmpxYDbLHanXUutoSFeyIcrMBO,'thumbnail':JgkWPmpxYDbLHanXUutoSFeyIcrMBR,'year':JgkWPmpxYDbLHanXUutoSFeyIcrMBC,'film_rating_code':JgkWPmpxYDbLHanXUutoSFeyIcrMBw,'film_rating_short':JgkWPmpxYDbLHanXUutoSFeyIcrMBz,'film_rating_long':JgkWPmpxYDbLHanXUutoSFeyIcrMBv,'duration':JgkWPmpxYDbLHanXUutoSFeyIcrMBE}
    JgkWPmpxYDbLHanXUutoSFeyIcrMjz.append(JgkWPmpxYDbLHanXUutoSFeyIcrMBA)
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
  return JgkWPmpxYDbLHanXUutoSFeyIcrMjz,JgkWPmpxYDbLHanXUutoSFeyIcrMBK
 def DeleteContinueList(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,codeList):
  try:
   for JgkWPmpxYDbLHanXUutoSFeyIcrMjv in codeList:
    JgkWPmpxYDbLHanXUutoSFeyIcrMlC ='/api/watches/'+JgkWPmpxYDbLHanXUutoSFeyIcrMjv
    JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
    JgkWPmpxYDbLHanXUutoSFeyIcrMld=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.makeDefaultCookies()
    JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Delete',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,params=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMld)
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   JgkWPmpxYDbLHanXUutoSFeyIcrMVT(exception)
 def Get_Now_Datetime(JgkWPmpxYDbLHanXUutoSFeyIcrMlj):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,movie_code,quality_str):
  JgkWPmpxYDbLHanXUutoSFeyIcrMil=JgkWPmpxYDbLHanXUutoSFeyIcrMij=JgkWPmpxYDbLHanXUutoSFeyIcrMiA=''
  try:
   JgkWPmpxYDbLHanXUutoSFeyIcrMlC='/api/watch/'+movie_code+'.json'
   JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+JgkWPmpxYDbLHanXUutoSFeyIcrMlC
   JgkWPmpxYDbLHanXUutoSFeyIcrMlO={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   JgkWPmpxYDbLHanXUutoSFeyIcrMld=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.makeDefaultCookies()
   JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Get',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMlO,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMld)
   JgkWPmpxYDbLHanXUutoSFeyIcrMBj=json.loads(JgkWPmpxYDbLHanXUutoSFeyIcrMlh.text)
   JgkWPmpxYDbLHanXUutoSFeyIcrMil=JgkWPmpxYDbLHanXUutoSFeyIcrMBj['streams'][0]['source']
   if JgkWPmpxYDbLHanXUutoSFeyIcrMil==JgkWPmpxYDbLHanXUutoSFeyIcrMVl:return(JgkWPmpxYDbLHanXUutoSFeyIcrMil,JgkWPmpxYDbLHanXUutoSFeyIcrMij,JgkWPmpxYDbLHanXUutoSFeyIcrMiA)
   if 'subtitles' in JgkWPmpxYDbLHanXUutoSFeyIcrMBj['streams'][0]:
    for JgkWPmpxYDbLHanXUutoSFeyIcrMiB in JgkWPmpxYDbLHanXUutoSFeyIcrMBj['streams'][0]['subtitles']:
     if JgkWPmpxYDbLHanXUutoSFeyIcrMiB['lang']=='ko':
      JgkWPmpxYDbLHanXUutoSFeyIcrMij=JgkWPmpxYDbLHanXUutoSFeyIcrMiB['url']
      break
   JgkWPmpxYDbLHanXUutoSFeyIcrMiV =JgkWPmpxYDbLHanXUutoSFeyIcrMBj['ping_payload']
   JgkWPmpxYDbLHanXUutoSFeyIcrMiN =JgkWPmpxYDbLHanXUutoSFeyIcrMlj.WC['cookies']['watcha_usercd']
   JgkWPmpxYDbLHanXUutoSFeyIcrMiT={'merchant':'giitd_frograms','sessionId':JgkWPmpxYDbLHanXUutoSFeyIcrMiV,'userId':JgkWPmpxYDbLHanXUutoSFeyIcrMiN}
   JgkWPmpxYDbLHanXUutoSFeyIcrMis=json.dumps(JgkWPmpxYDbLHanXUutoSFeyIcrMiT,separators=(",",":")).encode('UTF-8')
   JgkWPmpxYDbLHanXUutoSFeyIcrMiA=base64.b64encode(JgkWPmpxYDbLHanXUutoSFeyIcrMis)
  except JgkWPmpxYDbLHanXUutoSFeyIcrMVN as exception:
   return(JgkWPmpxYDbLHanXUutoSFeyIcrMil,JgkWPmpxYDbLHanXUutoSFeyIcrMij,JgkWPmpxYDbLHanXUutoSFeyIcrMiA)
  return(JgkWPmpxYDbLHanXUutoSFeyIcrMil,JgkWPmpxYDbLHanXUutoSFeyIcrMij,JgkWPmpxYDbLHanXUutoSFeyIcrMiA) 
 def GetBookmarkInfo(JgkWPmpxYDbLHanXUutoSFeyIcrMlj,videoid,vidtype):
  JgkWPmpxYDbLHanXUutoSFeyIcrMiK={'indexinfo':{'ott':'watcha','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  JgkWPmpxYDbLHanXUutoSFeyIcrMlw=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.API_DOMAIN+'/api/contents/'+videoid
  JgkWPmpxYDbLHanXUutoSFeyIcrMlh=JgkWPmpxYDbLHanXUutoSFeyIcrMlj.callRequestCookies('Get',JgkWPmpxYDbLHanXUutoSFeyIcrMlw,payload=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,params=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,headers=JgkWPmpxYDbLHanXUutoSFeyIcrMVl,cookies=JgkWPmpxYDbLHanXUutoSFeyIcrMVl)
  JgkWPmpxYDbLHanXUutoSFeyIcrMjR=json.loads(JgkWPmpxYDbLHanXUutoSFeyIcrMlh.text)
  if not('title' in JgkWPmpxYDbLHanXUutoSFeyIcrMjR):return{}
  JgkWPmpxYDbLHanXUutoSFeyIcrMif=JgkWPmpxYDbLHanXUutoSFeyIcrMjR
  JgkWPmpxYDbLHanXUutoSFeyIcrMVT(JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('duration'))
  JgkWPmpxYDbLHanXUutoSFeyIcrMiQ=JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('title')
  JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['infoLabels']['title']=JgkWPmpxYDbLHanXUutoSFeyIcrMiQ
  JgkWPmpxYDbLHanXUutoSFeyIcrMiQ +=u'  (%s)'%(JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('year'))
  JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['title'] =JgkWPmpxYDbLHanXUutoSFeyIcrMiQ
  JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['infoLabels']['mpaa'] =JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('film_rating_long')
  JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['infoLabels']['plot'] =JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('story').replace('<br>','\n')
  JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['infoLabels']['year'] =JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('year')
  if vidtype=='movie':
   JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['infoLabels']['duration']=JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('duration')
  JgkWPmpxYDbLHanXUutoSFeyIcrMiq=[]
  for JgkWPmpxYDbLHanXUutoSFeyIcrMiG in JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('actors'):
   JgkWPmpxYDbLHanXUutoSFeyIcrMiO =JgkWPmpxYDbLHanXUutoSFeyIcrMiG.get('name')
   JgkWPmpxYDbLHanXUutoSFeyIcrMih='' if JgkWPmpxYDbLHanXUutoSFeyIcrMiG.get('photo')==JgkWPmpxYDbLHanXUutoSFeyIcrMVl else JgkWPmpxYDbLHanXUutoSFeyIcrMiG.get('photo').get('small')
   JgkWPmpxYDbLHanXUutoSFeyIcrMiq.append({'name':JgkWPmpxYDbLHanXUutoSFeyIcrMiO,'thumbnail':JgkWPmpxYDbLHanXUutoSFeyIcrMih})
  if JgkWPmpxYDbLHanXUutoSFeyIcrMVA(JgkWPmpxYDbLHanXUutoSFeyIcrMiq)>0:
   JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['infoLabels']['cast']=JgkWPmpxYDbLHanXUutoSFeyIcrMiq
  JgkWPmpxYDbLHanXUutoSFeyIcrMid=[]
  for JgkWPmpxYDbLHanXUutoSFeyIcrMiR in JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('directors'):JgkWPmpxYDbLHanXUutoSFeyIcrMid.append(JgkWPmpxYDbLHanXUutoSFeyIcrMiR.get('name'))
  if JgkWPmpxYDbLHanXUutoSFeyIcrMVA(JgkWPmpxYDbLHanXUutoSFeyIcrMid)>0:
   JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['infoLabels']['director']=JgkWPmpxYDbLHanXUutoSFeyIcrMid
  JgkWPmpxYDbLHanXUutoSFeyIcrMiC=[]
  for JgkWPmpxYDbLHanXUutoSFeyIcrMiw in JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('genres'):JgkWPmpxYDbLHanXUutoSFeyIcrMiC.append(JgkWPmpxYDbLHanXUutoSFeyIcrMiw.get('name'))
  if JgkWPmpxYDbLHanXUutoSFeyIcrMVA(JgkWPmpxYDbLHanXUutoSFeyIcrMiC)>0:
   JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['infoLabels']['genre']=JgkWPmpxYDbLHanXUutoSFeyIcrMiC
  JgkWPmpxYDbLHanXUutoSFeyIcrMBd =''
  JgkWPmpxYDbLHanXUutoSFeyIcrMiz =''
  JgkWPmpxYDbLHanXUutoSFeyIcrMiv =''
  if JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('poster') !=JgkWPmpxYDbLHanXUutoSFeyIcrMVl:JgkWPmpxYDbLHanXUutoSFeyIcrMBd =JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('poster').get('original')
  if JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('thumbnail')!=JgkWPmpxYDbLHanXUutoSFeyIcrMVl:JgkWPmpxYDbLHanXUutoSFeyIcrMiz =JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('thumbnail').get('large')
  if JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('stillcut')!=JgkWPmpxYDbLHanXUutoSFeyIcrMVl:JgkWPmpxYDbLHanXUutoSFeyIcrMiv =JgkWPmpxYDbLHanXUutoSFeyIcrMif.get('stillcut').get('large')
  if JgkWPmpxYDbLHanXUutoSFeyIcrMiz=='':JgkWPmpxYDbLHanXUutoSFeyIcrMiz=JgkWPmpxYDbLHanXUutoSFeyIcrMiv
  JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['thumbnail']['poster']=JgkWPmpxYDbLHanXUutoSFeyIcrMBd
  JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['thumbnail']['fanart']=JgkWPmpxYDbLHanXUutoSFeyIcrMiz
  JgkWPmpxYDbLHanXUutoSFeyIcrMiK['saveinfo']['thumbnail']['thumb']=JgkWPmpxYDbLHanXUutoSFeyIcrMiv
  return JgkWPmpxYDbLHanXUutoSFeyIcrMiK
# Created by pyminifier (https://github.com/liftoff/pyminifier)
