__author__="NightRain"
FvGbPfoWIjgTLlkxRYNymDKcCVOuHe=object
FvGbPfoWIjgTLlkxRYNymDKcCVOuHs=None
FvGbPfoWIjgTLlkxRYNymDKcCVOuHJ=False
FvGbPfoWIjgTLlkxRYNymDKcCVOuHr=True
FvGbPfoWIjgTLlkxRYNymDKcCVOuHt=Exception
FvGbPfoWIjgTLlkxRYNymDKcCVOuHz=str
FvGbPfoWIjgTLlkxRYNymDKcCVOuHw=print
FvGbPfoWIjgTLlkxRYNymDKcCVOuHq=len
FvGbPfoWIjgTLlkxRYNymDKcCVOuHd=int
FvGbPfoWIjgTLlkxRYNymDKcCVOuHE=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import base64
import requests
import datetime
FvGbPfoWIjgTLlkxRYNymDKcCVOueJ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
class FvGbPfoWIjgTLlkxRYNymDKcCVOues(FvGbPfoWIjgTLlkxRYNymDKcCVOuHe):
 def __init__(FvGbPfoWIjgTLlkxRYNymDKcCVOueH):
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_TOKEN ='' 
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUIT =''
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUITV =''
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_USERCD=''
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.API_DOMAIN ='https://play.watcha.net'
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.EPISODE_LIMIT=20
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.SEARCH_LIMIT =30
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.DEFAULT_HEADER={'user-agent':FvGbPfoWIjgTLlkxRYNymDKcCVOueJ,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,jobtype,FvGbPfoWIjgTLlkxRYNymDKcCVOuea,payload=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,params=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,cookies=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,redirects=FvGbPfoWIjgTLlkxRYNymDKcCVOuHJ):
  FvGbPfoWIjgTLlkxRYNymDKcCVOuer=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.DEFAULT_HEADER
  if headers:FvGbPfoWIjgTLlkxRYNymDKcCVOuer.update(headers)
  if jobtype=='Get':
   FvGbPfoWIjgTLlkxRYNymDKcCVOuet=requests.get(FvGbPfoWIjgTLlkxRYNymDKcCVOuea,params=params,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuer,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   FvGbPfoWIjgTLlkxRYNymDKcCVOuet=requests.put(FvGbPfoWIjgTLlkxRYNymDKcCVOuea,data=payload,params=params,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuer,cookies=cookies,allow_redirects=redirects)
  else:
   FvGbPfoWIjgTLlkxRYNymDKcCVOuet=requests.post(FvGbPfoWIjgTLlkxRYNymDKcCVOuea,data=payload,params=params,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuer,cookies=cookies,allow_redirects=redirects)
  return FvGbPfoWIjgTLlkxRYNymDKcCVOuet
 def SaveCredential(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,FvGbPfoWIjgTLlkxRYNymDKcCVOuez):
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_TOKEN =FvGbPfoWIjgTLlkxRYNymDKcCVOuez.get('watcha_token')
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUIT =FvGbPfoWIjgTLlkxRYNymDKcCVOuez.get('watcha_guit')
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUITV =FvGbPfoWIjgTLlkxRYNymDKcCVOuez.get('watcha_guitv')
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_USERCD =FvGbPfoWIjgTLlkxRYNymDKcCVOuez.get('watcha_usercd')
 def SaveCredential_usercd(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,FvGbPfoWIjgTLlkxRYNymDKcCVOuew):
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_USERCD=FvGbPfoWIjgTLlkxRYNymDKcCVOuew
 def SaveCredential_guitv(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,FvGbPfoWIjgTLlkxRYNymDKcCVOueq,FvGbPfoWIjgTLlkxRYNymDKcCVOued):
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUITV=FvGbPfoWIjgTLlkxRYNymDKcCVOueq
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_TOKEN=FvGbPfoWIjgTLlkxRYNymDKcCVOued 
 def ClearCredential(FvGbPfoWIjgTLlkxRYNymDKcCVOueH):
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_TOKEN ='' 
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUIT =''
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUITV =''
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_USERCD=''
 def LoadCredential(FvGbPfoWIjgTLlkxRYNymDKcCVOueH):
  FvGbPfoWIjgTLlkxRYNymDKcCVOuez={'watcha_token':FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_TOKEN,'watcha_guit':FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUIT,'watcha_guitv':FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUITV,'watcha_usercd':FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_USERCD}
  return FvGbPfoWIjgTLlkxRYNymDKcCVOuez
 def makeDefaultCookies(FvGbPfoWIjgTLlkxRYNymDKcCVOueH):
  FvGbPfoWIjgTLlkxRYNymDKcCVOueE={'_s_guit':FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUIT,'_guinness-premium_session':FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_TOKEN}
  if FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUITV:
   FvGbPfoWIjgTLlkxRYNymDKcCVOueE['_s_guitv']=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_GUITV
  return FvGbPfoWIjgTLlkxRYNymDKcCVOueE
 def makeurl(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,domain,path,query1=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,query2=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs):
  FvGbPfoWIjgTLlkxRYNymDKcCVOuea=domain+path
  if query1:
   FvGbPfoWIjgTLlkxRYNymDKcCVOuea+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   FvGbPfoWIjgTLlkxRYNymDKcCVOuea+='&%s'%urllib.parse.urlencode(query2)
  return FvGbPfoWIjgTLlkxRYNymDKcCVOuea
 def GetCredential(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,user_id,user_pw,user_pf):
  FvGbPfoWIjgTLlkxRYNymDKcCVOueM=FvGbPfoWIjgTLlkxRYNymDKcCVOuHJ
  FvGbPfoWIjgTLlkxRYNymDKcCVOueB=FvGbPfoWIjgTLlkxRYNymDKcCVOuep='-'
  try:
   FvGbPfoWIjgTLlkxRYNymDKcCVOueU=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.API_DOMAIN+'/api/session'
   FvGbPfoWIjgTLlkxRYNymDKcCVOueA={'email':user_id,'password':user_pw}
   FvGbPfoWIjgTLlkxRYNymDKcCVOueQ={'accept':'application/vnd.frograms+json;version=4'}
   FvGbPfoWIjgTLlkxRYNymDKcCVOuei=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.callRequestCookies('Post',FvGbPfoWIjgTLlkxRYNymDKcCVOueU,payload=FvGbPfoWIjgTLlkxRYNymDKcCVOueA,params=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOueQ,cookies=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs)
   for FvGbPfoWIjgTLlkxRYNymDKcCVOuen in FvGbPfoWIjgTLlkxRYNymDKcCVOuei.cookies:
    if FvGbPfoWIjgTLlkxRYNymDKcCVOuen.name=='_guinness-premium_session':
     FvGbPfoWIjgTLlkxRYNymDKcCVOuep=FvGbPfoWIjgTLlkxRYNymDKcCVOuen.value
    elif FvGbPfoWIjgTLlkxRYNymDKcCVOuen.name=='_s_guit':
     FvGbPfoWIjgTLlkxRYNymDKcCVOueB=FvGbPfoWIjgTLlkxRYNymDKcCVOuen.value
   if FvGbPfoWIjgTLlkxRYNymDKcCVOuep:FvGbPfoWIjgTLlkxRYNymDKcCVOueM=FvGbPfoWIjgTLlkxRYNymDKcCVOuHr
  except FvGbPfoWIjgTLlkxRYNymDKcCVOuHt as exception:
   FvGbPfoWIjgTLlkxRYNymDKcCVOueB=FvGbPfoWIjgTLlkxRYNymDKcCVOuep='' 
  FvGbPfoWIjgTLlkxRYNymDKcCVOuez={'watcha_guit':FvGbPfoWIjgTLlkxRYNymDKcCVOueB,'watcha_token':FvGbPfoWIjgTLlkxRYNymDKcCVOuep,'watcha_guitv':'','watcha_usercd':''}
  FvGbPfoWIjgTLlkxRYNymDKcCVOueH.SaveCredential(FvGbPfoWIjgTLlkxRYNymDKcCVOuez)
  try:
   FvGbPfoWIjgTLlkxRYNymDKcCVOueh=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.GetProfilesList()
   FvGbPfoWIjgTLlkxRYNymDKcCVOuse =FvGbPfoWIjgTLlkxRYNymDKcCVOueh[user_pf]
   FvGbPfoWIjgTLlkxRYNymDKcCVOueH.SaveCredential_usercd(FvGbPfoWIjgTLlkxRYNymDKcCVOuse)
  except FvGbPfoWIjgTLlkxRYNymDKcCVOuHt as exception:
   FvGbPfoWIjgTLlkxRYNymDKcCVOueH.ClearCredential()
   return FvGbPfoWIjgTLlkxRYNymDKcCVOuHJ
  if user_pf!=0:
   FvGbPfoWIjgTLlkxRYNymDKcCVOueq,FvGbPfoWIjgTLlkxRYNymDKcCVOued=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.GetProfilesConvert(FvGbPfoWIjgTLlkxRYNymDKcCVOuse)
   FvGbPfoWIjgTLlkxRYNymDKcCVOueH.SaveCredential_guitv(FvGbPfoWIjgTLlkxRYNymDKcCVOueq,FvGbPfoWIjgTLlkxRYNymDKcCVOued)
  return FvGbPfoWIjgTLlkxRYNymDKcCVOueM
 def GetSubGroupList(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,stype):
  FvGbPfoWIjgTLlkxRYNymDKcCVOusJ=[]
  try:
   FvGbPfoWIjgTLlkxRYNymDKcCVOusH ='/api/categories.json'
   FvGbPfoWIjgTLlkxRYNymDKcCVOuea=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeurl(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.API_DOMAIN,FvGbPfoWIjgTLlkxRYNymDKcCVOusH)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuen=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeDefaultCookies()
   FvGbPfoWIjgTLlkxRYNymDKcCVOuei=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.callRequestCookies('Get',FvGbPfoWIjgTLlkxRYNymDKcCVOuea,payload=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,params=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,cookies=FvGbPfoWIjgTLlkxRYNymDKcCVOuen)
   FvGbPfoWIjgTLlkxRYNymDKcCVOusr=json.loads(FvGbPfoWIjgTLlkxRYNymDKcCVOuei.text)
   if not('genres' in FvGbPfoWIjgTLlkxRYNymDKcCVOusr):return FvGbPfoWIjgTLlkxRYNymDKcCVOusJ
   if stype=='genres':
    FvGbPfoWIjgTLlkxRYNymDKcCVOust=FvGbPfoWIjgTLlkxRYNymDKcCVOusr['genres']
   else:
    FvGbPfoWIjgTLlkxRYNymDKcCVOust=FvGbPfoWIjgTLlkxRYNymDKcCVOusr['tags']
   for FvGbPfoWIjgTLlkxRYNymDKcCVOusz in FvGbPfoWIjgTLlkxRYNymDKcCVOust:
    FvGbPfoWIjgTLlkxRYNymDKcCVOusw=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['name']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusq =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['api_path']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusd =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['entity']['id']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusE={'group_name':FvGbPfoWIjgTLlkxRYNymDKcCVOusw,'api_path':FvGbPfoWIjgTLlkxRYNymDKcCVOusq,'tag_id':FvGbPfoWIjgTLlkxRYNymDKcCVOuHz(FvGbPfoWIjgTLlkxRYNymDKcCVOusd)}
    FvGbPfoWIjgTLlkxRYNymDKcCVOusJ.append(FvGbPfoWIjgTLlkxRYNymDKcCVOusE)
  except FvGbPfoWIjgTLlkxRYNymDKcCVOuHt as exception:
   FvGbPfoWIjgTLlkxRYNymDKcCVOuHw(exception)
  return FvGbPfoWIjgTLlkxRYNymDKcCVOusJ
 def GetCategoryList(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,stype,FvGbPfoWIjgTLlkxRYNymDKcCVOusd,FvGbPfoWIjgTLlkxRYNymDKcCVOusq,page_int,in_sort):
  FvGbPfoWIjgTLlkxRYNymDKcCVOusJ=[]
  FvGbPfoWIjgTLlkxRYNymDKcCVOusa=FvGbPfoWIjgTLlkxRYNymDKcCVOuHJ
  FvGbPfoWIjgTLlkxRYNymDKcCVOusS={}
  try:
   if 'categories' in FvGbPfoWIjgTLlkxRYNymDKcCVOusq:
    FvGbPfoWIjgTLlkxRYNymDKcCVOusH ='/api/categories/contents.json'
    if stype=='genres':
     FvGbPfoWIjgTLlkxRYNymDKcCVOusS['genre']=FvGbPfoWIjgTLlkxRYNymDKcCVOusd
    else:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusS['tag'] =FvGbPfoWIjgTLlkxRYNymDKcCVOusd
    FvGbPfoWIjgTLlkxRYNymDKcCVOusS['order']=in_sort 
    if page_int>1:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusS['page']=FvGbPfoWIjgTLlkxRYNymDKcCVOuHz(page_int-1)
   else: 
    FvGbPfoWIjgTLlkxRYNymDKcCVOusH ='/api/'+FvGbPfoWIjgTLlkxRYNymDKcCVOusq+'.json'
    if page_int>1:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusS['page']=FvGbPfoWIjgTLlkxRYNymDKcCVOuHz(page_int)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuea=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeurl(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.API_DOMAIN,FvGbPfoWIjgTLlkxRYNymDKcCVOusH)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuen=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeDefaultCookies()
   FvGbPfoWIjgTLlkxRYNymDKcCVOuei=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.callRequestCookies('Get',FvGbPfoWIjgTLlkxRYNymDKcCVOuea,payload=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,params=FvGbPfoWIjgTLlkxRYNymDKcCVOusS,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,cookies=FvGbPfoWIjgTLlkxRYNymDKcCVOuen)
   FvGbPfoWIjgTLlkxRYNymDKcCVOusr=json.loads(FvGbPfoWIjgTLlkxRYNymDKcCVOuei.text)
   if not('contents' in FvGbPfoWIjgTLlkxRYNymDKcCVOusr):return FvGbPfoWIjgTLlkxRYNymDKcCVOusJ,FvGbPfoWIjgTLlkxRYNymDKcCVOusa
   FvGbPfoWIjgTLlkxRYNymDKcCVOust=FvGbPfoWIjgTLlkxRYNymDKcCVOusr['contents']
   FvGbPfoWIjgTLlkxRYNymDKcCVOusa=FvGbPfoWIjgTLlkxRYNymDKcCVOusr['meta']['has_next']
   for FvGbPfoWIjgTLlkxRYNymDKcCVOusz in FvGbPfoWIjgTLlkxRYNymDKcCVOust:
    FvGbPfoWIjgTLlkxRYNymDKcCVOusX =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['code']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusM=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['content_type']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusB =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['title']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusU =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['story']
    if FvGbPfoWIjgTLlkxRYNymDKcCVOusz['thumbnail']!=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusA =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['thumbnail']['medium']
    else:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusA =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['stillcut']['medium']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusQ =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['year']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusi =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['film_rating_code']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusn=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['film_rating_short']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp={}
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp['mpaa']=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['film_rating_long']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp['year']=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['year']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp['title']=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['title']
    if FvGbPfoWIjgTLlkxRYNymDKcCVOusM=='movies':
     FvGbPfoWIjgTLlkxRYNymDKcCVOusp['mediatype']='movie' 
     FvGbPfoWIjgTLlkxRYNymDKcCVOusp['duration']=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['duration']
    else:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusp['mediatype']='episode' 
    FvGbPfoWIjgTLlkxRYNymDKcCVOusE={'code':FvGbPfoWIjgTLlkxRYNymDKcCVOusX,'content_type':FvGbPfoWIjgTLlkxRYNymDKcCVOusM,'title':FvGbPfoWIjgTLlkxRYNymDKcCVOusB,'story':FvGbPfoWIjgTLlkxRYNymDKcCVOusU,'thumbnail':FvGbPfoWIjgTLlkxRYNymDKcCVOusA,'year':FvGbPfoWIjgTLlkxRYNymDKcCVOusQ,'film_rating_code':FvGbPfoWIjgTLlkxRYNymDKcCVOusi,'film_rating_short':FvGbPfoWIjgTLlkxRYNymDKcCVOusn,'info':FvGbPfoWIjgTLlkxRYNymDKcCVOusp}
    FvGbPfoWIjgTLlkxRYNymDKcCVOusJ.append(FvGbPfoWIjgTLlkxRYNymDKcCVOusE)
  except FvGbPfoWIjgTLlkxRYNymDKcCVOuHt as exception:
   FvGbPfoWIjgTLlkxRYNymDKcCVOuHw(exception)
  return FvGbPfoWIjgTLlkxRYNymDKcCVOusJ,FvGbPfoWIjgTLlkxRYNymDKcCVOusa
 def GetCategoryList_morepage(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,stype,FvGbPfoWIjgTLlkxRYNymDKcCVOusd,FvGbPfoWIjgTLlkxRYNymDKcCVOusq,page_int,in_sort):
  FvGbPfoWIjgTLlkxRYNymDKcCVOusa=FvGbPfoWIjgTLlkxRYNymDKcCVOuHJ
  if not('categories' in FvGbPfoWIjgTLlkxRYNymDKcCVOusq):return FvGbPfoWIjgTLlkxRYNymDKcCVOuHr
  try:
   FvGbPfoWIjgTLlkxRYNymDKcCVOusH ='/api/categories/contents.json'
   FvGbPfoWIjgTLlkxRYNymDKcCVOusS={}
   if stype=='genres':
    FvGbPfoWIjgTLlkxRYNymDKcCVOusS['genre']=FvGbPfoWIjgTLlkxRYNymDKcCVOusd
   else:
    FvGbPfoWIjgTLlkxRYNymDKcCVOusS['tag'] =FvGbPfoWIjgTLlkxRYNymDKcCVOusd
   FvGbPfoWIjgTLlkxRYNymDKcCVOusS['order']=in_sort 
   if page_int>1:
    FvGbPfoWIjgTLlkxRYNymDKcCVOusS['page']=FvGbPfoWIjgTLlkxRYNymDKcCVOuHz(page_int-1)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuea=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeurl(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.API_DOMAIN,FvGbPfoWIjgTLlkxRYNymDKcCVOusH)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuen=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeDefaultCookies()
   FvGbPfoWIjgTLlkxRYNymDKcCVOuei=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.callRequestCookies('Get',FvGbPfoWIjgTLlkxRYNymDKcCVOuea,payload=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,params=FvGbPfoWIjgTLlkxRYNymDKcCVOusS,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,cookies=FvGbPfoWIjgTLlkxRYNymDKcCVOuen)
   FvGbPfoWIjgTLlkxRYNymDKcCVOusr=json.loads(FvGbPfoWIjgTLlkxRYNymDKcCVOuei.text)
   FvGbPfoWIjgTLlkxRYNymDKcCVOusa=FvGbPfoWIjgTLlkxRYNymDKcCVOusr['meta']['has_next']
  except FvGbPfoWIjgTLlkxRYNymDKcCVOuHt as exception:
   FvGbPfoWIjgTLlkxRYNymDKcCVOuHw(exception)
  return FvGbPfoWIjgTLlkxRYNymDKcCVOusa
 def GetEpisodoList(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,program_code,page_int,orderby='asc'):
  FvGbPfoWIjgTLlkxRYNymDKcCVOusJ=[]
  FvGbPfoWIjgTLlkxRYNymDKcCVOusa=FvGbPfoWIjgTLlkxRYNymDKcCVOuHJ
  FvGbPfoWIjgTLlkxRYNymDKcCVOush=''
  try:
   FvGbPfoWIjgTLlkxRYNymDKcCVOusH ='/api/contents/'+program_code+'/tv_episodes.json'
   FvGbPfoWIjgTLlkxRYNymDKcCVOusS={'all':'true'}
   FvGbPfoWIjgTLlkxRYNymDKcCVOuea=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeurl(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.API_DOMAIN,FvGbPfoWIjgTLlkxRYNymDKcCVOusH)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuen=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeDefaultCookies()
   FvGbPfoWIjgTLlkxRYNymDKcCVOuei=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.callRequestCookies('Get',FvGbPfoWIjgTLlkxRYNymDKcCVOuea,payload=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,params=FvGbPfoWIjgTLlkxRYNymDKcCVOusS,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,cookies=FvGbPfoWIjgTLlkxRYNymDKcCVOuen)
   FvGbPfoWIjgTLlkxRYNymDKcCVOusr=json.loads(FvGbPfoWIjgTLlkxRYNymDKcCVOuei.text)
   if not('tv_episode_codes' in FvGbPfoWIjgTLlkxRYNymDKcCVOusr):return FvGbPfoWIjgTLlkxRYNymDKcCVOusJ,FvGbPfoWIjgTLlkxRYNymDKcCVOusa
   FvGbPfoWIjgTLlkxRYNymDKcCVOust=FvGbPfoWIjgTLlkxRYNymDKcCVOusr['tv_episode_codes']
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJe=FvGbPfoWIjgTLlkxRYNymDKcCVOuHq(FvGbPfoWIjgTLlkxRYNymDKcCVOust)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJs =FvGbPfoWIjgTLlkxRYNymDKcCVOuHd(FvGbPfoWIjgTLlkxRYNymDKcCVOuJe//(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    FvGbPfoWIjgTLlkxRYNymDKcCVOuJH =(FvGbPfoWIjgTLlkxRYNymDKcCVOuJe-1)-((page_int-1)*FvGbPfoWIjgTLlkxRYNymDKcCVOueH.EPISODE_LIMIT)
   else:
    FvGbPfoWIjgTLlkxRYNymDKcCVOuJH =(page_int-1)*FvGbPfoWIjgTLlkxRYNymDKcCVOueH.EPISODE_LIMIT
   for i in FvGbPfoWIjgTLlkxRYNymDKcCVOuHE(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.EPISODE_LIMIT):
    if orderby=='desc':
     FvGbPfoWIjgTLlkxRYNymDKcCVOuJr=FvGbPfoWIjgTLlkxRYNymDKcCVOuJH-i
     if FvGbPfoWIjgTLlkxRYNymDKcCVOuJr<0:break
    else:
     FvGbPfoWIjgTLlkxRYNymDKcCVOuJr=FvGbPfoWIjgTLlkxRYNymDKcCVOuJH+i
     if FvGbPfoWIjgTLlkxRYNymDKcCVOuJr>=FvGbPfoWIjgTLlkxRYNymDKcCVOuJe:break
    if FvGbPfoWIjgTLlkxRYNymDKcCVOush!='':FvGbPfoWIjgTLlkxRYNymDKcCVOush+=','
    FvGbPfoWIjgTLlkxRYNymDKcCVOush+=FvGbPfoWIjgTLlkxRYNymDKcCVOust[FvGbPfoWIjgTLlkxRYNymDKcCVOuJr]
   if FvGbPfoWIjgTLlkxRYNymDKcCVOuJs>page_int:FvGbPfoWIjgTLlkxRYNymDKcCVOusa=FvGbPfoWIjgTLlkxRYNymDKcCVOuHr
  except FvGbPfoWIjgTLlkxRYNymDKcCVOuHt as exception:
   FvGbPfoWIjgTLlkxRYNymDKcCVOuHw(exception)
  try:
   FvGbPfoWIjgTLlkxRYNymDKcCVOusS={'codes':FvGbPfoWIjgTLlkxRYNymDKcCVOush}
   FvGbPfoWIjgTLlkxRYNymDKcCVOuea=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeurl(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.API_DOMAIN,FvGbPfoWIjgTLlkxRYNymDKcCVOusH)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuen=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeDefaultCookies()
   FvGbPfoWIjgTLlkxRYNymDKcCVOuei=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.callRequestCookies('Get',FvGbPfoWIjgTLlkxRYNymDKcCVOuea,payload=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,params=FvGbPfoWIjgTLlkxRYNymDKcCVOusS,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,cookies=FvGbPfoWIjgTLlkxRYNymDKcCVOuen)
   FvGbPfoWIjgTLlkxRYNymDKcCVOusr=json.loads(FvGbPfoWIjgTLlkxRYNymDKcCVOuei.text)
   if not('tv_episodes' in FvGbPfoWIjgTLlkxRYNymDKcCVOusr):return FvGbPfoWIjgTLlkxRYNymDKcCVOusJ
   FvGbPfoWIjgTLlkxRYNymDKcCVOust=FvGbPfoWIjgTLlkxRYNymDKcCVOusr['tv_episodes']
   for FvGbPfoWIjgTLlkxRYNymDKcCVOusz in FvGbPfoWIjgTLlkxRYNymDKcCVOust:
    FvGbPfoWIjgTLlkxRYNymDKcCVOusX =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['code']
    if FvGbPfoWIjgTLlkxRYNymDKcCVOusz['title']:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusB =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['title']
    else:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusB =''
    FvGbPfoWIjgTLlkxRYNymDKcCVOusA =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['stillcut']['medium']
    FvGbPfoWIjgTLlkxRYNymDKcCVOuJt =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['display_number']
    FvGbPfoWIjgTLlkxRYNymDKcCVOuJz=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['tv_season_title']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp={}
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp['mediatype'] ='episode'
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp['tvshowtitle']=FvGbPfoWIjgTLlkxRYNymDKcCVOusB if FvGbPfoWIjgTLlkxRYNymDKcCVOusB else FvGbPfoWIjgTLlkxRYNymDKcCVOuJz
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp['title'] ='%s %s'%(FvGbPfoWIjgTLlkxRYNymDKcCVOuJz,FvGbPfoWIjgTLlkxRYNymDKcCVOuJt)if FvGbPfoWIjgTLlkxRYNymDKcCVOusB else FvGbPfoWIjgTLlkxRYNymDKcCVOuJt
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp['duration'] =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['duration']
    try:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusp['episode']=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['episode_number']
    except:
     FvGbPfoWIjgTLlkxRYNymDKcCVOuHs
    FvGbPfoWIjgTLlkxRYNymDKcCVOusE={'code':FvGbPfoWIjgTLlkxRYNymDKcCVOusX,'title':FvGbPfoWIjgTLlkxRYNymDKcCVOusB,'thumbnail':FvGbPfoWIjgTLlkxRYNymDKcCVOusA,'display_num':FvGbPfoWIjgTLlkxRYNymDKcCVOuJt,'season_title':FvGbPfoWIjgTLlkxRYNymDKcCVOuJz,'info':FvGbPfoWIjgTLlkxRYNymDKcCVOusp}
    FvGbPfoWIjgTLlkxRYNymDKcCVOusJ.append(FvGbPfoWIjgTLlkxRYNymDKcCVOusE)
  except FvGbPfoWIjgTLlkxRYNymDKcCVOuHt as exception:
   FvGbPfoWIjgTLlkxRYNymDKcCVOuHw(exception)
  return FvGbPfoWIjgTLlkxRYNymDKcCVOusJ,FvGbPfoWIjgTLlkxRYNymDKcCVOusa
 def GetSearchList(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,search_key,page_int):
  FvGbPfoWIjgTLlkxRYNymDKcCVOuJw=[]
  FvGbPfoWIjgTLlkxRYNymDKcCVOusa=FvGbPfoWIjgTLlkxRYNymDKcCVOuHJ
  try:
   FvGbPfoWIjgTLlkxRYNymDKcCVOusH ='/api/search.json'
   FvGbPfoWIjgTLlkxRYNymDKcCVOusS={'query':search_key,'page':FvGbPfoWIjgTLlkxRYNymDKcCVOuHz(page_int),'per':FvGbPfoWIjgTLlkxRYNymDKcCVOuHz(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.SEARCH_LIMIT),'exclude':'limited'}
   FvGbPfoWIjgTLlkxRYNymDKcCVOuea=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeurl(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.API_DOMAIN,FvGbPfoWIjgTLlkxRYNymDKcCVOusH)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuen=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeDefaultCookies()
   FvGbPfoWIjgTLlkxRYNymDKcCVOuei=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.callRequestCookies('Get',FvGbPfoWIjgTLlkxRYNymDKcCVOuea,payload=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,params=FvGbPfoWIjgTLlkxRYNymDKcCVOusS,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,cookies=FvGbPfoWIjgTLlkxRYNymDKcCVOuen)
   FvGbPfoWIjgTLlkxRYNymDKcCVOusr=json.loads(FvGbPfoWIjgTLlkxRYNymDKcCVOuei.text)
   if not('results' in FvGbPfoWIjgTLlkxRYNymDKcCVOusr):return FvGbPfoWIjgTLlkxRYNymDKcCVOuJw,FvGbPfoWIjgTLlkxRYNymDKcCVOusa
   FvGbPfoWIjgTLlkxRYNymDKcCVOust=FvGbPfoWIjgTLlkxRYNymDKcCVOusr['results']
   FvGbPfoWIjgTLlkxRYNymDKcCVOusa=FvGbPfoWIjgTLlkxRYNymDKcCVOusr['meta']['has_next']
   for FvGbPfoWIjgTLlkxRYNymDKcCVOusz in FvGbPfoWIjgTLlkxRYNymDKcCVOust:
    FvGbPfoWIjgTLlkxRYNymDKcCVOusX =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['code']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusM=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['content_type']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusB =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['title']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusU =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['story']
    if FvGbPfoWIjgTLlkxRYNymDKcCVOusz['thumbnail']!=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusA =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['thumbnail']['medium']
    else:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusA =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['stillcut']['medium']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusQ =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['year']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusi =FvGbPfoWIjgTLlkxRYNymDKcCVOusz['film_rating_code']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusn=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['film_rating_short']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp={}
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp['mpaa']=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['film_rating_long']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp['year']=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['year']
    FvGbPfoWIjgTLlkxRYNymDKcCVOusp['title']=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['title']
    if FvGbPfoWIjgTLlkxRYNymDKcCVOusM=='movies':
     FvGbPfoWIjgTLlkxRYNymDKcCVOusp['mediatype']='movie' 
     FvGbPfoWIjgTLlkxRYNymDKcCVOusp['duration']=FvGbPfoWIjgTLlkxRYNymDKcCVOusz['duration']
    else:
     FvGbPfoWIjgTLlkxRYNymDKcCVOusp['mediatype']='episode' 
    FvGbPfoWIjgTLlkxRYNymDKcCVOusE={'code':FvGbPfoWIjgTLlkxRYNymDKcCVOusX,'content_type':FvGbPfoWIjgTLlkxRYNymDKcCVOusM,'title':FvGbPfoWIjgTLlkxRYNymDKcCVOusB,'story':FvGbPfoWIjgTLlkxRYNymDKcCVOusU,'thumbnail':FvGbPfoWIjgTLlkxRYNymDKcCVOusA,'year':FvGbPfoWIjgTLlkxRYNymDKcCVOusQ,'film_rating_code':FvGbPfoWIjgTLlkxRYNymDKcCVOusi,'film_rating_short':FvGbPfoWIjgTLlkxRYNymDKcCVOusn,'info':FvGbPfoWIjgTLlkxRYNymDKcCVOusp}
    FvGbPfoWIjgTLlkxRYNymDKcCVOuJw.append(FvGbPfoWIjgTLlkxRYNymDKcCVOusE)
  except FvGbPfoWIjgTLlkxRYNymDKcCVOuHt as exception:
   FvGbPfoWIjgTLlkxRYNymDKcCVOuHw(exception)
  return FvGbPfoWIjgTLlkxRYNymDKcCVOuJw,FvGbPfoWIjgTLlkxRYNymDKcCVOusa
 def GetProfilesList(FvGbPfoWIjgTLlkxRYNymDKcCVOueH):
  FvGbPfoWIjgTLlkxRYNymDKcCVOueh=[]
  try:
   FvGbPfoWIjgTLlkxRYNymDKcCVOusH ='/manage_profiles'
   FvGbPfoWIjgTLlkxRYNymDKcCVOuea=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeurl(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.API_DOMAIN,FvGbPfoWIjgTLlkxRYNymDKcCVOusH)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuen=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeDefaultCookies()
   FvGbPfoWIjgTLlkxRYNymDKcCVOuei=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.callRequestCookies('Get',FvGbPfoWIjgTLlkxRYNymDKcCVOuea,payload=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,params=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,cookies=FvGbPfoWIjgTLlkxRYNymDKcCVOuen)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJq=FvGbPfoWIjgTLlkxRYNymDKcCVOuei.text
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJd =re.findall('/api/users/me.{5000}',FvGbPfoWIjgTLlkxRYNymDKcCVOuJq)[0]
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJd =FvGbPfoWIjgTLlkxRYNymDKcCVOuJd.replace('&quot;','')
   FvGbPfoWIjgTLlkxRYNymDKcCVOueh=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',FvGbPfoWIjgTLlkxRYNymDKcCVOuJd)
   for i in FvGbPfoWIjgTLlkxRYNymDKcCVOuHE(FvGbPfoWIjgTLlkxRYNymDKcCVOuHq(FvGbPfoWIjgTLlkxRYNymDKcCVOueh)):
    FvGbPfoWIjgTLlkxRYNymDKcCVOuJE=FvGbPfoWIjgTLlkxRYNymDKcCVOueh[i]
    FvGbPfoWIjgTLlkxRYNymDKcCVOuJE =FvGbPfoWIjgTLlkxRYNymDKcCVOuJE.split(':')[1]
    FvGbPfoWIjgTLlkxRYNymDKcCVOueh[i]=FvGbPfoWIjgTLlkxRYNymDKcCVOuJE.split(',')[0]
  except FvGbPfoWIjgTLlkxRYNymDKcCVOuHt as exception:
   FvGbPfoWIjgTLlkxRYNymDKcCVOuHw(exception)
  return FvGbPfoWIjgTLlkxRYNymDKcCVOueh
 def GetProfilesConvert(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,FvGbPfoWIjgTLlkxRYNymDKcCVOuew):
  FvGbPfoWIjgTLlkxRYNymDKcCVOuJa=''
  FvGbPfoWIjgTLlkxRYNymDKcCVOuJS=''
  try:
   FvGbPfoWIjgTLlkxRYNymDKcCVOusH ='/api/users/'+FvGbPfoWIjgTLlkxRYNymDKcCVOuew+'/convert'
   FvGbPfoWIjgTLlkxRYNymDKcCVOuea=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeurl(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.API_DOMAIN,FvGbPfoWIjgTLlkxRYNymDKcCVOusH)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuen=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeDefaultCookies()
   FvGbPfoWIjgTLlkxRYNymDKcCVOuei=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.callRequestCookies('Put',FvGbPfoWIjgTLlkxRYNymDKcCVOuea,payload=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,params=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,cookies=FvGbPfoWIjgTLlkxRYNymDKcCVOuen)
   for FvGbPfoWIjgTLlkxRYNymDKcCVOuen in FvGbPfoWIjgTLlkxRYNymDKcCVOuei.cookies:
    if FvGbPfoWIjgTLlkxRYNymDKcCVOuen.name=='_s_guitv':
     FvGbPfoWIjgTLlkxRYNymDKcCVOuJX=FvGbPfoWIjgTLlkxRYNymDKcCVOuen.value
    elif FvGbPfoWIjgTLlkxRYNymDKcCVOuen.name=='_guinness-premium_session':
     FvGbPfoWIjgTLlkxRYNymDKcCVOuep=FvGbPfoWIjgTLlkxRYNymDKcCVOuen.value
   if FvGbPfoWIjgTLlkxRYNymDKcCVOuJX:
    FvGbPfoWIjgTLlkxRYNymDKcCVOuJa=FvGbPfoWIjgTLlkxRYNymDKcCVOuJX
   if FvGbPfoWIjgTLlkxRYNymDKcCVOuep:
    FvGbPfoWIjgTLlkxRYNymDKcCVOuJS=FvGbPfoWIjgTLlkxRYNymDKcCVOuep
  except FvGbPfoWIjgTLlkxRYNymDKcCVOuHt as exception:
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJa=''
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJS=''
  return FvGbPfoWIjgTLlkxRYNymDKcCVOuJa,FvGbPfoWIjgTLlkxRYNymDKcCVOuJS
 def Get_Now_Datetime(FvGbPfoWIjgTLlkxRYNymDKcCVOueH):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(FvGbPfoWIjgTLlkxRYNymDKcCVOueH,movie_code,quality_str):
  FvGbPfoWIjgTLlkxRYNymDKcCVOuJB=FvGbPfoWIjgTLlkxRYNymDKcCVOuJA=FvGbPfoWIjgTLlkxRYNymDKcCVOuJh=''
  try:
   FvGbPfoWIjgTLlkxRYNymDKcCVOusH='/api/watch/'+movie_code+'.json'
   FvGbPfoWIjgTLlkxRYNymDKcCVOuea=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeurl(FvGbPfoWIjgTLlkxRYNymDKcCVOueH.API_DOMAIN,FvGbPfoWIjgTLlkxRYNymDKcCVOusH)
   FvGbPfoWIjgTLlkxRYNymDKcCVOueQ={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   FvGbPfoWIjgTLlkxRYNymDKcCVOuen=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.makeDefaultCookies()
   FvGbPfoWIjgTLlkxRYNymDKcCVOuei=FvGbPfoWIjgTLlkxRYNymDKcCVOueH.callRequestCookies('Get',FvGbPfoWIjgTLlkxRYNymDKcCVOuea,payload=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,params=FvGbPfoWIjgTLlkxRYNymDKcCVOuHs,headers=FvGbPfoWIjgTLlkxRYNymDKcCVOueQ,cookies=FvGbPfoWIjgTLlkxRYNymDKcCVOuen)
   FvGbPfoWIjgTLlkxRYNymDKcCVOusr=json.loads(FvGbPfoWIjgTLlkxRYNymDKcCVOuei.text)
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJB=FvGbPfoWIjgTLlkxRYNymDKcCVOusr['streams'][0]['source']
   if FvGbPfoWIjgTLlkxRYNymDKcCVOuJB==FvGbPfoWIjgTLlkxRYNymDKcCVOuHs:return(FvGbPfoWIjgTLlkxRYNymDKcCVOuJB,FvGbPfoWIjgTLlkxRYNymDKcCVOuJA,FvGbPfoWIjgTLlkxRYNymDKcCVOuJh)
   if 'subtitles' in FvGbPfoWIjgTLlkxRYNymDKcCVOusr['streams'][0]:
    for FvGbPfoWIjgTLlkxRYNymDKcCVOuJU in FvGbPfoWIjgTLlkxRYNymDKcCVOusr['streams'][0]['subtitles']:
     if FvGbPfoWIjgTLlkxRYNymDKcCVOuJU['lang']=='ko':
      FvGbPfoWIjgTLlkxRYNymDKcCVOuJA=FvGbPfoWIjgTLlkxRYNymDKcCVOuJU['url']
      break
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJQ =FvGbPfoWIjgTLlkxRYNymDKcCVOusr['ping_payload']
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJi =FvGbPfoWIjgTLlkxRYNymDKcCVOueH.WATCHA_USERCD
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJn={'merchant':'giitd_frograms','sessionId':FvGbPfoWIjgTLlkxRYNymDKcCVOuJQ,'userId':FvGbPfoWIjgTLlkxRYNymDKcCVOuJi}
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJp=json.dumps(FvGbPfoWIjgTLlkxRYNymDKcCVOuJn,separators=(",",":")).encode('UTF-8')
   FvGbPfoWIjgTLlkxRYNymDKcCVOuJh=base64.b64encode(FvGbPfoWIjgTLlkxRYNymDKcCVOuJp)
  except FvGbPfoWIjgTLlkxRYNymDKcCVOuHt as exception:
   return(FvGbPfoWIjgTLlkxRYNymDKcCVOuJB,FvGbPfoWIjgTLlkxRYNymDKcCVOuJA,FvGbPfoWIjgTLlkxRYNymDKcCVOuJh)
  return(FvGbPfoWIjgTLlkxRYNymDKcCVOuJB,FvGbPfoWIjgTLlkxRYNymDKcCVOuJA,FvGbPfoWIjgTLlkxRYNymDKcCVOuJh) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
