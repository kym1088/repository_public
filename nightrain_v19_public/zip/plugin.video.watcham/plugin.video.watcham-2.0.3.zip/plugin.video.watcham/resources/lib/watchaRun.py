__author__="NightRain"
TfcusSBAxHyJpWVvbMCeUXidgEQkrG=object
TfcusSBAxHyJpWVvbMCeUXidgEQkrl=None
TfcusSBAxHyJpWVvbMCeUXidgEQkrt=False
TfcusSBAxHyJpWVvbMCeUXidgEQkzO=int
TfcusSBAxHyJpWVvbMCeUXidgEQkzn=True
TfcusSBAxHyJpWVvbMCeUXidgEQkzK=len
TfcusSBAxHyJpWVvbMCeUXidgEQkza=range
TfcusSBAxHyJpWVvbMCeUXidgEQkzr=str
TfcusSBAxHyJpWVvbMCeUXidgEQkzY=open
TfcusSBAxHyJpWVvbMCeUXidgEQkzF=dict
TfcusSBAxHyJpWVvbMCeUXidgEQkzL=Exception
TfcusSBAxHyJpWVvbMCeUXidgEQkzI=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
TfcusSBAxHyJpWVvbMCeUXidgEQkOK=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'검색 (search)','mode':'SEARCH','stype':'-','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-'}]
TfcusSBAxHyJpWVvbMCeUXidgEQkOa=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
TfcusSBAxHyJpWVvbMCeUXidgEQkOr=40
TfcusSBAxHyJpWVvbMCeUXidgEQkOz =20
TfcusSBAxHyJpWVvbMCeUXidgEQkOY='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
TfcusSBAxHyJpWVvbMCeUXidgEQkOF =xbmc.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
TfcusSBAxHyJpWVvbMCeUXidgEQkOL=xbmc.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class TfcusSBAxHyJpWVvbMCeUXidgEQkOn(TfcusSBAxHyJpWVvbMCeUXidgEQkrG):
 def __init__(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,TfcusSBAxHyJpWVvbMCeUXidgEQkOw,TfcusSBAxHyJpWVvbMCeUXidgEQkOj,TfcusSBAxHyJpWVvbMCeUXidgEQkOP):
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_url =TfcusSBAxHyJpWVvbMCeUXidgEQkOw
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_handle=TfcusSBAxHyJpWVvbMCeUXidgEQkOj
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.main_params =TfcusSBAxHyJpWVvbMCeUXidgEQkOP
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj =FvGbPfoWIjgTLlkxRYNymDKcCVOues() 
 def addon_noti(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,sting):
  try:
   TfcusSBAxHyJpWVvbMCeUXidgEQkOD=xbmcgui.Dialog()
   TfcusSBAxHyJpWVvbMCeUXidgEQkOD.notification(__addonname__,sting)
  except:
   TfcusSBAxHyJpWVvbMCeUXidgEQkrl
 def addon_log(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,string,isDebug=TfcusSBAxHyJpWVvbMCeUXidgEQkrt):
  try:
   TfcusSBAxHyJpWVvbMCeUXidgEQkOh=string.encode('utf-8','ignore')
  except:
   TfcusSBAxHyJpWVvbMCeUXidgEQkOh='addonException: addon_log'
  if isDebug:TfcusSBAxHyJpWVvbMCeUXidgEQkOm=xbmc.LOGDEBUG
  else:TfcusSBAxHyJpWVvbMCeUXidgEQkOm=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,TfcusSBAxHyJpWVvbMCeUXidgEQkOh),level=TfcusSBAxHyJpWVvbMCeUXidgEQkOm)
 def get_keyboard_input(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,TfcusSBAxHyJpWVvbMCeUXidgEQknY):
  TfcusSBAxHyJpWVvbMCeUXidgEQkOR=TfcusSBAxHyJpWVvbMCeUXidgEQkrl
  kb=xbmc.Keyboard()
  kb.setHeading(TfcusSBAxHyJpWVvbMCeUXidgEQknY)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   TfcusSBAxHyJpWVvbMCeUXidgEQkOR=kb.getText()
  return TfcusSBAxHyJpWVvbMCeUXidgEQkOR
 def get_settings_login_info(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  TfcusSBAxHyJpWVvbMCeUXidgEQkOq =__addon__.getSetting('id')
  TfcusSBAxHyJpWVvbMCeUXidgEQkON =__addon__.getSetting('pw')
  TfcusSBAxHyJpWVvbMCeUXidgEQkOG=TfcusSBAxHyJpWVvbMCeUXidgEQkzO(__addon__.getSetting('selected_profile'))
  return(TfcusSBAxHyJpWVvbMCeUXidgEQkOq,TfcusSBAxHyJpWVvbMCeUXidgEQkON,TfcusSBAxHyJpWVvbMCeUXidgEQkOG)
 def get_selQuality(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  try:
   TfcusSBAxHyJpWVvbMCeUXidgEQkOl=['3840x2160/1','1920x1080/1','1280x720/1']
   TfcusSBAxHyJpWVvbMCeUXidgEQkOt=TfcusSBAxHyJpWVvbMCeUXidgEQkzO(__addon__.getSetting('selected_quality'))
   return TfcusSBAxHyJpWVvbMCeUXidgEQkOl[TfcusSBAxHyJpWVvbMCeUXidgEQkOt]
  except:
   TfcusSBAxHyJpWVvbMCeUXidgEQkrl
  return 1080 
 def get_settings_direct_replay(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  TfcusSBAxHyJpWVvbMCeUXidgEQknO=TfcusSBAxHyJpWVvbMCeUXidgEQkzO(__addon__.getSetting('direct_replay'))
  if TfcusSBAxHyJpWVvbMCeUXidgEQknO==0:
   return TfcusSBAxHyJpWVvbMCeUXidgEQkrt
  else:
   return TfcusSBAxHyJpWVvbMCeUXidgEQkzn
 def set_winCredential(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,credential):
  TfcusSBAxHyJpWVvbMCeUXidgEQknK=xbmcgui.Window(10000)
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_LOGINTIME',TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  TfcusSBAxHyJpWVvbMCeUXidgEQknK=xbmcgui.Window(10000)
  TfcusSBAxHyJpWVvbMCeUXidgEQkna={'watcha_token':TfcusSBAxHyJpWVvbMCeUXidgEQknK.getProperty('WATCHA_M_TOKEN'),'watcha_guit':TfcusSBAxHyJpWVvbMCeUXidgEQknK.getProperty('WATCHA_M_GUIT'),'watcha_guitv':TfcusSBAxHyJpWVvbMCeUXidgEQknK.getProperty('WATCHA_M_GUITV'),'watcha_usercd':TfcusSBAxHyJpWVvbMCeUXidgEQknK.getProperty('WATCHA_M_USERCD')}
  return TfcusSBAxHyJpWVvbMCeUXidgEQkna
 def set_winEpisodeOrderby(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,TfcusSBAxHyJpWVvbMCeUXidgEQknr):
  TfcusSBAxHyJpWVvbMCeUXidgEQknK=xbmcgui.Window(10000)
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_ORDERBY',TfcusSBAxHyJpWVvbMCeUXidgEQknr)
 def get_winEpisodeOrderby(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  TfcusSBAxHyJpWVvbMCeUXidgEQknK=xbmcgui.Window(10000)
  return TfcusSBAxHyJpWVvbMCeUXidgEQknK.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,args):
  TfcusSBAxHyJpWVvbMCeUXidgEQknr =args.get('orderby')
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.set_winEpisodeOrderby(TfcusSBAxHyJpWVvbMCeUXidgEQknr)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,label,sublabel='',img='',infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkrl,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQkzn,params=''):
  TfcusSBAxHyJpWVvbMCeUXidgEQknz='%s?%s'%(TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_url,urllib.parse.urlencode(params))
  if sublabel:TfcusSBAxHyJpWVvbMCeUXidgEQknY='%s < %s >'%(label,sublabel)
  else: TfcusSBAxHyJpWVvbMCeUXidgEQknY=label
  if not img:img='DefaultFolder.png'
  TfcusSBAxHyJpWVvbMCeUXidgEQknF=xbmcgui.ListItem(TfcusSBAxHyJpWVvbMCeUXidgEQknY)
  TfcusSBAxHyJpWVvbMCeUXidgEQknF.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:TfcusSBAxHyJpWVvbMCeUXidgEQknF.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:TfcusSBAxHyJpWVvbMCeUXidgEQknF.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_handle,TfcusSBAxHyJpWVvbMCeUXidgEQknz,TfcusSBAxHyJpWVvbMCeUXidgEQknF,isFolder)
 def dp_Main_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  for TfcusSBAxHyJpWVvbMCeUXidgEQknL in TfcusSBAxHyJpWVvbMCeUXidgEQkOK:
   TfcusSBAxHyJpWVvbMCeUXidgEQknY=TfcusSBAxHyJpWVvbMCeUXidgEQknL.get('title')
   TfcusSBAxHyJpWVvbMCeUXidgEQknI={'mode':TfcusSBAxHyJpWVvbMCeUXidgEQknL.get('mode'),'stype':TfcusSBAxHyJpWVvbMCeUXidgEQknL.get('stype'),'api_path':TfcusSBAxHyJpWVvbMCeUXidgEQknL.get('api_path'),'page':'1','sort':TfcusSBAxHyJpWVvbMCeUXidgEQknL.get('sort'),'tag_id':'-'}
   if TfcusSBAxHyJpWVvbMCeUXidgEQknL.get('mode')=='XXX':
    TfcusSBAxHyJpWVvbMCeUXidgEQknI['mode']='XXX'
    TfcusSBAxHyJpWVvbMCeUXidgEQknw=TfcusSBAxHyJpWVvbMCeUXidgEQkrt
   else:
    TfcusSBAxHyJpWVvbMCeUXidgEQknw=TfcusSBAxHyJpWVvbMCeUXidgEQkzn
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel='',img='',infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkrl,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQknw,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkzK(TfcusSBAxHyJpWVvbMCeUXidgEQkOK)>0:xbmcplugin.endOfDirectory(TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_handle)
 def login_main(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  (TfcusSBAxHyJpWVvbMCeUXidgEQknP,TfcusSBAxHyJpWVvbMCeUXidgEQkno,TfcusSBAxHyJpWVvbMCeUXidgEQknD)=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_settings_login_info()
  if not(TfcusSBAxHyJpWVvbMCeUXidgEQknP and TfcusSBAxHyJpWVvbMCeUXidgEQkno):
   TfcusSBAxHyJpWVvbMCeUXidgEQkOD=xbmcgui.Dialog()
   TfcusSBAxHyJpWVvbMCeUXidgEQknh=TfcusSBAxHyJpWVvbMCeUXidgEQkOD.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if TfcusSBAxHyJpWVvbMCeUXidgEQknh==TfcusSBAxHyJpWVvbMCeUXidgEQkzn:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_winEpisodeOrderby()=='':
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.set_winEpisodeOrderby('asc')
  if TfcusSBAxHyJpWVvbMCeUXidgEQkOI.cookiefile_check():return
  TfcusSBAxHyJpWVvbMCeUXidgEQknm =TfcusSBAxHyJpWVvbMCeUXidgEQkzO(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  TfcusSBAxHyJpWVvbMCeUXidgEQknR=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if TfcusSBAxHyJpWVvbMCeUXidgEQknR==TfcusSBAxHyJpWVvbMCeUXidgEQkrl or TfcusSBAxHyJpWVvbMCeUXidgEQknR=='':TfcusSBAxHyJpWVvbMCeUXidgEQknR=TfcusSBAxHyJpWVvbMCeUXidgEQkzO('19000101')
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   TfcusSBAxHyJpWVvbMCeUXidgEQknq=0
   while TfcusSBAxHyJpWVvbMCeUXidgEQkzn:
    TfcusSBAxHyJpWVvbMCeUXidgEQknq+=1
    time.sleep(0.05)
    if TfcusSBAxHyJpWVvbMCeUXidgEQknR>=TfcusSBAxHyJpWVvbMCeUXidgEQknm:return
    if TfcusSBAxHyJpWVvbMCeUXidgEQknq>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if TfcusSBAxHyJpWVvbMCeUXidgEQknR>=TfcusSBAxHyJpWVvbMCeUXidgEQknm:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.GetCredential(TfcusSBAxHyJpWVvbMCeUXidgEQknP,TfcusSBAxHyJpWVvbMCeUXidgEQkno,TfcusSBAxHyJpWVvbMCeUXidgEQknD):
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.set_winCredential(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.LoadCredential())
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,args):
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.SaveCredential(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_winCredential())
  TfcusSBAxHyJpWVvbMCeUXidgEQknN =args.get('stype')
  TfcusSBAxHyJpWVvbMCeUXidgEQknG =TfcusSBAxHyJpWVvbMCeUXidgEQkzO(args.get('page'))
  TfcusSBAxHyJpWVvbMCeUXidgEQknl =args.get('sort')
  TfcusSBAxHyJpWVvbMCeUXidgEQknt=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.GetSubGroupList(TfcusSBAxHyJpWVvbMCeUXidgEQknN)
  TfcusSBAxHyJpWVvbMCeUXidgEQkKO=TfcusSBAxHyJpWVvbMCeUXidgEQkOr if TfcusSBAxHyJpWVvbMCeUXidgEQknN=='genres' else TfcusSBAxHyJpWVvbMCeUXidgEQkOz
  TfcusSBAxHyJpWVvbMCeUXidgEQkKn=TfcusSBAxHyJpWVvbMCeUXidgEQkzK(TfcusSBAxHyJpWVvbMCeUXidgEQknt)
  TfcusSBAxHyJpWVvbMCeUXidgEQkKa =TfcusSBAxHyJpWVvbMCeUXidgEQkzO(TfcusSBAxHyJpWVvbMCeUXidgEQkKn//(TfcusSBAxHyJpWVvbMCeUXidgEQkKO+1))+1
  TfcusSBAxHyJpWVvbMCeUXidgEQkKr =(TfcusSBAxHyJpWVvbMCeUXidgEQknG-1)*TfcusSBAxHyJpWVvbMCeUXidgEQkKO
  for i in TfcusSBAxHyJpWVvbMCeUXidgEQkza(TfcusSBAxHyJpWVvbMCeUXidgEQkKO):
   TfcusSBAxHyJpWVvbMCeUXidgEQkKz=TfcusSBAxHyJpWVvbMCeUXidgEQkKr+i
   if TfcusSBAxHyJpWVvbMCeUXidgEQkKz>=TfcusSBAxHyJpWVvbMCeUXidgEQkKn:break
   TfcusSBAxHyJpWVvbMCeUXidgEQknY =TfcusSBAxHyJpWVvbMCeUXidgEQknt[TfcusSBAxHyJpWVvbMCeUXidgEQkKz].get('group_name')
   TfcusSBAxHyJpWVvbMCeUXidgEQkKY =TfcusSBAxHyJpWVvbMCeUXidgEQknt[TfcusSBAxHyJpWVvbMCeUXidgEQkKz].get('api_path')
   TfcusSBAxHyJpWVvbMCeUXidgEQkKF =TfcusSBAxHyJpWVvbMCeUXidgEQknt[TfcusSBAxHyJpWVvbMCeUXidgEQkKz].get('tag_id')
   TfcusSBAxHyJpWVvbMCeUXidgEQknI={'mode':'CATEGORY_LIST','api_path':TfcusSBAxHyJpWVvbMCeUXidgEQkKY,'tag_id':TfcusSBAxHyJpWVvbMCeUXidgEQkKF,'stype':TfcusSBAxHyJpWVvbMCeUXidgEQknN,'page':'1','sort':TfcusSBAxHyJpWVvbMCeUXidgEQknl}
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel='',img='',infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkrl,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQkzn,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkKa>TfcusSBAxHyJpWVvbMCeUXidgEQknG:
   TfcusSBAxHyJpWVvbMCeUXidgEQknI={}
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['mode'] ='SUB_GROUP' 
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['stype'] =TfcusSBAxHyJpWVvbMCeUXidgEQknN
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['api_path']=args.get('api_path')
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['page'] =TfcusSBAxHyJpWVvbMCeUXidgEQkzr(TfcusSBAxHyJpWVvbMCeUXidgEQknG+1)
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['sort'] =TfcusSBAxHyJpWVvbMCeUXidgEQknl
   TfcusSBAxHyJpWVvbMCeUXidgEQknY='[B]%s >>[/B]'%'다음 페이지'
   TfcusSBAxHyJpWVvbMCeUXidgEQkKL=TfcusSBAxHyJpWVvbMCeUXidgEQkzr(TfcusSBAxHyJpWVvbMCeUXidgEQknG+1)
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel=TfcusSBAxHyJpWVvbMCeUXidgEQkKL,img='',infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkrl,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQkzn,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkzK(TfcusSBAxHyJpWVvbMCeUXidgEQknt)>0:xbmcplugin.endOfDirectory(TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_handle,cacheToDisc=TfcusSBAxHyJpWVvbMCeUXidgEQkzn)
 def play_VIDEO(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,args):
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.SaveCredential(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_winCredential())
  TfcusSBAxHyJpWVvbMCeUXidgEQkKI =args.get('movie_code')
  TfcusSBAxHyJpWVvbMCeUXidgEQkKw =args.get('season_code')
  TfcusSBAxHyJpWVvbMCeUXidgEQknY =args.get('title')
  TfcusSBAxHyJpWVvbMCeUXidgEQkKj =args.get('thumbnail')
  TfcusSBAxHyJpWVvbMCeUXidgEQkKP =TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_selQuality()
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.addon_log(TfcusSBAxHyJpWVvbMCeUXidgEQkKI+' - '+TfcusSBAxHyJpWVvbMCeUXidgEQkKw,TfcusSBAxHyJpWVvbMCeUXidgEQkrt)
  TfcusSBAxHyJpWVvbMCeUXidgEQkKo,TfcusSBAxHyJpWVvbMCeUXidgEQkKD,TfcusSBAxHyJpWVvbMCeUXidgEQkKh=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.GetStreamingURL(TfcusSBAxHyJpWVvbMCeUXidgEQkKI,TfcusSBAxHyJpWVvbMCeUXidgEQkKP)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkKo=='':
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.addon_noti(__language__(30908).encode('utf8'))
   return
  TfcusSBAxHyJpWVvbMCeUXidgEQkKm=TfcusSBAxHyJpWVvbMCeUXidgEQkKo
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.addon_log(TfcusSBAxHyJpWVvbMCeUXidgEQkKm,TfcusSBAxHyJpWVvbMCeUXidgEQkrt)
  TfcusSBAxHyJpWVvbMCeUXidgEQkKR=xbmcgui.ListItem(path=TfcusSBAxHyJpWVvbMCeUXidgEQkKm)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkKh:
   TfcusSBAxHyJpWVvbMCeUXidgEQkKq=TfcusSBAxHyJpWVvbMCeUXidgEQkKh
   TfcusSBAxHyJpWVvbMCeUXidgEQkKN ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   TfcusSBAxHyJpWVvbMCeUXidgEQkKG ='mpd'
   TfcusSBAxHyJpWVvbMCeUXidgEQkKl ='com.widevine.alpha'
   TfcusSBAxHyJpWVvbMCeUXidgEQkKt =inputstreamhelper.Helper(TfcusSBAxHyJpWVvbMCeUXidgEQkKG,drm=TfcusSBAxHyJpWVvbMCeUXidgEQkKl)
   if TfcusSBAxHyJpWVvbMCeUXidgEQkKt.check_inputstream():
    TfcusSBAxHyJpWVvbMCeUXidgEQkaO={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+TfcusSBAxHyJpWVvbMCeUXidgEQkKI,'dt-custom-data':TfcusSBAxHyJpWVvbMCeUXidgEQkKq,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':TfcusSBAxHyJpWVvbMCeUXidgEQkOY,'Content-Type':'application/octet-stream'}
    TfcusSBAxHyJpWVvbMCeUXidgEQkan=TfcusSBAxHyJpWVvbMCeUXidgEQkKN+'|'+urllib.parse.urlencode(TfcusSBAxHyJpWVvbMCeUXidgEQkaO)+'|R{SSM}|'
    TfcusSBAxHyJpWVvbMCeUXidgEQkOI.addon_log(TfcusSBAxHyJpWVvbMCeUXidgEQkan)
    TfcusSBAxHyJpWVvbMCeUXidgEQkKR.setProperty('inputstream',TfcusSBAxHyJpWVvbMCeUXidgEQkKt.inputstream_addon)
    TfcusSBAxHyJpWVvbMCeUXidgEQkKR.setProperty('inputstream.adaptive.manifest_type',TfcusSBAxHyJpWVvbMCeUXidgEQkKG)
    TfcusSBAxHyJpWVvbMCeUXidgEQkKR.setProperty('inputstream.adaptive.license_type',TfcusSBAxHyJpWVvbMCeUXidgEQkKl)
    TfcusSBAxHyJpWVvbMCeUXidgEQkKR.setProperty('inputstream.adaptive.license_key',TfcusSBAxHyJpWVvbMCeUXidgEQkan)
    TfcusSBAxHyJpWVvbMCeUXidgEQkKR.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(TfcusSBAxHyJpWVvbMCeUXidgEQkOY))
  if TfcusSBAxHyJpWVvbMCeUXidgEQkKD:
   try:
    f=TfcusSBAxHyJpWVvbMCeUXidgEQkzY(TfcusSBAxHyJpWVvbMCeUXidgEQkOF,'w',-1,'utf-8')
    TfcusSBAxHyJpWVvbMCeUXidgEQkaK=requests.get(TfcusSBAxHyJpWVvbMCeUXidgEQkKD)
    TfcusSBAxHyJpWVvbMCeUXidgEQkar=TfcusSBAxHyJpWVvbMCeUXidgEQkaK.content.decode('utf-8') 
    for TfcusSBAxHyJpWVvbMCeUXidgEQkaz in TfcusSBAxHyJpWVvbMCeUXidgEQkar.splitlines():
     TfcusSBAxHyJpWVvbMCeUXidgEQkaY=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',TfcusSBAxHyJpWVvbMCeUXidgEQkaz)
     f.write(TfcusSBAxHyJpWVvbMCeUXidgEQkaY+'\n')
    f.close()
    TfcusSBAxHyJpWVvbMCeUXidgEQkKR.setSubtitles([TfcusSBAxHyJpWVvbMCeUXidgEQkOF,TfcusSBAxHyJpWVvbMCeUXidgEQkKD])
   except:
    TfcusSBAxHyJpWVvbMCeUXidgEQkKR.setSubtitles([TfcusSBAxHyJpWVvbMCeUXidgEQkKD])
  xbmcplugin.setResolvedUrl(TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_handle,TfcusSBAxHyJpWVvbMCeUXidgEQkzn,TfcusSBAxHyJpWVvbMCeUXidgEQkKR)
  try:
   TfcusSBAxHyJpWVvbMCeUXidgEQknN='movie' if TfcusSBAxHyJpWVvbMCeUXidgEQkKw=='-' else 'seasons'
   TfcusSBAxHyJpWVvbMCeUXidgEQknI={'code':TfcusSBAxHyJpWVvbMCeUXidgEQkKI if TfcusSBAxHyJpWVvbMCeUXidgEQknN=='movie' else TfcusSBAxHyJpWVvbMCeUXidgEQkKw,'img':TfcusSBAxHyJpWVvbMCeUXidgEQkKj,'title':TfcusSBAxHyJpWVvbMCeUXidgEQknY,'videoid':TfcusSBAxHyJpWVvbMCeUXidgEQkKI}
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.Save_Watched_List(TfcusSBAxHyJpWVvbMCeUXidgEQknN,TfcusSBAxHyJpWVvbMCeUXidgEQknI)
  except:
   TfcusSBAxHyJpWVvbMCeUXidgEQkrl
 def dp_Category_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,args):
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.SaveCredential(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_winCredential())
  TfcusSBAxHyJpWVvbMCeUXidgEQknN =args.get('stype')
  TfcusSBAxHyJpWVvbMCeUXidgEQkKF =args.get('tag_id')
  TfcusSBAxHyJpWVvbMCeUXidgEQkKY=args.get('api_path')
  TfcusSBAxHyJpWVvbMCeUXidgEQknG=TfcusSBAxHyJpWVvbMCeUXidgEQkzO(args.get('page'))
  TfcusSBAxHyJpWVvbMCeUXidgEQknl =args.get('sort')
  TfcusSBAxHyJpWVvbMCeUXidgEQkaF,TfcusSBAxHyJpWVvbMCeUXidgEQkaL=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.GetCategoryList(TfcusSBAxHyJpWVvbMCeUXidgEQknN,TfcusSBAxHyJpWVvbMCeUXidgEQkKF,TfcusSBAxHyJpWVvbMCeUXidgEQkKY,TfcusSBAxHyJpWVvbMCeUXidgEQknG,TfcusSBAxHyJpWVvbMCeUXidgEQknl)
  for TfcusSBAxHyJpWVvbMCeUXidgEQkaI in TfcusSBAxHyJpWVvbMCeUXidgEQkaF:
   TfcusSBAxHyJpWVvbMCeUXidgEQkKI =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('code')
   TfcusSBAxHyJpWVvbMCeUXidgEQknY =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('title')
   TfcusSBAxHyJpWVvbMCeUXidgEQkaw =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('content_type')
   TfcusSBAxHyJpWVvbMCeUXidgEQkaj =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('story')
   TfcusSBAxHyJpWVvbMCeUXidgEQkKj =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('thumbnail')
   TfcusSBAxHyJpWVvbMCeUXidgEQkaP =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('year')
   TfcusSBAxHyJpWVvbMCeUXidgEQkao =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('film_rating_code')
   TfcusSBAxHyJpWVvbMCeUXidgEQkaD=TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('film_rating_short')
   if TfcusSBAxHyJpWVvbMCeUXidgEQkaw=='movies': 
    TfcusSBAxHyJpWVvbMCeUXidgEQknw=TfcusSBAxHyJpWVvbMCeUXidgEQkrt
    TfcusSBAxHyJpWVvbMCeUXidgEQkah ='MOVIE'
    TfcusSBAxHyJpWVvbMCeUXidgEQknj=''
    TfcusSBAxHyJpWVvbMCeUXidgEQkKw='-'
   else: 
    TfcusSBAxHyJpWVvbMCeUXidgEQknw=TfcusSBAxHyJpWVvbMCeUXidgEQkzn
    TfcusSBAxHyJpWVvbMCeUXidgEQkah ='EPISODE'
    TfcusSBAxHyJpWVvbMCeUXidgEQknj='Series'
    TfcusSBAxHyJpWVvbMCeUXidgEQkKw=TfcusSBAxHyJpWVvbMCeUXidgEQkKI
   TfcusSBAxHyJpWVvbMCeUXidgEQkam=TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('info')
   TfcusSBAxHyJpWVvbMCeUXidgEQkam['plot']='%s (%s)\n년도 : %s\n\n%s'%(TfcusSBAxHyJpWVvbMCeUXidgEQknY,TfcusSBAxHyJpWVvbMCeUXidgEQkaD,TfcusSBAxHyJpWVvbMCeUXidgEQkaP,TfcusSBAxHyJpWVvbMCeUXidgEQkaj)
   if TfcusSBAxHyJpWVvbMCeUXidgEQkao>=19:
    TfcusSBAxHyJpWVvbMCeUXidgEQknY+='  (%s년 - %s)'%(TfcusSBAxHyJpWVvbMCeUXidgEQkaP,TfcusSBAxHyJpWVvbMCeUXidgEQkzr(TfcusSBAxHyJpWVvbMCeUXidgEQkaD))
   else:
    TfcusSBAxHyJpWVvbMCeUXidgEQknY+='  (%s년)'%(TfcusSBAxHyJpWVvbMCeUXidgEQkaP)
   TfcusSBAxHyJpWVvbMCeUXidgEQknI={'mode':TfcusSBAxHyJpWVvbMCeUXidgEQkah,'movie_code':TfcusSBAxHyJpWVvbMCeUXidgEQkKI,'page':'1','season_code':TfcusSBAxHyJpWVvbMCeUXidgEQkKw,'title':TfcusSBAxHyJpWVvbMCeUXidgEQknY,'thumbnail':TfcusSBAxHyJpWVvbMCeUXidgEQkKj}
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel=TfcusSBAxHyJpWVvbMCeUXidgEQknj,img=TfcusSBAxHyJpWVvbMCeUXidgEQkKj,infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkam,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQknw,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkaL:
   if TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.GetCategoryList_morepage(TfcusSBAxHyJpWVvbMCeUXidgEQknN,TfcusSBAxHyJpWVvbMCeUXidgEQkKF,TfcusSBAxHyJpWVvbMCeUXidgEQkKY,TfcusSBAxHyJpWVvbMCeUXidgEQknG+1,TfcusSBAxHyJpWVvbMCeUXidgEQknl):
    TfcusSBAxHyJpWVvbMCeUXidgEQknI={}
    TfcusSBAxHyJpWVvbMCeUXidgEQknI['mode'] ='CATEGORY_LIST'
    TfcusSBAxHyJpWVvbMCeUXidgEQknI['stype'] =TfcusSBAxHyJpWVvbMCeUXidgEQknN
    TfcusSBAxHyJpWVvbMCeUXidgEQknI['tag_id'] =TfcusSBAxHyJpWVvbMCeUXidgEQkKF
    TfcusSBAxHyJpWVvbMCeUXidgEQknI['api_path']=TfcusSBAxHyJpWVvbMCeUXidgEQkKY
    TfcusSBAxHyJpWVvbMCeUXidgEQknI['page'] =TfcusSBAxHyJpWVvbMCeUXidgEQkzr(TfcusSBAxHyJpWVvbMCeUXidgEQknG+1)
    TfcusSBAxHyJpWVvbMCeUXidgEQknI['sort'] =TfcusSBAxHyJpWVvbMCeUXidgEQknl
    TfcusSBAxHyJpWVvbMCeUXidgEQknY='[B]%s >>[/B]'%'다음 페이지'
    TfcusSBAxHyJpWVvbMCeUXidgEQkKL=TfcusSBAxHyJpWVvbMCeUXidgEQkzr(TfcusSBAxHyJpWVvbMCeUXidgEQknG+1)
    TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel=TfcusSBAxHyJpWVvbMCeUXidgEQkKL,img='',infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkrl,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQkzn,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkzK(TfcusSBAxHyJpWVvbMCeUXidgEQkaF)>0:
   if TfcusSBAxHyJpWVvbMCeUXidgEQkKY=='arrivals/latest':
    xbmcplugin.endOfDirectory(TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_handle,cacheToDisc=TfcusSBAxHyJpWVvbMCeUXidgEQkzn)
   else:
    xbmcplugin.endOfDirectory(TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_handle,cacheToDisc=TfcusSBAxHyJpWVvbMCeUXidgEQkrt)
 def dp_Episode_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,args):
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.SaveCredential(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_winCredential())
  TfcusSBAxHyJpWVvbMCeUXidgEQkaq=args.get('movie_code')
  TfcusSBAxHyJpWVvbMCeUXidgEQknG =TfcusSBAxHyJpWVvbMCeUXidgEQkzO(args.get('page'))
  TfcusSBAxHyJpWVvbMCeUXidgEQkKw =args.get('season_code')
  TfcusSBAxHyJpWVvbMCeUXidgEQkaF,TfcusSBAxHyJpWVvbMCeUXidgEQkaL=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.GetEpisodoList(TfcusSBAxHyJpWVvbMCeUXidgEQkaq,TfcusSBAxHyJpWVvbMCeUXidgEQknG,orderby=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_winEpisodeOrderby())
  for TfcusSBAxHyJpWVvbMCeUXidgEQkaI in TfcusSBAxHyJpWVvbMCeUXidgEQkaF:
   TfcusSBAxHyJpWVvbMCeUXidgEQkKI =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('code')
   TfcusSBAxHyJpWVvbMCeUXidgEQknY =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('title')
   TfcusSBAxHyJpWVvbMCeUXidgEQkKj =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('thumbnail')
   TfcusSBAxHyJpWVvbMCeUXidgEQkaN =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('display_num')
   TfcusSBAxHyJpWVvbMCeUXidgEQkaG=TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('season_title')
   TfcusSBAxHyJpWVvbMCeUXidgEQkam=TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('info')
   TfcusSBAxHyJpWVvbMCeUXidgEQkam['plot']='%s\n%s\n\n%s'%(TfcusSBAxHyJpWVvbMCeUXidgEQkaG,TfcusSBAxHyJpWVvbMCeUXidgEQkaN,TfcusSBAxHyJpWVvbMCeUXidgEQknY)
   TfcusSBAxHyJpWVvbMCeUXidgEQknY='(%s) %s'%(TfcusSBAxHyJpWVvbMCeUXidgEQkaN,TfcusSBAxHyJpWVvbMCeUXidgEQknY)
   TfcusSBAxHyJpWVvbMCeUXidgEQknI={'mode':'MOVIE','movie_code':TfcusSBAxHyJpWVvbMCeUXidgEQkKI,'season_code':TfcusSBAxHyJpWVvbMCeUXidgEQkKw,'title':'%s < %s >'%(TfcusSBAxHyJpWVvbMCeUXidgEQknY,TfcusSBAxHyJpWVvbMCeUXidgEQkaG),'thumbnail':TfcusSBAxHyJpWVvbMCeUXidgEQkKj}
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel=TfcusSBAxHyJpWVvbMCeUXidgEQkaG,img=TfcusSBAxHyJpWVvbMCeUXidgEQkKj,infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkam,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQkrt,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
  if TfcusSBAxHyJpWVvbMCeUXidgEQknG==1:
   TfcusSBAxHyJpWVvbMCeUXidgEQkam={'plot':'정렬순서를 변경합니다.'}
   TfcusSBAxHyJpWVvbMCeUXidgEQknI={}
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['mode'] ='ORDER_BY' 
   if TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_winEpisodeOrderby()=='desc':
    TfcusSBAxHyJpWVvbMCeUXidgEQknY='정렬순서변경 : 최신화부터 -> 1회부터'
    TfcusSBAxHyJpWVvbMCeUXidgEQknI['orderby']='asc'
   else:
    TfcusSBAxHyJpWVvbMCeUXidgEQknY='정렬순서변경 : 1회부터 -> 최신화부터'
    TfcusSBAxHyJpWVvbMCeUXidgEQknI['orderby']='desc'
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel='',img='',infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkam,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQkrt,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkaL:
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['mode'] ='EPISODE' 
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['movie_code']=TfcusSBAxHyJpWVvbMCeUXidgEQkaq
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['page'] =TfcusSBAxHyJpWVvbMCeUXidgEQkzr(TfcusSBAxHyJpWVvbMCeUXidgEQknG+1)
   TfcusSBAxHyJpWVvbMCeUXidgEQknY='[B]%s >>[/B]'%'다음 페이지'
   TfcusSBAxHyJpWVvbMCeUXidgEQkKL=TfcusSBAxHyJpWVvbMCeUXidgEQkzr(TfcusSBAxHyJpWVvbMCeUXidgEQknG+1)
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel=TfcusSBAxHyJpWVvbMCeUXidgEQkKL,img='',infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkrl,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQkzn,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkzK(TfcusSBAxHyJpWVvbMCeUXidgEQkaF)>0:xbmcplugin.endOfDirectory(TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_handle,cacheToDisc=TfcusSBAxHyJpWVvbMCeUXidgEQkzn)
 def dp_Search_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,args):
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.SaveCredential(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_winCredential())
  TfcusSBAxHyJpWVvbMCeUXidgEQknG =TfcusSBAxHyJpWVvbMCeUXidgEQkzO(args.get('page'))
  if 'search_key' in args:
   TfcusSBAxHyJpWVvbMCeUXidgEQkal=args.get('search_key')
  else:
   TfcusSBAxHyJpWVvbMCeUXidgEQkal=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not TfcusSBAxHyJpWVvbMCeUXidgEQkal:return
  TfcusSBAxHyJpWVvbMCeUXidgEQkaF,TfcusSBAxHyJpWVvbMCeUXidgEQkaL=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.GetSearchList(TfcusSBAxHyJpWVvbMCeUXidgEQkal,TfcusSBAxHyJpWVvbMCeUXidgEQknG)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkzK(TfcusSBAxHyJpWVvbMCeUXidgEQkaF)==0:return
  for TfcusSBAxHyJpWVvbMCeUXidgEQkaI in TfcusSBAxHyJpWVvbMCeUXidgEQkaF:
   TfcusSBAxHyJpWVvbMCeUXidgEQkKI =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('code')
   TfcusSBAxHyJpWVvbMCeUXidgEQknY =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('title')
   TfcusSBAxHyJpWVvbMCeUXidgEQkaw=TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('content_type')
   TfcusSBAxHyJpWVvbMCeUXidgEQkaj =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('story')
   TfcusSBAxHyJpWVvbMCeUXidgEQkKj =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('thumbnail')
   TfcusSBAxHyJpWVvbMCeUXidgEQkaP =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('year')
   TfcusSBAxHyJpWVvbMCeUXidgEQkao =TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('film_rating_code')
   TfcusSBAxHyJpWVvbMCeUXidgEQkaD=TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('film_rating_short')
   if TfcusSBAxHyJpWVvbMCeUXidgEQkaw=='movies': 
    TfcusSBAxHyJpWVvbMCeUXidgEQknw=TfcusSBAxHyJpWVvbMCeUXidgEQkrt
    TfcusSBAxHyJpWVvbMCeUXidgEQkah ='MOVIE'
    TfcusSBAxHyJpWVvbMCeUXidgEQknj=''
    TfcusSBAxHyJpWVvbMCeUXidgEQkKw='-'
   else: 
    TfcusSBAxHyJpWVvbMCeUXidgEQknw=TfcusSBAxHyJpWVvbMCeUXidgEQkzn
    TfcusSBAxHyJpWVvbMCeUXidgEQkah ='EPISODE'
    TfcusSBAxHyJpWVvbMCeUXidgEQknj='Series'
    TfcusSBAxHyJpWVvbMCeUXidgEQkKw=TfcusSBAxHyJpWVvbMCeUXidgEQkKI
   TfcusSBAxHyJpWVvbMCeUXidgEQkam=TfcusSBAxHyJpWVvbMCeUXidgEQkaI.get('info')
   TfcusSBAxHyJpWVvbMCeUXidgEQkam['plot']='%s (%s)\n년도 : %s\n\n%s'%(TfcusSBAxHyJpWVvbMCeUXidgEQknY,TfcusSBAxHyJpWVvbMCeUXidgEQkaD,TfcusSBAxHyJpWVvbMCeUXidgEQkaP,TfcusSBAxHyJpWVvbMCeUXidgEQkaj)
   if TfcusSBAxHyJpWVvbMCeUXidgEQkao>=19:
    TfcusSBAxHyJpWVvbMCeUXidgEQknY+='  (%s년 - %s)'%(TfcusSBAxHyJpWVvbMCeUXidgEQkaP,TfcusSBAxHyJpWVvbMCeUXidgEQkzr(TfcusSBAxHyJpWVvbMCeUXidgEQkaD))
   else:
    TfcusSBAxHyJpWVvbMCeUXidgEQknY+='  (%s년)'%(TfcusSBAxHyJpWVvbMCeUXidgEQkaP)
   TfcusSBAxHyJpWVvbMCeUXidgEQknI={'mode':TfcusSBAxHyJpWVvbMCeUXidgEQkah,'movie_code':TfcusSBAxHyJpWVvbMCeUXidgEQkKI,'page':'1','season_code':TfcusSBAxHyJpWVvbMCeUXidgEQkKw,'title':TfcusSBAxHyJpWVvbMCeUXidgEQknY,'thumbnail':TfcusSBAxHyJpWVvbMCeUXidgEQkKj}
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel=TfcusSBAxHyJpWVvbMCeUXidgEQknj,img=TfcusSBAxHyJpWVvbMCeUXidgEQkKj,infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkam,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQknw,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkaL:
   TfcusSBAxHyJpWVvbMCeUXidgEQknI={}
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['mode'] ='SEARCH'
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['search_key']=TfcusSBAxHyJpWVvbMCeUXidgEQkal
   TfcusSBAxHyJpWVvbMCeUXidgEQknI['page'] =TfcusSBAxHyJpWVvbMCeUXidgEQkzr(TfcusSBAxHyJpWVvbMCeUXidgEQknG+1)
   TfcusSBAxHyJpWVvbMCeUXidgEQknY='[B]%s >>[/B]'%'다음 페이지'
   TfcusSBAxHyJpWVvbMCeUXidgEQkKL=TfcusSBAxHyJpWVvbMCeUXidgEQkzr(TfcusSBAxHyJpWVvbMCeUXidgEQknG+1)
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel=TfcusSBAxHyJpWVvbMCeUXidgEQkKL,img='',infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkrl,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQkzn,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkzK(TfcusSBAxHyJpWVvbMCeUXidgEQkaF)>0:xbmcplugin.endOfDirectory(TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_handle)
 def Delete_Watched_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,TfcusSBAxHyJpWVvbMCeUXidgEQknN):
  try:
   TfcusSBAxHyJpWVvbMCeUXidgEQkat=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TfcusSBAxHyJpWVvbMCeUXidgEQknN))
   fp=TfcusSBAxHyJpWVvbMCeUXidgEQkzY(TfcusSBAxHyJpWVvbMCeUXidgEQkat,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   TfcusSBAxHyJpWVvbMCeUXidgEQkrl
 def dp_WatchList_Delete(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,args):
  TfcusSBAxHyJpWVvbMCeUXidgEQknN=args.get('stype')
  TfcusSBAxHyJpWVvbMCeUXidgEQkOD=xbmcgui.Dialog()
  TfcusSBAxHyJpWVvbMCeUXidgEQknh=TfcusSBAxHyJpWVvbMCeUXidgEQkOD.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if TfcusSBAxHyJpWVvbMCeUXidgEQknh==TfcusSBAxHyJpWVvbMCeUXidgEQkrt:sys.exit()
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.Delete_Watched_List(TfcusSBAxHyJpWVvbMCeUXidgEQknN)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,TfcusSBAxHyJpWVvbMCeUXidgEQknN):
  try:
   TfcusSBAxHyJpWVvbMCeUXidgEQkat=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TfcusSBAxHyJpWVvbMCeUXidgEQknN))
   fp=TfcusSBAxHyJpWVvbMCeUXidgEQkzY(TfcusSBAxHyJpWVvbMCeUXidgEQkat,'r',-1,'utf-8')
   TfcusSBAxHyJpWVvbMCeUXidgEQkrO=fp.readlines()
   fp.close()
  except:
   TfcusSBAxHyJpWVvbMCeUXidgEQkrO=[]
  return TfcusSBAxHyJpWVvbMCeUXidgEQkrO
 def Save_Watched_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,TfcusSBAxHyJpWVvbMCeUXidgEQknN,TfcusSBAxHyJpWVvbMCeUXidgEQkOP):
  try:
   TfcusSBAxHyJpWVvbMCeUXidgEQkat=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TfcusSBAxHyJpWVvbMCeUXidgEQknN))
   TfcusSBAxHyJpWVvbMCeUXidgEQkrn=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.Load_Watched_List(TfcusSBAxHyJpWVvbMCeUXidgEQknN) 
   fp=TfcusSBAxHyJpWVvbMCeUXidgEQkzY(TfcusSBAxHyJpWVvbMCeUXidgEQkat,'w',-1,'utf-8')
   TfcusSBAxHyJpWVvbMCeUXidgEQkrK=urllib.parse.urlencode(TfcusSBAxHyJpWVvbMCeUXidgEQkOP)
   TfcusSBAxHyJpWVvbMCeUXidgEQkrK=TfcusSBAxHyJpWVvbMCeUXidgEQkrK+'\n'
   fp.write(TfcusSBAxHyJpWVvbMCeUXidgEQkrK)
   TfcusSBAxHyJpWVvbMCeUXidgEQkra=0
   for TfcusSBAxHyJpWVvbMCeUXidgEQkrz in TfcusSBAxHyJpWVvbMCeUXidgEQkrn:
    TfcusSBAxHyJpWVvbMCeUXidgEQkrY=TfcusSBAxHyJpWVvbMCeUXidgEQkzF(urllib.parse.parse_qsl(TfcusSBAxHyJpWVvbMCeUXidgEQkrz))
    TfcusSBAxHyJpWVvbMCeUXidgEQkrF=TfcusSBAxHyJpWVvbMCeUXidgEQkOP.get('code')
    TfcusSBAxHyJpWVvbMCeUXidgEQkrL=TfcusSBAxHyJpWVvbMCeUXidgEQkrY.get('code')
    if TfcusSBAxHyJpWVvbMCeUXidgEQknN=='seasons' and TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_settings_direct_replay()==TfcusSBAxHyJpWVvbMCeUXidgEQkzn:
     TfcusSBAxHyJpWVvbMCeUXidgEQkrF=TfcusSBAxHyJpWVvbMCeUXidgEQkOP.get('videoid')
     TfcusSBAxHyJpWVvbMCeUXidgEQkrL=TfcusSBAxHyJpWVvbMCeUXidgEQkrY.get('videoid')if TfcusSBAxHyJpWVvbMCeUXidgEQkrL!=TfcusSBAxHyJpWVvbMCeUXidgEQkrl else '-'
    if TfcusSBAxHyJpWVvbMCeUXidgEQkrF!=TfcusSBAxHyJpWVvbMCeUXidgEQkrL:
     fp.write(TfcusSBAxHyJpWVvbMCeUXidgEQkrz)
     TfcusSBAxHyJpWVvbMCeUXidgEQkra+=1
     if TfcusSBAxHyJpWVvbMCeUXidgEQkra>=50:break
   fp.close()
  except:
   TfcusSBAxHyJpWVvbMCeUXidgEQkrl
 def dp_Watch_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI,args):
  TfcusSBAxHyJpWVvbMCeUXidgEQknN =args.get('stype')
  TfcusSBAxHyJpWVvbMCeUXidgEQknO=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.get_settings_direct_replay()
  if TfcusSBAxHyJpWVvbMCeUXidgEQknN=='-':
   for TfcusSBAxHyJpWVvbMCeUXidgEQkrI in TfcusSBAxHyJpWVvbMCeUXidgEQkOa:
    TfcusSBAxHyJpWVvbMCeUXidgEQknY=TfcusSBAxHyJpWVvbMCeUXidgEQkrI.get('title')
    TfcusSBAxHyJpWVvbMCeUXidgEQknI={'mode':TfcusSBAxHyJpWVvbMCeUXidgEQkrI.get('mode'),'stype':TfcusSBAxHyJpWVvbMCeUXidgEQkrI.get('stype')}
    TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel='',img='',infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkrl,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQkzn,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
   if TfcusSBAxHyJpWVvbMCeUXidgEQkzK(TfcusSBAxHyJpWVvbMCeUXidgEQkOa)>0:xbmcplugin.endOfDirectory(TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_handle)
  else:
   TfcusSBAxHyJpWVvbMCeUXidgEQkrw=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.Load_Watched_List(TfcusSBAxHyJpWVvbMCeUXidgEQknN)
   for TfcusSBAxHyJpWVvbMCeUXidgEQkrj in TfcusSBAxHyJpWVvbMCeUXidgEQkrw:
    TfcusSBAxHyJpWVvbMCeUXidgEQkrP=TfcusSBAxHyJpWVvbMCeUXidgEQkzF(urllib.parse.parse_qsl(TfcusSBAxHyJpWVvbMCeUXidgEQkrj))
    TfcusSBAxHyJpWVvbMCeUXidgEQkKI=TfcusSBAxHyJpWVvbMCeUXidgEQkrP.get('code')
    TfcusSBAxHyJpWVvbMCeUXidgEQknY =TfcusSBAxHyJpWVvbMCeUXidgEQkrP.get('title')
    TfcusSBAxHyJpWVvbMCeUXidgEQkKj =TfcusSBAxHyJpWVvbMCeUXidgEQkrP.get('img')
    TfcusSBAxHyJpWVvbMCeUXidgEQkro =TfcusSBAxHyJpWVvbMCeUXidgEQkrP.get('videoid')
    TfcusSBAxHyJpWVvbMCeUXidgEQkam={}
    TfcusSBAxHyJpWVvbMCeUXidgEQkam['plot']=TfcusSBAxHyJpWVvbMCeUXidgEQknY
    if TfcusSBAxHyJpWVvbMCeUXidgEQknN=='movie':
     TfcusSBAxHyJpWVvbMCeUXidgEQknI={'mode':'MOVIE','page':'1','movie_code':TfcusSBAxHyJpWVvbMCeUXidgEQkKI,'season_code':'-','title':TfcusSBAxHyJpWVvbMCeUXidgEQknY,'thumbnail':TfcusSBAxHyJpWVvbMCeUXidgEQkKj}
     TfcusSBAxHyJpWVvbMCeUXidgEQknw=TfcusSBAxHyJpWVvbMCeUXidgEQkrt
    else:
     if TfcusSBAxHyJpWVvbMCeUXidgEQknO==TfcusSBAxHyJpWVvbMCeUXidgEQkrt or TfcusSBAxHyJpWVvbMCeUXidgEQkro==TfcusSBAxHyJpWVvbMCeUXidgEQkrl:
      TfcusSBAxHyJpWVvbMCeUXidgEQknI={'mode':'EPISODE','page':'1','movie_code':TfcusSBAxHyJpWVvbMCeUXidgEQkKI,'season_code':TfcusSBAxHyJpWVvbMCeUXidgEQkKI,'title':TfcusSBAxHyJpWVvbMCeUXidgEQknY,'thumbnail':TfcusSBAxHyJpWVvbMCeUXidgEQkKj}
      TfcusSBAxHyJpWVvbMCeUXidgEQknw=TfcusSBAxHyJpWVvbMCeUXidgEQkzn
     else:
      TfcusSBAxHyJpWVvbMCeUXidgEQknI={'mode':'MOVIE','movie_code':TfcusSBAxHyJpWVvbMCeUXidgEQkro,'season_code':TfcusSBAxHyJpWVvbMCeUXidgEQkKI,'title':TfcusSBAxHyJpWVvbMCeUXidgEQknY,'thumbnail':TfcusSBAxHyJpWVvbMCeUXidgEQkKj}
      TfcusSBAxHyJpWVvbMCeUXidgEQknw=TfcusSBAxHyJpWVvbMCeUXidgEQkrt
    TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel='',img=TfcusSBAxHyJpWVvbMCeUXidgEQkKj,infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkam,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQknw,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
   TfcusSBAxHyJpWVvbMCeUXidgEQkam={'plot':'시청목록을 삭제합니다.'}
   TfcusSBAxHyJpWVvbMCeUXidgEQknY='*** 시청목록 삭제 ***'
   TfcusSBAxHyJpWVvbMCeUXidgEQknI={'mode':'MYVIEW_REMOVE','stype':TfcusSBAxHyJpWVvbMCeUXidgEQknN}
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.add_dir(TfcusSBAxHyJpWVvbMCeUXidgEQknY,sublabel='',img='',infoLabels=TfcusSBAxHyJpWVvbMCeUXidgEQkam,isFolder=TfcusSBAxHyJpWVvbMCeUXidgEQkrt,params=TfcusSBAxHyJpWVvbMCeUXidgEQknI)
   xbmcplugin.endOfDirectory(TfcusSBAxHyJpWVvbMCeUXidgEQkOI._addon_handle,cacheToDisc=TfcusSBAxHyJpWVvbMCeUXidgEQkrt)
 def logout(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  TfcusSBAxHyJpWVvbMCeUXidgEQkOD=xbmcgui.Dialog()
  TfcusSBAxHyJpWVvbMCeUXidgEQknh=TfcusSBAxHyJpWVvbMCeUXidgEQkOD.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if TfcusSBAxHyJpWVvbMCeUXidgEQknh==TfcusSBAxHyJpWVvbMCeUXidgEQkrt:sys.exit()
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.wininfo_clear()
  if os.path.isfile(TfcusSBAxHyJpWVvbMCeUXidgEQkOL):os.remove(TfcusSBAxHyJpWVvbMCeUXidgEQkOL)
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  TfcusSBAxHyJpWVvbMCeUXidgEQknK=xbmcgui.Window(10000)
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_TOKEN','')
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_GUIT','')
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_GUITV','')
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_USERCD','')
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  TfcusSBAxHyJpWVvbMCeUXidgEQkrD =TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.Get_Now_Datetime()
  TfcusSBAxHyJpWVvbMCeUXidgEQkrh=TfcusSBAxHyJpWVvbMCeUXidgEQkrD+datetime.timedelta(days=TfcusSBAxHyJpWVvbMCeUXidgEQkzO(__addon__.getSetting('cache_ttl')))
  TfcusSBAxHyJpWVvbMCeUXidgEQknK=xbmcgui.Window(10000)
  TfcusSBAxHyJpWVvbMCeUXidgEQkrm={'watcha_token':TfcusSBAxHyJpWVvbMCeUXidgEQknK.getProperty('WATCHA_M_TOKEN'),'watcha_guit':TfcusSBAxHyJpWVvbMCeUXidgEQknK.getProperty('WATCHA_M_GUIT'),'watcha_guitv':TfcusSBAxHyJpWVvbMCeUXidgEQknK.getProperty('WATCHA_M_GUITV'),'watcha_usercd':TfcusSBAxHyJpWVvbMCeUXidgEQknK.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':TfcusSBAxHyJpWVvbMCeUXidgEQkrh.strftime('%Y-%m-%d')}
  try: 
   fp=TfcusSBAxHyJpWVvbMCeUXidgEQkzY(TfcusSBAxHyJpWVvbMCeUXidgEQkOL,'w',-1,'utf-8')
   json.dump(TfcusSBAxHyJpWVvbMCeUXidgEQkrm,fp)
   fp.close()
  except TfcusSBAxHyJpWVvbMCeUXidgEQkzL as exception:
   TfcusSBAxHyJpWVvbMCeUXidgEQkzI(exception)
 def cookiefile_check(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  TfcusSBAxHyJpWVvbMCeUXidgEQkrm={}
  try: 
   fp=TfcusSBAxHyJpWVvbMCeUXidgEQkzY(TfcusSBAxHyJpWVvbMCeUXidgEQkOL,'r',-1,'utf-8')
   TfcusSBAxHyJpWVvbMCeUXidgEQkrm= json.load(fp)
   fp.close()
  except TfcusSBAxHyJpWVvbMCeUXidgEQkzL as exception:
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.wininfo_clear()
   return TfcusSBAxHyJpWVvbMCeUXidgEQkrt
  TfcusSBAxHyJpWVvbMCeUXidgEQknP =__addon__.getSetting('id')
  TfcusSBAxHyJpWVvbMCeUXidgEQkno =__addon__.getSetting('pw')
  TfcusSBAxHyJpWVvbMCeUXidgEQkrR =__addon__.getSetting('selected_profile')
  TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_id']=base64.standard_b64decode(TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_id']).decode('utf-8')
  TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_pw']=base64.standard_b64decode(TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_pw']).decode('utf-8')
  if TfcusSBAxHyJpWVvbMCeUXidgEQknP!=TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_id']or TfcusSBAxHyJpWVvbMCeUXidgEQkno!=TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_pw']or TfcusSBAxHyJpWVvbMCeUXidgEQkrR!=TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_profile']:
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.wininfo_clear()
   return TfcusSBAxHyJpWVvbMCeUXidgEQkrt
  TfcusSBAxHyJpWVvbMCeUXidgEQknm =TfcusSBAxHyJpWVvbMCeUXidgEQkzO(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  TfcusSBAxHyJpWVvbMCeUXidgEQkrq=TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_limitdate']
  TfcusSBAxHyJpWVvbMCeUXidgEQknR =TfcusSBAxHyJpWVvbMCeUXidgEQkzO(re.sub('-','',TfcusSBAxHyJpWVvbMCeUXidgEQkrq))
  if TfcusSBAxHyJpWVvbMCeUXidgEQknR<TfcusSBAxHyJpWVvbMCeUXidgEQknm:
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.wininfo_clear()
   return TfcusSBAxHyJpWVvbMCeUXidgEQkrt
  TfcusSBAxHyJpWVvbMCeUXidgEQknK=xbmcgui.Window(10000)
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_TOKEN',TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_token'])
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_GUIT',TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_guit'])
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_GUITV',TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_guitv'])
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_USERCD',TfcusSBAxHyJpWVvbMCeUXidgEQkrm['watcha_usercd'])
  TfcusSBAxHyJpWVvbMCeUXidgEQknK.setProperty('WATCHA_M_LOGINTIME',TfcusSBAxHyJpWVvbMCeUXidgEQkrq)
  return TfcusSBAxHyJpWVvbMCeUXidgEQkzn
 def watcha_main(TfcusSBAxHyJpWVvbMCeUXidgEQkOI):
  TfcusSBAxHyJpWVvbMCeUXidgEQkrN=TfcusSBAxHyJpWVvbMCeUXidgEQkOI.main_params.get('mode',TfcusSBAxHyJpWVvbMCeUXidgEQkrl)
  if TfcusSBAxHyJpWVvbMCeUXidgEQkrN=='LOGOUT':
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.logout()
   return
  TfcusSBAxHyJpWVvbMCeUXidgEQkOI.login_main()
  if TfcusSBAxHyJpWVvbMCeUXidgEQkrN is TfcusSBAxHyJpWVvbMCeUXidgEQkrl:
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.dp_Main_List()
  elif TfcusSBAxHyJpWVvbMCeUXidgEQkrN=='SUB_GROUP':
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.dp_SubGroup_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.main_params)
  elif TfcusSBAxHyJpWVvbMCeUXidgEQkrN=='CATEGORY_LIST':
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.dp_Category_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.main_params)
  elif TfcusSBAxHyJpWVvbMCeUXidgEQkrN=='EPISODE':
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.dp_Episode_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.main_params)
  elif TfcusSBAxHyJpWVvbMCeUXidgEQkrN=='ORDER_BY':
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.dp_setEpOrderby(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.main_params)
  elif TfcusSBAxHyJpWVvbMCeUXidgEQkrN=='SEARCH':
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.dp_Search_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.main_params)
  elif TfcusSBAxHyJpWVvbMCeUXidgEQkrN=='MOVIE':
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.play_VIDEO(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.main_params)
  elif TfcusSBAxHyJpWVvbMCeUXidgEQkrN=='WATCH':
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.dp_Watch_List(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.main_params)
  elif TfcusSBAxHyJpWVvbMCeUXidgEQkrN=='MYVIEW_REMOVE':
   TfcusSBAxHyJpWVvbMCeUXidgEQkOI.dp_WatchList_Delete(TfcusSBAxHyJpWVvbMCeUXidgEQkOI.main_params)
  else:
   TfcusSBAxHyJpWVvbMCeUXidgEQkrl
# Created by pyminifier (https://github.com/liftoff/pyminifier)
