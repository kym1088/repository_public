__author__="NightRain"
vWtgQsluUqrEBjTPMixOpLyADdJkHR=object
vWtgQsluUqrEBjTPMixOpLyADdJkHX=None
vWtgQsluUqrEBjTPMixOpLyADdJkHN=False
vWtgQsluUqrEBjTPMixOpLyADdJkHC=True
vWtgQsluUqrEBjTPMixOpLyADdJkGI=Exception
vWtgQsluUqrEBjTPMixOpLyADdJkGn=print
vWtgQsluUqrEBjTPMixOpLyADdJkGc=str
vWtgQsluUqrEBjTPMixOpLyADdJkGH=len
vWtgQsluUqrEBjTPMixOpLyADdJkGm=int
vWtgQsluUqrEBjTPMixOpLyADdJkGw=range
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
class vWtgQsluUqrEBjTPMixOpLyADdJkIn(vWtgQsluUqrEBjTPMixOpLyADdJkHR):
 def __init__(vWtgQsluUqrEBjTPMixOpLyADdJkIc):
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_TOKEN ='' 
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUIT =''
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUITV =''
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_USERCD=''
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.MAIN_DOMAIN ='https://watcha.com'
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN ='https://api-mars.watcha.com'
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.EPISODE_LIMIT=20
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.SEARCH_LIMIT =30
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.DEFAULT_HEADER={'user-agent':vWtgQsluUqrEBjTPMixOpLyADdJkIc.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(vWtgQsluUqrEBjTPMixOpLyADdJkIc,jobtype,vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJkHX,headers=vWtgQsluUqrEBjTPMixOpLyADdJkHX,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkHX,redirects=vWtgQsluUqrEBjTPMixOpLyADdJkHN):
  vWtgQsluUqrEBjTPMixOpLyADdJkIH=vWtgQsluUqrEBjTPMixOpLyADdJkIc.DEFAULT_HEADER
  if headers:vWtgQsluUqrEBjTPMixOpLyADdJkIH.update(headers)
  if jobtype=='Get':
   vWtgQsluUqrEBjTPMixOpLyADdJkIG=requests.get(vWtgQsluUqrEBjTPMixOpLyADdJkIC,params=params,headers=vWtgQsluUqrEBjTPMixOpLyADdJkIH,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   vWtgQsluUqrEBjTPMixOpLyADdJkIG=requests.put(vWtgQsluUqrEBjTPMixOpLyADdJkIC,data=payload,params=params,headers=vWtgQsluUqrEBjTPMixOpLyADdJkIH,cookies=cookies,allow_redirects=redirects)
  else:
   vWtgQsluUqrEBjTPMixOpLyADdJkIG=requests.post(vWtgQsluUqrEBjTPMixOpLyADdJkIC,data=payload,params=params,headers=vWtgQsluUqrEBjTPMixOpLyADdJkIH,cookies=cookies,allow_redirects=redirects)
  return vWtgQsluUqrEBjTPMixOpLyADdJkIG
 def SaveCredential(vWtgQsluUqrEBjTPMixOpLyADdJkIc,vWtgQsluUqrEBjTPMixOpLyADdJkIm):
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_TOKEN =vWtgQsluUqrEBjTPMixOpLyADdJkIm.get('watcha_token')
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUIT =vWtgQsluUqrEBjTPMixOpLyADdJkIm.get('watcha_guit')
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUITV =vWtgQsluUqrEBjTPMixOpLyADdJkIm.get('watcha_guitv')
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_USERCD =vWtgQsluUqrEBjTPMixOpLyADdJkIm.get('watcha_usercd')
 def SaveCredential_usercd(vWtgQsluUqrEBjTPMixOpLyADdJkIc,vWtgQsluUqrEBjTPMixOpLyADdJkIw):
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_USERCD=vWtgQsluUqrEBjTPMixOpLyADdJkIw
 def SaveCredential_guitv(vWtgQsluUqrEBjTPMixOpLyADdJkIc,vWtgQsluUqrEBjTPMixOpLyADdJkIS,vWtgQsluUqrEBjTPMixOpLyADdJkIf):
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUITV=vWtgQsluUqrEBjTPMixOpLyADdJkIS
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_TOKEN=vWtgQsluUqrEBjTPMixOpLyADdJkIf 
 def ClearCredential(vWtgQsluUqrEBjTPMixOpLyADdJkIc):
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_TOKEN ='' 
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUIT =''
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUITV =''
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_USERCD=''
 def LoadCredential(vWtgQsluUqrEBjTPMixOpLyADdJkIc):
  vWtgQsluUqrEBjTPMixOpLyADdJkIm={'watcha_token':vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_TOKEN,'watcha_guit':vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUIT,'watcha_guitv':vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUITV,'watcha_usercd':vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_USERCD}
  return vWtgQsluUqrEBjTPMixOpLyADdJkIm
 def makeDefaultCookies(vWtgQsluUqrEBjTPMixOpLyADdJkIc):
  vWtgQsluUqrEBjTPMixOpLyADdJkIh={'_s_guit':vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUIT,'_guinness-premium_session':vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_TOKEN}
  if vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUITV:
   vWtgQsluUqrEBjTPMixOpLyADdJkIh['_s_guitv']=vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_GUITV
  return vWtgQsluUqrEBjTPMixOpLyADdJkIh
 def GetCredential(vWtgQsluUqrEBjTPMixOpLyADdJkIc,user_id,user_pw,user_pf):
  vWtgQsluUqrEBjTPMixOpLyADdJkIK=vWtgQsluUqrEBjTPMixOpLyADdJkHN
  vWtgQsluUqrEBjTPMixOpLyADdJkIa=vWtgQsluUqrEBjTPMixOpLyADdJkIe='-'
  try:
   vWtgQsluUqrEBjTPMixOpLyADdJkIz=vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN+'/api/session'
   vWtgQsluUqrEBjTPMixOpLyADdJkIV={'email':user_id,'password':user_pw}
   vWtgQsluUqrEBjTPMixOpLyADdJkIY={'accept':'application/vnd.frograms+json;version=4'}
   vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Post',vWtgQsluUqrEBjTPMixOpLyADdJkIz,payload=vWtgQsluUqrEBjTPMixOpLyADdJkIV,params=vWtgQsluUqrEBjTPMixOpLyADdJkHX,headers=vWtgQsluUqrEBjTPMixOpLyADdJkIY,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkHX)
   for vWtgQsluUqrEBjTPMixOpLyADdJkIF in vWtgQsluUqrEBjTPMixOpLyADdJkIo.cookies:
    if vWtgQsluUqrEBjTPMixOpLyADdJkIF.name=='_guinness-premium_session':
     vWtgQsluUqrEBjTPMixOpLyADdJkIe=vWtgQsluUqrEBjTPMixOpLyADdJkIF.value
    elif vWtgQsluUqrEBjTPMixOpLyADdJkIF.name=='_s_guit':
     vWtgQsluUqrEBjTPMixOpLyADdJkIa=vWtgQsluUqrEBjTPMixOpLyADdJkIF.value
   if vWtgQsluUqrEBjTPMixOpLyADdJkIe:vWtgQsluUqrEBjTPMixOpLyADdJkIK=vWtgQsluUqrEBjTPMixOpLyADdJkHC
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   vWtgQsluUqrEBjTPMixOpLyADdJkGn(exception)
   vWtgQsluUqrEBjTPMixOpLyADdJkIa=vWtgQsluUqrEBjTPMixOpLyADdJkIe='' 
  vWtgQsluUqrEBjTPMixOpLyADdJkIm={'watcha_guit':vWtgQsluUqrEBjTPMixOpLyADdJkIa,'watcha_token':vWtgQsluUqrEBjTPMixOpLyADdJkIe,'watcha_guitv':'','watcha_usercd':''}
  vWtgQsluUqrEBjTPMixOpLyADdJkIc.SaveCredential(vWtgQsluUqrEBjTPMixOpLyADdJkIm)
  try:
   vWtgQsluUqrEBjTPMixOpLyADdJkIb=vWtgQsluUqrEBjTPMixOpLyADdJkIc.GetProfilesList()
   vWtgQsluUqrEBjTPMixOpLyADdJkIR =vWtgQsluUqrEBjTPMixOpLyADdJkIb[user_pf]
   vWtgQsluUqrEBjTPMixOpLyADdJkIc.SaveCredential_usercd(vWtgQsluUqrEBjTPMixOpLyADdJkIR)
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   vWtgQsluUqrEBjTPMixOpLyADdJkGn(exception)
   vWtgQsluUqrEBjTPMixOpLyADdJkIc.ClearCredential()
   return vWtgQsluUqrEBjTPMixOpLyADdJkHN
  if user_pf!=0:
   vWtgQsluUqrEBjTPMixOpLyADdJkIS,vWtgQsluUqrEBjTPMixOpLyADdJkIf=vWtgQsluUqrEBjTPMixOpLyADdJkIc.GetProfilesConvert(vWtgQsluUqrEBjTPMixOpLyADdJkIR)
   vWtgQsluUqrEBjTPMixOpLyADdJkIc.SaveCredential_guitv(vWtgQsluUqrEBjTPMixOpLyADdJkIS,vWtgQsluUqrEBjTPMixOpLyADdJkIf)
  return vWtgQsluUqrEBjTPMixOpLyADdJkIK
 def GetSubGroupList(vWtgQsluUqrEBjTPMixOpLyADdJkIc,stype):
  vWtgQsluUqrEBjTPMixOpLyADdJkIX=[]
  try:
   vWtgQsluUqrEBjTPMixOpLyADdJkIN ='/api/categories.json'
   vWtgQsluUqrEBjTPMixOpLyADdJkIC=vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN+vWtgQsluUqrEBjTPMixOpLyADdJkIN
   vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Get',vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJkHX,headers=vWtgQsluUqrEBjTPMixOpLyADdJkHX,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkHX)
   vWtgQsluUqrEBjTPMixOpLyADdJknI=json.loads(vWtgQsluUqrEBjTPMixOpLyADdJkIo.text)
   if not('genres' in vWtgQsluUqrEBjTPMixOpLyADdJknI):return vWtgQsluUqrEBjTPMixOpLyADdJkIX
   if stype=='genres':
    vWtgQsluUqrEBjTPMixOpLyADdJknc=vWtgQsluUqrEBjTPMixOpLyADdJknI['genres']
   else:
    vWtgQsluUqrEBjTPMixOpLyADdJknc=vWtgQsluUqrEBjTPMixOpLyADdJknI['tags']
   for vWtgQsluUqrEBjTPMixOpLyADdJknH in vWtgQsluUqrEBjTPMixOpLyADdJknc:
    vWtgQsluUqrEBjTPMixOpLyADdJknG=vWtgQsluUqrEBjTPMixOpLyADdJknH['name']
    vWtgQsluUqrEBjTPMixOpLyADdJknm =vWtgQsluUqrEBjTPMixOpLyADdJknH['api_path']
    vWtgQsluUqrEBjTPMixOpLyADdJknw =vWtgQsluUqrEBjTPMixOpLyADdJknH['entity']['id']
    vWtgQsluUqrEBjTPMixOpLyADdJknS={'group_name':vWtgQsluUqrEBjTPMixOpLyADdJknG,'api_path':vWtgQsluUqrEBjTPMixOpLyADdJknm,'tag_id':vWtgQsluUqrEBjTPMixOpLyADdJkGc(vWtgQsluUqrEBjTPMixOpLyADdJknw)}
    vWtgQsluUqrEBjTPMixOpLyADdJkIX.append(vWtgQsluUqrEBjTPMixOpLyADdJknS)
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   vWtgQsluUqrEBjTPMixOpLyADdJkGn(exception)
  return vWtgQsluUqrEBjTPMixOpLyADdJkIX
 def GetCategoryList(vWtgQsluUqrEBjTPMixOpLyADdJkIc,stype,vWtgQsluUqrEBjTPMixOpLyADdJknw,vWtgQsluUqrEBjTPMixOpLyADdJknm,page_int,in_sort):
  vWtgQsluUqrEBjTPMixOpLyADdJkIX=[]
  vWtgQsluUqrEBjTPMixOpLyADdJknf=vWtgQsluUqrEBjTPMixOpLyADdJkHN
  vWtgQsluUqrEBjTPMixOpLyADdJknh={}
  try:
   if 'categories' in vWtgQsluUqrEBjTPMixOpLyADdJknm:
    vWtgQsluUqrEBjTPMixOpLyADdJkIN ='/api/categories/contents.json'
    if stype=='genres':
     vWtgQsluUqrEBjTPMixOpLyADdJknh['genre']=vWtgQsluUqrEBjTPMixOpLyADdJknw
    else:
     vWtgQsluUqrEBjTPMixOpLyADdJknh['tag'] =vWtgQsluUqrEBjTPMixOpLyADdJknw
    vWtgQsluUqrEBjTPMixOpLyADdJknh['order']=in_sort 
    if page_int>1:
     vWtgQsluUqrEBjTPMixOpLyADdJknh['page']=vWtgQsluUqrEBjTPMixOpLyADdJkGc(page_int-1)
   else: 
    vWtgQsluUqrEBjTPMixOpLyADdJkIN ='/api/'+vWtgQsluUqrEBjTPMixOpLyADdJknm+'.json'
    if page_int>1:
     vWtgQsluUqrEBjTPMixOpLyADdJknh['page']=vWtgQsluUqrEBjTPMixOpLyADdJkGc(page_int)
   vWtgQsluUqrEBjTPMixOpLyADdJkIC=vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN+vWtgQsluUqrEBjTPMixOpLyADdJkIN
   vWtgQsluUqrEBjTPMixOpLyADdJkIF=vWtgQsluUqrEBjTPMixOpLyADdJkIc.makeDefaultCookies()
   vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Get',vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJknh,headers=vWtgQsluUqrEBjTPMixOpLyADdJkHX,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkIF)
   vWtgQsluUqrEBjTPMixOpLyADdJknI=json.loads(vWtgQsluUqrEBjTPMixOpLyADdJkIo.text)
   if not('contents' in vWtgQsluUqrEBjTPMixOpLyADdJknI):return vWtgQsluUqrEBjTPMixOpLyADdJkIX,vWtgQsluUqrEBjTPMixOpLyADdJknf
   vWtgQsluUqrEBjTPMixOpLyADdJknc=vWtgQsluUqrEBjTPMixOpLyADdJknI['contents']
   vWtgQsluUqrEBjTPMixOpLyADdJknf=vWtgQsluUqrEBjTPMixOpLyADdJknI['meta']['has_next']
   for vWtgQsluUqrEBjTPMixOpLyADdJknH in vWtgQsluUqrEBjTPMixOpLyADdJknc:
    vWtgQsluUqrEBjTPMixOpLyADdJknK =vWtgQsluUqrEBjTPMixOpLyADdJknH['code']
    vWtgQsluUqrEBjTPMixOpLyADdJkna=vWtgQsluUqrEBjTPMixOpLyADdJknH['content_type']
    vWtgQsluUqrEBjTPMixOpLyADdJknz =vWtgQsluUqrEBjTPMixOpLyADdJknH['title']
    vWtgQsluUqrEBjTPMixOpLyADdJknV =vWtgQsluUqrEBjTPMixOpLyADdJknH['story']
    vWtgQsluUqrEBjTPMixOpLyADdJknY=vWtgQsluUqrEBjTPMixOpLyADdJkHb=vWtgQsluUqrEBjTPMixOpLyADdJkHe=''
    if vWtgQsluUqrEBjTPMixOpLyADdJknH.get('poster') !=vWtgQsluUqrEBjTPMixOpLyADdJkHX:vWtgQsluUqrEBjTPMixOpLyADdJknY=vWtgQsluUqrEBjTPMixOpLyADdJknH.get('poster').get('original')
    if vWtgQsluUqrEBjTPMixOpLyADdJknH.get('stillcut')!=vWtgQsluUqrEBjTPMixOpLyADdJkHX:vWtgQsluUqrEBjTPMixOpLyADdJkHb =vWtgQsluUqrEBjTPMixOpLyADdJknH.get('stillcut').get('large')
    if vWtgQsluUqrEBjTPMixOpLyADdJknH.get('thumbnail')!=vWtgQsluUqrEBjTPMixOpLyADdJkHX:vWtgQsluUqrEBjTPMixOpLyADdJkHe=vWtgQsluUqrEBjTPMixOpLyADdJknH.get('thumbnail').get('large')
    if vWtgQsluUqrEBjTPMixOpLyADdJkHe=='' :vWtgQsluUqrEBjTPMixOpLyADdJkHe=vWtgQsluUqrEBjTPMixOpLyADdJkHb
    vWtgQsluUqrEBjTPMixOpLyADdJkno={'thumb':vWtgQsluUqrEBjTPMixOpLyADdJkHb,'poster':vWtgQsluUqrEBjTPMixOpLyADdJknY,'fanart':vWtgQsluUqrEBjTPMixOpLyADdJkHe}
    vWtgQsluUqrEBjTPMixOpLyADdJknF =vWtgQsluUqrEBjTPMixOpLyADdJknH['year']
    vWtgQsluUqrEBjTPMixOpLyADdJkne =vWtgQsluUqrEBjTPMixOpLyADdJknH['film_rating_code']
    vWtgQsluUqrEBjTPMixOpLyADdJknb=vWtgQsluUqrEBjTPMixOpLyADdJknH['film_rating_short']
    vWtgQsluUqrEBjTPMixOpLyADdJknR =vWtgQsluUqrEBjTPMixOpLyADdJknH['film_rating_long']
    if vWtgQsluUqrEBjTPMixOpLyADdJkna=='movies':
     vWtgQsluUqrEBjTPMixOpLyADdJknX =vWtgQsluUqrEBjTPMixOpLyADdJknH['duration']
    else:
     vWtgQsluUqrEBjTPMixOpLyADdJknX ='0'
    vWtgQsluUqrEBjTPMixOpLyADdJknS={'code':vWtgQsluUqrEBjTPMixOpLyADdJknK,'content_type':vWtgQsluUqrEBjTPMixOpLyADdJkna,'title':vWtgQsluUqrEBjTPMixOpLyADdJknz,'story':vWtgQsluUqrEBjTPMixOpLyADdJknV,'thumbnail':vWtgQsluUqrEBjTPMixOpLyADdJkno,'year':vWtgQsluUqrEBjTPMixOpLyADdJknF,'film_rating_code':vWtgQsluUqrEBjTPMixOpLyADdJkne,'film_rating_short':vWtgQsluUqrEBjTPMixOpLyADdJknb,'film_rating_long':vWtgQsluUqrEBjTPMixOpLyADdJknR,'duration':vWtgQsluUqrEBjTPMixOpLyADdJknX}
    vWtgQsluUqrEBjTPMixOpLyADdJkIX.append(vWtgQsluUqrEBjTPMixOpLyADdJknS)
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   vWtgQsluUqrEBjTPMixOpLyADdJkGn(exception)
  return vWtgQsluUqrEBjTPMixOpLyADdJkIX,vWtgQsluUqrEBjTPMixOpLyADdJknf
 def GetCategoryList_morepage(vWtgQsluUqrEBjTPMixOpLyADdJkIc,stype,vWtgQsluUqrEBjTPMixOpLyADdJknw,vWtgQsluUqrEBjTPMixOpLyADdJknm,page_int,in_sort):
  vWtgQsluUqrEBjTPMixOpLyADdJknf=vWtgQsluUqrEBjTPMixOpLyADdJkHN
  if not('categories' in vWtgQsluUqrEBjTPMixOpLyADdJknm):return vWtgQsluUqrEBjTPMixOpLyADdJkHC
  try:
   vWtgQsluUqrEBjTPMixOpLyADdJkIN ='/api/categories/contents.json'
   vWtgQsluUqrEBjTPMixOpLyADdJkIC=vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN+vWtgQsluUqrEBjTPMixOpLyADdJkIN
   vWtgQsluUqrEBjTPMixOpLyADdJknh={}
   if stype=='genres':
    vWtgQsluUqrEBjTPMixOpLyADdJknh['genre']=vWtgQsluUqrEBjTPMixOpLyADdJknw
   else:
    vWtgQsluUqrEBjTPMixOpLyADdJknh['tag'] =vWtgQsluUqrEBjTPMixOpLyADdJknw
   vWtgQsluUqrEBjTPMixOpLyADdJknh['order']=in_sort 
   if page_int>1:
    vWtgQsluUqrEBjTPMixOpLyADdJknh['page']=vWtgQsluUqrEBjTPMixOpLyADdJkGc(page_int-1)
   vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Get',vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJknh,headers=vWtgQsluUqrEBjTPMixOpLyADdJkHX,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkHX)
   vWtgQsluUqrEBjTPMixOpLyADdJknI=json.loads(vWtgQsluUqrEBjTPMixOpLyADdJkIo.text)
   vWtgQsluUqrEBjTPMixOpLyADdJknf=vWtgQsluUqrEBjTPMixOpLyADdJknI['meta']['has_next']
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   vWtgQsluUqrEBjTPMixOpLyADdJkGn(exception)
  return vWtgQsluUqrEBjTPMixOpLyADdJknf
 def GetProgramInfo(vWtgQsluUqrEBjTPMixOpLyADdJkIc,program_code):
  vWtgQsluUqrEBjTPMixOpLyADdJknN={}
  try:
   vWtgQsluUqrEBjTPMixOpLyADdJkIN ='/api/contents/'+program_code
   vWtgQsluUqrEBjTPMixOpLyADdJkIC=vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN+vWtgQsluUqrEBjTPMixOpLyADdJkIN
   vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Get',vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJkHX,headers=vWtgQsluUqrEBjTPMixOpLyADdJkHX,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkHX)
   vWtgQsluUqrEBjTPMixOpLyADdJknI=json.loads(vWtgQsluUqrEBjTPMixOpLyADdJkIo.text)
   vWtgQsluUqrEBjTPMixOpLyADdJknC=img_clearlogo=''
   vWtgQsluUqrEBjTPMixOpLyADdJknC=vWtgQsluUqrEBjTPMixOpLyADdJknI.get('poster').get('original')
   if vWtgQsluUqrEBjTPMixOpLyADdJkGH(vWtgQsluUqrEBjTPMixOpLyADdJknI.get('title_logos'))>0:img_clearlogo=vWtgQsluUqrEBjTPMixOpLyADdJknI.get('title_logos')[0].get('src')
   vWtgQsluUqrEBjTPMixOpLyADdJknN={'imgPoster':vWtgQsluUqrEBjTPMixOpLyADdJknC,'imgClearlogo':img_clearlogo}
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   vWtgQsluUqrEBjTPMixOpLyADdJkGn(exception)
  return vWtgQsluUqrEBjTPMixOpLyADdJknN
 def GetEpisodoList(vWtgQsluUqrEBjTPMixOpLyADdJkIc,program_code,page_int,orderby='asc'):
  vWtgQsluUqrEBjTPMixOpLyADdJkIX=[]
  vWtgQsluUqrEBjTPMixOpLyADdJknf=vWtgQsluUqrEBjTPMixOpLyADdJkHN
  vWtgQsluUqrEBjTPMixOpLyADdJkcI=''
  try:
   vWtgQsluUqrEBjTPMixOpLyADdJkIN ='/api/contents/'+program_code+'/tv_episodes.json'
   vWtgQsluUqrEBjTPMixOpLyADdJkIC=vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN+vWtgQsluUqrEBjTPMixOpLyADdJkIN
   vWtgQsluUqrEBjTPMixOpLyADdJknh={'all':'true'}
   vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Get',vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJknh,headers=vWtgQsluUqrEBjTPMixOpLyADdJkHX,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkHX)
   vWtgQsluUqrEBjTPMixOpLyADdJknI=json.loads(vWtgQsluUqrEBjTPMixOpLyADdJkIo.text)
   if not('tv_episode_codes' in vWtgQsluUqrEBjTPMixOpLyADdJknI):return vWtgQsluUqrEBjTPMixOpLyADdJkIX,vWtgQsluUqrEBjTPMixOpLyADdJknf
   vWtgQsluUqrEBjTPMixOpLyADdJknc=vWtgQsluUqrEBjTPMixOpLyADdJknI['tv_episode_codes']
   vWtgQsluUqrEBjTPMixOpLyADdJkcn=vWtgQsluUqrEBjTPMixOpLyADdJkGH(vWtgQsluUqrEBjTPMixOpLyADdJknc)
   vWtgQsluUqrEBjTPMixOpLyADdJkcH =vWtgQsluUqrEBjTPMixOpLyADdJkGm(vWtgQsluUqrEBjTPMixOpLyADdJkcn//(vWtgQsluUqrEBjTPMixOpLyADdJkIc.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    vWtgQsluUqrEBjTPMixOpLyADdJkcG =(vWtgQsluUqrEBjTPMixOpLyADdJkcn-1)-((page_int-1)*vWtgQsluUqrEBjTPMixOpLyADdJkIc.EPISODE_LIMIT)
   else:
    vWtgQsluUqrEBjTPMixOpLyADdJkcG =(page_int-1)*vWtgQsluUqrEBjTPMixOpLyADdJkIc.EPISODE_LIMIT
   for i in vWtgQsluUqrEBjTPMixOpLyADdJkGw(vWtgQsluUqrEBjTPMixOpLyADdJkIc.EPISODE_LIMIT):
    if orderby=='desc':
     vWtgQsluUqrEBjTPMixOpLyADdJkcm=vWtgQsluUqrEBjTPMixOpLyADdJkcG-i
     if vWtgQsluUqrEBjTPMixOpLyADdJkcm<0:break
    else:
     vWtgQsluUqrEBjTPMixOpLyADdJkcm=vWtgQsluUqrEBjTPMixOpLyADdJkcG+i
     if vWtgQsluUqrEBjTPMixOpLyADdJkcm>=vWtgQsluUqrEBjTPMixOpLyADdJkcn:break
    if vWtgQsluUqrEBjTPMixOpLyADdJkcI!='':vWtgQsluUqrEBjTPMixOpLyADdJkcI+=','
    vWtgQsluUqrEBjTPMixOpLyADdJkcI+=vWtgQsluUqrEBjTPMixOpLyADdJknc[vWtgQsluUqrEBjTPMixOpLyADdJkcm]
   if vWtgQsluUqrEBjTPMixOpLyADdJkcH>page_int:vWtgQsluUqrEBjTPMixOpLyADdJknf=vWtgQsluUqrEBjTPMixOpLyADdJkHC
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   vWtgQsluUqrEBjTPMixOpLyADdJkGn(exception)
  vWtgQsluUqrEBjTPMixOpLyADdJkcw=vWtgQsluUqrEBjTPMixOpLyADdJkIc.GetProgramInfo(program_code)
  try:
   vWtgQsluUqrEBjTPMixOpLyADdJkIC=vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN+vWtgQsluUqrEBjTPMixOpLyADdJkIN
   vWtgQsluUqrEBjTPMixOpLyADdJknh={'codes':vWtgQsluUqrEBjTPMixOpLyADdJkcI}
   vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Get',vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJknh,headers=vWtgQsluUqrEBjTPMixOpLyADdJkHX,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkHX)
   vWtgQsluUqrEBjTPMixOpLyADdJknI=json.loads(vWtgQsluUqrEBjTPMixOpLyADdJkIo.text)
   if not('tv_episodes' in vWtgQsluUqrEBjTPMixOpLyADdJknI):return vWtgQsluUqrEBjTPMixOpLyADdJkIX
   vWtgQsluUqrEBjTPMixOpLyADdJknc=vWtgQsluUqrEBjTPMixOpLyADdJknI['tv_episodes']
   for vWtgQsluUqrEBjTPMixOpLyADdJknH in vWtgQsluUqrEBjTPMixOpLyADdJknc:
    vWtgQsluUqrEBjTPMixOpLyADdJknK =vWtgQsluUqrEBjTPMixOpLyADdJknH['code']
    if vWtgQsluUqrEBjTPMixOpLyADdJknH['title']:
     vWtgQsluUqrEBjTPMixOpLyADdJknz =vWtgQsluUqrEBjTPMixOpLyADdJknH['title']
    else:
     vWtgQsluUqrEBjTPMixOpLyADdJknz =''
    vWtgQsluUqrEBjTPMixOpLyADdJknY=vWtgQsluUqrEBjTPMixOpLyADdJkHb=vWtgQsluUqrEBjTPMixOpLyADdJkHe=vWtgQsluUqrEBjTPMixOpLyADdJkcS=''
    vWtgQsluUqrEBjTPMixOpLyADdJknY =vWtgQsluUqrEBjTPMixOpLyADdJkcw.get('imgPoster')
    vWtgQsluUqrEBjTPMixOpLyADdJkcS=vWtgQsluUqrEBjTPMixOpLyADdJkcw.get('imgClearlogo')
    if vWtgQsluUqrEBjTPMixOpLyADdJknH.get('stillcut') !=vWtgQsluUqrEBjTPMixOpLyADdJkHX:vWtgQsluUqrEBjTPMixOpLyADdJkHb =vWtgQsluUqrEBjTPMixOpLyADdJknH.get('stillcut').get('large')
    if vWtgQsluUqrEBjTPMixOpLyADdJknH.get('tv_season_stillcut')!=vWtgQsluUqrEBjTPMixOpLyADdJkHX:vWtgQsluUqrEBjTPMixOpLyADdJkHe=vWtgQsluUqrEBjTPMixOpLyADdJknH.get('tv_season_stillcut').get('large')
    vWtgQsluUqrEBjTPMixOpLyADdJkno={'thumb':vWtgQsluUqrEBjTPMixOpLyADdJkHb,'poster':vWtgQsluUqrEBjTPMixOpLyADdJknY,'fanart':vWtgQsluUqrEBjTPMixOpLyADdJkHe,'clearlogo':vWtgQsluUqrEBjTPMixOpLyADdJkcS}
    vWtgQsluUqrEBjTPMixOpLyADdJkcf =vWtgQsluUqrEBjTPMixOpLyADdJknH['display_number']
    vWtgQsluUqrEBjTPMixOpLyADdJkch=vWtgQsluUqrEBjTPMixOpLyADdJknH['tv_season_title']
    vWtgQsluUqrEBjTPMixOpLyADdJknX =vWtgQsluUqrEBjTPMixOpLyADdJknH['duration']
    try:
     vWtgQsluUqrEBjTPMixOpLyADdJkcK=vWtgQsluUqrEBjTPMixOpLyADdJknH['episode_number']
    except:
     vWtgQsluUqrEBjTPMixOpLyADdJkcK='0'
    vWtgQsluUqrEBjTPMixOpLyADdJknS={'code':vWtgQsluUqrEBjTPMixOpLyADdJknK,'title':vWtgQsluUqrEBjTPMixOpLyADdJknz,'thumbnail':vWtgQsluUqrEBjTPMixOpLyADdJkno,'display_num':vWtgQsluUqrEBjTPMixOpLyADdJkcf,'season_title':vWtgQsluUqrEBjTPMixOpLyADdJkch,'duration':vWtgQsluUqrEBjTPMixOpLyADdJknX,'episode_number':vWtgQsluUqrEBjTPMixOpLyADdJkcK}
    vWtgQsluUqrEBjTPMixOpLyADdJkIX.append(vWtgQsluUqrEBjTPMixOpLyADdJknS)
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   vWtgQsluUqrEBjTPMixOpLyADdJkGn(exception)
  return vWtgQsluUqrEBjTPMixOpLyADdJkIX,vWtgQsluUqrEBjTPMixOpLyADdJknf
 def GetSearchList(vWtgQsluUqrEBjTPMixOpLyADdJkIc,search_key,page_int):
  vWtgQsluUqrEBjTPMixOpLyADdJkca=[]
  vWtgQsluUqrEBjTPMixOpLyADdJknf=vWtgQsluUqrEBjTPMixOpLyADdJkHN
  try:
   vWtgQsluUqrEBjTPMixOpLyADdJkIN ='/api/search.json'
   vWtgQsluUqrEBjTPMixOpLyADdJkIC=vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN+vWtgQsluUqrEBjTPMixOpLyADdJkIN
   vWtgQsluUqrEBjTPMixOpLyADdJknh={'query':search_key,'page':vWtgQsluUqrEBjTPMixOpLyADdJkGc(page_int),'per':vWtgQsluUqrEBjTPMixOpLyADdJkGc(vWtgQsluUqrEBjTPMixOpLyADdJkIc.SEARCH_LIMIT),'exclude':'limited'}
   vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Get',vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJknh,headers=vWtgQsluUqrEBjTPMixOpLyADdJkHX,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkHX)
   vWtgQsluUqrEBjTPMixOpLyADdJknI=json.loads(vWtgQsluUqrEBjTPMixOpLyADdJkIo.text)
   if not('results' in vWtgQsluUqrEBjTPMixOpLyADdJknI):return vWtgQsluUqrEBjTPMixOpLyADdJkca,vWtgQsluUqrEBjTPMixOpLyADdJknf
   vWtgQsluUqrEBjTPMixOpLyADdJknc=vWtgQsluUqrEBjTPMixOpLyADdJknI['results']
   vWtgQsluUqrEBjTPMixOpLyADdJknf=vWtgQsluUqrEBjTPMixOpLyADdJknI['meta']['has_next']
   for vWtgQsluUqrEBjTPMixOpLyADdJknH in vWtgQsluUqrEBjTPMixOpLyADdJknc:
    vWtgQsluUqrEBjTPMixOpLyADdJknK =vWtgQsluUqrEBjTPMixOpLyADdJknH['code']
    vWtgQsluUqrEBjTPMixOpLyADdJkna=vWtgQsluUqrEBjTPMixOpLyADdJknH['content_type']
    vWtgQsluUqrEBjTPMixOpLyADdJknz =vWtgQsluUqrEBjTPMixOpLyADdJknH['title']
    vWtgQsluUqrEBjTPMixOpLyADdJknV =vWtgQsluUqrEBjTPMixOpLyADdJknH['story']
    vWtgQsluUqrEBjTPMixOpLyADdJknY=vWtgQsluUqrEBjTPMixOpLyADdJkHb=vWtgQsluUqrEBjTPMixOpLyADdJkHe=''
    if vWtgQsluUqrEBjTPMixOpLyADdJknH.get('poster') !=vWtgQsluUqrEBjTPMixOpLyADdJkHX:vWtgQsluUqrEBjTPMixOpLyADdJknY=vWtgQsluUqrEBjTPMixOpLyADdJknH.get('poster').get('original')
    if vWtgQsluUqrEBjTPMixOpLyADdJknH.get('stillcut')!=vWtgQsluUqrEBjTPMixOpLyADdJkHX:vWtgQsluUqrEBjTPMixOpLyADdJkHb =vWtgQsluUqrEBjTPMixOpLyADdJknH.get('stillcut').get('large')
    if vWtgQsluUqrEBjTPMixOpLyADdJknH.get('thumbnail')!=vWtgQsluUqrEBjTPMixOpLyADdJkHX:vWtgQsluUqrEBjTPMixOpLyADdJkHe=vWtgQsluUqrEBjTPMixOpLyADdJknH.get('thumbnail').get('large')
    if vWtgQsluUqrEBjTPMixOpLyADdJkHe=='' :vWtgQsluUqrEBjTPMixOpLyADdJkHe=vWtgQsluUqrEBjTPMixOpLyADdJkHb
    vWtgQsluUqrEBjTPMixOpLyADdJkno={'thumb':vWtgQsluUqrEBjTPMixOpLyADdJkHb,'poster':vWtgQsluUqrEBjTPMixOpLyADdJknY,'fanart':vWtgQsluUqrEBjTPMixOpLyADdJkHe}
    vWtgQsluUqrEBjTPMixOpLyADdJknF =vWtgQsluUqrEBjTPMixOpLyADdJknH['year']
    vWtgQsluUqrEBjTPMixOpLyADdJkne =vWtgQsluUqrEBjTPMixOpLyADdJknH['film_rating_code']
    vWtgQsluUqrEBjTPMixOpLyADdJknb=vWtgQsluUqrEBjTPMixOpLyADdJknH['film_rating_short']
    vWtgQsluUqrEBjTPMixOpLyADdJknR =vWtgQsluUqrEBjTPMixOpLyADdJknH['film_rating_long']
    if vWtgQsluUqrEBjTPMixOpLyADdJkna=='movies':
     vWtgQsluUqrEBjTPMixOpLyADdJknX =vWtgQsluUqrEBjTPMixOpLyADdJknH['duration']
    else:
     vWtgQsluUqrEBjTPMixOpLyADdJknX ='0'
    vWtgQsluUqrEBjTPMixOpLyADdJknS={'code':vWtgQsluUqrEBjTPMixOpLyADdJknK,'content_type':vWtgQsluUqrEBjTPMixOpLyADdJkna,'title':vWtgQsluUqrEBjTPMixOpLyADdJknz,'story':vWtgQsluUqrEBjTPMixOpLyADdJknV,'thumbnail':vWtgQsluUqrEBjTPMixOpLyADdJkno,'year':vWtgQsluUqrEBjTPMixOpLyADdJknF,'film_rating_code':vWtgQsluUqrEBjTPMixOpLyADdJkne,'film_rating_short':vWtgQsluUqrEBjTPMixOpLyADdJknb,'film_rating_long':vWtgQsluUqrEBjTPMixOpLyADdJknR,'duration':vWtgQsluUqrEBjTPMixOpLyADdJknX}
    vWtgQsluUqrEBjTPMixOpLyADdJkca.append(vWtgQsluUqrEBjTPMixOpLyADdJknS)
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   vWtgQsluUqrEBjTPMixOpLyADdJkGn(exception)
  return vWtgQsluUqrEBjTPMixOpLyADdJkca,vWtgQsluUqrEBjTPMixOpLyADdJknf
 def GetProfilesList(vWtgQsluUqrEBjTPMixOpLyADdJkIc):
  vWtgQsluUqrEBjTPMixOpLyADdJkIb=[]
  try:
   vWtgQsluUqrEBjTPMixOpLyADdJkIN ='/manage_profiles'
   vWtgQsluUqrEBjTPMixOpLyADdJkIC=vWtgQsluUqrEBjTPMixOpLyADdJkIc.MAIN_DOMAIN+vWtgQsluUqrEBjTPMixOpLyADdJkIN
   vWtgQsluUqrEBjTPMixOpLyADdJkIF=vWtgQsluUqrEBjTPMixOpLyADdJkIc.makeDefaultCookies()
   vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Get',vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJkHX,headers=vWtgQsluUqrEBjTPMixOpLyADdJkHX,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkIF,redirects=vWtgQsluUqrEBjTPMixOpLyADdJkHC)
   vWtgQsluUqrEBjTPMixOpLyADdJkcz=vWtgQsluUqrEBjTPMixOpLyADdJkIo.text
   vWtgQsluUqrEBjTPMixOpLyADdJkcV =re.findall('/api/users/me.{5000}',vWtgQsluUqrEBjTPMixOpLyADdJkcz)[0]
   vWtgQsluUqrEBjTPMixOpLyADdJkcV =vWtgQsluUqrEBjTPMixOpLyADdJkcV.replace('&quot;','')
   vWtgQsluUqrEBjTPMixOpLyADdJkIb=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',vWtgQsluUqrEBjTPMixOpLyADdJkcV)
   for i in vWtgQsluUqrEBjTPMixOpLyADdJkGw(vWtgQsluUqrEBjTPMixOpLyADdJkGH(vWtgQsluUqrEBjTPMixOpLyADdJkIb)):
    vWtgQsluUqrEBjTPMixOpLyADdJkcY=vWtgQsluUqrEBjTPMixOpLyADdJkIb[i]
    vWtgQsluUqrEBjTPMixOpLyADdJkcY =vWtgQsluUqrEBjTPMixOpLyADdJkcY.split(':')[1]
    vWtgQsluUqrEBjTPMixOpLyADdJkIb[i]=vWtgQsluUqrEBjTPMixOpLyADdJkcY.split(',')[0]
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   vWtgQsluUqrEBjTPMixOpLyADdJkGn(exception)
  return vWtgQsluUqrEBjTPMixOpLyADdJkIb
 def GetProfilesConvert(vWtgQsluUqrEBjTPMixOpLyADdJkIc,vWtgQsluUqrEBjTPMixOpLyADdJkIw):
  vWtgQsluUqrEBjTPMixOpLyADdJkco=''
  vWtgQsluUqrEBjTPMixOpLyADdJkcF=''
  try:
   vWtgQsluUqrEBjTPMixOpLyADdJkIN ='/api/users/'+vWtgQsluUqrEBjTPMixOpLyADdJkIw+'/convert'
   vWtgQsluUqrEBjTPMixOpLyADdJkIC=vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN+vWtgQsluUqrEBjTPMixOpLyADdJkIN
   vWtgQsluUqrEBjTPMixOpLyADdJkIF=vWtgQsluUqrEBjTPMixOpLyADdJkIc.makeDefaultCookies()
   vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Put',vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJkHX,headers=vWtgQsluUqrEBjTPMixOpLyADdJkHX,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkIF)
   for vWtgQsluUqrEBjTPMixOpLyADdJkIF in vWtgQsluUqrEBjTPMixOpLyADdJkIo.cookies:
    if vWtgQsluUqrEBjTPMixOpLyADdJkIF.name=='_s_guitv':
     vWtgQsluUqrEBjTPMixOpLyADdJkce=vWtgQsluUqrEBjTPMixOpLyADdJkIF.value
    elif vWtgQsluUqrEBjTPMixOpLyADdJkIF.name=='_guinness-premium_session':
     vWtgQsluUqrEBjTPMixOpLyADdJkIe=vWtgQsluUqrEBjTPMixOpLyADdJkIF.value
   if vWtgQsluUqrEBjTPMixOpLyADdJkce:
    vWtgQsluUqrEBjTPMixOpLyADdJkco=vWtgQsluUqrEBjTPMixOpLyADdJkce
   if vWtgQsluUqrEBjTPMixOpLyADdJkIe:
    vWtgQsluUqrEBjTPMixOpLyADdJkcF=vWtgQsluUqrEBjTPMixOpLyADdJkIe
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   vWtgQsluUqrEBjTPMixOpLyADdJkco=''
   vWtgQsluUqrEBjTPMixOpLyADdJkcF=''
  return vWtgQsluUqrEBjTPMixOpLyADdJkco,vWtgQsluUqrEBjTPMixOpLyADdJkcF
 def Get_Now_Datetime(vWtgQsluUqrEBjTPMixOpLyADdJkIc):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(vWtgQsluUqrEBjTPMixOpLyADdJkIc,movie_code,quality_str):
  vWtgQsluUqrEBjTPMixOpLyADdJkcR=vWtgQsluUqrEBjTPMixOpLyADdJkcN=vWtgQsluUqrEBjTPMixOpLyADdJkHG=''
  try:
   vWtgQsluUqrEBjTPMixOpLyADdJkIN='/api/watch/'+movie_code+'.json'
   vWtgQsluUqrEBjTPMixOpLyADdJkIC=vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN+vWtgQsluUqrEBjTPMixOpLyADdJkIN
   vWtgQsluUqrEBjTPMixOpLyADdJkIY={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   vWtgQsluUqrEBjTPMixOpLyADdJkIF=vWtgQsluUqrEBjTPMixOpLyADdJkIc.makeDefaultCookies()
   vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Get',vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJkHX,headers=vWtgQsluUqrEBjTPMixOpLyADdJkIY,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkIF)
   vWtgQsluUqrEBjTPMixOpLyADdJknI=json.loads(vWtgQsluUqrEBjTPMixOpLyADdJkIo.text)
   vWtgQsluUqrEBjTPMixOpLyADdJkcR=vWtgQsluUqrEBjTPMixOpLyADdJknI['streams'][0]['source']
   if vWtgQsluUqrEBjTPMixOpLyADdJkcR==vWtgQsluUqrEBjTPMixOpLyADdJkHX:return(vWtgQsluUqrEBjTPMixOpLyADdJkcR,vWtgQsluUqrEBjTPMixOpLyADdJkcN,vWtgQsluUqrEBjTPMixOpLyADdJkHG)
   if 'subtitles' in vWtgQsluUqrEBjTPMixOpLyADdJknI['streams'][0]:
    for vWtgQsluUqrEBjTPMixOpLyADdJkcX in vWtgQsluUqrEBjTPMixOpLyADdJknI['streams'][0]['subtitles']:
     if vWtgQsluUqrEBjTPMixOpLyADdJkcX['lang']=='ko':
      vWtgQsluUqrEBjTPMixOpLyADdJkcN=vWtgQsluUqrEBjTPMixOpLyADdJkcX['url']
      break
   vWtgQsluUqrEBjTPMixOpLyADdJkcC =vWtgQsluUqrEBjTPMixOpLyADdJknI['ping_payload']
   vWtgQsluUqrEBjTPMixOpLyADdJkHI =vWtgQsluUqrEBjTPMixOpLyADdJkIc.WATCHA_USERCD
   vWtgQsluUqrEBjTPMixOpLyADdJkHn={'merchant':'giitd_frograms','sessionId':vWtgQsluUqrEBjTPMixOpLyADdJkcC,'userId':vWtgQsluUqrEBjTPMixOpLyADdJkHI}
   vWtgQsluUqrEBjTPMixOpLyADdJkHc=json.dumps(vWtgQsluUqrEBjTPMixOpLyADdJkHn,separators=(",",":")).encode('UTF-8')
   vWtgQsluUqrEBjTPMixOpLyADdJkHG=base64.b64encode(vWtgQsluUqrEBjTPMixOpLyADdJkHc)
  except vWtgQsluUqrEBjTPMixOpLyADdJkGI as exception:
   return(vWtgQsluUqrEBjTPMixOpLyADdJkcR,vWtgQsluUqrEBjTPMixOpLyADdJkcN,vWtgQsluUqrEBjTPMixOpLyADdJkHG)
  return(vWtgQsluUqrEBjTPMixOpLyADdJkcR,vWtgQsluUqrEBjTPMixOpLyADdJkcN,vWtgQsluUqrEBjTPMixOpLyADdJkHG) 
 def GetBookmarkInfo(vWtgQsluUqrEBjTPMixOpLyADdJkIc,videoid,vidtype):
  vWtgQsluUqrEBjTPMixOpLyADdJkHm={'indexinfo':{'ott':'watcha','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  vWtgQsluUqrEBjTPMixOpLyADdJkIC=vWtgQsluUqrEBjTPMixOpLyADdJkIc.API_DOMAIN+'/api/contents/'+videoid
  vWtgQsluUqrEBjTPMixOpLyADdJkIo=vWtgQsluUqrEBjTPMixOpLyADdJkIc.callRequestCookies('Get',vWtgQsluUqrEBjTPMixOpLyADdJkIC,payload=vWtgQsluUqrEBjTPMixOpLyADdJkHX,params=vWtgQsluUqrEBjTPMixOpLyADdJkHX,headers=vWtgQsluUqrEBjTPMixOpLyADdJkHX,cookies=vWtgQsluUqrEBjTPMixOpLyADdJkHX)
  vWtgQsluUqrEBjTPMixOpLyADdJkHw=json.loads(vWtgQsluUqrEBjTPMixOpLyADdJkIo.text)
  if not('title' in vWtgQsluUqrEBjTPMixOpLyADdJkHw):return{}
  vWtgQsluUqrEBjTPMixOpLyADdJkHS=vWtgQsluUqrEBjTPMixOpLyADdJkHw
  vWtgQsluUqrEBjTPMixOpLyADdJkHf=vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('title')
  vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['infoLabels']['title']=vWtgQsluUqrEBjTPMixOpLyADdJkHf
  vWtgQsluUqrEBjTPMixOpLyADdJkHf +=u'  (%s년 - %s)'%(vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('year'),vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('film_rating_short'))
  vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['title'] =vWtgQsluUqrEBjTPMixOpLyADdJkHf
  vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['infoLabels']['mpaa'] =vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('film_rating_long')
  vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['infoLabels']['plot'] =vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('story').replace('<br>','\n')
  vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['infoLabels']['year'] =vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('year')
  if vidtype=='movies':
   vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['infoLabels']['duration']=vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('duration')
  vWtgQsluUqrEBjTPMixOpLyADdJkHh=[]
  for vWtgQsluUqrEBjTPMixOpLyADdJkHK in vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('actors'):
   vWtgQsluUqrEBjTPMixOpLyADdJkHa =vWtgQsluUqrEBjTPMixOpLyADdJkHK.get('name')
   vWtgQsluUqrEBjTPMixOpLyADdJkHz='' if vWtgQsluUqrEBjTPMixOpLyADdJkHK.get('photo')==vWtgQsluUqrEBjTPMixOpLyADdJkHX else vWtgQsluUqrEBjTPMixOpLyADdJkHK.get('photo').get('small')
   vWtgQsluUqrEBjTPMixOpLyADdJkHh.append({'name':vWtgQsluUqrEBjTPMixOpLyADdJkHa,'thumbnail':vWtgQsluUqrEBjTPMixOpLyADdJkHz})
  if vWtgQsluUqrEBjTPMixOpLyADdJkGH(vWtgQsluUqrEBjTPMixOpLyADdJkHh)>0:
   vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['infoLabels']['cast']=vWtgQsluUqrEBjTPMixOpLyADdJkHh
  vWtgQsluUqrEBjTPMixOpLyADdJkHV=[]
  for vWtgQsluUqrEBjTPMixOpLyADdJkHY in vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('directors'):vWtgQsluUqrEBjTPMixOpLyADdJkHV.append(vWtgQsluUqrEBjTPMixOpLyADdJkHY.get('name'))
  if vWtgQsluUqrEBjTPMixOpLyADdJkGH(vWtgQsluUqrEBjTPMixOpLyADdJkHV)>0:
   vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['infoLabels']['director']=vWtgQsluUqrEBjTPMixOpLyADdJkHV
  vWtgQsluUqrEBjTPMixOpLyADdJkHo=[]
  for vWtgQsluUqrEBjTPMixOpLyADdJkHF in vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('genres'):vWtgQsluUqrEBjTPMixOpLyADdJkHo.append(vWtgQsluUqrEBjTPMixOpLyADdJkHF.get('name'))
  if vWtgQsluUqrEBjTPMixOpLyADdJkGH(vWtgQsluUqrEBjTPMixOpLyADdJkHo)>0:
   vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['infoLabels']['genre']=vWtgQsluUqrEBjTPMixOpLyADdJkHo
  vWtgQsluUqrEBjTPMixOpLyADdJknY =''
  vWtgQsluUqrEBjTPMixOpLyADdJkHe =''
  vWtgQsluUqrEBjTPMixOpLyADdJkHb =''
  if vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('poster') !=vWtgQsluUqrEBjTPMixOpLyADdJkHX:vWtgQsluUqrEBjTPMixOpLyADdJknY =vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('poster').get('original')
  if vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('thumbnail')!=vWtgQsluUqrEBjTPMixOpLyADdJkHX:vWtgQsluUqrEBjTPMixOpLyADdJkHe =vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('thumbnail').get('large')
  if vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('stillcut')!=vWtgQsluUqrEBjTPMixOpLyADdJkHX:vWtgQsluUqrEBjTPMixOpLyADdJkHb =vWtgQsluUqrEBjTPMixOpLyADdJkHS.get('stillcut').get('large')
  if vWtgQsluUqrEBjTPMixOpLyADdJkHe=='':vWtgQsluUqrEBjTPMixOpLyADdJkHe=vWtgQsluUqrEBjTPMixOpLyADdJkHb
  vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['thumbnail']['poster']=vWtgQsluUqrEBjTPMixOpLyADdJknY
  vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['thumbnail']['fanart']=vWtgQsluUqrEBjTPMixOpLyADdJkHe
  vWtgQsluUqrEBjTPMixOpLyADdJkHm['saveinfo']['thumbnail']['thumb']=vWtgQsluUqrEBjTPMixOpLyADdJkHb
  return vWtgQsluUqrEBjTPMixOpLyADdJkHm
# Created by pyminifier (https://github.com/liftoff/pyminifier)
