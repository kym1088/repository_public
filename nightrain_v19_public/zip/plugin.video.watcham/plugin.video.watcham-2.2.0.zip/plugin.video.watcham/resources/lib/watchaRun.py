__author__="NightRain"
lwbiMJFadqnYLoEtkOfTHCrQVusIPp=object
lwbiMJFadqnYLoEtkOfTHCrQVusIPG=None
lwbiMJFadqnYLoEtkOfTHCrQVusIPW=int
lwbiMJFadqnYLoEtkOfTHCrQVusIPA=True
lwbiMJFadqnYLoEtkOfTHCrQVusIPD=False
lwbiMJFadqnYLoEtkOfTHCrQVusIPR=type
lwbiMJFadqnYLoEtkOfTHCrQVusIPe=dict
lwbiMJFadqnYLoEtkOfTHCrQVusIPS=len
lwbiMJFadqnYLoEtkOfTHCrQVusIPy=range
lwbiMJFadqnYLoEtkOfTHCrQVusIPX=str
lwbiMJFadqnYLoEtkOfTHCrQVusIPh=open
lwbiMJFadqnYLoEtkOfTHCrQVusIPv=Exception
lwbiMJFadqnYLoEtkOfTHCrQVusIPg=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
lwbiMJFadqnYLoEtkOfTHCrQVusINx=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-','icon':'history.png'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','sort':'-','icon':'bookmark.png'}]
lwbiMJFadqnYLoEtkOfTHCrQVusINc=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
lwbiMJFadqnYLoEtkOfTHCrQVusINm=40
lwbiMJFadqnYLoEtkOfTHCrQVusINj =20
lwbiMJFadqnYLoEtkOfTHCrQVusINP =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
lwbiMJFadqnYLoEtkOfTHCrQVusINp =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
lwbiMJFadqnYLoEtkOfTHCrQVusING=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
from watchaCore import*
class lwbiMJFadqnYLoEtkOfTHCrQVusINU(lwbiMJFadqnYLoEtkOfTHCrQVusIPp):
 def __init__(lwbiMJFadqnYLoEtkOfTHCrQVusINW,lwbiMJFadqnYLoEtkOfTHCrQVusINA,lwbiMJFadqnYLoEtkOfTHCrQVusIND,lwbiMJFadqnYLoEtkOfTHCrQVusINR):
  lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_url =lwbiMJFadqnYLoEtkOfTHCrQVusINA
  lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle=lwbiMJFadqnYLoEtkOfTHCrQVusIND
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params =lwbiMJFadqnYLoEtkOfTHCrQVusINR
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj =vWtgQsluUqrEBjTPMixOpLyADdJkIn() 
 def addon_noti(lwbiMJFadqnYLoEtkOfTHCrQVusINW,sting):
  try:
   lwbiMJFadqnYLoEtkOfTHCrQVusINS=xbmcgui.Dialog()
   lwbiMJFadqnYLoEtkOfTHCrQVusINS.notification(__addonname__,sting)
  except:
   lwbiMJFadqnYLoEtkOfTHCrQVusIPG
 def addon_log(lwbiMJFadqnYLoEtkOfTHCrQVusINW,string):
  try:
   lwbiMJFadqnYLoEtkOfTHCrQVusINy=string.encode('utf-8','ignore')
  except:
   lwbiMJFadqnYLoEtkOfTHCrQVusINy='addonException: addon_log'
  lwbiMJFadqnYLoEtkOfTHCrQVusINX=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,lwbiMJFadqnYLoEtkOfTHCrQVusINy),level=lwbiMJFadqnYLoEtkOfTHCrQVusINX)
 def get_keyboard_input(lwbiMJFadqnYLoEtkOfTHCrQVusINW,lwbiMJFadqnYLoEtkOfTHCrQVusIUD):
  lwbiMJFadqnYLoEtkOfTHCrQVusINh=lwbiMJFadqnYLoEtkOfTHCrQVusIPG
  kb=xbmc.Keyboard()
  kb.setHeading(lwbiMJFadqnYLoEtkOfTHCrQVusIUD)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   lwbiMJFadqnYLoEtkOfTHCrQVusINh=kb.getText()
  return lwbiMJFadqnYLoEtkOfTHCrQVusINh
 def get_settings_login_info(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  lwbiMJFadqnYLoEtkOfTHCrQVusINv =__addon__.getSetting('id')
  lwbiMJFadqnYLoEtkOfTHCrQVusINg =__addon__.getSetting('pw')
  lwbiMJFadqnYLoEtkOfTHCrQVusINB=lwbiMJFadqnYLoEtkOfTHCrQVusIPW(__addon__.getSetting('selected_profile'))
  return(lwbiMJFadqnYLoEtkOfTHCrQVusINv,lwbiMJFadqnYLoEtkOfTHCrQVusINg,lwbiMJFadqnYLoEtkOfTHCrQVusINB)
 def get_settings_totalsearch(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  lwbiMJFadqnYLoEtkOfTHCrQVusINz =lwbiMJFadqnYLoEtkOfTHCrQVusIPA if __addon__.getSetting('local_search')=='true' else lwbiMJFadqnYLoEtkOfTHCrQVusIPD
  lwbiMJFadqnYLoEtkOfTHCrQVusINK=lwbiMJFadqnYLoEtkOfTHCrQVusIPA if __addon__.getSetting('local_history')=='true' else lwbiMJFadqnYLoEtkOfTHCrQVusIPD
  lwbiMJFadqnYLoEtkOfTHCrQVusIUN =lwbiMJFadqnYLoEtkOfTHCrQVusIPA if __addon__.getSetting('total_search')=='true' else lwbiMJFadqnYLoEtkOfTHCrQVusIPD
  lwbiMJFadqnYLoEtkOfTHCrQVusIUx=lwbiMJFadqnYLoEtkOfTHCrQVusIPA if __addon__.getSetting('total_history')=='true' else lwbiMJFadqnYLoEtkOfTHCrQVusIPD
  lwbiMJFadqnYLoEtkOfTHCrQVusIUc=lwbiMJFadqnYLoEtkOfTHCrQVusIPA if __addon__.getSetting('menu_bookmark')=='true' else lwbiMJFadqnYLoEtkOfTHCrQVusIPD
  return(lwbiMJFadqnYLoEtkOfTHCrQVusINz,lwbiMJFadqnYLoEtkOfTHCrQVusINK,lwbiMJFadqnYLoEtkOfTHCrQVusIUN,lwbiMJFadqnYLoEtkOfTHCrQVusIUx,lwbiMJFadqnYLoEtkOfTHCrQVusIUc)
 def get_settings_makebookmark(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  return lwbiMJFadqnYLoEtkOfTHCrQVusIPA if __addon__.getSetting('make_bookmark')=='true' else lwbiMJFadqnYLoEtkOfTHCrQVusIPD
 def get_selQuality(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  try:
   lwbiMJFadqnYLoEtkOfTHCrQVusIUm=['3840x2160/1','1920x1080/1','1280x720/1']
   lwbiMJFadqnYLoEtkOfTHCrQVusIUj=lwbiMJFadqnYLoEtkOfTHCrQVusIPW(__addon__.getSetting('selected_quality'))
   return lwbiMJFadqnYLoEtkOfTHCrQVusIUm[lwbiMJFadqnYLoEtkOfTHCrQVusIUj]
  except:
   lwbiMJFadqnYLoEtkOfTHCrQVusIPG
  return 1080 
 def get_settings_direct_replay(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  lwbiMJFadqnYLoEtkOfTHCrQVusIUP=lwbiMJFadqnYLoEtkOfTHCrQVusIPW(__addon__.getSetting('direct_replay'))
  if lwbiMJFadqnYLoEtkOfTHCrQVusIUP==0:
   return lwbiMJFadqnYLoEtkOfTHCrQVusIPD
  else:
   return lwbiMJFadqnYLoEtkOfTHCrQVusIPA
 def set_winCredential(lwbiMJFadqnYLoEtkOfTHCrQVusINW,credential):
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp=xbmcgui.Window(10000)
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_LOGINTIME',lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp=xbmcgui.Window(10000)
  lwbiMJFadqnYLoEtkOfTHCrQVusIUG={'watcha_token':lwbiMJFadqnYLoEtkOfTHCrQVusIUp.getProperty('WATCHA_M_TOKEN'),'watcha_guit':lwbiMJFadqnYLoEtkOfTHCrQVusIUp.getProperty('WATCHA_M_GUIT'),'watcha_guitv':lwbiMJFadqnYLoEtkOfTHCrQVusIUp.getProperty('WATCHA_M_GUITV'),'watcha_usercd':lwbiMJFadqnYLoEtkOfTHCrQVusIUp.getProperty('WATCHA_M_USERCD')}
  return lwbiMJFadqnYLoEtkOfTHCrQVusIUG
 def set_winEpisodeOrderby(lwbiMJFadqnYLoEtkOfTHCrQVusINW,lwbiMJFadqnYLoEtkOfTHCrQVusIUW):
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp=xbmcgui.Window(10000)
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_ORDERBY',lwbiMJFadqnYLoEtkOfTHCrQVusIUW)
 def get_winEpisodeOrderby(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp=xbmcgui.Window(10000)
  return lwbiMJFadqnYLoEtkOfTHCrQVusIUp.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusIUW =args.get('orderby')
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.set_winEpisodeOrderby(lwbiMJFadqnYLoEtkOfTHCrQVusIUW)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusINW,label,sublabel='',img='',infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusIPG,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPA,params='',isLink=lwbiMJFadqnYLoEtkOfTHCrQVusIPD,ContextMenu=lwbiMJFadqnYLoEtkOfTHCrQVusIPG):
  lwbiMJFadqnYLoEtkOfTHCrQVusIUA='%s?%s'%(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_url,urllib.parse.urlencode(params))
  if sublabel:lwbiMJFadqnYLoEtkOfTHCrQVusIUD='%s < %s >'%(label,sublabel)
  else: lwbiMJFadqnYLoEtkOfTHCrQVusIUD=label
  if not img:img='DefaultFolder.png'
  lwbiMJFadqnYLoEtkOfTHCrQVusIUR=xbmcgui.ListItem(lwbiMJFadqnYLoEtkOfTHCrQVusIUD)
  if lwbiMJFadqnYLoEtkOfTHCrQVusIPR(img)==lwbiMJFadqnYLoEtkOfTHCrQVusIPe:
   lwbiMJFadqnYLoEtkOfTHCrQVusIUR.setArt(img)
  else:
   lwbiMJFadqnYLoEtkOfTHCrQVusIUR.setArt({'thumb':img,'poster':img})
  if infoLabels:lwbiMJFadqnYLoEtkOfTHCrQVusIUR.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   lwbiMJFadqnYLoEtkOfTHCrQVusIUR.setProperty('IsPlayable','true')
  if ContextMenu:lwbiMJFadqnYLoEtkOfTHCrQVusIUR.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,lwbiMJFadqnYLoEtkOfTHCrQVusIUA,lwbiMJFadqnYLoEtkOfTHCrQVusIUR,isFolder)
 def dp_Main_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  (lwbiMJFadqnYLoEtkOfTHCrQVusINz,lwbiMJFadqnYLoEtkOfTHCrQVusINK,lwbiMJFadqnYLoEtkOfTHCrQVusIUN,lwbiMJFadqnYLoEtkOfTHCrQVusIUx,lwbiMJFadqnYLoEtkOfTHCrQVusIUc)=lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_settings_totalsearch()
  for lwbiMJFadqnYLoEtkOfTHCrQVusIUe in lwbiMJFadqnYLoEtkOfTHCrQVusINx:
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD=lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('title')
   lwbiMJFadqnYLoEtkOfTHCrQVusIUS=''
   if lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('mode')=='LOCAL_SEARCH' and lwbiMJFadqnYLoEtkOfTHCrQVusINz ==lwbiMJFadqnYLoEtkOfTHCrQVusIPD:continue
   elif lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('mode')=='SEARCH_HISTORY' and lwbiMJFadqnYLoEtkOfTHCrQVusINK==lwbiMJFadqnYLoEtkOfTHCrQVusIPD:continue
   elif lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('mode')=='TOTAL_SEARCH' and lwbiMJFadqnYLoEtkOfTHCrQVusIUN ==lwbiMJFadqnYLoEtkOfTHCrQVusIPD:continue
   elif lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('mode')=='TOTAL_HISTORY' and lwbiMJFadqnYLoEtkOfTHCrQVusIUx==lwbiMJFadqnYLoEtkOfTHCrQVusIPD:continue
   elif lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('mode')=='MENU_BOOKMARK' and lwbiMJFadqnYLoEtkOfTHCrQVusIUc==lwbiMJFadqnYLoEtkOfTHCrQVusIPD:continue
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('mode'),'stype':lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('stype'),'api_path':lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('api_path'),'page':'1','sort':lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('sort'),'tag_id':'-'}
   if lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('mode')=='LOCAL_SEARCH':lwbiMJFadqnYLoEtkOfTHCrQVusIUy['historyyn']='Y' 
   if lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    lwbiMJFadqnYLoEtkOfTHCrQVusIUX=lwbiMJFadqnYLoEtkOfTHCrQVusIPD
    lwbiMJFadqnYLoEtkOfTHCrQVusIUh =lwbiMJFadqnYLoEtkOfTHCrQVusIPA
   else:
    lwbiMJFadqnYLoEtkOfTHCrQVusIUX=lwbiMJFadqnYLoEtkOfTHCrQVusIPA
    lwbiMJFadqnYLoEtkOfTHCrQVusIUh =lwbiMJFadqnYLoEtkOfTHCrQVusIPD
   if 'icon' in lwbiMJFadqnYLoEtkOfTHCrQVusIUe:lwbiMJFadqnYLoEtkOfTHCrQVusIUS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',lwbiMJFadqnYLoEtkOfTHCrQVusIUe.get('icon')) 
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel='',img=lwbiMJFadqnYLoEtkOfTHCrQVusIUS,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusIPG,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIUX,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy,isLink=lwbiMJFadqnYLoEtkOfTHCrQVusIUh)
  xbmcplugin.endOfDirectory(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle)
 def login_main(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  (lwbiMJFadqnYLoEtkOfTHCrQVusIUg,lwbiMJFadqnYLoEtkOfTHCrQVusIUB,lwbiMJFadqnYLoEtkOfTHCrQVusIUz)=lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_settings_login_info()
  if not(lwbiMJFadqnYLoEtkOfTHCrQVusIUg and lwbiMJFadqnYLoEtkOfTHCrQVusIUB):
   lwbiMJFadqnYLoEtkOfTHCrQVusINS=xbmcgui.Dialog()
   lwbiMJFadqnYLoEtkOfTHCrQVusIUK=lwbiMJFadqnYLoEtkOfTHCrQVusINS.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if lwbiMJFadqnYLoEtkOfTHCrQVusIUK==lwbiMJFadqnYLoEtkOfTHCrQVusIPA:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_winEpisodeOrderby()=='':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.set_winEpisodeOrderby('asc')
  if lwbiMJFadqnYLoEtkOfTHCrQVusINW.cookiefile_check():return
  lwbiMJFadqnYLoEtkOfTHCrQVusIxN =lwbiMJFadqnYLoEtkOfTHCrQVusIPW(lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  lwbiMJFadqnYLoEtkOfTHCrQVusIxU=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if lwbiMJFadqnYLoEtkOfTHCrQVusIxU==lwbiMJFadqnYLoEtkOfTHCrQVusIPG or lwbiMJFadqnYLoEtkOfTHCrQVusIxU=='':
   lwbiMJFadqnYLoEtkOfTHCrQVusIxU=lwbiMJFadqnYLoEtkOfTHCrQVusIPW('19000101')
  else:
   lwbiMJFadqnYLoEtkOfTHCrQVusIxU=lwbiMJFadqnYLoEtkOfTHCrQVusIPW(re.sub('-','',lwbiMJFadqnYLoEtkOfTHCrQVusIxU))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   lwbiMJFadqnYLoEtkOfTHCrQVusIxc=0
   while lwbiMJFadqnYLoEtkOfTHCrQVusIPA:
    lwbiMJFadqnYLoEtkOfTHCrQVusIxc+=1
    time.sleep(0.05)
    if lwbiMJFadqnYLoEtkOfTHCrQVusIxU>=lwbiMJFadqnYLoEtkOfTHCrQVusIxN:return
    if lwbiMJFadqnYLoEtkOfTHCrQVusIxc>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if lwbiMJFadqnYLoEtkOfTHCrQVusIxU>=lwbiMJFadqnYLoEtkOfTHCrQVusIxN:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.GetCredential(lwbiMJFadqnYLoEtkOfTHCrQVusIUg,lwbiMJFadqnYLoEtkOfTHCrQVusIUB,lwbiMJFadqnYLoEtkOfTHCrQVusIUz):
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.set_winCredential(lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.LoadCredential())
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.SaveCredential(lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_winCredential())
  lwbiMJFadqnYLoEtkOfTHCrQVusIxm =args.get('stype')
  lwbiMJFadqnYLoEtkOfTHCrQVusIxj =lwbiMJFadqnYLoEtkOfTHCrQVusIPW(args.get('page'))
  lwbiMJFadqnYLoEtkOfTHCrQVusIxP =args.get('sort')
  lwbiMJFadqnYLoEtkOfTHCrQVusIxp=lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.GetSubGroupList(lwbiMJFadqnYLoEtkOfTHCrQVusIxm)
  lwbiMJFadqnYLoEtkOfTHCrQVusIxG=lwbiMJFadqnYLoEtkOfTHCrQVusINm if lwbiMJFadqnYLoEtkOfTHCrQVusIxm=='genres' else lwbiMJFadqnYLoEtkOfTHCrQVusINj
  lwbiMJFadqnYLoEtkOfTHCrQVusIxW=lwbiMJFadqnYLoEtkOfTHCrQVusIPS(lwbiMJFadqnYLoEtkOfTHCrQVusIxp)
  lwbiMJFadqnYLoEtkOfTHCrQVusIxA =lwbiMJFadqnYLoEtkOfTHCrQVusIPW(lwbiMJFadqnYLoEtkOfTHCrQVusIxW//(lwbiMJFadqnYLoEtkOfTHCrQVusIxG+1))+1
  lwbiMJFadqnYLoEtkOfTHCrQVusIxD =(lwbiMJFadqnYLoEtkOfTHCrQVusIxj-1)*lwbiMJFadqnYLoEtkOfTHCrQVusIxG
  for i in lwbiMJFadqnYLoEtkOfTHCrQVusIPy(lwbiMJFadqnYLoEtkOfTHCrQVusIxG):
   lwbiMJFadqnYLoEtkOfTHCrQVusIxR=lwbiMJFadqnYLoEtkOfTHCrQVusIxD+i
   if lwbiMJFadqnYLoEtkOfTHCrQVusIxR>=lwbiMJFadqnYLoEtkOfTHCrQVusIxW:break
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD =lwbiMJFadqnYLoEtkOfTHCrQVusIxp[lwbiMJFadqnYLoEtkOfTHCrQVusIxR].get('group_name')
   lwbiMJFadqnYLoEtkOfTHCrQVusIxe =lwbiMJFadqnYLoEtkOfTHCrQVusIxp[lwbiMJFadqnYLoEtkOfTHCrQVusIxR].get('api_path')
   lwbiMJFadqnYLoEtkOfTHCrQVusIxS =lwbiMJFadqnYLoEtkOfTHCrQVusIxp[lwbiMJFadqnYLoEtkOfTHCrQVusIxR].get('tag_id')
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':'CATEGORY_LIST','api_path':lwbiMJFadqnYLoEtkOfTHCrQVusIxe,'tag_id':lwbiMJFadqnYLoEtkOfTHCrQVusIxS,'stype':lwbiMJFadqnYLoEtkOfTHCrQVusIxm,'page':'1','sort':lwbiMJFadqnYLoEtkOfTHCrQVusIxP}
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel='',img='',infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusIPG,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPA,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy)
  if lwbiMJFadqnYLoEtkOfTHCrQVusIxA>lwbiMJFadqnYLoEtkOfTHCrQVusIxj:
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy={}
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['mode'] ='SUB_GROUP' 
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['stype'] =lwbiMJFadqnYLoEtkOfTHCrQVusIxm
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['api_path']=args.get('api_path')
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['page'] =lwbiMJFadqnYLoEtkOfTHCrQVusIPX(lwbiMJFadqnYLoEtkOfTHCrQVusIxj+1)
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['sort'] =lwbiMJFadqnYLoEtkOfTHCrQVusIxP
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD='[B]%s >>[/B]'%'다음 페이지'
   lwbiMJFadqnYLoEtkOfTHCrQVusIxy=lwbiMJFadqnYLoEtkOfTHCrQVusIPX(lwbiMJFadqnYLoEtkOfTHCrQVusIxj+1)
   lwbiMJFadqnYLoEtkOfTHCrQVusIUS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel=lwbiMJFadqnYLoEtkOfTHCrQVusIxy,img=lwbiMJFadqnYLoEtkOfTHCrQVusIUS,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusIPG,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPA,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy)
  if lwbiMJFadqnYLoEtkOfTHCrQVusIPS(lwbiMJFadqnYLoEtkOfTHCrQVusIxp)>0:xbmcplugin.endOfDirectory(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,cacheToDisc=lwbiMJFadqnYLoEtkOfTHCrQVusIPA)
 def play_VIDEO(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.SaveCredential(lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_winCredential())
  lwbiMJFadqnYLoEtkOfTHCrQVusIxX =args.get('movie_code')
  lwbiMJFadqnYLoEtkOfTHCrQVusIxh =args.get('season_code')
  lwbiMJFadqnYLoEtkOfTHCrQVusIUD =args.get('title')
  lwbiMJFadqnYLoEtkOfTHCrQVusIxv =args.get('thumbnail')
  lwbiMJFadqnYLoEtkOfTHCrQVusIxg =lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_selQuality()
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.addon_log(lwbiMJFadqnYLoEtkOfTHCrQVusIxX+' - '+lwbiMJFadqnYLoEtkOfTHCrQVusIxh)
  lwbiMJFadqnYLoEtkOfTHCrQVusIxB,lwbiMJFadqnYLoEtkOfTHCrQVusIxz,lwbiMJFadqnYLoEtkOfTHCrQVusIxK=lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.GetStreamingURL(lwbiMJFadqnYLoEtkOfTHCrQVusIxX,lwbiMJFadqnYLoEtkOfTHCrQVusIxg)
  if lwbiMJFadqnYLoEtkOfTHCrQVusIxB=='':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.addon_noti(__language__(30908).encode('utf8'))
   return
  lwbiMJFadqnYLoEtkOfTHCrQVusIcN=lwbiMJFadqnYLoEtkOfTHCrQVusIxB
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.addon_log(lwbiMJFadqnYLoEtkOfTHCrQVusIcN)
  lwbiMJFadqnYLoEtkOfTHCrQVusIcU=xbmcgui.ListItem(path=lwbiMJFadqnYLoEtkOfTHCrQVusIcN)
  if lwbiMJFadqnYLoEtkOfTHCrQVusIxK:
   lwbiMJFadqnYLoEtkOfTHCrQVusIcx=lwbiMJFadqnYLoEtkOfTHCrQVusIxK
   lwbiMJFadqnYLoEtkOfTHCrQVusIcm ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   lwbiMJFadqnYLoEtkOfTHCrQVusIcj ='mpd'
   lwbiMJFadqnYLoEtkOfTHCrQVusIcP ='com.widevine.alpha'
   lwbiMJFadqnYLoEtkOfTHCrQVusIcp =inputstreamhelper.Helper(lwbiMJFadqnYLoEtkOfTHCrQVusIcj,drm=lwbiMJFadqnYLoEtkOfTHCrQVusIcP)
   if lwbiMJFadqnYLoEtkOfTHCrQVusIcp.check_inputstream():
    lwbiMJFadqnYLoEtkOfTHCrQVusIcG={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+lwbiMJFadqnYLoEtkOfTHCrQVusIxX,'dt-custom-data':lwbiMJFadqnYLoEtkOfTHCrQVusIcx,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    lwbiMJFadqnYLoEtkOfTHCrQVusIcW=lwbiMJFadqnYLoEtkOfTHCrQVusIcm+'|'+urllib.parse.urlencode(lwbiMJFadqnYLoEtkOfTHCrQVusIcG)+'|R{SSM}|'
    lwbiMJFadqnYLoEtkOfTHCrQVusINW.addon_log(lwbiMJFadqnYLoEtkOfTHCrQVusIcW)
    lwbiMJFadqnYLoEtkOfTHCrQVusIcU.setProperty('inputstream',lwbiMJFadqnYLoEtkOfTHCrQVusIcp.inputstream_addon)
    lwbiMJFadqnYLoEtkOfTHCrQVusIcU.setProperty('inputstream.adaptive.manifest_type',lwbiMJFadqnYLoEtkOfTHCrQVusIcj)
    lwbiMJFadqnYLoEtkOfTHCrQVusIcU.setProperty('inputstream.adaptive.license_type',lwbiMJFadqnYLoEtkOfTHCrQVusIcP)
    lwbiMJFadqnYLoEtkOfTHCrQVusIcU.setProperty('inputstream.adaptive.license_key',lwbiMJFadqnYLoEtkOfTHCrQVusIcW)
    lwbiMJFadqnYLoEtkOfTHCrQVusIcU.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.USER_AGENT))
  if lwbiMJFadqnYLoEtkOfTHCrQVusIxz:
   try:
    f=lwbiMJFadqnYLoEtkOfTHCrQVusIPh(lwbiMJFadqnYLoEtkOfTHCrQVusINP,'w',-1,'utf-8')
    lwbiMJFadqnYLoEtkOfTHCrQVusIcA=requests.get(lwbiMJFadqnYLoEtkOfTHCrQVusIxz)
    lwbiMJFadqnYLoEtkOfTHCrQVusIcD=lwbiMJFadqnYLoEtkOfTHCrQVusIcA.content.decode('utf-8') 
    for lwbiMJFadqnYLoEtkOfTHCrQVusIcR in lwbiMJFadqnYLoEtkOfTHCrQVusIcD.splitlines():
     lwbiMJFadqnYLoEtkOfTHCrQVusIce=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',lwbiMJFadqnYLoEtkOfTHCrQVusIcR)
     f.write(lwbiMJFadqnYLoEtkOfTHCrQVusIce+'\n')
    f.close()
    lwbiMJFadqnYLoEtkOfTHCrQVusIcU.setSubtitles([lwbiMJFadqnYLoEtkOfTHCrQVusINP,lwbiMJFadqnYLoEtkOfTHCrQVusIxz])
   except:
    lwbiMJFadqnYLoEtkOfTHCrQVusIcU.setSubtitles([lwbiMJFadqnYLoEtkOfTHCrQVusIxz])
  xbmcplugin.setResolvedUrl(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,lwbiMJFadqnYLoEtkOfTHCrQVusIPA,lwbiMJFadqnYLoEtkOfTHCrQVusIcU)
  try:
   lwbiMJFadqnYLoEtkOfTHCrQVusIxm='movie' if lwbiMJFadqnYLoEtkOfTHCrQVusIxh=='-' else 'seasons'
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'code':lwbiMJFadqnYLoEtkOfTHCrQVusIxX if lwbiMJFadqnYLoEtkOfTHCrQVusIxm=='movie' else lwbiMJFadqnYLoEtkOfTHCrQVusIxh,'img':lwbiMJFadqnYLoEtkOfTHCrQVusIxv,'title':lwbiMJFadqnYLoEtkOfTHCrQVusIUD,'videoid':lwbiMJFadqnYLoEtkOfTHCrQVusIxX}
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.Save_Watched_List(lwbiMJFadqnYLoEtkOfTHCrQVusIxm,lwbiMJFadqnYLoEtkOfTHCrQVusIUy)
  except:
   lwbiMJFadqnYLoEtkOfTHCrQVusIPG
 def dp_Category_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.SaveCredential(lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_winCredential())
  lwbiMJFadqnYLoEtkOfTHCrQVusIxm =args.get('stype')
  lwbiMJFadqnYLoEtkOfTHCrQVusIxS =args.get('tag_id')
  lwbiMJFadqnYLoEtkOfTHCrQVusIxe=args.get('api_path')
  lwbiMJFadqnYLoEtkOfTHCrQVusIxj=lwbiMJFadqnYLoEtkOfTHCrQVusIPW(args.get('page'))
  lwbiMJFadqnYLoEtkOfTHCrQVusIxP =args.get('sort')
  lwbiMJFadqnYLoEtkOfTHCrQVusIcS,lwbiMJFadqnYLoEtkOfTHCrQVusIcy=lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.GetCategoryList(lwbiMJFadqnYLoEtkOfTHCrQVusIxm,lwbiMJFadqnYLoEtkOfTHCrQVusIxS,lwbiMJFadqnYLoEtkOfTHCrQVusIxe,lwbiMJFadqnYLoEtkOfTHCrQVusIxj,lwbiMJFadqnYLoEtkOfTHCrQVusIxP)
  for lwbiMJFadqnYLoEtkOfTHCrQVusIcX in lwbiMJFadqnYLoEtkOfTHCrQVusIcS:
   lwbiMJFadqnYLoEtkOfTHCrQVusIxX =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('code')
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('title')
   lwbiMJFadqnYLoEtkOfTHCrQVusIch =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('content_type')
   lwbiMJFadqnYLoEtkOfTHCrQVusIcv =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('story')
   lwbiMJFadqnYLoEtkOfTHCrQVusIxv =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('thumbnail')
   lwbiMJFadqnYLoEtkOfTHCrQVusIcg =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('year')
   lwbiMJFadqnYLoEtkOfTHCrQVusIcB =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('film_rating_code')
   lwbiMJFadqnYLoEtkOfTHCrQVusIcz=lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('film_rating_short')
   lwbiMJFadqnYLoEtkOfTHCrQVusIcK =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('film_rating_long')
   lwbiMJFadqnYLoEtkOfTHCrQVusImN =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('duration')
   if lwbiMJFadqnYLoEtkOfTHCrQVusIch=='movies': 
    lwbiMJFadqnYLoEtkOfTHCrQVusIUX =lwbiMJFadqnYLoEtkOfTHCrQVusIPD
    lwbiMJFadqnYLoEtkOfTHCrQVusImU ='MOVIE'
    lwbiMJFadqnYLoEtkOfTHCrQVusIUv =''
    lwbiMJFadqnYLoEtkOfTHCrQVusIxh='-'
    lwbiMJFadqnYLoEtkOfTHCrQVusImx ='movie'
   else: 
    lwbiMJFadqnYLoEtkOfTHCrQVusIUX =lwbiMJFadqnYLoEtkOfTHCrQVusIPA
    lwbiMJFadqnYLoEtkOfTHCrQVusImU ='EPISODE'
    lwbiMJFadqnYLoEtkOfTHCrQVusIUv ='' 
    lwbiMJFadqnYLoEtkOfTHCrQVusIxh=lwbiMJFadqnYLoEtkOfTHCrQVusIxX
    lwbiMJFadqnYLoEtkOfTHCrQVusImx ='tvshow' 
   lwbiMJFadqnYLoEtkOfTHCrQVusImc={'mediatype':lwbiMJFadqnYLoEtkOfTHCrQVusImx,'mpaa':lwbiMJFadqnYLoEtkOfTHCrQVusIcK,'title':lwbiMJFadqnYLoEtkOfTHCrQVusIUD,'year':lwbiMJFadqnYLoEtkOfTHCrQVusIcg,'duration':lwbiMJFadqnYLoEtkOfTHCrQVusImN,'plot':lwbiMJFadqnYLoEtkOfTHCrQVusIcv}
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD+='  (%s년 - %s)'%(lwbiMJFadqnYLoEtkOfTHCrQVusIcg,lwbiMJFadqnYLoEtkOfTHCrQVusIPX(lwbiMJFadqnYLoEtkOfTHCrQVusIcz))
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':lwbiMJFadqnYLoEtkOfTHCrQVusImU,'movie_code':lwbiMJFadqnYLoEtkOfTHCrQVusIxX,'page':'1','season_code':lwbiMJFadqnYLoEtkOfTHCrQVusIxh,'title':lwbiMJFadqnYLoEtkOfTHCrQVusIUD,'thumbnail':lwbiMJFadqnYLoEtkOfTHCrQVusIxv}
   if lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_settings_makebookmark():
    lwbiMJFadqnYLoEtkOfTHCrQVusImj={'videoid':lwbiMJFadqnYLoEtkOfTHCrQVusIxX,'vidtype':'tvshow' if lwbiMJFadqnYLoEtkOfTHCrQVusIch=='tv_seasons' else 'movie','vtitle':lwbiMJFadqnYLoEtkOfTHCrQVusIUD,'vsubtitle':'',}
    lwbiMJFadqnYLoEtkOfTHCrQVusImP=json.dumps(lwbiMJFadqnYLoEtkOfTHCrQVusImj)
    lwbiMJFadqnYLoEtkOfTHCrQVusImP=urllib.parse.quote(lwbiMJFadqnYLoEtkOfTHCrQVusImP)
    lwbiMJFadqnYLoEtkOfTHCrQVusImp='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(lwbiMJFadqnYLoEtkOfTHCrQVusImP)
    lwbiMJFadqnYLoEtkOfTHCrQVusImG=[('찜한 영상에 추가 (통합 bookmark mini)',lwbiMJFadqnYLoEtkOfTHCrQVusImp)]
   else:
    lwbiMJFadqnYLoEtkOfTHCrQVusImG=lwbiMJFadqnYLoEtkOfTHCrQVusIPG
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel=lwbiMJFadqnYLoEtkOfTHCrQVusIUv,img=lwbiMJFadqnYLoEtkOfTHCrQVusIxv,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusImc,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIUX,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy,ContextMenu=lwbiMJFadqnYLoEtkOfTHCrQVusImG)
  if lwbiMJFadqnYLoEtkOfTHCrQVusIcy:
   if lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.GetCategoryList_morepage(lwbiMJFadqnYLoEtkOfTHCrQVusIxm,lwbiMJFadqnYLoEtkOfTHCrQVusIxS,lwbiMJFadqnYLoEtkOfTHCrQVusIxe,lwbiMJFadqnYLoEtkOfTHCrQVusIxj+1,lwbiMJFadqnYLoEtkOfTHCrQVusIxP):
    lwbiMJFadqnYLoEtkOfTHCrQVusIUy={}
    lwbiMJFadqnYLoEtkOfTHCrQVusIUy['mode'] ='CATEGORY_LIST'
    lwbiMJFadqnYLoEtkOfTHCrQVusIUy['stype'] =lwbiMJFadqnYLoEtkOfTHCrQVusIxm
    lwbiMJFadqnYLoEtkOfTHCrQVusIUy['tag_id'] =lwbiMJFadqnYLoEtkOfTHCrQVusIxS
    lwbiMJFadqnYLoEtkOfTHCrQVusIUy['api_path']=lwbiMJFadqnYLoEtkOfTHCrQVusIxe
    lwbiMJFadqnYLoEtkOfTHCrQVusIUy['page'] =lwbiMJFadqnYLoEtkOfTHCrQVusIPX(lwbiMJFadqnYLoEtkOfTHCrQVusIxj+1)
    lwbiMJFadqnYLoEtkOfTHCrQVusIUy['sort'] =lwbiMJFadqnYLoEtkOfTHCrQVusIxP
    lwbiMJFadqnYLoEtkOfTHCrQVusIUD='[B]%s >>[/B]'%'다음 페이지'
    lwbiMJFadqnYLoEtkOfTHCrQVusIxy=lwbiMJFadqnYLoEtkOfTHCrQVusIPX(lwbiMJFadqnYLoEtkOfTHCrQVusIxj+1)
    lwbiMJFadqnYLoEtkOfTHCrQVusIUS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
    lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel=lwbiMJFadqnYLoEtkOfTHCrQVusIxy,img=lwbiMJFadqnYLoEtkOfTHCrQVusIUS,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusIPG,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPA,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy)
  xbmcplugin.setContent(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,'movies')
  if lwbiMJFadqnYLoEtkOfTHCrQVusIPS(lwbiMJFadqnYLoEtkOfTHCrQVusIcS)>0:
   if lwbiMJFadqnYLoEtkOfTHCrQVusIxe=='arrivals/latest':
    xbmcplugin.endOfDirectory(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,cacheToDisc=lwbiMJFadqnYLoEtkOfTHCrQVusIPA)
   else:
    xbmcplugin.endOfDirectory(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,cacheToDisc=lwbiMJFadqnYLoEtkOfTHCrQVusIPD)
 def dp_Episode_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.SaveCredential(lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_winCredential())
  lwbiMJFadqnYLoEtkOfTHCrQVusImA=args.get('movie_code')
  lwbiMJFadqnYLoEtkOfTHCrQVusIxj =lwbiMJFadqnYLoEtkOfTHCrQVusIPW(args.get('page'))
  lwbiMJFadqnYLoEtkOfTHCrQVusIxh =args.get('season_code')
  lwbiMJFadqnYLoEtkOfTHCrQVusIcS,lwbiMJFadqnYLoEtkOfTHCrQVusIcy=lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.GetEpisodoList(lwbiMJFadqnYLoEtkOfTHCrQVusImA,lwbiMJFadqnYLoEtkOfTHCrQVusIxj,orderby=lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_winEpisodeOrderby())
  for lwbiMJFadqnYLoEtkOfTHCrQVusIcX in lwbiMJFadqnYLoEtkOfTHCrQVusIcS:
   lwbiMJFadqnYLoEtkOfTHCrQVusIxX =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('code')
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('title')
   lwbiMJFadqnYLoEtkOfTHCrQVusIxv =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('thumbnail')
   lwbiMJFadqnYLoEtkOfTHCrQVusImD =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('display_num')
   lwbiMJFadqnYLoEtkOfTHCrQVusImR =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('season_title')
   lwbiMJFadqnYLoEtkOfTHCrQVusIme=lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('episode_number')
   lwbiMJFadqnYLoEtkOfTHCrQVusImN =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('duration')
   lwbiMJFadqnYLoEtkOfTHCrQVusImc={'mediatype':'episode','tvshowtitle':lwbiMJFadqnYLoEtkOfTHCrQVusIUD if lwbiMJFadqnYLoEtkOfTHCrQVusIUD!='' else lwbiMJFadqnYLoEtkOfTHCrQVusImR,'title':'%s %s'%(lwbiMJFadqnYLoEtkOfTHCrQVusImR,lwbiMJFadqnYLoEtkOfTHCrQVusImD)if lwbiMJFadqnYLoEtkOfTHCrQVusIUD!='' else lwbiMJFadqnYLoEtkOfTHCrQVusImD,'episode':lwbiMJFadqnYLoEtkOfTHCrQVusIme,'duration':lwbiMJFadqnYLoEtkOfTHCrQVusImN,'plot':'%s\n%s\n\n%s'%(lwbiMJFadqnYLoEtkOfTHCrQVusImR,lwbiMJFadqnYLoEtkOfTHCrQVusImD,lwbiMJFadqnYLoEtkOfTHCrQVusIUD)}
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD='(%s) %s'%(lwbiMJFadqnYLoEtkOfTHCrQVusImD,lwbiMJFadqnYLoEtkOfTHCrQVusIUD)
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':'MOVIE','movie_code':lwbiMJFadqnYLoEtkOfTHCrQVusIxX,'season_code':lwbiMJFadqnYLoEtkOfTHCrQVusIxh,'title':'%s < %s >'%(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,lwbiMJFadqnYLoEtkOfTHCrQVusImR),'thumbnail':lwbiMJFadqnYLoEtkOfTHCrQVusIxv}
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel=lwbiMJFadqnYLoEtkOfTHCrQVusImR,img=lwbiMJFadqnYLoEtkOfTHCrQVusIxv,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusImc,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPD,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy)
  if lwbiMJFadqnYLoEtkOfTHCrQVusIxj==1:
   lwbiMJFadqnYLoEtkOfTHCrQVusImc={'plot':'정렬순서를 변경합니다.'}
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy={}
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['mode'] ='ORDER_BY' 
   if lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_winEpisodeOrderby()=='desc':
    lwbiMJFadqnYLoEtkOfTHCrQVusIUD='정렬순서변경 : 최신화부터 -> 1회부터'
    lwbiMJFadqnYLoEtkOfTHCrQVusIUy['orderby']='asc'
   else:
    lwbiMJFadqnYLoEtkOfTHCrQVusIUD='정렬순서변경 : 1회부터 -> 최신화부터'
    lwbiMJFadqnYLoEtkOfTHCrQVusIUy['orderby']='desc'
   lwbiMJFadqnYLoEtkOfTHCrQVusIUS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel='',img=lwbiMJFadqnYLoEtkOfTHCrQVusIUS,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusImc,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPD,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy,isLink=lwbiMJFadqnYLoEtkOfTHCrQVusIPA)
  if lwbiMJFadqnYLoEtkOfTHCrQVusIcy:
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['mode'] ='EPISODE' 
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['movie_code']=lwbiMJFadqnYLoEtkOfTHCrQVusImA
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['page'] =lwbiMJFadqnYLoEtkOfTHCrQVusIPX(lwbiMJFadqnYLoEtkOfTHCrQVusIxj+1)
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD='[B]%s >>[/B]'%'다음 페이지'
   lwbiMJFadqnYLoEtkOfTHCrQVusIxy=lwbiMJFadqnYLoEtkOfTHCrQVusIPX(lwbiMJFadqnYLoEtkOfTHCrQVusIxj+1)
   lwbiMJFadqnYLoEtkOfTHCrQVusIUS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel=lwbiMJFadqnYLoEtkOfTHCrQVusIxy,img=lwbiMJFadqnYLoEtkOfTHCrQVusIUS,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusIPG,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPA,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy)
  xbmcplugin.setContent(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,'episodes')
  if lwbiMJFadqnYLoEtkOfTHCrQVusIPS(lwbiMJFadqnYLoEtkOfTHCrQVusIcS)>0:xbmcplugin.endOfDirectory(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,cacheToDisc=lwbiMJFadqnYLoEtkOfTHCrQVusIPA)
 def dp_Search_History(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusImS=lwbiMJFadqnYLoEtkOfTHCrQVusINW.Load_List_File('search')
  for lwbiMJFadqnYLoEtkOfTHCrQVusImy in lwbiMJFadqnYLoEtkOfTHCrQVusImS:
   lwbiMJFadqnYLoEtkOfTHCrQVusImX=lwbiMJFadqnYLoEtkOfTHCrQVusIPe(urllib.parse.parse_qsl(lwbiMJFadqnYLoEtkOfTHCrQVusImy))
   lwbiMJFadqnYLoEtkOfTHCrQVusImh=lwbiMJFadqnYLoEtkOfTHCrQVusImX.get('skey').strip()
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':'LOCAL_SEARCH','search_key':lwbiMJFadqnYLoEtkOfTHCrQVusImh,'page':'1','historyyn':'Y',}
   lwbiMJFadqnYLoEtkOfTHCrQVusImv={'mode':'SEARCH_REMOVE','stype':'ONE','skey':lwbiMJFadqnYLoEtkOfTHCrQVusImh,}
   lwbiMJFadqnYLoEtkOfTHCrQVusImg=urllib.parse.urlencode(lwbiMJFadqnYLoEtkOfTHCrQVusImv)
   lwbiMJFadqnYLoEtkOfTHCrQVusImG=[('선택된 검색어 ( %s ) 삭제'%(lwbiMJFadqnYLoEtkOfTHCrQVusImh),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(lwbiMJFadqnYLoEtkOfTHCrQVusImg))]
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusImh,sublabel='',img=lwbiMJFadqnYLoEtkOfTHCrQVusIPG,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusIPG,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPA,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy,ContextMenu=lwbiMJFadqnYLoEtkOfTHCrQVusImG)
  lwbiMJFadqnYLoEtkOfTHCrQVusImc={'plot':'검색목록 전체를 삭제합니다.'}
  lwbiMJFadqnYLoEtkOfTHCrQVusIUD='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  lwbiMJFadqnYLoEtkOfTHCrQVusIUS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel='',img=lwbiMJFadqnYLoEtkOfTHCrQVusIUS,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusImc,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPD,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy,isLink=lwbiMJFadqnYLoEtkOfTHCrQVusIPA)
  xbmcplugin.endOfDirectory(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,cacheToDisc=lwbiMJFadqnYLoEtkOfTHCrQVusIPD)
 def dp_Search_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.SaveCredential(lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_winCredential())
  lwbiMJFadqnYLoEtkOfTHCrQVusIxj =lwbiMJFadqnYLoEtkOfTHCrQVusIPW(args.get('page'))
  if 'search_key' in args:
   lwbiMJFadqnYLoEtkOfTHCrQVusImB=args.get('search_key')
  else:
   lwbiMJFadqnYLoEtkOfTHCrQVusImB=lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not lwbiMJFadqnYLoEtkOfTHCrQVusImB:
    xbmcplugin.endOfDirectory(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle)
    return
  lwbiMJFadqnYLoEtkOfTHCrQVusIcS,lwbiMJFadqnYLoEtkOfTHCrQVusIcy=lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.GetSearchList(lwbiMJFadqnYLoEtkOfTHCrQVusImB,lwbiMJFadqnYLoEtkOfTHCrQVusIxj)
  for lwbiMJFadqnYLoEtkOfTHCrQVusIcX in lwbiMJFadqnYLoEtkOfTHCrQVusIcS:
   lwbiMJFadqnYLoEtkOfTHCrQVusIxX =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('code')
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('title')
   lwbiMJFadqnYLoEtkOfTHCrQVusIch=lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('content_type')
   lwbiMJFadqnYLoEtkOfTHCrQVusIcv =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('story')
   lwbiMJFadqnYLoEtkOfTHCrQVusIxv =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('thumbnail')
   lwbiMJFadqnYLoEtkOfTHCrQVusIcg =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('year')
   lwbiMJFadqnYLoEtkOfTHCrQVusIcB =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('film_rating_code')
   lwbiMJFadqnYLoEtkOfTHCrQVusIcz=lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('film_rating_short')
   lwbiMJFadqnYLoEtkOfTHCrQVusIcK =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('film_rating_long')
   lwbiMJFadqnYLoEtkOfTHCrQVusImN =lwbiMJFadqnYLoEtkOfTHCrQVusIcX.get('duration')
   if lwbiMJFadqnYLoEtkOfTHCrQVusIch=='movies': 
    lwbiMJFadqnYLoEtkOfTHCrQVusIUX =lwbiMJFadqnYLoEtkOfTHCrQVusIPD
    lwbiMJFadqnYLoEtkOfTHCrQVusImU ='MOVIE'
    lwbiMJFadqnYLoEtkOfTHCrQVusIUv =''
    lwbiMJFadqnYLoEtkOfTHCrQVusIxh='-'
    lwbiMJFadqnYLoEtkOfTHCrQVusImx ='movie'
   else: 
    lwbiMJFadqnYLoEtkOfTHCrQVusIUX =lwbiMJFadqnYLoEtkOfTHCrQVusIPA
    lwbiMJFadqnYLoEtkOfTHCrQVusImU ='EPISODE'
    lwbiMJFadqnYLoEtkOfTHCrQVusIUv ='' 
    lwbiMJFadqnYLoEtkOfTHCrQVusIxh=lwbiMJFadqnYLoEtkOfTHCrQVusIxX
    lwbiMJFadqnYLoEtkOfTHCrQVusImx ='tvshow' 
   lwbiMJFadqnYLoEtkOfTHCrQVusImc={'mediatype':lwbiMJFadqnYLoEtkOfTHCrQVusImx,'mpaa':lwbiMJFadqnYLoEtkOfTHCrQVusIcK,'title':lwbiMJFadqnYLoEtkOfTHCrQVusIUD,'year':lwbiMJFadqnYLoEtkOfTHCrQVusIcg,'duration':lwbiMJFadqnYLoEtkOfTHCrQVusImN,'plot':lwbiMJFadqnYLoEtkOfTHCrQVusIcv}
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD+='  (%s년 - %s)'%(lwbiMJFadqnYLoEtkOfTHCrQVusIcg,lwbiMJFadqnYLoEtkOfTHCrQVusIPX(lwbiMJFadqnYLoEtkOfTHCrQVusIcz))
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':lwbiMJFadqnYLoEtkOfTHCrQVusImU,'movie_code':lwbiMJFadqnYLoEtkOfTHCrQVusIxX,'page':'1','season_code':lwbiMJFadqnYLoEtkOfTHCrQVusIxh,'title':lwbiMJFadqnYLoEtkOfTHCrQVusIUD,'thumbnail':lwbiMJFadqnYLoEtkOfTHCrQVusIxv}
   if lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_settings_makebookmark():
    lwbiMJFadqnYLoEtkOfTHCrQVusImj={'videoid':lwbiMJFadqnYLoEtkOfTHCrQVusIxX,'vidtype':'tvshow' if lwbiMJFadqnYLoEtkOfTHCrQVusIch=='tv_seasons' else 'movie','vtitle':lwbiMJFadqnYLoEtkOfTHCrQVusIUD,'vsubtitle':'',}
    lwbiMJFadqnYLoEtkOfTHCrQVusImP=json.dumps(lwbiMJFadqnYLoEtkOfTHCrQVusImj)
    lwbiMJFadqnYLoEtkOfTHCrQVusImP=urllib.parse.quote(lwbiMJFadqnYLoEtkOfTHCrQVusImP)
    lwbiMJFadqnYLoEtkOfTHCrQVusImp='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(lwbiMJFadqnYLoEtkOfTHCrQVusImP)
    lwbiMJFadqnYLoEtkOfTHCrQVusImG=[('찜한 영상에 추가 (통합 bookmark mini)',lwbiMJFadqnYLoEtkOfTHCrQVusImp)]
   else:
    lwbiMJFadqnYLoEtkOfTHCrQVusImG=lwbiMJFadqnYLoEtkOfTHCrQVusIPG
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel=lwbiMJFadqnYLoEtkOfTHCrQVusIUv,img=lwbiMJFadqnYLoEtkOfTHCrQVusIxv,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusImc,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIUX,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy,ContextMenu=lwbiMJFadqnYLoEtkOfTHCrQVusImG)
  if lwbiMJFadqnYLoEtkOfTHCrQVusIcy:
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy={}
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['mode'] ='SEARCH'
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['search_key']=lwbiMJFadqnYLoEtkOfTHCrQVusImB
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy['page'] =lwbiMJFadqnYLoEtkOfTHCrQVusIPX(lwbiMJFadqnYLoEtkOfTHCrQVusIxj+1)
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD='[B]%s >>[/B]'%'다음 페이지'
   lwbiMJFadqnYLoEtkOfTHCrQVusIxy=lwbiMJFadqnYLoEtkOfTHCrQVusIPX(lwbiMJFadqnYLoEtkOfTHCrQVusIxj+1)
   lwbiMJFadqnYLoEtkOfTHCrQVusIUS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel=lwbiMJFadqnYLoEtkOfTHCrQVusIxy,img=lwbiMJFadqnYLoEtkOfTHCrQVusIUS,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusIPG,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPA,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy)
  xbmcplugin.setContent(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,'movies')
  xbmcplugin.endOfDirectory(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,cacheToDisc=lwbiMJFadqnYLoEtkOfTHCrQVusIPD)
  if args.get('historyyn')=='Y':lwbiMJFadqnYLoEtkOfTHCrQVusINW.Save_Searched_List(lwbiMJFadqnYLoEtkOfTHCrQVusImB)
 def Delete_List_File(lwbiMJFadqnYLoEtkOfTHCrQVusINW,lwbiMJFadqnYLoEtkOfTHCrQVusIxm,skey='-'):
  if lwbiMJFadqnYLoEtkOfTHCrQVusIxm=='ALL':
   try:
    lwbiMJFadqnYLoEtkOfTHCrQVusImz=lwbiMJFadqnYLoEtkOfTHCrQVusING
    fp=lwbiMJFadqnYLoEtkOfTHCrQVusIPh(lwbiMJFadqnYLoEtkOfTHCrQVusImz,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    lwbiMJFadqnYLoEtkOfTHCrQVusIPG
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIxm=='ONE':
   try:
    lwbiMJFadqnYLoEtkOfTHCrQVusImz=lwbiMJFadqnYLoEtkOfTHCrQVusING
    lwbiMJFadqnYLoEtkOfTHCrQVusImK=lwbiMJFadqnYLoEtkOfTHCrQVusINW.Load_List_File('search') 
    fp=lwbiMJFadqnYLoEtkOfTHCrQVusIPh(lwbiMJFadqnYLoEtkOfTHCrQVusImz,'w',-1,'utf-8')
    for lwbiMJFadqnYLoEtkOfTHCrQVusIjN in lwbiMJFadqnYLoEtkOfTHCrQVusImK:
     lwbiMJFadqnYLoEtkOfTHCrQVusIjU=lwbiMJFadqnYLoEtkOfTHCrQVusIPe(urllib.parse.parse_qsl(lwbiMJFadqnYLoEtkOfTHCrQVusIjN))
     lwbiMJFadqnYLoEtkOfTHCrQVusIjx=lwbiMJFadqnYLoEtkOfTHCrQVusIjU.get('skey').strip()
     if skey!=lwbiMJFadqnYLoEtkOfTHCrQVusIjx:
      fp.write(lwbiMJFadqnYLoEtkOfTHCrQVusIjN)
    fp.close()
   except:
    lwbiMJFadqnYLoEtkOfTHCrQVusIPG
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIxm in['seasons','movie']:
   try:
    lwbiMJFadqnYLoEtkOfTHCrQVusImz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lwbiMJFadqnYLoEtkOfTHCrQVusIxm))
    fp=lwbiMJFadqnYLoEtkOfTHCrQVusIPh(lwbiMJFadqnYLoEtkOfTHCrQVusImz,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    lwbiMJFadqnYLoEtkOfTHCrQVusIPG
 def dp_Listfile_Delete(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusIxm=args.get('stype')
  lwbiMJFadqnYLoEtkOfTHCrQVusImh =args.get('skey')
  lwbiMJFadqnYLoEtkOfTHCrQVusINS=xbmcgui.Dialog()
  if lwbiMJFadqnYLoEtkOfTHCrQVusIxm=='ALL':
   lwbiMJFadqnYLoEtkOfTHCrQVusIUK=lwbiMJFadqnYLoEtkOfTHCrQVusINS.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIxm=='ONE':
   lwbiMJFadqnYLoEtkOfTHCrQVusIUK=lwbiMJFadqnYLoEtkOfTHCrQVusINS.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIxm in['seasons','movie']:
   lwbiMJFadqnYLoEtkOfTHCrQVusIUK=lwbiMJFadqnYLoEtkOfTHCrQVusINS.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if lwbiMJFadqnYLoEtkOfTHCrQVusIUK==lwbiMJFadqnYLoEtkOfTHCrQVusIPD:sys.exit()
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.Delete_List_File(lwbiMJFadqnYLoEtkOfTHCrQVusIxm,skey=lwbiMJFadqnYLoEtkOfTHCrQVusImh)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(lwbiMJFadqnYLoEtkOfTHCrQVusINW,lwbiMJFadqnYLoEtkOfTHCrQVusIxm): 
  try:
   if lwbiMJFadqnYLoEtkOfTHCrQVusIxm=='search':
    lwbiMJFadqnYLoEtkOfTHCrQVusImz=lwbiMJFadqnYLoEtkOfTHCrQVusING
   elif lwbiMJFadqnYLoEtkOfTHCrQVusIxm in['seasons','movie']:
    lwbiMJFadqnYLoEtkOfTHCrQVusImz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lwbiMJFadqnYLoEtkOfTHCrQVusIxm))
   else:
    return[]
   fp=lwbiMJFadqnYLoEtkOfTHCrQVusIPh(lwbiMJFadqnYLoEtkOfTHCrQVusImz,'r',-1,'utf-8')
   lwbiMJFadqnYLoEtkOfTHCrQVusIjc=fp.readlines()
   fp.close()
  except:
   lwbiMJFadqnYLoEtkOfTHCrQVusIjc=[]
  return lwbiMJFadqnYLoEtkOfTHCrQVusIjc
 def Save_Watched_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW,lwbiMJFadqnYLoEtkOfTHCrQVusIxm,lwbiMJFadqnYLoEtkOfTHCrQVusINR):
  try:
   lwbiMJFadqnYLoEtkOfTHCrQVusIjm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%lwbiMJFadqnYLoEtkOfTHCrQVusIxm))
   lwbiMJFadqnYLoEtkOfTHCrQVusImK=lwbiMJFadqnYLoEtkOfTHCrQVusINW.Load_List_File(lwbiMJFadqnYLoEtkOfTHCrQVusIxm) 
   fp=lwbiMJFadqnYLoEtkOfTHCrQVusIPh(lwbiMJFadqnYLoEtkOfTHCrQVusIjm,'w',-1,'utf-8')
   lwbiMJFadqnYLoEtkOfTHCrQVusIjP=urllib.parse.urlencode(lwbiMJFadqnYLoEtkOfTHCrQVusINR)
   lwbiMJFadqnYLoEtkOfTHCrQVusIjP=lwbiMJFadqnYLoEtkOfTHCrQVusIjP+'\n'
   fp.write(lwbiMJFadqnYLoEtkOfTHCrQVusIjP)
   lwbiMJFadqnYLoEtkOfTHCrQVusIjp=0
   for lwbiMJFadqnYLoEtkOfTHCrQVusIjN in lwbiMJFadqnYLoEtkOfTHCrQVusImK:
    lwbiMJFadqnYLoEtkOfTHCrQVusIjU=lwbiMJFadqnYLoEtkOfTHCrQVusIPe(urllib.parse.parse_qsl(lwbiMJFadqnYLoEtkOfTHCrQVusIjN))
    lwbiMJFadqnYLoEtkOfTHCrQVusIjG=lwbiMJFadqnYLoEtkOfTHCrQVusINR.get('code').strip()
    lwbiMJFadqnYLoEtkOfTHCrQVusIjW=lwbiMJFadqnYLoEtkOfTHCrQVusIjU.get('code').strip()
    if lwbiMJFadqnYLoEtkOfTHCrQVusIxm=='seasons' and lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_settings_direct_replay()==lwbiMJFadqnYLoEtkOfTHCrQVusIPA:
     lwbiMJFadqnYLoEtkOfTHCrQVusIjG=lwbiMJFadqnYLoEtkOfTHCrQVusINR.get('videoid').strip()
     lwbiMJFadqnYLoEtkOfTHCrQVusIjW=lwbiMJFadqnYLoEtkOfTHCrQVusIjU.get('videoid').strip()if lwbiMJFadqnYLoEtkOfTHCrQVusIjW!=lwbiMJFadqnYLoEtkOfTHCrQVusIPG else '-'
    if lwbiMJFadqnYLoEtkOfTHCrQVusIjG!=lwbiMJFadqnYLoEtkOfTHCrQVusIjW:
     fp.write(lwbiMJFadqnYLoEtkOfTHCrQVusIjN)
     lwbiMJFadqnYLoEtkOfTHCrQVusIjp+=1
     if lwbiMJFadqnYLoEtkOfTHCrQVusIjp>=50:break
   fp.close()
  except:
   lwbiMJFadqnYLoEtkOfTHCrQVusIPG
 def dp_Watch_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusIxm =args.get('stype')
  lwbiMJFadqnYLoEtkOfTHCrQVusIUP=lwbiMJFadqnYLoEtkOfTHCrQVusINW.get_settings_direct_replay()
  if lwbiMJFadqnYLoEtkOfTHCrQVusIxm=='-':
   for lwbiMJFadqnYLoEtkOfTHCrQVusIjA in lwbiMJFadqnYLoEtkOfTHCrQVusINc:
    lwbiMJFadqnYLoEtkOfTHCrQVusIUD=lwbiMJFadqnYLoEtkOfTHCrQVusIjA.get('title')
    lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':lwbiMJFadqnYLoEtkOfTHCrQVusIjA.get('mode'),'stype':lwbiMJFadqnYLoEtkOfTHCrQVusIjA.get('stype')}
    lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel='',img='',infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusIPG,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPA,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy)
   if lwbiMJFadqnYLoEtkOfTHCrQVusIPS(lwbiMJFadqnYLoEtkOfTHCrQVusINc)>0:xbmcplugin.endOfDirectory(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle)
  else:
   lwbiMJFadqnYLoEtkOfTHCrQVusIjD=lwbiMJFadqnYLoEtkOfTHCrQVusINW.Load_List_File(lwbiMJFadqnYLoEtkOfTHCrQVusIxm)
   for lwbiMJFadqnYLoEtkOfTHCrQVusIjR in lwbiMJFadqnYLoEtkOfTHCrQVusIjD:
    lwbiMJFadqnYLoEtkOfTHCrQVusImX=lwbiMJFadqnYLoEtkOfTHCrQVusIPe(urllib.parse.parse_qsl(lwbiMJFadqnYLoEtkOfTHCrQVusIjR))
    lwbiMJFadqnYLoEtkOfTHCrQVusIxX=lwbiMJFadqnYLoEtkOfTHCrQVusImX.get('code').strip()
    lwbiMJFadqnYLoEtkOfTHCrQVusIUD =lwbiMJFadqnYLoEtkOfTHCrQVusImX.get('title').strip()
    lwbiMJFadqnYLoEtkOfTHCrQVusIxv =lwbiMJFadqnYLoEtkOfTHCrQVusImX.get('img').strip()
    lwbiMJFadqnYLoEtkOfTHCrQVusIje =lwbiMJFadqnYLoEtkOfTHCrQVusImX.get('videoid').strip()
    try:
     lwbiMJFadqnYLoEtkOfTHCrQVusIxv=lwbiMJFadqnYLoEtkOfTHCrQVusIxv.replace('\'','\"')
     lwbiMJFadqnYLoEtkOfTHCrQVusIxv=json.loads(lwbiMJFadqnYLoEtkOfTHCrQVusIxv)
    except:
     lwbiMJFadqnYLoEtkOfTHCrQVusIPG
    lwbiMJFadqnYLoEtkOfTHCrQVusImc={}
    lwbiMJFadqnYLoEtkOfTHCrQVusImc['plot']=lwbiMJFadqnYLoEtkOfTHCrQVusIUD
    if lwbiMJFadqnYLoEtkOfTHCrQVusIxm=='movie':
     lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':'MOVIE','page':'1','movie_code':lwbiMJFadqnYLoEtkOfTHCrQVusIxX,'season_code':'-','title':lwbiMJFadqnYLoEtkOfTHCrQVusIUD,'thumbnail':lwbiMJFadqnYLoEtkOfTHCrQVusIxv}
     lwbiMJFadqnYLoEtkOfTHCrQVusIUX=lwbiMJFadqnYLoEtkOfTHCrQVusIPD
    else:
     if lwbiMJFadqnYLoEtkOfTHCrQVusIUP==lwbiMJFadqnYLoEtkOfTHCrQVusIPD or lwbiMJFadqnYLoEtkOfTHCrQVusIje==lwbiMJFadqnYLoEtkOfTHCrQVusIPG:
      lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':'EPISODE','page':'1','movie_code':lwbiMJFadqnYLoEtkOfTHCrQVusIxX,'season_code':lwbiMJFadqnYLoEtkOfTHCrQVusIxX,'title':lwbiMJFadqnYLoEtkOfTHCrQVusIUD,'thumbnail':lwbiMJFadqnYLoEtkOfTHCrQVusIxv}
      lwbiMJFadqnYLoEtkOfTHCrQVusIUX=lwbiMJFadqnYLoEtkOfTHCrQVusIPA
     else:
      lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':'MOVIE','movie_code':lwbiMJFadqnYLoEtkOfTHCrQVusIje,'season_code':lwbiMJFadqnYLoEtkOfTHCrQVusIxX,'title':lwbiMJFadqnYLoEtkOfTHCrQVusIUD,'thumbnail':lwbiMJFadqnYLoEtkOfTHCrQVusIxv}
      lwbiMJFadqnYLoEtkOfTHCrQVusIUX=lwbiMJFadqnYLoEtkOfTHCrQVusIPD
    lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel='',img=lwbiMJFadqnYLoEtkOfTHCrQVusIxv,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusImc,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIUX,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy)
   lwbiMJFadqnYLoEtkOfTHCrQVusImc={'plot':'시청목록을 삭제합니다.'}
   lwbiMJFadqnYLoEtkOfTHCrQVusIUD='*** 시청목록 삭제 ***'
   lwbiMJFadqnYLoEtkOfTHCrQVusIUy={'mode':'MYVIEW_REMOVE','stype':lwbiMJFadqnYLoEtkOfTHCrQVusIxm,'skey':'-',}
   lwbiMJFadqnYLoEtkOfTHCrQVusIUS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.add_dir(lwbiMJFadqnYLoEtkOfTHCrQVusIUD,sublabel='',img=lwbiMJFadqnYLoEtkOfTHCrQVusIUS,infoLabels=lwbiMJFadqnYLoEtkOfTHCrQVusImc,isFolder=lwbiMJFadqnYLoEtkOfTHCrQVusIPD,params=lwbiMJFadqnYLoEtkOfTHCrQVusIUy,isLink=lwbiMJFadqnYLoEtkOfTHCrQVusIPA)
   if lwbiMJFadqnYLoEtkOfTHCrQVusIxm=='movie':xbmcplugin.setContent(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,'movies')
   else:xbmcplugin.setContent(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(lwbiMJFadqnYLoEtkOfTHCrQVusINW._addon_handle,cacheToDisc=lwbiMJFadqnYLoEtkOfTHCrQVusIPD)
 def Save_Searched_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW,lwbiMJFadqnYLoEtkOfTHCrQVusImB):
  try:
   lwbiMJFadqnYLoEtkOfTHCrQVusIjS=lwbiMJFadqnYLoEtkOfTHCrQVusING
   lwbiMJFadqnYLoEtkOfTHCrQVusImK=lwbiMJFadqnYLoEtkOfTHCrQVusINW.Load_List_File('search') 
   lwbiMJFadqnYLoEtkOfTHCrQVusIjy={'skey':lwbiMJFadqnYLoEtkOfTHCrQVusImB.strip()}
   fp=lwbiMJFadqnYLoEtkOfTHCrQVusIPh(lwbiMJFadqnYLoEtkOfTHCrQVusIjS,'w',-1,'utf-8')
   lwbiMJFadqnYLoEtkOfTHCrQVusIjP=urllib.parse.urlencode(lwbiMJFadqnYLoEtkOfTHCrQVusIjy)
   lwbiMJFadqnYLoEtkOfTHCrQVusIjP=lwbiMJFadqnYLoEtkOfTHCrQVusIjP+'\n'
   fp.write(lwbiMJFadqnYLoEtkOfTHCrQVusIjP)
   lwbiMJFadqnYLoEtkOfTHCrQVusIjp=0
   for lwbiMJFadqnYLoEtkOfTHCrQVusIjN in lwbiMJFadqnYLoEtkOfTHCrQVusImK:
    lwbiMJFadqnYLoEtkOfTHCrQVusIjU=lwbiMJFadqnYLoEtkOfTHCrQVusIPe(urllib.parse.parse_qsl(lwbiMJFadqnYLoEtkOfTHCrQVusIjN))
    lwbiMJFadqnYLoEtkOfTHCrQVusIjG=lwbiMJFadqnYLoEtkOfTHCrQVusIjy.get('skey').strip()
    lwbiMJFadqnYLoEtkOfTHCrQVusIjW=lwbiMJFadqnYLoEtkOfTHCrQVusIjU.get('skey').strip()
    if lwbiMJFadqnYLoEtkOfTHCrQVusIjG!=lwbiMJFadqnYLoEtkOfTHCrQVusIjW:
     fp.write(lwbiMJFadqnYLoEtkOfTHCrQVusIjN)
     lwbiMJFadqnYLoEtkOfTHCrQVusIjp+=1
     if lwbiMJFadqnYLoEtkOfTHCrQVusIjp>=50:break
   fp.close()
  except:
   lwbiMJFadqnYLoEtkOfTHCrQVusIPG
 def logout(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  lwbiMJFadqnYLoEtkOfTHCrQVusINS=xbmcgui.Dialog()
  lwbiMJFadqnYLoEtkOfTHCrQVusIUK=lwbiMJFadqnYLoEtkOfTHCrQVusINS.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if lwbiMJFadqnYLoEtkOfTHCrQVusIUK==lwbiMJFadqnYLoEtkOfTHCrQVusIPD:sys.exit()
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.wininfo_clear()
  if os.path.isfile(lwbiMJFadqnYLoEtkOfTHCrQVusINp):os.remove(lwbiMJFadqnYLoEtkOfTHCrQVusINp)
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp=xbmcgui.Window(10000)
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_TOKEN','')
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_GUIT','')
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_GUITV','')
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_USERCD','')
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  lwbiMJFadqnYLoEtkOfTHCrQVusIjX =lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.Get_Now_Datetime()
  lwbiMJFadqnYLoEtkOfTHCrQVusIjh=lwbiMJFadqnYLoEtkOfTHCrQVusIjX+datetime.timedelta(days=lwbiMJFadqnYLoEtkOfTHCrQVusIPW(__addon__.getSetting('cache_ttl')))
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp=xbmcgui.Window(10000)
  lwbiMJFadqnYLoEtkOfTHCrQVusIjv={'watcha_token':lwbiMJFadqnYLoEtkOfTHCrQVusIUp.getProperty('WATCHA_M_TOKEN'),'watcha_guit':lwbiMJFadqnYLoEtkOfTHCrQVusIUp.getProperty('WATCHA_M_GUIT'),'watcha_guitv':lwbiMJFadqnYLoEtkOfTHCrQVusIUp.getProperty('WATCHA_M_GUITV'),'watcha_usercd':lwbiMJFadqnYLoEtkOfTHCrQVusIUp.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':lwbiMJFadqnYLoEtkOfTHCrQVusIjh.strftime('%Y-%m-%d')}
  try: 
   fp=lwbiMJFadqnYLoEtkOfTHCrQVusIPh(lwbiMJFadqnYLoEtkOfTHCrQVusINp,'w',-1,'utf-8')
   json.dump(lwbiMJFadqnYLoEtkOfTHCrQVusIjv,fp)
   fp.close()
  except lwbiMJFadqnYLoEtkOfTHCrQVusIPv as exception:
   lwbiMJFadqnYLoEtkOfTHCrQVusIPg(exception)
 def cookiefile_check(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  lwbiMJFadqnYLoEtkOfTHCrQVusIjv={}
  try: 
   fp=lwbiMJFadqnYLoEtkOfTHCrQVusIPh(lwbiMJFadqnYLoEtkOfTHCrQVusINp,'r',-1,'utf-8')
   lwbiMJFadqnYLoEtkOfTHCrQVusIjv= json.load(fp)
   fp.close()
  except lwbiMJFadqnYLoEtkOfTHCrQVusIPv as exception:
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.wininfo_clear()
   return lwbiMJFadqnYLoEtkOfTHCrQVusIPD
  lwbiMJFadqnYLoEtkOfTHCrQVusIUg =__addon__.getSetting('id')
  lwbiMJFadqnYLoEtkOfTHCrQVusIUB =__addon__.getSetting('pw')
  lwbiMJFadqnYLoEtkOfTHCrQVusIjg =__addon__.getSetting('selected_profile')
  lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_id']=base64.standard_b64decode(lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_id']).decode('utf-8')
  lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_pw']=base64.standard_b64decode(lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_pw']).decode('utf-8')
  if lwbiMJFadqnYLoEtkOfTHCrQVusIUg!=lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_id']or lwbiMJFadqnYLoEtkOfTHCrQVusIUB!=lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_pw']or lwbiMJFadqnYLoEtkOfTHCrQVusIjg!=lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_profile']:
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.wininfo_clear()
   return lwbiMJFadqnYLoEtkOfTHCrQVusIPD
  lwbiMJFadqnYLoEtkOfTHCrQVusIxN =lwbiMJFadqnYLoEtkOfTHCrQVusIPW(lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  lwbiMJFadqnYLoEtkOfTHCrQVusIjB=lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_limitdate']
  lwbiMJFadqnYLoEtkOfTHCrQVusIxU =lwbiMJFadqnYLoEtkOfTHCrQVusIPW(re.sub('-','',lwbiMJFadqnYLoEtkOfTHCrQVusIjB))
  if lwbiMJFadqnYLoEtkOfTHCrQVusIxU<lwbiMJFadqnYLoEtkOfTHCrQVusIxN:
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.wininfo_clear()
   return lwbiMJFadqnYLoEtkOfTHCrQVusIPD
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp=xbmcgui.Window(10000)
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_TOKEN',lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_token'])
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_GUIT',lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_guit'])
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_GUITV',lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_guitv'])
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_USERCD',lwbiMJFadqnYLoEtkOfTHCrQVusIjv['watcha_usercd'])
  lwbiMJFadqnYLoEtkOfTHCrQVusIUp.setProperty('WATCHA_M_LOGINTIME',lwbiMJFadqnYLoEtkOfTHCrQVusIjB)
  return lwbiMJFadqnYLoEtkOfTHCrQVusIPA
 def dp_Global_Search(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusIjz=args.get('mode')
  if lwbiMJFadqnYLoEtkOfTHCrQVusIjz=='TOTAL_SEARCH':
   lwbiMJFadqnYLoEtkOfTHCrQVusIjK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   lwbiMJFadqnYLoEtkOfTHCrQVusIjK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(lwbiMJFadqnYLoEtkOfTHCrQVusIjK)
 def dp_Bookmark_Menu(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusIjK='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(lwbiMJFadqnYLoEtkOfTHCrQVusIjK)
 def dp_Set_Bookmark(lwbiMJFadqnYLoEtkOfTHCrQVusINW,args):
  lwbiMJFadqnYLoEtkOfTHCrQVusIPN=urllib.parse.unquote(args.get('bm_param'))
  lwbiMJFadqnYLoEtkOfTHCrQVusIPN=json.loads(lwbiMJFadqnYLoEtkOfTHCrQVusIPN)
  lwbiMJFadqnYLoEtkOfTHCrQVusIje =lwbiMJFadqnYLoEtkOfTHCrQVusIPN.get('videoid')
  lwbiMJFadqnYLoEtkOfTHCrQVusIPU =lwbiMJFadqnYLoEtkOfTHCrQVusIPN.get('vidtype')
  lwbiMJFadqnYLoEtkOfTHCrQVusIPx =lwbiMJFadqnYLoEtkOfTHCrQVusIPN.get('vtitle')
  lwbiMJFadqnYLoEtkOfTHCrQVusIPc =lwbiMJFadqnYLoEtkOfTHCrQVusIPN.get('vsubtitle')
  lwbiMJFadqnYLoEtkOfTHCrQVusINS=xbmcgui.Dialog()
  lwbiMJFadqnYLoEtkOfTHCrQVusIUK=lwbiMJFadqnYLoEtkOfTHCrQVusINS.yesno(__language__(30913).encode('utf8'),lwbiMJFadqnYLoEtkOfTHCrQVusIPx+' \n\n'+__language__(30914))
  if lwbiMJFadqnYLoEtkOfTHCrQVusIUK==lwbiMJFadqnYLoEtkOfTHCrQVusIPD:return
  lwbiMJFadqnYLoEtkOfTHCrQVusIPm=lwbiMJFadqnYLoEtkOfTHCrQVusINW.WatchaObj.GetBookmarkInfo(lwbiMJFadqnYLoEtkOfTHCrQVusIje,lwbiMJFadqnYLoEtkOfTHCrQVusIPU)
  lwbiMJFadqnYLoEtkOfTHCrQVusIPj=json.dumps(lwbiMJFadqnYLoEtkOfTHCrQVusIPm)
  lwbiMJFadqnYLoEtkOfTHCrQVusIPj=urllib.parse.quote(lwbiMJFadqnYLoEtkOfTHCrQVusIPj)
  lwbiMJFadqnYLoEtkOfTHCrQVusImp ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(lwbiMJFadqnYLoEtkOfTHCrQVusIPj)
  xbmc.executebuiltin(lwbiMJFadqnYLoEtkOfTHCrQVusImp)
 def watcha_main(lwbiMJFadqnYLoEtkOfTHCrQVusINW):
  lwbiMJFadqnYLoEtkOfTHCrQVusIjz=lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params.get('mode',lwbiMJFadqnYLoEtkOfTHCrQVusIPG)
  if lwbiMJFadqnYLoEtkOfTHCrQVusIjz=='LOGOUT':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.logout()
   return
  lwbiMJFadqnYLoEtkOfTHCrQVusINW.login_main()
  if lwbiMJFadqnYLoEtkOfTHCrQVusIjz is lwbiMJFadqnYLoEtkOfTHCrQVusIPG:
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_Main_List()
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz=='SUB_GROUP':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_SubGroup_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz=='CATEGORY_LIST':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_Category_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz=='EPISODE':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_Episode_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz=='ORDER_BY':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_setEpOrderby(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz in['SEARCH','LOCAL_SEARCH']:
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_Search_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz=='MOVIE':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.play_VIDEO(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz=='WATCH':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_Watch_List(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_Listfile_Delete(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz in['TOTAL_SEARCH','TOTAL_HISTORY']:
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_Global_Search(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz=='SEARCH_HISTORY':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_Search_History(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz=='MENU_BOOKMARK':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_Bookmark_Menu(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  elif lwbiMJFadqnYLoEtkOfTHCrQVusIjz=='SET_BOOKMARK':
   lwbiMJFadqnYLoEtkOfTHCrQVusINW.dp_Set_Bookmark(lwbiMJFadqnYLoEtkOfTHCrQVusINW.main_params)
  else:
   lwbiMJFadqnYLoEtkOfTHCrQVusIPG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
