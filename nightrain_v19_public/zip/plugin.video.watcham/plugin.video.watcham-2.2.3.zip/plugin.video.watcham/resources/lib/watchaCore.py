__author__="NightRain"
KxjYWgqdAtwVoPITMeOJLRlbphDcyX=object
KxjYWgqdAtwVoPITMeOJLRlbphDcyH=None
KxjYWgqdAtwVoPITMeOJLRlbphDcyQ=False
KxjYWgqdAtwVoPITMeOJLRlbphDcyr=open
KxjYWgqdAtwVoPITMeOJLRlbphDcyU=True
KxjYWgqdAtwVoPITMeOJLRlbphDcyB=Exception
KxjYWgqdAtwVoPITMeOJLRlbphDcyE=print
KxjYWgqdAtwVoPITMeOJLRlbphDcyu=range
KxjYWgqdAtwVoPITMeOJLRlbphDcyG=len
KxjYWgqdAtwVoPITMeOJLRlbphDcSn=str
KxjYWgqdAtwVoPITMeOJLRlbphDcSC=int
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
class KxjYWgqdAtwVoPITMeOJLRlbphDcnC(KxjYWgqdAtwVoPITMeOJLRlbphDcyX):
 def __init__(KxjYWgqdAtwVoPITMeOJLRlbphDcnf):
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC ={}
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.Init_WC_Total()
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.MAIN_DOMAIN ='https://watcha.com'
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN ='https://api-mars.watcha.com'
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.EPISODE_LIMIT=20
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.SEARCH_LIMIT =30
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.DEFAULT_HEADER={'user-agent':KxjYWgqdAtwVoPITMeOJLRlbphDcnf.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def Init_WC_Total(KxjYWgqdAtwVoPITMeOJLRlbphDcnf):
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC={'account':{},'cookies':{'watcha_token':'','watcha_guit':'','watcha_guitv':'','watcha_usercd':'',},}
 def callRequestCookies(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,jobtype,KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,redirects=KxjYWgqdAtwVoPITMeOJLRlbphDcyQ):
  KxjYWgqdAtwVoPITMeOJLRlbphDcny=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.DEFAULT_HEADER
  if headers:KxjYWgqdAtwVoPITMeOJLRlbphDcny.update(headers)
  if jobtype=='Get':
   KxjYWgqdAtwVoPITMeOJLRlbphDcnS=requests.get(KxjYWgqdAtwVoPITMeOJLRlbphDcnB,params=params,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcny,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   KxjYWgqdAtwVoPITMeOJLRlbphDcnS=requests.put(KxjYWgqdAtwVoPITMeOJLRlbphDcnB,data=payload,params=params,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcny,cookies=cookies,allow_redirects=redirects)
  else:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnS=requests.post(KxjYWgqdAtwVoPITMeOJLRlbphDcnB,data=payload,params=params,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcny,cookies=cookies,allow_redirects=redirects)
  return KxjYWgqdAtwVoPITMeOJLRlbphDcnS
 def JsonFile_Save(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,filename,KxjYWgqdAtwVoPITMeOJLRlbphDcna):
  if filename=='':return KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  try:
   fp=KxjYWgqdAtwVoPITMeOJLRlbphDcyr(filename,'w',-1,'utf-8')
   json.dump(KxjYWgqdAtwVoPITMeOJLRlbphDcna,fp,indent=4,ensure_ascii=KxjYWgqdAtwVoPITMeOJLRlbphDcyQ)
   fp.close()
  except:
   return KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  return KxjYWgqdAtwVoPITMeOJLRlbphDcyU
 def JsonFile_Load(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,filename):
  if filename=='':return{}
  try:
   fp=KxjYWgqdAtwVoPITMeOJLRlbphDcyr(filename,'r',-1,'utf-8')
   KxjYWgqdAtwVoPITMeOJLRlbphDcnv=json.load(fp)
   fp.close()
  except:
   return{}
  return KxjYWgqdAtwVoPITMeOJLRlbphDcnv
 def Save_session_acount(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,KxjYWgqdAtwVoPITMeOJLRlbphDcnz,KxjYWgqdAtwVoPITMeOJLRlbphDcnm,KxjYWgqdAtwVoPITMeOJLRlbphDcnN):
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['account']['wcid']=base64.standard_b64encode(KxjYWgqdAtwVoPITMeOJLRlbphDcnz.encode()).decode('utf-8')
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['account']['wcpw']=base64.standard_b64encode(KxjYWgqdAtwVoPITMeOJLRlbphDcnm.encode()).decode('utf-8')
  KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['account']['wcpf']=KxjYWgqdAtwVoPITMeOJLRlbphDcnN 
 def Load_session_acount(KxjYWgqdAtwVoPITMeOJLRlbphDcnf):
  try:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnz=base64.standard_b64decode(KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['account']['wcid']).decode('utf-8')
   KxjYWgqdAtwVoPITMeOJLRlbphDcnm=base64.standard_b64decode(KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['account']['wcpw']).decode('utf-8')
   KxjYWgqdAtwVoPITMeOJLRlbphDcnN=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['account']['wcpf']
  except:
   return '','',0
  return KxjYWgqdAtwVoPITMeOJLRlbphDcnz,KxjYWgqdAtwVoPITMeOJLRlbphDcnm,KxjYWgqdAtwVoPITMeOJLRlbphDcnN
 def makeDefaultCookies(KxjYWgqdAtwVoPITMeOJLRlbphDcnf):
  KxjYWgqdAtwVoPITMeOJLRlbphDcnk={'_s_guit':KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_guit'],'_guinness-premium_session':KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_token']}
  if KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_guitv']:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnk['_s_guitv']=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_guitv']
  return KxjYWgqdAtwVoPITMeOJLRlbphDcnk
 def GetCredential(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,user_id,user_pw,user_pf):
  try:
   KxjYWgqdAtwVoPITMeOJLRlbphDcns=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN+'/api/session'
   KxjYWgqdAtwVoPITMeOJLRlbphDcnF={'email':user_id,'password':user_pw}
   KxjYWgqdAtwVoPITMeOJLRlbphDcnX={'accept':'application/vnd.frograms+json;version=4'}
   KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Post',KxjYWgqdAtwVoPITMeOJLRlbphDcns,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcnF,params=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcnX,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcyH)
   for KxjYWgqdAtwVoPITMeOJLRlbphDcnQ in KxjYWgqdAtwVoPITMeOJLRlbphDcnH.cookies:
    if KxjYWgqdAtwVoPITMeOJLRlbphDcnQ.name=='_guinness-premium_session':
     KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_token']=KxjYWgqdAtwVoPITMeOJLRlbphDcnQ.value
    elif KxjYWgqdAtwVoPITMeOJLRlbphDcnQ.name=='_s_guit':
     KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_guit']=KxjYWgqdAtwVoPITMeOJLRlbphDcnQ.value
   if KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_token']=='':
    KxjYWgqdAtwVoPITMeOJLRlbphDcnf.Init_WC_Total()
    return KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  except KxjYWgqdAtwVoPITMeOJLRlbphDcyB as exception:
   KxjYWgqdAtwVoPITMeOJLRlbphDcyE(exception)
   KxjYWgqdAtwVoPITMeOJLRlbphDcnf.Init_WC_Total()
   return KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  if KxjYWgqdAtwVoPITMeOJLRlbphDcnf.GetProfilesList(user_pf)==KxjYWgqdAtwVoPITMeOJLRlbphDcyQ:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnf.Init_WC_Total()
   return KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  if user_pf!=0:
   if KxjYWgqdAtwVoPITMeOJLRlbphDcnf.GetProfilesConvert()==KxjYWgqdAtwVoPITMeOJLRlbphDcyQ:
    KxjYWgqdAtwVoPITMeOJLRlbphDcnf.Init_WC_Total()
    return KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  return KxjYWgqdAtwVoPITMeOJLRlbphDcyU
 def GetProfilesList(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,user_pf):
  KxjYWgqdAtwVoPITMeOJLRlbphDcnr=[]
  try:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnU ='/manage_profiles'
   KxjYWgqdAtwVoPITMeOJLRlbphDcnB=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.MAIN_DOMAIN+KxjYWgqdAtwVoPITMeOJLRlbphDcnU
   KxjYWgqdAtwVoPITMeOJLRlbphDcnQ=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.makeDefaultCookies()
   KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Get',KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcnQ,redirects=KxjYWgqdAtwVoPITMeOJLRlbphDcyU)
   KxjYWgqdAtwVoPITMeOJLRlbphDcnE=KxjYWgqdAtwVoPITMeOJLRlbphDcnH.text
   KxjYWgqdAtwVoPITMeOJLRlbphDcnu =re.findall('/api/users/me.{8000}',KxjYWgqdAtwVoPITMeOJLRlbphDcnE)[0]
   KxjYWgqdAtwVoPITMeOJLRlbphDcnu =KxjYWgqdAtwVoPITMeOJLRlbphDcnu.replace('&quot;','')
   KxjYWgqdAtwVoPITMeOJLRlbphDcnr=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',KxjYWgqdAtwVoPITMeOJLRlbphDcnu)
   for i in KxjYWgqdAtwVoPITMeOJLRlbphDcyu(KxjYWgqdAtwVoPITMeOJLRlbphDcyG(KxjYWgqdAtwVoPITMeOJLRlbphDcnr)):
    KxjYWgqdAtwVoPITMeOJLRlbphDcnG=KxjYWgqdAtwVoPITMeOJLRlbphDcnr[i]
    KxjYWgqdAtwVoPITMeOJLRlbphDcnG =KxjYWgqdAtwVoPITMeOJLRlbphDcnG.split(':')[1]
    KxjYWgqdAtwVoPITMeOJLRlbphDcnr[i]=KxjYWgqdAtwVoPITMeOJLRlbphDcnG.split(',')[0]
   KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_usercd']=KxjYWgqdAtwVoPITMeOJLRlbphDcnr[user_pf]
  except KxjYWgqdAtwVoPITMeOJLRlbphDcyB as exception:
   KxjYWgqdAtwVoPITMeOJLRlbphDcyE(exception)
   KxjYWgqdAtwVoPITMeOJLRlbphDcnf.Init_WC_Total()
   return KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  return KxjYWgqdAtwVoPITMeOJLRlbphDcyU
 def GetProfilesConvert(KxjYWgqdAtwVoPITMeOJLRlbphDcnf):
  try:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnU ='/api/users/'+KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_usercd']+'/convert'
   KxjYWgqdAtwVoPITMeOJLRlbphDcnB=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN+KxjYWgqdAtwVoPITMeOJLRlbphDcnU
   KxjYWgqdAtwVoPITMeOJLRlbphDcnQ=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.makeDefaultCookies()
   KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Put',KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcnQ)
   for KxjYWgqdAtwVoPITMeOJLRlbphDcnQ in KxjYWgqdAtwVoPITMeOJLRlbphDcnH.cookies:
    if KxjYWgqdAtwVoPITMeOJLRlbphDcnQ.name=='_s_guitv':
     KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_guitv']=KxjYWgqdAtwVoPITMeOJLRlbphDcnQ.value
    elif KxjYWgqdAtwVoPITMeOJLRlbphDcnQ.name=='_guinness-premium_session':
     KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_token']=KxjYWgqdAtwVoPITMeOJLRlbphDcnQ.value
  except KxjYWgqdAtwVoPITMeOJLRlbphDcyB as exception:
   KxjYWgqdAtwVoPITMeOJLRlbphDcyE(exception)
   KxjYWgqdAtwVoPITMeOJLRlbphDcnf.Init_WC_Total()
   return KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  return KxjYWgqdAtwVoPITMeOJLRlbphDcyU
 def GetSubGroupList(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,stype):
  KxjYWgqdAtwVoPITMeOJLRlbphDcCn=[]
  try:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnU ='/api/categories.json'
   KxjYWgqdAtwVoPITMeOJLRlbphDcnB=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN+KxjYWgqdAtwVoPITMeOJLRlbphDcnU
   KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Get',KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcyH)
   KxjYWgqdAtwVoPITMeOJLRlbphDcCf=json.loads(KxjYWgqdAtwVoPITMeOJLRlbphDcnH.text)
   if not('genres' in KxjYWgqdAtwVoPITMeOJLRlbphDcCf):return KxjYWgqdAtwVoPITMeOJLRlbphDcCn
   if stype=='genres':
    KxjYWgqdAtwVoPITMeOJLRlbphDcCy=KxjYWgqdAtwVoPITMeOJLRlbphDcCf['genres']
   else:
    KxjYWgqdAtwVoPITMeOJLRlbphDcCy=KxjYWgqdAtwVoPITMeOJLRlbphDcCf['tags']
   for KxjYWgqdAtwVoPITMeOJLRlbphDcCS in KxjYWgqdAtwVoPITMeOJLRlbphDcCy:
    KxjYWgqdAtwVoPITMeOJLRlbphDcCa=KxjYWgqdAtwVoPITMeOJLRlbphDcCS['name']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCi =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['api_path']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCv =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['entity']['id']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCz={'group_name':KxjYWgqdAtwVoPITMeOJLRlbphDcCa,'api_path':KxjYWgqdAtwVoPITMeOJLRlbphDcCi,'tag_id':KxjYWgqdAtwVoPITMeOJLRlbphDcSn(KxjYWgqdAtwVoPITMeOJLRlbphDcCv)}
    KxjYWgqdAtwVoPITMeOJLRlbphDcCn.append(KxjYWgqdAtwVoPITMeOJLRlbphDcCz)
  except KxjYWgqdAtwVoPITMeOJLRlbphDcyB as exception:
   KxjYWgqdAtwVoPITMeOJLRlbphDcyE(exception)
  return KxjYWgqdAtwVoPITMeOJLRlbphDcCn
 def GetCategoryList(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,stype,KxjYWgqdAtwVoPITMeOJLRlbphDcCv,KxjYWgqdAtwVoPITMeOJLRlbphDcCi,page_int,in_sort):
  KxjYWgqdAtwVoPITMeOJLRlbphDcCn=[]
  KxjYWgqdAtwVoPITMeOJLRlbphDcCm=KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  KxjYWgqdAtwVoPITMeOJLRlbphDcCN={}
  try:
   if 'categories' in KxjYWgqdAtwVoPITMeOJLRlbphDcCi:
    KxjYWgqdAtwVoPITMeOJLRlbphDcnU ='/api/categories/contents.json'
    if stype=='genres':
     KxjYWgqdAtwVoPITMeOJLRlbphDcCN['genre']=KxjYWgqdAtwVoPITMeOJLRlbphDcCv
    else:
     KxjYWgqdAtwVoPITMeOJLRlbphDcCN['tag'] =KxjYWgqdAtwVoPITMeOJLRlbphDcCv
    KxjYWgqdAtwVoPITMeOJLRlbphDcCN['order']=in_sort 
    if page_int>1:
     KxjYWgqdAtwVoPITMeOJLRlbphDcCN['page']=KxjYWgqdAtwVoPITMeOJLRlbphDcSn(page_int-1)
   else: 
    KxjYWgqdAtwVoPITMeOJLRlbphDcnU ='/api/'+KxjYWgqdAtwVoPITMeOJLRlbphDcCi+'.json'
    if page_int>1:
     KxjYWgqdAtwVoPITMeOJLRlbphDcCN['page']=KxjYWgqdAtwVoPITMeOJLRlbphDcSn(page_int)
   KxjYWgqdAtwVoPITMeOJLRlbphDcnB=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN+KxjYWgqdAtwVoPITMeOJLRlbphDcnU
   KxjYWgqdAtwVoPITMeOJLRlbphDcnQ=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.makeDefaultCookies()
   KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Get',KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcCN,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcnQ)
   KxjYWgqdAtwVoPITMeOJLRlbphDcCf=json.loads(KxjYWgqdAtwVoPITMeOJLRlbphDcnH.text)
   if not('contents' in KxjYWgqdAtwVoPITMeOJLRlbphDcCf):return KxjYWgqdAtwVoPITMeOJLRlbphDcCn,KxjYWgqdAtwVoPITMeOJLRlbphDcCm
   KxjYWgqdAtwVoPITMeOJLRlbphDcCy=KxjYWgqdAtwVoPITMeOJLRlbphDcCf['contents']
   KxjYWgqdAtwVoPITMeOJLRlbphDcCm=KxjYWgqdAtwVoPITMeOJLRlbphDcCf['meta']['has_next']
   for KxjYWgqdAtwVoPITMeOJLRlbphDcCS in KxjYWgqdAtwVoPITMeOJLRlbphDcCy:
    KxjYWgqdAtwVoPITMeOJLRlbphDcCk =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['code']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCs=KxjYWgqdAtwVoPITMeOJLRlbphDcCS['content_type']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCF =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['title']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCX =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['story']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCH=KxjYWgqdAtwVoPITMeOJLRlbphDcyF=KxjYWgqdAtwVoPITMeOJLRlbphDcys=''
    if KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('poster') !=KxjYWgqdAtwVoPITMeOJLRlbphDcyH:KxjYWgqdAtwVoPITMeOJLRlbphDcCH=KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('poster').get('original')
    if KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('stillcut')!=KxjYWgqdAtwVoPITMeOJLRlbphDcyH:KxjYWgqdAtwVoPITMeOJLRlbphDcyF =KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('stillcut').get('large')
    if KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('thumbnail')!=KxjYWgqdAtwVoPITMeOJLRlbphDcyH:KxjYWgqdAtwVoPITMeOJLRlbphDcys=KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('thumbnail').get('large')
    if KxjYWgqdAtwVoPITMeOJLRlbphDcys=='' :KxjYWgqdAtwVoPITMeOJLRlbphDcys=KxjYWgqdAtwVoPITMeOJLRlbphDcyF
    KxjYWgqdAtwVoPITMeOJLRlbphDcCQ={'thumb':KxjYWgqdAtwVoPITMeOJLRlbphDcyF,'poster':KxjYWgqdAtwVoPITMeOJLRlbphDcCH,'fanart':KxjYWgqdAtwVoPITMeOJLRlbphDcys}
    KxjYWgqdAtwVoPITMeOJLRlbphDcCr =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['year']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCU =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['film_rating_code']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCB=KxjYWgqdAtwVoPITMeOJLRlbphDcCS['film_rating_short']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCE =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['film_rating_long']
    if KxjYWgqdAtwVoPITMeOJLRlbphDcCs=='movies':
     KxjYWgqdAtwVoPITMeOJLRlbphDcCu =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['duration']
    else:
     KxjYWgqdAtwVoPITMeOJLRlbphDcCu ='0'
    KxjYWgqdAtwVoPITMeOJLRlbphDcCz={'code':KxjYWgqdAtwVoPITMeOJLRlbphDcCk,'content_type':KxjYWgqdAtwVoPITMeOJLRlbphDcCs,'title':KxjYWgqdAtwVoPITMeOJLRlbphDcCF,'story':KxjYWgqdAtwVoPITMeOJLRlbphDcCX,'thumbnail':KxjYWgqdAtwVoPITMeOJLRlbphDcCQ,'year':KxjYWgqdAtwVoPITMeOJLRlbphDcCr,'film_rating_code':KxjYWgqdAtwVoPITMeOJLRlbphDcCU,'film_rating_short':KxjYWgqdAtwVoPITMeOJLRlbphDcCB,'film_rating_long':KxjYWgqdAtwVoPITMeOJLRlbphDcCE,'duration':KxjYWgqdAtwVoPITMeOJLRlbphDcCu}
    KxjYWgqdAtwVoPITMeOJLRlbphDcCn.append(KxjYWgqdAtwVoPITMeOJLRlbphDcCz)
  except KxjYWgqdAtwVoPITMeOJLRlbphDcyB as exception:
   KxjYWgqdAtwVoPITMeOJLRlbphDcyE(exception)
  return KxjYWgqdAtwVoPITMeOJLRlbphDcCn,KxjYWgqdAtwVoPITMeOJLRlbphDcCm
 def GetCategoryList_morepage(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,stype,KxjYWgqdAtwVoPITMeOJLRlbphDcCv,KxjYWgqdAtwVoPITMeOJLRlbphDcCi,page_int,in_sort):
  KxjYWgqdAtwVoPITMeOJLRlbphDcCm=KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  if not('categories' in KxjYWgqdAtwVoPITMeOJLRlbphDcCi):return KxjYWgqdAtwVoPITMeOJLRlbphDcyU
  try:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnU ='/api/categories/contents.json'
   KxjYWgqdAtwVoPITMeOJLRlbphDcnB=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN+KxjYWgqdAtwVoPITMeOJLRlbphDcnU
   KxjYWgqdAtwVoPITMeOJLRlbphDcCN={}
   if stype=='genres':
    KxjYWgqdAtwVoPITMeOJLRlbphDcCN['genre']=KxjYWgqdAtwVoPITMeOJLRlbphDcCv
   else:
    KxjYWgqdAtwVoPITMeOJLRlbphDcCN['tag'] =KxjYWgqdAtwVoPITMeOJLRlbphDcCv
   KxjYWgqdAtwVoPITMeOJLRlbphDcCN['order']=in_sort 
   if page_int>1:
    KxjYWgqdAtwVoPITMeOJLRlbphDcCN['page']=KxjYWgqdAtwVoPITMeOJLRlbphDcSn(page_int-1)
   KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Get',KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcCN,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcyH)
   KxjYWgqdAtwVoPITMeOJLRlbphDcCf=json.loads(KxjYWgqdAtwVoPITMeOJLRlbphDcnH.text)
   KxjYWgqdAtwVoPITMeOJLRlbphDcCm=KxjYWgqdAtwVoPITMeOJLRlbphDcCf['meta']['has_next']
  except KxjYWgqdAtwVoPITMeOJLRlbphDcyB as exception:
   KxjYWgqdAtwVoPITMeOJLRlbphDcyE(exception)
  return KxjYWgqdAtwVoPITMeOJLRlbphDcCm
 def GetProgramInfo(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,program_code):
  KxjYWgqdAtwVoPITMeOJLRlbphDcCG={}
  try:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnU ='/api/contents/'+program_code
   KxjYWgqdAtwVoPITMeOJLRlbphDcnB=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN+KxjYWgqdAtwVoPITMeOJLRlbphDcnU
   KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Get',KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcyH)
   KxjYWgqdAtwVoPITMeOJLRlbphDcCf=json.loads(KxjYWgqdAtwVoPITMeOJLRlbphDcnH.text)
   KxjYWgqdAtwVoPITMeOJLRlbphDcfn=img_clearlogo=''
   KxjYWgqdAtwVoPITMeOJLRlbphDcfn=KxjYWgqdAtwVoPITMeOJLRlbphDcCf.get('poster').get('original')
   if KxjYWgqdAtwVoPITMeOJLRlbphDcyG(KxjYWgqdAtwVoPITMeOJLRlbphDcCf.get('title_logos'))>0:img_clearlogo=KxjYWgqdAtwVoPITMeOJLRlbphDcCf.get('title_logos')[0].get('src')
   KxjYWgqdAtwVoPITMeOJLRlbphDcCG={'imgPoster':KxjYWgqdAtwVoPITMeOJLRlbphDcfn,'imgClearlogo':img_clearlogo}
  except KxjYWgqdAtwVoPITMeOJLRlbphDcyB as exception:
   KxjYWgqdAtwVoPITMeOJLRlbphDcyE(exception)
  return KxjYWgqdAtwVoPITMeOJLRlbphDcCG
 def GetEpisodoList(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,program_code,page_int,orderby='asc'):
  KxjYWgqdAtwVoPITMeOJLRlbphDcCn=[]
  KxjYWgqdAtwVoPITMeOJLRlbphDcCm=KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  KxjYWgqdAtwVoPITMeOJLRlbphDcfC=''
  try:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnU ='/api/contents/'+program_code+'/tv_episodes.json'
   KxjYWgqdAtwVoPITMeOJLRlbphDcnB=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN+KxjYWgqdAtwVoPITMeOJLRlbphDcnU
   KxjYWgqdAtwVoPITMeOJLRlbphDcCN={'all':'true'}
   KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Get',KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcCN,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcyH)
   KxjYWgqdAtwVoPITMeOJLRlbphDcCf=json.loads(KxjYWgqdAtwVoPITMeOJLRlbphDcnH.text)
   if not('tv_episode_codes' in KxjYWgqdAtwVoPITMeOJLRlbphDcCf):return KxjYWgqdAtwVoPITMeOJLRlbphDcCn,KxjYWgqdAtwVoPITMeOJLRlbphDcCm
   KxjYWgqdAtwVoPITMeOJLRlbphDcCy=KxjYWgqdAtwVoPITMeOJLRlbphDcCf['tv_episode_codes']
   KxjYWgqdAtwVoPITMeOJLRlbphDcfy=KxjYWgqdAtwVoPITMeOJLRlbphDcyG(KxjYWgqdAtwVoPITMeOJLRlbphDcCy)
   KxjYWgqdAtwVoPITMeOJLRlbphDcfS =KxjYWgqdAtwVoPITMeOJLRlbphDcSC(KxjYWgqdAtwVoPITMeOJLRlbphDcfy//(KxjYWgqdAtwVoPITMeOJLRlbphDcnf.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    KxjYWgqdAtwVoPITMeOJLRlbphDcfa =(KxjYWgqdAtwVoPITMeOJLRlbphDcfy-1)-((page_int-1)*KxjYWgqdAtwVoPITMeOJLRlbphDcnf.EPISODE_LIMIT)
   else:
    KxjYWgqdAtwVoPITMeOJLRlbphDcfa =(page_int-1)*KxjYWgqdAtwVoPITMeOJLRlbphDcnf.EPISODE_LIMIT
   for i in KxjYWgqdAtwVoPITMeOJLRlbphDcyu(KxjYWgqdAtwVoPITMeOJLRlbphDcnf.EPISODE_LIMIT):
    if orderby=='desc':
     KxjYWgqdAtwVoPITMeOJLRlbphDcfi=KxjYWgqdAtwVoPITMeOJLRlbphDcfa-i
     if KxjYWgqdAtwVoPITMeOJLRlbphDcfi<0:break
    else:
     KxjYWgqdAtwVoPITMeOJLRlbphDcfi=KxjYWgqdAtwVoPITMeOJLRlbphDcfa+i
     if KxjYWgqdAtwVoPITMeOJLRlbphDcfi>=KxjYWgqdAtwVoPITMeOJLRlbphDcfy:break
    if KxjYWgqdAtwVoPITMeOJLRlbphDcfC!='':KxjYWgqdAtwVoPITMeOJLRlbphDcfC+=','
    KxjYWgqdAtwVoPITMeOJLRlbphDcfC+=KxjYWgqdAtwVoPITMeOJLRlbphDcCy[KxjYWgqdAtwVoPITMeOJLRlbphDcfi]
   if KxjYWgqdAtwVoPITMeOJLRlbphDcfS>page_int:KxjYWgqdAtwVoPITMeOJLRlbphDcCm=KxjYWgqdAtwVoPITMeOJLRlbphDcyU
  except KxjYWgqdAtwVoPITMeOJLRlbphDcyB as exception:
   KxjYWgqdAtwVoPITMeOJLRlbphDcyE(exception)
  KxjYWgqdAtwVoPITMeOJLRlbphDcfv=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.GetProgramInfo(program_code)
  try:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnB=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN+KxjYWgqdAtwVoPITMeOJLRlbphDcnU
   KxjYWgqdAtwVoPITMeOJLRlbphDcCN={'codes':KxjYWgqdAtwVoPITMeOJLRlbphDcfC}
   KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Get',KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcCN,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcyH)
   KxjYWgqdAtwVoPITMeOJLRlbphDcCf=json.loads(KxjYWgqdAtwVoPITMeOJLRlbphDcnH.text)
   if not('tv_episodes' in KxjYWgqdAtwVoPITMeOJLRlbphDcCf):return KxjYWgqdAtwVoPITMeOJLRlbphDcCn
   KxjYWgqdAtwVoPITMeOJLRlbphDcCy=KxjYWgqdAtwVoPITMeOJLRlbphDcCf['tv_episodes']
   for KxjYWgqdAtwVoPITMeOJLRlbphDcCS in KxjYWgqdAtwVoPITMeOJLRlbphDcCy:
    KxjYWgqdAtwVoPITMeOJLRlbphDcCk =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['code']
    if KxjYWgqdAtwVoPITMeOJLRlbphDcCS['title']:
     KxjYWgqdAtwVoPITMeOJLRlbphDcCF =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['title']
    else:
     KxjYWgqdAtwVoPITMeOJLRlbphDcCF =''
    KxjYWgqdAtwVoPITMeOJLRlbphDcCH=KxjYWgqdAtwVoPITMeOJLRlbphDcyF=KxjYWgqdAtwVoPITMeOJLRlbphDcys=KxjYWgqdAtwVoPITMeOJLRlbphDcfz=''
    KxjYWgqdAtwVoPITMeOJLRlbphDcCH =KxjYWgqdAtwVoPITMeOJLRlbphDcfv.get('imgPoster')
    KxjYWgqdAtwVoPITMeOJLRlbphDcfz=KxjYWgqdAtwVoPITMeOJLRlbphDcfv.get('imgClearlogo')
    if KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('stillcut') !=KxjYWgqdAtwVoPITMeOJLRlbphDcyH:KxjYWgqdAtwVoPITMeOJLRlbphDcyF =KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('stillcut').get('large')
    if KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('tv_season_stillcut')!=KxjYWgqdAtwVoPITMeOJLRlbphDcyH:KxjYWgqdAtwVoPITMeOJLRlbphDcys=KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('tv_season_stillcut').get('large')
    KxjYWgqdAtwVoPITMeOJLRlbphDcCQ={'thumb':KxjYWgqdAtwVoPITMeOJLRlbphDcyF,'poster':KxjYWgqdAtwVoPITMeOJLRlbphDcCH,'fanart':KxjYWgqdAtwVoPITMeOJLRlbphDcys,'clearlogo':KxjYWgqdAtwVoPITMeOJLRlbphDcfz}
    KxjYWgqdAtwVoPITMeOJLRlbphDcfm =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['display_number']
    KxjYWgqdAtwVoPITMeOJLRlbphDcfN=KxjYWgqdAtwVoPITMeOJLRlbphDcCS['tv_season_title']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCu =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['duration']
    try:
     KxjYWgqdAtwVoPITMeOJLRlbphDcfk=KxjYWgqdAtwVoPITMeOJLRlbphDcCS['episode_number']
    except:
     KxjYWgqdAtwVoPITMeOJLRlbphDcfk='0'
    KxjYWgqdAtwVoPITMeOJLRlbphDcCz={'code':KxjYWgqdAtwVoPITMeOJLRlbphDcCk,'title':KxjYWgqdAtwVoPITMeOJLRlbphDcCF,'thumbnail':KxjYWgqdAtwVoPITMeOJLRlbphDcCQ,'display_num':KxjYWgqdAtwVoPITMeOJLRlbphDcfm,'season_title':KxjYWgqdAtwVoPITMeOJLRlbphDcfN,'duration':KxjYWgqdAtwVoPITMeOJLRlbphDcCu,'episode_number':KxjYWgqdAtwVoPITMeOJLRlbphDcfk}
    KxjYWgqdAtwVoPITMeOJLRlbphDcCn.append(KxjYWgqdAtwVoPITMeOJLRlbphDcCz)
  except KxjYWgqdAtwVoPITMeOJLRlbphDcyB as exception:
   KxjYWgqdAtwVoPITMeOJLRlbphDcyE(exception)
  return KxjYWgqdAtwVoPITMeOJLRlbphDcCn,KxjYWgqdAtwVoPITMeOJLRlbphDcCm
 def GetSearchList(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,search_key,page_int):
  KxjYWgqdAtwVoPITMeOJLRlbphDcfs=[]
  KxjYWgqdAtwVoPITMeOJLRlbphDcCm=KxjYWgqdAtwVoPITMeOJLRlbphDcyQ
  try:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnU ='/api/search.json'
   KxjYWgqdAtwVoPITMeOJLRlbphDcnB=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN+KxjYWgqdAtwVoPITMeOJLRlbphDcnU
   KxjYWgqdAtwVoPITMeOJLRlbphDcCN={'query':search_key,'page':KxjYWgqdAtwVoPITMeOJLRlbphDcSn(page_int),'per':KxjYWgqdAtwVoPITMeOJLRlbphDcSn(KxjYWgqdAtwVoPITMeOJLRlbphDcnf.SEARCH_LIMIT),'exclude':'limited'}
   KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Get',KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcCN,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcyH)
   KxjYWgqdAtwVoPITMeOJLRlbphDcCf=json.loads(KxjYWgqdAtwVoPITMeOJLRlbphDcnH.text)
   if not('results' in KxjYWgqdAtwVoPITMeOJLRlbphDcCf):return KxjYWgqdAtwVoPITMeOJLRlbphDcfs,KxjYWgqdAtwVoPITMeOJLRlbphDcCm
   KxjYWgqdAtwVoPITMeOJLRlbphDcCy=KxjYWgqdAtwVoPITMeOJLRlbphDcCf['results']
   KxjYWgqdAtwVoPITMeOJLRlbphDcCm=KxjYWgqdAtwVoPITMeOJLRlbphDcCf['meta']['has_next']
   for KxjYWgqdAtwVoPITMeOJLRlbphDcCS in KxjYWgqdAtwVoPITMeOJLRlbphDcCy:
    KxjYWgqdAtwVoPITMeOJLRlbphDcCk =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['code']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCs=KxjYWgqdAtwVoPITMeOJLRlbphDcCS['content_type']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCF =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['title']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCX =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['story']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCH=KxjYWgqdAtwVoPITMeOJLRlbphDcyF=KxjYWgqdAtwVoPITMeOJLRlbphDcys=''
    if KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('poster') !=KxjYWgqdAtwVoPITMeOJLRlbphDcyH:KxjYWgqdAtwVoPITMeOJLRlbphDcCH=KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('poster').get('original')
    if KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('stillcut')!=KxjYWgqdAtwVoPITMeOJLRlbphDcyH:KxjYWgqdAtwVoPITMeOJLRlbphDcyF =KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('stillcut').get('large')
    if KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('thumbnail')!=KxjYWgqdAtwVoPITMeOJLRlbphDcyH:KxjYWgqdAtwVoPITMeOJLRlbphDcys=KxjYWgqdAtwVoPITMeOJLRlbphDcCS.get('thumbnail').get('large')
    if KxjYWgqdAtwVoPITMeOJLRlbphDcys=='' :KxjYWgqdAtwVoPITMeOJLRlbphDcys=KxjYWgqdAtwVoPITMeOJLRlbphDcyF
    KxjYWgqdAtwVoPITMeOJLRlbphDcCQ={'thumb':KxjYWgqdAtwVoPITMeOJLRlbphDcyF,'poster':KxjYWgqdAtwVoPITMeOJLRlbphDcCH,'fanart':KxjYWgqdAtwVoPITMeOJLRlbphDcys}
    KxjYWgqdAtwVoPITMeOJLRlbphDcCr =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['year']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCU =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['film_rating_code']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCB=KxjYWgqdAtwVoPITMeOJLRlbphDcCS['film_rating_short']
    KxjYWgqdAtwVoPITMeOJLRlbphDcCE =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['film_rating_long']
    if KxjYWgqdAtwVoPITMeOJLRlbphDcCs=='movies':
     KxjYWgqdAtwVoPITMeOJLRlbphDcCu =KxjYWgqdAtwVoPITMeOJLRlbphDcCS['duration']
    else:
     KxjYWgqdAtwVoPITMeOJLRlbphDcCu ='0'
    KxjYWgqdAtwVoPITMeOJLRlbphDcCz={'code':KxjYWgqdAtwVoPITMeOJLRlbphDcCk,'content_type':KxjYWgqdAtwVoPITMeOJLRlbphDcCs,'title':KxjYWgqdAtwVoPITMeOJLRlbphDcCF,'story':KxjYWgqdAtwVoPITMeOJLRlbphDcCX,'thumbnail':KxjYWgqdAtwVoPITMeOJLRlbphDcCQ,'year':KxjYWgqdAtwVoPITMeOJLRlbphDcCr,'film_rating_code':KxjYWgqdAtwVoPITMeOJLRlbphDcCU,'film_rating_short':KxjYWgqdAtwVoPITMeOJLRlbphDcCB,'film_rating_long':KxjYWgqdAtwVoPITMeOJLRlbphDcCE,'duration':KxjYWgqdAtwVoPITMeOJLRlbphDcCu}
    KxjYWgqdAtwVoPITMeOJLRlbphDcfs.append(KxjYWgqdAtwVoPITMeOJLRlbphDcCz)
  except KxjYWgqdAtwVoPITMeOJLRlbphDcyB as exception:
   KxjYWgqdAtwVoPITMeOJLRlbphDcyE(exception)
  return KxjYWgqdAtwVoPITMeOJLRlbphDcfs,KxjYWgqdAtwVoPITMeOJLRlbphDcCm
 def Get_Now_Datetime(KxjYWgqdAtwVoPITMeOJLRlbphDcnf):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,movie_code,quality_str):
  KxjYWgqdAtwVoPITMeOJLRlbphDcfX=KxjYWgqdAtwVoPITMeOJLRlbphDcfQ=KxjYWgqdAtwVoPITMeOJLRlbphDcfu=''
  try:
   KxjYWgqdAtwVoPITMeOJLRlbphDcnU='/api/watch/'+movie_code+'.json'
   KxjYWgqdAtwVoPITMeOJLRlbphDcnB=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN+KxjYWgqdAtwVoPITMeOJLRlbphDcnU
   KxjYWgqdAtwVoPITMeOJLRlbphDcnX={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   KxjYWgqdAtwVoPITMeOJLRlbphDcnQ=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.makeDefaultCookies()
   KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Get',KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcnX,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcnQ)
   KxjYWgqdAtwVoPITMeOJLRlbphDcCf=json.loads(KxjYWgqdAtwVoPITMeOJLRlbphDcnH.text)
   KxjYWgqdAtwVoPITMeOJLRlbphDcfX=KxjYWgqdAtwVoPITMeOJLRlbphDcCf['streams'][0]['source']
   if KxjYWgqdAtwVoPITMeOJLRlbphDcfX==KxjYWgqdAtwVoPITMeOJLRlbphDcyH:return(KxjYWgqdAtwVoPITMeOJLRlbphDcfX,KxjYWgqdAtwVoPITMeOJLRlbphDcfQ,KxjYWgqdAtwVoPITMeOJLRlbphDcfu)
   if 'subtitles' in KxjYWgqdAtwVoPITMeOJLRlbphDcCf['streams'][0]:
    for KxjYWgqdAtwVoPITMeOJLRlbphDcfH in KxjYWgqdAtwVoPITMeOJLRlbphDcCf['streams'][0]['subtitles']:
     if KxjYWgqdAtwVoPITMeOJLRlbphDcfH['lang']=='ko':
      KxjYWgqdAtwVoPITMeOJLRlbphDcfQ=KxjYWgqdAtwVoPITMeOJLRlbphDcfH['url']
      break
   KxjYWgqdAtwVoPITMeOJLRlbphDcfr =KxjYWgqdAtwVoPITMeOJLRlbphDcCf['ping_payload']
   KxjYWgqdAtwVoPITMeOJLRlbphDcfU =KxjYWgqdAtwVoPITMeOJLRlbphDcnf.WC['cookies']['watcha_usercd']
   KxjYWgqdAtwVoPITMeOJLRlbphDcfB={'merchant':'giitd_frograms','sessionId':KxjYWgqdAtwVoPITMeOJLRlbphDcfr,'userId':KxjYWgqdAtwVoPITMeOJLRlbphDcfU}
   KxjYWgqdAtwVoPITMeOJLRlbphDcfE=json.dumps(KxjYWgqdAtwVoPITMeOJLRlbphDcfB,separators=(",",":")).encode('UTF-8')
   KxjYWgqdAtwVoPITMeOJLRlbphDcfu=base64.b64encode(KxjYWgqdAtwVoPITMeOJLRlbphDcfE)
  except KxjYWgqdAtwVoPITMeOJLRlbphDcyB as exception:
   return(KxjYWgqdAtwVoPITMeOJLRlbphDcfX,KxjYWgqdAtwVoPITMeOJLRlbphDcfQ,KxjYWgqdAtwVoPITMeOJLRlbphDcfu)
  return(KxjYWgqdAtwVoPITMeOJLRlbphDcfX,KxjYWgqdAtwVoPITMeOJLRlbphDcfQ,KxjYWgqdAtwVoPITMeOJLRlbphDcfu) 
 def GetBookmarkInfo(KxjYWgqdAtwVoPITMeOJLRlbphDcnf,videoid,vidtype):
  KxjYWgqdAtwVoPITMeOJLRlbphDcfG={'indexinfo':{'ott':'watcha','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  KxjYWgqdAtwVoPITMeOJLRlbphDcnB=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.API_DOMAIN+'/api/contents/'+videoid
  KxjYWgqdAtwVoPITMeOJLRlbphDcnH=KxjYWgqdAtwVoPITMeOJLRlbphDcnf.callRequestCookies('Get',KxjYWgqdAtwVoPITMeOJLRlbphDcnB,payload=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,params=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,headers=KxjYWgqdAtwVoPITMeOJLRlbphDcyH,cookies=KxjYWgqdAtwVoPITMeOJLRlbphDcyH)
  KxjYWgqdAtwVoPITMeOJLRlbphDcyn=json.loads(KxjYWgqdAtwVoPITMeOJLRlbphDcnH.text)
  if not('title' in KxjYWgqdAtwVoPITMeOJLRlbphDcyn):return{}
  KxjYWgqdAtwVoPITMeOJLRlbphDcyC=KxjYWgqdAtwVoPITMeOJLRlbphDcyn
  KxjYWgqdAtwVoPITMeOJLRlbphDcyE(KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('duration'))
  KxjYWgqdAtwVoPITMeOJLRlbphDcyf=KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('title')
  KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['infoLabels']['title']=KxjYWgqdAtwVoPITMeOJLRlbphDcyf
  KxjYWgqdAtwVoPITMeOJLRlbphDcyf +=u'  (%s)'%(KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('year'))
  KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['title'] =KxjYWgqdAtwVoPITMeOJLRlbphDcyf
  KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['infoLabels']['mpaa'] =KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('film_rating_long')
  KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['infoLabels']['plot'] =KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('story').replace('<br>','\n')
  KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['infoLabels']['year'] =KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('year')
  if vidtype=='movie':
   KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['infoLabels']['duration']=KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('duration')
  KxjYWgqdAtwVoPITMeOJLRlbphDcyS=[]
  for KxjYWgqdAtwVoPITMeOJLRlbphDcya in KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('actors'):
   KxjYWgqdAtwVoPITMeOJLRlbphDcyi =KxjYWgqdAtwVoPITMeOJLRlbphDcya.get('name')
   KxjYWgqdAtwVoPITMeOJLRlbphDcyv='' if KxjYWgqdAtwVoPITMeOJLRlbphDcya.get('photo')==KxjYWgqdAtwVoPITMeOJLRlbphDcyH else KxjYWgqdAtwVoPITMeOJLRlbphDcya.get('photo').get('small')
   KxjYWgqdAtwVoPITMeOJLRlbphDcyS.append({'name':KxjYWgqdAtwVoPITMeOJLRlbphDcyi,'thumbnail':KxjYWgqdAtwVoPITMeOJLRlbphDcyv})
  if KxjYWgqdAtwVoPITMeOJLRlbphDcyG(KxjYWgqdAtwVoPITMeOJLRlbphDcyS)>0:
   KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['infoLabels']['cast']=KxjYWgqdAtwVoPITMeOJLRlbphDcyS
  KxjYWgqdAtwVoPITMeOJLRlbphDcyz=[]
  for KxjYWgqdAtwVoPITMeOJLRlbphDcym in KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('directors'):KxjYWgqdAtwVoPITMeOJLRlbphDcyz.append(KxjYWgqdAtwVoPITMeOJLRlbphDcym.get('name'))
  if KxjYWgqdAtwVoPITMeOJLRlbphDcyG(KxjYWgqdAtwVoPITMeOJLRlbphDcyz)>0:
   KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['infoLabels']['director']=KxjYWgqdAtwVoPITMeOJLRlbphDcyz
  KxjYWgqdAtwVoPITMeOJLRlbphDcyN=[]
  for KxjYWgqdAtwVoPITMeOJLRlbphDcyk in KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('genres'):KxjYWgqdAtwVoPITMeOJLRlbphDcyN.append(KxjYWgqdAtwVoPITMeOJLRlbphDcyk.get('name'))
  if KxjYWgqdAtwVoPITMeOJLRlbphDcyG(KxjYWgqdAtwVoPITMeOJLRlbphDcyN)>0:
   KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['infoLabels']['genre']=KxjYWgqdAtwVoPITMeOJLRlbphDcyN
  KxjYWgqdAtwVoPITMeOJLRlbphDcCH =''
  KxjYWgqdAtwVoPITMeOJLRlbphDcys =''
  KxjYWgqdAtwVoPITMeOJLRlbphDcyF =''
  if KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('poster') !=KxjYWgqdAtwVoPITMeOJLRlbphDcyH:KxjYWgqdAtwVoPITMeOJLRlbphDcCH =KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('poster').get('original')
  if KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('thumbnail')!=KxjYWgqdAtwVoPITMeOJLRlbphDcyH:KxjYWgqdAtwVoPITMeOJLRlbphDcys =KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('thumbnail').get('large')
  if KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('stillcut')!=KxjYWgqdAtwVoPITMeOJLRlbphDcyH:KxjYWgqdAtwVoPITMeOJLRlbphDcyF =KxjYWgqdAtwVoPITMeOJLRlbphDcyC.get('stillcut').get('large')
  if KxjYWgqdAtwVoPITMeOJLRlbphDcys=='':KxjYWgqdAtwVoPITMeOJLRlbphDcys=KxjYWgqdAtwVoPITMeOJLRlbphDcyF
  KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['thumbnail']['poster']=KxjYWgqdAtwVoPITMeOJLRlbphDcCH
  KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['thumbnail']['fanart']=KxjYWgqdAtwVoPITMeOJLRlbphDcys
  KxjYWgqdAtwVoPITMeOJLRlbphDcfG['saveinfo']['thumbnail']['thumb']=KxjYWgqdAtwVoPITMeOJLRlbphDcyF
  return KxjYWgqdAtwVoPITMeOJLRlbphDcfG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
