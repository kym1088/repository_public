__author__="NightRain"
ybpEvQBlaDATjYrXWqoKILsJgfHzRx=object
ybpEvQBlaDATjYrXWqoKILsJgfHzRt=None
ybpEvQBlaDATjYrXWqoKILsJgfHzRU=int
ybpEvQBlaDATjYrXWqoKILsJgfHzRP=True
ybpEvQBlaDATjYrXWqoKILsJgfHzRV=False
ybpEvQBlaDATjYrXWqoKILsJgfHzRh=type
ybpEvQBlaDATjYrXWqoKILsJgfHzRm=dict
ybpEvQBlaDATjYrXWqoKILsJgfHzRi=len
ybpEvQBlaDATjYrXWqoKILsJgfHzRN=range
ybpEvQBlaDATjYrXWqoKILsJgfHzwe=str
ybpEvQBlaDATjYrXWqoKILsJgfHzwO=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
ybpEvQBlaDATjYrXWqoKILsJgfHzeS=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-','icon':'history.png'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','sort':'-','icon':'bookmark.png'}]
ybpEvQBlaDATjYrXWqoKILsJgfHzeu=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
ybpEvQBlaDATjYrXWqoKILsJgfHzeG=40
ybpEvQBlaDATjYrXWqoKILsJgfHzeC =20
ybpEvQBlaDATjYrXWqoKILsJgfHzeR =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
ybpEvQBlaDATjYrXWqoKILsJgfHzew =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.srt'))
ybpEvQBlaDATjYrXWqoKILsJgfHzeM =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
ybpEvQBlaDATjYrXWqoKILsJgfHzek=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
from watchaCore import*
class ybpEvQBlaDATjYrXWqoKILsJgfHzeO(ybpEvQBlaDATjYrXWqoKILsJgfHzRx):
 def __init__(ybpEvQBlaDATjYrXWqoKILsJgfHzec,ybpEvQBlaDATjYrXWqoKILsJgfHzed,ybpEvQBlaDATjYrXWqoKILsJgfHzen,ybpEvQBlaDATjYrXWqoKILsJgfHzeF):
  ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_url =ybpEvQBlaDATjYrXWqoKILsJgfHzed
  ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle=ybpEvQBlaDATjYrXWqoKILsJgfHzen
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params =ybpEvQBlaDATjYrXWqoKILsJgfHzeF
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj =KxjYWgqdAtwVoPITMeOJLRlbphDcnC() 
 def addon_noti(ybpEvQBlaDATjYrXWqoKILsJgfHzec,sting):
  try:
   ybpEvQBlaDATjYrXWqoKILsJgfHzet=xbmcgui.Dialog()
   ybpEvQBlaDATjYrXWqoKILsJgfHzet.notification(__addonname__,sting)
  except:
   ybpEvQBlaDATjYrXWqoKILsJgfHzRt
 def addon_log(ybpEvQBlaDATjYrXWqoKILsJgfHzec,string):
  try:
   ybpEvQBlaDATjYrXWqoKILsJgfHzeU=string.encode('utf-8','ignore')
  except:
   ybpEvQBlaDATjYrXWqoKILsJgfHzeU='addonException: addon_log'
  ybpEvQBlaDATjYrXWqoKILsJgfHzeP=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,ybpEvQBlaDATjYrXWqoKILsJgfHzeU),level=ybpEvQBlaDATjYrXWqoKILsJgfHzeP)
 def get_keyboard_input(ybpEvQBlaDATjYrXWqoKILsJgfHzec,ybpEvQBlaDATjYrXWqoKILsJgfHzOc):
  ybpEvQBlaDATjYrXWqoKILsJgfHzeV=ybpEvQBlaDATjYrXWqoKILsJgfHzRt
  kb=xbmc.Keyboard()
  kb.setHeading(ybpEvQBlaDATjYrXWqoKILsJgfHzOc)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   ybpEvQBlaDATjYrXWqoKILsJgfHzeV=kb.getText()
  return ybpEvQBlaDATjYrXWqoKILsJgfHzeV
 def get_settings_account(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  ybpEvQBlaDATjYrXWqoKILsJgfHzeh =__addon__.getSetting('id')
  ybpEvQBlaDATjYrXWqoKILsJgfHzem =__addon__.getSetting('pw')
  ybpEvQBlaDATjYrXWqoKILsJgfHzei=ybpEvQBlaDATjYrXWqoKILsJgfHzRU(__addon__.getSetting('selected_profile'))
  return(ybpEvQBlaDATjYrXWqoKILsJgfHzeh,ybpEvQBlaDATjYrXWqoKILsJgfHzem,ybpEvQBlaDATjYrXWqoKILsJgfHzei)
 def get_settings_totalsearch(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  ybpEvQBlaDATjYrXWqoKILsJgfHzeN =ybpEvQBlaDATjYrXWqoKILsJgfHzRP if __addon__.getSetting('local_search')=='true' else ybpEvQBlaDATjYrXWqoKILsJgfHzRV
  ybpEvQBlaDATjYrXWqoKILsJgfHzOe=ybpEvQBlaDATjYrXWqoKILsJgfHzRP if __addon__.getSetting('local_history')=='true' else ybpEvQBlaDATjYrXWqoKILsJgfHzRV
  ybpEvQBlaDATjYrXWqoKILsJgfHzOS =ybpEvQBlaDATjYrXWqoKILsJgfHzRP if __addon__.getSetting('total_search')=='true' else ybpEvQBlaDATjYrXWqoKILsJgfHzRV
  ybpEvQBlaDATjYrXWqoKILsJgfHzOu=ybpEvQBlaDATjYrXWqoKILsJgfHzRP if __addon__.getSetting('total_history')=='true' else ybpEvQBlaDATjYrXWqoKILsJgfHzRV
  ybpEvQBlaDATjYrXWqoKILsJgfHzOG=ybpEvQBlaDATjYrXWqoKILsJgfHzRP if __addon__.getSetting('menu_bookmark')=='true' else ybpEvQBlaDATjYrXWqoKILsJgfHzRV
  return(ybpEvQBlaDATjYrXWqoKILsJgfHzeN,ybpEvQBlaDATjYrXWqoKILsJgfHzOe,ybpEvQBlaDATjYrXWqoKILsJgfHzOS,ybpEvQBlaDATjYrXWqoKILsJgfHzOu,ybpEvQBlaDATjYrXWqoKILsJgfHzOG)
 def get_settings_makebookmark(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  return ybpEvQBlaDATjYrXWqoKILsJgfHzRP if __addon__.getSetting('make_bookmark')=='true' else ybpEvQBlaDATjYrXWqoKILsJgfHzRV
 def get_selQuality(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  try:
   ybpEvQBlaDATjYrXWqoKILsJgfHzOC=['3840x2160/1','1920x1080/1','1280x720/1']
   ybpEvQBlaDATjYrXWqoKILsJgfHzOR=ybpEvQBlaDATjYrXWqoKILsJgfHzRU(__addon__.getSetting('selected_quality'))
   return ybpEvQBlaDATjYrXWqoKILsJgfHzOC[ybpEvQBlaDATjYrXWqoKILsJgfHzOR]
  except:
   ybpEvQBlaDATjYrXWqoKILsJgfHzRt
  return 1080 
 def get_settings_direct_replay(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  ybpEvQBlaDATjYrXWqoKILsJgfHzOw=ybpEvQBlaDATjYrXWqoKILsJgfHzRU(__addon__.getSetting('direct_replay'))
  if ybpEvQBlaDATjYrXWqoKILsJgfHzOw==0:
   return ybpEvQBlaDATjYrXWqoKILsJgfHzRV
  else:
   return ybpEvQBlaDATjYrXWqoKILsJgfHzRP
 def set_winEpisodeOrderby(ybpEvQBlaDATjYrXWqoKILsJgfHzec,ybpEvQBlaDATjYrXWqoKILsJgfHzOM):
  __addon__.setSetting('watcha_orderby',ybpEvQBlaDATjYrXWqoKILsJgfHzOM)
 def get_winEpisodeOrderby(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  ybpEvQBlaDATjYrXWqoKILsJgfHzOM=__addon__.getSetting('watcha_orderby')
  if ybpEvQBlaDATjYrXWqoKILsJgfHzOM in['',ybpEvQBlaDATjYrXWqoKILsJgfHzRt]:ybpEvQBlaDATjYrXWqoKILsJgfHzOM='asc'
  return ybpEvQBlaDATjYrXWqoKILsJgfHzOM
 def dp_setEpOrderby(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzOM =args.get('orderby')
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.set_winEpisodeOrderby(ybpEvQBlaDATjYrXWqoKILsJgfHzOM)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzec,label,sublabel='',img='',infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzRt,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRP,params='',isLink=ybpEvQBlaDATjYrXWqoKILsJgfHzRV,ContextMenu=ybpEvQBlaDATjYrXWqoKILsJgfHzRt):
  ybpEvQBlaDATjYrXWqoKILsJgfHzOk='%s?%s'%(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_url,urllib.parse.urlencode(params))
  if sublabel:ybpEvQBlaDATjYrXWqoKILsJgfHzOc='%s < %s >'%(label,sublabel)
  else: ybpEvQBlaDATjYrXWqoKILsJgfHzOc=label
  if not img:img='DefaultFolder.png'
  ybpEvQBlaDATjYrXWqoKILsJgfHzOd=xbmcgui.ListItem(ybpEvQBlaDATjYrXWqoKILsJgfHzOc)
  if ybpEvQBlaDATjYrXWqoKILsJgfHzRh(img)==ybpEvQBlaDATjYrXWqoKILsJgfHzRm:
   ybpEvQBlaDATjYrXWqoKILsJgfHzOd.setArt(img)
  else:
   ybpEvQBlaDATjYrXWqoKILsJgfHzOd.setArt({'thumb':img,'poster':img})
  if infoLabels:ybpEvQBlaDATjYrXWqoKILsJgfHzOd.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   ybpEvQBlaDATjYrXWqoKILsJgfHzOd.setProperty('IsPlayable','true')
  if ContextMenu:ybpEvQBlaDATjYrXWqoKILsJgfHzOd.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,ybpEvQBlaDATjYrXWqoKILsJgfHzOk,ybpEvQBlaDATjYrXWqoKILsJgfHzOd,isFolder)
 def dp_Main_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  (ybpEvQBlaDATjYrXWqoKILsJgfHzeN,ybpEvQBlaDATjYrXWqoKILsJgfHzOe,ybpEvQBlaDATjYrXWqoKILsJgfHzOS,ybpEvQBlaDATjYrXWqoKILsJgfHzOu,ybpEvQBlaDATjYrXWqoKILsJgfHzOG)=ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_settings_totalsearch()
  for ybpEvQBlaDATjYrXWqoKILsJgfHzOn in ybpEvQBlaDATjYrXWqoKILsJgfHzeS:
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc=ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('title')
   ybpEvQBlaDATjYrXWqoKILsJgfHzOF=''
   if ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('mode')=='LOCAL_SEARCH' and ybpEvQBlaDATjYrXWqoKILsJgfHzeN ==ybpEvQBlaDATjYrXWqoKILsJgfHzRV:continue
   elif ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('mode')=='SEARCH_HISTORY' and ybpEvQBlaDATjYrXWqoKILsJgfHzOe==ybpEvQBlaDATjYrXWqoKILsJgfHzRV:continue
   elif ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('mode')=='TOTAL_SEARCH' and ybpEvQBlaDATjYrXWqoKILsJgfHzOS ==ybpEvQBlaDATjYrXWqoKILsJgfHzRV:continue
   elif ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('mode')=='TOTAL_HISTORY' and ybpEvQBlaDATjYrXWqoKILsJgfHzOu==ybpEvQBlaDATjYrXWqoKILsJgfHzRV:continue
   elif ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('mode')=='MENU_BOOKMARK' and ybpEvQBlaDATjYrXWqoKILsJgfHzOG==ybpEvQBlaDATjYrXWqoKILsJgfHzRV:continue
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('mode'),'stype':ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('stype'),'api_path':ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('api_path'),'page':'1','sort':ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('sort'),'tag_id':'-'}
   if ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('mode')=='LOCAL_SEARCH':ybpEvQBlaDATjYrXWqoKILsJgfHzOx['historyyn']='Y' 
   if ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    ybpEvQBlaDATjYrXWqoKILsJgfHzOt=ybpEvQBlaDATjYrXWqoKILsJgfHzRV
    ybpEvQBlaDATjYrXWqoKILsJgfHzOU =ybpEvQBlaDATjYrXWqoKILsJgfHzRP
   else:
    ybpEvQBlaDATjYrXWqoKILsJgfHzOt=ybpEvQBlaDATjYrXWqoKILsJgfHzRP
    ybpEvQBlaDATjYrXWqoKILsJgfHzOU =ybpEvQBlaDATjYrXWqoKILsJgfHzRV
   if 'icon' in ybpEvQBlaDATjYrXWqoKILsJgfHzOn:ybpEvQBlaDATjYrXWqoKILsJgfHzOF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',ybpEvQBlaDATjYrXWqoKILsJgfHzOn.get('icon')) 
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel='',img=ybpEvQBlaDATjYrXWqoKILsJgfHzOF,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzRt,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzOt,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx,isLink=ybpEvQBlaDATjYrXWqoKILsJgfHzOU)
  xbmcplugin.endOfDirectory(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle)
 def login_main(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  (ybpEvQBlaDATjYrXWqoKILsJgfHzOV,ybpEvQBlaDATjYrXWqoKILsJgfHzOh,ybpEvQBlaDATjYrXWqoKILsJgfHzOm)=ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_settings_account()
  if not(ybpEvQBlaDATjYrXWqoKILsJgfHzOV and ybpEvQBlaDATjYrXWqoKILsJgfHzOh):
   ybpEvQBlaDATjYrXWqoKILsJgfHzet=xbmcgui.Dialog()
   ybpEvQBlaDATjYrXWqoKILsJgfHzOi=ybpEvQBlaDATjYrXWqoKILsJgfHzet.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if ybpEvQBlaDATjYrXWqoKILsJgfHzOi==ybpEvQBlaDATjYrXWqoKILsJgfHzRP:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if ybpEvQBlaDATjYrXWqoKILsJgfHzec.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   ybpEvQBlaDATjYrXWqoKILsJgfHzON=0
   while ybpEvQBlaDATjYrXWqoKILsJgfHzRP:
    ybpEvQBlaDATjYrXWqoKILsJgfHzON+=1
    time.sleep(0.05)
    if ybpEvQBlaDATjYrXWqoKILsJgfHzON>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  ybpEvQBlaDATjYrXWqoKILsJgfHzSe=ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.GetCredential(ybpEvQBlaDATjYrXWqoKILsJgfHzOV,ybpEvQBlaDATjYrXWqoKILsJgfHzOh,ybpEvQBlaDATjYrXWqoKILsJgfHzOm)
  if ybpEvQBlaDATjYrXWqoKILsJgfHzSe:ybpEvQBlaDATjYrXWqoKILsJgfHzec.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
  if ybpEvQBlaDATjYrXWqoKILsJgfHzSe==ybpEvQBlaDATjYrXWqoKILsJgfHzRV:
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_SubGroup_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzSO =args.get('stype')
  ybpEvQBlaDATjYrXWqoKILsJgfHzSu =ybpEvQBlaDATjYrXWqoKILsJgfHzRU(args.get('page'))
  ybpEvQBlaDATjYrXWqoKILsJgfHzSG =args.get('sort')
  ybpEvQBlaDATjYrXWqoKILsJgfHzSC=ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.GetSubGroupList(ybpEvQBlaDATjYrXWqoKILsJgfHzSO)
  ybpEvQBlaDATjYrXWqoKILsJgfHzSR=ybpEvQBlaDATjYrXWqoKILsJgfHzeG if ybpEvQBlaDATjYrXWqoKILsJgfHzSO=='genres' else ybpEvQBlaDATjYrXWqoKILsJgfHzeC
  ybpEvQBlaDATjYrXWqoKILsJgfHzSw=ybpEvQBlaDATjYrXWqoKILsJgfHzRi(ybpEvQBlaDATjYrXWqoKILsJgfHzSC)
  ybpEvQBlaDATjYrXWqoKILsJgfHzSM =ybpEvQBlaDATjYrXWqoKILsJgfHzRU(ybpEvQBlaDATjYrXWqoKILsJgfHzSw//(ybpEvQBlaDATjYrXWqoKILsJgfHzSR+1))+1
  ybpEvQBlaDATjYrXWqoKILsJgfHzSk =(ybpEvQBlaDATjYrXWqoKILsJgfHzSu-1)*ybpEvQBlaDATjYrXWqoKILsJgfHzSR
  for i in ybpEvQBlaDATjYrXWqoKILsJgfHzRN(ybpEvQBlaDATjYrXWqoKILsJgfHzSR):
   ybpEvQBlaDATjYrXWqoKILsJgfHzSc=ybpEvQBlaDATjYrXWqoKILsJgfHzSk+i
   if ybpEvQBlaDATjYrXWqoKILsJgfHzSc>=ybpEvQBlaDATjYrXWqoKILsJgfHzSw:break
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc =ybpEvQBlaDATjYrXWqoKILsJgfHzSC[ybpEvQBlaDATjYrXWqoKILsJgfHzSc].get('group_name')
   ybpEvQBlaDATjYrXWqoKILsJgfHzSd =ybpEvQBlaDATjYrXWqoKILsJgfHzSC[ybpEvQBlaDATjYrXWqoKILsJgfHzSc].get('api_path')
   ybpEvQBlaDATjYrXWqoKILsJgfHzSn =ybpEvQBlaDATjYrXWqoKILsJgfHzSC[ybpEvQBlaDATjYrXWqoKILsJgfHzSc].get('tag_id')
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':'CATEGORY_LIST','api_path':ybpEvQBlaDATjYrXWqoKILsJgfHzSd,'tag_id':ybpEvQBlaDATjYrXWqoKILsJgfHzSn,'stype':ybpEvQBlaDATjYrXWqoKILsJgfHzSO,'page':'1','sort':ybpEvQBlaDATjYrXWqoKILsJgfHzSG}
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel='',img='',infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzRt,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRP,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx)
  if ybpEvQBlaDATjYrXWqoKILsJgfHzSM>ybpEvQBlaDATjYrXWqoKILsJgfHzSu:
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx={}
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['mode'] ='SUB_GROUP' 
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['stype'] =ybpEvQBlaDATjYrXWqoKILsJgfHzSO
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['api_path']=args.get('api_path')
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['page'] =ybpEvQBlaDATjYrXWqoKILsJgfHzwe(ybpEvQBlaDATjYrXWqoKILsJgfHzSu+1)
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['sort'] =ybpEvQBlaDATjYrXWqoKILsJgfHzSG
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc='[B]%s >>[/B]'%'다음 페이지'
   ybpEvQBlaDATjYrXWqoKILsJgfHzSF=ybpEvQBlaDATjYrXWqoKILsJgfHzwe(ybpEvQBlaDATjYrXWqoKILsJgfHzSu+1)
   ybpEvQBlaDATjYrXWqoKILsJgfHzOF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel=ybpEvQBlaDATjYrXWqoKILsJgfHzSF,img=ybpEvQBlaDATjYrXWqoKILsJgfHzOF,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzRt,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRP,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx)
  if ybpEvQBlaDATjYrXWqoKILsJgfHzRi(ybpEvQBlaDATjYrXWqoKILsJgfHzSC)>0:xbmcplugin.endOfDirectory(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,cacheToDisc=ybpEvQBlaDATjYrXWqoKILsJgfHzRP)
 def play_VIDEO(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzSx =args.get('movie_code')
  ybpEvQBlaDATjYrXWqoKILsJgfHzSt =args.get('season_code')
  ybpEvQBlaDATjYrXWqoKILsJgfHzOc =args.get('title')
  ybpEvQBlaDATjYrXWqoKILsJgfHzSU =args.get('thumbnail')
  ybpEvQBlaDATjYrXWqoKILsJgfHzSP =ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_selQuality()
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.addon_log(ybpEvQBlaDATjYrXWqoKILsJgfHzSx+' - '+ybpEvQBlaDATjYrXWqoKILsJgfHzSt)
  ybpEvQBlaDATjYrXWqoKILsJgfHzSV,ybpEvQBlaDATjYrXWqoKILsJgfHzSh,ybpEvQBlaDATjYrXWqoKILsJgfHzSm=ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.GetStreamingURL(ybpEvQBlaDATjYrXWqoKILsJgfHzSx,ybpEvQBlaDATjYrXWqoKILsJgfHzSP)
  if ybpEvQBlaDATjYrXWqoKILsJgfHzSV=='':
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.addon_noti(__language__(30908).encode('utf8'))
   return
  ybpEvQBlaDATjYrXWqoKILsJgfHzSi=ybpEvQBlaDATjYrXWqoKILsJgfHzSV
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.addon_log(ybpEvQBlaDATjYrXWqoKILsJgfHzSi)
  ybpEvQBlaDATjYrXWqoKILsJgfHzSN=xbmcgui.ListItem(path=ybpEvQBlaDATjYrXWqoKILsJgfHzSi)
  if ybpEvQBlaDATjYrXWqoKILsJgfHzSm:
   ybpEvQBlaDATjYrXWqoKILsJgfHzue=ybpEvQBlaDATjYrXWqoKILsJgfHzSm
   ybpEvQBlaDATjYrXWqoKILsJgfHzuO ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   ybpEvQBlaDATjYrXWqoKILsJgfHzuS ='mpd'
   ybpEvQBlaDATjYrXWqoKILsJgfHzuG ='com.widevine.alpha'
   ybpEvQBlaDATjYrXWqoKILsJgfHzuC =inputstreamhelper.Helper(ybpEvQBlaDATjYrXWqoKILsJgfHzuS,drm=ybpEvQBlaDATjYrXWqoKILsJgfHzuG)
   if ybpEvQBlaDATjYrXWqoKILsJgfHzuC.check_inputstream():
    ybpEvQBlaDATjYrXWqoKILsJgfHzuR={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+ybpEvQBlaDATjYrXWqoKILsJgfHzSx,'dt-custom-data':ybpEvQBlaDATjYrXWqoKILsJgfHzue,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    ybpEvQBlaDATjYrXWqoKILsJgfHzuw=ybpEvQBlaDATjYrXWqoKILsJgfHzuO+'|'+urllib.parse.urlencode(ybpEvQBlaDATjYrXWqoKILsJgfHzuR)+'|R{SSM}|'
    ybpEvQBlaDATjYrXWqoKILsJgfHzec.addon_log(ybpEvQBlaDATjYrXWqoKILsJgfHzuw)
    ybpEvQBlaDATjYrXWqoKILsJgfHzSN.setProperty('inputstream',ybpEvQBlaDATjYrXWqoKILsJgfHzuC.inputstream_addon)
    ybpEvQBlaDATjYrXWqoKILsJgfHzSN.setProperty('inputstream.adaptive.manifest_type',ybpEvQBlaDATjYrXWqoKILsJgfHzuS)
    ybpEvQBlaDATjYrXWqoKILsJgfHzSN.setProperty('inputstream.adaptive.license_type',ybpEvQBlaDATjYrXWqoKILsJgfHzuG)
    ybpEvQBlaDATjYrXWqoKILsJgfHzSN.setProperty('inputstream.adaptive.license_key',ybpEvQBlaDATjYrXWqoKILsJgfHzuw)
    ybpEvQBlaDATjYrXWqoKILsJgfHzSN.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.USER_AGENT))
  if ybpEvQBlaDATjYrXWqoKILsJgfHzSh:
   try:
    f=ybpEvQBlaDATjYrXWqoKILsJgfHzwO(ybpEvQBlaDATjYrXWqoKILsJgfHzeR,'w',-1,'utf-8')
    ybpEvQBlaDATjYrXWqoKILsJgfHzuM=requests.get(ybpEvQBlaDATjYrXWqoKILsJgfHzSh)
    ybpEvQBlaDATjYrXWqoKILsJgfHzuk=ybpEvQBlaDATjYrXWqoKILsJgfHzuM.content.decode('utf-8') 
    for ybpEvQBlaDATjYrXWqoKILsJgfHzuc in ybpEvQBlaDATjYrXWqoKILsJgfHzuk.splitlines():
     ybpEvQBlaDATjYrXWqoKILsJgfHzud=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',ybpEvQBlaDATjYrXWqoKILsJgfHzuc)
     f.write(ybpEvQBlaDATjYrXWqoKILsJgfHzud+'\n')
    f.close()
    ybpEvQBlaDATjYrXWqoKILsJgfHzSN.setSubtitles([ybpEvQBlaDATjYrXWqoKILsJgfHzeR,ybpEvQBlaDATjYrXWqoKILsJgfHzSh])
   except:
    ybpEvQBlaDATjYrXWqoKILsJgfHzSN.setSubtitles([ybpEvQBlaDATjYrXWqoKILsJgfHzSh])
  xbmcplugin.setResolvedUrl(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,ybpEvQBlaDATjYrXWqoKILsJgfHzRP,ybpEvQBlaDATjYrXWqoKILsJgfHzSN)
  try:
   ybpEvQBlaDATjYrXWqoKILsJgfHzSO='movie' if ybpEvQBlaDATjYrXWqoKILsJgfHzSt=='-' else 'seasons'
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'code':ybpEvQBlaDATjYrXWqoKILsJgfHzSx if ybpEvQBlaDATjYrXWqoKILsJgfHzSO=='movie' else ybpEvQBlaDATjYrXWqoKILsJgfHzSt,'img':ybpEvQBlaDATjYrXWqoKILsJgfHzSU,'title':ybpEvQBlaDATjYrXWqoKILsJgfHzOc,'videoid':ybpEvQBlaDATjYrXWqoKILsJgfHzSx}
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.Save_Watched_List(ybpEvQBlaDATjYrXWqoKILsJgfHzSO,ybpEvQBlaDATjYrXWqoKILsJgfHzOx)
  except:
   ybpEvQBlaDATjYrXWqoKILsJgfHzRt
 def srtConvert(ybpEvQBlaDATjYrXWqoKILsJgfHzec,ybpEvQBlaDATjYrXWqoKILsJgfHzuF):
  ybpEvQBlaDATjYrXWqoKILsJgfHzun=re.sub(r'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',ybpEvQBlaDATjYrXWqoKILsJgfHzuF)
  ybpEvQBlaDATjYrXWqoKILsJgfHzun=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',ybpEvQBlaDATjYrXWqoKILsJgfHzun)
  ybpEvQBlaDATjYrXWqoKILsJgfHzun=re.sub(r'(\d\d).(\d\d\d) --> (\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',ybpEvQBlaDATjYrXWqoKILsJgfHzun)
  ybpEvQBlaDATjYrXWqoKILsJgfHzun=re.sub(r'WEBVTT\n','',ybpEvQBlaDATjYrXWqoKILsJgfHzun)
  ybpEvQBlaDATjYrXWqoKILsJgfHzun=re.sub(r'Kind:[ \-\w]+\n','',ybpEvQBlaDATjYrXWqoKILsJgfHzun)
  ybpEvQBlaDATjYrXWqoKILsJgfHzun=re.sub(r'Language:[ \-\w]+\n','',ybpEvQBlaDATjYrXWqoKILsJgfHzun)
  ybpEvQBlaDATjYrXWqoKILsJgfHzun=re.sub(r'<c[.\w\d]*>','',ybpEvQBlaDATjYrXWqoKILsJgfHzun)
  ybpEvQBlaDATjYrXWqoKILsJgfHzun=re.sub(r'</c>','',ybpEvQBlaDATjYrXWqoKILsJgfHzun)
  ybpEvQBlaDATjYrXWqoKILsJgfHzun=re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>','',ybpEvQBlaDATjYrXWqoKILsJgfHzun)
  ybpEvQBlaDATjYrXWqoKILsJgfHzun=re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n','',ybpEvQBlaDATjYrXWqoKILsJgfHzun)
  ybpEvQBlaDATjYrXWqoKILsJgfHzun=re.sub(r'Style:\n##\n','',ybpEvQBlaDATjYrXWqoKILsJgfHzun)
  return ybpEvQBlaDATjYrXWqoKILsJgfHzun
 def vtt_to_srt(ybpEvQBlaDATjYrXWqoKILsJgfHzec,vttFilename,srtFilename):
  try:
   f=ybpEvQBlaDATjYrXWqoKILsJgfHzwO(vttFilename,'r',-1,'utf-8')
   ybpEvQBlaDATjYrXWqoKILsJgfHzuF=f.read()
   f.close()
   ybpEvQBlaDATjYrXWqoKILsJgfHzux=''
   ybpEvQBlaDATjYrXWqoKILsJgfHzux=ybpEvQBlaDATjYrXWqoKILsJgfHzux+ybpEvQBlaDATjYrXWqoKILsJgfHzec.srtConvert(ybpEvQBlaDATjYrXWqoKILsJgfHzuF)
   f=ybpEvQBlaDATjYrXWqoKILsJgfHzwO(srtFilename,'w',-1,'utf-8')
   f.writelines(ybpEvQBlaDATjYrXWqoKILsJgfHzwe(ybpEvQBlaDATjYrXWqoKILsJgfHzux))
   f.close()
  except:
   return ybpEvQBlaDATjYrXWqoKILsJgfHzRV
  return ybpEvQBlaDATjYrXWqoKILsJgfHzRP
 def dp_Category_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzSO =args.get('stype')
  ybpEvQBlaDATjYrXWqoKILsJgfHzSn =args.get('tag_id')
  ybpEvQBlaDATjYrXWqoKILsJgfHzSd=args.get('api_path')
  ybpEvQBlaDATjYrXWqoKILsJgfHzSu=ybpEvQBlaDATjYrXWqoKILsJgfHzRU(args.get('page'))
  ybpEvQBlaDATjYrXWqoKILsJgfHzSG =args.get('sort')
  ybpEvQBlaDATjYrXWqoKILsJgfHzut,ybpEvQBlaDATjYrXWqoKILsJgfHzuU=ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.GetCategoryList(ybpEvQBlaDATjYrXWqoKILsJgfHzSO,ybpEvQBlaDATjYrXWqoKILsJgfHzSn,ybpEvQBlaDATjYrXWqoKILsJgfHzSd,ybpEvQBlaDATjYrXWqoKILsJgfHzSu,ybpEvQBlaDATjYrXWqoKILsJgfHzSG)
  for ybpEvQBlaDATjYrXWqoKILsJgfHzuP in ybpEvQBlaDATjYrXWqoKILsJgfHzut:
   ybpEvQBlaDATjYrXWqoKILsJgfHzSx =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('code')
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('title')
   ybpEvQBlaDATjYrXWqoKILsJgfHzuV =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('content_type')
   ybpEvQBlaDATjYrXWqoKILsJgfHzuh =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('story')
   ybpEvQBlaDATjYrXWqoKILsJgfHzSU =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('thumbnail')
   ybpEvQBlaDATjYrXWqoKILsJgfHzum =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('year')
   ybpEvQBlaDATjYrXWqoKILsJgfHzui =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('film_rating_code')
   ybpEvQBlaDATjYrXWqoKILsJgfHzuN=ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('film_rating_short')
   ybpEvQBlaDATjYrXWqoKILsJgfHzGe =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('film_rating_long')
   ybpEvQBlaDATjYrXWqoKILsJgfHzGO =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('duration')
   if ybpEvQBlaDATjYrXWqoKILsJgfHzuV=='movies': 
    ybpEvQBlaDATjYrXWqoKILsJgfHzOt =ybpEvQBlaDATjYrXWqoKILsJgfHzRV
    ybpEvQBlaDATjYrXWqoKILsJgfHzGS ='MOVIE'
    ybpEvQBlaDATjYrXWqoKILsJgfHzOP =''
    ybpEvQBlaDATjYrXWqoKILsJgfHzSt='-'
    ybpEvQBlaDATjYrXWqoKILsJgfHzGu ='movie'
   else: 
    ybpEvQBlaDATjYrXWqoKILsJgfHzOt =ybpEvQBlaDATjYrXWqoKILsJgfHzRP
    ybpEvQBlaDATjYrXWqoKILsJgfHzGS ='EPISODE'
    ybpEvQBlaDATjYrXWqoKILsJgfHzOP ='' 
    ybpEvQBlaDATjYrXWqoKILsJgfHzSt=ybpEvQBlaDATjYrXWqoKILsJgfHzSx
    ybpEvQBlaDATjYrXWqoKILsJgfHzGu ='tvshow' 
   ybpEvQBlaDATjYrXWqoKILsJgfHzGC={'mediatype':ybpEvQBlaDATjYrXWqoKILsJgfHzGu,'mpaa':ybpEvQBlaDATjYrXWqoKILsJgfHzGe,'title':ybpEvQBlaDATjYrXWqoKILsJgfHzOc,'year':ybpEvQBlaDATjYrXWqoKILsJgfHzum,'duration':ybpEvQBlaDATjYrXWqoKILsJgfHzGO,'plot':ybpEvQBlaDATjYrXWqoKILsJgfHzuh}
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc+='  (%s)'%(ybpEvQBlaDATjYrXWqoKILsJgfHzum)
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':ybpEvQBlaDATjYrXWqoKILsJgfHzGS,'movie_code':ybpEvQBlaDATjYrXWqoKILsJgfHzSx,'page':'1','season_code':ybpEvQBlaDATjYrXWqoKILsJgfHzSt,'title':ybpEvQBlaDATjYrXWqoKILsJgfHzOc,'thumbnail':ybpEvQBlaDATjYrXWqoKILsJgfHzSU}
   if ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_settings_makebookmark():
    ybpEvQBlaDATjYrXWqoKILsJgfHzGR={'videoid':ybpEvQBlaDATjYrXWqoKILsJgfHzSx,'vidtype':'tvshow' if ybpEvQBlaDATjYrXWqoKILsJgfHzuV=='tv_seasons' else 'movie','vtitle':ybpEvQBlaDATjYrXWqoKILsJgfHzOc,'vsubtitle':'',}
    ybpEvQBlaDATjYrXWqoKILsJgfHzGw=json.dumps(ybpEvQBlaDATjYrXWqoKILsJgfHzGR)
    ybpEvQBlaDATjYrXWqoKILsJgfHzGw=urllib.parse.quote(ybpEvQBlaDATjYrXWqoKILsJgfHzGw)
    ybpEvQBlaDATjYrXWqoKILsJgfHzGM='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(ybpEvQBlaDATjYrXWqoKILsJgfHzGw)
    ybpEvQBlaDATjYrXWqoKILsJgfHzGk=[('(통합) 찜 영상에 추가',ybpEvQBlaDATjYrXWqoKILsJgfHzGM)]
   else:
    ybpEvQBlaDATjYrXWqoKILsJgfHzGk=ybpEvQBlaDATjYrXWqoKILsJgfHzRt
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel=ybpEvQBlaDATjYrXWqoKILsJgfHzOP,img=ybpEvQBlaDATjYrXWqoKILsJgfHzSU,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzGC,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzOt,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx,ContextMenu=ybpEvQBlaDATjYrXWqoKILsJgfHzGk)
  if ybpEvQBlaDATjYrXWqoKILsJgfHzuU:
   if ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.GetCategoryList_morepage(ybpEvQBlaDATjYrXWqoKILsJgfHzSO,ybpEvQBlaDATjYrXWqoKILsJgfHzSn,ybpEvQBlaDATjYrXWqoKILsJgfHzSd,ybpEvQBlaDATjYrXWqoKILsJgfHzSu+1,ybpEvQBlaDATjYrXWqoKILsJgfHzSG):
    ybpEvQBlaDATjYrXWqoKILsJgfHzOx={}
    ybpEvQBlaDATjYrXWqoKILsJgfHzOx['mode'] ='CATEGORY_LIST'
    ybpEvQBlaDATjYrXWqoKILsJgfHzOx['stype'] =ybpEvQBlaDATjYrXWqoKILsJgfHzSO
    ybpEvQBlaDATjYrXWqoKILsJgfHzOx['tag_id'] =ybpEvQBlaDATjYrXWqoKILsJgfHzSn
    ybpEvQBlaDATjYrXWqoKILsJgfHzOx['api_path']=ybpEvQBlaDATjYrXWqoKILsJgfHzSd
    ybpEvQBlaDATjYrXWqoKILsJgfHzOx['page'] =ybpEvQBlaDATjYrXWqoKILsJgfHzwe(ybpEvQBlaDATjYrXWqoKILsJgfHzSu+1)
    ybpEvQBlaDATjYrXWqoKILsJgfHzOx['sort'] =ybpEvQBlaDATjYrXWqoKILsJgfHzSG
    ybpEvQBlaDATjYrXWqoKILsJgfHzOc='[B]%s >>[/B]'%'다음 페이지'
    ybpEvQBlaDATjYrXWqoKILsJgfHzSF=ybpEvQBlaDATjYrXWqoKILsJgfHzwe(ybpEvQBlaDATjYrXWqoKILsJgfHzSu+1)
    ybpEvQBlaDATjYrXWqoKILsJgfHzOF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
    ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel=ybpEvQBlaDATjYrXWqoKILsJgfHzSF,img=ybpEvQBlaDATjYrXWqoKILsJgfHzOF,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzRt,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRP,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx)
  xbmcplugin.setContent(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,'movies')
  if ybpEvQBlaDATjYrXWqoKILsJgfHzRi(ybpEvQBlaDATjYrXWqoKILsJgfHzut)>0:
   if ybpEvQBlaDATjYrXWqoKILsJgfHzSd=='arrivals/latest':
    xbmcplugin.endOfDirectory(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,cacheToDisc=ybpEvQBlaDATjYrXWqoKILsJgfHzRP)
   else:
    xbmcplugin.endOfDirectory(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,cacheToDisc=ybpEvQBlaDATjYrXWqoKILsJgfHzRV)
 def dp_Episode_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzGd=args.get('movie_code')
  ybpEvQBlaDATjYrXWqoKILsJgfHzSu =ybpEvQBlaDATjYrXWqoKILsJgfHzRU(args.get('page'))
  ybpEvQBlaDATjYrXWqoKILsJgfHzSt =args.get('season_code')
  ybpEvQBlaDATjYrXWqoKILsJgfHzut,ybpEvQBlaDATjYrXWqoKILsJgfHzuU=ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.GetEpisodoList(ybpEvQBlaDATjYrXWqoKILsJgfHzGd,ybpEvQBlaDATjYrXWqoKILsJgfHzSu,orderby=ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_winEpisodeOrderby())
  for ybpEvQBlaDATjYrXWqoKILsJgfHzuP in ybpEvQBlaDATjYrXWqoKILsJgfHzut:
   ybpEvQBlaDATjYrXWqoKILsJgfHzSx =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('code')
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('title')
   ybpEvQBlaDATjYrXWqoKILsJgfHzSU =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('thumbnail')
   ybpEvQBlaDATjYrXWqoKILsJgfHzGn =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('display_num')
   ybpEvQBlaDATjYrXWqoKILsJgfHzGF =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('season_title')
   ybpEvQBlaDATjYrXWqoKILsJgfHzGx=ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('episode_number')
   ybpEvQBlaDATjYrXWqoKILsJgfHzGO =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('duration')
   ybpEvQBlaDATjYrXWqoKILsJgfHzGC={'mediatype':'episode','tvshowtitle':ybpEvQBlaDATjYrXWqoKILsJgfHzOc if ybpEvQBlaDATjYrXWqoKILsJgfHzOc!='' else ybpEvQBlaDATjYrXWqoKILsJgfHzGF,'title':'%s %s'%(ybpEvQBlaDATjYrXWqoKILsJgfHzGF,ybpEvQBlaDATjYrXWqoKILsJgfHzGn)if ybpEvQBlaDATjYrXWqoKILsJgfHzOc!='' else ybpEvQBlaDATjYrXWqoKILsJgfHzGn,'episode':ybpEvQBlaDATjYrXWqoKILsJgfHzGx,'duration':ybpEvQBlaDATjYrXWqoKILsJgfHzGO,'plot':'%s\n%s\n\n%s'%(ybpEvQBlaDATjYrXWqoKILsJgfHzGF,ybpEvQBlaDATjYrXWqoKILsJgfHzGn,ybpEvQBlaDATjYrXWqoKILsJgfHzOc)}
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc='(%s) %s'%(ybpEvQBlaDATjYrXWqoKILsJgfHzGn,ybpEvQBlaDATjYrXWqoKILsJgfHzOc)
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':'MOVIE','movie_code':ybpEvQBlaDATjYrXWqoKILsJgfHzSx,'season_code':ybpEvQBlaDATjYrXWqoKILsJgfHzSt,'title':'%s < %s >'%(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,ybpEvQBlaDATjYrXWqoKILsJgfHzGF),'thumbnail':ybpEvQBlaDATjYrXWqoKILsJgfHzSU}
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel=ybpEvQBlaDATjYrXWqoKILsJgfHzGF,img=ybpEvQBlaDATjYrXWqoKILsJgfHzSU,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzGC,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRV,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx)
  if ybpEvQBlaDATjYrXWqoKILsJgfHzSu==1:
   ybpEvQBlaDATjYrXWqoKILsJgfHzGC={'plot':'정렬순서를 변경합니다.'}
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx={}
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['mode'] ='ORDER_BY' 
   if ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_winEpisodeOrderby()=='desc':
    ybpEvQBlaDATjYrXWqoKILsJgfHzOc='정렬순서변경 : 최신화부터 -> 1회부터'
    ybpEvQBlaDATjYrXWqoKILsJgfHzOx['orderby']='asc'
   else:
    ybpEvQBlaDATjYrXWqoKILsJgfHzOc='정렬순서변경 : 1회부터 -> 최신화부터'
    ybpEvQBlaDATjYrXWqoKILsJgfHzOx['orderby']='desc'
   ybpEvQBlaDATjYrXWqoKILsJgfHzOF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel='',img=ybpEvQBlaDATjYrXWqoKILsJgfHzOF,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzGC,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRV,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx,isLink=ybpEvQBlaDATjYrXWqoKILsJgfHzRP)
  if ybpEvQBlaDATjYrXWqoKILsJgfHzuU:
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['mode'] ='EPISODE' 
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['movie_code']=ybpEvQBlaDATjYrXWqoKILsJgfHzGd
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['page'] =ybpEvQBlaDATjYrXWqoKILsJgfHzwe(ybpEvQBlaDATjYrXWqoKILsJgfHzSu+1)
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc='[B]%s >>[/B]'%'다음 페이지'
   ybpEvQBlaDATjYrXWqoKILsJgfHzSF=ybpEvQBlaDATjYrXWqoKILsJgfHzwe(ybpEvQBlaDATjYrXWqoKILsJgfHzSu+1)
   ybpEvQBlaDATjYrXWqoKILsJgfHzOF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel=ybpEvQBlaDATjYrXWqoKILsJgfHzSF,img=ybpEvQBlaDATjYrXWqoKILsJgfHzOF,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzRt,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRP,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx)
  xbmcplugin.setContent(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,'episodes')
  if ybpEvQBlaDATjYrXWqoKILsJgfHzRi(ybpEvQBlaDATjYrXWqoKILsJgfHzut)>0:xbmcplugin.endOfDirectory(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,cacheToDisc=ybpEvQBlaDATjYrXWqoKILsJgfHzRP)
 def dp_Search_History(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzGt=ybpEvQBlaDATjYrXWqoKILsJgfHzec.Load_List_File('search')
  for ybpEvQBlaDATjYrXWqoKILsJgfHzGU in ybpEvQBlaDATjYrXWqoKILsJgfHzGt:
   ybpEvQBlaDATjYrXWqoKILsJgfHzGP=ybpEvQBlaDATjYrXWqoKILsJgfHzRm(urllib.parse.parse_qsl(ybpEvQBlaDATjYrXWqoKILsJgfHzGU))
   ybpEvQBlaDATjYrXWqoKILsJgfHzGV=ybpEvQBlaDATjYrXWqoKILsJgfHzGP.get('skey').strip()
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':'LOCAL_SEARCH','search_key':ybpEvQBlaDATjYrXWqoKILsJgfHzGV,'page':'1','historyyn':'Y',}
   ybpEvQBlaDATjYrXWqoKILsJgfHzGh={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':ybpEvQBlaDATjYrXWqoKILsJgfHzGV,'vType':'-',}
   ybpEvQBlaDATjYrXWqoKILsJgfHzGm=urllib.parse.urlencode(ybpEvQBlaDATjYrXWqoKILsJgfHzGh)
   ybpEvQBlaDATjYrXWqoKILsJgfHzGk=[('선택된 검색어 ( %s ) 삭제'%(ybpEvQBlaDATjYrXWqoKILsJgfHzGV),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(ybpEvQBlaDATjYrXWqoKILsJgfHzGm))]
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzGV,sublabel='',img=ybpEvQBlaDATjYrXWqoKILsJgfHzRt,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzRt,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRP,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx,ContextMenu=ybpEvQBlaDATjYrXWqoKILsJgfHzGk)
  ybpEvQBlaDATjYrXWqoKILsJgfHzGC={'plot':'검색목록 전체를 삭제합니다.'}
  ybpEvQBlaDATjYrXWqoKILsJgfHzOc='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  ybpEvQBlaDATjYrXWqoKILsJgfHzOF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel='',img=ybpEvQBlaDATjYrXWqoKILsJgfHzOF,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzGC,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRV,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx,isLink=ybpEvQBlaDATjYrXWqoKILsJgfHzRP)
  xbmcplugin.endOfDirectory(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,cacheToDisc=ybpEvQBlaDATjYrXWqoKILsJgfHzRV)
 def dp_Search_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzSu =ybpEvQBlaDATjYrXWqoKILsJgfHzRU(args.get('page'))
  if 'search_key' in args:
   ybpEvQBlaDATjYrXWqoKILsJgfHzGi=args.get('search_key')
  else:
   ybpEvQBlaDATjYrXWqoKILsJgfHzGi=ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not ybpEvQBlaDATjYrXWqoKILsJgfHzGi:
    return
  ybpEvQBlaDATjYrXWqoKILsJgfHzut,ybpEvQBlaDATjYrXWqoKILsJgfHzuU=ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.GetSearchList(ybpEvQBlaDATjYrXWqoKILsJgfHzGi,ybpEvQBlaDATjYrXWqoKILsJgfHzSu)
  for ybpEvQBlaDATjYrXWqoKILsJgfHzuP in ybpEvQBlaDATjYrXWqoKILsJgfHzut:
   ybpEvQBlaDATjYrXWqoKILsJgfHzSx =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('code')
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('title')
   ybpEvQBlaDATjYrXWqoKILsJgfHzuV=ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('content_type')
   ybpEvQBlaDATjYrXWqoKILsJgfHzuh =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('story')
   ybpEvQBlaDATjYrXWqoKILsJgfHzSU =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('thumbnail')
   ybpEvQBlaDATjYrXWqoKILsJgfHzum =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('year')
   ybpEvQBlaDATjYrXWqoKILsJgfHzui =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('film_rating_code')
   ybpEvQBlaDATjYrXWqoKILsJgfHzuN=ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('film_rating_short')
   ybpEvQBlaDATjYrXWqoKILsJgfHzGe =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('film_rating_long')
   ybpEvQBlaDATjYrXWqoKILsJgfHzGO =ybpEvQBlaDATjYrXWqoKILsJgfHzuP.get('duration')
   if ybpEvQBlaDATjYrXWqoKILsJgfHzuV=='movies': 
    ybpEvQBlaDATjYrXWqoKILsJgfHzOt =ybpEvQBlaDATjYrXWqoKILsJgfHzRV
    ybpEvQBlaDATjYrXWqoKILsJgfHzGS ='MOVIE'
    ybpEvQBlaDATjYrXWqoKILsJgfHzOP =''
    ybpEvQBlaDATjYrXWqoKILsJgfHzSt='-'
    ybpEvQBlaDATjYrXWqoKILsJgfHzGu ='movie'
   else: 
    ybpEvQBlaDATjYrXWqoKILsJgfHzOt =ybpEvQBlaDATjYrXWqoKILsJgfHzRP
    ybpEvQBlaDATjYrXWqoKILsJgfHzGS ='EPISODE'
    ybpEvQBlaDATjYrXWqoKILsJgfHzOP ='' 
    ybpEvQBlaDATjYrXWqoKILsJgfHzSt=ybpEvQBlaDATjYrXWqoKILsJgfHzSx
    ybpEvQBlaDATjYrXWqoKILsJgfHzGu ='tvshow' 
   ybpEvQBlaDATjYrXWqoKILsJgfHzGC={'mediatype':ybpEvQBlaDATjYrXWqoKILsJgfHzGu,'mpaa':ybpEvQBlaDATjYrXWqoKILsJgfHzGe,'title':ybpEvQBlaDATjYrXWqoKILsJgfHzOc,'year':ybpEvQBlaDATjYrXWqoKILsJgfHzum,'duration':ybpEvQBlaDATjYrXWqoKILsJgfHzGO,'plot':ybpEvQBlaDATjYrXWqoKILsJgfHzuh}
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc+='  (%s)'%(ybpEvQBlaDATjYrXWqoKILsJgfHzum)
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':ybpEvQBlaDATjYrXWqoKILsJgfHzGS,'movie_code':ybpEvQBlaDATjYrXWqoKILsJgfHzSx,'page':'1','season_code':ybpEvQBlaDATjYrXWqoKILsJgfHzSt,'title':ybpEvQBlaDATjYrXWqoKILsJgfHzOc,'thumbnail':ybpEvQBlaDATjYrXWqoKILsJgfHzSU}
   if ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_settings_makebookmark():
    ybpEvQBlaDATjYrXWqoKILsJgfHzGR={'videoid':ybpEvQBlaDATjYrXWqoKILsJgfHzSx,'vidtype':'tvshow' if ybpEvQBlaDATjYrXWqoKILsJgfHzuV=='tv_seasons' else 'movie','vtitle':ybpEvQBlaDATjYrXWqoKILsJgfHzOc,'vsubtitle':'',}
    ybpEvQBlaDATjYrXWqoKILsJgfHzGw=json.dumps(ybpEvQBlaDATjYrXWqoKILsJgfHzGR)
    ybpEvQBlaDATjYrXWqoKILsJgfHzGw=urllib.parse.quote(ybpEvQBlaDATjYrXWqoKILsJgfHzGw)
    ybpEvQBlaDATjYrXWqoKILsJgfHzGM='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(ybpEvQBlaDATjYrXWqoKILsJgfHzGw)
    ybpEvQBlaDATjYrXWqoKILsJgfHzGk=[('(통합) 찜 영상에 추가',ybpEvQBlaDATjYrXWqoKILsJgfHzGM)]
   else:
    ybpEvQBlaDATjYrXWqoKILsJgfHzGk=ybpEvQBlaDATjYrXWqoKILsJgfHzRt
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel=ybpEvQBlaDATjYrXWqoKILsJgfHzOP,img=ybpEvQBlaDATjYrXWqoKILsJgfHzSU,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzGC,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzOt,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx,ContextMenu=ybpEvQBlaDATjYrXWqoKILsJgfHzGk)
  if ybpEvQBlaDATjYrXWqoKILsJgfHzuU:
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx={}
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['mode'] ='SEARCH'
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['search_key']=ybpEvQBlaDATjYrXWqoKILsJgfHzGi
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx['page'] =ybpEvQBlaDATjYrXWqoKILsJgfHzwe(ybpEvQBlaDATjYrXWqoKILsJgfHzSu+1)
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc='[B]%s >>[/B]'%'다음 페이지'
   ybpEvQBlaDATjYrXWqoKILsJgfHzSF=ybpEvQBlaDATjYrXWqoKILsJgfHzwe(ybpEvQBlaDATjYrXWqoKILsJgfHzSu+1)
   ybpEvQBlaDATjYrXWqoKILsJgfHzOF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel=ybpEvQBlaDATjYrXWqoKILsJgfHzSF,img=ybpEvQBlaDATjYrXWqoKILsJgfHzOF,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzRt,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRP,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx)
  xbmcplugin.setContent(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,'movies')
  xbmcplugin.endOfDirectory(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,cacheToDisc=ybpEvQBlaDATjYrXWqoKILsJgfHzRP)
  if args.get('historyyn')=='Y':ybpEvQBlaDATjYrXWqoKILsJgfHzec.Save_Searched_List(ybpEvQBlaDATjYrXWqoKILsJgfHzGi)
 def Delete_List_File(ybpEvQBlaDATjYrXWqoKILsJgfHzec,ybpEvQBlaDATjYrXWqoKILsJgfHzSO,skey='-'):
  if ybpEvQBlaDATjYrXWqoKILsJgfHzSO=='ALL':
   try:
    ybpEvQBlaDATjYrXWqoKILsJgfHzGN=ybpEvQBlaDATjYrXWqoKILsJgfHzek
    fp=ybpEvQBlaDATjYrXWqoKILsJgfHzwO(ybpEvQBlaDATjYrXWqoKILsJgfHzGN,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    ybpEvQBlaDATjYrXWqoKILsJgfHzRt
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzSO=='ONE':
   try:
    ybpEvQBlaDATjYrXWqoKILsJgfHzGN=ybpEvQBlaDATjYrXWqoKILsJgfHzek
    ybpEvQBlaDATjYrXWqoKILsJgfHzCe=ybpEvQBlaDATjYrXWqoKILsJgfHzec.Load_List_File('search') 
    fp=ybpEvQBlaDATjYrXWqoKILsJgfHzwO(ybpEvQBlaDATjYrXWqoKILsJgfHzGN,'w',-1,'utf-8')
    for ybpEvQBlaDATjYrXWqoKILsJgfHzCO in ybpEvQBlaDATjYrXWqoKILsJgfHzCe:
     ybpEvQBlaDATjYrXWqoKILsJgfHzCS=ybpEvQBlaDATjYrXWqoKILsJgfHzRm(urllib.parse.parse_qsl(ybpEvQBlaDATjYrXWqoKILsJgfHzCO))
     ybpEvQBlaDATjYrXWqoKILsJgfHzCu=ybpEvQBlaDATjYrXWqoKILsJgfHzCS.get('skey').strip()
     if skey!=ybpEvQBlaDATjYrXWqoKILsJgfHzCu:
      fp.write(ybpEvQBlaDATjYrXWqoKILsJgfHzCO)
    fp.close()
   except:
    ybpEvQBlaDATjYrXWqoKILsJgfHzRt
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzSO in['seasons','movie']:
   try:
    ybpEvQBlaDATjYrXWqoKILsJgfHzGN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ybpEvQBlaDATjYrXWqoKILsJgfHzSO))
    fp=ybpEvQBlaDATjYrXWqoKILsJgfHzwO(ybpEvQBlaDATjYrXWqoKILsJgfHzGN,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    ybpEvQBlaDATjYrXWqoKILsJgfHzRt
 def dp_History_Remove(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzCG=args.get('delType')
  ybpEvQBlaDATjYrXWqoKILsJgfHzCR =args.get('sKey')
  ybpEvQBlaDATjYrXWqoKILsJgfHzCw =args.get('vType')
  ybpEvQBlaDATjYrXWqoKILsJgfHzet=xbmcgui.Dialog()
  if ybpEvQBlaDATjYrXWqoKILsJgfHzCG=='SEARCH_ALL':
   ybpEvQBlaDATjYrXWqoKILsJgfHzOi=ybpEvQBlaDATjYrXWqoKILsJgfHzet.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzCG=='SEARCH_ONE':
   ybpEvQBlaDATjYrXWqoKILsJgfHzOi=ybpEvQBlaDATjYrXWqoKILsJgfHzet.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzCG=='WATCH_ALL':
   ybpEvQBlaDATjYrXWqoKILsJgfHzOi=ybpEvQBlaDATjYrXWqoKILsJgfHzet.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzCG=='WATCH_ONE':
   ybpEvQBlaDATjYrXWqoKILsJgfHzOi=ybpEvQBlaDATjYrXWqoKILsJgfHzet.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if ybpEvQBlaDATjYrXWqoKILsJgfHzOi==ybpEvQBlaDATjYrXWqoKILsJgfHzRV:sys.exit()
  if ybpEvQBlaDATjYrXWqoKILsJgfHzCG=='SEARCH_ALL':
   if os.path.isfile(ybpEvQBlaDATjYrXWqoKILsJgfHzek):os.remove(ybpEvQBlaDATjYrXWqoKILsJgfHzek)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzCG=='SEARCH_ONE':
   try:
    ybpEvQBlaDATjYrXWqoKILsJgfHzGN=ybpEvQBlaDATjYrXWqoKILsJgfHzek
    ybpEvQBlaDATjYrXWqoKILsJgfHzCe=ybpEvQBlaDATjYrXWqoKILsJgfHzec.Load_List_File('search') 
    fp=ybpEvQBlaDATjYrXWqoKILsJgfHzwO(ybpEvQBlaDATjYrXWqoKILsJgfHzGN,'w',-1,'utf-8')
    for ybpEvQBlaDATjYrXWqoKILsJgfHzCO in ybpEvQBlaDATjYrXWqoKILsJgfHzCe:
     ybpEvQBlaDATjYrXWqoKILsJgfHzCS=ybpEvQBlaDATjYrXWqoKILsJgfHzRm(urllib.parse.parse_qsl(ybpEvQBlaDATjYrXWqoKILsJgfHzCO))
     ybpEvQBlaDATjYrXWqoKILsJgfHzCu=ybpEvQBlaDATjYrXWqoKILsJgfHzCS.get('skey').strip()
     if ybpEvQBlaDATjYrXWqoKILsJgfHzCR!=ybpEvQBlaDATjYrXWqoKILsJgfHzCu:
      fp.write(ybpEvQBlaDATjYrXWqoKILsJgfHzCO)
    fp.close()
   except:
    ybpEvQBlaDATjYrXWqoKILsJgfHzRt
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzCG=='WATCH_ALL':
   ybpEvQBlaDATjYrXWqoKILsJgfHzGN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ybpEvQBlaDATjYrXWqoKILsJgfHzCw))
   if os.path.isfile(ybpEvQBlaDATjYrXWqoKILsJgfHzGN):os.remove(ybpEvQBlaDATjYrXWqoKILsJgfHzGN)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzCG=='WATCH_ONE':
   ybpEvQBlaDATjYrXWqoKILsJgfHzGN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ybpEvQBlaDATjYrXWqoKILsJgfHzCw))
   try:
    ybpEvQBlaDATjYrXWqoKILsJgfHzCe=ybpEvQBlaDATjYrXWqoKILsJgfHzec.Load_List_File(ybpEvQBlaDATjYrXWqoKILsJgfHzCw) 
    fp=ybpEvQBlaDATjYrXWqoKILsJgfHzwO(ybpEvQBlaDATjYrXWqoKILsJgfHzGN,'w',-1,'utf-8')
    for ybpEvQBlaDATjYrXWqoKILsJgfHzCO in ybpEvQBlaDATjYrXWqoKILsJgfHzCe:
     ybpEvQBlaDATjYrXWqoKILsJgfHzCS=ybpEvQBlaDATjYrXWqoKILsJgfHzRm(urllib.parse.parse_qsl(ybpEvQBlaDATjYrXWqoKILsJgfHzCO))
     ybpEvQBlaDATjYrXWqoKILsJgfHzCu=ybpEvQBlaDATjYrXWqoKILsJgfHzCS.get('code').strip()
     if ybpEvQBlaDATjYrXWqoKILsJgfHzCR!=ybpEvQBlaDATjYrXWqoKILsJgfHzCu:
      fp.write(ybpEvQBlaDATjYrXWqoKILsJgfHzCO)
    fp.close()
   except:
    ybpEvQBlaDATjYrXWqoKILsJgfHzRt
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(ybpEvQBlaDATjYrXWqoKILsJgfHzec,ybpEvQBlaDATjYrXWqoKILsJgfHzSO): 
  try:
   if ybpEvQBlaDATjYrXWqoKILsJgfHzSO=='search':
    ybpEvQBlaDATjYrXWqoKILsJgfHzGN=ybpEvQBlaDATjYrXWqoKILsJgfHzek
   elif ybpEvQBlaDATjYrXWqoKILsJgfHzSO in['seasons','movie']:
    ybpEvQBlaDATjYrXWqoKILsJgfHzGN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ybpEvQBlaDATjYrXWqoKILsJgfHzSO))
   else:
    return[]
   fp=ybpEvQBlaDATjYrXWqoKILsJgfHzwO(ybpEvQBlaDATjYrXWqoKILsJgfHzGN,'r',-1,'utf-8')
   ybpEvQBlaDATjYrXWqoKILsJgfHzCM=fp.readlines()
   fp.close()
  except:
   ybpEvQBlaDATjYrXWqoKILsJgfHzCM=[]
  return ybpEvQBlaDATjYrXWqoKILsJgfHzCM
 def Save_Watched_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec,ybpEvQBlaDATjYrXWqoKILsJgfHzSO,ybpEvQBlaDATjYrXWqoKILsJgfHzeF):
  try:
   ybpEvQBlaDATjYrXWqoKILsJgfHzCk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ybpEvQBlaDATjYrXWqoKILsJgfHzSO))
   ybpEvQBlaDATjYrXWqoKILsJgfHzCe=ybpEvQBlaDATjYrXWqoKILsJgfHzec.Load_List_File(ybpEvQBlaDATjYrXWqoKILsJgfHzSO) 
   fp=ybpEvQBlaDATjYrXWqoKILsJgfHzwO(ybpEvQBlaDATjYrXWqoKILsJgfHzCk,'w',-1,'utf-8')
   ybpEvQBlaDATjYrXWqoKILsJgfHzCc=urllib.parse.urlencode(ybpEvQBlaDATjYrXWqoKILsJgfHzeF)
   ybpEvQBlaDATjYrXWqoKILsJgfHzCc=ybpEvQBlaDATjYrXWqoKILsJgfHzCc+'\n'
   fp.write(ybpEvQBlaDATjYrXWqoKILsJgfHzCc)
   ybpEvQBlaDATjYrXWqoKILsJgfHzCd=0
   for ybpEvQBlaDATjYrXWqoKILsJgfHzCO in ybpEvQBlaDATjYrXWqoKILsJgfHzCe:
    ybpEvQBlaDATjYrXWqoKILsJgfHzCS=ybpEvQBlaDATjYrXWqoKILsJgfHzRm(urllib.parse.parse_qsl(ybpEvQBlaDATjYrXWqoKILsJgfHzCO))
    ybpEvQBlaDATjYrXWqoKILsJgfHzCn=ybpEvQBlaDATjYrXWqoKILsJgfHzeF.get('code').strip()
    ybpEvQBlaDATjYrXWqoKILsJgfHzCF=ybpEvQBlaDATjYrXWqoKILsJgfHzCS.get('code').strip()
    if ybpEvQBlaDATjYrXWqoKILsJgfHzSO=='seasons' and ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_settings_direct_replay()==ybpEvQBlaDATjYrXWqoKILsJgfHzRP:
     ybpEvQBlaDATjYrXWqoKILsJgfHzCn=ybpEvQBlaDATjYrXWqoKILsJgfHzeF.get('videoid').strip()
     ybpEvQBlaDATjYrXWqoKILsJgfHzCF=ybpEvQBlaDATjYrXWqoKILsJgfHzCS.get('videoid').strip()if ybpEvQBlaDATjYrXWqoKILsJgfHzCF!=ybpEvQBlaDATjYrXWqoKILsJgfHzRt else '-'
    if ybpEvQBlaDATjYrXWqoKILsJgfHzCn!=ybpEvQBlaDATjYrXWqoKILsJgfHzCF:
     fp.write(ybpEvQBlaDATjYrXWqoKILsJgfHzCO)
     ybpEvQBlaDATjYrXWqoKILsJgfHzCd+=1
     if ybpEvQBlaDATjYrXWqoKILsJgfHzCd>=50:break
   fp.close()
  except:
   ybpEvQBlaDATjYrXWqoKILsJgfHzRt
 def dp_Watch_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzSO =args.get('stype')
  ybpEvQBlaDATjYrXWqoKILsJgfHzOw=ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_settings_direct_replay()
  if ybpEvQBlaDATjYrXWqoKILsJgfHzSO=='-':
   for ybpEvQBlaDATjYrXWqoKILsJgfHzCx in ybpEvQBlaDATjYrXWqoKILsJgfHzeu:
    ybpEvQBlaDATjYrXWqoKILsJgfHzOc=ybpEvQBlaDATjYrXWqoKILsJgfHzCx.get('title')
    ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':ybpEvQBlaDATjYrXWqoKILsJgfHzCx.get('mode'),'stype':ybpEvQBlaDATjYrXWqoKILsJgfHzCx.get('stype')}
    ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel='',img='',infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzRt,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRP,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx)
   if ybpEvQBlaDATjYrXWqoKILsJgfHzRi(ybpEvQBlaDATjYrXWqoKILsJgfHzeu)>0:xbmcplugin.endOfDirectory(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle)
  else:
   ybpEvQBlaDATjYrXWqoKILsJgfHzCt=ybpEvQBlaDATjYrXWqoKILsJgfHzec.Load_List_File(ybpEvQBlaDATjYrXWqoKILsJgfHzSO)
   for ybpEvQBlaDATjYrXWqoKILsJgfHzCU in ybpEvQBlaDATjYrXWqoKILsJgfHzCt:
    ybpEvQBlaDATjYrXWqoKILsJgfHzGP=ybpEvQBlaDATjYrXWqoKILsJgfHzRm(urllib.parse.parse_qsl(ybpEvQBlaDATjYrXWqoKILsJgfHzCU))
    ybpEvQBlaDATjYrXWqoKILsJgfHzSx=ybpEvQBlaDATjYrXWqoKILsJgfHzGP.get('code').strip()
    ybpEvQBlaDATjYrXWqoKILsJgfHzOc =ybpEvQBlaDATjYrXWqoKILsJgfHzGP.get('title').strip()
    ybpEvQBlaDATjYrXWqoKILsJgfHzSU =ybpEvQBlaDATjYrXWqoKILsJgfHzGP.get('img').strip()
    ybpEvQBlaDATjYrXWqoKILsJgfHzCP =ybpEvQBlaDATjYrXWqoKILsJgfHzGP.get('videoid').strip()
    try:
     ybpEvQBlaDATjYrXWqoKILsJgfHzSU=ybpEvQBlaDATjYrXWqoKILsJgfHzSU.replace('\'','\"')
     ybpEvQBlaDATjYrXWqoKILsJgfHzSU=json.loads(ybpEvQBlaDATjYrXWqoKILsJgfHzSU)
    except:
     ybpEvQBlaDATjYrXWqoKILsJgfHzRt
    ybpEvQBlaDATjYrXWqoKILsJgfHzGC={}
    ybpEvQBlaDATjYrXWqoKILsJgfHzGC['plot']=ybpEvQBlaDATjYrXWqoKILsJgfHzOc
    if ybpEvQBlaDATjYrXWqoKILsJgfHzSO=='movie':
     ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':'MOVIE','page':'1','movie_code':ybpEvQBlaDATjYrXWqoKILsJgfHzSx,'season_code':'-','title':ybpEvQBlaDATjYrXWqoKILsJgfHzOc,'thumbnail':ybpEvQBlaDATjYrXWqoKILsJgfHzSU}
     ybpEvQBlaDATjYrXWqoKILsJgfHzOt=ybpEvQBlaDATjYrXWqoKILsJgfHzRV
    else:
     if ybpEvQBlaDATjYrXWqoKILsJgfHzOw==ybpEvQBlaDATjYrXWqoKILsJgfHzRV or ybpEvQBlaDATjYrXWqoKILsJgfHzCP==ybpEvQBlaDATjYrXWqoKILsJgfHzRt:
      ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':'EPISODE','page':'1','movie_code':ybpEvQBlaDATjYrXWqoKILsJgfHzSx,'season_code':ybpEvQBlaDATjYrXWqoKILsJgfHzSx,'title':ybpEvQBlaDATjYrXWqoKILsJgfHzOc,'thumbnail':ybpEvQBlaDATjYrXWqoKILsJgfHzSU}
      ybpEvQBlaDATjYrXWqoKILsJgfHzOt=ybpEvQBlaDATjYrXWqoKILsJgfHzRP
     else:
      ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':'MOVIE','movie_code':ybpEvQBlaDATjYrXWqoKILsJgfHzCP,'season_code':ybpEvQBlaDATjYrXWqoKILsJgfHzSx,'title':ybpEvQBlaDATjYrXWqoKILsJgfHzOc,'thumbnail':ybpEvQBlaDATjYrXWqoKILsJgfHzSU}
      ybpEvQBlaDATjYrXWqoKILsJgfHzOt=ybpEvQBlaDATjYrXWqoKILsJgfHzRV
    ybpEvQBlaDATjYrXWqoKILsJgfHzGh={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':ybpEvQBlaDATjYrXWqoKILsJgfHzSx,'vType':ybpEvQBlaDATjYrXWqoKILsJgfHzSO,}
    ybpEvQBlaDATjYrXWqoKILsJgfHzGm=urllib.parse.urlencode(ybpEvQBlaDATjYrXWqoKILsJgfHzGh)
    ybpEvQBlaDATjYrXWqoKILsJgfHzGk=[('선택된 시청이력 ( %s ) 삭제'%(ybpEvQBlaDATjYrXWqoKILsJgfHzOc),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(ybpEvQBlaDATjYrXWqoKILsJgfHzGm))]
    ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel='',img=ybpEvQBlaDATjYrXWqoKILsJgfHzSU,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzGC,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzOt,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx,ContextMenu=ybpEvQBlaDATjYrXWqoKILsJgfHzGk)
   ybpEvQBlaDATjYrXWqoKILsJgfHzGC={'plot':'시청목록을 삭제합니다.'}
   ybpEvQBlaDATjYrXWqoKILsJgfHzOc='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   ybpEvQBlaDATjYrXWqoKILsJgfHzOx={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':ybpEvQBlaDATjYrXWqoKILsJgfHzSO,}
   ybpEvQBlaDATjYrXWqoKILsJgfHzOF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.add_dir(ybpEvQBlaDATjYrXWqoKILsJgfHzOc,sublabel='',img=ybpEvQBlaDATjYrXWqoKILsJgfHzOF,infoLabels=ybpEvQBlaDATjYrXWqoKILsJgfHzGC,isFolder=ybpEvQBlaDATjYrXWqoKILsJgfHzRV,params=ybpEvQBlaDATjYrXWqoKILsJgfHzOx,isLink=ybpEvQBlaDATjYrXWqoKILsJgfHzRP)
   if ybpEvQBlaDATjYrXWqoKILsJgfHzSO=='movie':xbmcplugin.setContent(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,'movies')
   else:xbmcplugin.setContent(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(ybpEvQBlaDATjYrXWqoKILsJgfHzec._addon_handle,cacheToDisc=ybpEvQBlaDATjYrXWqoKILsJgfHzRV)
 def Save_Searched_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec,ybpEvQBlaDATjYrXWqoKILsJgfHzGi):
  try:
   ybpEvQBlaDATjYrXWqoKILsJgfHzCV=ybpEvQBlaDATjYrXWqoKILsJgfHzek
   ybpEvQBlaDATjYrXWqoKILsJgfHzCe=ybpEvQBlaDATjYrXWqoKILsJgfHzec.Load_List_File('search') 
   ybpEvQBlaDATjYrXWqoKILsJgfHzCh={'skey':ybpEvQBlaDATjYrXWqoKILsJgfHzGi.strip()}
   fp=ybpEvQBlaDATjYrXWqoKILsJgfHzwO(ybpEvQBlaDATjYrXWqoKILsJgfHzCV,'w',-1,'utf-8')
   ybpEvQBlaDATjYrXWqoKILsJgfHzCc=urllib.parse.urlencode(ybpEvQBlaDATjYrXWqoKILsJgfHzCh)
   ybpEvQBlaDATjYrXWqoKILsJgfHzCc=ybpEvQBlaDATjYrXWqoKILsJgfHzCc+'\n'
   fp.write(ybpEvQBlaDATjYrXWqoKILsJgfHzCc)
   ybpEvQBlaDATjYrXWqoKILsJgfHzCd=0
   for ybpEvQBlaDATjYrXWqoKILsJgfHzCO in ybpEvQBlaDATjYrXWqoKILsJgfHzCe:
    ybpEvQBlaDATjYrXWqoKILsJgfHzCS=ybpEvQBlaDATjYrXWqoKILsJgfHzRm(urllib.parse.parse_qsl(ybpEvQBlaDATjYrXWqoKILsJgfHzCO))
    ybpEvQBlaDATjYrXWqoKILsJgfHzCn=ybpEvQBlaDATjYrXWqoKILsJgfHzCh.get('skey').strip()
    ybpEvQBlaDATjYrXWqoKILsJgfHzCF=ybpEvQBlaDATjYrXWqoKILsJgfHzCS.get('skey').strip()
    if ybpEvQBlaDATjYrXWqoKILsJgfHzCn!=ybpEvQBlaDATjYrXWqoKILsJgfHzCF:
     fp.write(ybpEvQBlaDATjYrXWqoKILsJgfHzCO)
     ybpEvQBlaDATjYrXWqoKILsJgfHzCd+=1
     if ybpEvQBlaDATjYrXWqoKILsJgfHzCd>=50:break
   fp.close()
  except:
   ybpEvQBlaDATjYrXWqoKILsJgfHzRt
 def logout(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  ybpEvQBlaDATjYrXWqoKILsJgfHzet=xbmcgui.Dialog()
  ybpEvQBlaDATjYrXWqoKILsJgfHzOi=ybpEvQBlaDATjYrXWqoKILsJgfHzet.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if ybpEvQBlaDATjYrXWqoKILsJgfHzOi==ybpEvQBlaDATjYrXWqoKILsJgfHzRV:sys.exit()
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.Init_WC_Total()
  if os.path.isfile(ybpEvQBlaDATjYrXWqoKILsJgfHzeM):os.remove(ybpEvQBlaDATjYrXWqoKILsJgfHzeM)
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  ybpEvQBlaDATjYrXWqoKILsJgfHzCm =ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.Get_Now_Datetime()
  ybpEvQBlaDATjYrXWqoKILsJgfHzCi=ybpEvQBlaDATjYrXWqoKILsJgfHzCm+datetime.timedelta(days=ybpEvQBlaDATjYrXWqoKILsJgfHzRU(__addon__.getSetting('cache_ttl')))
  (ybpEvQBlaDATjYrXWqoKILsJgfHzOV,ybpEvQBlaDATjYrXWqoKILsJgfHzOh,ybpEvQBlaDATjYrXWqoKILsJgfHzOm)=ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_settings_account()
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.Save_session_acount(ybpEvQBlaDATjYrXWqoKILsJgfHzOV,ybpEvQBlaDATjYrXWqoKILsJgfHzOh,ybpEvQBlaDATjYrXWqoKILsJgfHzOm)
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.WC['account']['token_limit']=ybpEvQBlaDATjYrXWqoKILsJgfHzCi.strftime('%Y%m%d')
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.JsonFile_Save(ybpEvQBlaDATjYrXWqoKILsJgfHzeM,ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.WC)
 def cookiefile_check(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.WC=ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.JsonFile_Load(ybpEvQBlaDATjYrXWqoKILsJgfHzeM)
  if 'account' not in ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.WC:
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.Init_WC_Total()
   return ybpEvQBlaDATjYrXWqoKILsJgfHzRV
  (ybpEvQBlaDATjYrXWqoKILsJgfHzCN,ybpEvQBlaDATjYrXWqoKILsJgfHzRe,ybpEvQBlaDATjYrXWqoKILsJgfHzRO)=ybpEvQBlaDATjYrXWqoKILsJgfHzec.get_settings_account()
  (ybpEvQBlaDATjYrXWqoKILsJgfHzRS,ybpEvQBlaDATjYrXWqoKILsJgfHzRu,ybpEvQBlaDATjYrXWqoKILsJgfHzRG)=ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.Load_session_acount()
  if ybpEvQBlaDATjYrXWqoKILsJgfHzCN!=ybpEvQBlaDATjYrXWqoKILsJgfHzRS or ybpEvQBlaDATjYrXWqoKILsJgfHzRe!=ybpEvQBlaDATjYrXWqoKILsJgfHzRu or ybpEvQBlaDATjYrXWqoKILsJgfHzRO!=ybpEvQBlaDATjYrXWqoKILsJgfHzRG:
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.Init_WC_Total()
   return ybpEvQBlaDATjYrXWqoKILsJgfHzRV
  if ybpEvQBlaDATjYrXWqoKILsJgfHzRU(ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))>ybpEvQBlaDATjYrXWqoKILsJgfHzRU(ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.WC['account']['token_limit']):
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.Init_WC_Total()
   return ybpEvQBlaDATjYrXWqoKILsJgfHzRV
  return ybpEvQBlaDATjYrXWqoKILsJgfHzRP
 def dp_Global_Search(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzRC=args.get('mode')
  if ybpEvQBlaDATjYrXWqoKILsJgfHzRC=='TOTAL_SEARCH':
   ybpEvQBlaDATjYrXWqoKILsJgfHzRw='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   ybpEvQBlaDATjYrXWqoKILsJgfHzRw='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(ybpEvQBlaDATjYrXWqoKILsJgfHzRw)
 def dp_Bookmark_Menu(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzRw='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(ybpEvQBlaDATjYrXWqoKILsJgfHzRw)
 def dp_Set_Bookmark(ybpEvQBlaDATjYrXWqoKILsJgfHzec,args):
  ybpEvQBlaDATjYrXWqoKILsJgfHzRM=urllib.parse.unquote(args.get('bm_param'))
  ybpEvQBlaDATjYrXWqoKILsJgfHzRM=json.loads(ybpEvQBlaDATjYrXWqoKILsJgfHzRM)
  ybpEvQBlaDATjYrXWqoKILsJgfHzCP =ybpEvQBlaDATjYrXWqoKILsJgfHzRM.get('videoid')
  ybpEvQBlaDATjYrXWqoKILsJgfHzRk =ybpEvQBlaDATjYrXWqoKILsJgfHzRM.get('vidtype')
  ybpEvQBlaDATjYrXWqoKILsJgfHzRc =ybpEvQBlaDATjYrXWqoKILsJgfHzRM.get('vtitle')
  ybpEvQBlaDATjYrXWqoKILsJgfHzRd =ybpEvQBlaDATjYrXWqoKILsJgfHzRM.get('vsubtitle')
  ybpEvQBlaDATjYrXWqoKILsJgfHzet=xbmcgui.Dialog()
  ybpEvQBlaDATjYrXWqoKILsJgfHzOi=ybpEvQBlaDATjYrXWqoKILsJgfHzet.yesno(__language__(30913).encode('utf8'),ybpEvQBlaDATjYrXWqoKILsJgfHzRc+' \n\n'+__language__(30914))
  if ybpEvQBlaDATjYrXWqoKILsJgfHzOi==ybpEvQBlaDATjYrXWqoKILsJgfHzRV:return
  ybpEvQBlaDATjYrXWqoKILsJgfHzRn=ybpEvQBlaDATjYrXWqoKILsJgfHzec.WatchaObj.GetBookmarkInfo(ybpEvQBlaDATjYrXWqoKILsJgfHzCP,ybpEvQBlaDATjYrXWqoKILsJgfHzRk)
  ybpEvQBlaDATjYrXWqoKILsJgfHzRF=json.dumps(ybpEvQBlaDATjYrXWqoKILsJgfHzRn)
  ybpEvQBlaDATjYrXWqoKILsJgfHzRF=urllib.parse.quote(ybpEvQBlaDATjYrXWqoKILsJgfHzRF)
  ybpEvQBlaDATjYrXWqoKILsJgfHzGM ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(ybpEvQBlaDATjYrXWqoKILsJgfHzRF)
  xbmc.executebuiltin(ybpEvQBlaDATjYrXWqoKILsJgfHzGM)
 def watcha_main(ybpEvQBlaDATjYrXWqoKILsJgfHzec):
  ybpEvQBlaDATjYrXWqoKILsJgfHzRC=ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params.get('mode',ybpEvQBlaDATjYrXWqoKILsJgfHzRt)
  if ybpEvQBlaDATjYrXWqoKILsJgfHzRC=='LOGOUT':
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.logout()
   return
  ybpEvQBlaDATjYrXWqoKILsJgfHzec.login_main()
  if ybpEvQBlaDATjYrXWqoKILsJgfHzRC is ybpEvQBlaDATjYrXWqoKILsJgfHzRt:
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_Main_List()
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC=='SUB_GROUP':
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_SubGroup_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC=='CATEGORY_LIST':
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_Category_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC=='EPISODE':
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_Episode_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC=='ORDER_BY':
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_setEpOrderby(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC in['SEARCH','LOCAL_SEARCH']:
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_Search_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC=='MOVIE':
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.play_VIDEO(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC=='WATCH':
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_Watch_List(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_History_Remove(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC in['TOTAL_SEARCH','TOTAL_HISTORY']:
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_Global_Search(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC=='SEARCH_HISTORY':
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_Search_History(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC=='MENU_BOOKMARK':
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_Bookmark_Menu(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  elif ybpEvQBlaDATjYrXWqoKILsJgfHzRC=='SET_BOOKMARK':
   ybpEvQBlaDATjYrXWqoKILsJgfHzec.dp_Set_Bookmark(ybpEvQBlaDATjYrXWqoKILsJgfHzec.main_params)
  else:
   ybpEvQBlaDATjYrXWqoKILsJgfHzRt
# Created by pyminifier (https://github.com/liftoff/pyminifier)
