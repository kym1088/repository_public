__author__="NightRain"
eNIdHQubrWPlzLfpmKGBnjDEigxsaR=object
eNIdHQubrWPlzLfpmKGBnjDEigxsaV=None
eNIdHQubrWPlzLfpmKGBnjDEigxsaJ=int
eNIdHQubrWPlzLfpmKGBnjDEigxsah=True
eNIdHQubrWPlzLfpmKGBnjDEigxsaX=False
eNIdHQubrWPlzLfpmKGBnjDEigxsac=type
eNIdHQubrWPlzLfpmKGBnjDEigxsat=dict
eNIdHQubrWPlzLfpmKGBnjDEigxsaT=len
eNIdHQubrWPlzLfpmKGBnjDEigxsak=range
eNIdHQubrWPlzLfpmKGBnjDEigxsaS=str
eNIdHQubrWPlzLfpmKGBnjDEigxsaC=open
eNIdHQubrWPlzLfpmKGBnjDEigxsaY=Exception
eNIdHQubrWPlzLfpmKGBnjDEigxsaM=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
eNIdHQubrWPlzLfpmKGBnjDEigxswO=[{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409','sort':'-'},{'title':'최고 인기 시리즈','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/410','sort':'-'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest','sort':'-'},{'title':'이어보기','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings','sort':'-'},{'title':'장르별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'2'},{'title':'특징별 분류 (평균별점순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'2'},{'title':'장르별 분류 (추천순)','mode':'SUB_GROUP','stype':'genres','api_path':'-','sort':'1'},{'title':'특징별 분류 (추천순)','mode':'SUB_GROUP','stype':'tags','api_path':'-','sort':'1'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-','sort':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','api_path':'-','sort':'-','icon':'history.png'},{'title':'검색 (왓챠)','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','sort':'-','icon':'search.png'},{'title':'통합검색 이력','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','sort':'-','icon':'search_history.png'}]
eNIdHQubrWPlzLfpmKGBnjDEigxswo=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
eNIdHQubrWPlzLfpmKGBnjDEigxswy=40
eNIdHQubrWPlzLfpmKGBnjDEigxswa =20
eNIdHQubrWPlzLfpmKGBnjDEigxswq =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
eNIdHQubrWPlzLfpmKGBnjDEigxswR=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
from watchaCore import*
class eNIdHQubrWPlzLfpmKGBnjDEigxswF(eNIdHQubrWPlzLfpmKGBnjDEigxsaR):
 def __init__(eNIdHQubrWPlzLfpmKGBnjDEigxswV,eNIdHQubrWPlzLfpmKGBnjDEigxswJ,eNIdHQubrWPlzLfpmKGBnjDEigxswh,eNIdHQubrWPlzLfpmKGBnjDEigxswX):
  eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_url =eNIdHQubrWPlzLfpmKGBnjDEigxswJ
  eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle=eNIdHQubrWPlzLfpmKGBnjDEigxswh
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.main_params =eNIdHQubrWPlzLfpmKGBnjDEigxswX
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj =SyesDdQokqTfHXnNBhIitFxuVWLlGM() 
 def addon_noti(eNIdHQubrWPlzLfpmKGBnjDEigxswV,sting):
  try:
   eNIdHQubrWPlzLfpmKGBnjDEigxswt=xbmcgui.Dialog()
   eNIdHQubrWPlzLfpmKGBnjDEigxswt.notification(__addonname__,sting)
  except:
   eNIdHQubrWPlzLfpmKGBnjDEigxsaV
 def addon_log(eNIdHQubrWPlzLfpmKGBnjDEigxswV,string):
  try:
   eNIdHQubrWPlzLfpmKGBnjDEigxswT=string.encode('utf-8','ignore')
  except:
   eNIdHQubrWPlzLfpmKGBnjDEigxswT='addonException: addon_log'
  eNIdHQubrWPlzLfpmKGBnjDEigxswk=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,eNIdHQubrWPlzLfpmKGBnjDEigxswT),level=eNIdHQubrWPlzLfpmKGBnjDEigxswk)
 def get_keyboard_input(eNIdHQubrWPlzLfpmKGBnjDEigxswV,eNIdHQubrWPlzLfpmKGBnjDEigxsFV):
  eNIdHQubrWPlzLfpmKGBnjDEigxswS=eNIdHQubrWPlzLfpmKGBnjDEigxsaV
  kb=xbmc.Keyboard()
  kb.setHeading(eNIdHQubrWPlzLfpmKGBnjDEigxsFV)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   eNIdHQubrWPlzLfpmKGBnjDEigxswS=kb.getText()
  return eNIdHQubrWPlzLfpmKGBnjDEigxswS
 def get_settings_login_info(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  eNIdHQubrWPlzLfpmKGBnjDEigxswC =__addon__.getSetting('id')
  eNIdHQubrWPlzLfpmKGBnjDEigxswY =__addon__.getSetting('pw')
  eNIdHQubrWPlzLfpmKGBnjDEigxswM=eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(__addon__.getSetting('selected_profile'))
  return(eNIdHQubrWPlzLfpmKGBnjDEigxswC,eNIdHQubrWPlzLfpmKGBnjDEigxswY,eNIdHQubrWPlzLfpmKGBnjDEigxswM)
 def get_settings_totalsearch(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  eNIdHQubrWPlzLfpmKGBnjDEigxswU =eNIdHQubrWPlzLfpmKGBnjDEigxsah if __addon__.getSetting('local_search')=='true' else eNIdHQubrWPlzLfpmKGBnjDEigxsaX
  eNIdHQubrWPlzLfpmKGBnjDEigxswv =eNIdHQubrWPlzLfpmKGBnjDEigxsah if __addon__.getSetting('total_search')=='true' else eNIdHQubrWPlzLfpmKGBnjDEigxsaX
  eNIdHQubrWPlzLfpmKGBnjDEigxswA=eNIdHQubrWPlzLfpmKGBnjDEigxsah if __addon__.getSetting('total_history')=='true' else eNIdHQubrWPlzLfpmKGBnjDEigxsaX
  return(eNIdHQubrWPlzLfpmKGBnjDEigxswU,eNIdHQubrWPlzLfpmKGBnjDEigxswv,eNIdHQubrWPlzLfpmKGBnjDEigxswA)
 def get_selQuality(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  try:
   eNIdHQubrWPlzLfpmKGBnjDEigxsFw=['3840x2160/1','1920x1080/1','1280x720/1']
   eNIdHQubrWPlzLfpmKGBnjDEigxsFO=eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(__addon__.getSetting('selected_quality'))
   return eNIdHQubrWPlzLfpmKGBnjDEigxsFw[eNIdHQubrWPlzLfpmKGBnjDEigxsFO]
  except:
   eNIdHQubrWPlzLfpmKGBnjDEigxsaV
  return 1080 
 def get_settings_direct_replay(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  eNIdHQubrWPlzLfpmKGBnjDEigxsFo=eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(__addon__.getSetting('direct_replay'))
  if eNIdHQubrWPlzLfpmKGBnjDEigxsFo==0:
   return eNIdHQubrWPlzLfpmKGBnjDEigxsaX
  else:
   return eNIdHQubrWPlzLfpmKGBnjDEigxsah
 def set_winCredential(eNIdHQubrWPlzLfpmKGBnjDEigxswV,credential):
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy=xbmcgui.Window(10000)
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_TOKEN',credential.get('watcha_token'))
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_GUIT',credential.get('watcha_guit'))
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_GUITV',credential.get('watcha_guitv'))
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_USERCD',credential.get('watcha_usercd'))
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_LOGINTIME',eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy=xbmcgui.Window(10000)
  eNIdHQubrWPlzLfpmKGBnjDEigxsFa={'watcha_token':eNIdHQubrWPlzLfpmKGBnjDEigxsFy.getProperty('WATCHA_M_TOKEN'),'watcha_guit':eNIdHQubrWPlzLfpmKGBnjDEigxsFy.getProperty('WATCHA_M_GUIT'),'watcha_guitv':eNIdHQubrWPlzLfpmKGBnjDEigxsFy.getProperty('WATCHA_M_GUITV'),'watcha_usercd':eNIdHQubrWPlzLfpmKGBnjDEigxsFy.getProperty('WATCHA_M_USERCD')}
  return eNIdHQubrWPlzLfpmKGBnjDEigxsFa
 def set_winEpisodeOrderby(eNIdHQubrWPlzLfpmKGBnjDEigxswV,eNIdHQubrWPlzLfpmKGBnjDEigxsFq):
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy=xbmcgui.Window(10000)
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_ORDERBY',eNIdHQubrWPlzLfpmKGBnjDEigxsFq)
 def get_winEpisodeOrderby(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy=xbmcgui.Window(10000)
  return eNIdHQubrWPlzLfpmKGBnjDEigxsFy.getProperty('WATCHA_M_ORDERBY')
 def dp_setEpOrderby(eNIdHQubrWPlzLfpmKGBnjDEigxswV,args):
  eNIdHQubrWPlzLfpmKGBnjDEigxsFq =args.get('orderby')
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.set_winEpisodeOrderby(eNIdHQubrWPlzLfpmKGBnjDEigxsFq)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxswV,label,sublabel='',img='',infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsaV,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsah,params='',isLink=eNIdHQubrWPlzLfpmKGBnjDEigxsaX,ContextMenu=eNIdHQubrWPlzLfpmKGBnjDEigxsaV):
  eNIdHQubrWPlzLfpmKGBnjDEigxsFR='%s?%s'%(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_url,urllib.parse.urlencode(params))
  if sublabel:eNIdHQubrWPlzLfpmKGBnjDEigxsFV='%s < %s >'%(label,sublabel)
  else: eNIdHQubrWPlzLfpmKGBnjDEigxsFV=label
  if not img:img='DefaultFolder.png'
  eNIdHQubrWPlzLfpmKGBnjDEigxsFJ=xbmcgui.ListItem(eNIdHQubrWPlzLfpmKGBnjDEigxsFV)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsac(img)==eNIdHQubrWPlzLfpmKGBnjDEigxsat:
   eNIdHQubrWPlzLfpmKGBnjDEigxsFJ.setArt(img)
  else:
   eNIdHQubrWPlzLfpmKGBnjDEigxsFJ.setArt({'thumb':img,'poster':img})
  if infoLabels:eNIdHQubrWPlzLfpmKGBnjDEigxsFJ.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   eNIdHQubrWPlzLfpmKGBnjDEigxsFJ.setProperty('IsPlayable','true')
  if ContextMenu:eNIdHQubrWPlzLfpmKGBnjDEigxsFJ.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle,eNIdHQubrWPlzLfpmKGBnjDEigxsFR,eNIdHQubrWPlzLfpmKGBnjDEigxsFJ,isFolder)
 def dp_Main_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  (eNIdHQubrWPlzLfpmKGBnjDEigxswU,eNIdHQubrWPlzLfpmKGBnjDEigxswv,eNIdHQubrWPlzLfpmKGBnjDEigxswA)=eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_settings_totalsearch()
  for eNIdHQubrWPlzLfpmKGBnjDEigxsFh in eNIdHQubrWPlzLfpmKGBnjDEigxswO:
   eNIdHQubrWPlzLfpmKGBnjDEigxsFV=eNIdHQubrWPlzLfpmKGBnjDEigxsFh.get('title')
   eNIdHQubrWPlzLfpmKGBnjDEigxsFX=''
   if eNIdHQubrWPlzLfpmKGBnjDEigxsFh.get('mode')=='LOCAL_SEARCH' and eNIdHQubrWPlzLfpmKGBnjDEigxswU ==eNIdHQubrWPlzLfpmKGBnjDEigxsaX:continue
   elif eNIdHQubrWPlzLfpmKGBnjDEigxsFh.get('mode')=='TOTAL_SEARCH' and eNIdHQubrWPlzLfpmKGBnjDEigxswv ==eNIdHQubrWPlzLfpmKGBnjDEigxsaX:continue
   elif eNIdHQubrWPlzLfpmKGBnjDEigxsFh.get('mode')=='TOTAL_HISTORY' and eNIdHQubrWPlzLfpmKGBnjDEigxswA==eNIdHQubrWPlzLfpmKGBnjDEigxsaX:continue
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc={'mode':eNIdHQubrWPlzLfpmKGBnjDEigxsFh.get('mode'),'stype':eNIdHQubrWPlzLfpmKGBnjDEigxsFh.get('stype'),'api_path':eNIdHQubrWPlzLfpmKGBnjDEigxsFh.get('api_path'),'page':'1','sort':eNIdHQubrWPlzLfpmKGBnjDEigxsFh.get('sort'),'tag_id':'-'}
   if eNIdHQubrWPlzLfpmKGBnjDEigxsFh.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY']:
    eNIdHQubrWPlzLfpmKGBnjDEigxsFt=eNIdHQubrWPlzLfpmKGBnjDEigxsaX
    eNIdHQubrWPlzLfpmKGBnjDEigxsFT =eNIdHQubrWPlzLfpmKGBnjDEigxsah
   else:
    eNIdHQubrWPlzLfpmKGBnjDEigxsFt=eNIdHQubrWPlzLfpmKGBnjDEigxsah
    eNIdHQubrWPlzLfpmKGBnjDEigxsFT =eNIdHQubrWPlzLfpmKGBnjDEigxsaX
   if 'icon' in eNIdHQubrWPlzLfpmKGBnjDEigxsFh:eNIdHQubrWPlzLfpmKGBnjDEigxsFX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',eNIdHQubrWPlzLfpmKGBnjDEigxsFh.get('icon')) 
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel='',img=eNIdHQubrWPlzLfpmKGBnjDEigxsFX,infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsaV,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsFt,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc,isLink=eNIdHQubrWPlzLfpmKGBnjDEigxsFT)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsaT(eNIdHQubrWPlzLfpmKGBnjDEigxswO)>0:xbmcplugin.endOfDirectory(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle)
 def login_main(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  (eNIdHQubrWPlzLfpmKGBnjDEigxsFS,eNIdHQubrWPlzLfpmKGBnjDEigxsFC,eNIdHQubrWPlzLfpmKGBnjDEigxsFY)=eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_settings_login_info()
  if not(eNIdHQubrWPlzLfpmKGBnjDEigxsFS and eNIdHQubrWPlzLfpmKGBnjDEigxsFC):
   eNIdHQubrWPlzLfpmKGBnjDEigxswt=xbmcgui.Dialog()
   eNIdHQubrWPlzLfpmKGBnjDEigxsFM=eNIdHQubrWPlzLfpmKGBnjDEigxswt.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if eNIdHQubrWPlzLfpmKGBnjDEigxsFM==eNIdHQubrWPlzLfpmKGBnjDEigxsah:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_winEpisodeOrderby()=='':
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.set_winEpisodeOrderby('asc')
  if eNIdHQubrWPlzLfpmKGBnjDEigxswV.cookiefile_check():return
  eNIdHQubrWPlzLfpmKGBnjDEigxsFU =eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  eNIdHQubrWPlzLfpmKGBnjDEigxsFv=xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINTIME')
  if eNIdHQubrWPlzLfpmKGBnjDEigxsFv==eNIdHQubrWPlzLfpmKGBnjDEigxsaV or eNIdHQubrWPlzLfpmKGBnjDEigxsFv=='':
   eNIdHQubrWPlzLfpmKGBnjDEigxsFv=eNIdHQubrWPlzLfpmKGBnjDEigxsaJ('19000101')
  else:
   eNIdHQubrWPlzLfpmKGBnjDEigxsFv=eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(re.sub('-','',eNIdHQubrWPlzLfpmKGBnjDEigxsFv))
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   eNIdHQubrWPlzLfpmKGBnjDEigxsFA=0
   while eNIdHQubrWPlzLfpmKGBnjDEigxsah:
    eNIdHQubrWPlzLfpmKGBnjDEigxsFA+=1
    time.sleep(0.05)
    if eNIdHQubrWPlzLfpmKGBnjDEigxsFv>=eNIdHQubrWPlzLfpmKGBnjDEigxsFU:return
    if eNIdHQubrWPlzLfpmKGBnjDEigxsFA>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  if eNIdHQubrWPlzLfpmKGBnjDEigxsFv>=eNIdHQubrWPlzLfpmKGBnjDEigxsFU:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   return
  if not eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.GetCredential(eNIdHQubrWPlzLfpmKGBnjDEigxsFS,eNIdHQubrWPlzLfpmKGBnjDEigxsFC,eNIdHQubrWPlzLfpmKGBnjDEigxsFY):
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
   sys.exit()
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.set_winCredential(eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.LoadCredential())
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
 def dp_SubGroup_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV,args):
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.SaveCredential(eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_winCredential())
  eNIdHQubrWPlzLfpmKGBnjDEigxsOw =args.get('stype')
  eNIdHQubrWPlzLfpmKGBnjDEigxsOF =eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(args.get('page'))
  eNIdHQubrWPlzLfpmKGBnjDEigxsOo =args.get('sort')
  eNIdHQubrWPlzLfpmKGBnjDEigxsOy=eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.GetSubGroupList(eNIdHQubrWPlzLfpmKGBnjDEigxsOw)
  eNIdHQubrWPlzLfpmKGBnjDEigxsOa=eNIdHQubrWPlzLfpmKGBnjDEigxswy if eNIdHQubrWPlzLfpmKGBnjDEigxsOw=='genres' else eNIdHQubrWPlzLfpmKGBnjDEigxswa
  eNIdHQubrWPlzLfpmKGBnjDEigxsOq=eNIdHQubrWPlzLfpmKGBnjDEigxsaT(eNIdHQubrWPlzLfpmKGBnjDEigxsOy)
  eNIdHQubrWPlzLfpmKGBnjDEigxsOR =eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(eNIdHQubrWPlzLfpmKGBnjDEigxsOq//(eNIdHQubrWPlzLfpmKGBnjDEigxsOa+1))+1
  eNIdHQubrWPlzLfpmKGBnjDEigxsOV =(eNIdHQubrWPlzLfpmKGBnjDEigxsOF-1)*eNIdHQubrWPlzLfpmKGBnjDEigxsOa
  for i in eNIdHQubrWPlzLfpmKGBnjDEigxsak(eNIdHQubrWPlzLfpmKGBnjDEigxsOa):
   eNIdHQubrWPlzLfpmKGBnjDEigxsOJ=eNIdHQubrWPlzLfpmKGBnjDEigxsOV+i
   if eNIdHQubrWPlzLfpmKGBnjDEigxsOJ>=eNIdHQubrWPlzLfpmKGBnjDEigxsOq:break
   eNIdHQubrWPlzLfpmKGBnjDEigxsFV =eNIdHQubrWPlzLfpmKGBnjDEigxsOy[eNIdHQubrWPlzLfpmKGBnjDEigxsOJ].get('group_name')
   eNIdHQubrWPlzLfpmKGBnjDEigxsOh =eNIdHQubrWPlzLfpmKGBnjDEigxsOy[eNIdHQubrWPlzLfpmKGBnjDEigxsOJ].get('api_path')
   eNIdHQubrWPlzLfpmKGBnjDEigxsOX =eNIdHQubrWPlzLfpmKGBnjDEigxsOy[eNIdHQubrWPlzLfpmKGBnjDEigxsOJ].get('tag_id')
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc={'mode':'CATEGORY_LIST','api_path':eNIdHQubrWPlzLfpmKGBnjDEigxsOh,'tag_id':eNIdHQubrWPlzLfpmKGBnjDEigxsOX,'stype':eNIdHQubrWPlzLfpmKGBnjDEigxsOw,'page':'1','sort':eNIdHQubrWPlzLfpmKGBnjDEigxsOo}
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel='',img='',infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsaV,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsah,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsOR>eNIdHQubrWPlzLfpmKGBnjDEigxsOF:
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc={}
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['mode'] ='SUB_GROUP' 
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['stype'] =eNIdHQubrWPlzLfpmKGBnjDEigxsOw
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['api_path']=args.get('api_path')
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['page'] =eNIdHQubrWPlzLfpmKGBnjDEigxsaS(eNIdHQubrWPlzLfpmKGBnjDEigxsOF+1)
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['sort'] =eNIdHQubrWPlzLfpmKGBnjDEigxsOo
   eNIdHQubrWPlzLfpmKGBnjDEigxsFV='[B]%s >>[/B]'%'다음 페이지'
   eNIdHQubrWPlzLfpmKGBnjDEigxsOc=eNIdHQubrWPlzLfpmKGBnjDEigxsaS(eNIdHQubrWPlzLfpmKGBnjDEigxsOF+1)
   eNIdHQubrWPlzLfpmKGBnjDEigxsFX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel=eNIdHQubrWPlzLfpmKGBnjDEigxsOc,img=eNIdHQubrWPlzLfpmKGBnjDEigxsFX,infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsaV,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsah,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsaT(eNIdHQubrWPlzLfpmKGBnjDEigxsOy)>0:xbmcplugin.endOfDirectory(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle,cacheToDisc=eNIdHQubrWPlzLfpmKGBnjDEigxsah)
 def play_VIDEO(eNIdHQubrWPlzLfpmKGBnjDEigxswV,args):
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.SaveCredential(eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_winCredential())
  eNIdHQubrWPlzLfpmKGBnjDEigxsOt =args.get('movie_code')
  eNIdHQubrWPlzLfpmKGBnjDEigxsOT =args.get('season_code')
  eNIdHQubrWPlzLfpmKGBnjDEigxsFV =args.get('title')
  eNIdHQubrWPlzLfpmKGBnjDEigxsOk =args.get('thumbnail')
  eNIdHQubrWPlzLfpmKGBnjDEigxsOS =eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_selQuality()
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.addon_log(eNIdHQubrWPlzLfpmKGBnjDEigxsOt+' - '+eNIdHQubrWPlzLfpmKGBnjDEigxsOT)
  eNIdHQubrWPlzLfpmKGBnjDEigxsOC,eNIdHQubrWPlzLfpmKGBnjDEigxsOY,eNIdHQubrWPlzLfpmKGBnjDEigxsOM=eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.GetStreamingURL(eNIdHQubrWPlzLfpmKGBnjDEigxsOt,eNIdHQubrWPlzLfpmKGBnjDEigxsOS)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsOC=='':
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.addon_noti(__language__(30908).encode('utf8'))
   return
  eNIdHQubrWPlzLfpmKGBnjDEigxsOU=eNIdHQubrWPlzLfpmKGBnjDEigxsOC
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.addon_log(eNIdHQubrWPlzLfpmKGBnjDEigxsOU)
  eNIdHQubrWPlzLfpmKGBnjDEigxsOv=xbmcgui.ListItem(path=eNIdHQubrWPlzLfpmKGBnjDEigxsOU)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsOM:
   eNIdHQubrWPlzLfpmKGBnjDEigxsOA=eNIdHQubrWPlzLfpmKGBnjDEigxsOM
   eNIdHQubrWPlzLfpmKGBnjDEigxsow ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   eNIdHQubrWPlzLfpmKGBnjDEigxsoF ='mpd'
   eNIdHQubrWPlzLfpmKGBnjDEigxsoO ='com.widevine.alpha'
   eNIdHQubrWPlzLfpmKGBnjDEigxsoy =inputstreamhelper.Helper(eNIdHQubrWPlzLfpmKGBnjDEigxsoF,drm=eNIdHQubrWPlzLfpmKGBnjDEigxsoO)
   if eNIdHQubrWPlzLfpmKGBnjDEigxsoy.check_inputstream():
    eNIdHQubrWPlzLfpmKGBnjDEigxsoa={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+eNIdHQubrWPlzLfpmKGBnjDEigxsOt,'dt-custom-data':eNIdHQubrWPlzLfpmKGBnjDEigxsOA,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream'}
    eNIdHQubrWPlzLfpmKGBnjDEigxsoq=eNIdHQubrWPlzLfpmKGBnjDEigxsow+'|'+urllib.parse.urlencode(eNIdHQubrWPlzLfpmKGBnjDEigxsoa)+'|R{SSM}|'
    eNIdHQubrWPlzLfpmKGBnjDEigxswV.addon_log(eNIdHQubrWPlzLfpmKGBnjDEigxsoq)
    eNIdHQubrWPlzLfpmKGBnjDEigxsOv.setProperty('inputstream',eNIdHQubrWPlzLfpmKGBnjDEigxsoy.inputstream_addon)
    eNIdHQubrWPlzLfpmKGBnjDEigxsOv.setProperty('inputstream.adaptive.manifest_type',eNIdHQubrWPlzLfpmKGBnjDEigxsoF)
    eNIdHQubrWPlzLfpmKGBnjDEigxsOv.setProperty('inputstream.adaptive.license_type',eNIdHQubrWPlzLfpmKGBnjDEigxsoO)
    eNIdHQubrWPlzLfpmKGBnjDEigxsOv.setProperty('inputstream.adaptive.license_key',eNIdHQubrWPlzLfpmKGBnjDEigxsoq)
    eNIdHQubrWPlzLfpmKGBnjDEigxsOv.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.USER_AGENT))
  if eNIdHQubrWPlzLfpmKGBnjDEigxsOY:
   try:
    f=eNIdHQubrWPlzLfpmKGBnjDEigxsaC(eNIdHQubrWPlzLfpmKGBnjDEigxswq,'w',-1,'utf-8')
    eNIdHQubrWPlzLfpmKGBnjDEigxsoR=requests.get(eNIdHQubrWPlzLfpmKGBnjDEigxsOY)
    eNIdHQubrWPlzLfpmKGBnjDEigxsoV=eNIdHQubrWPlzLfpmKGBnjDEigxsoR.content.decode('utf-8') 
    for eNIdHQubrWPlzLfpmKGBnjDEigxsoJ in eNIdHQubrWPlzLfpmKGBnjDEigxsoV.splitlines():
     eNIdHQubrWPlzLfpmKGBnjDEigxsoh=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',eNIdHQubrWPlzLfpmKGBnjDEigxsoJ)
     f.write(eNIdHQubrWPlzLfpmKGBnjDEigxsoh+'\n')
    f.close()
    eNIdHQubrWPlzLfpmKGBnjDEigxsOv.setSubtitles([eNIdHQubrWPlzLfpmKGBnjDEigxswq,eNIdHQubrWPlzLfpmKGBnjDEigxsOY])
   except:
    eNIdHQubrWPlzLfpmKGBnjDEigxsOv.setSubtitles([eNIdHQubrWPlzLfpmKGBnjDEigxsOY])
  xbmcplugin.setResolvedUrl(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle,eNIdHQubrWPlzLfpmKGBnjDEigxsah,eNIdHQubrWPlzLfpmKGBnjDEigxsOv)
  try:
   eNIdHQubrWPlzLfpmKGBnjDEigxsOw='movie' if eNIdHQubrWPlzLfpmKGBnjDEigxsOT=='-' else 'seasons'
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc={'code':eNIdHQubrWPlzLfpmKGBnjDEigxsOt if eNIdHQubrWPlzLfpmKGBnjDEigxsOw=='movie' else eNIdHQubrWPlzLfpmKGBnjDEigxsOT,'img':eNIdHQubrWPlzLfpmKGBnjDEigxsOk,'title':eNIdHQubrWPlzLfpmKGBnjDEigxsFV,'videoid':eNIdHQubrWPlzLfpmKGBnjDEigxsOt}
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.Save_Watched_List(eNIdHQubrWPlzLfpmKGBnjDEigxsOw,eNIdHQubrWPlzLfpmKGBnjDEigxsFc)
  except:
   eNIdHQubrWPlzLfpmKGBnjDEigxsaV
 def dp_Category_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV,args):
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.SaveCredential(eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_winCredential())
  eNIdHQubrWPlzLfpmKGBnjDEigxsOw =args.get('stype')
  eNIdHQubrWPlzLfpmKGBnjDEigxsOX =args.get('tag_id')
  eNIdHQubrWPlzLfpmKGBnjDEigxsOh=args.get('api_path')
  eNIdHQubrWPlzLfpmKGBnjDEigxsOF=eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(args.get('page'))
  eNIdHQubrWPlzLfpmKGBnjDEigxsOo =args.get('sort')
  eNIdHQubrWPlzLfpmKGBnjDEigxsoX,eNIdHQubrWPlzLfpmKGBnjDEigxsoc=eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.GetCategoryList(eNIdHQubrWPlzLfpmKGBnjDEigxsOw,eNIdHQubrWPlzLfpmKGBnjDEigxsOX,eNIdHQubrWPlzLfpmKGBnjDEigxsOh,eNIdHQubrWPlzLfpmKGBnjDEigxsOF,eNIdHQubrWPlzLfpmKGBnjDEigxsOo)
  for eNIdHQubrWPlzLfpmKGBnjDEigxsot in eNIdHQubrWPlzLfpmKGBnjDEigxsoX:
   eNIdHQubrWPlzLfpmKGBnjDEigxsOt =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('code')
   eNIdHQubrWPlzLfpmKGBnjDEigxsFV =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('title')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoT =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('content_type')
   eNIdHQubrWPlzLfpmKGBnjDEigxsok =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('story')
   eNIdHQubrWPlzLfpmKGBnjDEigxsOk =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('thumbnail')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoS =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('year')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoC =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('film_rating_code')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoY=eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('film_rating_short')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoM =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('film_rating_long')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoU =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('duration')
   if eNIdHQubrWPlzLfpmKGBnjDEigxsoT=='movies': 
    eNIdHQubrWPlzLfpmKGBnjDEigxsFt =eNIdHQubrWPlzLfpmKGBnjDEigxsaX
    eNIdHQubrWPlzLfpmKGBnjDEigxsov ='MOVIE'
    eNIdHQubrWPlzLfpmKGBnjDEigxsFk =''
    eNIdHQubrWPlzLfpmKGBnjDEigxsOT='-'
    eNIdHQubrWPlzLfpmKGBnjDEigxsoA ='movie'
   else: 
    eNIdHQubrWPlzLfpmKGBnjDEigxsFt =eNIdHQubrWPlzLfpmKGBnjDEigxsah
    eNIdHQubrWPlzLfpmKGBnjDEigxsov ='EPISODE'
    eNIdHQubrWPlzLfpmKGBnjDEigxsFk ='Series'
    eNIdHQubrWPlzLfpmKGBnjDEigxsOT=eNIdHQubrWPlzLfpmKGBnjDEigxsOt
    eNIdHQubrWPlzLfpmKGBnjDEigxsoA ='tvshow' 
   eNIdHQubrWPlzLfpmKGBnjDEigxsyw={'mediatype':eNIdHQubrWPlzLfpmKGBnjDEigxsoA,'mpaa':eNIdHQubrWPlzLfpmKGBnjDEigxsoM,'title':eNIdHQubrWPlzLfpmKGBnjDEigxsFV,'year':eNIdHQubrWPlzLfpmKGBnjDEigxsoS,'duration':eNIdHQubrWPlzLfpmKGBnjDEigxsoU,'plot':'%s (%s)\n년도 : %s\n\n%s'%(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,eNIdHQubrWPlzLfpmKGBnjDEigxsoY,eNIdHQubrWPlzLfpmKGBnjDEigxsoS,eNIdHQubrWPlzLfpmKGBnjDEigxsok)}
   if eNIdHQubrWPlzLfpmKGBnjDEigxsoC>=19:
    eNIdHQubrWPlzLfpmKGBnjDEigxsFV+='  (%s년 - %s)'%(eNIdHQubrWPlzLfpmKGBnjDEigxsoS,eNIdHQubrWPlzLfpmKGBnjDEigxsaS(eNIdHQubrWPlzLfpmKGBnjDEigxsoY))
   else:
    eNIdHQubrWPlzLfpmKGBnjDEigxsFV+='  (%s년)'%(eNIdHQubrWPlzLfpmKGBnjDEigxsoS)
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc={'mode':eNIdHQubrWPlzLfpmKGBnjDEigxsov,'movie_code':eNIdHQubrWPlzLfpmKGBnjDEigxsOt,'page':'1','season_code':eNIdHQubrWPlzLfpmKGBnjDEigxsOT,'title':eNIdHQubrWPlzLfpmKGBnjDEigxsFV,'thumbnail':eNIdHQubrWPlzLfpmKGBnjDEigxsOk}
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel=eNIdHQubrWPlzLfpmKGBnjDEigxsFk,img=eNIdHQubrWPlzLfpmKGBnjDEigxsOk,infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsyw,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsFt,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsoc:
   if eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.GetCategoryList_morepage(eNIdHQubrWPlzLfpmKGBnjDEigxsOw,eNIdHQubrWPlzLfpmKGBnjDEigxsOX,eNIdHQubrWPlzLfpmKGBnjDEigxsOh,eNIdHQubrWPlzLfpmKGBnjDEigxsOF+1,eNIdHQubrWPlzLfpmKGBnjDEigxsOo):
    eNIdHQubrWPlzLfpmKGBnjDEigxsFc={}
    eNIdHQubrWPlzLfpmKGBnjDEigxsFc['mode'] ='CATEGORY_LIST'
    eNIdHQubrWPlzLfpmKGBnjDEigxsFc['stype'] =eNIdHQubrWPlzLfpmKGBnjDEigxsOw
    eNIdHQubrWPlzLfpmKGBnjDEigxsFc['tag_id'] =eNIdHQubrWPlzLfpmKGBnjDEigxsOX
    eNIdHQubrWPlzLfpmKGBnjDEigxsFc['api_path']=eNIdHQubrWPlzLfpmKGBnjDEigxsOh
    eNIdHQubrWPlzLfpmKGBnjDEigxsFc['page'] =eNIdHQubrWPlzLfpmKGBnjDEigxsaS(eNIdHQubrWPlzLfpmKGBnjDEigxsOF+1)
    eNIdHQubrWPlzLfpmKGBnjDEigxsFc['sort'] =eNIdHQubrWPlzLfpmKGBnjDEigxsOo
    eNIdHQubrWPlzLfpmKGBnjDEigxsFV='[B]%s >>[/B]'%'다음 페이지'
    eNIdHQubrWPlzLfpmKGBnjDEigxsOc=eNIdHQubrWPlzLfpmKGBnjDEigxsaS(eNIdHQubrWPlzLfpmKGBnjDEigxsOF+1)
    eNIdHQubrWPlzLfpmKGBnjDEigxsFX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
    eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel=eNIdHQubrWPlzLfpmKGBnjDEigxsOc,img=eNIdHQubrWPlzLfpmKGBnjDEigxsFX,infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsaV,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsah,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsaT(eNIdHQubrWPlzLfpmKGBnjDEigxsoX)>0:
   if eNIdHQubrWPlzLfpmKGBnjDEigxsOh=='arrivals/latest':
    xbmcplugin.endOfDirectory(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle,cacheToDisc=eNIdHQubrWPlzLfpmKGBnjDEigxsah)
   else:
    xbmcplugin.endOfDirectory(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle,cacheToDisc=eNIdHQubrWPlzLfpmKGBnjDEigxsaX)
 def dp_Episode_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV,args):
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.SaveCredential(eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_winCredential())
  eNIdHQubrWPlzLfpmKGBnjDEigxsyO=args.get('movie_code')
  eNIdHQubrWPlzLfpmKGBnjDEigxsOF =eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(args.get('page'))
  eNIdHQubrWPlzLfpmKGBnjDEigxsOT =args.get('season_code')
  eNIdHQubrWPlzLfpmKGBnjDEigxsoX,eNIdHQubrWPlzLfpmKGBnjDEigxsoc=eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.GetEpisodoList(eNIdHQubrWPlzLfpmKGBnjDEigxsyO,eNIdHQubrWPlzLfpmKGBnjDEigxsOF,orderby=eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_winEpisodeOrderby())
  for eNIdHQubrWPlzLfpmKGBnjDEigxsot in eNIdHQubrWPlzLfpmKGBnjDEigxsoX:
   eNIdHQubrWPlzLfpmKGBnjDEigxsOt =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('code')
   eNIdHQubrWPlzLfpmKGBnjDEigxsFV =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('title')
   eNIdHQubrWPlzLfpmKGBnjDEigxsOk =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('thumbnail')
   eNIdHQubrWPlzLfpmKGBnjDEigxsyo =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('display_num')
   eNIdHQubrWPlzLfpmKGBnjDEigxsya =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('season_title')
   eNIdHQubrWPlzLfpmKGBnjDEigxsyq=eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('episode_number')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoU =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('duration')
   eNIdHQubrWPlzLfpmKGBnjDEigxsyw={'mediatype':'episode','tvshowtitle':eNIdHQubrWPlzLfpmKGBnjDEigxsFV if eNIdHQubrWPlzLfpmKGBnjDEigxsFV!='' else eNIdHQubrWPlzLfpmKGBnjDEigxsya,'title':'%s %s'%(eNIdHQubrWPlzLfpmKGBnjDEigxsya,eNIdHQubrWPlzLfpmKGBnjDEigxsyo)if eNIdHQubrWPlzLfpmKGBnjDEigxsFV!='' else eNIdHQubrWPlzLfpmKGBnjDEigxsyo,'episode':eNIdHQubrWPlzLfpmKGBnjDEigxsyq,'duration':eNIdHQubrWPlzLfpmKGBnjDEigxsoU,'plot':'%s\n%s\n\n%s'%(eNIdHQubrWPlzLfpmKGBnjDEigxsya,eNIdHQubrWPlzLfpmKGBnjDEigxsyo,eNIdHQubrWPlzLfpmKGBnjDEigxsFV)}
   eNIdHQubrWPlzLfpmKGBnjDEigxsFV='(%s) %s'%(eNIdHQubrWPlzLfpmKGBnjDEigxsyo,eNIdHQubrWPlzLfpmKGBnjDEigxsFV)
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc={'mode':'MOVIE','movie_code':eNIdHQubrWPlzLfpmKGBnjDEigxsOt,'season_code':eNIdHQubrWPlzLfpmKGBnjDEigxsOT,'title':'%s < %s >'%(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,eNIdHQubrWPlzLfpmKGBnjDEigxsya),'thumbnail':eNIdHQubrWPlzLfpmKGBnjDEigxsOk}
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel=eNIdHQubrWPlzLfpmKGBnjDEigxsya,img=eNIdHQubrWPlzLfpmKGBnjDEigxsOk,infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsyw,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsaX,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsOF==1:
   eNIdHQubrWPlzLfpmKGBnjDEigxsyw={'plot':'정렬순서를 변경합니다.'}
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc={}
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['mode'] ='ORDER_BY' 
   if eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_winEpisodeOrderby()=='desc':
    eNIdHQubrWPlzLfpmKGBnjDEigxsFV='정렬순서변경 : 최신화부터 -> 1회부터'
    eNIdHQubrWPlzLfpmKGBnjDEigxsFc['orderby']='asc'
   else:
    eNIdHQubrWPlzLfpmKGBnjDEigxsFV='정렬순서변경 : 1회부터 -> 최신화부터'
    eNIdHQubrWPlzLfpmKGBnjDEigxsFc['orderby']='desc'
   eNIdHQubrWPlzLfpmKGBnjDEigxsFX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel='',img=eNIdHQubrWPlzLfpmKGBnjDEigxsFX,infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsyw,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsaX,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc,isLink=eNIdHQubrWPlzLfpmKGBnjDEigxsah)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsoc:
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['mode'] ='EPISODE' 
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['movie_code']=eNIdHQubrWPlzLfpmKGBnjDEigxsyO
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['page'] =eNIdHQubrWPlzLfpmKGBnjDEigxsaS(eNIdHQubrWPlzLfpmKGBnjDEigxsOF+1)
   eNIdHQubrWPlzLfpmKGBnjDEigxsFV='[B]%s >>[/B]'%'다음 페이지'
   eNIdHQubrWPlzLfpmKGBnjDEigxsOc=eNIdHQubrWPlzLfpmKGBnjDEigxsaS(eNIdHQubrWPlzLfpmKGBnjDEigxsOF+1)
   eNIdHQubrWPlzLfpmKGBnjDEigxsFX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel=eNIdHQubrWPlzLfpmKGBnjDEigxsOc,img=eNIdHQubrWPlzLfpmKGBnjDEigxsFX,infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsaV,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsah,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsaT(eNIdHQubrWPlzLfpmKGBnjDEigxsoX)>0:xbmcplugin.endOfDirectory(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle,cacheToDisc=eNIdHQubrWPlzLfpmKGBnjDEigxsah)
 def dp_Search_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV,args):
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.SaveCredential(eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_winCredential())
  eNIdHQubrWPlzLfpmKGBnjDEigxsOF =eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(args.get('page'))
  if 'search_key' in args:
   eNIdHQubrWPlzLfpmKGBnjDEigxsyR=args.get('search_key')
  else:
   eNIdHQubrWPlzLfpmKGBnjDEigxsyR=eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not eNIdHQubrWPlzLfpmKGBnjDEigxsyR:
    xbmcplugin.endOfDirectory(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle)
    return
  eNIdHQubrWPlzLfpmKGBnjDEigxsoX,eNIdHQubrWPlzLfpmKGBnjDEigxsoc=eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.GetSearchList(eNIdHQubrWPlzLfpmKGBnjDEigxsyR,eNIdHQubrWPlzLfpmKGBnjDEigxsOF)
  for eNIdHQubrWPlzLfpmKGBnjDEigxsot in eNIdHQubrWPlzLfpmKGBnjDEigxsoX:
   eNIdHQubrWPlzLfpmKGBnjDEigxsOt =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('code')
   eNIdHQubrWPlzLfpmKGBnjDEigxsFV =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('title')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoT=eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('content_type')
   eNIdHQubrWPlzLfpmKGBnjDEigxsok =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('story')
   eNIdHQubrWPlzLfpmKGBnjDEigxsOk =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('thumbnail')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoS =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('year')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoC =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('film_rating_code')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoY=eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('film_rating_short')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoM =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('film_rating_long')
   eNIdHQubrWPlzLfpmKGBnjDEigxsoU =eNIdHQubrWPlzLfpmKGBnjDEigxsot.get('duration')
   if eNIdHQubrWPlzLfpmKGBnjDEigxsoT=='movies': 
    eNIdHQubrWPlzLfpmKGBnjDEigxsFt =eNIdHQubrWPlzLfpmKGBnjDEigxsaX
    eNIdHQubrWPlzLfpmKGBnjDEigxsov ='MOVIE'
    eNIdHQubrWPlzLfpmKGBnjDEigxsFk =''
    eNIdHQubrWPlzLfpmKGBnjDEigxsOT='-'
    eNIdHQubrWPlzLfpmKGBnjDEigxsoA ='movie'
   else: 
    eNIdHQubrWPlzLfpmKGBnjDEigxsFt =eNIdHQubrWPlzLfpmKGBnjDEigxsah
    eNIdHQubrWPlzLfpmKGBnjDEigxsov ='EPISODE'
    eNIdHQubrWPlzLfpmKGBnjDEigxsFk ='Series'
    eNIdHQubrWPlzLfpmKGBnjDEigxsOT=eNIdHQubrWPlzLfpmKGBnjDEigxsOt
    eNIdHQubrWPlzLfpmKGBnjDEigxsoA ='tvshow' 
   eNIdHQubrWPlzLfpmKGBnjDEigxsyw={'mediatype':eNIdHQubrWPlzLfpmKGBnjDEigxsoA,'mpaa':eNIdHQubrWPlzLfpmKGBnjDEigxsoM,'title':eNIdHQubrWPlzLfpmKGBnjDEigxsFV,'year':eNIdHQubrWPlzLfpmKGBnjDEigxsoS,'duration':eNIdHQubrWPlzLfpmKGBnjDEigxsoU,'plot':'%s (%s)\n년도 : %s\n\n%s'%(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,eNIdHQubrWPlzLfpmKGBnjDEigxsoY,eNIdHQubrWPlzLfpmKGBnjDEigxsoS,eNIdHQubrWPlzLfpmKGBnjDEigxsok)}
   if eNIdHQubrWPlzLfpmKGBnjDEigxsoC>=19:
    eNIdHQubrWPlzLfpmKGBnjDEigxsFV+='  (%s년 - %s)'%(eNIdHQubrWPlzLfpmKGBnjDEigxsoS,eNIdHQubrWPlzLfpmKGBnjDEigxsaS(eNIdHQubrWPlzLfpmKGBnjDEigxsoY))
   else:
    eNIdHQubrWPlzLfpmKGBnjDEigxsFV+='  (%s년)'%(eNIdHQubrWPlzLfpmKGBnjDEigxsoS)
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc={'mode':eNIdHQubrWPlzLfpmKGBnjDEigxsov,'movie_code':eNIdHQubrWPlzLfpmKGBnjDEigxsOt,'page':'1','season_code':eNIdHQubrWPlzLfpmKGBnjDEigxsOT,'title':eNIdHQubrWPlzLfpmKGBnjDEigxsFV,'thumbnail':eNIdHQubrWPlzLfpmKGBnjDEigxsOk}
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel=eNIdHQubrWPlzLfpmKGBnjDEigxsFk,img=eNIdHQubrWPlzLfpmKGBnjDEigxsOk,infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsyw,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsFt,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsoc:
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc={}
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['mode'] ='SEARCH'
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['search_key']=eNIdHQubrWPlzLfpmKGBnjDEigxsyR
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc['page'] =eNIdHQubrWPlzLfpmKGBnjDEigxsaS(eNIdHQubrWPlzLfpmKGBnjDEigxsOF+1)
   eNIdHQubrWPlzLfpmKGBnjDEigxsFV='[B]%s >>[/B]'%'다음 페이지'
   eNIdHQubrWPlzLfpmKGBnjDEigxsOc=eNIdHQubrWPlzLfpmKGBnjDEigxsaS(eNIdHQubrWPlzLfpmKGBnjDEigxsOF+1)
   eNIdHQubrWPlzLfpmKGBnjDEigxsFX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel=eNIdHQubrWPlzLfpmKGBnjDEigxsOc,img=eNIdHQubrWPlzLfpmKGBnjDEigxsFX,infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsaV,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsah,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc)
  xbmcplugin.endOfDirectory(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle,cacheToDisc=eNIdHQubrWPlzLfpmKGBnjDEigxsaX)
 def Delete_Watched_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV,eNIdHQubrWPlzLfpmKGBnjDEigxsOw):
  try:
   eNIdHQubrWPlzLfpmKGBnjDEigxsyV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eNIdHQubrWPlzLfpmKGBnjDEigxsOw))
   fp=eNIdHQubrWPlzLfpmKGBnjDEigxsaC(eNIdHQubrWPlzLfpmKGBnjDEigxsyV,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   eNIdHQubrWPlzLfpmKGBnjDEigxsaV
 def dp_WatchList_Delete(eNIdHQubrWPlzLfpmKGBnjDEigxswV,args):
  eNIdHQubrWPlzLfpmKGBnjDEigxsOw=args.get('stype')
  eNIdHQubrWPlzLfpmKGBnjDEigxswt=xbmcgui.Dialog()
  eNIdHQubrWPlzLfpmKGBnjDEigxsFM=eNIdHQubrWPlzLfpmKGBnjDEigxswt.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if eNIdHQubrWPlzLfpmKGBnjDEigxsFM==eNIdHQubrWPlzLfpmKGBnjDEigxsaX:sys.exit()
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.Delete_Watched_List(eNIdHQubrWPlzLfpmKGBnjDEigxsOw)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV,eNIdHQubrWPlzLfpmKGBnjDEigxsOw):
  try:
   eNIdHQubrWPlzLfpmKGBnjDEigxsyV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eNIdHQubrWPlzLfpmKGBnjDEigxsOw))
   fp=eNIdHQubrWPlzLfpmKGBnjDEigxsaC(eNIdHQubrWPlzLfpmKGBnjDEigxsyV,'r',-1,'utf-8')
   eNIdHQubrWPlzLfpmKGBnjDEigxsyJ=fp.readlines()
   fp.close()
  except:
   eNIdHQubrWPlzLfpmKGBnjDEigxsyJ=[]
  return eNIdHQubrWPlzLfpmKGBnjDEigxsyJ
 def Save_Watched_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV,eNIdHQubrWPlzLfpmKGBnjDEigxsOw,eNIdHQubrWPlzLfpmKGBnjDEigxswX):
  try:
   eNIdHQubrWPlzLfpmKGBnjDEigxsyV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eNIdHQubrWPlzLfpmKGBnjDEigxsOw))
   eNIdHQubrWPlzLfpmKGBnjDEigxsyh=eNIdHQubrWPlzLfpmKGBnjDEigxswV.Load_Watched_List(eNIdHQubrWPlzLfpmKGBnjDEigxsOw) 
   fp=eNIdHQubrWPlzLfpmKGBnjDEigxsaC(eNIdHQubrWPlzLfpmKGBnjDEigxsyV,'w',-1,'utf-8')
   eNIdHQubrWPlzLfpmKGBnjDEigxsyX=urllib.parse.urlencode(eNIdHQubrWPlzLfpmKGBnjDEigxswX)
   eNIdHQubrWPlzLfpmKGBnjDEigxsyX=eNIdHQubrWPlzLfpmKGBnjDEigxsyX+'\n'
   fp.write(eNIdHQubrWPlzLfpmKGBnjDEigxsyX)
   eNIdHQubrWPlzLfpmKGBnjDEigxsyc=0
   for eNIdHQubrWPlzLfpmKGBnjDEigxsyt in eNIdHQubrWPlzLfpmKGBnjDEigxsyh:
    eNIdHQubrWPlzLfpmKGBnjDEigxsyT=eNIdHQubrWPlzLfpmKGBnjDEigxsat(urllib.parse.parse_qsl(eNIdHQubrWPlzLfpmKGBnjDEigxsyt))
    eNIdHQubrWPlzLfpmKGBnjDEigxsyk=eNIdHQubrWPlzLfpmKGBnjDEigxswX.get('code').strip()
    eNIdHQubrWPlzLfpmKGBnjDEigxsyS=eNIdHQubrWPlzLfpmKGBnjDEigxsyT.get('code').strip()
    if eNIdHQubrWPlzLfpmKGBnjDEigxsOw=='seasons' and eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_settings_direct_replay()==eNIdHQubrWPlzLfpmKGBnjDEigxsah:
     eNIdHQubrWPlzLfpmKGBnjDEigxsyk=eNIdHQubrWPlzLfpmKGBnjDEigxswX.get('videoid').strip()
     eNIdHQubrWPlzLfpmKGBnjDEigxsyS=eNIdHQubrWPlzLfpmKGBnjDEigxsyT.get('videoid').strip()if eNIdHQubrWPlzLfpmKGBnjDEigxsyS!=eNIdHQubrWPlzLfpmKGBnjDEigxsaV else '-'
    if eNIdHQubrWPlzLfpmKGBnjDEigxsyk!=eNIdHQubrWPlzLfpmKGBnjDEigxsyS:
     fp.write(eNIdHQubrWPlzLfpmKGBnjDEigxsyt)
     eNIdHQubrWPlzLfpmKGBnjDEigxsyc+=1
     if eNIdHQubrWPlzLfpmKGBnjDEigxsyc>=50:break
   fp.close()
  except:
   eNIdHQubrWPlzLfpmKGBnjDEigxsaV
 def dp_Watch_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV,args):
  eNIdHQubrWPlzLfpmKGBnjDEigxsOw =args.get('stype')
  eNIdHQubrWPlzLfpmKGBnjDEigxsFo=eNIdHQubrWPlzLfpmKGBnjDEigxswV.get_settings_direct_replay()
  if eNIdHQubrWPlzLfpmKGBnjDEigxsOw=='-':
   for eNIdHQubrWPlzLfpmKGBnjDEigxsyC in eNIdHQubrWPlzLfpmKGBnjDEigxswo:
    eNIdHQubrWPlzLfpmKGBnjDEigxsFV=eNIdHQubrWPlzLfpmKGBnjDEigxsyC.get('title')
    eNIdHQubrWPlzLfpmKGBnjDEigxsFc={'mode':eNIdHQubrWPlzLfpmKGBnjDEigxsyC.get('mode'),'stype':eNIdHQubrWPlzLfpmKGBnjDEigxsyC.get('stype')}
    eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel='',img='',infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsaV,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsah,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc)
   if eNIdHQubrWPlzLfpmKGBnjDEigxsaT(eNIdHQubrWPlzLfpmKGBnjDEigxswo)>0:xbmcplugin.endOfDirectory(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle)
  else:
   eNIdHQubrWPlzLfpmKGBnjDEigxsyY=eNIdHQubrWPlzLfpmKGBnjDEigxswV.Load_Watched_List(eNIdHQubrWPlzLfpmKGBnjDEigxsOw)
   for eNIdHQubrWPlzLfpmKGBnjDEigxsyM in eNIdHQubrWPlzLfpmKGBnjDEigxsyY:
    eNIdHQubrWPlzLfpmKGBnjDEigxsyU=eNIdHQubrWPlzLfpmKGBnjDEigxsat(urllib.parse.parse_qsl(eNIdHQubrWPlzLfpmKGBnjDEigxsyM))
    eNIdHQubrWPlzLfpmKGBnjDEigxsOt=eNIdHQubrWPlzLfpmKGBnjDEigxsyU.get('code').strip()
    eNIdHQubrWPlzLfpmKGBnjDEigxsFV =eNIdHQubrWPlzLfpmKGBnjDEigxsyU.get('title').strip()
    eNIdHQubrWPlzLfpmKGBnjDEigxsOk =eNIdHQubrWPlzLfpmKGBnjDEigxsyU.get('img').strip()
    eNIdHQubrWPlzLfpmKGBnjDEigxsyv =eNIdHQubrWPlzLfpmKGBnjDEigxsyU.get('videoid').strip()
    try:
     eNIdHQubrWPlzLfpmKGBnjDEigxsOk=eNIdHQubrWPlzLfpmKGBnjDEigxsOk.replace('\'','\"')
     eNIdHQubrWPlzLfpmKGBnjDEigxsOk=json.loads(eNIdHQubrWPlzLfpmKGBnjDEigxsOk)
    except:
     eNIdHQubrWPlzLfpmKGBnjDEigxsaV
    eNIdHQubrWPlzLfpmKGBnjDEigxsyw={}
    eNIdHQubrWPlzLfpmKGBnjDEigxsyw['plot']=eNIdHQubrWPlzLfpmKGBnjDEigxsFV
    if eNIdHQubrWPlzLfpmKGBnjDEigxsOw=='movie':
     eNIdHQubrWPlzLfpmKGBnjDEigxsFc={'mode':'MOVIE','page':'1','movie_code':eNIdHQubrWPlzLfpmKGBnjDEigxsOt,'season_code':'-','title':eNIdHQubrWPlzLfpmKGBnjDEigxsFV,'thumbnail':eNIdHQubrWPlzLfpmKGBnjDEigxsOk}
     eNIdHQubrWPlzLfpmKGBnjDEigxsFt=eNIdHQubrWPlzLfpmKGBnjDEigxsaX
    else:
     if eNIdHQubrWPlzLfpmKGBnjDEigxsFo==eNIdHQubrWPlzLfpmKGBnjDEigxsaX or eNIdHQubrWPlzLfpmKGBnjDEigxsyv==eNIdHQubrWPlzLfpmKGBnjDEigxsaV:
      eNIdHQubrWPlzLfpmKGBnjDEigxsFc={'mode':'EPISODE','page':'1','movie_code':eNIdHQubrWPlzLfpmKGBnjDEigxsOt,'season_code':eNIdHQubrWPlzLfpmKGBnjDEigxsOt,'title':eNIdHQubrWPlzLfpmKGBnjDEigxsFV,'thumbnail':eNIdHQubrWPlzLfpmKGBnjDEigxsOk}
      eNIdHQubrWPlzLfpmKGBnjDEigxsFt=eNIdHQubrWPlzLfpmKGBnjDEigxsah
     else:
      eNIdHQubrWPlzLfpmKGBnjDEigxsFc={'mode':'MOVIE','movie_code':eNIdHQubrWPlzLfpmKGBnjDEigxsyv,'season_code':eNIdHQubrWPlzLfpmKGBnjDEigxsOt,'title':eNIdHQubrWPlzLfpmKGBnjDEigxsFV,'thumbnail':eNIdHQubrWPlzLfpmKGBnjDEigxsOk}
      eNIdHQubrWPlzLfpmKGBnjDEigxsFt=eNIdHQubrWPlzLfpmKGBnjDEigxsaX
    eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel='',img=eNIdHQubrWPlzLfpmKGBnjDEigxsOk,infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsyw,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsFt,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc)
   eNIdHQubrWPlzLfpmKGBnjDEigxsyw={'plot':'시청목록을 삭제합니다.'}
   eNIdHQubrWPlzLfpmKGBnjDEigxsFV='*** 시청목록 삭제 ***'
   eNIdHQubrWPlzLfpmKGBnjDEigxsFc={'mode':'MYVIEW_REMOVE','stype':eNIdHQubrWPlzLfpmKGBnjDEigxsOw}
   eNIdHQubrWPlzLfpmKGBnjDEigxsFX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.add_dir(eNIdHQubrWPlzLfpmKGBnjDEigxsFV,sublabel='',img=eNIdHQubrWPlzLfpmKGBnjDEigxsFX,infoLabels=eNIdHQubrWPlzLfpmKGBnjDEigxsyw,isFolder=eNIdHQubrWPlzLfpmKGBnjDEigxsaX,params=eNIdHQubrWPlzLfpmKGBnjDEigxsFc,isLink=eNIdHQubrWPlzLfpmKGBnjDEigxsah)
   xbmcplugin.endOfDirectory(eNIdHQubrWPlzLfpmKGBnjDEigxswV._addon_handle,cacheToDisc=eNIdHQubrWPlzLfpmKGBnjDEigxsaX)
 def logout(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  eNIdHQubrWPlzLfpmKGBnjDEigxswt=xbmcgui.Dialog()
  eNIdHQubrWPlzLfpmKGBnjDEigxsFM=eNIdHQubrWPlzLfpmKGBnjDEigxswt.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if eNIdHQubrWPlzLfpmKGBnjDEigxsFM==eNIdHQubrWPlzLfpmKGBnjDEigxsaX:sys.exit()
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.wininfo_clear()
  if os.path.isfile(eNIdHQubrWPlzLfpmKGBnjDEigxswR):os.remove(eNIdHQubrWPlzLfpmKGBnjDEigxswR)
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy=xbmcgui.Window(10000)
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_TOKEN','')
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_GUIT','')
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_GUITV','')
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_USERCD','')
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_LOGINTIME','')
 def cookiefile_save(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  eNIdHQubrWPlzLfpmKGBnjDEigxsyA =eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.Get_Now_Datetime()
  eNIdHQubrWPlzLfpmKGBnjDEigxsaw=eNIdHQubrWPlzLfpmKGBnjDEigxsyA+datetime.timedelta(days=eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(__addon__.getSetting('cache_ttl')))
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy=xbmcgui.Window(10000)
  eNIdHQubrWPlzLfpmKGBnjDEigxsaF={'watcha_token':eNIdHQubrWPlzLfpmKGBnjDEigxsFy.getProperty('WATCHA_M_TOKEN'),'watcha_guit':eNIdHQubrWPlzLfpmKGBnjDEigxsFy.getProperty('WATCHA_M_GUIT'),'watcha_guitv':eNIdHQubrWPlzLfpmKGBnjDEigxsFy.getProperty('WATCHA_M_GUITV'),'watcha_usercd':eNIdHQubrWPlzLfpmKGBnjDEigxsFy.getProperty('WATCHA_M_USERCD'),'watcha_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'watcha_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'watcha_profile':__addon__.getSetting('selected_profile'),'watcha_limitdate':eNIdHQubrWPlzLfpmKGBnjDEigxsaw.strftime('%Y-%m-%d')}
  try: 
   fp=eNIdHQubrWPlzLfpmKGBnjDEigxsaC(eNIdHQubrWPlzLfpmKGBnjDEigxswR,'w',-1,'utf-8')
   json.dump(eNIdHQubrWPlzLfpmKGBnjDEigxsaF,fp)
   fp.close()
  except eNIdHQubrWPlzLfpmKGBnjDEigxsaY as exception:
   eNIdHQubrWPlzLfpmKGBnjDEigxsaM(exception)
 def cookiefile_check(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  eNIdHQubrWPlzLfpmKGBnjDEigxsaF={}
  try: 
   fp=eNIdHQubrWPlzLfpmKGBnjDEigxsaC(eNIdHQubrWPlzLfpmKGBnjDEigxswR,'r',-1,'utf-8')
   eNIdHQubrWPlzLfpmKGBnjDEigxsaF= json.load(fp)
   fp.close()
  except eNIdHQubrWPlzLfpmKGBnjDEigxsaY as exception:
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.wininfo_clear()
   return eNIdHQubrWPlzLfpmKGBnjDEigxsaX
  eNIdHQubrWPlzLfpmKGBnjDEigxsFS =__addon__.getSetting('id')
  eNIdHQubrWPlzLfpmKGBnjDEigxsFC =__addon__.getSetting('pw')
  eNIdHQubrWPlzLfpmKGBnjDEigxsaO =__addon__.getSetting('selected_profile')
  eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_id']=base64.standard_b64decode(eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_id']).decode('utf-8')
  eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_pw']=base64.standard_b64decode(eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_pw']).decode('utf-8')
  if eNIdHQubrWPlzLfpmKGBnjDEigxsFS!=eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_id']or eNIdHQubrWPlzLfpmKGBnjDEigxsFC!=eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_pw']or eNIdHQubrWPlzLfpmKGBnjDEigxsaO!=eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_profile']:
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.wininfo_clear()
   return eNIdHQubrWPlzLfpmKGBnjDEigxsaX
  eNIdHQubrWPlzLfpmKGBnjDEigxsFU =eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(eNIdHQubrWPlzLfpmKGBnjDEigxswV.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))
  eNIdHQubrWPlzLfpmKGBnjDEigxsao=eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_limitdate']
  eNIdHQubrWPlzLfpmKGBnjDEigxsFv =eNIdHQubrWPlzLfpmKGBnjDEigxsaJ(re.sub('-','',eNIdHQubrWPlzLfpmKGBnjDEigxsao))
  if eNIdHQubrWPlzLfpmKGBnjDEigxsFv<eNIdHQubrWPlzLfpmKGBnjDEigxsFU:
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.wininfo_clear()
   return eNIdHQubrWPlzLfpmKGBnjDEigxsaX
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy=xbmcgui.Window(10000)
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_TOKEN',eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_token'])
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_GUIT',eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_guit'])
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_GUITV',eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_guitv'])
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_USERCD',eNIdHQubrWPlzLfpmKGBnjDEigxsaF['watcha_usercd'])
  eNIdHQubrWPlzLfpmKGBnjDEigxsFy.setProperty('WATCHA_M_LOGINTIME',eNIdHQubrWPlzLfpmKGBnjDEigxsao)
  return eNIdHQubrWPlzLfpmKGBnjDEigxsah
 def dp_Global_Search(eNIdHQubrWPlzLfpmKGBnjDEigxswV,args):
  eNIdHQubrWPlzLfpmKGBnjDEigxsay=args.get('mode')
  if eNIdHQubrWPlzLfpmKGBnjDEigxsay=='TOTAL_SEARCH':
   eNIdHQubrWPlzLfpmKGBnjDEigxsaq='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   eNIdHQubrWPlzLfpmKGBnjDEigxsaq='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(eNIdHQubrWPlzLfpmKGBnjDEigxsaq)
 def watcha_main(eNIdHQubrWPlzLfpmKGBnjDEigxswV):
  eNIdHQubrWPlzLfpmKGBnjDEigxsay=eNIdHQubrWPlzLfpmKGBnjDEigxswV.main_params.get('mode',eNIdHQubrWPlzLfpmKGBnjDEigxsaV)
  if eNIdHQubrWPlzLfpmKGBnjDEigxsay=='LOGOUT':
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.logout()
   return
  eNIdHQubrWPlzLfpmKGBnjDEigxswV.login_main()
  if eNIdHQubrWPlzLfpmKGBnjDEigxsay is eNIdHQubrWPlzLfpmKGBnjDEigxsaV:
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.dp_Main_List()
  elif eNIdHQubrWPlzLfpmKGBnjDEigxsay=='SUB_GROUP':
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.dp_SubGroup_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV.main_params)
  elif eNIdHQubrWPlzLfpmKGBnjDEigxsay=='CATEGORY_LIST':
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.dp_Category_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV.main_params)
  elif eNIdHQubrWPlzLfpmKGBnjDEigxsay=='EPISODE':
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.dp_Episode_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV.main_params)
  elif eNIdHQubrWPlzLfpmKGBnjDEigxsay=='ORDER_BY':
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.dp_setEpOrderby(eNIdHQubrWPlzLfpmKGBnjDEigxswV.main_params)
  elif eNIdHQubrWPlzLfpmKGBnjDEigxsay in['SEARCH','LOCAL_SEARCH']:
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.dp_Search_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV.main_params)
  elif eNIdHQubrWPlzLfpmKGBnjDEigxsay=='MOVIE':
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.play_VIDEO(eNIdHQubrWPlzLfpmKGBnjDEigxswV.main_params)
  elif eNIdHQubrWPlzLfpmKGBnjDEigxsay=='WATCH':
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.dp_Watch_List(eNIdHQubrWPlzLfpmKGBnjDEigxswV.main_params)
  elif eNIdHQubrWPlzLfpmKGBnjDEigxsay=='MYVIEW_REMOVE':
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.dp_WatchList_Delete(eNIdHQubrWPlzLfpmKGBnjDEigxswV.main_params)
  elif eNIdHQubrWPlzLfpmKGBnjDEigxsay in['TOTAL_SEARCH','TOTAL_HISTORY']:
   eNIdHQubrWPlzLfpmKGBnjDEigxswV.dp_Global_Search(eNIdHQubrWPlzLfpmKGBnjDEigxswV.main_params)
  else:
   eNIdHQubrWPlzLfpmKGBnjDEigxsaV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
