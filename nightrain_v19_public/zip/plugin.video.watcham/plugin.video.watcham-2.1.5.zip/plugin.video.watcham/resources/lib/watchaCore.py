__author__="NightRain"
SyesDdQokqTfHXnNBhIitFxuVWLlma=object
SyesDdQokqTfHXnNBhIitFxuVWLlmw=None
SyesDdQokqTfHXnNBhIitFxuVWLlmr=False
SyesDdQokqTfHXnNBhIitFxuVWLlmY=True
SyesDdQokqTfHXnNBhIitFxuVWLlmb=Exception
SyesDdQokqTfHXnNBhIitFxuVWLlmC=print
SyesDdQokqTfHXnNBhIitFxuVWLlmp=str
SyesDdQokqTfHXnNBhIitFxuVWLlmR=len
SyesDdQokqTfHXnNBhIitFxuVWLlmg=int
SyesDdQokqTfHXnNBhIitFxuVWLlmU=range
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
class SyesDdQokqTfHXnNBhIitFxuVWLlGM(SyesDdQokqTfHXnNBhIitFxuVWLlma):
 def __init__(SyesDdQokqTfHXnNBhIitFxuVWLlGJ):
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_TOKEN ='' 
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUIT =''
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUITV =''
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_USERCD=''
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.MAIN_DOMAIN ='https://watcha.com'
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.API_DOMAIN ='https://api-mars.watcha.com'
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.EPISODE_LIMIT=20
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.SEARCH_LIMIT =30
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.DEFAULT_HEADER={'user-agent':SyesDdQokqTfHXnNBhIitFxuVWLlGJ.USER_AGENT,'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.0'}
 def callRequestCookies(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,jobtype,SyesDdQokqTfHXnNBhIitFxuVWLlGK,payload=SyesDdQokqTfHXnNBhIitFxuVWLlmw,params=SyesDdQokqTfHXnNBhIitFxuVWLlmw,headers=SyesDdQokqTfHXnNBhIitFxuVWLlmw,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlmw,redirects=SyesDdQokqTfHXnNBhIitFxuVWLlmr):
  SyesDdQokqTfHXnNBhIitFxuVWLlGm=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.DEFAULT_HEADER
  if headers:SyesDdQokqTfHXnNBhIitFxuVWLlGm.update(headers)
  if jobtype=='Get':
   SyesDdQokqTfHXnNBhIitFxuVWLlGO=requests.get(SyesDdQokqTfHXnNBhIitFxuVWLlGK,params=params,headers=SyesDdQokqTfHXnNBhIitFxuVWLlGm,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   SyesDdQokqTfHXnNBhIitFxuVWLlGO=requests.put(SyesDdQokqTfHXnNBhIitFxuVWLlGK,data=payload,params=params,headers=SyesDdQokqTfHXnNBhIitFxuVWLlGm,cookies=cookies,allow_redirects=redirects)
  else:
   SyesDdQokqTfHXnNBhIitFxuVWLlGO=requests.post(SyesDdQokqTfHXnNBhIitFxuVWLlGK,data=payload,params=params,headers=SyesDdQokqTfHXnNBhIitFxuVWLlGm,cookies=cookies,allow_redirects=redirects)
  return SyesDdQokqTfHXnNBhIitFxuVWLlGO
 def SaveCredential(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,SyesDdQokqTfHXnNBhIitFxuVWLlGa):
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_TOKEN =SyesDdQokqTfHXnNBhIitFxuVWLlGa.get('watcha_token')
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUIT =SyesDdQokqTfHXnNBhIitFxuVWLlGa.get('watcha_guit')
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUITV =SyesDdQokqTfHXnNBhIitFxuVWLlGa.get('watcha_guitv')
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_USERCD =SyesDdQokqTfHXnNBhIitFxuVWLlGa.get('watcha_usercd')
 def SaveCredential_usercd(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,SyesDdQokqTfHXnNBhIitFxuVWLlGw):
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_USERCD=SyesDdQokqTfHXnNBhIitFxuVWLlGw
 def SaveCredential_guitv(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,SyesDdQokqTfHXnNBhIitFxuVWLlGr,SyesDdQokqTfHXnNBhIitFxuVWLlGY):
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUITV=SyesDdQokqTfHXnNBhIitFxuVWLlGr
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_TOKEN=SyesDdQokqTfHXnNBhIitFxuVWLlGY 
 def ClearCredential(SyesDdQokqTfHXnNBhIitFxuVWLlGJ):
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_TOKEN ='' 
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUIT =''
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUITV =''
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_USERCD=''
 def LoadCredential(SyesDdQokqTfHXnNBhIitFxuVWLlGJ):
  SyesDdQokqTfHXnNBhIitFxuVWLlGa={'watcha_token':SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_TOKEN,'watcha_guit':SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUIT,'watcha_guitv':SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUITV,'watcha_usercd':SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_USERCD}
  return SyesDdQokqTfHXnNBhIitFxuVWLlGa
 def makeDefaultCookies(SyesDdQokqTfHXnNBhIitFxuVWLlGJ):
  SyesDdQokqTfHXnNBhIitFxuVWLlGb={'_s_guit':SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUIT,'_guinness-premium_session':SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_TOKEN}
  if SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUITV:
   SyesDdQokqTfHXnNBhIitFxuVWLlGb['_s_guitv']=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_GUITV
  return SyesDdQokqTfHXnNBhIitFxuVWLlGb
 def GetCredential(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,user_id,user_pw,user_pf):
  SyesDdQokqTfHXnNBhIitFxuVWLlGC=SyesDdQokqTfHXnNBhIitFxuVWLlmr
  SyesDdQokqTfHXnNBhIitFxuVWLlGp=SyesDdQokqTfHXnNBhIitFxuVWLlGc='-'
  try:
   SyesDdQokqTfHXnNBhIitFxuVWLlGR=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.API_DOMAIN+'/api/session'
   SyesDdQokqTfHXnNBhIitFxuVWLlGg={'email':user_id,'password':user_pw}
   SyesDdQokqTfHXnNBhIitFxuVWLlGU={'accept':'application/vnd.frograms+json;version=4'}
   SyesDdQokqTfHXnNBhIitFxuVWLlGj=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.callRequestCookies('Post',SyesDdQokqTfHXnNBhIitFxuVWLlGR,payload=SyesDdQokqTfHXnNBhIitFxuVWLlGg,params=SyesDdQokqTfHXnNBhIitFxuVWLlmw,headers=SyesDdQokqTfHXnNBhIitFxuVWLlGU,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlmw)
   for SyesDdQokqTfHXnNBhIitFxuVWLlGv in SyesDdQokqTfHXnNBhIitFxuVWLlGj.cookies:
    if SyesDdQokqTfHXnNBhIitFxuVWLlGv.name=='_guinness-premium_session':
     SyesDdQokqTfHXnNBhIitFxuVWLlGc=SyesDdQokqTfHXnNBhIitFxuVWLlGv.value
    elif SyesDdQokqTfHXnNBhIitFxuVWLlGv.name=='_s_guit':
     SyesDdQokqTfHXnNBhIitFxuVWLlGp=SyesDdQokqTfHXnNBhIitFxuVWLlGv.value
   if SyesDdQokqTfHXnNBhIitFxuVWLlGc:SyesDdQokqTfHXnNBhIitFxuVWLlGC=SyesDdQokqTfHXnNBhIitFxuVWLlmY
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   SyesDdQokqTfHXnNBhIitFxuVWLlmC(exception)
   SyesDdQokqTfHXnNBhIitFxuVWLlGp=SyesDdQokqTfHXnNBhIitFxuVWLlGc='' 
  SyesDdQokqTfHXnNBhIitFxuVWLlGa={'watcha_guit':SyesDdQokqTfHXnNBhIitFxuVWLlGp,'watcha_token':SyesDdQokqTfHXnNBhIitFxuVWLlGc,'watcha_guitv':'','watcha_usercd':''}
  SyesDdQokqTfHXnNBhIitFxuVWLlGJ.SaveCredential(SyesDdQokqTfHXnNBhIitFxuVWLlGa)
  try:
   SyesDdQokqTfHXnNBhIitFxuVWLlGE=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.GetProfilesList()
   SyesDdQokqTfHXnNBhIitFxuVWLlGA =SyesDdQokqTfHXnNBhIitFxuVWLlGE[user_pf]
   SyesDdQokqTfHXnNBhIitFxuVWLlGJ.SaveCredential_usercd(SyesDdQokqTfHXnNBhIitFxuVWLlGA)
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   SyesDdQokqTfHXnNBhIitFxuVWLlmC(exception)
   SyesDdQokqTfHXnNBhIitFxuVWLlGJ.ClearCredential()
   return SyesDdQokqTfHXnNBhIitFxuVWLlmr
  if user_pf!=0:
   SyesDdQokqTfHXnNBhIitFxuVWLlGr,SyesDdQokqTfHXnNBhIitFxuVWLlGY=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.GetProfilesConvert(SyesDdQokqTfHXnNBhIitFxuVWLlGA)
   SyesDdQokqTfHXnNBhIitFxuVWLlGJ.SaveCredential_guitv(SyesDdQokqTfHXnNBhIitFxuVWLlGr,SyesDdQokqTfHXnNBhIitFxuVWLlGY)
  return SyesDdQokqTfHXnNBhIitFxuVWLlGC
 def GetSubGroupList(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,stype):
  SyesDdQokqTfHXnNBhIitFxuVWLlGP=[]
  try:
   SyesDdQokqTfHXnNBhIitFxuVWLlGz ='/api/categories.json'
   SyesDdQokqTfHXnNBhIitFxuVWLlGK=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.API_DOMAIN+SyesDdQokqTfHXnNBhIitFxuVWLlGz
   SyesDdQokqTfHXnNBhIitFxuVWLlGj=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.callRequestCookies('Get',SyesDdQokqTfHXnNBhIitFxuVWLlGK,payload=SyesDdQokqTfHXnNBhIitFxuVWLlmw,params=SyesDdQokqTfHXnNBhIitFxuVWLlmw,headers=SyesDdQokqTfHXnNBhIitFxuVWLlmw,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlmw)
   SyesDdQokqTfHXnNBhIitFxuVWLlMG=json.loads(SyesDdQokqTfHXnNBhIitFxuVWLlGj.text)
   if not('genres' in SyesDdQokqTfHXnNBhIitFxuVWLlMG):return SyesDdQokqTfHXnNBhIitFxuVWLlGP
   if stype=='genres':
    SyesDdQokqTfHXnNBhIitFxuVWLlMJ=SyesDdQokqTfHXnNBhIitFxuVWLlMG['genres']
   else:
    SyesDdQokqTfHXnNBhIitFxuVWLlMJ=SyesDdQokqTfHXnNBhIitFxuVWLlMG['tags']
   for SyesDdQokqTfHXnNBhIitFxuVWLlMm in SyesDdQokqTfHXnNBhIitFxuVWLlMJ:
    SyesDdQokqTfHXnNBhIitFxuVWLlMO=SyesDdQokqTfHXnNBhIitFxuVWLlMm['name']
    SyesDdQokqTfHXnNBhIitFxuVWLlMa =SyesDdQokqTfHXnNBhIitFxuVWLlMm['api_path']
    SyesDdQokqTfHXnNBhIitFxuVWLlMw =SyesDdQokqTfHXnNBhIitFxuVWLlMm['entity']['id']
    SyesDdQokqTfHXnNBhIitFxuVWLlMr={'group_name':SyesDdQokqTfHXnNBhIitFxuVWLlMO,'api_path':SyesDdQokqTfHXnNBhIitFxuVWLlMa,'tag_id':SyesDdQokqTfHXnNBhIitFxuVWLlmp(SyesDdQokqTfHXnNBhIitFxuVWLlMw)}
    SyesDdQokqTfHXnNBhIitFxuVWLlGP.append(SyesDdQokqTfHXnNBhIitFxuVWLlMr)
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   SyesDdQokqTfHXnNBhIitFxuVWLlmC(exception)
  return SyesDdQokqTfHXnNBhIitFxuVWLlGP
 def GetCategoryList(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,stype,SyesDdQokqTfHXnNBhIitFxuVWLlMw,SyesDdQokqTfHXnNBhIitFxuVWLlMa,page_int,in_sort):
  SyesDdQokqTfHXnNBhIitFxuVWLlGP=[]
  SyesDdQokqTfHXnNBhIitFxuVWLlMY=SyesDdQokqTfHXnNBhIitFxuVWLlmr
  SyesDdQokqTfHXnNBhIitFxuVWLlMb={}
  try:
   if 'categories' in SyesDdQokqTfHXnNBhIitFxuVWLlMa:
    SyesDdQokqTfHXnNBhIitFxuVWLlGz ='/api/categories/contents.json'
    if stype=='genres':
     SyesDdQokqTfHXnNBhIitFxuVWLlMb['genre']=SyesDdQokqTfHXnNBhIitFxuVWLlMw
    else:
     SyesDdQokqTfHXnNBhIitFxuVWLlMb['tag'] =SyesDdQokqTfHXnNBhIitFxuVWLlMw
    SyesDdQokqTfHXnNBhIitFxuVWLlMb['order']=in_sort 
    if page_int>1:
     SyesDdQokqTfHXnNBhIitFxuVWLlMb['page']=SyesDdQokqTfHXnNBhIitFxuVWLlmp(page_int-1)
   else: 
    SyesDdQokqTfHXnNBhIitFxuVWLlGz ='/api/'+SyesDdQokqTfHXnNBhIitFxuVWLlMa+'.json'
    if page_int>1:
     SyesDdQokqTfHXnNBhIitFxuVWLlMb['page']=SyesDdQokqTfHXnNBhIitFxuVWLlmp(page_int)
   SyesDdQokqTfHXnNBhIitFxuVWLlGK=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.API_DOMAIN+SyesDdQokqTfHXnNBhIitFxuVWLlGz
   SyesDdQokqTfHXnNBhIitFxuVWLlGv=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.makeDefaultCookies()
   SyesDdQokqTfHXnNBhIitFxuVWLlGj=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.callRequestCookies('Get',SyesDdQokqTfHXnNBhIitFxuVWLlGK,payload=SyesDdQokqTfHXnNBhIitFxuVWLlmw,params=SyesDdQokqTfHXnNBhIitFxuVWLlMb,headers=SyesDdQokqTfHXnNBhIitFxuVWLlmw,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlGv)
   SyesDdQokqTfHXnNBhIitFxuVWLlMG=json.loads(SyesDdQokqTfHXnNBhIitFxuVWLlGj.text)
   if not('contents' in SyesDdQokqTfHXnNBhIitFxuVWLlMG):return SyesDdQokqTfHXnNBhIitFxuVWLlGP,SyesDdQokqTfHXnNBhIitFxuVWLlMY
   SyesDdQokqTfHXnNBhIitFxuVWLlMJ=SyesDdQokqTfHXnNBhIitFxuVWLlMG['contents']
   SyesDdQokqTfHXnNBhIitFxuVWLlMY=SyesDdQokqTfHXnNBhIitFxuVWLlMG['meta']['has_next']
   for SyesDdQokqTfHXnNBhIitFxuVWLlMm in SyesDdQokqTfHXnNBhIitFxuVWLlMJ:
    SyesDdQokqTfHXnNBhIitFxuVWLlMC =SyesDdQokqTfHXnNBhIitFxuVWLlMm['code']
    SyesDdQokqTfHXnNBhIitFxuVWLlMp=SyesDdQokqTfHXnNBhIitFxuVWLlMm['content_type']
    SyesDdQokqTfHXnNBhIitFxuVWLlMR =SyesDdQokqTfHXnNBhIitFxuVWLlMm['title']
    SyesDdQokqTfHXnNBhIitFxuVWLlMg =SyesDdQokqTfHXnNBhIitFxuVWLlMm['story']
    SyesDdQokqTfHXnNBhIitFxuVWLlMU=tmp_thumb=tmp_fanart=''
    if SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('poster') !=SyesDdQokqTfHXnNBhIitFxuVWLlmw:SyesDdQokqTfHXnNBhIitFxuVWLlMU=SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('poster').get('original')
    if SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('stillcut')!=SyesDdQokqTfHXnNBhIitFxuVWLlmw:tmp_thumb =SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('stillcut').get('large')
    if SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('thumbnail')!=SyesDdQokqTfHXnNBhIitFxuVWLlmw:tmp_fanart=SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('thumbnail').get('large')
    if tmp_fanart=='' :tmp_fanart=tmp_thumb
    SyesDdQokqTfHXnNBhIitFxuVWLlMj={'thumb':tmp_thumb,'poster':SyesDdQokqTfHXnNBhIitFxuVWLlMU,'fanart':tmp_fanart}
    SyesDdQokqTfHXnNBhIitFxuVWLlMv =SyesDdQokqTfHXnNBhIitFxuVWLlMm['year']
    SyesDdQokqTfHXnNBhIitFxuVWLlMc =SyesDdQokqTfHXnNBhIitFxuVWLlMm['film_rating_code']
    SyesDdQokqTfHXnNBhIitFxuVWLlME=SyesDdQokqTfHXnNBhIitFxuVWLlMm['film_rating_short']
    SyesDdQokqTfHXnNBhIitFxuVWLlMA =SyesDdQokqTfHXnNBhIitFxuVWLlMm['film_rating_long']
    if SyesDdQokqTfHXnNBhIitFxuVWLlMp=='movies':
     SyesDdQokqTfHXnNBhIitFxuVWLlMP =SyesDdQokqTfHXnNBhIitFxuVWLlMm['duration']
    else:
     SyesDdQokqTfHXnNBhIitFxuVWLlMP ='0'
    SyesDdQokqTfHXnNBhIitFxuVWLlMr={'code':SyesDdQokqTfHXnNBhIitFxuVWLlMC,'content_type':SyesDdQokqTfHXnNBhIitFxuVWLlMp,'title':SyesDdQokqTfHXnNBhIitFxuVWLlMR,'story':SyesDdQokqTfHXnNBhIitFxuVWLlMg,'thumbnail':SyesDdQokqTfHXnNBhIitFxuVWLlMj,'year':SyesDdQokqTfHXnNBhIitFxuVWLlMv,'film_rating_code':SyesDdQokqTfHXnNBhIitFxuVWLlMc,'film_rating_short':SyesDdQokqTfHXnNBhIitFxuVWLlME,'film_rating_long':SyesDdQokqTfHXnNBhIitFxuVWLlMA,'duration':SyesDdQokqTfHXnNBhIitFxuVWLlMP}
    SyesDdQokqTfHXnNBhIitFxuVWLlGP.append(SyesDdQokqTfHXnNBhIitFxuVWLlMr)
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   SyesDdQokqTfHXnNBhIitFxuVWLlmC(exception)
  return SyesDdQokqTfHXnNBhIitFxuVWLlGP,SyesDdQokqTfHXnNBhIitFxuVWLlMY
 def GetCategoryList_morepage(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,stype,SyesDdQokqTfHXnNBhIitFxuVWLlMw,SyesDdQokqTfHXnNBhIitFxuVWLlMa,page_int,in_sort):
  SyesDdQokqTfHXnNBhIitFxuVWLlMY=SyesDdQokqTfHXnNBhIitFxuVWLlmr
  if not('categories' in SyesDdQokqTfHXnNBhIitFxuVWLlMa):return SyesDdQokqTfHXnNBhIitFxuVWLlmY
  try:
   SyesDdQokqTfHXnNBhIitFxuVWLlGz ='/api/categories/contents.json'
   SyesDdQokqTfHXnNBhIitFxuVWLlGK=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.API_DOMAIN+SyesDdQokqTfHXnNBhIitFxuVWLlGz
   SyesDdQokqTfHXnNBhIitFxuVWLlMb={}
   if stype=='genres':
    SyesDdQokqTfHXnNBhIitFxuVWLlMb['genre']=SyesDdQokqTfHXnNBhIitFxuVWLlMw
   else:
    SyesDdQokqTfHXnNBhIitFxuVWLlMb['tag'] =SyesDdQokqTfHXnNBhIitFxuVWLlMw
   SyesDdQokqTfHXnNBhIitFxuVWLlMb['order']=in_sort 
   if page_int>1:
    SyesDdQokqTfHXnNBhIitFxuVWLlMb['page']=SyesDdQokqTfHXnNBhIitFxuVWLlmp(page_int-1)
   SyesDdQokqTfHXnNBhIitFxuVWLlGj=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.callRequestCookies('Get',SyesDdQokqTfHXnNBhIitFxuVWLlGK,payload=SyesDdQokqTfHXnNBhIitFxuVWLlmw,params=SyesDdQokqTfHXnNBhIitFxuVWLlMb,headers=SyesDdQokqTfHXnNBhIitFxuVWLlmw,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlmw)
   SyesDdQokqTfHXnNBhIitFxuVWLlMG=json.loads(SyesDdQokqTfHXnNBhIitFxuVWLlGj.text)
   SyesDdQokqTfHXnNBhIitFxuVWLlMY=SyesDdQokqTfHXnNBhIitFxuVWLlMG['meta']['has_next']
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   SyesDdQokqTfHXnNBhIitFxuVWLlmC(exception)
  return SyesDdQokqTfHXnNBhIitFxuVWLlMY
 def GetProgramInfo(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,program_code):
  SyesDdQokqTfHXnNBhIitFxuVWLlMz={}
  try:
   SyesDdQokqTfHXnNBhIitFxuVWLlGz ='/api/contents/'+program_code
   SyesDdQokqTfHXnNBhIitFxuVWLlGK=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.API_DOMAIN+SyesDdQokqTfHXnNBhIitFxuVWLlGz
   SyesDdQokqTfHXnNBhIitFxuVWLlGj=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.callRequestCookies('Get',SyesDdQokqTfHXnNBhIitFxuVWLlGK,payload=SyesDdQokqTfHXnNBhIitFxuVWLlmw,params=SyesDdQokqTfHXnNBhIitFxuVWLlmw,headers=SyesDdQokqTfHXnNBhIitFxuVWLlmw,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlmw)
   SyesDdQokqTfHXnNBhIitFxuVWLlMG=json.loads(SyesDdQokqTfHXnNBhIitFxuVWLlGj.text)
   SyesDdQokqTfHXnNBhIitFxuVWLlMK=img_clearlogo=''
   SyesDdQokqTfHXnNBhIitFxuVWLlMK=SyesDdQokqTfHXnNBhIitFxuVWLlMG.get('poster').get('original')
   if SyesDdQokqTfHXnNBhIitFxuVWLlmR(SyesDdQokqTfHXnNBhIitFxuVWLlMG.get('title_logos'))>0:img_clearlogo=SyesDdQokqTfHXnNBhIitFxuVWLlMG.get('title_logos')[0].get('src')
   SyesDdQokqTfHXnNBhIitFxuVWLlMz={'imgPoster':SyesDdQokqTfHXnNBhIitFxuVWLlMK,'imgClearlogo':img_clearlogo}
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   SyesDdQokqTfHXnNBhIitFxuVWLlmC(exception)
  return SyesDdQokqTfHXnNBhIitFxuVWLlMz
 def GetEpisodoList(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,program_code,page_int,orderby='asc'):
  SyesDdQokqTfHXnNBhIitFxuVWLlGP=[]
  SyesDdQokqTfHXnNBhIitFxuVWLlMY=SyesDdQokqTfHXnNBhIitFxuVWLlmr
  SyesDdQokqTfHXnNBhIitFxuVWLlJG=''
  try:
   SyesDdQokqTfHXnNBhIitFxuVWLlGz ='/api/contents/'+program_code+'/tv_episodes.json'
   SyesDdQokqTfHXnNBhIitFxuVWLlGK=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.API_DOMAIN+SyesDdQokqTfHXnNBhIitFxuVWLlGz
   SyesDdQokqTfHXnNBhIitFxuVWLlMb={'all':'true'}
   SyesDdQokqTfHXnNBhIitFxuVWLlGj=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.callRequestCookies('Get',SyesDdQokqTfHXnNBhIitFxuVWLlGK,payload=SyesDdQokqTfHXnNBhIitFxuVWLlmw,params=SyesDdQokqTfHXnNBhIitFxuVWLlMb,headers=SyesDdQokqTfHXnNBhIitFxuVWLlmw,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlmw)
   SyesDdQokqTfHXnNBhIitFxuVWLlMG=json.loads(SyesDdQokqTfHXnNBhIitFxuVWLlGj.text)
   if not('tv_episode_codes' in SyesDdQokqTfHXnNBhIitFxuVWLlMG):return SyesDdQokqTfHXnNBhIitFxuVWLlGP,SyesDdQokqTfHXnNBhIitFxuVWLlMY
   SyesDdQokqTfHXnNBhIitFxuVWLlMJ=SyesDdQokqTfHXnNBhIitFxuVWLlMG['tv_episode_codes']
   SyesDdQokqTfHXnNBhIitFxuVWLlJM=SyesDdQokqTfHXnNBhIitFxuVWLlmR(SyesDdQokqTfHXnNBhIitFxuVWLlMJ)
   SyesDdQokqTfHXnNBhIitFxuVWLlJm =SyesDdQokqTfHXnNBhIitFxuVWLlmg(SyesDdQokqTfHXnNBhIitFxuVWLlJM//(SyesDdQokqTfHXnNBhIitFxuVWLlGJ.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    SyesDdQokqTfHXnNBhIitFxuVWLlJO =(SyesDdQokqTfHXnNBhIitFxuVWLlJM-1)-((page_int-1)*SyesDdQokqTfHXnNBhIitFxuVWLlGJ.EPISODE_LIMIT)
   else:
    SyesDdQokqTfHXnNBhIitFxuVWLlJO =(page_int-1)*SyesDdQokqTfHXnNBhIitFxuVWLlGJ.EPISODE_LIMIT
   for i in SyesDdQokqTfHXnNBhIitFxuVWLlmU(SyesDdQokqTfHXnNBhIitFxuVWLlGJ.EPISODE_LIMIT):
    if orderby=='desc':
     SyesDdQokqTfHXnNBhIitFxuVWLlJa=SyesDdQokqTfHXnNBhIitFxuVWLlJO-i
     if SyesDdQokqTfHXnNBhIitFxuVWLlJa<0:break
    else:
     SyesDdQokqTfHXnNBhIitFxuVWLlJa=SyesDdQokqTfHXnNBhIitFxuVWLlJO+i
     if SyesDdQokqTfHXnNBhIitFxuVWLlJa>=SyesDdQokqTfHXnNBhIitFxuVWLlJM:break
    if SyesDdQokqTfHXnNBhIitFxuVWLlJG!='':SyesDdQokqTfHXnNBhIitFxuVWLlJG+=','
    SyesDdQokqTfHXnNBhIitFxuVWLlJG+=SyesDdQokqTfHXnNBhIitFxuVWLlMJ[SyesDdQokqTfHXnNBhIitFxuVWLlJa]
   if SyesDdQokqTfHXnNBhIitFxuVWLlJm>page_int:SyesDdQokqTfHXnNBhIitFxuVWLlMY=SyesDdQokqTfHXnNBhIitFxuVWLlmY
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   SyesDdQokqTfHXnNBhIitFxuVWLlmC(exception)
  SyesDdQokqTfHXnNBhIitFxuVWLlJw=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.GetProgramInfo(program_code)
  try:
   SyesDdQokqTfHXnNBhIitFxuVWLlGK=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.API_DOMAIN+SyesDdQokqTfHXnNBhIitFxuVWLlGz
   SyesDdQokqTfHXnNBhIitFxuVWLlMb={'codes':SyesDdQokqTfHXnNBhIitFxuVWLlJG}
   SyesDdQokqTfHXnNBhIitFxuVWLlGj=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.callRequestCookies('Get',SyesDdQokqTfHXnNBhIitFxuVWLlGK,payload=SyesDdQokqTfHXnNBhIitFxuVWLlmw,params=SyesDdQokqTfHXnNBhIitFxuVWLlMb,headers=SyesDdQokqTfHXnNBhIitFxuVWLlmw,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlmw)
   SyesDdQokqTfHXnNBhIitFxuVWLlMG=json.loads(SyesDdQokqTfHXnNBhIitFxuVWLlGj.text)
   if not('tv_episodes' in SyesDdQokqTfHXnNBhIitFxuVWLlMG):return SyesDdQokqTfHXnNBhIitFxuVWLlGP
   SyesDdQokqTfHXnNBhIitFxuVWLlMJ=SyesDdQokqTfHXnNBhIitFxuVWLlMG['tv_episodes']
   for SyesDdQokqTfHXnNBhIitFxuVWLlMm in SyesDdQokqTfHXnNBhIitFxuVWLlMJ:
    SyesDdQokqTfHXnNBhIitFxuVWLlMC =SyesDdQokqTfHXnNBhIitFxuVWLlMm['code']
    if SyesDdQokqTfHXnNBhIitFxuVWLlMm['title']:
     SyesDdQokqTfHXnNBhIitFxuVWLlMR =SyesDdQokqTfHXnNBhIitFxuVWLlMm['title']
    else:
     SyesDdQokqTfHXnNBhIitFxuVWLlMR =''
    SyesDdQokqTfHXnNBhIitFxuVWLlMU=tmp_thumb=tmp_fanart=SyesDdQokqTfHXnNBhIitFxuVWLlJr=''
    SyesDdQokqTfHXnNBhIitFxuVWLlMU =SyesDdQokqTfHXnNBhIitFxuVWLlJw.get('imgPoster')
    SyesDdQokqTfHXnNBhIitFxuVWLlJr=SyesDdQokqTfHXnNBhIitFxuVWLlJw.get('imgClearlogo')
    if SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('stillcut') !=SyesDdQokqTfHXnNBhIitFxuVWLlmw:tmp_thumb =SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('stillcut').get('large')
    if SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('tv_season_stillcut')!=SyesDdQokqTfHXnNBhIitFxuVWLlmw:tmp_fanart=SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('tv_season_stillcut').get('large')
    SyesDdQokqTfHXnNBhIitFxuVWLlMj={'thumb':tmp_thumb,'poster':SyesDdQokqTfHXnNBhIitFxuVWLlMU,'fanart':tmp_fanart,'clearlogo':SyesDdQokqTfHXnNBhIitFxuVWLlJr}
    SyesDdQokqTfHXnNBhIitFxuVWLlJY =SyesDdQokqTfHXnNBhIitFxuVWLlMm['display_number']
    SyesDdQokqTfHXnNBhIitFxuVWLlJb=SyesDdQokqTfHXnNBhIitFxuVWLlMm['tv_season_title']
    SyesDdQokqTfHXnNBhIitFxuVWLlMP =SyesDdQokqTfHXnNBhIitFxuVWLlMm['duration']
    try:
     SyesDdQokqTfHXnNBhIitFxuVWLlJC=SyesDdQokqTfHXnNBhIitFxuVWLlMm['episode_number']
    except:
     SyesDdQokqTfHXnNBhIitFxuVWLlJC='0'
    SyesDdQokqTfHXnNBhIitFxuVWLlMr={'code':SyesDdQokqTfHXnNBhIitFxuVWLlMC,'title':SyesDdQokqTfHXnNBhIitFxuVWLlMR,'thumbnail':SyesDdQokqTfHXnNBhIitFxuVWLlMj,'display_num':SyesDdQokqTfHXnNBhIitFxuVWLlJY,'season_title':SyesDdQokqTfHXnNBhIitFxuVWLlJb,'duration':SyesDdQokqTfHXnNBhIitFxuVWLlMP,'episode_number':SyesDdQokqTfHXnNBhIitFxuVWLlJC}
    SyesDdQokqTfHXnNBhIitFxuVWLlGP.append(SyesDdQokqTfHXnNBhIitFxuVWLlMr)
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   SyesDdQokqTfHXnNBhIitFxuVWLlmC(exception)
  return SyesDdQokqTfHXnNBhIitFxuVWLlGP,SyesDdQokqTfHXnNBhIitFxuVWLlMY
 def GetSearchList(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,search_key,page_int):
  SyesDdQokqTfHXnNBhIitFxuVWLlJp=[]
  SyesDdQokqTfHXnNBhIitFxuVWLlMY=SyesDdQokqTfHXnNBhIitFxuVWLlmr
  try:
   SyesDdQokqTfHXnNBhIitFxuVWLlGz ='/api/search.json'
   SyesDdQokqTfHXnNBhIitFxuVWLlGK=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.API_DOMAIN+SyesDdQokqTfHXnNBhIitFxuVWLlGz
   SyesDdQokqTfHXnNBhIitFxuVWLlMb={'query':search_key,'page':SyesDdQokqTfHXnNBhIitFxuVWLlmp(page_int),'per':SyesDdQokqTfHXnNBhIitFxuVWLlmp(SyesDdQokqTfHXnNBhIitFxuVWLlGJ.SEARCH_LIMIT),'exclude':'limited'}
   SyesDdQokqTfHXnNBhIitFxuVWLlGj=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.callRequestCookies('Get',SyesDdQokqTfHXnNBhIitFxuVWLlGK,payload=SyesDdQokqTfHXnNBhIitFxuVWLlmw,params=SyesDdQokqTfHXnNBhIitFxuVWLlMb,headers=SyesDdQokqTfHXnNBhIitFxuVWLlmw,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlmw)
   SyesDdQokqTfHXnNBhIitFxuVWLlMG=json.loads(SyesDdQokqTfHXnNBhIitFxuVWLlGj.text)
   if not('results' in SyesDdQokqTfHXnNBhIitFxuVWLlMG):return SyesDdQokqTfHXnNBhIitFxuVWLlJp,SyesDdQokqTfHXnNBhIitFxuVWLlMY
   SyesDdQokqTfHXnNBhIitFxuVWLlMJ=SyesDdQokqTfHXnNBhIitFxuVWLlMG['results']
   SyesDdQokqTfHXnNBhIitFxuVWLlMY=SyesDdQokqTfHXnNBhIitFxuVWLlMG['meta']['has_next']
   for SyesDdQokqTfHXnNBhIitFxuVWLlMm in SyesDdQokqTfHXnNBhIitFxuVWLlMJ:
    SyesDdQokqTfHXnNBhIitFxuVWLlMC =SyesDdQokqTfHXnNBhIitFxuVWLlMm['code']
    SyesDdQokqTfHXnNBhIitFxuVWLlMp=SyesDdQokqTfHXnNBhIitFxuVWLlMm['content_type']
    SyesDdQokqTfHXnNBhIitFxuVWLlMR =SyesDdQokqTfHXnNBhIitFxuVWLlMm['title']
    SyesDdQokqTfHXnNBhIitFxuVWLlMg =SyesDdQokqTfHXnNBhIitFxuVWLlMm['story']
    SyesDdQokqTfHXnNBhIitFxuVWLlMU=tmp_thumb=tmp_fanart=''
    if SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('poster') !=SyesDdQokqTfHXnNBhIitFxuVWLlmw:SyesDdQokqTfHXnNBhIitFxuVWLlMU=SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('poster').get('original')
    if SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('stillcut')!=SyesDdQokqTfHXnNBhIitFxuVWLlmw:tmp_thumb =SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('stillcut').get('large')
    if SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('thumbnail')!=SyesDdQokqTfHXnNBhIitFxuVWLlmw:tmp_fanart=SyesDdQokqTfHXnNBhIitFxuVWLlMm.get('thumbnail').get('large')
    if tmp_fanart=='' :tmp_fanart=tmp_thumb
    SyesDdQokqTfHXnNBhIitFxuVWLlMj={'thumb':tmp_thumb,'poster':SyesDdQokqTfHXnNBhIitFxuVWLlMU,'fanart':tmp_fanart}
    SyesDdQokqTfHXnNBhIitFxuVWLlMv =SyesDdQokqTfHXnNBhIitFxuVWLlMm['year']
    SyesDdQokqTfHXnNBhIitFxuVWLlMc =SyesDdQokqTfHXnNBhIitFxuVWLlMm['film_rating_code']
    SyesDdQokqTfHXnNBhIitFxuVWLlME=SyesDdQokqTfHXnNBhIitFxuVWLlMm['film_rating_short']
    SyesDdQokqTfHXnNBhIitFxuVWLlMA =SyesDdQokqTfHXnNBhIitFxuVWLlMm['film_rating_long']
    if SyesDdQokqTfHXnNBhIitFxuVWLlMp=='movies':
     SyesDdQokqTfHXnNBhIitFxuVWLlMP =SyesDdQokqTfHXnNBhIitFxuVWLlMm['duration']
    else:
     SyesDdQokqTfHXnNBhIitFxuVWLlMP ='0'
    SyesDdQokqTfHXnNBhIitFxuVWLlMr={'code':SyesDdQokqTfHXnNBhIitFxuVWLlMC,'content_type':SyesDdQokqTfHXnNBhIitFxuVWLlMp,'title':SyesDdQokqTfHXnNBhIitFxuVWLlMR,'story':SyesDdQokqTfHXnNBhIitFxuVWLlMg,'thumbnail':SyesDdQokqTfHXnNBhIitFxuVWLlMj,'year':SyesDdQokqTfHXnNBhIitFxuVWLlMv,'film_rating_code':SyesDdQokqTfHXnNBhIitFxuVWLlMc,'film_rating_short':SyesDdQokqTfHXnNBhIitFxuVWLlME,'film_rating_long':SyesDdQokqTfHXnNBhIitFxuVWLlMA,'duration':SyesDdQokqTfHXnNBhIitFxuVWLlMP}
    SyesDdQokqTfHXnNBhIitFxuVWLlJp.append(SyesDdQokqTfHXnNBhIitFxuVWLlMr)
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   SyesDdQokqTfHXnNBhIitFxuVWLlmC(exception)
  return SyesDdQokqTfHXnNBhIitFxuVWLlJp,SyesDdQokqTfHXnNBhIitFxuVWLlMY
 def GetProfilesList(SyesDdQokqTfHXnNBhIitFxuVWLlGJ):
  SyesDdQokqTfHXnNBhIitFxuVWLlGE=[]
  try:
   SyesDdQokqTfHXnNBhIitFxuVWLlGz ='/manage_profiles'
   SyesDdQokqTfHXnNBhIitFxuVWLlGK=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.MAIN_DOMAIN+SyesDdQokqTfHXnNBhIitFxuVWLlGz
   SyesDdQokqTfHXnNBhIitFxuVWLlGv=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.makeDefaultCookies()
   SyesDdQokqTfHXnNBhIitFxuVWLlGj=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.callRequestCookies('Get',SyesDdQokqTfHXnNBhIitFxuVWLlGK,payload=SyesDdQokqTfHXnNBhIitFxuVWLlmw,params=SyesDdQokqTfHXnNBhIitFxuVWLlmw,headers=SyesDdQokqTfHXnNBhIitFxuVWLlmw,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlGv,redirects=SyesDdQokqTfHXnNBhIitFxuVWLlmY)
   SyesDdQokqTfHXnNBhIitFxuVWLlJR=SyesDdQokqTfHXnNBhIitFxuVWLlGj.text
   SyesDdQokqTfHXnNBhIitFxuVWLlJg =re.findall('/api/users/me.{5000}',SyesDdQokqTfHXnNBhIitFxuVWLlJR)[0]
   SyesDdQokqTfHXnNBhIitFxuVWLlJg =SyesDdQokqTfHXnNBhIitFxuVWLlJg.replace('&quot;','')
   SyesDdQokqTfHXnNBhIitFxuVWLlGE=re.findall('Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:',SyesDdQokqTfHXnNBhIitFxuVWLlJg)
   for i in SyesDdQokqTfHXnNBhIitFxuVWLlmU(SyesDdQokqTfHXnNBhIitFxuVWLlmR(SyesDdQokqTfHXnNBhIitFxuVWLlGE)):
    SyesDdQokqTfHXnNBhIitFxuVWLlJU=SyesDdQokqTfHXnNBhIitFxuVWLlGE[i]
    SyesDdQokqTfHXnNBhIitFxuVWLlJU =SyesDdQokqTfHXnNBhIitFxuVWLlJU.split(':')[1]
    SyesDdQokqTfHXnNBhIitFxuVWLlGE[i]=SyesDdQokqTfHXnNBhIitFxuVWLlJU.split(',')[0]
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   SyesDdQokqTfHXnNBhIitFxuVWLlmC(exception)
  return SyesDdQokqTfHXnNBhIitFxuVWLlGE
 def GetProfilesConvert(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,SyesDdQokqTfHXnNBhIitFxuVWLlGw):
  SyesDdQokqTfHXnNBhIitFxuVWLlJj=''
  SyesDdQokqTfHXnNBhIitFxuVWLlJv=''
  try:
   SyesDdQokqTfHXnNBhIitFxuVWLlGz ='/api/users/'+SyesDdQokqTfHXnNBhIitFxuVWLlGw+'/convert'
   SyesDdQokqTfHXnNBhIitFxuVWLlGK=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.API_DOMAIN+SyesDdQokqTfHXnNBhIitFxuVWLlGz
   SyesDdQokqTfHXnNBhIitFxuVWLlGv=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.makeDefaultCookies()
   SyesDdQokqTfHXnNBhIitFxuVWLlGj=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.callRequestCookies('Put',SyesDdQokqTfHXnNBhIitFxuVWLlGK,payload=SyesDdQokqTfHXnNBhIitFxuVWLlmw,params=SyesDdQokqTfHXnNBhIitFxuVWLlmw,headers=SyesDdQokqTfHXnNBhIitFxuVWLlmw,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlGv)
   for SyesDdQokqTfHXnNBhIitFxuVWLlGv in SyesDdQokqTfHXnNBhIitFxuVWLlGj.cookies:
    if SyesDdQokqTfHXnNBhIitFxuVWLlGv.name=='_s_guitv':
     SyesDdQokqTfHXnNBhIitFxuVWLlJc=SyesDdQokqTfHXnNBhIitFxuVWLlGv.value
    elif SyesDdQokqTfHXnNBhIitFxuVWLlGv.name=='_guinness-premium_session':
     SyesDdQokqTfHXnNBhIitFxuVWLlGc=SyesDdQokqTfHXnNBhIitFxuVWLlGv.value
   if SyesDdQokqTfHXnNBhIitFxuVWLlJc:
    SyesDdQokqTfHXnNBhIitFxuVWLlJj=SyesDdQokqTfHXnNBhIitFxuVWLlJc
   if SyesDdQokqTfHXnNBhIitFxuVWLlGc:
    SyesDdQokqTfHXnNBhIitFxuVWLlJv=SyesDdQokqTfHXnNBhIitFxuVWLlGc
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   SyesDdQokqTfHXnNBhIitFxuVWLlJj=''
   SyesDdQokqTfHXnNBhIitFxuVWLlJv=''
  return SyesDdQokqTfHXnNBhIitFxuVWLlJj,SyesDdQokqTfHXnNBhIitFxuVWLlJv
 def Get_Now_Datetime(SyesDdQokqTfHXnNBhIitFxuVWLlGJ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(SyesDdQokqTfHXnNBhIitFxuVWLlGJ,movie_code,quality_str):
  SyesDdQokqTfHXnNBhIitFxuVWLlJA=SyesDdQokqTfHXnNBhIitFxuVWLlJz=SyesDdQokqTfHXnNBhIitFxuVWLlmO=''
  try:
   SyesDdQokqTfHXnNBhIitFxuVWLlGz='/api/watch/'+movie_code+'.json'
   SyesDdQokqTfHXnNBhIitFxuVWLlGK=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.API_DOMAIN+SyesDdQokqTfHXnNBhIitFxuVWLlGz
   SyesDdQokqTfHXnNBhIitFxuVWLlGU={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str}
   SyesDdQokqTfHXnNBhIitFxuVWLlGv=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.makeDefaultCookies()
   SyesDdQokqTfHXnNBhIitFxuVWLlGj=SyesDdQokqTfHXnNBhIitFxuVWLlGJ.callRequestCookies('Get',SyesDdQokqTfHXnNBhIitFxuVWLlGK,payload=SyesDdQokqTfHXnNBhIitFxuVWLlmw,params=SyesDdQokqTfHXnNBhIitFxuVWLlmw,headers=SyesDdQokqTfHXnNBhIitFxuVWLlGU,cookies=SyesDdQokqTfHXnNBhIitFxuVWLlGv)
   SyesDdQokqTfHXnNBhIitFxuVWLlMG=json.loads(SyesDdQokqTfHXnNBhIitFxuVWLlGj.text)
   SyesDdQokqTfHXnNBhIitFxuVWLlJA=SyesDdQokqTfHXnNBhIitFxuVWLlMG['streams'][0]['source']
   if SyesDdQokqTfHXnNBhIitFxuVWLlJA==SyesDdQokqTfHXnNBhIitFxuVWLlmw:return(SyesDdQokqTfHXnNBhIitFxuVWLlJA,SyesDdQokqTfHXnNBhIitFxuVWLlJz,SyesDdQokqTfHXnNBhIitFxuVWLlmO)
   if 'subtitles' in SyesDdQokqTfHXnNBhIitFxuVWLlMG['streams'][0]:
    for SyesDdQokqTfHXnNBhIitFxuVWLlJP in SyesDdQokqTfHXnNBhIitFxuVWLlMG['streams'][0]['subtitles']:
     if SyesDdQokqTfHXnNBhIitFxuVWLlJP['lang']=='ko':
      SyesDdQokqTfHXnNBhIitFxuVWLlJz=SyesDdQokqTfHXnNBhIitFxuVWLlJP['url']
      break
   SyesDdQokqTfHXnNBhIitFxuVWLlJK =SyesDdQokqTfHXnNBhIitFxuVWLlMG['ping_payload']
   SyesDdQokqTfHXnNBhIitFxuVWLlmG =SyesDdQokqTfHXnNBhIitFxuVWLlGJ.WATCHA_USERCD
   SyesDdQokqTfHXnNBhIitFxuVWLlmM={'merchant':'giitd_frograms','sessionId':SyesDdQokqTfHXnNBhIitFxuVWLlJK,'userId':SyesDdQokqTfHXnNBhIitFxuVWLlmG}
   SyesDdQokqTfHXnNBhIitFxuVWLlmJ=json.dumps(SyesDdQokqTfHXnNBhIitFxuVWLlmM,separators=(",",":")).encode('UTF-8')
   SyesDdQokqTfHXnNBhIitFxuVWLlmO=base64.b64encode(SyesDdQokqTfHXnNBhIitFxuVWLlmJ)
  except SyesDdQokqTfHXnNBhIitFxuVWLlmb as exception:
   return(SyesDdQokqTfHXnNBhIitFxuVWLlJA,SyesDdQokqTfHXnNBhIitFxuVWLlJz,SyesDdQokqTfHXnNBhIitFxuVWLlmO)
  return(SyesDdQokqTfHXnNBhIitFxuVWLlJA,SyesDdQokqTfHXnNBhIitFxuVWLlJz,SyesDdQokqTfHXnNBhIitFxuVWLlmO) 
# Created by pyminifier (https://github.com/liftoff/pyminifier)
