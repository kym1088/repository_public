__author__="NightRain"
pOgxlseFyIkSAuEaPYQVwUbjJChoBn=object
pOgxlseFyIkSAuEaPYQVwUbjJChoBv=None
pOgxlseFyIkSAuEaPYQVwUbjJChoBM=False
pOgxlseFyIkSAuEaPYQVwUbjJChoBL=open
pOgxlseFyIkSAuEaPYQVwUbjJChoBK=True
pOgxlseFyIkSAuEaPYQVwUbjJChoBr=id
pOgxlseFyIkSAuEaPYQVwUbjJChoBW=str
pOgxlseFyIkSAuEaPYQVwUbjJChomc=range
pOgxlseFyIkSAuEaPYQVwUbjJChomi=Exception
pOgxlseFyIkSAuEaPYQVwUbjJChomH=print
pOgxlseFyIkSAuEaPYQVwUbjJChomd=int
pOgxlseFyIkSAuEaPYQVwUbjJChomB=len
import urllib
import re
import json
import sys
import time
import base64
import requests
import datetime
import string
import random
class pOgxlseFyIkSAuEaPYQVwUbjJChoci(pOgxlseFyIkSAuEaPYQVwUbjJChoBn):
 def __init__(pOgxlseFyIkSAuEaPYQVwUbjJChocH):
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC ={}
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.Init_WC_Total()
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.MAIN_DOMAIN ='https://watcha.com'
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN ='https://api-mars.watcha.com'
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.EPISODE_LIMIT=20
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.SEARCH_LIMIT =30
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36'
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.USER_AGENT2 ='User-Agent: Dalvik/2.1.0 (Linux; U; Android 9; A95X_F3_Air Build/A95X_F3_AIR_M)/WatchaPlay-Android/1.10.34'
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.DEFAULT_HEADER={'user-agent':pOgxlseFyIkSAuEaPYQVwUbjJChocH.USER_AGENT}
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC_SUBTITLE_VTT =''
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC_SUBTITLE_SRT =''
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC_COOKIE_FILENAME =''
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC_SEARCHEDC_FILENAME=''
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC_STREAM_FILENAME =''
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC_TEMP_JSONFILE_1 =''
 def Get_Base_Headers(pOgxlseFyIkSAuEaPYQVwUbjJChocH):
  pOgxlseFyIkSAuEaPYQVwUbjJChocd={'x-watchaplay-client':'WatchaPlay-WebApp','x-watchaplay-client-language':'ko','x-watchaplay-client-region':'KR','x-watchaplay-client-version':'1.0.3',}
  return pOgxlseFyIkSAuEaPYQVwUbjJChocd
 def Get_Base_Headers_v2(pOgxlseFyIkSAuEaPYQVwUbjJChocH):
  pOgxlseFyIkSAuEaPYQVwUbjJChocB ='1.10.35' 
  pOgxlseFyIkSAuEaPYQVwUbjJChocm ='30' 
  pOgxlseFyIkSAuEaPYQVwUbjJChocX ='NVIDIA SHIELD Android TV'
  pOgxlseFyIkSAuEaPYQVwUbjJChocf =base64.standard_b64encode((pOgxlseFyIkSAuEaPYQVwUbjJChocX+'-'+pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['deviceId2']).encode()).decode('utf-8') 
  pOgxlseFyIkSAuEaPYQVwUbjJChocN ='1920x1080/2.0/320/xhdpi'
  pOgxlseFyIkSAuEaPYQVwUbjJChocq ='2596eb93-6e7f-4eba-925c-ddf783246860' 
  pOgxlseFyIkSAuEaPYQVwUbjJChocd={'X-WatchaPlay-Client-Device-Id':pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['deviceId1'],'X-WatchaPlay-Client-Device-Id2':pOgxlseFyIkSAuEaPYQVwUbjJChocf,'X-WatchaPlay-Client-Device-Name':pOgxlseFyIkSAuEaPYQVwUbjJChocX,'X-WatchaPlay-Client-ADID':pOgxlseFyIkSAuEaPYQVwUbjJChocq,'X-WatchaPlay-Client':'WatchaPlay-Android','X-WatchaPlay-Client-Version':pOgxlseFyIkSAuEaPYQVwUbjJChocB,'X-WatchaPlay-Client-Subclass':'Normal','X-WatchaPlay-Client-Ui-Mode-Name':'television','X-WatchaPlay-Screen':pOgxlseFyIkSAuEaPYQVwUbjJChocN,'X-WatchaPlay-Network-Status':'wifi','X-WatchaPlay-Appsflyer-Device-ID':pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['flyerId'],'X-FROGRAMS-CLIENT':'Mars-Android-Box','X-FROGRAMS-APP-CODE':'mars','X-FROGRAMS-DEVICE-IDENTIFIER':pOgxlseFyIkSAuEaPYQVwUbjJChocf,'X-FROGRAMS-DEVICE-NAME':pOgxlseFyIkSAuEaPYQVwUbjJChocX,'X-FROGRAMS-AD-ID':pOgxlseFyIkSAuEaPYQVwUbjJChocq,'X-FROGRAMS-APPSFLYER-DEVICE-ID':pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['flyerId'],'X-FROGRAMS-VERSION':pOgxlseFyIkSAuEaPYQVwUbjJChocB,'X-FROGRAMS-OS-VERSION':pOgxlseFyIkSAuEaPYQVwUbjJChocm,'X-FROGRAMS-NETWORK-STATUS':'wifi','X-FROGRAMS-MARS-SCREEN':pOgxlseFyIkSAuEaPYQVwUbjJChocN,'X-FROGRAMS-MARS-UI-MODE':'television',}
  return pOgxlseFyIkSAuEaPYQVwUbjJChocd
 def Init_WC_Total(pOgxlseFyIkSAuEaPYQVwUbjJChocH):
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC={'account':{},'cookies':{'watcha_token':'','watcha_guit':'','watcha_guitv':'','watcha_usercd':'',},}
 def callRequestCookies(pOgxlseFyIkSAuEaPYQVwUbjJChocH,jobtype,pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,redirects=pOgxlseFyIkSAuEaPYQVwUbjJChoBM):
  pOgxlseFyIkSAuEaPYQVwUbjJChocD=pOgxlseFyIkSAuEaPYQVwUbjJChocH.DEFAULT_HEADER
  if headers:pOgxlseFyIkSAuEaPYQVwUbjJChocD.update(headers)
  if jobtype=='Get':
   pOgxlseFyIkSAuEaPYQVwUbjJChocz=requests.get(pOgxlseFyIkSAuEaPYQVwUbjJChoiT,params=params,headers=pOgxlseFyIkSAuEaPYQVwUbjJChocD,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Put':
   pOgxlseFyIkSAuEaPYQVwUbjJChocz=requests.put(pOgxlseFyIkSAuEaPYQVwUbjJChoiT,data=payload,params=params,headers=pOgxlseFyIkSAuEaPYQVwUbjJChocD,cookies=cookies,allow_redirects=redirects)
  elif jobtype=='Delete':
   pOgxlseFyIkSAuEaPYQVwUbjJChocz=requests.delete(pOgxlseFyIkSAuEaPYQVwUbjJChoiT,params=params,headers=pOgxlseFyIkSAuEaPYQVwUbjJChocD,cookies=cookies,allow_redirects=redirects)
  else:
   pOgxlseFyIkSAuEaPYQVwUbjJChocz=requests.post(pOgxlseFyIkSAuEaPYQVwUbjJChoiT,data=payload,params=params,headers=pOgxlseFyIkSAuEaPYQVwUbjJChocD,cookies=cookies,allow_redirects=redirects)
  return pOgxlseFyIkSAuEaPYQVwUbjJChocz
 def JsonFile_Save(pOgxlseFyIkSAuEaPYQVwUbjJChocH,filename,pOgxlseFyIkSAuEaPYQVwUbjJChocG):
  if filename=='':return pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  try:
   fp=pOgxlseFyIkSAuEaPYQVwUbjJChoBL(filename,'w',-1,'utf-8')
   json.dump(pOgxlseFyIkSAuEaPYQVwUbjJChocG,fp,indent=4,ensure_ascii=pOgxlseFyIkSAuEaPYQVwUbjJChoBM)
   fp.close()
  except:
   return pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  return pOgxlseFyIkSAuEaPYQVwUbjJChoBK
 def JsonFile_Load(pOgxlseFyIkSAuEaPYQVwUbjJChocH,filename):
  if filename=='':return{}
  try:
   fp=pOgxlseFyIkSAuEaPYQVwUbjJChoBL(filename,'r',-1,'utf-8')
   pOgxlseFyIkSAuEaPYQVwUbjJChoct=json.load(fp)
   fp.close()
  except:
   return{}
  return pOgxlseFyIkSAuEaPYQVwUbjJChoct
 def Save_session_acount(pOgxlseFyIkSAuEaPYQVwUbjJChocH,pOgxlseFyIkSAuEaPYQVwUbjJChocR,pOgxlseFyIkSAuEaPYQVwUbjJChocn,pOgxlseFyIkSAuEaPYQVwUbjJChocv):
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['account']['wcid']=base64.standard_b64encode(pOgxlseFyIkSAuEaPYQVwUbjJChocR.encode()).decode('utf-8')
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['account']['wcpw']=base64.standard_b64encode(pOgxlseFyIkSAuEaPYQVwUbjJChocn.encode()).decode('utf-8')
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['account']['wcpf']=pOgxlseFyIkSAuEaPYQVwUbjJChocv 
 def Load_session_acount(pOgxlseFyIkSAuEaPYQVwUbjJChocH):
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChocR=base64.standard_b64decode(pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['account']['wcid']).decode('utf-8')
   pOgxlseFyIkSAuEaPYQVwUbjJChocn=base64.standard_b64decode(pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['account']['wcpw']).decode('utf-8')
   pOgxlseFyIkSAuEaPYQVwUbjJChocv=pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['account']['wcpf']
  except:
   return '','',0
  return pOgxlseFyIkSAuEaPYQVwUbjJChocR,pOgxlseFyIkSAuEaPYQVwUbjJChocn,pOgxlseFyIkSAuEaPYQVwUbjJChocv
 def Get_DeviceID(pOgxlseFyIkSAuEaPYQVwUbjJChocH,pOgxlseFyIkSAuEaPYQVwUbjJChoBr,pf):
  import hashlib
  m1=hashlib.md5()
  m2=hashlib.md5()
  pOgxlseFyIkSAuEaPYQVwUbjJChocM=pOgxlseFyIkSAuEaPYQVwUbjJChoBr+pOgxlseFyIkSAuEaPYQVwUbjJChoBW(pf)
  pOgxlseFyIkSAuEaPYQVwUbjJChocL=pOgxlseFyIkSAuEaPYQVwUbjJChoBW(pf)+pOgxlseFyIkSAuEaPYQVwUbjJChoBr
  m1.update(pOgxlseFyIkSAuEaPYQVwUbjJChocM.encode('utf-8'))
  m2.update(pOgxlseFyIkSAuEaPYQVwUbjJChocL.encode('utf-8'))
  pOgxlseFyIkSAuEaPYQVwUbjJChocK=pOgxlseFyIkSAuEaPYQVwUbjJChoBW(m1.hexdigest())
  pOgxlseFyIkSAuEaPYQVwUbjJChocr=pOgxlseFyIkSAuEaPYQVwUbjJChoBW(m2.hexdigest())
  pOgxlseFyIkSAuEaPYQVwUbjJChocW=pOgxlseFyIkSAuEaPYQVwUbjJChocK[:16]
  pOgxlseFyIkSAuEaPYQVwUbjJChoic='%s-%s-%s-%s-%s'%(pOgxlseFyIkSAuEaPYQVwUbjJChocr[:8],pOgxlseFyIkSAuEaPYQVwUbjJChocr[8:12],pOgxlseFyIkSAuEaPYQVwUbjJChocr[12:16],pOgxlseFyIkSAuEaPYQVwUbjJChocr[16:20],pOgxlseFyIkSAuEaPYQVwUbjJChocr[20:])
  return pOgxlseFyIkSAuEaPYQVwUbjJChocW,pOgxlseFyIkSAuEaPYQVwUbjJChoic
 def make_Random_Intstr(pOgxlseFyIkSAuEaPYQVwUbjJChocH,size):
  pOgxlseFyIkSAuEaPYQVwUbjJChoiH=string.digits 
  pOgxlseFyIkSAuEaPYQVwUbjJChoid=''
  for i in pOgxlseFyIkSAuEaPYQVwUbjJChomc(size):
   pOgxlseFyIkSAuEaPYQVwUbjJChoid+=random.choice(pOgxlseFyIkSAuEaPYQVwUbjJChoiH)
  return pOgxlseFyIkSAuEaPYQVwUbjJChoid
 def makeDefaultCookies(pOgxlseFyIkSAuEaPYQVwUbjJChocH):
  pOgxlseFyIkSAuEaPYQVwUbjJChoiB={'_s_guit':pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_guit'],'_guinness-premium_session':pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_token']}
  if pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_guitv']:
   pOgxlseFyIkSAuEaPYQVwUbjJChoiB['_s_guitv']=pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_guitv']
  return pOgxlseFyIkSAuEaPYQVwUbjJChoiB
 def GetCredential(pOgxlseFyIkSAuEaPYQVwUbjJChocH,user_id,user_pw,user_pf):
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChoim=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+'/api/session'
   pOgxlseFyIkSAuEaPYQVwUbjJChoiX={'email':user_id,'password':user_pw}
   pOgxlseFyIkSAuEaPYQVwUbjJChoif=pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiN={'accept':'application/vnd.frograms+json;version=4'}
   pOgxlseFyIkSAuEaPYQVwUbjJChoif.update(pOgxlseFyIkSAuEaPYQVwUbjJChoiN)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Post',pOgxlseFyIkSAuEaPYQVwUbjJChoim,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoiX,params=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoBv)
   for pOgxlseFyIkSAuEaPYQVwUbjJChoiD in pOgxlseFyIkSAuEaPYQVwUbjJChoiq.cookies:
    if pOgxlseFyIkSAuEaPYQVwUbjJChoiD.name=='_ale_session':
     pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_token']=pOgxlseFyIkSAuEaPYQVwUbjJChoiD.value
    elif pOgxlseFyIkSAuEaPYQVwUbjJChoiD.name=='_s_guit':
     pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_guit']=pOgxlseFyIkSAuEaPYQVwUbjJChoiD.value
   if pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_token']=='':
    pOgxlseFyIkSAuEaPYQVwUbjJChocH.Init_WC_Total()
    return pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
   pOgxlseFyIkSAuEaPYQVwUbjJChocH.Init_WC_Total()
   return pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  if pOgxlseFyIkSAuEaPYQVwUbjJChocH.GetProfilesList(user_pf)==pOgxlseFyIkSAuEaPYQVwUbjJChoBM:
   pOgxlseFyIkSAuEaPYQVwUbjJChocH.Init_WC_Total()
   return pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  if user_pf!=0:
   if pOgxlseFyIkSAuEaPYQVwUbjJChocH.GetProfilesConvert()==pOgxlseFyIkSAuEaPYQVwUbjJChoBM:
    pOgxlseFyIkSAuEaPYQVwUbjJChocH.Init_WC_Total()
    return pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  (pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['deviceId1'],pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['deviceId2'])=pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_DeviceID(user_id,user_pf)
  pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['flyerId']=pOgxlseFyIkSAuEaPYQVwUbjJChoBW(pOgxlseFyIkSAuEaPYQVwUbjJChomd(time.time()*1000))+'-'+pOgxlseFyIkSAuEaPYQVwUbjJChocH.make_Random_Intstr(19)
  return pOgxlseFyIkSAuEaPYQVwUbjJChoBK
 def GetProfilesList(pOgxlseFyIkSAuEaPYQVwUbjJChocH,user_pf):
  pOgxlseFyIkSAuEaPYQVwUbjJChoiz=[]
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/groups/members'
   pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.MAIN_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
   pOgxlseFyIkSAuEaPYQVwUbjJChoif=pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiD=pOgxlseFyIkSAuEaPYQVwUbjJChocH.makeDefaultCookies()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoiD,redirects=pOgxlseFyIkSAuEaPYQVwUbjJChoBK)
   pOgxlseFyIkSAuEaPYQVwUbjJChoit=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiz.append(pOgxlseFyIkSAuEaPYQVwUbjJChoit['naive_group']['chief_user']['code'])
   for pOgxlseFyIkSAuEaPYQVwUbjJChoiR in pOgxlseFyIkSAuEaPYQVwUbjJChoit['naive_group']['valid_memberships']:
    pOgxlseFyIkSAuEaPYQVwUbjJChoiz.append(pOgxlseFyIkSAuEaPYQVwUbjJChoiR['user']['code'])
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(pOgxlseFyIkSAuEaPYQVwUbjJChoiz)
   pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_usercd']=pOgxlseFyIkSAuEaPYQVwUbjJChoiz[user_pf]
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
   pOgxlseFyIkSAuEaPYQVwUbjJChocH.Init_WC_Total()
   return pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  return pOgxlseFyIkSAuEaPYQVwUbjJChoBK
 def GetProfilesConvert(pOgxlseFyIkSAuEaPYQVwUbjJChocH):
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/users/'+pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_usercd']+'/convert'
   pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
   pOgxlseFyIkSAuEaPYQVwUbjJChoif =pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiD =pOgxlseFyIkSAuEaPYQVwUbjJChocH.makeDefaultCookies()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Put',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoiD)
   for pOgxlseFyIkSAuEaPYQVwUbjJChoiD in pOgxlseFyIkSAuEaPYQVwUbjJChoiq.cookies:
    if pOgxlseFyIkSAuEaPYQVwUbjJChoiD.name=='_s_guitv':
     pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_guitv']=pOgxlseFyIkSAuEaPYQVwUbjJChoiD.value
    elif pOgxlseFyIkSAuEaPYQVwUbjJChoiD.name=='_guinness-premium_session':
     pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_token']=pOgxlseFyIkSAuEaPYQVwUbjJChoiD.value
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
   pOgxlseFyIkSAuEaPYQVwUbjJChocH.Init_WC_Total()
   return pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  return pOgxlseFyIkSAuEaPYQVwUbjJChoBK
 def GetSubGroupList(pOgxlseFyIkSAuEaPYQVwUbjJChocH,stype):
  pOgxlseFyIkSAuEaPYQVwUbjJChoin=[]
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/categories.json'
   pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
   pOgxlseFyIkSAuEaPYQVwUbjJChoif =pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiD =pOgxlseFyIkSAuEaPYQVwUbjJChocH.makeDefaultCookies()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoiD)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiv=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
   if not('genres' in pOgxlseFyIkSAuEaPYQVwUbjJChoiv):return pOgxlseFyIkSAuEaPYQVwUbjJChoin
   if stype=='genres':
    pOgxlseFyIkSAuEaPYQVwUbjJChoiM=pOgxlseFyIkSAuEaPYQVwUbjJChoiv['genres']
   else:
    pOgxlseFyIkSAuEaPYQVwUbjJChoiM=pOgxlseFyIkSAuEaPYQVwUbjJChoiv['tags']
   for pOgxlseFyIkSAuEaPYQVwUbjJChoiL in pOgxlseFyIkSAuEaPYQVwUbjJChoiM:
    pOgxlseFyIkSAuEaPYQVwUbjJChoiK=pOgxlseFyIkSAuEaPYQVwUbjJChoiL['name']
    pOgxlseFyIkSAuEaPYQVwUbjJChoir =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['api_path']
    pOgxlseFyIkSAuEaPYQVwUbjJChoiW =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['entity']['id']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHc={'group_name':pOgxlseFyIkSAuEaPYQVwUbjJChoiK,'api_path':pOgxlseFyIkSAuEaPYQVwUbjJChoir,'tag_id':pOgxlseFyIkSAuEaPYQVwUbjJChoBW(pOgxlseFyIkSAuEaPYQVwUbjJChoiW)}
    pOgxlseFyIkSAuEaPYQVwUbjJChoin.append(pOgxlseFyIkSAuEaPYQVwUbjJChoHc)
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
  return pOgxlseFyIkSAuEaPYQVwUbjJChoin
 def GetCategoryList(pOgxlseFyIkSAuEaPYQVwUbjJChocH,stype,pOgxlseFyIkSAuEaPYQVwUbjJChoiW,pOgxlseFyIkSAuEaPYQVwUbjJChoir,pOgxlseFyIkSAuEaPYQVwUbjJChodG):
  pOgxlseFyIkSAuEaPYQVwUbjJChoin=[]
  pOgxlseFyIkSAuEaPYQVwUbjJChoHi=pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  pOgxlseFyIkSAuEaPYQVwUbjJChoHd={}
  try:
   if 'categories' in pOgxlseFyIkSAuEaPYQVwUbjJChoir:
    pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/tags'
    pOgxlseFyIkSAuEaPYQVwUbjJChoHd['ids']=pOgxlseFyIkSAuEaPYQVwUbjJChoiW
   else: 
    pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/'+pOgxlseFyIkSAuEaPYQVwUbjJChoir+'.json'
    if pOgxlseFyIkSAuEaPYQVwUbjJChodG>1:
     pOgxlseFyIkSAuEaPYQVwUbjJChoHd['page']=pOgxlseFyIkSAuEaPYQVwUbjJChoBW(pOgxlseFyIkSAuEaPYQVwUbjJChodG)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
   pOgxlseFyIkSAuEaPYQVwUbjJChoif =pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiD =pOgxlseFyIkSAuEaPYQVwUbjJChocH.makeDefaultCookies()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoHd,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoiD)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiv=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
   if not('contents' in pOgxlseFyIkSAuEaPYQVwUbjJChoiv):return pOgxlseFyIkSAuEaPYQVwUbjJChoin,pOgxlseFyIkSAuEaPYQVwUbjJChoHi
   pOgxlseFyIkSAuEaPYQVwUbjJChoiM=pOgxlseFyIkSAuEaPYQVwUbjJChoiv['contents']
   pOgxlseFyIkSAuEaPYQVwUbjJChoHi=pOgxlseFyIkSAuEaPYQVwUbjJChoiv['meta']['has_next']
   for pOgxlseFyIkSAuEaPYQVwUbjJChoiL in pOgxlseFyIkSAuEaPYQVwUbjJChoiM:
    pOgxlseFyIkSAuEaPYQVwUbjJChoHB =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['code']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHm=pOgxlseFyIkSAuEaPYQVwUbjJChoiL['content_type']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHX =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['title']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHf =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['story']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHN =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['badge_text']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHq=pOgxlseFyIkSAuEaPYQVwUbjJChoBR=pOgxlseFyIkSAuEaPYQVwUbjJChoBt=''
    if pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('poster') !=pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoHq=pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('poster').get('original')
    if pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('stillcut')!=pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoBR =pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('stillcut').get('large')
    if pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('thumbnail')!=pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoBt=pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('thumbnail').get('large')
    if pOgxlseFyIkSAuEaPYQVwUbjJChoBt=='' :pOgxlseFyIkSAuEaPYQVwUbjJChoBt=pOgxlseFyIkSAuEaPYQVwUbjJChoBR
    pOgxlseFyIkSAuEaPYQVwUbjJChoHD={'thumb':pOgxlseFyIkSAuEaPYQVwUbjJChoBR,'poster':pOgxlseFyIkSAuEaPYQVwUbjJChoHq,'fanart':pOgxlseFyIkSAuEaPYQVwUbjJChoBt}
    pOgxlseFyIkSAuEaPYQVwUbjJChoHz =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['year']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHG =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['film_rating_code']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHT=pOgxlseFyIkSAuEaPYQVwUbjJChoiL['film_rating_short']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHt =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['film_rating_long']
    if pOgxlseFyIkSAuEaPYQVwUbjJChoHm=='movies':
     pOgxlseFyIkSAuEaPYQVwUbjJChoHR =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['duration']
    else:
     pOgxlseFyIkSAuEaPYQVwUbjJChoHR ='0'
    pOgxlseFyIkSAuEaPYQVwUbjJChoHc={'code':pOgxlseFyIkSAuEaPYQVwUbjJChoHB,'content_type':pOgxlseFyIkSAuEaPYQVwUbjJChoHm,'title':pOgxlseFyIkSAuEaPYQVwUbjJChoHX,'story':pOgxlseFyIkSAuEaPYQVwUbjJChoHf,'thumbnail':pOgxlseFyIkSAuEaPYQVwUbjJChoHD,'year':pOgxlseFyIkSAuEaPYQVwUbjJChoHz,'film_rating_code':pOgxlseFyIkSAuEaPYQVwUbjJChoHG,'film_rating_short':pOgxlseFyIkSAuEaPYQVwUbjJChoHT,'film_rating_long':pOgxlseFyIkSAuEaPYQVwUbjJChoHt,'duration':pOgxlseFyIkSAuEaPYQVwUbjJChoHR,'badge':pOgxlseFyIkSAuEaPYQVwUbjJChoHN,}
    pOgxlseFyIkSAuEaPYQVwUbjJChoin.append(pOgxlseFyIkSAuEaPYQVwUbjJChoHc)
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
  return pOgxlseFyIkSAuEaPYQVwUbjJChoin,pOgxlseFyIkSAuEaPYQVwUbjJChoHi
 def GetProgramInfo(pOgxlseFyIkSAuEaPYQVwUbjJChocH,program_code):
  pOgxlseFyIkSAuEaPYQVwUbjJChoHn={}
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/contents/'+program_code
   pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
   pOgxlseFyIkSAuEaPYQVwUbjJChoif=pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoBv)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiv=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
   pOgxlseFyIkSAuEaPYQVwUbjJChoHv=img_clearlogo=''
   pOgxlseFyIkSAuEaPYQVwUbjJChoHv=pOgxlseFyIkSAuEaPYQVwUbjJChoiv.get('poster').get('original')
   if pOgxlseFyIkSAuEaPYQVwUbjJChomB(pOgxlseFyIkSAuEaPYQVwUbjJChoiv.get('title_logos'))>0:img_clearlogo=pOgxlseFyIkSAuEaPYQVwUbjJChoiv.get('title_logos')[0].get('src')
   pOgxlseFyIkSAuEaPYQVwUbjJChoHn={'imgPoster':pOgxlseFyIkSAuEaPYQVwUbjJChoHv,'imgClearlogo':img_clearlogo}
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
  return pOgxlseFyIkSAuEaPYQVwUbjJChoHn
 def GetSeasonList(pOgxlseFyIkSAuEaPYQVwUbjJChocH,program_code):
  pOgxlseFyIkSAuEaPYQVwUbjJChoHM=[]
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/aio_contents/'+program_code
   pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
   pOgxlseFyIkSAuEaPYQVwUbjJChoif =pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoBv)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiv=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
   if not('result' in pOgxlseFyIkSAuEaPYQVwUbjJChoiv):return pOgxlseFyIkSAuEaPYQVwUbjJChoHM
   for pOgxlseFyIkSAuEaPYQVwUbjJChoiL in pOgxlseFyIkSAuEaPYQVwUbjJChoiv.get('result').get('seasons'):
    pOgxlseFyIkSAuEaPYQVwUbjJChoHL =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['id']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHK =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['titles']['short']or pOgxlseFyIkSAuEaPYQVwUbjJChoiL['titles']['original']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHc={'seasonId':pOgxlseFyIkSAuEaPYQVwUbjJChoHL,'seasonNm':pOgxlseFyIkSAuEaPYQVwUbjJChoHK,}
    pOgxlseFyIkSAuEaPYQVwUbjJChoHM.append(pOgxlseFyIkSAuEaPYQVwUbjJChoHc)
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
  return pOgxlseFyIkSAuEaPYQVwUbjJChoHM
 def GetEpisodoList(pOgxlseFyIkSAuEaPYQVwUbjJChocH,program_code,pOgxlseFyIkSAuEaPYQVwUbjJChodG,orderby='asc'):
  pOgxlseFyIkSAuEaPYQVwUbjJChoin=[]
  pOgxlseFyIkSAuEaPYQVwUbjJChoHi=pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  pOgxlseFyIkSAuEaPYQVwUbjJChoHr=''
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/contents/'+program_code+'/tv_episodes.json'
   pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
   pOgxlseFyIkSAuEaPYQVwUbjJChoHd={'all':'true'}
   pOgxlseFyIkSAuEaPYQVwUbjJChoif =pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoHd,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoBv)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiv=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
   if not('tv_episode_codes' in pOgxlseFyIkSAuEaPYQVwUbjJChoiv):return pOgxlseFyIkSAuEaPYQVwUbjJChoin,pOgxlseFyIkSAuEaPYQVwUbjJChoHi
   pOgxlseFyIkSAuEaPYQVwUbjJChoiM=pOgxlseFyIkSAuEaPYQVwUbjJChoiv['tv_episode_codes']
   pOgxlseFyIkSAuEaPYQVwUbjJChoHW=pOgxlseFyIkSAuEaPYQVwUbjJChomB(pOgxlseFyIkSAuEaPYQVwUbjJChoiM)
   pOgxlseFyIkSAuEaPYQVwUbjJChodc =pOgxlseFyIkSAuEaPYQVwUbjJChomd(pOgxlseFyIkSAuEaPYQVwUbjJChoHW//(pOgxlseFyIkSAuEaPYQVwUbjJChocH.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    pOgxlseFyIkSAuEaPYQVwUbjJChodi =(pOgxlseFyIkSAuEaPYQVwUbjJChoHW-1)-((pOgxlseFyIkSAuEaPYQVwUbjJChodG-1)*pOgxlseFyIkSAuEaPYQVwUbjJChocH.EPISODE_LIMIT)
   else:
    pOgxlseFyIkSAuEaPYQVwUbjJChodi =(pOgxlseFyIkSAuEaPYQVwUbjJChodG-1)*pOgxlseFyIkSAuEaPYQVwUbjJChocH.EPISODE_LIMIT
   for i in pOgxlseFyIkSAuEaPYQVwUbjJChomc(pOgxlseFyIkSAuEaPYQVwUbjJChocH.EPISODE_LIMIT):
    if orderby=='desc':
     pOgxlseFyIkSAuEaPYQVwUbjJChodH=pOgxlseFyIkSAuEaPYQVwUbjJChodi-i
     if pOgxlseFyIkSAuEaPYQVwUbjJChodH<0:break
    else:
     pOgxlseFyIkSAuEaPYQVwUbjJChodH=pOgxlseFyIkSAuEaPYQVwUbjJChodi+i
     if pOgxlseFyIkSAuEaPYQVwUbjJChodH>=pOgxlseFyIkSAuEaPYQVwUbjJChoHW:break
    if pOgxlseFyIkSAuEaPYQVwUbjJChoHr!='':pOgxlseFyIkSAuEaPYQVwUbjJChoHr+=','
    pOgxlseFyIkSAuEaPYQVwUbjJChoHr+=pOgxlseFyIkSAuEaPYQVwUbjJChoiM[pOgxlseFyIkSAuEaPYQVwUbjJChodH]
   if pOgxlseFyIkSAuEaPYQVwUbjJChodc>pOgxlseFyIkSAuEaPYQVwUbjJChodG:pOgxlseFyIkSAuEaPYQVwUbjJChoHi=pOgxlseFyIkSAuEaPYQVwUbjJChoBK
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
  pOgxlseFyIkSAuEaPYQVwUbjJChodB=pOgxlseFyIkSAuEaPYQVwUbjJChocH.GetProgramInfo(program_code)
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
   pOgxlseFyIkSAuEaPYQVwUbjJChoHd={'codes':pOgxlseFyIkSAuEaPYQVwUbjJChoHr}
   pOgxlseFyIkSAuEaPYQVwUbjJChoif =pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoHd,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoBv)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiv=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
   if not('tv_episodes' in pOgxlseFyIkSAuEaPYQVwUbjJChoiv):return pOgxlseFyIkSAuEaPYQVwUbjJChoin
   pOgxlseFyIkSAuEaPYQVwUbjJChoiM=pOgxlseFyIkSAuEaPYQVwUbjJChoiv['tv_episodes']
   for pOgxlseFyIkSAuEaPYQVwUbjJChoiL in pOgxlseFyIkSAuEaPYQVwUbjJChoiM:
    pOgxlseFyIkSAuEaPYQVwUbjJChoHB =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['code']
    if pOgxlseFyIkSAuEaPYQVwUbjJChoiL['title']:
     pOgxlseFyIkSAuEaPYQVwUbjJChoHX =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['title']
    else:
     pOgxlseFyIkSAuEaPYQVwUbjJChoHX =''
    pOgxlseFyIkSAuEaPYQVwUbjJChoHq=pOgxlseFyIkSAuEaPYQVwUbjJChoBR=pOgxlseFyIkSAuEaPYQVwUbjJChoBt=pOgxlseFyIkSAuEaPYQVwUbjJChodm=''
    pOgxlseFyIkSAuEaPYQVwUbjJChoHq =pOgxlseFyIkSAuEaPYQVwUbjJChodB.get('imgPoster')
    pOgxlseFyIkSAuEaPYQVwUbjJChodm=pOgxlseFyIkSAuEaPYQVwUbjJChodB.get('imgClearlogo')
    if pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('stillcut') !=pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoBR =pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('stillcut').get('large')
    if pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('tv_season_stillcut')!=pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoBt=pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('tv_season_stillcut').get('large')
    pOgxlseFyIkSAuEaPYQVwUbjJChoHD={'thumb':pOgxlseFyIkSAuEaPYQVwUbjJChoBR,'poster':pOgxlseFyIkSAuEaPYQVwUbjJChoHq,'fanart':pOgxlseFyIkSAuEaPYQVwUbjJChoBt,'clearlogo':pOgxlseFyIkSAuEaPYQVwUbjJChodm}
    pOgxlseFyIkSAuEaPYQVwUbjJChodX =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['display_number']
    pOgxlseFyIkSAuEaPYQVwUbjJChodf=pOgxlseFyIkSAuEaPYQVwUbjJChoiL['tv_season_title']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHR =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['duration']
    try:
     pOgxlseFyIkSAuEaPYQVwUbjJChodN=pOgxlseFyIkSAuEaPYQVwUbjJChoiL['episode_number']
    except:
     pOgxlseFyIkSAuEaPYQVwUbjJChodN='0'
    pOgxlseFyIkSAuEaPYQVwUbjJChoHc={'code':pOgxlseFyIkSAuEaPYQVwUbjJChoHB,'title':pOgxlseFyIkSAuEaPYQVwUbjJChoHX,'thumbnail':pOgxlseFyIkSAuEaPYQVwUbjJChoHD,'display_num':pOgxlseFyIkSAuEaPYQVwUbjJChodX,'season_title':pOgxlseFyIkSAuEaPYQVwUbjJChodf,'duration':pOgxlseFyIkSAuEaPYQVwUbjJChoHR,'episode_number':pOgxlseFyIkSAuEaPYQVwUbjJChodN}
    pOgxlseFyIkSAuEaPYQVwUbjJChoin.append(pOgxlseFyIkSAuEaPYQVwUbjJChoHc)
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
  return pOgxlseFyIkSAuEaPYQVwUbjJChoin,pOgxlseFyIkSAuEaPYQVwUbjJChoHi
 def GetHomeList_bak(pOgxlseFyIkSAuEaPYQVwUbjJChocH):
  pOgxlseFyIkSAuEaPYQVwUbjJChodq=[]
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/aio_browses/video/header'
   pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
   pOgxlseFyIkSAuEaPYQVwUbjJChoif=pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiB=pOgxlseFyIkSAuEaPYQVwUbjJChocH.makeDefaultCookies()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoiB)
   pOgxlseFyIkSAuEaPYQVwUbjJChoit=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
   if not('result' in pOgxlseFyIkSAuEaPYQVwUbjJChoit):return pOgxlseFyIkSAuEaPYQVwUbjJChodq
   pOgxlseFyIkSAuEaPYQVwUbjJChoiM=pOgxlseFyIkSAuEaPYQVwUbjJChoit['result'][0]['cells']
   for pOgxlseFyIkSAuEaPYQVwUbjJChoiL in pOgxlseFyIkSAuEaPYQVwUbjJChoiM:
    pOgxlseFyIkSAuEaPYQVwUbjJChoHm=pOgxlseFyIkSAuEaPYQVwUbjJChoiL['relations'][0]['type']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHX =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['title']
    pOgxlseFyIkSAuEaPYQVwUbjJChodD =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['badge']
    pOgxlseFyIkSAuEaPYQVwUbjJChodz =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['media']['fullhd']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHD ={'thumb':pOgxlseFyIkSAuEaPYQVwUbjJChodz,'fanart':pOgxlseFyIkSAuEaPYQVwUbjJChodz}
    pOgxlseFyIkSAuEaPYQVwUbjJChoHB =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['relations'][0]['id']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHc={'code':pOgxlseFyIkSAuEaPYQVwUbjJChoHB,'content_type':pOgxlseFyIkSAuEaPYQVwUbjJChoHm,'title':pOgxlseFyIkSAuEaPYQVwUbjJChoHX,'bedge':pOgxlseFyIkSAuEaPYQVwUbjJChodD,'thumbnail':pOgxlseFyIkSAuEaPYQVwUbjJChoHD}
    pOgxlseFyIkSAuEaPYQVwUbjJChodq.append(pOgxlseFyIkSAuEaPYQVwUbjJChoHc)
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
  return pOgxlseFyIkSAuEaPYQVwUbjJChodq
 def GetHomeList(pOgxlseFyIkSAuEaPYQVwUbjJChocH):
  pOgxlseFyIkSAuEaPYQVwUbjJChodq=[]
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/aio_browses/video/all'
   pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
   pOgxlseFyIkSAuEaPYQVwUbjJChoif=pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiB=pOgxlseFyIkSAuEaPYQVwUbjJChocH.makeDefaultCookies()
   pOgxlseFyIkSAuEaPYQVwUbjJChodG=1
   pOgxlseFyIkSAuEaPYQVwUbjJChoHi=pOgxlseFyIkSAuEaPYQVwUbjJChoBK
   while pOgxlseFyIkSAuEaPYQVwUbjJChoHi:
    pOgxlseFyIkSAuEaPYQVwUbjJChocd={'page':pOgxlseFyIkSAuEaPYQVwUbjJChoBW(pOgxlseFyIkSAuEaPYQVwUbjJChodG)}
    pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChocd,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoiB)
    pOgxlseFyIkSAuEaPYQVwUbjJChoit=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
    if not('result' in pOgxlseFyIkSAuEaPYQVwUbjJChoit):return pOgxlseFyIkSAuEaPYQVwUbjJChodq
    pOgxlseFyIkSAuEaPYQVwUbjJChoiM=pOgxlseFyIkSAuEaPYQVwUbjJChoit['result']['items']
    for pOgxlseFyIkSAuEaPYQVwUbjJChoiL in pOgxlseFyIkSAuEaPYQVwUbjJChoiM:
     pOgxlseFyIkSAuEaPYQVwUbjJChoHm=pOgxlseFyIkSAuEaPYQVwUbjJChoiL['type']
     if pOgxlseFyIkSAuEaPYQVwUbjJChoHm in['custom_list']:
      pOgxlseFyIkSAuEaPYQVwUbjJChoHc={'code':pOgxlseFyIkSAuEaPYQVwUbjJChoiL['relations'][0]['id'],'content_type':pOgxlseFyIkSAuEaPYQVwUbjJChoiL['relations'][0]['type'],'title':pOgxlseFyIkSAuEaPYQVwUbjJChoiL['title'],}
      pOgxlseFyIkSAuEaPYQVwUbjJChodq.append(pOgxlseFyIkSAuEaPYQVwUbjJChoHc)
    pOgxlseFyIkSAuEaPYQVwUbjJChodG+=1
    if pOgxlseFyIkSAuEaPYQVwUbjJChoit['result']['next']==pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoHi=pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
  return pOgxlseFyIkSAuEaPYQVwUbjJChodq
 def GetSearchList(pOgxlseFyIkSAuEaPYQVwUbjJChocH,search_key,pOgxlseFyIkSAuEaPYQVwUbjJChodG):
  pOgxlseFyIkSAuEaPYQVwUbjJChodT=[]
  pOgxlseFyIkSAuEaPYQVwUbjJChoHi=pOgxlseFyIkSAuEaPYQVwUbjJChoBM
  try:
   pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/search.json'
   pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
   pOgxlseFyIkSAuEaPYQVwUbjJChoHd={'query':search_key,'page':pOgxlseFyIkSAuEaPYQVwUbjJChoBW(pOgxlseFyIkSAuEaPYQVwUbjJChodG),'per':pOgxlseFyIkSAuEaPYQVwUbjJChoBW(pOgxlseFyIkSAuEaPYQVwUbjJChocH.SEARCH_LIMIT),'exclude':'limited'}
   pOgxlseFyIkSAuEaPYQVwUbjJChoif=pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoHd,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoBv)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiv=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
   if not('results' in pOgxlseFyIkSAuEaPYQVwUbjJChoiv):return pOgxlseFyIkSAuEaPYQVwUbjJChodT,pOgxlseFyIkSAuEaPYQVwUbjJChoHi
   pOgxlseFyIkSAuEaPYQVwUbjJChoiM=pOgxlseFyIkSAuEaPYQVwUbjJChoiv['results']
   pOgxlseFyIkSAuEaPYQVwUbjJChoHi=pOgxlseFyIkSAuEaPYQVwUbjJChoiv['meta']['has_next']
   for pOgxlseFyIkSAuEaPYQVwUbjJChoiL in pOgxlseFyIkSAuEaPYQVwUbjJChoiM:
    pOgxlseFyIkSAuEaPYQVwUbjJChoHB =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['code']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHm=pOgxlseFyIkSAuEaPYQVwUbjJChoiL['content_type']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHX =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['title']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHf =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['story']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHq=pOgxlseFyIkSAuEaPYQVwUbjJChoBR=pOgxlseFyIkSAuEaPYQVwUbjJChoBt=''
    if pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('poster') !=pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoHq=pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('poster').get('original')
    if pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('stillcut')!=pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoBR =pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('stillcut').get('large')
    if pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('thumbnail')!=pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoBt=pOgxlseFyIkSAuEaPYQVwUbjJChoiL.get('thumbnail').get('large')
    if pOgxlseFyIkSAuEaPYQVwUbjJChoBt=='' :pOgxlseFyIkSAuEaPYQVwUbjJChoBt=pOgxlseFyIkSAuEaPYQVwUbjJChoBR
    pOgxlseFyIkSAuEaPYQVwUbjJChoHD={'thumb':pOgxlseFyIkSAuEaPYQVwUbjJChoBR,'poster':pOgxlseFyIkSAuEaPYQVwUbjJChoHq,'fanart':pOgxlseFyIkSAuEaPYQVwUbjJChoBt}
    pOgxlseFyIkSAuEaPYQVwUbjJChoHz =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['year']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHG =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['film_rating_code']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHT=pOgxlseFyIkSAuEaPYQVwUbjJChoiL['film_rating_short']
    pOgxlseFyIkSAuEaPYQVwUbjJChoHt =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['film_rating_long']
    if pOgxlseFyIkSAuEaPYQVwUbjJChoHm=='movies':
     pOgxlseFyIkSAuEaPYQVwUbjJChoHR =pOgxlseFyIkSAuEaPYQVwUbjJChoiL['duration']
    else:
     pOgxlseFyIkSAuEaPYQVwUbjJChoHR ='0'
    pOgxlseFyIkSAuEaPYQVwUbjJChoHc={'code':pOgxlseFyIkSAuEaPYQVwUbjJChoHB,'content_type':pOgxlseFyIkSAuEaPYQVwUbjJChoHm,'title':pOgxlseFyIkSAuEaPYQVwUbjJChoHX,'story':pOgxlseFyIkSAuEaPYQVwUbjJChoHf,'thumbnail':pOgxlseFyIkSAuEaPYQVwUbjJChoHD,'year':pOgxlseFyIkSAuEaPYQVwUbjJChoHz,'film_rating_code':pOgxlseFyIkSAuEaPYQVwUbjJChoHG,'film_rating_short':pOgxlseFyIkSAuEaPYQVwUbjJChoHT,'film_rating_long':pOgxlseFyIkSAuEaPYQVwUbjJChoHt,'duration':pOgxlseFyIkSAuEaPYQVwUbjJChoHR}
    pOgxlseFyIkSAuEaPYQVwUbjJChodT.append(pOgxlseFyIkSAuEaPYQVwUbjJChoHc)
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
  return pOgxlseFyIkSAuEaPYQVwUbjJChodT,pOgxlseFyIkSAuEaPYQVwUbjJChoHi
 def DeleteContinueList(pOgxlseFyIkSAuEaPYQVwUbjJChocH,codeList):
  try:
   for pOgxlseFyIkSAuEaPYQVwUbjJChodt in codeList:
    pOgxlseFyIkSAuEaPYQVwUbjJChoiG ='/api/watches/'+pOgxlseFyIkSAuEaPYQVwUbjJChodt
    pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
    pOgxlseFyIkSAuEaPYQVwUbjJChoif =pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
    pOgxlseFyIkSAuEaPYQVwUbjJChoiD =pOgxlseFyIkSAuEaPYQVwUbjJChocH.makeDefaultCookies()
    pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Delete',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,params=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoiD)
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   pOgxlseFyIkSAuEaPYQVwUbjJChomH(exception)
 def Get_Now_Datetime(pOgxlseFyIkSAuEaPYQVwUbjJChocH):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetStreamingURL(pOgxlseFyIkSAuEaPYQVwUbjJChocH,movie_code,quality_str,proxyUse=pOgxlseFyIkSAuEaPYQVwUbjJChoBM,inScreen='BASE',inSound='2CH'):
  pOgxlseFyIkSAuEaPYQVwUbjJChodn={'streamUrl':'','subtitleUrl':'','customdata':'',}
  try:
   if proxyUse:
    pOgxlseFyIkSAuEaPYQVwUbjJChodv ='0' if inScreen=='BASE' and inSound=='2CH' else '3'
    pOgxlseFyIkSAuEaPYQVwUbjJChodM='4' if inScreen=='VISION' else '1'
    pOgxlseFyIkSAuEaPYQVwUbjJChodL ='0' if inSound!='ATMOS' else '1'
    pOgxlseFyIkSAuEaPYQVwUbjJChomH('hCodec  = '+pOgxlseFyIkSAuEaPYQVwUbjJChodv)
    pOgxlseFyIkSAuEaPYQVwUbjJChomH('hScreen = '+pOgxlseFyIkSAuEaPYQVwUbjJChodM)
    pOgxlseFyIkSAuEaPYQVwUbjJChomH('hSound  = '+pOgxlseFyIkSAuEaPYQVwUbjJChodL)
    pOgxlseFyIkSAuEaPYQVwUbjJChoiG='/api/watch/'+movie_code+'.json?localtracks=%5B%5D&player_v2=true'
    pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
    pOgxlseFyIkSAuEaPYQVwUbjJChoif=pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers_v2()
    pOgxlseFyIkSAuEaPYQVwUbjJChoiN={'X-FROGRAMS-MARS-CODEC-FLAG':pOgxlseFyIkSAuEaPYQVwUbjJChodv,'X-WatchaPlay-Client-Codec-Flag':pOgxlseFyIkSAuEaPYQVwUbjJChodv,'X-FROGRAMS-MARS-HDR-CAPABILITIES':pOgxlseFyIkSAuEaPYQVwUbjJChodM,'X-WatchaPlay-Client-HDR-Capabilities':pOgxlseFyIkSAuEaPYQVwUbjJChodM,'X-FROGRAMS-MARS-AUDIO-CAPABILITIES':pOgxlseFyIkSAuEaPYQVwUbjJChodL,'X-WatchaPlay-Client-Audio-Capabilities':pOgxlseFyIkSAuEaPYQVwUbjJChodL,}
    pOgxlseFyIkSAuEaPYQVwUbjJChoif.update(pOgxlseFyIkSAuEaPYQVwUbjJChoiN)
   else:
    pOgxlseFyIkSAuEaPYQVwUbjJChoiG='/api/watch/'+movie_code+'.json'
    pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+pOgxlseFyIkSAuEaPYQVwUbjJChoiG
    pOgxlseFyIkSAuEaPYQVwUbjJChoif=pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
    pOgxlseFyIkSAuEaPYQVwUbjJChoiN={'x-watchaplay-client-codec-flag':'3','x-watchaplay-media-devices-info':'1','x-watchaplay-screen':quality_str,}
    pOgxlseFyIkSAuEaPYQVwUbjJChoif.update(pOgxlseFyIkSAuEaPYQVwUbjJChoiN)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiD=pOgxlseFyIkSAuEaPYQVwUbjJChocH.makeDefaultCookies()
   pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoiD)
   pOgxlseFyIkSAuEaPYQVwUbjJChoiv=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
   pOgxlseFyIkSAuEaPYQVwUbjJChodn['streamUrl']=pOgxlseFyIkSAuEaPYQVwUbjJChoiv['streams'][0]['source']
   if pOgxlseFyIkSAuEaPYQVwUbjJChodn['streamUrl']==pOgxlseFyIkSAuEaPYQVwUbjJChoBv:return pOgxlseFyIkSAuEaPYQVwUbjJChodn
   if 'subtitles' in pOgxlseFyIkSAuEaPYQVwUbjJChoiv['streams'][0]:
    for pOgxlseFyIkSAuEaPYQVwUbjJChodK in pOgxlseFyIkSAuEaPYQVwUbjJChoiv['streams'][0]['subtitles']:
     if pOgxlseFyIkSAuEaPYQVwUbjJChodK['lang']=='ko':
      pOgxlseFyIkSAuEaPYQVwUbjJChodn['subtitleUrl']=pOgxlseFyIkSAuEaPYQVwUbjJChodK['url']
      break
   pOgxlseFyIkSAuEaPYQVwUbjJChodr =pOgxlseFyIkSAuEaPYQVwUbjJChoiv['ping_payload']
   pOgxlseFyIkSAuEaPYQVwUbjJChodW =pOgxlseFyIkSAuEaPYQVwUbjJChocH.WC['cookies']['watcha_usercd']
   pOgxlseFyIkSAuEaPYQVwUbjJChoBc={'merchant':'giitd_frograms','sessionId':pOgxlseFyIkSAuEaPYQVwUbjJChodr,'userId':pOgxlseFyIkSAuEaPYQVwUbjJChodW}
   pOgxlseFyIkSAuEaPYQVwUbjJChoBi=json.dumps(pOgxlseFyIkSAuEaPYQVwUbjJChoBc,separators=(",",":")).encode('UTF-8')
   pOgxlseFyIkSAuEaPYQVwUbjJChodn['customdata']=base64.b64encode(pOgxlseFyIkSAuEaPYQVwUbjJChoBi)
  except pOgxlseFyIkSAuEaPYQVwUbjJChomi as exception:
   return pOgxlseFyIkSAuEaPYQVwUbjJChodn
  return pOgxlseFyIkSAuEaPYQVwUbjJChodn
 def GetBookmarkInfo(pOgxlseFyIkSAuEaPYQVwUbjJChocH,videoid,vidtype):
  pOgxlseFyIkSAuEaPYQVwUbjJChoBH={'indexinfo':{'ott':'watcha','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  pOgxlseFyIkSAuEaPYQVwUbjJChoiT=pOgxlseFyIkSAuEaPYQVwUbjJChocH.API_DOMAIN+'/api/contents/'+videoid
  pOgxlseFyIkSAuEaPYQVwUbjJChoif=pOgxlseFyIkSAuEaPYQVwUbjJChocH.Get_Base_Headers()
  pOgxlseFyIkSAuEaPYQVwUbjJChoiq=pOgxlseFyIkSAuEaPYQVwUbjJChocH.callRequestCookies('Get',pOgxlseFyIkSAuEaPYQVwUbjJChoiT,payload=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,params=pOgxlseFyIkSAuEaPYQVwUbjJChoBv,headers=pOgxlseFyIkSAuEaPYQVwUbjJChoif,cookies=pOgxlseFyIkSAuEaPYQVwUbjJChoBv)
  pOgxlseFyIkSAuEaPYQVwUbjJChoit=json.loads(pOgxlseFyIkSAuEaPYQVwUbjJChoiq.text)
  if not('title' in pOgxlseFyIkSAuEaPYQVwUbjJChoit):return{}
  pOgxlseFyIkSAuEaPYQVwUbjJChoBd=pOgxlseFyIkSAuEaPYQVwUbjJChoit
  pOgxlseFyIkSAuEaPYQVwUbjJChomH(pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('duration'))
  pOgxlseFyIkSAuEaPYQVwUbjJChoBm=pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('title')
  pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['infoLabels']['title']=pOgxlseFyIkSAuEaPYQVwUbjJChoBm
  pOgxlseFyIkSAuEaPYQVwUbjJChoBm +=u'  (%s)'%(pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('year'))
  pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['title'] =pOgxlseFyIkSAuEaPYQVwUbjJChoBm
  pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['infoLabels']['mpaa'] =pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('film_rating_long')
  pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['infoLabels']['plot'] =pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('story').replace('<br>','\n')
  pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['infoLabels']['year'] =pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('year')
  if vidtype=='movie':
   pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['infoLabels']['duration']=pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('duration')
  pOgxlseFyIkSAuEaPYQVwUbjJChoBX=[]
  for pOgxlseFyIkSAuEaPYQVwUbjJChoBf in pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('actors'):
   pOgxlseFyIkSAuEaPYQVwUbjJChoBN =pOgxlseFyIkSAuEaPYQVwUbjJChoBf.get('name')
   pOgxlseFyIkSAuEaPYQVwUbjJChoBq='' if pOgxlseFyIkSAuEaPYQVwUbjJChoBf.get('photo')==pOgxlseFyIkSAuEaPYQVwUbjJChoBv else pOgxlseFyIkSAuEaPYQVwUbjJChoBf.get('photo').get('small')
   pOgxlseFyIkSAuEaPYQVwUbjJChoBX.append({'name':pOgxlseFyIkSAuEaPYQVwUbjJChoBN,'thumbnail':pOgxlseFyIkSAuEaPYQVwUbjJChoBq})
  if pOgxlseFyIkSAuEaPYQVwUbjJChomB(pOgxlseFyIkSAuEaPYQVwUbjJChoBX)>0:
   pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['infoLabels']['cast']=pOgxlseFyIkSAuEaPYQVwUbjJChoBX
  pOgxlseFyIkSAuEaPYQVwUbjJChoBD=[]
  for pOgxlseFyIkSAuEaPYQVwUbjJChoBz in pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('directors'):pOgxlseFyIkSAuEaPYQVwUbjJChoBD.append(pOgxlseFyIkSAuEaPYQVwUbjJChoBz.get('name'))
  if pOgxlseFyIkSAuEaPYQVwUbjJChomB(pOgxlseFyIkSAuEaPYQVwUbjJChoBD)>0:
   pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['infoLabels']['director']=pOgxlseFyIkSAuEaPYQVwUbjJChoBD
  pOgxlseFyIkSAuEaPYQVwUbjJChoBG=[]
  for pOgxlseFyIkSAuEaPYQVwUbjJChoBT in pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('genres'):pOgxlseFyIkSAuEaPYQVwUbjJChoBG.append(pOgxlseFyIkSAuEaPYQVwUbjJChoBT.get('name'))
  if pOgxlseFyIkSAuEaPYQVwUbjJChomB(pOgxlseFyIkSAuEaPYQVwUbjJChoBG)>0:
   pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['infoLabels']['genre']=pOgxlseFyIkSAuEaPYQVwUbjJChoBG
  pOgxlseFyIkSAuEaPYQVwUbjJChoHq =''
  pOgxlseFyIkSAuEaPYQVwUbjJChoBt =''
  pOgxlseFyIkSAuEaPYQVwUbjJChoBR =''
  if pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('poster') !=pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoHq =pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('poster').get('original')
  if pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('thumbnail')!=pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoBt =pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('thumbnail').get('large')
  if pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('stillcut')!=pOgxlseFyIkSAuEaPYQVwUbjJChoBv:pOgxlseFyIkSAuEaPYQVwUbjJChoBR =pOgxlseFyIkSAuEaPYQVwUbjJChoBd.get('stillcut').get('large')
  if pOgxlseFyIkSAuEaPYQVwUbjJChoBt=='':pOgxlseFyIkSAuEaPYQVwUbjJChoBt=pOgxlseFyIkSAuEaPYQVwUbjJChoBR
  pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['thumbnail']['poster']=pOgxlseFyIkSAuEaPYQVwUbjJChoHq
  pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['thumbnail']['fanart']=pOgxlseFyIkSAuEaPYQVwUbjJChoBt
  pOgxlseFyIkSAuEaPYQVwUbjJChoBH['saveinfo']['thumbnail']['thumb']=pOgxlseFyIkSAuEaPYQVwUbjJChoBR
  return pOgxlseFyIkSAuEaPYQVwUbjJChoBH
# Created by pyminifier (https://github.com/liftoff/pyminifier)
