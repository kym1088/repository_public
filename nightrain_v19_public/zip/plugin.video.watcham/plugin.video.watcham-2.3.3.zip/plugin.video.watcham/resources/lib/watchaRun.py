__author__="NightRain"
nEUpGhmyoQOvRfCIxbPVSDaLMkdTsN=object
nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA=None
nEUpGhmyoQOvRfCIxbPVSDaLMkdTst=int
nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH=True
nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu=False
nEUpGhmyoQOvRfCIxbPVSDaLMkdTsK=type
nEUpGhmyoQOvRfCIxbPVSDaLMkdTsW=dict
nEUpGhmyoQOvRfCIxbPVSDaLMkdTsw=getattr
nEUpGhmyoQOvRfCIxbPVSDaLMkdTsg=list
nEUpGhmyoQOvRfCIxbPVSDaLMkdTsB=len
nEUpGhmyoQOvRfCIxbPVSDaLMkdTse=range
nEUpGhmyoQOvRfCIxbPVSDaLMkdTsF=str
nEUpGhmyoQOvRfCIxbPVSDaLMkdTsl=open
from ast import Pass
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
nEUpGhmyoQOvRfCIxbPVSDaLMkdTzq=[{'title':'홈','mode':'HOME_GROUP','stype':'-','api_path':'-'},{'title':'오직 왓챠에서!','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/6100'},{'title':'왓플 최고 인기작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/409'},{'title':'4K / HDR, ATOMOS 지원작','mode':'CATEGORY_LIST','stype':'-','api_path':'staffmades/3025'},{'title':'새로 올라온 작품','mode':'CATEGORY_LIST','stype':'-','api_path':'arrivals/latest'},{'title':'장르별 둘러보기','mode':'SUB_GROUP','stype':'genres','api_path':'-'},{'title':'특징별 둘러보기','mode':'SUB_GROUP','stype':'tags','api_path':'-'},{'title':'이어보기 (시청이력)','mode':'CATEGORY_LIST','stype':'-','api_path':'users/me/watchings'},{'title':'-----------------','mode':'XXX','stype':'XXX','api_path':'-'},{'title':'(왓챠) 검색','mode':'LOCAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'(왓챠) 검색기록','mode':'SEARCH_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','api_path':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','api_path':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','api_path':'-','icon':'bookmark.png'},]
nEUpGhmyoQOvRfCIxbPVSDaLMkdTzc=[{'title':'영화 시청내역','mode':'WATCH','stype':'movie'},{'title':'시리즈 시청내역','mode':'WATCH','stype':'seasons'}]
nEUpGhmyoQOvRfCIxbPVSDaLMkdTzY={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
nEUpGhmyoQOvRfCIxbPVSDaLMkdTzJ=40
nEUpGhmyoQOvRfCIxbPVSDaLMkdTzr =30
from watchaCore import*
class nEUpGhmyoQOvRfCIxbPVSDaLMkdTzj(nEUpGhmyoQOvRfCIxbPVSDaLMkdTsN):
 def __init__(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzi,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzN,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzA):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_url =nEUpGhmyoQOvRfCIxbPVSDaLMkdTzi
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzN
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params =nEUpGhmyoQOvRfCIxbPVSDaLMkdTzA
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj =pOgxlseFyIkSAuEaPYQVwUbjJChoci() 
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_SUBTITLE_VTT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.vtt'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_SUBTITLE_SRT =xbmcvfs.translatePath(os.path.join(__profile__,'temp_subtitles.srt'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_COOKIE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'watcha_cookies.json'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_SEARCHEDC_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'watcha_searched.txt'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'wc_stream.mpd'))
 def addon_noti(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,sting):
  try:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH=xbmcgui.Dialog()
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH.notification(__addonname__,sting)
  except:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
 def addon_log(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,string):
  try:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzu=string.encode('utf-8','ignore')
  except:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzu='addonException: addon_log'
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzK=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzu),level=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzK)
 def get_keyboard_input(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzW=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
  kb=xbmc.Keyboard()
  kb.setHeading(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzW=kb.getText()
  return nEUpGhmyoQOvRfCIxbPVSDaLMkdTzW
 def get_settings_account(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzw =__addon__.getSetting('id')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzg =__addon__.getSetting('pw')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzB=nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(__addon__.getSetting('selected_profile'))
  return(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzw,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzg,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzB)
 def get_settings_totalsearch(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTze =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH if __addon__.getSetting('local_search')=='true' else nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzF=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH if __addon__.getSetting('local_history')=='true' else nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzl =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH if __addon__.getSetting('total_search')=='true' else nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzX=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH if __addon__.getSetting('total_history')=='true' else nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjz=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH if __addon__.getSetting('menu_bookmark')=='true' else nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  return(nEUpGhmyoQOvRfCIxbPVSDaLMkdTze,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzF,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzl,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzX,nEUpGhmyoQOvRfCIxbPVSDaLMkdTjz)
 def get_settings_makebookmark(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  return nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH if __addon__.getSetting('make_bookmark')=='true' else nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
 def get_settings_proxyport(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjq =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH if __addon__.getSetting('proxyYn')=='true' else nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(__addon__.getSetting('proxyPort'))
  return nEUpGhmyoQOvRfCIxbPVSDaLMkdTjq,nEUpGhmyoQOvRfCIxbPVSDaLMkdTjc
 def get_settings_playback(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjY=[3840,1920,1280]
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjJ =['BASE','HDR','VISION']
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjr =['2CH','6CH','ATMOS']
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(__addon__.getSetting('selected_quality'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTji =nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(__addon__.getSetting('selected_screen'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjN =nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(__addon__.getSetting('selected_sound'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjA={'max_quality':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjY[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjs],'sel_screen':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjJ[nEUpGhmyoQOvRfCIxbPVSDaLMkdTji],'sel_sound':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjr[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjN],'streamFilename':nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_STREAM_FILENAME,}
  return nEUpGhmyoQOvRfCIxbPVSDaLMkdTjA
 def Base64_Encode(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,plaintext):
  return base64.standard_b64encode(plaintext.encode()).decode('utf-8')
 def Params_JsonToStr(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,paramJson):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjt=json.dumps(paramJson,separators=(',',':'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjt=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.Base64_Encode(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjt)
  return nEUpGhmyoQOvRfCIxbPVSDaLMkdTjt
 def get_selQuality(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  try:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjY=['3840x2160/2.0/320/xhdpi','1920x1080/2.0/320/xhdpi','1280x720/2.0/320/xhdpi']
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(__addon__.getSetting('selected_quality'))
   return nEUpGhmyoQOvRfCIxbPVSDaLMkdTjY[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjs]
  except:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
  return 1080 
 def get_settings_direct_replay(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjH=nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(__addon__.getSetting('direct_replay'))
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTjH==0:
   return nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  else:
   return nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH
 def set_winEpisodeOrderby(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,nEUpGhmyoQOvRfCIxbPVSDaLMkdTju):
  __addon__.setSetting('watcha_orderby',nEUpGhmyoQOvRfCIxbPVSDaLMkdTju)
 def get_winEpisodeOrderby(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTju=__addon__.getSetting('watcha_orderby')
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTju in['',nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA]:nEUpGhmyoQOvRfCIxbPVSDaLMkdTju='asc'
  return nEUpGhmyoQOvRfCIxbPVSDaLMkdTju
 def dp_setEpOrderby(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTju =args.get('orderby')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.set_winEpisodeOrderby(nEUpGhmyoQOvRfCIxbPVSDaLMkdTju)
  xbmc.executebuiltin("Container.Refresh")
 def add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,label,sublabel='',img='',infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH,params='',isLink=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu,ContextMenu=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjK='%s?%s'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_url,urllib.parse.urlencode(params))
  if sublabel:nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW='%s < %s >'%(label,sublabel)
  else: nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW=label
  if not img:img='DefaultFolder.png'
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjw=xbmcgui.ListItem(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTsK(img)==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsW:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjw.setArt(img)
  else:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjw.setArt({'thumb':img,'poster':img})
  if infoLabels:nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.Set_InfoTag(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjw.getVideoInfoTag(),infoLabels)
  if not isFolder and not isLink:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjw.setProperty('IsPlayable','true')
  if ContextMenu:nEUpGhmyoQOvRfCIxbPVSDaLMkdTjw.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,nEUpGhmyoQOvRfCIxbPVSDaLMkdTjK,nEUpGhmyoQOvRfCIxbPVSDaLMkdTjw,isFolder)
 def Set_InfoTag(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,video_InfoTag:xbmc.InfoTagVideo,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqj):
  for nEUpGhmyoQOvRfCIxbPVSDaLMkdTjg,value in nEUpGhmyoQOvRfCIxbPVSDaLMkdTqj.items():
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTzY[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjg]['type']=='string':
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTsw(video_InfoTag,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzY[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjg]['func'])(value)
   elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTzY[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjg]['type']=='int':
    if nEUpGhmyoQOvRfCIxbPVSDaLMkdTsK(value)==nEUpGhmyoQOvRfCIxbPVSDaLMkdTst:
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTjB=nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(value)
    else:
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTjB=0
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTsw(video_InfoTag,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzY[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjg]['func'])(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjB)
   elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTzY[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjg]['type']=='actor':
    if value!=[]:
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTsw(video_InfoTag,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzY[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjg]['func'])([xbmc.Actor(name)for name in value])
   elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTzY[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjg]['type']=='list':
    if nEUpGhmyoQOvRfCIxbPVSDaLMkdTsK(value)==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsg:
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTsw(video_InfoTag,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzY[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjg]['func'])(value)
    else:
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTsw(video_InfoTag,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzY[nEUpGhmyoQOvRfCIxbPVSDaLMkdTjg]['func'])([value])
 def dp_Main_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  (nEUpGhmyoQOvRfCIxbPVSDaLMkdTze,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzF,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzl,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzX,nEUpGhmyoQOvRfCIxbPVSDaLMkdTjz)=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_settings_totalsearch()
  for nEUpGhmyoQOvRfCIxbPVSDaLMkdTje in nEUpGhmyoQOvRfCIxbPVSDaLMkdTzq:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW=nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('title')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF=''
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('mode')=='LOCAL_SEARCH' and nEUpGhmyoQOvRfCIxbPVSDaLMkdTze ==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu:continue
   elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('mode')=='SEARCH_HISTORY' and nEUpGhmyoQOvRfCIxbPVSDaLMkdTzF==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu:continue
   elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('mode')=='TOTAL_SEARCH' and nEUpGhmyoQOvRfCIxbPVSDaLMkdTzl ==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu:continue
   elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('mode')=='TOTAL_HISTORY' and nEUpGhmyoQOvRfCIxbPVSDaLMkdTzX==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu:continue
   elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('mode')=='MENU_BOOKMARK' and nEUpGhmyoQOvRfCIxbPVSDaLMkdTjz==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu:continue
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('mode'),'stype':nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('stype'),'api_path':nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('api_path'),'page':'1','tag_id':'-',}
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('mode')=='LOCAL_SEARCH':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['historyyn']='Y' 
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTqz =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH
   else:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTqz =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqj={'title':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,'plot':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW}
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('mode')=='XXX':nEUpGhmyoQOvRfCIxbPVSDaLMkdTqj=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
   if 'icon' in nEUpGhmyoQOvRfCIxbPVSDaLMkdTje:nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',nEUpGhmyoQOvRfCIxbPVSDaLMkdTje.get('icon')) 
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel='',img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTqj,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl,isLink=nEUpGhmyoQOvRfCIxbPVSDaLMkdTqz)
  xbmcplugin.endOfDirectory(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle)
 def login_main(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  (nEUpGhmyoQOvRfCIxbPVSDaLMkdTqY,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqJ,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqr)=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_settings_account()
  if not(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqY and nEUpGhmyoQOvRfCIxbPVSDaLMkdTqJ):
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH=xbmcgui.Dialog()
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('WATCHA_M_LOGINWAIT')=='TRUE':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqi=0
   while nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTqi+=1
    time.sleep(0.05)
    if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqi>600:return
  else:
   xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','TRUE')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqN=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.GetCredential(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqY,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqJ,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqr)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqN:nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.cookiefile_save()
  xbmcgui.Window(10000).setProperty('WATCHA_M_LOGINWAIT','FALSE')
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqN==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_HomeGroup_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqA=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.GetHomeList()
  for nEUpGhmyoQOvRfCIxbPVSDaLMkdTqt in nEUpGhmyoQOvRfCIxbPVSDaLMkdTqA:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqH =nEUpGhmyoQOvRfCIxbPVSDaLMkdTqt.get('code')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqu=nEUpGhmyoQOvRfCIxbPVSDaLMkdTqt.get('content_type')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW =nEUpGhmyoQOvRfCIxbPVSDaLMkdTqt.get('title')
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqu=='staffmades':
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':'CATEGORY_LIST','api_path':'staffmades/'+nEUpGhmyoQOvRfCIxbPVSDaLMkdTqH,'page':'1',}
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl)
   else:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTqK
  xbmcplugin.endOfDirectory(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,cacheToDisc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH)
 def dp_SubGroup_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw =args.get('stype')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg =nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(args.get('page'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqB=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.GetSubGroupList(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqe=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzJ if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw=='genres' else nEUpGhmyoQOvRfCIxbPVSDaLMkdTzr
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqF=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsB(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqB)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTql =nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqF//(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqe+1))+1
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqX =(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg-1)*nEUpGhmyoQOvRfCIxbPVSDaLMkdTqe
  for i in nEUpGhmyoQOvRfCIxbPVSDaLMkdTse(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqe):
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcz=nEUpGhmyoQOvRfCIxbPVSDaLMkdTqX+i
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTcz>=nEUpGhmyoQOvRfCIxbPVSDaLMkdTqF:break
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW =nEUpGhmyoQOvRfCIxbPVSDaLMkdTqB[nEUpGhmyoQOvRfCIxbPVSDaLMkdTcz].get('group_name')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcj =nEUpGhmyoQOvRfCIxbPVSDaLMkdTqB[nEUpGhmyoQOvRfCIxbPVSDaLMkdTcz].get('api_path')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcq =nEUpGhmyoQOvRfCIxbPVSDaLMkdTqB[nEUpGhmyoQOvRfCIxbPVSDaLMkdTcz].get('tag_id')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':'CATEGORY_LIST','api_path':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcj,'tag_id':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcq,'stype':nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw,'page':'1',}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel='',img='',infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTql>nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['mode'] ='SUB_GROUP' 
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['stype'] =nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['api_path']=args.get('api_path')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['page'] =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsF(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg+1)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW='[B]%s >>[/B]'%'다음 페이지'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcY=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsF(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg+1)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcY,img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTsB(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqB)>0:xbmcplugin.endOfDirectory(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,cacheToDisc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH)
 def play_VIDEO(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ =args.get('movie_code')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr =args.get('season_code')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW =args.get('title')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs =args.get('thumbnail')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.addon_log(nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ+' - '+nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTci =nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_selQuality()
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjq,nEUpGhmyoQOvRfCIxbPVSDaLMkdTjc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_settings_proxyport()
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjA=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_settings_playback()
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcN=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.GetStreamingURL(nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,nEUpGhmyoQOvRfCIxbPVSDaLMkdTci,proxyUse=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjq,inScreen=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjA['sel_screen'],inSound=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjA['sel_sound'])
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTcN['streamUrl']=='':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.addon_noti(__language__(30908).encode('utf8'))
   return
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcA=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcN['streamUrl']
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.addon_log(nEUpGhmyoQOvRfCIxbPVSDaLMkdTcA)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTjq:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTct={'addon':'watcham','playOption':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjA,}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTct=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.Params_JsonToStr(nEUpGhmyoQOvRfCIxbPVSDaLMkdTct)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcA='http://127.0.0.1:{}/{}|proxy-mini={}'.format(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjc,nEUpGhmyoQOvRfCIxbPVSDaLMkdTcA,nEUpGhmyoQOvRfCIxbPVSDaLMkdTct)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcH=xbmcgui.ListItem(path=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcA)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTcN['customdata']:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcu=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcN['customdata']
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcK ='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcW ='mpd'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcw ='com.widevine.alpha'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcg =inputstreamhelper.Helper(nEUpGhmyoQOvRfCIxbPVSDaLMkdTcW,drm=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcw)
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTcg.check_inputstream():
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcB={'Host':'lic.drmtoday.com','origin':'https://play.watcha.net','referer':'https://play.watcha.net/watch/'+nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,'dt-custom-data':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcu,'Sec-Fetch-Dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.USER_AGENT,'Content-Type':'application/octet-stream',}
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTce=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcK+'|'+urllib.parse.urlencode(nEUpGhmyoQOvRfCIxbPVSDaLMkdTcB)+'|R{SSM}|'
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.addon_log(nEUpGhmyoQOvRfCIxbPVSDaLMkdTce)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcH.setProperty('inputstream',nEUpGhmyoQOvRfCIxbPVSDaLMkdTcg.inputstream_addon)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcH.setProperty('inputstream.adaptive.manifest_type',nEUpGhmyoQOvRfCIxbPVSDaLMkdTcW)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcH.setProperty('inputstream.adaptive.license_type',nEUpGhmyoQOvRfCIxbPVSDaLMkdTcw)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcH.setProperty('inputstream.adaptive.license_key',nEUpGhmyoQOvRfCIxbPVSDaLMkdTce)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcH.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.USER_AGENT))
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTcN['subtitleUrl']:
   try:
    f=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_SUBTITLE_VTT,'w',-1,'utf-8')
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcF=requests.get(nEUpGhmyoQOvRfCIxbPVSDaLMkdTcN['subtitleUrl'])
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcl=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcF.content.decode('utf-8') 
    for nEUpGhmyoQOvRfCIxbPVSDaLMkdTcX in nEUpGhmyoQOvRfCIxbPVSDaLMkdTcl.splitlines():
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTYz=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*',r'00:\1.\2 --> 00:\3.\4',nEUpGhmyoQOvRfCIxbPVSDaLMkdTcX)
     f.write(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYz+'\n')
    f.close()
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcH.setSubtitles([nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_SUBTITLE_VTT,nEUpGhmyoQOvRfCIxbPVSDaLMkdTcN['subtitleUrl']])
   except:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcH.setSubtitles([nEUpGhmyoQOvRfCIxbPVSDaLMkdTcN['subtitleUrl']])
  xbmcplugin.setResolvedUrl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH,nEUpGhmyoQOvRfCIxbPVSDaLMkdTcH)
  try:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw='movie' if nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr=='-' else 'seasons'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw=='movie' else nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr,'img':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs,'title':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,'videoid':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.Save_Watched_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw,nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl)
  except:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
 def srtConvert(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,nEUpGhmyoQOvRfCIxbPVSDaLMkdTYq):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj=re.sub(r'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYq)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj=re.sub(r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj=re.sub(r'(\d\d).(\d\d\d) --> (\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n',r'\1,\2 --> \3,\4\n',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj=re.sub(r'WEBVTT\n','',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj=re.sub(r'Kind:[ \-\w]+\n','',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj=re.sub(r'Language:[ \-\w]+\n','',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj=re.sub(r'<c[.\w\d]*>','',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj=re.sub(r'</c>','',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj=re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>','',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj=re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n','',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj=re.sub(r'Style:\n##\n','',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj)
  return nEUpGhmyoQOvRfCIxbPVSDaLMkdTYj
 def vtt_to_srt(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,vttFilename,srtFilename):
  try:
   f=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsl(vttFilename,'r',-1,'utf-8')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYq=f.read()
   f.close()
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYc=''
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYc+nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.srtConvert(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYq)
   f=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsl(srtFilename,'w',-1,'utf-8')
   f.writelines(nEUpGhmyoQOvRfCIxbPVSDaLMkdTsF(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYc))
   f.close()
  except:
   return nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  return nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH
 def dp_Category_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw =args.get('stype')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcq =args.get('tag_id')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcj=args.get('api_path')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg=nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(args.get('page'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYJ=[]
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYr,nEUpGhmyoQOvRfCIxbPVSDaLMkdTYs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.GetCategoryList(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw,nEUpGhmyoQOvRfCIxbPVSDaLMkdTcq,nEUpGhmyoQOvRfCIxbPVSDaLMkdTcj,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg)
  for nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi in nEUpGhmyoQOvRfCIxbPVSDaLMkdTYr:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('code')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('title')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqu =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('content_type')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYN =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('story')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('thumbnail')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYA =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('year')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYt =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('film_rating_code')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYH=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('film_rating_short')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYu =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('film_rating_long')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYK =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('duration')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYW =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('badge')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYJ.append(nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ)
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqu=='movies': 
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYw ='MOVIE'
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr='-'
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYg ='movie'
   else: 
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYw ='SEASON'
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYg ='tvshow' 
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB={'mediatype':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYg,'mpaa':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYu,'title':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,'year':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYA,'duration':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYK,'plot':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYN,}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW+='  (%s)'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYA)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYw,'movie_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,'page':'1','season_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr,'title':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,'thumbnail':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs,}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYe=[]
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTcj=='users/me/watchings':
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYF={'codeList':[nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ]}
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl=json.dumps(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYF)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl=urllib.parse.quote(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYX='RunPlugin(plugin://plugin.video.watcham/?mode=DELETE_CONTINUE&bm_param=%s)'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYe.append(('(선택영상) 이어보기에서 삭제',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYX))
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_settings_makebookmark():
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYF={'videoid':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,'vidtype':'tvshow' if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqu=='tv_seasons' else 'movie','vtitle':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,'vsubtitle':'',}
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl=json.dumps(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYF)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl=urllib.parse.quote(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYX='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYe.append(('(통합) 찜 영상에 추가',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYX))
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYW,img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl,ContextMenu=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYe)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTcj=='users/me/watchings':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYF={'codeList':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYJ}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl=json.dumps(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYF,separators=(',',':'))
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.addon_log(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl=urllib.parse.quote(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.addon_log(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':'DELETE_CONTINUE','bm_param':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYF,}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB={'plot':'이어보기 목록 전체를 삭제합니다.'}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW='** 이어보기 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel='',img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl,isLink=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTYs:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['mode'] ='CATEGORY_LIST'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['stype'] =nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['tag_id'] =nEUpGhmyoQOvRfCIxbPVSDaLMkdTcq
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['api_path']=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcj
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['page'] =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsF(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg+1)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW='[B]%s >>[/B]'%'다음 페이지'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcY=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsF(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg+1)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcY,img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl)
  xbmcplugin.setContent(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,'movies')
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTsB(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYr)>0:
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTcj=='arrivals/latest':
    xbmcplugin.endOfDirectory(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,cacheToDisc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH)
   else:
    xbmcplugin.endOfDirectory(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,cacheToDisc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu)
 def dp_Season_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr=args.get('season_code')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs =args.get('thumbnail')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs=json.loads(nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs.replace('\'','"'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTJz=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.GetSeasonList(nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTsB(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJz)>1:
   for nEUpGhmyoQOvRfCIxbPVSDaLMkdTJj in nEUpGhmyoQOvRfCIxbPVSDaLMkdTJz:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTJq=nEUpGhmyoQOvRfCIxbPVSDaLMkdTJj.get('seasonId')
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTJc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTJj.get('seasonNm')
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB={'mediatype':'tvshow','title':nEUpGhmyoQOvRfCIxbPVSDaLMkdTJc,}
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':'EPISODE','movie_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTJq,'page':'1','season_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTJq,'title':nEUpGhmyoQOvRfCIxbPVSDaLMkdTJc,'thumbnail':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs,}
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJc,sublabel=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl,ContextMenu=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA)
   xbmcplugin.setContent(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,'seasons')
   xbmcplugin.endOfDirectory(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,cacheToDisc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu)
  else:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJY={'movie_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr,'page':'1','season_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr,}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Episode_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJY)
 def dp_Episode_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTJr=args.get('movie_code')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg =nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(args.get('page'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr =args.get('season_code')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYr,nEUpGhmyoQOvRfCIxbPVSDaLMkdTYs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.GetEpisodoList(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJr,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg,orderby=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_winEpisodeOrderby())
  for nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi in nEUpGhmyoQOvRfCIxbPVSDaLMkdTYr:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('code')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('title')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('thumbnail')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJs =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('display_num')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJi =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('season_title')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJN=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('episode_number')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYK =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('duration')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB={'mediatype':'episode','tvshowtitle':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW if nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW!='' else nEUpGhmyoQOvRfCIxbPVSDaLMkdTJi,'title':'%s %s'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJi,nEUpGhmyoQOvRfCIxbPVSDaLMkdTJs)if nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW!='' else nEUpGhmyoQOvRfCIxbPVSDaLMkdTJs,'episode':nEUpGhmyoQOvRfCIxbPVSDaLMkdTJN,'duration':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYK,'plot':'%s\n%s\n\n%s'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJi,nEUpGhmyoQOvRfCIxbPVSDaLMkdTJs,nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW)}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW='(%s) %s'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJs,nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':'MOVIE','movie_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,'season_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr,'title':'%s < %s >'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,nEUpGhmyoQOvRfCIxbPVSDaLMkdTJi),'thumbnail':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel=nEUpGhmyoQOvRfCIxbPVSDaLMkdTJi,img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg==1:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB={'plot':'정렬순서를 변경합니다.'}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['mode'] ='ORDER_BY' 
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_winEpisodeOrderby()=='desc':
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW='정렬순서변경 : 최신화부터 -> 1회부터'
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['orderby']='asc'
   else:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW='정렬순서변경 : 1회부터 -> 최신화부터'
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['orderby']='desc'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel='',img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl,isLink=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTYs:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['mode'] ='EPISODE' 
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['movie_code']=nEUpGhmyoQOvRfCIxbPVSDaLMkdTJr
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['page'] =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsF(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg+1)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW='[B]%s >>[/B]'%'다음 페이지'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcY=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsF(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg+1)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcY,img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl)
  xbmcplugin.setContent(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,'episodes')
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTsB(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYr)>0:xbmcplugin.endOfDirectory(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,cacheToDisc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH)
 def dp_Search_History(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTJA=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.Load_List_File('search')
  for nEUpGhmyoQOvRfCIxbPVSDaLMkdTJt in nEUpGhmyoQOvRfCIxbPVSDaLMkdTJA:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJH=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsW(urllib.parse.parse_qsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJt))
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJu=nEUpGhmyoQOvRfCIxbPVSDaLMkdTJH.get('skey').strip()
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':'LOCAL_SEARCH','search_key':nEUpGhmyoQOvRfCIxbPVSDaLMkdTJu,'page':'1','historyyn':'Y',}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJK={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':nEUpGhmyoQOvRfCIxbPVSDaLMkdTJu,'vType':'-',}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJW=urllib.parse.urlencode(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJK)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYe=[('선택된 검색어 ( %s ) 삭제'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJu),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJW))]
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJu,sublabel='',img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl,ContextMenu=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYe)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB={'plot':'검색목록 전체를 삭제합니다.'}
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel='',img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl,isLink=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH)
  xbmcplugin.endOfDirectory(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,cacheToDisc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu)
 def dp_Search_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg =nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(args.get('page'))
  if 'search_key' in args:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJw=args.get('search_key')
  else:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJw=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not nEUpGhmyoQOvRfCIxbPVSDaLMkdTJw:
    return
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYr,nEUpGhmyoQOvRfCIxbPVSDaLMkdTYs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.GetSearchList(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJw,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg)
  for nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi in nEUpGhmyoQOvRfCIxbPVSDaLMkdTYr:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('code')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('title')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqu=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('content_type')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYN =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('story')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('thumbnail')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYA =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('year')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYt =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('film_rating_code')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYH=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('film_rating_short')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYu =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('film_rating_long')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYK =nEUpGhmyoQOvRfCIxbPVSDaLMkdTYi.get('duration')
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqu=='movies': 
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYw ='MOVIE'
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTqc =''
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr='-'
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYg ='movie'
   else: 
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYw ='SEASON'
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTqc ='' 
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYg ='tvshow' 
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB={'mediatype':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYg,'mpaa':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYu,'title':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,'year':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYA,'duration':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYK,'plot':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYN}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW+='  (%s)'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYA)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':nEUpGhmyoQOvRfCIxbPVSDaLMkdTYw,'movie_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,'page':'1','season_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcr,'title':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,'thumbnail':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs}
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_settings_makebookmark():
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYF={'videoid':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,'vidtype':'tvshow' if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqu=='tv_seasons' else 'movie','vtitle':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,'vsubtitle':'',}
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl=json.dumps(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYF)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl=urllib.parse.quote(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYX='RunPlugin(plugin://plugin.video.watcham/?mode=SET_BOOKMARK&bm_param=%s)'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYl)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYe=[('(통합) 찜 영상에 추가',nEUpGhmyoQOvRfCIxbPVSDaLMkdTYX)]
   else:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYe=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel=nEUpGhmyoQOvRfCIxbPVSDaLMkdTqc,img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl,ContextMenu=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYe)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTYs:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['mode'] ='SEARCH'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['search_key']=nEUpGhmyoQOvRfCIxbPVSDaLMkdTJw
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl['page'] =nEUpGhmyoQOvRfCIxbPVSDaLMkdTsF(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg+1)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW='[B]%s >>[/B]'%'다음 페이지'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTcY=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsF(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqg+1)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcY,img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl)
  xbmcplugin.setContent(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,'movies')
  xbmcplugin.endOfDirectory(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,cacheToDisc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH)
  if args.get('historyyn')=='Y':nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.Save_Searched_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJw)
 def dp_Delete_Continue(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg=urllib.parse.unquote(args.get('bm_param'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg=nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg.replace('\'','"')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.addon_log(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg=json.loads(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYJ=nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg.get('codeList')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH=xbmcgui.Dialog()
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu:sys.exit()
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.DeleteContinueList(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYJ)
  xbmc.executebuiltin("Container.Refresh")
 def dp_History_Remove(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTJB=args.get('delType')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTJe =args.get('sKey')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTJF =args.get('vType')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH=xbmcgui.Dialog()
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTJB=='SEARCH_ALL':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTJB=='SEARCH_ONE':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTJB=='WATCH_ALL':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTJB=='WATCH_ONE':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH.yesno(__language__(30915).encode('utf8'),__language__(30905).encode('utf8'))
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu:sys.exit()
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTJB=='SEARCH_ALL':
   if os.path.isfile(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_SEARCHEDC_FILENAME):os.remove(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_SEARCHEDC_FILENAME)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTJB=='SEARCH_ONE':
   try:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTJl=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_SEARCHEDC_FILENAME
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTJX=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.Load_List_File('search') 
    fp=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJl,'w',-1,'utf-8')
    for nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz in nEUpGhmyoQOvRfCIxbPVSDaLMkdTJX:
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTrj=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsW(urllib.parse.parse_qsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz))
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTrq=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrj.get('skey').strip()
     if nEUpGhmyoQOvRfCIxbPVSDaLMkdTJe!=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrq:
      fp.write(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz)
    fp.close()
   except:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTJB=='WATCH_ALL':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%nEUpGhmyoQOvRfCIxbPVSDaLMkdTJF))
   if os.path.isfile(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJl):os.remove(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJl)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTJB=='WATCH_ONE':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%nEUpGhmyoQOvRfCIxbPVSDaLMkdTJF))
   try:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTJX=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.Load_List_File(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJF) 
    fp=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJl,'w',-1,'utf-8')
    for nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz in nEUpGhmyoQOvRfCIxbPVSDaLMkdTJX:
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTrj=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsW(urllib.parse.parse_qsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz))
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTrq=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrj.get('code').strip()
     if nEUpGhmyoQOvRfCIxbPVSDaLMkdTJe!=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrq:
      fp.write(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz)
    fp.close()
   except:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw): 
  try:
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw=='search':
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTJl=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_SEARCHEDC_FILENAME
   elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw in['seasons','movie']:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTJl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw))
   else:
    return[]
   fp=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJl,'r',-1,'utf-8')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrc=fp.readlines()
   fp.close()
  except:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrc=[]
  return nEUpGhmyoQOvRfCIxbPVSDaLMkdTrc
 def Save_Watched_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzA):
  try:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrY=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw))
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJX=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.Load_List_File(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw) 
   fp=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrY,'w',-1,'utf-8')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrJ=urllib.parse.urlencode(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzA)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrJ=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrJ+'\n'
   fp.write(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrJ)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrs=0
   for nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz in nEUpGhmyoQOvRfCIxbPVSDaLMkdTJX:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTrj=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsW(urllib.parse.parse_qsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz))
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTri=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzA.get('code').strip()
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTrN=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrj.get('code').strip()
    if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw=='seasons' and nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_settings_direct_replay()==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH:
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTri=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzA.get('videoid').strip()
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTrN=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrj.get('videoid').strip()if nEUpGhmyoQOvRfCIxbPVSDaLMkdTrN!=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA else '-'
    if nEUpGhmyoQOvRfCIxbPVSDaLMkdTri!=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrN:
     fp.write(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz)
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTrs+=1
     if nEUpGhmyoQOvRfCIxbPVSDaLMkdTrs>=50:break
   fp.close()
  except:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
 def dp_Watch_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw =args.get('stype')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTjH=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_settings_direct_replay()
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw=='-':
   for nEUpGhmyoQOvRfCIxbPVSDaLMkdTrA in nEUpGhmyoQOvRfCIxbPVSDaLMkdTzc:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrA.get('title')
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':nEUpGhmyoQOvRfCIxbPVSDaLMkdTrA.get('mode'),'stype':nEUpGhmyoQOvRfCIxbPVSDaLMkdTrA.get('stype')}
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel='',img='',infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl)
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTsB(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzc)>0:xbmcplugin.endOfDirectory(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle)
  else:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrt=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.Load_List_File(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw)
   for nEUpGhmyoQOvRfCIxbPVSDaLMkdTrH in nEUpGhmyoQOvRfCIxbPVSDaLMkdTrt:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTJH=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsW(urllib.parse.parse_qsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrH))
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ=nEUpGhmyoQOvRfCIxbPVSDaLMkdTJH.get('code').strip()
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW =nEUpGhmyoQOvRfCIxbPVSDaLMkdTJH.get('title').strip()
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs =nEUpGhmyoQOvRfCIxbPVSDaLMkdTJH.get('img').strip()
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTru =nEUpGhmyoQOvRfCIxbPVSDaLMkdTJH.get('videoid').strip()
    try:
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs.replace('\'','\"')
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs=json.loads(nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs)
    except:
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB={}
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB['plot']=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW
    if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw=='movie':
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB['mediatype']='movie'
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':'MOVIE','page':'1','movie_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,'season_code':'-','title':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,'thumbnail':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs}
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
    else:
     if nEUpGhmyoQOvRfCIxbPVSDaLMkdTjH==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu or nEUpGhmyoQOvRfCIxbPVSDaLMkdTru==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA:
      nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB['mediatype']='tvshow'
      nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':'EPISODE','page':'1','movie_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,'season_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,'title':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,'thumbnail':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs}
      nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH
     else:
      nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB['mediatype']='episode'
      nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':'MOVIE','movie_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTru,'season_code':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,'title':nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,'thumbnail':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs}
      nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTJK={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':nEUpGhmyoQOvRfCIxbPVSDaLMkdTcJ,'vType':nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw,}
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTJW=urllib.parse.urlencode(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJK)
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTYe=[('선택된 시청이력 ( %s ) 삭제'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW),'RunPlugin(plugin://plugin.video.watcham/?%s)'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJW))]
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel='',img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTcs,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjX,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl,ContextMenu=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYe)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB={'plot':'시청목록을 삭제합니다.'}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw,}
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.add_dir(nEUpGhmyoQOvRfCIxbPVSDaLMkdTjW,sublabel='',img=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjF,infoLabels=nEUpGhmyoQOvRfCIxbPVSDaLMkdTYB,isFolder=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu,params=nEUpGhmyoQOvRfCIxbPVSDaLMkdTjl,isLink=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH)
   if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqw=='movie':xbmcplugin.setContent(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,'movies')
   else:xbmcplugin.setContent(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs._addon_handle,cacheToDisc=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu)
 def Save_Searched_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,nEUpGhmyoQOvRfCIxbPVSDaLMkdTJw):
  try:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrK=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_SEARCHEDC_FILENAME
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTJX=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.Load_List_File('search') 
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrW={'skey':nEUpGhmyoQOvRfCIxbPVSDaLMkdTJw.strip()}
   fp=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrK,'w',-1,'utf-8')
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrJ=urllib.parse.urlencode(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrW)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrJ=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrJ+'\n'
   fp.write(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrJ)
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTrs=0
   for nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz in nEUpGhmyoQOvRfCIxbPVSDaLMkdTJX:
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTrj=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsW(urllib.parse.parse_qsl(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz))
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTri=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrW.get('skey').strip()
    nEUpGhmyoQOvRfCIxbPVSDaLMkdTrN=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrj.get('skey').strip()
    if nEUpGhmyoQOvRfCIxbPVSDaLMkdTri!=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrN:
     fp.write(nEUpGhmyoQOvRfCIxbPVSDaLMkdTrz)
     nEUpGhmyoQOvRfCIxbPVSDaLMkdTrs+=1
     if nEUpGhmyoQOvRfCIxbPVSDaLMkdTrs>=50:break
   fp.close()
  except:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
 def logout(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH=xbmcgui.Dialog()
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu:sys.exit()
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.Init_WC_Total()
  if os.path.isfile(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_COOKIE_FILENAME):os.remove(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_COOKIE_FILENAME)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTrw =nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.Get_Now_Datetime()
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTrg=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrw+datetime.timedelta(days=nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(__addon__.getSetting('cache_ttl')))
  (nEUpGhmyoQOvRfCIxbPVSDaLMkdTqY,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqJ,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqr)=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_settings_account()
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.Save_session_acount(nEUpGhmyoQOvRfCIxbPVSDaLMkdTqY,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqJ,nEUpGhmyoQOvRfCIxbPVSDaLMkdTqr)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC['account']['token_limit']=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrg.strftime('%Y%m%d')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.JsonFile_Save(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_COOKIE_FILENAME,nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC)
 def cookiefile_check(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.JsonFile_Load(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC_COOKIE_FILENAME)
  if 'account' not in nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.Init_WC_Total()
   return nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  if 'deviceId2' not in nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC['cookies']:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.Init_WC_Total()
   return nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  (nEUpGhmyoQOvRfCIxbPVSDaLMkdTrB,nEUpGhmyoQOvRfCIxbPVSDaLMkdTre,nEUpGhmyoQOvRfCIxbPVSDaLMkdTrF)=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.get_settings_account()
  (nEUpGhmyoQOvRfCIxbPVSDaLMkdTrl,nEUpGhmyoQOvRfCIxbPVSDaLMkdTrX,nEUpGhmyoQOvRfCIxbPVSDaLMkdTsz)=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.Load_session_acount()
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTrB!=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrl or nEUpGhmyoQOvRfCIxbPVSDaLMkdTre!=nEUpGhmyoQOvRfCIxbPVSDaLMkdTrX or nEUpGhmyoQOvRfCIxbPVSDaLMkdTrF!=nEUpGhmyoQOvRfCIxbPVSDaLMkdTsz:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.Init_WC_Total()
   return nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.Get_Now_Datetime().strftime('%Y%m%d'))>nEUpGhmyoQOvRfCIxbPVSDaLMkdTst(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.WC['account']['token_limit']):
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.Init_WC_Total()
   return nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu
  return nEUpGhmyoQOvRfCIxbPVSDaLMkdTsH
 def dp_Global_Search(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=args.get('mode')
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='TOTAL_SEARCH':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTsq='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTsq='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(nEUpGhmyoQOvRfCIxbPVSDaLMkdTsq)
 def dp_Bookmark_Menu(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTsq='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(nEUpGhmyoQOvRfCIxbPVSDaLMkdTsq)
 def dp_Set_Bookmark(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs,args):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg=urllib.parse.unquote(args.get('bm_param'))
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg=json.loads(nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTru =nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg.get('videoid')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTsc =nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg.get('vidtype')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTsY =nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg.get('vtitle')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTsJ =nEUpGhmyoQOvRfCIxbPVSDaLMkdTJg.get('vsubtitle')
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH=xbmcgui.Dialog()
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzH.yesno(__language__(30913).encode('utf8'),nEUpGhmyoQOvRfCIxbPVSDaLMkdTsY+' \n\n'+__language__(30914))
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTqs==nEUpGhmyoQOvRfCIxbPVSDaLMkdTsu:return
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTsr=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.WatchaObj.GetBookmarkInfo(nEUpGhmyoQOvRfCIxbPVSDaLMkdTru,nEUpGhmyoQOvRfCIxbPVSDaLMkdTsc)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTsi=json.dumps(nEUpGhmyoQOvRfCIxbPVSDaLMkdTsr)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTsi=urllib.parse.quote(nEUpGhmyoQOvRfCIxbPVSDaLMkdTsi)
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTYX ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(nEUpGhmyoQOvRfCIxbPVSDaLMkdTsi)
  xbmc.executebuiltin(nEUpGhmyoQOvRfCIxbPVSDaLMkdTYX)
 def watcha_main(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs):
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params.get('mode',nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA)
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='LOGOUT':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.logout()
   return
  nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.login_main()
  if nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj is nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Main_List()
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='HOME_GROUP':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_HomeGroup_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='SUB_GROUP':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_SubGroup_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='CATEGORY_LIST':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Category_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='SEASON':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Season_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='EPISODE':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Episode_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='ORDER_BY':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_setEpOrderby(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj in['SEARCH','LOCAL_SEARCH']:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Search_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='MOVIE':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.play_VIDEO(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='WATCH':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Watch_List(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_History_Remove(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj in['TOTAL_SEARCH','TOTAL_HISTORY']:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Global_Search(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='SEARCH_HISTORY':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Search_History(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='MENU_BOOKMARK':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Bookmark_Menu(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='SET_BOOKMARK':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Set_Bookmark(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  elif nEUpGhmyoQOvRfCIxbPVSDaLMkdTsj=='DELETE_CONTINUE':
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.dp_Delete_Continue(nEUpGhmyoQOvRfCIxbPVSDaLMkdTzs.main_params)
  else:
   nEUpGhmyoQOvRfCIxbPVSDaLMkdTsA
# Created by pyminifier (https://github.com/liftoff/pyminifier)
