import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
import requests
import urllib
import json
import base64
import re
import xml.etree.ElementTree as ET
import io
import os
import xml.dom.minidom


REMOVE_IN_HEADERS  = ['proxy-mini','host','referer','upgrade'] #,'accept-encoding'] #,'content-length']
REMOVE_OUT_HEADERS = ['date','server','set-cookie','keep-alive','connection','transfer-encoding','content-encoding','content-length']
AUDIO_VALUE = {
			'-'     : 0,
			'2CH'   : 1,
			'6CH'   : 2,
			'ATMOS' : 3,
}

class BoriProxyHandler( BaseHTTPRequestHandler ):

	def __init__(self, request, client_address, server):
		self.HTTP_CLIENT = requests.Session()
		self.REQ_INFO    = {}

		try:
		   BaseHTTPRequestHandler.__init__(self, request, client_address, server)
		except (IOError, OSError) as e:
			pass


	def Make_Header( self, header_exceptList=[] ):
		reqHeader = {}
		header_exceptList.extend( REMOVE_IN_HEADERS ) # 소문자

		for key, value in dict(self.headers).items():
			if key.lower() not in header_exceptList:
				reqHeader[key.lower()] = value
				#print( key.lower(), value )
		return reqHeader

	def Make_NewUrl( self, scheme, netloc, path, params='', query='', fragemnt='' ):
		new_url = ( scheme, netloc, path, params, query, fragemnt )
		return urllib.parse.urlunparse( new_url ) 

	def Send_BlankImage( self ):
		self.send_response( 200 )
		self.send_header( 'Content-Type', 'image/x-icon' )
		self.send_header( 'Content-Length', 0 )
		self.end_headers()

	def Send_ErrorPage( self ):
		self.send_response( 200 )
		self.send_header( 'Content-Type', 'text/html; charset=UTF-8' )
		self.end_headers()
		self.wfile.write( 'request error!'.encode('utf-8') )


	def Parse_BaseRequest( self ):
		self.REQ_INFO = {}

		try:
			self.REQ_INFO['url']   = self.path.strip('/') # path 전체
			proxyData = dict(self.headers).get('proxy-mini')
			if proxyData:
				self.REQ_INFO['addon'] = json.loads( base64.standard_b64decode( proxyData ).decode('utf-8') )
			else:
				self.REQ_INFO['addon'] = {}

			#print( self.REQ_INFO['url'] )
			print( self.REQ_INFO['addon'] )

			parseResult = urllib.parse.urlparse( self.REQ_INFO['url'] )  # scheme, netloc, path, params, query, fragment

			self.REQ_INFO['scheme']    = parseResult.scheme
			self.REQ_INFO['netloc']    = parseResult.netloc
			self.REQ_INFO['path']      = parseResult.path.strip('/').split('/')
			self.REQ_INFO['last_path'] = self.REQ_INFO['path'][len(self.REQ_INFO['path'])-1]
			#self.REQ_INFO['params']    = #parseResult.params
			self.REQ_INFO['query']     = dict( urllib.parse.parse_qsl( parseResult.query ) ) 
			#self.REQ_INFO['fragment']  = parseResult.fragment

			lp_type = self.REQ_INFO['last_path'].split('.')
			self.REQ_INFO['last_type'] = lp_type[len(lp_type)-1] #확장자

			length = int(self.headers.get('content-length', 0))
			self.REQ_INFO['postData'] = self.rfile.read(length) if length else None

		except Exception as e:
			print(Exception)
			self.REQ_INFO = {}
			return False

		return True


	def Output_Headers( self, response ):
		self.send_response( response.status_code )

		for resHeader in list(response.headers.items()):
			self.send_header(resHeader[0], resHeader[1])
			#print(  resHeader[0], resHeader[1] )

		self.end_headers()


	def Output_Response( self, response, res_data=None, header_exceptList=[] ):
		# except header
		for resHeader in list(response.headers.items()):
			if resHeader[0].lower() in REMOVE_OUT_HEADERS or resHeader[0].lower() in header_exceptList:
				response.headers.pop(resHeader[0], None)
                
		if res_data:
			#zipStr = self._gzip( res_data.encode('utf-8') )
			#response.headers['content-encoding'] = 'gzip'
			zipStr = res_data.encode('utf-8')

			response.headers['content-length']   = str(len(zipStr))
			self.Output_Headers( response )
			self.wfile.write( zipStr )

		else:
			self.Output_Headers( response )
			
			for chunk in response.iter_content(1048576):
				try:
					self.wfile.write(chunk)
				except Exception as e:
					print( e )
					break


	def do_HEAD( self ):
		self.send_response(200)


	def do_POST( self ):
		if self.Parse_BaseRequest() == False:
			self.send_response( 404 )
			return 

		# requests URL
		try:
			#response = self.HTTP_CLIENT.post( url=reqParse['url'], headers=self.Make_Header(), data=reqParse['postData'], stream=True )
			response = requests.post( url=self.REQ_INFO['url'], headers=self.Make_Header(), data=self.REQ_INFO['postData'], stream=True )
		except Exception as exception:
			print(exception)
			self.Send_ErrorPage()
			return

		self.Output_Response( response, res_data=None, header_exceptList=[] )



	# http://127.0.0.1:9999/https://www.naver.com
	# http://127.0.0.1:52103/https://www.naver.com
	# http://127.0.0.1:9999/https://vod-spc-ap-north-2.media.dssott.com/ps01/disney/3939e7e3-99ab-4668-a867-00b783e1b05d/ctr-all-8f08b949-08dd-41ea-8fbe-1d37f945b9df-a7eaab44-ac86-4771-86cf-fcbe256a9374.m3u8?r=720&a=3&v=1&hash=aa4b5318d957012246fb7f650e074649d93dd279
	def do_GET( self ):

		if self.Parse_BaseRequest() == False:
			self.send_response( 404 )
			return 

		if self.REQ_INFO['last_path'].lower() == 'favicon.ico':
			self.Send_BlankImage() # 공백icon
			return 

		if self.REQ_INFO['scheme'].lower() not in ['http','https']:
			self.send_response( 404 )
			return 


		# requests URL
		try:
			#response = self.HTTP_CLIENT.get( url=reqParse['url'], headers=self.Make_Header(), stream=True )
			response = requests.get( url=self.REQ_INFO['url'], headers=self.Make_Header(), stream=True )
		except Exception as exception:
			print(exception)
			self.Send_ErrorPage()
			return

		#print( self.REQ_INFO )
		res_data = None
		if self.REQ_INFO['last_type'].lower() in ['mpd'] and self.REQ_INFO.get('addon').get('addon') == 'watcham':
			mpd = response.content.decode('utf-8')
			res_data = self.Watcha_Parse_mpd( mpd )

		self.Output_Response( response, res_data, header_exceptList=[] )


	def Watcha_Parse_mpd( self, mpd ):
		MAX_VIDEO = {
					'width'     : 0,
					'bandwidth' : 0,
		}
		MAX_AUDIO = 0
		sel_sound = AUDIO_VALUE[ self.REQ_INFO['addon']['playOption']['sel_sound'] ]  # 1~3


		treeDom    = ET.ElementTree ( ET.fromstring( mpd ) )
		rootNode   = treeDom.getroot()

		# namespace
		XMLNS = re.match( r'\{.*\}', rootNode.tag )[0]
		namespaces = dict(   [node for _, node in ET.iterparse( io.StringIO(mpd), events=['start-ns'] ) ]  )
		for key, value in namespaces.items():
			ET.register_namespace(key, value)


		# 1차 video, audio  최대값 확인
		PeriodNode = rootNode.find( XMLNS + 'Period' )
		for i_AdaptationSet in PeriodNode.findall( XMLNS + 'AdaptationSet' ) :
			# 자막 제거
			if i_AdaptationSet.attrib.get('contentType') == 'text':
				PeriodNode.remove( i_AdaptationSet )
				continue

			if i_AdaptationSet.attrib.get('contentType') == 'video':
				for i_Node in i_AdaptationSet.findall( XMLNS + 'Representation' ):

					node_width     = int( i_Node.attrib.get('width') )
					node_bandwidth = int( i_Node.attrib.get('bandwidth') )

					if MAX_VIDEO['width'] <= node_width and node_width <= self.REQ_INFO['addon']['playOption']['max_quality']:
						if MAX_VIDEO['bandwidth'] < node_bandwidth:
							MAX_VIDEO['width']     = node_width
							MAX_VIDEO['bandwidth'] = node_bandwidth

			if i_AdaptationSet.attrib.get('contentType') == 'audio':
				for i_Node in i_AdaptationSet.findall( XMLNS + 'Representation' ):
					node_sound = AUDIO_VALUE[ self.getAudioAdaptInfo( XMLNS, i_Node) ]
					if MAX_AUDIO < node_sound and node_sound <= sel_sound:
						MAX_AUDIO = node_sound

		print ( MAX_AUDIO )

		# 2차 video 삭제
		for i_AdaptationSet in PeriodNode.findall( XMLNS + 'AdaptationSet' ) :
			if i_AdaptationSet.attrib.get('contentType') == 'video':
				for i_Node in i_AdaptationSet.findall( XMLNS + 'Representation' ):

					node_width     = int( i_Node.attrib.get('width') )
					node_bandwidth = int( i_Node.attrib.get('bandwidth') )

					if MAX_VIDEO['width'] != node_width or MAX_VIDEO['bandwidth'] != node_bandwidth:
						i_AdaptationSet.remove( i_Node )

			if i_AdaptationSet.attrib.get('contentType') == 'audio':
				for i_Node in i_AdaptationSet.findall( XMLNS + 'Representation' ):
					node_sound = AUDIO_VALUE[ self.getAudioAdaptInfo( XMLNS, i_Node) ]
					if MAX_AUDIO != node_sound : 
						i_AdaptationSet.remove( i_Node )


		print( MAX_VIDEO )


		# 확인용 파일저장 (namespaces)
		'''
		self.indent( rootNode )
		tree = ET.ElementTree( rootNode )
		tree.write( pret_filename, encoding='utf-8', xml_declaration=True, method='xml' )
		'''

		# 확인용 (일부만)
		'''
		root = xml.dom.minidom.parseString( mpd.encode('utf8') )
		pretty = root.toprettyxml(encoding='utf-8')
		with open( pret_filename, 'w+') as fp:
			for ii in pretty.splitlines():
				line = ii.decode('utf-8')
				#if line.startswith('\t\t\t'): continue
				fp.write( line + '\n' )
		'''

		xml_String = ET.tostring(rootNode).decode('utf-8')
		xml_String = xml.dom.minidom.parseString(xml_String) # prettyxml
		xml_String = xml_String.toprettyxml(indent="  ")     # prettyxml


		try:
			mpd_filename = self.REQ_INFO['addon']['playOption']['streamFilename']
			fp = open(mpd_filename, 'w', -1, 'utf-8')
			fp.write(xml_String)
			fp.close()
		except Exception as exception:
			pass


		return xml_String


	def getAudioAdaptInfo( self, XMLNS, adaptNode ):
		if adaptNode.attrib.get('codecs').startswith( 'ec-3' ) : return 'ATMOS'

		iNode = adaptNode.find( XMLNS + 'AudioChannelConfiguration' )
		if   iNode.attrib.get('value') == '2': return '2CH'
		elif iNode.attrib.get('value') == '6': return '6CH'

		return '-'


	def indent( self, elem, level=0 ):
		i = "\n" + level*"  "
		if len(elem):
			if not elem.text or not elem.text.strip():
				elem.text = i + "  "
			if not elem.tail or not elem.tail.strip():
				elem.tail = i
			for elem in elem:
				self.indent(elem, level+1)
			if not elem.tail or not elem.tail.strip():
				elem.tail = i
		else:
			if level and (not elem.tail or not elem.tail.strip()):
				elem.tail = i


	def _gzip(self, data=None):
		from io import BytesIO
		from gzip import GzipFile
		out = BytesIO()
		f = GzipFile(fileobj=out, mode='w', compresslevel=5)
		f.write(data)
		f.close()
		return out.getvalue()



class WatchaProxy(object):
	def __init__( self ):
		self.started = False
		self.PORT = None

	def start(self):
		if self.started: return

		self._server = HTTPServer( ('0.0.0.0', self.PORT), BoriProxyHandler )
		#self._server.timeout = 10
		self._httpd_thread = threading.Thread(target=self._server.serve_forever)
		self._httpd_thread.start()
		self.started = True

	def stop(self):
		if not self.started: return

		self._server.shutdown()
		self._server.server_close()
		self._server.socket.close()
		self._httpd_thread.join()
		self.started = False



if __name__ == "__main__":
	TEST_PORT = 9999
	httpd = HTTPServer( ('0.0.0.0', TEST_PORT), BoriProxyHandler )
	print(f'Server running on port : {TEST_PORT}')
	httpd.serve_forever()
