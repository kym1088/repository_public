__author__="NightRain"
PhxkrJDoqYCwsazXniAfHtNlLcMERg=str
PhxkrJDoqYCwsazXniAfHtNlLcMERF=True
PhxkrJDoqYCwsazXniAfHtNlLcMERI=False
PhxkrJDoqYCwsazXniAfHtNlLcMERS=print
PhxkrJDoqYCwsazXniAfHtNlLcMERb=open
PhxkrJDoqYCwsazXniAfHtNlLcMERu=Exception
PhxkrJDoqYCwsazXniAfHtNlLcMEvR=int
import json
import time
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 PhxkrJDoqYCwsazXniAfHtNlLcMERQ='ADDON'
except:
 PhxkrJDoqYCwsazXniAfHtNlLcMERQ='SINGLE'
if PhxkrJDoqYCwsazXniAfHtNlLcMERQ=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  PhxkrJDoqYCwsazXniAfHtNlLcMERG=PhxkrJDoqYCwsazXniAfHtNlLcMERg(string).encode('utf-8','ignore')
  PhxkrJDoqYCwsazXniAfHtNlLcMERK=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,PhxkrJDoqYCwsazXniAfHtNlLcMERG),level=PhxkrJDoqYCwsazXniAfHtNlLcMERK)
 def addon_getautoepg():
  return PhxkrJDoqYCwsazXniAfHtNlLcMERF if __addon__.getSetting('autoEpg')=='true' else PhxkrJDoqYCwsazXniAfHtNlLcMERI
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  PhxkrJDoqYCwsazXniAfHtNlLcMERS(string)
 def addon_getautoepg():
  return PhxkrJDoqYCwsazXniAfHtNlLcMERF
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class PhxkrJDoqYCwsazXniAfHtNlLcMERv():
 def __init__(PhxkrJDoqYCwsazXniAfHtNlLcMERB):
  PhxkrJDoqYCwsazXniAfHtNlLcMERB.START_INTERVAL =3000 
  PhxkrJDoqYCwsazXniAfHtNlLcMERB.INTERVAL =20 
  PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_FILETAGNM ='date_makeepg'
  PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_MAKEDATE ='-' 
  PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_WILL_TM =-1 
 def Get_Now_Datetime(PhxkrJDoqYCwsazXniAfHtNlLcMERB):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(PhxkrJDoqYCwsazXniAfHtNlLcMERB):
  PhxkrJDoqYCwsazXniAfHtNlLcMERd ='-'
  if PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_MAKEDATE=='-':
   try:
    fp=PhxkrJDoqYCwsazXniAfHtNlLcMERb(addon_epgupdate_confignm(),'r',-1,'utf-8')
    PhxkrJDoqYCwsazXniAfHtNlLcMERp= json.load(fp)
    fp.close()
    PhxkrJDoqYCwsazXniAfHtNlLcMERd=PhxkrJDoqYCwsazXniAfHtNlLcMERp[PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_FILETAGNM]
   except PhxkrJDoqYCwsazXniAfHtNlLcMERu as exception:
    return 2 
  else:
   PhxkrJDoqYCwsazXniAfHtNlLcMERd=PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_MAKEDATE
  PhxkrJDoqYCwsazXniAfHtNlLcMERV =PhxkrJDoqYCwsazXniAfHtNlLcMERB.Get_Now_Datetime()
  PhxkrJDoqYCwsazXniAfHtNlLcMERO=(PhxkrJDoqYCwsazXniAfHtNlLcMERV-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  PhxkrJDoqYCwsazXniAfHtNlLcMERT =PhxkrJDoqYCwsazXniAfHtNlLcMERV.strftime('%Y-%m-%d')
  PhxkrJDoqYCwsazXniAfHtNlLcMERj =PhxkrJDoqYCwsazXniAfHtNlLcMERV.strftime('%H')
  if PhxkrJDoqYCwsazXniAfHtNlLcMERd==PhxkrJDoqYCwsazXniAfHtNlLcMERT: return-1
  if PhxkrJDoqYCwsazXniAfHtNlLcMERd==PhxkrJDoqYCwsazXniAfHtNlLcMERO and PhxkrJDoqYCwsazXniAfHtNlLcMERj=='00':return 30
  return 2
 def MakeEpg_RandomTm(PhxkrJDoqYCwsazXniAfHtNlLcMERB,mintm):
  PhxkrJDoqYCwsazXniAfHtNlLcMERW=(mintm*60)+random.randint(0,60)
  PhxkrJDoqYCwsazXniAfHtNlLcMERV =PhxkrJDoqYCwsazXniAfHtNlLcMERB.Get_Now_Datetime()
  PhxkrJDoqYCwsazXniAfHtNlLcMERy =(PhxkrJDoqYCwsazXniAfHtNlLcMERV+datetime.timedelta(seconds=PhxkrJDoqYCwsazXniAfHtNlLcMERW)).strftime('%Y%m%d%H%M%S')
  return PhxkrJDoqYCwsazXniAfHtNlLcMEvR(PhxkrJDoqYCwsazXniAfHtNlLcMERy)
 def MakeEpg_SaveJson(PhxkrJDoqYCwsazXniAfHtNlLcMERB):
  PhxkrJDoqYCwsazXniAfHtNlLcMERp={PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_FILETAGNM:PhxkrJDoqYCwsazXniAfHtNlLcMERB.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=PhxkrJDoqYCwsazXniAfHtNlLcMERb(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(PhxkrJDoqYCwsazXniAfHtNlLcMERp,fp)
   fp.close()
  except PhxkrJDoqYCwsazXniAfHtNlLcMERu as exception:
   return
 def service_run(PhxkrJDoqYCwsazXniAfHtNlLcMERB):
  if addon_getautoepg()==PhxkrJDoqYCwsazXniAfHtNlLcMERI:return
  PhxkrJDoqYCwsazXniAfHtNlLcMERe=PhxkrJDoqYCwsazXniAfHtNlLcMERB.MakeEpg_DateCheck()
  if PhxkrJDoqYCwsazXniAfHtNlLcMERe<0:
   return
  if PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_WILL_TM<0:
   PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_WILL_TM=PhxkrJDoqYCwsazXniAfHtNlLcMERB.MakeEpg_RandomTm(PhxkrJDoqYCwsazXniAfHtNlLcMERe)
   addon_log('EPG_WILL_TM --> '+PhxkrJDoqYCwsazXniAfHtNlLcMERg(PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_WILL_TM))
  else:
   PhxkrJDoqYCwsazXniAfHtNlLcMERT=PhxkrJDoqYCwsazXniAfHtNlLcMERB.Get_Now_Datetime()
   if PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_WILL_TM<PhxkrJDoqYCwsazXniAfHtNlLcMEvR(PhxkrJDoqYCwsazXniAfHtNlLcMERT.strftime('%Y%m%d%H%M%S')):
    addon_log('make epg')
    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
    PhxkrJDoqYCwsazXniAfHtNlLcMERB.MakeEpg_SaveJson()
    PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_MAKEDATE=PhxkrJDoqYCwsazXniAfHtNlLcMERT.strftime('%Y-%m-%d')
    PhxkrJDoqYCwsazXniAfHtNlLcMERB.EPG_WILL_TM =-1
   else:
    pass
  pass
if __name__=="__main__":
 addon_log('__main__')
 PhxkrJDoqYCwsazXniAfHtNlLcMERm=PhxkrJDoqYCwsazXniAfHtNlLcMERv()
 time.sleep(PhxkrJDoqYCwsazXniAfHtNlLcMERm.START_INTERVAL)
 while PhxkrJDoqYCwsazXniAfHtNlLcMERF:
  time.sleep(PhxkrJDoqYCwsazXniAfHtNlLcMERm.INTERVAL)
  PhxkrJDoqYCwsazXniAfHtNlLcMERm.service_run()
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
