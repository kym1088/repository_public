__author__="NightRain"
BDpUxhsIcnCOTaifmQoWzAgLSrbFHy=object
BDpUxhsIcnCOTaifmQoWzAgLSrbFHP=False
BDpUxhsIcnCOTaifmQoWzAgLSrbFtY=None
BDpUxhsIcnCOTaifmQoWzAgLSrbFtv=True
BDpUxhsIcnCOTaifmQoWzAgLSrbFtH=len
BDpUxhsIcnCOTaifmQoWzAgLSrbFtj=str
BDpUxhsIcnCOTaifmQoWzAgLSrbFtw=open
BDpUxhsIcnCOTaifmQoWzAgLSrbFtJ=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
BDpUxhsIcnCOTaifmQoWzAgLSrbFYH=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (시즌)','mode':'ADD_M3U','sType':'seezn','sName':'시즌'},{'title':'     - M3U 추가 (삼성tv 플러스)','mode':'ADD_M3U','sType':'samsung','sName':'삼성TV 플러스'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
BDpUxhsIcnCOTaifmQoWzAgLSrbFYt=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class BDpUxhsIcnCOTaifmQoWzAgLSrbFYv(BDpUxhsIcnCOTaifmQoWzAgLSrbFHy):
 def __init__(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj,BDpUxhsIcnCOTaifmQoWzAgLSrbFYw,BDpUxhsIcnCOTaifmQoWzAgLSrbFYJ,BDpUxhsIcnCOTaifmQoWzAgLSrbFYR):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj._addon_url =BDpUxhsIcnCOTaifmQoWzAgLSrbFYw
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj._addon_handle =BDpUxhsIcnCOTaifmQoWzAgLSrbFYJ
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.main_params =BDpUxhsIcnCOTaifmQoWzAgLSrbFYR
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_FILE_PATH ='' 
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_FILE_NAME ='' 
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVE =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONTVING =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSPOTV =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZN =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSAMSUNG =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVERADIO =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVEHOME =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONRELIGION =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSPOTVPAY =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZNPAY =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZNHOME =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZNRADIO =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSAMSUNGHOME=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_DISPLAYNM =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_AUTORESTART =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj =dSErPRhcuVptLilygUqOQmJfzsMFjT() 
 def addon_noti(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj,sting):
  try:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYN=xbmcgui.Dialog()
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYN.notification(__addonname__,sting)
  except:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFtY
 def addon_log(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj,string):
  try:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYX=string.encode('utf-8','ignore')
  except:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYX='addonException: addon_log'
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYd=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,BDpUxhsIcnCOTaifmQoWzAgLSrbFYX),level=BDpUxhsIcnCOTaifmQoWzAgLSrbFYd)
 def get_keyboard_input(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj,BDpUxhsIcnCOTaifmQoWzAgLSrbFYE):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYl=BDpUxhsIcnCOTaifmQoWzAgLSrbFtY
  kb=xbmc.Keyboard()
  kb.setHeading(BDpUxhsIcnCOTaifmQoWzAgLSrbFYE)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYl=kb.getText()
  return BDpUxhsIcnCOTaifmQoWzAgLSrbFYl
 def add_dir(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj,label,sublabel='',img='',infoLabels=BDpUxhsIcnCOTaifmQoWzAgLSrbFtY,isFolder=BDpUxhsIcnCOTaifmQoWzAgLSrbFtv,params='',isLink=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP,ContextMenu=BDpUxhsIcnCOTaifmQoWzAgLSrbFtY):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYK='%s?%s'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj._addon_url,urllib.parse.urlencode(params))
  if sublabel:BDpUxhsIcnCOTaifmQoWzAgLSrbFYE='%s < %s >'%(label,sublabel)
  else: BDpUxhsIcnCOTaifmQoWzAgLSrbFYE=label
  if not img:img='DefaultFolder.png'
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYu=xbmcgui.ListItem(BDpUxhsIcnCOTaifmQoWzAgLSrbFYE)
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYu.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:BDpUxhsIcnCOTaifmQoWzAgLSrbFYu.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYu.setProperty('IsPlayable','true')
  if ContextMenu:BDpUxhsIcnCOTaifmQoWzAgLSrbFYu.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj._addon_handle,BDpUxhsIcnCOTaifmQoWzAgLSrbFYK,BDpUxhsIcnCOTaifmQoWzAgLSrbFYu,isFolder)
 def make_M3u_Filename(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj,tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_FILE_PATH+BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj,tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_FILE_PATH+BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_FILE_NAME+'.xml'
 def dp_Main_List(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj):
  for BDpUxhsIcnCOTaifmQoWzAgLSrbFYV in BDpUxhsIcnCOTaifmQoWzAgLSrbFYH:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYE=BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('title')
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYG=''
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYM={'mode':BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('mode'),'sType':BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('sType'),'sName':BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('sName')}
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('mode')=='XXX':
    BDpUxhsIcnCOTaifmQoWzAgLSrbFYe=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
    BDpUxhsIcnCOTaifmQoWzAgLSrbFYk =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv
   else:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFYe=BDpUxhsIcnCOTaifmQoWzAgLSrbFtv
    BDpUxhsIcnCOTaifmQoWzAgLSrbFYk =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYy=BDpUxhsIcnCOTaifmQoWzAgLSrbFtv
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('mode')=='ADD_M3U':
    if BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('sType')=='wavve' and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVE ==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:BDpUxhsIcnCOTaifmQoWzAgLSrbFYy=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
    if BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('sType')=='tving' and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONTVING ==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:BDpUxhsIcnCOTaifmQoWzAgLSrbFYy=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
    if BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('sType')=='spotv' and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSPOTV ==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:BDpUxhsIcnCOTaifmQoWzAgLSrbFYy=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
    if BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('sType')=='seezn' and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZN ==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:BDpUxhsIcnCOTaifmQoWzAgLSrbFYy=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
    if BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('sType')=='samsung' and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSAMSUNG==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:BDpUxhsIcnCOTaifmQoWzAgLSrbFYy=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFYy==BDpUxhsIcnCOTaifmQoWzAgLSrbFtv:
    if 'icon' in BDpUxhsIcnCOTaifmQoWzAgLSrbFYV:BDpUxhsIcnCOTaifmQoWzAgLSrbFYG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',BDpUxhsIcnCOTaifmQoWzAgLSrbFYV.get('icon')) 
    BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.add_dir(BDpUxhsIcnCOTaifmQoWzAgLSrbFYE,sublabel='',img=BDpUxhsIcnCOTaifmQoWzAgLSrbFYG,infoLabels=BDpUxhsIcnCOTaifmQoWzAgLSrbFtY,isFolder=BDpUxhsIcnCOTaifmQoWzAgLSrbFYe,params=BDpUxhsIcnCOTaifmQoWzAgLSrbFYM,isLink=BDpUxhsIcnCOTaifmQoWzAgLSrbFYk)
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFYH)>0:xbmcplugin.endOfDirectory(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj._addon_handle,cacheToDisc=BDpUxhsIcnCOTaifmQoWzAgLSrbFtv)
 def dp_Delete_M3u(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj,args):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYN=xbmcgui.Dialog()
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvY=BDpUxhsIcnCOTaifmQoWzAgLSrbFYN.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFvY==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:sys.exit()
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvH=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_M3u_Filename(tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP)
  if xbmcvfs.exists(BDpUxhsIcnCOTaifmQoWzAgLSrbFvH):
   if xbmcvfs.delete(BDpUxhsIcnCOTaifmQoWzAgLSrbFvH)==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_noti(__language__(30910).encode('utf-8'))
    return
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj,args):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=args.get('sType')
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvj=args.get('sName')
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYN=xbmcgui.Dialog()
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvY=BDpUxhsIcnCOTaifmQoWzAgLSrbFYN.yesno((BDpUxhsIcnCOTaifmQoWzAgLSrbFvj+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFvY==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:sys.exit()
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvw =[]
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvJ =[]
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvH=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_M3u_Filename(tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFtv)
  if os.path.isfile(BDpUxhsIcnCOTaifmQoWzAgLSrbFvH):os.remove(BDpUxhsIcnCOTaifmQoWzAgLSrbFvH)
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='all':
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvH=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_M3u_Filename(tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP)
   if xbmcvfs.exists(BDpUxhsIcnCOTaifmQoWzAgLSrbFvH):
    if xbmcvfs.delete(BDpUxhsIcnCOTaifmQoWzAgLSrbFvH)==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:
     BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvR=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_M3u_Filename(tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP)
   if xbmcvfs.exists(BDpUxhsIcnCOTaifmQoWzAgLSrbFvR):
    BDpUxhsIcnCOTaifmQoWzAgLSrbFvq=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_M3u_Filename(tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFtv)
    xbmcvfs.copy(BDpUxhsIcnCOTaifmQoWzAgLSrbFvR,BDpUxhsIcnCOTaifmQoWzAgLSrbFvq)
  if(BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='wavve' or BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='all')and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVE:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvN=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_ChannelList_Wavve(exceptGroup=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_EexceptGroup_Wavve())
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)!=0:BDpUxhsIcnCOTaifmQoWzAgLSrbFvw.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_log('wavve cnt ----> '+BDpUxhsIcnCOTaifmQoWzAgLSrbFtj(BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)))
  if(BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='tving' or BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='all')and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONTVING:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvN=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_ChannelList_Tving()
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)!=0:BDpUxhsIcnCOTaifmQoWzAgLSrbFvw.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_log('tving cnt ----> '+BDpUxhsIcnCOTaifmQoWzAgLSrbFtj(BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)))
  if(BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='spotv' or BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='all')and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSPOTV:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvN=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_ChannelList_Spotv(payyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSPOTVPAY)
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)!=0:BDpUxhsIcnCOTaifmQoWzAgLSrbFvw.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_log('spotv cnt ----> '+BDpUxhsIcnCOTaifmQoWzAgLSrbFtj(BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)))
  if(BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='seezn' or BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='all')and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZN:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvN=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_ChannelList_Seezn(exceptGroup=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_EexceptGroup_Seezn())
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)!=0:BDpUxhsIcnCOTaifmQoWzAgLSrbFvw.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_log('seezn cnt ----> '+BDpUxhsIcnCOTaifmQoWzAgLSrbFtj(BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)))
  if(BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='samsung' or BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='all')and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSAMSUNG:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvX=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_BaseInfo_Samsungtv()
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvN=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_ChannelList_Samsungtv(BDpUxhsIcnCOTaifmQoWzAgLSrbFvX,exceptGroup=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_EexceptGroup_Samsungtv())
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)!=0:BDpUxhsIcnCOTaifmQoWzAgLSrbFvw.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_log('samsungtv cnt ----> '+BDpUxhsIcnCOTaifmQoWzAgLSrbFtj(BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFvN)))
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFvw)==0:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_noti(__language__(30909).encode('utf8'))
   return
  for BDpUxhsIcnCOTaifmQoWzAgLSrbFvd in BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.INIT_GENRESORT:
   for BDpUxhsIcnCOTaifmQoWzAgLSrbFvl in BDpUxhsIcnCOTaifmQoWzAgLSrbFvw:
    if BDpUxhsIcnCOTaifmQoWzAgLSrbFvl['genrenm']==BDpUxhsIcnCOTaifmQoWzAgLSrbFvd:
     BDpUxhsIcnCOTaifmQoWzAgLSrbFvJ.append(BDpUxhsIcnCOTaifmQoWzAgLSrbFvl)
  for BDpUxhsIcnCOTaifmQoWzAgLSrbFvl in BDpUxhsIcnCOTaifmQoWzAgLSrbFvw:
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFvl['genrenm']not in BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.INIT_GENRESORT:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFvJ.append(BDpUxhsIcnCOTaifmQoWzAgLSrbFvl)
  try:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvH=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_M3u_Filename(tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFtv)
   if os.path.isfile(BDpUxhsIcnCOTaifmQoWzAgLSrbFvH):
    fp=BDpUxhsIcnCOTaifmQoWzAgLSrbFtw(BDpUxhsIcnCOTaifmQoWzAgLSrbFvH,'a',-1,'utf-8')
   else:
    fp=BDpUxhsIcnCOTaifmQoWzAgLSrbFtw(BDpUxhsIcnCOTaifmQoWzAgLSrbFvH,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for BDpUxhsIcnCOTaifmQoWzAgLSrbFvK in BDpUxhsIcnCOTaifmQoWzAgLSrbFvJ:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFvE =BDpUxhsIcnCOTaifmQoWzAgLSrbFvK['channelid']
    BDpUxhsIcnCOTaifmQoWzAgLSrbFvu =BDpUxhsIcnCOTaifmQoWzAgLSrbFvK['channelnm']
    BDpUxhsIcnCOTaifmQoWzAgLSrbFvV=BDpUxhsIcnCOTaifmQoWzAgLSrbFvK['channelimg']
    BDpUxhsIcnCOTaifmQoWzAgLSrbFvG =BDpUxhsIcnCOTaifmQoWzAgLSrbFvK['ott']
    BDpUxhsIcnCOTaifmQoWzAgLSrbFvM ='%s.%s'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFvE,BDpUxhsIcnCOTaifmQoWzAgLSrbFvG)
    BDpUxhsIcnCOTaifmQoWzAgLSrbFve=BDpUxhsIcnCOTaifmQoWzAgLSrbFvK['genrenm']
    if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_DISPLAYNM:
     BDpUxhsIcnCOTaifmQoWzAgLSrbFvu='%s (%s)'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFvu,BDpUxhsIcnCOTaifmQoWzAgLSrbFvG)
    if BDpUxhsIcnCOTaifmQoWzAgLSrbFve=='라디오/음악':
     BDpUxhsIcnCOTaifmQoWzAgLSrbFvk='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFvM,BDpUxhsIcnCOTaifmQoWzAgLSrbFvu,BDpUxhsIcnCOTaifmQoWzAgLSrbFve,BDpUxhsIcnCOTaifmQoWzAgLSrbFvV,BDpUxhsIcnCOTaifmQoWzAgLSrbFvu)
    else:
     BDpUxhsIcnCOTaifmQoWzAgLSrbFvk='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFvM,BDpUxhsIcnCOTaifmQoWzAgLSrbFvu,BDpUxhsIcnCOTaifmQoWzAgLSrbFve,BDpUxhsIcnCOTaifmQoWzAgLSrbFvV,BDpUxhsIcnCOTaifmQoWzAgLSrbFvu)
    if BDpUxhsIcnCOTaifmQoWzAgLSrbFvG=='wavve':
     BDpUxhsIcnCOTaifmQoWzAgLSrbFvy ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFvE)
    elif BDpUxhsIcnCOTaifmQoWzAgLSrbFvG=='tving':
     BDpUxhsIcnCOTaifmQoWzAgLSrbFvy ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFvE)
    elif BDpUxhsIcnCOTaifmQoWzAgLSrbFvG=='spotv':
     BDpUxhsIcnCOTaifmQoWzAgLSrbFvy ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFvE)
    elif BDpUxhsIcnCOTaifmQoWzAgLSrbFvG=='seezn':
     BDpUxhsIcnCOTaifmQoWzAgLSrbFvP='128' if BDpUxhsIcnCOTaifmQoWzAgLSrbFve=='라디오/음악' else '4000'
     BDpUxhsIcnCOTaifmQoWzAgLSrbFvy ='plugin://plugin.video.seeznm/?mode=LIVE&mediacode=%s&bitrate=%s\n'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFvE,BDpUxhsIcnCOTaifmQoWzAgLSrbFvP)
    if BDpUxhsIcnCOTaifmQoWzAgLSrbFvG=='samsung':
     BDpUxhsIcnCOTaifmQoWzAgLSrbFvy ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFvE)
    fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFvk)
    fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFvy)
   fp.close()
  except:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_noti(__language__(30910).encode('utf8'))
   return
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvR=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_M3u_Filename(tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFtv)
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvq=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_M3u_Filename(tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP)
  if xbmcvfs.copy(BDpUxhsIcnCOTaifmQoWzAgLSrbFvR,BDpUxhsIcnCOTaifmQoWzAgLSrbFvq):
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_noti((BDpUxhsIcnCOTaifmQoWzAgLSrbFvj+' '+__language__(30908)).encode('utf8'))
  else:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_noti(__language__(30910).encode('utf-8'))
 def dp_Make_Epg(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj,args):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=args.get('sType')
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvj=args.get('sName')
  BDpUxhsIcnCOTaifmQoWzAgLSrbFHY=args.get('sNoti')
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFHY!='N':
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYN=xbmcgui.Dialog()
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvY=BDpUxhsIcnCOTaifmQoWzAgLSrbFYN.yesno((BDpUxhsIcnCOTaifmQoWzAgLSrbFvj+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFvY==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:sys.exit()
  BDpUxhsIcnCOTaifmQoWzAgLSrbFHv=[]
  BDpUxhsIcnCOTaifmQoWzAgLSrbFHt=[]
  if(BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='wavve' or BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='all')and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVE:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHj,BDpUxhsIcnCOTaifmQoWzAgLSrbFHw=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_EexceptGroup_Wavve())
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFHw)!=0:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHv.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFHj)
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHt.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFHw)
  if(BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='tving' or BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='all')and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONTVING:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHj,BDpUxhsIcnCOTaifmQoWzAgLSrbFHw=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_EpgInfo_Tving()
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFHw)!=0:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHv.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFHj)
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHt.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFHw)
  if(BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='spotv' or BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='all')and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSPOTV:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHj,BDpUxhsIcnCOTaifmQoWzAgLSrbFHw=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_EpgInfo_Spotv(payyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSPOTVPAY)
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFHw)!=0:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHv.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFHj)
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHt.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFHw)
  if(BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='seezn' or BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='all')and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZN:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHj,BDpUxhsIcnCOTaifmQoWzAgLSrbFHw=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_EpgInfo_Seezn(exceptGroup=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_EexceptGroup_Seezn())
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFHw)!=0:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHv.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFHj)
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHt.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFHw)
  if(BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='samsung' or BDpUxhsIcnCOTaifmQoWzAgLSrbFvt=='all')and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSAMSUNG:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvX=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_BaseInfo_Samsungtv()
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHj,BDpUxhsIcnCOTaifmQoWzAgLSrbFHw=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_EpgInfo_Samsungtv(BDpUxhsIcnCOTaifmQoWzAgLSrbFvX,exceptGroup=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_EexceptGroup_Samsungtv())
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFHw)!=0:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHv.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFHj)
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHt.extend(BDpUxhsIcnCOTaifmQoWzAgLSrbFHw)
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFtH(BDpUxhsIcnCOTaifmQoWzAgLSrbFHt)==0:
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFHY!='N':BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvH=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_Epg_Filename(tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFtv)
   fp=BDpUxhsIcnCOTaifmQoWzAgLSrbFtw(BDpUxhsIcnCOTaifmQoWzAgLSrbFvH,'w',-1,'utf-8')
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHJ='<?xml version="1.0" encoding="UTF-8"?>\n'
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHR='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHq='<tv generator-info-name="boritv_epg">\n\n'
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHN='\n</tv>\n'
   fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFHJ)
   fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFHR)
   fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFHq)
   for BDpUxhsIcnCOTaifmQoWzAgLSrbFHX in BDpUxhsIcnCOTaifmQoWzAgLSrbFHv:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHd='  <channel id="%s.%s">\n' %(BDpUxhsIcnCOTaifmQoWzAgLSrbFHX.get('channelid'),BDpUxhsIcnCOTaifmQoWzAgLSrbFHX.get('ott'))
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHl='    <display-name>%s</display-name>\n'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFHX.get('channelnm'))
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHK='    <icon src="%s" />\n' %(BDpUxhsIcnCOTaifmQoWzAgLSrbFHX.get('channelimg'))
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHE='  </channel>\n\n'
    fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFHd)
    fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFHl)
    fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFHK)
    fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFHE)
   for BDpUxhsIcnCOTaifmQoWzAgLSrbFHX in BDpUxhsIcnCOTaifmQoWzAgLSrbFHt:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHd='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(BDpUxhsIcnCOTaifmQoWzAgLSrbFHX.get('startTime'),BDpUxhsIcnCOTaifmQoWzAgLSrbFHX.get('endTime'),BDpUxhsIcnCOTaifmQoWzAgLSrbFHX.get('channelid'),BDpUxhsIcnCOTaifmQoWzAgLSrbFHX.get('ott'))
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHl='    <title lang="kr">%s</title>\n' %(BDpUxhsIcnCOTaifmQoWzAgLSrbFHX.get('title'))
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHK='  </programme>\n\n'
    fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFHd)
    fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFHl)
    fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFHK)
   fp.write(BDpUxhsIcnCOTaifmQoWzAgLSrbFHN)
   fp.close()
  except:
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFHY!='N':BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_noti(__language__(30910).encode('utf8'))
   return
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.MakeEpg_SaveJson()
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvR=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_Epg_Filename(tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFtv)
  BDpUxhsIcnCOTaifmQoWzAgLSrbFvq=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.make_Epg_Filename(tempyn=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP)
  if xbmcvfs.copy(BDpUxhsIcnCOTaifmQoWzAgLSrbFvR,BDpUxhsIcnCOTaifmQoWzAgLSrbFvq):
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFHY!='N':BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_noti((BDpUxhsIcnCOTaifmQoWzAgLSrbFvj+' '+__language__(30912)).encode('utf8'))
  else:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_AUTORESTART:
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHu=xbmcaddon.Addon('pvr.iptvsimple')
    BDpUxhsIcnCOTaifmQoWzAgLSrbFHu.setSetting('anything','anything')
  except:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFtY 
 def make_EexceptGroup_Wavve(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFHV=[]
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVERADIO==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHV.append('라디오/음악')
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVEHOME==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHV.append('홈쇼핑')
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONRELIGION==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHV.append('종교')
  return BDpUxhsIcnCOTaifmQoWzAgLSrbFHV
 def make_EexceptGroup_Seezn(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFHV=[]
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZNRADIO==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHV.append('라디오/음악')
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZNHOME==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHV.append('홈쇼핑')
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZNPAY==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHV.append('won')
  return BDpUxhsIcnCOTaifmQoWzAgLSrbFHV
 def make_EexceptGroup_Samsungtv(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFHV=[]
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSAMSUNGHOME==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFHV.append('홈쇼핑')
  return BDpUxhsIcnCOTaifmQoWzAgLSrbFHV
 def get_radio_list(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj):
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVERADIO==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:return[]
  BDpUxhsIcnCOTaifmQoWzAgLSrbFHG=[{'broadcastid':'46584','genre':'10'}]
  return BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_ChannelList_WavveExcept(BDpUxhsIcnCOTaifmQoWzAgLSrbFHG)
 def check_config(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFHM=BDpUxhsIcnCOTaifmQoWzAgLSrbFtv
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVE =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onWavve')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONTVING =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onTvng')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSPOTV =BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZN =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onSeezn')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSAMSUNG =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onSamsung')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVERADIO =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onWavveRadio')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVEHOME =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onWavveHome')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONRELIGION =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onWavveReligion')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSPOTVPAY =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onSpotvPay')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZNPAY =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onSeeznPay')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZNHOME =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onSeeznHome')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZNRADIO =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onSeeznRadio')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSAMSUNGHOME =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('onSamsungHome')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_DISPLAYNM =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('displayOTTnm')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_AUTORESTART =BDpUxhsIcnCOTaifmQoWzAgLSrbFtv if __addon__.getSetting('autoRestart')=='true' else BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_FILE_PATH=='' or BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_FILE_NAME=='':BDpUxhsIcnCOTaifmQoWzAgLSrbFHM=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONWAVVE==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONTVING==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSEEZN==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP and BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.M3U_ONSAMSUNG==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:BDpUxhsIcnCOTaifmQoWzAgLSrbFHM=BDpUxhsIcnCOTaifmQoWzAgLSrbFHP
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFHM==BDpUxhsIcnCOTaifmQoWzAgLSrbFHP:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYN=xbmcgui.Dialog()
   BDpUxhsIcnCOTaifmQoWzAgLSrbFvY=BDpUxhsIcnCOTaifmQoWzAgLSrbFYN.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if BDpUxhsIcnCOTaifmQoWzAgLSrbFvY==BDpUxhsIcnCOTaifmQoWzAgLSrbFtv:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFHe={'date_makeepg':BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=BDpUxhsIcnCOTaifmQoWzAgLSrbFtw(BDpUxhsIcnCOTaifmQoWzAgLSrbFYt,'w',-1,'utf-8')
   json.dump(BDpUxhsIcnCOTaifmQoWzAgLSrbFHe,fp)
   fp.close()
  except BDpUxhsIcnCOTaifmQoWzAgLSrbFtJ as exception:
   return
 def boritv_main(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj):
  BDpUxhsIcnCOTaifmQoWzAgLSrbFHk=BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.main_params.get('mode',BDpUxhsIcnCOTaifmQoWzAgLSrbFtY)
  BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.check_config()
  if BDpUxhsIcnCOTaifmQoWzAgLSrbFHk is BDpUxhsIcnCOTaifmQoWzAgLSrbFtY:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.dp_Main_List()
  elif BDpUxhsIcnCOTaifmQoWzAgLSrbFHk=='DEL_M3U':
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.dp_Delete_M3u(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.main_params)
  elif BDpUxhsIcnCOTaifmQoWzAgLSrbFHk=='ADD_M3U':
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.dp_MakeAdd_M3u(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.main_params)
  elif BDpUxhsIcnCOTaifmQoWzAgLSrbFHk=='ADD_EPG':
   BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.dp_Make_Epg(BDpUxhsIcnCOTaifmQoWzAgLSrbFYj.main_params)
  else:
   BDpUxhsIcnCOTaifmQoWzAgLSrbFtY
# Created by pyminifier (https://github.com/liftoff/pyminifier)
