__author__="NightRain"
dSErPRhcuVptLilygUqOQmJfzsMFXj=False
dSErPRhcuVptLilygUqOQmJfzsMFXT=object
dSErPRhcuVptLilygUqOQmJfzsMFXH=None
dSErPRhcuVptLilygUqOQmJfzsMFXv=str
dSErPRhcuVptLilygUqOQmJfzsMFXn=Exception
dSErPRhcuVptLilygUqOQmJfzsMFXA=print
dSErPRhcuVptLilygUqOQmJfzsMFXa=True
dSErPRhcuVptLilygUqOQmJfzsMFXD=int
dSErPRhcuVptLilygUqOQmJfzsMFXN=range
dSErPRhcuVptLilygUqOQmJfzsMFXb=len
dSErPRhcuVptLilygUqOQmJfzsMFXY=set
dSErPRhcuVptLilygUqOQmJfzsMFXx=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
dSErPRhcuVptLilygUqOQmJfzsMFjH=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
dSErPRhcuVptLilygUqOQmJfzsMFjv=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':dSErPRhcuVptLilygUqOQmJfzsMFXj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':dSErPRhcuVptLilygUqOQmJfzsMFXj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':dSErPRhcuVptLilygUqOQmJfzsMFXj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':dSErPRhcuVptLilygUqOQmJfzsMFXj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':dSErPRhcuVptLilygUqOQmJfzsMFXj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':dSErPRhcuVptLilygUqOQmJfzsMFXj,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class dSErPRhcuVptLilygUqOQmJfzsMFjT(dSErPRhcuVptLilygUqOQmJfzsMFXT):
 def __init__(dSErPRhcuVptLilygUqOQmJfzsMFjX):
  dSErPRhcuVptLilygUqOQmJfzsMFjX.API_WAVVE ='https://apis.wavve.com'
  dSErPRhcuVptLilygUqOQmJfzsMFjX.API_TVING ='https://api.tving.com'
  dSErPRhcuVptLilygUqOQmJfzsMFjX.API_TVINGIMG ='https://image.tving.com'
  dSErPRhcuVptLilygUqOQmJfzsMFjX.API_SPOTV ='https://www.spotvnow.co.kr'
  dSErPRhcuVptLilygUqOQmJfzsMFjX.API_SEEZN ='https://api.seezntv.com'
  dSErPRhcuVptLilygUqOQmJfzsMFjX.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  dSErPRhcuVptLilygUqOQmJfzsMFjX.HTTPTAG ='https://'
  dSErPRhcuVptLilygUqOQmJfzsMFjX.LIMIT_WAVVE =200
  dSErPRhcuVptLilygUqOQmJfzsMFjX.LIMIT_TVING =60
  dSErPRhcuVptLilygUqOQmJfzsMFjX.LIMIT_TVINGEPG=20 
  dSErPRhcuVptLilygUqOQmJfzsMFjX.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
  dSErPRhcuVptLilygUqOQmJfzsMFjX.APPVERSION ='91.0.4472.124' 
  dSErPRhcuVptLilygUqOQmJfzsMFjX.DEVICEMODEL ='Chrome' 
  dSErPRhcuVptLilygUqOQmJfzsMFjX.OSTYPE ='Windows' 
  dSErPRhcuVptLilygUqOQmJfzsMFjX.OSVERSION ='NT 10.0' 
  dSErPRhcuVptLilygUqOQmJfzsMFjX.SEEZN_HEADER ={'X-APP-VERSION':dSErPRhcuVptLilygUqOQmJfzsMFjX.APPVERSION,'X-DEVICE-MODEL':dSErPRhcuVptLilygUqOQmJfzsMFjX.DEVICEMODEL,'X-OS-TYPE':dSErPRhcuVptLilygUqOQmJfzsMFjX.OSTYPE,'X-OS-VERSION':dSErPRhcuVptLilygUqOQmJfzsMFjX.OSVERSION,}
  dSErPRhcuVptLilygUqOQmJfzsMFjX.DEFAULT_HEADER={'user-agent':dSErPRhcuVptLilygUqOQmJfzsMFjX.USER_AGENT}
  dSErPRhcuVptLilygUqOQmJfzsMFjX.SLEEP_TIME =0.2
  dSErPRhcuVptLilygUqOQmJfzsMFjX.INIT_GENRESORT=MASTER_GENRE
  dSErPRhcuVptLilygUqOQmJfzsMFjX.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(dSErPRhcuVptLilygUqOQmJfzsMFjX,jobtype,dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFXH,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH,redirects=dSErPRhcuVptLilygUqOQmJfzsMFXj):
  dSErPRhcuVptLilygUqOQmJfzsMFja=dSErPRhcuVptLilygUqOQmJfzsMFjX.DEFAULT_HEADER
  if headers:dSErPRhcuVptLilygUqOQmJfzsMFja.update(headers)
  if jobtype=='Get':
   dSErPRhcuVptLilygUqOQmJfzsMFjD=requests.get(dSErPRhcuVptLilygUqOQmJfzsMFjW,params=params,headers=dSErPRhcuVptLilygUqOQmJfzsMFja,cookies=cookies,allow_redirects=redirects)
  else:
   dSErPRhcuVptLilygUqOQmJfzsMFjD=requests.post(dSErPRhcuVptLilygUqOQmJfzsMFjW,data=payload,params=params,headers=dSErPRhcuVptLilygUqOQmJfzsMFja,cookies=cookies,allow_redirects=redirects)
  return dSErPRhcuVptLilygUqOQmJfzsMFjD
 def Get_DefaultParams_Wavve(dSErPRhcuVptLilygUqOQmJfzsMFjX):
  dSErPRhcuVptLilygUqOQmJfzsMFjN={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return dSErPRhcuVptLilygUqOQmJfzsMFjN
 def Get_DefaultParams_Tving(dSErPRhcuVptLilygUqOQmJfzsMFjX):
  dSErPRhcuVptLilygUqOQmJfzsMFjN={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return dSErPRhcuVptLilygUqOQmJfzsMFjN
 def Get_Now_Datetime(dSErPRhcuVptLilygUqOQmJfzsMFjX):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(dSErPRhcuVptLilygUqOQmJfzsMFjX,in_text):
  dSErPRhcuVptLilygUqOQmJfzsMFjY=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return dSErPRhcuVptLilygUqOQmJfzsMFjY
 def Get_ChannelList_Wavve(dSErPRhcuVptLilygUqOQmJfzsMFjX,exceptGroup=[]):
  dSErPRhcuVptLilygUqOQmJfzsMFjx =[]
  dSErPRhcuVptLilygUqOQmJfzsMFjC=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_ChannelImg_Wavve()
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_WAVVE+'/cf/live/recommend-channels'
   dSErPRhcuVptLilygUqOQmJfzsMFjN={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFjX.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   dSErPRhcuVptLilygUqOQmJfzsMFjN.update(dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_DefaultParams_Wavve())
   dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFjN,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH)
   dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
   if not('celllist' in dSErPRhcuVptLilygUqOQmJfzsMFje['cell_toplist']):return dSErPRhcuVptLilygUqOQmJfzsMFjx
   dSErPRhcuVptLilygUqOQmJfzsMFjk=dSErPRhcuVptLilygUqOQmJfzsMFje['cell_toplist']['celllist']
   for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFjk:
    dSErPRhcuVptLilygUqOQmJfzsMFjB=dSErPRhcuVptLilygUqOQmJfzsMFjK['contentid']
    dSErPRhcuVptLilygUqOQmJfzsMFjG=dSErPRhcuVptLilygUqOQmJfzsMFjK['title_list'][0]['text']
    if dSErPRhcuVptLilygUqOQmJfzsMFjB in dSErPRhcuVptLilygUqOQmJfzsMFjC:
     dSErPRhcuVptLilygUqOQmJfzsMFjI=dSErPRhcuVptLilygUqOQmJfzsMFjC[dSErPRhcuVptLilygUqOQmJfzsMFjB]
    else:
     dSErPRhcuVptLilygUqOQmJfzsMFjI=''
    dSErPRhcuVptLilygUqOQmJfzsMFjo=dSErPRhcuVptLilygUqOQmJfzsMFjX.make_getGenre(dSErPRhcuVptLilygUqOQmJfzsMFjB,'wavve')
    dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'channelnm':dSErPRhcuVptLilygUqOQmJfzsMFjG,'channelimg':dSErPRhcuVptLilygUqOQmJfzsMFjX.HTTPTAG+dSErPRhcuVptLilygUqOQmJfzsMFjI if dSErPRhcuVptLilygUqOQmJfzsMFjI!='' else '','ott':'wavve','genrenm':dSErPRhcuVptLilygUqOQmJfzsMFjo}
    if dSErPRhcuVptLilygUqOQmJfzsMFjo not in exceptGroup:
     dSErPRhcuVptLilygUqOQmJfzsMFjx.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[]
  return dSErPRhcuVptLilygUqOQmJfzsMFjx
 def Get_ChannelList_WavveExcept(dSErPRhcuVptLilygUqOQmJfzsMFjX,exceptGroup=[]):
  dSErPRhcuVptLilygUqOQmJfzsMFjx=[]
  if exceptGroup==[]:return[]
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_WAVVE+'/cf/live/recommend-channels'
   for dSErPRhcuVptLilygUqOQmJfzsMFjK in exceptGroup:
    dSErPRhcuVptLilygUqOQmJfzsMFjN={'WeekDay':'all','adult':'n','broadcastid':dSErPRhcuVptLilygUqOQmJfzsMFjK['broadcastid'],'contenttype':'channel','genre':dSErPRhcuVptLilygUqOQmJfzsMFjK['genre'],'isrecommend':'y','limit':dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFjX.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    dSErPRhcuVptLilygUqOQmJfzsMFjN.update(dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_DefaultParams_Wavve())
    dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFjN,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH)
    dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
    if not('celllist' in dSErPRhcuVptLilygUqOQmJfzsMFje['cell_toplist']):return dSErPRhcuVptLilygUqOQmJfzsMFjx
    dSErPRhcuVptLilygUqOQmJfzsMFjk=dSErPRhcuVptLilygUqOQmJfzsMFje['cell_toplist']['celllist']
    for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFjk:
     dSErPRhcuVptLilygUqOQmJfzsMFjx.append(dSErPRhcuVptLilygUqOQmJfzsMFjK['contentid'])
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[]
  return dSErPRhcuVptLilygUqOQmJfzsMFjx
 def Get_ChannelImg_Wavve(dSErPRhcuVptLilygUqOQmJfzsMFjX):
  dSErPRhcuVptLilygUqOQmJfzsMFTH={}
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFTv=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_Now_Datetime()
   dSErPRhcuVptLilygUqOQmJfzsMFTX =dSErPRhcuVptLilygUqOQmJfzsMFTv+datetime.timedelta(hours=3)
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_WAVVE+'/live/epgs'
   dSErPRhcuVptLilygUqOQmJfzsMFjN={'limit':dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFjX.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':dSErPRhcuVptLilygUqOQmJfzsMFTv.strftime('%Y-%m-%d %H:00'),'enddatetime':dSErPRhcuVptLilygUqOQmJfzsMFTX.strftime('%Y-%m-%d %H:00')}
   dSErPRhcuVptLilygUqOQmJfzsMFjN.update(dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_DefaultParams_Wavve())
   dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFjN,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH)
   dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
   dSErPRhcuVptLilygUqOQmJfzsMFjk=dSErPRhcuVptLilygUqOQmJfzsMFje['list']
   for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFjk:
    dSErPRhcuVptLilygUqOQmJfzsMFTH[dSErPRhcuVptLilygUqOQmJfzsMFjK['channelid']]=dSErPRhcuVptLilygUqOQmJfzsMFjK['channelimage']
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
  return dSErPRhcuVptLilygUqOQmJfzsMFTH
 def Get_ChanneGenrename_Wavve(dSErPRhcuVptLilygUqOQmJfzsMFjX,dSErPRhcuVptLilygUqOQmJfzsMFjB):
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_WAVVE+'/live/channels/'+dSErPRhcuVptLilygUqOQmJfzsMFjB
   dSErPRhcuVptLilygUqOQmJfzsMFjN=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_DefaultParams_Wavve()
   dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFjN,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH)
   dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
   dSErPRhcuVptLilygUqOQmJfzsMFTn=dSErPRhcuVptLilygUqOQmJfzsMFje['genretext']
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return ''
  return dSErPRhcuVptLilygUqOQmJfzsMFTn
 def Get_ChannelList_Spotv(dSErPRhcuVptLilygUqOQmJfzsMFjX,payyn=dSErPRhcuVptLilygUqOQmJfzsMFXa):
  dSErPRhcuVptLilygUqOQmJfzsMFjx=[]
  try:
   for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFjv:
    dSErPRhcuVptLilygUqOQmJfzsMFjB=dSErPRhcuVptLilygUqOQmJfzsMFjK['videoId']
    dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'channelnm':dSErPRhcuVptLilygUqOQmJfzsMFjK['name'],'channelimg':dSErPRhcuVptLilygUqOQmJfzsMFjK['logo'],'ott':'spotv','genrenm':dSErPRhcuVptLilygUqOQmJfzsMFjX.make_getGenre(dSErPRhcuVptLilygUqOQmJfzsMFjB,'spotv')}
    if payyn==dSErPRhcuVptLilygUqOQmJfzsMFXa or dSErPRhcuVptLilygUqOQmJfzsMFjK['free']==dSErPRhcuVptLilygUqOQmJfzsMFXa:
     dSErPRhcuVptLilygUqOQmJfzsMFjx.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[]
  return dSErPRhcuVptLilygUqOQmJfzsMFjx
 def Get_ChannelList_Tving(dSErPRhcuVptLilygUqOQmJfzsMFjX):
  dSErPRhcuVptLilygUqOQmJfzsMFjx =[]
  dSErPRhcuVptLilygUqOQmJfzsMFTA=[]
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_TVING+'/v2/media/lives'
   dSErPRhcuVptLilygUqOQmJfzsMFjN={'pageNo':'1','pageSize':dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFjX.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   dSErPRhcuVptLilygUqOQmJfzsMFjN.update(dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_DefaultParams_Tving())
   dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFjN,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH)
   dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
   if not('result' in dSErPRhcuVptLilygUqOQmJfzsMFje['body']):return dSErPRhcuVptLilygUqOQmJfzsMFjx
   dSErPRhcuVptLilygUqOQmJfzsMFjk=dSErPRhcuVptLilygUqOQmJfzsMFje['body']['result']
   for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFjk:
    if dSErPRhcuVptLilygUqOQmJfzsMFjK['live_code']=='C44441':continue 
    dSErPRhcuVptLilygUqOQmJfzsMFTA.append(dSErPRhcuVptLilygUqOQmJfzsMFjK['live_code'])
   dSErPRhcuVptLilygUqOQmJfzsMFjC=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_ChannelImg_Tving(dSErPRhcuVptLilygUqOQmJfzsMFTA)
   for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFjk:
    dSErPRhcuVptLilygUqOQmJfzsMFjB=dSErPRhcuVptLilygUqOQmJfzsMFjK['live_code']
    if dSErPRhcuVptLilygUqOQmJfzsMFjB=='C44441':continue 
    dSErPRhcuVptLilygUqOQmJfzsMFjG=dSErPRhcuVptLilygUqOQmJfzsMFjK['schedule']['channel']['name']['ko']
    if dSErPRhcuVptLilygUqOQmJfzsMFjB in dSErPRhcuVptLilygUqOQmJfzsMFjC:
     dSErPRhcuVptLilygUqOQmJfzsMFjI=dSErPRhcuVptLilygUqOQmJfzsMFjC[dSErPRhcuVptLilygUqOQmJfzsMFjB]
    else:
     dSErPRhcuVptLilygUqOQmJfzsMFjI=''
    dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'channelnm':dSErPRhcuVptLilygUqOQmJfzsMFjG,'channelimg':dSErPRhcuVptLilygUqOQmJfzsMFjI,'ott':'tving','genrenm':dSErPRhcuVptLilygUqOQmJfzsMFjX.make_getGenre(dSErPRhcuVptLilygUqOQmJfzsMFjB,'tving')}
    dSErPRhcuVptLilygUqOQmJfzsMFjx.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[]
  return dSErPRhcuVptLilygUqOQmJfzsMFjx
 def Get_timestamp(dSErPRhcuVptLilygUqOQmJfzsMFjX,timetype=1):
  ts=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(dSErPRhcuVptLilygUqOQmJfzsMFjX,timetype):
  if timetype=='1':
   dSErPRhcuVptLilygUqOQmJfzsMFTa={'transactionId':dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   dSErPRhcuVptLilygUqOQmJfzsMFTa={'timestamp':dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_timestamp(timetype=1),'transactionId':dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_timestamp(timetype=1)+'000000000000001',}
  return dSErPRhcuVptLilygUqOQmJfzsMFTa
 def Get_ChannelList_Seezn(dSErPRhcuVptLilygUqOQmJfzsMFjX,exceptGroup=[]):
  dSErPRhcuVptLilygUqOQmJfzsMFjx =[]
  dSErPRhcuVptLilygUqOQmJfzsMFTD =dSErPRhcuVptLilygUqOQmJfzsMFXa if 'won' in exceptGroup else dSErPRhcuVptLilygUqOQmJfzsMFXj
  dSErPRhcuVptLilygUqOQmJfzsMFTN =dSErPRhcuVptLilygUqOQmJfzsMFXa if '홈쇼핑' in exceptGroup else dSErPRhcuVptLilygUqOQmJfzsMFXj
  dSErPRhcuVptLilygUqOQmJfzsMFTb=dSErPRhcuVptLilygUqOQmJfzsMFXa if '라디오/음악' in exceptGroup else dSErPRhcuVptLilygUqOQmJfzsMFXj
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_SEEZN+'/svc/menu/app6/api/epg_chlist' 
   dSErPRhcuVptLilygUqOQmJfzsMFjN={'category_id':'2','istest':'0',}
   dSErPRhcuVptLilygUqOQmJfzsMFTY=dSErPRhcuVptLilygUqOQmJfzsMFjX.Make_Header_Timestamp(timetype='2')
   dSErPRhcuVptLilygUqOQmJfzsMFTY.update(dSErPRhcuVptLilygUqOQmJfzsMFjX.SEEZN_HEADER)
   dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFjN,headers=dSErPRhcuVptLilygUqOQmJfzsMFTY,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH,redirects=dSErPRhcuVptLilygUqOQmJfzsMFXa)
   if dSErPRhcuVptLilygUqOQmJfzsMFjw.status_code!=200:return[]
   dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
   if dSErPRhcuVptLilygUqOQmJfzsMFje.get('meta').get('code')!='200':return[]
   dSErPRhcuVptLilygUqOQmJfzsMFTx=dSErPRhcuVptLilygUqOQmJfzsMFje.get('data').get('list')[0].get('list_channel')
   for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFTx:
    dSErPRhcuVptLilygUqOQmJfzsMFTC =dSErPRhcuVptLilygUqOQmJfzsMFjK.get('bit_rate_info').split(",")[0]
    dSErPRhcuVptLilygUqOQmJfzsMFjB =dSErPRhcuVptLilygUqOQmJfzsMFjK.get('ch_no')
    dSErPRhcuVptLilygUqOQmJfzsMFjo=dSErPRhcuVptLilygUqOQmJfzsMFjX.make_getGenre(dSErPRhcuVptLilygUqOQmJfzsMFjB,'seezn')
    dSErPRhcuVptLilygUqOQmJfzsMFTW =dSErPRhcuVptLilygUqOQmJfzsMFjK.get('type')
    dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'channelnm':dSErPRhcuVptLilygUqOQmJfzsMFjK.get('service_ch_name').replace(',','.'),'channelimg':dSErPRhcuVptLilygUqOQmJfzsMFjK.get('ch_image_list'),'ott':'seezn','genrenm':dSErPRhcuVptLilygUqOQmJfzsMFjo,}
    if dSErPRhcuVptLilygUqOQmJfzsMFjB=='404':continue 
    if dSErPRhcuVptLilygUqOQmJfzsMFjK['adult_yn']=='Y':continue 
    if dSErPRhcuVptLilygUqOQmJfzsMFjK['won_yn'] =='Y' and dSErPRhcuVptLilygUqOQmJfzsMFTD==dSErPRhcuVptLilygUqOQmJfzsMFXa:continue 
    if dSErPRhcuVptLilygUqOQmJfzsMFjo in exceptGroup:continue 
    if dSErPRhcuVptLilygUqOQmJfzsMFTW!='EPG':
     if dSErPRhcuVptLilygUqOQmJfzsMFTN and dSErPRhcuVptLilygUqOQmJfzsMFTW=='SHOP' :continue
     if dSErPRhcuVptLilygUqOQmJfzsMFTb and dSErPRhcuVptLilygUqOQmJfzsMFTW=='AUDIO_MUSIC':continue
    dSErPRhcuVptLilygUqOQmJfzsMFjx.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[]
  return dSErPRhcuVptLilygUqOQmJfzsMFjx
 def Get_EpgInfo_Seezn(dSErPRhcuVptLilygUqOQmJfzsMFjX,exceptGroup=[]):
  dSErPRhcuVptLilygUqOQmJfzsMFjx=[]
  dSErPRhcuVptLilygUqOQmJfzsMFTw =[]
  dSErPRhcuVptLilygUqOQmJfzsMFjx=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_ChannelList_Seezn(exceptGroup)
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_SEEZN+'/svc/menu/app6/api/epg_proglist' 
   for dSErPRhcuVptLilygUqOQmJfzsMFTe in dSErPRhcuVptLilygUqOQmJfzsMFjx:
    time.sleep(0.3)
    dSErPRhcuVptLilygUqOQmJfzsMFjB =dSErPRhcuVptLilygUqOQmJfzsMFTe.get('channelid')
    dSErPRhcuVptLilygUqOQmJfzsMFjN={'ch_no':dSErPRhcuVptLilygUqOQmJfzsMFjB}
    dSErPRhcuVptLilygUqOQmJfzsMFTY=dSErPRhcuVptLilygUqOQmJfzsMFjX.Make_Header_Timestamp(timetype='2')
    dSErPRhcuVptLilygUqOQmJfzsMFTY.update(dSErPRhcuVptLilygUqOQmJfzsMFjX.SEEZN_HEADER)
    dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFjN,headers=dSErPRhcuVptLilygUqOQmJfzsMFTY,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH,redirects=dSErPRhcuVptLilygUqOQmJfzsMFXa)
    if dSErPRhcuVptLilygUqOQmJfzsMFjw.status_code!=200:return[],[]
    dSErPRhcuVptLilygUqOQmJfzsMFTk=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
    if dSErPRhcuVptLilygUqOQmJfzsMFTk.get('meta').get('code')!='200':return[],[]
    for dSErPRhcuVptLilygUqOQmJfzsMFTK in dSErPRhcuVptLilygUqOQmJfzsMFTk.get('data').get('list'):
     dSErPRhcuVptLilygUqOQmJfzsMFTB=dSErPRhcuVptLilygUqOQmJfzsMFTK.get('start_ymd')
     dSErPRhcuVptLilygUqOQmJfzsMFTv=dSErPRhcuVptLilygUqOQmJfzsMFTK.get('start_time').replace(':','')
     dSErPRhcuVptLilygUqOQmJfzsMFTX =dSErPRhcuVptLilygUqOQmJfzsMFTK.get('end_time').replace(':','')
     if dSErPRhcuVptLilygUqOQmJfzsMFXD(dSErPRhcuVptLilygUqOQmJfzsMFTv)>dSErPRhcuVptLilygUqOQmJfzsMFXD(dSErPRhcuVptLilygUqOQmJfzsMFTX):
      dSErPRhcuVptLilygUqOQmJfzsMFTG=datetime.datetime.strptime(dSErPRhcuVptLilygUqOQmJfzsMFTB,'%Y%m%d')+datetime.timedelta(days=dSErPRhcuVptLilygUqOQmJfzsMFXD(1))
      dSErPRhcuVptLilygUqOQmJfzsMFTG=dSErPRhcuVptLilygUqOQmJfzsMFTG.strftime('%Y%m%d')
     else:
      dSErPRhcuVptLilygUqOQmJfzsMFTG=dSErPRhcuVptLilygUqOQmJfzsMFTB
     dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'title':dSErPRhcuVptLilygUqOQmJfzsMFjX.xmlText(urllib.parse.unquote_plus(dSErPRhcuVptLilygUqOQmJfzsMFTK.get('program_name'))),'startTime':dSErPRhcuVptLilygUqOQmJfzsMFTB+dSErPRhcuVptLilygUqOQmJfzsMFTv+'00','endTime':dSErPRhcuVptLilygUqOQmJfzsMFTG+dSErPRhcuVptLilygUqOQmJfzsMFTX+'00','ott':'seezn'}
     dSErPRhcuVptLilygUqOQmJfzsMFTw.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[],[]
  return dSErPRhcuVptLilygUqOQmJfzsMFjx,dSErPRhcuVptLilygUqOQmJfzsMFTw
 def make_EpgDatetime_Tving(dSErPRhcuVptLilygUqOQmJfzsMFjX,days=2):
  dSErPRhcuVptLilygUqOQmJfzsMFTI=[]
  dSErPRhcuVptLilygUqOQmJfzsMFTo=dSErPRhcuVptLilygUqOQmJfzsMFjX.make_DateList(days=2,dateType='2')
  dSErPRhcuVptLilygUqOQmJfzsMFHj=dSErPRhcuVptLilygUqOQmJfzsMFXD(dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFTo:
   for dSErPRhcuVptLilygUqOQmJfzsMFHT in dSErPRhcuVptLilygUqOQmJfzsMFXN(8):
    dSErPRhcuVptLilygUqOQmJfzsMFTj={'ndate':dSErPRhcuVptLilygUqOQmJfzsMFjK,'starttm':dSErPRhcuVptLilygUqOQmJfzsMFjH[dSErPRhcuVptLilygUqOQmJfzsMFHT]['starttm'],'endtm':dSErPRhcuVptLilygUqOQmJfzsMFjH[dSErPRhcuVptLilygUqOQmJfzsMFHT]['endtm']}
    dSErPRhcuVptLilygUqOQmJfzsMFHv=dSErPRhcuVptLilygUqOQmJfzsMFXD(dSErPRhcuVptLilygUqOQmJfzsMFjK+dSErPRhcuVptLilygUqOQmJfzsMFjH[dSErPRhcuVptLilygUqOQmJfzsMFHT]['starttm'])
    dSErPRhcuVptLilygUqOQmJfzsMFHX=dSErPRhcuVptLilygUqOQmJfzsMFXD(dSErPRhcuVptLilygUqOQmJfzsMFjK+dSErPRhcuVptLilygUqOQmJfzsMFjH[dSErPRhcuVptLilygUqOQmJfzsMFHT]['endtm'])
    if dSErPRhcuVptLilygUqOQmJfzsMFHj<=dSErPRhcuVptLilygUqOQmJfzsMFHv or(dSErPRhcuVptLilygUqOQmJfzsMFHv<dSErPRhcuVptLilygUqOQmJfzsMFHj and dSErPRhcuVptLilygUqOQmJfzsMFHj<dSErPRhcuVptLilygUqOQmJfzsMFHX):
     dSErPRhcuVptLilygUqOQmJfzsMFTI.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  return dSErPRhcuVptLilygUqOQmJfzsMFTI
 def make_DateList(dSErPRhcuVptLilygUqOQmJfzsMFjX,days=2,dateType='1'):
  dSErPRhcuVptLilygUqOQmJfzsMFTo=[]
  dSErPRhcuVptLilygUqOQmJfzsMFHn =dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_Now_Datetime()
  if dateType=='1':
   dSErPRhcuVptLilygUqOQmJfzsMFHn=dSErPRhcuVptLilygUqOQmJfzsMFHn-datetime.timedelta(days=1)
  for i in dSErPRhcuVptLilygUqOQmJfzsMFXN(days):
   dSErPRhcuVptLilygUqOQmJfzsMFHA=dSErPRhcuVptLilygUqOQmJfzsMFHn+datetime.timedelta(days=i)
   if dateType=='1':
    dSErPRhcuVptLilygUqOQmJfzsMFTo.append(dSErPRhcuVptLilygUqOQmJfzsMFHA.strftime('%Y%m%d'))
   else:
    dSErPRhcuVptLilygUqOQmJfzsMFTo.append(dSErPRhcuVptLilygUqOQmJfzsMFHA.strftime('%Y%m%d'))
  return dSErPRhcuVptLilygUqOQmJfzsMFTo
 def make_Tving_ChannleGroup(dSErPRhcuVptLilygUqOQmJfzsMFjX,dSErPRhcuVptLilygUqOQmJfzsMFTA):
  dSErPRhcuVptLilygUqOQmJfzsMFHa=[]
  i=0
  dSErPRhcuVptLilygUqOQmJfzsMFHD=''
  for dSErPRhcuVptLilygUqOQmJfzsMFHN in dSErPRhcuVptLilygUqOQmJfzsMFTA:
   if i==0:dSErPRhcuVptLilygUqOQmJfzsMFHD=dSErPRhcuVptLilygUqOQmJfzsMFHN
   else:dSErPRhcuVptLilygUqOQmJfzsMFHD+=',%s'%(dSErPRhcuVptLilygUqOQmJfzsMFHN)
   i+=1
   if i>=dSErPRhcuVptLilygUqOQmJfzsMFjX.LIMIT_TVINGEPG:
    dSErPRhcuVptLilygUqOQmJfzsMFHa.append(dSErPRhcuVptLilygUqOQmJfzsMFHD)
    i=0
    dSErPRhcuVptLilygUqOQmJfzsMFHD=''
  if dSErPRhcuVptLilygUqOQmJfzsMFHD!='':
   dSErPRhcuVptLilygUqOQmJfzsMFHa.append(dSErPRhcuVptLilygUqOQmJfzsMFHD)
  return dSErPRhcuVptLilygUqOQmJfzsMFHa
 def Get_ChannelImg_Tving(dSErPRhcuVptLilygUqOQmJfzsMFjX,chid_list):
  dSErPRhcuVptLilygUqOQmJfzsMFTH={}
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFHb=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_Now_Datetime().strftime('%Y%m%d')
   dSErPRhcuVptLilygUqOQmJfzsMFTv =dSErPRhcuVptLilygUqOQmJfzsMFjH[6]['starttm'] 
   dSErPRhcuVptLilygUqOQmJfzsMFTX =dSErPRhcuVptLilygUqOQmJfzsMFjH[6]['endtm']
   dSErPRhcuVptLilygUqOQmJfzsMFHa=dSErPRhcuVptLilygUqOQmJfzsMFjX.make_Tving_ChannleGroup(chid_list)
   for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFHa:
    dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_TVING+'/v2/media/schedules'
    dSErPRhcuVptLilygUqOQmJfzsMFjN={'pageNo':'1','pageSize':dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFjX.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':dSErPRhcuVptLilygUqOQmJfzsMFHb,'broadcastDate':dSErPRhcuVptLilygUqOQmJfzsMFHb,'startBroadTime':dSErPRhcuVptLilygUqOQmJfzsMFTv,'endBroadTime':dSErPRhcuVptLilygUqOQmJfzsMFTX,'channelCode':dSErPRhcuVptLilygUqOQmJfzsMFjK}
    dSErPRhcuVptLilygUqOQmJfzsMFjN.update(dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_DefaultParams_Tving())
    dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFjN,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH)
    dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
    if not('result' in dSErPRhcuVptLilygUqOQmJfzsMFje['body']):return{}
    dSErPRhcuVptLilygUqOQmJfzsMFjk=dSErPRhcuVptLilygUqOQmJfzsMFje['body']['result']
    for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFjk:
     for dSErPRhcuVptLilygUqOQmJfzsMFHY in dSErPRhcuVptLilygUqOQmJfzsMFjK['image']:
      if dSErPRhcuVptLilygUqOQmJfzsMFHY['code']=='CAIC0400':dSErPRhcuVptLilygUqOQmJfzsMFTH[dSErPRhcuVptLilygUqOQmJfzsMFjK['channel_code']]=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_TVINGIMG+dSErPRhcuVptLilygUqOQmJfzsMFHY['url']
      elif dSErPRhcuVptLilygUqOQmJfzsMFHY['code']=='CAIC1400':dSErPRhcuVptLilygUqOQmJfzsMFTH[dSErPRhcuVptLilygUqOQmJfzsMFjK['channel_code']]=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_TVINGIMG+dSErPRhcuVptLilygUqOQmJfzsMFHY['url']
      elif dSErPRhcuVptLilygUqOQmJfzsMFHY['code']=='CAIC1900':dSErPRhcuVptLilygUqOQmJfzsMFTH[dSErPRhcuVptLilygUqOQmJfzsMFjK['channel_code']]=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_TVINGIMG+dSErPRhcuVptLilygUqOQmJfzsMFHY['url']
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return{}
  return dSErPRhcuVptLilygUqOQmJfzsMFTH
 def Get_EpgInfo_Spotv(dSErPRhcuVptLilygUqOQmJfzsMFjX,days=3,payyn=dSErPRhcuVptLilygUqOQmJfzsMFXa):
  dSErPRhcuVptLilygUqOQmJfzsMFjx=[]
  dSErPRhcuVptLilygUqOQmJfzsMFTw =[]
  try:
   for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFjv:
    dSErPRhcuVptLilygUqOQmJfzsMFjB =dSErPRhcuVptLilygUqOQmJfzsMFjK['videoId']
    dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'channelnm':dSErPRhcuVptLilygUqOQmJfzsMFjX.xmlText(dSErPRhcuVptLilygUqOQmJfzsMFjK['name']),'channelimg':dSErPRhcuVptLilygUqOQmJfzsMFjK['logo'],'ott':'spotv','epgtype':dSErPRhcuVptLilygUqOQmJfzsMFjK['epgtype'],'epgnm':dSErPRhcuVptLilygUqOQmJfzsMFjK['epgnm']}
    if payyn==dSErPRhcuVptLilygUqOQmJfzsMFXa or dSErPRhcuVptLilygUqOQmJfzsMFjK['free']==dSErPRhcuVptLilygUqOQmJfzsMFXa:
     dSErPRhcuVptLilygUqOQmJfzsMFjx.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[],[]
  '''
  try:
   for now_day in days_list:
    url = self.API_SPOTV + '/api/v2/program/' + now_day
    response = self.callRequestCookies('Get', url, payload=None, params=None, headers=None, cookies=None )
    res_json = json.loads(response.text )
    for i_section in res_json:
     if find_list.get(i_section['channelId'] ) == None: continue
     temp_list = {'channelid' : find_list.get(i_section['channelId'] ) , 'title' : self.xmlText(i_section['title'] ) , 'startTime' : i_section['startTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'endTime' : i_section['endTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'ott' : 'spotv' }
     epg_list.append(temp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  try:
   for dSErPRhcuVptLilygUqOQmJfzsMFTe in dSErPRhcuVptLilygUqOQmJfzsMFjx:
    if dSErPRhcuVptLilygUqOQmJfzsMFTe['epgtype']=='spotvon':
     dSErPRhcuVptLilygUqOQmJfzsMFHx=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_EpgInfo_Spotv_spotvon(dSErPRhcuVptLilygUqOQmJfzsMFTe['channelid'],dSErPRhcuVptLilygUqOQmJfzsMFTe['epgnm'],days)
     if dSErPRhcuVptLilygUqOQmJfzsMFXb(dSErPRhcuVptLilygUqOQmJfzsMFHx)>0:dSErPRhcuVptLilygUqOQmJfzsMFTw.extend(dSErPRhcuVptLilygUqOQmJfzsMFHx)
    if dSErPRhcuVptLilygUqOQmJfzsMFTe['epgtype']=='spotvnet':
     dSErPRhcuVptLilygUqOQmJfzsMFHx=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_EpgInfo_Spotv_spotvnet(dSErPRhcuVptLilygUqOQmJfzsMFTe['channelid'],dSErPRhcuVptLilygUqOQmJfzsMFTe['epgnm'],days)
     if dSErPRhcuVptLilygUqOQmJfzsMFXb(dSErPRhcuVptLilygUqOQmJfzsMFHx)>0:dSErPRhcuVptLilygUqOQmJfzsMFTw.extend(dSErPRhcuVptLilygUqOQmJfzsMFHx)
    time.sleep(dSErPRhcuVptLilygUqOQmJfzsMFjX.SLEEP_TIME)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[],[]
  return dSErPRhcuVptLilygUqOQmJfzsMFjx,dSErPRhcuVptLilygUqOQmJfzsMFTw
 def Get_EpgInfo_Spotv_spotvon(dSErPRhcuVptLilygUqOQmJfzsMFjX,dSErPRhcuVptLilygUqOQmJfzsMFjB,epgnm,days):
  dSErPRhcuVptLilygUqOQmJfzsMFTw =[]
  dSErPRhcuVptLilygUqOQmJfzsMFTo=dSErPRhcuVptLilygUqOQmJfzsMFjX.make_DateList(days=days,dateType='1')
  dSErPRhcuVptLilygUqOQmJfzsMFHC=''
  try:
   for dSErPRhcuVptLilygUqOQmJfzsMFHW in dSErPRhcuVptLilygUqOQmJfzsMFTo:
    dSErPRhcuVptLilygUqOQmJfzsMFjW='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,dSErPRhcuVptLilygUqOQmJfzsMFHW)
    dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFXH,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH)
    dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
    for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFje:
     dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'title':dSErPRhcuVptLilygUqOQmJfzsMFjX.xmlText(dSErPRhcuVptLilygUqOQmJfzsMFjK['title']),'startTime':dSErPRhcuVptLilygUqOQmJfzsMFjK['sch_date'].replace('-','')+dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFjK['sch_hour']).zfill(2)+dSErPRhcuVptLilygUqOQmJfzsMFjK['sch_min']+'00','ott':'spotv'}
     dSErPRhcuVptLilygUqOQmJfzsMFTw.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
    dSErPRhcuVptLilygUqOQmJfzsMFHC=dSErPRhcuVptLilygUqOQmJfzsMFHW
   for i in dSErPRhcuVptLilygUqOQmJfzsMFXN(dSErPRhcuVptLilygUqOQmJfzsMFXb(dSErPRhcuVptLilygUqOQmJfzsMFTw)):
    if i>0:dSErPRhcuVptLilygUqOQmJfzsMFTw[i-1]['endTime']=dSErPRhcuVptLilygUqOQmJfzsMFTw[i]['startTime']
    if i==dSErPRhcuVptLilygUqOQmJfzsMFXb(dSErPRhcuVptLilygUqOQmJfzsMFTw)-1: dSErPRhcuVptLilygUqOQmJfzsMFTw[i]['endTime']=dSErPRhcuVptLilygUqOQmJfzsMFHC+'240000'
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[]
  return dSErPRhcuVptLilygUqOQmJfzsMFTw
 def Get_EpgInfo_Spotv_spotvnet(dSErPRhcuVptLilygUqOQmJfzsMFjX,dSErPRhcuVptLilygUqOQmJfzsMFjB,epgnm,days):
  dSErPRhcuVptLilygUqOQmJfzsMFTw =[]
  dSErPRhcuVptLilygUqOQmJfzsMFTo=dSErPRhcuVptLilygUqOQmJfzsMFjX.make_DateList(days=days,dateType='1')
  dSErPRhcuVptLilygUqOQmJfzsMFHC=''
  try:
   for dSErPRhcuVptLilygUqOQmJfzsMFHW in dSErPRhcuVptLilygUqOQmJfzsMFTo:
    dSErPRhcuVptLilygUqOQmJfzsMFjW='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,dSErPRhcuVptLilygUqOQmJfzsMFHW)
    dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFXH,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH)
    dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
    for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFje:
     dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'title':dSErPRhcuVptLilygUqOQmJfzsMFjX.xmlText(dSErPRhcuVptLilygUqOQmJfzsMFjK['title']),'startTime':dSErPRhcuVptLilygUqOQmJfzsMFjK['sch_date'].replace('-','')+dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFjK['sch_hour']).zfill(2)+dSErPRhcuVptLilygUqOQmJfzsMFjK['sch_min']+'00','ott':'spotv'}
     dSErPRhcuVptLilygUqOQmJfzsMFTw.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
    dSErPRhcuVptLilygUqOQmJfzsMFHC=dSErPRhcuVptLilygUqOQmJfzsMFHW
   for i in dSErPRhcuVptLilygUqOQmJfzsMFXN(dSErPRhcuVptLilygUqOQmJfzsMFXb(dSErPRhcuVptLilygUqOQmJfzsMFTw)):
    if i>0:dSErPRhcuVptLilygUqOQmJfzsMFTw[i-1]['endTime']=dSErPRhcuVptLilygUqOQmJfzsMFTw[i]['startTime']
    if i==dSErPRhcuVptLilygUqOQmJfzsMFXb(dSErPRhcuVptLilygUqOQmJfzsMFTw)-1: dSErPRhcuVptLilygUqOQmJfzsMFTw[i]['endTime']=dSErPRhcuVptLilygUqOQmJfzsMFHC+'240000'
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[]
  return dSErPRhcuVptLilygUqOQmJfzsMFTw
 def Get_EpgInfo_Wavve(dSErPRhcuVptLilygUqOQmJfzsMFjX,days=2,exceptGroup=[]):
  dSErPRhcuVptLilygUqOQmJfzsMFjx =[]
  dSErPRhcuVptLilygUqOQmJfzsMFTw =[]
  dSErPRhcuVptLilygUqOQmJfzsMFHn =dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_Now_Datetime()
  dSErPRhcuVptLilygUqOQmJfzsMFHw =dSErPRhcuVptLilygUqOQmJfzsMFHn+datetime.timedelta(hours=-2)
  dSErPRhcuVptLilygUqOQmJfzsMFHe =dSErPRhcuVptLilygUqOQmJfzsMFHn+datetime.timedelta(days=(days-1))
  if dSErPRhcuVptLilygUqOQmJfzsMFXD(dSErPRhcuVptLilygUqOQmJfzsMFHw.strftime('%H'))<=3:
   dSErPRhcuVptLilygUqOQmJfzsMFHk=dSErPRhcuVptLilygUqOQmJfzsMFHw.strftime('%Y-%m-%d 00:00')
  else:
   dSErPRhcuVptLilygUqOQmJfzsMFHk=dSErPRhcuVptLilygUqOQmJfzsMFHw.strftime('%Y-%m-%d %H:00')
  dSErPRhcuVptLilygUqOQmJfzsMFHK =dSErPRhcuVptLilygUqOQmJfzsMFHe.strftime('%Y-%m-%d 24:00')
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_WAVVE+'/live/epgs'
   dSErPRhcuVptLilygUqOQmJfzsMFjN={'limit':dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFjX.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':dSErPRhcuVptLilygUqOQmJfzsMFHk,'enddatetime':dSErPRhcuVptLilygUqOQmJfzsMFHK}
   dSErPRhcuVptLilygUqOQmJfzsMFjN.update(dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_DefaultParams_Wavve())
   dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFjN,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH)
   dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
   dSErPRhcuVptLilygUqOQmJfzsMFTk=dSErPRhcuVptLilygUqOQmJfzsMFje['list']
   for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFTk:
    dSErPRhcuVptLilygUqOQmJfzsMFjB =dSErPRhcuVptLilygUqOQmJfzsMFjK['channelid']
    dSErPRhcuVptLilygUqOQmJfzsMFjo=dSErPRhcuVptLilygUqOQmJfzsMFjX.make_getGenre(dSErPRhcuVptLilygUqOQmJfzsMFjB,'wavve')
    dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'channelnm':dSErPRhcuVptLilygUqOQmJfzsMFjX.xmlText(dSErPRhcuVptLilygUqOQmJfzsMFjK['channelname']),'channelimg':dSErPRhcuVptLilygUqOQmJfzsMFjX.HTTPTAG+dSErPRhcuVptLilygUqOQmJfzsMFjK['channelimage'],'ott':'wavve'}
    if dSErPRhcuVptLilygUqOQmJfzsMFjo not in exceptGroup:
     dSErPRhcuVptLilygUqOQmJfzsMFjx.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
    for dSErPRhcuVptLilygUqOQmJfzsMFTK in dSErPRhcuVptLilygUqOQmJfzsMFjK['list']:
     dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjK['channelid'],'title':dSErPRhcuVptLilygUqOQmJfzsMFjX.xmlText(dSErPRhcuVptLilygUqOQmJfzsMFTK['title']),'startTime':dSErPRhcuVptLilygUqOQmJfzsMFTK['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':dSErPRhcuVptLilygUqOQmJfzsMFTK['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if dSErPRhcuVptLilygUqOQmJfzsMFjo not in exceptGroup and dSErPRhcuVptLilygUqOQmJfzsMFTK['starttime']!=dSErPRhcuVptLilygUqOQmJfzsMFTK['endtime']:
      dSErPRhcuVptLilygUqOQmJfzsMFTw.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[],[]
  dSErPRhcuVptLilygUqOQmJfzsMFHB=dSErPRhcuVptLilygUqOQmJfzsMFXb(dSErPRhcuVptLilygUqOQmJfzsMFTw)
  for i in(dSErPRhcuVptLilygUqOQmJfzsMFXN(1,dSErPRhcuVptLilygUqOQmJfzsMFHB)):
   if dSErPRhcuVptLilygUqOQmJfzsMFXD(dSErPRhcuVptLilygUqOQmJfzsMFTw[i-1]['endTime'])+1==dSErPRhcuVptLilygUqOQmJfzsMFXD(dSErPRhcuVptLilygUqOQmJfzsMFTw[i]['startTime'])and dSErPRhcuVptLilygUqOQmJfzsMFTw[i-1]['channelid']==dSErPRhcuVptLilygUqOQmJfzsMFTw[i]['channelid']:
    dSErPRhcuVptLilygUqOQmJfzsMFTw[i-1]['endTime']=dSErPRhcuVptLilygUqOQmJfzsMFTw[i]['startTime']
  return dSErPRhcuVptLilygUqOQmJfzsMFjx,dSErPRhcuVptLilygUqOQmJfzsMFTw
 def Get_EpgInfo_Tving(dSErPRhcuVptLilygUqOQmJfzsMFjX,days=2):
  dSErPRhcuVptLilygUqOQmJfzsMFjx=[]
  dSErPRhcuVptLilygUqOQmJfzsMFTw =[]
  dSErPRhcuVptLilygUqOQmJfzsMFHG =[]
  dSErPRhcuVptLilygUqOQmJfzsMFHI =dSErPRhcuVptLilygUqOQmJfzsMFjX.make_EpgDatetime_Tving(days=days)
  dSErPRhcuVptLilygUqOQmJfzsMFjx =dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_ChannelList_Tving()
  dSErPRhcuVptLilygUqOQmJfzsMFHo=[]
  for i in dSErPRhcuVptLilygUqOQmJfzsMFXN(dSErPRhcuVptLilygUqOQmJfzsMFXb(dSErPRhcuVptLilygUqOQmJfzsMFjx)):
   dSErPRhcuVptLilygUqOQmJfzsMFjx[i]['channelnm']=dSErPRhcuVptLilygUqOQmJfzsMFjX.xmlText(dSErPRhcuVptLilygUqOQmJfzsMFjx[i]['channelnm'])
   dSErPRhcuVptLilygUqOQmJfzsMFHo.append(dSErPRhcuVptLilygUqOQmJfzsMFjx[i]['channelid'])
  dSErPRhcuVptLilygUqOQmJfzsMFvj=dSErPRhcuVptLilygUqOQmJfzsMFjX.make_Tving_ChannleGroup(dSErPRhcuVptLilygUqOQmJfzsMFHo)
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_TVING+'/v2/media/schedules'
   for dSErPRhcuVptLilygUqOQmJfzsMFvT in dSErPRhcuVptLilygUqOQmJfzsMFHI:
    for dSErPRhcuVptLilygUqOQmJfzsMFTe in dSErPRhcuVptLilygUqOQmJfzsMFvj:
     dSErPRhcuVptLilygUqOQmJfzsMFjN={'pageNo':'1','pageSize':dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFjX.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':dSErPRhcuVptLilygUqOQmJfzsMFvT['ndate'],'broadcastDate':dSErPRhcuVptLilygUqOQmJfzsMFvT['ndate'],'startBroadTime':dSErPRhcuVptLilygUqOQmJfzsMFvT['starttm'],'endBroadTime':dSErPRhcuVptLilygUqOQmJfzsMFvT['endtm'],'channelCode':dSErPRhcuVptLilygUqOQmJfzsMFTe}
     dSErPRhcuVptLilygUqOQmJfzsMFjN.update(dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_DefaultParams_Tving())
     dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFjN,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH)
     dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
     dSErPRhcuVptLilygUqOQmJfzsMFjk=dSErPRhcuVptLilygUqOQmJfzsMFje['body']['result']
     for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFjk:
      if 'schedules' not in dSErPRhcuVptLilygUqOQmJfzsMFjK:continue
      if dSErPRhcuVptLilygUqOQmJfzsMFjK['schedules']==dSErPRhcuVptLilygUqOQmJfzsMFXH:continue
      for dSErPRhcuVptLilygUqOQmJfzsMFvH in dSErPRhcuVptLilygUqOQmJfzsMFjK['schedules']:
       dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFvH['schedule_code'],'title':dSErPRhcuVptLilygUqOQmJfzsMFjX.xmlText(dSErPRhcuVptLilygUqOQmJfzsMFvH['program']['name']['ko']),'startTime':dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFvH['broadcast_start_time']),'endTime':dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFvH['broadcast_end_time']),'ott':'tving'}
       dSErPRhcuVptLilygUqOQmJfzsMFvX=dSErPRhcuVptLilygUqOQmJfzsMFvH['schedule_code']+dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFvH['broadcast_start_time'])
       if dSErPRhcuVptLilygUqOQmJfzsMFvX in dSErPRhcuVptLilygUqOQmJfzsMFHG:continue
       dSErPRhcuVptLilygUqOQmJfzsMFHG.append(dSErPRhcuVptLilygUqOQmJfzsMFvX)
       dSErPRhcuVptLilygUqOQmJfzsMFTw.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
     time.sleep(dSErPRhcuVptLilygUqOQmJfzsMFjX.SLEEP_TIME)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[],[]
  return dSErPRhcuVptLilygUqOQmJfzsMFjx,dSErPRhcuVptLilygUqOQmJfzsMFTw
 def Get_BaseInfo_Samsungtv(dSErPRhcuVptLilygUqOQmJfzsMFjX):
  dSErPRhcuVptLilygUqOQmJfzsMFvn={}
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_SAMSUNGTV
   dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFXH,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFXH)
   for dSErPRhcuVptLilygUqOQmJfzsMFvA in dSErPRhcuVptLilygUqOQmJfzsMFjw.cookies:
    if dSErPRhcuVptLilygUqOQmJfzsMFvA.name=='session':
     dSErPRhcuVptLilygUqOQmJfzsMFvn['session']=dSErPRhcuVptLilygUqOQmJfzsMFvA.value
    elif dSErPRhcuVptLilygUqOQmJfzsMFvA.name=='session.sig':
     dSErPRhcuVptLilygUqOQmJfzsMFvn['session.sig']=dSErPRhcuVptLilygUqOQmJfzsMFvA.value
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return{}
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_SAMSUNGTV+'/user'
   dSErPRhcuVptLilygUqOQmJfzsMFva={'session':dSErPRhcuVptLilygUqOQmJfzsMFvn['session'],'session.sig':dSErPRhcuVptLilygUqOQmJfzsMFvn['session.sig'],}
   dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=dSErPRhcuVptLilygUqOQmJfzsMFXH,headers=dSErPRhcuVptLilygUqOQmJfzsMFXH,cookies=dSErPRhcuVptLilygUqOQmJfzsMFva)
   dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
   dSErPRhcuVptLilygUqOQmJfzsMFvn['countryCode']=dSErPRhcuVptLilygUqOQmJfzsMFje.get('countryCode')
   dSErPRhcuVptLilygUqOQmJfzsMFvn['uuid'] =dSErPRhcuVptLilygUqOQmJfzsMFje.get('uuid')
   dSErPRhcuVptLilygUqOQmJfzsMFvn['ip'] =dSErPRhcuVptLilygUqOQmJfzsMFje.get('ip')
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return{}
  return dSErPRhcuVptLilygUqOQmJfzsMFvn
 def Get_BaseRequest_Samsungtv(dSErPRhcuVptLilygUqOQmJfzsMFjX,dSErPRhcuVptLilygUqOQmJfzsMFvn):
  def t_Cache():
   dSErPRhcuVptLilygUqOQmJfzsMFHj =dSErPRhcuVptLilygUqOQmJfzsMFXD(time.time())
   dSErPRhcuVptLilygUqOQmJfzsMFvD=dSErPRhcuVptLilygUqOQmJfzsMFXD(dSErPRhcuVptLilygUqOQmJfzsMFHj-dSErPRhcuVptLilygUqOQmJfzsMFHj%3600)
   return dSErPRhcuVptLilygUqOQmJfzsMFvD,dSErPRhcuVptLilygUqOQmJfzsMFHj
  def zlib_compress(plaintext):
   dSErPRhcuVptLilygUqOQmJfzsMFvN=zlib.compress(plaintext.encode('utf-8'))
   return base64.standard_b64encode(dSErPRhcuVptLilygUqOQmJfzsMFvN).decode('utf-8')
  dSErPRhcuVptLilygUqOQmJfzsMFje={}
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFjW=dSErPRhcuVptLilygUqOQmJfzsMFjX.API_SAMSUNGTV+'/api/lives'
   dSErPRhcuVptLilygUqOQmJfzsMFvD,dSErPRhcuVptLilygUqOQmJfzsMFHj=t_Cache()
   dSErPRhcuVptLilygUqOQmJfzsMFvb=zlib_compress(dSErPRhcuVptLilygUqOQmJfzsMFvn['uuid']+':'+dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFHj))
   dSErPRhcuVptLilygUqOQmJfzsMFva={'session':dSErPRhcuVptLilygUqOQmJfzsMFvn['session'],'session.sig':dSErPRhcuVptLilygUqOQmJfzsMFvn['session.sig'],}
   dSErPRhcuVptLilygUqOQmJfzsMFjN ={'t':dSErPRhcuVptLilygUqOQmJfzsMFXv(dSErPRhcuVptLilygUqOQmJfzsMFvD)}
   dSErPRhcuVptLilygUqOQmJfzsMFTY ={'x-cred-payload':dSErPRhcuVptLilygUqOQmJfzsMFvb}
   dSErPRhcuVptLilygUqOQmJfzsMFjw=dSErPRhcuVptLilygUqOQmJfzsMFjX.callRequestCookies('Get',dSErPRhcuVptLilygUqOQmJfzsMFjW,payload=dSErPRhcuVptLilygUqOQmJfzsMFXH,params=params,headers=headers,cookies=cookies)
   dSErPRhcuVptLilygUqOQmJfzsMFje=json.loads(dSErPRhcuVptLilygUqOQmJfzsMFjw.text)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
  return dSErPRhcuVptLilygUqOQmJfzsMFje
 def Get_ChannelList_Samsungtv(dSErPRhcuVptLilygUqOQmJfzsMFjX,dSErPRhcuVptLilygUqOQmJfzsMFvn,exceptGroup=[]):
  dSErPRhcuVptLilygUqOQmJfzsMFjx =[]
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFje=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_BaseRequest_Samsungtv(dSErPRhcuVptLilygUqOQmJfzsMFvn)
   dSErPRhcuVptLilygUqOQmJfzsMFjk=dSErPRhcuVptLilygUqOQmJfzsMFje['live']['channel']
   for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFjk:
    dSErPRhcuVptLilygUqOQmJfzsMFjB =dSErPRhcuVptLilygUqOQmJfzsMFjK.get('id')
    dSErPRhcuVptLilygUqOQmJfzsMFjG =dSErPRhcuVptLilygUqOQmJfzsMFjK.get('name')
    dSErPRhcuVptLilygUqOQmJfzsMFjI=dSErPRhcuVptLilygUqOQmJfzsMFjK.get('logo')
    dSErPRhcuVptLilygUqOQmJfzsMFjo=dSErPRhcuVptLilygUqOQmJfzsMFjX.make_getGenre(dSErPRhcuVptLilygUqOQmJfzsMFjB,'samsung')
    dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'channelnm':dSErPRhcuVptLilygUqOQmJfzsMFjG,'channelimg':dSErPRhcuVptLilygUqOQmJfzsMFjI,'ott':'samsung','genrenm':dSErPRhcuVptLilygUqOQmJfzsMFjo}
    if dSErPRhcuVptLilygUqOQmJfzsMFjo not in exceptGroup:
     dSErPRhcuVptLilygUqOQmJfzsMFjx.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[]
  return dSErPRhcuVptLilygUqOQmJfzsMFjx
 def Get_EpgInfo_Samsungtv(dSErPRhcuVptLilygUqOQmJfzsMFjX,dSErPRhcuVptLilygUqOQmJfzsMFvn,exceptGroup=[]):
  dSErPRhcuVptLilygUqOQmJfzsMFjx=[]
  dSErPRhcuVptLilygUqOQmJfzsMFTw =[]
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFje =dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_BaseRequest_Samsungtv(dSErPRhcuVptLilygUqOQmJfzsMFvn)
   dSErPRhcuVptLilygUqOQmJfzsMFjK=dSErPRhcuVptLilygUqOQmJfzsMFje['live']['channel']
   for dSErPRhcuVptLilygUqOQmJfzsMFTe in dSErPRhcuVptLilygUqOQmJfzsMFjK:
    dSErPRhcuVptLilygUqOQmJfzsMFjB =dSErPRhcuVptLilygUqOQmJfzsMFTe.get('id')
    dSErPRhcuVptLilygUqOQmJfzsMFjG =dSErPRhcuVptLilygUqOQmJfzsMFTe.get('name')
    dSErPRhcuVptLilygUqOQmJfzsMFjI=dSErPRhcuVptLilygUqOQmJfzsMFTe.get('logo')
    dSErPRhcuVptLilygUqOQmJfzsMFTk =dSErPRhcuVptLilygUqOQmJfzsMFTe.get('program')
    dSErPRhcuVptLilygUqOQmJfzsMFjo=dSErPRhcuVptLilygUqOQmJfzsMFjX.make_getGenre(dSErPRhcuVptLilygUqOQmJfzsMFjB,'samsung')
    if dSErPRhcuVptLilygUqOQmJfzsMFjo in exceptGroup:
     continue
    dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'channelnm':dSErPRhcuVptLilygUqOQmJfzsMFjG,'channelimg':dSErPRhcuVptLilygUqOQmJfzsMFjI,'ott':'samsung','genrenm':dSErPRhcuVptLilygUqOQmJfzsMFjo}
    dSErPRhcuVptLilygUqOQmJfzsMFjx.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
    for dSErPRhcuVptLilygUqOQmJfzsMFTK in dSErPRhcuVptLilygUqOQmJfzsMFTk:
     dSErPRhcuVptLilygUqOQmJfzsMFvY=dSErPRhcuVptLilygUqOQmJfzsMFTK.get('start_time')
     dSErPRhcuVptLilygUqOQmJfzsMFvx =dSErPRhcuVptLilygUqOQmJfzsMFTK.get('duration') 
     dSErPRhcuVptLilygUqOQmJfzsMFTv=datetime.datetime.strptime(dSErPRhcuVptLilygUqOQmJfzsMFvY,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     dSErPRhcuVptLilygUqOQmJfzsMFTX =dSErPRhcuVptLilygUqOQmJfzsMFTv+datetime.timedelta(seconds=dSErPRhcuVptLilygUqOQmJfzsMFvx)
     dSErPRhcuVptLilygUqOQmJfzsMFTj={'channelid':dSErPRhcuVptLilygUqOQmJfzsMFjB,'title':dSErPRhcuVptLilygUqOQmJfzsMFjX.xmlText(urllib.parse.unquote_plus(dSErPRhcuVptLilygUqOQmJfzsMFTK.get('title'))),'startTime':dSErPRhcuVptLilygUqOQmJfzsMFTv.strftime('%Y%m%d%H%M00'),'endTime':dSErPRhcuVptLilygUqOQmJfzsMFTX.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     dSErPRhcuVptLilygUqOQmJfzsMFTw.append(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  except dSErPRhcuVptLilygUqOQmJfzsMFXn as exception:
   dSErPRhcuVptLilygUqOQmJfzsMFXA(exception)
   return[],[]
  return dSErPRhcuVptLilygUqOQmJfzsMFjx,dSErPRhcuVptLilygUqOQmJfzsMFTw
 def make_getGenre(dSErPRhcuVptLilygUqOQmJfzsMFjX,dSErPRhcuVptLilygUqOQmJfzsMFjB,dSErPRhcuVptLilygUqOQmJfzsMFvG):
  try:
   dSErPRhcuVptLilygUqOQmJfzsMFTn=dSErPRhcuVptLilygUqOQmJfzsMFjX.INIT_CHANNEL.get(dSErPRhcuVptLilygUqOQmJfzsMFjB+'.'+dSErPRhcuVptLilygUqOQmJfzsMFvG).get('genre')
  except:
   dSErPRhcuVptLilygUqOQmJfzsMFTn=dSErPRhcuVptLilygUqOQmJfzsMFjX.INIT_CHANNEL.get('-').get('genre')
  return dSErPRhcuVptLilygUqOQmJfzsMFTn
 def make_base_allchannel_py(dSErPRhcuVptLilygUqOQmJfzsMFjX,dSErPRhcuVptLilygUqOQmJfzsMFvn):
  dSErPRhcuVptLilygUqOQmJfzsMFvC =[]
  dSErPRhcuVptLilygUqOQmJfzsMFvW=[]
  dSErPRhcuVptLilygUqOQmJfzsMFvw=dSErPRhcuVptLilygUqOQmJfzsMFXY()
  dSErPRhcuVptLilygUqOQmJfzsMFTj=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_ChannelList_Wavve()
  dSErPRhcuVptLilygUqOQmJfzsMFvC.extend(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  dSErPRhcuVptLilygUqOQmJfzsMFTj=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_ChannelList_Tving()
  dSErPRhcuVptLilygUqOQmJfzsMFvC.extend(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  dSErPRhcuVptLilygUqOQmJfzsMFTj=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_ChannelList_Seezn()
  dSErPRhcuVptLilygUqOQmJfzsMFvC.extend(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  dSErPRhcuVptLilygUqOQmJfzsMFTj=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_ChannelList_Samsungtv(dSErPRhcuVptLilygUqOQmJfzsMFvn)
  dSErPRhcuVptLilygUqOQmJfzsMFvC.extend(dSErPRhcuVptLilygUqOQmJfzsMFTj)
  dSErPRhcuVptLilygUqOQmJfzsMFXA('1')
  for i in dSErPRhcuVptLilygUqOQmJfzsMFXN(dSErPRhcuVptLilygUqOQmJfzsMFXb(dSErPRhcuVptLilygUqOQmJfzsMFvC)):
   if dSErPRhcuVptLilygUqOQmJfzsMFvC[i]['genrenm']=='-':
    if dSErPRhcuVptLilygUqOQmJfzsMFvC[i]['ott']=='wavve':
     dSErPRhcuVptLilygUqOQmJfzsMFTn=dSErPRhcuVptLilygUqOQmJfzsMFjX.Get_ChanneGenrename_Wavve(dSErPRhcuVptLilygUqOQmJfzsMFvC[i]['channelid'])
     if dSErPRhcuVptLilygUqOQmJfzsMFTn not in dSErPRhcuVptLilygUqOQmJfzsMFvw:dSErPRhcuVptLilygUqOQmJfzsMFvw.add(dSErPRhcuVptLilygUqOQmJfzsMFTn)
     time.sleep(dSErPRhcuVptLilygUqOQmJfzsMFjX.SLEEP_TIME)
    elif dSErPRhcuVptLilygUqOQmJfzsMFvC[i]['ott']=='spotv':
     dSErPRhcuVptLilygUqOQmJfzsMFTn='스포츠'
    else:
     dSErPRhcuVptLilygUqOQmJfzsMFTn='-'
    dSErPRhcuVptLilygUqOQmJfzsMFvC[i]['genrenm']=dSErPRhcuVptLilygUqOQmJfzsMFTn
   else:
    if dSErPRhcuVptLilygUqOQmJfzsMFvC[i]['genrenm']not in dSErPRhcuVptLilygUqOQmJfzsMFvw:dSErPRhcuVptLilygUqOQmJfzsMFvw.add(dSErPRhcuVptLilygUqOQmJfzsMFvC[i]['genrenm'])
  dSErPRhcuVptLilygUqOQmJfzsMFvw.add(dSErPRhcuVptLilygUqOQmJfzsMFjX.INIT_CHANNEL.get('-').get('genre'))
  dSErPRhcuVptLilygUqOQmJfzsMFXA('2')
  for dSErPRhcuVptLilygUqOQmJfzsMFve in dSErPRhcuVptLilygUqOQmJfzsMFvw:
   for dSErPRhcuVptLilygUqOQmJfzsMFvk in dSErPRhcuVptLilygUqOQmJfzsMFvC:
    if dSErPRhcuVptLilygUqOQmJfzsMFvk['genrenm']==dSErPRhcuVptLilygUqOQmJfzsMFve:
     dSErPRhcuVptLilygUqOQmJfzsMFvW.append(dSErPRhcuVptLilygUqOQmJfzsMFvk)
  for dSErPRhcuVptLilygUqOQmJfzsMFvk in dSErPRhcuVptLilygUqOQmJfzsMFvC:
   if dSErPRhcuVptLilygUqOQmJfzsMFvk['genrenm']not in dSErPRhcuVptLilygUqOQmJfzsMFvw:
    dSErPRhcuVptLilygUqOQmJfzsMFvW.append(dSErPRhcuVptLilygUqOQmJfzsMFvk)
  dSErPRhcuVptLilygUqOQmJfzsMFXA('3')
  dSErPRhcuVptLilygUqOQmJfzsMFvK='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(dSErPRhcuVptLilygUqOQmJfzsMFvK):os.remove(dSErPRhcuVptLilygUqOQmJfzsMFvK)
  fp=dSErPRhcuVptLilygUqOQmJfzsMFXx(dSErPRhcuVptLilygUqOQmJfzsMFvK,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  dSErPRhcuVptLilygUqOQmJfzsMFvB=dSErPRhcuVptLilygUqOQmJfzsMFXb(dSErPRhcuVptLilygUqOQmJfzsMFvW)
  i=0
  for dSErPRhcuVptLilygUqOQmJfzsMFjK in dSErPRhcuVptLilygUqOQmJfzsMFvW:
   i+=1
   dSErPRhcuVptLilygUqOQmJfzsMFjB =dSErPRhcuVptLilygUqOQmJfzsMFjK['channelid']
   dSErPRhcuVptLilygUqOQmJfzsMFjG =dSErPRhcuVptLilygUqOQmJfzsMFjK['channelnm']
   dSErPRhcuVptLilygUqOQmJfzsMFvG =dSErPRhcuVptLilygUqOQmJfzsMFjK['ott']
   dSErPRhcuVptLilygUqOQmJfzsMFvI ='%s.%s'%(dSErPRhcuVptLilygUqOQmJfzsMFjB,dSErPRhcuVptLilygUqOQmJfzsMFvG)
   dSErPRhcuVptLilygUqOQmJfzsMFTn =dSErPRhcuVptLilygUqOQmJfzsMFjK['genrenm']
   dSErPRhcuVptLilygUqOQmJfzsMFvo='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(dSErPRhcuVptLilygUqOQmJfzsMFvI,dSErPRhcuVptLilygUqOQmJfzsMFjG,dSErPRhcuVptLilygUqOQmJfzsMFTn)
   if i<dSErPRhcuVptLilygUqOQmJfzsMFvB:
    fp.write(dSErPRhcuVptLilygUqOQmJfzsMFvo+',\n')
   else:
    fp.write(dSErPRhcuVptLilygUqOQmJfzsMFvo+'\n')
  fp.write('}\n')
  fp.close()
  return dSErPRhcuVptLilygUqOQmJfzsMFvw
# Created by pyminifier (https://github.com/liftoff/pyminifier)
