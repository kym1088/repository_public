__author__="NightRain"
aHhekyqcCVXtWUizEwBjPLoNlTRxpJ=object
aHhekyqcCVXtWUizEwBjPLoNlTRxpv=None
aHhekyqcCVXtWUizEwBjPLoNlTRxpF=False
aHhekyqcCVXtWUizEwBjPLoNlTRxps=str
aHhekyqcCVXtWUizEwBjPLoNlTRxpY=Exception
aHhekyqcCVXtWUizEwBjPLoNlTRxpb=print
aHhekyqcCVXtWUizEwBjPLoNlTRxpA=True
aHhekyqcCVXtWUizEwBjPLoNlTRxpr=int
aHhekyqcCVXtWUizEwBjPLoNlTRxpI=range
aHhekyqcCVXtWUizEwBjPLoNlTRxpm=len
aHhekyqcCVXtWUizEwBjPLoNlTRxpg=set
aHhekyqcCVXtWUizEwBjPLoNlTRxpS=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
from channelgenre import*
aHhekyqcCVXtWUizEwBjPLoNlTRxDK='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
aHhekyqcCVXtWUizEwBjPLoNlTRxDp=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
class aHhekyqcCVXtWUizEwBjPLoNlTRxDu(aHhekyqcCVXtWUizEwBjPLoNlTRxpJ):
 def __init__(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ):
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_WAVVE ='https://apis.wavve.com'
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_TVING ='https://api.tving.com'
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_TVINGIMG ='https://image.tving.com'
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_SPOTV ='https://www.spotvnow.co.kr'
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.HTTPTAG ='https://'
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.LIMIT_WAVVE =200
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.LIMIT_TVING =60
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.LIMIT_TVINGEPG=20 
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.DEFAULT_HEADER={'user-agent':aHhekyqcCVXtWUizEwBjPLoNlTRxDK}
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.SLEEP_TIME =0.2
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.INIT_GENRESORT=MASTER_GENRE
  aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,jobtype,aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,redirects=aHhekyqcCVXtWUizEwBjPLoNlTRxpF):
  aHhekyqcCVXtWUizEwBjPLoNlTRxDs=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.DEFAULT_HEADER
  if headers:aHhekyqcCVXtWUizEwBjPLoNlTRxDs.update(headers)
  if jobtype=='Get':
   aHhekyqcCVXtWUizEwBjPLoNlTRxDY=requests.get(aHhekyqcCVXtWUizEwBjPLoNlTRxDS,params=params,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxDs,cookies=cookies,allow_redirects=redirects)
  else:
   aHhekyqcCVXtWUizEwBjPLoNlTRxDY=requests.post(aHhekyqcCVXtWUizEwBjPLoNlTRxDS,data=payload,params=params,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxDs,cookies=cookies,allow_redirects=redirects)
  return aHhekyqcCVXtWUizEwBjPLoNlTRxDY
 def Get_DefaultParams_Wavve(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ):
  aHhekyqcCVXtWUizEwBjPLoNlTRxDb={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return aHhekyqcCVXtWUizEwBjPLoNlTRxDb
 def Get_DefaultParams_Tving(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ):
  aHhekyqcCVXtWUizEwBjPLoNlTRxDb={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return aHhekyqcCVXtWUizEwBjPLoNlTRxDb
 def Get_Now_Datetime(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,in_text):
  aHhekyqcCVXtWUizEwBjPLoNlTRxDr=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return aHhekyqcCVXtWUizEwBjPLoNlTRxDr
 def Get_ChannelList_Wavve(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,exceptGroup=[]):
  aHhekyqcCVXtWUizEwBjPLoNlTRxDI =[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxDm=[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxDg=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_ChannelImg_Wavve()
  if exceptGroup!=[]:
   aHhekyqcCVXtWUizEwBjPLoNlTRxDm=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_ChannelList_WavveExcept(exceptGroup)
  try:
   aHhekyqcCVXtWUizEwBjPLoNlTRxDS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_WAVVE+'/cf/live/recommend-channels'
   aHhekyqcCVXtWUizEwBjPLoNlTRxDb={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':aHhekyqcCVXtWUizEwBjPLoNlTRxps(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   aHhekyqcCVXtWUizEwBjPLoNlTRxDb.update(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_DefaultParams_Wavve())
   aHhekyqcCVXtWUizEwBjPLoNlTRxDO=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.callRequestCookies('Get',aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxDb,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv)
   aHhekyqcCVXtWUizEwBjPLoNlTRxDM=json.loads(aHhekyqcCVXtWUizEwBjPLoNlTRxDO.text)
   if not('celllist' in aHhekyqcCVXtWUizEwBjPLoNlTRxDM['cell_toplist']):return aHhekyqcCVXtWUizEwBjPLoNlTRxDI
   aHhekyqcCVXtWUizEwBjPLoNlTRxDn=aHhekyqcCVXtWUizEwBjPLoNlTRxDM['cell_toplist']['celllist']
   for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxDn:
    aHhekyqcCVXtWUizEwBjPLoNlTRxDf=aHhekyqcCVXtWUizEwBjPLoNlTRxDd['contentid']
    aHhekyqcCVXtWUizEwBjPLoNlTRxDQ=aHhekyqcCVXtWUizEwBjPLoNlTRxDd['title_list'][0]['text']
    if aHhekyqcCVXtWUizEwBjPLoNlTRxDf in aHhekyqcCVXtWUizEwBjPLoNlTRxDg:
     aHhekyqcCVXtWUizEwBjPLoNlTRxDG=aHhekyqcCVXtWUizEwBjPLoNlTRxDg[aHhekyqcCVXtWUizEwBjPLoNlTRxDf]
    else:
     aHhekyqcCVXtWUizEwBjPLoNlTRxDG=''
    aHhekyqcCVXtWUizEwBjPLoNlTRxuD={'channelid':aHhekyqcCVXtWUizEwBjPLoNlTRxDf,'channelnm':aHhekyqcCVXtWUizEwBjPLoNlTRxDQ,'channelimg':aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.HTTPTAG+aHhekyqcCVXtWUizEwBjPLoNlTRxDG if aHhekyqcCVXtWUizEwBjPLoNlTRxDG!='' else '','ott':'wavve','genrenm':aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.make_getGenre(aHhekyqcCVXtWUizEwBjPLoNlTRxDf,'wavve')}
    if aHhekyqcCVXtWUizEwBjPLoNlTRxDf not in aHhekyqcCVXtWUizEwBjPLoNlTRxDm:
     aHhekyqcCVXtWUizEwBjPLoNlTRxDI.append(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
  except aHhekyqcCVXtWUizEwBjPLoNlTRxpY as exception:
   aHhekyqcCVXtWUizEwBjPLoNlTRxpb(exception)
   return[]
  return aHhekyqcCVXtWUizEwBjPLoNlTRxDI
 def Get_ChannelList_WavveExcept(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,exceptGroup=[]):
  aHhekyqcCVXtWUizEwBjPLoNlTRxDI=[]
  if exceptGroup==[]:return[]
  try:
   aHhekyqcCVXtWUizEwBjPLoNlTRxDS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_WAVVE+'/cf/live/recommend-channels'
   for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in exceptGroup:
    aHhekyqcCVXtWUizEwBjPLoNlTRxDb={'WeekDay':'all','adult':'n','broadcastid':aHhekyqcCVXtWUizEwBjPLoNlTRxDd['broadcastid'],'contenttype':'channel','genre':aHhekyqcCVXtWUizEwBjPLoNlTRxDd['genre'],'isrecommend':'y','limit':aHhekyqcCVXtWUizEwBjPLoNlTRxps(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    aHhekyqcCVXtWUizEwBjPLoNlTRxDb.update(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_DefaultParams_Wavve())
    aHhekyqcCVXtWUizEwBjPLoNlTRxDO=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.callRequestCookies('Get',aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxDb,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv)
    aHhekyqcCVXtWUizEwBjPLoNlTRxDM=json.loads(aHhekyqcCVXtWUizEwBjPLoNlTRxDO.text)
    if not('celllist' in aHhekyqcCVXtWUizEwBjPLoNlTRxDM['cell_toplist']):return aHhekyqcCVXtWUizEwBjPLoNlTRxDI
    aHhekyqcCVXtWUizEwBjPLoNlTRxDn=aHhekyqcCVXtWUizEwBjPLoNlTRxDM['cell_toplist']['celllist']
    for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxDn:
     aHhekyqcCVXtWUizEwBjPLoNlTRxDI.append(aHhekyqcCVXtWUizEwBjPLoNlTRxDd['contentid'])
  except aHhekyqcCVXtWUizEwBjPLoNlTRxpY as exception:
   aHhekyqcCVXtWUizEwBjPLoNlTRxpb(exception)
   return[]
  return aHhekyqcCVXtWUizEwBjPLoNlTRxDI
 def Get_ChannelImg_Wavve(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ):
  aHhekyqcCVXtWUizEwBjPLoNlTRxuK={}
  try:
   aHhekyqcCVXtWUizEwBjPLoNlTRxup=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_Now_Datetime()
   aHhekyqcCVXtWUizEwBjPLoNlTRxuJ =aHhekyqcCVXtWUizEwBjPLoNlTRxup+datetime.timedelta(hours=3)
   aHhekyqcCVXtWUizEwBjPLoNlTRxDS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_WAVVE+'/live/epgs'
   aHhekyqcCVXtWUizEwBjPLoNlTRxDb={'limit':aHhekyqcCVXtWUizEwBjPLoNlTRxps(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':aHhekyqcCVXtWUizEwBjPLoNlTRxup.strftime('%Y-%m-%d %H:00'),'enddatetime':aHhekyqcCVXtWUizEwBjPLoNlTRxuJ.strftime('%Y-%m-%d %H:00')}
   aHhekyqcCVXtWUizEwBjPLoNlTRxDb.update(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_DefaultParams_Wavve())
   aHhekyqcCVXtWUizEwBjPLoNlTRxDO=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.callRequestCookies('Get',aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxDb,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv)
   aHhekyqcCVXtWUizEwBjPLoNlTRxDM=json.loads(aHhekyqcCVXtWUizEwBjPLoNlTRxDO.text)
   aHhekyqcCVXtWUizEwBjPLoNlTRxDn=aHhekyqcCVXtWUizEwBjPLoNlTRxDM['list']
   for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxDn:
    aHhekyqcCVXtWUizEwBjPLoNlTRxuK[aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelid']]=aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelimage']
  except aHhekyqcCVXtWUizEwBjPLoNlTRxpY as exception:
   aHhekyqcCVXtWUizEwBjPLoNlTRxpb(exception)
  return aHhekyqcCVXtWUizEwBjPLoNlTRxuK
 def Get_ChanneGenrename_Wavve(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,aHhekyqcCVXtWUizEwBjPLoNlTRxDf):
  try:
   aHhekyqcCVXtWUizEwBjPLoNlTRxDS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_WAVVE+'/live/channels/'+aHhekyqcCVXtWUizEwBjPLoNlTRxDf
   aHhekyqcCVXtWUizEwBjPLoNlTRxDb=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_DefaultParams_Wavve()
   aHhekyqcCVXtWUizEwBjPLoNlTRxDO=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.callRequestCookies('Get',aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxDb,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv)
   aHhekyqcCVXtWUizEwBjPLoNlTRxDM=json.loads(aHhekyqcCVXtWUizEwBjPLoNlTRxDO.text)
   aHhekyqcCVXtWUizEwBjPLoNlTRxuv=aHhekyqcCVXtWUizEwBjPLoNlTRxDM['genretext']
  except aHhekyqcCVXtWUizEwBjPLoNlTRxpY as exception:
   aHhekyqcCVXtWUizEwBjPLoNlTRxpb(exception)
   return ''
  return aHhekyqcCVXtWUizEwBjPLoNlTRxuv
 def Get_ChannelList_Spotv(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,payyn=aHhekyqcCVXtWUizEwBjPLoNlTRxpA):
  aHhekyqcCVXtWUizEwBjPLoNlTRxDI=[]
  try:
   aHhekyqcCVXtWUizEwBjPLoNlTRxDS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_SPOTV+'/api/v2/channel'
   aHhekyqcCVXtWUizEwBjPLoNlTRxDO=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.callRequestCookies('Get',aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv)
   aHhekyqcCVXtWUizEwBjPLoNlTRxDM=json.loads(aHhekyqcCVXtWUizEwBjPLoNlTRxDO.text)
   for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxDM:
    aHhekyqcCVXtWUizEwBjPLoNlTRxDf=aHhekyqcCVXtWUizEwBjPLoNlTRxDd['videoId'].replace('ref:','')
    aHhekyqcCVXtWUizEwBjPLoNlTRxuD={'channelid':aHhekyqcCVXtWUizEwBjPLoNlTRxDf,'channelnm':aHhekyqcCVXtWUizEwBjPLoNlTRxDd['name'],'channelimg':aHhekyqcCVXtWUizEwBjPLoNlTRxDd['logo'],'ott':'spotv','genrenm':aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.make_getGenre(aHhekyqcCVXtWUizEwBjPLoNlTRxDf,'spotv')}
    if payyn==aHhekyqcCVXtWUizEwBjPLoNlTRxpA or aHhekyqcCVXtWUizEwBjPLoNlTRxDd['free']==aHhekyqcCVXtWUizEwBjPLoNlTRxpA:
     aHhekyqcCVXtWUizEwBjPLoNlTRxDI.append(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
  except aHhekyqcCVXtWUizEwBjPLoNlTRxpY as exception:
   aHhekyqcCVXtWUizEwBjPLoNlTRxpb(exception)
   return[]
  return aHhekyqcCVXtWUizEwBjPLoNlTRxDI
 def Get_ChannelList_Tving(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ):
  aHhekyqcCVXtWUizEwBjPLoNlTRxDI =[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxuF=[]
  try:
   aHhekyqcCVXtWUizEwBjPLoNlTRxDS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_TVING+'/v2/media/lives'
   aHhekyqcCVXtWUizEwBjPLoNlTRxDb={'pageNo':'1','pageSize':aHhekyqcCVXtWUizEwBjPLoNlTRxps(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   aHhekyqcCVXtWUizEwBjPLoNlTRxDb.update(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_DefaultParams_Tving())
   aHhekyqcCVXtWUizEwBjPLoNlTRxDO=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.callRequestCookies('Get',aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxDb,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv)
   aHhekyqcCVXtWUizEwBjPLoNlTRxDM=json.loads(aHhekyqcCVXtWUizEwBjPLoNlTRxDO.text)
   if not('result' in aHhekyqcCVXtWUizEwBjPLoNlTRxDM['body']):return aHhekyqcCVXtWUizEwBjPLoNlTRxDI
   aHhekyqcCVXtWUizEwBjPLoNlTRxDn=aHhekyqcCVXtWUizEwBjPLoNlTRxDM['body']['result']
   for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxDn:
    if aHhekyqcCVXtWUizEwBjPLoNlTRxDd['live_code']=='C44441':continue 
    aHhekyqcCVXtWUizEwBjPLoNlTRxuF.append(aHhekyqcCVXtWUizEwBjPLoNlTRxDd['live_code'])
   aHhekyqcCVXtWUizEwBjPLoNlTRxDg=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_ChannelImg_Tving(aHhekyqcCVXtWUizEwBjPLoNlTRxuF)
   for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxDn:
    aHhekyqcCVXtWUizEwBjPLoNlTRxDf=aHhekyqcCVXtWUizEwBjPLoNlTRxDd['live_code']
    if aHhekyqcCVXtWUizEwBjPLoNlTRxDf=='C44441':continue 
    aHhekyqcCVXtWUizEwBjPLoNlTRxDQ=aHhekyqcCVXtWUizEwBjPLoNlTRxDd['schedule']['channel']['name']['ko']
    if aHhekyqcCVXtWUizEwBjPLoNlTRxDf in aHhekyqcCVXtWUizEwBjPLoNlTRxDg:
     aHhekyqcCVXtWUizEwBjPLoNlTRxDG=aHhekyqcCVXtWUizEwBjPLoNlTRxDg[aHhekyqcCVXtWUizEwBjPLoNlTRxDf]
    else:
     aHhekyqcCVXtWUizEwBjPLoNlTRxDG=''
    aHhekyqcCVXtWUizEwBjPLoNlTRxuD={'channelid':aHhekyqcCVXtWUizEwBjPLoNlTRxDf,'channelnm':aHhekyqcCVXtWUizEwBjPLoNlTRxDQ,'channelimg':aHhekyqcCVXtWUizEwBjPLoNlTRxDG,'ott':'tving','genrenm':aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.make_getGenre(aHhekyqcCVXtWUizEwBjPLoNlTRxDf,'tving')}
    aHhekyqcCVXtWUizEwBjPLoNlTRxDI.append(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
  except aHhekyqcCVXtWUizEwBjPLoNlTRxpY as exception:
   aHhekyqcCVXtWUizEwBjPLoNlTRxpb(exception)
   return[]
  return aHhekyqcCVXtWUizEwBjPLoNlTRxDI
 def make_EpgDatetime_Tving(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,days=2):
  aHhekyqcCVXtWUizEwBjPLoNlTRxus=[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxuY=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.make_DateList(days=2,dateType='2')
  aHhekyqcCVXtWUizEwBjPLoNlTRxub=aHhekyqcCVXtWUizEwBjPLoNlTRxpr(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxuY:
   for aHhekyqcCVXtWUizEwBjPLoNlTRxuA in aHhekyqcCVXtWUizEwBjPLoNlTRxpI(8):
    aHhekyqcCVXtWUizEwBjPLoNlTRxuD={'ndate':aHhekyqcCVXtWUizEwBjPLoNlTRxDd,'starttm':aHhekyqcCVXtWUizEwBjPLoNlTRxDp[aHhekyqcCVXtWUizEwBjPLoNlTRxuA]['starttm'],'endtm':aHhekyqcCVXtWUizEwBjPLoNlTRxDp[aHhekyqcCVXtWUizEwBjPLoNlTRxuA]['endtm']}
    aHhekyqcCVXtWUizEwBjPLoNlTRxur=aHhekyqcCVXtWUizEwBjPLoNlTRxpr(aHhekyqcCVXtWUizEwBjPLoNlTRxDd+aHhekyqcCVXtWUizEwBjPLoNlTRxDp[aHhekyqcCVXtWUizEwBjPLoNlTRxuA]['starttm'])
    aHhekyqcCVXtWUizEwBjPLoNlTRxuI=aHhekyqcCVXtWUizEwBjPLoNlTRxpr(aHhekyqcCVXtWUizEwBjPLoNlTRxDd+aHhekyqcCVXtWUizEwBjPLoNlTRxDp[aHhekyqcCVXtWUizEwBjPLoNlTRxuA]['endtm'])
    if aHhekyqcCVXtWUizEwBjPLoNlTRxub<=aHhekyqcCVXtWUizEwBjPLoNlTRxur or(aHhekyqcCVXtWUizEwBjPLoNlTRxur<aHhekyqcCVXtWUizEwBjPLoNlTRxub and aHhekyqcCVXtWUizEwBjPLoNlTRxub<aHhekyqcCVXtWUizEwBjPLoNlTRxuI):
     aHhekyqcCVXtWUizEwBjPLoNlTRxus.append(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
  return aHhekyqcCVXtWUizEwBjPLoNlTRxus
 def make_DateList(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,days=2,dateType='1'):
  aHhekyqcCVXtWUizEwBjPLoNlTRxuY=[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxum =aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_Now_Datetime()
  if dateType=='1':
   aHhekyqcCVXtWUizEwBjPLoNlTRxum=aHhekyqcCVXtWUizEwBjPLoNlTRxum-datetime.timedelta(days=1)
  for i in aHhekyqcCVXtWUizEwBjPLoNlTRxpI(days):
   aHhekyqcCVXtWUizEwBjPLoNlTRxug=aHhekyqcCVXtWUizEwBjPLoNlTRxum+datetime.timedelta(days=i)
   if dateType=='1':
    aHhekyqcCVXtWUizEwBjPLoNlTRxuY.append(aHhekyqcCVXtWUizEwBjPLoNlTRxug.strftime('%Y-%m-%d'))
   else:
    aHhekyqcCVXtWUizEwBjPLoNlTRxuY.append(aHhekyqcCVXtWUizEwBjPLoNlTRxug.strftime('%Y%m%d'))
  return aHhekyqcCVXtWUizEwBjPLoNlTRxuY
 def make_Tving_ChannleGroup(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,aHhekyqcCVXtWUizEwBjPLoNlTRxuF):
  aHhekyqcCVXtWUizEwBjPLoNlTRxuS=[]
  i=0
  aHhekyqcCVXtWUizEwBjPLoNlTRxuO=''
  for aHhekyqcCVXtWUizEwBjPLoNlTRxuM in aHhekyqcCVXtWUizEwBjPLoNlTRxuF:
   if i==0:aHhekyqcCVXtWUizEwBjPLoNlTRxuO=aHhekyqcCVXtWUizEwBjPLoNlTRxuM
   else:aHhekyqcCVXtWUizEwBjPLoNlTRxuO+=',%s'%(aHhekyqcCVXtWUizEwBjPLoNlTRxuM)
   i+=1
   if i>=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.LIMIT_TVINGEPG:
    aHhekyqcCVXtWUizEwBjPLoNlTRxuS.append(aHhekyqcCVXtWUizEwBjPLoNlTRxuO)
    i=0
    aHhekyqcCVXtWUizEwBjPLoNlTRxuO=''
  if aHhekyqcCVXtWUizEwBjPLoNlTRxuO!='':
   aHhekyqcCVXtWUizEwBjPLoNlTRxuS.append(aHhekyqcCVXtWUizEwBjPLoNlTRxuO)
  return aHhekyqcCVXtWUizEwBjPLoNlTRxuS
 def Get_ChannelImg_Tving(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,chid_list):
  aHhekyqcCVXtWUizEwBjPLoNlTRxuK={}
  try:
   aHhekyqcCVXtWUizEwBjPLoNlTRxun=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_Now_Datetime().strftime('%Y%m%d')
   aHhekyqcCVXtWUizEwBjPLoNlTRxup =aHhekyqcCVXtWUizEwBjPLoNlTRxDp[6]['starttm'] 
   aHhekyqcCVXtWUizEwBjPLoNlTRxuJ =aHhekyqcCVXtWUizEwBjPLoNlTRxDp[6]['endtm']
   aHhekyqcCVXtWUizEwBjPLoNlTRxuS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.make_Tving_ChannleGroup(chid_list)
   for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxuS:
    aHhekyqcCVXtWUizEwBjPLoNlTRxDS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_TVING+'/v2/media/schedules'
    aHhekyqcCVXtWUizEwBjPLoNlTRxDb={'pageNo':'1','pageSize':aHhekyqcCVXtWUizEwBjPLoNlTRxps(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':aHhekyqcCVXtWUizEwBjPLoNlTRxun,'broadcastDate':aHhekyqcCVXtWUizEwBjPLoNlTRxun,'startBroadTime':aHhekyqcCVXtWUizEwBjPLoNlTRxup,'endBroadTime':aHhekyqcCVXtWUizEwBjPLoNlTRxuJ,'channelCode':aHhekyqcCVXtWUizEwBjPLoNlTRxDd}
    aHhekyqcCVXtWUizEwBjPLoNlTRxDb.update(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_DefaultParams_Tving())
    aHhekyqcCVXtWUizEwBjPLoNlTRxDO=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.callRequestCookies('Get',aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxDb,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv)
    aHhekyqcCVXtWUizEwBjPLoNlTRxDM=json.loads(aHhekyqcCVXtWUizEwBjPLoNlTRxDO.text)
    if not('result' in aHhekyqcCVXtWUizEwBjPLoNlTRxDM['body']):return{}
    aHhekyqcCVXtWUizEwBjPLoNlTRxDn=aHhekyqcCVXtWUizEwBjPLoNlTRxDM['body']['result']
    for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxDn:
     aHhekyqcCVXtWUizEwBjPLoNlTRxuK[aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channel_code']]=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_TVINGIMG+aHhekyqcCVXtWUizEwBjPLoNlTRxDd['image'][2]['url']
  except aHhekyqcCVXtWUizEwBjPLoNlTRxpY as exception:
   aHhekyqcCVXtWUizEwBjPLoNlTRxpb(exception)
   return{}
  return aHhekyqcCVXtWUizEwBjPLoNlTRxuK
 def Get_EpgInfo_Spotv(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,days=3,payyn=aHhekyqcCVXtWUizEwBjPLoNlTRxpA):
  aHhekyqcCVXtWUizEwBjPLoNlTRxud ={}
  aHhekyqcCVXtWUizEwBjPLoNlTRxDI=[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxuf =[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxuY=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.make_DateList(days=days,dateType='1')
  aHhekyqcCVXtWUizEwBjPLoNlTRxpb(aHhekyqcCVXtWUizEwBjPLoNlTRxuY)
  try:
   aHhekyqcCVXtWUizEwBjPLoNlTRxDS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_SPOTV+'/api/v2/channel'
   aHhekyqcCVXtWUizEwBjPLoNlTRxDO=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.callRequestCookies('Get',aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv)
   aHhekyqcCVXtWUizEwBjPLoNlTRxDM=json.loads(aHhekyqcCVXtWUizEwBjPLoNlTRxDO.text)
   for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxDM:
    aHhekyqcCVXtWUizEwBjPLoNlTRxDf =aHhekyqcCVXtWUizEwBjPLoNlTRxDd['videoId'].replace('ref:','')
    aHhekyqcCVXtWUizEwBjPLoNlTRxuD={'channelid':aHhekyqcCVXtWUizEwBjPLoNlTRxDf,'channelnm':aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.xmlText(aHhekyqcCVXtWUizEwBjPLoNlTRxDd['name']),'channelimg':aHhekyqcCVXtWUizEwBjPLoNlTRxDd['logo'],'ott':'spotv'}
    if payyn==aHhekyqcCVXtWUizEwBjPLoNlTRxpA or aHhekyqcCVXtWUizEwBjPLoNlTRxDd['free']==aHhekyqcCVXtWUizEwBjPLoNlTRxpA:
     aHhekyqcCVXtWUizEwBjPLoNlTRxud[aHhekyqcCVXtWUizEwBjPLoNlTRxDd['id']]=aHhekyqcCVXtWUizEwBjPLoNlTRxDf
     aHhekyqcCVXtWUizEwBjPLoNlTRxDI.append(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
  except aHhekyqcCVXtWUizEwBjPLoNlTRxpY as exception:
   aHhekyqcCVXtWUizEwBjPLoNlTRxpb(exception)
   return[],[]
  try:
   for aHhekyqcCVXtWUizEwBjPLoNlTRxuQ in aHhekyqcCVXtWUizEwBjPLoNlTRxuY:
    aHhekyqcCVXtWUizEwBjPLoNlTRxDS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_SPOTV+'/api/v2/program/'+aHhekyqcCVXtWUizEwBjPLoNlTRxuQ
    aHhekyqcCVXtWUizEwBjPLoNlTRxDO=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.callRequestCookies('Get',aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv)
    aHhekyqcCVXtWUizEwBjPLoNlTRxDM=json.loads(aHhekyqcCVXtWUizEwBjPLoNlTRxDO.text)
    for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxDM:
     if aHhekyqcCVXtWUizEwBjPLoNlTRxud.get(aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelId'])==aHhekyqcCVXtWUizEwBjPLoNlTRxpv:continue
     aHhekyqcCVXtWUizEwBjPLoNlTRxuD={'channelid':aHhekyqcCVXtWUizEwBjPLoNlTRxud.get(aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelId']),'title':aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.xmlText(aHhekyqcCVXtWUizEwBjPLoNlTRxDd['title']),'startTime':aHhekyqcCVXtWUizEwBjPLoNlTRxDd['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':aHhekyqcCVXtWUizEwBjPLoNlTRxDd['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     aHhekyqcCVXtWUizEwBjPLoNlTRxuf.append(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
    time.sleep(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.SLEEP_TIME)
  except aHhekyqcCVXtWUizEwBjPLoNlTRxpY as exception:
   aHhekyqcCVXtWUizEwBjPLoNlTRxpb(exception)
   return[],[]
  return aHhekyqcCVXtWUizEwBjPLoNlTRxDI,aHhekyqcCVXtWUizEwBjPLoNlTRxuf
 def Get_EpgInfo_Wavve(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,days=2,exceptGroup=[]):
  aHhekyqcCVXtWUizEwBjPLoNlTRxDI =[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxuf =[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxDm=[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxum =aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_Now_Datetime()
  aHhekyqcCVXtWUizEwBjPLoNlTRxuG =aHhekyqcCVXtWUizEwBjPLoNlTRxum+datetime.timedelta(hours=-2)
  aHhekyqcCVXtWUizEwBjPLoNlTRxKD =aHhekyqcCVXtWUizEwBjPLoNlTRxum+datetime.timedelta(days=(days-1))
  if aHhekyqcCVXtWUizEwBjPLoNlTRxpr(aHhekyqcCVXtWUizEwBjPLoNlTRxuG.strftime('%H'))<=3:
   aHhekyqcCVXtWUizEwBjPLoNlTRxKu=aHhekyqcCVXtWUizEwBjPLoNlTRxuG.strftime('%Y-%m-%d 00:00')
  else:
   aHhekyqcCVXtWUizEwBjPLoNlTRxKu=aHhekyqcCVXtWUizEwBjPLoNlTRxuG.strftime('%Y-%m-%d %H:00')
  aHhekyqcCVXtWUizEwBjPLoNlTRxKp =aHhekyqcCVXtWUizEwBjPLoNlTRxKD.strftime('%Y-%m-%d 24:00')
  if exceptGroup!=[]:
   aHhekyqcCVXtWUizEwBjPLoNlTRxDm=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_ChannelList_WavveExcept(exceptGroup)
  try:
   aHhekyqcCVXtWUizEwBjPLoNlTRxDS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_WAVVE+'/live/epgs'
   aHhekyqcCVXtWUizEwBjPLoNlTRxDb={'limit':aHhekyqcCVXtWUizEwBjPLoNlTRxps(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':aHhekyqcCVXtWUizEwBjPLoNlTRxKu,'enddatetime':aHhekyqcCVXtWUizEwBjPLoNlTRxKp}
   aHhekyqcCVXtWUizEwBjPLoNlTRxDb.update(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_DefaultParams_Wavve())
   aHhekyqcCVXtWUizEwBjPLoNlTRxDO=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.callRequestCookies('Get',aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxDb,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv)
   aHhekyqcCVXtWUizEwBjPLoNlTRxDM=json.loads(aHhekyqcCVXtWUizEwBjPLoNlTRxDO.text)
   aHhekyqcCVXtWUizEwBjPLoNlTRxKJ=aHhekyqcCVXtWUizEwBjPLoNlTRxDM['list']
   for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxKJ:
    aHhekyqcCVXtWUizEwBjPLoNlTRxuD={'channelid':aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelid'],'channelnm':aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.xmlText(aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelname']),'channelimg':aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.HTTPTAG+aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelimage'],'ott':'wavve'}
    if aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelid']not in aHhekyqcCVXtWUizEwBjPLoNlTRxDm:
     aHhekyqcCVXtWUizEwBjPLoNlTRxDI.append(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
    for aHhekyqcCVXtWUizEwBjPLoNlTRxKv in aHhekyqcCVXtWUizEwBjPLoNlTRxDd['list']:
     aHhekyqcCVXtWUizEwBjPLoNlTRxuD={'channelid':aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelid'],'title':aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.xmlText(aHhekyqcCVXtWUizEwBjPLoNlTRxKv['title']),'startTime':aHhekyqcCVXtWUizEwBjPLoNlTRxKv['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':aHhekyqcCVXtWUizEwBjPLoNlTRxKv['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelid']not in aHhekyqcCVXtWUizEwBjPLoNlTRxDm and aHhekyqcCVXtWUizEwBjPLoNlTRxKv['starttime']!=aHhekyqcCVXtWUizEwBjPLoNlTRxKv['endtime']:
      aHhekyqcCVXtWUizEwBjPLoNlTRxuf.append(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
  except aHhekyqcCVXtWUizEwBjPLoNlTRxpY as exception:
   aHhekyqcCVXtWUizEwBjPLoNlTRxpb(exception)
   return[],[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxKF=aHhekyqcCVXtWUizEwBjPLoNlTRxpm(aHhekyqcCVXtWUizEwBjPLoNlTRxuf)
  for i in(aHhekyqcCVXtWUizEwBjPLoNlTRxpI(1,aHhekyqcCVXtWUizEwBjPLoNlTRxKF)):
   if aHhekyqcCVXtWUizEwBjPLoNlTRxpr(aHhekyqcCVXtWUizEwBjPLoNlTRxuf[i-1]['endTime'])+1==aHhekyqcCVXtWUizEwBjPLoNlTRxpr(aHhekyqcCVXtWUizEwBjPLoNlTRxuf[i]['startTime'])and aHhekyqcCVXtWUizEwBjPLoNlTRxuf[i-1]['channelid']==aHhekyqcCVXtWUizEwBjPLoNlTRxuf[i]['channelid']:
    aHhekyqcCVXtWUizEwBjPLoNlTRxuf[i-1]['endTime']=aHhekyqcCVXtWUizEwBjPLoNlTRxuf[i]['startTime']
  return aHhekyqcCVXtWUizEwBjPLoNlTRxDI,aHhekyqcCVXtWUizEwBjPLoNlTRxuf
 def Get_EpgInfo_Tving(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,days=2):
  aHhekyqcCVXtWUizEwBjPLoNlTRxDI=[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxuf =[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxKs =[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxKY =aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.make_EpgDatetime_Tving(days=days)
  aHhekyqcCVXtWUizEwBjPLoNlTRxDI =aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_ChannelList_Tving()
  aHhekyqcCVXtWUizEwBjPLoNlTRxKb=[]
  for i in aHhekyqcCVXtWUizEwBjPLoNlTRxpI(aHhekyqcCVXtWUizEwBjPLoNlTRxpm(aHhekyqcCVXtWUizEwBjPLoNlTRxDI)):
   aHhekyqcCVXtWUizEwBjPLoNlTRxDI[i]['channelnm']=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.xmlText(aHhekyqcCVXtWUizEwBjPLoNlTRxDI[i]['channelnm'])
   aHhekyqcCVXtWUizEwBjPLoNlTRxKb.append(aHhekyqcCVXtWUizEwBjPLoNlTRxDI[i]['channelid'])
  aHhekyqcCVXtWUizEwBjPLoNlTRxKA=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.make_Tving_ChannleGroup(aHhekyqcCVXtWUizEwBjPLoNlTRxKb)
  try:
   aHhekyqcCVXtWUizEwBjPLoNlTRxDS=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.API_TVING+'/v2/media/schedules'
   for aHhekyqcCVXtWUizEwBjPLoNlTRxKr in aHhekyqcCVXtWUizEwBjPLoNlTRxKY:
    for aHhekyqcCVXtWUizEwBjPLoNlTRxKI in aHhekyqcCVXtWUizEwBjPLoNlTRxKA:
     aHhekyqcCVXtWUizEwBjPLoNlTRxDb={'pageNo':'1','pageSize':aHhekyqcCVXtWUizEwBjPLoNlTRxps(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':aHhekyqcCVXtWUizEwBjPLoNlTRxKr['ndate'],'broadcastDate':aHhekyqcCVXtWUizEwBjPLoNlTRxKr['ndate'],'startBroadTime':aHhekyqcCVXtWUizEwBjPLoNlTRxKr['starttm'],'endBroadTime':aHhekyqcCVXtWUizEwBjPLoNlTRxKr['endtm'],'channelCode':aHhekyqcCVXtWUizEwBjPLoNlTRxKI}
     aHhekyqcCVXtWUizEwBjPLoNlTRxDb.update(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_DefaultParams_Tving())
     aHhekyqcCVXtWUizEwBjPLoNlTRxDO=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.callRequestCookies('Get',aHhekyqcCVXtWUizEwBjPLoNlTRxDS,payload=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,params=aHhekyqcCVXtWUizEwBjPLoNlTRxDb,headers=aHhekyqcCVXtWUizEwBjPLoNlTRxpv,cookies=aHhekyqcCVXtWUizEwBjPLoNlTRxpv)
     aHhekyqcCVXtWUizEwBjPLoNlTRxDM=json.loads(aHhekyqcCVXtWUizEwBjPLoNlTRxDO.text)
     aHhekyqcCVXtWUizEwBjPLoNlTRxDn=aHhekyqcCVXtWUizEwBjPLoNlTRxDM['body']['result']
     for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxDn:
      if 'schedules' not in aHhekyqcCVXtWUizEwBjPLoNlTRxDd:continue
      if aHhekyqcCVXtWUizEwBjPLoNlTRxDd['schedules']==aHhekyqcCVXtWUizEwBjPLoNlTRxpv:continue
      for aHhekyqcCVXtWUizEwBjPLoNlTRxKm in aHhekyqcCVXtWUizEwBjPLoNlTRxDd['schedules']:
       aHhekyqcCVXtWUizEwBjPLoNlTRxuD={'channelid':aHhekyqcCVXtWUizEwBjPLoNlTRxKm['schedule_code'],'title':aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.xmlText(aHhekyqcCVXtWUizEwBjPLoNlTRxKm['program']['name']['ko']),'startTime':aHhekyqcCVXtWUizEwBjPLoNlTRxps(aHhekyqcCVXtWUizEwBjPLoNlTRxKm['broadcast_start_time']),'endTime':aHhekyqcCVXtWUizEwBjPLoNlTRxps(aHhekyqcCVXtWUizEwBjPLoNlTRxKm['broadcast_end_time']),'ott':'tving'}
       aHhekyqcCVXtWUizEwBjPLoNlTRxKg=aHhekyqcCVXtWUizEwBjPLoNlTRxKm['schedule_code']+aHhekyqcCVXtWUizEwBjPLoNlTRxps(aHhekyqcCVXtWUizEwBjPLoNlTRxKm['broadcast_start_time'])
       if aHhekyqcCVXtWUizEwBjPLoNlTRxKg in aHhekyqcCVXtWUizEwBjPLoNlTRxKs:continue
       aHhekyqcCVXtWUizEwBjPLoNlTRxKs.append(aHhekyqcCVXtWUizEwBjPLoNlTRxKg)
       aHhekyqcCVXtWUizEwBjPLoNlTRxuf.append(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
     time.sleep(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.SLEEP_TIME)
  except aHhekyqcCVXtWUizEwBjPLoNlTRxpY as exception:
   aHhekyqcCVXtWUizEwBjPLoNlTRxpb(exception)
   return[],[]
  return aHhekyqcCVXtWUizEwBjPLoNlTRxDI,aHhekyqcCVXtWUizEwBjPLoNlTRxuf
 def make_getGenre(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ,aHhekyqcCVXtWUizEwBjPLoNlTRxDf,aHhekyqcCVXtWUizEwBjPLoNlTRxpD):
  try:
   aHhekyqcCVXtWUizEwBjPLoNlTRxuv=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.INIT_CHANNEL.get(aHhekyqcCVXtWUizEwBjPLoNlTRxDf+'.'+aHhekyqcCVXtWUizEwBjPLoNlTRxpD).get('genre')
  except:
   aHhekyqcCVXtWUizEwBjPLoNlTRxuv='-'
  return aHhekyqcCVXtWUizEwBjPLoNlTRxuv
 def make_base_allchannel_py(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ):
  aHhekyqcCVXtWUizEwBjPLoNlTRxKS =[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxKO=[]
  aHhekyqcCVXtWUizEwBjPLoNlTRxKM=aHhekyqcCVXtWUizEwBjPLoNlTRxpg()
  aHhekyqcCVXtWUizEwBjPLoNlTRxuD=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_ChannelList_Wavve()
  aHhekyqcCVXtWUizEwBjPLoNlTRxKS.extend(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
  aHhekyqcCVXtWUizEwBjPLoNlTRxuD=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_ChannelList_Tving()
  aHhekyqcCVXtWUizEwBjPLoNlTRxKS.extend(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
  aHhekyqcCVXtWUizEwBjPLoNlTRxuD=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_ChannelList_Spotv()
  aHhekyqcCVXtWUizEwBjPLoNlTRxKS.extend(aHhekyqcCVXtWUizEwBjPLoNlTRxuD)
  aHhekyqcCVXtWUizEwBjPLoNlTRxpb('1')
  for i in aHhekyqcCVXtWUizEwBjPLoNlTRxpI(aHhekyqcCVXtWUizEwBjPLoNlTRxpm(aHhekyqcCVXtWUizEwBjPLoNlTRxKS)):
   if aHhekyqcCVXtWUizEwBjPLoNlTRxKS[i]['genrenm']=='-':
    if aHhekyqcCVXtWUizEwBjPLoNlTRxKS[i]['ott']=='wavve':
     aHhekyqcCVXtWUizEwBjPLoNlTRxuv=aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.Get_ChanneGenrename_Wavve(aHhekyqcCVXtWUizEwBjPLoNlTRxKS[i]['channelid'])
     if aHhekyqcCVXtWUizEwBjPLoNlTRxuv not in aHhekyqcCVXtWUizEwBjPLoNlTRxKM:aHhekyqcCVXtWUizEwBjPLoNlTRxKM.add(aHhekyqcCVXtWUizEwBjPLoNlTRxuv)
     time.sleep(aHhekyqcCVXtWUizEwBjPLoNlTRxDJ.SLEEP_TIME)
    elif aHhekyqcCVXtWUizEwBjPLoNlTRxKS[i]['ott']=='spotv':
     aHhekyqcCVXtWUizEwBjPLoNlTRxuv='스포츠'
    else:
     aHhekyqcCVXtWUizEwBjPLoNlTRxuv='-'
    aHhekyqcCVXtWUizEwBjPLoNlTRxKS[i]['genrenm']=aHhekyqcCVXtWUizEwBjPLoNlTRxuv
   else:
    if aHhekyqcCVXtWUizEwBjPLoNlTRxKS[i]['genrenm']not in aHhekyqcCVXtWUizEwBjPLoNlTRxKM:aHhekyqcCVXtWUizEwBjPLoNlTRxKM.add(aHhekyqcCVXtWUizEwBjPLoNlTRxKS[i]['genrenm'])
  aHhekyqcCVXtWUizEwBjPLoNlTRxKM.add('-')
  aHhekyqcCVXtWUizEwBjPLoNlTRxpb('2')
  for aHhekyqcCVXtWUizEwBjPLoNlTRxKn in aHhekyqcCVXtWUizEwBjPLoNlTRxKM:
   for aHhekyqcCVXtWUizEwBjPLoNlTRxKd in aHhekyqcCVXtWUizEwBjPLoNlTRxKS:
    if aHhekyqcCVXtWUizEwBjPLoNlTRxKd['genrenm']==aHhekyqcCVXtWUizEwBjPLoNlTRxKn:
     aHhekyqcCVXtWUizEwBjPLoNlTRxKO.append(aHhekyqcCVXtWUizEwBjPLoNlTRxKd)
  for aHhekyqcCVXtWUizEwBjPLoNlTRxKd in aHhekyqcCVXtWUizEwBjPLoNlTRxKS:
   if aHhekyqcCVXtWUizEwBjPLoNlTRxKd['genrenm']not in aHhekyqcCVXtWUizEwBjPLoNlTRxKM:
    aHhekyqcCVXtWUizEwBjPLoNlTRxKf.append(aHhekyqcCVXtWUizEwBjPLoNlTRxKd)
  aHhekyqcCVXtWUizEwBjPLoNlTRxpb('3')
  aHhekyqcCVXtWUizEwBjPLoNlTRxKQ='d:\\job\\channelgenre.json'
  if os.path.isfile(aHhekyqcCVXtWUizEwBjPLoNlTRxKQ):os.remove(aHhekyqcCVXtWUizEwBjPLoNlTRxKQ)
  fp=aHhekyqcCVXtWUizEwBjPLoNlTRxpS(aHhekyqcCVXtWUizEwBjPLoNlTRxKQ,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  aHhekyqcCVXtWUizEwBjPLoNlTRxKG=aHhekyqcCVXtWUizEwBjPLoNlTRxpm(aHhekyqcCVXtWUizEwBjPLoNlTRxKO)
  i=0
  for aHhekyqcCVXtWUizEwBjPLoNlTRxDd in aHhekyqcCVXtWUizEwBjPLoNlTRxKO:
   i+=1
   aHhekyqcCVXtWUizEwBjPLoNlTRxDf =aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelid']
   aHhekyqcCVXtWUizEwBjPLoNlTRxDQ =aHhekyqcCVXtWUizEwBjPLoNlTRxDd['channelnm']
   aHhekyqcCVXtWUizEwBjPLoNlTRxpD =aHhekyqcCVXtWUizEwBjPLoNlTRxDd['ott']
   aHhekyqcCVXtWUizEwBjPLoNlTRxpu ='%s.%s'%(aHhekyqcCVXtWUizEwBjPLoNlTRxDf,aHhekyqcCVXtWUizEwBjPLoNlTRxpD)
   aHhekyqcCVXtWUizEwBjPLoNlTRxuv =aHhekyqcCVXtWUizEwBjPLoNlTRxDd['genrenm']
   aHhekyqcCVXtWUizEwBjPLoNlTRxpK='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(aHhekyqcCVXtWUizEwBjPLoNlTRxpu,aHhekyqcCVXtWUizEwBjPLoNlTRxDQ,aHhekyqcCVXtWUizEwBjPLoNlTRxuv)
   if i<aHhekyqcCVXtWUizEwBjPLoNlTRxKG:
    fp.write(aHhekyqcCVXtWUizEwBjPLoNlTRxpK+',\n')
   else:
    fp.write(aHhekyqcCVXtWUizEwBjPLoNlTRxpK+'\n')
  fp.write('}\n')
  fp.close()
  return aHhekyqcCVXtWUizEwBjPLoNlTRxKM
# Created by pyminifier (https://github.com/liftoff/pyminifier)
