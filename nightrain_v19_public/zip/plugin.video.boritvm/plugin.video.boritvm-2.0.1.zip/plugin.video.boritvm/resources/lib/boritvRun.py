__author__="NightRain"
zGOtRBvkeQhmWaLDgwlVuXiynISTPs=object
zGOtRBvkeQhmWaLDgwlVuXiynISTPf=False
zGOtRBvkeQhmWaLDgwlVuXiynISTPq=None
zGOtRBvkeQhmWaLDgwlVuXiynISTPU=True
zGOtRBvkeQhmWaLDgwlVuXiynISTPY=len
zGOtRBvkeQhmWaLDgwlVuXiynISTPx=str
zGOtRBvkeQhmWaLDgwlVuXiynISTPF=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
zGOtRBvkeQhmWaLDgwlVuXiynISTNP=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
zGOtRBvkeQhmWaLDgwlVuXiynISTNb='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
from boritvCore import*
class zGOtRBvkeQhmWaLDgwlVuXiynISTNE(zGOtRBvkeQhmWaLDgwlVuXiynISTPs):
 def __init__(zGOtRBvkeQhmWaLDgwlVuXiynISTNc,zGOtRBvkeQhmWaLDgwlVuXiynISTNC,zGOtRBvkeQhmWaLDgwlVuXiynISTNH,zGOtRBvkeQhmWaLDgwlVuXiynISTNK):
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc._addon_url =zGOtRBvkeQhmWaLDgwlVuXiynISTNC
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc._addon_handle =zGOtRBvkeQhmWaLDgwlVuXiynISTNH
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.main_params =zGOtRBvkeQhmWaLDgwlVuXiynISTNK
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_FILE_PATH ='' 
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_FILE_NAME ='' 
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVE =zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONTVING =zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONSPOTV =zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVERADIO=zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVEHOME =zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONSPOTVPAY =zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_DISPLAYNM =zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.BoritvObj =aHhekyqcCVXtWUizEwBjPLoNlTRxDu() 
 def addon_noti(zGOtRBvkeQhmWaLDgwlVuXiynISTNc,sting):
  try:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNp=xbmcgui.Dialog()
   zGOtRBvkeQhmWaLDgwlVuXiynISTNp.notification(__addonname__,sting)
  except:
   zGOtRBvkeQhmWaLDgwlVuXiynISTPq
 def addon_log(zGOtRBvkeQhmWaLDgwlVuXiynISTNc,string):
  try:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNo=string.encode('utf-8','ignore')
  except:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNo='addonException: addon_log'
  zGOtRBvkeQhmWaLDgwlVuXiynISTNr=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,zGOtRBvkeQhmWaLDgwlVuXiynISTNo),level=zGOtRBvkeQhmWaLDgwlVuXiynISTNr)
 def get_keyboard_input(zGOtRBvkeQhmWaLDgwlVuXiynISTNc,zGOtRBvkeQhmWaLDgwlVuXiynISTNf):
  zGOtRBvkeQhmWaLDgwlVuXiynISTNd=zGOtRBvkeQhmWaLDgwlVuXiynISTPq
  kb=xbmc.Keyboard()
  kb.setHeading(zGOtRBvkeQhmWaLDgwlVuXiynISTNf)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   zGOtRBvkeQhmWaLDgwlVuXiynISTNd=kb.getText()
  return zGOtRBvkeQhmWaLDgwlVuXiynISTNd
 def add_dir(zGOtRBvkeQhmWaLDgwlVuXiynISTNc,label,sublabel='',img='',infoLabels=zGOtRBvkeQhmWaLDgwlVuXiynISTPq,isFolder=zGOtRBvkeQhmWaLDgwlVuXiynISTPU,params=''):
  zGOtRBvkeQhmWaLDgwlVuXiynISTNs='%s?%s'%(zGOtRBvkeQhmWaLDgwlVuXiynISTNc._addon_url,urllib.parse.urlencode(params))
  if sublabel:zGOtRBvkeQhmWaLDgwlVuXiynISTNf='%s < %s >'%(label,sublabel)
  else: zGOtRBvkeQhmWaLDgwlVuXiynISTNf=label
  if not img:img='DefaultFolder.png'
  zGOtRBvkeQhmWaLDgwlVuXiynISTNq=xbmcgui.ListItem(zGOtRBvkeQhmWaLDgwlVuXiynISTNf)
  zGOtRBvkeQhmWaLDgwlVuXiynISTNq.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:zGOtRBvkeQhmWaLDgwlVuXiynISTNq.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:zGOtRBvkeQhmWaLDgwlVuXiynISTNq.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(zGOtRBvkeQhmWaLDgwlVuXiynISTNc._addon_handle,zGOtRBvkeQhmWaLDgwlVuXiynISTNs,zGOtRBvkeQhmWaLDgwlVuXiynISTNq,isFolder)
 def make_M3u_Filename(zGOtRBvkeQhmWaLDgwlVuXiynISTNc):
  return zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_FILE_PATH+zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(zGOtRBvkeQhmWaLDgwlVuXiynISTNc):
  return zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_FILE_PATH+zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_FILE_NAME+'.xml'
 def dp_Main_List(zGOtRBvkeQhmWaLDgwlVuXiynISTNc):
  for zGOtRBvkeQhmWaLDgwlVuXiynISTNU in zGOtRBvkeQhmWaLDgwlVuXiynISTNP:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNf=zGOtRBvkeQhmWaLDgwlVuXiynISTNU.get('title')
   zGOtRBvkeQhmWaLDgwlVuXiynISTNY={'mode':zGOtRBvkeQhmWaLDgwlVuXiynISTNU.get('mode'),'sType':zGOtRBvkeQhmWaLDgwlVuXiynISTNU.get('sType'),'sName':zGOtRBvkeQhmWaLDgwlVuXiynISTNU.get('sName')}
   if zGOtRBvkeQhmWaLDgwlVuXiynISTNU.get('mode')=='XXX':
    zGOtRBvkeQhmWaLDgwlVuXiynISTNx=zGOtRBvkeQhmWaLDgwlVuXiynISTPf
   else:
    zGOtRBvkeQhmWaLDgwlVuXiynISTNx=zGOtRBvkeQhmWaLDgwlVuXiynISTPU
   zGOtRBvkeQhmWaLDgwlVuXiynISTNF=zGOtRBvkeQhmWaLDgwlVuXiynISTPU
   if zGOtRBvkeQhmWaLDgwlVuXiynISTNU.get('mode')=='ADD_M3U':
    if zGOtRBvkeQhmWaLDgwlVuXiynISTNU.get('sType')=='wavve' and zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVE==zGOtRBvkeQhmWaLDgwlVuXiynISTPf:zGOtRBvkeQhmWaLDgwlVuXiynISTNF=zGOtRBvkeQhmWaLDgwlVuXiynISTPf
    if zGOtRBvkeQhmWaLDgwlVuXiynISTNU.get('sType')=='tving' and zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONTVING==zGOtRBvkeQhmWaLDgwlVuXiynISTPf:zGOtRBvkeQhmWaLDgwlVuXiynISTNF=zGOtRBvkeQhmWaLDgwlVuXiynISTPf
    if zGOtRBvkeQhmWaLDgwlVuXiynISTNU.get('sType')=='spotv' and zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONSPOTV==zGOtRBvkeQhmWaLDgwlVuXiynISTPf:zGOtRBvkeQhmWaLDgwlVuXiynISTNF=zGOtRBvkeQhmWaLDgwlVuXiynISTPf
   if zGOtRBvkeQhmWaLDgwlVuXiynISTNF==zGOtRBvkeQhmWaLDgwlVuXiynISTPU:
    zGOtRBvkeQhmWaLDgwlVuXiynISTNc.add_dir(zGOtRBvkeQhmWaLDgwlVuXiynISTNf,sublabel='',img='',infoLabels=zGOtRBvkeQhmWaLDgwlVuXiynISTPq,isFolder=zGOtRBvkeQhmWaLDgwlVuXiynISTNx,params=zGOtRBvkeQhmWaLDgwlVuXiynISTNY)
  if zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTNP)>0:xbmcplugin.endOfDirectory(zGOtRBvkeQhmWaLDgwlVuXiynISTNc._addon_handle,cacheToDisc=zGOtRBvkeQhmWaLDgwlVuXiynISTPU)
 def dp_Delete_M3u(zGOtRBvkeQhmWaLDgwlVuXiynISTNc,args):
  zGOtRBvkeQhmWaLDgwlVuXiynISTNp=xbmcgui.Dialog()
  zGOtRBvkeQhmWaLDgwlVuXiynISTNJ=zGOtRBvkeQhmWaLDgwlVuXiynISTNp.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if zGOtRBvkeQhmWaLDgwlVuXiynISTNJ==zGOtRBvkeQhmWaLDgwlVuXiynISTPf:sys.exit()
  zGOtRBvkeQhmWaLDgwlVuXiynISTNA=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.make_M3u_Filename()
  if os.path.isfile(zGOtRBvkeQhmWaLDgwlVuXiynISTNA):os.remove(zGOtRBvkeQhmWaLDgwlVuXiynISTNA)
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(zGOtRBvkeQhmWaLDgwlVuXiynISTNc,args):
  zGOtRBvkeQhmWaLDgwlVuXiynISTEN=args.get('sType')
  zGOtRBvkeQhmWaLDgwlVuXiynISTEP=args.get('sName')
  zGOtRBvkeQhmWaLDgwlVuXiynISTNp=xbmcgui.Dialog()
  zGOtRBvkeQhmWaLDgwlVuXiynISTNJ=zGOtRBvkeQhmWaLDgwlVuXiynISTNp.yesno((zGOtRBvkeQhmWaLDgwlVuXiynISTEP+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if zGOtRBvkeQhmWaLDgwlVuXiynISTNJ==zGOtRBvkeQhmWaLDgwlVuXiynISTPf:sys.exit()
  zGOtRBvkeQhmWaLDgwlVuXiynISTEb =[]
  zGOtRBvkeQhmWaLDgwlVuXiynISTEc =[]
  zGOtRBvkeQhmWaLDgwlVuXiynISTEC=[]
  if zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='all':
   zGOtRBvkeQhmWaLDgwlVuXiynISTNA=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.make_M3u_Filename()
   if os.path.isfile(zGOtRBvkeQhmWaLDgwlVuXiynISTNA):os.remove(zGOtRBvkeQhmWaLDgwlVuXiynISTNA)
  if(zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='wavve' or zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='all')and zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVE:
   zGOtRBvkeQhmWaLDgwlVuXiynISTEH=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.BoritvObj.Get_ChannelList_Wavve(exceptGroup=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.make_EexceptGroup_Wavve())
   if zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTEH)!=0:zGOtRBvkeQhmWaLDgwlVuXiynISTEb.extend(zGOtRBvkeQhmWaLDgwlVuXiynISTEH)
   zGOtRBvkeQhmWaLDgwlVuXiynISTEC=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.get_radio_list()
   zGOtRBvkeQhmWaLDgwlVuXiynISTNc.addon_log('wavve cnt ----> '+zGOtRBvkeQhmWaLDgwlVuXiynISTPx(zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTEH)))
  if(zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='tving' or zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='all')and zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONTVING:
   zGOtRBvkeQhmWaLDgwlVuXiynISTEH=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.BoritvObj.Get_ChannelList_Tving()
   if zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTEH)!=0:zGOtRBvkeQhmWaLDgwlVuXiynISTEb.extend(zGOtRBvkeQhmWaLDgwlVuXiynISTEH)
   zGOtRBvkeQhmWaLDgwlVuXiynISTNc.addon_log('tving cnt ----> '+zGOtRBvkeQhmWaLDgwlVuXiynISTPx(zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTEH)))
  if(zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='spotv' or zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='all')and zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONSPOTV:
   zGOtRBvkeQhmWaLDgwlVuXiynISTEH=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.BoritvObj.Get_ChannelList_Spotv(payyn=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONSPOTVPAY)
   if zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTEH)!=0:zGOtRBvkeQhmWaLDgwlVuXiynISTEb.extend(zGOtRBvkeQhmWaLDgwlVuXiynISTEH)
   zGOtRBvkeQhmWaLDgwlVuXiynISTNc.addon_log('spotv cnt ----> '+zGOtRBvkeQhmWaLDgwlVuXiynISTPx(zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTEH)))
  if zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTEb)==0:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNc.addon_noti(__language__(30909).encode('utf8'))
   return
  for zGOtRBvkeQhmWaLDgwlVuXiynISTEK in zGOtRBvkeQhmWaLDgwlVuXiynISTNc.BoritvObj.INIT_GENRESORT:
   for zGOtRBvkeQhmWaLDgwlVuXiynISTEj in zGOtRBvkeQhmWaLDgwlVuXiynISTEb:
    if zGOtRBvkeQhmWaLDgwlVuXiynISTEj['genrenm']==zGOtRBvkeQhmWaLDgwlVuXiynISTEK:
     zGOtRBvkeQhmWaLDgwlVuXiynISTEc.append(zGOtRBvkeQhmWaLDgwlVuXiynISTEj)
  for zGOtRBvkeQhmWaLDgwlVuXiynISTEj in zGOtRBvkeQhmWaLDgwlVuXiynISTEb:
   if zGOtRBvkeQhmWaLDgwlVuXiynISTEj['genrenm']not in zGOtRBvkeQhmWaLDgwlVuXiynISTNc.BoritvObj.INIT_GENRESORT:
    zGOtRBvkeQhmWaLDgwlVuXiynISTEc.append(zGOtRBvkeQhmWaLDgwlVuXiynISTEj)
  try:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNA=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.make_M3u_Filename()
   if os.path.isfile(zGOtRBvkeQhmWaLDgwlVuXiynISTNA):
    fp=zGOtRBvkeQhmWaLDgwlVuXiynISTPF(zGOtRBvkeQhmWaLDgwlVuXiynISTNA,'a',-1,'utf-8')
   else:
    fp=zGOtRBvkeQhmWaLDgwlVuXiynISTPF(zGOtRBvkeQhmWaLDgwlVuXiynISTNA,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for zGOtRBvkeQhmWaLDgwlVuXiynISTEp in zGOtRBvkeQhmWaLDgwlVuXiynISTEc:
    zGOtRBvkeQhmWaLDgwlVuXiynISTEo =zGOtRBvkeQhmWaLDgwlVuXiynISTEp['channelid']
    zGOtRBvkeQhmWaLDgwlVuXiynISTEr =zGOtRBvkeQhmWaLDgwlVuXiynISTEp['channelnm']
    zGOtRBvkeQhmWaLDgwlVuXiynISTEd=zGOtRBvkeQhmWaLDgwlVuXiynISTEp['channelimg']
    zGOtRBvkeQhmWaLDgwlVuXiynISTEs =zGOtRBvkeQhmWaLDgwlVuXiynISTEp['ott']
    zGOtRBvkeQhmWaLDgwlVuXiynISTEf ='%s.%s'%(zGOtRBvkeQhmWaLDgwlVuXiynISTEo,zGOtRBvkeQhmWaLDgwlVuXiynISTEs)
    zGOtRBvkeQhmWaLDgwlVuXiynISTEq=zGOtRBvkeQhmWaLDgwlVuXiynISTEp['genrenm']
    if zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_DISPLAYNM:
     zGOtRBvkeQhmWaLDgwlVuXiynISTEr='%s (%s)'%(zGOtRBvkeQhmWaLDgwlVuXiynISTEr,zGOtRBvkeQhmWaLDgwlVuXiynISTEs)
    if zGOtRBvkeQhmWaLDgwlVuXiynISTEo in zGOtRBvkeQhmWaLDgwlVuXiynISTEC:
     zGOtRBvkeQhmWaLDgwlVuXiynISTEU='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(zGOtRBvkeQhmWaLDgwlVuXiynISTEf,zGOtRBvkeQhmWaLDgwlVuXiynISTEr,zGOtRBvkeQhmWaLDgwlVuXiynISTEq,zGOtRBvkeQhmWaLDgwlVuXiynISTEd,zGOtRBvkeQhmWaLDgwlVuXiynISTEr)
    else:
     zGOtRBvkeQhmWaLDgwlVuXiynISTEU='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(zGOtRBvkeQhmWaLDgwlVuXiynISTEf,zGOtRBvkeQhmWaLDgwlVuXiynISTEr,zGOtRBvkeQhmWaLDgwlVuXiynISTEq,zGOtRBvkeQhmWaLDgwlVuXiynISTEd,zGOtRBvkeQhmWaLDgwlVuXiynISTEr)
    if zGOtRBvkeQhmWaLDgwlVuXiynISTEs=='wavve':
     zGOtRBvkeQhmWaLDgwlVuXiynISTEY ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(zGOtRBvkeQhmWaLDgwlVuXiynISTEo)
    elif zGOtRBvkeQhmWaLDgwlVuXiynISTEs=='tving':
     zGOtRBvkeQhmWaLDgwlVuXiynISTEY ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(zGOtRBvkeQhmWaLDgwlVuXiynISTEo)
    elif zGOtRBvkeQhmWaLDgwlVuXiynISTEs=='spotv':
     zGOtRBvkeQhmWaLDgwlVuXiynISTEY ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(zGOtRBvkeQhmWaLDgwlVuXiynISTEo)
    fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTEU)
    fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTEY)
   fp.close()
  except:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNc.addon_noti(__language__(30910).encode('utf8'))
   return
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.addon_noti((zGOtRBvkeQhmWaLDgwlVuXiynISTEP+' '+__language__(30908)).encode('utf8'))
 def dp_Make_Epg(zGOtRBvkeQhmWaLDgwlVuXiynISTNc,args):
  zGOtRBvkeQhmWaLDgwlVuXiynISTEN=args.get('sType')
  zGOtRBvkeQhmWaLDgwlVuXiynISTEP=args.get('sName')
  zGOtRBvkeQhmWaLDgwlVuXiynISTNp=xbmcgui.Dialog()
  zGOtRBvkeQhmWaLDgwlVuXiynISTNJ=zGOtRBvkeQhmWaLDgwlVuXiynISTNp.yesno((zGOtRBvkeQhmWaLDgwlVuXiynISTEP+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
  if zGOtRBvkeQhmWaLDgwlVuXiynISTNJ==zGOtRBvkeQhmWaLDgwlVuXiynISTPf:sys.exit()
  zGOtRBvkeQhmWaLDgwlVuXiynISTEx=[]
  zGOtRBvkeQhmWaLDgwlVuXiynISTEF=[]
  if(zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='wavve' or zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='all')and zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVE:
   zGOtRBvkeQhmWaLDgwlVuXiynISTEM,zGOtRBvkeQhmWaLDgwlVuXiynISTEJ=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.make_EexceptGroup_Wavve())
   if zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTEJ)!=0:
    zGOtRBvkeQhmWaLDgwlVuXiynISTEx.extend(zGOtRBvkeQhmWaLDgwlVuXiynISTEM)
    zGOtRBvkeQhmWaLDgwlVuXiynISTEF.extend(zGOtRBvkeQhmWaLDgwlVuXiynISTEJ)
  if(zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='tving' or zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='all')and zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONTVING:
   zGOtRBvkeQhmWaLDgwlVuXiynISTEM,zGOtRBvkeQhmWaLDgwlVuXiynISTEJ=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.BoritvObj.Get_EpgInfo_Tving()
   if zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTEJ)!=0:
    zGOtRBvkeQhmWaLDgwlVuXiynISTEx.extend(zGOtRBvkeQhmWaLDgwlVuXiynISTEM)
    zGOtRBvkeQhmWaLDgwlVuXiynISTEF.extend(zGOtRBvkeQhmWaLDgwlVuXiynISTEJ)
  if(zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='spotv' or zGOtRBvkeQhmWaLDgwlVuXiynISTEN=='all')and zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONSPOTV:
   zGOtRBvkeQhmWaLDgwlVuXiynISTEM,zGOtRBvkeQhmWaLDgwlVuXiynISTEJ=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.BoritvObj.Get_EpgInfo_Spotv(payyn=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONSPOTVPAY)
   if zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTEJ)!=0:
    zGOtRBvkeQhmWaLDgwlVuXiynISTEx.extend(zGOtRBvkeQhmWaLDgwlVuXiynISTEM)
    zGOtRBvkeQhmWaLDgwlVuXiynISTEF.extend(zGOtRBvkeQhmWaLDgwlVuXiynISTEJ)
  if zGOtRBvkeQhmWaLDgwlVuXiynISTPY(zGOtRBvkeQhmWaLDgwlVuXiynISTEF)==0:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNc.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNA=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.make_Epg_Filename()
   fp=zGOtRBvkeQhmWaLDgwlVuXiynISTPF(zGOtRBvkeQhmWaLDgwlVuXiynISTNA,'w',-1,'utf-8')
   zGOtRBvkeQhmWaLDgwlVuXiynISTEA='<?xml version="1.0" encoding="UTF-8"?>\n'
   zGOtRBvkeQhmWaLDgwlVuXiynISTPN='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   zGOtRBvkeQhmWaLDgwlVuXiynISTPE='<tv generator-info-name="boritv_epg">\n\n'
   zGOtRBvkeQhmWaLDgwlVuXiynISTPb='\n</tv>\n'
   fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTEA)
   fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTPN)
   fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTPE)
   for zGOtRBvkeQhmWaLDgwlVuXiynISTPc in zGOtRBvkeQhmWaLDgwlVuXiynISTEx:
    zGOtRBvkeQhmWaLDgwlVuXiynISTPC='  <channel id="%s.%s">\n' %(zGOtRBvkeQhmWaLDgwlVuXiynISTPc.get('channelid'),zGOtRBvkeQhmWaLDgwlVuXiynISTPc.get('ott'))
    zGOtRBvkeQhmWaLDgwlVuXiynISTPH='    <display-name>%s</display-name>\n'%(zGOtRBvkeQhmWaLDgwlVuXiynISTPc.get('channelnm'))
    zGOtRBvkeQhmWaLDgwlVuXiynISTPK='    <icon src="%s" />\n' %(zGOtRBvkeQhmWaLDgwlVuXiynISTPc.get('channelimg'))
    zGOtRBvkeQhmWaLDgwlVuXiynISTPj='  </channel>\n\n'
    fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTPC)
    fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTPH)
    fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTPK)
    fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTPj)
   for zGOtRBvkeQhmWaLDgwlVuXiynISTPc in zGOtRBvkeQhmWaLDgwlVuXiynISTEF:
    zGOtRBvkeQhmWaLDgwlVuXiynISTPC='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(zGOtRBvkeQhmWaLDgwlVuXiynISTPc.get('startTime'),zGOtRBvkeQhmWaLDgwlVuXiynISTPc.get('endTime'),zGOtRBvkeQhmWaLDgwlVuXiynISTPc.get('channelid'),zGOtRBvkeQhmWaLDgwlVuXiynISTPc.get('ott'))
    zGOtRBvkeQhmWaLDgwlVuXiynISTPH='    <title lang="kr">%s</title>\n' %(zGOtRBvkeQhmWaLDgwlVuXiynISTPc.get('title'))
    zGOtRBvkeQhmWaLDgwlVuXiynISTPK='  </programme>\n\n'
    fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTPC)
    fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTPH)
    fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTPK)
   fp.write(zGOtRBvkeQhmWaLDgwlVuXiynISTPb)
   fp.close()
  except:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNc.addon_noti(__language__(30910).encode('utf8'))
   return
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.addon_noti((zGOtRBvkeQhmWaLDgwlVuXiynISTEP+' '+__language__(30912)).encode('utf8'))
 def make_EexceptGroup_Wavve(zGOtRBvkeQhmWaLDgwlVuXiynISTNc):
  zGOtRBvkeQhmWaLDgwlVuXiynISTPp=[]
  if zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVERADIO==zGOtRBvkeQhmWaLDgwlVuXiynISTPf:
   zGOtRBvkeQhmWaLDgwlVuXiynISTPo={'broadcastid':'46584','genre':'10'}
   zGOtRBvkeQhmWaLDgwlVuXiynISTPp.append(zGOtRBvkeQhmWaLDgwlVuXiynISTPo)
  if zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVEHOME==zGOtRBvkeQhmWaLDgwlVuXiynISTPf:
   zGOtRBvkeQhmWaLDgwlVuXiynISTPo={'broadcastid':'46584','genre':'03'}
   zGOtRBvkeQhmWaLDgwlVuXiynISTPp.append(zGOtRBvkeQhmWaLDgwlVuXiynISTPo)
  return zGOtRBvkeQhmWaLDgwlVuXiynISTPp
 def get_radio_list(zGOtRBvkeQhmWaLDgwlVuXiynISTNc):
  if zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVERADIO==zGOtRBvkeQhmWaLDgwlVuXiynISTPf:return[]
  zGOtRBvkeQhmWaLDgwlVuXiynISTPo=[{'broadcastid':'46584','genre':'10'}]
  return zGOtRBvkeQhmWaLDgwlVuXiynISTNc.BoritvObj.Get_ChannelList_WavveExcept(zGOtRBvkeQhmWaLDgwlVuXiynISTPo)
 def check_config(zGOtRBvkeQhmWaLDgwlVuXiynISTNc):
  zGOtRBvkeQhmWaLDgwlVuXiynISTPr=zGOtRBvkeQhmWaLDgwlVuXiynISTPU
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVE =zGOtRBvkeQhmWaLDgwlVuXiynISTPU if __addon__.getSetting('onWavve')=='true' else zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONTVING =zGOtRBvkeQhmWaLDgwlVuXiynISTPU if __addon__.getSetting('onTvng')=='true' else zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONSPOTV =zGOtRBvkeQhmWaLDgwlVuXiynISTPU if __addon__.getSetting('onSpotv')=='true' else zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVERADIO=zGOtRBvkeQhmWaLDgwlVuXiynISTPU if __addon__.getSetting('onWavveRadio')=='true' else zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVEHOME =zGOtRBvkeQhmWaLDgwlVuXiynISTPU if __addon__.getSetting('onWavveHome')=='true' else zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONSPOTVPAY =zGOtRBvkeQhmWaLDgwlVuXiynISTPU if __addon__.getSetting('onSpotvPay')=='true' else zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_DISPLAYNM =zGOtRBvkeQhmWaLDgwlVuXiynISTPU if __addon__.getSetting('displayOTTnm')=='true' else zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  if zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_FILE_PATH=='' or zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_FILE_NAME=='':zGOtRBvkeQhmWaLDgwlVuXiynISTPr=zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  if zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONWAVVE==zGOtRBvkeQhmWaLDgwlVuXiynISTPf and zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONTVING=='' and zGOtRBvkeQhmWaLDgwlVuXiynISTNc.M3U_ONSPOTV=='':zGOtRBvkeQhmWaLDgwlVuXiynISTPr=zGOtRBvkeQhmWaLDgwlVuXiynISTPf
  if zGOtRBvkeQhmWaLDgwlVuXiynISTPr==zGOtRBvkeQhmWaLDgwlVuXiynISTPf:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNp=xbmcgui.Dialog()
   zGOtRBvkeQhmWaLDgwlVuXiynISTNJ=zGOtRBvkeQhmWaLDgwlVuXiynISTNp.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if zGOtRBvkeQhmWaLDgwlVuXiynISTNJ==zGOtRBvkeQhmWaLDgwlVuXiynISTPU:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def boritv_main(zGOtRBvkeQhmWaLDgwlVuXiynISTNc):
  zGOtRBvkeQhmWaLDgwlVuXiynISTPd=zGOtRBvkeQhmWaLDgwlVuXiynISTNc.main_params.get('mode',zGOtRBvkeQhmWaLDgwlVuXiynISTPq)
  zGOtRBvkeQhmWaLDgwlVuXiynISTNc.check_config()
  if zGOtRBvkeQhmWaLDgwlVuXiynISTPd is zGOtRBvkeQhmWaLDgwlVuXiynISTPq:
   zGOtRBvkeQhmWaLDgwlVuXiynISTNc.dp_Main_List()
  elif zGOtRBvkeQhmWaLDgwlVuXiynISTPd=='DEL_M3U':
   zGOtRBvkeQhmWaLDgwlVuXiynISTNc.dp_Delete_M3u(zGOtRBvkeQhmWaLDgwlVuXiynISTNc.main_params)
  elif zGOtRBvkeQhmWaLDgwlVuXiynISTPd=='ADD_M3U':
   zGOtRBvkeQhmWaLDgwlVuXiynISTNc.dp_MakeAdd_M3u(zGOtRBvkeQhmWaLDgwlVuXiynISTNc.main_params)
  elif zGOtRBvkeQhmWaLDgwlVuXiynISTPd=='ADD_EPG':
   zGOtRBvkeQhmWaLDgwlVuXiynISTNc.dp_Make_Epg(zGOtRBvkeQhmWaLDgwlVuXiynISTNc.main_params)
  else:
   zGOtRBvkeQhmWaLDgwlVuXiynISTPq
# Created by pyminifier (https://github.com/liftoff/pyminifier)
