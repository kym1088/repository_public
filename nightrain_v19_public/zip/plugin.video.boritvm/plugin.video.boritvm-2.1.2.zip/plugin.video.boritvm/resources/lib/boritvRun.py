__author__="NightRain"
fcONhsiAYRmXPHbpkWtyLGaJdxjBwI=object
fcONhsiAYRmXPHbpkWtyLGaJdxjBwS=False
fcONhsiAYRmXPHbpkWtyLGaJdxjBwr=None
fcONhsiAYRmXPHbpkWtyLGaJdxjBwv=True
fcONhsiAYRmXPHbpkWtyLGaJdxjBVE=len
fcONhsiAYRmXPHbpkWtyLGaJdxjBVl=str
fcONhsiAYRmXPHbpkWtyLGaJdxjBVw=open
fcONhsiAYRmXPHbpkWtyLGaJdxjBVU=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
fcONhsiAYRmXPHbpkWtyLGaJdxjBEw=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
fcONhsiAYRmXPHbpkWtyLGaJdxjBEV=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class fcONhsiAYRmXPHbpkWtyLGaJdxjBEl(fcONhsiAYRmXPHbpkWtyLGaJdxjBwI):
 def __init__(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU,fcONhsiAYRmXPHbpkWtyLGaJdxjBEg,fcONhsiAYRmXPHbpkWtyLGaJdxjBEo,fcONhsiAYRmXPHbpkWtyLGaJdxjBEq):
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU._addon_url =fcONhsiAYRmXPHbpkWtyLGaJdxjBEg
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU._addon_handle =fcONhsiAYRmXPHbpkWtyLGaJdxjBEo
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.main_params =fcONhsiAYRmXPHbpkWtyLGaJdxjBEq
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_FILE_PATH ='' 
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_FILE_NAME ='' 
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVE =fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONTVING =fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONSPOTV =fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVERADIO=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVEHOME =fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONRELIGION =fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONSPOTVPAY =fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_DISPLAYNM =fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_AUTORESTART =fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.BoritvObj =GrMLvOEahPmgyJcjdkiYTBAFNbxtul() 
 def addon_noti(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU,sting):
  try:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEu=xbmcgui.Dialog()
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEu.notification(__addonname__,sting)
  except:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwr
 def addon_log(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU,string):
  try:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEz=string.encode('utf-8','ignore')
  except:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEz='addonException: addon_log'
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEC=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,fcONhsiAYRmXPHbpkWtyLGaJdxjBEz),level=fcONhsiAYRmXPHbpkWtyLGaJdxjBEC)
 def get_keyboard_input(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU,fcONhsiAYRmXPHbpkWtyLGaJdxjBEF):
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEQ=fcONhsiAYRmXPHbpkWtyLGaJdxjBwr
  kb=xbmc.Keyboard()
  kb.setHeading(fcONhsiAYRmXPHbpkWtyLGaJdxjBEF)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEQ=kb.getText()
  return fcONhsiAYRmXPHbpkWtyLGaJdxjBEQ
 def add_dir(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU,label,sublabel='',img='',infoLabels=fcONhsiAYRmXPHbpkWtyLGaJdxjBwr,isFolder=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv,params='',isLink=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS,ContextMenu=fcONhsiAYRmXPHbpkWtyLGaJdxjBwr):
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEK='%s?%s'%(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU._addon_url,urllib.parse.urlencode(params))
  if sublabel:fcONhsiAYRmXPHbpkWtyLGaJdxjBEF='%s < %s >'%(label,sublabel)
  else: fcONhsiAYRmXPHbpkWtyLGaJdxjBEF=label
  if not img:img='DefaultFolder.png'
  fcONhsiAYRmXPHbpkWtyLGaJdxjBED=xbmcgui.ListItem(fcONhsiAYRmXPHbpkWtyLGaJdxjBEF)
  fcONhsiAYRmXPHbpkWtyLGaJdxjBED.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:fcONhsiAYRmXPHbpkWtyLGaJdxjBED.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBED.setProperty('IsPlayable','true')
  if ContextMenu:fcONhsiAYRmXPHbpkWtyLGaJdxjBED.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU._addon_handle,fcONhsiAYRmXPHbpkWtyLGaJdxjBEK,fcONhsiAYRmXPHbpkWtyLGaJdxjBED,isFolder)
 def make_M3u_Filename(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU,tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_FILE_PATH+fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU,tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_FILE_PATH+fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_FILE_NAME+'.xml'
 def dp_Main_List(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU):
  for fcONhsiAYRmXPHbpkWtyLGaJdxjBEM in fcONhsiAYRmXPHbpkWtyLGaJdxjBEw:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEF=fcONhsiAYRmXPHbpkWtyLGaJdxjBEM.get('title')
   fcONhsiAYRmXPHbpkWtyLGaJdxjBET=''
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEn={'mode':fcONhsiAYRmXPHbpkWtyLGaJdxjBEM.get('mode'),'sType':fcONhsiAYRmXPHbpkWtyLGaJdxjBEM.get('sType'),'sName':fcONhsiAYRmXPHbpkWtyLGaJdxjBEM.get('sName')}
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBEM.get('mode')=='XXX':
    fcONhsiAYRmXPHbpkWtyLGaJdxjBEI=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
    fcONhsiAYRmXPHbpkWtyLGaJdxjBES =fcONhsiAYRmXPHbpkWtyLGaJdxjBwv
   else:
    fcONhsiAYRmXPHbpkWtyLGaJdxjBEI=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv
    fcONhsiAYRmXPHbpkWtyLGaJdxjBES =fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEr=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBEM.get('mode')=='ADD_M3U':
    if fcONhsiAYRmXPHbpkWtyLGaJdxjBEM.get('sType')=='wavve' and fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVE==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:fcONhsiAYRmXPHbpkWtyLGaJdxjBEr=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
    if fcONhsiAYRmXPHbpkWtyLGaJdxjBEM.get('sType')=='tving' and fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONTVING==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:fcONhsiAYRmXPHbpkWtyLGaJdxjBEr=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
    if fcONhsiAYRmXPHbpkWtyLGaJdxjBEM.get('sType')=='spotv' and fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONSPOTV==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:fcONhsiAYRmXPHbpkWtyLGaJdxjBEr=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBEr==fcONhsiAYRmXPHbpkWtyLGaJdxjBwv:
    if 'icon' in fcONhsiAYRmXPHbpkWtyLGaJdxjBEM:fcONhsiAYRmXPHbpkWtyLGaJdxjBET=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',fcONhsiAYRmXPHbpkWtyLGaJdxjBEM.get('icon')) 
    fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.add_dir(fcONhsiAYRmXPHbpkWtyLGaJdxjBEF,sublabel='',img=fcONhsiAYRmXPHbpkWtyLGaJdxjBET,infoLabels=fcONhsiAYRmXPHbpkWtyLGaJdxjBwr,isFolder=fcONhsiAYRmXPHbpkWtyLGaJdxjBEI,params=fcONhsiAYRmXPHbpkWtyLGaJdxjBEn,isLink=fcONhsiAYRmXPHbpkWtyLGaJdxjBES)
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBEw)>0:xbmcplugin.endOfDirectory(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU._addon_handle,cacheToDisc=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv)
 def dp_Delete_M3u(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU,args):
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEu=xbmcgui.Dialog()
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlE=fcONhsiAYRmXPHbpkWtyLGaJdxjBEu.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBlE==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:sys.exit()
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlw=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_M3u_Filename(tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS)
  if xbmcvfs.exists(fcONhsiAYRmXPHbpkWtyLGaJdxjBlw):
   if xbmcvfs.delete(fcONhsiAYRmXPHbpkWtyLGaJdxjBlw)==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:
    fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_noti(__language__(30910).encode('utf-8'))
    return
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU,args):
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=args.get('sType')
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlU=args.get('sName')
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEu=xbmcgui.Dialog()
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlE=fcONhsiAYRmXPHbpkWtyLGaJdxjBEu.yesno((fcONhsiAYRmXPHbpkWtyLGaJdxjBlU+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBlE==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:sys.exit()
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlg =[]
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlo =[]
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlw=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_M3u_Filename(tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv)
  if os.path.isfile(fcONhsiAYRmXPHbpkWtyLGaJdxjBlw):os.remove(fcONhsiAYRmXPHbpkWtyLGaJdxjBlw)
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='all':
   fcONhsiAYRmXPHbpkWtyLGaJdxjBlw=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_M3u_Filename(tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS)
   if xbmcvfs.exists(fcONhsiAYRmXPHbpkWtyLGaJdxjBlw):
    if xbmcvfs.delete(fcONhsiAYRmXPHbpkWtyLGaJdxjBlw)==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:
     fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBlq=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_M3u_Filename(tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS)
   if xbmcvfs.exists(fcONhsiAYRmXPHbpkWtyLGaJdxjBlq):
    fcONhsiAYRmXPHbpkWtyLGaJdxjBle=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_M3u_Filename(tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv)
    xbmcvfs.copy(fcONhsiAYRmXPHbpkWtyLGaJdxjBlq,fcONhsiAYRmXPHbpkWtyLGaJdxjBle)
  if(fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='wavve' or fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='all')and fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVE:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBlu=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.BoritvObj.Get_ChannelList_Wavve(exceptGroup=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_EexceptGroup_Wavve())
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBlu)!=0:fcONhsiAYRmXPHbpkWtyLGaJdxjBlg.extend(fcONhsiAYRmXPHbpkWtyLGaJdxjBlu)
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_log('wavve cnt ----> '+fcONhsiAYRmXPHbpkWtyLGaJdxjBVl(fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBlu)))
  if(fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='tving' or fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='all')and fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONTVING:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBlu=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.BoritvObj.Get_ChannelList_Tving()
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBlu)!=0:fcONhsiAYRmXPHbpkWtyLGaJdxjBlg.extend(fcONhsiAYRmXPHbpkWtyLGaJdxjBlu)
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_log('tving cnt ----> '+fcONhsiAYRmXPHbpkWtyLGaJdxjBVl(fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBlu)))
  if(fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='spotv' or fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='all')and fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONSPOTV:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBlu=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.BoritvObj.Get_ChannelList_Spotv(payyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONSPOTVPAY)
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBlu)!=0:fcONhsiAYRmXPHbpkWtyLGaJdxjBlg.extend(fcONhsiAYRmXPHbpkWtyLGaJdxjBlu)
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_log('spotv cnt ----> '+fcONhsiAYRmXPHbpkWtyLGaJdxjBVl(fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBlu)))
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBlg)==0:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_noti(__language__(30909).encode('utf8'))
   return
  for fcONhsiAYRmXPHbpkWtyLGaJdxjBlz in fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.BoritvObj.INIT_GENRESORT:
   for fcONhsiAYRmXPHbpkWtyLGaJdxjBlC in fcONhsiAYRmXPHbpkWtyLGaJdxjBlg:
    if fcONhsiAYRmXPHbpkWtyLGaJdxjBlC['genrenm']==fcONhsiAYRmXPHbpkWtyLGaJdxjBlz:
     fcONhsiAYRmXPHbpkWtyLGaJdxjBlo.append(fcONhsiAYRmXPHbpkWtyLGaJdxjBlC)
  for fcONhsiAYRmXPHbpkWtyLGaJdxjBlC in fcONhsiAYRmXPHbpkWtyLGaJdxjBlg:
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBlC['genrenm']not in fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.BoritvObj.INIT_GENRESORT:
    fcONhsiAYRmXPHbpkWtyLGaJdxjBlo.append(fcONhsiAYRmXPHbpkWtyLGaJdxjBlC)
  try:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBlw=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_M3u_Filename(tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv)
   if os.path.isfile(fcONhsiAYRmXPHbpkWtyLGaJdxjBlw):
    fp=fcONhsiAYRmXPHbpkWtyLGaJdxjBVw(fcONhsiAYRmXPHbpkWtyLGaJdxjBlw,'a',-1,'utf-8')
   else:
    fp=fcONhsiAYRmXPHbpkWtyLGaJdxjBVw(fcONhsiAYRmXPHbpkWtyLGaJdxjBlw,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for fcONhsiAYRmXPHbpkWtyLGaJdxjBlQ in fcONhsiAYRmXPHbpkWtyLGaJdxjBlo:
    fcONhsiAYRmXPHbpkWtyLGaJdxjBlK =fcONhsiAYRmXPHbpkWtyLGaJdxjBlQ['channelid']
    fcONhsiAYRmXPHbpkWtyLGaJdxjBlF =fcONhsiAYRmXPHbpkWtyLGaJdxjBlQ['channelnm']
    fcONhsiAYRmXPHbpkWtyLGaJdxjBlD=fcONhsiAYRmXPHbpkWtyLGaJdxjBlQ['channelimg']
    fcONhsiAYRmXPHbpkWtyLGaJdxjBlM =fcONhsiAYRmXPHbpkWtyLGaJdxjBlQ['ott']
    fcONhsiAYRmXPHbpkWtyLGaJdxjBlT ='%s.%s'%(fcONhsiAYRmXPHbpkWtyLGaJdxjBlK,fcONhsiAYRmXPHbpkWtyLGaJdxjBlM)
    fcONhsiAYRmXPHbpkWtyLGaJdxjBln=fcONhsiAYRmXPHbpkWtyLGaJdxjBlQ['genrenm']
    if fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_DISPLAYNM:
     fcONhsiAYRmXPHbpkWtyLGaJdxjBlF='%s (%s)'%(fcONhsiAYRmXPHbpkWtyLGaJdxjBlF,fcONhsiAYRmXPHbpkWtyLGaJdxjBlM)
    if fcONhsiAYRmXPHbpkWtyLGaJdxjBln=='라디오/음악':
     fcONhsiAYRmXPHbpkWtyLGaJdxjBlI='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(fcONhsiAYRmXPHbpkWtyLGaJdxjBlT,fcONhsiAYRmXPHbpkWtyLGaJdxjBlF,fcONhsiAYRmXPHbpkWtyLGaJdxjBln,fcONhsiAYRmXPHbpkWtyLGaJdxjBlD,fcONhsiAYRmXPHbpkWtyLGaJdxjBlF)
    else:
     fcONhsiAYRmXPHbpkWtyLGaJdxjBlI='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(fcONhsiAYRmXPHbpkWtyLGaJdxjBlT,fcONhsiAYRmXPHbpkWtyLGaJdxjBlF,fcONhsiAYRmXPHbpkWtyLGaJdxjBln,fcONhsiAYRmXPHbpkWtyLGaJdxjBlD,fcONhsiAYRmXPHbpkWtyLGaJdxjBlF)
    if fcONhsiAYRmXPHbpkWtyLGaJdxjBlM=='wavve':
     fcONhsiAYRmXPHbpkWtyLGaJdxjBlS ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(fcONhsiAYRmXPHbpkWtyLGaJdxjBlK)
    elif fcONhsiAYRmXPHbpkWtyLGaJdxjBlM=='tving':
     fcONhsiAYRmXPHbpkWtyLGaJdxjBlS ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(fcONhsiAYRmXPHbpkWtyLGaJdxjBlK)
    elif fcONhsiAYRmXPHbpkWtyLGaJdxjBlM=='spotv':
     fcONhsiAYRmXPHbpkWtyLGaJdxjBlS ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(fcONhsiAYRmXPHbpkWtyLGaJdxjBlK)
    fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBlI)
    fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBlS)
   fp.close()
  except:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_noti(__language__(30910).encode('utf8'))
   return
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlq=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_M3u_Filename(tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv)
  fcONhsiAYRmXPHbpkWtyLGaJdxjBle=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_M3u_Filename(tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS)
  if xbmcvfs.copy(fcONhsiAYRmXPHbpkWtyLGaJdxjBlq,fcONhsiAYRmXPHbpkWtyLGaJdxjBle):
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_noti((fcONhsiAYRmXPHbpkWtyLGaJdxjBlU+' '+__language__(30908)).encode('utf8'))
  else:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_noti(__language__(30910).encode('utf-8'))
 def dp_Make_Epg(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU,args):
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=args.get('sType')
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlU=args.get('sName')
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlr=args.get('sNoti')
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBlr!='N':
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEu=xbmcgui.Dialog()
   fcONhsiAYRmXPHbpkWtyLGaJdxjBlE=fcONhsiAYRmXPHbpkWtyLGaJdxjBEu.yesno((fcONhsiAYRmXPHbpkWtyLGaJdxjBlU+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBlE==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:sys.exit()
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlv=[]
  fcONhsiAYRmXPHbpkWtyLGaJdxjBwE=[]
  if(fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='wavve' or fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='all')and fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVE:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwl,fcONhsiAYRmXPHbpkWtyLGaJdxjBwV=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_EexceptGroup_Wavve())
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBwV)!=0:
    fcONhsiAYRmXPHbpkWtyLGaJdxjBlv.extend(fcONhsiAYRmXPHbpkWtyLGaJdxjBwl)
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwE.extend(fcONhsiAYRmXPHbpkWtyLGaJdxjBwV)
  if(fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='tving' or fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='all')and fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONTVING:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwl,fcONhsiAYRmXPHbpkWtyLGaJdxjBwV=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.BoritvObj.Get_EpgInfo_Tving()
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBwV)!=0:
    fcONhsiAYRmXPHbpkWtyLGaJdxjBlv.extend(fcONhsiAYRmXPHbpkWtyLGaJdxjBwl)
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwE.extend(fcONhsiAYRmXPHbpkWtyLGaJdxjBwV)
  if(fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='spotv' or fcONhsiAYRmXPHbpkWtyLGaJdxjBlV=='all')and fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONSPOTV:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwl,fcONhsiAYRmXPHbpkWtyLGaJdxjBwV=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.BoritvObj.Get_EpgInfo_Spotv(payyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONSPOTVPAY)
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBwV)!=0:
    fcONhsiAYRmXPHbpkWtyLGaJdxjBlv.extend(fcONhsiAYRmXPHbpkWtyLGaJdxjBwl)
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwE.extend(fcONhsiAYRmXPHbpkWtyLGaJdxjBwV)
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBVE(fcONhsiAYRmXPHbpkWtyLGaJdxjBwE)==0:
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBlr!='N':fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBlw=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_Epg_Filename(tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv)
   fp=fcONhsiAYRmXPHbpkWtyLGaJdxjBVw(fcONhsiAYRmXPHbpkWtyLGaJdxjBlw,'w',-1,'utf-8')
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwU='<?xml version="1.0" encoding="UTF-8"?>\n'
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwg='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwo='<tv generator-info-name="boritv_epg">\n\n'
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwq='\n</tv>\n'
   fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBwU)
   fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBwg)
   fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBwo)
   for fcONhsiAYRmXPHbpkWtyLGaJdxjBwe in fcONhsiAYRmXPHbpkWtyLGaJdxjBlv:
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwu='  <channel id="%s.%s">\n' %(fcONhsiAYRmXPHbpkWtyLGaJdxjBwe.get('channelid'),fcONhsiAYRmXPHbpkWtyLGaJdxjBwe.get('ott'))
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwz='    <display-name>%s</display-name>\n'%(fcONhsiAYRmXPHbpkWtyLGaJdxjBwe.get('channelnm'))
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwC='    <icon src="%s" />\n' %(fcONhsiAYRmXPHbpkWtyLGaJdxjBwe.get('channelimg'))
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwQ='  </channel>\n\n'
    fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBwu)
    fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBwz)
    fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBwC)
    fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBwQ)
   for fcONhsiAYRmXPHbpkWtyLGaJdxjBwe in fcONhsiAYRmXPHbpkWtyLGaJdxjBwE:
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwu='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(fcONhsiAYRmXPHbpkWtyLGaJdxjBwe.get('startTime'),fcONhsiAYRmXPHbpkWtyLGaJdxjBwe.get('endTime'),fcONhsiAYRmXPHbpkWtyLGaJdxjBwe.get('channelid'),fcONhsiAYRmXPHbpkWtyLGaJdxjBwe.get('ott'))
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwz='    <title lang="kr">%s</title>\n' %(fcONhsiAYRmXPHbpkWtyLGaJdxjBwe.get('title'))
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwC='  </programme>\n\n'
    fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBwu)
    fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBwz)
    fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBwC)
   fp.write(fcONhsiAYRmXPHbpkWtyLGaJdxjBwq)
   fp.close()
  except:
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBlr!='N':fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_noti(__language__(30910).encode('utf8'))
   return
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.MakeEpg_SaveJson()
  fcONhsiAYRmXPHbpkWtyLGaJdxjBlq=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_Epg_Filename(tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv)
  fcONhsiAYRmXPHbpkWtyLGaJdxjBle=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.make_Epg_Filename(tempyn=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS)
  if xbmcvfs.copy(fcONhsiAYRmXPHbpkWtyLGaJdxjBlq,fcONhsiAYRmXPHbpkWtyLGaJdxjBle):
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBlr!='N':fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_noti((fcONhsiAYRmXPHbpkWtyLGaJdxjBlU+' '+__language__(30912)).encode('utf8'))
  else:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_AUTORESTART:
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwK=xbmcaddon.Addon('pvr.iptvsimple')
    fcONhsiAYRmXPHbpkWtyLGaJdxjBwK.setSetting('anything','anything')
  except:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwr 
 def make_EexceptGroup_Wavve(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU):
  fcONhsiAYRmXPHbpkWtyLGaJdxjBwF=[]
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVERADIO==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwF.append('라디오/음악')
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVEHOME==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwF.append('홈쇼핑')
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONRELIGION==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwF.append('종교')
  return fcONhsiAYRmXPHbpkWtyLGaJdxjBwF
 def get_radio_list(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU):
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVERADIO==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:return[]
  fcONhsiAYRmXPHbpkWtyLGaJdxjBwD=[{'broadcastid':'46584','genre':'10'}]
  return fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.BoritvObj.Get_ChannelList_WavveExcept(fcONhsiAYRmXPHbpkWtyLGaJdxjBwD)
 def check_config(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU):
  fcONhsiAYRmXPHbpkWtyLGaJdxjBwM=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVE =fcONhsiAYRmXPHbpkWtyLGaJdxjBwv if __addon__.getSetting('onWavve')=='true' else fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONTVING =fcONhsiAYRmXPHbpkWtyLGaJdxjBwv if __addon__.getSetting('onTvng')=='true' else fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONSPOTV =fcONhsiAYRmXPHbpkWtyLGaJdxjBwv if __addon__.getSetting('onSpotv')=='true' else fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVERADIO=fcONhsiAYRmXPHbpkWtyLGaJdxjBwv if __addon__.getSetting('onWavveRadio')=='true' else fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVEHOME =fcONhsiAYRmXPHbpkWtyLGaJdxjBwv if __addon__.getSetting('onWavveHome')=='true' else fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONRELIGION =fcONhsiAYRmXPHbpkWtyLGaJdxjBwv if __addon__.getSetting('onWavveReligion')=='true' else fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONSPOTVPAY =fcONhsiAYRmXPHbpkWtyLGaJdxjBwv if __addon__.getSetting('onSpotvPay')=='true' else fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_DISPLAYNM =fcONhsiAYRmXPHbpkWtyLGaJdxjBwv if __addon__.getSetting('displayOTTnm')=='true' else fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_AUTORESTART =fcONhsiAYRmXPHbpkWtyLGaJdxjBwv if __addon__.getSetting('autoRestart')=='true' else fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_FILE_PATH=='' or fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_FILE_NAME=='':fcONhsiAYRmXPHbpkWtyLGaJdxjBwM=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONWAVVE==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS and fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONTVING=='' and fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.M3U_ONSPOTV=='':fcONhsiAYRmXPHbpkWtyLGaJdxjBwM=fcONhsiAYRmXPHbpkWtyLGaJdxjBwS
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBwM==fcONhsiAYRmXPHbpkWtyLGaJdxjBwS:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEu=xbmcgui.Dialog()
   fcONhsiAYRmXPHbpkWtyLGaJdxjBlE=fcONhsiAYRmXPHbpkWtyLGaJdxjBEu.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if fcONhsiAYRmXPHbpkWtyLGaJdxjBlE==fcONhsiAYRmXPHbpkWtyLGaJdxjBwv:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU):
  fcONhsiAYRmXPHbpkWtyLGaJdxjBwT={'date_makeepg':fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=fcONhsiAYRmXPHbpkWtyLGaJdxjBVw(fcONhsiAYRmXPHbpkWtyLGaJdxjBEV,'w',-1,'utf-8')
   json.dump(fcONhsiAYRmXPHbpkWtyLGaJdxjBwT,fp)
   fp.close()
  except fcONhsiAYRmXPHbpkWtyLGaJdxjBVU as exception:
   return
 def boritv_main(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU):
  fcONhsiAYRmXPHbpkWtyLGaJdxjBwn=fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.main_params.get('mode',fcONhsiAYRmXPHbpkWtyLGaJdxjBwr)
  fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.check_config()
  if fcONhsiAYRmXPHbpkWtyLGaJdxjBwn is fcONhsiAYRmXPHbpkWtyLGaJdxjBwr:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.dp_Main_List()
  elif fcONhsiAYRmXPHbpkWtyLGaJdxjBwn=='DEL_M3U':
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.dp_Delete_M3u(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.main_params)
  elif fcONhsiAYRmXPHbpkWtyLGaJdxjBwn=='ADD_M3U':
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.dp_MakeAdd_M3u(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.main_params)
  elif fcONhsiAYRmXPHbpkWtyLGaJdxjBwn=='ADD_EPG':
   fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.dp_Make_Epg(fcONhsiAYRmXPHbpkWtyLGaJdxjBEU.main_params)
  else:
   fcONhsiAYRmXPHbpkWtyLGaJdxjBwr
# Created by pyminifier (https://github.com/liftoff/pyminifier)
