__author__="NightRain"
GrMLvOEahPmgyJcjdkiYTBAFNbxtKo=False
GrMLvOEahPmgyJcjdkiYTBAFNbxtKI=object
GrMLvOEahPmgyJcjdkiYTBAFNbxtKC=None
GrMLvOEahPmgyJcjdkiYTBAFNbxtKV=str
GrMLvOEahPmgyJcjdkiYTBAFNbxtKS=Exception
GrMLvOEahPmgyJcjdkiYTBAFNbxtKp=print
GrMLvOEahPmgyJcjdkiYTBAFNbxtKz=True
GrMLvOEahPmgyJcjdkiYTBAFNbxtKn=int
GrMLvOEahPmgyJcjdkiYTBAFNbxtKs=range
GrMLvOEahPmgyJcjdkiYTBAFNbxtKe=len
GrMLvOEahPmgyJcjdkiYTBAFNbxtKD=set
GrMLvOEahPmgyJcjdkiYTBAFNbxtKW=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
from channelgenre import*
GrMLvOEahPmgyJcjdkiYTBAFNbxtuH=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
GrMLvOEahPmgyJcjdkiYTBAFNbxtuK=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':GrMLvOEahPmgyJcjdkiYTBAFNbxtKo,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':GrMLvOEahPmgyJcjdkiYTBAFNbxtKo,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':GrMLvOEahPmgyJcjdkiYTBAFNbxtKo,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':GrMLvOEahPmgyJcjdkiYTBAFNbxtKo,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':GrMLvOEahPmgyJcjdkiYTBAFNbxtKo,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':GrMLvOEahPmgyJcjdkiYTBAFNbxtKo,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class GrMLvOEahPmgyJcjdkiYTBAFNbxtul(GrMLvOEahPmgyJcjdkiYTBAFNbxtKI):
 def __init__(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_WAVVE ='https://apis.wavve.com'
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_TVING ='https://api.tving.com'
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_TVINGIMG ='https://image.tving.com'
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_SPOTV ='https://www.spotvnow.co.kr'
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.HTTPTAG ='https://'
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.LIMIT_WAVVE =200
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.LIMIT_TVING =60
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.LIMIT_TVINGEPG=20 
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.DEFAULT_HEADER={'user-agent':GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.USER_AGENT}
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.SLEEP_TIME =0.2
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.INIT_GENRESORT=MASTER_GENRE
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,jobtype,GrMLvOEahPmgyJcjdkiYTBAFNbxtus,payload=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,params=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,cookies=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,redirects=GrMLvOEahPmgyJcjdkiYTBAFNbxtKo):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuI=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.DEFAULT_HEADER
  if headers:GrMLvOEahPmgyJcjdkiYTBAFNbxtuI.update(headers)
  if jobtype=='Get':
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuC=requests.get(GrMLvOEahPmgyJcjdkiYTBAFNbxtus,params=params,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtuI,cookies=cookies,allow_redirects=redirects)
  else:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuC=requests.post(GrMLvOEahPmgyJcjdkiYTBAFNbxtus,data=payload,params=params,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtuI,cookies=cookies,allow_redirects=redirects)
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtuC
 def Get_DefaultParams_Wavve(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuV={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtuV
 def Get_DefaultParams_Tving(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuV={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtuV
 def Get_Now_Datetime(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,in_text):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtup=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtup
 def Get_ChannelList_Wavve(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,exceptGroup=[]):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuz =[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtun=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_ChannelImg_Wavve()
  try:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtus=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_WAVVE+'/cf/live/recommend-channels'
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuV={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuV.update(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_DefaultParams_Wavve())
   GrMLvOEahPmgyJcjdkiYTBAFNbxtue=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.callRequestCookies('Get',GrMLvOEahPmgyJcjdkiYTBAFNbxtus,payload=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,params=GrMLvOEahPmgyJcjdkiYTBAFNbxtuV,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,cookies=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC)
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuD=json.loads(GrMLvOEahPmgyJcjdkiYTBAFNbxtue.text)
   if not('celllist' in GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['cell_toplist']):return GrMLvOEahPmgyJcjdkiYTBAFNbxtuz
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuW=GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['cell_toplist']['celllist']
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtuW:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuX=GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['contentid']
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuU=GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['title_list'][0]['text']
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtuX in GrMLvOEahPmgyJcjdkiYTBAFNbxtun:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuw=GrMLvOEahPmgyJcjdkiYTBAFNbxtun[GrMLvOEahPmgyJcjdkiYTBAFNbxtuX]
    else:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuw=''
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuf=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.make_getGenre(GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,'wavve')
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlu={'channelid':GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,'channelnm':GrMLvOEahPmgyJcjdkiYTBAFNbxtuU,'channelimg':GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.HTTPTAG+GrMLvOEahPmgyJcjdkiYTBAFNbxtuw if GrMLvOEahPmgyJcjdkiYTBAFNbxtuw!='' else '','ott':'wavve','genrenm':GrMLvOEahPmgyJcjdkiYTBAFNbxtuf}
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtuf not in exceptGroup:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuz.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return[]
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtuz
 def Get_ChannelList_WavveExcept(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,exceptGroup=[]):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuz=[]
  if exceptGroup==[]:return[]
  try:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtus=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_WAVVE+'/cf/live/recommend-channels'
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in exceptGroup:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuV={'WeekDay':'all','adult':'n','broadcastid':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['broadcastid'],'contenttype':'channel','genre':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['genre'],'isrecommend':'y','limit':GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuV.update(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_DefaultParams_Wavve())
    GrMLvOEahPmgyJcjdkiYTBAFNbxtue=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.callRequestCookies('Get',GrMLvOEahPmgyJcjdkiYTBAFNbxtus,payload=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,params=GrMLvOEahPmgyJcjdkiYTBAFNbxtuV,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,cookies=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC)
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuD=json.loads(GrMLvOEahPmgyJcjdkiYTBAFNbxtue.text)
    if not('celllist' in GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['cell_toplist']):return GrMLvOEahPmgyJcjdkiYTBAFNbxtuz
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuW=GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['cell_toplist']['celllist']
    for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtuW:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuz.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['contentid'])
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return[]
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtuz
 def Get_ChannelImg_Wavve(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlH={}
  try:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtlK=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_Now_Datetime()
   GrMLvOEahPmgyJcjdkiYTBAFNbxtlQ =GrMLvOEahPmgyJcjdkiYTBAFNbxtlK+datetime.timedelta(hours=3)
   GrMLvOEahPmgyJcjdkiYTBAFNbxtus=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_WAVVE+'/live/epgs'
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuV={'limit':GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':GrMLvOEahPmgyJcjdkiYTBAFNbxtlK.strftime('%Y-%m-%d %H:00'),'enddatetime':GrMLvOEahPmgyJcjdkiYTBAFNbxtlQ.strftime('%Y-%m-%d %H:00')}
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuV.update(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_DefaultParams_Wavve())
   GrMLvOEahPmgyJcjdkiYTBAFNbxtue=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.callRequestCookies('Get',GrMLvOEahPmgyJcjdkiYTBAFNbxtus,payload=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,params=GrMLvOEahPmgyJcjdkiYTBAFNbxtuV,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,cookies=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC)
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuD=json.loads(GrMLvOEahPmgyJcjdkiYTBAFNbxtue.text)
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuW=GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['list']
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtuW:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlH[GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['channelid']]=GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['channelimage']
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtlH
 def Get_ChanneGenrename_Wavve(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,GrMLvOEahPmgyJcjdkiYTBAFNbxtuX):
  try:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtus=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_WAVVE+'/live/channels/'+GrMLvOEahPmgyJcjdkiYTBAFNbxtuX
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuV=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_DefaultParams_Wavve()
   GrMLvOEahPmgyJcjdkiYTBAFNbxtue=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.callRequestCookies('Get',GrMLvOEahPmgyJcjdkiYTBAFNbxtus,payload=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,params=GrMLvOEahPmgyJcjdkiYTBAFNbxtuV,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,cookies=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC)
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuD=json.loads(GrMLvOEahPmgyJcjdkiYTBAFNbxtue.text)
   GrMLvOEahPmgyJcjdkiYTBAFNbxtlq=GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['genretext']
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return ''
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtlq
 def Get_ChannelList_Spotv(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,payyn=GrMLvOEahPmgyJcjdkiYTBAFNbxtKz):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuz=[]
  try:
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtuK:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuX=GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['videoId']
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlu={'channelid':GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,'channelnm':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['name'],'channelimg':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['logo'],'ott':'spotv','genrenm':GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.make_getGenre(GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,'spotv')}
    if payyn==GrMLvOEahPmgyJcjdkiYTBAFNbxtKz or GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['free']==GrMLvOEahPmgyJcjdkiYTBAFNbxtKz:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuz.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return[]
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtuz
 def Get_ChannelList_Tving(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuz =[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlo=[]
  try:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtus=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_TVING+'/v2/media/lives'
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuV={'pageNo':'1','pageSize':GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuV.update(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_DefaultParams_Tving())
   GrMLvOEahPmgyJcjdkiYTBAFNbxtue=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.callRequestCookies('Get',GrMLvOEahPmgyJcjdkiYTBAFNbxtus,payload=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,params=GrMLvOEahPmgyJcjdkiYTBAFNbxtuV,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,cookies=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC)
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuD=json.loads(GrMLvOEahPmgyJcjdkiYTBAFNbxtue.text)
   if not('result' in GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['body']):return GrMLvOEahPmgyJcjdkiYTBAFNbxtuz
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuW=GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['body']['result']
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtuW:
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['live_code']=='C44441':continue 
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlo.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['live_code'])
   GrMLvOEahPmgyJcjdkiYTBAFNbxtun=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_ChannelImg_Tving(GrMLvOEahPmgyJcjdkiYTBAFNbxtlo)
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtuW:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuX=GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['live_code']
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtuX=='C44441':continue 
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuU=GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['schedule']['channel']['name']['ko']
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtuX in GrMLvOEahPmgyJcjdkiYTBAFNbxtun:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuw=GrMLvOEahPmgyJcjdkiYTBAFNbxtun[GrMLvOEahPmgyJcjdkiYTBAFNbxtuX]
    else:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuw=''
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlu={'channelid':GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,'channelnm':GrMLvOEahPmgyJcjdkiYTBAFNbxtuU,'channelimg':GrMLvOEahPmgyJcjdkiYTBAFNbxtuw,'ott':'tving','genrenm':GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.make_getGenre(GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,'tving')}
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuz.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return[]
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtuz
 def make_EpgDatetime_Tving(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,days=2):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlI=[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlC=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.make_DateList(days=2,dateType='2')
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlV=GrMLvOEahPmgyJcjdkiYTBAFNbxtKn(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtlC:
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtlS in GrMLvOEahPmgyJcjdkiYTBAFNbxtKs(8):
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlu={'ndate':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR,'starttm':GrMLvOEahPmgyJcjdkiYTBAFNbxtuH[GrMLvOEahPmgyJcjdkiYTBAFNbxtlS]['starttm'],'endtm':GrMLvOEahPmgyJcjdkiYTBAFNbxtuH[GrMLvOEahPmgyJcjdkiYTBAFNbxtlS]['endtm']}
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlp=GrMLvOEahPmgyJcjdkiYTBAFNbxtKn(GrMLvOEahPmgyJcjdkiYTBAFNbxtuR+GrMLvOEahPmgyJcjdkiYTBAFNbxtuH[GrMLvOEahPmgyJcjdkiYTBAFNbxtlS]['starttm'])
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlz=GrMLvOEahPmgyJcjdkiYTBAFNbxtKn(GrMLvOEahPmgyJcjdkiYTBAFNbxtuR+GrMLvOEahPmgyJcjdkiYTBAFNbxtuH[GrMLvOEahPmgyJcjdkiYTBAFNbxtlS]['endtm'])
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtlV<=GrMLvOEahPmgyJcjdkiYTBAFNbxtlp or(GrMLvOEahPmgyJcjdkiYTBAFNbxtlp<GrMLvOEahPmgyJcjdkiYTBAFNbxtlV and GrMLvOEahPmgyJcjdkiYTBAFNbxtlV<GrMLvOEahPmgyJcjdkiYTBAFNbxtlz):
     GrMLvOEahPmgyJcjdkiYTBAFNbxtlI.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtlI
 def make_DateList(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,days=2,dateType='1'):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlC=[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtln =GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_Now_Datetime()
  if dateType=='1':
   GrMLvOEahPmgyJcjdkiYTBAFNbxtln=GrMLvOEahPmgyJcjdkiYTBAFNbxtln-datetime.timedelta(days=1)
  for i in GrMLvOEahPmgyJcjdkiYTBAFNbxtKs(days):
   GrMLvOEahPmgyJcjdkiYTBAFNbxtls=GrMLvOEahPmgyJcjdkiYTBAFNbxtln+datetime.timedelta(days=i)
   if dateType=='1':
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlC.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtls.strftime('%Y%m%d'))
   else:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlC.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtls.strftime('%Y%m%d'))
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtlC
 def make_Tving_ChannleGroup(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,GrMLvOEahPmgyJcjdkiYTBAFNbxtlo):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtle=[]
  i=0
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlD=''
  for GrMLvOEahPmgyJcjdkiYTBAFNbxtlW in GrMLvOEahPmgyJcjdkiYTBAFNbxtlo:
   if i==0:GrMLvOEahPmgyJcjdkiYTBAFNbxtlD=GrMLvOEahPmgyJcjdkiYTBAFNbxtlW
   else:GrMLvOEahPmgyJcjdkiYTBAFNbxtlD+=',%s'%(GrMLvOEahPmgyJcjdkiYTBAFNbxtlW)
   i+=1
   if i>=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.LIMIT_TVINGEPG:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtle.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlD)
    i=0
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlD=''
  if GrMLvOEahPmgyJcjdkiYTBAFNbxtlD!='':
   GrMLvOEahPmgyJcjdkiYTBAFNbxtle.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlD)
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtle
 def Get_ChannelImg_Tving(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,chid_list):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlH={}
  try:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtlR=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_Now_Datetime().strftime('%Y%m%d')
   GrMLvOEahPmgyJcjdkiYTBAFNbxtlK =GrMLvOEahPmgyJcjdkiYTBAFNbxtuH[6]['starttm'] 
   GrMLvOEahPmgyJcjdkiYTBAFNbxtlQ =GrMLvOEahPmgyJcjdkiYTBAFNbxtuH[6]['endtm']
   GrMLvOEahPmgyJcjdkiYTBAFNbxtle=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.make_Tving_ChannleGroup(chid_list)
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtle:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtus=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_TVING+'/v2/media/schedules'
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuV={'pageNo':'1','pageSize':GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':GrMLvOEahPmgyJcjdkiYTBAFNbxtlR,'broadcastDate':GrMLvOEahPmgyJcjdkiYTBAFNbxtlR,'startBroadTime':GrMLvOEahPmgyJcjdkiYTBAFNbxtlK,'endBroadTime':GrMLvOEahPmgyJcjdkiYTBAFNbxtlQ,'channelCode':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR}
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuV.update(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_DefaultParams_Tving())
    GrMLvOEahPmgyJcjdkiYTBAFNbxtue=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.callRequestCookies('Get',GrMLvOEahPmgyJcjdkiYTBAFNbxtus,payload=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,params=GrMLvOEahPmgyJcjdkiYTBAFNbxtuV,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,cookies=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC)
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuD=json.loads(GrMLvOEahPmgyJcjdkiYTBAFNbxtue.text)
    if not('result' in GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['body']):return{}
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuW=GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['body']['result']
    for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtuW:
     for GrMLvOEahPmgyJcjdkiYTBAFNbxtlX in GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['image']:
      if GrMLvOEahPmgyJcjdkiYTBAFNbxtlX['code']=='CAIC0400':GrMLvOEahPmgyJcjdkiYTBAFNbxtlH[GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['channel_code']]=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_TVINGIMG+GrMLvOEahPmgyJcjdkiYTBAFNbxtlX['url']
      elif GrMLvOEahPmgyJcjdkiYTBAFNbxtlX['code']=='CAIC1400':GrMLvOEahPmgyJcjdkiYTBAFNbxtlH[GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['channel_code']]=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_TVINGIMG+GrMLvOEahPmgyJcjdkiYTBAFNbxtlX['url']
      elif GrMLvOEahPmgyJcjdkiYTBAFNbxtlX['code']=='CAIC1900':GrMLvOEahPmgyJcjdkiYTBAFNbxtlH[GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['channel_code']]=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_TVINGIMG+GrMLvOEahPmgyJcjdkiYTBAFNbxtlX['url']
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return{}
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtlH
 def Get_EpgInfo_Spotv(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,days=3,payyn=GrMLvOEahPmgyJcjdkiYTBAFNbxtKz):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuz=[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlU =[]
  try:
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtuK:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuX =GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['videoId']
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlu={'channelid':GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,'channelnm':GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.xmlText(GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['name']),'channelimg':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['logo'],'ott':'spotv','epgtype':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['epgtype'],'epgnm':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['epgnm']}
    if payyn==GrMLvOEahPmgyJcjdkiYTBAFNbxtKz or GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['free']==GrMLvOEahPmgyJcjdkiYTBAFNbxtKz:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuz.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return[],[]
  '''
  try:
   for now_day in days_list:
    url = self.API_SPOTV + '/api/v2/program/' + now_day
    response = self.callRequestCookies('Get', url, payload=None, params=None, headers=None, cookies=None )
    res_json = json.loads(response.text )
    for i_section in res_json:
     if find_list.get(i_section['channelId'] ) == None: continue
     temp_list = {'channelid' : find_list.get(i_section['channelId'] ) , 'title' : self.xmlText(i_section['title'] ) , 'startTime' : i_section['startTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'endTime' : i_section['endTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'ott' : 'spotv' }
     epg_list.append(temp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  try:
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtlw in GrMLvOEahPmgyJcjdkiYTBAFNbxtuz:
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtlw['epgtype']=='spotvon':
     GrMLvOEahPmgyJcjdkiYTBAFNbxtlf=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_EpgInfo_Spotv_spotvon(GrMLvOEahPmgyJcjdkiYTBAFNbxtlw['channelid'],GrMLvOEahPmgyJcjdkiYTBAFNbxtlw['epgnm'],days)
     if GrMLvOEahPmgyJcjdkiYTBAFNbxtKe(GrMLvOEahPmgyJcjdkiYTBAFNbxtlf)>0:GrMLvOEahPmgyJcjdkiYTBAFNbxtlU.extend(GrMLvOEahPmgyJcjdkiYTBAFNbxtlf)
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtlw['epgtype']=='spotvnet':
     GrMLvOEahPmgyJcjdkiYTBAFNbxtlf=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_EpgInfo_Spotv_spotvnet(GrMLvOEahPmgyJcjdkiYTBAFNbxtlw['channelid'],GrMLvOEahPmgyJcjdkiYTBAFNbxtlw['epgnm'],days)
     if GrMLvOEahPmgyJcjdkiYTBAFNbxtKe(GrMLvOEahPmgyJcjdkiYTBAFNbxtlf)>0:GrMLvOEahPmgyJcjdkiYTBAFNbxtlU.extend(GrMLvOEahPmgyJcjdkiYTBAFNbxtlf)
    time.sleep(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.SLEEP_TIME)
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return[],[]
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtuz,GrMLvOEahPmgyJcjdkiYTBAFNbxtlU
 def Get_EpgInfo_Spotv_spotvon(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,epgnm,days):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlU =[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlC=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.make_DateList(days=days,dateType='1')
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHu=''
  try:
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtHl in GrMLvOEahPmgyJcjdkiYTBAFNbxtlC:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtus='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,GrMLvOEahPmgyJcjdkiYTBAFNbxtHl)
    GrMLvOEahPmgyJcjdkiYTBAFNbxtue=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.callRequestCookies('Get',GrMLvOEahPmgyJcjdkiYTBAFNbxtus,payload=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,params=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,cookies=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC)
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuD=json.loads(GrMLvOEahPmgyJcjdkiYTBAFNbxtue.text)
    for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtuD:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtlu={'channelid':GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,'title':GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.xmlText(GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['title']),'startTime':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['sch_date'].replace('-','')+GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['sch_hour']).zfill(2)+GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['sch_min']+'00','ott':'spotv'}
     GrMLvOEahPmgyJcjdkiYTBAFNbxtlU.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
    GrMLvOEahPmgyJcjdkiYTBAFNbxtHu=GrMLvOEahPmgyJcjdkiYTBAFNbxtHl
   for i in GrMLvOEahPmgyJcjdkiYTBAFNbxtKs(GrMLvOEahPmgyJcjdkiYTBAFNbxtKe(GrMLvOEahPmgyJcjdkiYTBAFNbxtlU)):
    if i>0:GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i-1]['endTime']=GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i]['startTime']
    if i==GrMLvOEahPmgyJcjdkiYTBAFNbxtKe(GrMLvOEahPmgyJcjdkiYTBAFNbxtlU)-1: GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i]['endTime']=GrMLvOEahPmgyJcjdkiYTBAFNbxtHu+'240000'
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return[]
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtlU
 def Get_EpgInfo_Spotv_spotvnet(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,epgnm,days):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlU =[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlC=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.make_DateList(days=days,dateType='1')
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHu=''
  try:
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtHl in GrMLvOEahPmgyJcjdkiYTBAFNbxtlC:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtus='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,GrMLvOEahPmgyJcjdkiYTBAFNbxtHl)
    GrMLvOEahPmgyJcjdkiYTBAFNbxtue=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.callRequestCookies('Get',GrMLvOEahPmgyJcjdkiYTBAFNbxtus,payload=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,params=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,cookies=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC)
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuD=json.loads(GrMLvOEahPmgyJcjdkiYTBAFNbxtue.text)
    for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtuD:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtlu={'channelid':GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,'title':GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.xmlText(GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['title']),'startTime':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['sch_date'].replace('-','')+GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['sch_hour']).zfill(2)+GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['sch_min']+'00','ott':'spotv'}
     GrMLvOEahPmgyJcjdkiYTBAFNbxtlU.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
    GrMLvOEahPmgyJcjdkiYTBAFNbxtHu=GrMLvOEahPmgyJcjdkiYTBAFNbxtHl
   for i in GrMLvOEahPmgyJcjdkiYTBAFNbxtKs(GrMLvOEahPmgyJcjdkiYTBAFNbxtKe(GrMLvOEahPmgyJcjdkiYTBAFNbxtlU)):
    if i>0:GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i-1]['endTime']=GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i]['startTime']
    if i==GrMLvOEahPmgyJcjdkiYTBAFNbxtKe(GrMLvOEahPmgyJcjdkiYTBAFNbxtlU)-1: GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i]['endTime']=GrMLvOEahPmgyJcjdkiYTBAFNbxtHu+'240000'
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return[]
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtlU
 def Get_EpgInfo_Wavve(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,days=2,exceptGroup=[]):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuz =[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlU =[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtln =GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_Now_Datetime()
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHK =GrMLvOEahPmgyJcjdkiYTBAFNbxtln+datetime.timedelta(hours=-2)
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHQ =GrMLvOEahPmgyJcjdkiYTBAFNbxtln+datetime.timedelta(days=(days-1))
  if GrMLvOEahPmgyJcjdkiYTBAFNbxtKn(GrMLvOEahPmgyJcjdkiYTBAFNbxtHK.strftime('%H'))<=3:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtHq=GrMLvOEahPmgyJcjdkiYTBAFNbxtHK.strftime('%Y-%m-%d 00:00')
  else:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtHq=GrMLvOEahPmgyJcjdkiYTBAFNbxtHK.strftime('%Y-%m-%d %H:00')
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHo =GrMLvOEahPmgyJcjdkiYTBAFNbxtHQ.strftime('%Y-%m-%d 24:00')
  try:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtus=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_WAVVE+'/live/epgs'
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuV={'limit':GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':GrMLvOEahPmgyJcjdkiYTBAFNbxtHq,'enddatetime':GrMLvOEahPmgyJcjdkiYTBAFNbxtHo}
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuV.update(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_DefaultParams_Wavve())
   GrMLvOEahPmgyJcjdkiYTBAFNbxtue=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.callRequestCookies('Get',GrMLvOEahPmgyJcjdkiYTBAFNbxtus,payload=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,params=GrMLvOEahPmgyJcjdkiYTBAFNbxtuV,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,cookies=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC)
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuD=json.loads(GrMLvOEahPmgyJcjdkiYTBAFNbxtue.text)
   GrMLvOEahPmgyJcjdkiYTBAFNbxtHI=GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['list']
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtHI:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuX =GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['channelid']
    GrMLvOEahPmgyJcjdkiYTBAFNbxtuf=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.make_getGenre(GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,'wavve')
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlu={'channelid':GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,'channelnm':GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.xmlText(GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['channelname']),'channelimg':GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.HTTPTAG+GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['channelimage'],'ott':'wavve'}
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtuf not in exceptGroup:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuz.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
    for GrMLvOEahPmgyJcjdkiYTBAFNbxtHC in GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['list']:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtlu={'channelid':GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['channelid'],'title':GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.xmlText(GrMLvOEahPmgyJcjdkiYTBAFNbxtHC['title']),'startTime':GrMLvOEahPmgyJcjdkiYTBAFNbxtHC['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':GrMLvOEahPmgyJcjdkiYTBAFNbxtHC['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if GrMLvOEahPmgyJcjdkiYTBAFNbxtuf not in exceptGroup and GrMLvOEahPmgyJcjdkiYTBAFNbxtHC['starttime']!=GrMLvOEahPmgyJcjdkiYTBAFNbxtHC['endtime']:
      GrMLvOEahPmgyJcjdkiYTBAFNbxtlU.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return[],[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHV=GrMLvOEahPmgyJcjdkiYTBAFNbxtKe(GrMLvOEahPmgyJcjdkiYTBAFNbxtlU)
  for i in(GrMLvOEahPmgyJcjdkiYTBAFNbxtKs(1,GrMLvOEahPmgyJcjdkiYTBAFNbxtHV)):
   if GrMLvOEahPmgyJcjdkiYTBAFNbxtKn(GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i-1]['endTime'])+1==GrMLvOEahPmgyJcjdkiYTBAFNbxtKn(GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i]['startTime'])and GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i-1]['channelid']==GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i]['channelid']:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i-1]['endTime']=GrMLvOEahPmgyJcjdkiYTBAFNbxtlU[i]['startTime']
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtuz,GrMLvOEahPmgyJcjdkiYTBAFNbxtlU
 def Get_EpgInfo_Tving(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,days=2):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuz=[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlU =[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHS =[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHp =GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.make_EpgDatetime_Tving(days=days)
  GrMLvOEahPmgyJcjdkiYTBAFNbxtuz =GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_ChannelList_Tving()
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHz=[]
  for i in GrMLvOEahPmgyJcjdkiYTBAFNbxtKs(GrMLvOEahPmgyJcjdkiYTBAFNbxtKe(GrMLvOEahPmgyJcjdkiYTBAFNbxtuz)):
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuz[i]['channelnm']=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.xmlText(GrMLvOEahPmgyJcjdkiYTBAFNbxtuz[i]['channelnm'])
   GrMLvOEahPmgyJcjdkiYTBAFNbxtHz.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtuz[i]['channelid'])
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHn=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.make_Tving_ChannleGroup(GrMLvOEahPmgyJcjdkiYTBAFNbxtHz)
  try:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtus=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.API_TVING+'/v2/media/schedules'
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtHs in GrMLvOEahPmgyJcjdkiYTBAFNbxtHp:
    for GrMLvOEahPmgyJcjdkiYTBAFNbxtlw in GrMLvOEahPmgyJcjdkiYTBAFNbxtHn:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuV={'pageNo':'1','pageSize':GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':GrMLvOEahPmgyJcjdkiYTBAFNbxtHs['ndate'],'broadcastDate':GrMLvOEahPmgyJcjdkiYTBAFNbxtHs['ndate'],'startBroadTime':GrMLvOEahPmgyJcjdkiYTBAFNbxtHs['starttm'],'endBroadTime':GrMLvOEahPmgyJcjdkiYTBAFNbxtHs['endtm'],'channelCode':GrMLvOEahPmgyJcjdkiYTBAFNbxtlw}
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuV.update(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_DefaultParams_Tving())
     GrMLvOEahPmgyJcjdkiYTBAFNbxtue=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.callRequestCookies('Get',GrMLvOEahPmgyJcjdkiYTBAFNbxtus,payload=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,params=GrMLvOEahPmgyJcjdkiYTBAFNbxtuV,headers=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC,cookies=GrMLvOEahPmgyJcjdkiYTBAFNbxtKC)
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuD=json.loads(GrMLvOEahPmgyJcjdkiYTBAFNbxtue.text)
     GrMLvOEahPmgyJcjdkiYTBAFNbxtuW=GrMLvOEahPmgyJcjdkiYTBAFNbxtuD['body']['result']
     for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtuW:
      if 'schedules' not in GrMLvOEahPmgyJcjdkiYTBAFNbxtuR:continue
      if GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['schedules']==GrMLvOEahPmgyJcjdkiYTBAFNbxtKC:continue
      for GrMLvOEahPmgyJcjdkiYTBAFNbxtHe in GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['schedules']:
       GrMLvOEahPmgyJcjdkiYTBAFNbxtlu={'channelid':GrMLvOEahPmgyJcjdkiYTBAFNbxtHe['schedule_code'],'title':GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.xmlText(GrMLvOEahPmgyJcjdkiYTBAFNbxtHe['program']['name']['ko']),'startTime':GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtHe['broadcast_start_time']),'endTime':GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtHe['broadcast_end_time']),'ott':'tving'}
       GrMLvOEahPmgyJcjdkiYTBAFNbxtHD=GrMLvOEahPmgyJcjdkiYTBAFNbxtHe['schedule_code']+GrMLvOEahPmgyJcjdkiYTBAFNbxtKV(GrMLvOEahPmgyJcjdkiYTBAFNbxtHe['broadcast_start_time'])
       if GrMLvOEahPmgyJcjdkiYTBAFNbxtHD in GrMLvOEahPmgyJcjdkiYTBAFNbxtHS:continue
       GrMLvOEahPmgyJcjdkiYTBAFNbxtHS.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtHD)
       GrMLvOEahPmgyJcjdkiYTBAFNbxtlU.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
     time.sleep(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.SLEEP_TIME)
  except GrMLvOEahPmgyJcjdkiYTBAFNbxtKS as exception:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKp(exception)
   return[],[]
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtuz,GrMLvOEahPmgyJcjdkiYTBAFNbxtlU
 def make_getGenre(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ,GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,GrMLvOEahPmgyJcjdkiYTBAFNbxtKH):
  try:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtlq=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.INIT_CHANNEL.get(GrMLvOEahPmgyJcjdkiYTBAFNbxtuX+'.'+GrMLvOEahPmgyJcjdkiYTBAFNbxtKH).get('genre')
  except:
   GrMLvOEahPmgyJcjdkiYTBAFNbxtlq='-'
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtlq
 def make_base_allchannel_py(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ):
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHW =[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHR=[]
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHX=GrMLvOEahPmgyJcjdkiYTBAFNbxtKD()
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlu=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_ChannelList_Wavve()
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHW.extend(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlu=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_ChannelList_Tving()
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHW.extend(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
  GrMLvOEahPmgyJcjdkiYTBAFNbxtlu=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_ChannelList_Spotv()
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHW.extend(GrMLvOEahPmgyJcjdkiYTBAFNbxtlu)
  GrMLvOEahPmgyJcjdkiYTBAFNbxtKp('1')
  for i in GrMLvOEahPmgyJcjdkiYTBAFNbxtKs(GrMLvOEahPmgyJcjdkiYTBAFNbxtKe(GrMLvOEahPmgyJcjdkiYTBAFNbxtHW)):
   if GrMLvOEahPmgyJcjdkiYTBAFNbxtHW[i]['genrenm']=='-':
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtHW[i]['ott']=='wavve':
     GrMLvOEahPmgyJcjdkiYTBAFNbxtlq=GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.Get_ChanneGenrename_Wavve(GrMLvOEahPmgyJcjdkiYTBAFNbxtHW[i]['channelid'])
     if GrMLvOEahPmgyJcjdkiYTBAFNbxtlq not in GrMLvOEahPmgyJcjdkiYTBAFNbxtHX:GrMLvOEahPmgyJcjdkiYTBAFNbxtHX.add(GrMLvOEahPmgyJcjdkiYTBAFNbxtlq)
     time.sleep(GrMLvOEahPmgyJcjdkiYTBAFNbxtuQ.SLEEP_TIME)
    elif GrMLvOEahPmgyJcjdkiYTBAFNbxtHW[i]['ott']=='spotv':
     GrMLvOEahPmgyJcjdkiYTBAFNbxtlq='스포츠'
    else:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtlq='-'
    GrMLvOEahPmgyJcjdkiYTBAFNbxtHW[i]['genrenm']=GrMLvOEahPmgyJcjdkiYTBAFNbxtlq
   else:
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtHW[i]['genrenm']not in GrMLvOEahPmgyJcjdkiYTBAFNbxtHX:GrMLvOEahPmgyJcjdkiYTBAFNbxtHX.add(GrMLvOEahPmgyJcjdkiYTBAFNbxtHW[i]['genrenm'])
  GrMLvOEahPmgyJcjdkiYTBAFNbxtHX.add('-')
  GrMLvOEahPmgyJcjdkiYTBAFNbxtKp('2')
  for GrMLvOEahPmgyJcjdkiYTBAFNbxtHU in GrMLvOEahPmgyJcjdkiYTBAFNbxtHX:
   for GrMLvOEahPmgyJcjdkiYTBAFNbxtHw in GrMLvOEahPmgyJcjdkiYTBAFNbxtHW:
    if GrMLvOEahPmgyJcjdkiYTBAFNbxtHw['genrenm']==GrMLvOEahPmgyJcjdkiYTBAFNbxtHU:
     GrMLvOEahPmgyJcjdkiYTBAFNbxtHR.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtHw)
  for GrMLvOEahPmgyJcjdkiYTBAFNbxtHw in GrMLvOEahPmgyJcjdkiYTBAFNbxtHW:
   if GrMLvOEahPmgyJcjdkiYTBAFNbxtHw['genrenm']not in GrMLvOEahPmgyJcjdkiYTBAFNbxtHX:
    GrMLvOEahPmgyJcjdkiYTBAFNbxtHf.append(GrMLvOEahPmgyJcjdkiYTBAFNbxtHw)
  GrMLvOEahPmgyJcjdkiYTBAFNbxtKp('3')
  GrMLvOEahPmgyJcjdkiYTBAFNbxtKu='d:\\job\\channelgenre.json'
  if os.path.isfile(GrMLvOEahPmgyJcjdkiYTBAFNbxtKu):os.remove(GrMLvOEahPmgyJcjdkiYTBAFNbxtKu)
  fp=GrMLvOEahPmgyJcjdkiYTBAFNbxtKW(GrMLvOEahPmgyJcjdkiYTBAFNbxtKu,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  GrMLvOEahPmgyJcjdkiYTBAFNbxtKl=GrMLvOEahPmgyJcjdkiYTBAFNbxtKe(GrMLvOEahPmgyJcjdkiYTBAFNbxtHR)
  i=0
  for GrMLvOEahPmgyJcjdkiYTBAFNbxtuR in GrMLvOEahPmgyJcjdkiYTBAFNbxtHR:
   i+=1
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuX =GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['channelid']
   GrMLvOEahPmgyJcjdkiYTBAFNbxtuU =GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['channelnm']
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKH =GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['ott']
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKQ ='%s.%s'%(GrMLvOEahPmgyJcjdkiYTBAFNbxtuX,GrMLvOEahPmgyJcjdkiYTBAFNbxtKH)
   GrMLvOEahPmgyJcjdkiYTBAFNbxtlq =GrMLvOEahPmgyJcjdkiYTBAFNbxtuR['genrenm']
   GrMLvOEahPmgyJcjdkiYTBAFNbxtKq='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(GrMLvOEahPmgyJcjdkiYTBAFNbxtKQ,GrMLvOEahPmgyJcjdkiYTBAFNbxtuU,GrMLvOEahPmgyJcjdkiYTBAFNbxtlq)
   if i<GrMLvOEahPmgyJcjdkiYTBAFNbxtKl:
    fp.write(GrMLvOEahPmgyJcjdkiYTBAFNbxtKq+',\n')
   else:
    fp.write(GrMLvOEahPmgyJcjdkiYTBAFNbxtKq+'\n')
  fp.write('}\n')
  fp.close()
  return GrMLvOEahPmgyJcjdkiYTBAFNbxtHX
# Created by pyminifier (https://github.com/liftoff/pyminifier)
