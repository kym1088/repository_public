__author__="NightRain"
import os
import sys
import xbmcaddon,xbmcvfs
import urllib
__cwd__=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
__lib__=os.path.join(__cwd__,'resources','lib')
sys.path.append(__lib__)
from boritvServiceRun import*
OxelkDgRNmKjEwSQsnFIdLvMqBiHXJ=xbmc.Monitor()
OxelkDgRNmKjEwSQsnFIdLvMqBiHXT=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYW()
xbmc.sleep(OxelkDgRNmKjEwSQsnFIdLvMqBiHXT.START_INTERVAL)
while not OxelkDgRNmKjEwSQsnFIdLvMqBiHXJ.abortRequested():
 if OxelkDgRNmKjEwSQsnFIdLvMqBiHXJ.waitForAbort(OxelkDgRNmKjEwSQsnFIdLvMqBiHXT.INTERVAL):
  break
 OxelkDgRNmKjEwSQsnFIdLvMqBiHXT.service_run()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
