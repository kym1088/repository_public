__author__="NightRain"
pHCgkhGBxiuKRQzlLTOjVaUDXnbtYm=str
pHCgkhGBxiuKRQzlLTOjVaUDXnbtYP=True
pHCgkhGBxiuKRQzlLTOjVaUDXnbtYw=False
pHCgkhGBxiuKRQzlLTOjVaUDXnbtYy=print
pHCgkhGBxiuKRQzlLTOjVaUDXnbtYo=open
pHCgkhGBxiuKRQzlLTOjVaUDXnbtYJ=Exception
pHCgkhGBxiuKRQzlLTOjVaUDXnbtWY=int
import json
import time
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 pHCgkhGBxiuKRQzlLTOjVaUDXnbtYr='ADDON'
except:
 pHCgkhGBxiuKRQzlLTOjVaUDXnbtYr='SINGLE'
if pHCgkhGBxiuKRQzlLTOjVaUDXnbtYr=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYc=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYm(string).encode('utf-8','ignore')
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYE=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,pHCgkhGBxiuKRQzlLTOjVaUDXnbtYc),level=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYE)
 def addon_getautoepg():
  return pHCgkhGBxiuKRQzlLTOjVaUDXnbtYP if __addon__.getSetting('autoEpg')=='true' else pHCgkhGBxiuKRQzlLTOjVaUDXnbtYw
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYy(string)
 def addon_getautoepg():
  return pHCgkhGBxiuKRQzlLTOjVaUDXnbtYP
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class pHCgkhGBxiuKRQzlLTOjVaUDXnbtYW():
 def __init__(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs):
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.START_INTERVAL =10 
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.INTERVAL =10 
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_FILETAGNM ='date_makeepg'
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_MAKEDATE ='-' 
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_WILL_TM =-1 
 def Get_Now_Datetime(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs):
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYA ='-'
  if pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_MAKEDATE=='-':
   try:
    fp=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYo(addon_epgupdate_confignm(),'r',-1,'utf-8')
    pHCgkhGBxiuKRQzlLTOjVaUDXnbtYF= json.load(fp)
    fp.close()
    pHCgkhGBxiuKRQzlLTOjVaUDXnbtYA=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYF[pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_FILETAGNM]
   except pHCgkhGBxiuKRQzlLTOjVaUDXnbtYJ as exception:
    return 2 
  else:
   pHCgkhGBxiuKRQzlLTOjVaUDXnbtYA=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_MAKEDATE
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYS =pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.Get_Now_Datetime()
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYN=(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYS-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYe =pHCgkhGBxiuKRQzlLTOjVaUDXnbtYS.strftime('%Y-%m-%d')
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYI =pHCgkhGBxiuKRQzlLTOjVaUDXnbtYS.strftime('%H')
  if pHCgkhGBxiuKRQzlLTOjVaUDXnbtYA==pHCgkhGBxiuKRQzlLTOjVaUDXnbtYe: return-1
  if pHCgkhGBxiuKRQzlLTOjVaUDXnbtYA==pHCgkhGBxiuKRQzlLTOjVaUDXnbtYN and pHCgkhGBxiuKRQzlLTOjVaUDXnbtYI=='00':return 30
  return 2
 def MakeEpg_RandomTm(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs,mintm):
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYf=(mintm*60)+random.randint(0,60)
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYS =pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.Get_Now_Datetime()
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYq =(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYS+datetime.timedelta(seconds=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYf)).strftime('%Y%m%d%H%M%S')
  return pHCgkhGBxiuKRQzlLTOjVaUDXnbtWY(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYq)
 def MakeEpg_SaveJson(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs):
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYF={pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_FILETAGNM:pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYo(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYF,fp)
   fp.close()
  except pHCgkhGBxiuKRQzlLTOjVaUDXnbtYJ as exception:
   return
 def service_run(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs):
  if addon_getautoepg()==pHCgkhGBxiuKRQzlLTOjVaUDXnbtYw:return
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYM=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.MakeEpg_DateCheck()
  if pHCgkhGBxiuKRQzlLTOjVaUDXnbtYM<0:
   return
  if pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_WILL_TM<0:
   pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_WILL_TM=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.MakeEpg_RandomTm(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYM)
   addon_log('EPG_WILL_TM --> '+pHCgkhGBxiuKRQzlLTOjVaUDXnbtYm(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_WILL_TM))
  else:
   pHCgkhGBxiuKRQzlLTOjVaUDXnbtYe=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.Get_Now_Datetime()
   if pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_WILL_TM<pHCgkhGBxiuKRQzlLTOjVaUDXnbtWY(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYe.strftime('%Y%m%d%H%M%S')):
    addon_log('make epg')
    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
    pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.MakeEpg_SaveJson()
    pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_MAKEDATE=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYe.strftime('%Y-%m-%d')
    pHCgkhGBxiuKRQzlLTOjVaUDXnbtYs.EPG_WILL_TM =-1
   else:
    pass
  pass
if __name__=="__main__":
 addon_log('__main__')
 pHCgkhGBxiuKRQzlLTOjVaUDXnbtYd=pHCgkhGBxiuKRQzlLTOjVaUDXnbtYW()
 time.sleep(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYd.START_INTERVAL)
 while pHCgkhGBxiuKRQzlLTOjVaUDXnbtYP:
  time.sleep(pHCgkhGBxiuKRQzlLTOjVaUDXnbtYd.INTERVAL)
  pHCgkhGBxiuKRQzlLTOjVaUDXnbtYd.service_run()
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
