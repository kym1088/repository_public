__author__="NightRain"
zevDRWUTCFforgOaNJMKHbIjPXpmBV=str
zevDRWUTCFforgOaNJMKHbIjPXpmBs=True
zevDRWUTCFforgOaNJMKHbIjPXpmBx=False
zevDRWUTCFforgOaNJMKHbIjPXpmBE=print
zevDRWUTCFforgOaNJMKHbIjPXpmnB=open
zevDRWUTCFforgOaNJMKHbIjPXpmni=Exception
zevDRWUTCFforgOaNJMKHbIjPXpmnh=int
zevDRWUTCFforgOaNJMKHbIjPXpmnq=KeyboardInterrupt
zevDRWUTCFforgOaNJMKHbIjPXpmnG=SystemExit
import json
import time
import threading
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 zevDRWUTCFforgOaNJMKHbIjPXpmBi='ADDON'
except:
 zevDRWUTCFforgOaNJMKHbIjPXpmBi='SINGLE'
if zevDRWUTCFforgOaNJMKHbIjPXpmBi=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  zevDRWUTCFforgOaNJMKHbIjPXpmBh=zevDRWUTCFforgOaNJMKHbIjPXpmBV(string).encode('utf-8','ignore')
  zevDRWUTCFforgOaNJMKHbIjPXpmBq=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,zevDRWUTCFforgOaNJMKHbIjPXpmBh),level=zevDRWUTCFforgOaNJMKHbIjPXpmBq)
 def addon_getautoepg():
  return zevDRWUTCFforgOaNJMKHbIjPXpmBs if __addon__.getSetting('autoEpg')=='true' else zevDRWUTCFforgOaNJMKHbIjPXpmBx
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  zevDRWUTCFforgOaNJMKHbIjPXpmBE(string)
 def addon_getautoepg():
  return zevDRWUTCFforgOaNJMKHbIjPXpmBs
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class zevDRWUTCFforgOaNJMKHbIjPXpmBn(threading.Thread):
 def __init__(zevDRWUTCFforgOaNJMKHbIjPXpmBG,zevDRWUTCFforgOaNJMKHbIjPXpmBc):
  zevDRWUTCFforgOaNJMKHbIjPXpmBG.STOPPED =zevDRWUTCFforgOaNJMKHbIjPXpmBc
  zevDRWUTCFforgOaNJMKHbIjPXpmBG.START_INTERVAL =10 
  zevDRWUTCFforgOaNJMKHbIjPXpmBG.INTERVAL =10 
  zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_FILETAGNM ='date_makeepg'
  zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_MAKEDATE ='-' 
  zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_WILL_TM =-1 
  threading.Thread.__init__(zevDRWUTCFforgOaNJMKHbIjPXpmBG)
 def Get_Now_Datetime(zevDRWUTCFforgOaNJMKHbIjPXpmBG):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(zevDRWUTCFforgOaNJMKHbIjPXpmBG):
  zevDRWUTCFforgOaNJMKHbIjPXpmBA ='-'
  if zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_MAKEDATE=='-':
   try:
    fp=zevDRWUTCFforgOaNJMKHbIjPXpmnB(addon_epgupdate_confignm(),'r',-1,'utf-8')
    zevDRWUTCFforgOaNJMKHbIjPXpmBu= json.load(fp)
    fp.close()
    zevDRWUTCFforgOaNJMKHbIjPXpmBA=zevDRWUTCFforgOaNJMKHbIjPXpmBu[zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_FILETAGNM]
   except zevDRWUTCFforgOaNJMKHbIjPXpmni as exception:
    return 5 
  else:
   zevDRWUTCFforgOaNJMKHbIjPXpmBA=zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_MAKEDATE
  zevDRWUTCFforgOaNJMKHbIjPXpmBk =zevDRWUTCFforgOaNJMKHbIjPXpmBG.Get_Now_Datetime()
  zevDRWUTCFforgOaNJMKHbIjPXpmBS=(zevDRWUTCFforgOaNJMKHbIjPXpmBk-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  zevDRWUTCFforgOaNJMKHbIjPXpmBy =zevDRWUTCFforgOaNJMKHbIjPXpmBk.strftime('%Y-%m-%d')
  zevDRWUTCFforgOaNJMKHbIjPXpmBd =zevDRWUTCFforgOaNJMKHbIjPXpmBk.strftime('%H')
  if zevDRWUTCFforgOaNJMKHbIjPXpmBA==zevDRWUTCFforgOaNJMKHbIjPXpmBy: return-1
  if zevDRWUTCFforgOaNJMKHbIjPXpmBA==zevDRWUTCFforgOaNJMKHbIjPXpmBS and zevDRWUTCFforgOaNJMKHbIjPXpmBd=='00':return 30
  return 5
 def MakeEpg_RandomTm(zevDRWUTCFforgOaNJMKHbIjPXpmBG,mintm):
  zevDRWUTCFforgOaNJMKHbIjPXpmBY=(mintm*60)+random.randint(0,300)
  zevDRWUTCFforgOaNJMKHbIjPXpmBk =zevDRWUTCFforgOaNJMKHbIjPXpmBG.Get_Now_Datetime()
  zevDRWUTCFforgOaNJMKHbIjPXpmBl =(zevDRWUTCFforgOaNJMKHbIjPXpmBk+datetime.timedelta(seconds=zevDRWUTCFforgOaNJMKHbIjPXpmBY)).strftime('%Y%m%d%H%M%S')
  return zevDRWUTCFforgOaNJMKHbIjPXpmnh(zevDRWUTCFforgOaNJMKHbIjPXpmBl)
 def MakeEpg_SaveJson(zevDRWUTCFforgOaNJMKHbIjPXpmBG):
  zevDRWUTCFforgOaNJMKHbIjPXpmBu={zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_FILETAGNM:zevDRWUTCFforgOaNJMKHbIjPXpmBG.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=zevDRWUTCFforgOaNJMKHbIjPXpmnB(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(zevDRWUTCFforgOaNJMKHbIjPXpmBu,fp)
   fp.close()
  except zevDRWUTCFforgOaNJMKHbIjPXpmni as exception:
   return
 def run(zevDRWUTCFforgOaNJMKHbIjPXpmBG):
  time.sleep(zevDRWUTCFforgOaNJMKHbIjPXpmBG.START_INTERVAL)
  while not zevDRWUTCFforgOaNJMKHbIjPXpmBG.STOPPED.wait(zevDRWUTCFforgOaNJMKHbIjPXpmBG.INTERVAL):
   if addon_getautoepg()==zevDRWUTCFforgOaNJMKHbIjPXpmBx:continue
   zevDRWUTCFforgOaNJMKHbIjPXpmBw=zevDRWUTCFforgOaNJMKHbIjPXpmBG.MakeEpg_DateCheck()
   if zevDRWUTCFforgOaNJMKHbIjPXpmBw<0:
    continue
   if zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_WILL_TM<0:
    zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_WILL_TM=zevDRWUTCFforgOaNJMKHbIjPXpmBG.MakeEpg_RandomTm(zevDRWUTCFforgOaNJMKHbIjPXpmBw)
    addon_log('EPG_WILL_TM --> '+zevDRWUTCFforgOaNJMKHbIjPXpmBV(zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_WILL_TM))
   else:
    zevDRWUTCFforgOaNJMKHbIjPXpmBy=zevDRWUTCFforgOaNJMKHbIjPXpmBG.Get_Now_Datetime()
    if zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_WILL_TM<zevDRWUTCFforgOaNJMKHbIjPXpmnh(zevDRWUTCFforgOaNJMKHbIjPXpmBy.strftime('%Y%m%d%H%M%S')):
     addon_log('make epg')
     xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
     zevDRWUTCFforgOaNJMKHbIjPXpmBG.MakeEpg_SaveJson()
     zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_MAKEDATE=zevDRWUTCFforgOaNJMKHbIjPXpmBy.strftime('%Y-%m-%d')
     zevDRWUTCFforgOaNJMKHbIjPXpmBG.EPG_WILL_TM =-1
    else:
     pass
   pass
if __name__=="__main__":
 zevDRWUTCFforgOaNJMKHbIjPXpmBQ =threading.Event()
 zevDRWUTCFforgOaNJMKHbIjPXpmBL=zevDRWUTCFforgOaNJMKHbIjPXpmBn(zevDRWUTCFforgOaNJMKHbIjPXpmBQ)
 zevDRWUTCFforgOaNJMKHbIjPXpmBL.start()
 try:
  while zevDRWUTCFforgOaNJMKHbIjPXpmBs:
   time.sleep(1)
   pass
 except(zevDRWUTCFforgOaNJMKHbIjPXpmnq,zevDRWUTCFforgOaNJMKHbIjPXpmnG):
  zevDRWUTCFforgOaNJMKHbIjPXpmBQ.set()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
