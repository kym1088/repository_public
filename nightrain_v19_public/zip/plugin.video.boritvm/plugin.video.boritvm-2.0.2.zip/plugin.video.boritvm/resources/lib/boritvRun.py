__author__="NightRain"
QCOeTimSvxMjAJXnzyYEltoNadrhRg=object
QCOeTimSvxMjAJXnzyYEltoNadrhRK=False
QCOeTimSvxMjAJXnzyYEltoNadrhRF=None
QCOeTimSvxMjAJXnzyYEltoNadrhRq=True
QCOeTimSvxMjAJXnzyYEltoNadrhRu=len
QCOeTimSvxMjAJXnzyYEltoNadrhRs=str
QCOeTimSvxMjAJXnzyYEltoNadrhRb=open
QCOeTimSvxMjAJXnzyYEltoNadrhfk=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
QCOeTimSvxMjAJXnzyYEltoNadrhkR=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
QCOeTimSvxMjAJXnzyYEltoNadrhkf='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
QCOeTimSvxMjAJXnzyYEltoNadrhkV=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class QCOeTimSvxMjAJXnzyYEltoNadrhkI(QCOeTimSvxMjAJXnzyYEltoNadrhRg):
 def __init__(QCOeTimSvxMjAJXnzyYEltoNadrhkH,QCOeTimSvxMjAJXnzyYEltoNadrhkW,QCOeTimSvxMjAJXnzyYEltoNadrhkw,QCOeTimSvxMjAJXnzyYEltoNadrhkU):
  QCOeTimSvxMjAJXnzyYEltoNadrhkH._addon_url =QCOeTimSvxMjAJXnzyYEltoNadrhkW
  QCOeTimSvxMjAJXnzyYEltoNadrhkH._addon_handle =QCOeTimSvxMjAJXnzyYEltoNadrhkw
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.main_params =QCOeTimSvxMjAJXnzyYEltoNadrhkU
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_FILE_PATH ='' 
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_FILE_NAME ='' 
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVE =QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONTVING =QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONSPOTV =QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVERADIO=QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVEHOME =QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONSPOTVPAY =QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_DISPLAYNM =QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.BoritvObj =CRDeXmfaHgdosJEtqOrclzSwhujMyP() 
 def addon_noti(QCOeTimSvxMjAJXnzyYEltoNadrhkH,sting):
  try:
   QCOeTimSvxMjAJXnzyYEltoNadrhkG=xbmcgui.Dialog()
   QCOeTimSvxMjAJXnzyYEltoNadrhkG.notification(__addonname__,sting)
  except:
   QCOeTimSvxMjAJXnzyYEltoNadrhRF
 def addon_log(QCOeTimSvxMjAJXnzyYEltoNadrhkH,string):
  try:
   QCOeTimSvxMjAJXnzyYEltoNadrhkc=string.encode('utf-8','ignore')
  except:
   QCOeTimSvxMjAJXnzyYEltoNadrhkc='addonException: addon_log'
  QCOeTimSvxMjAJXnzyYEltoNadrhkp=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,QCOeTimSvxMjAJXnzyYEltoNadrhkc),level=QCOeTimSvxMjAJXnzyYEltoNadrhkp)
 def get_keyboard_input(QCOeTimSvxMjAJXnzyYEltoNadrhkH,QCOeTimSvxMjAJXnzyYEltoNadrhkL):
  QCOeTimSvxMjAJXnzyYEltoNadrhkB=QCOeTimSvxMjAJXnzyYEltoNadrhRF
  kb=xbmc.Keyboard()
  kb.setHeading(QCOeTimSvxMjAJXnzyYEltoNadrhkL)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   QCOeTimSvxMjAJXnzyYEltoNadrhkB=kb.getText()
  return QCOeTimSvxMjAJXnzyYEltoNadrhkB
 def add_dir(QCOeTimSvxMjAJXnzyYEltoNadrhkH,label,sublabel='',img='',infoLabels=QCOeTimSvxMjAJXnzyYEltoNadrhRF,isFolder=QCOeTimSvxMjAJXnzyYEltoNadrhRq,params=''):
  QCOeTimSvxMjAJXnzyYEltoNadrhkP='%s?%s'%(QCOeTimSvxMjAJXnzyYEltoNadrhkH._addon_url,urllib.parse.urlencode(params))
  if sublabel:QCOeTimSvxMjAJXnzyYEltoNadrhkL='%s < %s >'%(label,sublabel)
  else: QCOeTimSvxMjAJXnzyYEltoNadrhkL=label
  if not img:img='DefaultFolder.png'
  QCOeTimSvxMjAJXnzyYEltoNadrhkg=xbmcgui.ListItem(QCOeTimSvxMjAJXnzyYEltoNadrhkL)
  QCOeTimSvxMjAJXnzyYEltoNadrhkg.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:QCOeTimSvxMjAJXnzyYEltoNadrhkg.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:QCOeTimSvxMjAJXnzyYEltoNadrhkg.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(QCOeTimSvxMjAJXnzyYEltoNadrhkH._addon_handle,QCOeTimSvxMjAJXnzyYEltoNadrhkP,QCOeTimSvxMjAJXnzyYEltoNadrhkg,isFolder)
 def make_M3u_Filename(QCOeTimSvxMjAJXnzyYEltoNadrhkH):
  return QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_FILE_PATH+QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(QCOeTimSvxMjAJXnzyYEltoNadrhkH):
  return QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_FILE_PATH+QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_FILE_NAME+'.xml'
 def dp_Main_List(QCOeTimSvxMjAJXnzyYEltoNadrhkH):
  for QCOeTimSvxMjAJXnzyYEltoNadrhkK in QCOeTimSvxMjAJXnzyYEltoNadrhkR:
   QCOeTimSvxMjAJXnzyYEltoNadrhkL=QCOeTimSvxMjAJXnzyYEltoNadrhkK.get('title')
   QCOeTimSvxMjAJXnzyYEltoNadrhkF={'mode':QCOeTimSvxMjAJXnzyYEltoNadrhkK.get('mode'),'sType':QCOeTimSvxMjAJXnzyYEltoNadrhkK.get('sType'),'sName':QCOeTimSvxMjAJXnzyYEltoNadrhkK.get('sName')}
   if QCOeTimSvxMjAJXnzyYEltoNadrhkK.get('mode')=='XXX':
    QCOeTimSvxMjAJXnzyYEltoNadrhkq=QCOeTimSvxMjAJXnzyYEltoNadrhRK
   else:
    QCOeTimSvxMjAJXnzyYEltoNadrhkq=QCOeTimSvxMjAJXnzyYEltoNadrhRq
   QCOeTimSvxMjAJXnzyYEltoNadrhku=QCOeTimSvxMjAJXnzyYEltoNadrhRq
   if QCOeTimSvxMjAJXnzyYEltoNadrhkK.get('mode')=='ADD_M3U':
    if QCOeTimSvxMjAJXnzyYEltoNadrhkK.get('sType')=='wavve' and QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVE==QCOeTimSvxMjAJXnzyYEltoNadrhRK:QCOeTimSvxMjAJXnzyYEltoNadrhku=QCOeTimSvxMjAJXnzyYEltoNadrhRK
    if QCOeTimSvxMjAJXnzyYEltoNadrhkK.get('sType')=='tving' and QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONTVING==QCOeTimSvxMjAJXnzyYEltoNadrhRK:QCOeTimSvxMjAJXnzyYEltoNadrhku=QCOeTimSvxMjAJXnzyYEltoNadrhRK
    if QCOeTimSvxMjAJXnzyYEltoNadrhkK.get('sType')=='spotv' and QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONSPOTV==QCOeTimSvxMjAJXnzyYEltoNadrhRK:QCOeTimSvxMjAJXnzyYEltoNadrhku=QCOeTimSvxMjAJXnzyYEltoNadrhRK
   if QCOeTimSvxMjAJXnzyYEltoNadrhku==QCOeTimSvxMjAJXnzyYEltoNadrhRq:
    QCOeTimSvxMjAJXnzyYEltoNadrhkH.add_dir(QCOeTimSvxMjAJXnzyYEltoNadrhkL,sublabel='',img='',infoLabels=QCOeTimSvxMjAJXnzyYEltoNadrhRF,isFolder=QCOeTimSvxMjAJXnzyYEltoNadrhkq,params=QCOeTimSvxMjAJXnzyYEltoNadrhkF)
  if QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhkR)>0:xbmcplugin.endOfDirectory(QCOeTimSvxMjAJXnzyYEltoNadrhkH._addon_handle,cacheToDisc=QCOeTimSvxMjAJXnzyYEltoNadrhRq)
 def dp_Delete_M3u(QCOeTimSvxMjAJXnzyYEltoNadrhkH,args):
  QCOeTimSvxMjAJXnzyYEltoNadrhkG=xbmcgui.Dialog()
  QCOeTimSvxMjAJXnzyYEltoNadrhkb=QCOeTimSvxMjAJXnzyYEltoNadrhkG.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if QCOeTimSvxMjAJXnzyYEltoNadrhkb==QCOeTimSvxMjAJXnzyYEltoNadrhRK:sys.exit()
  QCOeTimSvxMjAJXnzyYEltoNadrhIk=QCOeTimSvxMjAJXnzyYEltoNadrhkH.make_M3u_Filename()
  if os.path.isfile(QCOeTimSvxMjAJXnzyYEltoNadrhIk):os.remove(QCOeTimSvxMjAJXnzyYEltoNadrhIk)
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(QCOeTimSvxMjAJXnzyYEltoNadrhkH,args):
  QCOeTimSvxMjAJXnzyYEltoNadrhIR=args.get('sType')
  QCOeTimSvxMjAJXnzyYEltoNadrhIf=args.get('sName')
  QCOeTimSvxMjAJXnzyYEltoNadrhkG=xbmcgui.Dialog()
  QCOeTimSvxMjAJXnzyYEltoNadrhkb=QCOeTimSvxMjAJXnzyYEltoNadrhkG.yesno((QCOeTimSvxMjAJXnzyYEltoNadrhIf+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if QCOeTimSvxMjAJXnzyYEltoNadrhkb==QCOeTimSvxMjAJXnzyYEltoNadrhRK:sys.exit()
  QCOeTimSvxMjAJXnzyYEltoNadrhIV =[]
  QCOeTimSvxMjAJXnzyYEltoNadrhIH =[]
  QCOeTimSvxMjAJXnzyYEltoNadrhIW=[]
  if QCOeTimSvxMjAJXnzyYEltoNadrhIR=='all':
   QCOeTimSvxMjAJXnzyYEltoNadrhIk=QCOeTimSvxMjAJXnzyYEltoNadrhkH.make_M3u_Filename()
   if os.path.isfile(QCOeTimSvxMjAJXnzyYEltoNadrhIk):os.remove(QCOeTimSvxMjAJXnzyYEltoNadrhIk)
  if(QCOeTimSvxMjAJXnzyYEltoNadrhIR=='wavve' or QCOeTimSvxMjAJXnzyYEltoNadrhIR=='all')and QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVE:
   QCOeTimSvxMjAJXnzyYEltoNadrhIw=QCOeTimSvxMjAJXnzyYEltoNadrhkH.BoritvObj.Get_ChannelList_Wavve(exceptGroup=QCOeTimSvxMjAJXnzyYEltoNadrhkH.make_EexceptGroup_Wavve())
   if QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhIw)!=0:QCOeTimSvxMjAJXnzyYEltoNadrhIV.extend(QCOeTimSvxMjAJXnzyYEltoNadrhIw)
   QCOeTimSvxMjAJXnzyYEltoNadrhIW=QCOeTimSvxMjAJXnzyYEltoNadrhkH.get_radio_list()
   QCOeTimSvxMjAJXnzyYEltoNadrhkH.addon_log('wavve cnt ----> '+QCOeTimSvxMjAJXnzyYEltoNadrhRs(QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhIw)))
  if(QCOeTimSvxMjAJXnzyYEltoNadrhIR=='tving' or QCOeTimSvxMjAJXnzyYEltoNadrhIR=='all')and QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONTVING:
   QCOeTimSvxMjAJXnzyYEltoNadrhIw=QCOeTimSvxMjAJXnzyYEltoNadrhkH.BoritvObj.Get_ChannelList_Tving()
   if QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhIw)!=0:QCOeTimSvxMjAJXnzyYEltoNadrhIV.extend(QCOeTimSvxMjAJXnzyYEltoNadrhIw)
   QCOeTimSvxMjAJXnzyYEltoNadrhkH.addon_log('tving cnt ----> '+QCOeTimSvxMjAJXnzyYEltoNadrhRs(QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhIw)))
  if(QCOeTimSvxMjAJXnzyYEltoNadrhIR=='spotv' or QCOeTimSvxMjAJXnzyYEltoNadrhIR=='all')and QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONSPOTV:
   QCOeTimSvxMjAJXnzyYEltoNadrhIw=QCOeTimSvxMjAJXnzyYEltoNadrhkH.BoritvObj.Get_ChannelList_Spotv(payyn=QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONSPOTVPAY)
   if QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhIw)!=0:QCOeTimSvxMjAJXnzyYEltoNadrhIV.extend(QCOeTimSvxMjAJXnzyYEltoNadrhIw)
   QCOeTimSvxMjAJXnzyYEltoNadrhkH.addon_log('spotv cnt ----> '+QCOeTimSvxMjAJXnzyYEltoNadrhRs(QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhIw)))
  if QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhIV)==0:
   QCOeTimSvxMjAJXnzyYEltoNadrhkH.addon_noti(__language__(30909).encode('utf8'))
   return
  for QCOeTimSvxMjAJXnzyYEltoNadrhIU in QCOeTimSvxMjAJXnzyYEltoNadrhkH.BoritvObj.INIT_GENRESORT:
   for QCOeTimSvxMjAJXnzyYEltoNadrhID in QCOeTimSvxMjAJXnzyYEltoNadrhIV:
    if QCOeTimSvxMjAJXnzyYEltoNadrhID['genrenm']==QCOeTimSvxMjAJXnzyYEltoNadrhIU:
     QCOeTimSvxMjAJXnzyYEltoNadrhIH.append(QCOeTimSvxMjAJXnzyYEltoNadrhID)
  for QCOeTimSvxMjAJXnzyYEltoNadrhID in QCOeTimSvxMjAJXnzyYEltoNadrhIV:
   if QCOeTimSvxMjAJXnzyYEltoNadrhID['genrenm']not in QCOeTimSvxMjAJXnzyYEltoNadrhkH.BoritvObj.INIT_GENRESORT:
    QCOeTimSvxMjAJXnzyYEltoNadrhIH.append(QCOeTimSvxMjAJXnzyYEltoNadrhID)
  try:
   QCOeTimSvxMjAJXnzyYEltoNadrhIk=QCOeTimSvxMjAJXnzyYEltoNadrhkH.make_M3u_Filename()
   if os.path.isfile(QCOeTimSvxMjAJXnzyYEltoNadrhIk):
    fp=QCOeTimSvxMjAJXnzyYEltoNadrhRb(QCOeTimSvxMjAJXnzyYEltoNadrhIk,'a',-1,'utf-8')
   else:
    fp=QCOeTimSvxMjAJXnzyYEltoNadrhRb(QCOeTimSvxMjAJXnzyYEltoNadrhIk,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for QCOeTimSvxMjAJXnzyYEltoNadrhIG in QCOeTimSvxMjAJXnzyYEltoNadrhIH:
    QCOeTimSvxMjAJXnzyYEltoNadrhIc =QCOeTimSvxMjAJXnzyYEltoNadrhIG['channelid']
    QCOeTimSvxMjAJXnzyYEltoNadrhIp =QCOeTimSvxMjAJXnzyYEltoNadrhIG['channelnm']
    QCOeTimSvxMjAJXnzyYEltoNadrhIB=QCOeTimSvxMjAJXnzyYEltoNadrhIG['channelimg']
    QCOeTimSvxMjAJXnzyYEltoNadrhIP =QCOeTimSvxMjAJXnzyYEltoNadrhIG['ott']
    QCOeTimSvxMjAJXnzyYEltoNadrhIL ='%s.%s'%(QCOeTimSvxMjAJXnzyYEltoNadrhIc,QCOeTimSvxMjAJXnzyYEltoNadrhIP)
    QCOeTimSvxMjAJXnzyYEltoNadrhIg=QCOeTimSvxMjAJXnzyYEltoNadrhIG['genrenm']
    if QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_DISPLAYNM:
     QCOeTimSvxMjAJXnzyYEltoNadrhIp='%s (%s)'%(QCOeTimSvxMjAJXnzyYEltoNadrhIp,QCOeTimSvxMjAJXnzyYEltoNadrhIP)
    if QCOeTimSvxMjAJXnzyYEltoNadrhIc in QCOeTimSvxMjAJXnzyYEltoNadrhIW:
     QCOeTimSvxMjAJXnzyYEltoNadrhIK='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(QCOeTimSvxMjAJXnzyYEltoNadrhIL,QCOeTimSvxMjAJXnzyYEltoNadrhIp,QCOeTimSvxMjAJXnzyYEltoNadrhIg,QCOeTimSvxMjAJXnzyYEltoNadrhIB,QCOeTimSvxMjAJXnzyYEltoNadrhIp)
    else:
     QCOeTimSvxMjAJXnzyYEltoNadrhIK='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(QCOeTimSvxMjAJXnzyYEltoNadrhIL,QCOeTimSvxMjAJXnzyYEltoNadrhIp,QCOeTimSvxMjAJXnzyYEltoNadrhIg,QCOeTimSvxMjAJXnzyYEltoNadrhIB,QCOeTimSvxMjAJXnzyYEltoNadrhIp)
    if QCOeTimSvxMjAJXnzyYEltoNadrhIP=='wavve':
     QCOeTimSvxMjAJXnzyYEltoNadrhIF ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(QCOeTimSvxMjAJXnzyYEltoNadrhIc)
    elif QCOeTimSvxMjAJXnzyYEltoNadrhIP=='tving':
     QCOeTimSvxMjAJXnzyYEltoNadrhIF ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(QCOeTimSvxMjAJXnzyYEltoNadrhIc)
    elif QCOeTimSvxMjAJXnzyYEltoNadrhIP=='spotv':
     QCOeTimSvxMjAJXnzyYEltoNadrhIF ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(QCOeTimSvxMjAJXnzyYEltoNadrhIc)
    fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhIK)
    fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhIF)
   fp.close()
  except:
   QCOeTimSvxMjAJXnzyYEltoNadrhkH.addon_noti(__language__(30910).encode('utf8'))
   return
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.addon_noti((QCOeTimSvxMjAJXnzyYEltoNadrhIf+' '+__language__(30908)).encode('utf8'))
 def dp_Make_Epg(QCOeTimSvxMjAJXnzyYEltoNadrhkH,args):
  QCOeTimSvxMjAJXnzyYEltoNadrhIR=args.get('sType')
  QCOeTimSvxMjAJXnzyYEltoNadrhIf=args.get('sName')
  QCOeTimSvxMjAJXnzyYEltoNadrhIq=args.get('sNoti')
  if QCOeTimSvxMjAJXnzyYEltoNadrhIq!='N':
   QCOeTimSvxMjAJXnzyYEltoNadrhkG=xbmcgui.Dialog()
   QCOeTimSvxMjAJXnzyYEltoNadrhkb=QCOeTimSvxMjAJXnzyYEltoNadrhkG.yesno((QCOeTimSvxMjAJXnzyYEltoNadrhIf+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if QCOeTimSvxMjAJXnzyYEltoNadrhkb==QCOeTimSvxMjAJXnzyYEltoNadrhRK:sys.exit()
  QCOeTimSvxMjAJXnzyYEltoNadrhIu=[]
  QCOeTimSvxMjAJXnzyYEltoNadrhIs=[]
  if(QCOeTimSvxMjAJXnzyYEltoNadrhIR=='wavve' or QCOeTimSvxMjAJXnzyYEltoNadrhIR=='all')and QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVE:
   QCOeTimSvxMjAJXnzyYEltoNadrhIb,QCOeTimSvxMjAJXnzyYEltoNadrhRk=QCOeTimSvxMjAJXnzyYEltoNadrhkH.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=QCOeTimSvxMjAJXnzyYEltoNadrhkH.make_EexceptGroup_Wavve())
   if QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhRk)!=0:
    QCOeTimSvxMjAJXnzyYEltoNadrhIu.extend(QCOeTimSvxMjAJXnzyYEltoNadrhIb)
    QCOeTimSvxMjAJXnzyYEltoNadrhIs.extend(QCOeTimSvxMjAJXnzyYEltoNadrhRk)
  if(QCOeTimSvxMjAJXnzyYEltoNadrhIR=='tving' or QCOeTimSvxMjAJXnzyYEltoNadrhIR=='all')and QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONTVING:
   QCOeTimSvxMjAJXnzyYEltoNadrhIb,QCOeTimSvxMjAJXnzyYEltoNadrhRk=QCOeTimSvxMjAJXnzyYEltoNadrhkH.BoritvObj.Get_EpgInfo_Tving()
   if QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhRk)!=0:
    QCOeTimSvxMjAJXnzyYEltoNadrhIu.extend(QCOeTimSvxMjAJXnzyYEltoNadrhIb)
    QCOeTimSvxMjAJXnzyYEltoNadrhIs.extend(QCOeTimSvxMjAJXnzyYEltoNadrhRk)
  if(QCOeTimSvxMjAJXnzyYEltoNadrhIR=='spotv' or QCOeTimSvxMjAJXnzyYEltoNadrhIR=='all')and QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONSPOTV:
   QCOeTimSvxMjAJXnzyYEltoNadrhIb,QCOeTimSvxMjAJXnzyYEltoNadrhRk=QCOeTimSvxMjAJXnzyYEltoNadrhkH.BoritvObj.Get_EpgInfo_Spotv(payyn=QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONSPOTVPAY)
   if QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhRk)!=0:
    QCOeTimSvxMjAJXnzyYEltoNadrhIu.extend(QCOeTimSvxMjAJXnzyYEltoNadrhIb)
    QCOeTimSvxMjAJXnzyYEltoNadrhIs.extend(QCOeTimSvxMjAJXnzyYEltoNadrhRk)
  if QCOeTimSvxMjAJXnzyYEltoNadrhRu(QCOeTimSvxMjAJXnzyYEltoNadrhIs)==0:
   if QCOeTimSvxMjAJXnzyYEltoNadrhIq!='N':QCOeTimSvxMjAJXnzyYEltoNadrhkH.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   QCOeTimSvxMjAJXnzyYEltoNadrhIk=QCOeTimSvxMjAJXnzyYEltoNadrhkH.make_Epg_Filename()
   fp=QCOeTimSvxMjAJXnzyYEltoNadrhRb(QCOeTimSvxMjAJXnzyYEltoNadrhIk,'w',-1,'utf-8')
   QCOeTimSvxMjAJXnzyYEltoNadrhRI='<?xml version="1.0" encoding="UTF-8"?>\n'
   QCOeTimSvxMjAJXnzyYEltoNadrhRf='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   QCOeTimSvxMjAJXnzyYEltoNadrhRV='<tv generator-info-name="boritv_epg">\n\n'
   QCOeTimSvxMjAJXnzyYEltoNadrhRH='\n</tv>\n'
   fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhRI)
   fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhRf)
   fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhRV)
   for QCOeTimSvxMjAJXnzyYEltoNadrhRW in QCOeTimSvxMjAJXnzyYEltoNadrhIu:
    QCOeTimSvxMjAJXnzyYEltoNadrhRw='  <channel id="%s.%s">\n' %(QCOeTimSvxMjAJXnzyYEltoNadrhRW.get('channelid'),QCOeTimSvxMjAJXnzyYEltoNadrhRW.get('ott'))
    QCOeTimSvxMjAJXnzyYEltoNadrhRU='    <display-name>%s</display-name>\n'%(QCOeTimSvxMjAJXnzyYEltoNadrhRW.get('channelnm'))
    QCOeTimSvxMjAJXnzyYEltoNadrhRD='    <icon src="%s" />\n' %(QCOeTimSvxMjAJXnzyYEltoNadrhRW.get('channelimg'))
    QCOeTimSvxMjAJXnzyYEltoNadrhRG='  </channel>\n\n'
    fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhRw)
    fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhRU)
    fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhRD)
    fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhRG)
   for QCOeTimSvxMjAJXnzyYEltoNadrhRW in QCOeTimSvxMjAJXnzyYEltoNadrhIs:
    QCOeTimSvxMjAJXnzyYEltoNadrhRw='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(QCOeTimSvxMjAJXnzyYEltoNadrhRW.get('startTime'),QCOeTimSvxMjAJXnzyYEltoNadrhRW.get('endTime'),QCOeTimSvxMjAJXnzyYEltoNadrhRW.get('channelid'),QCOeTimSvxMjAJXnzyYEltoNadrhRW.get('ott'))
    QCOeTimSvxMjAJXnzyYEltoNadrhRU='    <title lang="kr">%s</title>\n' %(QCOeTimSvxMjAJXnzyYEltoNadrhRW.get('title'))
    QCOeTimSvxMjAJXnzyYEltoNadrhRD='  </programme>\n\n'
    fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhRw)
    fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhRU)
    fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhRD)
   fp.write(QCOeTimSvxMjAJXnzyYEltoNadrhRH)
   fp.close()
  except:
   if QCOeTimSvxMjAJXnzyYEltoNadrhIq!='N':QCOeTimSvxMjAJXnzyYEltoNadrhkH.addon_noti(__language__(30910).encode('utf8'))
   return
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.MakeEpg_SaveJson()
  if QCOeTimSvxMjAJXnzyYEltoNadrhIq!='N':QCOeTimSvxMjAJXnzyYEltoNadrhkH.addon_noti((QCOeTimSvxMjAJXnzyYEltoNadrhIf+' '+__language__(30912)).encode('utf8'))
 def make_EexceptGroup_Wavve(QCOeTimSvxMjAJXnzyYEltoNadrhkH):
  QCOeTimSvxMjAJXnzyYEltoNadrhRc=[]
  if QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVERADIO==QCOeTimSvxMjAJXnzyYEltoNadrhRK:
   QCOeTimSvxMjAJXnzyYEltoNadrhRp={'broadcastid':'46584','genre':'10'}
   QCOeTimSvxMjAJXnzyYEltoNadrhRc.append(QCOeTimSvxMjAJXnzyYEltoNadrhRp)
  if QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVEHOME==QCOeTimSvxMjAJXnzyYEltoNadrhRK:
   QCOeTimSvxMjAJXnzyYEltoNadrhRp={'broadcastid':'46584','genre':'03'}
   QCOeTimSvxMjAJXnzyYEltoNadrhRc.append(QCOeTimSvxMjAJXnzyYEltoNadrhRp)
  return QCOeTimSvxMjAJXnzyYEltoNadrhRc
 def get_radio_list(QCOeTimSvxMjAJXnzyYEltoNadrhkH):
  if QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVERADIO==QCOeTimSvxMjAJXnzyYEltoNadrhRK:return[]
  QCOeTimSvxMjAJXnzyYEltoNadrhRp=[{'broadcastid':'46584','genre':'10'}]
  return QCOeTimSvxMjAJXnzyYEltoNadrhkH.BoritvObj.Get_ChannelList_WavveExcept(QCOeTimSvxMjAJXnzyYEltoNadrhRp)
 def check_config(QCOeTimSvxMjAJXnzyYEltoNadrhkH):
  QCOeTimSvxMjAJXnzyYEltoNadrhRB=QCOeTimSvxMjAJXnzyYEltoNadrhRq
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVE =QCOeTimSvxMjAJXnzyYEltoNadrhRq if __addon__.getSetting('onWavve')=='true' else QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONTVING =QCOeTimSvxMjAJXnzyYEltoNadrhRq if __addon__.getSetting('onTvng')=='true' else QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONSPOTV =QCOeTimSvxMjAJXnzyYEltoNadrhRq if __addon__.getSetting('onSpotv')=='true' else QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVERADIO=QCOeTimSvxMjAJXnzyYEltoNadrhRq if __addon__.getSetting('onWavveRadio')=='true' else QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVEHOME =QCOeTimSvxMjAJXnzyYEltoNadrhRq if __addon__.getSetting('onWavveHome')=='true' else QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONSPOTVPAY =QCOeTimSvxMjAJXnzyYEltoNadrhRq if __addon__.getSetting('onSpotvPay')=='true' else QCOeTimSvxMjAJXnzyYEltoNadrhRK
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_DISPLAYNM =QCOeTimSvxMjAJXnzyYEltoNadrhRq if __addon__.getSetting('displayOTTnm')=='true' else QCOeTimSvxMjAJXnzyYEltoNadrhRK
  if QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_FILE_PATH=='' or QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_FILE_NAME=='':QCOeTimSvxMjAJXnzyYEltoNadrhRB=QCOeTimSvxMjAJXnzyYEltoNadrhRK
  if QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONWAVVE==QCOeTimSvxMjAJXnzyYEltoNadrhRK and QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONTVING=='' and QCOeTimSvxMjAJXnzyYEltoNadrhkH.M3U_ONSPOTV=='':QCOeTimSvxMjAJXnzyYEltoNadrhRB=QCOeTimSvxMjAJXnzyYEltoNadrhRK
  if QCOeTimSvxMjAJXnzyYEltoNadrhRB==QCOeTimSvxMjAJXnzyYEltoNadrhRK:
   QCOeTimSvxMjAJXnzyYEltoNadrhkG=xbmcgui.Dialog()
   QCOeTimSvxMjAJXnzyYEltoNadrhkb=QCOeTimSvxMjAJXnzyYEltoNadrhkG.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if QCOeTimSvxMjAJXnzyYEltoNadrhkb==QCOeTimSvxMjAJXnzyYEltoNadrhRq:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(QCOeTimSvxMjAJXnzyYEltoNadrhkH):
  QCOeTimSvxMjAJXnzyYEltoNadrhRP={'date_makeepg':QCOeTimSvxMjAJXnzyYEltoNadrhkH.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=QCOeTimSvxMjAJXnzyYEltoNadrhRb(QCOeTimSvxMjAJXnzyYEltoNadrhkV,'w',-1,'utf-8')
   json.dump(QCOeTimSvxMjAJXnzyYEltoNadrhRP,fp)
   fp.close()
  except QCOeTimSvxMjAJXnzyYEltoNadrhfk as exception:
   return
 def boritv_main(QCOeTimSvxMjAJXnzyYEltoNadrhkH):
  QCOeTimSvxMjAJXnzyYEltoNadrhRL=QCOeTimSvxMjAJXnzyYEltoNadrhkH.main_params.get('mode',QCOeTimSvxMjAJXnzyYEltoNadrhRF)
  QCOeTimSvxMjAJXnzyYEltoNadrhkH.check_config()
  if QCOeTimSvxMjAJXnzyYEltoNadrhRL is QCOeTimSvxMjAJXnzyYEltoNadrhRF:
   QCOeTimSvxMjAJXnzyYEltoNadrhkH.dp_Main_List()
  elif QCOeTimSvxMjAJXnzyYEltoNadrhRL=='DEL_M3U':
   QCOeTimSvxMjAJXnzyYEltoNadrhkH.dp_Delete_M3u(QCOeTimSvxMjAJXnzyYEltoNadrhkH.main_params)
  elif QCOeTimSvxMjAJXnzyYEltoNadrhRL=='ADD_M3U':
   QCOeTimSvxMjAJXnzyYEltoNadrhkH.dp_MakeAdd_M3u(QCOeTimSvxMjAJXnzyYEltoNadrhkH.main_params)
  elif QCOeTimSvxMjAJXnzyYEltoNadrhRL=='ADD_EPG':
   QCOeTimSvxMjAJXnzyYEltoNadrhkH.dp_Make_Epg(QCOeTimSvxMjAJXnzyYEltoNadrhkH.main_params)
  else:
   QCOeTimSvxMjAJXnzyYEltoNadrhRF
# Created by pyminifier (https://github.com/liftoff/pyminifier)
