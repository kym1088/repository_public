# -*- coding: utf-8 -*-
__author__ = "NightRain"

import os
import sys
import xbmcaddon, xbmcvfs
import urllib
import threading


__cwd__ = xbmcvfs.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
__lib__ = os.path.join( __cwd__, 'resources', 'lib' )
sys.path.append(__lib__)

from boritvServiceRun import *



stop_flag  = threading.Event()
serviceObj = zevDRWUTCFforgOaNJMKHbIjPXpmBn( stop_flag )
serviceObj.start()

try:
	while True:
		time.sleep(1)
		pass
except (KeyboardInterrupt, SystemExit):
	stop_flag.set()

	
