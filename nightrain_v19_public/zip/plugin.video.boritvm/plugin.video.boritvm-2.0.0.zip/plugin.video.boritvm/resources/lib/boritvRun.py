__author__="NightRain"
CgoFpYmKGBfTwvcdPEkHhQJIAMxWjU=object
CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD=False
CgoFpYmKGBfTwvcdPEkHhQJIAMxWjS=None
CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs=True
CgoFpYmKGBfTwvcdPEkHhQJIAMxWjV=len
CgoFpYmKGBfTwvcdPEkHhQJIAMxWja=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
CgoFpYmKGBfTwvcdPEkHhQJIAMxWej=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
CgoFpYmKGBfTwvcdPEkHhQJIAMxWel='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
from boritvCore import*
class CgoFpYmKGBfTwvcdPEkHhQJIAMxWen(CgoFpYmKGBfTwvcdPEkHhQJIAMxWjU):
 def __init__(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq,CgoFpYmKGBfTwvcdPEkHhQJIAMxWeL,CgoFpYmKGBfTwvcdPEkHhQJIAMxWer,CgoFpYmKGBfTwvcdPEkHhQJIAMxWey):
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq._addon_url =CgoFpYmKGBfTwvcdPEkHhQJIAMxWeL
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq._addon_handle =CgoFpYmKGBfTwvcdPEkHhQJIAMxWer
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.main_params =CgoFpYmKGBfTwvcdPEkHhQJIAMxWey
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_FILE_PATH ='' 
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_FILE_NAME ='' 
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVE =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONTVING =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONSPOTV =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVERADIO=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVEHOME =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONSPOTVPAY =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_DISPLAYNM =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.BoritvObj =EdgXxrtzJMUhvSckTBHPNeLAaKbQsW() 
 def addon_noti(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq,sting):
  try:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeD=xbmcgui.Dialog()
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeD.notification(__addonname__,sting)
  except:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWjS
 def addon_log(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq,string):
  try:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeS=string.encode('utf-8','ignore')
  except:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeS='addonException: addon_log'
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWes=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,CgoFpYmKGBfTwvcdPEkHhQJIAMxWeS),level=CgoFpYmKGBfTwvcdPEkHhQJIAMxWes)
 def get_keyboard_input(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq,CgoFpYmKGBfTwvcdPEkHhQJIAMxWeb):
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeV=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjS
  kb=xbmc.Keyboard()
  kb.setHeading(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeb)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeV=kb.getText()
  return CgoFpYmKGBfTwvcdPEkHhQJIAMxWeV
 def add_dir(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq,label,sublabel='',img='',infoLabels=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjS,isFolder=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs,params=''):
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWea='%s?%s'%(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq._addon_url,urllib.parse.urlencode(params))
  if sublabel:CgoFpYmKGBfTwvcdPEkHhQJIAMxWeb='%s < %s >'%(label,sublabel)
  else: CgoFpYmKGBfTwvcdPEkHhQJIAMxWeb=label
  if not img:img='DefaultFolder.png'
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeR=xbmcgui.ListItem(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeb)
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeR.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:CgoFpYmKGBfTwvcdPEkHhQJIAMxWeR.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:CgoFpYmKGBfTwvcdPEkHhQJIAMxWeR.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq._addon_handle,CgoFpYmKGBfTwvcdPEkHhQJIAMxWea,CgoFpYmKGBfTwvcdPEkHhQJIAMxWeR,isFolder)
 def make_M3u_Filename(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq):
  return CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_FILE_PATH+CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq):
  return CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_FILE_PATH+CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_FILE_NAME+'.xml'
 def dp_Main_List(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq):
  for CgoFpYmKGBfTwvcdPEkHhQJIAMxWei in CgoFpYmKGBfTwvcdPEkHhQJIAMxWej:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeb=CgoFpYmKGBfTwvcdPEkHhQJIAMxWei.get('title')
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeu={'mode':CgoFpYmKGBfTwvcdPEkHhQJIAMxWei.get('mode'),'sType':CgoFpYmKGBfTwvcdPEkHhQJIAMxWei.get('sType'),'sName':CgoFpYmKGBfTwvcdPEkHhQJIAMxWei.get('sName')}
   if CgoFpYmKGBfTwvcdPEkHhQJIAMxWei.get('mode')=='XXX':
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWet=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
   else:
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWet=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeX=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs
   if CgoFpYmKGBfTwvcdPEkHhQJIAMxWei.get('mode')=='ADD_M3U':
    if CgoFpYmKGBfTwvcdPEkHhQJIAMxWei.get('sType')=='wavve' and CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVE==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD:CgoFpYmKGBfTwvcdPEkHhQJIAMxWeX=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
    if CgoFpYmKGBfTwvcdPEkHhQJIAMxWei.get('sType')=='tving' and CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONTVING==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD:CgoFpYmKGBfTwvcdPEkHhQJIAMxWeX=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
    if CgoFpYmKGBfTwvcdPEkHhQJIAMxWei.get('sType')=='spotv' and CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONSPOTV==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD:CgoFpYmKGBfTwvcdPEkHhQJIAMxWeX=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
   if CgoFpYmKGBfTwvcdPEkHhQJIAMxWeX==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs:
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.add_dir(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeb,sublabel='',img='',infoLabels=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjS,isFolder=CgoFpYmKGBfTwvcdPEkHhQJIAMxWet,params=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeu)
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWjV(CgoFpYmKGBfTwvcdPEkHhQJIAMxWej)>0:xbmcplugin.endOfDirectory(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq._addon_handle,cacheToDisc=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs)
 def dp_Delete_M3u(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq,args):
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeD=xbmcgui.Dialog()
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeO=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeD.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWeO==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD:sys.exit()
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.make_M3u_Filename()
  if os.path.isfile(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN):os.remove(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN)
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq,args):
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=args.get('sType')
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWnj=args.get('sName')
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeD=xbmcgui.Dialog()
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeO=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeD.yesno((CgoFpYmKGBfTwvcdPEkHhQJIAMxWnj+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWeO==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD:sys.exit()
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWnl=[]
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='all':
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.make_M3u_Filename()
   if os.path.isfile(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN):os.remove(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN)
  if(CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='wavve' or CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='all')and CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVE:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWnq=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.BoritvObj.Get_ChannelList_Wavve(exceptGroup=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.make_EexceptGroup_Wavve())
   if CgoFpYmKGBfTwvcdPEkHhQJIAMxWjV(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnq)!=0:CgoFpYmKGBfTwvcdPEkHhQJIAMxWnl.extend(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnq)
  if(CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='tving' or CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='all')and CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONTVING:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWnq=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.BoritvObj.Get_ChannelList_Tving()
   if CgoFpYmKGBfTwvcdPEkHhQJIAMxWjV(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnq)!=0:CgoFpYmKGBfTwvcdPEkHhQJIAMxWnl.extend(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnq)
  if(CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='spotv' or CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='all')and CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONSPOTV:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWnq=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.BoritvObj.Get_ChannelList_Spotv(payyn=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONSPOTVPAY)
   if CgoFpYmKGBfTwvcdPEkHhQJIAMxWjV(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnq)!=0:CgoFpYmKGBfTwvcdPEkHhQJIAMxWnl.extend(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnq)
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWjV(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnl)==0:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.make_M3u_Filename()
   if os.path.isfile(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN):
    fp=CgoFpYmKGBfTwvcdPEkHhQJIAMxWja(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN,'a',-1,'utf-8')
   else:
    fp=CgoFpYmKGBfTwvcdPEkHhQJIAMxWja(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for CgoFpYmKGBfTwvcdPEkHhQJIAMxWnL in CgoFpYmKGBfTwvcdPEkHhQJIAMxWnl:
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWnr =CgoFpYmKGBfTwvcdPEkHhQJIAMxWnL['channelid']
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWny =CgoFpYmKGBfTwvcdPEkHhQJIAMxWnL['channelnm']
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWnU=CgoFpYmKGBfTwvcdPEkHhQJIAMxWnL['channelimg']
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWnD =CgoFpYmKGBfTwvcdPEkHhQJIAMxWnL['ott']
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWnS ='%s.%s'%(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnr,CgoFpYmKGBfTwvcdPEkHhQJIAMxWnD)
    if CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_DISPLAYNM:
     CgoFpYmKGBfTwvcdPEkHhQJIAMxWny='%s (%s)'%(CgoFpYmKGBfTwvcdPEkHhQJIAMxWny,CgoFpYmKGBfTwvcdPEkHhQJIAMxWnD)
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWns='#EXTINF:0 tvg-ID="%s" tvg-name="%s" tvg-logo="%s",%s\n'%(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnS,CgoFpYmKGBfTwvcdPEkHhQJIAMxWny,CgoFpYmKGBfTwvcdPEkHhQJIAMxWnU,CgoFpYmKGBfTwvcdPEkHhQJIAMxWny)
    if CgoFpYmKGBfTwvcdPEkHhQJIAMxWnD=='wavve':
     CgoFpYmKGBfTwvcdPEkHhQJIAMxWnV ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnr)
    elif CgoFpYmKGBfTwvcdPEkHhQJIAMxWnD=='tving':
     CgoFpYmKGBfTwvcdPEkHhQJIAMxWnV ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnr)
    elif CgoFpYmKGBfTwvcdPEkHhQJIAMxWnD=='spotv':
     CgoFpYmKGBfTwvcdPEkHhQJIAMxWnV ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnr)
    fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWns)
    fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnV)
   fp.close()
  except:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.addon_noti(__language__(30910).encode('utf8'))
   return
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.addon_noti((CgoFpYmKGBfTwvcdPEkHhQJIAMxWnj+' '+__language__(30908)).encode('utf8'))
 def dp_Make_Epg(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq,args):
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=args.get('sType')
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWnj=args.get('sName')
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeD=xbmcgui.Dialog()
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeO=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeD.yesno((CgoFpYmKGBfTwvcdPEkHhQJIAMxWnj+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWeO==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD:sys.exit()
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWna=[]
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWnb=[]
  if(CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='wavve' or CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='all')and CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVE:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWnR,CgoFpYmKGBfTwvcdPEkHhQJIAMxWni=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.make_EexceptGroup_Wavve())
   if CgoFpYmKGBfTwvcdPEkHhQJIAMxWjV(CgoFpYmKGBfTwvcdPEkHhQJIAMxWni)!=0:
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWna.extend(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnR)
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWnb.extend(CgoFpYmKGBfTwvcdPEkHhQJIAMxWni)
  if(CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='tving' or CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='all')and CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONTVING:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWnR,CgoFpYmKGBfTwvcdPEkHhQJIAMxWni=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.BoritvObj.Get_EpgInfo_Tving()
   if CgoFpYmKGBfTwvcdPEkHhQJIAMxWjV(CgoFpYmKGBfTwvcdPEkHhQJIAMxWni)!=0:
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWna.extend(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnR)
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWnb.extend(CgoFpYmKGBfTwvcdPEkHhQJIAMxWni)
  if(CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='spotv' or CgoFpYmKGBfTwvcdPEkHhQJIAMxWne=='all')and CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONSPOTV:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWnR,CgoFpYmKGBfTwvcdPEkHhQJIAMxWni=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.BoritvObj.Get_EpgInfo_Spotv(payyn=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONSPOTVPAY)
   if CgoFpYmKGBfTwvcdPEkHhQJIAMxWjV(CgoFpYmKGBfTwvcdPEkHhQJIAMxWni)!=0:
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWna.extend(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnR)
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWnb.extend(CgoFpYmKGBfTwvcdPEkHhQJIAMxWni)
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWjV(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnb)==0:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.make_Epg_Filename()
   fp=CgoFpYmKGBfTwvcdPEkHhQJIAMxWja(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeN,'w',-1,'utf-8')
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWnu='<?xml version="1.0" encoding="UTF-8"?>\n'
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWnt='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWnX='<tv generator-info-name="boritv_epg">\n\n'
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWnz='\n</tv>\n'
   fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnu)
   fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnt)
   fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnX)
   for CgoFpYmKGBfTwvcdPEkHhQJIAMxWnO in CgoFpYmKGBfTwvcdPEkHhQJIAMxWna:
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWnN='  <channel id="%s.%s">\n' %(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnO.get('channelid'),CgoFpYmKGBfTwvcdPEkHhQJIAMxWnO.get('ott'))
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWje='    <display-name>%s</display-name>\n'%(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnO.get('channelnm'))
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWjn='    <icon src="%s" />\n' %(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnO.get('channelimg'))
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWjl='  </channel>\n\n'
    fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnN)
    fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWje)
    fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWjn)
    fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWjl)
   for CgoFpYmKGBfTwvcdPEkHhQJIAMxWnO in CgoFpYmKGBfTwvcdPEkHhQJIAMxWnb:
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWnN='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnO.get('startTime'),CgoFpYmKGBfTwvcdPEkHhQJIAMxWnO.get('endTime'),CgoFpYmKGBfTwvcdPEkHhQJIAMxWnO.get('channelid'),CgoFpYmKGBfTwvcdPEkHhQJIAMxWnO.get('ott'))
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWje='    <title lang="kr">%s</title>\n' %(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnO.get('title'))
    CgoFpYmKGBfTwvcdPEkHhQJIAMxWjn='  </programme>\n\n'
    fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnN)
    fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWje)
    fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWjn)
   fp.write(CgoFpYmKGBfTwvcdPEkHhQJIAMxWnz)
   fp.close()
  except:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.addon_noti(__language__(30910).encode('utf8'))
   return
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.addon_noti((CgoFpYmKGBfTwvcdPEkHhQJIAMxWnj+' '+__language__(30912)).encode('utf8'))
 def make_EexceptGroup_Wavve(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq):
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWjq=[]
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVERADIO==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWjL={'broadcastid':'46584','genre':'10'}
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWjq.append(CgoFpYmKGBfTwvcdPEkHhQJIAMxWjL)
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVEHOME==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWjL={'broadcastid':'46584','genre':'03'}
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWjq.append(CgoFpYmKGBfTwvcdPEkHhQJIAMxWjL)
  return CgoFpYmKGBfTwvcdPEkHhQJIAMxWjq
 def check_config(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq):
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWjr=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVE =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs if __addon__.getSetting('onWavve')=='true' else CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONTVING =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs if __addon__.getSetting('onTvng')=='true' else CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONSPOTV =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs if __addon__.getSetting('onSpotv')=='true' else CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVERADIO=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs if __addon__.getSetting('onWavveRadio')=='true' else CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVEHOME =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs if __addon__.getSetting('onWavveHome')=='true' else CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONSPOTVPAY =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs if __addon__.getSetting('onSpotvPay')=='true' else CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_DISPLAYNM =CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs if __addon__.getSetting('displayOTTnm')=='true' else CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_FILE_PATH=='' or CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_FILE_NAME=='':CgoFpYmKGBfTwvcdPEkHhQJIAMxWjr=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONWAVVE==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD and CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONTVING=='' and CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.M3U_ONSPOTV=='':CgoFpYmKGBfTwvcdPEkHhQJIAMxWjr=CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWjr==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjD:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeD=xbmcgui.Dialog()
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeO=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeD.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if CgoFpYmKGBfTwvcdPEkHhQJIAMxWeO==CgoFpYmKGBfTwvcdPEkHhQJIAMxWjs:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def boritv_main(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq):
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWjy=CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.main_params.get('mode',CgoFpYmKGBfTwvcdPEkHhQJIAMxWjS)
  CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.check_config()
  if CgoFpYmKGBfTwvcdPEkHhQJIAMxWjy is CgoFpYmKGBfTwvcdPEkHhQJIAMxWjS:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.dp_Main_List()
  elif CgoFpYmKGBfTwvcdPEkHhQJIAMxWjy=='DEL_M3U':
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.dp_Delete_M3u(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.main_params)
  elif CgoFpYmKGBfTwvcdPEkHhQJIAMxWjy=='ADD_M3U':
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.dp_MakeAdd_M3u(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.main_params)
  elif CgoFpYmKGBfTwvcdPEkHhQJIAMxWjy=='ADD_EPG':
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.dp_Make_Epg(CgoFpYmKGBfTwvcdPEkHhQJIAMxWeq.main_params)
  else:
   CgoFpYmKGBfTwvcdPEkHhQJIAMxWjS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
