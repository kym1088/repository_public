__author__="NightRain"
EdgXxrtzJMUhvSckTBHPNeLAaKbQOG=object
EdgXxrtzJMUhvSckTBHPNeLAaKbQOi=None
EdgXxrtzJMUhvSckTBHPNeLAaKbQOl=False
EdgXxrtzJMUhvSckTBHPNeLAaKbQOD=str
EdgXxrtzJMUhvSckTBHPNeLAaKbQOp=Exception
EdgXxrtzJMUhvSckTBHPNeLAaKbQOf=print
EdgXxrtzJMUhvSckTBHPNeLAaKbQOm=True
EdgXxrtzJMUhvSckTBHPNeLAaKbQOn=int
EdgXxrtzJMUhvSckTBHPNeLAaKbQOY=range
EdgXxrtzJMUhvSckTBHPNeLAaKbQOC=len
import urllib
import re
import json
import sys
import requests
import datetime
import time
EdgXxrtzJMUhvSckTBHPNeLAaKbQsO='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
EdgXxrtzJMUhvSckTBHPNeLAaKbQsF=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
class EdgXxrtzJMUhvSckTBHPNeLAaKbQsW(EdgXxrtzJMUhvSckTBHPNeLAaKbQOG):
 def __init__(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_WAVVE ='https://apis.wavve.com'
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_TVING ='https://api.tving.com'
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_TVINGIMG ='https://image.tving.com'
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_SPOTV ='https://www.spotvnow.co.kr'
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.HTTPTAG ='https://'
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.LIMIT_WAVVE =200
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.LIMIT_TVING =60
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.LIMIT_TVINGEPG=20 
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.DEFAULT_HEADER={'user-agent':EdgXxrtzJMUhvSckTBHPNeLAaKbQsO}
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.SLEEP_TIME =0.2
 def callRequestCookies(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,jobtype,EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,payload=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,params=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,cookies=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,redirects=EdgXxrtzJMUhvSckTBHPNeLAaKbQOl):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsR=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.DEFAULT_HEADER
  if headers:EdgXxrtzJMUhvSckTBHPNeLAaKbQsR.update(headers)
  if jobtype=='Get':
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsy=requests.get(EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,params=params,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQsR,cookies=cookies,allow_redirects=redirects)
  else:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsy=requests.post(EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,data=payload,params=params,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQsR,cookies=cookies,allow_redirects=redirects)
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsy
 def Get_DefaultParams_Wavve(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsw={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsw
 def Get_DefaultParams_Tving(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsw={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsw
 def Get_Now_Datetime(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,in_text):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQso=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQso
 def Get_ChannelList_Wavve(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,exceptGroup=[]):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsu =[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsq=[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsG=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_ChannelImg_Wavve()
  if exceptGroup!=[]:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsq=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_ChannelList_WavveExcept(exceptGroup)
  try:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsi=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_WAVVE+'/cf/live/recommend-channels'
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsw={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':EdgXxrtzJMUhvSckTBHPNeLAaKbQOD(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsw.update(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_DefaultParams_Wavve())
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsl=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.callRequestCookies('Get',EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,payload=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,params=EdgXxrtzJMUhvSckTBHPNeLAaKbQsw,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,cookies=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi)
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsD=json.loads(EdgXxrtzJMUhvSckTBHPNeLAaKbQsl.text)
   if not('celllist' in EdgXxrtzJMUhvSckTBHPNeLAaKbQsD['cell_toplist']):return EdgXxrtzJMUhvSckTBHPNeLAaKbQsu
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsp=EdgXxrtzJMUhvSckTBHPNeLAaKbQsD['cell_toplist']['celllist']
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQsp:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsm=EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['contentid']
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsn=EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['title_list'][0]['text']
    if EdgXxrtzJMUhvSckTBHPNeLAaKbQsm in EdgXxrtzJMUhvSckTBHPNeLAaKbQsG:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsY=EdgXxrtzJMUhvSckTBHPNeLAaKbQsG[EdgXxrtzJMUhvSckTBHPNeLAaKbQsm]
    else:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsY=''
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsC={'channelid':EdgXxrtzJMUhvSckTBHPNeLAaKbQsm,'channelnm':EdgXxrtzJMUhvSckTBHPNeLAaKbQsn,'channelimg':EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.HTTPTAG+EdgXxrtzJMUhvSckTBHPNeLAaKbQsY if EdgXxrtzJMUhvSckTBHPNeLAaKbQsY!='' else '','ott':'wavve'}
    if EdgXxrtzJMUhvSckTBHPNeLAaKbQsm not in EdgXxrtzJMUhvSckTBHPNeLAaKbQsq:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsu.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsC)
  except EdgXxrtzJMUhvSckTBHPNeLAaKbQOp as exception:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOf(exception)
   return[]
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsu
 def Get_ChannelList_WavveExcept(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,exceptGroup=[]):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsu=[]
  if exceptGroup==[]:return[]
  try:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsi=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_WAVVE+'/cf/live/recommend-channels'
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in exceptGroup:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsw={'WeekDay':'all','adult':'n','broadcastid':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['broadcastid'],'contenttype':'channel','genre':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['genre'],'isrecommend':'y','limit':EdgXxrtzJMUhvSckTBHPNeLAaKbQOD(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsw.update(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_DefaultParams_Wavve())
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsl=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.callRequestCookies('Get',EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,payload=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,params=EdgXxrtzJMUhvSckTBHPNeLAaKbQsw,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,cookies=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi)
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsD=json.loads(EdgXxrtzJMUhvSckTBHPNeLAaKbQsl.text)
    if not('celllist' in EdgXxrtzJMUhvSckTBHPNeLAaKbQsD['cell_toplist']):return EdgXxrtzJMUhvSckTBHPNeLAaKbQsu
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsp=EdgXxrtzJMUhvSckTBHPNeLAaKbQsD['cell_toplist']['celllist']
    for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQsp:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsu.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['contentid'])
  except EdgXxrtzJMUhvSckTBHPNeLAaKbQOp as exception:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOf(exception)
   return[]
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsu
 def Get_ChannelImg_Wavve(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsV={}
  try:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQWs=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_Now_Datetime()
   EdgXxrtzJMUhvSckTBHPNeLAaKbQWO =EdgXxrtzJMUhvSckTBHPNeLAaKbQWs+datetime.timedelta(hours=3)
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsi=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_WAVVE+'/live/epgs'
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsw={'limit':EdgXxrtzJMUhvSckTBHPNeLAaKbQOD(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':EdgXxrtzJMUhvSckTBHPNeLAaKbQWs.strftime('%Y-%m-%d %H:00'),'enddatetime':EdgXxrtzJMUhvSckTBHPNeLAaKbQWO.strftime('%Y-%m-%d %H:00')}
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsw.update(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_DefaultParams_Wavve())
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsl=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.callRequestCookies('Get',EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,payload=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,params=EdgXxrtzJMUhvSckTBHPNeLAaKbQsw,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,cookies=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi)
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsD=json.loads(EdgXxrtzJMUhvSckTBHPNeLAaKbQsl.text)
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsp=EdgXxrtzJMUhvSckTBHPNeLAaKbQsD['list']
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQsp:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsV[EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channelid']]=EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channelimage']
  except EdgXxrtzJMUhvSckTBHPNeLAaKbQOp as exception:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOf(exception)
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsV
 def Get_ChannelList_Spotv(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,payyn=EdgXxrtzJMUhvSckTBHPNeLAaKbQOm):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsu=[]
  try:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsi=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_SPOTV+'/api/v2/channel'
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsl=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.callRequestCookies('Get',EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,payload=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,params=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,cookies=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi)
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsD=json.loads(EdgXxrtzJMUhvSckTBHPNeLAaKbQsl.text)
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQsD:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsC={'channelid':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['videoId'].replace('ref:',''),'channelnm':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['name'],'channelimg':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['logo'],'ott':'spotv'}
    if payyn==EdgXxrtzJMUhvSckTBHPNeLAaKbQOm or EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['free']==EdgXxrtzJMUhvSckTBHPNeLAaKbQOm:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsu.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsC)
  except EdgXxrtzJMUhvSckTBHPNeLAaKbQOp as exception:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOf(exception)
   return[]
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsu
 def Get_ChannelList_Tving(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsu =[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWF=[]
  try:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsi=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_TVING+'/v2/media/lives'
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsw={'pageNo':'1','pageSize':EdgXxrtzJMUhvSckTBHPNeLAaKbQOD(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsw.update(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_DefaultParams_Tving())
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsl=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.callRequestCookies('Get',EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,payload=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,params=EdgXxrtzJMUhvSckTBHPNeLAaKbQsw,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,cookies=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi)
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsD=json.loads(EdgXxrtzJMUhvSckTBHPNeLAaKbQsl.text)
   if not('result' in EdgXxrtzJMUhvSckTBHPNeLAaKbQsD['body']):return EdgXxrtzJMUhvSckTBHPNeLAaKbQsu
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsp=EdgXxrtzJMUhvSckTBHPNeLAaKbQsD['body']['result']
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQsp:
    if EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['live_code']=='C44441':continue 
    EdgXxrtzJMUhvSckTBHPNeLAaKbQWF.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['live_code'])
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsG=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_ChannelImg_Tving(EdgXxrtzJMUhvSckTBHPNeLAaKbQWF)
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQsp:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsm=EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['live_code']
    if EdgXxrtzJMUhvSckTBHPNeLAaKbQsm=='C44441':continue 
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsn=EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['schedule']['channel']['name']['ko']
    if EdgXxrtzJMUhvSckTBHPNeLAaKbQsm in EdgXxrtzJMUhvSckTBHPNeLAaKbQsG:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsY=EdgXxrtzJMUhvSckTBHPNeLAaKbQsG[EdgXxrtzJMUhvSckTBHPNeLAaKbQsm]
    else:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsY=''
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsC={'channelid':EdgXxrtzJMUhvSckTBHPNeLAaKbQsm,'channelnm':EdgXxrtzJMUhvSckTBHPNeLAaKbQsn,'channelimg':EdgXxrtzJMUhvSckTBHPNeLAaKbQsY,'ott':'tving'}
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsu.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsC)
  except EdgXxrtzJMUhvSckTBHPNeLAaKbQOp as exception:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOf(exception)
   return[]
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsu
 def make_EpgDatetime_Tving(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,days=2):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWj=[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWR=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.make_DateList(days=2,dateType='2')
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWy=EdgXxrtzJMUhvSckTBHPNeLAaKbQOn(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQWR:
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQWw in EdgXxrtzJMUhvSckTBHPNeLAaKbQOY(8):
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsC={'ndate':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf,'starttm':EdgXxrtzJMUhvSckTBHPNeLAaKbQsF[EdgXxrtzJMUhvSckTBHPNeLAaKbQWw]['starttm'],'endtm':EdgXxrtzJMUhvSckTBHPNeLAaKbQsF[EdgXxrtzJMUhvSckTBHPNeLAaKbQWw]['endtm']}
    EdgXxrtzJMUhvSckTBHPNeLAaKbQWI=EdgXxrtzJMUhvSckTBHPNeLAaKbQOn(EdgXxrtzJMUhvSckTBHPNeLAaKbQsf+EdgXxrtzJMUhvSckTBHPNeLAaKbQsF[EdgXxrtzJMUhvSckTBHPNeLAaKbQWw]['starttm'])
    EdgXxrtzJMUhvSckTBHPNeLAaKbQWo=EdgXxrtzJMUhvSckTBHPNeLAaKbQOn(EdgXxrtzJMUhvSckTBHPNeLAaKbQsf+EdgXxrtzJMUhvSckTBHPNeLAaKbQsF[EdgXxrtzJMUhvSckTBHPNeLAaKbQWw]['endtm'])
    if EdgXxrtzJMUhvSckTBHPNeLAaKbQWy<=EdgXxrtzJMUhvSckTBHPNeLAaKbQWI or(EdgXxrtzJMUhvSckTBHPNeLAaKbQWI<EdgXxrtzJMUhvSckTBHPNeLAaKbQWy and EdgXxrtzJMUhvSckTBHPNeLAaKbQWy<EdgXxrtzJMUhvSckTBHPNeLAaKbQWo):
     EdgXxrtzJMUhvSckTBHPNeLAaKbQWj.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsC)
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQWj
 def make_DateList(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,days=2,dateType='1'):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWR=[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWu =EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_Now_Datetime()
  for i in EdgXxrtzJMUhvSckTBHPNeLAaKbQOY(days):
   EdgXxrtzJMUhvSckTBHPNeLAaKbQWq=EdgXxrtzJMUhvSckTBHPNeLAaKbQWu+datetime.timedelta(days=i)
   if dateType=='1':
    EdgXxrtzJMUhvSckTBHPNeLAaKbQWR.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQWq.strftime('%Y-%m-%d'))
   else:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQWR.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQWq.strftime('%Y%m%d'))
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQWR
 def make_Tving_ChannleGroup(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,EdgXxrtzJMUhvSckTBHPNeLAaKbQWF):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWG=[]
  i=0
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWi=''
  for EdgXxrtzJMUhvSckTBHPNeLAaKbQWl in EdgXxrtzJMUhvSckTBHPNeLAaKbQWF:
   if i==0:EdgXxrtzJMUhvSckTBHPNeLAaKbQWi=EdgXxrtzJMUhvSckTBHPNeLAaKbQWl
   else:EdgXxrtzJMUhvSckTBHPNeLAaKbQWi+=',%s'%(EdgXxrtzJMUhvSckTBHPNeLAaKbQWl)
   i+=1
   if i>=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.LIMIT_TVINGEPG:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQWG.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQWi)
    i=0
    EdgXxrtzJMUhvSckTBHPNeLAaKbQWi=''
  if EdgXxrtzJMUhvSckTBHPNeLAaKbQWi!='':
   EdgXxrtzJMUhvSckTBHPNeLAaKbQWG.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQWi)
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQWG
 def Get_ChannelImg_Tving(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,chid_list):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsV={}
  try:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQWD=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_Now_Datetime().strftime('%Y%m%d')
   EdgXxrtzJMUhvSckTBHPNeLAaKbQWs =EdgXxrtzJMUhvSckTBHPNeLAaKbQsF[6]['starttm'] 
   EdgXxrtzJMUhvSckTBHPNeLAaKbQWO =EdgXxrtzJMUhvSckTBHPNeLAaKbQsF[6]['endtm']
   EdgXxrtzJMUhvSckTBHPNeLAaKbQWG=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.make_Tving_ChannleGroup(chid_list)
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQWG:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsi=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_TVING+'/v2/media/schedules'
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsw={'pageNo':'1','pageSize':EdgXxrtzJMUhvSckTBHPNeLAaKbQOD(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':EdgXxrtzJMUhvSckTBHPNeLAaKbQWD,'broadcastDate':EdgXxrtzJMUhvSckTBHPNeLAaKbQWD,'startBroadTime':EdgXxrtzJMUhvSckTBHPNeLAaKbQWs,'endBroadTime':EdgXxrtzJMUhvSckTBHPNeLAaKbQWO,'channelCode':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf}
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsw.update(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_DefaultParams_Tving())
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsl=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.callRequestCookies('Get',EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,payload=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,params=EdgXxrtzJMUhvSckTBHPNeLAaKbQsw,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,cookies=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi)
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsD=json.loads(EdgXxrtzJMUhvSckTBHPNeLAaKbQsl.text)
    if not('result' in EdgXxrtzJMUhvSckTBHPNeLAaKbQsD['body']):return{}
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsp=EdgXxrtzJMUhvSckTBHPNeLAaKbQsD['body']['result']
    for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQsp:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsV[EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channel_code']]=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_TVINGIMG+EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['image'][2]['url']
  except EdgXxrtzJMUhvSckTBHPNeLAaKbQOp as exception:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOf(exception)
   return{}
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsV
 def Get_EpgInfo_Spotv(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,days=2,payyn=EdgXxrtzJMUhvSckTBHPNeLAaKbQOm):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWp ={}
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsu=[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWf =[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWR=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.make_DateList(days=days,dateType='1')
  try:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsi=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_SPOTV+'/api/v2/channel'
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsl=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.callRequestCookies('Get',EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,payload=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,params=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,cookies=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi)
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsD=json.loads(EdgXxrtzJMUhvSckTBHPNeLAaKbQsl.text)
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQsD:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsm=EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['videoId'].replace('ref:','')
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsC={'channelid':EdgXxrtzJMUhvSckTBHPNeLAaKbQsm,'channelnm':EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.xmlText(EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['name']),'channelimg':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['logo'],'ott':'spotv'}
    if payyn==EdgXxrtzJMUhvSckTBHPNeLAaKbQOm or EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['free']==EdgXxrtzJMUhvSckTBHPNeLAaKbQOm:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQWp[EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['id']]=EdgXxrtzJMUhvSckTBHPNeLAaKbQsm
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsu.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsC)
  except EdgXxrtzJMUhvSckTBHPNeLAaKbQOp as exception:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOf(exception)
   return[],[]
  try:
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQWm in EdgXxrtzJMUhvSckTBHPNeLAaKbQWR:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsi=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_SPOTV+'/api/v2/program/'+EdgXxrtzJMUhvSckTBHPNeLAaKbQWm
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsl=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.callRequestCookies('Get',EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,payload=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,params=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,cookies=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi)
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsD=json.loads(EdgXxrtzJMUhvSckTBHPNeLAaKbQsl.text)
    for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQsD:
     if EdgXxrtzJMUhvSckTBHPNeLAaKbQWp.get(EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channelId'])==EdgXxrtzJMUhvSckTBHPNeLAaKbQOi:continue
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsC={'channelid':EdgXxrtzJMUhvSckTBHPNeLAaKbQWp.get(EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channelId']),'title':EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.xmlText(EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['title']),'startTime':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     EdgXxrtzJMUhvSckTBHPNeLAaKbQWf.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsC)
    time.sleep(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.SLEEP_TIME)
  except EdgXxrtzJMUhvSckTBHPNeLAaKbQOp as exception:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOf(exception)
   return[],[]
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsu,EdgXxrtzJMUhvSckTBHPNeLAaKbQWf
 def Get_EpgInfo_Wavve(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,days=2,exceptGroup=[]):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsu =[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWf =[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsq=[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWu =EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_Now_Datetime()
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWn =EdgXxrtzJMUhvSckTBHPNeLAaKbQWu+datetime.timedelta(hours=-2)
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWY =EdgXxrtzJMUhvSckTBHPNeLAaKbQWu+datetime.timedelta(days=(days-1))
  if EdgXxrtzJMUhvSckTBHPNeLAaKbQOn(EdgXxrtzJMUhvSckTBHPNeLAaKbQWn.strftime('%H'))<=3:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQWC=EdgXxrtzJMUhvSckTBHPNeLAaKbQWn.strftime('%Y-%m-%d 00:00')
  else:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQWC=EdgXxrtzJMUhvSckTBHPNeLAaKbQWn.strftime('%Y-%m-%d %H:00')
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWV =EdgXxrtzJMUhvSckTBHPNeLAaKbQWY.strftime('%Y-%m-%d 24:00')
  if exceptGroup!=[]:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsq=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_ChannelList_WavveExcept(exceptGroup)
  try:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsi=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_WAVVE+'/live/epgs'
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsw={'limit':EdgXxrtzJMUhvSckTBHPNeLAaKbQOD(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':EdgXxrtzJMUhvSckTBHPNeLAaKbQWC,'enddatetime':EdgXxrtzJMUhvSckTBHPNeLAaKbQWV}
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsw.update(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_DefaultParams_Wavve())
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsl=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.callRequestCookies('Get',EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,payload=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,params=EdgXxrtzJMUhvSckTBHPNeLAaKbQsw,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,cookies=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi)
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsD=json.loads(EdgXxrtzJMUhvSckTBHPNeLAaKbQsl.text)
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOs=EdgXxrtzJMUhvSckTBHPNeLAaKbQsD['list']
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQOs:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQsC={'channelid':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channelid'],'channelnm':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channelname'],'channelimg':EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.HTTPTAG+EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channelimage'],'ott':'wavve'}
    if EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channelid']not in EdgXxrtzJMUhvSckTBHPNeLAaKbQsq:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsu.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsC)
    for EdgXxrtzJMUhvSckTBHPNeLAaKbQOW in EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['list']:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsC={'channelid':EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channelid'],'title':EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.xmlText(EdgXxrtzJMUhvSckTBHPNeLAaKbQOW['title']),'startTime':EdgXxrtzJMUhvSckTBHPNeLAaKbQOW['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':EdgXxrtzJMUhvSckTBHPNeLAaKbQOW['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channelid']not in EdgXxrtzJMUhvSckTBHPNeLAaKbQsq and EdgXxrtzJMUhvSckTBHPNeLAaKbQOW['starttime']!=EdgXxrtzJMUhvSckTBHPNeLAaKbQOW['endtime']:
      EdgXxrtzJMUhvSckTBHPNeLAaKbQWf.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsC)
  except EdgXxrtzJMUhvSckTBHPNeLAaKbQOp as exception:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOf(exception)
   return[],[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQOF=EdgXxrtzJMUhvSckTBHPNeLAaKbQOC(EdgXxrtzJMUhvSckTBHPNeLAaKbQWf)
  for i in(EdgXxrtzJMUhvSckTBHPNeLAaKbQOY(1,EdgXxrtzJMUhvSckTBHPNeLAaKbQOF)):
   if EdgXxrtzJMUhvSckTBHPNeLAaKbQOn(EdgXxrtzJMUhvSckTBHPNeLAaKbQWf[i-1]['endTime'])+1==EdgXxrtzJMUhvSckTBHPNeLAaKbQOn(EdgXxrtzJMUhvSckTBHPNeLAaKbQWf[i]['startTime'])and EdgXxrtzJMUhvSckTBHPNeLAaKbQWf[i-1]['channelid']==EdgXxrtzJMUhvSckTBHPNeLAaKbQWf[i]['channelid']:
    EdgXxrtzJMUhvSckTBHPNeLAaKbQWf[i-1]['endTime']=EdgXxrtzJMUhvSckTBHPNeLAaKbQWf[i]['startTime']
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsu,EdgXxrtzJMUhvSckTBHPNeLAaKbQWf
 def Get_EpgInfo_Tving(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj,days=2):
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsu=[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQWf =[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQOj =[]
  EdgXxrtzJMUhvSckTBHPNeLAaKbQOR =EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.make_EpgDatetime_Tving(days=days)
  EdgXxrtzJMUhvSckTBHPNeLAaKbQsu =EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_ChannelList_Tving()
  EdgXxrtzJMUhvSckTBHPNeLAaKbQOy=[]
  for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQsu:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOy.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['channelid'])
  EdgXxrtzJMUhvSckTBHPNeLAaKbQOw=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.make_Tving_ChannleGroup(EdgXxrtzJMUhvSckTBHPNeLAaKbQOy)
  try:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQsi=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.API_TVING+'/v2/media/schedules'
   for EdgXxrtzJMUhvSckTBHPNeLAaKbQOI in EdgXxrtzJMUhvSckTBHPNeLAaKbQOR:
    for EdgXxrtzJMUhvSckTBHPNeLAaKbQOo in EdgXxrtzJMUhvSckTBHPNeLAaKbQOw:
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsw={'pageNo':'1','pageSize':EdgXxrtzJMUhvSckTBHPNeLAaKbQOD(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':EdgXxrtzJMUhvSckTBHPNeLAaKbQOI['ndate'],'broadcastDate':EdgXxrtzJMUhvSckTBHPNeLAaKbQOI['ndate'],'startBroadTime':EdgXxrtzJMUhvSckTBHPNeLAaKbQOI['starttm'],'endBroadTime':EdgXxrtzJMUhvSckTBHPNeLAaKbQOI['endtm'],'channelCode':EdgXxrtzJMUhvSckTBHPNeLAaKbQOo}
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsw.update(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.Get_DefaultParams_Tving())
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsl=EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.callRequestCookies('Get',EdgXxrtzJMUhvSckTBHPNeLAaKbQsi,payload=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,params=EdgXxrtzJMUhvSckTBHPNeLAaKbQsw,headers=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi,cookies=EdgXxrtzJMUhvSckTBHPNeLAaKbQOi)
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsD=json.loads(EdgXxrtzJMUhvSckTBHPNeLAaKbQsl.text)
     EdgXxrtzJMUhvSckTBHPNeLAaKbQsp=EdgXxrtzJMUhvSckTBHPNeLAaKbQsD['body']['result']
     for EdgXxrtzJMUhvSckTBHPNeLAaKbQsf in EdgXxrtzJMUhvSckTBHPNeLAaKbQsp:
      if not('schedules' in EdgXxrtzJMUhvSckTBHPNeLAaKbQsf):continue
      for EdgXxrtzJMUhvSckTBHPNeLAaKbQOu in EdgXxrtzJMUhvSckTBHPNeLAaKbQsf['schedules']:
       EdgXxrtzJMUhvSckTBHPNeLAaKbQsC={'channelid':EdgXxrtzJMUhvSckTBHPNeLAaKbQOu['schedule_code'],'title':EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.xmlText(EdgXxrtzJMUhvSckTBHPNeLAaKbQOu['program']['name']['ko']),'startTime':EdgXxrtzJMUhvSckTBHPNeLAaKbQOD(EdgXxrtzJMUhvSckTBHPNeLAaKbQOu['broadcast_start_time']),'endTime':EdgXxrtzJMUhvSckTBHPNeLAaKbQOD(EdgXxrtzJMUhvSckTBHPNeLAaKbQOu['broadcast_end_time']),'ott':'tving'}
       EdgXxrtzJMUhvSckTBHPNeLAaKbQOq=EdgXxrtzJMUhvSckTBHPNeLAaKbQOu['schedule_code']+EdgXxrtzJMUhvSckTBHPNeLAaKbQOD(EdgXxrtzJMUhvSckTBHPNeLAaKbQOu['broadcast_start_time'])
       if EdgXxrtzJMUhvSckTBHPNeLAaKbQOq in EdgXxrtzJMUhvSckTBHPNeLAaKbQOj:continue
       EdgXxrtzJMUhvSckTBHPNeLAaKbQOj.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQOq)
       EdgXxrtzJMUhvSckTBHPNeLAaKbQWf.append(EdgXxrtzJMUhvSckTBHPNeLAaKbQsC)
     time.sleep(EdgXxrtzJMUhvSckTBHPNeLAaKbQsj.SLEEP_TIME)
  except EdgXxrtzJMUhvSckTBHPNeLAaKbQOp as exception:
   EdgXxrtzJMUhvSckTBHPNeLAaKbQOf(exception)
   return[],[]
  return EdgXxrtzJMUhvSckTBHPNeLAaKbQsu,EdgXxrtzJMUhvSckTBHPNeLAaKbQWf
# Created by pyminifier (https://github.com/liftoff/pyminifier)
