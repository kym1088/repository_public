__author__="NightRain"
srQbdkjqXBmvoHGtLRAVuNanDxElfw=False
srQbdkjqXBmvoHGtLRAVuNanDxElfz=object
srQbdkjqXBmvoHGtLRAVuNanDxElfS=None
srQbdkjqXBmvoHGtLRAVuNanDxElfU=str
srQbdkjqXBmvoHGtLRAVuNanDxElfI=Exception
srQbdkjqXBmvoHGtLRAVuNanDxElfM=print
srQbdkjqXBmvoHGtLRAVuNanDxElfC=True
srQbdkjqXBmvoHGtLRAVuNanDxElfT=int
srQbdkjqXBmvoHGtLRAVuNanDxElfJ=range
srQbdkjqXBmvoHGtLRAVuNanDxElfh=len
srQbdkjqXBmvoHGtLRAVuNanDxElfP=set
srQbdkjqXBmvoHGtLRAVuNanDxElfg=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
from channelgenre import*
srQbdkjqXBmvoHGtLRAVuNanDxElYW=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
srQbdkjqXBmvoHGtLRAVuNanDxElYf=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':srQbdkjqXBmvoHGtLRAVuNanDxElfw,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':srQbdkjqXBmvoHGtLRAVuNanDxElfw,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':srQbdkjqXBmvoHGtLRAVuNanDxElfw,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':srQbdkjqXBmvoHGtLRAVuNanDxElfw,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':srQbdkjqXBmvoHGtLRAVuNanDxElfw,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':srQbdkjqXBmvoHGtLRAVuNanDxElfw,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class srQbdkjqXBmvoHGtLRAVuNanDxElYc(srQbdkjqXBmvoHGtLRAVuNanDxElfz):
 def __init__(srQbdkjqXBmvoHGtLRAVuNanDxElYp):
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_WAVVE ='https://apis.wavve.com'
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_TVING ='https://api.tving.com'
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_TVINGIMG ='https://image.tving.com'
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_SPOTV ='https://www.spotvnow.co.kr'
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.HTTPTAG ='https://'
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.LIMIT_WAVVE =200
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.LIMIT_TVING =60
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.LIMIT_TVINGEPG=20 
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.DEFAULT_HEADER={'user-agent':srQbdkjqXBmvoHGtLRAVuNanDxElYp.USER_AGENT}
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.SLEEP_TIME =0.2
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.INIT_GENRESORT=MASTER_GENRE
  srQbdkjqXBmvoHGtLRAVuNanDxElYp.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(srQbdkjqXBmvoHGtLRAVuNanDxElYp,jobtype,srQbdkjqXBmvoHGtLRAVuNanDxElYh,payload=srQbdkjqXBmvoHGtLRAVuNanDxElfS,params=srQbdkjqXBmvoHGtLRAVuNanDxElfS,headers=srQbdkjqXBmvoHGtLRAVuNanDxElfS,cookies=srQbdkjqXBmvoHGtLRAVuNanDxElfS,redirects=srQbdkjqXBmvoHGtLRAVuNanDxElfw):
  srQbdkjqXBmvoHGtLRAVuNanDxElYS=srQbdkjqXBmvoHGtLRAVuNanDxElYp.DEFAULT_HEADER
  if headers:srQbdkjqXBmvoHGtLRAVuNanDxElYS.update(headers)
  if jobtype=='Get':
   srQbdkjqXBmvoHGtLRAVuNanDxElYU=requests.get(srQbdkjqXBmvoHGtLRAVuNanDxElYh,params=params,headers=srQbdkjqXBmvoHGtLRAVuNanDxElYS,cookies=cookies,allow_redirects=redirects)
  else:
   srQbdkjqXBmvoHGtLRAVuNanDxElYU=requests.post(srQbdkjqXBmvoHGtLRAVuNanDxElYh,data=payload,params=params,headers=srQbdkjqXBmvoHGtLRAVuNanDxElYS,cookies=cookies,allow_redirects=redirects)
  return srQbdkjqXBmvoHGtLRAVuNanDxElYU
 def Get_DefaultParams_Wavve(srQbdkjqXBmvoHGtLRAVuNanDxElYp):
  srQbdkjqXBmvoHGtLRAVuNanDxElYI={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return srQbdkjqXBmvoHGtLRAVuNanDxElYI
 def Get_DefaultParams_Tving(srQbdkjqXBmvoHGtLRAVuNanDxElYp):
  srQbdkjqXBmvoHGtLRAVuNanDxElYI={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return srQbdkjqXBmvoHGtLRAVuNanDxElYI
 def Get_Now_Datetime(srQbdkjqXBmvoHGtLRAVuNanDxElYp):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(srQbdkjqXBmvoHGtLRAVuNanDxElYp,in_text):
  srQbdkjqXBmvoHGtLRAVuNanDxElYC=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return srQbdkjqXBmvoHGtLRAVuNanDxElYC
 def Get_ChannelList_Wavve(srQbdkjqXBmvoHGtLRAVuNanDxElYp,exceptGroup=[]):
  srQbdkjqXBmvoHGtLRAVuNanDxElYT =[]
  srQbdkjqXBmvoHGtLRAVuNanDxElYJ=srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_ChannelImg_Wavve()
  try:
   srQbdkjqXBmvoHGtLRAVuNanDxElYh=srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_WAVVE+'/cf/live/recommend-channels'
   srQbdkjqXBmvoHGtLRAVuNanDxElYI={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElYp.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   srQbdkjqXBmvoHGtLRAVuNanDxElYI.update(srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_DefaultParams_Wavve())
   srQbdkjqXBmvoHGtLRAVuNanDxElYP=srQbdkjqXBmvoHGtLRAVuNanDxElYp.callRequestCookies('Get',srQbdkjqXBmvoHGtLRAVuNanDxElYh,payload=srQbdkjqXBmvoHGtLRAVuNanDxElfS,params=srQbdkjqXBmvoHGtLRAVuNanDxElYI,headers=srQbdkjqXBmvoHGtLRAVuNanDxElfS,cookies=srQbdkjqXBmvoHGtLRAVuNanDxElfS)
   srQbdkjqXBmvoHGtLRAVuNanDxElYg=json.loads(srQbdkjqXBmvoHGtLRAVuNanDxElYP.text)
   if not('celllist' in srQbdkjqXBmvoHGtLRAVuNanDxElYg['cell_toplist']):return srQbdkjqXBmvoHGtLRAVuNanDxElYT
   srQbdkjqXBmvoHGtLRAVuNanDxElYe=srQbdkjqXBmvoHGtLRAVuNanDxElYg['cell_toplist']['celllist']
   for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElYe:
    srQbdkjqXBmvoHGtLRAVuNanDxElYi=srQbdkjqXBmvoHGtLRAVuNanDxElYO['contentid']
    srQbdkjqXBmvoHGtLRAVuNanDxElYK=srQbdkjqXBmvoHGtLRAVuNanDxElYO['title_list'][0]['text']
    if srQbdkjqXBmvoHGtLRAVuNanDxElYi in srQbdkjqXBmvoHGtLRAVuNanDxElYJ:
     srQbdkjqXBmvoHGtLRAVuNanDxElYy=srQbdkjqXBmvoHGtLRAVuNanDxElYJ[srQbdkjqXBmvoHGtLRAVuNanDxElYi]
    else:
     srQbdkjqXBmvoHGtLRAVuNanDxElYy=''
    srQbdkjqXBmvoHGtLRAVuNanDxElYF=srQbdkjqXBmvoHGtLRAVuNanDxElYp.make_getGenre(srQbdkjqXBmvoHGtLRAVuNanDxElYi,'wavve')
    srQbdkjqXBmvoHGtLRAVuNanDxElcY={'channelid':srQbdkjqXBmvoHGtLRAVuNanDxElYi,'channelnm':srQbdkjqXBmvoHGtLRAVuNanDxElYK,'channelimg':srQbdkjqXBmvoHGtLRAVuNanDxElYp.HTTPTAG+srQbdkjqXBmvoHGtLRAVuNanDxElYy if srQbdkjqXBmvoHGtLRAVuNanDxElYy!='' else '','ott':'wavve','genrenm':srQbdkjqXBmvoHGtLRAVuNanDxElYF}
    if srQbdkjqXBmvoHGtLRAVuNanDxElYF not in exceptGroup:
     srQbdkjqXBmvoHGtLRAVuNanDxElYT.append(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return[]
  return srQbdkjqXBmvoHGtLRAVuNanDxElYT
 def Get_ChannelList_WavveExcept(srQbdkjqXBmvoHGtLRAVuNanDxElYp,exceptGroup=[]):
  srQbdkjqXBmvoHGtLRAVuNanDxElYT=[]
  if exceptGroup==[]:return[]
  try:
   srQbdkjqXBmvoHGtLRAVuNanDxElYh=srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_WAVVE+'/cf/live/recommend-channels'
   for srQbdkjqXBmvoHGtLRAVuNanDxElYO in exceptGroup:
    srQbdkjqXBmvoHGtLRAVuNanDxElYI={'WeekDay':'all','adult':'n','broadcastid':srQbdkjqXBmvoHGtLRAVuNanDxElYO['broadcastid'],'contenttype':'channel','genre':srQbdkjqXBmvoHGtLRAVuNanDxElYO['genre'],'isrecommend':'y','limit':srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElYp.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    srQbdkjqXBmvoHGtLRAVuNanDxElYI.update(srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_DefaultParams_Wavve())
    srQbdkjqXBmvoHGtLRAVuNanDxElYP=srQbdkjqXBmvoHGtLRAVuNanDxElYp.callRequestCookies('Get',srQbdkjqXBmvoHGtLRAVuNanDxElYh,payload=srQbdkjqXBmvoHGtLRAVuNanDxElfS,params=srQbdkjqXBmvoHGtLRAVuNanDxElYI,headers=srQbdkjqXBmvoHGtLRAVuNanDxElfS,cookies=srQbdkjqXBmvoHGtLRAVuNanDxElfS)
    srQbdkjqXBmvoHGtLRAVuNanDxElYg=json.loads(srQbdkjqXBmvoHGtLRAVuNanDxElYP.text)
    if not('celllist' in srQbdkjqXBmvoHGtLRAVuNanDxElYg['cell_toplist']):return srQbdkjqXBmvoHGtLRAVuNanDxElYT
    srQbdkjqXBmvoHGtLRAVuNanDxElYe=srQbdkjqXBmvoHGtLRAVuNanDxElYg['cell_toplist']['celllist']
    for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElYe:
     srQbdkjqXBmvoHGtLRAVuNanDxElYT.append(srQbdkjqXBmvoHGtLRAVuNanDxElYO['contentid'])
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return[]
  return srQbdkjqXBmvoHGtLRAVuNanDxElYT
 def Get_ChannelImg_Wavve(srQbdkjqXBmvoHGtLRAVuNanDxElYp):
  srQbdkjqXBmvoHGtLRAVuNanDxElcW={}
  try:
   srQbdkjqXBmvoHGtLRAVuNanDxElcf=srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_Now_Datetime()
   srQbdkjqXBmvoHGtLRAVuNanDxElcp =srQbdkjqXBmvoHGtLRAVuNanDxElcf+datetime.timedelta(hours=3)
   srQbdkjqXBmvoHGtLRAVuNanDxElYh=srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_WAVVE+'/live/epgs'
   srQbdkjqXBmvoHGtLRAVuNanDxElYI={'limit':srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElYp.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':srQbdkjqXBmvoHGtLRAVuNanDxElcf.strftime('%Y-%m-%d %H:00'),'enddatetime':srQbdkjqXBmvoHGtLRAVuNanDxElcp.strftime('%Y-%m-%d %H:00')}
   srQbdkjqXBmvoHGtLRAVuNanDxElYI.update(srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_DefaultParams_Wavve())
   srQbdkjqXBmvoHGtLRAVuNanDxElYP=srQbdkjqXBmvoHGtLRAVuNanDxElYp.callRequestCookies('Get',srQbdkjqXBmvoHGtLRAVuNanDxElYh,payload=srQbdkjqXBmvoHGtLRAVuNanDxElfS,params=srQbdkjqXBmvoHGtLRAVuNanDxElYI,headers=srQbdkjqXBmvoHGtLRAVuNanDxElfS,cookies=srQbdkjqXBmvoHGtLRAVuNanDxElfS)
   srQbdkjqXBmvoHGtLRAVuNanDxElYg=json.loads(srQbdkjqXBmvoHGtLRAVuNanDxElYP.text)
   srQbdkjqXBmvoHGtLRAVuNanDxElYe=srQbdkjqXBmvoHGtLRAVuNanDxElYg['list']
   for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElYe:
    srQbdkjqXBmvoHGtLRAVuNanDxElcW[srQbdkjqXBmvoHGtLRAVuNanDxElYO['channelid']]=srQbdkjqXBmvoHGtLRAVuNanDxElYO['channelimage']
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
  return srQbdkjqXBmvoHGtLRAVuNanDxElcW
 def Get_ChanneGenrename_Wavve(srQbdkjqXBmvoHGtLRAVuNanDxElYp,srQbdkjqXBmvoHGtLRAVuNanDxElYi):
  try:
   srQbdkjqXBmvoHGtLRAVuNanDxElYh=srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_WAVVE+'/live/channels/'+srQbdkjqXBmvoHGtLRAVuNanDxElYi
   srQbdkjqXBmvoHGtLRAVuNanDxElYI=srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_DefaultParams_Wavve()
   srQbdkjqXBmvoHGtLRAVuNanDxElYP=srQbdkjqXBmvoHGtLRAVuNanDxElYp.callRequestCookies('Get',srQbdkjqXBmvoHGtLRAVuNanDxElYh,payload=srQbdkjqXBmvoHGtLRAVuNanDxElfS,params=srQbdkjqXBmvoHGtLRAVuNanDxElYI,headers=srQbdkjqXBmvoHGtLRAVuNanDxElfS,cookies=srQbdkjqXBmvoHGtLRAVuNanDxElfS)
   srQbdkjqXBmvoHGtLRAVuNanDxElYg=json.loads(srQbdkjqXBmvoHGtLRAVuNanDxElYP.text)
   srQbdkjqXBmvoHGtLRAVuNanDxElcw=srQbdkjqXBmvoHGtLRAVuNanDxElYg['genretext']
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return ''
  return srQbdkjqXBmvoHGtLRAVuNanDxElcw
 def Get_ChannelList_Spotv(srQbdkjqXBmvoHGtLRAVuNanDxElYp,payyn=srQbdkjqXBmvoHGtLRAVuNanDxElfC):
  srQbdkjqXBmvoHGtLRAVuNanDxElYT=[]
  try:
   for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElYf:
    srQbdkjqXBmvoHGtLRAVuNanDxElYi=srQbdkjqXBmvoHGtLRAVuNanDxElYO['videoId']
    srQbdkjqXBmvoHGtLRAVuNanDxElcY={'channelid':srQbdkjqXBmvoHGtLRAVuNanDxElYi,'channelnm':srQbdkjqXBmvoHGtLRAVuNanDxElYO['name'],'channelimg':srQbdkjqXBmvoHGtLRAVuNanDxElYO['logo'],'ott':'spotv','genrenm':srQbdkjqXBmvoHGtLRAVuNanDxElYp.make_getGenre(srQbdkjqXBmvoHGtLRAVuNanDxElYi,'spotv')}
    if payyn==srQbdkjqXBmvoHGtLRAVuNanDxElfC or srQbdkjqXBmvoHGtLRAVuNanDxElYO['free']==srQbdkjqXBmvoHGtLRAVuNanDxElfC:
     srQbdkjqXBmvoHGtLRAVuNanDxElYT.append(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return[]
  return srQbdkjqXBmvoHGtLRAVuNanDxElYT
 def Get_ChannelList_Tving(srQbdkjqXBmvoHGtLRAVuNanDxElYp):
  srQbdkjqXBmvoHGtLRAVuNanDxElYT =[]
  srQbdkjqXBmvoHGtLRAVuNanDxElcz=[]
  try:
   srQbdkjqXBmvoHGtLRAVuNanDxElYh=srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_TVING+'/v2/media/lives'
   srQbdkjqXBmvoHGtLRAVuNanDxElYI={'pageNo':'1','pageSize':srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElYp.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   srQbdkjqXBmvoHGtLRAVuNanDxElYI.update(srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_DefaultParams_Tving())
   srQbdkjqXBmvoHGtLRAVuNanDxElYP=srQbdkjqXBmvoHGtLRAVuNanDxElYp.callRequestCookies('Get',srQbdkjqXBmvoHGtLRAVuNanDxElYh,payload=srQbdkjqXBmvoHGtLRAVuNanDxElfS,params=srQbdkjqXBmvoHGtLRAVuNanDxElYI,headers=srQbdkjqXBmvoHGtLRAVuNanDxElfS,cookies=srQbdkjqXBmvoHGtLRAVuNanDxElfS)
   srQbdkjqXBmvoHGtLRAVuNanDxElYg=json.loads(srQbdkjqXBmvoHGtLRAVuNanDxElYP.text)
   if not('result' in srQbdkjqXBmvoHGtLRAVuNanDxElYg['body']):return srQbdkjqXBmvoHGtLRAVuNanDxElYT
   srQbdkjqXBmvoHGtLRAVuNanDxElYe=srQbdkjqXBmvoHGtLRAVuNanDxElYg['body']['result']
   for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElYe:
    if srQbdkjqXBmvoHGtLRAVuNanDxElYO['live_code']=='C44441':continue 
    srQbdkjqXBmvoHGtLRAVuNanDxElcz.append(srQbdkjqXBmvoHGtLRAVuNanDxElYO['live_code'])
   srQbdkjqXBmvoHGtLRAVuNanDxElYJ=srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_ChannelImg_Tving(srQbdkjqXBmvoHGtLRAVuNanDxElcz)
   for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElYe:
    srQbdkjqXBmvoHGtLRAVuNanDxElYi=srQbdkjqXBmvoHGtLRAVuNanDxElYO['live_code']
    if srQbdkjqXBmvoHGtLRAVuNanDxElYi=='C44441':continue 
    srQbdkjqXBmvoHGtLRAVuNanDxElYK=srQbdkjqXBmvoHGtLRAVuNanDxElYO['schedule']['channel']['name']['ko']
    if srQbdkjqXBmvoHGtLRAVuNanDxElYi in srQbdkjqXBmvoHGtLRAVuNanDxElYJ:
     srQbdkjqXBmvoHGtLRAVuNanDxElYy=srQbdkjqXBmvoHGtLRAVuNanDxElYJ[srQbdkjqXBmvoHGtLRAVuNanDxElYi]
    else:
     srQbdkjqXBmvoHGtLRAVuNanDxElYy=''
    srQbdkjqXBmvoHGtLRAVuNanDxElcY={'channelid':srQbdkjqXBmvoHGtLRAVuNanDxElYi,'channelnm':srQbdkjqXBmvoHGtLRAVuNanDxElYK,'channelimg':srQbdkjqXBmvoHGtLRAVuNanDxElYy,'ott':'tving','genrenm':srQbdkjqXBmvoHGtLRAVuNanDxElYp.make_getGenre(srQbdkjqXBmvoHGtLRAVuNanDxElYi,'tving')}
    srQbdkjqXBmvoHGtLRAVuNanDxElYT.append(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return[]
  return srQbdkjqXBmvoHGtLRAVuNanDxElYT
 def make_EpgDatetime_Tving(srQbdkjqXBmvoHGtLRAVuNanDxElYp,days=2):
  srQbdkjqXBmvoHGtLRAVuNanDxElcS=[]
  srQbdkjqXBmvoHGtLRAVuNanDxElcU=srQbdkjqXBmvoHGtLRAVuNanDxElYp.make_DateList(days=2,dateType='2')
  srQbdkjqXBmvoHGtLRAVuNanDxElcI=srQbdkjqXBmvoHGtLRAVuNanDxElfT(srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElcU:
   for srQbdkjqXBmvoHGtLRAVuNanDxElcM in srQbdkjqXBmvoHGtLRAVuNanDxElfJ(8):
    srQbdkjqXBmvoHGtLRAVuNanDxElcY={'ndate':srQbdkjqXBmvoHGtLRAVuNanDxElYO,'starttm':srQbdkjqXBmvoHGtLRAVuNanDxElYW[srQbdkjqXBmvoHGtLRAVuNanDxElcM]['starttm'],'endtm':srQbdkjqXBmvoHGtLRAVuNanDxElYW[srQbdkjqXBmvoHGtLRAVuNanDxElcM]['endtm']}
    srQbdkjqXBmvoHGtLRAVuNanDxElcC=srQbdkjqXBmvoHGtLRAVuNanDxElfT(srQbdkjqXBmvoHGtLRAVuNanDxElYO+srQbdkjqXBmvoHGtLRAVuNanDxElYW[srQbdkjqXBmvoHGtLRAVuNanDxElcM]['starttm'])
    srQbdkjqXBmvoHGtLRAVuNanDxElcT=srQbdkjqXBmvoHGtLRAVuNanDxElfT(srQbdkjqXBmvoHGtLRAVuNanDxElYO+srQbdkjqXBmvoHGtLRAVuNanDxElYW[srQbdkjqXBmvoHGtLRAVuNanDxElcM]['endtm'])
    if srQbdkjqXBmvoHGtLRAVuNanDxElcI<=srQbdkjqXBmvoHGtLRAVuNanDxElcC or(srQbdkjqXBmvoHGtLRAVuNanDxElcC<srQbdkjqXBmvoHGtLRAVuNanDxElcI and srQbdkjqXBmvoHGtLRAVuNanDxElcI<srQbdkjqXBmvoHGtLRAVuNanDxElcT):
     srQbdkjqXBmvoHGtLRAVuNanDxElcS.append(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
  return srQbdkjqXBmvoHGtLRAVuNanDxElcS
 def make_DateList(srQbdkjqXBmvoHGtLRAVuNanDxElYp,days=2,dateType='1'):
  srQbdkjqXBmvoHGtLRAVuNanDxElcU=[]
  srQbdkjqXBmvoHGtLRAVuNanDxElcJ =srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_Now_Datetime()
  if dateType=='1':
   srQbdkjqXBmvoHGtLRAVuNanDxElcJ=srQbdkjqXBmvoHGtLRAVuNanDxElcJ-datetime.timedelta(days=1)
  for i in srQbdkjqXBmvoHGtLRAVuNanDxElfJ(days):
   srQbdkjqXBmvoHGtLRAVuNanDxElch=srQbdkjqXBmvoHGtLRAVuNanDxElcJ+datetime.timedelta(days=i)
   if dateType=='1':
    srQbdkjqXBmvoHGtLRAVuNanDxElcU.append(srQbdkjqXBmvoHGtLRAVuNanDxElch.strftime('%Y%m%d'))
   else:
    srQbdkjqXBmvoHGtLRAVuNanDxElcU.append(srQbdkjqXBmvoHGtLRAVuNanDxElch.strftime('%Y%m%d'))
  return srQbdkjqXBmvoHGtLRAVuNanDxElcU
 def make_Tving_ChannleGroup(srQbdkjqXBmvoHGtLRAVuNanDxElYp,srQbdkjqXBmvoHGtLRAVuNanDxElcz):
  srQbdkjqXBmvoHGtLRAVuNanDxElcP=[]
  i=0
  srQbdkjqXBmvoHGtLRAVuNanDxElcg=''
  for srQbdkjqXBmvoHGtLRAVuNanDxElce in srQbdkjqXBmvoHGtLRAVuNanDxElcz:
   if i==0:srQbdkjqXBmvoHGtLRAVuNanDxElcg=srQbdkjqXBmvoHGtLRAVuNanDxElce
   else:srQbdkjqXBmvoHGtLRAVuNanDxElcg+=',%s'%(srQbdkjqXBmvoHGtLRAVuNanDxElce)
   i+=1
   if i>=srQbdkjqXBmvoHGtLRAVuNanDxElYp.LIMIT_TVINGEPG:
    srQbdkjqXBmvoHGtLRAVuNanDxElcP.append(srQbdkjqXBmvoHGtLRAVuNanDxElcg)
    i=0
    srQbdkjqXBmvoHGtLRAVuNanDxElcg=''
  if srQbdkjqXBmvoHGtLRAVuNanDxElcg!='':
   srQbdkjqXBmvoHGtLRAVuNanDxElcP.append(srQbdkjqXBmvoHGtLRAVuNanDxElcg)
  return srQbdkjqXBmvoHGtLRAVuNanDxElcP
 def Get_ChannelImg_Tving(srQbdkjqXBmvoHGtLRAVuNanDxElYp,chid_list):
  srQbdkjqXBmvoHGtLRAVuNanDxElcW={}
  try:
   srQbdkjqXBmvoHGtLRAVuNanDxElcO=srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_Now_Datetime().strftime('%Y%m%d')
   srQbdkjqXBmvoHGtLRAVuNanDxElcf =srQbdkjqXBmvoHGtLRAVuNanDxElYW[6]['starttm'] 
   srQbdkjqXBmvoHGtLRAVuNanDxElcp =srQbdkjqXBmvoHGtLRAVuNanDxElYW[6]['endtm']
   srQbdkjqXBmvoHGtLRAVuNanDxElcP=srQbdkjqXBmvoHGtLRAVuNanDxElYp.make_Tving_ChannleGroup(chid_list)
   for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElcP:
    srQbdkjqXBmvoHGtLRAVuNanDxElYh=srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_TVING+'/v2/media/schedules'
    srQbdkjqXBmvoHGtLRAVuNanDxElYI={'pageNo':'1','pageSize':srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElYp.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':srQbdkjqXBmvoHGtLRAVuNanDxElcO,'broadcastDate':srQbdkjqXBmvoHGtLRAVuNanDxElcO,'startBroadTime':srQbdkjqXBmvoHGtLRAVuNanDxElcf,'endBroadTime':srQbdkjqXBmvoHGtLRAVuNanDxElcp,'channelCode':srQbdkjqXBmvoHGtLRAVuNanDxElYO}
    srQbdkjqXBmvoHGtLRAVuNanDxElYI.update(srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_DefaultParams_Tving())
    srQbdkjqXBmvoHGtLRAVuNanDxElYP=srQbdkjqXBmvoHGtLRAVuNanDxElYp.callRequestCookies('Get',srQbdkjqXBmvoHGtLRAVuNanDxElYh,payload=srQbdkjqXBmvoHGtLRAVuNanDxElfS,params=srQbdkjqXBmvoHGtLRAVuNanDxElYI,headers=srQbdkjqXBmvoHGtLRAVuNanDxElfS,cookies=srQbdkjqXBmvoHGtLRAVuNanDxElfS)
    srQbdkjqXBmvoHGtLRAVuNanDxElYg=json.loads(srQbdkjqXBmvoHGtLRAVuNanDxElYP.text)
    if not('result' in srQbdkjqXBmvoHGtLRAVuNanDxElYg['body']):return{}
    srQbdkjqXBmvoHGtLRAVuNanDxElYe=srQbdkjqXBmvoHGtLRAVuNanDxElYg['body']['result']
    for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElYe:
     srQbdkjqXBmvoHGtLRAVuNanDxElcW[srQbdkjqXBmvoHGtLRAVuNanDxElYO['channel_code']]=srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_TVINGIMG+srQbdkjqXBmvoHGtLRAVuNanDxElYO['image'][2]['url']
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return{}
  return srQbdkjqXBmvoHGtLRAVuNanDxElcW
 def Get_EpgInfo_Spotv(srQbdkjqXBmvoHGtLRAVuNanDxElYp,days=3,payyn=srQbdkjqXBmvoHGtLRAVuNanDxElfC):
  srQbdkjqXBmvoHGtLRAVuNanDxElYT=[]
  srQbdkjqXBmvoHGtLRAVuNanDxElci =[]
  try:
   for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElYf:
    srQbdkjqXBmvoHGtLRAVuNanDxElYi =srQbdkjqXBmvoHGtLRAVuNanDxElYO['videoId']
    srQbdkjqXBmvoHGtLRAVuNanDxElcY={'channelid':srQbdkjqXBmvoHGtLRAVuNanDxElYi,'channelnm':srQbdkjqXBmvoHGtLRAVuNanDxElYp.xmlText(srQbdkjqXBmvoHGtLRAVuNanDxElYO['name']),'channelimg':srQbdkjqXBmvoHGtLRAVuNanDxElYO['logo'],'ott':'spotv','epgtype':srQbdkjqXBmvoHGtLRAVuNanDxElYO['epgtype'],'epgnm':srQbdkjqXBmvoHGtLRAVuNanDxElYO['epgnm']}
    if payyn==srQbdkjqXBmvoHGtLRAVuNanDxElfC or srQbdkjqXBmvoHGtLRAVuNanDxElYO['free']==srQbdkjqXBmvoHGtLRAVuNanDxElfC:
     srQbdkjqXBmvoHGtLRAVuNanDxElYT.append(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return[],[]
  '''
  try:
   for now_day in days_list:
    url = self.API_SPOTV + '/api/v2/program/' + now_day
    response = self.callRequestCookies('Get', url, payload=None, params=None, headers=None, cookies=None )
    res_json = json.loads(response.text )
    for i_section in res_json:
     if find_list.get(i_section['channelId'] ) == None: continue
     temp_list = {'channelid' : find_list.get(i_section['channelId'] ) , 'title' : self.xmlText(i_section['title'] ) , 'startTime' : i_section['startTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'endTime' : i_section['endTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'ott' : 'spotv' }
     epg_list.append(temp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  try:
   for srQbdkjqXBmvoHGtLRAVuNanDxElcK in srQbdkjqXBmvoHGtLRAVuNanDxElYT:
    if srQbdkjqXBmvoHGtLRAVuNanDxElcK['epgtype']=='spotvon':
     srQbdkjqXBmvoHGtLRAVuNanDxElcy=srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_EpgInfo_Spotv_spotvon(srQbdkjqXBmvoHGtLRAVuNanDxElcK['channelid'],srQbdkjqXBmvoHGtLRAVuNanDxElcK['epgnm'],days)
     if srQbdkjqXBmvoHGtLRAVuNanDxElfh(srQbdkjqXBmvoHGtLRAVuNanDxElcy)>0:srQbdkjqXBmvoHGtLRAVuNanDxElci.extend(srQbdkjqXBmvoHGtLRAVuNanDxElcy)
    if srQbdkjqXBmvoHGtLRAVuNanDxElcK['epgtype']=='spotvnet':
     srQbdkjqXBmvoHGtLRAVuNanDxElcy=srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_EpgInfo_Spotv_spotvnet(srQbdkjqXBmvoHGtLRAVuNanDxElcK['channelid'],srQbdkjqXBmvoHGtLRAVuNanDxElcK['epgnm'],days)
     if srQbdkjqXBmvoHGtLRAVuNanDxElfh(srQbdkjqXBmvoHGtLRAVuNanDxElcy)>0:srQbdkjqXBmvoHGtLRAVuNanDxElci.extend(srQbdkjqXBmvoHGtLRAVuNanDxElcy)
    time.sleep(srQbdkjqXBmvoHGtLRAVuNanDxElYp.SLEEP_TIME)
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return[],[]
  return srQbdkjqXBmvoHGtLRAVuNanDxElYT,srQbdkjqXBmvoHGtLRAVuNanDxElci
 def Get_EpgInfo_Spotv_spotvon(srQbdkjqXBmvoHGtLRAVuNanDxElYp,srQbdkjqXBmvoHGtLRAVuNanDxElYi,epgnm,days):
  srQbdkjqXBmvoHGtLRAVuNanDxElci =[]
  srQbdkjqXBmvoHGtLRAVuNanDxElcU=srQbdkjqXBmvoHGtLRAVuNanDxElYp.make_DateList(days=days,dateType='1')
  srQbdkjqXBmvoHGtLRAVuNanDxElcF=''
  try:
   for srQbdkjqXBmvoHGtLRAVuNanDxElWY in srQbdkjqXBmvoHGtLRAVuNanDxElcU:
    srQbdkjqXBmvoHGtLRAVuNanDxElYh='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,srQbdkjqXBmvoHGtLRAVuNanDxElWY)
    srQbdkjqXBmvoHGtLRAVuNanDxElYP=srQbdkjqXBmvoHGtLRAVuNanDxElYp.callRequestCookies('Get',srQbdkjqXBmvoHGtLRAVuNanDxElYh,payload=srQbdkjqXBmvoHGtLRAVuNanDxElfS,params=srQbdkjqXBmvoHGtLRAVuNanDxElfS,headers=srQbdkjqXBmvoHGtLRAVuNanDxElfS,cookies=srQbdkjqXBmvoHGtLRAVuNanDxElfS)
    srQbdkjqXBmvoHGtLRAVuNanDxElYg=json.loads(srQbdkjqXBmvoHGtLRAVuNanDxElYP.text)
    for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElYg:
     srQbdkjqXBmvoHGtLRAVuNanDxElcY={'channelid':srQbdkjqXBmvoHGtLRAVuNanDxElYi,'title':srQbdkjqXBmvoHGtLRAVuNanDxElYp.xmlText(srQbdkjqXBmvoHGtLRAVuNanDxElYO['title']),'startTime':srQbdkjqXBmvoHGtLRAVuNanDxElYO['sch_date'].replace('-','')+srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElYO['sch_hour']).zfill(2)+srQbdkjqXBmvoHGtLRAVuNanDxElYO['sch_min']+'00','ott':'spotv'}
     srQbdkjqXBmvoHGtLRAVuNanDxElci.append(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
    srQbdkjqXBmvoHGtLRAVuNanDxElcF=srQbdkjqXBmvoHGtLRAVuNanDxElWY
   for i in srQbdkjqXBmvoHGtLRAVuNanDxElfJ(srQbdkjqXBmvoHGtLRAVuNanDxElfh(srQbdkjqXBmvoHGtLRAVuNanDxElci)):
    if i>0:srQbdkjqXBmvoHGtLRAVuNanDxElci[i-1]['endTime']=srQbdkjqXBmvoHGtLRAVuNanDxElci[i]['startTime']
    if i==srQbdkjqXBmvoHGtLRAVuNanDxElfh(srQbdkjqXBmvoHGtLRAVuNanDxElci)-1: srQbdkjqXBmvoHGtLRAVuNanDxElci[i]['endTime']=srQbdkjqXBmvoHGtLRAVuNanDxElcF+'240000'
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return[]
  return srQbdkjqXBmvoHGtLRAVuNanDxElci
 def Get_EpgInfo_Spotv_spotvnet(srQbdkjqXBmvoHGtLRAVuNanDxElYp,srQbdkjqXBmvoHGtLRAVuNanDxElYi,epgnm,days):
  srQbdkjqXBmvoHGtLRAVuNanDxElci =[]
  srQbdkjqXBmvoHGtLRAVuNanDxElcU=srQbdkjqXBmvoHGtLRAVuNanDxElYp.make_DateList(days=days,dateType='1')
  srQbdkjqXBmvoHGtLRAVuNanDxElcF=''
  try:
   for srQbdkjqXBmvoHGtLRAVuNanDxElWY in srQbdkjqXBmvoHGtLRAVuNanDxElcU:
    srQbdkjqXBmvoHGtLRAVuNanDxElYh='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,srQbdkjqXBmvoHGtLRAVuNanDxElWY)
    srQbdkjqXBmvoHGtLRAVuNanDxElYP=srQbdkjqXBmvoHGtLRAVuNanDxElYp.callRequestCookies('Get',srQbdkjqXBmvoHGtLRAVuNanDxElYh,payload=srQbdkjqXBmvoHGtLRAVuNanDxElfS,params=srQbdkjqXBmvoHGtLRAVuNanDxElfS,headers=srQbdkjqXBmvoHGtLRAVuNanDxElfS,cookies=srQbdkjqXBmvoHGtLRAVuNanDxElfS)
    srQbdkjqXBmvoHGtLRAVuNanDxElYg=json.loads(srQbdkjqXBmvoHGtLRAVuNanDxElYP.text)
    for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElYg:
     srQbdkjqXBmvoHGtLRAVuNanDxElcY={'channelid':srQbdkjqXBmvoHGtLRAVuNanDxElYi,'title':srQbdkjqXBmvoHGtLRAVuNanDxElYp.xmlText(srQbdkjqXBmvoHGtLRAVuNanDxElYO['title']),'startTime':srQbdkjqXBmvoHGtLRAVuNanDxElYO['sch_date'].replace('-','')+srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElYO['sch_hour']).zfill(2)+srQbdkjqXBmvoHGtLRAVuNanDxElYO['sch_min']+'00','ott':'spotv'}
     srQbdkjqXBmvoHGtLRAVuNanDxElci.append(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
    srQbdkjqXBmvoHGtLRAVuNanDxElcF=srQbdkjqXBmvoHGtLRAVuNanDxElWY
   for i in srQbdkjqXBmvoHGtLRAVuNanDxElfJ(srQbdkjqXBmvoHGtLRAVuNanDxElfh(srQbdkjqXBmvoHGtLRAVuNanDxElci)):
    if i>0:srQbdkjqXBmvoHGtLRAVuNanDxElci[i-1]['endTime']=srQbdkjqXBmvoHGtLRAVuNanDxElci[i]['startTime']
    if i==srQbdkjqXBmvoHGtLRAVuNanDxElfh(srQbdkjqXBmvoHGtLRAVuNanDxElci)-1: srQbdkjqXBmvoHGtLRAVuNanDxElci[i]['endTime']=srQbdkjqXBmvoHGtLRAVuNanDxElcF+'240000'
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return[]
  return srQbdkjqXBmvoHGtLRAVuNanDxElci
 def Get_EpgInfo_Wavve(srQbdkjqXBmvoHGtLRAVuNanDxElYp,days=2,exceptGroup=[]):
  srQbdkjqXBmvoHGtLRAVuNanDxElYT =[]
  srQbdkjqXBmvoHGtLRAVuNanDxElci =[]
  srQbdkjqXBmvoHGtLRAVuNanDxElcJ =srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_Now_Datetime()
  srQbdkjqXBmvoHGtLRAVuNanDxElWc =srQbdkjqXBmvoHGtLRAVuNanDxElcJ+datetime.timedelta(hours=-2)
  srQbdkjqXBmvoHGtLRAVuNanDxElWf =srQbdkjqXBmvoHGtLRAVuNanDxElcJ+datetime.timedelta(days=(days-1))
  if srQbdkjqXBmvoHGtLRAVuNanDxElfT(srQbdkjqXBmvoHGtLRAVuNanDxElWc.strftime('%H'))<=3:
   srQbdkjqXBmvoHGtLRAVuNanDxElWp=srQbdkjqXBmvoHGtLRAVuNanDxElWc.strftime('%Y-%m-%d 00:00')
  else:
   srQbdkjqXBmvoHGtLRAVuNanDxElWp=srQbdkjqXBmvoHGtLRAVuNanDxElWc.strftime('%Y-%m-%d %H:00')
  srQbdkjqXBmvoHGtLRAVuNanDxElWw =srQbdkjqXBmvoHGtLRAVuNanDxElWf.strftime('%Y-%m-%d 24:00')
  try:
   srQbdkjqXBmvoHGtLRAVuNanDxElYh=srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_WAVVE+'/live/epgs'
   srQbdkjqXBmvoHGtLRAVuNanDxElYI={'limit':srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElYp.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':srQbdkjqXBmvoHGtLRAVuNanDxElWp,'enddatetime':srQbdkjqXBmvoHGtLRAVuNanDxElWw}
   srQbdkjqXBmvoHGtLRAVuNanDxElYI.update(srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_DefaultParams_Wavve())
   srQbdkjqXBmvoHGtLRAVuNanDxElYP=srQbdkjqXBmvoHGtLRAVuNanDxElYp.callRequestCookies('Get',srQbdkjqXBmvoHGtLRAVuNanDxElYh,payload=srQbdkjqXBmvoHGtLRAVuNanDxElfS,params=srQbdkjqXBmvoHGtLRAVuNanDxElYI,headers=srQbdkjqXBmvoHGtLRAVuNanDxElfS,cookies=srQbdkjqXBmvoHGtLRAVuNanDxElfS)
   srQbdkjqXBmvoHGtLRAVuNanDxElYg=json.loads(srQbdkjqXBmvoHGtLRAVuNanDxElYP.text)
   srQbdkjqXBmvoHGtLRAVuNanDxElWz=srQbdkjqXBmvoHGtLRAVuNanDxElYg['list']
   for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElWz:
    srQbdkjqXBmvoHGtLRAVuNanDxElYi =srQbdkjqXBmvoHGtLRAVuNanDxElYO['channelid']
    srQbdkjqXBmvoHGtLRAVuNanDxElYF=srQbdkjqXBmvoHGtLRAVuNanDxElYp.make_getGenre(srQbdkjqXBmvoHGtLRAVuNanDxElYi,'wavve')
    srQbdkjqXBmvoHGtLRAVuNanDxElcY={'channelid':srQbdkjqXBmvoHGtLRAVuNanDxElYi,'channelnm':srQbdkjqXBmvoHGtLRAVuNanDxElYp.xmlText(srQbdkjqXBmvoHGtLRAVuNanDxElYO['channelname']),'channelimg':srQbdkjqXBmvoHGtLRAVuNanDxElYp.HTTPTAG+srQbdkjqXBmvoHGtLRAVuNanDxElYO['channelimage'],'ott':'wavve'}
    if srQbdkjqXBmvoHGtLRAVuNanDxElYF not in exceptGroup:
     srQbdkjqXBmvoHGtLRAVuNanDxElYT.append(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
    for srQbdkjqXBmvoHGtLRAVuNanDxElWS in srQbdkjqXBmvoHGtLRAVuNanDxElYO['list']:
     srQbdkjqXBmvoHGtLRAVuNanDxElcY={'channelid':srQbdkjqXBmvoHGtLRAVuNanDxElYO['channelid'],'title':srQbdkjqXBmvoHGtLRAVuNanDxElYp.xmlText(srQbdkjqXBmvoHGtLRAVuNanDxElWS['title']),'startTime':srQbdkjqXBmvoHGtLRAVuNanDxElWS['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':srQbdkjqXBmvoHGtLRAVuNanDxElWS['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if srQbdkjqXBmvoHGtLRAVuNanDxElYF not in exceptGroup and srQbdkjqXBmvoHGtLRAVuNanDxElWS['starttime']!=srQbdkjqXBmvoHGtLRAVuNanDxElWS['endtime']:
      srQbdkjqXBmvoHGtLRAVuNanDxElci.append(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return[],[]
  srQbdkjqXBmvoHGtLRAVuNanDxElWU=srQbdkjqXBmvoHGtLRAVuNanDxElfh(srQbdkjqXBmvoHGtLRAVuNanDxElci)
  for i in(srQbdkjqXBmvoHGtLRAVuNanDxElfJ(1,srQbdkjqXBmvoHGtLRAVuNanDxElWU)):
   if srQbdkjqXBmvoHGtLRAVuNanDxElfT(srQbdkjqXBmvoHGtLRAVuNanDxElci[i-1]['endTime'])+1==srQbdkjqXBmvoHGtLRAVuNanDxElfT(srQbdkjqXBmvoHGtLRAVuNanDxElci[i]['startTime'])and srQbdkjqXBmvoHGtLRAVuNanDxElci[i-1]['channelid']==srQbdkjqXBmvoHGtLRAVuNanDxElci[i]['channelid']:
    srQbdkjqXBmvoHGtLRAVuNanDxElci[i-1]['endTime']=srQbdkjqXBmvoHGtLRAVuNanDxElci[i]['startTime']
  return srQbdkjqXBmvoHGtLRAVuNanDxElYT,srQbdkjqXBmvoHGtLRAVuNanDxElci
 def Get_EpgInfo_Tving(srQbdkjqXBmvoHGtLRAVuNanDxElYp,days=2):
  srQbdkjqXBmvoHGtLRAVuNanDxElYT=[]
  srQbdkjqXBmvoHGtLRAVuNanDxElci =[]
  srQbdkjqXBmvoHGtLRAVuNanDxElWI =[]
  srQbdkjqXBmvoHGtLRAVuNanDxElWM =srQbdkjqXBmvoHGtLRAVuNanDxElYp.make_EpgDatetime_Tving(days=days)
  srQbdkjqXBmvoHGtLRAVuNanDxElYT =srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_ChannelList_Tving()
  srQbdkjqXBmvoHGtLRAVuNanDxElWC=[]
  for i in srQbdkjqXBmvoHGtLRAVuNanDxElfJ(srQbdkjqXBmvoHGtLRAVuNanDxElfh(srQbdkjqXBmvoHGtLRAVuNanDxElYT)):
   srQbdkjqXBmvoHGtLRAVuNanDxElYT[i]['channelnm']=srQbdkjqXBmvoHGtLRAVuNanDxElYp.xmlText(srQbdkjqXBmvoHGtLRAVuNanDxElYT[i]['channelnm'])
   srQbdkjqXBmvoHGtLRAVuNanDxElWC.append(srQbdkjqXBmvoHGtLRAVuNanDxElYT[i]['channelid'])
  srQbdkjqXBmvoHGtLRAVuNanDxElWT=srQbdkjqXBmvoHGtLRAVuNanDxElYp.make_Tving_ChannleGroup(srQbdkjqXBmvoHGtLRAVuNanDxElWC)
  try:
   srQbdkjqXBmvoHGtLRAVuNanDxElYh=srQbdkjqXBmvoHGtLRAVuNanDxElYp.API_TVING+'/v2/media/schedules'
   for srQbdkjqXBmvoHGtLRAVuNanDxElWJ in srQbdkjqXBmvoHGtLRAVuNanDxElWM:
    for srQbdkjqXBmvoHGtLRAVuNanDxElcK in srQbdkjqXBmvoHGtLRAVuNanDxElWT:
     srQbdkjqXBmvoHGtLRAVuNanDxElYI={'pageNo':'1','pageSize':srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElYp.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':srQbdkjqXBmvoHGtLRAVuNanDxElWJ['ndate'],'broadcastDate':srQbdkjqXBmvoHGtLRAVuNanDxElWJ['ndate'],'startBroadTime':srQbdkjqXBmvoHGtLRAVuNanDxElWJ['starttm'],'endBroadTime':srQbdkjqXBmvoHGtLRAVuNanDxElWJ['endtm'],'channelCode':srQbdkjqXBmvoHGtLRAVuNanDxElcK}
     srQbdkjqXBmvoHGtLRAVuNanDxElYI.update(srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_DefaultParams_Tving())
     srQbdkjqXBmvoHGtLRAVuNanDxElYP=srQbdkjqXBmvoHGtLRAVuNanDxElYp.callRequestCookies('Get',srQbdkjqXBmvoHGtLRAVuNanDxElYh,payload=srQbdkjqXBmvoHGtLRAVuNanDxElfS,params=srQbdkjqXBmvoHGtLRAVuNanDxElYI,headers=srQbdkjqXBmvoHGtLRAVuNanDxElfS,cookies=srQbdkjqXBmvoHGtLRAVuNanDxElfS)
     srQbdkjqXBmvoHGtLRAVuNanDxElYg=json.loads(srQbdkjqXBmvoHGtLRAVuNanDxElYP.text)
     srQbdkjqXBmvoHGtLRAVuNanDxElYe=srQbdkjqXBmvoHGtLRAVuNanDxElYg['body']['result']
     for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElYe:
      if 'schedules' not in srQbdkjqXBmvoHGtLRAVuNanDxElYO:continue
      if srQbdkjqXBmvoHGtLRAVuNanDxElYO['schedules']==srQbdkjqXBmvoHGtLRAVuNanDxElfS:continue
      for srQbdkjqXBmvoHGtLRAVuNanDxElWh in srQbdkjqXBmvoHGtLRAVuNanDxElYO['schedules']:
       srQbdkjqXBmvoHGtLRAVuNanDxElcY={'channelid':srQbdkjqXBmvoHGtLRAVuNanDxElWh['schedule_code'],'title':srQbdkjqXBmvoHGtLRAVuNanDxElYp.xmlText(srQbdkjqXBmvoHGtLRAVuNanDxElWh['program']['name']['ko']),'startTime':srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElWh['broadcast_start_time']),'endTime':srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElWh['broadcast_end_time']),'ott':'tving'}
       srQbdkjqXBmvoHGtLRAVuNanDxElWP=srQbdkjqXBmvoHGtLRAVuNanDxElWh['schedule_code']+srQbdkjqXBmvoHGtLRAVuNanDxElfU(srQbdkjqXBmvoHGtLRAVuNanDxElWh['broadcast_start_time'])
       if srQbdkjqXBmvoHGtLRAVuNanDxElWP in srQbdkjqXBmvoHGtLRAVuNanDxElWI:continue
       srQbdkjqXBmvoHGtLRAVuNanDxElWI.append(srQbdkjqXBmvoHGtLRAVuNanDxElWP)
       srQbdkjqXBmvoHGtLRAVuNanDxElci.append(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
     time.sleep(srQbdkjqXBmvoHGtLRAVuNanDxElYp.SLEEP_TIME)
  except srQbdkjqXBmvoHGtLRAVuNanDxElfI as exception:
   srQbdkjqXBmvoHGtLRAVuNanDxElfM(exception)
   return[],[]
  return srQbdkjqXBmvoHGtLRAVuNanDxElYT,srQbdkjqXBmvoHGtLRAVuNanDxElci
 def make_getGenre(srQbdkjqXBmvoHGtLRAVuNanDxElYp,srQbdkjqXBmvoHGtLRAVuNanDxElYi,srQbdkjqXBmvoHGtLRAVuNanDxElfc):
  try:
   srQbdkjqXBmvoHGtLRAVuNanDxElcw=srQbdkjqXBmvoHGtLRAVuNanDxElYp.INIT_CHANNEL.get(srQbdkjqXBmvoHGtLRAVuNanDxElYi+'.'+srQbdkjqXBmvoHGtLRAVuNanDxElfc).get('genre')
  except:
   srQbdkjqXBmvoHGtLRAVuNanDxElcw='-'
  return srQbdkjqXBmvoHGtLRAVuNanDxElcw
 def make_base_allchannel_py(srQbdkjqXBmvoHGtLRAVuNanDxElYp):
  srQbdkjqXBmvoHGtLRAVuNanDxElWg =[]
  srQbdkjqXBmvoHGtLRAVuNanDxElWe=[]
  srQbdkjqXBmvoHGtLRAVuNanDxElWO=srQbdkjqXBmvoHGtLRAVuNanDxElfP()
  srQbdkjqXBmvoHGtLRAVuNanDxElcY=srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_ChannelList_Wavve()
  srQbdkjqXBmvoHGtLRAVuNanDxElWg.extend(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
  srQbdkjqXBmvoHGtLRAVuNanDxElcY=srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_ChannelList_Tving()
  srQbdkjqXBmvoHGtLRAVuNanDxElWg.extend(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
  srQbdkjqXBmvoHGtLRAVuNanDxElcY=srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_ChannelList_Spotv()
  srQbdkjqXBmvoHGtLRAVuNanDxElWg.extend(srQbdkjqXBmvoHGtLRAVuNanDxElcY)
  srQbdkjqXBmvoHGtLRAVuNanDxElfM('1')
  for i in srQbdkjqXBmvoHGtLRAVuNanDxElfJ(srQbdkjqXBmvoHGtLRAVuNanDxElfh(srQbdkjqXBmvoHGtLRAVuNanDxElWg)):
   if srQbdkjqXBmvoHGtLRAVuNanDxElWg[i]['genrenm']=='-':
    if srQbdkjqXBmvoHGtLRAVuNanDxElWg[i]['ott']=='wavve':
     srQbdkjqXBmvoHGtLRAVuNanDxElcw=srQbdkjqXBmvoHGtLRAVuNanDxElYp.Get_ChanneGenrename_Wavve(srQbdkjqXBmvoHGtLRAVuNanDxElWg[i]['channelid'])
     if srQbdkjqXBmvoHGtLRAVuNanDxElcw not in srQbdkjqXBmvoHGtLRAVuNanDxElWO:srQbdkjqXBmvoHGtLRAVuNanDxElWO.add(srQbdkjqXBmvoHGtLRAVuNanDxElcw)
     time.sleep(srQbdkjqXBmvoHGtLRAVuNanDxElYp.SLEEP_TIME)
    elif srQbdkjqXBmvoHGtLRAVuNanDxElWg[i]['ott']=='spotv':
     srQbdkjqXBmvoHGtLRAVuNanDxElcw='스포츠'
    else:
     srQbdkjqXBmvoHGtLRAVuNanDxElcw='-'
    srQbdkjqXBmvoHGtLRAVuNanDxElWg[i]['genrenm']=srQbdkjqXBmvoHGtLRAVuNanDxElcw
   else:
    if srQbdkjqXBmvoHGtLRAVuNanDxElWg[i]['genrenm']not in srQbdkjqXBmvoHGtLRAVuNanDxElWO:srQbdkjqXBmvoHGtLRAVuNanDxElWO.add(srQbdkjqXBmvoHGtLRAVuNanDxElWg[i]['genrenm'])
  srQbdkjqXBmvoHGtLRAVuNanDxElWO.add('-')
  srQbdkjqXBmvoHGtLRAVuNanDxElfM('2')
  for srQbdkjqXBmvoHGtLRAVuNanDxElWi in srQbdkjqXBmvoHGtLRAVuNanDxElWO:
   for srQbdkjqXBmvoHGtLRAVuNanDxElWK in srQbdkjqXBmvoHGtLRAVuNanDxElWg:
    if srQbdkjqXBmvoHGtLRAVuNanDxElWK['genrenm']==srQbdkjqXBmvoHGtLRAVuNanDxElWi:
     srQbdkjqXBmvoHGtLRAVuNanDxElWe.append(srQbdkjqXBmvoHGtLRAVuNanDxElWK)
  for srQbdkjqXBmvoHGtLRAVuNanDxElWK in srQbdkjqXBmvoHGtLRAVuNanDxElWg:
   if srQbdkjqXBmvoHGtLRAVuNanDxElWK['genrenm']not in srQbdkjqXBmvoHGtLRAVuNanDxElWO:
    srQbdkjqXBmvoHGtLRAVuNanDxElWy.append(srQbdkjqXBmvoHGtLRAVuNanDxElWK)
  srQbdkjqXBmvoHGtLRAVuNanDxElfM('3')
  srQbdkjqXBmvoHGtLRAVuNanDxElWF='d:\\job\\channelgenre.json'
  if os.path.isfile(srQbdkjqXBmvoHGtLRAVuNanDxElWF):os.remove(srQbdkjqXBmvoHGtLRAVuNanDxElWF)
  fp=srQbdkjqXBmvoHGtLRAVuNanDxElfg(srQbdkjqXBmvoHGtLRAVuNanDxElWF,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  srQbdkjqXBmvoHGtLRAVuNanDxElfY=srQbdkjqXBmvoHGtLRAVuNanDxElfh(srQbdkjqXBmvoHGtLRAVuNanDxElWe)
  i=0
  for srQbdkjqXBmvoHGtLRAVuNanDxElYO in srQbdkjqXBmvoHGtLRAVuNanDxElWe:
   i+=1
   srQbdkjqXBmvoHGtLRAVuNanDxElYi =srQbdkjqXBmvoHGtLRAVuNanDxElYO['channelid']
   srQbdkjqXBmvoHGtLRAVuNanDxElYK =srQbdkjqXBmvoHGtLRAVuNanDxElYO['channelnm']
   srQbdkjqXBmvoHGtLRAVuNanDxElfc =srQbdkjqXBmvoHGtLRAVuNanDxElYO['ott']
   srQbdkjqXBmvoHGtLRAVuNanDxElfW ='%s.%s'%(srQbdkjqXBmvoHGtLRAVuNanDxElYi,srQbdkjqXBmvoHGtLRAVuNanDxElfc)
   srQbdkjqXBmvoHGtLRAVuNanDxElcw =srQbdkjqXBmvoHGtLRAVuNanDxElYO['genrenm']
   srQbdkjqXBmvoHGtLRAVuNanDxElfp='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(srQbdkjqXBmvoHGtLRAVuNanDxElfW,srQbdkjqXBmvoHGtLRAVuNanDxElYK,srQbdkjqXBmvoHGtLRAVuNanDxElcw)
   if i<srQbdkjqXBmvoHGtLRAVuNanDxElfY:
    fp.write(srQbdkjqXBmvoHGtLRAVuNanDxElfp+',\n')
   else:
    fp.write(srQbdkjqXBmvoHGtLRAVuNanDxElfp+'\n')
  fp.write('}\n')
  fp.close()
  return srQbdkjqXBmvoHGtLRAVuNanDxElWO
# Created by pyminifier (https://github.com/liftoff/pyminifier)
