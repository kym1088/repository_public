__author__="NightRain"
import os
import sys
import xbmcaddon,xbmcvfs
import urllib
__cwd__=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
__lib__=os.path.join(__cwd__,'resources','lib')
sys.path.append(__lib__)
from boritvServiceRun import*
dMbvoRmaNOpzrWYihxGqfyIASQswtK=xbmc.Monitor()
dMbvoRmaNOpzrWYihxGqfyIASQswtn=PUblfHDwgOcnYBrGkTahemXFuLVJEQ()
xbmc.sleep(dMbvoRmaNOpzrWYihxGqfyIASQswtn.START_INTERVAL)
while not dMbvoRmaNOpzrWYihxGqfyIASQswtK.abortRequested():
 if dMbvoRmaNOpzrWYihxGqfyIASQswtK.waitForAbort(dMbvoRmaNOpzrWYihxGqfyIASQswtn.INTERVAL):
  break
 dMbvoRmaNOpzrWYihxGqfyIASQswtn.service_run()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
