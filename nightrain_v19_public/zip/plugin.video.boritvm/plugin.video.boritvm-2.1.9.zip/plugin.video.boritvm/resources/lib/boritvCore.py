__author__="NightRain"
ITmlcPxRFtBjWzAhfYsuiCOyabHkeU=False
ITmlcPxRFtBjWzAhfYsuiCOyabHkeQ=object
ITmlcPxRFtBjWzAhfYsuiCOyabHked=None
ITmlcPxRFtBjWzAhfYsuiCOyabHkeL=str
ITmlcPxRFtBjWzAhfYsuiCOyabHkeo=Exception
ITmlcPxRFtBjWzAhfYsuiCOyabHkep=print
ITmlcPxRFtBjWzAhfYsuiCOyabHkeN=True
ITmlcPxRFtBjWzAhfYsuiCOyabHkeK=int
ITmlcPxRFtBjWzAhfYsuiCOyabHkeX=range
ITmlcPxRFtBjWzAhfYsuiCOyabHkeD=len
ITmlcPxRFtBjWzAhfYsuiCOyabHkeG=dict
ITmlcPxRFtBjWzAhfYsuiCOyabHkev=set
ITmlcPxRFtBjWzAhfYsuiCOyabHkeV=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
ITmlcPxRFtBjWzAhfYsuiCOyabHkSQ=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
ITmlcPxRFtBjWzAhfYsuiCOyabHkSd=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':ITmlcPxRFtBjWzAhfYsuiCOyabHkeU,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':ITmlcPxRFtBjWzAhfYsuiCOyabHkeU,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':ITmlcPxRFtBjWzAhfYsuiCOyabHkeU,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':ITmlcPxRFtBjWzAhfYsuiCOyabHkeU,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':ITmlcPxRFtBjWzAhfYsuiCOyabHkeU,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':ITmlcPxRFtBjWzAhfYsuiCOyabHkeU,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class ITmlcPxRFtBjWzAhfYsuiCOyabHkSU(ITmlcPxRFtBjWzAhfYsuiCOyabHkeQ):
 def __init__(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_WAVVE ='https://apis.wavve.com'
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_TVING ='https://api.tving.com'
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_TVINGIMG ='https://image.tving.com'
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_SPOTV ='https://www.spotvnow.co.kr'
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_SEEZN ='https://api.seezntv.com'
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.HTTPTAG ='https://'
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.LIMIT_WAVVE =200
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.LIMIT_TVING =60
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.LIMIT_TVINGEPG=20 
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36'
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.APPVERSION ='99.0.4844.82' 
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.DEVICEMODEL ='Chrome' 
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.OSTYPE ='Windows' 
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.OSVERSION ='NT 10.0' 
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.SEEZN_HEADER ={'X-APP-VERSION':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.APPVERSION,'X-DEVICE-MODEL':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.DEVICEMODEL,'X-OS-TYPE':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.OSTYPE,'X-OS-VERSION':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.OSVERSION,'X-DEVICE-TYPE':'PCWEB',}
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.DEFAULT_HEADER={'user-agent':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.USER_AGENT}
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.SLEEP_TIME =0.2
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.INIT_GENRESORT=MASTER_GENRE
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,jobtype,ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHked,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked,redirects=ITmlcPxRFtBjWzAhfYsuiCOyabHkeU):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSp=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.DEFAULT_HEADER
  if headers:ITmlcPxRFtBjWzAhfYsuiCOyabHkSp.update(headers)
  if jobtype=='Get':
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSN=requests.get(ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,params=params,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHkSp,cookies=cookies,allow_redirects=redirects)
  else:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSN=requests.post(ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,data=payload,params=params,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHkSp,cookies=cookies,allow_redirects=redirects)
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSN
 def Get_DefaultParams_Wavve(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSK={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSK
 def Get_DefaultParams_Tving(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSK={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSK
 def Get_Now_Datetime(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,in_text):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSD=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSD
 def Get_ChannelList_Wavve(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,exceptGroup=[]):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSv=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_ChannelImg_Wavve()
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_WAVVE+'/cf/live/recommend-channels'
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSK={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSK.update(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_DefaultParams_Wavve())
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHkSK,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
   if not('celllist' in ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['cell_toplist']):return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSg=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['cell_toplist']['celllist']
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSg:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSw=ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['contentid']
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSE=ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['title_list'][0]['text']
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSw in ITmlcPxRFtBjWzAhfYsuiCOyabHkSv:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSr=ITmlcPxRFtBjWzAhfYsuiCOyabHkSv[ITmlcPxRFtBjWzAhfYsuiCOyabHkSw]
    else:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSr=''
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSM=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_getGenre(ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'wavve')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'channelnm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSE,'channelimg':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.HTTPTAG+ITmlcPxRFtBjWzAhfYsuiCOyabHkSr if ITmlcPxRFtBjWzAhfYsuiCOyabHkSr!='' else '','ott':'wavve','genrenm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSM}
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSM not in exceptGroup:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSG.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[]
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG
 def Get_ChannelList_WavveExcept(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,exceptGroup=[]):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG=[]
  if exceptGroup==[]:return[]
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_WAVVE+'/cf/live/recommend-channels'
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in exceptGroup:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSK={'WeekDay':'all','adult':'n','broadcastid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['broadcastid'],'contenttype':'channel','genre':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['genre'],'isrecommend':'y','limit':ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSK.update(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_DefaultParams_Wavve())
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHkSK,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
    if not('celllist' in ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['cell_toplist']):return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSg=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['cell_toplist']['celllist']
    for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSg:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSG.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['contentid'])
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[]
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG
 def Get_ChannelImg_Wavve(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUQ={}
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUd=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_Now_Datetime()
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUe =ITmlcPxRFtBjWzAhfYsuiCOyabHkUd+datetime.timedelta(hours=3)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_WAVVE+'/live/epgs'
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSK={'limit':ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':ITmlcPxRFtBjWzAhfYsuiCOyabHkUd.strftime('%Y-%m-%d %H:00'),'enddatetime':ITmlcPxRFtBjWzAhfYsuiCOyabHkUe.strftime('%Y-%m-%d %H:00')}
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSK.update(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_DefaultParams_Wavve())
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHkSK,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSg=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['list']
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSg:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUQ[ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channelid']]=ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channelimage']
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkUQ
 def Get_ChanneGenrename_Wavve(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,ITmlcPxRFtBjWzAhfYsuiCOyabHkSw):
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_WAVVE+'/live/channels/'+ITmlcPxRFtBjWzAhfYsuiCOyabHkSw
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSK=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_DefaultParams_Wavve()
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHkSK,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUL=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['genretext']
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return ''
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkUL
 def Get_ChannelList_Spotv(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,payyn=ITmlcPxRFtBjWzAhfYsuiCOyabHkeN):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG=[]
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_SPOTV+'/api/v2/channel'
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHked,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSw=ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['id'])
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'channelnm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['name'],'channelimg':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['logo'],'ott':'spotv','genrenm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_getGenre(ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'spotv'),'free':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['free']}
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSG.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[]
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG
 def Get_ChannelList_Tving(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUo=[]
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_TVING+'/v2/media/lives'
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSK={'pageNo':'1','pageSize':ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSK.update(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_DefaultParams_Tving())
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHkSK,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
   if not('result' in ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['body']):return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSg=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['body']['result']
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSg:
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['live_code']=='C44441':continue 
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUo.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['live_code'])
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSv=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_ChannelImg_Tving(ITmlcPxRFtBjWzAhfYsuiCOyabHkUo)
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSg:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSw=ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['live_code']
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSw=='C44441':continue 
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSE=ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['schedule']['channel']['name']['ko']
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSw in ITmlcPxRFtBjWzAhfYsuiCOyabHkSv:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSr=ITmlcPxRFtBjWzAhfYsuiCOyabHkSv[ITmlcPxRFtBjWzAhfYsuiCOyabHkSw]
    else:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSr=''
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'channelnm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSE,'channelimg':ITmlcPxRFtBjWzAhfYsuiCOyabHkSr,'ott':'tving','genrenm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_getGenre(ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'tving')}
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSG.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[]
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG
 def Get_timestamp(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,timetype=1):
  ts=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,timetype):
  if timetype=='1':
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUp={'transactionId':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUp={'timestamp':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_timestamp(timetype=1),'transactionId':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_timestamp(timetype=1)+'000000000000001',}
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkUp
 def Get_ChannelList_Seezn(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,exceptGroup=[]):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUN =ITmlcPxRFtBjWzAhfYsuiCOyabHkeN if 'won' in exceptGroup else ITmlcPxRFtBjWzAhfYsuiCOyabHkeU
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUK =ITmlcPxRFtBjWzAhfYsuiCOyabHkeN if '홈쇼핑' in exceptGroup else ITmlcPxRFtBjWzAhfYsuiCOyabHkeU
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUX=ITmlcPxRFtBjWzAhfYsuiCOyabHkeN if '라디오/음악' in exceptGroup else ITmlcPxRFtBjWzAhfYsuiCOyabHkeU
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_SEEZN+'/svc/menu/app6/api/epg_chlist' 
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSK={'category_id':'2','istest':'0',}
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUD=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Make_Header_Timestamp(timetype='2')
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUD.update(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.SEEZN_HEADER)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHkSK,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHkUD,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked,redirects=ITmlcPxRFtBjWzAhfYsuiCOyabHkeN)
   if ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.status_code!=200:return[]
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
   if ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ.get('meta').get('code')!='200':return[]
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUG=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ.get('data').get('list')[0].get('list_channel')
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkUG:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUv =ITmlcPxRFtBjWzAhfYsuiCOyabHkSq.get('bit_rate_info').split(",")[0]
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSw =ITmlcPxRFtBjWzAhfYsuiCOyabHkSq.get('ch_no')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSM=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_getGenre(ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'seezn')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUV =ITmlcPxRFtBjWzAhfYsuiCOyabHkSq.get('type')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'channelnm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq.get('service_ch_name').replace(',','.'),'channelimg':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq.get('ch_image_list'),'ott':'seezn','genrenm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSM,}
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSw=='404':continue 
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['adult_yn']=='Y':continue 
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['won_yn'] =='Y' and ITmlcPxRFtBjWzAhfYsuiCOyabHkUN==ITmlcPxRFtBjWzAhfYsuiCOyabHkeN:continue 
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSM in exceptGroup:continue 
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkUV!='EPG':
     if ITmlcPxRFtBjWzAhfYsuiCOyabHkUK and ITmlcPxRFtBjWzAhfYsuiCOyabHkUV=='SHOP' :continue
     if ITmlcPxRFtBjWzAhfYsuiCOyabHkUX and ITmlcPxRFtBjWzAhfYsuiCOyabHkUV=='AUDIO_MUSIC':continue
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSG.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[]
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG
 def Get_EpgInfo_Seezn(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,exceptGroup=[]):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG=[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUn =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_ChannelList_Seezn(exceptGroup)
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_SEEZN+'/svc/menu/app6/api/epg_proglist' 
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkUJ in ITmlcPxRFtBjWzAhfYsuiCOyabHkSG:
    time.sleep(0.3)
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSw =ITmlcPxRFtBjWzAhfYsuiCOyabHkUJ.get('channelid')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSK={'ch_no':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw}
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUD=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Make_Header_Timestamp(timetype='2')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUD.update(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.SEEZN_HEADER)
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHkSK,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHkUD,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked,redirects=ITmlcPxRFtBjWzAhfYsuiCOyabHkeN)
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.status_code!=200:return[],[]
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUg=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkUg.get('meta').get('code')!='200':return[],[]
    for ITmlcPxRFtBjWzAhfYsuiCOyabHkUq in ITmlcPxRFtBjWzAhfYsuiCOyabHkUg.get('data').get('list'):
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUw=ITmlcPxRFtBjWzAhfYsuiCOyabHkUq.get('start_ymd')
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUd=ITmlcPxRFtBjWzAhfYsuiCOyabHkUq.get('start_time').replace(':','')
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUe =ITmlcPxRFtBjWzAhfYsuiCOyabHkUq.get('end_time').replace(':','')
     if ITmlcPxRFtBjWzAhfYsuiCOyabHkeK(ITmlcPxRFtBjWzAhfYsuiCOyabHkUd)>ITmlcPxRFtBjWzAhfYsuiCOyabHkeK(ITmlcPxRFtBjWzAhfYsuiCOyabHkUe):
      ITmlcPxRFtBjWzAhfYsuiCOyabHkUE=datetime.datetime.strptime(ITmlcPxRFtBjWzAhfYsuiCOyabHkUw,'%Y%m%d')+datetime.timedelta(days=ITmlcPxRFtBjWzAhfYsuiCOyabHkeK(1))
      ITmlcPxRFtBjWzAhfYsuiCOyabHkUE=ITmlcPxRFtBjWzAhfYsuiCOyabHkUE.strftime('%Y%m%d')
     else:
      ITmlcPxRFtBjWzAhfYsuiCOyabHkUE=ITmlcPxRFtBjWzAhfYsuiCOyabHkUw
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'title':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.xmlText(urllib.parse.unquote_plus(ITmlcPxRFtBjWzAhfYsuiCOyabHkUq.get('program_name'))),'startTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkUw+ITmlcPxRFtBjWzAhfYsuiCOyabHkUd+'00','endTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkUE+ITmlcPxRFtBjWzAhfYsuiCOyabHkUe+'00','ott':'seezn'}
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUn.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[],[]
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG,ITmlcPxRFtBjWzAhfYsuiCOyabHkUn
 def make_EpgDatetime_Tving(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,days=2):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUr=[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUM=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_DateList(days=2,dateType='2')
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQS=ITmlcPxRFtBjWzAhfYsuiCOyabHkeK(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkUM:
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkQU in ITmlcPxRFtBjWzAhfYsuiCOyabHkeX(8):
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'ndate':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq,'starttm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSQ[ITmlcPxRFtBjWzAhfYsuiCOyabHkQU]['starttm'],'endtm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSQ[ITmlcPxRFtBjWzAhfYsuiCOyabHkQU]['endtm']}
    ITmlcPxRFtBjWzAhfYsuiCOyabHkQd=ITmlcPxRFtBjWzAhfYsuiCOyabHkeK(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq+ITmlcPxRFtBjWzAhfYsuiCOyabHkSQ[ITmlcPxRFtBjWzAhfYsuiCOyabHkQU]['starttm'])
    ITmlcPxRFtBjWzAhfYsuiCOyabHkQe=ITmlcPxRFtBjWzAhfYsuiCOyabHkeK(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq+ITmlcPxRFtBjWzAhfYsuiCOyabHkSQ[ITmlcPxRFtBjWzAhfYsuiCOyabHkQU]['endtm'])
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkQS<=ITmlcPxRFtBjWzAhfYsuiCOyabHkQd or(ITmlcPxRFtBjWzAhfYsuiCOyabHkQd<ITmlcPxRFtBjWzAhfYsuiCOyabHkQS and ITmlcPxRFtBjWzAhfYsuiCOyabHkQS<ITmlcPxRFtBjWzAhfYsuiCOyabHkQe):
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUr.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkUr
 def make_DateList(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,days=2,dateType='1'):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUM=[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQL =ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_Now_Datetime()
  for i in ITmlcPxRFtBjWzAhfYsuiCOyabHkeX(days):
   ITmlcPxRFtBjWzAhfYsuiCOyabHkQo=ITmlcPxRFtBjWzAhfYsuiCOyabHkQL+datetime.timedelta(days=i)
   if dateType=='1':
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUM.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkQo.strftime('%Y-%m-%d'))
   else:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUM.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkQo.strftime('%Y%m%d'))
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkUM
 def make_Tving_ChannleGroup(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,ITmlcPxRFtBjWzAhfYsuiCOyabHkUo):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQp=[]
  i=0
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQN=''
  for ITmlcPxRFtBjWzAhfYsuiCOyabHkQK in ITmlcPxRFtBjWzAhfYsuiCOyabHkUo:
   if i==0:ITmlcPxRFtBjWzAhfYsuiCOyabHkQN=ITmlcPxRFtBjWzAhfYsuiCOyabHkQK
   else:ITmlcPxRFtBjWzAhfYsuiCOyabHkQN+=',%s'%(ITmlcPxRFtBjWzAhfYsuiCOyabHkQK)
   i+=1
   if i>=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.LIMIT_TVINGEPG:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkQp.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkQN)
    i=0
    ITmlcPxRFtBjWzAhfYsuiCOyabHkQN=''
  if ITmlcPxRFtBjWzAhfYsuiCOyabHkQN!='':
   ITmlcPxRFtBjWzAhfYsuiCOyabHkQp.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkQN)
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkQp
 def Get_ChannelImg_Tving(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,chid_list):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUQ={}
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkQX=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_Now_Datetime().strftime('%Y%m%d')
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUd =ITmlcPxRFtBjWzAhfYsuiCOyabHkSQ[6]['starttm'] 
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUe =ITmlcPxRFtBjWzAhfYsuiCOyabHkSQ[6]['endtm']
   ITmlcPxRFtBjWzAhfYsuiCOyabHkQp=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_Tving_ChannleGroup(chid_list)
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkQp:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_TVING+'/v2/media/schedules'
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSK={'pageNo':'1','pageSize':ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':ITmlcPxRFtBjWzAhfYsuiCOyabHkQX,'broadcastDate':ITmlcPxRFtBjWzAhfYsuiCOyabHkQX,'startBroadTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkUd,'endBroadTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkUe,'channelCode':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq}
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSK.update(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_DefaultParams_Tving())
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHkSK,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
    if not('result' in ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['body']):return{}
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSg=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['body']['result']
    for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSg:
     for ITmlcPxRFtBjWzAhfYsuiCOyabHkQD in ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['image']:
      if ITmlcPxRFtBjWzAhfYsuiCOyabHkQD['code']=='CAIC0400':ITmlcPxRFtBjWzAhfYsuiCOyabHkUQ[ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channel_code']]=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_TVINGIMG+ITmlcPxRFtBjWzAhfYsuiCOyabHkQD['url']
      elif ITmlcPxRFtBjWzAhfYsuiCOyabHkQD['code']=='CAIC1400':ITmlcPxRFtBjWzAhfYsuiCOyabHkUQ[ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channel_code']]=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_TVINGIMG+ITmlcPxRFtBjWzAhfYsuiCOyabHkQD['url']
      elif ITmlcPxRFtBjWzAhfYsuiCOyabHkQD['code']=='CAIC1900':ITmlcPxRFtBjWzAhfYsuiCOyabHkUQ[ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channel_code']]=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_TVINGIMG+ITmlcPxRFtBjWzAhfYsuiCOyabHkQD['url']
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return{}
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkUQ
 def Get_EpgInfo_Spotv(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,days=2,payyn=ITmlcPxRFtBjWzAhfYsuiCOyabHkeN):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG=[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUn =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUM=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_DateList(days=days,dateType='1')
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_SPOTV+'/api/v2/channel'
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHked,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSw =ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['id'])
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'channelnm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.xmlText(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['name']),'channelimg':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['logo'],'ott':'spotv'}
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSG.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[],[]
  try:
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkQG in ITmlcPxRFtBjWzAhfYsuiCOyabHkUM:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_SPOTV+'/api/v2/program/'+ITmlcPxRFtBjWzAhfYsuiCOyabHkQG
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHked,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
    for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSw =ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channelId'])
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'title':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.xmlText(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['title']),'startTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUn.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
    time.sleep(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.SLEEP_TIME)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[],[]
  '''
  try:
   for i_channel in channel_list:
    if i_channel['epgtype'] == 'spotvon':
     tmp_list = self.Get_EpgInfo_Spotv_spotvon(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    if i_channel['epgtype'] == 'spotvnet':
     tmp_list = self.Get_EpgInfo_Spotv_spotvnet(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG,ITmlcPxRFtBjWzAhfYsuiCOyabHkUn
 def Get_EpgInfo_Spotv_spotvon(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,epgnm,days):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUn =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUM=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_DateList(days=days,dateType='1')
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQv=''
  try:
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkQG in ITmlcPxRFtBjWzAhfYsuiCOyabHkUM:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSV='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,ITmlcPxRFtBjWzAhfYsuiCOyabHkQG)
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHked,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
    for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'title':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.xmlText(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['title']),'startTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['sch_date'].replace('-','')+ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['sch_hour']).zfill(2)+ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['sch_min']+'00','ott':'spotv'}
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUn.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
    ITmlcPxRFtBjWzAhfYsuiCOyabHkQv=ITmlcPxRFtBjWzAhfYsuiCOyabHkQG
   for i in ITmlcPxRFtBjWzAhfYsuiCOyabHkeX(ITmlcPxRFtBjWzAhfYsuiCOyabHkeD(ITmlcPxRFtBjWzAhfYsuiCOyabHkUn)):
    if i>0:ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i-1]['endTime']=ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i]['startTime']
    if i==ITmlcPxRFtBjWzAhfYsuiCOyabHkeD(ITmlcPxRFtBjWzAhfYsuiCOyabHkUn)-1: ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i]['endTime']=ITmlcPxRFtBjWzAhfYsuiCOyabHkQv+'240000'
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[]
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkUn
 def Get_EpgInfo_Spotv_spotvnet(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,epgnm,days):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUn =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUM=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_DateList(days=days,dateType='1')
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQv=''
  try:
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkQG in ITmlcPxRFtBjWzAhfYsuiCOyabHkUM:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSV='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,ITmlcPxRFtBjWzAhfYsuiCOyabHkQG)
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHked,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
    for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'title':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.xmlText(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['title']),'startTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['sch_date'].replace('-','')+ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['sch_hour']).zfill(2)+ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['sch_min']+'00','ott':'spotv'}
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUn.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
    ITmlcPxRFtBjWzAhfYsuiCOyabHkQv=ITmlcPxRFtBjWzAhfYsuiCOyabHkQG
   for i in ITmlcPxRFtBjWzAhfYsuiCOyabHkeX(ITmlcPxRFtBjWzAhfYsuiCOyabHkeD(ITmlcPxRFtBjWzAhfYsuiCOyabHkUn)):
    if i>0:ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i-1]['endTime']=ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i]['startTime']
    if i==ITmlcPxRFtBjWzAhfYsuiCOyabHkeD(ITmlcPxRFtBjWzAhfYsuiCOyabHkUn)-1: ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i]['endTime']=ITmlcPxRFtBjWzAhfYsuiCOyabHkQv+'240000'
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[]
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkUn
 def Get_EpgInfo_Wavve(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,days=2,exceptGroup=[]):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUn =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQL =ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_Now_Datetime()
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQV =ITmlcPxRFtBjWzAhfYsuiCOyabHkQL+datetime.timedelta(hours=-2)
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQn =ITmlcPxRFtBjWzAhfYsuiCOyabHkQL+datetime.timedelta(days=(days-1))
  if ITmlcPxRFtBjWzAhfYsuiCOyabHkeK(ITmlcPxRFtBjWzAhfYsuiCOyabHkQV.strftime('%H'))<=3:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkQJ=ITmlcPxRFtBjWzAhfYsuiCOyabHkQV.strftime('%Y-%m-%d 00:00')
  else:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkQJ=ITmlcPxRFtBjWzAhfYsuiCOyabHkQV.strftime('%Y-%m-%d %H:00')
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQg =ITmlcPxRFtBjWzAhfYsuiCOyabHkQn.strftime('%Y-%m-%d 24:00')
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_WAVVE+'/live/epgs'
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSK={'limit':ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':ITmlcPxRFtBjWzAhfYsuiCOyabHkQJ,'enddatetime':ITmlcPxRFtBjWzAhfYsuiCOyabHkQg}
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSK.update(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_DefaultParams_Wavve())
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHkSK,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUg=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['list']
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkUg:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSw =ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channelid']
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSM=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_getGenre(ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'wavve')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'channelnm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.xmlText(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channelname']),'channelimg':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.HTTPTAG+ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channelimage'],'ott':'wavve'}
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSM not in exceptGroup:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSG.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
    for ITmlcPxRFtBjWzAhfYsuiCOyabHkUq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['list']:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channelid'],'title':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.xmlText(ITmlcPxRFtBjWzAhfYsuiCOyabHkUq['title']),'startTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkUq['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkUq['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if ITmlcPxRFtBjWzAhfYsuiCOyabHkSM not in exceptGroup and ITmlcPxRFtBjWzAhfYsuiCOyabHkUq['starttime']!=ITmlcPxRFtBjWzAhfYsuiCOyabHkUq['endtime']:
      ITmlcPxRFtBjWzAhfYsuiCOyabHkUn.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[],[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQq=ITmlcPxRFtBjWzAhfYsuiCOyabHkeD(ITmlcPxRFtBjWzAhfYsuiCOyabHkUn)
  for i in(ITmlcPxRFtBjWzAhfYsuiCOyabHkeX(1,ITmlcPxRFtBjWzAhfYsuiCOyabHkQq)):
   if ITmlcPxRFtBjWzAhfYsuiCOyabHkeK(ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i-1]['endTime'])+1==ITmlcPxRFtBjWzAhfYsuiCOyabHkeK(ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i]['startTime'])and ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i-1]['channelid']==ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i]['channelid']:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i-1]['endTime']=ITmlcPxRFtBjWzAhfYsuiCOyabHkUn[i]['startTime']
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG,ITmlcPxRFtBjWzAhfYsuiCOyabHkUn
 def Get_EpgInfo_Tving(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,days=2):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG=[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUn =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQw =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQE =ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_EpgDatetime_Tving(days=days)
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG =ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_ChannelList_Tving()
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQr=[]
  for i in ITmlcPxRFtBjWzAhfYsuiCOyabHkeX(ITmlcPxRFtBjWzAhfYsuiCOyabHkeD(ITmlcPxRFtBjWzAhfYsuiCOyabHkSG)):
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSG[i]['channelnm']=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.xmlText(ITmlcPxRFtBjWzAhfYsuiCOyabHkSG[i]['channelnm'])
   ITmlcPxRFtBjWzAhfYsuiCOyabHkQr.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkSG[i]['channelid'])
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQM=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_Tving_ChannleGroup(ITmlcPxRFtBjWzAhfYsuiCOyabHkQr)
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_TVING+'/v2/media/schedules'
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkdS in ITmlcPxRFtBjWzAhfYsuiCOyabHkQE:
    for ITmlcPxRFtBjWzAhfYsuiCOyabHkUJ in ITmlcPxRFtBjWzAhfYsuiCOyabHkQM:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSK={'pageNo':'1','pageSize':ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':ITmlcPxRFtBjWzAhfYsuiCOyabHkdS['ndate'],'broadcastDate':ITmlcPxRFtBjWzAhfYsuiCOyabHkdS['ndate'],'startBroadTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkdS['starttm'],'endBroadTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkdS['endtm'],'channelCode':ITmlcPxRFtBjWzAhfYsuiCOyabHkUJ}
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSK.update(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_DefaultParams_Tving())
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHkSK,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSg=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['body']['result']
     for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSg:
      if 'schedules' not in ITmlcPxRFtBjWzAhfYsuiCOyabHkSq:continue
      if ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['schedules']==ITmlcPxRFtBjWzAhfYsuiCOyabHked:continue
      for ITmlcPxRFtBjWzAhfYsuiCOyabHkdU in ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['schedules']:
       ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkdU['schedule_code'],'title':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.xmlText(ITmlcPxRFtBjWzAhfYsuiCOyabHkdU['program']['name']['ko']),'startTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkdU['broadcast_start_time']),'endTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkdU['broadcast_end_time']),'ott':'tving'}
       ITmlcPxRFtBjWzAhfYsuiCOyabHkdQ=ITmlcPxRFtBjWzAhfYsuiCOyabHkdU['schedule_code']+ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkdU['broadcast_start_time'])
       if ITmlcPxRFtBjWzAhfYsuiCOyabHkdQ in ITmlcPxRFtBjWzAhfYsuiCOyabHkQw:continue
       ITmlcPxRFtBjWzAhfYsuiCOyabHkQw.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkdQ)
       ITmlcPxRFtBjWzAhfYsuiCOyabHkUn.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
     time.sleep(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.SLEEP_TIME)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[],[]
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG,ITmlcPxRFtBjWzAhfYsuiCOyabHkUn
 def Get_BaseInfo_Samsungtv(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkde={}
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_SAMSUNGTV
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHked,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHked)
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkdL in ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.cookies:
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkdL.name=='session':
     ITmlcPxRFtBjWzAhfYsuiCOyabHkde['session']=ITmlcPxRFtBjWzAhfYsuiCOyabHkdL.value
    elif ITmlcPxRFtBjWzAhfYsuiCOyabHkdL.name=='session.sig':
     ITmlcPxRFtBjWzAhfYsuiCOyabHkde['session.sig']=ITmlcPxRFtBjWzAhfYsuiCOyabHkdL.value
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return{}
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_SAMSUNGTV+'/user'
   ITmlcPxRFtBjWzAhfYsuiCOyabHkdo={'session':ITmlcPxRFtBjWzAhfYsuiCOyabHkde['session'],'session.sig':ITmlcPxRFtBjWzAhfYsuiCOyabHkde['session.sig'],}
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHked,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHked,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHkdo)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkde['countryCode']=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ.get('countryCode')
   ITmlcPxRFtBjWzAhfYsuiCOyabHkde['uuid'] =ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ.get('uuid')
   ITmlcPxRFtBjWzAhfYsuiCOyabHkde['ip'] =ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ.get('ip')
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return{}
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkde
 def t_Cache(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkQS =ITmlcPxRFtBjWzAhfYsuiCOyabHkeK(time.time())
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdp=ITmlcPxRFtBjWzAhfYsuiCOyabHkeK(ITmlcPxRFtBjWzAhfYsuiCOyabHkQS-ITmlcPxRFtBjWzAhfYsuiCOyabHkQS%3600)
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkdp,ITmlcPxRFtBjWzAhfYsuiCOyabHkQS
 def zlib_compress(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,plaintext):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdN=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(ITmlcPxRFtBjWzAhfYsuiCOyabHkdN).decode('utf-8')
 def Get_BaseRequest_Samsungtv(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,ITmlcPxRFtBjWzAhfYsuiCOyabHkde):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ={}
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSV=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.API_SAMSUNGTV+'/api/lives'
   ITmlcPxRFtBjWzAhfYsuiCOyabHkdp,ITmlcPxRFtBjWzAhfYsuiCOyabHkQS=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.t_Cache()
   ITmlcPxRFtBjWzAhfYsuiCOyabHkdK=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.zlib_compress(ITmlcPxRFtBjWzAhfYsuiCOyabHkde['uuid']+':'+ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkQS))
   ITmlcPxRFtBjWzAhfYsuiCOyabHkdo={'session':ITmlcPxRFtBjWzAhfYsuiCOyabHkde['session'],'session.sig':ITmlcPxRFtBjWzAhfYsuiCOyabHkde['session.sig'],}
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSK ={'t':ITmlcPxRFtBjWzAhfYsuiCOyabHkeL(ITmlcPxRFtBjWzAhfYsuiCOyabHkdp)}
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUD ={'x-cred-payload':ITmlcPxRFtBjWzAhfYsuiCOyabHkdK}
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSn=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.callRequestCookies('Get',ITmlcPxRFtBjWzAhfYsuiCOyabHkSV,payload=ITmlcPxRFtBjWzAhfYsuiCOyabHked,params=ITmlcPxRFtBjWzAhfYsuiCOyabHkSK,headers=ITmlcPxRFtBjWzAhfYsuiCOyabHkUD,cookies=ITmlcPxRFtBjWzAhfYsuiCOyabHkdo)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=json.loads(ITmlcPxRFtBjWzAhfYsuiCOyabHkSn.text)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ
 def Make_Samsungtv_logoUrl(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,fullUrl):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdX=urllib.parse.urlparse(fullUrl) 
  if ITmlcPxRFtBjWzAhfYsuiCOyabHkdX.netloc=='us-image.samsungtvplus.com':
   ITmlcPxRFtBjWzAhfYsuiCOyabHkdD=ITmlcPxRFtBjWzAhfYsuiCOyabHkeG(urllib.parse.parse_qsl(ITmlcPxRFtBjWzAhfYsuiCOyabHkdX.query))
   if 'url' in ITmlcPxRFtBjWzAhfYsuiCOyabHkdD:
    return ITmlcPxRFtBjWzAhfYsuiCOyabHkdD.get('url')
  return fullUrl
 def Get_ChannelList_Samsungtv(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,ITmlcPxRFtBjWzAhfYsuiCOyabHkde,exceptGroup=[]):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG =[]
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_BaseRequest_Samsungtv(ITmlcPxRFtBjWzAhfYsuiCOyabHkde)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSg=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['live']['channel']
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkSg:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSw =ITmlcPxRFtBjWzAhfYsuiCOyabHkSq.get('id')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSE =ITmlcPxRFtBjWzAhfYsuiCOyabHkSq.get('name')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSr=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Make_Samsungtv_logoUrl(ITmlcPxRFtBjWzAhfYsuiCOyabHkSq.get('logo'))
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSM=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_getGenre(ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'samsung')
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSM in['-','']:ITmlcPxRFtBjWzAhfYsuiCOyabHkSM='정주행 채널'
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'channelnm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSE,'channelimg':ITmlcPxRFtBjWzAhfYsuiCOyabHkSr,'ott':'samsung','genrenm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSM}
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSM not in exceptGroup:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkSG.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[]
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG
 def Get_EpgInfo_Samsungtv(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,ITmlcPxRFtBjWzAhfYsuiCOyabHkde,exceptGroup=[]):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkSG=[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUn =[]
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ =ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_BaseRequest_Samsungtv(ITmlcPxRFtBjWzAhfYsuiCOyabHkde)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSq=ITmlcPxRFtBjWzAhfYsuiCOyabHkSJ['live']['channel']
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkUJ in ITmlcPxRFtBjWzAhfYsuiCOyabHkSq:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSw =ITmlcPxRFtBjWzAhfYsuiCOyabHkUJ.get('id')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSE =ITmlcPxRFtBjWzAhfYsuiCOyabHkUJ.get('name')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSr=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Make_Samsungtv_logoUrl(ITmlcPxRFtBjWzAhfYsuiCOyabHkUJ.get('logo'))
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUg =ITmlcPxRFtBjWzAhfYsuiCOyabHkUJ.get('program')
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSM=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.make_getGenre(ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'samsung')
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkSM in exceptGroup:
     continue
    ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'channelnm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSE,'channelimg':ITmlcPxRFtBjWzAhfYsuiCOyabHkSr,'ott':'samsung','genrenm':ITmlcPxRFtBjWzAhfYsuiCOyabHkSM}
    ITmlcPxRFtBjWzAhfYsuiCOyabHkSG.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
    for ITmlcPxRFtBjWzAhfYsuiCOyabHkUq in ITmlcPxRFtBjWzAhfYsuiCOyabHkUg:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkdG=ITmlcPxRFtBjWzAhfYsuiCOyabHkUq.get('start_time')
     ITmlcPxRFtBjWzAhfYsuiCOyabHkdv =ITmlcPxRFtBjWzAhfYsuiCOyabHkUq.get('duration') 
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUd=datetime.datetime.strptime(ITmlcPxRFtBjWzAhfYsuiCOyabHkdG,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUe =ITmlcPxRFtBjWzAhfYsuiCOyabHkUd+datetime.timedelta(seconds=ITmlcPxRFtBjWzAhfYsuiCOyabHkdv)
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUS={'channelid':ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,'title':ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.xmlText(urllib.parse.unquote_plus(ITmlcPxRFtBjWzAhfYsuiCOyabHkUq.get('title'))),'startTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkUd.strftime('%Y%m%d%H%M00'),'endTime':ITmlcPxRFtBjWzAhfYsuiCOyabHkUe.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUn.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  except ITmlcPxRFtBjWzAhfYsuiCOyabHkeo as exception:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkep(exception)
   return[],[]
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkSG,ITmlcPxRFtBjWzAhfYsuiCOyabHkUn
 def make_getGenre(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,ITmlcPxRFtBjWzAhfYsuiCOyabHkdr):
  try:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUL=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.INIT_CHANNEL.get(ITmlcPxRFtBjWzAhfYsuiCOyabHkSw+'.'+ITmlcPxRFtBjWzAhfYsuiCOyabHkdr).get('genre')
  except:
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUL=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.INIT_CHANNEL.get('-').get('genre')
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkUL
 def make_base_allchannel_py(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe,ITmlcPxRFtBjWzAhfYsuiCOyabHkde):
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdV =[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdn=[]
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdJ=ITmlcPxRFtBjWzAhfYsuiCOyabHkev()
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUS=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_ChannelList_Wavve()
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdV.extend(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUS=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_ChannelList_Tving()
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdV.extend(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUS=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_ChannelList_Spotv()
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdV.extend(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUS=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_ChannelList_Seezn()
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdV.extend(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  ITmlcPxRFtBjWzAhfYsuiCOyabHkUS=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_ChannelList_Samsungtv(ITmlcPxRFtBjWzAhfYsuiCOyabHkde)
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdV.extend(ITmlcPxRFtBjWzAhfYsuiCOyabHkUS)
  ITmlcPxRFtBjWzAhfYsuiCOyabHkep('1')
  for i in ITmlcPxRFtBjWzAhfYsuiCOyabHkeX(ITmlcPxRFtBjWzAhfYsuiCOyabHkeD(ITmlcPxRFtBjWzAhfYsuiCOyabHkdV)):
   if ITmlcPxRFtBjWzAhfYsuiCOyabHkdV[i]['genrenm']=='-':
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkdV[i]['ott']=='wavve':
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUL=ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.Get_ChanneGenrename_Wavve(ITmlcPxRFtBjWzAhfYsuiCOyabHkdV[i]['channelid'])
     if ITmlcPxRFtBjWzAhfYsuiCOyabHkUL not in ITmlcPxRFtBjWzAhfYsuiCOyabHkdJ:ITmlcPxRFtBjWzAhfYsuiCOyabHkdJ.add(ITmlcPxRFtBjWzAhfYsuiCOyabHkUL)
     time.sleep(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.SLEEP_TIME)
    elif ITmlcPxRFtBjWzAhfYsuiCOyabHkdV[i]['ott']=='spotv':
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUL='스포츠'
    else:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkUL='-'
    ITmlcPxRFtBjWzAhfYsuiCOyabHkdV[i]['genrenm']=ITmlcPxRFtBjWzAhfYsuiCOyabHkUL
   else:
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkdV[i]['genrenm']not in ITmlcPxRFtBjWzAhfYsuiCOyabHkdJ:ITmlcPxRFtBjWzAhfYsuiCOyabHkdJ.add(ITmlcPxRFtBjWzAhfYsuiCOyabHkdV[i]['genrenm'])
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdJ.add(ITmlcPxRFtBjWzAhfYsuiCOyabHkSe.INIT_CHANNEL.get('-').get('genre'))
  ITmlcPxRFtBjWzAhfYsuiCOyabHkep('2')
  for ITmlcPxRFtBjWzAhfYsuiCOyabHkdg in ITmlcPxRFtBjWzAhfYsuiCOyabHkdJ:
   for ITmlcPxRFtBjWzAhfYsuiCOyabHkdq in ITmlcPxRFtBjWzAhfYsuiCOyabHkdV:
    if ITmlcPxRFtBjWzAhfYsuiCOyabHkdq['genrenm']==ITmlcPxRFtBjWzAhfYsuiCOyabHkdg:
     ITmlcPxRFtBjWzAhfYsuiCOyabHkdn.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkdq)
  for ITmlcPxRFtBjWzAhfYsuiCOyabHkdq in ITmlcPxRFtBjWzAhfYsuiCOyabHkdV:
   if ITmlcPxRFtBjWzAhfYsuiCOyabHkdq['genrenm']not in ITmlcPxRFtBjWzAhfYsuiCOyabHkdJ:
    ITmlcPxRFtBjWzAhfYsuiCOyabHkdn.append(ITmlcPxRFtBjWzAhfYsuiCOyabHkdq)
  ITmlcPxRFtBjWzAhfYsuiCOyabHkep('3')
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdw='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(ITmlcPxRFtBjWzAhfYsuiCOyabHkdw):os.remove(ITmlcPxRFtBjWzAhfYsuiCOyabHkdw)
  fp=ITmlcPxRFtBjWzAhfYsuiCOyabHkeV(ITmlcPxRFtBjWzAhfYsuiCOyabHkdw,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  ITmlcPxRFtBjWzAhfYsuiCOyabHkdE=ITmlcPxRFtBjWzAhfYsuiCOyabHkeD(ITmlcPxRFtBjWzAhfYsuiCOyabHkdn)
  i=0
  for ITmlcPxRFtBjWzAhfYsuiCOyabHkSq in ITmlcPxRFtBjWzAhfYsuiCOyabHkdn:
   i+=1
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSw =ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channelid']
   ITmlcPxRFtBjWzAhfYsuiCOyabHkSE =ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['channelnm']
   ITmlcPxRFtBjWzAhfYsuiCOyabHkdr =ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['ott']
   ITmlcPxRFtBjWzAhfYsuiCOyabHkdM ='%s.%s'%(ITmlcPxRFtBjWzAhfYsuiCOyabHkSw,ITmlcPxRFtBjWzAhfYsuiCOyabHkdr)
   ITmlcPxRFtBjWzAhfYsuiCOyabHkUL =ITmlcPxRFtBjWzAhfYsuiCOyabHkSq['genrenm']
   ITmlcPxRFtBjWzAhfYsuiCOyabHkeS='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(ITmlcPxRFtBjWzAhfYsuiCOyabHkdM,ITmlcPxRFtBjWzAhfYsuiCOyabHkSE,ITmlcPxRFtBjWzAhfYsuiCOyabHkUL)
   if i<ITmlcPxRFtBjWzAhfYsuiCOyabHkdE:
    fp.write(ITmlcPxRFtBjWzAhfYsuiCOyabHkeS+',\n')
   else:
    fp.write(ITmlcPxRFtBjWzAhfYsuiCOyabHkeS+'\n')
  fp.write('}\n')
  fp.close()
  return ITmlcPxRFtBjWzAhfYsuiCOyabHkdJ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
