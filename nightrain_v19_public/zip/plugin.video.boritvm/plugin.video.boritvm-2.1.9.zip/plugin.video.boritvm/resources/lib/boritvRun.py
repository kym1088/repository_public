__author__="NightRain"
vgRkjLcGtYwsoxBIKJVfmpnPbUCArq=object
vgRkjLcGtYwsoxBIKJVfmpnPbUCArH=False
vgRkjLcGtYwsoxBIKJVfmpnPbUCArh=None
vgRkjLcGtYwsoxBIKJVfmpnPbUCAri=True
vgRkjLcGtYwsoxBIKJVfmpnPbUCArF=len
vgRkjLcGtYwsoxBIKJVfmpnPbUCArd=str
vgRkjLcGtYwsoxBIKJVfmpnPbUCArz=open
vgRkjLcGtYwsoxBIKJVfmpnPbUCArl=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
vgRkjLcGtYwsoxBIKJVfmpnPbUCANe=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'     - M3U 추가 (시즌)','mode':'ADD_M3U','sType':'seezn','sName':'시즌'},{'title':'     - M3U 추가 (삼성tv 플러스)','mode':'ADD_M3U','sType':'samsung','sName':'삼성TV 플러스'},{'title':'     - M3U 추가 (사용자 m3u)','mode':'ADD_M3U','sType':'custom','sName':'사용자 m3u 파일'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
vgRkjLcGtYwsoxBIKJVfmpnPbUCANr=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class vgRkjLcGtYwsoxBIKJVfmpnPbUCANu(vgRkjLcGtYwsoxBIKJVfmpnPbUCArq):
 def __init__(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM,vgRkjLcGtYwsoxBIKJVfmpnPbUCANq,vgRkjLcGtYwsoxBIKJVfmpnPbUCANH,vgRkjLcGtYwsoxBIKJVfmpnPbUCANh):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM._addon_url =vgRkjLcGtYwsoxBIKJVfmpnPbUCANq
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM._addon_handle =vgRkjLcGtYwsoxBIKJVfmpnPbUCANH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.main_params =vgRkjLcGtYwsoxBIKJVfmpnPbUCANh
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_FILE_PATH ='' 
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_FILE_NAME ='' 
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVE =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONTVING =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSPOTV =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZN =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSAMSUNG =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVERADIO =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVEHOME =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONRELIGION =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSPOTVPAY =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZNPAY =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZNHOME =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZNRADIO =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSAMSUNGHOME=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_DISPLAYNM =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_AUTORESTART =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_CUSTOM_LIST =[]
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj =ITmlcPxRFtBjWzAhfYsuiCOyabHkSU() 
 def addon_noti(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM,sting):
  try:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANF=xbmcgui.Dialog()
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANF.notification(__addonname__,sting)
  except:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCArh
 def addon_log(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM,string):
  try:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANd=string.encode('utf-8','ignore')
  except:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANd='addonException: addon_log'
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANz=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,vgRkjLcGtYwsoxBIKJVfmpnPbUCANd),level=vgRkjLcGtYwsoxBIKJVfmpnPbUCANz)
 def get_keyboard_input(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM,vgRkjLcGtYwsoxBIKJVfmpnPbUCANQ):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANl=vgRkjLcGtYwsoxBIKJVfmpnPbUCArh
  kb=xbmc.Keyboard()
  kb.setHeading(vgRkjLcGtYwsoxBIKJVfmpnPbUCANQ)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANl=kb.getText()
  return vgRkjLcGtYwsoxBIKJVfmpnPbUCANl
 def add_dir(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM,label,sublabel='',img='',infoLabels=vgRkjLcGtYwsoxBIKJVfmpnPbUCArh,isFolder=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri,params='',isLink=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH,ContextMenu=vgRkjLcGtYwsoxBIKJVfmpnPbUCArh):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANX='%s?%s'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM._addon_url,urllib.parse.urlencode(params))
  if sublabel:vgRkjLcGtYwsoxBIKJVfmpnPbUCANQ='%s < %s >'%(label,sublabel)
  else: vgRkjLcGtYwsoxBIKJVfmpnPbUCANQ=label
  if not img:img='DefaultFolder.png'
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANT=xbmcgui.ListItem(vgRkjLcGtYwsoxBIKJVfmpnPbUCANQ)
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANT.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:vgRkjLcGtYwsoxBIKJVfmpnPbUCANT.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANT.setProperty('IsPlayable','true')
  if ContextMenu:vgRkjLcGtYwsoxBIKJVfmpnPbUCANT.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM._addon_handle,vgRkjLcGtYwsoxBIKJVfmpnPbUCANX,vgRkjLcGtYwsoxBIKJVfmpnPbUCANT,isFolder)
 def make_M3u_Filename(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM,tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_FILE_PATH+vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM,tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_FILE_PATH+vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_FILE_NAME+'.xml'
 def dp_Main_List(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM):
  for vgRkjLcGtYwsoxBIKJVfmpnPbUCAND in vgRkjLcGtYwsoxBIKJVfmpnPbUCANe:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANQ=vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('title')
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANW=''
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANS={'mode':vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('mode'),'sType':vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('sType'),'sName':vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('sName')}
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('mode')=='XXX':
    vgRkjLcGtYwsoxBIKJVfmpnPbUCANa=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
    vgRkjLcGtYwsoxBIKJVfmpnPbUCANO =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri
   else:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCANa=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri
    vgRkjLcGtYwsoxBIKJVfmpnPbUCANO =vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANE=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('mode')=='ADD_M3U':
    if vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('sType')=='wavve' and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVE ==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:vgRkjLcGtYwsoxBIKJVfmpnPbUCANE=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
    if vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('sType')=='tving' and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONTVING ==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:vgRkjLcGtYwsoxBIKJVfmpnPbUCANE=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
    if vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('sType')=='spotv' and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSPOTV ==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:vgRkjLcGtYwsoxBIKJVfmpnPbUCANE=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
    if vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('sType')=='seezn' and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZN ==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:vgRkjLcGtYwsoxBIKJVfmpnPbUCANE=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
    if vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('sType')=='samsung' and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSAMSUNG==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:vgRkjLcGtYwsoxBIKJVfmpnPbUCANE=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
    if vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('sType')=='custom' and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_CUSTOM_LIST==[]:vgRkjLcGtYwsoxBIKJVfmpnPbUCANE=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCANE==vgRkjLcGtYwsoxBIKJVfmpnPbUCAri:
    if 'icon' in vgRkjLcGtYwsoxBIKJVfmpnPbUCAND:vgRkjLcGtYwsoxBIKJVfmpnPbUCANW=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',vgRkjLcGtYwsoxBIKJVfmpnPbUCAND.get('icon')) 
    vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.add_dir(vgRkjLcGtYwsoxBIKJVfmpnPbUCANQ,sublabel='',img=vgRkjLcGtYwsoxBIKJVfmpnPbUCANW,infoLabels=vgRkjLcGtYwsoxBIKJVfmpnPbUCArh,isFolder=vgRkjLcGtYwsoxBIKJVfmpnPbUCANa,params=vgRkjLcGtYwsoxBIKJVfmpnPbUCANS,isLink=vgRkjLcGtYwsoxBIKJVfmpnPbUCANO)
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCANe)>0:xbmcplugin.endOfDirectory(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM._addon_handle,cacheToDisc=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri)
 def dp_Delete_M3u(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM,args):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANF=xbmcgui.Dialog()
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAuN=vgRkjLcGtYwsoxBIKJVfmpnPbUCANF.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCAuN==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:sys.exit()
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAue=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_M3u_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH)
  if xbmcvfs.exists(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue):
   if xbmcvfs.delete(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue)==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti(__language__(30910).encode('utf-8'))
    return
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM,args):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=args.get('sType')
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAuM=args.get('sName')
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANF=xbmcgui.Dialog()
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAuN=vgRkjLcGtYwsoxBIKJVfmpnPbUCANF.yesno((vgRkjLcGtYwsoxBIKJVfmpnPbUCAuM+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCAuN==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:sys.exit()
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAuq =[]
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAuH =[]
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAue=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_M3u_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri)
  if os.path.isfile(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue):os.remove(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue)
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all':
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAue=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_M3u_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH)
   if xbmcvfs.exists(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue):
    if xbmcvfs.delete(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue)==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:
     vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAuh=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_M3u_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH)
   if xbmcvfs.exists(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuh):
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAui=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_M3u_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri)
    xbmcvfs.copy(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuh,vgRkjLcGtYwsoxBIKJVfmpnPbUCAui)
  if(vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='wavve' or vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all')and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVE:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_ChannelList_Wavve(exceptGroup=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_EexceptGroup_Wavve())
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)!=0:vgRkjLcGtYwsoxBIKJVfmpnPbUCAuq.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_log('wavve cnt ----> '+vgRkjLcGtYwsoxBIKJVfmpnPbUCArd(vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)))
  if(vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='tving' or vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all')and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONTVING:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_ChannelList_Tving()
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)!=0:vgRkjLcGtYwsoxBIKJVfmpnPbUCAuq.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_log('tving cnt ----> '+vgRkjLcGtYwsoxBIKJVfmpnPbUCArd(vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)))
  if(vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='spotv' or vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all')and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSPOTV:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_ChannelList_Spotv(payyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSPOTVPAY)
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)!=0:vgRkjLcGtYwsoxBIKJVfmpnPbUCAuq.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_log('spotv cnt ----> '+vgRkjLcGtYwsoxBIKJVfmpnPbUCArd(vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)))
  if(vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='seezn' or vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all')and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZN:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_ChannelList_Seezn(exceptGroup=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_EexceptGroup_Seezn())
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)!=0:vgRkjLcGtYwsoxBIKJVfmpnPbUCAuq.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_log('seezn cnt ----> '+vgRkjLcGtYwsoxBIKJVfmpnPbUCArd(vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)))
  if(vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='samsung' or vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all')and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSAMSUNG:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAud=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_BaseInfo_Samsungtv()
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_ChannelList_Samsungtv(vgRkjLcGtYwsoxBIKJVfmpnPbUCAud,exceptGroup=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_EexceptGroup_Samsungtv())
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)!=0:vgRkjLcGtYwsoxBIKJVfmpnPbUCAuq.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_log('samsungtv cnt ----> '+vgRkjLcGtYwsoxBIKJVfmpnPbUCArd(vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuF)))
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuq)==0 and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_CUSTOM_LIST==[]:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti(__language__(30909).encode('utf8'))
   return
  for vgRkjLcGtYwsoxBIKJVfmpnPbUCAuz in vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.INIT_GENRESORT:
   for vgRkjLcGtYwsoxBIKJVfmpnPbUCAul in vgRkjLcGtYwsoxBIKJVfmpnPbUCAuq:
    if vgRkjLcGtYwsoxBIKJVfmpnPbUCAul['genrenm']==vgRkjLcGtYwsoxBIKJVfmpnPbUCAuz:
     vgRkjLcGtYwsoxBIKJVfmpnPbUCAuH.append(vgRkjLcGtYwsoxBIKJVfmpnPbUCAul)
  for vgRkjLcGtYwsoxBIKJVfmpnPbUCAul in vgRkjLcGtYwsoxBIKJVfmpnPbUCAuq:
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCAul['genrenm']not in vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.INIT_GENRESORT:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAuH.append(vgRkjLcGtYwsoxBIKJVfmpnPbUCAul)
  try:
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuq)>0:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAue=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_M3u_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri)
    if os.path.isfile(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue):
     fp=vgRkjLcGtYwsoxBIKJVfmpnPbUCArz(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue,'a',-1,'utf-8')
    else:
     fp=vgRkjLcGtYwsoxBIKJVfmpnPbUCArz(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for vgRkjLcGtYwsoxBIKJVfmpnPbUCAuX in vgRkjLcGtYwsoxBIKJVfmpnPbUCAuH:
     vgRkjLcGtYwsoxBIKJVfmpnPbUCAuQ =vgRkjLcGtYwsoxBIKJVfmpnPbUCAuX['channelid']
     vgRkjLcGtYwsoxBIKJVfmpnPbUCAuT =vgRkjLcGtYwsoxBIKJVfmpnPbUCAuX['channelnm']
     vgRkjLcGtYwsoxBIKJVfmpnPbUCAuD=vgRkjLcGtYwsoxBIKJVfmpnPbUCAuX['channelimg']
     vgRkjLcGtYwsoxBIKJVfmpnPbUCAuW =vgRkjLcGtYwsoxBIKJVfmpnPbUCAuX['ott']
     vgRkjLcGtYwsoxBIKJVfmpnPbUCAuS ='%s.%s'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuQ,vgRkjLcGtYwsoxBIKJVfmpnPbUCAuW)
     vgRkjLcGtYwsoxBIKJVfmpnPbUCAua=vgRkjLcGtYwsoxBIKJVfmpnPbUCAuX['genrenm']
     if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_DISPLAYNM:
      vgRkjLcGtYwsoxBIKJVfmpnPbUCAuT='%s (%s)'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuT,vgRkjLcGtYwsoxBIKJVfmpnPbUCAuW)
     if vgRkjLcGtYwsoxBIKJVfmpnPbUCAua=='라디오/음악':
      vgRkjLcGtYwsoxBIKJVfmpnPbUCAuO='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuS,vgRkjLcGtYwsoxBIKJVfmpnPbUCAuT,vgRkjLcGtYwsoxBIKJVfmpnPbUCAua,vgRkjLcGtYwsoxBIKJVfmpnPbUCAuD,vgRkjLcGtYwsoxBIKJVfmpnPbUCAuT)
     else:
      vgRkjLcGtYwsoxBIKJVfmpnPbUCAuO='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuS,vgRkjLcGtYwsoxBIKJVfmpnPbUCAuT,vgRkjLcGtYwsoxBIKJVfmpnPbUCAua,vgRkjLcGtYwsoxBIKJVfmpnPbUCAuD,vgRkjLcGtYwsoxBIKJVfmpnPbUCAuT)
     if vgRkjLcGtYwsoxBIKJVfmpnPbUCAuW=='wavve':
      vgRkjLcGtYwsoxBIKJVfmpnPbUCAuE ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuQ)
     elif vgRkjLcGtYwsoxBIKJVfmpnPbUCAuW=='tving':
      vgRkjLcGtYwsoxBIKJVfmpnPbUCAuE ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuQ)
     elif vgRkjLcGtYwsoxBIKJVfmpnPbUCAuW=='spotv':
      vgRkjLcGtYwsoxBIKJVfmpnPbUCAuE ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuQ)
     elif vgRkjLcGtYwsoxBIKJVfmpnPbUCAuW=='seezn':
      vgRkjLcGtYwsoxBIKJVfmpnPbUCAuy='128' if vgRkjLcGtYwsoxBIKJVfmpnPbUCAua=='라디오/음악' else '4000'
      vgRkjLcGtYwsoxBIKJVfmpnPbUCAuE ='plugin://plugin.video.seeznm/?mode=LIVE&mediacode=%s&bitrate=%s\n'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuQ,vgRkjLcGtYwsoxBIKJVfmpnPbUCAuy)
     if vgRkjLcGtYwsoxBIKJVfmpnPbUCAuW=='samsung':
      vgRkjLcGtYwsoxBIKJVfmpnPbUCAuE ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuQ)
     fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuO)
     fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuE)
    fp.close()
  except:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti(__language__(30910).encode('utf8'))
   return
  try:
   if(vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='custom' or vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all')and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_CUSTOM_LIST!=[]:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAue=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_M3u_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri)
    if os.path.isfile(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue):
     fp=vgRkjLcGtYwsoxBIKJVfmpnPbUCArz(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue,'a',-1,'utf-8')
    else:
     fp=vgRkjLcGtYwsoxBIKJVfmpnPbUCArz(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for vgRkjLcGtYwsoxBIKJVfmpnPbUCAeN in vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_CUSTOM_LIST:
     vgRkjLcGtYwsoxBIKJVfmpnPbUCAeu=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.customEpg_FileRead(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeN)
     for vgRkjLcGtYwsoxBIKJVfmpnPbUCAer in vgRkjLcGtYwsoxBIKJVfmpnPbUCAeu:
      vgRkjLcGtYwsoxBIKJVfmpnPbUCAer=vgRkjLcGtYwsoxBIKJVfmpnPbUCAer.strip()
      if vgRkjLcGtYwsoxBIKJVfmpnPbUCAer not in['','#EXTM3U']:
       fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAer+'\n')
   fp.close()
  except:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti(__language__(30910).encode('utf8'))
   return
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAuh=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_M3u_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri)
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAui=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_M3u_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH)
  if xbmcvfs.copy(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuh,vgRkjLcGtYwsoxBIKJVfmpnPbUCAui):
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti((vgRkjLcGtYwsoxBIKJVfmpnPbUCAuM+' '+__language__(30908)).encode('utf8'))
  else:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti(__language__(30910).encode('utf-8'))
 def customEpg_FileList(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAeM=[]
  if __addon__.getSetting('custom01on')=='true':vgRkjLcGtYwsoxBIKJVfmpnPbUCAeM.append(__addon__.getSetting('custom01nm'))
  if __addon__.getSetting('custom02on')=='true':vgRkjLcGtYwsoxBIKJVfmpnPbUCAeM.append(__addon__.getSetting('custom02nm'))
  if __addon__.getSetting('custom03on')=='true':vgRkjLcGtYwsoxBIKJVfmpnPbUCAeM.append(__addon__.getSetting('custom03nm'))
  if __addon__.getSetting('custom04on')=='true':vgRkjLcGtYwsoxBIKJVfmpnPbUCAeM.append(__addon__.getSetting('custom04nm'))
  if __addon__.getSetting('custom05on')=='true':vgRkjLcGtYwsoxBIKJVfmpnPbUCAeM.append(__addon__.getSetting('custom05nm'))
  return vgRkjLcGtYwsoxBIKJVfmpnPbUCAeM
 def customEpg_FileRead(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM,source_filename):
  try:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAeq=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
   if os.path.isfile(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeq):os.remove(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeq)
   xbmcvfs.copy(source_filename,vgRkjLcGtYwsoxBIKJVfmpnPbUCAeq)
   fp=vgRkjLcGtYwsoxBIKJVfmpnPbUCArz(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeq,'r',-1,'utf-8')
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAeH=fp.readlines()
  except:
   return[]
  return vgRkjLcGtYwsoxBIKJVfmpnPbUCAeH
 def dp_Make_Epg(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM,args):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=args.get('sType')
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAuM=args.get('sName')
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAeh=args.get('sNoti')
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCAeh!='N':
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANF=xbmcgui.Dialog()
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAuN=vgRkjLcGtYwsoxBIKJVfmpnPbUCANF.yesno((vgRkjLcGtYwsoxBIKJVfmpnPbUCAuM+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCAuN==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:sys.exit()
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAei=[]
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAeF=[]
  if(vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='wavve' or vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all')and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVE:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAed,vgRkjLcGtYwsoxBIKJVfmpnPbUCAez=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_EexceptGroup_Wavve())
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAez)!=0:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAei.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAed)
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeF.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAez)
  if(vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='tving' or vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all')and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONTVING:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAed,vgRkjLcGtYwsoxBIKJVfmpnPbUCAez=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_EpgInfo_Tving()
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAez)!=0:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAei.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAed)
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeF.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAez)
  if(vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='spotv' or vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all')and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSPOTV:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAed,vgRkjLcGtYwsoxBIKJVfmpnPbUCAez=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_EpgInfo_Spotv(payyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSPOTVPAY)
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAez)!=0:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAei.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAed)
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeF.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAez)
  if(vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='seezn' or vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all')and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZN:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAed,vgRkjLcGtYwsoxBIKJVfmpnPbUCAez=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_EpgInfo_Seezn(exceptGroup=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_EexceptGroup_Seezn())
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAez)!=0:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAei.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAed)
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeF.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAez)
  if(vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='samsung' or vgRkjLcGtYwsoxBIKJVfmpnPbUCAur=='all')and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSAMSUNG:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAud=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_BaseInfo_Samsungtv()
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAed,vgRkjLcGtYwsoxBIKJVfmpnPbUCAez=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_EpgInfo_Samsungtv(vgRkjLcGtYwsoxBIKJVfmpnPbUCAud,exceptGroup=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_EexceptGroup_Samsungtv())
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAez)!=0:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAei.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAed)
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeF.extend(vgRkjLcGtYwsoxBIKJVfmpnPbUCAez)
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCArF(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeF)==0:
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCAeh!='N':vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAue=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_Epg_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri)
   fp=vgRkjLcGtYwsoxBIKJVfmpnPbUCArz(vgRkjLcGtYwsoxBIKJVfmpnPbUCAue,'w',-1,'utf-8')
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAel='<?xml version="1.0" encoding="UTF-8"?>\n'
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAeX='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAeQ='<tv generator-info-name="boritv_epg">\n\n'
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAeT='\n</tv>\n'
   fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAel)
   fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeX)
   fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeQ)
   for vgRkjLcGtYwsoxBIKJVfmpnPbUCAeD in vgRkjLcGtYwsoxBIKJVfmpnPbUCAei:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeW='  <channel id="%s.%s">\n' %(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeD.get('channelid'),vgRkjLcGtYwsoxBIKJVfmpnPbUCAeD.get('ott'))
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeS='    <display-name>%s</display-name>\n'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeD.get('channelnm'))
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAea='    <icon src="%s" />\n' %(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeD.get('channelimg'))
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeO='  </channel>\n\n'
    fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeW)
    fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeS)
    fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAea)
    fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeO)
   for vgRkjLcGtYwsoxBIKJVfmpnPbUCAeD in vgRkjLcGtYwsoxBIKJVfmpnPbUCAeF:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeW='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeD.get('startTime'),vgRkjLcGtYwsoxBIKJVfmpnPbUCAeD.get('endTime'),vgRkjLcGtYwsoxBIKJVfmpnPbUCAeD.get('channelid'),vgRkjLcGtYwsoxBIKJVfmpnPbUCAeD.get('ott'))
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeS='    <title lang="kr">%s</title>\n' %(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeD.get('title'))
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAea='  </programme>\n\n'
    fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeW)
    fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeS)
    fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAea)
   fp.write(vgRkjLcGtYwsoxBIKJVfmpnPbUCAeT)
   fp.close()
  except:
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCAeh!='N':vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti(__language__(30910).encode('utf8'))
   return
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.MakeEpg_SaveJson()
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAuh=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_Epg_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri)
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAui=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.make_Epg_Filename(tempyn=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH)
  if xbmcvfs.copy(vgRkjLcGtYwsoxBIKJVfmpnPbUCAuh,vgRkjLcGtYwsoxBIKJVfmpnPbUCAui):
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCAeh!='N':vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti((vgRkjLcGtYwsoxBIKJVfmpnPbUCAuM+' '+__language__(30912)).encode('utf8'))
  else:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_AUTORESTART:
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeE=xbmcaddon.Addon('pvr.iptvsimple')
    vgRkjLcGtYwsoxBIKJVfmpnPbUCAeE.setSetting('anything','anything')
  except:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCArh 
 def make_EexceptGroup_Wavve(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAey=[]
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVERADIO==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAey.append('라디오/음악')
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVEHOME==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAey.append('홈쇼핑')
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONRELIGION==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAey.append('종교')
  return vgRkjLcGtYwsoxBIKJVfmpnPbUCAey
 def make_EexceptGroup_Seezn(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAey=[]
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZNRADIO==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAey.append('라디오/음악')
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZNHOME==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAey.append('홈쇼핑')
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZNPAY==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAey.append('won')
  return vgRkjLcGtYwsoxBIKJVfmpnPbUCAey
 def make_EexceptGroup_Samsungtv(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAey=[]
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSAMSUNGHOME==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAey.append('홈쇼핑')
  return vgRkjLcGtYwsoxBIKJVfmpnPbUCAey
 def get_radio_list(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM):
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVERADIO==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:return[]
  vgRkjLcGtYwsoxBIKJVfmpnPbUCArN=[{'broadcastid':'46584','genre':'10'}]
  return vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_ChannelList_WavveExcept(vgRkjLcGtYwsoxBIKJVfmpnPbUCArN)
 def check_config(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAru=vgRkjLcGtYwsoxBIKJVfmpnPbUCAri
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVE =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onWavve')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONTVING =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onTvng')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSPOTV =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onSpotv')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZN =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onSeezn')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSAMSUNG =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onSamsung')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVERADIO =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onWavveRadio')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVEHOME =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onWavveHome')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONRELIGION =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onWavveReligion')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSPOTVPAY =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onSpotvPay')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZNPAY =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onSeeznPay')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZNHOME =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onSeeznHome')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZNRADIO =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onSeeznRadio')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSAMSUNGHOME =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('onSamsungHome')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_DISPLAYNM =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('displayOTTnm')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_AUTORESTART =vgRkjLcGtYwsoxBIKJVfmpnPbUCAri if __addon__.getSetting('autoRestart')=='true' else vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_CUSTOM_LIST =vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.customEpg_FileList()
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_FILE_PATH=='' or vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_FILE_NAME=='':vgRkjLcGtYwsoxBIKJVfmpnPbUCAru=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONWAVVE==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONTVING==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSPOTV==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSEEZN==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH and vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.M3U_ONSAMSUNG==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:vgRkjLcGtYwsoxBIKJVfmpnPbUCAru=vgRkjLcGtYwsoxBIKJVfmpnPbUCArH
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCAru==vgRkjLcGtYwsoxBIKJVfmpnPbUCArH:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANF=xbmcgui.Dialog()
   vgRkjLcGtYwsoxBIKJVfmpnPbUCAuN=vgRkjLcGtYwsoxBIKJVfmpnPbUCANF.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if vgRkjLcGtYwsoxBIKJVfmpnPbUCAuN==vgRkjLcGtYwsoxBIKJVfmpnPbUCAri:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCAre={'date_makeepg':vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=vgRkjLcGtYwsoxBIKJVfmpnPbUCArz(vgRkjLcGtYwsoxBIKJVfmpnPbUCANr,'w',-1,'utf-8')
   json.dump(vgRkjLcGtYwsoxBIKJVfmpnPbUCAre,fp)
   fp.close()
  except vgRkjLcGtYwsoxBIKJVfmpnPbUCArl as exception:
   return
 def boritv_main(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM):
  vgRkjLcGtYwsoxBIKJVfmpnPbUCArM=vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.main_params.get('mode',vgRkjLcGtYwsoxBIKJVfmpnPbUCArh)
  vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.check_config()
  if vgRkjLcGtYwsoxBIKJVfmpnPbUCArM is vgRkjLcGtYwsoxBIKJVfmpnPbUCArh:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.dp_Main_List()
  elif vgRkjLcGtYwsoxBIKJVfmpnPbUCArM=='DEL_M3U':
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.dp_Delete_M3u(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.main_params)
  elif vgRkjLcGtYwsoxBIKJVfmpnPbUCArM=='ADD_M3U':
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.dp_MakeAdd_M3u(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.main_params)
  elif vgRkjLcGtYwsoxBIKJVfmpnPbUCArM=='ADD_EPG':
   vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.dp_Make_Epg(vgRkjLcGtYwsoxBIKJVfmpnPbUCANM.main_params)
  else:
   vgRkjLcGtYwsoxBIKJVfmpnPbUCArh
# Created by pyminifier (https://github.com/liftoff/pyminifier)
