__author__="NightRain"
PUblfHDwgOcnYBrGkTahemXFuLVJEs=str
PUblfHDwgOcnYBrGkTahemXFuLVJEz=True
PUblfHDwgOcnYBrGkTahemXFuLVJEo=False
PUblfHDwgOcnYBrGkTahemXFuLVJES=print
PUblfHDwgOcnYBrGkTahemXFuLVJEN=open
PUblfHDwgOcnYBrGkTahemXFuLVJEd=Exception
PUblfHDwgOcnYBrGkTahemXFuLVJQE=int
import json
import time
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 PUblfHDwgOcnYBrGkTahemXFuLVJER='ADDON'
except:
 PUblfHDwgOcnYBrGkTahemXFuLVJER='SINGLE'
if PUblfHDwgOcnYBrGkTahemXFuLVJER=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  PUblfHDwgOcnYBrGkTahemXFuLVJEq=PUblfHDwgOcnYBrGkTahemXFuLVJEs(string).encode('utf-8','ignore')
  PUblfHDwgOcnYBrGkTahemXFuLVJEp=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,PUblfHDwgOcnYBrGkTahemXFuLVJEq),level=PUblfHDwgOcnYBrGkTahemXFuLVJEp)
 def addon_getautoepg():
  return PUblfHDwgOcnYBrGkTahemXFuLVJEz if __addon__.getSetting('autoEpg')=='true' else PUblfHDwgOcnYBrGkTahemXFuLVJEo
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  PUblfHDwgOcnYBrGkTahemXFuLVJES(string)
 def addon_getautoepg():
  return PUblfHDwgOcnYBrGkTahemXFuLVJEz
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class PUblfHDwgOcnYBrGkTahemXFuLVJEQ():
 def __init__(PUblfHDwgOcnYBrGkTahemXFuLVJEv):
  PUblfHDwgOcnYBrGkTahemXFuLVJEv.START_INTERVAL =3000 
  PUblfHDwgOcnYBrGkTahemXFuLVJEv.INTERVAL =20 
  PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_FILETAGNM ='date_makeepg'
  PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_MAKEDATE ='-' 
  PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_WILL_TM =-1 
 def Get_Now_Datetime(PUblfHDwgOcnYBrGkTahemXFuLVJEv):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(PUblfHDwgOcnYBrGkTahemXFuLVJEv):
  PUblfHDwgOcnYBrGkTahemXFuLVJEI ='-'
  if PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_MAKEDATE=='-':
   try:
    fp=PUblfHDwgOcnYBrGkTahemXFuLVJEN(addon_epgupdate_confignm(),'r',-1,'utf-8')
    PUblfHDwgOcnYBrGkTahemXFuLVJEj= json.load(fp)
    fp.close()
    PUblfHDwgOcnYBrGkTahemXFuLVJEI=PUblfHDwgOcnYBrGkTahemXFuLVJEj[PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_FILETAGNM]
   except PUblfHDwgOcnYBrGkTahemXFuLVJEd as exception:
    return 2 
  else:
   PUblfHDwgOcnYBrGkTahemXFuLVJEI=PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_MAKEDATE
  PUblfHDwgOcnYBrGkTahemXFuLVJEx =PUblfHDwgOcnYBrGkTahemXFuLVJEv.Get_Now_Datetime()
  PUblfHDwgOcnYBrGkTahemXFuLVJEi=(PUblfHDwgOcnYBrGkTahemXFuLVJEx-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  PUblfHDwgOcnYBrGkTahemXFuLVJEM =PUblfHDwgOcnYBrGkTahemXFuLVJEx.strftime('%Y-%m-%d')
  PUblfHDwgOcnYBrGkTahemXFuLVJEW =PUblfHDwgOcnYBrGkTahemXFuLVJEx.strftime('%H')
  if PUblfHDwgOcnYBrGkTahemXFuLVJEI==PUblfHDwgOcnYBrGkTahemXFuLVJEM: return-1
  if PUblfHDwgOcnYBrGkTahemXFuLVJEI==PUblfHDwgOcnYBrGkTahemXFuLVJEi and PUblfHDwgOcnYBrGkTahemXFuLVJEW=='00':return 30
  return 2
 def MakeEpg_RandomTm(PUblfHDwgOcnYBrGkTahemXFuLVJEv,mintm):
  PUblfHDwgOcnYBrGkTahemXFuLVJEy=(mintm*60)+random.randint(0,60)
  PUblfHDwgOcnYBrGkTahemXFuLVJEx =PUblfHDwgOcnYBrGkTahemXFuLVJEv.Get_Now_Datetime()
  PUblfHDwgOcnYBrGkTahemXFuLVJEC =(PUblfHDwgOcnYBrGkTahemXFuLVJEx+datetime.timedelta(seconds=PUblfHDwgOcnYBrGkTahemXFuLVJEy)).strftime('%Y%m%d%H%M%S')
  return PUblfHDwgOcnYBrGkTahemXFuLVJQE(PUblfHDwgOcnYBrGkTahemXFuLVJEC)
 def MakeEpg_SaveJson(PUblfHDwgOcnYBrGkTahemXFuLVJEv):
  PUblfHDwgOcnYBrGkTahemXFuLVJEj={PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_FILETAGNM:PUblfHDwgOcnYBrGkTahemXFuLVJEv.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=PUblfHDwgOcnYBrGkTahemXFuLVJEN(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(PUblfHDwgOcnYBrGkTahemXFuLVJEj,fp)
   fp.close()
  except PUblfHDwgOcnYBrGkTahemXFuLVJEd as exception:
   return
 def service_run(PUblfHDwgOcnYBrGkTahemXFuLVJEv):
  if addon_getautoepg()==PUblfHDwgOcnYBrGkTahemXFuLVJEo:return
  PUblfHDwgOcnYBrGkTahemXFuLVJEA=PUblfHDwgOcnYBrGkTahemXFuLVJEv.MakeEpg_DateCheck()
  if PUblfHDwgOcnYBrGkTahemXFuLVJEA<0:
   return
  if PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_WILL_TM<0:
   PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_WILL_TM=PUblfHDwgOcnYBrGkTahemXFuLVJEv.MakeEpg_RandomTm(PUblfHDwgOcnYBrGkTahemXFuLVJEA)
   addon_log('EPG_WILL_TM --> '+PUblfHDwgOcnYBrGkTahemXFuLVJEs(PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_WILL_TM))
  else:
   PUblfHDwgOcnYBrGkTahemXFuLVJEM=PUblfHDwgOcnYBrGkTahemXFuLVJEv.Get_Now_Datetime()
   if PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_WILL_TM<PUblfHDwgOcnYBrGkTahemXFuLVJQE(PUblfHDwgOcnYBrGkTahemXFuLVJEM.strftime('%Y%m%d%H%M%S')):
    addon_log('make epg')
    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
    PUblfHDwgOcnYBrGkTahemXFuLVJEv.MakeEpg_SaveJson()
    PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_MAKEDATE=PUblfHDwgOcnYBrGkTahemXFuLVJEM.strftime('%Y-%m-%d')
    PUblfHDwgOcnYBrGkTahemXFuLVJEv.EPG_WILL_TM =-1
   else:
    pass
  pass
if __name__=="__main__":
 addon_log('__main__')
 PUblfHDwgOcnYBrGkTahemXFuLVJEK=PUblfHDwgOcnYBrGkTahemXFuLVJEQ()
 time.sleep(3)
 while PUblfHDwgOcnYBrGkTahemXFuLVJEz:
  time.sleep(PUblfHDwgOcnYBrGkTahemXFuLVJEK.INTERVAL)
  PUblfHDwgOcnYBrGkTahemXFuLVJEK.service_run()
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
