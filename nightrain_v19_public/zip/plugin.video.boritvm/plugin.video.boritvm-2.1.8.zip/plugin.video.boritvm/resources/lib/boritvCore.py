__author__="NightRain"
ifaPgqTnmLUxYzbXrtQKBHCwSRlDyV=False
ifaPgqTnmLUxYzbXrtQKBHCwSRlDoI=object
ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ=None
ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN=str
ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy=Exception
ifaPgqTnmLUxYzbXrtQKBHCwSRlDop=print
ifaPgqTnmLUxYzbXrtQKBHCwSRlDok=True
ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh=int
ifaPgqTnmLUxYzbXrtQKBHCwSRlDoW=range
ifaPgqTnmLUxYzbXrtQKBHCwSRlDov=len
ifaPgqTnmLUxYzbXrtQKBHCwSRlDoG=set
ifaPgqTnmLUxYzbXrtQKBHCwSRlDoM=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
ifaPgqTnmLUxYzbXrtQKBHCwSRlDIN=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
ifaPgqTnmLUxYzbXrtQKBHCwSRlDIy=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyV,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyV,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyV,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyV,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyV,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyV,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class ifaPgqTnmLUxYzbXrtQKBHCwSRlDIJ(ifaPgqTnmLUxYzbXrtQKBHCwSRlDoI):
 def __init__(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_WAVVE ='https://apis.wavve.com'
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_TVING ='https://api.tving.com'
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_TVINGIMG ='https://image.tving.com'
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_SPOTV ='https://www.spotvnow.co.kr'
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_SEEZN ='https://api.seezntv.com'
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.HTTPTAG ='https://'
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.LIMIT_WAVVE =200
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.LIMIT_TVING =60
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.LIMIT_TVINGEPG=20 
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.APPVERSION ='91.0.4472.124' 
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.DEVICEMODEL ='Chrome' 
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.OSTYPE ='Windows' 
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.OSVERSION ='NT 10.0' 
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.SEEZN_HEADER ={'X-APP-VERSION':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.APPVERSION,'X-DEVICE-MODEL':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.DEVICEMODEL,'X-OS-TYPE':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.OSTYPE,'X-OS-VERSION':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.OSVERSION,}
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.DEFAULT_HEADER={'user-agent':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.USER_AGENT}
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.SLEEP_TIME =0.2
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.INIT_GENRESORT=MASTER_GENRE
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,jobtype,ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,redirects=ifaPgqTnmLUxYzbXrtQKBHCwSRlDyV):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIh=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.DEFAULT_HEADER
  if headers:ifaPgqTnmLUxYzbXrtQKBHCwSRlDIh.update(headers)
  if jobtype=='Get':
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIW=requests.get(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,params=params,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIh,cookies=cookies,allow_redirects=redirects)
  else:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIW=requests.post(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,data=payload,params=params,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIh,cookies=cookies,allow_redirects=redirects)
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIW
 def Get_DefaultParams_Wavve(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv
 def Get_DefaultParams_Tving(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv
 def Get_Now_Datetime(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,in_text):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIM=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIM
 def Get_ChannelList_Wavve(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,exceptGroup=[]):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIj=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_ChannelImg_Wavve()
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_WAVVE+'/cf/live/recommend-channels'
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv.update(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_DefaultParams_Wavve())
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
   if not('celllist' in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['cell_toplist']):return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDId=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['cell_toplist']['celllist']
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDId:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['contentid']
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIA=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['title_list'][0]['text']
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIj:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIe=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIj[ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc]
    else:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIe=''
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_getGenre(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'wavve')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'channelnm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIA,'channelimg':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.HTTPTAG+ifaPgqTnmLUxYzbXrtQKBHCwSRlDIe if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIe!='' else '','ott':'wavve','genrenm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV}
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV not in exceptGroup:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[]
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu
 def Get_ChannelList_WavveExcept(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,exceptGroup=[]):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu=[]
  if exceptGroup==[]:return[]
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_WAVVE+'/cf/live/recommend-channels'
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in exceptGroup:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv={'WeekDay':'all','adult':'n','broadcastid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['broadcastid'],'contenttype':'channel','genre':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['genre'],'isrecommend':'y','limit':ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv.update(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_DefaultParams_Wavve())
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
    if not('celllist' in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['cell_toplist']):return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDId=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['cell_toplist']['celllist']
    for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDId:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['contentid'])
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[]
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu
 def Get_ChannelImg_Wavve(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJN={}
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJy=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_Now_Datetime()
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJo =ifaPgqTnmLUxYzbXrtQKBHCwSRlDJy+datetime.timedelta(hours=3)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_WAVVE+'/live/epgs'
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv={'limit':ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJy.strftime('%Y-%m-%d %H:00'),'enddatetime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJo.strftime('%Y-%m-%d %H:00')}
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv.update(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_DefaultParams_Wavve())
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDId=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['list']
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDId:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJN[ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channelid']]=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channelimage']
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDJN
 def Get_ChanneGenrename_Wavve(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc):
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_WAVVE+'/live/channels/'+ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_DefaultParams_Wavve()
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['genretext']
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return ''
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp
 def Get_ChannelList_Spotv(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,payyn=ifaPgqTnmLUxYzbXrtQKBHCwSRlDok):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu=[]
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_SPOTV+'/api/v2/channel'
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['id'])
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'channelnm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['name'],'channelimg':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['logo'],'ott':'spotv','genrenm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_getGenre(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'spotv'),'free':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['free']}
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[]
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu
 def Get_ChannelList_Tving(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJk=[]
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_TVING+'/v2/media/lives'
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv={'pageNo':'1','pageSize':ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv.update(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_DefaultParams_Tving())
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
   if not('result' in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['body']):return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDId=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['body']['result']
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDId:
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['live_code']=='C44441':continue 
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJk.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['live_code'])
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIj=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_ChannelImg_Tving(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJk)
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDId:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['live_code']
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc=='C44441':continue 
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIA=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['schedule']['channel']['name']['ko']
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIj:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIe=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIj[ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc]
    else:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIe=''
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'channelnm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIA,'channelimg':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIe,'ott':'tving','genrenm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_getGenre(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'tving')}
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[]
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu
 def Get_timestamp(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,timetype=1):
  ts=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,timetype):
  if timetype=='1':
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJh={'transactionId':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJh={'timestamp':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_timestamp(timetype=1),'transactionId':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_timestamp(timetype=1)+'000000000000001',}
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDJh
 def Get_ChannelList_Seezn(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,exceptGroup=[]):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJW =ifaPgqTnmLUxYzbXrtQKBHCwSRlDok if 'won' in exceptGroup else ifaPgqTnmLUxYzbXrtQKBHCwSRlDyV
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJv =ifaPgqTnmLUxYzbXrtQKBHCwSRlDok if '홈쇼핑' in exceptGroup else ifaPgqTnmLUxYzbXrtQKBHCwSRlDyV
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJG=ifaPgqTnmLUxYzbXrtQKBHCwSRlDok if '라디오/음악' in exceptGroup else ifaPgqTnmLUxYzbXrtQKBHCwSRlDyV
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_SEEZN+'/svc/menu/app6/api/epg_chlist' 
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv={'category_id':'2','istest':'0',}
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJM=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Make_Header_Timestamp(timetype='2')
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJM.update(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.SEEZN_HEADER)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJM,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,redirects=ifaPgqTnmLUxYzbXrtQKBHCwSRlDok)
   if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.status_code!=200:return[]
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
   if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO.get('meta').get('code')!='200':return[]
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJu=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO.get('data').get('list')[0].get('list_channel')
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDJu:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJj =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF.get('bit_rate_info').split(",")[0]
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF.get('ch_no')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_getGenre(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'seezn')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJE =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF.get('type')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'channelnm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF.get('service_ch_name').replace(',','.'),'channelimg':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF.get('ch_image_list'),'ott':'seezn','genrenm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV,}
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc=='404':continue 
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['adult_yn']=='Y':continue 
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['won_yn'] =='Y' and ifaPgqTnmLUxYzbXrtQKBHCwSRlDJW==ifaPgqTnmLUxYzbXrtQKBHCwSRlDok:continue 
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV in exceptGroup:continue 
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDJE!='EPG':
     if ifaPgqTnmLUxYzbXrtQKBHCwSRlDJv and ifaPgqTnmLUxYzbXrtQKBHCwSRlDJE=='SHOP' :continue
     if ifaPgqTnmLUxYzbXrtQKBHCwSRlDJG and ifaPgqTnmLUxYzbXrtQKBHCwSRlDJE=='AUDIO_MUSIC':continue
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[]
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu
 def Get_EpgInfo_Seezn(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,exceptGroup=[]):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu=[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_ChannelList_Seezn(exceptGroup)
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_SEEZN+'/svc/menu/app6/api/epg_proglist' 
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDJO in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu:
    time.sleep(0.3)
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc =ifaPgqTnmLUxYzbXrtQKBHCwSRlDJO.get('channelid')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv={'ch_no':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc}
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJM=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Make_Header_Timestamp(timetype='2')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJM.update(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.SEEZN_HEADER)
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJM,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,redirects=ifaPgqTnmLUxYzbXrtQKBHCwSRlDok)
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.status_code!=200:return[],[]
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJd=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDJd.get('meta').get('code')!='200':return[],[]
    for ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDJd.get('data').get('list'):
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJc=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF.get('start_ymd')
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJy=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF.get('start_time').replace(':','')
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJo =ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF.get('end_time').replace(':','')
     if ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJy)>ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJo):
      ifaPgqTnmLUxYzbXrtQKBHCwSRlDJA=datetime.datetime.strptime(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJc,'%Y%m%d')+datetime.timedelta(days=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh(1))
      ifaPgqTnmLUxYzbXrtQKBHCwSRlDJA=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJA.strftime('%Y%m%d')
     else:
      ifaPgqTnmLUxYzbXrtQKBHCwSRlDJA=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJc
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'title':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.xmlText(urllib.parse.unquote_plus(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF.get('program_name'))),'startTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJc+ifaPgqTnmLUxYzbXrtQKBHCwSRlDJy+'00','endTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJA+ifaPgqTnmLUxYzbXrtQKBHCwSRlDJo+'00','ott':'seezn'}
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[],[]
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu,ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs
 def make_EpgDatetime_Tving(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,days=2):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJe=[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_DateList(days=2,dateType='2')
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNI=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV:
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDNJ in ifaPgqTnmLUxYzbXrtQKBHCwSRlDoW(8):
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'ndate':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF,'starttm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIN[ifaPgqTnmLUxYzbXrtQKBHCwSRlDNJ]['starttm'],'endtm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIN[ifaPgqTnmLUxYzbXrtQKBHCwSRlDNJ]['endtm']}
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDNy=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF+ifaPgqTnmLUxYzbXrtQKBHCwSRlDIN[ifaPgqTnmLUxYzbXrtQKBHCwSRlDNJ]['starttm'])
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDNo=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF+ifaPgqTnmLUxYzbXrtQKBHCwSRlDIN[ifaPgqTnmLUxYzbXrtQKBHCwSRlDNJ]['endtm'])
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDNI<=ifaPgqTnmLUxYzbXrtQKBHCwSRlDNy or(ifaPgqTnmLUxYzbXrtQKBHCwSRlDNy<ifaPgqTnmLUxYzbXrtQKBHCwSRlDNI and ifaPgqTnmLUxYzbXrtQKBHCwSRlDNI<ifaPgqTnmLUxYzbXrtQKBHCwSRlDNo):
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJe.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDJe
 def make_DateList(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,days=2,dateType='1'):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV=[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNp =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_Now_Datetime()
  for i in ifaPgqTnmLUxYzbXrtQKBHCwSRlDoW(days):
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDNk=ifaPgqTnmLUxYzbXrtQKBHCwSRlDNp+datetime.timedelta(days=i)
   if dateType=='1':
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDNk.strftime('%Y-%m-%d'))
   else:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDNk.strftime('%Y%m%d'))
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV
 def make_Tving_ChannleGroup(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,ifaPgqTnmLUxYzbXrtQKBHCwSRlDJk):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNh=[]
  i=0
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNW=''
  for ifaPgqTnmLUxYzbXrtQKBHCwSRlDNv in ifaPgqTnmLUxYzbXrtQKBHCwSRlDJk:
   if i==0:ifaPgqTnmLUxYzbXrtQKBHCwSRlDNW=ifaPgqTnmLUxYzbXrtQKBHCwSRlDNv
   else:ifaPgqTnmLUxYzbXrtQKBHCwSRlDNW+=',%s'%(ifaPgqTnmLUxYzbXrtQKBHCwSRlDNv)
   i+=1
   if i>=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.LIMIT_TVINGEPG:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDNh.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDNW)
    i=0
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDNW=''
  if ifaPgqTnmLUxYzbXrtQKBHCwSRlDNW!='':
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDNh.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDNW)
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDNh
 def Get_ChannelImg_Tving(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,chid_list):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJN={}
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDNG=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_Now_Datetime().strftime('%Y%m%d')
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJy =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIN[6]['starttm'] 
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJo =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIN[6]['endtm']
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDNh=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_Tving_ChannleGroup(chid_list)
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDNh:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_TVING+'/v2/media/schedules'
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv={'pageNo':'1','pageSize':ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':ifaPgqTnmLUxYzbXrtQKBHCwSRlDNG,'broadcastDate':ifaPgqTnmLUxYzbXrtQKBHCwSRlDNG,'startBroadTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJy,'endBroadTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJo,'channelCode':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF}
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv.update(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_DefaultParams_Tving())
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
    if not('result' in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['body']):return{}
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDId=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['body']['result']
    for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDId:
     for ifaPgqTnmLUxYzbXrtQKBHCwSRlDNM in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['image']:
      if ifaPgqTnmLUxYzbXrtQKBHCwSRlDNM['code']=='CAIC0400':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJN[ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channel_code']]=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_TVINGIMG+ifaPgqTnmLUxYzbXrtQKBHCwSRlDNM['url']
      elif ifaPgqTnmLUxYzbXrtQKBHCwSRlDNM['code']=='CAIC1400':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJN[ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channel_code']]=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_TVINGIMG+ifaPgqTnmLUxYzbXrtQKBHCwSRlDNM['url']
      elif ifaPgqTnmLUxYzbXrtQKBHCwSRlDNM['code']=='CAIC1900':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJN[ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channel_code']]=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_TVINGIMG+ifaPgqTnmLUxYzbXrtQKBHCwSRlDNM['url']
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return{}
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDJN
 def Get_EpgInfo_Spotv(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,days=2,payyn=ifaPgqTnmLUxYzbXrtQKBHCwSRlDok):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu=[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_DateList(days=days,dateType='1')
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_SPOTV+'/api/v2/channel'
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc =ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['id'])
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'channelnm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.xmlText(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['name']),'channelimg':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['logo'],'ott':'spotv'}
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[],[]
  try:
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDNu in ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_SPOTV+'/api/v2/program/'+ifaPgqTnmLUxYzbXrtQKBHCwSRlDNu
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
    for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc =ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channelId'])
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'title':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.xmlText(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['title']),'startTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
    time.sleep(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.SLEEP_TIME)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[],[]
  '''
  try:
   for i_channel in channel_list:
    if i_channel['epgtype'] == 'spotvon':
     tmp_list = self.Get_EpgInfo_Spotv_spotvon(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    if i_channel['epgtype'] == 'spotvnet':
     tmp_list = self.Get_EpgInfo_Spotv_spotvnet(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu,ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs
 def Get_EpgInfo_Spotv_spotvon(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,epgnm,days):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_DateList(days=days,dateType='1')
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNj=''
  try:
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDNu in ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,ifaPgqTnmLUxYzbXrtQKBHCwSRlDNu)
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
    for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'title':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.xmlText(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['title']),'startTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['sch_date'].replace('-','')+ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['sch_hour']).zfill(2)+ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['sch_min']+'00','ott':'spotv'}
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDNj=ifaPgqTnmLUxYzbXrtQKBHCwSRlDNu
   for i in ifaPgqTnmLUxYzbXrtQKBHCwSRlDoW(ifaPgqTnmLUxYzbXrtQKBHCwSRlDov(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs)):
    if i>0:ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i-1]['endTime']=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i]['startTime']
    if i==ifaPgqTnmLUxYzbXrtQKBHCwSRlDov(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs)-1: ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i]['endTime']=ifaPgqTnmLUxYzbXrtQKBHCwSRlDNj+'240000'
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[]
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs
 def Get_EpgInfo_Spotv_spotvnet(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,epgnm,days):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_DateList(days=days,dateType='1')
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNj=''
  try:
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDNu in ifaPgqTnmLUxYzbXrtQKBHCwSRlDJV:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,ifaPgqTnmLUxYzbXrtQKBHCwSRlDNu)
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
    for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'title':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.xmlText(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['title']),'startTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['sch_date'].replace('-','')+ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['sch_hour']).zfill(2)+ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['sch_min']+'00','ott':'spotv'}
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDNj=ifaPgqTnmLUxYzbXrtQKBHCwSRlDNu
   for i in ifaPgqTnmLUxYzbXrtQKBHCwSRlDoW(ifaPgqTnmLUxYzbXrtQKBHCwSRlDov(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs)):
    if i>0:ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i-1]['endTime']=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i]['startTime']
    if i==ifaPgqTnmLUxYzbXrtQKBHCwSRlDov(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs)-1: ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i]['endTime']=ifaPgqTnmLUxYzbXrtQKBHCwSRlDNj+'240000'
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[]
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs
 def Get_EpgInfo_Wavve(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,days=2,exceptGroup=[]):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNp =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_Now_Datetime()
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNE =ifaPgqTnmLUxYzbXrtQKBHCwSRlDNp+datetime.timedelta(hours=-2)
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNs =ifaPgqTnmLUxYzbXrtQKBHCwSRlDNp+datetime.timedelta(days=(days-1))
  if ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh(ifaPgqTnmLUxYzbXrtQKBHCwSRlDNE.strftime('%H'))<=3:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDNO=ifaPgqTnmLUxYzbXrtQKBHCwSRlDNE.strftime('%Y-%m-%d 00:00')
  else:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDNO=ifaPgqTnmLUxYzbXrtQKBHCwSRlDNE.strftime('%Y-%m-%d %H:00')
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNd =ifaPgqTnmLUxYzbXrtQKBHCwSRlDNs.strftime('%Y-%m-%d 24:00')
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_WAVVE+'/live/epgs'
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv={'limit':ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDNO,'enddatetime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDNd}
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv.update(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_DefaultParams_Wavve())
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJd=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['list']
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDJd:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channelid']
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_getGenre(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'wavve')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'channelnm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.xmlText(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channelname']),'channelimg':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.HTTPTAG+ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channelimage'],'ott':'wavve'}
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV not in exceptGroup:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
    for ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['list']:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channelid'],'title':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.xmlText(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF['title']),'startTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV not in exceptGroup and ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF['starttime']!=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF['endtime']:
      ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[],[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNF=ifaPgqTnmLUxYzbXrtQKBHCwSRlDov(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs)
  for i in(ifaPgqTnmLUxYzbXrtQKBHCwSRlDoW(1,ifaPgqTnmLUxYzbXrtQKBHCwSRlDNF)):
   if ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i-1]['endTime'])+1==ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i]['startTime'])and ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i-1]['channelid']==ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i]['channelid']:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i-1]['endTime']=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs[i]['startTime']
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu,ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs
 def Get_EpgInfo_Tving(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,days=2):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu=[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNc =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNA =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_EpgDatetime_Tving(days=days)
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_ChannelList_Tving()
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNe=[]
  for i in ifaPgqTnmLUxYzbXrtQKBHCwSRlDoW(ifaPgqTnmLUxYzbXrtQKBHCwSRlDov(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu)):
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu[i]['channelnm']=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.xmlText(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu[i]['channelnm'])
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDNe.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu[i]['channelid'])
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNV=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_Tving_ChannleGroup(ifaPgqTnmLUxYzbXrtQKBHCwSRlDNe)
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_TVING+'/v2/media/schedules'
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDyI in ifaPgqTnmLUxYzbXrtQKBHCwSRlDNA:
    for ifaPgqTnmLUxYzbXrtQKBHCwSRlDJO in ifaPgqTnmLUxYzbXrtQKBHCwSRlDNV:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv={'pageNo':'1','pageSize':ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyI['ndate'],'broadcastDate':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyI['ndate'],'startBroadTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyI['starttm'],'endBroadTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyI['endtm'],'channelCode':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJO}
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv.update(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_DefaultParams_Tving())
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDId=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['body']['result']
     for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDId:
      if 'schedules' not in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF:continue
      if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['schedules']==ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ:continue
      for ifaPgqTnmLUxYzbXrtQKBHCwSRlDyJ in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['schedules']:
       ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyJ['schedule_code'],'title':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.xmlText(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyJ['program']['name']['ko']),'startTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyJ['broadcast_start_time']),'endTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyJ['broadcast_end_time']),'ott':'tving'}
       ifaPgqTnmLUxYzbXrtQKBHCwSRlDyN=ifaPgqTnmLUxYzbXrtQKBHCwSRlDyJ['schedule_code']+ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyJ['broadcast_start_time'])
       if ifaPgqTnmLUxYzbXrtQKBHCwSRlDyN in ifaPgqTnmLUxYzbXrtQKBHCwSRlDNc:continue
       ifaPgqTnmLUxYzbXrtQKBHCwSRlDNc.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyN)
       ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
     time.sleep(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.SLEEP_TIME)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[],[]
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu,ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs
 def Get_BaseInfo_Samsungtv(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo={}
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_SAMSUNGTV
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ)
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDyp in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.cookies:
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDyp.name=='session':
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo['session']=ifaPgqTnmLUxYzbXrtQKBHCwSRlDyp.value
    elif ifaPgqTnmLUxYzbXrtQKBHCwSRlDyp.name=='session.sig':
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo['session.sig']=ifaPgqTnmLUxYzbXrtQKBHCwSRlDyp.value
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return{}
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_SAMSUNGTV+'/user'
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDyk={'session':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo['session'],'session.sig':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo['session.sig'],}
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDyk)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo['countryCode']=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO.get('countryCode')
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo['uuid'] =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO.get('uuid')
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo['ip'] =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO.get('ip')
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return{}
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo
 def t_Cache(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDNI =ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh(time.time())
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyh=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoh(ifaPgqTnmLUxYzbXrtQKBHCwSRlDNI-ifaPgqTnmLUxYzbXrtQKBHCwSRlDNI%3600)
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDyh,ifaPgqTnmLUxYzbXrtQKBHCwSRlDNI
 def zlib_compress(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,plaintext):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyW=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyW).decode('utf-8')
 def Get_BaseRequest_Samsungtv(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO={}
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.API_SAMSUNGTV+'/api/lives'
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDyh,ifaPgqTnmLUxYzbXrtQKBHCwSRlDNI=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.t_Cache()
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDyv=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.zlib_compress(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo['uuid']+':'+ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDNI))
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDyk={'session':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo['session'],'session.sig':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo['session.sig'],}
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv ={'t':ifaPgqTnmLUxYzbXrtQKBHCwSRlDoN(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyh)}
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJM ={'x-cred-payload':ifaPgqTnmLUxYzbXrtQKBHCwSRlDyv}
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.callRequestCookies('Get',ifaPgqTnmLUxYzbXrtQKBHCwSRlDIE,payload=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoJ,params=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIv,headers=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJM,cookies=ifaPgqTnmLUxYzbXrtQKBHCwSRlDyk)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=json.loads(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIs.text)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO
 def Get_ChannelList_Samsungtv(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo,exceptGroup=[]):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu =[]
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_BaseRequest_Samsungtv(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDId=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['live']['channel']
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDId:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF.get('id')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIA =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF.get('name')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIe=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF.get('logo')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_getGenre(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'samsung')
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV in['-','']:ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV='정주행 채널'
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'channelnm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIA,'channelimg':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIe,'ott':'samsung','genrenm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV}
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV not in exceptGroup:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[]
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu
 def Get_EpgInfo_Samsungtv(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo,exceptGroup=[]):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu=[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs =[]
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_BaseRequest_Samsungtv(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIO['live']['channel']
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDJO in ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc =ifaPgqTnmLUxYzbXrtQKBHCwSRlDJO.get('id')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIA =ifaPgqTnmLUxYzbXrtQKBHCwSRlDJO.get('name')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIe=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJO.get('logo')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJd =ifaPgqTnmLUxYzbXrtQKBHCwSRlDJO.get('program')
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.make_getGenre(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'samsung')
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV in exceptGroup:
     continue
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'channelnm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIA,'channelimg':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIe,'ott':'samsung','genrenm':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIV}
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
    for ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDJd:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDyG=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF.get('start_time')
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDyM =ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF.get('duration') 
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJy=datetime.datetime.strptime(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyG,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJo =ifaPgqTnmLUxYzbXrtQKBHCwSRlDJy+datetime.timedelta(seconds=ifaPgqTnmLUxYzbXrtQKBHCwSRlDyM)
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI={'channelid':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,'title':ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.xmlText(urllib.parse.unquote_plus(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJF.get('title'))),'startTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJy.strftime('%Y%m%d%H%M00'),'endTime':ifaPgqTnmLUxYzbXrtQKBHCwSRlDJo.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  except ifaPgqTnmLUxYzbXrtQKBHCwSRlDoy as exception:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDop(exception)
   return[],[]
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDIu,ifaPgqTnmLUxYzbXrtQKBHCwSRlDJs
 def make_getGenre(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,ifaPgqTnmLUxYzbXrtQKBHCwSRlDyc):
  try:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.INIT_CHANNEL.get(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc+'.'+ifaPgqTnmLUxYzbXrtQKBHCwSRlDyc).get('genre')
  except:
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.INIT_CHANNEL.get('-').get('genre')
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp
 def make_base_allchannel_py(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo,ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo):
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu =[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyj=[]
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyE=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoG()
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_ChannelList_Wavve()
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu.extend(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_ChannelList_Tving()
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu.extend(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_ChannelList_Spotv()
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu.extend(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_ChannelList_Seezn()
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu.extend(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_ChannelList_Samsungtv(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyo)
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu.extend(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJI)
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDop('1')
  for i in ifaPgqTnmLUxYzbXrtQKBHCwSRlDoW(ifaPgqTnmLUxYzbXrtQKBHCwSRlDov(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu)):
   if ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu[i]['genrenm']=='-':
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu[i]['ott']=='wavve':
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp=ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.Get_ChanneGenrename_Wavve(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu[i]['channelid'])
     if ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp not in ifaPgqTnmLUxYzbXrtQKBHCwSRlDyE:ifaPgqTnmLUxYzbXrtQKBHCwSRlDyE.add(ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp)
     time.sleep(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.SLEEP_TIME)
    elif ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu[i]['ott']=='spotv':
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp='스포츠'
    else:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp='-'
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu[i]['genrenm']=ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp
   else:
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu[i]['genrenm']not in ifaPgqTnmLUxYzbXrtQKBHCwSRlDyE:ifaPgqTnmLUxYzbXrtQKBHCwSRlDyE.add(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu[i]['genrenm'])
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyE.add(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIo.INIT_CHANNEL.get('-').get('genre'))
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDop('2')
  for ifaPgqTnmLUxYzbXrtQKBHCwSRlDys in ifaPgqTnmLUxYzbXrtQKBHCwSRlDyE:
   for ifaPgqTnmLUxYzbXrtQKBHCwSRlDyO in ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu:
    if ifaPgqTnmLUxYzbXrtQKBHCwSRlDyO['genrenm']==ifaPgqTnmLUxYzbXrtQKBHCwSRlDys:
     ifaPgqTnmLUxYzbXrtQKBHCwSRlDyj.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyO)
  for ifaPgqTnmLUxYzbXrtQKBHCwSRlDyO in ifaPgqTnmLUxYzbXrtQKBHCwSRlDyu:
   if ifaPgqTnmLUxYzbXrtQKBHCwSRlDyO['genrenm']not in ifaPgqTnmLUxYzbXrtQKBHCwSRlDyE:
    ifaPgqTnmLUxYzbXrtQKBHCwSRlDyj.append(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyO)
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDop('3')
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyd='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyd):os.remove(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyd)
  fp=ifaPgqTnmLUxYzbXrtQKBHCwSRlDoM(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyd,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  ifaPgqTnmLUxYzbXrtQKBHCwSRlDyF=ifaPgqTnmLUxYzbXrtQKBHCwSRlDov(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyj)
  i=0
  for ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF in ifaPgqTnmLUxYzbXrtQKBHCwSRlDyj:
   i+=1
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channelid']
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDIA =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['channelnm']
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDyc =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['ott']
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDyA ='%s.%s'%(ifaPgqTnmLUxYzbXrtQKBHCwSRlDIc,ifaPgqTnmLUxYzbXrtQKBHCwSRlDyc)
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIF['genrenm']
   ifaPgqTnmLUxYzbXrtQKBHCwSRlDye='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(ifaPgqTnmLUxYzbXrtQKBHCwSRlDyA,ifaPgqTnmLUxYzbXrtQKBHCwSRlDIA,ifaPgqTnmLUxYzbXrtQKBHCwSRlDJp)
   if i<ifaPgqTnmLUxYzbXrtQKBHCwSRlDyF:
    fp.write(ifaPgqTnmLUxYzbXrtQKBHCwSRlDye+',\n')
   else:
    fp.write(ifaPgqTnmLUxYzbXrtQKBHCwSRlDye+'\n')
  fp.write('}\n')
  fp.close()
  return ifaPgqTnmLUxYzbXrtQKBHCwSRlDyE
# Created by pyminifier (https://github.com/liftoff/pyminifier)
