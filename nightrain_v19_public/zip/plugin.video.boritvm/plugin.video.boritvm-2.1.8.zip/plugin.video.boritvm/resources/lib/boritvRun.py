__author__="NightRain"
EdunhyTNAxLziaHjGYDmPkOfXUovep=object
EdunhyTNAxLziaHjGYDmPkOfXUovel=False
EdunhyTNAxLziaHjGYDmPkOfXUoveV=None
EdunhyTNAxLziaHjGYDmPkOfXUoveR=True
EdunhyTNAxLziaHjGYDmPkOfXUoveQ=len
EdunhyTNAxLziaHjGYDmPkOfXUoves=str
EdunhyTNAxLziaHjGYDmPkOfXUoveg=open
EdunhyTNAxLziaHjGYDmPkOfXUoveI=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
EdunhyTNAxLziaHjGYDmPkOfXUovFM=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'     - M3U 추가 (시즌)','mode':'ADD_M3U','sType':'seezn','sName':'시즌'},{'title':'     - M3U 추가 (삼성tv 플러스)','mode':'ADD_M3U','sType':'samsung','sName':'삼성TV 플러스'},{'title':'     - M3U 추가 (사용자 m3u)','mode':'ADD_M3U','sType':'custom','sName':'사용자 m3u 파일'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
EdunhyTNAxLziaHjGYDmPkOfXUovFe=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class EdunhyTNAxLziaHjGYDmPkOfXUovFW(EdunhyTNAxLziaHjGYDmPkOfXUovep):
 def __init__(EdunhyTNAxLziaHjGYDmPkOfXUovFB,EdunhyTNAxLziaHjGYDmPkOfXUovFp,EdunhyTNAxLziaHjGYDmPkOfXUovFl,EdunhyTNAxLziaHjGYDmPkOfXUovFV):
  EdunhyTNAxLziaHjGYDmPkOfXUovFB._addon_url =EdunhyTNAxLziaHjGYDmPkOfXUovFp
  EdunhyTNAxLziaHjGYDmPkOfXUovFB._addon_handle =EdunhyTNAxLziaHjGYDmPkOfXUovFl
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.main_params =EdunhyTNAxLziaHjGYDmPkOfXUovFV
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_FILE_PATH ='' 
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_FILE_NAME ='' 
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVE =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONTVING =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSPOTV =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZN =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSAMSUNG =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVERADIO =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVEHOME =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONRELIGION =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSPOTVPAY =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZNPAY =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZNHOME =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZNRADIO =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSAMSUNGHOME=EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_DISPLAYNM =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_AUTORESTART =EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_CUSTOM_LIST =[]
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj =ifaPgqTnmLUxYzbXrtQKBHCwSRlDIJ() 
 def addon_noti(EdunhyTNAxLziaHjGYDmPkOfXUovFB,sting):
  try:
   EdunhyTNAxLziaHjGYDmPkOfXUovFQ=xbmcgui.Dialog()
   EdunhyTNAxLziaHjGYDmPkOfXUovFQ.notification(__addonname__,sting)
  except:
   EdunhyTNAxLziaHjGYDmPkOfXUoveV
 def addon_log(EdunhyTNAxLziaHjGYDmPkOfXUovFB,string):
  try:
   EdunhyTNAxLziaHjGYDmPkOfXUovFs=string.encode('utf-8','ignore')
  except:
   EdunhyTNAxLziaHjGYDmPkOfXUovFs='addonException: addon_log'
  EdunhyTNAxLziaHjGYDmPkOfXUovFg=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,EdunhyTNAxLziaHjGYDmPkOfXUovFs),level=EdunhyTNAxLziaHjGYDmPkOfXUovFg)
 def get_keyboard_input(EdunhyTNAxLziaHjGYDmPkOfXUovFB,EdunhyTNAxLziaHjGYDmPkOfXUovFC):
  EdunhyTNAxLziaHjGYDmPkOfXUovFI=EdunhyTNAxLziaHjGYDmPkOfXUoveV
  kb=xbmc.Keyboard()
  kb.setHeading(EdunhyTNAxLziaHjGYDmPkOfXUovFC)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   EdunhyTNAxLziaHjGYDmPkOfXUovFI=kb.getText()
  return EdunhyTNAxLziaHjGYDmPkOfXUovFI
 def add_dir(EdunhyTNAxLziaHjGYDmPkOfXUovFB,label,sublabel='',img='',infoLabels=EdunhyTNAxLziaHjGYDmPkOfXUoveV,isFolder=EdunhyTNAxLziaHjGYDmPkOfXUoveR,params='',isLink=EdunhyTNAxLziaHjGYDmPkOfXUovel,ContextMenu=EdunhyTNAxLziaHjGYDmPkOfXUoveV):
  EdunhyTNAxLziaHjGYDmPkOfXUovFr='%s?%s'%(EdunhyTNAxLziaHjGYDmPkOfXUovFB._addon_url,urllib.parse.urlencode(params))
  if sublabel:EdunhyTNAxLziaHjGYDmPkOfXUovFC='%s < %s >'%(label,sublabel)
  else: EdunhyTNAxLziaHjGYDmPkOfXUovFC=label
  if not img:img='DefaultFolder.png'
  EdunhyTNAxLziaHjGYDmPkOfXUovFc=xbmcgui.ListItem(EdunhyTNAxLziaHjGYDmPkOfXUovFC)
  EdunhyTNAxLziaHjGYDmPkOfXUovFc.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:EdunhyTNAxLziaHjGYDmPkOfXUovFc.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   EdunhyTNAxLziaHjGYDmPkOfXUovFc.setProperty('IsPlayable','true')
  if ContextMenu:EdunhyTNAxLziaHjGYDmPkOfXUovFc.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(EdunhyTNAxLziaHjGYDmPkOfXUovFB._addon_handle,EdunhyTNAxLziaHjGYDmPkOfXUovFr,EdunhyTNAxLziaHjGYDmPkOfXUovFc,isFolder)
 def make_M3u_Filename(EdunhyTNAxLziaHjGYDmPkOfXUovFB,tempyn=EdunhyTNAxLziaHjGYDmPkOfXUovel):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_FILE_PATH+EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(EdunhyTNAxLziaHjGYDmPkOfXUovFB,tempyn=EdunhyTNAxLziaHjGYDmPkOfXUovel):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_FILE_PATH+EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_FILE_NAME+'.xml'
 def dp_Main_List(EdunhyTNAxLziaHjGYDmPkOfXUovFB):
  for EdunhyTNAxLziaHjGYDmPkOfXUovFb in EdunhyTNAxLziaHjGYDmPkOfXUovFM:
   EdunhyTNAxLziaHjGYDmPkOfXUovFC=EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('title')
   EdunhyTNAxLziaHjGYDmPkOfXUovFJ=''
   EdunhyTNAxLziaHjGYDmPkOfXUovFq={'mode':EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('mode'),'sType':EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('sType'),'sName':EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('sName')}
   if EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('mode')=='XXX':
    EdunhyTNAxLziaHjGYDmPkOfXUovFt=EdunhyTNAxLziaHjGYDmPkOfXUovel
    EdunhyTNAxLziaHjGYDmPkOfXUovFw =EdunhyTNAxLziaHjGYDmPkOfXUoveR
   else:
    EdunhyTNAxLziaHjGYDmPkOfXUovFt=EdunhyTNAxLziaHjGYDmPkOfXUoveR
    EdunhyTNAxLziaHjGYDmPkOfXUovFw =EdunhyTNAxLziaHjGYDmPkOfXUovel
   EdunhyTNAxLziaHjGYDmPkOfXUovFK=EdunhyTNAxLziaHjGYDmPkOfXUoveR
   if EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('mode')=='ADD_M3U':
    if EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('sType')=='wavve' and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVE ==EdunhyTNAxLziaHjGYDmPkOfXUovel:EdunhyTNAxLziaHjGYDmPkOfXUovFK=EdunhyTNAxLziaHjGYDmPkOfXUovel
    if EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('sType')=='tving' and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONTVING ==EdunhyTNAxLziaHjGYDmPkOfXUovel:EdunhyTNAxLziaHjGYDmPkOfXUovFK=EdunhyTNAxLziaHjGYDmPkOfXUovel
    if EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('sType')=='spotv' and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSPOTV ==EdunhyTNAxLziaHjGYDmPkOfXUovel:EdunhyTNAxLziaHjGYDmPkOfXUovFK=EdunhyTNAxLziaHjGYDmPkOfXUovel
    if EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('sType')=='seezn' and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZN ==EdunhyTNAxLziaHjGYDmPkOfXUovel:EdunhyTNAxLziaHjGYDmPkOfXUovFK=EdunhyTNAxLziaHjGYDmPkOfXUovel
    if EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('sType')=='samsung' and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSAMSUNG==EdunhyTNAxLziaHjGYDmPkOfXUovel:EdunhyTNAxLziaHjGYDmPkOfXUovFK=EdunhyTNAxLziaHjGYDmPkOfXUovel
    if EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('sType')=='custom' and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_CUSTOM_LIST==[]:EdunhyTNAxLziaHjGYDmPkOfXUovFK=EdunhyTNAxLziaHjGYDmPkOfXUovel
   if EdunhyTNAxLziaHjGYDmPkOfXUovFK==EdunhyTNAxLziaHjGYDmPkOfXUoveR:
    if 'icon' in EdunhyTNAxLziaHjGYDmPkOfXUovFb:EdunhyTNAxLziaHjGYDmPkOfXUovFJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',EdunhyTNAxLziaHjGYDmPkOfXUovFb.get('icon')) 
    EdunhyTNAxLziaHjGYDmPkOfXUovFB.add_dir(EdunhyTNAxLziaHjGYDmPkOfXUovFC,sublabel='',img=EdunhyTNAxLziaHjGYDmPkOfXUovFJ,infoLabels=EdunhyTNAxLziaHjGYDmPkOfXUoveV,isFolder=EdunhyTNAxLziaHjGYDmPkOfXUovFt,params=EdunhyTNAxLziaHjGYDmPkOfXUovFq,isLink=EdunhyTNAxLziaHjGYDmPkOfXUovFw)
  if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovFM)>0:xbmcplugin.endOfDirectory(EdunhyTNAxLziaHjGYDmPkOfXUovFB._addon_handle,cacheToDisc=EdunhyTNAxLziaHjGYDmPkOfXUoveR)
 def dp_Delete_M3u(EdunhyTNAxLziaHjGYDmPkOfXUovFB,args):
  EdunhyTNAxLziaHjGYDmPkOfXUovFQ=xbmcgui.Dialog()
  EdunhyTNAxLziaHjGYDmPkOfXUovWF=EdunhyTNAxLziaHjGYDmPkOfXUovFQ.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if EdunhyTNAxLziaHjGYDmPkOfXUovWF==EdunhyTNAxLziaHjGYDmPkOfXUovel:sys.exit()
  EdunhyTNAxLziaHjGYDmPkOfXUovWM=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_M3u_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUovel)
  if xbmcvfs.exists(EdunhyTNAxLziaHjGYDmPkOfXUovWM):
   if xbmcvfs.delete(EdunhyTNAxLziaHjGYDmPkOfXUovWM)==EdunhyTNAxLziaHjGYDmPkOfXUovel:
    EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti(__language__(30910).encode('utf-8'))
    return
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(EdunhyTNAxLziaHjGYDmPkOfXUovFB,args):
  EdunhyTNAxLziaHjGYDmPkOfXUovWe=args.get('sType')
  EdunhyTNAxLziaHjGYDmPkOfXUovWB=args.get('sName')
  EdunhyTNAxLziaHjGYDmPkOfXUovFQ=xbmcgui.Dialog()
  EdunhyTNAxLziaHjGYDmPkOfXUovWF=EdunhyTNAxLziaHjGYDmPkOfXUovFQ.yesno((EdunhyTNAxLziaHjGYDmPkOfXUovWB+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if EdunhyTNAxLziaHjGYDmPkOfXUovWF==EdunhyTNAxLziaHjGYDmPkOfXUovel:sys.exit()
  EdunhyTNAxLziaHjGYDmPkOfXUovWp =[]
  EdunhyTNAxLziaHjGYDmPkOfXUovWl =[]
  EdunhyTNAxLziaHjGYDmPkOfXUovWM=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_M3u_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUoveR)
  if os.path.isfile(EdunhyTNAxLziaHjGYDmPkOfXUovWM):os.remove(EdunhyTNAxLziaHjGYDmPkOfXUovWM)
  if EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all':
   EdunhyTNAxLziaHjGYDmPkOfXUovWM=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_M3u_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUovel)
   if xbmcvfs.exists(EdunhyTNAxLziaHjGYDmPkOfXUovWM):
    if xbmcvfs.delete(EdunhyTNAxLziaHjGYDmPkOfXUovWM)==EdunhyTNAxLziaHjGYDmPkOfXUovel:
     EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   EdunhyTNAxLziaHjGYDmPkOfXUovWV=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_M3u_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUovel)
   if xbmcvfs.exists(EdunhyTNAxLziaHjGYDmPkOfXUovWV):
    EdunhyTNAxLziaHjGYDmPkOfXUovWR=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_M3u_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUoveR)
    xbmcvfs.copy(EdunhyTNAxLziaHjGYDmPkOfXUovWV,EdunhyTNAxLziaHjGYDmPkOfXUovWR)
  if(EdunhyTNAxLziaHjGYDmPkOfXUovWe=='wavve' or EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all')and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVE:
   EdunhyTNAxLziaHjGYDmPkOfXUovWQ=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_ChannelList_Wavve(exceptGroup=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_EexceptGroup_Wavve())
   if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)!=0:EdunhyTNAxLziaHjGYDmPkOfXUovWp.extend(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_log('wavve cnt ----> '+EdunhyTNAxLziaHjGYDmPkOfXUoves(EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)))
  if(EdunhyTNAxLziaHjGYDmPkOfXUovWe=='tving' or EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all')and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONTVING:
   EdunhyTNAxLziaHjGYDmPkOfXUovWQ=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_ChannelList_Tving()
   if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)!=0:EdunhyTNAxLziaHjGYDmPkOfXUovWp.extend(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_log('tving cnt ----> '+EdunhyTNAxLziaHjGYDmPkOfXUoves(EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)))
  if(EdunhyTNAxLziaHjGYDmPkOfXUovWe=='spotv' or EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all')and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSPOTV:
   EdunhyTNAxLziaHjGYDmPkOfXUovWQ=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_ChannelList_Spotv(payyn=EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSPOTVPAY)
   if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)!=0:EdunhyTNAxLziaHjGYDmPkOfXUovWp.extend(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_log('spotv cnt ----> '+EdunhyTNAxLziaHjGYDmPkOfXUoves(EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)))
  if(EdunhyTNAxLziaHjGYDmPkOfXUovWe=='seezn' or EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all')and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZN:
   EdunhyTNAxLziaHjGYDmPkOfXUovWQ=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_ChannelList_Seezn(exceptGroup=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_EexceptGroup_Seezn())
   if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)!=0:EdunhyTNAxLziaHjGYDmPkOfXUovWp.extend(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_log('seezn cnt ----> '+EdunhyTNAxLziaHjGYDmPkOfXUoves(EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)))
  if(EdunhyTNAxLziaHjGYDmPkOfXUovWe=='samsung' or EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all')and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSAMSUNG:
   EdunhyTNAxLziaHjGYDmPkOfXUovWs=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_BaseInfo_Samsungtv()
   EdunhyTNAxLziaHjGYDmPkOfXUovWQ=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_ChannelList_Samsungtv(EdunhyTNAxLziaHjGYDmPkOfXUovWs,exceptGroup=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_EexceptGroup_Samsungtv())
   if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)!=0:EdunhyTNAxLziaHjGYDmPkOfXUovWp.extend(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_log('samsungtv cnt ----> '+EdunhyTNAxLziaHjGYDmPkOfXUoves(EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWQ)))
  if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWp)==0 and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_CUSTOM_LIST==[]:
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti(__language__(30909).encode('utf8'))
   return
  for EdunhyTNAxLziaHjGYDmPkOfXUovWg in EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.INIT_GENRESORT:
   for EdunhyTNAxLziaHjGYDmPkOfXUovWI in EdunhyTNAxLziaHjGYDmPkOfXUovWp:
    if EdunhyTNAxLziaHjGYDmPkOfXUovWI['genrenm']==EdunhyTNAxLziaHjGYDmPkOfXUovWg:
     EdunhyTNAxLziaHjGYDmPkOfXUovWl.append(EdunhyTNAxLziaHjGYDmPkOfXUovWI)
  for EdunhyTNAxLziaHjGYDmPkOfXUovWI in EdunhyTNAxLziaHjGYDmPkOfXUovWp:
   if EdunhyTNAxLziaHjGYDmPkOfXUovWI['genrenm']not in EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.INIT_GENRESORT:
    EdunhyTNAxLziaHjGYDmPkOfXUovWl.append(EdunhyTNAxLziaHjGYDmPkOfXUovWI)
  try:
   if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovWp)>0:
    EdunhyTNAxLziaHjGYDmPkOfXUovWM=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_M3u_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUoveR)
    if os.path.isfile(EdunhyTNAxLziaHjGYDmPkOfXUovWM):
     fp=EdunhyTNAxLziaHjGYDmPkOfXUoveg(EdunhyTNAxLziaHjGYDmPkOfXUovWM,'a',-1,'utf-8')
    else:
     fp=EdunhyTNAxLziaHjGYDmPkOfXUoveg(EdunhyTNAxLziaHjGYDmPkOfXUovWM,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for EdunhyTNAxLziaHjGYDmPkOfXUovWr in EdunhyTNAxLziaHjGYDmPkOfXUovWl:
     EdunhyTNAxLziaHjGYDmPkOfXUovWC =EdunhyTNAxLziaHjGYDmPkOfXUovWr['channelid']
     EdunhyTNAxLziaHjGYDmPkOfXUovWc =EdunhyTNAxLziaHjGYDmPkOfXUovWr['channelnm']
     EdunhyTNAxLziaHjGYDmPkOfXUovWb=EdunhyTNAxLziaHjGYDmPkOfXUovWr['channelimg']
     EdunhyTNAxLziaHjGYDmPkOfXUovWJ =EdunhyTNAxLziaHjGYDmPkOfXUovWr['ott']
     EdunhyTNAxLziaHjGYDmPkOfXUovWq ='%s.%s'%(EdunhyTNAxLziaHjGYDmPkOfXUovWC,EdunhyTNAxLziaHjGYDmPkOfXUovWJ)
     EdunhyTNAxLziaHjGYDmPkOfXUovWt=EdunhyTNAxLziaHjGYDmPkOfXUovWr['genrenm']
     if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_DISPLAYNM:
      EdunhyTNAxLziaHjGYDmPkOfXUovWc='%s (%s)'%(EdunhyTNAxLziaHjGYDmPkOfXUovWc,EdunhyTNAxLziaHjGYDmPkOfXUovWJ)
     if EdunhyTNAxLziaHjGYDmPkOfXUovWt=='라디오/음악':
      EdunhyTNAxLziaHjGYDmPkOfXUovWw='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(EdunhyTNAxLziaHjGYDmPkOfXUovWq,EdunhyTNAxLziaHjGYDmPkOfXUovWc,EdunhyTNAxLziaHjGYDmPkOfXUovWt,EdunhyTNAxLziaHjGYDmPkOfXUovWb,EdunhyTNAxLziaHjGYDmPkOfXUovWc)
     else:
      EdunhyTNAxLziaHjGYDmPkOfXUovWw='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(EdunhyTNAxLziaHjGYDmPkOfXUovWq,EdunhyTNAxLziaHjGYDmPkOfXUovWc,EdunhyTNAxLziaHjGYDmPkOfXUovWt,EdunhyTNAxLziaHjGYDmPkOfXUovWb,EdunhyTNAxLziaHjGYDmPkOfXUovWc)
     if EdunhyTNAxLziaHjGYDmPkOfXUovWJ=='wavve':
      EdunhyTNAxLziaHjGYDmPkOfXUovWK ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(EdunhyTNAxLziaHjGYDmPkOfXUovWC)
     elif EdunhyTNAxLziaHjGYDmPkOfXUovWJ=='tving':
      EdunhyTNAxLziaHjGYDmPkOfXUovWK ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(EdunhyTNAxLziaHjGYDmPkOfXUovWC)
     elif EdunhyTNAxLziaHjGYDmPkOfXUovWJ=='spotv':
      EdunhyTNAxLziaHjGYDmPkOfXUovWK ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(EdunhyTNAxLziaHjGYDmPkOfXUovWC)
     elif EdunhyTNAxLziaHjGYDmPkOfXUovWJ=='seezn':
      EdunhyTNAxLziaHjGYDmPkOfXUovWS='128' if EdunhyTNAxLziaHjGYDmPkOfXUovWt=='라디오/음악' else '4000'
      EdunhyTNAxLziaHjGYDmPkOfXUovWK ='plugin://plugin.video.seeznm/?mode=LIVE&mediacode=%s&bitrate=%s\n'%(EdunhyTNAxLziaHjGYDmPkOfXUovWC,EdunhyTNAxLziaHjGYDmPkOfXUovWS)
     if EdunhyTNAxLziaHjGYDmPkOfXUovWJ=='samsung':
      EdunhyTNAxLziaHjGYDmPkOfXUovWK ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(EdunhyTNAxLziaHjGYDmPkOfXUovWC)
     fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovWw)
     fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovWK)
    fp.close()
  except:
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti(__language__(30910).encode('utf8'))
   return
  try:
   if(EdunhyTNAxLziaHjGYDmPkOfXUovWe=='custom' or EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all')and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_CUSTOM_LIST!=[]:
    EdunhyTNAxLziaHjGYDmPkOfXUovWM=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_M3u_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUoveR)
    if os.path.isfile(EdunhyTNAxLziaHjGYDmPkOfXUovWM):
     fp=EdunhyTNAxLziaHjGYDmPkOfXUoveg(EdunhyTNAxLziaHjGYDmPkOfXUovWM,'a',-1,'utf-8')
    else:
     fp=EdunhyTNAxLziaHjGYDmPkOfXUoveg(EdunhyTNAxLziaHjGYDmPkOfXUovWM,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for EdunhyTNAxLziaHjGYDmPkOfXUovMF in EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_CUSTOM_LIST:
     EdunhyTNAxLziaHjGYDmPkOfXUovMW=EdunhyTNAxLziaHjGYDmPkOfXUovFB.customEpg_FileRead(EdunhyTNAxLziaHjGYDmPkOfXUovMF)
     for EdunhyTNAxLziaHjGYDmPkOfXUovMe in EdunhyTNAxLziaHjGYDmPkOfXUovMW:
      EdunhyTNAxLziaHjGYDmPkOfXUovMe=EdunhyTNAxLziaHjGYDmPkOfXUovMe.strip()
      if EdunhyTNAxLziaHjGYDmPkOfXUovMe not in['','#EXTM3U']:
       fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMe+'\n')
   fp.close()
  except:
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti(__language__(30910).encode('utf8'))
   return
  EdunhyTNAxLziaHjGYDmPkOfXUovWV=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_M3u_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUoveR)
  EdunhyTNAxLziaHjGYDmPkOfXUovWR=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_M3u_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUovel)
  if xbmcvfs.copy(EdunhyTNAxLziaHjGYDmPkOfXUovWV,EdunhyTNAxLziaHjGYDmPkOfXUovWR):
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti((EdunhyTNAxLziaHjGYDmPkOfXUovWB+' '+__language__(30908)).encode('utf8'))
  else:
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti(__language__(30910).encode('utf-8'))
 def customEpg_FileList(EdunhyTNAxLziaHjGYDmPkOfXUovFB):
  EdunhyTNAxLziaHjGYDmPkOfXUovMB=[]
  if __addon__.getSetting('custom01on')=='true':EdunhyTNAxLziaHjGYDmPkOfXUovMB.append(__addon__.getSetting('custom01nm'))
  if __addon__.getSetting('custom02on')=='true':EdunhyTNAxLziaHjGYDmPkOfXUovMB.append(__addon__.getSetting('custom02nm'))
  if __addon__.getSetting('custom03on')=='true':EdunhyTNAxLziaHjGYDmPkOfXUovMB.append(__addon__.getSetting('custom03nm'))
  if __addon__.getSetting('custom04on')=='true':EdunhyTNAxLziaHjGYDmPkOfXUovMB.append(__addon__.getSetting('custom04nm'))
  if __addon__.getSetting('custom05on')=='true':EdunhyTNAxLziaHjGYDmPkOfXUovMB.append(__addon__.getSetting('custom05nm'))
  return EdunhyTNAxLziaHjGYDmPkOfXUovMB
 def customEpg_FileRead(EdunhyTNAxLziaHjGYDmPkOfXUovFB,source_filename):
  try:
   EdunhyTNAxLziaHjGYDmPkOfXUovMp=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
   if os.path.isfile(EdunhyTNAxLziaHjGYDmPkOfXUovMp):os.remove(EdunhyTNAxLziaHjGYDmPkOfXUovMp)
   xbmcvfs.copy(source_filename,EdunhyTNAxLziaHjGYDmPkOfXUovMp)
   fp=EdunhyTNAxLziaHjGYDmPkOfXUoveg(EdunhyTNAxLziaHjGYDmPkOfXUovMp,'r',-1,'utf-8')
   EdunhyTNAxLziaHjGYDmPkOfXUovMl=fp.readlines()
  except:
   return[]
  return EdunhyTNAxLziaHjGYDmPkOfXUovMl
 def dp_Make_Epg(EdunhyTNAxLziaHjGYDmPkOfXUovFB,args):
  EdunhyTNAxLziaHjGYDmPkOfXUovWe=args.get('sType')
  EdunhyTNAxLziaHjGYDmPkOfXUovWB=args.get('sName')
  EdunhyTNAxLziaHjGYDmPkOfXUovMV=args.get('sNoti')
  if EdunhyTNAxLziaHjGYDmPkOfXUovMV!='N':
   EdunhyTNAxLziaHjGYDmPkOfXUovFQ=xbmcgui.Dialog()
   EdunhyTNAxLziaHjGYDmPkOfXUovWF=EdunhyTNAxLziaHjGYDmPkOfXUovFQ.yesno((EdunhyTNAxLziaHjGYDmPkOfXUovWB+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if EdunhyTNAxLziaHjGYDmPkOfXUovWF==EdunhyTNAxLziaHjGYDmPkOfXUovel:sys.exit()
  EdunhyTNAxLziaHjGYDmPkOfXUovMR=[]
  EdunhyTNAxLziaHjGYDmPkOfXUovMQ=[]
  if(EdunhyTNAxLziaHjGYDmPkOfXUovWe=='wavve' or EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all')and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVE:
   EdunhyTNAxLziaHjGYDmPkOfXUovMs,EdunhyTNAxLziaHjGYDmPkOfXUovMg=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_EexceptGroup_Wavve())
   if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovMg)!=0:
    EdunhyTNAxLziaHjGYDmPkOfXUovMR.extend(EdunhyTNAxLziaHjGYDmPkOfXUovMs)
    EdunhyTNAxLziaHjGYDmPkOfXUovMQ.extend(EdunhyTNAxLziaHjGYDmPkOfXUovMg)
  if(EdunhyTNAxLziaHjGYDmPkOfXUovWe=='tving' or EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all')and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONTVING:
   EdunhyTNAxLziaHjGYDmPkOfXUovMs,EdunhyTNAxLziaHjGYDmPkOfXUovMg=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_EpgInfo_Tving()
   if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovMg)!=0:
    EdunhyTNAxLziaHjGYDmPkOfXUovMR.extend(EdunhyTNAxLziaHjGYDmPkOfXUovMs)
    EdunhyTNAxLziaHjGYDmPkOfXUovMQ.extend(EdunhyTNAxLziaHjGYDmPkOfXUovMg)
  if(EdunhyTNAxLziaHjGYDmPkOfXUovWe=='spotv' or EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all')and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSPOTV:
   EdunhyTNAxLziaHjGYDmPkOfXUovMs,EdunhyTNAxLziaHjGYDmPkOfXUovMg=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_EpgInfo_Spotv(payyn=EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSPOTVPAY)
   if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovMg)!=0:
    EdunhyTNAxLziaHjGYDmPkOfXUovMR.extend(EdunhyTNAxLziaHjGYDmPkOfXUovMs)
    EdunhyTNAxLziaHjGYDmPkOfXUovMQ.extend(EdunhyTNAxLziaHjGYDmPkOfXUovMg)
  if(EdunhyTNAxLziaHjGYDmPkOfXUovWe=='seezn' or EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all')and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZN:
   EdunhyTNAxLziaHjGYDmPkOfXUovMs,EdunhyTNAxLziaHjGYDmPkOfXUovMg=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_EpgInfo_Seezn(exceptGroup=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_EexceptGroup_Seezn())
   if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovMg)!=0:
    EdunhyTNAxLziaHjGYDmPkOfXUovMR.extend(EdunhyTNAxLziaHjGYDmPkOfXUovMs)
    EdunhyTNAxLziaHjGYDmPkOfXUovMQ.extend(EdunhyTNAxLziaHjGYDmPkOfXUovMg)
  if(EdunhyTNAxLziaHjGYDmPkOfXUovWe=='samsung' or EdunhyTNAxLziaHjGYDmPkOfXUovWe=='all')and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSAMSUNG:
   EdunhyTNAxLziaHjGYDmPkOfXUovWs=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_BaseInfo_Samsungtv()
   EdunhyTNAxLziaHjGYDmPkOfXUovMs,EdunhyTNAxLziaHjGYDmPkOfXUovMg=EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_EpgInfo_Samsungtv(EdunhyTNAxLziaHjGYDmPkOfXUovWs,exceptGroup=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_EexceptGroup_Samsungtv())
   if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovMg)!=0:
    EdunhyTNAxLziaHjGYDmPkOfXUovMR.extend(EdunhyTNAxLziaHjGYDmPkOfXUovMs)
    EdunhyTNAxLziaHjGYDmPkOfXUovMQ.extend(EdunhyTNAxLziaHjGYDmPkOfXUovMg)
  if EdunhyTNAxLziaHjGYDmPkOfXUoveQ(EdunhyTNAxLziaHjGYDmPkOfXUovMQ)==0:
   if EdunhyTNAxLziaHjGYDmPkOfXUovMV!='N':EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   EdunhyTNAxLziaHjGYDmPkOfXUovWM=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_Epg_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUoveR)
   fp=EdunhyTNAxLziaHjGYDmPkOfXUoveg(EdunhyTNAxLziaHjGYDmPkOfXUovWM,'w',-1,'utf-8')
   EdunhyTNAxLziaHjGYDmPkOfXUovMI='<?xml version="1.0" encoding="UTF-8"?>\n'
   EdunhyTNAxLziaHjGYDmPkOfXUovMr='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   EdunhyTNAxLziaHjGYDmPkOfXUovMC='<tv generator-info-name="boritv_epg">\n\n'
   EdunhyTNAxLziaHjGYDmPkOfXUovMc='\n</tv>\n'
   fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMI)
   fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMr)
   fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMC)
   for EdunhyTNAxLziaHjGYDmPkOfXUovMb in EdunhyTNAxLziaHjGYDmPkOfXUovMR:
    EdunhyTNAxLziaHjGYDmPkOfXUovMJ='  <channel id="%s.%s">\n' %(EdunhyTNAxLziaHjGYDmPkOfXUovMb.get('channelid'),EdunhyTNAxLziaHjGYDmPkOfXUovMb.get('ott'))
    EdunhyTNAxLziaHjGYDmPkOfXUovMq='    <display-name>%s</display-name>\n'%(EdunhyTNAxLziaHjGYDmPkOfXUovMb.get('channelnm'))
    EdunhyTNAxLziaHjGYDmPkOfXUovMt='    <icon src="%s" />\n' %(EdunhyTNAxLziaHjGYDmPkOfXUovMb.get('channelimg'))
    EdunhyTNAxLziaHjGYDmPkOfXUovMw='  </channel>\n\n'
    fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMJ)
    fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMq)
    fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMt)
    fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMw)
   for EdunhyTNAxLziaHjGYDmPkOfXUovMb in EdunhyTNAxLziaHjGYDmPkOfXUovMQ:
    EdunhyTNAxLziaHjGYDmPkOfXUovMJ='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(EdunhyTNAxLziaHjGYDmPkOfXUovMb.get('startTime'),EdunhyTNAxLziaHjGYDmPkOfXUovMb.get('endTime'),EdunhyTNAxLziaHjGYDmPkOfXUovMb.get('channelid'),EdunhyTNAxLziaHjGYDmPkOfXUovMb.get('ott'))
    EdunhyTNAxLziaHjGYDmPkOfXUovMq='    <title lang="kr">%s</title>\n' %(EdunhyTNAxLziaHjGYDmPkOfXUovMb.get('title'))
    EdunhyTNAxLziaHjGYDmPkOfXUovMt='  </programme>\n\n'
    fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMJ)
    fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMq)
    fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMt)
   fp.write(EdunhyTNAxLziaHjGYDmPkOfXUovMc)
   fp.close()
  except:
   if EdunhyTNAxLziaHjGYDmPkOfXUovMV!='N':EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti(__language__(30910).encode('utf8'))
   return
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.MakeEpg_SaveJson()
  EdunhyTNAxLziaHjGYDmPkOfXUovWV=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_Epg_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUoveR)
  EdunhyTNAxLziaHjGYDmPkOfXUovWR=EdunhyTNAxLziaHjGYDmPkOfXUovFB.make_Epg_Filename(tempyn=EdunhyTNAxLziaHjGYDmPkOfXUovel)
  if xbmcvfs.copy(EdunhyTNAxLziaHjGYDmPkOfXUovWV,EdunhyTNAxLziaHjGYDmPkOfXUovWR):
   if EdunhyTNAxLziaHjGYDmPkOfXUovMV!='N':EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti((EdunhyTNAxLziaHjGYDmPkOfXUovWB+' '+__language__(30912)).encode('utf8'))
  else:
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_AUTORESTART:
    EdunhyTNAxLziaHjGYDmPkOfXUovMK=xbmcaddon.Addon('pvr.iptvsimple')
    EdunhyTNAxLziaHjGYDmPkOfXUovMK.setSetting('anything','anything')
  except:
   EdunhyTNAxLziaHjGYDmPkOfXUoveV 
 def make_EexceptGroup_Wavve(EdunhyTNAxLziaHjGYDmPkOfXUovFB):
  EdunhyTNAxLziaHjGYDmPkOfXUovMS=[]
  if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVERADIO==EdunhyTNAxLziaHjGYDmPkOfXUovel:
   EdunhyTNAxLziaHjGYDmPkOfXUovMS.append('라디오/음악')
  if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVEHOME==EdunhyTNAxLziaHjGYDmPkOfXUovel:
   EdunhyTNAxLziaHjGYDmPkOfXUovMS.append('홈쇼핑')
  if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONRELIGION==EdunhyTNAxLziaHjGYDmPkOfXUovel:
   EdunhyTNAxLziaHjGYDmPkOfXUovMS.append('종교')
  return EdunhyTNAxLziaHjGYDmPkOfXUovMS
 def make_EexceptGroup_Seezn(EdunhyTNAxLziaHjGYDmPkOfXUovFB):
  EdunhyTNAxLziaHjGYDmPkOfXUovMS=[]
  if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZNRADIO==EdunhyTNAxLziaHjGYDmPkOfXUovel:
   EdunhyTNAxLziaHjGYDmPkOfXUovMS.append('라디오/음악')
  if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZNHOME==EdunhyTNAxLziaHjGYDmPkOfXUovel:
   EdunhyTNAxLziaHjGYDmPkOfXUovMS.append('홈쇼핑')
  if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZNPAY==EdunhyTNAxLziaHjGYDmPkOfXUovel:
   EdunhyTNAxLziaHjGYDmPkOfXUovMS.append('won')
  return EdunhyTNAxLziaHjGYDmPkOfXUovMS
 def make_EexceptGroup_Samsungtv(EdunhyTNAxLziaHjGYDmPkOfXUovFB):
  EdunhyTNAxLziaHjGYDmPkOfXUovMS=[]
  if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSAMSUNGHOME==EdunhyTNAxLziaHjGYDmPkOfXUovel:
   EdunhyTNAxLziaHjGYDmPkOfXUovMS.append('홈쇼핑')
  return EdunhyTNAxLziaHjGYDmPkOfXUovMS
 def get_radio_list(EdunhyTNAxLziaHjGYDmPkOfXUovFB):
  if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVERADIO==EdunhyTNAxLziaHjGYDmPkOfXUovel:return[]
  EdunhyTNAxLziaHjGYDmPkOfXUoveF=[{'broadcastid':'46584','genre':'10'}]
  return EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_ChannelList_WavveExcept(EdunhyTNAxLziaHjGYDmPkOfXUoveF)
 def check_config(EdunhyTNAxLziaHjGYDmPkOfXUovFB):
  EdunhyTNAxLziaHjGYDmPkOfXUoveW=EdunhyTNAxLziaHjGYDmPkOfXUoveR
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVE =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onWavve')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONTVING =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onTvng')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSPOTV =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onSpotv')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZN =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onSeezn')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSAMSUNG =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onSamsung')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVERADIO =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onWavveRadio')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVEHOME =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onWavveHome')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONRELIGION =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onWavveReligion')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSPOTVPAY =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onSpotvPay')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZNPAY =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onSeeznPay')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZNHOME =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onSeeznHome')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZNRADIO =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onSeeznRadio')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSAMSUNGHOME =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('onSamsungHome')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_DISPLAYNM =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('displayOTTnm')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_AUTORESTART =EdunhyTNAxLziaHjGYDmPkOfXUoveR if __addon__.getSetting('autoRestart')=='true' else EdunhyTNAxLziaHjGYDmPkOfXUovel
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_CUSTOM_LIST =EdunhyTNAxLziaHjGYDmPkOfXUovFB.customEpg_FileList()
  if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_FILE_PATH=='' or EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_FILE_NAME=='':EdunhyTNAxLziaHjGYDmPkOfXUoveW=EdunhyTNAxLziaHjGYDmPkOfXUovel
  if EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONWAVVE==EdunhyTNAxLziaHjGYDmPkOfXUovel and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONTVING==EdunhyTNAxLziaHjGYDmPkOfXUovel and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSPOTV==EdunhyTNAxLziaHjGYDmPkOfXUovel and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSEEZN==EdunhyTNAxLziaHjGYDmPkOfXUovel and EdunhyTNAxLziaHjGYDmPkOfXUovFB.M3U_ONSAMSUNG==EdunhyTNAxLziaHjGYDmPkOfXUovel:EdunhyTNAxLziaHjGYDmPkOfXUoveW=EdunhyTNAxLziaHjGYDmPkOfXUovel
  if EdunhyTNAxLziaHjGYDmPkOfXUoveW==EdunhyTNAxLziaHjGYDmPkOfXUovel:
   EdunhyTNAxLziaHjGYDmPkOfXUovFQ=xbmcgui.Dialog()
   EdunhyTNAxLziaHjGYDmPkOfXUovWF=EdunhyTNAxLziaHjGYDmPkOfXUovFQ.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if EdunhyTNAxLziaHjGYDmPkOfXUovWF==EdunhyTNAxLziaHjGYDmPkOfXUoveR:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(EdunhyTNAxLziaHjGYDmPkOfXUovFB):
  EdunhyTNAxLziaHjGYDmPkOfXUoveM={'date_makeepg':EdunhyTNAxLziaHjGYDmPkOfXUovFB.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=EdunhyTNAxLziaHjGYDmPkOfXUoveg(EdunhyTNAxLziaHjGYDmPkOfXUovFe,'w',-1,'utf-8')
   json.dump(EdunhyTNAxLziaHjGYDmPkOfXUoveM,fp)
   fp.close()
  except EdunhyTNAxLziaHjGYDmPkOfXUoveI as exception:
   return
 def boritv_main(EdunhyTNAxLziaHjGYDmPkOfXUovFB):
  EdunhyTNAxLziaHjGYDmPkOfXUoveB=EdunhyTNAxLziaHjGYDmPkOfXUovFB.main_params.get('mode',EdunhyTNAxLziaHjGYDmPkOfXUoveV)
  EdunhyTNAxLziaHjGYDmPkOfXUovFB.check_config()
  if EdunhyTNAxLziaHjGYDmPkOfXUoveB is EdunhyTNAxLziaHjGYDmPkOfXUoveV:
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.dp_Main_List()
  elif EdunhyTNAxLziaHjGYDmPkOfXUoveB=='DEL_M3U':
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.dp_Delete_M3u(EdunhyTNAxLziaHjGYDmPkOfXUovFB.main_params)
  elif EdunhyTNAxLziaHjGYDmPkOfXUoveB=='ADD_M3U':
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.dp_MakeAdd_M3u(EdunhyTNAxLziaHjGYDmPkOfXUovFB.main_params)
  elif EdunhyTNAxLziaHjGYDmPkOfXUoveB=='ADD_EPG':
   EdunhyTNAxLziaHjGYDmPkOfXUovFB.dp_Make_Epg(EdunhyTNAxLziaHjGYDmPkOfXUovFB.main_params)
  else:
   EdunhyTNAxLziaHjGYDmPkOfXUoveV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
