__author__="NightRain"
cAosLhqzafuxQbmFMBpRXDjEGOSNVk=str
cAosLhqzafuxQbmFMBpRXDjEGOSNVg=True
cAosLhqzafuxQbmFMBpRXDjEGOSNVP=False
cAosLhqzafuxQbmFMBpRXDjEGOSNVw=print
cAosLhqzafuxQbmFMBpRXDjEGOSNVT=open
cAosLhqzafuxQbmFMBpRXDjEGOSNVr=Exception
cAosLhqzafuxQbmFMBpRXDjEGOSNWV=int
import json
import time
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 cAosLhqzafuxQbmFMBpRXDjEGOSNVe='ADDON'
except:
 cAosLhqzafuxQbmFMBpRXDjEGOSNVe='SINGLE'
if cAosLhqzafuxQbmFMBpRXDjEGOSNVe=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  cAosLhqzafuxQbmFMBpRXDjEGOSNVn=cAosLhqzafuxQbmFMBpRXDjEGOSNVk(string).encode('utf-8','ignore')
  cAosLhqzafuxQbmFMBpRXDjEGOSNVI=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,cAosLhqzafuxQbmFMBpRXDjEGOSNVn),level=cAosLhqzafuxQbmFMBpRXDjEGOSNVI)
 def addon_getautoepg():
  return cAosLhqzafuxQbmFMBpRXDjEGOSNVg if __addon__.getSetting('autoEpg')=='true' else cAosLhqzafuxQbmFMBpRXDjEGOSNVP
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  cAosLhqzafuxQbmFMBpRXDjEGOSNVw(string)
 def addon_getautoepg():
  return cAosLhqzafuxQbmFMBpRXDjEGOSNVg
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class cAosLhqzafuxQbmFMBpRXDjEGOSNVW():
 def __init__(cAosLhqzafuxQbmFMBpRXDjEGOSNVl):
  cAosLhqzafuxQbmFMBpRXDjEGOSNVl.START_INTERVAL =3000 
  cAosLhqzafuxQbmFMBpRXDjEGOSNVl.INTERVAL =20 
  cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_FILETAGNM ='date_makeepg'
  cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_MAKEDATE ='-' 
  cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_WILL_TM =-1 
 def Get_Now_Datetime(cAosLhqzafuxQbmFMBpRXDjEGOSNVl):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(cAosLhqzafuxQbmFMBpRXDjEGOSNVl):
  cAosLhqzafuxQbmFMBpRXDjEGOSNVd ='-'
  if cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_MAKEDATE=='-':
   try:
    fp=cAosLhqzafuxQbmFMBpRXDjEGOSNVT(addon_epgupdate_confignm(),'r',-1,'utf-8')
    cAosLhqzafuxQbmFMBpRXDjEGOSNVU= json.load(fp)
    fp.close()
    cAosLhqzafuxQbmFMBpRXDjEGOSNVd=cAosLhqzafuxQbmFMBpRXDjEGOSNVU[cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_FILETAGNM]
   except cAosLhqzafuxQbmFMBpRXDjEGOSNVr as exception:
    return 2 
  else:
   cAosLhqzafuxQbmFMBpRXDjEGOSNVd=cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_MAKEDATE
  cAosLhqzafuxQbmFMBpRXDjEGOSNVi =cAosLhqzafuxQbmFMBpRXDjEGOSNVl.Get_Now_Datetime()
  cAosLhqzafuxQbmFMBpRXDjEGOSNVK=(cAosLhqzafuxQbmFMBpRXDjEGOSNVi-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  cAosLhqzafuxQbmFMBpRXDjEGOSNVC =cAosLhqzafuxQbmFMBpRXDjEGOSNVi.strftime('%Y-%m-%d')
  cAosLhqzafuxQbmFMBpRXDjEGOSNVt =cAosLhqzafuxQbmFMBpRXDjEGOSNVi.strftime('%H')
  if cAosLhqzafuxQbmFMBpRXDjEGOSNVd==cAosLhqzafuxQbmFMBpRXDjEGOSNVC: return-1
  if cAosLhqzafuxQbmFMBpRXDjEGOSNVd==cAosLhqzafuxQbmFMBpRXDjEGOSNVK and cAosLhqzafuxQbmFMBpRXDjEGOSNVt=='00':return 30
  return 2
 def MakeEpg_RandomTm(cAosLhqzafuxQbmFMBpRXDjEGOSNVl,mintm):
  cAosLhqzafuxQbmFMBpRXDjEGOSNVH=(mintm*60)+random.randint(0,60)
  cAosLhqzafuxQbmFMBpRXDjEGOSNVi =cAosLhqzafuxQbmFMBpRXDjEGOSNVl.Get_Now_Datetime()
  cAosLhqzafuxQbmFMBpRXDjEGOSNVY =(cAosLhqzafuxQbmFMBpRXDjEGOSNVi+datetime.timedelta(seconds=cAosLhqzafuxQbmFMBpRXDjEGOSNVH)).strftime('%Y%m%d%H%M%S')
  return cAosLhqzafuxQbmFMBpRXDjEGOSNWV(cAosLhqzafuxQbmFMBpRXDjEGOSNVY)
 def MakeEpg_SaveJson(cAosLhqzafuxQbmFMBpRXDjEGOSNVl):
  cAosLhqzafuxQbmFMBpRXDjEGOSNVU={cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_FILETAGNM:cAosLhqzafuxQbmFMBpRXDjEGOSNVl.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=cAosLhqzafuxQbmFMBpRXDjEGOSNVT(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(cAosLhqzafuxQbmFMBpRXDjEGOSNVU,fp)
   fp.close()
  except cAosLhqzafuxQbmFMBpRXDjEGOSNVr as exception:
   return
 def service_run(cAosLhqzafuxQbmFMBpRXDjEGOSNVl):
  if addon_getautoepg()==cAosLhqzafuxQbmFMBpRXDjEGOSNVP:return
  cAosLhqzafuxQbmFMBpRXDjEGOSNVy=cAosLhqzafuxQbmFMBpRXDjEGOSNVl.MakeEpg_DateCheck()
  if cAosLhqzafuxQbmFMBpRXDjEGOSNVy<0:
   return
  if cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_WILL_TM<0:
   cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_WILL_TM=cAosLhqzafuxQbmFMBpRXDjEGOSNVl.MakeEpg_RandomTm(cAosLhqzafuxQbmFMBpRXDjEGOSNVy)
   addon_log('EPG_WILL_TM --> '+cAosLhqzafuxQbmFMBpRXDjEGOSNVk(cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_WILL_TM))
  else:
   cAosLhqzafuxQbmFMBpRXDjEGOSNVC=cAosLhqzafuxQbmFMBpRXDjEGOSNVl.Get_Now_Datetime()
   if cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_WILL_TM<cAosLhqzafuxQbmFMBpRXDjEGOSNWV(cAosLhqzafuxQbmFMBpRXDjEGOSNVC.strftime('%Y%m%d%H%M%S')):
    addon_log('make epg')
    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
    cAosLhqzafuxQbmFMBpRXDjEGOSNVl.MakeEpg_SaveJson()
    cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_MAKEDATE=cAosLhqzafuxQbmFMBpRXDjEGOSNVC.strftime('%Y-%m-%d')
    cAosLhqzafuxQbmFMBpRXDjEGOSNVl.EPG_WILL_TM =-1
   else:
    pass
  pass
if __name__=="__main__":
 addon_log('__main__')
 cAosLhqzafuxQbmFMBpRXDjEGOSNVv=cAosLhqzafuxQbmFMBpRXDjEGOSNVW()
 time.sleep(3)
 while cAosLhqzafuxQbmFMBpRXDjEGOSNVg:
  time.sleep(cAosLhqzafuxQbmFMBpRXDjEGOSNVv.INTERVAL)
  cAosLhqzafuxQbmFMBpRXDjEGOSNVv.service_run()
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
