__author__="NightRain"
qUlcKQTxLbEICkPmMjsSoeytYapWvd=str
qUlcKQTxLbEICkPmMjsSoeytYapWvi=True
qUlcKQTxLbEICkPmMjsSoeytYapWvG=False
qUlcKQTxLbEICkPmMjsSoeytYapWvh=print
qUlcKQTxLbEICkPmMjsSoeytYapWvg=open
qUlcKQTxLbEICkPmMjsSoeytYapWvn=Exception
qUlcKQTxLbEICkPmMjsSoeytYapWOv=int
import json
import time
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 qUlcKQTxLbEICkPmMjsSoeytYapWvR='ADDON'
except:
 qUlcKQTxLbEICkPmMjsSoeytYapWvR='SINGLE'
if qUlcKQTxLbEICkPmMjsSoeytYapWvR=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  qUlcKQTxLbEICkPmMjsSoeytYapWvA=qUlcKQTxLbEICkPmMjsSoeytYapWvd(string).encode('utf-8','ignore')
  qUlcKQTxLbEICkPmMjsSoeytYapWvz=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,qUlcKQTxLbEICkPmMjsSoeytYapWvA),level=qUlcKQTxLbEICkPmMjsSoeytYapWvz)
 def addon_getautoepg():
  return qUlcKQTxLbEICkPmMjsSoeytYapWvi if __addon__.getSetting('autoEpg')=='true' else qUlcKQTxLbEICkPmMjsSoeytYapWvG
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  qUlcKQTxLbEICkPmMjsSoeytYapWvh(string)
 def addon_getautoepg():
  return qUlcKQTxLbEICkPmMjsSoeytYapWvi
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class qUlcKQTxLbEICkPmMjsSoeytYapWvO():
 def __init__(qUlcKQTxLbEICkPmMjsSoeytYapWvV):
  qUlcKQTxLbEICkPmMjsSoeytYapWvV.START_INTERVAL =3000 
  qUlcKQTxLbEICkPmMjsSoeytYapWvV.INTERVAL =20 
  qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_FILETAGNM ='date_makeepg'
  qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_MAKEDATE ='-' 
  qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_WILL_TM =-1 
 def Get_Now_Datetime(qUlcKQTxLbEICkPmMjsSoeytYapWvV):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(qUlcKQTxLbEICkPmMjsSoeytYapWvV):
  qUlcKQTxLbEICkPmMjsSoeytYapWvN ='-'
  if qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_MAKEDATE=='-':
   try:
    fp=qUlcKQTxLbEICkPmMjsSoeytYapWvg(addon_epgupdate_confignm(),'r',-1,'utf-8')
    qUlcKQTxLbEICkPmMjsSoeytYapWvB= json.load(fp)
    fp.close()
    qUlcKQTxLbEICkPmMjsSoeytYapWvN=qUlcKQTxLbEICkPmMjsSoeytYapWvB[qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_FILETAGNM]
   except qUlcKQTxLbEICkPmMjsSoeytYapWvn as exception:
    return 2 
  else:
   qUlcKQTxLbEICkPmMjsSoeytYapWvN=qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_MAKEDATE
  qUlcKQTxLbEICkPmMjsSoeytYapWvH =qUlcKQTxLbEICkPmMjsSoeytYapWvV.Get_Now_Datetime()
  qUlcKQTxLbEICkPmMjsSoeytYapWvu=(qUlcKQTxLbEICkPmMjsSoeytYapWvH-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  qUlcKQTxLbEICkPmMjsSoeytYapWvw =qUlcKQTxLbEICkPmMjsSoeytYapWvH.strftime('%Y-%m-%d')
  qUlcKQTxLbEICkPmMjsSoeytYapWvf =qUlcKQTxLbEICkPmMjsSoeytYapWvH.strftime('%H')
  if qUlcKQTxLbEICkPmMjsSoeytYapWvN==qUlcKQTxLbEICkPmMjsSoeytYapWvw: return-1
  if qUlcKQTxLbEICkPmMjsSoeytYapWvN==qUlcKQTxLbEICkPmMjsSoeytYapWvu and qUlcKQTxLbEICkPmMjsSoeytYapWvf=='00':return 30
  return 2
 def MakeEpg_RandomTm(qUlcKQTxLbEICkPmMjsSoeytYapWvV,mintm):
  qUlcKQTxLbEICkPmMjsSoeytYapWvr=(mintm*60)+random.randint(0,60)
  qUlcKQTxLbEICkPmMjsSoeytYapWvH =qUlcKQTxLbEICkPmMjsSoeytYapWvV.Get_Now_Datetime()
  qUlcKQTxLbEICkPmMjsSoeytYapWvJ =(qUlcKQTxLbEICkPmMjsSoeytYapWvH+datetime.timedelta(seconds=qUlcKQTxLbEICkPmMjsSoeytYapWvr)).strftime('%Y%m%d%H%M%S')
  return qUlcKQTxLbEICkPmMjsSoeytYapWOv(qUlcKQTxLbEICkPmMjsSoeytYapWvJ)
 def MakeEpg_SaveJson(qUlcKQTxLbEICkPmMjsSoeytYapWvV):
  qUlcKQTxLbEICkPmMjsSoeytYapWvB={qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_FILETAGNM:qUlcKQTxLbEICkPmMjsSoeytYapWvV.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=qUlcKQTxLbEICkPmMjsSoeytYapWvg(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(qUlcKQTxLbEICkPmMjsSoeytYapWvB,fp)
   fp.close()
  except qUlcKQTxLbEICkPmMjsSoeytYapWvn as exception:
   return
 def service_run(qUlcKQTxLbEICkPmMjsSoeytYapWvV):
  if addon_getautoepg()==qUlcKQTxLbEICkPmMjsSoeytYapWvG:return
  qUlcKQTxLbEICkPmMjsSoeytYapWvD=qUlcKQTxLbEICkPmMjsSoeytYapWvV.MakeEpg_DateCheck()
  if qUlcKQTxLbEICkPmMjsSoeytYapWvD<0:
   return
  if qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_WILL_TM<0:
   qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_WILL_TM=qUlcKQTxLbEICkPmMjsSoeytYapWvV.MakeEpg_RandomTm(qUlcKQTxLbEICkPmMjsSoeytYapWvD)
   addon_log('EPG_WILL_TM --> '+qUlcKQTxLbEICkPmMjsSoeytYapWvd(qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_WILL_TM))
  else:
   qUlcKQTxLbEICkPmMjsSoeytYapWvw=qUlcKQTxLbEICkPmMjsSoeytYapWvV.Get_Now_Datetime()
   if qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_WILL_TM<qUlcKQTxLbEICkPmMjsSoeytYapWOv(qUlcKQTxLbEICkPmMjsSoeytYapWvw.strftime('%Y%m%d%H%M%S')):
    addon_log('make epg')
    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
    qUlcKQTxLbEICkPmMjsSoeytYapWvV.MakeEpg_SaveJson()
    qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_MAKEDATE=qUlcKQTxLbEICkPmMjsSoeytYapWvw.strftime('%Y-%m-%d')
    qUlcKQTxLbEICkPmMjsSoeytYapWvV.EPG_WILL_TM =-1
   else:
    pass
  pass
if __name__=="__main__":
 addon_log('__main__')
 qUlcKQTxLbEICkPmMjsSoeytYapWvX=qUlcKQTxLbEICkPmMjsSoeytYapWvO()
 time.sleep(qUlcKQTxLbEICkPmMjsSoeytYapWvX.START_INTERVAL)
 while qUlcKQTxLbEICkPmMjsSoeytYapWvi:
  time.sleep(qUlcKQTxLbEICkPmMjsSoeytYapWvX.INTERVAL)
  qUlcKQTxLbEICkPmMjsSoeytYapWvX.service_run()
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
