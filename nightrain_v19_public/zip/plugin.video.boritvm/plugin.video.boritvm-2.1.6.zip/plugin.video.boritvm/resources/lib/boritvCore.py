__author__="NightRain"
hVIEkTbeAzvwraQpgPJuLMxKnjWYBX=False
hVIEkTbeAzvwraQpgPJuLMxKnjWYBt=object
hVIEkTbeAzvwraQpgPJuLMxKnjWYBC=None
hVIEkTbeAzvwraQpgPJuLMxKnjWYBm=str
hVIEkTbeAzvwraQpgPJuLMxKnjWYBO=Exception
hVIEkTbeAzvwraQpgPJuLMxKnjWYBF=print
hVIEkTbeAzvwraQpgPJuLMxKnjWYBl=True
hVIEkTbeAzvwraQpgPJuLMxKnjWYBy=int
hVIEkTbeAzvwraQpgPJuLMxKnjWYBD=range
hVIEkTbeAzvwraQpgPJuLMxKnjWYBN=len
hVIEkTbeAzvwraQpgPJuLMxKnjWYBS=set
hVIEkTbeAzvwraQpgPJuLMxKnjWYBi=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
hVIEkTbeAzvwraQpgPJuLMxKnjWYXC=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
hVIEkTbeAzvwraQpgPJuLMxKnjWYXm=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':hVIEkTbeAzvwraQpgPJuLMxKnjWYBX,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':hVIEkTbeAzvwraQpgPJuLMxKnjWYBX,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':hVIEkTbeAzvwraQpgPJuLMxKnjWYBX,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':hVIEkTbeAzvwraQpgPJuLMxKnjWYBX,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':hVIEkTbeAzvwraQpgPJuLMxKnjWYBX,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':hVIEkTbeAzvwraQpgPJuLMxKnjWYBX,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class hVIEkTbeAzvwraQpgPJuLMxKnjWYXt(hVIEkTbeAzvwraQpgPJuLMxKnjWYBt):
 def __init__(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_WAVVE ='https://apis.wavve.com'
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_TVING ='https://api.tving.com'
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_TVINGIMG ='https://image.tving.com'
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_SPOTV ='https://www.spotvnow.co.kr'
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_SEEZN ='https://api.seezntv.com'
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.HTTPTAG ='https://'
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.LIMIT_WAVVE =200
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.LIMIT_TVING =60
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.LIMIT_TVINGEPG=20 
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.APPVERSION ='91.0.4472.124' 
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.DEVICEMODEL ='Chrome' 
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.OSTYPE ='Windows' 
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.OSVERSION ='NT 10.0' 
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.SEEZN_HEADER ={'X-APP-VERSION':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.APPVERSION,'X-DEVICE-MODEL':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.DEVICEMODEL,'X-OS-TYPE':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.OSTYPE,'X-OS-VERSION':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.OSVERSION,}
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.DEFAULT_HEADER={'user-agent':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.USER_AGENT}
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.SLEEP_TIME =0.2
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.INIT_GENRESORT=MASTER_GENRE
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,jobtype,hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,redirects=hVIEkTbeAzvwraQpgPJuLMxKnjWYBX):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXl=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.DEFAULT_HEADER
  if headers:hVIEkTbeAzvwraQpgPJuLMxKnjWYXl.update(headers)
  if jobtype=='Get':
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXy=requests.get(hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,params=params,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYXl,cookies=cookies,allow_redirects=redirects)
  else:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXy=requests.post(hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,data=payload,params=params,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYXl,cookies=cookies,allow_redirects=redirects)
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXy
 def Get_DefaultParams_Wavve(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXD={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXD
 def Get_DefaultParams_Tving(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXD={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXD
 def Get_Now_Datetime(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,in_text):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXS=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXS
 def Get_ChannelList_Wavve(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,exceptGroup=[]):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi =[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXf=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_ChannelImg_Wavve()
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_WAVVE+'/cf/live/recommend-channels'
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXD={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXD.update(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_DefaultParams_Wavve())
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYXD,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
   if not('celllist' in hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['cell_toplist']):return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXc=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['cell_toplist']['celllist']
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXc:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXH=hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['contentid']
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXd=hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['title_list'][0]['text']
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXH in hVIEkTbeAzvwraQpgPJuLMxKnjWYXf:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXG=hVIEkTbeAzvwraQpgPJuLMxKnjWYXf[hVIEkTbeAzvwraQpgPJuLMxKnjWYXH]
    else:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXG=''
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXo=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_getGenre(hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'wavve')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'channelnm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXd,'channelimg':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.HTTPTAG+hVIEkTbeAzvwraQpgPJuLMxKnjWYXG if hVIEkTbeAzvwraQpgPJuLMxKnjWYXG!='' else '','ott':'wavve','genrenm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXo}
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXo not in exceptGroup:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXi.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi
 def Get_ChannelList_WavveExcept(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,exceptGroup=[]):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi=[]
  if exceptGroup==[]:return[]
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_WAVVE+'/cf/live/recommend-channels'
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in exceptGroup:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXD={'WeekDay':'all','adult':'n','broadcastid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['broadcastid'],'contenttype':'channel','genre':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['genre'],'isrecommend':'y','limit':hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXD.update(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_DefaultParams_Wavve())
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYXD,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC)
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
    if not('celllist' in hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['cell_toplist']):return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXc=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['cell_toplist']['celllist']
    for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXc:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXi.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['contentid'])
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi
 def Get_ChannelImg_Wavve(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtC={}
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtm=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_Now_Datetime()
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtB =hVIEkTbeAzvwraQpgPJuLMxKnjWYtm+datetime.timedelta(hours=3)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_WAVVE+'/live/epgs'
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXD={'limit':hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':hVIEkTbeAzvwraQpgPJuLMxKnjWYtm.strftime('%Y-%m-%d %H:00'),'enddatetime':hVIEkTbeAzvwraQpgPJuLMxKnjWYtB.strftime('%Y-%m-%d %H:00')}
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXD.update(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_DefaultParams_Wavve())
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYXD,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXc=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['list']
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXc:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtC[hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['channelid']]=hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['channelimage']
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYtC
 def Get_ChanneGenrename_Wavve(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,hVIEkTbeAzvwraQpgPJuLMxKnjWYXH):
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_WAVVE+'/live/channels/'+hVIEkTbeAzvwraQpgPJuLMxKnjWYXH
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXD=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_DefaultParams_Wavve()
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYXD,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtO=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['genretext']
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return ''
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYtO
 def Get_ChannelList_Spotv(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,payyn=hVIEkTbeAzvwraQpgPJuLMxKnjWYBl):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi=[]
  try:
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXm:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXH=hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['videoId']
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'channelnm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['name'],'channelimg':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['logo'],'ott':'spotv','genrenm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_getGenre(hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'spotv')}
    if payyn==hVIEkTbeAzvwraQpgPJuLMxKnjWYBl or hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['free']==hVIEkTbeAzvwraQpgPJuLMxKnjWYBl:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXi.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi
 def Get_ChannelList_Tving(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi =[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtF=[]
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_TVING+'/v2/media/lives'
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXD={'pageNo':'1','pageSize':hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXD.update(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_DefaultParams_Tving())
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYXD,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
   if not('result' in hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['body']):return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXc=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['body']['result']
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXc:
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['live_code']=='C44441':continue 
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtF.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['live_code'])
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXf=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_ChannelImg_Tving(hVIEkTbeAzvwraQpgPJuLMxKnjWYtF)
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXc:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXH=hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['live_code']
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXH=='C44441':continue 
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXd=hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['schedule']['channel']['name']['ko']
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXH in hVIEkTbeAzvwraQpgPJuLMxKnjWYXf:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXG=hVIEkTbeAzvwraQpgPJuLMxKnjWYXf[hVIEkTbeAzvwraQpgPJuLMxKnjWYXH]
    else:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXG=''
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'channelnm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXd,'channelimg':hVIEkTbeAzvwraQpgPJuLMxKnjWYXG,'ott':'tving','genrenm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_getGenre(hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'tving')}
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXi.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi
 def Get_timestamp(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,timetype=1):
  ts=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,timetype):
  if timetype=='1':
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtl={'transactionId':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtl={'timestamp':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_timestamp(timetype=1),'transactionId':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_timestamp(timetype=1)+'000000000000001',}
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYtl
 def Get_ChannelList_Seezn(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,exceptGroup=[]):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi =[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYty =hVIEkTbeAzvwraQpgPJuLMxKnjWYBl if 'won' in exceptGroup else hVIEkTbeAzvwraQpgPJuLMxKnjWYBX
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtD =hVIEkTbeAzvwraQpgPJuLMxKnjWYBl if '홈쇼핑' in exceptGroup else hVIEkTbeAzvwraQpgPJuLMxKnjWYBX
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtN=hVIEkTbeAzvwraQpgPJuLMxKnjWYBl if '라디오/음악' in exceptGroup else hVIEkTbeAzvwraQpgPJuLMxKnjWYBX
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_SEEZN+'/svc/menu/app6/api/epg_chlist' 
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXD={'category_id':'2','istest':'0',}
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtS=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Make_Header_Timestamp(timetype='2')
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtS.update(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.SEEZN_HEADER)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYXD,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYtS,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,redirects=hVIEkTbeAzvwraQpgPJuLMxKnjWYBl)
   if hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.status_code!=200:return[]
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
   if hVIEkTbeAzvwraQpgPJuLMxKnjWYXq.get('meta').get('code')!='200':return[]
   hVIEkTbeAzvwraQpgPJuLMxKnjWYti=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq.get('data').get('list')[0].get('list_channel')
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYti:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtf =hVIEkTbeAzvwraQpgPJuLMxKnjWYXs.get('bit_rate_info').split(",")[0]
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXH =hVIEkTbeAzvwraQpgPJuLMxKnjWYXs.get('ch_no')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXo=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_getGenre(hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'seezn')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtU =hVIEkTbeAzvwraQpgPJuLMxKnjWYXs.get('type')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'channelnm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs.get('service_ch_name').replace(',','.'),'channelimg':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs.get('ch_image_list'),'ott':'seezn','genrenm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXo,}
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXH=='404':continue 
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['adult_yn']=='Y':continue 
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['won_yn'] =='Y' and hVIEkTbeAzvwraQpgPJuLMxKnjWYty==hVIEkTbeAzvwraQpgPJuLMxKnjWYBl:continue 
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXo in exceptGroup:continue 
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYtU!='EPG':
     if hVIEkTbeAzvwraQpgPJuLMxKnjWYtD and hVIEkTbeAzvwraQpgPJuLMxKnjWYtU=='SHOP' :continue
     if hVIEkTbeAzvwraQpgPJuLMxKnjWYtN and hVIEkTbeAzvwraQpgPJuLMxKnjWYtU=='AUDIO_MUSIC':continue
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXi.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi
 def Get_EpgInfo_Seezn(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,exceptGroup=[]):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi=[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtR =[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_ChannelList_Seezn(exceptGroup)
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_SEEZN+'/svc/menu/app6/api/epg_proglist' 
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYtq in hVIEkTbeAzvwraQpgPJuLMxKnjWYXi:
    time.sleep(0.3)
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXH =hVIEkTbeAzvwraQpgPJuLMxKnjWYtq.get('channelid')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXD={'ch_no':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH}
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtS=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Make_Header_Timestamp(timetype='2')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtS.update(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.SEEZN_HEADER)
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYXD,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYtS,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,redirects=hVIEkTbeAzvwraQpgPJuLMxKnjWYBl)
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.status_code!=200:return[],[]
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtc=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYtc.get('meta').get('code')!='200':return[],[]
    for hVIEkTbeAzvwraQpgPJuLMxKnjWYts in hVIEkTbeAzvwraQpgPJuLMxKnjWYtc.get('data').get('list'):
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtH=hVIEkTbeAzvwraQpgPJuLMxKnjWYts.get('start_ymd')
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtm=hVIEkTbeAzvwraQpgPJuLMxKnjWYts.get('start_time').replace(':','')
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtB =hVIEkTbeAzvwraQpgPJuLMxKnjWYts.get('end_time').replace(':','')
     if hVIEkTbeAzvwraQpgPJuLMxKnjWYBy(hVIEkTbeAzvwraQpgPJuLMxKnjWYtm)>hVIEkTbeAzvwraQpgPJuLMxKnjWYBy(hVIEkTbeAzvwraQpgPJuLMxKnjWYtB):
      hVIEkTbeAzvwraQpgPJuLMxKnjWYtd=datetime.datetime.strptime(hVIEkTbeAzvwraQpgPJuLMxKnjWYtH,'%Y%m%d')+datetime.timedelta(days=hVIEkTbeAzvwraQpgPJuLMxKnjWYBy(1))
      hVIEkTbeAzvwraQpgPJuLMxKnjWYtd=hVIEkTbeAzvwraQpgPJuLMxKnjWYtd.strftime('%Y%m%d')
     else:
      hVIEkTbeAzvwraQpgPJuLMxKnjWYtd=hVIEkTbeAzvwraQpgPJuLMxKnjWYtH
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'title':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.xmlText(urllib.parse.unquote_plus(hVIEkTbeAzvwraQpgPJuLMxKnjWYts.get('program_name'))),'startTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYtH+hVIEkTbeAzvwraQpgPJuLMxKnjWYtm+'00','endTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYtd+hVIEkTbeAzvwraQpgPJuLMxKnjWYtB+'00','ott':'seezn'}
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtR.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[],[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi,hVIEkTbeAzvwraQpgPJuLMxKnjWYtR
 def make_EpgDatetime_Tving(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,days=2):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtG=[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYto=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_DateList(days=2,dateType='2')
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCX=hVIEkTbeAzvwraQpgPJuLMxKnjWYBy(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYto:
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYCt in hVIEkTbeAzvwraQpgPJuLMxKnjWYBD(8):
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'ndate':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs,'starttm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXC[hVIEkTbeAzvwraQpgPJuLMxKnjWYCt]['starttm'],'endtm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXC[hVIEkTbeAzvwraQpgPJuLMxKnjWYCt]['endtm']}
    hVIEkTbeAzvwraQpgPJuLMxKnjWYCm=hVIEkTbeAzvwraQpgPJuLMxKnjWYBy(hVIEkTbeAzvwraQpgPJuLMxKnjWYXs+hVIEkTbeAzvwraQpgPJuLMxKnjWYXC[hVIEkTbeAzvwraQpgPJuLMxKnjWYCt]['starttm'])
    hVIEkTbeAzvwraQpgPJuLMxKnjWYCB=hVIEkTbeAzvwraQpgPJuLMxKnjWYBy(hVIEkTbeAzvwraQpgPJuLMxKnjWYXs+hVIEkTbeAzvwraQpgPJuLMxKnjWYXC[hVIEkTbeAzvwraQpgPJuLMxKnjWYCt]['endtm'])
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYCX<=hVIEkTbeAzvwraQpgPJuLMxKnjWYCm or(hVIEkTbeAzvwraQpgPJuLMxKnjWYCm<hVIEkTbeAzvwraQpgPJuLMxKnjWYCX and hVIEkTbeAzvwraQpgPJuLMxKnjWYCX<hVIEkTbeAzvwraQpgPJuLMxKnjWYCB):
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtG.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYtG
 def make_DateList(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,days=2,dateType='1'):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYto=[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCO =hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_Now_Datetime()
  if dateType=='1':
   hVIEkTbeAzvwraQpgPJuLMxKnjWYCO=hVIEkTbeAzvwraQpgPJuLMxKnjWYCO-datetime.timedelta(days=1)
  for i in hVIEkTbeAzvwraQpgPJuLMxKnjWYBD(days):
   hVIEkTbeAzvwraQpgPJuLMxKnjWYCF=hVIEkTbeAzvwraQpgPJuLMxKnjWYCO+datetime.timedelta(days=i)
   if dateType=='1':
    hVIEkTbeAzvwraQpgPJuLMxKnjWYto.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYCF.strftime('%Y%m%d'))
   else:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYto.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYCF.strftime('%Y%m%d'))
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYto
 def make_Tving_ChannleGroup(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,hVIEkTbeAzvwraQpgPJuLMxKnjWYtF):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCl=[]
  i=0
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCy=''
  for hVIEkTbeAzvwraQpgPJuLMxKnjWYCD in hVIEkTbeAzvwraQpgPJuLMxKnjWYtF:
   if i==0:hVIEkTbeAzvwraQpgPJuLMxKnjWYCy=hVIEkTbeAzvwraQpgPJuLMxKnjWYCD
   else:hVIEkTbeAzvwraQpgPJuLMxKnjWYCy+=',%s'%(hVIEkTbeAzvwraQpgPJuLMxKnjWYCD)
   i+=1
   if i>=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.LIMIT_TVINGEPG:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYCl.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYCy)
    i=0
    hVIEkTbeAzvwraQpgPJuLMxKnjWYCy=''
  if hVIEkTbeAzvwraQpgPJuLMxKnjWYCy!='':
   hVIEkTbeAzvwraQpgPJuLMxKnjWYCl.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYCy)
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYCl
 def Get_ChannelImg_Tving(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,chid_list):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtC={}
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYCN=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_Now_Datetime().strftime('%Y%m%d')
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtm =hVIEkTbeAzvwraQpgPJuLMxKnjWYXC[6]['starttm'] 
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtB =hVIEkTbeAzvwraQpgPJuLMxKnjWYXC[6]['endtm']
   hVIEkTbeAzvwraQpgPJuLMxKnjWYCl=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_Tving_ChannleGroup(chid_list)
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYCl:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_TVING+'/v2/media/schedules'
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXD={'pageNo':'1','pageSize':hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':hVIEkTbeAzvwraQpgPJuLMxKnjWYCN,'broadcastDate':hVIEkTbeAzvwraQpgPJuLMxKnjWYCN,'startBroadTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYtm,'endBroadTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYtB,'channelCode':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs}
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXD.update(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_DefaultParams_Tving())
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYXD,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC)
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
    if not('result' in hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['body']):return{}
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXc=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['body']['result']
    for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXc:
     for hVIEkTbeAzvwraQpgPJuLMxKnjWYCS in hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['image']:
      if hVIEkTbeAzvwraQpgPJuLMxKnjWYCS['code']=='CAIC0400':hVIEkTbeAzvwraQpgPJuLMxKnjWYtC[hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['channel_code']]=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_TVINGIMG+hVIEkTbeAzvwraQpgPJuLMxKnjWYCS['url']
      elif hVIEkTbeAzvwraQpgPJuLMxKnjWYCS['code']=='CAIC1400':hVIEkTbeAzvwraQpgPJuLMxKnjWYtC[hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['channel_code']]=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_TVINGIMG+hVIEkTbeAzvwraQpgPJuLMxKnjWYCS['url']
      elif hVIEkTbeAzvwraQpgPJuLMxKnjWYCS['code']=='CAIC1900':hVIEkTbeAzvwraQpgPJuLMxKnjWYtC[hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['channel_code']]=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_TVINGIMG+hVIEkTbeAzvwraQpgPJuLMxKnjWYCS['url']
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return{}
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYtC
 def Get_EpgInfo_Spotv(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,days=3,payyn=hVIEkTbeAzvwraQpgPJuLMxKnjWYBl):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi=[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtR =[]
  try:
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXm:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXH =hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['videoId']
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'channelnm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.xmlText(hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['name']),'channelimg':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['logo'],'ott':'spotv','epgtype':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['epgtype'],'epgnm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['epgnm']}
    if payyn==hVIEkTbeAzvwraQpgPJuLMxKnjWYBl or hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['free']==hVIEkTbeAzvwraQpgPJuLMxKnjWYBl:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXi.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[],[]
  '''
  try:
   for now_day in days_list:
    url = self.API_SPOTV + '/api/v2/program/' + now_day
    response = self.callRequestCookies('Get', url, payload=None, params=None, headers=None, cookies=None )
    res_json = json.loads(response.text )
    for i_section in res_json:
     if find_list.get(i_section['channelId'] ) == None: continue
     temp_list = {'channelid' : find_list.get(i_section['channelId'] ) , 'title' : self.xmlText(i_section['title'] ) , 'startTime' : i_section['startTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'endTime' : i_section['endTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'ott' : 'spotv' }
     epg_list.append(temp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  try:
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYtq in hVIEkTbeAzvwraQpgPJuLMxKnjWYXi:
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYtq['epgtype']=='spotvon':
     hVIEkTbeAzvwraQpgPJuLMxKnjWYCi=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_EpgInfo_Spotv_spotvon(hVIEkTbeAzvwraQpgPJuLMxKnjWYtq['channelid'],hVIEkTbeAzvwraQpgPJuLMxKnjWYtq['epgnm'],days)
     if hVIEkTbeAzvwraQpgPJuLMxKnjWYBN(hVIEkTbeAzvwraQpgPJuLMxKnjWYCi)>0:hVIEkTbeAzvwraQpgPJuLMxKnjWYtR.extend(hVIEkTbeAzvwraQpgPJuLMxKnjWYCi)
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYtq['epgtype']=='spotvnet':
     hVIEkTbeAzvwraQpgPJuLMxKnjWYCi=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_EpgInfo_Spotv_spotvnet(hVIEkTbeAzvwraQpgPJuLMxKnjWYtq['channelid'],hVIEkTbeAzvwraQpgPJuLMxKnjWYtq['epgnm'],days)
     if hVIEkTbeAzvwraQpgPJuLMxKnjWYBN(hVIEkTbeAzvwraQpgPJuLMxKnjWYCi)>0:hVIEkTbeAzvwraQpgPJuLMxKnjWYtR.extend(hVIEkTbeAzvwraQpgPJuLMxKnjWYCi)
    time.sleep(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.SLEEP_TIME)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[],[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi,hVIEkTbeAzvwraQpgPJuLMxKnjWYtR
 def Get_EpgInfo_Spotv_spotvon(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,epgnm,days):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtR =[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYto=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_DateList(days=days,dateType='1')
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCf=''
  try:
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYCU in hVIEkTbeAzvwraQpgPJuLMxKnjWYto:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXU='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,hVIEkTbeAzvwraQpgPJuLMxKnjWYCU)
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC)
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
    for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXq:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'title':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.xmlText(hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['title']),'startTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['sch_date'].replace('-','')+hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['sch_hour']).zfill(2)+hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['sch_min']+'00','ott':'spotv'}
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtR.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
    hVIEkTbeAzvwraQpgPJuLMxKnjWYCf=hVIEkTbeAzvwraQpgPJuLMxKnjWYCU
   for i in hVIEkTbeAzvwraQpgPJuLMxKnjWYBD(hVIEkTbeAzvwraQpgPJuLMxKnjWYBN(hVIEkTbeAzvwraQpgPJuLMxKnjWYtR)):
    if i>0:hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i-1]['endTime']=hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i]['startTime']
    if i==hVIEkTbeAzvwraQpgPJuLMxKnjWYBN(hVIEkTbeAzvwraQpgPJuLMxKnjWYtR)-1: hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i]['endTime']=hVIEkTbeAzvwraQpgPJuLMxKnjWYCf+'240000'
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYtR
 def Get_EpgInfo_Spotv_spotvnet(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,epgnm,days):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtR =[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYto=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_DateList(days=days,dateType='1')
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCf=''
  try:
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYCU in hVIEkTbeAzvwraQpgPJuLMxKnjWYto:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXU='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,hVIEkTbeAzvwraQpgPJuLMxKnjWYCU)
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC)
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
    for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXq:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'title':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.xmlText(hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['title']),'startTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['sch_date'].replace('-','')+hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['sch_hour']).zfill(2)+hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['sch_min']+'00','ott':'spotv'}
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtR.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
    hVIEkTbeAzvwraQpgPJuLMxKnjWYCf=hVIEkTbeAzvwraQpgPJuLMxKnjWYCU
   for i in hVIEkTbeAzvwraQpgPJuLMxKnjWYBD(hVIEkTbeAzvwraQpgPJuLMxKnjWYBN(hVIEkTbeAzvwraQpgPJuLMxKnjWYtR)):
    if i>0:hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i-1]['endTime']=hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i]['startTime']
    if i==hVIEkTbeAzvwraQpgPJuLMxKnjWYBN(hVIEkTbeAzvwraQpgPJuLMxKnjWYtR)-1: hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i]['endTime']=hVIEkTbeAzvwraQpgPJuLMxKnjWYCf+'240000'
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYtR
 def Get_EpgInfo_Wavve(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,days=2,exceptGroup=[]):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi =[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtR =[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCO =hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_Now_Datetime()
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCR =hVIEkTbeAzvwraQpgPJuLMxKnjWYCO+datetime.timedelta(hours=-2)
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCq =hVIEkTbeAzvwraQpgPJuLMxKnjWYCO+datetime.timedelta(days=(days-1))
  if hVIEkTbeAzvwraQpgPJuLMxKnjWYBy(hVIEkTbeAzvwraQpgPJuLMxKnjWYCR.strftime('%H'))<=3:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYCc=hVIEkTbeAzvwraQpgPJuLMxKnjWYCR.strftime('%Y-%m-%d 00:00')
  else:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYCc=hVIEkTbeAzvwraQpgPJuLMxKnjWYCR.strftime('%Y-%m-%d %H:00')
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCs =hVIEkTbeAzvwraQpgPJuLMxKnjWYCq.strftime('%Y-%m-%d 24:00')
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_WAVVE+'/live/epgs'
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXD={'limit':hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':hVIEkTbeAzvwraQpgPJuLMxKnjWYCc,'enddatetime':hVIEkTbeAzvwraQpgPJuLMxKnjWYCs}
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXD.update(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_DefaultParams_Wavve())
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYXD,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtc=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['list']
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYtc:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXH =hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['channelid']
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXo=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_getGenre(hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'wavve')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'channelnm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.xmlText(hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['channelname']),'channelimg':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.HTTPTAG+hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['channelimage'],'ott':'wavve'}
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXo not in exceptGroup:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXi.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
    for hVIEkTbeAzvwraQpgPJuLMxKnjWYts in hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['list']:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['channelid'],'title':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.xmlText(hVIEkTbeAzvwraQpgPJuLMxKnjWYts['title']),'startTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYts['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYts['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if hVIEkTbeAzvwraQpgPJuLMxKnjWYXo not in exceptGroup and hVIEkTbeAzvwraQpgPJuLMxKnjWYts['starttime']!=hVIEkTbeAzvwraQpgPJuLMxKnjWYts['endtime']:
      hVIEkTbeAzvwraQpgPJuLMxKnjWYtR.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[],[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCH=hVIEkTbeAzvwraQpgPJuLMxKnjWYBN(hVIEkTbeAzvwraQpgPJuLMxKnjWYtR)
  for i in(hVIEkTbeAzvwraQpgPJuLMxKnjWYBD(1,hVIEkTbeAzvwraQpgPJuLMxKnjWYCH)):
   if hVIEkTbeAzvwraQpgPJuLMxKnjWYBy(hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i-1]['endTime'])+1==hVIEkTbeAzvwraQpgPJuLMxKnjWYBy(hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i]['startTime'])and hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i-1]['channelid']==hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i]['channelid']:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i-1]['endTime']=hVIEkTbeAzvwraQpgPJuLMxKnjWYtR[i]['startTime']
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi,hVIEkTbeAzvwraQpgPJuLMxKnjWYtR
 def Get_EpgInfo_Tving(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,days=2):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi=[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtR =[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCd =[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCG =hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_EpgDatetime_Tving(days=days)
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi =hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_ChannelList_Tving()
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCo=[]
  for i in hVIEkTbeAzvwraQpgPJuLMxKnjWYBD(hVIEkTbeAzvwraQpgPJuLMxKnjWYBN(hVIEkTbeAzvwraQpgPJuLMxKnjWYXi)):
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXi[i]['channelnm']=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.xmlText(hVIEkTbeAzvwraQpgPJuLMxKnjWYXi[i]['channelnm'])
   hVIEkTbeAzvwraQpgPJuLMxKnjWYCo.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYXi[i]['channelid'])
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmX=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_Tving_ChannleGroup(hVIEkTbeAzvwraQpgPJuLMxKnjWYCo)
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_TVING+'/v2/media/schedules'
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYmt in hVIEkTbeAzvwraQpgPJuLMxKnjWYCG:
    for hVIEkTbeAzvwraQpgPJuLMxKnjWYtq in hVIEkTbeAzvwraQpgPJuLMxKnjWYmX:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXD={'pageNo':'1','pageSize':hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':hVIEkTbeAzvwraQpgPJuLMxKnjWYmt['ndate'],'broadcastDate':hVIEkTbeAzvwraQpgPJuLMxKnjWYmt['ndate'],'startBroadTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYmt['starttm'],'endBroadTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYmt['endtm'],'channelCode':hVIEkTbeAzvwraQpgPJuLMxKnjWYtq}
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXD.update(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_DefaultParams_Tving())
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYXD,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC)
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXc=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['body']['result']
     for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXc:
      if 'schedules' not in hVIEkTbeAzvwraQpgPJuLMxKnjWYXs:continue
      if hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['schedules']==hVIEkTbeAzvwraQpgPJuLMxKnjWYBC:continue
      for hVIEkTbeAzvwraQpgPJuLMxKnjWYmC in hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['schedules']:
       hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYmC['schedule_code'],'title':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.xmlText(hVIEkTbeAzvwraQpgPJuLMxKnjWYmC['program']['name']['ko']),'startTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYmC['broadcast_start_time']),'endTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYmC['broadcast_end_time']),'ott':'tving'}
       hVIEkTbeAzvwraQpgPJuLMxKnjWYmB=hVIEkTbeAzvwraQpgPJuLMxKnjWYmC['schedule_code']+hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYmC['broadcast_start_time'])
       if hVIEkTbeAzvwraQpgPJuLMxKnjWYmB in hVIEkTbeAzvwraQpgPJuLMxKnjWYCd:continue
       hVIEkTbeAzvwraQpgPJuLMxKnjWYCd.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYmB)
       hVIEkTbeAzvwraQpgPJuLMxKnjWYtR.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
     time.sleep(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.SLEEP_TIME)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[],[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi,hVIEkTbeAzvwraQpgPJuLMxKnjWYtR
 def Get_BaseInfo_Samsungtv(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmO={}
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_SAMSUNGTV
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC)
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYmF in hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.cookies:
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYmF.name=='session':
     hVIEkTbeAzvwraQpgPJuLMxKnjWYmO['session']=hVIEkTbeAzvwraQpgPJuLMxKnjWYmF.value
    elif hVIEkTbeAzvwraQpgPJuLMxKnjWYmF.name=='session.sig':
     hVIEkTbeAzvwraQpgPJuLMxKnjWYmO['session.sig']=hVIEkTbeAzvwraQpgPJuLMxKnjWYmF.value
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return{}
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_SAMSUNGTV+'/user'
   hVIEkTbeAzvwraQpgPJuLMxKnjWYml={'session':hVIEkTbeAzvwraQpgPJuLMxKnjWYmO['session'],'session.sig':hVIEkTbeAzvwraQpgPJuLMxKnjWYmO['session.sig'],}
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYml)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYmO['countryCode']=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq.get('countryCode')
   hVIEkTbeAzvwraQpgPJuLMxKnjWYmO['uuid'] =hVIEkTbeAzvwraQpgPJuLMxKnjWYXq.get('uuid')
   hVIEkTbeAzvwraQpgPJuLMxKnjWYmO['ip'] =hVIEkTbeAzvwraQpgPJuLMxKnjWYXq.get('ip')
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return{}
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYmO
 def t_Cache(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYCX =hVIEkTbeAzvwraQpgPJuLMxKnjWYBy(time.time())
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmy=hVIEkTbeAzvwraQpgPJuLMxKnjWYBy(hVIEkTbeAzvwraQpgPJuLMxKnjWYCX-hVIEkTbeAzvwraQpgPJuLMxKnjWYCX%3600)
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYmy,hVIEkTbeAzvwraQpgPJuLMxKnjWYCX
 def zlib_compress(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,plaintext):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmD=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(hVIEkTbeAzvwraQpgPJuLMxKnjWYmD).decode('utf-8')
 def Get_BaseRequest_Samsungtv(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,hVIEkTbeAzvwraQpgPJuLMxKnjWYmO):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXq={}
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXU=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.API_SAMSUNGTV+'/api/lives'
   hVIEkTbeAzvwraQpgPJuLMxKnjWYmy,hVIEkTbeAzvwraQpgPJuLMxKnjWYCX=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.t_Cache()
   hVIEkTbeAzvwraQpgPJuLMxKnjWYmN=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.zlib_compress(hVIEkTbeAzvwraQpgPJuLMxKnjWYmO['uuid']+':'+hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYCX))
   hVIEkTbeAzvwraQpgPJuLMxKnjWYml={'session':hVIEkTbeAzvwraQpgPJuLMxKnjWYmO['session'],'session.sig':hVIEkTbeAzvwraQpgPJuLMxKnjWYmO['session.sig'],}
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXD ={'t':hVIEkTbeAzvwraQpgPJuLMxKnjWYBm(hVIEkTbeAzvwraQpgPJuLMxKnjWYmy)}
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtS ={'x-cred-payload':hVIEkTbeAzvwraQpgPJuLMxKnjWYmN}
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXR=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.callRequestCookies('Get',hVIEkTbeAzvwraQpgPJuLMxKnjWYXU,payload=hVIEkTbeAzvwraQpgPJuLMxKnjWYBC,params=hVIEkTbeAzvwraQpgPJuLMxKnjWYXD,headers=hVIEkTbeAzvwraQpgPJuLMxKnjWYtS,cookies=hVIEkTbeAzvwraQpgPJuLMxKnjWYml)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=json.loads(hVIEkTbeAzvwraQpgPJuLMxKnjWYXR.text)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXq
 def Get_ChannelList_Samsungtv(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,hVIEkTbeAzvwraQpgPJuLMxKnjWYmO,exceptGroup=[]):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi =[]
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXq=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_BaseRequest_Samsungtv(hVIEkTbeAzvwraQpgPJuLMxKnjWYmO)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXc=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['live']['channel']
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYXc:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXH =hVIEkTbeAzvwraQpgPJuLMxKnjWYXs.get('id')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXd =hVIEkTbeAzvwraQpgPJuLMxKnjWYXs.get('name')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXG=hVIEkTbeAzvwraQpgPJuLMxKnjWYXs.get('logo')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXo=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_getGenre(hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'samsung')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'channelnm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXd,'channelimg':hVIEkTbeAzvwraQpgPJuLMxKnjWYXG,'ott':'samsung','genrenm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXo}
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXo not in exceptGroup:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYXi.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi
 def Get_EpgInfo_Samsungtv(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,hVIEkTbeAzvwraQpgPJuLMxKnjWYmO,exceptGroup=[]):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYXi=[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtR =[]
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXq =hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_BaseRequest_Samsungtv(hVIEkTbeAzvwraQpgPJuLMxKnjWYmO)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXs=hVIEkTbeAzvwraQpgPJuLMxKnjWYXq['live']['channel']
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYtq in hVIEkTbeAzvwraQpgPJuLMxKnjWYXs:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXH =hVIEkTbeAzvwraQpgPJuLMxKnjWYtq.get('id')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXd =hVIEkTbeAzvwraQpgPJuLMxKnjWYtq.get('name')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXG=hVIEkTbeAzvwraQpgPJuLMxKnjWYtq.get('logo')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtc =hVIEkTbeAzvwraQpgPJuLMxKnjWYtq.get('program')
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXo=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.make_getGenre(hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'samsung')
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYXo in exceptGroup:
     continue
    hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'channelnm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXd,'channelimg':hVIEkTbeAzvwraQpgPJuLMxKnjWYXG,'ott':'samsung','genrenm':hVIEkTbeAzvwraQpgPJuLMxKnjWYXo}
    hVIEkTbeAzvwraQpgPJuLMxKnjWYXi.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
    for hVIEkTbeAzvwraQpgPJuLMxKnjWYts in hVIEkTbeAzvwraQpgPJuLMxKnjWYtc:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYmS=hVIEkTbeAzvwraQpgPJuLMxKnjWYts.get('start_time')
     hVIEkTbeAzvwraQpgPJuLMxKnjWYmi =hVIEkTbeAzvwraQpgPJuLMxKnjWYts.get('duration') 
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtm=datetime.datetime.strptime(hVIEkTbeAzvwraQpgPJuLMxKnjWYmS,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtB =hVIEkTbeAzvwraQpgPJuLMxKnjWYtm+datetime.timedelta(seconds=hVIEkTbeAzvwraQpgPJuLMxKnjWYmi)
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtX={'channelid':hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,'title':hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.xmlText(urllib.parse.unquote_plus(hVIEkTbeAzvwraQpgPJuLMxKnjWYts.get('title'))),'startTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYtm.strftime('%Y%m%d%H%M00'),'endTime':hVIEkTbeAzvwraQpgPJuLMxKnjWYtB.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtR.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  except hVIEkTbeAzvwraQpgPJuLMxKnjWYBO as exception:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYBF(exception)
   return[],[]
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYXi,hVIEkTbeAzvwraQpgPJuLMxKnjWYtR
 def make_getGenre(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,hVIEkTbeAzvwraQpgPJuLMxKnjWYmd):
  try:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtO=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.INIT_CHANNEL.get(hVIEkTbeAzvwraQpgPJuLMxKnjWYXH+'.'+hVIEkTbeAzvwraQpgPJuLMxKnjWYmd).get('genre')
  except:
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtO=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.INIT_CHANNEL.get('-').get('genre')
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYtO
 def make_base_allchannel_py(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB,hVIEkTbeAzvwraQpgPJuLMxKnjWYmO):
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmf =[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmU=[]
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmR=hVIEkTbeAzvwraQpgPJuLMxKnjWYBS()
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtX=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_ChannelList_Wavve()
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmf.extend(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtX=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_ChannelList_Tving()
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmf.extend(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtX=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_ChannelList_Seezn()
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmf.extend(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  hVIEkTbeAzvwraQpgPJuLMxKnjWYtX=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_ChannelList_Samsungtv(hVIEkTbeAzvwraQpgPJuLMxKnjWYmO)
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmf.extend(hVIEkTbeAzvwraQpgPJuLMxKnjWYtX)
  hVIEkTbeAzvwraQpgPJuLMxKnjWYBF('1')
  for i in hVIEkTbeAzvwraQpgPJuLMxKnjWYBD(hVIEkTbeAzvwraQpgPJuLMxKnjWYBN(hVIEkTbeAzvwraQpgPJuLMxKnjWYmf)):
   if hVIEkTbeAzvwraQpgPJuLMxKnjWYmf[i]['genrenm']=='-':
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYmf[i]['ott']=='wavve':
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtO=hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.Get_ChanneGenrename_Wavve(hVIEkTbeAzvwraQpgPJuLMxKnjWYmf[i]['channelid'])
     if hVIEkTbeAzvwraQpgPJuLMxKnjWYtO not in hVIEkTbeAzvwraQpgPJuLMxKnjWYmR:hVIEkTbeAzvwraQpgPJuLMxKnjWYmR.add(hVIEkTbeAzvwraQpgPJuLMxKnjWYtO)
     time.sleep(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.SLEEP_TIME)
    elif hVIEkTbeAzvwraQpgPJuLMxKnjWYmf[i]['ott']=='spotv':
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtO='스포츠'
    else:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYtO='-'
    hVIEkTbeAzvwraQpgPJuLMxKnjWYmf[i]['genrenm']=hVIEkTbeAzvwraQpgPJuLMxKnjWYtO
   else:
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYmf[i]['genrenm']not in hVIEkTbeAzvwraQpgPJuLMxKnjWYmR:hVIEkTbeAzvwraQpgPJuLMxKnjWYmR.add(hVIEkTbeAzvwraQpgPJuLMxKnjWYmf[i]['genrenm'])
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmR.add(hVIEkTbeAzvwraQpgPJuLMxKnjWYXB.INIT_CHANNEL.get('-').get('genre'))
  hVIEkTbeAzvwraQpgPJuLMxKnjWYBF('2')
  for hVIEkTbeAzvwraQpgPJuLMxKnjWYmq in hVIEkTbeAzvwraQpgPJuLMxKnjWYmR:
   for hVIEkTbeAzvwraQpgPJuLMxKnjWYmc in hVIEkTbeAzvwraQpgPJuLMxKnjWYmf:
    if hVIEkTbeAzvwraQpgPJuLMxKnjWYmc['genrenm']==hVIEkTbeAzvwraQpgPJuLMxKnjWYmq:
     hVIEkTbeAzvwraQpgPJuLMxKnjWYmU.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYmc)
  for hVIEkTbeAzvwraQpgPJuLMxKnjWYmc in hVIEkTbeAzvwraQpgPJuLMxKnjWYmf:
   if hVIEkTbeAzvwraQpgPJuLMxKnjWYmc['genrenm']not in hVIEkTbeAzvwraQpgPJuLMxKnjWYmR:
    hVIEkTbeAzvwraQpgPJuLMxKnjWYmU.append(hVIEkTbeAzvwraQpgPJuLMxKnjWYmc)
  hVIEkTbeAzvwraQpgPJuLMxKnjWYBF('3')
  hVIEkTbeAzvwraQpgPJuLMxKnjWYms='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(hVIEkTbeAzvwraQpgPJuLMxKnjWYms):os.remove(hVIEkTbeAzvwraQpgPJuLMxKnjWYms)
  fp=hVIEkTbeAzvwraQpgPJuLMxKnjWYBi(hVIEkTbeAzvwraQpgPJuLMxKnjWYms,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  hVIEkTbeAzvwraQpgPJuLMxKnjWYmH=hVIEkTbeAzvwraQpgPJuLMxKnjWYBN(hVIEkTbeAzvwraQpgPJuLMxKnjWYmU)
  i=0
  for hVIEkTbeAzvwraQpgPJuLMxKnjWYXs in hVIEkTbeAzvwraQpgPJuLMxKnjWYmU:
   i+=1
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXH =hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['channelid']
   hVIEkTbeAzvwraQpgPJuLMxKnjWYXd =hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['channelnm']
   hVIEkTbeAzvwraQpgPJuLMxKnjWYmd =hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['ott']
   hVIEkTbeAzvwraQpgPJuLMxKnjWYmG ='%s.%s'%(hVIEkTbeAzvwraQpgPJuLMxKnjWYXH,hVIEkTbeAzvwraQpgPJuLMxKnjWYmd)
   hVIEkTbeAzvwraQpgPJuLMxKnjWYtO =hVIEkTbeAzvwraQpgPJuLMxKnjWYXs['genrenm']
   hVIEkTbeAzvwraQpgPJuLMxKnjWYmo='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(hVIEkTbeAzvwraQpgPJuLMxKnjWYmG,hVIEkTbeAzvwraQpgPJuLMxKnjWYXd,hVIEkTbeAzvwraQpgPJuLMxKnjWYtO)
   if i<hVIEkTbeAzvwraQpgPJuLMxKnjWYmH:
    fp.write(hVIEkTbeAzvwraQpgPJuLMxKnjWYmo+',\n')
   else:
    fp.write(hVIEkTbeAzvwraQpgPJuLMxKnjWYmo+'\n')
  fp.write('}\n')
  fp.close()
  return hVIEkTbeAzvwraQpgPJuLMxKnjWYmR
# Created by pyminifier (https://github.com/liftoff/pyminifier)
