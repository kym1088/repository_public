__author__="NightRain"
OgfpqHNubvlEdYCGWMFriJKBSwDhne=object
OgfpqHNubvlEdYCGWMFriJKBSwDhnm=False
OgfpqHNubvlEdYCGWMFriJKBSwDhsQ=None
OgfpqHNubvlEdYCGWMFriJKBSwDhsR=True
OgfpqHNubvlEdYCGWMFriJKBSwDhsn=len
OgfpqHNubvlEdYCGWMFriJKBSwDhsU=str
OgfpqHNubvlEdYCGWMFriJKBSwDhsV=open
OgfpqHNubvlEdYCGWMFriJKBSwDhsX=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
OgfpqHNubvlEdYCGWMFriJKBSwDhQn=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (시즌)','mode':'ADD_M3U','sType':'seezn','sName':'시즌'},{'title':'     - M3U 추가 (삼성tv 플러스)','mode':'ADD_M3U','sType':'samsung','sName':'삼성TV 플러스'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
OgfpqHNubvlEdYCGWMFriJKBSwDhQs=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class OgfpqHNubvlEdYCGWMFriJKBSwDhQR(OgfpqHNubvlEdYCGWMFriJKBSwDhne):
 def __init__(OgfpqHNubvlEdYCGWMFriJKBSwDhQU,OgfpqHNubvlEdYCGWMFriJKBSwDhQV,OgfpqHNubvlEdYCGWMFriJKBSwDhQX,OgfpqHNubvlEdYCGWMFriJKBSwDhQa):
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU._addon_url =OgfpqHNubvlEdYCGWMFriJKBSwDhQV
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU._addon_handle =OgfpqHNubvlEdYCGWMFriJKBSwDhQX
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.main_params =OgfpqHNubvlEdYCGWMFriJKBSwDhQa
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_FILE_PATH ='' 
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_FILE_NAME ='' 
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVE =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONTVING =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSPOTV =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZN =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSAMSUNG =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVERADIO =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVEHOME =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONRELIGION =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSPOTVPAY =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZNPAY =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZNHOME =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZNRADIO =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSAMSUNGHOME=OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_DISPLAYNM =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_AUTORESTART =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj =hVIEkTbeAzvwraQpgPJuLMxKnjWYXt() 
 def addon_noti(OgfpqHNubvlEdYCGWMFriJKBSwDhQU,sting):
  try:
   OgfpqHNubvlEdYCGWMFriJKBSwDhQy=xbmcgui.Dialog()
   OgfpqHNubvlEdYCGWMFriJKBSwDhQy.notification(__addonname__,sting)
  except:
   OgfpqHNubvlEdYCGWMFriJKBSwDhsQ
 def addon_log(OgfpqHNubvlEdYCGWMFriJKBSwDhQU,string):
  try:
   OgfpqHNubvlEdYCGWMFriJKBSwDhQk=string.encode('utf-8','ignore')
  except:
   OgfpqHNubvlEdYCGWMFriJKBSwDhQk='addonException: addon_log'
  OgfpqHNubvlEdYCGWMFriJKBSwDhQI=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,OgfpqHNubvlEdYCGWMFriJKBSwDhQk),level=OgfpqHNubvlEdYCGWMFriJKBSwDhQI)
 def get_keyboard_input(OgfpqHNubvlEdYCGWMFriJKBSwDhQU,OgfpqHNubvlEdYCGWMFriJKBSwDhQP):
  OgfpqHNubvlEdYCGWMFriJKBSwDhQc=OgfpqHNubvlEdYCGWMFriJKBSwDhsQ
  kb=xbmc.Keyboard()
  kb.setHeading(OgfpqHNubvlEdYCGWMFriJKBSwDhQP)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   OgfpqHNubvlEdYCGWMFriJKBSwDhQc=kb.getText()
  return OgfpqHNubvlEdYCGWMFriJKBSwDhQc
 def add_dir(OgfpqHNubvlEdYCGWMFriJKBSwDhQU,label,sublabel='',img='',infoLabels=OgfpqHNubvlEdYCGWMFriJKBSwDhsQ,isFolder=OgfpqHNubvlEdYCGWMFriJKBSwDhsR,params='',isLink=OgfpqHNubvlEdYCGWMFriJKBSwDhnm,ContextMenu=OgfpqHNubvlEdYCGWMFriJKBSwDhsQ):
  OgfpqHNubvlEdYCGWMFriJKBSwDhQL='%s?%s'%(OgfpqHNubvlEdYCGWMFriJKBSwDhQU._addon_url,urllib.parse.urlencode(params))
  if sublabel:OgfpqHNubvlEdYCGWMFriJKBSwDhQP='%s < %s >'%(label,sublabel)
  else: OgfpqHNubvlEdYCGWMFriJKBSwDhQP=label
  if not img:img='DefaultFolder.png'
  OgfpqHNubvlEdYCGWMFriJKBSwDhQz=xbmcgui.ListItem(OgfpqHNubvlEdYCGWMFriJKBSwDhQP)
  OgfpqHNubvlEdYCGWMFriJKBSwDhQz.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:OgfpqHNubvlEdYCGWMFriJKBSwDhQz.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   OgfpqHNubvlEdYCGWMFriJKBSwDhQz.setProperty('IsPlayable','true')
  if ContextMenu:OgfpqHNubvlEdYCGWMFriJKBSwDhQz.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(OgfpqHNubvlEdYCGWMFriJKBSwDhQU._addon_handle,OgfpqHNubvlEdYCGWMFriJKBSwDhQL,OgfpqHNubvlEdYCGWMFriJKBSwDhQz,isFolder)
 def make_M3u_Filename(OgfpqHNubvlEdYCGWMFriJKBSwDhQU,tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhnm):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_FILE_PATH+OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(OgfpqHNubvlEdYCGWMFriJKBSwDhQU,tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhnm):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_FILE_PATH+OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_FILE_NAME+'.xml'
 def dp_Main_List(OgfpqHNubvlEdYCGWMFriJKBSwDhQU):
  for OgfpqHNubvlEdYCGWMFriJKBSwDhQo in OgfpqHNubvlEdYCGWMFriJKBSwDhQn:
   OgfpqHNubvlEdYCGWMFriJKBSwDhQP=OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('title')
   OgfpqHNubvlEdYCGWMFriJKBSwDhQt=''
   OgfpqHNubvlEdYCGWMFriJKBSwDhQA={'mode':OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('mode'),'sType':OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('sType'),'sName':OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('sName')}
   if OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('mode')=='XXX':
    OgfpqHNubvlEdYCGWMFriJKBSwDhQT=OgfpqHNubvlEdYCGWMFriJKBSwDhnm
    OgfpqHNubvlEdYCGWMFriJKBSwDhQj =OgfpqHNubvlEdYCGWMFriJKBSwDhsR
   else:
    OgfpqHNubvlEdYCGWMFriJKBSwDhQT=OgfpqHNubvlEdYCGWMFriJKBSwDhsR
    OgfpqHNubvlEdYCGWMFriJKBSwDhQj =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
   OgfpqHNubvlEdYCGWMFriJKBSwDhQe=OgfpqHNubvlEdYCGWMFriJKBSwDhsR
   if OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('mode')=='ADD_M3U':
    if OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('sType')=='wavve' and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVE ==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:OgfpqHNubvlEdYCGWMFriJKBSwDhQe=OgfpqHNubvlEdYCGWMFriJKBSwDhnm
    if OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('sType')=='tving' and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONTVING ==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:OgfpqHNubvlEdYCGWMFriJKBSwDhQe=OgfpqHNubvlEdYCGWMFriJKBSwDhnm
    if OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('sType')=='spotv' and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSPOTV ==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:OgfpqHNubvlEdYCGWMFriJKBSwDhQe=OgfpqHNubvlEdYCGWMFriJKBSwDhnm
    if OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('sType')=='seezn' and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZN ==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:OgfpqHNubvlEdYCGWMFriJKBSwDhQe=OgfpqHNubvlEdYCGWMFriJKBSwDhnm
    if OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('sType')=='samsung' and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSAMSUNG==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:OgfpqHNubvlEdYCGWMFriJKBSwDhQe=OgfpqHNubvlEdYCGWMFriJKBSwDhnm
   if OgfpqHNubvlEdYCGWMFriJKBSwDhQe==OgfpqHNubvlEdYCGWMFriJKBSwDhsR:
    if 'icon' in OgfpqHNubvlEdYCGWMFriJKBSwDhQo:OgfpqHNubvlEdYCGWMFriJKBSwDhQt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',OgfpqHNubvlEdYCGWMFriJKBSwDhQo.get('icon')) 
    OgfpqHNubvlEdYCGWMFriJKBSwDhQU.add_dir(OgfpqHNubvlEdYCGWMFriJKBSwDhQP,sublabel='',img=OgfpqHNubvlEdYCGWMFriJKBSwDhQt,infoLabels=OgfpqHNubvlEdYCGWMFriJKBSwDhsQ,isFolder=OgfpqHNubvlEdYCGWMFriJKBSwDhQT,params=OgfpqHNubvlEdYCGWMFriJKBSwDhQA,isLink=OgfpqHNubvlEdYCGWMFriJKBSwDhQj)
  if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhQn)>0:xbmcplugin.endOfDirectory(OgfpqHNubvlEdYCGWMFriJKBSwDhQU._addon_handle,cacheToDisc=OgfpqHNubvlEdYCGWMFriJKBSwDhsR)
 def dp_Delete_M3u(OgfpqHNubvlEdYCGWMFriJKBSwDhQU,args):
  OgfpqHNubvlEdYCGWMFriJKBSwDhQy=xbmcgui.Dialog()
  OgfpqHNubvlEdYCGWMFriJKBSwDhRQ=OgfpqHNubvlEdYCGWMFriJKBSwDhQy.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if OgfpqHNubvlEdYCGWMFriJKBSwDhRQ==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:sys.exit()
  OgfpqHNubvlEdYCGWMFriJKBSwDhRn=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_M3u_Filename(tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhnm)
  if xbmcvfs.exists(OgfpqHNubvlEdYCGWMFriJKBSwDhRn):
   if xbmcvfs.delete(OgfpqHNubvlEdYCGWMFriJKBSwDhRn)==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:
    OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_noti(__language__(30910).encode('utf-8'))
    return
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(OgfpqHNubvlEdYCGWMFriJKBSwDhQU,args):
  OgfpqHNubvlEdYCGWMFriJKBSwDhRs=args.get('sType')
  OgfpqHNubvlEdYCGWMFriJKBSwDhRU=args.get('sName')
  OgfpqHNubvlEdYCGWMFriJKBSwDhQy=xbmcgui.Dialog()
  OgfpqHNubvlEdYCGWMFriJKBSwDhRQ=OgfpqHNubvlEdYCGWMFriJKBSwDhQy.yesno((OgfpqHNubvlEdYCGWMFriJKBSwDhRU+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if OgfpqHNubvlEdYCGWMFriJKBSwDhRQ==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:sys.exit()
  OgfpqHNubvlEdYCGWMFriJKBSwDhRV =[]
  OgfpqHNubvlEdYCGWMFriJKBSwDhRX =[]
  OgfpqHNubvlEdYCGWMFriJKBSwDhRn=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_M3u_Filename(tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhsR)
  if os.path.isfile(OgfpqHNubvlEdYCGWMFriJKBSwDhRn):os.remove(OgfpqHNubvlEdYCGWMFriJKBSwDhRn)
  if OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='all':
   OgfpqHNubvlEdYCGWMFriJKBSwDhRn=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_M3u_Filename(tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhnm)
   if xbmcvfs.exists(OgfpqHNubvlEdYCGWMFriJKBSwDhRn):
    if xbmcvfs.delete(OgfpqHNubvlEdYCGWMFriJKBSwDhRn)==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:
     OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   OgfpqHNubvlEdYCGWMFriJKBSwDhRa=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_M3u_Filename(tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhnm)
   if xbmcvfs.exists(OgfpqHNubvlEdYCGWMFriJKBSwDhRa):
    OgfpqHNubvlEdYCGWMFriJKBSwDhRx=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_M3u_Filename(tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhsR)
    xbmcvfs.copy(OgfpqHNubvlEdYCGWMFriJKBSwDhRa,OgfpqHNubvlEdYCGWMFriJKBSwDhRx)
  if(OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='wavve' or OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='all')and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVE:
   OgfpqHNubvlEdYCGWMFriJKBSwDhRy=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_ChannelList_Wavve(exceptGroup=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_EexceptGroup_Wavve())
   if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)!=0:OgfpqHNubvlEdYCGWMFriJKBSwDhRV.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_log('wavve cnt ----> '+OgfpqHNubvlEdYCGWMFriJKBSwDhsU(OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)))
  if(OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='tving' or OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='all')and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONTVING:
   OgfpqHNubvlEdYCGWMFriJKBSwDhRy=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_ChannelList_Tving()
   if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)!=0:OgfpqHNubvlEdYCGWMFriJKBSwDhRV.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_log('tving cnt ----> '+OgfpqHNubvlEdYCGWMFriJKBSwDhsU(OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)))
  if(OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='spotv' or OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='all')and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSPOTV:
   OgfpqHNubvlEdYCGWMFriJKBSwDhRy=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_ChannelList_Spotv(payyn=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSPOTVPAY)
   if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)!=0:OgfpqHNubvlEdYCGWMFriJKBSwDhRV.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_log('spotv cnt ----> '+OgfpqHNubvlEdYCGWMFriJKBSwDhsU(OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)))
  if(OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='seezn' or OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='all')and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZN:
   OgfpqHNubvlEdYCGWMFriJKBSwDhRy=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_ChannelList_Seezn(exceptGroup=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_EexceptGroup_Seezn())
   if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)!=0:OgfpqHNubvlEdYCGWMFriJKBSwDhRV.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_log('seezn cnt ----> '+OgfpqHNubvlEdYCGWMFriJKBSwDhsU(OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)))
  if(OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='samsung' or OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='all')and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSAMSUNG:
   OgfpqHNubvlEdYCGWMFriJKBSwDhRk=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_BaseInfo_Samsungtv()
   OgfpqHNubvlEdYCGWMFriJKBSwDhRy=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_ChannelList_Samsungtv(OgfpqHNubvlEdYCGWMFriJKBSwDhRk,exceptGroup=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_EexceptGroup_Samsungtv())
   if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)!=0:OgfpqHNubvlEdYCGWMFriJKBSwDhRV.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_log('samsungtv cnt ----> '+OgfpqHNubvlEdYCGWMFriJKBSwDhsU(OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhRy)))
  if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhRV)==0:
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_noti(__language__(30909).encode('utf8'))
   return
  for OgfpqHNubvlEdYCGWMFriJKBSwDhRI in OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.INIT_GENRESORT:
   for OgfpqHNubvlEdYCGWMFriJKBSwDhRc in OgfpqHNubvlEdYCGWMFriJKBSwDhRV:
    if OgfpqHNubvlEdYCGWMFriJKBSwDhRc['genrenm']==OgfpqHNubvlEdYCGWMFriJKBSwDhRI:
     OgfpqHNubvlEdYCGWMFriJKBSwDhRX.append(OgfpqHNubvlEdYCGWMFriJKBSwDhRc)
  for OgfpqHNubvlEdYCGWMFriJKBSwDhRc in OgfpqHNubvlEdYCGWMFriJKBSwDhRV:
   if OgfpqHNubvlEdYCGWMFriJKBSwDhRc['genrenm']not in OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.INIT_GENRESORT:
    OgfpqHNubvlEdYCGWMFriJKBSwDhRX.append(OgfpqHNubvlEdYCGWMFriJKBSwDhRc)
  try:
   OgfpqHNubvlEdYCGWMFriJKBSwDhRn=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_M3u_Filename(tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhsR)
   if os.path.isfile(OgfpqHNubvlEdYCGWMFriJKBSwDhRn):
    fp=OgfpqHNubvlEdYCGWMFriJKBSwDhsV(OgfpqHNubvlEdYCGWMFriJKBSwDhRn,'a',-1,'utf-8')
   else:
    fp=OgfpqHNubvlEdYCGWMFriJKBSwDhsV(OgfpqHNubvlEdYCGWMFriJKBSwDhRn,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for OgfpqHNubvlEdYCGWMFriJKBSwDhRL in OgfpqHNubvlEdYCGWMFriJKBSwDhRX:
    OgfpqHNubvlEdYCGWMFriJKBSwDhRP =OgfpqHNubvlEdYCGWMFriJKBSwDhRL['channelid']
    OgfpqHNubvlEdYCGWMFriJKBSwDhRz =OgfpqHNubvlEdYCGWMFriJKBSwDhRL['channelnm']
    OgfpqHNubvlEdYCGWMFriJKBSwDhRo=OgfpqHNubvlEdYCGWMFriJKBSwDhRL['channelimg']
    OgfpqHNubvlEdYCGWMFriJKBSwDhRt =OgfpqHNubvlEdYCGWMFriJKBSwDhRL['ott']
    OgfpqHNubvlEdYCGWMFriJKBSwDhRA ='%s.%s'%(OgfpqHNubvlEdYCGWMFriJKBSwDhRP,OgfpqHNubvlEdYCGWMFriJKBSwDhRt)
    OgfpqHNubvlEdYCGWMFriJKBSwDhRT=OgfpqHNubvlEdYCGWMFriJKBSwDhRL['genrenm']
    if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_DISPLAYNM:
     OgfpqHNubvlEdYCGWMFriJKBSwDhRz='%s (%s)'%(OgfpqHNubvlEdYCGWMFriJKBSwDhRz,OgfpqHNubvlEdYCGWMFriJKBSwDhRt)
    if OgfpqHNubvlEdYCGWMFriJKBSwDhRT=='라디오/음악':
     OgfpqHNubvlEdYCGWMFriJKBSwDhRj='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(OgfpqHNubvlEdYCGWMFriJKBSwDhRA,OgfpqHNubvlEdYCGWMFriJKBSwDhRz,OgfpqHNubvlEdYCGWMFriJKBSwDhRT,OgfpqHNubvlEdYCGWMFriJKBSwDhRo,OgfpqHNubvlEdYCGWMFriJKBSwDhRz)
    else:
     OgfpqHNubvlEdYCGWMFriJKBSwDhRj='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(OgfpqHNubvlEdYCGWMFriJKBSwDhRA,OgfpqHNubvlEdYCGWMFriJKBSwDhRz,OgfpqHNubvlEdYCGWMFriJKBSwDhRT,OgfpqHNubvlEdYCGWMFriJKBSwDhRo,OgfpqHNubvlEdYCGWMFriJKBSwDhRz)
    if OgfpqHNubvlEdYCGWMFriJKBSwDhRt=='wavve':
     OgfpqHNubvlEdYCGWMFriJKBSwDhRe ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(OgfpqHNubvlEdYCGWMFriJKBSwDhRP)
    elif OgfpqHNubvlEdYCGWMFriJKBSwDhRt=='tving':
     OgfpqHNubvlEdYCGWMFriJKBSwDhRe ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(OgfpqHNubvlEdYCGWMFriJKBSwDhRP)
    elif OgfpqHNubvlEdYCGWMFriJKBSwDhRt=='spotv':
     OgfpqHNubvlEdYCGWMFriJKBSwDhRe ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(OgfpqHNubvlEdYCGWMFriJKBSwDhRP)
    elif OgfpqHNubvlEdYCGWMFriJKBSwDhRt=='seezn':
     OgfpqHNubvlEdYCGWMFriJKBSwDhRm='128' if OgfpqHNubvlEdYCGWMFriJKBSwDhRT=='라디오/음악' else '4000'
     OgfpqHNubvlEdYCGWMFriJKBSwDhRe ='plugin://plugin.video.seeznm/?mode=LIVE&mediacode=%s&bitrate=%s\n'%(OgfpqHNubvlEdYCGWMFriJKBSwDhRP,OgfpqHNubvlEdYCGWMFriJKBSwDhRm)
    if OgfpqHNubvlEdYCGWMFriJKBSwDhRt=='samsung':
     OgfpqHNubvlEdYCGWMFriJKBSwDhRe ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(OgfpqHNubvlEdYCGWMFriJKBSwDhRP)
    fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhRj)
    fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhRe)
   fp.close()
  except:
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_noti(__language__(30910).encode('utf8'))
   return
  OgfpqHNubvlEdYCGWMFriJKBSwDhRa=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_M3u_Filename(tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhsR)
  OgfpqHNubvlEdYCGWMFriJKBSwDhRx=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_M3u_Filename(tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhnm)
  if xbmcvfs.copy(OgfpqHNubvlEdYCGWMFriJKBSwDhRa,OgfpqHNubvlEdYCGWMFriJKBSwDhRx):
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_noti((OgfpqHNubvlEdYCGWMFriJKBSwDhRU+' '+__language__(30908)).encode('utf8'))
  else:
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_noti(__language__(30910).encode('utf-8'))
 def dp_Make_Epg(OgfpqHNubvlEdYCGWMFriJKBSwDhQU,args):
  OgfpqHNubvlEdYCGWMFriJKBSwDhRs=args.get('sType')
  OgfpqHNubvlEdYCGWMFriJKBSwDhRU=args.get('sName')
  OgfpqHNubvlEdYCGWMFriJKBSwDhnQ=args.get('sNoti')
  if OgfpqHNubvlEdYCGWMFriJKBSwDhnQ!='N':
   OgfpqHNubvlEdYCGWMFriJKBSwDhQy=xbmcgui.Dialog()
   OgfpqHNubvlEdYCGWMFriJKBSwDhRQ=OgfpqHNubvlEdYCGWMFriJKBSwDhQy.yesno((OgfpqHNubvlEdYCGWMFriJKBSwDhRU+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if OgfpqHNubvlEdYCGWMFriJKBSwDhRQ==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:sys.exit()
  OgfpqHNubvlEdYCGWMFriJKBSwDhnR=[]
  OgfpqHNubvlEdYCGWMFriJKBSwDhns=[]
  if(OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='wavve' or OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='all')and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVE:
   OgfpqHNubvlEdYCGWMFriJKBSwDhnU,OgfpqHNubvlEdYCGWMFriJKBSwDhnV=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_EexceptGroup_Wavve())
   if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhnV)!=0:
    OgfpqHNubvlEdYCGWMFriJKBSwDhnR.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhnU)
    OgfpqHNubvlEdYCGWMFriJKBSwDhns.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhnV)
  if(OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='tving' or OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='all')and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONTVING:
   OgfpqHNubvlEdYCGWMFriJKBSwDhnU,OgfpqHNubvlEdYCGWMFriJKBSwDhnV=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_EpgInfo_Tving()
   if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhnV)!=0:
    OgfpqHNubvlEdYCGWMFriJKBSwDhnR.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhnU)
    OgfpqHNubvlEdYCGWMFriJKBSwDhns.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhnV)
  if(OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='spotv' or OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='all')and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSPOTV:
   OgfpqHNubvlEdYCGWMFriJKBSwDhnU,OgfpqHNubvlEdYCGWMFriJKBSwDhnV=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_EpgInfo_Spotv(payyn=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSPOTVPAY)
   if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhnV)!=0:
    OgfpqHNubvlEdYCGWMFriJKBSwDhnR.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhnU)
    OgfpqHNubvlEdYCGWMFriJKBSwDhns.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhnV)
  if(OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='seezn' or OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='all')and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZN:
   OgfpqHNubvlEdYCGWMFriJKBSwDhnU,OgfpqHNubvlEdYCGWMFriJKBSwDhnV=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_EpgInfo_Seezn(exceptGroup=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_EexceptGroup_Seezn())
   if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhnV)!=0:
    OgfpqHNubvlEdYCGWMFriJKBSwDhnR.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhnU)
    OgfpqHNubvlEdYCGWMFriJKBSwDhns.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhnV)
  if(OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='samsung' or OgfpqHNubvlEdYCGWMFriJKBSwDhRs=='all')and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSAMSUNG:
   OgfpqHNubvlEdYCGWMFriJKBSwDhRk=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_BaseInfo_Samsungtv()
   OgfpqHNubvlEdYCGWMFriJKBSwDhnU,OgfpqHNubvlEdYCGWMFriJKBSwDhnV=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_EpgInfo_Samsungtv(OgfpqHNubvlEdYCGWMFriJKBSwDhRk,exceptGroup=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_EexceptGroup_Samsungtv())
   if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhnV)!=0:
    OgfpqHNubvlEdYCGWMFriJKBSwDhnR.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhnU)
    OgfpqHNubvlEdYCGWMFriJKBSwDhns.extend(OgfpqHNubvlEdYCGWMFriJKBSwDhnV)
  if OgfpqHNubvlEdYCGWMFriJKBSwDhsn(OgfpqHNubvlEdYCGWMFriJKBSwDhns)==0:
   if OgfpqHNubvlEdYCGWMFriJKBSwDhnQ!='N':OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   OgfpqHNubvlEdYCGWMFriJKBSwDhRn=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_Epg_Filename(tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhsR)
   fp=OgfpqHNubvlEdYCGWMFriJKBSwDhsV(OgfpqHNubvlEdYCGWMFriJKBSwDhRn,'w',-1,'utf-8')
   OgfpqHNubvlEdYCGWMFriJKBSwDhnX='<?xml version="1.0" encoding="UTF-8"?>\n'
   OgfpqHNubvlEdYCGWMFriJKBSwDhna='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   OgfpqHNubvlEdYCGWMFriJKBSwDhnx='<tv generator-info-name="boritv_epg">\n\n'
   OgfpqHNubvlEdYCGWMFriJKBSwDhny='\n</tv>\n'
   fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhnX)
   fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhna)
   fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhnx)
   for OgfpqHNubvlEdYCGWMFriJKBSwDhnk in OgfpqHNubvlEdYCGWMFriJKBSwDhnR:
    OgfpqHNubvlEdYCGWMFriJKBSwDhnI='  <channel id="%s.%s">\n' %(OgfpqHNubvlEdYCGWMFriJKBSwDhnk.get('channelid'),OgfpqHNubvlEdYCGWMFriJKBSwDhnk.get('ott'))
    OgfpqHNubvlEdYCGWMFriJKBSwDhnc='    <display-name>%s</display-name>\n'%(OgfpqHNubvlEdYCGWMFriJKBSwDhnk.get('channelnm'))
    OgfpqHNubvlEdYCGWMFriJKBSwDhnL='    <icon src="%s" />\n' %(OgfpqHNubvlEdYCGWMFriJKBSwDhnk.get('channelimg'))
    OgfpqHNubvlEdYCGWMFriJKBSwDhnP='  </channel>\n\n'
    fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhnI)
    fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhnc)
    fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhnL)
    fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhnP)
   for OgfpqHNubvlEdYCGWMFriJKBSwDhnk in OgfpqHNubvlEdYCGWMFriJKBSwDhns:
    OgfpqHNubvlEdYCGWMFriJKBSwDhnI='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(OgfpqHNubvlEdYCGWMFriJKBSwDhnk.get('startTime'),OgfpqHNubvlEdYCGWMFriJKBSwDhnk.get('endTime'),OgfpqHNubvlEdYCGWMFriJKBSwDhnk.get('channelid'),OgfpqHNubvlEdYCGWMFriJKBSwDhnk.get('ott'))
    OgfpqHNubvlEdYCGWMFriJKBSwDhnc='    <title lang="kr">%s</title>\n' %(OgfpqHNubvlEdYCGWMFriJKBSwDhnk.get('title'))
    OgfpqHNubvlEdYCGWMFriJKBSwDhnL='  </programme>\n\n'
    fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhnI)
    fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhnc)
    fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhnL)
   fp.write(OgfpqHNubvlEdYCGWMFriJKBSwDhny)
   fp.close()
  except:
   if OgfpqHNubvlEdYCGWMFriJKBSwDhnQ!='N':OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_noti(__language__(30910).encode('utf8'))
   return
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.MakeEpg_SaveJson()
  OgfpqHNubvlEdYCGWMFriJKBSwDhRa=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_Epg_Filename(tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhsR)
  OgfpqHNubvlEdYCGWMFriJKBSwDhRx=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.make_Epg_Filename(tempyn=OgfpqHNubvlEdYCGWMFriJKBSwDhnm)
  if xbmcvfs.copy(OgfpqHNubvlEdYCGWMFriJKBSwDhRa,OgfpqHNubvlEdYCGWMFriJKBSwDhRx):
   if OgfpqHNubvlEdYCGWMFriJKBSwDhnQ!='N':OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_noti((OgfpqHNubvlEdYCGWMFriJKBSwDhRU+' '+__language__(30912)).encode('utf8'))
  else:
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_AUTORESTART:
    OgfpqHNubvlEdYCGWMFriJKBSwDhnz=xbmcaddon.Addon('pvr.iptvsimple')
    OgfpqHNubvlEdYCGWMFriJKBSwDhnz.setSetting('anything','anything')
  except:
   OgfpqHNubvlEdYCGWMFriJKBSwDhsQ 
 def make_EexceptGroup_Wavve(OgfpqHNubvlEdYCGWMFriJKBSwDhQU):
  OgfpqHNubvlEdYCGWMFriJKBSwDhno=[]
  if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVERADIO==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:
   OgfpqHNubvlEdYCGWMFriJKBSwDhno.append('라디오/음악')
  if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVEHOME==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:
   OgfpqHNubvlEdYCGWMFriJKBSwDhno.append('홈쇼핑')
  if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONRELIGION==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:
   OgfpqHNubvlEdYCGWMFriJKBSwDhno.append('종교')
  return OgfpqHNubvlEdYCGWMFriJKBSwDhno
 def make_EexceptGroup_Seezn(OgfpqHNubvlEdYCGWMFriJKBSwDhQU):
  OgfpqHNubvlEdYCGWMFriJKBSwDhno=[]
  if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZNRADIO==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:
   OgfpqHNubvlEdYCGWMFriJKBSwDhno.append('라디오/음악')
  if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZNHOME==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:
   OgfpqHNubvlEdYCGWMFriJKBSwDhno.append('홈쇼핑')
  if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZNPAY==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:
   OgfpqHNubvlEdYCGWMFriJKBSwDhno.append('won')
  return OgfpqHNubvlEdYCGWMFriJKBSwDhno
 def make_EexceptGroup_Samsungtv(OgfpqHNubvlEdYCGWMFriJKBSwDhQU):
  OgfpqHNubvlEdYCGWMFriJKBSwDhno=[]
  if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSAMSUNGHOME==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:
   OgfpqHNubvlEdYCGWMFriJKBSwDhno.append('홈쇼핑')
  return OgfpqHNubvlEdYCGWMFriJKBSwDhno
 def get_radio_list(OgfpqHNubvlEdYCGWMFriJKBSwDhQU):
  if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVERADIO==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:return[]
  OgfpqHNubvlEdYCGWMFriJKBSwDhnt=[{'broadcastid':'46584','genre':'10'}]
  return OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_ChannelList_WavveExcept(OgfpqHNubvlEdYCGWMFriJKBSwDhnt)
 def check_config(OgfpqHNubvlEdYCGWMFriJKBSwDhQU):
  OgfpqHNubvlEdYCGWMFriJKBSwDhnA=OgfpqHNubvlEdYCGWMFriJKBSwDhsR
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVE =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onWavve')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONTVING =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onTvng')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSPOTV =OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZN =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onSeezn')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSAMSUNG =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onSamsung')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVERADIO =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onWavveRadio')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVEHOME =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onWavveHome')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONRELIGION =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onWavveReligion')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSPOTVPAY =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onSpotvPay')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZNPAY =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onSeeznPay')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZNHOME =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onSeeznHome')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZNRADIO =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onSeeznRadio')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSAMSUNGHOME =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('onSamsungHome')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_DISPLAYNM =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('displayOTTnm')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_AUTORESTART =OgfpqHNubvlEdYCGWMFriJKBSwDhsR if __addon__.getSetting('autoRestart')=='true' else OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_FILE_PATH=='' or OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_FILE_NAME=='':OgfpqHNubvlEdYCGWMFriJKBSwDhnA=OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  if OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONWAVVE==OgfpqHNubvlEdYCGWMFriJKBSwDhnm and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONTVING==OgfpqHNubvlEdYCGWMFriJKBSwDhnm and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSEEZN==OgfpqHNubvlEdYCGWMFriJKBSwDhnm and OgfpqHNubvlEdYCGWMFriJKBSwDhQU.M3U_ONSAMSUNG==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:OgfpqHNubvlEdYCGWMFriJKBSwDhnA=OgfpqHNubvlEdYCGWMFriJKBSwDhnm
  if OgfpqHNubvlEdYCGWMFriJKBSwDhnA==OgfpqHNubvlEdYCGWMFriJKBSwDhnm:
   OgfpqHNubvlEdYCGWMFriJKBSwDhQy=xbmcgui.Dialog()
   OgfpqHNubvlEdYCGWMFriJKBSwDhRQ=OgfpqHNubvlEdYCGWMFriJKBSwDhQy.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if OgfpqHNubvlEdYCGWMFriJKBSwDhRQ==OgfpqHNubvlEdYCGWMFriJKBSwDhsR:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(OgfpqHNubvlEdYCGWMFriJKBSwDhQU):
  OgfpqHNubvlEdYCGWMFriJKBSwDhnT={'date_makeepg':OgfpqHNubvlEdYCGWMFriJKBSwDhQU.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=OgfpqHNubvlEdYCGWMFriJKBSwDhsV(OgfpqHNubvlEdYCGWMFriJKBSwDhQs,'w',-1,'utf-8')
   json.dump(OgfpqHNubvlEdYCGWMFriJKBSwDhnT,fp)
   fp.close()
  except OgfpqHNubvlEdYCGWMFriJKBSwDhsX as exception:
   return
 def boritv_main(OgfpqHNubvlEdYCGWMFriJKBSwDhQU):
  OgfpqHNubvlEdYCGWMFriJKBSwDhnj=OgfpqHNubvlEdYCGWMFriJKBSwDhQU.main_params.get('mode',OgfpqHNubvlEdYCGWMFriJKBSwDhsQ)
  OgfpqHNubvlEdYCGWMFriJKBSwDhQU.check_config()
  if OgfpqHNubvlEdYCGWMFriJKBSwDhnj is OgfpqHNubvlEdYCGWMFriJKBSwDhsQ:
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.dp_Main_List()
  elif OgfpqHNubvlEdYCGWMFriJKBSwDhnj=='DEL_M3U':
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.dp_Delete_M3u(OgfpqHNubvlEdYCGWMFriJKBSwDhQU.main_params)
  elif OgfpqHNubvlEdYCGWMFriJKBSwDhnj=='ADD_M3U':
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.dp_MakeAdd_M3u(OgfpqHNubvlEdYCGWMFriJKBSwDhQU.main_params)
  elif OgfpqHNubvlEdYCGWMFriJKBSwDhnj=='ADD_EPG':
   OgfpqHNubvlEdYCGWMFriJKBSwDhQU.dp_Make_Epg(OgfpqHNubvlEdYCGWMFriJKBSwDhQU.main_params)
  else:
   OgfpqHNubvlEdYCGWMFriJKBSwDhsQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
