__author__="NightRain"
MEQUpKtCLnzrlfGSWsOJekBaPmocDj=object
MEQUpKtCLnzrlfGSWsOJekBaPmocDv=False
MEQUpKtCLnzrlfGSWsOJekBaPmocDb=None
MEQUpKtCLnzrlfGSWsOJekBaPmocDu=True
MEQUpKtCLnzrlfGSWsOJekBaPmocDi=getattr
MEQUpKtCLnzrlfGSWsOJekBaPmocDH=type
MEQUpKtCLnzrlfGSWsOJekBaPmocDy=int
MEQUpKtCLnzrlfGSWsOJekBaPmocDh=list
MEQUpKtCLnzrlfGSWsOJekBaPmocDV=len
MEQUpKtCLnzrlfGSWsOJekBaPmocDg=str
MEQUpKtCLnzrlfGSWsOJekBaPmocDN=open
MEQUpKtCLnzrlfGSWsOJekBaPmocDq=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
MEQUpKtCLnzrlfGSWsOJekBaPmocwI=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'     - M3U 추가 (삼성tv 플러스)','mode':'ADD_M3U','sType':'samsung','sName':'삼성TV 플러스'},{'title':'     - M3U 추가 (사용자 m3u)','mode':'ADD_M3U','sType':'custom','sName':'사용자 m3u 파일'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
MEQUpKtCLnzrlfGSWsOJekBaPmocwD={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MEQUpKtCLnzrlfGSWsOJekBaPmocwT=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class MEQUpKtCLnzrlfGSWsOJekBaPmocwd(MEQUpKtCLnzrlfGSWsOJekBaPmocDj):
 def __init__(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,MEQUpKtCLnzrlfGSWsOJekBaPmocwX,MEQUpKtCLnzrlfGSWsOJekBaPmocwY,MEQUpKtCLnzrlfGSWsOJekBaPmocwj):
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx._addon_url =MEQUpKtCLnzrlfGSWsOJekBaPmocwX
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx._addon_handle =MEQUpKtCLnzrlfGSWsOJekBaPmocwY
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.main_params =MEQUpKtCLnzrlfGSWsOJekBaPmocwj
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_FILE_PATH ='' 
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_FILE_NAME ='' 
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVE =MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONTVING =MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSPOTV =MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSAMSUNG =MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVERADIO =MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVEHOME =MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONRELIGION =MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSPOTVPAY =MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSAMSUNGHOME=MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_DISPLAYNM =MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_AUTORESTART =MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_CUSTOM_LIST =[]
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOX() 
 def addon_noti(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,sting):
  try:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwb=xbmcgui.Dialog()
   MEQUpKtCLnzrlfGSWsOJekBaPmocwb.notification(__addonname__,sting)
  except:
   MEQUpKtCLnzrlfGSWsOJekBaPmocDb
 def addon_log(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,string):
  try:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwu=string.encode('utf-8','ignore')
  except:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwu='addonException: addon_log'
  MEQUpKtCLnzrlfGSWsOJekBaPmocwi=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,MEQUpKtCLnzrlfGSWsOJekBaPmocwu),level=MEQUpKtCLnzrlfGSWsOJekBaPmocwi)
 def get_keyboard_input(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,MEQUpKtCLnzrlfGSWsOJekBaPmocwh):
  MEQUpKtCLnzrlfGSWsOJekBaPmocwH=MEQUpKtCLnzrlfGSWsOJekBaPmocDb
  kb=xbmc.Keyboard()
  kb.setHeading(MEQUpKtCLnzrlfGSWsOJekBaPmocwh)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   MEQUpKtCLnzrlfGSWsOJekBaPmocwH=kb.getText()
  return MEQUpKtCLnzrlfGSWsOJekBaPmocwH
 def add_dir(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,label,sublabel='',img='',infoLabels=MEQUpKtCLnzrlfGSWsOJekBaPmocDb,isFolder=MEQUpKtCLnzrlfGSWsOJekBaPmocDu,params='',isLink=MEQUpKtCLnzrlfGSWsOJekBaPmocDv,ContextMenu=MEQUpKtCLnzrlfGSWsOJekBaPmocDb):
  MEQUpKtCLnzrlfGSWsOJekBaPmocwy='%s?%s'%(MEQUpKtCLnzrlfGSWsOJekBaPmocwx._addon_url,urllib.parse.urlencode(params))
  if sublabel:MEQUpKtCLnzrlfGSWsOJekBaPmocwh='%s < %s >'%(label,sublabel)
  else: MEQUpKtCLnzrlfGSWsOJekBaPmocwh=label
  if not img:img='DefaultFolder.png'
  MEQUpKtCLnzrlfGSWsOJekBaPmocwV=xbmcgui.ListItem(MEQUpKtCLnzrlfGSWsOJekBaPmocwh)
  MEQUpKtCLnzrlfGSWsOJekBaPmocwV.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.KodiVersion>=20:
   if infoLabels:MEQUpKtCLnzrlfGSWsOJekBaPmocwx.Set_InfoTag(MEQUpKtCLnzrlfGSWsOJekBaPmocwV.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:MEQUpKtCLnzrlfGSWsOJekBaPmocwV.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwV.setProperty('IsPlayable','true')
  if ContextMenu:MEQUpKtCLnzrlfGSWsOJekBaPmocwV.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(MEQUpKtCLnzrlfGSWsOJekBaPmocwx._addon_handle,MEQUpKtCLnzrlfGSWsOJekBaPmocwy,MEQUpKtCLnzrlfGSWsOJekBaPmocwV,isFolder)
 def Set_InfoTag(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,video_InfoTag:xbmc.InfoTagVideo,MEQUpKtCLnzrlfGSWsOJekBaPmocwR):
  for MEQUpKtCLnzrlfGSWsOJekBaPmocwg,value in MEQUpKtCLnzrlfGSWsOJekBaPmocwR.items():
   if MEQUpKtCLnzrlfGSWsOJekBaPmocwD[MEQUpKtCLnzrlfGSWsOJekBaPmocwg]['type']=='string':
    MEQUpKtCLnzrlfGSWsOJekBaPmocDi(video_InfoTag,MEQUpKtCLnzrlfGSWsOJekBaPmocwD[MEQUpKtCLnzrlfGSWsOJekBaPmocwg]['func'])(value)
   elif MEQUpKtCLnzrlfGSWsOJekBaPmocwD[MEQUpKtCLnzrlfGSWsOJekBaPmocwg]['type']=='int':
    if MEQUpKtCLnzrlfGSWsOJekBaPmocDH(value)==MEQUpKtCLnzrlfGSWsOJekBaPmocDy:
     MEQUpKtCLnzrlfGSWsOJekBaPmocwN=MEQUpKtCLnzrlfGSWsOJekBaPmocDy(value)
    else:
     MEQUpKtCLnzrlfGSWsOJekBaPmocwN=0
    MEQUpKtCLnzrlfGSWsOJekBaPmocDi(video_InfoTag,MEQUpKtCLnzrlfGSWsOJekBaPmocwD[MEQUpKtCLnzrlfGSWsOJekBaPmocwg]['func'])(MEQUpKtCLnzrlfGSWsOJekBaPmocwN)
   elif MEQUpKtCLnzrlfGSWsOJekBaPmocwD[MEQUpKtCLnzrlfGSWsOJekBaPmocwg]['type']=='actor':
    if value!=[]:
     MEQUpKtCLnzrlfGSWsOJekBaPmocDi(video_InfoTag,MEQUpKtCLnzrlfGSWsOJekBaPmocwD[MEQUpKtCLnzrlfGSWsOJekBaPmocwg]['func'])([xbmc.Actor(name)for name in value])
   elif MEQUpKtCLnzrlfGSWsOJekBaPmocwD[MEQUpKtCLnzrlfGSWsOJekBaPmocwg]['type']=='list':
    if MEQUpKtCLnzrlfGSWsOJekBaPmocDH(value)==MEQUpKtCLnzrlfGSWsOJekBaPmocDh:
     MEQUpKtCLnzrlfGSWsOJekBaPmocDi(video_InfoTag,MEQUpKtCLnzrlfGSWsOJekBaPmocwD[MEQUpKtCLnzrlfGSWsOJekBaPmocwg]['func'])(value)
    else:
     MEQUpKtCLnzrlfGSWsOJekBaPmocDi(video_InfoTag,MEQUpKtCLnzrlfGSWsOJekBaPmocwD[MEQUpKtCLnzrlfGSWsOJekBaPmocwg]['func'])([value])
 def make_M3u_Filename(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDv):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_FILE_PATH+MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDv):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_FILE_PATH+MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_FILE_NAME+'.xml'
 def dp_Main_List(MEQUpKtCLnzrlfGSWsOJekBaPmocwx):
  for MEQUpKtCLnzrlfGSWsOJekBaPmocwq in MEQUpKtCLnzrlfGSWsOJekBaPmocwI:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwh=MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('title')
   MEQUpKtCLnzrlfGSWsOJekBaPmocwF=''
   MEQUpKtCLnzrlfGSWsOJekBaPmocwA={'mode':MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('mode'),'sType':MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('sType'),'sName':MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('sName')}
   MEQUpKtCLnzrlfGSWsOJekBaPmocwR={'title':MEQUpKtCLnzrlfGSWsOJekBaPmocwh,'plot':MEQUpKtCLnzrlfGSWsOJekBaPmocwh}
   if MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('mode')=='XXX':
    MEQUpKtCLnzrlfGSWsOJekBaPmocdw=MEQUpKtCLnzrlfGSWsOJekBaPmocDv
    MEQUpKtCLnzrlfGSWsOJekBaPmocdI =MEQUpKtCLnzrlfGSWsOJekBaPmocDu
   else:
    MEQUpKtCLnzrlfGSWsOJekBaPmocdw=MEQUpKtCLnzrlfGSWsOJekBaPmocDu
    MEQUpKtCLnzrlfGSWsOJekBaPmocdI =MEQUpKtCLnzrlfGSWsOJekBaPmocDv
   MEQUpKtCLnzrlfGSWsOJekBaPmocdD=MEQUpKtCLnzrlfGSWsOJekBaPmocDu
   if MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('mode')=='ADD_M3U':
    if MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('sType')=='wavve' and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVE ==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:MEQUpKtCLnzrlfGSWsOJekBaPmocdD=MEQUpKtCLnzrlfGSWsOJekBaPmocDv
    if MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('sType')=='tving' and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONTVING ==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:MEQUpKtCLnzrlfGSWsOJekBaPmocdD=MEQUpKtCLnzrlfGSWsOJekBaPmocDv
    if MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('sType')=='spotv' and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSPOTV ==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:MEQUpKtCLnzrlfGSWsOJekBaPmocdD=MEQUpKtCLnzrlfGSWsOJekBaPmocDv
    if MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('sType')=='samsung' and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSAMSUNG==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:MEQUpKtCLnzrlfGSWsOJekBaPmocdD=MEQUpKtCLnzrlfGSWsOJekBaPmocDv
    if MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('sType')=='custom' and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_CUSTOM_LIST==[]:MEQUpKtCLnzrlfGSWsOJekBaPmocdD=MEQUpKtCLnzrlfGSWsOJekBaPmocDv
   if MEQUpKtCLnzrlfGSWsOJekBaPmocdD==MEQUpKtCLnzrlfGSWsOJekBaPmocDu:
    if 'icon' in MEQUpKtCLnzrlfGSWsOJekBaPmocwq:MEQUpKtCLnzrlfGSWsOJekBaPmocwF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',MEQUpKtCLnzrlfGSWsOJekBaPmocwq.get('icon')) 
    MEQUpKtCLnzrlfGSWsOJekBaPmocwx.add_dir(MEQUpKtCLnzrlfGSWsOJekBaPmocwh,sublabel='',img=MEQUpKtCLnzrlfGSWsOJekBaPmocwF,infoLabels=MEQUpKtCLnzrlfGSWsOJekBaPmocwR,isFolder=MEQUpKtCLnzrlfGSWsOJekBaPmocdw,params=MEQUpKtCLnzrlfGSWsOJekBaPmocwA,isLink=MEQUpKtCLnzrlfGSWsOJekBaPmocdI)
  if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocwI)>0:xbmcplugin.endOfDirectory(MEQUpKtCLnzrlfGSWsOJekBaPmocwx._addon_handle,cacheToDisc=MEQUpKtCLnzrlfGSWsOJekBaPmocDu)
 def dp_Delete_M3u(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,args):
  MEQUpKtCLnzrlfGSWsOJekBaPmocwb=xbmcgui.Dialog()
  MEQUpKtCLnzrlfGSWsOJekBaPmocdx=MEQUpKtCLnzrlfGSWsOJekBaPmocwb.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if MEQUpKtCLnzrlfGSWsOJekBaPmocdx==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:sys.exit()
  MEQUpKtCLnzrlfGSWsOJekBaPmocdX=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_M3u_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDv)
  if xbmcvfs.exists(MEQUpKtCLnzrlfGSWsOJekBaPmocdX):
   if xbmcvfs.delete(MEQUpKtCLnzrlfGSWsOJekBaPmocdX)==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:
    MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti(__language__(30910).encode('utf-8'))
    return
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,args):
  MEQUpKtCLnzrlfGSWsOJekBaPmocdY=args.get('sType')
  MEQUpKtCLnzrlfGSWsOJekBaPmocdj=args.get('sName')
  MEQUpKtCLnzrlfGSWsOJekBaPmocwb=xbmcgui.Dialog()
  MEQUpKtCLnzrlfGSWsOJekBaPmocdx=MEQUpKtCLnzrlfGSWsOJekBaPmocwb.yesno((MEQUpKtCLnzrlfGSWsOJekBaPmocdj+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if MEQUpKtCLnzrlfGSWsOJekBaPmocdx==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:sys.exit()
  MEQUpKtCLnzrlfGSWsOJekBaPmocdv =[]
  MEQUpKtCLnzrlfGSWsOJekBaPmocdb =[]
  MEQUpKtCLnzrlfGSWsOJekBaPmocdX=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_M3u_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDu)
  if os.path.isfile(MEQUpKtCLnzrlfGSWsOJekBaPmocdX):os.remove(MEQUpKtCLnzrlfGSWsOJekBaPmocdX)
  if MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='all':
   MEQUpKtCLnzrlfGSWsOJekBaPmocdX=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_M3u_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDv)
   if xbmcvfs.exists(MEQUpKtCLnzrlfGSWsOJekBaPmocdX):
    if xbmcvfs.delete(MEQUpKtCLnzrlfGSWsOJekBaPmocdX)==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:
     MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   MEQUpKtCLnzrlfGSWsOJekBaPmocdu=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_M3u_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDv)
   if xbmcvfs.exists(MEQUpKtCLnzrlfGSWsOJekBaPmocdu):
    MEQUpKtCLnzrlfGSWsOJekBaPmocdi=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_M3u_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDu)
    xbmcvfs.copy(MEQUpKtCLnzrlfGSWsOJekBaPmocdu,MEQUpKtCLnzrlfGSWsOJekBaPmocdi)
  if(MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='wavve' or MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='all')and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVE:
   MEQUpKtCLnzrlfGSWsOJekBaPmocdH=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_ChannelList_Wavve(exceptGroup=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_EexceptGroup_Wavve())
   if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)!=0:MEQUpKtCLnzrlfGSWsOJekBaPmocdv.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_log('wavve cnt ----> '+MEQUpKtCLnzrlfGSWsOJekBaPmocDg(MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)))
  if(MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='tving' or MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='all')and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONTVING:
   MEQUpKtCLnzrlfGSWsOJekBaPmocdH=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_ChannelList_Tving()
   if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)!=0:MEQUpKtCLnzrlfGSWsOJekBaPmocdv.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_log('tving cnt ----> '+MEQUpKtCLnzrlfGSWsOJekBaPmocDg(MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)))
  if(MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='spotv' or MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='all')and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSPOTV:
   MEQUpKtCLnzrlfGSWsOJekBaPmocdH=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_ChannelList_Spotv(payyn=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSPOTVPAY)
   if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)!=0:MEQUpKtCLnzrlfGSWsOJekBaPmocdv.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_log('spotv cnt ----> '+MEQUpKtCLnzrlfGSWsOJekBaPmocDg(MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)))
  if(MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='samsung' or MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='all')and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSAMSUNG:
   MEQUpKtCLnzrlfGSWsOJekBaPmocdy=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_BaseInfo_Samsungtv()
   MEQUpKtCLnzrlfGSWsOJekBaPmocdH=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_ChannelList_Samsungtv(MEQUpKtCLnzrlfGSWsOJekBaPmocdy,exceptGroup=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_EexceptGroup_Samsungtv())
   if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)!=0:MEQUpKtCLnzrlfGSWsOJekBaPmocdv.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_log('samsungtv cnt ----> '+MEQUpKtCLnzrlfGSWsOJekBaPmocDg(MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocdH)))
  if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocdv)==0 and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_CUSTOM_LIST==[]:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti(__language__(30909).encode('utf8'))
   return
  for MEQUpKtCLnzrlfGSWsOJekBaPmocdh in MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.INIT_GENRESORT:
   for MEQUpKtCLnzrlfGSWsOJekBaPmocdV in MEQUpKtCLnzrlfGSWsOJekBaPmocdv:
    if MEQUpKtCLnzrlfGSWsOJekBaPmocdV['genrenm']==MEQUpKtCLnzrlfGSWsOJekBaPmocdh:
     MEQUpKtCLnzrlfGSWsOJekBaPmocdb.append(MEQUpKtCLnzrlfGSWsOJekBaPmocdV)
  for MEQUpKtCLnzrlfGSWsOJekBaPmocdV in MEQUpKtCLnzrlfGSWsOJekBaPmocdv:
   if MEQUpKtCLnzrlfGSWsOJekBaPmocdV['genrenm']not in MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.INIT_GENRESORT:
    MEQUpKtCLnzrlfGSWsOJekBaPmocdb.append(MEQUpKtCLnzrlfGSWsOJekBaPmocdV)
  try:
   if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocdv)>0:
    MEQUpKtCLnzrlfGSWsOJekBaPmocdX=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_M3u_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDu)
    if os.path.isfile(MEQUpKtCLnzrlfGSWsOJekBaPmocdX):
     fp=MEQUpKtCLnzrlfGSWsOJekBaPmocDN(MEQUpKtCLnzrlfGSWsOJekBaPmocdX,'a',-1,'utf-8')
    else:
     fp=MEQUpKtCLnzrlfGSWsOJekBaPmocDN(MEQUpKtCLnzrlfGSWsOJekBaPmocdX,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for MEQUpKtCLnzrlfGSWsOJekBaPmocdg in MEQUpKtCLnzrlfGSWsOJekBaPmocdb:
     MEQUpKtCLnzrlfGSWsOJekBaPmocdN =MEQUpKtCLnzrlfGSWsOJekBaPmocdg['channelid']
     MEQUpKtCLnzrlfGSWsOJekBaPmocdq =MEQUpKtCLnzrlfGSWsOJekBaPmocdg['channelnm']
     MEQUpKtCLnzrlfGSWsOJekBaPmocdF=MEQUpKtCLnzrlfGSWsOJekBaPmocdg['channelimg']
     MEQUpKtCLnzrlfGSWsOJekBaPmocdA =MEQUpKtCLnzrlfGSWsOJekBaPmocdg['ott']
     MEQUpKtCLnzrlfGSWsOJekBaPmocdR ='%s.%s'%(MEQUpKtCLnzrlfGSWsOJekBaPmocdN,MEQUpKtCLnzrlfGSWsOJekBaPmocdA)
     MEQUpKtCLnzrlfGSWsOJekBaPmocIw=MEQUpKtCLnzrlfGSWsOJekBaPmocdg['genrenm']
     if MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_DISPLAYNM:
      MEQUpKtCLnzrlfGSWsOJekBaPmocdq='%s (%s)'%(MEQUpKtCLnzrlfGSWsOJekBaPmocdq,MEQUpKtCLnzrlfGSWsOJekBaPmocdA)
     if MEQUpKtCLnzrlfGSWsOJekBaPmocIw=='라디오/음악':
      MEQUpKtCLnzrlfGSWsOJekBaPmocId='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(MEQUpKtCLnzrlfGSWsOJekBaPmocdR,MEQUpKtCLnzrlfGSWsOJekBaPmocdq,MEQUpKtCLnzrlfGSWsOJekBaPmocIw,MEQUpKtCLnzrlfGSWsOJekBaPmocdF,MEQUpKtCLnzrlfGSWsOJekBaPmocdq)
     else:
      MEQUpKtCLnzrlfGSWsOJekBaPmocId='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(MEQUpKtCLnzrlfGSWsOJekBaPmocdR,MEQUpKtCLnzrlfGSWsOJekBaPmocdq,MEQUpKtCLnzrlfGSWsOJekBaPmocIw,MEQUpKtCLnzrlfGSWsOJekBaPmocdF,MEQUpKtCLnzrlfGSWsOJekBaPmocdq)
     if MEQUpKtCLnzrlfGSWsOJekBaPmocdA=='wavve':
      MEQUpKtCLnzrlfGSWsOJekBaPmocID ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(MEQUpKtCLnzrlfGSWsOJekBaPmocdN)
     elif MEQUpKtCLnzrlfGSWsOJekBaPmocdA=='tving':
      MEQUpKtCLnzrlfGSWsOJekBaPmocID ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(MEQUpKtCLnzrlfGSWsOJekBaPmocdN)
     elif MEQUpKtCLnzrlfGSWsOJekBaPmocdA=='spotv':
      MEQUpKtCLnzrlfGSWsOJekBaPmocID ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(MEQUpKtCLnzrlfGSWsOJekBaPmocdN)
     if MEQUpKtCLnzrlfGSWsOJekBaPmocdA=='samsung':
      MEQUpKtCLnzrlfGSWsOJekBaPmocID ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(MEQUpKtCLnzrlfGSWsOJekBaPmocdN)
     fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocId)
     fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocID)
    fp.close()
  except:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti(__language__(30910).encode('utf8'))
   return
  try:
   if(MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='custom' or MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='all')and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_CUSTOM_LIST!=[]:
    MEQUpKtCLnzrlfGSWsOJekBaPmocdX=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_M3u_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDu)
    if os.path.isfile(MEQUpKtCLnzrlfGSWsOJekBaPmocdX):
     fp=MEQUpKtCLnzrlfGSWsOJekBaPmocDN(MEQUpKtCLnzrlfGSWsOJekBaPmocdX,'a',-1,'utf-8')
    else:
     fp=MEQUpKtCLnzrlfGSWsOJekBaPmocDN(MEQUpKtCLnzrlfGSWsOJekBaPmocdX,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for MEQUpKtCLnzrlfGSWsOJekBaPmocIT in MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_CUSTOM_LIST:
     MEQUpKtCLnzrlfGSWsOJekBaPmocIx=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.customEpg_FileRead(MEQUpKtCLnzrlfGSWsOJekBaPmocIT)
     for MEQUpKtCLnzrlfGSWsOJekBaPmocIX in MEQUpKtCLnzrlfGSWsOJekBaPmocIx:
      MEQUpKtCLnzrlfGSWsOJekBaPmocIX=MEQUpKtCLnzrlfGSWsOJekBaPmocIX.strip()
      if MEQUpKtCLnzrlfGSWsOJekBaPmocIX not in['','#EXTM3U']:
       fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocIX+'\n')
   fp.close()
  except:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti(__language__(30910).encode('utf8'))
   return
  MEQUpKtCLnzrlfGSWsOJekBaPmocdu=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_M3u_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDu)
  MEQUpKtCLnzrlfGSWsOJekBaPmocdi=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_M3u_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDv)
  if xbmcvfs.copy(MEQUpKtCLnzrlfGSWsOJekBaPmocdu,MEQUpKtCLnzrlfGSWsOJekBaPmocdi):
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti((MEQUpKtCLnzrlfGSWsOJekBaPmocdj+' '+__language__(30908)).encode('utf8'))
  else:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti(__language__(30910).encode('utf-8'))
 def customEpg_FileList(MEQUpKtCLnzrlfGSWsOJekBaPmocwx):
  MEQUpKtCLnzrlfGSWsOJekBaPmocIY=[]
  if __addon__.getSetting('custom01on')=='true':MEQUpKtCLnzrlfGSWsOJekBaPmocIY.append(__addon__.getSetting('custom01nm'))
  if __addon__.getSetting('custom02on')=='true':MEQUpKtCLnzrlfGSWsOJekBaPmocIY.append(__addon__.getSetting('custom02nm'))
  if __addon__.getSetting('custom03on')=='true':MEQUpKtCLnzrlfGSWsOJekBaPmocIY.append(__addon__.getSetting('custom03nm'))
  if __addon__.getSetting('custom04on')=='true':MEQUpKtCLnzrlfGSWsOJekBaPmocIY.append(__addon__.getSetting('custom04nm'))
  if __addon__.getSetting('custom05on')=='true':MEQUpKtCLnzrlfGSWsOJekBaPmocIY.append(__addon__.getSetting('custom05nm'))
  return MEQUpKtCLnzrlfGSWsOJekBaPmocIY
 def customEpg_FileRead(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,source_filename):
  try:
   MEQUpKtCLnzrlfGSWsOJekBaPmocIj=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
   if os.path.isfile(MEQUpKtCLnzrlfGSWsOJekBaPmocIj):os.remove(MEQUpKtCLnzrlfGSWsOJekBaPmocIj)
   xbmcvfs.copy(source_filename,MEQUpKtCLnzrlfGSWsOJekBaPmocIj)
   fp=MEQUpKtCLnzrlfGSWsOJekBaPmocDN(MEQUpKtCLnzrlfGSWsOJekBaPmocIj,'r',-1,'utf-8')
   MEQUpKtCLnzrlfGSWsOJekBaPmocIv=fp.readlines()
  except:
   return[]
  return MEQUpKtCLnzrlfGSWsOJekBaPmocIv
 def dp_Make_Epg(MEQUpKtCLnzrlfGSWsOJekBaPmocwx,args):
  MEQUpKtCLnzrlfGSWsOJekBaPmocdY=args.get('sType')
  MEQUpKtCLnzrlfGSWsOJekBaPmocdj=args.get('sName')
  MEQUpKtCLnzrlfGSWsOJekBaPmocIb=args.get('sNoti')
  if MEQUpKtCLnzrlfGSWsOJekBaPmocIb!='N':
   MEQUpKtCLnzrlfGSWsOJekBaPmocwb=xbmcgui.Dialog()
   MEQUpKtCLnzrlfGSWsOJekBaPmocdx=MEQUpKtCLnzrlfGSWsOJekBaPmocwb.yesno((MEQUpKtCLnzrlfGSWsOJekBaPmocdj+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if MEQUpKtCLnzrlfGSWsOJekBaPmocdx==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:sys.exit()
  MEQUpKtCLnzrlfGSWsOJekBaPmocIu=[]
  MEQUpKtCLnzrlfGSWsOJekBaPmocIi=[]
  if(MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='wavve' or MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='all')and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVE:
   MEQUpKtCLnzrlfGSWsOJekBaPmocIH,MEQUpKtCLnzrlfGSWsOJekBaPmocIy=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_EexceptGroup_Wavve())
   if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocIy)!=0:
    MEQUpKtCLnzrlfGSWsOJekBaPmocIu.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocIH)
    MEQUpKtCLnzrlfGSWsOJekBaPmocIi.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocIy)
  if(MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='tving' or MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='all')and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONTVING:
   MEQUpKtCLnzrlfGSWsOJekBaPmocIH,MEQUpKtCLnzrlfGSWsOJekBaPmocIy=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_EpgInfo_Tving()
   if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocIy)!=0:
    MEQUpKtCLnzrlfGSWsOJekBaPmocIu.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocIH)
    MEQUpKtCLnzrlfGSWsOJekBaPmocIi.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocIy)
  if(MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='spotv' or MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='all')and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSPOTV:
   MEQUpKtCLnzrlfGSWsOJekBaPmocIH,MEQUpKtCLnzrlfGSWsOJekBaPmocIy=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_EpgInfo_Spotv(payyn=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSPOTVPAY)
   if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocIy)!=0:
    MEQUpKtCLnzrlfGSWsOJekBaPmocIu.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocIH)
    MEQUpKtCLnzrlfGSWsOJekBaPmocIi.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocIy)
  if(MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='samsung' or MEQUpKtCLnzrlfGSWsOJekBaPmocdY=='all')and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSAMSUNG:
   MEQUpKtCLnzrlfGSWsOJekBaPmocdy=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_BaseInfo_Samsungtv()
   MEQUpKtCLnzrlfGSWsOJekBaPmocIH,MEQUpKtCLnzrlfGSWsOJekBaPmocIy=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_EpgInfo_Samsungtv(MEQUpKtCLnzrlfGSWsOJekBaPmocdy,exceptGroup=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_EexceptGroup_Samsungtv())
   if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocIy)!=0:
    MEQUpKtCLnzrlfGSWsOJekBaPmocIu.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocIH)
    MEQUpKtCLnzrlfGSWsOJekBaPmocIi.extend(MEQUpKtCLnzrlfGSWsOJekBaPmocIy)
  if MEQUpKtCLnzrlfGSWsOJekBaPmocDV(MEQUpKtCLnzrlfGSWsOJekBaPmocIi)==0:
   if MEQUpKtCLnzrlfGSWsOJekBaPmocIb!='N':MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   MEQUpKtCLnzrlfGSWsOJekBaPmocdX=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_Epg_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDu)
   fp=MEQUpKtCLnzrlfGSWsOJekBaPmocDN(MEQUpKtCLnzrlfGSWsOJekBaPmocdX,'w',-1,'utf-8')
   MEQUpKtCLnzrlfGSWsOJekBaPmocIh='<?xml version="1.0" encoding="UTF-8"?>\n'
   MEQUpKtCLnzrlfGSWsOJekBaPmocIV='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   MEQUpKtCLnzrlfGSWsOJekBaPmocIg='<tv generator-info-name="boritv_epg">\n\n'
   MEQUpKtCLnzrlfGSWsOJekBaPmocIN='\n</tv>\n'
   fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocIh)
   fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocIV)
   fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocIg)
   for MEQUpKtCLnzrlfGSWsOJekBaPmocIq in MEQUpKtCLnzrlfGSWsOJekBaPmocIu:
    MEQUpKtCLnzrlfGSWsOJekBaPmocIF='  <channel id="%s.%s">\n' %(MEQUpKtCLnzrlfGSWsOJekBaPmocIq.get('channelid'),MEQUpKtCLnzrlfGSWsOJekBaPmocIq.get('ott'))
    MEQUpKtCLnzrlfGSWsOJekBaPmocIA='    <display-name>%s</display-name>\n'%(MEQUpKtCLnzrlfGSWsOJekBaPmocIq.get('channelnm'))
    MEQUpKtCLnzrlfGSWsOJekBaPmocIR='    <icon src="%s" />\n' %(MEQUpKtCLnzrlfGSWsOJekBaPmocIq.get('channelimg'))
    MEQUpKtCLnzrlfGSWsOJekBaPmocDw='  </channel>\n\n'
    fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocIF)
    fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocIA)
    fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocIR)
    fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocDw)
   for MEQUpKtCLnzrlfGSWsOJekBaPmocIq in MEQUpKtCLnzrlfGSWsOJekBaPmocIi:
    MEQUpKtCLnzrlfGSWsOJekBaPmocIF='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(MEQUpKtCLnzrlfGSWsOJekBaPmocIq.get('startTime'),MEQUpKtCLnzrlfGSWsOJekBaPmocIq.get('endTime'),MEQUpKtCLnzrlfGSWsOJekBaPmocIq.get('channelid'),MEQUpKtCLnzrlfGSWsOJekBaPmocIq.get('ott'))
    MEQUpKtCLnzrlfGSWsOJekBaPmocIA='    <title lang="kr">%s</title>\n' %(MEQUpKtCLnzrlfGSWsOJekBaPmocIq.get('title'))
    MEQUpKtCLnzrlfGSWsOJekBaPmocIR='  </programme>\n\n'
    fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocIF)
    fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocIA)
    fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocIR)
   fp.write(MEQUpKtCLnzrlfGSWsOJekBaPmocIN)
   fp.close()
  except:
   if MEQUpKtCLnzrlfGSWsOJekBaPmocIb!='N':MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti(__language__(30910).encode('utf8'))
   return
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.MakeEpg_SaveJson()
  MEQUpKtCLnzrlfGSWsOJekBaPmocdu=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_Epg_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDu)
  MEQUpKtCLnzrlfGSWsOJekBaPmocdi=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.make_Epg_Filename(tempyn=MEQUpKtCLnzrlfGSWsOJekBaPmocDv)
  if xbmcvfs.copy(MEQUpKtCLnzrlfGSWsOJekBaPmocdu,MEQUpKtCLnzrlfGSWsOJekBaPmocdi):
   if MEQUpKtCLnzrlfGSWsOJekBaPmocIb!='N':MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti((MEQUpKtCLnzrlfGSWsOJekBaPmocdj+' '+__language__(30912)).encode('utf8'))
  else:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_AUTORESTART:
    MEQUpKtCLnzrlfGSWsOJekBaPmocDd=xbmcaddon.Addon('pvr.iptvsimple')
    MEQUpKtCLnzrlfGSWsOJekBaPmocDd.setSetting('anything','anything')
  except:
   MEQUpKtCLnzrlfGSWsOJekBaPmocDb 
 def make_EexceptGroup_Wavve(MEQUpKtCLnzrlfGSWsOJekBaPmocwx):
  MEQUpKtCLnzrlfGSWsOJekBaPmocDI=[]
  if MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVERADIO==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:
   MEQUpKtCLnzrlfGSWsOJekBaPmocDI.append('라디오/음악')
  if MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVEHOME==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:
   MEQUpKtCLnzrlfGSWsOJekBaPmocDI.append('홈쇼핑')
  if MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONRELIGION==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:
   MEQUpKtCLnzrlfGSWsOJekBaPmocDI.append('종교')
  return MEQUpKtCLnzrlfGSWsOJekBaPmocDI
 def make_EexceptGroup_Samsungtv(MEQUpKtCLnzrlfGSWsOJekBaPmocwx):
  MEQUpKtCLnzrlfGSWsOJekBaPmocDI=[]
  if MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSAMSUNGHOME==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:
   MEQUpKtCLnzrlfGSWsOJekBaPmocDI.append('홈쇼핑')
  return MEQUpKtCLnzrlfGSWsOJekBaPmocDI
 def get_radio_list(MEQUpKtCLnzrlfGSWsOJekBaPmocwx):
  if MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVERADIO==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:return[]
  MEQUpKtCLnzrlfGSWsOJekBaPmocDT=[{'broadcastid':'46584','genre':'10'}]
  return MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_ChannelList_WavveExcept(MEQUpKtCLnzrlfGSWsOJekBaPmocDT)
 def check_config(MEQUpKtCLnzrlfGSWsOJekBaPmocwx):
  MEQUpKtCLnzrlfGSWsOJekBaPmocDx=MEQUpKtCLnzrlfGSWsOJekBaPmocDu
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVE =MEQUpKtCLnzrlfGSWsOJekBaPmocDu if __addon__.getSetting('onWavve')=='true' else MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONTVING =MEQUpKtCLnzrlfGSWsOJekBaPmocDu if __addon__.getSetting('onTvng')=='true' else MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSPOTV =MEQUpKtCLnzrlfGSWsOJekBaPmocDu if __addon__.getSetting('onSpotv')=='true' else MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSAMSUNG =MEQUpKtCLnzrlfGSWsOJekBaPmocDu if __addon__.getSetting('onSamsung')=='true' else MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVERADIO =MEQUpKtCLnzrlfGSWsOJekBaPmocDu if __addon__.getSetting('onWavveRadio')=='true' else MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVEHOME =MEQUpKtCLnzrlfGSWsOJekBaPmocDu if __addon__.getSetting('onWavveHome')=='true' else MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONRELIGION =MEQUpKtCLnzrlfGSWsOJekBaPmocDu if __addon__.getSetting('onWavveReligion')=='true' else MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSPOTVPAY =MEQUpKtCLnzrlfGSWsOJekBaPmocDu if __addon__.getSetting('onSpotvPay')=='true' else MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSAMSUNGHOME =MEQUpKtCLnzrlfGSWsOJekBaPmocDu if __addon__.getSetting('onSamsungHome')=='true' else MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_DISPLAYNM =MEQUpKtCLnzrlfGSWsOJekBaPmocDu if __addon__.getSetting('displayOTTnm')=='true' else MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_AUTORESTART =MEQUpKtCLnzrlfGSWsOJekBaPmocDu if __addon__.getSetting('autoRestart')=='true' else MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_CUSTOM_LIST =MEQUpKtCLnzrlfGSWsOJekBaPmocwx.customEpg_FileList()
  if MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_FILE_PATH=='' or MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_FILE_NAME=='':MEQUpKtCLnzrlfGSWsOJekBaPmocDx=MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  if MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONWAVVE==MEQUpKtCLnzrlfGSWsOJekBaPmocDv and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONTVING==MEQUpKtCLnzrlfGSWsOJekBaPmocDv and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSPOTV==MEQUpKtCLnzrlfGSWsOJekBaPmocDv and MEQUpKtCLnzrlfGSWsOJekBaPmocwx.M3U_ONSAMSUNG==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:MEQUpKtCLnzrlfGSWsOJekBaPmocDx=MEQUpKtCLnzrlfGSWsOJekBaPmocDv
  if MEQUpKtCLnzrlfGSWsOJekBaPmocDx==MEQUpKtCLnzrlfGSWsOJekBaPmocDv:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwb=xbmcgui.Dialog()
   MEQUpKtCLnzrlfGSWsOJekBaPmocdx=MEQUpKtCLnzrlfGSWsOJekBaPmocwb.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if MEQUpKtCLnzrlfGSWsOJekBaPmocdx==MEQUpKtCLnzrlfGSWsOJekBaPmocDu:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(MEQUpKtCLnzrlfGSWsOJekBaPmocwx):
  MEQUpKtCLnzrlfGSWsOJekBaPmocDX={'date_makeepg':MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=MEQUpKtCLnzrlfGSWsOJekBaPmocDN(MEQUpKtCLnzrlfGSWsOJekBaPmocwT,'w',-1,'utf-8')
   json.dump(MEQUpKtCLnzrlfGSWsOJekBaPmocDX,fp)
   fp.close()
  except MEQUpKtCLnzrlfGSWsOJekBaPmocDq as exception:
   return
 def boritv_main(MEQUpKtCLnzrlfGSWsOJekBaPmocwx):
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.BoritvObj.KodiVersion=MEQUpKtCLnzrlfGSWsOJekBaPmocDy(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  MEQUpKtCLnzrlfGSWsOJekBaPmocDY=MEQUpKtCLnzrlfGSWsOJekBaPmocwx.main_params.get('mode',MEQUpKtCLnzrlfGSWsOJekBaPmocDb)
  MEQUpKtCLnzrlfGSWsOJekBaPmocwx.check_config()
  if MEQUpKtCLnzrlfGSWsOJekBaPmocDY is MEQUpKtCLnzrlfGSWsOJekBaPmocDb:
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.dp_Main_List()
  elif MEQUpKtCLnzrlfGSWsOJekBaPmocDY=='DEL_M3U':
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.dp_Delete_M3u(MEQUpKtCLnzrlfGSWsOJekBaPmocwx.main_params)
  elif MEQUpKtCLnzrlfGSWsOJekBaPmocDY=='ADD_M3U':
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.dp_MakeAdd_M3u(MEQUpKtCLnzrlfGSWsOJekBaPmocwx.main_params)
  elif MEQUpKtCLnzrlfGSWsOJekBaPmocDY=='ADD_EPG':
   MEQUpKtCLnzrlfGSWsOJekBaPmocwx.dp_Make_Epg(MEQUpKtCLnzrlfGSWsOJekBaPmocwx.main_params)
  else:
   MEQUpKtCLnzrlfGSWsOJekBaPmocDb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
