__author__="NightRain"
nkpQDAdqTzPcgtsFJyxCYHSfUmvwjG=False
nkpQDAdqTzPcgtsFJyxCYHSfUmvwjl=object
nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM=None
nkpQDAdqTzPcgtsFJyxCYHSfUmvwja=str
nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo=Exception
nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr=print
nkpQDAdqTzPcgtsFJyxCYHSfUmvwjL=True
nkpQDAdqTzPcgtsFJyxCYHSfUmvwhO=int
nkpQDAdqTzPcgtsFJyxCYHSfUmvwhX=range
nkpQDAdqTzPcgtsFJyxCYHSfUmvwhE=len
nkpQDAdqTzPcgtsFJyxCYHSfUmvwhj=dict
nkpQDAdqTzPcgtsFJyxCYHSfUmvwhe=set
nkpQDAdqTzPcgtsFJyxCYHSfUmvwhK=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
nkpQDAdqTzPcgtsFJyxCYHSfUmvwOE=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
nkpQDAdqTzPcgtsFJyxCYHSfUmvwOj=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':nkpQDAdqTzPcgtsFJyxCYHSfUmvwjG,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':nkpQDAdqTzPcgtsFJyxCYHSfUmvwjG,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':nkpQDAdqTzPcgtsFJyxCYHSfUmvwjG,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':nkpQDAdqTzPcgtsFJyxCYHSfUmvwjG,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':nkpQDAdqTzPcgtsFJyxCYHSfUmvwjG,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':nkpQDAdqTzPcgtsFJyxCYHSfUmvwjG,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class nkpQDAdqTzPcgtsFJyxCYHSfUmvwOX(nkpQDAdqTzPcgtsFJyxCYHSfUmvwjl):
 def __init__(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_WAVVE ='https://apis.wavve.com'
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_TVING ='https://api.tving.com'
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_TVINGIMG ='https://image.tving.com'
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_SPOTV ='https://www.spotvnow.co.kr'
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.HTTPTAG ='https://'
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.LIMIT_WAVVE =200
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.LIMIT_TVING =60
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.LIMIT_TVINGEPG=20 
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.APPVERSION ='115.0.0.0' 
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.DEVICEMODEL ='Chrome' 
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.OSTYPE ='Windows' 
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.OSVERSION ='NT 10.0' 
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.DEFAULT_HEADER={'user-agent':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.USER_AGENT}
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.SLEEP_TIME =0.2
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.INIT_GENRESORT=MASTER_GENRE
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.INIT_CHANNEL =MASTER_CHANNEL
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.KodiVersion =20
 def callRequestCookies(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,jobtype,nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,redirects=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjG):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOB=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.DEFAULT_HEADER
  if headers:nkpQDAdqTzPcgtsFJyxCYHSfUmvwOB.update(headers)
  if jobtype=='Get':
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOb=requests.get(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,params=params,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOB,cookies=cookies,allow_redirects=redirects)
  else:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOb=requests.post(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,data=payload,params=params,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOB,cookies=cookies,allow_redirects=redirects)
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOb
 def Get_DefaultParams_Wavve(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI
 def Get_DefaultParams_Tving(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI
 def Get_Now_Datetime(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,in_text):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOu=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOu
 def Get_ChannelList_Wavve(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,exceptGroup=[]):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV =[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOW=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_ChannelImg_Wavve()
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_WAVVE+'/cf/live/recommend-channels'
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI.update(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_DefaultParams_Wavve())
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
   if not('celllist' in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['cell_toplist']):return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['cell_toplist']['celllist']
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['contentid']
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOo=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['title_list'][0]['text']
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOW:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOr=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOW[nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa]
    else:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOr=''
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_getGenre(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'wavve')
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'channelnm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOo,'channelimg':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.HTTPTAG+nkpQDAdqTzPcgtsFJyxCYHSfUmvwOr if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOr!='' else '','ott':'wavve','genrenm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL}
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL not in exceptGroup:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[]
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV
 def Get_ChannelList_WavveExcept(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,exceptGroup=[]):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV=[]
  if exceptGroup==[]:return[]
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_WAVVE+'/cf/live/recommend-channels'
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in exceptGroup:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI={'WeekDay':'all','adult':'n','broadcastid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['broadcastid'],'contenttype':'channel','genre':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['genre'],'isrecommend':'y','limit':nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI.update(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_DefaultParams_Wavve())
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
    if not('celllist' in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['cell_toplist']):return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['cell_toplist']['celllist']
    for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['contentid'])
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[]
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV
 def Get_ChannelImg_Wavve(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXE={}
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXj=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_Now_Datetime()
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXh =nkpQDAdqTzPcgtsFJyxCYHSfUmvwXj+datetime.timedelta(hours=3)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_WAVVE+'/live/epgs'
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI={'limit':nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwXj.strftime('%Y-%m-%d %H:00'),'enddatetime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwXh.strftime('%Y-%m-%d %H:00')}
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI.update(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_DefaultParams_Wavve())
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['list']
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXE[nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channelid']]=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channelimage']
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwXE
 def Get_ChanneGenrename_Wavve(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa):
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_WAVVE+'/live/channels/'+nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_DefaultParams_Wavve()
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['genretext']
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return ''
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe
 def Get_ChannelList_Spotv(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,payyn=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjL):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV=[]
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_SPOTV+'/api/v3/channel'
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa=nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['id'])
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'channelnm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['name'],'channelimg':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['logo'],'ott':'spotv','genrenm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_getGenre(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'spotv'),'free':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['free']}
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[]
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV
 def Get_ChannelList_Tving(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV =[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXK=[]
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_TVING+'/v2/media/lives'
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI={'pageNo':'1','pageSize':nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI.update(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_DefaultParams_Tving())
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
   if not('result' in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['body']):return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['body']['result']
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl:
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['live_code']=='C44441':continue 
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXK.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['live_code'])
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOW=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_ChannelImg_Tving(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXK)
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['live_code']
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa=='C44441':continue 
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOo=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['schedule']['channel']['name']['ko']
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOW:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOr=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOW[nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa]
    else:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOr=''
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'channelnm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOo,'channelimg':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOr,'ott':'tving','genrenm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_getGenre(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'tving')}
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[]
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV
 def Get_timestamp(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,timetype=1):
  ts=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,timetype):
  if timetype=='1':
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXB={'transactionId':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXB={'timestamp':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_timestamp(timetype=1),'transactionId':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_timestamp(timetype=1)+'000000000000001',}
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwXB
 def make_EpgDatetime_Tving(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,days=2):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXb=[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_DateList(days=2,dateType='2')
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXN=nkpQDAdqTzPcgtsFJyxCYHSfUmvwhO(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI:
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwXu in nkpQDAdqTzPcgtsFJyxCYHSfUmvwhX(8):
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'ndate':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM,'starttm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOE[nkpQDAdqTzPcgtsFJyxCYHSfUmvwXu]['starttm'],'endtm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOE[nkpQDAdqTzPcgtsFJyxCYHSfUmvwXu]['endtm']}
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXV=nkpQDAdqTzPcgtsFJyxCYHSfUmvwhO(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM+nkpQDAdqTzPcgtsFJyxCYHSfUmvwOE[nkpQDAdqTzPcgtsFJyxCYHSfUmvwXu]['starttm'])
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXW=nkpQDAdqTzPcgtsFJyxCYHSfUmvwhO(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM+nkpQDAdqTzPcgtsFJyxCYHSfUmvwOE[nkpQDAdqTzPcgtsFJyxCYHSfUmvwXu]['endtm'])
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwXN<=nkpQDAdqTzPcgtsFJyxCYHSfUmvwXV or(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXV<nkpQDAdqTzPcgtsFJyxCYHSfUmvwXN and nkpQDAdqTzPcgtsFJyxCYHSfUmvwXN<nkpQDAdqTzPcgtsFJyxCYHSfUmvwXW):
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXb.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwXb
 def make_DateList(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,days=2,dateType='1'):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI=[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXi =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_Now_Datetime()
  for i in nkpQDAdqTzPcgtsFJyxCYHSfUmvwhX(days):
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwXi+datetime.timedelta(days=i)
   if dateType=='1':
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXR.strftime('%Y-%m-%d'))
   else:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXR.strftime('%Y%m%d'))
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI
 def make_Tving_ChannleGroup(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,nkpQDAdqTzPcgtsFJyxCYHSfUmvwXK):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXG=[]
  i=0
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXl=''
  for nkpQDAdqTzPcgtsFJyxCYHSfUmvwXM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwXK:
   if i==0:nkpQDAdqTzPcgtsFJyxCYHSfUmvwXl=nkpQDAdqTzPcgtsFJyxCYHSfUmvwXM
   else:nkpQDAdqTzPcgtsFJyxCYHSfUmvwXl+=',%s'%(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXM)
   i+=1
   if i>=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.LIMIT_TVINGEPG:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXG.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXl)
    i=0
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXl=''
  if nkpQDAdqTzPcgtsFJyxCYHSfUmvwXl!='':
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXG.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXl)
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwXG
 def Get_ChannelImg_Tving(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,chid_list):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXE={}
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXa=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_Now_Datetime().strftime('%Y%m%d')
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXj =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOE[6]['starttm'] 
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXh =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOE[6]['endtm']
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXG=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_Tving_ChannleGroup(chid_list)
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwXG:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_TVING+'/v2/media/schedules'
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI={'pageNo':'1','pageSize':nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':nkpQDAdqTzPcgtsFJyxCYHSfUmvwXa,'broadcastDate':nkpQDAdqTzPcgtsFJyxCYHSfUmvwXa,'startBroadTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwXj,'endBroadTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwXh,'channelCode':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM}
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI.update(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_DefaultParams_Tving())
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
    if not('result' in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['body']):return{}
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['body']['result']
    for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl:
     for nkpQDAdqTzPcgtsFJyxCYHSfUmvwXo in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['image']:
      if nkpQDAdqTzPcgtsFJyxCYHSfUmvwXo['code']=='CAIC0400':nkpQDAdqTzPcgtsFJyxCYHSfUmvwXE[nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channel_code']]=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_TVINGIMG+nkpQDAdqTzPcgtsFJyxCYHSfUmvwXo['url']
      elif nkpQDAdqTzPcgtsFJyxCYHSfUmvwXo['code']=='CAIC1400':nkpQDAdqTzPcgtsFJyxCYHSfUmvwXE[nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channel_code']]=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_TVINGIMG+nkpQDAdqTzPcgtsFJyxCYHSfUmvwXo['url']
      elif nkpQDAdqTzPcgtsFJyxCYHSfUmvwXo['code']=='CAIC1900':nkpQDAdqTzPcgtsFJyxCYHSfUmvwXE[nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channel_code']]=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_TVINGIMG+nkpQDAdqTzPcgtsFJyxCYHSfUmvwXo['url']
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return{}
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwXE
 def Get_EpgInfo_Spotv(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,days=2,payyn=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjL):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV=[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr =[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_DateList(days=days,dateType='1')
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_SPOTV+'/api/v3/channel'
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa =nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['id'])
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'channelnm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.xmlText(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['name']),'channelimg':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['logo'],'ott':'spotv'}
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[],[]
  try:
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwXL in nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_SPOTV+'/api/v3/program/'+nkpQDAdqTzPcgtsFJyxCYHSfUmvwXL
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
    for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa =nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channelId'])
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'title':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.xmlText(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['title']),'startTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
    time.sleep(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.SLEEP_TIME)
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[],[]
  '''
  try:
   for i_channel in channel_list:
    if i_channel['epgtype'] == 'spotvon':
     tmp_list = self.Get_EpgInfo_Spotv_spotvon(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    if i_channel['epgtype'] == 'spotvnet':
     tmp_list = self.Get_EpgInfo_Spotv_spotvnet(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV,nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr
 def Get_EpgInfo_Spotv_spotvon(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,epgnm,days):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr =[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_DateList(days=days,dateType='1')
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEO=''
  try:
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwXL in nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,nkpQDAdqTzPcgtsFJyxCYHSfUmvwXL)
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
    for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'title':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.xmlText(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['title']),'startTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['sch_date'].replace('-','')+nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['sch_hour']).zfill(2)+nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['sch_min']+'00','ott':'spotv'}
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwEO=nkpQDAdqTzPcgtsFJyxCYHSfUmvwXL
   for i in nkpQDAdqTzPcgtsFJyxCYHSfUmvwhX(nkpQDAdqTzPcgtsFJyxCYHSfUmvwhE(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr)):
    if i>0:nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i-1]['endTime']=nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i]['startTime']
    if i==nkpQDAdqTzPcgtsFJyxCYHSfUmvwhE(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr)-1: nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i]['endTime']=nkpQDAdqTzPcgtsFJyxCYHSfUmvwEO+'240000'
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[]
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr
 def Get_EpgInfo_Spotv_spotvnet(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,epgnm,days):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr =[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_DateList(days=days,dateType='1')
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEO=''
  try:
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwXL in nkpQDAdqTzPcgtsFJyxCYHSfUmvwXI:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,nkpQDAdqTzPcgtsFJyxCYHSfUmvwXL)
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
    for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'title':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.xmlText(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['title']),'startTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['sch_date'].replace('-','')+nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['sch_hour']).zfill(2)+nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['sch_min']+'00','ott':'spotv'}
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwEO=nkpQDAdqTzPcgtsFJyxCYHSfUmvwXL
   for i in nkpQDAdqTzPcgtsFJyxCYHSfUmvwhX(nkpQDAdqTzPcgtsFJyxCYHSfUmvwhE(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr)):
    if i>0:nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i-1]['endTime']=nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i]['startTime']
    if i==nkpQDAdqTzPcgtsFJyxCYHSfUmvwhE(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr)-1: nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i]['endTime']=nkpQDAdqTzPcgtsFJyxCYHSfUmvwEO+'240000'
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[]
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr
 def Get_EpgInfo_Wavve(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,days=2,exceptGroup=[]):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV =[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr =[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXi =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_Now_Datetime()
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEX =nkpQDAdqTzPcgtsFJyxCYHSfUmvwXi+datetime.timedelta(hours=-2)
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEj =nkpQDAdqTzPcgtsFJyxCYHSfUmvwXi+datetime.timedelta(days=(days-1))
  if nkpQDAdqTzPcgtsFJyxCYHSfUmvwhO(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEX.strftime('%H'))<=3:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwEh=nkpQDAdqTzPcgtsFJyxCYHSfUmvwEX.strftime('%Y-%m-%d 00:00')
  else:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwEh=nkpQDAdqTzPcgtsFJyxCYHSfUmvwEX.strftime('%Y-%m-%d %H:00')
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEe =nkpQDAdqTzPcgtsFJyxCYHSfUmvwEj.strftime('%Y-%m-%d 24:00')
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_WAVVE+'/live/epgs'
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI={'limit':nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEh,'enddatetime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEe}
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI.update(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_DefaultParams_Wavve())
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwEK=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['list']
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwEK:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channelid']
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_getGenre(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'wavve')
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'channelnm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.xmlText(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channelname']),'channelimg':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.HTTPTAG+nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channelimage'],'ott':'wavve'}
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL not in exceptGroup:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
    for nkpQDAdqTzPcgtsFJyxCYHSfUmvwEB in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['list']:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channelid'],'title':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.xmlText(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEB['title']),'startTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEB['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEB['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL not in exceptGroup and nkpQDAdqTzPcgtsFJyxCYHSfUmvwEB['starttime']!=nkpQDAdqTzPcgtsFJyxCYHSfUmvwEB['endtime']:
      nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[],[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEb=nkpQDAdqTzPcgtsFJyxCYHSfUmvwhE(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr)
  for i in(nkpQDAdqTzPcgtsFJyxCYHSfUmvwhX(1,nkpQDAdqTzPcgtsFJyxCYHSfUmvwEb)):
   if nkpQDAdqTzPcgtsFJyxCYHSfUmvwhO(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i-1]['endTime'])+1==nkpQDAdqTzPcgtsFJyxCYHSfUmvwhO(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i]['startTime'])and nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i-1]['channelid']==nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i]['channelid']:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i-1]['endTime']=nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr[i]['startTime']
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV,nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr
 def Get_EpgInfo_Tving(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,days=2):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV=[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr =[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEI =[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEN =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_EpgDatetime_Tving(days=days)
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_ChannelList_Tving()
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEu=[]
  for i in nkpQDAdqTzPcgtsFJyxCYHSfUmvwhX(nkpQDAdqTzPcgtsFJyxCYHSfUmvwhE(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV)):
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV[i]['channelnm']=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.xmlText(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV[i]['channelnm'])
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwEu.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV[i]['channelid'])
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEV=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_Tving_ChannleGroup(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEu)
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_TVING+'/v2/media/schedules'
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwEW in nkpQDAdqTzPcgtsFJyxCYHSfUmvwEN:
    for nkpQDAdqTzPcgtsFJyxCYHSfUmvwEi in nkpQDAdqTzPcgtsFJyxCYHSfUmvwEV:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI={'pageNo':'1','pageSize':nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEW['ndate'],'broadcastDate':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEW['ndate'],'startBroadTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEW['starttm'],'endBroadTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEW['endtm'],'channelCode':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEi}
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI.update(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_DefaultParams_Tving())
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['body']['result']
     for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl:
      if 'schedules' not in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM:continue
      if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['schedules']==nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM:continue
      for nkpQDAdqTzPcgtsFJyxCYHSfUmvwER in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['schedules']:
       nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwER['schedule_code'],'title':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.xmlText(nkpQDAdqTzPcgtsFJyxCYHSfUmvwER['program']['name']['ko']),'startTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwER['broadcast_start_time']),'endTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwER['broadcast_end_time']),'ott':'tving'}
       nkpQDAdqTzPcgtsFJyxCYHSfUmvwEG=nkpQDAdqTzPcgtsFJyxCYHSfUmvwER['schedule_code']+nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwER['broadcast_start_time'])
       if nkpQDAdqTzPcgtsFJyxCYHSfUmvwEG in nkpQDAdqTzPcgtsFJyxCYHSfUmvwEI:continue
       nkpQDAdqTzPcgtsFJyxCYHSfUmvwEI.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEG)
       nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
     time.sleep(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.SLEEP_TIME)
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[],[]
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV,nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr
 def Get_BaseInfo_Samsungtv(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl={}
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_SAMSUNGTV
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM)
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwEM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.cookies:
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwEM.name=='session':
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl['session']=nkpQDAdqTzPcgtsFJyxCYHSfUmvwEM.value
    elif nkpQDAdqTzPcgtsFJyxCYHSfUmvwEM.name=='session.sig':
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl['session.sig']=nkpQDAdqTzPcgtsFJyxCYHSfUmvwEM.value
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return{}
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_SAMSUNGTV+'/user'
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwEa={'session':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl['session'],'session.sig':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl['session.sig'],}
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwEa)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl['countryCode']=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG.get('countryCode')
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl['uuid'] =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG.get('uuid')
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl['ip'] =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG.get('ip')
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return{}
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl
 def t_Cache(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXN =nkpQDAdqTzPcgtsFJyxCYHSfUmvwhO(time.time())
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEo=nkpQDAdqTzPcgtsFJyxCYHSfUmvwhO(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXN-nkpQDAdqTzPcgtsFJyxCYHSfUmvwXN%3600)
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwEo,nkpQDAdqTzPcgtsFJyxCYHSfUmvwXN
 def zlib_compress(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,plaintext):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwEr=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEr).decode('utf-8')
 def Get_BaseRequest_Samsungtv(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG={}
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.API_SAMSUNGTV+'/api/lives'
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwEo,nkpQDAdqTzPcgtsFJyxCYHSfUmvwXN=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.t_Cache()
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwEL=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.zlib_compress(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl['uuid']+':'+nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXN))
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwEa={'session':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl['session'],'session.sig':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl['session.sig'],}
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI ={'t':nkpQDAdqTzPcgtsFJyxCYHSfUmvwja(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEo)}
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjO ={'x-cred-payload':nkpQDAdqTzPcgtsFJyxCYHSfUmvwEL}
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.callRequestCookies('Get',nkpQDAdqTzPcgtsFJyxCYHSfUmvwOi,payload=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjM,params=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOI,headers=nkpQDAdqTzPcgtsFJyxCYHSfUmvwjO,cookies=nkpQDAdqTzPcgtsFJyxCYHSfUmvwEa)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=json.loads(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOR.text)
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG
 def Make_Samsungtv_logoUrl(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,fullUrl):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjX=urllib.parse.urlparse(fullUrl) 
  if nkpQDAdqTzPcgtsFJyxCYHSfUmvwjX.netloc=='us-image.samsungtvplus.com':
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjE=nkpQDAdqTzPcgtsFJyxCYHSfUmvwhj(urllib.parse.parse_qsl(nkpQDAdqTzPcgtsFJyxCYHSfUmvwjX.query))
   if 'url' in nkpQDAdqTzPcgtsFJyxCYHSfUmvwjE:
    return nkpQDAdqTzPcgtsFJyxCYHSfUmvwjE.get('url')
  return fullUrl
 def Get_ChannelList_Samsungtv(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl,exceptGroup=[]):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV =[]
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_BaseRequest_Samsungtv(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['live']['channel']
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOl:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM.get('id')
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOo =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM.get('name')
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOr=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Make_Samsungtv_logoUrl(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM.get('logo'))
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_getGenre(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'samsung')
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL in['-','']:nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL='정주행 채널'
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'channelnm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOo,'channelimg':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOr,'ott':'samsung','genrenm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL}
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL not in exceptGroup:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[]
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV
 def Get_EpgInfo_Samsungtv(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl,exceptGroup=[]):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV=[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr =[]
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_BaseRequest_Samsungtv(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOG['live']['channel']
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwEi in nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa =nkpQDAdqTzPcgtsFJyxCYHSfUmvwEi.get('id')
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOo =nkpQDAdqTzPcgtsFJyxCYHSfUmvwEi.get('name')
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOr=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Make_Samsungtv_logoUrl(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEi.get('logo'))
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwEK =nkpQDAdqTzPcgtsFJyxCYHSfUmvwEi.get('program')
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.make_getGenre(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'samsung')
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL in exceptGroup:
     continue
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'channelnm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOo,'channelimg':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOr,'ott':'samsung','genrenm':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOL}
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
    for nkpQDAdqTzPcgtsFJyxCYHSfUmvwEB in nkpQDAdqTzPcgtsFJyxCYHSfUmvwEK:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwjh=nkpQDAdqTzPcgtsFJyxCYHSfUmvwEB.get('start_time')
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwje =nkpQDAdqTzPcgtsFJyxCYHSfUmvwEB.get('duration') 
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXj=datetime.datetime.strptime(nkpQDAdqTzPcgtsFJyxCYHSfUmvwjh,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXh =nkpQDAdqTzPcgtsFJyxCYHSfUmvwXj+datetime.timedelta(seconds=nkpQDAdqTzPcgtsFJyxCYHSfUmvwje)
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO={'channelid':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,'title':nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.xmlText(urllib.parse.unquote_plus(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEB.get('title'))),'startTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwXj.strftime('%Y%m%d%H%M00'),'endTime':nkpQDAdqTzPcgtsFJyxCYHSfUmvwXh.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  except nkpQDAdqTzPcgtsFJyxCYHSfUmvwjo as exception:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr(exception)
   return[],[]
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwOV,nkpQDAdqTzPcgtsFJyxCYHSfUmvwXr
 def make_getGenre(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,nkpQDAdqTzPcgtsFJyxCYHSfUmvwjW):
  try:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.INIT_CHANNEL.get(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa+'.'+nkpQDAdqTzPcgtsFJyxCYHSfUmvwjW).get('genre')
  except:
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.INIT_CHANNEL.get('-').get('genre')
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe
 def make_base_allchannel_py(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh,nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl):
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK =[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjB=[]
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjb=nkpQDAdqTzPcgtsFJyxCYHSfUmvwhe()
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_ChannelList_Wavve()
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK.extend(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_ChannelList_Tving()
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK.extend(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_ChannelList_Spotv()
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK.extend(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_ChannelList_Samsungtv(nkpQDAdqTzPcgtsFJyxCYHSfUmvwEl)
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK.extend(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXO)
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr('1')
  for i in nkpQDAdqTzPcgtsFJyxCYHSfUmvwhX(nkpQDAdqTzPcgtsFJyxCYHSfUmvwhE(nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK)):
   if nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK[i]['genrenm']=='-':
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK[i]['ott']=='wavve':
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe=nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.Get_ChanneGenrename_Wavve(nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK[i]['channelid'])
     if nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe not in nkpQDAdqTzPcgtsFJyxCYHSfUmvwjb:nkpQDAdqTzPcgtsFJyxCYHSfUmvwjb.add(nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe)
     time.sleep(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.SLEEP_TIME)
    elif nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK[i]['ott']=='spotv':
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe='스포츠'
    else:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe='-'
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK[i]['genrenm']=nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe
   else:
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK[i]['genrenm']not in nkpQDAdqTzPcgtsFJyxCYHSfUmvwjb:nkpQDAdqTzPcgtsFJyxCYHSfUmvwjb.add(nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK[i]['genrenm'])
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjb.add(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOh.INIT_CHANNEL.get('-').get('genre'))
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr('2')
  for nkpQDAdqTzPcgtsFJyxCYHSfUmvwjI in nkpQDAdqTzPcgtsFJyxCYHSfUmvwjb:
   for nkpQDAdqTzPcgtsFJyxCYHSfUmvwjN in nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK:
    if nkpQDAdqTzPcgtsFJyxCYHSfUmvwjN['genrenm']==nkpQDAdqTzPcgtsFJyxCYHSfUmvwjI:
     nkpQDAdqTzPcgtsFJyxCYHSfUmvwjB.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwjN)
  for nkpQDAdqTzPcgtsFJyxCYHSfUmvwjN in nkpQDAdqTzPcgtsFJyxCYHSfUmvwjK:
   if nkpQDAdqTzPcgtsFJyxCYHSfUmvwjN['genrenm']not in nkpQDAdqTzPcgtsFJyxCYHSfUmvwjb:
    nkpQDAdqTzPcgtsFJyxCYHSfUmvwjB.append(nkpQDAdqTzPcgtsFJyxCYHSfUmvwjN)
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjr('3')
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwju='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(nkpQDAdqTzPcgtsFJyxCYHSfUmvwju):os.remove(nkpQDAdqTzPcgtsFJyxCYHSfUmvwju)
  fp=nkpQDAdqTzPcgtsFJyxCYHSfUmvwhK(nkpQDAdqTzPcgtsFJyxCYHSfUmvwju,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  nkpQDAdqTzPcgtsFJyxCYHSfUmvwjV=nkpQDAdqTzPcgtsFJyxCYHSfUmvwhE(nkpQDAdqTzPcgtsFJyxCYHSfUmvwjB)
  i=0
  for nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM in nkpQDAdqTzPcgtsFJyxCYHSfUmvwjB:
   i+=1
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channelid']
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwOo =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['channelnm']
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjW =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['ott']
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwji ='%s.%s'%(nkpQDAdqTzPcgtsFJyxCYHSfUmvwOa,nkpQDAdqTzPcgtsFJyxCYHSfUmvwjW)
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe =nkpQDAdqTzPcgtsFJyxCYHSfUmvwOM['genrenm']
   nkpQDAdqTzPcgtsFJyxCYHSfUmvwjR='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(nkpQDAdqTzPcgtsFJyxCYHSfUmvwji,nkpQDAdqTzPcgtsFJyxCYHSfUmvwOo,nkpQDAdqTzPcgtsFJyxCYHSfUmvwXe)
   if i<nkpQDAdqTzPcgtsFJyxCYHSfUmvwjV:
    fp.write(nkpQDAdqTzPcgtsFJyxCYHSfUmvwjR+',\n')
   else:
    fp.write(nkpQDAdqTzPcgtsFJyxCYHSfUmvwjR+'\n')
  fp.write('}\n')
  fp.close()
  return nkpQDAdqTzPcgtsFJyxCYHSfUmvwjb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
