__author__="NightRain"
uzxtwfalXJdoNrOpCKQgsFGTceyMLD=False
uzxtwfalXJdoNrOpCKQgsFGTceyMLn=object
uzxtwfalXJdoNrOpCKQgsFGTceyMLh=None
uzxtwfalXJdoNrOpCKQgsFGTceyMLU=str
uzxtwfalXJdoNrOpCKQgsFGTceyMLv=Exception
uzxtwfalXJdoNrOpCKQgsFGTceyMLH=print
uzxtwfalXJdoNrOpCKQgsFGTceyMLj=True
uzxtwfalXJdoNrOpCKQgsFGTceyMPB=int
uzxtwfalXJdoNrOpCKQgsFGTceyMPA=range
uzxtwfalXJdoNrOpCKQgsFGTceyMPE=len
uzxtwfalXJdoNrOpCKQgsFGTceyMPL=dict
uzxtwfalXJdoNrOpCKQgsFGTceyMPk=set
uzxtwfalXJdoNrOpCKQgsFGTceyMPR=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
uzxtwfalXJdoNrOpCKQgsFGTceyMBE=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
uzxtwfalXJdoNrOpCKQgsFGTceyMBL=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':uzxtwfalXJdoNrOpCKQgsFGTceyMLD,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':uzxtwfalXJdoNrOpCKQgsFGTceyMLD,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':uzxtwfalXJdoNrOpCKQgsFGTceyMLD,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':uzxtwfalXJdoNrOpCKQgsFGTceyMLD,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':uzxtwfalXJdoNrOpCKQgsFGTceyMLD,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':uzxtwfalXJdoNrOpCKQgsFGTceyMLD,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class uzxtwfalXJdoNrOpCKQgsFGTceyMBA(uzxtwfalXJdoNrOpCKQgsFGTceyMLn):
 def __init__(uzxtwfalXJdoNrOpCKQgsFGTceyMBP):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_WAVVE ='https://apis.wavve.com'
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_TVING ='https://api.tving.com'
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_TVINGIMG ='https://image.tving.com'
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_SPOTV ='https://www.spotvnow.co.kr'
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.HTTPTAG ='https://'
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.LIMIT_WAVVE =500
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.LIMIT_TVING =60
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.LIMIT_TVINGEPG=20 
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.APPVERSION ='115.0.0.0' 
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.DEVICEMODEL ='Chrome' 
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.OSTYPE ='Windows' 
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.OSVERSION ='NT 10.0' 
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.DEFAULT_HEADER={'user-agent':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.USER_AGENT}
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.SLEEP_TIME =0.2
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.INIT_GENRESORT=MASTER_GENRE
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.INIT_CHANNEL =MASTER_CHANNEL
  uzxtwfalXJdoNrOpCKQgsFGTceyMBP.KodiVersion =20
 def callRequestCookies(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,jobtype,uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,redirects=uzxtwfalXJdoNrOpCKQgsFGTceyMLD):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBm=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.DEFAULT_HEADER
  if headers:uzxtwfalXJdoNrOpCKQgsFGTceyMBm.update(headers)
  if jobtype=='Get':
   uzxtwfalXJdoNrOpCKQgsFGTceyMBb=requests.get(uzxtwfalXJdoNrOpCKQgsFGTceyMBV,params=params,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMBm,cookies=cookies,allow_redirects=redirects)
  else:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBb=requests.post(uzxtwfalXJdoNrOpCKQgsFGTceyMBV,data=payload,params=params,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMBm,cookies=cookies,allow_redirects=redirects)
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBb
 def Get_DefaultParams_Wavve(uzxtwfalXJdoNrOpCKQgsFGTceyMBP):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBY={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBY
 def Get_DefaultParams_Tving(uzxtwfalXJdoNrOpCKQgsFGTceyMBP):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBY={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBY
 def Get_Now_Datetime(uzxtwfalXJdoNrOpCKQgsFGTceyMBP):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,in_text):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBI=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBI
 def Get_ChannelList_Wavve(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,exceptGroup=[]):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBq =[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMBi=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_ChannelImg_Wavve()
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_WAVVE+'/cf/live/recommend-channels'
   uzxtwfalXJdoNrOpCKQgsFGTceyMBY={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   uzxtwfalXJdoNrOpCKQgsFGTceyMBY.update(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_DefaultParams_Wavve())
   uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMBY,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
   if not('celllist' in uzxtwfalXJdoNrOpCKQgsFGTceyMBD['cell_toplist']):return uzxtwfalXJdoNrOpCKQgsFGTceyMBq
   uzxtwfalXJdoNrOpCKQgsFGTceyMBn=uzxtwfalXJdoNrOpCKQgsFGTceyMBD['cell_toplist']['celllist']
   for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBn:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBU=uzxtwfalXJdoNrOpCKQgsFGTceyMBh['contentid']
    uzxtwfalXJdoNrOpCKQgsFGTceyMBv=uzxtwfalXJdoNrOpCKQgsFGTceyMBh['title_list'][0]['text']
    if uzxtwfalXJdoNrOpCKQgsFGTceyMBU in uzxtwfalXJdoNrOpCKQgsFGTceyMBi:
     uzxtwfalXJdoNrOpCKQgsFGTceyMBH=uzxtwfalXJdoNrOpCKQgsFGTceyMBi[uzxtwfalXJdoNrOpCKQgsFGTceyMBU]
    else:
     uzxtwfalXJdoNrOpCKQgsFGTceyMBH=''
    uzxtwfalXJdoNrOpCKQgsFGTceyMBj=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_getGenre(uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'wavve')
    uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'channelnm':uzxtwfalXJdoNrOpCKQgsFGTceyMBv,'channelimg':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.HTTPTAG+uzxtwfalXJdoNrOpCKQgsFGTceyMBH if uzxtwfalXJdoNrOpCKQgsFGTceyMBH!='' else '','ott':'wavve','genrenm':uzxtwfalXJdoNrOpCKQgsFGTceyMBj}
    if uzxtwfalXJdoNrOpCKQgsFGTceyMBj not in exceptGroup:
     uzxtwfalXJdoNrOpCKQgsFGTceyMBq.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[]
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBq
 def Get_ChannelList_WavveExcept(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,exceptGroup=[]):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBq=[]
  if exceptGroup==[]:return[]
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_WAVVE+'/cf/live/recommend-channels'
   for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in exceptGroup:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBY={'WeekDay':'all','adult':'n','broadcastid':uzxtwfalXJdoNrOpCKQgsFGTceyMBh['broadcastid'],'contenttype':'channel','genre':uzxtwfalXJdoNrOpCKQgsFGTceyMBh['genre'],'isrecommend':'y','limit':uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    uzxtwfalXJdoNrOpCKQgsFGTceyMBY.update(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_DefaultParams_Wavve())
    uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMBY,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
    uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
    if not('celllist' in uzxtwfalXJdoNrOpCKQgsFGTceyMBD['cell_toplist']):return uzxtwfalXJdoNrOpCKQgsFGTceyMBq
    uzxtwfalXJdoNrOpCKQgsFGTceyMBn=uzxtwfalXJdoNrOpCKQgsFGTceyMBD['cell_toplist']['celllist']
    for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBn:
     uzxtwfalXJdoNrOpCKQgsFGTceyMBq.append(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['contentid'])
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[]
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBq
 def Get_ChannelImg_Wavve(uzxtwfalXJdoNrOpCKQgsFGTceyMBP):
  uzxtwfalXJdoNrOpCKQgsFGTceyMAE={}
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMAL=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_Now_Datetime()
   uzxtwfalXJdoNrOpCKQgsFGTceyMAP =uzxtwfalXJdoNrOpCKQgsFGTceyMAL+datetime.timedelta(hours=3)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_WAVVE+'/live/epgs'
   uzxtwfalXJdoNrOpCKQgsFGTceyMBY={'limit':uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':uzxtwfalXJdoNrOpCKQgsFGTceyMAL.strftime('%Y-%m-%d %H:00'),'enddatetime':uzxtwfalXJdoNrOpCKQgsFGTceyMAP.strftime('%Y-%m-%d %H:00')}
   uzxtwfalXJdoNrOpCKQgsFGTceyMBY.update(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_DefaultParams_Wavve())
   uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMBY,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBn=uzxtwfalXJdoNrOpCKQgsFGTceyMBD['list']
   for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBn:
    uzxtwfalXJdoNrOpCKQgsFGTceyMAE[uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channelid']]=uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channelimage']
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
  return uzxtwfalXJdoNrOpCKQgsFGTceyMAE
 def Get_ChanneGenrename_Wavve(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,uzxtwfalXJdoNrOpCKQgsFGTceyMBU):
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_WAVVE+'/live/channels/'+uzxtwfalXJdoNrOpCKQgsFGTceyMBU
   uzxtwfalXJdoNrOpCKQgsFGTceyMBY=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_DefaultParams_Wavve()
   uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMBY,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
   uzxtwfalXJdoNrOpCKQgsFGTceyMAk=uzxtwfalXJdoNrOpCKQgsFGTceyMBD['genretext']
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return ''
  return uzxtwfalXJdoNrOpCKQgsFGTceyMAk
 def Get_ChannelList_Spotv(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,payyn=uzxtwfalXJdoNrOpCKQgsFGTceyMLj):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBq=[]
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_SPOTV+'/api/v3/channel'
   uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
   for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBD:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBU=uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['id'])
    uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'channelnm':uzxtwfalXJdoNrOpCKQgsFGTceyMBh['name'],'channelimg':uzxtwfalXJdoNrOpCKQgsFGTceyMBh['logo'],'ott':'spotv','genrenm':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_getGenre(uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'spotv'),'free':uzxtwfalXJdoNrOpCKQgsFGTceyMBh['free']}
    uzxtwfalXJdoNrOpCKQgsFGTceyMBq.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[]
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBq
 def Get_ChannelList_Tving(uzxtwfalXJdoNrOpCKQgsFGTceyMBP):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBq =[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMAR=[]
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_TVING+'/v2/media/lives'
   uzxtwfalXJdoNrOpCKQgsFGTceyMBY={'pageNo':'1','pageSize':uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   uzxtwfalXJdoNrOpCKQgsFGTceyMBY.update(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_DefaultParams_Tving())
   uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMBY,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
   if not('result' in uzxtwfalXJdoNrOpCKQgsFGTceyMBD['body']):return uzxtwfalXJdoNrOpCKQgsFGTceyMBq
   uzxtwfalXJdoNrOpCKQgsFGTceyMBn=uzxtwfalXJdoNrOpCKQgsFGTceyMBD['body']['result']
   for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBn:
    if uzxtwfalXJdoNrOpCKQgsFGTceyMBh['live_code']=='C44441':continue 
    uzxtwfalXJdoNrOpCKQgsFGTceyMAR.append(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['live_code'])
   uzxtwfalXJdoNrOpCKQgsFGTceyMBi=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_ChannelImg_Tving(uzxtwfalXJdoNrOpCKQgsFGTceyMAR)
   for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBn:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBU=uzxtwfalXJdoNrOpCKQgsFGTceyMBh['live_code']
    if uzxtwfalXJdoNrOpCKQgsFGTceyMBU=='C44441':continue 
    uzxtwfalXJdoNrOpCKQgsFGTceyMBv=uzxtwfalXJdoNrOpCKQgsFGTceyMBh['schedule']['channel']['name']['ko']
    if uzxtwfalXJdoNrOpCKQgsFGTceyMBU in uzxtwfalXJdoNrOpCKQgsFGTceyMBi:
     uzxtwfalXJdoNrOpCKQgsFGTceyMBH=uzxtwfalXJdoNrOpCKQgsFGTceyMBi[uzxtwfalXJdoNrOpCKQgsFGTceyMBU]
    else:
     uzxtwfalXJdoNrOpCKQgsFGTceyMBH=''
    uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'channelnm':uzxtwfalXJdoNrOpCKQgsFGTceyMBv,'channelimg':uzxtwfalXJdoNrOpCKQgsFGTceyMBH,'ott':'tving','genrenm':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_getGenre(uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'tving')}
    uzxtwfalXJdoNrOpCKQgsFGTceyMBq.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[]
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBq
 def Get_timestamp(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,timetype=1):
  ts=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,timetype):
  if timetype=='1':
   uzxtwfalXJdoNrOpCKQgsFGTceyMAm={'transactionId':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   uzxtwfalXJdoNrOpCKQgsFGTceyMAm={'timestamp':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_timestamp(timetype=1),'transactionId':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_timestamp(timetype=1)+'000000000000001',}
  return uzxtwfalXJdoNrOpCKQgsFGTceyMAm
 def make_EpgDatetime_Tving(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,days=2):
  uzxtwfalXJdoNrOpCKQgsFGTceyMAb=[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMAY=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_DateList(days=2,dateType='2')
  uzxtwfalXJdoNrOpCKQgsFGTceyMAS=uzxtwfalXJdoNrOpCKQgsFGTceyMPB(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMAY:
   for uzxtwfalXJdoNrOpCKQgsFGTceyMAI in uzxtwfalXJdoNrOpCKQgsFGTceyMPA(8):
    uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'ndate':uzxtwfalXJdoNrOpCKQgsFGTceyMBh,'starttm':uzxtwfalXJdoNrOpCKQgsFGTceyMBE[uzxtwfalXJdoNrOpCKQgsFGTceyMAI]['starttm'],'endtm':uzxtwfalXJdoNrOpCKQgsFGTceyMBE[uzxtwfalXJdoNrOpCKQgsFGTceyMAI]['endtm']}
    uzxtwfalXJdoNrOpCKQgsFGTceyMAq=uzxtwfalXJdoNrOpCKQgsFGTceyMPB(uzxtwfalXJdoNrOpCKQgsFGTceyMBh+uzxtwfalXJdoNrOpCKQgsFGTceyMBE[uzxtwfalXJdoNrOpCKQgsFGTceyMAI]['starttm'])
    uzxtwfalXJdoNrOpCKQgsFGTceyMAi=uzxtwfalXJdoNrOpCKQgsFGTceyMPB(uzxtwfalXJdoNrOpCKQgsFGTceyMBh+uzxtwfalXJdoNrOpCKQgsFGTceyMBE[uzxtwfalXJdoNrOpCKQgsFGTceyMAI]['endtm'])
    if uzxtwfalXJdoNrOpCKQgsFGTceyMAS<=uzxtwfalXJdoNrOpCKQgsFGTceyMAq or(uzxtwfalXJdoNrOpCKQgsFGTceyMAq<uzxtwfalXJdoNrOpCKQgsFGTceyMAS and uzxtwfalXJdoNrOpCKQgsFGTceyMAS<uzxtwfalXJdoNrOpCKQgsFGTceyMAi):
     uzxtwfalXJdoNrOpCKQgsFGTceyMAb.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  return uzxtwfalXJdoNrOpCKQgsFGTceyMAb
 def make_DateList(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,days=2,dateType='1'):
  uzxtwfalXJdoNrOpCKQgsFGTceyMAY=[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMAV =uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_Now_Datetime()
  for i in uzxtwfalXJdoNrOpCKQgsFGTceyMPA(days):
   uzxtwfalXJdoNrOpCKQgsFGTceyMAW=uzxtwfalXJdoNrOpCKQgsFGTceyMAV+datetime.timedelta(days=i)
   if dateType=='1':
    uzxtwfalXJdoNrOpCKQgsFGTceyMAY.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAW.strftime('%Y-%m-%d'))
   else:
    uzxtwfalXJdoNrOpCKQgsFGTceyMAY.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAW.strftime('%Y%m%d'))
  return uzxtwfalXJdoNrOpCKQgsFGTceyMAY
 def make_Tving_ChannleGroup(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,uzxtwfalXJdoNrOpCKQgsFGTceyMAR):
  uzxtwfalXJdoNrOpCKQgsFGTceyMAD=[]
  i=0
  uzxtwfalXJdoNrOpCKQgsFGTceyMAn=''
  for uzxtwfalXJdoNrOpCKQgsFGTceyMAh in uzxtwfalXJdoNrOpCKQgsFGTceyMAR:
   if i==0:uzxtwfalXJdoNrOpCKQgsFGTceyMAn=uzxtwfalXJdoNrOpCKQgsFGTceyMAh
   else:uzxtwfalXJdoNrOpCKQgsFGTceyMAn+=',%s'%(uzxtwfalXJdoNrOpCKQgsFGTceyMAh)
   i+=1
   if i>=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.LIMIT_TVINGEPG:
    uzxtwfalXJdoNrOpCKQgsFGTceyMAD.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAn)
    i=0
    uzxtwfalXJdoNrOpCKQgsFGTceyMAn=''
  if uzxtwfalXJdoNrOpCKQgsFGTceyMAn!='':
   uzxtwfalXJdoNrOpCKQgsFGTceyMAD.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAn)
  return uzxtwfalXJdoNrOpCKQgsFGTceyMAD
 def Get_ChannelImg_Tving(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,chid_list):
  uzxtwfalXJdoNrOpCKQgsFGTceyMAE={}
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMAU=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_Now_Datetime().strftime('%Y%m%d')
   uzxtwfalXJdoNrOpCKQgsFGTceyMAL =uzxtwfalXJdoNrOpCKQgsFGTceyMBE[6]['starttm'] 
   uzxtwfalXJdoNrOpCKQgsFGTceyMAP =uzxtwfalXJdoNrOpCKQgsFGTceyMBE[6]['endtm']
   uzxtwfalXJdoNrOpCKQgsFGTceyMAD=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_Tving_ChannleGroup(chid_list)
   for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMAD:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_TVING+'/v2/media/schedules'
    uzxtwfalXJdoNrOpCKQgsFGTceyMBY={'pageNo':'1','pageSize':uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':uzxtwfalXJdoNrOpCKQgsFGTceyMAU,'broadcastDate':uzxtwfalXJdoNrOpCKQgsFGTceyMAU,'startBroadTime':uzxtwfalXJdoNrOpCKQgsFGTceyMAL,'endBroadTime':uzxtwfalXJdoNrOpCKQgsFGTceyMAP,'channelCode':uzxtwfalXJdoNrOpCKQgsFGTceyMBh}
    uzxtwfalXJdoNrOpCKQgsFGTceyMBY.update(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_DefaultParams_Tving())
    uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMBY,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
    uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
    if not('result' in uzxtwfalXJdoNrOpCKQgsFGTceyMBD['body']):return{}
    uzxtwfalXJdoNrOpCKQgsFGTceyMBn=uzxtwfalXJdoNrOpCKQgsFGTceyMBD['body']['result']
    for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBn:
     for uzxtwfalXJdoNrOpCKQgsFGTceyMAv in uzxtwfalXJdoNrOpCKQgsFGTceyMBh['image']:
      if uzxtwfalXJdoNrOpCKQgsFGTceyMAv['code']=='CAIC0400':uzxtwfalXJdoNrOpCKQgsFGTceyMAE[uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channel_code']]=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_TVINGIMG+uzxtwfalXJdoNrOpCKQgsFGTceyMAv['url']
      elif uzxtwfalXJdoNrOpCKQgsFGTceyMAv['code']=='CAIC1400':uzxtwfalXJdoNrOpCKQgsFGTceyMAE[uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channel_code']]=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_TVINGIMG+uzxtwfalXJdoNrOpCKQgsFGTceyMAv['url']
      elif uzxtwfalXJdoNrOpCKQgsFGTceyMAv['code']=='CAIC1900':uzxtwfalXJdoNrOpCKQgsFGTceyMAE[uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channel_code']]=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_TVINGIMG+uzxtwfalXJdoNrOpCKQgsFGTceyMAv['url']
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return{}
  return uzxtwfalXJdoNrOpCKQgsFGTceyMAE
 def Get_EpgInfo_Spotv(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,days=2,payyn=uzxtwfalXJdoNrOpCKQgsFGTceyMLj):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBq=[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMAH =[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMAY=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_DateList(days=days,dateType='1')
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_SPOTV+'/api/v3/channel'
   uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
   for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBD:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBU =uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['id'])
    uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'channelnm':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.xmlText(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['name']),'channelimg':uzxtwfalXJdoNrOpCKQgsFGTceyMBh['logo'],'ott':'spotv'}
    uzxtwfalXJdoNrOpCKQgsFGTceyMBq.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[],[]
  try:
   for uzxtwfalXJdoNrOpCKQgsFGTceyMAj in uzxtwfalXJdoNrOpCKQgsFGTceyMAY:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_SPOTV+'/api/v3/program/'+uzxtwfalXJdoNrOpCKQgsFGTceyMAj
    uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
    uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
    for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBD:
     uzxtwfalXJdoNrOpCKQgsFGTceyMBU =uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channelId'])
     uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'title':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.xmlText(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['title']),'startTime':uzxtwfalXJdoNrOpCKQgsFGTceyMBh['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':uzxtwfalXJdoNrOpCKQgsFGTceyMBh['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     uzxtwfalXJdoNrOpCKQgsFGTceyMAH.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
    time.sleep(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.SLEEP_TIME)
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[],[]
  '''
  try:
   for i_channel in channel_list:
    if i_channel['epgtype'] == 'spotvon':
     tmp_list = self.Get_EpgInfo_Spotv_spotvon(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    if i_channel['epgtype'] == 'spotvnet':
     tmp_list = self.Get_EpgInfo_Spotv_spotvnet(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBq,uzxtwfalXJdoNrOpCKQgsFGTceyMAH
 def Get_EpgInfo_Spotv_spotvon(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,uzxtwfalXJdoNrOpCKQgsFGTceyMBU,epgnm,days):
  uzxtwfalXJdoNrOpCKQgsFGTceyMAH =[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMAY=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_DateList(days=days,dateType='1')
  uzxtwfalXJdoNrOpCKQgsFGTceyMEB=''
  try:
   for uzxtwfalXJdoNrOpCKQgsFGTceyMAj in uzxtwfalXJdoNrOpCKQgsFGTceyMAY:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBV='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,uzxtwfalXJdoNrOpCKQgsFGTceyMAj)
    uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
    uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
    for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBD:
     uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'title':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.xmlText(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['title']),'startTime':uzxtwfalXJdoNrOpCKQgsFGTceyMBh['sch_date'].replace('-','')+uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['sch_hour']).zfill(2)+uzxtwfalXJdoNrOpCKQgsFGTceyMBh['sch_min']+'00','ott':'spotv'}
     uzxtwfalXJdoNrOpCKQgsFGTceyMAH.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
    uzxtwfalXJdoNrOpCKQgsFGTceyMEB=uzxtwfalXJdoNrOpCKQgsFGTceyMAj
   for i in uzxtwfalXJdoNrOpCKQgsFGTceyMPA(uzxtwfalXJdoNrOpCKQgsFGTceyMPE(uzxtwfalXJdoNrOpCKQgsFGTceyMAH)):
    if i>0:uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i-1]['endTime']=uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i]['startTime']
    if i==uzxtwfalXJdoNrOpCKQgsFGTceyMPE(uzxtwfalXJdoNrOpCKQgsFGTceyMAH)-1: uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i]['endTime']=uzxtwfalXJdoNrOpCKQgsFGTceyMEB+'240000'
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[]
  return uzxtwfalXJdoNrOpCKQgsFGTceyMAH
 def Get_EpgInfo_Spotv_spotvnet(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,uzxtwfalXJdoNrOpCKQgsFGTceyMBU,epgnm,days):
  uzxtwfalXJdoNrOpCKQgsFGTceyMAH =[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMAY=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_DateList(days=days,dateType='1')
  uzxtwfalXJdoNrOpCKQgsFGTceyMEB=''
  try:
   for uzxtwfalXJdoNrOpCKQgsFGTceyMAj in uzxtwfalXJdoNrOpCKQgsFGTceyMAY:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBV='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,uzxtwfalXJdoNrOpCKQgsFGTceyMAj)
    uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
    uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
    for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBD:
     uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'title':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.xmlText(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['title']),'startTime':uzxtwfalXJdoNrOpCKQgsFGTceyMBh['sch_date'].replace('-','')+uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['sch_hour']).zfill(2)+uzxtwfalXJdoNrOpCKQgsFGTceyMBh['sch_min']+'00','ott':'spotv'}
     uzxtwfalXJdoNrOpCKQgsFGTceyMAH.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
    uzxtwfalXJdoNrOpCKQgsFGTceyMEB=uzxtwfalXJdoNrOpCKQgsFGTceyMAj
   for i in uzxtwfalXJdoNrOpCKQgsFGTceyMPA(uzxtwfalXJdoNrOpCKQgsFGTceyMPE(uzxtwfalXJdoNrOpCKQgsFGTceyMAH)):
    if i>0:uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i-1]['endTime']=uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i]['startTime']
    if i==uzxtwfalXJdoNrOpCKQgsFGTceyMPE(uzxtwfalXJdoNrOpCKQgsFGTceyMAH)-1: uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i]['endTime']=uzxtwfalXJdoNrOpCKQgsFGTceyMEB+'240000'
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[]
  return uzxtwfalXJdoNrOpCKQgsFGTceyMAH
 def Get_EpgInfo_Wavve(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,days=2,exceptGroup=[]):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBq =[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMAH =[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMAV =uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_Now_Datetime()
  uzxtwfalXJdoNrOpCKQgsFGTceyMEA =uzxtwfalXJdoNrOpCKQgsFGTceyMAV+datetime.timedelta(hours=-2)
  uzxtwfalXJdoNrOpCKQgsFGTceyMEL =uzxtwfalXJdoNrOpCKQgsFGTceyMAV+datetime.timedelta(days=days)
  if uzxtwfalXJdoNrOpCKQgsFGTceyMPB(uzxtwfalXJdoNrOpCKQgsFGTceyMEA.strftime('%H'))<=3:
   uzxtwfalXJdoNrOpCKQgsFGTceyMEP=uzxtwfalXJdoNrOpCKQgsFGTceyMEA.strftime('%Y-%m-%d 00:00')
  else:
   uzxtwfalXJdoNrOpCKQgsFGTceyMEP=uzxtwfalXJdoNrOpCKQgsFGTceyMEA.strftime('%Y-%m-%d %H:00')
  uzxtwfalXJdoNrOpCKQgsFGTceyMEk =uzxtwfalXJdoNrOpCKQgsFGTceyMEL.strftime('%Y-%m-%d 00:00')
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_WAVVE+'/live/epgs'
   uzxtwfalXJdoNrOpCKQgsFGTceyMBY={'limit':uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':uzxtwfalXJdoNrOpCKQgsFGTceyMEP,'enddatetime':uzxtwfalXJdoNrOpCKQgsFGTceyMEk,}
   uzxtwfalXJdoNrOpCKQgsFGTceyMBY.update(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_DefaultParams_Wavve())
   uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMBY,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
   uzxtwfalXJdoNrOpCKQgsFGTceyMER=uzxtwfalXJdoNrOpCKQgsFGTceyMBD['list']
   for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMER:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBU =uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channelid']
    uzxtwfalXJdoNrOpCKQgsFGTceyMBj=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_getGenre(uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'wavve')
    uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'channelnm':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.xmlText(uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channelname']),'channelimg':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.HTTPTAG+uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channelimage'],'ott':'wavve'}
    if uzxtwfalXJdoNrOpCKQgsFGTceyMBj not in exceptGroup:
     uzxtwfalXJdoNrOpCKQgsFGTceyMBq.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
    for uzxtwfalXJdoNrOpCKQgsFGTceyMEm in uzxtwfalXJdoNrOpCKQgsFGTceyMBh['list']:
     uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channelid'],'title':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.xmlText(uzxtwfalXJdoNrOpCKQgsFGTceyMEm['title']),'startTime':uzxtwfalXJdoNrOpCKQgsFGTceyMEm['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':uzxtwfalXJdoNrOpCKQgsFGTceyMEm['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if uzxtwfalXJdoNrOpCKQgsFGTceyMBj not in exceptGroup and uzxtwfalXJdoNrOpCKQgsFGTceyMEm['starttime']!=uzxtwfalXJdoNrOpCKQgsFGTceyMEm['endtime']:
      uzxtwfalXJdoNrOpCKQgsFGTceyMAH.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[],[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMEb=uzxtwfalXJdoNrOpCKQgsFGTceyMPE(uzxtwfalXJdoNrOpCKQgsFGTceyMAH)
  for i in(uzxtwfalXJdoNrOpCKQgsFGTceyMPA(1,uzxtwfalXJdoNrOpCKQgsFGTceyMEb)):
   if uzxtwfalXJdoNrOpCKQgsFGTceyMPB(uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i-1]['endTime'])+1==uzxtwfalXJdoNrOpCKQgsFGTceyMPB(uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i]['startTime'])and uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i-1]['channelid']==uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i]['channelid']:
    uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i-1]['endTime']=uzxtwfalXJdoNrOpCKQgsFGTceyMAH[i]['startTime']
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBq,uzxtwfalXJdoNrOpCKQgsFGTceyMAH
 def Get_EpgInfo_Tving(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,days=2):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBq=[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMAH =[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMEY =[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMES =uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_EpgDatetime_Tving(days=days)
  uzxtwfalXJdoNrOpCKQgsFGTceyMBq =uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_ChannelList_Tving()
  uzxtwfalXJdoNrOpCKQgsFGTceyMEI=[]
  for i in uzxtwfalXJdoNrOpCKQgsFGTceyMPA(uzxtwfalXJdoNrOpCKQgsFGTceyMPE(uzxtwfalXJdoNrOpCKQgsFGTceyMBq)):
   uzxtwfalXJdoNrOpCKQgsFGTceyMBq[i]['channelnm']=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.xmlText(uzxtwfalXJdoNrOpCKQgsFGTceyMBq[i]['channelnm'])
   uzxtwfalXJdoNrOpCKQgsFGTceyMEI.append(uzxtwfalXJdoNrOpCKQgsFGTceyMBq[i]['channelid'])
  uzxtwfalXJdoNrOpCKQgsFGTceyMEq=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_Tving_ChannleGroup(uzxtwfalXJdoNrOpCKQgsFGTceyMEI)
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_TVING+'/v2/media/schedules'
   for uzxtwfalXJdoNrOpCKQgsFGTceyMEi in uzxtwfalXJdoNrOpCKQgsFGTceyMES:
    for uzxtwfalXJdoNrOpCKQgsFGTceyMEV in uzxtwfalXJdoNrOpCKQgsFGTceyMEq:
     uzxtwfalXJdoNrOpCKQgsFGTceyMBY={'pageNo':'1','pageSize':uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':uzxtwfalXJdoNrOpCKQgsFGTceyMEi['ndate'],'broadcastDate':uzxtwfalXJdoNrOpCKQgsFGTceyMEi['ndate'],'startBroadTime':uzxtwfalXJdoNrOpCKQgsFGTceyMEi['starttm'],'endBroadTime':uzxtwfalXJdoNrOpCKQgsFGTceyMEi['endtm'],'channelCode':uzxtwfalXJdoNrOpCKQgsFGTceyMEV}
     uzxtwfalXJdoNrOpCKQgsFGTceyMBY.update(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_DefaultParams_Tving())
     uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMBY,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
     uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
     uzxtwfalXJdoNrOpCKQgsFGTceyMBn=uzxtwfalXJdoNrOpCKQgsFGTceyMBD['body']['result']
     for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBn:
      if 'schedules' not in uzxtwfalXJdoNrOpCKQgsFGTceyMBh:continue
      if uzxtwfalXJdoNrOpCKQgsFGTceyMBh['schedules']==uzxtwfalXJdoNrOpCKQgsFGTceyMLh:continue
      for uzxtwfalXJdoNrOpCKQgsFGTceyMEW in uzxtwfalXJdoNrOpCKQgsFGTceyMBh['schedules']:
       uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMEW['schedule_code'],'title':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.xmlText(uzxtwfalXJdoNrOpCKQgsFGTceyMEW['program']['name']['ko']),'startTime':uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMEW['broadcast_start_time']),'endTime':uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMEW['broadcast_end_time']),'ott':'tving'}
       uzxtwfalXJdoNrOpCKQgsFGTceyMED=uzxtwfalXJdoNrOpCKQgsFGTceyMEW['schedule_code']+uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMEW['broadcast_start_time'])
       if uzxtwfalXJdoNrOpCKQgsFGTceyMED in uzxtwfalXJdoNrOpCKQgsFGTceyMEY:continue
       uzxtwfalXJdoNrOpCKQgsFGTceyMEY.append(uzxtwfalXJdoNrOpCKQgsFGTceyMED)
       uzxtwfalXJdoNrOpCKQgsFGTceyMAH.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
     time.sleep(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.SLEEP_TIME)
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[],[]
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBq,uzxtwfalXJdoNrOpCKQgsFGTceyMAH
 def Get_BaseInfo_Samsungtv(uzxtwfalXJdoNrOpCKQgsFGTceyMBP):
  uzxtwfalXJdoNrOpCKQgsFGTceyMEn={}
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_SAMSUNGTV
   uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMLh)
   for uzxtwfalXJdoNrOpCKQgsFGTceyMEh in uzxtwfalXJdoNrOpCKQgsFGTceyMBW.cookies:
    if uzxtwfalXJdoNrOpCKQgsFGTceyMEh.name=='session':
     uzxtwfalXJdoNrOpCKQgsFGTceyMEn['session']=uzxtwfalXJdoNrOpCKQgsFGTceyMEh.value
    elif uzxtwfalXJdoNrOpCKQgsFGTceyMEh.name=='session.sig':
     uzxtwfalXJdoNrOpCKQgsFGTceyMEn['session.sig']=uzxtwfalXJdoNrOpCKQgsFGTceyMEh.value
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return{}
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_SAMSUNGTV+'/user'
   uzxtwfalXJdoNrOpCKQgsFGTceyMEU={'session':uzxtwfalXJdoNrOpCKQgsFGTceyMEn['session'],'session.sig':uzxtwfalXJdoNrOpCKQgsFGTceyMEn['session.sig'],}
   uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMEU)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
   uzxtwfalXJdoNrOpCKQgsFGTceyMEn['countryCode']=uzxtwfalXJdoNrOpCKQgsFGTceyMBD.get('countryCode')
   uzxtwfalXJdoNrOpCKQgsFGTceyMEn['uuid'] =uzxtwfalXJdoNrOpCKQgsFGTceyMBD.get('uuid')
   uzxtwfalXJdoNrOpCKQgsFGTceyMEn['ip'] =uzxtwfalXJdoNrOpCKQgsFGTceyMBD.get('ip')
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return{}
  return uzxtwfalXJdoNrOpCKQgsFGTceyMEn
 def t_Cache(uzxtwfalXJdoNrOpCKQgsFGTceyMBP):
  uzxtwfalXJdoNrOpCKQgsFGTceyMAS =uzxtwfalXJdoNrOpCKQgsFGTceyMPB(time.time())
  uzxtwfalXJdoNrOpCKQgsFGTceyMEv=uzxtwfalXJdoNrOpCKQgsFGTceyMPB(uzxtwfalXJdoNrOpCKQgsFGTceyMAS-uzxtwfalXJdoNrOpCKQgsFGTceyMAS%3600)
  return uzxtwfalXJdoNrOpCKQgsFGTceyMEv,uzxtwfalXJdoNrOpCKQgsFGTceyMAS
 def zlib_compress(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,plaintext):
  uzxtwfalXJdoNrOpCKQgsFGTceyMEH=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(uzxtwfalXJdoNrOpCKQgsFGTceyMEH).decode('utf-8')
 def Get_BaseRequest_Samsungtv(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,uzxtwfalXJdoNrOpCKQgsFGTceyMEn):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBD={}
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBV=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.API_SAMSUNGTV+'/api/lives'
   uzxtwfalXJdoNrOpCKQgsFGTceyMEv,uzxtwfalXJdoNrOpCKQgsFGTceyMAS=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.t_Cache()
   uzxtwfalXJdoNrOpCKQgsFGTceyMEj=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.zlib_compress(uzxtwfalXJdoNrOpCKQgsFGTceyMEn['uuid']+':'+uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMAS))
   uzxtwfalXJdoNrOpCKQgsFGTceyMEU={'session':uzxtwfalXJdoNrOpCKQgsFGTceyMEn['session'],'session.sig':uzxtwfalXJdoNrOpCKQgsFGTceyMEn['session.sig'],}
   uzxtwfalXJdoNrOpCKQgsFGTceyMBY ={'t':uzxtwfalXJdoNrOpCKQgsFGTceyMLU(uzxtwfalXJdoNrOpCKQgsFGTceyMEv)}
   uzxtwfalXJdoNrOpCKQgsFGTceyMLB ={'x-cred-payload':uzxtwfalXJdoNrOpCKQgsFGTceyMEj}
   uzxtwfalXJdoNrOpCKQgsFGTceyMBW=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.callRequestCookies('Get',uzxtwfalXJdoNrOpCKQgsFGTceyMBV,payload=uzxtwfalXJdoNrOpCKQgsFGTceyMLh,params=uzxtwfalXJdoNrOpCKQgsFGTceyMBY,headers=uzxtwfalXJdoNrOpCKQgsFGTceyMLB,cookies=uzxtwfalXJdoNrOpCKQgsFGTceyMEU)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBD=json.loads(uzxtwfalXJdoNrOpCKQgsFGTceyMBW.text)
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBD
 def Make_Samsungtv_logoUrl(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,fullUrl):
  uzxtwfalXJdoNrOpCKQgsFGTceyMLA=urllib.parse.urlparse(fullUrl) 
  if uzxtwfalXJdoNrOpCKQgsFGTceyMLA.netloc=='us-image.samsungtvplus.com':
   uzxtwfalXJdoNrOpCKQgsFGTceyMLE=uzxtwfalXJdoNrOpCKQgsFGTceyMPL(urllib.parse.parse_qsl(uzxtwfalXJdoNrOpCKQgsFGTceyMLA.query))
   if 'url' in uzxtwfalXJdoNrOpCKQgsFGTceyMLE:
    return uzxtwfalXJdoNrOpCKQgsFGTceyMLE.get('url')
  return fullUrl
 def Get_ChannelList_Samsungtv(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,uzxtwfalXJdoNrOpCKQgsFGTceyMEn,exceptGroup=[]):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBq =[]
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBD=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_BaseRequest_Samsungtv(uzxtwfalXJdoNrOpCKQgsFGTceyMEn)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBn=uzxtwfalXJdoNrOpCKQgsFGTceyMBD['live']['channel']
   for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMBn:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBU =uzxtwfalXJdoNrOpCKQgsFGTceyMBh.get('id')
    uzxtwfalXJdoNrOpCKQgsFGTceyMBv =uzxtwfalXJdoNrOpCKQgsFGTceyMBh.get('name')
    uzxtwfalXJdoNrOpCKQgsFGTceyMBH=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Make_Samsungtv_logoUrl(uzxtwfalXJdoNrOpCKQgsFGTceyMBh.get('logo'))
    uzxtwfalXJdoNrOpCKQgsFGTceyMBj=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_getGenre(uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'samsung')
    if uzxtwfalXJdoNrOpCKQgsFGTceyMBj in['-','']:uzxtwfalXJdoNrOpCKQgsFGTceyMBj='정주행 채널'
    uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'channelnm':uzxtwfalXJdoNrOpCKQgsFGTceyMBv,'channelimg':uzxtwfalXJdoNrOpCKQgsFGTceyMBH,'ott':'samsung','genrenm':uzxtwfalXJdoNrOpCKQgsFGTceyMBj}
    if uzxtwfalXJdoNrOpCKQgsFGTceyMBj not in exceptGroup:
     uzxtwfalXJdoNrOpCKQgsFGTceyMBq.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[]
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBq
 def Get_EpgInfo_Samsungtv(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,uzxtwfalXJdoNrOpCKQgsFGTceyMEn,exceptGroup=[]):
  uzxtwfalXJdoNrOpCKQgsFGTceyMBq=[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMAH =[]
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMBD =uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_BaseRequest_Samsungtv(uzxtwfalXJdoNrOpCKQgsFGTceyMEn)
   uzxtwfalXJdoNrOpCKQgsFGTceyMBh=uzxtwfalXJdoNrOpCKQgsFGTceyMBD['live']['channel']
   for uzxtwfalXJdoNrOpCKQgsFGTceyMEV in uzxtwfalXJdoNrOpCKQgsFGTceyMBh:
    uzxtwfalXJdoNrOpCKQgsFGTceyMBU =uzxtwfalXJdoNrOpCKQgsFGTceyMEV.get('id')
    uzxtwfalXJdoNrOpCKQgsFGTceyMBv =uzxtwfalXJdoNrOpCKQgsFGTceyMEV.get('name')
    uzxtwfalXJdoNrOpCKQgsFGTceyMBH=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Make_Samsungtv_logoUrl(uzxtwfalXJdoNrOpCKQgsFGTceyMEV.get('logo'))
    uzxtwfalXJdoNrOpCKQgsFGTceyMER =uzxtwfalXJdoNrOpCKQgsFGTceyMEV.get('program')
    uzxtwfalXJdoNrOpCKQgsFGTceyMBj=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.make_getGenre(uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'samsung')
    if uzxtwfalXJdoNrOpCKQgsFGTceyMBj in exceptGroup:
     continue
    uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'channelnm':uzxtwfalXJdoNrOpCKQgsFGTceyMBv,'channelimg':uzxtwfalXJdoNrOpCKQgsFGTceyMBH,'ott':'samsung','genrenm':uzxtwfalXJdoNrOpCKQgsFGTceyMBj}
    uzxtwfalXJdoNrOpCKQgsFGTceyMBq.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
    for uzxtwfalXJdoNrOpCKQgsFGTceyMEm in uzxtwfalXJdoNrOpCKQgsFGTceyMER:
     uzxtwfalXJdoNrOpCKQgsFGTceyMLP=uzxtwfalXJdoNrOpCKQgsFGTceyMEm.get('start_time')
     uzxtwfalXJdoNrOpCKQgsFGTceyMLk =uzxtwfalXJdoNrOpCKQgsFGTceyMEm.get('duration') 
     uzxtwfalXJdoNrOpCKQgsFGTceyMAL=datetime.datetime.strptime(uzxtwfalXJdoNrOpCKQgsFGTceyMLP,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     uzxtwfalXJdoNrOpCKQgsFGTceyMAP =uzxtwfalXJdoNrOpCKQgsFGTceyMAL+datetime.timedelta(seconds=uzxtwfalXJdoNrOpCKQgsFGTceyMLk)
     uzxtwfalXJdoNrOpCKQgsFGTceyMAB={'channelid':uzxtwfalXJdoNrOpCKQgsFGTceyMBU,'title':uzxtwfalXJdoNrOpCKQgsFGTceyMBP.xmlText(urllib.parse.unquote_plus(uzxtwfalXJdoNrOpCKQgsFGTceyMEm.get('title'))),'startTime':uzxtwfalXJdoNrOpCKQgsFGTceyMAL.strftime('%Y%m%d%H%M00'),'endTime':uzxtwfalXJdoNrOpCKQgsFGTceyMAP.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     uzxtwfalXJdoNrOpCKQgsFGTceyMAH.append(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  except uzxtwfalXJdoNrOpCKQgsFGTceyMLv as exception:
   uzxtwfalXJdoNrOpCKQgsFGTceyMLH(exception)
   return[],[]
  return uzxtwfalXJdoNrOpCKQgsFGTceyMBq,uzxtwfalXJdoNrOpCKQgsFGTceyMAH
 def make_getGenre(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,uzxtwfalXJdoNrOpCKQgsFGTceyMBU,uzxtwfalXJdoNrOpCKQgsFGTceyMLi):
  try:
   uzxtwfalXJdoNrOpCKQgsFGTceyMAk=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.INIT_CHANNEL.get(uzxtwfalXJdoNrOpCKQgsFGTceyMBU+'.'+uzxtwfalXJdoNrOpCKQgsFGTceyMLi).get('genre')
  except:
   uzxtwfalXJdoNrOpCKQgsFGTceyMAk=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.INIT_CHANNEL.get('-').get('genre')
  return uzxtwfalXJdoNrOpCKQgsFGTceyMAk
 def make_base_allchannel_py(uzxtwfalXJdoNrOpCKQgsFGTceyMBP,uzxtwfalXJdoNrOpCKQgsFGTceyMEn):
  uzxtwfalXJdoNrOpCKQgsFGTceyMLR =[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMLm=[]
  uzxtwfalXJdoNrOpCKQgsFGTceyMLb=uzxtwfalXJdoNrOpCKQgsFGTceyMPk()
  uzxtwfalXJdoNrOpCKQgsFGTceyMAB=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_ChannelList_Wavve()
  uzxtwfalXJdoNrOpCKQgsFGTceyMLR.extend(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  uzxtwfalXJdoNrOpCKQgsFGTceyMAB=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_ChannelList_Tving()
  uzxtwfalXJdoNrOpCKQgsFGTceyMLR.extend(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  uzxtwfalXJdoNrOpCKQgsFGTceyMAB=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_ChannelList_Spotv()
  uzxtwfalXJdoNrOpCKQgsFGTceyMLR.extend(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  uzxtwfalXJdoNrOpCKQgsFGTceyMAB=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_ChannelList_Samsungtv(uzxtwfalXJdoNrOpCKQgsFGTceyMEn)
  uzxtwfalXJdoNrOpCKQgsFGTceyMLR.extend(uzxtwfalXJdoNrOpCKQgsFGTceyMAB)
  uzxtwfalXJdoNrOpCKQgsFGTceyMLH('1')
  for i in uzxtwfalXJdoNrOpCKQgsFGTceyMPA(uzxtwfalXJdoNrOpCKQgsFGTceyMPE(uzxtwfalXJdoNrOpCKQgsFGTceyMLR)):
   if uzxtwfalXJdoNrOpCKQgsFGTceyMLR[i]['genrenm']=='-':
    if uzxtwfalXJdoNrOpCKQgsFGTceyMLR[i]['ott']=='wavve':
     uzxtwfalXJdoNrOpCKQgsFGTceyMAk=uzxtwfalXJdoNrOpCKQgsFGTceyMBP.Get_ChanneGenrename_Wavve(uzxtwfalXJdoNrOpCKQgsFGTceyMLR[i]['channelid'])
     if uzxtwfalXJdoNrOpCKQgsFGTceyMAk not in uzxtwfalXJdoNrOpCKQgsFGTceyMLb:uzxtwfalXJdoNrOpCKQgsFGTceyMLb.add(uzxtwfalXJdoNrOpCKQgsFGTceyMAk)
     time.sleep(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.SLEEP_TIME)
    elif uzxtwfalXJdoNrOpCKQgsFGTceyMLR[i]['ott']=='spotv':
     uzxtwfalXJdoNrOpCKQgsFGTceyMAk='스포츠'
    else:
     uzxtwfalXJdoNrOpCKQgsFGTceyMAk='-'
    uzxtwfalXJdoNrOpCKQgsFGTceyMLR[i]['genrenm']=uzxtwfalXJdoNrOpCKQgsFGTceyMAk
   else:
    if uzxtwfalXJdoNrOpCKQgsFGTceyMLR[i]['genrenm']not in uzxtwfalXJdoNrOpCKQgsFGTceyMLb:uzxtwfalXJdoNrOpCKQgsFGTceyMLb.add(uzxtwfalXJdoNrOpCKQgsFGTceyMLR[i]['genrenm'])
  uzxtwfalXJdoNrOpCKQgsFGTceyMLb.add(uzxtwfalXJdoNrOpCKQgsFGTceyMBP.INIT_CHANNEL.get('-').get('genre'))
  uzxtwfalXJdoNrOpCKQgsFGTceyMLH('2')
  for uzxtwfalXJdoNrOpCKQgsFGTceyMLY in uzxtwfalXJdoNrOpCKQgsFGTceyMLb:
   for uzxtwfalXJdoNrOpCKQgsFGTceyMLS in uzxtwfalXJdoNrOpCKQgsFGTceyMLR:
    if uzxtwfalXJdoNrOpCKQgsFGTceyMLS['genrenm']==uzxtwfalXJdoNrOpCKQgsFGTceyMLY:
     uzxtwfalXJdoNrOpCKQgsFGTceyMLm.append(uzxtwfalXJdoNrOpCKQgsFGTceyMLS)
  for uzxtwfalXJdoNrOpCKQgsFGTceyMLS in uzxtwfalXJdoNrOpCKQgsFGTceyMLR:
   if uzxtwfalXJdoNrOpCKQgsFGTceyMLS['genrenm']not in uzxtwfalXJdoNrOpCKQgsFGTceyMLb:
    uzxtwfalXJdoNrOpCKQgsFGTceyMLm.append(uzxtwfalXJdoNrOpCKQgsFGTceyMLS)
  uzxtwfalXJdoNrOpCKQgsFGTceyMLH('3')
  uzxtwfalXJdoNrOpCKQgsFGTceyMLI='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(uzxtwfalXJdoNrOpCKQgsFGTceyMLI):os.remove(uzxtwfalXJdoNrOpCKQgsFGTceyMLI)
  fp=uzxtwfalXJdoNrOpCKQgsFGTceyMPR(uzxtwfalXJdoNrOpCKQgsFGTceyMLI,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  uzxtwfalXJdoNrOpCKQgsFGTceyMLq=uzxtwfalXJdoNrOpCKQgsFGTceyMPE(uzxtwfalXJdoNrOpCKQgsFGTceyMLm)
  i=0
  for uzxtwfalXJdoNrOpCKQgsFGTceyMBh in uzxtwfalXJdoNrOpCKQgsFGTceyMLm:
   i+=1
   uzxtwfalXJdoNrOpCKQgsFGTceyMBU =uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channelid']
   uzxtwfalXJdoNrOpCKQgsFGTceyMBv =uzxtwfalXJdoNrOpCKQgsFGTceyMBh['channelnm']
   uzxtwfalXJdoNrOpCKQgsFGTceyMLi =uzxtwfalXJdoNrOpCKQgsFGTceyMBh['ott']
   uzxtwfalXJdoNrOpCKQgsFGTceyMLV ='%s.%s'%(uzxtwfalXJdoNrOpCKQgsFGTceyMBU,uzxtwfalXJdoNrOpCKQgsFGTceyMLi)
   uzxtwfalXJdoNrOpCKQgsFGTceyMAk =uzxtwfalXJdoNrOpCKQgsFGTceyMBh['genrenm']
   uzxtwfalXJdoNrOpCKQgsFGTceyMLW='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(uzxtwfalXJdoNrOpCKQgsFGTceyMLV,uzxtwfalXJdoNrOpCKQgsFGTceyMBv,uzxtwfalXJdoNrOpCKQgsFGTceyMAk)
   if i<uzxtwfalXJdoNrOpCKQgsFGTceyMLq:
    fp.write(uzxtwfalXJdoNrOpCKQgsFGTceyMLW+',\n')
   else:
    fp.write(uzxtwfalXJdoNrOpCKQgsFGTceyMLW+'\n')
  fp.write('}\n')
  fp.close()
  return uzxtwfalXJdoNrOpCKQgsFGTceyMLb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
