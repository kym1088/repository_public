__author__="NightRain"
TwaljeymOEpRDYKqCGIhPstxgfMANH=object
TwaljeymOEpRDYKqCGIhPstxgfMANo=False
TwaljeymOEpRDYKqCGIhPstxgfMANd=None
TwaljeymOEpRDYKqCGIhPstxgfMANz=True
TwaljeymOEpRDYKqCGIhPstxgfMANV=getattr
TwaljeymOEpRDYKqCGIhPstxgfMANF=type
TwaljeymOEpRDYKqCGIhPstxgfMANc=int
TwaljeymOEpRDYKqCGIhPstxgfMANB=list
TwaljeymOEpRDYKqCGIhPstxgfMANk=len
TwaljeymOEpRDYKqCGIhPstxgfMANQ=str
TwaljeymOEpRDYKqCGIhPstxgfMANL=open
TwaljeymOEpRDYKqCGIhPstxgfMANJ=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
TwaljeymOEpRDYKqCGIhPstxgfMArb=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'     - M3U 추가 (삼성tv 플러스)','mode':'ADD_M3U','sType':'samsung','sName':'삼성TV 플러스'},{'title':'     - M3U 추가 (사용자 m3u)','mode':'ADD_M3U','sType':'custom','sName':'사용자 m3u 파일'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
TwaljeymOEpRDYKqCGIhPstxgfMArN={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
TwaljeymOEpRDYKqCGIhPstxgfMAru=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class TwaljeymOEpRDYKqCGIhPstxgfMAri(TwaljeymOEpRDYKqCGIhPstxgfMANH):
 def __init__(TwaljeymOEpRDYKqCGIhPstxgfMArW,TwaljeymOEpRDYKqCGIhPstxgfMArS,TwaljeymOEpRDYKqCGIhPstxgfMArU,TwaljeymOEpRDYKqCGIhPstxgfMArH):
  TwaljeymOEpRDYKqCGIhPstxgfMArW._addon_url =TwaljeymOEpRDYKqCGIhPstxgfMArS
  TwaljeymOEpRDYKqCGIhPstxgfMArW._addon_handle =TwaljeymOEpRDYKqCGIhPstxgfMArU
  TwaljeymOEpRDYKqCGIhPstxgfMArW.main_params =TwaljeymOEpRDYKqCGIhPstxgfMArH
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_FILE_PATH ='' 
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_FILE_NAME ='' 
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVE =TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONTVING =TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSPOTV =TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSAMSUNG =TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVERADIO =TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVEHOME =TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONRELIGION =TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSPOTVPAY =TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSAMSUNGHOME=TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_DISPLAYNM =TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_AUTORESTART =TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_CUSTOM_LIST =[]
  TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj =uzxtwfalXJdoNrOpCKQgsFGTceyMBA() 
 def addon_noti(TwaljeymOEpRDYKqCGIhPstxgfMArW,sting):
  try:
   TwaljeymOEpRDYKqCGIhPstxgfMArd=xbmcgui.Dialog()
   TwaljeymOEpRDYKqCGIhPstxgfMArd.notification(__addonname__,sting)
  except:
   TwaljeymOEpRDYKqCGIhPstxgfMANd
 def addon_log(TwaljeymOEpRDYKqCGIhPstxgfMArW,string):
  try:
   TwaljeymOEpRDYKqCGIhPstxgfMArz=string.encode('utf-8','ignore')
  except:
   TwaljeymOEpRDYKqCGIhPstxgfMArz='addonException: addon_log'
  TwaljeymOEpRDYKqCGIhPstxgfMArV=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,TwaljeymOEpRDYKqCGIhPstxgfMArz),level=TwaljeymOEpRDYKqCGIhPstxgfMArV)
 def get_keyboard_input(TwaljeymOEpRDYKqCGIhPstxgfMArW,TwaljeymOEpRDYKqCGIhPstxgfMArB):
  TwaljeymOEpRDYKqCGIhPstxgfMArF=TwaljeymOEpRDYKqCGIhPstxgfMANd
  kb=xbmc.Keyboard()
  kb.setHeading(TwaljeymOEpRDYKqCGIhPstxgfMArB)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   TwaljeymOEpRDYKqCGIhPstxgfMArF=kb.getText()
  return TwaljeymOEpRDYKqCGIhPstxgfMArF
 def add_dir(TwaljeymOEpRDYKqCGIhPstxgfMArW,label,sublabel='',img='',infoLabels=TwaljeymOEpRDYKqCGIhPstxgfMANd,isFolder=TwaljeymOEpRDYKqCGIhPstxgfMANz,params='',isLink=TwaljeymOEpRDYKqCGIhPstxgfMANo,ContextMenu=TwaljeymOEpRDYKqCGIhPstxgfMANd):
  TwaljeymOEpRDYKqCGIhPstxgfMArc='%s?%s'%(TwaljeymOEpRDYKqCGIhPstxgfMArW._addon_url,urllib.parse.urlencode(params))
  if sublabel:TwaljeymOEpRDYKqCGIhPstxgfMArB='%s < %s >'%(label,sublabel)
  else: TwaljeymOEpRDYKqCGIhPstxgfMArB=label
  if not img:img='DefaultFolder.png'
  TwaljeymOEpRDYKqCGIhPstxgfMArk=xbmcgui.ListItem(TwaljeymOEpRDYKqCGIhPstxgfMArB)
  TwaljeymOEpRDYKqCGIhPstxgfMArk.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.KodiVersion>=20:
   if infoLabels:TwaljeymOEpRDYKqCGIhPstxgfMArW.Set_InfoTag(TwaljeymOEpRDYKqCGIhPstxgfMArk.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:TwaljeymOEpRDYKqCGIhPstxgfMArk.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   TwaljeymOEpRDYKqCGIhPstxgfMArk.setProperty('IsPlayable','true')
  if ContextMenu:TwaljeymOEpRDYKqCGIhPstxgfMArk.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(TwaljeymOEpRDYKqCGIhPstxgfMArW._addon_handle,TwaljeymOEpRDYKqCGIhPstxgfMArc,TwaljeymOEpRDYKqCGIhPstxgfMArk,isFolder)
 def Set_InfoTag(TwaljeymOEpRDYKqCGIhPstxgfMArW,video_InfoTag:xbmc.InfoTagVideo,TwaljeymOEpRDYKqCGIhPstxgfMArn):
  for TwaljeymOEpRDYKqCGIhPstxgfMArQ,value in TwaljeymOEpRDYKqCGIhPstxgfMArn.items():
   if TwaljeymOEpRDYKqCGIhPstxgfMArN[TwaljeymOEpRDYKqCGIhPstxgfMArQ]['type']=='string':
    TwaljeymOEpRDYKqCGIhPstxgfMANV(video_InfoTag,TwaljeymOEpRDYKqCGIhPstxgfMArN[TwaljeymOEpRDYKqCGIhPstxgfMArQ]['func'])(value)
   elif TwaljeymOEpRDYKqCGIhPstxgfMArN[TwaljeymOEpRDYKqCGIhPstxgfMArQ]['type']=='int':
    if TwaljeymOEpRDYKqCGIhPstxgfMANF(value)==TwaljeymOEpRDYKqCGIhPstxgfMANc:
     TwaljeymOEpRDYKqCGIhPstxgfMArL=TwaljeymOEpRDYKqCGIhPstxgfMANc(value)
    else:
     TwaljeymOEpRDYKqCGIhPstxgfMArL=0
    TwaljeymOEpRDYKqCGIhPstxgfMANV(video_InfoTag,TwaljeymOEpRDYKqCGIhPstxgfMArN[TwaljeymOEpRDYKqCGIhPstxgfMArQ]['func'])(TwaljeymOEpRDYKqCGIhPstxgfMArL)
   elif TwaljeymOEpRDYKqCGIhPstxgfMArN[TwaljeymOEpRDYKqCGIhPstxgfMArQ]['type']=='actor':
    if value!=[]:
     TwaljeymOEpRDYKqCGIhPstxgfMANV(video_InfoTag,TwaljeymOEpRDYKqCGIhPstxgfMArN[TwaljeymOEpRDYKqCGIhPstxgfMArQ]['func'])([xbmc.Actor(name)for name in value])
   elif TwaljeymOEpRDYKqCGIhPstxgfMArN[TwaljeymOEpRDYKqCGIhPstxgfMArQ]['type']=='list':
    if TwaljeymOEpRDYKqCGIhPstxgfMANF(value)==TwaljeymOEpRDYKqCGIhPstxgfMANB:
     TwaljeymOEpRDYKqCGIhPstxgfMANV(video_InfoTag,TwaljeymOEpRDYKqCGIhPstxgfMArN[TwaljeymOEpRDYKqCGIhPstxgfMArQ]['func'])(value)
    else:
     TwaljeymOEpRDYKqCGIhPstxgfMANV(video_InfoTag,TwaljeymOEpRDYKqCGIhPstxgfMArN[TwaljeymOEpRDYKqCGIhPstxgfMArQ]['func'])([value])
 def make_M3u_Filename(TwaljeymOEpRDYKqCGIhPstxgfMArW,tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANo):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_FILE_PATH+TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(TwaljeymOEpRDYKqCGIhPstxgfMArW,tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANo):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_FILE_PATH+TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_FILE_NAME+'.xml'
 def dp_Main_List(TwaljeymOEpRDYKqCGIhPstxgfMArW):
  for TwaljeymOEpRDYKqCGIhPstxgfMArJ in TwaljeymOEpRDYKqCGIhPstxgfMArb:
   TwaljeymOEpRDYKqCGIhPstxgfMArB=TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('title')
   TwaljeymOEpRDYKqCGIhPstxgfMArX=''
   TwaljeymOEpRDYKqCGIhPstxgfMArv={'mode':TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('mode'),'sType':TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('sType'),'sName':TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('sName')}
   TwaljeymOEpRDYKqCGIhPstxgfMArn={'title':TwaljeymOEpRDYKqCGIhPstxgfMArB,'plot':TwaljeymOEpRDYKqCGIhPstxgfMArB}
   if TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('mode')=='XXX':
    TwaljeymOEpRDYKqCGIhPstxgfMAir=TwaljeymOEpRDYKqCGIhPstxgfMANo
    TwaljeymOEpRDYKqCGIhPstxgfMAib =TwaljeymOEpRDYKqCGIhPstxgfMANz
   else:
    TwaljeymOEpRDYKqCGIhPstxgfMAir=TwaljeymOEpRDYKqCGIhPstxgfMANz
    TwaljeymOEpRDYKqCGIhPstxgfMAib =TwaljeymOEpRDYKqCGIhPstxgfMANo
   TwaljeymOEpRDYKqCGIhPstxgfMAiN=TwaljeymOEpRDYKqCGIhPstxgfMANz
   if TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('mode')=='ADD_M3U':
    if TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('sType')=='wavve' and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVE ==TwaljeymOEpRDYKqCGIhPstxgfMANo:TwaljeymOEpRDYKqCGIhPstxgfMAiN=TwaljeymOEpRDYKqCGIhPstxgfMANo
    if TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('sType')=='tving' and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONTVING ==TwaljeymOEpRDYKqCGIhPstxgfMANo:TwaljeymOEpRDYKqCGIhPstxgfMAiN=TwaljeymOEpRDYKqCGIhPstxgfMANo
    if TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('sType')=='spotv' and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSPOTV ==TwaljeymOEpRDYKqCGIhPstxgfMANo:TwaljeymOEpRDYKqCGIhPstxgfMAiN=TwaljeymOEpRDYKqCGIhPstxgfMANo
    if TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('sType')=='samsung' and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSAMSUNG==TwaljeymOEpRDYKqCGIhPstxgfMANo:TwaljeymOEpRDYKqCGIhPstxgfMAiN=TwaljeymOEpRDYKqCGIhPstxgfMANo
    if TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('sType')=='custom' and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_CUSTOM_LIST==[]:TwaljeymOEpRDYKqCGIhPstxgfMAiN=TwaljeymOEpRDYKqCGIhPstxgfMANo
   if TwaljeymOEpRDYKqCGIhPstxgfMAiN==TwaljeymOEpRDYKqCGIhPstxgfMANz:
    if 'icon' in TwaljeymOEpRDYKqCGIhPstxgfMArJ:TwaljeymOEpRDYKqCGIhPstxgfMArX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',TwaljeymOEpRDYKqCGIhPstxgfMArJ.get('icon')) 
    TwaljeymOEpRDYKqCGIhPstxgfMArW.add_dir(TwaljeymOEpRDYKqCGIhPstxgfMArB,sublabel='',img=TwaljeymOEpRDYKqCGIhPstxgfMArX,infoLabels=TwaljeymOEpRDYKqCGIhPstxgfMArn,isFolder=TwaljeymOEpRDYKqCGIhPstxgfMAir,params=TwaljeymOEpRDYKqCGIhPstxgfMArv,isLink=TwaljeymOEpRDYKqCGIhPstxgfMAib)
  if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMArb)>0:xbmcplugin.endOfDirectory(TwaljeymOEpRDYKqCGIhPstxgfMArW._addon_handle,cacheToDisc=TwaljeymOEpRDYKqCGIhPstxgfMANz)
 def dp_Delete_M3u(TwaljeymOEpRDYKqCGIhPstxgfMArW,args):
  TwaljeymOEpRDYKqCGIhPstxgfMArd=xbmcgui.Dialog()
  TwaljeymOEpRDYKqCGIhPstxgfMAiW=TwaljeymOEpRDYKqCGIhPstxgfMArd.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if TwaljeymOEpRDYKqCGIhPstxgfMAiW==TwaljeymOEpRDYKqCGIhPstxgfMANo:sys.exit()
  TwaljeymOEpRDYKqCGIhPstxgfMAiS=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_M3u_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANo)
  if xbmcvfs.exists(TwaljeymOEpRDYKqCGIhPstxgfMAiS):
   if xbmcvfs.delete(TwaljeymOEpRDYKqCGIhPstxgfMAiS)==TwaljeymOEpRDYKqCGIhPstxgfMANo:
    TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti(__language__(30910).encode('utf-8'))
    return
  TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(TwaljeymOEpRDYKqCGIhPstxgfMArW,args):
  TwaljeymOEpRDYKqCGIhPstxgfMAiU=args.get('sType')
  TwaljeymOEpRDYKqCGIhPstxgfMAiH=args.get('sName')
  TwaljeymOEpRDYKqCGIhPstxgfMArd=xbmcgui.Dialog()
  TwaljeymOEpRDYKqCGIhPstxgfMAiW=TwaljeymOEpRDYKqCGIhPstxgfMArd.yesno((TwaljeymOEpRDYKqCGIhPstxgfMAiH+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if TwaljeymOEpRDYKqCGIhPstxgfMAiW==TwaljeymOEpRDYKqCGIhPstxgfMANo:sys.exit()
  TwaljeymOEpRDYKqCGIhPstxgfMAio =[]
  TwaljeymOEpRDYKqCGIhPstxgfMAid =[]
  TwaljeymOEpRDYKqCGIhPstxgfMAiS=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_M3u_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANz)
  if os.path.isfile(TwaljeymOEpRDYKqCGIhPstxgfMAiS):os.remove(TwaljeymOEpRDYKqCGIhPstxgfMAiS)
  if TwaljeymOEpRDYKqCGIhPstxgfMAiU=='all':
   TwaljeymOEpRDYKqCGIhPstxgfMAiS=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_M3u_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANo)
   if xbmcvfs.exists(TwaljeymOEpRDYKqCGIhPstxgfMAiS):
    if xbmcvfs.delete(TwaljeymOEpRDYKqCGIhPstxgfMAiS)==TwaljeymOEpRDYKqCGIhPstxgfMANo:
     TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   TwaljeymOEpRDYKqCGIhPstxgfMAiz=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_M3u_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANo)
   if xbmcvfs.exists(TwaljeymOEpRDYKqCGIhPstxgfMAiz):
    TwaljeymOEpRDYKqCGIhPstxgfMAiV=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_M3u_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANz)
    xbmcvfs.copy(TwaljeymOEpRDYKqCGIhPstxgfMAiz,TwaljeymOEpRDYKqCGIhPstxgfMAiV)
  if(TwaljeymOEpRDYKqCGIhPstxgfMAiU=='wavve' or TwaljeymOEpRDYKqCGIhPstxgfMAiU=='all')and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVE:
   TwaljeymOEpRDYKqCGIhPstxgfMAiF=TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_ChannelList_Wavve(exceptGroup=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_EexceptGroup_Wavve())
   if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAiF)!=0:TwaljeymOEpRDYKqCGIhPstxgfMAio.extend(TwaljeymOEpRDYKqCGIhPstxgfMAiF)
   TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_log('wavve cnt ----> '+TwaljeymOEpRDYKqCGIhPstxgfMANQ(TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAiF)))
  if(TwaljeymOEpRDYKqCGIhPstxgfMAiU=='tving' or TwaljeymOEpRDYKqCGIhPstxgfMAiU=='all')and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONTVING:
   TwaljeymOEpRDYKqCGIhPstxgfMAiF=TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_ChannelList_Tving()
   if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAiF)!=0:TwaljeymOEpRDYKqCGIhPstxgfMAio.extend(TwaljeymOEpRDYKqCGIhPstxgfMAiF)
   TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_log('tving cnt ----> '+TwaljeymOEpRDYKqCGIhPstxgfMANQ(TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAiF)))
  if(TwaljeymOEpRDYKqCGIhPstxgfMAiU=='spotv' or TwaljeymOEpRDYKqCGIhPstxgfMAiU=='all')and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSPOTV:
   TwaljeymOEpRDYKqCGIhPstxgfMAiF=TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_ChannelList_Spotv(payyn=TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSPOTVPAY)
   if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAiF)!=0:TwaljeymOEpRDYKqCGIhPstxgfMAio.extend(TwaljeymOEpRDYKqCGIhPstxgfMAiF)
   TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_log('spotv cnt ----> '+TwaljeymOEpRDYKqCGIhPstxgfMANQ(TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAiF)))
  if(TwaljeymOEpRDYKqCGIhPstxgfMAiU=='samsung' or TwaljeymOEpRDYKqCGIhPstxgfMAiU=='all')and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSAMSUNG:
   TwaljeymOEpRDYKqCGIhPstxgfMAic=TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_BaseInfo_Samsungtv()
   TwaljeymOEpRDYKqCGIhPstxgfMAiF=TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_ChannelList_Samsungtv(TwaljeymOEpRDYKqCGIhPstxgfMAic,exceptGroup=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_EexceptGroup_Samsungtv())
   if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAiF)!=0:TwaljeymOEpRDYKqCGIhPstxgfMAio.extend(TwaljeymOEpRDYKqCGIhPstxgfMAiF)
   TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_log('samsungtv cnt ----> '+TwaljeymOEpRDYKqCGIhPstxgfMANQ(TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAiF)))
  if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAio)==0 and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_CUSTOM_LIST==[]:
   TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti(__language__(30909).encode('utf8'))
   return
  for TwaljeymOEpRDYKqCGIhPstxgfMAiB in TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.INIT_GENRESORT:
   for TwaljeymOEpRDYKqCGIhPstxgfMAik in TwaljeymOEpRDYKqCGIhPstxgfMAio:
    if TwaljeymOEpRDYKqCGIhPstxgfMAik['genrenm']==TwaljeymOEpRDYKqCGIhPstxgfMAiB:
     TwaljeymOEpRDYKqCGIhPstxgfMAid.append(TwaljeymOEpRDYKqCGIhPstxgfMAik)
  for TwaljeymOEpRDYKqCGIhPstxgfMAik in TwaljeymOEpRDYKqCGIhPstxgfMAio:
   if TwaljeymOEpRDYKqCGIhPstxgfMAik['genrenm']not in TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.INIT_GENRESORT:
    TwaljeymOEpRDYKqCGIhPstxgfMAid.append(TwaljeymOEpRDYKqCGIhPstxgfMAik)
  try:
   if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAio)>0:
    TwaljeymOEpRDYKqCGIhPstxgfMAiS=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_M3u_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANz)
    if os.path.isfile(TwaljeymOEpRDYKqCGIhPstxgfMAiS):
     fp=TwaljeymOEpRDYKqCGIhPstxgfMANL(TwaljeymOEpRDYKqCGIhPstxgfMAiS,'a',-1,'utf-8')
    else:
     fp=TwaljeymOEpRDYKqCGIhPstxgfMANL(TwaljeymOEpRDYKqCGIhPstxgfMAiS,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for TwaljeymOEpRDYKqCGIhPstxgfMAiQ in TwaljeymOEpRDYKqCGIhPstxgfMAid:
     TwaljeymOEpRDYKqCGIhPstxgfMAiL =TwaljeymOEpRDYKqCGIhPstxgfMAiQ['channelid']
     TwaljeymOEpRDYKqCGIhPstxgfMAiJ =TwaljeymOEpRDYKqCGIhPstxgfMAiQ['channelnm']
     TwaljeymOEpRDYKqCGIhPstxgfMAiX=TwaljeymOEpRDYKqCGIhPstxgfMAiQ['channelimg']
     TwaljeymOEpRDYKqCGIhPstxgfMAiv =TwaljeymOEpRDYKqCGIhPstxgfMAiQ['ott']
     TwaljeymOEpRDYKqCGIhPstxgfMAin ='%s.%s'%(TwaljeymOEpRDYKqCGIhPstxgfMAiL,TwaljeymOEpRDYKqCGIhPstxgfMAiv)
     TwaljeymOEpRDYKqCGIhPstxgfMAbr=TwaljeymOEpRDYKqCGIhPstxgfMAiQ['genrenm']
     if TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_DISPLAYNM:
      TwaljeymOEpRDYKqCGIhPstxgfMAiJ='%s (%s)'%(TwaljeymOEpRDYKqCGIhPstxgfMAiJ,TwaljeymOEpRDYKqCGIhPstxgfMAiv)
     if TwaljeymOEpRDYKqCGIhPstxgfMAbr=='라디오/음악':
      TwaljeymOEpRDYKqCGIhPstxgfMAbi='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(TwaljeymOEpRDYKqCGIhPstxgfMAin,TwaljeymOEpRDYKqCGIhPstxgfMAiJ,TwaljeymOEpRDYKqCGIhPstxgfMAbr,TwaljeymOEpRDYKqCGIhPstxgfMAiX,TwaljeymOEpRDYKqCGIhPstxgfMAiJ)
     else:
      TwaljeymOEpRDYKqCGIhPstxgfMAbi='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(TwaljeymOEpRDYKqCGIhPstxgfMAin,TwaljeymOEpRDYKqCGIhPstxgfMAiJ,TwaljeymOEpRDYKqCGIhPstxgfMAbr,TwaljeymOEpRDYKqCGIhPstxgfMAiX,TwaljeymOEpRDYKqCGIhPstxgfMAiJ)
     if TwaljeymOEpRDYKqCGIhPstxgfMAiv=='wavve':
      TwaljeymOEpRDYKqCGIhPstxgfMAbN ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(TwaljeymOEpRDYKqCGIhPstxgfMAiL)
     elif TwaljeymOEpRDYKqCGIhPstxgfMAiv=='tving':
      TwaljeymOEpRDYKqCGIhPstxgfMAbN ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(TwaljeymOEpRDYKqCGIhPstxgfMAiL)
     elif TwaljeymOEpRDYKqCGIhPstxgfMAiv=='spotv':
      TwaljeymOEpRDYKqCGIhPstxgfMAbN ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(TwaljeymOEpRDYKqCGIhPstxgfMAiL)
     if TwaljeymOEpRDYKqCGIhPstxgfMAiv=='samsung':
      TwaljeymOEpRDYKqCGIhPstxgfMAbN ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(TwaljeymOEpRDYKqCGIhPstxgfMAiL)
     fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbi)
     fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbN)
    fp.close()
  except:
   TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti(__language__(30910).encode('utf8'))
   return
  try:
   if(TwaljeymOEpRDYKqCGIhPstxgfMAiU=='custom' or TwaljeymOEpRDYKqCGIhPstxgfMAiU=='all')and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_CUSTOM_LIST!=[]:
    TwaljeymOEpRDYKqCGIhPstxgfMAiS=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_M3u_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANz)
    if os.path.isfile(TwaljeymOEpRDYKqCGIhPstxgfMAiS):
     fp=TwaljeymOEpRDYKqCGIhPstxgfMANL(TwaljeymOEpRDYKqCGIhPstxgfMAiS,'a',-1,'utf-8')
    else:
     fp=TwaljeymOEpRDYKqCGIhPstxgfMANL(TwaljeymOEpRDYKqCGIhPstxgfMAiS,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for TwaljeymOEpRDYKqCGIhPstxgfMAbu in TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_CUSTOM_LIST:
     TwaljeymOEpRDYKqCGIhPstxgfMAbW=TwaljeymOEpRDYKqCGIhPstxgfMArW.customEpg_FileRead(TwaljeymOEpRDYKqCGIhPstxgfMAbu)
     for TwaljeymOEpRDYKqCGIhPstxgfMAbS in TwaljeymOEpRDYKqCGIhPstxgfMAbW:
      TwaljeymOEpRDYKqCGIhPstxgfMAbS=TwaljeymOEpRDYKqCGIhPstxgfMAbS.strip()
      if TwaljeymOEpRDYKqCGIhPstxgfMAbS not in['','#EXTM3U']:
       fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbS+'\n')
   fp.close()
  except:
   TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti(__language__(30910).encode('utf8'))
   return
  TwaljeymOEpRDYKqCGIhPstxgfMAiz=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_M3u_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANz)
  TwaljeymOEpRDYKqCGIhPstxgfMAiV=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_M3u_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANo)
  if xbmcvfs.copy(TwaljeymOEpRDYKqCGIhPstxgfMAiz,TwaljeymOEpRDYKqCGIhPstxgfMAiV):
   TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti((TwaljeymOEpRDYKqCGIhPstxgfMAiH+' '+__language__(30908)).encode('utf8'))
  else:
   TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti(__language__(30910).encode('utf-8'))
 def customEpg_FileList(TwaljeymOEpRDYKqCGIhPstxgfMArW):
  TwaljeymOEpRDYKqCGIhPstxgfMAbU=[]
  if __addon__.getSetting('custom01on')=='true':TwaljeymOEpRDYKqCGIhPstxgfMAbU.append(__addon__.getSetting('custom01nm'))
  if __addon__.getSetting('custom02on')=='true':TwaljeymOEpRDYKqCGIhPstxgfMAbU.append(__addon__.getSetting('custom02nm'))
  if __addon__.getSetting('custom03on')=='true':TwaljeymOEpRDYKqCGIhPstxgfMAbU.append(__addon__.getSetting('custom03nm'))
  if __addon__.getSetting('custom04on')=='true':TwaljeymOEpRDYKqCGIhPstxgfMAbU.append(__addon__.getSetting('custom04nm'))
  if __addon__.getSetting('custom05on')=='true':TwaljeymOEpRDYKqCGIhPstxgfMAbU.append(__addon__.getSetting('custom05nm'))
  return TwaljeymOEpRDYKqCGIhPstxgfMAbU
 def customEpg_FileRead(TwaljeymOEpRDYKqCGIhPstxgfMArW,source_filename):
  try:
   TwaljeymOEpRDYKqCGIhPstxgfMAbH=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
   if os.path.isfile(TwaljeymOEpRDYKqCGIhPstxgfMAbH):os.remove(TwaljeymOEpRDYKqCGIhPstxgfMAbH)
   xbmcvfs.copy(source_filename,TwaljeymOEpRDYKqCGIhPstxgfMAbH)
   fp=TwaljeymOEpRDYKqCGIhPstxgfMANL(TwaljeymOEpRDYKqCGIhPstxgfMAbH,'r',-1,'utf-8')
   TwaljeymOEpRDYKqCGIhPstxgfMAbo=fp.readlines()
  except:
   return[]
  return TwaljeymOEpRDYKqCGIhPstxgfMAbo
 def dp_Make_Epg(TwaljeymOEpRDYKqCGIhPstxgfMArW,args):
  TwaljeymOEpRDYKqCGIhPstxgfMAiU=args.get('sType')
  TwaljeymOEpRDYKqCGIhPstxgfMAiH=args.get('sName')
  TwaljeymOEpRDYKqCGIhPstxgfMAbd=args.get('sNoti')
  if TwaljeymOEpRDYKqCGIhPstxgfMAbd!='N':
   TwaljeymOEpRDYKqCGIhPstxgfMArd=xbmcgui.Dialog()
   TwaljeymOEpRDYKqCGIhPstxgfMAiW=TwaljeymOEpRDYKqCGIhPstxgfMArd.yesno((TwaljeymOEpRDYKqCGIhPstxgfMAiH+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if TwaljeymOEpRDYKqCGIhPstxgfMAiW==TwaljeymOEpRDYKqCGIhPstxgfMANo:sys.exit()
  TwaljeymOEpRDYKqCGIhPstxgfMAbz=[]
  TwaljeymOEpRDYKqCGIhPstxgfMAbV=[]
  if(TwaljeymOEpRDYKqCGIhPstxgfMAiU=='wavve' or TwaljeymOEpRDYKqCGIhPstxgfMAiU=='all')and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVE:
   TwaljeymOEpRDYKqCGIhPstxgfMAbF,TwaljeymOEpRDYKqCGIhPstxgfMAbc=TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_EexceptGroup_Wavve())
   if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAbc)!=0:
    TwaljeymOEpRDYKqCGIhPstxgfMAbz.extend(TwaljeymOEpRDYKqCGIhPstxgfMAbF)
    TwaljeymOEpRDYKqCGIhPstxgfMAbV.extend(TwaljeymOEpRDYKqCGIhPstxgfMAbc)
  if(TwaljeymOEpRDYKqCGIhPstxgfMAiU=='tving' or TwaljeymOEpRDYKqCGIhPstxgfMAiU=='all')and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONTVING:
   TwaljeymOEpRDYKqCGIhPstxgfMAbF,TwaljeymOEpRDYKqCGIhPstxgfMAbc=TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_EpgInfo_Tving()
   if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAbc)!=0:
    TwaljeymOEpRDYKqCGIhPstxgfMAbz.extend(TwaljeymOEpRDYKqCGIhPstxgfMAbF)
    TwaljeymOEpRDYKqCGIhPstxgfMAbV.extend(TwaljeymOEpRDYKqCGIhPstxgfMAbc)
  if(TwaljeymOEpRDYKqCGIhPstxgfMAiU=='spotv' or TwaljeymOEpRDYKqCGIhPstxgfMAiU=='all')and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSPOTV:
   TwaljeymOEpRDYKqCGIhPstxgfMAbF,TwaljeymOEpRDYKqCGIhPstxgfMAbc=TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_EpgInfo_Spotv(payyn=TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSPOTVPAY)
   if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAbc)!=0:
    TwaljeymOEpRDYKqCGIhPstxgfMAbz.extend(TwaljeymOEpRDYKqCGIhPstxgfMAbF)
    TwaljeymOEpRDYKqCGIhPstxgfMAbV.extend(TwaljeymOEpRDYKqCGIhPstxgfMAbc)
  if(TwaljeymOEpRDYKqCGIhPstxgfMAiU=='samsung' or TwaljeymOEpRDYKqCGIhPstxgfMAiU=='all')and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSAMSUNG:
   TwaljeymOEpRDYKqCGIhPstxgfMAic=TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_BaseInfo_Samsungtv()
   TwaljeymOEpRDYKqCGIhPstxgfMAbF,TwaljeymOEpRDYKqCGIhPstxgfMAbc=TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_EpgInfo_Samsungtv(TwaljeymOEpRDYKqCGIhPstxgfMAic,exceptGroup=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_EexceptGroup_Samsungtv())
   if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAbc)!=0:
    TwaljeymOEpRDYKqCGIhPstxgfMAbz.extend(TwaljeymOEpRDYKqCGIhPstxgfMAbF)
    TwaljeymOEpRDYKqCGIhPstxgfMAbV.extend(TwaljeymOEpRDYKqCGIhPstxgfMAbc)
  if TwaljeymOEpRDYKqCGIhPstxgfMANk(TwaljeymOEpRDYKqCGIhPstxgfMAbV)==0:
   if TwaljeymOEpRDYKqCGIhPstxgfMAbd!='N':TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   TwaljeymOEpRDYKqCGIhPstxgfMAiS=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_Epg_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANz)
   fp=TwaljeymOEpRDYKqCGIhPstxgfMANL(TwaljeymOEpRDYKqCGIhPstxgfMAiS,'w',-1,'utf-8')
   TwaljeymOEpRDYKqCGIhPstxgfMAbB='<?xml version="1.0" encoding="UTF-8"?>\n'
   TwaljeymOEpRDYKqCGIhPstxgfMAbk='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   TwaljeymOEpRDYKqCGIhPstxgfMAbQ='<tv generator-info-name="boritv_epg">\n\n'
   TwaljeymOEpRDYKqCGIhPstxgfMAbL='\n</tv>\n'
   fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbB)
   fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbk)
   fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbQ)
   for TwaljeymOEpRDYKqCGIhPstxgfMAbJ in TwaljeymOEpRDYKqCGIhPstxgfMAbz:
    TwaljeymOEpRDYKqCGIhPstxgfMAbX='  <channel id="%s.%s">\n' %(TwaljeymOEpRDYKqCGIhPstxgfMAbJ.get('channelid'),TwaljeymOEpRDYKqCGIhPstxgfMAbJ.get('ott'))
    TwaljeymOEpRDYKqCGIhPstxgfMAbv='    <display-name>%s</display-name>\n'%(TwaljeymOEpRDYKqCGIhPstxgfMAbJ.get('channelnm'))
    TwaljeymOEpRDYKqCGIhPstxgfMAbn='    <icon src="%s" />\n' %(TwaljeymOEpRDYKqCGIhPstxgfMAbJ.get('channelimg'))
    TwaljeymOEpRDYKqCGIhPstxgfMANr='  </channel>\n\n'
    fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbX)
    fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbv)
    fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbn)
    fp.write(TwaljeymOEpRDYKqCGIhPstxgfMANr)
   for TwaljeymOEpRDYKqCGIhPstxgfMAbJ in TwaljeymOEpRDYKqCGIhPstxgfMAbV:
    TwaljeymOEpRDYKqCGIhPstxgfMAbX='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(TwaljeymOEpRDYKqCGIhPstxgfMAbJ.get('startTime'),TwaljeymOEpRDYKqCGIhPstxgfMAbJ.get('endTime'),TwaljeymOEpRDYKqCGIhPstxgfMAbJ.get('channelid'),TwaljeymOEpRDYKqCGIhPstxgfMAbJ.get('ott'))
    TwaljeymOEpRDYKqCGIhPstxgfMAbv='    <title lang="kr">%s</title>\n' %(TwaljeymOEpRDYKqCGIhPstxgfMAbJ.get('title'))
    TwaljeymOEpRDYKqCGIhPstxgfMAbn='  </programme>\n\n'
    fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbX)
    fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbv)
    fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbn)
   fp.write(TwaljeymOEpRDYKqCGIhPstxgfMAbL)
   fp.close()
  except:
   if TwaljeymOEpRDYKqCGIhPstxgfMAbd!='N':TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti(__language__(30910).encode('utf8'))
   return
  TwaljeymOEpRDYKqCGIhPstxgfMArW.MakeEpg_SaveJson()
  TwaljeymOEpRDYKqCGIhPstxgfMAiz=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_Epg_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANz)
  TwaljeymOEpRDYKqCGIhPstxgfMAiV=TwaljeymOEpRDYKqCGIhPstxgfMArW.make_Epg_Filename(tempyn=TwaljeymOEpRDYKqCGIhPstxgfMANo)
  if xbmcvfs.copy(TwaljeymOEpRDYKqCGIhPstxgfMAiz,TwaljeymOEpRDYKqCGIhPstxgfMAiV):
   if TwaljeymOEpRDYKqCGIhPstxgfMAbd!='N':TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti((TwaljeymOEpRDYKqCGIhPstxgfMAiH+' '+__language__(30912)).encode('utf8'))
  else:
   TwaljeymOEpRDYKqCGIhPstxgfMArW.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_AUTORESTART:
    TwaljeymOEpRDYKqCGIhPstxgfMANi=xbmcaddon.Addon('pvr.iptvsimple')
    TwaljeymOEpRDYKqCGIhPstxgfMANi.setSetting('anything','anything')
  except:
   TwaljeymOEpRDYKqCGIhPstxgfMANd 
 def make_EexceptGroup_Wavve(TwaljeymOEpRDYKqCGIhPstxgfMArW):
  TwaljeymOEpRDYKqCGIhPstxgfMANb=[]
  if TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVERADIO==TwaljeymOEpRDYKqCGIhPstxgfMANo:
   TwaljeymOEpRDYKqCGIhPstxgfMANb.append('라디오/음악')
  if TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVEHOME==TwaljeymOEpRDYKqCGIhPstxgfMANo:
   TwaljeymOEpRDYKqCGIhPstxgfMANb.append('홈쇼핑')
  if TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONRELIGION==TwaljeymOEpRDYKqCGIhPstxgfMANo:
   TwaljeymOEpRDYKqCGIhPstxgfMANb.append('종교')
  return TwaljeymOEpRDYKqCGIhPstxgfMANb
 def make_EexceptGroup_Samsungtv(TwaljeymOEpRDYKqCGIhPstxgfMArW):
  TwaljeymOEpRDYKqCGIhPstxgfMANb=[]
  if TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSAMSUNGHOME==TwaljeymOEpRDYKqCGIhPstxgfMANo:
   TwaljeymOEpRDYKqCGIhPstxgfMANb.append('홈쇼핑')
  return TwaljeymOEpRDYKqCGIhPstxgfMANb
 def get_radio_list(TwaljeymOEpRDYKqCGIhPstxgfMArW):
  if TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVERADIO==TwaljeymOEpRDYKqCGIhPstxgfMANo:return[]
  TwaljeymOEpRDYKqCGIhPstxgfMANu=[{'broadcastid':'46584','genre':'10'}]
  return TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_ChannelList_WavveExcept(TwaljeymOEpRDYKqCGIhPstxgfMANu)
 def check_config(TwaljeymOEpRDYKqCGIhPstxgfMArW):
  TwaljeymOEpRDYKqCGIhPstxgfMANW=TwaljeymOEpRDYKqCGIhPstxgfMANz
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVE =TwaljeymOEpRDYKqCGIhPstxgfMANz if __addon__.getSetting('onWavve')=='true' else TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONTVING =TwaljeymOEpRDYKqCGIhPstxgfMANz if __addon__.getSetting('onTvng')=='true' else TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSPOTV =TwaljeymOEpRDYKqCGIhPstxgfMANz if __addon__.getSetting('onSpotv')=='true' else TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSAMSUNG =TwaljeymOEpRDYKqCGIhPstxgfMANz if __addon__.getSetting('onSamsung')=='true' else TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVERADIO =TwaljeymOEpRDYKqCGIhPstxgfMANz if __addon__.getSetting('onWavveRadio')=='true' else TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVEHOME =TwaljeymOEpRDYKqCGIhPstxgfMANz if __addon__.getSetting('onWavveHome')=='true' else TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONRELIGION =TwaljeymOEpRDYKqCGIhPstxgfMANz if __addon__.getSetting('onWavveReligion')=='true' else TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSPOTVPAY =TwaljeymOEpRDYKqCGIhPstxgfMANz if __addon__.getSetting('onSpotvPay')=='true' else TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSAMSUNGHOME =TwaljeymOEpRDYKqCGIhPstxgfMANz if __addon__.getSetting('onSamsungHome')=='true' else TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_DISPLAYNM =TwaljeymOEpRDYKqCGIhPstxgfMANz if __addon__.getSetting('displayOTTnm')=='true' else TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_AUTORESTART =TwaljeymOEpRDYKqCGIhPstxgfMANz if __addon__.getSetting('autoRestart')=='true' else TwaljeymOEpRDYKqCGIhPstxgfMANo
  TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_CUSTOM_LIST =TwaljeymOEpRDYKqCGIhPstxgfMArW.customEpg_FileList()
  if TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_FILE_PATH=='' or TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_FILE_NAME=='':TwaljeymOEpRDYKqCGIhPstxgfMANW=TwaljeymOEpRDYKqCGIhPstxgfMANo
  if TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONWAVVE==TwaljeymOEpRDYKqCGIhPstxgfMANo and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONTVING==TwaljeymOEpRDYKqCGIhPstxgfMANo and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSPOTV==TwaljeymOEpRDYKqCGIhPstxgfMANo and TwaljeymOEpRDYKqCGIhPstxgfMArW.M3U_ONSAMSUNG==TwaljeymOEpRDYKqCGIhPstxgfMANo:TwaljeymOEpRDYKqCGIhPstxgfMANW=TwaljeymOEpRDYKqCGIhPstxgfMANo
  if TwaljeymOEpRDYKqCGIhPstxgfMANW==TwaljeymOEpRDYKqCGIhPstxgfMANo:
   TwaljeymOEpRDYKqCGIhPstxgfMArd=xbmcgui.Dialog()
   TwaljeymOEpRDYKqCGIhPstxgfMAiW=TwaljeymOEpRDYKqCGIhPstxgfMArd.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if TwaljeymOEpRDYKqCGIhPstxgfMAiW==TwaljeymOEpRDYKqCGIhPstxgfMANz:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(TwaljeymOEpRDYKqCGIhPstxgfMArW):
  TwaljeymOEpRDYKqCGIhPstxgfMANS={'date_makeepg':TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=TwaljeymOEpRDYKqCGIhPstxgfMANL(TwaljeymOEpRDYKqCGIhPstxgfMAru,'w',-1,'utf-8')
   json.dump(TwaljeymOEpRDYKqCGIhPstxgfMANS,fp)
   fp.close()
  except TwaljeymOEpRDYKqCGIhPstxgfMANJ as exception:
   return
 def boritv_main(TwaljeymOEpRDYKqCGIhPstxgfMArW):
  TwaljeymOEpRDYKqCGIhPstxgfMArW.BoritvObj.KodiVersion=TwaljeymOEpRDYKqCGIhPstxgfMANc(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  TwaljeymOEpRDYKqCGIhPstxgfMANU=TwaljeymOEpRDYKqCGIhPstxgfMArW.main_params.get('mode',TwaljeymOEpRDYKqCGIhPstxgfMANd)
  TwaljeymOEpRDYKqCGIhPstxgfMArW.check_config()
  if TwaljeymOEpRDYKqCGIhPstxgfMANU is TwaljeymOEpRDYKqCGIhPstxgfMANd:
   TwaljeymOEpRDYKqCGIhPstxgfMArW.dp_Main_List()
  elif TwaljeymOEpRDYKqCGIhPstxgfMANU=='DEL_M3U':
   TwaljeymOEpRDYKqCGIhPstxgfMArW.dp_Delete_M3u(TwaljeymOEpRDYKqCGIhPstxgfMArW.main_params)
  elif TwaljeymOEpRDYKqCGIhPstxgfMANU=='ADD_M3U':
   TwaljeymOEpRDYKqCGIhPstxgfMArW.dp_MakeAdd_M3u(TwaljeymOEpRDYKqCGIhPstxgfMArW.main_params)
  elif TwaljeymOEpRDYKqCGIhPstxgfMANU=='ADD_EPG':
   TwaljeymOEpRDYKqCGIhPstxgfMArW.dp_Make_Epg(TwaljeymOEpRDYKqCGIhPstxgfMArW.main_params)
  else:
   TwaljeymOEpRDYKqCGIhPstxgfMANd
# Created by pyminifier (https://github.com/liftoff/pyminifier)
