__author__="NightRain"
kKytxNeSgslUTfXCPAmnRqvLDcEQdW=object
kKytxNeSgslUTfXCPAmnRqvLDcEQdO=False
kKytxNeSgslUTfXCPAmnRqvLDcEQdz=None
kKytxNeSgslUTfXCPAmnRqvLDcEQdb=True
kKytxNeSgslUTfXCPAmnRqvLDcEQda=getattr
kKytxNeSgslUTfXCPAmnRqvLDcEQdj=type
kKytxNeSgslUTfXCPAmnRqvLDcEQdw=int
kKytxNeSgslUTfXCPAmnRqvLDcEQdp=list
kKytxNeSgslUTfXCPAmnRqvLDcEQdF=len
kKytxNeSgslUTfXCPAmnRqvLDcEQdu=str
kKytxNeSgslUTfXCPAmnRqvLDcEQdh=open
kKytxNeSgslUTfXCPAmnRqvLDcEQdG=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
kKytxNeSgslUTfXCPAmnRqvLDcEQMJ=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'     - M3U 추가 (삼성tv 플러스)','mode':'ADD_M3U','sType':'samsung','sName':'삼성TV 플러스'},{'title':'     - M3U 추가 (사용자 m3u)','mode':'ADD_M3U','sType':'custom','sName':'사용자 m3u 파일'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
kKytxNeSgslUTfXCPAmnRqvLDcEQMd={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
kKytxNeSgslUTfXCPAmnRqvLDcEQMo=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class kKytxNeSgslUTfXCPAmnRqvLDcEQMi(kKytxNeSgslUTfXCPAmnRqvLDcEQdW):
 def __init__(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,kKytxNeSgslUTfXCPAmnRqvLDcEQMr,kKytxNeSgslUTfXCPAmnRqvLDcEQMI,kKytxNeSgslUTfXCPAmnRqvLDcEQMW):
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB._addon_url =kKytxNeSgslUTfXCPAmnRqvLDcEQMr
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB._addon_handle =kKytxNeSgslUTfXCPAmnRqvLDcEQMI
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.main_params =kKytxNeSgslUTfXCPAmnRqvLDcEQMW
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_FILE_PATH ='' 
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_FILE_NAME ='' 
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVE =kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONTVING =kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSPOTV =kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSAMSUNG =kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVERADIO =kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVEHOME =kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONRELIGION =kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSPOTVPAY =kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSAMSUNGHOME=kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_DISPLAYNM =kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_AUTORESTART =kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_CUSTOM_LIST =[]
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj =GIVAofBEHlkeircXMsQvuzmLDFbpnt() 
 def addon_noti(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,sting):
  try:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMz=xbmcgui.Dialog()
   kKytxNeSgslUTfXCPAmnRqvLDcEQMz.notification(__addonname__,sting)
  except:
   kKytxNeSgslUTfXCPAmnRqvLDcEQdz
 def addon_log(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,string):
  try:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMb=string.encode('utf-8','ignore')
  except:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMb='addonException: addon_log'
  kKytxNeSgslUTfXCPAmnRqvLDcEQMa=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,kKytxNeSgslUTfXCPAmnRqvLDcEQMb),level=kKytxNeSgslUTfXCPAmnRqvLDcEQMa)
 def get_keyboard_input(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,kKytxNeSgslUTfXCPAmnRqvLDcEQMp):
  kKytxNeSgslUTfXCPAmnRqvLDcEQMj=kKytxNeSgslUTfXCPAmnRqvLDcEQdz
  kb=xbmc.Keyboard()
  kb.setHeading(kKytxNeSgslUTfXCPAmnRqvLDcEQMp)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   kKytxNeSgslUTfXCPAmnRqvLDcEQMj=kb.getText()
  return kKytxNeSgslUTfXCPAmnRqvLDcEQMj
 def add_dir(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,label,sublabel='',img='',infoLabels=kKytxNeSgslUTfXCPAmnRqvLDcEQdz,isFolder=kKytxNeSgslUTfXCPAmnRqvLDcEQdb,params='',isLink=kKytxNeSgslUTfXCPAmnRqvLDcEQdO,ContextMenu=kKytxNeSgslUTfXCPAmnRqvLDcEQdz):
  kKytxNeSgslUTfXCPAmnRqvLDcEQMw='%s?%s'%(kKytxNeSgslUTfXCPAmnRqvLDcEQMB._addon_url,urllib.parse.urlencode(params))
  if sublabel:kKytxNeSgslUTfXCPAmnRqvLDcEQMp='%s < %s >'%(label,sublabel)
  else: kKytxNeSgslUTfXCPAmnRqvLDcEQMp=label
  if not img:img='DefaultFolder.png'
  kKytxNeSgslUTfXCPAmnRqvLDcEQMF=xbmcgui.ListItem(kKytxNeSgslUTfXCPAmnRqvLDcEQMp)
  kKytxNeSgslUTfXCPAmnRqvLDcEQMF.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.KodiVersion>=20:
   if infoLabels:kKytxNeSgslUTfXCPAmnRqvLDcEQMB.Set_InfoTag(kKytxNeSgslUTfXCPAmnRqvLDcEQMF.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:kKytxNeSgslUTfXCPAmnRqvLDcEQMF.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMF.setProperty('IsPlayable','true')
  if ContextMenu:kKytxNeSgslUTfXCPAmnRqvLDcEQMF.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(kKytxNeSgslUTfXCPAmnRqvLDcEQMB._addon_handle,kKytxNeSgslUTfXCPAmnRqvLDcEQMw,kKytxNeSgslUTfXCPAmnRqvLDcEQMF,isFolder)
 def Set_InfoTag(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,video_InfoTag:xbmc.InfoTagVideo,kKytxNeSgslUTfXCPAmnRqvLDcEQMV):
  for kKytxNeSgslUTfXCPAmnRqvLDcEQMu,value in kKytxNeSgslUTfXCPAmnRqvLDcEQMV.items():
   if kKytxNeSgslUTfXCPAmnRqvLDcEQMd[kKytxNeSgslUTfXCPAmnRqvLDcEQMu]['type']=='string':
    kKytxNeSgslUTfXCPAmnRqvLDcEQda(video_InfoTag,kKytxNeSgslUTfXCPAmnRqvLDcEQMd[kKytxNeSgslUTfXCPAmnRqvLDcEQMu]['func'])(value)
   elif kKytxNeSgslUTfXCPAmnRqvLDcEQMd[kKytxNeSgslUTfXCPAmnRqvLDcEQMu]['type']=='int':
    if kKytxNeSgslUTfXCPAmnRqvLDcEQdj(value)==kKytxNeSgslUTfXCPAmnRqvLDcEQdw:
     kKytxNeSgslUTfXCPAmnRqvLDcEQMh=kKytxNeSgslUTfXCPAmnRqvLDcEQdw(value)
    else:
     kKytxNeSgslUTfXCPAmnRqvLDcEQMh=0
    kKytxNeSgslUTfXCPAmnRqvLDcEQda(video_InfoTag,kKytxNeSgslUTfXCPAmnRqvLDcEQMd[kKytxNeSgslUTfXCPAmnRqvLDcEQMu]['func'])(kKytxNeSgslUTfXCPAmnRqvLDcEQMh)
   elif kKytxNeSgslUTfXCPAmnRqvLDcEQMd[kKytxNeSgslUTfXCPAmnRqvLDcEQMu]['type']=='actor':
    if value!=[]:
     kKytxNeSgslUTfXCPAmnRqvLDcEQda(video_InfoTag,kKytxNeSgslUTfXCPAmnRqvLDcEQMd[kKytxNeSgslUTfXCPAmnRqvLDcEQMu]['func'])([xbmc.Actor(name)for name in value])
   elif kKytxNeSgslUTfXCPAmnRqvLDcEQMd[kKytxNeSgslUTfXCPAmnRqvLDcEQMu]['type']=='list':
    if kKytxNeSgslUTfXCPAmnRqvLDcEQdj(value)==kKytxNeSgslUTfXCPAmnRqvLDcEQdp:
     kKytxNeSgslUTfXCPAmnRqvLDcEQda(video_InfoTag,kKytxNeSgslUTfXCPAmnRqvLDcEQMd[kKytxNeSgslUTfXCPAmnRqvLDcEQMu]['func'])(value)
    else:
     kKytxNeSgslUTfXCPAmnRqvLDcEQda(video_InfoTag,kKytxNeSgslUTfXCPAmnRqvLDcEQMd[kKytxNeSgslUTfXCPAmnRqvLDcEQMu]['func'])([value])
 def make_M3u_Filename(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdO):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_FILE_PATH+kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdO):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_FILE_PATH+kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_FILE_NAME+'.xml'
 def dp_Main_List(kKytxNeSgslUTfXCPAmnRqvLDcEQMB):
  for kKytxNeSgslUTfXCPAmnRqvLDcEQMG in kKytxNeSgslUTfXCPAmnRqvLDcEQMJ:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMp=kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('title')
   kKytxNeSgslUTfXCPAmnRqvLDcEQMH=''
   kKytxNeSgslUTfXCPAmnRqvLDcEQMY={'mode':kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('mode'),'sType':kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('sType'),'sName':kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('sName')}
   kKytxNeSgslUTfXCPAmnRqvLDcEQMV={'title':kKytxNeSgslUTfXCPAmnRqvLDcEQMp,'plot':kKytxNeSgslUTfXCPAmnRqvLDcEQMp}
   if kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('mode')=='XXX':
    kKytxNeSgslUTfXCPAmnRqvLDcEQiM=kKytxNeSgslUTfXCPAmnRqvLDcEQdO
    kKytxNeSgslUTfXCPAmnRqvLDcEQiJ =kKytxNeSgslUTfXCPAmnRqvLDcEQdb
   else:
    kKytxNeSgslUTfXCPAmnRqvLDcEQiM=kKytxNeSgslUTfXCPAmnRqvLDcEQdb
    kKytxNeSgslUTfXCPAmnRqvLDcEQiJ =kKytxNeSgslUTfXCPAmnRqvLDcEQdO
   kKytxNeSgslUTfXCPAmnRqvLDcEQid=kKytxNeSgslUTfXCPAmnRqvLDcEQdb
   if kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('mode')=='ADD_M3U':
    if kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('sType')=='wavve' and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVE ==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:kKytxNeSgslUTfXCPAmnRqvLDcEQid=kKytxNeSgslUTfXCPAmnRqvLDcEQdO
    if kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('sType')=='tving' and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONTVING ==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:kKytxNeSgslUTfXCPAmnRqvLDcEQid=kKytxNeSgslUTfXCPAmnRqvLDcEQdO
    if kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('sType')=='spotv' and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSPOTV ==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:kKytxNeSgslUTfXCPAmnRqvLDcEQid=kKytxNeSgslUTfXCPAmnRqvLDcEQdO
    if kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('sType')=='samsung' and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSAMSUNG==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:kKytxNeSgslUTfXCPAmnRqvLDcEQid=kKytxNeSgslUTfXCPAmnRqvLDcEQdO
    if kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('sType')=='custom' and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_CUSTOM_LIST==[]:kKytxNeSgslUTfXCPAmnRqvLDcEQid=kKytxNeSgslUTfXCPAmnRqvLDcEQdO
   if kKytxNeSgslUTfXCPAmnRqvLDcEQid==kKytxNeSgslUTfXCPAmnRqvLDcEQdb:
    if 'icon' in kKytxNeSgslUTfXCPAmnRqvLDcEQMG:kKytxNeSgslUTfXCPAmnRqvLDcEQMH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',kKytxNeSgslUTfXCPAmnRqvLDcEQMG.get('icon')) 
    kKytxNeSgslUTfXCPAmnRqvLDcEQMB.add_dir(kKytxNeSgslUTfXCPAmnRqvLDcEQMp,sublabel='',img=kKytxNeSgslUTfXCPAmnRqvLDcEQMH,infoLabels=kKytxNeSgslUTfXCPAmnRqvLDcEQMV,isFolder=kKytxNeSgslUTfXCPAmnRqvLDcEQiM,params=kKytxNeSgslUTfXCPAmnRqvLDcEQMY,isLink=kKytxNeSgslUTfXCPAmnRqvLDcEQiJ)
  if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQMJ)>0:xbmcplugin.endOfDirectory(kKytxNeSgslUTfXCPAmnRqvLDcEQMB._addon_handle,cacheToDisc=kKytxNeSgslUTfXCPAmnRqvLDcEQdb)
 def dp_Delete_M3u(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,args):
  kKytxNeSgslUTfXCPAmnRqvLDcEQMz=xbmcgui.Dialog()
  kKytxNeSgslUTfXCPAmnRqvLDcEQiB=kKytxNeSgslUTfXCPAmnRqvLDcEQMz.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if kKytxNeSgslUTfXCPAmnRqvLDcEQiB==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:sys.exit()
  kKytxNeSgslUTfXCPAmnRqvLDcEQir=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_M3u_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdO)
  if xbmcvfs.exists(kKytxNeSgslUTfXCPAmnRqvLDcEQir):
   if xbmcvfs.delete(kKytxNeSgslUTfXCPAmnRqvLDcEQir)==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:
    kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti(__language__(30910).encode('utf-8'))
    return
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,args):
  kKytxNeSgslUTfXCPAmnRqvLDcEQiI=args.get('sType')
  kKytxNeSgslUTfXCPAmnRqvLDcEQiW=args.get('sName')
  kKytxNeSgslUTfXCPAmnRqvLDcEQMz=xbmcgui.Dialog()
  kKytxNeSgslUTfXCPAmnRqvLDcEQiB=kKytxNeSgslUTfXCPAmnRqvLDcEQMz.yesno((kKytxNeSgslUTfXCPAmnRqvLDcEQiW+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if kKytxNeSgslUTfXCPAmnRqvLDcEQiB==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:sys.exit()
  kKytxNeSgslUTfXCPAmnRqvLDcEQiO =[]
  kKytxNeSgslUTfXCPAmnRqvLDcEQiz =[]
  kKytxNeSgslUTfXCPAmnRqvLDcEQir=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_M3u_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdb)
  if os.path.isfile(kKytxNeSgslUTfXCPAmnRqvLDcEQir):os.remove(kKytxNeSgslUTfXCPAmnRqvLDcEQir)
  if kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='all':
   kKytxNeSgslUTfXCPAmnRqvLDcEQir=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_M3u_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdO)
   if xbmcvfs.exists(kKytxNeSgslUTfXCPAmnRqvLDcEQir):
    if xbmcvfs.delete(kKytxNeSgslUTfXCPAmnRqvLDcEQir)==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:
     kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   kKytxNeSgslUTfXCPAmnRqvLDcEQib=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_M3u_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdO)
   if xbmcvfs.exists(kKytxNeSgslUTfXCPAmnRqvLDcEQib):
    kKytxNeSgslUTfXCPAmnRqvLDcEQia=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_M3u_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdb)
    xbmcvfs.copy(kKytxNeSgslUTfXCPAmnRqvLDcEQib,kKytxNeSgslUTfXCPAmnRqvLDcEQia)
  if(kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='wavve' or kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='all')and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVE:
   kKytxNeSgslUTfXCPAmnRqvLDcEQij=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_ChannelList_Wavve(exceptGroup=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_EexceptGroup_Wavve())
   if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQij)!=0:kKytxNeSgslUTfXCPAmnRqvLDcEQiO.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQij)
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_log('wavve cnt ----> '+kKytxNeSgslUTfXCPAmnRqvLDcEQdu(kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQij)))
  if(kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='tving' or kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='all')and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONTVING:
   kKytxNeSgslUTfXCPAmnRqvLDcEQij=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_ChannelList_Tving()
   if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQij)!=0:kKytxNeSgslUTfXCPAmnRqvLDcEQiO.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQij)
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_log('tving cnt ----> '+kKytxNeSgslUTfXCPAmnRqvLDcEQdu(kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQij)))
  if(kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='spotv' or kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='all')and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSPOTV:
   kKytxNeSgslUTfXCPAmnRqvLDcEQij=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_ChannelList_Spotv(payyn=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSPOTVPAY)
   if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQij)!=0:kKytxNeSgslUTfXCPAmnRqvLDcEQiO.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQij)
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_log('spotv cnt ----> '+kKytxNeSgslUTfXCPAmnRqvLDcEQdu(kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQij)))
  if(kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='samsung' or kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='all')and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSAMSUNG:
   kKytxNeSgslUTfXCPAmnRqvLDcEQiw=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_BaseInfo_Samsungtv()
   kKytxNeSgslUTfXCPAmnRqvLDcEQij=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_ChannelList_Samsungtv(kKytxNeSgslUTfXCPAmnRqvLDcEQiw,exceptGroup=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_EexceptGroup_Samsungtv())
   if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQij)!=0:kKytxNeSgslUTfXCPAmnRqvLDcEQiO.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQij)
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_log('samsungtv cnt ----> '+kKytxNeSgslUTfXCPAmnRqvLDcEQdu(kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQij)))
  if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQiO)==0 and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_CUSTOM_LIST==[]:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti(__language__(30909).encode('utf8'))
   return
  for kKytxNeSgslUTfXCPAmnRqvLDcEQip in kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.INIT_GENRESORT:
   for kKytxNeSgslUTfXCPAmnRqvLDcEQiF in kKytxNeSgslUTfXCPAmnRqvLDcEQiO:
    if kKytxNeSgslUTfXCPAmnRqvLDcEQiF['genrenm']==kKytxNeSgslUTfXCPAmnRqvLDcEQip:
     kKytxNeSgslUTfXCPAmnRqvLDcEQiz.append(kKytxNeSgslUTfXCPAmnRqvLDcEQiF)
  for kKytxNeSgslUTfXCPAmnRqvLDcEQiF in kKytxNeSgslUTfXCPAmnRqvLDcEQiO:
   if kKytxNeSgslUTfXCPAmnRqvLDcEQiF['genrenm']not in kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.INIT_GENRESORT:
    kKytxNeSgslUTfXCPAmnRqvLDcEQiz.append(kKytxNeSgslUTfXCPAmnRqvLDcEQiF)
  try:
   if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQiO)>0:
    kKytxNeSgslUTfXCPAmnRqvLDcEQir=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_M3u_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdb)
    if os.path.isfile(kKytxNeSgslUTfXCPAmnRqvLDcEQir):
     fp=kKytxNeSgslUTfXCPAmnRqvLDcEQdh(kKytxNeSgslUTfXCPAmnRqvLDcEQir,'a',-1,'utf-8')
    else:
     fp=kKytxNeSgslUTfXCPAmnRqvLDcEQdh(kKytxNeSgslUTfXCPAmnRqvLDcEQir,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for kKytxNeSgslUTfXCPAmnRqvLDcEQiu in kKytxNeSgslUTfXCPAmnRqvLDcEQiz:
     kKytxNeSgslUTfXCPAmnRqvLDcEQih =kKytxNeSgslUTfXCPAmnRqvLDcEQiu['channelid']
     kKytxNeSgslUTfXCPAmnRqvLDcEQiG =kKytxNeSgslUTfXCPAmnRqvLDcEQiu['channelnm']
     kKytxNeSgslUTfXCPAmnRqvLDcEQiH=kKytxNeSgslUTfXCPAmnRqvLDcEQiu['channelimg']
     kKytxNeSgslUTfXCPAmnRqvLDcEQiY =kKytxNeSgslUTfXCPAmnRqvLDcEQiu['ott']
     kKytxNeSgslUTfXCPAmnRqvLDcEQiV ='%s.%s'%(kKytxNeSgslUTfXCPAmnRqvLDcEQih,kKytxNeSgslUTfXCPAmnRqvLDcEQiY)
     kKytxNeSgslUTfXCPAmnRqvLDcEQJM=kKytxNeSgslUTfXCPAmnRqvLDcEQiu['genrenm']
     if kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_DISPLAYNM:
      kKytxNeSgslUTfXCPAmnRqvLDcEQiG='%s (%s)'%(kKytxNeSgslUTfXCPAmnRqvLDcEQiG,kKytxNeSgslUTfXCPAmnRqvLDcEQiY)
     if kKytxNeSgslUTfXCPAmnRqvLDcEQJM=='라디오/음악':
      kKytxNeSgslUTfXCPAmnRqvLDcEQJi='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(kKytxNeSgslUTfXCPAmnRqvLDcEQiV,kKytxNeSgslUTfXCPAmnRqvLDcEQiG,kKytxNeSgslUTfXCPAmnRqvLDcEQJM,kKytxNeSgslUTfXCPAmnRqvLDcEQiH,kKytxNeSgslUTfXCPAmnRqvLDcEQiG)
     else:
      kKytxNeSgslUTfXCPAmnRqvLDcEQJi='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(kKytxNeSgslUTfXCPAmnRqvLDcEQiV,kKytxNeSgslUTfXCPAmnRqvLDcEQiG,kKytxNeSgslUTfXCPAmnRqvLDcEQJM,kKytxNeSgslUTfXCPAmnRqvLDcEQiH,kKytxNeSgslUTfXCPAmnRqvLDcEQiG)
     if kKytxNeSgslUTfXCPAmnRqvLDcEQiY=='wavve':
      kKytxNeSgslUTfXCPAmnRqvLDcEQJd ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(kKytxNeSgslUTfXCPAmnRqvLDcEQih)
     elif kKytxNeSgslUTfXCPAmnRqvLDcEQiY=='tving':
      kKytxNeSgslUTfXCPAmnRqvLDcEQJd ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(kKytxNeSgslUTfXCPAmnRqvLDcEQih)
     elif kKytxNeSgslUTfXCPAmnRqvLDcEQiY=='spotv':
      kKytxNeSgslUTfXCPAmnRqvLDcEQJd ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(kKytxNeSgslUTfXCPAmnRqvLDcEQih)
     if kKytxNeSgslUTfXCPAmnRqvLDcEQiY=='samsung':
      kKytxNeSgslUTfXCPAmnRqvLDcEQJd ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(kKytxNeSgslUTfXCPAmnRqvLDcEQih)
     fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJi)
     fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJd)
    fp.close()
  except:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti(__language__(30910).encode('utf8'))
   return
  try:
   if(kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='custom' or kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='all')and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_CUSTOM_LIST!=[]:
    kKytxNeSgslUTfXCPAmnRqvLDcEQir=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_M3u_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdb)
    if os.path.isfile(kKytxNeSgslUTfXCPAmnRqvLDcEQir):
     fp=kKytxNeSgslUTfXCPAmnRqvLDcEQdh(kKytxNeSgslUTfXCPAmnRqvLDcEQir,'a',-1,'utf-8')
    else:
     fp=kKytxNeSgslUTfXCPAmnRqvLDcEQdh(kKytxNeSgslUTfXCPAmnRqvLDcEQir,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for kKytxNeSgslUTfXCPAmnRqvLDcEQJo in kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_CUSTOM_LIST:
     kKytxNeSgslUTfXCPAmnRqvLDcEQJB=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.customEpg_FileRead(kKytxNeSgslUTfXCPAmnRqvLDcEQJo)
     for kKytxNeSgslUTfXCPAmnRqvLDcEQJr in kKytxNeSgslUTfXCPAmnRqvLDcEQJB:
      kKytxNeSgslUTfXCPAmnRqvLDcEQJr=kKytxNeSgslUTfXCPAmnRqvLDcEQJr.strip()
      if kKytxNeSgslUTfXCPAmnRqvLDcEQJr not in['','#EXTM3U']:
       fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJr+'\n')
   fp.close()
  except:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti(__language__(30910).encode('utf8'))
   return
  kKytxNeSgslUTfXCPAmnRqvLDcEQib=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_M3u_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdb)
  kKytxNeSgslUTfXCPAmnRqvLDcEQia=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_M3u_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdO)
  if xbmcvfs.copy(kKytxNeSgslUTfXCPAmnRqvLDcEQib,kKytxNeSgslUTfXCPAmnRqvLDcEQia):
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti((kKytxNeSgslUTfXCPAmnRqvLDcEQiW+' '+__language__(30908)).encode('utf8'))
  else:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti(__language__(30910).encode('utf-8'))
 def customEpg_FileList(kKytxNeSgslUTfXCPAmnRqvLDcEQMB):
  kKytxNeSgslUTfXCPAmnRqvLDcEQJI=[]
  if __addon__.getSetting('custom01on')=='true':kKytxNeSgslUTfXCPAmnRqvLDcEQJI.append(__addon__.getSetting('custom01nm'))
  if __addon__.getSetting('custom02on')=='true':kKytxNeSgslUTfXCPAmnRqvLDcEQJI.append(__addon__.getSetting('custom02nm'))
  if __addon__.getSetting('custom03on')=='true':kKytxNeSgslUTfXCPAmnRqvLDcEQJI.append(__addon__.getSetting('custom03nm'))
  if __addon__.getSetting('custom04on')=='true':kKytxNeSgslUTfXCPAmnRqvLDcEQJI.append(__addon__.getSetting('custom04nm'))
  if __addon__.getSetting('custom05on')=='true':kKytxNeSgslUTfXCPAmnRqvLDcEQJI.append(__addon__.getSetting('custom05nm'))
  return kKytxNeSgslUTfXCPAmnRqvLDcEQJI
 def customEpg_FileRead(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,source_filename):
  try:
   kKytxNeSgslUTfXCPAmnRqvLDcEQJW=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
   if os.path.isfile(kKytxNeSgslUTfXCPAmnRqvLDcEQJW):os.remove(kKytxNeSgslUTfXCPAmnRqvLDcEQJW)
   xbmcvfs.copy(source_filename,kKytxNeSgslUTfXCPAmnRqvLDcEQJW)
   fp=kKytxNeSgslUTfXCPAmnRqvLDcEQdh(kKytxNeSgslUTfXCPAmnRqvLDcEQJW,'r',-1,'utf-8')
   kKytxNeSgslUTfXCPAmnRqvLDcEQJO=fp.readlines()
  except:
   return[]
  return kKytxNeSgslUTfXCPAmnRqvLDcEQJO
 def dp_Make_Epg(kKytxNeSgslUTfXCPAmnRqvLDcEQMB,args):
  kKytxNeSgslUTfXCPAmnRqvLDcEQiI=args.get('sType')
  kKytxNeSgslUTfXCPAmnRqvLDcEQiW=args.get('sName')
  kKytxNeSgslUTfXCPAmnRqvLDcEQJz=args.get('sNoti')
  if kKytxNeSgslUTfXCPAmnRqvLDcEQJz!='N':
   kKytxNeSgslUTfXCPAmnRqvLDcEQMz=xbmcgui.Dialog()
   kKytxNeSgslUTfXCPAmnRqvLDcEQiB=kKytxNeSgslUTfXCPAmnRqvLDcEQMz.yesno((kKytxNeSgslUTfXCPAmnRqvLDcEQiW+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if kKytxNeSgslUTfXCPAmnRqvLDcEQiB==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:sys.exit()
  kKytxNeSgslUTfXCPAmnRqvLDcEQJb=[]
  kKytxNeSgslUTfXCPAmnRqvLDcEQJa=[]
  if(kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='wavve' or kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='all')and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVE:
   kKytxNeSgslUTfXCPAmnRqvLDcEQJj,kKytxNeSgslUTfXCPAmnRqvLDcEQJw=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_EexceptGroup_Wavve())
   if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQJw)!=0:
    kKytxNeSgslUTfXCPAmnRqvLDcEQJb.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQJj)
    kKytxNeSgslUTfXCPAmnRqvLDcEQJa.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQJw)
  if(kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='tving' or kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='all')and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONTVING:
   kKytxNeSgslUTfXCPAmnRqvLDcEQJj,kKytxNeSgslUTfXCPAmnRqvLDcEQJw=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_EpgInfo_Tving()
   if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQJw)!=0:
    kKytxNeSgslUTfXCPAmnRqvLDcEQJb.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQJj)
    kKytxNeSgslUTfXCPAmnRqvLDcEQJa.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQJw)
  if(kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='spotv' or kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='all')and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSPOTV:
   kKytxNeSgslUTfXCPAmnRqvLDcEQJj,kKytxNeSgslUTfXCPAmnRqvLDcEQJw=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_EpgInfo_Spotv(payyn=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSPOTVPAY)
   if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQJw)!=0:
    kKytxNeSgslUTfXCPAmnRqvLDcEQJb.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQJj)
    kKytxNeSgslUTfXCPAmnRqvLDcEQJa.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQJw)
  if(kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='samsung' or kKytxNeSgslUTfXCPAmnRqvLDcEQiI=='all')and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSAMSUNG:
   kKytxNeSgslUTfXCPAmnRqvLDcEQiw=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_BaseInfo_Samsungtv()
   kKytxNeSgslUTfXCPAmnRqvLDcEQJj,kKytxNeSgslUTfXCPAmnRqvLDcEQJw=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_EpgInfo_Samsungtv(kKytxNeSgslUTfXCPAmnRqvLDcEQiw,exceptGroup=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_EexceptGroup_Samsungtv())
   if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQJw)!=0:
    kKytxNeSgslUTfXCPAmnRqvLDcEQJb.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQJj)
    kKytxNeSgslUTfXCPAmnRqvLDcEQJa.extend(kKytxNeSgslUTfXCPAmnRqvLDcEQJw)
  if kKytxNeSgslUTfXCPAmnRqvLDcEQdF(kKytxNeSgslUTfXCPAmnRqvLDcEQJa)==0:
   if kKytxNeSgslUTfXCPAmnRqvLDcEQJz!='N':kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   kKytxNeSgslUTfXCPAmnRqvLDcEQir=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_Epg_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdb)
   fp=kKytxNeSgslUTfXCPAmnRqvLDcEQdh(kKytxNeSgslUTfXCPAmnRqvLDcEQir,'w',-1,'utf-8')
   kKytxNeSgslUTfXCPAmnRqvLDcEQJp='<?xml version="1.0" encoding="UTF-8"?>\n'
   kKytxNeSgslUTfXCPAmnRqvLDcEQJF='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   kKytxNeSgslUTfXCPAmnRqvLDcEQJu='<tv generator-info-name="boritv_epg">\n\n'
   kKytxNeSgslUTfXCPAmnRqvLDcEQJh='\n</tv>\n'
   fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJp)
   fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJF)
   fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJu)
   for kKytxNeSgslUTfXCPAmnRqvLDcEQJG in kKytxNeSgslUTfXCPAmnRqvLDcEQJb:
    kKytxNeSgslUTfXCPAmnRqvLDcEQJH='  <channel id="%s.%s">\n' %(kKytxNeSgslUTfXCPAmnRqvLDcEQJG.get('channelid'),kKytxNeSgslUTfXCPAmnRqvLDcEQJG.get('ott'))
    kKytxNeSgslUTfXCPAmnRqvLDcEQJY='    <display-name>%s</display-name>\n'%(kKytxNeSgslUTfXCPAmnRqvLDcEQJG.get('channelnm'))
    kKytxNeSgslUTfXCPAmnRqvLDcEQJV='    <icon src="%s" />\n' %(kKytxNeSgslUTfXCPAmnRqvLDcEQJG.get('channelimg'))
    kKytxNeSgslUTfXCPAmnRqvLDcEQdM='  </channel>\n\n'
    fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJH)
    fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJY)
    fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJV)
    fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQdM)
   for kKytxNeSgslUTfXCPAmnRqvLDcEQJG in kKytxNeSgslUTfXCPAmnRqvLDcEQJa:
    kKytxNeSgslUTfXCPAmnRqvLDcEQJH='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(kKytxNeSgslUTfXCPAmnRqvLDcEQJG.get('startTime'),kKytxNeSgslUTfXCPAmnRqvLDcEQJG.get('endTime'),kKytxNeSgslUTfXCPAmnRqvLDcEQJG.get('channelid'),kKytxNeSgslUTfXCPAmnRqvLDcEQJG.get('ott'))
    kKytxNeSgslUTfXCPAmnRqvLDcEQJY='    <title lang="kr">%s</title>\n' %(kKytxNeSgslUTfXCPAmnRqvLDcEQJG.get('title'))
    kKytxNeSgslUTfXCPAmnRqvLDcEQJV='  </programme>\n\n'
    fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJH)
    fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJY)
    fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJV)
   fp.write(kKytxNeSgslUTfXCPAmnRqvLDcEQJh)
   fp.close()
  except:
   if kKytxNeSgslUTfXCPAmnRqvLDcEQJz!='N':kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti(__language__(30910).encode('utf8'))
   return
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.MakeEpg_SaveJson()
  kKytxNeSgslUTfXCPAmnRqvLDcEQib=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_Epg_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdb)
  kKytxNeSgslUTfXCPAmnRqvLDcEQia=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.make_Epg_Filename(tempyn=kKytxNeSgslUTfXCPAmnRqvLDcEQdO)
  if xbmcvfs.copy(kKytxNeSgslUTfXCPAmnRqvLDcEQib,kKytxNeSgslUTfXCPAmnRqvLDcEQia):
   if kKytxNeSgslUTfXCPAmnRqvLDcEQJz!='N':kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti((kKytxNeSgslUTfXCPAmnRqvLDcEQiW+' '+__language__(30912)).encode('utf8'))
  else:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_AUTORESTART:
    kKytxNeSgslUTfXCPAmnRqvLDcEQdi=xbmcaddon.Addon('pvr.iptvsimple')
    kKytxNeSgslUTfXCPAmnRqvLDcEQdi.setSetting('anything','anything')
  except:
   kKytxNeSgslUTfXCPAmnRqvLDcEQdz 
 def make_EexceptGroup_Wavve(kKytxNeSgslUTfXCPAmnRqvLDcEQMB):
  kKytxNeSgslUTfXCPAmnRqvLDcEQdJ=[]
  if kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVERADIO==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:
   kKytxNeSgslUTfXCPAmnRqvLDcEQdJ.append('라디오/음악')
  if kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVEHOME==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:
   kKytxNeSgslUTfXCPAmnRqvLDcEQdJ.append('홈쇼핑')
  if kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONRELIGION==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:
   kKytxNeSgslUTfXCPAmnRqvLDcEQdJ.append('종교')
  return kKytxNeSgslUTfXCPAmnRqvLDcEQdJ
 def make_EexceptGroup_Samsungtv(kKytxNeSgslUTfXCPAmnRqvLDcEQMB):
  kKytxNeSgslUTfXCPAmnRqvLDcEQdJ=[]
  if kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSAMSUNGHOME==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:
   kKytxNeSgslUTfXCPAmnRqvLDcEQdJ.append('홈쇼핑')
  return kKytxNeSgslUTfXCPAmnRqvLDcEQdJ
 def get_radio_list(kKytxNeSgslUTfXCPAmnRqvLDcEQMB):
  if kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVERADIO==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:return[]
  kKytxNeSgslUTfXCPAmnRqvLDcEQdo=[{'broadcastid':'46584','genre':'10'}]
  return kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_ChannelList_WavveExcept(kKytxNeSgslUTfXCPAmnRqvLDcEQdo)
 def check_config(kKytxNeSgslUTfXCPAmnRqvLDcEQMB):
  kKytxNeSgslUTfXCPAmnRqvLDcEQdB=kKytxNeSgslUTfXCPAmnRqvLDcEQdb
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVE =kKytxNeSgslUTfXCPAmnRqvLDcEQdb if __addon__.getSetting('onWavve')=='true' else kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONTVING =kKytxNeSgslUTfXCPAmnRqvLDcEQdb if __addon__.getSetting('onTvng')=='true' else kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSPOTV =kKytxNeSgslUTfXCPAmnRqvLDcEQdb if __addon__.getSetting('onSpotv')=='true' else kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSAMSUNG =kKytxNeSgslUTfXCPAmnRqvLDcEQdb if __addon__.getSetting('onSamsung')=='true' else kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVERADIO =kKytxNeSgslUTfXCPAmnRqvLDcEQdb if __addon__.getSetting('onWavveRadio')=='true' else kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVEHOME =kKytxNeSgslUTfXCPAmnRqvLDcEQdb if __addon__.getSetting('onWavveHome')=='true' else kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONRELIGION =kKytxNeSgslUTfXCPAmnRqvLDcEQdb if __addon__.getSetting('onWavveReligion')=='true' else kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSPOTVPAY =kKytxNeSgslUTfXCPAmnRqvLDcEQdb if __addon__.getSetting('onSpotvPay')=='true' else kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSAMSUNGHOME =kKytxNeSgslUTfXCPAmnRqvLDcEQdb if __addon__.getSetting('onSamsungHome')=='true' else kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_DISPLAYNM =kKytxNeSgslUTfXCPAmnRqvLDcEQdb if __addon__.getSetting('displayOTTnm')=='true' else kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_AUTORESTART =kKytxNeSgslUTfXCPAmnRqvLDcEQdb if __addon__.getSetting('autoRestart')=='true' else kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_CUSTOM_LIST =kKytxNeSgslUTfXCPAmnRqvLDcEQMB.customEpg_FileList()
  if kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_FILE_PATH=='' or kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_FILE_NAME=='':kKytxNeSgslUTfXCPAmnRqvLDcEQdB=kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  if kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONWAVVE==kKytxNeSgslUTfXCPAmnRqvLDcEQdO and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONTVING==kKytxNeSgslUTfXCPAmnRqvLDcEQdO and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSPOTV==kKytxNeSgslUTfXCPAmnRqvLDcEQdO and kKytxNeSgslUTfXCPAmnRqvLDcEQMB.M3U_ONSAMSUNG==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:kKytxNeSgslUTfXCPAmnRqvLDcEQdB=kKytxNeSgslUTfXCPAmnRqvLDcEQdO
  if kKytxNeSgslUTfXCPAmnRqvLDcEQdB==kKytxNeSgslUTfXCPAmnRqvLDcEQdO:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMz=xbmcgui.Dialog()
   kKytxNeSgslUTfXCPAmnRqvLDcEQiB=kKytxNeSgslUTfXCPAmnRqvLDcEQMz.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if kKytxNeSgslUTfXCPAmnRqvLDcEQiB==kKytxNeSgslUTfXCPAmnRqvLDcEQdb:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(kKytxNeSgslUTfXCPAmnRqvLDcEQMB):
  kKytxNeSgslUTfXCPAmnRqvLDcEQdr={'date_makeepg':kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=kKytxNeSgslUTfXCPAmnRqvLDcEQdh(kKytxNeSgslUTfXCPAmnRqvLDcEQMo,'w',-1,'utf-8')
   json.dump(kKytxNeSgslUTfXCPAmnRqvLDcEQdr,fp)
   fp.close()
  except kKytxNeSgslUTfXCPAmnRqvLDcEQdG as exception:
   return
 def boritv_main(kKytxNeSgslUTfXCPAmnRqvLDcEQMB):
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.BoritvObj.KodiVersion=kKytxNeSgslUTfXCPAmnRqvLDcEQdw(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  kKytxNeSgslUTfXCPAmnRqvLDcEQdI=kKytxNeSgslUTfXCPAmnRqvLDcEQMB.main_params.get('mode',kKytxNeSgslUTfXCPAmnRqvLDcEQdz)
  kKytxNeSgslUTfXCPAmnRqvLDcEQMB.check_config()
  if kKytxNeSgslUTfXCPAmnRqvLDcEQdI is kKytxNeSgslUTfXCPAmnRqvLDcEQdz:
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.dp_Main_List()
  elif kKytxNeSgslUTfXCPAmnRqvLDcEQdI=='DEL_M3U':
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.dp_Delete_M3u(kKytxNeSgslUTfXCPAmnRqvLDcEQMB.main_params)
  elif kKytxNeSgslUTfXCPAmnRqvLDcEQdI=='ADD_M3U':
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.dp_MakeAdd_M3u(kKytxNeSgslUTfXCPAmnRqvLDcEQMB.main_params)
  elif kKytxNeSgslUTfXCPAmnRqvLDcEQdI=='ADD_EPG':
   kKytxNeSgslUTfXCPAmnRqvLDcEQMB.dp_Make_Epg(kKytxNeSgslUTfXCPAmnRqvLDcEQMB.main_params)
  else:
   kKytxNeSgslUTfXCPAmnRqvLDcEQdz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
