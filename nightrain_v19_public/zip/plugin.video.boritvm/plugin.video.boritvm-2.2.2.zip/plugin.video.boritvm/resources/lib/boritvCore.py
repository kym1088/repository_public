__author__="NightRain"
GIVAofBEHlkeircXMsQvuzmLDFbpPd=False
GIVAofBEHlkeircXMsQvuzmLDFbpPO=object
GIVAofBEHlkeircXMsQvuzmLDFbpPx=None
GIVAofBEHlkeircXMsQvuzmLDFbpPh=str
GIVAofBEHlkeircXMsQvuzmLDFbpPU=Exception
GIVAofBEHlkeircXMsQvuzmLDFbpPY=print
GIVAofBEHlkeircXMsQvuzmLDFbpgn=True
GIVAofBEHlkeircXMsQvuzmLDFbpgt=int
GIVAofBEHlkeircXMsQvuzmLDFbpgR=range
GIVAofBEHlkeircXMsQvuzmLDFbpgP=len
GIVAofBEHlkeircXMsQvuzmLDFbpgw=dict
GIVAofBEHlkeircXMsQvuzmLDFbpgq=set
GIVAofBEHlkeircXMsQvuzmLDFbpgK=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
GIVAofBEHlkeircXMsQvuzmLDFbpnR=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
GIVAofBEHlkeircXMsQvuzmLDFbpnP=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':GIVAofBEHlkeircXMsQvuzmLDFbpPd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':GIVAofBEHlkeircXMsQvuzmLDFbpPd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':GIVAofBEHlkeircXMsQvuzmLDFbpPd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':GIVAofBEHlkeircXMsQvuzmLDFbpPd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':GIVAofBEHlkeircXMsQvuzmLDFbpPd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':GIVAofBEHlkeircXMsQvuzmLDFbpPd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class GIVAofBEHlkeircXMsQvuzmLDFbpnt(GIVAofBEHlkeircXMsQvuzmLDFbpPO):
 def __init__(GIVAofBEHlkeircXMsQvuzmLDFbpng):
  GIVAofBEHlkeircXMsQvuzmLDFbpng.API_WAVVE ='https://apis.wavve.com'
  GIVAofBEHlkeircXMsQvuzmLDFbpng.API_TVING ='https://api.tving.com'
  GIVAofBEHlkeircXMsQvuzmLDFbpng.API_TVINGIMG ='https://image.tving.com'
  GIVAofBEHlkeircXMsQvuzmLDFbpng.API_SPOTV ='https://www.spotvnow.co.kr'
  GIVAofBEHlkeircXMsQvuzmLDFbpng.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  GIVAofBEHlkeircXMsQvuzmLDFbpng.HTTPTAG ='https://'
  GIVAofBEHlkeircXMsQvuzmLDFbpng.LIMIT_WAVVE =500
  GIVAofBEHlkeircXMsQvuzmLDFbpng.LIMIT_TVING =60
  GIVAofBEHlkeircXMsQvuzmLDFbpng.LIMIT_TVINGEPG=20 
  GIVAofBEHlkeircXMsQvuzmLDFbpng.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
  GIVAofBEHlkeircXMsQvuzmLDFbpng.APPVERSION ='115.0.0.0' 
  GIVAofBEHlkeircXMsQvuzmLDFbpng.DEVICEMODEL ='Chrome' 
  GIVAofBEHlkeircXMsQvuzmLDFbpng.OSTYPE ='Windows' 
  GIVAofBEHlkeircXMsQvuzmLDFbpng.OSVERSION ='NT 10.0' 
  GIVAofBEHlkeircXMsQvuzmLDFbpng.DEFAULT_HEADER={'user-agent':GIVAofBEHlkeircXMsQvuzmLDFbpng.USER_AGENT}
  GIVAofBEHlkeircXMsQvuzmLDFbpng.SLEEP_TIME =0.2
  GIVAofBEHlkeircXMsQvuzmLDFbpng.INIT_GENRESORT=MASTER_GENRE
  GIVAofBEHlkeircXMsQvuzmLDFbpng.INIT_CHANNEL =MASTER_CHANNEL
  GIVAofBEHlkeircXMsQvuzmLDFbpng.KodiVersion =20
 def callRequestCookies(GIVAofBEHlkeircXMsQvuzmLDFbpng,jobtype,GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpPx,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx,redirects=GIVAofBEHlkeircXMsQvuzmLDFbpPd):
  GIVAofBEHlkeircXMsQvuzmLDFbpnK=GIVAofBEHlkeircXMsQvuzmLDFbpng.DEFAULT_HEADER
  if headers:GIVAofBEHlkeircXMsQvuzmLDFbpnK.update(headers)
  if jobtype=='Get':
   GIVAofBEHlkeircXMsQvuzmLDFbpnC=requests.get(GIVAofBEHlkeircXMsQvuzmLDFbpnT,params=params,headers=GIVAofBEHlkeircXMsQvuzmLDFbpnK,cookies=cookies,allow_redirects=redirects)
  else:
   GIVAofBEHlkeircXMsQvuzmLDFbpnC=requests.post(GIVAofBEHlkeircXMsQvuzmLDFbpnT,data=payload,params=params,headers=GIVAofBEHlkeircXMsQvuzmLDFbpnK,cookies=cookies,allow_redirects=redirects)
  return GIVAofBEHlkeircXMsQvuzmLDFbpnC
 def Get_DefaultParams_Wavve(GIVAofBEHlkeircXMsQvuzmLDFbpng):
  GIVAofBEHlkeircXMsQvuzmLDFbpnj={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return GIVAofBEHlkeircXMsQvuzmLDFbpnj
 def Get_DefaultParams_Tving(GIVAofBEHlkeircXMsQvuzmLDFbpng):
  GIVAofBEHlkeircXMsQvuzmLDFbpnj={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return GIVAofBEHlkeircXMsQvuzmLDFbpnj
 def Get_Now_Datetime(GIVAofBEHlkeircXMsQvuzmLDFbpng):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(GIVAofBEHlkeircXMsQvuzmLDFbpng,in_text):
  GIVAofBEHlkeircXMsQvuzmLDFbpnS=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return GIVAofBEHlkeircXMsQvuzmLDFbpnS
 def Get_ChannelList_Wavve(GIVAofBEHlkeircXMsQvuzmLDFbpng,exceptGroup=[]):
  GIVAofBEHlkeircXMsQvuzmLDFbpnN =[]
  GIVAofBEHlkeircXMsQvuzmLDFbpnJ=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_ChannelImg_Wavve()
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_WAVVE+'/cf/live/recommend-channels'
   GIVAofBEHlkeircXMsQvuzmLDFbpnj={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpng.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   GIVAofBEHlkeircXMsQvuzmLDFbpnj.update(GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_DefaultParams_Wavve())
   GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpnj,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
   GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
   if not('celllist' in GIVAofBEHlkeircXMsQvuzmLDFbpna['cell_toplist']):return GIVAofBEHlkeircXMsQvuzmLDFbpnN
   GIVAofBEHlkeircXMsQvuzmLDFbpnd=GIVAofBEHlkeircXMsQvuzmLDFbpna['cell_toplist']['celllist']
   for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpnd:
    GIVAofBEHlkeircXMsQvuzmLDFbpnx=GIVAofBEHlkeircXMsQvuzmLDFbpnO['contentid']
    GIVAofBEHlkeircXMsQvuzmLDFbpnh=GIVAofBEHlkeircXMsQvuzmLDFbpnO['title_list'][0]['text']
    if GIVAofBEHlkeircXMsQvuzmLDFbpnx in GIVAofBEHlkeircXMsQvuzmLDFbpnJ:
     GIVAofBEHlkeircXMsQvuzmLDFbpnU=GIVAofBEHlkeircXMsQvuzmLDFbpnJ[GIVAofBEHlkeircXMsQvuzmLDFbpnx]
    else:
     GIVAofBEHlkeircXMsQvuzmLDFbpnU=''
    GIVAofBEHlkeircXMsQvuzmLDFbpnY=GIVAofBEHlkeircXMsQvuzmLDFbpng.make_getGenre(GIVAofBEHlkeircXMsQvuzmLDFbpnx,'wavve')
    GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnx,'channelnm':GIVAofBEHlkeircXMsQvuzmLDFbpnh,'channelimg':GIVAofBEHlkeircXMsQvuzmLDFbpng.HTTPTAG+GIVAofBEHlkeircXMsQvuzmLDFbpnU if GIVAofBEHlkeircXMsQvuzmLDFbpnU!='' else '','ott':'wavve','genrenm':GIVAofBEHlkeircXMsQvuzmLDFbpnY}
    if GIVAofBEHlkeircXMsQvuzmLDFbpnY not in exceptGroup:
     GIVAofBEHlkeircXMsQvuzmLDFbpnN.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[]
  return GIVAofBEHlkeircXMsQvuzmLDFbpnN
 def Get_ChannelList_WavveExcept(GIVAofBEHlkeircXMsQvuzmLDFbpng,exceptGroup=[]):
  GIVAofBEHlkeircXMsQvuzmLDFbpnN=[]
  if exceptGroup==[]:return[]
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_WAVVE+'/cf/live/recommend-channels'
   for GIVAofBEHlkeircXMsQvuzmLDFbpnO in exceptGroup:
    GIVAofBEHlkeircXMsQvuzmLDFbpnj={'WeekDay':'all','adult':'n','broadcastid':GIVAofBEHlkeircXMsQvuzmLDFbpnO['broadcastid'],'contenttype':'channel','genre':GIVAofBEHlkeircXMsQvuzmLDFbpnO['genre'],'isrecommend':'y','limit':GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpng.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    GIVAofBEHlkeircXMsQvuzmLDFbpnj.update(GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_DefaultParams_Wavve())
    GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpnj,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
    GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
    if not('celllist' in GIVAofBEHlkeircXMsQvuzmLDFbpna['cell_toplist']):return GIVAofBEHlkeircXMsQvuzmLDFbpnN
    GIVAofBEHlkeircXMsQvuzmLDFbpnd=GIVAofBEHlkeircXMsQvuzmLDFbpna['cell_toplist']['celllist']
    for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpnd:
     GIVAofBEHlkeircXMsQvuzmLDFbpnN.append(GIVAofBEHlkeircXMsQvuzmLDFbpnO['contentid'])
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[]
  return GIVAofBEHlkeircXMsQvuzmLDFbpnN
 def Get_ChannelImg_Wavve(GIVAofBEHlkeircXMsQvuzmLDFbpng):
  GIVAofBEHlkeircXMsQvuzmLDFbptR={}
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbptP=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_Now_Datetime()
   GIVAofBEHlkeircXMsQvuzmLDFbptg =GIVAofBEHlkeircXMsQvuzmLDFbptP+datetime.timedelta(hours=3)
   GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_WAVVE+'/live/epgs'
   GIVAofBEHlkeircXMsQvuzmLDFbpnj={'limit':GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpng.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':GIVAofBEHlkeircXMsQvuzmLDFbptP.strftime('%Y-%m-%d %H:00'),'enddatetime':GIVAofBEHlkeircXMsQvuzmLDFbptg.strftime('%Y-%m-%d %H:00')}
   GIVAofBEHlkeircXMsQvuzmLDFbpnj.update(GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_DefaultParams_Wavve())
   GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpnj,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
   GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
   GIVAofBEHlkeircXMsQvuzmLDFbpnd=GIVAofBEHlkeircXMsQvuzmLDFbpna['list']
   for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpnd:
    GIVAofBEHlkeircXMsQvuzmLDFbptR[GIVAofBEHlkeircXMsQvuzmLDFbpnO['channelid']]=GIVAofBEHlkeircXMsQvuzmLDFbpnO['channelimage']
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
  return GIVAofBEHlkeircXMsQvuzmLDFbptR
 def Get_ChanneGenrename_Wavve(GIVAofBEHlkeircXMsQvuzmLDFbpng,GIVAofBEHlkeircXMsQvuzmLDFbpnx):
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_WAVVE+'/live/channels/'+GIVAofBEHlkeircXMsQvuzmLDFbpnx
   GIVAofBEHlkeircXMsQvuzmLDFbpnj=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_DefaultParams_Wavve()
   GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpnj,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
   GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
   GIVAofBEHlkeircXMsQvuzmLDFbptw=GIVAofBEHlkeircXMsQvuzmLDFbpna['genretext']
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return ''
  return GIVAofBEHlkeircXMsQvuzmLDFbptw
 def Get_ChannelList_Spotv(GIVAofBEHlkeircXMsQvuzmLDFbpng,payyn=GIVAofBEHlkeircXMsQvuzmLDFbpgn):
  GIVAofBEHlkeircXMsQvuzmLDFbpnN=[]
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_SPOTV+'/api/v3/channel'
   GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpPx,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
   GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
   for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpna:
    GIVAofBEHlkeircXMsQvuzmLDFbpnx=GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpnO['id'])
    GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnx,'channelnm':GIVAofBEHlkeircXMsQvuzmLDFbpnO['name'],'channelimg':GIVAofBEHlkeircXMsQvuzmLDFbpnO['logo'],'ott':'spotv','genrenm':GIVAofBEHlkeircXMsQvuzmLDFbpng.make_getGenre(GIVAofBEHlkeircXMsQvuzmLDFbpnx,'spotv'),'free':GIVAofBEHlkeircXMsQvuzmLDFbpnO['free']}
    GIVAofBEHlkeircXMsQvuzmLDFbpnN.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[]
  return GIVAofBEHlkeircXMsQvuzmLDFbpnN
 def Get_ChannelList_Tving(GIVAofBEHlkeircXMsQvuzmLDFbpng):
  GIVAofBEHlkeircXMsQvuzmLDFbpnN =[]
  GIVAofBEHlkeircXMsQvuzmLDFbptq=[]
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_TVING+'/v2/media/lives'
   GIVAofBEHlkeircXMsQvuzmLDFbpnj={'pageNo':'1','pageSize':GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpng.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   GIVAofBEHlkeircXMsQvuzmLDFbpnj.update(GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_DefaultParams_Tving())
   GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpnj,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
   GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
   if not('result' in GIVAofBEHlkeircXMsQvuzmLDFbpna['body']):return GIVAofBEHlkeircXMsQvuzmLDFbpnN
   GIVAofBEHlkeircXMsQvuzmLDFbpnd=GIVAofBEHlkeircXMsQvuzmLDFbpna['body']['result']
   for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpnd:
    if GIVAofBEHlkeircXMsQvuzmLDFbpnO['live_code']=='C44441':continue 
    GIVAofBEHlkeircXMsQvuzmLDFbptq.append(GIVAofBEHlkeircXMsQvuzmLDFbpnO['live_code'])
   GIVAofBEHlkeircXMsQvuzmLDFbpnJ=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_ChannelImg_Tving(GIVAofBEHlkeircXMsQvuzmLDFbptq)
   for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpnd:
    GIVAofBEHlkeircXMsQvuzmLDFbpnx=GIVAofBEHlkeircXMsQvuzmLDFbpnO['live_code']
    if GIVAofBEHlkeircXMsQvuzmLDFbpnx=='C44441':continue 
    GIVAofBEHlkeircXMsQvuzmLDFbpnh=GIVAofBEHlkeircXMsQvuzmLDFbpnO['schedule']['channel']['name']['ko']
    if GIVAofBEHlkeircXMsQvuzmLDFbpnx in GIVAofBEHlkeircXMsQvuzmLDFbpnJ:
     GIVAofBEHlkeircXMsQvuzmLDFbpnU=GIVAofBEHlkeircXMsQvuzmLDFbpnJ[GIVAofBEHlkeircXMsQvuzmLDFbpnx]
    else:
     GIVAofBEHlkeircXMsQvuzmLDFbpnU=''
    GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnx,'channelnm':GIVAofBEHlkeircXMsQvuzmLDFbpnh,'channelimg':GIVAofBEHlkeircXMsQvuzmLDFbpnU,'ott':'tving','genrenm':GIVAofBEHlkeircXMsQvuzmLDFbpng.make_getGenre(GIVAofBEHlkeircXMsQvuzmLDFbpnx,'tving')}
    GIVAofBEHlkeircXMsQvuzmLDFbpnN.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[]
  return GIVAofBEHlkeircXMsQvuzmLDFbpnN
 def Get_timestamp(GIVAofBEHlkeircXMsQvuzmLDFbpng,timetype=1):
  ts=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(GIVAofBEHlkeircXMsQvuzmLDFbpng,timetype):
  if timetype=='1':
   GIVAofBEHlkeircXMsQvuzmLDFbptK={'transactionId':GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   GIVAofBEHlkeircXMsQvuzmLDFbptK={'timestamp':GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_timestamp(timetype=1),'transactionId':GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_timestamp(timetype=1)+'000000000000001',}
  return GIVAofBEHlkeircXMsQvuzmLDFbptK
 def make_EpgDatetime_Tving(GIVAofBEHlkeircXMsQvuzmLDFbpng,days=2):
  GIVAofBEHlkeircXMsQvuzmLDFbptC=[]
  GIVAofBEHlkeircXMsQvuzmLDFbptj=GIVAofBEHlkeircXMsQvuzmLDFbpng.make_DateList(days=2,dateType='2')
  GIVAofBEHlkeircXMsQvuzmLDFbptW=GIVAofBEHlkeircXMsQvuzmLDFbpgt(GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbptj:
   for GIVAofBEHlkeircXMsQvuzmLDFbptS in GIVAofBEHlkeircXMsQvuzmLDFbpgR(8):
    GIVAofBEHlkeircXMsQvuzmLDFbptn={'ndate':GIVAofBEHlkeircXMsQvuzmLDFbpnO,'starttm':GIVAofBEHlkeircXMsQvuzmLDFbpnR[GIVAofBEHlkeircXMsQvuzmLDFbptS]['starttm'],'endtm':GIVAofBEHlkeircXMsQvuzmLDFbpnR[GIVAofBEHlkeircXMsQvuzmLDFbptS]['endtm']}
    GIVAofBEHlkeircXMsQvuzmLDFbptN=GIVAofBEHlkeircXMsQvuzmLDFbpgt(GIVAofBEHlkeircXMsQvuzmLDFbpnO+GIVAofBEHlkeircXMsQvuzmLDFbpnR[GIVAofBEHlkeircXMsQvuzmLDFbptS]['starttm'])
    GIVAofBEHlkeircXMsQvuzmLDFbptJ=GIVAofBEHlkeircXMsQvuzmLDFbpgt(GIVAofBEHlkeircXMsQvuzmLDFbpnO+GIVAofBEHlkeircXMsQvuzmLDFbpnR[GIVAofBEHlkeircXMsQvuzmLDFbptS]['endtm'])
    if GIVAofBEHlkeircXMsQvuzmLDFbptW<=GIVAofBEHlkeircXMsQvuzmLDFbptN or(GIVAofBEHlkeircXMsQvuzmLDFbptN<GIVAofBEHlkeircXMsQvuzmLDFbptW and GIVAofBEHlkeircXMsQvuzmLDFbptW<GIVAofBEHlkeircXMsQvuzmLDFbptJ):
     GIVAofBEHlkeircXMsQvuzmLDFbptC.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  return GIVAofBEHlkeircXMsQvuzmLDFbptC
 def make_DateList(GIVAofBEHlkeircXMsQvuzmLDFbpng,days=2,dateType='1'):
  GIVAofBEHlkeircXMsQvuzmLDFbptj=[]
  GIVAofBEHlkeircXMsQvuzmLDFbptT =GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_Now_Datetime()
  for i in GIVAofBEHlkeircXMsQvuzmLDFbpgR(days):
   GIVAofBEHlkeircXMsQvuzmLDFbpty=GIVAofBEHlkeircXMsQvuzmLDFbptT+datetime.timedelta(days=i)
   if dateType=='1':
    GIVAofBEHlkeircXMsQvuzmLDFbptj.append(GIVAofBEHlkeircXMsQvuzmLDFbpty.strftime('%Y-%m-%d'))
   else:
    GIVAofBEHlkeircXMsQvuzmLDFbptj.append(GIVAofBEHlkeircXMsQvuzmLDFbpty.strftime('%Y%m%d'))
  return GIVAofBEHlkeircXMsQvuzmLDFbptj
 def make_Tving_ChannleGroup(GIVAofBEHlkeircXMsQvuzmLDFbpng,GIVAofBEHlkeircXMsQvuzmLDFbptq):
  GIVAofBEHlkeircXMsQvuzmLDFbpta=[]
  i=0
  GIVAofBEHlkeircXMsQvuzmLDFbptd=''
  for GIVAofBEHlkeircXMsQvuzmLDFbptO in GIVAofBEHlkeircXMsQvuzmLDFbptq:
   if i==0:GIVAofBEHlkeircXMsQvuzmLDFbptd=GIVAofBEHlkeircXMsQvuzmLDFbptO
   else:GIVAofBEHlkeircXMsQvuzmLDFbptd+=',%s'%(GIVAofBEHlkeircXMsQvuzmLDFbptO)
   i+=1
   if i>=GIVAofBEHlkeircXMsQvuzmLDFbpng.LIMIT_TVINGEPG:
    GIVAofBEHlkeircXMsQvuzmLDFbpta.append(GIVAofBEHlkeircXMsQvuzmLDFbptd)
    i=0
    GIVAofBEHlkeircXMsQvuzmLDFbptd=''
  if GIVAofBEHlkeircXMsQvuzmLDFbptd!='':
   GIVAofBEHlkeircXMsQvuzmLDFbpta.append(GIVAofBEHlkeircXMsQvuzmLDFbptd)
  return GIVAofBEHlkeircXMsQvuzmLDFbpta
 def Get_ChannelImg_Tving(GIVAofBEHlkeircXMsQvuzmLDFbpng,chid_list):
  GIVAofBEHlkeircXMsQvuzmLDFbptR={}
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbptx=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_Now_Datetime().strftime('%Y%m%d')
   GIVAofBEHlkeircXMsQvuzmLDFbptP =GIVAofBEHlkeircXMsQvuzmLDFbpnR[6]['starttm'] 
   GIVAofBEHlkeircXMsQvuzmLDFbptg =GIVAofBEHlkeircXMsQvuzmLDFbpnR[6]['endtm']
   GIVAofBEHlkeircXMsQvuzmLDFbpta=GIVAofBEHlkeircXMsQvuzmLDFbpng.make_Tving_ChannleGroup(chid_list)
   for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpta:
    GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_TVING+'/v2/media/schedules'
    GIVAofBEHlkeircXMsQvuzmLDFbpnj={'pageNo':'1','pageSize':GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpng.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':GIVAofBEHlkeircXMsQvuzmLDFbptx,'broadcastDate':GIVAofBEHlkeircXMsQvuzmLDFbptx,'startBroadTime':GIVAofBEHlkeircXMsQvuzmLDFbptP,'endBroadTime':GIVAofBEHlkeircXMsQvuzmLDFbptg,'channelCode':GIVAofBEHlkeircXMsQvuzmLDFbpnO}
    GIVAofBEHlkeircXMsQvuzmLDFbpnj.update(GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_DefaultParams_Tving())
    GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpnj,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
    GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
    if not('result' in GIVAofBEHlkeircXMsQvuzmLDFbpna['body']):return{}
    GIVAofBEHlkeircXMsQvuzmLDFbpnd=GIVAofBEHlkeircXMsQvuzmLDFbpna['body']['result']
    for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpnd:
     for GIVAofBEHlkeircXMsQvuzmLDFbpth in GIVAofBEHlkeircXMsQvuzmLDFbpnO['image']:
      if GIVAofBEHlkeircXMsQvuzmLDFbpth['code']=='CAIC0400':GIVAofBEHlkeircXMsQvuzmLDFbptR[GIVAofBEHlkeircXMsQvuzmLDFbpnO['channel_code']]=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_TVINGIMG+GIVAofBEHlkeircXMsQvuzmLDFbpth['url']
      elif GIVAofBEHlkeircXMsQvuzmLDFbpth['code']=='CAIC1400':GIVAofBEHlkeircXMsQvuzmLDFbptR[GIVAofBEHlkeircXMsQvuzmLDFbpnO['channel_code']]=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_TVINGIMG+GIVAofBEHlkeircXMsQvuzmLDFbpth['url']
      elif GIVAofBEHlkeircXMsQvuzmLDFbpth['code']=='CAIC1900':GIVAofBEHlkeircXMsQvuzmLDFbptR[GIVAofBEHlkeircXMsQvuzmLDFbpnO['channel_code']]=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_TVINGIMG+GIVAofBEHlkeircXMsQvuzmLDFbpth['url']
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return{}
  return GIVAofBEHlkeircXMsQvuzmLDFbptR
 def Get_EpgInfo_Spotv(GIVAofBEHlkeircXMsQvuzmLDFbpng,days=2,payyn=GIVAofBEHlkeircXMsQvuzmLDFbpgn):
  GIVAofBEHlkeircXMsQvuzmLDFbpnN=[]
  GIVAofBEHlkeircXMsQvuzmLDFbptU =[]
  GIVAofBEHlkeircXMsQvuzmLDFbptj=GIVAofBEHlkeircXMsQvuzmLDFbpng.make_DateList(days=days,dateType='1')
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_SPOTV+'/api/v3/channel'
   GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpPx,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
   GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
   for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpna:
    GIVAofBEHlkeircXMsQvuzmLDFbpnx =GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpnO['id'])
    GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnx,'channelnm':GIVAofBEHlkeircXMsQvuzmLDFbpng.xmlText(GIVAofBEHlkeircXMsQvuzmLDFbpnO['name']),'channelimg':GIVAofBEHlkeircXMsQvuzmLDFbpnO['logo'],'ott':'spotv'}
    GIVAofBEHlkeircXMsQvuzmLDFbpnN.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[],[]
  try:
   for GIVAofBEHlkeircXMsQvuzmLDFbptY in GIVAofBEHlkeircXMsQvuzmLDFbptj:
    GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_SPOTV+'/api/v3/program/'+GIVAofBEHlkeircXMsQvuzmLDFbptY
    GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpPx,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
    GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
    for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpna:
     GIVAofBEHlkeircXMsQvuzmLDFbpnx =GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpnO['channelId'])
     GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnx,'title':GIVAofBEHlkeircXMsQvuzmLDFbpng.xmlText(GIVAofBEHlkeircXMsQvuzmLDFbpnO['title']),'startTime':GIVAofBEHlkeircXMsQvuzmLDFbpnO['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':GIVAofBEHlkeircXMsQvuzmLDFbpnO['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     GIVAofBEHlkeircXMsQvuzmLDFbptU.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
    time.sleep(GIVAofBEHlkeircXMsQvuzmLDFbpng.SLEEP_TIME)
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[],[]
  '''
  try:
   for i_channel in channel_list:
    if i_channel['epgtype'] == 'spotvon':
     tmp_list = self.Get_EpgInfo_Spotv_spotvon(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    if i_channel['epgtype'] == 'spotvnet':
     tmp_list = self.Get_EpgInfo_Spotv_spotvnet(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  return GIVAofBEHlkeircXMsQvuzmLDFbpnN,GIVAofBEHlkeircXMsQvuzmLDFbptU
 def Get_EpgInfo_Spotv_spotvon(GIVAofBEHlkeircXMsQvuzmLDFbpng,GIVAofBEHlkeircXMsQvuzmLDFbpnx,epgnm,days):
  GIVAofBEHlkeircXMsQvuzmLDFbptU =[]
  GIVAofBEHlkeircXMsQvuzmLDFbptj=GIVAofBEHlkeircXMsQvuzmLDFbpng.make_DateList(days=days,dateType='1')
  GIVAofBEHlkeircXMsQvuzmLDFbpRn=''
  try:
   for GIVAofBEHlkeircXMsQvuzmLDFbptY in GIVAofBEHlkeircXMsQvuzmLDFbptj:
    GIVAofBEHlkeircXMsQvuzmLDFbpnT='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,GIVAofBEHlkeircXMsQvuzmLDFbptY)
    GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpPx,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
    GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
    for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpna:
     GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnx,'title':GIVAofBEHlkeircXMsQvuzmLDFbpng.xmlText(GIVAofBEHlkeircXMsQvuzmLDFbpnO['title']),'startTime':GIVAofBEHlkeircXMsQvuzmLDFbpnO['sch_date'].replace('-','')+GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpnO['sch_hour']).zfill(2)+GIVAofBEHlkeircXMsQvuzmLDFbpnO['sch_min']+'00','ott':'spotv'}
     GIVAofBEHlkeircXMsQvuzmLDFbptU.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
    GIVAofBEHlkeircXMsQvuzmLDFbpRn=GIVAofBEHlkeircXMsQvuzmLDFbptY
   for i in GIVAofBEHlkeircXMsQvuzmLDFbpgR(GIVAofBEHlkeircXMsQvuzmLDFbpgP(GIVAofBEHlkeircXMsQvuzmLDFbptU)):
    if i>0:GIVAofBEHlkeircXMsQvuzmLDFbptU[i-1]['endTime']=GIVAofBEHlkeircXMsQvuzmLDFbptU[i]['startTime']
    if i==GIVAofBEHlkeircXMsQvuzmLDFbpgP(GIVAofBEHlkeircXMsQvuzmLDFbptU)-1: GIVAofBEHlkeircXMsQvuzmLDFbptU[i]['endTime']=GIVAofBEHlkeircXMsQvuzmLDFbpRn+'240000'
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[]
  return GIVAofBEHlkeircXMsQvuzmLDFbptU
 def Get_EpgInfo_Spotv_spotvnet(GIVAofBEHlkeircXMsQvuzmLDFbpng,GIVAofBEHlkeircXMsQvuzmLDFbpnx,epgnm,days):
  GIVAofBEHlkeircXMsQvuzmLDFbptU =[]
  GIVAofBEHlkeircXMsQvuzmLDFbptj=GIVAofBEHlkeircXMsQvuzmLDFbpng.make_DateList(days=days,dateType='1')
  GIVAofBEHlkeircXMsQvuzmLDFbpRn=''
  try:
   for GIVAofBEHlkeircXMsQvuzmLDFbptY in GIVAofBEHlkeircXMsQvuzmLDFbptj:
    GIVAofBEHlkeircXMsQvuzmLDFbpnT='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,GIVAofBEHlkeircXMsQvuzmLDFbptY)
    GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpPx,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
    GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
    for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpna:
     GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnx,'title':GIVAofBEHlkeircXMsQvuzmLDFbpng.xmlText(GIVAofBEHlkeircXMsQvuzmLDFbpnO['title']),'startTime':GIVAofBEHlkeircXMsQvuzmLDFbpnO['sch_date'].replace('-','')+GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpnO['sch_hour']).zfill(2)+GIVAofBEHlkeircXMsQvuzmLDFbpnO['sch_min']+'00','ott':'spotv'}
     GIVAofBEHlkeircXMsQvuzmLDFbptU.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
    GIVAofBEHlkeircXMsQvuzmLDFbpRn=GIVAofBEHlkeircXMsQvuzmLDFbptY
   for i in GIVAofBEHlkeircXMsQvuzmLDFbpgR(GIVAofBEHlkeircXMsQvuzmLDFbpgP(GIVAofBEHlkeircXMsQvuzmLDFbptU)):
    if i>0:GIVAofBEHlkeircXMsQvuzmLDFbptU[i-1]['endTime']=GIVAofBEHlkeircXMsQvuzmLDFbptU[i]['startTime']
    if i==GIVAofBEHlkeircXMsQvuzmLDFbpgP(GIVAofBEHlkeircXMsQvuzmLDFbptU)-1: GIVAofBEHlkeircXMsQvuzmLDFbptU[i]['endTime']=GIVAofBEHlkeircXMsQvuzmLDFbpRn+'240000'
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[]
  return GIVAofBEHlkeircXMsQvuzmLDFbptU
 def Make_Wavve_TimeList(GIVAofBEHlkeircXMsQvuzmLDFbpng,days=2):
  GIVAofBEHlkeircXMsQvuzmLDFbptC=[]
  GIVAofBEHlkeircXMsQvuzmLDFbpRt=[['00:00','03:00'],['03:00','06:00'],['06:00','09:00'],['09:00','12:00'],['12:00','15:00'],['15:00','18:00'],['18:00','21:00'],['21:00','24:00'],]
  GIVAofBEHlkeircXMsQvuzmLDFbpRP =GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_Now_Datetime()
  for i in GIVAofBEHlkeircXMsQvuzmLDFbpgR(days):
   GIVAofBEHlkeircXMsQvuzmLDFbpRg =GIVAofBEHlkeircXMsQvuzmLDFbpRP+datetime.timedelta(days=+i)
   GIVAofBEHlkeircXMsQvuzmLDFbpRw =GIVAofBEHlkeircXMsQvuzmLDFbpRg.strftime('%Y-%m-%d')
   for GIVAofBEHlkeircXMsQvuzmLDFbpRq in GIVAofBEHlkeircXMsQvuzmLDFbpRt:
    GIVAofBEHlkeircXMsQvuzmLDFbpRK=['{} {}'.format(GIVAofBEHlkeircXMsQvuzmLDFbpRw,GIVAofBEHlkeircXMsQvuzmLDFbpRq[0]),'{} {}'.format(GIVAofBEHlkeircXMsQvuzmLDFbpRw,GIVAofBEHlkeircXMsQvuzmLDFbpRq[1]),]
    GIVAofBEHlkeircXMsQvuzmLDFbptC.append(GIVAofBEHlkeircXMsQvuzmLDFbpRK)
  return GIVAofBEHlkeircXMsQvuzmLDFbptC
 def Get_EpgInfo_Wavve(GIVAofBEHlkeircXMsQvuzmLDFbpng,days=2,exceptGroup=[]):
  GIVAofBEHlkeircXMsQvuzmLDFbpnN =[]
  GIVAofBEHlkeircXMsQvuzmLDFbptU =[]
  GIVAofBEHlkeircXMsQvuzmLDFbptC=GIVAofBEHlkeircXMsQvuzmLDFbpng.Make_Wavve_TimeList(days)
  try:
   for GIVAofBEHlkeircXMsQvuzmLDFbpRq in GIVAofBEHlkeircXMsQvuzmLDFbptC:
    GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_WAVVE+'/live/epgs'
    GIVAofBEHlkeircXMsQvuzmLDFbpnj={'limit':GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpng.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':GIVAofBEHlkeircXMsQvuzmLDFbpRq[0],'enddatetime':GIVAofBEHlkeircXMsQvuzmLDFbpRq[1],}
    GIVAofBEHlkeircXMsQvuzmLDFbpnj.update(GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_DefaultParams_Wavve())
    GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpnj,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
    GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
    GIVAofBEHlkeircXMsQvuzmLDFbpRC=GIVAofBEHlkeircXMsQvuzmLDFbpna['list']
    for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpRC:
     GIVAofBEHlkeircXMsQvuzmLDFbpnx =GIVAofBEHlkeircXMsQvuzmLDFbpnO['channelid']
     GIVAofBEHlkeircXMsQvuzmLDFbpnY=GIVAofBEHlkeircXMsQvuzmLDFbpng.make_getGenre(GIVAofBEHlkeircXMsQvuzmLDFbpnx,'wavve')
     GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnx,'channelnm':GIVAofBEHlkeircXMsQvuzmLDFbpng.xmlText(GIVAofBEHlkeircXMsQvuzmLDFbpnO['channelname']),'channelimg':GIVAofBEHlkeircXMsQvuzmLDFbpng.HTTPTAG+GIVAofBEHlkeircXMsQvuzmLDFbpnO['channelimage'],'ott':'wavve'}
     if GIVAofBEHlkeircXMsQvuzmLDFbpnY not in exceptGroup:
      GIVAofBEHlkeircXMsQvuzmLDFbpnN.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
     for GIVAofBEHlkeircXMsQvuzmLDFbpRj in GIVAofBEHlkeircXMsQvuzmLDFbpnO['list']:
      GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnO['channelid'],'title':GIVAofBEHlkeircXMsQvuzmLDFbpng.xmlText(GIVAofBEHlkeircXMsQvuzmLDFbpRj['title']),'startTime':GIVAofBEHlkeircXMsQvuzmLDFbpRj['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':GIVAofBEHlkeircXMsQvuzmLDFbpRj['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
      if GIVAofBEHlkeircXMsQvuzmLDFbpnY not in exceptGroup and GIVAofBEHlkeircXMsQvuzmLDFbpRj['starttime']!=GIVAofBEHlkeircXMsQvuzmLDFbpRj['endtime']:
       GIVAofBEHlkeircXMsQvuzmLDFbptU.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[],[]
  GIVAofBEHlkeircXMsQvuzmLDFbpRW=GIVAofBEHlkeircXMsQvuzmLDFbpgP(GIVAofBEHlkeircXMsQvuzmLDFbptU)
  for i in(GIVAofBEHlkeircXMsQvuzmLDFbpgR(1,GIVAofBEHlkeircXMsQvuzmLDFbpRW)):
   if GIVAofBEHlkeircXMsQvuzmLDFbpgt(GIVAofBEHlkeircXMsQvuzmLDFbptU[i-1]['endTime'])+1==GIVAofBEHlkeircXMsQvuzmLDFbpgt(GIVAofBEHlkeircXMsQvuzmLDFbptU[i]['startTime'])and GIVAofBEHlkeircXMsQvuzmLDFbptU[i-1]['channelid']==GIVAofBEHlkeircXMsQvuzmLDFbptU[i]['channelid']:
    GIVAofBEHlkeircXMsQvuzmLDFbptU[i-1]['endTime']=GIVAofBEHlkeircXMsQvuzmLDFbptU[i]['startTime']
  return GIVAofBEHlkeircXMsQvuzmLDFbpnN,GIVAofBEHlkeircXMsQvuzmLDFbptU
 def Get_EpgInfo_Tving(GIVAofBEHlkeircXMsQvuzmLDFbpng,days=2):
  GIVAofBEHlkeircXMsQvuzmLDFbpnN=[]
  GIVAofBEHlkeircXMsQvuzmLDFbptU =[]
  GIVAofBEHlkeircXMsQvuzmLDFbpRS =[]
  GIVAofBEHlkeircXMsQvuzmLDFbpRN =GIVAofBEHlkeircXMsQvuzmLDFbpng.make_EpgDatetime_Tving(days=days)
  GIVAofBEHlkeircXMsQvuzmLDFbpnN =GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_ChannelList_Tving()
  GIVAofBEHlkeircXMsQvuzmLDFbpRJ=[]
  for i in GIVAofBEHlkeircXMsQvuzmLDFbpgR(GIVAofBEHlkeircXMsQvuzmLDFbpgP(GIVAofBEHlkeircXMsQvuzmLDFbpnN)):
   GIVAofBEHlkeircXMsQvuzmLDFbpnN[i]['channelnm']=GIVAofBEHlkeircXMsQvuzmLDFbpng.xmlText(GIVAofBEHlkeircXMsQvuzmLDFbpnN[i]['channelnm'])
   GIVAofBEHlkeircXMsQvuzmLDFbpRJ.append(GIVAofBEHlkeircXMsQvuzmLDFbpnN[i]['channelid'])
  GIVAofBEHlkeircXMsQvuzmLDFbpRT=GIVAofBEHlkeircXMsQvuzmLDFbpng.make_Tving_ChannleGroup(GIVAofBEHlkeircXMsQvuzmLDFbpRJ)
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_TVING+'/v2/media/schedules'
   for GIVAofBEHlkeircXMsQvuzmLDFbpRq in GIVAofBEHlkeircXMsQvuzmLDFbpRN:
    for GIVAofBEHlkeircXMsQvuzmLDFbpRy in GIVAofBEHlkeircXMsQvuzmLDFbpRT:
     GIVAofBEHlkeircXMsQvuzmLDFbpnj={'pageNo':'1','pageSize':GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpng.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':GIVAofBEHlkeircXMsQvuzmLDFbpRq['ndate'],'broadcastDate':GIVAofBEHlkeircXMsQvuzmLDFbpRq['ndate'],'startBroadTime':GIVAofBEHlkeircXMsQvuzmLDFbpRq['starttm'],'endBroadTime':GIVAofBEHlkeircXMsQvuzmLDFbpRq['endtm'],'channelCode':GIVAofBEHlkeircXMsQvuzmLDFbpRy}
     GIVAofBEHlkeircXMsQvuzmLDFbpnj.update(GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_DefaultParams_Tving())
     GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpnj,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
     GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
     GIVAofBEHlkeircXMsQvuzmLDFbpnd=GIVAofBEHlkeircXMsQvuzmLDFbpna['body']['result']
     for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpnd:
      if 'schedules' not in GIVAofBEHlkeircXMsQvuzmLDFbpnO:continue
      if GIVAofBEHlkeircXMsQvuzmLDFbpnO['schedules']==GIVAofBEHlkeircXMsQvuzmLDFbpPx:continue
      for GIVAofBEHlkeircXMsQvuzmLDFbpRa in GIVAofBEHlkeircXMsQvuzmLDFbpnO['schedules']:
       GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpRa['schedule_code'],'title':GIVAofBEHlkeircXMsQvuzmLDFbpng.xmlText(GIVAofBEHlkeircXMsQvuzmLDFbpRa['program']['name']['ko']),'startTime':GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpRa['broadcast_start_time']),'endTime':GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpRa['broadcast_end_time']),'ott':'tving'}
       GIVAofBEHlkeircXMsQvuzmLDFbpRd=GIVAofBEHlkeircXMsQvuzmLDFbpRa['schedule_code']+GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpRa['broadcast_start_time'])
       if GIVAofBEHlkeircXMsQvuzmLDFbpRd in GIVAofBEHlkeircXMsQvuzmLDFbpRS:continue
       GIVAofBEHlkeircXMsQvuzmLDFbpRS.append(GIVAofBEHlkeircXMsQvuzmLDFbpRd)
       GIVAofBEHlkeircXMsQvuzmLDFbptU.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
     time.sleep(GIVAofBEHlkeircXMsQvuzmLDFbpng.SLEEP_TIME)
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[],[]
  return GIVAofBEHlkeircXMsQvuzmLDFbpnN,GIVAofBEHlkeircXMsQvuzmLDFbptU
 def Get_BaseInfo_Samsungtv(GIVAofBEHlkeircXMsQvuzmLDFbpng):
  GIVAofBEHlkeircXMsQvuzmLDFbpRO={}
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_SAMSUNGTV
   GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpPx,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpPx)
   for GIVAofBEHlkeircXMsQvuzmLDFbpRx in GIVAofBEHlkeircXMsQvuzmLDFbpny.cookies:
    if GIVAofBEHlkeircXMsQvuzmLDFbpRx.name=='session':
     GIVAofBEHlkeircXMsQvuzmLDFbpRO['session']=GIVAofBEHlkeircXMsQvuzmLDFbpRx.value
    elif GIVAofBEHlkeircXMsQvuzmLDFbpRx.name=='session.sig':
     GIVAofBEHlkeircXMsQvuzmLDFbpRO['session.sig']=GIVAofBEHlkeircXMsQvuzmLDFbpRx.value
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return{}
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_SAMSUNGTV+'/user'
   GIVAofBEHlkeircXMsQvuzmLDFbpRh={'session':GIVAofBEHlkeircXMsQvuzmLDFbpRO['session'],'session.sig':GIVAofBEHlkeircXMsQvuzmLDFbpRO['session.sig'],}
   GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpPx,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPx,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpRh)
   GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
   GIVAofBEHlkeircXMsQvuzmLDFbpRO['countryCode']=GIVAofBEHlkeircXMsQvuzmLDFbpna.get('countryCode')
   GIVAofBEHlkeircXMsQvuzmLDFbpRO['uuid'] =GIVAofBEHlkeircXMsQvuzmLDFbpna.get('uuid')
   GIVAofBEHlkeircXMsQvuzmLDFbpRO['ip'] =GIVAofBEHlkeircXMsQvuzmLDFbpna.get('ip')
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return{}
  return GIVAofBEHlkeircXMsQvuzmLDFbpRO
 def t_Cache(GIVAofBEHlkeircXMsQvuzmLDFbpng):
  GIVAofBEHlkeircXMsQvuzmLDFbptW =GIVAofBEHlkeircXMsQvuzmLDFbpgt(time.time())
  GIVAofBEHlkeircXMsQvuzmLDFbpRU=GIVAofBEHlkeircXMsQvuzmLDFbpgt(GIVAofBEHlkeircXMsQvuzmLDFbptW-GIVAofBEHlkeircXMsQvuzmLDFbptW%3600)
  return GIVAofBEHlkeircXMsQvuzmLDFbpRU,GIVAofBEHlkeircXMsQvuzmLDFbptW
 def zlib_compress(GIVAofBEHlkeircXMsQvuzmLDFbpng,plaintext):
  GIVAofBEHlkeircXMsQvuzmLDFbpRY=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(GIVAofBEHlkeircXMsQvuzmLDFbpRY).decode('utf-8')
 def Get_BaseRequest_Samsungtv(GIVAofBEHlkeircXMsQvuzmLDFbpng,GIVAofBEHlkeircXMsQvuzmLDFbpRO):
  GIVAofBEHlkeircXMsQvuzmLDFbpna={}
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpnT=GIVAofBEHlkeircXMsQvuzmLDFbpng.API_SAMSUNGTV+'/api/lives'
   GIVAofBEHlkeircXMsQvuzmLDFbpRU,GIVAofBEHlkeircXMsQvuzmLDFbptW=GIVAofBEHlkeircXMsQvuzmLDFbpng.t_Cache()
   GIVAofBEHlkeircXMsQvuzmLDFbpPn=GIVAofBEHlkeircXMsQvuzmLDFbpng.zlib_compress(GIVAofBEHlkeircXMsQvuzmLDFbpRO['uuid']+':'+GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbptW))
   GIVAofBEHlkeircXMsQvuzmLDFbpRh={'session':GIVAofBEHlkeircXMsQvuzmLDFbpRO['session'],'session.sig':GIVAofBEHlkeircXMsQvuzmLDFbpRO['session.sig'],}
   GIVAofBEHlkeircXMsQvuzmLDFbpnj ={'t':GIVAofBEHlkeircXMsQvuzmLDFbpPh(GIVAofBEHlkeircXMsQvuzmLDFbpRU)}
   GIVAofBEHlkeircXMsQvuzmLDFbpPt ={'x-cred-payload':GIVAofBEHlkeircXMsQvuzmLDFbpPn}
   GIVAofBEHlkeircXMsQvuzmLDFbpny=GIVAofBEHlkeircXMsQvuzmLDFbpng.callRequestCookies('Get',GIVAofBEHlkeircXMsQvuzmLDFbpnT,payload=GIVAofBEHlkeircXMsQvuzmLDFbpPx,params=GIVAofBEHlkeircXMsQvuzmLDFbpnj,headers=GIVAofBEHlkeircXMsQvuzmLDFbpPt,cookies=GIVAofBEHlkeircXMsQvuzmLDFbpRh)
   GIVAofBEHlkeircXMsQvuzmLDFbpna=json.loads(GIVAofBEHlkeircXMsQvuzmLDFbpny.text)
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
  return GIVAofBEHlkeircXMsQvuzmLDFbpna
 def Make_Samsungtv_logoUrl(GIVAofBEHlkeircXMsQvuzmLDFbpng,fullUrl):
  GIVAofBEHlkeircXMsQvuzmLDFbpPR=urllib.parse.urlparse(fullUrl) 
  if GIVAofBEHlkeircXMsQvuzmLDFbpPR.netloc=='us-image.samsungtvplus.com':
   GIVAofBEHlkeircXMsQvuzmLDFbpPg=GIVAofBEHlkeircXMsQvuzmLDFbpgw(urllib.parse.parse_qsl(GIVAofBEHlkeircXMsQvuzmLDFbpPR.query))
   if 'url' in GIVAofBEHlkeircXMsQvuzmLDFbpPg:
    return GIVAofBEHlkeircXMsQvuzmLDFbpPg.get('url')
  return fullUrl
 def Get_ChannelList_Samsungtv(GIVAofBEHlkeircXMsQvuzmLDFbpng,GIVAofBEHlkeircXMsQvuzmLDFbpRO,exceptGroup=[]):
  GIVAofBEHlkeircXMsQvuzmLDFbpnN =[]
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpna=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_BaseRequest_Samsungtv(GIVAofBEHlkeircXMsQvuzmLDFbpRO)
   GIVAofBEHlkeircXMsQvuzmLDFbpnd=GIVAofBEHlkeircXMsQvuzmLDFbpna['live']['channel']
   for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpnd:
    GIVAofBEHlkeircXMsQvuzmLDFbpnx =GIVAofBEHlkeircXMsQvuzmLDFbpnO.get('id')
    GIVAofBEHlkeircXMsQvuzmLDFbpnh =GIVAofBEHlkeircXMsQvuzmLDFbpnO.get('name')
    GIVAofBEHlkeircXMsQvuzmLDFbpnU=GIVAofBEHlkeircXMsQvuzmLDFbpng.Make_Samsungtv_logoUrl(GIVAofBEHlkeircXMsQvuzmLDFbpnO.get('logo'))
    GIVAofBEHlkeircXMsQvuzmLDFbpnY=GIVAofBEHlkeircXMsQvuzmLDFbpng.make_getGenre(GIVAofBEHlkeircXMsQvuzmLDFbpnx,'samsung')
    if GIVAofBEHlkeircXMsQvuzmLDFbpnY in['-','']:GIVAofBEHlkeircXMsQvuzmLDFbpnY='정주행 채널'
    GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnx,'channelnm':GIVAofBEHlkeircXMsQvuzmLDFbpnh,'channelimg':GIVAofBEHlkeircXMsQvuzmLDFbpnU,'ott':'samsung','genrenm':GIVAofBEHlkeircXMsQvuzmLDFbpnY}
    if GIVAofBEHlkeircXMsQvuzmLDFbpnY not in exceptGroup:
     GIVAofBEHlkeircXMsQvuzmLDFbpnN.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[]
  return GIVAofBEHlkeircXMsQvuzmLDFbpnN
 def Get_EpgInfo_Samsungtv(GIVAofBEHlkeircXMsQvuzmLDFbpng,GIVAofBEHlkeircXMsQvuzmLDFbpRO,exceptGroup=[]):
  GIVAofBEHlkeircXMsQvuzmLDFbpnN=[]
  GIVAofBEHlkeircXMsQvuzmLDFbptU =[]
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbpna =GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_BaseRequest_Samsungtv(GIVAofBEHlkeircXMsQvuzmLDFbpRO)
   GIVAofBEHlkeircXMsQvuzmLDFbpnO=GIVAofBEHlkeircXMsQvuzmLDFbpna['live']['channel']
   for GIVAofBEHlkeircXMsQvuzmLDFbpRy in GIVAofBEHlkeircXMsQvuzmLDFbpnO:
    GIVAofBEHlkeircXMsQvuzmLDFbpnx =GIVAofBEHlkeircXMsQvuzmLDFbpRy.get('id')
    GIVAofBEHlkeircXMsQvuzmLDFbpnh =GIVAofBEHlkeircXMsQvuzmLDFbpRy.get('name')
    GIVAofBEHlkeircXMsQvuzmLDFbpnU=GIVAofBEHlkeircXMsQvuzmLDFbpng.Make_Samsungtv_logoUrl(GIVAofBEHlkeircXMsQvuzmLDFbpRy.get('logo'))
    GIVAofBEHlkeircXMsQvuzmLDFbpRC =GIVAofBEHlkeircXMsQvuzmLDFbpRy.get('program')
    GIVAofBEHlkeircXMsQvuzmLDFbpnY=GIVAofBEHlkeircXMsQvuzmLDFbpng.make_getGenre(GIVAofBEHlkeircXMsQvuzmLDFbpnx,'samsung')
    if GIVAofBEHlkeircXMsQvuzmLDFbpnY in exceptGroup:
     continue
    GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnx,'channelnm':GIVAofBEHlkeircXMsQvuzmLDFbpnh,'channelimg':GIVAofBEHlkeircXMsQvuzmLDFbpnU,'ott':'samsung','genrenm':GIVAofBEHlkeircXMsQvuzmLDFbpnY}
    GIVAofBEHlkeircXMsQvuzmLDFbpnN.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
    for GIVAofBEHlkeircXMsQvuzmLDFbpRj in GIVAofBEHlkeircXMsQvuzmLDFbpRC:
     GIVAofBEHlkeircXMsQvuzmLDFbpPw=GIVAofBEHlkeircXMsQvuzmLDFbpRj.get('start_time')
     GIVAofBEHlkeircXMsQvuzmLDFbpPq =GIVAofBEHlkeircXMsQvuzmLDFbpRj.get('duration') 
     GIVAofBEHlkeircXMsQvuzmLDFbptP=datetime.datetime.strptime(GIVAofBEHlkeircXMsQvuzmLDFbpPw,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     GIVAofBEHlkeircXMsQvuzmLDFbptg =GIVAofBEHlkeircXMsQvuzmLDFbptP+datetime.timedelta(seconds=GIVAofBEHlkeircXMsQvuzmLDFbpPq)
     GIVAofBEHlkeircXMsQvuzmLDFbptn={'channelid':GIVAofBEHlkeircXMsQvuzmLDFbpnx,'title':GIVAofBEHlkeircXMsQvuzmLDFbpng.xmlText(urllib.parse.unquote_plus(GIVAofBEHlkeircXMsQvuzmLDFbpRj.get('title'))),'startTime':GIVAofBEHlkeircXMsQvuzmLDFbptP.strftime('%Y%m%d%H%M00'),'endTime':GIVAofBEHlkeircXMsQvuzmLDFbptg.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     GIVAofBEHlkeircXMsQvuzmLDFbptU.append(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  except GIVAofBEHlkeircXMsQvuzmLDFbpPU as exception:
   GIVAofBEHlkeircXMsQvuzmLDFbpPY(exception)
   return[],[]
  return GIVAofBEHlkeircXMsQvuzmLDFbpnN,GIVAofBEHlkeircXMsQvuzmLDFbptU
 def make_getGenre(GIVAofBEHlkeircXMsQvuzmLDFbpng,GIVAofBEHlkeircXMsQvuzmLDFbpnx,GIVAofBEHlkeircXMsQvuzmLDFbpPT):
  try:
   GIVAofBEHlkeircXMsQvuzmLDFbptw=GIVAofBEHlkeircXMsQvuzmLDFbpng.INIT_CHANNEL.get(GIVAofBEHlkeircXMsQvuzmLDFbpnx+'.'+GIVAofBEHlkeircXMsQvuzmLDFbpPT).get('genre')
  except:
   GIVAofBEHlkeircXMsQvuzmLDFbptw=GIVAofBEHlkeircXMsQvuzmLDFbpng.INIT_CHANNEL.get('-').get('genre')
  return GIVAofBEHlkeircXMsQvuzmLDFbptw
 def make_base_allchannel_py(GIVAofBEHlkeircXMsQvuzmLDFbpng,GIVAofBEHlkeircXMsQvuzmLDFbpRO):
  GIVAofBEHlkeircXMsQvuzmLDFbpPK =[]
  GIVAofBEHlkeircXMsQvuzmLDFbpPC=[]
  GIVAofBEHlkeircXMsQvuzmLDFbpPj=GIVAofBEHlkeircXMsQvuzmLDFbpgq()
  GIVAofBEHlkeircXMsQvuzmLDFbptn=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_ChannelList_Wavve()
  GIVAofBEHlkeircXMsQvuzmLDFbpPK.extend(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  GIVAofBEHlkeircXMsQvuzmLDFbptn=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_ChannelList_Tving()
  GIVAofBEHlkeircXMsQvuzmLDFbpPK.extend(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  GIVAofBEHlkeircXMsQvuzmLDFbptn=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_ChannelList_Spotv()
  GIVAofBEHlkeircXMsQvuzmLDFbpPK.extend(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  GIVAofBEHlkeircXMsQvuzmLDFbptn=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_ChannelList_Samsungtv(GIVAofBEHlkeircXMsQvuzmLDFbpRO)
  GIVAofBEHlkeircXMsQvuzmLDFbpPK.extend(GIVAofBEHlkeircXMsQvuzmLDFbptn)
  GIVAofBEHlkeircXMsQvuzmLDFbpPY('1')
  for i in GIVAofBEHlkeircXMsQvuzmLDFbpgR(GIVAofBEHlkeircXMsQvuzmLDFbpgP(GIVAofBEHlkeircXMsQvuzmLDFbpPK)):
   if GIVAofBEHlkeircXMsQvuzmLDFbpPK[i]['genrenm']=='-':
    if GIVAofBEHlkeircXMsQvuzmLDFbpPK[i]['ott']=='wavve':
     GIVAofBEHlkeircXMsQvuzmLDFbptw=GIVAofBEHlkeircXMsQvuzmLDFbpng.Get_ChanneGenrename_Wavve(GIVAofBEHlkeircXMsQvuzmLDFbpPK[i]['channelid'])
     if GIVAofBEHlkeircXMsQvuzmLDFbptw not in GIVAofBEHlkeircXMsQvuzmLDFbpPj:GIVAofBEHlkeircXMsQvuzmLDFbpPj.add(GIVAofBEHlkeircXMsQvuzmLDFbptw)
     time.sleep(GIVAofBEHlkeircXMsQvuzmLDFbpng.SLEEP_TIME)
    elif GIVAofBEHlkeircXMsQvuzmLDFbpPK[i]['ott']=='spotv':
     GIVAofBEHlkeircXMsQvuzmLDFbptw='스포츠'
    else:
     GIVAofBEHlkeircXMsQvuzmLDFbptw='-'
    GIVAofBEHlkeircXMsQvuzmLDFbpPK[i]['genrenm']=GIVAofBEHlkeircXMsQvuzmLDFbptw
   else:
    if GIVAofBEHlkeircXMsQvuzmLDFbpPK[i]['genrenm']not in GIVAofBEHlkeircXMsQvuzmLDFbpPj:GIVAofBEHlkeircXMsQvuzmLDFbpPj.add(GIVAofBEHlkeircXMsQvuzmLDFbpPK[i]['genrenm'])
  GIVAofBEHlkeircXMsQvuzmLDFbpPj.add(GIVAofBEHlkeircXMsQvuzmLDFbpng.INIT_CHANNEL.get('-').get('genre'))
  GIVAofBEHlkeircXMsQvuzmLDFbpPY('2')
  for GIVAofBEHlkeircXMsQvuzmLDFbpPW in GIVAofBEHlkeircXMsQvuzmLDFbpPj:
   for GIVAofBEHlkeircXMsQvuzmLDFbpPS in GIVAofBEHlkeircXMsQvuzmLDFbpPK:
    if GIVAofBEHlkeircXMsQvuzmLDFbpPS['genrenm']==GIVAofBEHlkeircXMsQvuzmLDFbpPW:
     GIVAofBEHlkeircXMsQvuzmLDFbpPC.append(GIVAofBEHlkeircXMsQvuzmLDFbpPS)
  for GIVAofBEHlkeircXMsQvuzmLDFbpPS in GIVAofBEHlkeircXMsQvuzmLDFbpPK:
   if GIVAofBEHlkeircXMsQvuzmLDFbpPS['genrenm']not in GIVAofBEHlkeircXMsQvuzmLDFbpPj:
    GIVAofBEHlkeircXMsQvuzmLDFbpPC.append(GIVAofBEHlkeircXMsQvuzmLDFbpPS)
  GIVAofBEHlkeircXMsQvuzmLDFbpPY('3')
  GIVAofBEHlkeircXMsQvuzmLDFbpPN='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(GIVAofBEHlkeircXMsQvuzmLDFbpPN):os.remove(GIVAofBEHlkeircXMsQvuzmLDFbpPN)
  fp=GIVAofBEHlkeircXMsQvuzmLDFbpgK(GIVAofBEHlkeircXMsQvuzmLDFbpPN,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  GIVAofBEHlkeircXMsQvuzmLDFbpPJ=GIVAofBEHlkeircXMsQvuzmLDFbpgP(GIVAofBEHlkeircXMsQvuzmLDFbpPC)
  i=0
  for GIVAofBEHlkeircXMsQvuzmLDFbpnO in GIVAofBEHlkeircXMsQvuzmLDFbpPC:
   i+=1
   GIVAofBEHlkeircXMsQvuzmLDFbpnx =GIVAofBEHlkeircXMsQvuzmLDFbpnO['channelid']
   GIVAofBEHlkeircXMsQvuzmLDFbpnh =GIVAofBEHlkeircXMsQvuzmLDFbpnO['channelnm']
   GIVAofBEHlkeircXMsQvuzmLDFbpPT =GIVAofBEHlkeircXMsQvuzmLDFbpnO['ott']
   GIVAofBEHlkeircXMsQvuzmLDFbpPy ='%s.%s'%(GIVAofBEHlkeircXMsQvuzmLDFbpnx,GIVAofBEHlkeircXMsQvuzmLDFbpPT)
   GIVAofBEHlkeircXMsQvuzmLDFbptw =GIVAofBEHlkeircXMsQvuzmLDFbpnO['genrenm']
   GIVAofBEHlkeircXMsQvuzmLDFbpPa='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(GIVAofBEHlkeircXMsQvuzmLDFbpPy,GIVAofBEHlkeircXMsQvuzmLDFbpnh,GIVAofBEHlkeircXMsQvuzmLDFbptw)
   if i<GIVAofBEHlkeircXMsQvuzmLDFbpPJ:
    fp.write(GIVAofBEHlkeircXMsQvuzmLDFbpPa+',\n')
   else:
    fp.write(GIVAofBEHlkeircXMsQvuzmLDFbpPa+'\n')
  fp.write('}\n')
  fp.close()
  return GIVAofBEHlkeircXMsQvuzmLDFbpPj
# Created by pyminifier (https://github.com/liftoff/pyminifier)
