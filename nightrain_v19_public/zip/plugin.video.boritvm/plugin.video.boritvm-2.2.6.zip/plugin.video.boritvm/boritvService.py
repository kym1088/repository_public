# -*- coding: utf-8 -*-
__author__ = "NightRain"

import os
import sys
import xbmcaddon, xbmcvfs
import urllib
#import threading


__cwd__ = xbmcvfs.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
__lib__ = os.path.join( __cwd__, 'resources', 'lib' )
sys.path.append(__lib__)

from boritvServiceRun import *



monitor = xbmc.Monitor()
serviceObj = BoritvServiceRun()
xbmc.sleep(serviceObj.START_INTERVAL)
    
while not monitor.abortRequested():
	# Sleep/wait for abort for 10 seconds
	if monitor.waitForAbort(serviceObj.INTERVAL):
		# Abort was requested while waiting. We should exit
		#xbmc.log("abort boritv!!! %s" % time.time(), level=xbmc.LOGNOTICE)	
		break

	serviceObj.service_run()
	#xbmc.log("hello addon! %s" % time.time(), level=xbmc.LOGNOTICE)	


	
