__author__="NightRain"
aYXhCglMDNFBRVLrGpdfAUOKwITuJW=object
aYXhCglMDNFBRVLrGpdfAUOKwITuJo=False
aYXhCglMDNFBRVLrGpdfAUOKwITuJz=None
aYXhCglMDNFBRVLrGpdfAUOKwITuJP=True
aYXhCglMDNFBRVLrGpdfAUOKwITuJx=getattr
aYXhCglMDNFBRVLrGpdfAUOKwITuJb=type
aYXhCglMDNFBRVLrGpdfAUOKwITuJi=int
aYXhCglMDNFBRVLrGpdfAUOKwITuJq=list
aYXhCglMDNFBRVLrGpdfAUOKwITuJv=len
aYXhCglMDNFBRVLrGpdfAUOKwITuJe=str
aYXhCglMDNFBRVLrGpdfAUOKwITuJn=open
aYXhCglMDNFBRVLrGpdfAUOKwITuJt=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
aYXhCglMDNFBRVLrGpdfAUOKwITumj=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'     - M3U 추가 (SBS)','mode':'ADD_M3U','sType':'bc_sbs','sName':'SBS'},{'title':'     - M3U 추가 (사용자 m3u)','mode':'ADD_M3U','sType':'custom','sName':'사용자 m3u 파일'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
aYXhCglMDNFBRVLrGpdfAUOKwITumJ={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
aYXhCglMDNFBRVLrGpdfAUOKwITums=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class aYXhCglMDNFBRVLrGpdfAUOKwITumH(aYXhCglMDNFBRVLrGpdfAUOKwITuJW):
 def __init__(aYXhCglMDNFBRVLrGpdfAUOKwITumy,aYXhCglMDNFBRVLrGpdfAUOKwITumc,aYXhCglMDNFBRVLrGpdfAUOKwITumk,aYXhCglMDNFBRVLrGpdfAUOKwITumW):
  aYXhCglMDNFBRVLrGpdfAUOKwITumy._addon_url =aYXhCglMDNFBRVLrGpdfAUOKwITumc
  aYXhCglMDNFBRVLrGpdfAUOKwITumy._addon_handle =aYXhCglMDNFBRVLrGpdfAUOKwITumk
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.main_params =aYXhCglMDNFBRVLrGpdfAUOKwITumW
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_FILE_PATH ='' 
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_FILE_NAME ='' 
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVE =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONTVING =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSPOTV =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSAMSUNG =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_BC_SBS =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVERADIO =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVEHOME =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONRELIGION =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSPOTVPAY =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSAMSUNGHOME=aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_DISPLAYNM =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_AUTORESTART =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_CUSTOM_LIST =[]
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj =XuMsGFkrdCKcPUiNDbtIEvVhpxmoeL() 
 def addon_noti(aYXhCglMDNFBRVLrGpdfAUOKwITumy,sting):
  try:
   aYXhCglMDNFBRVLrGpdfAUOKwITumz=xbmcgui.Dialog()
   aYXhCglMDNFBRVLrGpdfAUOKwITumz.notification(__addonname__,sting)
  except:
   aYXhCglMDNFBRVLrGpdfAUOKwITuJz
 def addon_log(aYXhCglMDNFBRVLrGpdfAUOKwITumy,string):
  try:
   aYXhCglMDNFBRVLrGpdfAUOKwITumP=string.encode('utf-8','ignore')
  except:
   aYXhCglMDNFBRVLrGpdfAUOKwITumP='addonException: addon_log'
  aYXhCglMDNFBRVLrGpdfAUOKwITumx=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,aYXhCglMDNFBRVLrGpdfAUOKwITumP),level=aYXhCglMDNFBRVLrGpdfAUOKwITumx)
 def get_keyboard_input(aYXhCglMDNFBRVLrGpdfAUOKwITumy,aYXhCglMDNFBRVLrGpdfAUOKwITumq):
  aYXhCglMDNFBRVLrGpdfAUOKwITumb=aYXhCglMDNFBRVLrGpdfAUOKwITuJz
  kb=xbmc.Keyboard()
  kb.setHeading(aYXhCglMDNFBRVLrGpdfAUOKwITumq)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   aYXhCglMDNFBRVLrGpdfAUOKwITumb=kb.getText()
  return aYXhCglMDNFBRVLrGpdfAUOKwITumb
 def add_dir(aYXhCglMDNFBRVLrGpdfAUOKwITumy,label,sublabel='',img='',infoLabels=aYXhCglMDNFBRVLrGpdfAUOKwITuJz,isFolder=aYXhCglMDNFBRVLrGpdfAUOKwITuJP,params='',isLink=aYXhCglMDNFBRVLrGpdfAUOKwITuJo,ContextMenu=aYXhCglMDNFBRVLrGpdfAUOKwITuJz):
  aYXhCglMDNFBRVLrGpdfAUOKwITumi='%s?%s'%(aYXhCglMDNFBRVLrGpdfAUOKwITumy._addon_url,urllib.parse.urlencode(params))
  if sublabel:aYXhCglMDNFBRVLrGpdfAUOKwITumq='%s < %s >'%(label,sublabel)
  else: aYXhCglMDNFBRVLrGpdfAUOKwITumq=label
  if not img:img='DefaultFolder.png'
  aYXhCglMDNFBRVLrGpdfAUOKwITumv=xbmcgui.ListItem(aYXhCglMDNFBRVLrGpdfAUOKwITumq)
  aYXhCglMDNFBRVLrGpdfAUOKwITumv.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.KodiVersion>=20:
   if infoLabels:aYXhCglMDNFBRVLrGpdfAUOKwITumy.Set_InfoTag(aYXhCglMDNFBRVLrGpdfAUOKwITumv.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:aYXhCglMDNFBRVLrGpdfAUOKwITumv.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   aYXhCglMDNFBRVLrGpdfAUOKwITumv.setProperty('IsPlayable','true')
  if ContextMenu:aYXhCglMDNFBRVLrGpdfAUOKwITumv.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(aYXhCglMDNFBRVLrGpdfAUOKwITumy._addon_handle,aYXhCglMDNFBRVLrGpdfAUOKwITumi,aYXhCglMDNFBRVLrGpdfAUOKwITumv,isFolder)
 def Set_InfoTag(aYXhCglMDNFBRVLrGpdfAUOKwITumy,video_InfoTag:xbmc.InfoTagVideo,aYXhCglMDNFBRVLrGpdfAUOKwITumQ):
  for aYXhCglMDNFBRVLrGpdfAUOKwITume,value in aYXhCglMDNFBRVLrGpdfAUOKwITumQ.items():
   if aYXhCglMDNFBRVLrGpdfAUOKwITumJ[aYXhCglMDNFBRVLrGpdfAUOKwITume]['type']=='string':
    aYXhCglMDNFBRVLrGpdfAUOKwITuJx(video_InfoTag,aYXhCglMDNFBRVLrGpdfAUOKwITumJ[aYXhCglMDNFBRVLrGpdfAUOKwITume]['func'])(value)
   elif aYXhCglMDNFBRVLrGpdfAUOKwITumJ[aYXhCglMDNFBRVLrGpdfAUOKwITume]['type']=='int':
    if aYXhCglMDNFBRVLrGpdfAUOKwITuJb(value)==aYXhCglMDNFBRVLrGpdfAUOKwITuJi:
     aYXhCglMDNFBRVLrGpdfAUOKwITumn=aYXhCglMDNFBRVLrGpdfAUOKwITuJi(value)
    else:
     aYXhCglMDNFBRVLrGpdfAUOKwITumn=0
    aYXhCglMDNFBRVLrGpdfAUOKwITuJx(video_InfoTag,aYXhCglMDNFBRVLrGpdfAUOKwITumJ[aYXhCglMDNFBRVLrGpdfAUOKwITume]['func'])(aYXhCglMDNFBRVLrGpdfAUOKwITumn)
   elif aYXhCglMDNFBRVLrGpdfAUOKwITumJ[aYXhCglMDNFBRVLrGpdfAUOKwITume]['type']=='actor':
    if value!=[]:
     aYXhCglMDNFBRVLrGpdfAUOKwITuJx(video_InfoTag,aYXhCglMDNFBRVLrGpdfAUOKwITumJ[aYXhCglMDNFBRVLrGpdfAUOKwITume]['func'])([xbmc.Actor(name)for name in value])
   elif aYXhCglMDNFBRVLrGpdfAUOKwITumJ[aYXhCglMDNFBRVLrGpdfAUOKwITume]['type']=='list':
    if aYXhCglMDNFBRVLrGpdfAUOKwITuJb(value)==aYXhCglMDNFBRVLrGpdfAUOKwITuJq:
     aYXhCglMDNFBRVLrGpdfAUOKwITuJx(video_InfoTag,aYXhCglMDNFBRVLrGpdfAUOKwITumJ[aYXhCglMDNFBRVLrGpdfAUOKwITume]['func'])(value)
    else:
     aYXhCglMDNFBRVLrGpdfAUOKwITuJx(video_InfoTag,aYXhCglMDNFBRVLrGpdfAUOKwITumJ[aYXhCglMDNFBRVLrGpdfAUOKwITume]['func'])([value])
 def make_M3u_Filename(aYXhCglMDNFBRVLrGpdfAUOKwITumy,tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJo):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_FILE_PATH+aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(aYXhCglMDNFBRVLrGpdfAUOKwITumy,tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJo):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_FILE_PATH+aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_FILE_NAME+'.xml'
 def dp_Main_List(aYXhCglMDNFBRVLrGpdfAUOKwITumy):
  for aYXhCglMDNFBRVLrGpdfAUOKwITumt in aYXhCglMDNFBRVLrGpdfAUOKwITumj:
   aYXhCglMDNFBRVLrGpdfAUOKwITumq=aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('title')
   aYXhCglMDNFBRVLrGpdfAUOKwITumS=''
   aYXhCglMDNFBRVLrGpdfAUOKwITumE={'mode':aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('mode'),'sType':aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('sType'),'sName':aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('sName')}
   aYXhCglMDNFBRVLrGpdfAUOKwITumQ={'title':aYXhCglMDNFBRVLrGpdfAUOKwITumq,'plot':aYXhCglMDNFBRVLrGpdfAUOKwITumq}
   if aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('mode')=='XXX':
    aYXhCglMDNFBRVLrGpdfAUOKwITuHm=aYXhCglMDNFBRVLrGpdfAUOKwITuJo
    aYXhCglMDNFBRVLrGpdfAUOKwITuHj =aYXhCglMDNFBRVLrGpdfAUOKwITuJP
   else:
    aYXhCglMDNFBRVLrGpdfAUOKwITuHm=aYXhCglMDNFBRVLrGpdfAUOKwITuJP
    aYXhCglMDNFBRVLrGpdfAUOKwITuHj =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
   aYXhCglMDNFBRVLrGpdfAUOKwITuHJ=aYXhCglMDNFBRVLrGpdfAUOKwITuJP
   if aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('mode')=='ADD_M3U':
    if aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('sType')=='wavve' and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVE ==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:aYXhCglMDNFBRVLrGpdfAUOKwITuHJ=aYXhCglMDNFBRVLrGpdfAUOKwITuJo
    if aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('sType')=='tving' and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONTVING ==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:aYXhCglMDNFBRVLrGpdfAUOKwITuHJ=aYXhCglMDNFBRVLrGpdfAUOKwITuJo
    if aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('sType')=='spotv' and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSPOTV ==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:aYXhCglMDNFBRVLrGpdfAUOKwITuHJ=aYXhCglMDNFBRVLrGpdfAUOKwITuJo
    if aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('sType')=='bc_sbs' and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_BC_SBS ==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:aYXhCglMDNFBRVLrGpdfAUOKwITuHJ=aYXhCglMDNFBRVLrGpdfAUOKwITuJo
    if aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('sType')=='samsung' and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSAMSUNG==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:aYXhCglMDNFBRVLrGpdfAUOKwITuHJ=aYXhCglMDNFBRVLrGpdfAUOKwITuJo
    if aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('sType')=='custom' and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_CUSTOM_LIST==[]:aYXhCglMDNFBRVLrGpdfAUOKwITuHJ=aYXhCglMDNFBRVLrGpdfAUOKwITuJo
   if aYXhCglMDNFBRVLrGpdfAUOKwITuHJ==aYXhCglMDNFBRVLrGpdfAUOKwITuJP:
    if 'icon' in aYXhCglMDNFBRVLrGpdfAUOKwITumt:aYXhCglMDNFBRVLrGpdfAUOKwITumS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',aYXhCglMDNFBRVLrGpdfAUOKwITumt.get('icon')) 
    aYXhCglMDNFBRVLrGpdfAUOKwITumy.add_dir(aYXhCglMDNFBRVLrGpdfAUOKwITumq,sublabel='',img=aYXhCglMDNFBRVLrGpdfAUOKwITumS,infoLabels=aYXhCglMDNFBRVLrGpdfAUOKwITumQ,isFolder=aYXhCglMDNFBRVLrGpdfAUOKwITuHm,params=aYXhCglMDNFBRVLrGpdfAUOKwITumE,isLink=aYXhCglMDNFBRVLrGpdfAUOKwITuHj)
  if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITumj)>0:xbmcplugin.endOfDirectory(aYXhCglMDNFBRVLrGpdfAUOKwITumy._addon_handle,cacheToDisc=aYXhCglMDNFBRVLrGpdfAUOKwITuJP)
 def dp_Delete_M3u(aYXhCglMDNFBRVLrGpdfAUOKwITumy,args):
  aYXhCglMDNFBRVLrGpdfAUOKwITumz=xbmcgui.Dialog()
  aYXhCglMDNFBRVLrGpdfAUOKwITuHy=aYXhCglMDNFBRVLrGpdfAUOKwITumz.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if aYXhCglMDNFBRVLrGpdfAUOKwITuHy==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:sys.exit()
  aYXhCglMDNFBRVLrGpdfAUOKwITuHc=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_M3u_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJo)
  if xbmcvfs.exists(aYXhCglMDNFBRVLrGpdfAUOKwITuHc):
   if xbmcvfs.delete(aYXhCglMDNFBRVLrGpdfAUOKwITuHc)==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:
    aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti(__language__(30910).encode('utf-8'))
    return
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(aYXhCglMDNFBRVLrGpdfAUOKwITumy,args):
  aYXhCglMDNFBRVLrGpdfAUOKwITuHk=args.get('sType')
  aYXhCglMDNFBRVLrGpdfAUOKwITuHW=args.get('sName')
  aYXhCglMDNFBRVLrGpdfAUOKwITumz=xbmcgui.Dialog()
  aYXhCglMDNFBRVLrGpdfAUOKwITuHy=aYXhCglMDNFBRVLrGpdfAUOKwITumz.yesno((aYXhCglMDNFBRVLrGpdfAUOKwITuHW+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if aYXhCglMDNFBRVLrGpdfAUOKwITuHy==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:sys.exit()
  aYXhCglMDNFBRVLrGpdfAUOKwITuHo =[]
  aYXhCglMDNFBRVLrGpdfAUOKwITuHz =[]
  aYXhCglMDNFBRVLrGpdfAUOKwITuHc=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_M3u_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJP)
  if os.path.isfile(aYXhCglMDNFBRVLrGpdfAUOKwITuHc):os.remove(aYXhCglMDNFBRVLrGpdfAUOKwITuHc)
  if aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all':
   aYXhCglMDNFBRVLrGpdfAUOKwITuHc=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_M3u_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJo)
   if xbmcvfs.exists(aYXhCglMDNFBRVLrGpdfAUOKwITuHc):
    if xbmcvfs.delete(aYXhCglMDNFBRVLrGpdfAUOKwITuHc)==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:
     aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   aYXhCglMDNFBRVLrGpdfAUOKwITuHP=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_M3u_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJo)
   if xbmcvfs.exists(aYXhCglMDNFBRVLrGpdfAUOKwITuHP):
    aYXhCglMDNFBRVLrGpdfAUOKwITuHx=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_M3u_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJP)
    xbmcvfs.copy(aYXhCglMDNFBRVLrGpdfAUOKwITuHP,aYXhCglMDNFBRVLrGpdfAUOKwITuHx)
  if(aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='wavve' or aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all')and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVE:
   aYXhCglMDNFBRVLrGpdfAUOKwITuHb=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_ChannelList_Wavve(exceptGroup=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_EexceptGroup_Wavve())
   if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)!=0:aYXhCglMDNFBRVLrGpdfAUOKwITuHo.extend(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_log('wavve cnt ----> '+aYXhCglMDNFBRVLrGpdfAUOKwITuJe(aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)))
  if(aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='tving' or aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all')and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONTVING:
   aYXhCglMDNFBRVLrGpdfAUOKwITuHb=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_ChannelList_Tving()
   if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)!=0:aYXhCglMDNFBRVLrGpdfAUOKwITuHo.extend(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_log('tving cnt ----> '+aYXhCglMDNFBRVLrGpdfAUOKwITuJe(aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)))
  if(aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='spotv' or aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all')and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSPOTV:
   aYXhCglMDNFBRVLrGpdfAUOKwITuHb=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_ChannelList_Spotv(payyn=aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSPOTVPAY)
   if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)!=0:aYXhCglMDNFBRVLrGpdfAUOKwITuHo.extend(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_log('spotv cnt ----> '+aYXhCglMDNFBRVLrGpdfAUOKwITuJe(aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)))
  if(aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='samsung' or aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all')and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSAMSUNG:
   aYXhCglMDNFBRVLrGpdfAUOKwITuHi=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_BaseInfo_Samsungtv()
   aYXhCglMDNFBRVLrGpdfAUOKwITuHb=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_ChannelList_Samsungtv(aYXhCglMDNFBRVLrGpdfAUOKwITuHi,exceptGroup=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_EexceptGroup_Samsungtv())
   if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)!=0:aYXhCglMDNFBRVLrGpdfAUOKwITuHo.extend(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_log('samsungtv cnt ----> '+aYXhCglMDNFBRVLrGpdfAUOKwITuJe(aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)))
  if(aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='bc_sbs' or aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all')and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_BC_SBS:
   aYXhCglMDNFBRVLrGpdfAUOKwITuHb=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_ChannelList_BroadCast_SBS()
   if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)!=0:aYXhCglMDNFBRVLrGpdfAUOKwITuHo.extend(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_log('bc_sbs cnt ----> '+aYXhCglMDNFBRVLrGpdfAUOKwITuJe(aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHb)))
  if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHo)==0 and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_CUSTOM_LIST==[]:
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti(__language__(30909).encode('utf8'))
   return
  for aYXhCglMDNFBRVLrGpdfAUOKwITuHq in aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.INIT_GENRESORT:
   for aYXhCglMDNFBRVLrGpdfAUOKwITuHv in aYXhCglMDNFBRVLrGpdfAUOKwITuHo:
    if aYXhCglMDNFBRVLrGpdfAUOKwITuHv['genrenm']==aYXhCglMDNFBRVLrGpdfAUOKwITuHq:
     aYXhCglMDNFBRVLrGpdfAUOKwITuHz.append(aYXhCglMDNFBRVLrGpdfAUOKwITuHv)
  for aYXhCglMDNFBRVLrGpdfAUOKwITuHv in aYXhCglMDNFBRVLrGpdfAUOKwITuHo:
   if aYXhCglMDNFBRVLrGpdfAUOKwITuHv['genrenm']not in aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.INIT_GENRESORT:
    aYXhCglMDNFBRVLrGpdfAUOKwITuHz.append(aYXhCglMDNFBRVLrGpdfAUOKwITuHv)
  try:
   if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuHo)>0:
    aYXhCglMDNFBRVLrGpdfAUOKwITuHc=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_M3u_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJP)
    if os.path.isfile(aYXhCglMDNFBRVLrGpdfAUOKwITuHc):
     fp=aYXhCglMDNFBRVLrGpdfAUOKwITuJn(aYXhCglMDNFBRVLrGpdfAUOKwITuHc,'a',-1,'utf-8')
    else:
     fp=aYXhCglMDNFBRVLrGpdfAUOKwITuJn(aYXhCglMDNFBRVLrGpdfAUOKwITuHc,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for aYXhCglMDNFBRVLrGpdfAUOKwITuHe in aYXhCglMDNFBRVLrGpdfAUOKwITuHz:
     aYXhCglMDNFBRVLrGpdfAUOKwITuHn =aYXhCglMDNFBRVLrGpdfAUOKwITuHe['channelid']
     aYXhCglMDNFBRVLrGpdfAUOKwITuHt =aYXhCglMDNFBRVLrGpdfAUOKwITuHe['channelnm']
     aYXhCglMDNFBRVLrGpdfAUOKwITuHS=aYXhCglMDNFBRVLrGpdfAUOKwITuHe['channelimg']
     aYXhCglMDNFBRVLrGpdfAUOKwITuHE =aYXhCglMDNFBRVLrGpdfAUOKwITuHe['ott']
     aYXhCglMDNFBRVLrGpdfAUOKwITuHQ ='%s.%s'%(aYXhCglMDNFBRVLrGpdfAUOKwITuHn,aYXhCglMDNFBRVLrGpdfAUOKwITuHE)
     aYXhCglMDNFBRVLrGpdfAUOKwITujm=aYXhCglMDNFBRVLrGpdfAUOKwITuHe['genrenm']
     if aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_DISPLAYNM:
      aYXhCglMDNFBRVLrGpdfAUOKwITuHt='%s (%s)'%(aYXhCglMDNFBRVLrGpdfAUOKwITuHt,aYXhCglMDNFBRVLrGpdfAUOKwITuHE)
     if aYXhCglMDNFBRVLrGpdfAUOKwITujm=='라디오/음악':
      aYXhCglMDNFBRVLrGpdfAUOKwITujH='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(aYXhCglMDNFBRVLrGpdfAUOKwITuHQ,aYXhCglMDNFBRVLrGpdfAUOKwITuHt,aYXhCglMDNFBRVLrGpdfAUOKwITujm,aYXhCglMDNFBRVLrGpdfAUOKwITuHS,aYXhCglMDNFBRVLrGpdfAUOKwITuHt)
     else:
      aYXhCglMDNFBRVLrGpdfAUOKwITujH='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(aYXhCglMDNFBRVLrGpdfAUOKwITuHQ,aYXhCglMDNFBRVLrGpdfAUOKwITuHt,aYXhCglMDNFBRVLrGpdfAUOKwITujm,aYXhCglMDNFBRVLrGpdfAUOKwITuHS,aYXhCglMDNFBRVLrGpdfAUOKwITuHt)
     if aYXhCglMDNFBRVLrGpdfAUOKwITuHE=='wavve':
      aYXhCglMDNFBRVLrGpdfAUOKwITujJ ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(aYXhCglMDNFBRVLrGpdfAUOKwITuHn)
     elif aYXhCglMDNFBRVLrGpdfAUOKwITuHE=='tving':
      aYXhCglMDNFBRVLrGpdfAUOKwITujJ ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(aYXhCglMDNFBRVLrGpdfAUOKwITuHn)
     elif aYXhCglMDNFBRVLrGpdfAUOKwITuHE=='spotv':
      aYXhCglMDNFBRVLrGpdfAUOKwITujJ ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(aYXhCglMDNFBRVLrGpdfAUOKwITuHn)
     elif aYXhCglMDNFBRVLrGpdfAUOKwITuHE=='samsung':
      aYXhCglMDNFBRVLrGpdfAUOKwITujJ ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(aYXhCglMDNFBRVLrGpdfAUOKwITuHn)
     elif aYXhCglMDNFBRVLrGpdfAUOKwITuHE=='bc_sbs':
      aYXhCglMDNFBRVLrGpdfAUOKwITujJ ='plugin://plugin.video.broadcastm/?mode=LIVE&company=sbs&channlCode=%s\n'%(aYXhCglMDNFBRVLrGpdfAUOKwITuHn)
     fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujH)
     fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujJ)
    fp.close()
  except:
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti(__language__(30910).encode('utf8'))
   return
  try:
   if(aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='custom' or aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all')and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_CUSTOM_LIST!=[]:
    aYXhCglMDNFBRVLrGpdfAUOKwITuHc=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_M3u_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJP)
    if os.path.isfile(aYXhCglMDNFBRVLrGpdfAUOKwITuHc):
     fp=aYXhCglMDNFBRVLrGpdfAUOKwITuJn(aYXhCglMDNFBRVLrGpdfAUOKwITuHc,'a',-1,'utf-8')
    else:
     fp=aYXhCglMDNFBRVLrGpdfAUOKwITuJn(aYXhCglMDNFBRVLrGpdfAUOKwITuHc,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for aYXhCglMDNFBRVLrGpdfAUOKwITujs in aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_CUSTOM_LIST:
     aYXhCglMDNFBRVLrGpdfAUOKwITujy=aYXhCglMDNFBRVLrGpdfAUOKwITumy.customEpg_FileRead(aYXhCglMDNFBRVLrGpdfAUOKwITujs)
     for aYXhCglMDNFBRVLrGpdfAUOKwITujc in aYXhCglMDNFBRVLrGpdfAUOKwITujy:
      aYXhCglMDNFBRVLrGpdfAUOKwITujc=aYXhCglMDNFBRVLrGpdfAUOKwITujc.strip()
      if aYXhCglMDNFBRVLrGpdfAUOKwITujc not in['','#EXTM3U']:
       fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujc+'\n')
   fp.close()
  except:
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti(__language__(30910).encode('utf8'))
   return
  aYXhCglMDNFBRVLrGpdfAUOKwITuHP=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_M3u_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJP)
  aYXhCglMDNFBRVLrGpdfAUOKwITuHx=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_M3u_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJo)
  if xbmcvfs.copy(aYXhCglMDNFBRVLrGpdfAUOKwITuHP,aYXhCglMDNFBRVLrGpdfAUOKwITuHx):
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti((aYXhCglMDNFBRVLrGpdfAUOKwITuHW+' '+__language__(30908)).encode('utf8'))
  else:
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti(__language__(30910).encode('utf-8'))
 def customEpg_FileList(aYXhCglMDNFBRVLrGpdfAUOKwITumy):
  aYXhCglMDNFBRVLrGpdfAUOKwITujk=[]
  if __addon__.getSetting('custom01on')=='true':aYXhCglMDNFBRVLrGpdfAUOKwITujk.append(__addon__.getSetting('custom01nm'))
  if __addon__.getSetting('custom02on')=='true':aYXhCglMDNFBRVLrGpdfAUOKwITujk.append(__addon__.getSetting('custom02nm'))
  if __addon__.getSetting('custom03on')=='true':aYXhCglMDNFBRVLrGpdfAUOKwITujk.append(__addon__.getSetting('custom03nm'))
  if __addon__.getSetting('custom04on')=='true':aYXhCglMDNFBRVLrGpdfAUOKwITujk.append(__addon__.getSetting('custom04nm'))
  if __addon__.getSetting('custom05on')=='true':aYXhCglMDNFBRVLrGpdfAUOKwITujk.append(__addon__.getSetting('custom05nm'))
  return aYXhCglMDNFBRVLrGpdfAUOKwITujk
 def customEpg_FileRead(aYXhCglMDNFBRVLrGpdfAUOKwITumy,source_filename):
  try:
   aYXhCglMDNFBRVLrGpdfAUOKwITujW=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
   if os.path.isfile(aYXhCglMDNFBRVLrGpdfAUOKwITujW):os.remove(aYXhCglMDNFBRVLrGpdfAUOKwITujW)
   xbmcvfs.copy(source_filename,aYXhCglMDNFBRVLrGpdfAUOKwITujW)
   fp=aYXhCglMDNFBRVLrGpdfAUOKwITuJn(aYXhCglMDNFBRVLrGpdfAUOKwITujW,'r',-1,'utf-8')
   aYXhCglMDNFBRVLrGpdfAUOKwITujo=fp.readlines()
  except:
   return[]
  return aYXhCglMDNFBRVLrGpdfAUOKwITujo
 def dp_Make_Epg(aYXhCglMDNFBRVLrGpdfAUOKwITumy,args):
  aYXhCglMDNFBRVLrGpdfAUOKwITuHk=args.get('sType')
  aYXhCglMDNFBRVLrGpdfAUOKwITuHW=args.get('sName')
  aYXhCglMDNFBRVLrGpdfAUOKwITujz=args.get('sNoti')
  if aYXhCglMDNFBRVLrGpdfAUOKwITujz!='N':
   aYXhCglMDNFBRVLrGpdfAUOKwITumz=xbmcgui.Dialog()
   aYXhCglMDNFBRVLrGpdfAUOKwITuHy=aYXhCglMDNFBRVLrGpdfAUOKwITumz.yesno((aYXhCglMDNFBRVLrGpdfAUOKwITuHW+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if aYXhCglMDNFBRVLrGpdfAUOKwITuHy==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:sys.exit()
  aYXhCglMDNFBRVLrGpdfAUOKwITujP=[]
  aYXhCglMDNFBRVLrGpdfAUOKwITujx=[]
  if(aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='wavve' or aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all')and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVE:
   aYXhCglMDNFBRVLrGpdfAUOKwITujb,aYXhCglMDNFBRVLrGpdfAUOKwITuji=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_EexceptGroup_Wavve())
   if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuji)!=0:
    aYXhCglMDNFBRVLrGpdfAUOKwITujP.extend(aYXhCglMDNFBRVLrGpdfAUOKwITujb)
    aYXhCglMDNFBRVLrGpdfAUOKwITujx.extend(aYXhCglMDNFBRVLrGpdfAUOKwITuji)
  if(aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='tving' or aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all')and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONTVING:
   aYXhCglMDNFBRVLrGpdfAUOKwITujb,aYXhCglMDNFBRVLrGpdfAUOKwITuji=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_EpgInfo_Tving()
   if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuji)!=0:
    aYXhCglMDNFBRVLrGpdfAUOKwITujP.extend(aYXhCglMDNFBRVLrGpdfAUOKwITujb)
    aYXhCglMDNFBRVLrGpdfAUOKwITujx.extend(aYXhCglMDNFBRVLrGpdfAUOKwITuji)
  if(aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='spotv' or aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all')and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSPOTV:
   aYXhCglMDNFBRVLrGpdfAUOKwITujb,aYXhCglMDNFBRVLrGpdfAUOKwITuji=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_EpgInfo_Spotv(payyn=aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSPOTVPAY)
   if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuji)!=0:
    aYXhCglMDNFBRVLrGpdfAUOKwITujP.extend(aYXhCglMDNFBRVLrGpdfAUOKwITujb)
    aYXhCglMDNFBRVLrGpdfAUOKwITujx.extend(aYXhCglMDNFBRVLrGpdfAUOKwITuji)
  if(aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='samsung' or aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all')and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSAMSUNG:
   aYXhCglMDNFBRVLrGpdfAUOKwITuHi=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_BaseInfo_Samsungtv()
   aYXhCglMDNFBRVLrGpdfAUOKwITujb,aYXhCglMDNFBRVLrGpdfAUOKwITuji=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_EpgInfo_Samsungtv(aYXhCglMDNFBRVLrGpdfAUOKwITuHi,exceptGroup=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_EexceptGroup_Samsungtv())
   if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuji)!=0:
    aYXhCglMDNFBRVLrGpdfAUOKwITujP.extend(aYXhCglMDNFBRVLrGpdfAUOKwITujb)
    aYXhCglMDNFBRVLrGpdfAUOKwITujx.extend(aYXhCglMDNFBRVLrGpdfAUOKwITuji)
  if(aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='bc_sbs' or aYXhCglMDNFBRVLrGpdfAUOKwITuHk=='all')and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_BC_SBS:
   aYXhCglMDNFBRVLrGpdfAUOKwITujb,aYXhCglMDNFBRVLrGpdfAUOKwITuji=aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_EpgInfo_BroadCast_SBS()
   if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITuji)!=0:
    aYXhCglMDNFBRVLrGpdfAUOKwITujP.extend(aYXhCglMDNFBRVLrGpdfAUOKwITujb)
    aYXhCglMDNFBRVLrGpdfAUOKwITujx.extend(aYXhCglMDNFBRVLrGpdfAUOKwITuji)
  if aYXhCglMDNFBRVLrGpdfAUOKwITuJv(aYXhCglMDNFBRVLrGpdfAUOKwITujx)==0:
   if aYXhCglMDNFBRVLrGpdfAUOKwITujz!='N':aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   aYXhCglMDNFBRVLrGpdfAUOKwITuHc=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_Epg_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJP)
   fp=aYXhCglMDNFBRVLrGpdfAUOKwITuJn(aYXhCglMDNFBRVLrGpdfAUOKwITuHc,'w',-1,'utf-8')
   aYXhCglMDNFBRVLrGpdfAUOKwITujq='<?xml version="1.0" encoding="UTF-8"?>\n'
   aYXhCglMDNFBRVLrGpdfAUOKwITujv='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   aYXhCglMDNFBRVLrGpdfAUOKwITuje='<tv generator-info-name="boritv_epg">\n\n'
   aYXhCglMDNFBRVLrGpdfAUOKwITujn='\n</tv>\n'
   fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujq)
   fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujv)
   fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITuje)
   for aYXhCglMDNFBRVLrGpdfAUOKwITujt in aYXhCglMDNFBRVLrGpdfAUOKwITujP:
    aYXhCglMDNFBRVLrGpdfAUOKwITujS='  <channel id="%s.%s">\n' %(aYXhCglMDNFBRVLrGpdfAUOKwITujt.get('channelid'),aYXhCglMDNFBRVLrGpdfAUOKwITujt.get('ott'))
    aYXhCglMDNFBRVLrGpdfAUOKwITujE='    <display-name>%s</display-name>\n'%(aYXhCglMDNFBRVLrGpdfAUOKwITujt.get('channelnm'))
    aYXhCglMDNFBRVLrGpdfAUOKwITujQ='    <icon src="%s" />\n' %(aYXhCglMDNFBRVLrGpdfAUOKwITujt.get('channelimg'))
    aYXhCglMDNFBRVLrGpdfAUOKwITuJm='  </channel>\n\n'
    fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujS)
    fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujE)
    fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujQ)
    fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITuJm)
   for aYXhCglMDNFBRVLrGpdfAUOKwITujt in aYXhCglMDNFBRVLrGpdfAUOKwITujx:
    aYXhCglMDNFBRVLrGpdfAUOKwITujS='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(aYXhCglMDNFBRVLrGpdfAUOKwITujt.get('startTime'),aYXhCglMDNFBRVLrGpdfAUOKwITujt.get('endTime'),aYXhCglMDNFBRVLrGpdfAUOKwITujt.get('channelid'),aYXhCglMDNFBRVLrGpdfAUOKwITujt.get('ott'))
    aYXhCglMDNFBRVLrGpdfAUOKwITujE='    <title lang="kr">%s</title>\n' %(aYXhCglMDNFBRVLrGpdfAUOKwITujt.get('title'))
    aYXhCglMDNFBRVLrGpdfAUOKwITujQ='  </programme>\n\n'
    fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujS)
    fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujE)
    fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujQ)
   fp.write(aYXhCglMDNFBRVLrGpdfAUOKwITujn)
   fp.close()
  except:
   if aYXhCglMDNFBRVLrGpdfAUOKwITujz!='N':aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti(__language__(30910).encode('utf8'))
   return
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.MakeEpg_SaveJson()
  aYXhCglMDNFBRVLrGpdfAUOKwITuHP=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_Epg_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJP)
  aYXhCglMDNFBRVLrGpdfAUOKwITuHx=aYXhCglMDNFBRVLrGpdfAUOKwITumy.make_Epg_Filename(tempyn=aYXhCglMDNFBRVLrGpdfAUOKwITuJo)
  if xbmcvfs.copy(aYXhCglMDNFBRVLrGpdfAUOKwITuHP,aYXhCglMDNFBRVLrGpdfAUOKwITuHx):
   if aYXhCglMDNFBRVLrGpdfAUOKwITujz!='N':aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti((aYXhCglMDNFBRVLrGpdfAUOKwITuHW+' '+__language__(30912)).encode('utf8'))
  else:
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_AUTORESTART:
    aYXhCglMDNFBRVLrGpdfAUOKwITuJH=xbmcaddon.Addon('pvr.iptvsimple')
    aYXhCglMDNFBRVLrGpdfAUOKwITuJH.setSetting('anything','anything')
  except:
   aYXhCglMDNFBRVLrGpdfAUOKwITuJz 
 def make_EexceptGroup_Wavve(aYXhCglMDNFBRVLrGpdfAUOKwITumy):
  aYXhCglMDNFBRVLrGpdfAUOKwITuJj=[]
  if aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVERADIO==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:
   aYXhCglMDNFBRVLrGpdfAUOKwITuJj.append('라디오/음악')
  if aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVEHOME==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:
   aYXhCglMDNFBRVLrGpdfAUOKwITuJj.append('홈쇼핑')
  if aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONRELIGION==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:
   aYXhCglMDNFBRVLrGpdfAUOKwITuJj.append('종교')
  return aYXhCglMDNFBRVLrGpdfAUOKwITuJj
 def make_EexceptGroup_Samsungtv(aYXhCglMDNFBRVLrGpdfAUOKwITumy):
  aYXhCglMDNFBRVLrGpdfAUOKwITuJj=[]
  if aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSAMSUNGHOME==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:
   aYXhCglMDNFBRVLrGpdfAUOKwITuJj.append('홈쇼핑')
  return aYXhCglMDNFBRVLrGpdfAUOKwITuJj
 def get_radio_list(aYXhCglMDNFBRVLrGpdfAUOKwITumy):
  if aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVERADIO==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:return[]
  aYXhCglMDNFBRVLrGpdfAUOKwITuJs=[{'broadcastid':'46584','genre':'10'}]
  return aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_ChannelList_WavveExcept(aYXhCglMDNFBRVLrGpdfAUOKwITuJs)
 def check_config(aYXhCglMDNFBRVLrGpdfAUOKwITumy):
  aYXhCglMDNFBRVLrGpdfAUOKwITuJy=aYXhCglMDNFBRVLrGpdfAUOKwITuJP
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVE =aYXhCglMDNFBRVLrGpdfAUOKwITuJP if __addon__.getSetting('onWavve')=='true' else aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONTVING =aYXhCglMDNFBRVLrGpdfAUOKwITuJP if __addon__.getSetting('onTvng')=='true' else aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSPOTV =aYXhCglMDNFBRVLrGpdfAUOKwITuJP if __addon__.getSetting('onSpotv')=='true' else aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_BC_SBS =aYXhCglMDNFBRVLrGpdfAUOKwITuJP if __addon__.getSetting('onBroadSBS')=='true' else aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSAMSUNG =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVERADIO =aYXhCglMDNFBRVLrGpdfAUOKwITuJP if __addon__.getSetting('onWavveRadio')=='true' else aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVEHOME =aYXhCglMDNFBRVLrGpdfAUOKwITuJP if __addon__.getSetting('onWavveHome')=='true' else aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONRELIGION =aYXhCglMDNFBRVLrGpdfAUOKwITuJP if __addon__.getSetting('onWavveReligion')=='true' else aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSPOTVPAY =aYXhCglMDNFBRVLrGpdfAUOKwITuJP if __addon__.getSetting('onSpotvPay')=='true' else aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSAMSUNGHOME =aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_DISPLAYNM =aYXhCglMDNFBRVLrGpdfAUOKwITuJP if __addon__.getSetting('displayOTTnm')=='true' else aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_AUTORESTART =aYXhCglMDNFBRVLrGpdfAUOKwITuJP if __addon__.getSetting('autoRestart')=='true' else aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_CUSTOM_LIST =aYXhCglMDNFBRVLrGpdfAUOKwITumy.customEpg_FileList()
  if aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_FILE_PATH=='' or aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_FILE_NAME=='':aYXhCglMDNFBRVLrGpdfAUOKwITuJy=aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  if aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONWAVVE==aYXhCglMDNFBRVLrGpdfAUOKwITuJo and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONTVING==aYXhCglMDNFBRVLrGpdfAUOKwITuJo and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSPOTV==aYXhCglMDNFBRVLrGpdfAUOKwITuJo and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_ONSAMSUNG==aYXhCglMDNFBRVLrGpdfAUOKwITuJo and aYXhCglMDNFBRVLrGpdfAUOKwITumy.M3U_BC_SBS==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:aYXhCglMDNFBRVLrGpdfAUOKwITuJy=aYXhCglMDNFBRVLrGpdfAUOKwITuJo
  if aYXhCglMDNFBRVLrGpdfAUOKwITuJy==aYXhCglMDNFBRVLrGpdfAUOKwITuJo:
   aYXhCglMDNFBRVLrGpdfAUOKwITumz=xbmcgui.Dialog()
   aYXhCglMDNFBRVLrGpdfAUOKwITuHy=aYXhCglMDNFBRVLrGpdfAUOKwITumz.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if aYXhCglMDNFBRVLrGpdfAUOKwITuHy==aYXhCglMDNFBRVLrGpdfAUOKwITuJP:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(aYXhCglMDNFBRVLrGpdfAUOKwITumy):
  aYXhCglMDNFBRVLrGpdfAUOKwITuJc={'date_makeepg':aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=aYXhCglMDNFBRVLrGpdfAUOKwITuJn(aYXhCglMDNFBRVLrGpdfAUOKwITums,'w',-1,'utf-8')
   json.dump(aYXhCglMDNFBRVLrGpdfAUOKwITuJc,fp)
   fp.close()
  except aYXhCglMDNFBRVLrGpdfAUOKwITuJt as exception:
   return
 def boritv_main(aYXhCglMDNFBRVLrGpdfAUOKwITumy):
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.BoritvObj.KodiVersion=aYXhCglMDNFBRVLrGpdfAUOKwITuJi(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  aYXhCglMDNFBRVLrGpdfAUOKwITuJk=aYXhCglMDNFBRVLrGpdfAUOKwITumy.main_params.get('mode',aYXhCglMDNFBRVLrGpdfAUOKwITuJz)
  aYXhCglMDNFBRVLrGpdfAUOKwITumy.check_config()
  if aYXhCglMDNFBRVLrGpdfAUOKwITuJk is aYXhCglMDNFBRVLrGpdfAUOKwITuJz:
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.dp_Main_List()
  elif aYXhCglMDNFBRVLrGpdfAUOKwITuJk=='DEL_M3U':
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.dp_Delete_M3u(aYXhCglMDNFBRVLrGpdfAUOKwITumy.main_params)
  elif aYXhCglMDNFBRVLrGpdfAUOKwITuJk=='ADD_M3U':
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.dp_MakeAdd_M3u(aYXhCglMDNFBRVLrGpdfAUOKwITumy.main_params)
  elif aYXhCglMDNFBRVLrGpdfAUOKwITuJk=='ADD_EPG':
   aYXhCglMDNFBRVLrGpdfAUOKwITumy.dp_Make_Epg(aYXhCglMDNFBRVLrGpdfAUOKwITumy.main_params)
  else:
   aYXhCglMDNFBRVLrGpdfAUOKwITuJz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
