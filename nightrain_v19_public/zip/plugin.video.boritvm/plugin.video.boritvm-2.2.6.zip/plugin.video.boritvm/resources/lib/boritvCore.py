__author__="NightRain"
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyn=False
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyT=object
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyR=open
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyH=True
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq=None
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ=Exception
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj=print
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyS=range
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyw=len
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf=str
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW=int
XuMsGFkrdCKcPUiNDbtIEvVhpxmoya=dict
XuMsGFkrdCKcPUiNDbtIEvVhpxmoyg=set
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
XuMsGFkrdCKcPUiNDbtIEvVhpxmoeO=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
XuMsGFkrdCKcPUiNDbtIEvVhpxmoel=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyn,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class XuMsGFkrdCKcPUiNDbtIEvVhpxmoeL(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyT):
 def __init__(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_WAVVE ='https://apis.wavve.com'
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_TVING ='https://api.tving.com'
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_TVINGIMG ='https://image.tving.com'
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_SPOTV ='https://www.spotvnow.co.kr'
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.HTTPTAG ='https://'
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.LIMIT_WAVVE =500
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.LIMIT_TVING =60
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.LIMIT_TVINGEPG=20 
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.APPVERSION ='115.0.0.0' 
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.DEVICEMODEL ='Chrome' 
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.OSTYPE ='Windows' 
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.OSVERSION ='NT 10.0' 
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.DEFAULT_HEADER={'user-agent':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.USER_AGENT}
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.SLEEP_TIME =0.2
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.INIT_GENRESORT=MASTER_GENRE
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.INIT_CHANNEL =MASTER_CHANNEL
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.KodiVersion =20
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.BT_CONTEXTJSON_FILE1=''
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.BT_CONTEXTJSON_FILE2=''
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.BT_CONTEXTJSON_FILE3=''
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.BT_CONTEXTJSON_FILE4=''
 def JsonFile_Save(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,XuMsGFkrdCKcPUiNDbtIEvVhpxmolB,XuMsGFkrdCKcPUiNDbtIEvVhpxmoeT):
  if XuMsGFkrdCKcPUiNDbtIEvVhpxmolB=='':return XuMsGFkrdCKcPUiNDbtIEvVhpxmoyn
  try:
   fp=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyR(XuMsGFkrdCKcPUiNDbtIEvVhpxmolB,'w',-1,'utf-8')
   json.dump(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeT,fp,indent=4,ensure_ascii=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyn)
   fp.close()
  except:
   return XuMsGFkrdCKcPUiNDbtIEvVhpxmoyn
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoyH
 def callRequestCookies(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,jobtype,XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,redirects=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyn):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeH=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.DEFAULT_HEADER
  if headers:XuMsGFkrdCKcPUiNDbtIEvVhpxmoeH.update(headers)
  if jobtype=='Get':
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeq=requests.get(XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,params=params,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeH,cookies=cookies,allow_redirects=redirects)
  else:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeq=requests.post(XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,data=payload,params=params,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeH,cookies=cookies,allow_redirects=redirects)
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoeq
 def Get_DefaultParams_Wavve(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ
 def Get_DefaultParams_Tving(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ
 def Get_Now_Datetime(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,in_text):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeS=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoeS
 def Get_ChannelList_BroadCast_SBS(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew =[]
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef='https://apis.sbs.co.kr/play-api/1.0/onair/channels'
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,redirects=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyH)
   if XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.status_code!=200:return[]
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoeg in XuMsGFkrdCKcPUiNDbtIEvVhpxmoea.get('list'):
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoeg['type']=='TV':
     if XuMsGFkrdCKcPUiNDbtIEvVhpxmoeg.get('channelid')+'.bc_sbs' in XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.INIT_CHANNEL:
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoez=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.INIT_CHANNEL[XuMsGFkrdCKcPUiNDbtIEvVhpxmoeg.get('channelid')+'.bc_sbs'].get('json_name')
     else:
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoez=''
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_getGenre(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeg.get('channelid'),'bc_sbs')
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoeg.get('channelid'),'channelnm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoeg.get('channelname'),'channelimg':'https://static.cloud.sbs.co.kr/common/img/sbsplayBig_logo.png','ott':'bc_sbs','genrenm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ,'json_name':XuMsGFkrdCKcPUiNDbtIEvVhpxmoez,}
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoew.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[]
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew
 def Get_EpgInfo_BroadCast_SBS(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,days=2):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew=[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB =[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoLe=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_DateList(days=2,dateType='3')
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew =XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_ChannelList_BroadCast_SBS()
  try:
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLO in XuMsGFkrdCKcPUiNDbtIEvVhpxmoew:
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoLO['json_name']in[XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,'']:continue
    for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLe:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLy='{dt.year}/{dt.month}/{dt.day}'.format(dt=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl)
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoef='https://static.cloud.sbs.co.kr/schedule/{}/{}.json'.format(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLy,XuMsGFkrdCKcPUiNDbtIEvVhpxmoLO['json_name'])
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
     for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLY in XuMsGFkrdCKcPUiNDbtIEvVhpxmoyS(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyw(XuMsGFkrdCKcPUiNDbtIEvVhpxmoea)):
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoLn=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoLT=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoLR=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLY]['start_time'].split(':')
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoLH=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLY]['end_time'].split(':')
      if XuMsGFkrdCKcPUiNDbtIEvVhpxmoyw(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLH)!=['']:
       if XuMsGFkrdCKcPUiNDbtIEvVhpxmoLY+1<XuMsGFkrdCKcPUiNDbtIEvVhpxmoyw(XuMsGFkrdCKcPUiNDbtIEvVhpxmoea):
        XuMsGFkrdCKcPUiNDbtIEvVhpxmoLH=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLY+1]['start_time'].split(':')
       else:
        XuMsGFkrdCKcPUiNDbtIEvVhpxmoLH=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLY]['start_time'].split(':')
        XuMsGFkrdCKcPUiNDbtIEvVhpxmoLH[0]=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLH[0])+1).zfill(2)
      if XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLR[0])>=24:
       XuMsGFkrdCKcPUiNDbtIEvVhpxmoLR[0]=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLR[0])-24).zfill(2)
       XuMsGFkrdCKcPUiNDbtIEvVhpxmoLn =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLn+datetime.timedelta(days=1)
      if XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLH[0])>=24:
       XuMsGFkrdCKcPUiNDbtIEvVhpxmoLH[0]=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLH[0])-24).zfill(2)
       XuMsGFkrdCKcPUiNDbtIEvVhpxmoLT =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLT+datetime.timedelta(days=1)
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLO['channelid'],'title':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.xmlText(XuMsGFkrdCKcPUiNDbtIEvVhpxmoea[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLY]['title']),'startTime':'{}{}{}00'.format(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLn.strftime('%Y%m%d'),XuMsGFkrdCKcPUiNDbtIEvVhpxmoLR[0],XuMsGFkrdCKcPUiNDbtIEvVhpxmoLR[1]),'endTime':'{}{}{}00'.format(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLT.strftime('%Y%m%d'),XuMsGFkrdCKcPUiNDbtIEvVhpxmoLH[0],XuMsGFkrdCKcPUiNDbtIEvVhpxmoLH[1]),'ott':'bc_sbs',}
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
     time.sleep(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.SLEEP_TIME)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[],[]
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew,XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB
 def Get_ChannelList_Wavve(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,exceptGroup=[]):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew =[]
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_WAVVE+'/v2/live/channels'
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ={'service':'wavve','uitype':'band_2_rank','uiparent':'GN55-LN99','uicode':'LN99','uirank':'3','limit':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(200),'offset':'0','orderby':'viewtime','broadcastid':'LN99','isBand':'true','uitype':'LN58','client_version':'7.1.40'}
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ.update(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_DefaultParams_Wavve())
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
   if not('context_list' in XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['data']):return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['data']['context_list']
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['context_id']
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['live']['name']
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['live']['main_image']
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw and(not XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw.startswith('http://'))and(not XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw.startswith('https://')):
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.HTTPTAG+XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_getGenre(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'wavve')
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'channelnm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS,'channelimg':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw,'ott':'wavve','genrenm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ}
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ not in exceptGroup:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoew.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[]
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew
 def Get_ChannelList_Wavve_250831(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,exceptGroup=[]):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew =[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoLf=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_ChannelImg_Wavve()
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_WAVVE+'/cf/live/recommend-channels'
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ.update(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_DefaultParams_Wavve())
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
   if not('celllist' in XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['cell_toplist']):return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['cell_toplist']['celllist']
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['contentid']
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['title_list'][0]['text']
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLf:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLf[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj]
     if not XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw.startswith('http://')and not XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw.startswith('https://'):
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.HTTPTAG+XuMsGFkrdCKcPUiNDbtIEvVhpxmoLf[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj]
    else:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw=''
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_getGenre(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'wavve')
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'channelnm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS,'channelimg':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw,'ott':'wavve','genrenm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ}
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ not in exceptGroup:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoew.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[]
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew
 def Get_ChannelList_WavveExcept(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,exceptGroup=[]):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew=[]
  if exceptGroup==[]:return[]
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_WAVVE+'/cf/live/recommend-channels'
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in exceptGroup:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ={'WeekDay':'all','adult':'n','broadcastid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['broadcastid'],'contenttype':'channel','genre':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['genre'],'isrecommend':'y','limit':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ.update(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_DefaultParams_Wavve())
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
    if not('celllist' in XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['cell_toplist']):return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['cell_toplist']['celllist']
    for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoew.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['contentid'])
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[]
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew
 def Get_ChannelImg_Wavve(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoLW={}
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLa=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_Now_Datetime()
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLg =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLa+datetime.timedelta(hours=3)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_WAVVE+'/live/epgs'
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ={'limit':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLa.strftime('%Y-%m-%d %H:00'),'enddatetime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLg.strftime('%Y-%m-%d %H:00')}
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ.update(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_DefaultParams_Wavve())
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['list']
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLW[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channelid']]=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channelimage']
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoLW
 def Get_ChanneGenrename_Wavve(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj):
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_WAVVE+'/live/channels/'+XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_DefaultParams_Wavve()
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['genretext']
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return ''
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz
 def Get_ChannelList_Spotv(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,payyn=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyH):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew=[]
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_SPOTV+'/api/v3/channel'
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoea:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['id'])
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'channelnm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['name'],'channelimg':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['logo'],'ott':'spotv','genrenm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_getGenre(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'spotv'),'free':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['free']}
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoew.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[]
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew
 def Get_ChannelList_Tving(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew =[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoLJ=[]
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_TVING+'/v2/media/lives'
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ={'pageNo':'1','pageSize':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ.update(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_DefaultParams_Tving())
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
   if not('result' in XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['body']):return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['body']['result']
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq:
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['live_code']=='C44441':continue 
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLJ.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['live_code'])
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLf=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_ChannelImg_Tving(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLJ)
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['live_code']
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj=='C44441':continue 
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['schedule']['channel']['name']['ko']
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLf:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLf[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj]
    else:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw=''
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'channelnm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS,'channelimg':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw,'ott':'tving','genrenm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_getGenre(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'tving')}
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoew.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[]
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew
 def Get_timestamp(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,timetype=1):
  ts=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,timetype):
  if timetype=='1':
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLA={'transactionId':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLA={'timestamp':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_timestamp(timetype=1),'transactionId':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_timestamp(timetype=1)+'000000000000001',}
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoLA
 def make_EpgDatetime_Tving(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,days=2):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoLB=[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOe=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_DateList(days=2,dateType='2')
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOL=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoOe:
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoOl in XuMsGFkrdCKcPUiNDbtIEvVhpxmoyS(8):
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'ndate':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ,'starttm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoeO[XuMsGFkrdCKcPUiNDbtIEvVhpxmoOl]['starttm'],'endtm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoeO[XuMsGFkrdCKcPUiNDbtIEvVhpxmoOl]['endtm']}
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoOy=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ+XuMsGFkrdCKcPUiNDbtIEvVhpxmoeO[XuMsGFkrdCKcPUiNDbtIEvVhpxmoOl]['starttm'])
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoOY=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ+XuMsGFkrdCKcPUiNDbtIEvVhpxmoeO[XuMsGFkrdCKcPUiNDbtIEvVhpxmoOl]['endtm'])
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoOL<=XuMsGFkrdCKcPUiNDbtIEvVhpxmoOy or(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOy<XuMsGFkrdCKcPUiNDbtIEvVhpxmoOL and XuMsGFkrdCKcPUiNDbtIEvVhpxmoOL<XuMsGFkrdCKcPUiNDbtIEvVhpxmoOY):
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLB.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoLB
 def make_DateList(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,days=2,dateType='1'):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOe=[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOn =XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_Now_Datetime()
  for i in XuMsGFkrdCKcPUiNDbtIEvVhpxmoyS(days):
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoOT=XuMsGFkrdCKcPUiNDbtIEvVhpxmoOn+datetime.timedelta(days=i)
   if dateType=='1':
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoOe.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOT.strftime('%Y-%m-%d'))
   elif dateType=='2':
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoOe.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOT.strftime('%Y%m%d'))
   else:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoOe.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOT)
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoOe
 def make_Tving_ChannleGroup(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,XuMsGFkrdCKcPUiNDbtIEvVhpxmoLJ):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOR=[]
  i=0
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOH=''
  for XuMsGFkrdCKcPUiNDbtIEvVhpxmoOq in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLJ:
   if i==0:XuMsGFkrdCKcPUiNDbtIEvVhpxmoOH=XuMsGFkrdCKcPUiNDbtIEvVhpxmoOq
   else:XuMsGFkrdCKcPUiNDbtIEvVhpxmoOH+=',%s'%(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOq)
   i+=1
   if i>=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.LIMIT_TVINGEPG:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoOR.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOH)
    i=0
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoOH=''
  if XuMsGFkrdCKcPUiNDbtIEvVhpxmoOH!='':
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoOR.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOH)
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoOR
 def Get_ChannelImg_Tving(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,chid_list):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoLW={}
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoOQ=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_Now_Datetime().strftime('%Y%m%d')
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLa =XuMsGFkrdCKcPUiNDbtIEvVhpxmoeO[6]['starttm'] 
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLg =XuMsGFkrdCKcPUiNDbtIEvVhpxmoeO[6]['endtm']
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoOR=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_Tving_ChannleGroup(chid_list)
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoOR:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_TVING+'/v2/media/schedules'
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ={'pageNo':'1','pageSize':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':XuMsGFkrdCKcPUiNDbtIEvVhpxmoOQ,'broadcastDate':XuMsGFkrdCKcPUiNDbtIEvVhpxmoOQ,'startBroadTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLa,'endBroadTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLg,'channelCode':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ}
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ.update(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_DefaultParams_Tving())
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
    if not('result' in XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['body']):return{}
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['body']['result']
    for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq:
     for XuMsGFkrdCKcPUiNDbtIEvVhpxmoOj in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['image']:
      if XuMsGFkrdCKcPUiNDbtIEvVhpxmoOj['code']=='CAIC0400':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLW[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channel_code']]=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_TVINGIMG+XuMsGFkrdCKcPUiNDbtIEvVhpxmoOj['url']
      elif XuMsGFkrdCKcPUiNDbtIEvVhpxmoOj['code']=='CAIC1400':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLW[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channel_code']]=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_TVINGIMG+XuMsGFkrdCKcPUiNDbtIEvVhpxmoOj['url']
      elif XuMsGFkrdCKcPUiNDbtIEvVhpxmoOj['code']=='CAIC1900':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLW[XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channel_code']]=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_TVINGIMG+XuMsGFkrdCKcPUiNDbtIEvVhpxmoOj['url']
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return{}
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoLW
 def Get_EpgInfo_Spotv(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,days=2,payyn=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyH):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew=[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB =[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOe=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_DateList(days=days,dateType='1')
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_SPOTV+'/api/v3/channel'
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoea:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj =XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['id'])
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'channelnm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.xmlText(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['name']),'channelimg':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['logo'],'ott':'spotv'}
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoew.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[],[]
  try:
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoOS in XuMsGFkrdCKcPUiNDbtIEvVhpxmoOe:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_SPOTV+'/api/v3/program/'+XuMsGFkrdCKcPUiNDbtIEvVhpxmoOS
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
    for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoea:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj =XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channelId'])
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'title':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.xmlText(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['title']),'startTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
    time.sleep(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.SLEEP_TIME)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[],[]
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew,XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB
 def Make_Wavve_TimeList(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,days=2):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoLB=[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOw=[['00:00','03:00'],['03:00','06:00'],['06:00','09:00'],['09:00','12:00'],['12:00','15:00'],['15:00','18:00'],['18:00','21:00'],['21:00','24:00'],]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOf =XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_Now_Datetime()
  for i in XuMsGFkrdCKcPUiNDbtIEvVhpxmoyS(days):
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoOW =XuMsGFkrdCKcPUiNDbtIEvVhpxmoOf+datetime.timedelta(days=+i)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLn =XuMsGFkrdCKcPUiNDbtIEvVhpxmoOW.strftime('%Y-%m-%d')
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl in XuMsGFkrdCKcPUiNDbtIEvVhpxmoOw:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoOa=['{} {}'.format(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLn,XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl[0]),'{} {}'.format(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLn,XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl[1]),]
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLB.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOa)
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoLB
 def Get_EpgInfo_Wavve(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,days=2,exceptGroup=[]):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOg =[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew =[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB =[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoLB=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Make_Wavve_TimeList(days)
  try:
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLB:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_WAVVE+'/live/epgs'
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ={'limit':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl[0],'enddatetime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl[1],}
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ.update(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_DefaultParams_Wavve())
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoOz=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['list']
    for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoOz:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channelid']
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_getGenre(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'wavve')
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channelimage']
     if not XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw.startswith('http://')and not XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw.startswith('https://'):
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.HTTPTAG+XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'channelnm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.xmlText(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channelname']),'channelimg':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw,'ott':'wavve'}
     if XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ not in exceptGroup and XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj not in XuMsGFkrdCKcPUiNDbtIEvVhpxmoOg:
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoew.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoOg.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj)
     for XuMsGFkrdCKcPUiNDbtIEvVhpxmoOJ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['list']:
      XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channelid'],'title':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.xmlText(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOJ['title']),'startTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoOJ['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoOJ['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
      if XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ not in exceptGroup and XuMsGFkrdCKcPUiNDbtIEvVhpxmoOJ['starttime']!=XuMsGFkrdCKcPUiNDbtIEvVhpxmoOJ['endtime']:
       XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[],[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOA=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyw(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB)
  for i in(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyS(1,XuMsGFkrdCKcPUiNDbtIEvVhpxmoOA)):
   if XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB[i-1]['endTime'])+1==XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB[i]['startTime'])and XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB[i-1]['channelid']==XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB[i]['channelid']:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB[i-1]['endTime']=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB[i]['startTime']
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyw(XuMsGFkrdCKcPUiNDbtIEvVhpxmoew))
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew,XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB
 def Get_EpgInfo_Tving(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,days=2):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew=[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB =[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOg =[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoLe =XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_EpgDatetime_Tving(days=days)
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew =XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_ChannelList_Tving()
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOB=[]
  for i in XuMsGFkrdCKcPUiNDbtIEvVhpxmoyS(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyw(XuMsGFkrdCKcPUiNDbtIEvVhpxmoew)):
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoew[i]['channelnm']=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.xmlText(XuMsGFkrdCKcPUiNDbtIEvVhpxmoew[i]['channelnm'])
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoOB.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoew[i]['channelid'])
  XuMsGFkrdCKcPUiNDbtIEvVhpxmole=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_Tving_ChannleGroup(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOB)
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_TVING+'/v2/media/schedules'
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLe:
    for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLO in XuMsGFkrdCKcPUiNDbtIEvVhpxmole:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ={'pageNo':'1','pageSize':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl['ndate'],'broadcastDate':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl['ndate'],'startBroadTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl['starttm'],'endBroadTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLl['endtm'],'channelCode':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLO}
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ.update(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_DefaultParams_Tving())
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['body']['result']
     for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq:
      if 'schedules' not in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ:continue
      if XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['schedules']==XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq:continue
      for XuMsGFkrdCKcPUiNDbtIEvVhpxmolL in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['schedules']:
       XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmolL['schedule_code'],'title':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.xmlText(XuMsGFkrdCKcPUiNDbtIEvVhpxmolL['program']['name']['ko']),'startTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmolL['broadcast_start_time']),'endTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmolL['broadcast_end_time']),'ott':'tving'}
       XuMsGFkrdCKcPUiNDbtIEvVhpxmolO=XuMsGFkrdCKcPUiNDbtIEvVhpxmolL['schedule_code']+XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmolL['broadcast_start_time'])
       if XuMsGFkrdCKcPUiNDbtIEvVhpxmolO in XuMsGFkrdCKcPUiNDbtIEvVhpxmoOg:continue
       XuMsGFkrdCKcPUiNDbtIEvVhpxmoOg.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmolO)
       XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
     time.sleep(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.SLEEP_TIME)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[],[]
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew,XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB
 def Get_BaseInfo_Samsungtv(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoly={}
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_SAMSUNGTV
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq)
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmolY in XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.cookies:
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmolY.name=='session':
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoly['session']=XuMsGFkrdCKcPUiNDbtIEvVhpxmolY.value
    elif XuMsGFkrdCKcPUiNDbtIEvVhpxmolY.name=='session.sig':
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoly['session.sig']=XuMsGFkrdCKcPUiNDbtIEvVhpxmolY.value
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return{}
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_SAMSUNGTV+'/user'
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoln={'session':XuMsGFkrdCKcPUiNDbtIEvVhpxmoly['session'],'session.sig':XuMsGFkrdCKcPUiNDbtIEvVhpxmoly['session.sig'],}
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoln)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoly['countryCode']=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea.get('countryCode')
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoly['uuid'] =XuMsGFkrdCKcPUiNDbtIEvVhpxmoea.get('uuid')
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoly['ip'] =XuMsGFkrdCKcPUiNDbtIEvVhpxmoea.get('ip')
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return{}
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoly
 def t_Cache(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoOL =XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(time.time())
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolT=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyW(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOL-XuMsGFkrdCKcPUiNDbtIEvVhpxmoOL%3600)
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmolT,XuMsGFkrdCKcPUiNDbtIEvVhpxmoOL
 def zlib_compress(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,plaintext):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolR=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(XuMsGFkrdCKcPUiNDbtIEvVhpxmolR).decode('utf-8')
 def Get_BaseRequest_Samsungtv(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,XuMsGFkrdCKcPUiNDbtIEvVhpxmoly):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoea={}
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoef=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.API_SAMSUNGTV+'/api/lives'
   XuMsGFkrdCKcPUiNDbtIEvVhpxmolT,XuMsGFkrdCKcPUiNDbtIEvVhpxmoOL=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.t_Cache()
   XuMsGFkrdCKcPUiNDbtIEvVhpxmolH=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.zlib_compress(XuMsGFkrdCKcPUiNDbtIEvVhpxmoly['uuid']+':'+XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOL))
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoln={'session':XuMsGFkrdCKcPUiNDbtIEvVhpxmoly['session'],'session.sig':XuMsGFkrdCKcPUiNDbtIEvVhpxmoly['session.sig'],}
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ ={'t':XuMsGFkrdCKcPUiNDbtIEvVhpxmoyf(XuMsGFkrdCKcPUiNDbtIEvVhpxmolT)}
   XuMsGFkrdCKcPUiNDbtIEvVhpxmolq ={'x-cred-payload':XuMsGFkrdCKcPUiNDbtIEvVhpxmolH}
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.callRequestCookies('Get',XuMsGFkrdCKcPUiNDbtIEvVhpxmoef,payload=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq,params=XuMsGFkrdCKcPUiNDbtIEvVhpxmoeQ,headers=XuMsGFkrdCKcPUiNDbtIEvVhpxmolq,cookies=XuMsGFkrdCKcPUiNDbtIEvVhpxmoln)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=json.loads(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeW.text)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoea
 def Make_Samsungtv_logoUrl(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,fullUrl):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolQ=urllib.parse.urlparse(fullUrl) 
  if XuMsGFkrdCKcPUiNDbtIEvVhpxmolQ.netloc=='us-image.samsungtvplus.com':
   XuMsGFkrdCKcPUiNDbtIEvVhpxmolj=XuMsGFkrdCKcPUiNDbtIEvVhpxmoya(urllib.parse.parse_qsl(XuMsGFkrdCKcPUiNDbtIEvVhpxmolQ.query))
   if 'url' in XuMsGFkrdCKcPUiNDbtIEvVhpxmolj:
    return XuMsGFkrdCKcPUiNDbtIEvVhpxmolj.get('url')
  return fullUrl
 def Get_ChannelList_Samsungtv(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,XuMsGFkrdCKcPUiNDbtIEvVhpxmoly,exceptGroup=[]):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew =[]
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_BaseRequest_Samsungtv(XuMsGFkrdCKcPUiNDbtIEvVhpxmoly)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['live']['channel']
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLq:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ.get('id')
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ.get('name')
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Make_Samsungtv_logoUrl(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ.get('logo'))
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_getGenre(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'samsung')
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ in['-','']:XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ='정주행 채널'
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'channelnm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS,'channelimg':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw,'ott':'samsung','genrenm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ}
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ not in exceptGroup:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoew.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[]
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew
 def Get_EpgInfo_Samsungtv(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,XuMsGFkrdCKcPUiNDbtIEvVhpxmoly,exceptGroup=[]):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoew=[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB =[]
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoea =XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_BaseRequest_Samsungtv(XuMsGFkrdCKcPUiNDbtIEvVhpxmoly)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ=XuMsGFkrdCKcPUiNDbtIEvVhpxmoea['live']['channel']
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLO in XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLO.get('id')
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLO.get('name')
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Make_Samsungtv_logoUrl(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLO.get('logo'))
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoOz =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLO.get('program')
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.make_getGenre(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'samsung')
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ in exceptGroup:
     continue
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'channelnm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS,'channelimg':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLw,'ott':'samsung','genrenm':XuMsGFkrdCKcPUiNDbtIEvVhpxmoeJ}
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoew.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
    for XuMsGFkrdCKcPUiNDbtIEvVhpxmoOJ in XuMsGFkrdCKcPUiNDbtIEvVhpxmoOz:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmolS=XuMsGFkrdCKcPUiNDbtIEvVhpxmoOJ.get('start_time')
     XuMsGFkrdCKcPUiNDbtIEvVhpxmolw =XuMsGFkrdCKcPUiNDbtIEvVhpxmoOJ.get('duration') 
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLa=datetime.datetime.strptime(XuMsGFkrdCKcPUiNDbtIEvVhpxmolS,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLg =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLa+datetime.timedelta(seconds=XuMsGFkrdCKcPUiNDbtIEvVhpxmolw)
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA={'channelid':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,'title':XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.xmlText(urllib.parse.unquote_plus(XuMsGFkrdCKcPUiNDbtIEvVhpxmoOJ.get('title'))),'startTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLa.strftime('%Y%m%d%H%M00'),'endTime':XuMsGFkrdCKcPUiNDbtIEvVhpxmoLg.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  except XuMsGFkrdCKcPUiNDbtIEvVhpxmoyQ as exception:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(exception)
   return[],[]
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoew,XuMsGFkrdCKcPUiNDbtIEvVhpxmoeB
 def make_getGenre(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,XuMsGFkrdCKcPUiNDbtIEvVhpxmoyL):
  try:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.INIT_CHANNEL.get(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj+'.'+XuMsGFkrdCKcPUiNDbtIEvVhpxmoyL).get('genre')
  except:
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.INIT_CHANNEL.get('-').get('genre')
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz
 def make_base_allchannel_py(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey,XuMsGFkrdCKcPUiNDbtIEvVhpxmoly):
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolf =[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolW=[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmola=[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolg=[]
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolz=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyg()
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_ChannelList_Wavve()
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolf.extend(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_ChannelList_Tving()
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolf.extend(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_ChannelList_Spotv()
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolf.extend(XuMsGFkrdCKcPUiNDbtIEvVhpxmoeA)
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj('1')
  for i in XuMsGFkrdCKcPUiNDbtIEvVhpxmoyS(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyw(XuMsGFkrdCKcPUiNDbtIEvVhpxmolf)):
   if XuMsGFkrdCKcPUiNDbtIEvVhpxmolf[i]['genrenm']=='-':
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmolf[i]['ott']=='wavve':
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz=XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.Get_ChanneGenrename_Wavve(XuMsGFkrdCKcPUiNDbtIEvVhpxmolf[i]['channelid'])
     if XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz not in XuMsGFkrdCKcPUiNDbtIEvVhpxmolz:XuMsGFkrdCKcPUiNDbtIEvVhpxmolz.add(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz)
     time.sleep(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.SLEEP_TIME)
    elif XuMsGFkrdCKcPUiNDbtIEvVhpxmolf[i]['ott']=='spotv':
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz='스포츠'
    else:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz='-'
    XuMsGFkrdCKcPUiNDbtIEvVhpxmolf[i]['genrenm']=XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz
   else:
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmolf[i]['genrenm']not in XuMsGFkrdCKcPUiNDbtIEvVhpxmolz:XuMsGFkrdCKcPUiNDbtIEvVhpxmolz.add(XuMsGFkrdCKcPUiNDbtIEvVhpxmolf[i]['genrenm'])
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolz.add(XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.INIT_CHANNEL.get('-').get('genre'))
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj('2')
  for XuMsGFkrdCKcPUiNDbtIEvVhpxmolJ in XuMsGFkrdCKcPUiNDbtIEvVhpxmolz:
   for XuMsGFkrdCKcPUiNDbtIEvVhpxmolA in XuMsGFkrdCKcPUiNDbtIEvVhpxmolf:
    if XuMsGFkrdCKcPUiNDbtIEvVhpxmolA['genrenm']==XuMsGFkrdCKcPUiNDbtIEvVhpxmolJ:
     XuMsGFkrdCKcPUiNDbtIEvVhpxmolW.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmolA)
  for XuMsGFkrdCKcPUiNDbtIEvVhpxmolA in XuMsGFkrdCKcPUiNDbtIEvVhpxmolf:
   if XuMsGFkrdCKcPUiNDbtIEvVhpxmolA['genrenm']not in XuMsGFkrdCKcPUiNDbtIEvVhpxmolz:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmolW.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmolA)
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj('3')
  XuMsGFkrdCKcPUiNDbtIEvVhpxmolB='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(XuMsGFkrdCKcPUiNDbtIEvVhpxmolB):os.remove(XuMsGFkrdCKcPUiNDbtIEvVhpxmolB)
  fp=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyR(XuMsGFkrdCKcPUiNDbtIEvVhpxmolB,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  XuMsGFkrdCKcPUiNDbtIEvVhpxmoye=XuMsGFkrdCKcPUiNDbtIEvVhpxmoyw(XuMsGFkrdCKcPUiNDbtIEvVhpxmolW)
  i=0
  for XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ in XuMsGFkrdCKcPUiNDbtIEvVhpxmolW:
   i+=1
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channelid']
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['channelnm']
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyL =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['ott']
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyO ='%s.%s'%(XuMsGFkrdCKcPUiNDbtIEvVhpxmoLj,XuMsGFkrdCKcPUiNDbtIEvVhpxmoyL)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz =XuMsGFkrdCKcPUiNDbtIEvVhpxmoLQ['genrenm']
   XuMsGFkrdCKcPUiNDbtIEvVhpxmoyl='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyO,XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS,XuMsGFkrdCKcPUiNDbtIEvVhpxmoLz)
   if i<XuMsGFkrdCKcPUiNDbtIEvVhpxmoye:
    fp.write(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyl+',\n')
   else:
    fp.write(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyl+'\n')
   XuMsGFkrdCKcPUiNDbtIEvVhpxmola.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyO)
   XuMsGFkrdCKcPUiNDbtIEvVhpxmolg.append(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyO+'.'+XuMsGFkrdCKcPUiNDbtIEvVhpxmoLS)
  fp.write('}\n')
  fp.close()
  for XuMsGFkrdCKcPUiNDbtIEvVhpxmoyY,value in XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.INIT_CHANNEL.items():
   if XuMsGFkrdCKcPUiNDbtIEvVhpxmoyY not in XuMsGFkrdCKcPUiNDbtIEvVhpxmola:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq
  for XuMsGFkrdCKcPUiNDbtIEvVhpxmoyY,value in XuMsGFkrdCKcPUiNDbtIEvVhpxmoey.INIT_CHANNEL.items():
   if XuMsGFkrdCKcPUiNDbtIEvVhpxmoyY+'.'+value.get('channelnm')not in XuMsGFkrdCKcPUiNDbtIEvVhpxmolg:
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoyj(XuMsGFkrdCKcPUiNDbtIEvVhpxmoyY+'.'+value.get('channelnm'))
    XuMsGFkrdCKcPUiNDbtIEvVhpxmoyq
  return XuMsGFkrdCKcPUiNDbtIEvVhpxmolz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
