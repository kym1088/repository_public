_E='genrenm'
_D='channelid'
_C='ott'
_B='Get'
_A=None
__author__='NightRain'
import json,requests,datetime
class Boritv:
	def __init__(A):A.HTTPTAG='https://';A.USER_AGENT='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36';A.DEFAULT_HEADER={'user-agent':A.USER_AGENT};A.KodiVersion=20;A.BT_CONTEXTJSON_FILE1='';A.BT_CONTEXTJSON_FILE2='';A.BT_CONTEXTJSON_FILE3='';A.BT_CONTEXTJSON_FILE4='';A.GIT_BASE_M3U=[];A.GIT_BASE_EPG=[];A.GIT_CHANNEL_INFO={}
	def callRequestCookies(F,jobtype,url,payload=_A,params=_A,headers=_A,cookies=_A):
		D=cookies;C=headers;B=params;A=F.DEFAULT_HEADER
		if C:A.update(C)
		if jobtype==_B:E=requests.get(url,params=B,headers=A,cookies=D)
		else:E=requests.post(url,data=payload,params=B,headers=A,cookies=D)
		return E
	def INIT_INFO_LIST(A):
		B='https://raw.githubusercontent.com/kym1088/channel_info/refs/heads/main/data/bt_m3u_base.json';C=A.callRequestCookies(_B,B,payload=_A,params=_A,headers=_A,cookies=_A);A.GIT_BASE_M3U=json.loads(C.text)
		for D in A.GIT_BASE_M3U:A.GIT_CHANNEL_INFO.update({D[_D]+'.'+D[_C]:D})
		B='https://raw.githubusercontent.com/kym1088/channel_info/refs/heads/main/data/bt_epg_base.json';C=A.callRequestCookies(_B,B,payload=_A,params=_A,headers=_A,cookies=_A);A.GIT_BASE_EPG=json.loads(C.text)
	def JsonFile_Save(D,filename,dic):
		B=filename;A=False
		if B=='':return A
		try:C=open(B,'w',-1,'utf-8');json.dump(dic,C,indent=4,ensure_ascii=A);C.close()
		except:return A
		return True
	def Get_Now_Datetime(A):return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
	def xmlText(B,in_text):A=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;');return A
	def git_make_channel_list(C,OTT_LIST,EXCEPT_GROUP):
		B=[]
		for A in C.GIT_BASE_M3U:
			if A[_C]in OTT_LIST and A[_E]not in EXCEPT_GROUP:B.append(A)
		return B
	def git_make_epg_list(B,OTT_LIST,EXCEPT_GROUP):
		H='channelimg';G='channelnm';C=[];D=[]
		for(A,I)in B.GIT_BASE_EPG.items():
			if A not in B.GIT_CHANNEL_INFO:E='-';continue
			else:E=B.GIT_CHANNEL_INFO[A][_E]
			J=A.split('.')[0];F=A.split('.')[1];K=B.GIT_CHANNEL_INFO[A][G];L=B.GIT_CHANNEL_INFO[A][H]
			if F not in OTT_LIST:continue
			if E in EXCEPT_GROUP:continue
			M={_D:J,_C:F,G:K,H:L};C.append(M)
			for N in I:"\n\t\t\t\ttemp_list = {\n\t\t\t\t\t\t\t\t'channelid' : i_epg['channelid'],\n\t\t\t\t\t\t\t\t'ott'       : i_epg['ott'],\n\t\t\t\t\t\t\t\t'startTime' : i_epg['startTime'],\n\t\t\t\t\t\t\t\t'endTime'   : i_epg['endTime'],\n\t\t\t\t\t\t\t\t'title'     : i_epg['title'],\n\t\t\t\t}\n\t\t\t\t";D.append(N)
		return C,D