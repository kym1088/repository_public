_h='라디오/음악'
_g='channelimg'
_f='channelnm'
_e='ADD_EPG'
_d='DEL_M3U'
_c='-----------------'
_b='ott'
_a='channelid'
_Z='bc_mbc'
_Y='bc_kbs'
_X='icon'
_W='custom'
_V='list'
_U='int'
_T='XXX'
_S='bc_sbs'
_R='spotv'
_Q='tving'
_P='wavve'
_O=None
_N='string'
_M='ADD_M3U'
_L='sName'
_K='utf-8'
_J='all'
_I='true'
_H='utf8'
_G='sType'
_F='title'
_E='mode'
_D='type'
_C='func'
_B=True
_A=False
__author__='NightRain'
import os,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,sys,datetime,time,urllib
MAIN_GROUP=[{_F:'*** 간단설명 (개별 OTT 애드온 필수) ***',_E:_T},{_F:'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)',_E:_T},{_F:'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)',_E:_T},{_F:_c,_E:_T},{_F:'-> M3U 파일 초기화/삭제',_E:_d},{_F:'     - M3U 추가 (웨이브)',_E:_M,_G:_P,_L:'웨이브'},{_F:'     - M3U 추가 (티빙)',_E:_M,_G:_Q,_L:'티빙'},{_F:'     - M3U 추가 (스포티비)',_E:_M,_G:_R,_L:'스포티비'},{_F:'     - M3U 추가 (SBS)',_E:_M,_G:_S,_L:'SBS'},{_F:'     - M3U 추가 (사용자 m3u)',_E:_M,_G:_W,_L:'사용자 m3u 파일'},{_F:'-> M3U (삭제후 일괄생성)',_E:_M,_G:_J,_L:'전체'},{_F:_c,_E:_T},{_F:'-> EPG 생성 (삭제후 일괄생성)',_E:_e,_G:_J,_L:'전체'}]
INFO_CONVERT_KEY={_F:{_C:'setTitle',_D:_N},'plot':{_C:'setPlot',_D:_N},'mpaa':{_C:'setMpaa',_D:_N},'mediatype':{_C:'setMediaType',_D:_N},'tvshowtitle':{_C:'setTvShowTitle',_D:_N},'premiered':{_C:'setPremiered',_D:_N},'aired':{_C:'setFirstAired',_D:_N},'year':{_C:'setYear',_D:_U},'duration':{_C:'setDuration',_D:_U},'episode':{_C:'setEpisode',_D:_U},'season':{_C:'setSeason',_D:_U},'studio':{_C:'setStudios',_D:_V},'genre':{_C:'setGenres',_D:_V},'country':{_C:'setCountries',_D:_V},'cast':{_C:'setCast',_D:'actor'},'director':{_C:'setDirectors',_D:_V}}
__addon__=xbmcaddon.Addon()
__language__=__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
EPGDATE_FILE_NAME=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class BoritvRun:
	def __init__(self,in_addonurl,in_handle,in_params):self._addon_url=in_addonurl;self._addon_handle=in_handle;self.main_params=in_params;self.M3U_FILE_PATH='';self.M3U_FILE_NAME='';self.M3U_ONWAVVE=_A;self.M3U_ONTVING=_A;self.M3U_ONSPOTV=_A;self.M3U_BC_SBS=_A;self.M3U_PJY=_A;self.M3U_ONWAVVERADIO=_A;self.M3U_ONWAVVEHOME=_A;self.M3U_DISPLAYNM=_A;self.M3U_AUTORESTART=_A;self.M3U_CUSTOM_LIST=[];self.BoritvObj=Boritv()
	def addon_noti(self,sting):
		try:dialog=xbmcgui.Dialog();dialog.notification(__addonname__,sting)
		except:_O
	def addon_log(self,string):
		try:log_message=string.encode(_K,'ignore')
		except:log_message='addonException: addon_log'
		level=xbmc.LOGINFO;xbmc.log('[%s-%s]: %s'%(__addonid__,__version__,log_message),level=level)
	def get_keyboard_input(self,title):
		input_text=_O;kb=xbmc.Keyboard();kb.setHeading(title);xbmc.sleep(1000);kb.doModal()
		if kb.isConfirmed():input_text=kb.getText()
		return input_text
	def add_dir(self,label,sublabel='',img='',infoLabels=_O,isFolder=_B,params='',isLink=_A,ContextMenu=_O):
		url='%s?%s'%(self._addon_url,urllib.parse.urlencode(params))
		if sublabel:title='%s < %s >'%(label,sublabel)
		else:title=label
		if not img:img='DefaultFolder.png'
		listitem=xbmcgui.ListItem(title);listitem.setArt({'thumbnailImage':img,_X:img,'poster':img})
		if self.BoritvObj.KodiVersion>=20:
			if infoLabels:self.Set_InfoTag(listitem.getVideoInfoTag(),infoLabels)
		elif infoLabels:listitem.setInfo('Video',infoLabels)
		if not isFolder and not isLink:listitem.setProperty('IsPlayable',_I)
		if ContextMenu:listitem.addContextMenuItems(ContextMenu)
		xbmcplugin.addDirectoryItem(self._addon_handle,url,listitem,isFolder)
	def Set_InfoTag(self,video_InfoTag,infoLabels):
		for(key,value)in infoLabels.items():
			if INFO_CONVERT_KEY[key][_D]==_N:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_C])(value)
			elif INFO_CONVERT_KEY[key][_D]==_U:
				if type(value)==int:intValue=int(value)
				else:intValue=0
				getattr(video_InfoTag,INFO_CONVERT_KEY[key][_C])(intValue)
			elif INFO_CONVERT_KEY[key][_D]=='actor':
				if value!=[]:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_C])([xbmc.Actor(name)for name in value])
			elif INFO_CONVERT_KEY[key][_D]==_V:
				if type(value)==list:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_C])(value)
				else:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_C])([value])
	def make_M3u_Filename(self,tempyn=_A):
		if tempyn:return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
		else:return self.M3U_FILE_PATH+self.M3U_FILE_NAME+'.m3u'
	def make_Epg_Filename(self,tempyn=_A):
		if tempyn:return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
		else:return self.M3U_FILE_PATH+self.M3U_FILE_NAME+'.xml'
	def dp_Main_List(self):
		for main_group in MAIN_GROUP:
			title=main_group.get(_F);icon_img='';params={_E:main_group.get(_E),_G:main_group.get(_G),_L:main_group.get(_L)};infoLabels={_F:title,'plot':title}
			if main_group.get(_E)==_T:isFolder=_A;isLink=_B
			else:isFolder=_B;isLink=_A
			addYn=_B
			if main_group.get(_E)==_M:
				if main_group.get(_G)==_P and self.M3U_ONWAVVE==_A:addYn=_A
				if main_group.get(_G)==_Q and self.M3U_ONTVING==_A:addYn=_A
				if main_group.get(_G)==_R and self.M3U_ONSPOTV==_A:addYn=_A
				if main_group.get(_G)==_S and self.M3U_BC_SBS==_A:addYn=_A
				if main_group.get(_G)==_W and self.M3U_CUSTOM_LIST==[]:addYn=_A
			if addYn==_B:
				if _X in main_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',main_group.get(_X))
				self.add_dir(title,sublabel='',img=icon_img,infoLabels=infoLabels,isFolder=isFolder,params=params,isLink=isLink)
		if len(MAIN_GROUP)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_B)
	def dp_Delete_M3u(self,args):
		dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30903).encode(_H),__language__(30904).encode(_H))
		if ret==_A:sys.exit()
		filename=self.make_M3u_Filename(tempyn=_A)
		if xbmcvfs.exists(filename):
			if xbmcvfs.delete(filename)==_A:self.addon_noti(__language__(30910).encode(_K));return
		self.addon_noti(__language__(30905).encode(_K))
	def dp_MakeAdd_M3u(self,args):
		B='#EXTM3U\n';A='pjy';sType=args.get(_G);sName=args.get(_L);dialog=xbmcgui.Dialog();ret=dialog.yesno((sName+__language__(30906)).encode(_H),__language__(30907).encode(_H))
		if ret==_A:sys.exit()
		filename=self.make_M3u_Filename(tempyn=_B)
		if os.path.isfile(filename):os.remove(filename)
		if sType==_J:
			filename=self.make_M3u_Filename(tempyn=_A)
			if xbmcvfs.exists(filename):
				if xbmcvfs.delete(filename)==_A:self.addon_noti(__language__(30910).encode(_K));return
		else:
			asis_filename=self.make_M3u_Filename(tempyn=_A)
			if xbmcvfs.exists(asis_filename):tobe_filename=self.make_M3u_Filename(tempyn=_B);xbmcvfs.copy(asis_filename,tobe_filename)
		OTT_LIST=[];EXCEPT_GROUP=self.make_EexceptGroup_Wavve()
		if(sType==A or sType==_J)and self.M3U_PJY:OTT_LIST.append(A)
		if(sType==_P or sType==_J)and self.M3U_ONWAVVE:OTT_LIST.append(_P)
		if(sType==_Q or sType==_J)and self.M3U_ONTVING:OTT_LIST.append(_Q)
		if(sType==_R or sType==_J)and self.M3U_ONSPOTV:OTT_LIST.append(_R)
		if(sType==_S or sType==_J)and self.M3U_BC_SBS:OTT_LIST.append(_S);OTT_LIST.append(_Y);OTT_LIST.append(_Z)
		if len(OTT_LIST)==0 and self.M3U_CUSTOM_LIST==[]:self.addon_noti(__language__(30909).encode(_H));return
		channel_list=self.BoritvObj.git_make_channel_list(OTT_LIST,EXCEPT_GROUP)
		try:
			if len(channel_list)>0:
				filename=self.make_M3u_Filename(tempyn=_B)
				if os.path.isfile(filename):fp=open(filename,'a',-1,_K)
				else:fp=open(filename,'w',-1,_K);fp.write(B)
				for gn_list in channel_list:
					channelid=gn_list[_a];channelnm=gn_list[_f];channelimg=gn_list[_g];ott=gn_list[_b];tvgid='%s.%s'%(channelid,ott);channelgenre=gn_list['genrenm']
					if self.M3U_DISPLAYNM:channelnm='%s (%s)'%(channelnm,ott)
					if channelgenre==_h:m3uinfo='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(tvgid,channelnm,channelgenre,channelimg,channelnm)
					else:m3uinfo='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(tvgid,channelnm,channelgenre,channelimg,channelnm)
					if ott==_P:m3uurl='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%channelid
					elif ott==_Q:m3uurl='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%channelid
					elif ott==_R:m3uurl='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%channelid
					elif ott==_S:m3uurl='plugin://plugin.video.broadcastm/?mode=LIVE&company=sbs&channlCode=%s\n'%channelid
					elif ott==_Y:m3uurl='plugin://plugin.video.broadcastm/?mode=LIVE&company=kbs&channlCode=%s\n'%channelid
					elif ott==_Z:m3uurl='plugin://plugin.video.broadcastm/?mode=LIVE&company=mbc&channlCode=%s\n'%channelid
					elif ott==A:m3uurl='{}\n'.format(gn_list['channelurl'])
					fp.write(m3uinfo);fp.write(m3uurl)
				fp.close()
		except:self.addon_noti(__language__(30910).encode(_H));return
		try:
			if(sType==_W or sType==_J)and self.M3U_CUSTOM_LIST!=[]:
				filename=self.make_M3u_Filename(tempyn=_B)
				if os.path.isfile(filename):fp=open(filename,'a',-1,_K)
				else:fp=open(filename,'w',-1,_K);fp.write(B)
				for custom_file in self.M3U_CUSTOM_LIST:
					file_lines=self.customEpg_FileRead(custom_file)
					for i_line in file_lines:
						i_line=i_line.strip()
						if i_line not in['','#EXTM3U']:fp.write(i_line+'\n')
			fp.close()
		except:self.addon_noti(__language__(30910).encode(_H));return
		asis_filename=self.make_M3u_Filename(tempyn=_B);tobe_filename=self.make_M3u_Filename(tempyn=_A)
		if xbmcvfs.copy(asis_filename,tobe_filename):self.addon_noti((sName+' '+__language__(30908)).encode(_H))
		else:self.addon_noti(__language__(30910).encode(_K))
	def customEpg_FileList(self):
		file_list=[]
		if __addon__.getSetting('custom01on')==_I:file_list.append(__addon__.getSetting('custom01nm'))
		if __addon__.getSetting('custom02on')==_I:file_list.append(__addon__.getSetting('custom02nm'))
		if __addon__.getSetting('custom03on')==_I:file_list.append(__addon__.getSetting('custom03nm'))
		if __addon__.getSetting('custom04on')==_I:file_list.append(__addon__.getSetting('custom04nm'))
		if __addon__.getSetting('custom05on')==_I:file_list.append(__addon__.getSetting('custom05nm'))
		return file_list
	def customEpg_FileRead(self,source_filename):
		try:
			temp_filename=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
			if os.path.isfile(temp_filename):os.remove(temp_filename)
			xbmcvfs.copy(source_filename,temp_filename);fp=open(temp_filename,'r',-1,_K);lines=fp.readlines()
		except:return[]
		return lines
	def dp_Make_Epg(self,args):
		B='anything';A='N';sType=args.get(_G);sName=args.get(_L);sNoti=args.get('sNoti')
		if sNoti!=A:
			dialog=xbmcgui.Dialog();ret=dialog.yesno((sName+__language__(30911)).encode(_H),__language__(30907).encode(_H))
			if ret==_A:sys.exit()
		OTT_LIST=[];EXCEPT_GROUP=self.make_EexceptGroup_Wavve()
		if(sType==_P or sType==_J)and self.M3U_ONWAVVE:OTT_LIST.append(_P)
		if(sType==_Q or sType==_J)and self.M3U_ONTVING:OTT_LIST.append(_Q)
		if(sType==_R or sType==_J)and self.M3U_ONSPOTV:OTT_LIST.append(_R)
		if(sType==_S or sType==_J)and self.M3U_BC_SBS:OTT_LIST.append(_S);OTT_LIST.append(_Y);OTT_LIST.append(_Z)
		CH_LIST,EPG_LIST=self.BoritvObj.git_make_epg_list(OTT_LIST,EXCEPT_GROUP)
		if len(EPG_LIST)==0:
			if sNoti!=A:self.addon_noti(__language__(30909).encode(_H))
			return
		try:
			filename=self.make_Epg_Filename(tempyn=_B);fp=open(filename,'w',-1,_K);xmltext_1='<?xml version="1.0" encoding="UTF-8"?>\n';xmltext_2='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n';xmltext_3='<tv generator-info-name="boritv_epg">\n\n';xmltext_4='\n</tv>\n';fp.write(xmltext_1);fp.write(xmltext_2);fp.write(xmltext_3)
			for i_section in CH_LIST:temptext_1='  <channel id="%s.%s">\n'%(i_section.get(_a),i_section.get(_b));temptext_2='    <display-name>%s</display-name>\n'%i_section.get(_f);temptext_3='    <icon src="%s" />\n'%i_section.get(_g);temptext_4='  </channel>\n\n';fp.write(temptext_1);fp.write(temptext_2);fp.write(temptext_3);fp.write(temptext_4)
			for i_section in EPG_LIST:temptext_1='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(i_section.get('startTime'),i_section.get('endTime'),i_section.get(_a),i_section.get(_b));temptext_2='    <title lang="kr">%s</title>\n'%i_section.get(_F);temptext_3='  </programme>\n\n';fp.write(temptext_1);fp.write(temptext_2);fp.write(temptext_3)
			fp.write(xmltext_4);fp.close()
		except:
			if sNoti!=A:self.addon_noti(__language__(30910).encode(_H))
			return
		self.MakeEpg_SaveJson();asis_filename=self.make_Epg_Filename(tempyn=_B);tobe_filename=self.make_Epg_Filename(tempyn=_A)
		if xbmcvfs.copy(asis_filename,tobe_filename):
			if sNoti!=A:self.addon_noti((sName+' '+__language__(30912)).encode(_H))
		else:self.addon_noti(__language__(30910).encode(_K))
		try:
			if self.M3U_AUTORESTART:addon=xbmcaddon.Addon('pvr.iptvsimple');addon.setSetting(B,B)
		except:_O
	def make_EexceptGroup_Wavve(self):
		except_group=[]
		if self.M3U_ONWAVVERADIO==_A:except_group.append(_h)
		if self.M3U_ONWAVVEHOME==_A:except_group.append('홈쇼핑')
		return except_group
	def check_config(self):
		checkyn=_B;self.M3U_FILE_PATH=__addon__.getSetting('m3uFilepath').strip();self.M3U_FILE_NAME=__addon__.getSetting('m3uFilename').strip();self.M3U_ONWAVVE=_B if __addon__.getSetting('onWavve')==_I else _A;self.M3U_ONTVING=_B if __addon__.getSetting('onTvng')==_I else _A;self.M3U_ONSPOTV=_B if __addon__.getSetting('onSpotv')==_I else _A;self.M3U_BC_SBS=_B if __addon__.getSetting('onBroadSBS')==_I else _A;self.M3U_ONWAVVERADIO=_B if __addon__.getSetting('onWavveRadio')==_I else _A;self.M3U_ONWAVVEHOME=_B if __addon__.getSetting('onWavveHome')==_I else _A;self.M3U_DISPLAYNM=_B if __addon__.getSetting('displayOTTnm')==_I else _A;self.M3U_AUTORESTART=_B if __addon__.getSetting('autoRestart')==_I else _A;self.M3U_CUSTOM_LIST=self.customEpg_FileList()
		if self.M3U_FILE_PATH==''or self.M3U_FILE_NAME=='':checkyn=_A
		if self.M3U_ONWAVVE==_A and self.M3U_ONTVING==_A and self.M3U_ONSPOTV==_A and self.M3U_BC_SBS==_A:checkyn=_A
		if checkyn==_A:
			dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30901).encode(_H),__language__(30902).encode(_H))
			if ret==_B:__addon__.openSettings();sys.exit()
			else:sys.exit()
	def MakeEpg_SaveJson(self):
		json_data={'date_makeepg':self.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
		try:fp=open(EPGDATE_FILE_NAME,'w',-1,_K);json.dump(json_data,fp);fp.close()
		except Exception as exception:return
	def boritv_main(self):
		self.BoritvObj.KodiVersion=int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0]);mode=self.main_params.get(_E,_O);self.check_config()
		if mode is _O:self.dp_Main_List()
		elif mode==_d:self.dp_Delete_M3u(self.main_params)
		elif mode==_M:self.BoritvObj.INIT_INFO_LIST();self.dp_MakeAdd_M3u(self.main_params)
		elif mode==_e:self.BoritvObj.INIT_INFO_LIST();self.dp_Make_Epg(self.main_params)
		else:_O