_D='__main__'
_C='%Y%m%d%H%M%S'
_B='utf-8'
_A='%Y-%m-%d'
__author__='NightRain'
import json,time,datetime,random,os
try:import xbmc,xbmcaddon,xbmcvfs;RUNMODE='ADDON'
except:RUNMODE='SINGLE'
if RUNMODE=='ADDON':
	__addon__=xbmcaddon.Addon();__version__=__addon__.getAddonInfo('version');__addonid__=__addon__.getAddonInfo('id');__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
	def addon_log(string):A=str(string).encode(_B,'ignore');B=xbmc.LOGINFO;xbmc.log('[%s-%s]: %s'%(__addonid__,__version__,A),level=B)
	def addon_getautoepg():return True if __addon__.getSetting('autoEpg')=='true'else False
	def addon_epgupdate_confignm():return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
	def addon_log(string):print(string)
	def addon_getautoepg():return True
	def addon_epgupdate_confignm():return'd:\\job\\boritv_update.json'
class BoritvServiceRun:
	def __init__(A):A.START_INTERVAL=3000;A.INTERVAL=20;A.EPG_FILETAGNM='date_makeepg';A.EPG_MAKEDATE='-';A.EPG_WILL_TM=-1
	def Get_Now_Datetime(A):return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
	def MakeEpg_DateCheck(A):
		B='-'
		if A.EPG_MAKEDATE=='-':
			try:D=open(addon_epgupdate_confignm(),'r',-1,_B);E=json.load(D);D.close();B=E[A.EPG_FILETAGNM]
			except Exception as I:return 2
		else:B=A.EPG_MAKEDATE
		C=A.Get_Now_Datetime();F=(C-datetime.timedelta(days=1)).strftime(_A);G=C.strftime(_A);H=C.strftime('%H')
		if B==G:return-1
		if B==F and H=='00':return 30
		return 2
	def MakeEpg_RandomTm(A,mintm):B=mintm*60+random.randint(0,60);C=A.Get_Now_Datetime();D=(C+datetime.timedelta(seconds=B)).strftime(_C);return int(D)
	def MakeEpg_SaveJson(A):
		C={A.EPG_FILETAGNM:A.Get_Now_Datetime().strftime(_A)}
		try:B=open(addon_epgupdate_confignm(),'w',-1,_B);json.dump(C,B);B.close()
		except Exception as D:return
	def service_run(A):
		if addon_getautoepg()==False:return
		B=A.MakeEpg_DateCheck()
		if B<0:return
		if A.EPG_WILL_TM<0:A.EPG_WILL_TM=A.MakeEpg_RandomTm(B);addon_log('EPG_WILL_TM --> '+str(A.EPG_WILL_TM))
		else:
			C=A.Get_Now_Datetime()
			if A.EPG_WILL_TM<int(C.strftime(_C)):addon_log('make epg');xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")');A.MakeEpg_SaveJson();A.EPG_MAKEDATE=C.strftime(_A);A.EPG_WILL_TM=-1
			else:0
if __name__==_D:
	addon_log(_D);serviceObj=BoritvServiceRun();time.sleep(3)
	while True:time.sleep(serviceObj.INTERVAL);serviceObj.service_run()