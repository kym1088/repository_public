__author__="NightRain"
uzKNBPsFhUVglxGtAiYCydRkSbwfTq=object
uzKNBPsFhUVglxGtAiYCydRkSbwfTL=False
uzKNBPsFhUVglxGtAiYCydRkSbwfTJ=None
uzKNBPsFhUVglxGtAiYCydRkSbwfTn=True
uzKNBPsFhUVglxGtAiYCydRkSbwfTc=len
uzKNBPsFhUVglxGtAiYCydRkSbwfTe=str
uzKNBPsFhUVglxGtAiYCydRkSbwfHm=open
uzKNBPsFhUVglxGtAiYCydRkSbwfHO=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
uzKNBPsFhUVglxGtAiYCydRkSbwfmT=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
uzKNBPsFhUVglxGtAiYCydRkSbwfmH=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class uzKNBPsFhUVglxGtAiYCydRkSbwfmO(uzKNBPsFhUVglxGtAiYCydRkSbwfTq):
 def __init__(uzKNBPsFhUVglxGtAiYCydRkSbwfmI,uzKNBPsFhUVglxGtAiYCydRkSbwfmW,uzKNBPsFhUVglxGtAiYCydRkSbwfmv,uzKNBPsFhUVglxGtAiYCydRkSbwfmX):
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI._addon_url =uzKNBPsFhUVglxGtAiYCydRkSbwfmW
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI._addon_handle =uzKNBPsFhUVglxGtAiYCydRkSbwfmv
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.main_params =uzKNBPsFhUVglxGtAiYCydRkSbwfmX
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_FILE_PATH ='' 
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_FILE_NAME ='' 
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVE =uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONTVING =uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONSPOTV =uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVERADIO=uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVEHOME =uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONRELIGION =uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONSPOTVPAY =uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_DISPLAYNM =uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_AUTORESTART =uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.BoritvObj =srQbdkjqXBmvoHGtLRAVuNanDxElYc() 
 def addon_noti(uzKNBPsFhUVglxGtAiYCydRkSbwfmI,sting):
  try:
   uzKNBPsFhUVglxGtAiYCydRkSbwfmr=xbmcgui.Dialog()
   uzKNBPsFhUVglxGtAiYCydRkSbwfmr.notification(__addonname__,sting)
  except:
   uzKNBPsFhUVglxGtAiYCydRkSbwfTJ
 def addon_log(uzKNBPsFhUVglxGtAiYCydRkSbwfmI,string):
  try:
   uzKNBPsFhUVglxGtAiYCydRkSbwfmp=string.encode('utf-8','ignore')
  except:
   uzKNBPsFhUVglxGtAiYCydRkSbwfmp='addonException: addon_log'
  uzKNBPsFhUVglxGtAiYCydRkSbwfmM=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,uzKNBPsFhUVglxGtAiYCydRkSbwfmp),level=uzKNBPsFhUVglxGtAiYCydRkSbwfmM)
 def get_keyboard_input(uzKNBPsFhUVglxGtAiYCydRkSbwfmI,uzKNBPsFhUVglxGtAiYCydRkSbwfmo):
  uzKNBPsFhUVglxGtAiYCydRkSbwfmE=uzKNBPsFhUVglxGtAiYCydRkSbwfTJ
  kb=xbmc.Keyboard()
  kb.setHeading(uzKNBPsFhUVglxGtAiYCydRkSbwfmo)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   uzKNBPsFhUVglxGtAiYCydRkSbwfmE=kb.getText()
  return uzKNBPsFhUVglxGtAiYCydRkSbwfmE
 def add_dir(uzKNBPsFhUVglxGtAiYCydRkSbwfmI,label,sublabel='',img='',infoLabels=uzKNBPsFhUVglxGtAiYCydRkSbwfTJ,isFolder=uzKNBPsFhUVglxGtAiYCydRkSbwfTn,params=''):
  uzKNBPsFhUVglxGtAiYCydRkSbwfmD='%s?%s'%(uzKNBPsFhUVglxGtAiYCydRkSbwfmI._addon_url,urllib.parse.urlencode(params))
  if sublabel:uzKNBPsFhUVglxGtAiYCydRkSbwfmo='%s < %s >'%(label,sublabel)
  else: uzKNBPsFhUVglxGtAiYCydRkSbwfmo=label
  if not img:img='DefaultFolder.png'
  uzKNBPsFhUVglxGtAiYCydRkSbwfmj=xbmcgui.ListItem(uzKNBPsFhUVglxGtAiYCydRkSbwfmo)
  uzKNBPsFhUVglxGtAiYCydRkSbwfmj.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:uzKNBPsFhUVglxGtAiYCydRkSbwfmj.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:uzKNBPsFhUVglxGtAiYCydRkSbwfmj.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(uzKNBPsFhUVglxGtAiYCydRkSbwfmI._addon_handle,uzKNBPsFhUVglxGtAiYCydRkSbwfmD,uzKNBPsFhUVglxGtAiYCydRkSbwfmj,isFolder)
 def make_M3u_Filename(uzKNBPsFhUVglxGtAiYCydRkSbwfmI,tempyn=uzKNBPsFhUVglxGtAiYCydRkSbwfTL):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_FILE_PATH+uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(uzKNBPsFhUVglxGtAiYCydRkSbwfmI,tempyn=uzKNBPsFhUVglxGtAiYCydRkSbwfTL):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_FILE_PATH+uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_FILE_NAME+'.xml'
 def dp_Main_List(uzKNBPsFhUVglxGtAiYCydRkSbwfmI):
  for uzKNBPsFhUVglxGtAiYCydRkSbwfmQ in uzKNBPsFhUVglxGtAiYCydRkSbwfmT:
   uzKNBPsFhUVglxGtAiYCydRkSbwfmo=uzKNBPsFhUVglxGtAiYCydRkSbwfmQ.get('title')
   uzKNBPsFhUVglxGtAiYCydRkSbwfmq={'mode':uzKNBPsFhUVglxGtAiYCydRkSbwfmQ.get('mode'),'sType':uzKNBPsFhUVglxGtAiYCydRkSbwfmQ.get('sType'),'sName':uzKNBPsFhUVglxGtAiYCydRkSbwfmQ.get('sName')}
   if uzKNBPsFhUVglxGtAiYCydRkSbwfmQ.get('mode')=='XXX':
    uzKNBPsFhUVglxGtAiYCydRkSbwfmL=uzKNBPsFhUVglxGtAiYCydRkSbwfTL
   else:
    uzKNBPsFhUVglxGtAiYCydRkSbwfmL=uzKNBPsFhUVglxGtAiYCydRkSbwfTn
   uzKNBPsFhUVglxGtAiYCydRkSbwfmJ=uzKNBPsFhUVglxGtAiYCydRkSbwfTn
   if uzKNBPsFhUVglxGtAiYCydRkSbwfmQ.get('mode')=='ADD_M3U':
    if uzKNBPsFhUVglxGtAiYCydRkSbwfmQ.get('sType')=='wavve' and uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVE==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:uzKNBPsFhUVglxGtAiYCydRkSbwfmJ=uzKNBPsFhUVglxGtAiYCydRkSbwfTL
    if uzKNBPsFhUVglxGtAiYCydRkSbwfmQ.get('sType')=='tving' and uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONTVING==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:uzKNBPsFhUVglxGtAiYCydRkSbwfmJ=uzKNBPsFhUVglxGtAiYCydRkSbwfTL
    if uzKNBPsFhUVglxGtAiYCydRkSbwfmQ.get('sType')=='spotv' and uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONSPOTV==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:uzKNBPsFhUVglxGtAiYCydRkSbwfmJ=uzKNBPsFhUVglxGtAiYCydRkSbwfTL
   if uzKNBPsFhUVglxGtAiYCydRkSbwfmJ==uzKNBPsFhUVglxGtAiYCydRkSbwfTn:
    uzKNBPsFhUVglxGtAiYCydRkSbwfmI.add_dir(uzKNBPsFhUVglxGtAiYCydRkSbwfmo,sublabel='',img='',infoLabels=uzKNBPsFhUVglxGtAiYCydRkSbwfTJ,isFolder=uzKNBPsFhUVglxGtAiYCydRkSbwfmL,params=uzKNBPsFhUVglxGtAiYCydRkSbwfmq)
  if uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfmT)>0:xbmcplugin.endOfDirectory(uzKNBPsFhUVglxGtAiYCydRkSbwfmI._addon_handle,cacheToDisc=uzKNBPsFhUVglxGtAiYCydRkSbwfTn)
 def dp_Delete_M3u(uzKNBPsFhUVglxGtAiYCydRkSbwfmI,args):
  uzKNBPsFhUVglxGtAiYCydRkSbwfmr=xbmcgui.Dialog()
  uzKNBPsFhUVglxGtAiYCydRkSbwfmc=uzKNBPsFhUVglxGtAiYCydRkSbwfmr.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if uzKNBPsFhUVglxGtAiYCydRkSbwfmc==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:sys.exit()
  uzKNBPsFhUVglxGtAiYCydRkSbwfme=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.make_M3u_Filename(tempyn=uzKNBPsFhUVglxGtAiYCydRkSbwfTL)
  if xbmcvfs.exists(uzKNBPsFhUVglxGtAiYCydRkSbwfme):
   if xbmcvfs.delete(uzKNBPsFhUVglxGtAiYCydRkSbwfme)==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:
    uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_noti(__language__(30910).encode('utf-8'))
    return
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(uzKNBPsFhUVglxGtAiYCydRkSbwfmI,args):
  uzKNBPsFhUVglxGtAiYCydRkSbwfOm=args.get('sType')
  uzKNBPsFhUVglxGtAiYCydRkSbwfOT=args.get('sName')
  uzKNBPsFhUVglxGtAiYCydRkSbwfmr=xbmcgui.Dialog()
  uzKNBPsFhUVglxGtAiYCydRkSbwfmc=uzKNBPsFhUVglxGtAiYCydRkSbwfmr.yesno((uzKNBPsFhUVglxGtAiYCydRkSbwfOT+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if uzKNBPsFhUVglxGtAiYCydRkSbwfmc==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:sys.exit()
  uzKNBPsFhUVglxGtAiYCydRkSbwfOH =[]
  uzKNBPsFhUVglxGtAiYCydRkSbwfOI =[]
  if uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='all':
   uzKNBPsFhUVglxGtAiYCydRkSbwfme=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.make_M3u_Filename(tempyn=uzKNBPsFhUVglxGtAiYCydRkSbwfTn)
   if os.path.isfile(uzKNBPsFhUVglxGtAiYCydRkSbwfme):os.remove(uzKNBPsFhUVglxGtAiYCydRkSbwfme)
   uzKNBPsFhUVglxGtAiYCydRkSbwfme=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.make_M3u_Filename(tempyn=uzKNBPsFhUVglxGtAiYCydRkSbwfTL)
   if xbmcvfs.exists(uzKNBPsFhUVglxGtAiYCydRkSbwfme):
    if xbmcvfs.delete(uzKNBPsFhUVglxGtAiYCydRkSbwfme)==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:
     uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_noti(__language__(30910).encode('utf-8'))
     return
  if(uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='wavve' or uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='all')and uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVE:
   uzKNBPsFhUVglxGtAiYCydRkSbwfOW=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.BoritvObj.Get_ChannelList_Wavve(exceptGroup=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.make_EexceptGroup_Wavve())
   if uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfOW)!=0:uzKNBPsFhUVglxGtAiYCydRkSbwfOH.extend(uzKNBPsFhUVglxGtAiYCydRkSbwfOW)
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_log('wavve cnt ----> '+uzKNBPsFhUVglxGtAiYCydRkSbwfTe(uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfOW)))
  if(uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='tving' or uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='all')and uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONTVING:
   uzKNBPsFhUVglxGtAiYCydRkSbwfOW=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.BoritvObj.Get_ChannelList_Tving()
   if uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfOW)!=0:uzKNBPsFhUVglxGtAiYCydRkSbwfOH.extend(uzKNBPsFhUVglxGtAiYCydRkSbwfOW)
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_log('tving cnt ----> '+uzKNBPsFhUVglxGtAiYCydRkSbwfTe(uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfOW)))
  if(uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='spotv' or uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='all')and uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONSPOTV:
   uzKNBPsFhUVglxGtAiYCydRkSbwfOW=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.BoritvObj.Get_ChannelList_Spotv(payyn=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONSPOTVPAY)
   if uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfOW)!=0:uzKNBPsFhUVglxGtAiYCydRkSbwfOH.extend(uzKNBPsFhUVglxGtAiYCydRkSbwfOW)
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_log('spotv cnt ----> '+uzKNBPsFhUVglxGtAiYCydRkSbwfTe(uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfOW)))
  if uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfOH)==0:
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_noti(__language__(30909).encode('utf8'))
   return
  for uzKNBPsFhUVglxGtAiYCydRkSbwfOv in uzKNBPsFhUVglxGtAiYCydRkSbwfmI.BoritvObj.INIT_GENRESORT:
   for uzKNBPsFhUVglxGtAiYCydRkSbwfOX in uzKNBPsFhUVglxGtAiYCydRkSbwfOH:
    if uzKNBPsFhUVglxGtAiYCydRkSbwfOX['genrenm']==uzKNBPsFhUVglxGtAiYCydRkSbwfOv:
     uzKNBPsFhUVglxGtAiYCydRkSbwfOI.append(uzKNBPsFhUVglxGtAiYCydRkSbwfOX)
  for uzKNBPsFhUVglxGtAiYCydRkSbwfOX in uzKNBPsFhUVglxGtAiYCydRkSbwfOH:
   if uzKNBPsFhUVglxGtAiYCydRkSbwfOX['genrenm']not in uzKNBPsFhUVglxGtAiYCydRkSbwfmI.BoritvObj.INIT_GENRESORT:
    uzKNBPsFhUVglxGtAiYCydRkSbwfOI.append(uzKNBPsFhUVglxGtAiYCydRkSbwfOX)
  try:
   uzKNBPsFhUVglxGtAiYCydRkSbwfme=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.make_M3u_Filename(tempyn=uzKNBPsFhUVglxGtAiYCydRkSbwfTn)
   if os.path.isfile(uzKNBPsFhUVglxGtAiYCydRkSbwfme):
    fp=uzKNBPsFhUVglxGtAiYCydRkSbwfHm(uzKNBPsFhUVglxGtAiYCydRkSbwfme,'a',-1,'utf-8')
   else:
    fp=uzKNBPsFhUVglxGtAiYCydRkSbwfHm(uzKNBPsFhUVglxGtAiYCydRkSbwfme,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for uzKNBPsFhUVglxGtAiYCydRkSbwfOa in uzKNBPsFhUVglxGtAiYCydRkSbwfOI:
    uzKNBPsFhUVglxGtAiYCydRkSbwfOr =uzKNBPsFhUVglxGtAiYCydRkSbwfOa['channelid']
    uzKNBPsFhUVglxGtAiYCydRkSbwfOp =uzKNBPsFhUVglxGtAiYCydRkSbwfOa['channelnm']
    uzKNBPsFhUVglxGtAiYCydRkSbwfOM=uzKNBPsFhUVglxGtAiYCydRkSbwfOa['channelimg']
    uzKNBPsFhUVglxGtAiYCydRkSbwfOE =uzKNBPsFhUVglxGtAiYCydRkSbwfOa['ott']
    uzKNBPsFhUVglxGtAiYCydRkSbwfOD ='%s.%s'%(uzKNBPsFhUVglxGtAiYCydRkSbwfOr,uzKNBPsFhUVglxGtAiYCydRkSbwfOE)
    uzKNBPsFhUVglxGtAiYCydRkSbwfOo=uzKNBPsFhUVglxGtAiYCydRkSbwfOa['genrenm']
    if uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_DISPLAYNM:
     uzKNBPsFhUVglxGtAiYCydRkSbwfOp='%s (%s)'%(uzKNBPsFhUVglxGtAiYCydRkSbwfOp,uzKNBPsFhUVglxGtAiYCydRkSbwfOE)
    if uzKNBPsFhUVglxGtAiYCydRkSbwfOo=='라디오/음악':
     uzKNBPsFhUVglxGtAiYCydRkSbwfOj='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(uzKNBPsFhUVglxGtAiYCydRkSbwfOD,uzKNBPsFhUVglxGtAiYCydRkSbwfOp,uzKNBPsFhUVglxGtAiYCydRkSbwfOo,uzKNBPsFhUVglxGtAiYCydRkSbwfOM,uzKNBPsFhUVglxGtAiYCydRkSbwfOp)
    else:
     uzKNBPsFhUVglxGtAiYCydRkSbwfOj='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(uzKNBPsFhUVglxGtAiYCydRkSbwfOD,uzKNBPsFhUVglxGtAiYCydRkSbwfOp,uzKNBPsFhUVglxGtAiYCydRkSbwfOo,uzKNBPsFhUVglxGtAiYCydRkSbwfOM,uzKNBPsFhUVglxGtAiYCydRkSbwfOp)
    if uzKNBPsFhUVglxGtAiYCydRkSbwfOE=='wavve':
     uzKNBPsFhUVglxGtAiYCydRkSbwfOQ ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(uzKNBPsFhUVglxGtAiYCydRkSbwfOr)
    elif uzKNBPsFhUVglxGtAiYCydRkSbwfOE=='tving':
     uzKNBPsFhUVglxGtAiYCydRkSbwfOQ ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(uzKNBPsFhUVglxGtAiYCydRkSbwfOr)
    elif uzKNBPsFhUVglxGtAiYCydRkSbwfOE=='spotv':
     uzKNBPsFhUVglxGtAiYCydRkSbwfOQ ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(uzKNBPsFhUVglxGtAiYCydRkSbwfOr)
    fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfOj)
    fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfOQ)
   fp.close()
  except:
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_noti(__language__(30910).encode('utf8'))
   return
  uzKNBPsFhUVglxGtAiYCydRkSbwfOq=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.make_M3u_Filename(tempyn=uzKNBPsFhUVglxGtAiYCydRkSbwfTn)
  uzKNBPsFhUVglxGtAiYCydRkSbwfOL=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.make_M3u_Filename(tempyn=uzKNBPsFhUVglxGtAiYCydRkSbwfTL)
  if xbmcvfs.copy(uzKNBPsFhUVglxGtAiYCydRkSbwfOq,uzKNBPsFhUVglxGtAiYCydRkSbwfOL):
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_noti((uzKNBPsFhUVglxGtAiYCydRkSbwfOT+' '+__language__(30908)).encode('utf8'))
  else:
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_noti(__language__(30910).encode('utf-8'))
 def dp_Make_Epg(uzKNBPsFhUVglxGtAiYCydRkSbwfmI,args):
  uzKNBPsFhUVglxGtAiYCydRkSbwfOm=args.get('sType')
  uzKNBPsFhUVglxGtAiYCydRkSbwfOT=args.get('sName')
  uzKNBPsFhUVglxGtAiYCydRkSbwfOJ=args.get('sNoti')
  if uzKNBPsFhUVglxGtAiYCydRkSbwfOJ!='N':
   uzKNBPsFhUVglxGtAiYCydRkSbwfmr=xbmcgui.Dialog()
   uzKNBPsFhUVglxGtAiYCydRkSbwfmc=uzKNBPsFhUVglxGtAiYCydRkSbwfmr.yesno((uzKNBPsFhUVglxGtAiYCydRkSbwfOT+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if uzKNBPsFhUVglxGtAiYCydRkSbwfmc==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:sys.exit()
  uzKNBPsFhUVglxGtAiYCydRkSbwfOn=[]
  uzKNBPsFhUVglxGtAiYCydRkSbwfOc=[]
  if(uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='wavve' or uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='all')and uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVE:
   uzKNBPsFhUVglxGtAiYCydRkSbwfOe,uzKNBPsFhUVglxGtAiYCydRkSbwfTm=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.make_EexceptGroup_Wavve())
   if uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfTm)!=0:
    uzKNBPsFhUVglxGtAiYCydRkSbwfOn.extend(uzKNBPsFhUVglxGtAiYCydRkSbwfOe)
    uzKNBPsFhUVglxGtAiYCydRkSbwfOc.extend(uzKNBPsFhUVglxGtAiYCydRkSbwfTm)
  if(uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='tving' or uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='all')and uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONTVING:
   uzKNBPsFhUVglxGtAiYCydRkSbwfOe,uzKNBPsFhUVglxGtAiYCydRkSbwfTm=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.BoritvObj.Get_EpgInfo_Tving()
   if uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfTm)!=0:
    uzKNBPsFhUVglxGtAiYCydRkSbwfOn.extend(uzKNBPsFhUVglxGtAiYCydRkSbwfOe)
    uzKNBPsFhUVglxGtAiYCydRkSbwfOc.extend(uzKNBPsFhUVglxGtAiYCydRkSbwfTm)
  if(uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='spotv' or uzKNBPsFhUVglxGtAiYCydRkSbwfOm=='all')and uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONSPOTV:
   uzKNBPsFhUVglxGtAiYCydRkSbwfOe,uzKNBPsFhUVglxGtAiYCydRkSbwfTm=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.BoritvObj.Get_EpgInfo_Spotv(payyn=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONSPOTVPAY)
   if uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfTm)!=0:
    uzKNBPsFhUVglxGtAiYCydRkSbwfOn.extend(uzKNBPsFhUVglxGtAiYCydRkSbwfOe)
    uzKNBPsFhUVglxGtAiYCydRkSbwfOc.extend(uzKNBPsFhUVglxGtAiYCydRkSbwfTm)
  if uzKNBPsFhUVglxGtAiYCydRkSbwfTc(uzKNBPsFhUVglxGtAiYCydRkSbwfOc)==0:
   if uzKNBPsFhUVglxGtAiYCydRkSbwfOJ!='N':uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   uzKNBPsFhUVglxGtAiYCydRkSbwfme=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.make_Epg_Filename(tempyn=uzKNBPsFhUVglxGtAiYCydRkSbwfTn)
   fp=uzKNBPsFhUVglxGtAiYCydRkSbwfHm(uzKNBPsFhUVglxGtAiYCydRkSbwfme,'w',-1,'utf-8')
   uzKNBPsFhUVglxGtAiYCydRkSbwfTO='<?xml version="1.0" encoding="UTF-8"?>\n'
   uzKNBPsFhUVglxGtAiYCydRkSbwfTH='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   uzKNBPsFhUVglxGtAiYCydRkSbwfTI='<tv generator-info-name="boritv_epg">\n\n'
   uzKNBPsFhUVglxGtAiYCydRkSbwfTW='\n</tv>\n'
   fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfTO)
   fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfTH)
   fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfTI)
   for uzKNBPsFhUVglxGtAiYCydRkSbwfTv in uzKNBPsFhUVglxGtAiYCydRkSbwfOn:
    uzKNBPsFhUVglxGtAiYCydRkSbwfTX='  <channel id="%s.%s">\n' %(uzKNBPsFhUVglxGtAiYCydRkSbwfTv.get('channelid'),uzKNBPsFhUVglxGtAiYCydRkSbwfTv.get('ott'))
    uzKNBPsFhUVglxGtAiYCydRkSbwfTa='    <display-name>%s</display-name>\n'%(uzKNBPsFhUVglxGtAiYCydRkSbwfTv.get('channelnm'))
    uzKNBPsFhUVglxGtAiYCydRkSbwfTr='    <icon src="%s" />\n' %(uzKNBPsFhUVglxGtAiYCydRkSbwfTv.get('channelimg'))
    uzKNBPsFhUVglxGtAiYCydRkSbwfTp='  </channel>\n\n'
    fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfTX)
    fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfTa)
    fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfTr)
    fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfTp)
   for uzKNBPsFhUVglxGtAiYCydRkSbwfTv in uzKNBPsFhUVglxGtAiYCydRkSbwfOc:
    uzKNBPsFhUVglxGtAiYCydRkSbwfTX='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(uzKNBPsFhUVglxGtAiYCydRkSbwfTv.get('startTime'),uzKNBPsFhUVglxGtAiYCydRkSbwfTv.get('endTime'),uzKNBPsFhUVglxGtAiYCydRkSbwfTv.get('channelid'),uzKNBPsFhUVglxGtAiYCydRkSbwfTv.get('ott'))
    uzKNBPsFhUVglxGtAiYCydRkSbwfTa='    <title lang="kr">%s</title>\n' %(uzKNBPsFhUVglxGtAiYCydRkSbwfTv.get('title'))
    uzKNBPsFhUVglxGtAiYCydRkSbwfTr='  </programme>\n\n'
    fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfTX)
    fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfTa)
    fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfTr)
   fp.write(uzKNBPsFhUVglxGtAiYCydRkSbwfTW)
   fp.close()
  except:
   if uzKNBPsFhUVglxGtAiYCydRkSbwfOJ!='N':uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_noti(__language__(30910).encode('utf8'))
   return
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.MakeEpg_SaveJson()
  uzKNBPsFhUVglxGtAiYCydRkSbwfOq=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.make_Epg_Filename(tempyn=uzKNBPsFhUVglxGtAiYCydRkSbwfTn)
  uzKNBPsFhUVglxGtAiYCydRkSbwfOL=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.make_Epg_Filename(tempyn=uzKNBPsFhUVglxGtAiYCydRkSbwfTL)
  if xbmcvfs.copy(uzKNBPsFhUVglxGtAiYCydRkSbwfOq,uzKNBPsFhUVglxGtAiYCydRkSbwfOL):
   if uzKNBPsFhUVglxGtAiYCydRkSbwfOJ!='N':uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_noti((uzKNBPsFhUVglxGtAiYCydRkSbwfOT+' '+__language__(30912)).encode('utf8'))
  else:
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_AUTORESTART:
    uzKNBPsFhUVglxGtAiYCydRkSbwfTM=xbmcaddon.Addon('pvr.iptvsimple')
    uzKNBPsFhUVglxGtAiYCydRkSbwfTM.setSetting('anything','anything')
  except:
   uzKNBPsFhUVglxGtAiYCydRkSbwfTJ 
 def make_EexceptGroup_Wavve(uzKNBPsFhUVglxGtAiYCydRkSbwfmI):
  uzKNBPsFhUVglxGtAiYCydRkSbwfTE=[]
  if uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVERADIO==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:
   uzKNBPsFhUVglxGtAiYCydRkSbwfTE.append('라디오/음악')
  if uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVEHOME==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:
   uzKNBPsFhUVglxGtAiYCydRkSbwfTE.append('홈쇼핑')
  if uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONRELIGION==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:
   uzKNBPsFhUVglxGtAiYCydRkSbwfTE.append('종교')
  return uzKNBPsFhUVglxGtAiYCydRkSbwfTE
 def get_radio_list(uzKNBPsFhUVglxGtAiYCydRkSbwfmI):
  if uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVERADIO==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:return[]
  uzKNBPsFhUVglxGtAiYCydRkSbwfTD=[{'broadcastid':'46584','genre':'10'}]
  return uzKNBPsFhUVglxGtAiYCydRkSbwfmI.BoritvObj.Get_ChannelList_WavveExcept(uzKNBPsFhUVglxGtAiYCydRkSbwfTD)
 def check_config(uzKNBPsFhUVglxGtAiYCydRkSbwfmI):
  uzKNBPsFhUVglxGtAiYCydRkSbwfTo=uzKNBPsFhUVglxGtAiYCydRkSbwfTn
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVE =uzKNBPsFhUVglxGtAiYCydRkSbwfTn if __addon__.getSetting('onWavve')=='true' else uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONTVING =uzKNBPsFhUVglxGtAiYCydRkSbwfTn if __addon__.getSetting('onTvng')=='true' else uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONSPOTV =uzKNBPsFhUVglxGtAiYCydRkSbwfTn if __addon__.getSetting('onSpotv')=='true' else uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVERADIO=uzKNBPsFhUVglxGtAiYCydRkSbwfTn if __addon__.getSetting('onWavveRadio')=='true' else uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVEHOME =uzKNBPsFhUVglxGtAiYCydRkSbwfTn if __addon__.getSetting('onWavveHome')=='true' else uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONRELIGION =uzKNBPsFhUVglxGtAiYCydRkSbwfTn if __addon__.getSetting('onWavveReligion')=='true' else uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONSPOTVPAY =uzKNBPsFhUVglxGtAiYCydRkSbwfTn if __addon__.getSetting('onSpotvPay')=='true' else uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_DISPLAYNM =uzKNBPsFhUVglxGtAiYCydRkSbwfTn if __addon__.getSetting('displayOTTnm')=='true' else uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_AUTORESTART =uzKNBPsFhUVglxGtAiYCydRkSbwfTn if __addon__.getSetting('autoRestart')=='true' else uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  if uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_FILE_PATH=='' or uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_FILE_NAME=='':uzKNBPsFhUVglxGtAiYCydRkSbwfTo=uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  if uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONWAVVE==uzKNBPsFhUVglxGtAiYCydRkSbwfTL and uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONTVING=='' and uzKNBPsFhUVglxGtAiYCydRkSbwfmI.M3U_ONSPOTV=='':uzKNBPsFhUVglxGtAiYCydRkSbwfTo=uzKNBPsFhUVglxGtAiYCydRkSbwfTL
  if uzKNBPsFhUVglxGtAiYCydRkSbwfTo==uzKNBPsFhUVglxGtAiYCydRkSbwfTL:
   uzKNBPsFhUVglxGtAiYCydRkSbwfmr=xbmcgui.Dialog()
   uzKNBPsFhUVglxGtAiYCydRkSbwfmc=uzKNBPsFhUVglxGtAiYCydRkSbwfmr.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if uzKNBPsFhUVglxGtAiYCydRkSbwfmc==uzKNBPsFhUVglxGtAiYCydRkSbwfTn:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(uzKNBPsFhUVglxGtAiYCydRkSbwfmI):
  uzKNBPsFhUVglxGtAiYCydRkSbwfTj={'date_makeepg':uzKNBPsFhUVglxGtAiYCydRkSbwfmI.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=uzKNBPsFhUVglxGtAiYCydRkSbwfHm(uzKNBPsFhUVglxGtAiYCydRkSbwfmH,'w',-1,'utf-8')
   json.dump(uzKNBPsFhUVglxGtAiYCydRkSbwfTj,fp)
   fp.close()
  except uzKNBPsFhUVglxGtAiYCydRkSbwfHO as exception:
   return
 def boritv_main(uzKNBPsFhUVglxGtAiYCydRkSbwfmI):
  uzKNBPsFhUVglxGtAiYCydRkSbwfTQ=uzKNBPsFhUVglxGtAiYCydRkSbwfmI.main_params.get('mode',uzKNBPsFhUVglxGtAiYCydRkSbwfTJ)
  uzKNBPsFhUVglxGtAiYCydRkSbwfmI.check_config()
  if uzKNBPsFhUVglxGtAiYCydRkSbwfTQ is uzKNBPsFhUVglxGtAiYCydRkSbwfTJ:
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.dp_Main_List()
  elif uzKNBPsFhUVglxGtAiYCydRkSbwfTQ=='DEL_M3U':
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.dp_Delete_M3u(uzKNBPsFhUVglxGtAiYCydRkSbwfmI.main_params)
  elif uzKNBPsFhUVglxGtAiYCydRkSbwfTQ=='ADD_M3U':
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.dp_MakeAdd_M3u(uzKNBPsFhUVglxGtAiYCydRkSbwfmI.main_params)
  elif uzKNBPsFhUVglxGtAiYCydRkSbwfTQ=='ADD_EPG':
   uzKNBPsFhUVglxGtAiYCydRkSbwfmI.dp_Make_Epg(uzKNBPsFhUVglxGtAiYCydRkSbwfmI.main_params)
  else:
   uzKNBPsFhUVglxGtAiYCydRkSbwfTJ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
