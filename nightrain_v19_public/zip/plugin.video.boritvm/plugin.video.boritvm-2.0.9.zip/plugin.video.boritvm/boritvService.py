__author__="NightRain"
import os
import sys
import xbmcaddon,xbmcvfs
import urllib
__cwd__=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
__lib__=os.path.join(__cwd__,'resources','lib')
sys.path.append(__lib__)
from boritvServiceRun import*
RLbtlQNxoqidCfABIHThJjrmcYPKpU=xbmc.Monitor()
RLbtlQNxoqidCfABIHThJjrmcYPKpO=DQtlgLyvYbIJXTarRzhqnHdGjEFmsC()
xbmc.sleep(RLbtlQNxoqidCfABIHThJjrmcYPKpO.START_INTERVAL)
while not RLbtlQNxoqidCfABIHThJjrmcYPKpU.abortRequested():
 if RLbtlQNxoqidCfABIHThJjrmcYPKpU.waitForAbort(RLbtlQNxoqidCfABIHThJjrmcYPKpO.INTERVAL):
  break
 RLbtlQNxoqidCfABIHThJjrmcYPKpO.service_run()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
