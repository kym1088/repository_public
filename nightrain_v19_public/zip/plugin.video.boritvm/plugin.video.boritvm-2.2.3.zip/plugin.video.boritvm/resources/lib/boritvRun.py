__author__="NightRain"
JUrFzIGEulStLHwidvMOpfPhxXkcKa=object
JUrFzIGEulStLHwidvMOpfPhxXkcKW=False
JUrFzIGEulStLHwidvMOpfPhxXkcKo=None
JUrFzIGEulStLHwidvMOpfPhxXkcKB=True
JUrFzIGEulStLHwidvMOpfPhxXkcKy=getattr
JUrFzIGEulStLHwidvMOpfPhxXkcKT=type
JUrFzIGEulStLHwidvMOpfPhxXkcKs=int
JUrFzIGEulStLHwidvMOpfPhxXkcKn=list
JUrFzIGEulStLHwidvMOpfPhxXkcKV=len
JUrFzIGEulStLHwidvMOpfPhxXkcKY=str
JUrFzIGEulStLHwidvMOpfPhxXkcKQ=open
JUrFzIGEulStLHwidvMOpfPhxXkcKD=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
JUrFzIGEulStLHwidvMOpfPhxXkcej=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'     - M3U 추가 (삼성tv 플러스)','mode':'ADD_M3U','sType':'samsung','sName':'삼성TV 플러스'},{'title':'     - M3U 추가 (사용자 m3u)','mode':'ADD_M3U','sType':'custom','sName':'사용자 m3u 파일'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
JUrFzIGEulStLHwidvMOpfPhxXkceK={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
JUrFzIGEulStLHwidvMOpfPhxXkceC=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class JUrFzIGEulStLHwidvMOpfPhxXkceN(JUrFzIGEulStLHwidvMOpfPhxXkcKa):
 def __init__(JUrFzIGEulStLHwidvMOpfPhxXkceR,JUrFzIGEulStLHwidvMOpfPhxXkceA,JUrFzIGEulStLHwidvMOpfPhxXkceg,JUrFzIGEulStLHwidvMOpfPhxXkcea):
  JUrFzIGEulStLHwidvMOpfPhxXkceR._addon_url =JUrFzIGEulStLHwidvMOpfPhxXkceA
  JUrFzIGEulStLHwidvMOpfPhxXkceR._addon_handle =JUrFzIGEulStLHwidvMOpfPhxXkceg
  JUrFzIGEulStLHwidvMOpfPhxXkceR.main_params =JUrFzIGEulStLHwidvMOpfPhxXkcea
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_FILE_PATH ='' 
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_FILE_NAME ='' 
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVE =JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONTVING =JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSPOTV =JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSAMSUNG =JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVERADIO =JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVEHOME =JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONRELIGION =JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSPOTVPAY =JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSAMSUNGHOME=JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_DISPLAYNM =JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_AUTORESTART =JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_CUSTOM_LIST =[]
  JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj =srPCUmafQyoYXAjhBJDqEKiVlLWupz() 
 def addon_noti(JUrFzIGEulStLHwidvMOpfPhxXkceR,sting):
  try:
   JUrFzIGEulStLHwidvMOpfPhxXkceo=xbmcgui.Dialog()
   JUrFzIGEulStLHwidvMOpfPhxXkceo.notification(__addonname__,sting)
  except:
   JUrFzIGEulStLHwidvMOpfPhxXkcKo
 def addon_log(JUrFzIGEulStLHwidvMOpfPhxXkceR,string):
  try:
   JUrFzIGEulStLHwidvMOpfPhxXkceB=string.encode('utf-8','ignore')
  except:
   JUrFzIGEulStLHwidvMOpfPhxXkceB='addonException: addon_log'
  JUrFzIGEulStLHwidvMOpfPhxXkcey=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,JUrFzIGEulStLHwidvMOpfPhxXkceB),level=JUrFzIGEulStLHwidvMOpfPhxXkcey)
 def get_keyboard_input(JUrFzIGEulStLHwidvMOpfPhxXkceR,JUrFzIGEulStLHwidvMOpfPhxXkcen):
  JUrFzIGEulStLHwidvMOpfPhxXkceT=JUrFzIGEulStLHwidvMOpfPhxXkcKo
  kb=xbmc.Keyboard()
  kb.setHeading(JUrFzIGEulStLHwidvMOpfPhxXkcen)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   JUrFzIGEulStLHwidvMOpfPhxXkceT=kb.getText()
  return JUrFzIGEulStLHwidvMOpfPhxXkceT
 def add_dir(JUrFzIGEulStLHwidvMOpfPhxXkceR,label,sublabel='',img='',infoLabels=JUrFzIGEulStLHwidvMOpfPhxXkcKo,isFolder=JUrFzIGEulStLHwidvMOpfPhxXkcKB,params='',isLink=JUrFzIGEulStLHwidvMOpfPhxXkcKW,ContextMenu=JUrFzIGEulStLHwidvMOpfPhxXkcKo):
  JUrFzIGEulStLHwidvMOpfPhxXkces='%s?%s'%(JUrFzIGEulStLHwidvMOpfPhxXkceR._addon_url,urllib.parse.urlencode(params))
  if sublabel:JUrFzIGEulStLHwidvMOpfPhxXkcen='%s < %s >'%(label,sublabel)
  else: JUrFzIGEulStLHwidvMOpfPhxXkcen=label
  if not img:img='DefaultFolder.png'
  JUrFzIGEulStLHwidvMOpfPhxXkceV=xbmcgui.ListItem(JUrFzIGEulStLHwidvMOpfPhxXkcen)
  JUrFzIGEulStLHwidvMOpfPhxXkceV.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.KodiVersion>=20:
   if infoLabels:JUrFzIGEulStLHwidvMOpfPhxXkceR.Set_InfoTag(JUrFzIGEulStLHwidvMOpfPhxXkceV.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:JUrFzIGEulStLHwidvMOpfPhxXkceV.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   JUrFzIGEulStLHwidvMOpfPhxXkceV.setProperty('IsPlayable','true')
  if ContextMenu:JUrFzIGEulStLHwidvMOpfPhxXkceV.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(JUrFzIGEulStLHwidvMOpfPhxXkceR._addon_handle,JUrFzIGEulStLHwidvMOpfPhxXkces,JUrFzIGEulStLHwidvMOpfPhxXkceV,isFolder)
 def Set_InfoTag(JUrFzIGEulStLHwidvMOpfPhxXkceR,video_InfoTag:xbmc.InfoTagVideo,JUrFzIGEulStLHwidvMOpfPhxXkceb):
  for JUrFzIGEulStLHwidvMOpfPhxXkceY,value in JUrFzIGEulStLHwidvMOpfPhxXkceb.items():
   if JUrFzIGEulStLHwidvMOpfPhxXkceK[JUrFzIGEulStLHwidvMOpfPhxXkceY]['type']=='string':
    JUrFzIGEulStLHwidvMOpfPhxXkcKy(video_InfoTag,JUrFzIGEulStLHwidvMOpfPhxXkceK[JUrFzIGEulStLHwidvMOpfPhxXkceY]['func'])(value)
   elif JUrFzIGEulStLHwidvMOpfPhxXkceK[JUrFzIGEulStLHwidvMOpfPhxXkceY]['type']=='int':
    if JUrFzIGEulStLHwidvMOpfPhxXkcKT(value)==JUrFzIGEulStLHwidvMOpfPhxXkcKs:
     JUrFzIGEulStLHwidvMOpfPhxXkceQ=JUrFzIGEulStLHwidvMOpfPhxXkcKs(value)
    else:
     JUrFzIGEulStLHwidvMOpfPhxXkceQ=0
    JUrFzIGEulStLHwidvMOpfPhxXkcKy(video_InfoTag,JUrFzIGEulStLHwidvMOpfPhxXkceK[JUrFzIGEulStLHwidvMOpfPhxXkceY]['func'])(JUrFzIGEulStLHwidvMOpfPhxXkceQ)
   elif JUrFzIGEulStLHwidvMOpfPhxXkceK[JUrFzIGEulStLHwidvMOpfPhxXkceY]['type']=='actor':
    if value!=[]:
     JUrFzIGEulStLHwidvMOpfPhxXkcKy(video_InfoTag,JUrFzIGEulStLHwidvMOpfPhxXkceK[JUrFzIGEulStLHwidvMOpfPhxXkceY]['func'])([xbmc.Actor(name)for name in value])
   elif JUrFzIGEulStLHwidvMOpfPhxXkceK[JUrFzIGEulStLHwidvMOpfPhxXkceY]['type']=='list':
    if JUrFzIGEulStLHwidvMOpfPhxXkcKT(value)==JUrFzIGEulStLHwidvMOpfPhxXkcKn:
     JUrFzIGEulStLHwidvMOpfPhxXkcKy(video_InfoTag,JUrFzIGEulStLHwidvMOpfPhxXkceK[JUrFzIGEulStLHwidvMOpfPhxXkceY]['func'])(value)
    else:
     JUrFzIGEulStLHwidvMOpfPhxXkcKy(video_InfoTag,JUrFzIGEulStLHwidvMOpfPhxXkceK[JUrFzIGEulStLHwidvMOpfPhxXkceY]['func'])([value])
 def make_M3u_Filename(JUrFzIGEulStLHwidvMOpfPhxXkceR,tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKW):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_FILE_PATH+JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(JUrFzIGEulStLHwidvMOpfPhxXkceR,tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKW):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_FILE_PATH+JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_FILE_NAME+'.xml'
 def dp_Main_List(JUrFzIGEulStLHwidvMOpfPhxXkceR):
  for JUrFzIGEulStLHwidvMOpfPhxXkceD in JUrFzIGEulStLHwidvMOpfPhxXkcej:
   JUrFzIGEulStLHwidvMOpfPhxXkcen=JUrFzIGEulStLHwidvMOpfPhxXkceD.get('title')
   JUrFzIGEulStLHwidvMOpfPhxXkceq=''
   JUrFzIGEulStLHwidvMOpfPhxXkcem={'mode':JUrFzIGEulStLHwidvMOpfPhxXkceD.get('mode'),'sType':JUrFzIGEulStLHwidvMOpfPhxXkceD.get('sType'),'sName':JUrFzIGEulStLHwidvMOpfPhxXkceD.get('sName')}
   JUrFzIGEulStLHwidvMOpfPhxXkceb={'title':JUrFzIGEulStLHwidvMOpfPhxXkcen,'plot':JUrFzIGEulStLHwidvMOpfPhxXkcen}
   if JUrFzIGEulStLHwidvMOpfPhxXkceD.get('mode')=='XXX':
    JUrFzIGEulStLHwidvMOpfPhxXkcNe=JUrFzIGEulStLHwidvMOpfPhxXkcKW
    JUrFzIGEulStLHwidvMOpfPhxXkcNj =JUrFzIGEulStLHwidvMOpfPhxXkcKB
   else:
    JUrFzIGEulStLHwidvMOpfPhxXkcNe=JUrFzIGEulStLHwidvMOpfPhxXkcKB
    JUrFzIGEulStLHwidvMOpfPhxXkcNj =JUrFzIGEulStLHwidvMOpfPhxXkcKW
   JUrFzIGEulStLHwidvMOpfPhxXkcNK=JUrFzIGEulStLHwidvMOpfPhxXkcKB
   if JUrFzIGEulStLHwidvMOpfPhxXkceD.get('mode')=='ADD_M3U':
    if JUrFzIGEulStLHwidvMOpfPhxXkceD.get('sType')=='wavve' and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVE ==JUrFzIGEulStLHwidvMOpfPhxXkcKW:JUrFzIGEulStLHwidvMOpfPhxXkcNK=JUrFzIGEulStLHwidvMOpfPhxXkcKW
    if JUrFzIGEulStLHwidvMOpfPhxXkceD.get('sType')=='tving' and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONTVING ==JUrFzIGEulStLHwidvMOpfPhxXkcKW:JUrFzIGEulStLHwidvMOpfPhxXkcNK=JUrFzIGEulStLHwidvMOpfPhxXkcKW
    if JUrFzIGEulStLHwidvMOpfPhxXkceD.get('sType')=='spotv' and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSPOTV ==JUrFzIGEulStLHwidvMOpfPhxXkcKW:JUrFzIGEulStLHwidvMOpfPhxXkcNK=JUrFzIGEulStLHwidvMOpfPhxXkcKW
    if JUrFzIGEulStLHwidvMOpfPhxXkceD.get('sType')=='samsung' and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSAMSUNG==JUrFzIGEulStLHwidvMOpfPhxXkcKW:JUrFzIGEulStLHwidvMOpfPhxXkcNK=JUrFzIGEulStLHwidvMOpfPhxXkcKW
    if JUrFzIGEulStLHwidvMOpfPhxXkceD.get('sType')=='custom' and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_CUSTOM_LIST==[]:JUrFzIGEulStLHwidvMOpfPhxXkcNK=JUrFzIGEulStLHwidvMOpfPhxXkcKW
   if JUrFzIGEulStLHwidvMOpfPhxXkcNK==JUrFzIGEulStLHwidvMOpfPhxXkcKB:
    if 'icon' in JUrFzIGEulStLHwidvMOpfPhxXkceD:JUrFzIGEulStLHwidvMOpfPhxXkceq=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',JUrFzIGEulStLHwidvMOpfPhxXkceD.get('icon')) 
    JUrFzIGEulStLHwidvMOpfPhxXkceR.add_dir(JUrFzIGEulStLHwidvMOpfPhxXkcen,sublabel='',img=JUrFzIGEulStLHwidvMOpfPhxXkceq,infoLabels=JUrFzIGEulStLHwidvMOpfPhxXkceb,isFolder=JUrFzIGEulStLHwidvMOpfPhxXkcNe,params=JUrFzIGEulStLHwidvMOpfPhxXkcem,isLink=JUrFzIGEulStLHwidvMOpfPhxXkcNj)
  if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcej)>0:xbmcplugin.endOfDirectory(JUrFzIGEulStLHwidvMOpfPhxXkceR._addon_handle,cacheToDisc=JUrFzIGEulStLHwidvMOpfPhxXkcKB)
 def dp_Delete_M3u(JUrFzIGEulStLHwidvMOpfPhxXkceR,args):
  JUrFzIGEulStLHwidvMOpfPhxXkceo=xbmcgui.Dialog()
  JUrFzIGEulStLHwidvMOpfPhxXkcNR=JUrFzIGEulStLHwidvMOpfPhxXkceo.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if JUrFzIGEulStLHwidvMOpfPhxXkcNR==JUrFzIGEulStLHwidvMOpfPhxXkcKW:sys.exit()
  JUrFzIGEulStLHwidvMOpfPhxXkcNA=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_M3u_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKW)
  if xbmcvfs.exists(JUrFzIGEulStLHwidvMOpfPhxXkcNA):
   if xbmcvfs.delete(JUrFzIGEulStLHwidvMOpfPhxXkcNA)==JUrFzIGEulStLHwidvMOpfPhxXkcKW:
    JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti(__language__(30910).encode('utf-8'))
    return
  JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(JUrFzIGEulStLHwidvMOpfPhxXkceR,args):
  JUrFzIGEulStLHwidvMOpfPhxXkcNg=args.get('sType')
  JUrFzIGEulStLHwidvMOpfPhxXkcNa=args.get('sName')
  JUrFzIGEulStLHwidvMOpfPhxXkceo=xbmcgui.Dialog()
  JUrFzIGEulStLHwidvMOpfPhxXkcNR=JUrFzIGEulStLHwidvMOpfPhxXkceo.yesno((JUrFzIGEulStLHwidvMOpfPhxXkcNa+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if JUrFzIGEulStLHwidvMOpfPhxXkcNR==JUrFzIGEulStLHwidvMOpfPhxXkcKW:sys.exit()
  JUrFzIGEulStLHwidvMOpfPhxXkcNW =[]
  JUrFzIGEulStLHwidvMOpfPhxXkcNo =[]
  JUrFzIGEulStLHwidvMOpfPhxXkcNA=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_M3u_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKB)
  if os.path.isfile(JUrFzIGEulStLHwidvMOpfPhxXkcNA):os.remove(JUrFzIGEulStLHwidvMOpfPhxXkcNA)
  if JUrFzIGEulStLHwidvMOpfPhxXkcNg=='all':
   JUrFzIGEulStLHwidvMOpfPhxXkcNA=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_M3u_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKW)
   if xbmcvfs.exists(JUrFzIGEulStLHwidvMOpfPhxXkcNA):
    if xbmcvfs.delete(JUrFzIGEulStLHwidvMOpfPhxXkcNA)==JUrFzIGEulStLHwidvMOpfPhxXkcKW:
     JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   JUrFzIGEulStLHwidvMOpfPhxXkcNB=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_M3u_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKW)
   if xbmcvfs.exists(JUrFzIGEulStLHwidvMOpfPhxXkcNB):
    JUrFzIGEulStLHwidvMOpfPhxXkcNy=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_M3u_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKB)
    xbmcvfs.copy(JUrFzIGEulStLHwidvMOpfPhxXkcNB,JUrFzIGEulStLHwidvMOpfPhxXkcNy)
  if(JUrFzIGEulStLHwidvMOpfPhxXkcNg=='wavve' or JUrFzIGEulStLHwidvMOpfPhxXkcNg=='all')and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVE:
   JUrFzIGEulStLHwidvMOpfPhxXkcNT=JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_ChannelList_Wavve(exceptGroup=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_EexceptGroup_Wavve())
   if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcNT)!=0:JUrFzIGEulStLHwidvMOpfPhxXkcNW.extend(JUrFzIGEulStLHwidvMOpfPhxXkcNT)
   JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_log('wavve cnt ----> '+JUrFzIGEulStLHwidvMOpfPhxXkcKY(JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcNT)))
  if(JUrFzIGEulStLHwidvMOpfPhxXkcNg=='tving' or JUrFzIGEulStLHwidvMOpfPhxXkcNg=='all')and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONTVING:
   JUrFzIGEulStLHwidvMOpfPhxXkcNT=JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_ChannelList_Tving()
   if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcNT)!=0:JUrFzIGEulStLHwidvMOpfPhxXkcNW.extend(JUrFzIGEulStLHwidvMOpfPhxXkcNT)
   JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_log('tving cnt ----> '+JUrFzIGEulStLHwidvMOpfPhxXkcKY(JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcNT)))
  if(JUrFzIGEulStLHwidvMOpfPhxXkcNg=='spotv' or JUrFzIGEulStLHwidvMOpfPhxXkcNg=='all')and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSPOTV:
   JUrFzIGEulStLHwidvMOpfPhxXkcNT=JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_ChannelList_Spotv(payyn=JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSPOTVPAY)
   if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcNT)!=0:JUrFzIGEulStLHwidvMOpfPhxXkcNW.extend(JUrFzIGEulStLHwidvMOpfPhxXkcNT)
   JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_log('spotv cnt ----> '+JUrFzIGEulStLHwidvMOpfPhxXkcKY(JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcNT)))
  if(JUrFzIGEulStLHwidvMOpfPhxXkcNg=='samsung' or JUrFzIGEulStLHwidvMOpfPhxXkcNg=='all')and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSAMSUNG:
   JUrFzIGEulStLHwidvMOpfPhxXkcNs=JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_BaseInfo_Samsungtv()
   JUrFzIGEulStLHwidvMOpfPhxXkcNT=JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_ChannelList_Samsungtv(JUrFzIGEulStLHwidvMOpfPhxXkcNs,exceptGroup=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_EexceptGroup_Samsungtv())
   if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcNT)!=0:JUrFzIGEulStLHwidvMOpfPhxXkcNW.extend(JUrFzIGEulStLHwidvMOpfPhxXkcNT)
   JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_log('samsungtv cnt ----> '+JUrFzIGEulStLHwidvMOpfPhxXkcKY(JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcNT)))
  if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcNW)==0 and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_CUSTOM_LIST==[]:
   JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti(__language__(30909).encode('utf8'))
   return
  for JUrFzIGEulStLHwidvMOpfPhxXkcNn in JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.INIT_GENRESORT:
   for JUrFzIGEulStLHwidvMOpfPhxXkcNV in JUrFzIGEulStLHwidvMOpfPhxXkcNW:
    if JUrFzIGEulStLHwidvMOpfPhxXkcNV['genrenm']==JUrFzIGEulStLHwidvMOpfPhxXkcNn:
     JUrFzIGEulStLHwidvMOpfPhxXkcNo.append(JUrFzIGEulStLHwidvMOpfPhxXkcNV)
  for JUrFzIGEulStLHwidvMOpfPhxXkcNV in JUrFzIGEulStLHwidvMOpfPhxXkcNW:
   if JUrFzIGEulStLHwidvMOpfPhxXkcNV['genrenm']not in JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.INIT_GENRESORT:
    JUrFzIGEulStLHwidvMOpfPhxXkcNo.append(JUrFzIGEulStLHwidvMOpfPhxXkcNV)
  try:
   if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcNW)>0:
    JUrFzIGEulStLHwidvMOpfPhxXkcNA=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_M3u_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKB)
    if os.path.isfile(JUrFzIGEulStLHwidvMOpfPhxXkcNA):
     fp=JUrFzIGEulStLHwidvMOpfPhxXkcKQ(JUrFzIGEulStLHwidvMOpfPhxXkcNA,'a',-1,'utf-8')
    else:
     fp=JUrFzIGEulStLHwidvMOpfPhxXkcKQ(JUrFzIGEulStLHwidvMOpfPhxXkcNA,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for JUrFzIGEulStLHwidvMOpfPhxXkcNY in JUrFzIGEulStLHwidvMOpfPhxXkcNo:
     JUrFzIGEulStLHwidvMOpfPhxXkcNQ =JUrFzIGEulStLHwidvMOpfPhxXkcNY['channelid']
     JUrFzIGEulStLHwidvMOpfPhxXkcND =JUrFzIGEulStLHwidvMOpfPhxXkcNY['channelnm']
     JUrFzIGEulStLHwidvMOpfPhxXkcNq=JUrFzIGEulStLHwidvMOpfPhxXkcNY['channelimg']
     JUrFzIGEulStLHwidvMOpfPhxXkcNm =JUrFzIGEulStLHwidvMOpfPhxXkcNY['ott']
     JUrFzIGEulStLHwidvMOpfPhxXkcNb ='%s.%s'%(JUrFzIGEulStLHwidvMOpfPhxXkcNQ,JUrFzIGEulStLHwidvMOpfPhxXkcNm)
     JUrFzIGEulStLHwidvMOpfPhxXkcje=JUrFzIGEulStLHwidvMOpfPhxXkcNY['genrenm']
     if JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_DISPLAYNM:
      JUrFzIGEulStLHwidvMOpfPhxXkcND='%s (%s)'%(JUrFzIGEulStLHwidvMOpfPhxXkcND,JUrFzIGEulStLHwidvMOpfPhxXkcNm)
     if JUrFzIGEulStLHwidvMOpfPhxXkcje=='라디오/음악':
      JUrFzIGEulStLHwidvMOpfPhxXkcjN='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(JUrFzIGEulStLHwidvMOpfPhxXkcNb,JUrFzIGEulStLHwidvMOpfPhxXkcND,JUrFzIGEulStLHwidvMOpfPhxXkcje,JUrFzIGEulStLHwidvMOpfPhxXkcNq,JUrFzIGEulStLHwidvMOpfPhxXkcND)
     else:
      JUrFzIGEulStLHwidvMOpfPhxXkcjN='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(JUrFzIGEulStLHwidvMOpfPhxXkcNb,JUrFzIGEulStLHwidvMOpfPhxXkcND,JUrFzIGEulStLHwidvMOpfPhxXkcje,JUrFzIGEulStLHwidvMOpfPhxXkcNq,JUrFzIGEulStLHwidvMOpfPhxXkcND)
     if JUrFzIGEulStLHwidvMOpfPhxXkcNm=='wavve':
      JUrFzIGEulStLHwidvMOpfPhxXkcjK ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(JUrFzIGEulStLHwidvMOpfPhxXkcNQ)
     elif JUrFzIGEulStLHwidvMOpfPhxXkcNm=='tving':
      JUrFzIGEulStLHwidvMOpfPhxXkcjK ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(JUrFzIGEulStLHwidvMOpfPhxXkcNQ)
     elif JUrFzIGEulStLHwidvMOpfPhxXkcNm=='spotv':
      JUrFzIGEulStLHwidvMOpfPhxXkcjK ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(JUrFzIGEulStLHwidvMOpfPhxXkcNQ)
     if JUrFzIGEulStLHwidvMOpfPhxXkcNm=='samsung':
      JUrFzIGEulStLHwidvMOpfPhxXkcjK ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(JUrFzIGEulStLHwidvMOpfPhxXkcNQ)
     fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjN)
     fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjK)
    fp.close()
  except:
   JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti(__language__(30910).encode('utf8'))
   return
  try:
   if(JUrFzIGEulStLHwidvMOpfPhxXkcNg=='custom' or JUrFzIGEulStLHwidvMOpfPhxXkcNg=='all')and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_CUSTOM_LIST!=[]:
    JUrFzIGEulStLHwidvMOpfPhxXkcNA=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_M3u_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKB)
    if os.path.isfile(JUrFzIGEulStLHwidvMOpfPhxXkcNA):
     fp=JUrFzIGEulStLHwidvMOpfPhxXkcKQ(JUrFzIGEulStLHwidvMOpfPhxXkcNA,'a',-1,'utf-8')
    else:
     fp=JUrFzIGEulStLHwidvMOpfPhxXkcKQ(JUrFzIGEulStLHwidvMOpfPhxXkcNA,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for JUrFzIGEulStLHwidvMOpfPhxXkcjC in JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_CUSTOM_LIST:
     JUrFzIGEulStLHwidvMOpfPhxXkcjR=JUrFzIGEulStLHwidvMOpfPhxXkceR.customEpg_FileRead(JUrFzIGEulStLHwidvMOpfPhxXkcjC)
     for JUrFzIGEulStLHwidvMOpfPhxXkcjA in JUrFzIGEulStLHwidvMOpfPhxXkcjR:
      JUrFzIGEulStLHwidvMOpfPhxXkcjA=JUrFzIGEulStLHwidvMOpfPhxXkcjA.strip()
      if JUrFzIGEulStLHwidvMOpfPhxXkcjA not in['','#EXTM3U']:
       fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjA+'\n')
   fp.close()
  except:
   JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti(__language__(30910).encode('utf8'))
   return
  JUrFzIGEulStLHwidvMOpfPhxXkcNB=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_M3u_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKB)
  JUrFzIGEulStLHwidvMOpfPhxXkcNy=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_M3u_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKW)
  if xbmcvfs.copy(JUrFzIGEulStLHwidvMOpfPhxXkcNB,JUrFzIGEulStLHwidvMOpfPhxXkcNy):
   JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti((JUrFzIGEulStLHwidvMOpfPhxXkcNa+' '+__language__(30908)).encode('utf8'))
  else:
   JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti(__language__(30910).encode('utf-8'))
 def customEpg_FileList(JUrFzIGEulStLHwidvMOpfPhxXkceR):
  JUrFzIGEulStLHwidvMOpfPhxXkcjg=[]
  if __addon__.getSetting('custom01on')=='true':JUrFzIGEulStLHwidvMOpfPhxXkcjg.append(__addon__.getSetting('custom01nm'))
  if __addon__.getSetting('custom02on')=='true':JUrFzIGEulStLHwidvMOpfPhxXkcjg.append(__addon__.getSetting('custom02nm'))
  if __addon__.getSetting('custom03on')=='true':JUrFzIGEulStLHwidvMOpfPhxXkcjg.append(__addon__.getSetting('custom03nm'))
  if __addon__.getSetting('custom04on')=='true':JUrFzIGEulStLHwidvMOpfPhxXkcjg.append(__addon__.getSetting('custom04nm'))
  if __addon__.getSetting('custom05on')=='true':JUrFzIGEulStLHwidvMOpfPhxXkcjg.append(__addon__.getSetting('custom05nm'))
  return JUrFzIGEulStLHwidvMOpfPhxXkcjg
 def customEpg_FileRead(JUrFzIGEulStLHwidvMOpfPhxXkceR,source_filename):
  try:
   JUrFzIGEulStLHwidvMOpfPhxXkcja=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
   if os.path.isfile(JUrFzIGEulStLHwidvMOpfPhxXkcja):os.remove(JUrFzIGEulStLHwidvMOpfPhxXkcja)
   xbmcvfs.copy(source_filename,JUrFzIGEulStLHwidvMOpfPhxXkcja)
   fp=JUrFzIGEulStLHwidvMOpfPhxXkcKQ(JUrFzIGEulStLHwidvMOpfPhxXkcja,'r',-1,'utf-8')
   JUrFzIGEulStLHwidvMOpfPhxXkcjW=fp.readlines()
  except:
   return[]
  return JUrFzIGEulStLHwidvMOpfPhxXkcjW
 def dp_Make_Epg(JUrFzIGEulStLHwidvMOpfPhxXkceR,args):
  JUrFzIGEulStLHwidvMOpfPhxXkcNg=args.get('sType')
  JUrFzIGEulStLHwidvMOpfPhxXkcNa=args.get('sName')
  JUrFzIGEulStLHwidvMOpfPhxXkcjo=args.get('sNoti')
  if JUrFzIGEulStLHwidvMOpfPhxXkcjo!='N':
   JUrFzIGEulStLHwidvMOpfPhxXkceo=xbmcgui.Dialog()
   JUrFzIGEulStLHwidvMOpfPhxXkcNR=JUrFzIGEulStLHwidvMOpfPhxXkceo.yesno((JUrFzIGEulStLHwidvMOpfPhxXkcNa+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if JUrFzIGEulStLHwidvMOpfPhxXkcNR==JUrFzIGEulStLHwidvMOpfPhxXkcKW:sys.exit()
  JUrFzIGEulStLHwidvMOpfPhxXkcjB=[]
  JUrFzIGEulStLHwidvMOpfPhxXkcjy=[]
  if(JUrFzIGEulStLHwidvMOpfPhxXkcNg=='wavve' or JUrFzIGEulStLHwidvMOpfPhxXkcNg=='all')and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVE:
   JUrFzIGEulStLHwidvMOpfPhxXkcjT,JUrFzIGEulStLHwidvMOpfPhxXkcjs=JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_EexceptGroup_Wavve())
   if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcjs)!=0:
    JUrFzIGEulStLHwidvMOpfPhxXkcjB.extend(JUrFzIGEulStLHwidvMOpfPhxXkcjT)
    JUrFzIGEulStLHwidvMOpfPhxXkcjy.extend(JUrFzIGEulStLHwidvMOpfPhxXkcjs)
  if(JUrFzIGEulStLHwidvMOpfPhxXkcNg=='tving' or JUrFzIGEulStLHwidvMOpfPhxXkcNg=='all')and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONTVING:
   JUrFzIGEulStLHwidvMOpfPhxXkcjT,JUrFzIGEulStLHwidvMOpfPhxXkcjs=JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_EpgInfo_Tving()
   if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcjs)!=0:
    JUrFzIGEulStLHwidvMOpfPhxXkcjB.extend(JUrFzIGEulStLHwidvMOpfPhxXkcjT)
    JUrFzIGEulStLHwidvMOpfPhxXkcjy.extend(JUrFzIGEulStLHwidvMOpfPhxXkcjs)
  if(JUrFzIGEulStLHwidvMOpfPhxXkcNg=='spotv' or JUrFzIGEulStLHwidvMOpfPhxXkcNg=='all')and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSPOTV:
   JUrFzIGEulStLHwidvMOpfPhxXkcjT,JUrFzIGEulStLHwidvMOpfPhxXkcjs=JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_EpgInfo_Spotv(payyn=JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSPOTVPAY)
   if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcjs)!=0:
    JUrFzIGEulStLHwidvMOpfPhxXkcjB.extend(JUrFzIGEulStLHwidvMOpfPhxXkcjT)
    JUrFzIGEulStLHwidvMOpfPhxXkcjy.extend(JUrFzIGEulStLHwidvMOpfPhxXkcjs)
  if(JUrFzIGEulStLHwidvMOpfPhxXkcNg=='samsung' or JUrFzIGEulStLHwidvMOpfPhxXkcNg=='all')and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSAMSUNG:
   JUrFzIGEulStLHwidvMOpfPhxXkcNs=JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_BaseInfo_Samsungtv()
   JUrFzIGEulStLHwidvMOpfPhxXkcjT,JUrFzIGEulStLHwidvMOpfPhxXkcjs=JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_EpgInfo_Samsungtv(JUrFzIGEulStLHwidvMOpfPhxXkcNs,exceptGroup=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_EexceptGroup_Samsungtv())
   if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcjs)!=0:
    JUrFzIGEulStLHwidvMOpfPhxXkcjB.extend(JUrFzIGEulStLHwidvMOpfPhxXkcjT)
    JUrFzIGEulStLHwidvMOpfPhxXkcjy.extend(JUrFzIGEulStLHwidvMOpfPhxXkcjs)
  if JUrFzIGEulStLHwidvMOpfPhxXkcKV(JUrFzIGEulStLHwidvMOpfPhxXkcjy)==0:
   if JUrFzIGEulStLHwidvMOpfPhxXkcjo!='N':JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   JUrFzIGEulStLHwidvMOpfPhxXkcNA=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_Epg_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKB)
   fp=JUrFzIGEulStLHwidvMOpfPhxXkcKQ(JUrFzIGEulStLHwidvMOpfPhxXkcNA,'w',-1,'utf-8')
   JUrFzIGEulStLHwidvMOpfPhxXkcjn='<?xml version="1.0" encoding="UTF-8"?>\n'
   JUrFzIGEulStLHwidvMOpfPhxXkcjV='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   JUrFzIGEulStLHwidvMOpfPhxXkcjY='<tv generator-info-name="boritv_epg">\n\n'
   JUrFzIGEulStLHwidvMOpfPhxXkcjQ='\n</tv>\n'
   fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjn)
   fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjV)
   fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjY)
   for JUrFzIGEulStLHwidvMOpfPhxXkcjD in JUrFzIGEulStLHwidvMOpfPhxXkcjB:
    JUrFzIGEulStLHwidvMOpfPhxXkcjq='  <channel id="%s.%s">\n' %(JUrFzIGEulStLHwidvMOpfPhxXkcjD.get('channelid'),JUrFzIGEulStLHwidvMOpfPhxXkcjD.get('ott'))
    JUrFzIGEulStLHwidvMOpfPhxXkcjm='    <display-name>%s</display-name>\n'%(JUrFzIGEulStLHwidvMOpfPhxXkcjD.get('channelnm'))
    JUrFzIGEulStLHwidvMOpfPhxXkcjb='    <icon src="%s" />\n' %(JUrFzIGEulStLHwidvMOpfPhxXkcjD.get('channelimg'))
    JUrFzIGEulStLHwidvMOpfPhxXkcKe='  </channel>\n\n'
    fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjq)
    fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjm)
    fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjb)
    fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcKe)
   for JUrFzIGEulStLHwidvMOpfPhxXkcjD in JUrFzIGEulStLHwidvMOpfPhxXkcjy:
    JUrFzIGEulStLHwidvMOpfPhxXkcjq='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(JUrFzIGEulStLHwidvMOpfPhxXkcjD.get('startTime'),JUrFzIGEulStLHwidvMOpfPhxXkcjD.get('endTime'),JUrFzIGEulStLHwidvMOpfPhxXkcjD.get('channelid'),JUrFzIGEulStLHwidvMOpfPhxXkcjD.get('ott'))
    JUrFzIGEulStLHwidvMOpfPhxXkcjm='    <title lang="kr">%s</title>\n' %(JUrFzIGEulStLHwidvMOpfPhxXkcjD.get('title'))
    JUrFzIGEulStLHwidvMOpfPhxXkcjb='  </programme>\n\n'
    fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjq)
    fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjm)
    fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjb)
   fp.write(JUrFzIGEulStLHwidvMOpfPhxXkcjQ)
   fp.close()
  except:
   if JUrFzIGEulStLHwidvMOpfPhxXkcjo!='N':JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti(__language__(30910).encode('utf8'))
   return
  JUrFzIGEulStLHwidvMOpfPhxXkceR.MakeEpg_SaveJson()
  JUrFzIGEulStLHwidvMOpfPhxXkcNB=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_Epg_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKB)
  JUrFzIGEulStLHwidvMOpfPhxXkcNy=JUrFzIGEulStLHwidvMOpfPhxXkceR.make_Epg_Filename(tempyn=JUrFzIGEulStLHwidvMOpfPhxXkcKW)
  if xbmcvfs.copy(JUrFzIGEulStLHwidvMOpfPhxXkcNB,JUrFzIGEulStLHwidvMOpfPhxXkcNy):
   if JUrFzIGEulStLHwidvMOpfPhxXkcjo!='N':JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti((JUrFzIGEulStLHwidvMOpfPhxXkcNa+' '+__language__(30912)).encode('utf8'))
  else:
   JUrFzIGEulStLHwidvMOpfPhxXkceR.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_AUTORESTART:
    JUrFzIGEulStLHwidvMOpfPhxXkcKN=xbmcaddon.Addon('pvr.iptvsimple')
    JUrFzIGEulStLHwidvMOpfPhxXkcKN.setSetting('anything','anything')
  except:
   JUrFzIGEulStLHwidvMOpfPhxXkcKo 
 def make_EexceptGroup_Wavve(JUrFzIGEulStLHwidvMOpfPhxXkceR):
  JUrFzIGEulStLHwidvMOpfPhxXkcKj=[]
  if JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVERADIO==JUrFzIGEulStLHwidvMOpfPhxXkcKW:
   JUrFzIGEulStLHwidvMOpfPhxXkcKj.append('라디오/음악')
  if JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVEHOME==JUrFzIGEulStLHwidvMOpfPhxXkcKW:
   JUrFzIGEulStLHwidvMOpfPhxXkcKj.append('홈쇼핑')
  if JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONRELIGION==JUrFzIGEulStLHwidvMOpfPhxXkcKW:
   JUrFzIGEulStLHwidvMOpfPhxXkcKj.append('종교')
  return JUrFzIGEulStLHwidvMOpfPhxXkcKj
 def make_EexceptGroup_Samsungtv(JUrFzIGEulStLHwidvMOpfPhxXkceR):
  JUrFzIGEulStLHwidvMOpfPhxXkcKj=[]
  if JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSAMSUNGHOME==JUrFzIGEulStLHwidvMOpfPhxXkcKW:
   JUrFzIGEulStLHwidvMOpfPhxXkcKj.append('홈쇼핑')
  return JUrFzIGEulStLHwidvMOpfPhxXkcKj
 def get_radio_list(JUrFzIGEulStLHwidvMOpfPhxXkceR):
  if JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVERADIO==JUrFzIGEulStLHwidvMOpfPhxXkcKW:return[]
  JUrFzIGEulStLHwidvMOpfPhxXkcKC=[{'broadcastid':'46584','genre':'10'}]
  return JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_ChannelList_WavveExcept(JUrFzIGEulStLHwidvMOpfPhxXkcKC)
 def check_config(JUrFzIGEulStLHwidvMOpfPhxXkceR):
  JUrFzIGEulStLHwidvMOpfPhxXkcKR=JUrFzIGEulStLHwidvMOpfPhxXkcKB
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVE =JUrFzIGEulStLHwidvMOpfPhxXkcKB if __addon__.getSetting('onWavve')=='true' else JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONTVING =JUrFzIGEulStLHwidvMOpfPhxXkcKB if __addon__.getSetting('onTvng')=='true' else JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSPOTV =JUrFzIGEulStLHwidvMOpfPhxXkcKB if __addon__.getSetting('onSpotv')=='true' else JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSAMSUNG =JUrFzIGEulStLHwidvMOpfPhxXkcKB if __addon__.getSetting('onSamsung')=='true' else JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVERADIO =JUrFzIGEulStLHwidvMOpfPhxXkcKB if __addon__.getSetting('onWavveRadio')=='true' else JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVEHOME =JUrFzIGEulStLHwidvMOpfPhxXkcKB if __addon__.getSetting('onWavveHome')=='true' else JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONRELIGION =JUrFzIGEulStLHwidvMOpfPhxXkcKB if __addon__.getSetting('onWavveReligion')=='true' else JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSPOTVPAY =JUrFzIGEulStLHwidvMOpfPhxXkcKB if __addon__.getSetting('onSpotvPay')=='true' else JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSAMSUNGHOME =JUrFzIGEulStLHwidvMOpfPhxXkcKB if __addon__.getSetting('onSamsungHome')=='true' else JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_DISPLAYNM =JUrFzIGEulStLHwidvMOpfPhxXkcKB if __addon__.getSetting('displayOTTnm')=='true' else JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_AUTORESTART =JUrFzIGEulStLHwidvMOpfPhxXkcKB if __addon__.getSetting('autoRestart')=='true' else JUrFzIGEulStLHwidvMOpfPhxXkcKW
  JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_CUSTOM_LIST =JUrFzIGEulStLHwidvMOpfPhxXkceR.customEpg_FileList()
  if JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_FILE_PATH=='' or JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_FILE_NAME=='':JUrFzIGEulStLHwidvMOpfPhxXkcKR=JUrFzIGEulStLHwidvMOpfPhxXkcKW
  if JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONWAVVE==JUrFzIGEulStLHwidvMOpfPhxXkcKW and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONTVING==JUrFzIGEulStLHwidvMOpfPhxXkcKW and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSPOTV==JUrFzIGEulStLHwidvMOpfPhxXkcKW and JUrFzIGEulStLHwidvMOpfPhxXkceR.M3U_ONSAMSUNG==JUrFzIGEulStLHwidvMOpfPhxXkcKW:JUrFzIGEulStLHwidvMOpfPhxXkcKR=JUrFzIGEulStLHwidvMOpfPhxXkcKW
  if JUrFzIGEulStLHwidvMOpfPhxXkcKR==JUrFzIGEulStLHwidvMOpfPhxXkcKW:
   JUrFzIGEulStLHwidvMOpfPhxXkceo=xbmcgui.Dialog()
   JUrFzIGEulStLHwidvMOpfPhxXkcNR=JUrFzIGEulStLHwidvMOpfPhxXkceo.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if JUrFzIGEulStLHwidvMOpfPhxXkcNR==JUrFzIGEulStLHwidvMOpfPhxXkcKB:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(JUrFzIGEulStLHwidvMOpfPhxXkceR):
  JUrFzIGEulStLHwidvMOpfPhxXkcKA={'date_makeepg':JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=JUrFzIGEulStLHwidvMOpfPhxXkcKQ(JUrFzIGEulStLHwidvMOpfPhxXkceC,'w',-1,'utf-8')
   json.dump(JUrFzIGEulStLHwidvMOpfPhxXkcKA,fp)
   fp.close()
  except JUrFzIGEulStLHwidvMOpfPhxXkcKD as exception:
   return
 def boritv_main(JUrFzIGEulStLHwidvMOpfPhxXkceR):
  JUrFzIGEulStLHwidvMOpfPhxXkceR.BoritvObj.KodiVersion=JUrFzIGEulStLHwidvMOpfPhxXkcKs(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  JUrFzIGEulStLHwidvMOpfPhxXkcKg=JUrFzIGEulStLHwidvMOpfPhxXkceR.main_params.get('mode',JUrFzIGEulStLHwidvMOpfPhxXkcKo)
  JUrFzIGEulStLHwidvMOpfPhxXkceR.check_config()
  if JUrFzIGEulStLHwidvMOpfPhxXkcKg is JUrFzIGEulStLHwidvMOpfPhxXkcKo:
   JUrFzIGEulStLHwidvMOpfPhxXkceR.dp_Main_List()
  elif JUrFzIGEulStLHwidvMOpfPhxXkcKg=='DEL_M3U':
   JUrFzIGEulStLHwidvMOpfPhxXkceR.dp_Delete_M3u(JUrFzIGEulStLHwidvMOpfPhxXkceR.main_params)
  elif JUrFzIGEulStLHwidvMOpfPhxXkcKg=='ADD_M3U':
   JUrFzIGEulStLHwidvMOpfPhxXkceR.dp_MakeAdd_M3u(JUrFzIGEulStLHwidvMOpfPhxXkceR.main_params)
  elif JUrFzIGEulStLHwidvMOpfPhxXkcKg=='ADD_EPG':
   JUrFzIGEulStLHwidvMOpfPhxXkceR.dp_Make_Epg(JUrFzIGEulStLHwidvMOpfPhxXkceR.main_params)
  else:
   JUrFzIGEulStLHwidvMOpfPhxXkcKo
# Created by pyminifier (https://github.com/liftoff/pyminifier)
