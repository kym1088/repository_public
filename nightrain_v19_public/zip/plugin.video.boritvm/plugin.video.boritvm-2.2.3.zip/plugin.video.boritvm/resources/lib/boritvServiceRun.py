# -*- coding: utf-8 -*-
__author__ = "NightRain"

import json
import time
#import threading
import datetime
import random
import os


###
try:
	import xbmc, xbmcaddon, xbmcvfs
	RUNMODE = 'ADDON'
except:
	RUNMODE = 'SINGLE'


if RUNMODE == 'ADDON':
	__addon__     = xbmcaddon.Addon()
	__version__   = __addon__.getAddonInfo('version')
	__addonid__   = __addon__.getAddonInfo('id')
	__profile__   = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))

	def addon_log( string ):
		log_message = str(string).encode('utf-8', 'ignore')
		level = xbmc.LOGINFO
		xbmc.log( "[%s-%s]: %s" %(__addonid__, __version__, log_message), level=level )

	def addon_getautoepg():
		return True if __addon__.getSetting( 'autoEpg') == 'true' else False

	def addon_epgupdate_confignm():
		return xbmcvfs.translatePath(os.path.join(__profile__, 'boritv_update.json'))

else:
	def addon_log( string ):
		print( string )

	def addon_getautoepg():
		return True

	def addon_epgupdate_confignm():
		return 'd:\\job\\boritv_update.json'

###


##### BoritvServiceRun class Start #####
class BoritvServiceRun():

	def __init__( self ):

		self.START_INTERVAL   = 3000 ### 3초
		self.INTERVAL         = 20 ### 20초
		self.EPG_FILETAGNM    = 'date_makeepg'
		self.EPG_MAKEDATE     = '-' ##### 생성일자
		self.EPG_WILL_TM      = -1  ##### 생성해야할 시간


	def Get_Now_Datetime( self ):
		return datetime.datetime.now( datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul') )
		#return datetime.datetime.utcnow() + datetime.timedelta(hours=9)


	def MakeEpg_DateCheck( self ):
		# return -1  오늘이면 미생성(pass)
 		# return 5  없으면(1일 이전)             : 5분후 바로생성
		# return 5  어제이고 현재시간 00시 아니면 : 5분후 바로생성
		# return 30 어제이고 현재시간 00시       : 30분후 생성

		filedate  = '-'

		# 1.생성일자 json 체크
		if self.EPG_MAKEDATE == '-':
			try:
				fp = open(addon_epgupdate_confignm(), 'r', -1, 'utf-8')
				json_data =  json.load(fp)
				fp.close()
				filedate = json_data[self.EPG_FILETAGNM]
			except Exception as exception:
				return 2 #5분이내 바로생성
		else:
			filedate = self.EPG_MAKEDATE


		tNow      = self.Get_Now_Datetime()
		yesterday = (tNow - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
		nowdate   = tNow.strftime('%Y-%m-%d')
		nowtm     = tNow.strftime('%H')


		# 2.생성일자가 오늘이면 미생성
		if filedate == nowdate:  return -1

		# 3. 생성일자가 어제이고 현재 00시이면 30분
		if filedate == yesterday and nowtm == '00' : return 30

		# 아니면 3분 (5분->3분)
		return 2


	# epg 생성할 시간 만들기
	def MakeEpg_RandomTm( self, mintm ):
		#plus_second = (mintm * 60) + random.randint(0, 300) # +5분 이내
		plus_second = (mintm * 60) + random.randint(0, 60) # +1분 이내
		#plus_second = (mintm * 10) # 테스트 10초
		
		tNow      = self.Get_Now_Datetime()
		maketm    = (tNow + datetime.timedelta(seconds=plus_second) ).strftime('%Y%m%d%H%M%S')
		return int(maketm)


	def MakeEpg_SaveJson( self ):
		json_data = { self.EPG_FILETAGNM : self.Get_Now_Datetime().strftime('%Y-%m-%d')	}
		try:		
			fp = open(addon_epgupdate_confignm(), 'w', -1, 'utf-8')
			json.dump(json_data, fp)
			fp.close()
		except Exception as exception:
			return



	def service_run(self):
		# 자동생성 옵션 활성화 체크
		if addon_getautoepg() == False: return


		# 생성해야할 시간 체크
		# return -1  오늘이면 미생성(pass)
		# return 5  없으면(1일 이전)             : 5분후 바로생성
		# return 5  어제이고 현재시간 00시 아니면 : 5분후 바로생성
		# return 30 어제이고 현재시간 00시       : 30분후 생성
		epg_make = self.MakeEpg_DateCheck()

		# 오늘 생성되었으면 패스
		if epg_make < 0:
			#addon_log( 'pass' )
			return

		if self.EPG_WILL_TM < 0: # 생성이 필요할때 생성시간 만들기
			self.EPG_WILL_TM = self.MakeEpg_RandomTm(epg_make)
			addon_log( 'EPG_WILL_TM --> ' + str(self.EPG_WILL_TM)  )
		else:
			nowdate = self.Get_Now_Datetime()
			if self.EPG_WILL_TM < int(nowdate.strftime('%Y%m%d%H%M%S')):

				### main job
				addon_log( 'make epg' )
				xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
				self.MakeEpg_SaveJson() #json 파일저장
				### main job

				self.EPG_MAKEDATE = nowdate.strftime('%Y-%m-%d')
				self.EPG_WILL_TM  = -1
			else:
				#addon_log( 'wait' )
				pass

		pass


##### BoritvServiceRun class End #####

		


if __name__ == "__main__":

	addon_log( '__main__' )
	serviceObj = BoritvServiceRun()
	time.sleep(3)

	while True:
		time.sleep(serviceObj.INTERVAL)
		serviceObj.service_run()
		pass


##### class End #####        