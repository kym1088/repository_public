__author__="NightRain"
srPCUmafQyoYXAjhBJDqEKiVlLWuIx=False
srPCUmafQyoYXAjhBJDqEKiVlLWuIe=object
srPCUmafQyoYXAjhBJDqEKiVlLWuIO=None
srPCUmafQyoYXAjhBJDqEKiVlLWuIR=str
srPCUmafQyoYXAjhBJDqEKiVlLWuIg=Exception
srPCUmafQyoYXAjhBJDqEKiVlLWuIv=print
srPCUmafQyoYXAjhBJDqEKiVlLWuMp=True
srPCUmafQyoYXAjhBJDqEKiVlLWuMz=int
srPCUmafQyoYXAjhBJDqEKiVlLWuMH=range
srPCUmafQyoYXAjhBJDqEKiVlLWuMI=len
srPCUmafQyoYXAjhBJDqEKiVlLWuMk=dict
srPCUmafQyoYXAjhBJDqEKiVlLWuMT=set
srPCUmafQyoYXAjhBJDqEKiVlLWuMw=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
srPCUmafQyoYXAjhBJDqEKiVlLWupH=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
srPCUmafQyoYXAjhBJDqEKiVlLWupI=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':srPCUmafQyoYXAjhBJDqEKiVlLWuIx,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':srPCUmafQyoYXAjhBJDqEKiVlLWuIx,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':srPCUmafQyoYXAjhBJDqEKiVlLWuIx,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':srPCUmafQyoYXAjhBJDqEKiVlLWuIx,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':srPCUmafQyoYXAjhBJDqEKiVlLWuIx,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':srPCUmafQyoYXAjhBJDqEKiVlLWuIx,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class srPCUmafQyoYXAjhBJDqEKiVlLWupz(srPCUmafQyoYXAjhBJDqEKiVlLWuIe):
 def __init__(srPCUmafQyoYXAjhBJDqEKiVlLWupM):
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_WAVVE ='https://apis.wavve.com'
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_TVING ='https://api.tving.com'
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_TVINGIMG ='https://image.tving.com'
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_SPOTV ='https://www.spotvnow.co.kr'
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.HTTPTAG ='https://'
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.LIMIT_WAVVE =500
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.LIMIT_TVING =60
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.LIMIT_TVINGEPG=20 
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.APPVERSION ='115.0.0.0' 
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.DEVICEMODEL ='Chrome' 
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.OSTYPE ='Windows' 
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.OSVERSION ='NT 10.0' 
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.DEFAULT_HEADER={'user-agent':srPCUmafQyoYXAjhBJDqEKiVlLWupM.USER_AGENT}
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.SLEEP_TIME =0.2
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.INIT_GENRESORT=MASTER_GENRE
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.INIT_CHANNEL =MASTER_CHANNEL
  srPCUmafQyoYXAjhBJDqEKiVlLWupM.KodiVersion =20
 def callRequestCookies(srPCUmafQyoYXAjhBJDqEKiVlLWupM,jobtype,srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,redirects=srPCUmafQyoYXAjhBJDqEKiVlLWuIx):
  srPCUmafQyoYXAjhBJDqEKiVlLWupw=srPCUmafQyoYXAjhBJDqEKiVlLWupM.DEFAULT_HEADER
  if headers:srPCUmafQyoYXAjhBJDqEKiVlLWupw.update(headers)
  if jobtype=='Get':
   srPCUmafQyoYXAjhBJDqEKiVlLWupc=requests.get(srPCUmafQyoYXAjhBJDqEKiVlLWupn,params=params,headers=srPCUmafQyoYXAjhBJDqEKiVlLWupw,cookies=cookies,allow_redirects=redirects)
  else:
   srPCUmafQyoYXAjhBJDqEKiVlLWupc=requests.post(srPCUmafQyoYXAjhBJDqEKiVlLWupn,data=payload,params=params,headers=srPCUmafQyoYXAjhBJDqEKiVlLWupw,cookies=cookies,allow_redirects=redirects)
  return srPCUmafQyoYXAjhBJDqEKiVlLWupc
 def Get_DefaultParams_Wavve(srPCUmafQyoYXAjhBJDqEKiVlLWupM):
  srPCUmafQyoYXAjhBJDqEKiVlLWupS={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return srPCUmafQyoYXAjhBJDqEKiVlLWupS
 def Get_DefaultParams_Tving(srPCUmafQyoYXAjhBJDqEKiVlLWupM):
  srPCUmafQyoYXAjhBJDqEKiVlLWupS={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return srPCUmafQyoYXAjhBJDqEKiVlLWupS
 def Get_Now_Datetime(srPCUmafQyoYXAjhBJDqEKiVlLWupM):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(srPCUmafQyoYXAjhBJDqEKiVlLWupM,in_text):
  srPCUmafQyoYXAjhBJDqEKiVlLWupd=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return srPCUmafQyoYXAjhBJDqEKiVlLWupd
 def Get_ChannelList_Wavve(srPCUmafQyoYXAjhBJDqEKiVlLWupM,exceptGroup=[]):
  srPCUmafQyoYXAjhBJDqEKiVlLWupb =[]
  srPCUmafQyoYXAjhBJDqEKiVlLWupt=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_ChannelImg_Wavve()
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_WAVVE+'/cf/live/recommend-channels'
   srPCUmafQyoYXAjhBJDqEKiVlLWupS={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupM.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   srPCUmafQyoYXAjhBJDqEKiVlLWupS.update(srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_DefaultParams_Wavve())
   srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWupS,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
   srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
   if not('celllist' in srPCUmafQyoYXAjhBJDqEKiVlLWupG['cell_toplist']):return srPCUmafQyoYXAjhBJDqEKiVlLWupb
   srPCUmafQyoYXAjhBJDqEKiVlLWupx=srPCUmafQyoYXAjhBJDqEKiVlLWupG['cell_toplist']['celllist']
   for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupx:
    srPCUmafQyoYXAjhBJDqEKiVlLWupO=srPCUmafQyoYXAjhBJDqEKiVlLWupe['contentid']
    srPCUmafQyoYXAjhBJDqEKiVlLWupR=srPCUmafQyoYXAjhBJDqEKiVlLWupe['title_list'][0]['text']
    if srPCUmafQyoYXAjhBJDqEKiVlLWupO in srPCUmafQyoYXAjhBJDqEKiVlLWupt:
     srPCUmafQyoYXAjhBJDqEKiVlLWupg=srPCUmafQyoYXAjhBJDqEKiVlLWupt[srPCUmafQyoYXAjhBJDqEKiVlLWupO]
     if not srPCUmafQyoYXAjhBJDqEKiVlLWupg.startswith('http://')and not srPCUmafQyoYXAjhBJDqEKiVlLWupg.startswith('https://'):
      srPCUmafQyoYXAjhBJDqEKiVlLWupg=srPCUmafQyoYXAjhBJDqEKiVlLWupM.HTTPTAG+srPCUmafQyoYXAjhBJDqEKiVlLWupt[srPCUmafQyoYXAjhBJDqEKiVlLWupO]
    else:
     srPCUmafQyoYXAjhBJDqEKiVlLWupg=''
    srPCUmafQyoYXAjhBJDqEKiVlLWupv=srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_getGenre(srPCUmafQyoYXAjhBJDqEKiVlLWupO,'wavve')
    srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupO,'channelnm':srPCUmafQyoYXAjhBJDqEKiVlLWupR,'channelimg':srPCUmafQyoYXAjhBJDqEKiVlLWupg,'ott':'wavve','genrenm':srPCUmafQyoYXAjhBJDqEKiVlLWupv}
    if srPCUmafQyoYXAjhBJDqEKiVlLWupv not in exceptGroup:
     srPCUmafQyoYXAjhBJDqEKiVlLWupb.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[]
  return srPCUmafQyoYXAjhBJDqEKiVlLWupb
 def Get_ChannelList_WavveExcept(srPCUmafQyoYXAjhBJDqEKiVlLWupM,exceptGroup=[]):
  srPCUmafQyoYXAjhBJDqEKiVlLWupb=[]
  if exceptGroup==[]:return[]
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_WAVVE+'/cf/live/recommend-channels'
   for srPCUmafQyoYXAjhBJDqEKiVlLWupe in exceptGroup:
    srPCUmafQyoYXAjhBJDqEKiVlLWupS={'WeekDay':'all','adult':'n','broadcastid':srPCUmafQyoYXAjhBJDqEKiVlLWupe['broadcastid'],'contenttype':'channel','genre':srPCUmafQyoYXAjhBJDqEKiVlLWupe['genre'],'isrecommend':'y','limit':srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupM.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    srPCUmafQyoYXAjhBJDqEKiVlLWupS.update(srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_DefaultParams_Wavve())
    srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWupS,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
    srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
    if not('celllist' in srPCUmafQyoYXAjhBJDqEKiVlLWupG['cell_toplist']):return srPCUmafQyoYXAjhBJDqEKiVlLWupb
    srPCUmafQyoYXAjhBJDqEKiVlLWupx=srPCUmafQyoYXAjhBJDqEKiVlLWupG['cell_toplist']['celllist']
    for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupx:
     srPCUmafQyoYXAjhBJDqEKiVlLWupb.append(srPCUmafQyoYXAjhBJDqEKiVlLWupe['contentid'])
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[]
  return srPCUmafQyoYXAjhBJDqEKiVlLWupb
 def Get_ChannelImg_Wavve(srPCUmafQyoYXAjhBJDqEKiVlLWupM):
  srPCUmafQyoYXAjhBJDqEKiVlLWuzH={}
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWuzI=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_Now_Datetime()
   srPCUmafQyoYXAjhBJDqEKiVlLWuzM =srPCUmafQyoYXAjhBJDqEKiVlLWuzI+datetime.timedelta(hours=3)
   srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_WAVVE+'/live/epgs'
   srPCUmafQyoYXAjhBJDqEKiVlLWupS={'limit':srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupM.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':srPCUmafQyoYXAjhBJDqEKiVlLWuzI.strftime('%Y-%m-%d %H:00'),'enddatetime':srPCUmafQyoYXAjhBJDqEKiVlLWuzM.strftime('%Y-%m-%d %H:00')}
   srPCUmafQyoYXAjhBJDqEKiVlLWupS.update(srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_DefaultParams_Wavve())
   srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWupS,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
   srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
   srPCUmafQyoYXAjhBJDqEKiVlLWupx=srPCUmafQyoYXAjhBJDqEKiVlLWupG['list']
   for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupx:
    srPCUmafQyoYXAjhBJDqEKiVlLWuzH[srPCUmafQyoYXAjhBJDqEKiVlLWupe['channelid']]=srPCUmafQyoYXAjhBJDqEKiVlLWupe['channelimage']
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
  return srPCUmafQyoYXAjhBJDqEKiVlLWuzH
 def Get_ChanneGenrename_Wavve(srPCUmafQyoYXAjhBJDqEKiVlLWupM,srPCUmafQyoYXAjhBJDqEKiVlLWupO):
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_WAVVE+'/live/channels/'+srPCUmafQyoYXAjhBJDqEKiVlLWupO
   srPCUmafQyoYXAjhBJDqEKiVlLWupS=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_DefaultParams_Wavve()
   srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWupS,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
   srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
   srPCUmafQyoYXAjhBJDqEKiVlLWuzk=srPCUmafQyoYXAjhBJDqEKiVlLWupG['genretext']
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return ''
  return srPCUmafQyoYXAjhBJDqEKiVlLWuzk
 def Get_ChannelList_Spotv(srPCUmafQyoYXAjhBJDqEKiVlLWupM,payyn=srPCUmafQyoYXAjhBJDqEKiVlLWuMp):
  srPCUmafQyoYXAjhBJDqEKiVlLWupb=[]
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_SPOTV+'/api/v3/channel'
   srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
   srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
   for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupG:
    srPCUmafQyoYXAjhBJDqEKiVlLWupO=srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupe['id'])
    srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupO,'channelnm':srPCUmafQyoYXAjhBJDqEKiVlLWupe['name'],'channelimg':srPCUmafQyoYXAjhBJDqEKiVlLWupe['logo'],'ott':'spotv','genrenm':srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_getGenre(srPCUmafQyoYXAjhBJDqEKiVlLWupO,'spotv'),'free':srPCUmafQyoYXAjhBJDqEKiVlLWupe['free']}
    srPCUmafQyoYXAjhBJDqEKiVlLWupb.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[]
  return srPCUmafQyoYXAjhBJDqEKiVlLWupb
 def Get_ChannelList_Tving(srPCUmafQyoYXAjhBJDqEKiVlLWupM):
  srPCUmafQyoYXAjhBJDqEKiVlLWupb =[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuzT=[]
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_TVING+'/v2/media/lives'
   srPCUmafQyoYXAjhBJDqEKiVlLWupS={'pageNo':'1','pageSize':srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupM.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   srPCUmafQyoYXAjhBJDqEKiVlLWupS.update(srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_DefaultParams_Tving())
   srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWupS,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
   srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
   if not('result' in srPCUmafQyoYXAjhBJDqEKiVlLWupG['body']):return srPCUmafQyoYXAjhBJDqEKiVlLWupb
   srPCUmafQyoYXAjhBJDqEKiVlLWupx=srPCUmafQyoYXAjhBJDqEKiVlLWupG['body']['result']
   for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupx:
    if srPCUmafQyoYXAjhBJDqEKiVlLWupe['live_code']=='C44441':continue 
    srPCUmafQyoYXAjhBJDqEKiVlLWuzT.append(srPCUmafQyoYXAjhBJDqEKiVlLWupe['live_code'])
   srPCUmafQyoYXAjhBJDqEKiVlLWupt=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_ChannelImg_Tving(srPCUmafQyoYXAjhBJDqEKiVlLWuzT)
   for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupx:
    srPCUmafQyoYXAjhBJDqEKiVlLWupO=srPCUmafQyoYXAjhBJDqEKiVlLWupe['live_code']
    if srPCUmafQyoYXAjhBJDqEKiVlLWupO=='C44441':continue 
    srPCUmafQyoYXAjhBJDqEKiVlLWupR=srPCUmafQyoYXAjhBJDqEKiVlLWupe['schedule']['channel']['name']['ko']
    if srPCUmafQyoYXAjhBJDqEKiVlLWupO in srPCUmafQyoYXAjhBJDqEKiVlLWupt:
     srPCUmafQyoYXAjhBJDqEKiVlLWupg=srPCUmafQyoYXAjhBJDqEKiVlLWupt[srPCUmafQyoYXAjhBJDqEKiVlLWupO]
    else:
     srPCUmafQyoYXAjhBJDqEKiVlLWupg=''
    srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupO,'channelnm':srPCUmafQyoYXAjhBJDqEKiVlLWupR,'channelimg':srPCUmafQyoYXAjhBJDqEKiVlLWupg,'ott':'tving','genrenm':srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_getGenre(srPCUmafQyoYXAjhBJDqEKiVlLWupO,'tving')}
    srPCUmafQyoYXAjhBJDqEKiVlLWupb.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[]
  return srPCUmafQyoYXAjhBJDqEKiVlLWupb
 def Get_timestamp(srPCUmafQyoYXAjhBJDqEKiVlLWupM,timetype=1):
  ts=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(srPCUmafQyoYXAjhBJDqEKiVlLWupM,timetype):
  if timetype=='1':
   srPCUmafQyoYXAjhBJDqEKiVlLWuzw={'transactionId':srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   srPCUmafQyoYXAjhBJDqEKiVlLWuzw={'timestamp':srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_timestamp(timetype=1),'transactionId':srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_timestamp(timetype=1)+'000000000000001',}
  return srPCUmafQyoYXAjhBJDqEKiVlLWuzw
 def make_EpgDatetime_Tving(srPCUmafQyoYXAjhBJDqEKiVlLWupM,days=2):
  srPCUmafQyoYXAjhBJDqEKiVlLWuzc=[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuzS=srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_DateList(days=2,dateType='2')
  srPCUmafQyoYXAjhBJDqEKiVlLWuzF=srPCUmafQyoYXAjhBJDqEKiVlLWuMz(srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWuzS:
   for srPCUmafQyoYXAjhBJDqEKiVlLWuzd in srPCUmafQyoYXAjhBJDqEKiVlLWuMH(8):
    srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'ndate':srPCUmafQyoYXAjhBJDqEKiVlLWupe,'starttm':srPCUmafQyoYXAjhBJDqEKiVlLWupH[srPCUmafQyoYXAjhBJDqEKiVlLWuzd]['starttm'],'endtm':srPCUmafQyoYXAjhBJDqEKiVlLWupH[srPCUmafQyoYXAjhBJDqEKiVlLWuzd]['endtm']}
    srPCUmafQyoYXAjhBJDqEKiVlLWuzb=srPCUmafQyoYXAjhBJDqEKiVlLWuMz(srPCUmafQyoYXAjhBJDqEKiVlLWupe+srPCUmafQyoYXAjhBJDqEKiVlLWupH[srPCUmafQyoYXAjhBJDqEKiVlLWuzd]['starttm'])
    srPCUmafQyoYXAjhBJDqEKiVlLWuzt=srPCUmafQyoYXAjhBJDqEKiVlLWuMz(srPCUmafQyoYXAjhBJDqEKiVlLWupe+srPCUmafQyoYXAjhBJDqEKiVlLWupH[srPCUmafQyoYXAjhBJDqEKiVlLWuzd]['endtm'])
    if srPCUmafQyoYXAjhBJDqEKiVlLWuzF<=srPCUmafQyoYXAjhBJDqEKiVlLWuzb or(srPCUmafQyoYXAjhBJDqEKiVlLWuzb<srPCUmafQyoYXAjhBJDqEKiVlLWuzF and srPCUmafQyoYXAjhBJDqEKiVlLWuzF<srPCUmafQyoYXAjhBJDqEKiVlLWuzt):
     srPCUmafQyoYXAjhBJDqEKiVlLWuzc.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  return srPCUmafQyoYXAjhBJDqEKiVlLWuzc
 def make_DateList(srPCUmafQyoYXAjhBJDqEKiVlLWupM,days=2,dateType='1'):
  srPCUmafQyoYXAjhBJDqEKiVlLWuzS=[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuzn =srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_Now_Datetime()
  for i in srPCUmafQyoYXAjhBJDqEKiVlLWuMH(days):
   srPCUmafQyoYXAjhBJDqEKiVlLWuzN=srPCUmafQyoYXAjhBJDqEKiVlLWuzn+datetime.timedelta(days=i)
   if dateType=='1':
    srPCUmafQyoYXAjhBJDqEKiVlLWuzS.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzN.strftime('%Y-%m-%d'))
   else:
    srPCUmafQyoYXAjhBJDqEKiVlLWuzS.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzN.strftime('%Y%m%d'))
  return srPCUmafQyoYXAjhBJDqEKiVlLWuzS
 def make_Tving_ChannleGroup(srPCUmafQyoYXAjhBJDqEKiVlLWupM,srPCUmafQyoYXAjhBJDqEKiVlLWuzT):
  srPCUmafQyoYXAjhBJDqEKiVlLWuzG=[]
  i=0
  srPCUmafQyoYXAjhBJDqEKiVlLWuzx=''
  for srPCUmafQyoYXAjhBJDqEKiVlLWuze in srPCUmafQyoYXAjhBJDqEKiVlLWuzT:
   if i==0:srPCUmafQyoYXAjhBJDqEKiVlLWuzx=srPCUmafQyoYXAjhBJDqEKiVlLWuze
   else:srPCUmafQyoYXAjhBJDqEKiVlLWuzx+=',%s'%(srPCUmafQyoYXAjhBJDqEKiVlLWuze)
   i+=1
   if i>=srPCUmafQyoYXAjhBJDqEKiVlLWupM.LIMIT_TVINGEPG:
    srPCUmafQyoYXAjhBJDqEKiVlLWuzG.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzx)
    i=0
    srPCUmafQyoYXAjhBJDqEKiVlLWuzx=''
  if srPCUmafQyoYXAjhBJDqEKiVlLWuzx!='':
   srPCUmafQyoYXAjhBJDqEKiVlLWuzG.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzx)
  return srPCUmafQyoYXAjhBJDqEKiVlLWuzG
 def Get_ChannelImg_Tving(srPCUmafQyoYXAjhBJDqEKiVlLWupM,chid_list):
  srPCUmafQyoYXAjhBJDqEKiVlLWuzH={}
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWuzO=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_Now_Datetime().strftime('%Y%m%d')
   srPCUmafQyoYXAjhBJDqEKiVlLWuzI =srPCUmafQyoYXAjhBJDqEKiVlLWupH[6]['starttm'] 
   srPCUmafQyoYXAjhBJDqEKiVlLWuzM =srPCUmafQyoYXAjhBJDqEKiVlLWupH[6]['endtm']
   srPCUmafQyoYXAjhBJDqEKiVlLWuzG=srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_Tving_ChannleGroup(chid_list)
   for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWuzG:
    srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_TVING+'/v2/media/schedules'
    srPCUmafQyoYXAjhBJDqEKiVlLWupS={'pageNo':'1','pageSize':srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupM.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':srPCUmafQyoYXAjhBJDqEKiVlLWuzO,'broadcastDate':srPCUmafQyoYXAjhBJDqEKiVlLWuzO,'startBroadTime':srPCUmafQyoYXAjhBJDqEKiVlLWuzI,'endBroadTime':srPCUmafQyoYXAjhBJDqEKiVlLWuzM,'channelCode':srPCUmafQyoYXAjhBJDqEKiVlLWupe}
    srPCUmafQyoYXAjhBJDqEKiVlLWupS.update(srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_DefaultParams_Tving())
    srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWupS,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
    srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
    if not('result' in srPCUmafQyoYXAjhBJDqEKiVlLWupG['body']):return{}
    srPCUmafQyoYXAjhBJDqEKiVlLWupx=srPCUmafQyoYXAjhBJDqEKiVlLWupG['body']['result']
    for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupx:
     for srPCUmafQyoYXAjhBJDqEKiVlLWuzR in srPCUmafQyoYXAjhBJDqEKiVlLWupe['image']:
      if srPCUmafQyoYXAjhBJDqEKiVlLWuzR['code']=='CAIC0400':srPCUmafQyoYXAjhBJDqEKiVlLWuzH[srPCUmafQyoYXAjhBJDqEKiVlLWupe['channel_code']]=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_TVINGIMG+srPCUmafQyoYXAjhBJDqEKiVlLWuzR['url']
      elif srPCUmafQyoYXAjhBJDqEKiVlLWuzR['code']=='CAIC1400':srPCUmafQyoYXAjhBJDqEKiVlLWuzH[srPCUmafQyoYXAjhBJDqEKiVlLWupe['channel_code']]=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_TVINGIMG+srPCUmafQyoYXAjhBJDqEKiVlLWuzR['url']
      elif srPCUmafQyoYXAjhBJDqEKiVlLWuzR['code']=='CAIC1900':srPCUmafQyoYXAjhBJDqEKiVlLWuzH[srPCUmafQyoYXAjhBJDqEKiVlLWupe['channel_code']]=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_TVINGIMG+srPCUmafQyoYXAjhBJDqEKiVlLWuzR['url']
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return{}
  return srPCUmafQyoYXAjhBJDqEKiVlLWuzH
 def Get_EpgInfo_Spotv(srPCUmafQyoYXAjhBJDqEKiVlLWupM,days=2,payyn=srPCUmafQyoYXAjhBJDqEKiVlLWuMp):
  srPCUmafQyoYXAjhBJDqEKiVlLWupb=[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuzg =[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuzS=srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_DateList(days=days,dateType='1')
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_SPOTV+'/api/v3/channel'
   srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
   srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
   for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupG:
    srPCUmafQyoYXAjhBJDqEKiVlLWupO =srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupe['id'])
    srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupO,'channelnm':srPCUmafQyoYXAjhBJDqEKiVlLWupM.xmlText(srPCUmafQyoYXAjhBJDqEKiVlLWupe['name']),'channelimg':srPCUmafQyoYXAjhBJDqEKiVlLWupe['logo'],'ott':'spotv'}
    srPCUmafQyoYXAjhBJDqEKiVlLWupb.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[],[]
  try:
   for srPCUmafQyoYXAjhBJDqEKiVlLWuzv in srPCUmafQyoYXAjhBJDqEKiVlLWuzS:
    srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_SPOTV+'/api/v3/program/'+srPCUmafQyoYXAjhBJDqEKiVlLWuzv
    srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
    srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
    for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupG:
     srPCUmafQyoYXAjhBJDqEKiVlLWupO =srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupe['channelId'])
     srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupO,'title':srPCUmafQyoYXAjhBJDqEKiVlLWupM.xmlText(srPCUmafQyoYXAjhBJDqEKiVlLWupe['title']),'startTime':srPCUmafQyoYXAjhBJDqEKiVlLWupe['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':srPCUmafQyoYXAjhBJDqEKiVlLWupe['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     srPCUmafQyoYXAjhBJDqEKiVlLWuzg.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
    time.sleep(srPCUmafQyoYXAjhBJDqEKiVlLWupM.SLEEP_TIME)
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[],[]
  '''
  try:
   for i_channel in channel_list:
    if i_channel['epgtype'] == 'spotvon':
     tmp_list = self.Get_EpgInfo_Spotv_spotvon(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    if i_channel['epgtype'] == 'spotvnet':
     tmp_list = self.Get_EpgInfo_Spotv_spotvnet(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  return srPCUmafQyoYXAjhBJDqEKiVlLWupb,srPCUmafQyoYXAjhBJDqEKiVlLWuzg
 def Get_EpgInfo_Spotv_spotvon(srPCUmafQyoYXAjhBJDqEKiVlLWupM,srPCUmafQyoYXAjhBJDqEKiVlLWupO,epgnm,days):
  srPCUmafQyoYXAjhBJDqEKiVlLWuzg =[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuzS=srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_DateList(days=days,dateType='1')
  srPCUmafQyoYXAjhBJDqEKiVlLWuHp=''
  try:
   for srPCUmafQyoYXAjhBJDqEKiVlLWuzv in srPCUmafQyoYXAjhBJDqEKiVlLWuzS:
    srPCUmafQyoYXAjhBJDqEKiVlLWupn='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,srPCUmafQyoYXAjhBJDqEKiVlLWuzv)
    srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
    srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
    for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupG:
     srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupO,'title':srPCUmafQyoYXAjhBJDqEKiVlLWupM.xmlText(srPCUmafQyoYXAjhBJDqEKiVlLWupe['title']),'startTime':srPCUmafQyoYXAjhBJDqEKiVlLWupe['sch_date'].replace('-','')+srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupe['sch_hour']).zfill(2)+srPCUmafQyoYXAjhBJDqEKiVlLWupe['sch_min']+'00','ott':'spotv'}
     srPCUmafQyoYXAjhBJDqEKiVlLWuzg.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
    srPCUmafQyoYXAjhBJDqEKiVlLWuHp=srPCUmafQyoYXAjhBJDqEKiVlLWuzv
   for i in srPCUmafQyoYXAjhBJDqEKiVlLWuMH(srPCUmafQyoYXAjhBJDqEKiVlLWuMI(srPCUmafQyoYXAjhBJDqEKiVlLWuzg)):
    if i>0:srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i-1]['endTime']=srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i]['startTime']
    if i==srPCUmafQyoYXAjhBJDqEKiVlLWuMI(srPCUmafQyoYXAjhBJDqEKiVlLWuzg)-1: srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i]['endTime']=srPCUmafQyoYXAjhBJDqEKiVlLWuHp+'240000'
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[]
  return srPCUmafQyoYXAjhBJDqEKiVlLWuzg
 def Get_EpgInfo_Spotv_spotvnet(srPCUmafQyoYXAjhBJDqEKiVlLWupM,srPCUmafQyoYXAjhBJDqEKiVlLWupO,epgnm,days):
  srPCUmafQyoYXAjhBJDqEKiVlLWuzg =[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuzS=srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_DateList(days=days,dateType='1')
  srPCUmafQyoYXAjhBJDqEKiVlLWuHp=''
  try:
   for srPCUmafQyoYXAjhBJDqEKiVlLWuzv in srPCUmafQyoYXAjhBJDqEKiVlLWuzS:
    srPCUmafQyoYXAjhBJDqEKiVlLWupn='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,srPCUmafQyoYXAjhBJDqEKiVlLWuzv)
    srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
    srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
    for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupG:
     srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupO,'title':srPCUmafQyoYXAjhBJDqEKiVlLWupM.xmlText(srPCUmafQyoYXAjhBJDqEKiVlLWupe['title']),'startTime':srPCUmafQyoYXAjhBJDqEKiVlLWupe['sch_date'].replace('-','')+srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupe['sch_hour']).zfill(2)+srPCUmafQyoYXAjhBJDqEKiVlLWupe['sch_min']+'00','ott':'spotv'}
     srPCUmafQyoYXAjhBJDqEKiVlLWuzg.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
    srPCUmafQyoYXAjhBJDqEKiVlLWuHp=srPCUmafQyoYXAjhBJDqEKiVlLWuzv
   for i in srPCUmafQyoYXAjhBJDqEKiVlLWuMH(srPCUmafQyoYXAjhBJDqEKiVlLWuMI(srPCUmafQyoYXAjhBJDqEKiVlLWuzg)):
    if i>0:srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i-1]['endTime']=srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i]['startTime']
    if i==srPCUmafQyoYXAjhBJDqEKiVlLWuMI(srPCUmafQyoYXAjhBJDqEKiVlLWuzg)-1: srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i]['endTime']=srPCUmafQyoYXAjhBJDqEKiVlLWuHp+'240000'
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[]
  return srPCUmafQyoYXAjhBJDqEKiVlLWuzg
 def Make_Wavve_TimeList(srPCUmafQyoYXAjhBJDqEKiVlLWupM,days=2):
  srPCUmafQyoYXAjhBJDqEKiVlLWuzc=[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuHz=[['00:00','03:00'],['03:00','06:00'],['06:00','09:00'],['09:00','12:00'],['12:00','15:00'],['15:00','18:00'],['18:00','21:00'],['21:00','24:00'],]
  srPCUmafQyoYXAjhBJDqEKiVlLWuHI =srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_Now_Datetime()
  for i in srPCUmafQyoYXAjhBJDqEKiVlLWuMH(days):
   srPCUmafQyoYXAjhBJDqEKiVlLWuHM =srPCUmafQyoYXAjhBJDqEKiVlLWuHI+datetime.timedelta(days=+i)
   srPCUmafQyoYXAjhBJDqEKiVlLWuHk =srPCUmafQyoYXAjhBJDqEKiVlLWuHM.strftime('%Y-%m-%d')
   for srPCUmafQyoYXAjhBJDqEKiVlLWuHT in srPCUmafQyoYXAjhBJDqEKiVlLWuHz:
    srPCUmafQyoYXAjhBJDqEKiVlLWuHw=['{} {}'.format(srPCUmafQyoYXAjhBJDqEKiVlLWuHk,srPCUmafQyoYXAjhBJDqEKiVlLWuHT[0]),'{} {}'.format(srPCUmafQyoYXAjhBJDqEKiVlLWuHk,srPCUmafQyoYXAjhBJDqEKiVlLWuHT[1]),]
    srPCUmafQyoYXAjhBJDqEKiVlLWuzc.append(srPCUmafQyoYXAjhBJDqEKiVlLWuHw)
  return srPCUmafQyoYXAjhBJDqEKiVlLWuzc
 def Get_EpgInfo_Wavve(srPCUmafQyoYXAjhBJDqEKiVlLWupM,days=2,exceptGroup=[]):
  srPCUmafQyoYXAjhBJDqEKiVlLWupb =[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuzg =[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuzc=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Make_Wavve_TimeList(days)
  try:
   for srPCUmafQyoYXAjhBJDqEKiVlLWuHT in srPCUmafQyoYXAjhBJDqEKiVlLWuzc:
    srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_WAVVE+'/live/epgs'
    srPCUmafQyoYXAjhBJDqEKiVlLWupS={'limit':srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupM.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':srPCUmafQyoYXAjhBJDqEKiVlLWuHT[0],'enddatetime':srPCUmafQyoYXAjhBJDqEKiVlLWuHT[1],}
    srPCUmafQyoYXAjhBJDqEKiVlLWupS.update(srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_DefaultParams_Wavve())
    srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWupS,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
    srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
    srPCUmafQyoYXAjhBJDqEKiVlLWuHc=srPCUmafQyoYXAjhBJDqEKiVlLWupG['list']
    for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWuHc:
     srPCUmafQyoYXAjhBJDqEKiVlLWupO =srPCUmafQyoYXAjhBJDqEKiVlLWupe['channelid']
     srPCUmafQyoYXAjhBJDqEKiVlLWupv=srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_getGenre(srPCUmafQyoYXAjhBJDqEKiVlLWupO,'wavve')
     srPCUmafQyoYXAjhBJDqEKiVlLWupg =srPCUmafQyoYXAjhBJDqEKiVlLWupe['channelimage']
     if not srPCUmafQyoYXAjhBJDqEKiVlLWupg.startswith('http://')and not srPCUmafQyoYXAjhBJDqEKiVlLWupg.startswith('https://'):
      srPCUmafQyoYXAjhBJDqEKiVlLWupg=srPCUmafQyoYXAjhBJDqEKiVlLWupM.HTTPTAG+srPCUmafQyoYXAjhBJDqEKiVlLWupg
     srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupO,'channelnm':srPCUmafQyoYXAjhBJDqEKiVlLWupM.xmlText(srPCUmafQyoYXAjhBJDqEKiVlLWupe['channelname']),'channelimg':srPCUmafQyoYXAjhBJDqEKiVlLWupg,'ott':'wavve'}
     if srPCUmafQyoYXAjhBJDqEKiVlLWupv not in exceptGroup:
      srPCUmafQyoYXAjhBJDqEKiVlLWupb.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
     for srPCUmafQyoYXAjhBJDqEKiVlLWuHS in srPCUmafQyoYXAjhBJDqEKiVlLWupe['list']:
      srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupe['channelid'],'title':srPCUmafQyoYXAjhBJDqEKiVlLWupM.xmlText(srPCUmafQyoYXAjhBJDqEKiVlLWuHS['title']),'startTime':srPCUmafQyoYXAjhBJDqEKiVlLWuHS['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':srPCUmafQyoYXAjhBJDqEKiVlLWuHS['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
      if srPCUmafQyoYXAjhBJDqEKiVlLWupv not in exceptGroup and srPCUmafQyoYXAjhBJDqEKiVlLWuHS['starttime']!=srPCUmafQyoYXAjhBJDqEKiVlLWuHS['endtime']:
       srPCUmafQyoYXAjhBJDqEKiVlLWuzg.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[],[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuHF=srPCUmafQyoYXAjhBJDqEKiVlLWuMI(srPCUmafQyoYXAjhBJDqEKiVlLWuzg)
  for i in(srPCUmafQyoYXAjhBJDqEKiVlLWuMH(1,srPCUmafQyoYXAjhBJDqEKiVlLWuHF)):
   if srPCUmafQyoYXAjhBJDqEKiVlLWuMz(srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i-1]['endTime'])+1==srPCUmafQyoYXAjhBJDqEKiVlLWuMz(srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i]['startTime'])and srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i-1]['channelid']==srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i]['channelid']:
    srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i-1]['endTime']=srPCUmafQyoYXAjhBJDqEKiVlLWuzg[i]['startTime']
  return srPCUmafQyoYXAjhBJDqEKiVlLWupb,srPCUmafQyoYXAjhBJDqEKiVlLWuzg
 def Get_EpgInfo_Tving(srPCUmafQyoYXAjhBJDqEKiVlLWupM,days=2):
  srPCUmafQyoYXAjhBJDqEKiVlLWupb=[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuzg =[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuHd =[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuHb =srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_EpgDatetime_Tving(days=days)
  srPCUmafQyoYXAjhBJDqEKiVlLWupb =srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_ChannelList_Tving()
  srPCUmafQyoYXAjhBJDqEKiVlLWuHt=[]
  for i in srPCUmafQyoYXAjhBJDqEKiVlLWuMH(srPCUmafQyoYXAjhBJDqEKiVlLWuMI(srPCUmafQyoYXAjhBJDqEKiVlLWupb)):
   srPCUmafQyoYXAjhBJDqEKiVlLWupb[i]['channelnm']=srPCUmafQyoYXAjhBJDqEKiVlLWupM.xmlText(srPCUmafQyoYXAjhBJDqEKiVlLWupb[i]['channelnm'])
   srPCUmafQyoYXAjhBJDqEKiVlLWuHt.append(srPCUmafQyoYXAjhBJDqEKiVlLWupb[i]['channelid'])
  srPCUmafQyoYXAjhBJDqEKiVlLWuHn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_Tving_ChannleGroup(srPCUmafQyoYXAjhBJDqEKiVlLWuHt)
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_TVING+'/v2/media/schedules'
   for srPCUmafQyoYXAjhBJDqEKiVlLWuHT in srPCUmafQyoYXAjhBJDqEKiVlLWuHb:
    for srPCUmafQyoYXAjhBJDqEKiVlLWuHN in srPCUmafQyoYXAjhBJDqEKiVlLWuHn:
     srPCUmafQyoYXAjhBJDqEKiVlLWupS={'pageNo':'1','pageSize':srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWupM.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':srPCUmafQyoYXAjhBJDqEKiVlLWuHT['ndate'],'broadcastDate':srPCUmafQyoYXAjhBJDqEKiVlLWuHT['ndate'],'startBroadTime':srPCUmafQyoYXAjhBJDqEKiVlLWuHT['starttm'],'endBroadTime':srPCUmafQyoYXAjhBJDqEKiVlLWuHT['endtm'],'channelCode':srPCUmafQyoYXAjhBJDqEKiVlLWuHN}
     srPCUmafQyoYXAjhBJDqEKiVlLWupS.update(srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_DefaultParams_Tving())
     srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWupS,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
     srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
     srPCUmafQyoYXAjhBJDqEKiVlLWupx=srPCUmafQyoYXAjhBJDqEKiVlLWupG['body']['result']
     for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupx:
      if 'schedules' not in srPCUmafQyoYXAjhBJDqEKiVlLWupe:continue
      if srPCUmafQyoYXAjhBJDqEKiVlLWupe['schedules']==srPCUmafQyoYXAjhBJDqEKiVlLWuIO:continue
      for srPCUmafQyoYXAjhBJDqEKiVlLWuHG in srPCUmafQyoYXAjhBJDqEKiVlLWupe['schedules']:
       srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWuHG['schedule_code'],'title':srPCUmafQyoYXAjhBJDqEKiVlLWupM.xmlText(srPCUmafQyoYXAjhBJDqEKiVlLWuHG['program']['name']['ko']),'startTime':srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWuHG['broadcast_start_time']),'endTime':srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWuHG['broadcast_end_time']),'ott':'tving'}
       srPCUmafQyoYXAjhBJDqEKiVlLWuHx=srPCUmafQyoYXAjhBJDqEKiVlLWuHG['schedule_code']+srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWuHG['broadcast_start_time'])
       if srPCUmafQyoYXAjhBJDqEKiVlLWuHx in srPCUmafQyoYXAjhBJDqEKiVlLWuHd:continue
       srPCUmafQyoYXAjhBJDqEKiVlLWuHd.append(srPCUmafQyoYXAjhBJDqEKiVlLWuHx)
       srPCUmafQyoYXAjhBJDqEKiVlLWuzg.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
     time.sleep(srPCUmafQyoYXAjhBJDqEKiVlLWupM.SLEEP_TIME)
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[],[]
  return srPCUmafQyoYXAjhBJDqEKiVlLWupb,srPCUmafQyoYXAjhBJDqEKiVlLWuzg
 def Get_BaseInfo_Samsungtv(srPCUmafQyoYXAjhBJDqEKiVlLWupM):
  srPCUmafQyoYXAjhBJDqEKiVlLWuHe={}
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_SAMSUNGTV
   srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuIO)
   for srPCUmafQyoYXAjhBJDqEKiVlLWuHO in srPCUmafQyoYXAjhBJDqEKiVlLWupN.cookies:
    if srPCUmafQyoYXAjhBJDqEKiVlLWuHO.name=='session':
     srPCUmafQyoYXAjhBJDqEKiVlLWuHe['session']=srPCUmafQyoYXAjhBJDqEKiVlLWuHO.value
    elif srPCUmafQyoYXAjhBJDqEKiVlLWuHO.name=='session.sig':
     srPCUmafQyoYXAjhBJDqEKiVlLWuHe['session.sig']=srPCUmafQyoYXAjhBJDqEKiVlLWuHO.value
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return{}
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_SAMSUNGTV+'/user'
   srPCUmafQyoYXAjhBJDqEKiVlLWuHR={'session':srPCUmafQyoYXAjhBJDqEKiVlLWuHe['session'],'session.sig':srPCUmafQyoYXAjhBJDqEKiVlLWuHe['session.sig'],}
   srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuHR)
   srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
   srPCUmafQyoYXAjhBJDqEKiVlLWuHe['countryCode']=srPCUmafQyoYXAjhBJDqEKiVlLWupG.get('countryCode')
   srPCUmafQyoYXAjhBJDqEKiVlLWuHe['uuid'] =srPCUmafQyoYXAjhBJDqEKiVlLWupG.get('uuid')
   srPCUmafQyoYXAjhBJDqEKiVlLWuHe['ip'] =srPCUmafQyoYXAjhBJDqEKiVlLWupG.get('ip')
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return{}
  return srPCUmafQyoYXAjhBJDqEKiVlLWuHe
 def t_Cache(srPCUmafQyoYXAjhBJDqEKiVlLWupM):
  srPCUmafQyoYXAjhBJDqEKiVlLWuzF =srPCUmafQyoYXAjhBJDqEKiVlLWuMz(time.time())
  srPCUmafQyoYXAjhBJDqEKiVlLWuHg=srPCUmafQyoYXAjhBJDqEKiVlLWuMz(srPCUmafQyoYXAjhBJDqEKiVlLWuzF-srPCUmafQyoYXAjhBJDqEKiVlLWuzF%3600)
  return srPCUmafQyoYXAjhBJDqEKiVlLWuHg,srPCUmafQyoYXAjhBJDqEKiVlLWuzF
 def zlib_compress(srPCUmafQyoYXAjhBJDqEKiVlLWupM,plaintext):
  srPCUmafQyoYXAjhBJDqEKiVlLWuHv=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(srPCUmafQyoYXAjhBJDqEKiVlLWuHv).decode('utf-8')
 def Get_BaseRequest_Samsungtv(srPCUmafQyoYXAjhBJDqEKiVlLWupM,srPCUmafQyoYXAjhBJDqEKiVlLWuHe):
  srPCUmafQyoYXAjhBJDqEKiVlLWupG={}
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupn=srPCUmafQyoYXAjhBJDqEKiVlLWupM.API_SAMSUNGTV+'/api/lives'
   srPCUmafQyoYXAjhBJDqEKiVlLWuHg,srPCUmafQyoYXAjhBJDqEKiVlLWuzF=srPCUmafQyoYXAjhBJDqEKiVlLWupM.t_Cache()
   srPCUmafQyoYXAjhBJDqEKiVlLWuIp=srPCUmafQyoYXAjhBJDqEKiVlLWupM.zlib_compress(srPCUmafQyoYXAjhBJDqEKiVlLWuHe['uuid']+':'+srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWuzF))
   srPCUmafQyoYXAjhBJDqEKiVlLWuHR={'session':srPCUmafQyoYXAjhBJDqEKiVlLWuHe['session'],'session.sig':srPCUmafQyoYXAjhBJDqEKiVlLWuHe['session.sig'],}
   srPCUmafQyoYXAjhBJDqEKiVlLWupS ={'t':srPCUmafQyoYXAjhBJDqEKiVlLWuIR(srPCUmafQyoYXAjhBJDqEKiVlLWuHg)}
   srPCUmafQyoYXAjhBJDqEKiVlLWuIz ={'x-cred-payload':srPCUmafQyoYXAjhBJDqEKiVlLWuIp}
   srPCUmafQyoYXAjhBJDqEKiVlLWupN=srPCUmafQyoYXAjhBJDqEKiVlLWupM.callRequestCookies('Get',srPCUmafQyoYXAjhBJDqEKiVlLWupn,payload=srPCUmafQyoYXAjhBJDqEKiVlLWuIO,params=srPCUmafQyoYXAjhBJDqEKiVlLWupS,headers=srPCUmafQyoYXAjhBJDqEKiVlLWuIz,cookies=srPCUmafQyoYXAjhBJDqEKiVlLWuHR)
   srPCUmafQyoYXAjhBJDqEKiVlLWupG=json.loads(srPCUmafQyoYXAjhBJDqEKiVlLWupN.text)
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
  return srPCUmafQyoYXAjhBJDqEKiVlLWupG
 def Make_Samsungtv_logoUrl(srPCUmafQyoYXAjhBJDqEKiVlLWupM,fullUrl):
  srPCUmafQyoYXAjhBJDqEKiVlLWuIH=urllib.parse.urlparse(fullUrl) 
  if srPCUmafQyoYXAjhBJDqEKiVlLWuIH.netloc=='us-image.samsungtvplus.com':
   srPCUmafQyoYXAjhBJDqEKiVlLWuIM=srPCUmafQyoYXAjhBJDqEKiVlLWuMk(urllib.parse.parse_qsl(srPCUmafQyoYXAjhBJDqEKiVlLWuIH.query))
   if 'url' in srPCUmafQyoYXAjhBJDqEKiVlLWuIM:
    return srPCUmafQyoYXAjhBJDqEKiVlLWuIM.get('url')
  return fullUrl
 def Get_ChannelList_Samsungtv(srPCUmafQyoYXAjhBJDqEKiVlLWupM,srPCUmafQyoYXAjhBJDqEKiVlLWuHe,exceptGroup=[]):
  srPCUmafQyoYXAjhBJDqEKiVlLWupb =[]
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupG=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_BaseRequest_Samsungtv(srPCUmafQyoYXAjhBJDqEKiVlLWuHe)
   srPCUmafQyoYXAjhBJDqEKiVlLWupx=srPCUmafQyoYXAjhBJDqEKiVlLWupG['live']['channel']
   for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWupx:
    srPCUmafQyoYXAjhBJDqEKiVlLWupO =srPCUmafQyoYXAjhBJDqEKiVlLWupe.get('id')
    srPCUmafQyoYXAjhBJDqEKiVlLWupR =srPCUmafQyoYXAjhBJDqEKiVlLWupe.get('name')
    srPCUmafQyoYXAjhBJDqEKiVlLWupg=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Make_Samsungtv_logoUrl(srPCUmafQyoYXAjhBJDqEKiVlLWupe.get('logo'))
    srPCUmafQyoYXAjhBJDqEKiVlLWupv=srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_getGenre(srPCUmafQyoYXAjhBJDqEKiVlLWupO,'samsung')
    if srPCUmafQyoYXAjhBJDqEKiVlLWupv in['-','']:srPCUmafQyoYXAjhBJDqEKiVlLWupv='정주행 채널'
    srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupO,'channelnm':srPCUmafQyoYXAjhBJDqEKiVlLWupR,'channelimg':srPCUmafQyoYXAjhBJDqEKiVlLWupg,'ott':'samsung','genrenm':srPCUmafQyoYXAjhBJDqEKiVlLWupv}
    if srPCUmafQyoYXAjhBJDqEKiVlLWupv not in exceptGroup:
     srPCUmafQyoYXAjhBJDqEKiVlLWupb.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[]
  return srPCUmafQyoYXAjhBJDqEKiVlLWupb
 def Get_EpgInfo_Samsungtv(srPCUmafQyoYXAjhBJDqEKiVlLWupM,srPCUmafQyoYXAjhBJDqEKiVlLWuHe,exceptGroup=[]):
  srPCUmafQyoYXAjhBJDqEKiVlLWupb=[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuzg =[]
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWupG =srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_BaseRequest_Samsungtv(srPCUmafQyoYXAjhBJDqEKiVlLWuHe)
   srPCUmafQyoYXAjhBJDqEKiVlLWupe=srPCUmafQyoYXAjhBJDqEKiVlLWupG['live']['channel']
   for srPCUmafQyoYXAjhBJDqEKiVlLWuHN in srPCUmafQyoYXAjhBJDqEKiVlLWupe:
    srPCUmafQyoYXAjhBJDqEKiVlLWupO =srPCUmafQyoYXAjhBJDqEKiVlLWuHN.get('id')
    srPCUmafQyoYXAjhBJDqEKiVlLWupR =srPCUmafQyoYXAjhBJDqEKiVlLWuHN.get('name')
    srPCUmafQyoYXAjhBJDqEKiVlLWupg=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Make_Samsungtv_logoUrl(srPCUmafQyoYXAjhBJDqEKiVlLWuHN.get('logo'))
    srPCUmafQyoYXAjhBJDqEKiVlLWuHc =srPCUmafQyoYXAjhBJDqEKiVlLWuHN.get('program')
    srPCUmafQyoYXAjhBJDqEKiVlLWupv=srPCUmafQyoYXAjhBJDqEKiVlLWupM.make_getGenre(srPCUmafQyoYXAjhBJDqEKiVlLWupO,'samsung')
    if srPCUmafQyoYXAjhBJDqEKiVlLWupv in exceptGroup:
     continue
    srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupO,'channelnm':srPCUmafQyoYXAjhBJDqEKiVlLWupR,'channelimg':srPCUmafQyoYXAjhBJDqEKiVlLWupg,'ott':'samsung','genrenm':srPCUmafQyoYXAjhBJDqEKiVlLWupv}
    srPCUmafQyoYXAjhBJDqEKiVlLWupb.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
    for srPCUmafQyoYXAjhBJDqEKiVlLWuHS in srPCUmafQyoYXAjhBJDqEKiVlLWuHc:
     srPCUmafQyoYXAjhBJDqEKiVlLWuIk=srPCUmafQyoYXAjhBJDqEKiVlLWuHS.get('start_time')
     srPCUmafQyoYXAjhBJDqEKiVlLWuIT =srPCUmafQyoYXAjhBJDqEKiVlLWuHS.get('duration') 
     srPCUmafQyoYXAjhBJDqEKiVlLWuzI=datetime.datetime.strptime(srPCUmafQyoYXAjhBJDqEKiVlLWuIk,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     srPCUmafQyoYXAjhBJDqEKiVlLWuzM =srPCUmafQyoYXAjhBJDqEKiVlLWuzI+datetime.timedelta(seconds=srPCUmafQyoYXAjhBJDqEKiVlLWuIT)
     srPCUmafQyoYXAjhBJDqEKiVlLWuzp={'channelid':srPCUmafQyoYXAjhBJDqEKiVlLWupO,'title':srPCUmafQyoYXAjhBJDqEKiVlLWupM.xmlText(urllib.parse.unquote_plus(srPCUmafQyoYXAjhBJDqEKiVlLWuHS.get('title'))),'startTime':srPCUmafQyoYXAjhBJDqEKiVlLWuzI.strftime('%Y%m%d%H%M00'),'endTime':srPCUmafQyoYXAjhBJDqEKiVlLWuzM.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     srPCUmafQyoYXAjhBJDqEKiVlLWuzg.append(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  except srPCUmafQyoYXAjhBJDqEKiVlLWuIg as exception:
   srPCUmafQyoYXAjhBJDqEKiVlLWuIv(exception)
   return[],[]
  return srPCUmafQyoYXAjhBJDqEKiVlLWupb,srPCUmafQyoYXAjhBJDqEKiVlLWuzg
 def make_getGenre(srPCUmafQyoYXAjhBJDqEKiVlLWupM,srPCUmafQyoYXAjhBJDqEKiVlLWupO,srPCUmafQyoYXAjhBJDqEKiVlLWuIn):
  try:
   srPCUmafQyoYXAjhBJDqEKiVlLWuzk=srPCUmafQyoYXAjhBJDqEKiVlLWupM.INIT_CHANNEL.get(srPCUmafQyoYXAjhBJDqEKiVlLWupO+'.'+srPCUmafQyoYXAjhBJDqEKiVlLWuIn).get('genre')
  except:
   srPCUmafQyoYXAjhBJDqEKiVlLWuzk=srPCUmafQyoYXAjhBJDqEKiVlLWupM.INIT_CHANNEL.get('-').get('genre')
  return srPCUmafQyoYXAjhBJDqEKiVlLWuzk
 def make_base_allchannel_py(srPCUmafQyoYXAjhBJDqEKiVlLWupM,srPCUmafQyoYXAjhBJDqEKiVlLWuHe):
  srPCUmafQyoYXAjhBJDqEKiVlLWuIw =[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuIc=[]
  srPCUmafQyoYXAjhBJDqEKiVlLWuIS=srPCUmafQyoYXAjhBJDqEKiVlLWuMT()
  srPCUmafQyoYXAjhBJDqEKiVlLWuzp=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_ChannelList_Wavve()
  srPCUmafQyoYXAjhBJDqEKiVlLWuIw.extend(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  srPCUmafQyoYXAjhBJDqEKiVlLWuzp=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_ChannelList_Tving()
  srPCUmafQyoYXAjhBJDqEKiVlLWuIw.extend(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  srPCUmafQyoYXAjhBJDqEKiVlLWuzp=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_ChannelList_Spotv()
  srPCUmafQyoYXAjhBJDqEKiVlLWuIw.extend(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  srPCUmafQyoYXAjhBJDqEKiVlLWuzp=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_ChannelList_Samsungtv(srPCUmafQyoYXAjhBJDqEKiVlLWuHe)
  srPCUmafQyoYXAjhBJDqEKiVlLWuIw.extend(srPCUmafQyoYXAjhBJDqEKiVlLWuzp)
  srPCUmafQyoYXAjhBJDqEKiVlLWuIv('1')
  for i in srPCUmafQyoYXAjhBJDqEKiVlLWuMH(srPCUmafQyoYXAjhBJDqEKiVlLWuMI(srPCUmafQyoYXAjhBJDqEKiVlLWuIw)):
   if srPCUmafQyoYXAjhBJDqEKiVlLWuIw[i]['genrenm']=='-':
    if srPCUmafQyoYXAjhBJDqEKiVlLWuIw[i]['ott']=='wavve':
     srPCUmafQyoYXAjhBJDqEKiVlLWuzk=srPCUmafQyoYXAjhBJDqEKiVlLWupM.Get_ChanneGenrename_Wavve(srPCUmafQyoYXAjhBJDqEKiVlLWuIw[i]['channelid'])
     if srPCUmafQyoYXAjhBJDqEKiVlLWuzk not in srPCUmafQyoYXAjhBJDqEKiVlLWuIS:srPCUmafQyoYXAjhBJDqEKiVlLWuIS.add(srPCUmafQyoYXAjhBJDqEKiVlLWuzk)
     time.sleep(srPCUmafQyoYXAjhBJDqEKiVlLWupM.SLEEP_TIME)
    elif srPCUmafQyoYXAjhBJDqEKiVlLWuIw[i]['ott']=='spotv':
     srPCUmafQyoYXAjhBJDqEKiVlLWuzk='스포츠'
    else:
     srPCUmafQyoYXAjhBJDqEKiVlLWuzk='-'
    srPCUmafQyoYXAjhBJDqEKiVlLWuIw[i]['genrenm']=srPCUmafQyoYXAjhBJDqEKiVlLWuzk
   else:
    if srPCUmafQyoYXAjhBJDqEKiVlLWuIw[i]['genrenm']not in srPCUmafQyoYXAjhBJDqEKiVlLWuIS:srPCUmafQyoYXAjhBJDqEKiVlLWuIS.add(srPCUmafQyoYXAjhBJDqEKiVlLWuIw[i]['genrenm'])
  srPCUmafQyoYXAjhBJDqEKiVlLWuIS.add(srPCUmafQyoYXAjhBJDqEKiVlLWupM.INIT_CHANNEL.get('-').get('genre'))
  srPCUmafQyoYXAjhBJDqEKiVlLWuIv('2')
  for srPCUmafQyoYXAjhBJDqEKiVlLWuIF in srPCUmafQyoYXAjhBJDqEKiVlLWuIS:
   for srPCUmafQyoYXAjhBJDqEKiVlLWuId in srPCUmafQyoYXAjhBJDqEKiVlLWuIw:
    if srPCUmafQyoYXAjhBJDqEKiVlLWuId['genrenm']==srPCUmafQyoYXAjhBJDqEKiVlLWuIF:
     srPCUmafQyoYXAjhBJDqEKiVlLWuIc.append(srPCUmafQyoYXAjhBJDqEKiVlLWuId)
  for srPCUmafQyoYXAjhBJDqEKiVlLWuId in srPCUmafQyoYXAjhBJDqEKiVlLWuIw:
   if srPCUmafQyoYXAjhBJDqEKiVlLWuId['genrenm']not in srPCUmafQyoYXAjhBJDqEKiVlLWuIS:
    srPCUmafQyoYXAjhBJDqEKiVlLWuIc.append(srPCUmafQyoYXAjhBJDqEKiVlLWuId)
  srPCUmafQyoYXAjhBJDqEKiVlLWuIv('3')
  srPCUmafQyoYXAjhBJDqEKiVlLWuIb='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(srPCUmafQyoYXAjhBJDqEKiVlLWuIb):os.remove(srPCUmafQyoYXAjhBJDqEKiVlLWuIb)
  fp=srPCUmafQyoYXAjhBJDqEKiVlLWuMw(srPCUmafQyoYXAjhBJDqEKiVlLWuIb,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  srPCUmafQyoYXAjhBJDqEKiVlLWuIt=srPCUmafQyoYXAjhBJDqEKiVlLWuMI(srPCUmafQyoYXAjhBJDqEKiVlLWuIc)
  i=0
  for srPCUmafQyoYXAjhBJDqEKiVlLWupe in srPCUmafQyoYXAjhBJDqEKiVlLWuIc:
   i+=1
   srPCUmafQyoYXAjhBJDqEKiVlLWupO =srPCUmafQyoYXAjhBJDqEKiVlLWupe['channelid']
   srPCUmafQyoYXAjhBJDqEKiVlLWupR =srPCUmafQyoYXAjhBJDqEKiVlLWupe['channelnm']
   srPCUmafQyoYXAjhBJDqEKiVlLWuIn =srPCUmafQyoYXAjhBJDqEKiVlLWupe['ott']
   srPCUmafQyoYXAjhBJDqEKiVlLWuIN ='%s.%s'%(srPCUmafQyoYXAjhBJDqEKiVlLWupO,srPCUmafQyoYXAjhBJDqEKiVlLWuIn)
   srPCUmafQyoYXAjhBJDqEKiVlLWuzk =srPCUmafQyoYXAjhBJDqEKiVlLWupe['genrenm']
   srPCUmafQyoYXAjhBJDqEKiVlLWuIG='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(srPCUmafQyoYXAjhBJDqEKiVlLWuIN,srPCUmafQyoYXAjhBJDqEKiVlLWupR,srPCUmafQyoYXAjhBJDqEKiVlLWuzk)
   if i<srPCUmafQyoYXAjhBJDqEKiVlLWuIt:
    fp.write(srPCUmafQyoYXAjhBJDqEKiVlLWuIG+',\n')
   else:
    fp.write(srPCUmafQyoYXAjhBJDqEKiVlLWuIG+'\n')
  fp.write('}\n')
  fp.close()
  return srPCUmafQyoYXAjhBJDqEKiVlLWuIS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
