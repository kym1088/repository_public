__author__="NightRain"
oEUfLaGkVApWngCSdrPwtxKbBqDuOI=False
oEUfLaGkVApWngCSdrPwtxKbBqDuOl=object
oEUfLaGkVApWngCSdrPwtxKbBqDuOM=None
oEUfLaGkVApWngCSdrPwtxKbBqDuOs=str
oEUfLaGkVApWngCSdrPwtxKbBqDuOY=Exception
oEUfLaGkVApWngCSdrPwtxKbBqDuOH=print
oEUfLaGkVApWngCSdrPwtxKbBqDuOR=True
oEUfLaGkVApWngCSdrPwtxKbBqDuOj=int
oEUfLaGkVApWngCSdrPwtxKbBqDuOm=range
oEUfLaGkVApWngCSdrPwtxKbBqDuOh=len
oEUfLaGkVApWngCSdrPwtxKbBqDuOJ=set
oEUfLaGkVApWngCSdrPwtxKbBqDuOQ=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
from channelgenre import*
oEUfLaGkVApWngCSdrPwtxKbBqDuyv=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
oEUfLaGkVApWngCSdrPwtxKbBqDuyO=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':oEUfLaGkVApWngCSdrPwtxKbBqDuOI,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':oEUfLaGkVApWngCSdrPwtxKbBqDuOI,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':oEUfLaGkVApWngCSdrPwtxKbBqDuOI,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':oEUfLaGkVApWngCSdrPwtxKbBqDuOI,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':oEUfLaGkVApWngCSdrPwtxKbBqDuOI,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':oEUfLaGkVApWngCSdrPwtxKbBqDuOI,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class oEUfLaGkVApWngCSdrPwtxKbBqDuyN(oEUfLaGkVApWngCSdrPwtxKbBqDuOl):
 def __init__(oEUfLaGkVApWngCSdrPwtxKbBqDuyi):
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_WAVVE ='https://apis.wavve.com'
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_TVING ='https://api.tving.com'
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_TVINGIMG ='https://image.tving.com'
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_SPOTV ='https://www.spotvnow.co.kr'
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.HTTPTAG ='https://'
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.LIMIT_WAVVE =200
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.LIMIT_TVING =60
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.LIMIT_TVINGEPG=20 
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.DEFAULT_HEADER={'user-agent':oEUfLaGkVApWngCSdrPwtxKbBqDuyi.USER_AGENT}
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.SLEEP_TIME =0.2
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.INIT_GENRESORT=MASTER_GENRE
  oEUfLaGkVApWngCSdrPwtxKbBqDuyi.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,jobtype,oEUfLaGkVApWngCSdrPwtxKbBqDuym,payload=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,params=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,cookies=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,redirects=oEUfLaGkVApWngCSdrPwtxKbBqDuOI):
  oEUfLaGkVApWngCSdrPwtxKbBqDuyl=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.DEFAULT_HEADER
  if headers:oEUfLaGkVApWngCSdrPwtxKbBqDuyl.update(headers)
  if jobtype=='Get':
   oEUfLaGkVApWngCSdrPwtxKbBqDuyM=requests.get(oEUfLaGkVApWngCSdrPwtxKbBqDuym,params=params,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuyl,cookies=cookies,allow_redirects=redirects)
  else:
   oEUfLaGkVApWngCSdrPwtxKbBqDuyM=requests.post(oEUfLaGkVApWngCSdrPwtxKbBqDuym,data=payload,params=params,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuyl,cookies=cookies,allow_redirects=redirects)
  return oEUfLaGkVApWngCSdrPwtxKbBqDuyM
 def Get_DefaultParams_Wavve(oEUfLaGkVApWngCSdrPwtxKbBqDuyi):
  oEUfLaGkVApWngCSdrPwtxKbBqDuys={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return oEUfLaGkVApWngCSdrPwtxKbBqDuys
 def Get_DefaultParams_Tving(oEUfLaGkVApWngCSdrPwtxKbBqDuyi):
  oEUfLaGkVApWngCSdrPwtxKbBqDuys={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return oEUfLaGkVApWngCSdrPwtxKbBqDuys
 def Get_Now_Datetime(oEUfLaGkVApWngCSdrPwtxKbBqDuyi):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,in_text):
  oEUfLaGkVApWngCSdrPwtxKbBqDuyH=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return oEUfLaGkVApWngCSdrPwtxKbBqDuyH
 def Get_ChannelList_Wavve(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,exceptGroup=[]):
  oEUfLaGkVApWngCSdrPwtxKbBqDuyR =[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuyj=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_ChannelImg_Wavve()
  try:
   oEUfLaGkVApWngCSdrPwtxKbBqDuym=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_WAVVE+'/cf/live/recommend-channels'
   oEUfLaGkVApWngCSdrPwtxKbBqDuys={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   oEUfLaGkVApWngCSdrPwtxKbBqDuys.update(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_DefaultParams_Wavve())
   oEUfLaGkVApWngCSdrPwtxKbBqDuyh=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.callRequestCookies('Get',oEUfLaGkVApWngCSdrPwtxKbBqDuym,payload=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,params=oEUfLaGkVApWngCSdrPwtxKbBqDuys,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,cookies=oEUfLaGkVApWngCSdrPwtxKbBqDuOM)
   oEUfLaGkVApWngCSdrPwtxKbBqDuyJ=json.loads(oEUfLaGkVApWngCSdrPwtxKbBqDuyh.text)
   if not('celllist' in oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['cell_toplist']):return oEUfLaGkVApWngCSdrPwtxKbBqDuyR
   oEUfLaGkVApWngCSdrPwtxKbBqDuyQ=oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['cell_toplist']['celllist']
   for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuyQ:
    oEUfLaGkVApWngCSdrPwtxKbBqDuyF=oEUfLaGkVApWngCSdrPwtxKbBqDuyc['contentid']
    oEUfLaGkVApWngCSdrPwtxKbBqDuyz=oEUfLaGkVApWngCSdrPwtxKbBqDuyc['title_list'][0]['text']
    if oEUfLaGkVApWngCSdrPwtxKbBqDuyF in oEUfLaGkVApWngCSdrPwtxKbBqDuyj:
     oEUfLaGkVApWngCSdrPwtxKbBqDuyT=oEUfLaGkVApWngCSdrPwtxKbBqDuyj[oEUfLaGkVApWngCSdrPwtxKbBqDuyF]
    else:
     oEUfLaGkVApWngCSdrPwtxKbBqDuyT=''
    oEUfLaGkVApWngCSdrPwtxKbBqDuyX=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.make_getGenre(oEUfLaGkVApWngCSdrPwtxKbBqDuyF,'wavve')
    oEUfLaGkVApWngCSdrPwtxKbBqDuNy={'channelid':oEUfLaGkVApWngCSdrPwtxKbBqDuyF,'channelnm':oEUfLaGkVApWngCSdrPwtxKbBqDuyz,'channelimg':oEUfLaGkVApWngCSdrPwtxKbBqDuyi.HTTPTAG+oEUfLaGkVApWngCSdrPwtxKbBqDuyT if oEUfLaGkVApWngCSdrPwtxKbBqDuyT!='' else '','ott':'wavve','genrenm':oEUfLaGkVApWngCSdrPwtxKbBqDuyX}
    if oEUfLaGkVApWngCSdrPwtxKbBqDuyX not in exceptGroup:
     oEUfLaGkVApWngCSdrPwtxKbBqDuyR.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return[]
  return oEUfLaGkVApWngCSdrPwtxKbBqDuyR
 def Get_ChannelList_WavveExcept(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,exceptGroup=[]):
  oEUfLaGkVApWngCSdrPwtxKbBqDuyR=[]
  if exceptGroup==[]:return[]
  try:
   oEUfLaGkVApWngCSdrPwtxKbBqDuym=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_WAVVE+'/cf/live/recommend-channels'
   for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in exceptGroup:
    oEUfLaGkVApWngCSdrPwtxKbBqDuys={'WeekDay':'all','adult':'n','broadcastid':oEUfLaGkVApWngCSdrPwtxKbBqDuyc['broadcastid'],'contenttype':'channel','genre':oEUfLaGkVApWngCSdrPwtxKbBqDuyc['genre'],'isrecommend':'y','limit':oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    oEUfLaGkVApWngCSdrPwtxKbBqDuys.update(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_DefaultParams_Wavve())
    oEUfLaGkVApWngCSdrPwtxKbBqDuyh=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.callRequestCookies('Get',oEUfLaGkVApWngCSdrPwtxKbBqDuym,payload=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,params=oEUfLaGkVApWngCSdrPwtxKbBqDuys,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,cookies=oEUfLaGkVApWngCSdrPwtxKbBqDuOM)
    oEUfLaGkVApWngCSdrPwtxKbBqDuyJ=json.loads(oEUfLaGkVApWngCSdrPwtxKbBqDuyh.text)
    if not('celllist' in oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['cell_toplist']):return oEUfLaGkVApWngCSdrPwtxKbBqDuyR
    oEUfLaGkVApWngCSdrPwtxKbBqDuyQ=oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['cell_toplist']['celllist']
    for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuyQ:
     oEUfLaGkVApWngCSdrPwtxKbBqDuyR.append(oEUfLaGkVApWngCSdrPwtxKbBqDuyc['contentid'])
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return[]
  return oEUfLaGkVApWngCSdrPwtxKbBqDuyR
 def Get_ChannelImg_Wavve(oEUfLaGkVApWngCSdrPwtxKbBqDuyi):
  oEUfLaGkVApWngCSdrPwtxKbBqDuNv={}
  try:
   oEUfLaGkVApWngCSdrPwtxKbBqDuNO=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_Now_Datetime()
   oEUfLaGkVApWngCSdrPwtxKbBqDuNi =oEUfLaGkVApWngCSdrPwtxKbBqDuNO+datetime.timedelta(hours=3)
   oEUfLaGkVApWngCSdrPwtxKbBqDuym=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_WAVVE+'/live/epgs'
   oEUfLaGkVApWngCSdrPwtxKbBqDuys={'limit':oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':oEUfLaGkVApWngCSdrPwtxKbBqDuNO.strftime('%Y-%m-%d %H:00'),'enddatetime':oEUfLaGkVApWngCSdrPwtxKbBqDuNi.strftime('%Y-%m-%d %H:00')}
   oEUfLaGkVApWngCSdrPwtxKbBqDuys.update(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_DefaultParams_Wavve())
   oEUfLaGkVApWngCSdrPwtxKbBqDuyh=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.callRequestCookies('Get',oEUfLaGkVApWngCSdrPwtxKbBqDuym,payload=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,params=oEUfLaGkVApWngCSdrPwtxKbBqDuys,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,cookies=oEUfLaGkVApWngCSdrPwtxKbBqDuOM)
   oEUfLaGkVApWngCSdrPwtxKbBqDuyJ=json.loads(oEUfLaGkVApWngCSdrPwtxKbBqDuyh.text)
   oEUfLaGkVApWngCSdrPwtxKbBqDuyQ=oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['list']
   for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuyQ:
    oEUfLaGkVApWngCSdrPwtxKbBqDuNv[oEUfLaGkVApWngCSdrPwtxKbBqDuyc['channelid']]=oEUfLaGkVApWngCSdrPwtxKbBqDuyc['channelimage']
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
  return oEUfLaGkVApWngCSdrPwtxKbBqDuNv
 def Get_ChanneGenrename_Wavve(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,oEUfLaGkVApWngCSdrPwtxKbBqDuyF):
  try:
   oEUfLaGkVApWngCSdrPwtxKbBqDuym=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_WAVVE+'/live/channels/'+oEUfLaGkVApWngCSdrPwtxKbBqDuyF
   oEUfLaGkVApWngCSdrPwtxKbBqDuys=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_DefaultParams_Wavve()
   oEUfLaGkVApWngCSdrPwtxKbBqDuyh=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.callRequestCookies('Get',oEUfLaGkVApWngCSdrPwtxKbBqDuym,payload=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,params=oEUfLaGkVApWngCSdrPwtxKbBqDuys,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,cookies=oEUfLaGkVApWngCSdrPwtxKbBqDuOM)
   oEUfLaGkVApWngCSdrPwtxKbBqDuyJ=json.loads(oEUfLaGkVApWngCSdrPwtxKbBqDuyh.text)
   oEUfLaGkVApWngCSdrPwtxKbBqDuNe=oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['genretext']
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return ''
  return oEUfLaGkVApWngCSdrPwtxKbBqDuNe
 def Get_ChannelList_Spotv(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,payyn=oEUfLaGkVApWngCSdrPwtxKbBqDuOR):
  oEUfLaGkVApWngCSdrPwtxKbBqDuyR=[]
  try:
   for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuyO:
    oEUfLaGkVApWngCSdrPwtxKbBqDuyF=oEUfLaGkVApWngCSdrPwtxKbBqDuyc['videoId']
    oEUfLaGkVApWngCSdrPwtxKbBqDuNy={'channelid':oEUfLaGkVApWngCSdrPwtxKbBqDuyF,'channelnm':oEUfLaGkVApWngCSdrPwtxKbBqDuyc['name'],'channelimg':oEUfLaGkVApWngCSdrPwtxKbBqDuyc['logo'],'ott':'spotv','genrenm':oEUfLaGkVApWngCSdrPwtxKbBqDuyi.make_getGenre(oEUfLaGkVApWngCSdrPwtxKbBqDuyF,'spotv')}
    if payyn==oEUfLaGkVApWngCSdrPwtxKbBqDuOR or oEUfLaGkVApWngCSdrPwtxKbBqDuyc['free']==oEUfLaGkVApWngCSdrPwtxKbBqDuOR:
     oEUfLaGkVApWngCSdrPwtxKbBqDuyR.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return[]
  return oEUfLaGkVApWngCSdrPwtxKbBqDuyR
 def Get_ChannelList_Tving(oEUfLaGkVApWngCSdrPwtxKbBqDuyi):
  oEUfLaGkVApWngCSdrPwtxKbBqDuyR =[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuNI=[]
  try:
   oEUfLaGkVApWngCSdrPwtxKbBqDuym=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_TVING+'/v2/media/lives'
   oEUfLaGkVApWngCSdrPwtxKbBqDuys={'pageNo':'1','pageSize':oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   oEUfLaGkVApWngCSdrPwtxKbBqDuys.update(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_DefaultParams_Tving())
   oEUfLaGkVApWngCSdrPwtxKbBqDuyh=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.callRequestCookies('Get',oEUfLaGkVApWngCSdrPwtxKbBqDuym,payload=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,params=oEUfLaGkVApWngCSdrPwtxKbBqDuys,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,cookies=oEUfLaGkVApWngCSdrPwtxKbBqDuOM)
   oEUfLaGkVApWngCSdrPwtxKbBqDuyJ=json.loads(oEUfLaGkVApWngCSdrPwtxKbBqDuyh.text)
   if not('result' in oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['body']):return oEUfLaGkVApWngCSdrPwtxKbBqDuyR
   oEUfLaGkVApWngCSdrPwtxKbBqDuyQ=oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['body']['result']
   for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuyQ:
    if oEUfLaGkVApWngCSdrPwtxKbBqDuyc['live_code']=='C44441':continue 
    oEUfLaGkVApWngCSdrPwtxKbBqDuNI.append(oEUfLaGkVApWngCSdrPwtxKbBqDuyc['live_code'])
   oEUfLaGkVApWngCSdrPwtxKbBqDuyj=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_ChannelImg_Tving(oEUfLaGkVApWngCSdrPwtxKbBqDuNI)
   for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuyQ:
    oEUfLaGkVApWngCSdrPwtxKbBqDuyF=oEUfLaGkVApWngCSdrPwtxKbBqDuyc['live_code']
    if oEUfLaGkVApWngCSdrPwtxKbBqDuyF=='C44441':continue 
    oEUfLaGkVApWngCSdrPwtxKbBqDuyz=oEUfLaGkVApWngCSdrPwtxKbBqDuyc['schedule']['channel']['name']['ko']
    if oEUfLaGkVApWngCSdrPwtxKbBqDuyF in oEUfLaGkVApWngCSdrPwtxKbBqDuyj:
     oEUfLaGkVApWngCSdrPwtxKbBqDuyT=oEUfLaGkVApWngCSdrPwtxKbBqDuyj[oEUfLaGkVApWngCSdrPwtxKbBqDuyF]
    else:
     oEUfLaGkVApWngCSdrPwtxKbBqDuyT=''
    oEUfLaGkVApWngCSdrPwtxKbBqDuNy={'channelid':oEUfLaGkVApWngCSdrPwtxKbBqDuyF,'channelnm':oEUfLaGkVApWngCSdrPwtxKbBqDuyz,'channelimg':oEUfLaGkVApWngCSdrPwtxKbBqDuyT,'ott':'tving','genrenm':oEUfLaGkVApWngCSdrPwtxKbBqDuyi.make_getGenre(oEUfLaGkVApWngCSdrPwtxKbBqDuyF,'tving')}
    oEUfLaGkVApWngCSdrPwtxKbBqDuyR.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return[]
  return oEUfLaGkVApWngCSdrPwtxKbBqDuyR
 def make_EpgDatetime_Tving(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,days=2):
  oEUfLaGkVApWngCSdrPwtxKbBqDuNl=[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuNM=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.make_DateList(days=2,dateType='2')
  oEUfLaGkVApWngCSdrPwtxKbBqDuNs=oEUfLaGkVApWngCSdrPwtxKbBqDuOj(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuNM:
   for oEUfLaGkVApWngCSdrPwtxKbBqDuNY in oEUfLaGkVApWngCSdrPwtxKbBqDuOm(8):
    oEUfLaGkVApWngCSdrPwtxKbBqDuNy={'ndate':oEUfLaGkVApWngCSdrPwtxKbBqDuyc,'starttm':oEUfLaGkVApWngCSdrPwtxKbBqDuyv[oEUfLaGkVApWngCSdrPwtxKbBqDuNY]['starttm'],'endtm':oEUfLaGkVApWngCSdrPwtxKbBqDuyv[oEUfLaGkVApWngCSdrPwtxKbBqDuNY]['endtm']}
    oEUfLaGkVApWngCSdrPwtxKbBqDuNH=oEUfLaGkVApWngCSdrPwtxKbBqDuOj(oEUfLaGkVApWngCSdrPwtxKbBqDuyc+oEUfLaGkVApWngCSdrPwtxKbBqDuyv[oEUfLaGkVApWngCSdrPwtxKbBqDuNY]['starttm'])
    oEUfLaGkVApWngCSdrPwtxKbBqDuNR=oEUfLaGkVApWngCSdrPwtxKbBqDuOj(oEUfLaGkVApWngCSdrPwtxKbBqDuyc+oEUfLaGkVApWngCSdrPwtxKbBqDuyv[oEUfLaGkVApWngCSdrPwtxKbBqDuNY]['endtm'])
    if oEUfLaGkVApWngCSdrPwtxKbBqDuNs<=oEUfLaGkVApWngCSdrPwtxKbBqDuNH or(oEUfLaGkVApWngCSdrPwtxKbBqDuNH<oEUfLaGkVApWngCSdrPwtxKbBqDuNs and oEUfLaGkVApWngCSdrPwtxKbBqDuNs<oEUfLaGkVApWngCSdrPwtxKbBqDuNR):
     oEUfLaGkVApWngCSdrPwtxKbBqDuNl.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
  return oEUfLaGkVApWngCSdrPwtxKbBqDuNl
 def make_DateList(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,days=2,dateType='1'):
  oEUfLaGkVApWngCSdrPwtxKbBqDuNM=[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuNj =oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_Now_Datetime()
  if dateType=='1':
   oEUfLaGkVApWngCSdrPwtxKbBqDuNj=oEUfLaGkVApWngCSdrPwtxKbBqDuNj-datetime.timedelta(days=1)
  for i in oEUfLaGkVApWngCSdrPwtxKbBqDuOm(days):
   oEUfLaGkVApWngCSdrPwtxKbBqDuNm=oEUfLaGkVApWngCSdrPwtxKbBqDuNj+datetime.timedelta(days=i)
   if dateType=='1':
    oEUfLaGkVApWngCSdrPwtxKbBqDuNM.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNm.strftime('%Y%m%d'))
   else:
    oEUfLaGkVApWngCSdrPwtxKbBqDuNM.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNm.strftime('%Y%m%d'))
  return oEUfLaGkVApWngCSdrPwtxKbBqDuNM
 def make_Tving_ChannleGroup(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,oEUfLaGkVApWngCSdrPwtxKbBqDuNI):
  oEUfLaGkVApWngCSdrPwtxKbBqDuNh=[]
  i=0
  oEUfLaGkVApWngCSdrPwtxKbBqDuNJ=''
  for oEUfLaGkVApWngCSdrPwtxKbBqDuNQ in oEUfLaGkVApWngCSdrPwtxKbBqDuNI:
   if i==0:oEUfLaGkVApWngCSdrPwtxKbBqDuNJ=oEUfLaGkVApWngCSdrPwtxKbBqDuNQ
   else:oEUfLaGkVApWngCSdrPwtxKbBqDuNJ+=',%s'%(oEUfLaGkVApWngCSdrPwtxKbBqDuNQ)
   i+=1
   if i>=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.LIMIT_TVINGEPG:
    oEUfLaGkVApWngCSdrPwtxKbBqDuNh.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNJ)
    i=0
    oEUfLaGkVApWngCSdrPwtxKbBqDuNJ=''
  if oEUfLaGkVApWngCSdrPwtxKbBqDuNJ!='':
   oEUfLaGkVApWngCSdrPwtxKbBqDuNh.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNJ)
  return oEUfLaGkVApWngCSdrPwtxKbBqDuNh
 def Get_ChannelImg_Tving(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,chid_list):
  oEUfLaGkVApWngCSdrPwtxKbBqDuNv={}
  try:
   oEUfLaGkVApWngCSdrPwtxKbBqDuNc=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_Now_Datetime().strftime('%Y%m%d')
   oEUfLaGkVApWngCSdrPwtxKbBqDuNO =oEUfLaGkVApWngCSdrPwtxKbBqDuyv[6]['starttm'] 
   oEUfLaGkVApWngCSdrPwtxKbBqDuNi =oEUfLaGkVApWngCSdrPwtxKbBqDuyv[6]['endtm']
   oEUfLaGkVApWngCSdrPwtxKbBqDuNh=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.make_Tving_ChannleGroup(chid_list)
   for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuNh:
    oEUfLaGkVApWngCSdrPwtxKbBqDuym=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_TVING+'/v2/media/schedules'
    oEUfLaGkVApWngCSdrPwtxKbBqDuys={'pageNo':'1','pageSize':oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':oEUfLaGkVApWngCSdrPwtxKbBqDuNc,'broadcastDate':oEUfLaGkVApWngCSdrPwtxKbBqDuNc,'startBroadTime':oEUfLaGkVApWngCSdrPwtxKbBqDuNO,'endBroadTime':oEUfLaGkVApWngCSdrPwtxKbBqDuNi,'channelCode':oEUfLaGkVApWngCSdrPwtxKbBqDuyc}
    oEUfLaGkVApWngCSdrPwtxKbBqDuys.update(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_DefaultParams_Tving())
    oEUfLaGkVApWngCSdrPwtxKbBqDuyh=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.callRequestCookies('Get',oEUfLaGkVApWngCSdrPwtxKbBqDuym,payload=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,params=oEUfLaGkVApWngCSdrPwtxKbBqDuys,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,cookies=oEUfLaGkVApWngCSdrPwtxKbBqDuOM)
    oEUfLaGkVApWngCSdrPwtxKbBqDuyJ=json.loads(oEUfLaGkVApWngCSdrPwtxKbBqDuyh.text)
    if not('result' in oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['body']):return{}
    oEUfLaGkVApWngCSdrPwtxKbBqDuyQ=oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['body']['result']
    for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuyQ:
     for oEUfLaGkVApWngCSdrPwtxKbBqDuNF in oEUfLaGkVApWngCSdrPwtxKbBqDuyc['image']:
      if oEUfLaGkVApWngCSdrPwtxKbBqDuNF['code']=='CAIC0400':oEUfLaGkVApWngCSdrPwtxKbBqDuNv[oEUfLaGkVApWngCSdrPwtxKbBqDuyc['channel_code']]=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_TVINGIMG+oEUfLaGkVApWngCSdrPwtxKbBqDuNF['url']
      elif oEUfLaGkVApWngCSdrPwtxKbBqDuNF['code']=='CAIC1400':oEUfLaGkVApWngCSdrPwtxKbBqDuNv[oEUfLaGkVApWngCSdrPwtxKbBqDuyc['channel_code']]=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_TVINGIMG+oEUfLaGkVApWngCSdrPwtxKbBqDuNF['url']
      elif oEUfLaGkVApWngCSdrPwtxKbBqDuNF['code']=='CAIC1900':oEUfLaGkVApWngCSdrPwtxKbBqDuNv[oEUfLaGkVApWngCSdrPwtxKbBqDuyc['channel_code']]=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_TVINGIMG+oEUfLaGkVApWngCSdrPwtxKbBqDuNF['url']
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return{}
  return oEUfLaGkVApWngCSdrPwtxKbBqDuNv
 def Get_EpgInfo_Spotv(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,days=3,payyn=oEUfLaGkVApWngCSdrPwtxKbBqDuOR):
  oEUfLaGkVApWngCSdrPwtxKbBqDuyR=[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuNz =[]
  try:
   for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuyO:
    oEUfLaGkVApWngCSdrPwtxKbBqDuyF =oEUfLaGkVApWngCSdrPwtxKbBqDuyc['videoId']
    oEUfLaGkVApWngCSdrPwtxKbBqDuNy={'channelid':oEUfLaGkVApWngCSdrPwtxKbBqDuyF,'channelnm':oEUfLaGkVApWngCSdrPwtxKbBqDuyi.xmlText(oEUfLaGkVApWngCSdrPwtxKbBqDuyc['name']),'channelimg':oEUfLaGkVApWngCSdrPwtxKbBqDuyc['logo'],'ott':'spotv','epgtype':oEUfLaGkVApWngCSdrPwtxKbBqDuyc['epgtype'],'epgnm':oEUfLaGkVApWngCSdrPwtxKbBqDuyc['epgnm']}
    if payyn==oEUfLaGkVApWngCSdrPwtxKbBqDuOR or oEUfLaGkVApWngCSdrPwtxKbBqDuyc['free']==oEUfLaGkVApWngCSdrPwtxKbBqDuOR:
     oEUfLaGkVApWngCSdrPwtxKbBqDuyR.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return[],[]
  '''
  try:
   for now_day in days_list:
    url = self.API_SPOTV + '/api/v2/program/' + now_day
    response = self.callRequestCookies('Get', url, payload=None, params=None, headers=None, cookies=None )
    res_json = json.loads(response.text )
    for i_section in res_json:
     if find_list.get(i_section['channelId'] ) == None: continue
     temp_list = {'channelid' : find_list.get(i_section['channelId'] ) , 'title' : self.xmlText(i_section['title'] ) , 'startTime' : i_section['startTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'endTime' : i_section['endTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'ott' : 'spotv' }
     epg_list.append(temp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  try:
   for oEUfLaGkVApWngCSdrPwtxKbBqDuNT in oEUfLaGkVApWngCSdrPwtxKbBqDuyR:
    if oEUfLaGkVApWngCSdrPwtxKbBqDuNT['epgtype']=='spotvon':
     oEUfLaGkVApWngCSdrPwtxKbBqDuNX=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_EpgInfo_Spotv_spotvon(oEUfLaGkVApWngCSdrPwtxKbBqDuNT['channelid'],oEUfLaGkVApWngCSdrPwtxKbBqDuNT['epgnm'],days)
     if oEUfLaGkVApWngCSdrPwtxKbBqDuOh(oEUfLaGkVApWngCSdrPwtxKbBqDuNX)>0:oEUfLaGkVApWngCSdrPwtxKbBqDuNz.extend(oEUfLaGkVApWngCSdrPwtxKbBqDuNX)
    if oEUfLaGkVApWngCSdrPwtxKbBqDuNT['epgtype']=='spotvnet':
     oEUfLaGkVApWngCSdrPwtxKbBqDuNX=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_EpgInfo_Spotv_spotvnet(oEUfLaGkVApWngCSdrPwtxKbBqDuNT['channelid'],oEUfLaGkVApWngCSdrPwtxKbBqDuNT['epgnm'],days)
     if oEUfLaGkVApWngCSdrPwtxKbBqDuOh(oEUfLaGkVApWngCSdrPwtxKbBqDuNX)>0:oEUfLaGkVApWngCSdrPwtxKbBqDuNz.extend(oEUfLaGkVApWngCSdrPwtxKbBqDuNX)
    time.sleep(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.SLEEP_TIME)
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return[],[]
  return oEUfLaGkVApWngCSdrPwtxKbBqDuyR,oEUfLaGkVApWngCSdrPwtxKbBqDuNz
 def Get_EpgInfo_Spotv_spotvon(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,oEUfLaGkVApWngCSdrPwtxKbBqDuyF,epgnm,days):
  oEUfLaGkVApWngCSdrPwtxKbBqDuNz =[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuNM=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.make_DateList(days=days,dateType='1')
  oEUfLaGkVApWngCSdrPwtxKbBqDuvy=''
  try:
   for oEUfLaGkVApWngCSdrPwtxKbBqDuvN in oEUfLaGkVApWngCSdrPwtxKbBqDuNM:
    oEUfLaGkVApWngCSdrPwtxKbBqDuym='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,oEUfLaGkVApWngCSdrPwtxKbBqDuvN)
    oEUfLaGkVApWngCSdrPwtxKbBqDuyh=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.callRequestCookies('Get',oEUfLaGkVApWngCSdrPwtxKbBqDuym,payload=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,params=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,cookies=oEUfLaGkVApWngCSdrPwtxKbBqDuOM)
    oEUfLaGkVApWngCSdrPwtxKbBqDuyJ=json.loads(oEUfLaGkVApWngCSdrPwtxKbBqDuyh.text)
    for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuyJ:
     oEUfLaGkVApWngCSdrPwtxKbBqDuNy={'channelid':oEUfLaGkVApWngCSdrPwtxKbBqDuyF,'title':oEUfLaGkVApWngCSdrPwtxKbBqDuyi.xmlText(oEUfLaGkVApWngCSdrPwtxKbBqDuyc['title']),'startTime':oEUfLaGkVApWngCSdrPwtxKbBqDuyc['sch_date'].replace('-','')+oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuyc['sch_hour']).zfill(2)+oEUfLaGkVApWngCSdrPwtxKbBqDuyc['sch_min']+'00','ott':'spotv'}
     oEUfLaGkVApWngCSdrPwtxKbBqDuNz.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
    oEUfLaGkVApWngCSdrPwtxKbBqDuvy=oEUfLaGkVApWngCSdrPwtxKbBqDuvN
   for i in oEUfLaGkVApWngCSdrPwtxKbBqDuOm(oEUfLaGkVApWngCSdrPwtxKbBqDuOh(oEUfLaGkVApWngCSdrPwtxKbBqDuNz)):
    if i>0:oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i-1]['endTime']=oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i]['startTime']
    if i==oEUfLaGkVApWngCSdrPwtxKbBqDuOh(oEUfLaGkVApWngCSdrPwtxKbBqDuNz)-1: oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i]['endTime']=oEUfLaGkVApWngCSdrPwtxKbBqDuvy+'240000'
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return[]
  return oEUfLaGkVApWngCSdrPwtxKbBqDuNz
 def Get_EpgInfo_Spotv_spotvnet(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,oEUfLaGkVApWngCSdrPwtxKbBqDuyF,epgnm,days):
  oEUfLaGkVApWngCSdrPwtxKbBqDuNz =[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuNM=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.make_DateList(days=days,dateType='1')
  oEUfLaGkVApWngCSdrPwtxKbBqDuvy=''
  try:
   for oEUfLaGkVApWngCSdrPwtxKbBqDuvN in oEUfLaGkVApWngCSdrPwtxKbBqDuNM:
    oEUfLaGkVApWngCSdrPwtxKbBqDuym='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,oEUfLaGkVApWngCSdrPwtxKbBqDuvN)
    oEUfLaGkVApWngCSdrPwtxKbBqDuyh=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.callRequestCookies('Get',oEUfLaGkVApWngCSdrPwtxKbBqDuym,payload=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,params=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,cookies=oEUfLaGkVApWngCSdrPwtxKbBqDuOM)
    oEUfLaGkVApWngCSdrPwtxKbBqDuyJ=json.loads(oEUfLaGkVApWngCSdrPwtxKbBqDuyh.text)
    for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuyJ:
     oEUfLaGkVApWngCSdrPwtxKbBqDuNy={'channelid':oEUfLaGkVApWngCSdrPwtxKbBqDuyF,'title':oEUfLaGkVApWngCSdrPwtxKbBqDuyi.xmlText(oEUfLaGkVApWngCSdrPwtxKbBqDuyc['title']),'startTime':oEUfLaGkVApWngCSdrPwtxKbBqDuyc['sch_date'].replace('-','')+oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuyc['sch_hour']).zfill(2)+oEUfLaGkVApWngCSdrPwtxKbBqDuyc['sch_min']+'00','ott':'spotv'}
     oEUfLaGkVApWngCSdrPwtxKbBqDuNz.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
    oEUfLaGkVApWngCSdrPwtxKbBqDuvy=oEUfLaGkVApWngCSdrPwtxKbBqDuvN
   for i in oEUfLaGkVApWngCSdrPwtxKbBqDuOm(oEUfLaGkVApWngCSdrPwtxKbBqDuOh(oEUfLaGkVApWngCSdrPwtxKbBqDuNz)):
    if i>0:oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i-1]['endTime']=oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i]['startTime']
    if i==oEUfLaGkVApWngCSdrPwtxKbBqDuOh(oEUfLaGkVApWngCSdrPwtxKbBqDuNz)-1: oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i]['endTime']=oEUfLaGkVApWngCSdrPwtxKbBqDuvy+'240000'
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return[]
  return oEUfLaGkVApWngCSdrPwtxKbBqDuNz
 def Get_EpgInfo_Wavve(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,days=2,exceptGroup=[]):
  oEUfLaGkVApWngCSdrPwtxKbBqDuyR =[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuNz =[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuNj =oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_Now_Datetime()
  oEUfLaGkVApWngCSdrPwtxKbBqDuvO =oEUfLaGkVApWngCSdrPwtxKbBqDuNj+datetime.timedelta(hours=-2)
  oEUfLaGkVApWngCSdrPwtxKbBqDuvi =oEUfLaGkVApWngCSdrPwtxKbBqDuNj+datetime.timedelta(days=(days-1))
  if oEUfLaGkVApWngCSdrPwtxKbBqDuOj(oEUfLaGkVApWngCSdrPwtxKbBqDuvO.strftime('%H'))<=3:
   oEUfLaGkVApWngCSdrPwtxKbBqDuve=oEUfLaGkVApWngCSdrPwtxKbBqDuvO.strftime('%Y-%m-%d 00:00')
  else:
   oEUfLaGkVApWngCSdrPwtxKbBqDuve=oEUfLaGkVApWngCSdrPwtxKbBqDuvO.strftime('%Y-%m-%d %H:00')
  oEUfLaGkVApWngCSdrPwtxKbBqDuvI =oEUfLaGkVApWngCSdrPwtxKbBqDuvi.strftime('%Y-%m-%d 24:00')
  try:
   oEUfLaGkVApWngCSdrPwtxKbBqDuym=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_WAVVE+'/live/epgs'
   oEUfLaGkVApWngCSdrPwtxKbBqDuys={'limit':oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':oEUfLaGkVApWngCSdrPwtxKbBqDuve,'enddatetime':oEUfLaGkVApWngCSdrPwtxKbBqDuvI}
   oEUfLaGkVApWngCSdrPwtxKbBqDuys.update(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_DefaultParams_Wavve())
   oEUfLaGkVApWngCSdrPwtxKbBqDuyh=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.callRequestCookies('Get',oEUfLaGkVApWngCSdrPwtxKbBqDuym,payload=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,params=oEUfLaGkVApWngCSdrPwtxKbBqDuys,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,cookies=oEUfLaGkVApWngCSdrPwtxKbBqDuOM)
   oEUfLaGkVApWngCSdrPwtxKbBqDuyJ=json.loads(oEUfLaGkVApWngCSdrPwtxKbBqDuyh.text)
   oEUfLaGkVApWngCSdrPwtxKbBqDuvl=oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['list']
   for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuvl:
    oEUfLaGkVApWngCSdrPwtxKbBqDuyF =oEUfLaGkVApWngCSdrPwtxKbBqDuyc['channelid']
    oEUfLaGkVApWngCSdrPwtxKbBqDuyX=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.make_getGenre(oEUfLaGkVApWngCSdrPwtxKbBqDuyF,'wavve')
    oEUfLaGkVApWngCSdrPwtxKbBqDuNy={'channelid':oEUfLaGkVApWngCSdrPwtxKbBqDuyF,'channelnm':oEUfLaGkVApWngCSdrPwtxKbBqDuyi.xmlText(oEUfLaGkVApWngCSdrPwtxKbBqDuyc['channelname']),'channelimg':oEUfLaGkVApWngCSdrPwtxKbBqDuyi.HTTPTAG+oEUfLaGkVApWngCSdrPwtxKbBqDuyc['channelimage'],'ott':'wavve'}
    if oEUfLaGkVApWngCSdrPwtxKbBqDuyX not in exceptGroup:
     oEUfLaGkVApWngCSdrPwtxKbBqDuyR.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
    for oEUfLaGkVApWngCSdrPwtxKbBqDuvM in oEUfLaGkVApWngCSdrPwtxKbBqDuyc['list']:
     oEUfLaGkVApWngCSdrPwtxKbBqDuNy={'channelid':oEUfLaGkVApWngCSdrPwtxKbBqDuyc['channelid'],'title':oEUfLaGkVApWngCSdrPwtxKbBqDuyi.xmlText(oEUfLaGkVApWngCSdrPwtxKbBqDuvM['title']),'startTime':oEUfLaGkVApWngCSdrPwtxKbBqDuvM['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':oEUfLaGkVApWngCSdrPwtxKbBqDuvM['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if oEUfLaGkVApWngCSdrPwtxKbBqDuyX not in exceptGroup and oEUfLaGkVApWngCSdrPwtxKbBqDuvM['starttime']!=oEUfLaGkVApWngCSdrPwtxKbBqDuvM['endtime']:
      oEUfLaGkVApWngCSdrPwtxKbBqDuNz.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return[],[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuvs=oEUfLaGkVApWngCSdrPwtxKbBqDuOh(oEUfLaGkVApWngCSdrPwtxKbBqDuNz)
  for i in(oEUfLaGkVApWngCSdrPwtxKbBqDuOm(1,oEUfLaGkVApWngCSdrPwtxKbBqDuvs)):
   if oEUfLaGkVApWngCSdrPwtxKbBqDuOj(oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i-1]['endTime'])+1==oEUfLaGkVApWngCSdrPwtxKbBqDuOj(oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i]['startTime'])and oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i-1]['channelid']==oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i]['channelid']:
    oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i-1]['endTime']=oEUfLaGkVApWngCSdrPwtxKbBqDuNz[i]['startTime']
  return oEUfLaGkVApWngCSdrPwtxKbBqDuyR,oEUfLaGkVApWngCSdrPwtxKbBqDuNz
 def Get_EpgInfo_Tving(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,days=2):
  oEUfLaGkVApWngCSdrPwtxKbBqDuyR=[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuNz =[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuvY =[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuvH =oEUfLaGkVApWngCSdrPwtxKbBqDuyi.make_EpgDatetime_Tving(days=days)
  oEUfLaGkVApWngCSdrPwtxKbBqDuyR =oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_ChannelList_Tving()
  oEUfLaGkVApWngCSdrPwtxKbBqDuvR=[]
  for i in oEUfLaGkVApWngCSdrPwtxKbBqDuOm(oEUfLaGkVApWngCSdrPwtxKbBqDuOh(oEUfLaGkVApWngCSdrPwtxKbBqDuyR)):
   oEUfLaGkVApWngCSdrPwtxKbBqDuyR[i]['channelnm']=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.xmlText(oEUfLaGkVApWngCSdrPwtxKbBqDuyR[i]['channelnm'])
   oEUfLaGkVApWngCSdrPwtxKbBqDuvR.append(oEUfLaGkVApWngCSdrPwtxKbBqDuyR[i]['channelid'])
  oEUfLaGkVApWngCSdrPwtxKbBqDuvj=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.make_Tving_ChannleGroup(oEUfLaGkVApWngCSdrPwtxKbBqDuvR)
  try:
   oEUfLaGkVApWngCSdrPwtxKbBqDuym=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.API_TVING+'/v2/media/schedules'
   for oEUfLaGkVApWngCSdrPwtxKbBqDuvm in oEUfLaGkVApWngCSdrPwtxKbBqDuvH:
    for oEUfLaGkVApWngCSdrPwtxKbBqDuNT in oEUfLaGkVApWngCSdrPwtxKbBqDuvj:
     oEUfLaGkVApWngCSdrPwtxKbBqDuys={'pageNo':'1','pageSize':oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':oEUfLaGkVApWngCSdrPwtxKbBqDuvm['ndate'],'broadcastDate':oEUfLaGkVApWngCSdrPwtxKbBqDuvm['ndate'],'startBroadTime':oEUfLaGkVApWngCSdrPwtxKbBqDuvm['starttm'],'endBroadTime':oEUfLaGkVApWngCSdrPwtxKbBqDuvm['endtm'],'channelCode':oEUfLaGkVApWngCSdrPwtxKbBqDuNT}
     oEUfLaGkVApWngCSdrPwtxKbBqDuys.update(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_DefaultParams_Tving())
     oEUfLaGkVApWngCSdrPwtxKbBqDuyh=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.callRequestCookies('Get',oEUfLaGkVApWngCSdrPwtxKbBqDuym,payload=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,params=oEUfLaGkVApWngCSdrPwtxKbBqDuys,headers=oEUfLaGkVApWngCSdrPwtxKbBqDuOM,cookies=oEUfLaGkVApWngCSdrPwtxKbBqDuOM)
     oEUfLaGkVApWngCSdrPwtxKbBqDuyJ=json.loads(oEUfLaGkVApWngCSdrPwtxKbBqDuyh.text)
     oEUfLaGkVApWngCSdrPwtxKbBqDuyQ=oEUfLaGkVApWngCSdrPwtxKbBqDuyJ['body']['result']
     for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuyQ:
      if 'schedules' not in oEUfLaGkVApWngCSdrPwtxKbBqDuyc:continue
      if oEUfLaGkVApWngCSdrPwtxKbBqDuyc['schedules']==oEUfLaGkVApWngCSdrPwtxKbBqDuOM:continue
      for oEUfLaGkVApWngCSdrPwtxKbBqDuvh in oEUfLaGkVApWngCSdrPwtxKbBqDuyc['schedules']:
       oEUfLaGkVApWngCSdrPwtxKbBqDuNy={'channelid':oEUfLaGkVApWngCSdrPwtxKbBqDuvh['schedule_code'],'title':oEUfLaGkVApWngCSdrPwtxKbBqDuyi.xmlText(oEUfLaGkVApWngCSdrPwtxKbBqDuvh['program']['name']['ko']),'startTime':oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuvh['broadcast_start_time']),'endTime':oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuvh['broadcast_end_time']),'ott':'tving'}
       oEUfLaGkVApWngCSdrPwtxKbBqDuvJ=oEUfLaGkVApWngCSdrPwtxKbBqDuvh['schedule_code']+oEUfLaGkVApWngCSdrPwtxKbBqDuOs(oEUfLaGkVApWngCSdrPwtxKbBqDuvh['broadcast_start_time'])
       if oEUfLaGkVApWngCSdrPwtxKbBqDuvJ in oEUfLaGkVApWngCSdrPwtxKbBqDuvY:continue
       oEUfLaGkVApWngCSdrPwtxKbBqDuvY.append(oEUfLaGkVApWngCSdrPwtxKbBqDuvJ)
       oEUfLaGkVApWngCSdrPwtxKbBqDuNz.append(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
     time.sleep(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.SLEEP_TIME)
  except oEUfLaGkVApWngCSdrPwtxKbBqDuOY as exception:
   oEUfLaGkVApWngCSdrPwtxKbBqDuOH(exception)
   return[],[]
  return oEUfLaGkVApWngCSdrPwtxKbBqDuyR,oEUfLaGkVApWngCSdrPwtxKbBqDuNz
 def make_getGenre(oEUfLaGkVApWngCSdrPwtxKbBqDuyi,oEUfLaGkVApWngCSdrPwtxKbBqDuyF,oEUfLaGkVApWngCSdrPwtxKbBqDuOv):
  try:
   oEUfLaGkVApWngCSdrPwtxKbBqDuNe=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.INIT_CHANNEL.get(oEUfLaGkVApWngCSdrPwtxKbBqDuyF+'.'+oEUfLaGkVApWngCSdrPwtxKbBqDuOv).get('genre')
  except:
   oEUfLaGkVApWngCSdrPwtxKbBqDuNe='-'
  return oEUfLaGkVApWngCSdrPwtxKbBqDuNe
 def make_base_allchannel_py(oEUfLaGkVApWngCSdrPwtxKbBqDuyi):
  oEUfLaGkVApWngCSdrPwtxKbBqDuvQ =[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuvc=[]
  oEUfLaGkVApWngCSdrPwtxKbBqDuvF=oEUfLaGkVApWngCSdrPwtxKbBqDuOJ()
  oEUfLaGkVApWngCSdrPwtxKbBqDuNy=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_ChannelList_Wavve()
  oEUfLaGkVApWngCSdrPwtxKbBqDuvQ.extend(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
  oEUfLaGkVApWngCSdrPwtxKbBqDuNy=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_ChannelList_Tving()
  oEUfLaGkVApWngCSdrPwtxKbBqDuvQ.extend(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
  oEUfLaGkVApWngCSdrPwtxKbBqDuNy=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_ChannelList_Spotv()
  oEUfLaGkVApWngCSdrPwtxKbBqDuvQ.extend(oEUfLaGkVApWngCSdrPwtxKbBqDuNy)
  oEUfLaGkVApWngCSdrPwtxKbBqDuOH('1')
  for i in oEUfLaGkVApWngCSdrPwtxKbBqDuOm(oEUfLaGkVApWngCSdrPwtxKbBqDuOh(oEUfLaGkVApWngCSdrPwtxKbBqDuvQ)):
   if oEUfLaGkVApWngCSdrPwtxKbBqDuvQ[i]['genrenm']=='-':
    if oEUfLaGkVApWngCSdrPwtxKbBqDuvQ[i]['ott']=='wavve':
     oEUfLaGkVApWngCSdrPwtxKbBqDuNe=oEUfLaGkVApWngCSdrPwtxKbBqDuyi.Get_ChanneGenrename_Wavve(oEUfLaGkVApWngCSdrPwtxKbBqDuvQ[i]['channelid'])
     if oEUfLaGkVApWngCSdrPwtxKbBqDuNe not in oEUfLaGkVApWngCSdrPwtxKbBqDuvF:oEUfLaGkVApWngCSdrPwtxKbBqDuvF.add(oEUfLaGkVApWngCSdrPwtxKbBqDuNe)
     time.sleep(oEUfLaGkVApWngCSdrPwtxKbBqDuyi.SLEEP_TIME)
    elif oEUfLaGkVApWngCSdrPwtxKbBqDuvQ[i]['ott']=='spotv':
     oEUfLaGkVApWngCSdrPwtxKbBqDuNe='스포츠'
    else:
     oEUfLaGkVApWngCSdrPwtxKbBqDuNe='-'
    oEUfLaGkVApWngCSdrPwtxKbBqDuvQ[i]['genrenm']=oEUfLaGkVApWngCSdrPwtxKbBqDuNe
   else:
    if oEUfLaGkVApWngCSdrPwtxKbBqDuvQ[i]['genrenm']not in oEUfLaGkVApWngCSdrPwtxKbBqDuvF:oEUfLaGkVApWngCSdrPwtxKbBqDuvF.add(oEUfLaGkVApWngCSdrPwtxKbBqDuvQ[i]['genrenm'])
  oEUfLaGkVApWngCSdrPwtxKbBqDuvF.add('-')
  oEUfLaGkVApWngCSdrPwtxKbBqDuOH('2')
  for oEUfLaGkVApWngCSdrPwtxKbBqDuvz in oEUfLaGkVApWngCSdrPwtxKbBqDuvF:
   for oEUfLaGkVApWngCSdrPwtxKbBqDuvT in oEUfLaGkVApWngCSdrPwtxKbBqDuvQ:
    if oEUfLaGkVApWngCSdrPwtxKbBqDuvT['genrenm']==oEUfLaGkVApWngCSdrPwtxKbBqDuvz:
     oEUfLaGkVApWngCSdrPwtxKbBqDuvc.append(oEUfLaGkVApWngCSdrPwtxKbBqDuvT)
  for oEUfLaGkVApWngCSdrPwtxKbBqDuvT in oEUfLaGkVApWngCSdrPwtxKbBqDuvQ:
   if oEUfLaGkVApWngCSdrPwtxKbBqDuvT['genrenm']not in oEUfLaGkVApWngCSdrPwtxKbBqDuvF:
    oEUfLaGkVApWngCSdrPwtxKbBqDuvX.append(oEUfLaGkVApWngCSdrPwtxKbBqDuvT)
  oEUfLaGkVApWngCSdrPwtxKbBqDuOH('3')
  oEUfLaGkVApWngCSdrPwtxKbBqDuOy='d:\\job\\channelgenre.json'
  if os.path.isfile(oEUfLaGkVApWngCSdrPwtxKbBqDuOy):os.remove(oEUfLaGkVApWngCSdrPwtxKbBqDuOy)
  fp=oEUfLaGkVApWngCSdrPwtxKbBqDuOQ(oEUfLaGkVApWngCSdrPwtxKbBqDuOy,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  oEUfLaGkVApWngCSdrPwtxKbBqDuON=oEUfLaGkVApWngCSdrPwtxKbBqDuOh(oEUfLaGkVApWngCSdrPwtxKbBqDuvc)
  i=0
  for oEUfLaGkVApWngCSdrPwtxKbBqDuyc in oEUfLaGkVApWngCSdrPwtxKbBqDuvc:
   i+=1
   oEUfLaGkVApWngCSdrPwtxKbBqDuyF =oEUfLaGkVApWngCSdrPwtxKbBqDuyc['channelid']
   oEUfLaGkVApWngCSdrPwtxKbBqDuyz =oEUfLaGkVApWngCSdrPwtxKbBqDuyc['channelnm']
   oEUfLaGkVApWngCSdrPwtxKbBqDuOv =oEUfLaGkVApWngCSdrPwtxKbBqDuyc['ott']
   oEUfLaGkVApWngCSdrPwtxKbBqDuOi ='%s.%s'%(oEUfLaGkVApWngCSdrPwtxKbBqDuyF,oEUfLaGkVApWngCSdrPwtxKbBqDuOv)
   oEUfLaGkVApWngCSdrPwtxKbBqDuNe =oEUfLaGkVApWngCSdrPwtxKbBqDuyc['genrenm']
   oEUfLaGkVApWngCSdrPwtxKbBqDuOe='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(oEUfLaGkVApWngCSdrPwtxKbBqDuOi,oEUfLaGkVApWngCSdrPwtxKbBqDuyz,oEUfLaGkVApWngCSdrPwtxKbBqDuNe)
   if i<oEUfLaGkVApWngCSdrPwtxKbBqDuON:
    fp.write(oEUfLaGkVApWngCSdrPwtxKbBqDuOe+',\n')
   else:
    fp.write(oEUfLaGkVApWngCSdrPwtxKbBqDuOe+'\n')
  fp.write('}\n')
  fp.close()
  return oEUfLaGkVApWngCSdrPwtxKbBqDuvF
# Created by pyminifier (https://github.com/liftoff/pyminifier)
