__author__="NightRain"
mVDCUfkhXnBzijbrOSdNtEHTILoGMp=str
mVDCUfkhXnBzijbrOSdNtEHTILoGMP=True
mVDCUfkhXnBzijbrOSdNtEHTILoGMu=False
mVDCUfkhXnBzijbrOSdNtEHTILoGMe=print
mVDCUfkhXnBzijbrOSdNtEHTILoGMx=open
mVDCUfkhXnBzijbrOSdNtEHTILoGMa=Exception
mVDCUfkhXnBzijbrOSdNtEHTILoGJM=int
import json
import time
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 mVDCUfkhXnBzijbrOSdNtEHTILoGMR='ADDON'
except:
 mVDCUfkhXnBzijbrOSdNtEHTILoGMR='SINGLE'
if mVDCUfkhXnBzijbrOSdNtEHTILoGMR=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  mVDCUfkhXnBzijbrOSdNtEHTILoGMs=mVDCUfkhXnBzijbrOSdNtEHTILoGMp(string).encode('utf-8','ignore')
  mVDCUfkhXnBzijbrOSdNtEHTILoGMq=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,mVDCUfkhXnBzijbrOSdNtEHTILoGMs),level=mVDCUfkhXnBzijbrOSdNtEHTILoGMq)
 def addon_getautoepg():
  return mVDCUfkhXnBzijbrOSdNtEHTILoGMP if __addon__.getSetting('autoEpg')=='true' else mVDCUfkhXnBzijbrOSdNtEHTILoGMu
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  mVDCUfkhXnBzijbrOSdNtEHTILoGMe(string)
 def addon_getautoepg():
  return mVDCUfkhXnBzijbrOSdNtEHTILoGMP
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class mVDCUfkhXnBzijbrOSdNtEHTILoGMJ():
 def __init__(mVDCUfkhXnBzijbrOSdNtEHTILoGMy):
  mVDCUfkhXnBzijbrOSdNtEHTILoGMy.START_INTERVAL =10 
  mVDCUfkhXnBzijbrOSdNtEHTILoGMy.INTERVAL =10 
  mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_FILETAGNM ='date_makeepg'
  mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_MAKEDATE ='-' 
  mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_WILL_TM =-1 
 def Get_Now_Datetime(mVDCUfkhXnBzijbrOSdNtEHTILoGMy):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(mVDCUfkhXnBzijbrOSdNtEHTILoGMy):
  mVDCUfkhXnBzijbrOSdNtEHTILoGMv ='-'
  if mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_MAKEDATE=='-':
   try:
    fp=mVDCUfkhXnBzijbrOSdNtEHTILoGMx(addon_epgupdate_confignm(),'r',-1,'utf-8')
    mVDCUfkhXnBzijbrOSdNtEHTILoGMQ= json.load(fp)
    fp.close()
    mVDCUfkhXnBzijbrOSdNtEHTILoGMv=mVDCUfkhXnBzijbrOSdNtEHTILoGMQ[mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_FILETAGNM]
   except mVDCUfkhXnBzijbrOSdNtEHTILoGMa as exception:
    return 2 
  else:
   mVDCUfkhXnBzijbrOSdNtEHTILoGMv=mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_MAKEDATE
  mVDCUfkhXnBzijbrOSdNtEHTILoGMg =mVDCUfkhXnBzijbrOSdNtEHTILoGMy.Get_Now_Datetime()
  mVDCUfkhXnBzijbrOSdNtEHTILoGMc=(mVDCUfkhXnBzijbrOSdNtEHTILoGMg-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  mVDCUfkhXnBzijbrOSdNtEHTILoGMW =mVDCUfkhXnBzijbrOSdNtEHTILoGMg.strftime('%Y-%m-%d')
  mVDCUfkhXnBzijbrOSdNtEHTILoGMF =mVDCUfkhXnBzijbrOSdNtEHTILoGMg.strftime('%H')
  if mVDCUfkhXnBzijbrOSdNtEHTILoGMv==mVDCUfkhXnBzijbrOSdNtEHTILoGMW: return-1
  if mVDCUfkhXnBzijbrOSdNtEHTILoGMv==mVDCUfkhXnBzijbrOSdNtEHTILoGMc and mVDCUfkhXnBzijbrOSdNtEHTILoGMF=='00':return 30
  return 2
 def MakeEpg_RandomTm(mVDCUfkhXnBzijbrOSdNtEHTILoGMy,mintm):
  mVDCUfkhXnBzijbrOSdNtEHTILoGMl=(mintm*60)+random.randint(0,60)
  mVDCUfkhXnBzijbrOSdNtEHTILoGMg =mVDCUfkhXnBzijbrOSdNtEHTILoGMy.Get_Now_Datetime()
  mVDCUfkhXnBzijbrOSdNtEHTILoGMK =(mVDCUfkhXnBzijbrOSdNtEHTILoGMg+datetime.timedelta(seconds=mVDCUfkhXnBzijbrOSdNtEHTILoGMl)).strftime('%Y%m%d%H%M%S')
  return mVDCUfkhXnBzijbrOSdNtEHTILoGJM(mVDCUfkhXnBzijbrOSdNtEHTILoGMK)
 def MakeEpg_SaveJson(mVDCUfkhXnBzijbrOSdNtEHTILoGMy):
  mVDCUfkhXnBzijbrOSdNtEHTILoGMQ={mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_FILETAGNM:mVDCUfkhXnBzijbrOSdNtEHTILoGMy.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=mVDCUfkhXnBzijbrOSdNtEHTILoGMx(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(mVDCUfkhXnBzijbrOSdNtEHTILoGMQ,fp)
   fp.close()
  except mVDCUfkhXnBzijbrOSdNtEHTILoGMa as exception:
   return
 def service_run(mVDCUfkhXnBzijbrOSdNtEHTILoGMy):
  if addon_getautoepg()==mVDCUfkhXnBzijbrOSdNtEHTILoGMu:return
  mVDCUfkhXnBzijbrOSdNtEHTILoGMw=mVDCUfkhXnBzijbrOSdNtEHTILoGMy.MakeEpg_DateCheck()
  if mVDCUfkhXnBzijbrOSdNtEHTILoGMw<0:
   return
  if mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_WILL_TM<0:
   mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_WILL_TM=mVDCUfkhXnBzijbrOSdNtEHTILoGMy.MakeEpg_RandomTm(mVDCUfkhXnBzijbrOSdNtEHTILoGMw)
   addon_log('EPG_WILL_TM --> '+mVDCUfkhXnBzijbrOSdNtEHTILoGMp(mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_WILL_TM))
  else:
   mVDCUfkhXnBzijbrOSdNtEHTILoGMW=mVDCUfkhXnBzijbrOSdNtEHTILoGMy.Get_Now_Datetime()
   if mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_WILL_TM<mVDCUfkhXnBzijbrOSdNtEHTILoGJM(mVDCUfkhXnBzijbrOSdNtEHTILoGMW.strftime('%Y%m%d%H%M%S')):
    addon_log('make epg')
    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
    mVDCUfkhXnBzijbrOSdNtEHTILoGMy.MakeEpg_SaveJson()
    mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_MAKEDATE=mVDCUfkhXnBzijbrOSdNtEHTILoGMW.strftime('%Y-%m-%d')
    mVDCUfkhXnBzijbrOSdNtEHTILoGMy.EPG_WILL_TM =-1
   else:
    pass
  pass
if __name__=="__main__":
 addon_log('__main__')
 mVDCUfkhXnBzijbrOSdNtEHTILoGMA=mVDCUfkhXnBzijbrOSdNtEHTILoGMJ()
 time.sleep(mVDCUfkhXnBzijbrOSdNtEHTILoGMA.START_INTERVAL)
 while mVDCUfkhXnBzijbrOSdNtEHTILoGMP:
  time.sleep(mVDCUfkhXnBzijbrOSdNtEHTILoGMA.INTERVAL)
  mVDCUfkhXnBzijbrOSdNtEHTILoGMA.service_run()
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
