__author__="NightRain"
WbFASkHgwhqYueiJvVPXQKBrNxcMOo=object
WbFASkHgwhqYueiJvVPXQKBrNxcMOn=False
WbFASkHgwhqYueiJvVPXQKBrNxcMOf=None
WbFASkHgwhqYueiJvVPXQKBrNxcMOd=True
WbFASkHgwhqYueiJvVPXQKBrNxcMGU=len
WbFASkHgwhqYueiJvVPXQKBrNxcMGl=str
WbFASkHgwhqYueiJvVPXQKBrNxcMGO=open
WbFASkHgwhqYueiJvVPXQKBrNxcMGm=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
WbFASkHgwhqYueiJvVPXQKBrNxcMUO=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
WbFASkHgwhqYueiJvVPXQKBrNxcMUG=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class WbFASkHgwhqYueiJvVPXQKBrNxcMUl(WbFASkHgwhqYueiJvVPXQKBrNxcMOo):
 def __init__(WbFASkHgwhqYueiJvVPXQKBrNxcMUm,WbFASkHgwhqYueiJvVPXQKBrNxcMUL,WbFASkHgwhqYueiJvVPXQKBrNxcMUs,WbFASkHgwhqYueiJvVPXQKBrNxcMUC):
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm._addon_url =WbFASkHgwhqYueiJvVPXQKBrNxcMUL
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm._addon_handle =WbFASkHgwhqYueiJvVPXQKBrNxcMUs
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.main_params =WbFASkHgwhqYueiJvVPXQKBrNxcMUC
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_FILE_PATH ='' 
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_FILE_NAME ='' 
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVE =WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONTVING =WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONSPOTV =WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVERADIO=WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVEHOME =WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONRELIGION =WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONSPOTVPAY =WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_DISPLAYNM =WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_AUTORESTART =WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.BoritvObj =oEUfLaGkVApWngCSdrPwtxKbBqDuyN() 
 def addon_noti(WbFASkHgwhqYueiJvVPXQKBrNxcMUm,sting):
  try:
   WbFASkHgwhqYueiJvVPXQKBrNxcMUa=xbmcgui.Dialog()
   WbFASkHgwhqYueiJvVPXQKBrNxcMUa.notification(__addonname__,sting)
  except:
   WbFASkHgwhqYueiJvVPXQKBrNxcMOf
 def addon_log(WbFASkHgwhqYueiJvVPXQKBrNxcMUm,string):
  try:
   WbFASkHgwhqYueiJvVPXQKBrNxcMUD=string.encode('utf-8','ignore')
  except:
   WbFASkHgwhqYueiJvVPXQKBrNxcMUD='addonException: addon_log'
  WbFASkHgwhqYueiJvVPXQKBrNxcMUI=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,WbFASkHgwhqYueiJvVPXQKBrNxcMUD),level=WbFASkHgwhqYueiJvVPXQKBrNxcMUI)
 def get_keyboard_input(WbFASkHgwhqYueiJvVPXQKBrNxcMUm,WbFASkHgwhqYueiJvVPXQKBrNxcMUp):
  WbFASkHgwhqYueiJvVPXQKBrNxcMUt=WbFASkHgwhqYueiJvVPXQKBrNxcMOf
  kb=xbmc.Keyboard()
  kb.setHeading(WbFASkHgwhqYueiJvVPXQKBrNxcMUp)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   WbFASkHgwhqYueiJvVPXQKBrNxcMUt=kb.getText()
  return WbFASkHgwhqYueiJvVPXQKBrNxcMUt
 def add_dir(WbFASkHgwhqYueiJvVPXQKBrNxcMUm,label,sublabel='',img='',infoLabels=WbFASkHgwhqYueiJvVPXQKBrNxcMOf,isFolder=WbFASkHgwhqYueiJvVPXQKBrNxcMOd,params='',isLink=WbFASkHgwhqYueiJvVPXQKBrNxcMOn,ContextMenu=WbFASkHgwhqYueiJvVPXQKBrNxcMOf):
  WbFASkHgwhqYueiJvVPXQKBrNxcMUT='%s?%s'%(WbFASkHgwhqYueiJvVPXQKBrNxcMUm._addon_url,urllib.parse.urlencode(params))
  if sublabel:WbFASkHgwhqYueiJvVPXQKBrNxcMUp='%s < %s >'%(label,sublabel)
  else: WbFASkHgwhqYueiJvVPXQKBrNxcMUp=label
  if not img:img='DefaultFolder.png'
  WbFASkHgwhqYueiJvVPXQKBrNxcMUR=xbmcgui.ListItem(WbFASkHgwhqYueiJvVPXQKBrNxcMUp)
  WbFASkHgwhqYueiJvVPXQKBrNxcMUR.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:WbFASkHgwhqYueiJvVPXQKBrNxcMUR.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   WbFASkHgwhqYueiJvVPXQKBrNxcMUR.setProperty('IsPlayable','true')
  if ContextMenu:WbFASkHgwhqYueiJvVPXQKBrNxcMUR.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(WbFASkHgwhqYueiJvVPXQKBrNxcMUm._addon_handle,WbFASkHgwhqYueiJvVPXQKBrNxcMUT,WbFASkHgwhqYueiJvVPXQKBrNxcMUR,isFolder)
 def make_M3u_Filename(WbFASkHgwhqYueiJvVPXQKBrNxcMUm,tempyn=WbFASkHgwhqYueiJvVPXQKBrNxcMOn):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_FILE_PATH+WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(WbFASkHgwhqYueiJvVPXQKBrNxcMUm,tempyn=WbFASkHgwhqYueiJvVPXQKBrNxcMOn):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_FILE_PATH+WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_FILE_NAME+'.xml'
 def dp_Main_List(WbFASkHgwhqYueiJvVPXQKBrNxcMUm):
  for WbFASkHgwhqYueiJvVPXQKBrNxcMUj in WbFASkHgwhqYueiJvVPXQKBrNxcMUO:
   WbFASkHgwhqYueiJvVPXQKBrNxcMUp=WbFASkHgwhqYueiJvVPXQKBrNxcMUj.get('title')
   WbFASkHgwhqYueiJvVPXQKBrNxcMUz=''
   WbFASkHgwhqYueiJvVPXQKBrNxcMUy={'mode':WbFASkHgwhqYueiJvVPXQKBrNxcMUj.get('mode'),'sType':WbFASkHgwhqYueiJvVPXQKBrNxcMUj.get('sType'),'sName':WbFASkHgwhqYueiJvVPXQKBrNxcMUj.get('sName')}
   if WbFASkHgwhqYueiJvVPXQKBrNxcMUj.get('mode')=='XXX':
    WbFASkHgwhqYueiJvVPXQKBrNxcMUo=WbFASkHgwhqYueiJvVPXQKBrNxcMOn
    WbFASkHgwhqYueiJvVPXQKBrNxcMUn =WbFASkHgwhqYueiJvVPXQKBrNxcMOd
   else:
    WbFASkHgwhqYueiJvVPXQKBrNxcMUo=WbFASkHgwhqYueiJvVPXQKBrNxcMOd
    WbFASkHgwhqYueiJvVPXQKBrNxcMUn =WbFASkHgwhqYueiJvVPXQKBrNxcMOn
   WbFASkHgwhqYueiJvVPXQKBrNxcMUf=WbFASkHgwhqYueiJvVPXQKBrNxcMOd
   if WbFASkHgwhqYueiJvVPXQKBrNxcMUj.get('mode')=='ADD_M3U':
    if WbFASkHgwhqYueiJvVPXQKBrNxcMUj.get('sType')=='wavve' and WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVE==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:WbFASkHgwhqYueiJvVPXQKBrNxcMUf=WbFASkHgwhqYueiJvVPXQKBrNxcMOn
    if WbFASkHgwhqYueiJvVPXQKBrNxcMUj.get('sType')=='tving' and WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONTVING==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:WbFASkHgwhqYueiJvVPXQKBrNxcMUf=WbFASkHgwhqYueiJvVPXQKBrNxcMOn
    if WbFASkHgwhqYueiJvVPXQKBrNxcMUj.get('sType')=='spotv' and WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONSPOTV==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:WbFASkHgwhqYueiJvVPXQKBrNxcMUf=WbFASkHgwhqYueiJvVPXQKBrNxcMOn
   if WbFASkHgwhqYueiJvVPXQKBrNxcMUf==WbFASkHgwhqYueiJvVPXQKBrNxcMOd:
    if 'icon' in WbFASkHgwhqYueiJvVPXQKBrNxcMUj:WbFASkHgwhqYueiJvVPXQKBrNxcMUz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',WbFASkHgwhqYueiJvVPXQKBrNxcMUj.get('icon')) 
    WbFASkHgwhqYueiJvVPXQKBrNxcMUm.add_dir(WbFASkHgwhqYueiJvVPXQKBrNxcMUp,sublabel='',img=WbFASkHgwhqYueiJvVPXQKBrNxcMUz,infoLabels=WbFASkHgwhqYueiJvVPXQKBrNxcMOf,isFolder=WbFASkHgwhqYueiJvVPXQKBrNxcMUo,params=WbFASkHgwhqYueiJvVPXQKBrNxcMUy,isLink=WbFASkHgwhqYueiJvVPXQKBrNxcMUn)
  if WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMUO)>0:xbmcplugin.endOfDirectory(WbFASkHgwhqYueiJvVPXQKBrNxcMUm._addon_handle,cacheToDisc=WbFASkHgwhqYueiJvVPXQKBrNxcMOd)
 def dp_Delete_M3u(WbFASkHgwhqYueiJvVPXQKBrNxcMUm,args):
  WbFASkHgwhqYueiJvVPXQKBrNxcMUa=xbmcgui.Dialog()
  WbFASkHgwhqYueiJvVPXQKBrNxcMlU=WbFASkHgwhqYueiJvVPXQKBrNxcMUa.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if WbFASkHgwhqYueiJvVPXQKBrNxcMlU==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:sys.exit()
  WbFASkHgwhqYueiJvVPXQKBrNxcMlO=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.make_M3u_Filename(tempyn=WbFASkHgwhqYueiJvVPXQKBrNxcMOn)
  if xbmcvfs.exists(WbFASkHgwhqYueiJvVPXQKBrNxcMlO):
   if xbmcvfs.delete(WbFASkHgwhqYueiJvVPXQKBrNxcMlO)==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:
    WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_noti(__language__(30910).encode('utf-8'))
    return
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(WbFASkHgwhqYueiJvVPXQKBrNxcMUm,args):
  WbFASkHgwhqYueiJvVPXQKBrNxcMlG=args.get('sType')
  WbFASkHgwhqYueiJvVPXQKBrNxcMlm=args.get('sName')
  WbFASkHgwhqYueiJvVPXQKBrNxcMUa=xbmcgui.Dialog()
  WbFASkHgwhqYueiJvVPXQKBrNxcMlU=WbFASkHgwhqYueiJvVPXQKBrNxcMUa.yesno((WbFASkHgwhqYueiJvVPXQKBrNxcMlm+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if WbFASkHgwhqYueiJvVPXQKBrNxcMlU==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:sys.exit()
  WbFASkHgwhqYueiJvVPXQKBrNxcMlL =[]
  WbFASkHgwhqYueiJvVPXQKBrNxcMls =[]
  if WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='all':
   WbFASkHgwhqYueiJvVPXQKBrNxcMlO=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.make_M3u_Filename(tempyn=WbFASkHgwhqYueiJvVPXQKBrNxcMOd)
   if os.path.isfile(WbFASkHgwhqYueiJvVPXQKBrNxcMlO):os.remove(WbFASkHgwhqYueiJvVPXQKBrNxcMlO)
   WbFASkHgwhqYueiJvVPXQKBrNxcMlO=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.make_M3u_Filename(tempyn=WbFASkHgwhqYueiJvVPXQKBrNxcMOn)
   if xbmcvfs.exists(WbFASkHgwhqYueiJvVPXQKBrNxcMlO):
    if xbmcvfs.delete(WbFASkHgwhqYueiJvVPXQKBrNxcMlO)==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:
     WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_noti(__language__(30910).encode('utf-8'))
     return
  if(WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='wavve' or WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='all')and WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVE:
   WbFASkHgwhqYueiJvVPXQKBrNxcMlC=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.BoritvObj.Get_ChannelList_Wavve(exceptGroup=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.make_EexceptGroup_Wavve())
   if WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMlC)!=0:WbFASkHgwhqYueiJvVPXQKBrNxcMlL.extend(WbFASkHgwhqYueiJvVPXQKBrNxcMlC)
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_log('wavve cnt ----> '+WbFASkHgwhqYueiJvVPXQKBrNxcMGl(WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMlC)))
  if(WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='tving' or WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='all')and WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONTVING:
   WbFASkHgwhqYueiJvVPXQKBrNxcMlC=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.BoritvObj.Get_ChannelList_Tving()
   if WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMlC)!=0:WbFASkHgwhqYueiJvVPXQKBrNxcMlL.extend(WbFASkHgwhqYueiJvVPXQKBrNxcMlC)
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_log('tving cnt ----> '+WbFASkHgwhqYueiJvVPXQKBrNxcMGl(WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMlC)))
  if(WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='spotv' or WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='all')and WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONSPOTV:
   WbFASkHgwhqYueiJvVPXQKBrNxcMlC=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.BoritvObj.Get_ChannelList_Spotv(payyn=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONSPOTVPAY)
   if WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMlC)!=0:WbFASkHgwhqYueiJvVPXQKBrNxcMlL.extend(WbFASkHgwhqYueiJvVPXQKBrNxcMlC)
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_log('spotv cnt ----> '+WbFASkHgwhqYueiJvVPXQKBrNxcMGl(WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMlC)))
  if WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMlL)==0:
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_noti(__language__(30909).encode('utf8'))
   return
  for WbFASkHgwhqYueiJvVPXQKBrNxcMlE in WbFASkHgwhqYueiJvVPXQKBrNxcMUm.BoritvObj.INIT_GENRESORT:
   for WbFASkHgwhqYueiJvVPXQKBrNxcMla in WbFASkHgwhqYueiJvVPXQKBrNxcMlL:
    if WbFASkHgwhqYueiJvVPXQKBrNxcMla['genrenm']==WbFASkHgwhqYueiJvVPXQKBrNxcMlE:
     WbFASkHgwhqYueiJvVPXQKBrNxcMls.append(WbFASkHgwhqYueiJvVPXQKBrNxcMla)
  for WbFASkHgwhqYueiJvVPXQKBrNxcMla in WbFASkHgwhqYueiJvVPXQKBrNxcMlL:
   if WbFASkHgwhqYueiJvVPXQKBrNxcMla['genrenm']not in WbFASkHgwhqYueiJvVPXQKBrNxcMUm.BoritvObj.INIT_GENRESORT:
    WbFASkHgwhqYueiJvVPXQKBrNxcMls.append(WbFASkHgwhqYueiJvVPXQKBrNxcMla)
  try:
   WbFASkHgwhqYueiJvVPXQKBrNxcMlO=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.make_M3u_Filename(tempyn=WbFASkHgwhqYueiJvVPXQKBrNxcMOd)
   if os.path.isfile(WbFASkHgwhqYueiJvVPXQKBrNxcMlO):
    fp=WbFASkHgwhqYueiJvVPXQKBrNxcMGO(WbFASkHgwhqYueiJvVPXQKBrNxcMlO,'a',-1,'utf-8')
   else:
    fp=WbFASkHgwhqYueiJvVPXQKBrNxcMGO(WbFASkHgwhqYueiJvVPXQKBrNxcMlO,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for WbFASkHgwhqYueiJvVPXQKBrNxcMlD in WbFASkHgwhqYueiJvVPXQKBrNxcMls:
    WbFASkHgwhqYueiJvVPXQKBrNxcMlI =WbFASkHgwhqYueiJvVPXQKBrNxcMlD['channelid']
    WbFASkHgwhqYueiJvVPXQKBrNxcMlt =WbFASkHgwhqYueiJvVPXQKBrNxcMlD['channelnm']
    WbFASkHgwhqYueiJvVPXQKBrNxcMlT=WbFASkHgwhqYueiJvVPXQKBrNxcMlD['channelimg']
    WbFASkHgwhqYueiJvVPXQKBrNxcMlp =WbFASkHgwhqYueiJvVPXQKBrNxcMlD['ott']
    WbFASkHgwhqYueiJvVPXQKBrNxcMlR ='%s.%s'%(WbFASkHgwhqYueiJvVPXQKBrNxcMlI,WbFASkHgwhqYueiJvVPXQKBrNxcMlp)
    WbFASkHgwhqYueiJvVPXQKBrNxcMlj=WbFASkHgwhqYueiJvVPXQKBrNxcMlD['genrenm']
    if WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_DISPLAYNM:
     WbFASkHgwhqYueiJvVPXQKBrNxcMlt='%s (%s)'%(WbFASkHgwhqYueiJvVPXQKBrNxcMlt,WbFASkHgwhqYueiJvVPXQKBrNxcMlp)
    if WbFASkHgwhqYueiJvVPXQKBrNxcMlj=='라디오/음악':
     WbFASkHgwhqYueiJvVPXQKBrNxcMlz='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(WbFASkHgwhqYueiJvVPXQKBrNxcMlR,WbFASkHgwhqYueiJvVPXQKBrNxcMlt,WbFASkHgwhqYueiJvVPXQKBrNxcMlj,WbFASkHgwhqYueiJvVPXQKBrNxcMlT,WbFASkHgwhqYueiJvVPXQKBrNxcMlt)
    else:
     WbFASkHgwhqYueiJvVPXQKBrNxcMlz='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(WbFASkHgwhqYueiJvVPXQKBrNxcMlR,WbFASkHgwhqYueiJvVPXQKBrNxcMlt,WbFASkHgwhqYueiJvVPXQKBrNxcMlj,WbFASkHgwhqYueiJvVPXQKBrNxcMlT,WbFASkHgwhqYueiJvVPXQKBrNxcMlt)
    if WbFASkHgwhqYueiJvVPXQKBrNxcMlp=='wavve':
     WbFASkHgwhqYueiJvVPXQKBrNxcMly ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(WbFASkHgwhqYueiJvVPXQKBrNxcMlI)
    elif WbFASkHgwhqYueiJvVPXQKBrNxcMlp=='tving':
     WbFASkHgwhqYueiJvVPXQKBrNxcMly ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(WbFASkHgwhqYueiJvVPXQKBrNxcMlI)
    elif WbFASkHgwhqYueiJvVPXQKBrNxcMlp=='spotv':
     WbFASkHgwhqYueiJvVPXQKBrNxcMly ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(WbFASkHgwhqYueiJvVPXQKBrNxcMlI)
    fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMlz)
    fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMly)
   fp.close()
  except:
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_noti(__language__(30910).encode('utf8'))
   return
  WbFASkHgwhqYueiJvVPXQKBrNxcMlo=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.make_M3u_Filename(tempyn=WbFASkHgwhqYueiJvVPXQKBrNxcMOd)
  WbFASkHgwhqYueiJvVPXQKBrNxcMln=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.make_M3u_Filename(tempyn=WbFASkHgwhqYueiJvVPXQKBrNxcMOn)
  if xbmcvfs.copy(WbFASkHgwhqYueiJvVPXQKBrNxcMlo,WbFASkHgwhqYueiJvVPXQKBrNxcMln):
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_noti((WbFASkHgwhqYueiJvVPXQKBrNxcMlm+' '+__language__(30908)).encode('utf8'))
  else:
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_noti(__language__(30910).encode('utf-8'))
 def dp_Make_Epg(WbFASkHgwhqYueiJvVPXQKBrNxcMUm,args):
  WbFASkHgwhqYueiJvVPXQKBrNxcMlG=args.get('sType')
  WbFASkHgwhqYueiJvVPXQKBrNxcMlm=args.get('sName')
  WbFASkHgwhqYueiJvVPXQKBrNxcMlf=args.get('sNoti')
  if WbFASkHgwhqYueiJvVPXQKBrNxcMlf!='N':
   WbFASkHgwhqYueiJvVPXQKBrNxcMUa=xbmcgui.Dialog()
   WbFASkHgwhqYueiJvVPXQKBrNxcMlU=WbFASkHgwhqYueiJvVPXQKBrNxcMUa.yesno((WbFASkHgwhqYueiJvVPXQKBrNxcMlm+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if WbFASkHgwhqYueiJvVPXQKBrNxcMlU==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:sys.exit()
  WbFASkHgwhqYueiJvVPXQKBrNxcMld=[]
  WbFASkHgwhqYueiJvVPXQKBrNxcMOU=[]
  if(WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='wavve' or WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='all')and WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVE:
   WbFASkHgwhqYueiJvVPXQKBrNxcMOl,WbFASkHgwhqYueiJvVPXQKBrNxcMOG=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.make_EexceptGroup_Wavve())
   if WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMOG)!=0:
    WbFASkHgwhqYueiJvVPXQKBrNxcMld.extend(WbFASkHgwhqYueiJvVPXQKBrNxcMOl)
    WbFASkHgwhqYueiJvVPXQKBrNxcMOU.extend(WbFASkHgwhqYueiJvVPXQKBrNxcMOG)
  if(WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='tving' or WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='all')and WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONTVING:
   WbFASkHgwhqYueiJvVPXQKBrNxcMOl,WbFASkHgwhqYueiJvVPXQKBrNxcMOG=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.BoritvObj.Get_EpgInfo_Tving()
   if WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMOG)!=0:
    WbFASkHgwhqYueiJvVPXQKBrNxcMld.extend(WbFASkHgwhqYueiJvVPXQKBrNxcMOl)
    WbFASkHgwhqYueiJvVPXQKBrNxcMOU.extend(WbFASkHgwhqYueiJvVPXQKBrNxcMOG)
  if(WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='spotv' or WbFASkHgwhqYueiJvVPXQKBrNxcMlG=='all')and WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONSPOTV:
   WbFASkHgwhqYueiJvVPXQKBrNxcMOl,WbFASkHgwhqYueiJvVPXQKBrNxcMOG=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.BoritvObj.Get_EpgInfo_Spotv(payyn=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONSPOTVPAY)
   if WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMOG)!=0:
    WbFASkHgwhqYueiJvVPXQKBrNxcMld.extend(WbFASkHgwhqYueiJvVPXQKBrNxcMOl)
    WbFASkHgwhqYueiJvVPXQKBrNxcMOU.extend(WbFASkHgwhqYueiJvVPXQKBrNxcMOG)
  if WbFASkHgwhqYueiJvVPXQKBrNxcMGU(WbFASkHgwhqYueiJvVPXQKBrNxcMOU)==0:
   if WbFASkHgwhqYueiJvVPXQKBrNxcMlf!='N':WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   WbFASkHgwhqYueiJvVPXQKBrNxcMlO=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.make_Epg_Filename(tempyn=WbFASkHgwhqYueiJvVPXQKBrNxcMOd)
   fp=WbFASkHgwhqYueiJvVPXQKBrNxcMGO(WbFASkHgwhqYueiJvVPXQKBrNxcMlO,'w',-1,'utf-8')
   WbFASkHgwhqYueiJvVPXQKBrNxcMOm='<?xml version="1.0" encoding="UTF-8"?>\n'
   WbFASkHgwhqYueiJvVPXQKBrNxcMOL='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   WbFASkHgwhqYueiJvVPXQKBrNxcMOs='<tv generator-info-name="boritv_epg">\n\n'
   WbFASkHgwhqYueiJvVPXQKBrNxcMOC='\n</tv>\n'
   fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMOm)
   fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMOL)
   fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMOs)
   for WbFASkHgwhqYueiJvVPXQKBrNxcMOE in WbFASkHgwhqYueiJvVPXQKBrNxcMld:
    WbFASkHgwhqYueiJvVPXQKBrNxcMOa='  <channel id="%s.%s">\n' %(WbFASkHgwhqYueiJvVPXQKBrNxcMOE.get('channelid'),WbFASkHgwhqYueiJvVPXQKBrNxcMOE.get('ott'))
    WbFASkHgwhqYueiJvVPXQKBrNxcMOD='    <display-name>%s</display-name>\n'%(WbFASkHgwhqYueiJvVPXQKBrNxcMOE.get('channelnm'))
    WbFASkHgwhqYueiJvVPXQKBrNxcMOI='    <icon src="%s" />\n' %(WbFASkHgwhqYueiJvVPXQKBrNxcMOE.get('channelimg'))
    WbFASkHgwhqYueiJvVPXQKBrNxcMOt='  </channel>\n\n'
    fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMOa)
    fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMOD)
    fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMOI)
    fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMOt)
   for WbFASkHgwhqYueiJvVPXQKBrNxcMOE in WbFASkHgwhqYueiJvVPXQKBrNxcMOU:
    WbFASkHgwhqYueiJvVPXQKBrNxcMOa='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(WbFASkHgwhqYueiJvVPXQKBrNxcMOE.get('startTime'),WbFASkHgwhqYueiJvVPXQKBrNxcMOE.get('endTime'),WbFASkHgwhqYueiJvVPXQKBrNxcMOE.get('channelid'),WbFASkHgwhqYueiJvVPXQKBrNxcMOE.get('ott'))
    WbFASkHgwhqYueiJvVPXQKBrNxcMOD='    <title lang="kr">%s</title>\n' %(WbFASkHgwhqYueiJvVPXQKBrNxcMOE.get('title'))
    WbFASkHgwhqYueiJvVPXQKBrNxcMOI='  </programme>\n\n'
    fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMOa)
    fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMOD)
    fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMOI)
   fp.write(WbFASkHgwhqYueiJvVPXQKBrNxcMOC)
   fp.close()
  except:
   if WbFASkHgwhqYueiJvVPXQKBrNxcMlf!='N':WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_noti(__language__(30910).encode('utf8'))
   return
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.MakeEpg_SaveJson()
  WbFASkHgwhqYueiJvVPXQKBrNxcMlo=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.make_Epg_Filename(tempyn=WbFASkHgwhqYueiJvVPXQKBrNxcMOd)
  WbFASkHgwhqYueiJvVPXQKBrNxcMln=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.make_Epg_Filename(tempyn=WbFASkHgwhqYueiJvVPXQKBrNxcMOn)
  if xbmcvfs.copy(WbFASkHgwhqYueiJvVPXQKBrNxcMlo,WbFASkHgwhqYueiJvVPXQKBrNxcMln):
   if WbFASkHgwhqYueiJvVPXQKBrNxcMlf!='N':WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_noti((WbFASkHgwhqYueiJvVPXQKBrNxcMlm+' '+__language__(30912)).encode('utf8'))
  else:
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_AUTORESTART:
    WbFASkHgwhqYueiJvVPXQKBrNxcMOT=xbmcaddon.Addon('pvr.iptvsimple')
    WbFASkHgwhqYueiJvVPXQKBrNxcMOT.setSetting('anything','anything')
  except:
   WbFASkHgwhqYueiJvVPXQKBrNxcMOf 
 def make_EexceptGroup_Wavve(WbFASkHgwhqYueiJvVPXQKBrNxcMUm):
  WbFASkHgwhqYueiJvVPXQKBrNxcMOp=[]
  if WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVERADIO==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:
   WbFASkHgwhqYueiJvVPXQKBrNxcMOp.append('라디오/음악')
  if WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVEHOME==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:
   WbFASkHgwhqYueiJvVPXQKBrNxcMOp.append('홈쇼핑')
  if WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONRELIGION==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:
   WbFASkHgwhqYueiJvVPXQKBrNxcMOp.append('종교')
  return WbFASkHgwhqYueiJvVPXQKBrNxcMOp
 def get_radio_list(WbFASkHgwhqYueiJvVPXQKBrNxcMUm):
  if WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVERADIO==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:return[]
  WbFASkHgwhqYueiJvVPXQKBrNxcMOR=[{'broadcastid':'46584','genre':'10'}]
  return WbFASkHgwhqYueiJvVPXQKBrNxcMUm.BoritvObj.Get_ChannelList_WavveExcept(WbFASkHgwhqYueiJvVPXQKBrNxcMOR)
 def check_config(WbFASkHgwhqYueiJvVPXQKBrNxcMUm):
  WbFASkHgwhqYueiJvVPXQKBrNxcMOj=WbFASkHgwhqYueiJvVPXQKBrNxcMOd
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVE =WbFASkHgwhqYueiJvVPXQKBrNxcMOd if __addon__.getSetting('onWavve')=='true' else WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONTVING =WbFASkHgwhqYueiJvVPXQKBrNxcMOd if __addon__.getSetting('onTvng')=='true' else WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONSPOTV =WbFASkHgwhqYueiJvVPXQKBrNxcMOd if __addon__.getSetting('onSpotv')=='true' else WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVERADIO=WbFASkHgwhqYueiJvVPXQKBrNxcMOd if __addon__.getSetting('onWavveRadio')=='true' else WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVEHOME =WbFASkHgwhqYueiJvVPXQKBrNxcMOd if __addon__.getSetting('onWavveHome')=='true' else WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONRELIGION =WbFASkHgwhqYueiJvVPXQKBrNxcMOd if __addon__.getSetting('onWavveReligion')=='true' else WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONSPOTVPAY =WbFASkHgwhqYueiJvVPXQKBrNxcMOd if __addon__.getSetting('onSpotvPay')=='true' else WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_DISPLAYNM =WbFASkHgwhqYueiJvVPXQKBrNxcMOd if __addon__.getSetting('displayOTTnm')=='true' else WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_AUTORESTART =WbFASkHgwhqYueiJvVPXQKBrNxcMOd if __addon__.getSetting('autoRestart')=='true' else WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  if WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_FILE_PATH=='' or WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_FILE_NAME=='':WbFASkHgwhqYueiJvVPXQKBrNxcMOj=WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  if WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONWAVVE==WbFASkHgwhqYueiJvVPXQKBrNxcMOn and WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONTVING=='' and WbFASkHgwhqYueiJvVPXQKBrNxcMUm.M3U_ONSPOTV=='':WbFASkHgwhqYueiJvVPXQKBrNxcMOj=WbFASkHgwhqYueiJvVPXQKBrNxcMOn
  if WbFASkHgwhqYueiJvVPXQKBrNxcMOj==WbFASkHgwhqYueiJvVPXQKBrNxcMOn:
   WbFASkHgwhqYueiJvVPXQKBrNxcMUa=xbmcgui.Dialog()
   WbFASkHgwhqYueiJvVPXQKBrNxcMlU=WbFASkHgwhqYueiJvVPXQKBrNxcMUa.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if WbFASkHgwhqYueiJvVPXQKBrNxcMlU==WbFASkHgwhqYueiJvVPXQKBrNxcMOd:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(WbFASkHgwhqYueiJvVPXQKBrNxcMUm):
  WbFASkHgwhqYueiJvVPXQKBrNxcMOz={'date_makeepg':WbFASkHgwhqYueiJvVPXQKBrNxcMUm.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=WbFASkHgwhqYueiJvVPXQKBrNxcMGO(WbFASkHgwhqYueiJvVPXQKBrNxcMUG,'w',-1,'utf-8')
   json.dump(WbFASkHgwhqYueiJvVPXQKBrNxcMOz,fp)
   fp.close()
  except WbFASkHgwhqYueiJvVPXQKBrNxcMGm as exception:
   return
 def boritv_main(WbFASkHgwhqYueiJvVPXQKBrNxcMUm):
  WbFASkHgwhqYueiJvVPXQKBrNxcMOy=WbFASkHgwhqYueiJvVPXQKBrNxcMUm.main_params.get('mode',WbFASkHgwhqYueiJvVPXQKBrNxcMOf)
  WbFASkHgwhqYueiJvVPXQKBrNxcMUm.check_config()
  if WbFASkHgwhqYueiJvVPXQKBrNxcMOy is WbFASkHgwhqYueiJvVPXQKBrNxcMOf:
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.dp_Main_List()
  elif WbFASkHgwhqYueiJvVPXQKBrNxcMOy=='DEL_M3U':
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.dp_Delete_M3u(WbFASkHgwhqYueiJvVPXQKBrNxcMUm.main_params)
  elif WbFASkHgwhqYueiJvVPXQKBrNxcMOy=='ADD_M3U':
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.dp_MakeAdd_M3u(WbFASkHgwhqYueiJvVPXQKBrNxcMUm.main_params)
  elif WbFASkHgwhqYueiJvVPXQKBrNxcMOy=='ADD_EPG':
   WbFASkHgwhqYueiJvVPXQKBrNxcMUm.dp_Make_Epg(WbFASkHgwhqYueiJvVPXQKBrNxcMUm.main_params)
  else:
   WbFASkHgwhqYueiJvVPXQKBrNxcMOf
# Created by pyminifier (https://github.com/liftoff/pyminifier)
