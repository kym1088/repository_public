__author__="NightRain"
OTPJGfQjyxiwbucRszdeDaKtolpUnr=str
OTPJGfQjyxiwbucRszdeDaKtolpUnX=True
OTPJGfQjyxiwbucRszdeDaKtolpUnN=False
OTPJGfQjyxiwbucRszdeDaKtolpUnF=print
OTPJGfQjyxiwbucRszdeDaKtolpUnH=open
OTPJGfQjyxiwbucRszdeDaKtolpUng=Exception
OTPJGfQjyxiwbucRszdeDaKtolpUYn=int
import json
import time
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 OTPJGfQjyxiwbucRszdeDaKtolpUnL='ADDON'
except:
 OTPJGfQjyxiwbucRszdeDaKtolpUnL='SINGLE'
if OTPJGfQjyxiwbucRszdeDaKtolpUnL=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  OTPJGfQjyxiwbucRszdeDaKtolpUnV=OTPJGfQjyxiwbucRszdeDaKtolpUnr(string).encode('utf-8','ignore')
  OTPJGfQjyxiwbucRszdeDaKtolpUnW=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,OTPJGfQjyxiwbucRszdeDaKtolpUnV),level=OTPJGfQjyxiwbucRszdeDaKtolpUnW)
 def addon_getautoepg():
  return OTPJGfQjyxiwbucRszdeDaKtolpUnX if __addon__.getSetting('autoEpg')=='true' else OTPJGfQjyxiwbucRszdeDaKtolpUnN
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  OTPJGfQjyxiwbucRszdeDaKtolpUnF(string)
 def addon_getautoepg():
  return OTPJGfQjyxiwbucRszdeDaKtolpUnX
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class OTPJGfQjyxiwbucRszdeDaKtolpUnY():
 def __init__(OTPJGfQjyxiwbucRszdeDaKtolpUnh):
  OTPJGfQjyxiwbucRszdeDaKtolpUnh.START_INTERVAL =3000 
  OTPJGfQjyxiwbucRszdeDaKtolpUnh.INTERVAL =20 
  OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_FILETAGNM ='date_makeepg'
  OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_MAKEDATE ='-' 
  OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_WILL_TM =-1 
 def Get_Now_Datetime(OTPJGfQjyxiwbucRszdeDaKtolpUnh):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(OTPJGfQjyxiwbucRszdeDaKtolpUnh):
  OTPJGfQjyxiwbucRszdeDaKtolpUnA ='-'
  if OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_MAKEDATE=='-':
   try:
    fp=OTPJGfQjyxiwbucRszdeDaKtolpUnH(addon_epgupdate_confignm(),'r',-1,'utf-8')
    OTPJGfQjyxiwbucRszdeDaKtolpUnS= json.load(fp)
    fp.close()
    OTPJGfQjyxiwbucRszdeDaKtolpUnA=OTPJGfQjyxiwbucRszdeDaKtolpUnS[OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_FILETAGNM]
   except OTPJGfQjyxiwbucRszdeDaKtolpUng as exception:
    return 2 
  else:
   OTPJGfQjyxiwbucRszdeDaKtolpUnA=OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_MAKEDATE
  OTPJGfQjyxiwbucRszdeDaKtolpUnm =OTPJGfQjyxiwbucRszdeDaKtolpUnh.Get_Now_Datetime()
  OTPJGfQjyxiwbucRszdeDaKtolpUnI=(OTPJGfQjyxiwbucRszdeDaKtolpUnm-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  OTPJGfQjyxiwbucRszdeDaKtolpUnq =OTPJGfQjyxiwbucRszdeDaKtolpUnm.strftime('%Y-%m-%d')
  OTPJGfQjyxiwbucRszdeDaKtolpUnk =OTPJGfQjyxiwbucRszdeDaKtolpUnm.strftime('%H')
  if OTPJGfQjyxiwbucRszdeDaKtolpUnA==OTPJGfQjyxiwbucRszdeDaKtolpUnq: return-1
  if OTPJGfQjyxiwbucRszdeDaKtolpUnA==OTPJGfQjyxiwbucRszdeDaKtolpUnI and OTPJGfQjyxiwbucRszdeDaKtolpUnk=='00':return 30
  return 2
 def MakeEpg_RandomTm(OTPJGfQjyxiwbucRszdeDaKtolpUnh,mintm):
  OTPJGfQjyxiwbucRszdeDaKtolpUnE=(mintm*60)+random.randint(0,60)
  OTPJGfQjyxiwbucRszdeDaKtolpUnm =OTPJGfQjyxiwbucRszdeDaKtolpUnh.Get_Now_Datetime()
  OTPJGfQjyxiwbucRszdeDaKtolpUnM =(OTPJGfQjyxiwbucRszdeDaKtolpUnm+datetime.timedelta(seconds=OTPJGfQjyxiwbucRszdeDaKtolpUnE)).strftime('%Y%m%d%H%M%S')
  return OTPJGfQjyxiwbucRszdeDaKtolpUYn(OTPJGfQjyxiwbucRszdeDaKtolpUnM)
 def MakeEpg_SaveJson(OTPJGfQjyxiwbucRszdeDaKtolpUnh):
  OTPJGfQjyxiwbucRszdeDaKtolpUnS={OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_FILETAGNM:OTPJGfQjyxiwbucRszdeDaKtolpUnh.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=OTPJGfQjyxiwbucRszdeDaKtolpUnH(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(OTPJGfQjyxiwbucRszdeDaKtolpUnS,fp)
   fp.close()
  except OTPJGfQjyxiwbucRszdeDaKtolpUng as exception:
   return
 def service_run(OTPJGfQjyxiwbucRszdeDaKtolpUnh):
  if addon_getautoepg()==OTPJGfQjyxiwbucRszdeDaKtolpUnN:return
  OTPJGfQjyxiwbucRszdeDaKtolpUnB=OTPJGfQjyxiwbucRszdeDaKtolpUnh.MakeEpg_DateCheck()
  if OTPJGfQjyxiwbucRszdeDaKtolpUnB<0:
   return
  if OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_WILL_TM<0:
   OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_WILL_TM=OTPJGfQjyxiwbucRszdeDaKtolpUnh.MakeEpg_RandomTm(OTPJGfQjyxiwbucRszdeDaKtolpUnB)
   addon_log('EPG_WILL_TM --> '+OTPJGfQjyxiwbucRszdeDaKtolpUnr(OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_WILL_TM))
  else:
   OTPJGfQjyxiwbucRszdeDaKtolpUnq=OTPJGfQjyxiwbucRszdeDaKtolpUnh.Get_Now_Datetime()
   if OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_WILL_TM<OTPJGfQjyxiwbucRszdeDaKtolpUYn(OTPJGfQjyxiwbucRszdeDaKtolpUnq.strftime('%Y%m%d%H%M%S')):
    addon_log('make epg')
    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
    OTPJGfQjyxiwbucRszdeDaKtolpUnh.MakeEpg_SaveJson()
    OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_MAKEDATE=OTPJGfQjyxiwbucRszdeDaKtolpUnq.strftime('%Y-%m-%d')
    OTPJGfQjyxiwbucRszdeDaKtolpUnh.EPG_WILL_TM =-1
   else:
    pass
  pass
if __name__=="__main__":
 addon_log('__main__')
 OTPJGfQjyxiwbucRszdeDaKtolpUnC=OTPJGfQjyxiwbucRszdeDaKtolpUnY()
 time.sleep(OTPJGfQjyxiwbucRszdeDaKtolpUnC.START_INTERVAL)
 while OTPJGfQjyxiwbucRszdeDaKtolpUnX:
  time.sleep(OTPJGfQjyxiwbucRszdeDaKtolpUnC.INTERVAL)
  OTPJGfQjyxiwbucRszdeDaKtolpUnC.service_run()
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
