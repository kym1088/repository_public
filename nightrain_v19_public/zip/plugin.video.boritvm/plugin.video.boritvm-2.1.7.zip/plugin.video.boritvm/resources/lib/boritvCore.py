__author__="NightRain"
UhdmiTcSOXuJjbRFkpzCEYgAfDHPns=False
UhdmiTcSOXuJjbRFkpzCEYgAfDHPna=object
UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM=None
UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN=str
UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL=Exception
UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB=print
UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr=True
UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW=int
UhdmiTcSOXuJjbRFkpzCEYgAfDHPnI=range
UhdmiTcSOXuJjbRFkpzCEYgAfDHPny=len
UhdmiTcSOXuJjbRFkpzCEYgAfDHPnl=set
UhdmiTcSOXuJjbRFkpzCEYgAfDHPne=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
UhdmiTcSOXuJjbRFkpzCEYgAfDHPsM=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
UhdmiTcSOXuJjbRFkpzCEYgAfDHPsN=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':UhdmiTcSOXuJjbRFkpzCEYgAfDHPns,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':UhdmiTcSOXuJjbRFkpzCEYgAfDHPns,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':UhdmiTcSOXuJjbRFkpzCEYgAfDHPns,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':UhdmiTcSOXuJjbRFkpzCEYgAfDHPns,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':UhdmiTcSOXuJjbRFkpzCEYgAfDHPns,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':UhdmiTcSOXuJjbRFkpzCEYgAfDHPns,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class UhdmiTcSOXuJjbRFkpzCEYgAfDHPsa(UhdmiTcSOXuJjbRFkpzCEYgAfDHPna):
 def __init__(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_WAVVE ='https://apis.wavve.com'
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_TVING ='https://api.tving.com'
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_TVINGIMG ='https://image.tving.com'
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_SPOTV ='https://www.spotvnow.co.kr'
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_SEEZN ='https://api.seezntv.com'
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.HTTPTAG ='https://'
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.LIMIT_WAVVE =200
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.LIMIT_TVING =60
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.LIMIT_TVINGEPG=20 
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.APPVERSION ='91.0.4472.124' 
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.DEVICEMODEL ='Chrome' 
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.OSTYPE ='Windows' 
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.OSVERSION ='NT 10.0' 
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.SEEZN_HEADER ={'X-APP-VERSION':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.APPVERSION,'X-DEVICE-MODEL':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.DEVICEMODEL,'X-OS-TYPE':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.OSTYPE,'X-OS-VERSION':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.OSVERSION,}
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.DEFAULT_HEADER={'user-agent':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.USER_AGENT}
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.SLEEP_TIME =0.2
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.INIT_GENRESORT=MASTER_GENRE
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,jobtype,UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,redirects=UhdmiTcSOXuJjbRFkpzCEYgAfDHPns):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsr=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.DEFAULT_HEADER
  if headers:UhdmiTcSOXuJjbRFkpzCEYgAfDHPsr.update(headers)
  if jobtype=='Get':
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsW=requests.get(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,params=params,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsr,cookies=cookies,allow_redirects=redirects)
  else:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsW=requests.post(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,data=payload,params=params,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsr,cookies=cookies,allow_redirects=redirects)
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPsW
 def Get_DefaultParams_Wavve(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI
 def Get_DefaultParams_Tving(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI
 def Get_Now_Datetime(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,in_text):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsl=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPsl
 def Get_ChannelList_Wavve(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,exceptGroup=[]):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse =[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsv=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_ChannelImg_Wavve()
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_WAVVE+'/cf/live/recommend-channels'
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI.update(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_DefaultParams_Wavve())
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
   if not('celllist' in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['cell_toplist']):return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['cell_toplist']['celllist']
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPst=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['contentid']
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsQ=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['title_list'][0]['text']
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPst in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsv:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPso=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsv[UhdmiTcSOXuJjbRFkpzCEYgAfDHPst]
    else:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPso=''
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_getGenre(UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'wavve')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'channelnm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsQ,'channelimg':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.HTTPTAG+UhdmiTcSOXuJjbRFkpzCEYgAfDHPso if UhdmiTcSOXuJjbRFkpzCEYgAfDHPso!='' else '','ott':'wavve','genrenm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV}
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV not in exceptGroup:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPse.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse
 def Get_ChannelList_WavveExcept(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,exceptGroup=[]):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse=[]
  if exceptGroup==[]:return[]
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_WAVVE+'/cf/live/recommend-channels'
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in exceptGroup:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI={'WeekDay':'all','adult':'n','broadcastid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['broadcastid'],'contenttype':'channel','genre':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['genre'],'isrecommend':'y','limit':UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI.update(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_DefaultParams_Wavve())
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM)
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
    if not('celllist' in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['cell_toplist']):return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['cell_toplist']['celllist']
    for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPse.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['contentid'])
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse
 def Get_ChannelImg_Wavve(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaM={}
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPaN=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_Now_Datetime()
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPan =UhdmiTcSOXuJjbRFkpzCEYgAfDHPaN+datetime.timedelta(hours=3)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_WAVVE+'/live/epgs'
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI={'limit':UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPaN.strftime('%Y-%m-%d %H:00'),'enddatetime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPan.strftime('%Y-%m-%d %H:00')}
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI.update(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_DefaultParams_Wavve())
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['list']
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPaM[UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['channelid']]=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['channelimage']
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPaM
 def Get_ChanneGenrename_Wavve(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,UhdmiTcSOXuJjbRFkpzCEYgAfDHPst):
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_WAVVE+'/live/channels/'+UhdmiTcSOXuJjbRFkpzCEYgAfDHPst
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_DefaultParams_Wavve()
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['genretext']
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return ''
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL
 def Get_ChannelList_Spotv(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,payyn=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse=[]
  try:
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsN:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPst=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['videoId']
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'channelnm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['name'],'channelimg':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['logo'],'ott':'spotv','genrenm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_getGenre(UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'spotv')}
    if payyn==UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr or UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['free']==UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPse.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse
 def Get_ChannelList_Tving(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse =[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaB=[]
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_TVING+'/v2/media/lives'
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI={'pageNo':'1','pageSize':UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI.update(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_DefaultParams_Tving())
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
   if not('result' in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['body']):return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['body']['result']
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx:
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['live_code']=='C44441':continue 
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPaB.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['live_code'])
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsv=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_ChannelImg_Tving(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaB)
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPst=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['live_code']
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPst=='C44441':continue 
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsQ=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['schedule']['channel']['name']['ko']
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPst in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsv:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPso=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsv[UhdmiTcSOXuJjbRFkpzCEYgAfDHPst]
    else:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPso=''
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'channelnm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsQ,'channelimg':UhdmiTcSOXuJjbRFkpzCEYgAfDHPso,'ott':'tving','genrenm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_getGenre(UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'tving')}
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPse.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse
 def Get_timestamp(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,timetype=1):
  ts=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,timetype):
  if timetype=='1':
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPar={'transactionId':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPar={'timestamp':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_timestamp(timetype=1),'transactionId':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_timestamp(timetype=1)+'000000000000001',}
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPar
 def Get_ChannelList_Seezn(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,exceptGroup=[]):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse =[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaW =UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr if 'won' in exceptGroup else UhdmiTcSOXuJjbRFkpzCEYgAfDHPns
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaI =UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr if '홈쇼핑' in exceptGroup else UhdmiTcSOXuJjbRFkpzCEYgAfDHPns
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPay=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr if '라디오/음악' in exceptGroup else UhdmiTcSOXuJjbRFkpzCEYgAfDHPns
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_SEEZN+'/svc/menu/app6/api/epg_chlist' 
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI={'category_id':'2','istest':'0',}
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPal=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Make_Header_Timestamp(timetype='2')
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPal.update(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.SEEZN_HEADER)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPal,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,redirects=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr)
   if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.status_code!=200:return[]
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
   if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK.get('meta').get('code')!='200':return[]
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPae=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK.get('data').get('list')[0].get('list_channel')
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPae:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPav =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq.get('bit_rate_info').split(",")[0]
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPst =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq.get('ch_no')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_getGenre(UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'seezn')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPaw =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq.get('type')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'channelnm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq.get('service_ch_name').replace(',','.'),'channelimg':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq.get('ch_image_list'),'ott':'seezn','genrenm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV,}
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPst=='404':continue 
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['adult_yn']=='Y':continue 
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['won_yn'] =='Y' and UhdmiTcSOXuJjbRFkpzCEYgAfDHPaW==UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr:continue 
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV in exceptGroup:continue 
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPaw!='EPG':
     if UhdmiTcSOXuJjbRFkpzCEYgAfDHPaI and UhdmiTcSOXuJjbRFkpzCEYgAfDHPaw=='SHOP' :continue
     if UhdmiTcSOXuJjbRFkpzCEYgAfDHPay and UhdmiTcSOXuJjbRFkpzCEYgAfDHPaw=='AUDIO_MUSIC':continue
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPse.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse
 def Get_EpgInfo_Seezn(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,exceptGroup=[]):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse=[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG =[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_ChannelList_Seezn(exceptGroup)
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_SEEZN+'/svc/menu/app6/api/epg_proglist' 
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK in UhdmiTcSOXuJjbRFkpzCEYgAfDHPse:
    time.sleep(0.3)
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPst =UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK.get('channelid')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI={'ch_no':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst}
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPal=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Make_Header_Timestamp(timetype='2')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPal.update(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.SEEZN_HEADER)
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPal,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,redirects=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr)
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.status_code!=200:return[],[]
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPax=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPax.get('meta').get('code')!='200':return[],[]
    for UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPax.get('data').get('list'):
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPat=UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq.get('start_ymd')
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPaN=UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq.get('start_time').replace(':','')
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPan =UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq.get('end_time').replace(':','')
     if UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaN)>UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW(UhdmiTcSOXuJjbRFkpzCEYgAfDHPan):
      UhdmiTcSOXuJjbRFkpzCEYgAfDHPaQ=datetime.datetime.strptime(UhdmiTcSOXuJjbRFkpzCEYgAfDHPat,'%Y%m%d')+datetime.timedelta(days=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW(1))
      UhdmiTcSOXuJjbRFkpzCEYgAfDHPaQ=UhdmiTcSOXuJjbRFkpzCEYgAfDHPaQ.strftime('%Y%m%d')
     else:
      UhdmiTcSOXuJjbRFkpzCEYgAfDHPaQ=UhdmiTcSOXuJjbRFkpzCEYgAfDHPat
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'title':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.xmlText(urllib.parse.unquote_plus(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq.get('program_name'))),'startTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPat+UhdmiTcSOXuJjbRFkpzCEYgAfDHPaN+'00','endTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPaQ+UhdmiTcSOXuJjbRFkpzCEYgAfDHPan+'00','ott':'seezn'}
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[],[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse,UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG
 def make_EpgDatetime_Tving(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,days=2):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPao=[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaV=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_DateList(days=2,dateType='2')
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMs=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPaV:
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPMa in UhdmiTcSOXuJjbRFkpzCEYgAfDHPnI(8):
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'ndate':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq,'starttm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsM[UhdmiTcSOXuJjbRFkpzCEYgAfDHPMa]['starttm'],'endtm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsM[UhdmiTcSOXuJjbRFkpzCEYgAfDHPMa]['endtm']}
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPMN=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq+UhdmiTcSOXuJjbRFkpzCEYgAfDHPsM[UhdmiTcSOXuJjbRFkpzCEYgAfDHPMa]['starttm'])
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPMn=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq+UhdmiTcSOXuJjbRFkpzCEYgAfDHPsM[UhdmiTcSOXuJjbRFkpzCEYgAfDHPMa]['endtm'])
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPMs<=UhdmiTcSOXuJjbRFkpzCEYgAfDHPMN or(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMN<UhdmiTcSOXuJjbRFkpzCEYgAfDHPMs and UhdmiTcSOXuJjbRFkpzCEYgAfDHPMs<UhdmiTcSOXuJjbRFkpzCEYgAfDHPMn):
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPao.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPao
 def make_DateList(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,days=2,dateType='1'):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaV=[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPML =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_Now_Datetime()
  if dateType=='1':
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPML=UhdmiTcSOXuJjbRFkpzCEYgAfDHPML-datetime.timedelta(days=1)
  for i in UhdmiTcSOXuJjbRFkpzCEYgAfDHPnI(days):
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPMB=UhdmiTcSOXuJjbRFkpzCEYgAfDHPML+datetime.timedelta(days=i)
   if dateType=='1':
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPaV.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMB.strftime('%Y%m%d'))
   else:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPaV.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMB.strftime('%Y%m%d'))
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPaV
 def make_Tving_ChannleGroup(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,UhdmiTcSOXuJjbRFkpzCEYgAfDHPaB):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMr=[]
  i=0
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMW=''
  for UhdmiTcSOXuJjbRFkpzCEYgAfDHPMI in UhdmiTcSOXuJjbRFkpzCEYgAfDHPaB:
   if i==0:UhdmiTcSOXuJjbRFkpzCEYgAfDHPMW=UhdmiTcSOXuJjbRFkpzCEYgAfDHPMI
   else:UhdmiTcSOXuJjbRFkpzCEYgAfDHPMW+=',%s'%(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMI)
   i+=1
   if i>=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.LIMIT_TVINGEPG:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPMr.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMW)
    i=0
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPMW=''
  if UhdmiTcSOXuJjbRFkpzCEYgAfDHPMW!='':
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPMr.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMW)
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPMr
 def Get_ChannelImg_Tving(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,chid_list):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaM={}
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPMy=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_Now_Datetime().strftime('%Y%m%d')
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPaN =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsM[6]['starttm'] 
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPan =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsM[6]['endtm']
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPMr=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_Tving_ChannleGroup(chid_list)
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPMr:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_TVING+'/v2/media/schedules'
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI={'pageNo':'1','pageSize':UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':UhdmiTcSOXuJjbRFkpzCEYgAfDHPMy,'broadcastDate':UhdmiTcSOXuJjbRFkpzCEYgAfDHPMy,'startBroadTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPaN,'endBroadTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPan,'channelCode':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq}
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI.update(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_DefaultParams_Tving())
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM)
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
    if not('result' in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['body']):return{}
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['body']['result']
    for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx:
     for UhdmiTcSOXuJjbRFkpzCEYgAfDHPMl in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['image']:
      if UhdmiTcSOXuJjbRFkpzCEYgAfDHPMl['code']=='CAIC0400':UhdmiTcSOXuJjbRFkpzCEYgAfDHPaM[UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['channel_code']]=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_TVINGIMG+UhdmiTcSOXuJjbRFkpzCEYgAfDHPMl['url']
      elif UhdmiTcSOXuJjbRFkpzCEYgAfDHPMl['code']=='CAIC1400':UhdmiTcSOXuJjbRFkpzCEYgAfDHPaM[UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['channel_code']]=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_TVINGIMG+UhdmiTcSOXuJjbRFkpzCEYgAfDHPMl['url']
      elif UhdmiTcSOXuJjbRFkpzCEYgAfDHPMl['code']=='CAIC1900':UhdmiTcSOXuJjbRFkpzCEYgAfDHPaM[UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['channel_code']]=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_TVINGIMG+UhdmiTcSOXuJjbRFkpzCEYgAfDHPMl['url']
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return{}
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPaM
 def Get_EpgInfo_Spotv(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,days=3,payyn=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse=[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG =[]
  try:
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsN:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPst =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['videoId']
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'channelnm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.xmlText(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['name']),'channelimg':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['logo'],'ott':'spotv','epgtype':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['epgtype'],'epgnm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['epgnm']}
    if payyn==UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr or UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['free']==UhdmiTcSOXuJjbRFkpzCEYgAfDHPnr:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPse.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[],[]
  '''
  try:
   for now_day in days_list:
    url = self.API_SPOTV + '/api/v2/program/' + now_day
    response = self.callRequestCookies('Get', url, payload=None, params=None, headers=None, cookies=None )
    res_json = json.loads(response.text )
    for i_section in res_json:
     if find_list.get(i_section['channelId'] ) == None: continue
     temp_list = {'channelid' : find_list.get(i_section['channelId'] ) , 'title' : self.xmlText(i_section['title'] ) , 'startTime' : i_section['startTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'endTime' : i_section['endTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'ott' : 'spotv' }
     epg_list.append(temp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  try:
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK in UhdmiTcSOXuJjbRFkpzCEYgAfDHPse:
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK['epgtype']=='spotvon':
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPMe=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_EpgInfo_Spotv_spotvon(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK['channelid'],UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK['epgnm'],days)
     if UhdmiTcSOXuJjbRFkpzCEYgAfDHPny(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMe)>0:UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG.extend(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMe)
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK['epgtype']=='spotvnet':
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPMe=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_EpgInfo_Spotv_spotvnet(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK['channelid'],UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK['epgnm'],days)
     if UhdmiTcSOXuJjbRFkpzCEYgAfDHPny(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMe)>0:UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG.extend(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMe)
    time.sleep(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.SLEEP_TIME)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[],[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse,UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG
 def Get_EpgInfo_Spotv_spotvon(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,epgnm,days):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG =[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaV=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_DateList(days=days,dateType='1')
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMv=''
  try:
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPMw in UhdmiTcSOXuJjbRFkpzCEYgAfDHPaV:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,UhdmiTcSOXuJjbRFkpzCEYgAfDHPMw)
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM)
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
    for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'title':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.xmlText(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['title']),'startTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['sch_date'].replace('-','')+UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['sch_hour']).zfill(2)+UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['sch_min']+'00','ott':'spotv'}
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPMv=UhdmiTcSOXuJjbRFkpzCEYgAfDHPMw
   for i in UhdmiTcSOXuJjbRFkpzCEYgAfDHPnI(UhdmiTcSOXuJjbRFkpzCEYgAfDHPny(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG)):
    if i>0:UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i-1]['endTime']=UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i]['startTime']
    if i==UhdmiTcSOXuJjbRFkpzCEYgAfDHPny(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG)-1: UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i]['endTime']=UhdmiTcSOXuJjbRFkpzCEYgAfDHPMv+'240000'
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG
 def Get_EpgInfo_Spotv_spotvnet(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,epgnm,days):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG =[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaV=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_DateList(days=days,dateType='1')
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMv=''
  try:
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPMw in UhdmiTcSOXuJjbRFkpzCEYgAfDHPaV:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,UhdmiTcSOXuJjbRFkpzCEYgAfDHPMw)
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM)
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
    for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'title':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.xmlText(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['title']),'startTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['sch_date'].replace('-','')+UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['sch_hour']).zfill(2)+UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['sch_min']+'00','ott':'spotv'}
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPMv=UhdmiTcSOXuJjbRFkpzCEYgAfDHPMw
   for i in UhdmiTcSOXuJjbRFkpzCEYgAfDHPnI(UhdmiTcSOXuJjbRFkpzCEYgAfDHPny(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG)):
    if i>0:UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i-1]['endTime']=UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i]['startTime']
    if i==UhdmiTcSOXuJjbRFkpzCEYgAfDHPny(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG)-1: UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i]['endTime']=UhdmiTcSOXuJjbRFkpzCEYgAfDHPMv+'240000'
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG
 def Get_EpgInfo_Wavve(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,days=2,exceptGroup=[]):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse =[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG =[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPML =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_Now_Datetime()
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMG =UhdmiTcSOXuJjbRFkpzCEYgAfDHPML+datetime.timedelta(hours=-2)
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMK =UhdmiTcSOXuJjbRFkpzCEYgAfDHPML+datetime.timedelta(days=(days-1))
  if UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMG.strftime('%H'))<=3:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPMx=UhdmiTcSOXuJjbRFkpzCEYgAfDHPMG.strftime('%Y-%m-%d 00:00')
  else:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPMx=UhdmiTcSOXuJjbRFkpzCEYgAfDHPMG.strftime('%Y-%m-%d %H:00')
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMq =UhdmiTcSOXuJjbRFkpzCEYgAfDHPMK.strftime('%Y-%m-%d 24:00')
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_WAVVE+'/live/epgs'
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI={'limit':UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPMx,'enddatetime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPMq}
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI.update(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_DefaultParams_Wavve())
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPax=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['list']
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPax:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPst =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['channelid']
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_getGenre(UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'wavve')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'channelnm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.xmlText(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['channelname']),'channelimg':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.HTTPTAG+UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['channelimage'],'ott':'wavve'}
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV not in exceptGroup:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPse.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
    for UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['list']:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['channelid'],'title':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.xmlText(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq['title']),'startTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV not in exceptGroup and UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq['starttime']!=UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq['endtime']:
      UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[],[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMt=UhdmiTcSOXuJjbRFkpzCEYgAfDHPny(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG)
  for i in(UhdmiTcSOXuJjbRFkpzCEYgAfDHPnI(1,UhdmiTcSOXuJjbRFkpzCEYgAfDHPMt)):
   if UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i-1]['endTime'])+1==UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i]['startTime'])and UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i-1]['channelid']==UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i]['channelid']:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i-1]['endTime']=UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG[i]['startTime']
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse,UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG
 def Get_EpgInfo_Tving(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,days=2):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse=[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG =[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMQ =[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMo =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_EpgDatetime_Tving(days=days)
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_ChannelList_Tving()
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMV=[]
  for i in UhdmiTcSOXuJjbRFkpzCEYgAfDHPnI(UhdmiTcSOXuJjbRFkpzCEYgAfDHPny(UhdmiTcSOXuJjbRFkpzCEYgAfDHPse)):
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPse[i]['channelnm']=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.xmlText(UhdmiTcSOXuJjbRFkpzCEYgAfDHPse[i]['channelnm'])
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPMV.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPse[i]['channelid'])
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNs=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_Tving_ChannleGroup(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMV)
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_TVING+'/v2/media/schedules'
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPNa in UhdmiTcSOXuJjbRFkpzCEYgAfDHPMo:
    for UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK in UhdmiTcSOXuJjbRFkpzCEYgAfDHPNs:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI={'pageNo':'1','pageSize':UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':UhdmiTcSOXuJjbRFkpzCEYgAfDHPNa['ndate'],'broadcastDate':UhdmiTcSOXuJjbRFkpzCEYgAfDHPNa['ndate'],'startBroadTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPNa['starttm'],'endBroadTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPNa['endtm'],'channelCode':UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK}
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI.update(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_DefaultParams_Tving())
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM)
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['body']['result']
     for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx:
      if 'schedules' not in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq:continue
      if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['schedules']==UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM:continue
      for UhdmiTcSOXuJjbRFkpzCEYgAfDHPNM in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['schedules']:
       UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPNM['schedule_code'],'title':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.xmlText(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNM['program']['name']['ko']),'startTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNM['broadcast_start_time']),'endTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNM['broadcast_end_time']),'ott':'tving'}
       UhdmiTcSOXuJjbRFkpzCEYgAfDHPNn=UhdmiTcSOXuJjbRFkpzCEYgAfDHPNM['schedule_code']+UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNM['broadcast_start_time'])
       if UhdmiTcSOXuJjbRFkpzCEYgAfDHPNn in UhdmiTcSOXuJjbRFkpzCEYgAfDHPMQ:continue
       UhdmiTcSOXuJjbRFkpzCEYgAfDHPMQ.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNn)
       UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
     time.sleep(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.SLEEP_TIME)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[],[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse,UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG
 def Get_BaseInfo_Samsungtv(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL={}
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_SAMSUNGTV
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM)
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPNB in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.cookies:
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPNB.name=='session':
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL['session']=UhdmiTcSOXuJjbRFkpzCEYgAfDHPNB.value
    elif UhdmiTcSOXuJjbRFkpzCEYgAfDHPNB.name=='session.sig':
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL['session.sig']=UhdmiTcSOXuJjbRFkpzCEYgAfDHPNB.value
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return{}
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_SAMSUNGTV+'/user'
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPNr={'session':UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL['session'],'session.sig':UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL['session.sig'],}
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPNr)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL['countryCode']=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK.get('countryCode')
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL['uuid'] =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK.get('uuid')
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL['ip'] =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK.get('ip')
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return{}
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL
 def t_Cache(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPMs =UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW(time.time())
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNW=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnW(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMs-UhdmiTcSOXuJjbRFkpzCEYgAfDHPMs%3600)
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPNW,UhdmiTcSOXuJjbRFkpzCEYgAfDHPMs
 def zlib_compress(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,plaintext):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNI=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNI).decode('utf-8')
 def Get_BaseRequest_Samsungtv(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK={}
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.API_SAMSUNGTV+'/api/lives'
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPNW,UhdmiTcSOXuJjbRFkpzCEYgAfDHPMs=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.t_Cache()
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPNy=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.zlib_compress(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL['uuid']+':'+UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPMs))
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPNr={'session':UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL['session'],'session.sig':UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL['session.sig'],}
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI ={'t':UhdmiTcSOXuJjbRFkpzCEYgAfDHPnN(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNW)}
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPal ={'x-cred-payload':UhdmiTcSOXuJjbRFkpzCEYgAfDHPNy}
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.callRequestCookies('Get',UhdmiTcSOXuJjbRFkpzCEYgAfDHPsw,payload=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnM,params=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsI,headers=UhdmiTcSOXuJjbRFkpzCEYgAfDHPal,cookies=UhdmiTcSOXuJjbRFkpzCEYgAfDHPNr)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=json.loads(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsG.text)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK
 def Get_ChannelList_Samsungtv(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL,exceptGroup=[]):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse =[]
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_BaseRequest_Samsungtv(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['live']['channel']
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsx:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPst =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq.get('id')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsQ =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq.get('name')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPso=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq.get('logo')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_getGenre(UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'samsung')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'channelnm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsQ,'channelimg':UhdmiTcSOXuJjbRFkpzCEYgAfDHPso,'ott':'samsung','genrenm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV}
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV not in exceptGroup:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPse.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse
 def Get_EpgInfo_Samsungtv(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL,exceptGroup=[]):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPse=[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG =[]
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_BaseRequest_Samsungtv(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsK['live']['channel']
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK in UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPst =UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK.get('id')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsQ =UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK.get('name')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPso=UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK.get('logo')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPax =UhdmiTcSOXuJjbRFkpzCEYgAfDHPaK.get('program')
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.make_getGenre(UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'samsung')
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV in exceptGroup:
     continue
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'channelnm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsQ,'channelimg':UhdmiTcSOXuJjbRFkpzCEYgAfDHPso,'ott':'samsung','genrenm':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsV}
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPse.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
    for UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPax:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPNl=UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq.get('start_time')
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPNe =UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq.get('duration') 
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPaN=datetime.datetime.strptime(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNl,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPan =UhdmiTcSOXuJjbRFkpzCEYgAfDHPaN+datetime.timedelta(seconds=UhdmiTcSOXuJjbRFkpzCEYgAfDHPNe)
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPas={'channelid':UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,'title':UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.xmlText(urllib.parse.unquote_plus(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaq.get('title'))),'startTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPaN.strftime('%Y%m%d%H%M00'),'endTime':UhdmiTcSOXuJjbRFkpzCEYgAfDHPan.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  except UhdmiTcSOXuJjbRFkpzCEYgAfDHPnL as exception:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB(exception)
   return[],[]
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPse,UhdmiTcSOXuJjbRFkpzCEYgAfDHPaG
 def make_getGenre(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,UhdmiTcSOXuJjbRFkpzCEYgAfDHPNQ):
  try:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.INIT_CHANNEL.get(UhdmiTcSOXuJjbRFkpzCEYgAfDHPst+'.'+UhdmiTcSOXuJjbRFkpzCEYgAfDHPNQ).get('genre')
  except:
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.INIT_CHANNEL.get('-').get('genre')
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL
 def make_base_allchannel_py(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn,UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL):
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv =[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNw=[]
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNG=UhdmiTcSOXuJjbRFkpzCEYgAfDHPnl()
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPas=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_ChannelList_Wavve()
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv.extend(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPas=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_ChannelList_Tving()
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv.extend(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPas=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_ChannelList_Seezn()
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv.extend(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPas=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_ChannelList_Samsungtv(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNL)
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv.extend(UhdmiTcSOXuJjbRFkpzCEYgAfDHPas)
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB('1')
  for i in UhdmiTcSOXuJjbRFkpzCEYgAfDHPnI(UhdmiTcSOXuJjbRFkpzCEYgAfDHPny(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv)):
   if UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv[i]['genrenm']=='-':
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv[i]['ott']=='wavve':
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL=UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.Get_ChanneGenrename_Wavve(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv[i]['channelid'])
     if UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL not in UhdmiTcSOXuJjbRFkpzCEYgAfDHPNG:UhdmiTcSOXuJjbRFkpzCEYgAfDHPNG.add(UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL)
     time.sleep(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.SLEEP_TIME)
    elif UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv[i]['ott']=='spotv':
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL='스포츠'
    else:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL='-'
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv[i]['genrenm']=UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL
   else:
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv[i]['genrenm']not in UhdmiTcSOXuJjbRFkpzCEYgAfDHPNG:UhdmiTcSOXuJjbRFkpzCEYgAfDHPNG.add(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv[i]['genrenm'])
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNG.add(UhdmiTcSOXuJjbRFkpzCEYgAfDHPsn.INIT_CHANNEL.get('-').get('genre'))
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB('2')
  for UhdmiTcSOXuJjbRFkpzCEYgAfDHPNK in UhdmiTcSOXuJjbRFkpzCEYgAfDHPNG:
   for UhdmiTcSOXuJjbRFkpzCEYgAfDHPNx in UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv:
    if UhdmiTcSOXuJjbRFkpzCEYgAfDHPNx['genrenm']==UhdmiTcSOXuJjbRFkpzCEYgAfDHPNK:
     UhdmiTcSOXuJjbRFkpzCEYgAfDHPNw.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNx)
  for UhdmiTcSOXuJjbRFkpzCEYgAfDHPNx in UhdmiTcSOXuJjbRFkpzCEYgAfDHPNv:
   if UhdmiTcSOXuJjbRFkpzCEYgAfDHPNx['genrenm']not in UhdmiTcSOXuJjbRFkpzCEYgAfDHPNG:
    UhdmiTcSOXuJjbRFkpzCEYgAfDHPNw.append(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNx)
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPnB('3')
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNq='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNq):os.remove(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNq)
  fp=UhdmiTcSOXuJjbRFkpzCEYgAfDHPne(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNq,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  UhdmiTcSOXuJjbRFkpzCEYgAfDHPNt=UhdmiTcSOXuJjbRFkpzCEYgAfDHPny(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNw)
  i=0
  for UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq in UhdmiTcSOXuJjbRFkpzCEYgAfDHPNw:
   i+=1
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPst =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['channelid']
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPsQ =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['channelnm']
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPNQ =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['ott']
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPNo ='%s.%s'%(UhdmiTcSOXuJjbRFkpzCEYgAfDHPst,UhdmiTcSOXuJjbRFkpzCEYgAfDHPNQ)
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsq['genrenm']
   UhdmiTcSOXuJjbRFkpzCEYgAfDHPNV='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNo,UhdmiTcSOXuJjbRFkpzCEYgAfDHPsQ,UhdmiTcSOXuJjbRFkpzCEYgAfDHPaL)
   if i<UhdmiTcSOXuJjbRFkpzCEYgAfDHPNt:
    fp.write(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNV+',\n')
   else:
    fp.write(UhdmiTcSOXuJjbRFkpzCEYgAfDHPNV+'\n')
  fp.write('}\n')
  fp.close()
  return UhdmiTcSOXuJjbRFkpzCEYgAfDHPNG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
