__author__="NightRain"
BoylxMhGFuJvPAwXcQRnapEKOqfzUT=object
BoylxMhGFuJvPAwXcQRnapEKOqfzUW=False
BoylxMhGFuJvPAwXcQRnapEKOqfzUk=None
BoylxMhGFuJvPAwXcQRnapEKOqfzUd=True
BoylxMhGFuJvPAwXcQRnapEKOqfzUs=len
BoylxMhGFuJvPAwXcQRnapEKOqfzUC=str
BoylxMhGFuJvPAwXcQRnapEKOqfzUI=open
BoylxMhGFuJvPAwXcQRnapEKOqfzUr=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
BoylxMhGFuJvPAwXcQRnapEKOqfzDH=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (시즌)','mode':'ADD_M3U','sType':'seezn','sName':'시즌'},{'title':'     - M3U 추가 (삼성tv 플러스)','mode':'ADD_M3U','sType':'samsung','sName':'삼성TV 플러스'},{'title':'     - M3U 추가 (사용자 m3u)','mode':'ADD_M3U','sType':'custom','sName':'사용자 m3u 파일'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
BoylxMhGFuJvPAwXcQRnapEKOqfzDU=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class BoylxMhGFuJvPAwXcQRnapEKOqfzDL(BoylxMhGFuJvPAwXcQRnapEKOqfzUT):
 def __init__(BoylxMhGFuJvPAwXcQRnapEKOqfzDj,BoylxMhGFuJvPAwXcQRnapEKOqfzDT,BoylxMhGFuJvPAwXcQRnapEKOqfzDW,BoylxMhGFuJvPAwXcQRnapEKOqfzDk):
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj._addon_url =BoylxMhGFuJvPAwXcQRnapEKOqfzDT
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj._addon_handle =BoylxMhGFuJvPAwXcQRnapEKOqfzDW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.main_params =BoylxMhGFuJvPAwXcQRnapEKOqfzDk
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_FILE_PATH ='' 
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_FILE_NAME ='' 
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVE =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONTVING =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSPOTV =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZN =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSAMSUNG =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVERADIO =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVEHOME =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONRELIGION =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSPOTVPAY =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZNPAY =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZNHOME =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZNRADIO =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSAMSUNGHOME=BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_DISPLAYNM =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_AUTORESTART =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_CUSTOM_LIST =[]
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj =UhdmiTcSOXuJjbRFkpzCEYgAfDHPsa() 
 def addon_noti(BoylxMhGFuJvPAwXcQRnapEKOqfzDj,sting):
  try:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDs=xbmcgui.Dialog()
   BoylxMhGFuJvPAwXcQRnapEKOqfzDs.notification(__addonname__,sting)
  except:
   BoylxMhGFuJvPAwXcQRnapEKOqfzUk
 def addon_log(BoylxMhGFuJvPAwXcQRnapEKOqfzDj,string):
  try:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDC=string.encode('utf-8','ignore')
  except:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDC='addonException: addon_log'
  BoylxMhGFuJvPAwXcQRnapEKOqfzDI=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,BoylxMhGFuJvPAwXcQRnapEKOqfzDC),level=BoylxMhGFuJvPAwXcQRnapEKOqfzDI)
 def get_keyboard_input(BoylxMhGFuJvPAwXcQRnapEKOqfzDj,BoylxMhGFuJvPAwXcQRnapEKOqfzDY):
  BoylxMhGFuJvPAwXcQRnapEKOqfzDr=BoylxMhGFuJvPAwXcQRnapEKOqfzUk
  kb=xbmc.Keyboard()
  kb.setHeading(BoylxMhGFuJvPAwXcQRnapEKOqfzDY)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   BoylxMhGFuJvPAwXcQRnapEKOqfzDr=kb.getText()
  return BoylxMhGFuJvPAwXcQRnapEKOqfzDr
 def add_dir(BoylxMhGFuJvPAwXcQRnapEKOqfzDj,label,sublabel='',img='',infoLabels=BoylxMhGFuJvPAwXcQRnapEKOqfzUk,isFolder=BoylxMhGFuJvPAwXcQRnapEKOqfzUd,params='',isLink=BoylxMhGFuJvPAwXcQRnapEKOqfzUW,ContextMenu=BoylxMhGFuJvPAwXcQRnapEKOqfzUk):
  BoylxMhGFuJvPAwXcQRnapEKOqfzDm='%s?%s'%(BoylxMhGFuJvPAwXcQRnapEKOqfzDj._addon_url,urllib.parse.urlencode(params))
  if sublabel:BoylxMhGFuJvPAwXcQRnapEKOqfzDY='%s < %s >'%(label,sublabel)
  else: BoylxMhGFuJvPAwXcQRnapEKOqfzDY=label
  if not img:img='DefaultFolder.png'
  BoylxMhGFuJvPAwXcQRnapEKOqfzDt=xbmcgui.ListItem(BoylxMhGFuJvPAwXcQRnapEKOqfzDY)
  BoylxMhGFuJvPAwXcQRnapEKOqfzDt.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:BoylxMhGFuJvPAwXcQRnapEKOqfzDt.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDt.setProperty('IsPlayable','true')
  if ContextMenu:BoylxMhGFuJvPAwXcQRnapEKOqfzDt.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(BoylxMhGFuJvPAwXcQRnapEKOqfzDj._addon_handle,BoylxMhGFuJvPAwXcQRnapEKOqfzDm,BoylxMhGFuJvPAwXcQRnapEKOqfzDt,isFolder)
 def make_M3u_Filename(BoylxMhGFuJvPAwXcQRnapEKOqfzDj,tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUW):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_FILE_PATH+BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(BoylxMhGFuJvPAwXcQRnapEKOqfzDj,tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUW):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_FILE_PATH+BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_FILE_NAME+'.xml'
 def dp_Main_List(BoylxMhGFuJvPAwXcQRnapEKOqfzDj):
  for BoylxMhGFuJvPAwXcQRnapEKOqfzDe in BoylxMhGFuJvPAwXcQRnapEKOqfzDH:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDY=BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('title')
   BoylxMhGFuJvPAwXcQRnapEKOqfzDg=''
   BoylxMhGFuJvPAwXcQRnapEKOqfzDN={'mode':BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('mode'),'sType':BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('sType'),'sName':BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('sName')}
   if BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('mode')=='XXX':
    BoylxMhGFuJvPAwXcQRnapEKOqfzDb=BoylxMhGFuJvPAwXcQRnapEKOqfzUW
    BoylxMhGFuJvPAwXcQRnapEKOqfzDi =BoylxMhGFuJvPAwXcQRnapEKOqfzUd
   else:
    BoylxMhGFuJvPAwXcQRnapEKOqfzDb=BoylxMhGFuJvPAwXcQRnapEKOqfzUd
    BoylxMhGFuJvPAwXcQRnapEKOqfzDi =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
   BoylxMhGFuJvPAwXcQRnapEKOqfzDV=BoylxMhGFuJvPAwXcQRnapEKOqfzUd
   if BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('mode')=='ADD_M3U':
    if BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('sType')=='wavve' and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVE ==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:BoylxMhGFuJvPAwXcQRnapEKOqfzDV=BoylxMhGFuJvPAwXcQRnapEKOqfzUW
    if BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('sType')=='tving' and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONTVING ==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:BoylxMhGFuJvPAwXcQRnapEKOqfzDV=BoylxMhGFuJvPAwXcQRnapEKOqfzUW
    if BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('sType')=='spotv' and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSPOTV ==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:BoylxMhGFuJvPAwXcQRnapEKOqfzDV=BoylxMhGFuJvPAwXcQRnapEKOqfzUW
    if BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('sType')=='seezn' and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZN ==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:BoylxMhGFuJvPAwXcQRnapEKOqfzDV=BoylxMhGFuJvPAwXcQRnapEKOqfzUW
    if BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('sType')=='samsung' and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSAMSUNG==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:BoylxMhGFuJvPAwXcQRnapEKOqfzDV=BoylxMhGFuJvPAwXcQRnapEKOqfzUW
    if BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('sType')=='custom' and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_CUSTOM_LIST==[]:BoylxMhGFuJvPAwXcQRnapEKOqfzDV=BoylxMhGFuJvPAwXcQRnapEKOqfzUW
   if BoylxMhGFuJvPAwXcQRnapEKOqfzDV==BoylxMhGFuJvPAwXcQRnapEKOqfzUd:
    if 'icon' in BoylxMhGFuJvPAwXcQRnapEKOqfzDe:BoylxMhGFuJvPAwXcQRnapEKOqfzDg=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',BoylxMhGFuJvPAwXcQRnapEKOqfzDe.get('icon')) 
    BoylxMhGFuJvPAwXcQRnapEKOqfzDj.add_dir(BoylxMhGFuJvPAwXcQRnapEKOqfzDY,sublabel='',img=BoylxMhGFuJvPAwXcQRnapEKOqfzDg,infoLabels=BoylxMhGFuJvPAwXcQRnapEKOqfzUk,isFolder=BoylxMhGFuJvPAwXcQRnapEKOqfzDb,params=BoylxMhGFuJvPAwXcQRnapEKOqfzDN,isLink=BoylxMhGFuJvPAwXcQRnapEKOqfzDi)
  if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzDH)>0:xbmcplugin.endOfDirectory(BoylxMhGFuJvPAwXcQRnapEKOqfzDj._addon_handle,cacheToDisc=BoylxMhGFuJvPAwXcQRnapEKOqfzUd)
 def dp_Delete_M3u(BoylxMhGFuJvPAwXcQRnapEKOqfzDj,args):
  BoylxMhGFuJvPAwXcQRnapEKOqfzDs=xbmcgui.Dialog()
  BoylxMhGFuJvPAwXcQRnapEKOqfzLD=BoylxMhGFuJvPAwXcQRnapEKOqfzDs.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if BoylxMhGFuJvPAwXcQRnapEKOqfzLD==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:sys.exit()
  BoylxMhGFuJvPAwXcQRnapEKOqfzLH=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_M3u_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUW)
  if xbmcvfs.exists(BoylxMhGFuJvPAwXcQRnapEKOqfzLH):
   if xbmcvfs.delete(BoylxMhGFuJvPAwXcQRnapEKOqfzLH)==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:
    BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti(__language__(30910).encode('utf-8'))
    return
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(BoylxMhGFuJvPAwXcQRnapEKOqfzDj,args):
  BoylxMhGFuJvPAwXcQRnapEKOqfzLU=args.get('sType')
  BoylxMhGFuJvPAwXcQRnapEKOqfzLj=args.get('sName')
  BoylxMhGFuJvPAwXcQRnapEKOqfzDs=xbmcgui.Dialog()
  BoylxMhGFuJvPAwXcQRnapEKOqfzLD=BoylxMhGFuJvPAwXcQRnapEKOqfzDs.yesno((BoylxMhGFuJvPAwXcQRnapEKOqfzLj+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if BoylxMhGFuJvPAwXcQRnapEKOqfzLD==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:sys.exit()
  BoylxMhGFuJvPAwXcQRnapEKOqfzLT =[]
  BoylxMhGFuJvPAwXcQRnapEKOqfzLW =[]
  BoylxMhGFuJvPAwXcQRnapEKOqfzLH=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_M3u_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUd)
  if os.path.isfile(BoylxMhGFuJvPAwXcQRnapEKOqfzLH):os.remove(BoylxMhGFuJvPAwXcQRnapEKOqfzLH)
  if BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all':
   BoylxMhGFuJvPAwXcQRnapEKOqfzLH=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_M3u_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUW)
   if xbmcvfs.exists(BoylxMhGFuJvPAwXcQRnapEKOqfzLH):
    if xbmcvfs.delete(BoylxMhGFuJvPAwXcQRnapEKOqfzLH)==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:
     BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   BoylxMhGFuJvPAwXcQRnapEKOqfzLk=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_M3u_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUW)
   if xbmcvfs.exists(BoylxMhGFuJvPAwXcQRnapEKOqfzLk):
    BoylxMhGFuJvPAwXcQRnapEKOqfzLd=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_M3u_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUd)
    xbmcvfs.copy(BoylxMhGFuJvPAwXcQRnapEKOqfzLk,BoylxMhGFuJvPAwXcQRnapEKOqfzLd)
  if(BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='wavve' or BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all')and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVE:
   BoylxMhGFuJvPAwXcQRnapEKOqfzLs=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_ChannelList_Wavve(exceptGroup=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_EexceptGroup_Wavve())
   if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)!=0:BoylxMhGFuJvPAwXcQRnapEKOqfzLT.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_log('wavve cnt ----> '+BoylxMhGFuJvPAwXcQRnapEKOqfzUC(BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)))
  if(BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='tving' or BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all')and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONTVING:
   BoylxMhGFuJvPAwXcQRnapEKOqfzLs=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_ChannelList_Tving()
   if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)!=0:BoylxMhGFuJvPAwXcQRnapEKOqfzLT.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_log('tving cnt ----> '+BoylxMhGFuJvPAwXcQRnapEKOqfzUC(BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)))
  if(BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='spotv' or BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all')and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSPOTV:
   BoylxMhGFuJvPAwXcQRnapEKOqfzLs=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_ChannelList_Spotv(payyn=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSPOTVPAY)
   if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)!=0:BoylxMhGFuJvPAwXcQRnapEKOqfzLT.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_log('spotv cnt ----> '+BoylxMhGFuJvPAwXcQRnapEKOqfzUC(BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)))
  if(BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='seezn' or BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all')and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZN:
   BoylxMhGFuJvPAwXcQRnapEKOqfzLs=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_ChannelList_Seezn(exceptGroup=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_EexceptGroup_Seezn())
   if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)!=0:BoylxMhGFuJvPAwXcQRnapEKOqfzLT.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_log('seezn cnt ----> '+BoylxMhGFuJvPAwXcQRnapEKOqfzUC(BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)))
  if(BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='samsung' or BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all')and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSAMSUNG:
   BoylxMhGFuJvPAwXcQRnapEKOqfzLC=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_BaseInfo_Samsungtv()
   BoylxMhGFuJvPAwXcQRnapEKOqfzLs=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_ChannelList_Samsungtv(BoylxMhGFuJvPAwXcQRnapEKOqfzLC,exceptGroup=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_EexceptGroup_Samsungtv())
   if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)!=0:BoylxMhGFuJvPAwXcQRnapEKOqfzLT.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_log('samsungtv cnt ----> '+BoylxMhGFuJvPAwXcQRnapEKOqfzUC(BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLs)))
  if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLT)==0 and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_CUSTOM_LIST==[]:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti(__language__(30909).encode('utf8'))
   return
  for BoylxMhGFuJvPAwXcQRnapEKOqfzLI in BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.INIT_GENRESORT:
   for BoylxMhGFuJvPAwXcQRnapEKOqfzLr in BoylxMhGFuJvPAwXcQRnapEKOqfzLT:
    if BoylxMhGFuJvPAwXcQRnapEKOqfzLr['genrenm']==BoylxMhGFuJvPAwXcQRnapEKOqfzLI:
     BoylxMhGFuJvPAwXcQRnapEKOqfzLW.append(BoylxMhGFuJvPAwXcQRnapEKOqfzLr)
  for BoylxMhGFuJvPAwXcQRnapEKOqfzLr in BoylxMhGFuJvPAwXcQRnapEKOqfzLT:
   if BoylxMhGFuJvPAwXcQRnapEKOqfzLr['genrenm']not in BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.INIT_GENRESORT:
    BoylxMhGFuJvPAwXcQRnapEKOqfzLW.append(BoylxMhGFuJvPAwXcQRnapEKOqfzLr)
  try:
   if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzLT)>0:
    BoylxMhGFuJvPAwXcQRnapEKOqfzLH=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_M3u_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUd)
    if os.path.isfile(BoylxMhGFuJvPAwXcQRnapEKOqfzLH):
     fp=BoylxMhGFuJvPAwXcQRnapEKOqfzUI(BoylxMhGFuJvPAwXcQRnapEKOqfzLH,'a',-1,'utf-8')
    else:
     fp=BoylxMhGFuJvPAwXcQRnapEKOqfzUI(BoylxMhGFuJvPAwXcQRnapEKOqfzLH,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for BoylxMhGFuJvPAwXcQRnapEKOqfzLm in BoylxMhGFuJvPAwXcQRnapEKOqfzLW:
     BoylxMhGFuJvPAwXcQRnapEKOqfzLY =BoylxMhGFuJvPAwXcQRnapEKOqfzLm['channelid']
     BoylxMhGFuJvPAwXcQRnapEKOqfzLt =BoylxMhGFuJvPAwXcQRnapEKOqfzLm['channelnm']
     BoylxMhGFuJvPAwXcQRnapEKOqfzLe=BoylxMhGFuJvPAwXcQRnapEKOqfzLm['channelimg']
     BoylxMhGFuJvPAwXcQRnapEKOqfzLg =BoylxMhGFuJvPAwXcQRnapEKOqfzLm['ott']
     BoylxMhGFuJvPAwXcQRnapEKOqfzLN ='%s.%s'%(BoylxMhGFuJvPAwXcQRnapEKOqfzLY,BoylxMhGFuJvPAwXcQRnapEKOqfzLg)
     BoylxMhGFuJvPAwXcQRnapEKOqfzLb=BoylxMhGFuJvPAwXcQRnapEKOqfzLm['genrenm']
     if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_DISPLAYNM:
      BoylxMhGFuJvPAwXcQRnapEKOqfzLt='%s (%s)'%(BoylxMhGFuJvPAwXcQRnapEKOqfzLt,BoylxMhGFuJvPAwXcQRnapEKOqfzLg)
     if BoylxMhGFuJvPAwXcQRnapEKOqfzLb=='라디오/음악':
      BoylxMhGFuJvPAwXcQRnapEKOqfzLi='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(BoylxMhGFuJvPAwXcQRnapEKOqfzLN,BoylxMhGFuJvPAwXcQRnapEKOqfzLt,BoylxMhGFuJvPAwXcQRnapEKOqfzLb,BoylxMhGFuJvPAwXcQRnapEKOqfzLe,BoylxMhGFuJvPAwXcQRnapEKOqfzLt)
     else:
      BoylxMhGFuJvPAwXcQRnapEKOqfzLi='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(BoylxMhGFuJvPAwXcQRnapEKOqfzLN,BoylxMhGFuJvPAwXcQRnapEKOqfzLt,BoylxMhGFuJvPAwXcQRnapEKOqfzLb,BoylxMhGFuJvPAwXcQRnapEKOqfzLe,BoylxMhGFuJvPAwXcQRnapEKOqfzLt)
     if BoylxMhGFuJvPAwXcQRnapEKOqfzLg=='wavve':
      BoylxMhGFuJvPAwXcQRnapEKOqfzLV ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(BoylxMhGFuJvPAwXcQRnapEKOqfzLY)
     elif BoylxMhGFuJvPAwXcQRnapEKOqfzLg=='tving':
      BoylxMhGFuJvPAwXcQRnapEKOqfzLV ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(BoylxMhGFuJvPAwXcQRnapEKOqfzLY)
     elif BoylxMhGFuJvPAwXcQRnapEKOqfzLg=='spotv':
      BoylxMhGFuJvPAwXcQRnapEKOqfzLV ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(BoylxMhGFuJvPAwXcQRnapEKOqfzLY)
     elif BoylxMhGFuJvPAwXcQRnapEKOqfzLg=='seezn':
      BoylxMhGFuJvPAwXcQRnapEKOqfzLS='128' if BoylxMhGFuJvPAwXcQRnapEKOqfzLb=='라디오/음악' else '4000'
      BoylxMhGFuJvPAwXcQRnapEKOqfzLV ='plugin://plugin.video.seeznm/?mode=LIVE&mediacode=%s&bitrate=%s\n'%(BoylxMhGFuJvPAwXcQRnapEKOqfzLY,BoylxMhGFuJvPAwXcQRnapEKOqfzLS)
     if BoylxMhGFuJvPAwXcQRnapEKOqfzLg=='samsung':
      BoylxMhGFuJvPAwXcQRnapEKOqfzLV ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(BoylxMhGFuJvPAwXcQRnapEKOqfzLY)
     fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzLi)
     fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzLV)
    fp.close()
  except:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti(__language__(30910).encode('utf8'))
   return
  try:
   if(BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='custom' or BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all')and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_CUSTOM_LIST!=[]:
    BoylxMhGFuJvPAwXcQRnapEKOqfzLH=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_M3u_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUd)
    if os.path.isfile(BoylxMhGFuJvPAwXcQRnapEKOqfzLH):
     fp=BoylxMhGFuJvPAwXcQRnapEKOqfzUI(BoylxMhGFuJvPAwXcQRnapEKOqfzLH,'a',-1,'utf-8')
    else:
     fp=BoylxMhGFuJvPAwXcQRnapEKOqfzUI(BoylxMhGFuJvPAwXcQRnapEKOqfzLH,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for BoylxMhGFuJvPAwXcQRnapEKOqfzHD in BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_CUSTOM_LIST:
     BoylxMhGFuJvPAwXcQRnapEKOqfzHL=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.customEpg_FileRead(BoylxMhGFuJvPAwXcQRnapEKOqfzHD)
     for BoylxMhGFuJvPAwXcQRnapEKOqfzHU in BoylxMhGFuJvPAwXcQRnapEKOqfzHL:
      BoylxMhGFuJvPAwXcQRnapEKOqfzHU=BoylxMhGFuJvPAwXcQRnapEKOqfzHU.strip()
      if BoylxMhGFuJvPAwXcQRnapEKOqfzHU not in['','#EXTM3U']:
       fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHU+'\n')
   fp.close()
  except:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti(__language__(30910).encode('utf8'))
   return
  BoylxMhGFuJvPAwXcQRnapEKOqfzLk=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_M3u_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUd)
  BoylxMhGFuJvPAwXcQRnapEKOqfzLd=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_M3u_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUW)
  if xbmcvfs.copy(BoylxMhGFuJvPAwXcQRnapEKOqfzLk,BoylxMhGFuJvPAwXcQRnapEKOqfzLd):
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti((BoylxMhGFuJvPAwXcQRnapEKOqfzLj+' '+__language__(30908)).encode('utf8'))
  else:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti(__language__(30910).encode('utf-8'))
 def customEpg_FileList(BoylxMhGFuJvPAwXcQRnapEKOqfzDj):
  BoylxMhGFuJvPAwXcQRnapEKOqfzHj=[]
  if __addon__.getSetting('custom01on')=='true':BoylxMhGFuJvPAwXcQRnapEKOqfzHj.append(__addon__.getSetting('custom01nm'))
  if __addon__.getSetting('custom02on')=='true':BoylxMhGFuJvPAwXcQRnapEKOqfzHj.append(__addon__.getSetting('custom02nm'))
  if __addon__.getSetting('custom03on')=='true':BoylxMhGFuJvPAwXcQRnapEKOqfzHj.append(__addon__.getSetting('custom03nm'))
  if __addon__.getSetting('custom04on')=='true':BoylxMhGFuJvPAwXcQRnapEKOqfzHj.append(__addon__.getSetting('custom04nm'))
  if __addon__.getSetting('custom05on')=='true':BoylxMhGFuJvPAwXcQRnapEKOqfzHj.append(__addon__.getSetting('custom05nm'))
  return BoylxMhGFuJvPAwXcQRnapEKOqfzHj
 def customEpg_FileRead(BoylxMhGFuJvPAwXcQRnapEKOqfzDj,source_filename):
  try:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHT=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
   if os.path.isfile(BoylxMhGFuJvPAwXcQRnapEKOqfzHT):os.remove(BoylxMhGFuJvPAwXcQRnapEKOqfzHT)
   xbmcvfs.copy(source_filename,BoylxMhGFuJvPAwXcQRnapEKOqfzHT)
   fp=BoylxMhGFuJvPAwXcQRnapEKOqfzUI(BoylxMhGFuJvPAwXcQRnapEKOqfzHT,'r',-1,'utf-8')
   BoylxMhGFuJvPAwXcQRnapEKOqfzHW=fp.readlines()
  except:
   return[]
  return BoylxMhGFuJvPAwXcQRnapEKOqfzHW
 def dp_Make_Epg(BoylxMhGFuJvPAwXcQRnapEKOqfzDj,args):
  BoylxMhGFuJvPAwXcQRnapEKOqfzLU=args.get('sType')
  BoylxMhGFuJvPAwXcQRnapEKOqfzLj=args.get('sName')
  BoylxMhGFuJvPAwXcQRnapEKOqfzHk=args.get('sNoti')
  if BoylxMhGFuJvPAwXcQRnapEKOqfzHk!='N':
   BoylxMhGFuJvPAwXcQRnapEKOqfzDs=xbmcgui.Dialog()
   BoylxMhGFuJvPAwXcQRnapEKOqfzLD=BoylxMhGFuJvPAwXcQRnapEKOqfzDs.yesno((BoylxMhGFuJvPAwXcQRnapEKOqfzLj+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if BoylxMhGFuJvPAwXcQRnapEKOqfzLD==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:sys.exit()
  BoylxMhGFuJvPAwXcQRnapEKOqfzHd=[]
  BoylxMhGFuJvPAwXcQRnapEKOqfzHs=[]
  if(BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='wavve' or BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all')and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVE:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHC,BoylxMhGFuJvPAwXcQRnapEKOqfzHI=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_EexceptGroup_Wavve())
   if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzHI)!=0:
    BoylxMhGFuJvPAwXcQRnapEKOqfzHd.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzHC)
    BoylxMhGFuJvPAwXcQRnapEKOqfzHs.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzHI)
  if(BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='tving' or BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all')and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONTVING:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHC,BoylxMhGFuJvPAwXcQRnapEKOqfzHI=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_EpgInfo_Tving()
   if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzHI)!=0:
    BoylxMhGFuJvPAwXcQRnapEKOqfzHd.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzHC)
    BoylxMhGFuJvPAwXcQRnapEKOqfzHs.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzHI)
  if(BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='spotv' or BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all')and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSPOTV:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHC,BoylxMhGFuJvPAwXcQRnapEKOqfzHI=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_EpgInfo_Spotv(payyn=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSPOTVPAY)
   if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzHI)!=0:
    BoylxMhGFuJvPAwXcQRnapEKOqfzHd.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzHC)
    BoylxMhGFuJvPAwXcQRnapEKOqfzHs.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzHI)
  if(BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='seezn' or BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all')and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZN:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHC,BoylxMhGFuJvPAwXcQRnapEKOqfzHI=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_EpgInfo_Seezn(exceptGroup=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_EexceptGroup_Seezn())
   if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzHI)!=0:
    BoylxMhGFuJvPAwXcQRnapEKOqfzHd.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzHC)
    BoylxMhGFuJvPAwXcQRnapEKOqfzHs.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzHI)
  if(BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='samsung' or BoylxMhGFuJvPAwXcQRnapEKOqfzLU=='all')and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSAMSUNG:
   BoylxMhGFuJvPAwXcQRnapEKOqfzLC=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_BaseInfo_Samsungtv()
   BoylxMhGFuJvPAwXcQRnapEKOqfzHC,BoylxMhGFuJvPAwXcQRnapEKOqfzHI=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_EpgInfo_Samsungtv(BoylxMhGFuJvPAwXcQRnapEKOqfzLC,exceptGroup=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_EexceptGroup_Samsungtv())
   if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzHI)!=0:
    BoylxMhGFuJvPAwXcQRnapEKOqfzHd.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzHC)
    BoylxMhGFuJvPAwXcQRnapEKOqfzHs.extend(BoylxMhGFuJvPAwXcQRnapEKOqfzHI)
  if BoylxMhGFuJvPAwXcQRnapEKOqfzUs(BoylxMhGFuJvPAwXcQRnapEKOqfzHs)==0:
   if BoylxMhGFuJvPAwXcQRnapEKOqfzHk!='N':BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   BoylxMhGFuJvPAwXcQRnapEKOqfzLH=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_Epg_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUd)
   fp=BoylxMhGFuJvPAwXcQRnapEKOqfzUI(BoylxMhGFuJvPAwXcQRnapEKOqfzLH,'w',-1,'utf-8')
   BoylxMhGFuJvPAwXcQRnapEKOqfzHr='<?xml version="1.0" encoding="UTF-8"?>\n'
   BoylxMhGFuJvPAwXcQRnapEKOqfzHm='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   BoylxMhGFuJvPAwXcQRnapEKOqfzHY='<tv generator-info-name="boritv_epg">\n\n'
   BoylxMhGFuJvPAwXcQRnapEKOqfzHt='\n</tv>\n'
   fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHr)
   fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHm)
   fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHY)
   for BoylxMhGFuJvPAwXcQRnapEKOqfzHe in BoylxMhGFuJvPAwXcQRnapEKOqfzHd:
    BoylxMhGFuJvPAwXcQRnapEKOqfzHg='  <channel id="%s.%s">\n' %(BoylxMhGFuJvPAwXcQRnapEKOqfzHe.get('channelid'),BoylxMhGFuJvPAwXcQRnapEKOqfzHe.get('ott'))
    BoylxMhGFuJvPAwXcQRnapEKOqfzHN='    <display-name>%s</display-name>\n'%(BoylxMhGFuJvPAwXcQRnapEKOqfzHe.get('channelnm'))
    BoylxMhGFuJvPAwXcQRnapEKOqfzHb='    <icon src="%s" />\n' %(BoylxMhGFuJvPAwXcQRnapEKOqfzHe.get('channelimg'))
    BoylxMhGFuJvPAwXcQRnapEKOqfzHi='  </channel>\n\n'
    fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHg)
    fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHN)
    fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHb)
    fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHi)
   for BoylxMhGFuJvPAwXcQRnapEKOqfzHe in BoylxMhGFuJvPAwXcQRnapEKOqfzHs:
    BoylxMhGFuJvPAwXcQRnapEKOqfzHg='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(BoylxMhGFuJvPAwXcQRnapEKOqfzHe.get('startTime'),BoylxMhGFuJvPAwXcQRnapEKOqfzHe.get('endTime'),BoylxMhGFuJvPAwXcQRnapEKOqfzHe.get('channelid'),BoylxMhGFuJvPAwXcQRnapEKOqfzHe.get('ott'))
    BoylxMhGFuJvPAwXcQRnapEKOqfzHN='    <title lang="kr">%s</title>\n' %(BoylxMhGFuJvPAwXcQRnapEKOqfzHe.get('title'))
    BoylxMhGFuJvPAwXcQRnapEKOqfzHb='  </programme>\n\n'
    fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHg)
    fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHN)
    fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHb)
   fp.write(BoylxMhGFuJvPAwXcQRnapEKOqfzHt)
   fp.close()
  except:
   if BoylxMhGFuJvPAwXcQRnapEKOqfzHk!='N':BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti(__language__(30910).encode('utf8'))
   return
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.MakeEpg_SaveJson()
  BoylxMhGFuJvPAwXcQRnapEKOqfzLk=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_Epg_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUd)
  BoylxMhGFuJvPAwXcQRnapEKOqfzLd=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.make_Epg_Filename(tempyn=BoylxMhGFuJvPAwXcQRnapEKOqfzUW)
  if xbmcvfs.copy(BoylxMhGFuJvPAwXcQRnapEKOqfzLk,BoylxMhGFuJvPAwXcQRnapEKOqfzLd):
   if BoylxMhGFuJvPAwXcQRnapEKOqfzHk!='N':BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti((BoylxMhGFuJvPAwXcQRnapEKOqfzLj+' '+__language__(30912)).encode('utf8'))
  else:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_AUTORESTART:
    BoylxMhGFuJvPAwXcQRnapEKOqfzHV=xbmcaddon.Addon('pvr.iptvsimple')
    BoylxMhGFuJvPAwXcQRnapEKOqfzHV.setSetting('anything','anything')
  except:
   BoylxMhGFuJvPAwXcQRnapEKOqfzUk 
 def make_EexceptGroup_Wavve(BoylxMhGFuJvPAwXcQRnapEKOqfzDj):
  BoylxMhGFuJvPAwXcQRnapEKOqfzHS=[]
  if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVERADIO==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHS.append('라디오/음악')
  if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVEHOME==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHS.append('홈쇼핑')
  if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONRELIGION==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHS.append('종교')
  return BoylxMhGFuJvPAwXcQRnapEKOqfzHS
 def make_EexceptGroup_Seezn(BoylxMhGFuJvPAwXcQRnapEKOqfzDj):
  BoylxMhGFuJvPAwXcQRnapEKOqfzHS=[]
  if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZNRADIO==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHS.append('라디오/음악')
  if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZNHOME==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHS.append('홈쇼핑')
  if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZNPAY==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHS.append('won')
  return BoylxMhGFuJvPAwXcQRnapEKOqfzHS
 def make_EexceptGroup_Samsungtv(BoylxMhGFuJvPAwXcQRnapEKOqfzDj):
  BoylxMhGFuJvPAwXcQRnapEKOqfzHS=[]
  if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSAMSUNGHOME==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:
   BoylxMhGFuJvPAwXcQRnapEKOqfzHS.append('홈쇼핑')
  return BoylxMhGFuJvPAwXcQRnapEKOqfzHS
 def get_radio_list(BoylxMhGFuJvPAwXcQRnapEKOqfzDj):
  if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVERADIO==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:return[]
  BoylxMhGFuJvPAwXcQRnapEKOqfzUD=[{'broadcastid':'46584','genre':'10'}]
  return BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_ChannelList_WavveExcept(BoylxMhGFuJvPAwXcQRnapEKOqfzUD)
 def check_config(BoylxMhGFuJvPAwXcQRnapEKOqfzDj):
  BoylxMhGFuJvPAwXcQRnapEKOqfzUL=BoylxMhGFuJvPAwXcQRnapEKOqfzUd
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVE =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onWavve')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONTVING =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onTvng')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSPOTV =BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZN =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onSeezn')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSAMSUNG =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onSamsung')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVERADIO =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onWavveRadio')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVEHOME =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onWavveHome')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONRELIGION =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onWavveReligion')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSPOTVPAY =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onSpotvPay')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZNPAY =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onSeeznPay')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZNHOME =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onSeeznHome')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZNRADIO =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onSeeznRadio')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSAMSUNGHOME =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('onSamsungHome')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_DISPLAYNM =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('displayOTTnm')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_AUTORESTART =BoylxMhGFuJvPAwXcQRnapEKOqfzUd if __addon__.getSetting('autoRestart')=='true' else BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_CUSTOM_LIST =BoylxMhGFuJvPAwXcQRnapEKOqfzDj.customEpg_FileList()
  if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_FILE_PATH=='' or BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_FILE_NAME=='':BoylxMhGFuJvPAwXcQRnapEKOqfzUL=BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  if BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONWAVVE==BoylxMhGFuJvPAwXcQRnapEKOqfzUW and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONTVING==BoylxMhGFuJvPAwXcQRnapEKOqfzUW and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSEEZN==BoylxMhGFuJvPAwXcQRnapEKOqfzUW and BoylxMhGFuJvPAwXcQRnapEKOqfzDj.M3U_ONSAMSUNG==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:BoylxMhGFuJvPAwXcQRnapEKOqfzUL=BoylxMhGFuJvPAwXcQRnapEKOqfzUW
  if BoylxMhGFuJvPAwXcQRnapEKOqfzUL==BoylxMhGFuJvPAwXcQRnapEKOqfzUW:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDs=xbmcgui.Dialog()
   BoylxMhGFuJvPAwXcQRnapEKOqfzLD=BoylxMhGFuJvPAwXcQRnapEKOqfzDs.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if BoylxMhGFuJvPAwXcQRnapEKOqfzLD==BoylxMhGFuJvPAwXcQRnapEKOqfzUd:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(BoylxMhGFuJvPAwXcQRnapEKOqfzDj):
  BoylxMhGFuJvPAwXcQRnapEKOqfzUH={'date_makeepg':BoylxMhGFuJvPAwXcQRnapEKOqfzDj.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=BoylxMhGFuJvPAwXcQRnapEKOqfzUI(BoylxMhGFuJvPAwXcQRnapEKOqfzDU,'w',-1,'utf-8')
   json.dump(BoylxMhGFuJvPAwXcQRnapEKOqfzUH,fp)
   fp.close()
  except BoylxMhGFuJvPAwXcQRnapEKOqfzUr as exception:
   return
 def boritv_main(BoylxMhGFuJvPAwXcQRnapEKOqfzDj):
  BoylxMhGFuJvPAwXcQRnapEKOqfzUj=BoylxMhGFuJvPAwXcQRnapEKOqfzDj.main_params.get('mode',BoylxMhGFuJvPAwXcQRnapEKOqfzUk)
  BoylxMhGFuJvPAwXcQRnapEKOqfzDj.check_config()
  if BoylxMhGFuJvPAwXcQRnapEKOqfzUj is BoylxMhGFuJvPAwXcQRnapEKOqfzUk:
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.dp_Main_List()
  elif BoylxMhGFuJvPAwXcQRnapEKOqfzUj=='DEL_M3U':
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.dp_Delete_M3u(BoylxMhGFuJvPAwXcQRnapEKOqfzDj.main_params)
  elif BoylxMhGFuJvPAwXcQRnapEKOqfzUj=='ADD_M3U':
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.dp_MakeAdd_M3u(BoylxMhGFuJvPAwXcQRnapEKOqfzDj.main_params)
  elif BoylxMhGFuJvPAwXcQRnapEKOqfzUj=='ADD_EPG':
   BoylxMhGFuJvPAwXcQRnapEKOqfzDj.dp_Make_Epg(BoylxMhGFuJvPAwXcQRnapEKOqfzDj.main_params)
  else:
   BoylxMhGFuJvPAwXcQRnapEKOqfzUk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
