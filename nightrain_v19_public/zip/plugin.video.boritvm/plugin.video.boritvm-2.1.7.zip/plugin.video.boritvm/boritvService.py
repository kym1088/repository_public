__author__="NightRain"
import os
import sys
import xbmcaddon,xbmcvfs
import urllib
__cwd__=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
__lib__=os.path.join(__cwd__,'resources','lib')
sys.path.append(__lib__)
from boritvServiceRun import*
auQsIPrqoyciRwkzDmtKLXNjegpYMx=xbmc.Monitor()
auQsIPrqoyciRwkzDmtKLXNjegpYMb=OTPJGfQjyxiwbucRszdeDaKtolpUnY()
xbmc.sleep(auQsIPrqoyciRwkzDmtKLXNjegpYMb.START_INTERVAL)
while not auQsIPrqoyciRwkzDmtKLXNjegpYMx.abortRequested():
 if auQsIPrqoyciRwkzDmtKLXNjegpYMx.waitForAbort(auQsIPrqoyciRwkzDmtKLXNjegpYMb.INTERVAL):
  break
 auQsIPrqoyciRwkzDmtKLXNjegpYMb.service_run()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
