__author__="NightRain"
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTB=object
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr=False
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTm=None
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo=True
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTE=getattr
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTl=type
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTg=int
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTU=list
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF=len
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTO=str
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTd=open
SnIwYcKhqPjfGkbLpAiNxRWtQXaVTe=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
SnIwYcKhqPjfGkbLpAiNxRWtQXaVMy=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'     - M3U 추가 (SBS)','mode':'ADD_M3U','sType':'bc_sbs','sName':'SBS'},{'title':'     - M3U 추가 (사용자 m3u)','mode':'ADD_M3U','sType':'custom','sName':'사용자 m3u 파일'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
SnIwYcKhqPjfGkbLpAiNxRWtQXaVMT={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
SnIwYcKhqPjfGkbLpAiNxRWtQXaVMC=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class SnIwYcKhqPjfGkbLpAiNxRWtQXaVMH(SnIwYcKhqPjfGkbLpAiNxRWtQXaVTB):
 def __init__(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMD,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMv,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMB):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz._addon_url =SnIwYcKhqPjfGkbLpAiNxRWtQXaVMD
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz._addon_handle =SnIwYcKhqPjfGkbLpAiNxRWtQXaVMv
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.main_params =SnIwYcKhqPjfGkbLpAiNxRWtQXaVMB
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_FILE_PATH ='' 
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_FILE_NAME ='' 
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVE =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONTVING =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSPOTV =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSAMSUNG =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_BC_SBS =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVERADIO =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVEHOME =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONRELIGION =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSPOTVPAY =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSAMSUNGHOME=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_DISPLAYNM =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_AUTORESTART =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_CUSTOM_LIST =[]
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj =HRmQWBfOuKveDYXLNAbzcqldoPGjMw() 
 def addon_noti(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,sting):
  try:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMm=xbmcgui.Dialog()
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMm.notification(__addonname__,sting)
  except:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVTm
 def addon_log(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,string):
  try:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMo=string.encode('utf-8','ignore')
  except:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMo='addonException: addon_log'
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVME=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMo),level=SnIwYcKhqPjfGkbLpAiNxRWtQXaVME)
 def get_keyboard_input(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMU):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMl=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTm
  kb=xbmc.Keyboard()
  kb.setHeading(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMU)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMl=kb.getText()
  return SnIwYcKhqPjfGkbLpAiNxRWtQXaVMl
 def add_dir(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,label,sublabel='',img='',infoLabels=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTm,isFolder=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo,params='',isLink=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr,ContextMenu=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTm):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMg='%s?%s'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz._addon_url,urllib.parse.urlencode(params))
  if sublabel:SnIwYcKhqPjfGkbLpAiNxRWtQXaVMU='%s < %s >'%(label,sublabel)
  else: SnIwYcKhqPjfGkbLpAiNxRWtQXaVMU=label
  if not img:img='DefaultFolder.png'
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMF=xbmcgui.ListItem(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMU)
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMF.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.KodiVersion>=20:
   if infoLabels:SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.Set_InfoTag(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMF.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:SnIwYcKhqPjfGkbLpAiNxRWtQXaVMF.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMF.setProperty('IsPlayable','true')
  if ContextMenu:SnIwYcKhqPjfGkbLpAiNxRWtQXaVMF.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz._addon_handle,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMg,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMF,isFolder)
 def Set_InfoTag(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,video_InfoTag:xbmc.InfoTagVideo,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMs):
  for SnIwYcKhqPjfGkbLpAiNxRWtQXaVMO,value in SnIwYcKhqPjfGkbLpAiNxRWtQXaVMs.items():
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMT[SnIwYcKhqPjfGkbLpAiNxRWtQXaVMO]['type']=='string':
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVTE(video_InfoTag,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMT[SnIwYcKhqPjfGkbLpAiNxRWtQXaVMO]['func'])(value)
   elif SnIwYcKhqPjfGkbLpAiNxRWtQXaVMT[SnIwYcKhqPjfGkbLpAiNxRWtQXaVMO]['type']=='int':
    if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTl(value)==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTg:
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVMd=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTg(value)
    else:
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVMd=0
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVTE(video_InfoTag,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMT[SnIwYcKhqPjfGkbLpAiNxRWtQXaVMO]['func'])(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMd)
   elif SnIwYcKhqPjfGkbLpAiNxRWtQXaVMT[SnIwYcKhqPjfGkbLpAiNxRWtQXaVMO]['type']=='actor':
    if value!=[]:
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVTE(video_InfoTag,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMT[SnIwYcKhqPjfGkbLpAiNxRWtQXaVMO]['func'])([xbmc.Actor(name)for name in value])
   elif SnIwYcKhqPjfGkbLpAiNxRWtQXaVMT[SnIwYcKhqPjfGkbLpAiNxRWtQXaVMO]['type']=='list':
    if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTl(value)==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTU:
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVTE(video_InfoTag,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMT[SnIwYcKhqPjfGkbLpAiNxRWtQXaVMO]['func'])(value)
    else:
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVTE(video_InfoTag,SnIwYcKhqPjfGkbLpAiNxRWtQXaVMT[SnIwYcKhqPjfGkbLpAiNxRWtQXaVMO]['func'])([value])
 def make_M3u_Filename(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_FILE_PATH+SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_FILE_PATH+SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_FILE_NAME+'.xml'
 def dp_Main_List(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz):
  for SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe in SnIwYcKhqPjfGkbLpAiNxRWtQXaVMy:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMU=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('title')
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMu=''
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMJ={'mode':SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('mode'),'sType':SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('sType'),'sName':SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('sName')}
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMs={'title':SnIwYcKhqPjfGkbLpAiNxRWtQXaVMU,'plot':SnIwYcKhqPjfGkbLpAiNxRWtQXaVMU}
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('mode')=='XXX':
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVHM=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVHy =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo
   else:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVHM=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVHy =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHT=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('mode')=='ADD_M3U':
    if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('sType')=='wavve' and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVE ==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:SnIwYcKhqPjfGkbLpAiNxRWtQXaVHT=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
    if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('sType')=='tving' and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONTVING ==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:SnIwYcKhqPjfGkbLpAiNxRWtQXaVHT=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
    if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('sType')=='spotv' and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSPOTV ==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:SnIwYcKhqPjfGkbLpAiNxRWtQXaVHT=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
    if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('sType')=='bc_sbs' and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_BC_SBS ==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:SnIwYcKhqPjfGkbLpAiNxRWtQXaVHT=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
    if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('sType')=='samsung' and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSAMSUNG==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:SnIwYcKhqPjfGkbLpAiNxRWtQXaVHT=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
    if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('sType')=='custom' and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_CUSTOM_LIST==[]:SnIwYcKhqPjfGkbLpAiNxRWtQXaVHT=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVHT==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo:
    if 'icon' in SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe:SnIwYcKhqPjfGkbLpAiNxRWtQXaVMu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',SnIwYcKhqPjfGkbLpAiNxRWtQXaVMe.get('icon')) 
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.add_dir(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMU,sublabel='',img=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMu,infoLabels=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMs,isFolder=SnIwYcKhqPjfGkbLpAiNxRWtQXaVHM,params=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMJ,isLink=SnIwYcKhqPjfGkbLpAiNxRWtQXaVHy)
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMy)>0:xbmcplugin.endOfDirectory(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz._addon_handle,cacheToDisc=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo)
 def dp_Delete_M3u(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,args):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMm=xbmcgui.Dialog()
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHz=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMm.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVHz==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:sys.exit()
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_M3u_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr)
  if xbmcvfs.exists(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD):
   if xbmcvfs.delete(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD)==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti(__language__(30910).encode('utf-8'))
    return
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,args):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=args.get('sType')
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHB=args.get('sName')
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMm=xbmcgui.Dialog()
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHz=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMm.yesno((SnIwYcKhqPjfGkbLpAiNxRWtQXaVHB+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVHz==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:sys.exit()
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHr =[]
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHm =[]
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_M3u_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo)
  if os.path.isfile(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD):os.remove(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD)
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all':
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_M3u_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr)
   if xbmcvfs.exists(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD):
    if xbmcvfs.delete(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD)==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHo=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_M3u_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr)
   if xbmcvfs.exists(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHo):
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVHE=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_M3u_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo)
    xbmcvfs.copy(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHo,SnIwYcKhqPjfGkbLpAiNxRWtQXaVHE)
  if(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='wavve' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all')and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVE:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_ChannelList_Wavve(exceptGroup=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_EexceptGroup_Wavve())
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)!=0:SnIwYcKhqPjfGkbLpAiNxRWtQXaVHr.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_log('wavve cnt ----> '+SnIwYcKhqPjfGkbLpAiNxRWtQXaVTO(SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)))
  if(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='tving' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all')and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONTVING:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_ChannelList_Tving()
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)!=0:SnIwYcKhqPjfGkbLpAiNxRWtQXaVHr.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_log('tving cnt ----> '+SnIwYcKhqPjfGkbLpAiNxRWtQXaVTO(SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)))
  if(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='spotv' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all')and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSPOTV:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_ChannelList_Spotv(payyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSPOTVPAY)
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)!=0:SnIwYcKhqPjfGkbLpAiNxRWtQXaVHr.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_log('spotv cnt ----> '+SnIwYcKhqPjfGkbLpAiNxRWtQXaVTO(SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)))
  if(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='samsung' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all')and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSAMSUNG:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHg=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_BaseInfo_Samsungtv()
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_ChannelList_Samsungtv(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHg,exceptGroup=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_EexceptGroup_Samsungtv())
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)!=0:SnIwYcKhqPjfGkbLpAiNxRWtQXaVHr.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_log('samsungtv cnt ----> '+SnIwYcKhqPjfGkbLpAiNxRWtQXaVTO(SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)))
  if(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='bc_sbs' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all')and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_BC_SBS:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_ChannelList_BroadCast_SBS()
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)!=0:SnIwYcKhqPjfGkbLpAiNxRWtQXaVHr.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_log('bc_sbs cnt ----> '+SnIwYcKhqPjfGkbLpAiNxRWtQXaVTO(SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHl)))
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHr)==0 and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_CUSTOM_LIST==[]:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti(__language__(30909).encode('utf8'))
   return
  for SnIwYcKhqPjfGkbLpAiNxRWtQXaVHU in SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.INIT_GENRESORT:
   for SnIwYcKhqPjfGkbLpAiNxRWtQXaVHF in SnIwYcKhqPjfGkbLpAiNxRWtQXaVHr:
    if SnIwYcKhqPjfGkbLpAiNxRWtQXaVHF['genrenm']==SnIwYcKhqPjfGkbLpAiNxRWtQXaVHU:
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVHm.append(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHF)
  for SnIwYcKhqPjfGkbLpAiNxRWtQXaVHF in SnIwYcKhqPjfGkbLpAiNxRWtQXaVHr:
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVHF['genrenm']not in SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.INIT_GENRESORT:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVHm.append(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHF)
  try:
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHr)>0:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_M3u_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo)
    if os.path.isfile(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD):
     fp=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTd(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD,'a',-1,'utf-8')
    else:
     fp=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTd(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for SnIwYcKhqPjfGkbLpAiNxRWtQXaVHO in SnIwYcKhqPjfGkbLpAiNxRWtQXaVHm:
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVHd =SnIwYcKhqPjfGkbLpAiNxRWtQXaVHO['channelid']
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVHe =SnIwYcKhqPjfGkbLpAiNxRWtQXaVHO['channelnm']
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVHu=SnIwYcKhqPjfGkbLpAiNxRWtQXaVHO['channelimg']
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVHJ =SnIwYcKhqPjfGkbLpAiNxRWtQXaVHO['ott']
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVHs ='%s.%s'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHd,SnIwYcKhqPjfGkbLpAiNxRWtQXaVHJ)
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVyM=SnIwYcKhqPjfGkbLpAiNxRWtQXaVHO['genrenm']
     if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_DISPLAYNM:
      SnIwYcKhqPjfGkbLpAiNxRWtQXaVHe='%s (%s)'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHe,SnIwYcKhqPjfGkbLpAiNxRWtQXaVHJ)
     if SnIwYcKhqPjfGkbLpAiNxRWtQXaVyM=='라디오/음악':
      SnIwYcKhqPjfGkbLpAiNxRWtQXaVyH='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHs,SnIwYcKhqPjfGkbLpAiNxRWtQXaVHe,SnIwYcKhqPjfGkbLpAiNxRWtQXaVyM,SnIwYcKhqPjfGkbLpAiNxRWtQXaVHu,SnIwYcKhqPjfGkbLpAiNxRWtQXaVHe)
     else:
      SnIwYcKhqPjfGkbLpAiNxRWtQXaVyH='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHs,SnIwYcKhqPjfGkbLpAiNxRWtQXaVHe,SnIwYcKhqPjfGkbLpAiNxRWtQXaVyM,SnIwYcKhqPjfGkbLpAiNxRWtQXaVHu,SnIwYcKhqPjfGkbLpAiNxRWtQXaVHe)
     if SnIwYcKhqPjfGkbLpAiNxRWtQXaVHJ=='wavve':
      SnIwYcKhqPjfGkbLpAiNxRWtQXaVyT ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHd)
     elif SnIwYcKhqPjfGkbLpAiNxRWtQXaVHJ=='tving':
      SnIwYcKhqPjfGkbLpAiNxRWtQXaVyT ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHd)
     elif SnIwYcKhqPjfGkbLpAiNxRWtQXaVHJ=='spotv':
      SnIwYcKhqPjfGkbLpAiNxRWtQXaVyT ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHd)
     elif SnIwYcKhqPjfGkbLpAiNxRWtQXaVHJ=='samsung':
      SnIwYcKhqPjfGkbLpAiNxRWtQXaVyT ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHd)
     elif SnIwYcKhqPjfGkbLpAiNxRWtQXaVHJ=='bc_sbs':
      SnIwYcKhqPjfGkbLpAiNxRWtQXaVyT ='plugin://plugin.video.broadcastm/?mode=LIVE&company=sbs&channlCode=%s\n'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHd)
     fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyH)
     fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyT)
    fp.close()
  except:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti(__language__(30910).encode('utf8'))
   return
  try:
   if(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='custom' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all')and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_CUSTOM_LIST!=[]:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_M3u_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo)
    if os.path.isfile(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD):
     fp=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTd(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD,'a',-1,'utf-8')
    else:
     fp=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTd(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for SnIwYcKhqPjfGkbLpAiNxRWtQXaVyC in SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_CUSTOM_LIST:
     SnIwYcKhqPjfGkbLpAiNxRWtQXaVyz=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.customEpg_FileRead(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyC)
     for SnIwYcKhqPjfGkbLpAiNxRWtQXaVyD in SnIwYcKhqPjfGkbLpAiNxRWtQXaVyz:
      SnIwYcKhqPjfGkbLpAiNxRWtQXaVyD=SnIwYcKhqPjfGkbLpAiNxRWtQXaVyD.strip()
      if SnIwYcKhqPjfGkbLpAiNxRWtQXaVyD not in['','#EXTM3U']:
       fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyD+'\n')
   fp.close()
  except:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti(__language__(30910).encode('utf8'))
   return
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHo=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_M3u_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo)
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHE=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_M3u_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr)
  if xbmcvfs.copy(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHo,SnIwYcKhqPjfGkbLpAiNxRWtQXaVHE):
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti((SnIwYcKhqPjfGkbLpAiNxRWtQXaVHB+' '+__language__(30908)).encode('utf8'))
  else:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti(__language__(30910).encode('utf-8'))
 def customEpg_FileList(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVyv=[]
  if __addon__.getSetting('custom01on')=='true':SnIwYcKhqPjfGkbLpAiNxRWtQXaVyv.append(__addon__.getSetting('custom01nm'))
  if __addon__.getSetting('custom02on')=='true':SnIwYcKhqPjfGkbLpAiNxRWtQXaVyv.append(__addon__.getSetting('custom02nm'))
  if __addon__.getSetting('custom03on')=='true':SnIwYcKhqPjfGkbLpAiNxRWtQXaVyv.append(__addon__.getSetting('custom03nm'))
  if __addon__.getSetting('custom04on')=='true':SnIwYcKhqPjfGkbLpAiNxRWtQXaVyv.append(__addon__.getSetting('custom04nm'))
  if __addon__.getSetting('custom05on')=='true':SnIwYcKhqPjfGkbLpAiNxRWtQXaVyv.append(__addon__.getSetting('custom05nm'))
  return SnIwYcKhqPjfGkbLpAiNxRWtQXaVyv
 def customEpg_FileRead(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,source_filename):
  try:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVyB=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
   if os.path.isfile(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyB):os.remove(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyB)
   xbmcvfs.copy(source_filename,SnIwYcKhqPjfGkbLpAiNxRWtQXaVyB)
   fp=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTd(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyB,'r',-1,'utf-8')
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVyr=fp.readlines()
  except:
   return[]
  return SnIwYcKhqPjfGkbLpAiNxRWtQXaVyr
 def dp_Make_Epg(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz,args):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=args.get('sType')
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHB=args.get('sName')
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVym=args.get('sNoti')
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVym!='N':
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMm=xbmcgui.Dialog()
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHz=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMm.yesno((SnIwYcKhqPjfGkbLpAiNxRWtQXaVHB+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVHz==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:sys.exit()
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVyo=[]
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVyE=[]
  if(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='wavve' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all')and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVE:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVyl,SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_EexceptGroup_Wavve())
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg)!=0:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyo.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyl)
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyE.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg)
  if(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='tving' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all')and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONTVING:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVyl,SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_EpgInfo_Tving()
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg)!=0:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyo.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyl)
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyE.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg)
  if(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='spotv' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all')and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSPOTV:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVyl,SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_EpgInfo_Spotv(payyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSPOTVPAY)
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg)!=0:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyo.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyl)
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyE.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg)
  if(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='samsung' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all')and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSAMSUNG:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHg=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_BaseInfo_Samsungtv()
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVyl,SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_EpgInfo_Samsungtv(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHg,exceptGroup=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_EexceptGroup_Samsungtv())
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg)!=0:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyo.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyl)
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyE.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg)
  if(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='bc_sbs' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVHv=='all')and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_BC_SBS:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVyl,SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_EpgInfo_BroadCast_SBS()
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg)!=0:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyo.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyl)
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyE.extend(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyg)
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTF(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyE)==0:
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVym!='N':SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_Epg_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo)
   fp=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTd(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHD,'w',-1,'utf-8')
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVyU='<?xml version="1.0" encoding="UTF-8"?>\n'
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVyF='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVyO='<tv generator-info-name="boritv_epg">\n\n'
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVyd='\n</tv>\n'
   fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyU)
   fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyF)
   fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyO)
   for SnIwYcKhqPjfGkbLpAiNxRWtQXaVye in SnIwYcKhqPjfGkbLpAiNxRWtQXaVyo:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyu='  <channel id="%s.%s">\n' %(SnIwYcKhqPjfGkbLpAiNxRWtQXaVye.get('channelid'),SnIwYcKhqPjfGkbLpAiNxRWtQXaVye.get('ott'))
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyJ='    <display-name>%s</display-name>\n'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVye.get('channelnm'))
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVys='    <icon src="%s" />\n' %(SnIwYcKhqPjfGkbLpAiNxRWtQXaVye.get('channelimg'))
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVTM='  </channel>\n\n'
    fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyu)
    fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyJ)
    fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVys)
    fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVTM)
   for SnIwYcKhqPjfGkbLpAiNxRWtQXaVye in SnIwYcKhqPjfGkbLpAiNxRWtQXaVyE:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyu='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(SnIwYcKhqPjfGkbLpAiNxRWtQXaVye.get('startTime'),SnIwYcKhqPjfGkbLpAiNxRWtQXaVye.get('endTime'),SnIwYcKhqPjfGkbLpAiNxRWtQXaVye.get('channelid'),SnIwYcKhqPjfGkbLpAiNxRWtQXaVye.get('ott'))
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVyJ='    <title lang="kr">%s</title>\n' %(SnIwYcKhqPjfGkbLpAiNxRWtQXaVye.get('title'))
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVys='  </programme>\n\n'
    fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyu)
    fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyJ)
    fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVys)
   fp.write(SnIwYcKhqPjfGkbLpAiNxRWtQXaVyd)
   fp.close()
  except:
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVym!='N':SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti(__language__(30910).encode('utf8'))
   return
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.MakeEpg_SaveJson()
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHo=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_Epg_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo)
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVHE=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.make_Epg_Filename(tempyn=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr)
  if xbmcvfs.copy(SnIwYcKhqPjfGkbLpAiNxRWtQXaVHo,SnIwYcKhqPjfGkbLpAiNxRWtQXaVHE):
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVym!='N':SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti((SnIwYcKhqPjfGkbLpAiNxRWtQXaVHB+' '+__language__(30912)).encode('utf8'))
  else:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_AUTORESTART:
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVTH=xbmcaddon.Addon('pvr.iptvsimple')
    SnIwYcKhqPjfGkbLpAiNxRWtQXaVTH.setSetting('anything','anything')
  except:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVTm 
 def make_EexceptGroup_Wavve(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVTy=[]
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVERADIO==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVTy.append('라디오/음악')
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVEHOME==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVTy.append('홈쇼핑')
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONRELIGION==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVTy.append('종교')
  return SnIwYcKhqPjfGkbLpAiNxRWtQXaVTy
 def make_EexceptGroup_Samsungtv(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVTy=[]
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSAMSUNGHOME==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVTy.append('홈쇼핑')
  return SnIwYcKhqPjfGkbLpAiNxRWtQXaVTy
 def get_radio_list(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz):
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVERADIO==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:return[]
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVTC=[{'broadcastid':'46584','genre':'10'}]
  return SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_ChannelList_WavveExcept(SnIwYcKhqPjfGkbLpAiNxRWtQXaVTC)
 def check_config(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVTz=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVE =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo if __addon__.getSetting('onWavve')=='true' else SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONTVING =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo if __addon__.getSetting('onTvng')=='true' else SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSPOTV =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo if __addon__.getSetting('onSpotv')=='true' else SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_BC_SBS =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo if __addon__.getSetting('onBroadSBS')=='true' else SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSAMSUNG =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVERADIO =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo if __addon__.getSetting('onWavveRadio')=='true' else SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVEHOME =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo if __addon__.getSetting('onWavveHome')=='true' else SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONRELIGION =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo if __addon__.getSetting('onWavveReligion')=='true' else SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSPOTVPAY =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo if __addon__.getSetting('onSpotvPay')=='true' else SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSAMSUNGHOME =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_DISPLAYNM =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo if __addon__.getSetting('displayOTTnm')=='true' else SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_AUTORESTART =SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo if __addon__.getSetting('autoRestart')=='true' else SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_CUSTOM_LIST =SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.customEpg_FileList()
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_FILE_PATH=='' or SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_FILE_NAME=='':SnIwYcKhqPjfGkbLpAiNxRWtQXaVTz=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONWAVVE==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONTVING==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSPOTV==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_ONSAMSUNG==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr and SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.M3U_BC_SBS==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:SnIwYcKhqPjfGkbLpAiNxRWtQXaVTz=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTz==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTr:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMm=xbmcgui.Dialog()
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVHz=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMm.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if SnIwYcKhqPjfGkbLpAiNxRWtQXaVHz==SnIwYcKhqPjfGkbLpAiNxRWtQXaVTo:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVTD={'date_makeepg':SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTd(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMC,'w',-1,'utf-8')
   json.dump(SnIwYcKhqPjfGkbLpAiNxRWtQXaVTD,fp)
   fp.close()
  except SnIwYcKhqPjfGkbLpAiNxRWtQXaVTe as exception:
   return
 def boritv_main(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz):
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.BoritvObj.KodiVersion=SnIwYcKhqPjfGkbLpAiNxRWtQXaVTg(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVTv=SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.main_params.get('mode',SnIwYcKhqPjfGkbLpAiNxRWtQXaVTm)
  SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.check_config()
  if SnIwYcKhqPjfGkbLpAiNxRWtQXaVTv is SnIwYcKhqPjfGkbLpAiNxRWtQXaVTm:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.dp_Main_List()
  elif SnIwYcKhqPjfGkbLpAiNxRWtQXaVTv=='DEL_M3U':
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.dp_Delete_M3u(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.main_params)
  elif SnIwYcKhqPjfGkbLpAiNxRWtQXaVTv=='ADD_M3U':
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.dp_MakeAdd_M3u(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.main_params)
  elif SnIwYcKhqPjfGkbLpAiNxRWtQXaVTv=='ADD_EPG':
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.dp_Make_Epg(SnIwYcKhqPjfGkbLpAiNxRWtQXaVMz.main_params)
  else:
   SnIwYcKhqPjfGkbLpAiNxRWtQXaVTm
# Created by pyminifier (https://github.com/liftoff/pyminifier)
