__author__="NightRain"
HRmQWBfOuKveDYXLNAbzcqldoPGjnS=False
HRmQWBfOuKveDYXLNAbzcqldoPGjnU=object
HRmQWBfOuKveDYXLNAbzcqldoPGjnF=open
HRmQWBfOuKveDYXLNAbzcqldoPGjnp=True
HRmQWBfOuKveDYXLNAbzcqldoPGjnh=None
HRmQWBfOuKveDYXLNAbzcqldoPGjnC=Exception
HRmQWBfOuKveDYXLNAbzcqldoPGjng=print
HRmQWBfOuKveDYXLNAbzcqldoPGjnk=range
HRmQWBfOuKveDYXLNAbzcqldoPGjnE=len
HRmQWBfOuKveDYXLNAbzcqldoPGjnr=str
HRmQWBfOuKveDYXLNAbzcqldoPGjnx=int
HRmQWBfOuKveDYXLNAbzcqldoPGjny=dict
HRmQWBfOuKveDYXLNAbzcqldoPGjnJ=set
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
import httpx
from channelgenre import*
HRmQWBfOuKveDYXLNAbzcqldoPGjMV=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
HRmQWBfOuKveDYXLNAbzcqldoPGjMs=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':HRmQWBfOuKveDYXLNAbzcqldoPGjnS,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':HRmQWBfOuKveDYXLNAbzcqldoPGjnS,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':HRmQWBfOuKveDYXLNAbzcqldoPGjnS,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':HRmQWBfOuKveDYXLNAbzcqldoPGjnS,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':HRmQWBfOuKveDYXLNAbzcqldoPGjnS,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':HRmQWBfOuKveDYXLNAbzcqldoPGjnS,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class HRmQWBfOuKveDYXLNAbzcqldoPGjMw(HRmQWBfOuKveDYXLNAbzcqldoPGjnU):
 def __init__(HRmQWBfOuKveDYXLNAbzcqldoPGjMn):
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_WAVVE ='https://apis.wavve.com'
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_TVING ='https://api.tving.com'
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_TVINGIMG ='https://image.tving.com'
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_SPOTV ='https://www.spotvnow.co.kr'
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.HTTPTAG ='https://'
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.LIMIT_WAVVE =500
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.LIMIT_TVING =60
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.LIMIT_TVINGEPG=20 
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.APPVERSION ='115.0.0.0' 
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.DEVICEMODEL ='Chrome' 
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.OSTYPE ='Windows' 
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.OSVERSION ='NT 10.0' 
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.DEFAULT_HEADER={'user-agent':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.USER_AGENT}
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.SLEEP_TIME =0.2
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.INIT_GENRESORT=MASTER_GENRE
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.INIT_CHANNEL =MASTER_CHANNEL
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.KodiVersion =20
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.BT_CONTEXTJSON_FILE1=''
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.BT_CONTEXTJSON_FILE2=''
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.BT_CONTEXTJSON_FILE3=''
  HRmQWBfOuKveDYXLNAbzcqldoPGjMn.BT_CONTEXTJSON_FILE4=''
 def JsonFile_Save(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,HRmQWBfOuKveDYXLNAbzcqldoPGjst,HRmQWBfOuKveDYXLNAbzcqldoPGjMU):
  if HRmQWBfOuKveDYXLNAbzcqldoPGjst=='':return HRmQWBfOuKveDYXLNAbzcqldoPGjnS
  try:
   fp=HRmQWBfOuKveDYXLNAbzcqldoPGjnF(HRmQWBfOuKveDYXLNAbzcqldoPGjst,'w',-1,'utf-8')
   json.dump(HRmQWBfOuKveDYXLNAbzcqldoPGjMU,fp,indent=4,ensure_ascii=HRmQWBfOuKveDYXLNAbzcqldoPGjnS)
   fp.close()
  except:
   return HRmQWBfOuKveDYXLNAbzcqldoPGjnS
  return HRmQWBfOuKveDYXLNAbzcqldoPGjnp
 def callRequestCookies(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,jobtype,HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,redirects=HRmQWBfOuKveDYXLNAbzcqldoPGjnS):
  HRmQWBfOuKveDYXLNAbzcqldoPGjMp=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.DEFAULT_HEADER
  if headers:HRmQWBfOuKveDYXLNAbzcqldoPGjMp.update(headers)
  if jobtype=='Get':
   HRmQWBfOuKveDYXLNAbzcqldoPGjMh=httpx.get(HRmQWBfOuKveDYXLNAbzcqldoPGjMr,params=params,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjMp,cookies=cookies,follow_redirects=redirects)
  else:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMh=httpx.post(HRmQWBfOuKveDYXLNAbzcqldoPGjMr,data=payload,params=params,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjMp,cookies=cookies,follow_redirects=redirects)
  return HRmQWBfOuKveDYXLNAbzcqldoPGjMh
 def Get_DefaultParams_Wavve(HRmQWBfOuKveDYXLNAbzcqldoPGjMn):
  HRmQWBfOuKveDYXLNAbzcqldoPGjMC={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return HRmQWBfOuKveDYXLNAbzcqldoPGjMC
 def Get_DefaultParams_Tving(HRmQWBfOuKveDYXLNAbzcqldoPGjMn):
  HRmQWBfOuKveDYXLNAbzcqldoPGjMC={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return HRmQWBfOuKveDYXLNAbzcqldoPGjMC
 def Get_Now_Datetime(HRmQWBfOuKveDYXLNAbzcqldoPGjMn):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,in_text):
  HRmQWBfOuKveDYXLNAbzcqldoPGjMk=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return HRmQWBfOuKveDYXLNAbzcqldoPGjMk
 def Get_ChannelList_BroadCast_SBS(HRmQWBfOuKveDYXLNAbzcqldoPGjMn):
  HRmQWBfOuKveDYXLNAbzcqldoPGjME =[]
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr='https://apis.sbs.co.kr/play-api/1.0/onair/channels'
   HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,redirects=HRmQWBfOuKveDYXLNAbzcqldoPGjnp)
   if HRmQWBfOuKveDYXLNAbzcqldoPGjMx.status_code!=200:return[]
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
   for HRmQWBfOuKveDYXLNAbzcqldoPGjMJ in HRmQWBfOuKveDYXLNAbzcqldoPGjMy.get('list'):
    if HRmQWBfOuKveDYXLNAbzcqldoPGjMJ['type']=='TV':
     if HRmQWBfOuKveDYXLNAbzcqldoPGjMJ.get('channelid')+'.bc_sbs' in HRmQWBfOuKveDYXLNAbzcqldoPGjMn.INIT_CHANNEL:
      HRmQWBfOuKveDYXLNAbzcqldoPGjMT=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.INIT_CHANNEL[HRmQWBfOuKveDYXLNAbzcqldoPGjMJ.get('channelid')+'.bc_sbs'].get('json_name')
     else:
      HRmQWBfOuKveDYXLNAbzcqldoPGjMT=''
     HRmQWBfOuKveDYXLNAbzcqldoPGjMI=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_getGenre(HRmQWBfOuKveDYXLNAbzcqldoPGjMJ.get('channelid'),'bc_sbs')
     HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjMJ.get('channelid'),'channelnm':HRmQWBfOuKveDYXLNAbzcqldoPGjMJ.get('channelname'),'channelimg':'https://static.cloud.sbs.co.kr/common/img/sbsplayBig_logo.png','ott':'bc_sbs','genrenm':HRmQWBfOuKveDYXLNAbzcqldoPGjMI,'json_name':HRmQWBfOuKveDYXLNAbzcqldoPGjMT,}
     HRmQWBfOuKveDYXLNAbzcqldoPGjME.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[]
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME
 def Get_EpgInfo_BroadCast_SBS(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,days=2):
  HRmQWBfOuKveDYXLNAbzcqldoPGjME=[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjMt =[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjwM=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_DateList(days=2,dateType='3')
  HRmQWBfOuKveDYXLNAbzcqldoPGjME =HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_ChannelList_BroadCast_SBS()
  try:
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwV in HRmQWBfOuKveDYXLNAbzcqldoPGjME:
    if HRmQWBfOuKveDYXLNAbzcqldoPGjwV['json_name']in[HRmQWBfOuKveDYXLNAbzcqldoPGjnh,'']:continue
    for HRmQWBfOuKveDYXLNAbzcqldoPGjws in HRmQWBfOuKveDYXLNAbzcqldoPGjwM:
     HRmQWBfOuKveDYXLNAbzcqldoPGjwn='{dt.year}/{dt.month}/{dt.day}'.format(dt=HRmQWBfOuKveDYXLNAbzcqldoPGjws)
     HRmQWBfOuKveDYXLNAbzcqldoPGjMr='https://static.cloud.sbs.co.kr/schedule/{}/{}.json'.format(HRmQWBfOuKveDYXLNAbzcqldoPGjwn,HRmQWBfOuKveDYXLNAbzcqldoPGjwV['json_name'])
     HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
     HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
     for HRmQWBfOuKveDYXLNAbzcqldoPGjwa in HRmQWBfOuKveDYXLNAbzcqldoPGjnk(HRmQWBfOuKveDYXLNAbzcqldoPGjnE(HRmQWBfOuKveDYXLNAbzcqldoPGjMy)):
      HRmQWBfOuKveDYXLNAbzcqldoPGjwS=HRmQWBfOuKveDYXLNAbzcqldoPGjws
      HRmQWBfOuKveDYXLNAbzcqldoPGjwU=HRmQWBfOuKveDYXLNAbzcqldoPGjws
      HRmQWBfOuKveDYXLNAbzcqldoPGjwF=HRmQWBfOuKveDYXLNAbzcqldoPGjMy[HRmQWBfOuKveDYXLNAbzcqldoPGjwa]['start_time'].split(':')
      HRmQWBfOuKveDYXLNAbzcqldoPGjwp=HRmQWBfOuKveDYXLNAbzcqldoPGjMy[HRmQWBfOuKveDYXLNAbzcqldoPGjwa]['end_time'].split(':')
      if HRmQWBfOuKveDYXLNAbzcqldoPGjnE(HRmQWBfOuKveDYXLNAbzcqldoPGjwp)!=['']:
       if HRmQWBfOuKveDYXLNAbzcqldoPGjwa+1<HRmQWBfOuKveDYXLNAbzcqldoPGjnE(HRmQWBfOuKveDYXLNAbzcqldoPGjMy):
        HRmQWBfOuKveDYXLNAbzcqldoPGjwp=HRmQWBfOuKveDYXLNAbzcqldoPGjMy[HRmQWBfOuKveDYXLNAbzcqldoPGjwa+1]['start_time'].split(':')
       else:
        HRmQWBfOuKveDYXLNAbzcqldoPGjwp=HRmQWBfOuKveDYXLNAbzcqldoPGjMy[HRmQWBfOuKveDYXLNAbzcqldoPGjwa]['start_time'].split(':')
        HRmQWBfOuKveDYXLNAbzcqldoPGjwp[0]=HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjnx(HRmQWBfOuKveDYXLNAbzcqldoPGjwp[0])+1).zfill(2)
      if HRmQWBfOuKveDYXLNAbzcqldoPGjnx(HRmQWBfOuKveDYXLNAbzcqldoPGjwF[0])>=24:
       HRmQWBfOuKveDYXLNAbzcqldoPGjwF[0]=HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjnx(HRmQWBfOuKveDYXLNAbzcqldoPGjwF[0])-24).zfill(2)
       HRmQWBfOuKveDYXLNAbzcqldoPGjwS =HRmQWBfOuKveDYXLNAbzcqldoPGjwS+datetime.timedelta(days=1)
      if HRmQWBfOuKveDYXLNAbzcqldoPGjnx(HRmQWBfOuKveDYXLNAbzcqldoPGjwp[0])>=24:
       HRmQWBfOuKveDYXLNAbzcqldoPGjwp[0]=HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjnx(HRmQWBfOuKveDYXLNAbzcqldoPGjwp[0])-24).zfill(2)
       HRmQWBfOuKveDYXLNAbzcqldoPGjwU =HRmQWBfOuKveDYXLNAbzcqldoPGjwU+datetime.timedelta(days=1)
      HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwV['channelid'],'title':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.xmlText(HRmQWBfOuKveDYXLNAbzcqldoPGjMy[HRmQWBfOuKveDYXLNAbzcqldoPGjwa]['title']),'startTime':'{}{}{}00'.format(HRmQWBfOuKveDYXLNAbzcqldoPGjwS.strftime('%Y%m%d'),HRmQWBfOuKveDYXLNAbzcqldoPGjwF[0],HRmQWBfOuKveDYXLNAbzcqldoPGjwF[1]),'endTime':'{}{}{}00'.format(HRmQWBfOuKveDYXLNAbzcqldoPGjwU.strftime('%Y%m%d'),HRmQWBfOuKveDYXLNAbzcqldoPGjwp[0],HRmQWBfOuKveDYXLNAbzcqldoPGjwp[1]),'ott':'bc_sbs',}
      HRmQWBfOuKveDYXLNAbzcqldoPGjMt.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
     time.sleep(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.SLEEP_TIME)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[],[]
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME,HRmQWBfOuKveDYXLNAbzcqldoPGjMt
 def Get_ChannelList_Wavve(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,exceptGroup=[]):
  HRmQWBfOuKveDYXLNAbzcqldoPGjME =[]
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_WAVVE+'/v2/live/channels'
   HRmQWBfOuKveDYXLNAbzcqldoPGjMC={'service':'wavve','uitype':'band_2_rank','uiparent':'GN55-LN99','uicode':'LN99','uirank':'3','limit':HRmQWBfOuKveDYXLNAbzcqldoPGjnr(200),'offset':'0','orderby':'viewtime','broadcastid':'LN99','isBand':'true','uitype':'LN58','client_version':'7.1.40'}
   HRmQWBfOuKveDYXLNAbzcqldoPGjMC.update(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_DefaultParams_Wavve())
   HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjMC,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
   if not('context_list' in HRmQWBfOuKveDYXLNAbzcqldoPGjMy['data']):return HRmQWBfOuKveDYXLNAbzcqldoPGjME
   HRmQWBfOuKveDYXLNAbzcqldoPGjwh=HRmQWBfOuKveDYXLNAbzcqldoPGjMy['data']['context_list']
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjwh:
    HRmQWBfOuKveDYXLNAbzcqldoPGjwg=HRmQWBfOuKveDYXLNAbzcqldoPGjwC['context_id']
    HRmQWBfOuKveDYXLNAbzcqldoPGjwk=HRmQWBfOuKveDYXLNAbzcqldoPGjwC['live']['name']
    HRmQWBfOuKveDYXLNAbzcqldoPGjwE=HRmQWBfOuKveDYXLNAbzcqldoPGjwC['live']['main_image']
    if HRmQWBfOuKveDYXLNAbzcqldoPGjwE and(not HRmQWBfOuKveDYXLNAbzcqldoPGjwE.startswith('http://'))and(not HRmQWBfOuKveDYXLNAbzcqldoPGjwE.startswith('https://')):
     HRmQWBfOuKveDYXLNAbzcqldoPGjwE=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.HTTPTAG+HRmQWBfOuKveDYXLNAbzcqldoPGjwE
    HRmQWBfOuKveDYXLNAbzcqldoPGjMI=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_getGenre(HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'wavve')
    HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'channelnm':HRmQWBfOuKveDYXLNAbzcqldoPGjwk,'channelimg':HRmQWBfOuKveDYXLNAbzcqldoPGjwE,'ott':'wavve','genrenm':HRmQWBfOuKveDYXLNAbzcqldoPGjMI}
    if HRmQWBfOuKveDYXLNAbzcqldoPGjMI not in exceptGroup:
     HRmQWBfOuKveDYXLNAbzcqldoPGjME.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[]
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME
 def Get_ChannelList_Wavve_250831(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,exceptGroup=[]):
  HRmQWBfOuKveDYXLNAbzcqldoPGjME =[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjwr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_ChannelImg_Wavve()
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_WAVVE+'/cf/live/recommend-channels'
   HRmQWBfOuKveDYXLNAbzcqldoPGjMC={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   HRmQWBfOuKveDYXLNAbzcqldoPGjMC.update(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_DefaultParams_Wavve())
   HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjMC,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
   if not('celllist' in HRmQWBfOuKveDYXLNAbzcqldoPGjMy['cell_toplist']):return HRmQWBfOuKveDYXLNAbzcqldoPGjME
   HRmQWBfOuKveDYXLNAbzcqldoPGjwh=HRmQWBfOuKveDYXLNAbzcqldoPGjMy['cell_toplist']['celllist']
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjwh:
    HRmQWBfOuKveDYXLNAbzcqldoPGjwg=HRmQWBfOuKveDYXLNAbzcqldoPGjwC['contentid']
    HRmQWBfOuKveDYXLNAbzcqldoPGjwk=HRmQWBfOuKveDYXLNAbzcqldoPGjwC['title_list'][0]['text']
    if HRmQWBfOuKveDYXLNAbzcqldoPGjwg in HRmQWBfOuKveDYXLNAbzcqldoPGjwr:
     HRmQWBfOuKveDYXLNAbzcqldoPGjwE=HRmQWBfOuKveDYXLNAbzcqldoPGjwr[HRmQWBfOuKveDYXLNAbzcqldoPGjwg]
     if not HRmQWBfOuKveDYXLNAbzcqldoPGjwE.startswith('http://')and not HRmQWBfOuKveDYXLNAbzcqldoPGjwE.startswith('https://'):
      HRmQWBfOuKveDYXLNAbzcqldoPGjwE=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.HTTPTAG+HRmQWBfOuKveDYXLNAbzcqldoPGjwr[HRmQWBfOuKveDYXLNAbzcqldoPGjwg]
    else:
     HRmQWBfOuKveDYXLNAbzcqldoPGjwE=''
    HRmQWBfOuKveDYXLNAbzcqldoPGjMI=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_getGenre(HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'wavve')
    HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'channelnm':HRmQWBfOuKveDYXLNAbzcqldoPGjwk,'channelimg':HRmQWBfOuKveDYXLNAbzcqldoPGjwE,'ott':'wavve','genrenm':HRmQWBfOuKveDYXLNAbzcqldoPGjMI}
    if HRmQWBfOuKveDYXLNAbzcqldoPGjMI not in exceptGroup:
     HRmQWBfOuKveDYXLNAbzcqldoPGjME.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[]
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME
 def Get_ChannelList_WavveExcept(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,exceptGroup=[]):
  HRmQWBfOuKveDYXLNAbzcqldoPGjME=[]
  if exceptGroup==[]:return[]
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_WAVVE+'/cf/live/recommend-channels'
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in exceptGroup:
    HRmQWBfOuKveDYXLNAbzcqldoPGjMC={'WeekDay':'all','adult':'n','broadcastid':HRmQWBfOuKveDYXLNAbzcqldoPGjwC['broadcastid'],'contenttype':'channel','genre':HRmQWBfOuKveDYXLNAbzcqldoPGjwC['genre'],'isrecommend':'y','limit':HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    HRmQWBfOuKveDYXLNAbzcqldoPGjMC.update(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_DefaultParams_Wavve())
    HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjMC,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
    HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
    if not('celllist' in HRmQWBfOuKveDYXLNAbzcqldoPGjMy['cell_toplist']):return HRmQWBfOuKveDYXLNAbzcqldoPGjME
    HRmQWBfOuKveDYXLNAbzcqldoPGjwh=HRmQWBfOuKveDYXLNAbzcqldoPGjMy['cell_toplist']['celllist']
    for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjwh:
     HRmQWBfOuKveDYXLNAbzcqldoPGjME.append(HRmQWBfOuKveDYXLNAbzcqldoPGjwC['contentid'])
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[]
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME
 def Get_ChannelImg_Wavve(HRmQWBfOuKveDYXLNAbzcqldoPGjMn):
  HRmQWBfOuKveDYXLNAbzcqldoPGjwx={}
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjwy=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_Now_Datetime()
   HRmQWBfOuKveDYXLNAbzcqldoPGjwJ =HRmQWBfOuKveDYXLNAbzcqldoPGjwy+datetime.timedelta(hours=3)
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_WAVVE+'/live/epgs'
   HRmQWBfOuKveDYXLNAbzcqldoPGjMC={'limit':HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':HRmQWBfOuKveDYXLNAbzcqldoPGjwy.strftime('%Y-%m-%d %H:00'),'enddatetime':HRmQWBfOuKveDYXLNAbzcqldoPGjwJ.strftime('%Y-%m-%d %H:00')}
   HRmQWBfOuKveDYXLNAbzcqldoPGjMC.update(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_DefaultParams_Wavve())
   HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjMC,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
   HRmQWBfOuKveDYXLNAbzcqldoPGjwh=HRmQWBfOuKveDYXLNAbzcqldoPGjMy['list']
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjwh:
    HRmQWBfOuKveDYXLNAbzcqldoPGjwx[HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channelid']]=HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channelimage']
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
  return HRmQWBfOuKveDYXLNAbzcqldoPGjwx
 def Get_ChanneGenrename_Wavve(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,HRmQWBfOuKveDYXLNAbzcqldoPGjwg):
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_WAVVE+'/live/channels/'+HRmQWBfOuKveDYXLNAbzcqldoPGjwg
   HRmQWBfOuKveDYXLNAbzcqldoPGjMC=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_DefaultParams_Wavve()
   HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjMC,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
   HRmQWBfOuKveDYXLNAbzcqldoPGjwT=HRmQWBfOuKveDYXLNAbzcqldoPGjMy['genretext']
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return ''
  return HRmQWBfOuKveDYXLNAbzcqldoPGjwT
 def Get_ChannelList_Spotv(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,payyn=HRmQWBfOuKveDYXLNAbzcqldoPGjnp):
  HRmQWBfOuKveDYXLNAbzcqldoPGjME=[]
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_SPOTV+'/api/v3/channel'
   HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjMy:
    HRmQWBfOuKveDYXLNAbzcqldoPGjwg=HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjwC['id'])
    HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'channelnm':HRmQWBfOuKveDYXLNAbzcqldoPGjwC['name'],'channelimg':HRmQWBfOuKveDYXLNAbzcqldoPGjwC['logo'],'ott':'spotv','genrenm':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_getGenre(HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'spotv'),'free':HRmQWBfOuKveDYXLNAbzcqldoPGjwC['free']}
    HRmQWBfOuKveDYXLNAbzcqldoPGjME.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[]
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME
 def Get_ChannelList_Tving(HRmQWBfOuKveDYXLNAbzcqldoPGjMn):
  HRmQWBfOuKveDYXLNAbzcqldoPGjME =[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjwI=[]
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_TVING+'/v2/media/lives'
   HRmQWBfOuKveDYXLNAbzcqldoPGjMC={'pageNo':'1','pageSize':HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   HRmQWBfOuKveDYXLNAbzcqldoPGjMC.update(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_DefaultParams_Tving())
   HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjMC,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
   if not('result' in HRmQWBfOuKveDYXLNAbzcqldoPGjMy['body']):return HRmQWBfOuKveDYXLNAbzcqldoPGjME
   HRmQWBfOuKveDYXLNAbzcqldoPGjwh=HRmQWBfOuKveDYXLNAbzcqldoPGjMy['body']['result']
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjwh:
    if HRmQWBfOuKveDYXLNAbzcqldoPGjwC['live_code']=='C44441':continue 
    HRmQWBfOuKveDYXLNAbzcqldoPGjwI.append(HRmQWBfOuKveDYXLNAbzcqldoPGjwC['live_code'])
   HRmQWBfOuKveDYXLNAbzcqldoPGjwr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_ChannelImg_Tving(HRmQWBfOuKveDYXLNAbzcqldoPGjwI)
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjwh:
    HRmQWBfOuKveDYXLNAbzcqldoPGjwg=HRmQWBfOuKveDYXLNAbzcqldoPGjwC['live_code']
    if HRmQWBfOuKveDYXLNAbzcqldoPGjwg=='C44441':continue 
    HRmQWBfOuKveDYXLNAbzcqldoPGjwk=HRmQWBfOuKveDYXLNAbzcqldoPGjwC['schedule']['channel']['name']['ko']
    if HRmQWBfOuKveDYXLNAbzcqldoPGjwg in HRmQWBfOuKveDYXLNAbzcqldoPGjwr:
     HRmQWBfOuKveDYXLNAbzcqldoPGjwE=HRmQWBfOuKveDYXLNAbzcqldoPGjwr[HRmQWBfOuKveDYXLNAbzcqldoPGjwg]
    else:
     HRmQWBfOuKveDYXLNAbzcqldoPGjwE=''
    HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'channelnm':HRmQWBfOuKveDYXLNAbzcqldoPGjwk,'channelimg':HRmQWBfOuKveDYXLNAbzcqldoPGjwE,'ott':'tving','genrenm':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_getGenre(HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'tving')}
    HRmQWBfOuKveDYXLNAbzcqldoPGjME.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[]
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME
 def Get_timestamp(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,timetype=1):
  ts=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,timetype):
  if timetype=='1':
   HRmQWBfOuKveDYXLNAbzcqldoPGjwi={'transactionId':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   HRmQWBfOuKveDYXLNAbzcqldoPGjwi={'timestamp':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_timestamp(timetype=1),'transactionId':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_timestamp(timetype=1)+'000000000000001',}
  return HRmQWBfOuKveDYXLNAbzcqldoPGjwi
 def make_EpgDatetime_Tving(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,days=2):
  HRmQWBfOuKveDYXLNAbzcqldoPGjwt=[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjVM=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_DateList(days=2,dateType='2')
  HRmQWBfOuKveDYXLNAbzcqldoPGjVw=HRmQWBfOuKveDYXLNAbzcqldoPGjnx(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjVM:
   for HRmQWBfOuKveDYXLNAbzcqldoPGjVs in HRmQWBfOuKveDYXLNAbzcqldoPGjnk(8):
    HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'ndate':HRmQWBfOuKveDYXLNAbzcqldoPGjwC,'starttm':HRmQWBfOuKveDYXLNAbzcqldoPGjMV[HRmQWBfOuKveDYXLNAbzcqldoPGjVs]['starttm'],'endtm':HRmQWBfOuKveDYXLNAbzcqldoPGjMV[HRmQWBfOuKveDYXLNAbzcqldoPGjVs]['endtm']}
    HRmQWBfOuKveDYXLNAbzcqldoPGjVn=HRmQWBfOuKveDYXLNAbzcqldoPGjnx(HRmQWBfOuKveDYXLNAbzcqldoPGjwC+HRmQWBfOuKveDYXLNAbzcqldoPGjMV[HRmQWBfOuKveDYXLNAbzcqldoPGjVs]['starttm'])
    HRmQWBfOuKveDYXLNAbzcqldoPGjVa=HRmQWBfOuKveDYXLNAbzcqldoPGjnx(HRmQWBfOuKveDYXLNAbzcqldoPGjwC+HRmQWBfOuKveDYXLNAbzcqldoPGjMV[HRmQWBfOuKveDYXLNAbzcqldoPGjVs]['endtm'])
    if HRmQWBfOuKveDYXLNAbzcqldoPGjVw<=HRmQWBfOuKveDYXLNAbzcqldoPGjVn or(HRmQWBfOuKveDYXLNAbzcqldoPGjVn<HRmQWBfOuKveDYXLNAbzcqldoPGjVw and HRmQWBfOuKveDYXLNAbzcqldoPGjVw<HRmQWBfOuKveDYXLNAbzcqldoPGjVa):
     HRmQWBfOuKveDYXLNAbzcqldoPGjwt.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  return HRmQWBfOuKveDYXLNAbzcqldoPGjwt
 def make_DateList(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,days=2,dateType='1'):
  HRmQWBfOuKveDYXLNAbzcqldoPGjVM=[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjVS =HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_Now_Datetime()
  for i in HRmQWBfOuKveDYXLNAbzcqldoPGjnk(days):
   HRmQWBfOuKveDYXLNAbzcqldoPGjVU=HRmQWBfOuKveDYXLNAbzcqldoPGjVS+datetime.timedelta(days=i)
   if dateType=='1':
    HRmQWBfOuKveDYXLNAbzcqldoPGjVM.append(HRmQWBfOuKveDYXLNAbzcqldoPGjVU.strftime('%Y-%m-%d'))
   elif dateType=='2':
    HRmQWBfOuKveDYXLNAbzcqldoPGjVM.append(HRmQWBfOuKveDYXLNAbzcqldoPGjVU.strftime('%Y%m%d'))
   else:
    HRmQWBfOuKveDYXLNAbzcqldoPGjVM.append(HRmQWBfOuKveDYXLNAbzcqldoPGjVU)
  return HRmQWBfOuKveDYXLNAbzcqldoPGjVM
 def make_Tving_ChannleGroup(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,HRmQWBfOuKveDYXLNAbzcqldoPGjwI):
  HRmQWBfOuKveDYXLNAbzcqldoPGjVF=[]
  i=0
  HRmQWBfOuKveDYXLNAbzcqldoPGjVp=''
  for HRmQWBfOuKveDYXLNAbzcqldoPGjVh in HRmQWBfOuKveDYXLNAbzcqldoPGjwI:
   if i==0:HRmQWBfOuKveDYXLNAbzcqldoPGjVp=HRmQWBfOuKveDYXLNAbzcqldoPGjVh
   else:HRmQWBfOuKveDYXLNAbzcqldoPGjVp+=',%s'%(HRmQWBfOuKveDYXLNAbzcqldoPGjVh)
   i+=1
   if i>=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.LIMIT_TVINGEPG:
    HRmQWBfOuKveDYXLNAbzcqldoPGjVF.append(HRmQWBfOuKveDYXLNAbzcqldoPGjVp)
    i=0
    HRmQWBfOuKveDYXLNAbzcqldoPGjVp=''
  if HRmQWBfOuKveDYXLNAbzcqldoPGjVp!='':
   HRmQWBfOuKveDYXLNAbzcqldoPGjVF.append(HRmQWBfOuKveDYXLNAbzcqldoPGjVp)
  return HRmQWBfOuKveDYXLNAbzcqldoPGjVF
 def Get_ChannelImg_Tving(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,chid_list):
  HRmQWBfOuKveDYXLNAbzcqldoPGjwx={}
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjVC=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_Now_Datetime().strftime('%Y%m%d')
   HRmQWBfOuKveDYXLNAbzcqldoPGjwy =HRmQWBfOuKveDYXLNAbzcqldoPGjMV[6]['starttm'] 
   HRmQWBfOuKveDYXLNAbzcqldoPGjwJ =HRmQWBfOuKveDYXLNAbzcqldoPGjMV[6]['endtm']
   HRmQWBfOuKveDYXLNAbzcqldoPGjVF=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_Tving_ChannleGroup(chid_list)
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjVF:
    HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_TVING+'/v2/media/schedules'
    HRmQWBfOuKveDYXLNAbzcqldoPGjMC={'pageNo':'1','pageSize':HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':HRmQWBfOuKveDYXLNAbzcqldoPGjVC,'broadcastDate':HRmQWBfOuKveDYXLNAbzcqldoPGjVC,'startBroadTime':HRmQWBfOuKveDYXLNAbzcqldoPGjwy,'endBroadTime':HRmQWBfOuKveDYXLNAbzcqldoPGjwJ,'channelCode':HRmQWBfOuKveDYXLNAbzcqldoPGjwC}
    HRmQWBfOuKveDYXLNAbzcqldoPGjMC.update(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_DefaultParams_Tving())
    HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjMC,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
    HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
    if not('result' in HRmQWBfOuKveDYXLNAbzcqldoPGjMy['body']):return{}
    HRmQWBfOuKveDYXLNAbzcqldoPGjwh=HRmQWBfOuKveDYXLNAbzcqldoPGjMy['body']['result']
    for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjwh:
     for HRmQWBfOuKveDYXLNAbzcqldoPGjVg in HRmQWBfOuKveDYXLNAbzcqldoPGjwC['image']:
      if HRmQWBfOuKveDYXLNAbzcqldoPGjVg['code']=='CAIC0400':HRmQWBfOuKveDYXLNAbzcqldoPGjwx[HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channel_code']]=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_TVINGIMG+HRmQWBfOuKveDYXLNAbzcqldoPGjVg['url']
      elif HRmQWBfOuKveDYXLNAbzcqldoPGjVg['code']=='CAIC1400':HRmQWBfOuKveDYXLNAbzcqldoPGjwx[HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channel_code']]=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_TVINGIMG+HRmQWBfOuKveDYXLNAbzcqldoPGjVg['url']
      elif HRmQWBfOuKveDYXLNAbzcqldoPGjVg['code']=='CAIC1900':HRmQWBfOuKveDYXLNAbzcqldoPGjwx[HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channel_code']]=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_TVINGIMG+HRmQWBfOuKveDYXLNAbzcqldoPGjVg['url']
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return{}
  return HRmQWBfOuKveDYXLNAbzcqldoPGjwx
 def Get_EpgInfo_Spotv(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,days=2,payyn=HRmQWBfOuKveDYXLNAbzcqldoPGjnp):
  HRmQWBfOuKveDYXLNAbzcqldoPGjME=[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjMt =[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjVM=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_DateList(days=days,dateType='1')
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_SPOTV+'/api/v3/channel'
   HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjMy:
    HRmQWBfOuKveDYXLNAbzcqldoPGjwg =HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjwC['id'])
    HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'channelnm':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.xmlText(HRmQWBfOuKveDYXLNAbzcqldoPGjwC['name']),'channelimg':HRmQWBfOuKveDYXLNAbzcqldoPGjwC['logo'],'ott':'spotv'}
    HRmQWBfOuKveDYXLNAbzcqldoPGjME.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[],[]
  try:
   for HRmQWBfOuKveDYXLNAbzcqldoPGjVk in HRmQWBfOuKveDYXLNAbzcqldoPGjVM:
    HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_SPOTV+'/api/v3/program/'+HRmQWBfOuKveDYXLNAbzcqldoPGjVk
    HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
    HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
    for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjMy:
     HRmQWBfOuKveDYXLNAbzcqldoPGjwg =HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channelId'])
     HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'title':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.xmlText(HRmQWBfOuKveDYXLNAbzcqldoPGjwC['title']),'startTime':HRmQWBfOuKveDYXLNAbzcqldoPGjwC['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':HRmQWBfOuKveDYXLNAbzcqldoPGjwC['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     HRmQWBfOuKveDYXLNAbzcqldoPGjMt.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
    time.sleep(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.SLEEP_TIME)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[],[]
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME,HRmQWBfOuKveDYXLNAbzcqldoPGjMt
 def Make_Wavve_TimeList(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,days=2):
  HRmQWBfOuKveDYXLNAbzcqldoPGjwt=[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjVE=[['00:00','03:00'],['03:00','06:00'],['06:00','09:00'],['09:00','12:00'],['12:00','15:00'],['15:00','18:00'],['18:00','21:00'],['21:00','24:00'],]
  HRmQWBfOuKveDYXLNAbzcqldoPGjVr =HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_Now_Datetime()
  for i in HRmQWBfOuKveDYXLNAbzcqldoPGjnk(days):
   HRmQWBfOuKveDYXLNAbzcqldoPGjVx =HRmQWBfOuKveDYXLNAbzcqldoPGjVr+datetime.timedelta(days=+i)
   HRmQWBfOuKveDYXLNAbzcqldoPGjwS =HRmQWBfOuKveDYXLNAbzcqldoPGjVx.strftime('%Y-%m-%d')
   for HRmQWBfOuKveDYXLNAbzcqldoPGjws in HRmQWBfOuKveDYXLNAbzcqldoPGjVE:
    HRmQWBfOuKveDYXLNAbzcqldoPGjVy=['{} {}'.format(HRmQWBfOuKveDYXLNAbzcqldoPGjwS,HRmQWBfOuKveDYXLNAbzcqldoPGjws[0]),'{} {}'.format(HRmQWBfOuKveDYXLNAbzcqldoPGjwS,HRmQWBfOuKveDYXLNAbzcqldoPGjws[1]),]
    HRmQWBfOuKveDYXLNAbzcqldoPGjwt.append(HRmQWBfOuKveDYXLNAbzcqldoPGjVy)
  return HRmQWBfOuKveDYXLNAbzcqldoPGjwt
 def Get_EpgInfo_Wavve(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,days=2,exceptGroup=[]):
  HRmQWBfOuKveDYXLNAbzcqldoPGjVJ =[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjME =[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjMt =[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjwt=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Make_Wavve_TimeList(days)
  try:
   for HRmQWBfOuKveDYXLNAbzcqldoPGjws in HRmQWBfOuKveDYXLNAbzcqldoPGjwt:
    HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_WAVVE+'/live/epgs'
    HRmQWBfOuKveDYXLNAbzcqldoPGjMC={'limit':HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':HRmQWBfOuKveDYXLNAbzcqldoPGjws[0],'enddatetime':HRmQWBfOuKveDYXLNAbzcqldoPGjws[1],}
    HRmQWBfOuKveDYXLNAbzcqldoPGjMC.update(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_DefaultParams_Wavve())
    HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjMC,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
    HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
    HRmQWBfOuKveDYXLNAbzcqldoPGjVT=HRmQWBfOuKveDYXLNAbzcqldoPGjMy['list']
    for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjVT:
     HRmQWBfOuKveDYXLNAbzcqldoPGjwg =HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channelid']
     HRmQWBfOuKveDYXLNAbzcqldoPGjMI=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_getGenre(HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'wavve')
     HRmQWBfOuKveDYXLNAbzcqldoPGjwE =HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channelimage']
     if not HRmQWBfOuKveDYXLNAbzcqldoPGjwE.startswith('http://')and not HRmQWBfOuKveDYXLNAbzcqldoPGjwE.startswith('https://'):
      HRmQWBfOuKveDYXLNAbzcqldoPGjwE=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.HTTPTAG+HRmQWBfOuKveDYXLNAbzcqldoPGjwE
     HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'channelnm':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.xmlText(HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channelname']),'channelimg':HRmQWBfOuKveDYXLNAbzcqldoPGjwE,'ott':'wavve'}
     if HRmQWBfOuKveDYXLNAbzcqldoPGjMI not in exceptGroup and HRmQWBfOuKveDYXLNAbzcqldoPGjwg not in HRmQWBfOuKveDYXLNAbzcqldoPGjVJ:
      HRmQWBfOuKveDYXLNAbzcqldoPGjME.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
      HRmQWBfOuKveDYXLNAbzcqldoPGjVJ.append(HRmQWBfOuKveDYXLNAbzcqldoPGjwg)
     for HRmQWBfOuKveDYXLNAbzcqldoPGjVI in HRmQWBfOuKveDYXLNAbzcqldoPGjwC['list']:
      HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channelid'],'title':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.xmlText(HRmQWBfOuKveDYXLNAbzcqldoPGjVI['title']),'startTime':HRmQWBfOuKveDYXLNAbzcqldoPGjVI['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':HRmQWBfOuKveDYXLNAbzcqldoPGjVI['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
      if HRmQWBfOuKveDYXLNAbzcqldoPGjMI not in exceptGroup and HRmQWBfOuKveDYXLNAbzcqldoPGjVI['starttime']!=HRmQWBfOuKveDYXLNAbzcqldoPGjVI['endtime']:
       HRmQWBfOuKveDYXLNAbzcqldoPGjMt.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[],[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjVi=HRmQWBfOuKveDYXLNAbzcqldoPGjnE(HRmQWBfOuKveDYXLNAbzcqldoPGjMt)
  for i in(HRmQWBfOuKveDYXLNAbzcqldoPGjnk(1,HRmQWBfOuKveDYXLNAbzcqldoPGjVi)):
   if HRmQWBfOuKveDYXLNAbzcqldoPGjnx(HRmQWBfOuKveDYXLNAbzcqldoPGjMt[i-1]['endTime'])+1==HRmQWBfOuKveDYXLNAbzcqldoPGjnx(HRmQWBfOuKveDYXLNAbzcqldoPGjMt[i]['startTime'])and HRmQWBfOuKveDYXLNAbzcqldoPGjMt[i-1]['channelid']==HRmQWBfOuKveDYXLNAbzcqldoPGjMt[i]['channelid']:
    HRmQWBfOuKveDYXLNAbzcqldoPGjMt[i-1]['endTime']=HRmQWBfOuKveDYXLNAbzcqldoPGjMt[i]['startTime']
  HRmQWBfOuKveDYXLNAbzcqldoPGjng(HRmQWBfOuKveDYXLNAbzcqldoPGjnE(HRmQWBfOuKveDYXLNAbzcqldoPGjME))
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME,HRmQWBfOuKveDYXLNAbzcqldoPGjMt
 def Get_EpgInfo_Tving(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,days=2):
  HRmQWBfOuKveDYXLNAbzcqldoPGjME=[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjMt =[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjVJ =[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjwM =HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_EpgDatetime_Tving(days=days)
  HRmQWBfOuKveDYXLNAbzcqldoPGjME =HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_ChannelList_Tving()
  HRmQWBfOuKveDYXLNAbzcqldoPGjVt=[]
  for i in HRmQWBfOuKveDYXLNAbzcqldoPGjnk(HRmQWBfOuKveDYXLNAbzcqldoPGjnE(HRmQWBfOuKveDYXLNAbzcqldoPGjME)):
   HRmQWBfOuKveDYXLNAbzcqldoPGjME[i]['channelnm']=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.xmlText(HRmQWBfOuKveDYXLNAbzcqldoPGjME[i]['channelnm'])
   HRmQWBfOuKveDYXLNAbzcqldoPGjVt.append(HRmQWBfOuKveDYXLNAbzcqldoPGjME[i]['channelid'])
  HRmQWBfOuKveDYXLNAbzcqldoPGjsM=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_Tving_ChannleGroup(HRmQWBfOuKveDYXLNAbzcqldoPGjVt)
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_TVING+'/v2/media/schedules'
   for HRmQWBfOuKveDYXLNAbzcqldoPGjws in HRmQWBfOuKveDYXLNAbzcqldoPGjwM:
    for HRmQWBfOuKveDYXLNAbzcqldoPGjwV in HRmQWBfOuKveDYXLNAbzcqldoPGjsM:
     HRmQWBfOuKveDYXLNAbzcqldoPGjMC={'pageNo':'1','pageSize':HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':HRmQWBfOuKveDYXLNAbzcqldoPGjws['ndate'],'broadcastDate':HRmQWBfOuKveDYXLNAbzcqldoPGjws['ndate'],'startBroadTime':HRmQWBfOuKveDYXLNAbzcqldoPGjws['starttm'],'endBroadTime':HRmQWBfOuKveDYXLNAbzcqldoPGjws['endtm'],'channelCode':HRmQWBfOuKveDYXLNAbzcqldoPGjwV}
     HRmQWBfOuKveDYXLNAbzcqldoPGjMC.update(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_DefaultParams_Tving())
     HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjMC,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
     HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
     HRmQWBfOuKveDYXLNAbzcqldoPGjwh=HRmQWBfOuKveDYXLNAbzcqldoPGjMy['body']['result']
     for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjwh:
      if 'schedules' not in HRmQWBfOuKveDYXLNAbzcqldoPGjwC:continue
      if HRmQWBfOuKveDYXLNAbzcqldoPGjwC['schedules']==HRmQWBfOuKveDYXLNAbzcqldoPGjnh:continue
      for HRmQWBfOuKveDYXLNAbzcqldoPGjsw in HRmQWBfOuKveDYXLNAbzcqldoPGjwC['schedules']:
       HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjsw['schedule_code'],'title':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.xmlText(HRmQWBfOuKveDYXLNAbzcqldoPGjsw['program']['name']['ko']),'startTime':HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjsw['broadcast_start_time']),'endTime':HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjsw['broadcast_end_time']),'ott':'tving'}
       HRmQWBfOuKveDYXLNAbzcqldoPGjsV=HRmQWBfOuKveDYXLNAbzcqldoPGjsw['schedule_code']+HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjsw['broadcast_start_time'])
       if HRmQWBfOuKveDYXLNAbzcqldoPGjsV in HRmQWBfOuKveDYXLNAbzcqldoPGjVJ:continue
       HRmQWBfOuKveDYXLNAbzcqldoPGjVJ.append(HRmQWBfOuKveDYXLNAbzcqldoPGjsV)
       HRmQWBfOuKveDYXLNAbzcqldoPGjMt.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
     time.sleep(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.SLEEP_TIME)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[],[]
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME,HRmQWBfOuKveDYXLNAbzcqldoPGjMt
 def Get_BaseInfo_Samsungtv(HRmQWBfOuKveDYXLNAbzcqldoPGjMn):
  HRmQWBfOuKveDYXLNAbzcqldoPGjsn={}
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_SAMSUNGTV
   HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjnh)
   for HRmQWBfOuKveDYXLNAbzcqldoPGjsa in HRmQWBfOuKveDYXLNAbzcqldoPGjMx.cookies:
    if HRmQWBfOuKveDYXLNAbzcqldoPGjsa.name=='session':
     HRmQWBfOuKveDYXLNAbzcqldoPGjsn['session']=HRmQWBfOuKveDYXLNAbzcqldoPGjsa.value
    elif HRmQWBfOuKveDYXLNAbzcqldoPGjsa.name=='session.sig':
     HRmQWBfOuKveDYXLNAbzcqldoPGjsn['session.sig']=HRmQWBfOuKveDYXLNAbzcqldoPGjsa.value
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return{}
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_SAMSUNGTV+'/user'
   HRmQWBfOuKveDYXLNAbzcqldoPGjsS={'session':HRmQWBfOuKveDYXLNAbzcqldoPGjsn['session'],'session.sig':HRmQWBfOuKveDYXLNAbzcqldoPGjsn['session.sig'],}
   HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjsS)
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
   HRmQWBfOuKveDYXLNAbzcqldoPGjsn['countryCode']=HRmQWBfOuKveDYXLNAbzcqldoPGjMy.get('countryCode')
   HRmQWBfOuKveDYXLNAbzcqldoPGjsn['uuid'] =HRmQWBfOuKveDYXLNAbzcqldoPGjMy.get('uuid')
   HRmQWBfOuKveDYXLNAbzcqldoPGjsn['ip'] =HRmQWBfOuKveDYXLNAbzcqldoPGjMy.get('ip')
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return{}
  return HRmQWBfOuKveDYXLNAbzcqldoPGjsn
 def t_Cache(HRmQWBfOuKveDYXLNAbzcqldoPGjMn):
  HRmQWBfOuKveDYXLNAbzcqldoPGjVw =HRmQWBfOuKveDYXLNAbzcqldoPGjnx(time.time())
  HRmQWBfOuKveDYXLNAbzcqldoPGjsU=HRmQWBfOuKveDYXLNAbzcqldoPGjnx(HRmQWBfOuKveDYXLNAbzcqldoPGjVw-HRmQWBfOuKveDYXLNAbzcqldoPGjVw%3600)
  return HRmQWBfOuKveDYXLNAbzcqldoPGjsU,HRmQWBfOuKveDYXLNAbzcqldoPGjVw
 def zlib_compress(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,plaintext):
  HRmQWBfOuKveDYXLNAbzcqldoPGjsF=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(HRmQWBfOuKveDYXLNAbzcqldoPGjsF).decode('utf-8')
 def Get_BaseRequest_Samsungtv(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,HRmQWBfOuKveDYXLNAbzcqldoPGjsn):
  HRmQWBfOuKveDYXLNAbzcqldoPGjMy={}
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMr=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.API_SAMSUNGTV+'/api/lives'
   HRmQWBfOuKveDYXLNAbzcqldoPGjsU,HRmQWBfOuKveDYXLNAbzcqldoPGjVw=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.t_Cache()
   HRmQWBfOuKveDYXLNAbzcqldoPGjsp=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.zlib_compress(HRmQWBfOuKveDYXLNAbzcqldoPGjsn['uuid']+':'+HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjVw))
   HRmQWBfOuKveDYXLNAbzcqldoPGjsS={'session':HRmQWBfOuKveDYXLNAbzcqldoPGjsn['session'],'session.sig':HRmQWBfOuKveDYXLNAbzcqldoPGjsn['session.sig'],}
   HRmQWBfOuKveDYXLNAbzcqldoPGjMC ={'t':HRmQWBfOuKveDYXLNAbzcqldoPGjnr(HRmQWBfOuKveDYXLNAbzcqldoPGjsU)}
   HRmQWBfOuKveDYXLNAbzcqldoPGjsh ={'x-cred-payload':HRmQWBfOuKveDYXLNAbzcqldoPGjsp}
   HRmQWBfOuKveDYXLNAbzcqldoPGjMx=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.callRequestCookies('Get',HRmQWBfOuKveDYXLNAbzcqldoPGjMr,payload=HRmQWBfOuKveDYXLNAbzcqldoPGjnh,params=HRmQWBfOuKveDYXLNAbzcqldoPGjMC,headers=HRmQWBfOuKveDYXLNAbzcqldoPGjsh,cookies=HRmQWBfOuKveDYXLNAbzcqldoPGjsS)
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy=json.loads(HRmQWBfOuKveDYXLNAbzcqldoPGjMx.text)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
  return HRmQWBfOuKveDYXLNAbzcqldoPGjMy
 def Make_Samsungtv_logoUrl(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,fullUrl):
  HRmQWBfOuKveDYXLNAbzcqldoPGjsC=urllib.parse.urlparse(fullUrl) 
  if HRmQWBfOuKveDYXLNAbzcqldoPGjsC.netloc=='us-image.samsungtvplus.com':
   HRmQWBfOuKveDYXLNAbzcqldoPGjsg=HRmQWBfOuKveDYXLNAbzcqldoPGjny(urllib.parse.parse_qsl(HRmQWBfOuKveDYXLNAbzcqldoPGjsC.query))
   if 'url' in HRmQWBfOuKveDYXLNAbzcqldoPGjsg:
    return HRmQWBfOuKveDYXLNAbzcqldoPGjsg.get('url')
  return fullUrl
 def Get_ChannelList_Samsungtv(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,HRmQWBfOuKveDYXLNAbzcqldoPGjsn,exceptGroup=[]):
  HRmQWBfOuKveDYXLNAbzcqldoPGjME =[]
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_BaseRequest_Samsungtv(HRmQWBfOuKveDYXLNAbzcqldoPGjsn)
   HRmQWBfOuKveDYXLNAbzcqldoPGjwh=HRmQWBfOuKveDYXLNAbzcqldoPGjMy['live']['channel']
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjwh:
    HRmQWBfOuKveDYXLNAbzcqldoPGjwg =HRmQWBfOuKveDYXLNAbzcqldoPGjwC.get('id')
    HRmQWBfOuKveDYXLNAbzcqldoPGjwk =HRmQWBfOuKveDYXLNAbzcqldoPGjwC.get('name')
    HRmQWBfOuKveDYXLNAbzcqldoPGjwE=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Make_Samsungtv_logoUrl(HRmQWBfOuKveDYXLNAbzcqldoPGjwC.get('logo'))
    HRmQWBfOuKveDYXLNAbzcqldoPGjMI=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_getGenre(HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'samsung')
    if HRmQWBfOuKveDYXLNAbzcqldoPGjMI in['-','']:HRmQWBfOuKveDYXLNAbzcqldoPGjMI='정주행 채널'
    HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'channelnm':HRmQWBfOuKveDYXLNAbzcqldoPGjwk,'channelimg':HRmQWBfOuKveDYXLNAbzcqldoPGjwE,'ott':'samsung','genrenm':HRmQWBfOuKveDYXLNAbzcqldoPGjMI}
    if HRmQWBfOuKveDYXLNAbzcqldoPGjMI not in exceptGroup:
     HRmQWBfOuKveDYXLNAbzcqldoPGjME.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[]
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME
 def Get_EpgInfo_Samsungtv(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,HRmQWBfOuKveDYXLNAbzcqldoPGjsn,exceptGroup=[]):
  HRmQWBfOuKveDYXLNAbzcqldoPGjME=[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjMt =[]
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjMy =HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_BaseRequest_Samsungtv(HRmQWBfOuKveDYXLNAbzcqldoPGjsn)
   HRmQWBfOuKveDYXLNAbzcqldoPGjwC=HRmQWBfOuKveDYXLNAbzcqldoPGjMy['live']['channel']
   for HRmQWBfOuKveDYXLNAbzcqldoPGjwV in HRmQWBfOuKveDYXLNAbzcqldoPGjwC:
    HRmQWBfOuKveDYXLNAbzcqldoPGjwg =HRmQWBfOuKveDYXLNAbzcqldoPGjwV.get('id')
    HRmQWBfOuKveDYXLNAbzcqldoPGjwk =HRmQWBfOuKveDYXLNAbzcqldoPGjwV.get('name')
    HRmQWBfOuKveDYXLNAbzcqldoPGjwE=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Make_Samsungtv_logoUrl(HRmQWBfOuKveDYXLNAbzcqldoPGjwV.get('logo'))
    HRmQWBfOuKveDYXLNAbzcqldoPGjVT =HRmQWBfOuKveDYXLNAbzcqldoPGjwV.get('program')
    HRmQWBfOuKveDYXLNAbzcqldoPGjMI=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.make_getGenre(HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'samsung')
    if HRmQWBfOuKveDYXLNAbzcqldoPGjMI in exceptGroup:
     continue
    HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'channelnm':HRmQWBfOuKveDYXLNAbzcqldoPGjwk,'channelimg':HRmQWBfOuKveDYXLNAbzcqldoPGjwE,'ott':'samsung','genrenm':HRmQWBfOuKveDYXLNAbzcqldoPGjMI}
    HRmQWBfOuKveDYXLNAbzcqldoPGjME.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
    for HRmQWBfOuKveDYXLNAbzcqldoPGjVI in HRmQWBfOuKveDYXLNAbzcqldoPGjVT:
     HRmQWBfOuKveDYXLNAbzcqldoPGjsk=HRmQWBfOuKveDYXLNAbzcqldoPGjVI.get('start_time')
     HRmQWBfOuKveDYXLNAbzcqldoPGjsE =HRmQWBfOuKveDYXLNAbzcqldoPGjVI.get('duration') 
     HRmQWBfOuKveDYXLNAbzcqldoPGjwy=datetime.datetime.strptime(HRmQWBfOuKveDYXLNAbzcqldoPGjsk,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     HRmQWBfOuKveDYXLNAbzcqldoPGjwJ =HRmQWBfOuKveDYXLNAbzcqldoPGjwy+datetime.timedelta(seconds=HRmQWBfOuKveDYXLNAbzcqldoPGjsE)
     HRmQWBfOuKveDYXLNAbzcqldoPGjMi={'channelid':HRmQWBfOuKveDYXLNAbzcqldoPGjwg,'title':HRmQWBfOuKveDYXLNAbzcqldoPGjMn.xmlText(urllib.parse.unquote_plus(HRmQWBfOuKveDYXLNAbzcqldoPGjVI.get('title'))),'startTime':HRmQWBfOuKveDYXLNAbzcqldoPGjwy.strftime('%Y%m%d%H%M00'),'endTime':HRmQWBfOuKveDYXLNAbzcqldoPGjwJ.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     HRmQWBfOuKveDYXLNAbzcqldoPGjMt.append(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  except HRmQWBfOuKveDYXLNAbzcqldoPGjnC as exception:
   HRmQWBfOuKveDYXLNAbzcqldoPGjng(exception)
   return[],[]
  return HRmQWBfOuKveDYXLNAbzcqldoPGjME,HRmQWBfOuKveDYXLNAbzcqldoPGjMt
 def make_getGenre(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,HRmQWBfOuKveDYXLNAbzcqldoPGjwg,HRmQWBfOuKveDYXLNAbzcqldoPGjnw):
  try:
   HRmQWBfOuKveDYXLNAbzcqldoPGjwT=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.INIT_CHANNEL.get(HRmQWBfOuKveDYXLNAbzcqldoPGjwg+'.'+HRmQWBfOuKveDYXLNAbzcqldoPGjnw).get('genre')
  except:
   HRmQWBfOuKveDYXLNAbzcqldoPGjwT=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.INIT_CHANNEL.get('-').get('genre')
  return HRmQWBfOuKveDYXLNAbzcqldoPGjwT
 def make_base_allchannel_py(HRmQWBfOuKveDYXLNAbzcqldoPGjMn,HRmQWBfOuKveDYXLNAbzcqldoPGjsn):
  HRmQWBfOuKveDYXLNAbzcqldoPGjsr =[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjsx=[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjsy=[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjsJ=[]
  HRmQWBfOuKveDYXLNAbzcqldoPGjsT=HRmQWBfOuKveDYXLNAbzcqldoPGjnJ()
  HRmQWBfOuKveDYXLNAbzcqldoPGjMi=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_ChannelList_Wavve()
  HRmQWBfOuKveDYXLNAbzcqldoPGjsr.extend(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  HRmQWBfOuKveDYXLNAbzcqldoPGjMi=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_ChannelList_Tving()
  HRmQWBfOuKveDYXLNAbzcqldoPGjsr.extend(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  HRmQWBfOuKveDYXLNAbzcqldoPGjMi=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_ChannelList_Spotv()
  HRmQWBfOuKveDYXLNAbzcqldoPGjsr.extend(HRmQWBfOuKveDYXLNAbzcqldoPGjMi)
  HRmQWBfOuKveDYXLNAbzcqldoPGjng('1')
  for i in HRmQWBfOuKveDYXLNAbzcqldoPGjnk(HRmQWBfOuKveDYXLNAbzcqldoPGjnE(HRmQWBfOuKveDYXLNAbzcqldoPGjsr)):
   if HRmQWBfOuKveDYXLNAbzcqldoPGjsr[i]['genrenm']=='-':
    if HRmQWBfOuKveDYXLNAbzcqldoPGjsr[i]['ott']=='wavve':
     HRmQWBfOuKveDYXLNAbzcqldoPGjwT=HRmQWBfOuKveDYXLNAbzcqldoPGjMn.Get_ChanneGenrename_Wavve(HRmQWBfOuKveDYXLNAbzcqldoPGjsr[i]['channelid'])
     if HRmQWBfOuKveDYXLNAbzcqldoPGjwT not in HRmQWBfOuKveDYXLNAbzcqldoPGjsT:HRmQWBfOuKveDYXLNAbzcqldoPGjsT.add(HRmQWBfOuKveDYXLNAbzcqldoPGjwT)
     time.sleep(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.SLEEP_TIME)
    elif HRmQWBfOuKveDYXLNAbzcqldoPGjsr[i]['ott']=='spotv':
     HRmQWBfOuKveDYXLNAbzcqldoPGjwT='스포츠'
    else:
     HRmQWBfOuKveDYXLNAbzcqldoPGjwT='-'
    HRmQWBfOuKveDYXLNAbzcqldoPGjsr[i]['genrenm']=HRmQWBfOuKveDYXLNAbzcqldoPGjwT
   else:
    if HRmQWBfOuKveDYXLNAbzcqldoPGjsr[i]['genrenm']not in HRmQWBfOuKveDYXLNAbzcqldoPGjsT:HRmQWBfOuKveDYXLNAbzcqldoPGjsT.add(HRmQWBfOuKveDYXLNAbzcqldoPGjsr[i]['genrenm'])
  HRmQWBfOuKveDYXLNAbzcqldoPGjsT.add(HRmQWBfOuKveDYXLNAbzcqldoPGjMn.INIT_CHANNEL.get('-').get('genre'))
  HRmQWBfOuKveDYXLNAbzcqldoPGjng('2')
  for HRmQWBfOuKveDYXLNAbzcqldoPGjsI in HRmQWBfOuKveDYXLNAbzcqldoPGjsT:
   for HRmQWBfOuKveDYXLNAbzcqldoPGjsi in HRmQWBfOuKveDYXLNAbzcqldoPGjsr:
    if HRmQWBfOuKveDYXLNAbzcqldoPGjsi['genrenm']==HRmQWBfOuKveDYXLNAbzcqldoPGjsI:
     HRmQWBfOuKveDYXLNAbzcqldoPGjsx.append(HRmQWBfOuKveDYXLNAbzcqldoPGjsi)
  for HRmQWBfOuKveDYXLNAbzcqldoPGjsi in HRmQWBfOuKveDYXLNAbzcqldoPGjsr:
   if HRmQWBfOuKveDYXLNAbzcqldoPGjsi['genrenm']not in HRmQWBfOuKveDYXLNAbzcqldoPGjsT:
    HRmQWBfOuKveDYXLNAbzcqldoPGjsx.append(HRmQWBfOuKveDYXLNAbzcqldoPGjsi)
  HRmQWBfOuKveDYXLNAbzcqldoPGjng('3')
  HRmQWBfOuKveDYXLNAbzcqldoPGjst='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(HRmQWBfOuKveDYXLNAbzcqldoPGjst):os.remove(HRmQWBfOuKveDYXLNAbzcqldoPGjst)
  fp=HRmQWBfOuKveDYXLNAbzcqldoPGjnF(HRmQWBfOuKveDYXLNAbzcqldoPGjst,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  HRmQWBfOuKveDYXLNAbzcqldoPGjnM=HRmQWBfOuKveDYXLNAbzcqldoPGjnE(HRmQWBfOuKveDYXLNAbzcqldoPGjsx)
  i=0
  for HRmQWBfOuKveDYXLNAbzcqldoPGjwC in HRmQWBfOuKveDYXLNAbzcqldoPGjsx:
   i+=1
   HRmQWBfOuKveDYXLNAbzcqldoPGjwg =HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channelid']
   HRmQWBfOuKveDYXLNAbzcqldoPGjwk =HRmQWBfOuKveDYXLNAbzcqldoPGjwC['channelnm']
   HRmQWBfOuKveDYXLNAbzcqldoPGjnw =HRmQWBfOuKveDYXLNAbzcqldoPGjwC['ott']
   HRmQWBfOuKveDYXLNAbzcqldoPGjnV ='%s.%s'%(HRmQWBfOuKveDYXLNAbzcqldoPGjwg,HRmQWBfOuKveDYXLNAbzcqldoPGjnw)
   HRmQWBfOuKveDYXLNAbzcqldoPGjwT =HRmQWBfOuKveDYXLNAbzcqldoPGjwC['genrenm']
   HRmQWBfOuKveDYXLNAbzcqldoPGjns='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(HRmQWBfOuKveDYXLNAbzcqldoPGjnV,HRmQWBfOuKveDYXLNAbzcqldoPGjwk,HRmQWBfOuKveDYXLNAbzcqldoPGjwT)
   if i<HRmQWBfOuKveDYXLNAbzcqldoPGjnM:
    fp.write(HRmQWBfOuKveDYXLNAbzcqldoPGjns+',\n')
   else:
    fp.write(HRmQWBfOuKveDYXLNAbzcqldoPGjns+'\n')
   HRmQWBfOuKveDYXLNAbzcqldoPGjsy.append(HRmQWBfOuKveDYXLNAbzcqldoPGjnV)
   HRmQWBfOuKveDYXLNAbzcqldoPGjsJ.append(HRmQWBfOuKveDYXLNAbzcqldoPGjnV+'.'+HRmQWBfOuKveDYXLNAbzcqldoPGjwk)
  fp.write('}\n')
  fp.close()
  for HRmQWBfOuKveDYXLNAbzcqldoPGjna,value in HRmQWBfOuKveDYXLNAbzcqldoPGjMn.INIT_CHANNEL.items():
   if HRmQWBfOuKveDYXLNAbzcqldoPGjna not in HRmQWBfOuKveDYXLNAbzcqldoPGjsy:
    HRmQWBfOuKveDYXLNAbzcqldoPGjnh
  for HRmQWBfOuKveDYXLNAbzcqldoPGjna,value in HRmQWBfOuKveDYXLNAbzcqldoPGjMn.INIT_CHANNEL.items():
   if HRmQWBfOuKveDYXLNAbzcqldoPGjna+'.'+value.get('channelnm')not in HRmQWBfOuKveDYXLNAbzcqldoPGjsJ:
    HRmQWBfOuKveDYXLNAbzcqldoPGjng(HRmQWBfOuKveDYXLNAbzcqldoPGjna+'.'+value.get('channelnm'))
    HRmQWBfOuKveDYXLNAbzcqldoPGjnh
  return HRmQWBfOuKveDYXLNAbzcqldoPGjsT
# Created by pyminifier (https://github.com/liftoff/pyminifier)
