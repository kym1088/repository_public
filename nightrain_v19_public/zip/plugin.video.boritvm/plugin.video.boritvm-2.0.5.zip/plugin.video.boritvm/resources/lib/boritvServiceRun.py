__author__="NightRain"
HEFhRkuQczGbtJIpvOgndKsfqMNmYW=str
HEFhRkuQczGbtJIpvOgndKsfqMNmYy=True
HEFhRkuQczGbtJIpvOgndKsfqMNmYT=False
HEFhRkuQczGbtJIpvOgndKsfqMNmYS=print
HEFhRkuQczGbtJIpvOgndKsfqMNmYr=open
HEFhRkuQczGbtJIpvOgndKsfqMNmYV=Exception
HEFhRkuQczGbtJIpvOgndKsfqMNmlY=int
import json
import time
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 HEFhRkuQczGbtJIpvOgndKsfqMNmYP='ADDON'
except:
 HEFhRkuQczGbtJIpvOgndKsfqMNmYP='SINGLE'
if HEFhRkuQczGbtJIpvOgndKsfqMNmYP=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  HEFhRkuQczGbtJIpvOgndKsfqMNmYC=HEFhRkuQczGbtJIpvOgndKsfqMNmYW(string).encode('utf-8','ignore')
  HEFhRkuQczGbtJIpvOgndKsfqMNmYi=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,HEFhRkuQczGbtJIpvOgndKsfqMNmYC),level=HEFhRkuQczGbtJIpvOgndKsfqMNmYi)
 def addon_getautoepg():
  return HEFhRkuQczGbtJIpvOgndKsfqMNmYy if __addon__.getSetting('autoEpg')=='true' else HEFhRkuQczGbtJIpvOgndKsfqMNmYT
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  HEFhRkuQczGbtJIpvOgndKsfqMNmYS(string)
 def addon_getautoepg():
  return HEFhRkuQczGbtJIpvOgndKsfqMNmYy
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class HEFhRkuQczGbtJIpvOgndKsfqMNmYl():
 def __init__(HEFhRkuQczGbtJIpvOgndKsfqMNmYo):
  HEFhRkuQczGbtJIpvOgndKsfqMNmYo.START_INTERVAL =10 
  HEFhRkuQczGbtJIpvOgndKsfqMNmYo.INTERVAL =10 
  HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_FILETAGNM ='date_makeepg'
  HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_MAKEDATE ='-' 
  HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_WILL_TM =-1 
 def Get_Now_Datetime(HEFhRkuQczGbtJIpvOgndKsfqMNmYo):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(HEFhRkuQczGbtJIpvOgndKsfqMNmYo):
  HEFhRkuQczGbtJIpvOgndKsfqMNmYe ='-'
  if HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_MAKEDATE=='-':
   try:
    fp=HEFhRkuQczGbtJIpvOgndKsfqMNmYr(addon_epgupdate_confignm(),'r',-1,'utf-8')
    HEFhRkuQczGbtJIpvOgndKsfqMNmYw= json.load(fp)
    fp.close()
    HEFhRkuQczGbtJIpvOgndKsfqMNmYe=HEFhRkuQczGbtJIpvOgndKsfqMNmYw[HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_FILETAGNM]
   except HEFhRkuQczGbtJIpvOgndKsfqMNmYV as exception:
    return 5 
  else:
   HEFhRkuQczGbtJIpvOgndKsfqMNmYe=HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_MAKEDATE
  HEFhRkuQczGbtJIpvOgndKsfqMNmYj =HEFhRkuQczGbtJIpvOgndKsfqMNmYo.Get_Now_Datetime()
  HEFhRkuQczGbtJIpvOgndKsfqMNmYL=(HEFhRkuQczGbtJIpvOgndKsfqMNmYj-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  HEFhRkuQczGbtJIpvOgndKsfqMNmYU =HEFhRkuQczGbtJIpvOgndKsfqMNmYj.strftime('%Y-%m-%d')
  HEFhRkuQczGbtJIpvOgndKsfqMNmYX =HEFhRkuQczGbtJIpvOgndKsfqMNmYj.strftime('%H')
  if HEFhRkuQczGbtJIpvOgndKsfqMNmYe==HEFhRkuQczGbtJIpvOgndKsfqMNmYU: return-1
  if HEFhRkuQczGbtJIpvOgndKsfqMNmYe==HEFhRkuQczGbtJIpvOgndKsfqMNmYL and HEFhRkuQczGbtJIpvOgndKsfqMNmYX=='00':return 30
  return 3
 def MakeEpg_RandomTm(HEFhRkuQczGbtJIpvOgndKsfqMNmYo,mintm):
  HEFhRkuQczGbtJIpvOgndKsfqMNmYB=(mintm*60)+random.randint(0,120)
  HEFhRkuQczGbtJIpvOgndKsfqMNmYj =HEFhRkuQczGbtJIpvOgndKsfqMNmYo.Get_Now_Datetime()
  HEFhRkuQczGbtJIpvOgndKsfqMNmYa =(HEFhRkuQczGbtJIpvOgndKsfqMNmYj+datetime.timedelta(seconds=HEFhRkuQczGbtJIpvOgndKsfqMNmYB)).strftime('%Y%m%d%H%M%S')
  return HEFhRkuQczGbtJIpvOgndKsfqMNmlY(HEFhRkuQczGbtJIpvOgndKsfqMNmYa)
 def MakeEpg_SaveJson(HEFhRkuQczGbtJIpvOgndKsfqMNmYo):
  HEFhRkuQczGbtJIpvOgndKsfqMNmYw={HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_FILETAGNM:HEFhRkuQczGbtJIpvOgndKsfqMNmYo.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=HEFhRkuQczGbtJIpvOgndKsfqMNmYr(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(HEFhRkuQczGbtJIpvOgndKsfqMNmYw,fp)
   fp.close()
  except HEFhRkuQczGbtJIpvOgndKsfqMNmYV as exception:
   return
 def service_run(HEFhRkuQczGbtJIpvOgndKsfqMNmYo):
  if addon_getautoepg()==HEFhRkuQczGbtJIpvOgndKsfqMNmYT:return
  HEFhRkuQczGbtJIpvOgndKsfqMNmYD=HEFhRkuQczGbtJIpvOgndKsfqMNmYo.MakeEpg_DateCheck()
  if HEFhRkuQczGbtJIpvOgndKsfqMNmYD<0:
   return
  if HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_WILL_TM<0:
   HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_WILL_TM=HEFhRkuQczGbtJIpvOgndKsfqMNmYo.MakeEpg_RandomTm(HEFhRkuQczGbtJIpvOgndKsfqMNmYD)
   addon_log('EPG_WILL_TM --> '+HEFhRkuQczGbtJIpvOgndKsfqMNmYW(HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_WILL_TM))
  else:
   HEFhRkuQczGbtJIpvOgndKsfqMNmYU=HEFhRkuQczGbtJIpvOgndKsfqMNmYo.Get_Now_Datetime()
   if HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_WILL_TM<HEFhRkuQczGbtJIpvOgndKsfqMNmlY(HEFhRkuQczGbtJIpvOgndKsfqMNmYU.strftime('%Y%m%d%H%M%S')):
    addon_log('make epg')
    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
    HEFhRkuQczGbtJIpvOgndKsfqMNmYo.MakeEpg_SaveJson()
    HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_MAKEDATE=HEFhRkuQczGbtJIpvOgndKsfqMNmYU.strftime('%Y-%m-%d')
    HEFhRkuQczGbtJIpvOgndKsfqMNmYo.EPG_WILL_TM =-1
   else:
    pass
  pass
if __name__=="__main__":
 addon_log('__main__')
 HEFhRkuQczGbtJIpvOgndKsfqMNmYx=HEFhRkuQczGbtJIpvOgndKsfqMNmYl()
 time.sleep(HEFhRkuQczGbtJIpvOgndKsfqMNmYx.START_INTERVAL)
 while HEFhRkuQczGbtJIpvOgndKsfqMNmYy:
  time.sleep(HEFhRkuQczGbtJIpvOgndKsfqMNmYx.INTERVAL)
  HEFhRkuQczGbtJIpvOgndKsfqMNmYx.service_run()
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
