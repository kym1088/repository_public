__author__="NightRain"
BIkQjeNATEagFrHSiOMftbxuyozqLp=object
BIkQjeNATEagFrHSiOMftbxuyozqLR=None
BIkQjeNATEagFrHSiOMftbxuyozqLm=False
BIkQjeNATEagFrHSiOMftbxuyozqLc=str
BIkQjeNATEagFrHSiOMftbxuyozqLd=Exception
BIkQjeNATEagFrHSiOMftbxuyozqLw=print
BIkQjeNATEagFrHSiOMftbxuyozqLU=True
BIkQjeNATEagFrHSiOMftbxuyozqLV=int
BIkQjeNATEagFrHSiOMftbxuyozqLs=range
BIkQjeNATEagFrHSiOMftbxuyozqLh=len
BIkQjeNATEagFrHSiOMftbxuyozqLn=set
BIkQjeNATEagFrHSiOMftbxuyozqLD=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
from channelgenre import*
BIkQjeNATEagFrHSiOMftbxuyozqCl='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
BIkQjeNATEagFrHSiOMftbxuyozqCL=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
class BIkQjeNATEagFrHSiOMftbxuyozqCJ(BIkQjeNATEagFrHSiOMftbxuyozqLp):
 def __init__(BIkQjeNATEagFrHSiOMftbxuyozqCp):
  BIkQjeNATEagFrHSiOMftbxuyozqCp.API_WAVVE ='https://apis.wavve.com'
  BIkQjeNATEagFrHSiOMftbxuyozqCp.API_TVING ='https://api.tving.com'
  BIkQjeNATEagFrHSiOMftbxuyozqCp.API_TVINGIMG ='https://image.tving.com'
  BIkQjeNATEagFrHSiOMftbxuyozqCp.API_SPOTV ='https://www.spotvnow.co.kr'
  BIkQjeNATEagFrHSiOMftbxuyozqCp.HTTPTAG ='https://'
  BIkQjeNATEagFrHSiOMftbxuyozqCp.LIMIT_WAVVE =200
  BIkQjeNATEagFrHSiOMftbxuyozqCp.LIMIT_TVING =60
  BIkQjeNATEagFrHSiOMftbxuyozqCp.LIMIT_TVINGEPG=20 
  BIkQjeNATEagFrHSiOMftbxuyozqCp.DEFAULT_HEADER={'user-agent':BIkQjeNATEagFrHSiOMftbxuyozqCl}
  BIkQjeNATEagFrHSiOMftbxuyozqCp.SLEEP_TIME =0.2
  BIkQjeNATEagFrHSiOMftbxuyozqCp.INIT_GENRESORT=MASTER_GENRE
  BIkQjeNATEagFrHSiOMftbxuyozqCp.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(BIkQjeNATEagFrHSiOMftbxuyozqCp,jobtype,BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqLR,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR,redirects=BIkQjeNATEagFrHSiOMftbxuyozqLm):
  BIkQjeNATEagFrHSiOMftbxuyozqCc=BIkQjeNATEagFrHSiOMftbxuyozqCp.DEFAULT_HEADER
  if headers:BIkQjeNATEagFrHSiOMftbxuyozqCc.update(headers)
  if jobtype=='Get':
   BIkQjeNATEagFrHSiOMftbxuyozqCd=requests.get(BIkQjeNATEagFrHSiOMftbxuyozqCD,params=params,headers=BIkQjeNATEagFrHSiOMftbxuyozqCc,cookies=cookies,allow_redirects=redirects)
  else:
   BIkQjeNATEagFrHSiOMftbxuyozqCd=requests.post(BIkQjeNATEagFrHSiOMftbxuyozqCD,data=payload,params=params,headers=BIkQjeNATEagFrHSiOMftbxuyozqCc,cookies=cookies,allow_redirects=redirects)
  return BIkQjeNATEagFrHSiOMftbxuyozqCd
 def Get_DefaultParams_Wavve(BIkQjeNATEagFrHSiOMftbxuyozqCp):
  BIkQjeNATEagFrHSiOMftbxuyozqCw={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return BIkQjeNATEagFrHSiOMftbxuyozqCw
 def Get_DefaultParams_Tving(BIkQjeNATEagFrHSiOMftbxuyozqCp):
  BIkQjeNATEagFrHSiOMftbxuyozqCw={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return BIkQjeNATEagFrHSiOMftbxuyozqCw
 def Get_Now_Datetime(BIkQjeNATEagFrHSiOMftbxuyozqCp):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(BIkQjeNATEagFrHSiOMftbxuyozqCp,in_text):
  BIkQjeNATEagFrHSiOMftbxuyozqCV=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return BIkQjeNATEagFrHSiOMftbxuyozqCV
 def Get_ChannelList_Wavve(BIkQjeNATEagFrHSiOMftbxuyozqCp,exceptGroup=[]):
  BIkQjeNATEagFrHSiOMftbxuyozqCs =[]
  BIkQjeNATEagFrHSiOMftbxuyozqCh=[]
  BIkQjeNATEagFrHSiOMftbxuyozqCn=BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_ChannelImg_Wavve()
  if exceptGroup!=[]:
   BIkQjeNATEagFrHSiOMftbxuyozqCh=BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_ChannelList_WavveExcept(exceptGroup)
  try:
   BIkQjeNATEagFrHSiOMftbxuyozqCD=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_WAVVE+'/cf/live/recommend-channels'
   BIkQjeNATEagFrHSiOMftbxuyozqCw={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':BIkQjeNATEagFrHSiOMftbxuyozqLc(BIkQjeNATEagFrHSiOMftbxuyozqCp.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   BIkQjeNATEagFrHSiOMftbxuyozqCw.update(BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_DefaultParams_Wavve())
   BIkQjeNATEagFrHSiOMftbxuyozqCG=BIkQjeNATEagFrHSiOMftbxuyozqCp.callRequestCookies('Get',BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqCw,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR)
   BIkQjeNATEagFrHSiOMftbxuyozqCP=json.loads(BIkQjeNATEagFrHSiOMftbxuyozqCG.text)
   if not('celllist' in BIkQjeNATEagFrHSiOMftbxuyozqCP['cell_toplist']):return BIkQjeNATEagFrHSiOMftbxuyozqCs
   BIkQjeNATEagFrHSiOMftbxuyozqCW=BIkQjeNATEagFrHSiOMftbxuyozqCP['cell_toplist']['celllist']
   for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqCW:
    BIkQjeNATEagFrHSiOMftbxuyozqCv=BIkQjeNATEagFrHSiOMftbxuyozqCK['contentid']
    BIkQjeNATEagFrHSiOMftbxuyozqCY=BIkQjeNATEagFrHSiOMftbxuyozqCK['title_list'][0]['text']
    if BIkQjeNATEagFrHSiOMftbxuyozqCv in BIkQjeNATEagFrHSiOMftbxuyozqCn:
     BIkQjeNATEagFrHSiOMftbxuyozqCX=BIkQjeNATEagFrHSiOMftbxuyozqCn[BIkQjeNATEagFrHSiOMftbxuyozqCv]
    else:
     BIkQjeNATEagFrHSiOMftbxuyozqCX=''
    BIkQjeNATEagFrHSiOMftbxuyozqJC={'channelid':BIkQjeNATEagFrHSiOMftbxuyozqCv,'channelnm':BIkQjeNATEagFrHSiOMftbxuyozqCY,'channelimg':BIkQjeNATEagFrHSiOMftbxuyozqCp.HTTPTAG+BIkQjeNATEagFrHSiOMftbxuyozqCX if BIkQjeNATEagFrHSiOMftbxuyozqCX!='' else '','ott':'wavve','genrenm':BIkQjeNATEagFrHSiOMftbxuyozqCp.make_getGenre(BIkQjeNATEagFrHSiOMftbxuyozqCv,'wavve')}
    if BIkQjeNATEagFrHSiOMftbxuyozqCv not in BIkQjeNATEagFrHSiOMftbxuyozqCh:
     BIkQjeNATEagFrHSiOMftbxuyozqCs.append(BIkQjeNATEagFrHSiOMftbxuyozqJC)
  except BIkQjeNATEagFrHSiOMftbxuyozqLd as exception:
   BIkQjeNATEagFrHSiOMftbxuyozqLw(exception)
   return[]
  return BIkQjeNATEagFrHSiOMftbxuyozqCs
 def Get_ChannelList_WavveExcept(BIkQjeNATEagFrHSiOMftbxuyozqCp,exceptGroup=[]):
  BIkQjeNATEagFrHSiOMftbxuyozqCs=[]
  if exceptGroup==[]:return[]
  try:
   BIkQjeNATEagFrHSiOMftbxuyozqCD=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_WAVVE+'/cf/live/recommend-channels'
   for BIkQjeNATEagFrHSiOMftbxuyozqCK in exceptGroup:
    BIkQjeNATEagFrHSiOMftbxuyozqCw={'WeekDay':'all','adult':'n','broadcastid':BIkQjeNATEagFrHSiOMftbxuyozqCK['broadcastid'],'contenttype':'channel','genre':BIkQjeNATEagFrHSiOMftbxuyozqCK['genre'],'isrecommend':'y','limit':BIkQjeNATEagFrHSiOMftbxuyozqLc(BIkQjeNATEagFrHSiOMftbxuyozqCp.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    BIkQjeNATEagFrHSiOMftbxuyozqCw.update(BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_DefaultParams_Wavve())
    BIkQjeNATEagFrHSiOMftbxuyozqCG=BIkQjeNATEagFrHSiOMftbxuyozqCp.callRequestCookies('Get',BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqCw,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR)
    BIkQjeNATEagFrHSiOMftbxuyozqCP=json.loads(BIkQjeNATEagFrHSiOMftbxuyozqCG.text)
    if not('celllist' in BIkQjeNATEagFrHSiOMftbxuyozqCP['cell_toplist']):return BIkQjeNATEagFrHSiOMftbxuyozqCs
    BIkQjeNATEagFrHSiOMftbxuyozqCW=BIkQjeNATEagFrHSiOMftbxuyozqCP['cell_toplist']['celllist']
    for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqCW:
     BIkQjeNATEagFrHSiOMftbxuyozqCs.append(BIkQjeNATEagFrHSiOMftbxuyozqCK['contentid'])
  except BIkQjeNATEagFrHSiOMftbxuyozqLd as exception:
   BIkQjeNATEagFrHSiOMftbxuyozqLw(exception)
   return[]
  return BIkQjeNATEagFrHSiOMftbxuyozqCs
 def Get_ChannelImg_Wavve(BIkQjeNATEagFrHSiOMftbxuyozqCp):
  BIkQjeNATEagFrHSiOMftbxuyozqJl={}
  try:
   BIkQjeNATEagFrHSiOMftbxuyozqJL=BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_Now_Datetime()
   BIkQjeNATEagFrHSiOMftbxuyozqJp =BIkQjeNATEagFrHSiOMftbxuyozqJL+datetime.timedelta(hours=3)
   BIkQjeNATEagFrHSiOMftbxuyozqCD=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_WAVVE+'/live/epgs'
   BIkQjeNATEagFrHSiOMftbxuyozqCw={'limit':BIkQjeNATEagFrHSiOMftbxuyozqLc(BIkQjeNATEagFrHSiOMftbxuyozqCp.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':BIkQjeNATEagFrHSiOMftbxuyozqJL.strftime('%Y-%m-%d %H:00'),'enddatetime':BIkQjeNATEagFrHSiOMftbxuyozqJp.strftime('%Y-%m-%d %H:00')}
   BIkQjeNATEagFrHSiOMftbxuyozqCw.update(BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_DefaultParams_Wavve())
   BIkQjeNATEagFrHSiOMftbxuyozqCG=BIkQjeNATEagFrHSiOMftbxuyozqCp.callRequestCookies('Get',BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqCw,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR)
   BIkQjeNATEagFrHSiOMftbxuyozqCP=json.loads(BIkQjeNATEagFrHSiOMftbxuyozqCG.text)
   BIkQjeNATEagFrHSiOMftbxuyozqCW=BIkQjeNATEagFrHSiOMftbxuyozqCP['list']
   for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqCW:
    BIkQjeNATEagFrHSiOMftbxuyozqJl[BIkQjeNATEagFrHSiOMftbxuyozqCK['channelid']]=BIkQjeNATEagFrHSiOMftbxuyozqCK['channelimage']
  except BIkQjeNATEagFrHSiOMftbxuyozqLd as exception:
   BIkQjeNATEagFrHSiOMftbxuyozqLw(exception)
  return BIkQjeNATEagFrHSiOMftbxuyozqJl
 def Get_ChanneGenrename_Wavve(BIkQjeNATEagFrHSiOMftbxuyozqCp,BIkQjeNATEagFrHSiOMftbxuyozqCv):
  try:
   BIkQjeNATEagFrHSiOMftbxuyozqCD=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_WAVVE+'/live/channels/'+BIkQjeNATEagFrHSiOMftbxuyozqCv
   BIkQjeNATEagFrHSiOMftbxuyozqCw=BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_DefaultParams_Wavve()
   BIkQjeNATEagFrHSiOMftbxuyozqCG=BIkQjeNATEagFrHSiOMftbxuyozqCp.callRequestCookies('Get',BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqCw,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR)
   BIkQjeNATEagFrHSiOMftbxuyozqCP=json.loads(BIkQjeNATEagFrHSiOMftbxuyozqCG.text)
   BIkQjeNATEagFrHSiOMftbxuyozqJR=BIkQjeNATEagFrHSiOMftbxuyozqCP['genretext']
  except BIkQjeNATEagFrHSiOMftbxuyozqLd as exception:
   BIkQjeNATEagFrHSiOMftbxuyozqLw(exception)
   return ''
  return BIkQjeNATEagFrHSiOMftbxuyozqJR
 def Get_ChannelList_Spotv(BIkQjeNATEagFrHSiOMftbxuyozqCp,payyn=BIkQjeNATEagFrHSiOMftbxuyozqLU):
  BIkQjeNATEagFrHSiOMftbxuyozqCs=[]
  try:
   BIkQjeNATEagFrHSiOMftbxuyozqCD=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_SPOTV+'/api/v2/channel'
   BIkQjeNATEagFrHSiOMftbxuyozqCG=BIkQjeNATEagFrHSiOMftbxuyozqCp.callRequestCookies('Get',BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqLR,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR)
   BIkQjeNATEagFrHSiOMftbxuyozqCP=json.loads(BIkQjeNATEagFrHSiOMftbxuyozqCG.text)
   for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqCP:
    BIkQjeNATEagFrHSiOMftbxuyozqCv=BIkQjeNATEagFrHSiOMftbxuyozqCK['videoId'].replace('ref:','')
    BIkQjeNATEagFrHSiOMftbxuyozqJC={'channelid':BIkQjeNATEagFrHSiOMftbxuyozqCv,'channelnm':BIkQjeNATEagFrHSiOMftbxuyozqCK['name'],'channelimg':BIkQjeNATEagFrHSiOMftbxuyozqCK['logo'],'ott':'spotv','genrenm':BIkQjeNATEagFrHSiOMftbxuyozqCp.make_getGenre(BIkQjeNATEagFrHSiOMftbxuyozqCv,'spotv')}
    if payyn==BIkQjeNATEagFrHSiOMftbxuyozqLU or BIkQjeNATEagFrHSiOMftbxuyozqCK['free']==BIkQjeNATEagFrHSiOMftbxuyozqLU:
     BIkQjeNATEagFrHSiOMftbxuyozqCs.append(BIkQjeNATEagFrHSiOMftbxuyozqJC)
  except BIkQjeNATEagFrHSiOMftbxuyozqLd as exception:
   BIkQjeNATEagFrHSiOMftbxuyozqLw(exception)
   return[]
  return BIkQjeNATEagFrHSiOMftbxuyozqCs
 def Get_ChannelList_Tving(BIkQjeNATEagFrHSiOMftbxuyozqCp):
  BIkQjeNATEagFrHSiOMftbxuyozqCs =[]
  BIkQjeNATEagFrHSiOMftbxuyozqJm=[]
  try:
   BIkQjeNATEagFrHSiOMftbxuyozqCD=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_TVING+'/v2/media/lives'
   BIkQjeNATEagFrHSiOMftbxuyozqCw={'pageNo':'1','pageSize':BIkQjeNATEagFrHSiOMftbxuyozqLc(BIkQjeNATEagFrHSiOMftbxuyozqCp.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   BIkQjeNATEagFrHSiOMftbxuyozqCw.update(BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_DefaultParams_Tving())
   BIkQjeNATEagFrHSiOMftbxuyozqCG=BIkQjeNATEagFrHSiOMftbxuyozqCp.callRequestCookies('Get',BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqCw,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR)
   BIkQjeNATEagFrHSiOMftbxuyozqCP=json.loads(BIkQjeNATEagFrHSiOMftbxuyozqCG.text)
   if not('result' in BIkQjeNATEagFrHSiOMftbxuyozqCP['body']):return BIkQjeNATEagFrHSiOMftbxuyozqCs
   BIkQjeNATEagFrHSiOMftbxuyozqCW=BIkQjeNATEagFrHSiOMftbxuyozqCP['body']['result']
   for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqCW:
    if BIkQjeNATEagFrHSiOMftbxuyozqCK['live_code']=='C44441':continue 
    BIkQjeNATEagFrHSiOMftbxuyozqJm.append(BIkQjeNATEagFrHSiOMftbxuyozqCK['live_code'])
   BIkQjeNATEagFrHSiOMftbxuyozqCn=BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_ChannelImg_Tving(BIkQjeNATEagFrHSiOMftbxuyozqJm)
   for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqCW:
    BIkQjeNATEagFrHSiOMftbxuyozqCv=BIkQjeNATEagFrHSiOMftbxuyozqCK['live_code']
    if BIkQjeNATEagFrHSiOMftbxuyozqCv=='C44441':continue 
    BIkQjeNATEagFrHSiOMftbxuyozqCY=BIkQjeNATEagFrHSiOMftbxuyozqCK['schedule']['channel']['name']['ko']
    if BIkQjeNATEagFrHSiOMftbxuyozqCv in BIkQjeNATEagFrHSiOMftbxuyozqCn:
     BIkQjeNATEagFrHSiOMftbxuyozqCX=BIkQjeNATEagFrHSiOMftbxuyozqCn[BIkQjeNATEagFrHSiOMftbxuyozqCv]
    else:
     BIkQjeNATEagFrHSiOMftbxuyozqCX=''
    BIkQjeNATEagFrHSiOMftbxuyozqJC={'channelid':BIkQjeNATEagFrHSiOMftbxuyozqCv,'channelnm':BIkQjeNATEagFrHSiOMftbxuyozqCY,'channelimg':BIkQjeNATEagFrHSiOMftbxuyozqCX,'ott':'tving','genrenm':BIkQjeNATEagFrHSiOMftbxuyozqCp.make_getGenre(BIkQjeNATEagFrHSiOMftbxuyozqCv,'tving')}
    BIkQjeNATEagFrHSiOMftbxuyozqCs.append(BIkQjeNATEagFrHSiOMftbxuyozqJC)
  except BIkQjeNATEagFrHSiOMftbxuyozqLd as exception:
   BIkQjeNATEagFrHSiOMftbxuyozqLw(exception)
   return[]
  return BIkQjeNATEagFrHSiOMftbxuyozqCs
 def make_EpgDatetime_Tving(BIkQjeNATEagFrHSiOMftbxuyozqCp,days=2):
  BIkQjeNATEagFrHSiOMftbxuyozqJc=[]
  BIkQjeNATEagFrHSiOMftbxuyozqJd=BIkQjeNATEagFrHSiOMftbxuyozqCp.make_DateList(days=2,dateType='2')
  BIkQjeNATEagFrHSiOMftbxuyozqJw=BIkQjeNATEagFrHSiOMftbxuyozqLV(BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqJd:
   for BIkQjeNATEagFrHSiOMftbxuyozqJU in BIkQjeNATEagFrHSiOMftbxuyozqLs(8):
    BIkQjeNATEagFrHSiOMftbxuyozqJC={'ndate':BIkQjeNATEagFrHSiOMftbxuyozqCK,'starttm':BIkQjeNATEagFrHSiOMftbxuyozqCL[BIkQjeNATEagFrHSiOMftbxuyozqJU]['starttm'],'endtm':BIkQjeNATEagFrHSiOMftbxuyozqCL[BIkQjeNATEagFrHSiOMftbxuyozqJU]['endtm']}
    BIkQjeNATEagFrHSiOMftbxuyozqJV=BIkQjeNATEagFrHSiOMftbxuyozqLV(BIkQjeNATEagFrHSiOMftbxuyozqCK+BIkQjeNATEagFrHSiOMftbxuyozqCL[BIkQjeNATEagFrHSiOMftbxuyozqJU]['starttm'])
    BIkQjeNATEagFrHSiOMftbxuyozqJs=BIkQjeNATEagFrHSiOMftbxuyozqLV(BIkQjeNATEagFrHSiOMftbxuyozqCK+BIkQjeNATEagFrHSiOMftbxuyozqCL[BIkQjeNATEagFrHSiOMftbxuyozqJU]['endtm'])
    if BIkQjeNATEagFrHSiOMftbxuyozqJw<=BIkQjeNATEagFrHSiOMftbxuyozqJV or(BIkQjeNATEagFrHSiOMftbxuyozqJV<BIkQjeNATEagFrHSiOMftbxuyozqJw and BIkQjeNATEagFrHSiOMftbxuyozqJw<BIkQjeNATEagFrHSiOMftbxuyozqJs):
     BIkQjeNATEagFrHSiOMftbxuyozqJc.append(BIkQjeNATEagFrHSiOMftbxuyozqJC)
  return BIkQjeNATEagFrHSiOMftbxuyozqJc
 def make_DateList(BIkQjeNATEagFrHSiOMftbxuyozqCp,days=2,dateType='1'):
  BIkQjeNATEagFrHSiOMftbxuyozqJd=[]
  BIkQjeNATEagFrHSiOMftbxuyozqJh =BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_Now_Datetime()
  if dateType=='1':
   BIkQjeNATEagFrHSiOMftbxuyozqJh=BIkQjeNATEagFrHSiOMftbxuyozqJh-datetime.timedelta(days=1)
  for i in BIkQjeNATEagFrHSiOMftbxuyozqLs(days):
   BIkQjeNATEagFrHSiOMftbxuyozqJn=BIkQjeNATEagFrHSiOMftbxuyozqJh+datetime.timedelta(days=i)
   if dateType=='1':
    BIkQjeNATEagFrHSiOMftbxuyozqJd.append(BIkQjeNATEagFrHSiOMftbxuyozqJn.strftime('%Y-%m-%d'))
   else:
    BIkQjeNATEagFrHSiOMftbxuyozqJd.append(BIkQjeNATEagFrHSiOMftbxuyozqJn.strftime('%Y%m%d'))
  return BIkQjeNATEagFrHSiOMftbxuyozqJd
 def make_Tving_ChannleGroup(BIkQjeNATEagFrHSiOMftbxuyozqCp,BIkQjeNATEagFrHSiOMftbxuyozqJm):
  BIkQjeNATEagFrHSiOMftbxuyozqJD=[]
  i=0
  BIkQjeNATEagFrHSiOMftbxuyozqJG=''
  for BIkQjeNATEagFrHSiOMftbxuyozqJP in BIkQjeNATEagFrHSiOMftbxuyozqJm:
   if i==0:BIkQjeNATEagFrHSiOMftbxuyozqJG=BIkQjeNATEagFrHSiOMftbxuyozqJP
   else:BIkQjeNATEagFrHSiOMftbxuyozqJG+=',%s'%(BIkQjeNATEagFrHSiOMftbxuyozqJP)
   i+=1
   if i>=BIkQjeNATEagFrHSiOMftbxuyozqCp.LIMIT_TVINGEPG:
    BIkQjeNATEagFrHSiOMftbxuyozqJD.append(BIkQjeNATEagFrHSiOMftbxuyozqJG)
    i=0
    BIkQjeNATEagFrHSiOMftbxuyozqJG=''
  if BIkQjeNATEagFrHSiOMftbxuyozqJG!='':
   BIkQjeNATEagFrHSiOMftbxuyozqJD.append(BIkQjeNATEagFrHSiOMftbxuyozqJG)
  return BIkQjeNATEagFrHSiOMftbxuyozqJD
 def Get_ChannelImg_Tving(BIkQjeNATEagFrHSiOMftbxuyozqCp,chid_list):
  BIkQjeNATEagFrHSiOMftbxuyozqJl={}
  try:
   BIkQjeNATEagFrHSiOMftbxuyozqJW=BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_Now_Datetime().strftime('%Y%m%d')
   BIkQjeNATEagFrHSiOMftbxuyozqJL =BIkQjeNATEagFrHSiOMftbxuyozqCL[6]['starttm'] 
   BIkQjeNATEagFrHSiOMftbxuyozqJp =BIkQjeNATEagFrHSiOMftbxuyozqCL[6]['endtm']
   BIkQjeNATEagFrHSiOMftbxuyozqJD=BIkQjeNATEagFrHSiOMftbxuyozqCp.make_Tving_ChannleGroup(chid_list)
   for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqJD:
    BIkQjeNATEagFrHSiOMftbxuyozqCD=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_TVING+'/v2/media/schedules'
    BIkQjeNATEagFrHSiOMftbxuyozqCw={'pageNo':'1','pageSize':BIkQjeNATEagFrHSiOMftbxuyozqLc(BIkQjeNATEagFrHSiOMftbxuyozqCp.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':BIkQjeNATEagFrHSiOMftbxuyozqJW,'broadcastDate':BIkQjeNATEagFrHSiOMftbxuyozqJW,'startBroadTime':BIkQjeNATEagFrHSiOMftbxuyozqJL,'endBroadTime':BIkQjeNATEagFrHSiOMftbxuyozqJp,'channelCode':BIkQjeNATEagFrHSiOMftbxuyozqCK}
    BIkQjeNATEagFrHSiOMftbxuyozqCw.update(BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_DefaultParams_Tving())
    BIkQjeNATEagFrHSiOMftbxuyozqCG=BIkQjeNATEagFrHSiOMftbxuyozqCp.callRequestCookies('Get',BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqCw,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR)
    BIkQjeNATEagFrHSiOMftbxuyozqCP=json.loads(BIkQjeNATEagFrHSiOMftbxuyozqCG.text)
    if not('result' in BIkQjeNATEagFrHSiOMftbxuyozqCP['body']):return{}
    BIkQjeNATEagFrHSiOMftbxuyozqCW=BIkQjeNATEagFrHSiOMftbxuyozqCP['body']['result']
    for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqCW:
     BIkQjeNATEagFrHSiOMftbxuyozqJl[BIkQjeNATEagFrHSiOMftbxuyozqCK['channel_code']]=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_TVINGIMG+BIkQjeNATEagFrHSiOMftbxuyozqCK['image'][2]['url']
  except BIkQjeNATEagFrHSiOMftbxuyozqLd as exception:
   BIkQjeNATEagFrHSiOMftbxuyozqLw(exception)
   return{}
  return BIkQjeNATEagFrHSiOMftbxuyozqJl
 def Get_EpgInfo_Spotv(BIkQjeNATEagFrHSiOMftbxuyozqCp,days=3,payyn=BIkQjeNATEagFrHSiOMftbxuyozqLU):
  BIkQjeNATEagFrHSiOMftbxuyozqJK ={}
  BIkQjeNATEagFrHSiOMftbxuyozqCs=[]
  BIkQjeNATEagFrHSiOMftbxuyozqJv =[]
  BIkQjeNATEagFrHSiOMftbxuyozqJd=BIkQjeNATEagFrHSiOMftbxuyozqCp.make_DateList(days=days,dateType='1')
  BIkQjeNATEagFrHSiOMftbxuyozqLw(BIkQjeNATEagFrHSiOMftbxuyozqJd)
  try:
   BIkQjeNATEagFrHSiOMftbxuyozqCD=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_SPOTV+'/api/v2/channel'
   BIkQjeNATEagFrHSiOMftbxuyozqCG=BIkQjeNATEagFrHSiOMftbxuyozqCp.callRequestCookies('Get',BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqLR,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR)
   BIkQjeNATEagFrHSiOMftbxuyozqCP=json.loads(BIkQjeNATEagFrHSiOMftbxuyozqCG.text)
   for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqCP:
    BIkQjeNATEagFrHSiOMftbxuyozqCv =BIkQjeNATEagFrHSiOMftbxuyozqCK['videoId'].replace('ref:','')
    BIkQjeNATEagFrHSiOMftbxuyozqJC={'channelid':BIkQjeNATEagFrHSiOMftbxuyozqCv,'channelnm':BIkQjeNATEagFrHSiOMftbxuyozqCp.xmlText(BIkQjeNATEagFrHSiOMftbxuyozqCK['name']),'channelimg':BIkQjeNATEagFrHSiOMftbxuyozqCK['logo'],'ott':'spotv'}
    if payyn==BIkQjeNATEagFrHSiOMftbxuyozqLU or BIkQjeNATEagFrHSiOMftbxuyozqCK['free']==BIkQjeNATEagFrHSiOMftbxuyozqLU:
     BIkQjeNATEagFrHSiOMftbxuyozqJK[BIkQjeNATEagFrHSiOMftbxuyozqCK['id']]=BIkQjeNATEagFrHSiOMftbxuyozqCv
     BIkQjeNATEagFrHSiOMftbxuyozqCs.append(BIkQjeNATEagFrHSiOMftbxuyozqJC)
  except BIkQjeNATEagFrHSiOMftbxuyozqLd as exception:
   BIkQjeNATEagFrHSiOMftbxuyozqLw(exception)
   return[],[]
  try:
   for BIkQjeNATEagFrHSiOMftbxuyozqJY in BIkQjeNATEagFrHSiOMftbxuyozqJd:
    BIkQjeNATEagFrHSiOMftbxuyozqCD=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_SPOTV+'/api/v2/program/'+BIkQjeNATEagFrHSiOMftbxuyozqJY
    BIkQjeNATEagFrHSiOMftbxuyozqCG=BIkQjeNATEagFrHSiOMftbxuyozqCp.callRequestCookies('Get',BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqLR,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR)
    BIkQjeNATEagFrHSiOMftbxuyozqCP=json.loads(BIkQjeNATEagFrHSiOMftbxuyozqCG.text)
    for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqCP:
     if BIkQjeNATEagFrHSiOMftbxuyozqJK.get(BIkQjeNATEagFrHSiOMftbxuyozqCK['channelId'])==BIkQjeNATEagFrHSiOMftbxuyozqLR:continue
     BIkQjeNATEagFrHSiOMftbxuyozqJC={'channelid':BIkQjeNATEagFrHSiOMftbxuyozqJK.get(BIkQjeNATEagFrHSiOMftbxuyozqCK['channelId']),'title':BIkQjeNATEagFrHSiOMftbxuyozqCp.xmlText(BIkQjeNATEagFrHSiOMftbxuyozqCK['title']),'startTime':BIkQjeNATEagFrHSiOMftbxuyozqCK['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':BIkQjeNATEagFrHSiOMftbxuyozqCK['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     BIkQjeNATEagFrHSiOMftbxuyozqJv.append(BIkQjeNATEagFrHSiOMftbxuyozqJC)
    time.sleep(BIkQjeNATEagFrHSiOMftbxuyozqCp.SLEEP_TIME)
  except BIkQjeNATEagFrHSiOMftbxuyozqLd as exception:
   BIkQjeNATEagFrHSiOMftbxuyozqLw(exception)
   return[],[]
  return BIkQjeNATEagFrHSiOMftbxuyozqCs,BIkQjeNATEagFrHSiOMftbxuyozqJv
 def Get_EpgInfo_Wavve(BIkQjeNATEagFrHSiOMftbxuyozqCp,days=2,exceptGroup=[]):
  BIkQjeNATEagFrHSiOMftbxuyozqCs =[]
  BIkQjeNATEagFrHSiOMftbxuyozqJv =[]
  BIkQjeNATEagFrHSiOMftbxuyozqCh=[]
  BIkQjeNATEagFrHSiOMftbxuyozqJh =BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_Now_Datetime()
  BIkQjeNATEagFrHSiOMftbxuyozqJX =BIkQjeNATEagFrHSiOMftbxuyozqJh+datetime.timedelta(hours=-2)
  BIkQjeNATEagFrHSiOMftbxuyozqlC =BIkQjeNATEagFrHSiOMftbxuyozqJh+datetime.timedelta(days=(days-1))
  if BIkQjeNATEagFrHSiOMftbxuyozqLV(BIkQjeNATEagFrHSiOMftbxuyozqJX.strftime('%H'))<=3:
   BIkQjeNATEagFrHSiOMftbxuyozqlJ=BIkQjeNATEagFrHSiOMftbxuyozqJX.strftime('%Y-%m-%d 00:00')
  else:
   BIkQjeNATEagFrHSiOMftbxuyozqlJ=BIkQjeNATEagFrHSiOMftbxuyozqJX.strftime('%Y-%m-%d %H:00')
  BIkQjeNATEagFrHSiOMftbxuyozqlL =BIkQjeNATEagFrHSiOMftbxuyozqlC.strftime('%Y-%m-%d 24:00')
  if exceptGroup!=[]:
   BIkQjeNATEagFrHSiOMftbxuyozqCh=BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_ChannelList_WavveExcept(exceptGroup)
  try:
   BIkQjeNATEagFrHSiOMftbxuyozqCD=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_WAVVE+'/live/epgs'
   BIkQjeNATEagFrHSiOMftbxuyozqCw={'limit':BIkQjeNATEagFrHSiOMftbxuyozqLc(BIkQjeNATEagFrHSiOMftbxuyozqCp.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':BIkQjeNATEagFrHSiOMftbxuyozqlJ,'enddatetime':BIkQjeNATEagFrHSiOMftbxuyozqlL}
   BIkQjeNATEagFrHSiOMftbxuyozqCw.update(BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_DefaultParams_Wavve())
   BIkQjeNATEagFrHSiOMftbxuyozqCG=BIkQjeNATEagFrHSiOMftbxuyozqCp.callRequestCookies('Get',BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqCw,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR)
   BIkQjeNATEagFrHSiOMftbxuyozqCP=json.loads(BIkQjeNATEagFrHSiOMftbxuyozqCG.text)
   BIkQjeNATEagFrHSiOMftbxuyozqlp=BIkQjeNATEagFrHSiOMftbxuyozqCP['list']
   for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqlp:
    BIkQjeNATEagFrHSiOMftbxuyozqJC={'channelid':BIkQjeNATEagFrHSiOMftbxuyozqCK['channelid'],'channelnm':BIkQjeNATEagFrHSiOMftbxuyozqCp.xmlText(BIkQjeNATEagFrHSiOMftbxuyozqCK['channelname']),'channelimg':BIkQjeNATEagFrHSiOMftbxuyozqCp.HTTPTAG+BIkQjeNATEagFrHSiOMftbxuyozqCK['channelimage'],'ott':'wavve'}
    if BIkQjeNATEagFrHSiOMftbxuyozqCK['channelid']not in BIkQjeNATEagFrHSiOMftbxuyozqCh:
     BIkQjeNATEagFrHSiOMftbxuyozqCs.append(BIkQjeNATEagFrHSiOMftbxuyozqJC)
    for BIkQjeNATEagFrHSiOMftbxuyozqlR in BIkQjeNATEagFrHSiOMftbxuyozqCK['list']:
     BIkQjeNATEagFrHSiOMftbxuyozqJC={'channelid':BIkQjeNATEagFrHSiOMftbxuyozqCK['channelid'],'title':BIkQjeNATEagFrHSiOMftbxuyozqCp.xmlText(BIkQjeNATEagFrHSiOMftbxuyozqlR['title']),'startTime':BIkQjeNATEagFrHSiOMftbxuyozqlR['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':BIkQjeNATEagFrHSiOMftbxuyozqlR['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if BIkQjeNATEagFrHSiOMftbxuyozqCK['channelid']not in BIkQjeNATEagFrHSiOMftbxuyozqCh and BIkQjeNATEagFrHSiOMftbxuyozqlR['starttime']!=BIkQjeNATEagFrHSiOMftbxuyozqlR['endtime']:
      BIkQjeNATEagFrHSiOMftbxuyozqJv.append(BIkQjeNATEagFrHSiOMftbxuyozqJC)
  except BIkQjeNATEagFrHSiOMftbxuyozqLd as exception:
   BIkQjeNATEagFrHSiOMftbxuyozqLw(exception)
   return[],[]
  BIkQjeNATEagFrHSiOMftbxuyozqlm=BIkQjeNATEagFrHSiOMftbxuyozqLh(BIkQjeNATEagFrHSiOMftbxuyozqJv)
  for i in(BIkQjeNATEagFrHSiOMftbxuyozqLs(1,BIkQjeNATEagFrHSiOMftbxuyozqlm)):
   if BIkQjeNATEagFrHSiOMftbxuyozqLV(BIkQjeNATEagFrHSiOMftbxuyozqJv[i-1]['endTime'])+1==BIkQjeNATEagFrHSiOMftbxuyozqLV(BIkQjeNATEagFrHSiOMftbxuyozqJv[i]['startTime'])and BIkQjeNATEagFrHSiOMftbxuyozqJv[i-1]['channelid']==BIkQjeNATEagFrHSiOMftbxuyozqJv[i]['channelid']:
    BIkQjeNATEagFrHSiOMftbxuyozqJv[i-1]['endTime']=BIkQjeNATEagFrHSiOMftbxuyozqJv[i]['startTime']
  return BIkQjeNATEagFrHSiOMftbxuyozqCs,BIkQjeNATEagFrHSiOMftbxuyozqJv
 def Get_EpgInfo_Tving(BIkQjeNATEagFrHSiOMftbxuyozqCp,days=2):
  BIkQjeNATEagFrHSiOMftbxuyozqCs=[]
  BIkQjeNATEagFrHSiOMftbxuyozqJv =[]
  BIkQjeNATEagFrHSiOMftbxuyozqlc =[]
  BIkQjeNATEagFrHSiOMftbxuyozqld =BIkQjeNATEagFrHSiOMftbxuyozqCp.make_EpgDatetime_Tving(days=days)
  BIkQjeNATEagFrHSiOMftbxuyozqCs =BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_ChannelList_Tving()
  BIkQjeNATEagFrHSiOMftbxuyozqlw=[]
  for i in BIkQjeNATEagFrHSiOMftbxuyozqLs(BIkQjeNATEagFrHSiOMftbxuyozqLh(BIkQjeNATEagFrHSiOMftbxuyozqCs)):
   BIkQjeNATEagFrHSiOMftbxuyozqCs[i]['channelnm']=BIkQjeNATEagFrHSiOMftbxuyozqCp.xmlText(BIkQjeNATEagFrHSiOMftbxuyozqCs[i]['channelnm'])
   BIkQjeNATEagFrHSiOMftbxuyozqlw.append(BIkQjeNATEagFrHSiOMftbxuyozqCs[i]['channelid'])
  BIkQjeNATEagFrHSiOMftbxuyozqlU=BIkQjeNATEagFrHSiOMftbxuyozqCp.make_Tving_ChannleGroup(BIkQjeNATEagFrHSiOMftbxuyozqlw)
  try:
   BIkQjeNATEagFrHSiOMftbxuyozqCD=BIkQjeNATEagFrHSiOMftbxuyozqCp.API_TVING+'/v2/media/schedules'
   for BIkQjeNATEagFrHSiOMftbxuyozqlV in BIkQjeNATEagFrHSiOMftbxuyozqld:
    for BIkQjeNATEagFrHSiOMftbxuyozqls in BIkQjeNATEagFrHSiOMftbxuyozqlU:
     BIkQjeNATEagFrHSiOMftbxuyozqCw={'pageNo':'1','pageSize':BIkQjeNATEagFrHSiOMftbxuyozqLc(BIkQjeNATEagFrHSiOMftbxuyozqCp.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':BIkQjeNATEagFrHSiOMftbxuyozqlV['ndate'],'broadcastDate':BIkQjeNATEagFrHSiOMftbxuyozqlV['ndate'],'startBroadTime':BIkQjeNATEagFrHSiOMftbxuyozqlV['starttm'],'endBroadTime':BIkQjeNATEagFrHSiOMftbxuyozqlV['endtm'],'channelCode':BIkQjeNATEagFrHSiOMftbxuyozqls}
     BIkQjeNATEagFrHSiOMftbxuyozqCw.update(BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_DefaultParams_Tving())
     BIkQjeNATEagFrHSiOMftbxuyozqCG=BIkQjeNATEagFrHSiOMftbxuyozqCp.callRequestCookies('Get',BIkQjeNATEagFrHSiOMftbxuyozqCD,payload=BIkQjeNATEagFrHSiOMftbxuyozqLR,params=BIkQjeNATEagFrHSiOMftbxuyozqCw,headers=BIkQjeNATEagFrHSiOMftbxuyozqLR,cookies=BIkQjeNATEagFrHSiOMftbxuyozqLR)
     BIkQjeNATEagFrHSiOMftbxuyozqCP=json.loads(BIkQjeNATEagFrHSiOMftbxuyozqCG.text)
     BIkQjeNATEagFrHSiOMftbxuyozqCW=BIkQjeNATEagFrHSiOMftbxuyozqCP['body']['result']
     for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqCW:
      if 'schedules' not in BIkQjeNATEagFrHSiOMftbxuyozqCK:continue
      if BIkQjeNATEagFrHSiOMftbxuyozqCK['schedules']==BIkQjeNATEagFrHSiOMftbxuyozqLR:continue
      for BIkQjeNATEagFrHSiOMftbxuyozqlh in BIkQjeNATEagFrHSiOMftbxuyozqCK['schedules']:
       BIkQjeNATEagFrHSiOMftbxuyozqJC={'channelid':BIkQjeNATEagFrHSiOMftbxuyozqlh['schedule_code'],'title':BIkQjeNATEagFrHSiOMftbxuyozqCp.xmlText(BIkQjeNATEagFrHSiOMftbxuyozqlh['program']['name']['ko']),'startTime':BIkQjeNATEagFrHSiOMftbxuyozqLc(BIkQjeNATEagFrHSiOMftbxuyozqlh['broadcast_start_time']),'endTime':BIkQjeNATEagFrHSiOMftbxuyozqLc(BIkQjeNATEagFrHSiOMftbxuyozqlh['broadcast_end_time']),'ott':'tving'}
       BIkQjeNATEagFrHSiOMftbxuyozqln=BIkQjeNATEagFrHSiOMftbxuyozqlh['schedule_code']+BIkQjeNATEagFrHSiOMftbxuyozqLc(BIkQjeNATEagFrHSiOMftbxuyozqlh['broadcast_start_time'])
       if BIkQjeNATEagFrHSiOMftbxuyozqln in BIkQjeNATEagFrHSiOMftbxuyozqlc:continue
       BIkQjeNATEagFrHSiOMftbxuyozqlc.append(BIkQjeNATEagFrHSiOMftbxuyozqln)
       BIkQjeNATEagFrHSiOMftbxuyozqJv.append(BIkQjeNATEagFrHSiOMftbxuyozqJC)
     time.sleep(BIkQjeNATEagFrHSiOMftbxuyozqCp.SLEEP_TIME)
  except BIkQjeNATEagFrHSiOMftbxuyozqLd as exception:
   BIkQjeNATEagFrHSiOMftbxuyozqLw(exception)
   return[],[]
  return BIkQjeNATEagFrHSiOMftbxuyozqCs,BIkQjeNATEagFrHSiOMftbxuyozqJv
 def make_getGenre(BIkQjeNATEagFrHSiOMftbxuyozqCp,BIkQjeNATEagFrHSiOMftbxuyozqCv,BIkQjeNATEagFrHSiOMftbxuyozqLC):
  try:
   BIkQjeNATEagFrHSiOMftbxuyozqJR=BIkQjeNATEagFrHSiOMftbxuyozqCp.INIT_CHANNEL.get(BIkQjeNATEagFrHSiOMftbxuyozqCv+'.'+BIkQjeNATEagFrHSiOMftbxuyozqLC).get('genre')
  except:
   BIkQjeNATEagFrHSiOMftbxuyozqJR='-'
  return BIkQjeNATEagFrHSiOMftbxuyozqJR
 def make_base_allchannel_py(BIkQjeNATEagFrHSiOMftbxuyozqCp):
  BIkQjeNATEagFrHSiOMftbxuyozqlD =[]
  BIkQjeNATEagFrHSiOMftbxuyozqlG=[]
  BIkQjeNATEagFrHSiOMftbxuyozqlP=BIkQjeNATEagFrHSiOMftbxuyozqLn()
  BIkQjeNATEagFrHSiOMftbxuyozqJC=BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_ChannelList_Wavve()
  BIkQjeNATEagFrHSiOMftbxuyozqlD.extend(BIkQjeNATEagFrHSiOMftbxuyozqJC)
  BIkQjeNATEagFrHSiOMftbxuyozqJC=BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_ChannelList_Tving()
  BIkQjeNATEagFrHSiOMftbxuyozqlD.extend(BIkQjeNATEagFrHSiOMftbxuyozqJC)
  BIkQjeNATEagFrHSiOMftbxuyozqJC=BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_ChannelList_Spotv()
  BIkQjeNATEagFrHSiOMftbxuyozqlD.extend(BIkQjeNATEagFrHSiOMftbxuyozqJC)
  BIkQjeNATEagFrHSiOMftbxuyozqLw('1')
  for i in BIkQjeNATEagFrHSiOMftbxuyozqLs(BIkQjeNATEagFrHSiOMftbxuyozqLh(BIkQjeNATEagFrHSiOMftbxuyozqlD)):
   if BIkQjeNATEagFrHSiOMftbxuyozqlD[i]['genrenm']=='-':
    if BIkQjeNATEagFrHSiOMftbxuyozqlD[i]['ott']=='wavve':
     BIkQjeNATEagFrHSiOMftbxuyozqJR=BIkQjeNATEagFrHSiOMftbxuyozqCp.Get_ChanneGenrename_Wavve(BIkQjeNATEagFrHSiOMftbxuyozqlD[i]['channelid'])
     if BIkQjeNATEagFrHSiOMftbxuyozqJR not in BIkQjeNATEagFrHSiOMftbxuyozqlP:BIkQjeNATEagFrHSiOMftbxuyozqlP.add(BIkQjeNATEagFrHSiOMftbxuyozqJR)
     time.sleep(BIkQjeNATEagFrHSiOMftbxuyozqCp.SLEEP_TIME)
    elif BIkQjeNATEagFrHSiOMftbxuyozqlD[i]['ott']=='spotv':
     BIkQjeNATEagFrHSiOMftbxuyozqJR='스포츠'
    else:
     BIkQjeNATEagFrHSiOMftbxuyozqJR='-'
    BIkQjeNATEagFrHSiOMftbxuyozqlD[i]['genrenm']=BIkQjeNATEagFrHSiOMftbxuyozqJR
   else:
    if BIkQjeNATEagFrHSiOMftbxuyozqlD[i]['genrenm']not in BIkQjeNATEagFrHSiOMftbxuyozqlP:BIkQjeNATEagFrHSiOMftbxuyozqlP.add(BIkQjeNATEagFrHSiOMftbxuyozqlD[i]['genrenm'])
  BIkQjeNATEagFrHSiOMftbxuyozqlP.add('-')
  BIkQjeNATEagFrHSiOMftbxuyozqLw('2')
  for BIkQjeNATEagFrHSiOMftbxuyozqlW in BIkQjeNATEagFrHSiOMftbxuyozqlP:
   for BIkQjeNATEagFrHSiOMftbxuyozqlK in BIkQjeNATEagFrHSiOMftbxuyozqlD:
    if BIkQjeNATEagFrHSiOMftbxuyozqlK['genrenm']==BIkQjeNATEagFrHSiOMftbxuyozqlW:
     BIkQjeNATEagFrHSiOMftbxuyozqlG.append(BIkQjeNATEagFrHSiOMftbxuyozqlK)
  for BIkQjeNATEagFrHSiOMftbxuyozqlK in BIkQjeNATEagFrHSiOMftbxuyozqlD:
   if BIkQjeNATEagFrHSiOMftbxuyozqlK['genrenm']not in BIkQjeNATEagFrHSiOMftbxuyozqlP:
    BIkQjeNATEagFrHSiOMftbxuyozqlv.append(BIkQjeNATEagFrHSiOMftbxuyozqlK)
  BIkQjeNATEagFrHSiOMftbxuyozqLw('3')
  BIkQjeNATEagFrHSiOMftbxuyozqlY='d:\\job\\channelgenre.json'
  if os.path.isfile(BIkQjeNATEagFrHSiOMftbxuyozqlY):os.remove(BIkQjeNATEagFrHSiOMftbxuyozqlY)
  fp=BIkQjeNATEagFrHSiOMftbxuyozqLD(BIkQjeNATEagFrHSiOMftbxuyozqlY,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  BIkQjeNATEagFrHSiOMftbxuyozqlX=BIkQjeNATEagFrHSiOMftbxuyozqLh(BIkQjeNATEagFrHSiOMftbxuyozqlG)
  i=0
  for BIkQjeNATEagFrHSiOMftbxuyozqCK in BIkQjeNATEagFrHSiOMftbxuyozqlG:
   i+=1
   BIkQjeNATEagFrHSiOMftbxuyozqCv =BIkQjeNATEagFrHSiOMftbxuyozqCK['channelid']
   BIkQjeNATEagFrHSiOMftbxuyozqCY =BIkQjeNATEagFrHSiOMftbxuyozqCK['channelnm']
   BIkQjeNATEagFrHSiOMftbxuyozqLC =BIkQjeNATEagFrHSiOMftbxuyozqCK['ott']
   BIkQjeNATEagFrHSiOMftbxuyozqLJ ='%s.%s'%(BIkQjeNATEagFrHSiOMftbxuyozqCv,BIkQjeNATEagFrHSiOMftbxuyozqLC)
   BIkQjeNATEagFrHSiOMftbxuyozqJR =BIkQjeNATEagFrHSiOMftbxuyozqCK['genrenm']
   BIkQjeNATEagFrHSiOMftbxuyozqLl='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(BIkQjeNATEagFrHSiOMftbxuyozqLJ,BIkQjeNATEagFrHSiOMftbxuyozqCY,BIkQjeNATEagFrHSiOMftbxuyozqJR)
   if i<BIkQjeNATEagFrHSiOMftbxuyozqlX:
    fp.write(BIkQjeNATEagFrHSiOMftbxuyozqLl+',\n')
   else:
    fp.write(BIkQjeNATEagFrHSiOMftbxuyozqLl+'\n')
  fp.write('}\n')
  fp.close()
  return BIkQjeNATEagFrHSiOMftbxuyozqlP
# Created by pyminifier (https://github.com/liftoff/pyminifier)
