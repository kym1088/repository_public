__author__="NightRain"
WuTEginUOICkMompLhjfFtasSexVyl=object
WuTEginUOICkMompLhjfFtasSexVyH=False
WuTEginUOICkMompLhjfFtasSexVyw=None
WuTEginUOICkMompLhjfFtasSexVyr=True
WuTEginUOICkMompLhjfFtasSexVcG=len
WuTEginUOICkMompLhjfFtasSexVcP=str
WuTEginUOICkMompLhjfFtasSexVcy=open
WuTEginUOICkMompLhjfFtasSexVcq=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
WuTEginUOICkMompLhjfFtasSexVGy=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
WuTEginUOICkMompLhjfFtasSexVGc='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
WuTEginUOICkMompLhjfFtasSexVGq=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class WuTEginUOICkMompLhjfFtasSexVGP(WuTEginUOICkMompLhjfFtasSexVyl):
 def __init__(WuTEginUOICkMompLhjfFtasSexVGb,WuTEginUOICkMompLhjfFtasSexVGz,WuTEginUOICkMompLhjfFtasSexVGA,WuTEginUOICkMompLhjfFtasSexVGd):
  WuTEginUOICkMompLhjfFtasSexVGb._addon_url =WuTEginUOICkMompLhjfFtasSexVGz
  WuTEginUOICkMompLhjfFtasSexVGb._addon_handle =WuTEginUOICkMompLhjfFtasSexVGA
  WuTEginUOICkMompLhjfFtasSexVGb.main_params =WuTEginUOICkMompLhjfFtasSexVGd
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_FILE_PATH ='' 
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_FILE_NAME ='' 
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVE =WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONTVING =WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONSPOTV =WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVERADIO=WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVEHOME =WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONSPOTVPAY =WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_DISPLAYNM =WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_AUTORESTART =WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.BoritvObj =BIkQjeNATEagFrHSiOMftbxuyozqCJ() 
 def addon_noti(WuTEginUOICkMompLhjfFtasSexVGb,sting):
  try:
   WuTEginUOICkMompLhjfFtasSexVGB=xbmcgui.Dialog()
   WuTEginUOICkMompLhjfFtasSexVGB.notification(__addonname__,sting)
  except:
   WuTEginUOICkMompLhjfFtasSexVyw
 def addon_log(WuTEginUOICkMompLhjfFtasSexVGb,string):
  try:
   WuTEginUOICkMompLhjfFtasSexVGN=string.encode('utf-8','ignore')
  except:
   WuTEginUOICkMompLhjfFtasSexVGN='addonException: addon_log'
  WuTEginUOICkMompLhjfFtasSexVGQ=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,WuTEginUOICkMompLhjfFtasSexVGN),level=WuTEginUOICkMompLhjfFtasSexVGQ)
 def get_keyboard_input(WuTEginUOICkMompLhjfFtasSexVGb,WuTEginUOICkMompLhjfFtasSexVGD):
  WuTEginUOICkMompLhjfFtasSexVGJ=WuTEginUOICkMompLhjfFtasSexVyw
  kb=xbmc.Keyboard()
  kb.setHeading(WuTEginUOICkMompLhjfFtasSexVGD)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   WuTEginUOICkMompLhjfFtasSexVGJ=kb.getText()
  return WuTEginUOICkMompLhjfFtasSexVGJ
 def add_dir(WuTEginUOICkMompLhjfFtasSexVGb,label,sublabel='',img='',infoLabels=WuTEginUOICkMompLhjfFtasSexVyw,isFolder=WuTEginUOICkMompLhjfFtasSexVyr,params=''):
  WuTEginUOICkMompLhjfFtasSexVGY='%s?%s'%(WuTEginUOICkMompLhjfFtasSexVGb._addon_url,urllib.parse.urlencode(params))
  if sublabel:WuTEginUOICkMompLhjfFtasSexVGD='%s < %s >'%(label,sublabel)
  else: WuTEginUOICkMompLhjfFtasSexVGD=label
  if not img:img='DefaultFolder.png'
  WuTEginUOICkMompLhjfFtasSexVGK=xbmcgui.ListItem(WuTEginUOICkMompLhjfFtasSexVGD)
  WuTEginUOICkMompLhjfFtasSexVGK.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:WuTEginUOICkMompLhjfFtasSexVGK.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:WuTEginUOICkMompLhjfFtasSexVGK.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(WuTEginUOICkMompLhjfFtasSexVGb._addon_handle,WuTEginUOICkMompLhjfFtasSexVGY,WuTEginUOICkMompLhjfFtasSexVGK,isFolder)
 def make_M3u_Filename(WuTEginUOICkMompLhjfFtasSexVGb,tempyn=WuTEginUOICkMompLhjfFtasSexVyH):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return WuTEginUOICkMompLhjfFtasSexVGb.M3U_FILE_PATH+WuTEginUOICkMompLhjfFtasSexVGb.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(WuTEginUOICkMompLhjfFtasSexVGb,tempyn=WuTEginUOICkMompLhjfFtasSexVyH):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return WuTEginUOICkMompLhjfFtasSexVGb.M3U_FILE_PATH+WuTEginUOICkMompLhjfFtasSexVGb.M3U_FILE_NAME+'.xml'
 def dp_Main_List(WuTEginUOICkMompLhjfFtasSexVGb):
  for WuTEginUOICkMompLhjfFtasSexVGX in WuTEginUOICkMompLhjfFtasSexVGy:
   WuTEginUOICkMompLhjfFtasSexVGD=WuTEginUOICkMompLhjfFtasSexVGX.get('title')
   WuTEginUOICkMompLhjfFtasSexVGv={'mode':WuTEginUOICkMompLhjfFtasSexVGX.get('mode'),'sType':WuTEginUOICkMompLhjfFtasSexVGX.get('sType'),'sName':WuTEginUOICkMompLhjfFtasSexVGX.get('sName')}
   if WuTEginUOICkMompLhjfFtasSexVGX.get('mode')=='XXX':
    WuTEginUOICkMompLhjfFtasSexVGl=WuTEginUOICkMompLhjfFtasSexVyH
   else:
    WuTEginUOICkMompLhjfFtasSexVGl=WuTEginUOICkMompLhjfFtasSexVyr
   WuTEginUOICkMompLhjfFtasSexVGH=WuTEginUOICkMompLhjfFtasSexVyr
   if WuTEginUOICkMompLhjfFtasSexVGX.get('mode')=='ADD_M3U':
    if WuTEginUOICkMompLhjfFtasSexVGX.get('sType')=='wavve' and WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVE==WuTEginUOICkMompLhjfFtasSexVyH:WuTEginUOICkMompLhjfFtasSexVGH=WuTEginUOICkMompLhjfFtasSexVyH
    if WuTEginUOICkMompLhjfFtasSexVGX.get('sType')=='tving' and WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONTVING==WuTEginUOICkMompLhjfFtasSexVyH:WuTEginUOICkMompLhjfFtasSexVGH=WuTEginUOICkMompLhjfFtasSexVyH
    if WuTEginUOICkMompLhjfFtasSexVGX.get('sType')=='spotv' and WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONSPOTV==WuTEginUOICkMompLhjfFtasSexVyH:WuTEginUOICkMompLhjfFtasSexVGH=WuTEginUOICkMompLhjfFtasSexVyH
   if WuTEginUOICkMompLhjfFtasSexVGH==WuTEginUOICkMompLhjfFtasSexVyr:
    WuTEginUOICkMompLhjfFtasSexVGb.add_dir(WuTEginUOICkMompLhjfFtasSexVGD,sublabel='',img='',infoLabels=WuTEginUOICkMompLhjfFtasSexVyw,isFolder=WuTEginUOICkMompLhjfFtasSexVGl,params=WuTEginUOICkMompLhjfFtasSexVGv)
  if WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVGy)>0:xbmcplugin.endOfDirectory(WuTEginUOICkMompLhjfFtasSexVGb._addon_handle,cacheToDisc=WuTEginUOICkMompLhjfFtasSexVyr)
 def dp_Delete_M3u(WuTEginUOICkMompLhjfFtasSexVGb,args):
  WuTEginUOICkMompLhjfFtasSexVGB=xbmcgui.Dialog()
  WuTEginUOICkMompLhjfFtasSexVGr=WuTEginUOICkMompLhjfFtasSexVGB.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if WuTEginUOICkMompLhjfFtasSexVGr==WuTEginUOICkMompLhjfFtasSexVyH:sys.exit()
  WuTEginUOICkMompLhjfFtasSexVPG=WuTEginUOICkMompLhjfFtasSexVGb.make_M3u_Filename(tempyn=WuTEginUOICkMompLhjfFtasSexVyH)
  if xbmcvfs.exists(WuTEginUOICkMompLhjfFtasSexVPG):
   if xbmcvfs.delete(WuTEginUOICkMompLhjfFtasSexVPG)==WuTEginUOICkMompLhjfFtasSexVyH:
    WuTEginUOICkMompLhjfFtasSexVGb.addon_noti(__language__(30910).encode('utf-8'))
    return
  WuTEginUOICkMompLhjfFtasSexVGb.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(WuTEginUOICkMompLhjfFtasSexVGb,args):
  WuTEginUOICkMompLhjfFtasSexVPy=args.get('sType')
  WuTEginUOICkMompLhjfFtasSexVPc=args.get('sName')
  WuTEginUOICkMompLhjfFtasSexVGB=xbmcgui.Dialog()
  WuTEginUOICkMompLhjfFtasSexVGr=WuTEginUOICkMompLhjfFtasSexVGB.yesno((WuTEginUOICkMompLhjfFtasSexVPc+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if WuTEginUOICkMompLhjfFtasSexVGr==WuTEginUOICkMompLhjfFtasSexVyH:sys.exit()
  WuTEginUOICkMompLhjfFtasSexVPq =[]
  WuTEginUOICkMompLhjfFtasSexVPb =[]
  WuTEginUOICkMompLhjfFtasSexVPz=[]
  if WuTEginUOICkMompLhjfFtasSexVPy=='all':
   WuTEginUOICkMompLhjfFtasSexVPG=WuTEginUOICkMompLhjfFtasSexVGb.make_M3u_Filename(tempyn=WuTEginUOICkMompLhjfFtasSexVyr)
   if os.path.isfile(WuTEginUOICkMompLhjfFtasSexVPG):os.remove(WuTEginUOICkMompLhjfFtasSexVPG)
   WuTEginUOICkMompLhjfFtasSexVPG=WuTEginUOICkMompLhjfFtasSexVGb.make_M3u_Filename(tempyn=WuTEginUOICkMompLhjfFtasSexVyH)
   if xbmcvfs.exists(WuTEginUOICkMompLhjfFtasSexVPG):
    if xbmcvfs.delete(WuTEginUOICkMompLhjfFtasSexVPG)==WuTEginUOICkMompLhjfFtasSexVyH:
     WuTEginUOICkMompLhjfFtasSexVGb.addon_noti(__language__(30910).encode('utf-8'))
     return
  if(WuTEginUOICkMompLhjfFtasSexVPy=='wavve' or WuTEginUOICkMompLhjfFtasSexVPy=='all')and WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVE:
   WuTEginUOICkMompLhjfFtasSexVPA=WuTEginUOICkMompLhjfFtasSexVGb.BoritvObj.Get_ChannelList_Wavve(exceptGroup=WuTEginUOICkMompLhjfFtasSexVGb.make_EexceptGroup_Wavve())
   if WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVPA)!=0:WuTEginUOICkMompLhjfFtasSexVPq.extend(WuTEginUOICkMompLhjfFtasSexVPA)
   WuTEginUOICkMompLhjfFtasSexVPz=WuTEginUOICkMompLhjfFtasSexVGb.get_radio_list()
   WuTEginUOICkMompLhjfFtasSexVGb.addon_log('wavve cnt ----> '+WuTEginUOICkMompLhjfFtasSexVcP(WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVPA)))
  if(WuTEginUOICkMompLhjfFtasSexVPy=='tving' or WuTEginUOICkMompLhjfFtasSexVPy=='all')and WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONTVING:
   WuTEginUOICkMompLhjfFtasSexVPA=WuTEginUOICkMompLhjfFtasSexVGb.BoritvObj.Get_ChannelList_Tving()
   if WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVPA)!=0:WuTEginUOICkMompLhjfFtasSexVPq.extend(WuTEginUOICkMompLhjfFtasSexVPA)
   WuTEginUOICkMompLhjfFtasSexVGb.addon_log('tving cnt ----> '+WuTEginUOICkMompLhjfFtasSexVcP(WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVPA)))
  if(WuTEginUOICkMompLhjfFtasSexVPy=='spotv' or WuTEginUOICkMompLhjfFtasSexVPy=='all')and WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONSPOTV:
   WuTEginUOICkMompLhjfFtasSexVPA=WuTEginUOICkMompLhjfFtasSexVGb.BoritvObj.Get_ChannelList_Spotv(payyn=WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONSPOTVPAY)
   if WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVPA)!=0:WuTEginUOICkMompLhjfFtasSexVPq.extend(WuTEginUOICkMompLhjfFtasSexVPA)
   WuTEginUOICkMompLhjfFtasSexVGb.addon_log('spotv cnt ----> '+WuTEginUOICkMompLhjfFtasSexVcP(WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVPA)))
  if WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVPq)==0:
   WuTEginUOICkMompLhjfFtasSexVGb.addon_noti(__language__(30909).encode('utf8'))
   return
  for WuTEginUOICkMompLhjfFtasSexVPd in WuTEginUOICkMompLhjfFtasSexVGb.BoritvObj.INIT_GENRESORT:
   for WuTEginUOICkMompLhjfFtasSexVPR in WuTEginUOICkMompLhjfFtasSexVPq:
    if WuTEginUOICkMompLhjfFtasSexVPR['genrenm']==WuTEginUOICkMompLhjfFtasSexVPd:
     WuTEginUOICkMompLhjfFtasSexVPb.append(WuTEginUOICkMompLhjfFtasSexVPR)
  for WuTEginUOICkMompLhjfFtasSexVPR in WuTEginUOICkMompLhjfFtasSexVPq:
   if WuTEginUOICkMompLhjfFtasSexVPR['genrenm']not in WuTEginUOICkMompLhjfFtasSexVGb.BoritvObj.INIT_GENRESORT:
    WuTEginUOICkMompLhjfFtasSexVPb.append(WuTEginUOICkMompLhjfFtasSexVPR)
  try:
   WuTEginUOICkMompLhjfFtasSexVPG=WuTEginUOICkMompLhjfFtasSexVGb.make_M3u_Filename(tempyn=WuTEginUOICkMompLhjfFtasSexVyr)
   if os.path.isfile(WuTEginUOICkMompLhjfFtasSexVPG):
    fp=WuTEginUOICkMompLhjfFtasSexVcy(WuTEginUOICkMompLhjfFtasSexVPG,'a',-1,'utf-8')
   else:
    fp=WuTEginUOICkMompLhjfFtasSexVcy(WuTEginUOICkMompLhjfFtasSexVPG,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for WuTEginUOICkMompLhjfFtasSexVPB in WuTEginUOICkMompLhjfFtasSexVPb:
    WuTEginUOICkMompLhjfFtasSexVPN =WuTEginUOICkMompLhjfFtasSexVPB['channelid']
    WuTEginUOICkMompLhjfFtasSexVPQ =WuTEginUOICkMompLhjfFtasSexVPB['channelnm']
    WuTEginUOICkMompLhjfFtasSexVPJ=WuTEginUOICkMompLhjfFtasSexVPB['channelimg']
    WuTEginUOICkMompLhjfFtasSexVPY =WuTEginUOICkMompLhjfFtasSexVPB['ott']
    WuTEginUOICkMompLhjfFtasSexVPD ='%s.%s'%(WuTEginUOICkMompLhjfFtasSexVPN,WuTEginUOICkMompLhjfFtasSexVPY)
    WuTEginUOICkMompLhjfFtasSexVPK=WuTEginUOICkMompLhjfFtasSexVPB['genrenm']
    if WuTEginUOICkMompLhjfFtasSexVGb.M3U_DISPLAYNM:
     WuTEginUOICkMompLhjfFtasSexVPQ='%s (%s)'%(WuTEginUOICkMompLhjfFtasSexVPQ,WuTEginUOICkMompLhjfFtasSexVPY)
    if WuTEginUOICkMompLhjfFtasSexVPN in WuTEginUOICkMompLhjfFtasSexVPz:
     WuTEginUOICkMompLhjfFtasSexVPX='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(WuTEginUOICkMompLhjfFtasSexVPD,WuTEginUOICkMompLhjfFtasSexVPQ,WuTEginUOICkMompLhjfFtasSexVPK,WuTEginUOICkMompLhjfFtasSexVPJ,WuTEginUOICkMompLhjfFtasSexVPQ)
    else:
     WuTEginUOICkMompLhjfFtasSexVPX='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(WuTEginUOICkMompLhjfFtasSexVPD,WuTEginUOICkMompLhjfFtasSexVPQ,WuTEginUOICkMompLhjfFtasSexVPK,WuTEginUOICkMompLhjfFtasSexVPJ,WuTEginUOICkMompLhjfFtasSexVPQ)
    if WuTEginUOICkMompLhjfFtasSexVPY=='wavve':
     WuTEginUOICkMompLhjfFtasSexVPv ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(WuTEginUOICkMompLhjfFtasSexVPN)
    elif WuTEginUOICkMompLhjfFtasSexVPY=='tving':
     WuTEginUOICkMompLhjfFtasSexVPv ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(WuTEginUOICkMompLhjfFtasSexVPN)
    elif WuTEginUOICkMompLhjfFtasSexVPY=='spotv':
     WuTEginUOICkMompLhjfFtasSexVPv ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(WuTEginUOICkMompLhjfFtasSexVPN)
    fp.write(WuTEginUOICkMompLhjfFtasSexVPX)
    fp.write(WuTEginUOICkMompLhjfFtasSexVPv)
   fp.close()
  except:
   WuTEginUOICkMompLhjfFtasSexVGb.addon_noti(__language__(30910).encode('utf8'))
   return
  WuTEginUOICkMompLhjfFtasSexVPl=WuTEginUOICkMompLhjfFtasSexVGb.make_M3u_Filename(tempyn=WuTEginUOICkMompLhjfFtasSexVyr)
  WuTEginUOICkMompLhjfFtasSexVPH=WuTEginUOICkMompLhjfFtasSexVGb.make_M3u_Filename(tempyn=WuTEginUOICkMompLhjfFtasSexVyH)
  if xbmcvfs.copy(WuTEginUOICkMompLhjfFtasSexVPl,WuTEginUOICkMompLhjfFtasSexVPH):
   WuTEginUOICkMompLhjfFtasSexVGb.addon_noti((WuTEginUOICkMompLhjfFtasSexVPc+' '+__language__(30908)).encode('utf8'))
  else:
   WuTEginUOICkMompLhjfFtasSexVGb.addon_noti(__language__(30910).encode('utf-8'))
 def dp_Make_Epg(WuTEginUOICkMompLhjfFtasSexVGb,args):
  WuTEginUOICkMompLhjfFtasSexVPy=args.get('sType')
  WuTEginUOICkMompLhjfFtasSexVPc=args.get('sName')
  WuTEginUOICkMompLhjfFtasSexVPw=args.get('sNoti')
  if WuTEginUOICkMompLhjfFtasSexVPw!='N':
   WuTEginUOICkMompLhjfFtasSexVGB=xbmcgui.Dialog()
   WuTEginUOICkMompLhjfFtasSexVGr=WuTEginUOICkMompLhjfFtasSexVGB.yesno((WuTEginUOICkMompLhjfFtasSexVPc+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if WuTEginUOICkMompLhjfFtasSexVGr==WuTEginUOICkMompLhjfFtasSexVyH:sys.exit()
  WuTEginUOICkMompLhjfFtasSexVPr=[]
  WuTEginUOICkMompLhjfFtasSexVyG=[]
  if(WuTEginUOICkMompLhjfFtasSexVPy=='wavve' or WuTEginUOICkMompLhjfFtasSexVPy=='all')and WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVE:
   WuTEginUOICkMompLhjfFtasSexVyP,WuTEginUOICkMompLhjfFtasSexVyc=WuTEginUOICkMompLhjfFtasSexVGb.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=WuTEginUOICkMompLhjfFtasSexVGb.make_EexceptGroup_Wavve())
   if WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVyc)!=0:
    WuTEginUOICkMompLhjfFtasSexVPr.extend(WuTEginUOICkMompLhjfFtasSexVyP)
    WuTEginUOICkMompLhjfFtasSexVyG.extend(WuTEginUOICkMompLhjfFtasSexVyc)
  if(WuTEginUOICkMompLhjfFtasSexVPy=='tving' or WuTEginUOICkMompLhjfFtasSexVPy=='all')and WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONTVING:
   WuTEginUOICkMompLhjfFtasSexVyP,WuTEginUOICkMompLhjfFtasSexVyc=WuTEginUOICkMompLhjfFtasSexVGb.BoritvObj.Get_EpgInfo_Tving()
   if WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVyc)!=0:
    WuTEginUOICkMompLhjfFtasSexVPr.extend(WuTEginUOICkMompLhjfFtasSexVyP)
    WuTEginUOICkMompLhjfFtasSexVyG.extend(WuTEginUOICkMompLhjfFtasSexVyc)
  if(WuTEginUOICkMompLhjfFtasSexVPy=='spotv' or WuTEginUOICkMompLhjfFtasSexVPy=='all')and WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONSPOTV:
   WuTEginUOICkMompLhjfFtasSexVyP,WuTEginUOICkMompLhjfFtasSexVyc=WuTEginUOICkMompLhjfFtasSexVGb.BoritvObj.Get_EpgInfo_Spotv(payyn=WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONSPOTVPAY)
   if WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVyc)!=0:
    WuTEginUOICkMompLhjfFtasSexVPr.extend(WuTEginUOICkMompLhjfFtasSexVyP)
    WuTEginUOICkMompLhjfFtasSexVyG.extend(WuTEginUOICkMompLhjfFtasSexVyc)
  if WuTEginUOICkMompLhjfFtasSexVcG(WuTEginUOICkMompLhjfFtasSexVyG)==0:
   if WuTEginUOICkMompLhjfFtasSexVPw!='N':WuTEginUOICkMompLhjfFtasSexVGb.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   WuTEginUOICkMompLhjfFtasSexVPG=WuTEginUOICkMompLhjfFtasSexVGb.make_Epg_Filename(tempyn=WuTEginUOICkMompLhjfFtasSexVyr)
   fp=WuTEginUOICkMompLhjfFtasSexVcy(WuTEginUOICkMompLhjfFtasSexVPG,'w',-1,'utf-8')
   WuTEginUOICkMompLhjfFtasSexVyq='<?xml version="1.0" encoding="UTF-8"?>\n'
   WuTEginUOICkMompLhjfFtasSexVyb='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   WuTEginUOICkMompLhjfFtasSexVyz='<tv generator-info-name="boritv_epg">\n\n'
   WuTEginUOICkMompLhjfFtasSexVyA='\n</tv>\n'
   fp.write(WuTEginUOICkMompLhjfFtasSexVyq)
   fp.write(WuTEginUOICkMompLhjfFtasSexVyb)
   fp.write(WuTEginUOICkMompLhjfFtasSexVyz)
   for WuTEginUOICkMompLhjfFtasSexVyd in WuTEginUOICkMompLhjfFtasSexVPr:
    WuTEginUOICkMompLhjfFtasSexVyR='  <channel id="%s.%s">\n' %(WuTEginUOICkMompLhjfFtasSexVyd.get('channelid'),WuTEginUOICkMompLhjfFtasSexVyd.get('ott'))
    WuTEginUOICkMompLhjfFtasSexVyB='    <display-name>%s</display-name>\n'%(WuTEginUOICkMompLhjfFtasSexVyd.get('channelnm'))
    WuTEginUOICkMompLhjfFtasSexVyN='    <icon src="%s" />\n' %(WuTEginUOICkMompLhjfFtasSexVyd.get('channelimg'))
    WuTEginUOICkMompLhjfFtasSexVyQ='  </channel>\n\n'
    fp.write(WuTEginUOICkMompLhjfFtasSexVyR)
    fp.write(WuTEginUOICkMompLhjfFtasSexVyB)
    fp.write(WuTEginUOICkMompLhjfFtasSexVyN)
    fp.write(WuTEginUOICkMompLhjfFtasSexVyQ)
   for WuTEginUOICkMompLhjfFtasSexVyd in WuTEginUOICkMompLhjfFtasSexVyG:
    WuTEginUOICkMompLhjfFtasSexVyR='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(WuTEginUOICkMompLhjfFtasSexVyd.get('startTime'),WuTEginUOICkMompLhjfFtasSexVyd.get('endTime'),WuTEginUOICkMompLhjfFtasSexVyd.get('channelid'),WuTEginUOICkMompLhjfFtasSexVyd.get('ott'))
    WuTEginUOICkMompLhjfFtasSexVyB='    <title lang="kr">%s</title>\n' %(WuTEginUOICkMompLhjfFtasSexVyd.get('title'))
    WuTEginUOICkMompLhjfFtasSexVyN='  </programme>\n\n'
    fp.write(WuTEginUOICkMompLhjfFtasSexVyR)
    fp.write(WuTEginUOICkMompLhjfFtasSexVyB)
    fp.write(WuTEginUOICkMompLhjfFtasSexVyN)
   fp.write(WuTEginUOICkMompLhjfFtasSexVyA)
   fp.close()
  except:
   if WuTEginUOICkMompLhjfFtasSexVPw!='N':WuTEginUOICkMompLhjfFtasSexVGb.addon_noti(__language__(30910).encode('utf8'))
   return
  WuTEginUOICkMompLhjfFtasSexVGb.MakeEpg_SaveJson()
  WuTEginUOICkMompLhjfFtasSexVPl=WuTEginUOICkMompLhjfFtasSexVGb.make_Epg_Filename(tempyn=WuTEginUOICkMompLhjfFtasSexVyr)
  WuTEginUOICkMompLhjfFtasSexVPH=WuTEginUOICkMompLhjfFtasSexVGb.make_Epg_Filename(tempyn=WuTEginUOICkMompLhjfFtasSexVyH)
  if xbmcvfs.copy(WuTEginUOICkMompLhjfFtasSexVPl,WuTEginUOICkMompLhjfFtasSexVPH):
   if WuTEginUOICkMompLhjfFtasSexVPw!='N':WuTEginUOICkMompLhjfFtasSexVGb.addon_noti((WuTEginUOICkMompLhjfFtasSexVPc+' '+__language__(30912)).encode('utf8'))
  else:
   WuTEginUOICkMompLhjfFtasSexVGb.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if WuTEginUOICkMompLhjfFtasSexVGb.M3U_AUTORESTART:
    WuTEginUOICkMompLhjfFtasSexVyJ=xbmcaddon.Addon('pvr.iptvsimple')
    WuTEginUOICkMompLhjfFtasSexVyJ.setSetting('anything','anything')
  except:
   WuTEginUOICkMompLhjfFtasSexVyw 
 def make_EexceptGroup_Wavve(WuTEginUOICkMompLhjfFtasSexVGb):
  WuTEginUOICkMompLhjfFtasSexVyY=[]
  if WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVERADIO==WuTEginUOICkMompLhjfFtasSexVyH:
   WuTEginUOICkMompLhjfFtasSexVyD={'broadcastid':'46584','genre':'10'}
   WuTEginUOICkMompLhjfFtasSexVyY.append(WuTEginUOICkMompLhjfFtasSexVyD)
  if WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVEHOME==WuTEginUOICkMompLhjfFtasSexVyH:
   WuTEginUOICkMompLhjfFtasSexVyD={'broadcastid':'46584','genre':'03'}
   WuTEginUOICkMompLhjfFtasSexVyY.append(WuTEginUOICkMompLhjfFtasSexVyD)
  return WuTEginUOICkMompLhjfFtasSexVyY
 def get_radio_list(WuTEginUOICkMompLhjfFtasSexVGb):
  if WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVERADIO==WuTEginUOICkMompLhjfFtasSexVyH:return[]
  WuTEginUOICkMompLhjfFtasSexVyD=[{'broadcastid':'46584','genre':'10'}]
  return WuTEginUOICkMompLhjfFtasSexVGb.BoritvObj.Get_ChannelList_WavveExcept(WuTEginUOICkMompLhjfFtasSexVyD)
 def check_config(WuTEginUOICkMompLhjfFtasSexVGb):
  WuTEginUOICkMompLhjfFtasSexVyK=WuTEginUOICkMompLhjfFtasSexVyr
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVE =WuTEginUOICkMompLhjfFtasSexVyr if __addon__.getSetting('onWavve')=='true' else WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONTVING =WuTEginUOICkMompLhjfFtasSexVyr if __addon__.getSetting('onTvng')=='true' else WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONSPOTV =WuTEginUOICkMompLhjfFtasSexVyr if __addon__.getSetting('onSpotv')=='true' else WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVERADIO=WuTEginUOICkMompLhjfFtasSexVyr if __addon__.getSetting('onWavveRadio')=='true' else WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVEHOME =WuTEginUOICkMompLhjfFtasSexVyr if __addon__.getSetting('onWavveHome')=='true' else WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONSPOTVPAY =WuTEginUOICkMompLhjfFtasSexVyr if __addon__.getSetting('onSpotvPay')=='true' else WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_DISPLAYNM =WuTEginUOICkMompLhjfFtasSexVyr if __addon__.getSetting('displayOTTnm')=='true' else WuTEginUOICkMompLhjfFtasSexVyH
  WuTEginUOICkMompLhjfFtasSexVGb.M3U_AUTORESTART =WuTEginUOICkMompLhjfFtasSexVyr if __addon__.getSetting('autoRestart')=='true' else WuTEginUOICkMompLhjfFtasSexVyH
  if WuTEginUOICkMompLhjfFtasSexVGb.M3U_FILE_PATH=='' or WuTEginUOICkMompLhjfFtasSexVGb.M3U_FILE_NAME=='':WuTEginUOICkMompLhjfFtasSexVyK=WuTEginUOICkMompLhjfFtasSexVyH
  if WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONWAVVE==WuTEginUOICkMompLhjfFtasSexVyH and WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONTVING=='' and WuTEginUOICkMompLhjfFtasSexVGb.M3U_ONSPOTV=='':WuTEginUOICkMompLhjfFtasSexVyK=WuTEginUOICkMompLhjfFtasSexVyH
  if WuTEginUOICkMompLhjfFtasSexVyK==WuTEginUOICkMompLhjfFtasSexVyH:
   WuTEginUOICkMompLhjfFtasSexVGB=xbmcgui.Dialog()
   WuTEginUOICkMompLhjfFtasSexVGr=WuTEginUOICkMompLhjfFtasSexVGB.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if WuTEginUOICkMompLhjfFtasSexVGr==WuTEginUOICkMompLhjfFtasSexVyr:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(WuTEginUOICkMompLhjfFtasSexVGb):
  WuTEginUOICkMompLhjfFtasSexVyX={'date_makeepg':WuTEginUOICkMompLhjfFtasSexVGb.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=WuTEginUOICkMompLhjfFtasSexVcy(WuTEginUOICkMompLhjfFtasSexVGq,'w',-1,'utf-8')
   json.dump(WuTEginUOICkMompLhjfFtasSexVyX,fp)
   fp.close()
  except WuTEginUOICkMompLhjfFtasSexVcq as exception:
   return
 def boritv_main(WuTEginUOICkMompLhjfFtasSexVGb):
  WuTEginUOICkMompLhjfFtasSexVyv=WuTEginUOICkMompLhjfFtasSexVGb.main_params.get('mode',WuTEginUOICkMompLhjfFtasSexVyw)
  WuTEginUOICkMompLhjfFtasSexVGb.check_config()
  if WuTEginUOICkMompLhjfFtasSexVyv is WuTEginUOICkMompLhjfFtasSexVyw:
   WuTEginUOICkMompLhjfFtasSexVGb.dp_Main_List()
  elif WuTEginUOICkMompLhjfFtasSexVyv=='DEL_M3U':
   WuTEginUOICkMompLhjfFtasSexVGb.dp_Delete_M3u(WuTEginUOICkMompLhjfFtasSexVGb.main_params)
  elif WuTEginUOICkMompLhjfFtasSexVyv=='ADD_M3U':
   WuTEginUOICkMompLhjfFtasSexVGb.dp_MakeAdd_M3u(WuTEginUOICkMompLhjfFtasSexVGb.main_params)
  elif WuTEginUOICkMompLhjfFtasSexVyv=='ADD_EPG':
   WuTEginUOICkMompLhjfFtasSexVGb.dp_Make_Epg(WuTEginUOICkMompLhjfFtasSexVGb.main_params)
  else:
   WuTEginUOICkMompLhjfFtasSexVyw
# Created by pyminifier (https://github.com/liftoff/pyminifier)
