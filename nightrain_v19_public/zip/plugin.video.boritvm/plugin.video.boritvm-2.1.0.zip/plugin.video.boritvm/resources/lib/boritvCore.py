__author__="NightRain"
fnLMVJkISrjRhQtdzEHauGDgKowUqm=False
fnLMVJkISrjRhQtdzEHauGDgKowUqF=object
fnLMVJkISrjRhQtdzEHauGDgKowUqX=None
fnLMVJkISrjRhQtdzEHauGDgKowUql=str
fnLMVJkISrjRhQtdzEHauGDgKowUqx=Exception
fnLMVJkISrjRhQtdzEHauGDgKowUqe=print
fnLMVJkISrjRhQtdzEHauGDgKowUqs=True
fnLMVJkISrjRhQtdzEHauGDgKowUqT=int
fnLMVJkISrjRhQtdzEHauGDgKowUqY=range
fnLMVJkISrjRhQtdzEHauGDgKowUqB=len
fnLMVJkISrjRhQtdzEHauGDgKowUqi=set
fnLMVJkISrjRhQtdzEHauGDgKowUqp=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
from channelgenre import*
fnLMVJkISrjRhQtdzEHauGDgKowUPN=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
fnLMVJkISrjRhQtdzEHauGDgKowUPq=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':fnLMVJkISrjRhQtdzEHauGDgKowUqm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':fnLMVJkISrjRhQtdzEHauGDgKowUqm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':fnLMVJkISrjRhQtdzEHauGDgKowUqm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':fnLMVJkISrjRhQtdzEHauGDgKowUqm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':fnLMVJkISrjRhQtdzEHauGDgKowUqm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':fnLMVJkISrjRhQtdzEHauGDgKowUqm,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class fnLMVJkISrjRhQtdzEHauGDgKowUPC(fnLMVJkISrjRhQtdzEHauGDgKowUqF):
 def __init__(fnLMVJkISrjRhQtdzEHauGDgKowUPc):
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_WAVVE ='https://apis.wavve.com'
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_TVING ='https://api.tving.com'
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_TVINGIMG ='https://image.tving.com'
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_SPOTV ='https://www.spotvnow.co.kr'
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.HTTPTAG ='https://'
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.LIMIT_WAVVE =200
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.LIMIT_TVING =60
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.LIMIT_TVINGEPG=20 
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.DEFAULT_HEADER={'user-agent':fnLMVJkISrjRhQtdzEHauGDgKowUPc.USER_AGENT}
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.SLEEP_TIME =0.2
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.INIT_GENRESORT=MASTER_GENRE
  fnLMVJkISrjRhQtdzEHauGDgKowUPc.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(fnLMVJkISrjRhQtdzEHauGDgKowUPc,jobtype,fnLMVJkISrjRhQtdzEHauGDgKowUPY,payload=fnLMVJkISrjRhQtdzEHauGDgKowUqX,params=fnLMVJkISrjRhQtdzEHauGDgKowUqX,headers=fnLMVJkISrjRhQtdzEHauGDgKowUqX,cookies=fnLMVJkISrjRhQtdzEHauGDgKowUqX,redirects=fnLMVJkISrjRhQtdzEHauGDgKowUqm):
  fnLMVJkISrjRhQtdzEHauGDgKowUPF=fnLMVJkISrjRhQtdzEHauGDgKowUPc.DEFAULT_HEADER
  if headers:fnLMVJkISrjRhQtdzEHauGDgKowUPF.update(headers)
  if jobtype=='Get':
   fnLMVJkISrjRhQtdzEHauGDgKowUPX=requests.get(fnLMVJkISrjRhQtdzEHauGDgKowUPY,params=params,headers=fnLMVJkISrjRhQtdzEHauGDgKowUPF,cookies=cookies,allow_redirects=redirects)
  else:
   fnLMVJkISrjRhQtdzEHauGDgKowUPX=requests.post(fnLMVJkISrjRhQtdzEHauGDgKowUPY,data=payload,params=params,headers=fnLMVJkISrjRhQtdzEHauGDgKowUPF,cookies=cookies,allow_redirects=redirects)
  return fnLMVJkISrjRhQtdzEHauGDgKowUPX
 def Get_DefaultParams_Wavve(fnLMVJkISrjRhQtdzEHauGDgKowUPc):
  fnLMVJkISrjRhQtdzEHauGDgKowUPl={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return fnLMVJkISrjRhQtdzEHauGDgKowUPl
 def Get_DefaultParams_Tving(fnLMVJkISrjRhQtdzEHauGDgKowUPc):
  fnLMVJkISrjRhQtdzEHauGDgKowUPl={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return fnLMVJkISrjRhQtdzEHauGDgKowUPl
 def Get_Now_Datetime(fnLMVJkISrjRhQtdzEHauGDgKowUPc):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(fnLMVJkISrjRhQtdzEHauGDgKowUPc,in_text):
  fnLMVJkISrjRhQtdzEHauGDgKowUPe=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return fnLMVJkISrjRhQtdzEHauGDgKowUPe
 def Get_ChannelList_Wavve(fnLMVJkISrjRhQtdzEHauGDgKowUPc,exceptGroup=[]):
  fnLMVJkISrjRhQtdzEHauGDgKowUPs =[]
  fnLMVJkISrjRhQtdzEHauGDgKowUPT=fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_ChannelImg_Wavve()
  try:
   fnLMVJkISrjRhQtdzEHauGDgKowUPY=fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_WAVVE+'/cf/live/recommend-channels'
   fnLMVJkISrjRhQtdzEHauGDgKowUPl={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUPc.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   fnLMVJkISrjRhQtdzEHauGDgKowUPl.update(fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_DefaultParams_Wavve())
   fnLMVJkISrjRhQtdzEHauGDgKowUPB=fnLMVJkISrjRhQtdzEHauGDgKowUPc.callRequestCookies('Get',fnLMVJkISrjRhQtdzEHauGDgKowUPY,payload=fnLMVJkISrjRhQtdzEHauGDgKowUqX,params=fnLMVJkISrjRhQtdzEHauGDgKowUPl,headers=fnLMVJkISrjRhQtdzEHauGDgKowUqX,cookies=fnLMVJkISrjRhQtdzEHauGDgKowUqX)
   fnLMVJkISrjRhQtdzEHauGDgKowUPi=json.loads(fnLMVJkISrjRhQtdzEHauGDgKowUPB.text)
   if not('celllist' in fnLMVJkISrjRhQtdzEHauGDgKowUPi['cell_toplist']):return fnLMVJkISrjRhQtdzEHauGDgKowUPs
   fnLMVJkISrjRhQtdzEHauGDgKowUPp=fnLMVJkISrjRhQtdzEHauGDgKowUPi['cell_toplist']['celllist']
   for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUPp:
    fnLMVJkISrjRhQtdzEHauGDgKowUPA=fnLMVJkISrjRhQtdzEHauGDgKowUPW['contentid']
    fnLMVJkISrjRhQtdzEHauGDgKowUPO=fnLMVJkISrjRhQtdzEHauGDgKowUPW['title_list'][0]['text']
    if fnLMVJkISrjRhQtdzEHauGDgKowUPA in fnLMVJkISrjRhQtdzEHauGDgKowUPT:
     fnLMVJkISrjRhQtdzEHauGDgKowUPy=fnLMVJkISrjRhQtdzEHauGDgKowUPT[fnLMVJkISrjRhQtdzEHauGDgKowUPA]
    else:
     fnLMVJkISrjRhQtdzEHauGDgKowUPy=''
    fnLMVJkISrjRhQtdzEHauGDgKowUPb=fnLMVJkISrjRhQtdzEHauGDgKowUPc.make_getGenre(fnLMVJkISrjRhQtdzEHauGDgKowUPA,'wavve')
    fnLMVJkISrjRhQtdzEHauGDgKowUCP={'channelid':fnLMVJkISrjRhQtdzEHauGDgKowUPA,'channelnm':fnLMVJkISrjRhQtdzEHauGDgKowUPO,'channelimg':fnLMVJkISrjRhQtdzEHauGDgKowUPc.HTTPTAG+fnLMVJkISrjRhQtdzEHauGDgKowUPy if fnLMVJkISrjRhQtdzEHauGDgKowUPy!='' else '','ott':'wavve','genrenm':fnLMVJkISrjRhQtdzEHauGDgKowUPb}
    if fnLMVJkISrjRhQtdzEHauGDgKowUPb not in exceptGroup:
     fnLMVJkISrjRhQtdzEHauGDgKowUPs.append(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return[]
  return fnLMVJkISrjRhQtdzEHauGDgKowUPs
 def Get_ChannelList_WavveExcept(fnLMVJkISrjRhQtdzEHauGDgKowUPc,exceptGroup=[]):
  fnLMVJkISrjRhQtdzEHauGDgKowUPs=[]
  if exceptGroup==[]:return[]
  try:
   fnLMVJkISrjRhQtdzEHauGDgKowUPY=fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_WAVVE+'/cf/live/recommend-channels'
   for fnLMVJkISrjRhQtdzEHauGDgKowUPW in exceptGroup:
    fnLMVJkISrjRhQtdzEHauGDgKowUPl={'WeekDay':'all','adult':'n','broadcastid':fnLMVJkISrjRhQtdzEHauGDgKowUPW['broadcastid'],'contenttype':'channel','genre':fnLMVJkISrjRhQtdzEHauGDgKowUPW['genre'],'isrecommend':'y','limit':fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUPc.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    fnLMVJkISrjRhQtdzEHauGDgKowUPl.update(fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_DefaultParams_Wavve())
    fnLMVJkISrjRhQtdzEHauGDgKowUPB=fnLMVJkISrjRhQtdzEHauGDgKowUPc.callRequestCookies('Get',fnLMVJkISrjRhQtdzEHauGDgKowUPY,payload=fnLMVJkISrjRhQtdzEHauGDgKowUqX,params=fnLMVJkISrjRhQtdzEHauGDgKowUPl,headers=fnLMVJkISrjRhQtdzEHauGDgKowUqX,cookies=fnLMVJkISrjRhQtdzEHauGDgKowUqX)
    fnLMVJkISrjRhQtdzEHauGDgKowUPi=json.loads(fnLMVJkISrjRhQtdzEHauGDgKowUPB.text)
    if not('celllist' in fnLMVJkISrjRhQtdzEHauGDgKowUPi['cell_toplist']):return fnLMVJkISrjRhQtdzEHauGDgKowUPs
    fnLMVJkISrjRhQtdzEHauGDgKowUPp=fnLMVJkISrjRhQtdzEHauGDgKowUPi['cell_toplist']['celllist']
    for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUPp:
     fnLMVJkISrjRhQtdzEHauGDgKowUPs.append(fnLMVJkISrjRhQtdzEHauGDgKowUPW['contentid'])
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return[]
  return fnLMVJkISrjRhQtdzEHauGDgKowUPs
 def Get_ChannelImg_Wavve(fnLMVJkISrjRhQtdzEHauGDgKowUPc):
  fnLMVJkISrjRhQtdzEHauGDgKowUCN={}
  try:
   fnLMVJkISrjRhQtdzEHauGDgKowUCq=fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_Now_Datetime()
   fnLMVJkISrjRhQtdzEHauGDgKowUCc =fnLMVJkISrjRhQtdzEHauGDgKowUCq+datetime.timedelta(hours=3)
   fnLMVJkISrjRhQtdzEHauGDgKowUPY=fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_WAVVE+'/live/epgs'
   fnLMVJkISrjRhQtdzEHauGDgKowUPl={'limit':fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUPc.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':fnLMVJkISrjRhQtdzEHauGDgKowUCq.strftime('%Y-%m-%d %H:00'),'enddatetime':fnLMVJkISrjRhQtdzEHauGDgKowUCc.strftime('%Y-%m-%d %H:00')}
   fnLMVJkISrjRhQtdzEHauGDgKowUPl.update(fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_DefaultParams_Wavve())
   fnLMVJkISrjRhQtdzEHauGDgKowUPB=fnLMVJkISrjRhQtdzEHauGDgKowUPc.callRequestCookies('Get',fnLMVJkISrjRhQtdzEHauGDgKowUPY,payload=fnLMVJkISrjRhQtdzEHauGDgKowUqX,params=fnLMVJkISrjRhQtdzEHauGDgKowUPl,headers=fnLMVJkISrjRhQtdzEHauGDgKowUqX,cookies=fnLMVJkISrjRhQtdzEHauGDgKowUqX)
   fnLMVJkISrjRhQtdzEHauGDgKowUPi=json.loads(fnLMVJkISrjRhQtdzEHauGDgKowUPB.text)
   fnLMVJkISrjRhQtdzEHauGDgKowUPp=fnLMVJkISrjRhQtdzEHauGDgKowUPi['list']
   for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUPp:
    fnLMVJkISrjRhQtdzEHauGDgKowUCN[fnLMVJkISrjRhQtdzEHauGDgKowUPW['channelid']]=fnLMVJkISrjRhQtdzEHauGDgKowUPW['channelimage']
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
  return fnLMVJkISrjRhQtdzEHauGDgKowUCN
 def Get_ChanneGenrename_Wavve(fnLMVJkISrjRhQtdzEHauGDgKowUPc,fnLMVJkISrjRhQtdzEHauGDgKowUPA):
  try:
   fnLMVJkISrjRhQtdzEHauGDgKowUPY=fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_WAVVE+'/live/channels/'+fnLMVJkISrjRhQtdzEHauGDgKowUPA
   fnLMVJkISrjRhQtdzEHauGDgKowUPl=fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_DefaultParams_Wavve()
   fnLMVJkISrjRhQtdzEHauGDgKowUPB=fnLMVJkISrjRhQtdzEHauGDgKowUPc.callRequestCookies('Get',fnLMVJkISrjRhQtdzEHauGDgKowUPY,payload=fnLMVJkISrjRhQtdzEHauGDgKowUqX,params=fnLMVJkISrjRhQtdzEHauGDgKowUPl,headers=fnLMVJkISrjRhQtdzEHauGDgKowUqX,cookies=fnLMVJkISrjRhQtdzEHauGDgKowUqX)
   fnLMVJkISrjRhQtdzEHauGDgKowUPi=json.loads(fnLMVJkISrjRhQtdzEHauGDgKowUPB.text)
   fnLMVJkISrjRhQtdzEHauGDgKowUCv=fnLMVJkISrjRhQtdzEHauGDgKowUPi['genretext']
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return ''
  return fnLMVJkISrjRhQtdzEHauGDgKowUCv
 def Get_ChannelList_Spotv(fnLMVJkISrjRhQtdzEHauGDgKowUPc,payyn=fnLMVJkISrjRhQtdzEHauGDgKowUqs):
  fnLMVJkISrjRhQtdzEHauGDgKowUPs=[]
  try:
   for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUPq:
    fnLMVJkISrjRhQtdzEHauGDgKowUPA=fnLMVJkISrjRhQtdzEHauGDgKowUPW['videoId']
    fnLMVJkISrjRhQtdzEHauGDgKowUCP={'channelid':fnLMVJkISrjRhQtdzEHauGDgKowUPA,'channelnm':fnLMVJkISrjRhQtdzEHauGDgKowUPW['name'],'channelimg':fnLMVJkISrjRhQtdzEHauGDgKowUPW['logo'],'ott':'spotv','genrenm':fnLMVJkISrjRhQtdzEHauGDgKowUPc.make_getGenre(fnLMVJkISrjRhQtdzEHauGDgKowUPA,'spotv')}
    if payyn==fnLMVJkISrjRhQtdzEHauGDgKowUqs or fnLMVJkISrjRhQtdzEHauGDgKowUPW['free']==fnLMVJkISrjRhQtdzEHauGDgKowUqs:
     fnLMVJkISrjRhQtdzEHauGDgKowUPs.append(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return[]
  return fnLMVJkISrjRhQtdzEHauGDgKowUPs
 def Get_ChannelList_Tving(fnLMVJkISrjRhQtdzEHauGDgKowUPc):
  fnLMVJkISrjRhQtdzEHauGDgKowUPs =[]
  fnLMVJkISrjRhQtdzEHauGDgKowUCm=[]
  try:
   fnLMVJkISrjRhQtdzEHauGDgKowUPY=fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_TVING+'/v2/media/lives'
   fnLMVJkISrjRhQtdzEHauGDgKowUPl={'pageNo':'1','pageSize':fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUPc.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   fnLMVJkISrjRhQtdzEHauGDgKowUPl.update(fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_DefaultParams_Tving())
   fnLMVJkISrjRhQtdzEHauGDgKowUPB=fnLMVJkISrjRhQtdzEHauGDgKowUPc.callRequestCookies('Get',fnLMVJkISrjRhQtdzEHauGDgKowUPY,payload=fnLMVJkISrjRhQtdzEHauGDgKowUqX,params=fnLMVJkISrjRhQtdzEHauGDgKowUPl,headers=fnLMVJkISrjRhQtdzEHauGDgKowUqX,cookies=fnLMVJkISrjRhQtdzEHauGDgKowUqX)
   fnLMVJkISrjRhQtdzEHauGDgKowUPi=json.loads(fnLMVJkISrjRhQtdzEHauGDgKowUPB.text)
   if not('result' in fnLMVJkISrjRhQtdzEHauGDgKowUPi['body']):return fnLMVJkISrjRhQtdzEHauGDgKowUPs
   fnLMVJkISrjRhQtdzEHauGDgKowUPp=fnLMVJkISrjRhQtdzEHauGDgKowUPi['body']['result']
   for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUPp:
    if fnLMVJkISrjRhQtdzEHauGDgKowUPW['live_code']=='C44441':continue 
    fnLMVJkISrjRhQtdzEHauGDgKowUCm.append(fnLMVJkISrjRhQtdzEHauGDgKowUPW['live_code'])
   fnLMVJkISrjRhQtdzEHauGDgKowUPT=fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_ChannelImg_Tving(fnLMVJkISrjRhQtdzEHauGDgKowUCm)
   for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUPp:
    fnLMVJkISrjRhQtdzEHauGDgKowUPA=fnLMVJkISrjRhQtdzEHauGDgKowUPW['live_code']
    if fnLMVJkISrjRhQtdzEHauGDgKowUPA=='C44441':continue 
    fnLMVJkISrjRhQtdzEHauGDgKowUPO=fnLMVJkISrjRhQtdzEHauGDgKowUPW['schedule']['channel']['name']['ko']
    if fnLMVJkISrjRhQtdzEHauGDgKowUPA in fnLMVJkISrjRhQtdzEHauGDgKowUPT:
     fnLMVJkISrjRhQtdzEHauGDgKowUPy=fnLMVJkISrjRhQtdzEHauGDgKowUPT[fnLMVJkISrjRhQtdzEHauGDgKowUPA]
    else:
     fnLMVJkISrjRhQtdzEHauGDgKowUPy=''
    fnLMVJkISrjRhQtdzEHauGDgKowUCP={'channelid':fnLMVJkISrjRhQtdzEHauGDgKowUPA,'channelnm':fnLMVJkISrjRhQtdzEHauGDgKowUPO,'channelimg':fnLMVJkISrjRhQtdzEHauGDgKowUPy,'ott':'tving','genrenm':fnLMVJkISrjRhQtdzEHauGDgKowUPc.make_getGenre(fnLMVJkISrjRhQtdzEHauGDgKowUPA,'tving')}
    fnLMVJkISrjRhQtdzEHauGDgKowUPs.append(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return[]
  return fnLMVJkISrjRhQtdzEHauGDgKowUPs
 def make_EpgDatetime_Tving(fnLMVJkISrjRhQtdzEHauGDgKowUPc,days=2):
  fnLMVJkISrjRhQtdzEHauGDgKowUCF=[]
  fnLMVJkISrjRhQtdzEHauGDgKowUCX=fnLMVJkISrjRhQtdzEHauGDgKowUPc.make_DateList(days=2,dateType='2')
  fnLMVJkISrjRhQtdzEHauGDgKowUCl=fnLMVJkISrjRhQtdzEHauGDgKowUqT(fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUCX:
   for fnLMVJkISrjRhQtdzEHauGDgKowUCx in fnLMVJkISrjRhQtdzEHauGDgKowUqY(8):
    fnLMVJkISrjRhQtdzEHauGDgKowUCP={'ndate':fnLMVJkISrjRhQtdzEHauGDgKowUPW,'starttm':fnLMVJkISrjRhQtdzEHauGDgKowUPN[fnLMVJkISrjRhQtdzEHauGDgKowUCx]['starttm'],'endtm':fnLMVJkISrjRhQtdzEHauGDgKowUPN[fnLMVJkISrjRhQtdzEHauGDgKowUCx]['endtm']}
    fnLMVJkISrjRhQtdzEHauGDgKowUCe=fnLMVJkISrjRhQtdzEHauGDgKowUqT(fnLMVJkISrjRhQtdzEHauGDgKowUPW+fnLMVJkISrjRhQtdzEHauGDgKowUPN[fnLMVJkISrjRhQtdzEHauGDgKowUCx]['starttm'])
    fnLMVJkISrjRhQtdzEHauGDgKowUCs=fnLMVJkISrjRhQtdzEHauGDgKowUqT(fnLMVJkISrjRhQtdzEHauGDgKowUPW+fnLMVJkISrjRhQtdzEHauGDgKowUPN[fnLMVJkISrjRhQtdzEHauGDgKowUCx]['endtm'])
    if fnLMVJkISrjRhQtdzEHauGDgKowUCl<=fnLMVJkISrjRhQtdzEHauGDgKowUCe or(fnLMVJkISrjRhQtdzEHauGDgKowUCe<fnLMVJkISrjRhQtdzEHauGDgKowUCl and fnLMVJkISrjRhQtdzEHauGDgKowUCl<fnLMVJkISrjRhQtdzEHauGDgKowUCs):
     fnLMVJkISrjRhQtdzEHauGDgKowUCF.append(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
  return fnLMVJkISrjRhQtdzEHauGDgKowUCF
 def make_DateList(fnLMVJkISrjRhQtdzEHauGDgKowUPc,days=2,dateType='1'):
  fnLMVJkISrjRhQtdzEHauGDgKowUCX=[]
  fnLMVJkISrjRhQtdzEHauGDgKowUCT =fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_Now_Datetime()
  if dateType=='1':
   fnLMVJkISrjRhQtdzEHauGDgKowUCT=fnLMVJkISrjRhQtdzEHauGDgKowUCT-datetime.timedelta(days=1)
  for i in fnLMVJkISrjRhQtdzEHauGDgKowUqY(days):
   fnLMVJkISrjRhQtdzEHauGDgKowUCY=fnLMVJkISrjRhQtdzEHauGDgKowUCT+datetime.timedelta(days=i)
   if dateType=='1':
    fnLMVJkISrjRhQtdzEHauGDgKowUCX.append(fnLMVJkISrjRhQtdzEHauGDgKowUCY.strftime('%Y%m%d'))
   else:
    fnLMVJkISrjRhQtdzEHauGDgKowUCX.append(fnLMVJkISrjRhQtdzEHauGDgKowUCY.strftime('%Y%m%d'))
  return fnLMVJkISrjRhQtdzEHauGDgKowUCX
 def make_Tving_ChannleGroup(fnLMVJkISrjRhQtdzEHauGDgKowUPc,fnLMVJkISrjRhQtdzEHauGDgKowUCm):
  fnLMVJkISrjRhQtdzEHauGDgKowUCB=[]
  i=0
  fnLMVJkISrjRhQtdzEHauGDgKowUCi=''
  for fnLMVJkISrjRhQtdzEHauGDgKowUCp in fnLMVJkISrjRhQtdzEHauGDgKowUCm:
   if i==0:fnLMVJkISrjRhQtdzEHauGDgKowUCi=fnLMVJkISrjRhQtdzEHauGDgKowUCp
   else:fnLMVJkISrjRhQtdzEHauGDgKowUCi+=',%s'%(fnLMVJkISrjRhQtdzEHauGDgKowUCp)
   i+=1
   if i>=fnLMVJkISrjRhQtdzEHauGDgKowUPc.LIMIT_TVINGEPG:
    fnLMVJkISrjRhQtdzEHauGDgKowUCB.append(fnLMVJkISrjRhQtdzEHauGDgKowUCi)
    i=0
    fnLMVJkISrjRhQtdzEHauGDgKowUCi=''
  if fnLMVJkISrjRhQtdzEHauGDgKowUCi!='':
   fnLMVJkISrjRhQtdzEHauGDgKowUCB.append(fnLMVJkISrjRhQtdzEHauGDgKowUCi)
  return fnLMVJkISrjRhQtdzEHauGDgKowUCB
 def Get_ChannelImg_Tving(fnLMVJkISrjRhQtdzEHauGDgKowUPc,chid_list):
  fnLMVJkISrjRhQtdzEHauGDgKowUCN={}
  try:
   fnLMVJkISrjRhQtdzEHauGDgKowUCW=fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_Now_Datetime().strftime('%Y%m%d')
   fnLMVJkISrjRhQtdzEHauGDgKowUCq =fnLMVJkISrjRhQtdzEHauGDgKowUPN[6]['starttm'] 
   fnLMVJkISrjRhQtdzEHauGDgKowUCc =fnLMVJkISrjRhQtdzEHauGDgKowUPN[6]['endtm']
   fnLMVJkISrjRhQtdzEHauGDgKowUCB=fnLMVJkISrjRhQtdzEHauGDgKowUPc.make_Tving_ChannleGroup(chid_list)
   for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUCB:
    fnLMVJkISrjRhQtdzEHauGDgKowUPY=fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_TVING+'/v2/media/schedules'
    fnLMVJkISrjRhQtdzEHauGDgKowUPl={'pageNo':'1','pageSize':fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUPc.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':fnLMVJkISrjRhQtdzEHauGDgKowUCW,'broadcastDate':fnLMVJkISrjRhQtdzEHauGDgKowUCW,'startBroadTime':fnLMVJkISrjRhQtdzEHauGDgKowUCq,'endBroadTime':fnLMVJkISrjRhQtdzEHauGDgKowUCc,'channelCode':fnLMVJkISrjRhQtdzEHauGDgKowUPW}
    fnLMVJkISrjRhQtdzEHauGDgKowUPl.update(fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_DefaultParams_Tving())
    fnLMVJkISrjRhQtdzEHauGDgKowUPB=fnLMVJkISrjRhQtdzEHauGDgKowUPc.callRequestCookies('Get',fnLMVJkISrjRhQtdzEHauGDgKowUPY,payload=fnLMVJkISrjRhQtdzEHauGDgKowUqX,params=fnLMVJkISrjRhQtdzEHauGDgKowUPl,headers=fnLMVJkISrjRhQtdzEHauGDgKowUqX,cookies=fnLMVJkISrjRhQtdzEHauGDgKowUqX)
    fnLMVJkISrjRhQtdzEHauGDgKowUPi=json.loads(fnLMVJkISrjRhQtdzEHauGDgKowUPB.text)
    if not('result' in fnLMVJkISrjRhQtdzEHauGDgKowUPi['body']):return{}
    fnLMVJkISrjRhQtdzEHauGDgKowUPp=fnLMVJkISrjRhQtdzEHauGDgKowUPi['body']['result']
    for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUPp:
     for fnLMVJkISrjRhQtdzEHauGDgKowUCA in fnLMVJkISrjRhQtdzEHauGDgKowUPW['image']:
      if fnLMVJkISrjRhQtdzEHauGDgKowUCA['code']=='CAIC0400':fnLMVJkISrjRhQtdzEHauGDgKowUCN[fnLMVJkISrjRhQtdzEHauGDgKowUPW['channel_code']]=fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_TVINGIMG+fnLMVJkISrjRhQtdzEHauGDgKowUCA['url']
      elif fnLMVJkISrjRhQtdzEHauGDgKowUCA['code']=='CAIC1400':fnLMVJkISrjRhQtdzEHauGDgKowUCN[fnLMVJkISrjRhQtdzEHauGDgKowUPW['channel_code']]=fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_TVINGIMG+fnLMVJkISrjRhQtdzEHauGDgKowUCA['url']
      elif fnLMVJkISrjRhQtdzEHauGDgKowUCA['code']=='CAIC1900':fnLMVJkISrjRhQtdzEHauGDgKowUCN[fnLMVJkISrjRhQtdzEHauGDgKowUPW['channel_code']]=fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_TVINGIMG+fnLMVJkISrjRhQtdzEHauGDgKowUCA['url']
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return{}
  return fnLMVJkISrjRhQtdzEHauGDgKowUCN
 def Get_EpgInfo_Spotv(fnLMVJkISrjRhQtdzEHauGDgKowUPc,days=3,payyn=fnLMVJkISrjRhQtdzEHauGDgKowUqs):
  fnLMVJkISrjRhQtdzEHauGDgKowUPs=[]
  fnLMVJkISrjRhQtdzEHauGDgKowUCO =[]
  try:
   for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUPq:
    fnLMVJkISrjRhQtdzEHauGDgKowUPA =fnLMVJkISrjRhQtdzEHauGDgKowUPW['videoId']
    fnLMVJkISrjRhQtdzEHauGDgKowUCP={'channelid':fnLMVJkISrjRhQtdzEHauGDgKowUPA,'channelnm':fnLMVJkISrjRhQtdzEHauGDgKowUPc.xmlText(fnLMVJkISrjRhQtdzEHauGDgKowUPW['name']),'channelimg':fnLMVJkISrjRhQtdzEHauGDgKowUPW['logo'],'ott':'spotv','epgtype':fnLMVJkISrjRhQtdzEHauGDgKowUPW['epgtype'],'epgnm':fnLMVJkISrjRhQtdzEHauGDgKowUPW['epgnm']}
    if payyn==fnLMVJkISrjRhQtdzEHauGDgKowUqs or fnLMVJkISrjRhQtdzEHauGDgKowUPW['free']==fnLMVJkISrjRhQtdzEHauGDgKowUqs:
     fnLMVJkISrjRhQtdzEHauGDgKowUPs.append(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return[],[]
  '''
  try:
   for now_day in days_list:
    url = self.API_SPOTV + '/api/v2/program/' + now_day
    response = self.callRequestCookies('Get', url, payload=None, params=None, headers=None, cookies=None )
    res_json = json.loads(response.text )
    for i_section in res_json:
     if find_list.get(i_section['channelId'] ) == None: continue
     temp_list = {'channelid' : find_list.get(i_section['channelId'] ) , 'title' : self.xmlText(i_section['title'] ) , 'startTime' : i_section['startTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'endTime' : i_section['endTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'ott' : 'spotv' }
     epg_list.append(temp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  try:
   for fnLMVJkISrjRhQtdzEHauGDgKowUCy in fnLMVJkISrjRhQtdzEHauGDgKowUPs:
    if fnLMVJkISrjRhQtdzEHauGDgKowUCy['epgtype']=='spotvon':
     fnLMVJkISrjRhQtdzEHauGDgKowUCb=fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_EpgInfo_Spotv_spotvon(fnLMVJkISrjRhQtdzEHauGDgKowUCy['channelid'],fnLMVJkISrjRhQtdzEHauGDgKowUCy['epgnm'],days)
     if fnLMVJkISrjRhQtdzEHauGDgKowUqB(fnLMVJkISrjRhQtdzEHauGDgKowUCb)>0:fnLMVJkISrjRhQtdzEHauGDgKowUCO.extend(fnLMVJkISrjRhQtdzEHauGDgKowUCb)
    if fnLMVJkISrjRhQtdzEHauGDgKowUCy['epgtype']=='spotvnet':
     fnLMVJkISrjRhQtdzEHauGDgKowUCb=fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_EpgInfo_Spotv_spotvnet(fnLMVJkISrjRhQtdzEHauGDgKowUCy['channelid'],fnLMVJkISrjRhQtdzEHauGDgKowUCy['epgnm'],days)
     if fnLMVJkISrjRhQtdzEHauGDgKowUqB(fnLMVJkISrjRhQtdzEHauGDgKowUCb)>0:fnLMVJkISrjRhQtdzEHauGDgKowUCO.extend(fnLMVJkISrjRhQtdzEHauGDgKowUCb)
    time.sleep(fnLMVJkISrjRhQtdzEHauGDgKowUPc.SLEEP_TIME)
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return[],[]
  return fnLMVJkISrjRhQtdzEHauGDgKowUPs,fnLMVJkISrjRhQtdzEHauGDgKowUCO
 def Get_EpgInfo_Spotv_spotvon(fnLMVJkISrjRhQtdzEHauGDgKowUPc,fnLMVJkISrjRhQtdzEHauGDgKowUPA,epgnm,days):
  fnLMVJkISrjRhQtdzEHauGDgKowUCO =[]
  fnLMVJkISrjRhQtdzEHauGDgKowUCX=fnLMVJkISrjRhQtdzEHauGDgKowUPc.make_DateList(days=days,dateType='1')
  fnLMVJkISrjRhQtdzEHauGDgKowUNP=''
  try:
   for fnLMVJkISrjRhQtdzEHauGDgKowUNC in fnLMVJkISrjRhQtdzEHauGDgKowUCX:
    fnLMVJkISrjRhQtdzEHauGDgKowUPY='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,fnLMVJkISrjRhQtdzEHauGDgKowUNC)
    fnLMVJkISrjRhQtdzEHauGDgKowUPB=fnLMVJkISrjRhQtdzEHauGDgKowUPc.callRequestCookies('Get',fnLMVJkISrjRhQtdzEHauGDgKowUPY,payload=fnLMVJkISrjRhQtdzEHauGDgKowUqX,params=fnLMVJkISrjRhQtdzEHauGDgKowUqX,headers=fnLMVJkISrjRhQtdzEHauGDgKowUqX,cookies=fnLMVJkISrjRhQtdzEHauGDgKowUqX)
    fnLMVJkISrjRhQtdzEHauGDgKowUPi=json.loads(fnLMVJkISrjRhQtdzEHauGDgKowUPB.text)
    for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUPi:
     fnLMVJkISrjRhQtdzEHauGDgKowUCP={'channelid':fnLMVJkISrjRhQtdzEHauGDgKowUPA,'title':fnLMVJkISrjRhQtdzEHauGDgKowUPc.xmlText(fnLMVJkISrjRhQtdzEHauGDgKowUPW['title']),'startTime':fnLMVJkISrjRhQtdzEHauGDgKowUPW['sch_date'].replace('-','')+fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUPW['sch_hour']).zfill(2)+fnLMVJkISrjRhQtdzEHauGDgKowUPW['sch_min']+'00','ott':'spotv'}
     fnLMVJkISrjRhQtdzEHauGDgKowUCO.append(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
    fnLMVJkISrjRhQtdzEHauGDgKowUNP=fnLMVJkISrjRhQtdzEHauGDgKowUNC
   for i in fnLMVJkISrjRhQtdzEHauGDgKowUqY(fnLMVJkISrjRhQtdzEHauGDgKowUqB(fnLMVJkISrjRhQtdzEHauGDgKowUCO)):
    if i>0:fnLMVJkISrjRhQtdzEHauGDgKowUCO[i-1]['endTime']=fnLMVJkISrjRhQtdzEHauGDgKowUCO[i]['startTime']
    if i==fnLMVJkISrjRhQtdzEHauGDgKowUqB(fnLMVJkISrjRhQtdzEHauGDgKowUCO)-1: fnLMVJkISrjRhQtdzEHauGDgKowUCO[i]['endTime']=fnLMVJkISrjRhQtdzEHauGDgKowUNP+'240000'
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return[]
  return fnLMVJkISrjRhQtdzEHauGDgKowUCO
 def Get_EpgInfo_Spotv_spotvnet(fnLMVJkISrjRhQtdzEHauGDgKowUPc,fnLMVJkISrjRhQtdzEHauGDgKowUPA,epgnm,days):
  fnLMVJkISrjRhQtdzEHauGDgKowUCO =[]
  fnLMVJkISrjRhQtdzEHauGDgKowUCX=fnLMVJkISrjRhQtdzEHauGDgKowUPc.make_DateList(days=days,dateType='1')
  fnLMVJkISrjRhQtdzEHauGDgKowUNP=''
  try:
   for fnLMVJkISrjRhQtdzEHauGDgKowUNC in fnLMVJkISrjRhQtdzEHauGDgKowUCX:
    fnLMVJkISrjRhQtdzEHauGDgKowUPY='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,fnLMVJkISrjRhQtdzEHauGDgKowUNC)
    fnLMVJkISrjRhQtdzEHauGDgKowUPB=fnLMVJkISrjRhQtdzEHauGDgKowUPc.callRequestCookies('Get',fnLMVJkISrjRhQtdzEHauGDgKowUPY,payload=fnLMVJkISrjRhQtdzEHauGDgKowUqX,params=fnLMVJkISrjRhQtdzEHauGDgKowUqX,headers=fnLMVJkISrjRhQtdzEHauGDgKowUqX,cookies=fnLMVJkISrjRhQtdzEHauGDgKowUqX)
    fnLMVJkISrjRhQtdzEHauGDgKowUPi=json.loads(fnLMVJkISrjRhQtdzEHauGDgKowUPB.text)
    for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUPi:
     fnLMVJkISrjRhQtdzEHauGDgKowUCP={'channelid':fnLMVJkISrjRhQtdzEHauGDgKowUPA,'title':fnLMVJkISrjRhQtdzEHauGDgKowUPc.xmlText(fnLMVJkISrjRhQtdzEHauGDgKowUPW['title']),'startTime':fnLMVJkISrjRhQtdzEHauGDgKowUPW['sch_date'].replace('-','')+fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUPW['sch_hour']).zfill(2)+fnLMVJkISrjRhQtdzEHauGDgKowUPW['sch_min']+'00','ott':'spotv'}
     fnLMVJkISrjRhQtdzEHauGDgKowUCO.append(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
    fnLMVJkISrjRhQtdzEHauGDgKowUNP=fnLMVJkISrjRhQtdzEHauGDgKowUNC
   for i in fnLMVJkISrjRhQtdzEHauGDgKowUqY(fnLMVJkISrjRhQtdzEHauGDgKowUqB(fnLMVJkISrjRhQtdzEHauGDgKowUCO)):
    if i>0:fnLMVJkISrjRhQtdzEHauGDgKowUCO[i-1]['endTime']=fnLMVJkISrjRhQtdzEHauGDgKowUCO[i]['startTime']
    if i==fnLMVJkISrjRhQtdzEHauGDgKowUqB(fnLMVJkISrjRhQtdzEHauGDgKowUCO)-1: fnLMVJkISrjRhQtdzEHauGDgKowUCO[i]['endTime']=fnLMVJkISrjRhQtdzEHauGDgKowUNP+'240000'
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return[]
  return fnLMVJkISrjRhQtdzEHauGDgKowUCO
 def Get_EpgInfo_Wavve(fnLMVJkISrjRhQtdzEHauGDgKowUPc,days=2,exceptGroup=[]):
  fnLMVJkISrjRhQtdzEHauGDgKowUPs =[]
  fnLMVJkISrjRhQtdzEHauGDgKowUCO =[]
  fnLMVJkISrjRhQtdzEHauGDgKowUCT =fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_Now_Datetime()
  fnLMVJkISrjRhQtdzEHauGDgKowUNq =fnLMVJkISrjRhQtdzEHauGDgKowUCT+datetime.timedelta(hours=-2)
  fnLMVJkISrjRhQtdzEHauGDgKowUNc =fnLMVJkISrjRhQtdzEHauGDgKowUCT+datetime.timedelta(days=(days-1))
  if fnLMVJkISrjRhQtdzEHauGDgKowUqT(fnLMVJkISrjRhQtdzEHauGDgKowUNq.strftime('%H'))<=3:
   fnLMVJkISrjRhQtdzEHauGDgKowUNv=fnLMVJkISrjRhQtdzEHauGDgKowUNq.strftime('%Y-%m-%d 00:00')
  else:
   fnLMVJkISrjRhQtdzEHauGDgKowUNv=fnLMVJkISrjRhQtdzEHauGDgKowUNq.strftime('%Y-%m-%d %H:00')
  fnLMVJkISrjRhQtdzEHauGDgKowUNm =fnLMVJkISrjRhQtdzEHauGDgKowUNc.strftime('%Y-%m-%d 24:00')
  try:
   fnLMVJkISrjRhQtdzEHauGDgKowUPY=fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_WAVVE+'/live/epgs'
   fnLMVJkISrjRhQtdzEHauGDgKowUPl={'limit':fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUPc.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':fnLMVJkISrjRhQtdzEHauGDgKowUNv,'enddatetime':fnLMVJkISrjRhQtdzEHauGDgKowUNm}
   fnLMVJkISrjRhQtdzEHauGDgKowUPl.update(fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_DefaultParams_Wavve())
   fnLMVJkISrjRhQtdzEHauGDgKowUPB=fnLMVJkISrjRhQtdzEHauGDgKowUPc.callRequestCookies('Get',fnLMVJkISrjRhQtdzEHauGDgKowUPY,payload=fnLMVJkISrjRhQtdzEHauGDgKowUqX,params=fnLMVJkISrjRhQtdzEHauGDgKowUPl,headers=fnLMVJkISrjRhQtdzEHauGDgKowUqX,cookies=fnLMVJkISrjRhQtdzEHauGDgKowUqX)
   fnLMVJkISrjRhQtdzEHauGDgKowUPi=json.loads(fnLMVJkISrjRhQtdzEHauGDgKowUPB.text)
   fnLMVJkISrjRhQtdzEHauGDgKowUNF=fnLMVJkISrjRhQtdzEHauGDgKowUPi['list']
   for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUNF:
    fnLMVJkISrjRhQtdzEHauGDgKowUPA =fnLMVJkISrjRhQtdzEHauGDgKowUPW['channelid']
    fnLMVJkISrjRhQtdzEHauGDgKowUPb=fnLMVJkISrjRhQtdzEHauGDgKowUPc.make_getGenre(fnLMVJkISrjRhQtdzEHauGDgKowUPA,'wavve')
    fnLMVJkISrjRhQtdzEHauGDgKowUCP={'channelid':fnLMVJkISrjRhQtdzEHauGDgKowUPA,'channelnm':fnLMVJkISrjRhQtdzEHauGDgKowUPc.xmlText(fnLMVJkISrjRhQtdzEHauGDgKowUPW['channelname']),'channelimg':fnLMVJkISrjRhQtdzEHauGDgKowUPc.HTTPTAG+fnLMVJkISrjRhQtdzEHauGDgKowUPW['channelimage'],'ott':'wavve'}
    if fnLMVJkISrjRhQtdzEHauGDgKowUPb not in exceptGroup:
     fnLMVJkISrjRhQtdzEHauGDgKowUPs.append(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
    for fnLMVJkISrjRhQtdzEHauGDgKowUNX in fnLMVJkISrjRhQtdzEHauGDgKowUPW['list']:
     fnLMVJkISrjRhQtdzEHauGDgKowUCP={'channelid':fnLMVJkISrjRhQtdzEHauGDgKowUPW['channelid'],'title':fnLMVJkISrjRhQtdzEHauGDgKowUPc.xmlText(fnLMVJkISrjRhQtdzEHauGDgKowUNX['title']),'startTime':fnLMVJkISrjRhQtdzEHauGDgKowUNX['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':fnLMVJkISrjRhQtdzEHauGDgKowUNX['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if fnLMVJkISrjRhQtdzEHauGDgKowUPb not in exceptGroup and fnLMVJkISrjRhQtdzEHauGDgKowUNX['starttime']!=fnLMVJkISrjRhQtdzEHauGDgKowUNX['endtime']:
      fnLMVJkISrjRhQtdzEHauGDgKowUCO.append(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return[],[]
  fnLMVJkISrjRhQtdzEHauGDgKowUNl=fnLMVJkISrjRhQtdzEHauGDgKowUqB(fnLMVJkISrjRhQtdzEHauGDgKowUCO)
  for i in(fnLMVJkISrjRhQtdzEHauGDgKowUqY(1,fnLMVJkISrjRhQtdzEHauGDgKowUNl)):
   if fnLMVJkISrjRhQtdzEHauGDgKowUqT(fnLMVJkISrjRhQtdzEHauGDgKowUCO[i-1]['endTime'])+1==fnLMVJkISrjRhQtdzEHauGDgKowUqT(fnLMVJkISrjRhQtdzEHauGDgKowUCO[i]['startTime'])and fnLMVJkISrjRhQtdzEHauGDgKowUCO[i-1]['channelid']==fnLMVJkISrjRhQtdzEHauGDgKowUCO[i]['channelid']:
    fnLMVJkISrjRhQtdzEHauGDgKowUCO[i-1]['endTime']=fnLMVJkISrjRhQtdzEHauGDgKowUCO[i]['startTime']
  return fnLMVJkISrjRhQtdzEHauGDgKowUPs,fnLMVJkISrjRhQtdzEHauGDgKowUCO
 def Get_EpgInfo_Tving(fnLMVJkISrjRhQtdzEHauGDgKowUPc,days=2):
  fnLMVJkISrjRhQtdzEHauGDgKowUPs=[]
  fnLMVJkISrjRhQtdzEHauGDgKowUCO =[]
  fnLMVJkISrjRhQtdzEHauGDgKowUNx =[]
  fnLMVJkISrjRhQtdzEHauGDgKowUNe =fnLMVJkISrjRhQtdzEHauGDgKowUPc.make_EpgDatetime_Tving(days=days)
  fnLMVJkISrjRhQtdzEHauGDgKowUPs =fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_ChannelList_Tving()
  fnLMVJkISrjRhQtdzEHauGDgKowUNs=[]
  for i in fnLMVJkISrjRhQtdzEHauGDgKowUqY(fnLMVJkISrjRhQtdzEHauGDgKowUqB(fnLMVJkISrjRhQtdzEHauGDgKowUPs)):
   fnLMVJkISrjRhQtdzEHauGDgKowUPs[i]['channelnm']=fnLMVJkISrjRhQtdzEHauGDgKowUPc.xmlText(fnLMVJkISrjRhQtdzEHauGDgKowUPs[i]['channelnm'])
   fnLMVJkISrjRhQtdzEHauGDgKowUNs.append(fnLMVJkISrjRhQtdzEHauGDgKowUPs[i]['channelid'])
  fnLMVJkISrjRhQtdzEHauGDgKowUNT=fnLMVJkISrjRhQtdzEHauGDgKowUPc.make_Tving_ChannleGroup(fnLMVJkISrjRhQtdzEHauGDgKowUNs)
  try:
   fnLMVJkISrjRhQtdzEHauGDgKowUPY=fnLMVJkISrjRhQtdzEHauGDgKowUPc.API_TVING+'/v2/media/schedules'
   for fnLMVJkISrjRhQtdzEHauGDgKowUNY in fnLMVJkISrjRhQtdzEHauGDgKowUNe:
    for fnLMVJkISrjRhQtdzEHauGDgKowUCy in fnLMVJkISrjRhQtdzEHauGDgKowUNT:
     fnLMVJkISrjRhQtdzEHauGDgKowUPl={'pageNo':'1','pageSize':fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUPc.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':fnLMVJkISrjRhQtdzEHauGDgKowUNY['ndate'],'broadcastDate':fnLMVJkISrjRhQtdzEHauGDgKowUNY['ndate'],'startBroadTime':fnLMVJkISrjRhQtdzEHauGDgKowUNY['starttm'],'endBroadTime':fnLMVJkISrjRhQtdzEHauGDgKowUNY['endtm'],'channelCode':fnLMVJkISrjRhQtdzEHauGDgKowUCy}
     fnLMVJkISrjRhQtdzEHauGDgKowUPl.update(fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_DefaultParams_Tving())
     fnLMVJkISrjRhQtdzEHauGDgKowUPB=fnLMVJkISrjRhQtdzEHauGDgKowUPc.callRequestCookies('Get',fnLMVJkISrjRhQtdzEHauGDgKowUPY,payload=fnLMVJkISrjRhQtdzEHauGDgKowUqX,params=fnLMVJkISrjRhQtdzEHauGDgKowUPl,headers=fnLMVJkISrjRhQtdzEHauGDgKowUqX,cookies=fnLMVJkISrjRhQtdzEHauGDgKowUqX)
     fnLMVJkISrjRhQtdzEHauGDgKowUPi=json.loads(fnLMVJkISrjRhQtdzEHauGDgKowUPB.text)
     fnLMVJkISrjRhQtdzEHauGDgKowUPp=fnLMVJkISrjRhQtdzEHauGDgKowUPi['body']['result']
     for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUPp:
      if 'schedules' not in fnLMVJkISrjRhQtdzEHauGDgKowUPW:continue
      if fnLMVJkISrjRhQtdzEHauGDgKowUPW['schedules']==fnLMVJkISrjRhQtdzEHauGDgKowUqX:continue
      for fnLMVJkISrjRhQtdzEHauGDgKowUNB in fnLMVJkISrjRhQtdzEHauGDgKowUPW['schedules']:
       fnLMVJkISrjRhQtdzEHauGDgKowUCP={'channelid':fnLMVJkISrjRhQtdzEHauGDgKowUNB['schedule_code'],'title':fnLMVJkISrjRhQtdzEHauGDgKowUPc.xmlText(fnLMVJkISrjRhQtdzEHauGDgKowUNB['program']['name']['ko']),'startTime':fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUNB['broadcast_start_time']),'endTime':fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUNB['broadcast_end_time']),'ott':'tving'}
       fnLMVJkISrjRhQtdzEHauGDgKowUNi=fnLMVJkISrjRhQtdzEHauGDgKowUNB['schedule_code']+fnLMVJkISrjRhQtdzEHauGDgKowUql(fnLMVJkISrjRhQtdzEHauGDgKowUNB['broadcast_start_time'])
       if fnLMVJkISrjRhQtdzEHauGDgKowUNi in fnLMVJkISrjRhQtdzEHauGDgKowUNx:continue
       fnLMVJkISrjRhQtdzEHauGDgKowUNx.append(fnLMVJkISrjRhQtdzEHauGDgKowUNi)
       fnLMVJkISrjRhQtdzEHauGDgKowUCO.append(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
     time.sleep(fnLMVJkISrjRhQtdzEHauGDgKowUPc.SLEEP_TIME)
  except fnLMVJkISrjRhQtdzEHauGDgKowUqx as exception:
   fnLMVJkISrjRhQtdzEHauGDgKowUqe(exception)
   return[],[]
  return fnLMVJkISrjRhQtdzEHauGDgKowUPs,fnLMVJkISrjRhQtdzEHauGDgKowUCO
 def make_getGenre(fnLMVJkISrjRhQtdzEHauGDgKowUPc,fnLMVJkISrjRhQtdzEHauGDgKowUPA,fnLMVJkISrjRhQtdzEHauGDgKowUqN):
  try:
   fnLMVJkISrjRhQtdzEHauGDgKowUCv=fnLMVJkISrjRhQtdzEHauGDgKowUPc.INIT_CHANNEL.get(fnLMVJkISrjRhQtdzEHauGDgKowUPA+'.'+fnLMVJkISrjRhQtdzEHauGDgKowUqN).get('genre')
  except:
   fnLMVJkISrjRhQtdzEHauGDgKowUCv='-'
  return fnLMVJkISrjRhQtdzEHauGDgKowUCv
 def make_base_allchannel_py(fnLMVJkISrjRhQtdzEHauGDgKowUPc):
  fnLMVJkISrjRhQtdzEHauGDgKowUNp =[]
  fnLMVJkISrjRhQtdzEHauGDgKowUNW=[]
  fnLMVJkISrjRhQtdzEHauGDgKowUNA=fnLMVJkISrjRhQtdzEHauGDgKowUqi()
  fnLMVJkISrjRhQtdzEHauGDgKowUCP=fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_ChannelList_Wavve()
  fnLMVJkISrjRhQtdzEHauGDgKowUNp.extend(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
  fnLMVJkISrjRhQtdzEHauGDgKowUCP=fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_ChannelList_Tving()
  fnLMVJkISrjRhQtdzEHauGDgKowUNp.extend(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
  fnLMVJkISrjRhQtdzEHauGDgKowUCP=fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_ChannelList_Spotv()
  fnLMVJkISrjRhQtdzEHauGDgKowUNp.extend(fnLMVJkISrjRhQtdzEHauGDgKowUCP)
  fnLMVJkISrjRhQtdzEHauGDgKowUqe('1')
  for i in fnLMVJkISrjRhQtdzEHauGDgKowUqY(fnLMVJkISrjRhQtdzEHauGDgKowUqB(fnLMVJkISrjRhQtdzEHauGDgKowUNp)):
   if fnLMVJkISrjRhQtdzEHauGDgKowUNp[i]['genrenm']=='-':
    if fnLMVJkISrjRhQtdzEHauGDgKowUNp[i]['ott']=='wavve':
     fnLMVJkISrjRhQtdzEHauGDgKowUCv=fnLMVJkISrjRhQtdzEHauGDgKowUPc.Get_ChanneGenrename_Wavve(fnLMVJkISrjRhQtdzEHauGDgKowUNp[i]['channelid'])
     if fnLMVJkISrjRhQtdzEHauGDgKowUCv not in fnLMVJkISrjRhQtdzEHauGDgKowUNA:fnLMVJkISrjRhQtdzEHauGDgKowUNA.add(fnLMVJkISrjRhQtdzEHauGDgKowUCv)
     time.sleep(fnLMVJkISrjRhQtdzEHauGDgKowUPc.SLEEP_TIME)
    elif fnLMVJkISrjRhQtdzEHauGDgKowUNp[i]['ott']=='spotv':
     fnLMVJkISrjRhQtdzEHauGDgKowUCv='스포츠'
    else:
     fnLMVJkISrjRhQtdzEHauGDgKowUCv='-'
    fnLMVJkISrjRhQtdzEHauGDgKowUNp[i]['genrenm']=fnLMVJkISrjRhQtdzEHauGDgKowUCv
   else:
    if fnLMVJkISrjRhQtdzEHauGDgKowUNp[i]['genrenm']not in fnLMVJkISrjRhQtdzEHauGDgKowUNA:fnLMVJkISrjRhQtdzEHauGDgKowUNA.add(fnLMVJkISrjRhQtdzEHauGDgKowUNp[i]['genrenm'])
  fnLMVJkISrjRhQtdzEHauGDgKowUNA.add('-')
  fnLMVJkISrjRhQtdzEHauGDgKowUqe('2')
  for fnLMVJkISrjRhQtdzEHauGDgKowUNO in fnLMVJkISrjRhQtdzEHauGDgKowUNA:
   for fnLMVJkISrjRhQtdzEHauGDgKowUNy in fnLMVJkISrjRhQtdzEHauGDgKowUNp:
    if fnLMVJkISrjRhQtdzEHauGDgKowUNy['genrenm']==fnLMVJkISrjRhQtdzEHauGDgKowUNO:
     fnLMVJkISrjRhQtdzEHauGDgKowUNW.append(fnLMVJkISrjRhQtdzEHauGDgKowUNy)
  for fnLMVJkISrjRhQtdzEHauGDgKowUNy in fnLMVJkISrjRhQtdzEHauGDgKowUNp:
   if fnLMVJkISrjRhQtdzEHauGDgKowUNy['genrenm']not in fnLMVJkISrjRhQtdzEHauGDgKowUNA:
    fnLMVJkISrjRhQtdzEHauGDgKowUNb.append(fnLMVJkISrjRhQtdzEHauGDgKowUNy)
  fnLMVJkISrjRhQtdzEHauGDgKowUqe('3')
  fnLMVJkISrjRhQtdzEHauGDgKowUqP='d:\\job\\channelgenre.json'
  if os.path.isfile(fnLMVJkISrjRhQtdzEHauGDgKowUqP):os.remove(fnLMVJkISrjRhQtdzEHauGDgKowUqP)
  fp=fnLMVJkISrjRhQtdzEHauGDgKowUqp(fnLMVJkISrjRhQtdzEHauGDgKowUqP,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  fnLMVJkISrjRhQtdzEHauGDgKowUqC=fnLMVJkISrjRhQtdzEHauGDgKowUqB(fnLMVJkISrjRhQtdzEHauGDgKowUNW)
  i=0
  for fnLMVJkISrjRhQtdzEHauGDgKowUPW in fnLMVJkISrjRhQtdzEHauGDgKowUNW:
   i+=1
   fnLMVJkISrjRhQtdzEHauGDgKowUPA =fnLMVJkISrjRhQtdzEHauGDgKowUPW['channelid']
   fnLMVJkISrjRhQtdzEHauGDgKowUPO =fnLMVJkISrjRhQtdzEHauGDgKowUPW['channelnm']
   fnLMVJkISrjRhQtdzEHauGDgKowUqN =fnLMVJkISrjRhQtdzEHauGDgKowUPW['ott']
   fnLMVJkISrjRhQtdzEHauGDgKowUqc ='%s.%s'%(fnLMVJkISrjRhQtdzEHauGDgKowUPA,fnLMVJkISrjRhQtdzEHauGDgKowUqN)
   fnLMVJkISrjRhQtdzEHauGDgKowUCv =fnLMVJkISrjRhQtdzEHauGDgKowUPW['genrenm']
   fnLMVJkISrjRhQtdzEHauGDgKowUqv='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(fnLMVJkISrjRhQtdzEHauGDgKowUqc,fnLMVJkISrjRhQtdzEHauGDgKowUPO,fnLMVJkISrjRhQtdzEHauGDgKowUCv)
   if i<fnLMVJkISrjRhQtdzEHauGDgKowUqC:
    fp.write(fnLMVJkISrjRhQtdzEHauGDgKowUqv+',\n')
   else:
    fp.write(fnLMVJkISrjRhQtdzEHauGDgKowUqv+'\n')
  fp.write('}\n')
  fp.close()
  return fnLMVJkISrjRhQtdzEHauGDgKowUNA
# Created by pyminifier (https://github.com/liftoff/pyminifier)
