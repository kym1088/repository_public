__author__="NightRain"
hnrYWiGuzkvSUETALoXJDlxwKMefdN=object
hnrYWiGuzkvSUETALoXJDlxwKMefdm=False
hnrYWiGuzkvSUETALoXJDlxwKMefdO=None
hnrYWiGuzkvSUETALoXJDlxwKMefdI=True
hnrYWiGuzkvSUETALoXJDlxwKMefdy=len
hnrYWiGuzkvSUETALoXJDlxwKMefdV=str
hnrYWiGuzkvSUETALoXJDlxwKMefBq=open
hnrYWiGuzkvSUETALoXJDlxwKMefBb=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
hnrYWiGuzkvSUETALoXJDlxwKMefqd=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
hnrYWiGuzkvSUETALoXJDlxwKMefqB=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class hnrYWiGuzkvSUETALoXJDlxwKMefqb(hnrYWiGuzkvSUETALoXJDlxwKMefdN):
 def __init__(hnrYWiGuzkvSUETALoXJDlxwKMefqc,hnrYWiGuzkvSUETALoXJDlxwKMefqH,hnrYWiGuzkvSUETALoXJDlxwKMefqC,hnrYWiGuzkvSUETALoXJDlxwKMefqt):
  hnrYWiGuzkvSUETALoXJDlxwKMefqc._addon_url =hnrYWiGuzkvSUETALoXJDlxwKMefqH
  hnrYWiGuzkvSUETALoXJDlxwKMefqc._addon_handle =hnrYWiGuzkvSUETALoXJDlxwKMefqC
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.main_params =hnrYWiGuzkvSUETALoXJDlxwKMefqt
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_FILE_PATH ='' 
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_FILE_NAME ='' 
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVE =hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONTVING =hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONSPOTV =hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVERADIO=hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVEHOME =hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONRELIGION =hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONSPOTVPAY =hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_DISPLAYNM =hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_AUTORESTART =hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.BoritvObj =fnLMVJkISrjRhQtdzEHauGDgKowUPC() 
 def addon_noti(hnrYWiGuzkvSUETALoXJDlxwKMefqc,sting):
  try:
   hnrYWiGuzkvSUETALoXJDlxwKMefqR=xbmcgui.Dialog()
   hnrYWiGuzkvSUETALoXJDlxwKMefqR.notification(__addonname__,sting)
  except:
   hnrYWiGuzkvSUETALoXJDlxwKMefdO
 def addon_log(hnrYWiGuzkvSUETALoXJDlxwKMefqc,string):
  try:
   hnrYWiGuzkvSUETALoXJDlxwKMefqa=string.encode('utf-8','ignore')
  except:
   hnrYWiGuzkvSUETALoXJDlxwKMefqa='addonException: addon_log'
  hnrYWiGuzkvSUETALoXJDlxwKMefqp=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,hnrYWiGuzkvSUETALoXJDlxwKMefqa),level=hnrYWiGuzkvSUETALoXJDlxwKMefqp)
 def get_keyboard_input(hnrYWiGuzkvSUETALoXJDlxwKMefqc,hnrYWiGuzkvSUETALoXJDlxwKMefqs):
  hnrYWiGuzkvSUETALoXJDlxwKMefqP=hnrYWiGuzkvSUETALoXJDlxwKMefdO
  kb=xbmc.Keyboard()
  kb.setHeading(hnrYWiGuzkvSUETALoXJDlxwKMefqs)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   hnrYWiGuzkvSUETALoXJDlxwKMefqP=kb.getText()
  return hnrYWiGuzkvSUETALoXJDlxwKMefqP
 def add_dir(hnrYWiGuzkvSUETALoXJDlxwKMefqc,label,sublabel='',img='',infoLabels=hnrYWiGuzkvSUETALoXJDlxwKMefdO,isFolder=hnrYWiGuzkvSUETALoXJDlxwKMefdI,params=''):
  hnrYWiGuzkvSUETALoXJDlxwKMefqj='%s?%s'%(hnrYWiGuzkvSUETALoXJDlxwKMefqc._addon_url,urllib.parse.urlencode(params))
  if sublabel:hnrYWiGuzkvSUETALoXJDlxwKMefqs='%s < %s >'%(label,sublabel)
  else: hnrYWiGuzkvSUETALoXJDlxwKMefqs=label
  if not img:img='DefaultFolder.png'
  hnrYWiGuzkvSUETALoXJDlxwKMefqg=xbmcgui.ListItem(hnrYWiGuzkvSUETALoXJDlxwKMefqs)
  hnrYWiGuzkvSUETALoXJDlxwKMefqg.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:hnrYWiGuzkvSUETALoXJDlxwKMefqg.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:hnrYWiGuzkvSUETALoXJDlxwKMefqg.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(hnrYWiGuzkvSUETALoXJDlxwKMefqc._addon_handle,hnrYWiGuzkvSUETALoXJDlxwKMefqj,hnrYWiGuzkvSUETALoXJDlxwKMefqg,isFolder)
 def make_M3u_Filename(hnrYWiGuzkvSUETALoXJDlxwKMefqc,tempyn=hnrYWiGuzkvSUETALoXJDlxwKMefdm):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_FILE_PATH+hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(hnrYWiGuzkvSUETALoXJDlxwKMefqc,tempyn=hnrYWiGuzkvSUETALoXJDlxwKMefdm):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_FILE_PATH+hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_FILE_NAME+'.xml'
 def dp_Main_List(hnrYWiGuzkvSUETALoXJDlxwKMefqc):
  for hnrYWiGuzkvSUETALoXJDlxwKMefqF in hnrYWiGuzkvSUETALoXJDlxwKMefqd:
   hnrYWiGuzkvSUETALoXJDlxwKMefqs=hnrYWiGuzkvSUETALoXJDlxwKMefqF.get('title')
   hnrYWiGuzkvSUETALoXJDlxwKMefqN={'mode':hnrYWiGuzkvSUETALoXJDlxwKMefqF.get('mode'),'sType':hnrYWiGuzkvSUETALoXJDlxwKMefqF.get('sType'),'sName':hnrYWiGuzkvSUETALoXJDlxwKMefqF.get('sName')}
   if hnrYWiGuzkvSUETALoXJDlxwKMefqF.get('mode')=='XXX':
    hnrYWiGuzkvSUETALoXJDlxwKMefqm=hnrYWiGuzkvSUETALoXJDlxwKMefdm
   else:
    hnrYWiGuzkvSUETALoXJDlxwKMefqm=hnrYWiGuzkvSUETALoXJDlxwKMefdI
   hnrYWiGuzkvSUETALoXJDlxwKMefqO=hnrYWiGuzkvSUETALoXJDlxwKMefdI
   if hnrYWiGuzkvSUETALoXJDlxwKMefqF.get('mode')=='ADD_M3U':
    if hnrYWiGuzkvSUETALoXJDlxwKMefqF.get('sType')=='wavve' and hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVE==hnrYWiGuzkvSUETALoXJDlxwKMefdm:hnrYWiGuzkvSUETALoXJDlxwKMefqO=hnrYWiGuzkvSUETALoXJDlxwKMefdm
    if hnrYWiGuzkvSUETALoXJDlxwKMefqF.get('sType')=='tving' and hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONTVING==hnrYWiGuzkvSUETALoXJDlxwKMefdm:hnrYWiGuzkvSUETALoXJDlxwKMefqO=hnrYWiGuzkvSUETALoXJDlxwKMefdm
    if hnrYWiGuzkvSUETALoXJDlxwKMefqF.get('sType')=='spotv' and hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONSPOTV==hnrYWiGuzkvSUETALoXJDlxwKMefdm:hnrYWiGuzkvSUETALoXJDlxwKMefqO=hnrYWiGuzkvSUETALoXJDlxwKMefdm
   if hnrYWiGuzkvSUETALoXJDlxwKMefqO==hnrYWiGuzkvSUETALoXJDlxwKMefdI:
    hnrYWiGuzkvSUETALoXJDlxwKMefqc.add_dir(hnrYWiGuzkvSUETALoXJDlxwKMefqs,sublabel='',img='',infoLabels=hnrYWiGuzkvSUETALoXJDlxwKMefdO,isFolder=hnrYWiGuzkvSUETALoXJDlxwKMefqm,params=hnrYWiGuzkvSUETALoXJDlxwKMefqN)
  if hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefqd)>0:xbmcplugin.endOfDirectory(hnrYWiGuzkvSUETALoXJDlxwKMefqc._addon_handle,cacheToDisc=hnrYWiGuzkvSUETALoXJDlxwKMefdI)
 def dp_Delete_M3u(hnrYWiGuzkvSUETALoXJDlxwKMefqc,args):
  hnrYWiGuzkvSUETALoXJDlxwKMefqR=xbmcgui.Dialog()
  hnrYWiGuzkvSUETALoXJDlxwKMefqy=hnrYWiGuzkvSUETALoXJDlxwKMefqR.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if hnrYWiGuzkvSUETALoXJDlxwKMefqy==hnrYWiGuzkvSUETALoXJDlxwKMefdm:sys.exit()
  hnrYWiGuzkvSUETALoXJDlxwKMefqV=hnrYWiGuzkvSUETALoXJDlxwKMefqc.make_M3u_Filename(tempyn=hnrYWiGuzkvSUETALoXJDlxwKMefdm)
  if xbmcvfs.exists(hnrYWiGuzkvSUETALoXJDlxwKMefqV):
   if xbmcvfs.delete(hnrYWiGuzkvSUETALoXJDlxwKMefqV)==hnrYWiGuzkvSUETALoXJDlxwKMefdm:
    hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_noti(__language__(30910).encode('utf-8'))
    return
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(hnrYWiGuzkvSUETALoXJDlxwKMefqc,args):
  hnrYWiGuzkvSUETALoXJDlxwKMefbq=args.get('sType')
  hnrYWiGuzkvSUETALoXJDlxwKMefbd=args.get('sName')
  hnrYWiGuzkvSUETALoXJDlxwKMefqR=xbmcgui.Dialog()
  hnrYWiGuzkvSUETALoXJDlxwKMefqy=hnrYWiGuzkvSUETALoXJDlxwKMefqR.yesno((hnrYWiGuzkvSUETALoXJDlxwKMefbd+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if hnrYWiGuzkvSUETALoXJDlxwKMefqy==hnrYWiGuzkvSUETALoXJDlxwKMefdm:sys.exit()
  hnrYWiGuzkvSUETALoXJDlxwKMefbB =[]
  hnrYWiGuzkvSUETALoXJDlxwKMefbc =[]
  if hnrYWiGuzkvSUETALoXJDlxwKMefbq=='all':
   hnrYWiGuzkvSUETALoXJDlxwKMefqV=hnrYWiGuzkvSUETALoXJDlxwKMefqc.make_M3u_Filename(tempyn=hnrYWiGuzkvSUETALoXJDlxwKMefdI)
   if os.path.isfile(hnrYWiGuzkvSUETALoXJDlxwKMefqV):os.remove(hnrYWiGuzkvSUETALoXJDlxwKMefqV)
   hnrYWiGuzkvSUETALoXJDlxwKMefqV=hnrYWiGuzkvSUETALoXJDlxwKMefqc.make_M3u_Filename(tempyn=hnrYWiGuzkvSUETALoXJDlxwKMefdm)
   if xbmcvfs.exists(hnrYWiGuzkvSUETALoXJDlxwKMefqV):
    if xbmcvfs.delete(hnrYWiGuzkvSUETALoXJDlxwKMefqV)==hnrYWiGuzkvSUETALoXJDlxwKMefdm:
     hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_noti(__language__(30910).encode('utf-8'))
     return
  if(hnrYWiGuzkvSUETALoXJDlxwKMefbq=='wavve' or hnrYWiGuzkvSUETALoXJDlxwKMefbq=='all')and hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVE:
   hnrYWiGuzkvSUETALoXJDlxwKMefbH=hnrYWiGuzkvSUETALoXJDlxwKMefqc.BoritvObj.Get_ChannelList_Wavve(exceptGroup=hnrYWiGuzkvSUETALoXJDlxwKMefqc.make_EexceptGroup_Wavve())
   if hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefbH)!=0:hnrYWiGuzkvSUETALoXJDlxwKMefbB.extend(hnrYWiGuzkvSUETALoXJDlxwKMefbH)
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_log('wavve cnt ----> '+hnrYWiGuzkvSUETALoXJDlxwKMefdV(hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefbH)))
  if(hnrYWiGuzkvSUETALoXJDlxwKMefbq=='tving' or hnrYWiGuzkvSUETALoXJDlxwKMefbq=='all')and hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONTVING:
   hnrYWiGuzkvSUETALoXJDlxwKMefbH=hnrYWiGuzkvSUETALoXJDlxwKMefqc.BoritvObj.Get_ChannelList_Tving()
   if hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefbH)!=0:hnrYWiGuzkvSUETALoXJDlxwKMefbB.extend(hnrYWiGuzkvSUETALoXJDlxwKMefbH)
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_log('tving cnt ----> '+hnrYWiGuzkvSUETALoXJDlxwKMefdV(hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefbH)))
  if(hnrYWiGuzkvSUETALoXJDlxwKMefbq=='spotv' or hnrYWiGuzkvSUETALoXJDlxwKMefbq=='all')and hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONSPOTV:
   hnrYWiGuzkvSUETALoXJDlxwKMefbH=hnrYWiGuzkvSUETALoXJDlxwKMefqc.BoritvObj.Get_ChannelList_Spotv(payyn=hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONSPOTVPAY)
   if hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefbH)!=0:hnrYWiGuzkvSUETALoXJDlxwKMefbB.extend(hnrYWiGuzkvSUETALoXJDlxwKMefbH)
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_log('spotv cnt ----> '+hnrYWiGuzkvSUETALoXJDlxwKMefdV(hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefbH)))
  if hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefbB)==0:
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_noti(__language__(30909).encode('utf8'))
   return
  for hnrYWiGuzkvSUETALoXJDlxwKMefbC in hnrYWiGuzkvSUETALoXJDlxwKMefqc.BoritvObj.INIT_GENRESORT:
   for hnrYWiGuzkvSUETALoXJDlxwKMefbt in hnrYWiGuzkvSUETALoXJDlxwKMefbB:
    if hnrYWiGuzkvSUETALoXJDlxwKMefbt['genrenm']==hnrYWiGuzkvSUETALoXJDlxwKMefbC:
     hnrYWiGuzkvSUETALoXJDlxwKMefbc.append(hnrYWiGuzkvSUETALoXJDlxwKMefbt)
  for hnrYWiGuzkvSUETALoXJDlxwKMefbt in hnrYWiGuzkvSUETALoXJDlxwKMefbB:
   if hnrYWiGuzkvSUETALoXJDlxwKMefbt['genrenm']not in hnrYWiGuzkvSUETALoXJDlxwKMefqc.BoritvObj.INIT_GENRESORT:
    hnrYWiGuzkvSUETALoXJDlxwKMefbc.append(hnrYWiGuzkvSUETALoXJDlxwKMefbt)
  try:
   hnrYWiGuzkvSUETALoXJDlxwKMefqV=hnrYWiGuzkvSUETALoXJDlxwKMefqc.make_M3u_Filename(tempyn=hnrYWiGuzkvSUETALoXJDlxwKMefdI)
   if os.path.isfile(hnrYWiGuzkvSUETALoXJDlxwKMefqV):
    fp=hnrYWiGuzkvSUETALoXJDlxwKMefBq(hnrYWiGuzkvSUETALoXJDlxwKMefqV,'a',-1,'utf-8')
   else:
    fp=hnrYWiGuzkvSUETALoXJDlxwKMefBq(hnrYWiGuzkvSUETALoXJDlxwKMefqV,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for hnrYWiGuzkvSUETALoXJDlxwKMefbQ in hnrYWiGuzkvSUETALoXJDlxwKMefbc:
    hnrYWiGuzkvSUETALoXJDlxwKMefbR =hnrYWiGuzkvSUETALoXJDlxwKMefbQ['channelid']
    hnrYWiGuzkvSUETALoXJDlxwKMefba =hnrYWiGuzkvSUETALoXJDlxwKMefbQ['channelnm']
    hnrYWiGuzkvSUETALoXJDlxwKMefbp=hnrYWiGuzkvSUETALoXJDlxwKMefbQ['channelimg']
    hnrYWiGuzkvSUETALoXJDlxwKMefbP =hnrYWiGuzkvSUETALoXJDlxwKMefbQ['ott']
    hnrYWiGuzkvSUETALoXJDlxwKMefbj ='%s.%s'%(hnrYWiGuzkvSUETALoXJDlxwKMefbR,hnrYWiGuzkvSUETALoXJDlxwKMefbP)
    hnrYWiGuzkvSUETALoXJDlxwKMefbs=hnrYWiGuzkvSUETALoXJDlxwKMefbQ['genrenm']
    if hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_DISPLAYNM:
     hnrYWiGuzkvSUETALoXJDlxwKMefba='%s (%s)'%(hnrYWiGuzkvSUETALoXJDlxwKMefba,hnrYWiGuzkvSUETALoXJDlxwKMefbP)
    if hnrYWiGuzkvSUETALoXJDlxwKMefbs=='라디오/음악':
     hnrYWiGuzkvSUETALoXJDlxwKMefbg='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(hnrYWiGuzkvSUETALoXJDlxwKMefbj,hnrYWiGuzkvSUETALoXJDlxwKMefba,hnrYWiGuzkvSUETALoXJDlxwKMefbs,hnrYWiGuzkvSUETALoXJDlxwKMefbp,hnrYWiGuzkvSUETALoXJDlxwKMefba)
    else:
     hnrYWiGuzkvSUETALoXJDlxwKMefbg='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(hnrYWiGuzkvSUETALoXJDlxwKMefbj,hnrYWiGuzkvSUETALoXJDlxwKMefba,hnrYWiGuzkvSUETALoXJDlxwKMefbs,hnrYWiGuzkvSUETALoXJDlxwKMefbp,hnrYWiGuzkvSUETALoXJDlxwKMefba)
    if hnrYWiGuzkvSUETALoXJDlxwKMefbP=='wavve':
     hnrYWiGuzkvSUETALoXJDlxwKMefbF ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(hnrYWiGuzkvSUETALoXJDlxwKMefbR)
    elif hnrYWiGuzkvSUETALoXJDlxwKMefbP=='tving':
     hnrYWiGuzkvSUETALoXJDlxwKMefbF ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(hnrYWiGuzkvSUETALoXJDlxwKMefbR)
    elif hnrYWiGuzkvSUETALoXJDlxwKMefbP=='spotv':
     hnrYWiGuzkvSUETALoXJDlxwKMefbF ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(hnrYWiGuzkvSUETALoXJDlxwKMefbR)
    fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefbg)
    fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefbF)
   fp.close()
  except:
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_noti(__language__(30910).encode('utf8'))
   return
  hnrYWiGuzkvSUETALoXJDlxwKMefbN=hnrYWiGuzkvSUETALoXJDlxwKMefqc.make_M3u_Filename(tempyn=hnrYWiGuzkvSUETALoXJDlxwKMefdI)
  hnrYWiGuzkvSUETALoXJDlxwKMefbm=hnrYWiGuzkvSUETALoXJDlxwKMefqc.make_M3u_Filename(tempyn=hnrYWiGuzkvSUETALoXJDlxwKMefdm)
  if xbmcvfs.copy(hnrYWiGuzkvSUETALoXJDlxwKMefbN,hnrYWiGuzkvSUETALoXJDlxwKMefbm):
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_noti((hnrYWiGuzkvSUETALoXJDlxwKMefbd+' '+__language__(30908)).encode('utf8'))
  else:
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_noti(__language__(30910).encode('utf-8'))
 def dp_Make_Epg(hnrYWiGuzkvSUETALoXJDlxwKMefqc,args):
  hnrYWiGuzkvSUETALoXJDlxwKMefbq=args.get('sType')
  hnrYWiGuzkvSUETALoXJDlxwKMefbd=args.get('sName')
  hnrYWiGuzkvSUETALoXJDlxwKMefbO=args.get('sNoti')
  if hnrYWiGuzkvSUETALoXJDlxwKMefbO!='N':
   hnrYWiGuzkvSUETALoXJDlxwKMefqR=xbmcgui.Dialog()
   hnrYWiGuzkvSUETALoXJDlxwKMefqy=hnrYWiGuzkvSUETALoXJDlxwKMefqR.yesno((hnrYWiGuzkvSUETALoXJDlxwKMefbd+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if hnrYWiGuzkvSUETALoXJDlxwKMefqy==hnrYWiGuzkvSUETALoXJDlxwKMefdm:sys.exit()
  hnrYWiGuzkvSUETALoXJDlxwKMefbI=[]
  hnrYWiGuzkvSUETALoXJDlxwKMefby=[]
  if(hnrYWiGuzkvSUETALoXJDlxwKMefbq=='wavve' or hnrYWiGuzkvSUETALoXJDlxwKMefbq=='all')and hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVE:
   hnrYWiGuzkvSUETALoXJDlxwKMefbV,hnrYWiGuzkvSUETALoXJDlxwKMefdq=hnrYWiGuzkvSUETALoXJDlxwKMefqc.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=hnrYWiGuzkvSUETALoXJDlxwKMefqc.make_EexceptGroup_Wavve())
   if hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefdq)!=0:
    hnrYWiGuzkvSUETALoXJDlxwKMefbI.extend(hnrYWiGuzkvSUETALoXJDlxwKMefbV)
    hnrYWiGuzkvSUETALoXJDlxwKMefby.extend(hnrYWiGuzkvSUETALoXJDlxwKMefdq)
  if(hnrYWiGuzkvSUETALoXJDlxwKMefbq=='tving' or hnrYWiGuzkvSUETALoXJDlxwKMefbq=='all')and hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONTVING:
   hnrYWiGuzkvSUETALoXJDlxwKMefbV,hnrYWiGuzkvSUETALoXJDlxwKMefdq=hnrYWiGuzkvSUETALoXJDlxwKMefqc.BoritvObj.Get_EpgInfo_Tving()
   if hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefdq)!=0:
    hnrYWiGuzkvSUETALoXJDlxwKMefbI.extend(hnrYWiGuzkvSUETALoXJDlxwKMefbV)
    hnrYWiGuzkvSUETALoXJDlxwKMefby.extend(hnrYWiGuzkvSUETALoXJDlxwKMefdq)
  if(hnrYWiGuzkvSUETALoXJDlxwKMefbq=='spotv' or hnrYWiGuzkvSUETALoXJDlxwKMefbq=='all')and hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONSPOTV:
   hnrYWiGuzkvSUETALoXJDlxwKMefbV,hnrYWiGuzkvSUETALoXJDlxwKMefdq=hnrYWiGuzkvSUETALoXJDlxwKMefqc.BoritvObj.Get_EpgInfo_Spotv(payyn=hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONSPOTVPAY)
   if hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefdq)!=0:
    hnrYWiGuzkvSUETALoXJDlxwKMefbI.extend(hnrYWiGuzkvSUETALoXJDlxwKMefbV)
    hnrYWiGuzkvSUETALoXJDlxwKMefby.extend(hnrYWiGuzkvSUETALoXJDlxwKMefdq)
  if hnrYWiGuzkvSUETALoXJDlxwKMefdy(hnrYWiGuzkvSUETALoXJDlxwKMefby)==0:
   if hnrYWiGuzkvSUETALoXJDlxwKMefbO!='N':hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   hnrYWiGuzkvSUETALoXJDlxwKMefqV=hnrYWiGuzkvSUETALoXJDlxwKMefqc.make_Epg_Filename(tempyn=hnrYWiGuzkvSUETALoXJDlxwKMefdI)
   fp=hnrYWiGuzkvSUETALoXJDlxwKMefBq(hnrYWiGuzkvSUETALoXJDlxwKMefqV,'w',-1,'utf-8')
   hnrYWiGuzkvSUETALoXJDlxwKMefdb='<?xml version="1.0" encoding="UTF-8"?>\n'
   hnrYWiGuzkvSUETALoXJDlxwKMefdB='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   hnrYWiGuzkvSUETALoXJDlxwKMefdc='<tv generator-info-name="boritv_epg">\n\n'
   hnrYWiGuzkvSUETALoXJDlxwKMefdH='\n</tv>\n'
   fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefdb)
   fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefdB)
   fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefdc)
   for hnrYWiGuzkvSUETALoXJDlxwKMefdC in hnrYWiGuzkvSUETALoXJDlxwKMefbI:
    hnrYWiGuzkvSUETALoXJDlxwKMefdt='  <channel id="%s.%s">\n' %(hnrYWiGuzkvSUETALoXJDlxwKMefdC.get('channelid'),hnrYWiGuzkvSUETALoXJDlxwKMefdC.get('ott'))
    hnrYWiGuzkvSUETALoXJDlxwKMefdQ='    <display-name>%s</display-name>\n'%(hnrYWiGuzkvSUETALoXJDlxwKMefdC.get('channelnm'))
    hnrYWiGuzkvSUETALoXJDlxwKMefdR='    <icon src="%s" />\n' %(hnrYWiGuzkvSUETALoXJDlxwKMefdC.get('channelimg'))
    hnrYWiGuzkvSUETALoXJDlxwKMefda='  </channel>\n\n'
    fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefdt)
    fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefdQ)
    fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefdR)
    fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefda)
   for hnrYWiGuzkvSUETALoXJDlxwKMefdC in hnrYWiGuzkvSUETALoXJDlxwKMefby:
    hnrYWiGuzkvSUETALoXJDlxwKMefdt='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(hnrYWiGuzkvSUETALoXJDlxwKMefdC.get('startTime'),hnrYWiGuzkvSUETALoXJDlxwKMefdC.get('endTime'),hnrYWiGuzkvSUETALoXJDlxwKMefdC.get('channelid'),hnrYWiGuzkvSUETALoXJDlxwKMefdC.get('ott'))
    hnrYWiGuzkvSUETALoXJDlxwKMefdQ='    <title lang="kr">%s</title>\n' %(hnrYWiGuzkvSUETALoXJDlxwKMefdC.get('title'))
    hnrYWiGuzkvSUETALoXJDlxwKMefdR='  </programme>\n\n'
    fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefdt)
    fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefdQ)
    fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefdR)
   fp.write(hnrYWiGuzkvSUETALoXJDlxwKMefdH)
   fp.close()
  except:
   if hnrYWiGuzkvSUETALoXJDlxwKMefbO!='N':hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_noti(__language__(30910).encode('utf8'))
   return
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.MakeEpg_SaveJson()
  hnrYWiGuzkvSUETALoXJDlxwKMefbN=hnrYWiGuzkvSUETALoXJDlxwKMefqc.make_Epg_Filename(tempyn=hnrYWiGuzkvSUETALoXJDlxwKMefdI)
  hnrYWiGuzkvSUETALoXJDlxwKMefbm=hnrYWiGuzkvSUETALoXJDlxwKMefqc.make_Epg_Filename(tempyn=hnrYWiGuzkvSUETALoXJDlxwKMefdm)
  if xbmcvfs.copy(hnrYWiGuzkvSUETALoXJDlxwKMefbN,hnrYWiGuzkvSUETALoXJDlxwKMefbm):
   if hnrYWiGuzkvSUETALoXJDlxwKMefbO!='N':hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_noti((hnrYWiGuzkvSUETALoXJDlxwKMefbd+' '+__language__(30912)).encode('utf8'))
  else:
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_AUTORESTART:
    hnrYWiGuzkvSUETALoXJDlxwKMefdp=xbmcaddon.Addon('pvr.iptvsimple')
    hnrYWiGuzkvSUETALoXJDlxwKMefdp.setSetting('anything','anything')
  except:
   hnrYWiGuzkvSUETALoXJDlxwKMefdO 
 def make_EexceptGroup_Wavve(hnrYWiGuzkvSUETALoXJDlxwKMefqc):
  hnrYWiGuzkvSUETALoXJDlxwKMefdP=[]
  if hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVERADIO==hnrYWiGuzkvSUETALoXJDlxwKMefdm:
   hnrYWiGuzkvSUETALoXJDlxwKMefdP.append('라디오/음악')
  if hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVEHOME==hnrYWiGuzkvSUETALoXJDlxwKMefdm:
   hnrYWiGuzkvSUETALoXJDlxwKMefdP.append('홈쇼핑')
  if hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONRELIGION==hnrYWiGuzkvSUETALoXJDlxwKMefdm:
   hnrYWiGuzkvSUETALoXJDlxwKMefdP.append('종교')
  return hnrYWiGuzkvSUETALoXJDlxwKMefdP
 def get_radio_list(hnrYWiGuzkvSUETALoXJDlxwKMefqc):
  if hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVERADIO==hnrYWiGuzkvSUETALoXJDlxwKMefdm:return[]
  hnrYWiGuzkvSUETALoXJDlxwKMefdj=[{'broadcastid':'46584','genre':'10'}]
  return hnrYWiGuzkvSUETALoXJDlxwKMefqc.BoritvObj.Get_ChannelList_WavveExcept(hnrYWiGuzkvSUETALoXJDlxwKMefdj)
 def check_config(hnrYWiGuzkvSUETALoXJDlxwKMefqc):
  hnrYWiGuzkvSUETALoXJDlxwKMefds=hnrYWiGuzkvSUETALoXJDlxwKMefdI
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVE =hnrYWiGuzkvSUETALoXJDlxwKMefdI if __addon__.getSetting('onWavve')=='true' else hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONTVING =hnrYWiGuzkvSUETALoXJDlxwKMefdI if __addon__.getSetting('onTvng')=='true' else hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONSPOTV =hnrYWiGuzkvSUETALoXJDlxwKMefdI if __addon__.getSetting('onSpotv')=='true' else hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVERADIO=hnrYWiGuzkvSUETALoXJDlxwKMefdI if __addon__.getSetting('onWavveRadio')=='true' else hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVEHOME =hnrYWiGuzkvSUETALoXJDlxwKMefdI if __addon__.getSetting('onWavveHome')=='true' else hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONRELIGION =hnrYWiGuzkvSUETALoXJDlxwKMefdI if __addon__.getSetting('onWavveReligion')=='true' else hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONSPOTVPAY =hnrYWiGuzkvSUETALoXJDlxwKMefdI if __addon__.getSetting('onSpotvPay')=='true' else hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_DISPLAYNM =hnrYWiGuzkvSUETALoXJDlxwKMefdI if __addon__.getSetting('displayOTTnm')=='true' else hnrYWiGuzkvSUETALoXJDlxwKMefdm
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_AUTORESTART =hnrYWiGuzkvSUETALoXJDlxwKMefdI if __addon__.getSetting('autoRestart')=='true' else hnrYWiGuzkvSUETALoXJDlxwKMefdm
  if hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_FILE_PATH=='' or hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_FILE_NAME=='':hnrYWiGuzkvSUETALoXJDlxwKMefds=hnrYWiGuzkvSUETALoXJDlxwKMefdm
  if hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONWAVVE==hnrYWiGuzkvSUETALoXJDlxwKMefdm and hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONTVING=='' and hnrYWiGuzkvSUETALoXJDlxwKMefqc.M3U_ONSPOTV=='':hnrYWiGuzkvSUETALoXJDlxwKMefds=hnrYWiGuzkvSUETALoXJDlxwKMefdm
  if hnrYWiGuzkvSUETALoXJDlxwKMefds==hnrYWiGuzkvSUETALoXJDlxwKMefdm:
   hnrYWiGuzkvSUETALoXJDlxwKMefqR=xbmcgui.Dialog()
   hnrYWiGuzkvSUETALoXJDlxwKMefqy=hnrYWiGuzkvSUETALoXJDlxwKMefqR.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if hnrYWiGuzkvSUETALoXJDlxwKMefqy==hnrYWiGuzkvSUETALoXJDlxwKMefdI:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(hnrYWiGuzkvSUETALoXJDlxwKMefqc):
  hnrYWiGuzkvSUETALoXJDlxwKMefdg={'date_makeepg':hnrYWiGuzkvSUETALoXJDlxwKMefqc.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=hnrYWiGuzkvSUETALoXJDlxwKMefBq(hnrYWiGuzkvSUETALoXJDlxwKMefqB,'w',-1,'utf-8')
   json.dump(hnrYWiGuzkvSUETALoXJDlxwKMefdg,fp)
   fp.close()
  except hnrYWiGuzkvSUETALoXJDlxwKMefBb as exception:
   return
 def boritv_main(hnrYWiGuzkvSUETALoXJDlxwKMefqc):
  hnrYWiGuzkvSUETALoXJDlxwKMefdF=hnrYWiGuzkvSUETALoXJDlxwKMefqc.main_params.get('mode',hnrYWiGuzkvSUETALoXJDlxwKMefdO)
  hnrYWiGuzkvSUETALoXJDlxwKMefqc.check_config()
  if hnrYWiGuzkvSUETALoXJDlxwKMefdF is hnrYWiGuzkvSUETALoXJDlxwKMefdO:
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.dp_Main_List()
  elif hnrYWiGuzkvSUETALoXJDlxwKMefdF=='DEL_M3U':
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.dp_Delete_M3u(hnrYWiGuzkvSUETALoXJDlxwKMefqc.main_params)
  elif hnrYWiGuzkvSUETALoXJDlxwKMefdF=='ADD_M3U':
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.dp_MakeAdd_M3u(hnrYWiGuzkvSUETALoXJDlxwKMefqc.main_params)
  elif hnrYWiGuzkvSUETALoXJDlxwKMefdF=='ADD_EPG':
   hnrYWiGuzkvSUETALoXJDlxwKMefqc.dp_Make_Epg(hnrYWiGuzkvSUETALoXJDlxwKMefqc.main_params)
  else:
   hnrYWiGuzkvSUETALoXJDlxwKMefdO
# Created by pyminifier (https://github.com/liftoff/pyminifier)
