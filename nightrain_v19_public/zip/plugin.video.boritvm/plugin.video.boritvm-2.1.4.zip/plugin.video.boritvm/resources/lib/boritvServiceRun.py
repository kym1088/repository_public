__author__="NightRain"
nNbWHPXkmpvorGCxTQUchiJdLBqAlf=str
nNbWHPXkmpvorGCxTQUchiJdLBqAlS=True
nNbWHPXkmpvorGCxTQUchiJdLBqAlV=False
nNbWHPXkmpvorGCxTQUchiJdLBqAlu=print
nNbWHPXkmpvorGCxTQUchiJdLBqAlR=open
nNbWHPXkmpvorGCxTQUchiJdLBqAlg=Exception
nNbWHPXkmpvorGCxTQUchiJdLBqAMl=int
import json
import time
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 nNbWHPXkmpvorGCxTQUchiJdLBqAlI='ADDON'
except:
 nNbWHPXkmpvorGCxTQUchiJdLBqAlI='SINGLE'
if nNbWHPXkmpvorGCxTQUchiJdLBqAlI=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  nNbWHPXkmpvorGCxTQUchiJdLBqAlO=nNbWHPXkmpvorGCxTQUchiJdLBqAlf(string).encode('utf-8','ignore')
  nNbWHPXkmpvorGCxTQUchiJdLBqAlF=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,nNbWHPXkmpvorGCxTQUchiJdLBqAlO),level=nNbWHPXkmpvorGCxTQUchiJdLBqAlF)
 def addon_getautoepg():
  return nNbWHPXkmpvorGCxTQUchiJdLBqAlS if __addon__.getSetting('autoEpg')=='true' else nNbWHPXkmpvorGCxTQUchiJdLBqAlV
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  nNbWHPXkmpvorGCxTQUchiJdLBqAlu(string)
 def addon_getautoepg():
  return nNbWHPXkmpvorGCxTQUchiJdLBqAlS
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class nNbWHPXkmpvorGCxTQUchiJdLBqAlM():
 def __init__(nNbWHPXkmpvorGCxTQUchiJdLBqAlE):
  nNbWHPXkmpvorGCxTQUchiJdLBqAlE.START_INTERVAL =3000 
  nNbWHPXkmpvorGCxTQUchiJdLBqAlE.INTERVAL =20 
  nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_FILETAGNM ='date_makeepg'
  nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_MAKEDATE ='-' 
  nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_WILL_TM =-1 
 def Get_Now_Datetime(nNbWHPXkmpvorGCxTQUchiJdLBqAlE):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(nNbWHPXkmpvorGCxTQUchiJdLBqAlE):
  nNbWHPXkmpvorGCxTQUchiJdLBqAlj ='-'
  if nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_MAKEDATE=='-':
   try:
    fp=nNbWHPXkmpvorGCxTQUchiJdLBqAlR(addon_epgupdate_confignm(),'r',-1,'utf-8')
    nNbWHPXkmpvorGCxTQUchiJdLBqAlY= json.load(fp)
    fp.close()
    nNbWHPXkmpvorGCxTQUchiJdLBqAlj=nNbWHPXkmpvorGCxTQUchiJdLBqAlY[nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_FILETAGNM]
   except nNbWHPXkmpvorGCxTQUchiJdLBqAlg as exception:
    return 2 
  else:
   nNbWHPXkmpvorGCxTQUchiJdLBqAlj=nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_MAKEDATE
  nNbWHPXkmpvorGCxTQUchiJdLBqAla =nNbWHPXkmpvorGCxTQUchiJdLBqAlE.Get_Now_Datetime()
  nNbWHPXkmpvorGCxTQUchiJdLBqAlw=(nNbWHPXkmpvorGCxTQUchiJdLBqAla-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  nNbWHPXkmpvorGCxTQUchiJdLBqAlt =nNbWHPXkmpvorGCxTQUchiJdLBqAla.strftime('%Y-%m-%d')
  nNbWHPXkmpvorGCxTQUchiJdLBqAls =nNbWHPXkmpvorGCxTQUchiJdLBqAla.strftime('%H')
  if nNbWHPXkmpvorGCxTQUchiJdLBqAlj==nNbWHPXkmpvorGCxTQUchiJdLBqAlt: return-1
  if nNbWHPXkmpvorGCxTQUchiJdLBqAlj==nNbWHPXkmpvorGCxTQUchiJdLBqAlw and nNbWHPXkmpvorGCxTQUchiJdLBqAls=='00':return 30
  return 2
 def MakeEpg_RandomTm(nNbWHPXkmpvorGCxTQUchiJdLBqAlE,mintm):
  nNbWHPXkmpvorGCxTQUchiJdLBqAle=(mintm*60)+random.randint(0,60)
  nNbWHPXkmpvorGCxTQUchiJdLBqAla =nNbWHPXkmpvorGCxTQUchiJdLBqAlE.Get_Now_Datetime()
  nNbWHPXkmpvorGCxTQUchiJdLBqAlK =(nNbWHPXkmpvorGCxTQUchiJdLBqAla+datetime.timedelta(seconds=nNbWHPXkmpvorGCxTQUchiJdLBqAle)).strftime('%Y%m%d%H%M%S')
  return nNbWHPXkmpvorGCxTQUchiJdLBqAMl(nNbWHPXkmpvorGCxTQUchiJdLBqAlK)
 def MakeEpg_SaveJson(nNbWHPXkmpvorGCxTQUchiJdLBqAlE):
  nNbWHPXkmpvorGCxTQUchiJdLBqAlY={nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_FILETAGNM:nNbWHPXkmpvorGCxTQUchiJdLBqAlE.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=nNbWHPXkmpvorGCxTQUchiJdLBqAlR(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(nNbWHPXkmpvorGCxTQUchiJdLBqAlY,fp)
   fp.close()
  except nNbWHPXkmpvorGCxTQUchiJdLBqAlg as exception:
   return
 def service_run(nNbWHPXkmpvorGCxTQUchiJdLBqAlE):
  if addon_getautoepg()==nNbWHPXkmpvorGCxTQUchiJdLBqAlV:return
  nNbWHPXkmpvorGCxTQUchiJdLBqAly=nNbWHPXkmpvorGCxTQUchiJdLBqAlE.MakeEpg_DateCheck()
  if nNbWHPXkmpvorGCxTQUchiJdLBqAly<0:
   return
  if nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_WILL_TM<0:
   nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_WILL_TM=nNbWHPXkmpvorGCxTQUchiJdLBqAlE.MakeEpg_RandomTm(nNbWHPXkmpvorGCxTQUchiJdLBqAly)
   addon_log('EPG_WILL_TM --> '+nNbWHPXkmpvorGCxTQUchiJdLBqAlf(nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_WILL_TM))
  else:
   nNbWHPXkmpvorGCxTQUchiJdLBqAlt=nNbWHPXkmpvorGCxTQUchiJdLBqAlE.Get_Now_Datetime()
   if nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_WILL_TM<nNbWHPXkmpvorGCxTQUchiJdLBqAMl(nNbWHPXkmpvorGCxTQUchiJdLBqAlt.strftime('%Y%m%d%H%M%S')):
    addon_log('make epg')
    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
    nNbWHPXkmpvorGCxTQUchiJdLBqAlE.MakeEpg_SaveJson()
    nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_MAKEDATE=nNbWHPXkmpvorGCxTQUchiJdLBqAlt.strftime('%Y-%m-%d')
    nNbWHPXkmpvorGCxTQUchiJdLBqAlE.EPG_WILL_TM =-1
   else:
    pass
  pass
if __name__=="__main__":
 addon_log('__main__')
 nNbWHPXkmpvorGCxTQUchiJdLBqAlD=nNbWHPXkmpvorGCxTQUchiJdLBqAlM()
 time.sleep(nNbWHPXkmpvorGCxTQUchiJdLBqAlD.START_INTERVAL)
 while nNbWHPXkmpvorGCxTQUchiJdLBqAlS:
  time.sleep(nNbWHPXkmpvorGCxTQUchiJdLBqAlD.INTERVAL)
  nNbWHPXkmpvorGCxTQUchiJdLBqAlD.service_run()
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
