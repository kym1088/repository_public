__author__="NightRain"
XtvzKLIVyTAusDFRcPxgkOqhmrSjle=False
XtvzKLIVyTAusDFRcPxgkOqhmrSjlJ=object
XtvzKLIVyTAusDFRcPxgkOqhmrSjlB=None
XtvzKLIVyTAusDFRcPxgkOqhmrSjlE=str
XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ=Exception
XtvzKLIVyTAusDFRcPxgkOqhmrSjlW=print
XtvzKLIVyTAusDFRcPxgkOqhmrSjln=True
XtvzKLIVyTAusDFRcPxgkOqhmrSjlH=int
XtvzKLIVyTAusDFRcPxgkOqhmrSjpo=range
XtvzKLIVyTAusDFRcPxgkOqhmrSjpi=len
XtvzKLIVyTAusDFRcPxgkOqhmrSjpd=set
XtvzKLIVyTAusDFRcPxgkOqhmrSjpl=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
from channelgenre import*
XtvzKLIVyTAusDFRcPxgkOqhmrSjod=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
XtvzKLIVyTAusDFRcPxgkOqhmrSjol=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':XtvzKLIVyTAusDFRcPxgkOqhmrSjle,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':XtvzKLIVyTAusDFRcPxgkOqhmrSjle,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':XtvzKLIVyTAusDFRcPxgkOqhmrSjle,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':XtvzKLIVyTAusDFRcPxgkOqhmrSjle,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':XtvzKLIVyTAusDFRcPxgkOqhmrSjle,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':XtvzKLIVyTAusDFRcPxgkOqhmrSjle,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class XtvzKLIVyTAusDFRcPxgkOqhmrSjoi(XtvzKLIVyTAusDFRcPxgkOqhmrSjlJ):
 def __init__(XtvzKLIVyTAusDFRcPxgkOqhmrSjop):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_WAVVE ='https://apis.wavve.com'
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_TVING ='https://api.tving.com'
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_TVINGIMG ='https://image.tving.com'
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_SPOTV ='https://www.spotvnow.co.kr'
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_SEEZN ='https://api.seezntv.com'
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.HTTPTAG ='https://'
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.LIMIT_WAVVE =200
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.LIMIT_TVING =60
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.LIMIT_TVINGEPG=20 
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.APPVERSION ='90.0.4430.93' 
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.DEVICEMODEL ='Chrome' 
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.OSTYPE ='Windows' 
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.OSVERSION ='NT 10.0' 
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.SEEZN_HEADER ={'X-APP-VERSION':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.APPVERSION,'X-DEVICE-MODEL':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.DEVICEMODEL,'X-OS-TYPE':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.OSTYPE,'X-OS-VERSION':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.OSVERSION,}
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.DEFAULT_HEADER={'user-agent':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.USER_AGENT}
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.SLEEP_TIME =0.2
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.INIT_GENRESORT=MASTER_GENRE
  XtvzKLIVyTAusDFRcPxgkOqhmrSjop.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,jobtype,XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,redirects=XtvzKLIVyTAusDFRcPxgkOqhmrSjle):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoU=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.DEFAULT_HEADER
  if headers:XtvzKLIVyTAusDFRcPxgkOqhmrSjoU.update(headers)
  if jobtype=='Get':
   XtvzKLIVyTAusDFRcPxgkOqhmrSjow=requests.get(XtvzKLIVyTAusDFRcPxgkOqhmrSjob,params=params,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjoU,cookies=cookies,allow_redirects=redirects)
  else:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjow=requests.post(XtvzKLIVyTAusDFRcPxgkOqhmrSjob,data=payload,params=params,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjoU,cookies=cookies,allow_redirects=redirects)
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjow
 def Get_DefaultParams_Wavve(XtvzKLIVyTAusDFRcPxgkOqhmrSjop):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoN={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoN
 def Get_DefaultParams_Tving(XtvzKLIVyTAusDFRcPxgkOqhmrSjop):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoN={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoN
 def Get_Now_Datetime(XtvzKLIVyTAusDFRcPxgkOqhmrSjop):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,in_text):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoG=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoG
 def Get_ChannelList_Wavve(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,exceptGroup=[]):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoC =[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoa=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_ChannelImg_Wavve()
  try:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjob=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_WAVVE+'/cf/live/recommend-channels'
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoN={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoN.update(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_DefaultParams_Wavve())
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjoN,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB)
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
   if not('celllist' in XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['cell_toplist']):return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoB=XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['cell_toplist']['celllist']
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjoB:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ=XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['contentid']
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoW=XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['title_list'][0]['text']
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ in XtvzKLIVyTAusDFRcPxgkOqhmrSjoa:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjon=XtvzKLIVyTAusDFRcPxgkOqhmrSjoa[XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ]
    else:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjon=''
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoH=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.make_getGenre(XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'wavve')
    XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'channelid':XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'channelnm':XtvzKLIVyTAusDFRcPxgkOqhmrSjoW,'channelimg':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.HTTPTAG+XtvzKLIVyTAusDFRcPxgkOqhmrSjon if XtvzKLIVyTAusDFRcPxgkOqhmrSjon!='' else '','ott':'wavve','genrenm':XtvzKLIVyTAusDFRcPxgkOqhmrSjoH}
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjoH not in exceptGroup:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjoC.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[]
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC
 def Get_ChannelList_WavveExcept(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,exceptGroup=[]):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoC=[]
  if exceptGroup==[]:return[]
  try:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjob=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_WAVVE+'/cf/live/recommend-channels'
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in exceptGroup:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoN={'WeekDay':'all','adult':'n','broadcastid':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['broadcastid'],'contenttype':'channel','genre':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['genre'],'isrecommend':'y','limit':XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoN.update(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_DefaultParams_Wavve())
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjoN,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB)
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
    if not('celllist' in XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['cell_toplist']):return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoB=XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['cell_toplist']['celllist']
    for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjoB:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjoC.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['contentid'])
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[]
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC
 def Get_ChannelImg_Wavve(XtvzKLIVyTAusDFRcPxgkOqhmrSjop):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjid={}
  try:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjil=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_Now_Datetime()
   XtvzKLIVyTAusDFRcPxgkOqhmrSjip =XtvzKLIVyTAusDFRcPxgkOqhmrSjil+datetime.timedelta(hours=3)
   XtvzKLIVyTAusDFRcPxgkOqhmrSjob=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_WAVVE+'/live/epgs'
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoN={'limit':XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':XtvzKLIVyTAusDFRcPxgkOqhmrSjil.strftime('%Y-%m-%d %H:00'),'enddatetime':XtvzKLIVyTAusDFRcPxgkOqhmrSjip.strftime('%Y-%m-%d %H:00')}
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoN.update(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_DefaultParams_Wavve())
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjoN,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB)
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoB=XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['list']
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjoB:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjid[XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['channelid']]=XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['channelimage']
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjid
 def Get_ChanneGenrename_Wavve(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ):
  try:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjob=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_WAVVE+'/live/channels/'+XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoN=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_DefaultParams_Wavve()
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjoN,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB)
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
   XtvzKLIVyTAusDFRcPxgkOqhmrSjiM=XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['genretext']
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return ''
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjiM
 def Get_ChannelList_Spotv(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,payyn=XtvzKLIVyTAusDFRcPxgkOqhmrSjln):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoC=[]
  try:
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjol:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ=XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['videoId']
    XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'channelid':XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'channelnm':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['name'],'channelimg':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['logo'],'ott':'spotv','genrenm':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.make_getGenre(XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'spotv')}
    if payyn==XtvzKLIVyTAusDFRcPxgkOqhmrSjln or XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['free']==XtvzKLIVyTAusDFRcPxgkOqhmrSjln:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjoC.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[]
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC
 def Get_ChannelList_Tving(XtvzKLIVyTAusDFRcPxgkOqhmrSjop):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoC =[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjif=[]
  try:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjob=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_TVING+'/v2/media/lives'
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoN={'pageNo':'1','pageSize':XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoN.update(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_DefaultParams_Tving())
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjoN,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB)
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
   if not('result' in XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['body']):return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoB=XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['body']['result']
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjoB:
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['live_code']=='C44441':continue 
    XtvzKLIVyTAusDFRcPxgkOqhmrSjif.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['live_code'])
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoa=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_ChannelImg_Tving(XtvzKLIVyTAusDFRcPxgkOqhmrSjif)
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjoB:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ=XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['live_code']
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ=='C44441':continue 
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoW=XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['schedule']['channel']['name']['ko']
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ in XtvzKLIVyTAusDFRcPxgkOqhmrSjoa:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjon=XtvzKLIVyTAusDFRcPxgkOqhmrSjoa[XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ]
    else:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjon=''
    XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'channelid':XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'channelnm':XtvzKLIVyTAusDFRcPxgkOqhmrSjoW,'channelimg':XtvzKLIVyTAusDFRcPxgkOqhmrSjon,'ott':'tving','genrenm':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.make_getGenre(XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'tving')}
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoC.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[]
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC
 def Get_timestamp(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,timetype=1):
  ts=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,timetype):
  if timetype=='1':
   XtvzKLIVyTAusDFRcPxgkOqhmrSjiU={'transactionId':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjiU={'timestamp':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_timestamp(timetype=1),'transactionId':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_timestamp(timetype=1)+'000000000000001',}
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjiU
 def Get_ChannelList_Seezn(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,exceptGroup=[]):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoC =[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjiw =XtvzKLIVyTAusDFRcPxgkOqhmrSjln if 'won' in exceptGroup else XtvzKLIVyTAusDFRcPxgkOqhmrSjle
  XtvzKLIVyTAusDFRcPxgkOqhmrSjiN =XtvzKLIVyTAusDFRcPxgkOqhmrSjln if '홈쇼핑' in exceptGroup else XtvzKLIVyTAusDFRcPxgkOqhmrSjle
  XtvzKLIVyTAusDFRcPxgkOqhmrSjiY=XtvzKLIVyTAusDFRcPxgkOqhmrSjln if '라디오/음악' in exceptGroup else XtvzKLIVyTAusDFRcPxgkOqhmrSjle
  try:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjob=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_SEEZN+'/svc/menu/app6/api/epg_chlist' 
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoN={'category_id':'2','istest':'0',}
   XtvzKLIVyTAusDFRcPxgkOqhmrSjiG=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Make_Header_Timestamp(timetype='2')
   XtvzKLIVyTAusDFRcPxgkOqhmrSjiG.update(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.SEEZN_HEADER)
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjoN,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjiG,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,redirects=XtvzKLIVyTAusDFRcPxgkOqhmrSjln)
   if XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.status_code!=200:return[]
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
   if XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ.get('meta').get('code')!='200':return[]
   XtvzKLIVyTAusDFRcPxgkOqhmrSjiC=XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ.get('data').get('list')[0].get('list_channel')
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjiC:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjia =XtvzKLIVyTAusDFRcPxgkOqhmrSjoE.get('bit_rate_info').split(",")[0]
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ =XtvzKLIVyTAusDFRcPxgkOqhmrSjoE.get('ch_no')
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoH=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.make_getGenre(XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'seezn')
    XtvzKLIVyTAusDFRcPxgkOqhmrSjib =XtvzKLIVyTAusDFRcPxgkOqhmrSjoE.get('type')
    XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'channelid':XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'channelnm':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE.get('service_ch_name').replace(',','.'),'channelimg':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE.get('ch_image_list'),'ott':'seezn','genrenm':XtvzKLIVyTAusDFRcPxgkOqhmrSjoH,}
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ=='404':continue 
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['adult_yn']=='Y':continue 
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['won_yn'] =='Y' and XtvzKLIVyTAusDFRcPxgkOqhmrSjiw==XtvzKLIVyTAusDFRcPxgkOqhmrSjln:continue 
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjoH in exceptGroup:continue 
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjib!='EPG':
     if XtvzKLIVyTAusDFRcPxgkOqhmrSjiN and XtvzKLIVyTAusDFRcPxgkOqhmrSjib=='SHOP' :continue
     if XtvzKLIVyTAusDFRcPxgkOqhmrSjiY and XtvzKLIVyTAusDFRcPxgkOqhmrSjib=='AUDIO_MUSIC':continue
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoC.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[]
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC
 def Get_EpgInfo_Seezn(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,exceptGroup=[]):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoC=[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjie =[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoC=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_ChannelList_Seezn(exceptGroup)
  try:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjob=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_SEEZN+'/svc/menu/app6/api/epg_proglist' 
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjiJ in XtvzKLIVyTAusDFRcPxgkOqhmrSjoC:
    time.sleep(0.3)
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ =XtvzKLIVyTAusDFRcPxgkOqhmrSjiJ.get('channelid')
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoN={'ch_no':XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ}
    XtvzKLIVyTAusDFRcPxgkOqhmrSjiG=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Make_Header_Timestamp(timetype='2')
    XtvzKLIVyTAusDFRcPxgkOqhmrSjiG.update(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.SEEZN_HEADER)
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjoN,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjiG,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,redirects=XtvzKLIVyTAusDFRcPxgkOqhmrSjln)
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.status_code!=200:return[],[]
    XtvzKLIVyTAusDFRcPxgkOqhmrSjiB=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjiB.get('meta').get('code')!='200':return[],[]
    for XtvzKLIVyTAusDFRcPxgkOqhmrSjiE in XtvzKLIVyTAusDFRcPxgkOqhmrSjiB.get('data').get('list'):
     XtvzKLIVyTAusDFRcPxgkOqhmrSjiQ=XtvzKLIVyTAusDFRcPxgkOqhmrSjiE.get('start_ymd')
     XtvzKLIVyTAusDFRcPxgkOqhmrSjil=XtvzKLIVyTAusDFRcPxgkOqhmrSjiE.get('start_time').replace(':','')
     XtvzKLIVyTAusDFRcPxgkOqhmrSjip =XtvzKLIVyTAusDFRcPxgkOqhmrSjiE.get('end_time').replace(':','')
     if XtvzKLIVyTAusDFRcPxgkOqhmrSjlH(XtvzKLIVyTAusDFRcPxgkOqhmrSjil)>XtvzKLIVyTAusDFRcPxgkOqhmrSjlH(XtvzKLIVyTAusDFRcPxgkOqhmrSjip):
      XtvzKLIVyTAusDFRcPxgkOqhmrSjiW=datetime.datetime.strptime(XtvzKLIVyTAusDFRcPxgkOqhmrSjiQ,'%Y%m%d')+datetime.timedelta(days=XtvzKLIVyTAusDFRcPxgkOqhmrSjlH(1))
      XtvzKLIVyTAusDFRcPxgkOqhmrSjiW=XtvzKLIVyTAusDFRcPxgkOqhmrSjiW.strftime('%Y%m%d')
     else:
      XtvzKLIVyTAusDFRcPxgkOqhmrSjiW=XtvzKLIVyTAusDFRcPxgkOqhmrSjiQ
     XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'channelid':XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'title':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.xmlText(urllib.parse.unquote_plus(XtvzKLIVyTAusDFRcPxgkOqhmrSjiE.get('program_name'))),'startTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjiQ+XtvzKLIVyTAusDFRcPxgkOqhmrSjil+'00','endTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjiW+XtvzKLIVyTAusDFRcPxgkOqhmrSjip+'00','ott':'seezn'}
     XtvzKLIVyTAusDFRcPxgkOqhmrSjie.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[],[]
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC,XtvzKLIVyTAusDFRcPxgkOqhmrSjie
 def make_EpgDatetime_Tving(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,days=2):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjin=[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjiH=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.make_DateList(days=2,dateType='2')
  XtvzKLIVyTAusDFRcPxgkOqhmrSjdo=XtvzKLIVyTAusDFRcPxgkOqhmrSjlH(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjiH:
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjdi in XtvzKLIVyTAusDFRcPxgkOqhmrSjpo(8):
    XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'ndate':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE,'starttm':XtvzKLIVyTAusDFRcPxgkOqhmrSjod[XtvzKLIVyTAusDFRcPxgkOqhmrSjdi]['starttm'],'endtm':XtvzKLIVyTAusDFRcPxgkOqhmrSjod[XtvzKLIVyTAusDFRcPxgkOqhmrSjdi]['endtm']}
    XtvzKLIVyTAusDFRcPxgkOqhmrSjdl=XtvzKLIVyTAusDFRcPxgkOqhmrSjlH(XtvzKLIVyTAusDFRcPxgkOqhmrSjoE+XtvzKLIVyTAusDFRcPxgkOqhmrSjod[XtvzKLIVyTAusDFRcPxgkOqhmrSjdi]['starttm'])
    XtvzKLIVyTAusDFRcPxgkOqhmrSjdp=XtvzKLIVyTAusDFRcPxgkOqhmrSjlH(XtvzKLIVyTAusDFRcPxgkOqhmrSjoE+XtvzKLIVyTAusDFRcPxgkOqhmrSjod[XtvzKLIVyTAusDFRcPxgkOqhmrSjdi]['endtm'])
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjdo<=XtvzKLIVyTAusDFRcPxgkOqhmrSjdl or(XtvzKLIVyTAusDFRcPxgkOqhmrSjdl<XtvzKLIVyTAusDFRcPxgkOqhmrSjdo and XtvzKLIVyTAusDFRcPxgkOqhmrSjdo<XtvzKLIVyTAusDFRcPxgkOqhmrSjdp):
     XtvzKLIVyTAusDFRcPxgkOqhmrSjin.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjin
 def make_DateList(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,days=2,dateType='1'):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjiH=[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjdM =XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_Now_Datetime()
  if dateType=='1':
   XtvzKLIVyTAusDFRcPxgkOqhmrSjdM=XtvzKLIVyTAusDFRcPxgkOqhmrSjdM-datetime.timedelta(days=1)
  for i in XtvzKLIVyTAusDFRcPxgkOqhmrSjpo(days):
   XtvzKLIVyTAusDFRcPxgkOqhmrSjdf=XtvzKLIVyTAusDFRcPxgkOqhmrSjdM+datetime.timedelta(days=i)
   if dateType=='1':
    XtvzKLIVyTAusDFRcPxgkOqhmrSjiH.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjdf.strftime('%Y%m%d'))
   else:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjiH.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjdf.strftime('%Y%m%d'))
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjiH
 def make_Tving_ChannleGroup(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,XtvzKLIVyTAusDFRcPxgkOqhmrSjif):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjdU=[]
  i=0
  XtvzKLIVyTAusDFRcPxgkOqhmrSjdw=''
  for XtvzKLIVyTAusDFRcPxgkOqhmrSjdN in XtvzKLIVyTAusDFRcPxgkOqhmrSjif:
   if i==0:XtvzKLIVyTAusDFRcPxgkOqhmrSjdw=XtvzKLIVyTAusDFRcPxgkOqhmrSjdN
   else:XtvzKLIVyTAusDFRcPxgkOqhmrSjdw+=',%s'%(XtvzKLIVyTAusDFRcPxgkOqhmrSjdN)
   i+=1
   if i>=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.LIMIT_TVINGEPG:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjdU.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjdw)
    i=0
    XtvzKLIVyTAusDFRcPxgkOqhmrSjdw=''
  if XtvzKLIVyTAusDFRcPxgkOqhmrSjdw!='':
   XtvzKLIVyTAusDFRcPxgkOqhmrSjdU.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjdw)
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjdU
 def Get_ChannelImg_Tving(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,chid_list):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjid={}
  try:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjdY=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_Now_Datetime().strftime('%Y%m%d')
   XtvzKLIVyTAusDFRcPxgkOqhmrSjil =XtvzKLIVyTAusDFRcPxgkOqhmrSjod[6]['starttm'] 
   XtvzKLIVyTAusDFRcPxgkOqhmrSjip =XtvzKLIVyTAusDFRcPxgkOqhmrSjod[6]['endtm']
   XtvzKLIVyTAusDFRcPxgkOqhmrSjdU=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.make_Tving_ChannleGroup(chid_list)
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjdU:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjob=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_TVING+'/v2/media/schedules'
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoN={'pageNo':'1','pageSize':XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':XtvzKLIVyTAusDFRcPxgkOqhmrSjdY,'broadcastDate':XtvzKLIVyTAusDFRcPxgkOqhmrSjdY,'startBroadTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjil,'endBroadTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjip,'channelCode':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE}
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoN.update(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_DefaultParams_Tving())
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjoN,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB)
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
    if not('result' in XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['body']):return{}
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoB=XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['body']['result']
    for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjoB:
     for XtvzKLIVyTAusDFRcPxgkOqhmrSjdG in XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['image']:
      if XtvzKLIVyTAusDFRcPxgkOqhmrSjdG['code']=='CAIC0400':XtvzKLIVyTAusDFRcPxgkOqhmrSjid[XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['channel_code']]=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_TVINGIMG+XtvzKLIVyTAusDFRcPxgkOqhmrSjdG['url']
      elif XtvzKLIVyTAusDFRcPxgkOqhmrSjdG['code']=='CAIC1400':XtvzKLIVyTAusDFRcPxgkOqhmrSjid[XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['channel_code']]=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_TVINGIMG+XtvzKLIVyTAusDFRcPxgkOqhmrSjdG['url']
      elif XtvzKLIVyTAusDFRcPxgkOqhmrSjdG['code']=='CAIC1900':XtvzKLIVyTAusDFRcPxgkOqhmrSjid[XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['channel_code']]=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_TVINGIMG+XtvzKLIVyTAusDFRcPxgkOqhmrSjdG['url']
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return{}
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjid
 def Get_EpgInfo_Spotv(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,days=3,payyn=XtvzKLIVyTAusDFRcPxgkOqhmrSjln):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoC=[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjie =[]
  try:
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjol:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ =XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['videoId']
    XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'channelid':XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'channelnm':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.xmlText(XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['name']),'channelimg':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['logo'],'ott':'spotv','epgtype':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['epgtype'],'epgnm':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['epgnm']}
    if payyn==XtvzKLIVyTAusDFRcPxgkOqhmrSjln or XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['free']==XtvzKLIVyTAusDFRcPxgkOqhmrSjln:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjoC.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[],[]
  '''
  try:
   for now_day in days_list:
    url = self.API_SPOTV + '/api/v2/program/' + now_day
    response = self.callRequestCookies('Get', url, payload=None, params=None, headers=None, cookies=None )
    res_json = json.loads(response.text )
    for i_section in res_json:
     if find_list.get(i_section['channelId'] ) == None: continue
     temp_list = {'channelid' : find_list.get(i_section['channelId'] ) , 'title' : self.xmlText(i_section['title'] ) , 'startTime' : i_section['startTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'endTime' : i_section['endTime'].replace('-','').replace(' ','').replace(':','')+'00' , 'ott' : 'spotv' }
     epg_list.append(temp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  try:
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjiJ in XtvzKLIVyTAusDFRcPxgkOqhmrSjoC:
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjiJ['epgtype']=='spotvon':
     XtvzKLIVyTAusDFRcPxgkOqhmrSjdC=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_EpgInfo_Spotv_spotvon(XtvzKLIVyTAusDFRcPxgkOqhmrSjiJ['channelid'],XtvzKLIVyTAusDFRcPxgkOqhmrSjiJ['epgnm'],days)
     if XtvzKLIVyTAusDFRcPxgkOqhmrSjpi(XtvzKLIVyTAusDFRcPxgkOqhmrSjdC)>0:XtvzKLIVyTAusDFRcPxgkOqhmrSjie.extend(XtvzKLIVyTAusDFRcPxgkOqhmrSjdC)
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjiJ['epgtype']=='spotvnet':
     XtvzKLIVyTAusDFRcPxgkOqhmrSjdC=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_EpgInfo_Spotv_spotvnet(XtvzKLIVyTAusDFRcPxgkOqhmrSjiJ['channelid'],XtvzKLIVyTAusDFRcPxgkOqhmrSjiJ['epgnm'],days)
     if XtvzKLIVyTAusDFRcPxgkOqhmrSjpi(XtvzKLIVyTAusDFRcPxgkOqhmrSjdC)>0:XtvzKLIVyTAusDFRcPxgkOqhmrSjie.extend(XtvzKLIVyTAusDFRcPxgkOqhmrSjdC)
    time.sleep(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.SLEEP_TIME)
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[],[]
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC,XtvzKLIVyTAusDFRcPxgkOqhmrSjie
 def Get_EpgInfo_Spotv_spotvon(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,epgnm,days):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjie =[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjiH=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.make_DateList(days=days,dateType='1')
  XtvzKLIVyTAusDFRcPxgkOqhmrSjda=''
  try:
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjdb in XtvzKLIVyTAusDFRcPxgkOqhmrSjiH:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjob='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,XtvzKLIVyTAusDFRcPxgkOqhmrSjdb)
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB)
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
    for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'channelid':XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'title':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.xmlText(XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['title']),'startTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['sch_date'].replace('-','')+XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['sch_hour']).zfill(2)+XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['sch_min']+'00','ott':'spotv'}
     XtvzKLIVyTAusDFRcPxgkOqhmrSjie.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
    XtvzKLIVyTAusDFRcPxgkOqhmrSjda=XtvzKLIVyTAusDFRcPxgkOqhmrSjdb
   for i in XtvzKLIVyTAusDFRcPxgkOqhmrSjpo(XtvzKLIVyTAusDFRcPxgkOqhmrSjpi(XtvzKLIVyTAusDFRcPxgkOqhmrSjie)):
    if i>0:XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i-1]['endTime']=XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i]['startTime']
    if i==XtvzKLIVyTAusDFRcPxgkOqhmrSjpi(XtvzKLIVyTAusDFRcPxgkOqhmrSjie)-1: XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i]['endTime']=XtvzKLIVyTAusDFRcPxgkOqhmrSjda+'240000'
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[]
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjie
 def Get_EpgInfo_Spotv_spotvnet(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,epgnm,days):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjie =[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjiH=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.make_DateList(days=days,dateType='1')
  XtvzKLIVyTAusDFRcPxgkOqhmrSjda=''
  try:
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjdb in XtvzKLIVyTAusDFRcPxgkOqhmrSjiH:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjob='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,XtvzKLIVyTAusDFRcPxgkOqhmrSjdb)
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB)
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
    for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'channelid':XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'title':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.xmlText(XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['title']),'startTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['sch_date'].replace('-','')+XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['sch_hour']).zfill(2)+XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['sch_min']+'00','ott':'spotv'}
     XtvzKLIVyTAusDFRcPxgkOqhmrSjie.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
    XtvzKLIVyTAusDFRcPxgkOqhmrSjda=XtvzKLIVyTAusDFRcPxgkOqhmrSjdb
   for i in XtvzKLIVyTAusDFRcPxgkOqhmrSjpo(XtvzKLIVyTAusDFRcPxgkOqhmrSjpi(XtvzKLIVyTAusDFRcPxgkOqhmrSjie)):
    if i>0:XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i-1]['endTime']=XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i]['startTime']
    if i==XtvzKLIVyTAusDFRcPxgkOqhmrSjpi(XtvzKLIVyTAusDFRcPxgkOqhmrSjie)-1: XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i]['endTime']=XtvzKLIVyTAusDFRcPxgkOqhmrSjda+'240000'
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[]
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjie
 def Get_EpgInfo_Wavve(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,days=2,exceptGroup=[]):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoC =[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjie =[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjdM =XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_Now_Datetime()
  XtvzKLIVyTAusDFRcPxgkOqhmrSjde =XtvzKLIVyTAusDFRcPxgkOqhmrSjdM+datetime.timedelta(hours=-2)
  XtvzKLIVyTAusDFRcPxgkOqhmrSjdJ =XtvzKLIVyTAusDFRcPxgkOqhmrSjdM+datetime.timedelta(days=(days-1))
  if XtvzKLIVyTAusDFRcPxgkOqhmrSjlH(XtvzKLIVyTAusDFRcPxgkOqhmrSjde.strftime('%H'))<=3:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjdB=XtvzKLIVyTAusDFRcPxgkOqhmrSjde.strftime('%Y-%m-%d 00:00')
  else:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjdB=XtvzKLIVyTAusDFRcPxgkOqhmrSjde.strftime('%Y-%m-%d %H:00')
  XtvzKLIVyTAusDFRcPxgkOqhmrSjdE =XtvzKLIVyTAusDFRcPxgkOqhmrSjdJ.strftime('%Y-%m-%d 24:00')
  try:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjob=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_WAVVE+'/live/epgs'
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoN={'limit':XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':XtvzKLIVyTAusDFRcPxgkOqhmrSjdB,'enddatetime':XtvzKLIVyTAusDFRcPxgkOqhmrSjdE}
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoN.update(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_DefaultParams_Wavve())
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjoN,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB)
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
   XtvzKLIVyTAusDFRcPxgkOqhmrSjiB=XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['list']
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjiB:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ =XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['channelid']
    XtvzKLIVyTAusDFRcPxgkOqhmrSjoH=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.make_getGenre(XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'wavve')
    XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'channelid':XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,'channelnm':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.xmlText(XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['channelname']),'channelimg':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.HTTPTAG+XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['channelimage'],'ott':'wavve'}
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjoH not in exceptGroup:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjoC.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
    for XtvzKLIVyTAusDFRcPxgkOqhmrSjiE in XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['list']:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'channelid':XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['channelid'],'title':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.xmlText(XtvzKLIVyTAusDFRcPxgkOqhmrSjiE['title']),'startTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjiE['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjiE['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if XtvzKLIVyTAusDFRcPxgkOqhmrSjoH not in exceptGroup and XtvzKLIVyTAusDFRcPxgkOqhmrSjiE['starttime']!=XtvzKLIVyTAusDFRcPxgkOqhmrSjiE['endtime']:
      XtvzKLIVyTAusDFRcPxgkOqhmrSjie.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[],[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjdQ=XtvzKLIVyTAusDFRcPxgkOqhmrSjpi(XtvzKLIVyTAusDFRcPxgkOqhmrSjie)
  for i in(XtvzKLIVyTAusDFRcPxgkOqhmrSjpo(1,XtvzKLIVyTAusDFRcPxgkOqhmrSjdQ)):
   if XtvzKLIVyTAusDFRcPxgkOqhmrSjlH(XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i-1]['endTime'])+1==XtvzKLIVyTAusDFRcPxgkOqhmrSjlH(XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i]['startTime'])and XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i-1]['channelid']==XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i]['channelid']:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i-1]['endTime']=XtvzKLIVyTAusDFRcPxgkOqhmrSjie[i]['startTime']
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC,XtvzKLIVyTAusDFRcPxgkOqhmrSjie
 def Get_EpgInfo_Tving(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,days=2):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoC=[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjie =[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjdW =[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjdn =XtvzKLIVyTAusDFRcPxgkOqhmrSjop.make_EpgDatetime_Tving(days=days)
  XtvzKLIVyTAusDFRcPxgkOqhmrSjoC =XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_ChannelList_Tving()
  XtvzKLIVyTAusDFRcPxgkOqhmrSjdH=[]
  for i in XtvzKLIVyTAusDFRcPxgkOqhmrSjpo(XtvzKLIVyTAusDFRcPxgkOqhmrSjpi(XtvzKLIVyTAusDFRcPxgkOqhmrSjoC)):
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoC[i]['channelnm']=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.xmlText(XtvzKLIVyTAusDFRcPxgkOqhmrSjoC[i]['channelnm'])
   XtvzKLIVyTAusDFRcPxgkOqhmrSjdH.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjoC[i]['channelid'])
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlo=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.make_Tving_ChannleGroup(XtvzKLIVyTAusDFRcPxgkOqhmrSjdH)
  try:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjob=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.API_TVING+'/v2/media/schedules'
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjli in XtvzKLIVyTAusDFRcPxgkOqhmrSjdn:
    for XtvzKLIVyTAusDFRcPxgkOqhmrSjiJ in XtvzKLIVyTAusDFRcPxgkOqhmrSjlo:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjoN={'pageNo':'1','pageSize':XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':XtvzKLIVyTAusDFRcPxgkOqhmrSjli['ndate'],'broadcastDate':XtvzKLIVyTAusDFRcPxgkOqhmrSjli['ndate'],'startBroadTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjli['starttm'],'endBroadTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjli['endtm'],'channelCode':XtvzKLIVyTAusDFRcPxgkOqhmrSjiJ}
     XtvzKLIVyTAusDFRcPxgkOqhmrSjoN.update(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_DefaultParams_Tving())
     XtvzKLIVyTAusDFRcPxgkOqhmrSjoe=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.callRequestCookies('Get',XtvzKLIVyTAusDFRcPxgkOqhmrSjob,payload=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,params=XtvzKLIVyTAusDFRcPxgkOqhmrSjoN,headers=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB,cookies=XtvzKLIVyTAusDFRcPxgkOqhmrSjlB)
     XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ=json.loads(XtvzKLIVyTAusDFRcPxgkOqhmrSjoe.text)
     XtvzKLIVyTAusDFRcPxgkOqhmrSjoB=XtvzKLIVyTAusDFRcPxgkOqhmrSjoJ['body']['result']
     for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjoB:
      if 'schedules' not in XtvzKLIVyTAusDFRcPxgkOqhmrSjoE:continue
      if XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['schedules']==XtvzKLIVyTAusDFRcPxgkOqhmrSjlB:continue
      for XtvzKLIVyTAusDFRcPxgkOqhmrSjld in XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['schedules']:
       XtvzKLIVyTAusDFRcPxgkOqhmrSjio={'channelid':XtvzKLIVyTAusDFRcPxgkOqhmrSjld['schedule_code'],'title':XtvzKLIVyTAusDFRcPxgkOqhmrSjop.xmlText(XtvzKLIVyTAusDFRcPxgkOqhmrSjld['program']['name']['ko']),'startTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjld['broadcast_start_time']),'endTime':XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjld['broadcast_end_time']),'ott':'tving'}
       XtvzKLIVyTAusDFRcPxgkOqhmrSjlp=XtvzKLIVyTAusDFRcPxgkOqhmrSjld['schedule_code']+XtvzKLIVyTAusDFRcPxgkOqhmrSjlE(XtvzKLIVyTAusDFRcPxgkOqhmrSjld['broadcast_start_time'])
       if XtvzKLIVyTAusDFRcPxgkOqhmrSjlp in XtvzKLIVyTAusDFRcPxgkOqhmrSjdW:continue
       XtvzKLIVyTAusDFRcPxgkOqhmrSjdW.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjlp)
       XtvzKLIVyTAusDFRcPxgkOqhmrSjie.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
     time.sleep(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.SLEEP_TIME)
  except XtvzKLIVyTAusDFRcPxgkOqhmrSjlQ as exception:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlW(exception)
   return[],[]
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjoC,XtvzKLIVyTAusDFRcPxgkOqhmrSjie
 def make_getGenre(XtvzKLIVyTAusDFRcPxgkOqhmrSjop,XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,XtvzKLIVyTAusDFRcPxgkOqhmrSjlC):
  try:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjiM=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.INIT_CHANNEL.get(XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ+'.'+XtvzKLIVyTAusDFRcPxgkOqhmrSjlC).get('genre')
  except:
   XtvzKLIVyTAusDFRcPxgkOqhmrSjiM='-'
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjiM
 def make_base_allchannel_py(XtvzKLIVyTAusDFRcPxgkOqhmrSjop):
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlM =[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlf=[]
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlU=XtvzKLIVyTAusDFRcPxgkOqhmrSjpd()
  XtvzKLIVyTAusDFRcPxgkOqhmrSjio=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_ChannelList_Wavve()
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlM.extend(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
  XtvzKLIVyTAusDFRcPxgkOqhmrSjio=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_ChannelList_Tving()
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlM.extend(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
  XtvzKLIVyTAusDFRcPxgkOqhmrSjio=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_ChannelList_Seezn()
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlM.extend(XtvzKLIVyTAusDFRcPxgkOqhmrSjio)
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlW('1')
  for i in XtvzKLIVyTAusDFRcPxgkOqhmrSjpo(XtvzKLIVyTAusDFRcPxgkOqhmrSjpi(XtvzKLIVyTAusDFRcPxgkOqhmrSjlM)):
   if XtvzKLIVyTAusDFRcPxgkOqhmrSjlM[i]['genrenm']=='-':
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjlM[i]['ott']=='wavve':
     XtvzKLIVyTAusDFRcPxgkOqhmrSjiM=XtvzKLIVyTAusDFRcPxgkOqhmrSjop.Get_ChanneGenrename_Wavve(XtvzKLIVyTAusDFRcPxgkOqhmrSjlM[i]['channelid'])
     if XtvzKLIVyTAusDFRcPxgkOqhmrSjiM not in XtvzKLIVyTAusDFRcPxgkOqhmrSjlU:XtvzKLIVyTAusDFRcPxgkOqhmrSjlU.add(XtvzKLIVyTAusDFRcPxgkOqhmrSjiM)
     time.sleep(XtvzKLIVyTAusDFRcPxgkOqhmrSjop.SLEEP_TIME)
    elif XtvzKLIVyTAusDFRcPxgkOqhmrSjlM[i]['ott']=='spotv':
     XtvzKLIVyTAusDFRcPxgkOqhmrSjiM='스포츠'
    else:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjiM='-'
    XtvzKLIVyTAusDFRcPxgkOqhmrSjlM[i]['genrenm']=XtvzKLIVyTAusDFRcPxgkOqhmrSjiM
   else:
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjlM[i]['genrenm']not in XtvzKLIVyTAusDFRcPxgkOqhmrSjlU:XtvzKLIVyTAusDFRcPxgkOqhmrSjlU.add(XtvzKLIVyTAusDFRcPxgkOqhmrSjlM[i]['genrenm'])
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlU.add('-')
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlW('2')
  for XtvzKLIVyTAusDFRcPxgkOqhmrSjlw in XtvzKLIVyTAusDFRcPxgkOqhmrSjlU:
   for XtvzKLIVyTAusDFRcPxgkOqhmrSjlN in XtvzKLIVyTAusDFRcPxgkOqhmrSjlM:
    if XtvzKLIVyTAusDFRcPxgkOqhmrSjlN['genrenm']==XtvzKLIVyTAusDFRcPxgkOqhmrSjlw:
     XtvzKLIVyTAusDFRcPxgkOqhmrSjlf.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjlN)
  for XtvzKLIVyTAusDFRcPxgkOqhmrSjlN in XtvzKLIVyTAusDFRcPxgkOqhmrSjlM:
   if XtvzKLIVyTAusDFRcPxgkOqhmrSjlN['genrenm']not in XtvzKLIVyTAusDFRcPxgkOqhmrSjlU:
    XtvzKLIVyTAusDFRcPxgkOqhmrSjlf.append(XtvzKLIVyTAusDFRcPxgkOqhmrSjlN)
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlW('3')
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlY='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(XtvzKLIVyTAusDFRcPxgkOqhmrSjlY):os.remove(XtvzKLIVyTAusDFRcPxgkOqhmrSjlY)
  fp=XtvzKLIVyTAusDFRcPxgkOqhmrSjpl(XtvzKLIVyTAusDFRcPxgkOqhmrSjlY,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  XtvzKLIVyTAusDFRcPxgkOqhmrSjlG=XtvzKLIVyTAusDFRcPxgkOqhmrSjpi(XtvzKLIVyTAusDFRcPxgkOqhmrSjlf)
  i=0
  for XtvzKLIVyTAusDFRcPxgkOqhmrSjoE in XtvzKLIVyTAusDFRcPxgkOqhmrSjlf:
   i+=1
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ =XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['channelid']
   XtvzKLIVyTAusDFRcPxgkOqhmrSjoW =XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['channelnm']
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlC =XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['ott']
   XtvzKLIVyTAusDFRcPxgkOqhmrSjla ='%s.%s'%(XtvzKLIVyTAusDFRcPxgkOqhmrSjoQ,XtvzKLIVyTAusDFRcPxgkOqhmrSjlC)
   XtvzKLIVyTAusDFRcPxgkOqhmrSjiM =XtvzKLIVyTAusDFRcPxgkOqhmrSjoE['genrenm']
   XtvzKLIVyTAusDFRcPxgkOqhmrSjlb='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(XtvzKLIVyTAusDFRcPxgkOqhmrSjla,XtvzKLIVyTAusDFRcPxgkOqhmrSjoW,XtvzKLIVyTAusDFRcPxgkOqhmrSjiM)
   if i<XtvzKLIVyTAusDFRcPxgkOqhmrSjlG:
    fp.write(XtvzKLIVyTAusDFRcPxgkOqhmrSjlb+',\n')
   else:
    fp.write(XtvzKLIVyTAusDFRcPxgkOqhmrSjlb+'\n')
  fp.write('}\n')
  fp.close()
  return XtvzKLIVyTAusDFRcPxgkOqhmrSjlU
# Created by pyminifier (https://github.com/liftoff/pyminifier)
