__author__="NightRain"
BjLOtwEoxuDMRCeqQnakVWsrFmGvdA=object
BjLOtwEoxuDMRCeqQnakVWsrFmGvdI=False
BjLOtwEoxuDMRCeqQnakVWsrFmGvdf=None
BjLOtwEoxuDMRCeqQnakVWsrFmGvPX=True
BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ=len
BjLOtwEoxuDMRCeqQnakVWsrFmGvPd=str
BjLOtwEoxuDMRCeqQnakVWsrFmGvPb=open
BjLOtwEoxuDMRCeqQnakVWsrFmGvPp=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
BjLOtwEoxuDMRCeqQnakVWsrFmGvXd=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (시즌)','mode':'ADD_M3U','sType':'seezn','sName':'시즌'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
BjLOtwEoxuDMRCeqQnakVWsrFmGvXP=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class BjLOtwEoxuDMRCeqQnakVWsrFmGvXJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvdA):
 def __init__(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb,BjLOtwEoxuDMRCeqQnakVWsrFmGvXp,BjLOtwEoxuDMRCeqQnakVWsrFmGvXU,BjLOtwEoxuDMRCeqQnakVWsrFmGvXy):
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb._addon_url =BjLOtwEoxuDMRCeqQnakVWsrFmGvXp
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb._addon_handle =BjLOtwEoxuDMRCeqQnakVWsrFmGvXU
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.main_params =BjLOtwEoxuDMRCeqQnakVWsrFmGvXy
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_FILE_PATH ='' 
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_FILE_NAME ='' 
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVE =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONTVING =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSPOTV =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZN =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVERADIO=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVEHOME =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONRELIGION =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSPOTVPAY =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZNPAY =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZNHOME =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZNRADIO=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_DISPLAYNM =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_AUTORESTART =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj =XtvzKLIVyTAusDFRcPxgkOqhmrSjoi() 
 def addon_noti(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb,sting):
  try:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXl=xbmcgui.Dialog()
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXl.notification(__addonname__,sting)
  except:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdf
 def addon_log(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb,string):
  try:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXK=string.encode('utf-8','ignore')
  except:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXK='addonException: addon_log'
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXN=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,BjLOtwEoxuDMRCeqQnakVWsrFmGvXK),level=BjLOtwEoxuDMRCeqQnakVWsrFmGvXN)
 def get_keyboard_input(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb,BjLOtwEoxuDMRCeqQnakVWsrFmGvXz):
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXh=BjLOtwEoxuDMRCeqQnakVWsrFmGvdf
  kb=xbmc.Keyboard()
  kb.setHeading(BjLOtwEoxuDMRCeqQnakVWsrFmGvXz)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXh=kb.getText()
  return BjLOtwEoxuDMRCeqQnakVWsrFmGvXh
 def add_dir(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb,label,sublabel='',img='',infoLabels=BjLOtwEoxuDMRCeqQnakVWsrFmGvdf,isFolder=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX,params='',isLink=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI,ContextMenu=BjLOtwEoxuDMRCeqQnakVWsrFmGvdf):
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXg='%s?%s'%(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb._addon_url,urllib.parse.urlencode(params))
  if sublabel:BjLOtwEoxuDMRCeqQnakVWsrFmGvXz='%s < %s >'%(label,sublabel)
  else: BjLOtwEoxuDMRCeqQnakVWsrFmGvXz=label
  if not img:img='DefaultFolder.png'
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXY=xbmcgui.ListItem(BjLOtwEoxuDMRCeqQnakVWsrFmGvXz)
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXY.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:BjLOtwEoxuDMRCeqQnakVWsrFmGvXY.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXY.setProperty('IsPlayable','true')
  if ContextMenu:BjLOtwEoxuDMRCeqQnakVWsrFmGvXY.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb._addon_handle,BjLOtwEoxuDMRCeqQnakVWsrFmGvXg,BjLOtwEoxuDMRCeqQnakVWsrFmGvXY,isFolder)
 def make_M3u_Filename(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb,tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_FILE_PATH+BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb,tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_FILE_PATH+BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_FILE_NAME+'.xml'
 def dp_Main_List(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb):
  for BjLOtwEoxuDMRCeqQnakVWsrFmGvXH in BjLOtwEoxuDMRCeqQnakVWsrFmGvXd:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXz=BjLOtwEoxuDMRCeqQnakVWsrFmGvXH.get('title')
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXT=''
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXi={'mode':BjLOtwEoxuDMRCeqQnakVWsrFmGvXH.get('mode'),'sType':BjLOtwEoxuDMRCeqQnakVWsrFmGvXH.get('sType'),'sName':BjLOtwEoxuDMRCeqQnakVWsrFmGvXH.get('sName')}
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvXH.get('mode')=='XXX':
    BjLOtwEoxuDMRCeqQnakVWsrFmGvXc=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
    BjLOtwEoxuDMRCeqQnakVWsrFmGvXA =BjLOtwEoxuDMRCeqQnakVWsrFmGvPX
   else:
    BjLOtwEoxuDMRCeqQnakVWsrFmGvXc=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX
    BjLOtwEoxuDMRCeqQnakVWsrFmGvXA =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXI=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvXH.get('mode')=='ADD_M3U':
    if BjLOtwEoxuDMRCeqQnakVWsrFmGvXH.get('sType')=='wavve' and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVE==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:BjLOtwEoxuDMRCeqQnakVWsrFmGvXI=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
    if BjLOtwEoxuDMRCeqQnakVWsrFmGvXH.get('sType')=='tving' and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONTVING==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:BjLOtwEoxuDMRCeqQnakVWsrFmGvXI=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
    if BjLOtwEoxuDMRCeqQnakVWsrFmGvXH.get('sType')=='spotv' and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSPOTV==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:BjLOtwEoxuDMRCeqQnakVWsrFmGvXI=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
    if BjLOtwEoxuDMRCeqQnakVWsrFmGvXH.get('sType')=='seezn' and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZN==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:BjLOtwEoxuDMRCeqQnakVWsrFmGvXI=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvXI==BjLOtwEoxuDMRCeqQnakVWsrFmGvPX:
    if 'icon' in BjLOtwEoxuDMRCeqQnakVWsrFmGvXH:BjLOtwEoxuDMRCeqQnakVWsrFmGvXT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',BjLOtwEoxuDMRCeqQnakVWsrFmGvXH.get('icon')) 
    BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.add_dir(BjLOtwEoxuDMRCeqQnakVWsrFmGvXz,sublabel='',img=BjLOtwEoxuDMRCeqQnakVWsrFmGvXT,infoLabels=BjLOtwEoxuDMRCeqQnakVWsrFmGvdf,isFolder=BjLOtwEoxuDMRCeqQnakVWsrFmGvXc,params=BjLOtwEoxuDMRCeqQnakVWsrFmGvXi,isLink=BjLOtwEoxuDMRCeqQnakVWsrFmGvXA)
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvXd)>0:xbmcplugin.endOfDirectory(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb._addon_handle,cacheToDisc=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX)
 def dp_Delete_M3u(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb,args):
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXl=xbmcgui.Dialog()
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJX=BjLOtwEoxuDMRCeqQnakVWsrFmGvXl.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvJX==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:sys.exit()
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJd=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_M3u_Filename(tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI)
  if xbmcvfs.exists(BjLOtwEoxuDMRCeqQnakVWsrFmGvJd):
   if xbmcvfs.delete(BjLOtwEoxuDMRCeqQnakVWsrFmGvJd)==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:
    BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_noti(__language__(30910).encode('utf-8'))
    return
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb,args):
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=args.get('sType')
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJb=args.get('sName')
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXl=xbmcgui.Dialog()
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJX=BjLOtwEoxuDMRCeqQnakVWsrFmGvXl.yesno((BjLOtwEoxuDMRCeqQnakVWsrFmGvJb+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvJX==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:sys.exit()
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJp =[]
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJU =[]
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJd=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_M3u_Filename(tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX)
  if os.path.isfile(BjLOtwEoxuDMRCeqQnakVWsrFmGvJd):os.remove(BjLOtwEoxuDMRCeqQnakVWsrFmGvJd)
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='all':
   BjLOtwEoxuDMRCeqQnakVWsrFmGvJd=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_M3u_Filename(tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI)
   if xbmcvfs.exists(BjLOtwEoxuDMRCeqQnakVWsrFmGvJd):
    if xbmcvfs.delete(BjLOtwEoxuDMRCeqQnakVWsrFmGvJd)==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:
     BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvJy=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_M3u_Filename(tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI)
   if xbmcvfs.exists(BjLOtwEoxuDMRCeqQnakVWsrFmGvJy):
    BjLOtwEoxuDMRCeqQnakVWsrFmGvJS=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_M3u_Filename(tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX)
    xbmcvfs.copy(BjLOtwEoxuDMRCeqQnakVWsrFmGvJy,BjLOtwEoxuDMRCeqQnakVWsrFmGvJS)
  if(BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='wavve' or BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='all')and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVE:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvJl=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.Get_ChannelList_Wavve(exceptGroup=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_EexceptGroup_Wavve())
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)!=0:BjLOtwEoxuDMRCeqQnakVWsrFmGvJp.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_log('wavve cnt ----> '+BjLOtwEoxuDMRCeqQnakVWsrFmGvPd(BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)))
  if(BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='tving' or BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='all')and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONTVING:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvJl=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.Get_ChannelList_Tving()
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)!=0:BjLOtwEoxuDMRCeqQnakVWsrFmGvJp.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_log('tving cnt ----> '+BjLOtwEoxuDMRCeqQnakVWsrFmGvPd(BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)))
  if(BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='spotv' or BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='all')and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSPOTV:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvJl=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.Get_ChannelList_Spotv(payyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSPOTVPAY)
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)!=0:BjLOtwEoxuDMRCeqQnakVWsrFmGvJp.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_log('spotv cnt ----> '+BjLOtwEoxuDMRCeqQnakVWsrFmGvPd(BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)))
  if(BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='seezn' or BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='all')and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZN:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvJl=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.Get_ChannelList_Seezn(exceptGroup=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_EexceptGroup_Seezn())
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)!=0:BjLOtwEoxuDMRCeqQnakVWsrFmGvJp.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_log('seezn cnt ----> '+BjLOtwEoxuDMRCeqQnakVWsrFmGvPd(BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvJl)))
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvJp)==0:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_noti(__language__(30909).encode('utf8'))
   return
  for BjLOtwEoxuDMRCeqQnakVWsrFmGvJK in BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.INIT_GENRESORT:
   for BjLOtwEoxuDMRCeqQnakVWsrFmGvJN in BjLOtwEoxuDMRCeqQnakVWsrFmGvJp:
    if BjLOtwEoxuDMRCeqQnakVWsrFmGvJN['genrenm']==BjLOtwEoxuDMRCeqQnakVWsrFmGvJK:
     BjLOtwEoxuDMRCeqQnakVWsrFmGvJU.append(BjLOtwEoxuDMRCeqQnakVWsrFmGvJN)
  for BjLOtwEoxuDMRCeqQnakVWsrFmGvJN in BjLOtwEoxuDMRCeqQnakVWsrFmGvJp:
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvJN['genrenm']not in BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.INIT_GENRESORT:
    BjLOtwEoxuDMRCeqQnakVWsrFmGvJU.append(BjLOtwEoxuDMRCeqQnakVWsrFmGvJN)
  try:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvJd=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_M3u_Filename(tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX)
   if os.path.isfile(BjLOtwEoxuDMRCeqQnakVWsrFmGvJd):
    fp=BjLOtwEoxuDMRCeqQnakVWsrFmGvPb(BjLOtwEoxuDMRCeqQnakVWsrFmGvJd,'a',-1,'utf-8')
   else:
    fp=BjLOtwEoxuDMRCeqQnakVWsrFmGvPb(BjLOtwEoxuDMRCeqQnakVWsrFmGvJd,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for BjLOtwEoxuDMRCeqQnakVWsrFmGvJh in BjLOtwEoxuDMRCeqQnakVWsrFmGvJU:
    BjLOtwEoxuDMRCeqQnakVWsrFmGvJg =BjLOtwEoxuDMRCeqQnakVWsrFmGvJh['channelid']
    BjLOtwEoxuDMRCeqQnakVWsrFmGvJz =BjLOtwEoxuDMRCeqQnakVWsrFmGvJh['channelnm']
    BjLOtwEoxuDMRCeqQnakVWsrFmGvJY=BjLOtwEoxuDMRCeqQnakVWsrFmGvJh['channelimg']
    BjLOtwEoxuDMRCeqQnakVWsrFmGvJH =BjLOtwEoxuDMRCeqQnakVWsrFmGvJh['ott']
    BjLOtwEoxuDMRCeqQnakVWsrFmGvJT ='%s.%s'%(BjLOtwEoxuDMRCeqQnakVWsrFmGvJg,BjLOtwEoxuDMRCeqQnakVWsrFmGvJH)
    BjLOtwEoxuDMRCeqQnakVWsrFmGvJi=BjLOtwEoxuDMRCeqQnakVWsrFmGvJh['genrenm']
    if BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_DISPLAYNM:
     BjLOtwEoxuDMRCeqQnakVWsrFmGvJz='%s (%s)'%(BjLOtwEoxuDMRCeqQnakVWsrFmGvJz,BjLOtwEoxuDMRCeqQnakVWsrFmGvJH)
    if BjLOtwEoxuDMRCeqQnakVWsrFmGvJi=='라디오/음악':
     BjLOtwEoxuDMRCeqQnakVWsrFmGvJc='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(BjLOtwEoxuDMRCeqQnakVWsrFmGvJT,BjLOtwEoxuDMRCeqQnakVWsrFmGvJz,BjLOtwEoxuDMRCeqQnakVWsrFmGvJi,BjLOtwEoxuDMRCeqQnakVWsrFmGvJY,BjLOtwEoxuDMRCeqQnakVWsrFmGvJz)
    else:
     BjLOtwEoxuDMRCeqQnakVWsrFmGvJc='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(BjLOtwEoxuDMRCeqQnakVWsrFmGvJT,BjLOtwEoxuDMRCeqQnakVWsrFmGvJz,BjLOtwEoxuDMRCeqQnakVWsrFmGvJi,BjLOtwEoxuDMRCeqQnakVWsrFmGvJY,BjLOtwEoxuDMRCeqQnakVWsrFmGvJz)
    if BjLOtwEoxuDMRCeqQnakVWsrFmGvJH=='wavve':
     BjLOtwEoxuDMRCeqQnakVWsrFmGvJA ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(BjLOtwEoxuDMRCeqQnakVWsrFmGvJg)
    elif BjLOtwEoxuDMRCeqQnakVWsrFmGvJH=='tving':
     BjLOtwEoxuDMRCeqQnakVWsrFmGvJA ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(BjLOtwEoxuDMRCeqQnakVWsrFmGvJg)
    elif BjLOtwEoxuDMRCeqQnakVWsrFmGvJH=='spotv':
     BjLOtwEoxuDMRCeqQnakVWsrFmGvJA ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(BjLOtwEoxuDMRCeqQnakVWsrFmGvJg)
    elif BjLOtwEoxuDMRCeqQnakVWsrFmGvJH=='seezn':
     BjLOtwEoxuDMRCeqQnakVWsrFmGvJI='128' if BjLOtwEoxuDMRCeqQnakVWsrFmGvJi=='라디오/음악' else '4000'
     BjLOtwEoxuDMRCeqQnakVWsrFmGvJA ='plugin://plugin.video.seeznm/?mode=LIVE&mediacode=%s&bitrate=%s\n'%(BjLOtwEoxuDMRCeqQnakVWsrFmGvJg,BjLOtwEoxuDMRCeqQnakVWsrFmGvJI)
    fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvJc)
    fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvJA)
   fp.close()
  except:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_noti(__language__(30910).encode('utf8'))
   return
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJy=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_M3u_Filename(tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX)
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJS=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_M3u_Filename(tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI)
  if xbmcvfs.copy(BjLOtwEoxuDMRCeqQnakVWsrFmGvJy,BjLOtwEoxuDMRCeqQnakVWsrFmGvJS):
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_noti((BjLOtwEoxuDMRCeqQnakVWsrFmGvJb+' '+__language__(30908)).encode('utf8'))
  else:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_noti(__language__(30910).encode('utf-8'))
 def dp_Make_Epg(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb,args):
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=args.get('sType')
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJb=args.get('sName')
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJf=args.get('sNoti')
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvJf!='N':
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXl=xbmcgui.Dialog()
   BjLOtwEoxuDMRCeqQnakVWsrFmGvJX=BjLOtwEoxuDMRCeqQnakVWsrFmGvXl.yesno((BjLOtwEoxuDMRCeqQnakVWsrFmGvJb+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvJX==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:sys.exit()
  BjLOtwEoxuDMRCeqQnakVWsrFmGvdX=[]
  BjLOtwEoxuDMRCeqQnakVWsrFmGvdJ=[]
  if(BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='wavve' or BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='all')and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVE:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdP,BjLOtwEoxuDMRCeqQnakVWsrFmGvdb=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_EexceptGroup_Wavve())
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvdb)!=0:
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdX.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvdP)
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdJ.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvdb)
  if(BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='tving' or BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='all')and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONTVING:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdP,BjLOtwEoxuDMRCeqQnakVWsrFmGvdb=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.Get_EpgInfo_Tving()
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvdb)!=0:
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdX.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvdP)
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdJ.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvdb)
  if(BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='spotv' or BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='all')and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSPOTV:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdP,BjLOtwEoxuDMRCeqQnakVWsrFmGvdb=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.Get_EpgInfo_Spotv(payyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSPOTVPAY)
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvdb)!=0:
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdX.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvdP)
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdJ.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvdb)
  if(BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='seezn' or BjLOtwEoxuDMRCeqQnakVWsrFmGvJP=='all')and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZN:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdP,BjLOtwEoxuDMRCeqQnakVWsrFmGvdb=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.Get_EpgInfo_Seezn(exceptGroup=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_EexceptGroup_Seezn())
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvdb)!=0:
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdX.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvdP)
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdJ.extend(BjLOtwEoxuDMRCeqQnakVWsrFmGvdb)
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvPJ(BjLOtwEoxuDMRCeqQnakVWsrFmGvdJ)==0:
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvJf!='N':BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvJd=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_Epg_Filename(tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX)
   fp=BjLOtwEoxuDMRCeqQnakVWsrFmGvPb(BjLOtwEoxuDMRCeqQnakVWsrFmGvJd,'w',-1,'utf-8')
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdp='<?xml version="1.0" encoding="UTF-8"?>\n'
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdU='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdy='<tv generator-info-name="boritv_epg">\n\n'
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdS='\n</tv>\n'
   fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvdp)
   fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvdU)
   fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvdy)
   for BjLOtwEoxuDMRCeqQnakVWsrFmGvdl in BjLOtwEoxuDMRCeqQnakVWsrFmGvdX:
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdK='  <channel id="%s.%s">\n' %(BjLOtwEoxuDMRCeqQnakVWsrFmGvdl.get('channelid'),BjLOtwEoxuDMRCeqQnakVWsrFmGvdl.get('ott'))
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdN='    <display-name>%s</display-name>\n'%(BjLOtwEoxuDMRCeqQnakVWsrFmGvdl.get('channelnm'))
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdh='    <icon src="%s" />\n' %(BjLOtwEoxuDMRCeqQnakVWsrFmGvdl.get('channelimg'))
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdg='  </channel>\n\n'
    fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvdK)
    fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvdN)
    fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvdh)
    fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvdg)
   for BjLOtwEoxuDMRCeqQnakVWsrFmGvdl in BjLOtwEoxuDMRCeqQnakVWsrFmGvdJ:
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdK='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(BjLOtwEoxuDMRCeqQnakVWsrFmGvdl.get('startTime'),BjLOtwEoxuDMRCeqQnakVWsrFmGvdl.get('endTime'),BjLOtwEoxuDMRCeqQnakVWsrFmGvdl.get('channelid'),BjLOtwEoxuDMRCeqQnakVWsrFmGvdl.get('ott'))
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdN='    <title lang="kr">%s</title>\n' %(BjLOtwEoxuDMRCeqQnakVWsrFmGvdl.get('title'))
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdh='  </programme>\n\n'
    fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvdK)
    fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvdN)
    fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvdh)
   fp.write(BjLOtwEoxuDMRCeqQnakVWsrFmGvdS)
   fp.close()
  except:
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvJf!='N':BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_noti(__language__(30910).encode('utf8'))
   return
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.MakeEpg_SaveJson()
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJy=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_Epg_Filename(tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX)
  BjLOtwEoxuDMRCeqQnakVWsrFmGvJS=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.make_Epg_Filename(tempyn=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI)
  if xbmcvfs.copy(BjLOtwEoxuDMRCeqQnakVWsrFmGvJy,BjLOtwEoxuDMRCeqQnakVWsrFmGvJS):
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvJf!='N':BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_noti((BjLOtwEoxuDMRCeqQnakVWsrFmGvJb+' '+__language__(30912)).encode('utf8'))
  else:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_AUTORESTART:
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdz=xbmcaddon.Addon('pvr.iptvsimple')
    BjLOtwEoxuDMRCeqQnakVWsrFmGvdz.setSetting('anything','anything')
  except:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdf 
 def make_EexceptGroup_Wavve(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb):
  BjLOtwEoxuDMRCeqQnakVWsrFmGvdY=[]
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVERADIO==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdY.append('라디오/음악')
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVEHOME==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdY.append('홈쇼핑')
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONRELIGION==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdY.append('종교')
  return BjLOtwEoxuDMRCeqQnakVWsrFmGvdY
 def make_EexceptGroup_Seezn(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb):
  BjLOtwEoxuDMRCeqQnakVWsrFmGvdY=[]
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZNRADIO==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdY.append('라디오/음악')
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZNHOME==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdY.append('홈쇼핑')
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZNPAY==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdY.append('won')
  return BjLOtwEoxuDMRCeqQnakVWsrFmGvdY
 def get_radio_list(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb):
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVERADIO==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:return[]
  BjLOtwEoxuDMRCeqQnakVWsrFmGvdH=[{'broadcastid':'46584','genre':'10'}]
  return BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.Get_ChannelList_WavveExcept(BjLOtwEoxuDMRCeqQnakVWsrFmGvdH)
 def check_config(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb):
  BjLOtwEoxuDMRCeqQnakVWsrFmGvdT=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVE =BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('onWavve')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONTVING =BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('onTvng')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSPOTV =BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZN =BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('onSeezn')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVERADIO=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('onWavveRadio')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVEHOME =BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('onWavveHome')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONRELIGION =BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('onWavveReligion')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSPOTVPAY =BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('onSpotvPay')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZNPAY =BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('onSeeznPay')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZNHOME =BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('onSeeznHome')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZNRADIO=BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('onSeeznRadio')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_DISPLAYNM =BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('displayOTTnm')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_AUTORESTART =BjLOtwEoxuDMRCeqQnakVWsrFmGvPX if __addon__.getSetting('autoRestart')=='true' else BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_FILE_PATH=='' or BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_FILE_NAME=='':BjLOtwEoxuDMRCeqQnakVWsrFmGvdT=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONWAVVE==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONTVING==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI and BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.M3U_ONSEEZN==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:BjLOtwEoxuDMRCeqQnakVWsrFmGvdT=BjLOtwEoxuDMRCeqQnakVWsrFmGvdI
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvdT==BjLOtwEoxuDMRCeqQnakVWsrFmGvdI:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXl=xbmcgui.Dialog()
   BjLOtwEoxuDMRCeqQnakVWsrFmGvJX=BjLOtwEoxuDMRCeqQnakVWsrFmGvXl.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if BjLOtwEoxuDMRCeqQnakVWsrFmGvJX==BjLOtwEoxuDMRCeqQnakVWsrFmGvPX:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb):
  BjLOtwEoxuDMRCeqQnakVWsrFmGvdi={'date_makeepg':BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=BjLOtwEoxuDMRCeqQnakVWsrFmGvPb(BjLOtwEoxuDMRCeqQnakVWsrFmGvXP,'w',-1,'utf-8')
   json.dump(BjLOtwEoxuDMRCeqQnakVWsrFmGvdi,fp)
   fp.close()
  except BjLOtwEoxuDMRCeqQnakVWsrFmGvPp as exception:
   return
 def boritv_main(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb):
  BjLOtwEoxuDMRCeqQnakVWsrFmGvdc=BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.main_params.get('mode',BjLOtwEoxuDMRCeqQnakVWsrFmGvdf)
  BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.check_config()
  if BjLOtwEoxuDMRCeqQnakVWsrFmGvdc is BjLOtwEoxuDMRCeqQnakVWsrFmGvdf:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.dp_Main_List()
  elif BjLOtwEoxuDMRCeqQnakVWsrFmGvdc=='DEL_M3U':
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.dp_Delete_M3u(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.main_params)
  elif BjLOtwEoxuDMRCeqQnakVWsrFmGvdc=='ADD_M3U':
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.dp_MakeAdd_M3u(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.main_params)
  elif BjLOtwEoxuDMRCeqQnakVWsrFmGvdc=='ADD_EPG':
   BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.dp_Make_Epg(BjLOtwEoxuDMRCeqQnakVWsrFmGvXb.main_params)
  else:
   BjLOtwEoxuDMRCeqQnakVWsrFmGvdf
# Created by pyminifier (https://github.com/liftoff/pyminifier)
