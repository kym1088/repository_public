__author__="NightRain"
sJFkugfnBUIKHlqeGVazRWCrMioTmx=object
sJFkugfnBUIKHlqeGVazRWCrMioTmS=False
sJFkugfnBUIKHlqeGVazRWCrMioTmX=None
sJFkugfnBUIKHlqeGVazRWCrMioTmv=True
sJFkugfnBUIKHlqeGVazRWCrMioTmA=len
sJFkugfnBUIKHlqeGVazRWCrMioTmh=str
sJFkugfnBUIKHlqeGVazRWCrMioTPb=open
sJFkugfnBUIKHlqeGVazRWCrMioTPY=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
sJFkugfnBUIKHlqeGVazRWCrMioTbm=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
sJFkugfnBUIKHlqeGVazRWCrMioTbP=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class sJFkugfnBUIKHlqeGVazRWCrMioTbY(sJFkugfnBUIKHlqeGVazRWCrMioTmx):
 def __init__(sJFkugfnBUIKHlqeGVazRWCrMioTby,sJFkugfnBUIKHlqeGVazRWCrMioTbE,sJFkugfnBUIKHlqeGVazRWCrMioTbQ,sJFkugfnBUIKHlqeGVazRWCrMioTbw):
  sJFkugfnBUIKHlqeGVazRWCrMioTby._addon_url =sJFkugfnBUIKHlqeGVazRWCrMioTbE
  sJFkugfnBUIKHlqeGVazRWCrMioTby._addon_handle =sJFkugfnBUIKHlqeGVazRWCrMioTbQ
  sJFkugfnBUIKHlqeGVazRWCrMioTby.main_params =sJFkugfnBUIKHlqeGVazRWCrMioTbw
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_FILE_PATH ='' 
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_FILE_NAME ='' 
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVE =sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONTVING =sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONSPOTV =sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVERADIO=sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVEHOME =sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONRELIGION =sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONSPOTVPAY =sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_DISPLAYNM =sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_AUTORESTART =sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.BoritvObj =PnkltNBCbVywjmaYpiAIezWLxosucU() 
 def addon_noti(sJFkugfnBUIKHlqeGVazRWCrMioTby,sting):
  try:
   sJFkugfnBUIKHlqeGVazRWCrMioTbN=xbmcgui.Dialog()
   sJFkugfnBUIKHlqeGVazRWCrMioTbN.notification(__addonname__,sting)
  except:
   sJFkugfnBUIKHlqeGVazRWCrMioTmX
 def addon_log(sJFkugfnBUIKHlqeGVazRWCrMioTby,string):
  try:
   sJFkugfnBUIKHlqeGVazRWCrMioTbO=string.encode('utf-8','ignore')
  except:
   sJFkugfnBUIKHlqeGVazRWCrMioTbO='addonException: addon_log'
  sJFkugfnBUIKHlqeGVazRWCrMioTbD=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,sJFkugfnBUIKHlqeGVazRWCrMioTbO),level=sJFkugfnBUIKHlqeGVazRWCrMioTbD)
 def get_keyboard_input(sJFkugfnBUIKHlqeGVazRWCrMioTby,sJFkugfnBUIKHlqeGVazRWCrMioTbc):
  sJFkugfnBUIKHlqeGVazRWCrMioTbj=sJFkugfnBUIKHlqeGVazRWCrMioTmX
  kb=xbmc.Keyboard()
  kb.setHeading(sJFkugfnBUIKHlqeGVazRWCrMioTbc)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   sJFkugfnBUIKHlqeGVazRWCrMioTbj=kb.getText()
  return sJFkugfnBUIKHlqeGVazRWCrMioTbj
 def add_dir(sJFkugfnBUIKHlqeGVazRWCrMioTby,label,sublabel='',img='',infoLabels=sJFkugfnBUIKHlqeGVazRWCrMioTmX,isFolder=sJFkugfnBUIKHlqeGVazRWCrMioTmv,params=''):
  sJFkugfnBUIKHlqeGVazRWCrMioTbt='%s?%s'%(sJFkugfnBUIKHlqeGVazRWCrMioTby._addon_url,urllib.parse.urlencode(params))
  if sublabel:sJFkugfnBUIKHlqeGVazRWCrMioTbc='%s < %s >'%(label,sublabel)
  else: sJFkugfnBUIKHlqeGVazRWCrMioTbc=label
  if not img:img='DefaultFolder.png'
  sJFkugfnBUIKHlqeGVazRWCrMioTbL=xbmcgui.ListItem(sJFkugfnBUIKHlqeGVazRWCrMioTbc)
  sJFkugfnBUIKHlqeGVazRWCrMioTbL.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:sJFkugfnBUIKHlqeGVazRWCrMioTbL.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:sJFkugfnBUIKHlqeGVazRWCrMioTbL.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(sJFkugfnBUIKHlqeGVazRWCrMioTby._addon_handle,sJFkugfnBUIKHlqeGVazRWCrMioTbt,sJFkugfnBUIKHlqeGVazRWCrMioTbL,isFolder)
 def make_M3u_Filename(sJFkugfnBUIKHlqeGVazRWCrMioTby,tempyn=sJFkugfnBUIKHlqeGVazRWCrMioTmS):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_FILE_PATH+sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(sJFkugfnBUIKHlqeGVazRWCrMioTby,tempyn=sJFkugfnBUIKHlqeGVazRWCrMioTmS):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_FILE_PATH+sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_FILE_NAME+'.xml'
 def dp_Main_List(sJFkugfnBUIKHlqeGVazRWCrMioTby):
  for sJFkugfnBUIKHlqeGVazRWCrMioTbp in sJFkugfnBUIKHlqeGVazRWCrMioTbm:
   sJFkugfnBUIKHlqeGVazRWCrMioTbc=sJFkugfnBUIKHlqeGVazRWCrMioTbp.get('title')
   sJFkugfnBUIKHlqeGVazRWCrMioTbx={'mode':sJFkugfnBUIKHlqeGVazRWCrMioTbp.get('mode'),'sType':sJFkugfnBUIKHlqeGVazRWCrMioTbp.get('sType'),'sName':sJFkugfnBUIKHlqeGVazRWCrMioTbp.get('sName')}
   if sJFkugfnBUIKHlqeGVazRWCrMioTbp.get('mode')=='XXX':
    sJFkugfnBUIKHlqeGVazRWCrMioTbS=sJFkugfnBUIKHlqeGVazRWCrMioTmS
   else:
    sJFkugfnBUIKHlqeGVazRWCrMioTbS=sJFkugfnBUIKHlqeGVazRWCrMioTmv
   sJFkugfnBUIKHlqeGVazRWCrMioTbX=sJFkugfnBUIKHlqeGVazRWCrMioTmv
   if sJFkugfnBUIKHlqeGVazRWCrMioTbp.get('mode')=='ADD_M3U':
    if sJFkugfnBUIKHlqeGVazRWCrMioTbp.get('sType')=='wavve' and sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVE==sJFkugfnBUIKHlqeGVazRWCrMioTmS:sJFkugfnBUIKHlqeGVazRWCrMioTbX=sJFkugfnBUIKHlqeGVazRWCrMioTmS
    if sJFkugfnBUIKHlqeGVazRWCrMioTbp.get('sType')=='tving' and sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONTVING==sJFkugfnBUIKHlqeGVazRWCrMioTmS:sJFkugfnBUIKHlqeGVazRWCrMioTbX=sJFkugfnBUIKHlqeGVazRWCrMioTmS
    if sJFkugfnBUIKHlqeGVazRWCrMioTbp.get('sType')=='spotv' and sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONSPOTV==sJFkugfnBUIKHlqeGVazRWCrMioTmS:sJFkugfnBUIKHlqeGVazRWCrMioTbX=sJFkugfnBUIKHlqeGVazRWCrMioTmS
   if sJFkugfnBUIKHlqeGVazRWCrMioTbX==sJFkugfnBUIKHlqeGVazRWCrMioTmv:
    sJFkugfnBUIKHlqeGVazRWCrMioTby.add_dir(sJFkugfnBUIKHlqeGVazRWCrMioTbc,sublabel='',img='',infoLabels=sJFkugfnBUIKHlqeGVazRWCrMioTmX,isFolder=sJFkugfnBUIKHlqeGVazRWCrMioTbS,params=sJFkugfnBUIKHlqeGVazRWCrMioTbx)
  if sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTbm)>0:xbmcplugin.endOfDirectory(sJFkugfnBUIKHlqeGVazRWCrMioTby._addon_handle,cacheToDisc=sJFkugfnBUIKHlqeGVazRWCrMioTmv)
 def dp_Delete_M3u(sJFkugfnBUIKHlqeGVazRWCrMioTby,args):
  sJFkugfnBUIKHlqeGVazRWCrMioTbN=xbmcgui.Dialog()
  sJFkugfnBUIKHlqeGVazRWCrMioTbA=sJFkugfnBUIKHlqeGVazRWCrMioTbN.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if sJFkugfnBUIKHlqeGVazRWCrMioTbA==sJFkugfnBUIKHlqeGVazRWCrMioTmS:sys.exit()
  sJFkugfnBUIKHlqeGVazRWCrMioTbh=sJFkugfnBUIKHlqeGVazRWCrMioTby.make_M3u_Filename(tempyn=sJFkugfnBUIKHlqeGVazRWCrMioTmS)
  if xbmcvfs.exists(sJFkugfnBUIKHlqeGVazRWCrMioTbh):
   if xbmcvfs.delete(sJFkugfnBUIKHlqeGVazRWCrMioTbh)==sJFkugfnBUIKHlqeGVazRWCrMioTmS:
    sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_noti(__language__(30910).encode('utf-8'))
    return
  sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(sJFkugfnBUIKHlqeGVazRWCrMioTby,args):
  sJFkugfnBUIKHlqeGVazRWCrMioTYb=args.get('sType')
  sJFkugfnBUIKHlqeGVazRWCrMioTYm=args.get('sName')
  sJFkugfnBUIKHlqeGVazRWCrMioTbN=xbmcgui.Dialog()
  sJFkugfnBUIKHlqeGVazRWCrMioTbA=sJFkugfnBUIKHlqeGVazRWCrMioTbN.yesno((sJFkugfnBUIKHlqeGVazRWCrMioTYm+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if sJFkugfnBUIKHlqeGVazRWCrMioTbA==sJFkugfnBUIKHlqeGVazRWCrMioTmS:sys.exit()
  sJFkugfnBUIKHlqeGVazRWCrMioTYP =[]
  sJFkugfnBUIKHlqeGVazRWCrMioTYy =[]
  if sJFkugfnBUIKHlqeGVazRWCrMioTYb=='all':
   sJFkugfnBUIKHlqeGVazRWCrMioTbh=sJFkugfnBUIKHlqeGVazRWCrMioTby.make_M3u_Filename(tempyn=sJFkugfnBUIKHlqeGVazRWCrMioTmv)
   if os.path.isfile(sJFkugfnBUIKHlqeGVazRWCrMioTbh):os.remove(sJFkugfnBUIKHlqeGVazRWCrMioTbh)
   sJFkugfnBUIKHlqeGVazRWCrMioTbh=sJFkugfnBUIKHlqeGVazRWCrMioTby.make_M3u_Filename(tempyn=sJFkugfnBUIKHlqeGVazRWCrMioTmS)
   if xbmcvfs.exists(sJFkugfnBUIKHlqeGVazRWCrMioTbh):
    if xbmcvfs.delete(sJFkugfnBUIKHlqeGVazRWCrMioTbh)==sJFkugfnBUIKHlqeGVazRWCrMioTmS:
     sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_noti(__language__(30910).encode('utf-8'))
     return
  if(sJFkugfnBUIKHlqeGVazRWCrMioTYb=='wavve' or sJFkugfnBUIKHlqeGVazRWCrMioTYb=='all')and sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVE:
   sJFkugfnBUIKHlqeGVazRWCrMioTYE=sJFkugfnBUIKHlqeGVazRWCrMioTby.BoritvObj.Get_ChannelList_Wavve(exceptGroup=sJFkugfnBUIKHlqeGVazRWCrMioTby.make_EexceptGroup_Wavve())
   if sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTYE)!=0:sJFkugfnBUIKHlqeGVazRWCrMioTYP.extend(sJFkugfnBUIKHlqeGVazRWCrMioTYE)
   sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_log('wavve cnt ----> '+sJFkugfnBUIKHlqeGVazRWCrMioTmh(sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTYE)))
  if(sJFkugfnBUIKHlqeGVazRWCrMioTYb=='tving' or sJFkugfnBUIKHlqeGVazRWCrMioTYb=='all')and sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONTVING:
   sJFkugfnBUIKHlqeGVazRWCrMioTYE=sJFkugfnBUIKHlqeGVazRWCrMioTby.BoritvObj.Get_ChannelList_Tving()
   if sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTYE)!=0:sJFkugfnBUIKHlqeGVazRWCrMioTYP.extend(sJFkugfnBUIKHlqeGVazRWCrMioTYE)
   sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_log('tving cnt ----> '+sJFkugfnBUIKHlqeGVazRWCrMioTmh(sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTYE)))
  if(sJFkugfnBUIKHlqeGVazRWCrMioTYb=='spotv' or sJFkugfnBUIKHlqeGVazRWCrMioTYb=='all')and sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONSPOTV:
   sJFkugfnBUIKHlqeGVazRWCrMioTYE=sJFkugfnBUIKHlqeGVazRWCrMioTby.BoritvObj.Get_ChannelList_Spotv(payyn=sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONSPOTVPAY)
   if sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTYE)!=0:sJFkugfnBUIKHlqeGVazRWCrMioTYP.extend(sJFkugfnBUIKHlqeGVazRWCrMioTYE)
   sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_log('spotv cnt ----> '+sJFkugfnBUIKHlqeGVazRWCrMioTmh(sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTYE)))
  if sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTYP)==0:
   sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_noti(__language__(30909).encode('utf8'))
   return
  for sJFkugfnBUIKHlqeGVazRWCrMioTYQ in sJFkugfnBUIKHlqeGVazRWCrMioTby.BoritvObj.INIT_GENRESORT:
   for sJFkugfnBUIKHlqeGVazRWCrMioTYw in sJFkugfnBUIKHlqeGVazRWCrMioTYP:
    if sJFkugfnBUIKHlqeGVazRWCrMioTYw['genrenm']==sJFkugfnBUIKHlqeGVazRWCrMioTYQ:
     sJFkugfnBUIKHlqeGVazRWCrMioTYy.append(sJFkugfnBUIKHlqeGVazRWCrMioTYw)
  for sJFkugfnBUIKHlqeGVazRWCrMioTYw in sJFkugfnBUIKHlqeGVazRWCrMioTYP:
   if sJFkugfnBUIKHlqeGVazRWCrMioTYw['genrenm']not in sJFkugfnBUIKHlqeGVazRWCrMioTby.BoritvObj.INIT_GENRESORT:
    sJFkugfnBUIKHlqeGVazRWCrMioTYy.append(sJFkugfnBUIKHlqeGVazRWCrMioTYw)
  try:
   sJFkugfnBUIKHlqeGVazRWCrMioTbh=sJFkugfnBUIKHlqeGVazRWCrMioTby.make_M3u_Filename(tempyn=sJFkugfnBUIKHlqeGVazRWCrMioTmv)
   if os.path.isfile(sJFkugfnBUIKHlqeGVazRWCrMioTbh):
    fp=sJFkugfnBUIKHlqeGVazRWCrMioTPb(sJFkugfnBUIKHlqeGVazRWCrMioTbh,'a',-1,'utf-8')
   else:
    fp=sJFkugfnBUIKHlqeGVazRWCrMioTPb(sJFkugfnBUIKHlqeGVazRWCrMioTbh,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for sJFkugfnBUIKHlqeGVazRWCrMioTYd in sJFkugfnBUIKHlqeGVazRWCrMioTYy:
    sJFkugfnBUIKHlqeGVazRWCrMioTYN =sJFkugfnBUIKHlqeGVazRWCrMioTYd['channelid']
    sJFkugfnBUIKHlqeGVazRWCrMioTYO =sJFkugfnBUIKHlqeGVazRWCrMioTYd['channelnm']
    sJFkugfnBUIKHlqeGVazRWCrMioTYD=sJFkugfnBUIKHlqeGVazRWCrMioTYd['channelimg']
    sJFkugfnBUIKHlqeGVazRWCrMioTYj =sJFkugfnBUIKHlqeGVazRWCrMioTYd['ott']
    sJFkugfnBUIKHlqeGVazRWCrMioTYt ='%s.%s'%(sJFkugfnBUIKHlqeGVazRWCrMioTYN,sJFkugfnBUIKHlqeGVazRWCrMioTYj)
    sJFkugfnBUIKHlqeGVazRWCrMioTYc=sJFkugfnBUIKHlqeGVazRWCrMioTYd['genrenm']
    if sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_DISPLAYNM:
     sJFkugfnBUIKHlqeGVazRWCrMioTYO='%s (%s)'%(sJFkugfnBUIKHlqeGVazRWCrMioTYO,sJFkugfnBUIKHlqeGVazRWCrMioTYj)
    if sJFkugfnBUIKHlqeGVazRWCrMioTYc=='라디오/음악':
     sJFkugfnBUIKHlqeGVazRWCrMioTYL='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(sJFkugfnBUIKHlqeGVazRWCrMioTYt,sJFkugfnBUIKHlqeGVazRWCrMioTYO,sJFkugfnBUIKHlqeGVazRWCrMioTYc,sJFkugfnBUIKHlqeGVazRWCrMioTYD,sJFkugfnBUIKHlqeGVazRWCrMioTYO)
    else:
     sJFkugfnBUIKHlqeGVazRWCrMioTYL='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(sJFkugfnBUIKHlqeGVazRWCrMioTYt,sJFkugfnBUIKHlqeGVazRWCrMioTYO,sJFkugfnBUIKHlqeGVazRWCrMioTYc,sJFkugfnBUIKHlqeGVazRWCrMioTYD,sJFkugfnBUIKHlqeGVazRWCrMioTYO)
    if sJFkugfnBUIKHlqeGVazRWCrMioTYj=='wavve':
     sJFkugfnBUIKHlqeGVazRWCrMioTYp ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(sJFkugfnBUIKHlqeGVazRWCrMioTYN)
    elif sJFkugfnBUIKHlqeGVazRWCrMioTYj=='tving':
     sJFkugfnBUIKHlqeGVazRWCrMioTYp ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(sJFkugfnBUIKHlqeGVazRWCrMioTYN)
    elif sJFkugfnBUIKHlqeGVazRWCrMioTYj=='spotv':
     sJFkugfnBUIKHlqeGVazRWCrMioTYp ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(sJFkugfnBUIKHlqeGVazRWCrMioTYN)
    fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTYL)
    fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTYp)
   fp.close()
  except:
   sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_noti(__language__(30910).encode('utf8'))
   return
  sJFkugfnBUIKHlqeGVazRWCrMioTYx=sJFkugfnBUIKHlqeGVazRWCrMioTby.make_M3u_Filename(tempyn=sJFkugfnBUIKHlqeGVazRWCrMioTmv)
  sJFkugfnBUIKHlqeGVazRWCrMioTYS=sJFkugfnBUIKHlqeGVazRWCrMioTby.make_M3u_Filename(tempyn=sJFkugfnBUIKHlqeGVazRWCrMioTmS)
  if xbmcvfs.copy(sJFkugfnBUIKHlqeGVazRWCrMioTYx,sJFkugfnBUIKHlqeGVazRWCrMioTYS):
   sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_noti((sJFkugfnBUIKHlqeGVazRWCrMioTYm+' '+__language__(30908)).encode('utf8'))
  else:
   sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_noti(__language__(30910).encode('utf-8'))
 def dp_Make_Epg(sJFkugfnBUIKHlqeGVazRWCrMioTby,args):
  sJFkugfnBUIKHlqeGVazRWCrMioTYb=args.get('sType')
  sJFkugfnBUIKHlqeGVazRWCrMioTYm=args.get('sName')
  sJFkugfnBUIKHlqeGVazRWCrMioTYX=args.get('sNoti')
  if sJFkugfnBUIKHlqeGVazRWCrMioTYX!='N':
   sJFkugfnBUIKHlqeGVazRWCrMioTbN=xbmcgui.Dialog()
   sJFkugfnBUIKHlqeGVazRWCrMioTbA=sJFkugfnBUIKHlqeGVazRWCrMioTbN.yesno((sJFkugfnBUIKHlqeGVazRWCrMioTYm+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if sJFkugfnBUIKHlqeGVazRWCrMioTbA==sJFkugfnBUIKHlqeGVazRWCrMioTmS:sys.exit()
  sJFkugfnBUIKHlqeGVazRWCrMioTYv=[]
  sJFkugfnBUIKHlqeGVazRWCrMioTYA=[]
  if(sJFkugfnBUIKHlqeGVazRWCrMioTYb=='wavve' or sJFkugfnBUIKHlqeGVazRWCrMioTYb=='all')and sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVE:
   sJFkugfnBUIKHlqeGVazRWCrMioTYh,sJFkugfnBUIKHlqeGVazRWCrMioTmb=sJFkugfnBUIKHlqeGVazRWCrMioTby.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=sJFkugfnBUIKHlqeGVazRWCrMioTby.make_EexceptGroup_Wavve())
   if sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTmb)!=0:
    sJFkugfnBUIKHlqeGVazRWCrMioTYv.extend(sJFkugfnBUIKHlqeGVazRWCrMioTYh)
    sJFkugfnBUIKHlqeGVazRWCrMioTYA.extend(sJFkugfnBUIKHlqeGVazRWCrMioTmb)
  if(sJFkugfnBUIKHlqeGVazRWCrMioTYb=='tving' or sJFkugfnBUIKHlqeGVazRWCrMioTYb=='all')and sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONTVING:
   sJFkugfnBUIKHlqeGVazRWCrMioTYh,sJFkugfnBUIKHlqeGVazRWCrMioTmb=sJFkugfnBUIKHlqeGVazRWCrMioTby.BoritvObj.Get_EpgInfo_Tving()
   if sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTmb)!=0:
    sJFkugfnBUIKHlqeGVazRWCrMioTYv.extend(sJFkugfnBUIKHlqeGVazRWCrMioTYh)
    sJFkugfnBUIKHlqeGVazRWCrMioTYA.extend(sJFkugfnBUIKHlqeGVazRWCrMioTmb)
  if(sJFkugfnBUIKHlqeGVazRWCrMioTYb=='spotv' or sJFkugfnBUIKHlqeGVazRWCrMioTYb=='all')and sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONSPOTV:
   sJFkugfnBUIKHlqeGVazRWCrMioTYh,sJFkugfnBUIKHlqeGVazRWCrMioTmb=sJFkugfnBUIKHlqeGVazRWCrMioTby.BoritvObj.Get_EpgInfo_Spotv(payyn=sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONSPOTVPAY)
   if sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTmb)!=0:
    sJFkugfnBUIKHlqeGVazRWCrMioTYv.extend(sJFkugfnBUIKHlqeGVazRWCrMioTYh)
    sJFkugfnBUIKHlqeGVazRWCrMioTYA.extend(sJFkugfnBUIKHlqeGVazRWCrMioTmb)
  if sJFkugfnBUIKHlqeGVazRWCrMioTmA(sJFkugfnBUIKHlqeGVazRWCrMioTYA)==0:
   if sJFkugfnBUIKHlqeGVazRWCrMioTYX!='N':sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   sJFkugfnBUIKHlqeGVazRWCrMioTbh=sJFkugfnBUIKHlqeGVazRWCrMioTby.make_Epg_Filename(tempyn=sJFkugfnBUIKHlqeGVazRWCrMioTmv)
   fp=sJFkugfnBUIKHlqeGVazRWCrMioTPb(sJFkugfnBUIKHlqeGVazRWCrMioTbh,'w',-1,'utf-8')
   sJFkugfnBUIKHlqeGVazRWCrMioTmY='<?xml version="1.0" encoding="UTF-8"?>\n'
   sJFkugfnBUIKHlqeGVazRWCrMioTmP='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   sJFkugfnBUIKHlqeGVazRWCrMioTmy='<tv generator-info-name="boritv_epg">\n\n'
   sJFkugfnBUIKHlqeGVazRWCrMioTmE='\n</tv>\n'
   fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTmY)
   fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTmP)
   fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTmy)
   for sJFkugfnBUIKHlqeGVazRWCrMioTmQ in sJFkugfnBUIKHlqeGVazRWCrMioTYv:
    sJFkugfnBUIKHlqeGVazRWCrMioTmw='  <channel id="%s.%s">\n' %(sJFkugfnBUIKHlqeGVazRWCrMioTmQ.get('channelid'),sJFkugfnBUIKHlqeGVazRWCrMioTmQ.get('ott'))
    sJFkugfnBUIKHlqeGVazRWCrMioTmd='    <display-name>%s</display-name>\n'%(sJFkugfnBUIKHlqeGVazRWCrMioTmQ.get('channelnm'))
    sJFkugfnBUIKHlqeGVazRWCrMioTmN='    <icon src="%s" />\n' %(sJFkugfnBUIKHlqeGVazRWCrMioTmQ.get('channelimg'))
    sJFkugfnBUIKHlqeGVazRWCrMioTmO='  </channel>\n\n'
    fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTmw)
    fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTmd)
    fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTmN)
    fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTmO)
   for sJFkugfnBUIKHlqeGVazRWCrMioTmQ in sJFkugfnBUIKHlqeGVazRWCrMioTYA:
    sJFkugfnBUIKHlqeGVazRWCrMioTmw='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(sJFkugfnBUIKHlqeGVazRWCrMioTmQ.get('startTime'),sJFkugfnBUIKHlqeGVazRWCrMioTmQ.get('endTime'),sJFkugfnBUIKHlqeGVazRWCrMioTmQ.get('channelid'),sJFkugfnBUIKHlqeGVazRWCrMioTmQ.get('ott'))
    sJFkugfnBUIKHlqeGVazRWCrMioTmd='    <title lang="kr">%s</title>\n' %(sJFkugfnBUIKHlqeGVazRWCrMioTmQ.get('title'))
    sJFkugfnBUIKHlqeGVazRWCrMioTmN='  </programme>\n\n'
    fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTmw)
    fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTmd)
    fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTmN)
   fp.write(sJFkugfnBUIKHlqeGVazRWCrMioTmE)
   fp.close()
  except:
   if sJFkugfnBUIKHlqeGVazRWCrMioTYX!='N':sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_noti(__language__(30910).encode('utf8'))
   return
  sJFkugfnBUIKHlqeGVazRWCrMioTby.MakeEpg_SaveJson()
  sJFkugfnBUIKHlqeGVazRWCrMioTYx=sJFkugfnBUIKHlqeGVazRWCrMioTby.make_Epg_Filename(tempyn=sJFkugfnBUIKHlqeGVazRWCrMioTmv)
  sJFkugfnBUIKHlqeGVazRWCrMioTYS=sJFkugfnBUIKHlqeGVazRWCrMioTby.make_Epg_Filename(tempyn=sJFkugfnBUIKHlqeGVazRWCrMioTmS)
  if xbmcvfs.copy(sJFkugfnBUIKHlqeGVazRWCrMioTYx,sJFkugfnBUIKHlqeGVazRWCrMioTYS):
   if sJFkugfnBUIKHlqeGVazRWCrMioTYX!='N':sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_noti((sJFkugfnBUIKHlqeGVazRWCrMioTYm+' '+__language__(30912)).encode('utf8'))
  else:
   sJFkugfnBUIKHlqeGVazRWCrMioTby.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_AUTORESTART:
    sJFkugfnBUIKHlqeGVazRWCrMioTmD=xbmcaddon.Addon('pvr.iptvsimple')
    sJFkugfnBUIKHlqeGVazRWCrMioTmD.setSetting('anything','anything')
  except:
   sJFkugfnBUIKHlqeGVazRWCrMioTmX 
 def make_EexceptGroup_Wavve(sJFkugfnBUIKHlqeGVazRWCrMioTby):
  sJFkugfnBUIKHlqeGVazRWCrMioTmj=[]
  if sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVERADIO==sJFkugfnBUIKHlqeGVazRWCrMioTmS:
   sJFkugfnBUIKHlqeGVazRWCrMioTmj.append('라디오/음악')
  if sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVEHOME==sJFkugfnBUIKHlqeGVazRWCrMioTmS:
   sJFkugfnBUIKHlqeGVazRWCrMioTmj.append('홈쇼핑')
  if sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONRELIGION==sJFkugfnBUIKHlqeGVazRWCrMioTmS:
   sJFkugfnBUIKHlqeGVazRWCrMioTmj.append('종교')
  return sJFkugfnBUIKHlqeGVazRWCrMioTmj
 def get_radio_list(sJFkugfnBUIKHlqeGVazRWCrMioTby):
  if sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVERADIO==sJFkugfnBUIKHlqeGVazRWCrMioTmS:return[]
  sJFkugfnBUIKHlqeGVazRWCrMioTmt=[{'broadcastid':'46584','genre':'10'}]
  return sJFkugfnBUIKHlqeGVazRWCrMioTby.BoritvObj.Get_ChannelList_WavveExcept(sJFkugfnBUIKHlqeGVazRWCrMioTmt)
 def check_config(sJFkugfnBUIKHlqeGVazRWCrMioTby):
  sJFkugfnBUIKHlqeGVazRWCrMioTmc=sJFkugfnBUIKHlqeGVazRWCrMioTmv
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVE =sJFkugfnBUIKHlqeGVazRWCrMioTmv if __addon__.getSetting('onWavve')=='true' else sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONTVING =sJFkugfnBUIKHlqeGVazRWCrMioTmv if __addon__.getSetting('onTvng')=='true' else sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONSPOTV =sJFkugfnBUIKHlqeGVazRWCrMioTmv if __addon__.getSetting('onSpotv')=='true' else sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVERADIO=sJFkugfnBUIKHlqeGVazRWCrMioTmv if __addon__.getSetting('onWavveRadio')=='true' else sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVEHOME =sJFkugfnBUIKHlqeGVazRWCrMioTmv if __addon__.getSetting('onWavveHome')=='true' else sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONRELIGION =sJFkugfnBUIKHlqeGVazRWCrMioTmv if __addon__.getSetting('onWavveReligion')=='true' else sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONSPOTVPAY =sJFkugfnBUIKHlqeGVazRWCrMioTmv if __addon__.getSetting('onSpotvPay')=='true' else sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_DISPLAYNM =sJFkugfnBUIKHlqeGVazRWCrMioTmv if __addon__.getSetting('displayOTTnm')=='true' else sJFkugfnBUIKHlqeGVazRWCrMioTmS
  sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_AUTORESTART =sJFkugfnBUIKHlqeGVazRWCrMioTmv if __addon__.getSetting('autoRestart')=='true' else sJFkugfnBUIKHlqeGVazRWCrMioTmS
  if sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_FILE_PATH=='' or sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_FILE_NAME=='':sJFkugfnBUIKHlqeGVazRWCrMioTmc=sJFkugfnBUIKHlqeGVazRWCrMioTmS
  if sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONWAVVE==sJFkugfnBUIKHlqeGVazRWCrMioTmS and sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONTVING=='' and sJFkugfnBUIKHlqeGVazRWCrMioTby.M3U_ONSPOTV=='':sJFkugfnBUIKHlqeGVazRWCrMioTmc=sJFkugfnBUIKHlqeGVazRWCrMioTmS
  if sJFkugfnBUIKHlqeGVazRWCrMioTmc==sJFkugfnBUIKHlqeGVazRWCrMioTmS:
   sJFkugfnBUIKHlqeGVazRWCrMioTbN=xbmcgui.Dialog()
   sJFkugfnBUIKHlqeGVazRWCrMioTbA=sJFkugfnBUIKHlqeGVazRWCrMioTbN.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if sJFkugfnBUIKHlqeGVazRWCrMioTbA==sJFkugfnBUIKHlqeGVazRWCrMioTmv:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(sJFkugfnBUIKHlqeGVazRWCrMioTby):
  sJFkugfnBUIKHlqeGVazRWCrMioTmL={'date_makeepg':sJFkugfnBUIKHlqeGVazRWCrMioTby.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=sJFkugfnBUIKHlqeGVazRWCrMioTPb(sJFkugfnBUIKHlqeGVazRWCrMioTbP,'w',-1,'utf-8')
   json.dump(sJFkugfnBUIKHlqeGVazRWCrMioTmL,fp)
   fp.close()
  except sJFkugfnBUIKHlqeGVazRWCrMioTPY as exception:
   return
 def boritv_main(sJFkugfnBUIKHlqeGVazRWCrMioTby):
  sJFkugfnBUIKHlqeGVazRWCrMioTmp=sJFkugfnBUIKHlqeGVazRWCrMioTby.main_params.get('mode',sJFkugfnBUIKHlqeGVazRWCrMioTmX)
  sJFkugfnBUIKHlqeGVazRWCrMioTby.check_config()
  if sJFkugfnBUIKHlqeGVazRWCrMioTmp is sJFkugfnBUIKHlqeGVazRWCrMioTmX:
   sJFkugfnBUIKHlqeGVazRWCrMioTby.dp_Main_List()
  elif sJFkugfnBUIKHlqeGVazRWCrMioTmp=='DEL_M3U':
   sJFkugfnBUIKHlqeGVazRWCrMioTby.dp_Delete_M3u(sJFkugfnBUIKHlqeGVazRWCrMioTby.main_params)
  elif sJFkugfnBUIKHlqeGVazRWCrMioTmp=='ADD_M3U':
   sJFkugfnBUIKHlqeGVazRWCrMioTby.dp_MakeAdd_M3u(sJFkugfnBUIKHlqeGVazRWCrMioTby.main_params)
  elif sJFkugfnBUIKHlqeGVazRWCrMioTmp=='ADD_EPG':
   sJFkugfnBUIKHlqeGVazRWCrMioTby.dp_Make_Epg(sJFkugfnBUIKHlqeGVazRWCrMioTby.main_params)
  else:
   sJFkugfnBUIKHlqeGVazRWCrMioTmX
# Created by pyminifier (https://github.com/liftoff/pyminifier)
