__author__="NightRain"
PnkltNBCbVywjmaYpiAIezWLxosuFX=object
PnkltNBCbVywjmaYpiAIezWLxosuFM=None
PnkltNBCbVywjmaYpiAIezWLxosuFO=False
PnkltNBCbVywjmaYpiAIezWLxosuFG=str
PnkltNBCbVywjmaYpiAIezWLxosuFE=Exception
PnkltNBCbVywjmaYpiAIezWLxosuFQ=print
PnkltNBCbVywjmaYpiAIezWLxosuFg=True
PnkltNBCbVywjmaYpiAIezWLxosuFv=int
PnkltNBCbVywjmaYpiAIezWLxosuFR=range
PnkltNBCbVywjmaYpiAIezWLxosuFd=len
PnkltNBCbVywjmaYpiAIezWLxosuFJ=set
PnkltNBCbVywjmaYpiAIezWLxosuFr=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
from channelgenre import*
PnkltNBCbVywjmaYpiAIezWLxosucX=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
class PnkltNBCbVywjmaYpiAIezWLxosucU(PnkltNBCbVywjmaYpiAIezWLxosuFX):
 def __init__(PnkltNBCbVywjmaYpiAIezWLxosucF):
  PnkltNBCbVywjmaYpiAIezWLxosucF.API_WAVVE ='https://apis.wavve.com'
  PnkltNBCbVywjmaYpiAIezWLxosucF.API_TVING ='https://api.tving.com'
  PnkltNBCbVywjmaYpiAIezWLxosucF.API_TVINGIMG ='https://image.tving.com'
  PnkltNBCbVywjmaYpiAIezWLxosucF.API_SPOTV ='https://www.spotvnow.co.kr'
  PnkltNBCbVywjmaYpiAIezWLxosucF.HTTPTAG ='https://'
  PnkltNBCbVywjmaYpiAIezWLxosucF.LIMIT_WAVVE =200
  PnkltNBCbVywjmaYpiAIezWLxosucF.LIMIT_TVING =60
  PnkltNBCbVywjmaYpiAIezWLxosucF.LIMIT_TVINGEPG=20 
  PnkltNBCbVywjmaYpiAIezWLxosucF.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  PnkltNBCbVywjmaYpiAIezWLxosucF.DEFAULT_HEADER={'user-agent':PnkltNBCbVywjmaYpiAIezWLxosucF.USER_AGENT}
  PnkltNBCbVywjmaYpiAIezWLxosucF.SLEEP_TIME =0.2
  PnkltNBCbVywjmaYpiAIezWLxosucF.INIT_GENRESORT=MASTER_GENRE
  PnkltNBCbVywjmaYpiAIezWLxosucF.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(PnkltNBCbVywjmaYpiAIezWLxosucF,jobtype,PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosuFM,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM,redirects=PnkltNBCbVywjmaYpiAIezWLxosuFO):
  PnkltNBCbVywjmaYpiAIezWLxosucG=PnkltNBCbVywjmaYpiAIezWLxosucF.DEFAULT_HEADER
  if headers:PnkltNBCbVywjmaYpiAIezWLxosucG.update(headers)
  if jobtype=='Get':
   PnkltNBCbVywjmaYpiAIezWLxosucE=requests.get(PnkltNBCbVywjmaYpiAIezWLxosucJ,params=params,headers=PnkltNBCbVywjmaYpiAIezWLxosucG,cookies=cookies,allow_redirects=redirects)
  else:
   PnkltNBCbVywjmaYpiAIezWLxosucE=requests.post(PnkltNBCbVywjmaYpiAIezWLxosucJ,data=payload,params=params,headers=PnkltNBCbVywjmaYpiAIezWLxosucG,cookies=cookies,allow_redirects=redirects)
  return PnkltNBCbVywjmaYpiAIezWLxosucE
 def Get_DefaultParams_Wavve(PnkltNBCbVywjmaYpiAIezWLxosucF):
  PnkltNBCbVywjmaYpiAIezWLxosucQ={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return PnkltNBCbVywjmaYpiAIezWLxosucQ
 def Get_DefaultParams_Tving(PnkltNBCbVywjmaYpiAIezWLxosucF):
  PnkltNBCbVywjmaYpiAIezWLxosucQ={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return PnkltNBCbVywjmaYpiAIezWLxosucQ
 def Get_Now_Datetime(PnkltNBCbVywjmaYpiAIezWLxosucF):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(PnkltNBCbVywjmaYpiAIezWLxosucF,in_text):
  PnkltNBCbVywjmaYpiAIezWLxosucv=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return PnkltNBCbVywjmaYpiAIezWLxosucv
 def Get_ChannelList_Wavve(PnkltNBCbVywjmaYpiAIezWLxosucF,exceptGroup=[]):
  PnkltNBCbVywjmaYpiAIezWLxosucR =[]
  PnkltNBCbVywjmaYpiAIezWLxosucd=PnkltNBCbVywjmaYpiAIezWLxosucF.Get_ChannelImg_Wavve()
  try:
   PnkltNBCbVywjmaYpiAIezWLxosucJ=PnkltNBCbVywjmaYpiAIezWLxosucF.API_WAVVE+'/cf/live/recommend-channels'
   PnkltNBCbVywjmaYpiAIezWLxosucQ={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':PnkltNBCbVywjmaYpiAIezWLxosuFG(PnkltNBCbVywjmaYpiAIezWLxosucF.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   PnkltNBCbVywjmaYpiAIezWLxosucQ.update(PnkltNBCbVywjmaYpiAIezWLxosucF.Get_DefaultParams_Wavve())
   PnkltNBCbVywjmaYpiAIezWLxosucr=PnkltNBCbVywjmaYpiAIezWLxosucF.callRequestCookies('Get',PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosucQ,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM)
   PnkltNBCbVywjmaYpiAIezWLxosucT=json.loads(PnkltNBCbVywjmaYpiAIezWLxosucr.text)
   if not('celllist' in PnkltNBCbVywjmaYpiAIezWLxosucT['cell_toplist']):return PnkltNBCbVywjmaYpiAIezWLxosucR
   PnkltNBCbVywjmaYpiAIezWLxosucD=PnkltNBCbVywjmaYpiAIezWLxosucT['cell_toplist']['celllist']
   for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosucD:
    PnkltNBCbVywjmaYpiAIezWLxosucf=PnkltNBCbVywjmaYpiAIezWLxosucS['contentid']
    PnkltNBCbVywjmaYpiAIezWLxosucH=PnkltNBCbVywjmaYpiAIezWLxosucS['title_list'][0]['text']
    if PnkltNBCbVywjmaYpiAIezWLxosucf in PnkltNBCbVywjmaYpiAIezWLxosucd:
     PnkltNBCbVywjmaYpiAIezWLxosucq=PnkltNBCbVywjmaYpiAIezWLxosucd[PnkltNBCbVywjmaYpiAIezWLxosucf]
    else:
     PnkltNBCbVywjmaYpiAIezWLxosucq=''
    PnkltNBCbVywjmaYpiAIezWLxosucK=PnkltNBCbVywjmaYpiAIezWLxosucF.make_getGenre(PnkltNBCbVywjmaYpiAIezWLxosucf,'wavve')
    PnkltNBCbVywjmaYpiAIezWLxosuch={'channelid':PnkltNBCbVywjmaYpiAIezWLxosucf,'channelnm':PnkltNBCbVywjmaYpiAIezWLxosucH,'channelimg':PnkltNBCbVywjmaYpiAIezWLxosucF.HTTPTAG+PnkltNBCbVywjmaYpiAIezWLxosucq if PnkltNBCbVywjmaYpiAIezWLxosucq!='' else '','ott':'wavve','genrenm':PnkltNBCbVywjmaYpiAIezWLxosucK}
    if PnkltNBCbVywjmaYpiAIezWLxosucK not in exceptGroup:
     PnkltNBCbVywjmaYpiAIezWLxosucR.append(PnkltNBCbVywjmaYpiAIezWLxosuch)
  except PnkltNBCbVywjmaYpiAIezWLxosuFE as exception:
   PnkltNBCbVywjmaYpiAIezWLxosuFQ(exception)
   return[]
  return PnkltNBCbVywjmaYpiAIezWLxosucR
 def Get_ChannelList_WavveExcept(PnkltNBCbVywjmaYpiAIezWLxosucF,exceptGroup=[]):
  PnkltNBCbVywjmaYpiAIezWLxosucR=[]
  if exceptGroup==[]:return[]
  try:
   PnkltNBCbVywjmaYpiAIezWLxosucJ=PnkltNBCbVywjmaYpiAIezWLxosucF.API_WAVVE+'/cf/live/recommend-channels'
   for PnkltNBCbVywjmaYpiAIezWLxosucS in exceptGroup:
    PnkltNBCbVywjmaYpiAIezWLxosucQ={'WeekDay':'all','adult':'n','broadcastid':PnkltNBCbVywjmaYpiAIezWLxosucS['broadcastid'],'contenttype':'channel','genre':PnkltNBCbVywjmaYpiAIezWLxosucS['genre'],'isrecommend':'y','limit':PnkltNBCbVywjmaYpiAIezWLxosuFG(PnkltNBCbVywjmaYpiAIezWLxosucF.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    PnkltNBCbVywjmaYpiAIezWLxosucQ.update(PnkltNBCbVywjmaYpiAIezWLxosucF.Get_DefaultParams_Wavve())
    PnkltNBCbVywjmaYpiAIezWLxosucr=PnkltNBCbVywjmaYpiAIezWLxosucF.callRequestCookies('Get',PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosucQ,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM)
    PnkltNBCbVywjmaYpiAIezWLxosucT=json.loads(PnkltNBCbVywjmaYpiAIezWLxosucr.text)
    if not('celllist' in PnkltNBCbVywjmaYpiAIezWLxosucT['cell_toplist']):return PnkltNBCbVywjmaYpiAIezWLxosucR
    PnkltNBCbVywjmaYpiAIezWLxosucD=PnkltNBCbVywjmaYpiAIezWLxosucT['cell_toplist']['celllist']
    for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosucD:
     PnkltNBCbVywjmaYpiAIezWLxosucR.append(PnkltNBCbVywjmaYpiAIezWLxosucS['contentid'])
  except PnkltNBCbVywjmaYpiAIezWLxosuFE as exception:
   PnkltNBCbVywjmaYpiAIezWLxosuFQ(exception)
   return[]
  return PnkltNBCbVywjmaYpiAIezWLxosucR
 def Get_ChannelImg_Wavve(PnkltNBCbVywjmaYpiAIezWLxosucF):
  PnkltNBCbVywjmaYpiAIezWLxosuUc={}
  try:
   PnkltNBCbVywjmaYpiAIezWLxosuUX=PnkltNBCbVywjmaYpiAIezWLxosucF.Get_Now_Datetime()
   PnkltNBCbVywjmaYpiAIezWLxosuUF =PnkltNBCbVywjmaYpiAIezWLxosuUX+datetime.timedelta(hours=3)
   PnkltNBCbVywjmaYpiAIezWLxosucJ=PnkltNBCbVywjmaYpiAIezWLxosucF.API_WAVVE+'/live/epgs'
   PnkltNBCbVywjmaYpiAIezWLxosucQ={'limit':PnkltNBCbVywjmaYpiAIezWLxosuFG(PnkltNBCbVywjmaYpiAIezWLxosucF.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':PnkltNBCbVywjmaYpiAIezWLxosuUX.strftime('%Y-%m-%d %H:00'),'enddatetime':PnkltNBCbVywjmaYpiAIezWLxosuUF.strftime('%Y-%m-%d %H:00')}
   PnkltNBCbVywjmaYpiAIezWLxosucQ.update(PnkltNBCbVywjmaYpiAIezWLxosucF.Get_DefaultParams_Wavve())
   PnkltNBCbVywjmaYpiAIezWLxosucr=PnkltNBCbVywjmaYpiAIezWLxosucF.callRequestCookies('Get',PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosucQ,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM)
   PnkltNBCbVywjmaYpiAIezWLxosucT=json.loads(PnkltNBCbVywjmaYpiAIezWLxosucr.text)
   PnkltNBCbVywjmaYpiAIezWLxosucD=PnkltNBCbVywjmaYpiAIezWLxosucT['list']
   for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosucD:
    PnkltNBCbVywjmaYpiAIezWLxosuUc[PnkltNBCbVywjmaYpiAIezWLxosucS['channelid']]=PnkltNBCbVywjmaYpiAIezWLxosucS['channelimage']
  except PnkltNBCbVywjmaYpiAIezWLxosuFE as exception:
   PnkltNBCbVywjmaYpiAIezWLxosuFQ(exception)
  return PnkltNBCbVywjmaYpiAIezWLxosuUc
 def Get_ChanneGenrename_Wavve(PnkltNBCbVywjmaYpiAIezWLxosucF,PnkltNBCbVywjmaYpiAIezWLxosucf):
  try:
   PnkltNBCbVywjmaYpiAIezWLxosucJ=PnkltNBCbVywjmaYpiAIezWLxosucF.API_WAVVE+'/live/channels/'+PnkltNBCbVywjmaYpiAIezWLxosucf
   PnkltNBCbVywjmaYpiAIezWLxosucQ=PnkltNBCbVywjmaYpiAIezWLxosucF.Get_DefaultParams_Wavve()
   PnkltNBCbVywjmaYpiAIezWLxosucr=PnkltNBCbVywjmaYpiAIezWLxosucF.callRequestCookies('Get',PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosucQ,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM)
   PnkltNBCbVywjmaYpiAIezWLxosucT=json.loads(PnkltNBCbVywjmaYpiAIezWLxosucr.text)
   PnkltNBCbVywjmaYpiAIezWLxosuUM=PnkltNBCbVywjmaYpiAIezWLxosucT['genretext']
  except PnkltNBCbVywjmaYpiAIezWLxosuFE as exception:
   PnkltNBCbVywjmaYpiAIezWLxosuFQ(exception)
   return ''
  return PnkltNBCbVywjmaYpiAIezWLxosuUM
 def Get_ChannelList_Spotv(PnkltNBCbVywjmaYpiAIezWLxosucF,payyn=PnkltNBCbVywjmaYpiAIezWLxosuFg):
  PnkltNBCbVywjmaYpiAIezWLxosucR=[]
  try:
   PnkltNBCbVywjmaYpiAIezWLxosucJ=PnkltNBCbVywjmaYpiAIezWLxosucF.API_SPOTV+'/api/v2/channel'
   PnkltNBCbVywjmaYpiAIezWLxosucr=PnkltNBCbVywjmaYpiAIezWLxosucF.callRequestCookies('Get',PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosuFM,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM)
   PnkltNBCbVywjmaYpiAIezWLxosucT=json.loads(PnkltNBCbVywjmaYpiAIezWLxosucr.text)
   for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosucT:
    PnkltNBCbVywjmaYpiAIezWLxosucf=PnkltNBCbVywjmaYpiAIezWLxosucS['videoId'].replace('ref:','')
    PnkltNBCbVywjmaYpiAIezWLxosuch={'channelid':PnkltNBCbVywjmaYpiAIezWLxosucf,'channelnm':PnkltNBCbVywjmaYpiAIezWLxosucS['name'],'channelimg':PnkltNBCbVywjmaYpiAIezWLxosucS['logo'],'ott':'spotv','genrenm':PnkltNBCbVywjmaYpiAIezWLxosucF.make_getGenre(PnkltNBCbVywjmaYpiAIezWLxosucf,'spotv')}
    if payyn==PnkltNBCbVywjmaYpiAIezWLxosuFg or PnkltNBCbVywjmaYpiAIezWLxosucS['free']==PnkltNBCbVywjmaYpiAIezWLxosuFg:
     PnkltNBCbVywjmaYpiAIezWLxosucR.append(PnkltNBCbVywjmaYpiAIezWLxosuch)
  except PnkltNBCbVywjmaYpiAIezWLxosuFE as exception:
   PnkltNBCbVywjmaYpiAIezWLxosuFQ(exception)
   return[]
  return PnkltNBCbVywjmaYpiAIezWLxosucR
 def Get_ChannelList_Tving(PnkltNBCbVywjmaYpiAIezWLxosucF):
  PnkltNBCbVywjmaYpiAIezWLxosucR =[]
  PnkltNBCbVywjmaYpiAIezWLxosuUO=[]
  try:
   PnkltNBCbVywjmaYpiAIezWLxosucJ=PnkltNBCbVywjmaYpiAIezWLxosucF.API_TVING+'/v2/media/lives'
   PnkltNBCbVywjmaYpiAIezWLxosucQ={'pageNo':'1','pageSize':PnkltNBCbVywjmaYpiAIezWLxosuFG(PnkltNBCbVywjmaYpiAIezWLxosucF.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   PnkltNBCbVywjmaYpiAIezWLxosucQ.update(PnkltNBCbVywjmaYpiAIezWLxosucF.Get_DefaultParams_Tving())
   PnkltNBCbVywjmaYpiAIezWLxosucr=PnkltNBCbVywjmaYpiAIezWLxosucF.callRequestCookies('Get',PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosucQ,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM)
   PnkltNBCbVywjmaYpiAIezWLxosucT=json.loads(PnkltNBCbVywjmaYpiAIezWLxosucr.text)
   if not('result' in PnkltNBCbVywjmaYpiAIezWLxosucT['body']):return PnkltNBCbVywjmaYpiAIezWLxosucR
   PnkltNBCbVywjmaYpiAIezWLxosucD=PnkltNBCbVywjmaYpiAIezWLxosucT['body']['result']
   for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosucD:
    if PnkltNBCbVywjmaYpiAIezWLxosucS['live_code']=='C44441':continue 
    PnkltNBCbVywjmaYpiAIezWLxosuUO.append(PnkltNBCbVywjmaYpiAIezWLxosucS['live_code'])
   PnkltNBCbVywjmaYpiAIezWLxosucd=PnkltNBCbVywjmaYpiAIezWLxosucF.Get_ChannelImg_Tving(PnkltNBCbVywjmaYpiAIezWLxosuUO)
   for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosucD:
    PnkltNBCbVywjmaYpiAIezWLxosucf=PnkltNBCbVywjmaYpiAIezWLxosucS['live_code']
    if PnkltNBCbVywjmaYpiAIezWLxosucf=='C44441':continue 
    PnkltNBCbVywjmaYpiAIezWLxosucH=PnkltNBCbVywjmaYpiAIezWLxosucS['schedule']['channel']['name']['ko']
    if PnkltNBCbVywjmaYpiAIezWLxosucf in PnkltNBCbVywjmaYpiAIezWLxosucd:
     PnkltNBCbVywjmaYpiAIezWLxosucq=PnkltNBCbVywjmaYpiAIezWLxosucd[PnkltNBCbVywjmaYpiAIezWLxosucf]
    else:
     PnkltNBCbVywjmaYpiAIezWLxosucq=''
    PnkltNBCbVywjmaYpiAIezWLxosuch={'channelid':PnkltNBCbVywjmaYpiAIezWLxosucf,'channelnm':PnkltNBCbVywjmaYpiAIezWLxosucH,'channelimg':PnkltNBCbVywjmaYpiAIezWLxosucq,'ott':'tving','genrenm':PnkltNBCbVywjmaYpiAIezWLxosucF.make_getGenre(PnkltNBCbVywjmaYpiAIezWLxosucf,'tving')}
    PnkltNBCbVywjmaYpiAIezWLxosucR.append(PnkltNBCbVywjmaYpiAIezWLxosuch)
  except PnkltNBCbVywjmaYpiAIezWLxosuFE as exception:
   PnkltNBCbVywjmaYpiAIezWLxosuFQ(exception)
   return[]
  return PnkltNBCbVywjmaYpiAIezWLxosucR
 def make_EpgDatetime_Tving(PnkltNBCbVywjmaYpiAIezWLxosucF,days=2):
  PnkltNBCbVywjmaYpiAIezWLxosuUG=[]
  PnkltNBCbVywjmaYpiAIezWLxosuUE=PnkltNBCbVywjmaYpiAIezWLxosucF.make_DateList(days=2,dateType='2')
  PnkltNBCbVywjmaYpiAIezWLxosuUQ=PnkltNBCbVywjmaYpiAIezWLxosuFv(PnkltNBCbVywjmaYpiAIezWLxosucF.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosuUE:
   for PnkltNBCbVywjmaYpiAIezWLxosuUg in PnkltNBCbVywjmaYpiAIezWLxosuFR(8):
    PnkltNBCbVywjmaYpiAIezWLxosuch={'ndate':PnkltNBCbVywjmaYpiAIezWLxosucS,'starttm':PnkltNBCbVywjmaYpiAIezWLxosucX[PnkltNBCbVywjmaYpiAIezWLxosuUg]['starttm'],'endtm':PnkltNBCbVywjmaYpiAIezWLxosucX[PnkltNBCbVywjmaYpiAIezWLxosuUg]['endtm']}
    PnkltNBCbVywjmaYpiAIezWLxosuUv=PnkltNBCbVywjmaYpiAIezWLxosuFv(PnkltNBCbVywjmaYpiAIezWLxosucS+PnkltNBCbVywjmaYpiAIezWLxosucX[PnkltNBCbVywjmaYpiAIezWLxosuUg]['starttm'])
    PnkltNBCbVywjmaYpiAIezWLxosuUR=PnkltNBCbVywjmaYpiAIezWLxosuFv(PnkltNBCbVywjmaYpiAIezWLxosucS+PnkltNBCbVywjmaYpiAIezWLxosucX[PnkltNBCbVywjmaYpiAIezWLxosuUg]['endtm'])
    if PnkltNBCbVywjmaYpiAIezWLxosuUQ<=PnkltNBCbVywjmaYpiAIezWLxosuUv or(PnkltNBCbVywjmaYpiAIezWLxosuUv<PnkltNBCbVywjmaYpiAIezWLxosuUQ and PnkltNBCbVywjmaYpiAIezWLxosuUQ<PnkltNBCbVywjmaYpiAIezWLxosuUR):
     PnkltNBCbVywjmaYpiAIezWLxosuUG.append(PnkltNBCbVywjmaYpiAIezWLxosuch)
  return PnkltNBCbVywjmaYpiAIezWLxosuUG
 def make_DateList(PnkltNBCbVywjmaYpiAIezWLxosucF,days=2,dateType='1'):
  PnkltNBCbVywjmaYpiAIezWLxosuUE=[]
  PnkltNBCbVywjmaYpiAIezWLxosuUd =PnkltNBCbVywjmaYpiAIezWLxosucF.Get_Now_Datetime()
  if dateType=='1':
   PnkltNBCbVywjmaYpiAIezWLxosuUd=PnkltNBCbVywjmaYpiAIezWLxosuUd-datetime.timedelta(days=1)
  for i in PnkltNBCbVywjmaYpiAIezWLxosuFR(days):
   PnkltNBCbVywjmaYpiAIezWLxosuUJ=PnkltNBCbVywjmaYpiAIezWLxosuUd+datetime.timedelta(days=i)
   if dateType=='1':
    PnkltNBCbVywjmaYpiAIezWLxosuUE.append(PnkltNBCbVywjmaYpiAIezWLxosuUJ.strftime('%Y-%m-%d'))
   else:
    PnkltNBCbVywjmaYpiAIezWLxosuUE.append(PnkltNBCbVywjmaYpiAIezWLxosuUJ.strftime('%Y%m%d'))
  return PnkltNBCbVywjmaYpiAIezWLxosuUE
 def make_Tving_ChannleGroup(PnkltNBCbVywjmaYpiAIezWLxosucF,PnkltNBCbVywjmaYpiAIezWLxosuUO):
  PnkltNBCbVywjmaYpiAIezWLxosuUr=[]
  i=0
  PnkltNBCbVywjmaYpiAIezWLxosuUT=''
  for PnkltNBCbVywjmaYpiAIezWLxosuUD in PnkltNBCbVywjmaYpiAIezWLxosuUO:
   if i==0:PnkltNBCbVywjmaYpiAIezWLxosuUT=PnkltNBCbVywjmaYpiAIezWLxosuUD
   else:PnkltNBCbVywjmaYpiAIezWLxosuUT+=',%s'%(PnkltNBCbVywjmaYpiAIezWLxosuUD)
   i+=1
   if i>=PnkltNBCbVywjmaYpiAIezWLxosucF.LIMIT_TVINGEPG:
    PnkltNBCbVywjmaYpiAIezWLxosuUr.append(PnkltNBCbVywjmaYpiAIezWLxosuUT)
    i=0
    PnkltNBCbVywjmaYpiAIezWLxosuUT=''
  if PnkltNBCbVywjmaYpiAIezWLxosuUT!='':
   PnkltNBCbVywjmaYpiAIezWLxosuUr.append(PnkltNBCbVywjmaYpiAIezWLxosuUT)
  return PnkltNBCbVywjmaYpiAIezWLxosuUr
 def Get_ChannelImg_Tving(PnkltNBCbVywjmaYpiAIezWLxosucF,chid_list):
  PnkltNBCbVywjmaYpiAIezWLxosuUc={}
  try:
   PnkltNBCbVywjmaYpiAIezWLxosuUS=PnkltNBCbVywjmaYpiAIezWLxosucF.Get_Now_Datetime().strftime('%Y%m%d')
   PnkltNBCbVywjmaYpiAIezWLxosuUX =PnkltNBCbVywjmaYpiAIezWLxosucX[6]['starttm'] 
   PnkltNBCbVywjmaYpiAIezWLxosuUF =PnkltNBCbVywjmaYpiAIezWLxosucX[6]['endtm']
   PnkltNBCbVywjmaYpiAIezWLxosuUr=PnkltNBCbVywjmaYpiAIezWLxosucF.make_Tving_ChannleGroup(chid_list)
   for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosuUr:
    PnkltNBCbVywjmaYpiAIezWLxosucJ=PnkltNBCbVywjmaYpiAIezWLxosucF.API_TVING+'/v2/media/schedules'
    PnkltNBCbVywjmaYpiAIezWLxosucQ={'pageNo':'1','pageSize':PnkltNBCbVywjmaYpiAIezWLxosuFG(PnkltNBCbVywjmaYpiAIezWLxosucF.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':PnkltNBCbVywjmaYpiAIezWLxosuUS,'broadcastDate':PnkltNBCbVywjmaYpiAIezWLxosuUS,'startBroadTime':PnkltNBCbVywjmaYpiAIezWLxosuUX,'endBroadTime':PnkltNBCbVywjmaYpiAIezWLxosuUF,'channelCode':PnkltNBCbVywjmaYpiAIezWLxosucS}
    PnkltNBCbVywjmaYpiAIezWLxosucQ.update(PnkltNBCbVywjmaYpiAIezWLxosucF.Get_DefaultParams_Tving())
    PnkltNBCbVywjmaYpiAIezWLxosucr=PnkltNBCbVywjmaYpiAIezWLxosucF.callRequestCookies('Get',PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosucQ,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM)
    PnkltNBCbVywjmaYpiAIezWLxosucT=json.loads(PnkltNBCbVywjmaYpiAIezWLxosucr.text)
    if not('result' in PnkltNBCbVywjmaYpiAIezWLxosucT['body']):return{}
    PnkltNBCbVywjmaYpiAIezWLxosucD=PnkltNBCbVywjmaYpiAIezWLxosucT['body']['result']
    for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosucD:
     PnkltNBCbVywjmaYpiAIezWLxosuUc[PnkltNBCbVywjmaYpiAIezWLxosucS['channel_code']]=PnkltNBCbVywjmaYpiAIezWLxosucF.API_TVINGIMG+PnkltNBCbVywjmaYpiAIezWLxosucS['image'][2]['url']
  except PnkltNBCbVywjmaYpiAIezWLxosuFE as exception:
   PnkltNBCbVywjmaYpiAIezWLxosuFQ(exception)
   return{}
  return PnkltNBCbVywjmaYpiAIezWLxosuUc
 def Get_EpgInfo_Spotv(PnkltNBCbVywjmaYpiAIezWLxosucF,days=3,payyn=PnkltNBCbVywjmaYpiAIezWLxosuFg):
  PnkltNBCbVywjmaYpiAIezWLxosuUf ={}
  PnkltNBCbVywjmaYpiAIezWLxosucR=[]
  PnkltNBCbVywjmaYpiAIezWLxosuUH =[]
  PnkltNBCbVywjmaYpiAIezWLxosuUE=PnkltNBCbVywjmaYpiAIezWLxosucF.make_DateList(days=days,dateType='1')
  PnkltNBCbVywjmaYpiAIezWLxosuFQ(PnkltNBCbVywjmaYpiAIezWLxosuUE)
  try:
   PnkltNBCbVywjmaYpiAIezWLxosucJ=PnkltNBCbVywjmaYpiAIezWLxosucF.API_SPOTV+'/api/v2/channel'
   PnkltNBCbVywjmaYpiAIezWLxosucr=PnkltNBCbVywjmaYpiAIezWLxosucF.callRequestCookies('Get',PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosuFM,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM)
   PnkltNBCbVywjmaYpiAIezWLxosucT=json.loads(PnkltNBCbVywjmaYpiAIezWLxosucr.text)
   for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosucT:
    PnkltNBCbVywjmaYpiAIezWLxosucf =PnkltNBCbVywjmaYpiAIezWLxosucS['videoId'].replace('ref:','')
    PnkltNBCbVywjmaYpiAIezWLxosuch={'channelid':PnkltNBCbVywjmaYpiAIezWLxosucf,'channelnm':PnkltNBCbVywjmaYpiAIezWLxosucF.xmlText(PnkltNBCbVywjmaYpiAIezWLxosucS['name']),'channelimg':PnkltNBCbVywjmaYpiAIezWLxosucS['logo'],'ott':'spotv'}
    if payyn==PnkltNBCbVywjmaYpiAIezWLxosuFg or PnkltNBCbVywjmaYpiAIezWLxosucS['free']==PnkltNBCbVywjmaYpiAIezWLxosuFg:
     PnkltNBCbVywjmaYpiAIezWLxosuUf[PnkltNBCbVywjmaYpiAIezWLxosucS['id']]=PnkltNBCbVywjmaYpiAIezWLxosucf
     PnkltNBCbVywjmaYpiAIezWLxosucR.append(PnkltNBCbVywjmaYpiAIezWLxosuch)
  except PnkltNBCbVywjmaYpiAIezWLxosuFE as exception:
   PnkltNBCbVywjmaYpiAIezWLxosuFQ(exception)
   return[],[]
  try:
   for PnkltNBCbVywjmaYpiAIezWLxosuUq in PnkltNBCbVywjmaYpiAIezWLxosuUE:
    PnkltNBCbVywjmaYpiAIezWLxosucJ=PnkltNBCbVywjmaYpiAIezWLxosucF.API_SPOTV+'/api/v2/program/'+PnkltNBCbVywjmaYpiAIezWLxosuUq
    PnkltNBCbVywjmaYpiAIezWLxosucr=PnkltNBCbVywjmaYpiAIezWLxosucF.callRequestCookies('Get',PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosuFM,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM)
    PnkltNBCbVywjmaYpiAIezWLxosucT=json.loads(PnkltNBCbVywjmaYpiAIezWLxosucr.text)
    for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosucT:
     if PnkltNBCbVywjmaYpiAIezWLxosuUf.get(PnkltNBCbVywjmaYpiAIezWLxosucS['channelId'])==PnkltNBCbVywjmaYpiAIezWLxosuFM:continue
     PnkltNBCbVywjmaYpiAIezWLxosuch={'channelid':PnkltNBCbVywjmaYpiAIezWLxosuUf.get(PnkltNBCbVywjmaYpiAIezWLxosucS['channelId']),'title':PnkltNBCbVywjmaYpiAIezWLxosucF.xmlText(PnkltNBCbVywjmaYpiAIezWLxosucS['title']),'startTime':PnkltNBCbVywjmaYpiAIezWLxosucS['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':PnkltNBCbVywjmaYpiAIezWLxosucS['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     PnkltNBCbVywjmaYpiAIezWLxosuUH.append(PnkltNBCbVywjmaYpiAIezWLxosuch)
    time.sleep(PnkltNBCbVywjmaYpiAIezWLxosucF.SLEEP_TIME)
  except PnkltNBCbVywjmaYpiAIezWLxosuFE as exception:
   PnkltNBCbVywjmaYpiAIezWLxosuFQ(exception)
   return[],[]
  return PnkltNBCbVywjmaYpiAIezWLxosucR,PnkltNBCbVywjmaYpiAIezWLxosuUH
 def Get_EpgInfo_Wavve(PnkltNBCbVywjmaYpiAIezWLxosucF,days=2,exceptGroup=[]):
  PnkltNBCbVywjmaYpiAIezWLxosucR =[]
  PnkltNBCbVywjmaYpiAIezWLxosuUH =[]
  PnkltNBCbVywjmaYpiAIezWLxosuUd =PnkltNBCbVywjmaYpiAIezWLxosucF.Get_Now_Datetime()
  PnkltNBCbVywjmaYpiAIezWLxosuUK =PnkltNBCbVywjmaYpiAIezWLxosuUd+datetime.timedelta(hours=-2)
  PnkltNBCbVywjmaYpiAIezWLxosuUh =PnkltNBCbVywjmaYpiAIezWLxosuUd+datetime.timedelta(days=(days-1))
  if PnkltNBCbVywjmaYpiAIezWLxosuFv(PnkltNBCbVywjmaYpiAIezWLxosuUK.strftime('%H'))<=3:
   PnkltNBCbVywjmaYpiAIezWLxosuXc=PnkltNBCbVywjmaYpiAIezWLxosuUK.strftime('%Y-%m-%d 00:00')
  else:
   PnkltNBCbVywjmaYpiAIezWLxosuXc=PnkltNBCbVywjmaYpiAIezWLxosuUK.strftime('%Y-%m-%d %H:00')
  PnkltNBCbVywjmaYpiAIezWLxosuXU =PnkltNBCbVywjmaYpiAIezWLxosuUh.strftime('%Y-%m-%d 24:00')
  try:
   PnkltNBCbVywjmaYpiAIezWLxosucJ=PnkltNBCbVywjmaYpiAIezWLxosucF.API_WAVVE+'/live/epgs'
   PnkltNBCbVywjmaYpiAIezWLxosucQ={'limit':PnkltNBCbVywjmaYpiAIezWLxosuFG(PnkltNBCbVywjmaYpiAIezWLxosucF.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':PnkltNBCbVywjmaYpiAIezWLxosuXc,'enddatetime':PnkltNBCbVywjmaYpiAIezWLxosuXU}
   PnkltNBCbVywjmaYpiAIezWLxosucQ.update(PnkltNBCbVywjmaYpiAIezWLxosucF.Get_DefaultParams_Wavve())
   PnkltNBCbVywjmaYpiAIezWLxosucr=PnkltNBCbVywjmaYpiAIezWLxosucF.callRequestCookies('Get',PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosucQ,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM)
   PnkltNBCbVywjmaYpiAIezWLxosucT=json.loads(PnkltNBCbVywjmaYpiAIezWLxosucr.text)
   PnkltNBCbVywjmaYpiAIezWLxosuXF=PnkltNBCbVywjmaYpiAIezWLxosucT['list']
   for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosuXF:
    PnkltNBCbVywjmaYpiAIezWLxosucf =PnkltNBCbVywjmaYpiAIezWLxosucS['channelid']
    PnkltNBCbVywjmaYpiAIezWLxosucK=PnkltNBCbVywjmaYpiAIezWLxosucF.make_getGenre(PnkltNBCbVywjmaYpiAIezWLxosucf,'wavve')
    PnkltNBCbVywjmaYpiAIezWLxosuch={'channelid':PnkltNBCbVywjmaYpiAIezWLxosucf,'channelnm':PnkltNBCbVywjmaYpiAIezWLxosucF.xmlText(PnkltNBCbVywjmaYpiAIezWLxosucS['channelname']),'channelimg':PnkltNBCbVywjmaYpiAIezWLxosucF.HTTPTAG+PnkltNBCbVywjmaYpiAIezWLxosucS['channelimage'],'ott':'wavve'}
    if PnkltNBCbVywjmaYpiAIezWLxosucK not in exceptGroup:
     PnkltNBCbVywjmaYpiAIezWLxosucR.append(PnkltNBCbVywjmaYpiAIezWLxosuch)
    for PnkltNBCbVywjmaYpiAIezWLxosuXM in PnkltNBCbVywjmaYpiAIezWLxosucS['list']:
     PnkltNBCbVywjmaYpiAIezWLxosuch={'channelid':PnkltNBCbVywjmaYpiAIezWLxosucS['channelid'],'title':PnkltNBCbVywjmaYpiAIezWLxosucF.xmlText(PnkltNBCbVywjmaYpiAIezWLxosuXM['title']),'startTime':PnkltNBCbVywjmaYpiAIezWLxosuXM['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':PnkltNBCbVywjmaYpiAIezWLxosuXM['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if PnkltNBCbVywjmaYpiAIezWLxosucK not in exceptGroup and PnkltNBCbVywjmaYpiAIezWLxosuXM['starttime']!=PnkltNBCbVywjmaYpiAIezWLxosuXM['endtime']:
      PnkltNBCbVywjmaYpiAIezWLxosuUH.append(PnkltNBCbVywjmaYpiAIezWLxosuch)
  except PnkltNBCbVywjmaYpiAIezWLxosuFE as exception:
   PnkltNBCbVywjmaYpiAIezWLxosuFQ(exception)
   return[],[]
  PnkltNBCbVywjmaYpiAIezWLxosuXO=PnkltNBCbVywjmaYpiAIezWLxosuFd(PnkltNBCbVywjmaYpiAIezWLxosuUH)
  for i in(PnkltNBCbVywjmaYpiAIezWLxosuFR(1,PnkltNBCbVywjmaYpiAIezWLxosuXO)):
   if PnkltNBCbVywjmaYpiAIezWLxosuFv(PnkltNBCbVywjmaYpiAIezWLxosuUH[i-1]['endTime'])+1==PnkltNBCbVywjmaYpiAIezWLxosuFv(PnkltNBCbVywjmaYpiAIezWLxosuUH[i]['startTime'])and PnkltNBCbVywjmaYpiAIezWLxosuUH[i-1]['channelid']==PnkltNBCbVywjmaYpiAIezWLxosuUH[i]['channelid']:
    PnkltNBCbVywjmaYpiAIezWLxosuUH[i-1]['endTime']=PnkltNBCbVywjmaYpiAIezWLxosuUH[i]['startTime']
  return PnkltNBCbVywjmaYpiAIezWLxosucR,PnkltNBCbVywjmaYpiAIezWLxosuUH
 def Get_EpgInfo_Tving(PnkltNBCbVywjmaYpiAIezWLxosucF,days=2):
  PnkltNBCbVywjmaYpiAIezWLxosucR=[]
  PnkltNBCbVywjmaYpiAIezWLxosuUH =[]
  PnkltNBCbVywjmaYpiAIezWLxosuXG =[]
  PnkltNBCbVywjmaYpiAIezWLxosuXE =PnkltNBCbVywjmaYpiAIezWLxosucF.make_EpgDatetime_Tving(days=days)
  PnkltNBCbVywjmaYpiAIezWLxosucR =PnkltNBCbVywjmaYpiAIezWLxosucF.Get_ChannelList_Tving()
  PnkltNBCbVywjmaYpiAIezWLxosuXQ=[]
  for i in PnkltNBCbVywjmaYpiAIezWLxosuFR(PnkltNBCbVywjmaYpiAIezWLxosuFd(PnkltNBCbVywjmaYpiAIezWLxosucR)):
   PnkltNBCbVywjmaYpiAIezWLxosucR[i]['channelnm']=PnkltNBCbVywjmaYpiAIezWLxosucF.xmlText(PnkltNBCbVywjmaYpiAIezWLxosucR[i]['channelnm'])
   PnkltNBCbVywjmaYpiAIezWLxosuXQ.append(PnkltNBCbVywjmaYpiAIezWLxosucR[i]['channelid'])
  PnkltNBCbVywjmaYpiAIezWLxosuXg=PnkltNBCbVywjmaYpiAIezWLxosucF.make_Tving_ChannleGroup(PnkltNBCbVywjmaYpiAIezWLxosuXQ)
  try:
   PnkltNBCbVywjmaYpiAIezWLxosucJ=PnkltNBCbVywjmaYpiAIezWLxosucF.API_TVING+'/v2/media/schedules'
   for PnkltNBCbVywjmaYpiAIezWLxosuXv in PnkltNBCbVywjmaYpiAIezWLxosuXE:
    for PnkltNBCbVywjmaYpiAIezWLxosuXR in PnkltNBCbVywjmaYpiAIezWLxosuXg:
     PnkltNBCbVywjmaYpiAIezWLxosucQ={'pageNo':'1','pageSize':PnkltNBCbVywjmaYpiAIezWLxosuFG(PnkltNBCbVywjmaYpiAIezWLxosucF.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':PnkltNBCbVywjmaYpiAIezWLxosuXv['ndate'],'broadcastDate':PnkltNBCbVywjmaYpiAIezWLxosuXv['ndate'],'startBroadTime':PnkltNBCbVywjmaYpiAIezWLxosuXv['starttm'],'endBroadTime':PnkltNBCbVywjmaYpiAIezWLxosuXv['endtm'],'channelCode':PnkltNBCbVywjmaYpiAIezWLxosuXR}
     PnkltNBCbVywjmaYpiAIezWLxosucQ.update(PnkltNBCbVywjmaYpiAIezWLxosucF.Get_DefaultParams_Tving())
     PnkltNBCbVywjmaYpiAIezWLxosucr=PnkltNBCbVywjmaYpiAIezWLxosucF.callRequestCookies('Get',PnkltNBCbVywjmaYpiAIezWLxosucJ,payload=PnkltNBCbVywjmaYpiAIezWLxosuFM,params=PnkltNBCbVywjmaYpiAIezWLxosucQ,headers=PnkltNBCbVywjmaYpiAIezWLxosuFM,cookies=PnkltNBCbVywjmaYpiAIezWLxosuFM)
     PnkltNBCbVywjmaYpiAIezWLxosucT=json.loads(PnkltNBCbVywjmaYpiAIezWLxosucr.text)
     PnkltNBCbVywjmaYpiAIezWLxosucD=PnkltNBCbVywjmaYpiAIezWLxosucT['body']['result']
     for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosucD:
      if 'schedules' not in PnkltNBCbVywjmaYpiAIezWLxosucS:continue
      if PnkltNBCbVywjmaYpiAIezWLxosucS['schedules']==PnkltNBCbVywjmaYpiAIezWLxosuFM:continue
      for PnkltNBCbVywjmaYpiAIezWLxosuXd in PnkltNBCbVywjmaYpiAIezWLxosucS['schedules']:
       PnkltNBCbVywjmaYpiAIezWLxosuch={'channelid':PnkltNBCbVywjmaYpiAIezWLxosuXd['schedule_code'],'title':PnkltNBCbVywjmaYpiAIezWLxosucF.xmlText(PnkltNBCbVywjmaYpiAIezWLxosuXd['program']['name']['ko']),'startTime':PnkltNBCbVywjmaYpiAIezWLxosuFG(PnkltNBCbVywjmaYpiAIezWLxosuXd['broadcast_start_time']),'endTime':PnkltNBCbVywjmaYpiAIezWLxosuFG(PnkltNBCbVywjmaYpiAIezWLxosuXd['broadcast_end_time']),'ott':'tving'}
       PnkltNBCbVywjmaYpiAIezWLxosuXJ=PnkltNBCbVywjmaYpiAIezWLxosuXd['schedule_code']+PnkltNBCbVywjmaYpiAIezWLxosuFG(PnkltNBCbVywjmaYpiAIezWLxosuXd['broadcast_start_time'])
       if PnkltNBCbVywjmaYpiAIezWLxosuXJ in PnkltNBCbVywjmaYpiAIezWLxosuXG:continue
       PnkltNBCbVywjmaYpiAIezWLxosuXG.append(PnkltNBCbVywjmaYpiAIezWLxosuXJ)
       PnkltNBCbVywjmaYpiAIezWLxosuUH.append(PnkltNBCbVywjmaYpiAIezWLxosuch)
     time.sleep(PnkltNBCbVywjmaYpiAIezWLxosucF.SLEEP_TIME)
  except PnkltNBCbVywjmaYpiAIezWLxosuFE as exception:
   PnkltNBCbVywjmaYpiAIezWLxosuFQ(exception)
   return[],[]
  return PnkltNBCbVywjmaYpiAIezWLxosucR,PnkltNBCbVywjmaYpiAIezWLxosuUH
 def make_getGenre(PnkltNBCbVywjmaYpiAIezWLxosucF,PnkltNBCbVywjmaYpiAIezWLxosucf,PnkltNBCbVywjmaYpiAIezWLxosuXh):
  try:
   PnkltNBCbVywjmaYpiAIezWLxosuUM=PnkltNBCbVywjmaYpiAIezWLxosucF.INIT_CHANNEL.get(PnkltNBCbVywjmaYpiAIezWLxosucf+'.'+PnkltNBCbVywjmaYpiAIezWLxosuXh).get('genre')
  except:
   PnkltNBCbVywjmaYpiAIezWLxosuUM='-'
  return PnkltNBCbVywjmaYpiAIezWLxosuUM
 def make_base_allchannel_py(PnkltNBCbVywjmaYpiAIezWLxosucF):
  PnkltNBCbVywjmaYpiAIezWLxosuXr =[]
  PnkltNBCbVywjmaYpiAIezWLxosuXT=[]
  PnkltNBCbVywjmaYpiAIezWLxosuXD=PnkltNBCbVywjmaYpiAIezWLxosuFJ()
  PnkltNBCbVywjmaYpiAIezWLxosuch=PnkltNBCbVywjmaYpiAIezWLxosucF.Get_ChannelList_Wavve()
  PnkltNBCbVywjmaYpiAIezWLxosuXr.extend(PnkltNBCbVywjmaYpiAIezWLxosuch)
  PnkltNBCbVywjmaYpiAIezWLxosuch=PnkltNBCbVywjmaYpiAIezWLxosucF.Get_ChannelList_Tving()
  PnkltNBCbVywjmaYpiAIezWLxosuXr.extend(PnkltNBCbVywjmaYpiAIezWLxosuch)
  PnkltNBCbVywjmaYpiAIezWLxosuch=PnkltNBCbVywjmaYpiAIezWLxosucF.Get_ChannelList_Spotv()
  PnkltNBCbVywjmaYpiAIezWLxosuXr.extend(PnkltNBCbVywjmaYpiAIezWLxosuch)
  PnkltNBCbVywjmaYpiAIezWLxosuFQ('1')
  for i in PnkltNBCbVywjmaYpiAIezWLxosuFR(PnkltNBCbVywjmaYpiAIezWLxosuFd(PnkltNBCbVywjmaYpiAIezWLxosuXr)):
   if PnkltNBCbVywjmaYpiAIezWLxosuXr[i]['genrenm']=='-':
    if PnkltNBCbVywjmaYpiAIezWLxosuXr[i]['ott']=='wavve':
     PnkltNBCbVywjmaYpiAIezWLxosuUM=PnkltNBCbVywjmaYpiAIezWLxosucF.Get_ChanneGenrename_Wavve(PnkltNBCbVywjmaYpiAIezWLxosuXr[i]['channelid'])
     if PnkltNBCbVywjmaYpiAIezWLxosuUM not in PnkltNBCbVywjmaYpiAIezWLxosuXD:PnkltNBCbVywjmaYpiAIezWLxosuXD.add(PnkltNBCbVywjmaYpiAIezWLxosuUM)
     time.sleep(PnkltNBCbVywjmaYpiAIezWLxosucF.SLEEP_TIME)
    elif PnkltNBCbVywjmaYpiAIezWLxosuXr[i]['ott']=='spotv':
     PnkltNBCbVywjmaYpiAIezWLxosuUM='스포츠'
    else:
     PnkltNBCbVywjmaYpiAIezWLxosuUM='-'
    PnkltNBCbVywjmaYpiAIezWLxosuXr[i]['genrenm']=PnkltNBCbVywjmaYpiAIezWLxosuUM
   else:
    if PnkltNBCbVywjmaYpiAIezWLxosuXr[i]['genrenm']not in PnkltNBCbVywjmaYpiAIezWLxosuXD:PnkltNBCbVywjmaYpiAIezWLxosuXD.add(PnkltNBCbVywjmaYpiAIezWLxosuXr[i]['genrenm'])
  PnkltNBCbVywjmaYpiAIezWLxosuXD.add('-')
  PnkltNBCbVywjmaYpiAIezWLxosuFQ('2')
  for PnkltNBCbVywjmaYpiAIezWLxosuXS in PnkltNBCbVywjmaYpiAIezWLxosuXD:
   for PnkltNBCbVywjmaYpiAIezWLxosuXf in PnkltNBCbVywjmaYpiAIezWLxosuXr:
    if PnkltNBCbVywjmaYpiAIezWLxosuXf['genrenm']==PnkltNBCbVywjmaYpiAIezWLxosuXS:
     PnkltNBCbVywjmaYpiAIezWLxosuXT.append(PnkltNBCbVywjmaYpiAIezWLxosuXf)
  for PnkltNBCbVywjmaYpiAIezWLxosuXf in PnkltNBCbVywjmaYpiAIezWLxosuXr:
   if PnkltNBCbVywjmaYpiAIezWLxosuXf['genrenm']not in PnkltNBCbVywjmaYpiAIezWLxosuXD:
    PnkltNBCbVywjmaYpiAIezWLxosuXH.append(PnkltNBCbVywjmaYpiAIezWLxosuXf)
  PnkltNBCbVywjmaYpiAIezWLxosuFQ('3')
  PnkltNBCbVywjmaYpiAIezWLxosuXq='d:\\job\\channelgenre.json'
  if os.path.isfile(PnkltNBCbVywjmaYpiAIezWLxosuXq):os.remove(PnkltNBCbVywjmaYpiAIezWLxosuXq)
  fp=PnkltNBCbVywjmaYpiAIezWLxosuFr(PnkltNBCbVywjmaYpiAIezWLxosuXq,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  PnkltNBCbVywjmaYpiAIezWLxosuXK=PnkltNBCbVywjmaYpiAIezWLxosuFd(PnkltNBCbVywjmaYpiAIezWLxosuXT)
  i=0
  for PnkltNBCbVywjmaYpiAIezWLxosucS in PnkltNBCbVywjmaYpiAIezWLxosuXT:
   i+=1
   PnkltNBCbVywjmaYpiAIezWLxosucf =PnkltNBCbVywjmaYpiAIezWLxosucS['channelid']
   PnkltNBCbVywjmaYpiAIezWLxosucH =PnkltNBCbVywjmaYpiAIezWLxosucS['channelnm']
   PnkltNBCbVywjmaYpiAIezWLxosuXh =PnkltNBCbVywjmaYpiAIezWLxosucS['ott']
   PnkltNBCbVywjmaYpiAIezWLxosuFc ='%s.%s'%(PnkltNBCbVywjmaYpiAIezWLxosucf,PnkltNBCbVywjmaYpiAIezWLxosuXh)
   PnkltNBCbVywjmaYpiAIezWLxosuUM =PnkltNBCbVywjmaYpiAIezWLxosucS['genrenm']
   PnkltNBCbVywjmaYpiAIezWLxosuFU='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(PnkltNBCbVywjmaYpiAIezWLxosuFc,PnkltNBCbVywjmaYpiAIezWLxosucH,PnkltNBCbVywjmaYpiAIezWLxosuUM)
   if i<PnkltNBCbVywjmaYpiAIezWLxosuXK:
    fp.write(PnkltNBCbVywjmaYpiAIezWLxosuFU+',\n')
   else:
    fp.write(PnkltNBCbVywjmaYpiAIezWLxosuFU+'\n')
  fp.write('}\n')
  fp.close()
  return PnkltNBCbVywjmaYpiAIezWLxosuXD
# Created by pyminifier (https://github.com/liftoff/pyminifier)
