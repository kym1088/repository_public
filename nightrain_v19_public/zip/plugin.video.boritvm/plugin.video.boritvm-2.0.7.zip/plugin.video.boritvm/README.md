# boritvM-v19
m3u, epg 생성 도우미 for Kodi19

###
# 저장소를 통해서만 업데이트 됩니다.
* [Korea OTT Package for Kodi 18 (public)-18.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v18_public.zip)
* [Korea OTT Package for Kodi 19 (public)-19.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v19_public.zip)
###

## Version 2.0.7 (2020.12.26)
- 추가채널 반영

## Version 2.0.6 (2020.12.12)
- 추가채널 반영

## Version 2.0.5 (2020.12.02)
- EPG 생성후 강제반영

## Version 2.0.4 (2020.11.21)
- 네트워크 폴더 지원

## Version 2.0.3 (2020.11.14)
- epg 자동생성 수정

## Version 2.0.2 (2020.11.13)
- epg 자동생성 기능추가

## Version 2.0.1 (2020.11.08)
- tving epg 조회오류 수정
- 채널 group

## Version 2.0.0 (2020.11.05)
- 신규작성



