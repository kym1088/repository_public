__author__="NightRain"
nJWUHEAokYstyaMIvmDXuCVSBhTfjd=False
nJWUHEAokYstyaMIvmDXuCVSBhTfjK=object
nJWUHEAokYstyaMIvmDXuCVSBhTfje=open
nJWUHEAokYstyaMIvmDXuCVSBhTfjc=True
nJWUHEAokYstyaMIvmDXuCVSBhTfjR=None
nJWUHEAokYstyaMIvmDXuCVSBhTfjG=Exception
nJWUHEAokYstyaMIvmDXuCVSBhTfjF=print
nJWUHEAokYstyaMIvmDXuCVSBhTfji=range
nJWUHEAokYstyaMIvmDXuCVSBhTfjl=len
nJWUHEAokYstyaMIvmDXuCVSBhTfjq=str
nJWUHEAokYstyaMIvmDXuCVSBhTfjP=int
nJWUHEAokYstyaMIvmDXuCVSBhTfjp=dict
nJWUHEAokYstyaMIvmDXuCVSBhTfjN=set
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
nJWUHEAokYstyaMIvmDXuCVSBhTfwx=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
nJWUHEAokYstyaMIvmDXuCVSBhTfwL=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':nJWUHEAokYstyaMIvmDXuCVSBhTfjd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':nJWUHEAokYstyaMIvmDXuCVSBhTfjd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':nJWUHEAokYstyaMIvmDXuCVSBhTfjd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':nJWUHEAokYstyaMIvmDXuCVSBhTfjd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':nJWUHEAokYstyaMIvmDXuCVSBhTfjd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':nJWUHEAokYstyaMIvmDXuCVSBhTfjd,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class nJWUHEAokYstyaMIvmDXuCVSBhTfwO(nJWUHEAokYstyaMIvmDXuCVSBhTfjK):
 def __init__(nJWUHEAokYstyaMIvmDXuCVSBhTfwj):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_WAVVE ='https://apis.wavve.com'
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_TVING ='https://api.tving.com'
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_TVINGIMG ='https://image.tving.com'
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_SPOTV ='https://www.spotvnow.co.kr'
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.HTTPTAG ='https://'
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.LIMIT_WAVVE =500
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.LIMIT_TVING =60
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.LIMIT_TVINGEPG=20 
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.APPVERSION ='115.0.0.0' 
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.DEVICEMODEL ='Chrome' 
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.OSTYPE ='Windows' 
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.OSVERSION ='NT 10.0' 
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.DEFAULT_HEADER={'user-agent':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.USER_AGENT}
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.SLEEP_TIME =0.2
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.INIT_GENRESORT=MASTER_GENRE
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.INIT_CHANNEL =MASTER_CHANNEL
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.KodiVersion =20
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.BT_CONTEXTJSON_FILE1=''
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.BT_CONTEXTJSON_FILE2=''
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.BT_CONTEXTJSON_FILE3=''
  nJWUHEAokYstyaMIvmDXuCVSBhTfwj.BT_CONTEXTJSON_FILE4=''
 def JsonFile_Save(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,nJWUHEAokYstyaMIvmDXuCVSBhTfLQ,nJWUHEAokYstyaMIvmDXuCVSBhTfwe):
  if nJWUHEAokYstyaMIvmDXuCVSBhTfLQ=='':return nJWUHEAokYstyaMIvmDXuCVSBhTfjd
  try:
   fp=nJWUHEAokYstyaMIvmDXuCVSBhTfje(nJWUHEAokYstyaMIvmDXuCVSBhTfLQ,'w',-1,'utf-8')
   json.dump(nJWUHEAokYstyaMIvmDXuCVSBhTfwe,fp,indent=4,ensure_ascii=nJWUHEAokYstyaMIvmDXuCVSBhTfjd)
   fp.close()
  except:
   return nJWUHEAokYstyaMIvmDXuCVSBhTfjd
  return nJWUHEAokYstyaMIvmDXuCVSBhTfjc
 def callRequestCookies(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,jobtype,nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,redirects=nJWUHEAokYstyaMIvmDXuCVSBhTfjd):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwR=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.DEFAULT_HEADER
  if headers:nJWUHEAokYstyaMIvmDXuCVSBhTfwR.update(headers)
  if jobtype=='Get':
   nJWUHEAokYstyaMIvmDXuCVSBhTfwG=requests.get(nJWUHEAokYstyaMIvmDXuCVSBhTfwP,params=params,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfwR,cookies=cookies,allow_redirects=redirects)
  else:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwG=requests.post(nJWUHEAokYstyaMIvmDXuCVSBhTfwP,data=payload,params=params,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfwR,cookies=cookies,allow_redirects=redirects)
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwG
 def Get_DefaultParams_Wavve(nJWUHEAokYstyaMIvmDXuCVSBhTfwj):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwF={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwF
 def Get_DefaultParams_Tving(nJWUHEAokYstyaMIvmDXuCVSBhTfwj):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwF={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwF
 def Get_Now_Datetime(nJWUHEAokYstyaMIvmDXuCVSBhTfwj):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,in_text):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwl=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwl
 def Get_ChannelList_BroadCast_SBS(nJWUHEAokYstyaMIvmDXuCVSBhTfwj):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq =[]
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP='https://apis.sbs.co.kr/play-api/1.0/onair/channels'
   nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,redirects=nJWUHEAokYstyaMIvmDXuCVSBhTfjc)
   if nJWUHEAokYstyaMIvmDXuCVSBhTfwp.status_code!=200:return[]
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
   for nJWUHEAokYstyaMIvmDXuCVSBhTfwg in nJWUHEAokYstyaMIvmDXuCVSBhTfwN.get('list'):
    if nJWUHEAokYstyaMIvmDXuCVSBhTfwg['type']=='TV':
     nJWUHEAokYstyaMIvmDXuCVSBhTfwb=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_getGenre(nJWUHEAokYstyaMIvmDXuCVSBhTfwg.get('channelid'),'bc_sbs')
     nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfwg.get('channelid'),'channelnm':nJWUHEAokYstyaMIvmDXuCVSBhTfwg.get('channelname'),'channelimg':'https://static.cloud.sbs.co.kr/common/img/sbsplayBig_logo.png','ott':'bc_sbs','genrenm':nJWUHEAokYstyaMIvmDXuCVSBhTfwb,'json_name':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.INIT_CHANNEL[nJWUHEAokYstyaMIvmDXuCVSBhTfwg.get('channelid')+'.bc_sbs'].get('json_name'),}
     nJWUHEAokYstyaMIvmDXuCVSBhTfwq.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[]
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq
 def Get_EpgInfo_BroadCast_SBS(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,days=2):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq=[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfwQ =[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfwz=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_DateList(days=2,dateType='3')
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq =nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_ChannelList_BroadCast_SBS()
  try:
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOw in nJWUHEAokYstyaMIvmDXuCVSBhTfwq:
    if nJWUHEAokYstyaMIvmDXuCVSBhTfOw['json_name']in[nJWUHEAokYstyaMIvmDXuCVSBhTfjR,'']:continue
    for nJWUHEAokYstyaMIvmDXuCVSBhTfOx in nJWUHEAokYstyaMIvmDXuCVSBhTfwz:
     nJWUHEAokYstyaMIvmDXuCVSBhTfOL='{dt.year}/{dt.month}/{dt.day}'.format(dt=nJWUHEAokYstyaMIvmDXuCVSBhTfOx)
     nJWUHEAokYstyaMIvmDXuCVSBhTfwP='https://static.cloud.sbs.co.kr/schedule/{}/{}.json'.format(nJWUHEAokYstyaMIvmDXuCVSBhTfOL,nJWUHEAokYstyaMIvmDXuCVSBhTfOw['json_name'])
     nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
     nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
     for nJWUHEAokYstyaMIvmDXuCVSBhTfOj in nJWUHEAokYstyaMIvmDXuCVSBhTfji(nJWUHEAokYstyaMIvmDXuCVSBhTfjl(nJWUHEAokYstyaMIvmDXuCVSBhTfwN)):
      nJWUHEAokYstyaMIvmDXuCVSBhTfOd=nJWUHEAokYstyaMIvmDXuCVSBhTfOx
      nJWUHEAokYstyaMIvmDXuCVSBhTfOK=nJWUHEAokYstyaMIvmDXuCVSBhTfOx
      nJWUHEAokYstyaMIvmDXuCVSBhTfOe=nJWUHEAokYstyaMIvmDXuCVSBhTfwN[nJWUHEAokYstyaMIvmDXuCVSBhTfOj]['start_time'].split(':')
      nJWUHEAokYstyaMIvmDXuCVSBhTfOc=nJWUHEAokYstyaMIvmDXuCVSBhTfwN[nJWUHEAokYstyaMIvmDXuCVSBhTfOj]['end_time'].split(':')
      if nJWUHEAokYstyaMIvmDXuCVSBhTfjl(nJWUHEAokYstyaMIvmDXuCVSBhTfOc)!=['']:
       if nJWUHEAokYstyaMIvmDXuCVSBhTfOj+1<nJWUHEAokYstyaMIvmDXuCVSBhTfjl(nJWUHEAokYstyaMIvmDXuCVSBhTfwN):
        nJWUHEAokYstyaMIvmDXuCVSBhTfOc=nJWUHEAokYstyaMIvmDXuCVSBhTfwN[nJWUHEAokYstyaMIvmDXuCVSBhTfOj+1]['start_time'].split(':')
       else:
        nJWUHEAokYstyaMIvmDXuCVSBhTfOc=nJWUHEAokYstyaMIvmDXuCVSBhTfwN[nJWUHEAokYstyaMIvmDXuCVSBhTfOj]['start_time'].split(':')
        nJWUHEAokYstyaMIvmDXuCVSBhTfOc[0]=nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfjP(nJWUHEAokYstyaMIvmDXuCVSBhTfOc[0])+1).zfill(2)
      if nJWUHEAokYstyaMIvmDXuCVSBhTfjP(nJWUHEAokYstyaMIvmDXuCVSBhTfOe[0])>=24:
       nJWUHEAokYstyaMIvmDXuCVSBhTfOe[0]=nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfjP(nJWUHEAokYstyaMIvmDXuCVSBhTfOe[0])-24).zfill(2)
       nJWUHEAokYstyaMIvmDXuCVSBhTfOd =nJWUHEAokYstyaMIvmDXuCVSBhTfOd+datetime.timedelta(days=1)
      if nJWUHEAokYstyaMIvmDXuCVSBhTfjP(nJWUHEAokYstyaMIvmDXuCVSBhTfOc[0])>=24:
       nJWUHEAokYstyaMIvmDXuCVSBhTfOc[0]=nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfjP(nJWUHEAokYstyaMIvmDXuCVSBhTfOc[0])-24).zfill(2)
       nJWUHEAokYstyaMIvmDXuCVSBhTfOK =nJWUHEAokYstyaMIvmDXuCVSBhTfOK+datetime.timedelta(days=1)
      nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOw['channelid'],'title':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.xmlText(nJWUHEAokYstyaMIvmDXuCVSBhTfwN[nJWUHEAokYstyaMIvmDXuCVSBhTfOj]['title']),'startTime':'{}{}{}00'.format(nJWUHEAokYstyaMIvmDXuCVSBhTfOd.strftime('%Y%m%d'),nJWUHEAokYstyaMIvmDXuCVSBhTfOe[0],nJWUHEAokYstyaMIvmDXuCVSBhTfOe[1]),'endTime':'{}{}{}00'.format(nJWUHEAokYstyaMIvmDXuCVSBhTfOK.strftime('%Y%m%d'),nJWUHEAokYstyaMIvmDXuCVSBhTfOc[0],nJWUHEAokYstyaMIvmDXuCVSBhTfOc[1]),'ott':'bc_sbs',}
      nJWUHEAokYstyaMIvmDXuCVSBhTfwQ.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
     time.sleep(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.SLEEP_TIME)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[],[]
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq,nJWUHEAokYstyaMIvmDXuCVSBhTfwQ
 def Get_ChannelList_Wavve(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,exceptGroup=[]):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq =[]
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_WAVVE+'/v2/live/channels'
   nJWUHEAokYstyaMIvmDXuCVSBhTfwF={'service':'wavve','uitype':'band_2_rank','uiparent':'GN55-LN99','uicode':'LN99','uirank':'3','limit':nJWUHEAokYstyaMIvmDXuCVSBhTfjq(200),'offset':'0','orderby':'viewtime','broadcastid':'LN99','isBand':'true','uitype':'LN58','client_version':'7.1.40'}
   nJWUHEAokYstyaMIvmDXuCVSBhTfwF.update(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_DefaultParams_Wavve())
   nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfwF,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
   if not('context_list' in nJWUHEAokYstyaMIvmDXuCVSBhTfwN['data']):return nJWUHEAokYstyaMIvmDXuCVSBhTfwq
   nJWUHEAokYstyaMIvmDXuCVSBhTfOR=nJWUHEAokYstyaMIvmDXuCVSBhTfwN['data']['context_list']
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfOR:
    nJWUHEAokYstyaMIvmDXuCVSBhTfOF=nJWUHEAokYstyaMIvmDXuCVSBhTfOG['context_id']
    nJWUHEAokYstyaMIvmDXuCVSBhTfOi=nJWUHEAokYstyaMIvmDXuCVSBhTfOG['live']['name']
    nJWUHEAokYstyaMIvmDXuCVSBhTfOl=nJWUHEAokYstyaMIvmDXuCVSBhTfOG['live']['main_image']
    if nJWUHEAokYstyaMIvmDXuCVSBhTfOl and(not nJWUHEAokYstyaMIvmDXuCVSBhTfOl.startswith('http://'))and(not nJWUHEAokYstyaMIvmDXuCVSBhTfOl.startswith('https://')):
     nJWUHEAokYstyaMIvmDXuCVSBhTfOl=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.HTTPTAG+nJWUHEAokYstyaMIvmDXuCVSBhTfOl
    nJWUHEAokYstyaMIvmDXuCVSBhTfwb=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_getGenre(nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'wavve')
    nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'channelnm':nJWUHEAokYstyaMIvmDXuCVSBhTfOi,'channelimg':nJWUHEAokYstyaMIvmDXuCVSBhTfOl,'ott':'wavve','genrenm':nJWUHEAokYstyaMIvmDXuCVSBhTfwb}
    if nJWUHEAokYstyaMIvmDXuCVSBhTfwb not in exceptGroup:
     nJWUHEAokYstyaMIvmDXuCVSBhTfwq.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[]
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq
 def Get_ChannelList_Wavve_250831(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,exceptGroup=[]):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq =[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfOq=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_ChannelImg_Wavve()
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_WAVVE+'/cf/live/recommend-channels'
   nJWUHEAokYstyaMIvmDXuCVSBhTfwF={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   nJWUHEAokYstyaMIvmDXuCVSBhTfwF.update(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_DefaultParams_Wavve())
   nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfwF,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
   if not('celllist' in nJWUHEAokYstyaMIvmDXuCVSBhTfwN['cell_toplist']):return nJWUHEAokYstyaMIvmDXuCVSBhTfwq
   nJWUHEAokYstyaMIvmDXuCVSBhTfOR=nJWUHEAokYstyaMIvmDXuCVSBhTfwN['cell_toplist']['celllist']
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfOR:
    nJWUHEAokYstyaMIvmDXuCVSBhTfOF=nJWUHEAokYstyaMIvmDXuCVSBhTfOG['contentid']
    nJWUHEAokYstyaMIvmDXuCVSBhTfOi=nJWUHEAokYstyaMIvmDXuCVSBhTfOG['title_list'][0]['text']
    if nJWUHEAokYstyaMIvmDXuCVSBhTfOF in nJWUHEAokYstyaMIvmDXuCVSBhTfOq:
     nJWUHEAokYstyaMIvmDXuCVSBhTfOl=nJWUHEAokYstyaMIvmDXuCVSBhTfOq[nJWUHEAokYstyaMIvmDXuCVSBhTfOF]
     if not nJWUHEAokYstyaMIvmDXuCVSBhTfOl.startswith('http://')and not nJWUHEAokYstyaMIvmDXuCVSBhTfOl.startswith('https://'):
      nJWUHEAokYstyaMIvmDXuCVSBhTfOl=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.HTTPTAG+nJWUHEAokYstyaMIvmDXuCVSBhTfOq[nJWUHEAokYstyaMIvmDXuCVSBhTfOF]
    else:
     nJWUHEAokYstyaMIvmDXuCVSBhTfOl=''
    nJWUHEAokYstyaMIvmDXuCVSBhTfwb=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_getGenre(nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'wavve')
    nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'channelnm':nJWUHEAokYstyaMIvmDXuCVSBhTfOi,'channelimg':nJWUHEAokYstyaMIvmDXuCVSBhTfOl,'ott':'wavve','genrenm':nJWUHEAokYstyaMIvmDXuCVSBhTfwb}
    if nJWUHEAokYstyaMIvmDXuCVSBhTfwb not in exceptGroup:
     nJWUHEAokYstyaMIvmDXuCVSBhTfwq.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[]
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq
 def Get_ChannelList_WavveExcept(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,exceptGroup=[]):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq=[]
  if exceptGroup==[]:return[]
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_WAVVE+'/cf/live/recommend-channels'
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in exceptGroup:
    nJWUHEAokYstyaMIvmDXuCVSBhTfwF={'WeekDay':'all','adult':'n','broadcastid':nJWUHEAokYstyaMIvmDXuCVSBhTfOG['broadcastid'],'contenttype':'channel','genre':nJWUHEAokYstyaMIvmDXuCVSBhTfOG['genre'],'isrecommend':'y','limit':nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    nJWUHEAokYstyaMIvmDXuCVSBhTfwF.update(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_DefaultParams_Wavve())
    nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfwF,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
    nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
    if not('celllist' in nJWUHEAokYstyaMIvmDXuCVSBhTfwN['cell_toplist']):return nJWUHEAokYstyaMIvmDXuCVSBhTfwq
    nJWUHEAokYstyaMIvmDXuCVSBhTfOR=nJWUHEAokYstyaMIvmDXuCVSBhTfwN['cell_toplist']['celllist']
    for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfOR:
     nJWUHEAokYstyaMIvmDXuCVSBhTfwq.append(nJWUHEAokYstyaMIvmDXuCVSBhTfOG['contentid'])
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[]
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq
 def Get_ChannelImg_Wavve(nJWUHEAokYstyaMIvmDXuCVSBhTfwj):
  nJWUHEAokYstyaMIvmDXuCVSBhTfOP={}
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfOp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_Now_Datetime()
   nJWUHEAokYstyaMIvmDXuCVSBhTfON =nJWUHEAokYstyaMIvmDXuCVSBhTfOp+datetime.timedelta(hours=3)
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_WAVVE+'/live/epgs'
   nJWUHEAokYstyaMIvmDXuCVSBhTfwF={'limit':nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':nJWUHEAokYstyaMIvmDXuCVSBhTfOp.strftime('%Y-%m-%d %H:00'),'enddatetime':nJWUHEAokYstyaMIvmDXuCVSBhTfON.strftime('%Y-%m-%d %H:00')}
   nJWUHEAokYstyaMIvmDXuCVSBhTfwF.update(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_DefaultParams_Wavve())
   nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfwF,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
   nJWUHEAokYstyaMIvmDXuCVSBhTfOR=nJWUHEAokYstyaMIvmDXuCVSBhTfwN['list']
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfOR:
    nJWUHEAokYstyaMIvmDXuCVSBhTfOP[nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channelid']]=nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channelimage']
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
  return nJWUHEAokYstyaMIvmDXuCVSBhTfOP
 def Get_ChanneGenrename_Wavve(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,nJWUHEAokYstyaMIvmDXuCVSBhTfOF):
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_WAVVE+'/live/channels/'+nJWUHEAokYstyaMIvmDXuCVSBhTfOF
   nJWUHEAokYstyaMIvmDXuCVSBhTfwF=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_DefaultParams_Wavve()
   nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfwF,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
   nJWUHEAokYstyaMIvmDXuCVSBhTfOg=nJWUHEAokYstyaMIvmDXuCVSBhTfwN['genretext']
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return ''
  return nJWUHEAokYstyaMIvmDXuCVSBhTfOg
 def Get_ChannelList_Spotv(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,payyn=nJWUHEAokYstyaMIvmDXuCVSBhTfjc):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq=[]
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_SPOTV+'/api/v3/channel'
   nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfwN:
    nJWUHEAokYstyaMIvmDXuCVSBhTfOF=nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfOG['id'])
    nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'channelnm':nJWUHEAokYstyaMIvmDXuCVSBhTfOG['name'],'channelimg':nJWUHEAokYstyaMIvmDXuCVSBhTfOG['logo'],'ott':'spotv','genrenm':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_getGenre(nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'spotv'),'free':nJWUHEAokYstyaMIvmDXuCVSBhTfOG['free']}
    nJWUHEAokYstyaMIvmDXuCVSBhTfwq.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[]
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq
 def Get_ChannelList_Tving(nJWUHEAokYstyaMIvmDXuCVSBhTfwj):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq =[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfOb=[]
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_TVING+'/v2/media/lives'
   nJWUHEAokYstyaMIvmDXuCVSBhTfwF={'pageNo':'1','pageSize':nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   nJWUHEAokYstyaMIvmDXuCVSBhTfwF.update(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_DefaultParams_Tving())
   nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfwF,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
   if not('result' in nJWUHEAokYstyaMIvmDXuCVSBhTfwN['body']):return nJWUHEAokYstyaMIvmDXuCVSBhTfwq
   nJWUHEAokYstyaMIvmDXuCVSBhTfOR=nJWUHEAokYstyaMIvmDXuCVSBhTfwN['body']['result']
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfOR:
    if nJWUHEAokYstyaMIvmDXuCVSBhTfOG['live_code']=='C44441':continue 
    nJWUHEAokYstyaMIvmDXuCVSBhTfOb.append(nJWUHEAokYstyaMIvmDXuCVSBhTfOG['live_code'])
   nJWUHEAokYstyaMIvmDXuCVSBhTfOq=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_ChannelImg_Tving(nJWUHEAokYstyaMIvmDXuCVSBhTfOb)
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfOR:
    nJWUHEAokYstyaMIvmDXuCVSBhTfOF=nJWUHEAokYstyaMIvmDXuCVSBhTfOG['live_code']
    if nJWUHEAokYstyaMIvmDXuCVSBhTfOF=='C44441':continue 
    nJWUHEAokYstyaMIvmDXuCVSBhTfOi=nJWUHEAokYstyaMIvmDXuCVSBhTfOG['schedule']['channel']['name']['ko']
    if nJWUHEAokYstyaMIvmDXuCVSBhTfOF in nJWUHEAokYstyaMIvmDXuCVSBhTfOq:
     nJWUHEAokYstyaMIvmDXuCVSBhTfOl=nJWUHEAokYstyaMIvmDXuCVSBhTfOq[nJWUHEAokYstyaMIvmDXuCVSBhTfOF]
    else:
     nJWUHEAokYstyaMIvmDXuCVSBhTfOl=''
    nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'channelnm':nJWUHEAokYstyaMIvmDXuCVSBhTfOi,'channelimg':nJWUHEAokYstyaMIvmDXuCVSBhTfOl,'ott':'tving','genrenm':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_getGenre(nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'tving')}
    nJWUHEAokYstyaMIvmDXuCVSBhTfwq.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[]
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq
 def Get_timestamp(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,timetype=1):
  ts=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,timetype):
  if timetype=='1':
   nJWUHEAokYstyaMIvmDXuCVSBhTfOr={'transactionId':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   nJWUHEAokYstyaMIvmDXuCVSBhTfOr={'timestamp':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_timestamp(timetype=1),'transactionId':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_timestamp(timetype=1)+'000000000000001',}
  return nJWUHEAokYstyaMIvmDXuCVSBhTfOr
 def make_EpgDatetime_Tving(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,days=2):
  nJWUHEAokYstyaMIvmDXuCVSBhTfOQ=[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfOz=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_DateList(days=2,dateType='2')
  nJWUHEAokYstyaMIvmDXuCVSBhTfxw=nJWUHEAokYstyaMIvmDXuCVSBhTfjP(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfOz:
   for nJWUHEAokYstyaMIvmDXuCVSBhTfxO in nJWUHEAokYstyaMIvmDXuCVSBhTfji(8):
    nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'ndate':nJWUHEAokYstyaMIvmDXuCVSBhTfOG,'starttm':nJWUHEAokYstyaMIvmDXuCVSBhTfwx[nJWUHEAokYstyaMIvmDXuCVSBhTfxO]['starttm'],'endtm':nJWUHEAokYstyaMIvmDXuCVSBhTfwx[nJWUHEAokYstyaMIvmDXuCVSBhTfxO]['endtm']}
    nJWUHEAokYstyaMIvmDXuCVSBhTfxL=nJWUHEAokYstyaMIvmDXuCVSBhTfjP(nJWUHEAokYstyaMIvmDXuCVSBhTfOG+nJWUHEAokYstyaMIvmDXuCVSBhTfwx[nJWUHEAokYstyaMIvmDXuCVSBhTfxO]['starttm'])
    nJWUHEAokYstyaMIvmDXuCVSBhTfxj=nJWUHEAokYstyaMIvmDXuCVSBhTfjP(nJWUHEAokYstyaMIvmDXuCVSBhTfOG+nJWUHEAokYstyaMIvmDXuCVSBhTfwx[nJWUHEAokYstyaMIvmDXuCVSBhTfxO]['endtm'])
    if nJWUHEAokYstyaMIvmDXuCVSBhTfxw<=nJWUHEAokYstyaMIvmDXuCVSBhTfxL or(nJWUHEAokYstyaMIvmDXuCVSBhTfxL<nJWUHEAokYstyaMIvmDXuCVSBhTfxw and nJWUHEAokYstyaMIvmDXuCVSBhTfxw<nJWUHEAokYstyaMIvmDXuCVSBhTfxj):
     nJWUHEAokYstyaMIvmDXuCVSBhTfOQ.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  return nJWUHEAokYstyaMIvmDXuCVSBhTfOQ
 def make_DateList(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,days=2,dateType='1'):
  nJWUHEAokYstyaMIvmDXuCVSBhTfOz=[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfxd =nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_Now_Datetime()
  for i in nJWUHEAokYstyaMIvmDXuCVSBhTfji(days):
   nJWUHEAokYstyaMIvmDXuCVSBhTfxK=nJWUHEAokYstyaMIvmDXuCVSBhTfxd+datetime.timedelta(days=i)
   if dateType=='1':
    nJWUHEAokYstyaMIvmDXuCVSBhTfOz.append(nJWUHEAokYstyaMIvmDXuCVSBhTfxK.strftime('%Y-%m-%d'))
   elif dateType=='2':
    nJWUHEAokYstyaMIvmDXuCVSBhTfOz.append(nJWUHEAokYstyaMIvmDXuCVSBhTfxK.strftime('%Y%m%d'))
   else:
    nJWUHEAokYstyaMIvmDXuCVSBhTfOz.append(nJWUHEAokYstyaMIvmDXuCVSBhTfxK)
  return nJWUHEAokYstyaMIvmDXuCVSBhTfOz
 def make_Tving_ChannleGroup(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,nJWUHEAokYstyaMIvmDXuCVSBhTfOb):
  nJWUHEAokYstyaMIvmDXuCVSBhTfxe=[]
  i=0
  nJWUHEAokYstyaMIvmDXuCVSBhTfxc=''
  for nJWUHEAokYstyaMIvmDXuCVSBhTfxR in nJWUHEAokYstyaMIvmDXuCVSBhTfOb:
   if i==0:nJWUHEAokYstyaMIvmDXuCVSBhTfxc=nJWUHEAokYstyaMIvmDXuCVSBhTfxR
   else:nJWUHEAokYstyaMIvmDXuCVSBhTfxc+=',%s'%(nJWUHEAokYstyaMIvmDXuCVSBhTfxR)
   i+=1
   if i>=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.LIMIT_TVINGEPG:
    nJWUHEAokYstyaMIvmDXuCVSBhTfxe.append(nJWUHEAokYstyaMIvmDXuCVSBhTfxc)
    i=0
    nJWUHEAokYstyaMIvmDXuCVSBhTfxc=''
  if nJWUHEAokYstyaMIvmDXuCVSBhTfxc!='':
   nJWUHEAokYstyaMIvmDXuCVSBhTfxe.append(nJWUHEAokYstyaMIvmDXuCVSBhTfxc)
  return nJWUHEAokYstyaMIvmDXuCVSBhTfxe
 def Get_ChannelImg_Tving(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,chid_list):
  nJWUHEAokYstyaMIvmDXuCVSBhTfOP={}
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfxG=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_Now_Datetime().strftime('%Y%m%d')
   nJWUHEAokYstyaMIvmDXuCVSBhTfOp =nJWUHEAokYstyaMIvmDXuCVSBhTfwx[6]['starttm'] 
   nJWUHEAokYstyaMIvmDXuCVSBhTfON =nJWUHEAokYstyaMIvmDXuCVSBhTfwx[6]['endtm']
   nJWUHEAokYstyaMIvmDXuCVSBhTfxe=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_Tving_ChannleGroup(chid_list)
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfxe:
    nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_TVING+'/v2/media/schedules'
    nJWUHEAokYstyaMIvmDXuCVSBhTfwF={'pageNo':'1','pageSize':nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':nJWUHEAokYstyaMIvmDXuCVSBhTfxG,'broadcastDate':nJWUHEAokYstyaMIvmDXuCVSBhTfxG,'startBroadTime':nJWUHEAokYstyaMIvmDXuCVSBhTfOp,'endBroadTime':nJWUHEAokYstyaMIvmDXuCVSBhTfON,'channelCode':nJWUHEAokYstyaMIvmDXuCVSBhTfOG}
    nJWUHEAokYstyaMIvmDXuCVSBhTfwF.update(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_DefaultParams_Tving())
    nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfwF,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
    nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
    if not('result' in nJWUHEAokYstyaMIvmDXuCVSBhTfwN['body']):return{}
    nJWUHEAokYstyaMIvmDXuCVSBhTfOR=nJWUHEAokYstyaMIvmDXuCVSBhTfwN['body']['result']
    for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfOR:
     for nJWUHEAokYstyaMIvmDXuCVSBhTfxF in nJWUHEAokYstyaMIvmDXuCVSBhTfOG['image']:
      if nJWUHEAokYstyaMIvmDXuCVSBhTfxF['code']=='CAIC0400':nJWUHEAokYstyaMIvmDXuCVSBhTfOP[nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channel_code']]=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_TVINGIMG+nJWUHEAokYstyaMIvmDXuCVSBhTfxF['url']
      elif nJWUHEAokYstyaMIvmDXuCVSBhTfxF['code']=='CAIC1400':nJWUHEAokYstyaMIvmDXuCVSBhTfOP[nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channel_code']]=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_TVINGIMG+nJWUHEAokYstyaMIvmDXuCVSBhTfxF['url']
      elif nJWUHEAokYstyaMIvmDXuCVSBhTfxF['code']=='CAIC1900':nJWUHEAokYstyaMIvmDXuCVSBhTfOP[nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channel_code']]=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_TVINGIMG+nJWUHEAokYstyaMIvmDXuCVSBhTfxF['url']
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return{}
  return nJWUHEAokYstyaMIvmDXuCVSBhTfOP
 def Get_EpgInfo_Spotv(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,days=2,payyn=nJWUHEAokYstyaMIvmDXuCVSBhTfjc):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq=[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfwQ =[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfOz=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_DateList(days=days,dateType='1')
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_SPOTV+'/api/v3/channel'
   nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfwN:
    nJWUHEAokYstyaMIvmDXuCVSBhTfOF =nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfOG['id'])
    nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'channelnm':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.xmlText(nJWUHEAokYstyaMIvmDXuCVSBhTfOG['name']),'channelimg':nJWUHEAokYstyaMIvmDXuCVSBhTfOG['logo'],'ott':'spotv'}
    nJWUHEAokYstyaMIvmDXuCVSBhTfwq.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[],[]
  try:
   for nJWUHEAokYstyaMIvmDXuCVSBhTfxi in nJWUHEAokYstyaMIvmDXuCVSBhTfOz:
    nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_SPOTV+'/api/v3/program/'+nJWUHEAokYstyaMIvmDXuCVSBhTfxi
    nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
    nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
    for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfwN:
     nJWUHEAokYstyaMIvmDXuCVSBhTfOF =nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channelId'])
     nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'title':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.xmlText(nJWUHEAokYstyaMIvmDXuCVSBhTfOG['title']),'startTime':nJWUHEAokYstyaMIvmDXuCVSBhTfOG['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':nJWUHEAokYstyaMIvmDXuCVSBhTfOG['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     nJWUHEAokYstyaMIvmDXuCVSBhTfwQ.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
    time.sleep(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.SLEEP_TIME)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[],[]
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq,nJWUHEAokYstyaMIvmDXuCVSBhTfwQ
 def Make_Wavve_TimeList(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,days=2):
  nJWUHEAokYstyaMIvmDXuCVSBhTfOQ=[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfxl=[['00:00','03:00'],['03:00','06:00'],['06:00','09:00'],['09:00','12:00'],['12:00','15:00'],['15:00','18:00'],['18:00','21:00'],['21:00','24:00'],]
  nJWUHEAokYstyaMIvmDXuCVSBhTfxq =nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_Now_Datetime()
  for i in nJWUHEAokYstyaMIvmDXuCVSBhTfji(days):
   nJWUHEAokYstyaMIvmDXuCVSBhTfxP =nJWUHEAokYstyaMIvmDXuCVSBhTfxq+datetime.timedelta(days=+i)
   nJWUHEAokYstyaMIvmDXuCVSBhTfOd =nJWUHEAokYstyaMIvmDXuCVSBhTfxP.strftime('%Y-%m-%d')
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOx in nJWUHEAokYstyaMIvmDXuCVSBhTfxl:
    nJWUHEAokYstyaMIvmDXuCVSBhTfxp=['{} {}'.format(nJWUHEAokYstyaMIvmDXuCVSBhTfOd,nJWUHEAokYstyaMIvmDXuCVSBhTfOx[0]),'{} {}'.format(nJWUHEAokYstyaMIvmDXuCVSBhTfOd,nJWUHEAokYstyaMIvmDXuCVSBhTfOx[1]),]
    nJWUHEAokYstyaMIvmDXuCVSBhTfOQ.append(nJWUHEAokYstyaMIvmDXuCVSBhTfxp)
  return nJWUHEAokYstyaMIvmDXuCVSBhTfOQ
 def Get_EpgInfo_Wavve(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,days=2,exceptGroup=[]):
  nJWUHEAokYstyaMIvmDXuCVSBhTfxN =[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq =[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfwQ =[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfOQ=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Make_Wavve_TimeList(days)
  try:
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOx in nJWUHEAokYstyaMIvmDXuCVSBhTfOQ:
    nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_WAVVE+'/live/epgs'
    nJWUHEAokYstyaMIvmDXuCVSBhTfwF={'limit':nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':nJWUHEAokYstyaMIvmDXuCVSBhTfOx[0],'enddatetime':nJWUHEAokYstyaMIvmDXuCVSBhTfOx[1],}
    nJWUHEAokYstyaMIvmDXuCVSBhTfwF.update(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_DefaultParams_Wavve())
    nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfwF,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
    nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
    nJWUHEAokYstyaMIvmDXuCVSBhTfxg=nJWUHEAokYstyaMIvmDXuCVSBhTfwN['list']
    for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfxg:
     nJWUHEAokYstyaMIvmDXuCVSBhTfOF =nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channelid']
     nJWUHEAokYstyaMIvmDXuCVSBhTfwb=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_getGenre(nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'wavve')
     nJWUHEAokYstyaMIvmDXuCVSBhTfOl =nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channelimage']
     if not nJWUHEAokYstyaMIvmDXuCVSBhTfOl.startswith('http://')and not nJWUHEAokYstyaMIvmDXuCVSBhTfOl.startswith('https://'):
      nJWUHEAokYstyaMIvmDXuCVSBhTfOl=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.HTTPTAG+nJWUHEAokYstyaMIvmDXuCVSBhTfOl
     nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'channelnm':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.xmlText(nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channelname']),'channelimg':nJWUHEAokYstyaMIvmDXuCVSBhTfOl,'ott':'wavve'}
     if nJWUHEAokYstyaMIvmDXuCVSBhTfwb not in exceptGroup and nJWUHEAokYstyaMIvmDXuCVSBhTfOF not in nJWUHEAokYstyaMIvmDXuCVSBhTfxN:
      nJWUHEAokYstyaMIvmDXuCVSBhTfwq.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
      nJWUHEAokYstyaMIvmDXuCVSBhTfxN.append(nJWUHEAokYstyaMIvmDXuCVSBhTfOF)
     for nJWUHEAokYstyaMIvmDXuCVSBhTfxb in nJWUHEAokYstyaMIvmDXuCVSBhTfOG['list']:
      nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channelid'],'title':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.xmlText(nJWUHEAokYstyaMIvmDXuCVSBhTfxb['title']),'startTime':nJWUHEAokYstyaMIvmDXuCVSBhTfxb['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':nJWUHEAokYstyaMIvmDXuCVSBhTfxb['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
      if nJWUHEAokYstyaMIvmDXuCVSBhTfwb not in exceptGroup and nJWUHEAokYstyaMIvmDXuCVSBhTfxb['starttime']!=nJWUHEAokYstyaMIvmDXuCVSBhTfxb['endtime']:
       nJWUHEAokYstyaMIvmDXuCVSBhTfwQ.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[],[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfxr=nJWUHEAokYstyaMIvmDXuCVSBhTfjl(nJWUHEAokYstyaMIvmDXuCVSBhTfwQ)
  for i in(nJWUHEAokYstyaMIvmDXuCVSBhTfji(1,nJWUHEAokYstyaMIvmDXuCVSBhTfxr)):
   if nJWUHEAokYstyaMIvmDXuCVSBhTfjP(nJWUHEAokYstyaMIvmDXuCVSBhTfwQ[i-1]['endTime'])+1==nJWUHEAokYstyaMIvmDXuCVSBhTfjP(nJWUHEAokYstyaMIvmDXuCVSBhTfwQ[i]['startTime'])and nJWUHEAokYstyaMIvmDXuCVSBhTfwQ[i-1]['channelid']==nJWUHEAokYstyaMIvmDXuCVSBhTfwQ[i]['channelid']:
    nJWUHEAokYstyaMIvmDXuCVSBhTfwQ[i-1]['endTime']=nJWUHEAokYstyaMIvmDXuCVSBhTfwQ[i]['startTime']
  nJWUHEAokYstyaMIvmDXuCVSBhTfjF(nJWUHEAokYstyaMIvmDXuCVSBhTfjl(nJWUHEAokYstyaMIvmDXuCVSBhTfwq))
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq,nJWUHEAokYstyaMIvmDXuCVSBhTfwQ
 def Get_EpgInfo_Tving(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,days=2):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq=[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfwQ =[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfxN =[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfwz =nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_EpgDatetime_Tving(days=days)
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq =nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_ChannelList_Tving()
  nJWUHEAokYstyaMIvmDXuCVSBhTfxQ=[]
  for i in nJWUHEAokYstyaMIvmDXuCVSBhTfji(nJWUHEAokYstyaMIvmDXuCVSBhTfjl(nJWUHEAokYstyaMIvmDXuCVSBhTfwq)):
   nJWUHEAokYstyaMIvmDXuCVSBhTfwq[i]['channelnm']=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.xmlText(nJWUHEAokYstyaMIvmDXuCVSBhTfwq[i]['channelnm'])
   nJWUHEAokYstyaMIvmDXuCVSBhTfxQ.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwq[i]['channelid'])
  nJWUHEAokYstyaMIvmDXuCVSBhTfxz=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_Tving_ChannleGroup(nJWUHEAokYstyaMIvmDXuCVSBhTfxQ)
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_TVING+'/v2/media/schedules'
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOx in nJWUHEAokYstyaMIvmDXuCVSBhTfwz:
    for nJWUHEAokYstyaMIvmDXuCVSBhTfOw in nJWUHEAokYstyaMIvmDXuCVSBhTfxz:
     nJWUHEAokYstyaMIvmDXuCVSBhTfwF={'pageNo':'1','pageSize':nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':nJWUHEAokYstyaMIvmDXuCVSBhTfOx['ndate'],'broadcastDate':nJWUHEAokYstyaMIvmDXuCVSBhTfOx['ndate'],'startBroadTime':nJWUHEAokYstyaMIvmDXuCVSBhTfOx['starttm'],'endBroadTime':nJWUHEAokYstyaMIvmDXuCVSBhTfOx['endtm'],'channelCode':nJWUHEAokYstyaMIvmDXuCVSBhTfOw}
     nJWUHEAokYstyaMIvmDXuCVSBhTfwF.update(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_DefaultParams_Tving())
     nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfwF,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
     nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
     nJWUHEAokYstyaMIvmDXuCVSBhTfOR=nJWUHEAokYstyaMIvmDXuCVSBhTfwN['body']['result']
     for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfOR:
      if 'schedules' not in nJWUHEAokYstyaMIvmDXuCVSBhTfOG:continue
      if nJWUHEAokYstyaMIvmDXuCVSBhTfOG['schedules']==nJWUHEAokYstyaMIvmDXuCVSBhTfjR:continue
      for nJWUHEAokYstyaMIvmDXuCVSBhTfLw in nJWUHEAokYstyaMIvmDXuCVSBhTfOG['schedules']:
       nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfLw['schedule_code'],'title':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.xmlText(nJWUHEAokYstyaMIvmDXuCVSBhTfLw['program']['name']['ko']),'startTime':nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfLw['broadcast_start_time']),'endTime':nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfLw['broadcast_end_time']),'ott':'tving'}
       nJWUHEAokYstyaMIvmDXuCVSBhTfLO=nJWUHEAokYstyaMIvmDXuCVSBhTfLw['schedule_code']+nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfLw['broadcast_start_time'])
       if nJWUHEAokYstyaMIvmDXuCVSBhTfLO in nJWUHEAokYstyaMIvmDXuCVSBhTfxN:continue
       nJWUHEAokYstyaMIvmDXuCVSBhTfxN.append(nJWUHEAokYstyaMIvmDXuCVSBhTfLO)
       nJWUHEAokYstyaMIvmDXuCVSBhTfwQ.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
     time.sleep(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.SLEEP_TIME)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[],[]
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq,nJWUHEAokYstyaMIvmDXuCVSBhTfwQ
 def Get_BaseInfo_Samsungtv(nJWUHEAokYstyaMIvmDXuCVSBhTfwj):
  nJWUHEAokYstyaMIvmDXuCVSBhTfLx={}
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_SAMSUNGTV
   nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfjR)
   for nJWUHEAokYstyaMIvmDXuCVSBhTfLj in nJWUHEAokYstyaMIvmDXuCVSBhTfwp.cookies:
    if nJWUHEAokYstyaMIvmDXuCVSBhTfLj.name=='session':
     nJWUHEAokYstyaMIvmDXuCVSBhTfLx['session']=nJWUHEAokYstyaMIvmDXuCVSBhTfLj.value
    elif nJWUHEAokYstyaMIvmDXuCVSBhTfLj.name=='session.sig':
     nJWUHEAokYstyaMIvmDXuCVSBhTfLx['session.sig']=nJWUHEAokYstyaMIvmDXuCVSBhTfLj.value
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return{}
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_SAMSUNGTV+'/user'
   nJWUHEAokYstyaMIvmDXuCVSBhTfLd={'session':nJWUHEAokYstyaMIvmDXuCVSBhTfLx['session'],'session.sig':nJWUHEAokYstyaMIvmDXuCVSBhTfLx['session.sig'],}
   nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfLd)
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
   nJWUHEAokYstyaMIvmDXuCVSBhTfLx['countryCode']=nJWUHEAokYstyaMIvmDXuCVSBhTfwN.get('countryCode')
   nJWUHEAokYstyaMIvmDXuCVSBhTfLx['uuid'] =nJWUHEAokYstyaMIvmDXuCVSBhTfwN.get('uuid')
   nJWUHEAokYstyaMIvmDXuCVSBhTfLx['ip'] =nJWUHEAokYstyaMIvmDXuCVSBhTfwN.get('ip')
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return{}
  return nJWUHEAokYstyaMIvmDXuCVSBhTfLx
 def t_Cache(nJWUHEAokYstyaMIvmDXuCVSBhTfwj):
  nJWUHEAokYstyaMIvmDXuCVSBhTfxw =nJWUHEAokYstyaMIvmDXuCVSBhTfjP(time.time())
  nJWUHEAokYstyaMIvmDXuCVSBhTfLK=nJWUHEAokYstyaMIvmDXuCVSBhTfjP(nJWUHEAokYstyaMIvmDXuCVSBhTfxw-nJWUHEAokYstyaMIvmDXuCVSBhTfxw%3600)
  return nJWUHEAokYstyaMIvmDXuCVSBhTfLK,nJWUHEAokYstyaMIvmDXuCVSBhTfxw
 def zlib_compress(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,plaintext):
  nJWUHEAokYstyaMIvmDXuCVSBhTfLe=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(nJWUHEAokYstyaMIvmDXuCVSBhTfLe).decode('utf-8')
 def Get_BaseRequest_Samsungtv(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,nJWUHEAokYstyaMIvmDXuCVSBhTfLx):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwN={}
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwP=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.API_SAMSUNGTV+'/api/lives'
   nJWUHEAokYstyaMIvmDXuCVSBhTfLK,nJWUHEAokYstyaMIvmDXuCVSBhTfxw=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.t_Cache()
   nJWUHEAokYstyaMIvmDXuCVSBhTfLc=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.zlib_compress(nJWUHEAokYstyaMIvmDXuCVSBhTfLx['uuid']+':'+nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfxw))
   nJWUHEAokYstyaMIvmDXuCVSBhTfLd={'session':nJWUHEAokYstyaMIvmDXuCVSBhTfLx['session'],'session.sig':nJWUHEAokYstyaMIvmDXuCVSBhTfLx['session.sig'],}
   nJWUHEAokYstyaMIvmDXuCVSBhTfwF ={'t':nJWUHEAokYstyaMIvmDXuCVSBhTfjq(nJWUHEAokYstyaMIvmDXuCVSBhTfLK)}
   nJWUHEAokYstyaMIvmDXuCVSBhTfLR ={'x-cred-payload':nJWUHEAokYstyaMIvmDXuCVSBhTfLc}
   nJWUHEAokYstyaMIvmDXuCVSBhTfwp=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.callRequestCookies('Get',nJWUHEAokYstyaMIvmDXuCVSBhTfwP,payload=nJWUHEAokYstyaMIvmDXuCVSBhTfjR,params=nJWUHEAokYstyaMIvmDXuCVSBhTfwF,headers=nJWUHEAokYstyaMIvmDXuCVSBhTfLR,cookies=nJWUHEAokYstyaMIvmDXuCVSBhTfLd)
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN=json.loads(nJWUHEAokYstyaMIvmDXuCVSBhTfwp.text)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwN
 def Make_Samsungtv_logoUrl(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,fullUrl):
  nJWUHEAokYstyaMIvmDXuCVSBhTfLG=urllib.parse.urlparse(fullUrl) 
  if nJWUHEAokYstyaMIvmDXuCVSBhTfLG.netloc=='us-image.samsungtvplus.com':
   nJWUHEAokYstyaMIvmDXuCVSBhTfLF=nJWUHEAokYstyaMIvmDXuCVSBhTfjp(urllib.parse.parse_qsl(nJWUHEAokYstyaMIvmDXuCVSBhTfLG.query))
   if 'url' in nJWUHEAokYstyaMIvmDXuCVSBhTfLF:
    return nJWUHEAokYstyaMIvmDXuCVSBhTfLF.get('url')
  return fullUrl
 def Get_ChannelList_Samsungtv(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,nJWUHEAokYstyaMIvmDXuCVSBhTfLx,exceptGroup=[]):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq =[]
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_BaseRequest_Samsungtv(nJWUHEAokYstyaMIvmDXuCVSBhTfLx)
   nJWUHEAokYstyaMIvmDXuCVSBhTfOR=nJWUHEAokYstyaMIvmDXuCVSBhTfwN['live']['channel']
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfOR:
    nJWUHEAokYstyaMIvmDXuCVSBhTfOF =nJWUHEAokYstyaMIvmDXuCVSBhTfOG.get('id')
    nJWUHEAokYstyaMIvmDXuCVSBhTfOi =nJWUHEAokYstyaMIvmDXuCVSBhTfOG.get('name')
    nJWUHEAokYstyaMIvmDXuCVSBhTfOl=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Make_Samsungtv_logoUrl(nJWUHEAokYstyaMIvmDXuCVSBhTfOG.get('logo'))
    nJWUHEAokYstyaMIvmDXuCVSBhTfwb=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_getGenre(nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'samsung')
    if nJWUHEAokYstyaMIvmDXuCVSBhTfwb in['-','']:nJWUHEAokYstyaMIvmDXuCVSBhTfwb='정주행 채널'
    nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'channelnm':nJWUHEAokYstyaMIvmDXuCVSBhTfOi,'channelimg':nJWUHEAokYstyaMIvmDXuCVSBhTfOl,'ott':'samsung','genrenm':nJWUHEAokYstyaMIvmDXuCVSBhTfwb}
    if nJWUHEAokYstyaMIvmDXuCVSBhTfwb not in exceptGroup:
     nJWUHEAokYstyaMIvmDXuCVSBhTfwq.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[]
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq
 def Get_EpgInfo_Samsungtv(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,nJWUHEAokYstyaMIvmDXuCVSBhTfLx,exceptGroup=[]):
  nJWUHEAokYstyaMIvmDXuCVSBhTfwq=[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfwQ =[]
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfwN =nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_BaseRequest_Samsungtv(nJWUHEAokYstyaMIvmDXuCVSBhTfLx)
   nJWUHEAokYstyaMIvmDXuCVSBhTfOG=nJWUHEAokYstyaMIvmDXuCVSBhTfwN['live']['channel']
   for nJWUHEAokYstyaMIvmDXuCVSBhTfOw in nJWUHEAokYstyaMIvmDXuCVSBhTfOG:
    nJWUHEAokYstyaMIvmDXuCVSBhTfOF =nJWUHEAokYstyaMIvmDXuCVSBhTfOw.get('id')
    nJWUHEAokYstyaMIvmDXuCVSBhTfOi =nJWUHEAokYstyaMIvmDXuCVSBhTfOw.get('name')
    nJWUHEAokYstyaMIvmDXuCVSBhTfOl=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Make_Samsungtv_logoUrl(nJWUHEAokYstyaMIvmDXuCVSBhTfOw.get('logo'))
    nJWUHEAokYstyaMIvmDXuCVSBhTfxg =nJWUHEAokYstyaMIvmDXuCVSBhTfOw.get('program')
    nJWUHEAokYstyaMIvmDXuCVSBhTfwb=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.make_getGenre(nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'samsung')
    if nJWUHEAokYstyaMIvmDXuCVSBhTfwb in exceptGroup:
     continue
    nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'channelnm':nJWUHEAokYstyaMIvmDXuCVSBhTfOi,'channelimg':nJWUHEAokYstyaMIvmDXuCVSBhTfOl,'ott':'samsung','genrenm':nJWUHEAokYstyaMIvmDXuCVSBhTfwb}
    nJWUHEAokYstyaMIvmDXuCVSBhTfwq.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
    for nJWUHEAokYstyaMIvmDXuCVSBhTfxb in nJWUHEAokYstyaMIvmDXuCVSBhTfxg:
     nJWUHEAokYstyaMIvmDXuCVSBhTfLi=nJWUHEAokYstyaMIvmDXuCVSBhTfxb.get('start_time')
     nJWUHEAokYstyaMIvmDXuCVSBhTfLl =nJWUHEAokYstyaMIvmDXuCVSBhTfxb.get('duration') 
     nJWUHEAokYstyaMIvmDXuCVSBhTfOp=datetime.datetime.strptime(nJWUHEAokYstyaMIvmDXuCVSBhTfLi,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     nJWUHEAokYstyaMIvmDXuCVSBhTfON =nJWUHEAokYstyaMIvmDXuCVSBhTfOp+datetime.timedelta(seconds=nJWUHEAokYstyaMIvmDXuCVSBhTfLl)
     nJWUHEAokYstyaMIvmDXuCVSBhTfwr={'channelid':nJWUHEAokYstyaMIvmDXuCVSBhTfOF,'title':nJWUHEAokYstyaMIvmDXuCVSBhTfwj.xmlText(urllib.parse.unquote_plus(nJWUHEAokYstyaMIvmDXuCVSBhTfxb.get('title'))),'startTime':nJWUHEAokYstyaMIvmDXuCVSBhTfOp.strftime('%Y%m%d%H%M00'),'endTime':nJWUHEAokYstyaMIvmDXuCVSBhTfON.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     nJWUHEAokYstyaMIvmDXuCVSBhTfwQ.append(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  except nJWUHEAokYstyaMIvmDXuCVSBhTfjG as exception:
   nJWUHEAokYstyaMIvmDXuCVSBhTfjF(exception)
   return[],[]
  return nJWUHEAokYstyaMIvmDXuCVSBhTfwq,nJWUHEAokYstyaMIvmDXuCVSBhTfwQ
 def make_getGenre(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,nJWUHEAokYstyaMIvmDXuCVSBhTfOF,nJWUHEAokYstyaMIvmDXuCVSBhTfjw):
  try:
   nJWUHEAokYstyaMIvmDXuCVSBhTfOg=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.INIT_CHANNEL.get(nJWUHEAokYstyaMIvmDXuCVSBhTfOF+'.'+nJWUHEAokYstyaMIvmDXuCVSBhTfjw).get('genre')
  except:
   nJWUHEAokYstyaMIvmDXuCVSBhTfOg=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.INIT_CHANNEL.get('-').get('genre')
  return nJWUHEAokYstyaMIvmDXuCVSBhTfOg
 def make_base_allchannel_py(nJWUHEAokYstyaMIvmDXuCVSBhTfwj,nJWUHEAokYstyaMIvmDXuCVSBhTfLx):
  nJWUHEAokYstyaMIvmDXuCVSBhTfLq =[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfLP=[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfLp=[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfLN=[]
  nJWUHEAokYstyaMIvmDXuCVSBhTfLg=nJWUHEAokYstyaMIvmDXuCVSBhTfjN()
  nJWUHEAokYstyaMIvmDXuCVSBhTfwr=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_ChannelList_Wavve()
  nJWUHEAokYstyaMIvmDXuCVSBhTfLq.extend(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  nJWUHEAokYstyaMIvmDXuCVSBhTfwr=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_ChannelList_Tving()
  nJWUHEAokYstyaMIvmDXuCVSBhTfLq.extend(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  nJWUHEAokYstyaMIvmDXuCVSBhTfwr=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_ChannelList_Spotv()
  nJWUHEAokYstyaMIvmDXuCVSBhTfLq.extend(nJWUHEAokYstyaMIvmDXuCVSBhTfwr)
  nJWUHEAokYstyaMIvmDXuCVSBhTfjF('1')
  for i in nJWUHEAokYstyaMIvmDXuCVSBhTfji(nJWUHEAokYstyaMIvmDXuCVSBhTfjl(nJWUHEAokYstyaMIvmDXuCVSBhTfLq)):
   if nJWUHEAokYstyaMIvmDXuCVSBhTfLq[i]['genrenm']=='-':
    if nJWUHEAokYstyaMIvmDXuCVSBhTfLq[i]['ott']=='wavve':
     nJWUHEAokYstyaMIvmDXuCVSBhTfOg=nJWUHEAokYstyaMIvmDXuCVSBhTfwj.Get_ChanneGenrename_Wavve(nJWUHEAokYstyaMIvmDXuCVSBhTfLq[i]['channelid'])
     if nJWUHEAokYstyaMIvmDXuCVSBhTfOg not in nJWUHEAokYstyaMIvmDXuCVSBhTfLg:nJWUHEAokYstyaMIvmDXuCVSBhTfLg.add(nJWUHEAokYstyaMIvmDXuCVSBhTfOg)
     time.sleep(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.SLEEP_TIME)
    elif nJWUHEAokYstyaMIvmDXuCVSBhTfLq[i]['ott']=='spotv':
     nJWUHEAokYstyaMIvmDXuCVSBhTfOg='스포츠'
    else:
     nJWUHEAokYstyaMIvmDXuCVSBhTfOg='-'
    nJWUHEAokYstyaMIvmDXuCVSBhTfLq[i]['genrenm']=nJWUHEAokYstyaMIvmDXuCVSBhTfOg
   else:
    if nJWUHEAokYstyaMIvmDXuCVSBhTfLq[i]['genrenm']not in nJWUHEAokYstyaMIvmDXuCVSBhTfLg:nJWUHEAokYstyaMIvmDXuCVSBhTfLg.add(nJWUHEAokYstyaMIvmDXuCVSBhTfLq[i]['genrenm'])
  nJWUHEAokYstyaMIvmDXuCVSBhTfLg.add(nJWUHEAokYstyaMIvmDXuCVSBhTfwj.INIT_CHANNEL.get('-').get('genre'))
  nJWUHEAokYstyaMIvmDXuCVSBhTfjF('2')
  for nJWUHEAokYstyaMIvmDXuCVSBhTfLb in nJWUHEAokYstyaMIvmDXuCVSBhTfLg:
   for nJWUHEAokYstyaMIvmDXuCVSBhTfLr in nJWUHEAokYstyaMIvmDXuCVSBhTfLq:
    if nJWUHEAokYstyaMIvmDXuCVSBhTfLr['genrenm']==nJWUHEAokYstyaMIvmDXuCVSBhTfLb:
     nJWUHEAokYstyaMIvmDXuCVSBhTfLP.append(nJWUHEAokYstyaMIvmDXuCVSBhTfLr)
  for nJWUHEAokYstyaMIvmDXuCVSBhTfLr in nJWUHEAokYstyaMIvmDXuCVSBhTfLq:
   if nJWUHEAokYstyaMIvmDXuCVSBhTfLr['genrenm']not in nJWUHEAokYstyaMIvmDXuCVSBhTfLg:
    nJWUHEAokYstyaMIvmDXuCVSBhTfLP.append(nJWUHEAokYstyaMIvmDXuCVSBhTfLr)
  nJWUHEAokYstyaMIvmDXuCVSBhTfjF('3')
  nJWUHEAokYstyaMIvmDXuCVSBhTfLQ='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(nJWUHEAokYstyaMIvmDXuCVSBhTfLQ):os.remove(nJWUHEAokYstyaMIvmDXuCVSBhTfLQ)
  fp=nJWUHEAokYstyaMIvmDXuCVSBhTfje(nJWUHEAokYstyaMIvmDXuCVSBhTfLQ,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  nJWUHEAokYstyaMIvmDXuCVSBhTfLz=nJWUHEAokYstyaMIvmDXuCVSBhTfjl(nJWUHEAokYstyaMIvmDXuCVSBhTfLP)
  i=0
  for nJWUHEAokYstyaMIvmDXuCVSBhTfOG in nJWUHEAokYstyaMIvmDXuCVSBhTfLP:
   i+=1
   nJWUHEAokYstyaMIvmDXuCVSBhTfOF =nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channelid']
   nJWUHEAokYstyaMIvmDXuCVSBhTfOi =nJWUHEAokYstyaMIvmDXuCVSBhTfOG['channelnm']
   nJWUHEAokYstyaMIvmDXuCVSBhTfjw =nJWUHEAokYstyaMIvmDXuCVSBhTfOG['ott']
   nJWUHEAokYstyaMIvmDXuCVSBhTfjO ='%s.%s'%(nJWUHEAokYstyaMIvmDXuCVSBhTfOF,nJWUHEAokYstyaMIvmDXuCVSBhTfjw)
   nJWUHEAokYstyaMIvmDXuCVSBhTfOg =nJWUHEAokYstyaMIvmDXuCVSBhTfOG['genrenm']
   nJWUHEAokYstyaMIvmDXuCVSBhTfjx='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(nJWUHEAokYstyaMIvmDXuCVSBhTfjO,nJWUHEAokYstyaMIvmDXuCVSBhTfOi,nJWUHEAokYstyaMIvmDXuCVSBhTfOg)
   if i<nJWUHEAokYstyaMIvmDXuCVSBhTfLz:
    fp.write(nJWUHEAokYstyaMIvmDXuCVSBhTfjx+',\n')
   else:
    fp.write(nJWUHEAokYstyaMIvmDXuCVSBhTfjx+'\n')
   nJWUHEAokYstyaMIvmDXuCVSBhTfLp.append(nJWUHEAokYstyaMIvmDXuCVSBhTfjO)
   nJWUHEAokYstyaMIvmDXuCVSBhTfLN.append(nJWUHEAokYstyaMIvmDXuCVSBhTfjO+'.'+nJWUHEAokYstyaMIvmDXuCVSBhTfOi)
  fp.write('}\n')
  fp.close()
  for nJWUHEAokYstyaMIvmDXuCVSBhTfjL,value in nJWUHEAokYstyaMIvmDXuCVSBhTfwj.INIT_CHANNEL.items():
   if nJWUHEAokYstyaMIvmDXuCVSBhTfjL not in nJWUHEAokYstyaMIvmDXuCVSBhTfLp:
    nJWUHEAokYstyaMIvmDXuCVSBhTfjR
  for nJWUHEAokYstyaMIvmDXuCVSBhTfjL,value in nJWUHEAokYstyaMIvmDXuCVSBhTfwj.INIT_CHANNEL.items():
   if nJWUHEAokYstyaMIvmDXuCVSBhTfjL+'.'+value.get('channelnm')not in nJWUHEAokYstyaMIvmDXuCVSBhTfLN:
    nJWUHEAokYstyaMIvmDXuCVSBhTfjF(nJWUHEAokYstyaMIvmDXuCVSBhTfjL+'.'+value.get('channelnm'))
    nJWUHEAokYstyaMIvmDXuCVSBhTfjR
  return nJWUHEAokYstyaMIvmDXuCVSBhTfLg
# Created by pyminifier (https://github.com/liftoff/pyminifier)
