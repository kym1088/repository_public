__author__="NightRain"
etAOsfCmglvJWTBozVFDjPbchkqIiS=object
etAOsfCmglvJWTBozVFDjPbchkqIiK=False
etAOsfCmglvJWTBozVFDjPbchkqIiE=None
etAOsfCmglvJWTBozVFDjPbchkqIip=True
etAOsfCmglvJWTBozVFDjPbchkqIiR=getattr
etAOsfCmglvJWTBozVFDjPbchkqIiH=type
etAOsfCmglvJWTBozVFDjPbchkqIia=int
etAOsfCmglvJWTBozVFDjPbchkqIiU=list
etAOsfCmglvJWTBozVFDjPbchkqIid=len
etAOsfCmglvJWTBozVFDjPbchkqIiL=str
etAOsfCmglvJWTBozVFDjPbchkqIiX=open
etAOsfCmglvJWTBozVFDjPbchkqIiG=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
etAOsfCmglvJWTBozVFDjPbchkqIrx=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'     - M3U 추가 (SBS)','mode':'ADD_M3U','sType':'bc_sbs','sName':'SBS'},{'title':'     - M3U 추가 (사용자 m3u)','mode':'ADD_M3U','sType':'custom','sName':'사용자 m3u 파일'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
etAOsfCmglvJWTBozVFDjPbchkqIri={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
etAOsfCmglvJWTBozVFDjPbchkqIrN=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class etAOsfCmglvJWTBozVFDjPbchkqIrY(etAOsfCmglvJWTBozVFDjPbchkqIiS):
 def __init__(etAOsfCmglvJWTBozVFDjPbchkqIrQ,etAOsfCmglvJWTBozVFDjPbchkqIrw,etAOsfCmglvJWTBozVFDjPbchkqIrn,etAOsfCmglvJWTBozVFDjPbchkqIrS):
  etAOsfCmglvJWTBozVFDjPbchkqIrQ._addon_url =etAOsfCmglvJWTBozVFDjPbchkqIrw
  etAOsfCmglvJWTBozVFDjPbchkqIrQ._addon_handle =etAOsfCmglvJWTBozVFDjPbchkqIrn
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.main_params =etAOsfCmglvJWTBozVFDjPbchkqIrS
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_FILE_PATH ='' 
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_FILE_NAME ='' 
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVE =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONTVING =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSPOTV =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSAMSUNG =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_BC_SBS =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVERADIO =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVEHOME =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONRELIGION =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSPOTVPAY =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSAMSUNGHOME=etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_DISPLAYNM =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_AUTORESTART =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_CUSTOM_LIST =[]
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj =nJWUHEAokYstyaMIvmDXuCVSBhTfwO() 
 def addon_noti(etAOsfCmglvJWTBozVFDjPbchkqIrQ,sting):
  try:
   etAOsfCmglvJWTBozVFDjPbchkqIrE=xbmcgui.Dialog()
   etAOsfCmglvJWTBozVFDjPbchkqIrE.notification(__addonname__,sting)
  except:
   etAOsfCmglvJWTBozVFDjPbchkqIiE
 def addon_log(etAOsfCmglvJWTBozVFDjPbchkqIrQ,string):
  try:
   etAOsfCmglvJWTBozVFDjPbchkqIrp=string.encode('utf-8','ignore')
  except:
   etAOsfCmglvJWTBozVFDjPbchkqIrp='addonException: addon_log'
  etAOsfCmglvJWTBozVFDjPbchkqIrR=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,etAOsfCmglvJWTBozVFDjPbchkqIrp),level=etAOsfCmglvJWTBozVFDjPbchkqIrR)
 def get_keyboard_input(etAOsfCmglvJWTBozVFDjPbchkqIrQ,etAOsfCmglvJWTBozVFDjPbchkqIrU):
  etAOsfCmglvJWTBozVFDjPbchkqIrH=etAOsfCmglvJWTBozVFDjPbchkqIiE
  kb=xbmc.Keyboard()
  kb.setHeading(etAOsfCmglvJWTBozVFDjPbchkqIrU)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   etAOsfCmglvJWTBozVFDjPbchkqIrH=kb.getText()
  return etAOsfCmglvJWTBozVFDjPbchkqIrH
 def add_dir(etAOsfCmglvJWTBozVFDjPbchkqIrQ,label,sublabel='',img='',infoLabels=etAOsfCmglvJWTBozVFDjPbchkqIiE,isFolder=etAOsfCmglvJWTBozVFDjPbchkqIip,params='',isLink=etAOsfCmglvJWTBozVFDjPbchkqIiK,ContextMenu=etAOsfCmglvJWTBozVFDjPbchkqIiE):
  etAOsfCmglvJWTBozVFDjPbchkqIra='%s?%s'%(etAOsfCmglvJWTBozVFDjPbchkqIrQ._addon_url,urllib.parse.urlencode(params))
  if sublabel:etAOsfCmglvJWTBozVFDjPbchkqIrU='%s < %s >'%(label,sublabel)
  else: etAOsfCmglvJWTBozVFDjPbchkqIrU=label
  if not img:img='DefaultFolder.png'
  etAOsfCmglvJWTBozVFDjPbchkqIrd=xbmcgui.ListItem(etAOsfCmglvJWTBozVFDjPbchkqIrU)
  etAOsfCmglvJWTBozVFDjPbchkqIrd.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.KodiVersion>=20:
   if infoLabels:etAOsfCmglvJWTBozVFDjPbchkqIrQ.Set_InfoTag(etAOsfCmglvJWTBozVFDjPbchkqIrd.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:etAOsfCmglvJWTBozVFDjPbchkqIrd.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   etAOsfCmglvJWTBozVFDjPbchkqIrd.setProperty('IsPlayable','true')
  if ContextMenu:etAOsfCmglvJWTBozVFDjPbchkqIrd.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(etAOsfCmglvJWTBozVFDjPbchkqIrQ._addon_handle,etAOsfCmglvJWTBozVFDjPbchkqIra,etAOsfCmglvJWTBozVFDjPbchkqIrd,isFolder)
 def Set_InfoTag(etAOsfCmglvJWTBozVFDjPbchkqIrQ,video_InfoTag:xbmc.InfoTagVideo,etAOsfCmglvJWTBozVFDjPbchkqIru):
  for etAOsfCmglvJWTBozVFDjPbchkqIrL,value in etAOsfCmglvJWTBozVFDjPbchkqIru.items():
   if etAOsfCmglvJWTBozVFDjPbchkqIri[etAOsfCmglvJWTBozVFDjPbchkqIrL]['type']=='string':
    etAOsfCmglvJWTBozVFDjPbchkqIiR(video_InfoTag,etAOsfCmglvJWTBozVFDjPbchkqIri[etAOsfCmglvJWTBozVFDjPbchkqIrL]['func'])(value)
   elif etAOsfCmglvJWTBozVFDjPbchkqIri[etAOsfCmglvJWTBozVFDjPbchkqIrL]['type']=='int':
    if etAOsfCmglvJWTBozVFDjPbchkqIiH(value)==etAOsfCmglvJWTBozVFDjPbchkqIia:
     etAOsfCmglvJWTBozVFDjPbchkqIrX=etAOsfCmglvJWTBozVFDjPbchkqIia(value)
    else:
     etAOsfCmglvJWTBozVFDjPbchkqIrX=0
    etAOsfCmglvJWTBozVFDjPbchkqIiR(video_InfoTag,etAOsfCmglvJWTBozVFDjPbchkqIri[etAOsfCmglvJWTBozVFDjPbchkqIrL]['func'])(etAOsfCmglvJWTBozVFDjPbchkqIrX)
   elif etAOsfCmglvJWTBozVFDjPbchkqIri[etAOsfCmglvJWTBozVFDjPbchkqIrL]['type']=='actor':
    if value!=[]:
     etAOsfCmglvJWTBozVFDjPbchkqIiR(video_InfoTag,etAOsfCmglvJWTBozVFDjPbchkqIri[etAOsfCmglvJWTBozVFDjPbchkqIrL]['func'])([xbmc.Actor(name)for name in value])
   elif etAOsfCmglvJWTBozVFDjPbchkqIri[etAOsfCmglvJWTBozVFDjPbchkqIrL]['type']=='list':
    if etAOsfCmglvJWTBozVFDjPbchkqIiH(value)==etAOsfCmglvJWTBozVFDjPbchkqIiU:
     etAOsfCmglvJWTBozVFDjPbchkqIiR(video_InfoTag,etAOsfCmglvJWTBozVFDjPbchkqIri[etAOsfCmglvJWTBozVFDjPbchkqIrL]['func'])(value)
    else:
     etAOsfCmglvJWTBozVFDjPbchkqIiR(video_InfoTag,etAOsfCmglvJWTBozVFDjPbchkqIri[etAOsfCmglvJWTBozVFDjPbchkqIrL]['func'])([value])
 def make_M3u_Filename(etAOsfCmglvJWTBozVFDjPbchkqIrQ,tempyn=etAOsfCmglvJWTBozVFDjPbchkqIiK):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_FILE_PATH+etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(etAOsfCmglvJWTBozVFDjPbchkqIrQ,tempyn=etAOsfCmglvJWTBozVFDjPbchkqIiK):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_FILE_PATH+etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_FILE_NAME+'.xml'
 def dp_Main_List(etAOsfCmglvJWTBozVFDjPbchkqIrQ):
  for etAOsfCmglvJWTBozVFDjPbchkqIrG in etAOsfCmglvJWTBozVFDjPbchkqIrx:
   etAOsfCmglvJWTBozVFDjPbchkqIrU=etAOsfCmglvJWTBozVFDjPbchkqIrG.get('title')
   etAOsfCmglvJWTBozVFDjPbchkqIry=''
   etAOsfCmglvJWTBozVFDjPbchkqIrM={'mode':etAOsfCmglvJWTBozVFDjPbchkqIrG.get('mode'),'sType':etAOsfCmglvJWTBozVFDjPbchkqIrG.get('sType'),'sName':etAOsfCmglvJWTBozVFDjPbchkqIrG.get('sName')}
   etAOsfCmglvJWTBozVFDjPbchkqIru={'title':etAOsfCmglvJWTBozVFDjPbchkqIrU,'plot':etAOsfCmglvJWTBozVFDjPbchkqIrU}
   if etAOsfCmglvJWTBozVFDjPbchkqIrG.get('mode')=='XXX':
    etAOsfCmglvJWTBozVFDjPbchkqIYr=etAOsfCmglvJWTBozVFDjPbchkqIiK
    etAOsfCmglvJWTBozVFDjPbchkqIYx =etAOsfCmglvJWTBozVFDjPbchkqIip
   else:
    etAOsfCmglvJWTBozVFDjPbchkqIYr=etAOsfCmglvJWTBozVFDjPbchkqIip
    etAOsfCmglvJWTBozVFDjPbchkqIYx =etAOsfCmglvJWTBozVFDjPbchkqIiK
   etAOsfCmglvJWTBozVFDjPbchkqIYi=etAOsfCmglvJWTBozVFDjPbchkqIip
   if etAOsfCmglvJWTBozVFDjPbchkqIrG.get('mode')=='ADD_M3U':
    if etAOsfCmglvJWTBozVFDjPbchkqIrG.get('sType')=='wavve' and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVE ==etAOsfCmglvJWTBozVFDjPbchkqIiK:etAOsfCmglvJWTBozVFDjPbchkqIYi=etAOsfCmglvJWTBozVFDjPbchkqIiK
    if etAOsfCmglvJWTBozVFDjPbchkqIrG.get('sType')=='tving' and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONTVING ==etAOsfCmglvJWTBozVFDjPbchkqIiK:etAOsfCmglvJWTBozVFDjPbchkqIYi=etAOsfCmglvJWTBozVFDjPbchkqIiK
    if etAOsfCmglvJWTBozVFDjPbchkqIrG.get('sType')=='spotv' and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSPOTV ==etAOsfCmglvJWTBozVFDjPbchkqIiK:etAOsfCmglvJWTBozVFDjPbchkqIYi=etAOsfCmglvJWTBozVFDjPbchkqIiK
    if etAOsfCmglvJWTBozVFDjPbchkqIrG.get('sType')=='bc_sbs' and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_BC_SBS ==etAOsfCmglvJWTBozVFDjPbchkqIiK:etAOsfCmglvJWTBozVFDjPbchkqIYi=etAOsfCmglvJWTBozVFDjPbchkqIiK
    if etAOsfCmglvJWTBozVFDjPbchkqIrG.get('sType')=='samsung' and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSAMSUNG==etAOsfCmglvJWTBozVFDjPbchkqIiK:etAOsfCmglvJWTBozVFDjPbchkqIYi=etAOsfCmglvJWTBozVFDjPbchkqIiK
    if etAOsfCmglvJWTBozVFDjPbchkqIrG.get('sType')=='custom' and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_CUSTOM_LIST==[]:etAOsfCmglvJWTBozVFDjPbchkqIYi=etAOsfCmglvJWTBozVFDjPbchkqIiK
   if etAOsfCmglvJWTBozVFDjPbchkqIYi==etAOsfCmglvJWTBozVFDjPbchkqIip:
    if 'icon' in etAOsfCmglvJWTBozVFDjPbchkqIrG:etAOsfCmglvJWTBozVFDjPbchkqIry=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',etAOsfCmglvJWTBozVFDjPbchkqIrG.get('icon')) 
    etAOsfCmglvJWTBozVFDjPbchkqIrQ.add_dir(etAOsfCmglvJWTBozVFDjPbchkqIrU,sublabel='',img=etAOsfCmglvJWTBozVFDjPbchkqIry,infoLabels=etAOsfCmglvJWTBozVFDjPbchkqIru,isFolder=etAOsfCmglvJWTBozVFDjPbchkqIYr,params=etAOsfCmglvJWTBozVFDjPbchkqIrM,isLink=etAOsfCmglvJWTBozVFDjPbchkqIYx)
  if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIrx)>0:xbmcplugin.endOfDirectory(etAOsfCmglvJWTBozVFDjPbchkqIrQ._addon_handle,cacheToDisc=etAOsfCmglvJWTBozVFDjPbchkqIip)
 def dp_Delete_M3u(etAOsfCmglvJWTBozVFDjPbchkqIrQ,args):
  etAOsfCmglvJWTBozVFDjPbchkqIrE=xbmcgui.Dialog()
  etAOsfCmglvJWTBozVFDjPbchkqIYQ=etAOsfCmglvJWTBozVFDjPbchkqIrE.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if etAOsfCmglvJWTBozVFDjPbchkqIYQ==etAOsfCmglvJWTBozVFDjPbchkqIiK:sys.exit()
  etAOsfCmglvJWTBozVFDjPbchkqIYw=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_M3u_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIiK)
  if xbmcvfs.exists(etAOsfCmglvJWTBozVFDjPbchkqIYw):
   if xbmcvfs.delete(etAOsfCmglvJWTBozVFDjPbchkqIYw)==etAOsfCmglvJWTBozVFDjPbchkqIiK:
    etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti(__language__(30910).encode('utf-8'))
    return
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(etAOsfCmglvJWTBozVFDjPbchkqIrQ,args):
  etAOsfCmglvJWTBozVFDjPbchkqIYn=args.get('sType')
  etAOsfCmglvJWTBozVFDjPbchkqIYS=args.get('sName')
  etAOsfCmglvJWTBozVFDjPbchkqIrE=xbmcgui.Dialog()
  etAOsfCmglvJWTBozVFDjPbchkqIYQ=etAOsfCmglvJWTBozVFDjPbchkqIrE.yesno((etAOsfCmglvJWTBozVFDjPbchkqIYS+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if etAOsfCmglvJWTBozVFDjPbchkqIYQ==etAOsfCmglvJWTBozVFDjPbchkqIiK:sys.exit()
  etAOsfCmglvJWTBozVFDjPbchkqIYK =[]
  etAOsfCmglvJWTBozVFDjPbchkqIYE =[]
  etAOsfCmglvJWTBozVFDjPbchkqIYw=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_M3u_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIip)
  if os.path.isfile(etAOsfCmglvJWTBozVFDjPbchkqIYw):os.remove(etAOsfCmglvJWTBozVFDjPbchkqIYw)
  if etAOsfCmglvJWTBozVFDjPbchkqIYn=='all':
   etAOsfCmglvJWTBozVFDjPbchkqIYw=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_M3u_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIiK)
   if xbmcvfs.exists(etAOsfCmglvJWTBozVFDjPbchkqIYw):
    if xbmcvfs.delete(etAOsfCmglvJWTBozVFDjPbchkqIYw)==etAOsfCmglvJWTBozVFDjPbchkqIiK:
     etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   etAOsfCmglvJWTBozVFDjPbchkqIYp=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_M3u_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIiK)
   if xbmcvfs.exists(etAOsfCmglvJWTBozVFDjPbchkqIYp):
    etAOsfCmglvJWTBozVFDjPbchkqIYR=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_M3u_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIip)
    xbmcvfs.copy(etAOsfCmglvJWTBozVFDjPbchkqIYp,etAOsfCmglvJWTBozVFDjPbchkqIYR)
  if(etAOsfCmglvJWTBozVFDjPbchkqIYn=='wavve' or etAOsfCmglvJWTBozVFDjPbchkqIYn=='all')and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVE:
   etAOsfCmglvJWTBozVFDjPbchkqIYH=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_ChannelList_Wavve(exceptGroup=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_EexceptGroup_Wavve())
   if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYH)!=0:etAOsfCmglvJWTBozVFDjPbchkqIYK.extend(etAOsfCmglvJWTBozVFDjPbchkqIYH)
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_log('wavve cnt ----> '+etAOsfCmglvJWTBozVFDjPbchkqIiL(etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYH)))
  if(etAOsfCmglvJWTBozVFDjPbchkqIYn=='tving' or etAOsfCmglvJWTBozVFDjPbchkqIYn=='all')and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONTVING:
   etAOsfCmglvJWTBozVFDjPbchkqIYH=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_ChannelList_Tving()
   if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYH)!=0:etAOsfCmglvJWTBozVFDjPbchkqIYK.extend(etAOsfCmglvJWTBozVFDjPbchkqIYH)
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_log('tving cnt ----> '+etAOsfCmglvJWTBozVFDjPbchkqIiL(etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYH)))
  if(etAOsfCmglvJWTBozVFDjPbchkqIYn=='spotv' or etAOsfCmglvJWTBozVFDjPbchkqIYn=='all')and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSPOTV:
   etAOsfCmglvJWTBozVFDjPbchkqIYH=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_ChannelList_Spotv(payyn=etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSPOTVPAY)
   if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYH)!=0:etAOsfCmglvJWTBozVFDjPbchkqIYK.extend(etAOsfCmglvJWTBozVFDjPbchkqIYH)
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_log('spotv cnt ----> '+etAOsfCmglvJWTBozVFDjPbchkqIiL(etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYH)))
  if(etAOsfCmglvJWTBozVFDjPbchkqIYn=='samsung' or etAOsfCmglvJWTBozVFDjPbchkqIYn=='all')and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSAMSUNG:
   etAOsfCmglvJWTBozVFDjPbchkqIYa=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_BaseInfo_Samsungtv()
   etAOsfCmglvJWTBozVFDjPbchkqIYH=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_ChannelList_Samsungtv(etAOsfCmglvJWTBozVFDjPbchkqIYa,exceptGroup=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_EexceptGroup_Samsungtv())
   if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYH)!=0:etAOsfCmglvJWTBozVFDjPbchkqIYK.extend(etAOsfCmglvJWTBozVFDjPbchkqIYH)
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_log('samsungtv cnt ----> '+etAOsfCmglvJWTBozVFDjPbchkqIiL(etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYH)))
  if(etAOsfCmglvJWTBozVFDjPbchkqIYn=='bc_sbs' or etAOsfCmglvJWTBozVFDjPbchkqIYn=='all')and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_BC_SBS:
   etAOsfCmglvJWTBozVFDjPbchkqIYH=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_ChannelList_BroadCast_SBS()
   if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYH)!=0:etAOsfCmglvJWTBozVFDjPbchkqIYK.extend(etAOsfCmglvJWTBozVFDjPbchkqIYH)
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_log('bc_sbs cnt ----> '+etAOsfCmglvJWTBozVFDjPbchkqIiL(etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYH)))
  if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYK)==0 and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_CUSTOM_LIST==[]:
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti(__language__(30909).encode('utf8'))
   return
  for etAOsfCmglvJWTBozVFDjPbchkqIYU in etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.INIT_GENRESORT:
   for etAOsfCmglvJWTBozVFDjPbchkqIYd in etAOsfCmglvJWTBozVFDjPbchkqIYK:
    if etAOsfCmglvJWTBozVFDjPbchkqIYd['genrenm']==etAOsfCmglvJWTBozVFDjPbchkqIYU:
     etAOsfCmglvJWTBozVFDjPbchkqIYE.append(etAOsfCmglvJWTBozVFDjPbchkqIYd)
  for etAOsfCmglvJWTBozVFDjPbchkqIYd in etAOsfCmglvJWTBozVFDjPbchkqIYK:
   if etAOsfCmglvJWTBozVFDjPbchkqIYd['genrenm']not in etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.INIT_GENRESORT:
    etAOsfCmglvJWTBozVFDjPbchkqIYE.append(etAOsfCmglvJWTBozVFDjPbchkqIYd)
  try:
   if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIYK)>0:
    etAOsfCmglvJWTBozVFDjPbchkqIYw=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_M3u_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIip)
    if os.path.isfile(etAOsfCmglvJWTBozVFDjPbchkqIYw):
     fp=etAOsfCmglvJWTBozVFDjPbchkqIiX(etAOsfCmglvJWTBozVFDjPbchkqIYw,'a',-1,'utf-8')
    else:
     fp=etAOsfCmglvJWTBozVFDjPbchkqIiX(etAOsfCmglvJWTBozVFDjPbchkqIYw,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for etAOsfCmglvJWTBozVFDjPbchkqIYL in etAOsfCmglvJWTBozVFDjPbchkqIYE:
     etAOsfCmglvJWTBozVFDjPbchkqIYX =etAOsfCmglvJWTBozVFDjPbchkqIYL['channelid']
     etAOsfCmglvJWTBozVFDjPbchkqIYG =etAOsfCmglvJWTBozVFDjPbchkqIYL['channelnm']
     etAOsfCmglvJWTBozVFDjPbchkqIYy=etAOsfCmglvJWTBozVFDjPbchkqIYL['channelimg']
     etAOsfCmglvJWTBozVFDjPbchkqIYM =etAOsfCmglvJWTBozVFDjPbchkqIYL['ott']
     etAOsfCmglvJWTBozVFDjPbchkqIYu ='%s.%s'%(etAOsfCmglvJWTBozVFDjPbchkqIYX,etAOsfCmglvJWTBozVFDjPbchkqIYM)
     etAOsfCmglvJWTBozVFDjPbchkqIxr=etAOsfCmglvJWTBozVFDjPbchkqIYL['genrenm']
     if etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_DISPLAYNM:
      etAOsfCmglvJWTBozVFDjPbchkqIYG='%s (%s)'%(etAOsfCmglvJWTBozVFDjPbchkqIYG,etAOsfCmglvJWTBozVFDjPbchkqIYM)
     if etAOsfCmglvJWTBozVFDjPbchkqIxr=='라디오/음악':
      etAOsfCmglvJWTBozVFDjPbchkqIxY='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(etAOsfCmglvJWTBozVFDjPbchkqIYu,etAOsfCmglvJWTBozVFDjPbchkqIYG,etAOsfCmglvJWTBozVFDjPbchkqIxr,etAOsfCmglvJWTBozVFDjPbchkqIYy,etAOsfCmglvJWTBozVFDjPbchkqIYG)
     else:
      etAOsfCmglvJWTBozVFDjPbchkqIxY='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(etAOsfCmglvJWTBozVFDjPbchkqIYu,etAOsfCmglvJWTBozVFDjPbchkqIYG,etAOsfCmglvJWTBozVFDjPbchkqIxr,etAOsfCmglvJWTBozVFDjPbchkqIYy,etAOsfCmglvJWTBozVFDjPbchkqIYG)
     if etAOsfCmglvJWTBozVFDjPbchkqIYM=='wavve':
      etAOsfCmglvJWTBozVFDjPbchkqIxi ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(etAOsfCmglvJWTBozVFDjPbchkqIYX)
     elif etAOsfCmglvJWTBozVFDjPbchkqIYM=='tving':
      etAOsfCmglvJWTBozVFDjPbchkqIxi ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(etAOsfCmglvJWTBozVFDjPbchkqIYX)
     elif etAOsfCmglvJWTBozVFDjPbchkqIYM=='spotv':
      etAOsfCmglvJWTBozVFDjPbchkqIxi ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(etAOsfCmglvJWTBozVFDjPbchkqIYX)
     elif etAOsfCmglvJWTBozVFDjPbchkqIYM=='samsung':
      etAOsfCmglvJWTBozVFDjPbchkqIxi ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(etAOsfCmglvJWTBozVFDjPbchkqIYX)
     elif etAOsfCmglvJWTBozVFDjPbchkqIYM=='bc_sbs':
      etAOsfCmglvJWTBozVFDjPbchkqIxi ='plugin://plugin.video.broadcastm/?mode=LIVE&company=sbs&channlCode=%s\n'%(etAOsfCmglvJWTBozVFDjPbchkqIYX)
     fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxY)
     fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxi)
    fp.close()
  except:
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti(__language__(30910).encode('utf8'))
   return
  try:
   if(etAOsfCmglvJWTBozVFDjPbchkqIYn=='custom' or etAOsfCmglvJWTBozVFDjPbchkqIYn=='all')and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_CUSTOM_LIST!=[]:
    etAOsfCmglvJWTBozVFDjPbchkqIYw=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_M3u_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIip)
    if os.path.isfile(etAOsfCmglvJWTBozVFDjPbchkqIYw):
     fp=etAOsfCmglvJWTBozVFDjPbchkqIiX(etAOsfCmglvJWTBozVFDjPbchkqIYw,'a',-1,'utf-8')
    else:
     fp=etAOsfCmglvJWTBozVFDjPbchkqIiX(etAOsfCmglvJWTBozVFDjPbchkqIYw,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for etAOsfCmglvJWTBozVFDjPbchkqIxN in etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_CUSTOM_LIST:
     etAOsfCmglvJWTBozVFDjPbchkqIxQ=etAOsfCmglvJWTBozVFDjPbchkqIrQ.customEpg_FileRead(etAOsfCmglvJWTBozVFDjPbchkqIxN)
     for etAOsfCmglvJWTBozVFDjPbchkqIxw in etAOsfCmglvJWTBozVFDjPbchkqIxQ:
      etAOsfCmglvJWTBozVFDjPbchkqIxw=etAOsfCmglvJWTBozVFDjPbchkqIxw.strip()
      if etAOsfCmglvJWTBozVFDjPbchkqIxw not in['','#EXTM3U']:
       fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxw+'\n')
   fp.close()
  except:
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti(__language__(30910).encode('utf8'))
   return
  etAOsfCmglvJWTBozVFDjPbchkqIYp=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_M3u_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIip)
  etAOsfCmglvJWTBozVFDjPbchkqIYR=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_M3u_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIiK)
  if xbmcvfs.copy(etAOsfCmglvJWTBozVFDjPbchkqIYp,etAOsfCmglvJWTBozVFDjPbchkqIYR):
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti((etAOsfCmglvJWTBozVFDjPbchkqIYS+' '+__language__(30908)).encode('utf8'))
  else:
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti(__language__(30910).encode('utf-8'))
 def customEpg_FileList(etAOsfCmglvJWTBozVFDjPbchkqIrQ):
  etAOsfCmglvJWTBozVFDjPbchkqIxn=[]
  if __addon__.getSetting('custom01on')=='true':etAOsfCmglvJWTBozVFDjPbchkqIxn.append(__addon__.getSetting('custom01nm'))
  if __addon__.getSetting('custom02on')=='true':etAOsfCmglvJWTBozVFDjPbchkqIxn.append(__addon__.getSetting('custom02nm'))
  if __addon__.getSetting('custom03on')=='true':etAOsfCmglvJWTBozVFDjPbchkqIxn.append(__addon__.getSetting('custom03nm'))
  if __addon__.getSetting('custom04on')=='true':etAOsfCmglvJWTBozVFDjPbchkqIxn.append(__addon__.getSetting('custom04nm'))
  if __addon__.getSetting('custom05on')=='true':etAOsfCmglvJWTBozVFDjPbchkqIxn.append(__addon__.getSetting('custom05nm'))
  return etAOsfCmglvJWTBozVFDjPbchkqIxn
 def customEpg_FileRead(etAOsfCmglvJWTBozVFDjPbchkqIrQ,source_filename):
  try:
   etAOsfCmglvJWTBozVFDjPbchkqIxS=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
   if os.path.isfile(etAOsfCmglvJWTBozVFDjPbchkqIxS):os.remove(etAOsfCmglvJWTBozVFDjPbchkqIxS)
   xbmcvfs.copy(source_filename,etAOsfCmglvJWTBozVFDjPbchkqIxS)
   fp=etAOsfCmglvJWTBozVFDjPbchkqIiX(etAOsfCmglvJWTBozVFDjPbchkqIxS,'r',-1,'utf-8')
   etAOsfCmglvJWTBozVFDjPbchkqIxK=fp.readlines()
  except:
   return[]
  return etAOsfCmglvJWTBozVFDjPbchkqIxK
 def dp_Make_Epg(etAOsfCmglvJWTBozVFDjPbchkqIrQ,args):
  etAOsfCmglvJWTBozVFDjPbchkqIYn=args.get('sType')
  etAOsfCmglvJWTBozVFDjPbchkqIYS=args.get('sName')
  etAOsfCmglvJWTBozVFDjPbchkqIxE=args.get('sNoti')
  if etAOsfCmglvJWTBozVFDjPbchkqIxE!='N':
   etAOsfCmglvJWTBozVFDjPbchkqIrE=xbmcgui.Dialog()
   etAOsfCmglvJWTBozVFDjPbchkqIYQ=etAOsfCmglvJWTBozVFDjPbchkqIrE.yesno((etAOsfCmglvJWTBozVFDjPbchkqIYS+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if etAOsfCmglvJWTBozVFDjPbchkqIYQ==etAOsfCmglvJWTBozVFDjPbchkqIiK:sys.exit()
  etAOsfCmglvJWTBozVFDjPbchkqIxp=[]
  etAOsfCmglvJWTBozVFDjPbchkqIxR=[]
  if(etAOsfCmglvJWTBozVFDjPbchkqIYn=='wavve' or etAOsfCmglvJWTBozVFDjPbchkqIYn=='all')and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVE:
   etAOsfCmglvJWTBozVFDjPbchkqIxH,etAOsfCmglvJWTBozVFDjPbchkqIxa=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_EexceptGroup_Wavve())
   if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIxa)!=0:
    etAOsfCmglvJWTBozVFDjPbchkqIxp.extend(etAOsfCmglvJWTBozVFDjPbchkqIxH)
    etAOsfCmglvJWTBozVFDjPbchkqIxR.extend(etAOsfCmglvJWTBozVFDjPbchkqIxa)
  if(etAOsfCmglvJWTBozVFDjPbchkqIYn=='tving' or etAOsfCmglvJWTBozVFDjPbchkqIYn=='all')and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONTVING:
   etAOsfCmglvJWTBozVFDjPbchkqIxH,etAOsfCmglvJWTBozVFDjPbchkqIxa=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_EpgInfo_Tving()
   if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIxa)!=0:
    etAOsfCmglvJWTBozVFDjPbchkqIxp.extend(etAOsfCmglvJWTBozVFDjPbchkqIxH)
    etAOsfCmglvJWTBozVFDjPbchkqIxR.extend(etAOsfCmglvJWTBozVFDjPbchkqIxa)
  if(etAOsfCmglvJWTBozVFDjPbchkqIYn=='spotv' or etAOsfCmglvJWTBozVFDjPbchkqIYn=='all')and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSPOTV:
   etAOsfCmglvJWTBozVFDjPbchkqIxH,etAOsfCmglvJWTBozVFDjPbchkqIxa=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_EpgInfo_Spotv(payyn=etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSPOTVPAY)
   if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIxa)!=0:
    etAOsfCmglvJWTBozVFDjPbchkqIxp.extend(etAOsfCmglvJWTBozVFDjPbchkqIxH)
    etAOsfCmglvJWTBozVFDjPbchkqIxR.extend(etAOsfCmglvJWTBozVFDjPbchkqIxa)
  if(etAOsfCmglvJWTBozVFDjPbchkqIYn=='samsung' or etAOsfCmglvJWTBozVFDjPbchkqIYn=='all')and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSAMSUNG:
   etAOsfCmglvJWTBozVFDjPbchkqIYa=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_BaseInfo_Samsungtv()
   etAOsfCmglvJWTBozVFDjPbchkqIxH,etAOsfCmglvJWTBozVFDjPbchkqIxa=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_EpgInfo_Samsungtv(etAOsfCmglvJWTBozVFDjPbchkqIYa,exceptGroup=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_EexceptGroup_Samsungtv())
   if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIxa)!=0:
    etAOsfCmglvJWTBozVFDjPbchkqIxp.extend(etAOsfCmglvJWTBozVFDjPbchkqIxH)
    etAOsfCmglvJWTBozVFDjPbchkqIxR.extend(etAOsfCmglvJWTBozVFDjPbchkqIxa)
  if(etAOsfCmglvJWTBozVFDjPbchkqIYn=='bc_sbs' or etAOsfCmglvJWTBozVFDjPbchkqIYn=='all')and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_BC_SBS:
   etAOsfCmglvJWTBozVFDjPbchkqIxH,etAOsfCmglvJWTBozVFDjPbchkqIxa=etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_EpgInfo_BroadCast_SBS()
   if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIxa)!=0:
    etAOsfCmglvJWTBozVFDjPbchkqIxp.extend(etAOsfCmglvJWTBozVFDjPbchkqIxH)
    etAOsfCmglvJWTBozVFDjPbchkqIxR.extend(etAOsfCmglvJWTBozVFDjPbchkqIxa)
  if etAOsfCmglvJWTBozVFDjPbchkqIid(etAOsfCmglvJWTBozVFDjPbchkqIxR)==0:
   if etAOsfCmglvJWTBozVFDjPbchkqIxE!='N':etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   etAOsfCmglvJWTBozVFDjPbchkqIYw=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_Epg_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIip)
   fp=etAOsfCmglvJWTBozVFDjPbchkqIiX(etAOsfCmglvJWTBozVFDjPbchkqIYw,'w',-1,'utf-8')
   etAOsfCmglvJWTBozVFDjPbchkqIxU='<?xml version="1.0" encoding="UTF-8"?>\n'
   etAOsfCmglvJWTBozVFDjPbchkqIxd='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   etAOsfCmglvJWTBozVFDjPbchkqIxL='<tv generator-info-name="boritv_epg">\n\n'
   etAOsfCmglvJWTBozVFDjPbchkqIxX='\n</tv>\n'
   fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxU)
   fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxd)
   fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxL)
   for etAOsfCmglvJWTBozVFDjPbchkqIxG in etAOsfCmglvJWTBozVFDjPbchkqIxp:
    etAOsfCmglvJWTBozVFDjPbchkqIxy='  <channel id="%s.%s">\n' %(etAOsfCmglvJWTBozVFDjPbchkqIxG.get('channelid'),etAOsfCmglvJWTBozVFDjPbchkqIxG.get('ott'))
    etAOsfCmglvJWTBozVFDjPbchkqIxM='    <display-name>%s</display-name>\n'%(etAOsfCmglvJWTBozVFDjPbchkqIxG.get('channelnm'))
    etAOsfCmglvJWTBozVFDjPbchkqIxu='    <icon src="%s" />\n' %(etAOsfCmglvJWTBozVFDjPbchkqIxG.get('channelimg'))
    etAOsfCmglvJWTBozVFDjPbchkqIir='  </channel>\n\n'
    fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxy)
    fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxM)
    fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxu)
    fp.write(etAOsfCmglvJWTBozVFDjPbchkqIir)
   for etAOsfCmglvJWTBozVFDjPbchkqIxG in etAOsfCmglvJWTBozVFDjPbchkqIxR:
    etAOsfCmglvJWTBozVFDjPbchkqIxy='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(etAOsfCmglvJWTBozVFDjPbchkqIxG.get('startTime'),etAOsfCmglvJWTBozVFDjPbchkqIxG.get('endTime'),etAOsfCmglvJWTBozVFDjPbchkqIxG.get('channelid'),etAOsfCmglvJWTBozVFDjPbchkqIxG.get('ott'))
    etAOsfCmglvJWTBozVFDjPbchkqIxM='    <title lang="kr">%s</title>\n' %(etAOsfCmglvJWTBozVFDjPbchkqIxG.get('title'))
    etAOsfCmglvJWTBozVFDjPbchkqIxu='  </programme>\n\n'
    fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxy)
    fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxM)
    fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxu)
   fp.write(etAOsfCmglvJWTBozVFDjPbchkqIxX)
   fp.close()
  except:
   if etAOsfCmglvJWTBozVFDjPbchkqIxE!='N':etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti(__language__(30910).encode('utf8'))
   return
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.MakeEpg_SaveJson()
  etAOsfCmglvJWTBozVFDjPbchkqIYp=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_Epg_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIip)
  etAOsfCmglvJWTBozVFDjPbchkqIYR=etAOsfCmglvJWTBozVFDjPbchkqIrQ.make_Epg_Filename(tempyn=etAOsfCmglvJWTBozVFDjPbchkqIiK)
  if xbmcvfs.copy(etAOsfCmglvJWTBozVFDjPbchkqIYp,etAOsfCmglvJWTBozVFDjPbchkqIYR):
   if etAOsfCmglvJWTBozVFDjPbchkqIxE!='N':etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti((etAOsfCmglvJWTBozVFDjPbchkqIYS+' '+__language__(30912)).encode('utf8'))
  else:
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_AUTORESTART:
    etAOsfCmglvJWTBozVFDjPbchkqIiY=xbmcaddon.Addon('pvr.iptvsimple')
    etAOsfCmglvJWTBozVFDjPbchkqIiY.setSetting('anything','anything')
  except:
   etAOsfCmglvJWTBozVFDjPbchkqIiE 
 def make_EexceptGroup_Wavve(etAOsfCmglvJWTBozVFDjPbchkqIrQ):
  etAOsfCmglvJWTBozVFDjPbchkqIix=[]
  if etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVERADIO==etAOsfCmglvJWTBozVFDjPbchkqIiK:
   etAOsfCmglvJWTBozVFDjPbchkqIix.append('라디오/음악')
  if etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVEHOME==etAOsfCmglvJWTBozVFDjPbchkqIiK:
   etAOsfCmglvJWTBozVFDjPbchkqIix.append('홈쇼핑')
  if etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONRELIGION==etAOsfCmglvJWTBozVFDjPbchkqIiK:
   etAOsfCmglvJWTBozVFDjPbchkqIix.append('종교')
  return etAOsfCmglvJWTBozVFDjPbchkqIix
 def make_EexceptGroup_Samsungtv(etAOsfCmglvJWTBozVFDjPbchkqIrQ):
  etAOsfCmglvJWTBozVFDjPbchkqIix=[]
  if etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSAMSUNGHOME==etAOsfCmglvJWTBozVFDjPbchkqIiK:
   etAOsfCmglvJWTBozVFDjPbchkqIix.append('홈쇼핑')
  return etAOsfCmglvJWTBozVFDjPbchkqIix
 def get_radio_list(etAOsfCmglvJWTBozVFDjPbchkqIrQ):
  if etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVERADIO==etAOsfCmglvJWTBozVFDjPbchkqIiK:return[]
  etAOsfCmglvJWTBozVFDjPbchkqIiN=[{'broadcastid':'46584','genre':'10'}]
  return etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_ChannelList_WavveExcept(etAOsfCmglvJWTBozVFDjPbchkqIiN)
 def check_config(etAOsfCmglvJWTBozVFDjPbchkqIrQ):
  etAOsfCmglvJWTBozVFDjPbchkqIiQ=etAOsfCmglvJWTBozVFDjPbchkqIip
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVE =etAOsfCmglvJWTBozVFDjPbchkqIip if __addon__.getSetting('onWavve')=='true' else etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONTVING =etAOsfCmglvJWTBozVFDjPbchkqIip if __addon__.getSetting('onTvng')=='true' else etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSPOTV =etAOsfCmglvJWTBozVFDjPbchkqIip if __addon__.getSetting('onSpotv')=='true' else etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_BC_SBS =etAOsfCmglvJWTBozVFDjPbchkqIip if __addon__.getSetting('onBroadSBS')=='true' else etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSAMSUNG =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVERADIO =etAOsfCmglvJWTBozVFDjPbchkqIip if __addon__.getSetting('onWavveRadio')=='true' else etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVEHOME =etAOsfCmglvJWTBozVFDjPbchkqIip if __addon__.getSetting('onWavveHome')=='true' else etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONRELIGION =etAOsfCmglvJWTBozVFDjPbchkqIip if __addon__.getSetting('onWavveReligion')=='true' else etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSPOTVPAY =etAOsfCmglvJWTBozVFDjPbchkqIip if __addon__.getSetting('onSpotvPay')=='true' else etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSAMSUNGHOME =etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_DISPLAYNM =etAOsfCmglvJWTBozVFDjPbchkqIip if __addon__.getSetting('displayOTTnm')=='true' else etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_AUTORESTART =etAOsfCmglvJWTBozVFDjPbchkqIip if __addon__.getSetting('autoRestart')=='true' else etAOsfCmglvJWTBozVFDjPbchkqIiK
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_CUSTOM_LIST =etAOsfCmglvJWTBozVFDjPbchkqIrQ.customEpg_FileList()
  if etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_FILE_PATH=='' or etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_FILE_NAME=='':etAOsfCmglvJWTBozVFDjPbchkqIiQ=etAOsfCmglvJWTBozVFDjPbchkqIiK
  if etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONWAVVE==etAOsfCmglvJWTBozVFDjPbchkqIiK and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONTVING==etAOsfCmglvJWTBozVFDjPbchkqIiK and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSPOTV==etAOsfCmglvJWTBozVFDjPbchkqIiK and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_ONSAMSUNG==etAOsfCmglvJWTBozVFDjPbchkqIiK and etAOsfCmglvJWTBozVFDjPbchkqIrQ.M3U_BC_SBS==etAOsfCmglvJWTBozVFDjPbchkqIiK:etAOsfCmglvJWTBozVFDjPbchkqIiQ=etAOsfCmglvJWTBozVFDjPbchkqIiK
  if etAOsfCmglvJWTBozVFDjPbchkqIiQ==etAOsfCmglvJWTBozVFDjPbchkqIiK:
   etAOsfCmglvJWTBozVFDjPbchkqIrE=xbmcgui.Dialog()
   etAOsfCmglvJWTBozVFDjPbchkqIYQ=etAOsfCmglvJWTBozVFDjPbchkqIrE.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if etAOsfCmglvJWTBozVFDjPbchkqIYQ==etAOsfCmglvJWTBozVFDjPbchkqIip:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(etAOsfCmglvJWTBozVFDjPbchkqIrQ):
  etAOsfCmglvJWTBozVFDjPbchkqIiw={'date_makeepg':etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=etAOsfCmglvJWTBozVFDjPbchkqIiX(etAOsfCmglvJWTBozVFDjPbchkqIrN,'w',-1,'utf-8')
   json.dump(etAOsfCmglvJWTBozVFDjPbchkqIiw,fp)
   fp.close()
  except etAOsfCmglvJWTBozVFDjPbchkqIiG as exception:
   return
 def boritv_main(etAOsfCmglvJWTBozVFDjPbchkqIrQ):
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.BoritvObj.KodiVersion=etAOsfCmglvJWTBozVFDjPbchkqIia(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  etAOsfCmglvJWTBozVFDjPbchkqIin=etAOsfCmglvJWTBozVFDjPbchkqIrQ.main_params.get('mode',etAOsfCmglvJWTBozVFDjPbchkqIiE)
  etAOsfCmglvJWTBozVFDjPbchkqIrQ.check_config()
  if etAOsfCmglvJWTBozVFDjPbchkqIin is etAOsfCmglvJWTBozVFDjPbchkqIiE:
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.dp_Main_List()
  elif etAOsfCmglvJWTBozVFDjPbchkqIin=='DEL_M3U':
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.dp_Delete_M3u(etAOsfCmglvJWTBozVFDjPbchkqIrQ.main_params)
  elif etAOsfCmglvJWTBozVFDjPbchkqIin=='ADD_M3U':
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.dp_MakeAdd_M3u(etAOsfCmglvJWTBozVFDjPbchkqIrQ.main_params)
  elif etAOsfCmglvJWTBozVFDjPbchkqIin=='ADD_EPG':
   etAOsfCmglvJWTBozVFDjPbchkqIrQ.dp_Make_Epg(etAOsfCmglvJWTBozVFDjPbchkqIrQ.main_params)
  else:
   etAOsfCmglvJWTBozVFDjPbchkqIiE
# Created by pyminifier (https://github.com/liftoff/pyminifier)
