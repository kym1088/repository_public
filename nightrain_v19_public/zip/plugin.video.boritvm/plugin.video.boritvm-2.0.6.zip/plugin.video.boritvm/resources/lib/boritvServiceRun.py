__author__="NightRain"
DQtlgLyvYbIJXTarRzhqnHdGjEFmsc=str
DQtlgLyvYbIJXTarRzhqnHdGjEFmse=True
DQtlgLyvYbIJXTarRzhqnHdGjEFmsi=False
DQtlgLyvYbIJXTarRzhqnHdGjEFmsB=print
DQtlgLyvYbIJXTarRzhqnHdGjEFmsW=open
DQtlgLyvYbIJXTarRzhqnHdGjEFmsK=Exception
DQtlgLyvYbIJXTarRzhqnHdGjEFmCs=int
import json
import time
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 DQtlgLyvYbIJXTarRzhqnHdGjEFmsN='ADDON'
except:
 DQtlgLyvYbIJXTarRzhqnHdGjEFmsN='SINGLE'
if DQtlgLyvYbIJXTarRzhqnHdGjEFmsN=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsf=DQtlgLyvYbIJXTarRzhqnHdGjEFmsc(string).encode('utf-8','ignore')
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsw=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,DQtlgLyvYbIJXTarRzhqnHdGjEFmsf),level=DQtlgLyvYbIJXTarRzhqnHdGjEFmsw)
 def addon_getautoepg():
  return DQtlgLyvYbIJXTarRzhqnHdGjEFmse if __addon__.getSetting('autoEpg')=='true' else DQtlgLyvYbIJXTarRzhqnHdGjEFmsi
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsB(string)
 def addon_getautoepg():
  return DQtlgLyvYbIJXTarRzhqnHdGjEFmse
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class DQtlgLyvYbIJXTarRzhqnHdGjEFmsC():
 def __init__(DQtlgLyvYbIJXTarRzhqnHdGjEFmsU):
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.START_INTERVAL =10 
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.INTERVAL =10 
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_FILETAGNM ='date_makeepg'
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_MAKEDATE ='-' 
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_WILL_TM =-1 
 def Get_Now_Datetime(DQtlgLyvYbIJXTarRzhqnHdGjEFmsU):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(DQtlgLyvYbIJXTarRzhqnHdGjEFmsU):
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsO ='-'
  if DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_MAKEDATE=='-':
   try:
    fp=DQtlgLyvYbIJXTarRzhqnHdGjEFmsW(addon_epgupdate_confignm(),'r',-1,'utf-8')
    DQtlgLyvYbIJXTarRzhqnHdGjEFmsS= json.load(fp)
    fp.close()
    DQtlgLyvYbIJXTarRzhqnHdGjEFmsO=DQtlgLyvYbIJXTarRzhqnHdGjEFmsS[DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_FILETAGNM]
   except DQtlgLyvYbIJXTarRzhqnHdGjEFmsK as exception:
    return 3 
  else:
   DQtlgLyvYbIJXTarRzhqnHdGjEFmsO=DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_MAKEDATE
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsx =DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.Get_Now_Datetime()
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsp=(DQtlgLyvYbIJXTarRzhqnHdGjEFmsx-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsu =DQtlgLyvYbIJXTarRzhqnHdGjEFmsx.strftime('%Y-%m-%d')
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsV =DQtlgLyvYbIJXTarRzhqnHdGjEFmsx.strftime('%H')
  if DQtlgLyvYbIJXTarRzhqnHdGjEFmsO==DQtlgLyvYbIJXTarRzhqnHdGjEFmsu: return-1
  if DQtlgLyvYbIJXTarRzhqnHdGjEFmsO==DQtlgLyvYbIJXTarRzhqnHdGjEFmsp and DQtlgLyvYbIJXTarRzhqnHdGjEFmsV=='00':return 30
  return 3
 def MakeEpg_RandomTm(DQtlgLyvYbIJXTarRzhqnHdGjEFmsU,mintm):
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsP=(mintm*60)+random.randint(0,60)
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsx =DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.Get_Now_Datetime()
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsM =(DQtlgLyvYbIJXTarRzhqnHdGjEFmsx+datetime.timedelta(seconds=DQtlgLyvYbIJXTarRzhqnHdGjEFmsP)).strftime('%Y%m%d%H%M%S')
  return DQtlgLyvYbIJXTarRzhqnHdGjEFmCs(DQtlgLyvYbIJXTarRzhqnHdGjEFmsM)
 def MakeEpg_SaveJson(DQtlgLyvYbIJXTarRzhqnHdGjEFmsU):
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsS={DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_FILETAGNM:DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=DQtlgLyvYbIJXTarRzhqnHdGjEFmsW(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(DQtlgLyvYbIJXTarRzhqnHdGjEFmsS,fp)
   fp.close()
  except DQtlgLyvYbIJXTarRzhqnHdGjEFmsK as exception:
   return
 def service_run(DQtlgLyvYbIJXTarRzhqnHdGjEFmsU):
  if addon_getautoepg()==DQtlgLyvYbIJXTarRzhqnHdGjEFmsi:return
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsA=DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.MakeEpg_DateCheck()
  if DQtlgLyvYbIJXTarRzhqnHdGjEFmsA<0:
   return
  if DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_WILL_TM<0:
   DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_WILL_TM=DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.MakeEpg_RandomTm(DQtlgLyvYbIJXTarRzhqnHdGjEFmsA)
   addon_log('EPG_WILL_TM --> '+DQtlgLyvYbIJXTarRzhqnHdGjEFmsc(DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_WILL_TM))
  else:
   DQtlgLyvYbIJXTarRzhqnHdGjEFmsu=DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.Get_Now_Datetime()
   if DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_WILL_TM<DQtlgLyvYbIJXTarRzhqnHdGjEFmCs(DQtlgLyvYbIJXTarRzhqnHdGjEFmsu.strftime('%Y%m%d%H%M%S')):
    addon_log('make epg')
    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
    DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.MakeEpg_SaveJson()
    DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_MAKEDATE=DQtlgLyvYbIJXTarRzhqnHdGjEFmsu.strftime('%Y-%m-%d')
    DQtlgLyvYbIJXTarRzhqnHdGjEFmsU.EPG_WILL_TM =-1
   else:
    pass
  pass
if __name__=="__main__":
 addon_log('__main__')
 DQtlgLyvYbIJXTarRzhqnHdGjEFmsk=DQtlgLyvYbIJXTarRzhqnHdGjEFmsC()
 time.sleep(DQtlgLyvYbIJXTarRzhqnHdGjEFmsk.START_INTERVAL)
 while DQtlgLyvYbIJXTarRzhqnHdGjEFmse:
  time.sleep(DQtlgLyvYbIJXTarRzhqnHdGjEFmsk.INTERVAL)
  DQtlgLyvYbIJXTarRzhqnHdGjEFmsk.service_run()
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
