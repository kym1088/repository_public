__author__="NightRain"
FODvIUaCWRPEjoeiHVwTpqMBGdAbgl=str
FODvIUaCWRPEjoeiHVwTpqMBGdAbgk=True
FODvIUaCWRPEjoeiHVwTpqMBGdAbgc=False
FODvIUaCWRPEjoeiHVwTpqMBGdAbgs=print
FODvIUaCWRPEjoeiHVwTpqMBGdAbgr=open
FODvIUaCWRPEjoeiHVwTpqMBGdAbgK=Exception
FODvIUaCWRPEjoeiHVwTpqMBGdAbLg=int
import json
import time
import datetime
import random
import os
try:
 import xbmc,xbmcaddon,xbmcvfs
 FODvIUaCWRPEjoeiHVwTpqMBGdAbgt='ADDON'
except:
 FODvIUaCWRPEjoeiHVwTpqMBGdAbgt='SINGLE'
if FODvIUaCWRPEjoeiHVwTpqMBGdAbgt=='ADDON':
 __addon__ =xbmcaddon.Addon()
 __version__ =__addon__.getAddonInfo('version')
 __addonid__ =__addon__.getAddonInfo('id')
 __profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
 def addon_log(string):
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgX=FODvIUaCWRPEjoeiHVwTpqMBGdAbgl(string).encode('utf-8','ignore')
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgn=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,FODvIUaCWRPEjoeiHVwTpqMBGdAbgX),level=FODvIUaCWRPEjoeiHVwTpqMBGdAbgn)
 def addon_getautoepg():
  return FODvIUaCWRPEjoeiHVwTpqMBGdAbgk if __addon__.getSetting('autoEpg')=='true' else FODvIUaCWRPEjoeiHVwTpqMBGdAbgc
 def addon_epgupdate_confignm():
  return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
else:
 def addon_log(string):
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgs(string)
 def addon_getautoepg():
  return FODvIUaCWRPEjoeiHVwTpqMBGdAbgk
 def addon_epgupdate_confignm():
  return 'd:\\job\\boritv_update.json'
class xFODvIUaCWRPEjoeiHVwTpqMBGdAbgL():
 def __init__(FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ):
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.START_INTERVAL =10 
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.INTERVAL =10 
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_FILETAGNM ='date_makeepg'
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_MAKEDATE ='-' 
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_WILL_TM =-1 
 def Get_Now_Datetime(FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def MakeEpg_DateCheck(FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ):
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgY ='-'
  if FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_MAKEDATE=='-':
   try:
    fp=FODvIUaCWRPEjoeiHVwTpqMBGdAbgr(addon_epgupdate_confignm(),'r',-1,'utf-8')
    FODvIUaCWRPEjoeiHVwTpqMBGdAbgm= json.load(fp)
    fp.close()
    FODvIUaCWRPEjoeiHVwTpqMBGdAbgY=FODvIUaCWRPEjoeiHVwTpqMBGdAbgm[FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_FILETAGNM]
   except FODvIUaCWRPEjoeiHVwTpqMBGdAbgK as exception:
    return 5 
  else:
   FODvIUaCWRPEjoeiHVwTpqMBGdAbgY=FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_MAKEDATE
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgS =FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.Get_Now_Datetime()
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgf=(FODvIUaCWRPEjoeiHVwTpqMBGdAbgS-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgu =FODvIUaCWRPEjoeiHVwTpqMBGdAbgS.strftime('%Y-%m-%d')
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgz =FODvIUaCWRPEjoeiHVwTpqMBGdAbgS.strftime('%H')
  if FODvIUaCWRPEjoeiHVwTpqMBGdAbgY==FODvIUaCWRPEjoeiHVwTpqMBGdAbgu: return-1
  if FODvIUaCWRPEjoeiHVwTpqMBGdAbgY==FODvIUaCWRPEjoeiHVwTpqMBGdAbgf and FODvIUaCWRPEjoeiHVwTpqMBGdAbgz=='00':return 30
  return 5
 def MakeEpg_RandomTm(FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ,mintm):
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgJ=(mintm*60)+random.randint(0,300)
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgS =FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.Get_Now_Datetime()
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgy =(FODvIUaCWRPEjoeiHVwTpqMBGdAbgS+datetime.timedelta(seconds=FODvIUaCWRPEjoeiHVwTpqMBGdAbgJ)).strftime('%Y%m%d%H%M%S')
  return FODvIUaCWRPEjoeiHVwTpqMBGdAbLg(FODvIUaCWRPEjoeiHVwTpqMBGdAbgy)
 def MakeEpg_SaveJson(FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ):
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgm={FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_FILETAGNM:FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=FODvIUaCWRPEjoeiHVwTpqMBGdAbgr(addon_epgupdate_confignm(),'w',-1,'utf-8')
   json.dump(FODvIUaCWRPEjoeiHVwTpqMBGdAbgm,fp)
   fp.close()
  except FODvIUaCWRPEjoeiHVwTpqMBGdAbgK as exception:
   return
 def service_run(FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ):
  if addon_getautoepg()==FODvIUaCWRPEjoeiHVwTpqMBGdAbgc:return
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgx=FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.MakeEpg_DateCheck()
  if FODvIUaCWRPEjoeiHVwTpqMBGdAbgx<0:
   return
  if FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_WILL_TM<0:
   FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_WILL_TM=FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.MakeEpg_RandomTm(FODvIUaCWRPEjoeiHVwTpqMBGdAbgx)
   addon_log('EPG_WILL_TM --> '+FODvIUaCWRPEjoeiHVwTpqMBGdAbgl(FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_WILL_TM))
  else:
   FODvIUaCWRPEjoeiHVwTpqMBGdAbgu=FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.Get_Now_Datetime()
   if FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_WILL_TM<FODvIUaCWRPEjoeiHVwTpqMBGdAbLg(FODvIUaCWRPEjoeiHVwTpqMBGdAbgu.strftime('%Y%m%d%H%M%S')):
    addon_log('make epg')
    xbmc.executebuiltin('RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")')
    FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.MakeEpg_SaveJson()
    FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_MAKEDATE=FODvIUaCWRPEjoeiHVwTpqMBGdAbgu.strftime('%Y-%m-%d')
    FODvIUaCWRPEjoeiHVwTpqMBGdAbgQ.EPG_WILL_TM =-1
   else:
    pass
  pass
if __name__=="__main__":
 addon_log('__main__')
 FODvIUaCWRPEjoeiHVwTpqMBGdAbgh=FODvIUaCWRPEjoeiHVwTpqMBGdAbgL()
 time.sleep(FODvIUaCWRPEjoeiHVwTpqMBGdAbgh.START_INTERVAL)
 while FODvIUaCWRPEjoeiHVwTpqMBGdAbgk:
  time.sleep(FODvIUaCWRPEjoeiHVwTpqMBGdAbgh.INTERVAL)
  FODvIUaCWRPEjoeiHVwTpqMBGdAbgh.service_run()
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
