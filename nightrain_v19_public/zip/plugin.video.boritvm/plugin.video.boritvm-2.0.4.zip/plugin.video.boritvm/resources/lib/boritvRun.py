__author__="NightRain"
qhyEbPFgSQmdlTfxMvAwHKCcYreDXs=object
qhyEbPFgSQmdlTfxMvAwHKCcYreDXB=False
qhyEbPFgSQmdlTfxMvAwHKCcYreDXV=None
qhyEbPFgSQmdlTfxMvAwHKCcYreDXW=True
qhyEbPFgSQmdlTfxMvAwHKCcYreDXa=len
qhyEbPFgSQmdlTfxMvAwHKCcYreDtN=str
qhyEbPFgSQmdlTfxMvAwHKCcYreDtJ=open
qhyEbPFgSQmdlTfxMvAwHKCcYreDtX=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
qhyEbPFgSQmdlTfxMvAwHKCcYreDNX=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'}]
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
qhyEbPFgSQmdlTfxMvAwHKCcYreDNt='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
qhyEbPFgSQmdlTfxMvAwHKCcYreDNn=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class qhyEbPFgSQmdlTfxMvAwHKCcYreDNJ(qhyEbPFgSQmdlTfxMvAwHKCcYreDXs):
 def __init__(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU,qhyEbPFgSQmdlTfxMvAwHKCcYreDNL,qhyEbPFgSQmdlTfxMvAwHKCcYreDNG,qhyEbPFgSQmdlTfxMvAwHKCcYreDNR):
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU._addon_url =qhyEbPFgSQmdlTfxMvAwHKCcYreDNL
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU._addon_handle =qhyEbPFgSQmdlTfxMvAwHKCcYreDNG
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.main_params =qhyEbPFgSQmdlTfxMvAwHKCcYreDNR
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_FILE_PATH ='' 
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_FILE_NAME ='' 
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVE =qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONTVING =qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONSPOTV =qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVERADIO=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVEHOME =qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONSPOTVPAY =qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_DISPLAYNM =qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.BoritvObj =YCEftNveGorqgwLpxyAuObDISsiTcV() 
 def addon_noti(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU,sting):
  try:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNp=xbmcgui.Dialog()
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNp.notification(__addonname__,sting)
  except:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXV
 def addon_log(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU,string):
  try:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNi=string.encode('utf-8','ignore')
  except:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNi='addonException: addon_log'
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNI=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,qhyEbPFgSQmdlTfxMvAwHKCcYreDNi),level=qhyEbPFgSQmdlTfxMvAwHKCcYreDNI)
 def get_keyboard_input(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU,qhyEbPFgSQmdlTfxMvAwHKCcYreDNz):
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNk=qhyEbPFgSQmdlTfxMvAwHKCcYreDXV
  kb=xbmc.Keyboard()
  kb.setHeading(qhyEbPFgSQmdlTfxMvAwHKCcYreDNz)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNk=kb.getText()
  return qhyEbPFgSQmdlTfxMvAwHKCcYreDNk
 def add_dir(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU,label,sublabel='',img='',infoLabels=qhyEbPFgSQmdlTfxMvAwHKCcYreDXV,isFolder=qhyEbPFgSQmdlTfxMvAwHKCcYreDXW,params=''):
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNO='%s?%s'%(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU._addon_url,urllib.parse.urlencode(params))
  if sublabel:qhyEbPFgSQmdlTfxMvAwHKCcYreDNz='%s < %s >'%(label,sublabel)
  else: qhyEbPFgSQmdlTfxMvAwHKCcYreDNz=label
  if not img:img='DefaultFolder.png'
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNj=xbmcgui.ListItem(qhyEbPFgSQmdlTfxMvAwHKCcYreDNz)
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNj.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:qhyEbPFgSQmdlTfxMvAwHKCcYreDNj.setInfo(type="video",infoLabels=infoLabels)
  if not isFolder:qhyEbPFgSQmdlTfxMvAwHKCcYreDNj.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU._addon_handle,qhyEbPFgSQmdlTfxMvAwHKCcYreDNO,qhyEbPFgSQmdlTfxMvAwHKCcYreDNj,isFolder)
 def make_M3u_Filename(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU,tempyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_FILE_PATH+qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU,tempyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_FILE_PATH+qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_FILE_NAME+'.xml'
 def dp_Main_List(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU):
  for qhyEbPFgSQmdlTfxMvAwHKCcYreDNo in qhyEbPFgSQmdlTfxMvAwHKCcYreDNX:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNz=qhyEbPFgSQmdlTfxMvAwHKCcYreDNo.get('title')
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNs={'mode':qhyEbPFgSQmdlTfxMvAwHKCcYreDNo.get('mode'),'sType':qhyEbPFgSQmdlTfxMvAwHKCcYreDNo.get('sType'),'sName':qhyEbPFgSQmdlTfxMvAwHKCcYreDNo.get('sName')}
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDNo.get('mode')=='XXX':
    qhyEbPFgSQmdlTfxMvAwHKCcYreDNB=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
   else:
    qhyEbPFgSQmdlTfxMvAwHKCcYreDNB=qhyEbPFgSQmdlTfxMvAwHKCcYreDXW
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNV=qhyEbPFgSQmdlTfxMvAwHKCcYreDXW
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDNo.get('mode')=='ADD_M3U':
    if qhyEbPFgSQmdlTfxMvAwHKCcYreDNo.get('sType')=='wavve' and qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVE==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:qhyEbPFgSQmdlTfxMvAwHKCcYreDNV=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
    if qhyEbPFgSQmdlTfxMvAwHKCcYreDNo.get('sType')=='tving' and qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONTVING==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:qhyEbPFgSQmdlTfxMvAwHKCcYreDNV=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
    if qhyEbPFgSQmdlTfxMvAwHKCcYreDNo.get('sType')=='spotv' and qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONSPOTV==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:qhyEbPFgSQmdlTfxMvAwHKCcYreDNV=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDNV==qhyEbPFgSQmdlTfxMvAwHKCcYreDXW:
    qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.add_dir(qhyEbPFgSQmdlTfxMvAwHKCcYreDNz,sublabel='',img='',infoLabels=qhyEbPFgSQmdlTfxMvAwHKCcYreDXV,isFolder=qhyEbPFgSQmdlTfxMvAwHKCcYreDNB,params=qhyEbPFgSQmdlTfxMvAwHKCcYreDNs)
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDNX)>0:xbmcplugin.endOfDirectory(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU._addon_handle,cacheToDisc=qhyEbPFgSQmdlTfxMvAwHKCcYreDXW)
 def dp_Delete_M3u(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU,args):
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNp=xbmcgui.Dialog()
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNa=qhyEbPFgSQmdlTfxMvAwHKCcYreDNp.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDNa==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:sys.exit()
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJN=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.make_M3u_Filename(tempyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB)
  if xbmcvfs.exists(qhyEbPFgSQmdlTfxMvAwHKCcYreDJN):
   if xbmcvfs.delete(qhyEbPFgSQmdlTfxMvAwHKCcYreDJN)==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:
    qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_noti(__language__(30910).encode('utf-8'))
    return
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU,args):
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=args.get('sType')
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJt=args.get('sName')
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNp=xbmcgui.Dialog()
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNa=qhyEbPFgSQmdlTfxMvAwHKCcYreDNp.yesno((qhyEbPFgSQmdlTfxMvAwHKCcYreDJt+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDNa==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:sys.exit()
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJn =[]
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJU =[]
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJL=[]
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='all':
   qhyEbPFgSQmdlTfxMvAwHKCcYreDJN=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.make_M3u_Filename(tempyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDXW)
   if os.path.isfile(qhyEbPFgSQmdlTfxMvAwHKCcYreDJN):os.remove(qhyEbPFgSQmdlTfxMvAwHKCcYreDJN)
   qhyEbPFgSQmdlTfxMvAwHKCcYreDJN=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.make_M3u_Filename(tempyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB)
   if xbmcvfs.exists(qhyEbPFgSQmdlTfxMvAwHKCcYreDJN):
    if xbmcvfs.delete(qhyEbPFgSQmdlTfxMvAwHKCcYreDJN)==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:
     qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_noti(__language__(30910).encode('utf-8'))
     return
  if(qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='wavve' or qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='all')and qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVE:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDJG=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.BoritvObj.Get_ChannelList_Wavve(exceptGroup=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.make_EexceptGroup_Wavve())
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDJG)!=0:qhyEbPFgSQmdlTfxMvAwHKCcYreDJn.extend(qhyEbPFgSQmdlTfxMvAwHKCcYreDJG)
   qhyEbPFgSQmdlTfxMvAwHKCcYreDJL=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.get_radio_list()
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_log('wavve cnt ----> '+qhyEbPFgSQmdlTfxMvAwHKCcYreDtN(qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDJG)))
  if(qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='tving' or qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='all')and qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONTVING:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDJG=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.BoritvObj.Get_ChannelList_Tving()
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDJG)!=0:qhyEbPFgSQmdlTfxMvAwHKCcYreDJn.extend(qhyEbPFgSQmdlTfxMvAwHKCcYreDJG)
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_log('tving cnt ----> '+qhyEbPFgSQmdlTfxMvAwHKCcYreDtN(qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDJG)))
  if(qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='spotv' or qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='all')and qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONSPOTV:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDJG=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.BoritvObj.Get_ChannelList_Spotv(payyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONSPOTVPAY)
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDJG)!=0:qhyEbPFgSQmdlTfxMvAwHKCcYreDJn.extend(qhyEbPFgSQmdlTfxMvAwHKCcYreDJG)
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_log('spotv cnt ----> '+qhyEbPFgSQmdlTfxMvAwHKCcYreDtN(qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDJG)))
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDJn)==0:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_noti(__language__(30909).encode('utf8'))
   return
  for qhyEbPFgSQmdlTfxMvAwHKCcYreDJR in qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.BoritvObj.INIT_GENRESORT:
   for qhyEbPFgSQmdlTfxMvAwHKCcYreDJu in qhyEbPFgSQmdlTfxMvAwHKCcYreDJn:
    if qhyEbPFgSQmdlTfxMvAwHKCcYreDJu['genrenm']==qhyEbPFgSQmdlTfxMvAwHKCcYreDJR:
     qhyEbPFgSQmdlTfxMvAwHKCcYreDJU.append(qhyEbPFgSQmdlTfxMvAwHKCcYreDJu)
  for qhyEbPFgSQmdlTfxMvAwHKCcYreDJu in qhyEbPFgSQmdlTfxMvAwHKCcYreDJn:
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDJu['genrenm']not in qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.BoritvObj.INIT_GENRESORT:
    qhyEbPFgSQmdlTfxMvAwHKCcYreDJU.append(qhyEbPFgSQmdlTfxMvAwHKCcYreDJu)
  try:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDJN=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.make_M3u_Filename(tempyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDXW)
   if os.path.isfile(qhyEbPFgSQmdlTfxMvAwHKCcYreDJN):
    fp=qhyEbPFgSQmdlTfxMvAwHKCcYreDtJ(qhyEbPFgSQmdlTfxMvAwHKCcYreDJN,'a',-1,'utf-8')
   else:
    fp=qhyEbPFgSQmdlTfxMvAwHKCcYreDtJ(qhyEbPFgSQmdlTfxMvAwHKCcYreDJN,'w',-1,'utf-8')
    fp.write('#EXTM3U\n')
   for qhyEbPFgSQmdlTfxMvAwHKCcYreDJp in qhyEbPFgSQmdlTfxMvAwHKCcYreDJU:
    qhyEbPFgSQmdlTfxMvAwHKCcYreDJi =qhyEbPFgSQmdlTfxMvAwHKCcYreDJp['channelid']
    qhyEbPFgSQmdlTfxMvAwHKCcYreDJI =qhyEbPFgSQmdlTfxMvAwHKCcYreDJp['channelnm']
    qhyEbPFgSQmdlTfxMvAwHKCcYreDJk=qhyEbPFgSQmdlTfxMvAwHKCcYreDJp['channelimg']
    qhyEbPFgSQmdlTfxMvAwHKCcYreDJO =qhyEbPFgSQmdlTfxMvAwHKCcYreDJp['ott']
    qhyEbPFgSQmdlTfxMvAwHKCcYreDJz ='%s.%s'%(qhyEbPFgSQmdlTfxMvAwHKCcYreDJi,qhyEbPFgSQmdlTfxMvAwHKCcYreDJO)
    qhyEbPFgSQmdlTfxMvAwHKCcYreDJj=qhyEbPFgSQmdlTfxMvAwHKCcYreDJp['genrenm']
    if qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_DISPLAYNM:
     qhyEbPFgSQmdlTfxMvAwHKCcYreDJI='%s (%s)'%(qhyEbPFgSQmdlTfxMvAwHKCcYreDJI,qhyEbPFgSQmdlTfxMvAwHKCcYreDJO)
    if qhyEbPFgSQmdlTfxMvAwHKCcYreDJi in qhyEbPFgSQmdlTfxMvAwHKCcYreDJL:
     qhyEbPFgSQmdlTfxMvAwHKCcYreDJo='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(qhyEbPFgSQmdlTfxMvAwHKCcYreDJz,qhyEbPFgSQmdlTfxMvAwHKCcYreDJI,qhyEbPFgSQmdlTfxMvAwHKCcYreDJj,qhyEbPFgSQmdlTfxMvAwHKCcYreDJk,qhyEbPFgSQmdlTfxMvAwHKCcYreDJI)
    else:
     qhyEbPFgSQmdlTfxMvAwHKCcYreDJo='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(qhyEbPFgSQmdlTfxMvAwHKCcYreDJz,qhyEbPFgSQmdlTfxMvAwHKCcYreDJI,qhyEbPFgSQmdlTfxMvAwHKCcYreDJj,qhyEbPFgSQmdlTfxMvAwHKCcYreDJk,qhyEbPFgSQmdlTfxMvAwHKCcYreDJI)
    if qhyEbPFgSQmdlTfxMvAwHKCcYreDJO=='wavve':
     qhyEbPFgSQmdlTfxMvAwHKCcYreDJs ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(qhyEbPFgSQmdlTfxMvAwHKCcYreDJi)
    elif qhyEbPFgSQmdlTfxMvAwHKCcYreDJO=='tving':
     qhyEbPFgSQmdlTfxMvAwHKCcYreDJs ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(qhyEbPFgSQmdlTfxMvAwHKCcYreDJi)
    elif qhyEbPFgSQmdlTfxMvAwHKCcYreDJO=='spotv':
     qhyEbPFgSQmdlTfxMvAwHKCcYreDJs ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(qhyEbPFgSQmdlTfxMvAwHKCcYreDJi)
    fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDJo)
    fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDJs)
   fp.close()
  except:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_noti(__language__(30910).encode('utf8'))
   return
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJB=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.make_M3u_Filename(tempyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDXW)
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJV=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.make_M3u_Filename(tempyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB)
  if xbmcvfs.copy(qhyEbPFgSQmdlTfxMvAwHKCcYreDJB,qhyEbPFgSQmdlTfxMvAwHKCcYreDJV):
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_noti((qhyEbPFgSQmdlTfxMvAwHKCcYreDJt+' '+__language__(30908)).encode('utf8'))
  else:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_noti(__language__(30910).encode('utf-8'))
 def dp_Make_Epg(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU,args):
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=args.get('sType')
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJt=args.get('sName')
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJW=args.get('sNoti')
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDJW!='N':
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNp=xbmcgui.Dialog()
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNa=qhyEbPFgSQmdlTfxMvAwHKCcYreDNp.yesno((qhyEbPFgSQmdlTfxMvAwHKCcYreDJt+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDNa==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:sys.exit()
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJa=[]
  qhyEbPFgSQmdlTfxMvAwHKCcYreDXN=[]
  if(qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='wavve' or qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='all')and qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVE:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXJ,qhyEbPFgSQmdlTfxMvAwHKCcYreDXt=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.make_EexceptGroup_Wavve())
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDXt)!=0:
    qhyEbPFgSQmdlTfxMvAwHKCcYreDJa.extend(qhyEbPFgSQmdlTfxMvAwHKCcYreDXJ)
    qhyEbPFgSQmdlTfxMvAwHKCcYreDXN.extend(qhyEbPFgSQmdlTfxMvAwHKCcYreDXt)
  if(qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='tving' or qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='all')and qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONTVING:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXJ,qhyEbPFgSQmdlTfxMvAwHKCcYreDXt=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.BoritvObj.Get_EpgInfo_Tving()
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDXt)!=0:
    qhyEbPFgSQmdlTfxMvAwHKCcYreDJa.extend(qhyEbPFgSQmdlTfxMvAwHKCcYreDXJ)
    qhyEbPFgSQmdlTfxMvAwHKCcYreDXN.extend(qhyEbPFgSQmdlTfxMvAwHKCcYreDXt)
  if(qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='spotv' or qhyEbPFgSQmdlTfxMvAwHKCcYreDJX=='all')and qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONSPOTV:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXJ,qhyEbPFgSQmdlTfxMvAwHKCcYreDXt=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.BoritvObj.Get_EpgInfo_Spotv(payyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONSPOTVPAY)
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDXt)!=0:
    qhyEbPFgSQmdlTfxMvAwHKCcYreDJa.extend(qhyEbPFgSQmdlTfxMvAwHKCcYreDXJ)
    qhyEbPFgSQmdlTfxMvAwHKCcYreDXN.extend(qhyEbPFgSQmdlTfxMvAwHKCcYreDXt)
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDXa(qhyEbPFgSQmdlTfxMvAwHKCcYreDXN)==0:
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDJW!='N':qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDJN=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.make_Epg_Filename(tempyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDXW)
   fp=qhyEbPFgSQmdlTfxMvAwHKCcYreDtJ(qhyEbPFgSQmdlTfxMvAwHKCcYreDJN,'w',-1,'utf-8')
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXn='<?xml version="1.0" encoding="UTF-8"?>\n'
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXU='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXL='<tv generator-info-name="boritv_epg">\n\n'
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXG='\n</tv>\n'
   fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDXn)
   fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDXU)
   fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDXL)
   for qhyEbPFgSQmdlTfxMvAwHKCcYreDXR in qhyEbPFgSQmdlTfxMvAwHKCcYreDJa:
    qhyEbPFgSQmdlTfxMvAwHKCcYreDXu='  <channel id="%s.%s">\n' %(qhyEbPFgSQmdlTfxMvAwHKCcYreDXR.get('channelid'),qhyEbPFgSQmdlTfxMvAwHKCcYreDXR.get('ott'))
    qhyEbPFgSQmdlTfxMvAwHKCcYreDXp='    <display-name>%s</display-name>\n'%(qhyEbPFgSQmdlTfxMvAwHKCcYreDXR.get('channelnm'))
    qhyEbPFgSQmdlTfxMvAwHKCcYreDXi='    <icon src="%s" />\n' %(qhyEbPFgSQmdlTfxMvAwHKCcYreDXR.get('channelimg'))
    qhyEbPFgSQmdlTfxMvAwHKCcYreDXI='  </channel>\n\n'
    fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDXu)
    fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDXp)
    fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDXi)
    fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDXI)
   for qhyEbPFgSQmdlTfxMvAwHKCcYreDXR in qhyEbPFgSQmdlTfxMvAwHKCcYreDXN:
    qhyEbPFgSQmdlTfxMvAwHKCcYreDXu='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(qhyEbPFgSQmdlTfxMvAwHKCcYreDXR.get('startTime'),qhyEbPFgSQmdlTfxMvAwHKCcYreDXR.get('endTime'),qhyEbPFgSQmdlTfxMvAwHKCcYreDXR.get('channelid'),qhyEbPFgSQmdlTfxMvAwHKCcYreDXR.get('ott'))
    qhyEbPFgSQmdlTfxMvAwHKCcYreDXp='    <title lang="kr">%s</title>\n' %(qhyEbPFgSQmdlTfxMvAwHKCcYreDXR.get('title'))
    qhyEbPFgSQmdlTfxMvAwHKCcYreDXi='  </programme>\n\n'
    fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDXu)
    fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDXp)
    fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDXi)
   fp.write(qhyEbPFgSQmdlTfxMvAwHKCcYreDXG)
   fp.close()
  except:
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDJW!='N':qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_noti(__language__(30910).encode('utf8'))
   return
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.MakeEpg_SaveJson()
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJB=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.make_Epg_Filename(tempyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDXW)
  qhyEbPFgSQmdlTfxMvAwHKCcYreDJV=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.make_Epg_Filename(tempyn=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB)
  if xbmcvfs.copy(qhyEbPFgSQmdlTfxMvAwHKCcYreDJB,qhyEbPFgSQmdlTfxMvAwHKCcYreDJV):
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDJW!='N':qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_noti((qhyEbPFgSQmdlTfxMvAwHKCcYreDJt+' '+__language__(30912)).encode('utf8'))
  else:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.addon_noti(__language__(30910).encode('utf-8'))
 def make_EexceptGroup_Wavve(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU):
  qhyEbPFgSQmdlTfxMvAwHKCcYreDXk=[]
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVERADIO==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXO={'broadcastid':'46584','genre':'10'}
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXk.append(qhyEbPFgSQmdlTfxMvAwHKCcYreDXO)
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVEHOME==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXO={'broadcastid':'46584','genre':'03'}
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXk.append(qhyEbPFgSQmdlTfxMvAwHKCcYreDXO)
  return qhyEbPFgSQmdlTfxMvAwHKCcYreDXk
 def get_radio_list(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU):
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVERADIO==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:return[]
  qhyEbPFgSQmdlTfxMvAwHKCcYreDXO=[{'broadcastid':'46584','genre':'10'}]
  return qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.BoritvObj.Get_ChannelList_WavveExcept(qhyEbPFgSQmdlTfxMvAwHKCcYreDXO)
 def check_config(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU):
  qhyEbPFgSQmdlTfxMvAwHKCcYreDXz=qhyEbPFgSQmdlTfxMvAwHKCcYreDXW
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVE =qhyEbPFgSQmdlTfxMvAwHKCcYreDXW if __addon__.getSetting('onWavve')=='true' else qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONTVING =qhyEbPFgSQmdlTfxMvAwHKCcYreDXW if __addon__.getSetting('onTvng')=='true' else qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONSPOTV =qhyEbPFgSQmdlTfxMvAwHKCcYreDXW if __addon__.getSetting('onSpotv')=='true' else qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVERADIO=qhyEbPFgSQmdlTfxMvAwHKCcYreDXW if __addon__.getSetting('onWavveRadio')=='true' else qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVEHOME =qhyEbPFgSQmdlTfxMvAwHKCcYreDXW if __addon__.getSetting('onWavveHome')=='true' else qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONSPOTVPAY =qhyEbPFgSQmdlTfxMvAwHKCcYreDXW if __addon__.getSetting('onSpotvPay')=='true' else qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_DISPLAYNM =qhyEbPFgSQmdlTfxMvAwHKCcYreDXW if __addon__.getSetting('displayOTTnm')=='true' else qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_FILE_PATH=='' or qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_FILE_NAME=='':qhyEbPFgSQmdlTfxMvAwHKCcYreDXz=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONWAVVE==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB and qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONTVING=='' and qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.M3U_ONSPOTV=='':qhyEbPFgSQmdlTfxMvAwHKCcYreDXz=qhyEbPFgSQmdlTfxMvAwHKCcYreDXB
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDXz==qhyEbPFgSQmdlTfxMvAwHKCcYreDXB:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNp=xbmcgui.Dialog()
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNa=qhyEbPFgSQmdlTfxMvAwHKCcYreDNp.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if qhyEbPFgSQmdlTfxMvAwHKCcYreDNa==qhyEbPFgSQmdlTfxMvAwHKCcYreDXW:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU):
  qhyEbPFgSQmdlTfxMvAwHKCcYreDXj={'date_makeepg':qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=qhyEbPFgSQmdlTfxMvAwHKCcYreDtJ(qhyEbPFgSQmdlTfxMvAwHKCcYreDNn,'w',-1,'utf-8')
   json.dump(qhyEbPFgSQmdlTfxMvAwHKCcYreDXj,fp)
   fp.close()
  except qhyEbPFgSQmdlTfxMvAwHKCcYreDtX as exception:
   return
 def boritv_main(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU):
  qhyEbPFgSQmdlTfxMvAwHKCcYreDXo=qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.main_params.get('mode',qhyEbPFgSQmdlTfxMvAwHKCcYreDXV)
  qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.check_config()
  if qhyEbPFgSQmdlTfxMvAwHKCcYreDXo is qhyEbPFgSQmdlTfxMvAwHKCcYreDXV:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.dp_Main_List()
  elif qhyEbPFgSQmdlTfxMvAwHKCcYreDXo=='DEL_M3U':
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.dp_Delete_M3u(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.main_params)
  elif qhyEbPFgSQmdlTfxMvAwHKCcYreDXo=='ADD_M3U':
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.dp_MakeAdd_M3u(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.main_params)
  elif qhyEbPFgSQmdlTfxMvAwHKCcYreDXo=='ADD_EPG':
   qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.dp_Make_Epg(qhyEbPFgSQmdlTfxMvAwHKCcYreDNU.main_params)
  else:
   qhyEbPFgSQmdlTfxMvAwHKCcYreDXV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
