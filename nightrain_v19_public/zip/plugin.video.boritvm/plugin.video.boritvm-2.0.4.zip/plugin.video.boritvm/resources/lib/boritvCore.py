__author__="NightRain"
YCEftNveGorqgwLpxyAuObDISsiTal=object
YCEftNveGorqgwLpxyAuObDISsiTaB=None
YCEftNveGorqgwLpxyAuObDISsiTad=False
YCEftNveGorqgwLpxyAuObDISsiTaQ=str
YCEftNveGorqgwLpxyAuObDISsiTah=Exception
YCEftNveGorqgwLpxyAuObDISsiTaX=print
YCEftNveGorqgwLpxyAuObDISsiTaz=True
YCEftNveGorqgwLpxyAuObDISsiTaK=int
YCEftNveGorqgwLpxyAuObDISsiTaW=range
YCEftNveGorqgwLpxyAuObDISsiTam=len
YCEftNveGorqgwLpxyAuObDISsiTaR=set
YCEftNveGorqgwLpxyAuObDISsiTaU=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
from channelgenre import*
YCEftNveGorqgwLpxyAuObDISsiTcM='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
YCEftNveGorqgwLpxyAuObDISsiTca=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
class YCEftNveGorqgwLpxyAuObDISsiTcV(YCEftNveGorqgwLpxyAuObDISsiTal):
 def __init__(YCEftNveGorqgwLpxyAuObDISsiTcl):
  YCEftNveGorqgwLpxyAuObDISsiTcl.API_WAVVE ='https://apis.wavve.com'
  YCEftNveGorqgwLpxyAuObDISsiTcl.API_TVING ='https://api.tving.com'
  YCEftNveGorqgwLpxyAuObDISsiTcl.API_TVINGIMG ='https://image.tving.com'
  YCEftNveGorqgwLpxyAuObDISsiTcl.API_SPOTV ='https://www.spotvnow.co.kr'
  YCEftNveGorqgwLpxyAuObDISsiTcl.HTTPTAG ='https://'
  YCEftNveGorqgwLpxyAuObDISsiTcl.LIMIT_WAVVE =200
  YCEftNveGorqgwLpxyAuObDISsiTcl.LIMIT_TVING =60
  YCEftNveGorqgwLpxyAuObDISsiTcl.LIMIT_TVINGEPG=20 
  YCEftNveGorqgwLpxyAuObDISsiTcl.DEFAULT_HEADER={'user-agent':YCEftNveGorqgwLpxyAuObDISsiTcM}
  YCEftNveGorqgwLpxyAuObDISsiTcl.SLEEP_TIME =0.2
  YCEftNveGorqgwLpxyAuObDISsiTcl.INIT_GENRESORT=MASTER_GENRE
  YCEftNveGorqgwLpxyAuObDISsiTcl.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(YCEftNveGorqgwLpxyAuObDISsiTcl,jobtype,YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTaB,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB,redirects=YCEftNveGorqgwLpxyAuObDISsiTad):
  YCEftNveGorqgwLpxyAuObDISsiTcQ=YCEftNveGorqgwLpxyAuObDISsiTcl.DEFAULT_HEADER
  if headers:YCEftNveGorqgwLpxyAuObDISsiTcQ.update(headers)
  if jobtype=='Get':
   YCEftNveGorqgwLpxyAuObDISsiTch=requests.get(YCEftNveGorqgwLpxyAuObDISsiTcU,params=params,headers=YCEftNveGorqgwLpxyAuObDISsiTcQ,cookies=cookies,allow_redirects=redirects)
  else:
   YCEftNveGorqgwLpxyAuObDISsiTch=requests.post(YCEftNveGorqgwLpxyAuObDISsiTcU,data=payload,params=params,headers=YCEftNveGorqgwLpxyAuObDISsiTcQ,cookies=cookies,allow_redirects=redirects)
  return YCEftNveGorqgwLpxyAuObDISsiTch
 def Get_DefaultParams_Wavve(YCEftNveGorqgwLpxyAuObDISsiTcl):
  YCEftNveGorqgwLpxyAuObDISsiTcX={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return YCEftNveGorqgwLpxyAuObDISsiTcX
 def Get_DefaultParams_Tving(YCEftNveGorqgwLpxyAuObDISsiTcl):
  YCEftNveGorqgwLpxyAuObDISsiTcX={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return YCEftNveGorqgwLpxyAuObDISsiTcX
 def Get_Now_Datetime(YCEftNveGorqgwLpxyAuObDISsiTcl):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(YCEftNveGorqgwLpxyAuObDISsiTcl,in_text):
  YCEftNveGorqgwLpxyAuObDISsiTcK=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return YCEftNveGorqgwLpxyAuObDISsiTcK
 def Get_ChannelList_Wavve(YCEftNveGorqgwLpxyAuObDISsiTcl,exceptGroup=[]):
  YCEftNveGorqgwLpxyAuObDISsiTcW =[]
  YCEftNveGorqgwLpxyAuObDISsiTcm=[]
  YCEftNveGorqgwLpxyAuObDISsiTcR=YCEftNveGorqgwLpxyAuObDISsiTcl.Get_ChannelImg_Wavve()
  if exceptGroup!=[]:
   YCEftNveGorqgwLpxyAuObDISsiTcm=YCEftNveGorqgwLpxyAuObDISsiTcl.Get_ChannelList_WavveExcept(exceptGroup)
  try:
   YCEftNveGorqgwLpxyAuObDISsiTcU=YCEftNveGorqgwLpxyAuObDISsiTcl.API_WAVVE+'/cf/live/recommend-channels'
   YCEftNveGorqgwLpxyAuObDISsiTcX={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':YCEftNveGorqgwLpxyAuObDISsiTaQ(YCEftNveGorqgwLpxyAuObDISsiTcl.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   YCEftNveGorqgwLpxyAuObDISsiTcX.update(YCEftNveGorqgwLpxyAuObDISsiTcl.Get_DefaultParams_Wavve())
   YCEftNveGorqgwLpxyAuObDISsiTcn=YCEftNveGorqgwLpxyAuObDISsiTcl.callRequestCookies('Get',YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTcX,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB)
   YCEftNveGorqgwLpxyAuObDISsiTck=json.loads(YCEftNveGorqgwLpxyAuObDISsiTcn.text)
   if not('celllist' in YCEftNveGorqgwLpxyAuObDISsiTck['cell_toplist']):return YCEftNveGorqgwLpxyAuObDISsiTcW
   YCEftNveGorqgwLpxyAuObDISsiTcF=YCEftNveGorqgwLpxyAuObDISsiTck['cell_toplist']['celllist']
   for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTcF:
    YCEftNveGorqgwLpxyAuObDISsiTcP=YCEftNveGorqgwLpxyAuObDISsiTcH['contentid']
    YCEftNveGorqgwLpxyAuObDISsiTcj=YCEftNveGorqgwLpxyAuObDISsiTcH['title_list'][0]['text']
    if YCEftNveGorqgwLpxyAuObDISsiTcP in YCEftNveGorqgwLpxyAuObDISsiTcR:
     YCEftNveGorqgwLpxyAuObDISsiTcJ=YCEftNveGorqgwLpxyAuObDISsiTcR[YCEftNveGorqgwLpxyAuObDISsiTcP]
    else:
     YCEftNveGorqgwLpxyAuObDISsiTcJ=''
    YCEftNveGorqgwLpxyAuObDISsiTVc={'channelid':YCEftNveGorqgwLpxyAuObDISsiTcP,'channelnm':YCEftNveGorqgwLpxyAuObDISsiTcj,'channelimg':YCEftNveGorqgwLpxyAuObDISsiTcl.HTTPTAG+YCEftNveGorqgwLpxyAuObDISsiTcJ if YCEftNveGorqgwLpxyAuObDISsiTcJ!='' else '','ott':'wavve','genrenm':YCEftNveGorqgwLpxyAuObDISsiTcl.make_getGenre(YCEftNveGorqgwLpxyAuObDISsiTcP,'wavve')}
    if YCEftNveGorqgwLpxyAuObDISsiTcP not in YCEftNveGorqgwLpxyAuObDISsiTcm:
     YCEftNveGorqgwLpxyAuObDISsiTcW.append(YCEftNveGorqgwLpxyAuObDISsiTVc)
  except YCEftNveGorqgwLpxyAuObDISsiTah as exception:
   YCEftNveGorqgwLpxyAuObDISsiTaX(exception)
   return[]
  return YCEftNveGorqgwLpxyAuObDISsiTcW
 def Get_ChannelList_WavveExcept(YCEftNveGorqgwLpxyAuObDISsiTcl,exceptGroup=[]):
  YCEftNveGorqgwLpxyAuObDISsiTcW=[]
  if exceptGroup==[]:return[]
  try:
   YCEftNveGorqgwLpxyAuObDISsiTcU=YCEftNveGorqgwLpxyAuObDISsiTcl.API_WAVVE+'/cf/live/recommend-channels'
   for YCEftNveGorqgwLpxyAuObDISsiTcH in exceptGroup:
    YCEftNveGorqgwLpxyAuObDISsiTcX={'WeekDay':'all','adult':'n','broadcastid':YCEftNveGorqgwLpxyAuObDISsiTcH['broadcastid'],'contenttype':'channel','genre':YCEftNveGorqgwLpxyAuObDISsiTcH['genre'],'isrecommend':'y','limit':YCEftNveGorqgwLpxyAuObDISsiTaQ(YCEftNveGorqgwLpxyAuObDISsiTcl.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    YCEftNveGorqgwLpxyAuObDISsiTcX.update(YCEftNveGorqgwLpxyAuObDISsiTcl.Get_DefaultParams_Wavve())
    YCEftNveGorqgwLpxyAuObDISsiTcn=YCEftNveGorqgwLpxyAuObDISsiTcl.callRequestCookies('Get',YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTcX,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB)
    YCEftNveGorqgwLpxyAuObDISsiTck=json.loads(YCEftNveGorqgwLpxyAuObDISsiTcn.text)
    if not('celllist' in YCEftNveGorqgwLpxyAuObDISsiTck['cell_toplist']):return YCEftNveGorqgwLpxyAuObDISsiTcW
    YCEftNveGorqgwLpxyAuObDISsiTcF=YCEftNveGorqgwLpxyAuObDISsiTck['cell_toplist']['celllist']
    for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTcF:
     YCEftNveGorqgwLpxyAuObDISsiTcW.append(YCEftNveGorqgwLpxyAuObDISsiTcH['contentid'])
  except YCEftNveGorqgwLpxyAuObDISsiTah as exception:
   YCEftNveGorqgwLpxyAuObDISsiTaX(exception)
   return[]
  return YCEftNveGorqgwLpxyAuObDISsiTcW
 def Get_ChannelImg_Wavve(YCEftNveGorqgwLpxyAuObDISsiTcl):
  YCEftNveGorqgwLpxyAuObDISsiTVM={}
  try:
   YCEftNveGorqgwLpxyAuObDISsiTVa=YCEftNveGorqgwLpxyAuObDISsiTcl.Get_Now_Datetime()
   YCEftNveGorqgwLpxyAuObDISsiTVl =YCEftNveGorqgwLpxyAuObDISsiTVa+datetime.timedelta(hours=3)
   YCEftNveGorqgwLpxyAuObDISsiTcU=YCEftNveGorqgwLpxyAuObDISsiTcl.API_WAVVE+'/live/epgs'
   YCEftNveGorqgwLpxyAuObDISsiTcX={'limit':YCEftNveGorqgwLpxyAuObDISsiTaQ(YCEftNveGorqgwLpxyAuObDISsiTcl.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':YCEftNveGorqgwLpxyAuObDISsiTVa.strftime('%Y-%m-%d %H:00'),'enddatetime':YCEftNveGorqgwLpxyAuObDISsiTVl.strftime('%Y-%m-%d %H:00')}
   YCEftNveGorqgwLpxyAuObDISsiTcX.update(YCEftNveGorqgwLpxyAuObDISsiTcl.Get_DefaultParams_Wavve())
   YCEftNveGorqgwLpxyAuObDISsiTcn=YCEftNveGorqgwLpxyAuObDISsiTcl.callRequestCookies('Get',YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTcX,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB)
   YCEftNveGorqgwLpxyAuObDISsiTck=json.loads(YCEftNveGorqgwLpxyAuObDISsiTcn.text)
   YCEftNveGorqgwLpxyAuObDISsiTcF=YCEftNveGorqgwLpxyAuObDISsiTck['list']
   for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTcF:
    YCEftNveGorqgwLpxyAuObDISsiTVM[YCEftNveGorqgwLpxyAuObDISsiTcH['channelid']]=YCEftNveGorqgwLpxyAuObDISsiTcH['channelimage']
  except YCEftNveGorqgwLpxyAuObDISsiTah as exception:
   YCEftNveGorqgwLpxyAuObDISsiTaX(exception)
  return YCEftNveGorqgwLpxyAuObDISsiTVM
 def Get_ChanneGenrename_Wavve(YCEftNveGorqgwLpxyAuObDISsiTcl,YCEftNveGorqgwLpxyAuObDISsiTcP):
  try:
   YCEftNveGorqgwLpxyAuObDISsiTcU=YCEftNveGorqgwLpxyAuObDISsiTcl.API_WAVVE+'/live/channels/'+YCEftNveGorqgwLpxyAuObDISsiTcP
   YCEftNveGorqgwLpxyAuObDISsiTcX=YCEftNveGorqgwLpxyAuObDISsiTcl.Get_DefaultParams_Wavve()
   YCEftNveGorqgwLpxyAuObDISsiTcn=YCEftNveGorqgwLpxyAuObDISsiTcl.callRequestCookies('Get',YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTcX,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB)
   YCEftNveGorqgwLpxyAuObDISsiTck=json.loads(YCEftNveGorqgwLpxyAuObDISsiTcn.text)
   YCEftNveGorqgwLpxyAuObDISsiTVB=YCEftNveGorqgwLpxyAuObDISsiTck['genretext']
  except YCEftNveGorqgwLpxyAuObDISsiTah as exception:
   YCEftNveGorqgwLpxyAuObDISsiTaX(exception)
   return ''
  return YCEftNveGorqgwLpxyAuObDISsiTVB
 def Get_ChannelList_Spotv(YCEftNveGorqgwLpxyAuObDISsiTcl,payyn=YCEftNveGorqgwLpxyAuObDISsiTaz):
  YCEftNveGorqgwLpxyAuObDISsiTcW=[]
  try:
   YCEftNveGorqgwLpxyAuObDISsiTcU=YCEftNveGorqgwLpxyAuObDISsiTcl.API_SPOTV+'/api/v2/channel'
   YCEftNveGorqgwLpxyAuObDISsiTcn=YCEftNveGorqgwLpxyAuObDISsiTcl.callRequestCookies('Get',YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTaB,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB)
   YCEftNveGorqgwLpxyAuObDISsiTck=json.loads(YCEftNveGorqgwLpxyAuObDISsiTcn.text)
   for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTck:
    YCEftNveGorqgwLpxyAuObDISsiTcP=YCEftNveGorqgwLpxyAuObDISsiTcH['videoId'].replace('ref:','')
    YCEftNveGorqgwLpxyAuObDISsiTVc={'channelid':YCEftNveGorqgwLpxyAuObDISsiTcP,'channelnm':YCEftNveGorqgwLpxyAuObDISsiTcH['name'],'channelimg':YCEftNveGorqgwLpxyAuObDISsiTcH['logo'],'ott':'spotv','genrenm':YCEftNveGorqgwLpxyAuObDISsiTcl.make_getGenre(YCEftNveGorqgwLpxyAuObDISsiTcP,'spotv')}
    if payyn==YCEftNveGorqgwLpxyAuObDISsiTaz or YCEftNveGorqgwLpxyAuObDISsiTcH['free']==YCEftNveGorqgwLpxyAuObDISsiTaz:
     YCEftNveGorqgwLpxyAuObDISsiTcW.append(YCEftNveGorqgwLpxyAuObDISsiTVc)
  except YCEftNveGorqgwLpxyAuObDISsiTah as exception:
   YCEftNveGorqgwLpxyAuObDISsiTaX(exception)
   return[]
  return YCEftNveGorqgwLpxyAuObDISsiTcW
 def Get_ChannelList_Tving(YCEftNveGorqgwLpxyAuObDISsiTcl):
  YCEftNveGorqgwLpxyAuObDISsiTcW =[]
  YCEftNveGorqgwLpxyAuObDISsiTVd=[]
  try:
   YCEftNveGorqgwLpxyAuObDISsiTcU=YCEftNveGorqgwLpxyAuObDISsiTcl.API_TVING+'/v2/media/lives'
   YCEftNveGorqgwLpxyAuObDISsiTcX={'pageNo':'1','pageSize':YCEftNveGorqgwLpxyAuObDISsiTaQ(YCEftNveGorqgwLpxyAuObDISsiTcl.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   YCEftNveGorqgwLpxyAuObDISsiTcX.update(YCEftNveGorqgwLpxyAuObDISsiTcl.Get_DefaultParams_Tving())
   YCEftNveGorqgwLpxyAuObDISsiTcn=YCEftNveGorqgwLpxyAuObDISsiTcl.callRequestCookies('Get',YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTcX,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB)
   YCEftNveGorqgwLpxyAuObDISsiTck=json.loads(YCEftNveGorqgwLpxyAuObDISsiTcn.text)
   if not('result' in YCEftNveGorqgwLpxyAuObDISsiTck['body']):return YCEftNveGorqgwLpxyAuObDISsiTcW
   YCEftNveGorqgwLpxyAuObDISsiTcF=YCEftNveGorqgwLpxyAuObDISsiTck['body']['result']
   for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTcF:
    if YCEftNveGorqgwLpxyAuObDISsiTcH['live_code']=='C44441':continue 
    YCEftNveGorqgwLpxyAuObDISsiTVd.append(YCEftNveGorqgwLpxyAuObDISsiTcH['live_code'])
   YCEftNveGorqgwLpxyAuObDISsiTcR=YCEftNveGorqgwLpxyAuObDISsiTcl.Get_ChannelImg_Tving(YCEftNveGorqgwLpxyAuObDISsiTVd)
   for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTcF:
    YCEftNveGorqgwLpxyAuObDISsiTcP=YCEftNveGorqgwLpxyAuObDISsiTcH['live_code']
    if YCEftNveGorqgwLpxyAuObDISsiTcP=='C44441':continue 
    YCEftNveGorqgwLpxyAuObDISsiTcj=YCEftNveGorqgwLpxyAuObDISsiTcH['schedule']['channel']['name']['ko']
    if YCEftNveGorqgwLpxyAuObDISsiTcP in YCEftNveGorqgwLpxyAuObDISsiTcR:
     YCEftNveGorqgwLpxyAuObDISsiTcJ=YCEftNveGorqgwLpxyAuObDISsiTcR[YCEftNveGorqgwLpxyAuObDISsiTcP]
    else:
     YCEftNveGorqgwLpxyAuObDISsiTcJ=''
    YCEftNveGorqgwLpxyAuObDISsiTVc={'channelid':YCEftNveGorqgwLpxyAuObDISsiTcP,'channelnm':YCEftNveGorqgwLpxyAuObDISsiTcj,'channelimg':YCEftNveGorqgwLpxyAuObDISsiTcJ,'ott':'tving','genrenm':YCEftNveGorqgwLpxyAuObDISsiTcl.make_getGenre(YCEftNveGorqgwLpxyAuObDISsiTcP,'tving')}
    YCEftNveGorqgwLpxyAuObDISsiTcW.append(YCEftNveGorqgwLpxyAuObDISsiTVc)
  except YCEftNveGorqgwLpxyAuObDISsiTah as exception:
   YCEftNveGorqgwLpxyAuObDISsiTaX(exception)
   return[]
  return YCEftNveGorqgwLpxyAuObDISsiTcW
 def make_EpgDatetime_Tving(YCEftNveGorqgwLpxyAuObDISsiTcl,days=2):
  YCEftNveGorqgwLpxyAuObDISsiTVQ=[]
  YCEftNveGorqgwLpxyAuObDISsiTVh=YCEftNveGorqgwLpxyAuObDISsiTcl.make_DateList(days=2,dateType='2')
  YCEftNveGorqgwLpxyAuObDISsiTVX=YCEftNveGorqgwLpxyAuObDISsiTaK(YCEftNveGorqgwLpxyAuObDISsiTcl.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTVh:
   for YCEftNveGorqgwLpxyAuObDISsiTVz in YCEftNveGorqgwLpxyAuObDISsiTaW(8):
    YCEftNveGorqgwLpxyAuObDISsiTVc={'ndate':YCEftNveGorqgwLpxyAuObDISsiTcH,'starttm':YCEftNveGorqgwLpxyAuObDISsiTca[YCEftNveGorqgwLpxyAuObDISsiTVz]['starttm'],'endtm':YCEftNveGorqgwLpxyAuObDISsiTca[YCEftNveGorqgwLpxyAuObDISsiTVz]['endtm']}
    YCEftNveGorqgwLpxyAuObDISsiTVK=YCEftNveGorqgwLpxyAuObDISsiTaK(YCEftNveGorqgwLpxyAuObDISsiTcH+YCEftNveGorqgwLpxyAuObDISsiTca[YCEftNveGorqgwLpxyAuObDISsiTVz]['starttm'])
    YCEftNveGorqgwLpxyAuObDISsiTVW=YCEftNveGorqgwLpxyAuObDISsiTaK(YCEftNveGorqgwLpxyAuObDISsiTcH+YCEftNveGorqgwLpxyAuObDISsiTca[YCEftNveGorqgwLpxyAuObDISsiTVz]['endtm'])
    if YCEftNveGorqgwLpxyAuObDISsiTVX<=YCEftNveGorqgwLpxyAuObDISsiTVK or(YCEftNveGorqgwLpxyAuObDISsiTVK<YCEftNveGorqgwLpxyAuObDISsiTVX and YCEftNveGorqgwLpxyAuObDISsiTVX<YCEftNveGorqgwLpxyAuObDISsiTVW):
     YCEftNveGorqgwLpxyAuObDISsiTVQ.append(YCEftNveGorqgwLpxyAuObDISsiTVc)
  return YCEftNveGorqgwLpxyAuObDISsiTVQ
 def make_DateList(YCEftNveGorqgwLpxyAuObDISsiTcl,days=2,dateType='1'):
  YCEftNveGorqgwLpxyAuObDISsiTVh=[]
  YCEftNveGorqgwLpxyAuObDISsiTVm =YCEftNveGorqgwLpxyAuObDISsiTcl.Get_Now_Datetime()
  if dateType=='1':
   YCEftNveGorqgwLpxyAuObDISsiTVm=YCEftNveGorqgwLpxyAuObDISsiTVm-datetime.timedelta(days=1)
  for i in YCEftNveGorqgwLpxyAuObDISsiTaW(days):
   YCEftNveGorqgwLpxyAuObDISsiTVR=YCEftNveGorqgwLpxyAuObDISsiTVm+datetime.timedelta(days=i)
   if dateType=='1':
    YCEftNveGorqgwLpxyAuObDISsiTVh.append(YCEftNveGorqgwLpxyAuObDISsiTVR.strftime('%Y-%m-%d'))
   else:
    YCEftNveGorqgwLpxyAuObDISsiTVh.append(YCEftNveGorqgwLpxyAuObDISsiTVR.strftime('%Y%m%d'))
  return YCEftNveGorqgwLpxyAuObDISsiTVh
 def make_Tving_ChannleGroup(YCEftNveGorqgwLpxyAuObDISsiTcl,YCEftNveGorqgwLpxyAuObDISsiTVd):
  YCEftNveGorqgwLpxyAuObDISsiTVU=[]
  i=0
  YCEftNveGorqgwLpxyAuObDISsiTVn=''
  for YCEftNveGorqgwLpxyAuObDISsiTVk in YCEftNveGorqgwLpxyAuObDISsiTVd:
   if i==0:YCEftNveGorqgwLpxyAuObDISsiTVn=YCEftNveGorqgwLpxyAuObDISsiTVk
   else:YCEftNveGorqgwLpxyAuObDISsiTVn+=',%s'%(YCEftNveGorqgwLpxyAuObDISsiTVk)
   i+=1
   if i>=YCEftNveGorqgwLpxyAuObDISsiTcl.LIMIT_TVINGEPG:
    YCEftNveGorqgwLpxyAuObDISsiTVU.append(YCEftNveGorqgwLpxyAuObDISsiTVn)
    i=0
    YCEftNveGorqgwLpxyAuObDISsiTVn=''
  if YCEftNveGorqgwLpxyAuObDISsiTVn!='':
   YCEftNveGorqgwLpxyAuObDISsiTVU.append(YCEftNveGorqgwLpxyAuObDISsiTVn)
  return YCEftNveGorqgwLpxyAuObDISsiTVU
 def Get_ChannelImg_Tving(YCEftNveGorqgwLpxyAuObDISsiTcl,chid_list):
  YCEftNveGorqgwLpxyAuObDISsiTVM={}
  try:
   YCEftNveGorqgwLpxyAuObDISsiTVF=YCEftNveGorqgwLpxyAuObDISsiTcl.Get_Now_Datetime().strftime('%Y%m%d')
   YCEftNveGorqgwLpxyAuObDISsiTVa =YCEftNveGorqgwLpxyAuObDISsiTca[6]['starttm'] 
   YCEftNveGorqgwLpxyAuObDISsiTVl =YCEftNveGorqgwLpxyAuObDISsiTca[6]['endtm']
   YCEftNveGorqgwLpxyAuObDISsiTVU=YCEftNveGorqgwLpxyAuObDISsiTcl.make_Tving_ChannleGroup(chid_list)
   for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTVU:
    YCEftNveGorqgwLpxyAuObDISsiTcU=YCEftNveGorqgwLpxyAuObDISsiTcl.API_TVING+'/v2/media/schedules'
    YCEftNveGorqgwLpxyAuObDISsiTcX={'pageNo':'1','pageSize':YCEftNveGorqgwLpxyAuObDISsiTaQ(YCEftNveGorqgwLpxyAuObDISsiTcl.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':YCEftNveGorqgwLpxyAuObDISsiTVF,'broadcastDate':YCEftNveGorqgwLpxyAuObDISsiTVF,'startBroadTime':YCEftNveGorqgwLpxyAuObDISsiTVa,'endBroadTime':YCEftNveGorqgwLpxyAuObDISsiTVl,'channelCode':YCEftNveGorqgwLpxyAuObDISsiTcH}
    YCEftNveGorqgwLpxyAuObDISsiTcX.update(YCEftNveGorqgwLpxyAuObDISsiTcl.Get_DefaultParams_Tving())
    YCEftNveGorqgwLpxyAuObDISsiTcn=YCEftNveGorqgwLpxyAuObDISsiTcl.callRequestCookies('Get',YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTcX,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB)
    YCEftNveGorqgwLpxyAuObDISsiTck=json.loads(YCEftNveGorqgwLpxyAuObDISsiTcn.text)
    if not('result' in YCEftNveGorqgwLpxyAuObDISsiTck['body']):return{}
    YCEftNveGorqgwLpxyAuObDISsiTcF=YCEftNveGorqgwLpxyAuObDISsiTck['body']['result']
    for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTcF:
     YCEftNveGorqgwLpxyAuObDISsiTVM[YCEftNveGorqgwLpxyAuObDISsiTcH['channel_code']]=YCEftNveGorqgwLpxyAuObDISsiTcl.API_TVINGIMG+YCEftNveGorqgwLpxyAuObDISsiTcH['image'][2]['url']
  except YCEftNveGorqgwLpxyAuObDISsiTah as exception:
   YCEftNveGorqgwLpxyAuObDISsiTaX(exception)
   return{}
  return YCEftNveGorqgwLpxyAuObDISsiTVM
 def Get_EpgInfo_Spotv(YCEftNveGorqgwLpxyAuObDISsiTcl,days=3,payyn=YCEftNveGorqgwLpxyAuObDISsiTaz):
  YCEftNveGorqgwLpxyAuObDISsiTVH ={}
  YCEftNveGorqgwLpxyAuObDISsiTcW=[]
  YCEftNveGorqgwLpxyAuObDISsiTVP =[]
  YCEftNveGorqgwLpxyAuObDISsiTVh=YCEftNveGorqgwLpxyAuObDISsiTcl.make_DateList(days=days,dateType='1')
  YCEftNveGorqgwLpxyAuObDISsiTaX(YCEftNveGorqgwLpxyAuObDISsiTVh)
  try:
   YCEftNveGorqgwLpxyAuObDISsiTcU=YCEftNveGorqgwLpxyAuObDISsiTcl.API_SPOTV+'/api/v2/channel'
   YCEftNveGorqgwLpxyAuObDISsiTcn=YCEftNveGorqgwLpxyAuObDISsiTcl.callRequestCookies('Get',YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTaB,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB)
   YCEftNveGorqgwLpxyAuObDISsiTck=json.loads(YCEftNveGorqgwLpxyAuObDISsiTcn.text)
   for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTck:
    YCEftNveGorqgwLpxyAuObDISsiTcP =YCEftNveGorqgwLpxyAuObDISsiTcH['videoId'].replace('ref:','')
    YCEftNveGorqgwLpxyAuObDISsiTVc={'channelid':YCEftNveGorqgwLpxyAuObDISsiTcP,'channelnm':YCEftNveGorqgwLpxyAuObDISsiTcl.xmlText(YCEftNveGorqgwLpxyAuObDISsiTcH['name']),'channelimg':YCEftNveGorqgwLpxyAuObDISsiTcH['logo'],'ott':'spotv'}
    if payyn==YCEftNveGorqgwLpxyAuObDISsiTaz or YCEftNveGorqgwLpxyAuObDISsiTcH['free']==YCEftNveGorqgwLpxyAuObDISsiTaz:
     YCEftNveGorqgwLpxyAuObDISsiTVH[YCEftNveGorqgwLpxyAuObDISsiTcH['id']]=YCEftNveGorqgwLpxyAuObDISsiTcP
     YCEftNveGorqgwLpxyAuObDISsiTcW.append(YCEftNveGorqgwLpxyAuObDISsiTVc)
  except YCEftNveGorqgwLpxyAuObDISsiTah as exception:
   YCEftNveGorqgwLpxyAuObDISsiTaX(exception)
   return[],[]
  try:
   for YCEftNveGorqgwLpxyAuObDISsiTVj in YCEftNveGorqgwLpxyAuObDISsiTVh:
    YCEftNveGorqgwLpxyAuObDISsiTcU=YCEftNveGorqgwLpxyAuObDISsiTcl.API_SPOTV+'/api/v2/program/'+YCEftNveGorqgwLpxyAuObDISsiTVj
    YCEftNveGorqgwLpxyAuObDISsiTcn=YCEftNveGorqgwLpxyAuObDISsiTcl.callRequestCookies('Get',YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTaB,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB)
    YCEftNveGorqgwLpxyAuObDISsiTck=json.loads(YCEftNveGorqgwLpxyAuObDISsiTcn.text)
    for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTck:
     if YCEftNveGorqgwLpxyAuObDISsiTVH.get(YCEftNveGorqgwLpxyAuObDISsiTcH['channelId'])==YCEftNveGorqgwLpxyAuObDISsiTaB:continue
     YCEftNveGorqgwLpxyAuObDISsiTVc={'channelid':YCEftNveGorqgwLpxyAuObDISsiTVH.get(YCEftNveGorqgwLpxyAuObDISsiTcH['channelId']),'title':YCEftNveGorqgwLpxyAuObDISsiTcl.xmlText(YCEftNveGorqgwLpxyAuObDISsiTcH['title']),'startTime':YCEftNveGorqgwLpxyAuObDISsiTcH['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':YCEftNveGorqgwLpxyAuObDISsiTcH['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     YCEftNveGorqgwLpxyAuObDISsiTVP.append(YCEftNveGorqgwLpxyAuObDISsiTVc)
    time.sleep(YCEftNveGorqgwLpxyAuObDISsiTcl.SLEEP_TIME)
  except YCEftNveGorqgwLpxyAuObDISsiTah as exception:
   YCEftNveGorqgwLpxyAuObDISsiTaX(exception)
   return[],[]
  return YCEftNveGorqgwLpxyAuObDISsiTcW,YCEftNveGorqgwLpxyAuObDISsiTVP
 def Get_EpgInfo_Wavve(YCEftNveGorqgwLpxyAuObDISsiTcl,days=2,exceptGroup=[]):
  YCEftNveGorqgwLpxyAuObDISsiTcW =[]
  YCEftNveGorqgwLpxyAuObDISsiTVP =[]
  YCEftNveGorqgwLpxyAuObDISsiTcm=[]
  YCEftNveGorqgwLpxyAuObDISsiTVm =YCEftNveGorqgwLpxyAuObDISsiTcl.Get_Now_Datetime()
  YCEftNveGorqgwLpxyAuObDISsiTVJ =YCEftNveGorqgwLpxyAuObDISsiTVm+datetime.timedelta(hours=-2)
  YCEftNveGorqgwLpxyAuObDISsiTMc =YCEftNveGorqgwLpxyAuObDISsiTVm+datetime.timedelta(days=(days-1))
  if YCEftNveGorqgwLpxyAuObDISsiTaK(YCEftNveGorqgwLpxyAuObDISsiTVJ.strftime('%H'))<=3:
   YCEftNveGorqgwLpxyAuObDISsiTMV=YCEftNveGorqgwLpxyAuObDISsiTVJ.strftime('%Y-%m-%d 00:00')
  else:
   YCEftNveGorqgwLpxyAuObDISsiTMV=YCEftNveGorqgwLpxyAuObDISsiTVJ.strftime('%Y-%m-%d %H:00')
  YCEftNveGorqgwLpxyAuObDISsiTMa =YCEftNveGorqgwLpxyAuObDISsiTMc.strftime('%Y-%m-%d 24:00')
  if exceptGroup!=[]:
   YCEftNveGorqgwLpxyAuObDISsiTcm=YCEftNveGorqgwLpxyAuObDISsiTcl.Get_ChannelList_WavveExcept(exceptGroup)
  try:
   YCEftNveGorqgwLpxyAuObDISsiTcU=YCEftNveGorqgwLpxyAuObDISsiTcl.API_WAVVE+'/live/epgs'
   YCEftNveGorqgwLpxyAuObDISsiTcX={'limit':YCEftNveGorqgwLpxyAuObDISsiTaQ(YCEftNveGorqgwLpxyAuObDISsiTcl.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':YCEftNveGorqgwLpxyAuObDISsiTMV,'enddatetime':YCEftNveGorqgwLpxyAuObDISsiTMa}
   YCEftNveGorqgwLpxyAuObDISsiTcX.update(YCEftNveGorqgwLpxyAuObDISsiTcl.Get_DefaultParams_Wavve())
   YCEftNveGorqgwLpxyAuObDISsiTcn=YCEftNveGorqgwLpxyAuObDISsiTcl.callRequestCookies('Get',YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTcX,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB)
   YCEftNveGorqgwLpxyAuObDISsiTck=json.loads(YCEftNveGorqgwLpxyAuObDISsiTcn.text)
   YCEftNveGorqgwLpxyAuObDISsiTMl=YCEftNveGorqgwLpxyAuObDISsiTck['list']
   for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTMl:
    YCEftNveGorqgwLpxyAuObDISsiTVc={'channelid':YCEftNveGorqgwLpxyAuObDISsiTcH['channelid'],'channelnm':YCEftNveGorqgwLpxyAuObDISsiTcl.xmlText(YCEftNveGorqgwLpxyAuObDISsiTcH['channelname']),'channelimg':YCEftNveGorqgwLpxyAuObDISsiTcl.HTTPTAG+YCEftNveGorqgwLpxyAuObDISsiTcH['channelimage'],'ott':'wavve'}
    if YCEftNveGorqgwLpxyAuObDISsiTcH['channelid']not in YCEftNveGorqgwLpxyAuObDISsiTcm:
     YCEftNveGorqgwLpxyAuObDISsiTcW.append(YCEftNveGorqgwLpxyAuObDISsiTVc)
    for YCEftNveGorqgwLpxyAuObDISsiTMB in YCEftNveGorqgwLpxyAuObDISsiTcH['list']:
     YCEftNveGorqgwLpxyAuObDISsiTVc={'channelid':YCEftNveGorqgwLpxyAuObDISsiTcH['channelid'],'title':YCEftNveGorqgwLpxyAuObDISsiTcl.xmlText(YCEftNveGorqgwLpxyAuObDISsiTMB['title']),'startTime':YCEftNveGorqgwLpxyAuObDISsiTMB['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':YCEftNveGorqgwLpxyAuObDISsiTMB['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if YCEftNveGorqgwLpxyAuObDISsiTcH['channelid']not in YCEftNveGorqgwLpxyAuObDISsiTcm and YCEftNveGorqgwLpxyAuObDISsiTMB['starttime']!=YCEftNveGorqgwLpxyAuObDISsiTMB['endtime']:
      YCEftNveGorqgwLpxyAuObDISsiTVP.append(YCEftNveGorqgwLpxyAuObDISsiTVc)
  except YCEftNveGorqgwLpxyAuObDISsiTah as exception:
   YCEftNveGorqgwLpxyAuObDISsiTaX(exception)
   return[],[]
  YCEftNveGorqgwLpxyAuObDISsiTMd=YCEftNveGorqgwLpxyAuObDISsiTam(YCEftNveGorqgwLpxyAuObDISsiTVP)
  for i in(YCEftNveGorqgwLpxyAuObDISsiTaW(1,YCEftNveGorqgwLpxyAuObDISsiTMd)):
   if YCEftNveGorqgwLpxyAuObDISsiTaK(YCEftNveGorqgwLpxyAuObDISsiTVP[i-1]['endTime'])+1==YCEftNveGorqgwLpxyAuObDISsiTaK(YCEftNveGorqgwLpxyAuObDISsiTVP[i]['startTime'])and YCEftNveGorqgwLpxyAuObDISsiTVP[i-1]['channelid']==YCEftNveGorqgwLpxyAuObDISsiTVP[i]['channelid']:
    YCEftNveGorqgwLpxyAuObDISsiTVP[i-1]['endTime']=YCEftNveGorqgwLpxyAuObDISsiTVP[i]['startTime']
  return YCEftNveGorqgwLpxyAuObDISsiTcW,YCEftNveGorqgwLpxyAuObDISsiTVP
 def Get_EpgInfo_Tving(YCEftNveGorqgwLpxyAuObDISsiTcl,days=2):
  YCEftNveGorqgwLpxyAuObDISsiTcW=[]
  YCEftNveGorqgwLpxyAuObDISsiTVP =[]
  YCEftNveGorqgwLpxyAuObDISsiTMQ =[]
  YCEftNveGorqgwLpxyAuObDISsiTMh =YCEftNveGorqgwLpxyAuObDISsiTcl.make_EpgDatetime_Tving(days=days)
  YCEftNveGorqgwLpxyAuObDISsiTcW =YCEftNveGorqgwLpxyAuObDISsiTcl.Get_ChannelList_Tving()
  YCEftNveGorqgwLpxyAuObDISsiTMX=[]
  for i in YCEftNveGorqgwLpxyAuObDISsiTaW(YCEftNveGorqgwLpxyAuObDISsiTam(YCEftNveGorqgwLpxyAuObDISsiTcW)):
   YCEftNveGorqgwLpxyAuObDISsiTcW[i]['channelnm']=YCEftNveGorqgwLpxyAuObDISsiTcl.xmlText(YCEftNveGorqgwLpxyAuObDISsiTcW[i]['channelnm'])
   YCEftNveGorqgwLpxyAuObDISsiTMX.append(YCEftNveGorqgwLpxyAuObDISsiTcW[i]['channelid'])
  YCEftNveGorqgwLpxyAuObDISsiTMz=YCEftNveGorqgwLpxyAuObDISsiTcl.make_Tving_ChannleGroup(YCEftNveGorqgwLpxyAuObDISsiTMX)
  try:
   YCEftNveGorqgwLpxyAuObDISsiTcU=YCEftNveGorqgwLpxyAuObDISsiTcl.API_TVING+'/v2/media/schedules'
   for YCEftNveGorqgwLpxyAuObDISsiTMK in YCEftNveGorqgwLpxyAuObDISsiTMh:
    for YCEftNveGorqgwLpxyAuObDISsiTMW in YCEftNveGorqgwLpxyAuObDISsiTMz:
     YCEftNveGorqgwLpxyAuObDISsiTcX={'pageNo':'1','pageSize':YCEftNveGorqgwLpxyAuObDISsiTaQ(YCEftNveGorqgwLpxyAuObDISsiTcl.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':YCEftNveGorqgwLpxyAuObDISsiTMK['ndate'],'broadcastDate':YCEftNveGorqgwLpxyAuObDISsiTMK['ndate'],'startBroadTime':YCEftNveGorqgwLpxyAuObDISsiTMK['starttm'],'endBroadTime':YCEftNveGorqgwLpxyAuObDISsiTMK['endtm'],'channelCode':YCEftNveGorqgwLpxyAuObDISsiTMW}
     YCEftNveGorqgwLpxyAuObDISsiTcX.update(YCEftNveGorqgwLpxyAuObDISsiTcl.Get_DefaultParams_Tving())
     YCEftNveGorqgwLpxyAuObDISsiTcn=YCEftNveGorqgwLpxyAuObDISsiTcl.callRequestCookies('Get',YCEftNveGorqgwLpxyAuObDISsiTcU,payload=YCEftNveGorqgwLpxyAuObDISsiTaB,params=YCEftNveGorqgwLpxyAuObDISsiTcX,headers=YCEftNveGorqgwLpxyAuObDISsiTaB,cookies=YCEftNveGorqgwLpxyAuObDISsiTaB)
     YCEftNveGorqgwLpxyAuObDISsiTck=json.loads(YCEftNveGorqgwLpxyAuObDISsiTcn.text)
     YCEftNveGorqgwLpxyAuObDISsiTcF=YCEftNveGorqgwLpxyAuObDISsiTck['body']['result']
     for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTcF:
      if 'schedules' not in YCEftNveGorqgwLpxyAuObDISsiTcH:continue
      if YCEftNveGorqgwLpxyAuObDISsiTcH['schedules']==YCEftNveGorqgwLpxyAuObDISsiTaB:continue
      for YCEftNveGorqgwLpxyAuObDISsiTMm in YCEftNveGorqgwLpxyAuObDISsiTcH['schedules']:
       YCEftNveGorqgwLpxyAuObDISsiTVc={'channelid':YCEftNveGorqgwLpxyAuObDISsiTMm['schedule_code'],'title':YCEftNveGorqgwLpxyAuObDISsiTcl.xmlText(YCEftNveGorqgwLpxyAuObDISsiTMm['program']['name']['ko']),'startTime':YCEftNveGorqgwLpxyAuObDISsiTaQ(YCEftNveGorqgwLpxyAuObDISsiTMm['broadcast_start_time']),'endTime':YCEftNveGorqgwLpxyAuObDISsiTaQ(YCEftNveGorqgwLpxyAuObDISsiTMm['broadcast_end_time']),'ott':'tving'}
       YCEftNveGorqgwLpxyAuObDISsiTMR=YCEftNveGorqgwLpxyAuObDISsiTMm['schedule_code']+YCEftNveGorqgwLpxyAuObDISsiTaQ(YCEftNveGorqgwLpxyAuObDISsiTMm['broadcast_start_time'])
       if YCEftNveGorqgwLpxyAuObDISsiTMR in YCEftNveGorqgwLpxyAuObDISsiTMQ:continue
       YCEftNveGorqgwLpxyAuObDISsiTMQ.append(YCEftNveGorqgwLpxyAuObDISsiTMR)
       YCEftNveGorqgwLpxyAuObDISsiTVP.append(YCEftNveGorqgwLpxyAuObDISsiTVc)
     time.sleep(YCEftNveGorqgwLpxyAuObDISsiTcl.SLEEP_TIME)
  except YCEftNveGorqgwLpxyAuObDISsiTah as exception:
   YCEftNveGorqgwLpxyAuObDISsiTaX(exception)
   return[],[]
  return YCEftNveGorqgwLpxyAuObDISsiTcW,YCEftNveGorqgwLpxyAuObDISsiTVP
 def make_getGenre(YCEftNveGorqgwLpxyAuObDISsiTcl,YCEftNveGorqgwLpxyAuObDISsiTcP,YCEftNveGorqgwLpxyAuObDISsiTac):
  try:
   YCEftNveGorqgwLpxyAuObDISsiTVB=YCEftNveGorqgwLpxyAuObDISsiTcl.INIT_CHANNEL.get(YCEftNveGorqgwLpxyAuObDISsiTcP+'.'+YCEftNveGorqgwLpxyAuObDISsiTac).get('genre')
  except:
   YCEftNveGorqgwLpxyAuObDISsiTVB='-'
  return YCEftNveGorqgwLpxyAuObDISsiTVB
 def make_base_allchannel_py(YCEftNveGorqgwLpxyAuObDISsiTcl):
  YCEftNveGorqgwLpxyAuObDISsiTMU =[]
  YCEftNveGorqgwLpxyAuObDISsiTMn=[]
  YCEftNveGorqgwLpxyAuObDISsiTMk=YCEftNveGorqgwLpxyAuObDISsiTaR()
  YCEftNveGorqgwLpxyAuObDISsiTVc=YCEftNveGorqgwLpxyAuObDISsiTcl.Get_ChannelList_Wavve()
  YCEftNveGorqgwLpxyAuObDISsiTMU.extend(YCEftNveGorqgwLpxyAuObDISsiTVc)
  YCEftNveGorqgwLpxyAuObDISsiTVc=YCEftNveGorqgwLpxyAuObDISsiTcl.Get_ChannelList_Tving()
  YCEftNveGorqgwLpxyAuObDISsiTMU.extend(YCEftNveGorqgwLpxyAuObDISsiTVc)
  YCEftNveGorqgwLpxyAuObDISsiTVc=YCEftNveGorqgwLpxyAuObDISsiTcl.Get_ChannelList_Spotv()
  YCEftNveGorqgwLpxyAuObDISsiTMU.extend(YCEftNveGorqgwLpxyAuObDISsiTVc)
  YCEftNveGorqgwLpxyAuObDISsiTaX('1')
  for i in YCEftNveGorqgwLpxyAuObDISsiTaW(YCEftNveGorqgwLpxyAuObDISsiTam(YCEftNveGorqgwLpxyAuObDISsiTMU)):
   if YCEftNveGorqgwLpxyAuObDISsiTMU[i]['genrenm']=='-':
    if YCEftNveGorqgwLpxyAuObDISsiTMU[i]['ott']=='wavve':
     YCEftNveGorqgwLpxyAuObDISsiTVB=YCEftNveGorqgwLpxyAuObDISsiTcl.Get_ChanneGenrename_Wavve(YCEftNveGorqgwLpxyAuObDISsiTMU[i]['channelid'])
     if YCEftNveGorqgwLpxyAuObDISsiTVB not in YCEftNveGorqgwLpxyAuObDISsiTMk:YCEftNveGorqgwLpxyAuObDISsiTMk.add(YCEftNveGorqgwLpxyAuObDISsiTVB)
     time.sleep(YCEftNveGorqgwLpxyAuObDISsiTcl.SLEEP_TIME)
    elif YCEftNveGorqgwLpxyAuObDISsiTMU[i]['ott']=='spotv':
     YCEftNveGorqgwLpxyAuObDISsiTVB='스포츠'
    else:
     YCEftNveGorqgwLpxyAuObDISsiTVB='-'
    YCEftNveGorqgwLpxyAuObDISsiTMU[i]['genrenm']=YCEftNveGorqgwLpxyAuObDISsiTVB
   else:
    if YCEftNveGorqgwLpxyAuObDISsiTMU[i]['genrenm']not in YCEftNveGorqgwLpxyAuObDISsiTMk:YCEftNveGorqgwLpxyAuObDISsiTMk.add(YCEftNveGorqgwLpxyAuObDISsiTMU[i]['genrenm'])
  YCEftNveGorqgwLpxyAuObDISsiTMk.add('-')
  YCEftNveGorqgwLpxyAuObDISsiTaX('2')
  for YCEftNveGorqgwLpxyAuObDISsiTMF in YCEftNveGorqgwLpxyAuObDISsiTMk:
   for YCEftNveGorqgwLpxyAuObDISsiTMH in YCEftNveGorqgwLpxyAuObDISsiTMU:
    if YCEftNveGorqgwLpxyAuObDISsiTMH['genrenm']==YCEftNveGorqgwLpxyAuObDISsiTMF:
     YCEftNveGorqgwLpxyAuObDISsiTMn.append(YCEftNveGorqgwLpxyAuObDISsiTMH)
  for YCEftNveGorqgwLpxyAuObDISsiTMH in YCEftNveGorqgwLpxyAuObDISsiTMU:
   if YCEftNveGorqgwLpxyAuObDISsiTMH['genrenm']not in YCEftNveGorqgwLpxyAuObDISsiTMk:
    YCEftNveGorqgwLpxyAuObDISsiTMP.append(YCEftNveGorqgwLpxyAuObDISsiTMH)
  YCEftNveGorqgwLpxyAuObDISsiTaX('3')
  YCEftNveGorqgwLpxyAuObDISsiTMj='d:\\job\\channelgenre.json'
  if os.path.isfile(YCEftNveGorqgwLpxyAuObDISsiTMj):os.remove(YCEftNveGorqgwLpxyAuObDISsiTMj)
  fp=YCEftNveGorqgwLpxyAuObDISsiTaU(YCEftNveGorqgwLpxyAuObDISsiTMj,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  YCEftNveGorqgwLpxyAuObDISsiTMJ=YCEftNveGorqgwLpxyAuObDISsiTam(YCEftNveGorqgwLpxyAuObDISsiTMn)
  i=0
  for YCEftNveGorqgwLpxyAuObDISsiTcH in YCEftNveGorqgwLpxyAuObDISsiTMn:
   i+=1
   YCEftNveGorqgwLpxyAuObDISsiTcP =YCEftNveGorqgwLpxyAuObDISsiTcH['channelid']
   YCEftNveGorqgwLpxyAuObDISsiTcj =YCEftNveGorqgwLpxyAuObDISsiTcH['channelnm']
   YCEftNveGorqgwLpxyAuObDISsiTac =YCEftNveGorqgwLpxyAuObDISsiTcH['ott']
   YCEftNveGorqgwLpxyAuObDISsiTaV ='%s.%s'%(YCEftNveGorqgwLpxyAuObDISsiTcP,YCEftNveGorqgwLpxyAuObDISsiTac)
   YCEftNveGorqgwLpxyAuObDISsiTVB =YCEftNveGorqgwLpxyAuObDISsiTcH['genrenm']
   YCEftNveGorqgwLpxyAuObDISsiTaM='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(YCEftNveGorqgwLpxyAuObDISsiTaV,YCEftNveGorqgwLpxyAuObDISsiTcj,YCEftNveGorqgwLpxyAuObDISsiTVB)
   if i<YCEftNveGorqgwLpxyAuObDISsiTMJ:
    fp.write(YCEftNveGorqgwLpxyAuObDISsiTaM+',\n')
   else:
    fp.write(YCEftNveGorqgwLpxyAuObDISsiTaM+'\n')
  fp.write('}\n')
  fp.close()
  return YCEftNveGorqgwLpxyAuObDISsiTMk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
