_A7='pvr.iptvsimple'
_A6='  </programme>\n\n'
_A5='    <title lang="kr">%s</title>\n'
_A4='startTime'
_A3='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'
_A2='  </channel>\n\n'
_A1='    <icon src="%s" />\n'
_A0='    <display-name>%s</display-name>\n'
_z='  <channel id="%s.%s">\n'
_y='\n</tv>\n'
_x='<tv generator-info-name="boritv_epg">\n\n'
_w='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
_v='<?xml version="1.0" encoding="UTF-8"?>\n'
_u='#EXTM3U'
_t='channelurl'
_s='plugin://plugin.video.broadcastm/?mode=LIVE&company=sbs&channlCode=%s\n'
_r='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'
_q='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'
_p='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'
_o='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'
_n='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'
_m='%s (%s)'
_l='ADD_EPG'
_k='DEL_M3U'
_j='-----------------'
_i='라디오/음악'
_h='icon'
_g='anything'
_f='pjy'
_e='channelimg'
_d='channelnm'
_c='#EXTM3U\n'
_b='genrenm'
_a='custom'
_Z='list'
_Y='int'
_X='ott'
_W='channelid'
_V='XXX'
_U='w'
_T='N'
_S='string'
_R='ADD_M3U'
_Q=None
_P='bc_sbs'
_O='spotv'
_N='tving'
_M='wavve'
_L='sName'
_K='true'
_J='sType'
_I='mode'
_H='title'
_G='type'
_F='utf-8'
_E='func'
_D='all'
_C='utf8'
_B=True
_A=False
__author__='NightRain'
import os,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,sys,datetime,time,urllib
MAIN_GROUP=[{_H:'*** 간단설명 (개별 OTT 애드온 필수) ***',_I:_V},{_H:'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)',_I:_V},{_H:'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)',_I:_V},{_H:_j,_I:_V},{_H:'-> M3U 파일 초기화/삭제',_I:_k},{_H:'     - M3U 추가 (웨이브)',_I:_R,_J:_M,_L:'웨이브'},{_H:'     - M3U 추가 (티빙)',_I:_R,_J:_N,_L:'티빙'},{_H:'     - M3U 추가 (스포티비)',_I:_R,_J:_O,_L:'스포티비'},{_H:'     - M3U 추가 (SBS)',_I:_R,_J:_P,_L:'SBS'},{_H:'     - M3U 추가 (사용자 m3u)',_I:_R,_J:_a,_L:'사용자 m3u 파일'},{_H:'-> M3U (삭제후 일괄생성)',_I:_R,_J:_D,_L:'전체'},{_H:_j,_I:_V},{_H:'-> EPG 생성 (삭제후 일괄생성)',_I:_l,_J:_D,_L:'전체'}]
INFO_CONVERT_KEY={_H:{_E:'setTitle',_G:_S},'plot':{_E:'setPlot',_G:_S},'mpaa':{_E:'setMpaa',_G:_S},'mediatype':{_E:'setMediaType',_G:_S},'tvshowtitle':{_E:'setTvShowTitle',_G:_S},'premiered':{_E:'setPremiered',_G:_S},'aired':{_E:'setFirstAired',_G:_S},'year':{_E:'setYear',_G:_Y},'duration':{_E:'setDuration',_G:_Y},'episode':{_E:'setEpisode',_G:_Y},'season':{_E:'setSeason',_G:_Y},'studio':{_E:'setStudios',_G:_Z},'genre':{_E:'setGenres',_G:_Z},'country':{_E:'setCountries',_G:_Z},'cast':{_E:'setCast',_G:'actor'},'director':{_E:'setDirectors',_G:_Z}}
__addon__=xbmcaddon.Addon()
__language__=__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
EPGDATE_FILE_NAME=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class BoritvRun:
	def __init__(self,in_addonurl,in_handle,in_params):self._addon_url=in_addonurl;self._addon_handle=in_handle;self.main_params=in_params;self.M3U_FILE_PATH='';self.M3U_FILE_NAME='';self.M3U_ONWAVVE=_A;self.M3U_ONTVING=_A;self.M3U_ONSPOTV=_A;self.M3U_BC_SBS=_A;self.M3U_PJY=_A;self.M3U_ONWAVVERADIO=_A;self.M3U_ONWAVVEHOME=_A;self.M3U_DISPLAYNM=_A;self.M3U_AUTORESTART=_A;self.M3U_CUSTOM_LIST=[];self.BoritvObj=Boritv()
	def addon_noti(self,sting):
		try:dialog=xbmcgui.Dialog();dialog.notification(__addonname__,sting)
		except:_Q
	def addon_log(self,string):
		try:log_message=string.encode(_F,'ignore')
		except:log_message='addonException: addon_log'
		level=xbmc.LOGINFO;xbmc.log('[%s-%s]: %s'%(__addonid__,__version__,log_message),level=level)
	def get_keyboard_input(self,title):
		input_text=_Q;kb=xbmc.Keyboard();kb.setHeading(title);xbmc.sleep(1000);kb.doModal()
		if kb.isConfirmed():input_text=kb.getText()
		return input_text
	def add_dir(self,label,sublabel='',img='',infoLabels=_Q,isFolder=_B,params='',isLink=_A,ContextMenu=_Q):
		url='%s?%s'%(self._addon_url,urllib.parse.urlencode(params))
		if sublabel:title='%s < %s >'%(label,sublabel)
		else:title=label
		if not img:img='DefaultFolder.png'
		listitem=xbmcgui.ListItem(title);listitem.setArt({'thumbnailImage':img,_h:img,'poster':img})
		if self.BoritvObj.KodiVersion>=20:
			if infoLabels:self.Set_InfoTag(listitem.getVideoInfoTag(),infoLabels)
		elif infoLabels:listitem.setInfo('Video',infoLabels)
		if not isFolder and not isLink:listitem.setProperty('IsPlayable',_K)
		if ContextMenu:listitem.addContextMenuItems(ContextMenu)
		xbmcplugin.addDirectoryItem(self._addon_handle,url,listitem,isFolder)
	def Set_InfoTag(self,video_InfoTag,infoLabels):
		for(key,value)in infoLabels.items():
			if INFO_CONVERT_KEY[key][_G]==_S:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_E])(value)
			elif INFO_CONVERT_KEY[key][_G]==_Y:
				if type(value)==int:intValue=int(value)
				else:intValue=0
				getattr(video_InfoTag,INFO_CONVERT_KEY[key][_E])(intValue)
			elif INFO_CONVERT_KEY[key][_G]=='actor':
				if value!=[]:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_E])([xbmc.Actor(name)for name in value])
			elif INFO_CONVERT_KEY[key][_G]==_Z:
				if type(value)==list:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_E])(value)
				else:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_E])([value])
	def make_M3u_Filename(self,tempyn=_A):
		if tempyn:return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
		else:return self.M3U_FILE_PATH+self.M3U_FILE_NAME+'.m3u'
	def make_Epg_Filename(self,tempyn=_A):
		if tempyn:return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
		else:return self.M3U_FILE_PATH+self.M3U_FILE_NAME+'.xml'
	def dp_Main_List(self):
		for main_group in MAIN_GROUP:
			title=main_group.get(_H);icon_img='';params={_I:main_group.get(_I),_J:main_group.get(_J),_L:main_group.get(_L)};infoLabels={_H:title,'plot':title}
			if main_group.get(_I)==_V:isFolder=_A;isLink=_B
			else:isFolder=_B;isLink=_A
			addYn=_B
			if main_group.get(_I)==_R:
				if main_group.get(_J)==_M and self.M3U_ONWAVVE==_A:addYn=_A
				if main_group.get(_J)==_N and self.M3U_ONTVING==_A:addYn=_A
				if main_group.get(_J)==_O and self.M3U_ONSPOTV==_A:addYn=_A
				if main_group.get(_J)==_P and self.M3U_BC_SBS==_A:addYn=_A
				if main_group.get(_J)==_a and self.M3U_CUSTOM_LIST==[]:addYn=_A
			if addYn==_B:
				if _h in main_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',main_group.get(_h))
				self.add_dir(title,sublabel='',img=icon_img,infoLabels=infoLabels,isFolder=isFolder,params=params,isLink=isLink)
		if len(MAIN_GROUP)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_B)
	def dp_Delete_M3u(self,args):
		dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30903).encode(_C),__language__(30904).encode(_C))
		if ret==_A:sys.exit()
		filename=self.make_M3u_Filename(tempyn=_A)
		if xbmcvfs.exists(filename):
			if xbmcvfs.delete(filename)==_A:self.addon_noti(__language__(30910).encode(_F));return
		self.addon_noti(__language__(30905).encode(_F))
	def dp_MakeAdd_M3u_old(self,args):
		sType=args.get(_J);sName=args.get(_L);dialog=xbmcgui.Dialog();ret=dialog.yesno((sName+__language__(30906)).encode(_C),__language__(30907).encode(_C))
		if ret==_A:sys.exit()
		GN_LIST=[];SORT_LIST=[];filename=self.make_M3u_Filename(tempyn=_B)
		if os.path.isfile(filename):os.remove(filename)
		if sType==_D:
			filename=self.make_M3u_Filename(tempyn=_A)
			if xbmcvfs.exists(filename):
				if xbmcvfs.delete(filename)==_A:self.addon_noti(__language__(30910).encode(_F));return
		else:
			asis_filename=self.make_M3u_Filename(tempyn=_A)
			if xbmcvfs.exists(asis_filename):tobe_filename=self.make_M3u_Filename(tempyn=_B);xbmcvfs.copy(asis_filename,tobe_filename)
		if self.M3U_PJY:
			temp_list=self.BoritvObj.Get_ChannelList_pjy()
			if len(temp_list)!=0:GN_LIST.extend(temp_list)
			self.addon_log('pjy cnt ----> '+str(len(temp_list)))
		if(sType==_M or sType==_D)and self.M3U_ONWAVVE:
			temp_list=self.BoritvObj.Get_ChannelList_Wavve(exceptGroup=self.make_EexceptGroup_Wavve())
			if len(temp_list)!=0:GN_LIST.extend(temp_list)
			self.addon_log('wavve cnt ----> '+str(len(temp_list)))
		if(sType==_N or sType==_D)and self.M3U_ONTVING:
			temp_list=self.BoritvObj.Get_ChannelList_Tving()
			if len(temp_list)!=0:GN_LIST.extend(temp_list)
			self.addon_log('tving cnt ----> '+str(len(temp_list)))
		if(sType==_O or sType==_D)and self.M3U_ONSPOTV:
			temp_list=self.BoritvObj.Get_ChannelList_Spotv()
			if len(temp_list)!=0:GN_LIST.extend(temp_list)
			self.addon_log('spotv cnt ----> '+str(len(temp_list)))
		if(sType==_P or sType==_D)and self.M3U_BC_SBS:
			temp_list=self.BoritvObj.Get_ChannelList_BroadCast_SBS()
			if len(temp_list)!=0:GN_LIST.extend(temp_list)
			self.addon_log('bc_sbs cnt ----> '+str(len(temp_list)))
		if len(GN_LIST)==0 and self.M3U_CUSTOM_LIST==[]:self.addon_noti(__language__(30909).encode(_C));return
		for i_genre in self.BoritvObj.INIT_GENRESORT:
			for i_list in GN_LIST:
				if i_list[_b]==i_genre:SORT_LIST.append(i_list)
		for i_list in GN_LIST:
			if i_list[_b]not in self.BoritvObj.INIT_GENRESORT:SORT_LIST.append(i_list)
		try:
			if len(GN_LIST)>0:
				filename=self.make_M3u_Filename(tempyn=_B)
				if os.path.isfile(filename):fp=open(filename,'a',-1,_F)
				else:fp=open(filename,_U,-1,_F);fp.write(_c)
				for gn_list in SORT_LIST:
					channelid=gn_list[_W];channelnm=gn_list[_d];channelimg=gn_list[_e];ott=gn_list[_X];tvgid='%s.%s'%(channelid,ott);channelgenre=gn_list[_b]
					if self.M3U_DISPLAYNM:channelnm=_m%(channelnm,ott)
					if channelgenre==_i:m3uinfo=_n%(tvgid,channelnm,channelgenre,channelimg,channelnm)
					else:m3uinfo=_o%(tvgid,channelnm,channelgenre,channelimg,channelnm)
					if ott==_M:m3uurl=_p%channelid
					elif ott==_N:m3uurl=_q%channelid
					elif ott==_O:m3uurl=_r%channelid
					elif ott=='samsung':m3uurl='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%channelid
					elif ott==_P:m3uurl=_s%channelid
					elif ott==_f:m3uurl='{}\n'.format(gn_list[_t])
					fp.write(m3uinfo);fp.write(m3uurl)
				fp.close()
		except:self.addon_noti(__language__(30910).encode(_C));return
		try:
			if(sType==_a or sType==_D)and self.M3U_CUSTOM_LIST!=[]:
				filename=self.make_M3u_Filename(tempyn=_B)
				if os.path.isfile(filename):fp=open(filename,'a',-1,_F)
				else:fp=open(filename,_U,-1,_F);fp.write(_c)
				for custom_file in self.M3U_CUSTOM_LIST:
					file_lines=self.customEpg_FileRead(custom_file)
					for i_line in file_lines:
						i_line=i_line.strip()
						if i_line not in['',_u]:fp.write(i_line+'\n')
			fp.close()
		except:self.addon_noti(__language__(30910).encode(_C));return
		asis_filename=self.make_M3u_Filename(tempyn=_B);tobe_filename=self.make_M3u_Filename(tempyn=_A)
		if xbmcvfs.copy(asis_filename,tobe_filename):self.addon_noti((sName+' '+__language__(30908)).encode(_C))
		else:self.addon_noti(__language__(30910).encode(_F))
	def dp_MakeAdd_M3u(self,args):
		sType=args.get(_J);sName=args.get(_L);dialog=xbmcgui.Dialog();ret=dialog.yesno((sName+__language__(30906)).encode(_C),__language__(30907).encode(_C))
		if ret==_A:sys.exit()
		filename=self.make_M3u_Filename(tempyn=_B)
		if os.path.isfile(filename):os.remove(filename)
		if sType==_D:
			filename=self.make_M3u_Filename(tempyn=_A)
			if xbmcvfs.exists(filename):
				if xbmcvfs.delete(filename)==_A:self.addon_noti(__language__(30910).encode(_F));return
		else:
			asis_filename=self.make_M3u_Filename(tempyn=_A)
			if xbmcvfs.exists(asis_filename):tobe_filename=self.make_M3u_Filename(tempyn=_B);xbmcvfs.copy(asis_filename,tobe_filename)
		OTT_LIST=[];EXCEPT_GROUP=self.make_EexceptGroup_Wavve()
		if(sType==_f or sType==_D)and self.M3U_PJY:OTT_LIST.append(_f)
		if(sType==_M or sType==_D)and self.M3U_ONWAVVE:OTT_LIST.append(_M)
		if(sType==_N or sType==_D)and self.M3U_ONTVING:OTT_LIST.append(_N)
		if(sType==_O or sType==_D)and self.M3U_ONSPOTV:OTT_LIST.append(_O)
		if(sType==_P or sType==_D)and self.M3U_BC_SBS:OTT_LIST.append(_P)
		if len(OTT_LIST)==0 and self.M3U_CUSTOM_LIST==[]:self.addon_noti(__language__(30909).encode(_C));return
		channel_list=self.BoritvObj.git_make_channel_list(OTT_LIST,EXCEPT_GROUP)
		try:
			if len(channel_list)>0:
				filename=self.make_M3u_Filename(tempyn=_B)
				if os.path.isfile(filename):fp=open(filename,'a',-1,_F)
				else:fp=open(filename,_U,-1,_F);fp.write(_c)
				for gn_list in channel_list:
					channelid=gn_list[_W];channelnm=gn_list[_d];channelimg=gn_list[_e];ott=gn_list[_X];tvgid='%s.%s'%(channelid,ott);channelgenre=gn_list[_b]
					if self.M3U_DISPLAYNM:channelnm=_m%(channelnm,ott)
					if channelgenre==_i:m3uinfo=_n%(tvgid,channelnm,channelgenre,channelimg,channelnm)
					else:m3uinfo=_o%(tvgid,channelnm,channelgenre,channelimg,channelnm)
					if ott==_M:m3uurl=_p%channelid
					elif ott==_N:m3uurl=_q%channelid
					elif ott==_O:m3uurl=_r%channelid
					elif ott==_P:m3uurl=_s%channelid
					elif ott==_f:m3uurl='{}\n'.format(gn_list[_t])
					fp.write(m3uinfo);fp.write(m3uurl)
				fp.close()
		except:self.addon_noti(__language__(30910).encode(_C));return
		try:
			if(sType==_a or sType==_D)and self.M3U_CUSTOM_LIST!=[]:
				filename=self.make_M3u_Filename(tempyn=_B)
				if os.path.isfile(filename):fp=open(filename,'a',-1,_F)
				else:fp=open(filename,_U,-1,_F);fp.write(_c)
				for custom_file in self.M3U_CUSTOM_LIST:
					file_lines=self.customEpg_FileRead(custom_file)
					for i_line in file_lines:
						i_line=i_line.strip()
						if i_line not in['',_u]:fp.write(i_line+'\n')
			fp.close()
		except:self.addon_noti(__language__(30910).encode(_C));return
		asis_filename=self.make_M3u_Filename(tempyn=_B);tobe_filename=self.make_M3u_Filename(tempyn=_A)
		if xbmcvfs.copy(asis_filename,tobe_filename):self.addon_noti((sName+' '+__language__(30908)).encode(_C))
		else:self.addon_noti(__language__(30910).encode(_F))
	def customEpg_FileList(self):
		file_list=[]
		if __addon__.getSetting('custom01on')==_K:file_list.append(__addon__.getSetting('custom01nm'))
		if __addon__.getSetting('custom02on')==_K:file_list.append(__addon__.getSetting('custom02nm'))
		if __addon__.getSetting('custom03on')==_K:file_list.append(__addon__.getSetting('custom03nm'))
		if __addon__.getSetting('custom04on')==_K:file_list.append(__addon__.getSetting('custom04nm'))
		if __addon__.getSetting('custom05on')==_K:file_list.append(__addon__.getSetting('custom05nm'))
		return file_list
	def customEpg_FileRead(self,source_filename):
		try:
			temp_filename=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
			if os.path.isfile(temp_filename):os.remove(temp_filename)
			xbmcvfs.copy(source_filename,temp_filename);fp=open(temp_filename,'r',-1,_F);lines=fp.readlines()
		except:return[]
		return lines
	def dp_Make_Epg_old(self,args):
		sType=args.get(_J);sName=args.get(_L);sNoti=args.get('sNoti')
		if sNoti!=_T:
			dialog=xbmcgui.Dialog();ret=dialog.yesno((sName+__language__(30911)).encode(_C),__language__(30907).encode(_C))
			if ret==_A:sys.exit()
		CH_LIST=[];EPG_LIST=[]
		if(sType==_M or sType==_D)and self.M3U_ONWAVVE:
			temp_ch,temp_epg=self.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=self.make_EexceptGroup_Wavve())
			if len(temp_epg)!=0:CH_LIST.extend(temp_ch);EPG_LIST.extend(temp_epg)
		if(sType==_N or sType==_D)and self.M3U_ONTVING:
			temp_ch,temp_epg=self.BoritvObj.Get_EpgInfo_Tving()
			if len(temp_epg)!=0:CH_LIST.extend(temp_ch);EPG_LIST.extend(temp_epg)
		if(sType==_O or sType==_D)and self.M3U_ONSPOTV:
			temp_ch,temp_epg=self.BoritvObj.Get_EpgInfo_Spotv()
			if len(temp_epg)!=0:CH_LIST.extend(temp_ch);EPG_LIST.extend(temp_epg)
		if(sType==_P or sType==_D)and self.M3U_BC_SBS:
			temp_ch,temp_epg=self.BoritvObj.Get_EpgInfo_BroadCast_SBS()
			if len(temp_epg)!=0:CH_LIST.extend(temp_ch);EPG_LIST.extend(temp_epg)
		if len(EPG_LIST)==0:
			if sNoti!=_T:self.addon_noti(__language__(30909).encode(_C))
			return
		try:
			filename=self.make_Epg_Filename(tempyn=_B);fp=open(filename,_U,-1,_F);xmltext_1=_v;xmltext_2=_w;xmltext_3=_x;xmltext_4=_y;fp.write(xmltext_1);fp.write(xmltext_2);fp.write(xmltext_3)
			for i_section in CH_LIST:temptext_1=_z%(i_section.get(_W),i_section.get(_X));temptext_2=_A0%i_section.get(_d);temptext_3=_A1%i_section.get(_e);temptext_4=_A2;fp.write(temptext_1);fp.write(temptext_2);fp.write(temptext_3);fp.write(temptext_4)
			for i_section in EPG_LIST:temptext_1=_A3%(i_section.get(_A4),i_section.get('endTime'),i_section.get(_W),i_section.get(_X));temptext_2=_A5%i_section.get(_H);temptext_3=_A6;fp.write(temptext_1);fp.write(temptext_2);fp.write(temptext_3)
			fp.write(xmltext_4);fp.close()
		except:
			if sNoti!=_T:self.addon_noti(__language__(30910).encode(_C))
			return
		self.MakeEpg_SaveJson();asis_filename=self.make_Epg_Filename(tempyn=_B);tobe_filename=self.make_Epg_Filename(tempyn=_A)
		if xbmcvfs.copy(asis_filename,tobe_filename):
			if sNoti!=_T:self.addon_noti((sName+' '+__language__(30912)).encode(_C))
		else:self.addon_noti(__language__(30910).encode(_F))
		try:
			if self.M3U_AUTORESTART:addon=xbmcaddon.Addon(_A7);addon.setSetting(_g,_g)
		except:_Q
	def dp_Make_Epg(self,args):
		sType=args.get(_J);sName=args.get(_L);sNoti=args.get('sNoti')
		if sNoti!=_T:
			dialog=xbmcgui.Dialog();ret=dialog.yesno((sName+__language__(30911)).encode(_C),__language__(30907).encode(_C))
			if ret==_A:sys.exit()
		OTT_LIST=[];EXCEPT_GROUP=self.make_EexceptGroup_Wavve()
		if(sType==_M or sType==_D)and self.M3U_ONWAVVE:OTT_LIST.append(_M)
		if(sType==_N or sType==_D)and self.M3U_ONTVING:OTT_LIST.append(_N)
		if(sType==_O or sType==_D)and self.M3U_ONSPOTV:OTT_LIST.append(_O)
		if(sType==_P or sType==_D)and self.M3U_BC_SBS:OTT_LIST.append(_P)
		CH_LIST,EPG_LIST=self.BoritvObj.git_make_epg_list(OTT_LIST,EXCEPT_GROUP)
		if len(EPG_LIST)==0:
			if sNoti!=_T:self.addon_noti(__language__(30909).encode(_C))
			return
		try:
			filename=self.make_Epg_Filename(tempyn=_B);fp=open(filename,_U,-1,_F);xmltext_1=_v;xmltext_2=_w;xmltext_3=_x;xmltext_4=_y;fp.write(xmltext_1);fp.write(xmltext_2);fp.write(xmltext_3)
			for i_section in CH_LIST:temptext_1=_z%(i_section.get(_W),i_section.get(_X));temptext_2=_A0%i_section.get(_d);temptext_3=_A1%i_section.get(_e);temptext_4=_A2;fp.write(temptext_1);fp.write(temptext_2);fp.write(temptext_3);fp.write(temptext_4)
			for i_section in EPG_LIST:temptext_1=_A3%(i_section.get(_A4),i_section.get('endTime'),i_section.get(_W),i_section.get(_X));temptext_2=_A5%i_section.get(_H);temptext_3=_A6;fp.write(temptext_1);fp.write(temptext_2);fp.write(temptext_3)
			fp.write(xmltext_4);fp.close()
		except:
			if sNoti!=_T:self.addon_noti(__language__(30910).encode(_C))
			return
		self.MakeEpg_SaveJson();asis_filename=self.make_Epg_Filename(tempyn=_B);tobe_filename=self.make_Epg_Filename(tempyn=_A)
		if xbmcvfs.copy(asis_filename,tobe_filename):
			if sNoti!=_T:self.addon_noti((sName+' '+__language__(30912)).encode(_C))
		else:self.addon_noti(__language__(30910).encode(_F))
		try:
			if self.M3U_AUTORESTART:addon=xbmcaddon.Addon(_A7);addon.setSetting(_g,_g)
		except:_Q
	def make_EexceptGroup_Wavve(self):
		except_group=[]
		if self.M3U_ONWAVVERADIO==_A:except_group.append(_i)
		if self.M3U_ONWAVVEHOME==_A:except_group.append('홈쇼핑')
		return except_group
	def check_config(self):
		checkyn=_B;self.M3U_FILE_PATH=__addon__.getSetting('m3uFilepath').strip();self.M3U_FILE_NAME=__addon__.getSetting('m3uFilename').strip();self.M3U_ONWAVVE=_B if __addon__.getSetting('onWavve')==_K else _A;self.M3U_ONTVING=_B if __addon__.getSetting('onTvng')==_K else _A;self.M3U_ONSPOTV=_B if __addon__.getSetting('onSpotv')==_K else _A;self.M3U_BC_SBS=_B if __addon__.getSetting('onBroadSBS')==_K else _A;self.M3U_ONWAVVERADIO=_B if __addon__.getSetting('onWavveRadio')==_K else _A;self.M3U_ONWAVVEHOME=_B if __addon__.getSetting('onWavveHome')==_K else _A;self.M3U_DISPLAYNM=_B if __addon__.getSetting('displayOTTnm')==_K else _A;self.M3U_AUTORESTART=_B if __addon__.getSetting('autoRestart')==_K else _A;self.M3U_CUSTOM_LIST=self.customEpg_FileList()
		if self.M3U_FILE_PATH==''or self.M3U_FILE_NAME=='':checkyn=_A
		if self.M3U_ONWAVVE==_A and self.M3U_ONTVING==_A and self.M3U_ONSPOTV==_A and self.M3U_BC_SBS==_A:checkyn=_A
		if checkyn==_A:
			dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30901).encode(_C),__language__(30902).encode(_C))
			if ret==_B:__addon__.openSettings();sys.exit()
			else:sys.exit()
	def MakeEpg_SaveJson(self):
		json_data={'date_makeepg':self.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
		try:fp=open(EPGDATE_FILE_NAME,_U,-1,_F);json.dump(json_data,fp);fp.close()
		except Exception as exception:return
	def boritv_main(self):
		self.BoritvObj.KodiVersion=int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0]);mode=self.main_params.get(_I,_Q);self.check_config()
		if mode is _Q:self.dp_Main_List()
		elif mode==_k:self.dp_Delete_M3u(self.main_params)
		elif mode==_R:self.BoritvObj.INIT_INFO_LIST();self.dp_MakeAdd_M3u(self.main_params)
		elif mode==_l:self.BoritvObj.INIT_INFO_LIST();self.dp_Make_Epg(self.main_params)
		else:_Q