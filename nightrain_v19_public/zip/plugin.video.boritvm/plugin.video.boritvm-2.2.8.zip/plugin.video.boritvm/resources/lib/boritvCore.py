_A4='channelCode'
_A3='endBroadTime'
_A2='startBroadTime'
_A1='broadcastDate'
_A0='broadDate'
_z='/v2/media/schedules'
_y='%Y-%m-%d'
_x='/api/v3/channel'
_w='http://'
_v='offset'
_u='channelname'
_t='210000'
_s='180000'
_r='150000'
_q='120000'
_p='090000'
_o='060000'
_n='030000'
_m='genre'
_l='ndate'
_k='000000000000001'
_j='tving'
_i='scope'
_h='adult'
_g='order'
_f='pageSize'
_e='pageNo'
_d='logo'
_c='bc_sbs'
_b='list'
_a='utf-8'
_Z='https://'
_Y='00'
_X='spotv'
_W='%Y%m%d'
_V='json_name'
_U='body'
_T='result'
_S='free'
_R='wavve'
_Q='id'
_P='1'
_O='endTime'
_N='startTime'
_M='title'
_L='genrenm'
_K='name'
_J=':'
_I='channelimg'
_H='all'
_G='channelnm'
_F='endtm'
_E='starttm'
_D='ott'
_C='Get'
_B='channelid'
_A=None
__author__='NightRain'
import urllib,re,json,sys,requests,datetime,time,os,zlib,base64,httpx
TIME_GROUP=[{_E:'000000',_F:_n},{_E:_n,_F:_o},{_E:_o,_F:_p},{_E:_p,_F:_q},{_E:_q,_F:_r},{_E:_r,_F:_s},{_E:_s,_F:_t},{_E:_t,_F:'240000'}]
class Boritv:
	def __init__(A):A.API_WAVVE='https://apis.wavve.com';A.API_TVING='https://api.tving.com';A.API_TVINGIMG='https://image.tving.com';A.API_SPOTV='https://www.spotvnow.co.kr';A.HTTPTAG=_Z;A.LIMIT_WAVVE=500;A.LIMIT_TVING=100;A.LIMIT_TVINGEPG=20;A.USER_AGENT='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36';A.APPVERSION='150.0.0.0';A.DEVICEMODEL='Chrome';A.OSTYPE='Windows';A.OSVERSION='NT 10.0';A.DEFAULT_HEADER={'user-agent':A.USER_AGENT};A.SLEEP_TIME=.2;A.KodiVersion=20;A.BT_CONTEXTJSON_FILE1='';A.BT_CONTEXTJSON_FILE2='';A.BT_CONTEXTJSON_FILE3='';A.BT_CONTEXTJSON_FILE4='';A.GIT_BASE_M3U=[];A.GIT_BASE_EPG=[];A.GIT_CHANNEL_INFO={}
	def callRequestCookies(F,jobtype,url,payload=_A,params=_A,headers=_A,cookies=_A):
		D=cookies;C=headers;B=params;A=F.DEFAULT_HEADER
		if C:A.update(C)
		if jobtype==_C:E=httpx.get(url,params=B,headers=A,cookies=D)
		else:E=httpx.post(url,data=payload,params=B,headers=A,cookies=D)
		return E
	def INIT_INFO_LIST(A):
		B='https://raw.githubusercontent.com/kym1088/channel_info/refs/heads/main/data/bt_m3u_base.json';C=A.callRequestCookies(_C,B,payload=_A,params=_A,headers=_A,cookies=_A);A.GIT_BASE_M3U=json.loads(C.text)
		for D in A.GIT_BASE_M3U:A.GIT_CHANNEL_INFO.update({D[_B]+'.'+D[_D]:D})
		B='https://raw.githubusercontent.com/kym1088/channel_info/refs/heads/main/data/bt_epg_base.json';C=A.callRequestCookies(_C,B,payload=_A,params=_A,headers=_A,cookies=_A);A.GIT_BASE_EPG=json.loads(C.text)
	def JsonFile_Save(D,filename,dic):
		B=filename;A=False
		if B=='':return A
		try:C=open(B,'w',-1,_a);json.dump(dic,C,indent=4,ensure_ascii=A);C.close()
		except:return A
		return True
	def Get_DefaultParams_Wavve(C):A='none';B={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':A,'device':'pc','drm':'wm','partner':'pooq','pooqzone':A,'region':'kor','targetage':_H};return B
	def Get_DefaultParams_Tving(B):A={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'};return A
	def Get_Now_Datetime(A):return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
	def xmlText(B,in_text):A=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;');return A
	def Get_ChannelList_BroadCast_SBS(B):
		F='.bc_sbs';C=[]
		try:
			G='https://apis.sbs.co.kr/play-api/1.0/onair/channels';D=B.callRequestCookies(_C,G,payload=_A,params=_A,headers=_A,cookies=_A,redirects=True)
			if D.status_code!=200:return[]
			H=json.loads(D.text)
			for A in H.get(_b):
				if A['type']=='TV':
					if A.get(_B)+F in B.INIT_CHANNEL:E=B.INIT_CHANNEL[A.get(_B)+F].get(_V)
					else:E=''
					I=B.make_getGenre(A.get(_B),_c);J={_B:A.get(_B),_G:A.get(_u),_I:'https://static.cloud.sbs.co.kr/common/img/sbsplayBig_logo.png',_D:_c,_L:I,_V:E};C.append(J)
		except Exception as K:print(K);return[]
		return C
	def Get_EpgInfo_BroadCast_SBS(D,days=2):
		M='{}{}{}00';K='start_time';F=[];L=[];N=D.make_DateList(days=2,dateType='3');F=D.Get_ChannelList_BroadCast_SBS()
		try:
			for G in F:
				if G[_V]in[_A,'']:continue
				for H in N:
					O='{dt.year}/{dt.month}/{dt.day}'.format(dt=H);P='https://static.cloud.sbs.co.kr/schedule/{}/{}.json'.format(O,G[_V]);Q=D.callRequestCookies(_C,P,payload=_A,params=_A,headers=_A,cookies=_A);B=json.loads(Q.text)
					for C in range(len(B)):
						I=H;J=H;E=B[C][K].split(_J);A=B[C]['end_time'].split(_J)
						if len(A)!=['']:
							if C+1<len(B):A=B[C+1][K].split(_J)
							else:A=B[C][K].split(_J);A[0]=str(int(A[0])+1).zfill(2)
						if int(E[0])>=24:E[0]=str(int(E[0])-24).zfill(2);I=I+datetime.timedelta(days=1)
						if int(A[0])>=24:A[0]=str(int(A[0])-24).zfill(2);J=J+datetime.timedelta(days=1)
						R={_B:G[_B],_M:D.xmlText(B[C][_M]),_N:M.format(I.strftime(_W),E[0],E[1]),_O:M.format(J.strftime(_W),A[0],A[1]),_D:_c};L.append(R)
					time.sleep(D.SLEEP_TIME)
		except Exception as S:print(S);return[],[]
		return F,L
	def Get_ChannelList_pjy(D):
		G='pjy';B='nm';E=[];C={'MBC':{_Q:'P02',B:'MBC 저화질'},'KBS1':{_Q:'P03',B:'KBS1 저화질'},'KBS2':{_Q:'P04',B:'KBS2 저화질'}}
		try:
			H='https://raw.githubusercontent.com/kenpark76/kenpark76.github.io/refs/heads/main/koreatv.json';I=D.callRequestCookies(_C,H,payload=_A,params=_A,headers=_A,cookies=_A,redirects=True);J=json.loads(I.text)
			for A in J:
				if C.get(A[_K])in[_A]:continue
				F=C.get(A[_K]).get(_Q);K=C.get(A[_K]).get(B);L=A[_d];M=A['uris'][0];N=D.make_getGenre(F,G);O={_B:F,_G:K,_I:L,_D:G,_L:N,'channelurl':M};E.append(O)
		except Exception as P:print(P);return[]
		return E
	def Get_ChannelList_Wavve(B,exceptGroup=[]):
		M='live';L='data';K='context_list';J='LN99';I='uitype';C=[]
		try:
			N=B.API_WAVVE+'/v2/live/channels';E={'service':_R,I:'band_2_rank','uiparent':'GN55-LN99','uicode':J,'uirank':'3','limit':str(200),_v:'0','orderby':'viewtime','broadcastid':J,'isBand':'true',I:'LN58','client_version':'7.1.40'};E.update(B.Get_DefaultParams_Wavve());O=B.callRequestCookies(_C,N,payload=_A,params=E,headers=_A,cookies=_A);F=json.loads(O.text)
			if not K in F[L]:return C
			P=F[L][K]
			for D in P:
				G=D['context_id'];Q=D[M][_K];A=D[M]['main_image']
				if A and not A.startswith(_w)and not A.startswith(_Z):A=B.HTTPTAG+A
				H=B.make_getGenre(G,_R);R={_B:G,_G:Q,_I:A,_D:_R,_L:H}
				if H not in exceptGroup:C.append(R)
		except Exception as S:print(S);return[]
		return C
	def Get_ChannelList_Spotv(B):
		C=[]
		try:
			E=B.API_SPOTV+_x;F=B.callRequestCookies(_C,E,payload=_A,params=_A,headers=_A,cookies=_A);G=json.loads(F.text)
			for A in G:D=str(A[_Q]);H={_B:D,_G:A[_K],_I:A[_d],_D:_X,_L:B.make_getGenre(D,_X),_S:A[_S]};C.append(H)
		except Exception as I:print(I);return[]
		return C
	def Get_ChannelList_Tving(A):
		L='C44441';E='live_code';D=[];F=[]
		try:
			M=A.API_TVING+'/v2/media/lives';G={_e:_P,_f:str(A.LIMIT_TVING),_g:'rating',_h:_H,_S:_H,'guest':_H,_i:_H,'channelType':'CPCS0100,CPCS0400'};G.update(A.Get_DefaultParams_Tving());N=A.callRequestCookies(_C,M,payload=_A,params=G,headers=_A,cookies=_A);H=json.loads(N.text)
			if not _T in H[_U]:return D
			I=H[_U][_T]
			for B in I:
				if B[E]==L:continue
				F.append(B[E])
			J=A.Get_ChannelImg_Tving(F)
			for B in I:
				C=B[E]
				if C==L:continue
				O=B['schedule']['channel'][_K]['ko']
				if C in J:K=J[C]
				else:K=''
				P={_B:C,_G:O,_I:K,_D:_j,_L:A.make_getGenre(C,_j)};D.append(P)
		except Exception as Q:print(Q);return[]
		return D
	def Get_timestamp(B,timetype=1):
		A=B.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
		if timetype!=1:A+=_k
		return A
	def Make_Header_Timestamp(A,timetype):
		C='transactionId'
		if timetype==_P:B={C:A.Get_timestamp(timetype=1)+_k}
		else:B={'timestamp':A.Get_timestamp(timetype=1),C:A.Get_timestamp(timetype=1)+_k}
		return B
	def make_EpgDatetime_Tving(D,days=2):
		E=[];G=D.make_DateList(days=2,dateType='2');B=int(D.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
		for C in G:
			for A in range(8):
				H={_l:C,_E:TIME_GROUP[A][_E],_F:TIME_GROUP[A][_F]};F=int(C+TIME_GROUP[A][_E]);I=int(C+TIME_GROUP[A][_F])
				if B<=F or F<B and B<I:E.append(H)
		return E
	def make_DateList(D,days=2,dateType=_P):
		C=dateType;A=[];E=D.Get_Now_Datetime()
		for F in range(days):
			B=E+datetime.timedelta(days=F)
			if C==_P:A.append(B.strftime(_y))
			elif C=='2':A.append(B.strftime(_W))
			else:A.append(B)
		return A
	def make_Tving_ChannleGroup(E,channelid_list):
		C=[];B=0;A=''
		for D in channelid_list:
			if B==0:A=D
			else:A+=',%s'%D
			B+=1
			if B>=E.LIMIT_TVINGEPG:C.append(A);B=0;A=''
		if A!='':C.append(A)
		return C
	def Get_ChannelImg_Tving(A,chid_list):
		G='url';F='channel_code';E='code';D={}
		try:
			H=A.Get_Now_Datetime().strftime(_W);K=TIME_GROUP[6][_E];L=TIME_GROUP[6][_F];M=A.make_Tving_ChannleGroup(chid_list)
			for B in M:
				N=A.API_TVING+_z;I={_e:_P,_f:str(A.LIMIT_TVINGEPG),_g:'chno',_i:_H,_h:'n',_S:_H,_A0:H,_A1:H,_A2:K,_A3:L,_A4:B};I.update(A.Get_DefaultParams_Tving());O=A.callRequestCookies(_C,N,payload=_A,params=I,headers=_A,cookies=_A);J=json.loads(O.text)
				if not _T in J[_U]:return{}
				P=J[_U][_T]
				for B in P:
					for C in B['image']:
						if C[E]=='CAIC0400':D[B[F]]=A.API_TVINGIMG+C[G]
						elif C[E]=='CAIC1400':D[B[F]]=A.API_TVINGIMG+C[G]
						elif C[E]=='CAIC1900':D[B[F]]=A.API_TVINGIMG+C[G]
		except Exception as Q:print(Q);return{}
		return D
	def Get_EpgInfo_Spotv(A,days=2):
		I=[];J=[];K=A.make_DateList(days=days,dateType=_P)
		try:
			C=A.API_SPOTV+_x;D=A.callRequestCookies(_C,C,payload=_A,params=_A,headers=_A,cookies=_A);E=json.loads(D.text)
			for B in E:F=str(B[_Q]);G={_B:F,_G:A.xmlText(B[_K]),_I:B[_d],_D:_X};I.append(G)
		except Exception as H:print(H);return[],[]
		try:
			for L in K:
				C=A.API_SPOTV+'/api/v3/program/'+L;D=A.callRequestCookies(_C,C,payload=_A,params=_A,headers=_A,cookies=_A);E=json.loads(D.text)
				for B in E:F=str(B['channelId']);G={_B:F,_M:A.xmlText(B[_M]),_N:B[_N].replace('-','').replace(' ','').replace(_J,'')+_Y,_O:B[_O].replace('-','').replace(' ','').replace(_J,'')+_Y,_D:_X};J.append(G)
				time.sleep(A.SLEEP_TIME)
		except Exception as H:print(H);return[],[]
		return I,J
	def Make_Wavve_TimeList(L,days=2):
		K='{} {}';J='21:00';I='18:00';H='15:00';G='12:00';F='09:00';E='06:00';D='03:00';A=[];M=[['00:00',D],[D,E],[E,F],[F,G],[G,H],[H,I],[I,J],[J,'24:00']];N=L.Get_Now_Datetime()
		for O in range(days):
			P=N+datetime.timedelta(days=+O);B=P.strftime(_y)
			for C in M:Q=[K.format(B,C[0]),K.format(B,C[1])];A.append(Q)
		return A
	def Get_EpgInfo_Wavve(A,days=2,exceptGroup=[]):
		P='endtime';O='starttime';I=exceptGroup;J=[];K=[];B=[];"\n\t\tnowdate       = self.Get_Now_Datetime()\n\t\tfromdate      = nowdate + datetime.timedelta( hours=-2  )\n\t\ttodate        = nowdate + datetime.timedelta( days=days ) # 2024.06.13\n\t\tif int(fromdate.strftime('%H')) <= 3 :\n\t\t\tstartdatetime = fromdate.strftime('%Y-%m-%d 00:00')\n\t\telse:\n\t\t\tstartdatetime = fromdate.strftime('%Y-%m-%d %H:00')\n\t\tenddatetime   = todate.strftime('%Y-%m-%d 00:00') # 2024.06.13\n\t\t";Q=A.Make_Wavve_TimeList(days)
		try:
			for L in Q:
				R=A.API_WAVVE+'/live/epgs';M={'limit':str(A.LIMIT_WAVVE),_v:'0',_m:_H,'startdatetime':L[0],'enddatetime':L[1]};M.update(A.Get_DefaultParams_Wavve());S=A.callRequestCookies(_C,R,payload=_A,params=M,headers=_A,cookies=_A);T=json.loads(S.text);U=T[_b]
				for D in U:
					G=D[_B];N=A.make_getGenre(G,_R);E=D['channelimage']
					if not E.startswith(_w)and not E.startswith(_Z):E=A.HTTPTAG+E
					H={_B:G,_G:A.xmlText(D[_u]),_I:E,_D:_R}
					if N not in I and G not in J:K.append(H);J.append(G)
					for F in D[_b]:
						H={_B:D[_B],_M:A.xmlText(F[_M]),_N:F[O].replace('-','').replace(' ','').replace(_J,'')+_Y,_O:F[P].replace('-','').replace(' ','').replace(_J,'')+_Y,_D:_R}
						if N not in I and F[O]!=F[P]:B.append(H)
		except Exception as V:print(V);return[],[]
		W=len(B)
		for C in range(1,W):
			if int(B[C-1][_O])+1==int(B[C][_N])and B[C-1][_B]==B[C][_B]:B[C-1][_O]=B[C][_N]
		return K,B
	def Get_EpgInfo_Tving(A,days=2):
		N='broadcast_start_time';M='schedule_code';G='schedules';B=[];H=[];I=[];O=A.make_EpgDatetime_Tving(days=days);B=A.Get_ChannelList_Tving();J=[]
		for E in range(len(B)):B[E][_G]=A.xmlText(B[E][_G]);J.append(B[E][_B])
		P=A.make_Tving_ChannleGroup(J)
		try:
			Q=A.API_TVING+_z
			for D in O:
				for R in P:
					K={_e:_P,_f:str(A.LIMIT_TVINGEPG),_g:'chno',_i:_H,_h:'n',_S:_H,_A0:D[_l],_A1:D[_l],_A2:D[_E],_A3:D[_F],_A4:R};K.update(A.Get_DefaultParams_Tving());S=A.callRequestCookies(_C,Q,payload=_A,params=K,headers=_A,cookies=_A);T=json.loads(S.text);U=T[_U][_T]
					for F in U:
						if G not in F:continue
						if F[G]==_A:continue
						for C in F[G]:
							V={_B:C[M],_M:A.xmlText(C['program'][_K]['ko']),_N:str(C[N]),_O:str(C['broadcast_end_time']),_D:_j};L=C[M]+str(C[N])
							if L in I:continue
							I.append(L);H.append(V)
					time.sleep(A.SLEEP_TIME)
		except Exception as W:print(W);return[],[]
		return B,H
	def t_Cache(C):A=int(time.time());B=int(A-A%3600);return B,A
	def zlib_compress(B,plaintext):A=zlib.compress(plaintext.encode(_a));return base64.standard_b64encode(A).decode(_a)
	def make_getGenre(A,channelid,ott):
		try:B=A.INIT_CHANNEL.get(channelid+'.'+ott).get(_m)
		except:B=A.INIT_CHANNEL.get('-').get(_m)
		return B
	def git_make_channel_list(C,OTT_LIST,EXCEPT_GROUP):
		B=[]
		for A in C.GIT_BASE_M3U:
			if A[_D]in OTT_LIST and A[_L]not in EXCEPT_GROUP:B.append(A)
		return B
	def git_make_epg_list(B,OTT_LIST,EXCEPT_GROUP):
		C=[];D=[]
		for(A,F)in B.GIT_BASE_EPG.items():
			if A not in B.GIT_CHANNEL_INFO:E='-';continue
			else:E=B.GIT_CHANNEL_INFO[A][_L]
			G=A.split('.')[0];H=A.split('.')[1];I=B.GIT_CHANNEL_INFO[A][_G];J=B.GIT_CHANNEL_INFO[A][_I]
			if E in EXCEPT_GROUP:continue
			K={_B:G,_D:H,_G:I,_I:J};C.append(K)
			for L in F:"\n\t\t\t\ttemp_list = {\n\t\t\t\t\t\t\t\t'channelid' : i_epg['channelid'],\n\t\t\t\t\t\t\t\t'ott'       : i_epg['ott'],\n\t\t\t\t\t\t\t\t'startTime' : i_epg['startTime'],\n\t\t\t\t\t\t\t\t'endTime'   : i_epg['endTime'],\n\t\t\t\t\t\t\t\t'title'     : i_epg['title'],\n\t\t\t\t}\n\t\t\t\t";D.append(L)
		return C,D