__author__="NightRain"
dVXainRWHyEvcSqUemtpGCFLuwNsJA=False
dVXainRWHyEvcSqUemtpGCFLuwNsJI=object
dVXainRWHyEvcSqUemtpGCFLuwNsJM=None
dVXainRWHyEvcSqUemtpGCFLuwNsJg=str
dVXainRWHyEvcSqUemtpGCFLuwNsJx=Exception
dVXainRWHyEvcSqUemtpGCFLuwNsJj=print
dVXainRWHyEvcSqUemtpGCFLuwNsTB=True
dVXainRWHyEvcSqUemtpGCFLuwNsTP=int
dVXainRWHyEvcSqUemtpGCFLuwNsTl=range
dVXainRWHyEvcSqUemtpGCFLuwNsTJ=len
dVXainRWHyEvcSqUemtpGCFLuwNsTY=dict
dVXainRWHyEvcSqUemtpGCFLuwNsTr=set
dVXainRWHyEvcSqUemtpGCFLuwNsTo=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
import zlib
import base64
from channelgenre import*
dVXainRWHyEvcSqUemtpGCFLuwNsBl=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
dVXainRWHyEvcSqUemtpGCFLuwNsBJ=[{'id':'1','name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':dVXainRWHyEvcSqUemtpGCFLuwNsJA,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'id':'2','name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':dVXainRWHyEvcSqUemtpGCFLuwNsJA,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'id':'3','name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':dVXainRWHyEvcSqUemtpGCFLuwNsJA,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'id':'9','name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':dVXainRWHyEvcSqUemtpGCFLuwNsJA,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'id':'10','name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':dVXainRWHyEvcSqUemtpGCFLuwNsJA,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'id':'11','name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':dVXainRWHyEvcSqUemtpGCFLuwNsJA,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
class dVXainRWHyEvcSqUemtpGCFLuwNsBP(dVXainRWHyEvcSqUemtpGCFLuwNsJI):
 def __init__(dVXainRWHyEvcSqUemtpGCFLuwNsBT):
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_WAVVE ='https://apis.wavve.com'
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_TVING ='https://api.tving.com'
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_TVINGIMG ='https://image.tving.com'
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_SPOTV ='https://www.spotvnow.co.kr'
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_SAMSUNGTV ='https://www.samsungtvplus.com'
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.HTTPTAG ='https://'
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.LIMIT_WAVVE =500
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.LIMIT_TVING =60
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.LIMIT_TVINGEPG=20 
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.APPVERSION ='115.0.0.0' 
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.DEVICEMODEL ='Chrome' 
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.OSTYPE ='Windows' 
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.OSVERSION ='NT 10.0' 
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.DEFAULT_HEADER={'user-agent':dVXainRWHyEvcSqUemtpGCFLuwNsBT.USER_AGENT}
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.SLEEP_TIME =0.2
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.INIT_GENRESORT=MASTER_GENRE
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.INIT_CHANNEL =MASTER_CHANNEL
  dVXainRWHyEvcSqUemtpGCFLuwNsBT.KodiVersion =20
 def callRequestCookies(dVXainRWHyEvcSqUemtpGCFLuwNsBT,jobtype,dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsJM,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM,redirects=dVXainRWHyEvcSqUemtpGCFLuwNsJA):
  dVXainRWHyEvcSqUemtpGCFLuwNsBo=dVXainRWHyEvcSqUemtpGCFLuwNsBT.DEFAULT_HEADER
  if headers:dVXainRWHyEvcSqUemtpGCFLuwNsBo.update(headers)
  if jobtype=='Get':
   dVXainRWHyEvcSqUemtpGCFLuwNsBf=requests.get(dVXainRWHyEvcSqUemtpGCFLuwNsBb,params=params,headers=dVXainRWHyEvcSqUemtpGCFLuwNsBo,cookies=cookies,allow_redirects=redirects)
  else:
   dVXainRWHyEvcSqUemtpGCFLuwNsBf=requests.post(dVXainRWHyEvcSqUemtpGCFLuwNsBb,data=payload,params=params,headers=dVXainRWHyEvcSqUemtpGCFLuwNsBo,cookies=cookies,allow_redirects=redirects)
  return dVXainRWHyEvcSqUemtpGCFLuwNsBf
 def Get_DefaultParams_Wavve(dVXainRWHyEvcSqUemtpGCFLuwNsBT):
  dVXainRWHyEvcSqUemtpGCFLuwNsBD={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return dVXainRWHyEvcSqUemtpGCFLuwNsBD
 def Get_DefaultParams_Tving(dVXainRWHyEvcSqUemtpGCFLuwNsBT):
  dVXainRWHyEvcSqUemtpGCFLuwNsBD={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return dVXainRWHyEvcSqUemtpGCFLuwNsBD
 def Get_Now_Datetime(dVXainRWHyEvcSqUemtpGCFLuwNsBT):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(dVXainRWHyEvcSqUemtpGCFLuwNsBT,in_text):
  dVXainRWHyEvcSqUemtpGCFLuwNsBz=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return dVXainRWHyEvcSqUemtpGCFLuwNsBz
 def Get_ChannelList_Wavve(dVXainRWHyEvcSqUemtpGCFLuwNsBT,exceptGroup=[]):
  dVXainRWHyEvcSqUemtpGCFLuwNsBO =[]
  dVXainRWHyEvcSqUemtpGCFLuwNsBh=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_ChannelImg_Wavve()
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_WAVVE+'/cf/live/recommend-channels'
   dVXainRWHyEvcSqUemtpGCFLuwNsBD={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBT.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   dVXainRWHyEvcSqUemtpGCFLuwNsBD.update(dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_DefaultParams_Wavve())
   dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsBD,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
   dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
   if not('celllist' in dVXainRWHyEvcSqUemtpGCFLuwNsBk['cell_toplist']):return dVXainRWHyEvcSqUemtpGCFLuwNsBO
   dVXainRWHyEvcSqUemtpGCFLuwNsBA=dVXainRWHyEvcSqUemtpGCFLuwNsBk['cell_toplist']['celllist']
   for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBA:
    dVXainRWHyEvcSqUemtpGCFLuwNsBM=dVXainRWHyEvcSqUemtpGCFLuwNsBI['contentid']
    dVXainRWHyEvcSqUemtpGCFLuwNsBg=dVXainRWHyEvcSqUemtpGCFLuwNsBI['title_list'][0]['text']
    if dVXainRWHyEvcSqUemtpGCFLuwNsBM in dVXainRWHyEvcSqUemtpGCFLuwNsBh:
     dVXainRWHyEvcSqUemtpGCFLuwNsBx=dVXainRWHyEvcSqUemtpGCFLuwNsBh[dVXainRWHyEvcSqUemtpGCFLuwNsBM]
     if not dVXainRWHyEvcSqUemtpGCFLuwNsBx.startswith('http://')and not dVXainRWHyEvcSqUemtpGCFLuwNsBx.startswith('https://'):
      dVXainRWHyEvcSqUemtpGCFLuwNsBx=dVXainRWHyEvcSqUemtpGCFLuwNsBT.HTTPTAG+dVXainRWHyEvcSqUemtpGCFLuwNsBh[dVXainRWHyEvcSqUemtpGCFLuwNsBM]
    else:
     dVXainRWHyEvcSqUemtpGCFLuwNsBx=''
    dVXainRWHyEvcSqUemtpGCFLuwNsBj=dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_getGenre(dVXainRWHyEvcSqUemtpGCFLuwNsBM,'wavve')
    dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBM,'channelnm':dVXainRWHyEvcSqUemtpGCFLuwNsBg,'channelimg':dVXainRWHyEvcSqUemtpGCFLuwNsBx,'ott':'wavve','genrenm':dVXainRWHyEvcSqUemtpGCFLuwNsBj}
    if dVXainRWHyEvcSqUemtpGCFLuwNsBj not in exceptGroup:
     dVXainRWHyEvcSqUemtpGCFLuwNsBO.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[]
  return dVXainRWHyEvcSqUemtpGCFLuwNsBO
 def Get_ChannelList_WavveExcept(dVXainRWHyEvcSqUemtpGCFLuwNsBT,exceptGroup=[]):
  dVXainRWHyEvcSqUemtpGCFLuwNsBO=[]
  if exceptGroup==[]:return[]
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_WAVVE+'/cf/live/recommend-channels'
   for dVXainRWHyEvcSqUemtpGCFLuwNsBI in exceptGroup:
    dVXainRWHyEvcSqUemtpGCFLuwNsBD={'WeekDay':'all','adult':'n','broadcastid':dVXainRWHyEvcSqUemtpGCFLuwNsBI['broadcastid'],'contenttype':'channel','genre':dVXainRWHyEvcSqUemtpGCFLuwNsBI['genre'],'isrecommend':'y','limit':dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBT.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    dVXainRWHyEvcSqUemtpGCFLuwNsBD.update(dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_DefaultParams_Wavve())
    dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsBD,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
    dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
    if not('celllist' in dVXainRWHyEvcSqUemtpGCFLuwNsBk['cell_toplist']):return dVXainRWHyEvcSqUemtpGCFLuwNsBO
    dVXainRWHyEvcSqUemtpGCFLuwNsBA=dVXainRWHyEvcSqUemtpGCFLuwNsBk['cell_toplist']['celllist']
    for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBA:
     dVXainRWHyEvcSqUemtpGCFLuwNsBO.append(dVXainRWHyEvcSqUemtpGCFLuwNsBI['contentid'])
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[]
  return dVXainRWHyEvcSqUemtpGCFLuwNsBO
 def Get_ChannelImg_Wavve(dVXainRWHyEvcSqUemtpGCFLuwNsBT):
  dVXainRWHyEvcSqUemtpGCFLuwNsPl={}
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsPJ=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_Now_Datetime()
   dVXainRWHyEvcSqUemtpGCFLuwNsPT =dVXainRWHyEvcSqUemtpGCFLuwNsPJ+datetime.timedelta(hours=3)
   dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_WAVVE+'/live/epgs'
   dVXainRWHyEvcSqUemtpGCFLuwNsBD={'limit':dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBT.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':dVXainRWHyEvcSqUemtpGCFLuwNsPJ.strftime('%Y-%m-%d %H:00'),'enddatetime':dVXainRWHyEvcSqUemtpGCFLuwNsPT.strftime('%Y-%m-%d %H:00')}
   dVXainRWHyEvcSqUemtpGCFLuwNsBD.update(dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_DefaultParams_Wavve())
   dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsBD,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
   dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
   dVXainRWHyEvcSqUemtpGCFLuwNsBA=dVXainRWHyEvcSqUemtpGCFLuwNsBk['list']
   for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBA:
    dVXainRWHyEvcSqUemtpGCFLuwNsPl[dVXainRWHyEvcSqUemtpGCFLuwNsBI['channelid']]=dVXainRWHyEvcSqUemtpGCFLuwNsBI['channelimage']
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
  return dVXainRWHyEvcSqUemtpGCFLuwNsPl
 def Get_ChanneGenrename_Wavve(dVXainRWHyEvcSqUemtpGCFLuwNsBT,dVXainRWHyEvcSqUemtpGCFLuwNsBM):
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_WAVVE+'/live/channels/'+dVXainRWHyEvcSqUemtpGCFLuwNsBM
   dVXainRWHyEvcSqUemtpGCFLuwNsBD=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_DefaultParams_Wavve()
   dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsBD,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
   dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
   dVXainRWHyEvcSqUemtpGCFLuwNsPY=dVXainRWHyEvcSqUemtpGCFLuwNsBk['genretext']
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return ''
  return dVXainRWHyEvcSqUemtpGCFLuwNsPY
 def Get_ChannelList_Spotv(dVXainRWHyEvcSqUemtpGCFLuwNsBT,payyn=dVXainRWHyEvcSqUemtpGCFLuwNsTB):
  dVXainRWHyEvcSqUemtpGCFLuwNsBO=[]
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_SPOTV+'/api/v3/channel'
   dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsJM,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
   dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
   for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBk:
    dVXainRWHyEvcSqUemtpGCFLuwNsBM=dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBI['id'])
    dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBM,'channelnm':dVXainRWHyEvcSqUemtpGCFLuwNsBI['name'],'channelimg':dVXainRWHyEvcSqUemtpGCFLuwNsBI['logo'],'ott':'spotv','genrenm':dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_getGenre(dVXainRWHyEvcSqUemtpGCFLuwNsBM,'spotv'),'free':dVXainRWHyEvcSqUemtpGCFLuwNsBI['free']}
    dVXainRWHyEvcSqUemtpGCFLuwNsBO.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[]
  return dVXainRWHyEvcSqUemtpGCFLuwNsBO
 def Get_ChannelList_Tving(dVXainRWHyEvcSqUemtpGCFLuwNsBT):
  dVXainRWHyEvcSqUemtpGCFLuwNsBO =[]
  dVXainRWHyEvcSqUemtpGCFLuwNsPr=[]
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_TVING+'/v2/media/lives'
   dVXainRWHyEvcSqUemtpGCFLuwNsBD={'pageNo':'1','pageSize':dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBT.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   dVXainRWHyEvcSqUemtpGCFLuwNsBD.update(dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_DefaultParams_Tving())
   dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsBD,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
   dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
   if not('result' in dVXainRWHyEvcSqUemtpGCFLuwNsBk['body']):return dVXainRWHyEvcSqUemtpGCFLuwNsBO
   dVXainRWHyEvcSqUemtpGCFLuwNsBA=dVXainRWHyEvcSqUemtpGCFLuwNsBk['body']['result']
   for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBA:
    if dVXainRWHyEvcSqUemtpGCFLuwNsBI['live_code']=='C44441':continue 
    dVXainRWHyEvcSqUemtpGCFLuwNsPr.append(dVXainRWHyEvcSqUemtpGCFLuwNsBI['live_code'])
   dVXainRWHyEvcSqUemtpGCFLuwNsBh=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_ChannelImg_Tving(dVXainRWHyEvcSqUemtpGCFLuwNsPr)
   for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBA:
    dVXainRWHyEvcSqUemtpGCFLuwNsBM=dVXainRWHyEvcSqUemtpGCFLuwNsBI['live_code']
    if dVXainRWHyEvcSqUemtpGCFLuwNsBM=='C44441':continue 
    dVXainRWHyEvcSqUemtpGCFLuwNsBg=dVXainRWHyEvcSqUemtpGCFLuwNsBI['schedule']['channel']['name']['ko']
    if dVXainRWHyEvcSqUemtpGCFLuwNsBM in dVXainRWHyEvcSqUemtpGCFLuwNsBh:
     dVXainRWHyEvcSqUemtpGCFLuwNsBx=dVXainRWHyEvcSqUemtpGCFLuwNsBh[dVXainRWHyEvcSqUemtpGCFLuwNsBM]
    else:
     dVXainRWHyEvcSqUemtpGCFLuwNsBx=''
    dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBM,'channelnm':dVXainRWHyEvcSqUemtpGCFLuwNsBg,'channelimg':dVXainRWHyEvcSqUemtpGCFLuwNsBx,'ott':'tving','genrenm':dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_getGenre(dVXainRWHyEvcSqUemtpGCFLuwNsBM,'tving')}
    dVXainRWHyEvcSqUemtpGCFLuwNsBO.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[]
  return dVXainRWHyEvcSqUemtpGCFLuwNsBO
 def Get_timestamp(dVXainRWHyEvcSqUemtpGCFLuwNsBT,timetype=1):
  ts=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_Now_Datetime().strftime('%Y%m%d%H%M%S%f')[:-3]
  if timetype!=1:ts+='000000000000001'
  return ts
 def Make_Header_Timestamp(dVXainRWHyEvcSqUemtpGCFLuwNsBT,timetype):
  if timetype=='1':
   dVXainRWHyEvcSqUemtpGCFLuwNsPo={'transactionId':dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_timestamp(timetype=1)+'000000000000001',}
  else:
   dVXainRWHyEvcSqUemtpGCFLuwNsPo={'timestamp':dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_timestamp(timetype=1),'transactionId':dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_timestamp(timetype=1)+'000000000000001',}
  return dVXainRWHyEvcSqUemtpGCFLuwNsPo
 def make_EpgDatetime_Tving(dVXainRWHyEvcSqUemtpGCFLuwNsBT,days=2):
  dVXainRWHyEvcSqUemtpGCFLuwNsPf=[]
  dVXainRWHyEvcSqUemtpGCFLuwNsPD=dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_DateList(days=2,dateType='2')
  dVXainRWHyEvcSqUemtpGCFLuwNsPQ=dVXainRWHyEvcSqUemtpGCFLuwNsTP(dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsPD:
   for dVXainRWHyEvcSqUemtpGCFLuwNsPz in dVXainRWHyEvcSqUemtpGCFLuwNsTl(8):
    dVXainRWHyEvcSqUemtpGCFLuwNsPB={'ndate':dVXainRWHyEvcSqUemtpGCFLuwNsBI,'starttm':dVXainRWHyEvcSqUemtpGCFLuwNsBl[dVXainRWHyEvcSqUemtpGCFLuwNsPz]['starttm'],'endtm':dVXainRWHyEvcSqUemtpGCFLuwNsBl[dVXainRWHyEvcSqUemtpGCFLuwNsPz]['endtm']}
    dVXainRWHyEvcSqUemtpGCFLuwNsPO=dVXainRWHyEvcSqUemtpGCFLuwNsTP(dVXainRWHyEvcSqUemtpGCFLuwNsBI+dVXainRWHyEvcSqUemtpGCFLuwNsBl[dVXainRWHyEvcSqUemtpGCFLuwNsPz]['starttm'])
    dVXainRWHyEvcSqUemtpGCFLuwNsPh=dVXainRWHyEvcSqUemtpGCFLuwNsTP(dVXainRWHyEvcSqUemtpGCFLuwNsBI+dVXainRWHyEvcSqUemtpGCFLuwNsBl[dVXainRWHyEvcSqUemtpGCFLuwNsPz]['endtm'])
    if dVXainRWHyEvcSqUemtpGCFLuwNsPQ<=dVXainRWHyEvcSqUemtpGCFLuwNsPO or(dVXainRWHyEvcSqUemtpGCFLuwNsPO<dVXainRWHyEvcSqUemtpGCFLuwNsPQ and dVXainRWHyEvcSqUemtpGCFLuwNsPQ<dVXainRWHyEvcSqUemtpGCFLuwNsPh):
     dVXainRWHyEvcSqUemtpGCFLuwNsPf.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  return dVXainRWHyEvcSqUemtpGCFLuwNsPf
 def make_DateList(dVXainRWHyEvcSqUemtpGCFLuwNsBT,days=2,dateType='1'):
  dVXainRWHyEvcSqUemtpGCFLuwNsPD=[]
  dVXainRWHyEvcSqUemtpGCFLuwNsPb =dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_Now_Datetime()
  for i in dVXainRWHyEvcSqUemtpGCFLuwNsTl(days):
   dVXainRWHyEvcSqUemtpGCFLuwNsPK=dVXainRWHyEvcSqUemtpGCFLuwNsPb+datetime.timedelta(days=i)
   if dateType=='1':
    dVXainRWHyEvcSqUemtpGCFLuwNsPD.append(dVXainRWHyEvcSqUemtpGCFLuwNsPK.strftime('%Y-%m-%d'))
   else:
    dVXainRWHyEvcSqUemtpGCFLuwNsPD.append(dVXainRWHyEvcSqUemtpGCFLuwNsPK.strftime('%Y%m%d'))
  return dVXainRWHyEvcSqUemtpGCFLuwNsPD
 def make_Tving_ChannleGroup(dVXainRWHyEvcSqUemtpGCFLuwNsBT,dVXainRWHyEvcSqUemtpGCFLuwNsPr):
  dVXainRWHyEvcSqUemtpGCFLuwNsPk=[]
  i=0
  dVXainRWHyEvcSqUemtpGCFLuwNsPA=''
  for dVXainRWHyEvcSqUemtpGCFLuwNsPI in dVXainRWHyEvcSqUemtpGCFLuwNsPr:
   if i==0:dVXainRWHyEvcSqUemtpGCFLuwNsPA=dVXainRWHyEvcSqUemtpGCFLuwNsPI
   else:dVXainRWHyEvcSqUemtpGCFLuwNsPA+=',%s'%(dVXainRWHyEvcSqUemtpGCFLuwNsPI)
   i+=1
   if i>=dVXainRWHyEvcSqUemtpGCFLuwNsBT.LIMIT_TVINGEPG:
    dVXainRWHyEvcSqUemtpGCFLuwNsPk.append(dVXainRWHyEvcSqUemtpGCFLuwNsPA)
    i=0
    dVXainRWHyEvcSqUemtpGCFLuwNsPA=''
  if dVXainRWHyEvcSqUemtpGCFLuwNsPA!='':
   dVXainRWHyEvcSqUemtpGCFLuwNsPk.append(dVXainRWHyEvcSqUemtpGCFLuwNsPA)
  return dVXainRWHyEvcSqUemtpGCFLuwNsPk
 def Get_ChannelImg_Tving(dVXainRWHyEvcSqUemtpGCFLuwNsBT,chid_list):
  dVXainRWHyEvcSqUemtpGCFLuwNsPl={}
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsPM=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_Now_Datetime().strftime('%Y%m%d')
   dVXainRWHyEvcSqUemtpGCFLuwNsPJ =dVXainRWHyEvcSqUemtpGCFLuwNsBl[6]['starttm'] 
   dVXainRWHyEvcSqUemtpGCFLuwNsPT =dVXainRWHyEvcSqUemtpGCFLuwNsBl[6]['endtm']
   dVXainRWHyEvcSqUemtpGCFLuwNsPk=dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_Tving_ChannleGroup(chid_list)
   for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsPk:
    dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_TVING+'/v2/media/schedules'
    dVXainRWHyEvcSqUemtpGCFLuwNsBD={'pageNo':'1','pageSize':dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBT.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':dVXainRWHyEvcSqUemtpGCFLuwNsPM,'broadcastDate':dVXainRWHyEvcSqUemtpGCFLuwNsPM,'startBroadTime':dVXainRWHyEvcSqUemtpGCFLuwNsPJ,'endBroadTime':dVXainRWHyEvcSqUemtpGCFLuwNsPT,'channelCode':dVXainRWHyEvcSqUemtpGCFLuwNsBI}
    dVXainRWHyEvcSqUemtpGCFLuwNsBD.update(dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_DefaultParams_Tving())
    dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsBD,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
    dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
    if not('result' in dVXainRWHyEvcSqUemtpGCFLuwNsBk['body']):return{}
    dVXainRWHyEvcSqUemtpGCFLuwNsBA=dVXainRWHyEvcSqUemtpGCFLuwNsBk['body']['result']
    for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBA:
     for dVXainRWHyEvcSqUemtpGCFLuwNsPg in dVXainRWHyEvcSqUemtpGCFLuwNsBI['image']:
      if dVXainRWHyEvcSqUemtpGCFLuwNsPg['code']=='CAIC0400':dVXainRWHyEvcSqUemtpGCFLuwNsPl[dVXainRWHyEvcSqUemtpGCFLuwNsBI['channel_code']]=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_TVINGIMG+dVXainRWHyEvcSqUemtpGCFLuwNsPg['url']
      elif dVXainRWHyEvcSqUemtpGCFLuwNsPg['code']=='CAIC1400':dVXainRWHyEvcSqUemtpGCFLuwNsPl[dVXainRWHyEvcSqUemtpGCFLuwNsBI['channel_code']]=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_TVINGIMG+dVXainRWHyEvcSqUemtpGCFLuwNsPg['url']
      elif dVXainRWHyEvcSqUemtpGCFLuwNsPg['code']=='CAIC1900':dVXainRWHyEvcSqUemtpGCFLuwNsPl[dVXainRWHyEvcSqUemtpGCFLuwNsBI['channel_code']]=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_TVINGIMG+dVXainRWHyEvcSqUemtpGCFLuwNsPg['url']
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return{}
  return dVXainRWHyEvcSqUemtpGCFLuwNsPl
 def Get_EpgInfo_Spotv(dVXainRWHyEvcSqUemtpGCFLuwNsBT,days=2,payyn=dVXainRWHyEvcSqUemtpGCFLuwNsTB):
  dVXainRWHyEvcSqUemtpGCFLuwNsBO=[]
  dVXainRWHyEvcSqUemtpGCFLuwNsPx =[]
  dVXainRWHyEvcSqUemtpGCFLuwNsPD=dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_DateList(days=days,dateType='1')
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_SPOTV+'/api/v3/channel'
   dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsJM,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
   dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
   for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBk:
    dVXainRWHyEvcSqUemtpGCFLuwNsBM =dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBI['id'])
    dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBM,'channelnm':dVXainRWHyEvcSqUemtpGCFLuwNsBT.xmlText(dVXainRWHyEvcSqUemtpGCFLuwNsBI['name']),'channelimg':dVXainRWHyEvcSqUemtpGCFLuwNsBI['logo'],'ott':'spotv'}
    dVXainRWHyEvcSqUemtpGCFLuwNsBO.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[],[]
  try:
   for dVXainRWHyEvcSqUemtpGCFLuwNsPj in dVXainRWHyEvcSqUemtpGCFLuwNsPD:
    dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_SPOTV+'/api/v3/program/'+dVXainRWHyEvcSqUemtpGCFLuwNsPj
    dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsJM,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
    dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
    for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBk:
     dVXainRWHyEvcSqUemtpGCFLuwNsBM =dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBI['channelId'])
     dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBM,'title':dVXainRWHyEvcSqUemtpGCFLuwNsBT.xmlText(dVXainRWHyEvcSqUemtpGCFLuwNsBI['title']),'startTime':dVXainRWHyEvcSqUemtpGCFLuwNsBI['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':dVXainRWHyEvcSqUemtpGCFLuwNsBI['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     dVXainRWHyEvcSqUemtpGCFLuwNsPx.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
    time.sleep(dVXainRWHyEvcSqUemtpGCFLuwNsBT.SLEEP_TIME)
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[],[]
  '''
  try:
   for i_channel in channel_list:
    if i_channel['epgtype'] == 'spotvon':
     tmp_list = self.Get_EpgInfo_Spotv_spotvon(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    if i_channel['epgtype'] == 'spotvnet':
     tmp_list = self.Get_EpgInfo_Spotv_spotvnet(i_channel['channelid'], i_channel['epgnm'], days )
     if len(tmp_list) > 0 : epg_list.extend(tmp_list )
    time.sleep(self.SLEEP_TIME) #####
  except Exception as exception:
   print(exception)
   return [], []
  '''  
  return dVXainRWHyEvcSqUemtpGCFLuwNsBO,dVXainRWHyEvcSqUemtpGCFLuwNsPx
 def Get_EpgInfo_Spotv_spotvon(dVXainRWHyEvcSqUemtpGCFLuwNsBT,dVXainRWHyEvcSqUemtpGCFLuwNsBM,epgnm,days):
  dVXainRWHyEvcSqUemtpGCFLuwNsPx =[]
  dVXainRWHyEvcSqUemtpGCFLuwNsPD=dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_DateList(days=days,dateType='1')
  dVXainRWHyEvcSqUemtpGCFLuwNslB=''
  try:
   for dVXainRWHyEvcSqUemtpGCFLuwNsPj in dVXainRWHyEvcSqUemtpGCFLuwNsPD:
    dVXainRWHyEvcSqUemtpGCFLuwNsBb='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,dVXainRWHyEvcSqUemtpGCFLuwNsPj)
    dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsJM,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
    dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
    for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBk:
     dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBM,'title':dVXainRWHyEvcSqUemtpGCFLuwNsBT.xmlText(dVXainRWHyEvcSqUemtpGCFLuwNsBI['title']),'startTime':dVXainRWHyEvcSqUemtpGCFLuwNsBI['sch_date'].replace('-','')+dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBI['sch_hour']).zfill(2)+dVXainRWHyEvcSqUemtpGCFLuwNsBI['sch_min']+'00','ott':'spotv'}
     dVXainRWHyEvcSqUemtpGCFLuwNsPx.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
    dVXainRWHyEvcSqUemtpGCFLuwNslB=dVXainRWHyEvcSqUemtpGCFLuwNsPj
   for i in dVXainRWHyEvcSqUemtpGCFLuwNsTl(dVXainRWHyEvcSqUemtpGCFLuwNsTJ(dVXainRWHyEvcSqUemtpGCFLuwNsPx)):
    if i>0:dVXainRWHyEvcSqUemtpGCFLuwNsPx[i-1]['endTime']=dVXainRWHyEvcSqUemtpGCFLuwNsPx[i]['startTime']
    if i==dVXainRWHyEvcSqUemtpGCFLuwNsTJ(dVXainRWHyEvcSqUemtpGCFLuwNsPx)-1: dVXainRWHyEvcSqUemtpGCFLuwNsPx[i]['endTime']=dVXainRWHyEvcSqUemtpGCFLuwNslB+'240000'
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[]
  return dVXainRWHyEvcSqUemtpGCFLuwNsPx
 def Get_EpgInfo_Spotv_spotvnet(dVXainRWHyEvcSqUemtpGCFLuwNsBT,dVXainRWHyEvcSqUemtpGCFLuwNsBM,epgnm,days):
  dVXainRWHyEvcSqUemtpGCFLuwNsPx =[]
  dVXainRWHyEvcSqUemtpGCFLuwNsPD=dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_DateList(days=days,dateType='1')
  dVXainRWHyEvcSqUemtpGCFLuwNslB=''
  try:
   for dVXainRWHyEvcSqUemtpGCFLuwNsPj in dVXainRWHyEvcSqUemtpGCFLuwNsPD:
    dVXainRWHyEvcSqUemtpGCFLuwNsBb='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,dVXainRWHyEvcSqUemtpGCFLuwNsPj)
    dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsJM,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
    dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
    for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBk:
     dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBM,'title':dVXainRWHyEvcSqUemtpGCFLuwNsBT.xmlText(dVXainRWHyEvcSqUemtpGCFLuwNsBI['title']),'startTime':dVXainRWHyEvcSqUemtpGCFLuwNsBI['sch_date'].replace('-','')+dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBI['sch_hour']).zfill(2)+dVXainRWHyEvcSqUemtpGCFLuwNsBI['sch_min']+'00','ott':'spotv'}
     dVXainRWHyEvcSqUemtpGCFLuwNsPx.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
    dVXainRWHyEvcSqUemtpGCFLuwNslB=dVXainRWHyEvcSqUemtpGCFLuwNsPj
   for i in dVXainRWHyEvcSqUemtpGCFLuwNsTl(dVXainRWHyEvcSqUemtpGCFLuwNsTJ(dVXainRWHyEvcSqUemtpGCFLuwNsPx)):
    if i>0:dVXainRWHyEvcSqUemtpGCFLuwNsPx[i-1]['endTime']=dVXainRWHyEvcSqUemtpGCFLuwNsPx[i]['startTime']
    if i==dVXainRWHyEvcSqUemtpGCFLuwNsTJ(dVXainRWHyEvcSqUemtpGCFLuwNsPx)-1: dVXainRWHyEvcSqUemtpGCFLuwNsPx[i]['endTime']=dVXainRWHyEvcSqUemtpGCFLuwNslB+'240000'
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[]
  return dVXainRWHyEvcSqUemtpGCFLuwNsPx
 def Make_Wavve_TimeList(dVXainRWHyEvcSqUemtpGCFLuwNsBT,days=2):
  dVXainRWHyEvcSqUemtpGCFLuwNsPf=[]
  dVXainRWHyEvcSqUemtpGCFLuwNslP=[['00:00','03:00'],['03:00','06:00'],['06:00','09:00'],['09:00','12:00'],['12:00','15:00'],['15:00','18:00'],['18:00','21:00'],['21:00','24:00'],]
  dVXainRWHyEvcSqUemtpGCFLuwNslJ =dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_Now_Datetime()
  for i in dVXainRWHyEvcSqUemtpGCFLuwNsTl(days):
   dVXainRWHyEvcSqUemtpGCFLuwNslT =dVXainRWHyEvcSqUemtpGCFLuwNslJ+datetime.timedelta(days=+i)
   dVXainRWHyEvcSqUemtpGCFLuwNslY =dVXainRWHyEvcSqUemtpGCFLuwNslT.strftime('%Y-%m-%d')
   for dVXainRWHyEvcSqUemtpGCFLuwNslr in dVXainRWHyEvcSqUemtpGCFLuwNslP:
    dVXainRWHyEvcSqUemtpGCFLuwNslo=['{} {}'.format(dVXainRWHyEvcSqUemtpGCFLuwNslY,dVXainRWHyEvcSqUemtpGCFLuwNslr[0]),'{} {}'.format(dVXainRWHyEvcSqUemtpGCFLuwNslY,dVXainRWHyEvcSqUemtpGCFLuwNslr[1]),]
    dVXainRWHyEvcSqUemtpGCFLuwNsPf.append(dVXainRWHyEvcSqUemtpGCFLuwNslo)
  return dVXainRWHyEvcSqUemtpGCFLuwNsPf
 def Get_EpgInfo_Wavve(dVXainRWHyEvcSqUemtpGCFLuwNsBT,days=2,exceptGroup=[]):
  dVXainRWHyEvcSqUemtpGCFLuwNslf =[]
  dVXainRWHyEvcSqUemtpGCFLuwNsBO =[]
  dVXainRWHyEvcSqUemtpGCFLuwNsPx =[]
  dVXainRWHyEvcSqUemtpGCFLuwNsPf=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Make_Wavve_TimeList(days)
  try:
   for dVXainRWHyEvcSqUemtpGCFLuwNslr in dVXainRWHyEvcSqUemtpGCFLuwNsPf:
    dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_WAVVE+'/live/epgs'
    dVXainRWHyEvcSqUemtpGCFLuwNsBD={'limit':dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBT.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':dVXainRWHyEvcSqUemtpGCFLuwNslr[0],'enddatetime':dVXainRWHyEvcSqUemtpGCFLuwNslr[1],}
    dVXainRWHyEvcSqUemtpGCFLuwNsBD.update(dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_DefaultParams_Wavve())
    dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsBD,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
    dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
    dVXainRWHyEvcSqUemtpGCFLuwNslD=dVXainRWHyEvcSqUemtpGCFLuwNsBk['list']
    for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNslD:
     dVXainRWHyEvcSqUemtpGCFLuwNsBM =dVXainRWHyEvcSqUemtpGCFLuwNsBI['channelid']
     dVXainRWHyEvcSqUemtpGCFLuwNsBj=dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_getGenre(dVXainRWHyEvcSqUemtpGCFLuwNsBM,'wavve')
     dVXainRWHyEvcSqUemtpGCFLuwNsBx =dVXainRWHyEvcSqUemtpGCFLuwNsBI['channelimage']
     if not dVXainRWHyEvcSqUemtpGCFLuwNsBx.startswith('http://')and not dVXainRWHyEvcSqUemtpGCFLuwNsBx.startswith('https://'):
      dVXainRWHyEvcSqUemtpGCFLuwNsBx=dVXainRWHyEvcSqUemtpGCFLuwNsBT.HTTPTAG+dVXainRWHyEvcSqUemtpGCFLuwNsBx
     dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBM,'channelnm':dVXainRWHyEvcSqUemtpGCFLuwNsBT.xmlText(dVXainRWHyEvcSqUemtpGCFLuwNsBI['channelname']),'channelimg':dVXainRWHyEvcSqUemtpGCFLuwNsBx,'ott':'wavve'}
     if dVXainRWHyEvcSqUemtpGCFLuwNsBj not in exceptGroup and dVXainRWHyEvcSqUemtpGCFLuwNsBM not in dVXainRWHyEvcSqUemtpGCFLuwNslf:
      dVXainRWHyEvcSqUemtpGCFLuwNsBO.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
      dVXainRWHyEvcSqUemtpGCFLuwNslf.append(dVXainRWHyEvcSqUemtpGCFLuwNsBM)
     for dVXainRWHyEvcSqUemtpGCFLuwNslQ in dVXainRWHyEvcSqUemtpGCFLuwNsBI['list']:
      dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBI['channelid'],'title':dVXainRWHyEvcSqUemtpGCFLuwNsBT.xmlText(dVXainRWHyEvcSqUemtpGCFLuwNslQ['title']),'startTime':dVXainRWHyEvcSqUemtpGCFLuwNslQ['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':dVXainRWHyEvcSqUemtpGCFLuwNslQ['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
      if dVXainRWHyEvcSqUemtpGCFLuwNsBj not in exceptGroup and dVXainRWHyEvcSqUemtpGCFLuwNslQ['starttime']!=dVXainRWHyEvcSqUemtpGCFLuwNslQ['endtime']:
       dVXainRWHyEvcSqUemtpGCFLuwNsPx.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[],[]
  dVXainRWHyEvcSqUemtpGCFLuwNslz=dVXainRWHyEvcSqUemtpGCFLuwNsTJ(dVXainRWHyEvcSqUemtpGCFLuwNsPx)
  for i in(dVXainRWHyEvcSqUemtpGCFLuwNsTl(1,dVXainRWHyEvcSqUemtpGCFLuwNslz)):
   if dVXainRWHyEvcSqUemtpGCFLuwNsTP(dVXainRWHyEvcSqUemtpGCFLuwNsPx[i-1]['endTime'])+1==dVXainRWHyEvcSqUemtpGCFLuwNsTP(dVXainRWHyEvcSqUemtpGCFLuwNsPx[i]['startTime'])and dVXainRWHyEvcSqUemtpGCFLuwNsPx[i-1]['channelid']==dVXainRWHyEvcSqUemtpGCFLuwNsPx[i]['channelid']:
    dVXainRWHyEvcSqUemtpGCFLuwNsPx[i-1]['endTime']=dVXainRWHyEvcSqUemtpGCFLuwNsPx[i]['startTime']
  dVXainRWHyEvcSqUemtpGCFLuwNsJj(dVXainRWHyEvcSqUemtpGCFLuwNsTJ(dVXainRWHyEvcSqUemtpGCFLuwNsBO))
  return dVXainRWHyEvcSqUemtpGCFLuwNsBO,dVXainRWHyEvcSqUemtpGCFLuwNsPx
 def Get_EpgInfo_Tving(dVXainRWHyEvcSqUemtpGCFLuwNsBT,days=2):
  dVXainRWHyEvcSqUemtpGCFLuwNsBO=[]
  dVXainRWHyEvcSqUemtpGCFLuwNsPx =[]
  dVXainRWHyEvcSqUemtpGCFLuwNslf =[]
  dVXainRWHyEvcSqUemtpGCFLuwNslO =dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_EpgDatetime_Tving(days=days)
  dVXainRWHyEvcSqUemtpGCFLuwNsBO =dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_ChannelList_Tving()
  dVXainRWHyEvcSqUemtpGCFLuwNslh=[]
  for i in dVXainRWHyEvcSqUemtpGCFLuwNsTl(dVXainRWHyEvcSqUemtpGCFLuwNsTJ(dVXainRWHyEvcSqUemtpGCFLuwNsBO)):
   dVXainRWHyEvcSqUemtpGCFLuwNsBO[i]['channelnm']=dVXainRWHyEvcSqUemtpGCFLuwNsBT.xmlText(dVXainRWHyEvcSqUemtpGCFLuwNsBO[i]['channelnm'])
   dVXainRWHyEvcSqUemtpGCFLuwNslh.append(dVXainRWHyEvcSqUemtpGCFLuwNsBO[i]['channelid'])
  dVXainRWHyEvcSqUemtpGCFLuwNslb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_Tving_ChannleGroup(dVXainRWHyEvcSqUemtpGCFLuwNslh)
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_TVING+'/v2/media/schedules'
   for dVXainRWHyEvcSqUemtpGCFLuwNslr in dVXainRWHyEvcSqUemtpGCFLuwNslO:
    for dVXainRWHyEvcSqUemtpGCFLuwNslK in dVXainRWHyEvcSqUemtpGCFLuwNslb:
     dVXainRWHyEvcSqUemtpGCFLuwNsBD={'pageNo':'1','pageSize':dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsBT.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':dVXainRWHyEvcSqUemtpGCFLuwNslr['ndate'],'broadcastDate':dVXainRWHyEvcSqUemtpGCFLuwNslr['ndate'],'startBroadTime':dVXainRWHyEvcSqUemtpGCFLuwNslr['starttm'],'endBroadTime':dVXainRWHyEvcSqUemtpGCFLuwNslr['endtm'],'channelCode':dVXainRWHyEvcSqUemtpGCFLuwNslK}
     dVXainRWHyEvcSqUemtpGCFLuwNsBD.update(dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_DefaultParams_Tving())
     dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsBD,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
     dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
     dVXainRWHyEvcSqUemtpGCFLuwNsBA=dVXainRWHyEvcSqUemtpGCFLuwNsBk['body']['result']
     for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBA:
      if 'schedules' not in dVXainRWHyEvcSqUemtpGCFLuwNsBI:continue
      if dVXainRWHyEvcSqUemtpGCFLuwNsBI['schedules']==dVXainRWHyEvcSqUemtpGCFLuwNsJM:continue
      for dVXainRWHyEvcSqUemtpGCFLuwNslk in dVXainRWHyEvcSqUemtpGCFLuwNsBI['schedules']:
       dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNslk['schedule_code'],'title':dVXainRWHyEvcSqUemtpGCFLuwNsBT.xmlText(dVXainRWHyEvcSqUemtpGCFLuwNslk['program']['name']['ko']),'startTime':dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNslk['broadcast_start_time']),'endTime':dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNslk['broadcast_end_time']),'ott':'tving'}
       dVXainRWHyEvcSqUemtpGCFLuwNslA=dVXainRWHyEvcSqUemtpGCFLuwNslk['schedule_code']+dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNslk['broadcast_start_time'])
       if dVXainRWHyEvcSqUemtpGCFLuwNslA in dVXainRWHyEvcSqUemtpGCFLuwNslf:continue
       dVXainRWHyEvcSqUemtpGCFLuwNslf.append(dVXainRWHyEvcSqUemtpGCFLuwNslA)
       dVXainRWHyEvcSqUemtpGCFLuwNsPx.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
     time.sleep(dVXainRWHyEvcSqUemtpGCFLuwNsBT.SLEEP_TIME)
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[],[]
  return dVXainRWHyEvcSqUemtpGCFLuwNsBO,dVXainRWHyEvcSqUemtpGCFLuwNsPx
 def Get_BaseInfo_Samsungtv(dVXainRWHyEvcSqUemtpGCFLuwNsBT):
  dVXainRWHyEvcSqUemtpGCFLuwNslI={}
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_SAMSUNGTV
   dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsJM,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNsJM)
   for dVXainRWHyEvcSqUemtpGCFLuwNslM in dVXainRWHyEvcSqUemtpGCFLuwNsBK.cookies:
    if dVXainRWHyEvcSqUemtpGCFLuwNslM.name=='session':
     dVXainRWHyEvcSqUemtpGCFLuwNslI['session']=dVXainRWHyEvcSqUemtpGCFLuwNslM.value
    elif dVXainRWHyEvcSqUemtpGCFLuwNslM.name=='session.sig':
     dVXainRWHyEvcSqUemtpGCFLuwNslI['session.sig']=dVXainRWHyEvcSqUemtpGCFLuwNslM.value
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return{}
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_SAMSUNGTV+'/user'
   dVXainRWHyEvcSqUemtpGCFLuwNslg={'session':dVXainRWHyEvcSqUemtpGCFLuwNslI['session'],'session.sig':dVXainRWHyEvcSqUemtpGCFLuwNslI['session.sig'],}
   dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsJM,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJM,cookies=dVXainRWHyEvcSqUemtpGCFLuwNslg)
   dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
   dVXainRWHyEvcSqUemtpGCFLuwNslI['countryCode']=dVXainRWHyEvcSqUemtpGCFLuwNsBk.get('countryCode')
   dVXainRWHyEvcSqUemtpGCFLuwNslI['uuid'] =dVXainRWHyEvcSqUemtpGCFLuwNsBk.get('uuid')
   dVXainRWHyEvcSqUemtpGCFLuwNslI['ip'] =dVXainRWHyEvcSqUemtpGCFLuwNsBk.get('ip')
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return{}
  return dVXainRWHyEvcSqUemtpGCFLuwNslI
 def t_Cache(dVXainRWHyEvcSqUemtpGCFLuwNsBT):
  dVXainRWHyEvcSqUemtpGCFLuwNsPQ =dVXainRWHyEvcSqUemtpGCFLuwNsTP(time.time())
  dVXainRWHyEvcSqUemtpGCFLuwNslx=dVXainRWHyEvcSqUemtpGCFLuwNsTP(dVXainRWHyEvcSqUemtpGCFLuwNsPQ-dVXainRWHyEvcSqUemtpGCFLuwNsPQ%3600)
  return dVXainRWHyEvcSqUemtpGCFLuwNslx,dVXainRWHyEvcSqUemtpGCFLuwNsPQ
 def zlib_compress(dVXainRWHyEvcSqUemtpGCFLuwNsBT,plaintext):
  dVXainRWHyEvcSqUemtpGCFLuwNslj=zlib.compress(plaintext.encode('utf-8'))
  return base64.standard_b64encode(dVXainRWHyEvcSqUemtpGCFLuwNslj).decode('utf-8')
 def Get_BaseRequest_Samsungtv(dVXainRWHyEvcSqUemtpGCFLuwNsBT,dVXainRWHyEvcSqUemtpGCFLuwNslI):
  dVXainRWHyEvcSqUemtpGCFLuwNsBk={}
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBb=dVXainRWHyEvcSqUemtpGCFLuwNsBT.API_SAMSUNGTV+'/api/lives'
   dVXainRWHyEvcSqUemtpGCFLuwNslx,dVXainRWHyEvcSqUemtpGCFLuwNsPQ=dVXainRWHyEvcSqUemtpGCFLuwNsBT.t_Cache()
   dVXainRWHyEvcSqUemtpGCFLuwNsJB=dVXainRWHyEvcSqUemtpGCFLuwNsBT.zlib_compress(dVXainRWHyEvcSqUemtpGCFLuwNslI['uuid']+':'+dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNsPQ))
   dVXainRWHyEvcSqUemtpGCFLuwNslg={'session':dVXainRWHyEvcSqUemtpGCFLuwNslI['session'],'session.sig':dVXainRWHyEvcSqUemtpGCFLuwNslI['session.sig'],}
   dVXainRWHyEvcSqUemtpGCFLuwNsBD ={'t':dVXainRWHyEvcSqUemtpGCFLuwNsJg(dVXainRWHyEvcSqUemtpGCFLuwNslx)}
   dVXainRWHyEvcSqUemtpGCFLuwNsJP ={'x-cred-payload':dVXainRWHyEvcSqUemtpGCFLuwNsJB}
   dVXainRWHyEvcSqUemtpGCFLuwNsBK=dVXainRWHyEvcSqUemtpGCFLuwNsBT.callRequestCookies('Get',dVXainRWHyEvcSqUemtpGCFLuwNsBb,payload=dVXainRWHyEvcSqUemtpGCFLuwNsJM,params=dVXainRWHyEvcSqUemtpGCFLuwNsBD,headers=dVXainRWHyEvcSqUemtpGCFLuwNsJP,cookies=dVXainRWHyEvcSqUemtpGCFLuwNslg)
   dVXainRWHyEvcSqUemtpGCFLuwNsBk=json.loads(dVXainRWHyEvcSqUemtpGCFLuwNsBK.text)
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
  return dVXainRWHyEvcSqUemtpGCFLuwNsBk
 def Make_Samsungtv_logoUrl(dVXainRWHyEvcSqUemtpGCFLuwNsBT,fullUrl):
  dVXainRWHyEvcSqUemtpGCFLuwNsJl=urllib.parse.urlparse(fullUrl) 
  if dVXainRWHyEvcSqUemtpGCFLuwNsJl.netloc=='us-image.samsungtvplus.com':
   dVXainRWHyEvcSqUemtpGCFLuwNsJT=dVXainRWHyEvcSqUemtpGCFLuwNsTY(urllib.parse.parse_qsl(dVXainRWHyEvcSqUemtpGCFLuwNsJl.query))
   if 'url' in dVXainRWHyEvcSqUemtpGCFLuwNsJT:
    return dVXainRWHyEvcSqUemtpGCFLuwNsJT.get('url')
  return fullUrl
 def Get_ChannelList_Samsungtv(dVXainRWHyEvcSqUemtpGCFLuwNsBT,dVXainRWHyEvcSqUemtpGCFLuwNslI,exceptGroup=[]):
  dVXainRWHyEvcSqUemtpGCFLuwNsBO =[]
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBk=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_BaseRequest_Samsungtv(dVXainRWHyEvcSqUemtpGCFLuwNslI)
   dVXainRWHyEvcSqUemtpGCFLuwNsBA=dVXainRWHyEvcSqUemtpGCFLuwNsBk['live']['channel']
   for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsBA:
    dVXainRWHyEvcSqUemtpGCFLuwNsBM =dVXainRWHyEvcSqUemtpGCFLuwNsBI.get('id')
    dVXainRWHyEvcSqUemtpGCFLuwNsBg =dVXainRWHyEvcSqUemtpGCFLuwNsBI.get('name')
    dVXainRWHyEvcSqUemtpGCFLuwNsBx=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Make_Samsungtv_logoUrl(dVXainRWHyEvcSqUemtpGCFLuwNsBI.get('logo'))
    dVXainRWHyEvcSqUemtpGCFLuwNsBj=dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_getGenre(dVXainRWHyEvcSqUemtpGCFLuwNsBM,'samsung')
    if dVXainRWHyEvcSqUemtpGCFLuwNsBj in['-','']:dVXainRWHyEvcSqUemtpGCFLuwNsBj='정주행 채널'
    dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBM,'channelnm':dVXainRWHyEvcSqUemtpGCFLuwNsBg,'channelimg':dVXainRWHyEvcSqUemtpGCFLuwNsBx,'ott':'samsung','genrenm':dVXainRWHyEvcSqUemtpGCFLuwNsBj}
    if dVXainRWHyEvcSqUemtpGCFLuwNsBj not in exceptGroup:
     dVXainRWHyEvcSqUemtpGCFLuwNsBO.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[]
  return dVXainRWHyEvcSqUemtpGCFLuwNsBO
 def Get_EpgInfo_Samsungtv(dVXainRWHyEvcSqUemtpGCFLuwNsBT,dVXainRWHyEvcSqUemtpGCFLuwNslI,exceptGroup=[]):
  dVXainRWHyEvcSqUemtpGCFLuwNsBO=[]
  dVXainRWHyEvcSqUemtpGCFLuwNsPx =[]
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsBk =dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_BaseRequest_Samsungtv(dVXainRWHyEvcSqUemtpGCFLuwNslI)
   dVXainRWHyEvcSqUemtpGCFLuwNsBI=dVXainRWHyEvcSqUemtpGCFLuwNsBk['live']['channel']
   for dVXainRWHyEvcSqUemtpGCFLuwNslK in dVXainRWHyEvcSqUemtpGCFLuwNsBI:
    dVXainRWHyEvcSqUemtpGCFLuwNsBM =dVXainRWHyEvcSqUemtpGCFLuwNslK.get('id')
    dVXainRWHyEvcSqUemtpGCFLuwNsBg =dVXainRWHyEvcSqUemtpGCFLuwNslK.get('name')
    dVXainRWHyEvcSqUemtpGCFLuwNsBx=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Make_Samsungtv_logoUrl(dVXainRWHyEvcSqUemtpGCFLuwNslK.get('logo'))
    dVXainRWHyEvcSqUemtpGCFLuwNslD =dVXainRWHyEvcSqUemtpGCFLuwNslK.get('program')
    dVXainRWHyEvcSqUemtpGCFLuwNsBj=dVXainRWHyEvcSqUemtpGCFLuwNsBT.make_getGenre(dVXainRWHyEvcSqUemtpGCFLuwNsBM,'samsung')
    if dVXainRWHyEvcSqUemtpGCFLuwNsBj in exceptGroup:
     continue
    dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBM,'channelnm':dVXainRWHyEvcSqUemtpGCFLuwNsBg,'channelimg':dVXainRWHyEvcSqUemtpGCFLuwNsBx,'ott':'samsung','genrenm':dVXainRWHyEvcSqUemtpGCFLuwNsBj}
    dVXainRWHyEvcSqUemtpGCFLuwNsBO.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
    for dVXainRWHyEvcSqUemtpGCFLuwNslQ in dVXainRWHyEvcSqUemtpGCFLuwNslD:
     dVXainRWHyEvcSqUemtpGCFLuwNsJY=dVXainRWHyEvcSqUemtpGCFLuwNslQ.get('start_time')
     dVXainRWHyEvcSqUemtpGCFLuwNsJr =dVXainRWHyEvcSqUemtpGCFLuwNslQ.get('duration') 
     dVXainRWHyEvcSqUemtpGCFLuwNsPJ=datetime.datetime.strptime(dVXainRWHyEvcSqUemtpGCFLuwNsJY,'%Y-%m-%dT%H:%M:%SZ')+datetime.timedelta(hours=9)
     dVXainRWHyEvcSqUemtpGCFLuwNsPT =dVXainRWHyEvcSqUemtpGCFLuwNsPJ+datetime.timedelta(seconds=dVXainRWHyEvcSqUemtpGCFLuwNsJr)
     dVXainRWHyEvcSqUemtpGCFLuwNsPB={'channelid':dVXainRWHyEvcSqUemtpGCFLuwNsBM,'title':dVXainRWHyEvcSqUemtpGCFLuwNsBT.xmlText(urllib.parse.unquote_plus(dVXainRWHyEvcSqUemtpGCFLuwNslQ.get('title'))),'startTime':dVXainRWHyEvcSqUemtpGCFLuwNsPJ.strftime('%Y%m%d%H%M00'),'endTime':dVXainRWHyEvcSqUemtpGCFLuwNsPT.strftime('%Y%m%d%H%M00'),'ott':'samsung'}
     dVXainRWHyEvcSqUemtpGCFLuwNsPx.append(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  except dVXainRWHyEvcSqUemtpGCFLuwNsJx as exception:
   dVXainRWHyEvcSqUemtpGCFLuwNsJj(exception)
   return[],[]
  return dVXainRWHyEvcSqUemtpGCFLuwNsBO,dVXainRWHyEvcSqUemtpGCFLuwNsPx
 def make_getGenre(dVXainRWHyEvcSqUemtpGCFLuwNsBT,dVXainRWHyEvcSqUemtpGCFLuwNsBM,dVXainRWHyEvcSqUemtpGCFLuwNsJb):
  try:
   dVXainRWHyEvcSqUemtpGCFLuwNsPY=dVXainRWHyEvcSqUemtpGCFLuwNsBT.INIT_CHANNEL.get(dVXainRWHyEvcSqUemtpGCFLuwNsBM+'.'+dVXainRWHyEvcSqUemtpGCFLuwNsJb).get('genre')
  except:
   dVXainRWHyEvcSqUemtpGCFLuwNsPY=dVXainRWHyEvcSqUemtpGCFLuwNsBT.INIT_CHANNEL.get('-').get('genre')
  return dVXainRWHyEvcSqUemtpGCFLuwNsPY
 def make_base_allchannel_py(dVXainRWHyEvcSqUemtpGCFLuwNsBT,dVXainRWHyEvcSqUemtpGCFLuwNslI):
  dVXainRWHyEvcSqUemtpGCFLuwNsJo =[]
  dVXainRWHyEvcSqUemtpGCFLuwNsJf=[]
  dVXainRWHyEvcSqUemtpGCFLuwNsJD=dVXainRWHyEvcSqUemtpGCFLuwNsTr()
  dVXainRWHyEvcSqUemtpGCFLuwNsPB=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_ChannelList_Wavve()
  dVXainRWHyEvcSqUemtpGCFLuwNsJo.extend(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  dVXainRWHyEvcSqUemtpGCFLuwNsPB=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_ChannelList_Tving()
  dVXainRWHyEvcSqUemtpGCFLuwNsJo.extend(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  dVXainRWHyEvcSqUemtpGCFLuwNsPB=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_ChannelList_Spotv()
  dVXainRWHyEvcSqUemtpGCFLuwNsJo.extend(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  dVXainRWHyEvcSqUemtpGCFLuwNsPB=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_ChannelList_Samsungtv(dVXainRWHyEvcSqUemtpGCFLuwNslI)
  dVXainRWHyEvcSqUemtpGCFLuwNsJo.extend(dVXainRWHyEvcSqUemtpGCFLuwNsPB)
  dVXainRWHyEvcSqUemtpGCFLuwNsJj('1')
  for i in dVXainRWHyEvcSqUemtpGCFLuwNsTl(dVXainRWHyEvcSqUemtpGCFLuwNsTJ(dVXainRWHyEvcSqUemtpGCFLuwNsJo)):
   if dVXainRWHyEvcSqUemtpGCFLuwNsJo[i]['genrenm']=='-':
    if dVXainRWHyEvcSqUemtpGCFLuwNsJo[i]['ott']=='wavve':
     dVXainRWHyEvcSqUemtpGCFLuwNsPY=dVXainRWHyEvcSqUemtpGCFLuwNsBT.Get_ChanneGenrename_Wavve(dVXainRWHyEvcSqUemtpGCFLuwNsJo[i]['channelid'])
     if dVXainRWHyEvcSqUemtpGCFLuwNsPY not in dVXainRWHyEvcSqUemtpGCFLuwNsJD:dVXainRWHyEvcSqUemtpGCFLuwNsJD.add(dVXainRWHyEvcSqUemtpGCFLuwNsPY)
     time.sleep(dVXainRWHyEvcSqUemtpGCFLuwNsBT.SLEEP_TIME)
    elif dVXainRWHyEvcSqUemtpGCFLuwNsJo[i]['ott']=='spotv':
     dVXainRWHyEvcSqUemtpGCFLuwNsPY='스포츠'
    else:
     dVXainRWHyEvcSqUemtpGCFLuwNsPY='-'
    dVXainRWHyEvcSqUemtpGCFLuwNsJo[i]['genrenm']=dVXainRWHyEvcSqUemtpGCFLuwNsPY
   else:
    if dVXainRWHyEvcSqUemtpGCFLuwNsJo[i]['genrenm']not in dVXainRWHyEvcSqUemtpGCFLuwNsJD:dVXainRWHyEvcSqUemtpGCFLuwNsJD.add(dVXainRWHyEvcSqUemtpGCFLuwNsJo[i]['genrenm'])
  dVXainRWHyEvcSqUemtpGCFLuwNsJD.add(dVXainRWHyEvcSqUemtpGCFLuwNsBT.INIT_CHANNEL.get('-').get('genre'))
  dVXainRWHyEvcSqUemtpGCFLuwNsJj('2')
  for dVXainRWHyEvcSqUemtpGCFLuwNsJQ in dVXainRWHyEvcSqUemtpGCFLuwNsJD:
   for dVXainRWHyEvcSqUemtpGCFLuwNsJz in dVXainRWHyEvcSqUemtpGCFLuwNsJo:
    if dVXainRWHyEvcSqUemtpGCFLuwNsJz['genrenm']==dVXainRWHyEvcSqUemtpGCFLuwNsJQ:
     dVXainRWHyEvcSqUemtpGCFLuwNsJf.append(dVXainRWHyEvcSqUemtpGCFLuwNsJz)
  for dVXainRWHyEvcSqUemtpGCFLuwNsJz in dVXainRWHyEvcSqUemtpGCFLuwNsJo:
   if dVXainRWHyEvcSqUemtpGCFLuwNsJz['genrenm']not in dVXainRWHyEvcSqUemtpGCFLuwNsJD:
    dVXainRWHyEvcSqUemtpGCFLuwNsJf.append(dVXainRWHyEvcSqUemtpGCFLuwNsJz)
  dVXainRWHyEvcSqUemtpGCFLuwNsJj('3')
  dVXainRWHyEvcSqUemtpGCFLuwNsJO='d:\\Naver MYBOX\\sync\\job\\channelgenre.json'
  if os.path.isfile(dVXainRWHyEvcSqUemtpGCFLuwNsJO):os.remove(dVXainRWHyEvcSqUemtpGCFLuwNsJO)
  fp=dVXainRWHyEvcSqUemtpGCFLuwNsTo(dVXainRWHyEvcSqUemtpGCFLuwNsJO,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  dVXainRWHyEvcSqUemtpGCFLuwNsJh=dVXainRWHyEvcSqUemtpGCFLuwNsTJ(dVXainRWHyEvcSqUemtpGCFLuwNsJf)
  i=0
  for dVXainRWHyEvcSqUemtpGCFLuwNsBI in dVXainRWHyEvcSqUemtpGCFLuwNsJf:
   i+=1
   dVXainRWHyEvcSqUemtpGCFLuwNsBM =dVXainRWHyEvcSqUemtpGCFLuwNsBI['channelid']
   dVXainRWHyEvcSqUemtpGCFLuwNsBg =dVXainRWHyEvcSqUemtpGCFLuwNsBI['channelnm']
   dVXainRWHyEvcSqUemtpGCFLuwNsJb =dVXainRWHyEvcSqUemtpGCFLuwNsBI['ott']
   dVXainRWHyEvcSqUemtpGCFLuwNsJK ='%s.%s'%(dVXainRWHyEvcSqUemtpGCFLuwNsBM,dVXainRWHyEvcSqUemtpGCFLuwNsJb)
   dVXainRWHyEvcSqUemtpGCFLuwNsPY =dVXainRWHyEvcSqUemtpGCFLuwNsBI['genrenm']
   dVXainRWHyEvcSqUemtpGCFLuwNsJk='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(dVXainRWHyEvcSqUemtpGCFLuwNsJK,dVXainRWHyEvcSqUemtpGCFLuwNsBg,dVXainRWHyEvcSqUemtpGCFLuwNsPY)
   if i<dVXainRWHyEvcSqUemtpGCFLuwNsJh:
    fp.write(dVXainRWHyEvcSqUemtpGCFLuwNsJk+',\n')
   else:
    fp.write(dVXainRWHyEvcSqUemtpGCFLuwNsJk+'\n')
  fp.write('}\n')
  fp.close()
  return dVXainRWHyEvcSqUemtpGCFLuwNsJD
# Created by pyminifier (https://github.com/liftoff/pyminifier)
