__author__="NightRain"
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHe=object
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr=False
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHD=None
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS=True
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHY=getattr
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHa=type
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHw=int
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHp=list
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN=len
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHT=str
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHl=open
MFJGhkvsnQdtOLmoWuPfVEbKcIxyHA=Exception
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
MFJGhkvsnQdtOLmoWuPfVEbKcIxyqR=[{'title':'*** 간단설명 (개별 OTT 애드온 필수) ***','mode':'XXX'},{'title':'     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)','mode':'XXX'},{'title':'     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)','mode':'XXX'},{'title':'-----------------','mode':'XXX'},{'title':'-> M3U 파일 초기화/삭제','mode':'DEL_M3U'},{'title':'     - M3U 추가 (웨이브)','mode':'ADD_M3U','sType':'wavve','sName':'웨이브'},{'title':'     - M3U 추가 (티빙)','mode':'ADD_M3U','sType':'tving','sName':'티빙'},{'title':'     - M3U 추가 (스포티비)','mode':'ADD_M3U','sType':'spotv','sName':'스포티비나우'},{'title':'     - M3U 추가 (삼성tv 플러스)','mode':'ADD_M3U','sType':'samsung','sName':'삼성TV 플러스'},{'title':'     - M3U 추가 (사용자 m3u)','mode':'ADD_M3U','sType':'custom','sName':'사용자 m3u 파일'},{'title':'-> M3U (삭제후 일괄생성)','mode':'ADD_M3U','sType':'all','sName':'전체'},{'title':'-----------------','mode':'XXX'},{'title':'-> EPG 생성 (삭제후 일괄생성)','mode':'ADD_EPG','sType':'all','sName':'전체'},]
MFJGhkvsnQdtOLmoWuPfVEbKcIxyqH={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
__addon__ =xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__ =xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__ =__addon__.getAddonInfo('version')
__addonid__ =__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MFJGhkvsnQdtOLmoWuPfVEbKcIxyqB=xbmcvfs.translatePath(os.path.join(__profile__,'boritv_update.json'))
from boritvCore import*
class MFJGhkvsnQdtOLmoWuPfVEbKcIxyqi(MFJGhkvsnQdtOLmoWuPfVEbKcIxyHe):
 def __init__(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqX,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqU,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqe):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz._addon_url =MFJGhkvsnQdtOLmoWuPfVEbKcIxyqX
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz._addon_handle =MFJGhkvsnQdtOLmoWuPfVEbKcIxyqU
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.main_params =MFJGhkvsnQdtOLmoWuPfVEbKcIxyqe
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_FILE_PATH ='' 
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_FILE_NAME ='' 
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVE =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONTVING =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSPOTV =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSAMSUNG =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVERADIO =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVEHOME =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONRELIGION =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSPOTVPAY =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSAMSUNGHOME=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_DISPLAYNM =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_AUTORESTART =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_CUSTOM_LIST =[]
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj =dVXainRWHyEvcSqUemtpGCFLuwNsBP() 
 def addon_noti(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,sting):
  try:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqD=xbmcgui.Dialog()
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqD.notification(__addonname__,sting)
  except:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyHD
 def addon_log(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,string):
  try:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqS=string.encode('utf-8','ignore')
  except:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqS='addonException: addon_log'
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqY=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqS),level=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqY)
 def get_keyboard_input(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqp):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqa=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHD
  kb=xbmc.Keyboard()
  kb.setHeading(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqp)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqa=kb.getText()
  return MFJGhkvsnQdtOLmoWuPfVEbKcIxyqa
 def add_dir(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,label,sublabel='',img='',infoLabels=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHD,isFolder=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS,params='',isLink=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr,ContextMenu=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHD):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqw='%s?%s'%(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz._addon_url,urllib.parse.urlencode(params))
  if sublabel:MFJGhkvsnQdtOLmoWuPfVEbKcIxyqp='%s < %s >'%(label,sublabel)
  else: MFJGhkvsnQdtOLmoWuPfVEbKcIxyqp=label
  if not img:img='DefaultFolder.png'
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqN=xbmcgui.ListItem(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqp)
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqN.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.KodiVersion>=20:
   if infoLabels:MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.Set_InfoTag(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqN.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:MFJGhkvsnQdtOLmoWuPfVEbKcIxyqN.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqN.setProperty('IsPlayable','true')
  if ContextMenu:MFJGhkvsnQdtOLmoWuPfVEbKcIxyqN.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz._addon_handle,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqw,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqN,isFolder)
 def Set_InfoTag(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,video_InfoTag:xbmc.InfoTagVideo,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqj):
  for MFJGhkvsnQdtOLmoWuPfVEbKcIxyqT,value in MFJGhkvsnQdtOLmoWuPfVEbKcIxyqj.items():
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqH[MFJGhkvsnQdtOLmoWuPfVEbKcIxyqT]['type']=='string':
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyHY(video_InfoTag,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqH[MFJGhkvsnQdtOLmoWuPfVEbKcIxyqT]['func'])(value)
   elif MFJGhkvsnQdtOLmoWuPfVEbKcIxyqH[MFJGhkvsnQdtOLmoWuPfVEbKcIxyqT]['type']=='int':
    if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHa(value)==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHw:
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyql=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHw(value)
    else:
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyql=0
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyHY(video_InfoTag,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqH[MFJGhkvsnQdtOLmoWuPfVEbKcIxyqT]['func'])(MFJGhkvsnQdtOLmoWuPfVEbKcIxyql)
   elif MFJGhkvsnQdtOLmoWuPfVEbKcIxyqH[MFJGhkvsnQdtOLmoWuPfVEbKcIxyqT]['type']=='actor':
    if value!=[]:
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyHY(video_InfoTag,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqH[MFJGhkvsnQdtOLmoWuPfVEbKcIxyqT]['func'])([xbmc.Actor(name)for name in value])
   elif MFJGhkvsnQdtOLmoWuPfVEbKcIxyqH[MFJGhkvsnQdtOLmoWuPfVEbKcIxyqT]['type']=='list':
    if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHa(value)==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHp:
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyHY(video_InfoTag,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqH[MFJGhkvsnQdtOLmoWuPfVEbKcIxyqT]['func'])(value)
    else:
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyHY(video_InfoTag,MFJGhkvsnQdtOLmoWuPfVEbKcIxyqH[MFJGhkvsnQdtOLmoWuPfVEbKcIxyqT]['func'])([value])
 def make_M3u_Filename(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.m3u'))
  else:
   return MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_FILE_PATH+MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_FILE_NAME+'.m3u'
 def make_Epg_Filename(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'boritv_temp.xml'))
  else:
   return MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_FILE_PATH+MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_FILE_NAME+'.xml'
 def dp_Main_List(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz):
  for MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA in MFJGhkvsnQdtOLmoWuPfVEbKcIxyqR:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqp=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('title')
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqC=''
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqg={'mode':MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('mode'),'sType':MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('sType'),'sName':MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('sName')}
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqj={'title':MFJGhkvsnQdtOLmoWuPfVEbKcIxyqp,'plot':MFJGhkvsnQdtOLmoWuPfVEbKcIxyqp}
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('mode')=='XXX':
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyiq=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyiR =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS
   else:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyiq=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyiR =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyiH=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('mode')=='ADD_M3U':
    if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('sType')=='wavve' and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVE ==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:MFJGhkvsnQdtOLmoWuPfVEbKcIxyiH=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
    if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('sType')=='tving' and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONTVING ==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:MFJGhkvsnQdtOLmoWuPfVEbKcIxyiH=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
    if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('sType')=='spotv' and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSPOTV ==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:MFJGhkvsnQdtOLmoWuPfVEbKcIxyiH=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
    if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('sType')=='samsung' and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSAMSUNG==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:MFJGhkvsnQdtOLmoWuPfVEbKcIxyiH=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
    if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('sType')=='custom' and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_CUSTOM_LIST==[]:MFJGhkvsnQdtOLmoWuPfVEbKcIxyiH=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyiH==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS:
    if 'icon' in MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA:MFJGhkvsnQdtOLmoWuPfVEbKcIxyqC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',MFJGhkvsnQdtOLmoWuPfVEbKcIxyqA.get('icon')) 
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.add_dir(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqp,sublabel='',img=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqC,infoLabels=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqj,isFolder=MFJGhkvsnQdtOLmoWuPfVEbKcIxyiq,params=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqg,isLink=MFJGhkvsnQdtOLmoWuPfVEbKcIxyiR)
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqR)>0:xbmcplugin.endOfDirectory(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz._addon_handle,cacheToDisc=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS)
 def dp_Delete_M3u(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,args):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqD=xbmcgui.Dialog()
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyiz=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqD.yesno(__language__(30903).encode('utf8'),__language__(30904).encode('utf8'))
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyiz==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:sys.exit()
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_M3u_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr)
  if xbmcvfs.exists(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX):
   if xbmcvfs.delete(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX)==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti(__language__(30910).encode('utf-8'))
    return
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti(__language__(30905).encode('utf-8'))
 def dp_MakeAdd_M3u(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,args):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=args.get('sType')
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyie=args.get('sName')
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqD=xbmcgui.Dialog()
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyiz=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqD.yesno((MFJGhkvsnQdtOLmoWuPfVEbKcIxyie+__language__(30906)).encode('utf8'),__language__(30907).encode('utf8'))
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyiz==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:sys.exit()
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyir =[]
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyiD =[]
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_M3u_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS)
  if os.path.isfile(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX):os.remove(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX)
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='all':
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_M3u_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr)
   if xbmcvfs.exists(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX):
    if xbmcvfs.delete(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX)==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti(__language__(30910).encode('utf-8'))
     return
  else:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyiS=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_M3u_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr)
   if xbmcvfs.exists(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiS):
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyiY=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_M3u_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS)
    xbmcvfs.copy(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiS,MFJGhkvsnQdtOLmoWuPfVEbKcIxyiY)
  if(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='wavve' or MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='all')and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVE:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyia=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_ChannelList_Wavve(exceptGroup=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_EexceptGroup_Wavve())
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)!=0:MFJGhkvsnQdtOLmoWuPfVEbKcIxyir.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_log('wavve cnt ----> '+MFJGhkvsnQdtOLmoWuPfVEbKcIxyHT(MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)))
  if(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='tving' or MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='all')and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONTVING:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyia=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_ChannelList_Tving()
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)!=0:MFJGhkvsnQdtOLmoWuPfVEbKcIxyir.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_log('tving cnt ----> '+MFJGhkvsnQdtOLmoWuPfVEbKcIxyHT(MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)))
  if(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='spotv' or MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='all')and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSPOTV:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyia=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_ChannelList_Spotv(payyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSPOTVPAY)
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)!=0:MFJGhkvsnQdtOLmoWuPfVEbKcIxyir.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_log('spotv cnt ----> '+MFJGhkvsnQdtOLmoWuPfVEbKcIxyHT(MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)))
  if(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='samsung' or MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='all')and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSAMSUNG:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyiw=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_BaseInfo_Samsungtv()
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyia=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_ChannelList_Samsungtv(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiw,exceptGroup=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_EexceptGroup_Samsungtv())
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)!=0:MFJGhkvsnQdtOLmoWuPfVEbKcIxyir.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_log('samsungtv cnt ----> '+MFJGhkvsnQdtOLmoWuPfVEbKcIxyHT(MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyia)))
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyir)==0 and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_CUSTOM_LIST==[]:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti(__language__(30909).encode('utf8'))
   return
  for MFJGhkvsnQdtOLmoWuPfVEbKcIxyip in MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.INIT_GENRESORT:
   for MFJGhkvsnQdtOLmoWuPfVEbKcIxyiN in MFJGhkvsnQdtOLmoWuPfVEbKcIxyir:
    if MFJGhkvsnQdtOLmoWuPfVEbKcIxyiN['genrenm']==MFJGhkvsnQdtOLmoWuPfVEbKcIxyip:
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyiD.append(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiN)
  for MFJGhkvsnQdtOLmoWuPfVEbKcIxyiN in MFJGhkvsnQdtOLmoWuPfVEbKcIxyir:
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyiN['genrenm']not in MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.INIT_GENRESORT:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyiD.append(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiN)
  try:
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyir)>0:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_M3u_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS)
    if os.path.isfile(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX):
     fp=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHl(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX,'a',-1,'utf-8')
    else:
     fp=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHl(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for MFJGhkvsnQdtOLmoWuPfVEbKcIxyiT in MFJGhkvsnQdtOLmoWuPfVEbKcIxyiD:
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyil =MFJGhkvsnQdtOLmoWuPfVEbKcIxyiT['channelid']
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyiA =MFJGhkvsnQdtOLmoWuPfVEbKcIxyiT['channelnm']
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyiC=MFJGhkvsnQdtOLmoWuPfVEbKcIxyiT['channelimg']
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyig =MFJGhkvsnQdtOLmoWuPfVEbKcIxyiT['ott']
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyij ='%s.%s'%(MFJGhkvsnQdtOLmoWuPfVEbKcIxyil,MFJGhkvsnQdtOLmoWuPfVEbKcIxyig)
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyRq=MFJGhkvsnQdtOLmoWuPfVEbKcIxyiT['genrenm']
     if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_DISPLAYNM:
      MFJGhkvsnQdtOLmoWuPfVEbKcIxyiA='%s (%s)'%(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiA,MFJGhkvsnQdtOLmoWuPfVEbKcIxyig)
     if MFJGhkvsnQdtOLmoWuPfVEbKcIxyRq=='라디오/음악':
      MFJGhkvsnQdtOLmoWuPfVEbKcIxyRi='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n'%(MFJGhkvsnQdtOLmoWuPfVEbKcIxyij,MFJGhkvsnQdtOLmoWuPfVEbKcIxyiA,MFJGhkvsnQdtOLmoWuPfVEbKcIxyRq,MFJGhkvsnQdtOLmoWuPfVEbKcIxyiC,MFJGhkvsnQdtOLmoWuPfVEbKcIxyiA)
     else:
      MFJGhkvsnQdtOLmoWuPfVEbKcIxyRi='#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n'%(MFJGhkvsnQdtOLmoWuPfVEbKcIxyij,MFJGhkvsnQdtOLmoWuPfVEbKcIxyiA,MFJGhkvsnQdtOLmoWuPfVEbKcIxyRq,MFJGhkvsnQdtOLmoWuPfVEbKcIxyiC,MFJGhkvsnQdtOLmoWuPfVEbKcIxyiA)
     if MFJGhkvsnQdtOLmoWuPfVEbKcIxyig=='wavve':
      MFJGhkvsnQdtOLmoWuPfVEbKcIxyRH ='plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n'%(MFJGhkvsnQdtOLmoWuPfVEbKcIxyil)
     elif MFJGhkvsnQdtOLmoWuPfVEbKcIxyig=='tving':
      MFJGhkvsnQdtOLmoWuPfVEbKcIxyRH ='plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n'%(MFJGhkvsnQdtOLmoWuPfVEbKcIxyil)
     elif MFJGhkvsnQdtOLmoWuPfVEbKcIxyig=='spotv':
      MFJGhkvsnQdtOLmoWuPfVEbKcIxyRH ='plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n'%(MFJGhkvsnQdtOLmoWuPfVEbKcIxyil)
     if MFJGhkvsnQdtOLmoWuPfVEbKcIxyig=='samsung':
      MFJGhkvsnQdtOLmoWuPfVEbKcIxyRH ='plugin://plugin.video.samsungtvm/?mode=LIVE&chid=%s\n'%(MFJGhkvsnQdtOLmoWuPfVEbKcIxyil)
     fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRi)
     fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRH)
    fp.close()
  except:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti(__language__(30910).encode('utf8'))
   return
  try:
   if(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='custom' or MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='all')and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_CUSTOM_LIST!=[]:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_M3u_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS)
    if os.path.isfile(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX):
     fp=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHl(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX,'a',-1,'utf-8')
    else:
     fp=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHl(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX,'w',-1,'utf-8')
     fp.write('#EXTM3U\n')
    for MFJGhkvsnQdtOLmoWuPfVEbKcIxyRB in MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_CUSTOM_LIST:
     MFJGhkvsnQdtOLmoWuPfVEbKcIxyRz=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.customEpg_FileRead(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRB)
     for MFJGhkvsnQdtOLmoWuPfVEbKcIxyRX in MFJGhkvsnQdtOLmoWuPfVEbKcIxyRz:
      MFJGhkvsnQdtOLmoWuPfVEbKcIxyRX=MFJGhkvsnQdtOLmoWuPfVEbKcIxyRX.strip()
      if MFJGhkvsnQdtOLmoWuPfVEbKcIxyRX not in['','#EXTM3U']:
       fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRX+'\n')
   fp.close()
  except:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti(__language__(30910).encode('utf8'))
   return
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyiS=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_M3u_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS)
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyiY=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_M3u_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr)
  if xbmcvfs.copy(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiS,MFJGhkvsnQdtOLmoWuPfVEbKcIxyiY):
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti((MFJGhkvsnQdtOLmoWuPfVEbKcIxyie+' '+__language__(30908)).encode('utf8'))
  else:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti(__language__(30910).encode('utf-8'))
 def customEpg_FileList(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyRU=[]
  if __addon__.getSetting('custom01on')=='true':MFJGhkvsnQdtOLmoWuPfVEbKcIxyRU.append(__addon__.getSetting('custom01nm'))
  if __addon__.getSetting('custom02on')=='true':MFJGhkvsnQdtOLmoWuPfVEbKcIxyRU.append(__addon__.getSetting('custom02nm'))
  if __addon__.getSetting('custom03on')=='true':MFJGhkvsnQdtOLmoWuPfVEbKcIxyRU.append(__addon__.getSetting('custom03nm'))
  if __addon__.getSetting('custom04on')=='true':MFJGhkvsnQdtOLmoWuPfVEbKcIxyRU.append(__addon__.getSetting('custom04nm'))
  if __addon__.getSetting('custom05on')=='true':MFJGhkvsnQdtOLmoWuPfVEbKcIxyRU.append(__addon__.getSetting('custom05nm'))
  return MFJGhkvsnQdtOLmoWuPfVEbKcIxyRU
 def customEpg_FileRead(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,source_filename):
  try:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyRe=xbmcvfs.translatePath(os.path.join(__profile__,'custom_temp.m3u'))
   if os.path.isfile(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRe):os.remove(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRe)
   xbmcvfs.copy(source_filename,MFJGhkvsnQdtOLmoWuPfVEbKcIxyRe)
   fp=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHl(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRe,'r',-1,'utf-8')
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyRr=fp.readlines()
  except:
   return[]
  return MFJGhkvsnQdtOLmoWuPfVEbKcIxyRr
 def dp_Make_Epg(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz,args):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=args.get('sType')
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyie=args.get('sName')
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyRD=args.get('sNoti')
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyRD!='N':
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqD=xbmcgui.Dialog()
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyiz=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqD.yesno((MFJGhkvsnQdtOLmoWuPfVEbKcIxyie+__language__(30911)).encode('utf8'),__language__(30907).encode('utf8'))
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyiz==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:sys.exit()
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyRS=[]
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyRY=[]
  if(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='wavve' or MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='all')and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVE:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyRa,MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_EpgInfo_Wavve(exceptGroup=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_EexceptGroup_Wavve())
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw)!=0:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRS.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRa)
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRY.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw)
  if(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='tving' or MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='all')and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONTVING:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyRa,MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_EpgInfo_Tving()
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw)!=0:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRS.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRa)
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRY.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw)
  if(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='spotv' or MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='all')and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSPOTV:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyRa,MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_EpgInfo_Spotv(payyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSPOTVPAY)
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw)!=0:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRS.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRa)
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRY.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw)
  if(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='samsung' or MFJGhkvsnQdtOLmoWuPfVEbKcIxyiU=='all')and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSAMSUNG:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyiw=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_BaseInfo_Samsungtv()
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyRa,MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_EpgInfo_Samsungtv(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiw,exceptGroup=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_EexceptGroup_Samsungtv())
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw)!=0:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRS.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRa)
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRY.extend(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRw)
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHN(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRY)==0:
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyRD!='N':MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti(__language__(30909).encode('utf8'))
   return
  try:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_Epg_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS)
   fp=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHl(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiX,'w',-1,'utf-8')
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyRp='<?xml version="1.0" encoding="UTF-8"?>\n'
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyRN='<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyRT='<tv generator-info-name="boritv_epg">\n\n'
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyRl='\n</tv>\n'
   fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRp)
   fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRN)
   fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRT)
   for MFJGhkvsnQdtOLmoWuPfVEbKcIxyRA in MFJGhkvsnQdtOLmoWuPfVEbKcIxyRS:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRC='  <channel id="%s.%s">\n' %(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRA.get('channelid'),MFJGhkvsnQdtOLmoWuPfVEbKcIxyRA.get('ott'))
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRg='    <display-name>%s</display-name>\n'%(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRA.get('channelnm'))
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRj='    <icon src="%s" />\n' %(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRA.get('channelimg'))
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyHq='  </channel>\n\n'
    fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRC)
    fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRg)
    fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRj)
    fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyHq)
   for MFJGhkvsnQdtOLmoWuPfVEbKcIxyRA in MFJGhkvsnQdtOLmoWuPfVEbKcIxyRY:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRC='  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n'%(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRA.get('startTime'),MFJGhkvsnQdtOLmoWuPfVEbKcIxyRA.get('endTime'),MFJGhkvsnQdtOLmoWuPfVEbKcIxyRA.get('channelid'),MFJGhkvsnQdtOLmoWuPfVEbKcIxyRA.get('ott'))
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRg='    <title lang="kr">%s</title>\n' %(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRA.get('title'))
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyRj='  </programme>\n\n'
    fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRC)
    fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRg)
    fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRj)
   fp.write(MFJGhkvsnQdtOLmoWuPfVEbKcIxyRl)
   fp.close()
  except:
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyRD!='N':MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti(__language__(30910).encode('utf8'))
   return
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.MakeEpg_SaveJson()
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyiS=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_Epg_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS)
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyiY=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.make_Epg_Filename(tempyn=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr)
  if xbmcvfs.copy(MFJGhkvsnQdtOLmoWuPfVEbKcIxyiS,MFJGhkvsnQdtOLmoWuPfVEbKcIxyiY):
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyRD!='N':MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti((MFJGhkvsnQdtOLmoWuPfVEbKcIxyie+' '+__language__(30912)).encode('utf8'))
  else:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.addon_noti(__language__(30910).encode('utf-8'))
  try:
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_AUTORESTART:
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyHi=xbmcaddon.Addon('pvr.iptvsimple')
    MFJGhkvsnQdtOLmoWuPfVEbKcIxyHi.setSetting('anything','anything')
  except:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyHD 
 def make_EexceptGroup_Wavve(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyHR=[]
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVERADIO==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyHR.append('라디오/음악')
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVEHOME==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyHR.append('홈쇼핑')
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONRELIGION==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyHR.append('종교')
  return MFJGhkvsnQdtOLmoWuPfVEbKcIxyHR
 def make_EexceptGroup_Samsungtv(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyHR=[]
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSAMSUNGHOME==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyHR.append('홈쇼핑')
  return MFJGhkvsnQdtOLmoWuPfVEbKcIxyHR
 def get_radio_list(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz):
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVERADIO==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:return[]
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyHB=[{'broadcastid':'46584','genre':'10'}]
  return MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_ChannelList_WavveExcept(MFJGhkvsnQdtOLmoWuPfVEbKcIxyHB)
 def check_config(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyHz=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_FILE_PATH =(__addon__.getSetting('m3uFilepath')).strip()
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_FILE_NAME =(__addon__.getSetting('m3uFilename')).strip()
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVE =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS if __addon__.getSetting('onWavve')=='true' else MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONTVING =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS if __addon__.getSetting('onTvng')=='true' else MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSPOTV =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS if __addon__.getSetting('onSpotv')=='true' else MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSAMSUNG =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS if __addon__.getSetting('onSamsung')=='true' else MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVERADIO =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS if __addon__.getSetting('onWavveRadio')=='true' else MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVEHOME =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS if __addon__.getSetting('onWavveHome')=='true' else MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONRELIGION =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS if __addon__.getSetting('onWavveReligion')=='true' else MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSPOTVPAY =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS if __addon__.getSetting('onSpotvPay')=='true' else MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSAMSUNGHOME =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS if __addon__.getSetting('onSamsungHome')=='true' else MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_DISPLAYNM =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS if __addon__.getSetting('displayOTTnm')=='true' else MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_AUTORESTART =MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS if __addon__.getSetting('autoRestart')=='true' else MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_CUSTOM_LIST =MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.customEpg_FileList()
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_FILE_PATH=='' or MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_FILE_NAME=='':MFJGhkvsnQdtOLmoWuPfVEbKcIxyHz=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONWAVVE==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONTVING==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSPOTV==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr and MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.M3U_ONSAMSUNG==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:MFJGhkvsnQdtOLmoWuPfVEbKcIxyHz=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHz==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHr:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqD=xbmcgui.Dialog()
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyiz=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqD.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if MFJGhkvsnQdtOLmoWuPfVEbKcIxyiz==MFJGhkvsnQdtOLmoWuPfVEbKcIxyHS:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def MakeEpg_SaveJson(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyHX={'date_makeepg':MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')}
  try: 
   fp=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHl(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqB,'w',-1,'utf-8')
   json.dump(MFJGhkvsnQdtOLmoWuPfVEbKcIxyHX,fp)
   fp.close()
  except MFJGhkvsnQdtOLmoWuPfVEbKcIxyHA as exception:
   return
 def boritv_main(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz):
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.BoritvObj.KodiVersion=MFJGhkvsnQdtOLmoWuPfVEbKcIxyHw(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyHU=MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.main_params.get('mode',MFJGhkvsnQdtOLmoWuPfVEbKcIxyHD)
  MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.check_config()
  if MFJGhkvsnQdtOLmoWuPfVEbKcIxyHU is MFJGhkvsnQdtOLmoWuPfVEbKcIxyHD:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.dp_Main_List()
  elif MFJGhkvsnQdtOLmoWuPfVEbKcIxyHU=='DEL_M3U':
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.dp_Delete_M3u(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.main_params)
  elif MFJGhkvsnQdtOLmoWuPfVEbKcIxyHU=='ADD_M3U':
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.dp_MakeAdd_M3u(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.main_params)
  elif MFJGhkvsnQdtOLmoWuPfVEbKcIxyHU=='ADD_EPG':
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.dp_Make_Epg(MFJGhkvsnQdtOLmoWuPfVEbKcIxyqz.main_params)
  else:
   MFJGhkvsnQdtOLmoWuPfVEbKcIxyHD
# Created by pyminifier (https://github.com/liftoff/pyminifier)
