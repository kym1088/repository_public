__author__="NightRain"
CRDeXmfaHgdosJEtqOrclzSwhujMUL=object
CRDeXmfaHgdosJEtqOrclzSwhujMUB=None
CRDeXmfaHgdosJEtqOrclzSwhujMUQ=False
CRDeXmfaHgdosJEtqOrclzSwhujMUx=str
CRDeXmfaHgdosJEtqOrclzSwhujMUT=Exception
CRDeXmfaHgdosJEtqOrclzSwhujMUk=print
CRDeXmfaHgdosJEtqOrclzSwhujMUi=True
CRDeXmfaHgdosJEtqOrclzSwhujMUv=int
CRDeXmfaHgdosJEtqOrclzSwhujMUF=range
CRDeXmfaHgdosJEtqOrclzSwhujMUV=len
CRDeXmfaHgdosJEtqOrclzSwhujMUK=set
CRDeXmfaHgdosJEtqOrclzSwhujMUp=open
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
from channelgenre import*
CRDeXmfaHgdosJEtqOrclzSwhujMyb='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
CRDeXmfaHgdosJEtqOrclzSwhujMyU=[{'starttm':'000000','endtm':'030000'},{'starttm':'030000','endtm':'060000'},{'starttm':'060000','endtm':'090000'},{'starttm':'090000','endtm':'120000'},{'starttm':'120000','endtm':'150000'},{'starttm':'150000','endtm':'180000'},{'starttm':'180000','endtm':'210000'},{'starttm':'210000','endtm':'240000'}]
class CRDeXmfaHgdosJEtqOrclzSwhujMyP(CRDeXmfaHgdosJEtqOrclzSwhujMUL):
 def __init__(CRDeXmfaHgdosJEtqOrclzSwhujMyL):
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_WAVVE ='https://apis.wavve.com'
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_TVING ='https://api.tving.com'
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_TVINGIMG ='https://image.tving.com'
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_SPOTV ='https://www.spotvnow.co.kr'
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.HTTPTAG ='https://'
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.LIMIT_WAVVE =200
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.LIMIT_TVING =60
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.LIMIT_TVINGEPG=20 
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.DEFAULT_HEADER={'user-agent':CRDeXmfaHgdosJEtqOrclzSwhujMyb}
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.SLEEP_TIME =0.2
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.INIT_GENRESORT=MASTER_GENRE
  CRDeXmfaHgdosJEtqOrclzSwhujMyL.INIT_CHANNEL =MASTER_CHANNEL
 def callRequestCookies(CRDeXmfaHgdosJEtqOrclzSwhujMyL,jobtype,CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMUB,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB,redirects=CRDeXmfaHgdosJEtqOrclzSwhujMUQ):
  CRDeXmfaHgdosJEtqOrclzSwhujMyx=CRDeXmfaHgdosJEtqOrclzSwhujMyL.DEFAULT_HEADER
  if headers:CRDeXmfaHgdosJEtqOrclzSwhujMyx.update(headers)
  if jobtype=='Get':
   CRDeXmfaHgdosJEtqOrclzSwhujMyT=requests.get(CRDeXmfaHgdosJEtqOrclzSwhujMyp,params=params,headers=CRDeXmfaHgdosJEtqOrclzSwhujMyx,cookies=cookies,allow_redirects=redirects)
  else:
   CRDeXmfaHgdosJEtqOrclzSwhujMyT=requests.post(CRDeXmfaHgdosJEtqOrclzSwhujMyp,data=payload,params=params,headers=CRDeXmfaHgdosJEtqOrclzSwhujMyx,cookies=cookies,allow_redirects=redirects)
  return CRDeXmfaHgdosJEtqOrclzSwhujMyT
 def Get_DefaultParams_Wavve(CRDeXmfaHgdosJEtqOrclzSwhujMyL):
  CRDeXmfaHgdosJEtqOrclzSwhujMyk={'apikey':'E5F3E0D30947AA5440556471321BB6D9','credential':'none','device':'pc','drm':'wm','partner':'pooq','pooqzone':'none','region':'kor','targetage':'all'}
  return CRDeXmfaHgdosJEtqOrclzSwhujMyk
 def Get_DefaultParams_Tving(CRDeXmfaHgdosJEtqOrclzSwhujMyL):
  CRDeXmfaHgdosJEtqOrclzSwhujMyk={'apiKey':'1e7952d0917d6aab1f0293a063697610','networkCode':'CSND0900','osCode':'CSOD0900','teleCode':'CSCD0900','screenCode':'CSSD0100'}
  return CRDeXmfaHgdosJEtqOrclzSwhujMyk
 def Get_Now_Datetime(CRDeXmfaHgdosJEtqOrclzSwhujMyL):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def xmlText(CRDeXmfaHgdosJEtqOrclzSwhujMyL,in_text):
  CRDeXmfaHgdosJEtqOrclzSwhujMyv=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return CRDeXmfaHgdosJEtqOrclzSwhujMyv
 def Get_ChannelList_Wavve(CRDeXmfaHgdosJEtqOrclzSwhujMyL,exceptGroup=[]):
  CRDeXmfaHgdosJEtqOrclzSwhujMyF =[]
  CRDeXmfaHgdosJEtqOrclzSwhujMyV=[]
  CRDeXmfaHgdosJEtqOrclzSwhujMyK=CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_ChannelImg_Wavve()
  if exceptGroup!=[]:
   CRDeXmfaHgdosJEtqOrclzSwhujMyV=CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_ChannelList_WavveExcept(exceptGroup)
  try:
   CRDeXmfaHgdosJEtqOrclzSwhujMyp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_WAVVE+'/cf/live/recommend-channels'
   CRDeXmfaHgdosJEtqOrclzSwhujMyk={'WeekDay':'all','broadcastid':'30783','contenttype':'channel','isrecommend':'y','limit':CRDeXmfaHgdosJEtqOrclzSwhujMUx(CRDeXmfaHgdosJEtqOrclzSwhujMyL.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
   CRDeXmfaHgdosJEtqOrclzSwhujMyk.update(CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_DefaultParams_Wavve())
   CRDeXmfaHgdosJEtqOrclzSwhujMyN=CRDeXmfaHgdosJEtqOrclzSwhujMyL.callRequestCookies('Get',CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMyk,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB)
   CRDeXmfaHgdosJEtqOrclzSwhujMyn=json.loads(CRDeXmfaHgdosJEtqOrclzSwhujMyN.text)
   if not('celllist' in CRDeXmfaHgdosJEtqOrclzSwhujMyn['cell_toplist']):return CRDeXmfaHgdosJEtqOrclzSwhujMyF
   CRDeXmfaHgdosJEtqOrclzSwhujMyW=CRDeXmfaHgdosJEtqOrclzSwhujMyn['cell_toplist']['celllist']
   for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMyW:
    CRDeXmfaHgdosJEtqOrclzSwhujMyA=CRDeXmfaHgdosJEtqOrclzSwhujMyG['contentid']
    CRDeXmfaHgdosJEtqOrclzSwhujMyI=CRDeXmfaHgdosJEtqOrclzSwhujMyG['title_list'][0]['text']
    if CRDeXmfaHgdosJEtqOrclzSwhujMyA in CRDeXmfaHgdosJEtqOrclzSwhujMyK:
     CRDeXmfaHgdosJEtqOrclzSwhujMyY=CRDeXmfaHgdosJEtqOrclzSwhujMyK[CRDeXmfaHgdosJEtqOrclzSwhujMyA]
    else:
     CRDeXmfaHgdosJEtqOrclzSwhujMyY=''
    CRDeXmfaHgdosJEtqOrclzSwhujMPy={'channelid':CRDeXmfaHgdosJEtqOrclzSwhujMyA,'channelnm':CRDeXmfaHgdosJEtqOrclzSwhujMyI,'channelimg':CRDeXmfaHgdosJEtqOrclzSwhujMyL.HTTPTAG+CRDeXmfaHgdosJEtqOrclzSwhujMyY if CRDeXmfaHgdosJEtqOrclzSwhujMyY!='' else '','ott':'wavve','genrenm':CRDeXmfaHgdosJEtqOrclzSwhujMyL.make_getGenre(CRDeXmfaHgdosJEtqOrclzSwhujMyA,'wavve')}
    if CRDeXmfaHgdosJEtqOrclzSwhujMyA not in CRDeXmfaHgdosJEtqOrclzSwhujMyV:
     CRDeXmfaHgdosJEtqOrclzSwhujMyF.append(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
  except CRDeXmfaHgdosJEtqOrclzSwhujMUT as exception:
   CRDeXmfaHgdosJEtqOrclzSwhujMUk(exception)
   return[]
  return CRDeXmfaHgdosJEtqOrclzSwhujMyF
 def Get_ChannelList_WavveExcept(CRDeXmfaHgdosJEtqOrclzSwhujMyL,exceptGroup=[]):
  CRDeXmfaHgdosJEtqOrclzSwhujMyF=[]
  if exceptGroup==[]:return[]
  try:
   CRDeXmfaHgdosJEtqOrclzSwhujMyp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_WAVVE+'/cf/live/recommend-channels'
   for CRDeXmfaHgdosJEtqOrclzSwhujMyG in exceptGroup:
    CRDeXmfaHgdosJEtqOrclzSwhujMyk={'WeekDay':'all','adult':'n','broadcastid':CRDeXmfaHgdosJEtqOrclzSwhujMyG['broadcastid'],'contenttype':'channel','genre':CRDeXmfaHgdosJEtqOrclzSwhujMyG['genre'],'isrecommend':'y','limit':CRDeXmfaHgdosJEtqOrclzSwhujMUx(CRDeXmfaHgdosJEtqOrclzSwhujMyL.LIMIT_WAVVE),'offset':'0','uicode':'LN58','uiparent':'GN54-LN58','uirank':'4','uitype':'LN58'}
    CRDeXmfaHgdosJEtqOrclzSwhujMyk.update(CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_DefaultParams_Wavve())
    CRDeXmfaHgdosJEtqOrclzSwhujMyN=CRDeXmfaHgdosJEtqOrclzSwhujMyL.callRequestCookies('Get',CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMyk,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB)
    CRDeXmfaHgdosJEtqOrclzSwhujMyn=json.loads(CRDeXmfaHgdosJEtqOrclzSwhujMyN.text)
    if not('celllist' in CRDeXmfaHgdosJEtqOrclzSwhujMyn['cell_toplist']):return CRDeXmfaHgdosJEtqOrclzSwhujMyF
    CRDeXmfaHgdosJEtqOrclzSwhujMyW=CRDeXmfaHgdosJEtqOrclzSwhujMyn['cell_toplist']['celllist']
    for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMyW:
     CRDeXmfaHgdosJEtqOrclzSwhujMyF.append(CRDeXmfaHgdosJEtqOrclzSwhujMyG['contentid'])
  except CRDeXmfaHgdosJEtqOrclzSwhujMUT as exception:
   CRDeXmfaHgdosJEtqOrclzSwhujMUk(exception)
   return[]
  return CRDeXmfaHgdosJEtqOrclzSwhujMyF
 def Get_ChannelImg_Wavve(CRDeXmfaHgdosJEtqOrclzSwhujMyL):
  CRDeXmfaHgdosJEtqOrclzSwhujMPb={}
  try:
   CRDeXmfaHgdosJEtqOrclzSwhujMPU=CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_Now_Datetime()
   CRDeXmfaHgdosJEtqOrclzSwhujMPL =CRDeXmfaHgdosJEtqOrclzSwhujMPU+datetime.timedelta(hours=3)
   CRDeXmfaHgdosJEtqOrclzSwhujMyp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_WAVVE+'/live/epgs'
   CRDeXmfaHgdosJEtqOrclzSwhujMyk={'limit':CRDeXmfaHgdosJEtqOrclzSwhujMUx(CRDeXmfaHgdosJEtqOrclzSwhujMyL.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':CRDeXmfaHgdosJEtqOrclzSwhujMPU.strftime('%Y-%m-%d %H:00'),'enddatetime':CRDeXmfaHgdosJEtqOrclzSwhujMPL.strftime('%Y-%m-%d %H:00')}
   CRDeXmfaHgdosJEtqOrclzSwhujMyk.update(CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_DefaultParams_Wavve())
   CRDeXmfaHgdosJEtqOrclzSwhujMyN=CRDeXmfaHgdosJEtqOrclzSwhujMyL.callRequestCookies('Get',CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMyk,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB)
   CRDeXmfaHgdosJEtqOrclzSwhujMyn=json.loads(CRDeXmfaHgdosJEtqOrclzSwhujMyN.text)
   CRDeXmfaHgdosJEtqOrclzSwhujMyW=CRDeXmfaHgdosJEtqOrclzSwhujMyn['list']
   for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMyW:
    CRDeXmfaHgdosJEtqOrclzSwhujMPb[CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelid']]=CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelimage']
  except CRDeXmfaHgdosJEtqOrclzSwhujMUT as exception:
   CRDeXmfaHgdosJEtqOrclzSwhujMUk(exception)
  return CRDeXmfaHgdosJEtqOrclzSwhujMPb
 def Get_ChanneGenrename_Wavve(CRDeXmfaHgdosJEtqOrclzSwhujMyL,CRDeXmfaHgdosJEtqOrclzSwhujMyA):
  try:
   CRDeXmfaHgdosJEtqOrclzSwhujMyp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_WAVVE+'/live/channels/'+CRDeXmfaHgdosJEtqOrclzSwhujMyA
   CRDeXmfaHgdosJEtqOrclzSwhujMyk=CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_DefaultParams_Wavve()
   CRDeXmfaHgdosJEtqOrclzSwhujMyN=CRDeXmfaHgdosJEtqOrclzSwhujMyL.callRequestCookies('Get',CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMyk,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB)
   CRDeXmfaHgdosJEtqOrclzSwhujMyn=json.loads(CRDeXmfaHgdosJEtqOrclzSwhujMyN.text)
   CRDeXmfaHgdosJEtqOrclzSwhujMPB=CRDeXmfaHgdosJEtqOrclzSwhujMyn['genretext']
  except CRDeXmfaHgdosJEtqOrclzSwhujMUT as exception:
   CRDeXmfaHgdosJEtqOrclzSwhujMUk(exception)
   return ''
  return CRDeXmfaHgdosJEtqOrclzSwhujMPB
 def Get_ChannelList_Spotv(CRDeXmfaHgdosJEtqOrclzSwhujMyL,payyn=CRDeXmfaHgdosJEtqOrclzSwhujMUi):
  CRDeXmfaHgdosJEtqOrclzSwhujMyF=[]
  try:
   CRDeXmfaHgdosJEtqOrclzSwhujMyp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_SPOTV+'/api/v2/channel'
   CRDeXmfaHgdosJEtqOrclzSwhujMyN=CRDeXmfaHgdosJEtqOrclzSwhujMyL.callRequestCookies('Get',CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMUB,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB)
   CRDeXmfaHgdosJEtqOrclzSwhujMyn=json.loads(CRDeXmfaHgdosJEtqOrclzSwhujMyN.text)
   for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMyn:
    CRDeXmfaHgdosJEtqOrclzSwhujMyA=CRDeXmfaHgdosJEtqOrclzSwhujMyG['videoId'].replace('ref:','')
    CRDeXmfaHgdosJEtqOrclzSwhujMPy={'channelid':CRDeXmfaHgdosJEtqOrclzSwhujMyA,'channelnm':CRDeXmfaHgdosJEtqOrclzSwhujMyG['name'],'channelimg':CRDeXmfaHgdosJEtqOrclzSwhujMyG['logo'],'ott':'spotv','genrenm':CRDeXmfaHgdosJEtqOrclzSwhujMyL.make_getGenre(CRDeXmfaHgdosJEtqOrclzSwhujMyA,'spotv')}
    if payyn==CRDeXmfaHgdosJEtqOrclzSwhujMUi or CRDeXmfaHgdosJEtqOrclzSwhujMyG['free']==CRDeXmfaHgdosJEtqOrclzSwhujMUi:
     CRDeXmfaHgdosJEtqOrclzSwhujMyF.append(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
  except CRDeXmfaHgdosJEtqOrclzSwhujMUT as exception:
   CRDeXmfaHgdosJEtqOrclzSwhujMUk(exception)
   return[]
  return CRDeXmfaHgdosJEtqOrclzSwhujMyF
 def Get_ChannelList_Tving(CRDeXmfaHgdosJEtqOrclzSwhujMyL):
  CRDeXmfaHgdosJEtqOrclzSwhujMyF =[]
  CRDeXmfaHgdosJEtqOrclzSwhujMPQ=[]
  try:
   CRDeXmfaHgdosJEtqOrclzSwhujMyp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_TVING+'/v2/media/lives'
   CRDeXmfaHgdosJEtqOrclzSwhujMyk={'pageNo':'1','pageSize':CRDeXmfaHgdosJEtqOrclzSwhujMUx(CRDeXmfaHgdosJEtqOrclzSwhujMyL.LIMIT_TVING),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':'CPCS0100,CPCS0400'}
   CRDeXmfaHgdosJEtqOrclzSwhujMyk.update(CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_DefaultParams_Tving())
   CRDeXmfaHgdosJEtqOrclzSwhujMyN=CRDeXmfaHgdosJEtqOrclzSwhujMyL.callRequestCookies('Get',CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMyk,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB)
   CRDeXmfaHgdosJEtqOrclzSwhujMyn=json.loads(CRDeXmfaHgdosJEtqOrclzSwhujMyN.text)
   if not('result' in CRDeXmfaHgdosJEtqOrclzSwhujMyn['body']):return CRDeXmfaHgdosJEtqOrclzSwhujMyF
   CRDeXmfaHgdosJEtqOrclzSwhujMyW=CRDeXmfaHgdosJEtqOrclzSwhujMyn['body']['result']
   for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMyW:
    if CRDeXmfaHgdosJEtqOrclzSwhujMyG['live_code']=='C44441':continue 
    CRDeXmfaHgdosJEtqOrclzSwhujMPQ.append(CRDeXmfaHgdosJEtqOrclzSwhujMyG['live_code'])
   CRDeXmfaHgdosJEtqOrclzSwhujMyK=CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_ChannelImg_Tving(CRDeXmfaHgdosJEtqOrclzSwhujMPQ)
   for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMyW:
    CRDeXmfaHgdosJEtqOrclzSwhujMyA=CRDeXmfaHgdosJEtqOrclzSwhujMyG['live_code']
    if CRDeXmfaHgdosJEtqOrclzSwhujMyA=='C44441':continue 
    CRDeXmfaHgdosJEtqOrclzSwhujMyI=CRDeXmfaHgdosJEtqOrclzSwhujMyG['schedule']['channel']['name']['ko']
    if CRDeXmfaHgdosJEtqOrclzSwhujMyA in CRDeXmfaHgdosJEtqOrclzSwhujMyK:
     CRDeXmfaHgdosJEtqOrclzSwhujMyY=CRDeXmfaHgdosJEtqOrclzSwhujMyK[CRDeXmfaHgdosJEtqOrclzSwhujMyA]
    else:
     CRDeXmfaHgdosJEtqOrclzSwhujMyY=''
    CRDeXmfaHgdosJEtqOrclzSwhujMPy={'channelid':CRDeXmfaHgdosJEtqOrclzSwhujMyA,'channelnm':CRDeXmfaHgdosJEtqOrclzSwhujMyI,'channelimg':CRDeXmfaHgdosJEtqOrclzSwhujMyY,'ott':'tving','genrenm':CRDeXmfaHgdosJEtqOrclzSwhujMyL.make_getGenre(CRDeXmfaHgdosJEtqOrclzSwhujMyA,'tving')}
    CRDeXmfaHgdosJEtqOrclzSwhujMyF.append(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
  except CRDeXmfaHgdosJEtqOrclzSwhujMUT as exception:
   CRDeXmfaHgdosJEtqOrclzSwhujMUk(exception)
   return[]
  return CRDeXmfaHgdosJEtqOrclzSwhujMyF
 def make_EpgDatetime_Tving(CRDeXmfaHgdosJEtqOrclzSwhujMyL,days=2):
  CRDeXmfaHgdosJEtqOrclzSwhujMPx=[]
  CRDeXmfaHgdosJEtqOrclzSwhujMPT=CRDeXmfaHgdosJEtqOrclzSwhujMyL.make_DateList(days=2,dateType='2')
  CRDeXmfaHgdosJEtqOrclzSwhujMPk=CRDeXmfaHgdosJEtqOrclzSwhujMUv(CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_Now_Datetime().strftime('%Y%m%d%H0000'))
  for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMPT:
   for CRDeXmfaHgdosJEtqOrclzSwhujMPi in CRDeXmfaHgdosJEtqOrclzSwhujMUF(8):
    CRDeXmfaHgdosJEtqOrclzSwhujMPy={'ndate':CRDeXmfaHgdosJEtqOrclzSwhujMyG,'starttm':CRDeXmfaHgdosJEtqOrclzSwhujMyU[CRDeXmfaHgdosJEtqOrclzSwhujMPi]['starttm'],'endtm':CRDeXmfaHgdosJEtqOrclzSwhujMyU[CRDeXmfaHgdosJEtqOrclzSwhujMPi]['endtm']}
    CRDeXmfaHgdosJEtqOrclzSwhujMPv=CRDeXmfaHgdosJEtqOrclzSwhujMUv(CRDeXmfaHgdosJEtqOrclzSwhujMyG+CRDeXmfaHgdosJEtqOrclzSwhujMyU[CRDeXmfaHgdosJEtqOrclzSwhujMPi]['starttm'])
    CRDeXmfaHgdosJEtqOrclzSwhujMPF=CRDeXmfaHgdosJEtqOrclzSwhujMUv(CRDeXmfaHgdosJEtqOrclzSwhujMyG+CRDeXmfaHgdosJEtqOrclzSwhujMyU[CRDeXmfaHgdosJEtqOrclzSwhujMPi]['endtm'])
    if CRDeXmfaHgdosJEtqOrclzSwhujMPk<=CRDeXmfaHgdosJEtqOrclzSwhujMPv or(CRDeXmfaHgdosJEtqOrclzSwhujMPv<CRDeXmfaHgdosJEtqOrclzSwhujMPk and CRDeXmfaHgdosJEtqOrclzSwhujMPk<CRDeXmfaHgdosJEtqOrclzSwhujMPF):
     CRDeXmfaHgdosJEtqOrclzSwhujMPx.append(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
  return CRDeXmfaHgdosJEtqOrclzSwhujMPx
 def make_DateList(CRDeXmfaHgdosJEtqOrclzSwhujMyL,days=2,dateType='1'):
  CRDeXmfaHgdosJEtqOrclzSwhujMPT=[]
  CRDeXmfaHgdosJEtqOrclzSwhujMPV =CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_Now_Datetime()
  if dateType=='1':
   CRDeXmfaHgdosJEtqOrclzSwhujMPV=CRDeXmfaHgdosJEtqOrclzSwhujMPV-datetime.timedelta(days=1)
  for i in CRDeXmfaHgdosJEtqOrclzSwhujMUF(days):
   CRDeXmfaHgdosJEtqOrclzSwhujMPK=CRDeXmfaHgdosJEtqOrclzSwhujMPV+datetime.timedelta(days=i)
   if dateType=='1':
    CRDeXmfaHgdosJEtqOrclzSwhujMPT.append(CRDeXmfaHgdosJEtqOrclzSwhujMPK.strftime('%Y-%m-%d'))
   else:
    CRDeXmfaHgdosJEtqOrclzSwhujMPT.append(CRDeXmfaHgdosJEtqOrclzSwhujMPK.strftime('%Y%m%d'))
  return CRDeXmfaHgdosJEtqOrclzSwhujMPT
 def make_Tving_ChannleGroup(CRDeXmfaHgdosJEtqOrclzSwhujMyL,CRDeXmfaHgdosJEtqOrclzSwhujMPQ):
  CRDeXmfaHgdosJEtqOrclzSwhujMPp=[]
  i=0
  CRDeXmfaHgdosJEtqOrclzSwhujMPN=''
  for CRDeXmfaHgdosJEtqOrclzSwhujMPn in CRDeXmfaHgdosJEtqOrclzSwhujMPQ:
   if i==0:CRDeXmfaHgdosJEtqOrclzSwhujMPN=CRDeXmfaHgdosJEtqOrclzSwhujMPn
   else:CRDeXmfaHgdosJEtqOrclzSwhujMPN+=',%s'%(CRDeXmfaHgdosJEtqOrclzSwhujMPn)
   i+=1
   if i>=CRDeXmfaHgdosJEtqOrclzSwhujMyL.LIMIT_TVINGEPG:
    CRDeXmfaHgdosJEtqOrclzSwhujMPp.append(CRDeXmfaHgdosJEtqOrclzSwhujMPN)
    i=0
    CRDeXmfaHgdosJEtqOrclzSwhujMPN=''
  if CRDeXmfaHgdosJEtqOrclzSwhujMPN!='':
   CRDeXmfaHgdosJEtqOrclzSwhujMPp.append(CRDeXmfaHgdosJEtqOrclzSwhujMPN)
  return CRDeXmfaHgdosJEtqOrclzSwhujMPp
 def Get_ChannelImg_Tving(CRDeXmfaHgdosJEtqOrclzSwhujMyL,chid_list):
  CRDeXmfaHgdosJEtqOrclzSwhujMPb={}
  try:
   CRDeXmfaHgdosJEtqOrclzSwhujMPW=CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_Now_Datetime().strftime('%Y%m%d')
   CRDeXmfaHgdosJEtqOrclzSwhujMPU =CRDeXmfaHgdosJEtqOrclzSwhujMyU[6]['starttm'] 
   CRDeXmfaHgdosJEtqOrclzSwhujMPL =CRDeXmfaHgdosJEtqOrclzSwhujMyU[6]['endtm']
   CRDeXmfaHgdosJEtqOrclzSwhujMPp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.make_Tving_ChannleGroup(chid_list)
   for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMPp:
    CRDeXmfaHgdosJEtqOrclzSwhujMyp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_TVING+'/v2/media/schedules'
    CRDeXmfaHgdosJEtqOrclzSwhujMyk={'pageNo':'1','pageSize':CRDeXmfaHgdosJEtqOrclzSwhujMUx(CRDeXmfaHgdosJEtqOrclzSwhujMyL.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':CRDeXmfaHgdosJEtqOrclzSwhujMPW,'broadcastDate':CRDeXmfaHgdosJEtqOrclzSwhujMPW,'startBroadTime':CRDeXmfaHgdosJEtqOrclzSwhujMPU,'endBroadTime':CRDeXmfaHgdosJEtqOrclzSwhujMPL,'channelCode':CRDeXmfaHgdosJEtqOrclzSwhujMyG}
    CRDeXmfaHgdosJEtqOrclzSwhujMyk.update(CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_DefaultParams_Tving())
    CRDeXmfaHgdosJEtqOrclzSwhujMyN=CRDeXmfaHgdosJEtqOrclzSwhujMyL.callRequestCookies('Get',CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMyk,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB)
    CRDeXmfaHgdosJEtqOrclzSwhujMyn=json.loads(CRDeXmfaHgdosJEtqOrclzSwhujMyN.text)
    if not('result' in CRDeXmfaHgdosJEtqOrclzSwhujMyn['body']):return{}
    CRDeXmfaHgdosJEtqOrclzSwhujMyW=CRDeXmfaHgdosJEtqOrclzSwhujMyn['body']['result']
    for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMyW:
     CRDeXmfaHgdosJEtqOrclzSwhujMPb[CRDeXmfaHgdosJEtqOrclzSwhujMyG['channel_code']]=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_TVINGIMG+CRDeXmfaHgdosJEtqOrclzSwhujMyG['image'][2]['url']
  except CRDeXmfaHgdosJEtqOrclzSwhujMUT as exception:
   CRDeXmfaHgdosJEtqOrclzSwhujMUk(exception)
   return{}
  return CRDeXmfaHgdosJEtqOrclzSwhujMPb
 def Get_EpgInfo_Spotv(CRDeXmfaHgdosJEtqOrclzSwhujMyL,days=3,payyn=CRDeXmfaHgdosJEtqOrclzSwhujMUi):
  CRDeXmfaHgdosJEtqOrclzSwhujMPG ={}
  CRDeXmfaHgdosJEtqOrclzSwhujMyF=[]
  CRDeXmfaHgdosJEtqOrclzSwhujMPA =[]
  CRDeXmfaHgdosJEtqOrclzSwhujMPT=CRDeXmfaHgdosJEtqOrclzSwhujMyL.make_DateList(days=days,dateType='1')
  CRDeXmfaHgdosJEtqOrclzSwhujMUk(CRDeXmfaHgdosJEtqOrclzSwhujMPT)
  try:
   CRDeXmfaHgdosJEtqOrclzSwhujMyp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_SPOTV+'/api/v2/channel'
   CRDeXmfaHgdosJEtqOrclzSwhujMyN=CRDeXmfaHgdosJEtqOrclzSwhujMyL.callRequestCookies('Get',CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMUB,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB)
   CRDeXmfaHgdosJEtqOrclzSwhujMyn=json.loads(CRDeXmfaHgdosJEtqOrclzSwhujMyN.text)
   for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMyn:
    CRDeXmfaHgdosJEtqOrclzSwhujMyA =CRDeXmfaHgdosJEtqOrclzSwhujMyG['videoId'].replace('ref:','')
    CRDeXmfaHgdosJEtqOrclzSwhujMPy={'channelid':CRDeXmfaHgdosJEtqOrclzSwhujMyA,'channelnm':CRDeXmfaHgdosJEtqOrclzSwhujMyL.xmlText(CRDeXmfaHgdosJEtqOrclzSwhujMyG['name']),'channelimg':CRDeXmfaHgdosJEtqOrclzSwhujMyG['logo'],'ott':'spotv'}
    if payyn==CRDeXmfaHgdosJEtqOrclzSwhujMUi or CRDeXmfaHgdosJEtqOrclzSwhujMyG['free']==CRDeXmfaHgdosJEtqOrclzSwhujMUi:
     CRDeXmfaHgdosJEtqOrclzSwhujMPG[CRDeXmfaHgdosJEtqOrclzSwhujMyG['id']]=CRDeXmfaHgdosJEtqOrclzSwhujMyA
     CRDeXmfaHgdosJEtqOrclzSwhujMyF.append(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
  except CRDeXmfaHgdosJEtqOrclzSwhujMUT as exception:
   CRDeXmfaHgdosJEtqOrclzSwhujMUk(exception)
   return[],[]
  try:
   for CRDeXmfaHgdosJEtqOrclzSwhujMPI in CRDeXmfaHgdosJEtqOrclzSwhujMPT:
    CRDeXmfaHgdosJEtqOrclzSwhujMyp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_SPOTV+'/api/v2/program/'+CRDeXmfaHgdosJEtqOrclzSwhujMPI
    CRDeXmfaHgdosJEtqOrclzSwhujMyN=CRDeXmfaHgdosJEtqOrclzSwhujMyL.callRequestCookies('Get',CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMUB,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB)
    CRDeXmfaHgdosJEtqOrclzSwhujMyn=json.loads(CRDeXmfaHgdosJEtqOrclzSwhujMyN.text)
    for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMyn:
     if CRDeXmfaHgdosJEtqOrclzSwhujMPG.get(CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelId'])==CRDeXmfaHgdosJEtqOrclzSwhujMUB:continue
     CRDeXmfaHgdosJEtqOrclzSwhujMPy={'channelid':CRDeXmfaHgdosJEtqOrclzSwhujMPG.get(CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelId']),'title':CRDeXmfaHgdosJEtqOrclzSwhujMyL.xmlText(CRDeXmfaHgdosJEtqOrclzSwhujMyG['title']),'startTime':CRDeXmfaHgdosJEtqOrclzSwhujMyG['startTime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':CRDeXmfaHgdosJEtqOrclzSwhujMyG['endTime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'spotv'}
     CRDeXmfaHgdosJEtqOrclzSwhujMPA.append(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
    time.sleep(CRDeXmfaHgdosJEtqOrclzSwhujMyL.SLEEP_TIME)
  except CRDeXmfaHgdosJEtqOrclzSwhujMUT as exception:
   CRDeXmfaHgdosJEtqOrclzSwhujMUk(exception)
   return[],[]
  return CRDeXmfaHgdosJEtqOrclzSwhujMyF,CRDeXmfaHgdosJEtqOrclzSwhujMPA
 def Get_EpgInfo_Wavve(CRDeXmfaHgdosJEtqOrclzSwhujMyL,days=2,exceptGroup=[]):
  CRDeXmfaHgdosJEtqOrclzSwhujMyF =[]
  CRDeXmfaHgdosJEtqOrclzSwhujMPA =[]
  CRDeXmfaHgdosJEtqOrclzSwhujMyV=[]
  CRDeXmfaHgdosJEtqOrclzSwhujMPV =CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_Now_Datetime()
  CRDeXmfaHgdosJEtqOrclzSwhujMPY =CRDeXmfaHgdosJEtqOrclzSwhujMPV+datetime.timedelta(hours=-2)
  CRDeXmfaHgdosJEtqOrclzSwhujMby =CRDeXmfaHgdosJEtqOrclzSwhujMPV+datetime.timedelta(days=(days-1))
  if CRDeXmfaHgdosJEtqOrclzSwhujMUv(CRDeXmfaHgdosJEtqOrclzSwhujMPY.strftime('%H'))<=3:
   CRDeXmfaHgdosJEtqOrclzSwhujMbP=CRDeXmfaHgdosJEtqOrclzSwhujMPY.strftime('%Y-%m-%d 00:00')
  else:
   CRDeXmfaHgdosJEtqOrclzSwhujMbP=CRDeXmfaHgdosJEtqOrclzSwhujMPY.strftime('%Y-%m-%d %H:00')
  CRDeXmfaHgdosJEtqOrclzSwhujMbU =CRDeXmfaHgdosJEtqOrclzSwhujMby.strftime('%Y-%m-%d 24:00')
  if exceptGroup!=[]:
   CRDeXmfaHgdosJEtqOrclzSwhujMyV=CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_ChannelList_WavveExcept(exceptGroup)
  try:
   CRDeXmfaHgdosJEtqOrclzSwhujMyp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_WAVVE+'/live/epgs'
   CRDeXmfaHgdosJEtqOrclzSwhujMyk={'limit':CRDeXmfaHgdosJEtqOrclzSwhujMUx(CRDeXmfaHgdosJEtqOrclzSwhujMyL.LIMIT_WAVVE),'offset':'0','genre':'all','startdatetime':CRDeXmfaHgdosJEtqOrclzSwhujMbP,'enddatetime':CRDeXmfaHgdosJEtqOrclzSwhujMbU}
   CRDeXmfaHgdosJEtqOrclzSwhujMyk.update(CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_DefaultParams_Wavve())
   CRDeXmfaHgdosJEtqOrclzSwhujMyN=CRDeXmfaHgdosJEtqOrclzSwhujMyL.callRequestCookies('Get',CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMyk,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB)
   CRDeXmfaHgdosJEtqOrclzSwhujMyn=json.loads(CRDeXmfaHgdosJEtqOrclzSwhujMyN.text)
   CRDeXmfaHgdosJEtqOrclzSwhujMbL=CRDeXmfaHgdosJEtqOrclzSwhujMyn['list']
   for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMbL:
    CRDeXmfaHgdosJEtqOrclzSwhujMPy={'channelid':CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelid'],'channelnm':CRDeXmfaHgdosJEtqOrclzSwhujMyL.xmlText(CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelname']),'channelimg':CRDeXmfaHgdosJEtqOrclzSwhujMyL.HTTPTAG+CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelimage'],'ott':'wavve'}
    if CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelid']not in CRDeXmfaHgdosJEtqOrclzSwhujMyV:
     CRDeXmfaHgdosJEtqOrclzSwhujMyF.append(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
    for CRDeXmfaHgdosJEtqOrclzSwhujMbB in CRDeXmfaHgdosJEtqOrclzSwhujMyG['list']:
     CRDeXmfaHgdosJEtqOrclzSwhujMPy={'channelid':CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelid'],'title':CRDeXmfaHgdosJEtqOrclzSwhujMyL.xmlText(CRDeXmfaHgdosJEtqOrclzSwhujMbB['title']),'startTime':CRDeXmfaHgdosJEtqOrclzSwhujMbB['starttime'].replace('-','').replace(' ','').replace(':','')+'00','endTime':CRDeXmfaHgdosJEtqOrclzSwhujMbB['endtime'].replace('-','').replace(' ','').replace(':','')+'00','ott':'wavve'}
     if CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelid']not in CRDeXmfaHgdosJEtqOrclzSwhujMyV and CRDeXmfaHgdosJEtqOrclzSwhujMbB['starttime']!=CRDeXmfaHgdosJEtqOrclzSwhujMbB['endtime']:
      CRDeXmfaHgdosJEtqOrclzSwhujMPA.append(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
  except CRDeXmfaHgdosJEtqOrclzSwhujMUT as exception:
   CRDeXmfaHgdosJEtqOrclzSwhujMUk(exception)
   return[],[]
  CRDeXmfaHgdosJEtqOrclzSwhujMbQ=CRDeXmfaHgdosJEtqOrclzSwhujMUV(CRDeXmfaHgdosJEtqOrclzSwhujMPA)
  for i in(CRDeXmfaHgdosJEtqOrclzSwhujMUF(1,CRDeXmfaHgdosJEtqOrclzSwhujMbQ)):
   if CRDeXmfaHgdosJEtqOrclzSwhujMUv(CRDeXmfaHgdosJEtqOrclzSwhujMPA[i-1]['endTime'])+1==CRDeXmfaHgdosJEtqOrclzSwhujMUv(CRDeXmfaHgdosJEtqOrclzSwhujMPA[i]['startTime'])and CRDeXmfaHgdosJEtqOrclzSwhujMPA[i-1]['channelid']==CRDeXmfaHgdosJEtqOrclzSwhujMPA[i]['channelid']:
    CRDeXmfaHgdosJEtqOrclzSwhujMPA[i-1]['endTime']=CRDeXmfaHgdosJEtqOrclzSwhujMPA[i]['startTime']
  return CRDeXmfaHgdosJEtqOrclzSwhujMyF,CRDeXmfaHgdosJEtqOrclzSwhujMPA
 def Get_EpgInfo_Tving(CRDeXmfaHgdosJEtqOrclzSwhujMyL,days=2):
  CRDeXmfaHgdosJEtqOrclzSwhujMyF=[]
  CRDeXmfaHgdosJEtqOrclzSwhujMPA =[]
  CRDeXmfaHgdosJEtqOrclzSwhujMbx =[]
  CRDeXmfaHgdosJEtqOrclzSwhujMbT =CRDeXmfaHgdosJEtqOrclzSwhujMyL.make_EpgDatetime_Tving(days=days)
  CRDeXmfaHgdosJEtqOrclzSwhujMyF =CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_ChannelList_Tving()
  CRDeXmfaHgdosJEtqOrclzSwhujMbk=[]
  for i in CRDeXmfaHgdosJEtqOrclzSwhujMUF(CRDeXmfaHgdosJEtqOrclzSwhujMUV(CRDeXmfaHgdosJEtqOrclzSwhujMyF)):
   CRDeXmfaHgdosJEtqOrclzSwhujMyF[i]['channelnm']=CRDeXmfaHgdosJEtqOrclzSwhujMyL.xmlText(CRDeXmfaHgdosJEtqOrclzSwhujMyF[i]['channelnm'])
   CRDeXmfaHgdosJEtqOrclzSwhujMbk.append(CRDeXmfaHgdosJEtqOrclzSwhujMyF[i]['channelid'])
  CRDeXmfaHgdosJEtqOrclzSwhujMbi=CRDeXmfaHgdosJEtqOrclzSwhujMyL.make_Tving_ChannleGroup(CRDeXmfaHgdosJEtqOrclzSwhujMbk)
  try:
   CRDeXmfaHgdosJEtqOrclzSwhujMyp=CRDeXmfaHgdosJEtqOrclzSwhujMyL.API_TVING+'/v2/media/schedules'
   for CRDeXmfaHgdosJEtqOrclzSwhujMbv in CRDeXmfaHgdosJEtqOrclzSwhujMbT:
    for CRDeXmfaHgdosJEtqOrclzSwhujMbF in CRDeXmfaHgdosJEtqOrclzSwhujMbi:
     CRDeXmfaHgdosJEtqOrclzSwhujMyk={'pageNo':'1','pageSize':CRDeXmfaHgdosJEtqOrclzSwhujMUx(CRDeXmfaHgdosJEtqOrclzSwhujMyL.LIMIT_TVINGEPG),'order':'chno','scope':'all','adult':'n','free':'all','broadDate':CRDeXmfaHgdosJEtqOrclzSwhujMbv['ndate'],'broadcastDate':CRDeXmfaHgdosJEtqOrclzSwhujMbv['ndate'],'startBroadTime':CRDeXmfaHgdosJEtqOrclzSwhujMbv['starttm'],'endBroadTime':CRDeXmfaHgdosJEtqOrclzSwhujMbv['endtm'],'channelCode':CRDeXmfaHgdosJEtqOrclzSwhujMbF}
     CRDeXmfaHgdosJEtqOrclzSwhujMyk.update(CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_DefaultParams_Tving())
     CRDeXmfaHgdosJEtqOrclzSwhujMyN=CRDeXmfaHgdosJEtqOrclzSwhujMyL.callRequestCookies('Get',CRDeXmfaHgdosJEtqOrclzSwhujMyp,payload=CRDeXmfaHgdosJEtqOrclzSwhujMUB,params=CRDeXmfaHgdosJEtqOrclzSwhujMyk,headers=CRDeXmfaHgdosJEtqOrclzSwhujMUB,cookies=CRDeXmfaHgdosJEtqOrclzSwhujMUB)
     CRDeXmfaHgdosJEtqOrclzSwhujMyn=json.loads(CRDeXmfaHgdosJEtqOrclzSwhujMyN.text)
     CRDeXmfaHgdosJEtqOrclzSwhujMyW=CRDeXmfaHgdosJEtqOrclzSwhujMyn['body']['result']
     for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMyW:
      if 'schedules' not in CRDeXmfaHgdosJEtqOrclzSwhujMyG:continue
      if CRDeXmfaHgdosJEtqOrclzSwhujMyG['schedules']==CRDeXmfaHgdosJEtqOrclzSwhujMUB:continue
      for CRDeXmfaHgdosJEtqOrclzSwhujMbV in CRDeXmfaHgdosJEtqOrclzSwhujMyG['schedules']:
       CRDeXmfaHgdosJEtqOrclzSwhujMPy={'channelid':CRDeXmfaHgdosJEtqOrclzSwhujMbV['schedule_code'],'title':CRDeXmfaHgdosJEtqOrclzSwhujMyL.xmlText(CRDeXmfaHgdosJEtqOrclzSwhujMbV['program']['name']['ko']),'startTime':CRDeXmfaHgdosJEtqOrclzSwhujMUx(CRDeXmfaHgdosJEtqOrclzSwhujMbV['broadcast_start_time']),'endTime':CRDeXmfaHgdosJEtqOrclzSwhujMUx(CRDeXmfaHgdosJEtqOrclzSwhujMbV['broadcast_end_time']),'ott':'tving'}
       CRDeXmfaHgdosJEtqOrclzSwhujMbK=CRDeXmfaHgdosJEtqOrclzSwhujMbV['schedule_code']+CRDeXmfaHgdosJEtqOrclzSwhujMUx(CRDeXmfaHgdosJEtqOrclzSwhujMbV['broadcast_start_time'])
       if CRDeXmfaHgdosJEtqOrclzSwhujMbK in CRDeXmfaHgdosJEtqOrclzSwhujMbx:continue
       CRDeXmfaHgdosJEtqOrclzSwhujMbx.append(CRDeXmfaHgdosJEtqOrclzSwhujMbK)
       CRDeXmfaHgdosJEtqOrclzSwhujMPA.append(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
     time.sleep(CRDeXmfaHgdosJEtqOrclzSwhujMyL.SLEEP_TIME)
  except CRDeXmfaHgdosJEtqOrclzSwhujMUT as exception:
   CRDeXmfaHgdosJEtqOrclzSwhujMUk(exception)
   return[],[]
  return CRDeXmfaHgdosJEtqOrclzSwhujMyF,CRDeXmfaHgdosJEtqOrclzSwhujMPA
 def make_getGenre(CRDeXmfaHgdosJEtqOrclzSwhujMyL,CRDeXmfaHgdosJEtqOrclzSwhujMyA,CRDeXmfaHgdosJEtqOrclzSwhujMUy):
  try:
   CRDeXmfaHgdosJEtqOrclzSwhujMPB=CRDeXmfaHgdosJEtqOrclzSwhujMyL.INIT_CHANNEL.get(CRDeXmfaHgdosJEtqOrclzSwhujMyA+'.'+CRDeXmfaHgdosJEtqOrclzSwhujMUy).get('genre')
  except:
   CRDeXmfaHgdosJEtqOrclzSwhujMPB='-'
  return CRDeXmfaHgdosJEtqOrclzSwhujMPB
 def make_base_allchannel_py(CRDeXmfaHgdosJEtqOrclzSwhujMyL):
  CRDeXmfaHgdosJEtqOrclzSwhujMbp =[]
  CRDeXmfaHgdosJEtqOrclzSwhujMbN=[]
  CRDeXmfaHgdosJEtqOrclzSwhujMbn=CRDeXmfaHgdosJEtqOrclzSwhujMUK()
  CRDeXmfaHgdosJEtqOrclzSwhujMPy=CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_ChannelList_Wavve()
  CRDeXmfaHgdosJEtqOrclzSwhujMbp.extend(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
  CRDeXmfaHgdosJEtqOrclzSwhujMPy=CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_ChannelList_Tving()
  CRDeXmfaHgdosJEtqOrclzSwhujMbp.extend(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
  CRDeXmfaHgdosJEtqOrclzSwhujMPy=CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_ChannelList_Spotv()
  CRDeXmfaHgdosJEtqOrclzSwhujMbp.extend(CRDeXmfaHgdosJEtqOrclzSwhujMPy)
  CRDeXmfaHgdosJEtqOrclzSwhujMUk('1')
  for i in CRDeXmfaHgdosJEtqOrclzSwhujMUF(CRDeXmfaHgdosJEtqOrclzSwhujMUV(CRDeXmfaHgdosJEtqOrclzSwhujMbp)):
   if CRDeXmfaHgdosJEtqOrclzSwhujMbp[i]['genrenm']=='-':
    if CRDeXmfaHgdosJEtqOrclzSwhujMbp[i]['ott']=='wavve':
     CRDeXmfaHgdosJEtqOrclzSwhujMPB=CRDeXmfaHgdosJEtqOrclzSwhujMyL.Get_ChanneGenrename_Wavve(CRDeXmfaHgdosJEtqOrclzSwhujMbp[i]['channelid'])
     if CRDeXmfaHgdosJEtqOrclzSwhujMPB not in CRDeXmfaHgdosJEtqOrclzSwhujMbn:CRDeXmfaHgdosJEtqOrclzSwhujMbn.add(CRDeXmfaHgdosJEtqOrclzSwhujMPB)
     time.sleep(CRDeXmfaHgdosJEtqOrclzSwhujMyL.SLEEP_TIME)
    elif CRDeXmfaHgdosJEtqOrclzSwhujMbp[i]['ott']=='spotv':
     CRDeXmfaHgdosJEtqOrclzSwhujMPB='스포츠'
    else:
     CRDeXmfaHgdosJEtqOrclzSwhujMPB='-'
    CRDeXmfaHgdosJEtqOrclzSwhujMbp[i]['genrenm']=CRDeXmfaHgdosJEtqOrclzSwhujMPB
   else:
    if CRDeXmfaHgdosJEtqOrclzSwhujMbp[i]['genrenm']not in CRDeXmfaHgdosJEtqOrclzSwhujMbn:CRDeXmfaHgdosJEtqOrclzSwhujMbn.add(CRDeXmfaHgdosJEtqOrclzSwhujMbp[i]['genrenm'])
  CRDeXmfaHgdosJEtqOrclzSwhujMbn.add('-')
  CRDeXmfaHgdosJEtqOrclzSwhujMUk('2')
  for CRDeXmfaHgdosJEtqOrclzSwhujMbW in CRDeXmfaHgdosJEtqOrclzSwhujMbn:
   for CRDeXmfaHgdosJEtqOrclzSwhujMbG in CRDeXmfaHgdosJEtqOrclzSwhujMbp:
    if CRDeXmfaHgdosJEtqOrclzSwhujMbG['genrenm']==CRDeXmfaHgdosJEtqOrclzSwhujMbW:
     CRDeXmfaHgdosJEtqOrclzSwhujMbN.append(CRDeXmfaHgdosJEtqOrclzSwhujMbG)
  for CRDeXmfaHgdosJEtqOrclzSwhujMbG in CRDeXmfaHgdosJEtqOrclzSwhujMbp:
   if CRDeXmfaHgdosJEtqOrclzSwhujMbG['genrenm']not in CRDeXmfaHgdosJEtqOrclzSwhujMbn:
    CRDeXmfaHgdosJEtqOrclzSwhujMbA.append(CRDeXmfaHgdosJEtqOrclzSwhujMbG)
  CRDeXmfaHgdosJEtqOrclzSwhujMUk('3')
  CRDeXmfaHgdosJEtqOrclzSwhujMbI='d:\\job\\channelgenre.json'
  if os.path.isfile(CRDeXmfaHgdosJEtqOrclzSwhujMbI):os.remove(CRDeXmfaHgdosJEtqOrclzSwhujMbI)
  fp=CRDeXmfaHgdosJEtqOrclzSwhujMUp(CRDeXmfaHgdosJEtqOrclzSwhujMbI,'w',-1,'utf-8')
  fp.write('MASTER_CHANNEL = {\n')
  CRDeXmfaHgdosJEtqOrclzSwhujMbY=CRDeXmfaHgdosJEtqOrclzSwhujMUV(CRDeXmfaHgdosJEtqOrclzSwhujMbN)
  i=0
  for CRDeXmfaHgdosJEtqOrclzSwhujMyG in CRDeXmfaHgdosJEtqOrclzSwhujMbN:
   i+=1
   CRDeXmfaHgdosJEtqOrclzSwhujMyA =CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelid']
   CRDeXmfaHgdosJEtqOrclzSwhujMyI =CRDeXmfaHgdosJEtqOrclzSwhujMyG['channelnm']
   CRDeXmfaHgdosJEtqOrclzSwhujMUy =CRDeXmfaHgdosJEtqOrclzSwhujMyG['ott']
   CRDeXmfaHgdosJEtqOrclzSwhujMUP ='%s.%s'%(CRDeXmfaHgdosJEtqOrclzSwhujMyA,CRDeXmfaHgdosJEtqOrclzSwhujMUy)
   CRDeXmfaHgdosJEtqOrclzSwhujMPB =CRDeXmfaHgdosJEtqOrclzSwhujMyG['genrenm']
   CRDeXmfaHgdosJEtqOrclzSwhujMUb='\t"%s" : { "channelnm" : "%s", "genre" : "%s" }'%(CRDeXmfaHgdosJEtqOrclzSwhujMUP,CRDeXmfaHgdosJEtqOrclzSwhujMyI,CRDeXmfaHgdosJEtqOrclzSwhujMPB)
   if i<CRDeXmfaHgdosJEtqOrclzSwhujMbY:
    fp.write(CRDeXmfaHgdosJEtqOrclzSwhujMUb+',\n')
   else:
    fp.write(CRDeXmfaHgdosJEtqOrclzSwhujMUb+'\n')
  fp.write('}\n')
  fp.close()
  return CRDeXmfaHgdosJEtqOrclzSwhujMbn
# Created by pyminifier (https://github.com/liftoff/pyminifier)
