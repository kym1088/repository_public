__author__="NightRain"
VApwTOnXYxmbkzPShGUWvjuKyldLfe=object
VApwTOnXYxmbkzPShGUWvjuKyldLfB=None
VApwTOnXYxmbkzPShGUWvjuKyldLfs=False
VApwTOnXYxmbkzPShGUWvjuKyldLfi=open
VApwTOnXYxmbkzPShGUWvjuKyldLfM=True
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class VApwTOnXYxmbkzPShGUWvjuKyldLfo(VApwTOnXYxmbkzPShGUWvjuKyldLfe):
 def __init__(VApwTOnXYxmbkzPShGUWvjuKyldLfN):
  VApwTOnXYxmbkzPShGUWvjuKyldLfN.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  VApwTOnXYxmbkzPShGUWvjuKyldLfN.DEFAULT_HEADER ={'user-agent':VApwTOnXYxmbkzPShGUWvjuKyldLfN.USER_AGENT}
 def callRequestCookies(VApwTOnXYxmbkzPShGUWvjuKyldLfN,jobtype,url,payload=VApwTOnXYxmbkzPShGUWvjuKyldLfB,params=VApwTOnXYxmbkzPShGUWvjuKyldLfB,headers=VApwTOnXYxmbkzPShGUWvjuKyldLfB,cookies=VApwTOnXYxmbkzPShGUWvjuKyldLfB,redirects=VApwTOnXYxmbkzPShGUWvjuKyldLfs):
  VApwTOnXYxmbkzPShGUWvjuKyldLfa=VApwTOnXYxmbkzPShGUWvjuKyldLfN.DEFAULT_HEADER
  if headers:VApwTOnXYxmbkzPShGUWvjuKyldLfa.update(headers)
  if jobtype=='Get':
   VApwTOnXYxmbkzPShGUWvjuKyldLfr=requests.get(url,params=params,headers=VApwTOnXYxmbkzPShGUWvjuKyldLfa,cookies=cookies,allow_redirects=redirects)
  else:
   VApwTOnXYxmbkzPShGUWvjuKyldLfr=requests.post(url,data=payload,params=params,headers=VApwTOnXYxmbkzPShGUWvjuKyldLfa,cookies=cookies,allow_redirects=redirects)
  return VApwTOnXYxmbkzPShGUWvjuKyldLfr
 def Get_Now_Datetime(VApwTOnXYxmbkzPShGUWvjuKyldLfN):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def local_dic_To_jsonfile(VApwTOnXYxmbkzPShGUWvjuKyldLfN,filename,dic):
  if filename=='':return VApwTOnXYxmbkzPShGUWvjuKyldLfs
  try:
   fp=VApwTOnXYxmbkzPShGUWvjuKyldLfi(filename,'w',-1,'utf-8')
   json.dump(dic,fp)
   fp.close()
  except:
   return VApwTOnXYxmbkzPShGUWvjuKyldLfs
  return VApwTOnXYxmbkzPShGUWvjuKyldLfM
 def local_jsonfile_To_dic(VApwTOnXYxmbkzPShGUWvjuKyldLfN,filename):
  if filename=='':return VApwTOnXYxmbkzPShGUWvjuKyldLfB
  try:
   fp=VApwTOnXYxmbkzPShGUWvjuKyldLfi(filename,'r',-1,'utf-8')
   VApwTOnXYxmbkzPShGUWvjuKyldLfR=json.load(fp)
   fp.close()
  except:
   VApwTOnXYxmbkzPShGUWvjuKyldLfR={}
  return VApwTOnXYxmbkzPShGUWvjuKyldLfR
# Created by pyminifier (https://github.com/liftoff/pyminifier)
