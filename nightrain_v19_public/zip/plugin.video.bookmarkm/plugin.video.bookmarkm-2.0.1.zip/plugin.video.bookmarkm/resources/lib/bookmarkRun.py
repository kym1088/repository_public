__author__="NightRain"
esbnBPruOHfUSCozNpwvDjIalAVLEc=object
esbnBPruOHfUSCozNpwvDjIalAVLEG=None
esbnBPruOHfUSCozNpwvDjIalAVLEk=True
esbnBPruOHfUSCozNpwvDjIalAVLET=False
esbnBPruOHfUSCozNpwvDjIalAVLEx=type
esbnBPruOHfUSCozNpwvDjIalAVLEy=dict
esbnBPruOHfUSCozNpwvDjIalAVLEq=list
esbnBPruOHfUSCozNpwvDjIalAVLEM=len
esbnBPruOHfUSCozNpwvDjIalAVLEF=int
esbnBPruOHfUSCozNpwvDjIalAVLEh=str
esbnBPruOHfUSCozNpwvDjIalAVLEW=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
esbnBPruOHfUSCozNpwvDjIalAVLtY=[{'title':'찜 목록 (웨이브+티빙+왓챠+쿠팡+넷플)','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','icon':'sum.png'},{'title':'-----------------','mode':'XXX'},{'title':'영화   찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'movie','icon':'movie.png'},{'title':'시리즈 찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'tvshow','icon':'tvshow.png'},{'title':'장르별 찜 목록','mode':'GENRE_GROUP','ott':'-','vidtype':'-','icon':'category.png'},{'title':'-----------------','mode':'XXX'},{'title':'웨이브 찜 목록','mode':'BOOKMARK_GROUP','ott':'wavve','vidtype':'-','icon':'wavve.png'},{'title':'티빙   찜 목록','mode':'BOOKMARK_GROUP','ott':'tving','vidtype':'-','icon':'tving.png'},{'title':'왓챠   찜 목록','mode':'BOOKMARK_GROUP','ott':'watcha','vidtype':'-','icon':'watcha.png'},{'title':'쿠팡   찜 목록','mode':'BOOKMARK_GROUP','ott':'coupang','vidtype':'-','icon':'coupang.png'},{'title':'넷플   찜 목록 (search mini 에서 등록)','mode':'BOOKMARK_GROUP','ott':'netflix','vidtype':'-','icon':'netflix.png'},]
from bookmarkCore import*
class esbnBPruOHfUSCozNpwvDjIalAVLtQ(esbnBPruOHfUSCozNpwvDjIalAVLEc):
 def __init__(esbnBPruOHfUSCozNpwvDjIalAVLtE,esbnBPruOHfUSCozNpwvDjIalAVLtg,esbnBPruOHfUSCozNpwvDjIalAVLtK,esbnBPruOHfUSCozNpwvDjIalAVLtm):
  esbnBPruOHfUSCozNpwvDjIalAVLtE._addon_url =esbnBPruOHfUSCozNpwvDjIalAVLtg
  esbnBPruOHfUSCozNpwvDjIalAVLtE._addon_handle=esbnBPruOHfUSCozNpwvDjIalAVLtK
  esbnBPruOHfUSCozNpwvDjIalAVLtE.main_params =esbnBPruOHfUSCozNpwvDjIalAVLtm
  esbnBPruOHfUSCozNpwvDjIalAVLtE.LIB_PATH =''
  esbnBPruOHfUSCozNpwvDjIalAVLtE.LIST_LIMIT =20
  esbnBPruOHfUSCozNpwvDjIalAVLtE.BookmarkObj =VApwTOnXYxmbkzPShGUWvjuKyldLfo() 
 def addon_noti(esbnBPruOHfUSCozNpwvDjIalAVLtE,sting):
  try:
   esbnBPruOHfUSCozNpwvDjIalAVLtR=xbmcgui.Dialog()
   esbnBPruOHfUSCozNpwvDjIalAVLtR.notification(__addonname__,sting)
  except:
   esbnBPruOHfUSCozNpwvDjIalAVLEG
 def addon_log(esbnBPruOHfUSCozNpwvDjIalAVLtE,string):
  try:
   esbnBPruOHfUSCozNpwvDjIalAVLtX=string.encode('utf-8','ignore')
  except:
   esbnBPruOHfUSCozNpwvDjIalAVLtX='addonException: addon_log'
  esbnBPruOHfUSCozNpwvDjIalAVLtd=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,esbnBPruOHfUSCozNpwvDjIalAVLtX),level=esbnBPruOHfUSCozNpwvDjIalAVLtd)
 def get_settings_select_ott(esbnBPruOHfUSCozNpwvDjIalAVLtE):
  esbnBPruOHfUSCozNpwvDjIalAVLtJ =esbnBPruOHfUSCozNpwvDjIalAVLEk if __addon__.getSetting('view_wavve')=='true' else esbnBPruOHfUSCozNpwvDjIalAVLET
  esbnBPruOHfUSCozNpwvDjIalAVLtc =esbnBPruOHfUSCozNpwvDjIalAVLEk if __addon__.getSetting('view_tving')=='true' else esbnBPruOHfUSCozNpwvDjIalAVLET
  esbnBPruOHfUSCozNpwvDjIalAVLtG =esbnBPruOHfUSCozNpwvDjIalAVLEk if __addon__.getSetting('view_watcha')=='true' else esbnBPruOHfUSCozNpwvDjIalAVLET
  esbnBPruOHfUSCozNpwvDjIalAVLtk=esbnBPruOHfUSCozNpwvDjIalAVLEk if __addon__.getSetting('view_coupang')=='true' else esbnBPruOHfUSCozNpwvDjIalAVLET
  esbnBPruOHfUSCozNpwvDjIalAVLtT=esbnBPruOHfUSCozNpwvDjIalAVLEk if __addon__.getSetting('view_netflix')=='true' else esbnBPruOHfUSCozNpwvDjIalAVLET
  return(esbnBPruOHfUSCozNpwvDjIalAVLtJ,esbnBPruOHfUSCozNpwvDjIalAVLtc,esbnBPruOHfUSCozNpwvDjIalAVLtG,esbnBPruOHfUSCozNpwvDjIalAVLtk,esbnBPruOHfUSCozNpwvDjIalAVLtT)
 def make_Index_Filename(esbnBPruOHfUSCozNpwvDjIalAVLtE,tempyn=esbnBPruOHfUSCozNpwvDjIalAVLET):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_index_file.json'))
  else:
   return esbnBPruOHfUSCozNpwvDjIalAVLtE.LIB_PATH+'bookmark_index.json'
 def make_Vinfo_Filename(esbnBPruOHfUSCozNpwvDjIalAVLtE,esbnBPruOHfUSCozNpwvDjIalAVLQF,esbnBPruOHfUSCozNpwvDjIalAVLQh,tempyn=esbnBPruOHfUSCozNpwvDjIalAVLET):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_vinfo_file.json'))
  else:
   esbnBPruOHfUSCozNpwvDjIalAVLtx='%s_%s.json'%(esbnBPruOHfUSCozNpwvDjIalAVLQF,esbnBPruOHfUSCozNpwvDjIalAVLQh)
   return esbnBPruOHfUSCozNpwvDjIalAVLtE.LIB_PATH+esbnBPruOHfUSCozNpwvDjIalAVLtx
 def add_dir(esbnBPruOHfUSCozNpwvDjIalAVLtE,label,sublabel='',ott='',img='',infoLabels=esbnBPruOHfUSCozNpwvDjIalAVLEG,isFolder=esbnBPruOHfUSCozNpwvDjIalAVLEk,params='',isLink=esbnBPruOHfUSCozNpwvDjIalAVLET,ContextMenu=esbnBPruOHfUSCozNpwvDjIalAVLEG):
  esbnBPruOHfUSCozNpwvDjIalAVLty='%s?%s'%(esbnBPruOHfUSCozNpwvDjIalAVLtE._addon_url,urllib.parse.urlencode(params))
  if sublabel and sublabel!='-':esbnBPruOHfUSCozNpwvDjIalAVLtq='%s < %s >'%(label,sublabel)
  else: esbnBPruOHfUSCozNpwvDjIalAVLtq=label
  if not img:img='DefaultFolder.png'
  if ott:esbnBPruOHfUSCozNpwvDjIalAVLtq='%s - [%s]'%(esbnBPruOHfUSCozNpwvDjIalAVLtq,ott)
  esbnBPruOHfUSCozNpwvDjIalAVLtM=xbmcgui.ListItem(esbnBPruOHfUSCozNpwvDjIalAVLtq)
  if esbnBPruOHfUSCozNpwvDjIalAVLEx(img)==esbnBPruOHfUSCozNpwvDjIalAVLEy:
   esbnBPruOHfUSCozNpwvDjIalAVLtM.setArt(img)
  else:
   esbnBPruOHfUSCozNpwvDjIalAVLtM.setArt({'thumb':img,'poster':img})
  esbnBPruOHfUSCozNpwvDjIalAVLtF=[]
  if infoLabels!=esbnBPruOHfUSCozNpwvDjIalAVLEG:
   if esbnBPruOHfUSCozNpwvDjIalAVLEx(infoLabels.get('cast'))==esbnBPruOHfUSCozNpwvDjIalAVLEq:
    if esbnBPruOHfUSCozNpwvDjIalAVLEM(infoLabels.get('cast'))>0 and esbnBPruOHfUSCozNpwvDjIalAVLEx(infoLabels.get('cast')[0])==esbnBPruOHfUSCozNpwvDjIalAVLEy:
     esbnBPruOHfUSCozNpwvDjIalAVLtF=infoLabels.get('cast')
     infoLabels['cast']=[]
  if infoLabels:esbnBPruOHfUSCozNpwvDjIalAVLtM.setInfo('Video',infoLabels)
  if esbnBPruOHfUSCozNpwvDjIalAVLEM(esbnBPruOHfUSCozNpwvDjIalAVLtF)>0:esbnBPruOHfUSCozNpwvDjIalAVLtM.setCast(esbnBPruOHfUSCozNpwvDjIalAVLtF)
  if not isFolder and not isLink:
   esbnBPruOHfUSCozNpwvDjIalAVLtM.setProperty('IsPlayable','true')
  if ContextMenu:esbnBPruOHfUSCozNpwvDjIalAVLtM.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(esbnBPruOHfUSCozNpwvDjIalAVLtE._addon_handle,esbnBPruOHfUSCozNpwvDjIalAVLty,esbnBPruOHfUSCozNpwvDjIalAVLtM,isFolder)
 def dp_Main_List(esbnBPruOHfUSCozNpwvDjIalAVLtE):
  (esbnBPruOHfUSCozNpwvDjIalAVLtJ,esbnBPruOHfUSCozNpwvDjIalAVLtc,esbnBPruOHfUSCozNpwvDjIalAVLtG,esbnBPruOHfUSCozNpwvDjIalAVLtk,esbnBPruOHfUSCozNpwvDjIalAVLtT)=esbnBPruOHfUSCozNpwvDjIalAVLtE.get_settings_select_ott()
  for esbnBPruOHfUSCozNpwvDjIalAVLtW in esbnBPruOHfUSCozNpwvDjIalAVLtY:
   esbnBPruOHfUSCozNpwvDjIalAVLtq=esbnBPruOHfUSCozNpwvDjIalAVLtW.get('title')
   esbnBPruOHfUSCozNpwvDjIalAVLQt=''
   if esbnBPruOHfUSCozNpwvDjIalAVLtW.get('ott')=='wavve' and esbnBPruOHfUSCozNpwvDjIalAVLtJ ==esbnBPruOHfUSCozNpwvDjIalAVLET:continue
   elif esbnBPruOHfUSCozNpwvDjIalAVLtW.get('ott')=='tving' and esbnBPruOHfUSCozNpwvDjIalAVLtc ==esbnBPruOHfUSCozNpwvDjIalAVLET:continue
   elif esbnBPruOHfUSCozNpwvDjIalAVLtW.get('ott')=='watcha' and esbnBPruOHfUSCozNpwvDjIalAVLtG ==esbnBPruOHfUSCozNpwvDjIalAVLET:continue
   elif esbnBPruOHfUSCozNpwvDjIalAVLtW.get('ott')=='coupang' and esbnBPruOHfUSCozNpwvDjIalAVLtk==esbnBPruOHfUSCozNpwvDjIalAVLET:continue
   elif esbnBPruOHfUSCozNpwvDjIalAVLtW.get('ott')=='netflix' and esbnBPruOHfUSCozNpwvDjIalAVLtT==esbnBPruOHfUSCozNpwvDjIalAVLET:continue
   esbnBPruOHfUSCozNpwvDjIalAVLQY={'mode':esbnBPruOHfUSCozNpwvDjIalAVLtW.get('mode'),'ott':esbnBPruOHfUSCozNpwvDjIalAVLtW.get('ott'),'vidtype':esbnBPruOHfUSCozNpwvDjIalAVLtW.get('vidtype'),'page':'1',}
   if esbnBPruOHfUSCozNpwvDjIalAVLtW.get('mode')=='XXX':
    esbnBPruOHfUSCozNpwvDjIalAVLQY['mode']='XXX'
    esbnBPruOHfUSCozNpwvDjIalAVLQE=esbnBPruOHfUSCozNpwvDjIalAVLET
    esbnBPruOHfUSCozNpwvDjIalAVLQg =esbnBPruOHfUSCozNpwvDjIalAVLEk
   else:
    if 'icon' in esbnBPruOHfUSCozNpwvDjIalAVLtW:
     esbnBPruOHfUSCozNpwvDjIalAVLQt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',esbnBPruOHfUSCozNpwvDjIalAVLtW.get('icon')) 
    esbnBPruOHfUSCozNpwvDjIalAVLQE=esbnBPruOHfUSCozNpwvDjIalAVLEk
    esbnBPruOHfUSCozNpwvDjIalAVLQg =esbnBPruOHfUSCozNpwvDjIalAVLET
   esbnBPruOHfUSCozNpwvDjIalAVLtE.add_dir(esbnBPruOHfUSCozNpwvDjIalAVLtq,sublabel='',ott='',img=esbnBPruOHfUSCozNpwvDjIalAVLQt,infoLabels=esbnBPruOHfUSCozNpwvDjIalAVLEG,isFolder=esbnBPruOHfUSCozNpwvDjIalAVLQE,params=esbnBPruOHfUSCozNpwvDjIalAVLQY,isLink=esbnBPruOHfUSCozNpwvDjIalAVLQg)
  xbmcplugin.endOfDirectory(esbnBPruOHfUSCozNpwvDjIalAVLtE._addon_handle)
 def dp_Genre_Grouplist(esbnBPruOHfUSCozNpwvDjIalAVLtE,args):
  esbnBPruOHfUSCozNpwvDjIalAVLQm=[]
  esbnBPruOHfUSCozNpwvDjIalAVLQi=esbnBPruOHfUSCozNpwvDjIalAVLtE.make_Index_Filename(tempyn=esbnBPruOHfUSCozNpwvDjIalAVLET)
  if xbmcvfs.exists(esbnBPruOHfUSCozNpwvDjIalAVLQi):
   esbnBPruOHfUSCozNpwvDjIalAVLQR=esbnBPruOHfUSCozNpwvDjIalAVLtE.jsonfile_To_dic(esbnBPruOHfUSCozNpwvDjIalAVLQi)
  else:
   esbnBPruOHfUSCozNpwvDjIalAVLQR=[]
  for esbnBPruOHfUSCozNpwvDjIalAVLQX in esbnBPruOHfUSCozNpwvDjIalAVLQR:
   esbnBPruOHfUSCozNpwvDjIalAVLQd =esbnBPruOHfUSCozNpwvDjIalAVLQX.get('genre')
   if esbnBPruOHfUSCozNpwvDjIalAVLQd not in esbnBPruOHfUSCozNpwvDjIalAVLQm:
    esbnBPruOHfUSCozNpwvDjIalAVLQm.append(esbnBPruOHfUSCozNpwvDjIalAVLQd)
  for esbnBPruOHfUSCozNpwvDjIalAVLQd in esbnBPruOHfUSCozNpwvDjIalAVLQm:
   esbnBPruOHfUSCozNpwvDjIalAVLQY={'mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','genre':esbnBPruOHfUSCozNpwvDjIalAVLQd,'page':'1',}
   esbnBPruOHfUSCozNpwvDjIalAVLtE.add_dir(esbnBPruOHfUSCozNpwvDjIalAVLQd,sublabel='',ott='',img='',infoLabels=esbnBPruOHfUSCozNpwvDjIalAVLEG,isFolder=esbnBPruOHfUSCozNpwvDjIalAVLEk,params=esbnBPruOHfUSCozNpwvDjIalAVLQY)
  xbmcplugin.endOfDirectory(esbnBPruOHfUSCozNpwvDjIalAVLtE._addon_handle)
 def dp_Bookmark_Grouplist(esbnBPruOHfUSCozNpwvDjIalAVLtE,args):
  esbnBPruOHfUSCozNpwvDjIalAVLQJ =esbnBPruOHfUSCozNpwvDjIalAVLET
  esbnBPruOHfUSCozNpwvDjIalAVLQc =[]
  esbnBPruOHfUSCozNpwvDjIalAVLQG =args.get('ott')
  esbnBPruOHfUSCozNpwvDjIalAVLQk=args.get('vidtype')
  esbnBPruOHfUSCozNpwvDjIalAVLQT =args.get('genre')
  if esbnBPruOHfUSCozNpwvDjIalAVLQT==esbnBPruOHfUSCozNpwvDjIalAVLEG:esbnBPruOHfUSCozNpwvDjIalAVLQT='all'
  esbnBPruOHfUSCozNpwvDjIalAVLQx =esbnBPruOHfUSCozNpwvDjIalAVLEF(args.get('page'))
  esbnBPruOHfUSCozNpwvDjIalAVLQy =esbnBPruOHfUSCozNpwvDjIalAVLtE.LIST_LIMIT*(esbnBPruOHfUSCozNpwvDjIalAVLQx-1)+1 
  esbnBPruOHfUSCozNpwvDjIalAVLQq =esbnBPruOHfUSCozNpwvDjIalAVLtE.LIST_LIMIT*esbnBPruOHfUSCozNpwvDjIalAVLQx
  esbnBPruOHfUSCozNpwvDjIalAVLQi=esbnBPruOHfUSCozNpwvDjIalAVLtE.make_Index_Filename(tempyn=esbnBPruOHfUSCozNpwvDjIalAVLET)
  if xbmcvfs.exists(esbnBPruOHfUSCozNpwvDjIalAVLQi):
   esbnBPruOHfUSCozNpwvDjIalAVLQR=esbnBPruOHfUSCozNpwvDjIalAVLtE.jsonfile_To_dic(esbnBPruOHfUSCozNpwvDjIalAVLQi)
  else:
   esbnBPruOHfUSCozNpwvDjIalAVLQR=[]
  esbnBPruOHfUSCozNpwvDjIalAVLQM=0
  for esbnBPruOHfUSCozNpwvDjIalAVLQX in esbnBPruOHfUSCozNpwvDjIalAVLQR:
   esbnBPruOHfUSCozNpwvDjIalAVLQF =esbnBPruOHfUSCozNpwvDjIalAVLQX.get('ott')
   esbnBPruOHfUSCozNpwvDjIalAVLQh=esbnBPruOHfUSCozNpwvDjIalAVLQX.get('videoid')
   esbnBPruOHfUSCozNpwvDjIalAVLQW=esbnBPruOHfUSCozNpwvDjIalAVLQX.get('vidtype')
   esbnBPruOHfUSCozNpwvDjIalAVLYt =esbnBPruOHfUSCozNpwvDjIalAVLQX.get('genre')
   if not(esbnBPruOHfUSCozNpwvDjIalAVLQG=='-' or esbnBPruOHfUSCozNpwvDjIalAVLQG==esbnBPruOHfUSCozNpwvDjIalAVLQF):continue
   if not(esbnBPruOHfUSCozNpwvDjIalAVLQk=='-' or esbnBPruOHfUSCozNpwvDjIalAVLQk==esbnBPruOHfUSCozNpwvDjIalAVLQW):continue
   if not(esbnBPruOHfUSCozNpwvDjIalAVLQT=='all' or esbnBPruOHfUSCozNpwvDjIalAVLQT==esbnBPruOHfUSCozNpwvDjIalAVLYt):continue
   esbnBPruOHfUSCozNpwvDjIalAVLQM+=1
   if esbnBPruOHfUSCozNpwvDjIalAVLQy>esbnBPruOHfUSCozNpwvDjIalAVLQM:continue
   if esbnBPruOHfUSCozNpwvDjIalAVLQq<esbnBPruOHfUSCozNpwvDjIalAVLQM:
    esbnBPruOHfUSCozNpwvDjIalAVLQJ=esbnBPruOHfUSCozNpwvDjIalAVLEk
    break
   esbnBPruOHfUSCozNpwvDjIalAVLYQ=esbnBPruOHfUSCozNpwvDjIalAVLtE.make_Vinfo_Filename(esbnBPruOHfUSCozNpwvDjIalAVLQF,esbnBPruOHfUSCozNpwvDjIalAVLQh,tempyn=esbnBPruOHfUSCozNpwvDjIalAVLET)
   if xbmcvfs.exists(esbnBPruOHfUSCozNpwvDjIalAVLYQ):
    esbnBPruOHfUSCozNpwvDjIalAVLYE=esbnBPruOHfUSCozNpwvDjIalAVLtE.jsonfile_To_dic(esbnBPruOHfUSCozNpwvDjIalAVLYQ)
    esbnBPruOHfUSCozNpwvDjIalAVLtq =esbnBPruOHfUSCozNpwvDjIalAVLYE.get('title')
    esbnBPruOHfUSCozNpwvDjIalAVLYg =esbnBPruOHfUSCozNpwvDjIalAVLYE.get('subtitle')
    esbnBPruOHfUSCozNpwvDjIalAVLYK =esbnBPruOHfUSCozNpwvDjIalAVLYE.get('thumbnail')
    esbnBPruOHfUSCozNpwvDjIalAVLth=esbnBPruOHfUSCozNpwvDjIalAVLYE.get('infoLabels')
   else:
    esbnBPruOHfUSCozNpwvDjIalAVLtq =esbnBPruOHfUSCozNpwvDjIalAVLQX.get('title')
    esbnBPruOHfUSCozNpwvDjIalAVLYg =''
    esbnBPruOHfUSCozNpwvDjIalAVLYK =''
    esbnBPruOHfUSCozNpwvDjIalAVLth={'mpaa':'0'}
    esbnBPruOHfUSCozNpwvDjIalAVLYE ={'infoLabels':{'title':esbnBPruOHfUSCozNpwvDjIalAVLtq}}
   esbnBPruOHfUSCozNpwvDjIalAVLQY={'mode':'HYPER_LINK','ott':esbnBPruOHfUSCozNpwvDjIalAVLQF,'videoid':esbnBPruOHfUSCozNpwvDjIalAVLQh,'vidtype':esbnBPruOHfUSCozNpwvDjIalAVLQW,'title':esbnBPruOHfUSCozNpwvDjIalAVLtq,'thumbnail':esbnBPruOHfUSCozNpwvDjIalAVLYK,'mpaa':esbnBPruOHfUSCozNpwvDjIalAVLEh(esbnBPruOHfUSCozNpwvDjIalAVLth.get('mpaa'))}
   esbnBPruOHfUSCozNpwvDjIalAVLYm={'mode':'BOOKMARK_REMOVE','list':[esbnBPruOHfUSCozNpwvDjIalAVLQX],}
   esbnBPruOHfUSCozNpwvDjIalAVLYi=urllib.parse.urlencode(esbnBPruOHfUSCozNpwvDjIalAVLYm)
   esbnBPruOHfUSCozNpwvDjIalAVLYR=[('찜 목록 ( %s ) 삭제'%(esbnBPruOHfUSCozNpwvDjIalAVLYE.get('infoLabels').get('title')),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(esbnBPruOHfUSCozNpwvDjIalAVLYi))]
   if esbnBPruOHfUSCozNpwvDjIalAVLQT!='all':
    esbnBPruOHfUSCozNpwvDjIalAVLYm={'mode':'GENRE_RENAME','list':[esbnBPruOHfUSCozNpwvDjIalAVLQX],}
    esbnBPruOHfUSCozNpwvDjIalAVLYi=urllib.parse.urlencode(esbnBPruOHfUSCozNpwvDjIalAVLYm)
    esbnBPruOHfUSCozNpwvDjIalAVLYR.append(('장르명 ( %s ) 수정'%(esbnBPruOHfUSCozNpwvDjIalAVLQT),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(esbnBPruOHfUSCozNpwvDjIalAVLYi)))
   esbnBPruOHfUSCozNpwvDjIalAVLtE.add_dir(esbnBPruOHfUSCozNpwvDjIalAVLtq,sublabel=esbnBPruOHfUSCozNpwvDjIalAVLYg,ott=esbnBPruOHfUSCozNpwvDjIalAVLQF,img=esbnBPruOHfUSCozNpwvDjIalAVLYK,infoLabels=esbnBPruOHfUSCozNpwvDjIalAVLth,isFolder=esbnBPruOHfUSCozNpwvDjIalAVLET,params=esbnBPruOHfUSCozNpwvDjIalAVLQY,isLink=esbnBPruOHfUSCozNpwvDjIalAVLEk,ContextMenu=esbnBPruOHfUSCozNpwvDjIalAVLYR)
   esbnBPruOHfUSCozNpwvDjIalAVLQc.append(esbnBPruOHfUSCozNpwvDjIalAVLQX)
  esbnBPruOHfUSCozNpwvDjIalAVLYX={'plot':'현재페이지의 전체목록을 삭제합니다.'}
  esbnBPruOHfUSCozNpwvDjIalAVLtq='* 현재페이지 목록 삭제 (개별삭제는 팝업메뉴) *'
  esbnBPruOHfUSCozNpwvDjIalAVLQY={'mode':'BOOKMARK_REMOVE','list':esbnBPruOHfUSCozNpwvDjIalAVLQc,}
  esbnBPruOHfUSCozNpwvDjIalAVLQt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  esbnBPruOHfUSCozNpwvDjIalAVLtE.add_dir(esbnBPruOHfUSCozNpwvDjIalAVLtq,sublabel='',ott='',img=esbnBPruOHfUSCozNpwvDjIalAVLQt,infoLabels=esbnBPruOHfUSCozNpwvDjIalAVLYX,isFolder=esbnBPruOHfUSCozNpwvDjIalAVLET,params=esbnBPruOHfUSCozNpwvDjIalAVLQY,isLink=esbnBPruOHfUSCozNpwvDjIalAVLEk)
  if esbnBPruOHfUSCozNpwvDjIalAVLQJ:
   esbnBPruOHfUSCozNpwvDjIalAVLQY={'mode':'BOOKMARK_GROUP','ott':esbnBPruOHfUSCozNpwvDjIalAVLQG,'vidtype':esbnBPruOHfUSCozNpwvDjIalAVLQk,'page':esbnBPruOHfUSCozNpwvDjIalAVLEh(esbnBPruOHfUSCozNpwvDjIalAVLQx+1)}
   esbnBPruOHfUSCozNpwvDjIalAVLtq='[B]%s >>[/B]'%'다음 페이지'
   esbnBPruOHfUSCozNpwvDjIalAVLYg=esbnBPruOHfUSCozNpwvDjIalAVLEh(esbnBPruOHfUSCozNpwvDjIalAVLQx+1)
   esbnBPruOHfUSCozNpwvDjIalAVLQt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   esbnBPruOHfUSCozNpwvDjIalAVLtE.add_dir(esbnBPruOHfUSCozNpwvDjIalAVLtq,sublabel=esbnBPruOHfUSCozNpwvDjIalAVLYg,ott='',img=esbnBPruOHfUSCozNpwvDjIalAVLQt,infoLabels=esbnBPruOHfUSCozNpwvDjIalAVLEG,isFolder=esbnBPruOHfUSCozNpwvDjIalAVLEk,params=esbnBPruOHfUSCozNpwvDjIalAVLQY)
  xbmcplugin.setContent(esbnBPruOHfUSCozNpwvDjIalAVLtE._addon_handle,'movies')
  xbmcplugin.endOfDirectory(esbnBPruOHfUSCozNpwvDjIalAVLtE._addon_handle)
 def get_keyboard_input(esbnBPruOHfUSCozNpwvDjIalAVLtE,defalut,esbnBPruOHfUSCozNpwvDjIalAVLtq):
  esbnBPruOHfUSCozNpwvDjIalAVLYd=esbnBPruOHfUSCozNpwvDjIalAVLEG
  kb=xbmc.Keyboard(defalut,esbnBPruOHfUSCozNpwvDjIalAVLtq,esbnBPruOHfUSCozNpwvDjIalAVLET)
  kb.setHeading(esbnBPruOHfUSCozNpwvDjIalAVLtq)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   esbnBPruOHfUSCozNpwvDjIalAVLYd=kb.getText()
  return esbnBPruOHfUSCozNpwvDjIalAVLYd
 def dp_Genre_Rename(esbnBPruOHfUSCozNpwvDjIalAVLtE,args):
  esbnBPruOHfUSCozNpwvDjIalAVLYJ =esbnBPruOHfUSCozNpwvDjIalAVLEk
  esbnBPruOHfUSCozNpwvDjIalAVLYc ={}
  try:
   esbnBPruOHfUSCozNpwvDjIalAVLYG=args.get('list')
   esbnBPruOHfUSCozNpwvDjIalAVLYG=esbnBPruOHfUSCozNpwvDjIalAVLYG.replace('\'','\"')
   esbnBPruOHfUSCozNpwvDjIalAVLYG=json.loads(esbnBPruOHfUSCozNpwvDjIalAVLYG)
  except:
   esbnBPruOHfUSCozNpwvDjIalAVLYJ=esbnBPruOHfUSCozNpwvDjIalAVLET
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   if esbnBPruOHfUSCozNpwvDjIalAVLEM(esbnBPruOHfUSCozNpwvDjIalAVLYG)!=0:
    esbnBPruOHfUSCozNpwvDjIalAVLYk=esbnBPruOHfUSCozNpwvDjIalAVLYG[0].get('genre')
   else:
    return
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLYT=esbnBPruOHfUSCozNpwvDjIalAVLtE.get_keyboard_input(esbnBPruOHfUSCozNpwvDjIalAVLYk,__language__(30909).encode('utf-8'))
   if esbnBPruOHfUSCozNpwvDjIalAVLYT!=esbnBPruOHfUSCozNpwvDjIalAVLEG:
    esbnBPruOHfUSCozNpwvDjIalAVLYT=esbnBPruOHfUSCozNpwvDjIalAVLYT.strip()
   else:
    return
   if esbnBPruOHfUSCozNpwvDjIalAVLYk==esbnBPruOHfUSCozNpwvDjIalAVLYT:
    esbnBPruOHfUSCozNpwvDjIalAVLtE.addon_noti(__language__(30910).encode('utf-8'))
    return
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   for esbnBPruOHfUSCozNpwvDjIalAVLYx in esbnBPruOHfUSCozNpwvDjIalAVLYG:
    if esbnBPruOHfUSCozNpwvDjIalAVLYx['ott']in esbnBPruOHfUSCozNpwvDjIalAVLYc:
     esbnBPruOHfUSCozNpwvDjIalAVLYc[esbnBPruOHfUSCozNpwvDjIalAVLYx['ott']].append(esbnBPruOHfUSCozNpwvDjIalAVLYx['videoid'])
    else:
     esbnBPruOHfUSCozNpwvDjIalAVLYc[esbnBPruOHfUSCozNpwvDjIalAVLYx['ott']]=[esbnBPruOHfUSCozNpwvDjIalAVLYx['videoid']]
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLQi=esbnBPruOHfUSCozNpwvDjIalAVLtE.make_Index_Filename(tempyn=esbnBPruOHfUSCozNpwvDjIalAVLET)
   if xbmcvfs.exists(esbnBPruOHfUSCozNpwvDjIalAVLQi):
    esbnBPruOHfUSCozNpwvDjIalAVLQR=esbnBPruOHfUSCozNpwvDjIalAVLtE.jsonfile_To_dic(esbnBPruOHfUSCozNpwvDjIalAVLQi)
   else:
    esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLET
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   for i in esbnBPruOHfUSCozNpwvDjIalAVLEW(esbnBPruOHfUSCozNpwvDjIalAVLEM(esbnBPruOHfUSCozNpwvDjIalAVLQR)):
    esbnBPruOHfUSCozNpwvDjIalAVLYy =esbnBPruOHfUSCozNpwvDjIalAVLQR[i].get('ott')
    esbnBPruOHfUSCozNpwvDjIalAVLYq=esbnBPruOHfUSCozNpwvDjIalAVLQR[i].get('videoid')
    if esbnBPruOHfUSCozNpwvDjIalAVLYy in esbnBPruOHfUSCozNpwvDjIalAVLYc:
     if esbnBPruOHfUSCozNpwvDjIalAVLYq in esbnBPruOHfUSCozNpwvDjIalAVLYc[esbnBPruOHfUSCozNpwvDjIalAVLYy]:
      esbnBPruOHfUSCozNpwvDjIalAVLQR[i]['genre']=esbnBPruOHfUSCozNpwvDjIalAVLYT
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLYJ=esbnBPruOHfUSCozNpwvDjIalAVLtE.dic_To_jsonfile(esbnBPruOHfUSCozNpwvDjIalAVLQi,esbnBPruOHfUSCozNpwvDjIalAVLQR)
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLtE.addon_noti(__language__(30911).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   esbnBPruOHfUSCozNpwvDjIalAVLtE.addon_noti(__language__(30912).encode('utf-8'))
 def dp_Bookmark_Remove(esbnBPruOHfUSCozNpwvDjIalAVLtE,args):
  esbnBPruOHfUSCozNpwvDjIalAVLYJ =esbnBPruOHfUSCozNpwvDjIalAVLEk
  esbnBPruOHfUSCozNpwvDjIalAVLYM ={}
  esbnBPruOHfUSCozNpwvDjIalAVLtR=xbmcgui.Dialog()
  esbnBPruOHfUSCozNpwvDjIalAVLYF=esbnBPruOHfUSCozNpwvDjIalAVLtR.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if esbnBPruOHfUSCozNpwvDjIalAVLYF==esbnBPruOHfUSCozNpwvDjIalAVLET:sys.exit()
  try:
   esbnBPruOHfUSCozNpwvDjIalAVLYG=args.get('list')
   esbnBPruOHfUSCozNpwvDjIalAVLYG=esbnBPruOHfUSCozNpwvDjIalAVLYG.replace('\'','\"')
   esbnBPruOHfUSCozNpwvDjIalAVLYG=json.loads(esbnBPruOHfUSCozNpwvDjIalAVLYG)
  except:
   esbnBPruOHfUSCozNpwvDjIalAVLYJ=esbnBPruOHfUSCozNpwvDjIalAVLET
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   for esbnBPruOHfUSCozNpwvDjIalAVLYx in esbnBPruOHfUSCozNpwvDjIalAVLYG:
    if esbnBPruOHfUSCozNpwvDjIalAVLYx['ott']in esbnBPruOHfUSCozNpwvDjIalAVLYM:
     esbnBPruOHfUSCozNpwvDjIalAVLYM[esbnBPruOHfUSCozNpwvDjIalAVLYx['ott']].append(esbnBPruOHfUSCozNpwvDjIalAVLYx['videoid'])
    else:
     esbnBPruOHfUSCozNpwvDjIalAVLYM[esbnBPruOHfUSCozNpwvDjIalAVLYx['ott']]=[esbnBPruOHfUSCozNpwvDjIalAVLYx['videoid']]
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLQi=esbnBPruOHfUSCozNpwvDjIalAVLtE.make_Index_Filename(tempyn=esbnBPruOHfUSCozNpwvDjIalAVLET)
   if xbmcvfs.exists(esbnBPruOHfUSCozNpwvDjIalAVLQi):
    esbnBPruOHfUSCozNpwvDjIalAVLQR=esbnBPruOHfUSCozNpwvDjIalAVLtE.jsonfile_To_dic(esbnBPruOHfUSCozNpwvDjIalAVLQi)
   else:
    esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLET
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLQX=[]
   for esbnBPruOHfUSCozNpwvDjIalAVLYh in esbnBPruOHfUSCozNpwvDjIalAVLQR:
    esbnBPruOHfUSCozNpwvDjIalAVLYy =esbnBPruOHfUSCozNpwvDjIalAVLYh.get('ott')
    esbnBPruOHfUSCozNpwvDjIalAVLYq=esbnBPruOHfUSCozNpwvDjIalAVLYh.get('videoid')
    if esbnBPruOHfUSCozNpwvDjIalAVLYy in esbnBPruOHfUSCozNpwvDjIalAVLYM:
     if esbnBPruOHfUSCozNpwvDjIalAVLYq in esbnBPruOHfUSCozNpwvDjIalAVLYM[esbnBPruOHfUSCozNpwvDjIalAVLYy]:
      esbnBPruOHfUSCozNpwvDjIalAVLYQ=esbnBPruOHfUSCozNpwvDjIalAVLtE.make_Vinfo_Filename(esbnBPruOHfUSCozNpwvDjIalAVLYy,esbnBPruOHfUSCozNpwvDjIalAVLYq,tempyn=esbnBPruOHfUSCozNpwvDjIalAVLET)
      xbmcvfs.delete(esbnBPruOHfUSCozNpwvDjIalAVLYQ)
      continue
    esbnBPruOHfUSCozNpwvDjIalAVLQX.append(esbnBPruOHfUSCozNpwvDjIalAVLYh)
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLEG
   esbnBPruOHfUSCozNpwvDjIalAVLYJ=esbnBPruOHfUSCozNpwvDjIalAVLtE.dic_To_jsonfile(esbnBPruOHfUSCozNpwvDjIalAVLQi,esbnBPruOHfUSCozNpwvDjIalAVLQX)
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLtE.addon_noti(__language__(30908).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   esbnBPruOHfUSCozNpwvDjIalAVLtE.addon_noti(__language__(30907).encode('utf-8'))
 def dp_Hyper_Link(esbnBPruOHfUSCozNpwvDjIalAVLtE,args):
  esbnBPruOHfUSCozNpwvDjIalAVLQF =args.get('ott')
  esbnBPruOHfUSCozNpwvDjIalAVLQh =args.get('videoid')
  esbnBPruOHfUSCozNpwvDjIalAVLQW =args.get('vidtype')
  esbnBPruOHfUSCozNpwvDjIalAVLtq =args.get('title')
  esbnBPruOHfUSCozNpwvDjIalAVLYK =args.get('thumbnail')
  esbnBPruOHfUSCozNpwvDjIalAVLYW =args.get('mpaa')
  if esbnBPruOHfUSCozNpwvDjIalAVLQF=='wavve':
   if esbnBPruOHfUSCozNpwvDjIalAVLQW=='tvshow':
    esbnBPruOHfUSCozNpwvDjIalAVLEt={'mode':'EPISODE_LIST','videoid':esbnBPruOHfUSCozNpwvDjIalAVLQh,'vidtype':esbnBPruOHfUSCozNpwvDjIalAVLQW,'page':'1',}
    esbnBPruOHfUSCozNpwvDjIalAVLEQ=urllib.parse.urlencode(esbnBPruOHfUSCozNpwvDjIalAVLEt)
    esbnBPruOHfUSCozNpwvDjIalAVLEY='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(esbnBPruOHfUSCozNpwvDjIalAVLEQ)
   else:
    esbnBPruOHfUSCozNpwvDjIalAVLEt={'mode':'MOVIE','contentid':esbnBPruOHfUSCozNpwvDjIalAVLQh,'title':esbnBPruOHfUSCozNpwvDjIalAVLtq,'thumbnail':esbnBPruOHfUSCozNpwvDjIalAVLYK,'age':esbnBPruOHfUSCozNpwvDjIalAVLYW,}
    esbnBPruOHfUSCozNpwvDjIalAVLEQ=urllib.parse.urlencode(esbnBPruOHfUSCozNpwvDjIalAVLEt)
    esbnBPruOHfUSCozNpwvDjIalAVLEY='PlayMedia("plugin://plugin.video.wavvem/?%s")'%(esbnBPruOHfUSCozNpwvDjIalAVLEQ)
  elif esbnBPruOHfUSCozNpwvDjIalAVLQF=='tving':
   if esbnBPruOHfUSCozNpwvDjIalAVLQW=='tvshow':
    esbnBPruOHfUSCozNpwvDjIalAVLEt={'mode':'EPISODE','programcode':esbnBPruOHfUSCozNpwvDjIalAVLQh,'page':'1',}
    esbnBPruOHfUSCozNpwvDjIalAVLEQ=urllib.parse.urlencode(esbnBPruOHfUSCozNpwvDjIalAVLEt)
    esbnBPruOHfUSCozNpwvDjIalAVLEY='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(esbnBPruOHfUSCozNpwvDjIalAVLEQ)
   else:
    esbnBPruOHfUSCozNpwvDjIalAVLEt={'mode':'MOVIE','stype':'movie','mediacode':esbnBPruOHfUSCozNpwvDjIalAVLQh,'title':esbnBPruOHfUSCozNpwvDjIalAVLtq,'thumbnail':esbnBPruOHfUSCozNpwvDjIalAVLYK,}
    esbnBPruOHfUSCozNpwvDjIalAVLEQ=urllib.parse.urlencode(esbnBPruOHfUSCozNpwvDjIalAVLEt)
    esbnBPruOHfUSCozNpwvDjIalAVLEY='PlayMedia("plugin://plugin.video.tvingm/?%s")'%(esbnBPruOHfUSCozNpwvDjIalAVLEQ)
  elif esbnBPruOHfUSCozNpwvDjIalAVLQF=='watcha':
   if esbnBPruOHfUSCozNpwvDjIalAVLQW=='tvshow':
    esbnBPruOHfUSCozNpwvDjIalAVLEt={'mode':'EPISODE','movie_code':esbnBPruOHfUSCozNpwvDjIalAVLQh,'season_code':esbnBPruOHfUSCozNpwvDjIalAVLQh,'page':'1',}
    esbnBPruOHfUSCozNpwvDjIalAVLEQ=urllib.parse.urlencode(esbnBPruOHfUSCozNpwvDjIalAVLEt)
    esbnBPruOHfUSCozNpwvDjIalAVLEY='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(esbnBPruOHfUSCozNpwvDjIalAVLEQ)
   else:
    esbnBPruOHfUSCozNpwvDjIalAVLEt={'mode':'MOVIE','movie_code':esbnBPruOHfUSCozNpwvDjIalAVLQh,'season_code':'-','title':esbnBPruOHfUSCozNpwvDjIalAVLtq,'thumbnail':esbnBPruOHfUSCozNpwvDjIalAVLYK,}
    esbnBPruOHfUSCozNpwvDjIalAVLEQ=urllib.parse.urlencode(esbnBPruOHfUSCozNpwvDjIalAVLEt)
    esbnBPruOHfUSCozNpwvDjIalAVLEY='PlayMedia("plugin://plugin.video.watcham/?%s")'%(esbnBPruOHfUSCozNpwvDjIalAVLEQ)
  elif esbnBPruOHfUSCozNpwvDjIalAVLQF=='coupang':
   if esbnBPruOHfUSCozNpwvDjIalAVLQW=='tvshow':
    esbnBPruOHfUSCozNpwvDjIalAVLEt={'mode':'SEASON_LIST','id':esbnBPruOHfUSCozNpwvDjIalAVLQh,'asis':'TVSHOW','title':esbnBPruOHfUSCozNpwvDjIalAVLtq,'thumbnail':esbnBPruOHfUSCozNpwvDjIalAVLYK,'page':'1',}
    esbnBPruOHfUSCozNpwvDjIalAVLEQ=urllib.parse.urlencode(esbnBPruOHfUSCozNpwvDjIalAVLEt)
    esbnBPruOHfUSCozNpwvDjIalAVLEY='ActivateWindow(10025,"plugin://plugin.video.coupangm/?%s",return)'%(esbnBPruOHfUSCozNpwvDjIalAVLEQ)
   else:
    esbnBPruOHfUSCozNpwvDjIalAVLEt={'mode':'MOVIE','id':esbnBPruOHfUSCozNpwvDjIalAVLQh,'asis':'MOVIE','title':esbnBPruOHfUSCozNpwvDjIalAVLtq,'thumbnail':esbnBPruOHfUSCozNpwvDjIalAVLYK,}
    esbnBPruOHfUSCozNpwvDjIalAVLEQ=urllib.parse.urlencode(esbnBPruOHfUSCozNpwvDjIalAVLEt)
    esbnBPruOHfUSCozNpwvDjIalAVLEY='PlayMedia("plugin://plugin.video.coupangm/?%s")'%(esbnBPruOHfUSCozNpwvDjIalAVLEQ)
  elif esbnBPruOHfUSCozNpwvDjIalAVLQF=='netflix':
   if esbnBPruOHfUSCozNpwvDjIalAVLQW=='tvshow':
    esbnBPruOHfUSCozNpwvDjIalAVLEY='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(esbnBPruOHfUSCozNpwvDjIalAVLQh)
   else:
    esbnBPruOHfUSCozNpwvDjIalAVLEY='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/")'%(esbnBPruOHfUSCozNpwvDjIalAVLQh)
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(esbnBPruOHfUSCozNpwvDjIalAVLEY)
 def dp_Set_Bookmark(esbnBPruOHfUSCozNpwvDjIalAVLtE,args):
  esbnBPruOHfUSCozNpwvDjIalAVLYJ =esbnBPruOHfUSCozNpwvDjIalAVLEk
  esbnBPruOHfUSCozNpwvDjIalAVLQR=[]
  esbnBPruOHfUSCozNpwvDjIalAVLEg =urllib.parse.unquote(args.get('bm_param'))
  esbnBPruOHfUSCozNpwvDjIalAVLEg =json.loads(esbnBPruOHfUSCozNpwvDjIalAVLEg)
  esbnBPruOHfUSCozNpwvDjIalAVLQX=esbnBPruOHfUSCozNpwvDjIalAVLEg.get('indexinfo')
  esbnBPruOHfUSCozNpwvDjIalAVLYE =esbnBPruOHfUSCozNpwvDjIalAVLEg.get('saveinfo')
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLYQ=esbnBPruOHfUSCozNpwvDjIalAVLtE.make_Vinfo_Filename(esbnBPruOHfUSCozNpwvDjIalAVLQX.get('ott'),esbnBPruOHfUSCozNpwvDjIalAVLQX.get('videoid'),tempyn=esbnBPruOHfUSCozNpwvDjIalAVLET)
   esbnBPruOHfUSCozNpwvDjIalAVLYJ=esbnBPruOHfUSCozNpwvDjIalAVLtE.dic_To_jsonfile(esbnBPruOHfUSCozNpwvDjIalAVLYQ,esbnBPruOHfUSCozNpwvDjIalAVLYE)
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLQi=esbnBPruOHfUSCozNpwvDjIalAVLtE.make_Index_Filename(tempyn=esbnBPruOHfUSCozNpwvDjIalAVLET)
   if xbmcvfs.exists(esbnBPruOHfUSCozNpwvDjIalAVLQi):
    esbnBPruOHfUSCozNpwvDjIalAVLQR=esbnBPruOHfUSCozNpwvDjIalAVLtE.jsonfile_To_dic(esbnBPruOHfUSCozNpwvDjIalAVLQi)
   else:
    esbnBPruOHfUSCozNpwvDjIalAVLQR=[]
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLEK =esbnBPruOHfUSCozNpwvDjIalAVLQX.get('ott')
   esbnBPruOHfUSCozNpwvDjIalAVLEm =esbnBPruOHfUSCozNpwvDjIalAVLQX.get('videoid')
   for i in esbnBPruOHfUSCozNpwvDjIalAVLEW(esbnBPruOHfUSCozNpwvDjIalAVLEM(esbnBPruOHfUSCozNpwvDjIalAVLQR)):
    esbnBPruOHfUSCozNpwvDjIalAVLYy =esbnBPruOHfUSCozNpwvDjIalAVLQR[i].get('ott')
    esbnBPruOHfUSCozNpwvDjIalAVLYq=esbnBPruOHfUSCozNpwvDjIalAVLQR[i].get('videoid')
    if esbnBPruOHfUSCozNpwvDjIalAVLEK==esbnBPruOHfUSCozNpwvDjIalAVLYy and esbnBPruOHfUSCozNpwvDjIalAVLEm==esbnBPruOHfUSCozNpwvDjIalAVLYq:
     esbnBPruOHfUSCozNpwvDjIalAVLQR.pop(i)
     break
   esbnBPruOHfUSCozNpwvDjIalAVLQX['title']=esbnBPruOHfUSCozNpwvDjIalAVLYE.get('title')
   if esbnBPruOHfUSCozNpwvDjIalAVLEM(esbnBPruOHfUSCozNpwvDjIalAVLYE.get('infoLabels').get('genre'))>0:
    esbnBPruOHfUSCozNpwvDjIalAVLQX['genre']=esbnBPruOHfUSCozNpwvDjIalAVLYE.get('infoLabels').get('genre')[0]
   else:
    esbnBPruOHfUSCozNpwvDjIalAVLQX['genre']='-'
   esbnBPruOHfUSCozNpwvDjIalAVLQR.insert(0,esbnBPruOHfUSCozNpwvDjIalAVLQX)
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLYJ=esbnBPruOHfUSCozNpwvDjIalAVLtE.dic_To_jsonfile(esbnBPruOHfUSCozNpwvDjIalAVLQi,esbnBPruOHfUSCozNpwvDjIalAVLQR)
  if esbnBPruOHfUSCozNpwvDjIalAVLYJ==esbnBPruOHfUSCozNpwvDjIalAVLEk:
   esbnBPruOHfUSCozNpwvDjIalAVLtE.addon_noti(__language__(30903).encode('utf8'))
  else:
   esbnBPruOHfUSCozNpwvDjIalAVLtE.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(esbnBPruOHfUSCozNpwvDjIalAVLtE):
  esbnBPruOHfUSCozNpwvDjIalAVLEi=esbnBPruOHfUSCozNpwvDjIalAVLEk
  esbnBPruOHfUSCozNpwvDjIalAVLtE.LIB_PATH =(__addon__.getSetting('libpath')).strip()
  if esbnBPruOHfUSCozNpwvDjIalAVLtE.LIB_PATH=='':esbnBPruOHfUSCozNpwvDjIalAVLEi=esbnBPruOHfUSCozNpwvDjIalAVLET
  if esbnBPruOHfUSCozNpwvDjIalAVLEi==esbnBPruOHfUSCozNpwvDjIalAVLET:
   esbnBPruOHfUSCozNpwvDjIalAVLtR=xbmcgui.Dialog()
   esbnBPruOHfUSCozNpwvDjIalAVLYF=esbnBPruOHfUSCozNpwvDjIalAVLtR.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if esbnBPruOHfUSCozNpwvDjIalAVLYF==esbnBPruOHfUSCozNpwvDjIalAVLEk:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def dic_To_jsonfile(esbnBPruOHfUSCozNpwvDjIalAVLtE,filename,esbnBPruOHfUSCozNpwvDjIalAVLER):
  if filename=='':return esbnBPruOHfUSCozNpwvDjIalAVLET
  try:
   fp=xbmcvfs.File(filename,'w')
   json.dump(esbnBPruOHfUSCozNpwvDjIalAVLER,fp,indent=4,ensure_ascii=esbnBPruOHfUSCozNpwvDjIalAVLET)
   fp.close()
  except:
   return esbnBPruOHfUSCozNpwvDjIalAVLET
  return esbnBPruOHfUSCozNpwvDjIalAVLEk
 def jsonfile_To_dic(esbnBPruOHfUSCozNpwvDjIalAVLtE,filename):
  if filename=='':return esbnBPruOHfUSCozNpwvDjIalAVLEG
  try:
   fp=xbmcvfs.File(filename)
   esbnBPruOHfUSCozNpwvDjIalAVLEd=json.load(fp)
   fp.close()
  except:
   esbnBPruOHfUSCozNpwvDjIalAVLEd={}
  return esbnBPruOHfUSCozNpwvDjIalAVLEd
 def bookmark_main(esbnBPruOHfUSCozNpwvDjIalAVLtE):
  esbnBPruOHfUSCozNpwvDjIalAVLEJ=esbnBPruOHfUSCozNpwvDjIalAVLtE.main_params.get('mode',esbnBPruOHfUSCozNpwvDjIalAVLEG)
  esbnBPruOHfUSCozNpwvDjIalAVLtE.option_check()
  if esbnBPruOHfUSCozNpwvDjIalAVLEJ is esbnBPruOHfUSCozNpwvDjIalAVLEG:
   esbnBPruOHfUSCozNpwvDjIalAVLtE.dp_Main_List()
  elif esbnBPruOHfUSCozNpwvDjIalAVLEJ=='SET_BOOKMARK':
   esbnBPruOHfUSCozNpwvDjIalAVLtE.dp_Set_Bookmark(esbnBPruOHfUSCozNpwvDjIalAVLtE.main_params)
  elif esbnBPruOHfUSCozNpwvDjIalAVLEJ=='GENRE_GROUP':
   esbnBPruOHfUSCozNpwvDjIalAVLtE.dp_Genre_Grouplist(esbnBPruOHfUSCozNpwvDjIalAVLtE.main_params)
  elif esbnBPruOHfUSCozNpwvDjIalAVLEJ=='BOOKMARK_GROUP':
   esbnBPruOHfUSCozNpwvDjIalAVLtE.dp_Bookmark_Grouplist(esbnBPruOHfUSCozNpwvDjIalAVLtE.main_params)
  elif esbnBPruOHfUSCozNpwvDjIalAVLEJ=='HYPER_LINK':
   esbnBPruOHfUSCozNpwvDjIalAVLtE.dp_Hyper_Link(esbnBPruOHfUSCozNpwvDjIalAVLtE.main_params)
  elif esbnBPruOHfUSCozNpwvDjIalAVLEJ=='BOOKMARK_REMOVE':
   esbnBPruOHfUSCozNpwvDjIalAVLtE.dp_Bookmark_Remove(esbnBPruOHfUSCozNpwvDjIalAVLtE.main_params)
  elif esbnBPruOHfUSCozNpwvDjIalAVLEJ=='GENRE_RENAME':
   esbnBPruOHfUSCozNpwvDjIalAVLtE.dp_Genre_Rename(esbnBPruOHfUSCozNpwvDjIalAVLtE.main_params)
  else:
   esbnBPruOHfUSCozNpwvDjIalAVLEG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
