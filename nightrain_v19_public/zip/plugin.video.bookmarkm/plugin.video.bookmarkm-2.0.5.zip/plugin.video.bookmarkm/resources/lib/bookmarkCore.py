__author__="NightRain"
gvOfzGxBKHiUFDjaJuCVrWkwQSEIhb=object
gvOfzGxBKHiUFDjaJuCVrWkwQSEIhq=None
gvOfzGxBKHiUFDjaJuCVrWkwQSEIhy=False
gvOfzGxBKHiUFDjaJuCVrWkwQSEIhR=open
gvOfzGxBKHiUFDjaJuCVrWkwQSEIhm=True
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class gvOfzGxBKHiUFDjaJuCVrWkwQSEIhX(gvOfzGxBKHiUFDjaJuCVrWkwQSEIhb):
 def __init__(gvOfzGxBKHiUFDjaJuCVrWkwQSEIhA):
  gvOfzGxBKHiUFDjaJuCVrWkwQSEIhA.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  gvOfzGxBKHiUFDjaJuCVrWkwQSEIhA.DEFAULT_HEADER ={'user-agent':gvOfzGxBKHiUFDjaJuCVrWkwQSEIhA.USER_AGENT}
 def callRequestCookies(gvOfzGxBKHiUFDjaJuCVrWkwQSEIhA,jobtype,url,payload=gvOfzGxBKHiUFDjaJuCVrWkwQSEIhq,params=gvOfzGxBKHiUFDjaJuCVrWkwQSEIhq,headers=gvOfzGxBKHiUFDjaJuCVrWkwQSEIhq,cookies=gvOfzGxBKHiUFDjaJuCVrWkwQSEIhq,redirects=gvOfzGxBKHiUFDjaJuCVrWkwQSEIhy):
  gvOfzGxBKHiUFDjaJuCVrWkwQSEIhP=gvOfzGxBKHiUFDjaJuCVrWkwQSEIhA.DEFAULT_HEADER
  if headers:gvOfzGxBKHiUFDjaJuCVrWkwQSEIhP.update(headers)
  if jobtype=='Get':
   gvOfzGxBKHiUFDjaJuCVrWkwQSEIhc=requests.get(url,params=params,headers=gvOfzGxBKHiUFDjaJuCVrWkwQSEIhP,cookies=cookies,allow_redirects=redirects)
  else:
   gvOfzGxBKHiUFDjaJuCVrWkwQSEIhc=requests.post(url,data=payload,params=params,headers=gvOfzGxBKHiUFDjaJuCVrWkwQSEIhP,cookies=cookies,allow_redirects=redirects)
  return gvOfzGxBKHiUFDjaJuCVrWkwQSEIhc
 def Get_Now_Datetime(gvOfzGxBKHiUFDjaJuCVrWkwQSEIhA):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def local_dic_To_jsonfile(gvOfzGxBKHiUFDjaJuCVrWkwQSEIhA,filename,dic):
  if filename=='':return gvOfzGxBKHiUFDjaJuCVrWkwQSEIhy
  try:
   fp=gvOfzGxBKHiUFDjaJuCVrWkwQSEIhR(filename,'w',-1,'utf-8')
   json.dump(dic,fp)
   fp.close()
  except:
   return gvOfzGxBKHiUFDjaJuCVrWkwQSEIhy
  return gvOfzGxBKHiUFDjaJuCVrWkwQSEIhm
 def local_jsonfile_To_dic(gvOfzGxBKHiUFDjaJuCVrWkwQSEIhA,filename):
  if filename=='':return gvOfzGxBKHiUFDjaJuCVrWkwQSEIhq
  try:
   fp=gvOfzGxBKHiUFDjaJuCVrWkwQSEIhR(filename,'r',-1,'utf-8')
   gvOfzGxBKHiUFDjaJuCVrWkwQSEIhn=json.load(fp)
   fp.close()
  except:
   gvOfzGxBKHiUFDjaJuCVrWkwQSEIhn={}
  return gvOfzGxBKHiUFDjaJuCVrWkwQSEIhn
# Created by pyminifier (https://github.com/liftoff/pyminifier)
