__author__="NightRain"
sozlvHYqVGbpOgwdIjLNRmrEiyaknc=object
sozlvHYqVGbpOgwdIjLNRmrEiyaknF=None
sozlvHYqVGbpOgwdIjLNRmrEiyaknT=True
sozlvHYqVGbpOgwdIjLNRmrEiyaknM=False
sozlvHYqVGbpOgwdIjLNRmrEiyaknh=type
sozlvHYqVGbpOgwdIjLNRmrEiyaknP=dict
sozlvHYqVGbpOgwdIjLNRmrEiyaknX=list
sozlvHYqVGbpOgwdIjLNRmrEiyaknB=len
sozlvHYqVGbpOgwdIjLNRmrEiyaknA=int
sozlvHYqVGbpOgwdIjLNRmrEiyaknW=str
sozlvHYqVGbpOgwdIjLNRmrEiyaknC=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
sozlvHYqVGbpOgwdIjLNRmrEiyakSc=[{'title':'찜 목록 (웨이브+티빙+왓챠+쿠팡+넷플)','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','icon':'sum.png'},{'title':'-----------------','mode':'XXX'},{'title':'영화   찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'movie','icon':'movie.png'},{'title':'시리즈 찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'tvshow','icon':'tvshow.png'},{'title':'장르별 찜 목록','mode':'GENRE_GROUP','ott':'-','vidtype':'-','icon':'category.png'},{'title':'-----------------','mode':'XXX'},{'title':'웨이브 찜 목록','mode':'BOOKMARK_GROUP','ott':'wavve','vidtype':'-','icon':'wavve.png'},{'title':'티빙   찜 목록','mode':'BOOKMARK_GROUP','ott':'tving','vidtype':'-','icon':'tving.png'},{'title':'왓챠   찜 목록','mode':'BOOKMARK_GROUP','ott':'watcha','vidtype':'-','icon':'watcha.png'},{'title':'쿠팡   찜 목록','mode':'BOOKMARK_GROUP','ott':'coupang','vidtype':'-','icon':'coupang.png'},{'title':'넷플   찜 목록 (search mini 에서 등록)','mode':'BOOKMARK_GROUP','ott':'netflix','vidtype':'-','icon':'netflix.png'},{'title':'프라임비디오 찜 목록 (테스트용)','mode':'BOOKMARK_GROUP','ott':'amazon','vidtype':'-','icon':'primev.png'},{'title':'디즈니플러스 찜 목록','mode':'BOOKMARK_GROUP','ott':'disney','vidtype':'-','icon':'disney.jpg'},]
from bookmarkCore import*
class sozlvHYqVGbpOgwdIjLNRmrEiyakSQ(sozlvHYqVGbpOgwdIjLNRmrEiyaknc):
 def __init__(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,sozlvHYqVGbpOgwdIjLNRmrEiyakSn,sozlvHYqVGbpOgwdIjLNRmrEiyakST,sozlvHYqVGbpOgwdIjLNRmrEiyakSM):
  sozlvHYqVGbpOgwdIjLNRmrEiyakSF._addon_url =sozlvHYqVGbpOgwdIjLNRmrEiyakSn
  sozlvHYqVGbpOgwdIjLNRmrEiyakSF._addon_handle=sozlvHYqVGbpOgwdIjLNRmrEiyakST
  sozlvHYqVGbpOgwdIjLNRmrEiyakSF.main_params =sozlvHYqVGbpOgwdIjLNRmrEiyakSM
  sozlvHYqVGbpOgwdIjLNRmrEiyakSF.LIB_PATH =''
  sozlvHYqVGbpOgwdIjLNRmrEiyakSF.LIST_LIMIT =20
  sozlvHYqVGbpOgwdIjLNRmrEiyakSF.BookmarkObj =gvOfzGxBKHiUFDjaJuCVrWkwQSEIhX() 
 def addon_noti(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,sting):
  try:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSP=xbmcgui.Dialog()
   sozlvHYqVGbpOgwdIjLNRmrEiyakSP.notification(__addonname__,sting)
  except:
   sozlvHYqVGbpOgwdIjLNRmrEiyaknF
 def addon_log(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,string):
  try:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSX=string.encode('utf-8','ignore')
  except:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSX='addonException: addon_log'
  sozlvHYqVGbpOgwdIjLNRmrEiyakSB=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,sozlvHYqVGbpOgwdIjLNRmrEiyakSX),level=sozlvHYqVGbpOgwdIjLNRmrEiyakSB)
 def get_settings_select_ott(sozlvHYqVGbpOgwdIjLNRmrEiyakSF):
  sozlvHYqVGbpOgwdIjLNRmrEiyakSA =sozlvHYqVGbpOgwdIjLNRmrEiyaknT if __addon__.getSetting('view_wavve')=='true' else sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  sozlvHYqVGbpOgwdIjLNRmrEiyakSW =sozlvHYqVGbpOgwdIjLNRmrEiyaknT if __addon__.getSetting('view_tving')=='true' else sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  sozlvHYqVGbpOgwdIjLNRmrEiyakSC =sozlvHYqVGbpOgwdIjLNRmrEiyaknT if __addon__.getSetting('view_watcha')=='true' else sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  sozlvHYqVGbpOgwdIjLNRmrEiyakSU=sozlvHYqVGbpOgwdIjLNRmrEiyaknT if __addon__.getSetting('view_coupang')=='true' else sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  sozlvHYqVGbpOgwdIjLNRmrEiyakSt=sozlvHYqVGbpOgwdIjLNRmrEiyaknT if __addon__.getSetting('view_netflix')=='true' else sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  sozlvHYqVGbpOgwdIjLNRmrEiyakSf =sozlvHYqVGbpOgwdIjLNRmrEiyaknT if __addon__.getSetting('view_primev')=='true' else sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  sozlvHYqVGbpOgwdIjLNRmrEiyakSJ =sozlvHYqVGbpOgwdIjLNRmrEiyaknT if __addon__.getSetting('view_disney')=='true' else sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  return(sozlvHYqVGbpOgwdIjLNRmrEiyakSA,sozlvHYqVGbpOgwdIjLNRmrEiyakSW,sozlvHYqVGbpOgwdIjLNRmrEiyakSC,sozlvHYqVGbpOgwdIjLNRmrEiyakSU,sozlvHYqVGbpOgwdIjLNRmrEiyakSt,sozlvHYqVGbpOgwdIjLNRmrEiyakSf,sozlvHYqVGbpOgwdIjLNRmrEiyakSJ)
 def make_Index_Filename(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,tempyn=sozlvHYqVGbpOgwdIjLNRmrEiyaknM):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_index_file.json'))
  else:
   return sozlvHYqVGbpOgwdIjLNRmrEiyakSF.LIB_PATH+'bookmark_index.json'
 def make_Vinfo_Filename(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,sozlvHYqVGbpOgwdIjLNRmrEiyakcS,sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,tempyn=sozlvHYqVGbpOgwdIjLNRmrEiyaknM):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_vinfo_file.json'))
  else:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSD='%s_%s.json'%(sozlvHYqVGbpOgwdIjLNRmrEiyakcS,sozlvHYqVGbpOgwdIjLNRmrEiyakcQ)
   return sozlvHYqVGbpOgwdIjLNRmrEiyakSF.LIB_PATH+sozlvHYqVGbpOgwdIjLNRmrEiyakSD
 def add_dir(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,label,sublabel='',ott='',img='',infoLabels=sozlvHYqVGbpOgwdIjLNRmrEiyaknF,isFolder=sozlvHYqVGbpOgwdIjLNRmrEiyaknT,params='',isLink=sozlvHYqVGbpOgwdIjLNRmrEiyaknM,ContextMenu=sozlvHYqVGbpOgwdIjLNRmrEiyaknF,direct_url=sozlvHYqVGbpOgwdIjLNRmrEiyaknF):
  if direct_url:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSu=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   sozlvHYqVGbpOgwdIjLNRmrEiyakSe=json.dumps(params,separators=(',',':'))
   sozlvHYqVGbpOgwdIjLNRmrEiyakSe=base64.standard_b64encode(sozlvHYqVGbpOgwdIjLNRmrEiyakSe.encode()).decode('utf-8')
   sozlvHYqVGbpOgwdIjLNRmrEiyakSe=sozlvHYqVGbpOgwdIjLNRmrEiyakSe.replace('+','%2B')
   sozlvHYqVGbpOgwdIjLNRmrEiyakSu='%s?params=%s'%(sozlvHYqVGbpOgwdIjLNRmrEiyakSF._addon_url,sozlvHYqVGbpOgwdIjLNRmrEiyakSe)
  if sublabel and sublabel!='-':sozlvHYqVGbpOgwdIjLNRmrEiyakSx='%s < %s >'%(label,sublabel)
  else: sozlvHYqVGbpOgwdIjLNRmrEiyakSx=label
  if not img:img='DefaultFolder.png'
  if ott:sozlvHYqVGbpOgwdIjLNRmrEiyakSx='%s - [%s]'%(sozlvHYqVGbpOgwdIjLNRmrEiyakSx,ott)
  sozlvHYqVGbpOgwdIjLNRmrEiyakQS=xbmcgui.ListItem(sozlvHYqVGbpOgwdIjLNRmrEiyakSx)
  if sozlvHYqVGbpOgwdIjLNRmrEiyaknh(img)==sozlvHYqVGbpOgwdIjLNRmrEiyaknP:
   sozlvHYqVGbpOgwdIjLNRmrEiyakQS.setArt(img)
  else:
   sozlvHYqVGbpOgwdIjLNRmrEiyakQS.setArt({'thumb':img,'poster':img})
  sozlvHYqVGbpOgwdIjLNRmrEiyakQc=[]
  if infoLabels!=sozlvHYqVGbpOgwdIjLNRmrEiyaknF:
   if sozlvHYqVGbpOgwdIjLNRmrEiyaknh(infoLabels.get('cast'))==sozlvHYqVGbpOgwdIjLNRmrEiyaknX:
    if sozlvHYqVGbpOgwdIjLNRmrEiyaknB(infoLabels.get('cast'))>0 and sozlvHYqVGbpOgwdIjLNRmrEiyaknh(infoLabels.get('cast')[0])==sozlvHYqVGbpOgwdIjLNRmrEiyaknP:
     sozlvHYqVGbpOgwdIjLNRmrEiyakQc=infoLabels.get('cast')
     infoLabels['cast']=[]
  if infoLabels:sozlvHYqVGbpOgwdIjLNRmrEiyakQS.setInfo('Video',infoLabels)
  if sozlvHYqVGbpOgwdIjLNRmrEiyaknB(sozlvHYqVGbpOgwdIjLNRmrEiyakQc)>0:sozlvHYqVGbpOgwdIjLNRmrEiyakQS.setCast(sozlvHYqVGbpOgwdIjLNRmrEiyakQc)
  if not isFolder and not isLink:
   sozlvHYqVGbpOgwdIjLNRmrEiyakQS.setProperty('IsPlayable','true')
  if ContextMenu:sozlvHYqVGbpOgwdIjLNRmrEiyakQS.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(sozlvHYqVGbpOgwdIjLNRmrEiyakSF._addon_handle,sozlvHYqVGbpOgwdIjLNRmrEiyakSu,sozlvHYqVGbpOgwdIjLNRmrEiyakQS,isFolder)
 def dp_Main_List(sozlvHYqVGbpOgwdIjLNRmrEiyakSF):
  (sozlvHYqVGbpOgwdIjLNRmrEiyakSA,sozlvHYqVGbpOgwdIjLNRmrEiyakSW,sozlvHYqVGbpOgwdIjLNRmrEiyakSC,sozlvHYqVGbpOgwdIjLNRmrEiyakSU,sozlvHYqVGbpOgwdIjLNRmrEiyakSt,sozlvHYqVGbpOgwdIjLNRmrEiyakSf,sozlvHYqVGbpOgwdIjLNRmrEiyakSJ)=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.get_settings_select_ott()
  for sozlvHYqVGbpOgwdIjLNRmrEiyakQn in sozlvHYqVGbpOgwdIjLNRmrEiyakSc:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSx=sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('title')
   sozlvHYqVGbpOgwdIjLNRmrEiyakQT=''
   if sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('ott')=='wavve' and sozlvHYqVGbpOgwdIjLNRmrEiyakSA ==sozlvHYqVGbpOgwdIjLNRmrEiyaknM:continue
   elif sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('ott')=='tving' and sozlvHYqVGbpOgwdIjLNRmrEiyakSW ==sozlvHYqVGbpOgwdIjLNRmrEiyaknM:continue
   elif sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('ott')=='watcha' and sozlvHYqVGbpOgwdIjLNRmrEiyakSC ==sozlvHYqVGbpOgwdIjLNRmrEiyaknM:continue
   elif sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('ott')=='coupang' and sozlvHYqVGbpOgwdIjLNRmrEiyakSU==sozlvHYqVGbpOgwdIjLNRmrEiyaknM:continue
   elif sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('ott')=='netflix' and sozlvHYqVGbpOgwdIjLNRmrEiyakSt==sozlvHYqVGbpOgwdIjLNRmrEiyaknM:continue
   elif sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('ott')=='amazon' and sozlvHYqVGbpOgwdIjLNRmrEiyakSf ==sozlvHYqVGbpOgwdIjLNRmrEiyaknM:continue
   elif sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('ott')=='disney' and sozlvHYqVGbpOgwdIjLNRmrEiyakSJ ==sozlvHYqVGbpOgwdIjLNRmrEiyaknM:continue
   sozlvHYqVGbpOgwdIjLNRmrEiyakSK={'mode':sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('mode'),'ott':sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('ott'),'vidtype':sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('vidtype'),'page':'1',}
   if sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('mode')=='XXX':
    sozlvHYqVGbpOgwdIjLNRmrEiyakSK['mode']='XXX'
    sozlvHYqVGbpOgwdIjLNRmrEiyakQM=sozlvHYqVGbpOgwdIjLNRmrEiyaknM
    sozlvHYqVGbpOgwdIjLNRmrEiyakQh =sozlvHYqVGbpOgwdIjLNRmrEiyaknT
   else:
    if 'icon' in sozlvHYqVGbpOgwdIjLNRmrEiyakQn:
     sozlvHYqVGbpOgwdIjLNRmrEiyakQT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',sozlvHYqVGbpOgwdIjLNRmrEiyakQn.get('icon')) 
    sozlvHYqVGbpOgwdIjLNRmrEiyakQM=sozlvHYqVGbpOgwdIjLNRmrEiyaknT
    sozlvHYqVGbpOgwdIjLNRmrEiyakQh =sozlvHYqVGbpOgwdIjLNRmrEiyaknM
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.add_dir(sozlvHYqVGbpOgwdIjLNRmrEiyakSx,sublabel='',ott='',img=sozlvHYqVGbpOgwdIjLNRmrEiyakQT,infoLabels=sozlvHYqVGbpOgwdIjLNRmrEiyaknF,isFolder=sozlvHYqVGbpOgwdIjLNRmrEiyakQM,params=sozlvHYqVGbpOgwdIjLNRmrEiyakSK,isLink=sozlvHYqVGbpOgwdIjLNRmrEiyakQh)
  xbmcplugin.endOfDirectory(sozlvHYqVGbpOgwdIjLNRmrEiyakSF._addon_handle)
 def dp_Genre_Grouplist(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,args):
  sozlvHYqVGbpOgwdIjLNRmrEiyakQX=[]
  sozlvHYqVGbpOgwdIjLNRmrEiyakQB=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.make_Index_Filename(tempyn=sozlvHYqVGbpOgwdIjLNRmrEiyaknM)
  if xbmcvfs.exists(sozlvHYqVGbpOgwdIjLNRmrEiyakQB):
   sozlvHYqVGbpOgwdIjLNRmrEiyakQA=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.jsonfile_To_dic(sozlvHYqVGbpOgwdIjLNRmrEiyakQB)
  else:
   sozlvHYqVGbpOgwdIjLNRmrEiyakQA=[]
  for sozlvHYqVGbpOgwdIjLNRmrEiyakQW in sozlvHYqVGbpOgwdIjLNRmrEiyakQA:
   sozlvHYqVGbpOgwdIjLNRmrEiyakQC =sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('genre')
   if sozlvHYqVGbpOgwdIjLNRmrEiyakQC not in sozlvHYqVGbpOgwdIjLNRmrEiyakQX:
    sozlvHYqVGbpOgwdIjLNRmrEiyakQX.append(sozlvHYqVGbpOgwdIjLNRmrEiyakQC)
  for sozlvHYqVGbpOgwdIjLNRmrEiyakQC in sozlvHYqVGbpOgwdIjLNRmrEiyakQX:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSK={'mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','genre':sozlvHYqVGbpOgwdIjLNRmrEiyakQC,'page':'1',}
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.add_dir(sozlvHYqVGbpOgwdIjLNRmrEiyakQC,sublabel='',ott='',img='',infoLabels=sozlvHYqVGbpOgwdIjLNRmrEiyaknF,isFolder=sozlvHYqVGbpOgwdIjLNRmrEiyaknT,params=sozlvHYqVGbpOgwdIjLNRmrEiyakSK)
  xbmcplugin.endOfDirectory(sozlvHYqVGbpOgwdIjLNRmrEiyakSF._addon_handle)
 def dp_Bookmark_Grouplist(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,args):
  sozlvHYqVGbpOgwdIjLNRmrEiyakQU =sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  sozlvHYqVGbpOgwdIjLNRmrEiyakQt =[]
  sozlvHYqVGbpOgwdIjLNRmrEiyakQf =args.get('ott')
  sozlvHYqVGbpOgwdIjLNRmrEiyakQJ=args.get('vidtype')
  sozlvHYqVGbpOgwdIjLNRmrEiyakQD =args.get('genre')
  if sozlvHYqVGbpOgwdIjLNRmrEiyakQD==sozlvHYqVGbpOgwdIjLNRmrEiyaknF:sozlvHYqVGbpOgwdIjLNRmrEiyakQD='all'
  sozlvHYqVGbpOgwdIjLNRmrEiyakQu =sozlvHYqVGbpOgwdIjLNRmrEiyaknA(args.get('page'))
  sozlvHYqVGbpOgwdIjLNRmrEiyakQK =sozlvHYqVGbpOgwdIjLNRmrEiyakSF.LIST_LIMIT*(sozlvHYqVGbpOgwdIjLNRmrEiyakQu-1)+1 
  sozlvHYqVGbpOgwdIjLNRmrEiyakQe =sozlvHYqVGbpOgwdIjLNRmrEiyakSF.LIST_LIMIT*sozlvHYqVGbpOgwdIjLNRmrEiyakQu
  sozlvHYqVGbpOgwdIjLNRmrEiyakQB=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.make_Index_Filename(tempyn=sozlvHYqVGbpOgwdIjLNRmrEiyaknM)
  if xbmcvfs.exists(sozlvHYqVGbpOgwdIjLNRmrEiyakQB):
   sozlvHYqVGbpOgwdIjLNRmrEiyakQA=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.jsonfile_To_dic(sozlvHYqVGbpOgwdIjLNRmrEiyakQB)
  else:
   sozlvHYqVGbpOgwdIjLNRmrEiyakQA=[]
  sozlvHYqVGbpOgwdIjLNRmrEiyakQx=0
  for sozlvHYqVGbpOgwdIjLNRmrEiyakQW in sozlvHYqVGbpOgwdIjLNRmrEiyakQA:
   sozlvHYqVGbpOgwdIjLNRmrEiyakcS =sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('ott')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcQ =sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('videoid')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcF =sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('vidtype')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcn =sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('genre')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcT =sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('linkUrl')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcM =sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('encodedId')
   sozlvHYqVGbpOgwdIjLNRmrEiyakch =sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('contentId')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcP=sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('contentClass')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcX=sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('contentSlugs')
   if not(sozlvHYqVGbpOgwdIjLNRmrEiyakQf=='-' or sozlvHYqVGbpOgwdIjLNRmrEiyakQf==sozlvHYqVGbpOgwdIjLNRmrEiyakcS):continue
   if not(sozlvHYqVGbpOgwdIjLNRmrEiyakQJ=='-' or sozlvHYqVGbpOgwdIjLNRmrEiyakQJ==sozlvHYqVGbpOgwdIjLNRmrEiyakcF):continue
   if not(sozlvHYqVGbpOgwdIjLNRmrEiyakQD=='all' or sozlvHYqVGbpOgwdIjLNRmrEiyakQD==sozlvHYqVGbpOgwdIjLNRmrEiyakcn):continue
   sozlvHYqVGbpOgwdIjLNRmrEiyakQx+=1
   if sozlvHYqVGbpOgwdIjLNRmrEiyakQK>sozlvHYqVGbpOgwdIjLNRmrEiyakQx:continue
   if sozlvHYqVGbpOgwdIjLNRmrEiyakQe<sozlvHYqVGbpOgwdIjLNRmrEiyakQx:
    sozlvHYqVGbpOgwdIjLNRmrEiyakQU=sozlvHYqVGbpOgwdIjLNRmrEiyaknT
    break
   sozlvHYqVGbpOgwdIjLNRmrEiyakcB=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.make_Vinfo_Filename(sozlvHYqVGbpOgwdIjLNRmrEiyakcS,sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,tempyn=sozlvHYqVGbpOgwdIjLNRmrEiyaknM)
   if xbmcvfs.exists(sozlvHYqVGbpOgwdIjLNRmrEiyakcB):
    sozlvHYqVGbpOgwdIjLNRmrEiyakcA=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.jsonfile_To_dic(sozlvHYqVGbpOgwdIjLNRmrEiyakcB)
    sozlvHYqVGbpOgwdIjLNRmrEiyakSx =sozlvHYqVGbpOgwdIjLNRmrEiyakcA.get('title')
    sozlvHYqVGbpOgwdIjLNRmrEiyakcW =sozlvHYqVGbpOgwdIjLNRmrEiyakcA.get('subtitle')
    sozlvHYqVGbpOgwdIjLNRmrEiyakcC =sozlvHYqVGbpOgwdIjLNRmrEiyakcA.get('thumbnail')
    sozlvHYqVGbpOgwdIjLNRmrEiyakQF=sozlvHYqVGbpOgwdIjLNRmrEiyakcA.get('infoLabels')
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakSx =sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('title')
    sozlvHYqVGbpOgwdIjLNRmrEiyakcW =''
    sozlvHYqVGbpOgwdIjLNRmrEiyakcC =''
    sozlvHYqVGbpOgwdIjLNRmrEiyakQF={'mpaa':'0'}
    sozlvHYqVGbpOgwdIjLNRmrEiyakcA ={'infoLabels':{'title':sozlvHYqVGbpOgwdIjLNRmrEiyakSx}}
   sozlvHYqVGbpOgwdIjLNRmrEiyakSK={'ott':sozlvHYqVGbpOgwdIjLNRmrEiyakcS,'videoid':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'vidtype':sozlvHYqVGbpOgwdIjLNRmrEiyakcF,'title':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'thumbnail':sozlvHYqVGbpOgwdIjLNRmrEiyakcC,'mpaa':sozlvHYqVGbpOgwdIjLNRmrEiyaknW(sozlvHYqVGbpOgwdIjLNRmrEiyakQF.get('mpaa')),'duration':sozlvHYqVGbpOgwdIjLNRmrEiyaknW(sozlvHYqVGbpOgwdIjLNRmrEiyakQF.get('duration')),'linkUrl':sozlvHYqVGbpOgwdIjLNRmrEiyakcT,'infoLabels':sozlvHYqVGbpOgwdIjLNRmrEiyakQF,'encodedId':sozlvHYqVGbpOgwdIjLNRmrEiyakcM,'contentId':sozlvHYqVGbpOgwdIjLNRmrEiyakch,'contentClass':sozlvHYqVGbpOgwdIjLNRmrEiyakcP,'contentSlugs':sozlvHYqVGbpOgwdIjLNRmrEiyakcX,}
   sozlvHYqVGbpOgwdIjLNRmrEiyakcU={'mode':'BOOKMARK_REMOVE','list':[sozlvHYqVGbpOgwdIjLNRmrEiyakQW],}
   sozlvHYqVGbpOgwdIjLNRmrEiyakct=urllib.parse.urlencode(sozlvHYqVGbpOgwdIjLNRmrEiyakcU)
   sozlvHYqVGbpOgwdIjLNRmrEiyakcf=[('찜 목록 ( %s ) 삭제'%(sozlvHYqVGbpOgwdIjLNRmrEiyakcA.get('infoLabels').get('title')),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(sozlvHYqVGbpOgwdIjLNRmrEiyakct))]
   if sozlvHYqVGbpOgwdIjLNRmrEiyakQD!='all':
    sozlvHYqVGbpOgwdIjLNRmrEiyakcU={'mode':'GENRE_RENAME','list':[sozlvHYqVGbpOgwdIjLNRmrEiyakQW],}
    sozlvHYqVGbpOgwdIjLNRmrEiyakct=urllib.parse.urlencode(sozlvHYqVGbpOgwdIjLNRmrEiyakcU)
    sozlvHYqVGbpOgwdIjLNRmrEiyakcf.append(('장르명 ( %s ) 수정'%(sozlvHYqVGbpOgwdIjLNRmrEiyakQD),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(sozlvHYqVGbpOgwdIjLNRmrEiyakct)))
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.make_Hyper_Link(sozlvHYqVGbpOgwdIjLNRmrEiyakSK)
   if sozlvHYqVGbpOgwdIjLNRmrEiyakcF=='tvshow':
    sozlvHYqVGbpOgwdIjLNRmrEiyakQM=sozlvHYqVGbpOgwdIjLNRmrEiyaknT
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakQM=sozlvHYqVGbpOgwdIjLNRmrEiyaknM
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.add_dir(sozlvHYqVGbpOgwdIjLNRmrEiyakSx,sublabel=sozlvHYqVGbpOgwdIjLNRmrEiyakcW,ott=sozlvHYqVGbpOgwdIjLNRmrEiyakcS,img=sozlvHYqVGbpOgwdIjLNRmrEiyakcC,infoLabels=sozlvHYqVGbpOgwdIjLNRmrEiyakQF,isFolder=sozlvHYqVGbpOgwdIjLNRmrEiyakQM,params=sozlvHYqVGbpOgwdIjLNRmrEiyaknF,isLink=sozlvHYqVGbpOgwdIjLNRmrEiyaknM,ContextMenu=sozlvHYqVGbpOgwdIjLNRmrEiyakcf,direct_url=sozlvHYqVGbpOgwdIjLNRmrEiyakcJ)
   sozlvHYqVGbpOgwdIjLNRmrEiyakQt.append(sozlvHYqVGbpOgwdIjLNRmrEiyakQW)
  sozlvHYqVGbpOgwdIjLNRmrEiyakcD={'plot':'현재페이지의 전체목록을 삭제합니다.'}
  sozlvHYqVGbpOgwdIjLNRmrEiyakSx='* 현재페이지 목록 삭제 (개별삭제는 팝업메뉴) *'
  sozlvHYqVGbpOgwdIjLNRmrEiyakSK={'mode':'BOOKMARK_REMOVE','list':sozlvHYqVGbpOgwdIjLNRmrEiyakQt,}
  sozlvHYqVGbpOgwdIjLNRmrEiyakQT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  sozlvHYqVGbpOgwdIjLNRmrEiyakSF.add_dir(sozlvHYqVGbpOgwdIjLNRmrEiyakSx,sublabel='',ott='',img=sozlvHYqVGbpOgwdIjLNRmrEiyakQT,infoLabels=sozlvHYqVGbpOgwdIjLNRmrEiyakcD,isFolder=sozlvHYqVGbpOgwdIjLNRmrEiyaknM,params=sozlvHYqVGbpOgwdIjLNRmrEiyakSK,isLink=sozlvHYqVGbpOgwdIjLNRmrEiyaknT)
  if sozlvHYqVGbpOgwdIjLNRmrEiyakQU:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSK={'mode':'BOOKMARK_GROUP','ott':sozlvHYqVGbpOgwdIjLNRmrEiyakQf,'vidtype':sozlvHYqVGbpOgwdIjLNRmrEiyakQJ,'page':sozlvHYqVGbpOgwdIjLNRmrEiyaknW(sozlvHYqVGbpOgwdIjLNRmrEiyakQu+1)}
   sozlvHYqVGbpOgwdIjLNRmrEiyakSx='[B]%s >>[/B]'%'다음 페이지'
   sozlvHYqVGbpOgwdIjLNRmrEiyakcW=sozlvHYqVGbpOgwdIjLNRmrEiyaknW(sozlvHYqVGbpOgwdIjLNRmrEiyakQu+1)
   sozlvHYqVGbpOgwdIjLNRmrEiyakQT=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.add_dir(sozlvHYqVGbpOgwdIjLNRmrEiyakSx,sublabel=sozlvHYqVGbpOgwdIjLNRmrEiyakcW,ott='',img=sozlvHYqVGbpOgwdIjLNRmrEiyakQT,infoLabels=sozlvHYqVGbpOgwdIjLNRmrEiyaknF,isFolder=sozlvHYqVGbpOgwdIjLNRmrEiyaknT,params=sozlvHYqVGbpOgwdIjLNRmrEiyakSK)
  xbmcplugin.setContent(sozlvHYqVGbpOgwdIjLNRmrEiyakSF._addon_handle,'movies')
  xbmcplugin.endOfDirectory(sozlvHYqVGbpOgwdIjLNRmrEiyakSF._addon_handle)
 def get_keyboard_input(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,defalut,sozlvHYqVGbpOgwdIjLNRmrEiyakSx):
  sozlvHYqVGbpOgwdIjLNRmrEiyakcu=sozlvHYqVGbpOgwdIjLNRmrEiyaknF
  kb=xbmc.Keyboard(defalut,sozlvHYqVGbpOgwdIjLNRmrEiyakSx,sozlvHYqVGbpOgwdIjLNRmrEiyaknM)
  kb.setHeading(sozlvHYqVGbpOgwdIjLNRmrEiyakSx)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   sozlvHYqVGbpOgwdIjLNRmrEiyakcu=kb.getText()
  return sozlvHYqVGbpOgwdIjLNRmrEiyakcu
 def dp_Genre_Rename(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,args):
  sozlvHYqVGbpOgwdIjLNRmrEiyakcK =sozlvHYqVGbpOgwdIjLNRmrEiyaknT
  sozlvHYqVGbpOgwdIjLNRmrEiyakce ={}
  try:
   sozlvHYqVGbpOgwdIjLNRmrEiyakcx=args.get('list')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcx=sozlvHYqVGbpOgwdIjLNRmrEiyakcx.replace('\'','\"')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcx=json.loads(sozlvHYqVGbpOgwdIjLNRmrEiyakcx)
  except:
   sozlvHYqVGbpOgwdIjLNRmrEiyakcK=sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   if sozlvHYqVGbpOgwdIjLNRmrEiyaknB(sozlvHYqVGbpOgwdIjLNRmrEiyakcx)!=0:
    sozlvHYqVGbpOgwdIjLNRmrEiyakFS=sozlvHYqVGbpOgwdIjLNRmrEiyakcx[0].get('genre')
   else:
    return
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakFQ=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.get_keyboard_input(sozlvHYqVGbpOgwdIjLNRmrEiyakFS,__language__(30909).encode('utf-8'))
   if sozlvHYqVGbpOgwdIjLNRmrEiyakFQ!=sozlvHYqVGbpOgwdIjLNRmrEiyaknF:
    sozlvHYqVGbpOgwdIjLNRmrEiyakFQ=sozlvHYqVGbpOgwdIjLNRmrEiyakFQ.strip()
   else:
    return
   if sozlvHYqVGbpOgwdIjLNRmrEiyakFS==sozlvHYqVGbpOgwdIjLNRmrEiyakFQ:
    sozlvHYqVGbpOgwdIjLNRmrEiyakSF.addon_noti(__language__(30910).encode('utf-8'))
    return
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   for sozlvHYqVGbpOgwdIjLNRmrEiyakFc in sozlvHYqVGbpOgwdIjLNRmrEiyakcx:
    if sozlvHYqVGbpOgwdIjLNRmrEiyakFc['ott']in sozlvHYqVGbpOgwdIjLNRmrEiyakce:
     sozlvHYqVGbpOgwdIjLNRmrEiyakce[sozlvHYqVGbpOgwdIjLNRmrEiyakFc['ott']].append(sozlvHYqVGbpOgwdIjLNRmrEiyakFc['videoid'])
    else:
     sozlvHYqVGbpOgwdIjLNRmrEiyakce[sozlvHYqVGbpOgwdIjLNRmrEiyakFc['ott']]=[sozlvHYqVGbpOgwdIjLNRmrEiyakFc['videoid']]
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakQB=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.make_Index_Filename(tempyn=sozlvHYqVGbpOgwdIjLNRmrEiyaknM)
   if xbmcvfs.exists(sozlvHYqVGbpOgwdIjLNRmrEiyakQB):
    sozlvHYqVGbpOgwdIjLNRmrEiyakQA=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.jsonfile_To_dic(sozlvHYqVGbpOgwdIjLNRmrEiyakQB)
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   for i in sozlvHYqVGbpOgwdIjLNRmrEiyaknC(sozlvHYqVGbpOgwdIjLNRmrEiyaknB(sozlvHYqVGbpOgwdIjLNRmrEiyakQA)):
    sozlvHYqVGbpOgwdIjLNRmrEiyakFn =sozlvHYqVGbpOgwdIjLNRmrEiyakQA[i].get('ott')
    sozlvHYqVGbpOgwdIjLNRmrEiyakFT=sozlvHYqVGbpOgwdIjLNRmrEiyakQA[i].get('videoid')
    if sozlvHYqVGbpOgwdIjLNRmrEiyakFn in sozlvHYqVGbpOgwdIjLNRmrEiyakce:
     if sozlvHYqVGbpOgwdIjLNRmrEiyakFT in sozlvHYqVGbpOgwdIjLNRmrEiyakce[sozlvHYqVGbpOgwdIjLNRmrEiyakFn]:
      sozlvHYqVGbpOgwdIjLNRmrEiyakQA[i]['genre']=sozlvHYqVGbpOgwdIjLNRmrEiyakFQ
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakcK=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.dic_To_jsonfile(sozlvHYqVGbpOgwdIjLNRmrEiyakQB,sozlvHYqVGbpOgwdIjLNRmrEiyakQA)
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.addon_noti(__language__(30911).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.addon_noti(__language__(30912).encode('utf-8'))
 def dp_Bookmark_Remove(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,args):
  sozlvHYqVGbpOgwdIjLNRmrEiyakcK =sozlvHYqVGbpOgwdIjLNRmrEiyaknT
  sozlvHYqVGbpOgwdIjLNRmrEiyakFM ={}
  sozlvHYqVGbpOgwdIjLNRmrEiyakSP=xbmcgui.Dialog()
  sozlvHYqVGbpOgwdIjLNRmrEiyakFh=sozlvHYqVGbpOgwdIjLNRmrEiyakSP.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if sozlvHYqVGbpOgwdIjLNRmrEiyakFh==sozlvHYqVGbpOgwdIjLNRmrEiyaknM:sys.exit()
  try:
   sozlvHYqVGbpOgwdIjLNRmrEiyakcx=args.get('list')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcx=sozlvHYqVGbpOgwdIjLNRmrEiyakcx.replace('\'','\"')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcx=json.loads(sozlvHYqVGbpOgwdIjLNRmrEiyakcx)
  except:
   sozlvHYqVGbpOgwdIjLNRmrEiyakcK=sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   for sozlvHYqVGbpOgwdIjLNRmrEiyakFc in sozlvHYqVGbpOgwdIjLNRmrEiyakcx:
    if sozlvHYqVGbpOgwdIjLNRmrEiyakFc['ott']in sozlvHYqVGbpOgwdIjLNRmrEiyakFM:
     sozlvHYqVGbpOgwdIjLNRmrEiyakFM[sozlvHYqVGbpOgwdIjLNRmrEiyakFc['ott']].append(sozlvHYqVGbpOgwdIjLNRmrEiyakFc['videoid'])
    else:
     sozlvHYqVGbpOgwdIjLNRmrEiyakFM[sozlvHYqVGbpOgwdIjLNRmrEiyakFc['ott']]=[sozlvHYqVGbpOgwdIjLNRmrEiyakFc['videoid']]
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakQB=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.make_Index_Filename(tempyn=sozlvHYqVGbpOgwdIjLNRmrEiyaknM)
   if xbmcvfs.exists(sozlvHYqVGbpOgwdIjLNRmrEiyakQB):
    sozlvHYqVGbpOgwdIjLNRmrEiyakQA=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.jsonfile_To_dic(sozlvHYqVGbpOgwdIjLNRmrEiyakQB)
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakQW=[]
   for sozlvHYqVGbpOgwdIjLNRmrEiyakFP in sozlvHYqVGbpOgwdIjLNRmrEiyakQA:
    sozlvHYqVGbpOgwdIjLNRmrEiyakFn =sozlvHYqVGbpOgwdIjLNRmrEiyakFP.get('ott')
    sozlvHYqVGbpOgwdIjLNRmrEiyakFT=sozlvHYqVGbpOgwdIjLNRmrEiyakFP.get('videoid')
    if sozlvHYqVGbpOgwdIjLNRmrEiyakFn in sozlvHYqVGbpOgwdIjLNRmrEiyakFM:
     if sozlvHYqVGbpOgwdIjLNRmrEiyakFT in sozlvHYqVGbpOgwdIjLNRmrEiyakFM[sozlvHYqVGbpOgwdIjLNRmrEiyakFn]:
      sozlvHYqVGbpOgwdIjLNRmrEiyakcB=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.make_Vinfo_Filename(sozlvHYqVGbpOgwdIjLNRmrEiyakFn,sozlvHYqVGbpOgwdIjLNRmrEiyakFT,tempyn=sozlvHYqVGbpOgwdIjLNRmrEiyaknM)
      xbmcvfs.delete(sozlvHYqVGbpOgwdIjLNRmrEiyakcB)
      continue
    sozlvHYqVGbpOgwdIjLNRmrEiyakQW.append(sozlvHYqVGbpOgwdIjLNRmrEiyakFP)
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyaknF
   sozlvHYqVGbpOgwdIjLNRmrEiyakcK=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.dic_To_jsonfile(sozlvHYqVGbpOgwdIjLNRmrEiyakQB,sozlvHYqVGbpOgwdIjLNRmrEiyakQW)
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.addon_noti(__language__(30908).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.addon_noti(__language__(30907).encode('utf-8'))
 def make_Hyper_Link(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,args):
  sozlvHYqVGbpOgwdIjLNRmrEiyakcJ=''
  sozlvHYqVGbpOgwdIjLNRmrEiyakcS =args.get('ott')
  sozlvHYqVGbpOgwdIjLNRmrEiyakcQ =args.get('videoid')
  sozlvHYqVGbpOgwdIjLNRmrEiyakcF =args.get('vidtype')
  sozlvHYqVGbpOgwdIjLNRmrEiyakSx =args.get('title')
  sozlvHYqVGbpOgwdIjLNRmrEiyakcC =args.get('thumbnail')
  sozlvHYqVGbpOgwdIjLNRmrEiyakFX =args.get('mpaa')
  sozlvHYqVGbpOgwdIjLNRmrEiyakcT =args.get('linkUrl')
  sozlvHYqVGbpOgwdIjLNRmrEiyakFB =args.get('duration')
  sozlvHYqVGbpOgwdIjLNRmrEiyakQF =args.get('infoLabels')
  sozlvHYqVGbpOgwdIjLNRmrEiyakcM =args.get('encodedId')
  sozlvHYqVGbpOgwdIjLNRmrEiyakch =args.get('contentId')
  sozlvHYqVGbpOgwdIjLNRmrEiyakcP=args.get('contentClass')
  sozlvHYqVGbpOgwdIjLNRmrEiyakcX=args.get('contentSlugs')
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcS=='wavve':
   if sozlvHYqVGbpOgwdIjLNRmrEiyakcF=='tvshow':
    sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'SEASON_LIST','videoid':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'vidtype':sozlvHYqVGbpOgwdIjLNRmrEiyakcF,}
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'MOVIE','contentid':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'title':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'thumbnail':sozlvHYqVGbpOgwdIjLNRmrEiyakcC,'age':sozlvHYqVGbpOgwdIjLNRmrEiyakFX,}
   sozlvHYqVGbpOgwdIjLNRmrEiyakFW=urllib.parse.urlencode(sozlvHYqVGbpOgwdIjLNRmrEiyakFA)
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ='plugin://plugin.video.wavvem/?'
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ+=sozlvHYqVGbpOgwdIjLNRmrEiyakFW
  elif sozlvHYqVGbpOgwdIjLNRmrEiyakcS=='tving':
   if sozlvHYqVGbpOgwdIjLNRmrEiyakcF=='tvshow':
    sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'EPISODE','programcode':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'page':'1',}
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'MOVIE','stype':'movie','mediacode':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'title':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'thumbnail':sozlvHYqVGbpOgwdIjLNRmrEiyakcC,}
   sozlvHYqVGbpOgwdIjLNRmrEiyakFW=urllib.parse.urlencode(sozlvHYqVGbpOgwdIjLNRmrEiyakFA)
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ='plugin://plugin.video.tvingm/?'
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ+=sozlvHYqVGbpOgwdIjLNRmrEiyakFW
  elif sozlvHYqVGbpOgwdIjLNRmrEiyakcS=='watcha':
   if sozlvHYqVGbpOgwdIjLNRmrEiyakcF=='tvshow':
    sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'EPISODE','movie_code':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'season_code':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'page':'1',}
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'MOVIE','movie_code':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'season_code':'-','title':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'thumbnail':sozlvHYqVGbpOgwdIjLNRmrEiyakcC,}
   sozlvHYqVGbpOgwdIjLNRmrEiyakFW=urllib.parse.urlencode(sozlvHYqVGbpOgwdIjLNRmrEiyakFA)
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ='plugin://plugin.video.watcham/?'
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ+=sozlvHYqVGbpOgwdIjLNRmrEiyakFW
  elif sozlvHYqVGbpOgwdIjLNRmrEiyakcS=='coupang':
   if sozlvHYqVGbpOgwdIjLNRmrEiyakcF=='tvshow':
    sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'SEASON_LIST','id':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'asis':'TVSHOW','title':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'thumbnail':sozlvHYqVGbpOgwdIjLNRmrEiyakcC,'page':'1',}
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'MOVIE','id':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'asis':'MOVIE','title':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'thumbnail':sozlvHYqVGbpOgwdIjLNRmrEiyakcC,}
   sozlvHYqVGbpOgwdIjLNRmrEiyakFW=urllib.parse.urlencode(sozlvHYqVGbpOgwdIjLNRmrEiyakFA)
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ='plugin://plugin.video.coupangm/?'
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ+=sozlvHYqVGbpOgwdIjLNRmrEiyakFW
  elif sozlvHYqVGbpOgwdIjLNRmrEiyakcS=='netflix':
   if sozlvHYqVGbpOgwdIjLNRmrEiyakcF=='tvshow':
    sozlvHYqVGbpOgwdIjLNRmrEiyakcJ='plugin://plugin.video.netflix/directory/show/%s/'%(sozlvHYqVGbpOgwdIjLNRmrEiyakcQ)
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakcJ='plugin://plugin.video.netflix/play/movie/%s/'%(sozlvHYqVGbpOgwdIjLNRmrEiyakcQ)
  elif sozlvHYqVGbpOgwdIjLNRmrEiyakcS=='amazon':
   if sozlvHYqVGbpOgwdIjLNRmrEiyakcF=='tvshow':
    sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'SEASON_LIST','values':{'titleID':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'linkUrl':sozlvHYqVGbpOgwdIjLNRmrEiyakcT,'duration':sozlvHYqVGbpOgwdIjLNRmrEiyakFB,'vType':sozlvHYqVGbpOgwdIjLNRmrEiyakcF,'image':sozlvHYqVGbpOgwdIjLNRmrEiyakcC,'title':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'infoLabels':sozlvHYqVGbpOgwdIjLNRmrEiyakQF,}}
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'MOVIE','values':{'titleID':sozlvHYqVGbpOgwdIjLNRmrEiyakcQ,'linkUrl':sozlvHYqVGbpOgwdIjLNRmrEiyakcT,'duration':sozlvHYqVGbpOgwdIjLNRmrEiyakFB,'vType':sozlvHYqVGbpOgwdIjLNRmrEiyakcF,'image':sozlvHYqVGbpOgwdIjLNRmrEiyakcC,'title':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'infoLabels':sozlvHYqVGbpOgwdIjLNRmrEiyakQF,}}
   sozlvHYqVGbpOgwdIjLNRmrEiyakFW=json.dumps(sozlvHYqVGbpOgwdIjLNRmrEiyakFA,separators=(',',':'))
   sozlvHYqVGbpOgwdIjLNRmrEiyakFW=base64.standard_b64encode(sozlvHYqVGbpOgwdIjLNRmrEiyakFW.encode()).decode('utf-8')
   sozlvHYqVGbpOgwdIjLNRmrEiyakFW=sozlvHYqVGbpOgwdIjLNRmrEiyakFW.replace('+','%2B')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ='plugin://plugin.video.primevm/?params='
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ+=sozlvHYqVGbpOgwdIjLNRmrEiyakFW
  elif sozlvHYqVGbpOgwdIjLNRmrEiyakcS=='disney':
   if sozlvHYqVGbpOgwdIjLNRmrEiyakcF=='tvshow':
    if sozlvHYqVGbpOgwdIjLNRmrEiyakcM:
     sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'SEASON_LIST','values':{'encodedId':sozlvHYqVGbpOgwdIjLNRmrEiyakcM,'vType':sozlvHYqVGbpOgwdIjLNRmrEiyakcF,'image':sozlvHYqVGbpOgwdIjLNRmrEiyakcC,'title':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'programTitle':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'infoLabels':sozlvHYqVGbpOgwdIjLNRmrEiyakQF,}}
    else:
     sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'PROGRAM_LIST','values':{'contentClass':sozlvHYqVGbpOgwdIjLNRmrEiyakcP,'contentSlugs':sozlvHYqVGbpOgwdIjLNRmrEiyakcX,'vType':sozlvHYqVGbpOgwdIjLNRmrEiyakcF,'image':sozlvHYqVGbpOgwdIjLNRmrEiyakcC,'title':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'programTitle':sozlvHYqVGbpOgwdIjLNRmrEiyakSx,'infoLabels':sozlvHYqVGbpOgwdIjLNRmrEiyakQF,}}
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakFA={'mode':'MOVIE','values':{'contentId':sozlvHYqVGbpOgwdIjLNRmrEiyakch,'vType':sozlvHYqVGbpOgwdIjLNRmrEiyakcF,'image':sozlvHYqVGbpOgwdIjLNRmrEiyakcC,'title':sozlvHYqVGbpOgwdIjLNRmrEiyakQF['title'],'programTitle':sozlvHYqVGbpOgwdIjLNRmrEiyakQF['title'],'infoLabels':sozlvHYqVGbpOgwdIjLNRmrEiyakQF,}}
   sozlvHYqVGbpOgwdIjLNRmrEiyakFW=json.dumps(sozlvHYqVGbpOgwdIjLNRmrEiyakFA,separators=(',',':'))
   sozlvHYqVGbpOgwdIjLNRmrEiyakFW=base64.standard_b64encode(sozlvHYqVGbpOgwdIjLNRmrEiyakFW.encode()).decode('utf-8')
   sozlvHYqVGbpOgwdIjLNRmrEiyakFW=sozlvHYqVGbpOgwdIjLNRmrEiyakFW.replace('+','%2B')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ='plugin://plugin.video.disneym/?params='
   sozlvHYqVGbpOgwdIjLNRmrEiyakcJ+=sozlvHYqVGbpOgwdIjLNRmrEiyakFW
  return sozlvHYqVGbpOgwdIjLNRmrEiyakcJ
 def dp_Set_Bookmark(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,args):
  sozlvHYqVGbpOgwdIjLNRmrEiyakcK =sozlvHYqVGbpOgwdIjLNRmrEiyaknT
  sozlvHYqVGbpOgwdIjLNRmrEiyakQA=[]
  sozlvHYqVGbpOgwdIjLNRmrEiyakFC=args.get('VIDEO_INFO')
  if sozlvHYqVGbpOgwdIjLNRmrEiyakFC:
   sozlvHYqVGbpOgwdIjLNRmrEiyakQW=sozlvHYqVGbpOgwdIjLNRmrEiyakFC.get('indexinfo')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcA =sozlvHYqVGbpOgwdIjLNRmrEiyakFC.get('saveinfo')
  else:
   sozlvHYqVGbpOgwdIjLNRmrEiyakFU =urllib.parse.unquote(args.get('bm_param'))
   sozlvHYqVGbpOgwdIjLNRmrEiyakFU =json.loads(sozlvHYqVGbpOgwdIjLNRmrEiyakFU)
   sozlvHYqVGbpOgwdIjLNRmrEiyakQW=sozlvHYqVGbpOgwdIjLNRmrEiyakFU.get('indexinfo')
   sozlvHYqVGbpOgwdIjLNRmrEiyakcA =sozlvHYqVGbpOgwdIjLNRmrEiyakFU.get('saveinfo')
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakcB=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.make_Vinfo_Filename(sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('ott'),sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('videoid'),tempyn=sozlvHYqVGbpOgwdIjLNRmrEiyaknM)
   sozlvHYqVGbpOgwdIjLNRmrEiyakcK=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.dic_To_jsonfile(sozlvHYqVGbpOgwdIjLNRmrEiyakcB,sozlvHYqVGbpOgwdIjLNRmrEiyakcA)
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakQB=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.make_Index_Filename(tempyn=sozlvHYqVGbpOgwdIjLNRmrEiyaknM)
   if xbmcvfs.exists(sozlvHYqVGbpOgwdIjLNRmrEiyakQB):
    sozlvHYqVGbpOgwdIjLNRmrEiyakQA=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.jsonfile_To_dic(sozlvHYqVGbpOgwdIjLNRmrEiyakQB)
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakQA=[]
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakFt =sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('ott')
   sozlvHYqVGbpOgwdIjLNRmrEiyakFf =sozlvHYqVGbpOgwdIjLNRmrEiyakQW.get('videoid')
   for i in sozlvHYqVGbpOgwdIjLNRmrEiyaknC(sozlvHYqVGbpOgwdIjLNRmrEiyaknB(sozlvHYqVGbpOgwdIjLNRmrEiyakQA)):
    sozlvHYqVGbpOgwdIjLNRmrEiyakFn =sozlvHYqVGbpOgwdIjLNRmrEiyakQA[i].get('ott')
    sozlvHYqVGbpOgwdIjLNRmrEiyakFT=sozlvHYqVGbpOgwdIjLNRmrEiyakQA[i].get('videoid')
    if sozlvHYqVGbpOgwdIjLNRmrEiyakFt==sozlvHYqVGbpOgwdIjLNRmrEiyakFn and sozlvHYqVGbpOgwdIjLNRmrEiyakFf==sozlvHYqVGbpOgwdIjLNRmrEiyakFT:
     sozlvHYqVGbpOgwdIjLNRmrEiyakQA.pop(i)
     break
   sozlvHYqVGbpOgwdIjLNRmrEiyakQW['title']=sozlvHYqVGbpOgwdIjLNRmrEiyakcA.get('title')
   if sozlvHYqVGbpOgwdIjLNRmrEiyaknB(sozlvHYqVGbpOgwdIjLNRmrEiyakcA.get('infoLabels').get('genre'))>0:
    sozlvHYqVGbpOgwdIjLNRmrEiyakQW['genre']=sozlvHYqVGbpOgwdIjLNRmrEiyakcA.get('infoLabels').get('genre')[0]
   else:
    sozlvHYqVGbpOgwdIjLNRmrEiyakQW['genre']='-'
   sozlvHYqVGbpOgwdIjLNRmrEiyakQA.insert(0,sozlvHYqVGbpOgwdIjLNRmrEiyakQW)
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakcK=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.dic_To_jsonfile(sozlvHYqVGbpOgwdIjLNRmrEiyakQB,sozlvHYqVGbpOgwdIjLNRmrEiyakQA)
  if sozlvHYqVGbpOgwdIjLNRmrEiyakcK==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.addon_noti(__language__(30903).encode('utf8'))
  else:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(sozlvHYqVGbpOgwdIjLNRmrEiyakSF):
  sozlvHYqVGbpOgwdIjLNRmrEiyakFJ=sozlvHYqVGbpOgwdIjLNRmrEiyaknT
  sozlvHYqVGbpOgwdIjLNRmrEiyakSF.LIB_PATH =(__addon__.getSetting('libpath')).strip()
  if sozlvHYqVGbpOgwdIjLNRmrEiyakSF.LIB_PATH=='':sozlvHYqVGbpOgwdIjLNRmrEiyakFJ=sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  if sozlvHYqVGbpOgwdIjLNRmrEiyakFJ==sozlvHYqVGbpOgwdIjLNRmrEiyaknM:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSP=xbmcgui.Dialog()
   sozlvHYqVGbpOgwdIjLNRmrEiyakFh=sozlvHYqVGbpOgwdIjLNRmrEiyakSP.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if sozlvHYqVGbpOgwdIjLNRmrEiyakFh==sozlvHYqVGbpOgwdIjLNRmrEiyaknT:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def dic_To_jsonfile(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,filename,sozlvHYqVGbpOgwdIjLNRmrEiyakFD):
  if filename=='':return sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  try:
   fp=xbmcvfs.File(filename,'w')
   json.dump(sozlvHYqVGbpOgwdIjLNRmrEiyakFD,fp,indent=4,ensure_ascii=sozlvHYqVGbpOgwdIjLNRmrEiyaknM)
   fp.close()
  except:
   return sozlvHYqVGbpOgwdIjLNRmrEiyaknM
  return sozlvHYqVGbpOgwdIjLNRmrEiyaknT
 def jsonfile_To_dic(sozlvHYqVGbpOgwdIjLNRmrEiyakSF,filename):
  if filename=='':return sozlvHYqVGbpOgwdIjLNRmrEiyaknF
  try:
   fp=xbmcvfs.File(filename)
   sozlvHYqVGbpOgwdIjLNRmrEiyakFK=json.load(fp)
   fp.close()
  except:
   sozlvHYqVGbpOgwdIjLNRmrEiyakFK={}
  return sozlvHYqVGbpOgwdIjLNRmrEiyakFK
 def bookmark_main(sozlvHYqVGbpOgwdIjLNRmrEiyakSF):
  sozlvHYqVGbpOgwdIjLNRmrEiyakFe=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.main_params.get('params')
  if sozlvHYqVGbpOgwdIjLNRmrEiyakFe:
   sozlvHYqVGbpOgwdIjLNRmrEiyakFx =base64.standard_b64decode(sozlvHYqVGbpOgwdIjLNRmrEiyakFe).decode('utf-8')
   sozlvHYqVGbpOgwdIjLNRmrEiyakFx =json.loads(sozlvHYqVGbpOgwdIjLNRmrEiyakFx)
   sozlvHYqVGbpOgwdIjLNRmrEiyaknS =sozlvHYqVGbpOgwdIjLNRmrEiyakFx.get('mode')
   sozlvHYqVGbpOgwdIjLNRmrEiyaknQ =sozlvHYqVGbpOgwdIjLNRmrEiyakFx.get('values')
  else:
   sozlvHYqVGbpOgwdIjLNRmrEiyaknS=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.main_params.get('mode',sozlvHYqVGbpOgwdIjLNRmrEiyaknF)
   sozlvHYqVGbpOgwdIjLNRmrEiyaknQ=sozlvHYqVGbpOgwdIjLNRmrEiyakSF.main_params
  sozlvHYqVGbpOgwdIjLNRmrEiyakSF.option_check()
  if sozlvHYqVGbpOgwdIjLNRmrEiyaknS is sozlvHYqVGbpOgwdIjLNRmrEiyaknF:
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.dp_Main_List()
  elif sozlvHYqVGbpOgwdIjLNRmrEiyaknS=='SET_BOOKMARK':
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.dp_Set_Bookmark(sozlvHYqVGbpOgwdIjLNRmrEiyaknQ)
  elif sozlvHYqVGbpOgwdIjLNRmrEiyaknS=='GENRE_GROUP':
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.dp_Genre_Grouplist(sozlvHYqVGbpOgwdIjLNRmrEiyaknQ)
  elif sozlvHYqVGbpOgwdIjLNRmrEiyaknS=='BOOKMARK_GROUP':
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.dp_Bookmark_Grouplist(sozlvHYqVGbpOgwdIjLNRmrEiyaknQ)
  elif sozlvHYqVGbpOgwdIjLNRmrEiyaknS=='BOOKMARK_REMOVE':
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.dp_Bookmark_Remove(sozlvHYqVGbpOgwdIjLNRmrEiyaknQ)
  elif sozlvHYqVGbpOgwdIjLNRmrEiyaknS=='GENRE_RENAME':
   sozlvHYqVGbpOgwdIjLNRmrEiyakSF.dp_Genre_Rename(sozlvHYqVGbpOgwdIjLNRmrEiyaknQ)
  else:
   sozlvHYqVGbpOgwdIjLNRmrEiyaknF
# Created by pyminifier (https://github.com/liftoff/pyminifier)
