__author__="NightRain"
duvQPHnBtrmhFiSlaKDoWLIpMVjqzc=object
duvQPHnBtrmhFiSlaKDoWLIpMVjqzg=None
duvQPHnBtrmhFiSlaKDoWLIpMVjqzR=True
duvQPHnBtrmhFiSlaKDoWLIpMVjqzw=False
duvQPHnBtrmhFiSlaKDoWLIpMVjqzs=type
duvQPHnBtrmhFiSlaKDoWLIpMVjqzX=dict
duvQPHnBtrmhFiSlaKDoWLIpMVjqzC=list
duvQPHnBtrmhFiSlaKDoWLIpMVjqzb=len
duvQPHnBtrmhFiSlaKDoWLIpMVjqzT=int
duvQPHnBtrmhFiSlaKDoWLIpMVjqzY=str
duvQPHnBtrmhFiSlaKDoWLIpMVjqzN=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
duvQPHnBtrmhFiSlaKDoWLIpMVjqEA=[{'title':'찜 목록 (웨이브+티빙+왓챠+넷플)','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','icon':'sum.png'},{'title':'-----------------','mode':'XXX'},{'title':'영화   찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'movie','icon':'movie.png'},{'title':'시리즈 찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'tvshow','icon':'tvshow.png'},{'title':'장르별 찜 목록','mode':'GENRE_GROUP','ott':'-','vidtype':'-','icon':'category.png'},{'title':'-----------------','mode':'XXX'},{'title':'웨이브 찜 목록','mode':'BOOKMARK_GROUP','ott':'wavve','vidtype':'-','icon':'wavve.png'},{'title':'티빙   찜 목록','mode':'BOOKMARK_GROUP','ott':'tving','vidtype':'-','icon':'tving.png'},{'title':'왓챠   찜 목록','mode':'BOOKMARK_GROUP','ott':'watcha','vidtype':'-','icon':'watcha.png'},{'title':'넷플   찜 목록 (search mini 에서 등록)','mode':'BOOKMARK_GROUP','ott':'netflix','vidtype':'-','icon':'netflix.png'},]
from bookmarkCore import*
class duvQPHnBtrmhFiSlaKDoWLIpMVjqEO(duvQPHnBtrmhFiSlaKDoWLIpMVjqzc):
 def __init__(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,duvQPHnBtrmhFiSlaKDoWLIpMVjqEk,duvQPHnBtrmhFiSlaKDoWLIpMVjqEf,duvQPHnBtrmhFiSlaKDoWLIpMVjqEU):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEz._addon_url =duvQPHnBtrmhFiSlaKDoWLIpMVjqEk
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEz._addon_handle=duvQPHnBtrmhFiSlaKDoWLIpMVjqEf
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.main_params =duvQPHnBtrmhFiSlaKDoWLIpMVjqEU
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.LIB_PATH =''
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.LIST_LIMIT =20
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.BookmarkObj =wFSrXtdYEijQMkJqpHlngPGKuNayAs() 
 def addon_noti(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,sting):
  try:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEy=xbmcgui.Dialog()
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEy.notification(__addonname__,sting)
  except:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqzg
 def addon_log(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,string):
  try:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEG=string.encode('utf-8','ignore')
  except:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEG='addonException: addon_log'
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEe=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,duvQPHnBtrmhFiSlaKDoWLIpMVjqEG),level=duvQPHnBtrmhFiSlaKDoWLIpMVjqEe)
 def get_settings_select_ott(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEc =duvQPHnBtrmhFiSlaKDoWLIpMVjqzR if __addon__.getSetting('view_wavve')=='true' else duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEg =duvQPHnBtrmhFiSlaKDoWLIpMVjqzR if __addon__.getSetting('view_tving')=='true' else duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  duvQPHnBtrmhFiSlaKDoWLIpMVjqER =duvQPHnBtrmhFiSlaKDoWLIpMVjqzR if __addon__.getSetting('view_watcha')=='true' else duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEw=duvQPHnBtrmhFiSlaKDoWLIpMVjqzR if __addon__.getSetting('view_netflix')=='true' else duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  return(duvQPHnBtrmhFiSlaKDoWLIpMVjqEc,duvQPHnBtrmhFiSlaKDoWLIpMVjqEg,duvQPHnBtrmhFiSlaKDoWLIpMVjqER,duvQPHnBtrmhFiSlaKDoWLIpMVjqEw)
 def make_Index_Filename(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,tempyn=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_index_file.json'))
  else:
   return duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.LIB_PATH+'bookmark_index.json'
 def make_Vinfo_Filename(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,duvQPHnBtrmhFiSlaKDoWLIpMVjqOT,duvQPHnBtrmhFiSlaKDoWLIpMVjqOY,tempyn=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_vinfo_file.json'))
  else:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEs='%s_%s.json'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqOT,duvQPHnBtrmhFiSlaKDoWLIpMVjqOY)
   return duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.LIB_PATH+duvQPHnBtrmhFiSlaKDoWLIpMVjqEs
 def add_dir(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,label,sublabel='',ott='',img='',infoLabels=duvQPHnBtrmhFiSlaKDoWLIpMVjqzg,isFolder=duvQPHnBtrmhFiSlaKDoWLIpMVjqzR,params='',isLink=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw,ContextMenu=duvQPHnBtrmhFiSlaKDoWLIpMVjqzg):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEX='%s?%s'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz._addon_url,urllib.parse.urlencode(params))
  if sublabel and sublabel!='-':duvQPHnBtrmhFiSlaKDoWLIpMVjqEC='%s < %s >'%(label,sublabel)
  else: duvQPHnBtrmhFiSlaKDoWLIpMVjqEC=label
  if not img:img='DefaultFolder.png'
  if ott:duvQPHnBtrmhFiSlaKDoWLIpMVjqEC='%s - [%s]'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqEC,ott)
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEb=xbmcgui.ListItem(duvQPHnBtrmhFiSlaKDoWLIpMVjqEC)
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqzs(img)==duvQPHnBtrmhFiSlaKDoWLIpMVjqzX:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEb.setArt(img)
  else:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEb.setArt({'thumb':img,'poster':img})
  duvQPHnBtrmhFiSlaKDoWLIpMVjqET=[]
  if infoLabels!=duvQPHnBtrmhFiSlaKDoWLIpMVjqzg:
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqzs(infoLabels.get('cast'))==duvQPHnBtrmhFiSlaKDoWLIpMVjqzC:
    if duvQPHnBtrmhFiSlaKDoWLIpMVjqzb(infoLabels.get('cast'))>0 and duvQPHnBtrmhFiSlaKDoWLIpMVjqzs(infoLabels.get('cast')[0])==duvQPHnBtrmhFiSlaKDoWLIpMVjqzX:
     duvQPHnBtrmhFiSlaKDoWLIpMVjqET=infoLabels.get('cast')
     infoLabels['cast']=[]
  if infoLabels:duvQPHnBtrmhFiSlaKDoWLIpMVjqEb.setInfo('Video',infoLabels)
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqzb(duvQPHnBtrmhFiSlaKDoWLIpMVjqET)>0:duvQPHnBtrmhFiSlaKDoWLIpMVjqEb.setCast(duvQPHnBtrmhFiSlaKDoWLIpMVjqET)
  if not isFolder and not isLink:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEb.setProperty('IsPlayable','true')
  if ContextMenu:duvQPHnBtrmhFiSlaKDoWLIpMVjqEb.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz._addon_handle,duvQPHnBtrmhFiSlaKDoWLIpMVjqEX,duvQPHnBtrmhFiSlaKDoWLIpMVjqEb,isFolder)
 def dp_Main_List(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz):
  (duvQPHnBtrmhFiSlaKDoWLIpMVjqEc,duvQPHnBtrmhFiSlaKDoWLIpMVjqEg,duvQPHnBtrmhFiSlaKDoWLIpMVjqER,duvQPHnBtrmhFiSlaKDoWLIpMVjqEw)=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.get_settings_select_ott()
  for duvQPHnBtrmhFiSlaKDoWLIpMVjqEN in duvQPHnBtrmhFiSlaKDoWLIpMVjqEA:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEC=duvQPHnBtrmhFiSlaKDoWLIpMVjqEN.get('title')
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEJ=''
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqEN.get('mode')=='GROUP_WAVVE' and duvQPHnBtrmhFiSlaKDoWLIpMVjqEc ==duvQPHnBtrmhFiSlaKDoWLIpMVjqzw:continue
   elif duvQPHnBtrmhFiSlaKDoWLIpMVjqEN.get('mode')=='GROUP_TVING' and duvQPHnBtrmhFiSlaKDoWLIpMVjqEg ==duvQPHnBtrmhFiSlaKDoWLIpMVjqzw:continue
   elif duvQPHnBtrmhFiSlaKDoWLIpMVjqEN.get('mode')=='GROUP_WATCHA' and duvQPHnBtrmhFiSlaKDoWLIpMVjqER ==duvQPHnBtrmhFiSlaKDoWLIpMVjqzw:continue
   elif duvQPHnBtrmhFiSlaKDoWLIpMVjqEN.get('mode')=='GROUP_NETFLIX' and duvQPHnBtrmhFiSlaKDoWLIpMVjqEw==duvQPHnBtrmhFiSlaKDoWLIpMVjqzw:continue
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOE={'mode':duvQPHnBtrmhFiSlaKDoWLIpMVjqEN.get('mode'),'ott':duvQPHnBtrmhFiSlaKDoWLIpMVjqEN.get('ott'),'vidtype':duvQPHnBtrmhFiSlaKDoWLIpMVjqEN.get('vidtype'),'page':'1',}
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqEN.get('mode')=='XXX':
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOE['mode']='XXX'
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOA=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOz =duvQPHnBtrmhFiSlaKDoWLIpMVjqzR
   else:
    if 'icon' in duvQPHnBtrmhFiSlaKDoWLIpMVjqEN:
     duvQPHnBtrmhFiSlaKDoWLIpMVjqEJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',duvQPHnBtrmhFiSlaKDoWLIpMVjqEN.get('icon')) 
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOA=duvQPHnBtrmhFiSlaKDoWLIpMVjqzR
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOz =duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.add_dir(duvQPHnBtrmhFiSlaKDoWLIpMVjqEC,sublabel='',ott='',img=duvQPHnBtrmhFiSlaKDoWLIpMVjqEJ,infoLabels=duvQPHnBtrmhFiSlaKDoWLIpMVjqzg,isFolder=duvQPHnBtrmhFiSlaKDoWLIpMVjqOA,params=duvQPHnBtrmhFiSlaKDoWLIpMVjqOE,isLink=duvQPHnBtrmhFiSlaKDoWLIpMVjqOz)
  xbmcplugin.endOfDirectory(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz._addon_handle)
 def dp_Genre_Grouplist(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,args):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOf=[]
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOU=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.make_Index_Filename(tempyn=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw)
  if xbmcvfs.exists(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU):
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOx=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.jsonfile_To_dic(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU)
  else:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOx=[]
  for duvQPHnBtrmhFiSlaKDoWLIpMVjqOy in duvQPHnBtrmhFiSlaKDoWLIpMVjqOx:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOG =duvQPHnBtrmhFiSlaKDoWLIpMVjqOy.get('genre')
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqOG not in duvQPHnBtrmhFiSlaKDoWLIpMVjqOf:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOf.append(duvQPHnBtrmhFiSlaKDoWLIpMVjqOG)
  for duvQPHnBtrmhFiSlaKDoWLIpMVjqOG in duvQPHnBtrmhFiSlaKDoWLIpMVjqOf:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOE={'mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','genre':duvQPHnBtrmhFiSlaKDoWLIpMVjqOG,'page':'1',}
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.add_dir(duvQPHnBtrmhFiSlaKDoWLIpMVjqOG,sublabel='',ott='',img='',infoLabels=duvQPHnBtrmhFiSlaKDoWLIpMVjqzg,isFolder=duvQPHnBtrmhFiSlaKDoWLIpMVjqzR,params=duvQPHnBtrmhFiSlaKDoWLIpMVjqOE)
  xbmcplugin.endOfDirectory(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz._addon_handle)
 def dp_Bookmark_Grouplist(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,args):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOe =duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOc =[]
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOg =args.get('ott')
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOR=args.get('vidtype')
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOw =args.get('genre')
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqOw==duvQPHnBtrmhFiSlaKDoWLIpMVjqzg:duvQPHnBtrmhFiSlaKDoWLIpMVjqOw='all'
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOs =duvQPHnBtrmhFiSlaKDoWLIpMVjqzT(args.get('page'))
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOX =duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.LIST_LIMIT*(duvQPHnBtrmhFiSlaKDoWLIpMVjqOs-1)+1 
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOC =duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.LIST_LIMIT*duvQPHnBtrmhFiSlaKDoWLIpMVjqOs
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOU=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.make_Index_Filename(tempyn=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw)
  if xbmcvfs.exists(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU):
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOx=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.jsonfile_To_dic(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU)
  else:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOx=[]
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOb=0
  for duvQPHnBtrmhFiSlaKDoWLIpMVjqOy in duvQPHnBtrmhFiSlaKDoWLIpMVjqOx:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOT =duvQPHnBtrmhFiSlaKDoWLIpMVjqOy.get('ott')
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOY=duvQPHnBtrmhFiSlaKDoWLIpMVjqOy.get('videoid')
   duvQPHnBtrmhFiSlaKDoWLIpMVjqON=duvQPHnBtrmhFiSlaKDoWLIpMVjqOy.get('vidtype')
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOJ =duvQPHnBtrmhFiSlaKDoWLIpMVjqOy.get('genre')
   if not(duvQPHnBtrmhFiSlaKDoWLIpMVjqOg=='-' or duvQPHnBtrmhFiSlaKDoWLIpMVjqOg==duvQPHnBtrmhFiSlaKDoWLIpMVjqOT):continue
   if not(duvQPHnBtrmhFiSlaKDoWLIpMVjqOR=='-' or duvQPHnBtrmhFiSlaKDoWLIpMVjqOR==duvQPHnBtrmhFiSlaKDoWLIpMVjqON):continue
   if not(duvQPHnBtrmhFiSlaKDoWLIpMVjqOw=='all' or duvQPHnBtrmhFiSlaKDoWLIpMVjqOw==duvQPHnBtrmhFiSlaKDoWLIpMVjqOJ):continue
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOb+=1
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqOX>duvQPHnBtrmhFiSlaKDoWLIpMVjqOb:continue
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqOC<duvQPHnBtrmhFiSlaKDoWLIpMVjqOb:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOe=duvQPHnBtrmhFiSlaKDoWLIpMVjqzR
    break
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAE=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.make_Vinfo_Filename(duvQPHnBtrmhFiSlaKDoWLIpMVjqOT,duvQPHnBtrmhFiSlaKDoWLIpMVjqOY,tempyn=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw)
   if xbmcvfs.exists(duvQPHnBtrmhFiSlaKDoWLIpMVjqAE):
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAO=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.jsonfile_To_dic(duvQPHnBtrmhFiSlaKDoWLIpMVjqAE)
    duvQPHnBtrmhFiSlaKDoWLIpMVjqEC =duvQPHnBtrmhFiSlaKDoWLIpMVjqAO.get('title')
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAz =duvQPHnBtrmhFiSlaKDoWLIpMVjqAO.get('subtitle')
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAk =duvQPHnBtrmhFiSlaKDoWLIpMVjqAO.get('thumbnail')
    duvQPHnBtrmhFiSlaKDoWLIpMVjqEY=duvQPHnBtrmhFiSlaKDoWLIpMVjqAO.get('infoLabels')
   else:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqEC =duvQPHnBtrmhFiSlaKDoWLIpMVjqOy.get('title')
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAz =''
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAk =''
    duvQPHnBtrmhFiSlaKDoWLIpMVjqEY={'mpaa':'0'}
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAO ={'infoLabels':{'title':duvQPHnBtrmhFiSlaKDoWLIpMVjqEC}}
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOE={'mode':'HYPER_LINK','ott':duvQPHnBtrmhFiSlaKDoWLIpMVjqOT,'videoid':duvQPHnBtrmhFiSlaKDoWLIpMVjqOY,'vidtype':duvQPHnBtrmhFiSlaKDoWLIpMVjqON,'title':duvQPHnBtrmhFiSlaKDoWLIpMVjqEC,'thumbnail':duvQPHnBtrmhFiSlaKDoWLIpMVjqAk,'mpaa':duvQPHnBtrmhFiSlaKDoWLIpMVjqzY(duvQPHnBtrmhFiSlaKDoWLIpMVjqEY.get('mpaa'))}
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAf={'mode':'BOOKMARK_REMOVE','list':[duvQPHnBtrmhFiSlaKDoWLIpMVjqOy],}
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAU=urllib.parse.urlencode(duvQPHnBtrmhFiSlaKDoWLIpMVjqAf)
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAx=[('찜 목록 ( %s ) 삭제'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqAO.get('infoLabels').get('title')),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqAU))]
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqOw!='all':
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAf={'mode':'GENRE_RENAME','list':[duvQPHnBtrmhFiSlaKDoWLIpMVjqOy],}
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAU=urllib.parse.urlencode(duvQPHnBtrmhFiSlaKDoWLIpMVjqAf)
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAx.append(('장르명 ( %s ) 수정'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqOw),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqAU)))
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.add_dir(duvQPHnBtrmhFiSlaKDoWLIpMVjqEC,sublabel=duvQPHnBtrmhFiSlaKDoWLIpMVjqAz,ott=duvQPHnBtrmhFiSlaKDoWLIpMVjqOT,img=duvQPHnBtrmhFiSlaKDoWLIpMVjqAk,infoLabels=duvQPHnBtrmhFiSlaKDoWLIpMVjqEY,isFolder=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw,params=duvQPHnBtrmhFiSlaKDoWLIpMVjqOE,isLink=duvQPHnBtrmhFiSlaKDoWLIpMVjqzR,ContextMenu=duvQPHnBtrmhFiSlaKDoWLIpMVjqAx)
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOc.append(duvQPHnBtrmhFiSlaKDoWLIpMVjqOy)
  duvQPHnBtrmhFiSlaKDoWLIpMVjqAy={'plot':'현재페이지의 전체목록을 삭제합니다.'}
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEC='* 현재페이지 목록 삭제 (개별삭제는 팝업메뉴) *'
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOE={'mode':'BOOKMARK_REMOVE','list':duvQPHnBtrmhFiSlaKDoWLIpMVjqOc,}
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.add_dir(duvQPHnBtrmhFiSlaKDoWLIpMVjqEC,sublabel='',ott='',img=duvQPHnBtrmhFiSlaKDoWLIpMVjqEJ,infoLabels=duvQPHnBtrmhFiSlaKDoWLIpMVjqAy,isFolder=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw,params=duvQPHnBtrmhFiSlaKDoWLIpMVjqOE,isLink=duvQPHnBtrmhFiSlaKDoWLIpMVjqzR)
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqOe:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOE={'mode':'BOOKMARK_GROUP','ott':duvQPHnBtrmhFiSlaKDoWLIpMVjqOg,'vidtype':duvQPHnBtrmhFiSlaKDoWLIpMVjqOR,'page':duvQPHnBtrmhFiSlaKDoWLIpMVjqzY(duvQPHnBtrmhFiSlaKDoWLIpMVjqOs+1)}
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEC='[B]%s >>[/B]'%'다음 페이지'
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAz=duvQPHnBtrmhFiSlaKDoWLIpMVjqzY(duvQPHnBtrmhFiSlaKDoWLIpMVjqOs+1)
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.add_dir(duvQPHnBtrmhFiSlaKDoWLIpMVjqEC,sublabel=duvQPHnBtrmhFiSlaKDoWLIpMVjqAz,ott='',img=duvQPHnBtrmhFiSlaKDoWLIpMVjqEJ,infoLabels=duvQPHnBtrmhFiSlaKDoWLIpMVjqzg,isFolder=duvQPHnBtrmhFiSlaKDoWLIpMVjqzR,params=duvQPHnBtrmhFiSlaKDoWLIpMVjqOE)
  xbmcplugin.setContent(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz._addon_handle,'movies')
  xbmcplugin.endOfDirectory(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz._addon_handle)
 def get_keyboard_input(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,defalut,duvQPHnBtrmhFiSlaKDoWLIpMVjqEC):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqAG=duvQPHnBtrmhFiSlaKDoWLIpMVjqzg
  kb=xbmc.Keyboard(defalut,duvQPHnBtrmhFiSlaKDoWLIpMVjqEC,duvQPHnBtrmhFiSlaKDoWLIpMVjqzw)
  kb.setHeading(duvQPHnBtrmhFiSlaKDoWLIpMVjqEC)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAG=kb.getText()
  return duvQPHnBtrmhFiSlaKDoWLIpMVjqAG
 def dp_Genre_Rename(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,args):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqAe =duvQPHnBtrmhFiSlaKDoWLIpMVjqzR
  duvQPHnBtrmhFiSlaKDoWLIpMVjqAc ={}
  try:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAg=args.get('list')
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAg=duvQPHnBtrmhFiSlaKDoWLIpMVjqAg.replace('\'','\"')
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAg=json.loads(duvQPHnBtrmhFiSlaKDoWLIpMVjqAg)
  except:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAe=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqzb(duvQPHnBtrmhFiSlaKDoWLIpMVjqAg)!=0:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAR=duvQPHnBtrmhFiSlaKDoWLIpMVjqAg[0].get('genre')
   else:
    return
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAw=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.get_keyboard_input(duvQPHnBtrmhFiSlaKDoWLIpMVjqAR,__language__(30909).encode('utf-8'))
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqAw!=duvQPHnBtrmhFiSlaKDoWLIpMVjqzg:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAw=duvQPHnBtrmhFiSlaKDoWLIpMVjqAw.strip()
   else:
    return
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqAR==duvQPHnBtrmhFiSlaKDoWLIpMVjqAw:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.addon_noti(__language__(30910).encode('utf-8'))
    return
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   for duvQPHnBtrmhFiSlaKDoWLIpMVjqAs in duvQPHnBtrmhFiSlaKDoWLIpMVjqAg:
    if duvQPHnBtrmhFiSlaKDoWLIpMVjqAs['ott']in duvQPHnBtrmhFiSlaKDoWLIpMVjqAc:
     duvQPHnBtrmhFiSlaKDoWLIpMVjqAc[duvQPHnBtrmhFiSlaKDoWLIpMVjqAs['ott']].append(duvQPHnBtrmhFiSlaKDoWLIpMVjqAs['videoid'])
    else:
     duvQPHnBtrmhFiSlaKDoWLIpMVjqAc[duvQPHnBtrmhFiSlaKDoWLIpMVjqAs['ott']]=[duvQPHnBtrmhFiSlaKDoWLIpMVjqAs['videoid']]
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOU=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.make_Index_Filename(tempyn=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw)
   if xbmcvfs.exists(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU):
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOx=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.jsonfile_To_dic(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU)
   else:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   for i in duvQPHnBtrmhFiSlaKDoWLIpMVjqzN(duvQPHnBtrmhFiSlaKDoWLIpMVjqzb(duvQPHnBtrmhFiSlaKDoWLIpMVjqOx)):
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAX =duvQPHnBtrmhFiSlaKDoWLIpMVjqOx[i].get('ott')
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAC=duvQPHnBtrmhFiSlaKDoWLIpMVjqOx[i].get('videoid')
    if duvQPHnBtrmhFiSlaKDoWLIpMVjqAX in duvQPHnBtrmhFiSlaKDoWLIpMVjqAc:
     if duvQPHnBtrmhFiSlaKDoWLIpMVjqAC in duvQPHnBtrmhFiSlaKDoWLIpMVjqAc[duvQPHnBtrmhFiSlaKDoWLIpMVjqAX]:
      duvQPHnBtrmhFiSlaKDoWLIpMVjqOx[i]['genre']=duvQPHnBtrmhFiSlaKDoWLIpMVjqAw
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAe=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.dic_To_jsonfile(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU,duvQPHnBtrmhFiSlaKDoWLIpMVjqOx)
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.addon_noti(__language__(30911).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.addon_noti(__language__(30912).encode('utf-8'))
 def dp_Bookmark_Remove(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,args):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqAe =duvQPHnBtrmhFiSlaKDoWLIpMVjqzR
  duvQPHnBtrmhFiSlaKDoWLIpMVjqAb ={}
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEy=xbmcgui.Dialog()
  duvQPHnBtrmhFiSlaKDoWLIpMVjqAT=duvQPHnBtrmhFiSlaKDoWLIpMVjqEy.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAT==duvQPHnBtrmhFiSlaKDoWLIpMVjqzw:sys.exit()
  try:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAg=args.get('list')
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAg=duvQPHnBtrmhFiSlaKDoWLIpMVjqAg.replace('\'','\"')
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAg=json.loads(duvQPHnBtrmhFiSlaKDoWLIpMVjqAg)
  except:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAe=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   for duvQPHnBtrmhFiSlaKDoWLIpMVjqAs in duvQPHnBtrmhFiSlaKDoWLIpMVjqAg:
    if duvQPHnBtrmhFiSlaKDoWLIpMVjqAs['ott']in duvQPHnBtrmhFiSlaKDoWLIpMVjqAb:
     duvQPHnBtrmhFiSlaKDoWLIpMVjqAb[duvQPHnBtrmhFiSlaKDoWLIpMVjqAs['ott']].append(duvQPHnBtrmhFiSlaKDoWLIpMVjqAs['videoid'])
    else:
     duvQPHnBtrmhFiSlaKDoWLIpMVjqAb[duvQPHnBtrmhFiSlaKDoWLIpMVjqAs['ott']]=[duvQPHnBtrmhFiSlaKDoWLIpMVjqAs['videoid']]
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOU=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.make_Index_Filename(tempyn=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw)
   if xbmcvfs.exists(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU):
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOx=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.jsonfile_To_dic(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU)
   else:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOy=[]
   for duvQPHnBtrmhFiSlaKDoWLIpMVjqAY in duvQPHnBtrmhFiSlaKDoWLIpMVjqOx:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAX =duvQPHnBtrmhFiSlaKDoWLIpMVjqAY.get('ott')
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAC=duvQPHnBtrmhFiSlaKDoWLIpMVjqAY.get('videoid')
    if duvQPHnBtrmhFiSlaKDoWLIpMVjqAX in duvQPHnBtrmhFiSlaKDoWLIpMVjqAb:
     if duvQPHnBtrmhFiSlaKDoWLIpMVjqAC in duvQPHnBtrmhFiSlaKDoWLIpMVjqAb[duvQPHnBtrmhFiSlaKDoWLIpMVjqAX]:
      duvQPHnBtrmhFiSlaKDoWLIpMVjqAE=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.make_Vinfo_Filename(duvQPHnBtrmhFiSlaKDoWLIpMVjqAX,duvQPHnBtrmhFiSlaKDoWLIpMVjqAC,tempyn=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw)
      xbmcvfs.delete(duvQPHnBtrmhFiSlaKDoWLIpMVjqAE)
      continue
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOy.append(duvQPHnBtrmhFiSlaKDoWLIpMVjqAY)
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqzg
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAe=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.dic_To_jsonfile(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU,duvQPHnBtrmhFiSlaKDoWLIpMVjqOy)
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.addon_noti(__language__(30908).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.addon_noti(__language__(30907).encode('utf-8'))
 def dp_Hyper_Link(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,args):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOT =args.get('ott')
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOY =args.get('videoid')
  duvQPHnBtrmhFiSlaKDoWLIpMVjqON =args.get('vidtype')
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEC =args.get('title')
  duvQPHnBtrmhFiSlaKDoWLIpMVjqAk =args.get('thumbnail')
  duvQPHnBtrmhFiSlaKDoWLIpMVjqAN =args.get('mpaa')
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqOT=='wavve':
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqON=='tvshow':
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ={'mode':'EPISODE_LIST','videoid':duvQPHnBtrmhFiSlaKDoWLIpMVjqOY,'vidtype':duvQPHnBtrmhFiSlaKDoWLIpMVjqON,'page':'1',}
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzE=urllib.parse.urlencode(duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ)
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzO='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqzE)
   else:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ={'mode':'MOVIE','contentid':duvQPHnBtrmhFiSlaKDoWLIpMVjqOY,'title':duvQPHnBtrmhFiSlaKDoWLIpMVjqEC,'thumbnail':duvQPHnBtrmhFiSlaKDoWLIpMVjqAk,'age':duvQPHnBtrmhFiSlaKDoWLIpMVjqAN,}
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzE=urllib.parse.urlencode(duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ)
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzO='PlayMedia("plugin://plugin.video.wavvem/?%s")'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqzE)
  elif duvQPHnBtrmhFiSlaKDoWLIpMVjqOT=='tving':
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqON=='tvshow':
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ={'mode':'EPISODE','programcode':duvQPHnBtrmhFiSlaKDoWLIpMVjqOY,'page':'1',}
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzE=urllib.parse.urlencode(duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ)
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzO='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqzE)
   else:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ={'mode':'MOVIE','stype':'movie','mediacode':duvQPHnBtrmhFiSlaKDoWLIpMVjqOY,'title':duvQPHnBtrmhFiSlaKDoWLIpMVjqEC,'thumbnail':duvQPHnBtrmhFiSlaKDoWLIpMVjqAk,}
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzE=urllib.parse.urlencode(duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ)
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzO='PlayMedia("plugin://plugin.video.tvingm/?%s")'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqzE)
  elif duvQPHnBtrmhFiSlaKDoWLIpMVjqOT=='watcha':
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqON=='tvshow':
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ={'mode':'EPISODE','movie_code':duvQPHnBtrmhFiSlaKDoWLIpMVjqOY,'season_code':duvQPHnBtrmhFiSlaKDoWLIpMVjqOY,'page':'1',}
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzE=urllib.parse.urlencode(duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ)
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzO='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqzE)
   else:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ={'mode':'MOVIE','movie_code':duvQPHnBtrmhFiSlaKDoWLIpMVjqOY,'season_code':'-','title':duvQPHnBtrmhFiSlaKDoWLIpMVjqEC,'thumbnail':duvQPHnBtrmhFiSlaKDoWLIpMVjqAk,}
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzE=urllib.parse.urlencode(duvQPHnBtrmhFiSlaKDoWLIpMVjqAJ)
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzO='PlayMedia("plugin://plugin.video.watcham/?%s")'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqzE)
  elif duvQPHnBtrmhFiSlaKDoWLIpMVjqOT=='netflix':
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqON=='tvshow':
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzO='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqOY)
   else:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqzO='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/")'%(duvQPHnBtrmhFiSlaKDoWLIpMVjqOY)
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(duvQPHnBtrmhFiSlaKDoWLIpMVjqzO)
 def dp_Set_Bookmark(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,args):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqAe =duvQPHnBtrmhFiSlaKDoWLIpMVjqzR
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOx=[]
  duvQPHnBtrmhFiSlaKDoWLIpMVjqzA =urllib.parse.unquote(args.get('bm_param'))
  duvQPHnBtrmhFiSlaKDoWLIpMVjqzA =json.loads(duvQPHnBtrmhFiSlaKDoWLIpMVjqzA)
  duvQPHnBtrmhFiSlaKDoWLIpMVjqOy=duvQPHnBtrmhFiSlaKDoWLIpMVjqzA.get('indexinfo')
  duvQPHnBtrmhFiSlaKDoWLIpMVjqAO =duvQPHnBtrmhFiSlaKDoWLIpMVjqzA.get('saveinfo')
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAE=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.make_Vinfo_Filename(duvQPHnBtrmhFiSlaKDoWLIpMVjqOy.get('ott'),duvQPHnBtrmhFiSlaKDoWLIpMVjqOy.get('videoid'),tempyn=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw)
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAe=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.dic_To_jsonfile(duvQPHnBtrmhFiSlaKDoWLIpMVjqAE,duvQPHnBtrmhFiSlaKDoWLIpMVjqAO)
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOU=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.make_Index_Filename(tempyn=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw)
   if xbmcvfs.exists(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU):
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOx=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.jsonfile_To_dic(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU)
   else:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOx=[]
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqzk =duvQPHnBtrmhFiSlaKDoWLIpMVjqOy.get('ott')
   duvQPHnBtrmhFiSlaKDoWLIpMVjqzf =duvQPHnBtrmhFiSlaKDoWLIpMVjqOy.get('videoid')
   for i in duvQPHnBtrmhFiSlaKDoWLIpMVjqzN(duvQPHnBtrmhFiSlaKDoWLIpMVjqzb(duvQPHnBtrmhFiSlaKDoWLIpMVjqOx)):
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAX =duvQPHnBtrmhFiSlaKDoWLIpMVjqOx[i].get('ott')
    duvQPHnBtrmhFiSlaKDoWLIpMVjqAC=duvQPHnBtrmhFiSlaKDoWLIpMVjqOx[i].get('videoid')
    if duvQPHnBtrmhFiSlaKDoWLIpMVjqzk==duvQPHnBtrmhFiSlaKDoWLIpMVjqAX and duvQPHnBtrmhFiSlaKDoWLIpMVjqzf==duvQPHnBtrmhFiSlaKDoWLIpMVjqAC:
     duvQPHnBtrmhFiSlaKDoWLIpMVjqOx.pop(i)
     break
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOy['title']=duvQPHnBtrmhFiSlaKDoWLIpMVjqAO.get('title')
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqzb(duvQPHnBtrmhFiSlaKDoWLIpMVjqAO.get('infoLabels').get('genre'))>0:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOy['genre']=duvQPHnBtrmhFiSlaKDoWLIpMVjqAO.get('infoLabels').get('genre')[0]
   else:
    duvQPHnBtrmhFiSlaKDoWLIpMVjqOy['genre']='-'
   duvQPHnBtrmhFiSlaKDoWLIpMVjqOx.insert(0,duvQPHnBtrmhFiSlaKDoWLIpMVjqOy)
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAe=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.dic_To_jsonfile(duvQPHnBtrmhFiSlaKDoWLIpMVjqOU,duvQPHnBtrmhFiSlaKDoWLIpMVjqOx)
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqAe==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.addon_noti(__language__(30903).encode('utf8'))
  else:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqzU=duvQPHnBtrmhFiSlaKDoWLIpMVjqzR
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.LIB_PATH =(__addon__.getSetting('libpath')).strip()
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.LIB_PATH=='':duvQPHnBtrmhFiSlaKDoWLIpMVjqzU=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqzU==duvQPHnBtrmhFiSlaKDoWLIpMVjqzw:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEy=xbmcgui.Dialog()
   duvQPHnBtrmhFiSlaKDoWLIpMVjqAT=duvQPHnBtrmhFiSlaKDoWLIpMVjqEy.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if duvQPHnBtrmhFiSlaKDoWLIpMVjqAT==duvQPHnBtrmhFiSlaKDoWLIpMVjqzR:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def dic_To_jsonfile(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,filename,duvQPHnBtrmhFiSlaKDoWLIpMVjqzx):
  if filename=='':return duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  try:
   fp=xbmcvfs.File(filename,'w')
   json.dump(duvQPHnBtrmhFiSlaKDoWLIpMVjqzx,fp,indent=4,ensure_ascii=duvQPHnBtrmhFiSlaKDoWLIpMVjqzw)
   fp.close()
  except:
   return duvQPHnBtrmhFiSlaKDoWLIpMVjqzw
  return duvQPHnBtrmhFiSlaKDoWLIpMVjqzR
 def jsonfile_To_dic(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz,filename):
  if filename=='':return duvQPHnBtrmhFiSlaKDoWLIpMVjqzg
  try:
   fp=xbmcvfs.File(filename)
   duvQPHnBtrmhFiSlaKDoWLIpMVjqzG=json.load(fp)
   fp.close()
  except:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqzG={}
  return duvQPHnBtrmhFiSlaKDoWLIpMVjqzG
 def bookmark_main(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz):
  duvQPHnBtrmhFiSlaKDoWLIpMVjqze=duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.main_params.get('mode',duvQPHnBtrmhFiSlaKDoWLIpMVjqzg)
  duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.option_check()
  if duvQPHnBtrmhFiSlaKDoWLIpMVjqze is duvQPHnBtrmhFiSlaKDoWLIpMVjqzg:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.dp_Main_List()
  elif duvQPHnBtrmhFiSlaKDoWLIpMVjqze=='SET_BOOKMARK':
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.dp_Set_Bookmark(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.main_params)
  elif duvQPHnBtrmhFiSlaKDoWLIpMVjqze=='GENRE_GROUP':
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.dp_Genre_Grouplist(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.main_params)
  elif duvQPHnBtrmhFiSlaKDoWLIpMVjqze=='BOOKMARK_GROUP':
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.dp_Bookmark_Grouplist(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.main_params)
  elif duvQPHnBtrmhFiSlaKDoWLIpMVjqze=='HYPER_LINK':
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.dp_Hyper_Link(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.main_params)
  elif duvQPHnBtrmhFiSlaKDoWLIpMVjqze=='BOOKMARK_REMOVE':
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.dp_Bookmark_Remove(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.main_params)
  elif duvQPHnBtrmhFiSlaKDoWLIpMVjqze=='GENRE_RENAME':
   duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.dp_Genre_Rename(duvQPHnBtrmhFiSlaKDoWLIpMVjqEz.main_params)
  else:
   duvQPHnBtrmhFiSlaKDoWLIpMVjqzg
# Created by pyminifier (https://github.com/liftoff/pyminifier)
