__author__="NightRain"
wFSrXtdYEijQMkJqpHlngPGKuNayAU=object
wFSrXtdYEijQMkJqpHlngPGKuNayAe=None
wFSrXtdYEijQMkJqpHlngPGKuNayAz=False
wFSrXtdYEijQMkJqpHlngPGKuNayAL=open
wFSrXtdYEijQMkJqpHlngPGKuNayAC=True
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class wFSrXtdYEijQMkJqpHlngPGKuNayAs(wFSrXtdYEijQMkJqpHlngPGKuNayAU):
 def __init__(wFSrXtdYEijQMkJqpHlngPGKuNayAh):
  wFSrXtdYEijQMkJqpHlngPGKuNayAh.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  wFSrXtdYEijQMkJqpHlngPGKuNayAh.DEFAULT_HEADER ={'user-agent':wFSrXtdYEijQMkJqpHlngPGKuNayAh.USER_AGENT}
 def callRequestCookies(wFSrXtdYEijQMkJqpHlngPGKuNayAh,jobtype,url,payload=wFSrXtdYEijQMkJqpHlngPGKuNayAe,params=wFSrXtdYEijQMkJqpHlngPGKuNayAe,headers=wFSrXtdYEijQMkJqpHlngPGKuNayAe,cookies=wFSrXtdYEijQMkJqpHlngPGKuNayAe,redirects=wFSrXtdYEijQMkJqpHlngPGKuNayAz):
  wFSrXtdYEijQMkJqpHlngPGKuNayAo=wFSrXtdYEijQMkJqpHlngPGKuNayAh.DEFAULT_HEADER
  if headers:wFSrXtdYEijQMkJqpHlngPGKuNayAo.update(headers)
  if jobtype=='Get':
   wFSrXtdYEijQMkJqpHlngPGKuNayAI=requests.get(url,params=params,headers=wFSrXtdYEijQMkJqpHlngPGKuNayAo,cookies=cookies,allow_redirects=redirects)
  else:
   wFSrXtdYEijQMkJqpHlngPGKuNayAI=requests.post(url,data=payload,params=params,headers=wFSrXtdYEijQMkJqpHlngPGKuNayAo,cookies=cookies,allow_redirects=redirects)
  return wFSrXtdYEijQMkJqpHlngPGKuNayAI
 def Get_Now_Datetime(wFSrXtdYEijQMkJqpHlngPGKuNayAh):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def local_dic_To_jsonfile(wFSrXtdYEijQMkJqpHlngPGKuNayAh,filename,dic):
  if filename=='':return wFSrXtdYEijQMkJqpHlngPGKuNayAz
  try:
   fp=wFSrXtdYEijQMkJqpHlngPGKuNayAL(filename,'w',-1,'utf-8')
   json.dump(dic,fp)
   fp.close()
  except:
   return wFSrXtdYEijQMkJqpHlngPGKuNayAz
  return wFSrXtdYEijQMkJqpHlngPGKuNayAC
 def local_jsonfile_To_dic(wFSrXtdYEijQMkJqpHlngPGKuNayAh,filename):
  if filename=='':return wFSrXtdYEijQMkJqpHlngPGKuNayAe
  try:
   fp=wFSrXtdYEijQMkJqpHlngPGKuNayAL(filename,'r',-1,'utf-8')
   wFSrXtdYEijQMkJqpHlngPGKuNayAc=json.load(fp)
   fp.close()
  except:
   wFSrXtdYEijQMkJqpHlngPGKuNayAc={}
  return wFSrXtdYEijQMkJqpHlngPGKuNayAc
# Created by pyminifier (https://github.com/liftoff/pyminifier)
