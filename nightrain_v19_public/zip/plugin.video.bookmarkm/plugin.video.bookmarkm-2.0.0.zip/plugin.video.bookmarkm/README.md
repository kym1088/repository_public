# searchM-v19
 OTT 통합검색 애드온 for Kodi19 


## Version 2.0. (2021.03.13)
- Initial addon version

