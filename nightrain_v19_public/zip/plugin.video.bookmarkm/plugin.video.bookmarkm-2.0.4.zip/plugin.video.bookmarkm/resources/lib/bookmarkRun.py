__author__="NightRain"
IAtuByiJKwTSWFXPnpgkCELbHUQjcv=object
IAtuByiJKwTSWFXPnpgkCELbHUQjcm=None
IAtuByiJKwTSWFXPnpgkCELbHUQjcD=True
IAtuByiJKwTSWFXPnpgkCELbHUQjcN=False
IAtuByiJKwTSWFXPnpgkCELbHUQjcx=type
IAtuByiJKwTSWFXPnpgkCELbHUQjcs=dict
IAtuByiJKwTSWFXPnpgkCELbHUQjco=list
IAtuByiJKwTSWFXPnpgkCELbHUQjcM=len
IAtuByiJKwTSWFXPnpgkCELbHUQjcR=int
IAtuByiJKwTSWFXPnpgkCELbHUQjcz=str
IAtuByiJKwTSWFXPnpgkCELbHUQjcr=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
IAtuByiJKwTSWFXPnpgkCELbHUQjYv=[{'title':'찜 목록 (웨이브+티빙+왓챠+쿠팡+넷플)','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','icon':'sum.png'},{'title':'-----------------','mode':'XXX'},{'title':'영화   찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'movie','icon':'movie.png'},{'title':'시리즈 찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'tvshow','icon':'tvshow.png'},{'title':'장르별 찜 목록','mode':'GENRE_GROUP','ott':'-','vidtype':'-','icon':'category.png'},{'title':'-----------------','mode':'XXX'},{'title':'웨이브 찜 목록','mode':'BOOKMARK_GROUP','ott':'wavve','vidtype':'-','icon':'wavve.png'},{'title':'티빙   찜 목록','mode':'BOOKMARK_GROUP','ott':'tving','vidtype':'-','icon':'tving.png'},{'title':'왓챠   찜 목록','mode':'BOOKMARK_GROUP','ott':'watcha','vidtype':'-','icon':'watcha.png'},{'title':'쿠팡   찜 목록','mode':'BOOKMARK_GROUP','ott':'coupang','vidtype':'-','icon':'coupang.png'},{'title':'넷플   찜 목록 (search mini 에서 등록)','mode':'BOOKMARK_GROUP','ott':'netflix','vidtype':'-','icon':'netflix.png'},{'title':'프라임비디오 찜 목록 (테스트용)','mode':'BOOKMARK_GROUP','ott':'amazon','vidtype':'-','icon':'primev.png'},{'title':'디즈니플러스 찜 목록','mode':'BOOKMARK_GROUP','ott':'disney','vidtype':'-','icon':'disney.jpg'},]
from bookmarkCore import*
class IAtuByiJKwTSWFXPnpgkCELbHUQjYO(IAtuByiJKwTSWFXPnpgkCELbHUQjcv):
 def __init__(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,IAtuByiJKwTSWFXPnpgkCELbHUQjYc,IAtuByiJKwTSWFXPnpgkCELbHUQjYD,IAtuByiJKwTSWFXPnpgkCELbHUQjYN):
  IAtuByiJKwTSWFXPnpgkCELbHUQjYm._addon_url =IAtuByiJKwTSWFXPnpgkCELbHUQjYc
  IAtuByiJKwTSWFXPnpgkCELbHUQjYm._addon_handle=IAtuByiJKwTSWFXPnpgkCELbHUQjYD
  IAtuByiJKwTSWFXPnpgkCELbHUQjYm.main_params =IAtuByiJKwTSWFXPnpgkCELbHUQjYN
  IAtuByiJKwTSWFXPnpgkCELbHUQjYm.LIB_PATH =''
  IAtuByiJKwTSWFXPnpgkCELbHUQjYm.LIST_LIMIT =20
  IAtuByiJKwTSWFXPnpgkCELbHUQjYm.BookmarkObj =OvhqacuFbxsMNlyLpgUQewDAVfCRnz() 
 def addon_noti(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,sting):
  try:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYs=xbmcgui.Dialog()
   IAtuByiJKwTSWFXPnpgkCELbHUQjYs.notification(__addonname__,sting)
  except:
   IAtuByiJKwTSWFXPnpgkCELbHUQjcm
 def addon_log(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,string):
  try:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYo=string.encode('utf-8','ignore')
  except:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYo='addonException: addon_log'
  IAtuByiJKwTSWFXPnpgkCELbHUQjYM=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,IAtuByiJKwTSWFXPnpgkCELbHUQjYo),level=IAtuByiJKwTSWFXPnpgkCELbHUQjYM)
 def get_settings_select_ott(IAtuByiJKwTSWFXPnpgkCELbHUQjYm):
  IAtuByiJKwTSWFXPnpgkCELbHUQjYR =IAtuByiJKwTSWFXPnpgkCELbHUQjcD if __addon__.getSetting('view_wavve')=='true' else IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  IAtuByiJKwTSWFXPnpgkCELbHUQjYz =IAtuByiJKwTSWFXPnpgkCELbHUQjcD if __addon__.getSetting('view_tving')=='true' else IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  IAtuByiJKwTSWFXPnpgkCELbHUQjYr =IAtuByiJKwTSWFXPnpgkCELbHUQjcD if __addon__.getSetting('view_watcha')=='true' else IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  IAtuByiJKwTSWFXPnpgkCELbHUQjYd=IAtuByiJKwTSWFXPnpgkCELbHUQjcD if __addon__.getSetting('view_coupang')=='true' else IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  IAtuByiJKwTSWFXPnpgkCELbHUQjYq=IAtuByiJKwTSWFXPnpgkCELbHUQjcD if __addon__.getSetting('view_netflix')=='true' else IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  IAtuByiJKwTSWFXPnpgkCELbHUQjYe =IAtuByiJKwTSWFXPnpgkCELbHUQjcD if __addon__.getSetting('view_primev')=='true' else IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  IAtuByiJKwTSWFXPnpgkCELbHUQjYa =IAtuByiJKwTSWFXPnpgkCELbHUQjcD if __addon__.getSetting('view_disney')=='true' else IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  return(IAtuByiJKwTSWFXPnpgkCELbHUQjYR,IAtuByiJKwTSWFXPnpgkCELbHUQjYz,IAtuByiJKwTSWFXPnpgkCELbHUQjYr,IAtuByiJKwTSWFXPnpgkCELbHUQjYd,IAtuByiJKwTSWFXPnpgkCELbHUQjYq,IAtuByiJKwTSWFXPnpgkCELbHUQjYe,IAtuByiJKwTSWFXPnpgkCELbHUQjYa)
 def make_Index_Filename(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,tempyn=IAtuByiJKwTSWFXPnpgkCELbHUQjcN):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_index_file.json'))
  else:
   return IAtuByiJKwTSWFXPnpgkCELbHUQjYm.LIB_PATH+'bookmark_index.json'
 def make_Vinfo_Filename(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,IAtuByiJKwTSWFXPnpgkCELbHUQjvY,IAtuByiJKwTSWFXPnpgkCELbHUQjvO,tempyn=IAtuByiJKwTSWFXPnpgkCELbHUQjcN):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_vinfo_file.json'))
  else:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYV='%s_%s.json'%(IAtuByiJKwTSWFXPnpgkCELbHUQjvY,IAtuByiJKwTSWFXPnpgkCELbHUQjvO)
   return IAtuByiJKwTSWFXPnpgkCELbHUQjYm.LIB_PATH+IAtuByiJKwTSWFXPnpgkCELbHUQjYV
 def add_dir(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,label,sublabel='',ott='',img='',infoLabels=IAtuByiJKwTSWFXPnpgkCELbHUQjcm,isFolder=IAtuByiJKwTSWFXPnpgkCELbHUQjcD,params='',isLink=IAtuByiJKwTSWFXPnpgkCELbHUQjcN,ContextMenu=IAtuByiJKwTSWFXPnpgkCELbHUQjcm,direct_url=IAtuByiJKwTSWFXPnpgkCELbHUQjcm):
  if direct_url:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYf=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   IAtuByiJKwTSWFXPnpgkCELbHUQjYG=json.dumps(params,separators=(',',':'))
   IAtuByiJKwTSWFXPnpgkCELbHUQjYG=base64.standard_b64encode(IAtuByiJKwTSWFXPnpgkCELbHUQjYG.encode()).decode('utf-8')
   IAtuByiJKwTSWFXPnpgkCELbHUQjYG=IAtuByiJKwTSWFXPnpgkCELbHUQjYG.replace('+','%2B')
   IAtuByiJKwTSWFXPnpgkCELbHUQjYf='%s?params=%s'%(IAtuByiJKwTSWFXPnpgkCELbHUQjYm._addon_url,IAtuByiJKwTSWFXPnpgkCELbHUQjYG)
  if sublabel and sublabel!='-':IAtuByiJKwTSWFXPnpgkCELbHUQjYh='%s < %s >'%(label,sublabel)
  else: IAtuByiJKwTSWFXPnpgkCELbHUQjYh=label
  if not img:img='DefaultFolder.png'
  if ott:IAtuByiJKwTSWFXPnpgkCELbHUQjYh='%s - [%s]'%(IAtuByiJKwTSWFXPnpgkCELbHUQjYh,ott)
  IAtuByiJKwTSWFXPnpgkCELbHUQjOY=xbmcgui.ListItem(IAtuByiJKwTSWFXPnpgkCELbHUQjYh)
  if IAtuByiJKwTSWFXPnpgkCELbHUQjcx(img)==IAtuByiJKwTSWFXPnpgkCELbHUQjcs:
   IAtuByiJKwTSWFXPnpgkCELbHUQjOY.setArt(img)
  else:
   IAtuByiJKwTSWFXPnpgkCELbHUQjOY.setArt({'thumb':img,'poster':img})
  IAtuByiJKwTSWFXPnpgkCELbHUQjOv=[]
  if infoLabels!=IAtuByiJKwTSWFXPnpgkCELbHUQjcm:
   if IAtuByiJKwTSWFXPnpgkCELbHUQjcx(infoLabels.get('cast'))==IAtuByiJKwTSWFXPnpgkCELbHUQjco:
    if IAtuByiJKwTSWFXPnpgkCELbHUQjcM(infoLabels.get('cast'))>0 and IAtuByiJKwTSWFXPnpgkCELbHUQjcx(infoLabels.get('cast')[0])==IAtuByiJKwTSWFXPnpgkCELbHUQjcs:
     IAtuByiJKwTSWFXPnpgkCELbHUQjOv=infoLabels.get('cast')
     infoLabels['cast']=[]
  if infoLabels:IAtuByiJKwTSWFXPnpgkCELbHUQjOY.setInfo('Video',infoLabels)
  if IAtuByiJKwTSWFXPnpgkCELbHUQjcM(IAtuByiJKwTSWFXPnpgkCELbHUQjOv)>0:IAtuByiJKwTSWFXPnpgkCELbHUQjOY.setCast(IAtuByiJKwTSWFXPnpgkCELbHUQjOv)
  if not isFolder and not isLink:
   IAtuByiJKwTSWFXPnpgkCELbHUQjOY.setProperty('IsPlayable','true')
  if ContextMenu:IAtuByiJKwTSWFXPnpgkCELbHUQjOY.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(IAtuByiJKwTSWFXPnpgkCELbHUQjYm._addon_handle,IAtuByiJKwTSWFXPnpgkCELbHUQjYf,IAtuByiJKwTSWFXPnpgkCELbHUQjOY,isFolder)
 def dp_Main_List(IAtuByiJKwTSWFXPnpgkCELbHUQjYm):
  (IAtuByiJKwTSWFXPnpgkCELbHUQjYR,IAtuByiJKwTSWFXPnpgkCELbHUQjYz,IAtuByiJKwTSWFXPnpgkCELbHUQjYr,IAtuByiJKwTSWFXPnpgkCELbHUQjYd,IAtuByiJKwTSWFXPnpgkCELbHUQjYq,IAtuByiJKwTSWFXPnpgkCELbHUQjYe,IAtuByiJKwTSWFXPnpgkCELbHUQjYa)=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.get_settings_select_ott()
  for IAtuByiJKwTSWFXPnpgkCELbHUQjOc in IAtuByiJKwTSWFXPnpgkCELbHUQjYv:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYh=IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('title')
   IAtuByiJKwTSWFXPnpgkCELbHUQjOD=''
   if IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('ott')=='wavve' and IAtuByiJKwTSWFXPnpgkCELbHUQjYR ==IAtuByiJKwTSWFXPnpgkCELbHUQjcN:continue
   elif IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('ott')=='tving' and IAtuByiJKwTSWFXPnpgkCELbHUQjYz ==IAtuByiJKwTSWFXPnpgkCELbHUQjcN:continue
   elif IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('ott')=='watcha' and IAtuByiJKwTSWFXPnpgkCELbHUQjYr ==IAtuByiJKwTSWFXPnpgkCELbHUQjcN:continue
   elif IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('ott')=='coupang' and IAtuByiJKwTSWFXPnpgkCELbHUQjYd==IAtuByiJKwTSWFXPnpgkCELbHUQjcN:continue
   elif IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('ott')=='netflix' and IAtuByiJKwTSWFXPnpgkCELbHUQjYq==IAtuByiJKwTSWFXPnpgkCELbHUQjcN:continue
   elif IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('ott')=='amazon' and IAtuByiJKwTSWFXPnpgkCELbHUQjYe ==IAtuByiJKwTSWFXPnpgkCELbHUQjcN:continue
   elif IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('ott')=='disney' and IAtuByiJKwTSWFXPnpgkCELbHUQjYa ==IAtuByiJKwTSWFXPnpgkCELbHUQjcN:continue
   IAtuByiJKwTSWFXPnpgkCELbHUQjYl={'mode':IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('mode'),'ott':IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('ott'),'vidtype':IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('vidtype'),'page':'1',}
   if IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('mode')=='XXX':
    IAtuByiJKwTSWFXPnpgkCELbHUQjYl['mode']='XXX'
    IAtuByiJKwTSWFXPnpgkCELbHUQjON=IAtuByiJKwTSWFXPnpgkCELbHUQjcN
    IAtuByiJKwTSWFXPnpgkCELbHUQjOx =IAtuByiJKwTSWFXPnpgkCELbHUQjcD
   else:
    if 'icon' in IAtuByiJKwTSWFXPnpgkCELbHUQjOc:
     IAtuByiJKwTSWFXPnpgkCELbHUQjOD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',IAtuByiJKwTSWFXPnpgkCELbHUQjOc.get('icon')) 
    IAtuByiJKwTSWFXPnpgkCELbHUQjON=IAtuByiJKwTSWFXPnpgkCELbHUQjcD
    IAtuByiJKwTSWFXPnpgkCELbHUQjOx =IAtuByiJKwTSWFXPnpgkCELbHUQjcN
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.add_dir(IAtuByiJKwTSWFXPnpgkCELbHUQjYh,sublabel='',ott='',img=IAtuByiJKwTSWFXPnpgkCELbHUQjOD,infoLabels=IAtuByiJKwTSWFXPnpgkCELbHUQjcm,isFolder=IAtuByiJKwTSWFXPnpgkCELbHUQjON,params=IAtuByiJKwTSWFXPnpgkCELbHUQjYl,isLink=IAtuByiJKwTSWFXPnpgkCELbHUQjOx)
  xbmcplugin.endOfDirectory(IAtuByiJKwTSWFXPnpgkCELbHUQjYm._addon_handle)
 def dp_Genre_Grouplist(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,args):
  IAtuByiJKwTSWFXPnpgkCELbHUQjOo=[]
  IAtuByiJKwTSWFXPnpgkCELbHUQjOM=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.make_Index_Filename(tempyn=IAtuByiJKwTSWFXPnpgkCELbHUQjcN)
  if xbmcvfs.exists(IAtuByiJKwTSWFXPnpgkCELbHUQjOM):
   IAtuByiJKwTSWFXPnpgkCELbHUQjOR=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.jsonfile_To_dic(IAtuByiJKwTSWFXPnpgkCELbHUQjOM)
  else:
   IAtuByiJKwTSWFXPnpgkCELbHUQjOR=[]
  for IAtuByiJKwTSWFXPnpgkCELbHUQjOz in IAtuByiJKwTSWFXPnpgkCELbHUQjOR:
   IAtuByiJKwTSWFXPnpgkCELbHUQjOr =IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('genre')
   if IAtuByiJKwTSWFXPnpgkCELbHUQjOr not in IAtuByiJKwTSWFXPnpgkCELbHUQjOo:
    IAtuByiJKwTSWFXPnpgkCELbHUQjOo.append(IAtuByiJKwTSWFXPnpgkCELbHUQjOr)
  for IAtuByiJKwTSWFXPnpgkCELbHUQjOr in IAtuByiJKwTSWFXPnpgkCELbHUQjOo:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYl={'mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','genre':IAtuByiJKwTSWFXPnpgkCELbHUQjOr,'page':'1',}
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.add_dir(IAtuByiJKwTSWFXPnpgkCELbHUQjOr,sublabel='',ott='',img='',infoLabels=IAtuByiJKwTSWFXPnpgkCELbHUQjcm,isFolder=IAtuByiJKwTSWFXPnpgkCELbHUQjcD,params=IAtuByiJKwTSWFXPnpgkCELbHUQjYl)
  xbmcplugin.endOfDirectory(IAtuByiJKwTSWFXPnpgkCELbHUQjYm._addon_handle)
 def dp_Bookmark_Grouplist(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,args):
  IAtuByiJKwTSWFXPnpgkCELbHUQjOd =IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  IAtuByiJKwTSWFXPnpgkCELbHUQjOq =[]
  IAtuByiJKwTSWFXPnpgkCELbHUQjOe =args.get('ott')
  IAtuByiJKwTSWFXPnpgkCELbHUQjOa=args.get('vidtype')
  IAtuByiJKwTSWFXPnpgkCELbHUQjOV =args.get('genre')
  if IAtuByiJKwTSWFXPnpgkCELbHUQjOV==IAtuByiJKwTSWFXPnpgkCELbHUQjcm:IAtuByiJKwTSWFXPnpgkCELbHUQjOV='all'
  IAtuByiJKwTSWFXPnpgkCELbHUQjOf =IAtuByiJKwTSWFXPnpgkCELbHUQjcR(args.get('page'))
  IAtuByiJKwTSWFXPnpgkCELbHUQjOl =IAtuByiJKwTSWFXPnpgkCELbHUQjYm.LIST_LIMIT*(IAtuByiJKwTSWFXPnpgkCELbHUQjOf-1)+1 
  IAtuByiJKwTSWFXPnpgkCELbHUQjOG =IAtuByiJKwTSWFXPnpgkCELbHUQjYm.LIST_LIMIT*IAtuByiJKwTSWFXPnpgkCELbHUQjOf
  IAtuByiJKwTSWFXPnpgkCELbHUQjOM=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.make_Index_Filename(tempyn=IAtuByiJKwTSWFXPnpgkCELbHUQjcN)
  if xbmcvfs.exists(IAtuByiJKwTSWFXPnpgkCELbHUQjOM):
   IAtuByiJKwTSWFXPnpgkCELbHUQjOR=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.jsonfile_To_dic(IAtuByiJKwTSWFXPnpgkCELbHUQjOM)
  else:
   IAtuByiJKwTSWFXPnpgkCELbHUQjOR=[]
  IAtuByiJKwTSWFXPnpgkCELbHUQjOh=0
  for IAtuByiJKwTSWFXPnpgkCELbHUQjOz in IAtuByiJKwTSWFXPnpgkCELbHUQjOR:
   IAtuByiJKwTSWFXPnpgkCELbHUQjvY =IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('ott')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvO =IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('videoid')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvm =IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('vidtype')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvc =IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('genre')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvD =IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('linkUrl')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvN =IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('encodedId')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvx =IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('contentId')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvs=IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('contentClass')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvo=IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('contentSlugs')
   if not(IAtuByiJKwTSWFXPnpgkCELbHUQjOe=='-' or IAtuByiJKwTSWFXPnpgkCELbHUQjOe==IAtuByiJKwTSWFXPnpgkCELbHUQjvY):continue
   if not(IAtuByiJKwTSWFXPnpgkCELbHUQjOa=='-' or IAtuByiJKwTSWFXPnpgkCELbHUQjOa==IAtuByiJKwTSWFXPnpgkCELbHUQjvm):continue
   if not(IAtuByiJKwTSWFXPnpgkCELbHUQjOV=='all' or IAtuByiJKwTSWFXPnpgkCELbHUQjOV==IAtuByiJKwTSWFXPnpgkCELbHUQjvc):continue
   IAtuByiJKwTSWFXPnpgkCELbHUQjOh+=1
   if IAtuByiJKwTSWFXPnpgkCELbHUQjOl>IAtuByiJKwTSWFXPnpgkCELbHUQjOh:continue
   if IAtuByiJKwTSWFXPnpgkCELbHUQjOG<IAtuByiJKwTSWFXPnpgkCELbHUQjOh:
    IAtuByiJKwTSWFXPnpgkCELbHUQjOd=IAtuByiJKwTSWFXPnpgkCELbHUQjcD
    break
   IAtuByiJKwTSWFXPnpgkCELbHUQjvM=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.make_Vinfo_Filename(IAtuByiJKwTSWFXPnpgkCELbHUQjvY,IAtuByiJKwTSWFXPnpgkCELbHUQjvO,tempyn=IAtuByiJKwTSWFXPnpgkCELbHUQjcN)
   if xbmcvfs.exists(IAtuByiJKwTSWFXPnpgkCELbHUQjvM):
    IAtuByiJKwTSWFXPnpgkCELbHUQjvR=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.jsonfile_To_dic(IAtuByiJKwTSWFXPnpgkCELbHUQjvM)
    IAtuByiJKwTSWFXPnpgkCELbHUQjYh =IAtuByiJKwTSWFXPnpgkCELbHUQjvR.get('title')
    IAtuByiJKwTSWFXPnpgkCELbHUQjvz =IAtuByiJKwTSWFXPnpgkCELbHUQjvR.get('subtitle')
    IAtuByiJKwTSWFXPnpgkCELbHUQjvr =IAtuByiJKwTSWFXPnpgkCELbHUQjvR.get('thumbnail')
    IAtuByiJKwTSWFXPnpgkCELbHUQjOm=IAtuByiJKwTSWFXPnpgkCELbHUQjvR.get('infoLabels')
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjYh =IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('title')
    IAtuByiJKwTSWFXPnpgkCELbHUQjvz =''
    IAtuByiJKwTSWFXPnpgkCELbHUQjvr =''
    IAtuByiJKwTSWFXPnpgkCELbHUQjOm={'mpaa':'0'}
    IAtuByiJKwTSWFXPnpgkCELbHUQjvR ={'infoLabels':{'title':IAtuByiJKwTSWFXPnpgkCELbHUQjYh}}
   IAtuByiJKwTSWFXPnpgkCELbHUQjYl={'ott':IAtuByiJKwTSWFXPnpgkCELbHUQjvY,'videoid':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'vidtype':IAtuByiJKwTSWFXPnpgkCELbHUQjvm,'title':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'thumbnail':IAtuByiJKwTSWFXPnpgkCELbHUQjvr,'mpaa':IAtuByiJKwTSWFXPnpgkCELbHUQjcz(IAtuByiJKwTSWFXPnpgkCELbHUQjOm.get('mpaa')),'duration':IAtuByiJKwTSWFXPnpgkCELbHUQjcz(IAtuByiJKwTSWFXPnpgkCELbHUQjOm.get('duration')),'linkUrl':IAtuByiJKwTSWFXPnpgkCELbHUQjvD,'infoLabels':IAtuByiJKwTSWFXPnpgkCELbHUQjOm,'encodedId':IAtuByiJKwTSWFXPnpgkCELbHUQjvN,'contentId':IAtuByiJKwTSWFXPnpgkCELbHUQjvx,'contentClass':IAtuByiJKwTSWFXPnpgkCELbHUQjvs,'contentSlugs':IAtuByiJKwTSWFXPnpgkCELbHUQjvo,}
   IAtuByiJKwTSWFXPnpgkCELbHUQjvd={'mode':'BOOKMARK_REMOVE','list':[IAtuByiJKwTSWFXPnpgkCELbHUQjOz],}
   IAtuByiJKwTSWFXPnpgkCELbHUQjvq=urllib.parse.urlencode(IAtuByiJKwTSWFXPnpgkCELbHUQjvd)
   IAtuByiJKwTSWFXPnpgkCELbHUQjve=[('찜 목록 ( %s ) 삭제'%(IAtuByiJKwTSWFXPnpgkCELbHUQjvR.get('infoLabels').get('title')),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(IAtuByiJKwTSWFXPnpgkCELbHUQjvq))]
   if IAtuByiJKwTSWFXPnpgkCELbHUQjOV!='all':
    IAtuByiJKwTSWFXPnpgkCELbHUQjvd={'mode':'GENRE_RENAME','list':[IAtuByiJKwTSWFXPnpgkCELbHUQjOz],}
    IAtuByiJKwTSWFXPnpgkCELbHUQjvq=urllib.parse.urlencode(IAtuByiJKwTSWFXPnpgkCELbHUQjvd)
    IAtuByiJKwTSWFXPnpgkCELbHUQjve.append(('장르명 ( %s ) 수정'%(IAtuByiJKwTSWFXPnpgkCELbHUQjOV),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(IAtuByiJKwTSWFXPnpgkCELbHUQjvq)))
   IAtuByiJKwTSWFXPnpgkCELbHUQjva=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.make_Hyper_Link(IAtuByiJKwTSWFXPnpgkCELbHUQjYl)
   if IAtuByiJKwTSWFXPnpgkCELbHUQjvm=='tvshow':
    IAtuByiJKwTSWFXPnpgkCELbHUQjON=IAtuByiJKwTSWFXPnpgkCELbHUQjcD
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjON=IAtuByiJKwTSWFXPnpgkCELbHUQjcN
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.add_dir(IAtuByiJKwTSWFXPnpgkCELbHUQjYh,sublabel=IAtuByiJKwTSWFXPnpgkCELbHUQjvz,ott=IAtuByiJKwTSWFXPnpgkCELbHUQjvY,img=IAtuByiJKwTSWFXPnpgkCELbHUQjvr,infoLabels=IAtuByiJKwTSWFXPnpgkCELbHUQjOm,isFolder=IAtuByiJKwTSWFXPnpgkCELbHUQjON,params=IAtuByiJKwTSWFXPnpgkCELbHUQjcm,isLink=IAtuByiJKwTSWFXPnpgkCELbHUQjcN,ContextMenu=IAtuByiJKwTSWFXPnpgkCELbHUQjve,direct_url=IAtuByiJKwTSWFXPnpgkCELbHUQjva)
   IAtuByiJKwTSWFXPnpgkCELbHUQjOq.append(IAtuByiJKwTSWFXPnpgkCELbHUQjOz)
  IAtuByiJKwTSWFXPnpgkCELbHUQjvV={'plot':'현재페이지의 전체목록을 삭제합니다.'}
  IAtuByiJKwTSWFXPnpgkCELbHUQjYh='* 현재페이지 목록 삭제 (개별삭제는 팝업메뉴) *'
  IAtuByiJKwTSWFXPnpgkCELbHUQjYl={'mode':'BOOKMARK_REMOVE','list':IAtuByiJKwTSWFXPnpgkCELbHUQjOq,}
  IAtuByiJKwTSWFXPnpgkCELbHUQjOD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  IAtuByiJKwTSWFXPnpgkCELbHUQjYm.add_dir(IAtuByiJKwTSWFXPnpgkCELbHUQjYh,sublabel='',ott='',img=IAtuByiJKwTSWFXPnpgkCELbHUQjOD,infoLabels=IAtuByiJKwTSWFXPnpgkCELbHUQjvV,isFolder=IAtuByiJKwTSWFXPnpgkCELbHUQjcN,params=IAtuByiJKwTSWFXPnpgkCELbHUQjYl,isLink=IAtuByiJKwTSWFXPnpgkCELbHUQjcD)
  if IAtuByiJKwTSWFXPnpgkCELbHUQjOd:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYl={'mode':'BOOKMARK_GROUP','ott':IAtuByiJKwTSWFXPnpgkCELbHUQjOe,'vidtype':IAtuByiJKwTSWFXPnpgkCELbHUQjOa,'page':IAtuByiJKwTSWFXPnpgkCELbHUQjcz(IAtuByiJKwTSWFXPnpgkCELbHUQjOf+1)}
   IAtuByiJKwTSWFXPnpgkCELbHUQjYh='[B]%s >>[/B]'%'다음 페이지'
   IAtuByiJKwTSWFXPnpgkCELbHUQjvz=IAtuByiJKwTSWFXPnpgkCELbHUQjcz(IAtuByiJKwTSWFXPnpgkCELbHUQjOf+1)
   IAtuByiJKwTSWFXPnpgkCELbHUQjOD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.add_dir(IAtuByiJKwTSWFXPnpgkCELbHUQjYh,sublabel=IAtuByiJKwTSWFXPnpgkCELbHUQjvz,ott='',img=IAtuByiJKwTSWFXPnpgkCELbHUQjOD,infoLabels=IAtuByiJKwTSWFXPnpgkCELbHUQjcm,isFolder=IAtuByiJKwTSWFXPnpgkCELbHUQjcD,params=IAtuByiJKwTSWFXPnpgkCELbHUQjYl)
  xbmcplugin.setContent(IAtuByiJKwTSWFXPnpgkCELbHUQjYm._addon_handle,'movies')
  xbmcplugin.endOfDirectory(IAtuByiJKwTSWFXPnpgkCELbHUQjYm._addon_handle)
 def get_keyboard_input(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,defalut,IAtuByiJKwTSWFXPnpgkCELbHUQjYh):
  IAtuByiJKwTSWFXPnpgkCELbHUQjvf=IAtuByiJKwTSWFXPnpgkCELbHUQjcm
  kb=xbmc.Keyboard(defalut,IAtuByiJKwTSWFXPnpgkCELbHUQjYh,IAtuByiJKwTSWFXPnpgkCELbHUQjcN)
  kb.setHeading(IAtuByiJKwTSWFXPnpgkCELbHUQjYh)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   IAtuByiJKwTSWFXPnpgkCELbHUQjvf=kb.getText()
  return IAtuByiJKwTSWFXPnpgkCELbHUQjvf
 def dp_Genre_Rename(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,args):
  IAtuByiJKwTSWFXPnpgkCELbHUQjvl =IAtuByiJKwTSWFXPnpgkCELbHUQjcD
  IAtuByiJKwTSWFXPnpgkCELbHUQjvG ={}
  try:
   IAtuByiJKwTSWFXPnpgkCELbHUQjvh=args.get('list')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvh=IAtuByiJKwTSWFXPnpgkCELbHUQjvh.replace('\'','\"')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvh=json.loads(IAtuByiJKwTSWFXPnpgkCELbHUQjvh)
  except:
   IAtuByiJKwTSWFXPnpgkCELbHUQjvl=IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   if IAtuByiJKwTSWFXPnpgkCELbHUQjcM(IAtuByiJKwTSWFXPnpgkCELbHUQjvh)!=0:
    IAtuByiJKwTSWFXPnpgkCELbHUQjmY=IAtuByiJKwTSWFXPnpgkCELbHUQjvh[0].get('genre')
   else:
    return
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjmO=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.get_keyboard_input(IAtuByiJKwTSWFXPnpgkCELbHUQjmY,__language__(30909).encode('utf-8'))
   if IAtuByiJKwTSWFXPnpgkCELbHUQjmO!=IAtuByiJKwTSWFXPnpgkCELbHUQjcm:
    IAtuByiJKwTSWFXPnpgkCELbHUQjmO=IAtuByiJKwTSWFXPnpgkCELbHUQjmO.strip()
   else:
    return
   if IAtuByiJKwTSWFXPnpgkCELbHUQjmY==IAtuByiJKwTSWFXPnpgkCELbHUQjmO:
    IAtuByiJKwTSWFXPnpgkCELbHUQjYm.addon_noti(__language__(30910).encode('utf-8'))
    return
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   for IAtuByiJKwTSWFXPnpgkCELbHUQjmv in IAtuByiJKwTSWFXPnpgkCELbHUQjvh:
    if IAtuByiJKwTSWFXPnpgkCELbHUQjmv['ott']in IAtuByiJKwTSWFXPnpgkCELbHUQjvG:
     IAtuByiJKwTSWFXPnpgkCELbHUQjvG[IAtuByiJKwTSWFXPnpgkCELbHUQjmv['ott']].append(IAtuByiJKwTSWFXPnpgkCELbHUQjmv['videoid'])
    else:
     IAtuByiJKwTSWFXPnpgkCELbHUQjvG[IAtuByiJKwTSWFXPnpgkCELbHUQjmv['ott']]=[IAtuByiJKwTSWFXPnpgkCELbHUQjmv['videoid']]
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjOM=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.make_Index_Filename(tempyn=IAtuByiJKwTSWFXPnpgkCELbHUQjcN)
   if xbmcvfs.exists(IAtuByiJKwTSWFXPnpgkCELbHUQjOM):
    IAtuByiJKwTSWFXPnpgkCELbHUQjOR=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.jsonfile_To_dic(IAtuByiJKwTSWFXPnpgkCELbHUQjOM)
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   for i in IAtuByiJKwTSWFXPnpgkCELbHUQjcr(IAtuByiJKwTSWFXPnpgkCELbHUQjcM(IAtuByiJKwTSWFXPnpgkCELbHUQjOR)):
    IAtuByiJKwTSWFXPnpgkCELbHUQjmc =IAtuByiJKwTSWFXPnpgkCELbHUQjOR[i].get('ott')
    IAtuByiJKwTSWFXPnpgkCELbHUQjmD=IAtuByiJKwTSWFXPnpgkCELbHUQjOR[i].get('videoid')
    if IAtuByiJKwTSWFXPnpgkCELbHUQjmc in IAtuByiJKwTSWFXPnpgkCELbHUQjvG:
     if IAtuByiJKwTSWFXPnpgkCELbHUQjmD in IAtuByiJKwTSWFXPnpgkCELbHUQjvG[IAtuByiJKwTSWFXPnpgkCELbHUQjmc]:
      IAtuByiJKwTSWFXPnpgkCELbHUQjOR[i]['genre']=IAtuByiJKwTSWFXPnpgkCELbHUQjmO
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjvl=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.dic_To_jsonfile(IAtuByiJKwTSWFXPnpgkCELbHUQjOM,IAtuByiJKwTSWFXPnpgkCELbHUQjOR)
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.addon_noti(__language__(30911).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.addon_noti(__language__(30912).encode('utf-8'))
 def dp_Bookmark_Remove(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,args):
  IAtuByiJKwTSWFXPnpgkCELbHUQjvl =IAtuByiJKwTSWFXPnpgkCELbHUQjcD
  IAtuByiJKwTSWFXPnpgkCELbHUQjmN ={}
  IAtuByiJKwTSWFXPnpgkCELbHUQjYs=xbmcgui.Dialog()
  IAtuByiJKwTSWFXPnpgkCELbHUQjmx=IAtuByiJKwTSWFXPnpgkCELbHUQjYs.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if IAtuByiJKwTSWFXPnpgkCELbHUQjmx==IAtuByiJKwTSWFXPnpgkCELbHUQjcN:sys.exit()
  try:
   IAtuByiJKwTSWFXPnpgkCELbHUQjvh=args.get('list')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvh=IAtuByiJKwTSWFXPnpgkCELbHUQjvh.replace('\'','\"')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvh=json.loads(IAtuByiJKwTSWFXPnpgkCELbHUQjvh)
  except:
   IAtuByiJKwTSWFXPnpgkCELbHUQjvl=IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   for IAtuByiJKwTSWFXPnpgkCELbHUQjmv in IAtuByiJKwTSWFXPnpgkCELbHUQjvh:
    if IAtuByiJKwTSWFXPnpgkCELbHUQjmv['ott']in IAtuByiJKwTSWFXPnpgkCELbHUQjmN:
     IAtuByiJKwTSWFXPnpgkCELbHUQjmN[IAtuByiJKwTSWFXPnpgkCELbHUQjmv['ott']].append(IAtuByiJKwTSWFXPnpgkCELbHUQjmv['videoid'])
    else:
     IAtuByiJKwTSWFXPnpgkCELbHUQjmN[IAtuByiJKwTSWFXPnpgkCELbHUQjmv['ott']]=[IAtuByiJKwTSWFXPnpgkCELbHUQjmv['videoid']]
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjOM=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.make_Index_Filename(tempyn=IAtuByiJKwTSWFXPnpgkCELbHUQjcN)
   if xbmcvfs.exists(IAtuByiJKwTSWFXPnpgkCELbHUQjOM):
    IAtuByiJKwTSWFXPnpgkCELbHUQjOR=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.jsonfile_To_dic(IAtuByiJKwTSWFXPnpgkCELbHUQjOM)
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjOz=[]
   for IAtuByiJKwTSWFXPnpgkCELbHUQjms in IAtuByiJKwTSWFXPnpgkCELbHUQjOR:
    IAtuByiJKwTSWFXPnpgkCELbHUQjmc =IAtuByiJKwTSWFXPnpgkCELbHUQjms.get('ott')
    IAtuByiJKwTSWFXPnpgkCELbHUQjmD=IAtuByiJKwTSWFXPnpgkCELbHUQjms.get('videoid')
    if IAtuByiJKwTSWFXPnpgkCELbHUQjmc in IAtuByiJKwTSWFXPnpgkCELbHUQjmN:
     if IAtuByiJKwTSWFXPnpgkCELbHUQjmD in IAtuByiJKwTSWFXPnpgkCELbHUQjmN[IAtuByiJKwTSWFXPnpgkCELbHUQjmc]:
      IAtuByiJKwTSWFXPnpgkCELbHUQjvM=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.make_Vinfo_Filename(IAtuByiJKwTSWFXPnpgkCELbHUQjmc,IAtuByiJKwTSWFXPnpgkCELbHUQjmD,tempyn=IAtuByiJKwTSWFXPnpgkCELbHUQjcN)
      xbmcvfs.delete(IAtuByiJKwTSWFXPnpgkCELbHUQjvM)
      continue
    IAtuByiJKwTSWFXPnpgkCELbHUQjOz.append(IAtuByiJKwTSWFXPnpgkCELbHUQjms)
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjcm
   IAtuByiJKwTSWFXPnpgkCELbHUQjvl=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.dic_To_jsonfile(IAtuByiJKwTSWFXPnpgkCELbHUQjOM,IAtuByiJKwTSWFXPnpgkCELbHUQjOz)
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.addon_noti(__language__(30908).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.addon_noti(__language__(30907).encode('utf-8'))
 def make_Hyper_Link(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,args):
  IAtuByiJKwTSWFXPnpgkCELbHUQjva=''
  IAtuByiJKwTSWFXPnpgkCELbHUQjvY =args.get('ott')
  IAtuByiJKwTSWFXPnpgkCELbHUQjvO =args.get('videoid')
  IAtuByiJKwTSWFXPnpgkCELbHUQjvm =args.get('vidtype')
  IAtuByiJKwTSWFXPnpgkCELbHUQjYh =args.get('title')
  IAtuByiJKwTSWFXPnpgkCELbHUQjvr =args.get('thumbnail')
  IAtuByiJKwTSWFXPnpgkCELbHUQjmo =args.get('mpaa')
  IAtuByiJKwTSWFXPnpgkCELbHUQjvD =args.get('linkUrl')
  IAtuByiJKwTSWFXPnpgkCELbHUQjmM =args.get('duration')
  IAtuByiJKwTSWFXPnpgkCELbHUQjOm=args.get('infoLabels')
  IAtuByiJKwTSWFXPnpgkCELbHUQjvN =args.get('encodedId')
  IAtuByiJKwTSWFXPnpgkCELbHUQjvx =args.get('contentId')
  IAtuByiJKwTSWFXPnpgkCELbHUQjvs=args.get('contentClass')
  IAtuByiJKwTSWFXPnpgkCELbHUQjvo=args.get('contentSlugs')
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvY=='wavve':
   if IAtuByiJKwTSWFXPnpgkCELbHUQjvm=='tvshow':
    IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'EPISODE_LIST','videoid':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'vidtype':IAtuByiJKwTSWFXPnpgkCELbHUQjvm,'page':'1',}
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'MOVIE','contentid':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'title':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'thumbnail':IAtuByiJKwTSWFXPnpgkCELbHUQjvr,'age':IAtuByiJKwTSWFXPnpgkCELbHUQjmo,}
   IAtuByiJKwTSWFXPnpgkCELbHUQjmz=urllib.parse.urlencode(IAtuByiJKwTSWFXPnpgkCELbHUQjmR)
   IAtuByiJKwTSWFXPnpgkCELbHUQjva='plugin://plugin.video.wavvem/?'
   IAtuByiJKwTSWFXPnpgkCELbHUQjva+=IAtuByiJKwTSWFXPnpgkCELbHUQjmz
  elif IAtuByiJKwTSWFXPnpgkCELbHUQjvY=='tving':
   if IAtuByiJKwTSWFXPnpgkCELbHUQjvm=='tvshow':
    IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'EPISODE','programcode':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'page':'1',}
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'MOVIE','stype':'movie','mediacode':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'title':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'thumbnail':IAtuByiJKwTSWFXPnpgkCELbHUQjvr,}
   IAtuByiJKwTSWFXPnpgkCELbHUQjmz=urllib.parse.urlencode(IAtuByiJKwTSWFXPnpgkCELbHUQjmR)
   IAtuByiJKwTSWFXPnpgkCELbHUQjva='plugin://plugin.video.tvingm/?'
   IAtuByiJKwTSWFXPnpgkCELbHUQjva+=IAtuByiJKwTSWFXPnpgkCELbHUQjmz
  elif IAtuByiJKwTSWFXPnpgkCELbHUQjvY=='watcha':
   if IAtuByiJKwTSWFXPnpgkCELbHUQjvm=='tvshow':
    IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'EPISODE','movie_code':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'season_code':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'page':'1',}
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'MOVIE','movie_code':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'season_code':'-','title':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'thumbnail':IAtuByiJKwTSWFXPnpgkCELbHUQjvr,}
   IAtuByiJKwTSWFXPnpgkCELbHUQjmz=urllib.parse.urlencode(IAtuByiJKwTSWFXPnpgkCELbHUQjmR)
   IAtuByiJKwTSWFXPnpgkCELbHUQjva='plugin://plugin.video.watcham/?'
   IAtuByiJKwTSWFXPnpgkCELbHUQjva+=IAtuByiJKwTSWFXPnpgkCELbHUQjmz
  elif IAtuByiJKwTSWFXPnpgkCELbHUQjvY=='coupang':
   if IAtuByiJKwTSWFXPnpgkCELbHUQjvm=='tvshow':
    IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'SEASON_LIST','id':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'asis':'TVSHOW','title':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'thumbnail':IAtuByiJKwTSWFXPnpgkCELbHUQjvr,'page':'1',}
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'MOVIE','id':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'asis':'MOVIE','title':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'thumbnail':IAtuByiJKwTSWFXPnpgkCELbHUQjvr,}
   IAtuByiJKwTSWFXPnpgkCELbHUQjmz=urllib.parse.urlencode(IAtuByiJKwTSWFXPnpgkCELbHUQjmR)
   IAtuByiJKwTSWFXPnpgkCELbHUQjva='plugin://plugin.video.coupangm/?'
   IAtuByiJKwTSWFXPnpgkCELbHUQjva+=IAtuByiJKwTSWFXPnpgkCELbHUQjmz
  elif IAtuByiJKwTSWFXPnpgkCELbHUQjvY=='netflix':
   if IAtuByiJKwTSWFXPnpgkCELbHUQjvm=='tvshow':
    IAtuByiJKwTSWFXPnpgkCELbHUQjva='plugin://plugin.video.netflix/directory/show/%s/'%(IAtuByiJKwTSWFXPnpgkCELbHUQjvO)
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjva='plugin://plugin.video.netflix/play/movie/%s/'%(IAtuByiJKwTSWFXPnpgkCELbHUQjvO)
  elif IAtuByiJKwTSWFXPnpgkCELbHUQjvY=='amazon':
   if IAtuByiJKwTSWFXPnpgkCELbHUQjvm=='tvshow':
    IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'SEASON_LIST','values':{'titleID':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'linkUrl':IAtuByiJKwTSWFXPnpgkCELbHUQjvD,'duration':IAtuByiJKwTSWFXPnpgkCELbHUQjmM,'vType':IAtuByiJKwTSWFXPnpgkCELbHUQjvm,'image':IAtuByiJKwTSWFXPnpgkCELbHUQjvr,'title':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'infoLabels':IAtuByiJKwTSWFXPnpgkCELbHUQjOm,}}
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'MOVIE','values':{'titleID':IAtuByiJKwTSWFXPnpgkCELbHUQjvO,'linkUrl':IAtuByiJKwTSWFXPnpgkCELbHUQjvD,'duration':IAtuByiJKwTSWFXPnpgkCELbHUQjmM,'vType':IAtuByiJKwTSWFXPnpgkCELbHUQjvm,'image':IAtuByiJKwTSWFXPnpgkCELbHUQjvr,'title':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'infoLabels':IAtuByiJKwTSWFXPnpgkCELbHUQjOm,}}
   IAtuByiJKwTSWFXPnpgkCELbHUQjmz=json.dumps(IAtuByiJKwTSWFXPnpgkCELbHUQjmR,separators=(',',':'))
   IAtuByiJKwTSWFXPnpgkCELbHUQjmz=base64.standard_b64encode(IAtuByiJKwTSWFXPnpgkCELbHUQjmz.encode()).decode('utf-8')
   IAtuByiJKwTSWFXPnpgkCELbHUQjmz=IAtuByiJKwTSWFXPnpgkCELbHUQjmz.replace('+','%2B')
   IAtuByiJKwTSWFXPnpgkCELbHUQjva='plugin://plugin.video.primevm/?params='
   IAtuByiJKwTSWFXPnpgkCELbHUQjva+=IAtuByiJKwTSWFXPnpgkCELbHUQjmz
  elif IAtuByiJKwTSWFXPnpgkCELbHUQjvY=='disney':
   if IAtuByiJKwTSWFXPnpgkCELbHUQjvm=='tvshow':
    if IAtuByiJKwTSWFXPnpgkCELbHUQjvN:
     IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'SEASON_LIST','values':{'encodedId':IAtuByiJKwTSWFXPnpgkCELbHUQjvN,'vType':IAtuByiJKwTSWFXPnpgkCELbHUQjvm,'image':IAtuByiJKwTSWFXPnpgkCELbHUQjvr,'title':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'programTitle':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'infoLabels':IAtuByiJKwTSWFXPnpgkCELbHUQjOm,}}
    else:
     IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'PROGRAM_LIST','values':{'contentClass':IAtuByiJKwTSWFXPnpgkCELbHUQjvs,'contentSlugs':IAtuByiJKwTSWFXPnpgkCELbHUQjvo,'vType':IAtuByiJKwTSWFXPnpgkCELbHUQjvm,'image':IAtuByiJKwTSWFXPnpgkCELbHUQjvr,'title':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'programTitle':IAtuByiJKwTSWFXPnpgkCELbHUQjYh,'infoLabels':IAtuByiJKwTSWFXPnpgkCELbHUQjOm,}}
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjmR={'mode':'MOVIE','values':{'contentId':IAtuByiJKwTSWFXPnpgkCELbHUQjvx,'vType':IAtuByiJKwTSWFXPnpgkCELbHUQjvm,'image':IAtuByiJKwTSWFXPnpgkCELbHUQjvr,'title':IAtuByiJKwTSWFXPnpgkCELbHUQjOm['title'],'programTitle':IAtuByiJKwTSWFXPnpgkCELbHUQjOm['title'],'infoLabels':IAtuByiJKwTSWFXPnpgkCELbHUQjOm,}}
   IAtuByiJKwTSWFXPnpgkCELbHUQjmz=json.dumps(IAtuByiJKwTSWFXPnpgkCELbHUQjmR,separators=(',',':'))
   IAtuByiJKwTSWFXPnpgkCELbHUQjmz=base64.standard_b64encode(IAtuByiJKwTSWFXPnpgkCELbHUQjmz.encode()).decode('utf-8')
   IAtuByiJKwTSWFXPnpgkCELbHUQjmz=IAtuByiJKwTSWFXPnpgkCELbHUQjmz.replace('+','%2B')
   IAtuByiJKwTSWFXPnpgkCELbHUQjva='plugin://plugin.video.disneym/?params='
   IAtuByiJKwTSWFXPnpgkCELbHUQjva+=IAtuByiJKwTSWFXPnpgkCELbHUQjmz
  return IAtuByiJKwTSWFXPnpgkCELbHUQjva
 def dp_Set_Bookmark(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,args):
  IAtuByiJKwTSWFXPnpgkCELbHUQjvl =IAtuByiJKwTSWFXPnpgkCELbHUQjcD
  IAtuByiJKwTSWFXPnpgkCELbHUQjOR=[]
  IAtuByiJKwTSWFXPnpgkCELbHUQjmr=args.get('VIDEO_INFO')
  if IAtuByiJKwTSWFXPnpgkCELbHUQjmr:
   IAtuByiJKwTSWFXPnpgkCELbHUQjOz=IAtuByiJKwTSWFXPnpgkCELbHUQjmr.get('indexinfo')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvR =IAtuByiJKwTSWFXPnpgkCELbHUQjmr.get('saveinfo')
  else:
   IAtuByiJKwTSWFXPnpgkCELbHUQjmd =urllib.parse.unquote(args.get('bm_param'))
   IAtuByiJKwTSWFXPnpgkCELbHUQjmd =json.loads(IAtuByiJKwTSWFXPnpgkCELbHUQjmd)
   IAtuByiJKwTSWFXPnpgkCELbHUQjOz=IAtuByiJKwTSWFXPnpgkCELbHUQjmd.get('indexinfo')
   IAtuByiJKwTSWFXPnpgkCELbHUQjvR =IAtuByiJKwTSWFXPnpgkCELbHUQjmd.get('saveinfo')
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjvM=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.make_Vinfo_Filename(IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('ott'),IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('videoid'),tempyn=IAtuByiJKwTSWFXPnpgkCELbHUQjcN)
   IAtuByiJKwTSWFXPnpgkCELbHUQjvl=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.dic_To_jsonfile(IAtuByiJKwTSWFXPnpgkCELbHUQjvM,IAtuByiJKwTSWFXPnpgkCELbHUQjvR)
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjOM=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.make_Index_Filename(tempyn=IAtuByiJKwTSWFXPnpgkCELbHUQjcN)
   if xbmcvfs.exists(IAtuByiJKwTSWFXPnpgkCELbHUQjOM):
    IAtuByiJKwTSWFXPnpgkCELbHUQjOR=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.jsonfile_To_dic(IAtuByiJKwTSWFXPnpgkCELbHUQjOM)
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjOR=[]
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjmq =IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('ott')
   IAtuByiJKwTSWFXPnpgkCELbHUQjme =IAtuByiJKwTSWFXPnpgkCELbHUQjOz.get('videoid')
   for i in IAtuByiJKwTSWFXPnpgkCELbHUQjcr(IAtuByiJKwTSWFXPnpgkCELbHUQjcM(IAtuByiJKwTSWFXPnpgkCELbHUQjOR)):
    IAtuByiJKwTSWFXPnpgkCELbHUQjmc =IAtuByiJKwTSWFXPnpgkCELbHUQjOR[i].get('ott')
    IAtuByiJKwTSWFXPnpgkCELbHUQjmD=IAtuByiJKwTSWFXPnpgkCELbHUQjOR[i].get('videoid')
    if IAtuByiJKwTSWFXPnpgkCELbHUQjmq==IAtuByiJKwTSWFXPnpgkCELbHUQjmc and IAtuByiJKwTSWFXPnpgkCELbHUQjme==IAtuByiJKwTSWFXPnpgkCELbHUQjmD:
     IAtuByiJKwTSWFXPnpgkCELbHUQjOR.pop(i)
     break
   IAtuByiJKwTSWFXPnpgkCELbHUQjOz['title']=IAtuByiJKwTSWFXPnpgkCELbHUQjvR.get('title')
   if IAtuByiJKwTSWFXPnpgkCELbHUQjcM(IAtuByiJKwTSWFXPnpgkCELbHUQjvR.get('infoLabels').get('genre'))>0:
    IAtuByiJKwTSWFXPnpgkCELbHUQjOz['genre']=IAtuByiJKwTSWFXPnpgkCELbHUQjvR.get('infoLabels').get('genre')[0]
   else:
    IAtuByiJKwTSWFXPnpgkCELbHUQjOz['genre']='-'
   IAtuByiJKwTSWFXPnpgkCELbHUQjOR.insert(0,IAtuByiJKwTSWFXPnpgkCELbHUQjOz)
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjvl=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.dic_To_jsonfile(IAtuByiJKwTSWFXPnpgkCELbHUQjOM,IAtuByiJKwTSWFXPnpgkCELbHUQjOR)
  if IAtuByiJKwTSWFXPnpgkCELbHUQjvl==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.addon_noti(__language__(30903).encode('utf8'))
  else:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(IAtuByiJKwTSWFXPnpgkCELbHUQjYm):
  IAtuByiJKwTSWFXPnpgkCELbHUQjma=IAtuByiJKwTSWFXPnpgkCELbHUQjcD
  IAtuByiJKwTSWFXPnpgkCELbHUQjYm.LIB_PATH =(__addon__.getSetting('libpath')).strip()
  if IAtuByiJKwTSWFXPnpgkCELbHUQjYm.LIB_PATH=='':IAtuByiJKwTSWFXPnpgkCELbHUQjma=IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  if IAtuByiJKwTSWFXPnpgkCELbHUQjma==IAtuByiJKwTSWFXPnpgkCELbHUQjcN:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYs=xbmcgui.Dialog()
   IAtuByiJKwTSWFXPnpgkCELbHUQjmx=IAtuByiJKwTSWFXPnpgkCELbHUQjYs.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if IAtuByiJKwTSWFXPnpgkCELbHUQjmx==IAtuByiJKwTSWFXPnpgkCELbHUQjcD:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def dic_To_jsonfile(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,filename,IAtuByiJKwTSWFXPnpgkCELbHUQjmV):
  if filename=='':return IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  try:
   fp=xbmcvfs.File(filename,'w')
   json.dump(IAtuByiJKwTSWFXPnpgkCELbHUQjmV,fp,indent=4,ensure_ascii=IAtuByiJKwTSWFXPnpgkCELbHUQjcN)
   fp.close()
  except:
   return IAtuByiJKwTSWFXPnpgkCELbHUQjcN
  return IAtuByiJKwTSWFXPnpgkCELbHUQjcD
 def jsonfile_To_dic(IAtuByiJKwTSWFXPnpgkCELbHUQjYm,filename):
  if filename=='':return IAtuByiJKwTSWFXPnpgkCELbHUQjcm
  try:
   fp=xbmcvfs.File(filename)
   IAtuByiJKwTSWFXPnpgkCELbHUQjml=json.load(fp)
   fp.close()
  except:
   IAtuByiJKwTSWFXPnpgkCELbHUQjml={}
  return IAtuByiJKwTSWFXPnpgkCELbHUQjml
 def bookmark_main(IAtuByiJKwTSWFXPnpgkCELbHUQjYm):
  IAtuByiJKwTSWFXPnpgkCELbHUQjmG=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.main_params.get('params')
  if IAtuByiJKwTSWFXPnpgkCELbHUQjmG:
   IAtuByiJKwTSWFXPnpgkCELbHUQjmh =base64.standard_b64decode(IAtuByiJKwTSWFXPnpgkCELbHUQjmG).decode('utf-8')
   IAtuByiJKwTSWFXPnpgkCELbHUQjmh =json.loads(IAtuByiJKwTSWFXPnpgkCELbHUQjmh)
   IAtuByiJKwTSWFXPnpgkCELbHUQjcY =IAtuByiJKwTSWFXPnpgkCELbHUQjmh.get('mode')
   IAtuByiJKwTSWFXPnpgkCELbHUQjcO =IAtuByiJKwTSWFXPnpgkCELbHUQjmh.get('values')
  else:
   IAtuByiJKwTSWFXPnpgkCELbHUQjcY=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.main_params.get('mode',IAtuByiJKwTSWFXPnpgkCELbHUQjcm)
   IAtuByiJKwTSWFXPnpgkCELbHUQjcO=IAtuByiJKwTSWFXPnpgkCELbHUQjYm.main_params
  IAtuByiJKwTSWFXPnpgkCELbHUQjYm.option_check()
  if IAtuByiJKwTSWFXPnpgkCELbHUQjcY is IAtuByiJKwTSWFXPnpgkCELbHUQjcm:
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.dp_Main_List()
  elif IAtuByiJKwTSWFXPnpgkCELbHUQjcY=='SET_BOOKMARK':
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.dp_Set_Bookmark(IAtuByiJKwTSWFXPnpgkCELbHUQjcO)
  elif IAtuByiJKwTSWFXPnpgkCELbHUQjcY=='GENRE_GROUP':
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.dp_Genre_Grouplist(IAtuByiJKwTSWFXPnpgkCELbHUQjcO)
  elif IAtuByiJKwTSWFXPnpgkCELbHUQjcY=='BOOKMARK_GROUP':
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.dp_Bookmark_Grouplist(IAtuByiJKwTSWFXPnpgkCELbHUQjcO)
  elif IAtuByiJKwTSWFXPnpgkCELbHUQjcY=='BOOKMARK_REMOVE':
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.dp_Bookmark_Remove(IAtuByiJKwTSWFXPnpgkCELbHUQjcO)
  elif IAtuByiJKwTSWFXPnpgkCELbHUQjcY=='GENRE_RENAME':
   IAtuByiJKwTSWFXPnpgkCELbHUQjYm.dp_Genre_Rename(IAtuByiJKwTSWFXPnpgkCELbHUQjcO)
  else:
   IAtuByiJKwTSWFXPnpgkCELbHUQjcm
# Created by pyminifier (https://github.com/liftoff/pyminifier)
