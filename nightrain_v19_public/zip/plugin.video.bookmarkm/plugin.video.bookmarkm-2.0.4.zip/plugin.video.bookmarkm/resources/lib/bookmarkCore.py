__author__="NightRain"
OvhqacuFbxsMNlyLpgUQewDAVfCRnY=object
OvhqacuFbxsMNlyLpgUQewDAVfCRni=None
OvhqacuFbxsMNlyLpgUQewDAVfCRnH=False
OvhqacuFbxsMNlyLpgUQewDAVfCRnt=open
OvhqacuFbxsMNlyLpgUQewDAVfCRnj=True
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class OvhqacuFbxsMNlyLpgUQewDAVfCRnz(OvhqacuFbxsMNlyLpgUQewDAVfCRnY):
 def __init__(OvhqacuFbxsMNlyLpgUQewDAVfCRno):
  OvhqacuFbxsMNlyLpgUQewDAVfCRno.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  OvhqacuFbxsMNlyLpgUQewDAVfCRno.DEFAULT_HEADER ={'user-agent':OvhqacuFbxsMNlyLpgUQewDAVfCRno.USER_AGENT}
 def callRequestCookies(OvhqacuFbxsMNlyLpgUQewDAVfCRno,jobtype,url,payload=OvhqacuFbxsMNlyLpgUQewDAVfCRni,params=OvhqacuFbxsMNlyLpgUQewDAVfCRni,headers=OvhqacuFbxsMNlyLpgUQewDAVfCRni,cookies=OvhqacuFbxsMNlyLpgUQewDAVfCRni,redirects=OvhqacuFbxsMNlyLpgUQewDAVfCRnH):
  OvhqacuFbxsMNlyLpgUQewDAVfCRnk=OvhqacuFbxsMNlyLpgUQewDAVfCRno.DEFAULT_HEADER
  if headers:OvhqacuFbxsMNlyLpgUQewDAVfCRnk.update(headers)
  if jobtype=='Get':
   OvhqacuFbxsMNlyLpgUQewDAVfCRnm=requests.get(url,params=params,headers=OvhqacuFbxsMNlyLpgUQewDAVfCRnk,cookies=cookies,allow_redirects=redirects)
  else:
   OvhqacuFbxsMNlyLpgUQewDAVfCRnm=requests.post(url,data=payload,params=params,headers=OvhqacuFbxsMNlyLpgUQewDAVfCRnk,cookies=cookies,allow_redirects=redirects)
  return OvhqacuFbxsMNlyLpgUQewDAVfCRnm
 def Get_Now_Datetime(OvhqacuFbxsMNlyLpgUQewDAVfCRno):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def local_dic_To_jsonfile(OvhqacuFbxsMNlyLpgUQewDAVfCRno,filename,dic):
  if filename=='':return OvhqacuFbxsMNlyLpgUQewDAVfCRnH
  try:
   fp=OvhqacuFbxsMNlyLpgUQewDAVfCRnt(filename,'w',-1,'utf-8')
   json.dump(dic,fp)
   fp.close()
  except:
   return OvhqacuFbxsMNlyLpgUQewDAVfCRnH
  return OvhqacuFbxsMNlyLpgUQewDAVfCRnj
 def local_jsonfile_To_dic(OvhqacuFbxsMNlyLpgUQewDAVfCRno,filename):
  if filename=='':return OvhqacuFbxsMNlyLpgUQewDAVfCRni
  try:
   fp=OvhqacuFbxsMNlyLpgUQewDAVfCRnt(filename,'r',-1,'utf-8')
   OvhqacuFbxsMNlyLpgUQewDAVfCRnr=json.load(fp)
   fp.close()
  except:
   OvhqacuFbxsMNlyLpgUQewDAVfCRnr={}
  return OvhqacuFbxsMNlyLpgUQewDAVfCRnr
# Created by pyminifier (https://github.com/liftoff/pyminifier)
