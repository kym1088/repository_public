__author__="NightRain"
rilIDnNwaujXPbHYFgGpLhTtkdEBUf=object
rilIDnNwaujXPbHYFgGpLhTtkdEBUq=None
rilIDnNwaujXPbHYFgGpLhTtkdEBUy=False
rilIDnNwaujXPbHYFgGpLhTtkdEBUx=open
rilIDnNwaujXPbHYFgGpLhTtkdEBUC=True
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class rilIDnNwaujXPbHYFgGpLhTtkdEBUK(rilIDnNwaujXPbHYFgGpLhTtkdEBUf):
 def __init__(rilIDnNwaujXPbHYFgGpLhTtkdEBUQ):
  rilIDnNwaujXPbHYFgGpLhTtkdEBUQ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  rilIDnNwaujXPbHYFgGpLhTtkdEBUQ.DEFAULT_HEADER ={'user-agent':rilIDnNwaujXPbHYFgGpLhTtkdEBUQ.USER_AGENT}
 def callRequestCookies(rilIDnNwaujXPbHYFgGpLhTtkdEBUQ,jobtype,url,payload=rilIDnNwaujXPbHYFgGpLhTtkdEBUq,params=rilIDnNwaujXPbHYFgGpLhTtkdEBUq,headers=rilIDnNwaujXPbHYFgGpLhTtkdEBUq,cookies=rilIDnNwaujXPbHYFgGpLhTtkdEBUq,redirects=rilIDnNwaujXPbHYFgGpLhTtkdEBUy):
  rilIDnNwaujXPbHYFgGpLhTtkdEBUR=rilIDnNwaujXPbHYFgGpLhTtkdEBUQ.DEFAULT_HEADER
  if headers:rilIDnNwaujXPbHYFgGpLhTtkdEBUR.update(headers)
  if jobtype=='Get':
   rilIDnNwaujXPbHYFgGpLhTtkdEBUW=requests.get(url,params=params,headers=rilIDnNwaujXPbHYFgGpLhTtkdEBUR,cookies=cookies,allow_redirects=redirects)
  else:
   rilIDnNwaujXPbHYFgGpLhTtkdEBUW=requests.post(url,data=payload,params=params,headers=rilIDnNwaujXPbHYFgGpLhTtkdEBUR,cookies=cookies,allow_redirects=redirects)
  return rilIDnNwaujXPbHYFgGpLhTtkdEBUW
 def Get_Now_Datetime(rilIDnNwaujXPbHYFgGpLhTtkdEBUQ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def local_dic_To_jsonfile(rilIDnNwaujXPbHYFgGpLhTtkdEBUQ,filename,dic):
  if filename=='':return rilIDnNwaujXPbHYFgGpLhTtkdEBUy
  try:
   fp=rilIDnNwaujXPbHYFgGpLhTtkdEBUx(filename,'w',-1,'utf-8')
   json.dump(dic,fp)
   fp.close()
  except:
   return rilIDnNwaujXPbHYFgGpLhTtkdEBUy
  return rilIDnNwaujXPbHYFgGpLhTtkdEBUC
 def local_jsonfile_To_dic(rilIDnNwaujXPbHYFgGpLhTtkdEBUQ,filename):
  if filename=='':return rilIDnNwaujXPbHYFgGpLhTtkdEBUq
  try:
   fp=rilIDnNwaujXPbHYFgGpLhTtkdEBUx(filename,'r',-1,'utf-8')
   rilIDnNwaujXPbHYFgGpLhTtkdEBUv=json.load(fp)
   fp.close()
  except:
   rilIDnNwaujXPbHYFgGpLhTtkdEBUv={}
  return rilIDnNwaujXPbHYFgGpLhTtkdEBUv
# Created by pyminifier (https://github.com/liftoff/pyminifier)
