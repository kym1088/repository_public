__author__="NightRain"
GUNixELuqzVpWRXKncJMrldHjyYsCS=object
GUNixELuqzVpWRXKncJMrldHjyYsCO=None
GUNixELuqzVpWRXKncJMrldHjyYsCv=True
GUNixELuqzVpWRXKncJMrldHjyYsAo=False
GUNixELuqzVpWRXKncJMrldHjyYsAt=type
GUNixELuqzVpWRXKncJMrldHjyYsAa=dict
GUNixELuqzVpWRXKncJMrldHjyYsAC=list
GUNixELuqzVpWRXKncJMrldHjyYsAm=len
GUNixELuqzVpWRXKncJMrldHjyYsAe=int
GUNixELuqzVpWRXKncJMrldHjyYsAF=str
GUNixELuqzVpWRXKncJMrldHjyYsAI=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
GUNixELuqzVpWRXKncJMrldHjyYsoa=[{'title':'찜 목록 (웨이브+티빙+왓챠+쿠팡+넷플)','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','icon':'sum.png'},{'title':'-----------------','mode':'XXX'},{'title':'영화   찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'movie','icon':'movie.png'},{'title':'시리즈 찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'tvshow','icon':'tvshow.png'},{'title':'장르별 찜 목록','mode':'GENRE_GROUP','ott':'-','vidtype':'-','icon':'category.png'},{'title':'-----------------','mode':'XXX'},{'title':'웨이브 찜 목록','mode':'BOOKMARK_GROUP','ott':'wavve','vidtype':'-','icon':'wavve.png'},{'title':'티빙   찜 목록','mode':'BOOKMARK_GROUP','ott':'tving','vidtype':'-','icon':'tving.png'},{'title':'왓챠   찜 목록','mode':'BOOKMARK_GROUP','ott':'watcha','vidtype':'-','icon':'watcha.png'},{'title':'쿠팡   찜 목록','mode':'BOOKMARK_GROUP','ott':'coupang','vidtype':'-','icon':'coupang.png'},{'title':'넷플   찜 목록 (search mini 에서 등록)','mode':'BOOKMARK_GROUP','ott':'netflix','vidtype':'-','icon':'netflix.png'},{'title':'프라임비디오 찜 목록 (테스트용)','mode':'BOOKMARK_GROUP','ott':'amazon','vidtype':'-','icon':'primev.png'},]
from bookmarkCore import*
class GUNixELuqzVpWRXKncJMrldHjyYsot(GUNixELuqzVpWRXKncJMrldHjyYsCS):
 def __init__(GUNixELuqzVpWRXKncJMrldHjyYsoC,GUNixELuqzVpWRXKncJMrldHjyYsoA,GUNixELuqzVpWRXKncJMrldHjyYsom,GUNixELuqzVpWRXKncJMrldHjyYsoe):
  GUNixELuqzVpWRXKncJMrldHjyYsoC._addon_url =GUNixELuqzVpWRXKncJMrldHjyYsoA
  GUNixELuqzVpWRXKncJMrldHjyYsoC._addon_handle=GUNixELuqzVpWRXKncJMrldHjyYsom
  GUNixELuqzVpWRXKncJMrldHjyYsoC.main_params =GUNixELuqzVpWRXKncJMrldHjyYsoe
  GUNixELuqzVpWRXKncJMrldHjyYsoC.LIB_PATH =''
  GUNixELuqzVpWRXKncJMrldHjyYsoC.LIST_LIMIT =20
  GUNixELuqzVpWRXKncJMrldHjyYsoC.BookmarkObj =rilIDnNwaujXPbHYFgGpLhTtkdEBUK() 
 def addon_noti(GUNixELuqzVpWRXKncJMrldHjyYsoC,sting):
  try:
   GUNixELuqzVpWRXKncJMrldHjyYsoI=xbmcgui.Dialog()
   GUNixELuqzVpWRXKncJMrldHjyYsoI.notification(__addonname__,sting)
  except:
   GUNixELuqzVpWRXKncJMrldHjyYsCO
 def addon_log(GUNixELuqzVpWRXKncJMrldHjyYsoC,string):
  try:
   GUNixELuqzVpWRXKncJMrldHjyYsoP=string.encode('utf-8','ignore')
  except:
   GUNixELuqzVpWRXKncJMrldHjyYsoP='addonException: addon_log'
  GUNixELuqzVpWRXKncJMrldHjyYsoD=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,GUNixELuqzVpWRXKncJMrldHjyYsoP),level=GUNixELuqzVpWRXKncJMrldHjyYsoD)
 def get_settings_select_ott(GUNixELuqzVpWRXKncJMrldHjyYsoC):
  GUNixELuqzVpWRXKncJMrldHjyYsoB =GUNixELuqzVpWRXKncJMrldHjyYsCv if __addon__.getSetting('view_wavve')=='true' else GUNixELuqzVpWRXKncJMrldHjyYsAo
  GUNixELuqzVpWRXKncJMrldHjyYsob =GUNixELuqzVpWRXKncJMrldHjyYsCv if __addon__.getSetting('view_tving')=='true' else GUNixELuqzVpWRXKncJMrldHjyYsAo
  GUNixELuqzVpWRXKncJMrldHjyYsoh =GUNixELuqzVpWRXKncJMrldHjyYsCv if __addon__.getSetting('view_watcha')=='true' else GUNixELuqzVpWRXKncJMrldHjyYsAo
  GUNixELuqzVpWRXKncJMrldHjyYsof=GUNixELuqzVpWRXKncJMrldHjyYsCv if __addon__.getSetting('view_coupang')=='true' else GUNixELuqzVpWRXKncJMrldHjyYsAo
  GUNixELuqzVpWRXKncJMrldHjyYsoQ=GUNixELuqzVpWRXKncJMrldHjyYsCv if __addon__.getSetting('view_netflix')=='true' else GUNixELuqzVpWRXKncJMrldHjyYsAo
  GUNixELuqzVpWRXKncJMrldHjyYsog =GUNixELuqzVpWRXKncJMrldHjyYsCv if __addon__.getSetting('view_primev')=='true' else GUNixELuqzVpWRXKncJMrldHjyYsAo
  return(GUNixELuqzVpWRXKncJMrldHjyYsoB,GUNixELuqzVpWRXKncJMrldHjyYsob,GUNixELuqzVpWRXKncJMrldHjyYsoh,GUNixELuqzVpWRXKncJMrldHjyYsof,GUNixELuqzVpWRXKncJMrldHjyYsoQ,GUNixELuqzVpWRXKncJMrldHjyYsog)
 def make_Index_Filename(GUNixELuqzVpWRXKncJMrldHjyYsoC,tempyn=GUNixELuqzVpWRXKncJMrldHjyYsAo):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_index_file.json'))
  else:
   return GUNixELuqzVpWRXKncJMrldHjyYsoC.LIB_PATH+'bookmark_index.json'
 def make_Vinfo_Filename(GUNixELuqzVpWRXKncJMrldHjyYsoC,GUNixELuqzVpWRXKncJMrldHjyYstv,GUNixELuqzVpWRXKncJMrldHjyYsao,tempyn=GUNixELuqzVpWRXKncJMrldHjyYsAo):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_vinfo_file.json'))
  else:
   GUNixELuqzVpWRXKncJMrldHjyYsoT='%s_%s.json'%(GUNixELuqzVpWRXKncJMrldHjyYstv,GUNixELuqzVpWRXKncJMrldHjyYsao)
   return GUNixELuqzVpWRXKncJMrldHjyYsoC.LIB_PATH+GUNixELuqzVpWRXKncJMrldHjyYsoT
 def add_dir(GUNixELuqzVpWRXKncJMrldHjyYsoC,label,sublabel='',ott='',img='',infoLabels=GUNixELuqzVpWRXKncJMrldHjyYsCO,isFolder=GUNixELuqzVpWRXKncJMrldHjyYsCv,params='',isLink=GUNixELuqzVpWRXKncJMrldHjyYsAo,ContextMenu=GUNixELuqzVpWRXKncJMrldHjyYsCO):
  params={'mode':params.get('mode'),'values':params,}
  GUNixELuqzVpWRXKncJMrldHjyYsok=json.dumps(params,separators=(',',':'))
  GUNixELuqzVpWRXKncJMrldHjyYsok=base64.standard_b64encode(GUNixELuqzVpWRXKncJMrldHjyYsok.encode()).decode('utf-8')
  GUNixELuqzVpWRXKncJMrldHjyYsok=GUNixELuqzVpWRXKncJMrldHjyYsok.replace('+','%2B')
  GUNixELuqzVpWRXKncJMrldHjyYsoS='%s?params=%s'%(GUNixELuqzVpWRXKncJMrldHjyYsoC._addon_url,GUNixELuqzVpWRXKncJMrldHjyYsok)
  if sublabel and sublabel!='-':GUNixELuqzVpWRXKncJMrldHjyYsoO='%s < %s >'%(label,sublabel)
  else: GUNixELuqzVpWRXKncJMrldHjyYsoO=label
  if not img:img='DefaultFolder.png'
  if ott:GUNixELuqzVpWRXKncJMrldHjyYsoO='%s - [%s]'%(GUNixELuqzVpWRXKncJMrldHjyYsoO,ott)
  GUNixELuqzVpWRXKncJMrldHjyYsov=xbmcgui.ListItem(GUNixELuqzVpWRXKncJMrldHjyYsoO)
  if GUNixELuqzVpWRXKncJMrldHjyYsAt(img)==GUNixELuqzVpWRXKncJMrldHjyYsAa:
   GUNixELuqzVpWRXKncJMrldHjyYsov.setArt(img)
  else:
   GUNixELuqzVpWRXKncJMrldHjyYsov.setArt({'thumb':img,'poster':img})
  GUNixELuqzVpWRXKncJMrldHjyYsto=[]
  if infoLabels!=GUNixELuqzVpWRXKncJMrldHjyYsCO:
   if GUNixELuqzVpWRXKncJMrldHjyYsAt(infoLabels.get('cast'))==GUNixELuqzVpWRXKncJMrldHjyYsAC:
    if GUNixELuqzVpWRXKncJMrldHjyYsAm(infoLabels.get('cast'))>0 and GUNixELuqzVpWRXKncJMrldHjyYsAt(infoLabels.get('cast')[0])==GUNixELuqzVpWRXKncJMrldHjyYsAa:
     GUNixELuqzVpWRXKncJMrldHjyYsto=infoLabels.get('cast')
     infoLabels['cast']=[]
  if infoLabels:GUNixELuqzVpWRXKncJMrldHjyYsov.setInfo('Video',infoLabels)
  if GUNixELuqzVpWRXKncJMrldHjyYsAm(GUNixELuqzVpWRXKncJMrldHjyYsto)>0:GUNixELuqzVpWRXKncJMrldHjyYsov.setCast(GUNixELuqzVpWRXKncJMrldHjyYsto)
  if not isFolder and not isLink:
   GUNixELuqzVpWRXKncJMrldHjyYsov.setProperty('IsPlayable','true')
  if ContextMenu:GUNixELuqzVpWRXKncJMrldHjyYsov.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(GUNixELuqzVpWRXKncJMrldHjyYsoC._addon_handle,GUNixELuqzVpWRXKncJMrldHjyYsoS,GUNixELuqzVpWRXKncJMrldHjyYsov,isFolder)
 def dp_Main_List(GUNixELuqzVpWRXKncJMrldHjyYsoC):
  (GUNixELuqzVpWRXKncJMrldHjyYsoB,GUNixELuqzVpWRXKncJMrldHjyYsob,GUNixELuqzVpWRXKncJMrldHjyYsoh,GUNixELuqzVpWRXKncJMrldHjyYsof,GUNixELuqzVpWRXKncJMrldHjyYsoQ,GUNixELuqzVpWRXKncJMrldHjyYsog)=GUNixELuqzVpWRXKncJMrldHjyYsoC.get_settings_select_ott()
  for GUNixELuqzVpWRXKncJMrldHjyYstC in GUNixELuqzVpWRXKncJMrldHjyYsoa:
   GUNixELuqzVpWRXKncJMrldHjyYsoO=GUNixELuqzVpWRXKncJMrldHjyYstC.get('title')
   GUNixELuqzVpWRXKncJMrldHjyYstA=''
   if GUNixELuqzVpWRXKncJMrldHjyYstC.get('ott')=='wavve' and GUNixELuqzVpWRXKncJMrldHjyYsoB ==GUNixELuqzVpWRXKncJMrldHjyYsAo:continue
   elif GUNixELuqzVpWRXKncJMrldHjyYstC.get('ott')=='tving' and GUNixELuqzVpWRXKncJMrldHjyYsob ==GUNixELuqzVpWRXKncJMrldHjyYsAo:continue
   elif GUNixELuqzVpWRXKncJMrldHjyYstC.get('ott')=='watcha' and GUNixELuqzVpWRXKncJMrldHjyYsoh ==GUNixELuqzVpWRXKncJMrldHjyYsAo:continue
   elif GUNixELuqzVpWRXKncJMrldHjyYstC.get('ott')=='coupang' and GUNixELuqzVpWRXKncJMrldHjyYsof==GUNixELuqzVpWRXKncJMrldHjyYsAo:continue
   elif GUNixELuqzVpWRXKncJMrldHjyYstC.get('ott')=='netflix' and GUNixELuqzVpWRXKncJMrldHjyYsoQ==GUNixELuqzVpWRXKncJMrldHjyYsAo:continue
   elif GUNixELuqzVpWRXKncJMrldHjyYstC.get('ott')=='amazon' and GUNixELuqzVpWRXKncJMrldHjyYsog ==GUNixELuqzVpWRXKncJMrldHjyYsAo:continue
   GUNixELuqzVpWRXKncJMrldHjyYsow={'mode':GUNixELuqzVpWRXKncJMrldHjyYstC.get('mode'),'ott':GUNixELuqzVpWRXKncJMrldHjyYstC.get('ott'),'vidtype':GUNixELuqzVpWRXKncJMrldHjyYstC.get('vidtype'),'page':'1',}
   if GUNixELuqzVpWRXKncJMrldHjyYstC.get('mode')=='XXX':
    GUNixELuqzVpWRXKncJMrldHjyYsow['mode']='XXX'
    GUNixELuqzVpWRXKncJMrldHjyYstm=GUNixELuqzVpWRXKncJMrldHjyYsAo
    GUNixELuqzVpWRXKncJMrldHjyYste =GUNixELuqzVpWRXKncJMrldHjyYsCv
   else:
    if 'icon' in GUNixELuqzVpWRXKncJMrldHjyYstC:
     GUNixELuqzVpWRXKncJMrldHjyYstA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',GUNixELuqzVpWRXKncJMrldHjyYstC.get('icon')) 
    GUNixELuqzVpWRXKncJMrldHjyYstm=GUNixELuqzVpWRXKncJMrldHjyYsCv
    GUNixELuqzVpWRXKncJMrldHjyYste =GUNixELuqzVpWRXKncJMrldHjyYsAo
   GUNixELuqzVpWRXKncJMrldHjyYsoC.add_dir(GUNixELuqzVpWRXKncJMrldHjyYsoO,sublabel='',ott='',img=GUNixELuqzVpWRXKncJMrldHjyYstA,infoLabels=GUNixELuqzVpWRXKncJMrldHjyYsCO,isFolder=GUNixELuqzVpWRXKncJMrldHjyYstm,params=GUNixELuqzVpWRXKncJMrldHjyYsow,isLink=GUNixELuqzVpWRXKncJMrldHjyYste)
  xbmcplugin.endOfDirectory(GUNixELuqzVpWRXKncJMrldHjyYsoC._addon_handle)
 def dp_Genre_Grouplist(GUNixELuqzVpWRXKncJMrldHjyYsoC,args):
  GUNixELuqzVpWRXKncJMrldHjyYstI=[]
  GUNixELuqzVpWRXKncJMrldHjyYstP=GUNixELuqzVpWRXKncJMrldHjyYsoC.make_Index_Filename(tempyn=GUNixELuqzVpWRXKncJMrldHjyYsAo)
  if xbmcvfs.exists(GUNixELuqzVpWRXKncJMrldHjyYstP):
   GUNixELuqzVpWRXKncJMrldHjyYstD=GUNixELuqzVpWRXKncJMrldHjyYsoC.jsonfile_To_dic(GUNixELuqzVpWRXKncJMrldHjyYstP)
  else:
   GUNixELuqzVpWRXKncJMrldHjyYstD=[]
  for GUNixELuqzVpWRXKncJMrldHjyYstB in GUNixELuqzVpWRXKncJMrldHjyYstD:
   GUNixELuqzVpWRXKncJMrldHjyYstb =GUNixELuqzVpWRXKncJMrldHjyYstB.get('genre')
   if GUNixELuqzVpWRXKncJMrldHjyYstb not in GUNixELuqzVpWRXKncJMrldHjyYstI:
    GUNixELuqzVpWRXKncJMrldHjyYstI.append(GUNixELuqzVpWRXKncJMrldHjyYstb)
  for GUNixELuqzVpWRXKncJMrldHjyYstb in GUNixELuqzVpWRXKncJMrldHjyYstI:
   GUNixELuqzVpWRXKncJMrldHjyYsow={'mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','genre':GUNixELuqzVpWRXKncJMrldHjyYstb,'page':'1',}
   GUNixELuqzVpWRXKncJMrldHjyYsoC.add_dir(GUNixELuqzVpWRXKncJMrldHjyYstb,sublabel='',ott='',img='',infoLabels=GUNixELuqzVpWRXKncJMrldHjyYsCO,isFolder=GUNixELuqzVpWRXKncJMrldHjyYsCv,params=GUNixELuqzVpWRXKncJMrldHjyYsow)
  xbmcplugin.endOfDirectory(GUNixELuqzVpWRXKncJMrldHjyYsoC._addon_handle)
 def dp_Bookmark_Grouplist(GUNixELuqzVpWRXKncJMrldHjyYsoC,args):
  GUNixELuqzVpWRXKncJMrldHjyYsth =GUNixELuqzVpWRXKncJMrldHjyYsAo
  GUNixELuqzVpWRXKncJMrldHjyYstf =[]
  GUNixELuqzVpWRXKncJMrldHjyYstQ =args.get('ott')
  GUNixELuqzVpWRXKncJMrldHjyYstg=args.get('vidtype')
  GUNixELuqzVpWRXKncJMrldHjyYstT =args.get('genre')
  if GUNixELuqzVpWRXKncJMrldHjyYstT==GUNixELuqzVpWRXKncJMrldHjyYsCO:GUNixELuqzVpWRXKncJMrldHjyYstT='all'
  GUNixELuqzVpWRXKncJMrldHjyYstw =GUNixELuqzVpWRXKncJMrldHjyYsAe(args.get('page'))
  GUNixELuqzVpWRXKncJMrldHjyYstk =GUNixELuqzVpWRXKncJMrldHjyYsoC.LIST_LIMIT*(GUNixELuqzVpWRXKncJMrldHjyYstw-1)+1 
  GUNixELuqzVpWRXKncJMrldHjyYstS =GUNixELuqzVpWRXKncJMrldHjyYsoC.LIST_LIMIT*GUNixELuqzVpWRXKncJMrldHjyYstw
  GUNixELuqzVpWRXKncJMrldHjyYstP=GUNixELuqzVpWRXKncJMrldHjyYsoC.make_Index_Filename(tempyn=GUNixELuqzVpWRXKncJMrldHjyYsAo)
  if xbmcvfs.exists(GUNixELuqzVpWRXKncJMrldHjyYstP):
   GUNixELuqzVpWRXKncJMrldHjyYstD=GUNixELuqzVpWRXKncJMrldHjyYsoC.jsonfile_To_dic(GUNixELuqzVpWRXKncJMrldHjyYstP)
  else:
   GUNixELuqzVpWRXKncJMrldHjyYstD=[]
  GUNixELuqzVpWRXKncJMrldHjyYstO=0
  for GUNixELuqzVpWRXKncJMrldHjyYstB in GUNixELuqzVpWRXKncJMrldHjyYstD:
   GUNixELuqzVpWRXKncJMrldHjyYstv =GUNixELuqzVpWRXKncJMrldHjyYstB.get('ott')
   GUNixELuqzVpWRXKncJMrldHjyYsao=GUNixELuqzVpWRXKncJMrldHjyYstB.get('videoid')
   GUNixELuqzVpWRXKncJMrldHjyYsat=GUNixELuqzVpWRXKncJMrldHjyYstB.get('vidtype')
   GUNixELuqzVpWRXKncJMrldHjyYsaC =GUNixELuqzVpWRXKncJMrldHjyYstB.get('genre')
   GUNixELuqzVpWRXKncJMrldHjyYsaA=GUNixELuqzVpWRXKncJMrldHjyYstB.get('linkUrl')
   if not(GUNixELuqzVpWRXKncJMrldHjyYstQ=='-' or GUNixELuqzVpWRXKncJMrldHjyYstQ==GUNixELuqzVpWRXKncJMrldHjyYstv):continue
   if not(GUNixELuqzVpWRXKncJMrldHjyYstg=='-' or GUNixELuqzVpWRXKncJMrldHjyYstg==GUNixELuqzVpWRXKncJMrldHjyYsat):continue
   if not(GUNixELuqzVpWRXKncJMrldHjyYstT=='all' or GUNixELuqzVpWRXKncJMrldHjyYstT==GUNixELuqzVpWRXKncJMrldHjyYsaC):continue
   GUNixELuqzVpWRXKncJMrldHjyYstO+=1
   if GUNixELuqzVpWRXKncJMrldHjyYstk>GUNixELuqzVpWRXKncJMrldHjyYstO:continue
   if GUNixELuqzVpWRXKncJMrldHjyYstS<GUNixELuqzVpWRXKncJMrldHjyYstO:
    GUNixELuqzVpWRXKncJMrldHjyYsth=GUNixELuqzVpWRXKncJMrldHjyYsCv
    break
   GUNixELuqzVpWRXKncJMrldHjyYsam=GUNixELuqzVpWRXKncJMrldHjyYsoC.make_Vinfo_Filename(GUNixELuqzVpWRXKncJMrldHjyYstv,GUNixELuqzVpWRXKncJMrldHjyYsao,tempyn=GUNixELuqzVpWRXKncJMrldHjyYsAo)
   if xbmcvfs.exists(GUNixELuqzVpWRXKncJMrldHjyYsam):
    GUNixELuqzVpWRXKncJMrldHjyYsae=GUNixELuqzVpWRXKncJMrldHjyYsoC.jsonfile_To_dic(GUNixELuqzVpWRXKncJMrldHjyYsam)
    GUNixELuqzVpWRXKncJMrldHjyYsoO =GUNixELuqzVpWRXKncJMrldHjyYsae.get('title')
    GUNixELuqzVpWRXKncJMrldHjyYsaF =GUNixELuqzVpWRXKncJMrldHjyYsae.get('subtitle')
    GUNixELuqzVpWRXKncJMrldHjyYsaI =GUNixELuqzVpWRXKncJMrldHjyYsae.get('thumbnail')
    GUNixELuqzVpWRXKncJMrldHjyYsta=GUNixELuqzVpWRXKncJMrldHjyYsae.get('infoLabels')
   else:
    GUNixELuqzVpWRXKncJMrldHjyYsoO =GUNixELuqzVpWRXKncJMrldHjyYstB.get('title')
    GUNixELuqzVpWRXKncJMrldHjyYsaF =''
    GUNixELuqzVpWRXKncJMrldHjyYsaI =''
    GUNixELuqzVpWRXKncJMrldHjyYsta={'mpaa':'0'}
    GUNixELuqzVpWRXKncJMrldHjyYsae ={'infoLabels':{'title':GUNixELuqzVpWRXKncJMrldHjyYsoO}}
   GUNixELuqzVpWRXKncJMrldHjyYsow={'mode':'HYPER_LINK','ott':GUNixELuqzVpWRXKncJMrldHjyYstv,'videoid':GUNixELuqzVpWRXKncJMrldHjyYsao,'vidtype':GUNixELuqzVpWRXKncJMrldHjyYsat,'title':GUNixELuqzVpWRXKncJMrldHjyYsoO,'thumbnail':GUNixELuqzVpWRXKncJMrldHjyYsaI,'mpaa':GUNixELuqzVpWRXKncJMrldHjyYsAF(GUNixELuqzVpWRXKncJMrldHjyYsta.get('mpaa')),'duration':GUNixELuqzVpWRXKncJMrldHjyYsAF(GUNixELuqzVpWRXKncJMrldHjyYsta.get('duration')),'linkUrl':GUNixELuqzVpWRXKncJMrldHjyYsaA,'infoLabels':GUNixELuqzVpWRXKncJMrldHjyYsta,}
   GUNixELuqzVpWRXKncJMrldHjyYsaP={'mode':'BOOKMARK_REMOVE','list':[GUNixELuqzVpWRXKncJMrldHjyYstB],}
   GUNixELuqzVpWRXKncJMrldHjyYsaD=urllib.parse.urlencode(GUNixELuqzVpWRXKncJMrldHjyYsaP)
   GUNixELuqzVpWRXKncJMrldHjyYsaB=[('찜 목록 ( %s ) 삭제'%(GUNixELuqzVpWRXKncJMrldHjyYsae.get('infoLabels').get('title')),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(GUNixELuqzVpWRXKncJMrldHjyYsaD))]
   if GUNixELuqzVpWRXKncJMrldHjyYstT!='all':
    GUNixELuqzVpWRXKncJMrldHjyYsaP={'mode':'GENRE_RENAME','list':[GUNixELuqzVpWRXKncJMrldHjyYstB],}
    GUNixELuqzVpWRXKncJMrldHjyYsaD=urllib.parse.urlencode(GUNixELuqzVpWRXKncJMrldHjyYsaP)
    GUNixELuqzVpWRXKncJMrldHjyYsaB.append(('장르명 ( %s ) 수정'%(GUNixELuqzVpWRXKncJMrldHjyYstT),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(GUNixELuqzVpWRXKncJMrldHjyYsaD)))
   GUNixELuqzVpWRXKncJMrldHjyYsoC.add_dir(GUNixELuqzVpWRXKncJMrldHjyYsoO,sublabel=GUNixELuqzVpWRXKncJMrldHjyYsaF,ott=GUNixELuqzVpWRXKncJMrldHjyYstv,img=GUNixELuqzVpWRXKncJMrldHjyYsaI,infoLabels=GUNixELuqzVpWRXKncJMrldHjyYsta,isFolder=GUNixELuqzVpWRXKncJMrldHjyYsAo,params=GUNixELuqzVpWRXKncJMrldHjyYsow,isLink=GUNixELuqzVpWRXKncJMrldHjyYsCv,ContextMenu=GUNixELuqzVpWRXKncJMrldHjyYsaB)
   GUNixELuqzVpWRXKncJMrldHjyYstf.append(GUNixELuqzVpWRXKncJMrldHjyYstB)
  GUNixELuqzVpWRXKncJMrldHjyYsab={'plot':'현재페이지의 전체목록을 삭제합니다.'}
  GUNixELuqzVpWRXKncJMrldHjyYsoO='* 현재페이지 목록 삭제 (개별삭제는 팝업메뉴) *'
  GUNixELuqzVpWRXKncJMrldHjyYsow={'mode':'BOOKMARK_REMOVE','list':GUNixELuqzVpWRXKncJMrldHjyYstf,}
  GUNixELuqzVpWRXKncJMrldHjyYstA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  GUNixELuqzVpWRXKncJMrldHjyYsoC.add_dir(GUNixELuqzVpWRXKncJMrldHjyYsoO,sublabel='',ott='',img=GUNixELuqzVpWRXKncJMrldHjyYstA,infoLabels=GUNixELuqzVpWRXKncJMrldHjyYsab,isFolder=GUNixELuqzVpWRXKncJMrldHjyYsAo,params=GUNixELuqzVpWRXKncJMrldHjyYsow,isLink=GUNixELuqzVpWRXKncJMrldHjyYsCv)
  if GUNixELuqzVpWRXKncJMrldHjyYsth:
   GUNixELuqzVpWRXKncJMrldHjyYsow={'mode':'BOOKMARK_GROUP','ott':GUNixELuqzVpWRXKncJMrldHjyYstQ,'vidtype':GUNixELuqzVpWRXKncJMrldHjyYstg,'page':GUNixELuqzVpWRXKncJMrldHjyYsAF(GUNixELuqzVpWRXKncJMrldHjyYstw+1)}
   GUNixELuqzVpWRXKncJMrldHjyYsoO='[B]%s >>[/B]'%'다음 페이지'
   GUNixELuqzVpWRXKncJMrldHjyYsaF=GUNixELuqzVpWRXKncJMrldHjyYsAF(GUNixELuqzVpWRXKncJMrldHjyYstw+1)
   GUNixELuqzVpWRXKncJMrldHjyYstA=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GUNixELuqzVpWRXKncJMrldHjyYsoC.add_dir(GUNixELuqzVpWRXKncJMrldHjyYsoO,sublabel=GUNixELuqzVpWRXKncJMrldHjyYsaF,ott='',img=GUNixELuqzVpWRXKncJMrldHjyYstA,infoLabels=GUNixELuqzVpWRXKncJMrldHjyYsCO,isFolder=GUNixELuqzVpWRXKncJMrldHjyYsCv,params=GUNixELuqzVpWRXKncJMrldHjyYsow)
  xbmcplugin.setContent(GUNixELuqzVpWRXKncJMrldHjyYsoC._addon_handle,'movies')
  xbmcplugin.endOfDirectory(GUNixELuqzVpWRXKncJMrldHjyYsoC._addon_handle)
 def get_keyboard_input(GUNixELuqzVpWRXKncJMrldHjyYsoC,defalut,GUNixELuqzVpWRXKncJMrldHjyYsoO):
  GUNixELuqzVpWRXKncJMrldHjyYsah=GUNixELuqzVpWRXKncJMrldHjyYsCO
  kb=xbmc.Keyboard(defalut,GUNixELuqzVpWRXKncJMrldHjyYsoO,GUNixELuqzVpWRXKncJMrldHjyYsAo)
  kb.setHeading(GUNixELuqzVpWRXKncJMrldHjyYsoO)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   GUNixELuqzVpWRXKncJMrldHjyYsah=kb.getText()
  return GUNixELuqzVpWRXKncJMrldHjyYsah
 def dp_Genre_Rename(GUNixELuqzVpWRXKncJMrldHjyYsoC,args):
  GUNixELuqzVpWRXKncJMrldHjyYsaf =GUNixELuqzVpWRXKncJMrldHjyYsCv
  GUNixELuqzVpWRXKncJMrldHjyYsaQ ={}
  try:
   GUNixELuqzVpWRXKncJMrldHjyYsag=args.get('list')
   GUNixELuqzVpWRXKncJMrldHjyYsag=GUNixELuqzVpWRXKncJMrldHjyYsag.replace('\'','\"')
   GUNixELuqzVpWRXKncJMrldHjyYsag=json.loads(GUNixELuqzVpWRXKncJMrldHjyYsag)
  except:
   GUNixELuqzVpWRXKncJMrldHjyYsaf=GUNixELuqzVpWRXKncJMrldHjyYsAo
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   if GUNixELuqzVpWRXKncJMrldHjyYsAm(GUNixELuqzVpWRXKncJMrldHjyYsag)!=0:
    GUNixELuqzVpWRXKncJMrldHjyYsaT=GUNixELuqzVpWRXKncJMrldHjyYsag[0].get('genre')
   else:
    return
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYsaw=GUNixELuqzVpWRXKncJMrldHjyYsoC.get_keyboard_input(GUNixELuqzVpWRXKncJMrldHjyYsaT,__language__(30909).encode('utf-8'))
   if GUNixELuqzVpWRXKncJMrldHjyYsaw!=GUNixELuqzVpWRXKncJMrldHjyYsCO:
    GUNixELuqzVpWRXKncJMrldHjyYsaw=GUNixELuqzVpWRXKncJMrldHjyYsaw.strip()
   else:
    return
   if GUNixELuqzVpWRXKncJMrldHjyYsaT==GUNixELuqzVpWRXKncJMrldHjyYsaw:
    GUNixELuqzVpWRXKncJMrldHjyYsoC.addon_noti(__language__(30910).encode('utf-8'))
    return
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   for GUNixELuqzVpWRXKncJMrldHjyYsak in GUNixELuqzVpWRXKncJMrldHjyYsag:
    if GUNixELuqzVpWRXKncJMrldHjyYsak['ott']in GUNixELuqzVpWRXKncJMrldHjyYsaQ:
     GUNixELuqzVpWRXKncJMrldHjyYsaQ[GUNixELuqzVpWRXKncJMrldHjyYsak['ott']].append(GUNixELuqzVpWRXKncJMrldHjyYsak['videoid'])
    else:
     GUNixELuqzVpWRXKncJMrldHjyYsaQ[GUNixELuqzVpWRXKncJMrldHjyYsak['ott']]=[GUNixELuqzVpWRXKncJMrldHjyYsak['videoid']]
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYstP=GUNixELuqzVpWRXKncJMrldHjyYsoC.make_Index_Filename(tempyn=GUNixELuqzVpWRXKncJMrldHjyYsAo)
   if xbmcvfs.exists(GUNixELuqzVpWRXKncJMrldHjyYstP):
    GUNixELuqzVpWRXKncJMrldHjyYstD=GUNixELuqzVpWRXKncJMrldHjyYsoC.jsonfile_To_dic(GUNixELuqzVpWRXKncJMrldHjyYstP)
   else:
    GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsAo
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   for i in GUNixELuqzVpWRXKncJMrldHjyYsAI(GUNixELuqzVpWRXKncJMrldHjyYsAm(GUNixELuqzVpWRXKncJMrldHjyYstD)):
    GUNixELuqzVpWRXKncJMrldHjyYsaS =GUNixELuqzVpWRXKncJMrldHjyYstD[i].get('ott')
    GUNixELuqzVpWRXKncJMrldHjyYsaO=GUNixELuqzVpWRXKncJMrldHjyYstD[i].get('videoid')
    if GUNixELuqzVpWRXKncJMrldHjyYsaS in GUNixELuqzVpWRXKncJMrldHjyYsaQ:
     if GUNixELuqzVpWRXKncJMrldHjyYsaO in GUNixELuqzVpWRXKncJMrldHjyYsaQ[GUNixELuqzVpWRXKncJMrldHjyYsaS]:
      GUNixELuqzVpWRXKncJMrldHjyYstD[i]['genre']=GUNixELuqzVpWRXKncJMrldHjyYsaw
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYsaf=GUNixELuqzVpWRXKncJMrldHjyYsoC.dic_To_jsonfile(GUNixELuqzVpWRXKncJMrldHjyYstP,GUNixELuqzVpWRXKncJMrldHjyYstD)
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYsoC.addon_noti(__language__(30911).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   GUNixELuqzVpWRXKncJMrldHjyYsoC.addon_noti(__language__(30912).encode('utf-8'))
 def dp_Bookmark_Remove(GUNixELuqzVpWRXKncJMrldHjyYsoC,args):
  GUNixELuqzVpWRXKncJMrldHjyYsaf =GUNixELuqzVpWRXKncJMrldHjyYsCv
  GUNixELuqzVpWRXKncJMrldHjyYsav ={}
  GUNixELuqzVpWRXKncJMrldHjyYsoI=xbmcgui.Dialog()
  GUNixELuqzVpWRXKncJMrldHjyYsCo=GUNixELuqzVpWRXKncJMrldHjyYsoI.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if GUNixELuqzVpWRXKncJMrldHjyYsCo==GUNixELuqzVpWRXKncJMrldHjyYsAo:sys.exit()
  try:
   GUNixELuqzVpWRXKncJMrldHjyYsag=args.get('list')
   GUNixELuqzVpWRXKncJMrldHjyYsag=GUNixELuqzVpWRXKncJMrldHjyYsag.replace('\'','\"')
   GUNixELuqzVpWRXKncJMrldHjyYsag=json.loads(GUNixELuqzVpWRXKncJMrldHjyYsag)
  except:
   GUNixELuqzVpWRXKncJMrldHjyYsaf=GUNixELuqzVpWRXKncJMrldHjyYsAo
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   for GUNixELuqzVpWRXKncJMrldHjyYsak in GUNixELuqzVpWRXKncJMrldHjyYsag:
    if GUNixELuqzVpWRXKncJMrldHjyYsak['ott']in GUNixELuqzVpWRXKncJMrldHjyYsav:
     GUNixELuqzVpWRXKncJMrldHjyYsav[GUNixELuqzVpWRXKncJMrldHjyYsak['ott']].append(GUNixELuqzVpWRXKncJMrldHjyYsak['videoid'])
    else:
     GUNixELuqzVpWRXKncJMrldHjyYsav[GUNixELuqzVpWRXKncJMrldHjyYsak['ott']]=[GUNixELuqzVpWRXKncJMrldHjyYsak['videoid']]
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYstP=GUNixELuqzVpWRXKncJMrldHjyYsoC.make_Index_Filename(tempyn=GUNixELuqzVpWRXKncJMrldHjyYsAo)
   if xbmcvfs.exists(GUNixELuqzVpWRXKncJMrldHjyYstP):
    GUNixELuqzVpWRXKncJMrldHjyYstD=GUNixELuqzVpWRXKncJMrldHjyYsoC.jsonfile_To_dic(GUNixELuqzVpWRXKncJMrldHjyYstP)
   else:
    GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsAo
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYstB=[]
   for GUNixELuqzVpWRXKncJMrldHjyYsCt in GUNixELuqzVpWRXKncJMrldHjyYstD:
    GUNixELuqzVpWRXKncJMrldHjyYsaS =GUNixELuqzVpWRXKncJMrldHjyYsCt.get('ott')
    GUNixELuqzVpWRXKncJMrldHjyYsaO=GUNixELuqzVpWRXKncJMrldHjyYsCt.get('videoid')
    if GUNixELuqzVpWRXKncJMrldHjyYsaS in GUNixELuqzVpWRXKncJMrldHjyYsav:
     if GUNixELuqzVpWRXKncJMrldHjyYsaO in GUNixELuqzVpWRXKncJMrldHjyYsav[GUNixELuqzVpWRXKncJMrldHjyYsaS]:
      GUNixELuqzVpWRXKncJMrldHjyYsam=GUNixELuqzVpWRXKncJMrldHjyYsoC.make_Vinfo_Filename(GUNixELuqzVpWRXKncJMrldHjyYsaS,GUNixELuqzVpWRXKncJMrldHjyYsaO,tempyn=GUNixELuqzVpWRXKncJMrldHjyYsAo)
      xbmcvfs.delete(GUNixELuqzVpWRXKncJMrldHjyYsam)
      continue
    GUNixELuqzVpWRXKncJMrldHjyYstB.append(GUNixELuqzVpWRXKncJMrldHjyYsCt)
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYsCO
   GUNixELuqzVpWRXKncJMrldHjyYsaf=GUNixELuqzVpWRXKncJMrldHjyYsoC.dic_To_jsonfile(GUNixELuqzVpWRXKncJMrldHjyYstP,GUNixELuqzVpWRXKncJMrldHjyYstB)
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYsoC.addon_noti(__language__(30908).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   GUNixELuqzVpWRXKncJMrldHjyYsoC.addon_noti(__language__(30907).encode('utf-8'))
 def dp_Hyper_Link(GUNixELuqzVpWRXKncJMrldHjyYsoC,args):
  GUNixELuqzVpWRXKncJMrldHjyYstv =args.get('ott')
  GUNixELuqzVpWRXKncJMrldHjyYsao =args.get('videoid')
  GUNixELuqzVpWRXKncJMrldHjyYsat =args.get('vidtype')
  GUNixELuqzVpWRXKncJMrldHjyYsoO =args.get('title')
  GUNixELuqzVpWRXKncJMrldHjyYsaI =args.get('thumbnail')
  GUNixELuqzVpWRXKncJMrldHjyYsCa =args.get('mpaa')
  GUNixELuqzVpWRXKncJMrldHjyYsaA =args.get('linkUrl')
  GUNixELuqzVpWRXKncJMrldHjyYsCA =args.get('duration')
  GUNixELuqzVpWRXKncJMrldHjyYsta=args.get('infoLabels')
  if GUNixELuqzVpWRXKncJMrldHjyYstv=='wavve':
   if GUNixELuqzVpWRXKncJMrldHjyYsat=='tvshow':
    GUNixELuqzVpWRXKncJMrldHjyYsCm={'mode':'EPISODE_LIST','videoid':GUNixELuqzVpWRXKncJMrldHjyYsao,'vidtype':GUNixELuqzVpWRXKncJMrldHjyYsat,'page':'1',}
    GUNixELuqzVpWRXKncJMrldHjyYsCe=urllib.parse.urlencode(GUNixELuqzVpWRXKncJMrldHjyYsCm)
    GUNixELuqzVpWRXKncJMrldHjyYsCF='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(GUNixELuqzVpWRXKncJMrldHjyYsCe)
   else:
    GUNixELuqzVpWRXKncJMrldHjyYsCm={'mode':'MOVIE','contentid':GUNixELuqzVpWRXKncJMrldHjyYsao,'title':GUNixELuqzVpWRXKncJMrldHjyYsoO,'thumbnail':GUNixELuqzVpWRXKncJMrldHjyYsaI,'age':GUNixELuqzVpWRXKncJMrldHjyYsCa,}
    GUNixELuqzVpWRXKncJMrldHjyYsCe=urllib.parse.urlencode(GUNixELuqzVpWRXKncJMrldHjyYsCm)
    GUNixELuqzVpWRXKncJMrldHjyYsCF='PlayMedia("plugin://plugin.video.wavvem/?%s")'%(GUNixELuqzVpWRXKncJMrldHjyYsCe)
  elif GUNixELuqzVpWRXKncJMrldHjyYstv=='tving':
   if GUNixELuqzVpWRXKncJMrldHjyYsat=='tvshow':
    GUNixELuqzVpWRXKncJMrldHjyYsCm={'mode':'EPISODE','programcode':GUNixELuqzVpWRXKncJMrldHjyYsao,'page':'1',}
    GUNixELuqzVpWRXKncJMrldHjyYsCe=urllib.parse.urlencode(GUNixELuqzVpWRXKncJMrldHjyYsCm)
    GUNixELuqzVpWRXKncJMrldHjyYsCF='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(GUNixELuqzVpWRXKncJMrldHjyYsCe)
   else:
    GUNixELuqzVpWRXKncJMrldHjyYsCm={'mode':'MOVIE','stype':'movie','mediacode':GUNixELuqzVpWRXKncJMrldHjyYsao,'title':GUNixELuqzVpWRXKncJMrldHjyYsoO,'thumbnail':GUNixELuqzVpWRXKncJMrldHjyYsaI,}
    GUNixELuqzVpWRXKncJMrldHjyYsCe=urllib.parse.urlencode(GUNixELuqzVpWRXKncJMrldHjyYsCm)
    GUNixELuqzVpWRXKncJMrldHjyYsCF='PlayMedia("plugin://plugin.video.tvingm/?%s")'%(GUNixELuqzVpWRXKncJMrldHjyYsCe)
  elif GUNixELuqzVpWRXKncJMrldHjyYstv=='watcha':
   if GUNixELuqzVpWRXKncJMrldHjyYsat=='tvshow':
    GUNixELuqzVpWRXKncJMrldHjyYsCm={'mode':'EPISODE','movie_code':GUNixELuqzVpWRXKncJMrldHjyYsao,'season_code':GUNixELuqzVpWRXKncJMrldHjyYsao,'page':'1',}
    GUNixELuqzVpWRXKncJMrldHjyYsCe=urllib.parse.urlencode(GUNixELuqzVpWRXKncJMrldHjyYsCm)
    GUNixELuqzVpWRXKncJMrldHjyYsCF='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(GUNixELuqzVpWRXKncJMrldHjyYsCe)
   else:
    GUNixELuqzVpWRXKncJMrldHjyYsCm={'mode':'MOVIE','movie_code':GUNixELuqzVpWRXKncJMrldHjyYsao,'season_code':'-','title':GUNixELuqzVpWRXKncJMrldHjyYsoO,'thumbnail':GUNixELuqzVpWRXKncJMrldHjyYsaI,}
    GUNixELuqzVpWRXKncJMrldHjyYsCe=urllib.parse.urlencode(GUNixELuqzVpWRXKncJMrldHjyYsCm)
    GUNixELuqzVpWRXKncJMrldHjyYsCF='PlayMedia("plugin://plugin.video.watcham/?%s")'%(GUNixELuqzVpWRXKncJMrldHjyYsCe)
  elif GUNixELuqzVpWRXKncJMrldHjyYstv=='coupang':
   if GUNixELuqzVpWRXKncJMrldHjyYsat=='tvshow':
    GUNixELuqzVpWRXKncJMrldHjyYsCm={'mode':'SEASON_LIST','id':GUNixELuqzVpWRXKncJMrldHjyYsao,'asis':'TVSHOW','title':GUNixELuqzVpWRXKncJMrldHjyYsoO,'thumbnail':GUNixELuqzVpWRXKncJMrldHjyYsaI,'page':'1',}
    GUNixELuqzVpWRXKncJMrldHjyYsCe=urllib.parse.urlencode(GUNixELuqzVpWRXKncJMrldHjyYsCm)
    GUNixELuqzVpWRXKncJMrldHjyYsCF='ActivateWindow(10025,"plugin://plugin.video.coupangm/?%s",return)'%(GUNixELuqzVpWRXKncJMrldHjyYsCe)
   else:
    GUNixELuqzVpWRXKncJMrldHjyYsCm={'mode':'MOVIE','id':GUNixELuqzVpWRXKncJMrldHjyYsao,'asis':'MOVIE','title':GUNixELuqzVpWRXKncJMrldHjyYsoO,'thumbnail':GUNixELuqzVpWRXKncJMrldHjyYsaI,}
    GUNixELuqzVpWRXKncJMrldHjyYsCe=urllib.parse.urlencode(GUNixELuqzVpWRXKncJMrldHjyYsCm)
    GUNixELuqzVpWRXKncJMrldHjyYsCF='PlayMedia("plugin://plugin.video.coupangm/?%s")'%(GUNixELuqzVpWRXKncJMrldHjyYsCe)
  elif GUNixELuqzVpWRXKncJMrldHjyYstv=='netflix':
   if GUNixELuqzVpWRXKncJMrldHjyYsat=='tvshow':
    GUNixELuqzVpWRXKncJMrldHjyYsCF='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(GUNixELuqzVpWRXKncJMrldHjyYsao)
   else:
    GUNixELuqzVpWRXKncJMrldHjyYsCF='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/")'%(GUNixELuqzVpWRXKncJMrldHjyYsao)
  elif GUNixELuqzVpWRXKncJMrldHjyYstv=='amazon':
   if GUNixELuqzVpWRXKncJMrldHjyYsat=='tvshow':
    GUNixELuqzVpWRXKncJMrldHjyYsCm={'mode':'SEASON_LIST','values':{'titleID':GUNixELuqzVpWRXKncJMrldHjyYsao,'linkUrl':GUNixELuqzVpWRXKncJMrldHjyYsaA,'duration':GUNixELuqzVpWRXKncJMrldHjyYsCA,'vType':GUNixELuqzVpWRXKncJMrldHjyYsat,'image':GUNixELuqzVpWRXKncJMrldHjyYsaI,'title':GUNixELuqzVpWRXKncJMrldHjyYsoO,'infoLabels':GUNixELuqzVpWRXKncJMrldHjyYsta,}}
    GUNixELuqzVpWRXKncJMrldHjyYsCe=json.dumps(GUNixELuqzVpWRXKncJMrldHjyYsCm,separators=(',',':'))
    GUNixELuqzVpWRXKncJMrldHjyYsCe=base64.standard_b64encode(GUNixELuqzVpWRXKncJMrldHjyYsCe.encode()).decode('utf-8')
    GUNixELuqzVpWRXKncJMrldHjyYsCe=GUNixELuqzVpWRXKncJMrldHjyYsCe.replace('+','%2B')
    GUNixELuqzVpWRXKncJMrldHjyYsCF='ActivateWindow(10025,"plugin://plugin.video.primevm/?params=%s",return)'%(GUNixELuqzVpWRXKncJMrldHjyYsCe)
   else:
    GUNixELuqzVpWRXKncJMrldHjyYsCm={'mode':'MOVIE','values':{'titleID':GUNixELuqzVpWRXKncJMrldHjyYsao,'linkUrl':GUNixELuqzVpWRXKncJMrldHjyYsaA,'duration':GUNixELuqzVpWRXKncJMrldHjyYsCA,'vType':GUNixELuqzVpWRXKncJMrldHjyYsat,'image':GUNixELuqzVpWRXKncJMrldHjyYsaI,'title':GUNixELuqzVpWRXKncJMrldHjyYsoO,'infoLabels':GUNixELuqzVpWRXKncJMrldHjyYsta,}}
    GUNixELuqzVpWRXKncJMrldHjyYsCe=json.dumps(GUNixELuqzVpWRXKncJMrldHjyYsCm,separators=(',',':'))
    GUNixELuqzVpWRXKncJMrldHjyYsCe=base64.standard_b64encode(GUNixELuqzVpWRXKncJMrldHjyYsCe.encode()).decode('utf-8')
    GUNixELuqzVpWRXKncJMrldHjyYsCe=GUNixELuqzVpWRXKncJMrldHjyYsCe.replace('+','%2B')
    GUNixELuqzVpWRXKncJMrldHjyYsCF='PlayMedia("plugin://plugin.video.primevm/?params=%s")'%(GUNixELuqzVpWRXKncJMrldHjyYsCe)
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(GUNixELuqzVpWRXKncJMrldHjyYsCF)
 def dp_Set_Bookmark(GUNixELuqzVpWRXKncJMrldHjyYsoC,args):
  GUNixELuqzVpWRXKncJMrldHjyYsaf =GUNixELuqzVpWRXKncJMrldHjyYsCv
  GUNixELuqzVpWRXKncJMrldHjyYstD=[]
  GUNixELuqzVpWRXKncJMrldHjyYsCI=args.get('VIDEO_INFO')
  if GUNixELuqzVpWRXKncJMrldHjyYsCI:
   GUNixELuqzVpWRXKncJMrldHjyYstB=GUNixELuqzVpWRXKncJMrldHjyYsCI.get('indexinfo')
   GUNixELuqzVpWRXKncJMrldHjyYsae =GUNixELuqzVpWRXKncJMrldHjyYsCI.get('saveinfo')
  else:
   GUNixELuqzVpWRXKncJMrldHjyYsCP =urllib.parse.unquote(args.get('bm_param'))
   GUNixELuqzVpWRXKncJMrldHjyYsCP =json.loads(GUNixELuqzVpWRXKncJMrldHjyYsCP)
   GUNixELuqzVpWRXKncJMrldHjyYstB=GUNixELuqzVpWRXKncJMrldHjyYsCP.get('indexinfo')
   GUNixELuqzVpWRXKncJMrldHjyYsae =GUNixELuqzVpWRXKncJMrldHjyYsCP.get('saveinfo')
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYsam=GUNixELuqzVpWRXKncJMrldHjyYsoC.make_Vinfo_Filename(GUNixELuqzVpWRXKncJMrldHjyYstB.get('ott'),GUNixELuqzVpWRXKncJMrldHjyYstB.get('videoid'),tempyn=GUNixELuqzVpWRXKncJMrldHjyYsAo)
   GUNixELuqzVpWRXKncJMrldHjyYsaf=GUNixELuqzVpWRXKncJMrldHjyYsoC.dic_To_jsonfile(GUNixELuqzVpWRXKncJMrldHjyYsam,GUNixELuqzVpWRXKncJMrldHjyYsae)
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYstP=GUNixELuqzVpWRXKncJMrldHjyYsoC.make_Index_Filename(tempyn=GUNixELuqzVpWRXKncJMrldHjyYsAo)
   if xbmcvfs.exists(GUNixELuqzVpWRXKncJMrldHjyYstP):
    GUNixELuqzVpWRXKncJMrldHjyYstD=GUNixELuqzVpWRXKncJMrldHjyYsoC.jsonfile_To_dic(GUNixELuqzVpWRXKncJMrldHjyYstP)
   else:
    GUNixELuqzVpWRXKncJMrldHjyYstD=[]
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYsCD =GUNixELuqzVpWRXKncJMrldHjyYstB.get('ott')
   GUNixELuqzVpWRXKncJMrldHjyYsCB =GUNixELuqzVpWRXKncJMrldHjyYstB.get('videoid')
   for i in GUNixELuqzVpWRXKncJMrldHjyYsAI(GUNixELuqzVpWRXKncJMrldHjyYsAm(GUNixELuqzVpWRXKncJMrldHjyYstD)):
    GUNixELuqzVpWRXKncJMrldHjyYsaS =GUNixELuqzVpWRXKncJMrldHjyYstD[i].get('ott')
    GUNixELuqzVpWRXKncJMrldHjyYsaO=GUNixELuqzVpWRXKncJMrldHjyYstD[i].get('videoid')
    if GUNixELuqzVpWRXKncJMrldHjyYsCD==GUNixELuqzVpWRXKncJMrldHjyYsaS and GUNixELuqzVpWRXKncJMrldHjyYsCB==GUNixELuqzVpWRXKncJMrldHjyYsaO:
     GUNixELuqzVpWRXKncJMrldHjyYstD.pop(i)
     break
   GUNixELuqzVpWRXKncJMrldHjyYstB['title']=GUNixELuqzVpWRXKncJMrldHjyYsae.get('title')
   if GUNixELuqzVpWRXKncJMrldHjyYsAm(GUNixELuqzVpWRXKncJMrldHjyYsae.get('infoLabels').get('genre'))>0:
    GUNixELuqzVpWRXKncJMrldHjyYstB['genre']=GUNixELuqzVpWRXKncJMrldHjyYsae.get('infoLabels').get('genre')[0]
   else:
    GUNixELuqzVpWRXKncJMrldHjyYstB['genre']='-'
   GUNixELuqzVpWRXKncJMrldHjyYstD.insert(0,GUNixELuqzVpWRXKncJMrldHjyYstB)
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYsaf=GUNixELuqzVpWRXKncJMrldHjyYsoC.dic_To_jsonfile(GUNixELuqzVpWRXKncJMrldHjyYstP,GUNixELuqzVpWRXKncJMrldHjyYstD)
  if GUNixELuqzVpWRXKncJMrldHjyYsaf==GUNixELuqzVpWRXKncJMrldHjyYsCv:
   GUNixELuqzVpWRXKncJMrldHjyYsoC.addon_noti(__language__(30903).encode('utf8'))
  else:
   GUNixELuqzVpWRXKncJMrldHjyYsoC.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(GUNixELuqzVpWRXKncJMrldHjyYsoC):
  GUNixELuqzVpWRXKncJMrldHjyYsCb=GUNixELuqzVpWRXKncJMrldHjyYsCv
  GUNixELuqzVpWRXKncJMrldHjyYsoC.LIB_PATH =(__addon__.getSetting('libpath')).strip()
  if GUNixELuqzVpWRXKncJMrldHjyYsoC.LIB_PATH=='':GUNixELuqzVpWRXKncJMrldHjyYsCb=GUNixELuqzVpWRXKncJMrldHjyYsAo
  if GUNixELuqzVpWRXKncJMrldHjyYsCb==GUNixELuqzVpWRXKncJMrldHjyYsAo:
   GUNixELuqzVpWRXKncJMrldHjyYsoI=xbmcgui.Dialog()
   GUNixELuqzVpWRXKncJMrldHjyYsCo=GUNixELuqzVpWRXKncJMrldHjyYsoI.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if GUNixELuqzVpWRXKncJMrldHjyYsCo==GUNixELuqzVpWRXKncJMrldHjyYsCv:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def dic_To_jsonfile(GUNixELuqzVpWRXKncJMrldHjyYsoC,filename,GUNixELuqzVpWRXKncJMrldHjyYsCh):
  if filename=='':return GUNixELuqzVpWRXKncJMrldHjyYsAo
  try:
   fp=xbmcvfs.File(filename,'w')
   json.dump(GUNixELuqzVpWRXKncJMrldHjyYsCh,fp,indent=4,ensure_ascii=GUNixELuqzVpWRXKncJMrldHjyYsAo)
   fp.close()
  except:
   return GUNixELuqzVpWRXKncJMrldHjyYsAo
  return GUNixELuqzVpWRXKncJMrldHjyYsCv
 def jsonfile_To_dic(GUNixELuqzVpWRXKncJMrldHjyYsoC,filename):
  if filename=='':return GUNixELuqzVpWRXKncJMrldHjyYsCO
  try:
   fp=xbmcvfs.File(filename)
   GUNixELuqzVpWRXKncJMrldHjyYsCQ=json.load(fp)
   fp.close()
  except:
   GUNixELuqzVpWRXKncJMrldHjyYsCQ={}
  return GUNixELuqzVpWRXKncJMrldHjyYsCQ
 def bookmark_main(GUNixELuqzVpWRXKncJMrldHjyYsoC):
  GUNixELuqzVpWRXKncJMrldHjyYsCg=GUNixELuqzVpWRXKncJMrldHjyYsoC.main_params.get('params')
  if GUNixELuqzVpWRXKncJMrldHjyYsCg:
   GUNixELuqzVpWRXKncJMrldHjyYsCT =base64.standard_b64decode(GUNixELuqzVpWRXKncJMrldHjyYsCg).decode('utf-8')
   GUNixELuqzVpWRXKncJMrldHjyYsCT =json.loads(GUNixELuqzVpWRXKncJMrldHjyYsCT)
   GUNixELuqzVpWRXKncJMrldHjyYsCw =GUNixELuqzVpWRXKncJMrldHjyYsCT.get('mode')
   GUNixELuqzVpWRXKncJMrldHjyYsCk =GUNixELuqzVpWRXKncJMrldHjyYsCT.get('values')
  else:
   GUNixELuqzVpWRXKncJMrldHjyYsCw=GUNixELuqzVpWRXKncJMrldHjyYsoC.main_params.get('mode',GUNixELuqzVpWRXKncJMrldHjyYsCO)
   GUNixELuqzVpWRXKncJMrldHjyYsCk=GUNixELuqzVpWRXKncJMrldHjyYsoC.main_params
  GUNixELuqzVpWRXKncJMrldHjyYsoC.option_check()
  if GUNixELuqzVpWRXKncJMrldHjyYsCw is GUNixELuqzVpWRXKncJMrldHjyYsCO:
   GUNixELuqzVpWRXKncJMrldHjyYsoC.dp_Main_List()
  elif GUNixELuqzVpWRXKncJMrldHjyYsCw=='SET_BOOKMARK':
   GUNixELuqzVpWRXKncJMrldHjyYsoC.dp_Set_Bookmark(GUNixELuqzVpWRXKncJMrldHjyYsCk)
  elif GUNixELuqzVpWRXKncJMrldHjyYsCw=='GENRE_GROUP':
   GUNixELuqzVpWRXKncJMrldHjyYsoC.dp_Genre_Grouplist(GUNixELuqzVpWRXKncJMrldHjyYsCk)
  elif GUNixELuqzVpWRXKncJMrldHjyYsCw=='BOOKMARK_GROUP':
   GUNixELuqzVpWRXKncJMrldHjyYsoC.dp_Bookmark_Grouplist(GUNixELuqzVpWRXKncJMrldHjyYsCk)
  elif GUNixELuqzVpWRXKncJMrldHjyYsCw=='HYPER_LINK':
   GUNixELuqzVpWRXKncJMrldHjyYsoC.dp_Hyper_Link(GUNixELuqzVpWRXKncJMrldHjyYsCk)
  elif GUNixELuqzVpWRXKncJMrldHjyYsCw=='BOOKMARK_REMOVE':
   GUNixELuqzVpWRXKncJMrldHjyYsoC.dp_Bookmark_Remove(GUNixELuqzVpWRXKncJMrldHjyYsCk)
  elif GUNixELuqzVpWRXKncJMrldHjyYsCw=='GENRE_RENAME':
   GUNixELuqzVpWRXKncJMrldHjyYsoC.dp_Genre_Rename(GUNixELuqzVpWRXKncJMrldHjyYsCk)
  else:
   GUNixELuqzVpWRXKncJMrldHjyYsCO
# Created by pyminifier (https://github.com/liftoff/pyminifier)
