# searchM-v19
 OTT 통합검색 애드온 for Kodi19 

## Version 2.0.2 (2021.11.11)
- 아마존 추가

## Version 2.0.1 (2021.07.28)
- 쿠팡플레이 추가

## Version 2.0.0 (2021.03.13)
- Initial addon version

