__author__="NightRain"
saGUquHKQexiXFftoWYyACDRMnOScP=object
saGUquHKQexiXFftoWYyACDRMnOScz=None
saGUquHKQexiXFftoWYyACDRMnOScm=True
saGUquHKQexiXFftoWYyACDRMnOSck=False
saGUquHKQexiXFftoWYyACDRMnOScw=type
saGUquHKQexiXFftoWYyACDRMnOScv=dict
saGUquHKQexiXFftoWYyACDRMnOSch=list
saGUquHKQexiXFftoWYyACDRMnOScb=len
saGUquHKQexiXFftoWYyACDRMnOScd=int
saGUquHKQexiXFftoWYyACDRMnOScI=str
saGUquHKQexiXFftoWYyACDRMnOScN=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
saGUquHKQexiXFftoWYyACDRMnOSLp=[{'title':'찜 목록 (웨이브+티빙+왓챠+쿠팡+넷플)','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','icon':'sum.png'},{'title':'-----------------','mode':'XXX'},{'title':'영화   찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'movie','icon':'movie.png'},{'title':'시리즈 찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'tvshow','icon':'tvshow.png'},{'title':'장르별 찜 목록','mode':'GENRE_GROUP','ott':'-','vidtype':'-','icon':'category.png'},{'title':'-----------------','mode':'XXX'},{'title':'웨이브 찜 목록','mode':'BOOKMARK_GROUP','ott':'wavve','vidtype':'-','icon':'wavve.png'},{'title':'티빙   찜 목록','mode':'BOOKMARK_GROUP','ott':'tving','vidtype':'-','icon':'tving.png'},{'title':'왓챠   찜 목록','mode':'BOOKMARK_GROUP','ott':'watcha','vidtype':'-','icon':'watcha.png'},{'title':'쿠팡   찜 목록','mode':'BOOKMARK_GROUP','ott':'coupang','vidtype':'-','icon':'coupang.png'},{'title':'넷플   찜 목록 (search mini 에서 등록)','mode':'BOOKMARK_GROUP','ott':'netflix','vidtype':'-','icon':'netflix.png'},{'title':'프라임비디오 찜 목록 (테스트용)','mode':'BOOKMARK_GROUP','ott':'amazon','vidtype':'-','icon':'primev.png'},{'title':'디즈니플러스 찜 목록','mode':'BOOKMARK_GROUP','ott':'disney','vidtype':'-','icon':'disney.jpg'},]
from bookmarkCore import*
class saGUquHKQexiXFftoWYyACDRMnOSLJ(saGUquHKQexiXFftoWYyACDRMnOScP):
 def __init__(saGUquHKQexiXFftoWYyACDRMnOSLP,saGUquHKQexiXFftoWYyACDRMnOSLc,saGUquHKQexiXFftoWYyACDRMnOSLz,saGUquHKQexiXFftoWYyACDRMnOSLm):
  saGUquHKQexiXFftoWYyACDRMnOSLP._addon_url =saGUquHKQexiXFftoWYyACDRMnOSLc
  saGUquHKQexiXFftoWYyACDRMnOSLP._addon_handle=saGUquHKQexiXFftoWYyACDRMnOSLz
  saGUquHKQexiXFftoWYyACDRMnOSLP.main_params =saGUquHKQexiXFftoWYyACDRMnOSLm
  saGUquHKQexiXFftoWYyACDRMnOSLP.LIB_PATH =''
  saGUquHKQexiXFftoWYyACDRMnOSLP.LIST_LIMIT =20
  saGUquHKQexiXFftoWYyACDRMnOSLP.BookmarkObj =KMXAqSvbBWQhyxdNilUmtOHFDRfasj() 
 def addon_noti(saGUquHKQexiXFftoWYyACDRMnOSLP,sting):
  try:
   saGUquHKQexiXFftoWYyACDRMnOSLw=xbmcgui.Dialog()
   saGUquHKQexiXFftoWYyACDRMnOSLw.notification(__addonname__,sting)
  except:
   saGUquHKQexiXFftoWYyACDRMnOScz
 def addon_log(saGUquHKQexiXFftoWYyACDRMnOSLP,string):
  try:
   saGUquHKQexiXFftoWYyACDRMnOSLv=string.encode('utf-8','ignore')
  except:
   saGUquHKQexiXFftoWYyACDRMnOSLv='addonException: addon_log'
  saGUquHKQexiXFftoWYyACDRMnOSLh=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,saGUquHKQexiXFftoWYyACDRMnOSLv),level=saGUquHKQexiXFftoWYyACDRMnOSLh)
 def get_settings_select_ott(saGUquHKQexiXFftoWYyACDRMnOSLP):
  saGUquHKQexiXFftoWYyACDRMnOSLb =saGUquHKQexiXFftoWYyACDRMnOScm if __addon__.getSetting('view_wavve')=='true' else saGUquHKQexiXFftoWYyACDRMnOSck
  saGUquHKQexiXFftoWYyACDRMnOSLd =saGUquHKQexiXFftoWYyACDRMnOScm if __addon__.getSetting('view_tving')=='true' else saGUquHKQexiXFftoWYyACDRMnOSck
  saGUquHKQexiXFftoWYyACDRMnOSLI =saGUquHKQexiXFftoWYyACDRMnOScm if __addon__.getSetting('view_watcha')=='true' else saGUquHKQexiXFftoWYyACDRMnOSck
  saGUquHKQexiXFftoWYyACDRMnOSLN=saGUquHKQexiXFftoWYyACDRMnOScm if __addon__.getSetting('view_coupang')=='true' else saGUquHKQexiXFftoWYyACDRMnOSck
  saGUquHKQexiXFftoWYyACDRMnOSLB=saGUquHKQexiXFftoWYyACDRMnOScm if __addon__.getSetting('view_netflix')=='true' else saGUquHKQexiXFftoWYyACDRMnOSck
  saGUquHKQexiXFftoWYyACDRMnOSLr =saGUquHKQexiXFftoWYyACDRMnOScm if __addon__.getSetting('view_primev')=='true' else saGUquHKQexiXFftoWYyACDRMnOSck
  saGUquHKQexiXFftoWYyACDRMnOSLT =saGUquHKQexiXFftoWYyACDRMnOScm if __addon__.getSetting('view_disney')=='true' else saGUquHKQexiXFftoWYyACDRMnOSck
  return(saGUquHKQexiXFftoWYyACDRMnOSLb,saGUquHKQexiXFftoWYyACDRMnOSLd,saGUquHKQexiXFftoWYyACDRMnOSLI,saGUquHKQexiXFftoWYyACDRMnOSLN,saGUquHKQexiXFftoWYyACDRMnOSLB,saGUquHKQexiXFftoWYyACDRMnOSLr,saGUquHKQexiXFftoWYyACDRMnOSLT)
 def make_Index_Filename(saGUquHKQexiXFftoWYyACDRMnOSLP,tempyn=saGUquHKQexiXFftoWYyACDRMnOSck):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_index_file.json'))
  else:
   return saGUquHKQexiXFftoWYyACDRMnOSLP.LIB_PATH+'bookmark_index.json'
 def make_Vinfo_Filename(saGUquHKQexiXFftoWYyACDRMnOSLP,saGUquHKQexiXFftoWYyACDRMnOSpL,saGUquHKQexiXFftoWYyACDRMnOSpJ,tempyn=saGUquHKQexiXFftoWYyACDRMnOSck):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_vinfo_file.json'))
  else:
   saGUquHKQexiXFftoWYyACDRMnOSLE='%s_%s.json'%(saGUquHKQexiXFftoWYyACDRMnOSpL,saGUquHKQexiXFftoWYyACDRMnOSpJ)
   return saGUquHKQexiXFftoWYyACDRMnOSLP.LIB_PATH+saGUquHKQexiXFftoWYyACDRMnOSLE
 def add_dir(saGUquHKQexiXFftoWYyACDRMnOSLP,label,sublabel='',ott='',img='',infoLabels=saGUquHKQexiXFftoWYyACDRMnOScz,isFolder=saGUquHKQexiXFftoWYyACDRMnOScm,params='',isLink=saGUquHKQexiXFftoWYyACDRMnOSck,ContextMenu=saGUquHKQexiXFftoWYyACDRMnOScz,direct_url=saGUquHKQexiXFftoWYyACDRMnOScz):
  if direct_url:
   saGUquHKQexiXFftoWYyACDRMnOSLg=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params,}
   saGUquHKQexiXFftoWYyACDRMnOSLl=json.dumps(params,separators=(',',':'))
   saGUquHKQexiXFftoWYyACDRMnOSLl=base64.standard_b64encode(saGUquHKQexiXFftoWYyACDRMnOSLl.encode()).decode('utf-8')
   saGUquHKQexiXFftoWYyACDRMnOSLl=saGUquHKQexiXFftoWYyACDRMnOSLl.replace('+','%2B')
   saGUquHKQexiXFftoWYyACDRMnOSLg='%s?params=%s'%(saGUquHKQexiXFftoWYyACDRMnOSLP._addon_url,saGUquHKQexiXFftoWYyACDRMnOSLl)
  if sublabel and sublabel!='-':saGUquHKQexiXFftoWYyACDRMnOSLj='%s < %s >'%(label,sublabel)
  else: saGUquHKQexiXFftoWYyACDRMnOSLj=label
  if not img:img='DefaultFolder.png'
  if ott:saGUquHKQexiXFftoWYyACDRMnOSLj='%s - [%s]'%(saGUquHKQexiXFftoWYyACDRMnOSLj,ott)
  saGUquHKQexiXFftoWYyACDRMnOSJL=xbmcgui.ListItem(saGUquHKQexiXFftoWYyACDRMnOSLj)
  if saGUquHKQexiXFftoWYyACDRMnOScw(img)==saGUquHKQexiXFftoWYyACDRMnOScv:
   saGUquHKQexiXFftoWYyACDRMnOSJL.setArt(img)
  else:
   saGUquHKQexiXFftoWYyACDRMnOSJL.setArt({'thumb':img,'poster':img})
  saGUquHKQexiXFftoWYyACDRMnOSJp=[]
  if infoLabels!=saGUquHKQexiXFftoWYyACDRMnOScz:
   if saGUquHKQexiXFftoWYyACDRMnOScw(infoLabels.get('cast'))==saGUquHKQexiXFftoWYyACDRMnOSch:
    if saGUquHKQexiXFftoWYyACDRMnOScb(infoLabels.get('cast'))>0 and saGUquHKQexiXFftoWYyACDRMnOScw(infoLabels.get('cast')[0])==saGUquHKQexiXFftoWYyACDRMnOScv:
     saGUquHKQexiXFftoWYyACDRMnOSJp=infoLabels.get('cast')
     infoLabels['cast']=[]
  if infoLabels:saGUquHKQexiXFftoWYyACDRMnOSJL.setInfo('Video',infoLabels)
  if saGUquHKQexiXFftoWYyACDRMnOScb(saGUquHKQexiXFftoWYyACDRMnOSJp)>0:saGUquHKQexiXFftoWYyACDRMnOSJL.setCast(saGUquHKQexiXFftoWYyACDRMnOSJp)
  if not isFolder and not isLink:
   saGUquHKQexiXFftoWYyACDRMnOSJL.setProperty('IsPlayable','true')
  if ContextMenu:saGUquHKQexiXFftoWYyACDRMnOSJL.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(saGUquHKQexiXFftoWYyACDRMnOSLP._addon_handle,saGUquHKQexiXFftoWYyACDRMnOSLg,saGUquHKQexiXFftoWYyACDRMnOSJL,isFolder)
 def dp_Main_List(saGUquHKQexiXFftoWYyACDRMnOSLP):
  (saGUquHKQexiXFftoWYyACDRMnOSLb,saGUquHKQexiXFftoWYyACDRMnOSLd,saGUquHKQexiXFftoWYyACDRMnOSLI,saGUquHKQexiXFftoWYyACDRMnOSLN,saGUquHKQexiXFftoWYyACDRMnOSLB,saGUquHKQexiXFftoWYyACDRMnOSLr,saGUquHKQexiXFftoWYyACDRMnOSLT)=saGUquHKQexiXFftoWYyACDRMnOSLP.get_settings_select_ott()
  for saGUquHKQexiXFftoWYyACDRMnOSJc in saGUquHKQexiXFftoWYyACDRMnOSLp:
   saGUquHKQexiXFftoWYyACDRMnOSLj=saGUquHKQexiXFftoWYyACDRMnOSJc.get('title')
   saGUquHKQexiXFftoWYyACDRMnOSJz=''
   if saGUquHKQexiXFftoWYyACDRMnOSJc.get('ott')=='wavve' and saGUquHKQexiXFftoWYyACDRMnOSLb ==saGUquHKQexiXFftoWYyACDRMnOSck:continue
   elif saGUquHKQexiXFftoWYyACDRMnOSJc.get('ott')=='tving' and saGUquHKQexiXFftoWYyACDRMnOSLd ==saGUquHKQexiXFftoWYyACDRMnOSck:continue
   elif saGUquHKQexiXFftoWYyACDRMnOSJc.get('ott')=='watcha' and saGUquHKQexiXFftoWYyACDRMnOSLI ==saGUquHKQexiXFftoWYyACDRMnOSck:continue
   elif saGUquHKQexiXFftoWYyACDRMnOSJc.get('ott')=='coupang' and saGUquHKQexiXFftoWYyACDRMnOSLN==saGUquHKQexiXFftoWYyACDRMnOSck:continue
   elif saGUquHKQexiXFftoWYyACDRMnOSJc.get('ott')=='netflix' and saGUquHKQexiXFftoWYyACDRMnOSLB==saGUquHKQexiXFftoWYyACDRMnOSck:continue
   elif saGUquHKQexiXFftoWYyACDRMnOSJc.get('ott')=='amazon' and saGUquHKQexiXFftoWYyACDRMnOSLr ==saGUquHKQexiXFftoWYyACDRMnOSck:continue
   elif saGUquHKQexiXFftoWYyACDRMnOSJc.get('ott')=='disney' and saGUquHKQexiXFftoWYyACDRMnOSLT ==saGUquHKQexiXFftoWYyACDRMnOSck:continue
   saGUquHKQexiXFftoWYyACDRMnOSLV={'mode':saGUquHKQexiXFftoWYyACDRMnOSJc.get('mode'),'ott':saGUquHKQexiXFftoWYyACDRMnOSJc.get('ott'),'vidtype':saGUquHKQexiXFftoWYyACDRMnOSJc.get('vidtype'),'page':'1',}
   if saGUquHKQexiXFftoWYyACDRMnOSJc.get('mode')=='XXX':
    saGUquHKQexiXFftoWYyACDRMnOSLV['mode']='XXX'
    saGUquHKQexiXFftoWYyACDRMnOSJm=saGUquHKQexiXFftoWYyACDRMnOSck
    saGUquHKQexiXFftoWYyACDRMnOSJk =saGUquHKQexiXFftoWYyACDRMnOScm
   else:
    if 'icon' in saGUquHKQexiXFftoWYyACDRMnOSJc:
     saGUquHKQexiXFftoWYyACDRMnOSJz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',saGUquHKQexiXFftoWYyACDRMnOSJc.get('icon')) 
    saGUquHKQexiXFftoWYyACDRMnOSJm=saGUquHKQexiXFftoWYyACDRMnOScm
    saGUquHKQexiXFftoWYyACDRMnOSJk =saGUquHKQexiXFftoWYyACDRMnOSck
   saGUquHKQexiXFftoWYyACDRMnOSLP.add_dir(saGUquHKQexiXFftoWYyACDRMnOSLj,sublabel='',ott='',img=saGUquHKQexiXFftoWYyACDRMnOSJz,infoLabels=saGUquHKQexiXFftoWYyACDRMnOScz,isFolder=saGUquHKQexiXFftoWYyACDRMnOSJm,params=saGUquHKQexiXFftoWYyACDRMnOSLV,isLink=saGUquHKQexiXFftoWYyACDRMnOSJk)
  xbmcplugin.endOfDirectory(saGUquHKQexiXFftoWYyACDRMnOSLP._addon_handle)
 def dp_Genre_Grouplist(saGUquHKQexiXFftoWYyACDRMnOSLP,args):
  saGUquHKQexiXFftoWYyACDRMnOSJv=[]
  saGUquHKQexiXFftoWYyACDRMnOSJh=saGUquHKQexiXFftoWYyACDRMnOSLP.make_Index_Filename(tempyn=saGUquHKQexiXFftoWYyACDRMnOSck)
  if xbmcvfs.exists(saGUquHKQexiXFftoWYyACDRMnOSJh):
   saGUquHKQexiXFftoWYyACDRMnOSJb=saGUquHKQexiXFftoWYyACDRMnOSLP.jsonfile_To_dic(saGUquHKQexiXFftoWYyACDRMnOSJh)
  else:
   saGUquHKQexiXFftoWYyACDRMnOSJb=[]
  for saGUquHKQexiXFftoWYyACDRMnOSJd in saGUquHKQexiXFftoWYyACDRMnOSJb:
   saGUquHKQexiXFftoWYyACDRMnOSJI =saGUquHKQexiXFftoWYyACDRMnOSJd.get('genre')
   if saGUquHKQexiXFftoWYyACDRMnOSJI not in saGUquHKQexiXFftoWYyACDRMnOSJv:
    saGUquHKQexiXFftoWYyACDRMnOSJv.append(saGUquHKQexiXFftoWYyACDRMnOSJI)
  for saGUquHKQexiXFftoWYyACDRMnOSJI in saGUquHKQexiXFftoWYyACDRMnOSJv:
   saGUquHKQexiXFftoWYyACDRMnOSLV={'mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','genre':saGUquHKQexiXFftoWYyACDRMnOSJI,'page':'1',}
   saGUquHKQexiXFftoWYyACDRMnOSLP.add_dir(saGUquHKQexiXFftoWYyACDRMnOSJI,sublabel='',ott='',img='',infoLabels=saGUquHKQexiXFftoWYyACDRMnOScz,isFolder=saGUquHKQexiXFftoWYyACDRMnOScm,params=saGUquHKQexiXFftoWYyACDRMnOSLV)
  xbmcplugin.endOfDirectory(saGUquHKQexiXFftoWYyACDRMnOSLP._addon_handle)
 def dp_Bookmark_Grouplist(saGUquHKQexiXFftoWYyACDRMnOSLP,args):
  saGUquHKQexiXFftoWYyACDRMnOSJN =saGUquHKQexiXFftoWYyACDRMnOSck
  saGUquHKQexiXFftoWYyACDRMnOSJB =[]
  saGUquHKQexiXFftoWYyACDRMnOSJr =args.get('ott')
  saGUquHKQexiXFftoWYyACDRMnOSJT=args.get('vidtype')
  saGUquHKQexiXFftoWYyACDRMnOSJE =args.get('genre')
  if saGUquHKQexiXFftoWYyACDRMnOSJE==saGUquHKQexiXFftoWYyACDRMnOScz:saGUquHKQexiXFftoWYyACDRMnOSJE='all'
  saGUquHKQexiXFftoWYyACDRMnOSJg =saGUquHKQexiXFftoWYyACDRMnOScd(args.get('page'))
  saGUquHKQexiXFftoWYyACDRMnOSJV =saGUquHKQexiXFftoWYyACDRMnOSLP.LIST_LIMIT*(saGUquHKQexiXFftoWYyACDRMnOSJg-1)+1 
  saGUquHKQexiXFftoWYyACDRMnOSJl =saGUquHKQexiXFftoWYyACDRMnOSLP.LIST_LIMIT*saGUquHKQexiXFftoWYyACDRMnOSJg
  saGUquHKQexiXFftoWYyACDRMnOSJh=saGUquHKQexiXFftoWYyACDRMnOSLP.make_Index_Filename(tempyn=saGUquHKQexiXFftoWYyACDRMnOSck)
  if xbmcvfs.exists(saGUquHKQexiXFftoWYyACDRMnOSJh):
   saGUquHKQexiXFftoWYyACDRMnOSJb=saGUquHKQexiXFftoWYyACDRMnOSLP.jsonfile_To_dic(saGUquHKQexiXFftoWYyACDRMnOSJh)
  else:
   saGUquHKQexiXFftoWYyACDRMnOSJb=[]
  saGUquHKQexiXFftoWYyACDRMnOSJj=0
  for saGUquHKQexiXFftoWYyACDRMnOSJd in saGUquHKQexiXFftoWYyACDRMnOSJb:
   saGUquHKQexiXFftoWYyACDRMnOSpL =saGUquHKQexiXFftoWYyACDRMnOSJd.get('ott')
   saGUquHKQexiXFftoWYyACDRMnOSpJ =saGUquHKQexiXFftoWYyACDRMnOSJd.get('videoid')
   saGUquHKQexiXFftoWYyACDRMnOSpP =saGUquHKQexiXFftoWYyACDRMnOSJd.get('vidtype')
   saGUquHKQexiXFftoWYyACDRMnOSpc =saGUquHKQexiXFftoWYyACDRMnOSJd.get('genre')
   saGUquHKQexiXFftoWYyACDRMnOSpz =saGUquHKQexiXFftoWYyACDRMnOSJd.get('linkUrl')
   saGUquHKQexiXFftoWYyACDRMnOSpm =saGUquHKQexiXFftoWYyACDRMnOSJd.get('encodedId')
   saGUquHKQexiXFftoWYyACDRMnOSpk =saGUquHKQexiXFftoWYyACDRMnOSJd.get('contentId')
   saGUquHKQexiXFftoWYyACDRMnOSpw=saGUquHKQexiXFftoWYyACDRMnOSJd.get('contentClass')
   saGUquHKQexiXFftoWYyACDRMnOSpv=saGUquHKQexiXFftoWYyACDRMnOSJd.get('contentSlugs')
   saGUquHKQexiXFftoWYyACDRMnOSph =saGUquHKQexiXFftoWYyACDRMnOSJd.get('entityId')
   if not(saGUquHKQexiXFftoWYyACDRMnOSJr=='-' or saGUquHKQexiXFftoWYyACDRMnOSJr==saGUquHKQexiXFftoWYyACDRMnOSpL):continue
   if not(saGUquHKQexiXFftoWYyACDRMnOSJT=='-' or saGUquHKQexiXFftoWYyACDRMnOSJT==saGUquHKQexiXFftoWYyACDRMnOSpP):continue
   if not(saGUquHKQexiXFftoWYyACDRMnOSJE=='all' or saGUquHKQexiXFftoWYyACDRMnOSJE==saGUquHKQexiXFftoWYyACDRMnOSpc):continue
   saGUquHKQexiXFftoWYyACDRMnOSJj+=1
   if saGUquHKQexiXFftoWYyACDRMnOSJV>saGUquHKQexiXFftoWYyACDRMnOSJj:continue
   if saGUquHKQexiXFftoWYyACDRMnOSJl<saGUquHKQexiXFftoWYyACDRMnOSJj:
    saGUquHKQexiXFftoWYyACDRMnOSJN=saGUquHKQexiXFftoWYyACDRMnOScm
    break
   saGUquHKQexiXFftoWYyACDRMnOSpb=saGUquHKQexiXFftoWYyACDRMnOSLP.make_Vinfo_Filename(saGUquHKQexiXFftoWYyACDRMnOSpL,saGUquHKQexiXFftoWYyACDRMnOSpJ,tempyn=saGUquHKQexiXFftoWYyACDRMnOSck)
   if xbmcvfs.exists(saGUquHKQexiXFftoWYyACDRMnOSpb):
    saGUquHKQexiXFftoWYyACDRMnOSpd=saGUquHKQexiXFftoWYyACDRMnOSLP.jsonfile_To_dic(saGUquHKQexiXFftoWYyACDRMnOSpb)
    saGUquHKQexiXFftoWYyACDRMnOSLj =saGUquHKQexiXFftoWYyACDRMnOSpd.get('title')
    saGUquHKQexiXFftoWYyACDRMnOSpI =saGUquHKQexiXFftoWYyACDRMnOSpd.get('subtitle')
    saGUquHKQexiXFftoWYyACDRMnOSpN =saGUquHKQexiXFftoWYyACDRMnOSpd.get('thumbnail')
    saGUquHKQexiXFftoWYyACDRMnOSJP=saGUquHKQexiXFftoWYyACDRMnOSpd.get('infoLabels')
   else:
    saGUquHKQexiXFftoWYyACDRMnOSLj =saGUquHKQexiXFftoWYyACDRMnOSJd.get('title')
    saGUquHKQexiXFftoWYyACDRMnOSpI =''
    saGUquHKQexiXFftoWYyACDRMnOSpN =''
    saGUquHKQexiXFftoWYyACDRMnOSJP={'mpaa':'0'}
    saGUquHKQexiXFftoWYyACDRMnOSpd ={'infoLabels':{'title':saGUquHKQexiXFftoWYyACDRMnOSLj}}
   saGUquHKQexiXFftoWYyACDRMnOSLV={'ott':saGUquHKQexiXFftoWYyACDRMnOSpL,'videoid':saGUquHKQexiXFftoWYyACDRMnOSpJ,'vidtype':saGUquHKQexiXFftoWYyACDRMnOSpP,'title':saGUquHKQexiXFftoWYyACDRMnOSLj,'thumbnail':saGUquHKQexiXFftoWYyACDRMnOSpN,'mpaa':saGUquHKQexiXFftoWYyACDRMnOScI(saGUquHKQexiXFftoWYyACDRMnOSJP.get('mpaa')),'duration':saGUquHKQexiXFftoWYyACDRMnOScI(saGUquHKQexiXFftoWYyACDRMnOSJP.get('duration')),'linkUrl':saGUquHKQexiXFftoWYyACDRMnOSpz,'infoLabels':saGUquHKQexiXFftoWYyACDRMnOSJP,'encodedId':saGUquHKQexiXFftoWYyACDRMnOSpm,'contentId':saGUquHKQexiXFftoWYyACDRMnOSpk,'contentClass':saGUquHKQexiXFftoWYyACDRMnOSpw,'contentSlugs':saGUquHKQexiXFftoWYyACDRMnOSpv,'entityId':saGUquHKQexiXFftoWYyACDRMnOSph,}
   saGUquHKQexiXFftoWYyACDRMnOSpB={'mode':'BOOKMARK_REMOVE','list':[saGUquHKQexiXFftoWYyACDRMnOSJd],}
   saGUquHKQexiXFftoWYyACDRMnOSpr=urllib.parse.urlencode(saGUquHKQexiXFftoWYyACDRMnOSpB)
   saGUquHKQexiXFftoWYyACDRMnOSpT=[('찜 목록 ( %s ) 삭제'%(saGUquHKQexiXFftoWYyACDRMnOSpd.get('infoLabels').get('title')),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(saGUquHKQexiXFftoWYyACDRMnOSpr))]
   if saGUquHKQexiXFftoWYyACDRMnOSJE!='all':
    saGUquHKQexiXFftoWYyACDRMnOSpB={'mode':'GENRE_RENAME','list':[saGUquHKQexiXFftoWYyACDRMnOSJd],}
    saGUquHKQexiXFftoWYyACDRMnOSpr=urllib.parse.urlencode(saGUquHKQexiXFftoWYyACDRMnOSpB)
    saGUquHKQexiXFftoWYyACDRMnOSpT.append(('장르명 ( %s ) 수정'%(saGUquHKQexiXFftoWYyACDRMnOSJE),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(saGUquHKQexiXFftoWYyACDRMnOSpr)))
   saGUquHKQexiXFftoWYyACDRMnOSpE=saGUquHKQexiXFftoWYyACDRMnOSLP.make_Hyper_Link(saGUquHKQexiXFftoWYyACDRMnOSLV)
   if saGUquHKQexiXFftoWYyACDRMnOSpP=='tvshow':
    saGUquHKQexiXFftoWYyACDRMnOSJm=saGUquHKQexiXFftoWYyACDRMnOScm
   else:
    saGUquHKQexiXFftoWYyACDRMnOSJm=saGUquHKQexiXFftoWYyACDRMnOSck
   saGUquHKQexiXFftoWYyACDRMnOSLP.add_dir(saGUquHKQexiXFftoWYyACDRMnOSLj,sublabel=saGUquHKQexiXFftoWYyACDRMnOSpI,ott=saGUquHKQexiXFftoWYyACDRMnOSpL,img=saGUquHKQexiXFftoWYyACDRMnOSpN,infoLabels=saGUquHKQexiXFftoWYyACDRMnOSJP,isFolder=saGUquHKQexiXFftoWYyACDRMnOSJm,params=saGUquHKQexiXFftoWYyACDRMnOScz,isLink=saGUquHKQexiXFftoWYyACDRMnOSck,ContextMenu=saGUquHKQexiXFftoWYyACDRMnOSpT,direct_url=saGUquHKQexiXFftoWYyACDRMnOSpE)
   saGUquHKQexiXFftoWYyACDRMnOSJB.append(saGUquHKQexiXFftoWYyACDRMnOSJd)
  saGUquHKQexiXFftoWYyACDRMnOSpg={'plot':'현재페이지의 전체목록을 삭제합니다.'}
  saGUquHKQexiXFftoWYyACDRMnOSLj='* 현재페이지 목록 삭제 (개별삭제는 팝업메뉴) *'
  saGUquHKQexiXFftoWYyACDRMnOSLV={'mode':'BOOKMARK_REMOVE','list':saGUquHKQexiXFftoWYyACDRMnOSJB,}
  saGUquHKQexiXFftoWYyACDRMnOSJz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  saGUquHKQexiXFftoWYyACDRMnOSLP.add_dir(saGUquHKQexiXFftoWYyACDRMnOSLj,sublabel='',ott='',img=saGUquHKQexiXFftoWYyACDRMnOSJz,infoLabels=saGUquHKQexiXFftoWYyACDRMnOSpg,isFolder=saGUquHKQexiXFftoWYyACDRMnOSck,params=saGUquHKQexiXFftoWYyACDRMnOSLV,isLink=saGUquHKQexiXFftoWYyACDRMnOScm)
  if saGUquHKQexiXFftoWYyACDRMnOSJN:
   saGUquHKQexiXFftoWYyACDRMnOSLV={'mode':'BOOKMARK_GROUP','ott':saGUquHKQexiXFftoWYyACDRMnOSJr,'vidtype':saGUquHKQexiXFftoWYyACDRMnOSJT,'page':saGUquHKQexiXFftoWYyACDRMnOScI(saGUquHKQexiXFftoWYyACDRMnOSJg+1)}
   saGUquHKQexiXFftoWYyACDRMnOSLj='[B]%s >>[/B]'%'다음 페이지'
   saGUquHKQexiXFftoWYyACDRMnOSpI=saGUquHKQexiXFftoWYyACDRMnOScI(saGUquHKQexiXFftoWYyACDRMnOSJg+1)
   saGUquHKQexiXFftoWYyACDRMnOSJz=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   saGUquHKQexiXFftoWYyACDRMnOSLP.add_dir(saGUquHKQexiXFftoWYyACDRMnOSLj,sublabel=saGUquHKQexiXFftoWYyACDRMnOSpI,ott='',img=saGUquHKQexiXFftoWYyACDRMnOSJz,infoLabels=saGUquHKQexiXFftoWYyACDRMnOScz,isFolder=saGUquHKQexiXFftoWYyACDRMnOScm,params=saGUquHKQexiXFftoWYyACDRMnOSLV)
  xbmcplugin.setContent(saGUquHKQexiXFftoWYyACDRMnOSLP._addon_handle,'movies')
  xbmcplugin.endOfDirectory(saGUquHKQexiXFftoWYyACDRMnOSLP._addon_handle)
 def get_keyboard_input(saGUquHKQexiXFftoWYyACDRMnOSLP,defalut,saGUquHKQexiXFftoWYyACDRMnOSLj):
  saGUquHKQexiXFftoWYyACDRMnOSpV=saGUquHKQexiXFftoWYyACDRMnOScz
  kb=xbmc.Keyboard(defalut,saGUquHKQexiXFftoWYyACDRMnOSLj,saGUquHKQexiXFftoWYyACDRMnOSck)
  kb.setHeading(saGUquHKQexiXFftoWYyACDRMnOSLj)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   saGUquHKQexiXFftoWYyACDRMnOSpV=kb.getText()
  return saGUquHKQexiXFftoWYyACDRMnOSpV
 def dp_Genre_Rename(saGUquHKQexiXFftoWYyACDRMnOSLP,args):
  saGUquHKQexiXFftoWYyACDRMnOSpl =saGUquHKQexiXFftoWYyACDRMnOScm
  saGUquHKQexiXFftoWYyACDRMnOSpj ={}
  try:
   saGUquHKQexiXFftoWYyACDRMnOSPL=args.get('list')
   saGUquHKQexiXFftoWYyACDRMnOSPL=saGUquHKQexiXFftoWYyACDRMnOSPL.replace('\'','\"')
   saGUquHKQexiXFftoWYyACDRMnOSPL=json.loads(saGUquHKQexiXFftoWYyACDRMnOSPL)
  except:
   saGUquHKQexiXFftoWYyACDRMnOSpl=saGUquHKQexiXFftoWYyACDRMnOSck
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   if saGUquHKQexiXFftoWYyACDRMnOScb(saGUquHKQexiXFftoWYyACDRMnOSPL)!=0:
    saGUquHKQexiXFftoWYyACDRMnOSPJ=saGUquHKQexiXFftoWYyACDRMnOSPL[0].get('genre')
   else:
    return
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSPp=saGUquHKQexiXFftoWYyACDRMnOSLP.get_keyboard_input(saGUquHKQexiXFftoWYyACDRMnOSPJ,__language__(30909).encode('utf-8'))
   if saGUquHKQexiXFftoWYyACDRMnOSPp!=saGUquHKQexiXFftoWYyACDRMnOScz:
    saGUquHKQexiXFftoWYyACDRMnOSPp=saGUquHKQexiXFftoWYyACDRMnOSPp.strip()
   else:
    return
   if saGUquHKQexiXFftoWYyACDRMnOSPJ==saGUquHKQexiXFftoWYyACDRMnOSPp:
    saGUquHKQexiXFftoWYyACDRMnOSLP.addon_noti(__language__(30910).encode('utf-8'))
    return
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   for saGUquHKQexiXFftoWYyACDRMnOSPc in saGUquHKQexiXFftoWYyACDRMnOSPL:
    if saGUquHKQexiXFftoWYyACDRMnOSPc['ott']in saGUquHKQexiXFftoWYyACDRMnOSpj:
     saGUquHKQexiXFftoWYyACDRMnOSpj[saGUquHKQexiXFftoWYyACDRMnOSPc['ott']].append(saGUquHKQexiXFftoWYyACDRMnOSPc['videoid'])
    else:
     saGUquHKQexiXFftoWYyACDRMnOSpj[saGUquHKQexiXFftoWYyACDRMnOSPc['ott']]=[saGUquHKQexiXFftoWYyACDRMnOSPc['videoid']]
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSJh=saGUquHKQexiXFftoWYyACDRMnOSLP.make_Index_Filename(tempyn=saGUquHKQexiXFftoWYyACDRMnOSck)
   if xbmcvfs.exists(saGUquHKQexiXFftoWYyACDRMnOSJh):
    saGUquHKQexiXFftoWYyACDRMnOSJb=saGUquHKQexiXFftoWYyACDRMnOSLP.jsonfile_To_dic(saGUquHKQexiXFftoWYyACDRMnOSJh)
   else:
    saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOSck
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   for i in saGUquHKQexiXFftoWYyACDRMnOScN(saGUquHKQexiXFftoWYyACDRMnOScb(saGUquHKQexiXFftoWYyACDRMnOSJb)):
    saGUquHKQexiXFftoWYyACDRMnOSPz =saGUquHKQexiXFftoWYyACDRMnOSJb[i].get('ott')
    saGUquHKQexiXFftoWYyACDRMnOSPm=saGUquHKQexiXFftoWYyACDRMnOSJb[i].get('videoid')
    if saGUquHKQexiXFftoWYyACDRMnOSPz in saGUquHKQexiXFftoWYyACDRMnOSpj:
     if saGUquHKQexiXFftoWYyACDRMnOSPm in saGUquHKQexiXFftoWYyACDRMnOSpj[saGUquHKQexiXFftoWYyACDRMnOSPz]:
      saGUquHKQexiXFftoWYyACDRMnOSJb[i]['genre']=saGUquHKQexiXFftoWYyACDRMnOSPp
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSpl=saGUquHKQexiXFftoWYyACDRMnOSLP.dic_To_jsonfile(saGUquHKQexiXFftoWYyACDRMnOSJh,saGUquHKQexiXFftoWYyACDRMnOSJb)
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSLP.addon_noti(__language__(30911).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   saGUquHKQexiXFftoWYyACDRMnOSLP.addon_noti(__language__(30912).encode('utf-8'))
 def dp_Bookmark_Remove(saGUquHKQexiXFftoWYyACDRMnOSLP,args):
  saGUquHKQexiXFftoWYyACDRMnOSpl =saGUquHKQexiXFftoWYyACDRMnOScm
  saGUquHKQexiXFftoWYyACDRMnOSPk ={}
  saGUquHKQexiXFftoWYyACDRMnOSLw=xbmcgui.Dialog()
  saGUquHKQexiXFftoWYyACDRMnOSPw=saGUquHKQexiXFftoWYyACDRMnOSLw.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if saGUquHKQexiXFftoWYyACDRMnOSPw==saGUquHKQexiXFftoWYyACDRMnOSck:sys.exit()
  try:
   saGUquHKQexiXFftoWYyACDRMnOSPL=args.get('list')
   saGUquHKQexiXFftoWYyACDRMnOSPL=saGUquHKQexiXFftoWYyACDRMnOSPL.replace('\'','\"')
   saGUquHKQexiXFftoWYyACDRMnOSPL=json.loads(saGUquHKQexiXFftoWYyACDRMnOSPL)
  except:
   saGUquHKQexiXFftoWYyACDRMnOSpl=saGUquHKQexiXFftoWYyACDRMnOSck
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   for saGUquHKQexiXFftoWYyACDRMnOSPc in saGUquHKQexiXFftoWYyACDRMnOSPL:
    if saGUquHKQexiXFftoWYyACDRMnOSPc['ott']in saGUquHKQexiXFftoWYyACDRMnOSPk:
     saGUquHKQexiXFftoWYyACDRMnOSPk[saGUquHKQexiXFftoWYyACDRMnOSPc['ott']].append(saGUquHKQexiXFftoWYyACDRMnOSPc['videoid'])
    else:
     saGUquHKQexiXFftoWYyACDRMnOSPk[saGUquHKQexiXFftoWYyACDRMnOSPc['ott']]=[saGUquHKQexiXFftoWYyACDRMnOSPc['videoid']]
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSJh=saGUquHKQexiXFftoWYyACDRMnOSLP.make_Index_Filename(tempyn=saGUquHKQexiXFftoWYyACDRMnOSck)
   if xbmcvfs.exists(saGUquHKQexiXFftoWYyACDRMnOSJh):
    saGUquHKQexiXFftoWYyACDRMnOSJb=saGUquHKQexiXFftoWYyACDRMnOSLP.jsonfile_To_dic(saGUquHKQexiXFftoWYyACDRMnOSJh)
   else:
    saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOSck
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSJd=[]
   for saGUquHKQexiXFftoWYyACDRMnOSPv in saGUquHKQexiXFftoWYyACDRMnOSJb:
    saGUquHKQexiXFftoWYyACDRMnOSPz =saGUquHKQexiXFftoWYyACDRMnOSPv.get('ott')
    saGUquHKQexiXFftoWYyACDRMnOSPm=saGUquHKQexiXFftoWYyACDRMnOSPv.get('videoid')
    if saGUquHKQexiXFftoWYyACDRMnOSPz in saGUquHKQexiXFftoWYyACDRMnOSPk:
     if saGUquHKQexiXFftoWYyACDRMnOSPm in saGUquHKQexiXFftoWYyACDRMnOSPk[saGUquHKQexiXFftoWYyACDRMnOSPz]:
      saGUquHKQexiXFftoWYyACDRMnOSpb=saGUquHKQexiXFftoWYyACDRMnOSLP.make_Vinfo_Filename(saGUquHKQexiXFftoWYyACDRMnOSPz,saGUquHKQexiXFftoWYyACDRMnOSPm,tempyn=saGUquHKQexiXFftoWYyACDRMnOSck)
      xbmcvfs.delete(saGUquHKQexiXFftoWYyACDRMnOSpb)
      continue
    saGUquHKQexiXFftoWYyACDRMnOSJd.append(saGUquHKQexiXFftoWYyACDRMnOSPv)
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOScz
   saGUquHKQexiXFftoWYyACDRMnOSpl=saGUquHKQexiXFftoWYyACDRMnOSLP.dic_To_jsonfile(saGUquHKQexiXFftoWYyACDRMnOSJh,saGUquHKQexiXFftoWYyACDRMnOSJd)
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSLP.addon_noti(__language__(30908).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   saGUquHKQexiXFftoWYyACDRMnOSLP.addon_noti(__language__(30907).encode('utf-8'))
 def make_Hyper_Link(saGUquHKQexiXFftoWYyACDRMnOSLP,args):
  saGUquHKQexiXFftoWYyACDRMnOSpE=''
  saGUquHKQexiXFftoWYyACDRMnOSpL =args.get('ott')
  saGUquHKQexiXFftoWYyACDRMnOSpJ =args.get('videoid')
  saGUquHKQexiXFftoWYyACDRMnOSpP =args.get('vidtype')
  saGUquHKQexiXFftoWYyACDRMnOSLj =args.get('title')
  saGUquHKQexiXFftoWYyACDRMnOSpN =args.get('thumbnail')
  saGUquHKQexiXFftoWYyACDRMnOSPh =args.get('mpaa')
  saGUquHKQexiXFftoWYyACDRMnOSpz =args.get('linkUrl')
  saGUquHKQexiXFftoWYyACDRMnOSPb =args.get('duration')
  saGUquHKQexiXFftoWYyACDRMnOSJP =args.get('infoLabels')
  saGUquHKQexiXFftoWYyACDRMnOSpm =args.get('encodedId')
  saGUquHKQexiXFftoWYyACDRMnOSpk =args.get('contentId')
  saGUquHKQexiXFftoWYyACDRMnOSpw=args.get('contentClass')
  saGUquHKQexiXFftoWYyACDRMnOSpv=args.get('contentSlugs')
  saGUquHKQexiXFftoWYyACDRMnOSph =args.get('entityId')
  if saGUquHKQexiXFftoWYyACDRMnOSpL=='wavve':
   if saGUquHKQexiXFftoWYyACDRMnOSpP=='tvshow':
    saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'SEASON_LIST','videoid':saGUquHKQexiXFftoWYyACDRMnOSpJ,'vidtype':saGUquHKQexiXFftoWYyACDRMnOSpP,}
   else:
    saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'MOVIE','contentid':saGUquHKQexiXFftoWYyACDRMnOSpJ,'title':saGUquHKQexiXFftoWYyACDRMnOSLj,'thumbnail':saGUquHKQexiXFftoWYyACDRMnOSpN,'age':saGUquHKQexiXFftoWYyACDRMnOSPh,}
   saGUquHKQexiXFftoWYyACDRMnOSPI=urllib.parse.urlencode(saGUquHKQexiXFftoWYyACDRMnOSPd)
   saGUquHKQexiXFftoWYyACDRMnOSpE='plugin://plugin.video.wavvem/?'
   saGUquHKQexiXFftoWYyACDRMnOSpE+=saGUquHKQexiXFftoWYyACDRMnOSPI
  elif saGUquHKQexiXFftoWYyACDRMnOSpL=='tving':
   if saGUquHKQexiXFftoWYyACDRMnOSpP=='tvshow':
    saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'EPISODE','programcode':saGUquHKQexiXFftoWYyACDRMnOSpJ,'page':'1',}
   else:
    saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'MOVIE','stype':'movie','mediacode':saGUquHKQexiXFftoWYyACDRMnOSpJ,'title':saGUquHKQexiXFftoWYyACDRMnOSLj,'thumbnail':saGUquHKQexiXFftoWYyACDRMnOSpN,}
   saGUquHKQexiXFftoWYyACDRMnOSPI=urllib.parse.urlencode(saGUquHKQexiXFftoWYyACDRMnOSPd)
   saGUquHKQexiXFftoWYyACDRMnOSpE='plugin://plugin.video.tvingm/?'
   saGUquHKQexiXFftoWYyACDRMnOSpE+=saGUquHKQexiXFftoWYyACDRMnOSPI
  elif saGUquHKQexiXFftoWYyACDRMnOSpL=='watcha':
   if saGUquHKQexiXFftoWYyACDRMnOSpP=='tvshow':
    saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'EPISODE','movie_code':saGUquHKQexiXFftoWYyACDRMnOSpJ,'season_code':saGUquHKQexiXFftoWYyACDRMnOSpJ,'page':'1',}
   else:
    saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'MOVIE','movie_code':saGUquHKQexiXFftoWYyACDRMnOSpJ,'season_code':'-','title':saGUquHKQexiXFftoWYyACDRMnOSLj,'thumbnail':saGUquHKQexiXFftoWYyACDRMnOSpN,}
   saGUquHKQexiXFftoWYyACDRMnOSPI=urllib.parse.urlencode(saGUquHKQexiXFftoWYyACDRMnOSPd)
   saGUquHKQexiXFftoWYyACDRMnOSpE='plugin://plugin.video.watcham/?'
   saGUquHKQexiXFftoWYyACDRMnOSpE+=saGUquHKQexiXFftoWYyACDRMnOSPI
  elif saGUquHKQexiXFftoWYyACDRMnOSpL=='coupang':
   if saGUquHKQexiXFftoWYyACDRMnOSpP=='tvshow':
    saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'SEASON_LIST','id':saGUquHKQexiXFftoWYyACDRMnOSpJ,'asis':'TVSHOW','title':saGUquHKQexiXFftoWYyACDRMnOSLj,'thumbnail':saGUquHKQexiXFftoWYyACDRMnOSpN,'page':'1',}
   else:
    saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'MOVIE','id':saGUquHKQexiXFftoWYyACDRMnOSpJ,'asis':'MOVIE','title':saGUquHKQexiXFftoWYyACDRMnOSLj,'thumbnail':saGUquHKQexiXFftoWYyACDRMnOSpN,}
   saGUquHKQexiXFftoWYyACDRMnOSPI=urllib.parse.urlencode(saGUquHKQexiXFftoWYyACDRMnOSPd)
   saGUquHKQexiXFftoWYyACDRMnOSpE='plugin://plugin.video.coupangm/?'
   saGUquHKQexiXFftoWYyACDRMnOSpE+=saGUquHKQexiXFftoWYyACDRMnOSPI
  elif saGUquHKQexiXFftoWYyACDRMnOSpL=='netflix':
   if saGUquHKQexiXFftoWYyACDRMnOSpP=='tvshow':
    saGUquHKQexiXFftoWYyACDRMnOSpE='plugin://plugin.video.netflix/directory/show/%s/'%(saGUquHKQexiXFftoWYyACDRMnOSpJ)
   else:
    saGUquHKQexiXFftoWYyACDRMnOSpE='plugin://plugin.video.netflix/play/movie/%s/'%(saGUquHKQexiXFftoWYyACDRMnOSpJ)
  elif saGUquHKQexiXFftoWYyACDRMnOSpL=='amazon':
   if saGUquHKQexiXFftoWYyACDRMnOSpP=='tvshow':
    saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'SEASON_LIST','values':{'titleID':saGUquHKQexiXFftoWYyACDRMnOSpJ,'linkUrl':saGUquHKQexiXFftoWYyACDRMnOSpz,'duration':saGUquHKQexiXFftoWYyACDRMnOSPb,'vType':saGUquHKQexiXFftoWYyACDRMnOSpP,'image':saGUquHKQexiXFftoWYyACDRMnOSpN,'title':saGUquHKQexiXFftoWYyACDRMnOSLj,'infoLabels':saGUquHKQexiXFftoWYyACDRMnOSJP,}}
   else:
    saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'MOVIE','values':{'titleID':saGUquHKQexiXFftoWYyACDRMnOSpJ,'linkUrl':saGUquHKQexiXFftoWYyACDRMnOSpz,'duration':saGUquHKQexiXFftoWYyACDRMnOSPb,'vType':saGUquHKQexiXFftoWYyACDRMnOSpP,'image':saGUquHKQexiXFftoWYyACDRMnOSpN,'title':saGUquHKQexiXFftoWYyACDRMnOSLj,'infoLabels':saGUquHKQexiXFftoWYyACDRMnOSJP,}}
   saGUquHKQexiXFftoWYyACDRMnOSPI=json.dumps(saGUquHKQexiXFftoWYyACDRMnOSPd,separators=(',',':'))
   saGUquHKQexiXFftoWYyACDRMnOSPI=base64.standard_b64encode(saGUquHKQexiXFftoWYyACDRMnOSPI.encode()).decode('utf-8')
   saGUquHKQexiXFftoWYyACDRMnOSPI=saGUquHKQexiXFftoWYyACDRMnOSPI.replace('+','%2B')
   saGUquHKQexiXFftoWYyACDRMnOSpE='plugin://plugin.video.primevm/?params='
   saGUquHKQexiXFftoWYyACDRMnOSpE+=saGUquHKQexiXFftoWYyACDRMnOSPI
  elif saGUquHKQexiXFftoWYyACDRMnOSpL=='disney':
   if saGUquHKQexiXFftoWYyACDRMnOSpP=='tvshow':
    if saGUquHKQexiXFftoWYyACDRMnOSph: 
     saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'SEASON_LIST','values':{'entityId':saGUquHKQexiXFftoWYyACDRMnOSph,'vType':saGUquHKQexiXFftoWYyACDRMnOSpP,'image':saGUquHKQexiXFftoWYyACDRMnOSpN,'title':saGUquHKQexiXFftoWYyACDRMnOSLj,'programTitle':saGUquHKQexiXFftoWYyACDRMnOSLj,'infoLabels':saGUquHKQexiXFftoWYyACDRMnOSJP,}}
    elif saGUquHKQexiXFftoWYyACDRMnOSpm:
     saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'SEASON_LIST','values':{'encodedId':saGUquHKQexiXFftoWYyACDRMnOSpm,'vType':saGUquHKQexiXFftoWYyACDRMnOSpP,'image':saGUquHKQexiXFftoWYyACDRMnOSpN,'title':saGUquHKQexiXFftoWYyACDRMnOSLj,'programTitle':saGUquHKQexiXFftoWYyACDRMnOSLj,'infoLabels':saGUquHKQexiXFftoWYyACDRMnOSJP,}}
    else:
     saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'PROGRAM_LIST','values':{'contentClass':saGUquHKQexiXFftoWYyACDRMnOSpw,'contentSlugs':saGUquHKQexiXFftoWYyACDRMnOSpv,'vType':saGUquHKQexiXFftoWYyACDRMnOSpP,'image':saGUquHKQexiXFftoWYyACDRMnOSpN,'title':saGUquHKQexiXFftoWYyACDRMnOSLj,'programTitle':saGUquHKQexiXFftoWYyACDRMnOSLj,'infoLabels':saGUquHKQexiXFftoWYyACDRMnOSJP,}}
   else:
    saGUquHKQexiXFftoWYyACDRMnOSPd={'mode':'MOVIE','values':{'contentId':saGUquHKQexiXFftoWYyACDRMnOSpk,'vType':saGUquHKQexiXFftoWYyACDRMnOSpP,'image':saGUquHKQexiXFftoWYyACDRMnOSpN,'title':saGUquHKQexiXFftoWYyACDRMnOSJP['title'],'programTitle':saGUquHKQexiXFftoWYyACDRMnOSJP['title'],'infoLabels':saGUquHKQexiXFftoWYyACDRMnOSJP,'entityId':saGUquHKQexiXFftoWYyACDRMnOSph,}}
   saGUquHKQexiXFftoWYyACDRMnOSPI=json.dumps(saGUquHKQexiXFftoWYyACDRMnOSPd,separators=(',',':'))
   saGUquHKQexiXFftoWYyACDRMnOSPI=base64.standard_b64encode(saGUquHKQexiXFftoWYyACDRMnOSPI.encode()).decode('utf-8')
   saGUquHKQexiXFftoWYyACDRMnOSPI=saGUquHKQexiXFftoWYyACDRMnOSPI.replace('+','%2B')
   saGUquHKQexiXFftoWYyACDRMnOSpE='plugin://plugin.video.disneym/?params='
   saGUquHKQexiXFftoWYyACDRMnOSpE+=saGUquHKQexiXFftoWYyACDRMnOSPI
  return saGUquHKQexiXFftoWYyACDRMnOSpE
 def dp_Set_Bookmark(saGUquHKQexiXFftoWYyACDRMnOSLP,args):
  saGUquHKQexiXFftoWYyACDRMnOSpl =saGUquHKQexiXFftoWYyACDRMnOScm
  saGUquHKQexiXFftoWYyACDRMnOSJb=[]
  saGUquHKQexiXFftoWYyACDRMnOSPN=args.get('VIDEO_INFO')
  if saGUquHKQexiXFftoWYyACDRMnOSPN:
   saGUquHKQexiXFftoWYyACDRMnOSJd=saGUquHKQexiXFftoWYyACDRMnOSPN.get('indexinfo')
   saGUquHKQexiXFftoWYyACDRMnOSpd =saGUquHKQexiXFftoWYyACDRMnOSPN.get('saveinfo')
  else:
   saGUquHKQexiXFftoWYyACDRMnOSPB =urllib.parse.unquote(args.get('bm_param'))
   saGUquHKQexiXFftoWYyACDRMnOSPB =json.loads(saGUquHKQexiXFftoWYyACDRMnOSPB)
   saGUquHKQexiXFftoWYyACDRMnOSJd=saGUquHKQexiXFftoWYyACDRMnOSPB.get('indexinfo')
   saGUquHKQexiXFftoWYyACDRMnOSpd =saGUquHKQexiXFftoWYyACDRMnOSPB.get('saveinfo')
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSpb=saGUquHKQexiXFftoWYyACDRMnOSLP.make_Vinfo_Filename(saGUquHKQexiXFftoWYyACDRMnOSJd.get('ott'),saGUquHKQexiXFftoWYyACDRMnOSJd.get('videoid'),tempyn=saGUquHKQexiXFftoWYyACDRMnOSck)
   saGUquHKQexiXFftoWYyACDRMnOSpl=saGUquHKQexiXFftoWYyACDRMnOSLP.dic_To_jsonfile(saGUquHKQexiXFftoWYyACDRMnOSpb,saGUquHKQexiXFftoWYyACDRMnOSpd)
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSJh=saGUquHKQexiXFftoWYyACDRMnOSLP.make_Index_Filename(tempyn=saGUquHKQexiXFftoWYyACDRMnOSck)
   if xbmcvfs.exists(saGUquHKQexiXFftoWYyACDRMnOSJh):
    saGUquHKQexiXFftoWYyACDRMnOSJb=saGUquHKQexiXFftoWYyACDRMnOSLP.jsonfile_To_dic(saGUquHKQexiXFftoWYyACDRMnOSJh)
   else:
    saGUquHKQexiXFftoWYyACDRMnOSJb=[]
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSPr =saGUquHKQexiXFftoWYyACDRMnOSJd.get('ott')
   saGUquHKQexiXFftoWYyACDRMnOSPT =saGUquHKQexiXFftoWYyACDRMnOSJd.get('videoid')
   for i in saGUquHKQexiXFftoWYyACDRMnOScN(saGUquHKQexiXFftoWYyACDRMnOScb(saGUquHKQexiXFftoWYyACDRMnOSJb)):
    saGUquHKQexiXFftoWYyACDRMnOSPz =saGUquHKQexiXFftoWYyACDRMnOSJb[i].get('ott')
    saGUquHKQexiXFftoWYyACDRMnOSPm=saGUquHKQexiXFftoWYyACDRMnOSJb[i].get('videoid')
    if saGUquHKQexiXFftoWYyACDRMnOSPr==saGUquHKQexiXFftoWYyACDRMnOSPz and saGUquHKQexiXFftoWYyACDRMnOSPT==saGUquHKQexiXFftoWYyACDRMnOSPm:
     saGUquHKQexiXFftoWYyACDRMnOSJb.pop(i)
     break
   saGUquHKQexiXFftoWYyACDRMnOSJd['title']=saGUquHKQexiXFftoWYyACDRMnOSpd.get('title')
   if saGUquHKQexiXFftoWYyACDRMnOScb(saGUquHKQexiXFftoWYyACDRMnOSpd.get('infoLabels').get('genre'))>0:
    saGUquHKQexiXFftoWYyACDRMnOSJd['genre']=saGUquHKQexiXFftoWYyACDRMnOSpd.get('infoLabels').get('genre')[0]
   else:
    saGUquHKQexiXFftoWYyACDRMnOSJd['genre']='-'
   saGUquHKQexiXFftoWYyACDRMnOSJb.insert(0,saGUquHKQexiXFftoWYyACDRMnOSJd)
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSpl=saGUquHKQexiXFftoWYyACDRMnOSLP.dic_To_jsonfile(saGUquHKQexiXFftoWYyACDRMnOSJh,saGUquHKQexiXFftoWYyACDRMnOSJb)
  if saGUquHKQexiXFftoWYyACDRMnOSpl==saGUquHKQexiXFftoWYyACDRMnOScm:
   saGUquHKQexiXFftoWYyACDRMnOSLP.addon_noti(__language__(30903).encode('utf8'))
  else:
   saGUquHKQexiXFftoWYyACDRMnOSLP.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(saGUquHKQexiXFftoWYyACDRMnOSLP):
  saGUquHKQexiXFftoWYyACDRMnOSPE=saGUquHKQexiXFftoWYyACDRMnOScm
  saGUquHKQexiXFftoWYyACDRMnOSLP.LIB_PATH =(__addon__.getSetting('libpath')).strip()
  if saGUquHKQexiXFftoWYyACDRMnOSLP.LIB_PATH=='':saGUquHKQexiXFftoWYyACDRMnOSPE=saGUquHKQexiXFftoWYyACDRMnOSck
  if saGUquHKQexiXFftoWYyACDRMnOSPE==saGUquHKQexiXFftoWYyACDRMnOSck:
   saGUquHKQexiXFftoWYyACDRMnOSLw=xbmcgui.Dialog()
   saGUquHKQexiXFftoWYyACDRMnOSPw=saGUquHKQexiXFftoWYyACDRMnOSLw.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if saGUquHKQexiXFftoWYyACDRMnOSPw==saGUquHKQexiXFftoWYyACDRMnOScm:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def dic_To_jsonfile(saGUquHKQexiXFftoWYyACDRMnOSLP,filename,saGUquHKQexiXFftoWYyACDRMnOSPg):
  if filename=='':return saGUquHKQexiXFftoWYyACDRMnOSck
  try:
   fp=xbmcvfs.File(filename,'w')
   json.dump(saGUquHKQexiXFftoWYyACDRMnOSPg,fp,indent=4,ensure_ascii=saGUquHKQexiXFftoWYyACDRMnOSck)
   fp.close()
  except:
   return saGUquHKQexiXFftoWYyACDRMnOSck
  return saGUquHKQexiXFftoWYyACDRMnOScm
 def jsonfile_To_dic(saGUquHKQexiXFftoWYyACDRMnOSLP,filename):
  if filename=='':return saGUquHKQexiXFftoWYyACDRMnOScz
  try:
   fp=xbmcvfs.File(filename)
   saGUquHKQexiXFftoWYyACDRMnOSPl=json.load(fp)
   fp.close()
  except:
   saGUquHKQexiXFftoWYyACDRMnOSPl={}
  return saGUquHKQexiXFftoWYyACDRMnOSPl
 def bookmark_main(saGUquHKQexiXFftoWYyACDRMnOSLP):
  saGUquHKQexiXFftoWYyACDRMnOSPj=saGUquHKQexiXFftoWYyACDRMnOSLP.main_params.get('params')
  if saGUquHKQexiXFftoWYyACDRMnOSPj:
   saGUquHKQexiXFftoWYyACDRMnOScL =base64.standard_b64decode(saGUquHKQexiXFftoWYyACDRMnOSPj).decode('utf-8')
   saGUquHKQexiXFftoWYyACDRMnOScL =json.loads(saGUquHKQexiXFftoWYyACDRMnOScL)
   saGUquHKQexiXFftoWYyACDRMnOScJ =saGUquHKQexiXFftoWYyACDRMnOScL.get('mode')
   saGUquHKQexiXFftoWYyACDRMnOScp =saGUquHKQexiXFftoWYyACDRMnOScL.get('values')
  else:
   saGUquHKQexiXFftoWYyACDRMnOScJ=saGUquHKQexiXFftoWYyACDRMnOSLP.main_params.get('mode',saGUquHKQexiXFftoWYyACDRMnOScz)
   saGUquHKQexiXFftoWYyACDRMnOScp=saGUquHKQexiXFftoWYyACDRMnOSLP.main_params
  saGUquHKQexiXFftoWYyACDRMnOSLP.option_check()
  if saGUquHKQexiXFftoWYyACDRMnOScJ is saGUquHKQexiXFftoWYyACDRMnOScz:
   saGUquHKQexiXFftoWYyACDRMnOSLP.dp_Main_List()
  elif saGUquHKQexiXFftoWYyACDRMnOScJ=='SET_BOOKMARK':
   saGUquHKQexiXFftoWYyACDRMnOSLP.dp_Set_Bookmark(saGUquHKQexiXFftoWYyACDRMnOScp)
  elif saGUquHKQexiXFftoWYyACDRMnOScJ=='GENRE_GROUP':
   saGUquHKQexiXFftoWYyACDRMnOSLP.dp_Genre_Grouplist(saGUquHKQexiXFftoWYyACDRMnOScp)
  elif saGUquHKQexiXFftoWYyACDRMnOScJ=='BOOKMARK_GROUP':
   saGUquHKQexiXFftoWYyACDRMnOSLP.dp_Bookmark_Grouplist(saGUquHKQexiXFftoWYyACDRMnOScp)
  elif saGUquHKQexiXFftoWYyACDRMnOScJ=='BOOKMARK_REMOVE':
   saGUquHKQexiXFftoWYyACDRMnOSLP.dp_Bookmark_Remove(saGUquHKQexiXFftoWYyACDRMnOScp)
  elif saGUquHKQexiXFftoWYyACDRMnOScJ=='GENRE_RENAME':
   saGUquHKQexiXFftoWYyACDRMnOSLP.dp_Genre_Rename(saGUquHKQexiXFftoWYyACDRMnOScp)
  else:
   saGUquHKQexiXFftoWYyACDRMnOScz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
