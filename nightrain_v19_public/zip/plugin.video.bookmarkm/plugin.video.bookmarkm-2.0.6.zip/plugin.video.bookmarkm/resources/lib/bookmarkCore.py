__author__="NightRain"
KMXAqSvbBWQhyxdNilUmtOHFDRfasL=object
KMXAqSvbBWQhyxdNilUmtOHFDRfasV=None
KMXAqSvbBWQhyxdNilUmtOHFDRfask=False
KMXAqSvbBWQhyxdNilUmtOHFDRfasn=open
KMXAqSvbBWQhyxdNilUmtOHFDRfasu=True
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class KMXAqSvbBWQhyxdNilUmtOHFDRfasj(KMXAqSvbBWQhyxdNilUmtOHFDRfasL):
 def __init__(KMXAqSvbBWQhyxdNilUmtOHFDRfasz):
  KMXAqSvbBWQhyxdNilUmtOHFDRfasz.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  KMXAqSvbBWQhyxdNilUmtOHFDRfasz.DEFAULT_HEADER ={'user-agent':KMXAqSvbBWQhyxdNilUmtOHFDRfasz.USER_AGENT}
 def callRequestCookies(KMXAqSvbBWQhyxdNilUmtOHFDRfasz,jobtype,url,payload=KMXAqSvbBWQhyxdNilUmtOHFDRfasV,params=KMXAqSvbBWQhyxdNilUmtOHFDRfasV,headers=KMXAqSvbBWQhyxdNilUmtOHFDRfasV,cookies=KMXAqSvbBWQhyxdNilUmtOHFDRfasV,redirects=KMXAqSvbBWQhyxdNilUmtOHFDRfask):
  KMXAqSvbBWQhyxdNilUmtOHFDRfasY=KMXAqSvbBWQhyxdNilUmtOHFDRfasz.DEFAULT_HEADER
  if headers:KMXAqSvbBWQhyxdNilUmtOHFDRfasY.update(headers)
  if jobtype=='Get':
   KMXAqSvbBWQhyxdNilUmtOHFDRfasC=requests.get(url,params=params,headers=KMXAqSvbBWQhyxdNilUmtOHFDRfasY,cookies=cookies,allow_redirects=redirects)
  else:
   KMXAqSvbBWQhyxdNilUmtOHFDRfasC=requests.post(url,data=payload,params=params,headers=KMXAqSvbBWQhyxdNilUmtOHFDRfasY,cookies=cookies,allow_redirects=redirects)
  return KMXAqSvbBWQhyxdNilUmtOHFDRfasC
 def Get_Now_Datetime(KMXAqSvbBWQhyxdNilUmtOHFDRfasz):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def local_dic_To_jsonfile(KMXAqSvbBWQhyxdNilUmtOHFDRfasz,filename,dic):
  if filename=='':return KMXAqSvbBWQhyxdNilUmtOHFDRfask
  try:
   fp=KMXAqSvbBWQhyxdNilUmtOHFDRfasn(filename,'w',-1,'utf-8')
   json.dump(dic,fp)
   fp.close()
  except:
   return KMXAqSvbBWQhyxdNilUmtOHFDRfask
  return KMXAqSvbBWQhyxdNilUmtOHFDRfasu
 def local_jsonfile_To_dic(KMXAqSvbBWQhyxdNilUmtOHFDRfasz,filename):
  if filename=='':return KMXAqSvbBWQhyxdNilUmtOHFDRfasV
  try:
   fp=KMXAqSvbBWQhyxdNilUmtOHFDRfasn(filename,'r',-1,'utf-8')
   KMXAqSvbBWQhyxdNilUmtOHFDRfase=json.load(fp)
   fp.close()
  except:
   KMXAqSvbBWQhyxdNilUmtOHFDRfase={}
  return KMXAqSvbBWQhyxdNilUmtOHFDRfase
# Created by pyminifier (https://github.com/liftoff/pyminifier)
