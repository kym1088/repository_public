__author__="NightRain"
nrJYPsjcoAUCbgQFTLXyOwxGHBfEVz=object
nrJYPsjcoAUCbgQFTLXyOwxGHBfEVN=None
nrJYPsjcoAUCbgQFTLXyOwxGHBfEVq=False
nrJYPsjcoAUCbgQFTLXyOwxGHBfEVu=open
nrJYPsjcoAUCbgQFTLXyOwxGHBfEVl=True
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class nrJYPsjcoAUCbgQFTLXyOwxGHBfEVR(nrJYPsjcoAUCbgQFTLXyOwxGHBfEVz):
 def __init__(nrJYPsjcoAUCbgQFTLXyOwxGHBfEVI):
  nrJYPsjcoAUCbgQFTLXyOwxGHBfEVI.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  nrJYPsjcoAUCbgQFTLXyOwxGHBfEVI.DEFAULT_HEADER ={'user-agent':nrJYPsjcoAUCbgQFTLXyOwxGHBfEVI.USER_AGENT}
 def callRequestCookies(nrJYPsjcoAUCbgQFTLXyOwxGHBfEVI,jobtype,url,payload=nrJYPsjcoAUCbgQFTLXyOwxGHBfEVN,params=nrJYPsjcoAUCbgQFTLXyOwxGHBfEVN,headers=nrJYPsjcoAUCbgQFTLXyOwxGHBfEVN,cookies=nrJYPsjcoAUCbgQFTLXyOwxGHBfEVN,redirects=nrJYPsjcoAUCbgQFTLXyOwxGHBfEVq):
  nrJYPsjcoAUCbgQFTLXyOwxGHBfEVm=nrJYPsjcoAUCbgQFTLXyOwxGHBfEVI.DEFAULT_HEADER
  if headers:nrJYPsjcoAUCbgQFTLXyOwxGHBfEVm.update(headers)
  if jobtype=='Get':
   nrJYPsjcoAUCbgQFTLXyOwxGHBfEVM=requests.get(url,params=params,headers=nrJYPsjcoAUCbgQFTLXyOwxGHBfEVm,cookies=cookies,allow_redirects=redirects)
  else:
   nrJYPsjcoAUCbgQFTLXyOwxGHBfEVM=requests.post(url,data=payload,params=params,headers=nrJYPsjcoAUCbgQFTLXyOwxGHBfEVm,cookies=cookies,allow_redirects=redirects)
  return nrJYPsjcoAUCbgQFTLXyOwxGHBfEVM
 def Get_Now_Datetime(nrJYPsjcoAUCbgQFTLXyOwxGHBfEVI):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def local_dic_To_jsonfile(nrJYPsjcoAUCbgQFTLXyOwxGHBfEVI,filename,dic):
  if filename=='':return nrJYPsjcoAUCbgQFTLXyOwxGHBfEVq
  try:
   fp=nrJYPsjcoAUCbgQFTLXyOwxGHBfEVu(filename,'w',-1,'utf-8')
   json.dump(dic,fp)
   fp.close()
  except:
   return nrJYPsjcoAUCbgQFTLXyOwxGHBfEVq
  return nrJYPsjcoAUCbgQFTLXyOwxGHBfEVl
 def local_jsonfile_To_dic(nrJYPsjcoAUCbgQFTLXyOwxGHBfEVI,filename):
  if filename=='':return nrJYPsjcoAUCbgQFTLXyOwxGHBfEVN
  try:
   fp=nrJYPsjcoAUCbgQFTLXyOwxGHBfEVu(filename,'r',-1,'utf-8')
   nrJYPsjcoAUCbgQFTLXyOwxGHBfEVk=json.load(fp)
   fp.close()
  except:
   nrJYPsjcoAUCbgQFTLXyOwxGHBfEVk={}
  return nrJYPsjcoAUCbgQFTLXyOwxGHBfEVk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
