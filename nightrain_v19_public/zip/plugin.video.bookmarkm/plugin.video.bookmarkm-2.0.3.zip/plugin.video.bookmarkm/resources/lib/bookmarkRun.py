__author__="NightRain"
xLngbWRANpXOTVscuoySKMtderkmhC=object
xLngbWRANpXOTVscuoySKMtderkmhE=None
xLngbWRANpXOTVscuoySKMtderkmhl=True
xLngbWRANpXOTVscuoySKMtderkmhH=False
xLngbWRANpXOTVscuoySKMtderkmhP=type
xLngbWRANpXOTVscuoySKMtderkmhG=dict
xLngbWRANpXOTVscuoySKMtderkmhB=list
xLngbWRANpXOTVscuoySKMtderkmhz=len
xLngbWRANpXOTVscuoySKMtderkmhw=int
xLngbWRANpXOTVscuoySKMtderkmhU=str
xLngbWRANpXOTVscuoySKMtderkmhD=range
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
xLngbWRANpXOTVscuoySKMtderkmFC=[{'title':'찜 목록 (웨이브+티빙+왓챠+쿠팡+넷플)','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','icon':'sum.png'},{'title':'-----------------','mode':'XXX'},{'title':'영화   찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'movie','icon':'movie.png'},{'title':'시리즈 찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'tvshow','icon':'tvshow.png'},{'title':'장르별 찜 목록','mode':'GENRE_GROUP','ott':'-','vidtype':'-','icon':'category.png'},{'title':'-----------------','mode':'XXX'},{'title':'웨이브 찜 목록','mode':'BOOKMARK_GROUP','ott':'wavve','vidtype':'-','icon':'wavve.png'},{'title':'티빙   찜 목록','mode':'BOOKMARK_GROUP','ott':'tving','vidtype':'-','icon':'tving.png'},{'title':'왓챠   찜 목록','mode':'BOOKMARK_GROUP','ott':'watcha','vidtype':'-','icon':'watcha.png'},{'title':'쿠팡   찜 목록','mode':'BOOKMARK_GROUP','ott':'coupang','vidtype':'-','icon':'coupang.png'},{'title':'넷플   찜 목록 (search mini 에서 등록)','mode':'BOOKMARK_GROUP','ott':'netflix','vidtype':'-','icon':'netflix.png'},{'title':'프라임비디오 찜 목록 (테스트용)','mode':'BOOKMARK_GROUP','ott':'amazon','vidtype':'-','icon':'primev.png'},{'title':'디즈니플러스 찜 목록','mode':'BOOKMARK_GROUP','ott':'disney','vidtype':'-','icon':'disney.jpg'},]
from bookmarkCore import*
class xLngbWRANpXOTVscuoySKMtderkmFI(xLngbWRANpXOTVscuoySKMtderkmhC):
 def __init__(xLngbWRANpXOTVscuoySKMtderkmFE,xLngbWRANpXOTVscuoySKMtderkmFh,xLngbWRANpXOTVscuoySKMtderkmFl,xLngbWRANpXOTVscuoySKMtderkmFH):
  xLngbWRANpXOTVscuoySKMtderkmFE._addon_url =xLngbWRANpXOTVscuoySKMtderkmFh
  xLngbWRANpXOTVscuoySKMtderkmFE._addon_handle=xLngbWRANpXOTVscuoySKMtderkmFl
  xLngbWRANpXOTVscuoySKMtderkmFE.main_params =xLngbWRANpXOTVscuoySKMtderkmFH
  xLngbWRANpXOTVscuoySKMtderkmFE.LIB_PATH =''
  xLngbWRANpXOTVscuoySKMtderkmFE.LIST_LIMIT =20
  xLngbWRANpXOTVscuoySKMtderkmFE.BookmarkObj =nrJYPsjcoAUCbgQFTLXyOwxGHBfEVR() 
 def addon_noti(xLngbWRANpXOTVscuoySKMtderkmFE,sting):
  try:
   xLngbWRANpXOTVscuoySKMtderkmFG=xbmcgui.Dialog()
   xLngbWRANpXOTVscuoySKMtderkmFG.notification(__addonname__,sting)
  except:
   xLngbWRANpXOTVscuoySKMtderkmhE
 def addon_log(xLngbWRANpXOTVscuoySKMtderkmFE,string):
  try:
   xLngbWRANpXOTVscuoySKMtderkmFB=string.encode('utf-8','ignore')
  except:
   xLngbWRANpXOTVscuoySKMtderkmFB='addonException: addon_log'
  xLngbWRANpXOTVscuoySKMtderkmFz=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,xLngbWRANpXOTVscuoySKMtderkmFB),level=xLngbWRANpXOTVscuoySKMtderkmFz)
 def get_settings_select_ott(xLngbWRANpXOTVscuoySKMtderkmFE):
  xLngbWRANpXOTVscuoySKMtderkmFw =xLngbWRANpXOTVscuoySKMtderkmhl if __addon__.getSetting('view_wavve')=='true' else xLngbWRANpXOTVscuoySKMtderkmhH
  xLngbWRANpXOTVscuoySKMtderkmFU =xLngbWRANpXOTVscuoySKMtderkmhl if __addon__.getSetting('view_tving')=='true' else xLngbWRANpXOTVscuoySKMtderkmhH
  xLngbWRANpXOTVscuoySKMtderkmFD =xLngbWRANpXOTVscuoySKMtderkmhl if __addon__.getSetting('view_watcha')=='true' else xLngbWRANpXOTVscuoySKMtderkmhH
  xLngbWRANpXOTVscuoySKMtderkmFv=xLngbWRANpXOTVscuoySKMtderkmhl if __addon__.getSetting('view_coupang')=='true' else xLngbWRANpXOTVscuoySKMtderkmhH
  xLngbWRANpXOTVscuoySKMtderkmFJ=xLngbWRANpXOTVscuoySKMtderkmhl if __addon__.getSetting('view_netflix')=='true' else xLngbWRANpXOTVscuoySKMtderkmhH
  xLngbWRANpXOTVscuoySKMtderkmFa =xLngbWRANpXOTVscuoySKMtderkmhl if __addon__.getSetting('view_primev')=='true' else xLngbWRANpXOTVscuoySKMtderkmhH
  xLngbWRANpXOTVscuoySKMtderkmFY =xLngbWRANpXOTVscuoySKMtderkmhl if __addon__.getSetting('view_disney')=='true' else xLngbWRANpXOTVscuoySKMtderkmhH
  return(xLngbWRANpXOTVscuoySKMtderkmFw,xLngbWRANpXOTVscuoySKMtderkmFU,xLngbWRANpXOTVscuoySKMtderkmFD,xLngbWRANpXOTVscuoySKMtderkmFv,xLngbWRANpXOTVscuoySKMtderkmFJ,xLngbWRANpXOTVscuoySKMtderkmFa,xLngbWRANpXOTVscuoySKMtderkmFY)
 def make_Index_Filename(xLngbWRANpXOTVscuoySKMtderkmFE,tempyn=xLngbWRANpXOTVscuoySKMtderkmhH):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_index_file.json'))
  else:
   return xLngbWRANpXOTVscuoySKMtderkmFE.LIB_PATH+'bookmark_index.json'
 def make_Vinfo_Filename(xLngbWRANpXOTVscuoySKMtderkmFE,xLngbWRANpXOTVscuoySKMtderkmCF,xLngbWRANpXOTVscuoySKMtderkmCI,tempyn=xLngbWRANpXOTVscuoySKMtderkmhH):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_vinfo_file.json'))
  else:
   xLngbWRANpXOTVscuoySKMtderkmFi='%s_%s.json'%(xLngbWRANpXOTVscuoySKMtderkmCF,xLngbWRANpXOTVscuoySKMtderkmCI)
   return xLngbWRANpXOTVscuoySKMtderkmFE.LIB_PATH+xLngbWRANpXOTVscuoySKMtderkmFi
 def add_dir(xLngbWRANpXOTVscuoySKMtderkmFE,label,sublabel='',ott='',img='',infoLabels=xLngbWRANpXOTVscuoySKMtderkmhE,isFolder=xLngbWRANpXOTVscuoySKMtderkmhl,params='',isLink=xLngbWRANpXOTVscuoySKMtderkmhH,ContextMenu=xLngbWRANpXOTVscuoySKMtderkmhE):
  params={'mode':params.get('mode'),'values':params,}
  xLngbWRANpXOTVscuoySKMtderkmFf=json.dumps(params,separators=(',',':'))
  xLngbWRANpXOTVscuoySKMtderkmFf=base64.standard_b64encode(xLngbWRANpXOTVscuoySKMtderkmFf.encode()).decode('utf-8')
  xLngbWRANpXOTVscuoySKMtderkmFf=xLngbWRANpXOTVscuoySKMtderkmFf.replace('+','%2B')
  xLngbWRANpXOTVscuoySKMtderkmFj='%s?params=%s'%(xLngbWRANpXOTVscuoySKMtderkmFE._addon_url,xLngbWRANpXOTVscuoySKMtderkmFf)
  if sublabel and sublabel!='-':xLngbWRANpXOTVscuoySKMtderkmFQ='%s < %s >'%(label,sublabel)
  else: xLngbWRANpXOTVscuoySKMtderkmFQ=label
  if not img:img='DefaultFolder.png'
  if ott:xLngbWRANpXOTVscuoySKMtderkmFQ='%s - [%s]'%(xLngbWRANpXOTVscuoySKMtderkmFQ,ott)
  xLngbWRANpXOTVscuoySKMtderkmIF=xbmcgui.ListItem(xLngbWRANpXOTVscuoySKMtderkmFQ)
  if xLngbWRANpXOTVscuoySKMtderkmhP(img)==xLngbWRANpXOTVscuoySKMtderkmhG:
   xLngbWRANpXOTVscuoySKMtderkmIF.setArt(img)
  else:
   xLngbWRANpXOTVscuoySKMtderkmIF.setArt({'thumb':img,'poster':img})
  xLngbWRANpXOTVscuoySKMtderkmIC=[]
  if infoLabels!=xLngbWRANpXOTVscuoySKMtderkmhE:
   if xLngbWRANpXOTVscuoySKMtderkmhP(infoLabels.get('cast'))==xLngbWRANpXOTVscuoySKMtderkmhB:
    if xLngbWRANpXOTVscuoySKMtderkmhz(infoLabels.get('cast'))>0 and xLngbWRANpXOTVscuoySKMtderkmhP(infoLabels.get('cast')[0])==xLngbWRANpXOTVscuoySKMtderkmhG:
     xLngbWRANpXOTVscuoySKMtderkmIC=infoLabels.get('cast')
     infoLabels['cast']=[]
  if infoLabels:xLngbWRANpXOTVscuoySKMtderkmIF.setInfo('Video',infoLabels)
  if xLngbWRANpXOTVscuoySKMtderkmhz(xLngbWRANpXOTVscuoySKMtderkmIC)>0:xLngbWRANpXOTVscuoySKMtderkmIF.setCast(xLngbWRANpXOTVscuoySKMtderkmIC)
  if not isFolder and not isLink:
   xLngbWRANpXOTVscuoySKMtderkmIF.setProperty('IsPlayable','true')
  if ContextMenu:xLngbWRANpXOTVscuoySKMtderkmIF.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(xLngbWRANpXOTVscuoySKMtderkmFE._addon_handle,xLngbWRANpXOTVscuoySKMtderkmFj,xLngbWRANpXOTVscuoySKMtderkmIF,isFolder)
 def dp_Main_List(xLngbWRANpXOTVscuoySKMtderkmFE):
  (xLngbWRANpXOTVscuoySKMtderkmFw,xLngbWRANpXOTVscuoySKMtderkmFU,xLngbWRANpXOTVscuoySKMtderkmFD,xLngbWRANpXOTVscuoySKMtderkmFv,xLngbWRANpXOTVscuoySKMtderkmFJ,xLngbWRANpXOTVscuoySKMtderkmFa,xLngbWRANpXOTVscuoySKMtderkmFY)=xLngbWRANpXOTVscuoySKMtderkmFE.get_settings_select_ott()
  for xLngbWRANpXOTVscuoySKMtderkmIh in xLngbWRANpXOTVscuoySKMtderkmFC:
   xLngbWRANpXOTVscuoySKMtderkmFQ=xLngbWRANpXOTVscuoySKMtderkmIh.get('title')
   xLngbWRANpXOTVscuoySKMtderkmIl=''
   if xLngbWRANpXOTVscuoySKMtderkmIh.get('ott')=='wavve' and xLngbWRANpXOTVscuoySKMtderkmFw ==xLngbWRANpXOTVscuoySKMtderkmhH:continue
   elif xLngbWRANpXOTVscuoySKMtderkmIh.get('ott')=='tving' and xLngbWRANpXOTVscuoySKMtderkmFU ==xLngbWRANpXOTVscuoySKMtderkmhH:continue
   elif xLngbWRANpXOTVscuoySKMtderkmIh.get('ott')=='watcha' and xLngbWRANpXOTVscuoySKMtderkmFD ==xLngbWRANpXOTVscuoySKMtderkmhH:continue
   elif xLngbWRANpXOTVscuoySKMtderkmIh.get('ott')=='coupang' and xLngbWRANpXOTVscuoySKMtderkmFv==xLngbWRANpXOTVscuoySKMtderkmhH:continue
   elif xLngbWRANpXOTVscuoySKMtderkmIh.get('ott')=='netflix' and xLngbWRANpXOTVscuoySKMtderkmFJ==xLngbWRANpXOTVscuoySKMtderkmhH:continue
   elif xLngbWRANpXOTVscuoySKMtderkmIh.get('ott')=='amazon' and xLngbWRANpXOTVscuoySKMtderkmFa ==xLngbWRANpXOTVscuoySKMtderkmhH:continue
   elif xLngbWRANpXOTVscuoySKMtderkmIh.get('ott')=='disney' and xLngbWRANpXOTVscuoySKMtderkmFY ==xLngbWRANpXOTVscuoySKMtderkmhH:continue
   xLngbWRANpXOTVscuoySKMtderkmFq={'mode':xLngbWRANpXOTVscuoySKMtderkmIh.get('mode'),'ott':xLngbWRANpXOTVscuoySKMtderkmIh.get('ott'),'vidtype':xLngbWRANpXOTVscuoySKMtderkmIh.get('vidtype'),'page':'1',}
   if xLngbWRANpXOTVscuoySKMtderkmIh.get('mode')=='XXX':
    xLngbWRANpXOTVscuoySKMtderkmFq['mode']='XXX'
    xLngbWRANpXOTVscuoySKMtderkmIH=xLngbWRANpXOTVscuoySKMtderkmhH
    xLngbWRANpXOTVscuoySKMtderkmIP =xLngbWRANpXOTVscuoySKMtderkmhl
   else:
    if 'icon' in xLngbWRANpXOTVscuoySKMtderkmIh:
     xLngbWRANpXOTVscuoySKMtderkmIl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',xLngbWRANpXOTVscuoySKMtderkmIh.get('icon')) 
    xLngbWRANpXOTVscuoySKMtderkmIH=xLngbWRANpXOTVscuoySKMtderkmhl
    xLngbWRANpXOTVscuoySKMtderkmIP =xLngbWRANpXOTVscuoySKMtderkmhH
   xLngbWRANpXOTVscuoySKMtderkmFE.add_dir(xLngbWRANpXOTVscuoySKMtderkmFQ,sublabel='',ott='',img=xLngbWRANpXOTVscuoySKMtderkmIl,infoLabels=xLngbWRANpXOTVscuoySKMtderkmhE,isFolder=xLngbWRANpXOTVscuoySKMtderkmIH,params=xLngbWRANpXOTVscuoySKMtderkmFq,isLink=xLngbWRANpXOTVscuoySKMtderkmIP)
  xbmcplugin.endOfDirectory(xLngbWRANpXOTVscuoySKMtderkmFE._addon_handle)
 def dp_Genre_Grouplist(xLngbWRANpXOTVscuoySKMtderkmFE,args):
  xLngbWRANpXOTVscuoySKMtderkmIB=[]
  xLngbWRANpXOTVscuoySKMtderkmIz=xLngbWRANpXOTVscuoySKMtderkmFE.make_Index_Filename(tempyn=xLngbWRANpXOTVscuoySKMtderkmhH)
  if xbmcvfs.exists(xLngbWRANpXOTVscuoySKMtderkmIz):
   xLngbWRANpXOTVscuoySKMtderkmIw=xLngbWRANpXOTVscuoySKMtderkmFE.jsonfile_To_dic(xLngbWRANpXOTVscuoySKMtderkmIz)
  else:
   xLngbWRANpXOTVscuoySKMtderkmIw=[]
  for xLngbWRANpXOTVscuoySKMtderkmIU in xLngbWRANpXOTVscuoySKMtderkmIw:
   xLngbWRANpXOTVscuoySKMtderkmID =xLngbWRANpXOTVscuoySKMtderkmIU.get('genre')
   if xLngbWRANpXOTVscuoySKMtderkmID not in xLngbWRANpXOTVscuoySKMtderkmIB:
    xLngbWRANpXOTVscuoySKMtderkmIB.append(xLngbWRANpXOTVscuoySKMtderkmID)
  for xLngbWRANpXOTVscuoySKMtderkmID in xLngbWRANpXOTVscuoySKMtderkmIB:
   xLngbWRANpXOTVscuoySKMtderkmFq={'mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','genre':xLngbWRANpXOTVscuoySKMtderkmID,'page':'1',}
   xLngbWRANpXOTVscuoySKMtderkmFE.add_dir(xLngbWRANpXOTVscuoySKMtderkmID,sublabel='',ott='',img='',infoLabels=xLngbWRANpXOTVscuoySKMtderkmhE,isFolder=xLngbWRANpXOTVscuoySKMtderkmhl,params=xLngbWRANpXOTVscuoySKMtderkmFq)
  xbmcplugin.endOfDirectory(xLngbWRANpXOTVscuoySKMtderkmFE._addon_handle)
 def dp_Bookmark_Grouplist(xLngbWRANpXOTVscuoySKMtderkmFE,args):
  xLngbWRANpXOTVscuoySKMtderkmIv =xLngbWRANpXOTVscuoySKMtderkmhH
  xLngbWRANpXOTVscuoySKMtderkmIJ =[]
  xLngbWRANpXOTVscuoySKMtderkmIa =args.get('ott')
  xLngbWRANpXOTVscuoySKMtderkmIY=args.get('vidtype')
  xLngbWRANpXOTVscuoySKMtderkmIi =args.get('genre')
  if xLngbWRANpXOTVscuoySKMtderkmIi==xLngbWRANpXOTVscuoySKMtderkmhE:xLngbWRANpXOTVscuoySKMtderkmIi='all'
  xLngbWRANpXOTVscuoySKMtderkmIq =xLngbWRANpXOTVscuoySKMtderkmhw(args.get('page'))
  xLngbWRANpXOTVscuoySKMtderkmIf =xLngbWRANpXOTVscuoySKMtderkmFE.LIST_LIMIT*(xLngbWRANpXOTVscuoySKMtderkmIq-1)+1 
  xLngbWRANpXOTVscuoySKMtderkmIj =xLngbWRANpXOTVscuoySKMtderkmFE.LIST_LIMIT*xLngbWRANpXOTVscuoySKMtderkmIq
  xLngbWRANpXOTVscuoySKMtderkmIz=xLngbWRANpXOTVscuoySKMtderkmFE.make_Index_Filename(tempyn=xLngbWRANpXOTVscuoySKMtderkmhH)
  if xbmcvfs.exists(xLngbWRANpXOTVscuoySKMtderkmIz):
   xLngbWRANpXOTVscuoySKMtderkmIw=xLngbWRANpXOTVscuoySKMtderkmFE.jsonfile_To_dic(xLngbWRANpXOTVscuoySKMtderkmIz)
  else:
   xLngbWRANpXOTVscuoySKMtderkmIw=[]
  xLngbWRANpXOTVscuoySKMtderkmIQ=0
  for xLngbWRANpXOTVscuoySKMtderkmIU in xLngbWRANpXOTVscuoySKMtderkmIw:
   xLngbWRANpXOTVscuoySKMtderkmCF =xLngbWRANpXOTVscuoySKMtderkmIU.get('ott')
   xLngbWRANpXOTVscuoySKMtderkmCI =xLngbWRANpXOTVscuoySKMtderkmIU.get('videoid')
   xLngbWRANpXOTVscuoySKMtderkmCE =xLngbWRANpXOTVscuoySKMtderkmIU.get('vidtype')
   xLngbWRANpXOTVscuoySKMtderkmCh =xLngbWRANpXOTVscuoySKMtderkmIU.get('genre')
   xLngbWRANpXOTVscuoySKMtderkmCl =xLngbWRANpXOTVscuoySKMtderkmIU.get('linkUrl')
   xLngbWRANpXOTVscuoySKMtderkmCH =xLngbWRANpXOTVscuoySKMtderkmIU.get('encodedId')
   xLngbWRANpXOTVscuoySKMtderkmCP =xLngbWRANpXOTVscuoySKMtderkmIU.get('contentId')
   xLngbWRANpXOTVscuoySKMtderkmCG=xLngbWRANpXOTVscuoySKMtderkmIU.get('contentClass')
   xLngbWRANpXOTVscuoySKMtderkmCB=xLngbWRANpXOTVscuoySKMtderkmIU.get('contentSlugs')
   if not(xLngbWRANpXOTVscuoySKMtderkmIa=='-' or xLngbWRANpXOTVscuoySKMtderkmIa==xLngbWRANpXOTVscuoySKMtderkmCF):continue
   if not(xLngbWRANpXOTVscuoySKMtderkmIY=='-' or xLngbWRANpXOTVscuoySKMtderkmIY==xLngbWRANpXOTVscuoySKMtderkmCE):continue
   if not(xLngbWRANpXOTVscuoySKMtderkmIi=='all' or xLngbWRANpXOTVscuoySKMtderkmIi==xLngbWRANpXOTVscuoySKMtderkmCh):continue
   xLngbWRANpXOTVscuoySKMtderkmIQ+=1
   if xLngbWRANpXOTVscuoySKMtderkmIf>xLngbWRANpXOTVscuoySKMtderkmIQ:continue
   if xLngbWRANpXOTVscuoySKMtderkmIj<xLngbWRANpXOTVscuoySKMtderkmIQ:
    xLngbWRANpXOTVscuoySKMtderkmIv=xLngbWRANpXOTVscuoySKMtderkmhl
    break
   xLngbWRANpXOTVscuoySKMtderkmCz=xLngbWRANpXOTVscuoySKMtderkmFE.make_Vinfo_Filename(xLngbWRANpXOTVscuoySKMtderkmCF,xLngbWRANpXOTVscuoySKMtderkmCI,tempyn=xLngbWRANpXOTVscuoySKMtderkmhH)
   if xbmcvfs.exists(xLngbWRANpXOTVscuoySKMtderkmCz):
    xLngbWRANpXOTVscuoySKMtderkmCw=xLngbWRANpXOTVscuoySKMtderkmFE.jsonfile_To_dic(xLngbWRANpXOTVscuoySKMtderkmCz)
    xLngbWRANpXOTVscuoySKMtderkmFQ =xLngbWRANpXOTVscuoySKMtderkmCw.get('title')
    xLngbWRANpXOTVscuoySKMtderkmCU =xLngbWRANpXOTVscuoySKMtderkmCw.get('subtitle')
    xLngbWRANpXOTVscuoySKMtderkmCD =xLngbWRANpXOTVscuoySKMtderkmCw.get('thumbnail')
    xLngbWRANpXOTVscuoySKMtderkmIE=xLngbWRANpXOTVscuoySKMtderkmCw.get('infoLabels')
   else:
    xLngbWRANpXOTVscuoySKMtderkmFQ =xLngbWRANpXOTVscuoySKMtderkmIU.get('title')
    xLngbWRANpXOTVscuoySKMtderkmCU =''
    xLngbWRANpXOTVscuoySKMtderkmCD =''
    xLngbWRANpXOTVscuoySKMtderkmIE={'mpaa':'0'}
    xLngbWRANpXOTVscuoySKMtderkmCw ={'infoLabels':{'title':xLngbWRANpXOTVscuoySKMtderkmFQ}}
   xLngbWRANpXOTVscuoySKMtderkmFq={'mode':'HYPER_LINK','ott':xLngbWRANpXOTVscuoySKMtderkmCF,'videoid':xLngbWRANpXOTVscuoySKMtderkmCI,'vidtype':xLngbWRANpXOTVscuoySKMtderkmCE,'title':xLngbWRANpXOTVscuoySKMtderkmFQ,'thumbnail':xLngbWRANpXOTVscuoySKMtderkmCD,'mpaa':xLngbWRANpXOTVscuoySKMtderkmhU(xLngbWRANpXOTVscuoySKMtderkmIE.get('mpaa')),'duration':xLngbWRANpXOTVscuoySKMtderkmhU(xLngbWRANpXOTVscuoySKMtderkmIE.get('duration')),'linkUrl':xLngbWRANpXOTVscuoySKMtderkmCl,'infoLabels':xLngbWRANpXOTVscuoySKMtderkmIE,'encodedId':xLngbWRANpXOTVscuoySKMtderkmCH,'contentId':xLngbWRANpXOTVscuoySKMtderkmCP,'contentClass':xLngbWRANpXOTVscuoySKMtderkmCG,'contentSlugs':xLngbWRANpXOTVscuoySKMtderkmCB,}
   xLngbWRANpXOTVscuoySKMtderkmCv={'mode':'BOOKMARK_REMOVE','list':[xLngbWRANpXOTVscuoySKMtderkmIU],}
   xLngbWRANpXOTVscuoySKMtderkmCJ=urllib.parse.urlencode(xLngbWRANpXOTVscuoySKMtderkmCv)
   xLngbWRANpXOTVscuoySKMtderkmCa=[('찜 목록 ( %s ) 삭제'%(xLngbWRANpXOTVscuoySKMtderkmCw.get('infoLabels').get('title')),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(xLngbWRANpXOTVscuoySKMtderkmCJ))]
   if xLngbWRANpXOTVscuoySKMtderkmIi!='all':
    xLngbWRANpXOTVscuoySKMtderkmCv={'mode':'GENRE_RENAME','list':[xLngbWRANpXOTVscuoySKMtderkmIU],}
    xLngbWRANpXOTVscuoySKMtderkmCJ=urllib.parse.urlencode(xLngbWRANpXOTVscuoySKMtderkmCv)
    xLngbWRANpXOTVscuoySKMtderkmCa.append(('장르명 ( %s ) 수정'%(xLngbWRANpXOTVscuoySKMtderkmIi),'RunPlugin(plugin://plugin.video.bookmarkm/?%s)'%(xLngbWRANpXOTVscuoySKMtderkmCJ)))
   xLngbWRANpXOTVscuoySKMtderkmFE.add_dir(xLngbWRANpXOTVscuoySKMtderkmFQ,sublabel=xLngbWRANpXOTVscuoySKMtderkmCU,ott=xLngbWRANpXOTVscuoySKMtderkmCF,img=xLngbWRANpXOTVscuoySKMtderkmCD,infoLabels=xLngbWRANpXOTVscuoySKMtderkmIE,isFolder=xLngbWRANpXOTVscuoySKMtderkmhH,params=xLngbWRANpXOTVscuoySKMtderkmFq,isLink=xLngbWRANpXOTVscuoySKMtderkmhl,ContextMenu=xLngbWRANpXOTVscuoySKMtderkmCa)
   xLngbWRANpXOTVscuoySKMtderkmIJ.append(xLngbWRANpXOTVscuoySKMtderkmIU)
  xLngbWRANpXOTVscuoySKMtderkmCY={'plot':'현재페이지의 전체목록을 삭제합니다.'}
  xLngbWRANpXOTVscuoySKMtderkmFQ='* 현재페이지 목록 삭제 (개별삭제는 팝업메뉴) *'
  xLngbWRANpXOTVscuoySKMtderkmFq={'mode':'BOOKMARK_REMOVE','list':xLngbWRANpXOTVscuoySKMtderkmIJ,}
  xLngbWRANpXOTVscuoySKMtderkmIl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  xLngbWRANpXOTVscuoySKMtderkmFE.add_dir(xLngbWRANpXOTVscuoySKMtderkmFQ,sublabel='',ott='',img=xLngbWRANpXOTVscuoySKMtderkmIl,infoLabels=xLngbWRANpXOTVscuoySKMtderkmCY,isFolder=xLngbWRANpXOTVscuoySKMtderkmhH,params=xLngbWRANpXOTVscuoySKMtderkmFq,isLink=xLngbWRANpXOTVscuoySKMtderkmhl)
  if xLngbWRANpXOTVscuoySKMtderkmIv:
   xLngbWRANpXOTVscuoySKMtderkmFq={'mode':'BOOKMARK_GROUP','ott':xLngbWRANpXOTVscuoySKMtderkmIa,'vidtype':xLngbWRANpXOTVscuoySKMtderkmIY,'page':xLngbWRANpXOTVscuoySKMtderkmhU(xLngbWRANpXOTVscuoySKMtderkmIq+1)}
   xLngbWRANpXOTVscuoySKMtderkmFQ='[B]%s >>[/B]'%'다음 페이지'
   xLngbWRANpXOTVscuoySKMtderkmCU=xLngbWRANpXOTVscuoySKMtderkmhU(xLngbWRANpXOTVscuoySKMtderkmIq+1)
   xLngbWRANpXOTVscuoySKMtderkmIl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   xLngbWRANpXOTVscuoySKMtderkmFE.add_dir(xLngbWRANpXOTVscuoySKMtderkmFQ,sublabel=xLngbWRANpXOTVscuoySKMtderkmCU,ott='',img=xLngbWRANpXOTVscuoySKMtderkmIl,infoLabels=xLngbWRANpXOTVscuoySKMtderkmhE,isFolder=xLngbWRANpXOTVscuoySKMtderkmhl,params=xLngbWRANpXOTVscuoySKMtderkmFq)
  xbmcplugin.setContent(xLngbWRANpXOTVscuoySKMtderkmFE._addon_handle,'movies')
  xbmcplugin.endOfDirectory(xLngbWRANpXOTVscuoySKMtderkmFE._addon_handle)
 def get_keyboard_input(xLngbWRANpXOTVscuoySKMtderkmFE,defalut,xLngbWRANpXOTVscuoySKMtderkmFQ):
  xLngbWRANpXOTVscuoySKMtderkmCi=xLngbWRANpXOTVscuoySKMtderkmhE
  kb=xbmc.Keyboard(defalut,xLngbWRANpXOTVscuoySKMtderkmFQ,xLngbWRANpXOTVscuoySKMtderkmhH)
  kb.setHeading(xLngbWRANpXOTVscuoySKMtderkmFQ)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   xLngbWRANpXOTVscuoySKMtderkmCi=kb.getText()
  return xLngbWRANpXOTVscuoySKMtderkmCi
 def dp_Genre_Rename(xLngbWRANpXOTVscuoySKMtderkmFE,args):
  xLngbWRANpXOTVscuoySKMtderkmCq =xLngbWRANpXOTVscuoySKMtderkmhl
  xLngbWRANpXOTVscuoySKMtderkmCf ={}
  try:
   xLngbWRANpXOTVscuoySKMtderkmCj=args.get('list')
   xLngbWRANpXOTVscuoySKMtderkmCj=xLngbWRANpXOTVscuoySKMtderkmCj.replace('\'','\"')
   xLngbWRANpXOTVscuoySKMtderkmCj=json.loads(xLngbWRANpXOTVscuoySKMtderkmCj)
  except:
   xLngbWRANpXOTVscuoySKMtderkmCq=xLngbWRANpXOTVscuoySKMtderkmhH
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   if xLngbWRANpXOTVscuoySKMtderkmhz(xLngbWRANpXOTVscuoySKMtderkmCj)!=0:
    xLngbWRANpXOTVscuoySKMtderkmCQ=xLngbWRANpXOTVscuoySKMtderkmCj[0].get('genre')
   else:
    return
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmEF=xLngbWRANpXOTVscuoySKMtderkmFE.get_keyboard_input(xLngbWRANpXOTVscuoySKMtderkmCQ,__language__(30909).encode('utf-8'))
   if xLngbWRANpXOTVscuoySKMtderkmEF!=xLngbWRANpXOTVscuoySKMtderkmhE:
    xLngbWRANpXOTVscuoySKMtderkmEF=xLngbWRANpXOTVscuoySKMtderkmEF.strip()
   else:
    return
   if xLngbWRANpXOTVscuoySKMtderkmCQ==xLngbWRANpXOTVscuoySKMtderkmEF:
    xLngbWRANpXOTVscuoySKMtderkmFE.addon_noti(__language__(30910).encode('utf-8'))
    return
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   for xLngbWRANpXOTVscuoySKMtderkmEI in xLngbWRANpXOTVscuoySKMtderkmCj:
    if xLngbWRANpXOTVscuoySKMtderkmEI['ott']in xLngbWRANpXOTVscuoySKMtderkmCf:
     xLngbWRANpXOTVscuoySKMtderkmCf[xLngbWRANpXOTVscuoySKMtderkmEI['ott']].append(xLngbWRANpXOTVscuoySKMtderkmEI['videoid'])
    else:
     xLngbWRANpXOTVscuoySKMtderkmCf[xLngbWRANpXOTVscuoySKMtderkmEI['ott']]=[xLngbWRANpXOTVscuoySKMtderkmEI['videoid']]
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmIz=xLngbWRANpXOTVscuoySKMtderkmFE.make_Index_Filename(tempyn=xLngbWRANpXOTVscuoySKMtderkmhH)
   if xbmcvfs.exists(xLngbWRANpXOTVscuoySKMtderkmIz):
    xLngbWRANpXOTVscuoySKMtderkmIw=xLngbWRANpXOTVscuoySKMtderkmFE.jsonfile_To_dic(xLngbWRANpXOTVscuoySKMtderkmIz)
   else:
    xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhH
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   for i in xLngbWRANpXOTVscuoySKMtderkmhD(xLngbWRANpXOTVscuoySKMtderkmhz(xLngbWRANpXOTVscuoySKMtderkmIw)):
    xLngbWRANpXOTVscuoySKMtderkmEC =xLngbWRANpXOTVscuoySKMtderkmIw[i].get('ott')
    xLngbWRANpXOTVscuoySKMtderkmEh=xLngbWRANpXOTVscuoySKMtderkmIw[i].get('videoid')
    if xLngbWRANpXOTVscuoySKMtderkmEC in xLngbWRANpXOTVscuoySKMtderkmCf:
     if xLngbWRANpXOTVscuoySKMtderkmEh in xLngbWRANpXOTVscuoySKMtderkmCf[xLngbWRANpXOTVscuoySKMtderkmEC]:
      xLngbWRANpXOTVscuoySKMtderkmIw[i]['genre']=xLngbWRANpXOTVscuoySKMtderkmEF
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmCq=xLngbWRANpXOTVscuoySKMtderkmFE.dic_To_jsonfile(xLngbWRANpXOTVscuoySKMtderkmIz,xLngbWRANpXOTVscuoySKMtderkmIw)
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmFE.addon_noti(__language__(30911).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   xLngbWRANpXOTVscuoySKMtderkmFE.addon_noti(__language__(30912).encode('utf-8'))
 def dp_Bookmark_Remove(xLngbWRANpXOTVscuoySKMtderkmFE,args):
  xLngbWRANpXOTVscuoySKMtderkmCq =xLngbWRANpXOTVscuoySKMtderkmhl
  xLngbWRANpXOTVscuoySKMtderkmEl ={}
  xLngbWRANpXOTVscuoySKMtderkmFG=xbmcgui.Dialog()
  xLngbWRANpXOTVscuoySKMtderkmEH=xLngbWRANpXOTVscuoySKMtderkmFG.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if xLngbWRANpXOTVscuoySKMtderkmEH==xLngbWRANpXOTVscuoySKMtderkmhH:sys.exit()
  try:
   xLngbWRANpXOTVscuoySKMtderkmCj=args.get('list')
   xLngbWRANpXOTVscuoySKMtderkmCj=xLngbWRANpXOTVscuoySKMtderkmCj.replace('\'','\"')
   xLngbWRANpXOTVscuoySKMtderkmCj=json.loads(xLngbWRANpXOTVscuoySKMtderkmCj)
  except:
   xLngbWRANpXOTVscuoySKMtderkmCq=xLngbWRANpXOTVscuoySKMtderkmhH
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   for xLngbWRANpXOTVscuoySKMtderkmEI in xLngbWRANpXOTVscuoySKMtderkmCj:
    if xLngbWRANpXOTVscuoySKMtderkmEI['ott']in xLngbWRANpXOTVscuoySKMtderkmEl:
     xLngbWRANpXOTVscuoySKMtderkmEl[xLngbWRANpXOTVscuoySKMtderkmEI['ott']].append(xLngbWRANpXOTVscuoySKMtderkmEI['videoid'])
    else:
     xLngbWRANpXOTVscuoySKMtderkmEl[xLngbWRANpXOTVscuoySKMtderkmEI['ott']]=[xLngbWRANpXOTVscuoySKMtderkmEI['videoid']]
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmIz=xLngbWRANpXOTVscuoySKMtderkmFE.make_Index_Filename(tempyn=xLngbWRANpXOTVscuoySKMtderkmhH)
   if xbmcvfs.exists(xLngbWRANpXOTVscuoySKMtderkmIz):
    xLngbWRANpXOTVscuoySKMtderkmIw=xLngbWRANpXOTVscuoySKMtderkmFE.jsonfile_To_dic(xLngbWRANpXOTVscuoySKMtderkmIz)
   else:
    xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhH
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmIU=[]
   for xLngbWRANpXOTVscuoySKMtderkmEP in xLngbWRANpXOTVscuoySKMtderkmIw:
    xLngbWRANpXOTVscuoySKMtderkmEC =xLngbWRANpXOTVscuoySKMtderkmEP.get('ott')
    xLngbWRANpXOTVscuoySKMtderkmEh=xLngbWRANpXOTVscuoySKMtderkmEP.get('videoid')
    if xLngbWRANpXOTVscuoySKMtderkmEC in xLngbWRANpXOTVscuoySKMtderkmEl:
     if xLngbWRANpXOTVscuoySKMtderkmEh in xLngbWRANpXOTVscuoySKMtderkmEl[xLngbWRANpXOTVscuoySKMtderkmEC]:
      xLngbWRANpXOTVscuoySKMtderkmCz=xLngbWRANpXOTVscuoySKMtderkmFE.make_Vinfo_Filename(xLngbWRANpXOTVscuoySKMtderkmEC,xLngbWRANpXOTVscuoySKMtderkmEh,tempyn=xLngbWRANpXOTVscuoySKMtderkmhH)
      xbmcvfs.delete(xLngbWRANpXOTVscuoySKMtderkmCz)
      continue
    xLngbWRANpXOTVscuoySKMtderkmIU.append(xLngbWRANpXOTVscuoySKMtderkmEP)
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmhE
   xLngbWRANpXOTVscuoySKMtderkmCq=xLngbWRANpXOTVscuoySKMtderkmFE.dic_To_jsonfile(xLngbWRANpXOTVscuoySKMtderkmIz,xLngbWRANpXOTVscuoySKMtderkmIU)
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmFE.addon_noti(__language__(30908).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   xLngbWRANpXOTVscuoySKMtderkmFE.addon_noti(__language__(30907).encode('utf-8'))
 def dp_Hyper_Link(xLngbWRANpXOTVscuoySKMtderkmFE,args):
  xLngbWRANpXOTVscuoySKMtderkmCF =args.get('ott')
  xLngbWRANpXOTVscuoySKMtderkmCI =args.get('videoid')
  xLngbWRANpXOTVscuoySKMtderkmCE =args.get('vidtype')
  xLngbWRANpXOTVscuoySKMtderkmFQ =args.get('title')
  xLngbWRANpXOTVscuoySKMtderkmCD =args.get('thumbnail')
  xLngbWRANpXOTVscuoySKMtderkmEG =args.get('mpaa')
  xLngbWRANpXOTVscuoySKMtderkmCl =args.get('linkUrl')
  xLngbWRANpXOTVscuoySKMtderkmEB =args.get('duration')
  xLngbWRANpXOTVscuoySKMtderkmIE=args.get('infoLabels')
  xLngbWRANpXOTVscuoySKMtderkmCH =args.get('encodedId')
  xLngbWRANpXOTVscuoySKMtderkmCP =args.get('contentId')
  xLngbWRANpXOTVscuoySKMtderkmCG=args.get('contentClass')
  xLngbWRANpXOTVscuoySKMtderkmCB=args.get('contentSlugs')
  if xLngbWRANpXOTVscuoySKMtderkmCF=='wavve':
   if xLngbWRANpXOTVscuoySKMtderkmCE=='tvshow':
    xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'EPISODE_LIST','videoid':xLngbWRANpXOTVscuoySKMtderkmCI,'vidtype':xLngbWRANpXOTVscuoySKMtderkmCE,'page':'1',}
    xLngbWRANpXOTVscuoySKMtderkmEw=urllib.parse.urlencode(xLngbWRANpXOTVscuoySKMtderkmEz)
    xLngbWRANpXOTVscuoySKMtderkmEU='ActivateWindow(10025,"plugin://plugin.video.wavvem/?%s",return)'%(xLngbWRANpXOTVscuoySKMtderkmEw)
   else:
    xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'MOVIE','contentid':xLngbWRANpXOTVscuoySKMtderkmCI,'title':xLngbWRANpXOTVscuoySKMtderkmFQ,'thumbnail':xLngbWRANpXOTVscuoySKMtderkmCD,'age':xLngbWRANpXOTVscuoySKMtderkmEG,}
    xLngbWRANpXOTVscuoySKMtderkmEw=urllib.parse.urlencode(xLngbWRANpXOTVscuoySKMtderkmEz)
    xLngbWRANpXOTVscuoySKMtderkmEU='PlayMedia("plugin://plugin.video.wavvem/?%s")'%(xLngbWRANpXOTVscuoySKMtderkmEw)
  elif xLngbWRANpXOTVscuoySKMtderkmCF=='tving':
   if xLngbWRANpXOTVscuoySKMtderkmCE=='tvshow':
    xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'EPISODE','programcode':xLngbWRANpXOTVscuoySKMtderkmCI,'page':'1',}
    xLngbWRANpXOTVscuoySKMtderkmEw=urllib.parse.urlencode(xLngbWRANpXOTVscuoySKMtderkmEz)
    xLngbWRANpXOTVscuoySKMtderkmEU='ActivateWindow(10025,"plugin://plugin.video.tvingm/?%s",return)'%(xLngbWRANpXOTVscuoySKMtderkmEw)
   else:
    xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'MOVIE','stype':'movie','mediacode':xLngbWRANpXOTVscuoySKMtderkmCI,'title':xLngbWRANpXOTVscuoySKMtderkmFQ,'thumbnail':xLngbWRANpXOTVscuoySKMtderkmCD,}
    xLngbWRANpXOTVscuoySKMtderkmEw=urllib.parse.urlencode(xLngbWRANpXOTVscuoySKMtderkmEz)
    xLngbWRANpXOTVscuoySKMtderkmEU='PlayMedia("plugin://plugin.video.tvingm/?%s")'%(xLngbWRANpXOTVscuoySKMtderkmEw)
  elif xLngbWRANpXOTVscuoySKMtderkmCF=='watcha':
   if xLngbWRANpXOTVscuoySKMtderkmCE=='tvshow':
    xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'EPISODE','movie_code':xLngbWRANpXOTVscuoySKMtderkmCI,'season_code':xLngbWRANpXOTVscuoySKMtderkmCI,'page':'1',}
    xLngbWRANpXOTVscuoySKMtderkmEw=urllib.parse.urlencode(xLngbWRANpXOTVscuoySKMtderkmEz)
    xLngbWRANpXOTVscuoySKMtderkmEU='ActivateWindow(10025,"plugin://plugin.video.watcham/?%s",return)'%(xLngbWRANpXOTVscuoySKMtderkmEw)
   else:
    xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'MOVIE','movie_code':xLngbWRANpXOTVscuoySKMtderkmCI,'season_code':'-','title':xLngbWRANpXOTVscuoySKMtderkmFQ,'thumbnail':xLngbWRANpXOTVscuoySKMtderkmCD,}
    xLngbWRANpXOTVscuoySKMtderkmEw=urllib.parse.urlencode(xLngbWRANpXOTVscuoySKMtderkmEz)
    xLngbWRANpXOTVscuoySKMtderkmEU='PlayMedia("plugin://plugin.video.watcham/?%s")'%(xLngbWRANpXOTVscuoySKMtderkmEw)
  elif xLngbWRANpXOTVscuoySKMtderkmCF=='coupang':
   if xLngbWRANpXOTVscuoySKMtderkmCE=='tvshow':
    xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'SEASON_LIST','id':xLngbWRANpXOTVscuoySKMtderkmCI,'asis':'TVSHOW','title':xLngbWRANpXOTVscuoySKMtderkmFQ,'thumbnail':xLngbWRANpXOTVscuoySKMtderkmCD,'page':'1',}
    xLngbWRANpXOTVscuoySKMtderkmEw=urllib.parse.urlencode(xLngbWRANpXOTVscuoySKMtderkmEz)
    xLngbWRANpXOTVscuoySKMtderkmEU='ActivateWindow(10025,"plugin://plugin.video.coupangm/?%s",return)'%(xLngbWRANpXOTVscuoySKMtderkmEw)
   else:
    xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'MOVIE','id':xLngbWRANpXOTVscuoySKMtderkmCI,'asis':'MOVIE','title':xLngbWRANpXOTVscuoySKMtderkmFQ,'thumbnail':xLngbWRANpXOTVscuoySKMtderkmCD,}
    xLngbWRANpXOTVscuoySKMtderkmEw=urllib.parse.urlencode(xLngbWRANpXOTVscuoySKMtderkmEz)
    xLngbWRANpXOTVscuoySKMtderkmEU='PlayMedia("plugin://plugin.video.coupangm/?%s")'%(xLngbWRANpXOTVscuoySKMtderkmEw)
  elif xLngbWRANpXOTVscuoySKMtderkmCF=='netflix':
   if xLngbWRANpXOTVscuoySKMtderkmCE=='tvshow':
    xLngbWRANpXOTVscuoySKMtderkmEU='ActivateWindow(10025,"plugin://plugin.video.netflix/directory/show/%s/",return)'%(xLngbWRANpXOTVscuoySKMtderkmCI)
   else:
    xLngbWRANpXOTVscuoySKMtderkmEU='PlayMedia("plugin://plugin.video.netflix/play/movie/%s/")'%(xLngbWRANpXOTVscuoySKMtderkmCI)
  elif xLngbWRANpXOTVscuoySKMtderkmCF=='amazon':
   if xLngbWRANpXOTVscuoySKMtderkmCE=='tvshow':
    xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'SEASON_LIST','values':{'titleID':xLngbWRANpXOTVscuoySKMtderkmCI,'linkUrl':xLngbWRANpXOTVscuoySKMtderkmCl,'duration':xLngbWRANpXOTVscuoySKMtderkmEB,'vType':xLngbWRANpXOTVscuoySKMtderkmCE,'image':xLngbWRANpXOTVscuoySKMtderkmCD,'title':xLngbWRANpXOTVscuoySKMtderkmFQ,'infoLabels':xLngbWRANpXOTVscuoySKMtderkmIE,}}
    xLngbWRANpXOTVscuoySKMtderkmEw=json.dumps(xLngbWRANpXOTVscuoySKMtderkmEz,separators=(',',':'))
    xLngbWRANpXOTVscuoySKMtderkmEw=base64.standard_b64encode(xLngbWRANpXOTVscuoySKMtderkmEw.encode()).decode('utf-8')
    xLngbWRANpXOTVscuoySKMtderkmEw=xLngbWRANpXOTVscuoySKMtderkmEw.replace('+','%2B')
    xLngbWRANpXOTVscuoySKMtderkmEU='ActivateWindow(10025,"plugin://plugin.video.primevm/?params=%s",return)'%(xLngbWRANpXOTVscuoySKMtderkmEw)
   else:
    xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'MOVIE','values':{'titleID':xLngbWRANpXOTVscuoySKMtderkmCI,'linkUrl':xLngbWRANpXOTVscuoySKMtderkmCl,'duration':xLngbWRANpXOTVscuoySKMtderkmEB,'vType':xLngbWRANpXOTVscuoySKMtderkmCE,'image':xLngbWRANpXOTVscuoySKMtderkmCD,'title':xLngbWRANpXOTVscuoySKMtderkmFQ,'infoLabels':xLngbWRANpXOTVscuoySKMtderkmIE,}}
    xLngbWRANpXOTVscuoySKMtderkmEw=json.dumps(xLngbWRANpXOTVscuoySKMtderkmEz,separators=(',',':'))
    xLngbWRANpXOTVscuoySKMtderkmEw=base64.standard_b64encode(xLngbWRANpXOTVscuoySKMtderkmEw.encode()).decode('utf-8')
    xLngbWRANpXOTVscuoySKMtderkmEw=xLngbWRANpXOTVscuoySKMtderkmEw.replace('+','%2B')
    xLngbWRANpXOTVscuoySKMtderkmEU='PlayMedia("plugin://plugin.video.primevm/?params=%s")'%(xLngbWRANpXOTVscuoySKMtderkmEw)
  elif xLngbWRANpXOTVscuoySKMtderkmCF=='disney':
   if xLngbWRANpXOTVscuoySKMtderkmCE=='tvshow':
    if xLngbWRANpXOTVscuoySKMtderkmCH:
     xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'SEASON_LIST','values':{'encodedId':xLngbWRANpXOTVscuoySKMtderkmCH,'vType':xLngbWRANpXOTVscuoySKMtderkmCE,'image':xLngbWRANpXOTVscuoySKMtderkmCD,'title':xLngbWRANpXOTVscuoySKMtderkmFQ,'programTitle':xLngbWRANpXOTVscuoySKMtderkmFQ,'infoLabels':xLngbWRANpXOTVscuoySKMtderkmIE,}}
    else:
     xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'PROGRAM_LIST','values':{'contentClass':xLngbWRANpXOTVscuoySKMtderkmCG,'contentSlugs':xLngbWRANpXOTVscuoySKMtderkmCB,'vType':xLngbWRANpXOTVscuoySKMtderkmCE,'image':xLngbWRANpXOTVscuoySKMtderkmCD,'title':xLngbWRANpXOTVscuoySKMtderkmFQ,'programTitle':xLngbWRANpXOTVscuoySKMtderkmFQ,'infoLabels':xLngbWRANpXOTVscuoySKMtderkmIE,}}
    xLngbWRANpXOTVscuoySKMtderkmEw=json.dumps(xLngbWRANpXOTVscuoySKMtderkmEz,separators=(',',':'))
    xLngbWRANpXOTVscuoySKMtderkmEw=base64.standard_b64encode(xLngbWRANpXOTVscuoySKMtderkmEw.encode()).decode('utf-8')
    xLngbWRANpXOTVscuoySKMtderkmEw=xLngbWRANpXOTVscuoySKMtderkmEw.replace('+','%2B')
    xLngbWRANpXOTVscuoySKMtderkmEU='ActivateWindow(10025,"plugin://plugin.video.disneym/?params=%s",return)'%(xLngbWRANpXOTVscuoySKMtderkmEw)
   else:
    xLngbWRANpXOTVscuoySKMtderkmEz={'mode':'MOVIE','values':{'contentId':xLngbWRANpXOTVscuoySKMtderkmCP,'vType':xLngbWRANpXOTVscuoySKMtderkmCE,'image':xLngbWRANpXOTVscuoySKMtderkmCD,'title':xLngbWRANpXOTVscuoySKMtderkmIE['title'],'programTitle':xLngbWRANpXOTVscuoySKMtderkmIE['title'],'infoLabels':xLngbWRANpXOTVscuoySKMtderkmIE,}}
    xLngbWRANpXOTVscuoySKMtderkmEw=json.dumps(xLngbWRANpXOTVscuoySKMtderkmEz,separators=(',',':'))
    xLngbWRANpXOTVscuoySKMtderkmEw=base64.standard_b64encode(xLngbWRANpXOTVscuoySKMtderkmEw.encode()).decode('utf-8')
    xLngbWRANpXOTVscuoySKMtderkmEw=xLngbWRANpXOTVscuoySKMtderkmEw.replace('+','%2B')
    xLngbWRANpXOTVscuoySKMtderkmEU='PlayMedia("plugin://plugin.video.disneym/?params=%s")'%(xLngbWRANpXOTVscuoySKMtderkmEw)
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(xLngbWRANpXOTVscuoySKMtderkmEU)
 def dp_Set_Bookmark(xLngbWRANpXOTVscuoySKMtderkmFE,args):
  xLngbWRANpXOTVscuoySKMtderkmCq =xLngbWRANpXOTVscuoySKMtderkmhl
  xLngbWRANpXOTVscuoySKMtderkmIw=[]
  xLngbWRANpXOTVscuoySKMtderkmED=args.get('VIDEO_INFO')
  if xLngbWRANpXOTVscuoySKMtderkmED:
   xLngbWRANpXOTVscuoySKMtderkmIU=xLngbWRANpXOTVscuoySKMtderkmED.get('indexinfo')
   xLngbWRANpXOTVscuoySKMtderkmCw =xLngbWRANpXOTVscuoySKMtderkmED.get('saveinfo')
  else:
   xLngbWRANpXOTVscuoySKMtderkmEv =urllib.parse.unquote(args.get('bm_param'))
   xLngbWRANpXOTVscuoySKMtderkmEv =json.loads(xLngbWRANpXOTVscuoySKMtderkmEv)
   xLngbWRANpXOTVscuoySKMtderkmIU=xLngbWRANpXOTVscuoySKMtderkmEv.get('indexinfo')
   xLngbWRANpXOTVscuoySKMtderkmCw =xLngbWRANpXOTVscuoySKMtderkmEv.get('saveinfo')
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmCz=xLngbWRANpXOTVscuoySKMtderkmFE.make_Vinfo_Filename(xLngbWRANpXOTVscuoySKMtderkmIU.get('ott'),xLngbWRANpXOTVscuoySKMtderkmIU.get('videoid'),tempyn=xLngbWRANpXOTVscuoySKMtderkmhH)
   xLngbWRANpXOTVscuoySKMtderkmCq=xLngbWRANpXOTVscuoySKMtderkmFE.dic_To_jsonfile(xLngbWRANpXOTVscuoySKMtderkmCz,xLngbWRANpXOTVscuoySKMtderkmCw)
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmIz=xLngbWRANpXOTVscuoySKMtderkmFE.make_Index_Filename(tempyn=xLngbWRANpXOTVscuoySKMtderkmhH)
   if xbmcvfs.exists(xLngbWRANpXOTVscuoySKMtderkmIz):
    xLngbWRANpXOTVscuoySKMtderkmIw=xLngbWRANpXOTVscuoySKMtderkmFE.jsonfile_To_dic(xLngbWRANpXOTVscuoySKMtderkmIz)
   else:
    xLngbWRANpXOTVscuoySKMtderkmIw=[]
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmEJ =xLngbWRANpXOTVscuoySKMtderkmIU.get('ott')
   xLngbWRANpXOTVscuoySKMtderkmEa =xLngbWRANpXOTVscuoySKMtderkmIU.get('videoid')
   for i in xLngbWRANpXOTVscuoySKMtderkmhD(xLngbWRANpXOTVscuoySKMtderkmhz(xLngbWRANpXOTVscuoySKMtderkmIw)):
    xLngbWRANpXOTVscuoySKMtderkmEC =xLngbWRANpXOTVscuoySKMtderkmIw[i].get('ott')
    xLngbWRANpXOTVscuoySKMtderkmEh=xLngbWRANpXOTVscuoySKMtderkmIw[i].get('videoid')
    if xLngbWRANpXOTVscuoySKMtderkmEJ==xLngbWRANpXOTVscuoySKMtderkmEC and xLngbWRANpXOTVscuoySKMtderkmEa==xLngbWRANpXOTVscuoySKMtderkmEh:
     xLngbWRANpXOTVscuoySKMtderkmIw.pop(i)
     break
   xLngbWRANpXOTVscuoySKMtderkmIU['title']=xLngbWRANpXOTVscuoySKMtderkmCw.get('title')
   if xLngbWRANpXOTVscuoySKMtderkmhz(xLngbWRANpXOTVscuoySKMtderkmCw.get('infoLabels').get('genre'))>0:
    xLngbWRANpXOTVscuoySKMtderkmIU['genre']=xLngbWRANpXOTVscuoySKMtderkmCw.get('infoLabels').get('genre')[0]
   else:
    xLngbWRANpXOTVscuoySKMtderkmIU['genre']='-'
   xLngbWRANpXOTVscuoySKMtderkmIw.insert(0,xLngbWRANpXOTVscuoySKMtderkmIU)
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmCq=xLngbWRANpXOTVscuoySKMtderkmFE.dic_To_jsonfile(xLngbWRANpXOTVscuoySKMtderkmIz,xLngbWRANpXOTVscuoySKMtderkmIw)
  if xLngbWRANpXOTVscuoySKMtderkmCq==xLngbWRANpXOTVscuoySKMtderkmhl:
   xLngbWRANpXOTVscuoySKMtderkmFE.addon_noti(__language__(30903).encode('utf8'))
  else:
   xLngbWRANpXOTVscuoySKMtderkmFE.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(xLngbWRANpXOTVscuoySKMtderkmFE):
  xLngbWRANpXOTVscuoySKMtderkmEY=xLngbWRANpXOTVscuoySKMtderkmhl
  xLngbWRANpXOTVscuoySKMtderkmFE.LIB_PATH =(__addon__.getSetting('libpath')).strip()
  if xLngbWRANpXOTVscuoySKMtderkmFE.LIB_PATH=='':xLngbWRANpXOTVscuoySKMtderkmEY=xLngbWRANpXOTVscuoySKMtderkmhH
  if xLngbWRANpXOTVscuoySKMtderkmEY==xLngbWRANpXOTVscuoySKMtderkmhH:
   xLngbWRANpXOTVscuoySKMtderkmFG=xbmcgui.Dialog()
   xLngbWRANpXOTVscuoySKMtderkmEH=xLngbWRANpXOTVscuoySKMtderkmFG.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if xLngbWRANpXOTVscuoySKMtderkmEH==xLngbWRANpXOTVscuoySKMtderkmhl:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def dic_To_jsonfile(xLngbWRANpXOTVscuoySKMtderkmFE,filename,xLngbWRANpXOTVscuoySKMtderkmEi):
  if filename=='':return xLngbWRANpXOTVscuoySKMtderkmhH
  try:
   fp=xbmcvfs.File(filename,'w')
   json.dump(xLngbWRANpXOTVscuoySKMtderkmEi,fp,indent=4,ensure_ascii=xLngbWRANpXOTVscuoySKMtderkmhH)
   fp.close()
  except:
   return xLngbWRANpXOTVscuoySKMtderkmhH
  return xLngbWRANpXOTVscuoySKMtderkmhl
 def jsonfile_To_dic(xLngbWRANpXOTVscuoySKMtderkmFE,filename):
  if filename=='':return xLngbWRANpXOTVscuoySKMtderkmhE
  try:
   fp=xbmcvfs.File(filename)
   xLngbWRANpXOTVscuoySKMtderkmEf=json.load(fp)
   fp.close()
  except:
   xLngbWRANpXOTVscuoySKMtderkmEf={}
  return xLngbWRANpXOTVscuoySKMtderkmEf
 def bookmark_main(xLngbWRANpXOTVscuoySKMtderkmFE):
  xLngbWRANpXOTVscuoySKMtderkmEj=xLngbWRANpXOTVscuoySKMtderkmFE.main_params.get('params')
  if xLngbWRANpXOTVscuoySKMtderkmEj:
   xLngbWRANpXOTVscuoySKMtderkmEQ =base64.standard_b64decode(xLngbWRANpXOTVscuoySKMtderkmEj).decode('utf-8')
   xLngbWRANpXOTVscuoySKMtderkmEQ =json.loads(xLngbWRANpXOTVscuoySKMtderkmEQ)
   xLngbWRANpXOTVscuoySKMtderkmhF =xLngbWRANpXOTVscuoySKMtderkmEQ.get('mode')
   xLngbWRANpXOTVscuoySKMtderkmhI =xLngbWRANpXOTVscuoySKMtderkmEQ.get('values')
  else:
   xLngbWRANpXOTVscuoySKMtderkmhF=xLngbWRANpXOTVscuoySKMtderkmFE.main_params.get('mode',xLngbWRANpXOTVscuoySKMtderkmhE)
   xLngbWRANpXOTVscuoySKMtderkmhI=xLngbWRANpXOTVscuoySKMtderkmFE.main_params
  xLngbWRANpXOTVscuoySKMtderkmFE.option_check()
  if xLngbWRANpXOTVscuoySKMtderkmhF is xLngbWRANpXOTVscuoySKMtderkmhE:
   xLngbWRANpXOTVscuoySKMtderkmFE.dp_Main_List()
  elif xLngbWRANpXOTVscuoySKMtderkmhF=='SET_BOOKMARK':
   xLngbWRANpXOTVscuoySKMtderkmFE.dp_Set_Bookmark(xLngbWRANpXOTVscuoySKMtderkmhI)
  elif xLngbWRANpXOTVscuoySKMtderkmhF=='GENRE_GROUP':
   xLngbWRANpXOTVscuoySKMtderkmFE.dp_Genre_Grouplist(xLngbWRANpXOTVscuoySKMtderkmhI)
  elif xLngbWRANpXOTVscuoySKMtderkmhF=='BOOKMARK_GROUP':
   xLngbWRANpXOTVscuoySKMtderkmFE.dp_Bookmark_Grouplist(xLngbWRANpXOTVscuoySKMtderkmhI)
  elif xLngbWRANpXOTVscuoySKMtderkmhF=='HYPER_LINK':
   xLngbWRANpXOTVscuoySKMtderkmFE.dp_Hyper_Link(xLngbWRANpXOTVscuoySKMtderkmhI)
  elif xLngbWRANpXOTVscuoySKMtderkmhF=='BOOKMARK_REMOVE':
   xLngbWRANpXOTVscuoySKMtderkmFE.dp_Bookmark_Remove(xLngbWRANpXOTVscuoySKMtderkmhI)
  elif xLngbWRANpXOTVscuoySKMtderkmhF=='GENRE_RENAME':
   xLngbWRANpXOTVscuoySKMtderkmFE.dp_Genre_Rename(xLngbWRANpXOTVscuoySKMtderkmhI)
  else:
   xLngbWRANpXOTVscuoySKMtderkmhE
# Created by pyminifier (https://github.com/liftoff/pyminifier)
