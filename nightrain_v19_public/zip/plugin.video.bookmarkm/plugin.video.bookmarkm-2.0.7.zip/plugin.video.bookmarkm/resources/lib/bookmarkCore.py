__author__="NightRain"
fuDeaqhRENvlzYJTicVFHrtQwsnymg=object
fuDeaqhRENvlzYJTicVFHrtQwsnymL=None
fuDeaqhRENvlzYJTicVFHrtQwsnymA=False
fuDeaqhRENvlzYJTicVFHrtQwsnymK=open
fuDeaqhRENvlzYJTicVFHrtQwsnymI=True
import urllib
import re
import json
import sys
import time
import requests
import base64
import datetime
class fuDeaqhRENvlzYJTicVFHrtQwsnymj(fuDeaqhRENvlzYJTicVFHrtQwsnymg):
 def __init__(fuDeaqhRENvlzYJTicVFHrtQwsnymp):
  fuDeaqhRENvlzYJTicVFHrtQwsnymp.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
  fuDeaqhRENvlzYJTicVFHrtQwsnymp.DEFAULT_HEADER ={'user-agent':fuDeaqhRENvlzYJTicVFHrtQwsnymp.USER_AGENT}
 def callRequestCookies(fuDeaqhRENvlzYJTicVFHrtQwsnymp,jobtype,url,payload=fuDeaqhRENvlzYJTicVFHrtQwsnymL,params=fuDeaqhRENvlzYJTicVFHrtQwsnymL,headers=fuDeaqhRENvlzYJTicVFHrtQwsnymL,cookies=fuDeaqhRENvlzYJTicVFHrtQwsnymL,redirects=fuDeaqhRENvlzYJTicVFHrtQwsnymA):
  fuDeaqhRENvlzYJTicVFHrtQwsnymb=fuDeaqhRENvlzYJTicVFHrtQwsnymp.DEFAULT_HEADER
  if headers:fuDeaqhRENvlzYJTicVFHrtQwsnymb.update(headers)
  if jobtype=='Get':
   fuDeaqhRENvlzYJTicVFHrtQwsnymG=requests.get(url,params=params,headers=fuDeaqhRENvlzYJTicVFHrtQwsnymb,cookies=cookies,allow_redirects=redirects)
  else:
   fuDeaqhRENvlzYJTicVFHrtQwsnymG=requests.post(url,data=payload,params=params,headers=fuDeaqhRENvlzYJTicVFHrtQwsnymb,cookies=cookies,allow_redirects=redirects)
  return fuDeaqhRENvlzYJTicVFHrtQwsnymG
 def Get_Now_Datetime(fuDeaqhRENvlzYJTicVFHrtQwsnymp):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def local_dic_To_jsonfile(fuDeaqhRENvlzYJTicVFHrtQwsnymp,filename,dic):
  if filename=='':return fuDeaqhRENvlzYJTicVFHrtQwsnymA
  try:
   fp=fuDeaqhRENvlzYJTicVFHrtQwsnymK(filename,'w',-1,'utf-8')
   json.dump(dic,fp)
   fp.close()
  except:
   return fuDeaqhRENvlzYJTicVFHrtQwsnymA
  return fuDeaqhRENvlzYJTicVFHrtQwsnymI
 def local_jsonfile_To_dic(fuDeaqhRENvlzYJTicVFHrtQwsnymp,filename):
  if filename=='':return fuDeaqhRENvlzYJTicVFHrtQwsnymL
  try:
   fp=fuDeaqhRENvlzYJTicVFHrtQwsnymK(filename,'r',-1,'utf-8')
   fuDeaqhRENvlzYJTicVFHrtQwsnymU=json.load(fp)
   fp.close()
  except:
   fuDeaqhRENvlzYJTicVFHrtQwsnymU={}
  return fuDeaqhRENvlzYJTicVFHrtQwsnymU
# Created by pyminifier (https://github.com/liftoff/pyminifier)
