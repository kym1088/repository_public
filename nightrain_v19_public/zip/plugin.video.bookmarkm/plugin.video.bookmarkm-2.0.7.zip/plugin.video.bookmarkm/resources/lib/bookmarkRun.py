__author__="NightRain"
OXGLKfWrFqxDneSAvMYgcNjEBwRQVa=object
OXGLKfWrFqxDneSAvMYgcNjEBwRQVC=None
OXGLKfWrFqxDneSAvMYgcNjEBwRQVU=True
OXGLKfWrFqxDneSAvMYgcNjEBwRQVP=False
OXGLKfWrFqxDneSAvMYgcNjEBwRQVs=type
OXGLKfWrFqxDneSAvMYgcNjEBwRQVm=dict
OXGLKfWrFqxDneSAvMYgcNjEBwRQVp=list
OXGLKfWrFqxDneSAvMYgcNjEBwRQVH=len
OXGLKfWrFqxDneSAvMYgcNjEBwRQVz=int
OXGLKfWrFqxDneSAvMYgcNjEBwRQVI=str
OXGLKfWrFqxDneSAvMYgcNjEBwRQVt=range
OXGLKfWrFqxDneSAvMYgcNjEBwRQVd=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import time
import urllib
import base64
import datetime
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
OXGLKfWrFqxDneSAvMYgcNjEBwRQhu=[{'title':'찜 목록 (웨이브+티빙+왓챠+쿠팡+넷플)','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'-','icon':'sum.png'},{'title':'-----------------','mode':'XXX'},{'title':'영화   찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'movie','icon':'movie.png'},{'title':'시리즈 찜 목록','mode':'BOOKMARK_GROUP','ott':'-','vidtype':'tvshow','icon':'tvshow.png'},{'title':'장르별 찜 목록','mode':'GENRE_GROUP','ott':'-','vidtype':'-','icon':'category.png'},{'title':'-----------------','mode':'XXX'},{'title':'웨이브 찜 목록','mode':'BOOKMARK_GROUP','ott':'wavve','vidtype':'-','icon':'wavve.png'},{'title':'티빙   찜 목록','mode':'BOOKMARK_GROUP','ott':'tving','vidtype':'-','icon':'tving.png'},{'title':'왓챠   찜 목록','mode':'BOOKMARK_GROUP','ott':'watcha','vidtype':'-','icon':'watcha.png'},{'title':'쿠팡   찜 목록','mode':'BOOKMARK_GROUP','ott':'coupang','vidtype':'-','icon':'coupang.png'},{'title':'넷플   찜 목록 (search mini 에서 등록)','mode':'BOOKMARK_GROUP','ott':'netflix','vidtype':'-','icon':'netflix.png'},{'title':'프라임비디오 찜 목록 (테스트용)','mode':'BOOKMARK_GROUP','ott':'amazon','vidtype':'-','icon':'primev.png'},{'title':'디즈니플러스 찜 목록','mode':'BOOKMARK_GROUP','ott':'disney','vidtype':'-','icon':'disney.jpg'},]
from bookmarkCore import*
class OXGLKfWrFqxDneSAvMYgcNjEBwRQhT(OXGLKfWrFqxDneSAvMYgcNjEBwRQVa):
 def __init__(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,OXGLKfWrFqxDneSAvMYgcNjEBwRQhV,OXGLKfWrFqxDneSAvMYgcNjEBwRQhC,OXGLKfWrFqxDneSAvMYgcNjEBwRQhU):
  OXGLKfWrFqxDneSAvMYgcNjEBwRQha._addon_url =OXGLKfWrFqxDneSAvMYgcNjEBwRQhV
  OXGLKfWrFqxDneSAvMYgcNjEBwRQha._addon_handle=OXGLKfWrFqxDneSAvMYgcNjEBwRQhC
  OXGLKfWrFqxDneSAvMYgcNjEBwRQha.main_params =OXGLKfWrFqxDneSAvMYgcNjEBwRQhU
  OXGLKfWrFqxDneSAvMYgcNjEBwRQha.LIB_PATH =''
  OXGLKfWrFqxDneSAvMYgcNjEBwRQha.LIST_LIMIT =20
  OXGLKfWrFqxDneSAvMYgcNjEBwRQha.BookmarkObj =fuDeaqhRENvlzYJTicVFHrtQwsnymj() 
 def addon_noti(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,sting):
  try:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhs=xbmcgui.Dialog()
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhs.notification(__addonname__,sting)
  except:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQVC
 def addon_log(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,string):
  try:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhm=string.encode('utf-8','ignore')
  except:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhm='addonException: addon_log'
  OXGLKfWrFqxDneSAvMYgcNjEBwRQhp=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,OXGLKfWrFqxDneSAvMYgcNjEBwRQhm),level=OXGLKfWrFqxDneSAvMYgcNjEBwRQhp)
 def get_settings_select_ott(OXGLKfWrFqxDneSAvMYgcNjEBwRQha):
  OXGLKfWrFqxDneSAvMYgcNjEBwRQhH =OXGLKfWrFqxDneSAvMYgcNjEBwRQVU if __addon__.getSetting('view_wavve')=='true' else OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  OXGLKfWrFqxDneSAvMYgcNjEBwRQhz =OXGLKfWrFqxDneSAvMYgcNjEBwRQVU if __addon__.getSetting('view_tving')=='true' else OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  OXGLKfWrFqxDneSAvMYgcNjEBwRQhI =OXGLKfWrFqxDneSAvMYgcNjEBwRQVU if __addon__.getSetting('view_watcha')=='true' else OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  OXGLKfWrFqxDneSAvMYgcNjEBwRQht=OXGLKfWrFqxDneSAvMYgcNjEBwRQVU if __addon__.getSetting('view_coupang')=='true' else OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  OXGLKfWrFqxDneSAvMYgcNjEBwRQhd=OXGLKfWrFqxDneSAvMYgcNjEBwRQVU if __addon__.getSetting('view_netflix')=='true' else OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  OXGLKfWrFqxDneSAvMYgcNjEBwRQho =OXGLKfWrFqxDneSAvMYgcNjEBwRQVU if __addon__.getSetting('view_primev')=='true' else OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  OXGLKfWrFqxDneSAvMYgcNjEBwRQhi =OXGLKfWrFqxDneSAvMYgcNjEBwRQVU if __addon__.getSetting('view_disney')=='true' else OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  return(OXGLKfWrFqxDneSAvMYgcNjEBwRQhH,OXGLKfWrFqxDneSAvMYgcNjEBwRQhz,OXGLKfWrFqxDneSAvMYgcNjEBwRQhI,OXGLKfWrFqxDneSAvMYgcNjEBwRQht,OXGLKfWrFqxDneSAvMYgcNjEBwRQhd,OXGLKfWrFqxDneSAvMYgcNjEBwRQho,OXGLKfWrFqxDneSAvMYgcNjEBwRQhi)
 def make_Index_Filename(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,tempyn=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_index_file.json'))
  else:
   return OXGLKfWrFqxDneSAvMYgcNjEBwRQha.LIB_PATH+'bookmark_index.json'
 def make_Vinfo_Filename(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,OXGLKfWrFqxDneSAvMYgcNjEBwRQuh,OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,tempyn=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP):
  if tempyn:
   return xbmcvfs.translatePath(os.path.join(__profile__,'temp_vinfo_file.json'))
  else:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhl='%s_%s.json'%(OXGLKfWrFqxDneSAvMYgcNjEBwRQuh,OXGLKfWrFqxDneSAvMYgcNjEBwRQuT)
   return OXGLKfWrFqxDneSAvMYgcNjEBwRQha.LIB_PATH+OXGLKfWrFqxDneSAvMYgcNjEBwRQhl
 def add_dir(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,label,sublabel='',ott='',img='',infoLabels=OXGLKfWrFqxDneSAvMYgcNjEBwRQVC,isFolder=OXGLKfWrFqxDneSAvMYgcNjEBwRQVU,params='',isLink=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP,ContextMenu=OXGLKfWrFqxDneSAvMYgcNjEBwRQVC,direct_url=OXGLKfWrFqxDneSAvMYgcNjEBwRQVC):
  if direct_url:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhy=direct_url 
  else:
   params={'mode':params.get('mode'),'values':params.get('values'),}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhb=json.dumps(params,separators=(',',':'))
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhb=base64.standard_b64encode(OXGLKfWrFqxDneSAvMYgcNjEBwRQhb.encode()).decode('utf-8')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhb=OXGLKfWrFqxDneSAvMYgcNjEBwRQhb.replace('+','%2B')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhy='%s?params=%s'%(OXGLKfWrFqxDneSAvMYgcNjEBwRQha._addon_url,OXGLKfWrFqxDneSAvMYgcNjEBwRQhb)
  if sublabel and sublabel!='-':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ='%s < %s >'%(label,sublabel)
  else: OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ=label
  if not img:img='DefaultFolder.png'
  if ott:OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ='%s - [%s]'%(OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,ott)
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTh=xbmcgui.ListItem(OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ)
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQVs(img)==OXGLKfWrFqxDneSAvMYgcNjEBwRQVm:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTh.setArt(img)
  else:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTh.setArt({'thumb':img,'poster':img})
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTu=[]
  if infoLabels!=OXGLKfWrFqxDneSAvMYgcNjEBwRQVC:
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQVs(infoLabels.get('cast'))==OXGLKfWrFqxDneSAvMYgcNjEBwRQVp:
    if OXGLKfWrFqxDneSAvMYgcNjEBwRQVH(infoLabels.get('cast'))>0 and OXGLKfWrFqxDneSAvMYgcNjEBwRQVs(infoLabels.get('cast')[0])==OXGLKfWrFqxDneSAvMYgcNjEBwRQVm:
     OXGLKfWrFqxDneSAvMYgcNjEBwRQTu=infoLabels.get('cast')
     infoLabels['cast']=[]
  if infoLabels:OXGLKfWrFqxDneSAvMYgcNjEBwRQTh.setInfo('Video',infoLabels)
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQVH(OXGLKfWrFqxDneSAvMYgcNjEBwRQTu)>0:OXGLKfWrFqxDneSAvMYgcNjEBwRQTh.setCast(OXGLKfWrFqxDneSAvMYgcNjEBwRQTu)
  if not isFolder and not isLink:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTh.setProperty('IsPlayable','true')
  if ContextMenu:OXGLKfWrFqxDneSAvMYgcNjEBwRQTh.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(OXGLKfWrFqxDneSAvMYgcNjEBwRQha._addon_handle,OXGLKfWrFqxDneSAvMYgcNjEBwRQhy,OXGLKfWrFqxDneSAvMYgcNjEBwRQTh,isFolder)
 def dp_Main_List(OXGLKfWrFqxDneSAvMYgcNjEBwRQha):
  (OXGLKfWrFqxDneSAvMYgcNjEBwRQhH,OXGLKfWrFqxDneSAvMYgcNjEBwRQhz,OXGLKfWrFqxDneSAvMYgcNjEBwRQhI,OXGLKfWrFqxDneSAvMYgcNjEBwRQht,OXGLKfWrFqxDneSAvMYgcNjEBwRQhd,OXGLKfWrFqxDneSAvMYgcNjEBwRQho,OXGLKfWrFqxDneSAvMYgcNjEBwRQhi)=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.get_settings_select_ott()
  for OXGLKfWrFqxDneSAvMYgcNjEBwRQTV in OXGLKfWrFqxDneSAvMYgcNjEBwRQhu:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ=OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('title')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTC=''
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('ott')=='wavve' and OXGLKfWrFqxDneSAvMYgcNjEBwRQhH ==OXGLKfWrFqxDneSAvMYgcNjEBwRQVP:continue
   elif OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('ott')=='tving' and OXGLKfWrFqxDneSAvMYgcNjEBwRQhz ==OXGLKfWrFqxDneSAvMYgcNjEBwRQVP:continue
   elif OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('ott')=='watcha' and OXGLKfWrFqxDneSAvMYgcNjEBwRQhI ==OXGLKfWrFqxDneSAvMYgcNjEBwRQVP:continue
   elif OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('ott')=='coupang' and OXGLKfWrFqxDneSAvMYgcNjEBwRQht==OXGLKfWrFqxDneSAvMYgcNjEBwRQVP:continue
   elif OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('ott')=='netflix' and OXGLKfWrFqxDneSAvMYgcNjEBwRQhd==OXGLKfWrFqxDneSAvMYgcNjEBwRQVP:continue
   elif OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('ott')=='amazon' and OXGLKfWrFqxDneSAvMYgcNjEBwRQho ==OXGLKfWrFqxDneSAvMYgcNjEBwRQVP:continue
   elif OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('ott')=='disney' and OXGLKfWrFqxDneSAvMYgcNjEBwRQhi ==OXGLKfWrFqxDneSAvMYgcNjEBwRQVP:continue
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhk={'mode':OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('mode'),'values':{'ott':OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('ott'),'vidtype':OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('vidtype'),'page':'1',},}
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('mode')=='XXX':
    OXGLKfWrFqxDneSAvMYgcNjEBwRQhk['mode']='XXX'
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTU=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTP =OXGLKfWrFqxDneSAvMYgcNjEBwRQVU
   else:
    if 'icon' in OXGLKfWrFqxDneSAvMYgcNjEBwRQTV:
     OXGLKfWrFqxDneSAvMYgcNjEBwRQTC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',OXGLKfWrFqxDneSAvMYgcNjEBwRQTV.get('icon')) 
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTU=OXGLKfWrFqxDneSAvMYgcNjEBwRQVU
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTP =OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.add_dir(OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,sublabel='',ott='',img=OXGLKfWrFqxDneSAvMYgcNjEBwRQTC,infoLabels=OXGLKfWrFqxDneSAvMYgcNjEBwRQVC,isFolder=OXGLKfWrFqxDneSAvMYgcNjEBwRQTU,params=OXGLKfWrFqxDneSAvMYgcNjEBwRQhk,isLink=OXGLKfWrFqxDneSAvMYgcNjEBwRQTP)
  xbmcplugin.endOfDirectory(OXGLKfWrFqxDneSAvMYgcNjEBwRQha._addon_handle)
 def dp_Genre_Grouplist(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,args):
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTm=[]
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTp=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.make_Index_Filename(tempyn=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP)
  if xbmcvfs.exists(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp):
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTH=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.jsonfile_To_dic(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp)
  else:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTH=[]
  for OXGLKfWrFqxDneSAvMYgcNjEBwRQTz in OXGLKfWrFqxDneSAvMYgcNjEBwRQTH:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTI =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('genre')
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQTI not in OXGLKfWrFqxDneSAvMYgcNjEBwRQTm:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTm.append(OXGLKfWrFqxDneSAvMYgcNjEBwRQTI)
  for OXGLKfWrFqxDneSAvMYgcNjEBwRQTI in OXGLKfWrFqxDneSAvMYgcNjEBwRQTm:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhk={'mode':'BOOKMARK_GROUP','values':{'ott':'-','vidtype':'-','genre':OXGLKfWrFqxDneSAvMYgcNjEBwRQTI,'page':'1',},}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.add_dir(OXGLKfWrFqxDneSAvMYgcNjEBwRQTI,sublabel='',ott='',img='',infoLabels=OXGLKfWrFqxDneSAvMYgcNjEBwRQVC,isFolder=OXGLKfWrFqxDneSAvMYgcNjEBwRQVU,params=OXGLKfWrFqxDneSAvMYgcNjEBwRQhk)
  xbmcplugin.endOfDirectory(OXGLKfWrFqxDneSAvMYgcNjEBwRQha._addon_handle)
 def dp_Bookmark_Grouplist(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,args):
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTt =OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTd =[]
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTo =args.get('ott')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTi=args.get('vidtype')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTl =args.get('genre')
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQTl==OXGLKfWrFqxDneSAvMYgcNjEBwRQVC:OXGLKfWrFqxDneSAvMYgcNjEBwRQTl='all'
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTy =OXGLKfWrFqxDneSAvMYgcNjEBwRQVz(args.get('page'))
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTk =OXGLKfWrFqxDneSAvMYgcNjEBwRQha.LIST_LIMIT*(OXGLKfWrFqxDneSAvMYgcNjEBwRQTy-1)+1 
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTb =OXGLKfWrFqxDneSAvMYgcNjEBwRQha.LIST_LIMIT*OXGLKfWrFqxDneSAvMYgcNjEBwRQTy
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTp=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.make_Index_Filename(tempyn=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP)
  if xbmcvfs.exists(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp):
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTH=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.jsonfile_To_dic(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp)
  else:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTH=[]
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTJ=0
  for OXGLKfWrFqxDneSAvMYgcNjEBwRQTz in OXGLKfWrFqxDneSAvMYgcNjEBwRQTH:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuh =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('ott')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuT =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('videoid')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQua =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('vidtype')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuV =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('genre')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuC =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('linkUrl')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuU =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('encodedId')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuP =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('contentId')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQus=OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('contentClass')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQum=OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('contentSlugs')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQup =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('entityId')
   if not(OXGLKfWrFqxDneSAvMYgcNjEBwRQTo=='-' or OXGLKfWrFqxDneSAvMYgcNjEBwRQTo==OXGLKfWrFqxDneSAvMYgcNjEBwRQuh):continue
   if not(OXGLKfWrFqxDneSAvMYgcNjEBwRQTi=='-' or OXGLKfWrFqxDneSAvMYgcNjEBwRQTi==OXGLKfWrFqxDneSAvMYgcNjEBwRQua):continue
   if not(OXGLKfWrFqxDneSAvMYgcNjEBwRQTl=='all' or OXGLKfWrFqxDneSAvMYgcNjEBwRQTl==OXGLKfWrFqxDneSAvMYgcNjEBwRQuV):continue
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTJ+=1
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQTk>OXGLKfWrFqxDneSAvMYgcNjEBwRQTJ:continue
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQTb<OXGLKfWrFqxDneSAvMYgcNjEBwRQTJ:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTt=OXGLKfWrFqxDneSAvMYgcNjEBwRQVU
    break
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuH=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.make_Vinfo_Filename(OXGLKfWrFqxDneSAvMYgcNjEBwRQuh,OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,tempyn=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP)
   if xbmcvfs.exists(OXGLKfWrFqxDneSAvMYgcNjEBwRQuH):
    OXGLKfWrFqxDneSAvMYgcNjEBwRQuz=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.jsonfile_To_dic(OXGLKfWrFqxDneSAvMYgcNjEBwRQuH)
    OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ =OXGLKfWrFqxDneSAvMYgcNjEBwRQuz.get('title')
    OXGLKfWrFqxDneSAvMYgcNjEBwRQuI =OXGLKfWrFqxDneSAvMYgcNjEBwRQuz.get('subtitle')
    OXGLKfWrFqxDneSAvMYgcNjEBwRQut =OXGLKfWrFqxDneSAvMYgcNjEBwRQuz.get('thumbnail')
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTa=OXGLKfWrFqxDneSAvMYgcNjEBwRQuz.get('infoLabels')
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('title')
    OXGLKfWrFqxDneSAvMYgcNjEBwRQuI =''
    OXGLKfWrFqxDneSAvMYgcNjEBwRQut =''
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTa={'mpaa':'0'}
    OXGLKfWrFqxDneSAvMYgcNjEBwRQuz ={'infoLabels':{'title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ}}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhk={'ott':OXGLKfWrFqxDneSAvMYgcNjEBwRQuh,'videoid':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'vidtype':OXGLKfWrFqxDneSAvMYgcNjEBwRQua,'title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'thumbnail':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,'mpaa':OXGLKfWrFqxDneSAvMYgcNjEBwRQVI(OXGLKfWrFqxDneSAvMYgcNjEBwRQTa.get('mpaa')),'duration':OXGLKfWrFqxDneSAvMYgcNjEBwRQVI(OXGLKfWrFqxDneSAvMYgcNjEBwRQTa.get('duration')),'linkUrl':OXGLKfWrFqxDneSAvMYgcNjEBwRQuC,'infoLabels':OXGLKfWrFqxDneSAvMYgcNjEBwRQTa,'encodedId':OXGLKfWrFqxDneSAvMYgcNjEBwRQuU,'contentId':OXGLKfWrFqxDneSAvMYgcNjEBwRQuP,'contentClass':OXGLKfWrFqxDneSAvMYgcNjEBwRQus,'contentSlugs':OXGLKfWrFqxDneSAvMYgcNjEBwRQum,'entityId':OXGLKfWrFqxDneSAvMYgcNjEBwRQup,}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQud={'mode':'BOOKMARK_REMOVE','values':{'list':[OXGLKfWrFqxDneSAvMYgcNjEBwRQTz],},}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuo=json.dumps(OXGLKfWrFqxDneSAvMYgcNjEBwRQud,separators=(',',':'))
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuo=base64.standard_b64encode(OXGLKfWrFqxDneSAvMYgcNjEBwRQuo.encode()).decode('utf-8')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuo=OXGLKfWrFqxDneSAvMYgcNjEBwRQuo.replace('+','%2B')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQui=[('찜 목록 ( %s ) 삭제'%(OXGLKfWrFqxDneSAvMYgcNjEBwRQuz.get('infoLabels').get('title')),'RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(OXGLKfWrFqxDneSAvMYgcNjEBwRQuo))]
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQTl!='all':
    OXGLKfWrFqxDneSAvMYgcNjEBwRQud={'mode':'GENRE_RENAME','values':{'list':[OXGLKfWrFqxDneSAvMYgcNjEBwRQTz],},}
    OXGLKfWrFqxDneSAvMYgcNjEBwRQuo=json.dumps(OXGLKfWrFqxDneSAvMYgcNjEBwRQud,separators=(',',':'))
    OXGLKfWrFqxDneSAvMYgcNjEBwRQuo=base64.standard_b64encode(OXGLKfWrFqxDneSAvMYgcNjEBwRQuo.encode()).decode('utf-8')
    OXGLKfWrFqxDneSAvMYgcNjEBwRQuo=OXGLKfWrFqxDneSAvMYgcNjEBwRQuo.replace('+','%2B')
    OXGLKfWrFqxDneSAvMYgcNjEBwRQui.append(('장르명 ( %s ) 수정'%(OXGLKfWrFqxDneSAvMYgcNjEBwRQTl),'RunPlugin(plugin://plugin.video.bookmarkm/?params=%s)'%(OXGLKfWrFqxDneSAvMYgcNjEBwRQuo)))
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.make_Hyper_Link(OXGLKfWrFqxDneSAvMYgcNjEBwRQhk)
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQua=='tvshow':
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTU=OXGLKfWrFqxDneSAvMYgcNjEBwRQVU
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTU=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.add_dir(OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,sublabel=OXGLKfWrFqxDneSAvMYgcNjEBwRQuI,ott=OXGLKfWrFqxDneSAvMYgcNjEBwRQuh,img=OXGLKfWrFqxDneSAvMYgcNjEBwRQut,infoLabels=OXGLKfWrFqxDneSAvMYgcNjEBwRQTa,isFolder=OXGLKfWrFqxDneSAvMYgcNjEBwRQTU,params=OXGLKfWrFqxDneSAvMYgcNjEBwRQVC,isLink=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP,ContextMenu=OXGLKfWrFqxDneSAvMYgcNjEBwRQui,direct_url=OXGLKfWrFqxDneSAvMYgcNjEBwRQul)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTd.append(OXGLKfWrFqxDneSAvMYgcNjEBwRQTz)
  OXGLKfWrFqxDneSAvMYgcNjEBwRQuy={'plot':'현재페이지의 전체목록을 삭제합니다.'}
  OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ='* 현재페이지 목록 삭제 (개별삭제는 팝업메뉴) *'
  OXGLKfWrFqxDneSAvMYgcNjEBwRQhk={'mode':'BOOKMARK_REMOVE','values':{'list':OXGLKfWrFqxDneSAvMYgcNjEBwRQTd,},}
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  OXGLKfWrFqxDneSAvMYgcNjEBwRQha.add_dir(OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,sublabel='',ott='',img=OXGLKfWrFqxDneSAvMYgcNjEBwRQTC,infoLabels=OXGLKfWrFqxDneSAvMYgcNjEBwRQuy,isFolder=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP,params=OXGLKfWrFqxDneSAvMYgcNjEBwRQhk,isLink=OXGLKfWrFqxDneSAvMYgcNjEBwRQVU)
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQTt:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhk={'mode':'BOOKMARK_GROUP','velues':{'ott':OXGLKfWrFqxDneSAvMYgcNjEBwRQTo,'vidtype':OXGLKfWrFqxDneSAvMYgcNjEBwRQTi,'page':OXGLKfWrFqxDneSAvMYgcNjEBwRQVI(OXGLKfWrFqxDneSAvMYgcNjEBwRQTy+1)},}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ='[B]%s >>[/B]'%'다음 페이지'
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuI=OXGLKfWrFqxDneSAvMYgcNjEBwRQVI(OXGLKfWrFqxDneSAvMYgcNjEBwRQTy+1)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.add_dir(OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,sublabel=OXGLKfWrFqxDneSAvMYgcNjEBwRQuI,ott='',img=OXGLKfWrFqxDneSAvMYgcNjEBwRQTC,infoLabels=OXGLKfWrFqxDneSAvMYgcNjEBwRQVC,isFolder=OXGLKfWrFqxDneSAvMYgcNjEBwRQVU,params=OXGLKfWrFqxDneSAvMYgcNjEBwRQhk)
  xbmcplugin.setContent(OXGLKfWrFqxDneSAvMYgcNjEBwRQha._addon_handle,'movies')
  xbmcplugin.endOfDirectory(OXGLKfWrFqxDneSAvMYgcNjEBwRQha._addon_handle)
 def get_keyboard_input(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,defalut,OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ):
  OXGLKfWrFqxDneSAvMYgcNjEBwRQuk=OXGLKfWrFqxDneSAvMYgcNjEBwRQVC
  kb=xbmc.Keyboard(defalut,OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,OXGLKfWrFqxDneSAvMYgcNjEBwRQVP)
  kb.setHeading(OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuk=kb.getText()
  return OXGLKfWrFqxDneSAvMYgcNjEBwRQuk
 def dp_Genre_Rename(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,args):
  OXGLKfWrFqxDneSAvMYgcNjEBwRQub =OXGLKfWrFqxDneSAvMYgcNjEBwRQVU
  OXGLKfWrFqxDneSAvMYgcNjEBwRQuJ ={}
  try:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQah=args.get('list')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQah=OXGLKfWrFqxDneSAvMYgcNjEBwRQah.replace('\'','\"')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQah=json.loads(OXGLKfWrFqxDneSAvMYgcNjEBwRQah)
  except:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQub=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQVH(OXGLKfWrFqxDneSAvMYgcNjEBwRQah)!=0:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaT=OXGLKfWrFqxDneSAvMYgcNjEBwRQah[0].get('genre')
   else:
    return
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQau=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.get_keyboard_input(OXGLKfWrFqxDneSAvMYgcNjEBwRQaT,__language__(30909).encode('utf-8'))
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQau!=OXGLKfWrFqxDneSAvMYgcNjEBwRQVC:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQau=OXGLKfWrFqxDneSAvMYgcNjEBwRQau.strip()
   else:
    return
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQaT==OXGLKfWrFqxDneSAvMYgcNjEBwRQau:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQha.addon_noti(__language__(30910).encode('utf-8'))
    return
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   for OXGLKfWrFqxDneSAvMYgcNjEBwRQaV in OXGLKfWrFqxDneSAvMYgcNjEBwRQah:
    if OXGLKfWrFqxDneSAvMYgcNjEBwRQaV['ott']in OXGLKfWrFqxDneSAvMYgcNjEBwRQuJ:
     OXGLKfWrFqxDneSAvMYgcNjEBwRQuJ[OXGLKfWrFqxDneSAvMYgcNjEBwRQaV['ott']].append(OXGLKfWrFqxDneSAvMYgcNjEBwRQaV['videoid'])
    else:
     OXGLKfWrFqxDneSAvMYgcNjEBwRQuJ[OXGLKfWrFqxDneSAvMYgcNjEBwRQaV['ott']]=[OXGLKfWrFqxDneSAvMYgcNjEBwRQaV['videoid']]
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTp=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.make_Index_Filename(tempyn=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP)
   if xbmcvfs.exists(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp):
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTH=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.jsonfile_To_dic(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp)
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   for i in OXGLKfWrFqxDneSAvMYgcNjEBwRQVt(OXGLKfWrFqxDneSAvMYgcNjEBwRQVH(OXGLKfWrFqxDneSAvMYgcNjEBwRQTH)):
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaC =OXGLKfWrFqxDneSAvMYgcNjEBwRQTH[i].get('ott')
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaU=OXGLKfWrFqxDneSAvMYgcNjEBwRQTH[i].get('videoid')
    if OXGLKfWrFqxDneSAvMYgcNjEBwRQaC in OXGLKfWrFqxDneSAvMYgcNjEBwRQuJ:
     if OXGLKfWrFqxDneSAvMYgcNjEBwRQaU in OXGLKfWrFqxDneSAvMYgcNjEBwRQuJ[OXGLKfWrFqxDneSAvMYgcNjEBwRQaC]:
      OXGLKfWrFqxDneSAvMYgcNjEBwRQTH[i]['genre']=OXGLKfWrFqxDneSAvMYgcNjEBwRQau
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQub=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.dic_To_jsonfile(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp,OXGLKfWrFqxDneSAvMYgcNjEBwRQTH)
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.addon_noti(__language__(30911).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.addon_noti(__language__(30912).encode('utf-8'))
 def dp_Bookmark_Remove(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,args):
  OXGLKfWrFqxDneSAvMYgcNjEBwRQub =OXGLKfWrFqxDneSAvMYgcNjEBwRQVU
  OXGLKfWrFqxDneSAvMYgcNjEBwRQaP ={}
  OXGLKfWrFqxDneSAvMYgcNjEBwRQhs=xbmcgui.Dialog()
  OXGLKfWrFqxDneSAvMYgcNjEBwRQas=OXGLKfWrFqxDneSAvMYgcNjEBwRQhs.yesno(__language__(30905).encode('utf8'),__language__(30906).encode('utf8'))
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQas==OXGLKfWrFqxDneSAvMYgcNjEBwRQVP:sys.exit()
  OXGLKfWrFqxDneSAvMYgcNjEBwRQah=args.get('list')
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   for OXGLKfWrFqxDneSAvMYgcNjEBwRQaV in OXGLKfWrFqxDneSAvMYgcNjEBwRQah:
    if OXGLKfWrFqxDneSAvMYgcNjEBwRQaV['ott']in OXGLKfWrFqxDneSAvMYgcNjEBwRQaP:
     OXGLKfWrFqxDneSAvMYgcNjEBwRQaP[OXGLKfWrFqxDneSAvMYgcNjEBwRQaV['ott']].append(OXGLKfWrFqxDneSAvMYgcNjEBwRQaV['videoid'])
    else:
     OXGLKfWrFqxDneSAvMYgcNjEBwRQaP[OXGLKfWrFqxDneSAvMYgcNjEBwRQaV['ott']]=[OXGLKfWrFqxDneSAvMYgcNjEBwRQaV['videoid']]
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTp=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.make_Index_Filename(tempyn=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP)
   if xbmcvfs.exists(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp):
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTH=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.jsonfile_To_dic(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp)
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTz=[]
   for OXGLKfWrFqxDneSAvMYgcNjEBwRQam in OXGLKfWrFqxDneSAvMYgcNjEBwRQTH:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaC =OXGLKfWrFqxDneSAvMYgcNjEBwRQam.get('ott')
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaU=OXGLKfWrFqxDneSAvMYgcNjEBwRQam.get('videoid')
    if OXGLKfWrFqxDneSAvMYgcNjEBwRQaC in OXGLKfWrFqxDneSAvMYgcNjEBwRQaP:
     if OXGLKfWrFqxDneSAvMYgcNjEBwRQaU in OXGLKfWrFqxDneSAvMYgcNjEBwRQaP[OXGLKfWrFqxDneSAvMYgcNjEBwRQaC]:
      OXGLKfWrFqxDneSAvMYgcNjEBwRQuH=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.make_Vinfo_Filename(OXGLKfWrFqxDneSAvMYgcNjEBwRQaC,OXGLKfWrFqxDneSAvMYgcNjEBwRQaU,tempyn=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP)
      xbmcvfs.delete(OXGLKfWrFqxDneSAvMYgcNjEBwRQuH)
      continue
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.append(OXGLKfWrFqxDneSAvMYgcNjEBwRQam)
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQVC
   OXGLKfWrFqxDneSAvMYgcNjEBwRQub=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.dic_To_jsonfile(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp,OXGLKfWrFqxDneSAvMYgcNjEBwRQTz)
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.addon_noti(__language__(30908).encode('utf-8'))
   xbmc.executebuiltin("Container.Refresh")
  else:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.addon_noti(__language__(30907).encode('utf-8'))
 def make_Hyper_Link(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,args):
  OXGLKfWrFqxDneSAvMYgcNjEBwRQul=''
  OXGLKfWrFqxDneSAvMYgcNjEBwRQuh =args.get('ott')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQuT =args.get('videoid')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQua =args.get('vidtype')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ =args.get('title')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQut =args.get('thumbnail')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQap =args.get('mpaa')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQuC =args.get('linkUrl')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQaH =args.get('duration')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTa =args.get('infoLabels')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQuU =args.get('encodedId')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQuP =args.get('contentId')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQus=args.get('contentClass')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQum=args.get('contentSlugs')
  OXGLKfWrFqxDneSAvMYgcNjEBwRQup =args.get('entityId')
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQuh=='wavve':
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQua=='tvshow':
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'SEASON_LIST','videoid':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'vidtype':OXGLKfWrFqxDneSAvMYgcNjEBwRQua,}
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'MOVIE','contentid':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'thumbnail':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,'age':OXGLKfWrFqxDneSAvMYgcNjEBwRQap,}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQaI=urllib.parse.urlencode(OXGLKfWrFqxDneSAvMYgcNjEBwRQaz)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul='plugin://plugin.video.wavvem/?'
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul+=OXGLKfWrFqxDneSAvMYgcNjEBwRQaI
  elif OXGLKfWrFqxDneSAvMYgcNjEBwRQuh=='tving':
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQua=='tvshow':
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'EPISODE','programcode':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'page':'1',}
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'MOVIE','stype':'movie','mediacode':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'thumbnail':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQaI=urllib.parse.urlencode(OXGLKfWrFqxDneSAvMYgcNjEBwRQaz)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul='plugin://plugin.video.tvingm/?'
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul+=OXGLKfWrFqxDneSAvMYgcNjEBwRQaI
  elif OXGLKfWrFqxDneSAvMYgcNjEBwRQuh=='watcha':
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQua=='tvshow':
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'EPISODE','movie_code':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'season_code':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'page':'1',}
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'MOVIE','movie_code':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'season_code':'-','title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'thumbnail':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQaI=urllib.parse.urlencode(OXGLKfWrFqxDneSAvMYgcNjEBwRQaz)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul='plugin://plugin.video.watcham/?'
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul+=OXGLKfWrFqxDneSAvMYgcNjEBwRQaI
  elif OXGLKfWrFqxDneSAvMYgcNjEBwRQuh=='coupang':
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQua=='tvshow':
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'SEASON_LIST','id':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'asis':'TVSHOW','title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'thumbnail':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,'page':'1',}
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'MOVIE','id':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'asis':'MOVIE','title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'thumbnail':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQaI=urllib.parse.urlencode(OXGLKfWrFqxDneSAvMYgcNjEBwRQaz)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul='plugin://plugin.video.coupangm/?'
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul+=OXGLKfWrFqxDneSAvMYgcNjEBwRQaI
  elif OXGLKfWrFqxDneSAvMYgcNjEBwRQuh=='netflix':
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQua=='tvshow':
    OXGLKfWrFqxDneSAvMYgcNjEBwRQul='plugin://plugin.video.netflix/directory/show/%s/'%(OXGLKfWrFqxDneSAvMYgcNjEBwRQuT)
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQul='plugin://plugin.video.netflix/play/movie/%s/'%(OXGLKfWrFqxDneSAvMYgcNjEBwRQuT)
  elif OXGLKfWrFqxDneSAvMYgcNjEBwRQuh=='amazon':
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQua=='tvshow':
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'SEASON_LIST','values':{'titleID':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'linkUrl':OXGLKfWrFqxDneSAvMYgcNjEBwRQuC,'duration':OXGLKfWrFqxDneSAvMYgcNjEBwRQaH,'vType':OXGLKfWrFqxDneSAvMYgcNjEBwRQua,'image':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,'title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'infoLabels':OXGLKfWrFqxDneSAvMYgcNjEBwRQTa,}}
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'MOVIE','values':{'titleID':OXGLKfWrFqxDneSAvMYgcNjEBwRQuT,'linkUrl':OXGLKfWrFqxDneSAvMYgcNjEBwRQuC,'duration':OXGLKfWrFqxDneSAvMYgcNjEBwRQaH,'vType':OXGLKfWrFqxDneSAvMYgcNjEBwRQua,'image':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,'title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'infoLabels':OXGLKfWrFqxDneSAvMYgcNjEBwRQTa,}}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQaI=json.dumps(OXGLKfWrFqxDneSAvMYgcNjEBwRQaz,separators=(',',':'))
   OXGLKfWrFqxDneSAvMYgcNjEBwRQaI=base64.standard_b64encode(OXGLKfWrFqxDneSAvMYgcNjEBwRQaI.encode()).decode('utf-8')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQaI=OXGLKfWrFqxDneSAvMYgcNjEBwRQaI.replace('+','%2B')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul='plugin://plugin.video.primevm/?params='
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul+=OXGLKfWrFqxDneSAvMYgcNjEBwRQaI
  elif OXGLKfWrFqxDneSAvMYgcNjEBwRQuh=='disney':
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQua=='tvshow':
    if OXGLKfWrFqxDneSAvMYgcNjEBwRQup: 
     OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'SEASON_LIST','values':{'entityId':OXGLKfWrFqxDneSAvMYgcNjEBwRQup,'vType':OXGLKfWrFqxDneSAvMYgcNjEBwRQua,'image':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,'title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'programTitle':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'infoLabels':OXGLKfWrFqxDneSAvMYgcNjEBwRQTa,}}
    elif OXGLKfWrFqxDneSAvMYgcNjEBwRQuU:
     OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'SEASON_LIST','values':{'encodedId':OXGLKfWrFqxDneSAvMYgcNjEBwRQuU,'vType':OXGLKfWrFqxDneSAvMYgcNjEBwRQua,'image':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,'title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'programTitle':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'infoLabels':OXGLKfWrFqxDneSAvMYgcNjEBwRQTa,}}
    else:
     OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'PROGRAM_LIST','values':{'contentClass':OXGLKfWrFqxDneSAvMYgcNjEBwRQus,'contentSlugs':OXGLKfWrFqxDneSAvMYgcNjEBwRQum,'vType':OXGLKfWrFqxDneSAvMYgcNjEBwRQua,'image':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,'title':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'programTitle':OXGLKfWrFqxDneSAvMYgcNjEBwRQhJ,'infoLabels':OXGLKfWrFqxDneSAvMYgcNjEBwRQTa,}}
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaz={'mode':'MOVIE','values':{'contentId':OXGLKfWrFqxDneSAvMYgcNjEBwRQuP,'vType':OXGLKfWrFqxDneSAvMYgcNjEBwRQua,'image':OXGLKfWrFqxDneSAvMYgcNjEBwRQut,'title':OXGLKfWrFqxDneSAvMYgcNjEBwRQTa['title'],'programTitle':OXGLKfWrFqxDneSAvMYgcNjEBwRQTa['title'],'infoLabels':OXGLKfWrFqxDneSAvMYgcNjEBwRQTa,'entityId':OXGLKfWrFqxDneSAvMYgcNjEBwRQup,}}
   OXGLKfWrFqxDneSAvMYgcNjEBwRQaI=json.dumps(OXGLKfWrFqxDneSAvMYgcNjEBwRQaz,separators=(',',':'))
   OXGLKfWrFqxDneSAvMYgcNjEBwRQaI=base64.standard_b64encode(OXGLKfWrFqxDneSAvMYgcNjEBwRQaI.encode()).decode('utf-8')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQaI=OXGLKfWrFqxDneSAvMYgcNjEBwRQaI.replace('+','%2B')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul='plugin://plugin.video.disneym/?params='
   OXGLKfWrFqxDneSAvMYgcNjEBwRQul+=OXGLKfWrFqxDneSAvMYgcNjEBwRQaI
  return OXGLKfWrFqxDneSAvMYgcNjEBwRQul
 def dp_Set_Bookmark(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,args):
  OXGLKfWrFqxDneSAvMYgcNjEBwRQub =OXGLKfWrFqxDneSAvMYgcNjEBwRQVU
  OXGLKfWrFqxDneSAvMYgcNjEBwRQTH=[]
  OXGLKfWrFqxDneSAvMYgcNjEBwRQat=args.get('VIDEO_INFO')
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQat:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTz=OXGLKfWrFqxDneSAvMYgcNjEBwRQat.get('indexinfo')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuz =OXGLKfWrFqxDneSAvMYgcNjEBwRQat.get('saveinfo')
  else:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQad =urllib.parse.unquote(args.get('bm_param'))
   OXGLKfWrFqxDneSAvMYgcNjEBwRQad =json.loads(OXGLKfWrFqxDneSAvMYgcNjEBwRQad)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTz=OXGLKfWrFqxDneSAvMYgcNjEBwRQad.get('indexinfo')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuz =OXGLKfWrFqxDneSAvMYgcNjEBwRQad.get('saveinfo')
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQuH=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.make_Vinfo_Filename(OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('ott'),OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('videoid'),tempyn=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQub=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.dic_To_jsonfile(OXGLKfWrFqxDneSAvMYgcNjEBwRQuH,OXGLKfWrFqxDneSAvMYgcNjEBwRQuz)
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTp=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.make_Index_Filename(tempyn=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP)
   if xbmcvfs.exists(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp):
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTH=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.jsonfile_To_dic(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp)
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTH=[]
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQao =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('ott')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQai =OXGLKfWrFqxDneSAvMYgcNjEBwRQTz.get('videoid')
   for i in OXGLKfWrFqxDneSAvMYgcNjEBwRQVt(OXGLKfWrFqxDneSAvMYgcNjEBwRQVH(OXGLKfWrFqxDneSAvMYgcNjEBwRQTH)):
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaC =OXGLKfWrFqxDneSAvMYgcNjEBwRQTH[i].get('ott')
    OXGLKfWrFqxDneSAvMYgcNjEBwRQaU=OXGLKfWrFqxDneSAvMYgcNjEBwRQTH[i].get('videoid')
    if OXGLKfWrFqxDneSAvMYgcNjEBwRQao==OXGLKfWrFqxDneSAvMYgcNjEBwRQaC and OXGLKfWrFqxDneSAvMYgcNjEBwRQai==OXGLKfWrFqxDneSAvMYgcNjEBwRQaU:
     OXGLKfWrFqxDneSAvMYgcNjEBwRQTH.pop(i)
     break
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTz['title']=OXGLKfWrFqxDneSAvMYgcNjEBwRQuz.get('title')
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQVH(OXGLKfWrFqxDneSAvMYgcNjEBwRQuz.get('infoLabels').get('genre'))>0:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTz['genre']=OXGLKfWrFqxDneSAvMYgcNjEBwRQuz.get('infoLabels').get('genre')[0]
   else:
    OXGLKfWrFqxDneSAvMYgcNjEBwRQTz['genre']='-'
   OXGLKfWrFqxDneSAvMYgcNjEBwRQTH.insert(0,OXGLKfWrFqxDneSAvMYgcNjEBwRQTz)
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQub=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.dic_To_jsonfile(OXGLKfWrFqxDneSAvMYgcNjEBwRQTp,OXGLKfWrFqxDneSAvMYgcNjEBwRQTH)
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQub==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.addon_noti(__language__(30903).encode('utf8'))
  else:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.addon_noti(__language__(30904).encode('utf-8'))
 def option_check(OXGLKfWrFqxDneSAvMYgcNjEBwRQha):
  OXGLKfWrFqxDneSAvMYgcNjEBwRQal=OXGLKfWrFqxDneSAvMYgcNjEBwRQVU
  OXGLKfWrFqxDneSAvMYgcNjEBwRQha.LIB_PATH =(__addon__.getSetting('libpath')).strip()
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQha.LIB_PATH=='':OXGLKfWrFqxDneSAvMYgcNjEBwRQal=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQal==OXGLKfWrFqxDneSAvMYgcNjEBwRQVP:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQhs=xbmcgui.Dialog()
   OXGLKfWrFqxDneSAvMYgcNjEBwRQas=OXGLKfWrFqxDneSAvMYgcNjEBwRQhs.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if OXGLKfWrFqxDneSAvMYgcNjEBwRQas==OXGLKfWrFqxDneSAvMYgcNjEBwRQVU:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
 def dic_To_jsonfile(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,filename,OXGLKfWrFqxDneSAvMYgcNjEBwRQay):
  if filename=='':return OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  try:
   fp=xbmcvfs.File(filename,'w')
   json.dump(OXGLKfWrFqxDneSAvMYgcNjEBwRQay,fp,indent=4,ensure_ascii=OXGLKfWrFqxDneSAvMYgcNjEBwRQVP)
   fp.close()
  except:
   return OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  return OXGLKfWrFqxDneSAvMYgcNjEBwRQVU
 def jsonfile_To_dic(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,filename):
  if filename=='':return OXGLKfWrFqxDneSAvMYgcNjEBwRQVC
  try:
   fp=xbmcvfs.File(filename)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQab=json.load(fp)
   fp.close()
  except:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQab={}
  return OXGLKfWrFqxDneSAvMYgcNjEBwRQab
 def TextFile_Save(OXGLKfWrFqxDneSAvMYgcNjEBwRQha,filename,resText):
  if filename=='':return OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  try:
   fp=OXGLKfWrFqxDneSAvMYgcNjEBwRQVd(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return OXGLKfWrFqxDneSAvMYgcNjEBwRQVP
  return OXGLKfWrFqxDneSAvMYgcNjEBwRQVU
 def bookmark_main(OXGLKfWrFqxDneSAvMYgcNjEBwRQha):
  OXGLKfWrFqxDneSAvMYgcNjEBwRQaJ=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.main_params.get('params')
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQaJ:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.addon_log('paramJson -> '+OXGLKfWrFqxDneSAvMYgcNjEBwRQaJ)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQVh =base64.standard_b64decode(OXGLKfWrFqxDneSAvMYgcNjEBwRQaJ).decode('utf-8')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQVh =json.loads(OXGLKfWrFqxDneSAvMYgcNjEBwRQVh)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQVT =OXGLKfWrFqxDneSAvMYgcNjEBwRQVh.get('mode')
   OXGLKfWrFqxDneSAvMYgcNjEBwRQVu =OXGLKfWrFqxDneSAvMYgcNjEBwRQVh.get('values')
  else:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQVT=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.main_params.get('mode',OXGLKfWrFqxDneSAvMYgcNjEBwRQVC)
   OXGLKfWrFqxDneSAvMYgcNjEBwRQVu=OXGLKfWrFqxDneSAvMYgcNjEBwRQha.main_params
  OXGLKfWrFqxDneSAvMYgcNjEBwRQha.option_check()
  if OXGLKfWrFqxDneSAvMYgcNjEBwRQVT is OXGLKfWrFqxDneSAvMYgcNjEBwRQVC:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.dp_Main_List()
  elif OXGLKfWrFqxDneSAvMYgcNjEBwRQVT=='SET_BOOKMARK':
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.dp_Set_Bookmark(OXGLKfWrFqxDneSAvMYgcNjEBwRQVu)
  elif OXGLKfWrFqxDneSAvMYgcNjEBwRQVT=='GENRE_GROUP':
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.dp_Genre_Grouplist(OXGLKfWrFqxDneSAvMYgcNjEBwRQVu)
  elif OXGLKfWrFqxDneSAvMYgcNjEBwRQVT=='BOOKMARK_GROUP':
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.dp_Bookmark_Grouplist(OXGLKfWrFqxDneSAvMYgcNjEBwRQVu)
  elif OXGLKfWrFqxDneSAvMYgcNjEBwRQVT=='BOOKMARK_REMOVE':
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.dp_Bookmark_Remove(OXGLKfWrFqxDneSAvMYgcNjEBwRQVu)
  elif OXGLKfWrFqxDneSAvMYgcNjEBwRQVT=='GENRE_RENAME':
   OXGLKfWrFqxDneSAvMYgcNjEBwRQha.dp_Genre_Rename(OXGLKfWrFqxDneSAvMYgcNjEBwRQVu)
  else:
   OXGLKfWrFqxDneSAvMYgcNjEBwRQVC
# Created by pyminifier (https://github.com/liftoff/pyminifier)
