__author__="NightRain"
WyCFArYsfhpJTVxiePBoRvlzgaqwUk=object
WyCFArYsfhpJTVxiePBoRvlzgaqwUH=None
WyCFArYsfhpJTVxiePBoRvlzgaqwUN=False
WyCFArYsfhpJTVxiePBoRvlzgaqwUn=print
WyCFArYsfhpJTVxiePBoRvlzgaqwUc=str
WyCFArYsfhpJTVxiePBoRvlzgaqwUD=True
WyCFArYsfhpJTVxiePBoRvlzgaqwUI=Exception
WyCFArYsfhpJTVxiePBoRvlzgaqwUt=range
WyCFArYsfhpJTVxiePBoRvlzgaqwUK=int
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
WyCFArYsfhpJTVxiePBoRvlzgaqwmu ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
WyCFArYsfhpJTVxiePBoRvlzgaqwmQ={'stream50':1080,'stream40':720,'stream30':540}
class WyCFArYsfhpJTVxiePBoRvlzgaqwmd(WyCFArYsfhpJTVxiePBoRvlzgaqwUk):
 def __init__(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SESSIONID=''
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SESSION =''
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_ACCOUNTID=''
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_POLICYKEY=''
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SUBEND =''
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_PMCODE ='987'
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_PMSIZE =3
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.GAMELIST_LIMIT =10
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN ='https://www.spotvnow.co.kr'
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.BC_DOMAIN ='https://players.brightcove.net'
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.DEFAULT_HEADER ={'user-agent':WyCFArYsfhpJTVxiePBoRvlzgaqwmu}
 def callRequestCookies(WyCFArYsfhpJTVxiePBoRvlzgaqwmU,jobtype,WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,redirects=WyCFArYsfhpJTVxiePBoRvlzgaqwUN):
  WyCFArYsfhpJTVxiePBoRvlzgaqwmS=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.DEFAULT_HEADER
  if headers:WyCFArYsfhpJTVxiePBoRvlzgaqwmS.update(headers)
  if jobtype=='Get':
   WyCFArYsfhpJTVxiePBoRvlzgaqwmk=requests.get(WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,params=params,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwmS,cookies=cookies,allow_redirects=redirects)
  else:
   WyCFArYsfhpJTVxiePBoRvlzgaqwmk=requests.post(WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,data=payload,params=params,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwmS,cookies=cookies,allow_redirects=redirects)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwmk
 def makeDefaultCookies(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwmH={'SESSION':WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SESSION}
  return WyCFArYsfhpJTVxiePBoRvlzgaqwmH
 def GetCredential(WyCFArYsfhpJTVxiePBoRvlzgaqwmU,user_id,user_pw):
  WyCFArYsfhpJTVxiePBoRvlzgaqwmN=WyCFArYsfhpJTVxiePBoRvlzgaqwUN
  WyCFArYsfhpJTVxiePBoRvlzgaqwmn=WyCFArYsfhpJTVxiePBoRvlzgaqwmj=WyCFArYsfhpJTVxiePBoRvlzgaqwmG=WyCFArYsfhpJTVxiePBoRvlzgaqwmO=WyCFArYsfhpJTVxiePBoRvlzgaqwmM=''
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwmc=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   WyCFArYsfhpJTVxiePBoRvlzgaqwmD=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   WyCFArYsfhpJTVxiePBoRvlzgaqwmI=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/login'
   WyCFArYsfhpJTVxiePBoRvlzgaqwmt={'username':WyCFArYsfhpJTVxiePBoRvlzgaqwmc,'password':WyCFArYsfhpJTVxiePBoRvlzgaqwmD}
   WyCFArYsfhpJTVxiePBoRvlzgaqwmt=json.dumps(WyCFArYsfhpJTVxiePBoRvlzgaqwmt)
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Post',WyCFArYsfhpJTVxiePBoRvlzgaqwmI,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwmt,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.status_code)
   for WyCFArYsfhpJTVxiePBoRvlzgaqwmL in WyCFArYsfhpJTVxiePBoRvlzgaqwmK.cookies:
    if WyCFArYsfhpJTVxiePBoRvlzgaqwmL.name=='SESSION':
     WyCFArYsfhpJTVxiePBoRvlzgaqwmj=WyCFArYsfhpJTVxiePBoRvlzgaqwmL.value
     break
   if WyCFArYsfhpJTVxiePBoRvlzgaqwmj=='':return WyCFArYsfhpJTVxiePBoRvlzgaqwmN
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   if not('userId' in WyCFArYsfhpJTVxiePBoRvlzgaqwmE):return WyCFArYsfhpJTVxiePBoRvlzgaqwmN
   WyCFArYsfhpJTVxiePBoRvlzgaqwmn=WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwmE['userId'])
   WyCFArYsfhpJTVxiePBoRvlzgaqwmM =WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwmE['subEndTime'])
   WyCFArYsfhpJTVxiePBoRvlzgaqwmG,WyCFArYsfhpJTVxiePBoRvlzgaqwmO=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.GetPolicyKey()
   if WyCFArYsfhpJTVxiePBoRvlzgaqwmO=='':return WyCFArYsfhpJTVxiePBoRvlzgaqwmN
   WyCFArYsfhpJTVxiePBoRvlzgaqwmN=WyCFArYsfhpJTVxiePBoRvlzgaqwUD
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwmn=WyCFArYsfhpJTVxiePBoRvlzgaqwmj='' 
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  WyCFArYsfhpJTVxiePBoRvlzgaqwmb={'spotv_sessionid':WyCFArYsfhpJTVxiePBoRvlzgaqwmn,'spotv_session':WyCFArYsfhpJTVxiePBoRvlzgaqwmj,'spotv_accountId':WyCFArYsfhpJTVxiePBoRvlzgaqwmG,'spotv_policyKey':WyCFArYsfhpJTVxiePBoRvlzgaqwmO,'spotv_subend':WyCFArYsfhpJTVxiePBoRvlzgaqwmM}
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SaveCredential(WyCFArYsfhpJTVxiePBoRvlzgaqwmb)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwmN
 def SaveCredential(WyCFArYsfhpJTVxiePBoRvlzgaqwmU,WyCFArYsfhpJTVxiePBoRvlzgaqwmb):
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SESSIONID=WyCFArYsfhpJTVxiePBoRvlzgaqwmb.get('spotv_sessionid')
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SESSION =WyCFArYsfhpJTVxiePBoRvlzgaqwmb.get('spotv_session')
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_ACCOUNTID=WyCFArYsfhpJTVxiePBoRvlzgaqwmb.get('spotv_accountId')
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_POLICYKEY=WyCFArYsfhpJTVxiePBoRvlzgaqwmb.get('spotv_policyKey')
  WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SUBEND =WyCFArYsfhpJTVxiePBoRvlzgaqwmb.get('spotv_subend')
 def LoadCredential(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwmb={'spotv_sessionid':WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SESSIONID,'spotv_session':WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SESSION,'spotv_accountId':WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_ACCOUNTID,'spotv_policyKey':WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_POLICYKEY,'spotv_subend':WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SUBEND}
  return WyCFArYsfhpJTVxiePBoRvlzgaqwmb
 def Get_Now_Datetime(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwdm=[]
  WyCFArYsfhpJTVxiePBoRvlzgaqwdu ={}
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/channel'
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   WyCFArYsfhpJTVxiePBoRvlzgaqwdu=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.GetEPGList()
   for i in WyCFArYsfhpJTVxiePBoRvlzgaqwUt(2):
    for WyCFArYsfhpJTVxiePBoRvlzgaqwdU in WyCFArYsfhpJTVxiePBoRvlzgaqwmE:
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS={}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS['mediatype']='video'
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS['title'] =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['programName']
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS['studio'] =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['name']
     WyCFArYsfhpJTVxiePBoRvlzgaqwdk={'id':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['id'],'name':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['name'],'logo':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['logo'],'videoId':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['videoId'].replace('ref:',''),'free':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['free'],'programName':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['programName'],'channelepg':WyCFArYsfhpJTVxiePBoRvlzgaqwdu.get(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['id']),'info':WyCFArYsfhpJTVxiePBoRvlzgaqwdS}
     if i==0:
      if WyCFArYsfhpJTVxiePBoRvlzgaqwdU['free']==WyCFArYsfhpJTVxiePBoRvlzgaqwUN:WyCFArYsfhpJTVxiePBoRvlzgaqwdm.append(WyCFArYsfhpJTVxiePBoRvlzgaqwdk)
     else:
      if WyCFArYsfhpJTVxiePBoRvlzgaqwdU['free']==WyCFArYsfhpJTVxiePBoRvlzgaqwUD:WyCFArYsfhpJTVxiePBoRvlzgaqwdm.append(WyCFArYsfhpJTVxiePBoRvlzgaqwdk)
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwdm
 def GetEPGList(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwdH={}
  WyCFArYsfhpJTVxiePBoRvlzgaqwdN=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.Get_Now_Datetime()
  WyCFArYsfhpJTVxiePBoRvlzgaqwdn=WyCFArYsfhpJTVxiePBoRvlzgaqwdN.strftime('%Y%m%d%H%M')
  WyCFArYsfhpJTVxiePBoRvlzgaqwdc='%s-%s-%s'%(WyCFArYsfhpJTVxiePBoRvlzgaqwdn[0:4],WyCFArYsfhpJTVxiePBoRvlzgaqwdn[4:6],WyCFArYsfhpJTVxiePBoRvlzgaqwdn[6:8])
  WyCFArYsfhpJTVxiePBoRvlzgaqwdD=(WyCFArYsfhpJTVxiePBoRvlzgaqwdN+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/program/'+WyCFArYsfhpJTVxiePBoRvlzgaqwdc
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   WyCFArYsfhpJTVxiePBoRvlzgaqwdI=-1 
   WyCFArYsfhpJTVxiePBoRvlzgaqwdt =''
   for WyCFArYsfhpJTVxiePBoRvlzgaqwdU in WyCFArYsfhpJTVxiePBoRvlzgaqwmE:
    WyCFArYsfhpJTVxiePBoRvlzgaqwdK=WyCFArYsfhpJTVxiePBoRvlzgaqwdU['channelId']
    WyCFArYsfhpJTVxiePBoRvlzgaqwdL =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['startTime'].replace('-','').replace(' ','').replace(':','')
    WyCFArYsfhpJTVxiePBoRvlzgaqwdj =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['endTime'].replace('-','').replace(' ','').replace(':','')
    if WyCFArYsfhpJTVxiePBoRvlzgaqwUK(WyCFArYsfhpJTVxiePBoRvlzgaqwdn)>WyCFArYsfhpJTVxiePBoRvlzgaqwUK(WyCFArYsfhpJTVxiePBoRvlzgaqwdj) :continue
    if WyCFArYsfhpJTVxiePBoRvlzgaqwUK(WyCFArYsfhpJTVxiePBoRvlzgaqwdD)<WyCFArYsfhpJTVxiePBoRvlzgaqwUK(WyCFArYsfhpJTVxiePBoRvlzgaqwdL):continue
    if WyCFArYsfhpJTVxiePBoRvlzgaqwdI!=WyCFArYsfhpJTVxiePBoRvlzgaqwdK:
     if WyCFArYsfhpJTVxiePBoRvlzgaqwdt!='':WyCFArYsfhpJTVxiePBoRvlzgaqwdH[WyCFArYsfhpJTVxiePBoRvlzgaqwdI]=WyCFArYsfhpJTVxiePBoRvlzgaqwdt
     WyCFArYsfhpJTVxiePBoRvlzgaqwdI=WyCFArYsfhpJTVxiePBoRvlzgaqwdK
     WyCFArYsfhpJTVxiePBoRvlzgaqwdt =''
    if WyCFArYsfhpJTVxiePBoRvlzgaqwdt:WyCFArYsfhpJTVxiePBoRvlzgaqwdt+='\n'
    WyCFArYsfhpJTVxiePBoRvlzgaqwdt+=WyCFArYsfhpJTVxiePBoRvlzgaqwdU['title']+'\n'
    WyCFArYsfhpJTVxiePBoRvlzgaqwdt+=' [%s ~ %s]'%(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['startTime'][-5:],WyCFArYsfhpJTVxiePBoRvlzgaqwdU['endTime'][-5:])+'\n'
   if WyCFArYsfhpJTVxiePBoRvlzgaqwdt:WyCFArYsfhpJTVxiePBoRvlzgaqwdH[WyCFArYsfhpJTVxiePBoRvlzgaqwdI]=WyCFArYsfhpJTVxiePBoRvlzgaqwdt
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwdH
 def GetEventLiveList(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwdm=[]
  WyCFArYsfhpJTVxiePBoRvlzgaqwdE =0
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdM=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.Get_Now_Datetime()
   WyCFArYsfhpJTVxiePBoRvlzgaqwdG=WyCFArYsfhpJTVxiePBoRvlzgaqwdM.strftime('%Y-%m-%d')
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
   return WyCFArYsfhpJTVxiePBoRvlzgaqwdm,WyCFArYsfhpJTVxiePBoRvlzgaqwdE
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/player/lives/'+WyCFArYsfhpJTVxiePBoRvlzgaqwdG 
   WyCFArYsfhpJTVxiePBoRvlzgaqwmH=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.makeDefaultCookies()
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwmH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwdE=WyCFArYsfhpJTVxiePBoRvlzgaqwmK.status_code 
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   for WyCFArYsfhpJTVxiePBoRvlzgaqwdO in WyCFArYsfhpJTVxiePBoRvlzgaqwmE:
    for WyCFArYsfhpJTVxiePBoRvlzgaqwdU in WyCFArYsfhpJTVxiePBoRvlzgaqwdO['liveNowList']:
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS={}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS['mediatype']='video'
     if WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['title']==WyCFArYsfhpJTVxiePBoRvlzgaqwUH or WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['title']=='':
      WyCFArYsfhpJTVxiePBoRvlzgaqwdb='%s ( %s : %s )'%(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['leagueName'],WyCFArYsfhpJTVxiePBoRvlzgaqwdU['homeNameShort'],WyCFArYsfhpJTVxiePBoRvlzgaqwdU['awayNameShort'])
     else:
      WyCFArYsfhpJTVxiePBoRvlzgaqwdb=WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['title']
     WyCFArYsfhpJTVxiePBoRvlzgaqwdk={'liveId':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['liveId'],'title':WyCFArYsfhpJTVxiePBoRvlzgaqwdb,'logo':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['leagueLogo'],'free':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['isFree'],'startTime':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['startTime'],'info':WyCFArYsfhpJTVxiePBoRvlzgaqwdS}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdm.append(WyCFArYsfhpJTVxiePBoRvlzgaqwdk)
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwdm,WyCFArYsfhpJTVxiePBoRvlzgaqwdE
 def GetEventLiveList_sub(WyCFArYsfhpJTVxiePBoRvlzgaqwmU,tDate):
  WyCFArYsfhpJTVxiePBoRvlzgaqwdm=[]
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/player/lives/'+tDate
   WyCFArYsfhpJTVxiePBoRvlzgaqwmH=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.makeDefaultCookies()
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwmH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   for WyCFArYsfhpJTVxiePBoRvlzgaqwdO in WyCFArYsfhpJTVxiePBoRvlzgaqwmE:
    for WyCFArYsfhpJTVxiePBoRvlzgaqwdU in WyCFArYsfhpJTVxiePBoRvlzgaqwdO['liveNowList']:
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS={}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS['mediatype']='video'
     if WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['title']==WyCFArYsfhpJTVxiePBoRvlzgaqwUH or WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['title']=='':
      WyCFArYsfhpJTVxiePBoRvlzgaqwdb='%s ( %s : %s )'%(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['leagueName'],WyCFArYsfhpJTVxiePBoRvlzgaqwdU['homeNameShort'],WyCFArYsfhpJTVxiePBoRvlzgaqwdU['awayNameShort'])
     else:
      WyCFArYsfhpJTVxiePBoRvlzgaqwdb=WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['title']
     WyCFArYsfhpJTVxiePBoRvlzgaqwdk={'liveId':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['liveId'],'title':WyCFArYsfhpJTVxiePBoRvlzgaqwdb,'logo':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['leagueLogo'],'free':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['isFree'],'startTime':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['startTime'],'info':WyCFArYsfhpJTVxiePBoRvlzgaqwdS}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdm.append(WyCFArYsfhpJTVxiePBoRvlzgaqwdk)
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwdm
 def GetEventLive_videoId(WyCFArYsfhpJTVxiePBoRvlzgaqwmU,liveId):
  WyCFArYsfhpJTVxiePBoRvlzgaqwdX=''
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/live/'+liveId
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   WyCFArYsfhpJTVxiePBoRvlzgaqwum=WyCFArYsfhpJTVxiePBoRvlzgaqwmE['videoId']
   WyCFArYsfhpJTVxiePBoRvlzgaqwdX=WyCFArYsfhpJTVxiePBoRvlzgaqwum.replace('ref:','')
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwdX
 def CheckMainEnd(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwud=base64.standard_b64encode((WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_PMCODE+WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SESSIONID).encode()).decode('utf-8')
  if WyCFArYsfhpJTVxiePBoRvlzgaqwud=='OTg3MTgzMzM0Ng==' or WyCFArYsfhpJTVxiePBoRvlzgaqwud=='OTg3MTgzMzExNw==':return WyCFArYsfhpJTVxiePBoRvlzgaqwUD
  return WyCFArYsfhpJTVxiePBoRvlzgaqwUN
 def CheckSubEnd(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwuQ=WyCFArYsfhpJTVxiePBoRvlzgaqwUN
  try:
   if WyCFArYsfhpJTVxiePBoRvlzgaqwmU.CheckMainEnd():return WyCFArYsfhpJTVxiePBoRvlzgaqwUD 
   if WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SUBEND=='0':return WyCFArYsfhpJTVxiePBoRvlzgaqwuQ
   WyCFArYsfhpJTVxiePBoRvlzgaqwuU =WyCFArYsfhpJTVxiePBoRvlzgaqwUK(WyCFArYsfhpJTVxiePBoRvlzgaqwmU.Get_Now_Datetime().strftime('%Y%m%d'))
   WyCFArYsfhpJTVxiePBoRvlzgaqwuS =WyCFArYsfhpJTVxiePBoRvlzgaqwUK(WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_SUBEND)/1000
   WyCFArYsfhpJTVxiePBoRvlzgaqwuk =WyCFArYsfhpJTVxiePBoRvlzgaqwUK(datetime.datetime.fromtimestamp(WyCFArYsfhpJTVxiePBoRvlzgaqwuS,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if WyCFArYsfhpJTVxiePBoRvlzgaqwuU<=WyCFArYsfhpJTVxiePBoRvlzgaqwuk:WyCFArYsfhpJTVxiePBoRvlzgaqwuQ=WyCFArYsfhpJTVxiePBoRvlzgaqwUD
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
   return WyCFArYsfhpJTVxiePBoRvlzgaqwuQ
  return WyCFArYsfhpJTVxiePBoRvlzgaqwuQ
 def GetMainJspath(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwuH=''
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwuN=WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text
   WyCFArYsfhpJTVxiePBoRvlzgaqwun =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',WyCFArYsfhpJTVxiePBoRvlzgaqwuN)[0]
   WyCFArYsfhpJTVxiePBoRvlzgaqwuH=WyCFArYsfhpJTVxiePBoRvlzgaqwun
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwuH
 def GetBcPlayerUrl(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwuc=''
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.GetMainJspath()
   if WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=='':return WyCFArYsfhpJTVxiePBoRvlzgaqwuc
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwuN=WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text
   WyCFArYsfhpJTVxiePBoRvlzgaqwuD =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',WyCFArYsfhpJTVxiePBoRvlzgaqwuN)[0]
   WyCFArYsfhpJTVxiePBoRvlzgaqwuD =WyCFArYsfhpJTVxiePBoRvlzgaqwuD.replace('bc','"bc"')
   WyCFArYsfhpJTVxiePBoRvlzgaqwuD =WyCFArYsfhpJTVxiePBoRvlzgaqwuD.replace('player','"player"')
   WyCFArYsfhpJTVxiePBoRvlzgaqwuD ='{'+WyCFArYsfhpJTVxiePBoRvlzgaqwuD+'}'
   WyCFArYsfhpJTVxiePBoRvlzgaqwuD =json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwuD)
   bc =WyCFArYsfhpJTVxiePBoRvlzgaqwuD['bc']
   WyCFArYsfhpJTVxiePBoRvlzgaqwuI =WyCFArYsfhpJTVxiePBoRvlzgaqwuD['player']
   WyCFArYsfhpJTVxiePBoRvlzgaqwuc="%s/%s/%s_default/index.min.js"%(WyCFArYsfhpJTVxiePBoRvlzgaqwmU.BC_DOMAIN,bc,WyCFArYsfhpJTVxiePBoRvlzgaqwuI)
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwuc
 def GetPolicyKey(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwut=policykey=''
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.GetBcPlayerUrl()
   if WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=='':return WyCFArYsfhpJTVxiePBoRvlzgaqwut,WyCFArYsfhpJTVxiePBoRvlzgaqwuL
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwuN=WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text
   WyCFArYsfhpJTVxiePBoRvlzgaqwun =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',WyCFArYsfhpJTVxiePBoRvlzgaqwuN)[0]
   WyCFArYsfhpJTVxiePBoRvlzgaqwun =WyCFArYsfhpJTVxiePBoRvlzgaqwun.replace('accountId','"accountId"')
   WyCFArYsfhpJTVxiePBoRvlzgaqwun =WyCFArYsfhpJTVxiePBoRvlzgaqwun.replace('policyKey','"policyKey"')
   WyCFArYsfhpJTVxiePBoRvlzgaqwun ='{'+WyCFArYsfhpJTVxiePBoRvlzgaqwun+'}'
   WyCFArYsfhpJTVxiePBoRvlzgaqwuK=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwun)
   WyCFArYsfhpJTVxiePBoRvlzgaqwut =WyCFArYsfhpJTVxiePBoRvlzgaqwuK['accountId']
   WyCFArYsfhpJTVxiePBoRvlzgaqwuL =WyCFArYsfhpJTVxiePBoRvlzgaqwuK['policyKey']
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwut,WyCFArYsfhpJTVxiePBoRvlzgaqwuL
 def GetBroadURL(WyCFArYsfhpJTVxiePBoRvlzgaqwmU,WyCFArYsfhpJTVxiePBoRvlzgaqwdX,mediatype,WyCFArYsfhpJTVxiePBoRvlzgaqwQS):
  WyCFArYsfhpJTVxiePBoRvlzgaqwuj=''
  try:
   if mediatype=='live':
    WyCFArYsfhpJTVxiePBoRvlzgaqwdX='ref%3A'+WyCFArYsfhpJTVxiePBoRvlzgaqwdX
   else:
    WyCFArYsfhpJTVxiePBoRvlzgaqwdX=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.GetReplay_UrlId(WyCFArYsfhpJTVxiePBoRvlzgaqwdX,WyCFArYsfhpJTVxiePBoRvlzgaqwQS)
    if WyCFArYsfhpJTVxiePBoRvlzgaqwdX=='':return WyCFArYsfhpJTVxiePBoRvlzgaqwuj
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.PLAYER_DOMAIN+'/playback/v1/accounts/'+WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_ACCOUNTID+'/videos/'+WyCFArYsfhpJTVxiePBoRvlzgaqwdX
   WyCFArYsfhpJTVxiePBoRvlzgaqwuE={'accept':'application/json;pk='+WyCFArYsfhpJTVxiePBoRvlzgaqwmU.SPOTV_POLICYKEY}
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwuE,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwuM=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   WyCFArYsfhpJTVxiePBoRvlzgaqwuj=WyCFArYsfhpJTVxiePBoRvlzgaqwuM['sources'][0]['src']
   if mediatype=='live':
    WyCFArYsfhpJTVxiePBoRvlzgaqwuj=WyCFArYsfhpJTVxiePBoRvlzgaqwuj.replace('playlist.m3u8','playlist_dvr.m3u8')
   WyCFArYsfhpJTVxiePBoRvlzgaqwuj=WyCFArYsfhpJTVxiePBoRvlzgaqwuj.replace('http://','https://')
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwuj
 def GetTitleGroupList(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwdm=[]
  WyCFArYsfhpJTVxiePBoRvlzgaqwuG=WyCFArYsfhpJTVxiePBoRvlzgaqwUN
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/home/web'
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   for WyCFArYsfhpJTVxiePBoRvlzgaqwdU in WyCFArYsfhpJTVxiePBoRvlzgaqwmE:
    WyCFArYsfhpJTVxiePBoRvlzgaqwdS={}
    WyCFArYsfhpJTVxiePBoRvlzgaqwdS['mediatype']='episode'
    if WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['type'])=='3':
     WyCFArYsfhpJTVxiePBoRvlzgaqwuO=''
     for WyCFArYsfhpJTVxiePBoRvlzgaqwub in WyCFArYsfhpJTVxiePBoRvlzgaqwdU['data']['list']:
      WyCFArYsfhpJTVxiePBoRvlzgaqwuX='[%s] %s vs %s\n<%s>\n\n'%(WyCFArYsfhpJTVxiePBoRvlzgaqwub['gameDesc']['roundName'],WyCFArYsfhpJTVxiePBoRvlzgaqwub['gameDesc']['homeNameShort'],WyCFArYsfhpJTVxiePBoRvlzgaqwub['gameDesc']['awayNameShort'],WyCFArYsfhpJTVxiePBoRvlzgaqwub['gameDesc']['beginDate'])
      WyCFArYsfhpJTVxiePBoRvlzgaqwuO+=WyCFArYsfhpJTVxiePBoRvlzgaqwuX
     WyCFArYsfhpJTVxiePBoRvlzgaqwdk={'title':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['title'],'logo':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['logo'],'reagueId':WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['destId']),'subGame':WyCFArYsfhpJTVxiePBoRvlzgaqwuO,'info':WyCFArYsfhpJTVxiePBoRvlzgaqwdS}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdm.append(WyCFArYsfhpJTVxiePBoRvlzgaqwdk)
     if WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['destId'])=='13':WyCFArYsfhpJTVxiePBoRvlzgaqwuG=WyCFArYsfhpJTVxiePBoRvlzgaqwUD
   if WyCFArYsfhpJTVxiePBoRvlzgaqwuG==WyCFArYsfhpJTVxiePBoRvlzgaqwUN:
    WyCFArYsfhpJTVxiePBoRvlzgaqwdS={'mediatype':'episode'}
    WyCFArYsfhpJTVxiePBoRvlzgaqwdk={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':'','info':WyCFArYsfhpJTVxiePBoRvlzgaqwdS}
    WyCFArYsfhpJTVxiePBoRvlzgaqwdm.append(WyCFArYsfhpJTVxiePBoRvlzgaqwdk)
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwdm
 def GetPopularGroupList(WyCFArYsfhpJTVxiePBoRvlzgaqwmU):
  WyCFArYsfhpJTVxiePBoRvlzgaqwdm=[]
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/home/web'
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   for WyCFArYsfhpJTVxiePBoRvlzgaqwdU in WyCFArYsfhpJTVxiePBoRvlzgaqwmE:
    WyCFArYsfhpJTVxiePBoRvlzgaqwdS={}
    WyCFArYsfhpJTVxiePBoRvlzgaqwdS['mediatype']='episode'
    if WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['type'])=='1' and WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['destId'])=='4':
     for WyCFArYsfhpJTVxiePBoRvlzgaqwub in WyCFArYsfhpJTVxiePBoRvlzgaqwdU['data']['list']:
      WyCFArYsfhpJTVxiePBoRvlzgaqwdS={}
      WyCFArYsfhpJTVxiePBoRvlzgaqwdS['mediatype']='video'
      WyCFArYsfhpJTVxiePBoRvlzgaqwQm =WyCFArYsfhpJTVxiePBoRvlzgaqwub['title']
      WyCFArYsfhpJTVxiePBoRvlzgaqwQd =WyCFArYsfhpJTVxiePBoRvlzgaqwub['id']
      WyCFArYsfhpJTVxiePBoRvlzgaqwQu =WyCFArYsfhpJTVxiePBoRvlzgaqwub['vtype']
      WyCFArYsfhpJTVxiePBoRvlzgaqwQU =WyCFArYsfhpJTVxiePBoRvlzgaqwub['imgUrl']
      WyCFArYsfhpJTVxiePBoRvlzgaqwQS =WyCFArYsfhpJTVxiePBoRvlzgaqwub['vtypeId']
      WyCFArYsfhpJTVxiePBoRvlzgaqwdS['duration'] =WyCFArYsfhpJTVxiePBoRvlzgaqwUK(WyCFArYsfhpJTVxiePBoRvlzgaqwub['duration']/1000)
      WyCFArYsfhpJTVxiePBoRvlzgaqwdk={'vodTitle':WyCFArYsfhpJTVxiePBoRvlzgaqwQm,'vodId':WyCFArYsfhpJTVxiePBoRvlzgaqwQd,'vodType':WyCFArYsfhpJTVxiePBoRvlzgaqwQu,'thumbnail':WyCFArYsfhpJTVxiePBoRvlzgaqwQU,'info':WyCFArYsfhpJTVxiePBoRvlzgaqwdS,'vtypeId':WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwQS)}
      WyCFArYsfhpJTVxiePBoRvlzgaqwdm.append(WyCFArYsfhpJTVxiePBoRvlzgaqwdk)
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwdm
 def GetSeasonList(WyCFArYsfhpJTVxiePBoRvlzgaqwmU,leagueId):
  WyCFArYsfhpJTVxiePBoRvlzgaqwdm=[]
  WyCFArYsfhpJTVxiePBoRvlzgaqwQk=WyCFArYsfhpJTVxiePBoRvlzgaqwQH=''
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/game/league/'+leagueId
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   WyCFArYsfhpJTVxiePBoRvlzgaqwQk=WyCFArYsfhpJTVxiePBoRvlzgaqwmE['name']
   WyCFArYsfhpJTVxiePBoRvlzgaqwQH=WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwmE['gameTypeId'])
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
   return WyCFArYsfhpJTVxiePBoRvlzgaqwdm
  if WyCFArYsfhpJTVxiePBoRvlzgaqwQH=='2':
   try:
    WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/year/'+leagueId
    WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
    WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
    for WyCFArYsfhpJTVxiePBoRvlzgaqwdU in WyCFArYsfhpJTVxiePBoRvlzgaqwmE:
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS={}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS['mediatype']='episode'
     WyCFArYsfhpJTVxiePBoRvlzgaqwdk={'reagueName':WyCFArYsfhpJTVxiePBoRvlzgaqwQk,'gameTypeId':WyCFArYsfhpJTVxiePBoRvlzgaqwQH,'seasonName':WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwdU),'seasonId':WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwdU),'info':WyCFArYsfhpJTVxiePBoRvlzgaqwdS}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdm.append(WyCFArYsfhpJTVxiePBoRvlzgaqwdk)
   except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
    WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
    return[]
  else:
   try:
    WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/season/'+leagueId
    WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
    WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
    for WyCFArYsfhpJTVxiePBoRvlzgaqwdU in WyCFArYsfhpJTVxiePBoRvlzgaqwmE:
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS={}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS['mediatype']='episode'
     WyCFArYsfhpJTVxiePBoRvlzgaqwdk={'reagueName':WyCFArYsfhpJTVxiePBoRvlzgaqwQk,'gameTypeId':WyCFArYsfhpJTVxiePBoRvlzgaqwQH,'seasonName':WyCFArYsfhpJTVxiePBoRvlzgaqwdU['name'],'seasonId':WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['id']),'info':WyCFArYsfhpJTVxiePBoRvlzgaqwdS}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdm.append(WyCFArYsfhpJTVxiePBoRvlzgaqwdk)
   except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
    WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
    return[]
  return WyCFArYsfhpJTVxiePBoRvlzgaqwdm
 def GetGameList(WyCFArYsfhpJTVxiePBoRvlzgaqwmU,WyCFArYsfhpJTVxiePBoRvlzgaqwQH,leagueId,seasonId,page_int):
  WyCFArYsfhpJTVxiePBoRvlzgaqwdm=[]
  WyCFArYsfhpJTVxiePBoRvlzgaqwQN=WyCFArYsfhpJTVxiePBoRvlzgaqwUN
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/vod/league/detail'
   WyCFArYsfhpJTVxiePBoRvlzgaqwQn={'gameType':WyCFArYsfhpJTVxiePBoRvlzgaqwQH,'leagueId':leagueId,'seasonId':seasonId if WyCFArYsfhpJTVxiePBoRvlzgaqwQH!='2' else '','teamId':'','roundId':'','year':'' if WyCFArYsfhpJTVxiePBoRvlzgaqwQH!='2' else seasonId,'pageNo':WyCFArYsfhpJTVxiePBoRvlzgaqwUc(page_int)}
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwQn,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   WyCFArYsfhpJTVxiePBoRvlzgaqwdO=WyCFArYsfhpJTVxiePBoRvlzgaqwmE['list']
   for WyCFArYsfhpJTVxiePBoRvlzgaqwQc in WyCFArYsfhpJTVxiePBoRvlzgaqwdO:
    for WyCFArYsfhpJTVxiePBoRvlzgaqwdU in WyCFArYsfhpJTVxiePBoRvlzgaqwQc['list']:
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS={}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS['mediatype']='video'
     if WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['title']==WyCFArYsfhpJTVxiePBoRvlzgaqwUH or WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['title']=='':
      WyCFArYsfhpJTVxiePBoRvlzgaqwdb ='%s vs %s'%(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['homeNameShort'],WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['awayNameShort'])
     else:
      WyCFArYsfhpJTVxiePBoRvlzgaqwdb =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['title']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQD =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['beginDate']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQI =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['id']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQt =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['leagueNameFull']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQK =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['seasonName']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQL =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['roundName']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQj =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['homeName']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQE =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['awayName']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQM =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['homeScore']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQG =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['gameDesc']['awayScore']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQO ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(WyCFArYsfhpJTVxiePBoRvlzgaqwQt,WyCFArYsfhpJTVxiePBoRvlzgaqwQK,WyCFArYsfhpJTVxiePBoRvlzgaqwQL,WyCFArYsfhpJTVxiePBoRvlzgaqwQD,WyCFArYsfhpJTVxiePBoRvlzgaqwQj,WyCFArYsfhpJTVxiePBoRvlzgaqwQM,WyCFArYsfhpJTVxiePBoRvlzgaqwQE,WyCFArYsfhpJTVxiePBoRvlzgaqwQG)
     WyCFArYsfhpJTVxiePBoRvlzgaqwdS['plot']=WyCFArYsfhpJTVxiePBoRvlzgaqwQO
     WyCFArYsfhpJTVxiePBoRvlzgaqwQb =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['replayVod']['count']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQX=WyCFArYsfhpJTVxiePBoRvlzgaqwdU['highlightVod']['count']
     WyCFArYsfhpJTVxiePBoRvlzgaqwUm =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['vods']['count']
     WyCFArYsfhpJTVxiePBoRvlzgaqwQU='' 
     WyCFArYsfhpJTVxiePBoRvlzgaqwUd=WyCFArYsfhpJTVxiePBoRvlzgaqwQb+WyCFArYsfhpJTVxiePBoRvlzgaqwQX+WyCFArYsfhpJTVxiePBoRvlzgaqwUm
     if WyCFArYsfhpJTVxiePBoRvlzgaqwUd==0:
      if WyCFArYsfhpJTVxiePBoRvlzgaqwQH=='2':
       WyCFArYsfhpJTVxiePBoRvlzgaqwdb='----- %s -----'%(WyCFArYsfhpJTVxiePBoRvlzgaqwQK)
       WyCFArYsfhpJTVxiePBoRvlzgaqwQD=''
      else:
       WyCFArYsfhpJTVxiePBoRvlzgaqwdb+=' - 관련영상 없음'
       WyCFArYsfhpJTVxiePBoRvlzgaqwdS['plot']+='\n\n ** 관련영상 없음 **'
     else:
      if WyCFArYsfhpJTVxiePBoRvlzgaqwQb!=0:
       WyCFArYsfhpJTVxiePBoRvlzgaqwQU =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['replayVod']['list'][0]['imgUrl']
      elif WyCFArYsfhpJTVxiePBoRvlzgaqwQX!=0:
       WyCFArYsfhpJTVxiePBoRvlzgaqwQU =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['highlightVod']['list'][0]['imgUrl']
      else:
       WyCFArYsfhpJTVxiePBoRvlzgaqwQU =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['vods']['list'][0]['imgUrl']
     WyCFArYsfhpJTVxiePBoRvlzgaqwdk={'gameTitle':WyCFArYsfhpJTVxiePBoRvlzgaqwdb,'gameId':WyCFArYsfhpJTVxiePBoRvlzgaqwQI,'beginDate':WyCFArYsfhpJTVxiePBoRvlzgaqwQD[:11],'thumbnail':WyCFArYsfhpJTVxiePBoRvlzgaqwQU,'info':WyCFArYsfhpJTVxiePBoRvlzgaqwdS,'leaguenm':WyCFArYsfhpJTVxiePBoRvlzgaqwQt,'seasonnm':WyCFArYsfhpJTVxiePBoRvlzgaqwQK,'roundnm':WyCFArYsfhpJTVxiePBoRvlzgaqwQL,'totVodCnt':WyCFArYsfhpJTVxiePBoRvlzgaqwUd}
     WyCFArYsfhpJTVxiePBoRvlzgaqwdm.append(WyCFArYsfhpJTVxiePBoRvlzgaqwdk)
   if WyCFArYsfhpJTVxiePBoRvlzgaqwQH=='2':
    if WyCFArYsfhpJTVxiePBoRvlzgaqwmE['count']>page_int*WyCFArYsfhpJTVxiePBoRvlzgaqwmU.GAMELIST_LIMIT:WyCFArYsfhpJTVxiePBoRvlzgaqwQN=WyCFArYsfhpJTVxiePBoRvlzgaqwUD
   else:
    if WyCFArYsfhpJTVxiePBoRvlzgaqwmE['list'][0]['count']>page_int*WyCFArYsfhpJTVxiePBoRvlzgaqwmU.GAMELIST_LIMIT:WyCFArYsfhpJTVxiePBoRvlzgaqwQN=WyCFArYsfhpJTVxiePBoRvlzgaqwUD
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwdm,WyCFArYsfhpJTVxiePBoRvlzgaqwQN
 def GetGameVodList(WyCFArYsfhpJTVxiePBoRvlzgaqwmU,WyCFArYsfhpJTVxiePBoRvlzgaqwQI):
  WyCFArYsfhpJTVxiePBoRvlzgaqwdm=[]
  WyCFArYsfhpJTVxiePBoRvlzgaqwUu=''
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/vod/game'
   WyCFArYsfhpJTVxiePBoRvlzgaqwQn={'gameId':WyCFArYsfhpJTVxiePBoRvlzgaqwQI,'pageItem':'1000'}
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwQn,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   WyCFArYsfhpJTVxiePBoRvlzgaqwQc=WyCFArYsfhpJTVxiePBoRvlzgaqwmE['list']
   for WyCFArYsfhpJTVxiePBoRvlzgaqwdU in WyCFArYsfhpJTVxiePBoRvlzgaqwQc:
    WyCFArYsfhpJTVxiePBoRvlzgaqwdS={}
    WyCFArYsfhpJTVxiePBoRvlzgaqwdS['mediatype']='video'
    WyCFArYsfhpJTVxiePBoRvlzgaqwQm =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['title']
    WyCFArYsfhpJTVxiePBoRvlzgaqwQd =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['id']
    WyCFArYsfhpJTVxiePBoRvlzgaqwQu =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['vtype']
    WyCFArYsfhpJTVxiePBoRvlzgaqwQU =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['imgUrl']
    WyCFArYsfhpJTVxiePBoRvlzgaqwQS =WyCFArYsfhpJTVxiePBoRvlzgaqwdU['vtypeId']
    WyCFArYsfhpJTVxiePBoRvlzgaqwdS['duration'] =WyCFArYsfhpJTVxiePBoRvlzgaqwUK(WyCFArYsfhpJTVxiePBoRvlzgaqwdU['duration']/1000)
    WyCFArYsfhpJTVxiePBoRvlzgaqwdk={'vodTitle':WyCFArYsfhpJTVxiePBoRvlzgaqwQm,'vodId':WyCFArYsfhpJTVxiePBoRvlzgaqwQd,'vodType':WyCFArYsfhpJTVxiePBoRvlzgaqwQu,'thumbnail':WyCFArYsfhpJTVxiePBoRvlzgaqwQU,'info':WyCFArYsfhpJTVxiePBoRvlzgaqwdS,'vtypeId':WyCFArYsfhpJTVxiePBoRvlzgaqwUc(WyCFArYsfhpJTVxiePBoRvlzgaqwQS)}
    WyCFArYsfhpJTVxiePBoRvlzgaqwdm.append(WyCFArYsfhpJTVxiePBoRvlzgaqwdk)
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwdm
 def GetReplay_UrlId(WyCFArYsfhpJTVxiePBoRvlzgaqwmU,WyCFArYsfhpJTVxiePBoRvlzgaqwUu,WyCFArYsfhpJTVxiePBoRvlzgaqwQS):
  WyCFArYsfhpJTVxiePBoRvlzgaqwUQ=WyCFArYsfhpJTVxiePBoRvlzgaqwdX=''
  WyCFArYsfhpJTVxiePBoRvlzgaqwUS=''
  try:
   WyCFArYsfhpJTVxiePBoRvlzgaqwdQ=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.API_DOMAIN+'/api/v2/vod/'+WyCFArYsfhpJTVxiePBoRvlzgaqwUu
   WyCFArYsfhpJTVxiePBoRvlzgaqwmK=WyCFArYsfhpJTVxiePBoRvlzgaqwmU.callRequestCookies('Get',WyCFArYsfhpJTVxiePBoRvlzgaqwdQ,payload=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,params=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,headers=WyCFArYsfhpJTVxiePBoRvlzgaqwUH,cookies=WyCFArYsfhpJTVxiePBoRvlzgaqwUH)
   WyCFArYsfhpJTVxiePBoRvlzgaqwmE=json.loads(WyCFArYsfhpJTVxiePBoRvlzgaqwmK.text)
   WyCFArYsfhpJTVxiePBoRvlzgaqwUQ =WyCFArYsfhpJTVxiePBoRvlzgaqwmE['clipId']
   WyCFArYsfhpJTVxiePBoRvlzgaqwdX=WyCFArYsfhpJTVxiePBoRvlzgaqwmE['videoId']
   WyCFArYsfhpJTVxiePBoRvlzgaqwUS=WyCFArYsfhpJTVxiePBoRvlzgaqwUQ
   if WyCFArYsfhpJTVxiePBoRvlzgaqwmU.CheckSubEnd()or WyCFArYsfhpJTVxiePBoRvlzgaqwQS!='1':WyCFArYsfhpJTVxiePBoRvlzgaqwUS=WyCFArYsfhpJTVxiePBoRvlzgaqwdX 
  except WyCFArYsfhpJTVxiePBoRvlzgaqwUI as exception:
   WyCFArYsfhpJTVxiePBoRvlzgaqwUn(exception)
  return WyCFArYsfhpJTVxiePBoRvlzgaqwUS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
