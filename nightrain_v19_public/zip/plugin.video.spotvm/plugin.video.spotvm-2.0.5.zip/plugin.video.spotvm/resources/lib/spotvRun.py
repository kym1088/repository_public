__author__="NightRain"
khVPtquIgJLOMNHcACRbioyjQUslEw=object
khVPtquIgJLOMNHcACRbioyjQUslEv=None
khVPtquIgJLOMNHcACRbioyjQUslEn=False
khVPtquIgJLOMNHcACRbioyjQUslEd=True
khVPtquIgJLOMNHcACRbioyjQUslED=int
khVPtquIgJLOMNHcACRbioyjQUslEB=len
khVPtquIgJLOMNHcACRbioyjQUslEm=str
khVPtquIgJLOMNHcACRbioyjQUslEp=open
khVPtquIgJLOMNHcACRbioyjQUslEF=Exception
khVPtquIgJLOMNHcACRbioyjQUslES=print
khVPtquIgJLOMNHcACRbioyjQUslEK=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
khVPtquIgJLOMNHcACRbioyjQUslar=[{'title':'TV 채널','mode':'LIVE_GROUP'},{'title':'Live중계 (독점,현지)','mode':'ELIVE_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'인기영상5','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH'}]
khVPtquIgJLOMNHcACRbioyjQUslaw ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
khVPtquIgJLOMNHcACRbioyjQUslaE=xbmc.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class khVPtquIgJLOMNHcACRbioyjQUslaW(khVPtquIgJLOMNHcACRbioyjQUslEw):
 def __init__(khVPtquIgJLOMNHcACRbioyjQUslav,khVPtquIgJLOMNHcACRbioyjQUslan,khVPtquIgJLOMNHcACRbioyjQUslad,khVPtquIgJLOMNHcACRbioyjQUslaD):
  khVPtquIgJLOMNHcACRbioyjQUslav._addon_url =khVPtquIgJLOMNHcACRbioyjQUslan
  khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle=khVPtquIgJLOMNHcACRbioyjQUslad
  khVPtquIgJLOMNHcACRbioyjQUslav.main_params =khVPtquIgJLOMNHcACRbioyjQUslaD
  khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj =WyCFArYsfhpJTVxiePBoRvlzgaqwmd() 
 def addon_noti(khVPtquIgJLOMNHcACRbioyjQUslav,sting):
  try:
   khVPtquIgJLOMNHcACRbioyjQUslam=xbmcgui.Dialog()
   khVPtquIgJLOMNHcACRbioyjQUslam.notification(__addonname__,sting)
  except:
   khVPtquIgJLOMNHcACRbioyjQUslEv
 def addon_log(khVPtquIgJLOMNHcACRbioyjQUslav,string,isDebug=khVPtquIgJLOMNHcACRbioyjQUslEn):
  try:
   khVPtquIgJLOMNHcACRbioyjQUslap=string.encode('utf-8','ignore')
  except:
   khVPtquIgJLOMNHcACRbioyjQUslap='addonException: addon_log'
  if isDebug:khVPtquIgJLOMNHcACRbioyjQUslaF=xbmc.LOGDEBUG
  else:khVPtquIgJLOMNHcACRbioyjQUslaF=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,khVPtquIgJLOMNHcACRbioyjQUslap),level=khVPtquIgJLOMNHcACRbioyjQUslaF)
 def get_keyboard_input(khVPtquIgJLOMNHcACRbioyjQUslav,khVPtquIgJLOMNHcACRbioyjQUslaT):
  khVPtquIgJLOMNHcACRbioyjQUslaS=khVPtquIgJLOMNHcACRbioyjQUslEv
  kb=xbmc.Keyboard()
  kb.setHeading(khVPtquIgJLOMNHcACRbioyjQUslaT)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   khVPtquIgJLOMNHcACRbioyjQUslaS=kb.getText()
  return khVPtquIgJLOMNHcACRbioyjQUslaS
 def get_settings_login_info(khVPtquIgJLOMNHcACRbioyjQUslav):
  khVPtquIgJLOMNHcACRbioyjQUslaK =__addon__.getSetting('id')
  khVPtquIgJLOMNHcACRbioyjQUslax =__addon__.getSetting('pw')
  return(khVPtquIgJLOMNHcACRbioyjQUslaK,khVPtquIgJLOMNHcACRbioyjQUslax)
 def set_winCredential(khVPtquIgJLOMNHcACRbioyjQUslav,credential):
  khVPtquIgJLOMNHcACRbioyjQUslae=xbmcgui.Window(10000)
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_LOGINTIME',khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(khVPtquIgJLOMNHcACRbioyjQUslav):
  khVPtquIgJLOMNHcACRbioyjQUslae=xbmcgui.Window(10000)
  khVPtquIgJLOMNHcACRbioyjQUslaz={'spotv_sessionid':khVPtquIgJLOMNHcACRbioyjQUslae.getProperty('SPOTV_M_SESSIONID'),'spotv_session':khVPtquIgJLOMNHcACRbioyjQUslae.getProperty('SPOTV_M_SESSION'),'spotv_accountId':khVPtquIgJLOMNHcACRbioyjQUslae.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':khVPtquIgJLOMNHcACRbioyjQUslae.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':khVPtquIgJLOMNHcACRbioyjQUslae.getProperty('SPOTV_M_SUBEND')}
  return khVPtquIgJLOMNHcACRbioyjQUslaz
 def add_dir(khVPtquIgJLOMNHcACRbioyjQUslav,label,sublabel='',img='',infoLabels=khVPtquIgJLOMNHcACRbioyjQUslEv,isFolder=khVPtquIgJLOMNHcACRbioyjQUslEd,params=''):
  khVPtquIgJLOMNHcACRbioyjQUslaY='%s?%s'%(khVPtquIgJLOMNHcACRbioyjQUslav._addon_url,urllib.parse.urlencode(params))
  if sublabel:khVPtquIgJLOMNHcACRbioyjQUslaT='%s < %s >'%(label,sublabel)
  else: khVPtquIgJLOMNHcACRbioyjQUslaT=label
  if not img:img='DefaultFolder.png'
  khVPtquIgJLOMNHcACRbioyjQUslaf=xbmcgui.ListItem(khVPtquIgJLOMNHcACRbioyjQUslaT)
  khVPtquIgJLOMNHcACRbioyjQUslaf.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:khVPtquIgJLOMNHcACRbioyjQUslaf.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:khVPtquIgJLOMNHcACRbioyjQUslaf.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle,khVPtquIgJLOMNHcACRbioyjQUslaY,khVPtquIgJLOMNHcACRbioyjQUslaf,isFolder)
 def get_selQuality(khVPtquIgJLOMNHcACRbioyjQUslav,etype):
  try:
   khVPtquIgJLOMNHcACRbioyjQUslaG='selected_quality'
   khVPtquIgJLOMNHcACRbioyjQUslaX=[1080,720,540]
   khVPtquIgJLOMNHcACRbioyjQUslWa=khVPtquIgJLOMNHcACRbioyjQUslED(__addon__.getSetting(khVPtquIgJLOMNHcACRbioyjQUslaG))
   return khVPtquIgJLOMNHcACRbioyjQUslaX[khVPtquIgJLOMNHcACRbioyjQUslWa]
  except:
   khVPtquIgJLOMNHcACRbioyjQUslEv
  return 1080 
 def dp_Main_List(khVPtquIgJLOMNHcACRbioyjQUslav):
  for khVPtquIgJLOMNHcACRbioyjQUslWr in khVPtquIgJLOMNHcACRbioyjQUslar:
   khVPtquIgJLOMNHcACRbioyjQUslaT=khVPtquIgJLOMNHcACRbioyjQUslWr.get('title')
   khVPtquIgJLOMNHcACRbioyjQUslWw={'mode':khVPtquIgJLOMNHcACRbioyjQUslWr.get('mode')}
   if khVPtquIgJLOMNHcACRbioyjQUslWr.get('mode')=='XXX':
    khVPtquIgJLOMNHcACRbioyjQUslWE=khVPtquIgJLOMNHcACRbioyjQUslEn
   else:
    khVPtquIgJLOMNHcACRbioyjQUslWE=khVPtquIgJLOMNHcACRbioyjQUslEd
   khVPtquIgJLOMNHcACRbioyjQUslav.add_dir(khVPtquIgJLOMNHcACRbioyjQUslaT,sublabel='',img='',infoLabels=khVPtquIgJLOMNHcACRbioyjQUslEv,isFolder=khVPtquIgJLOMNHcACRbioyjQUslWE,params=khVPtquIgJLOMNHcACRbioyjQUslWw)
  if khVPtquIgJLOMNHcACRbioyjQUslEB(khVPtquIgJLOMNHcACRbioyjQUslar)>0:xbmcplugin.endOfDirectory(khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle)
 def dp_MainLeague_List(khVPtquIgJLOMNHcACRbioyjQUslav,args):
  khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.SaveCredential(khVPtquIgJLOMNHcACRbioyjQUslav.get_winCredential())
  khVPtquIgJLOMNHcACRbioyjQUslWn=khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.GetTitleGroupList()
  for khVPtquIgJLOMNHcACRbioyjQUslWd in khVPtquIgJLOMNHcACRbioyjQUslWn:
   khVPtquIgJLOMNHcACRbioyjQUslaT =khVPtquIgJLOMNHcACRbioyjQUslWd.get('title')
   khVPtquIgJLOMNHcACRbioyjQUslWD =khVPtquIgJLOMNHcACRbioyjQUslWd.get('logo')
   khVPtquIgJLOMNHcACRbioyjQUslWB =khVPtquIgJLOMNHcACRbioyjQUslWd.get('reagueId')
   khVPtquIgJLOMNHcACRbioyjQUslWm =khVPtquIgJLOMNHcACRbioyjQUslWd.get('subGame')
   khVPtquIgJLOMNHcACRbioyjQUslWp=khVPtquIgJLOMNHcACRbioyjQUslWd.get('info')
   khVPtquIgJLOMNHcACRbioyjQUslWp['plot']='%s\n\n%s'%(khVPtquIgJLOMNHcACRbioyjQUslaT,khVPtquIgJLOMNHcACRbioyjQUslWm)
   khVPtquIgJLOMNHcACRbioyjQUslWw={'mode':'LEAGUE_GROUP','reagueId':khVPtquIgJLOMNHcACRbioyjQUslWB}
   khVPtquIgJLOMNHcACRbioyjQUslav.add_dir(khVPtquIgJLOMNHcACRbioyjQUslaT,sublabel=khVPtquIgJLOMNHcACRbioyjQUslEv,img=khVPtquIgJLOMNHcACRbioyjQUslWD,infoLabels=khVPtquIgJLOMNHcACRbioyjQUslWp,isFolder=khVPtquIgJLOMNHcACRbioyjQUslEd,params=khVPtquIgJLOMNHcACRbioyjQUslWw)
  if khVPtquIgJLOMNHcACRbioyjQUslEB(khVPtquIgJLOMNHcACRbioyjQUslWn)>0:xbmcplugin.endOfDirectory(khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle,cacheToDisc=khVPtquIgJLOMNHcACRbioyjQUslEn)
 def dp_PopVod_GroupList(khVPtquIgJLOMNHcACRbioyjQUslav,args):
  khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.SaveCredential(khVPtquIgJLOMNHcACRbioyjQUslav.get_winCredential())
  khVPtquIgJLOMNHcACRbioyjQUslWn=khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.GetPopularGroupList()
  for khVPtquIgJLOMNHcACRbioyjQUslWd in khVPtquIgJLOMNHcACRbioyjQUslWn:
   khVPtquIgJLOMNHcACRbioyjQUslWF =khVPtquIgJLOMNHcACRbioyjQUslWd.get('vodTitle')
   khVPtquIgJLOMNHcACRbioyjQUslWS =khVPtquIgJLOMNHcACRbioyjQUslWd.get('vodId')
   khVPtquIgJLOMNHcACRbioyjQUslWK =khVPtquIgJLOMNHcACRbioyjQUslWd.get('vodType')
   khVPtquIgJLOMNHcACRbioyjQUslWD=khVPtquIgJLOMNHcACRbioyjQUslWd.get('thumbnail')
   khVPtquIgJLOMNHcACRbioyjQUslWx =khVPtquIgJLOMNHcACRbioyjQUslWd.get('vtypeId')
   khVPtquIgJLOMNHcACRbioyjQUslWp=khVPtquIgJLOMNHcACRbioyjQUslWd.get('info')
   khVPtquIgJLOMNHcACRbioyjQUslWp['plot']=khVPtquIgJLOMNHcACRbioyjQUslWF
   khVPtquIgJLOMNHcACRbioyjQUslWw={'mode':'POP_VOD','mediacode':khVPtquIgJLOMNHcACRbioyjQUslWS,'mediatype':'vod','vtypeId':khVPtquIgJLOMNHcACRbioyjQUslWx}
   khVPtquIgJLOMNHcACRbioyjQUslav.add_dir(khVPtquIgJLOMNHcACRbioyjQUslWF,sublabel=khVPtquIgJLOMNHcACRbioyjQUslWK,img=khVPtquIgJLOMNHcACRbioyjQUslWD,infoLabels=khVPtquIgJLOMNHcACRbioyjQUslWp,isFolder=khVPtquIgJLOMNHcACRbioyjQUslEn,params=khVPtquIgJLOMNHcACRbioyjQUslWw)
  if khVPtquIgJLOMNHcACRbioyjQUslEB(khVPtquIgJLOMNHcACRbioyjQUslWn)>0:xbmcplugin.endOfDirectory(khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle,cacheToDisc=khVPtquIgJLOMNHcACRbioyjQUslEn)
 def dp_Season_List(khVPtquIgJLOMNHcACRbioyjQUslav,args):
  khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.SaveCredential(khVPtquIgJLOMNHcACRbioyjQUslav.get_winCredential())
  khVPtquIgJLOMNHcACRbioyjQUslWB=args.get('reagueId')
  khVPtquIgJLOMNHcACRbioyjQUslWn=khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.GetSeasonList(khVPtquIgJLOMNHcACRbioyjQUslWB)
  for khVPtquIgJLOMNHcACRbioyjQUslWd in khVPtquIgJLOMNHcACRbioyjQUslWn:
   khVPtquIgJLOMNHcACRbioyjQUslWe =khVPtquIgJLOMNHcACRbioyjQUslWd.get('reagueName')
   khVPtquIgJLOMNHcACRbioyjQUslWz =khVPtquIgJLOMNHcACRbioyjQUslWd.get('gameTypeId')
   khVPtquIgJLOMNHcACRbioyjQUslWY =khVPtquIgJLOMNHcACRbioyjQUslWd.get('seasonName')
   khVPtquIgJLOMNHcACRbioyjQUslWT =khVPtquIgJLOMNHcACRbioyjQUslWd.get('seasonId')
   khVPtquIgJLOMNHcACRbioyjQUslWp=khVPtquIgJLOMNHcACRbioyjQUslWd.get('info')
   khVPtquIgJLOMNHcACRbioyjQUslWp['plot']='%s - %s'%(khVPtquIgJLOMNHcACRbioyjQUslWe,khVPtquIgJLOMNHcACRbioyjQUslWY)
   khVPtquIgJLOMNHcACRbioyjQUslWw={'mode':'SEASON_GROUP','reagueId':khVPtquIgJLOMNHcACRbioyjQUslWB,'seasonId':khVPtquIgJLOMNHcACRbioyjQUslWT,'gameTypeId':khVPtquIgJLOMNHcACRbioyjQUslWz,'page':'1'}
   khVPtquIgJLOMNHcACRbioyjQUslav.add_dir(khVPtquIgJLOMNHcACRbioyjQUslWe,sublabel=khVPtquIgJLOMNHcACRbioyjQUslWY,img='',infoLabels=khVPtquIgJLOMNHcACRbioyjQUslWp,isFolder=khVPtquIgJLOMNHcACRbioyjQUslEd,params=khVPtquIgJLOMNHcACRbioyjQUslWw)
  if khVPtquIgJLOMNHcACRbioyjQUslEB(khVPtquIgJLOMNHcACRbioyjQUslWn)>0:xbmcplugin.endOfDirectory(khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle,cacheToDisc=khVPtquIgJLOMNHcACRbioyjQUslEd)
 def dp_Game_List(khVPtquIgJLOMNHcACRbioyjQUslav,args):
  khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.SaveCredential(khVPtquIgJLOMNHcACRbioyjQUslav.get_winCredential())
  khVPtquIgJLOMNHcACRbioyjQUslWz=args.get('gameTypeId')
  khVPtquIgJLOMNHcACRbioyjQUslWB =args.get('reagueId')
  khVPtquIgJLOMNHcACRbioyjQUslWT =args.get('seasonId')
  khVPtquIgJLOMNHcACRbioyjQUslWf =khVPtquIgJLOMNHcACRbioyjQUslED(args.get('page'))
  khVPtquIgJLOMNHcACRbioyjQUslWn,khVPtquIgJLOMNHcACRbioyjQUslWG=khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.GetGameList(khVPtquIgJLOMNHcACRbioyjQUslWz,khVPtquIgJLOMNHcACRbioyjQUslWB,khVPtquIgJLOMNHcACRbioyjQUslWT,khVPtquIgJLOMNHcACRbioyjQUslWf)
  for khVPtquIgJLOMNHcACRbioyjQUslWd in khVPtquIgJLOMNHcACRbioyjQUslWn:
   khVPtquIgJLOMNHcACRbioyjQUslWX =khVPtquIgJLOMNHcACRbioyjQUslWd.get('gameTitle')
   khVPtquIgJLOMNHcACRbioyjQUslra =khVPtquIgJLOMNHcACRbioyjQUslWd.get('beginDate')
   khVPtquIgJLOMNHcACRbioyjQUslWD =khVPtquIgJLOMNHcACRbioyjQUslWd.get('thumbnail')
   khVPtquIgJLOMNHcACRbioyjQUslrW =khVPtquIgJLOMNHcACRbioyjQUslWd.get('gameId')
   khVPtquIgJLOMNHcACRbioyjQUslrw =khVPtquIgJLOMNHcACRbioyjQUslWd.get('totVodCnt')
   khVPtquIgJLOMNHcACRbioyjQUslrE =khVPtquIgJLOMNHcACRbioyjQUslWd.get('leaguenm')
   khVPtquIgJLOMNHcACRbioyjQUslrv =khVPtquIgJLOMNHcACRbioyjQUslWd.get('seasonnm')
   khVPtquIgJLOMNHcACRbioyjQUslrn =khVPtquIgJLOMNHcACRbioyjQUslWd.get('roundnm')
   khVPtquIgJLOMNHcACRbioyjQUslrd ='%s < %s >'%(khVPtquIgJLOMNHcACRbioyjQUslWX,khVPtquIgJLOMNHcACRbioyjQUslra)
   khVPtquIgJLOMNHcACRbioyjQUslWp=khVPtquIgJLOMNHcACRbioyjQUslWd.get('info')
   khVPtquIgJLOMNHcACRbioyjQUslWw={'mode':'GAME_VOD_GROUP' if khVPtquIgJLOMNHcACRbioyjQUslrw!=0 else 'XXX','saveTitle':khVPtquIgJLOMNHcACRbioyjQUslrd,'saveImg':khVPtquIgJLOMNHcACRbioyjQUslWD,'saveInfo':khVPtquIgJLOMNHcACRbioyjQUslWp['plot'],'gameid':khVPtquIgJLOMNHcACRbioyjQUslrW}
   khVPtquIgJLOMNHcACRbioyjQUslav.add_dir(khVPtquIgJLOMNHcACRbioyjQUslWX,sublabel=khVPtquIgJLOMNHcACRbioyjQUslra,img=khVPtquIgJLOMNHcACRbioyjQUslWD,infoLabels=khVPtquIgJLOMNHcACRbioyjQUslWp,isFolder=khVPtquIgJLOMNHcACRbioyjQUslEd,params=khVPtquIgJLOMNHcACRbioyjQUslWw)
  if khVPtquIgJLOMNHcACRbioyjQUslWG:
   khVPtquIgJLOMNHcACRbioyjQUslWw['mode'] ='SEASON_GROUP' 
   khVPtquIgJLOMNHcACRbioyjQUslWw['reagueId'] =khVPtquIgJLOMNHcACRbioyjQUslWB
   khVPtquIgJLOMNHcACRbioyjQUslWw['seasonId'] =khVPtquIgJLOMNHcACRbioyjQUslWT
   khVPtquIgJLOMNHcACRbioyjQUslWw['gameTypeId']=khVPtquIgJLOMNHcACRbioyjQUslWz
   khVPtquIgJLOMNHcACRbioyjQUslWw['page'] =khVPtquIgJLOMNHcACRbioyjQUslEm(khVPtquIgJLOMNHcACRbioyjQUslWf+1)
   khVPtquIgJLOMNHcACRbioyjQUslaT='[B]%s >>[/B]'%'다음 페이지'
   khVPtquIgJLOMNHcACRbioyjQUslrD=khVPtquIgJLOMNHcACRbioyjQUslEm(khVPtquIgJLOMNHcACRbioyjQUslWf+1)
   khVPtquIgJLOMNHcACRbioyjQUslav.add_dir(khVPtquIgJLOMNHcACRbioyjQUslaT,sublabel=khVPtquIgJLOMNHcACRbioyjQUslrD,img='',infoLabels=khVPtquIgJLOMNHcACRbioyjQUslEv,isFolder=khVPtquIgJLOMNHcACRbioyjQUslEd,params=khVPtquIgJLOMNHcACRbioyjQUslWw)
  if khVPtquIgJLOMNHcACRbioyjQUslEB(khVPtquIgJLOMNHcACRbioyjQUslWn)>0:xbmcplugin.endOfDirectory(khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle,cacheToDisc=khVPtquIgJLOMNHcACRbioyjQUslEn)
 def dp_GameVod_List(khVPtquIgJLOMNHcACRbioyjQUslav,args):
  khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.SaveCredential(khVPtquIgJLOMNHcACRbioyjQUslav.get_winCredential())
  khVPtquIgJLOMNHcACRbioyjQUslrB =args.get('gameid')
  khVPtquIgJLOMNHcACRbioyjQUslrd=args.get('saveTitle')
  khVPtquIgJLOMNHcACRbioyjQUslrm =args.get('saveImg')
  khVPtquIgJLOMNHcACRbioyjQUslrp =args.get('saveInfo')
  khVPtquIgJLOMNHcACRbioyjQUslWn=khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.GetGameVodList(khVPtquIgJLOMNHcACRbioyjQUslrB)
  for khVPtquIgJLOMNHcACRbioyjQUslWd in khVPtquIgJLOMNHcACRbioyjQUslWn:
   khVPtquIgJLOMNHcACRbioyjQUslWF =khVPtquIgJLOMNHcACRbioyjQUslWd.get('vodTitle')
   khVPtquIgJLOMNHcACRbioyjQUslWS =khVPtquIgJLOMNHcACRbioyjQUslWd.get('vodId')
   khVPtquIgJLOMNHcACRbioyjQUslWK =khVPtquIgJLOMNHcACRbioyjQUslWd.get('vodType')
   khVPtquIgJLOMNHcACRbioyjQUslWD=khVPtquIgJLOMNHcACRbioyjQUslWd.get('thumbnail')
   khVPtquIgJLOMNHcACRbioyjQUslWx =khVPtquIgJLOMNHcACRbioyjQUslWd.get('vtypeId')
   khVPtquIgJLOMNHcACRbioyjQUslWp=khVPtquIgJLOMNHcACRbioyjQUslWd.get('info')
   khVPtquIgJLOMNHcACRbioyjQUslWp['plot']='%s \n\n %s'%(khVPtquIgJLOMNHcACRbioyjQUslWF,khVPtquIgJLOMNHcACRbioyjQUslrp)
   khVPtquIgJLOMNHcACRbioyjQUslWw={'mode':'GAME_VOD','saveTitle':khVPtquIgJLOMNHcACRbioyjQUslrd,'saveImg':khVPtquIgJLOMNHcACRbioyjQUslrm,'saveId':khVPtquIgJLOMNHcACRbioyjQUslrB,'saveInfo':khVPtquIgJLOMNHcACRbioyjQUslrp,'mediacode':khVPtquIgJLOMNHcACRbioyjQUslWS,'mediatype':'vod','vtypeId':khVPtquIgJLOMNHcACRbioyjQUslWx}
   khVPtquIgJLOMNHcACRbioyjQUslav.add_dir(khVPtquIgJLOMNHcACRbioyjQUslWF,sublabel=khVPtquIgJLOMNHcACRbioyjQUslWK,img=khVPtquIgJLOMNHcACRbioyjQUslWD,infoLabels=khVPtquIgJLOMNHcACRbioyjQUslWp,isFolder=khVPtquIgJLOMNHcACRbioyjQUslEn,params=khVPtquIgJLOMNHcACRbioyjQUslWw)
  if khVPtquIgJLOMNHcACRbioyjQUslEB(khVPtquIgJLOMNHcACRbioyjQUslWn)>0:xbmcplugin.endOfDirectory(khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle,cacheToDisc=khVPtquIgJLOMNHcACRbioyjQUslEn)
 def login_main(khVPtquIgJLOMNHcACRbioyjQUslav):
  (khVPtquIgJLOMNHcACRbioyjQUslrF,khVPtquIgJLOMNHcACRbioyjQUslrS)=khVPtquIgJLOMNHcACRbioyjQUslav.get_settings_login_info()
  if not(khVPtquIgJLOMNHcACRbioyjQUslrF and khVPtquIgJLOMNHcACRbioyjQUslrS):
   khVPtquIgJLOMNHcACRbioyjQUslam=xbmcgui.Dialog()
   khVPtquIgJLOMNHcACRbioyjQUslrK=khVPtquIgJLOMNHcACRbioyjQUslam.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if khVPtquIgJLOMNHcACRbioyjQUslrK==khVPtquIgJLOMNHcACRbioyjQUslEd:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if khVPtquIgJLOMNHcACRbioyjQUslav.cookiefile_check():return
  khVPtquIgJLOMNHcACRbioyjQUslrx =khVPtquIgJLOMNHcACRbioyjQUslED(khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  khVPtquIgJLOMNHcACRbioyjQUslre=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if khVPtquIgJLOMNHcACRbioyjQUslre==khVPtquIgJLOMNHcACRbioyjQUslEv or khVPtquIgJLOMNHcACRbioyjQUslre=='':
   khVPtquIgJLOMNHcACRbioyjQUslre=khVPtquIgJLOMNHcACRbioyjQUslED('19000101')
  else:
   khVPtquIgJLOMNHcACRbioyjQUslre=khVPtquIgJLOMNHcACRbioyjQUslED(re.sub('-','',khVPtquIgJLOMNHcACRbioyjQUslre))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   khVPtquIgJLOMNHcACRbioyjQUslrz=0
   while khVPtquIgJLOMNHcACRbioyjQUslEd:
    khVPtquIgJLOMNHcACRbioyjQUslrz+=1
    time.sleep(0.05)
    if khVPtquIgJLOMNHcACRbioyjQUslre>=khVPtquIgJLOMNHcACRbioyjQUslrx:return
    if khVPtquIgJLOMNHcACRbioyjQUslrz>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if khVPtquIgJLOMNHcACRbioyjQUslre>=khVPtquIgJLOMNHcACRbioyjQUslrx:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.GetCredential(khVPtquIgJLOMNHcACRbioyjQUslrF,khVPtquIgJLOMNHcACRbioyjQUslrS):
   khVPtquIgJLOMNHcACRbioyjQUslav.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  khVPtquIgJLOMNHcACRbioyjQUslav.set_winCredential(khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.LoadCredential())
  khVPtquIgJLOMNHcACRbioyjQUslav.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(khVPtquIgJLOMNHcACRbioyjQUslav,args):
  khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.SaveCredential(khVPtquIgJLOMNHcACRbioyjQUslav.get_winCredential())
  khVPtquIgJLOMNHcACRbioyjQUslrY=khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.GetLiveChannelList()
  for khVPtquIgJLOMNHcACRbioyjQUslrT in khVPtquIgJLOMNHcACRbioyjQUslrY:
   khVPtquIgJLOMNHcACRbioyjQUslaT =khVPtquIgJLOMNHcACRbioyjQUslrT.get('name')
   khVPtquIgJLOMNHcACRbioyjQUslWv =khVPtquIgJLOMNHcACRbioyjQUslrT.get('programName')
   khVPtquIgJLOMNHcACRbioyjQUslWD =khVPtquIgJLOMNHcACRbioyjQUslrT.get('logo')
   khVPtquIgJLOMNHcACRbioyjQUslrf=khVPtquIgJLOMNHcACRbioyjQUslrT.get('channelepg')
   khVPtquIgJLOMNHcACRbioyjQUslrG =khVPtquIgJLOMNHcACRbioyjQUslrT.get('free')
   khVPtquIgJLOMNHcACRbioyjQUslWp=khVPtquIgJLOMNHcACRbioyjQUslrT.get('info')
   khVPtquIgJLOMNHcACRbioyjQUslWp['plot']='%s'%(khVPtquIgJLOMNHcACRbioyjQUslrf)
   khVPtquIgJLOMNHcACRbioyjQUslWw={'mode':'LIVE','mediaid':khVPtquIgJLOMNHcACRbioyjQUslrT.get('id'),'mediacode':khVPtquIgJLOMNHcACRbioyjQUslrT.get('videoId'),'free':khVPtquIgJLOMNHcACRbioyjQUslrG,'mediatype':'live'}
   if khVPtquIgJLOMNHcACRbioyjQUslrG:khVPtquIgJLOMNHcACRbioyjQUslaT+=' [free]'
   khVPtquIgJLOMNHcACRbioyjQUslav.add_dir(khVPtquIgJLOMNHcACRbioyjQUslaT,sublabel=khVPtquIgJLOMNHcACRbioyjQUslWv,img=khVPtquIgJLOMNHcACRbioyjQUslWD,infoLabels=khVPtquIgJLOMNHcACRbioyjQUslWp,isFolder=khVPtquIgJLOMNHcACRbioyjQUslEn,params=khVPtquIgJLOMNHcACRbioyjQUslWw)
  if khVPtquIgJLOMNHcACRbioyjQUslEB(khVPtquIgJLOMNHcACRbioyjQUslrY)>0:xbmcplugin.endOfDirectory(khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle,cacheToDisc=khVPtquIgJLOMNHcACRbioyjQUslEn)
 def dp_EventLiveChannel_List(khVPtquIgJLOMNHcACRbioyjQUslav,args):
  khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.SaveCredential(khVPtquIgJLOMNHcACRbioyjQUslav.get_winCredential())
  khVPtquIgJLOMNHcACRbioyjQUslrY,khVPtquIgJLOMNHcACRbioyjQUslrX=khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.GetEventLiveList()
  if khVPtquIgJLOMNHcACRbioyjQUslrX!=401 and khVPtquIgJLOMNHcACRbioyjQUslEB(khVPtquIgJLOMNHcACRbioyjQUslrY)==0:
   khVPtquIgJLOMNHcACRbioyjQUslav.addon_noti(__language__(30907).encode('utf8'))
  for khVPtquIgJLOMNHcACRbioyjQUslrT in khVPtquIgJLOMNHcACRbioyjQUslrY:
   khVPtquIgJLOMNHcACRbioyjQUslaT =khVPtquIgJLOMNHcACRbioyjQUslrT.get('title')
   khVPtquIgJLOMNHcACRbioyjQUslWv =khVPtquIgJLOMNHcACRbioyjQUslrT.get('startTime')
   khVPtquIgJLOMNHcACRbioyjQUslWD =khVPtquIgJLOMNHcACRbioyjQUslrT.get('logo')
   khVPtquIgJLOMNHcACRbioyjQUslrG =khVPtquIgJLOMNHcACRbioyjQUslrT.get('free')
   khVPtquIgJLOMNHcACRbioyjQUslWp=khVPtquIgJLOMNHcACRbioyjQUslrT.get('info')
   khVPtquIgJLOMNHcACRbioyjQUslWp['plot']='%s\n\n%s'%(khVPtquIgJLOMNHcACRbioyjQUslaT,khVPtquIgJLOMNHcACRbioyjQUslWv)
   khVPtquIgJLOMNHcACRbioyjQUslWw={'mode':'ELIVE','mediaid':khVPtquIgJLOMNHcACRbioyjQUslrT.get('liveId'),'mediacode':'','free':khVPtquIgJLOMNHcACRbioyjQUslrG,'mediatype':'live'}
   if khVPtquIgJLOMNHcACRbioyjQUslrG:khVPtquIgJLOMNHcACRbioyjQUslaT+=' [free]'
   khVPtquIgJLOMNHcACRbioyjQUslav.add_dir(khVPtquIgJLOMNHcACRbioyjQUslaT,sublabel=khVPtquIgJLOMNHcACRbioyjQUslWv,img=khVPtquIgJLOMNHcACRbioyjQUslWD,infoLabels=khVPtquIgJLOMNHcACRbioyjQUslWp,isFolder=khVPtquIgJLOMNHcACRbioyjQUslEn,params=khVPtquIgJLOMNHcACRbioyjQUslWw)
  if khVPtquIgJLOMNHcACRbioyjQUslEB(khVPtquIgJLOMNHcACRbioyjQUslrY)>0:xbmcplugin.endOfDirectory(khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle,cacheToDisc=khVPtquIgJLOMNHcACRbioyjQUslEd)
  return khVPtquIgJLOMNHcACRbioyjQUslrX
 def play_VIDEO(khVPtquIgJLOMNHcACRbioyjQUslav,args):
  khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.SaveCredential(khVPtquIgJLOMNHcACRbioyjQUslav.get_winCredential())
  if args.get('free')=='False':
   if khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.CheckSubEnd()==khVPtquIgJLOMNHcACRbioyjQUslEn:
    khVPtquIgJLOMNHcACRbioyjQUslav.addon_noti(__language__(30908).encode('utf8'))
    return
  khVPtquIgJLOMNHcACRbioyjQUslwa =args.get('mode')
  khVPtquIgJLOMNHcACRbioyjQUslwW =args.get('mediacode')
  khVPtquIgJLOMNHcACRbioyjQUslwr =args.get('mediatype')
  khVPtquIgJLOMNHcACRbioyjQUslWx =args.get('vtypeId')
  if args.get('mode')=='ELIVE':
   khVPtquIgJLOMNHcACRbioyjQUslwW=khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if khVPtquIgJLOMNHcACRbioyjQUslwW=='' or khVPtquIgJLOMNHcACRbioyjQUslwW==khVPtquIgJLOMNHcACRbioyjQUslEv:
   khVPtquIgJLOMNHcACRbioyjQUslav.addon_noti(__language__(30907).encode('utf8'))
   return
  khVPtquIgJLOMNHcACRbioyjQUslwE=khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.GetBroadURL(khVPtquIgJLOMNHcACRbioyjQUslwW,khVPtquIgJLOMNHcACRbioyjQUslwr,khVPtquIgJLOMNHcACRbioyjQUslWx)
  if khVPtquIgJLOMNHcACRbioyjQUslwE=='':
   khVPtquIgJLOMNHcACRbioyjQUslav.addon_noti(__language__(30908).encode('utf8'))
   return
  khVPtquIgJLOMNHcACRbioyjQUslwv=khVPtquIgJLOMNHcACRbioyjQUslwE
  khVPtquIgJLOMNHcACRbioyjQUslav.addon_log(khVPtquIgJLOMNHcACRbioyjQUslwv,khVPtquIgJLOMNHcACRbioyjQUslEn)
  khVPtquIgJLOMNHcACRbioyjQUslwn=xbmcgui.ListItem(path=khVPtquIgJLOMNHcACRbioyjQUslwv)
  xbmcplugin.setResolvedUrl(khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle,khVPtquIgJLOMNHcACRbioyjQUslEd,khVPtquIgJLOMNHcACRbioyjQUslwn)
  try:
   if khVPtquIgJLOMNHcACRbioyjQUslwr=='vod' and khVPtquIgJLOMNHcACRbioyjQUslwa!='POP_VOD':
    khVPtquIgJLOMNHcACRbioyjQUslWw={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    khVPtquIgJLOMNHcACRbioyjQUslav.Save_Watched_List(khVPtquIgJLOMNHcACRbioyjQUslwr,khVPtquIgJLOMNHcACRbioyjQUslWw)
  except:
   khVPtquIgJLOMNHcACRbioyjQUslEv
 def logout(khVPtquIgJLOMNHcACRbioyjQUslav):
  khVPtquIgJLOMNHcACRbioyjQUslam=xbmcgui.Dialog()
  khVPtquIgJLOMNHcACRbioyjQUslrK=khVPtquIgJLOMNHcACRbioyjQUslam.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if khVPtquIgJLOMNHcACRbioyjQUslrK==khVPtquIgJLOMNHcACRbioyjQUslEn:sys.exit()
  khVPtquIgJLOMNHcACRbioyjQUslav.wininfo_clear()
  if os.path.isfile(khVPtquIgJLOMNHcACRbioyjQUslaE):os.remove(khVPtquIgJLOMNHcACRbioyjQUslaE)
  khVPtquIgJLOMNHcACRbioyjQUslav.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(khVPtquIgJLOMNHcACRbioyjQUslav):
  khVPtquIgJLOMNHcACRbioyjQUslae=xbmcgui.Window(10000)
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_SESSIONID','')
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_SESSION','')
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_ACCOUNTID','')
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_POLICYKEY','')
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_SUBEND','')
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(khVPtquIgJLOMNHcACRbioyjQUslav):
  khVPtquIgJLOMNHcACRbioyjQUslwd =khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.Get_Now_Datetime()
  khVPtquIgJLOMNHcACRbioyjQUslwD=khVPtquIgJLOMNHcACRbioyjQUslwd+datetime.timedelta(days=khVPtquIgJLOMNHcACRbioyjQUslED(__addon__.getSetting('cache_ttl')))
  khVPtquIgJLOMNHcACRbioyjQUslae=xbmcgui.Window(10000)
  khVPtquIgJLOMNHcACRbioyjQUslwB={'spotv_sessionid':khVPtquIgJLOMNHcACRbioyjQUslae.getProperty('SPOTV_M_SESSIONID'),'spotv_session':khVPtquIgJLOMNHcACRbioyjQUslae.getProperty('SPOTV_M_SESSION'),'spotv_accountId':khVPtquIgJLOMNHcACRbioyjQUslae.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(khVPtquIgJLOMNHcACRbioyjQUslae.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.SPOTV_PMCODE+khVPtquIgJLOMNHcACRbioyjQUslae.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':khVPtquIgJLOMNHcACRbioyjQUslwD.strftime('%Y-%m-%d')}
  try: 
   fp=khVPtquIgJLOMNHcACRbioyjQUslEp(khVPtquIgJLOMNHcACRbioyjQUslaE,'w',-1,'utf-8')
   json.dump(khVPtquIgJLOMNHcACRbioyjQUslwB,fp)
   fp.close()
  except khVPtquIgJLOMNHcACRbioyjQUslEF as exception:
   khVPtquIgJLOMNHcACRbioyjQUslES(exception)
 def cookiefile_check(khVPtquIgJLOMNHcACRbioyjQUslav):
  khVPtquIgJLOMNHcACRbioyjQUslwB={}
  try: 
   fp=khVPtquIgJLOMNHcACRbioyjQUslEp(khVPtquIgJLOMNHcACRbioyjQUslaE,'r',-1,'utf-8')
   khVPtquIgJLOMNHcACRbioyjQUslwB= json.load(fp)
   fp.close()
  except khVPtquIgJLOMNHcACRbioyjQUslEF as exception:
   khVPtquIgJLOMNHcACRbioyjQUslav.wininfo_clear()
   return khVPtquIgJLOMNHcACRbioyjQUslEn
  khVPtquIgJLOMNHcACRbioyjQUslrF =__addon__.getSetting('id')
  khVPtquIgJLOMNHcACRbioyjQUslrS =__addon__.getSetting('pw')
  khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_id'] =base64.standard_b64decode(khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_id']).decode('utf-8')
  khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_pw'] =base64.standard_b64decode(khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_pw']).decode('utf-8')
  khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_policyKey']=base64.standard_b64decode(khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_policyKey']).decode('utf-8')
  khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_subend']=base64.standard_b64decode(khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_subend']).decode('utf-8')[khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.SPOTV_PMSIZE:]
  if khVPtquIgJLOMNHcACRbioyjQUslrF!=khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_id']or khVPtquIgJLOMNHcACRbioyjQUslrS!=khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_pw']:
   khVPtquIgJLOMNHcACRbioyjQUslav.wininfo_clear()
   return khVPtquIgJLOMNHcACRbioyjQUslEn
  khVPtquIgJLOMNHcACRbioyjQUslrx =khVPtquIgJLOMNHcACRbioyjQUslED(khVPtquIgJLOMNHcACRbioyjQUslav.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  khVPtquIgJLOMNHcACRbioyjQUslwm=khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_limitdate']
  khVPtquIgJLOMNHcACRbioyjQUslre =khVPtquIgJLOMNHcACRbioyjQUslED(re.sub('-','',khVPtquIgJLOMNHcACRbioyjQUslwm))
  if khVPtquIgJLOMNHcACRbioyjQUslre<khVPtquIgJLOMNHcACRbioyjQUslrx:
   khVPtquIgJLOMNHcACRbioyjQUslav.wininfo_clear()
   return khVPtquIgJLOMNHcACRbioyjQUslEn
  khVPtquIgJLOMNHcACRbioyjQUslae=xbmcgui.Window(10000)
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_SESSIONID',khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_sessionid'])
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_SESSION',khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_session'])
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_ACCOUNTID',khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_accountId'])
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_POLICYKEY',khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_policyKey'])
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_SUBEND',khVPtquIgJLOMNHcACRbioyjQUslwB['spotv_subend'])
  khVPtquIgJLOMNHcACRbioyjQUslae.setProperty('SPOTV_M_LOGINTIME',khVPtquIgJLOMNHcACRbioyjQUslwm)
  return khVPtquIgJLOMNHcACRbioyjQUslEd
 def dp_WatchList_Delete(khVPtquIgJLOMNHcACRbioyjQUslav,args):
  khVPtquIgJLOMNHcACRbioyjQUslwr=args.get('mediatype')
  khVPtquIgJLOMNHcACRbioyjQUslam=xbmcgui.Dialog()
  khVPtquIgJLOMNHcACRbioyjQUslrK=khVPtquIgJLOMNHcACRbioyjQUslam.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if khVPtquIgJLOMNHcACRbioyjQUslrK==khVPtquIgJLOMNHcACRbioyjQUslEn:sys.exit()
  khVPtquIgJLOMNHcACRbioyjQUslav.Delete_Watched_List(khVPtquIgJLOMNHcACRbioyjQUslwr)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(khVPtquIgJLOMNHcACRbioyjQUslav,khVPtquIgJLOMNHcACRbioyjQUslwr):
  try:
   khVPtquIgJLOMNHcACRbioyjQUslwp=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%khVPtquIgJLOMNHcACRbioyjQUslwr))
   fp=khVPtquIgJLOMNHcACRbioyjQUslEp(khVPtquIgJLOMNHcACRbioyjQUslwp,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   khVPtquIgJLOMNHcACRbioyjQUslEv
 def Load_Watched_List(khVPtquIgJLOMNHcACRbioyjQUslav,khVPtquIgJLOMNHcACRbioyjQUslwr):
  try:
   khVPtquIgJLOMNHcACRbioyjQUslwp=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%khVPtquIgJLOMNHcACRbioyjQUslwr))
   fp=khVPtquIgJLOMNHcACRbioyjQUslEp(khVPtquIgJLOMNHcACRbioyjQUslwp,'r',-1,'utf-8')
   khVPtquIgJLOMNHcACRbioyjQUslwF=fp.readlines()
   fp.close()
  except:
   khVPtquIgJLOMNHcACRbioyjQUslwF=[]
  return khVPtquIgJLOMNHcACRbioyjQUslwF
 def Save_Watched_List(khVPtquIgJLOMNHcACRbioyjQUslav,stype,khVPtquIgJLOMNHcACRbioyjQUslaD):
  try:
   khVPtquIgJLOMNHcACRbioyjQUslwp=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   khVPtquIgJLOMNHcACRbioyjQUslwS=khVPtquIgJLOMNHcACRbioyjQUslav.Load_Watched_List(stype) 
   fp=khVPtquIgJLOMNHcACRbioyjQUslEp(khVPtquIgJLOMNHcACRbioyjQUslwp,'w',-1,'utf-8')
   khVPtquIgJLOMNHcACRbioyjQUslwK=urllib.parse.urlencode(khVPtquIgJLOMNHcACRbioyjQUslaD)
   khVPtquIgJLOMNHcACRbioyjQUslwK=khVPtquIgJLOMNHcACRbioyjQUslwK+'\n'
   fp.write(khVPtquIgJLOMNHcACRbioyjQUslwK)
   khVPtquIgJLOMNHcACRbioyjQUslwx=0
   for khVPtquIgJLOMNHcACRbioyjQUslwe in khVPtquIgJLOMNHcACRbioyjQUslwS:
    khVPtquIgJLOMNHcACRbioyjQUslwz=khVPtquIgJLOMNHcACRbioyjQUslEK(urllib.parse.parse_qsl(khVPtquIgJLOMNHcACRbioyjQUslwe))
    khVPtquIgJLOMNHcACRbioyjQUslwY=khVPtquIgJLOMNHcACRbioyjQUslaD.get('code')
    khVPtquIgJLOMNHcACRbioyjQUslwT=khVPtquIgJLOMNHcACRbioyjQUslwz.get('code')
    if khVPtquIgJLOMNHcACRbioyjQUslwY!=khVPtquIgJLOMNHcACRbioyjQUslwT:
     fp.write(khVPtquIgJLOMNHcACRbioyjQUslwe)
     khVPtquIgJLOMNHcACRbioyjQUslwx+=1
     if khVPtquIgJLOMNHcACRbioyjQUslwx>=50:break
   fp.close()
  except:
   khVPtquIgJLOMNHcACRbioyjQUslEv
 def dp_Watch_List(khVPtquIgJLOMNHcACRbioyjQUslav,args):
  khVPtquIgJLOMNHcACRbioyjQUslwr ='vod'
  if khVPtquIgJLOMNHcACRbioyjQUslwr=='vod':
   khVPtquIgJLOMNHcACRbioyjQUslwf=khVPtquIgJLOMNHcACRbioyjQUslav.Load_Watched_List(khVPtquIgJLOMNHcACRbioyjQUslwr)
   for khVPtquIgJLOMNHcACRbioyjQUslwG in khVPtquIgJLOMNHcACRbioyjQUslwf:
    khVPtquIgJLOMNHcACRbioyjQUslwX=khVPtquIgJLOMNHcACRbioyjQUslEK(urllib.parse.parse_qsl(khVPtquIgJLOMNHcACRbioyjQUslwG))
    khVPtquIgJLOMNHcACRbioyjQUslaT =khVPtquIgJLOMNHcACRbioyjQUslwX.get('title')
    khVPtquIgJLOMNHcACRbioyjQUslWD=khVPtquIgJLOMNHcACRbioyjQUslwX.get('img')
    khVPtquIgJLOMNHcACRbioyjQUslwW=khVPtquIgJLOMNHcACRbioyjQUslwX.get('code')
    khVPtquIgJLOMNHcACRbioyjQUslEa =khVPtquIgJLOMNHcACRbioyjQUslwX.get('info')
    khVPtquIgJLOMNHcACRbioyjQUslWp={}
    khVPtquIgJLOMNHcACRbioyjQUslWp['plot']=khVPtquIgJLOMNHcACRbioyjQUslEa
    khVPtquIgJLOMNHcACRbioyjQUslWw={'mode':'GAME_VOD_GROUP','gameid':khVPtquIgJLOMNHcACRbioyjQUslwW,'saveTitle':khVPtquIgJLOMNHcACRbioyjQUslaT,'saveImg':khVPtquIgJLOMNHcACRbioyjQUslWD,'saveInfo':khVPtquIgJLOMNHcACRbioyjQUslEa,'mediatype':khVPtquIgJLOMNHcACRbioyjQUslwr}
    khVPtquIgJLOMNHcACRbioyjQUslav.add_dir(khVPtquIgJLOMNHcACRbioyjQUslaT,sublabel='',img=khVPtquIgJLOMNHcACRbioyjQUslWD,infoLabels=khVPtquIgJLOMNHcACRbioyjQUslWp,isFolder=khVPtquIgJLOMNHcACRbioyjQUslEd,params=khVPtquIgJLOMNHcACRbioyjQUslWw)
   khVPtquIgJLOMNHcACRbioyjQUslWp={'plot':'시청목록을 삭제합니다.'}
   khVPtquIgJLOMNHcACRbioyjQUslaT='*** 시청목록 삭제 ***'
   khVPtquIgJLOMNHcACRbioyjQUslWw={'mode':'MYVIEW_REMOVE','mediatype':khVPtquIgJLOMNHcACRbioyjQUslwr}
   khVPtquIgJLOMNHcACRbioyjQUslav.add_dir(khVPtquIgJLOMNHcACRbioyjQUslaT,sublabel='',img='',infoLabels=khVPtquIgJLOMNHcACRbioyjQUslWp,isFolder=khVPtquIgJLOMNHcACRbioyjQUslEn,params=khVPtquIgJLOMNHcACRbioyjQUslWw)
   xbmcplugin.endOfDirectory(khVPtquIgJLOMNHcACRbioyjQUslav._addon_handle,cacheToDisc=khVPtquIgJLOMNHcACRbioyjQUslEn)
 def spotv_main(khVPtquIgJLOMNHcACRbioyjQUslav):
  khVPtquIgJLOMNHcACRbioyjQUslEr=khVPtquIgJLOMNHcACRbioyjQUslav.main_params.get('mode',khVPtquIgJLOMNHcACRbioyjQUslEv)
  if khVPtquIgJLOMNHcACRbioyjQUslEr=='LOGOUT':
   khVPtquIgJLOMNHcACRbioyjQUslav.logout()
   return
  khVPtquIgJLOMNHcACRbioyjQUslav.login_main()
  if khVPtquIgJLOMNHcACRbioyjQUslEr is khVPtquIgJLOMNHcACRbioyjQUslEv:
   khVPtquIgJLOMNHcACRbioyjQUslav.dp_Main_List()
  elif khVPtquIgJLOMNHcACRbioyjQUslEr=='LIVE_GROUP':
   khVPtquIgJLOMNHcACRbioyjQUslav.dp_LiveChannel_List(khVPtquIgJLOMNHcACRbioyjQUslav.main_params)
  elif khVPtquIgJLOMNHcACRbioyjQUslEr=='ELIVE_GROUP':
   khVPtquIgJLOMNHcACRbioyjQUslrX=khVPtquIgJLOMNHcACRbioyjQUslav.dp_EventLiveChannel_List(khVPtquIgJLOMNHcACRbioyjQUslav.main_params)
   if khVPtquIgJLOMNHcACRbioyjQUslrX==401:
    if os.path.isfile(khVPtquIgJLOMNHcACRbioyjQUslaE):os.remove(khVPtquIgJLOMNHcACRbioyjQUslaE)
    khVPtquIgJLOMNHcACRbioyjQUslav.login_main()
    khVPtquIgJLOMNHcACRbioyjQUslav.dp_EventLiveChannel_List(khVPtquIgJLOMNHcACRbioyjQUslav.main_params)
  elif khVPtquIgJLOMNHcACRbioyjQUslEr in['LIVE','GAME_VOD','POP_VOD','ELIVE']:
   khVPtquIgJLOMNHcACRbioyjQUslav.play_VIDEO(khVPtquIgJLOMNHcACRbioyjQUslav.main_params)
  elif khVPtquIgJLOMNHcACRbioyjQUslEr=='VOD_GROUP':
   khVPtquIgJLOMNHcACRbioyjQUslav.dp_MainLeague_List(khVPtquIgJLOMNHcACRbioyjQUslav.main_params)
  elif khVPtquIgJLOMNHcACRbioyjQUslEr=='POP_GROUP':
   khVPtquIgJLOMNHcACRbioyjQUslav.dp_PopVod_GroupList(khVPtquIgJLOMNHcACRbioyjQUslav.main_params)
  elif khVPtquIgJLOMNHcACRbioyjQUslEr=='LEAGUE_GROUP':
   khVPtquIgJLOMNHcACRbioyjQUslav.dp_Season_List(khVPtquIgJLOMNHcACRbioyjQUslav.main_params)
  elif khVPtquIgJLOMNHcACRbioyjQUslEr=='SEASON_GROUP':
   khVPtquIgJLOMNHcACRbioyjQUslav.dp_Game_List(khVPtquIgJLOMNHcACRbioyjQUslav.main_params)
  elif khVPtquIgJLOMNHcACRbioyjQUslEr=='GAME_VOD_GROUP':
   khVPtquIgJLOMNHcACRbioyjQUslav.dp_GameVod_List(khVPtquIgJLOMNHcACRbioyjQUslav.main_params)
  elif khVPtquIgJLOMNHcACRbioyjQUslEr=='WATCH':
   khVPtquIgJLOMNHcACRbioyjQUslav.dp_Watch_List(khVPtquIgJLOMNHcACRbioyjQUslav.main_params)
  elif khVPtquIgJLOMNHcACRbioyjQUslEr=='MYVIEW_REMOVE':
   khVPtquIgJLOMNHcACRbioyjQUslav.dp_WatchList_Delete(khVPtquIgJLOMNHcACRbioyjQUslav.main_params)
  else:
   khVPtquIgJLOMNHcACRbioyjQUslEv
# Created by pyminifier (https://github.com/liftoff/pyminifier)
