__author__="NightRain"
mrczXpUQCiVkyaFuSdJDWBLqTjGfwM=object
mrczXpUQCiVkyaFuSdJDWBLqTjGfwR=None
mrczXpUQCiVkyaFuSdJDWBLqTjGfwY=False
mrczXpUQCiVkyaFuSdJDWBLqTjGfwv=print
mrczXpUQCiVkyaFuSdJDWBLqTjGfwo=str
mrczXpUQCiVkyaFuSdJDWBLqTjGfws=True
mrczXpUQCiVkyaFuSdJDWBLqTjGfwt=Exception
mrczXpUQCiVkyaFuSdJDWBLqTjGfwe=int
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
mrczXpUQCiVkyaFuSdJDWBLqTjGfNg ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
mrczXpUQCiVkyaFuSdJDWBLqTjGfNw={'stream50':1080,'stream40':720,'stream30':540}
class mrczXpUQCiVkyaFuSdJDWBLqTjGfNh(mrczXpUQCiVkyaFuSdJDWBLqTjGfwM):
 def __init__(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SESSIONID=''
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SESSION =''
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_ACCOUNTID=''
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_POLICYKEY=''
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SUBEND =''
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_PMCODE ='987'
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_PMSIZE =3
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.GAMELIST_LIMIT =10
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.API_DOMAIN ='https://www.spotvnow.co.kr'
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.BC_DOMAIN ='https://players.brightcove.net'
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.DEFAULT_HEADER ={'user-agent':mrczXpUQCiVkyaFuSdJDWBLqTjGfNg}
 def callRequestCookies(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn,jobtype,mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,redirects=mrczXpUQCiVkyaFuSdJDWBLqTjGfwY):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNK=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.DEFAULT_HEADER
  if headers:mrczXpUQCiVkyaFuSdJDWBLqTjGfNK.update(headers)
  if jobtype=='Get':
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNA=requests.get(mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,params=params,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfNK,cookies=cookies,allow_redirects=redirects)
  else:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNA=requests.post(mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,data=payload,params=params,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfNK,cookies=cookies,allow_redirects=redirects)
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfNA
 def makeDefaultCookies(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNI={'SESSION':mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SESSION}
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfNI
 def GetCredential(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn,user_id,user_pw):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNH=mrczXpUQCiVkyaFuSdJDWBLqTjGfwY
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNE=mrczXpUQCiVkyaFuSdJDWBLqTjGfNs=mrczXpUQCiVkyaFuSdJDWBLqTjGfNO=mrczXpUQCiVkyaFuSdJDWBLqTjGfNx=mrczXpUQCiVkyaFuSdJDWBLqTjGfNe=''
  try:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNl=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNM=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNR=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.API_DOMAIN+'/api/v2/login'
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNY={'username':mrczXpUQCiVkyaFuSdJDWBLqTjGfNl,'password':mrczXpUQCiVkyaFuSdJDWBLqTjGfNM}
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNY=json.dumps(mrczXpUQCiVkyaFuSdJDWBLqTjGfNY)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Post',mrczXpUQCiVkyaFuSdJDWBLqTjGfNR,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfNY,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.status_code)
   for mrczXpUQCiVkyaFuSdJDWBLqTjGfNo in mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.cookies:
    if mrczXpUQCiVkyaFuSdJDWBLqTjGfNo.name=='SESSION':
     mrczXpUQCiVkyaFuSdJDWBLqTjGfNs=mrczXpUQCiVkyaFuSdJDWBLqTjGfNo.value
     break
   if mrczXpUQCiVkyaFuSdJDWBLqTjGfNs=='':return mrczXpUQCiVkyaFuSdJDWBLqTjGfNH
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNt=json.loads(mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text)
   if not('userId' in mrczXpUQCiVkyaFuSdJDWBLqTjGfNt):return mrczXpUQCiVkyaFuSdJDWBLqTjGfNH
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNE=mrczXpUQCiVkyaFuSdJDWBLqTjGfwo(mrczXpUQCiVkyaFuSdJDWBLqTjGfNt['userId'])
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNe =mrczXpUQCiVkyaFuSdJDWBLqTjGfwo(mrczXpUQCiVkyaFuSdJDWBLqTjGfNt['subEndTime'])
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNO,mrczXpUQCiVkyaFuSdJDWBLqTjGfNx=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.GetPolicyKey()
   if mrczXpUQCiVkyaFuSdJDWBLqTjGfNx=='':return mrczXpUQCiVkyaFuSdJDWBLqTjGfNH
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNH=mrczXpUQCiVkyaFuSdJDWBLqTjGfws
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNE=mrczXpUQCiVkyaFuSdJDWBLqTjGfNs='' 
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNP={'spotv_sessionid':mrczXpUQCiVkyaFuSdJDWBLqTjGfNE,'spotv_session':mrczXpUQCiVkyaFuSdJDWBLqTjGfNs,'spotv_accountId':mrczXpUQCiVkyaFuSdJDWBLqTjGfNO,'spotv_policyKey':mrczXpUQCiVkyaFuSdJDWBLqTjGfNx,'spotv_subend':mrczXpUQCiVkyaFuSdJDWBLqTjGfNe}
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SaveCredential(mrczXpUQCiVkyaFuSdJDWBLqTjGfNP)
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfNH
 def SaveCredential(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn,mrczXpUQCiVkyaFuSdJDWBLqTjGfNP):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SESSIONID=mrczXpUQCiVkyaFuSdJDWBLqTjGfNP.get('spotv_sessionid')
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SESSION =mrczXpUQCiVkyaFuSdJDWBLqTjGfNP.get('spotv_session')
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_ACCOUNTID=mrczXpUQCiVkyaFuSdJDWBLqTjGfNP.get('spotv_accountId')
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_POLICYKEY=mrczXpUQCiVkyaFuSdJDWBLqTjGfNP.get('spotv_policyKey')
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SUBEND =mrczXpUQCiVkyaFuSdJDWBLqTjGfNP.get('spotv_subend')
 def LoadCredential(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfNP={'spotv_sessionid':mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SESSIONID,'spotv_session':mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SESSION,'spotv_accountId':mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_ACCOUNTID,'spotv_policyKey':mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_POLICYKEY,'spotv_subend':mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SUBEND}
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfNP
 def Get_Now_Datetime(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhN=[]
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhg ={}
  try:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.API_DOMAIN+'/api/v2/channel'
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Get',mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNt=json.loads(mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhg=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.GetEPGList()
   for mrczXpUQCiVkyaFuSdJDWBLqTjGfhn in mrczXpUQCiVkyaFuSdJDWBLqTjGfNt:
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhK={}
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhK['mediatype']='video'
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhK['title'] =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['programName']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhK['studio'] =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['name']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhA={'id':mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['id'],'name':mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['name'],'logo':mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['logo'],'videoId':mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['videoId'].replace('ref:',''),'free':mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['free'],'programName':mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['programName'],'channelepg':mrczXpUQCiVkyaFuSdJDWBLqTjGfhg.get(mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['id']),'info':mrczXpUQCiVkyaFuSdJDWBLqTjGfhK}
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhN.append(mrczXpUQCiVkyaFuSdJDWBLqTjGfhA)
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfhN
 def GetEPGList(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhI={}
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhH=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.Get_Now_Datetime()
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhE=mrczXpUQCiVkyaFuSdJDWBLqTjGfhH.strftime('%Y%m%d%H%M')
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhl='%s-%s-%s'%(mrczXpUQCiVkyaFuSdJDWBLqTjGfhE[0:4],mrczXpUQCiVkyaFuSdJDWBLqTjGfhE[4:6],mrczXpUQCiVkyaFuSdJDWBLqTjGfhE[6:8])
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhM=(mrczXpUQCiVkyaFuSdJDWBLqTjGfhH+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.API_DOMAIN+'/api/v2/program/'+mrczXpUQCiVkyaFuSdJDWBLqTjGfhl
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Get',mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNt=json.loads(mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhR=-1 
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhY =''
   for mrczXpUQCiVkyaFuSdJDWBLqTjGfhn in mrczXpUQCiVkyaFuSdJDWBLqTjGfNt:
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhv=mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['channelId']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfho =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['startTime'].replace('-','').replace(' ','').replace(':','')
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhs =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['endTime'].replace('-','').replace(' ','').replace(':','')
    if mrczXpUQCiVkyaFuSdJDWBLqTjGfwe(mrczXpUQCiVkyaFuSdJDWBLqTjGfhE)>mrczXpUQCiVkyaFuSdJDWBLqTjGfwe(mrczXpUQCiVkyaFuSdJDWBLqTjGfhs) :continue
    if mrczXpUQCiVkyaFuSdJDWBLqTjGfwe(mrczXpUQCiVkyaFuSdJDWBLqTjGfhM)<mrczXpUQCiVkyaFuSdJDWBLqTjGfwe(mrczXpUQCiVkyaFuSdJDWBLqTjGfho):continue
    if mrczXpUQCiVkyaFuSdJDWBLqTjGfhR!=mrczXpUQCiVkyaFuSdJDWBLqTjGfhv:
     if mrczXpUQCiVkyaFuSdJDWBLqTjGfhY!='':mrczXpUQCiVkyaFuSdJDWBLqTjGfhI[mrczXpUQCiVkyaFuSdJDWBLqTjGfhR]=mrczXpUQCiVkyaFuSdJDWBLqTjGfhY
     mrczXpUQCiVkyaFuSdJDWBLqTjGfhR=mrczXpUQCiVkyaFuSdJDWBLqTjGfhv
     mrczXpUQCiVkyaFuSdJDWBLqTjGfhY =''
    if mrczXpUQCiVkyaFuSdJDWBLqTjGfhY:mrczXpUQCiVkyaFuSdJDWBLqTjGfhY+='\n'
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhY+=mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['title']+'\n'
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhY+=' [%s ~ %s]'%(mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['startTime'][-5:],mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['endTime'][-5:])+'\n'
   if mrczXpUQCiVkyaFuSdJDWBLqTjGfhY:mrczXpUQCiVkyaFuSdJDWBLqTjGfhI[mrczXpUQCiVkyaFuSdJDWBLqTjGfhR]=mrczXpUQCiVkyaFuSdJDWBLqTjGfhY
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfhI
 def CheckMainEnd(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfht=base64.standard_b64encode((mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_PMCODE+mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SESSIONID).encode()).decode('utf-8')
  if mrczXpUQCiVkyaFuSdJDWBLqTjGfht=='OTg3MTgzMzM0Ng==' or mrczXpUQCiVkyaFuSdJDWBLqTjGfht=='OTg3MTgzMzExNw==':return mrczXpUQCiVkyaFuSdJDWBLqTjGfws
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfwY
 def CheckSubEnd(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhe=mrczXpUQCiVkyaFuSdJDWBLqTjGfwY
  try:
   if mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.CheckMainEnd():return mrczXpUQCiVkyaFuSdJDWBLqTjGfws 
   if mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_SUBEND=='0':return mrczXpUQCiVkyaFuSdJDWBLqTjGfhe
  except:
   return mrczXpUQCiVkyaFuSdJDWBLqTjGfhe
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfhe
 def GetMainJspath(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhO=''
  try:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.API_DOMAIN
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Get',mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhx=mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhP =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',mrczXpUQCiVkyaFuSdJDWBLqTjGfhx)[0]
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhO=mrczXpUQCiVkyaFuSdJDWBLqTjGfhP
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfhO
 def GetBcPlayerUrl(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhb=''
  try:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.GetMainJspath()
   if mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=='':return mrczXpUQCiVkyaFuSdJDWBLqTjGfhb
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Get',mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhx=mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgN =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',mrczXpUQCiVkyaFuSdJDWBLqTjGfhx)[0]
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgN =mrczXpUQCiVkyaFuSdJDWBLqTjGfgN.replace('bc','"bc"')
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgN =mrczXpUQCiVkyaFuSdJDWBLqTjGfgN.replace('player','"player"')
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgN ='{'+mrczXpUQCiVkyaFuSdJDWBLqTjGfgN+'}'
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgN =json.loads(mrczXpUQCiVkyaFuSdJDWBLqTjGfgN)
   bc =mrczXpUQCiVkyaFuSdJDWBLqTjGfgN['bc']
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgh =mrczXpUQCiVkyaFuSdJDWBLqTjGfgN['player']
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhb="%s/%s/%s_default/index.min.js"%(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.BC_DOMAIN,bc,mrczXpUQCiVkyaFuSdJDWBLqTjGfgh)
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfhb
 def GetPolicyKey(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfgw=policykey=''
  try:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.GetBcPlayerUrl()
   if mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=='':return mrczXpUQCiVkyaFuSdJDWBLqTjGfgw,mrczXpUQCiVkyaFuSdJDWBLqTjGfgK
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Get',mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhx=mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhP =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',mrczXpUQCiVkyaFuSdJDWBLqTjGfhx)[0]
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhP =mrczXpUQCiVkyaFuSdJDWBLqTjGfhP.replace('accountId','"accountId"')
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhP =mrczXpUQCiVkyaFuSdJDWBLqTjGfhP.replace('policyKey','"policyKey"')
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhP ='{'+mrczXpUQCiVkyaFuSdJDWBLqTjGfhP+'}'
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgn=json.loads(mrczXpUQCiVkyaFuSdJDWBLqTjGfhP)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgw =mrczXpUQCiVkyaFuSdJDWBLqTjGfgn['accountId']
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgK =mrczXpUQCiVkyaFuSdJDWBLqTjGfgn['policyKey']
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfgw,mrczXpUQCiVkyaFuSdJDWBLqTjGfgK
 def GetBroadURL(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn,mrczXpUQCiVkyaFuSdJDWBLqTjGfgI,mediatype):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfgA=''
  try:
   if mediatype=='live':
    mrczXpUQCiVkyaFuSdJDWBLqTjGfgI='ref%3A'+mrczXpUQCiVkyaFuSdJDWBLqTjGfgI
   else:
    mrczXpUQCiVkyaFuSdJDWBLqTjGfgI=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.GetReplay_UrlId(mrczXpUQCiVkyaFuSdJDWBLqTjGfgI)
    if mrczXpUQCiVkyaFuSdJDWBLqTjGfgI=='':return mrczXpUQCiVkyaFuSdJDWBLqTjGfgA
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.PLAYER_DOMAIN+'/playback/v1/accounts/'+mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_ACCOUNTID+'/videos/'+mrczXpUQCiVkyaFuSdJDWBLqTjGfgI
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgH={'accept':'application/json;pk='+mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.SPOTV_POLICYKEY}
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Get',mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfgH,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgE=json.loads(mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgA=mrczXpUQCiVkyaFuSdJDWBLqTjGfgE['sources'][0]['src']
   if mediatype=='live':
    mrczXpUQCiVkyaFuSdJDWBLqTjGfgA=mrczXpUQCiVkyaFuSdJDWBLqTjGfgA.replace('playlist.m3u8','playlist_dvr.m3u8')
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgA=mrczXpUQCiVkyaFuSdJDWBLqTjGfgA.replace('http://','https://')
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfgA
 def GetTitleGroupList(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhN=[]
  try:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.API_DOMAIN+'/api/v2/home/web'
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Get',mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNt=json.loads(mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text)
   for mrczXpUQCiVkyaFuSdJDWBLqTjGfhn in mrczXpUQCiVkyaFuSdJDWBLqTjGfNt:
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhK={}
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhK['mediatype']='episode'
    if mrczXpUQCiVkyaFuSdJDWBLqTjGfwo(mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['type'])=='3':
     mrczXpUQCiVkyaFuSdJDWBLqTjGfgl=''
     for mrczXpUQCiVkyaFuSdJDWBLqTjGfgM in mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['data']['list']:
      mrczXpUQCiVkyaFuSdJDWBLqTjGfgR='[%s] %s vs %s\n<%s>\n\n'%(mrczXpUQCiVkyaFuSdJDWBLqTjGfgM['gameDesc']['roundName'],mrczXpUQCiVkyaFuSdJDWBLqTjGfgM['gameDesc']['homeNameShort'],mrczXpUQCiVkyaFuSdJDWBLqTjGfgM['gameDesc']['awayNameShort'],mrczXpUQCiVkyaFuSdJDWBLqTjGfgM['gameDesc']['beginDate'])
      mrczXpUQCiVkyaFuSdJDWBLqTjGfgl+=mrczXpUQCiVkyaFuSdJDWBLqTjGfgR
     mrczXpUQCiVkyaFuSdJDWBLqTjGfhA={'title':mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['title'],'logo':mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['logo'],'reagueId':mrczXpUQCiVkyaFuSdJDWBLqTjGfwo(mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['destId']),'subGame':mrczXpUQCiVkyaFuSdJDWBLqTjGfgl,'info':mrczXpUQCiVkyaFuSdJDWBLqTjGfhK}
     mrczXpUQCiVkyaFuSdJDWBLqTjGfhN.append(mrczXpUQCiVkyaFuSdJDWBLqTjGfhA)
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfhN
 def GetSeasonList(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn,leagueid):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhN=[]
  mrczXpUQCiVkyaFuSdJDWBLqTjGfgY=mrczXpUQCiVkyaFuSdJDWBLqTjGfgv=''
  try:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.API_DOMAIN+'/api/v2/game/league/'+leagueid
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Get',mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNt=json.loads(mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgY=mrczXpUQCiVkyaFuSdJDWBLqTjGfNt['name']
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgv=mrczXpUQCiVkyaFuSdJDWBLqTjGfwo(mrczXpUQCiVkyaFuSdJDWBLqTjGfNt['gameTypeId'])
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
   return mrczXpUQCiVkyaFuSdJDWBLqTjGfhN
  try:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.API_DOMAIN+'/api/v2/season/'+leagueid
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Get',mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNt=json.loads(mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text)
   for mrczXpUQCiVkyaFuSdJDWBLqTjGfhn in mrczXpUQCiVkyaFuSdJDWBLqTjGfNt:
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhK={}
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhK['mediatype']='episode'
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhA={'reagueName':mrczXpUQCiVkyaFuSdJDWBLqTjGfgY,'gameTypeId':mrczXpUQCiVkyaFuSdJDWBLqTjGfgv,'seasonName':mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['name'],'seasonId':mrczXpUQCiVkyaFuSdJDWBLqTjGfwo(mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['id']),'info':mrczXpUQCiVkyaFuSdJDWBLqTjGfhK}
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhN.append(mrczXpUQCiVkyaFuSdJDWBLqTjGfhA)
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
   return[]
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfhN
 def GetGameList(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn,gameType,leagueId,seasonId,page_int):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfhN=[]
  mrczXpUQCiVkyaFuSdJDWBLqTjGfgo=mrczXpUQCiVkyaFuSdJDWBLqTjGfwY
  mrczXpUQCiVkyaFuSdJDWBLqTjGfgs=''
  try:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.API_DOMAIN+'/api/v2/vod/league/detail'
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgt={'gameType':gameType,'leagueId':leagueId,'seasonId':seasonId,'teamId':'','roundId':'','year':'','pageNo':mrczXpUQCiVkyaFuSdJDWBLqTjGfwo(page_int)}
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Get',mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfgt,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNt=json.loads(mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfge=mrczXpUQCiVkyaFuSdJDWBLqTjGfNt['list'][0]['list']
   for mrczXpUQCiVkyaFuSdJDWBLqTjGfhn in mrczXpUQCiVkyaFuSdJDWBLqTjGfge:
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhK={}
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhK['mediatype']='video'
    mrczXpUQCiVkyaFuSdJDWBLqTjGfgO ='%s vs %s'%(mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['gameDesc']['homeNameShort'],mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['gameDesc']['awayNameShort'])
    mrczXpUQCiVkyaFuSdJDWBLqTjGfgx =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['gameDesc']['beginDate']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfgP =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['gameDesc']['leagueNameFull']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfgb =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['gameDesc']['seasonName']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfwN =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['gameDesc']['roundName']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfwh =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['gameDesc']['homeName']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfwg =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['gameDesc']['awayName']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfwn =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['gameDesc']['homeScore']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfwK =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['gameDesc']['awayScore']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfwA ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(mrczXpUQCiVkyaFuSdJDWBLqTjGfgP,mrczXpUQCiVkyaFuSdJDWBLqTjGfgb,mrczXpUQCiVkyaFuSdJDWBLqTjGfwN,mrczXpUQCiVkyaFuSdJDWBLqTjGfgx,mrczXpUQCiVkyaFuSdJDWBLqTjGfwh,mrczXpUQCiVkyaFuSdJDWBLqTjGfwn,mrczXpUQCiVkyaFuSdJDWBLqTjGfwg,mrczXpUQCiVkyaFuSdJDWBLqTjGfwK)
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhK['plot']=mrczXpUQCiVkyaFuSdJDWBLqTjGfwA
    mrczXpUQCiVkyaFuSdJDWBLqTjGfwI =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['replayVod']['count']
    mrczXpUQCiVkyaFuSdJDWBLqTjGfwH=mrczXpUQCiVkyaFuSdJDWBLqTjGfgs='' 
    if mrczXpUQCiVkyaFuSdJDWBLqTjGfwI!=0:
     mrczXpUQCiVkyaFuSdJDWBLqTjGfwH =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['replayVod']['list'][0]['imgUrl']
     mrczXpUQCiVkyaFuSdJDWBLqTjGfgs =mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['replayVod']['list'][0]['id']
     mrczXpUQCiVkyaFuSdJDWBLqTjGfhK['duration']=mrczXpUQCiVkyaFuSdJDWBLqTjGfwe(mrczXpUQCiVkyaFuSdJDWBLqTjGfhn['replayVod']['list'][0]['duration']/1000)
    else:
     mrczXpUQCiVkyaFuSdJDWBLqTjGfgO+=' - 다시보기 없음'
     mrczXpUQCiVkyaFuSdJDWBLqTjGfhK['plot']+='\n\n ** 다시보기 없음 **'
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhA={'gameTitle':mrczXpUQCiVkyaFuSdJDWBLqTjGfgO,'replayId':mrczXpUQCiVkyaFuSdJDWBLqTjGfgs,'beginDate':mrczXpUQCiVkyaFuSdJDWBLqTjGfgx[:11],'thumbnail':mrczXpUQCiVkyaFuSdJDWBLqTjGfwH,'info':mrczXpUQCiVkyaFuSdJDWBLqTjGfhK,'leaguenm':mrczXpUQCiVkyaFuSdJDWBLqTjGfgP,'seasonnm':mrczXpUQCiVkyaFuSdJDWBLqTjGfgb,'roundnm':mrczXpUQCiVkyaFuSdJDWBLqTjGfwN}
    mrczXpUQCiVkyaFuSdJDWBLqTjGfhN.append(mrczXpUQCiVkyaFuSdJDWBLqTjGfhA)
   if mrczXpUQCiVkyaFuSdJDWBLqTjGfNt['list'][0]['count']>page_int*mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.GAMELIST_LIMIT:mrczXpUQCiVkyaFuSdJDWBLqTjGfgo=mrczXpUQCiVkyaFuSdJDWBLqTjGfws
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfhN,mrczXpUQCiVkyaFuSdJDWBLqTjGfgo
 def GetReplay_UrlId(mrczXpUQCiVkyaFuSdJDWBLqTjGfNn,mrczXpUQCiVkyaFuSdJDWBLqTjGfgs):
  mrczXpUQCiVkyaFuSdJDWBLqTjGfwE=mrczXpUQCiVkyaFuSdJDWBLqTjGfgI=''
  mrczXpUQCiVkyaFuSdJDWBLqTjGfwl=''
  try:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfhw=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.API_DOMAIN+'/api/v2/vod/'+mrczXpUQCiVkyaFuSdJDWBLqTjGfgs
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNv=mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.callRequestCookies('Get',mrczXpUQCiVkyaFuSdJDWBLqTjGfhw,payload=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,params=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,headers=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR,cookies=mrczXpUQCiVkyaFuSdJDWBLqTjGfwR)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfNt=json.loads(mrczXpUQCiVkyaFuSdJDWBLqTjGfNv.text)
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwE =mrczXpUQCiVkyaFuSdJDWBLqTjGfNt['clipId']
   mrczXpUQCiVkyaFuSdJDWBLqTjGfgI=mrczXpUQCiVkyaFuSdJDWBLqTjGfNt['videoId']
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwl=mrczXpUQCiVkyaFuSdJDWBLqTjGfwE
   if mrczXpUQCiVkyaFuSdJDWBLqTjGfNn.CheckSubEnd():mrczXpUQCiVkyaFuSdJDWBLqTjGfwl=mrczXpUQCiVkyaFuSdJDWBLqTjGfgI
  except mrczXpUQCiVkyaFuSdJDWBLqTjGfwt as exception:
   mrczXpUQCiVkyaFuSdJDWBLqTjGfwv(exception)
  return mrczXpUQCiVkyaFuSdJDWBLqTjGfwl
# Created by pyminifier (https://github.com/liftoff/pyminifier)
