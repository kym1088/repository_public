__author__="NightRain"
yQlrSeEYxtGUAmLJoVkBpPXjqaznMO=object
yQlrSeEYxtGUAmLJoVkBpPXjqaznMK=None
yQlrSeEYxtGUAmLJoVkBpPXjqaznMH=False
yQlrSeEYxtGUAmLJoVkBpPXjqaznMC=True
yQlrSeEYxtGUAmLJoVkBpPXjqaznMI=int
yQlrSeEYxtGUAmLJoVkBpPXjqaznMN=len
yQlrSeEYxtGUAmLJoVkBpPXjqaznMd=str
yQlrSeEYxtGUAmLJoVkBpPXjqazncf=open
yQlrSeEYxtGUAmLJoVkBpPXjqazncF=Exception
yQlrSeEYxtGUAmLJoVkBpPXjqazncw=print
yQlrSeEYxtGUAmLJoVkBpPXjqazncM=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
yQlrSeEYxtGUAmLJoVkBpPXjqaznfw=[{'title':'LIVE 채널','mode':'LIVE_GROUP','mediatype':'live'},{'title':'VOD 영상','mode':'VOD_GROUP','mediatype':'replay'},{'title':'-----------------','mode':'XXX','mediatype':'-'},{'title':'Watched (시청목록)','mode':'WATCH','mediatype':'replay'}]
yQlrSeEYxtGUAmLJoVkBpPXjqaznfM ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
yQlrSeEYxtGUAmLJoVkBpPXjqaznfc=xbmc.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class yQlrSeEYxtGUAmLJoVkBpPXjqaznfF(yQlrSeEYxtGUAmLJoVkBpPXjqaznMO):
 def __init__(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,yQlrSeEYxtGUAmLJoVkBpPXjqaznfW,yQlrSeEYxtGUAmLJoVkBpPXjqaznfu,yQlrSeEYxtGUAmLJoVkBpPXjqaznfh):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv._addon_url =yQlrSeEYxtGUAmLJoVkBpPXjqaznfW
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv._addon_handle=yQlrSeEYxtGUAmLJoVkBpPXjqaznfu
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.main_params =yQlrSeEYxtGUAmLJoVkBpPXjqaznfh
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj =mrczXpUQCiVkyaFuSdJDWBLqTjGfNh() 
 def addon_noti(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,sting):
  try:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfg=xbmcgui.Dialog()
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfg.notification(__addonname__,sting)
  except:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMK
 def addon_log(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,string,isDebug=yQlrSeEYxtGUAmLJoVkBpPXjqaznMH):
  try:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfi=string.encode('utf-8','ignore')
  except:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfi='addonException: addon_log'
  if isDebug:yQlrSeEYxtGUAmLJoVkBpPXjqaznfT=xbmc.LOGDEBUG
  else:yQlrSeEYxtGUAmLJoVkBpPXjqaznfT=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,yQlrSeEYxtGUAmLJoVkBpPXjqaznfi),level=yQlrSeEYxtGUAmLJoVkBpPXjqaznfT)
 def get_keyboard_input(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,yQlrSeEYxtGUAmLJoVkBpPXjqaznfC):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfs=yQlrSeEYxtGUAmLJoVkBpPXjqaznMK
  kb=xbmc.Keyboard()
  kb.setHeading(yQlrSeEYxtGUAmLJoVkBpPXjqaznfC)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfs=kb.getText()
  return yQlrSeEYxtGUAmLJoVkBpPXjqaznfs
 def get_settings_login_info(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfb =__addon__.getSetting('id')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfD =__addon__.getSetting('pw')
  return(yQlrSeEYxtGUAmLJoVkBpPXjqaznfb,yQlrSeEYxtGUAmLJoVkBpPXjqaznfD)
 def set_winCredential(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,credential):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO=xbmcgui.Window(10000)
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_LOGINTIME',yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO=xbmcgui.Window(10000)
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfK={'spotv_sessionid':yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.getProperty('SPOTV_M_SESSIONID'),'spotv_session':yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.getProperty('SPOTV_M_SESSION'),'spotv_accountId':yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.getProperty('SPOTV_M_SUBEND')}
  return yQlrSeEYxtGUAmLJoVkBpPXjqaznfK
 def add_dir(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,label,sublabel='',img='',infoLabels=yQlrSeEYxtGUAmLJoVkBpPXjqaznMK,isFolder=yQlrSeEYxtGUAmLJoVkBpPXjqaznMC,params=''):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfH='%s?%s'%(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv._addon_url,urllib.parse.urlencode(params))
  if sublabel:yQlrSeEYxtGUAmLJoVkBpPXjqaznfC='%s < %s >'%(label,sublabel)
  else: yQlrSeEYxtGUAmLJoVkBpPXjqaznfC=label
  if not img:img='DefaultFolder.png'
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfI=xbmcgui.ListItem(yQlrSeEYxtGUAmLJoVkBpPXjqaznfC)
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfI.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:yQlrSeEYxtGUAmLJoVkBpPXjqaznfI.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:yQlrSeEYxtGUAmLJoVkBpPXjqaznfI.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv._addon_handle,yQlrSeEYxtGUAmLJoVkBpPXjqaznfH,yQlrSeEYxtGUAmLJoVkBpPXjqaznfI,isFolder)
 def get_selQuality(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,etype):
  try:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfN='selected_quality'
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfd=[1080,720,540]
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFf=yQlrSeEYxtGUAmLJoVkBpPXjqaznMI(__addon__.getSetting(yQlrSeEYxtGUAmLJoVkBpPXjqaznfN))
   return yQlrSeEYxtGUAmLJoVkBpPXjqaznfd[yQlrSeEYxtGUAmLJoVkBpPXjqaznFf]
  except:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMK
  return 1080 
 def dp_Main_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv):
  for yQlrSeEYxtGUAmLJoVkBpPXjqaznFw in yQlrSeEYxtGUAmLJoVkBpPXjqaznfw:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfC=yQlrSeEYxtGUAmLJoVkBpPXjqaznFw.get('title')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFM={'mode':yQlrSeEYxtGUAmLJoVkBpPXjqaznFw.get('mode'),'mediatype':yQlrSeEYxtGUAmLJoVkBpPXjqaznFw.get('mediatype')}
   if yQlrSeEYxtGUAmLJoVkBpPXjqaznFw.get('mode')=='XXX':
    yQlrSeEYxtGUAmLJoVkBpPXjqaznFc=yQlrSeEYxtGUAmLJoVkBpPXjqaznMH
   else:
    yQlrSeEYxtGUAmLJoVkBpPXjqaznFc=yQlrSeEYxtGUAmLJoVkBpPXjqaznMC
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.add_dir(yQlrSeEYxtGUAmLJoVkBpPXjqaznfC,sublabel='',img='',infoLabels=yQlrSeEYxtGUAmLJoVkBpPXjqaznMK,isFolder=yQlrSeEYxtGUAmLJoVkBpPXjqaznFc,params=yQlrSeEYxtGUAmLJoVkBpPXjqaznFM)
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznMN(yQlrSeEYxtGUAmLJoVkBpPXjqaznfw)>0:xbmcplugin.endOfDirectory(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv._addon_handle)
 def dp_MainLeague_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,args):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.SaveCredential(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.get_winCredential())
  yQlrSeEYxtGUAmLJoVkBpPXjqaznFW=yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.GetTitleGroupList()
  for yQlrSeEYxtGUAmLJoVkBpPXjqaznFu in yQlrSeEYxtGUAmLJoVkBpPXjqaznFW:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfC =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('title')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFh =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('logo')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFR =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('reagueId')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFg =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('subGame')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFi=yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('info')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFi['plot']='%s\n\n%s'%(yQlrSeEYxtGUAmLJoVkBpPXjqaznfC,yQlrSeEYxtGUAmLJoVkBpPXjqaznFg)
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFM={'mode':'LEAGUE_GROUP','reagueId':yQlrSeEYxtGUAmLJoVkBpPXjqaznFR}
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.add_dir(yQlrSeEYxtGUAmLJoVkBpPXjqaznfC,sublabel=yQlrSeEYxtGUAmLJoVkBpPXjqaznMK,img=yQlrSeEYxtGUAmLJoVkBpPXjqaznFh,infoLabels=yQlrSeEYxtGUAmLJoVkBpPXjqaznFi,isFolder=yQlrSeEYxtGUAmLJoVkBpPXjqaznMC,params=yQlrSeEYxtGUAmLJoVkBpPXjqaznFM)
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznMN(yQlrSeEYxtGUAmLJoVkBpPXjqaznFW)>0:xbmcplugin.endOfDirectory(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv._addon_handle,cacheToDisc=yQlrSeEYxtGUAmLJoVkBpPXjqaznMH)
 def dp_Season_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,args):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.SaveCredential(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.get_winCredential())
  yQlrSeEYxtGUAmLJoVkBpPXjqaznFR=args.get('reagueId')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznFW=yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.GetSeasonList(yQlrSeEYxtGUAmLJoVkBpPXjqaznFR)
  for yQlrSeEYxtGUAmLJoVkBpPXjqaznFu in yQlrSeEYxtGUAmLJoVkBpPXjqaznFW:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFT =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('reagueName')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFs =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('gameTypeId')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFb =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('seasonName')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFD =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('seasonId')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFi=yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('info')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFi['plot']='%s - %s'%(yQlrSeEYxtGUAmLJoVkBpPXjqaznFT,yQlrSeEYxtGUAmLJoVkBpPXjqaznFb)
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFM={'mode':'SEASON_GROUP','reagueId':yQlrSeEYxtGUAmLJoVkBpPXjqaznFR,'seasonId':yQlrSeEYxtGUAmLJoVkBpPXjqaznFD,'gameTypeId':yQlrSeEYxtGUAmLJoVkBpPXjqaznFs,'page':'1'}
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.add_dir(yQlrSeEYxtGUAmLJoVkBpPXjqaznFT,sublabel=yQlrSeEYxtGUAmLJoVkBpPXjqaznFb,img='',infoLabels=yQlrSeEYxtGUAmLJoVkBpPXjqaznFi,isFolder=yQlrSeEYxtGUAmLJoVkBpPXjqaznMC,params=yQlrSeEYxtGUAmLJoVkBpPXjqaznFM)
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznMN(yQlrSeEYxtGUAmLJoVkBpPXjqaznFW)>0:xbmcplugin.endOfDirectory(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv._addon_handle,cacheToDisc=yQlrSeEYxtGUAmLJoVkBpPXjqaznMC)
 def dp_Game_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,args):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.SaveCredential(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.get_winCredential())
  yQlrSeEYxtGUAmLJoVkBpPXjqaznFs=args.get('gameTypeId')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznFR =args.get('reagueId')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznFD =args.get('seasonId')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznFO =yQlrSeEYxtGUAmLJoVkBpPXjqaznMI(args.get('page'))
  yQlrSeEYxtGUAmLJoVkBpPXjqaznFW,yQlrSeEYxtGUAmLJoVkBpPXjqaznFK=yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.GetGameList(yQlrSeEYxtGUAmLJoVkBpPXjqaznFs,yQlrSeEYxtGUAmLJoVkBpPXjqaznFR,yQlrSeEYxtGUAmLJoVkBpPXjqaznFD,yQlrSeEYxtGUAmLJoVkBpPXjqaznFO)
  for yQlrSeEYxtGUAmLJoVkBpPXjqaznFu in yQlrSeEYxtGUAmLJoVkBpPXjqaznFW:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFH =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('gameTitle')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFC =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('beginDate')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFh =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('thumbnail')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFI =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('replayId')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFN =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('leaguenm')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFd =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('seasonnm')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznwf =yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('roundnm')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznwF='[%s : %s] %s < %s >'%(yQlrSeEYxtGUAmLJoVkBpPXjqaznFN,yQlrSeEYxtGUAmLJoVkBpPXjqaznFd,yQlrSeEYxtGUAmLJoVkBpPXjqaznFH,yQlrSeEYxtGUAmLJoVkBpPXjqaznFC)
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFi=yQlrSeEYxtGUAmLJoVkBpPXjqaznFu.get('info')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFM={'mode':'GAME_VOD','title':yQlrSeEYxtGUAmLJoVkBpPXjqaznwF,'thumbnail':yQlrSeEYxtGUAmLJoVkBpPXjqaznFh,'mediacode':yQlrSeEYxtGUAmLJoVkBpPXjqaznFI,'mediatype':'replay','info_text':yQlrSeEYxtGUAmLJoVkBpPXjqaznFi['plot']}
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.add_dir(yQlrSeEYxtGUAmLJoVkBpPXjqaznFH,sublabel=yQlrSeEYxtGUAmLJoVkBpPXjqaznFC,img=yQlrSeEYxtGUAmLJoVkBpPXjqaznFh,infoLabels=yQlrSeEYxtGUAmLJoVkBpPXjqaznFi,isFolder=yQlrSeEYxtGUAmLJoVkBpPXjqaznMH,params=yQlrSeEYxtGUAmLJoVkBpPXjqaznFM)
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznFK:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFM['mode'] ='SEASON_GROUP' 
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFM['reagueId'] =yQlrSeEYxtGUAmLJoVkBpPXjqaznFR
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFM['seasonId'] =yQlrSeEYxtGUAmLJoVkBpPXjqaznFD
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFM['gameTypeId']=yQlrSeEYxtGUAmLJoVkBpPXjqaznFs
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFM['page'] =yQlrSeEYxtGUAmLJoVkBpPXjqaznMd(yQlrSeEYxtGUAmLJoVkBpPXjqaznFO+1)
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfC='[B]%s >>[/B]'%'다음 페이지'
   yQlrSeEYxtGUAmLJoVkBpPXjqaznwM=yQlrSeEYxtGUAmLJoVkBpPXjqaznMd(yQlrSeEYxtGUAmLJoVkBpPXjqaznFO+1)
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.add_dir(yQlrSeEYxtGUAmLJoVkBpPXjqaznfC,sublabel=yQlrSeEYxtGUAmLJoVkBpPXjqaznwM,img='',infoLabels=yQlrSeEYxtGUAmLJoVkBpPXjqaznMK,isFolder=yQlrSeEYxtGUAmLJoVkBpPXjqaznMC,params=yQlrSeEYxtGUAmLJoVkBpPXjqaznFM)
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznMN(yQlrSeEYxtGUAmLJoVkBpPXjqaznFW)>0:xbmcplugin.endOfDirectory(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv._addon_handle,cacheToDisc=yQlrSeEYxtGUAmLJoVkBpPXjqaznMH)
 def login_main(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv):
  (yQlrSeEYxtGUAmLJoVkBpPXjqaznwc,yQlrSeEYxtGUAmLJoVkBpPXjqaznwv)=yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.get_settings_login_info()
  if not(yQlrSeEYxtGUAmLJoVkBpPXjqaznwc and yQlrSeEYxtGUAmLJoVkBpPXjqaznwv):
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfg=xbmcgui.Dialog()
   yQlrSeEYxtGUAmLJoVkBpPXjqaznwW=yQlrSeEYxtGUAmLJoVkBpPXjqaznfg.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if yQlrSeEYxtGUAmLJoVkBpPXjqaznwW==yQlrSeEYxtGUAmLJoVkBpPXjqaznMC:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.cookiefile_check():return
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwu =yQlrSeEYxtGUAmLJoVkBpPXjqaznMI(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwh=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznwh==yQlrSeEYxtGUAmLJoVkBpPXjqaznMK or yQlrSeEYxtGUAmLJoVkBpPXjqaznwh=='':yQlrSeEYxtGUAmLJoVkBpPXjqaznwh=yQlrSeEYxtGUAmLJoVkBpPXjqaznMI('19000101')
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   yQlrSeEYxtGUAmLJoVkBpPXjqaznwR=0
   while yQlrSeEYxtGUAmLJoVkBpPXjqaznMC:
    yQlrSeEYxtGUAmLJoVkBpPXjqaznwR+=1
    time.sleep(0.05)
    if yQlrSeEYxtGUAmLJoVkBpPXjqaznwh>=yQlrSeEYxtGUAmLJoVkBpPXjqaznwu:return
    if yQlrSeEYxtGUAmLJoVkBpPXjqaznwR>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznwh>=yQlrSeEYxtGUAmLJoVkBpPXjqaznwu:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.GetCredential(yQlrSeEYxtGUAmLJoVkBpPXjqaznwc,yQlrSeEYxtGUAmLJoVkBpPXjqaznwv):
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.set_winCredential(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.LoadCredential())
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,args):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.SaveCredential(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.get_winCredential())
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwg=yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.GetLiveChannelList()
  for yQlrSeEYxtGUAmLJoVkBpPXjqaznwi in yQlrSeEYxtGUAmLJoVkBpPXjqaznwg:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfC =yQlrSeEYxtGUAmLJoVkBpPXjqaznwi.get('name')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFv =yQlrSeEYxtGUAmLJoVkBpPXjqaznwi.get('programName')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFh =yQlrSeEYxtGUAmLJoVkBpPXjqaznwi.get('logo')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznwT=yQlrSeEYxtGUAmLJoVkBpPXjqaznwi.get('channelepg')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznws =yQlrSeEYxtGUAmLJoVkBpPXjqaznwi.get('free')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFi=yQlrSeEYxtGUAmLJoVkBpPXjqaznwi.get('info')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFi['plot']='%s'%(yQlrSeEYxtGUAmLJoVkBpPXjqaznwT)
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFM={'mode':'LIVE','mediaid':yQlrSeEYxtGUAmLJoVkBpPXjqaznwi.get('id'),'mediacode':yQlrSeEYxtGUAmLJoVkBpPXjqaznwi.get('videoId'),'free':yQlrSeEYxtGUAmLJoVkBpPXjqaznws,'mediatype':'live'}
   if yQlrSeEYxtGUAmLJoVkBpPXjqaznws:yQlrSeEYxtGUAmLJoVkBpPXjqaznfC+=' [free]'
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.add_dir(yQlrSeEYxtGUAmLJoVkBpPXjqaznfC,sublabel=yQlrSeEYxtGUAmLJoVkBpPXjqaznFv,img=yQlrSeEYxtGUAmLJoVkBpPXjqaznFh,infoLabels=yQlrSeEYxtGUAmLJoVkBpPXjqaznFi,isFolder=yQlrSeEYxtGUAmLJoVkBpPXjqaznMH,params=yQlrSeEYxtGUAmLJoVkBpPXjqaznFM)
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznMN(yQlrSeEYxtGUAmLJoVkBpPXjqaznwg)>0:xbmcplugin.endOfDirectory(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv._addon_handle,cacheToDisc=yQlrSeEYxtGUAmLJoVkBpPXjqaznMH)
 def play_VIDEO(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,args):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.SaveCredential(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.get_winCredential())
  if args.get('free')=='False':
   if yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.CheckSubEnd()==yQlrSeEYxtGUAmLJoVkBpPXjqaznMH:
    yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.addon_noti(__language__(30908).encode('utf8'))
    return
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwb =args.get('mediacode')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwD =args.get('mediatype')
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznwb=='' or yQlrSeEYxtGUAmLJoVkBpPXjqaznwb==yQlrSeEYxtGUAmLJoVkBpPXjqaznMK:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.addon_noti(__language__(30907).encode('utf8'))
   return
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwO=yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.GetBroadURL(yQlrSeEYxtGUAmLJoVkBpPXjqaznwb,yQlrSeEYxtGUAmLJoVkBpPXjqaznwD)
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznwO=='':
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.addon_noti(__language__(30908).encode('utf8'))
   return
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwK=yQlrSeEYxtGUAmLJoVkBpPXjqaznwO
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.addon_log(yQlrSeEYxtGUAmLJoVkBpPXjqaznwK,yQlrSeEYxtGUAmLJoVkBpPXjqaznMH)
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwH=xbmcgui.ListItem(path=yQlrSeEYxtGUAmLJoVkBpPXjqaznwK)
  xbmcplugin.setResolvedUrl(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv._addon_handle,yQlrSeEYxtGUAmLJoVkBpPXjqaznMC,yQlrSeEYxtGUAmLJoVkBpPXjqaznwH)
  try:
   if yQlrSeEYxtGUAmLJoVkBpPXjqaznwD=='replay':
    yQlrSeEYxtGUAmLJoVkBpPXjqaznFM={'code':args.get('mediacode'),'img':args.get('thumbnail'),'title':args.get('title'),'info_text':args.get('info_text')}
    yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.Save_Watched_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznwD,yQlrSeEYxtGUAmLJoVkBpPXjqaznFM)
  except:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMK
 def logout(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfg=xbmcgui.Dialog()
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwW=yQlrSeEYxtGUAmLJoVkBpPXjqaznfg.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznwW==yQlrSeEYxtGUAmLJoVkBpPXjqaznMH:sys.exit()
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.wininfo_clear()
  if os.path.isfile(yQlrSeEYxtGUAmLJoVkBpPXjqaznfc):os.remove(yQlrSeEYxtGUAmLJoVkBpPXjqaznfc)
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO=xbmcgui.Window(10000)
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_SESSIONID','')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_SESSION','')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_ACCOUNTID','')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_POLICYKEY','')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_SUBEND','')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwC =yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.Get_Now_Datetime()
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwI=yQlrSeEYxtGUAmLJoVkBpPXjqaznwC+datetime.timedelta(days=yQlrSeEYxtGUAmLJoVkBpPXjqaznMI(__addon__.getSetting('cache_ttl')))
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO=xbmcgui.Window(10000)
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwN={'spotv_sessionid':yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.getProperty('SPOTV_M_SESSIONID'),'spotv_session':yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.getProperty('SPOTV_M_SESSION'),'spotv_accountId':yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.SPOTV_PMCODE+yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':yQlrSeEYxtGUAmLJoVkBpPXjqaznwI.strftime('%Y-%m-%d')}
  try: 
   fp=yQlrSeEYxtGUAmLJoVkBpPXjqazncf(yQlrSeEYxtGUAmLJoVkBpPXjqaznfc,'w',-1,'utf-8')
   json.dump(yQlrSeEYxtGUAmLJoVkBpPXjqaznwN,fp)
   fp.close()
  except yQlrSeEYxtGUAmLJoVkBpPXjqazncF as exception:
   yQlrSeEYxtGUAmLJoVkBpPXjqazncw(exception)
 def cookiefile_check(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwN={}
  try: 
   fp=yQlrSeEYxtGUAmLJoVkBpPXjqazncf(yQlrSeEYxtGUAmLJoVkBpPXjqaznfc,'r',-1,'utf-8')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznwN= json.load(fp)
   fp.close()
  except yQlrSeEYxtGUAmLJoVkBpPXjqazncF as exception:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.wininfo_clear()
   return yQlrSeEYxtGUAmLJoVkBpPXjqaznMH
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwc =__addon__.getSetting('id')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwv =__addon__.getSetting('pw')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_id'] =base64.standard_b64decode(yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_id']).decode('utf-8')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_pw'] =base64.standard_b64decode(yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_pw']).decode('utf-8')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_policyKey']=base64.standard_b64decode(yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_policyKey']).decode('utf-8')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_subend']=base64.standard_b64decode(yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_subend']).decode('utf-8')[yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.SPOTV_PMSIZE:]
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznwc!=yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_id']or yQlrSeEYxtGUAmLJoVkBpPXjqaznwv!=yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_pw']:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.wininfo_clear()
   return yQlrSeEYxtGUAmLJoVkBpPXjqaznMH
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwu =yQlrSeEYxtGUAmLJoVkBpPXjqaznMI(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwd=yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_limitdate']
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwh =yQlrSeEYxtGUAmLJoVkBpPXjqaznMI(re.sub('-','',yQlrSeEYxtGUAmLJoVkBpPXjqaznwd))
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznwh<yQlrSeEYxtGUAmLJoVkBpPXjqaznwu:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.wininfo_clear()
   return yQlrSeEYxtGUAmLJoVkBpPXjqaznMH
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO=xbmcgui.Window(10000)
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_SESSIONID',yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_sessionid'])
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_SESSION',yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_session'])
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_ACCOUNTID',yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_accountId'])
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_POLICYKEY',yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_policyKey'])
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_SUBEND',yQlrSeEYxtGUAmLJoVkBpPXjqaznwN['spotv_subend'])
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfO.setProperty('SPOTV_M_LOGINTIME',yQlrSeEYxtGUAmLJoVkBpPXjqaznwd)
  return yQlrSeEYxtGUAmLJoVkBpPXjqaznMC
 def dp_WatchList_Delete(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,args):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwD=args.get('mediatype')
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfg=xbmcgui.Dialog()
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwW=yQlrSeEYxtGUAmLJoVkBpPXjqaznfg.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznwW==yQlrSeEYxtGUAmLJoVkBpPXjqaznMH:sys.exit()
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.Delete_Watched_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznwD)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,yQlrSeEYxtGUAmLJoVkBpPXjqaznwD):
  try:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMf=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%yQlrSeEYxtGUAmLJoVkBpPXjqaznwD))
   fp=yQlrSeEYxtGUAmLJoVkBpPXjqazncf(yQlrSeEYxtGUAmLJoVkBpPXjqaznMf,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMK
 def Load_Watched_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,yQlrSeEYxtGUAmLJoVkBpPXjqaznwD):
  try:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMf=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%yQlrSeEYxtGUAmLJoVkBpPXjqaznwD))
   fp=yQlrSeEYxtGUAmLJoVkBpPXjqazncf(yQlrSeEYxtGUAmLJoVkBpPXjqaznMf,'r',-1,'utf-8')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMF=fp.readlines()
   fp.close()
  except:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMF=[]
  return yQlrSeEYxtGUAmLJoVkBpPXjqaznMF
 def Save_Watched_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,stype,yQlrSeEYxtGUAmLJoVkBpPXjqaznfh):
  try:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMf=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMw=yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.Load_Watched_List(stype) 
   fp=yQlrSeEYxtGUAmLJoVkBpPXjqazncf(yQlrSeEYxtGUAmLJoVkBpPXjqaznMf,'w',-1,'utf-8')
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMc=urllib.parse.urlencode(yQlrSeEYxtGUAmLJoVkBpPXjqaznfh)
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMc=yQlrSeEYxtGUAmLJoVkBpPXjqaznMc+'\n'
   fp.write(yQlrSeEYxtGUAmLJoVkBpPXjqaznMc)
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMv=0
   for yQlrSeEYxtGUAmLJoVkBpPXjqaznMW in yQlrSeEYxtGUAmLJoVkBpPXjqaznMw:
    yQlrSeEYxtGUAmLJoVkBpPXjqaznMu=yQlrSeEYxtGUAmLJoVkBpPXjqazncM(urllib.parse.parse_qsl(yQlrSeEYxtGUAmLJoVkBpPXjqaznMW))
    yQlrSeEYxtGUAmLJoVkBpPXjqaznMh=yQlrSeEYxtGUAmLJoVkBpPXjqaznfh.get('code')
    yQlrSeEYxtGUAmLJoVkBpPXjqaznMR=yQlrSeEYxtGUAmLJoVkBpPXjqaznMu.get('code')
    if yQlrSeEYxtGUAmLJoVkBpPXjqaznMh!=yQlrSeEYxtGUAmLJoVkBpPXjqaznMR:
     fp.write(yQlrSeEYxtGUAmLJoVkBpPXjqaznMW)
     yQlrSeEYxtGUAmLJoVkBpPXjqaznMv+=1
     if yQlrSeEYxtGUAmLJoVkBpPXjqaznMv>=50:break
   fp.close()
  except:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMK
 def dp_Watch_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv,args):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznwD =args.get('mediatype')
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznwD=='replay':
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMg=yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.Load_Watched_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznwD)
   for yQlrSeEYxtGUAmLJoVkBpPXjqaznMi in yQlrSeEYxtGUAmLJoVkBpPXjqaznMg:
    yQlrSeEYxtGUAmLJoVkBpPXjqaznMT=yQlrSeEYxtGUAmLJoVkBpPXjqazncM(urllib.parse.parse_qsl(yQlrSeEYxtGUAmLJoVkBpPXjqaznMi))
    yQlrSeEYxtGUAmLJoVkBpPXjqaznfC =yQlrSeEYxtGUAmLJoVkBpPXjqaznMT.get('title')
    yQlrSeEYxtGUAmLJoVkBpPXjqaznFh=yQlrSeEYxtGUAmLJoVkBpPXjqaznMT.get('img')
    yQlrSeEYxtGUAmLJoVkBpPXjqaznwb=yQlrSeEYxtGUAmLJoVkBpPXjqaznMT.get('code')
    yQlrSeEYxtGUAmLJoVkBpPXjqaznMs=yQlrSeEYxtGUAmLJoVkBpPXjqaznMT.get('info_text')
    yQlrSeEYxtGUAmLJoVkBpPXjqaznFi={}
    if yQlrSeEYxtGUAmLJoVkBpPXjqaznMs==yQlrSeEYxtGUAmLJoVkBpPXjqaznMK or yQlrSeEYxtGUAmLJoVkBpPXjqaznMs=='':
     yQlrSeEYxtGUAmLJoVkBpPXjqaznFi['plot']=yQlrSeEYxtGUAmLJoVkBpPXjqaznfC
    else:
     yQlrSeEYxtGUAmLJoVkBpPXjqaznFi['plot']=yQlrSeEYxtGUAmLJoVkBpPXjqaznMs
    yQlrSeEYxtGUAmLJoVkBpPXjqaznFM={'mode':'GAME_VOD','mediacode':yQlrSeEYxtGUAmLJoVkBpPXjqaznwb,'title':yQlrSeEYxtGUAmLJoVkBpPXjqaznfC,'thumbnail':yQlrSeEYxtGUAmLJoVkBpPXjqaznFh,'mediatype':yQlrSeEYxtGUAmLJoVkBpPXjqaznwD,'info_text':yQlrSeEYxtGUAmLJoVkBpPXjqaznFi['plot']}
    yQlrSeEYxtGUAmLJoVkBpPXjqaznFc=yQlrSeEYxtGUAmLJoVkBpPXjqaznMH
    yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.add_dir(yQlrSeEYxtGUAmLJoVkBpPXjqaznfC,sublabel='',img=yQlrSeEYxtGUAmLJoVkBpPXjqaznFh,infoLabels=yQlrSeEYxtGUAmLJoVkBpPXjqaznFi,isFolder=yQlrSeEYxtGUAmLJoVkBpPXjqaznFc,params=yQlrSeEYxtGUAmLJoVkBpPXjqaznFM)
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFi={'plot':'시청목록을 삭제합니다.'}
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfC='*** 시청목록 삭제 ***'
   yQlrSeEYxtGUAmLJoVkBpPXjqaznFM={'mode':'MYVIEW_REMOVE','mediatype':'replay'}
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.add_dir(yQlrSeEYxtGUAmLJoVkBpPXjqaznfC,sublabel='',img='',infoLabels=yQlrSeEYxtGUAmLJoVkBpPXjqaznFi,isFolder=yQlrSeEYxtGUAmLJoVkBpPXjqaznMH,params=yQlrSeEYxtGUAmLJoVkBpPXjqaznFM)
   xbmcplugin.endOfDirectory(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv._addon_handle,cacheToDisc=yQlrSeEYxtGUAmLJoVkBpPXjqaznMH)
 def spotv_main(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv):
  yQlrSeEYxtGUAmLJoVkBpPXjqaznMD=yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.main_params.get('mode',yQlrSeEYxtGUAmLJoVkBpPXjqaznMK)
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznMD=='LOGOUT':
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.logout()
   return
  yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.login_main()
  if yQlrSeEYxtGUAmLJoVkBpPXjqaznMD is yQlrSeEYxtGUAmLJoVkBpPXjqaznMK:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.dp_Main_List()
  elif yQlrSeEYxtGUAmLJoVkBpPXjqaznMD=='LIVE_GROUP':
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.dp_LiveChannel_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.main_params)
  elif yQlrSeEYxtGUAmLJoVkBpPXjqaznMD in['LIVE','GAME_VOD']:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.play_VIDEO(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.main_params)
  elif yQlrSeEYxtGUAmLJoVkBpPXjqaznMD=='VOD_GROUP':
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.dp_MainLeague_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.main_params)
  elif yQlrSeEYxtGUAmLJoVkBpPXjqaznMD=='LEAGUE_GROUP':
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.dp_Season_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.main_params)
  elif yQlrSeEYxtGUAmLJoVkBpPXjqaznMD=='SEASON_GROUP':
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.dp_Game_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.main_params)
  elif yQlrSeEYxtGUAmLJoVkBpPXjqaznMD=='WATCH':
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.dp_Watch_List(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.main_params)
  elif yQlrSeEYxtGUAmLJoVkBpPXjqaznMD=='MYVIEW_REMOVE':
   yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.dp_WatchList_Delete(yQlrSeEYxtGUAmLJoVkBpPXjqaznfv.main_params)
  else:
   yQlrSeEYxtGUAmLJoVkBpPXjqaznMK
# Created by pyminifier (https://github.com/liftoff/pyminifier)
