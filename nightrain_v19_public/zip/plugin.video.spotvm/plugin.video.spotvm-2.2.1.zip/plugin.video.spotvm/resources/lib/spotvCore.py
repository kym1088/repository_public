__author__="NightRain"
xXvpLcVArtGUFSCKNafRojnlqWYuBb=object
xXvpLcVArtGUFSCKNafRojnlqWYuBy=None
xXvpLcVArtGUFSCKNafRojnlqWYuBh=False
xXvpLcVArtGUFSCKNafRojnlqWYuBe=open
xXvpLcVArtGUFSCKNafRojnlqWYuBD=True
xXvpLcVArtGUFSCKNafRojnlqWYuBQ=str
xXvpLcVArtGUFSCKNafRojnlqWYuBO=Exception
xXvpLcVArtGUFSCKNafRojnlqWYuBk=print
xXvpLcVArtGUFSCKNafRojnlqWYuBH=int
xXvpLcVArtGUFSCKNafRojnlqWYuBT=len
xXvpLcVArtGUFSCKNafRojnlqWYuBs=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
xXvpLcVArtGUFSCKNafRojnlqWYuzM={'stream50':1080,'stream40':720,'stream30':540}
class xXvpLcVArtGUFSCKNafRojnlqWYuzw(xXvpLcVArtGUFSCKNafRojnlqWYuBb):
 def __init__(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.SPOTV_PMCODE ='987'
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.SPOTV_PMSIZE =3
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.GAMELIST_LIMIT =10
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN ='https://www.spotvnow.co.kr'
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.BC_DOMAIN ='https://players.brightcove.net'
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.DEFAULT_HEADER ={'user-agent':xXvpLcVArtGUFSCKNafRojnlqWYuzg.USER_AGENT}
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST ={}
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.Init_ST_Total()
 def Init_ST_Total(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST={'account':{},'cookies':{'spotv_sessionid':'','spotv_session':'','spotv_accountId':'','spotv_policyKey':'','spotv_subend':'',},}
 def callRequestCookies(xXvpLcVArtGUFSCKNafRojnlqWYuzg,jobtype,xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy,redirects=xXvpLcVArtGUFSCKNafRojnlqWYuBh):
  xXvpLcVArtGUFSCKNafRojnlqWYuzB=xXvpLcVArtGUFSCKNafRojnlqWYuzg.DEFAULT_HEADER
  if headers:xXvpLcVArtGUFSCKNafRojnlqWYuzB.update(headers)
  if jobtype=='Get':
   xXvpLcVArtGUFSCKNafRojnlqWYuzd=requests.get(xXvpLcVArtGUFSCKNafRojnlqWYuzs,params=params,headers=xXvpLcVArtGUFSCKNafRojnlqWYuzB,cookies=cookies,allow_redirects=redirects)
  else:
   xXvpLcVArtGUFSCKNafRojnlqWYuzd=requests.post(xXvpLcVArtGUFSCKNafRojnlqWYuzs,data=payload,params=params,headers=xXvpLcVArtGUFSCKNafRojnlqWYuzB,cookies=cookies,allow_redirects=redirects)
  return xXvpLcVArtGUFSCKNafRojnlqWYuzd
 def JsonFile_Save(xXvpLcVArtGUFSCKNafRojnlqWYuzg,filename,xXvpLcVArtGUFSCKNafRojnlqWYuzJ):
  if filename=='':return xXvpLcVArtGUFSCKNafRojnlqWYuBh
  try:
   fp=xXvpLcVArtGUFSCKNafRojnlqWYuBe(filename,'w',-1,'utf-8')
   json.dump(xXvpLcVArtGUFSCKNafRojnlqWYuzJ,fp,indent=4,ensure_ascii=xXvpLcVArtGUFSCKNafRojnlqWYuBh)
   fp.close()
  except:
   return xXvpLcVArtGUFSCKNafRojnlqWYuBh
  return xXvpLcVArtGUFSCKNafRojnlqWYuBD
 def JsonFile_Load(xXvpLcVArtGUFSCKNafRojnlqWYuzg,filename):
  if filename=='':return{}
  try:
   fp=xXvpLcVArtGUFSCKNafRojnlqWYuBe(filename,'r',-1,'utf-8')
   xXvpLcVArtGUFSCKNafRojnlqWYuzm=json.load(fp)
   fp.close()
  except:
   return{}
  return xXvpLcVArtGUFSCKNafRojnlqWYuzm
 def Save_session_acount(xXvpLcVArtGUFSCKNafRojnlqWYuzg,xXvpLcVArtGUFSCKNafRojnlqWYuzI,xXvpLcVArtGUFSCKNafRojnlqWYuzi):
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['account']['stid'] =base64.standard_b64encode(xXvpLcVArtGUFSCKNafRojnlqWYuzI.encode()).decode('utf-8')
  xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['account']['stpw'] =base64.standard_b64encode(xXvpLcVArtGUFSCKNafRojnlqWYuzi.encode()).decode('utf-8')
 def Load_session_acount(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzI =base64.standard_b64decode(xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['account']['stid']).decode('utf-8')
   xXvpLcVArtGUFSCKNafRojnlqWYuzi =base64.standard_b64decode(xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['account']['stpw']).decode('utf-8')
  except:
   return '',''
  return xXvpLcVArtGUFSCKNafRojnlqWYuzI,xXvpLcVArtGUFSCKNafRojnlqWYuzi
 def makeDefaultCookies(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuzE={'SESSION':xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['cookies']['spotv_session']}
  return xXvpLcVArtGUFSCKNafRojnlqWYuzE
 def makeDefaultHeaders(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuzb={'accept':'application/json;pk={}'.format(xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['cookies']['spotv_policyKey'])}
  return xXvpLcVArtGUFSCKNafRojnlqWYuzb
 def xmlText(xXvpLcVArtGUFSCKNafRojnlqWYuzg,in_text):
  xXvpLcVArtGUFSCKNafRojnlqWYuzy=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return xXvpLcVArtGUFSCKNafRojnlqWYuzy
 def GetCredential(xXvpLcVArtGUFSCKNafRojnlqWYuzg,user_id,user_pw):
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzh=base64.standard_b64encode(user_id.encode('UTF-8')).decode('utf-8')
   xXvpLcVArtGUFSCKNafRojnlqWYuze=base64.standard_b64encode(user_pw.encode('UTF-8')).decode('utf-8')
   xXvpLcVArtGUFSCKNafRojnlqWYuzD=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/login'
   xXvpLcVArtGUFSCKNafRojnlqWYuzQ={'username':xXvpLcVArtGUFSCKNafRojnlqWYuzh,'password':xXvpLcVArtGUFSCKNafRojnlqWYuze}
   xXvpLcVArtGUFSCKNafRojnlqWYuzQ=json.dumps(xXvpLcVArtGUFSCKNafRojnlqWYuzQ)
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Post',xXvpLcVArtGUFSCKNafRojnlqWYuzD,payload=xXvpLcVArtGUFSCKNafRojnlqWYuzQ,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   for xXvpLcVArtGUFSCKNafRojnlqWYuzH in xXvpLcVArtGUFSCKNafRojnlqWYuzO.cookies:
    if xXvpLcVArtGUFSCKNafRojnlqWYuzH.name=='SESSION':
     xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['cookies']['spotv_session']=xXvpLcVArtGUFSCKNafRojnlqWYuzH.value
     break
   if xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['cookies']['spotv_session']=='':
    xXvpLcVArtGUFSCKNafRojnlqWYuzg.Init_ST_Total()
    return xXvpLcVArtGUFSCKNafRojnlqWYuBh
   xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['cookies']['spotv_sessionid']=xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuzk['userId'])
   xXvpLcVArtGUFSCKNafRojnlqWYuzT=xXvpLcVArtGUFSCKNafRojnlqWYuzg.SPOTV_PMCODE+xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuzk['subEndTime'])
   xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['cookies']['spotv_subend'] =base64.standard_b64encode(xXvpLcVArtGUFSCKNafRojnlqWYuzT.encode()).decode('utf-8')
   if xXvpLcVArtGUFSCKNafRojnlqWYuzg.GetPolicyKey()==xXvpLcVArtGUFSCKNafRojnlqWYuBh:
    xXvpLcVArtGUFSCKNafRojnlqWYuzg.Init_ST_Total()
    return xXvpLcVArtGUFSCKNafRojnlqWYuBh
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
   xXvpLcVArtGUFSCKNafRojnlqWYuzg.Init_ST_Total()
   return xXvpLcVArtGUFSCKNafRojnlqWYuBh
  return xXvpLcVArtGUFSCKNafRojnlqWYuBD
 def GetPolicyKey(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.GetBcPlayerUrl()
   if xXvpLcVArtGUFSCKNafRojnlqWYuzs=='':return xXvpLcVArtGUFSCKNafRojnlqWYuBh
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuwz=xXvpLcVArtGUFSCKNafRojnlqWYuzO.text
   xXvpLcVArtGUFSCKNafRojnlqWYuwM =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',xXvpLcVArtGUFSCKNafRojnlqWYuwz)[0]
   xXvpLcVArtGUFSCKNafRojnlqWYuwM =xXvpLcVArtGUFSCKNafRojnlqWYuwM.replace('accountId','"accountId"')
   xXvpLcVArtGUFSCKNafRojnlqWYuwM =xXvpLcVArtGUFSCKNafRojnlqWYuwM.replace('policyKey','"policyKey"')
   xXvpLcVArtGUFSCKNafRojnlqWYuwM ='{'+xXvpLcVArtGUFSCKNafRojnlqWYuwM+'}'
   xXvpLcVArtGUFSCKNafRojnlqWYuwg=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuwM)
   xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['cookies']['spotv_accountId']=xXvpLcVArtGUFSCKNafRojnlqWYuwg['accountId']
   xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['cookies']['spotv_policyKey']=xXvpLcVArtGUFSCKNafRojnlqWYuwg['policyKey']
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
   return xXvpLcVArtGUFSCKNafRojnlqWYuBh
  return xXvpLcVArtGUFSCKNafRojnlqWYuBD
 def GetBcPlayerUrl(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuwB=''
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.GetMainJspath()
   if xXvpLcVArtGUFSCKNafRojnlqWYuzs=='':return xXvpLcVArtGUFSCKNafRojnlqWYuwB
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuwz=xXvpLcVArtGUFSCKNafRojnlqWYuzO.text
   xXvpLcVArtGUFSCKNafRojnlqWYuwd =r'default:{(.*?)}'
   xXvpLcVArtGUFSCKNafRojnlqWYuwJ =re.compile(xXvpLcVArtGUFSCKNafRojnlqWYuwd).findall(xXvpLcVArtGUFSCKNafRojnlqWYuwz)[0]
   xXvpLcVArtGUFSCKNafRojnlqWYuwP=r'bc:"(.*?)"'
   xXvpLcVArtGUFSCKNafRojnlqWYuwm=re.compile(xXvpLcVArtGUFSCKNafRojnlqWYuwP).findall(xXvpLcVArtGUFSCKNafRojnlqWYuwJ)[0]
   xXvpLcVArtGUFSCKNafRojnlqWYuwI=r'":"(.*?)"'
   xXvpLcVArtGUFSCKNafRojnlqWYuwi=re.compile(xXvpLcVArtGUFSCKNafRojnlqWYuwI).findall(xXvpLcVArtGUFSCKNafRojnlqWYuwJ)[0]
   xXvpLcVArtGUFSCKNafRojnlqWYuwB="%s/%s/%s_default/index.min.js"%(xXvpLcVArtGUFSCKNafRojnlqWYuzg.BC_DOMAIN,xXvpLcVArtGUFSCKNafRojnlqWYuwm,xXvpLcVArtGUFSCKNafRojnlqWYuwi)
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuwB
 def GetMainJspath(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuwE=''
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuwz=xXvpLcVArtGUFSCKNafRojnlqWYuzO.text
   xXvpLcVArtGUFSCKNafRojnlqWYuwM =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',xXvpLcVArtGUFSCKNafRojnlqWYuwz)[0]
   xXvpLcVArtGUFSCKNafRojnlqWYuwE=xXvpLcVArtGUFSCKNafRojnlqWYuwM
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuwE
 def Get_Now_Datetime(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuwy=[]
  xXvpLcVArtGUFSCKNafRojnlqWYuwh ={}
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/channel'
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   xXvpLcVArtGUFSCKNafRojnlqWYuwh=xXvpLcVArtGUFSCKNafRojnlqWYuzg.GetEPGList()
   for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuzk:
    xXvpLcVArtGUFSCKNafRojnlqWYuwD={'id':xXvpLcVArtGUFSCKNafRojnlqWYuwe['id'],'name':xXvpLcVArtGUFSCKNafRojnlqWYuwe['name'],'logo':xXvpLcVArtGUFSCKNafRojnlqWYuwe['logo'],'free':xXvpLcVArtGUFSCKNafRojnlqWYuwe['free'],'programName':xXvpLcVArtGUFSCKNafRojnlqWYuwe['programName'],'channelepg':xXvpLcVArtGUFSCKNafRojnlqWYuwh.get(xXvpLcVArtGUFSCKNafRojnlqWYuwe['id']),'hlsUrl':xXvpLcVArtGUFSCKNafRojnlqWYuwe['hlsUrl'],}
    xXvpLcVArtGUFSCKNafRojnlqWYuwy.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuwy
 def GetHlsUrl(xXvpLcVArtGUFSCKNafRojnlqWYuzg,mediacode):
  xXvpLcVArtGUFSCKNafRojnlqWYuwQ=''
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/channel'
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuzk:
    if xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuwe['id'])==xXvpLcVArtGUFSCKNafRojnlqWYuBQ(mediacode):
     xXvpLcVArtGUFSCKNafRojnlqWYuwQ=xXvpLcVArtGUFSCKNafRojnlqWYuwe['hlsUrl']
     break
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuwQ
 def GetEPGList(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuwO={}
  xXvpLcVArtGUFSCKNafRojnlqWYuwk=xXvpLcVArtGUFSCKNafRojnlqWYuzg.Get_Now_Datetime()
  xXvpLcVArtGUFSCKNafRojnlqWYuwH=xXvpLcVArtGUFSCKNafRojnlqWYuwk.strftime('%Y%m%d%H%M')
  xXvpLcVArtGUFSCKNafRojnlqWYuwT='%s-%s-%s'%(xXvpLcVArtGUFSCKNafRojnlqWYuwH[0:4],xXvpLcVArtGUFSCKNafRojnlqWYuwH[4:6],xXvpLcVArtGUFSCKNafRojnlqWYuwH[6:8])
  xXvpLcVArtGUFSCKNafRojnlqWYuws=(xXvpLcVArtGUFSCKNafRojnlqWYuwk+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/program/'+xXvpLcVArtGUFSCKNafRojnlqWYuwT
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   xXvpLcVArtGUFSCKNafRojnlqWYuMz=-1 
   xXvpLcVArtGUFSCKNafRojnlqWYuMw =''
   for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuzk:
    xXvpLcVArtGUFSCKNafRojnlqWYuMg=xXvpLcVArtGUFSCKNafRojnlqWYuwe['channelId']
    xXvpLcVArtGUFSCKNafRojnlqWYuMB =xXvpLcVArtGUFSCKNafRojnlqWYuwe['startTime'].replace('-','').replace(' ','').replace(':','')
    xXvpLcVArtGUFSCKNafRojnlqWYuMd =xXvpLcVArtGUFSCKNafRojnlqWYuwe['endTime'].replace('-','').replace(' ','').replace(':','')
    if xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuwH)>xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuMd) :continue
    if xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuws)<xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuMB):continue
    if xXvpLcVArtGUFSCKNafRojnlqWYuMz!=xXvpLcVArtGUFSCKNafRojnlqWYuMg:
     if xXvpLcVArtGUFSCKNafRojnlqWYuMw!='':xXvpLcVArtGUFSCKNafRojnlqWYuwO[xXvpLcVArtGUFSCKNafRojnlqWYuMz]=xXvpLcVArtGUFSCKNafRojnlqWYuMw
     xXvpLcVArtGUFSCKNafRojnlqWYuMz=xXvpLcVArtGUFSCKNafRojnlqWYuMg
     xXvpLcVArtGUFSCKNafRojnlqWYuMw =''
    if xXvpLcVArtGUFSCKNafRojnlqWYuMw:xXvpLcVArtGUFSCKNafRojnlqWYuMw+='\n'
    xXvpLcVArtGUFSCKNafRojnlqWYuMw+=xXvpLcVArtGUFSCKNafRojnlqWYuwe['title']+'\n'
    xXvpLcVArtGUFSCKNafRojnlqWYuMw+=' [%s ~ %s]'%(xXvpLcVArtGUFSCKNafRojnlqWYuwe['startTime'][-5:],xXvpLcVArtGUFSCKNafRojnlqWYuwe['endTime'][-5:])+'\n'
   if xXvpLcVArtGUFSCKNafRojnlqWYuMw:xXvpLcVArtGUFSCKNafRojnlqWYuwO[xXvpLcVArtGUFSCKNafRojnlqWYuMz]=xXvpLcVArtGUFSCKNafRojnlqWYuMw
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuwO
 def GetEPGList_new(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuwO={}
  xXvpLcVArtGUFSCKNafRojnlqWYuwk=xXvpLcVArtGUFSCKNafRojnlqWYuzg.Get_Now_Datetime()
  xXvpLcVArtGUFSCKNafRojnlqWYuwH=xXvpLcVArtGUFSCKNafRojnlqWYuwk.strftime('%Y%m%d%H%M00')
  xXvpLcVArtGUFSCKNafRojnlqWYuwT='%s%s%s'%(xXvpLcVArtGUFSCKNafRojnlqWYuwH[0:4],xXvpLcVArtGUFSCKNafRojnlqWYuwH[4:6],xXvpLcVArtGUFSCKNafRojnlqWYuwH[6:8])
  xXvpLcVArtGUFSCKNafRojnlqWYuws=(xXvpLcVArtGUFSCKNafRojnlqWYuwk+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for xXvpLcVArtGUFSCKNafRojnlqWYuwe in LIVETV_LIST:
    xXvpLcVArtGUFSCKNafRojnlqWYuMJ =xXvpLcVArtGUFSCKNafRojnlqWYuwe['videoId']
    if xXvpLcVArtGUFSCKNafRojnlqWYuwe['epgtype']=='spotvon':
     xXvpLcVArtGUFSCKNafRojnlqWYuMw=xXvpLcVArtGUFSCKNafRojnlqWYuzg.Get_EpgInfo_Spotv_spotvon(xXvpLcVArtGUFSCKNafRojnlqWYuMJ,xXvpLcVArtGUFSCKNafRojnlqWYuwe['epgnm'],xXvpLcVArtGUFSCKNafRojnlqWYuwT)
     xXvpLcVArtGUFSCKNafRojnlqWYuwO[xXvpLcVArtGUFSCKNafRojnlqWYuMJ]=xXvpLcVArtGUFSCKNafRojnlqWYuMw
    if xXvpLcVArtGUFSCKNafRojnlqWYuwe['epgtype']=='spotvnet':
     xXvpLcVArtGUFSCKNafRojnlqWYuMw=xXvpLcVArtGUFSCKNafRojnlqWYuzg.Get_EpgInfo_Spotv_spotvnet(xXvpLcVArtGUFSCKNafRojnlqWYuMJ,xXvpLcVArtGUFSCKNafRojnlqWYuwe['epgnm'],xXvpLcVArtGUFSCKNafRojnlqWYuwT)
     xXvpLcVArtGUFSCKNafRojnlqWYuwO[xXvpLcVArtGUFSCKNafRojnlqWYuMJ]=xXvpLcVArtGUFSCKNafRojnlqWYuMw
   for xXvpLcVArtGUFSCKNafRojnlqWYuMP in xXvpLcVArtGUFSCKNafRojnlqWYuwO.keys():
    if xXvpLcVArtGUFSCKNafRojnlqWYuBT(xXvpLcVArtGUFSCKNafRojnlqWYuwO.get(xXvpLcVArtGUFSCKNafRojnlqWYuMP))==0:continue
    xXvpLcVArtGUFSCKNafRojnlqWYuMw =''
    xXvpLcVArtGUFSCKNafRojnlqWYuMm=''
    for xXvpLcVArtGUFSCKNafRojnlqWYuMI in xXvpLcVArtGUFSCKNafRojnlqWYuwO.get(xXvpLcVArtGUFSCKNafRojnlqWYuMP):
     xXvpLcVArtGUFSCKNafRojnlqWYuMB =xXvpLcVArtGUFSCKNafRojnlqWYuMI['startTime']
     xXvpLcVArtGUFSCKNafRojnlqWYuMd =xXvpLcVArtGUFSCKNafRojnlqWYuMI['endTime']
     if xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuwH)>xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuMd) :continue
     if xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuws)<xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuMB):continue
     if xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuwH)>=xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuMB)and xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuwH)<xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuMd):xXvpLcVArtGUFSCKNafRojnlqWYuMm=xXvpLcVArtGUFSCKNafRojnlqWYuzg.xmlText(xXvpLcVArtGUFSCKNafRojnlqWYuMI['title'])
     if xXvpLcVArtGUFSCKNafRojnlqWYuMw:xXvpLcVArtGUFSCKNafRojnlqWYuMw+='\n'
     xXvpLcVArtGUFSCKNafRojnlqWYuMw+=xXvpLcVArtGUFSCKNafRojnlqWYuzg.xmlText(xXvpLcVArtGUFSCKNafRojnlqWYuMI['title'])+'\n'
     xXvpLcVArtGUFSCKNafRojnlqWYuMw+=' [%s:%s ~ %s:%s]'%(xXvpLcVArtGUFSCKNafRojnlqWYuMI['startTime'][8:10],xXvpLcVArtGUFSCKNafRojnlqWYuMI['startTime'][10:12],xXvpLcVArtGUFSCKNafRojnlqWYuMI['endTime'][8:10],xXvpLcVArtGUFSCKNafRojnlqWYuMI['endTime'][10:12])+'\n'
    xXvpLcVArtGUFSCKNafRojnlqWYuwO[xXvpLcVArtGUFSCKNafRojnlqWYuMP]={'epg':xXvpLcVArtGUFSCKNafRojnlqWYuMw,'title':xXvpLcVArtGUFSCKNafRojnlqWYuMm}
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuwO
 def Get_EpgInfo_Spotv_spotvon(xXvpLcVArtGUFSCKNafRojnlqWYuzg,xXvpLcVArtGUFSCKNafRojnlqWYuMJ,epgnm,now_day):
  xXvpLcVArtGUFSCKNafRojnlqWYuwO =[]
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuMi=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuMi:
    xXvpLcVArtGUFSCKNafRojnlqWYuwD={'title':xXvpLcVArtGUFSCKNafRojnlqWYuwe['title'],'startTime':xXvpLcVArtGUFSCKNafRojnlqWYuwe['sch_date'].replace('-','')+xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuwe['sch_hour']).zfill(2)+xXvpLcVArtGUFSCKNafRojnlqWYuwe['sch_min']+'00'}
    xXvpLcVArtGUFSCKNafRojnlqWYuwO.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
   for i in xXvpLcVArtGUFSCKNafRojnlqWYuBs(xXvpLcVArtGUFSCKNafRojnlqWYuBT(xXvpLcVArtGUFSCKNafRojnlqWYuwO)):
    if i>0:xXvpLcVArtGUFSCKNafRojnlqWYuwO[i-1]['endTime']=xXvpLcVArtGUFSCKNafRojnlqWYuwO[i]['startTime']
    if i==xXvpLcVArtGUFSCKNafRojnlqWYuBT(xXvpLcVArtGUFSCKNafRojnlqWYuwO)-1: xXvpLcVArtGUFSCKNafRojnlqWYuwO[i]['endTime']=now_day+'240000'
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
   return[]
  return xXvpLcVArtGUFSCKNafRojnlqWYuwO
 def Get_EpgInfo_Spotv_spotvnet(xXvpLcVArtGUFSCKNafRojnlqWYuzg,xXvpLcVArtGUFSCKNafRojnlqWYuMJ,epgnm,now_day):
  xXvpLcVArtGUFSCKNafRojnlqWYuwO =[]
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuMi=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuMi:
    xXvpLcVArtGUFSCKNafRojnlqWYuwD={'title':xXvpLcVArtGUFSCKNafRojnlqWYuwe['title'],'startTime':xXvpLcVArtGUFSCKNafRojnlqWYuwe['sch_date'].replace('-','')+xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuwe['sch_hour']).zfill(2)+xXvpLcVArtGUFSCKNafRojnlqWYuwe['sch_min']+'00'}
    xXvpLcVArtGUFSCKNafRojnlqWYuwO.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
   for i in xXvpLcVArtGUFSCKNafRojnlqWYuBs(xXvpLcVArtGUFSCKNafRojnlqWYuBT(xXvpLcVArtGUFSCKNafRojnlqWYuwO)):
    if i>0:xXvpLcVArtGUFSCKNafRojnlqWYuwO[i-1]['endTime']=xXvpLcVArtGUFSCKNafRojnlqWYuwO[i]['startTime']
    if i==xXvpLcVArtGUFSCKNafRojnlqWYuBT(xXvpLcVArtGUFSCKNafRojnlqWYuwO)-1: xXvpLcVArtGUFSCKNafRojnlqWYuwO[i]['endTime']=now_day+'240000'
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
   return[]
  return xXvpLcVArtGUFSCKNafRojnlqWYuwO
 def GetEventLiveList(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuwy=[]
  xXvpLcVArtGUFSCKNafRojnlqWYuME =0
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuMb=xXvpLcVArtGUFSCKNafRojnlqWYuzg.Get_Now_Datetime()
   xXvpLcVArtGUFSCKNafRojnlqWYuMy=xXvpLcVArtGUFSCKNafRojnlqWYuMb.strftime('%Y-%m-%d')
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
   return xXvpLcVArtGUFSCKNafRojnlqWYuwy,xXvpLcVArtGUFSCKNafRojnlqWYuME
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/player/lives/'+xXvpLcVArtGUFSCKNafRojnlqWYuMy 
   xXvpLcVArtGUFSCKNafRojnlqWYuzE=xXvpLcVArtGUFSCKNafRojnlqWYuzg.makeDefaultCookies()
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuzE)
   xXvpLcVArtGUFSCKNafRojnlqWYuME=xXvpLcVArtGUFSCKNafRojnlqWYuzO.status_code 
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   for xXvpLcVArtGUFSCKNafRojnlqWYuMh in xXvpLcVArtGUFSCKNafRojnlqWYuzk:
    for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuMh['liveNowList']:
     if xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['title']==xXvpLcVArtGUFSCKNafRojnlqWYuBy or xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['title']=='':
      xXvpLcVArtGUFSCKNafRojnlqWYuMe='%s ( %s : %s )'%(xXvpLcVArtGUFSCKNafRojnlqWYuwe['leagueName'],xXvpLcVArtGUFSCKNafRojnlqWYuwe['homeNameShort'],xXvpLcVArtGUFSCKNafRojnlqWYuwe['awayNameShort'])
     else:
      xXvpLcVArtGUFSCKNafRojnlqWYuMe=xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['title']
     xXvpLcVArtGUFSCKNafRojnlqWYuwD={'liveId':xXvpLcVArtGUFSCKNafRojnlqWYuwe['liveId'],'title':xXvpLcVArtGUFSCKNafRojnlqWYuMe,'logo':xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['leagueLogo'],'free':xXvpLcVArtGUFSCKNafRojnlqWYuwe['isFree'],'startTime':xXvpLcVArtGUFSCKNafRojnlqWYuwe['startTime']}
     xXvpLcVArtGUFSCKNafRojnlqWYuwy.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuwy,xXvpLcVArtGUFSCKNafRojnlqWYuME
 def GetEventLive_videoId(xXvpLcVArtGUFSCKNafRojnlqWYuzg,liveId):
  xXvpLcVArtGUFSCKNafRojnlqWYuMD=''
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/live/'+liveId
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   xXvpLcVArtGUFSCKNafRojnlqWYuMQ=xXvpLcVArtGUFSCKNafRojnlqWYuzk['videoId']
   xXvpLcVArtGUFSCKNafRojnlqWYuMD=xXvpLcVArtGUFSCKNafRojnlqWYuMQ.replace('ref:','')
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuMD
 def CheckMainEnd(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuMO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.SPOTV_PMCODE+xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['cookies']['spotv_sessionid']
  xXvpLcVArtGUFSCKNafRojnlqWYuMO=base64.standard_b64encode(xXvpLcVArtGUFSCKNafRojnlqWYuMO.encode()).decode('utf-8')
  if xXvpLcVArtGUFSCKNafRojnlqWYuMO=='OTg3MTgzMzM0Ng==' or xXvpLcVArtGUFSCKNafRojnlqWYuMO=='OTg3MTgzMzExNw==':return xXvpLcVArtGUFSCKNafRojnlqWYuBD
  return xXvpLcVArtGUFSCKNafRojnlqWYuBh
 def CheckSubEnd(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuzm=xXvpLcVArtGUFSCKNafRojnlqWYuBh
  try:
   if xXvpLcVArtGUFSCKNafRojnlqWYuzg.CheckMainEnd():return xXvpLcVArtGUFSCKNafRojnlqWYuBD 
   xXvpLcVArtGUFSCKNafRojnlqWYuMk=base64.standard_b64decode(xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['cookies']['spotv_subend']).decode('utf-8')[xXvpLcVArtGUFSCKNafRojnlqWYuzg.SPOTV_PMSIZE:]
   if xXvpLcVArtGUFSCKNafRojnlqWYuMk=='0':return xXvpLcVArtGUFSCKNafRojnlqWYuzm
   xXvpLcVArtGUFSCKNafRojnlqWYuMH =xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuzg.Get_Now_Datetime().strftime('%Y%m%d'))
   xXvpLcVArtGUFSCKNafRojnlqWYuMT =xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuMk)/1000
   xXvpLcVArtGUFSCKNafRojnlqWYuMs =xXvpLcVArtGUFSCKNafRojnlqWYuBH(datetime.datetime.fromtimestamp(xXvpLcVArtGUFSCKNafRojnlqWYuMT,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if xXvpLcVArtGUFSCKNafRojnlqWYuMH<=xXvpLcVArtGUFSCKNafRojnlqWYuMs:xXvpLcVArtGUFSCKNafRojnlqWYuzm=xXvpLcVArtGUFSCKNafRojnlqWYuBD
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
   return xXvpLcVArtGUFSCKNafRojnlqWYuzm
  return xXvpLcVArtGUFSCKNafRojnlqWYuzm
 def GetBroadURL(xXvpLcVArtGUFSCKNafRojnlqWYuzg,xXvpLcVArtGUFSCKNafRojnlqWYuMD,mediatype,xXvpLcVArtGUFSCKNafRojnlqWYugi):
  xXvpLcVArtGUFSCKNafRojnlqWYugz=''
  try:
   if mediatype=='live':
    xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/live/'+xXvpLcVArtGUFSCKNafRojnlqWYuMD
   else:
    xXvpLcVArtGUFSCKNafRojnlqWYuMD=xXvpLcVArtGUFSCKNafRojnlqWYuzg.GetReplay_UrlId(xXvpLcVArtGUFSCKNafRojnlqWYuMD,xXvpLcVArtGUFSCKNafRojnlqWYugi)
    if xXvpLcVArtGUFSCKNafRojnlqWYuMD=='':return xXvpLcVArtGUFSCKNafRojnlqWYugz
    xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.PLAYER_DOMAIN+'/playback/v1/accounts/'+xXvpLcVArtGUFSCKNafRojnlqWYuzg.ST['cookies']['spotv_accountId']+'/videos/'+xXvpLcVArtGUFSCKNafRojnlqWYuMD
   xXvpLcVArtGUFSCKNafRojnlqWYuzb=xXvpLcVArtGUFSCKNafRojnlqWYuzg.makeDefaultHeaders()
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuzb,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuMi=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   if mediatype=='live':
    xXvpLcVArtGUFSCKNafRojnlqWYugz=xXvpLcVArtGUFSCKNafRojnlqWYuMi['hlsUrl2']
   else:
    xXvpLcVArtGUFSCKNafRojnlqWYugz=xXvpLcVArtGUFSCKNafRojnlqWYuMi['sources'][0]['src']
   xXvpLcVArtGUFSCKNafRojnlqWYugz=xXvpLcVArtGUFSCKNafRojnlqWYugz.replace('http://','https://')
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYugz
 def GetTitleGroupList(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuwy=[]
  xXvpLcVArtGUFSCKNafRojnlqWYugw=xXvpLcVArtGUFSCKNafRojnlqWYuBh
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/home/web'
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuzk:
    if xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuwe['type'])=='3':
     xXvpLcVArtGUFSCKNafRojnlqWYugM=''
     for xXvpLcVArtGUFSCKNafRojnlqWYugB in xXvpLcVArtGUFSCKNafRojnlqWYuwe['data']['list']:
      xXvpLcVArtGUFSCKNafRojnlqWYugd='[%s] %s vs %s\n<%s>\n\n'%(xXvpLcVArtGUFSCKNafRojnlqWYugB['gameDesc']['roundName'],xXvpLcVArtGUFSCKNafRojnlqWYugB['gameDesc']['homeNameShort'],xXvpLcVArtGUFSCKNafRojnlqWYugB['gameDesc']['awayNameShort'],xXvpLcVArtGUFSCKNafRojnlqWYugB['gameDesc']['beginDate'])
      xXvpLcVArtGUFSCKNafRojnlqWYugM+=xXvpLcVArtGUFSCKNafRojnlqWYugd
     xXvpLcVArtGUFSCKNafRojnlqWYuwD={'title':xXvpLcVArtGUFSCKNafRojnlqWYuwe['title'],'logo':xXvpLcVArtGUFSCKNafRojnlqWYuwe['logo'],'reagueId':xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuwe['destId']),'subGame':xXvpLcVArtGUFSCKNafRojnlqWYugM}
     xXvpLcVArtGUFSCKNafRojnlqWYuwy.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
     if xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuwe['destId'])=='13':xXvpLcVArtGUFSCKNafRojnlqWYugw=xXvpLcVArtGUFSCKNafRojnlqWYuBD
   if xXvpLcVArtGUFSCKNafRojnlqWYugw==xXvpLcVArtGUFSCKNafRojnlqWYuBh:
    xXvpLcVArtGUFSCKNafRojnlqWYuwD={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    xXvpLcVArtGUFSCKNafRojnlqWYuwy.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuwy
 def GetPopularGroupList(xXvpLcVArtGUFSCKNafRojnlqWYuzg):
  xXvpLcVArtGUFSCKNafRojnlqWYuwy=[]
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/home/web'
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuzk:
    if xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuwe['type'])=='1' and xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuwe['destId'])=='4':
     for xXvpLcVArtGUFSCKNafRojnlqWYugB in xXvpLcVArtGUFSCKNafRojnlqWYuwe['data']['list']:
      xXvpLcVArtGUFSCKNafRojnlqWYugJ =xXvpLcVArtGUFSCKNafRojnlqWYugB['title']
      xXvpLcVArtGUFSCKNafRojnlqWYugP =xXvpLcVArtGUFSCKNafRojnlqWYugB['id']
      xXvpLcVArtGUFSCKNafRojnlqWYugm =xXvpLcVArtGUFSCKNafRojnlqWYugB['vtype']
      xXvpLcVArtGUFSCKNafRojnlqWYugI =xXvpLcVArtGUFSCKNafRojnlqWYugB['imgUrl']
      xXvpLcVArtGUFSCKNafRojnlqWYugi =xXvpLcVArtGUFSCKNafRojnlqWYugB['vtypeId']
      xXvpLcVArtGUFSCKNafRojnlqWYuwD={'vodTitle':xXvpLcVArtGUFSCKNafRojnlqWYugJ,'vodId':xXvpLcVArtGUFSCKNafRojnlqWYugP,'vodType':xXvpLcVArtGUFSCKNafRojnlqWYugm,'thumbnail':xXvpLcVArtGUFSCKNafRojnlqWYugI,'vtypeId':xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYugi),'duration':xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYugB['duration']/1000)}
      xXvpLcVArtGUFSCKNafRojnlqWYuwy.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuwy
 def Get_NowVod_GroupList(xXvpLcVArtGUFSCKNafRojnlqWYuzg,page_int):
  xXvpLcVArtGUFSCKNafRojnlqWYuwy=[]
  xXvpLcVArtGUFSCKNafRojnlqWYugE=xXvpLcVArtGUFSCKNafRojnlqWYuBh
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/theme/14/list'
   xXvpLcVArtGUFSCKNafRojnlqWYugb={'pageItem':'10','pageNo':xXvpLcVArtGUFSCKNafRojnlqWYuBQ(page_int)}
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYugb,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuzk['list']:
    xXvpLcVArtGUFSCKNafRojnlqWYugJ =xXvpLcVArtGUFSCKNafRojnlqWYuwe['title']
    xXvpLcVArtGUFSCKNafRojnlqWYugP =xXvpLcVArtGUFSCKNafRojnlqWYuwe['id']
    xXvpLcVArtGUFSCKNafRojnlqWYugm =xXvpLcVArtGUFSCKNafRojnlqWYuwe['vtype']
    xXvpLcVArtGUFSCKNafRojnlqWYugI =xXvpLcVArtGUFSCKNafRojnlqWYuwe['imgUrl']
    xXvpLcVArtGUFSCKNafRojnlqWYugi =xXvpLcVArtGUFSCKNafRojnlqWYuwe['vtypeId']
    xXvpLcVArtGUFSCKNafRojnlqWYuwD={'vodTitle':xXvpLcVArtGUFSCKNafRojnlqWYugJ,'vodId':xXvpLcVArtGUFSCKNafRojnlqWYugP,'vodType':xXvpLcVArtGUFSCKNafRojnlqWYugm,'thumbnail':xXvpLcVArtGUFSCKNafRojnlqWYugI,'vtypeId':xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYugi),'duration':xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuwe['duration']/1000),}
    xXvpLcVArtGUFSCKNafRojnlqWYuwy.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
    if xXvpLcVArtGUFSCKNafRojnlqWYuzk['count']>page_int*xXvpLcVArtGUFSCKNafRojnlqWYuzg.GAMELIST_LIMIT:xXvpLcVArtGUFSCKNafRojnlqWYugE=xXvpLcVArtGUFSCKNafRojnlqWYuBD
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuwy,xXvpLcVArtGUFSCKNafRojnlqWYugE
 def GetSeasonList(xXvpLcVArtGUFSCKNafRojnlqWYuzg,leagueId):
  xXvpLcVArtGUFSCKNafRojnlqWYuwy=[]
  xXvpLcVArtGUFSCKNafRojnlqWYugy=xXvpLcVArtGUFSCKNafRojnlqWYugh=''
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/game/league/'+leagueId
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   xXvpLcVArtGUFSCKNafRojnlqWYugy=xXvpLcVArtGUFSCKNafRojnlqWYuzk['name']
   xXvpLcVArtGUFSCKNafRojnlqWYugh=xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuzk['gameTypeId'])
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
   return xXvpLcVArtGUFSCKNafRojnlqWYuwy
  if xXvpLcVArtGUFSCKNafRojnlqWYugh=='2':
   try:
    xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/year/'+leagueId
    xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
    xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
    for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuzk:
     xXvpLcVArtGUFSCKNafRojnlqWYuwD={'reagueName':xXvpLcVArtGUFSCKNafRojnlqWYugy,'gameTypeId':xXvpLcVArtGUFSCKNafRojnlqWYugh,'seasonName':xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuwe),'seasonId':xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuwe)}
     xXvpLcVArtGUFSCKNafRojnlqWYuwy.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
   except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
    xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
    return[]
  else:
   try:
    xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/season/'+leagueId
    xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
    xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
    for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuzk:
     xXvpLcVArtGUFSCKNafRojnlqWYuwD={'reagueName':xXvpLcVArtGUFSCKNafRojnlqWYugy,'gameTypeId':xXvpLcVArtGUFSCKNafRojnlqWYugh,'seasonName':xXvpLcVArtGUFSCKNafRojnlqWYuwe['name'],'seasonId':xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYuwe['id'])}
     xXvpLcVArtGUFSCKNafRojnlqWYuwy.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
   except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
    xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
    return[]
  return xXvpLcVArtGUFSCKNafRojnlqWYuwy
 def GetGameList(xXvpLcVArtGUFSCKNafRojnlqWYuzg,xXvpLcVArtGUFSCKNafRojnlqWYugh,leagueId,seasonId,page_int,hidescore=xXvpLcVArtGUFSCKNafRojnlqWYuBD):
  xXvpLcVArtGUFSCKNafRojnlqWYuwy=[]
  xXvpLcVArtGUFSCKNafRojnlqWYugE=xXvpLcVArtGUFSCKNafRojnlqWYuBh
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/vod/league/detail'
   xXvpLcVArtGUFSCKNafRojnlqWYugb={'gameType':xXvpLcVArtGUFSCKNafRojnlqWYugh,'leagueId':leagueId,'seasonId':seasonId if xXvpLcVArtGUFSCKNafRojnlqWYugh!='2' else '','teamId':'','roundId':'','year':'' if xXvpLcVArtGUFSCKNafRojnlqWYugh!='2' else seasonId,'pageNo':xXvpLcVArtGUFSCKNafRojnlqWYuBQ(page_int)}
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYugb,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   xXvpLcVArtGUFSCKNafRojnlqWYuMh=xXvpLcVArtGUFSCKNafRojnlqWYuzk['list']
   for xXvpLcVArtGUFSCKNafRojnlqWYuge in xXvpLcVArtGUFSCKNafRojnlqWYuMh:
    for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuge['list']:
     if xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['title']==xXvpLcVArtGUFSCKNafRojnlqWYuBy or xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['title']=='':
      xXvpLcVArtGUFSCKNafRojnlqWYuMe ='%s vs %s'%(xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['homeNameShort'],xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['awayNameShort'])
     else:
      xXvpLcVArtGUFSCKNafRojnlqWYuMe =xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['title']
     xXvpLcVArtGUFSCKNafRojnlqWYugD =xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['beginDate']
     xXvpLcVArtGUFSCKNafRojnlqWYugQ =xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['id']
     xXvpLcVArtGUFSCKNafRojnlqWYugO =xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['leagueNameFull']
     xXvpLcVArtGUFSCKNafRojnlqWYugk =xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['seasonName']
     xXvpLcVArtGUFSCKNafRojnlqWYugH =xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['roundName']
     xXvpLcVArtGUFSCKNafRojnlqWYugT =xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['homeName']
     xXvpLcVArtGUFSCKNafRojnlqWYugs =xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['awayName']
     xXvpLcVArtGUFSCKNafRojnlqWYuBz =xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['homeScore']
     xXvpLcVArtGUFSCKNafRojnlqWYuBw =xXvpLcVArtGUFSCKNafRojnlqWYuwe['gameDesc']['awayScore']
     if hidescore==xXvpLcVArtGUFSCKNafRojnlqWYuBD:
      xXvpLcVArtGUFSCKNafRojnlqWYuBM ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(xXvpLcVArtGUFSCKNafRojnlqWYugO,xXvpLcVArtGUFSCKNafRojnlqWYugk,xXvpLcVArtGUFSCKNafRojnlqWYugH,xXvpLcVArtGUFSCKNafRojnlqWYugD,xXvpLcVArtGUFSCKNafRojnlqWYugT,xXvpLcVArtGUFSCKNafRojnlqWYugs)
     else:
      xXvpLcVArtGUFSCKNafRojnlqWYuBM ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(xXvpLcVArtGUFSCKNafRojnlqWYugO,xXvpLcVArtGUFSCKNafRojnlqWYugk,xXvpLcVArtGUFSCKNafRojnlqWYugH,xXvpLcVArtGUFSCKNafRojnlqWYugD,xXvpLcVArtGUFSCKNafRojnlqWYugT,xXvpLcVArtGUFSCKNafRojnlqWYuBz,xXvpLcVArtGUFSCKNafRojnlqWYugs,xXvpLcVArtGUFSCKNafRojnlqWYuBw)
     xXvpLcVArtGUFSCKNafRojnlqWYuBg=xXvpLcVArtGUFSCKNafRojnlqWYuBM
     xXvpLcVArtGUFSCKNafRojnlqWYuBd =xXvpLcVArtGUFSCKNafRojnlqWYuwe['replayVod']['count']
     xXvpLcVArtGUFSCKNafRojnlqWYuBJ=xXvpLcVArtGUFSCKNafRojnlqWYuwe['highlightVod']['count']
     xXvpLcVArtGUFSCKNafRojnlqWYuBP =xXvpLcVArtGUFSCKNafRojnlqWYuwe['vods']['count']
     xXvpLcVArtGUFSCKNafRojnlqWYugI='' 
     xXvpLcVArtGUFSCKNafRojnlqWYuBm=xXvpLcVArtGUFSCKNafRojnlqWYuBd+xXvpLcVArtGUFSCKNafRojnlqWYuBJ+xXvpLcVArtGUFSCKNafRojnlqWYuBP
     if xXvpLcVArtGUFSCKNafRojnlqWYuBm==0:
      if xXvpLcVArtGUFSCKNafRojnlqWYugh=='2':
       xXvpLcVArtGUFSCKNafRojnlqWYuMe='----- %s -----'%(xXvpLcVArtGUFSCKNafRojnlqWYugk)
       xXvpLcVArtGUFSCKNafRojnlqWYugD=''
      else:
       xXvpLcVArtGUFSCKNafRojnlqWYuMe+=' - 관련영상 없음'
       xXvpLcVArtGUFSCKNafRojnlqWYuBg+='\n\n ** 관련영상 없음 **'
     else:
      if xXvpLcVArtGUFSCKNafRojnlqWYuBd!=0:
       xXvpLcVArtGUFSCKNafRojnlqWYugI =xXvpLcVArtGUFSCKNafRojnlqWYuwe['replayVod']['list'][0]['imgUrl']
      elif xXvpLcVArtGUFSCKNafRojnlqWYuBJ!=0:
       xXvpLcVArtGUFSCKNafRojnlqWYugI =xXvpLcVArtGUFSCKNafRojnlqWYuwe['highlightVod']['list'][0]['imgUrl']
      else:
       xXvpLcVArtGUFSCKNafRojnlqWYugI =xXvpLcVArtGUFSCKNafRojnlqWYuwe['vods']['list'][0]['imgUrl']
     xXvpLcVArtGUFSCKNafRojnlqWYuwD={'gameTitle':xXvpLcVArtGUFSCKNafRojnlqWYuMe,'gameId':xXvpLcVArtGUFSCKNafRojnlqWYugQ,'beginDate':xXvpLcVArtGUFSCKNafRojnlqWYugD[:11],'thumbnail':xXvpLcVArtGUFSCKNafRojnlqWYugI,'info_plot':xXvpLcVArtGUFSCKNafRojnlqWYuBg,'leaguenm':xXvpLcVArtGUFSCKNafRojnlqWYugO,'seasonnm':xXvpLcVArtGUFSCKNafRojnlqWYugk,'roundnm':xXvpLcVArtGUFSCKNafRojnlqWYugH,'totVodCnt':xXvpLcVArtGUFSCKNafRojnlqWYuBm}
     xXvpLcVArtGUFSCKNafRojnlqWYuwy.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  if xXvpLcVArtGUFSCKNafRojnlqWYuzk['count']>page_int*xXvpLcVArtGUFSCKNafRojnlqWYuzg.GAMELIST_LIMIT:xXvpLcVArtGUFSCKNafRojnlqWYugE=xXvpLcVArtGUFSCKNafRojnlqWYuBD
  return xXvpLcVArtGUFSCKNafRojnlqWYuwy,xXvpLcVArtGUFSCKNafRojnlqWYugE
 def GetGameVodList(xXvpLcVArtGUFSCKNafRojnlqWYuzg,xXvpLcVArtGUFSCKNafRojnlqWYugQ,vodCount=1000):
  xXvpLcVArtGUFSCKNafRojnlqWYuwy=[]
  xXvpLcVArtGUFSCKNafRojnlqWYuBI=''
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/vod/game'
   xXvpLcVArtGUFSCKNafRojnlqWYugb={'gameId':xXvpLcVArtGUFSCKNafRojnlqWYugQ,'pageItem':xXvpLcVArtGUFSCKNafRojnlqWYuBQ(vodCount)}
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYugb,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   xXvpLcVArtGUFSCKNafRojnlqWYuge=xXvpLcVArtGUFSCKNafRojnlqWYuzk['list']
   for xXvpLcVArtGUFSCKNafRojnlqWYuwe in xXvpLcVArtGUFSCKNafRojnlqWYuge:
    xXvpLcVArtGUFSCKNafRojnlqWYugJ =xXvpLcVArtGUFSCKNafRojnlqWYuwe['title']
    xXvpLcVArtGUFSCKNafRojnlqWYugP =xXvpLcVArtGUFSCKNafRojnlqWYuwe['id']
    xXvpLcVArtGUFSCKNafRojnlqWYugm =xXvpLcVArtGUFSCKNafRojnlqWYuwe['vtype']
    xXvpLcVArtGUFSCKNafRojnlqWYugI =xXvpLcVArtGUFSCKNafRojnlqWYuwe['imgUrl']
    xXvpLcVArtGUFSCKNafRojnlqWYugi =xXvpLcVArtGUFSCKNafRojnlqWYuwe['vtypeId']
    xXvpLcVArtGUFSCKNafRojnlqWYuBi =xXvpLcVArtGUFSCKNafRojnlqWYuwe['isFree']
    xXvpLcVArtGUFSCKNafRojnlqWYuwD={'vodTitle':xXvpLcVArtGUFSCKNafRojnlqWYugJ,'vodId':xXvpLcVArtGUFSCKNafRojnlqWYugP,'vodType':xXvpLcVArtGUFSCKNafRojnlqWYugm,'thumbnail':xXvpLcVArtGUFSCKNafRojnlqWYugI,'vtypeId':xXvpLcVArtGUFSCKNafRojnlqWYuBQ(xXvpLcVArtGUFSCKNafRojnlqWYugi),'duration':xXvpLcVArtGUFSCKNafRojnlqWYuBH(xXvpLcVArtGUFSCKNafRojnlqWYuwe['duration']/1000),'isFree':xXvpLcVArtGUFSCKNafRojnlqWYuBi}
    xXvpLcVArtGUFSCKNafRojnlqWYuwy.append(xXvpLcVArtGUFSCKNafRojnlqWYuwD)
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuwy
 def GetReplay_UrlId(xXvpLcVArtGUFSCKNafRojnlqWYuzg,xXvpLcVArtGUFSCKNafRojnlqWYuBI,xXvpLcVArtGUFSCKNafRojnlqWYugi):
  xXvpLcVArtGUFSCKNafRojnlqWYuBE=''
  try:
   xXvpLcVArtGUFSCKNafRojnlqWYuzs=xXvpLcVArtGUFSCKNafRojnlqWYuzg.API_DOMAIN+'/api/v2/vod/'+xXvpLcVArtGUFSCKNafRojnlqWYuBI
   xXvpLcVArtGUFSCKNafRojnlqWYuzO=xXvpLcVArtGUFSCKNafRojnlqWYuzg.callRequestCookies('Get',xXvpLcVArtGUFSCKNafRojnlqWYuzs,payload=xXvpLcVArtGUFSCKNafRojnlqWYuBy,params=xXvpLcVArtGUFSCKNafRojnlqWYuBy,headers=xXvpLcVArtGUFSCKNafRojnlqWYuBy,cookies=xXvpLcVArtGUFSCKNafRojnlqWYuBy)
   xXvpLcVArtGUFSCKNafRojnlqWYuzk=json.loads(xXvpLcVArtGUFSCKNafRojnlqWYuzO.text)
   xXvpLcVArtGUFSCKNafRojnlqWYuBE=xXvpLcVArtGUFSCKNafRojnlqWYuzk['videoId']
  except xXvpLcVArtGUFSCKNafRojnlqWYuBO as exception:
   xXvpLcVArtGUFSCKNafRojnlqWYuBk(exception)
  return xXvpLcVArtGUFSCKNafRojnlqWYuBE
# Created by pyminifier (https://github.com/liftoff/pyminifier)
