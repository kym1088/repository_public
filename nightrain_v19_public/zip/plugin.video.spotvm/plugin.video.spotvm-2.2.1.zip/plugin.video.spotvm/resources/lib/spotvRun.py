__author__="NightRain"
OJVzIWdNjTUbFMQigrseELakGXwPYD=object
OJVzIWdNjTUbFMQigrseELakGXwPYK=None
OJVzIWdNjTUbFMQigrseELakGXwPYc=False
OJVzIWdNjTUbFMQigrseELakGXwPYH=True
OJVzIWdNjTUbFMQigrseELakGXwPYv=int
OJVzIWdNjTUbFMQigrseELakGXwPYl=len
OJVzIWdNjTUbFMQigrseELakGXwPYp=str
OJVzIWdNjTUbFMQigrseELakGXwPfm=id
OJVzIWdNjTUbFMQigrseELakGXwPfx=open
OJVzIWdNjTUbFMQigrseELakGXwPft=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
OJVzIWdNjTUbFMQigrseELakGXwPmt=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (경기중에만 재생)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'오늘의 추천 VOD','mode':'NOW_GROUP'},{'title':'인기영상 5','mode':'POP_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'VOD (리그, 경기별)','mode':'VOD_GROUP'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'},]
OJVzIWdNjTUbFMQigrseELakGXwPmn=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class OJVzIWdNjTUbFMQigrseELakGXwPmx(OJVzIWdNjTUbFMQigrseELakGXwPYD):
 def __init__(OJVzIWdNjTUbFMQigrseELakGXwPmY,OJVzIWdNjTUbFMQigrseELakGXwPmf,OJVzIWdNjTUbFMQigrseELakGXwPmR,OJVzIWdNjTUbFMQigrseELakGXwPmS):
  OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_url =OJVzIWdNjTUbFMQigrseELakGXwPmf
  OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle=OJVzIWdNjTUbFMQigrseELakGXwPmR
  OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params =OJVzIWdNjTUbFMQigrseELakGXwPmS
  OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj =xXvpLcVArtGUFSCKNafRojnlqWYuzw() 
 def addon_noti(OJVzIWdNjTUbFMQigrseELakGXwPmY,sting):
  try:
   OJVzIWdNjTUbFMQigrseELakGXwPmu=xbmcgui.Dialog()
   OJVzIWdNjTUbFMQigrseELakGXwPmu.notification(__addonname__,sting)
  except:
   OJVzIWdNjTUbFMQigrseELakGXwPYK
 def addon_log(OJVzIWdNjTUbFMQigrseELakGXwPmY,string):
  try:
   OJVzIWdNjTUbFMQigrseELakGXwPmo=string.encode('utf-8','ignore')
  except:
   OJVzIWdNjTUbFMQigrseELakGXwPmo='addonException: addon_log'
  OJVzIWdNjTUbFMQigrseELakGXwPmB=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,OJVzIWdNjTUbFMQigrseELakGXwPmo),level=OJVzIWdNjTUbFMQigrseELakGXwPmB)
 def get_keyboard_input(OJVzIWdNjTUbFMQigrseELakGXwPmY,OJVzIWdNjTUbFMQigrseELakGXwPmK):
  OJVzIWdNjTUbFMQigrseELakGXwPmq=OJVzIWdNjTUbFMQigrseELakGXwPYK
  kb=xbmc.Keyboard()
  kb.setHeading(OJVzIWdNjTUbFMQigrseELakGXwPmK)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   OJVzIWdNjTUbFMQigrseELakGXwPmq=kb.getText()
  return OJVzIWdNjTUbFMQigrseELakGXwPmq
 def get_settings_account(OJVzIWdNjTUbFMQigrseELakGXwPmY):
  OJVzIWdNjTUbFMQigrseELakGXwPmC =__addon__.getSetting('id')
  OJVzIWdNjTUbFMQigrseELakGXwPmh =__addon__.getSetting('pw')
  return(OJVzIWdNjTUbFMQigrseELakGXwPmC,OJVzIWdNjTUbFMQigrseELakGXwPmh)
 def get_settings_hidescoreyn(OJVzIWdNjTUbFMQigrseELakGXwPmY):
  OJVzIWdNjTUbFMQigrseELakGXwPmA =__addon__.getSetting('hidescore')
  if OJVzIWdNjTUbFMQigrseELakGXwPmA=='false':
   return OJVzIWdNjTUbFMQigrseELakGXwPYc
  else:
   return OJVzIWdNjTUbFMQigrseELakGXwPYH
 def add_dir(OJVzIWdNjTUbFMQigrseELakGXwPmY,label,sublabel='',img='',infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPYK,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYH,params='',isLink=OJVzIWdNjTUbFMQigrseELakGXwPYc,ContextMenu=OJVzIWdNjTUbFMQigrseELakGXwPYK):
  OJVzIWdNjTUbFMQigrseELakGXwPmD='%s?%s'%(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_url,urllib.parse.urlencode(params))
  if sublabel:OJVzIWdNjTUbFMQigrseELakGXwPmK='%s < %s >'%(label,sublabel)
  else: OJVzIWdNjTUbFMQigrseELakGXwPmK=label
  if not img:img='DefaultFolder.png'
  OJVzIWdNjTUbFMQigrseELakGXwPmc=xbmcgui.ListItem(OJVzIWdNjTUbFMQigrseELakGXwPmK)
  OJVzIWdNjTUbFMQigrseELakGXwPmc.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:OJVzIWdNjTUbFMQigrseELakGXwPmc.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   OJVzIWdNjTUbFMQigrseELakGXwPmc.setProperty('IsPlayable','true')
  if ContextMenu:OJVzIWdNjTUbFMQigrseELakGXwPmc.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,OJVzIWdNjTUbFMQigrseELakGXwPmD,OJVzIWdNjTUbFMQigrseELakGXwPmc,isFolder)
 def get_selQuality(OJVzIWdNjTUbFMQigrseELakGXwPmY,etype):
  try:
   OJVzIWdNjTUbFMQigrseELakGXwPmH='selected_quality'
   OJVzIWdNjTUbFMQigrseELakGXwPmv=[1080,720,540]
   OJVzIWdNjTUbFMQigrseELakGXwPml=OJVzIWdNjTUbFMQigrseELakGXwPYv(__addon__.getSetting(OJVzIWdNjTUbFMQigrseELakGXwPmH))
   return OJVzIWdNjTUbFMQigrseELakGXwPmv[OJVzIWdNjTUbFMQigrseELakGXwPml]
  except:
   OJVzIWdNjTUbFMQigrseELakGXwPYK
  return 1080 
 def dp_Main_List(OJVzIWdNjTUbFMQigrseELakGXwPmY):
  for OJVzIWdNjTUbFMQigrseELakGXwPmp in OJVzIWdNjTUbFMQigrseELakGXwPmt:
   OJVzIWdNjTUbFMQigrseELakGXwPmK=OJVzIWdNjTUbFMQigrseELakGXwPmp.get('title')
   OJVzIWdNjTUbFMQigrseELakGXwPxm=''
   OJVzIWdNjTUbFMQigrseELakGXwPxt={'mode':OJVzIWdNjTUbFMQigrseELakGXwPmp.get('mode'),'page':'1'}
   if OJVzIWdNjTUbFMQigrseELakGXwPmp.get('mode')=='XXX':
    OJVzIWdNjTUbFMQigrseELakGXwPxn=OJVzIWdNjTUbFMQigrseELakGXwPYc
    OJVzIWdNjTUbFMQigrseELakGXwPxY =OJVzIWdNjTUbFMQigrseELakGXwPYH
   else:
    OJVzIWdNjTUbFMQigrseELakGXwPxn=OJVzIWdNjTUbFMQigrseELakGXwPYH
    OJVzIWdNjTUbFMQigrseELakGXwPxY =OJVzIWdNjTUbFMQigrseELakGXwPYc
   if 'icon' in OJVzIWdNjTUbFMQigrseELakGXwPmp:OJVzIWdNjTUbFMQigrseELakGXwPxm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',OJVzIWdNjTUbFMQigrseELakGXwPmp.get('icon')) 
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPmK,sublabel='',img=OJVzIWdNjTUbFMQigrseELakGXwPxm,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPYK,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPxn,params=OJVzIWdNjTUbFMQigrseELakGXwPxt,isLink=OJVzIWdNjTUbFMQigrseELakGXwPxY)
  if OJVzIWdNjTUbFMQigrseELakGXwPYl(OJVzIWdNjTUbFMQigrseELakGXwPmt)>0:xbmcplugin.endOfDirectory(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle)
 def dp_MainLeague_List(OJVzIWdNjTUbFMQigrseELakGXwPmY,args):
  OJVzIWdNjTUbFMQigrseELakGXwPxR=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.GetTitleGroupList()
  for OJVzIWdNjTUbFMQigrseELakGXwPxS in OJVzIWdNjTUbFMQigrseELakGXwPxR:
   OJVzIWdNjTUbFMQigrseELakGXwPmK =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('title')
   OJVzIWdNjTUbFMQigrseELakGXwPxy =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('logo')
   OJVzIWdNjTUbFMQigrseELakGXwPxu =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('reagueId')
   OJVzIWdNjTUbFMQigrseELakGXwPxo =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('subGame')
   OJVzIWdNjTUbFMQigrseELakGXwPxB={'mediatype':'episode','plot':'%s\n\n%s'%(OJVzIWdNjTUbFMQigrseELakGXwPmK,OJVzIWdNjTUbFMQigrseELakGXwPxo)}
   OJVzIWdNjTUbFMQigrseELakGXwPxt={'mode':'LEAGUE_GROUP','reagueId':OJVzIWdNjTUbFMQigrseELakGXwPxu}
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPmK,sublabel=OJVzIWdNjTUbFMQigrseELakGXwPYK,img=OJVzIWdNjTUbFMQigrseELakGXwPxy,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPxB,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYH,params=OJVzIWdNjTUbFMQigrseELakGXwPxt)
  if OJVzIWdNjTUbFMQigrseELakGXwPYl(OJVzIWdNjTUbFMQigrseELakGXwPxR)>0:xbmcplugin.endOfDirectory(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,cacheToDisc=OJVzIWdNjTUbFMQigrseELakGXwPYc)
 def dp_NowVod_GroupList(OJVzIWdNjTUbFMQigrseELakGXwPmY,args):
  OJVzIWdNjTUbFMQigrseELakGXwPxq=OJVzIWdNjTUbFMQigrseELakGXwPYv(args.get('page'))
  OJVzIWdNjTUbFMQigrseELakGXwPxR,OJVzIWdNjTUbFMQigrseELakGXwPxC=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.Get_NowVod_GroupList(OJVzIWdNjTUbFMQigrseELakGXwPxq)
  for OJVzIWdNjTUbFMQigrseELakGXwPxS in OJVzIWdNjTUbFMQigrseELakGXwPxR:
   OJVzIWdNjTUbFMQigrseELakGXwPxh =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vodTitle')
   OJVzIWdNjTUbFMQigrseELakGXwPxA =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vodId')
   OJVzIWdNjTUbFMQigrseELakGXwPxD =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vodType')
   OJVzIWdNjTUbFMQigrseELakGXwPxy=OJVzIWdNjTUbFMQigrseELakGXwPxS.get('thumbnail')
   OJVzIWdNjTUbFMQigrseELakGXwPxK =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vtypeId')
   OJVzIWdNjTUbFMQigrseELakGXwPxc =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('duration')
   OJVzIWdNjTUbFMQigrseELakGXwPxB={'mediatype':'episode','duration':OJVzIWdNjTUbFMQigrseELakGXwPxc,'plot':OJVzIWdNjTUbFMQigrseELakGXwPxh}
   OJVzIWdNjTUbFMQigrseELakGXwPxt={'mode':'NOW_VOD','mediacode':OJVzIWdNjTUbFMQigrseELakGXwPxA,'mediatype':'vod','vtypeId':OJVzIWdNjTUbFMQigrseELakGXwPxK}
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPxh,sublabel=OJVzIWdNjTUbFMQigrseELakGXwPxD,img=OJVzIWdNjTUbFMQigrseELakGXwPxy,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPxB,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYc,params=OJVzIWdNjTUbFMQigrseELakGXwPxt)
  if OJVzIWdNjTUbFMQigrseELakGXwPxC:
   OJVzIWdNjTUbFMQigrseELakGXwPxt['mode'] ='NOW_GROUP' 
   OJVzIWdNjTUbFMQigrseELakGXwPxt['page'] =OJVzIWdNjTUbFMQigrseELakGXwPYp(OJVzIWdNjTUbFMQigrseELakGXwPxq+1)
   OJVzIWdNjTUbFMQigrseELakGXwPmK='[B]%s >>[/B]'%'다음 페이지'
   OJVzIWdNjTUbFMQigrseELakGXwPxH=OJVzIWdNjTUbFMQigrseELakGXwPYp(OJVzIWdNjTUbFMQigrseELakGXwPxq+1)
   OJVzIWdNjTUbFMQigrseELakGXwPxm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPmK,sublabel=OJVzIWdNjTUbFMQigrseELakGXwPxH,img=OJVzIWdNjTUbFMQigrseELakGXwPxm,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPYK,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYH,params=OJVzIWdNjTUbFMQigrseELakGXwPxt)
  xbmcplugin.setContent(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,cacheToDisc=OJVzIWdNjTUbFMQigrseELakGXwPYc)
 def dp_PopVod_GroupList(OJVzIWdNjTUbFMQigrseELakGXwPmY,args):
  OJVzIWdNjTUbFMQigrseELakGXwPxR=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.GetPopularGroupList()
  for OJVzIWdNjTUbFMQigrseELakGXwPxS in OJVzIWdNjTUbFMQigrseELakGXwPxR:
   OJVzIWdNjTUbFMQigrseELakGXwPxh =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vodTitle')
   OJVzIWdNjTUbFMQigrseELakGXwPxA =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vodId')
   OJVzIWdNjTUbFMQigrseELakGXwPxD =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vodType')
   OJVzIWdNjTUbFMQigrseELakGXwPxy=OJVzIWdNjTUbFMQigrseELakGXwPxS.get('thumbnail')
   OJVzIWdNjTUbFMQigrseELakGXwPxK =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vtypeId')
   OJVzIWdNjTUbFMQigrseELakGXwPxc =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('duration')
   OJVzIWdNjTUbFMQigrseELakGXwPxB={'mediatype':'episode','duration':OJVzIWdNjTUbFMQigrseELakGXwPxc,'plot':OJVzIWdNjTUbFMQigrseELakGXwPxh}
   OJVzIWdNjTUbFMQigrseELakGXwPxt={'mode':'POP_VOD','mediacode':OJVzIWdNjTUbFMQigrseELakGXwPxA,'mediatype':'vod','vtypeId':OJVzIWdNjTUbFMQigrseELakGXwPxK}
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPxh,sublabel=OJVzIWdNjTUbFMQigrseELakGXwPxD,img=OJVzIWdNjTUbFMQigrseELakGXwPxy,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPxB,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYc,params=OJVzIWdNjTUbFMQigrseELakGXwPxt)
  xbmcplugin.setContent(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,cacheToDisc=OJVzIWdNjTUbFMQigrseELakGXwPYc)
 def dp_Season_List(OJVzIWdNjTUbFMQigrseELakGXwPmY,args):
  OJVzIWdNjTUbFMQigrseELakGXwPxu=args.get('reagueId')
  OJVzIWdNjTUbFMQigrseELakGXwPxR=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.GetSeasonList(OJVzIWdNjTUbFMQigrseELakGXwPxu)
  for OJVzIWdNjTUbFMQigrseELakGXwPxS in OJVzIWdNjTUbFMQigrseELakGXwPxR:
   OJVzIWdNjTUbFMQigrseELakGXwPxl =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('reagueName')
   OJVzIWdNjTUbFMQigrseELakGXwPxp =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('gameTypeId')
   OJVzIWdNjTUbFMQigrseELakGXwPtm =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('seasonName')
   OJVzIWdNjTUbFMQigrseELakGXwPtx =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('seasonId')
   OJVzIWdNjTUbFMQigrseELakGXwPxB={'mediatype':'episode','plot':'%s - %s'%(OJVzIWdNjTUbFMQigrseELakGXwPxl,OJVzIWdNjTUbFMQigrseELakGXwPtm)}
   OJVzIWdNjTUbFMQigrseELakGXwPxt={'mode':'SEASON_GROUP','reagueId':OJVzIWdNjTUbFMQigrseELakGXwPxu,'seasonId':OJVzIWdNjTUbFMQigrseELakGXwPtx,'gameTypeId':OJVzIWdNjTUbFMQigrseELakGXwPxp,'page':'1'}
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPxl,sublabel=OJVzIWdNjTUbFMQigrseELakGXwPtm,img='',infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPxB,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYH,params=OJVzIWdNjTUbFMQigrseELakGXwPxt)
  if OJVzIWdNjTUbFMQigrseELakGXwPYl(OJVzIWdNjTUbFMQigrseELakGXwPxR)>0:xbmcplugin.endOfDirectory(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,cacheToDisc=OJVzIWdNjTUbFMQigrseELakGXwPYH)
 def dp_Game_List(OJVzIWdNjTUbFMQigrseELakGXwPmY,args):
  OJVzIWdNjTUbFMQigrseELakGXwPxp=args.get('gameTypeId')
  OJVzIWdNjTUbFMQigrseELakGXwPxu =args.get('reagueId')
  OJVzIWdNjTUbFMQigrseELakGXwPtx =args.get('seasonId')
  OJVzIWdNjTUbFMQigrseELakGXwPxq =OJVzIWdNjTUbFMQigrseELakGXwPYv(args.get('page'))
  OJVzIWdNjTUbFMQigrseELakGXwPxR,OJVzIWdNjTUbFMQigrseELakGXwPxC=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.GetGameList(OJVzIWdNjTUbFMQigrseELakGXwPxp,OJVzIWdNjTUbFMQigrseELakGXwPxu,OJVzIWdNjTUbFMQigrseELakGXwPtx,OJVzIWdNjTUbFMQigrseELakGXwPxq,hidescore=OJVzIWdNjTUbFMQigrseELakGXwPmY.get_settings_hidescoreyn())
  for OJVzIWdNjTUbFMQigrseELakGXwPxS in OJVzIWdNjTUbFMQigrseELakGXwPxR:
   OJVzIWdNjTUbFMQigrseELakGXwPtn =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('gameTitle')
   OJVzIWdNjTUbFMQigrseELakGXwPtY =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('beginDate')
   OJVzIWdNjTUbFMQigrseELakGXwPxy =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('thumbnail')
   OJVzIWdNjTUbFMQigrseELakGXwPtf =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('gameId')
   OJVzIWdNjTUbFMQigrseELakGXwPtR =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('totVodCnt')
   OJVzIWdNjTUbFMQigrseELakGXwPtS =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('leaguenm')
   OJVzIWdNjTUbFMQigrseELakGXwPty =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('seasonnm')
   OJVzIWdNjTUbFMQigrseELakGXwPtu =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('roundnm')
   OJVzIWdNjTUbFMQigrseELakGXwPto =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('info_plot')
   OJVzIWdNjTUbFMQigrseELakGXwPtB ='%s < %s >'%(OJVzIWdNjTUbFMQigrseELakGXwPtn,OJVzIWdNjTUbFMQigrseELakGXwPtY)
   OJVzIWdNjTUbFMQigrseELakGXwPxB={'mediatype':'video','plot':OJVzIWdNjTUbFMQigrseELakGXwPto}
   OJVzIWdNjTUbFMQigrseELakGXwPxt={'mode':'GAME_VOD_GROUP' if OJVzIWdNjTUbFMQigrseELakGXwPtR!=0 else 'XXX','saveTitle':OJVzIWdNjTUbFMQigrseELakGXwPtB,'saveImg':OJVzIWdNjTUbFMQigrseELakGXwPxy,'saveInfo':OJVzIWdNjTUbFMQigrseELakGXwPxB['plot'],'gameid':OJVzIWdNjTUbFMQigrseELakGXwPtf,'totVodCnt':OJVzIWdNjTUbFMQigrseELakGXwPtR,}
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPtn,sublabel=OJVzIWdNjTUbFMQigrseELakGXwPtY,img=OJVzIWdNjTUbFMQigrseELakGXwPxy,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPxB,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYH,params=OJVzIWdNjTUbFMQigrseELakGXwPxt)
  if OJVzIWdNjTUbFMQigrseELakGXwPxC:
   OJVzIWdNjTUbFMQigrseELakGXwPxt['mode'] ='SEASON_GROUP' 
   OJVzIWdNjTUbFMQigrseELakGXwPxt['reagueId'] =OJVzIWdNjTUbFMQigrseELakGXwPxu
   OJVzIWdNjTUbFMQigrseELakGXwPxt['seasonId'] =OJVzIWdNjTUbFMQigrseELakGXwPtx
   OJVzIWdNjTUbFMQigrseELakGXwPxt['gameTypeId']=OJVzIWdNjTUbFMQigrseELakGXwPxp
   OJVzIWdNjTUbFMQigrseELakGXwPxt['page'] =OJVzIWdNjTUbFMQigrseELakGXwPYp(OJVzIWdNjTUbFMQigrseELakGXwPxq+1)
   OJVzIWdNjTUbFMQigrseELakGXwPmK='[B]%s >>[/B]'%'다음 페이지'
   OJVzIWdNjTUbFMQigrseELakGXwPxH=OJVzIWdNjTUbFMQigrseELakGXwPYp(OJVzIWdNjTUbFMQigrseELakGXwPxq+1)
   OJVzIWdNjTUbFMQigrseELakGXwPxm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPmK,sublabel=OJVzIWdNjTUbFMQigrseELakGXwPxH,img=OJVzIWdNjTUbFMQigrseELakGXwPxm,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPYK,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYH,params=OJVzIWdNjTUbFMQigrseELakGXwPxt)
  if OJVzIWdNjTUbFMQigrseELakGXwPYl(OJVzIWdNjTUbFMQigrseELakGXwPxR)>0:xbmcplugin.endOfDirectory(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,cacheToDisc=OJVzIWdNjTUbFMQigrseELakGXwPYc)
 def dp_GameVod_List(OJVzIWdNjTUbFMQigrseELakGXwPmY,args):
  OJVzIWdNjTUbFMQigrseELakGXwPtq =args.get('gameid')
  OJVzIWdNjTUbFMQigrseELakGXwPtB=args.get('saveTitle')
  OJVzIWdNjTUbFMQigrseELakGXwPtC =args.get('saveImg')
  OJVzIWdNjTUbFMQigrseELakGXwPth =args.get('saveInfo')
  OJVzIWdNjTUbFMQigrseELakGXwPxR=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.GetGameVodList(OJVzIWdNjTUbFMQigrseELakGXwPtq)
  for OJVzIWdNjTUbFMQigrseELakGXwPxS in OJVzIWdNjTUbFMQigrseELakGXwPxR:
   OJVzIWdNjTUbFMQigrseELakGXwPxh =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vodTitle')
   OJVzIWdNjTUbFMQigrseELakGXwPxA =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vodId')
   OJVzIWdNjTUbFMQigrseELakGXwPxD =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vodType')
   OJVzIWdNjTUbFMQigrseELakGXwPxy=OJVzIWdNjTUbFMQigrseELakGXwPxS.get('thumbnail')
   OJVzIWdNjTUbFMQigrseELakGXwPxK =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('vtypeId')
   OJVzIWdNjTUbFMQigrseELakGXwPxc =OJVzIWdNjTUbFMQigrseELakGXwPxS.get('duration')
   OJVzIWdNjTUbFMQigrseELakGXwPxB={'mediatype':'episode','duration':OJVzIWdNjTUbFMQigrseELakGXwPxc,'plot':'%s \n\n %s'%(OJVzIWdNjTUbFMQigrseELakGXwPxh,OJVzIWdNjTUbFMQigrseELakGXwPth)}
   OJVzIWdNjTUbFMQigrseELakGXwPxt={'mode':'GAME_VOD','saveTitle':OJVzIWdNjTUbFMQigrseELakGXwPtB,'saveImg':OJVzIWdNjTUbFMQigrseELakGXwPtC,'saveId':OJVzIWdNjTUbFMQigrseELakGXwPtq,'saveInfo':OJVzIWdNjTUbFMQigrseELakGXwPth,'mediacode':OJVzIWdNjTUbFMQigrseELakGXwPxA,'mediatype':'vod','vtypeId':OJVzIWdNjTUbFMQigrseELakGXwPxK}
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPxh,sublabel=OJVzIWdNjTUbFMQigrseELakGXwPxD,img=OJVzIWdNjTUbFMQigrseELakGXwPxy,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPxB,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYc,params=OJVzIWdNjTUbFMQigrseELakGXwPxt)
  xbmcplugin.setContent(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,'episodes')
  xbmcplugin.endOfDirectory(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,cacheToDisc=OJVzIWdNjTUbFMQigrseELakGXwPYc)
 def login_main(OJVzIWdNjTUbFMQigrseELakGXwPmY):
  (OJVzIWdNjTUbFMQigrseELakGXwPtA,OJVzIWdNjTUbFMQigrseELakGXwPtD)=OJVzIWdNjTUbFMQigrseELakGXwPmY.get_settings_account()
  if not(OJVzIWdNjTUbFMQigrseELakGXwPtA and OJVzIWdNjTUbFMQigrseELakGXwPtD):
   OJVzIWdNjTUbFMQigrseELakGXwPmu=xbmcgui.Dialog()
   OJVzIWdNjTUbFMQigrseELakGXwPtK=OJVzIWdNjTUbFMQigrseELakGXwPmu.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if OJVzIWdNjTUbFMQigrseELakGXwPtK==OJVzIWdNjTUbFMQigrseELakGXwPYH:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if OJVzIWdNjTUbFMQigrseELakGXwPmY.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   OJVzIWdNjTUbFMQigrseELakGXwPtc=0
   while OJVzIWdNjTUbFMQigrseELakGXwPYH:
    OJVzIWdNjTUbFMQigrseELakGXwPtc+=1
    time.sleep(0.05)
    if OJVzIWdNjTUbFMQigrseELakGXwPtc>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  OJVzIWdNjTUbFMQigrseELakGXwPtH=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.GetCredential(OJVzIWdNjTUbFMQigrseELakGXwPtA,OJVzIWdNjTUbFMQigrseELakGXwPtD)
  if OJVzIWdNjTUbFMQigrseELakGXwPtH:OJVzIWdNjTUbFMQigrseELakGXwPmY.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
  if OJVzIWdNjTUbFMQigrseELakGXwPtH==OJVzIWdNjTUbFMQigrseELakGXwPYc:
   OJVzIWdNjTUbFMQigrseELakGXwPmY.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_LiveChannel_List(OJVzIWdNjTUbFMQigrseELakGXwPmY,args):
  OJVzIWdNjTUbFMQigrseELakGXwPtv=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.GetLiveChannelList()
  for OJVzIWdNjTUbFMQigrseELakGXwPtl in OJVzIWdNjTUbFMQigrseELakGXwPtv:
   OJVzIWdNjTUbFMQigrseELakGXwPfm =OJVzIWdNjTUbFMQigrseELakGXwPtl.get('id')
   OJVzIWdNjTUbFMQigrseELakGXwPmK =OJVzIWdNjTUbFMQigrseELakGXwPtl.get('name')
   OJVzIWdNjTUbFMQigrseELakGXwPxf =OJVzIWdNjTUbFMQigrseELakGXwPtl.get('programName')
   OJVzIWdNjTUbFMQigrseELakGXwPxy =OJVzIWdNjTUbFMQigrseELakGXwPtl.get('logo')
   OJVzIWdNjTUbFMQigrseELakGXwPtp=OJVzIWdNjTUbFMQigrseELakGXwPtl.get('channelepg')
   OJVzIWdNjTUbFMQigrseELakGXwPnm =OJVzIWdNjTUbFMQigrseELakGXwPtl.get('free')
   OJVzIWdNjTUbFMQigrseELakGXwPnx =OJVzIWdNjTUbFMQigrseELakGXwPtl.get('hlsUrl')
   OJVzIWdNjTUbFMQigrseELakGXwPxB={'plot':'%s\n\n%s'%(OJVzIWdNjTUbFMQigrseELakGXwPmK,OJVzIWdNjTUbFMQigrseELakGXwPtp),'mediatype':'episode',}
   OJVzIWdNjTUbFMQigrseELakGXwPxt={'mode':'LIVE','mediacode':OJVzIWdNjTUbFMQigrseELakGXwPfm,'hlsUrl':OJVzIWdNjTUbFMQigrseELakGXwPnx,'free':OJVzIWdNjTUbFMQigrseELakGXwPnm,'mediatype':'live'}
   if OJVzIWdNjTUbFMQigrseELakGXwPnm:OJVzIWdNjTUbFMQigrseELakGXwPmK+=' [free]'
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPmK,sublabel=OJVzIWdNjTUbFMQigrseELakGXwPxf,img=OJVzIWdNjTUbFMQigrseELakGXwPxy,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPxB,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYc,params=OJVzIWdNjTUbFMQigrseELakGXwPxt)
  xbmcplugin.setContent(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,'episodes')
  if OJVzIWdNjTUbFMQigrseELakGXwPYl(OJVzIWdNjTUbFMQigrseELakGXwPtv)>0:xbmcplugin.endOfDirectory(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,cacheToDisc=OJVzIWdNjTUbFMQigrseELakGXwPYc)
 def dp_EventLiveChannel_List(OJVzIWdNjTUbFMQigrseELakGXwPmY,args):
  OJVzIWdNjTUbFMQigrseELakGXwPtv,OJVzIWdNjTUbFMQigrseELakGXwPnt=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.GetEventLiveList()
  if OJVzIWdNjTUbFMQigrseELakGXwPnt!=401 and OJVzIWdNjTUbFMQigrseELakGXwPYl(OJVzIWdNjTUbFMQigrseELakGXwPtv)==0:
   OJVzIWdNjTUbFMQigrseELakGXwPmY.addon_noti(__language__(30907).encode('utf8'))
  for OJVzIWdNjTUbFMQigrseELakGXwPtl in OJVzIWdNjTUbFMQigrseELakGXwPtv:
   OJVzIWdNjTUbFMQigrseELakGXwPmK =OJVzIWdNjTUbFMQigrseELakGXwPtl.get('title')
   OJVzIWdNjTUbFMQigrseELakGXwPxf =OJVzIWdNjTUbFMQigrseELakGXwPtl.get('startTime')
   OJVzIWdNjTUbFMQigrseELakGXwPxy =OJVzIWdNjTUbFMQigrseELakGXwPtl.get('logo')
   OJVzIWdNjTUbFMQigrseELakGXwPnm =OJVzIWdNjTUbFMQigrseELakGXwPtl.get('free')
   OJVzIWdNjTUbFMQigrseELakGXwPxB={'mediatype':'episode','plot':'%s\n\n%s'%(OJVzIWdNjTUbFMQigrseELakGXwPmK,OJVzIWdNjTUbFMQigrseELakGXwPxf)}
   OJVzIWdNjTUbFMQigrseELakGXwPxt={'mode':'ELIVE','mediacode':OJVzIWdNjTUbFMQigrseELakGXwPtl.get('liveId'),'free':OJVzIWdNjTUbFMQigrseELakGXwPnm,'mediatype':'live'}
   if OJVzIWdNjTUbFMQigrseELakGXwPnm:OJVzIWdNjTUbFMQigrseELakGXwPmK+=' [free]'
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPmK,sublabel=OJVzIWdNjTUbFMQigrseELakGXwPxf,img=OJVzIWdNjTUbFMQigrseELakGXwPxy,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPxB,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYc,params=OJVzIWdNjTUbFMQigrseELakGXwPxt)
  xbmcplugin.setContent(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,'episodes')
  if OJVzIWdNjTUbFMQigrseELakGXwPYl(OJVzIWdNjTUbFMQigrseELakGXwPtv)>0:xbmcplugin.endOfDirectory(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,cacheToDisc=OJVzIWdNjTUbFMQigrseELakGXwPYH)
  return OJVzIWdNjTUbFMQigrseELakGXwPnt
 def play_VIDEO(OJVzIWdNjTUbFMQigrseELakGXwPmY,args):
  OJVzIWdNjTUbFMQigrseELakGXwPnY =args.get('mode')
  OJVzIWdNjTUbFMQigrseELakGXwPnf =args.get('mediacode')
  OJVzIWdNjTUbFMQigrseELakGXwPnR =args.get('mediatype')
  OJVzIWdNjTUbFMQigrseELakGXwPxK =args.get('vtypeId')
  OJVzIWdNjTUbFMQigrseELakGXwPnx =args.get('hlsUrl')
  if OJVzIWdNjTUbFMQigrseELakGXwPnY=='LIVE':
   if args.get('free')=='False':
    if OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.CheckSubEnd()==OJVzIWdNjTUbFMQigrseELakGXwPYc:
     OJVzIWdNjTUbFMQigrseELakGXwPmY.addon_noti(__language__(30908).encode('utf8'))
     return
  elif OJVzIWdNjTUbFMQigrseELakGXwPnY=='ELIVE':
   if args.get('free')=='False':
    if OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.CheckSubEnd()==OJVzIWdNjTUbFMQigrseELakGXwPYc:
     OJVzIWdNjTUbFMQigrseELakGXwPmY.addon_noti(__language__(30908).encode('utf8'))
     return
  if OJVzIWdNjTUbFMQigrseELakGXwPnf=='' or OJVzIWdNjTUbFMQigrseELakGXwPnf==OJVzIWdNjTUbFMQigrseELakGXwPYK:
   OJVzIWdNjTUbFMQigrseELakGXwPmY.addon_noti(__language__(30907).encode('utf8'))
   return
  if OJVzIWdNjTUbFMQigrseELakGXwPnY=='LIVE':
   if OJVzIWdNjTUbFMQigrseELakGXwPnx:
    OJVzIWdNjTUbFMQigrseELakGXwPnS=OJVzIWdNjTUbFMQigrseELakGXwPnx
   else:
    OJVzIWdNjTUbFMQigrseELakGXwPnS=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.GetHlsUrl(OJVzIWdNjTUbFMQigrseELakGXwPnf)
  else:
   OJVzIWdNjTUbFMQigrseELakGXwPnS=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.GetBroadURL(OJVzIWdNjTUbFMQigrseELakGXwPnf,OJVzIWdNjTUbFMQigrseELakGXwPnR,OJVzIWdNjTUbFMQigrseELakGXwPxK)
  if OJVzIWdNjTUbFMQigrseELakGXwPnS=='':
   OJVzIWdNjTUbFMQigrseELakGXwPmY.addon_noti(__language__(30908).encode('utf8'))
   return
  OJVzIWdNjTUbFMQigrseELakGXwPny=OJVzIWdNjTUbFMQigrseELakGXwPnS
  try:
   OJVzIWdNjTUbFMQigrseELakGXwPmY.addon_log('mainMode  = '+OJVzIWdNjTUbFMQigrseELakGXwPnY)
  except:
   OJVzIWdNjTUbFMQigrseELakGXwPYK
  OJVzIWdNjTUbFMQigrseELakGXwPmY.addon_log(OJVzIWdNjTUbFMQigrseELakGXwPny)
  OJVzIWdNjTUbFMQigrseELakGXwPnu=xbmcgui.ListItem(path=OJVzIWdNjTUbFMQigrseELakGXwPny)
  xbmcplugin.setResolvedUrl(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,OJVzIWdNjTUbFMQigrseELakGXwPYH,OJVzIWdNjTUbFMQigrseELakGXwPnu)
  try:
   if OJVzIWdNjTUbFMQigrseELakGXwPnR=='vod' and OJVzIWdNjTUbFMQigrseELakGXwPnY not in['POP_VOD','NOW_VOD']:
    OJVzIWdNjTUbFMQigrseELakGXwPxt={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    OJVzIWdNjTUbFMQigrseELakGXwPmY.Save_Watched_List(OJVzIWdNjTUbFMQigrseELakGXwPnR,OJVzIWdNjTUbFMQigrseELakGXwPxt)
  except:
   OJVzIWdNjTUbFMQigrseELakGXwPYK
 def logout(OJVzIWdNjTUbFMQigrseELakGXwPmY):
  OJVzIWdNjTUbFMQigrseELakGXwPmu=xbmcgui.Dialog()
  OJVzIWdNjTUbFMQigrseELakGXwPtK=OJVzIWdNjTUbFMQigrseELakGXwPmu.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if OJVzIWdNjTUbFMQigrseELakGXwPtK==OJVzIWdNjTUbFMQigrseELakGXwPYc:sys.exit()
  OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.Init_ST_Total()
  if os.path.isfile(OJVzIWdNjTUbFMQigrseELakGXwPmn):os.remove(OJVzIWdNjTUbFMQigrseELakGXwPmn)
  OJVzIWdNjTUbFMQigrseELakGXwPmY.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(OJVzIWdNjTUbFMQigrseELakGXwPmY):
  OJVzIWdNjTUbFMQigrseELakGXwPno =OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.Get_Now_Datetime()
  OJVzIWdNjTUbFMQigrseELakGXwPnB=OJVzIWdNjTUbFMQigrseELakGXwPno+datetime.timedelta(days=OJVzIWdNjTUbFMQigrseELakGXwPYv(__addon__.getSetting('cache_ttl')))
  (OJVzIWdNjTUbFMQigrseELakGXwPtA,OJVzIWdNjTUbFMQigrseELakGXwPtD)=OJVzIWdNjTUbFMQigrseELakGXwPmY.get_settings_account()
  OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.Save_session_acount(OJVzIWdNjTUbFMQigrseELakGXwPtA,OJVzIWdNjTUbFMQigrseELakGXwPtD)
  OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.ST['account']['token_limit']=OJVzIWdNjTUbFMQigrseELakGXwPnB.strftime('%Y%m%d')
  OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.JsonFile_Save(OJVzIWdNjTUbFMQigrseELakGXwPmn,OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.ST)
 def cookiefile_check(OJVzIWdNjTUbFMQigrseELakGXwPmY):
  OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.ST=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.JsonFile_Load(OJVzIWdNjTUbFMQigrseELakGXwPmn)
  if 'account' not in OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.ST:
   OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.Init_ST_Total()
   return OJVzIWdNjTUbFMQigrseELakGXwPYc
  (OJVzIWdNjTUbFMQigrseELakGXwPnq,OJVzIWdNjTUbFMQigrseELakGXwPnC)=OJVzIWdNjTUbFMQigrseELakGXwPmY.get_settings_account()
  (OJVzIWdNjTUbFMQigrseELakGXwPnh,OJVzIWdNjTUbFMQigrseELakGXwPnA)=OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.Load_session_acount()
  if OJVzIWdNjTUbFMQigrseELakGXwPnq!=OJVzIWdNjTUbFMQigrseELakGXwPnh or OJVzIWdNjTUbFMQigrseELakGXwPnC!=OJVzIWdNjTUbFMQigrseELakGXwPnA:
   OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.Init_ST_Total()
   return OJVzIWdNjTUbFMQigrseELakGXwPYc
  if OJVzIWdNjTUbFMQigrseELakGXwPYv(OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))>OJVzIWdNjTUbFMQigrseELakGXwPYv(OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.ST['account']['token_limit']):
   OJVzIWdNjTUbFMQigrseELakGXwPmY.SpotvObj.Init_ST_Total()
   return OJVzIWdNjTUbFMQigrseELakGXwPYc
  return OJVzIWdNjTUbFMQigrseELakGXwPYH
 def dp_History_Remove(OJVzIWdNjTUbFMQigrseELakGXwPmY,args):
  OJVzIWdNjTUbFMQigrseELakGXwPnD=args.get('delType')
  OJVzIWdNjTUbFMQigrseELakGXwPnK =args.get('sKey')
  OJVzIWdNjTUbFMQigrseELakGXwPnc =args.get('vType')
  OJVzIWdNjTUbFMQigrseELakGXwPmu=xbmcgui.Dialog()
  if OJVzIWdNjTUbFMQigrseELakGXwPnD=='WATCH_ALL':
   OJVzIWdNjTUbFMQigrseELakGXwPtK=OJVzIWdNjTUbFMQigrseELakGXwPmu.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif OJVzIWdNjTUbFMQigrseELakGXwPnD=='WATCH_ONE':
   OJVzIWdNjTUbFMQigrseELakGXwPtK=OJVzIWdNjTUbFMQigrseELakGXwPmu.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  if OJVzIWdNjTUbFMQigrseELakGXwPtK==OJVzIWdNjTUbFMQigrseELakGXwPYc:sys.exit()
  if OJVzIWdNjTUbFMQigrseELakGXwPnD=='WATCH_ALL':
   OJVzIWdNjTUbFMQigrseELakGXwPnH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%OJVzIWdNjTUbFMQigrseELakGXwPnc))
   if os.path.isfile(OJVzIWdNjTUbFMQigrseELakGXwPnH):os.remove(OJVzIWdNjTUbFMQigrseELakGXwPnH)
  elif OJVzIWdNjTUbFMQigrseELakGXwPnD=='WATCH_ONE':
   OJVzIWdNjTUbFMQigrseELakGXwPnH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%OJVzIWdNjTUbFMQigrseELakGXwPnc))
   try:
    OJVzIWdNjTUbFMQigrseELakGXwPnv=OJVzIWdNjTUbFMQigrseELakGXwPmY.Load_List_File(OJVzIWdNjTUbFMQigrseELakGXwPnc) 
    fp=OJVzIWdNjTUbFMQigrseELakGXwPfx(OJVzIWdNjTUbFMQigrseELakGXwPnH,'w',-1,'utf-8')
    for OJVzIWdNjTUbFMQigrseELakGXwPnl in OJVzIWdNjTUbFMQigrseELakGXwPnv:
     OJVzIWdNjTUbFMQigrseELakGXwPnp=OJVzIWdNjTUbFMQigrseELakGXwPft(urllib.parse.parse_qsl(OJVzIWdNjTUbFMQigrseELakGXwPnl))
     OJVzIWdNjTUbFMQigrseELakGXwPYm=OJVzIWdNjTUbFMQigrseELakGXwPnp.get('code').strip()
     if OJVzIWdNjTUbFMQigrseELakGXwPnK!=OJVzIWdNjTUbFMQigrseELakGXwPYm:
      fp.write(OJVzIWdNjTUbFMQigrseELakGXwPnl)
    fp.close()
   except:
    OJVzIWdNjTUbFMQigrseELakGXwPYK
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(OJVzIWdNjTUbFMQigrseELakGXwPmY,OJVzIWdNjTUbFMQigrseELakGXwPnR):
  try:
   OJVzIWdNjTUbFMQigrseELakGXwPYx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%OJVzIWdNjTUbFMQigrseELakGXwPnR))
   fp=OJVzIWdNjTUbFMQigrseELakGXwPfx(OJVzIWdNjTUbFMQigrseELakGXwPYx,'r',-1,'utf-8')
   OJVzIWdNjTUbFMQigrseELakGXwPYt=fp.readlines()
   fp.close()
  except:
   OJVzIWdNjTUbFMQigrseELakGXwPYt=[]
  return OJVzIWdNjTUbFMQigrseELakGXwPYt
 def Save_Watched_List(OJVzIWdNjTUbFMQigrseELakGXwPmY,stype,OJVzIWdNjTUbFMQigrseELakGXwPmS):
  try:
   OJVzIWdNjTUbFMQigrseELakGXwPYx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   OJVzIWdNjTUbFMQigrseELakGXwPnv=OJVzIWdNjTUbFMQigrseELakGXwPmY.Load_List_File(stype) 
   fp=OJVzIWdNjTUbFMQigrseELakGXwPfx(OJVzIWdNjTUbFMQigrseELakGXwPYx,'w',-1,'utf-8')
   OJVzIWdNjTUbFMQigrseELakGXwPYn=urllib.parse.urlencode(OJVzIWdNjTUbFMQigrseELakGXwPmS)
   OJVzIWdNjTUbFMQigrseELakGXwPYn=OJVzIWdNjTUbFMQigrseELakGXwPYn+'\n'
   fp.write(OJVzIWdNjTUbFMQigrseELakGXwPYn)
   OJVzIWdNjTUbFMQigrseELakGXwPYf=0
   for OJVzIWdNjTUbFMQigrseELakGXwPnl in OJVzIWdNjTUbFMQigrseELakGXwPnv:
    OJVzIWdNjTUbFMQigrseELakGXwPnp=OJVzIWdNjTUbFMQigrseELakGXwPft(urllib.parse.parse_qsl(OJVzIWdNjTUbFMQigrseELakGXwPnl))
    OJVzIWdNjTUbFMQigrseELakGXwPYR=OJVzIWdNjTUbFMQigrseELakGXwPmS.get('code')
    OJVzIWdNjTUbFMQigrseELakGXwPYS=OJVzIWdNjTUbFMQigrseELakGXwPnp.get('code')
    if OJVzIWdNjTUbFMQigrseELakGXwPYR!=OJVzIWdNjTUbFMQigrseELakGXwPYS:
     fp.write(OJVzIWdNjTUbFMQigrseELakGXwPnl)
     OJVzIWdNjTUbFMQigrseELakGXwPYf+=1
     if OJVzIWdNjTUbFMQigrseELakGXwPYf>=50:break
   fp.close()
  except:
   OJVzIWdNjTUbFMQigrseELakGXwPYK
 def dp_Watch_List(OJVzIWdNjTUbFMQigrseELakGXwPmY,args):
  OJVzIWdNjTUbFMQigrseELakGXwPnR ='vod'
  if OJVzIWdNjTUbFMQigrseELakGXwPnR=='vod':
   OJVzIWdNjTUbFMQigrseELakGXwPYy=OJVzIWdNjTUbFMQigrseELakGXwPmY.Load_List_File(OJVzIWdNjTUbFMQigrseELakGXwPnR)
   for OJVzIWdNjTUbFMQigrseELakGXwPYu in OJVzIWdNjTUbFMQigrseELakGXwPYy:
    OJVzIWdNjTUbFMQigrseELakGXwPYo=OJVzIWdNjTUbFMQigrseELakGXwPft(urllib.parse.parse_qsl(OJVzIWdNjTUbFMQigrseELakGXwPYu))
    OJVzIWdNjTUbFMQigrseELakGXwPmK =OJVzIWdNjTUbFMQigrseELakGXwPYo.get('title')
    OJVzIWdNjTUbFMQigrseELakGXwPxy=OJVzIWdNjTUbFMQigrseELakGXwPYo.get('img')
    OJVzIWdNjTUbFMQigrseELakGXwPnf=OJVzIWdNjTUbFMQigrseELakGXwPYo.get('code')
    OJVzIWdNjTUbFMQigrseELakGXwPYB =OJVzIWdNjTUbFMQigrseELakGXwPYo.get('info')
    OJVzIWdNjTUbFMQigrseELakGXwPxB={}
    OJVzIWdNjTUbFMQigrseELakGXwPxB['plot'] =OJVzIWdNjTUbFMQigrseELakGXwPYB
    OJVzIWdNjTUbFMQigrseELakGXwPxB['mediatype']='tvshow'
    OJVzIWdNjTUbFMQigrseELakGXwPxt={'mode':'GAME_VOD_GROUP','gameid':OJVzIWdNjTUbFMQigrseELakGXwPnf,'saveTitle':OJVzIWdNjTUbFMQigrseELakGXwPmK,'saveImg':OJVzIWdNjTUbFMQigrseELakGXwPxy,'saveInfo':OJVzIWdNjTUbFMQigrseELakGXwPYB,'mediatype':OJVzIWdNjTUbFMQigrseELakGXwPnR}
    OJVzIWdNjTUbFMQigrseELakGXwPYq={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':OJVzIWdNjTUbFMQigrseELakGXwPnf,'vType':OJVzIWdNjTUbFMQigrseELakGXwPnR,}
    OJVzIWdNjTUbFMQigrseELakGXwPYC=urllib.parse.urlencode(OJVzIWdNjTUbFMQigrseELakGXwPYq)
    OJVzIWdNjTUbFMQigrseELakGXwPYh=[('선택된 시청이력 ( %s ) 삭제'%(OJVzIWdNjTUbFMQigrseELakGXwPmK),'RunPlugin(plugin://plugin.video.spotvm/?%s)'%(OJVzIWdNjTUbFMQigrseELakGXwPYC))]
    OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPmK,sublabel='',img=OJVzIWdNjTUbFMQigrseELakGXwPxy,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPxB,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYH,params=OJVzIWdNjTUbFMQigrseELakGXwPxt,ContextMenu=OJVzIWdNjTUbFMQigrseELakGXwPYh)
   OJVzIWdNjTUbFMQigrseELakGXwPxB={'plot':'시청목록을 삭제합니다.'}
   OJVzIWdNjTUbFMQigrseELakGXwPmK='*** 시청목록 삭제 ***'
   OJVzIWdNjTUbFMQigrseELakGXwPxt={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':OJVzIWdNjTUbFMQigrseELakGXwPnR,}
   OJVzIWdNjTUbFMQigrseELakGXwPxm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   OJVzIWdNjTUbFMQigrseELakGXwPmY.add_dir(OJVzIWdNjTUbFMQigrseELakGXwPmK,sublabel='',img=OJVzIWdNjTUbFMQigrseELakGXwPxm,infoLabels=OJVzIWdNjTUbFMQigrseELakGXwPxB,isFolder=OJVzIWdNjTUbFMQigrseELakGXwPYc,params=OJVzIWdNjTUbFMQigrseELakGXwPxt,isLink=OJVzIWdNjTUbFMQigrseELakGXwPYH)
   xbmcplugin.endOfDirectory(OJVzIWdNjTUbFMQigrseELakGXwPmY._addon_handle,cacheToDisc=OJVzIWdNjTUbFMQigrseELakGXwPYc)
 def spotv_main(OJVzIWdNjTUbFMQigrseELakGXwPmY):
  OJVzIWdNjTUbFMQigrseELakGXwPYA=OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params.get('mode',OJVzIWdNjTUbFMQigrseELakGXwPYK)
  if OJVzIWdNjTUbFMQigrseELakGXwPYA=='LOGOUT':
   OJVzIWdNjTUbFMQigrseELakGXwPmY.logout()
   return
  OJVzIWdNjTUbFMQigrseELakGXwPmY.login_main()
  if OJVzIWdNjTUbFMQigrseELakGXwPYA is OJVzIWdNjTUbFMQigrseELakGXwPYK:
   OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_Main_List()
  elif OJVzIWdNjTUbFMQigrseELakGXwPYA=='LIVE_GROUP':
   OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_LiveChannel_List(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
  elif OJVzIWdNjTUbFMQigrseELakGXwPYA=='ELIVE_GROUP':
   OJVzIWdNjTUbFMQigrseELakGXwPnt=OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_EventLiveChannel_List(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
   if OJVzIWdNjTUbFMQigrseELakGXwPnt==401:
    if os.path.isfile(OJVzIWdNjTUbFMQigrseELakGXwPmn):os.remove(OJVzIWdNjTUbFMQigrseELakGXwPmn)
    OJVzIWdNjTUbFMQigrseELakGXwPmY.login_main()
    OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_EventLiveChannel_List(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
  elif OJVzIWdNjTUbFMQigrseELakGXwPYA in['LIVE','GAME_VOD','POP_VOD','NOW_VOD','ELIVE']:
   OJVzIWdNjTUbFMQigrseELakGXwPmY.play_VIDEO(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
  elif OJVzIWdNjTUbFMQigrseELakGXwPYA=='VOD_GROUP':
   OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_MainLeague_List(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
  elif OJVzIWdNjTUbFMQigrseELakGXwPYA=='NOW_GROUP':
   OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_NowVod_GroupList(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
  elif OJVzIWdNjTUbFMQigrseELakGXwPYA=='POP_GROUP':
   OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_PopVod_GroupList(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
  elif OJVzIWdNjTUbFMQigrseELakGXwPYA=='LEAGUE_GROUP':
   OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_Season_List(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
  elif OJVzIWdNjTUbFMQigrseELakGXwPYA=='SEASON_GROUP':
   OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_Game_List(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
  elif OJVzIWdNjTUbFMQigrseELakGXwPYA=='GAME_VOD_GROUP':
   OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_GameVod_List(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
  elif OJVzIWdNjTUbFMQigrseELakGXwPYA=='WATCH':
   OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_Watch_List(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
  elif OJVzIWdNjTUbFMQigrseELakGXwPYA=='MYVIEW_REMOVE':
   OJVzIWdNjTUbFMQigrseELakGXwPmY.dp_History_Remove(OJVzIWdNjTUbFMQigrseELakGXwPmY.main_params)
  else:
   OJVzIWdNjTUbFMQigrseELakGXwPYK
# Created by pyminifier (https://github.com/liftoff/pyminifier)
