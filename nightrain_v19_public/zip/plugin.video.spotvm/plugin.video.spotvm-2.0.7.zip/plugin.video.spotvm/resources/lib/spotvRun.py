__author__="NightRain"
AjrmvpLygwSHqKnYVDoTabzfukisCW=object
AjrmvpLygwSHqKnYVDoTabzfukisCN=None
AjrmvpLygwSHqKnYVDoTabzfukisCM=True
AjrmvpLygwSHqKnYVDoTabzfukisCO=int
AjrmvpLygwSHqKnYVDoTabzfukisCP=False
AjrmvpLygwSHqKnYVDoTabzfukisCx=len
AjrmvpLygwSHqKnYVDoTabzfukisCI=str
AjrmvpLygwSHqKnYVDoTabzfukisCX=open
AjrmvpLygwSHqKnYVDoTabzfukisCJ=Exception
AjrmvpLygwSHqKnYVDoTabzfukisCG=print
AjrmvpLygwSHqKnYVDoTabzfukisCB=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
AjrmvpLygwSHqKnYVDoTabzfukisdQ=[{'title':'TV 채널','mode':'LIVE_GROUP'},{'title':'Live중계 (독점,현지)','mode':'ELIVE_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'인기영상5','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH'}]
AjrmvpLygwSHqKnYVDoTabzfukisdW ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
AjrmvpLygwSHqKnYVDoTabzfukisdC=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class AjrmvpLygwSHqKnYVDoTabzfukisdh(AjrmvpLygwSHqKnYVDoTabzfukisCW):
 def __init__(AjrmvpLygwSHqKnYVDoTabzfukisdN,AjrmvpLygwSHqKnYVDoTabzfukisdM,AjrmvpLygwSHqKnYVDoTabzfukisdO,AjrmvpLygwSHqKnYVDoTabzfukisdP):
  AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_url =AjrmvpLygwSHqKnYVDoTabzfukisdM
  AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle=AjrmvpLygwSHqKnYVDoTabzfukisdO
  AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params =AjrmvpLygwSHqKnYVDoTabzfukisdP
  AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj =KgRnduCXGceFTfbrkQpiljNymIaHMo() 
 def addon_noti(AjrmvpLygwSHqKnYVDoTabzfukisdN,sting):
  try:
   AjrmvpLygwSHqKnYVDoTabzfukisdI=xbmcgui.Dialog()
   AjrmvpLygwSHqKnYVDoTabzfukisdI.notification(__addonname__,sting)
  except:
   AjrmvpLygwSHqKnYVDoTabzfukisCN
 def addon_log(AjrmvpLygwSHqKnYVDoTabzfukisdN,string):
  try:
   AjrmvpLygwSHqKnYVDoTabzfukisdX=string.encode('utf-8','ignore')
  except:
   AjrmvpLygwSHqKnYVDoTabzfukisdX='addonException: addon_log'
  AjrmvpLygwSHqKnYVDoTabzfukisdJ=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,AjrmvpLygwSHqKnYVDoTabzfukisdX),level=AjrmvpLygwSHqKnYVDoTabzfukisdJ)
 def get_keyboard_input(AjrmvpLygwSHqKnYVDoTabzfukisdN,AjrmvpLygwSHqKnYVDoTabzfukisdR):
  AjrmvpLygwSHqKnYVDoTabzfukisdG=AjrmvpLygwSHqKnYVDoTabzfukisCN
  kb=xbmc.Keyboard()
  kb.setHeading(AjrmvpLygwSHqKnYVDoTabzfukisdR)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   AjrmvpLygwSHqKnYVDoTabzfukisdG=kb.getText()
  return AjrmvpLygwSHqKnYVDoTabzfukisdG
 def get_settings_login_info(AjrmvpLygwSHqKnYVDoTabzfukisdN):
  AjrmvpLygwSHqKnYVDoTabzfukisdB =__addon__.getSetting('id')
  AjrmvpLygwSHqKnYVDoTabzfukisdE =__addon__.getSetting('pw')
  return(AjrmvpLygwSHqKnYVDoTabzfukisdB,AjrmvpLygwSHqKnYVDoTabzfukisdE)
 def set_winCredential(AjrmvpLygwSHqKnYVDoTabzfukisdN,credential):
  AjrmvpLygwSHqKnYVDoTabzfukisdt=xbmcgui.Window(10000)
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_LOGINTIME',AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(AjrmvpLygwSHqKnYVDoTabzfukisdN):
  AjrmvpLygwSHqKnYVDoTabzfukisdt=xbmcgui.Window(10000)
  AjrmvpLygwSHqKnYVDoTabzfukisdl={'spotv_sessionid':AjrmvpLygwSHqKnYVDoTabzfukisdt.getProperty('SPOTV_M_SESSIONID'),'spotv_session':AjrmvpLygwSHqKnYVDoTabzfukisdt.getProperty('SPOTV_M_SESSION'),'spotv_accountId':AjrmvpLygwSHqKnYVDoTabzfukisdt.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':AjrmvpLygwSHqKnYVDoTabzfukisdt.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':AjrmvpLygwSHqKnYVDoTabzfukisdt.getProperty('SPOTV_M_SUBEND')}
  return AjrmvpLygwSHqKnYVDoTabzfukisdl
 def add_dir(AjrmvpLygwSHqKnYVDoTabzfukisdN,label,sublabel='',img='',infoLabels=AjrmvpLygwSHqKnYVDoTabzfukisCN,isFolder=AjrmvpLygwSHqKnYVDoTabzfukisCM,params=''):
  AjrmvpLygwSHqKnYVDoTabzfukisdc='%s?%s'%(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_url,urllib.parse.urlencode(params))
  if sublabel:AjrmvpLygwSHqKnYVDoTabzfukisdR='%s < %s >'%(label,sublabel)
  else: AjrmvpLygwSHqKnYVDoTabzfukisdR=label
  if not img:img='DefaultFolder.png'
  AjrmvpLygwSHqKnYVDoTabzfukisdF=xbmcgui.ListItem(AjrmvpLygwSHqKnYVDoTabzfukisdR)
  AjrmvpLygwSHqKnYVDoTabzfukisdF.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:AjrmvpLygwSHqKnYVDoTabzfukisdF.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:AjrmvpLygwSHqKnYVDoTabzfukisdF.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle,AjrmvpLygwSHqKnYVDoTabzfukisdc,AjrmvpLygwSHqKnYVDoTabzfukisdF,isFolder)
 def get_selQuality(AjrmvpLygwSHqKnYVDoTabzfukisdN,etype):
  try:
   AjrmvpLygwSHqKnYVDoTabzfukisde='selected_quality'
   AjrmvpLygwSHqKnYVDoTabzfukisdU=[1080,720,540]
   AjrmvpLygwSHqKnYVDoTabzfukishd=AjrmvpLygwSHqKnYVDoTabzfukisCO(__addon__.getSetting(AjrmvpLygwSHqKnYVDoTabzfukisde))
   return AjrmvpLygwSHqKnYVDoTabzfukisdU[AjrmvpLygwSHqKnYVDoTabzfukishd]
  except:
   AjrmvpLygwSHqKnYVDoTabzfukisCN
  return 1080 
 def dp_Main_List(AjrmvpLygwSHqKnYVDoTabzfukisdN):
  for AjrmvpLygwSHqKnYVDoTabzfukishQ in AjrmvpLygwSHqKnYVDoTabzfukisdQ:
   AjrmvpLygwSHqKnYVDoTabzfukisdR=AjrmvpLygwSHqKnYVDoTabzfukishQ.get('title')
   AjrmvpLygwSHqKnYVDoTabzfukishW={'mode':AjrmvpLygwSHqKnYVDoTabzfukishQ.get('mode')}
   if AjrmvpLygwSHqKnYVDoTabzfukishQ.get('mode')=='XXX':
    AjrmvpLygwSHqKnYVDoTabzfukishC=AjrmvpLygwSHqKnYVDoTabzfukisCP
   else:
    AjrmvpLygwSHqKnYVDoTabzfukishC=AjrmvpLygwSHqKnYVDoTabzfukisCM
   AjrmvpLygwSHqKnYVDoTabzfukisdN.add_dir(AjrmvpLygwSHqKnYVDoTabzfukisdR,sublabel='',img='',infoLabels=AjrmvpLygwSHqKnYVDoTabzfukisCN,isFolder=AjrmvpLygwSHqKnYVDoTabzfukishC,params=AjrmvpLygwSHqKnYVDoTabzfukishW)
  if AjrmvpLygwSHqKnYVDoTabzfukisCx(AjrmvpLygwSHqKnYVDoTabzfukisdQ)>0:xbmcplugin.endOfDirectory(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle)
 def dp_MainLeague_List(AjrmvpLygwSHqKnYVDoTabzfukisdN,args):
  AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.SaveCredential(AjrmvpLygwSHqKnYVDoTabzfukisdN.get_winCredential())
  AjrmvpLygwSHqKnYVDoTabzfukishM=AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.GetTitleGroupList()
  for AjrmvpLygwSHqKnYVDoTabzfukishO in AjrmvpLygwSHqKnYVDoTabzfukishM:
   AjrmvpLygwSHqKnYVDoTabzfukisdR =AjrmvpLygwSHqKnYVDoTabzfukishO.get('title')
   AjrmvpLygwSHqKnYVDoTabzfukishP =AjrmvpLygwSHqKnYVDoTabzfukishO.get('logo')
   AjrmvpLygwSHqKnYVDoTabzfukishx =AjrmvpLygwSHqKnYVDoTabzfukishO.get('reagueId')
   AjrmvpLygwSHqKnYVDoTabzfukishI =AjrmvpLygwSHqKnYVDoTabzfukishO.get('subGame')
   AjrmvpLygwSHqKnYVDoTabzfukishX=AjrmvpLygwSHqKnYVDoTabzfukishO.get('info')
   AjrmvpLygwSHqKnYVDoTabzfukishX['plot']='%s\n\n%s'%(AjrmvpLygwSHqKnYVDoTabzfukisdR,AjrmvpLygwSHqKnYVDoTabzfukishI)
   AjrmvpLygwSHqKnYVDoTabzfukishW={'mode':'LEAGUE_GROUP','reagueId':AjrmvpLygwSHqKnYVDoTabzfukishx}
   AjrmvpLygwSHqKnYVDoTabzfukisdN.add_dir(AjrmvpLygwSHqKnYVDoTabzfukisdR,sublabel=AjrmvpLygwSHqKnYVDoTabzfukisCN,img=AjrmvpLygwSHqKnYVDoTabzfukishP,infoLabels=AjrmvpLygwSHqKnYVDoTabzfukishX,isFolder=AjrmvpLygwSHqKnYVDoTabzfukisCM,params=AjrmvpLygwSHqKnYVDoTabzfukishW)
  if AjrmvpLygwSHqKnYVDoTabzfukisCx(AjrmvpLygwSHqKnYVDoTabzfukishM)>0:xbmcplugin.endOfDirectory(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle,cacheToDisc=AjrmvpLygwSHqKnYVDoTabzfukisCP)
 def dp_PopVod_GroupList(AjrmvpLygwSHqKnYVDoTabzfukisdN,args):
  AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.SaveCredential(AjrmvpLygwSHqKnYVDoTabzfukisdN.get_winCredential())
  AjrmvpLygwSHqKnYVDoTabzfukishM=AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.GetPopularGroupList()
  for AjrmvpLygwSHqKnYVDoTabzfukishO in AjrmvpLygwSHqKnYVDoTabzfukishM:
   AjrmvpLygwSHqKnYVDoTabzfukishJ =AjrmvpLygwSHqKnYVDoTabzfukishO.get('vodTitle')
   AjrmvpLygwSHqKnYVDoTabzfukishG =AjrmvpLygwSHqKnYVDoTabzfukishO.get('vodId')
   AjrmvpLygwSHqKnYVDoTabzfukishB =AjrmvpLygwSHqKnYVDoTabzfukishO.get('vodType')
   AjrmvpLygwSHqKnYVDoTabzfukishP=AjrmvpLygwSHqKnYVDoTabzfukishO.get('thumbnail')
   AjrmvpLygwSHqKnYVDoTabzfukishE =AjrmvpLygwSHqKnYVDoTabzfukishO.get('vtypeId')
   AjrmvpLygwSHqKnYVDoTabzfukishX=AjrmvpLygwSHqKnYVDoTabzfukishO.get('info')
   AjrmvpLygwSHqKnYVDoTabzfukishX['plot']=AjrmvpLygwSHqKnYVDoTabzfukishJ
   AjrmvpLygwSHqKnYVDoTabzfukishW={'mode':'POP_VOD','mediacode':AjrmvpLygwSHqKnYVDoTabzfukishG,'mediatype':'vod','vtypeId':AjrmvpLygwSHqKnYVDoTabzfukishE}
   AjrmvpLygwSHqKnYVDoTabzfukisdN.add_dir(AjrmvpLygwSHqKnYVDoTabzfukishJ,sublabel=AjrmvpLygwSHqKnYVDoTabzfukishB,img=AjrmvpLygwSHqKnYVDoTabzfukishP,infoLabels=AjrmvpLygwSHqKnYVDoTabzfukishX,isFolder=AjrmvpLygwSHqKnYVDoTabzfukisCP,params=AjrmvpLygwSHqKnYVDoTabzfukishW)
  if AjrmvpLygwSHqKnYVDoTabzfukisCx(AjrmvpLygwSHqKnYVDoTabzfukishM)>0:xbmcplugin.endOfDirectory(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle,cacheToDisc=AjrmvpLygwSHqKnYVDoTabzfukisCP)
 def dp_Season_List(AjrmvpLygwSHqKnYVDoTabzfukisdN,args):
  AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.SaveCredential(AjrmvpLygwSHqKnYVDoTabzfukisdN.get_winCredential())
  AjrmvpLygwSHqKnYVDoTabzfukishx=args.get('reagueId')
  AjrmvpLygwSHqKnYVDoTabzfukishM=AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.GetSeasonList(AjrmvpLygwSHqKnYVDoTabzfukishx)
  for AjrmvpLygwSHqKnYVDoTabzfukishO in AjrmvpLygwSHqKnYVDoTabzfukishM:
   AjrmvpLygwSHqKnYVDoTabzfukisht =AjrmvpLygwSHqKnYVDoTabzfukishO.get('reagueName')
   AjrmvpLygwSHqKnYVDoTabzfukishl =AjrmvpLygwSHqKnYVDoTabzfukishO.get('gameTypeId')
   AjrmvpLygwSHqKnYVDoTabzfukishc =AjrmvpLygwSHqKnYVDoTabzfukishO.get('seasonName')
   AjrmvpLygwSHqKnYVDoTabzfukishR =AjrmvpLygwSHqKnYVDoTabzfukishO.get('seasonId')
   AjrmvpLygwSHqKnYVDoTabzfukishX=AjrmvpLygwSHqKnYVDoTabzfukishO.get('info')
   AjrmvpLygwSHqKnYVDoTabzfukishX['plot']='%s - %s'%(AjrmvpLygwSHqKnYVDoTabzfukisht,AjrmvpLygwSHqKnYVDoTabzfukishc)
   AjrmvpLygwSHqKnYVDoTabzfukishW={'mode':'SEASON_GROUP','reagueId':AjrmvpLygwSHqKnYVDoTabzfukishx,'seasonId':AjrmvpLygwSHqKnYVDoTabzfukishR,'gameTypeId':AjrmvpLygwSHqKnYVDoTabzfukishl,'page':'1'}
   AjrmvpLygwSHqKnYVDoTabzfukisdN.add_dir(AjrmvpLygwSHqKnYVDoTabzfukisht,sublabel=AjrmvpLygwSHqKnYVDoTabzfukishc,img='',infoLabels=AjrmvpLygwSHqKnYVDoTabzfukishX,isFolder=AjrmvpLygwSHqKnYVDoTabzfukisCM,params=AjrmvpLygwSHqKnYVDoTabzfukishW)
  if AjrmvpLygwSHqKnYVDoTabzfukisCx(AjrmvpLygwSHqKnYVDoTabzfukishM)>0:xbmcplugin.endOfDirectory(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle,cacheToDisc=AjrmvpLygwSHqKnYVDoTabzfukisCM)
 def dp_Game_List(AjrmvpLygwSHqKnYVDoTabzfukisdN,args):
  AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.SaveCredential(AjrmvpLygwSHqKnYVDoTabzfukisdN.get_winCredential())
  AjrmvpLygwSHqKnYVDoTabzfukishl=args.get('gameTypeId')
  AjrmvpLygwSHqKnYVDoTabzfukishx =args.get('reagueId')
  AjrmvpLygwSHqKnYVDoTabzfukishR =args.get('seasonId')
  AjrmvpLygwSHqKnYVDoTabzfukishF =AjrmvpLygwSHqKnYVDoTabzfukisCO(args.get('page'))
  AjrmvpLygwSHqKnYVDoTabzfukishM,AjrmvpLygwSHqKnYVDoTabzfukishe=AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.GetGameList(AjrmvpLygwSHqKnYVDoTabzfukishl,AjrmvpLygwSHqKnYVDoTabzfukishx,AjrmvpLygwSHqKnYVDoTabzfukishR,AjrmvpLygwSHqKnYVDoTabzfukishF)
  for AjrmvpLygwSHqKnYVDoTabzfukishO in AjrmvpLygwSHqKnYVDoTabzfukishM:
   AjrmvpLygwSHqKnYVDoTabzfukishU =AjrmvpLygwSHqKnYVDoTabzfukishO.get('gameTitle')
   AjrmvpLygwSHqKnYVDoTabzfukisQd =AjrmvpLygwSHqKnYVDoTabzfukishO.get('beginDate')
   AjrmvpLygwSHqKnYVDoTabzfukishP =AjrmvpLygwSHqKnYVDoTabzfukishO.get('thumbnail')
   AjrmvpLygwSHqKnYVDoTabzfukisQh =AjrmvpLygwSHqKnYVDoTabzfukishO.get('gameId')
   AjrmvpLygwSHqKnYVDoTabzfukisQW =AjrmvpLygwSHqKnYVDoTabzfukishO.get('totVodCnt')
   AjrmvpLygwSHqKnYVDoTabzfukisQC =AjrmvpLygwSHqKnYVDoTabzfukishO.get('leaguenm')
   AjrmvpLygwSHqKnYVDoTabzfukisQN =AjrmvpLygwSHqKnYVDoTabzfukishO.get('seasonnm')
   AjrmvpLygwSHqKnYVDoTabzfukisQM =AjrmvpLygwSHqKnYVDoTabzfukishO.get('roundnm')
   AjrmvpLygwSHqKnYVDoTabzfukisQO ='%s < %s >'%(AjrmvpLygwSHqKnYVDoTabzfukishU,AjrmvpLygwSHqKnYVDoTabzfukisQd)
   AjrmvpLygwSHqKnYVDoTabzfukishX=AjrmvpLygwSHqKnYVDoTabzfukishO.get('info')
   AjrmvpLygwSHqKnYVDoTabzfukishW={'mode':'GAME_VOD_GROUP' if AjrmvpLygwSHqKnYVDoTabzfukisQW!=0 else 'XXX','saveTitle':AjrmvpLygwSHqKnYVDoTabzfukisQO,'saveImg':AjrmvpLygwSHqKnYVDoTabzfukishP,'saveInfo':AjrmvpLygwSHqKnYVDoTabzfukishX['plot'],'gameid':AjrmvpLygwSHqKnYVDoTabzfukisQh}
   AjrmvpLygwSHqKnYVDoTabzfukisdN.add_dir(AjrmvpLygwSHqKnYVDoTabzfukishU,sublabel=AjrmvpLygwSHqKnYVDoTabzfukisQd,img=AjrmvpLygwSHqKnYVDoTabzfukishP,infoLabels=AjrmvpLygwSHqKnYVDoTabzfukishX,isFolder=AjrmvpLygwSHqKnYVDoTabzfukisCM,params=AjrmvpLygwSHqKnYVDoTabzfukishW)
  if AjrmvpLygwSHqKnYVDoTabzfukishe:
   AjrmvpLygwSHqKnYVDoTabzfukishW['mode'] ='SEASON_GROUP' 
   AjrmvpLygwSHqKnYVDoTabzfukishW['reagueId'] =AjrmvpLygwSHqKnYVDoTabzfukishx
   AjrmvpLygwSHqKnYVDoTabzfukishW['seasonId'] =AjrmvpLygwSHqKnYVDoTabzfukishR
   AjrmvpLygwSHqKnYVDoTabzfukishW['gameTypeId']=AjrmvpLygwSHqKnYVDoTabzfukishl
   AjrmvpLygwSHqKnYVDoTabzfukishW['page'] =AjrmvpLygwSHqKnYVDoTabzfukisCI(AjrmvpLygwSHqKnYVDoTabzfukishF+1)
   AjrmvpLygwSHqKnYVDoTabzfukisdR='[B]%s >>[/B]'%'다음 페이지'
   AjrmvpLygwSHqKnYVDoTabzfukisQP=AjrmvpLygwSHqKnYVDoTabzfukisCI(AjrmvpLygwSHqKnYVDoTabzfukishF+1)
   AjrmvpLygwSHqKnYVDoTabzfukisdN.add_dir(AjrmvpLygwSHqKnYVDoTabzfukisdR,sublabel=AjrmvpLygwSHqKnYVDoTabzfukisQP,img='',infoLabels=AjrmvpLygwSHqKnYVDoTabzfukisCN,isFolder=AjrmvpLygwSHqKnYVDoTabzfukisCM,params=AjrmvpLygwSHqKnYVDoTabzfukishW)
  if AjrmvpLygwSHqKnYVDoTabzfukisCx(AjrmvpLygwSHqKnYVDoTabzfukishM)>0:xbmcplugin.endOfDirectory(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle,cacheToDisc=AjrmvpLygwSHqKnYVDoTabzfukisCP)
 def dp_GameVod_List(AjrmvpLygwSHqKnYVDoTabzfukisdN,args):
  AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.SaveCredential(AjrmvpLygwSHqKnYVDoTabzfukisdN.get_winCredential())
  AjrmvpLygwSHqKnYVDoTabzfukisQx =args.get('gameid')
  AjrmvpLygwSHqKnYVDoTabzfukisQO=args.get('saveTitle')
  AjrmvpLygwSHqKnYVDoTabzfukisQI =args.get('saveImg')
  AjrmvpLygwSHqKnYVDoTabzfukisQX =args.get('saveInfo')
  AjrmvpLygwSHqKnYVDoTabzfukishM=AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.GetGameVodList(AjrmvpLygwSHqKnYVDoTabzfukisQx)
  for AjrmvpLygwSHqKnYVDoTabzfukishO in AjrmvpLygwSHqKnYVDoTabzfukishM:
   AjrmvpLygwSHqKnYVDoTabzfukishJ =AjrmvpLygwSHqKnYVDoTabzfukishO.get('vodTitle')
   AjrmvpLygwSHqKnYVDoTabzfukishG =AjrmvpLygwSHqKnYVDoTabzfukishO.get('vodId')
   AjrmvpLygwSHqKnYVDoTabzfukishB =AjrmvpLygwSHqKnYVDoTabzfukishO.get('vodType')
   AjrmvpLygwSHqKnYVDoTabzfukishP=AjrmvpLygwSHqKnYVDoTabzfukishO.get('thumbnail')
   AjrmvpLygwSHqKnYVDoTabzfukishE =AjrmvpLygwSHqKnYVDoTabzfukishO.get('vtypeId')
   AjrmvpLygwSHqKnYVDoTabzfukishX=AjrmvpLygwSHqKnYVDoTabzfukishO.get('info')
   AjrmvpLygwSHqKnYVDoTabzfukishX['plot']='%s \n\n %s'%(AjrmvpLygwSHqKnYVDoTabzfukishJ,AjrmvpLygwSHqKnYVDoTabzfukisQX)
   AjrmvpLygwSHqKnYVDoTabzfukishW={'mode':'GAME_VOD','saveTitle':AjrmvpLygwSHqKnYVDoTabzfukisQO,'saveImg':AjrmvpLygwSHqKnYVDoTabzfukisQI,'saveId':AjrmvpLygwSHqKnYVDoTabzfukisQx,'saveInfo':AjrmvpLygwSHqKnYVDoTabzfukisQX,'mediacode':AjrmvpLygwSHqKnYVDoTabzfukishG,'mediatype':'vod','vtypeId':AjrmvpLygwSHqKnYVDoTabzfukishE}
   AjrmvpLygwSHqKnYVDoTabzfukisdN.add_dir(AjrmvpLygwSHqKnYVDoTabzfukishJ,sublabel=AjrmvpLygwSHqKnYVDoTabzfukishB,img=AjrmvpLygwSHqKnYVDoTabzfukishP,infoLabels=AjrmvpLygwSHqKnYVDoTabzfukishX,isFolder=AjrmvpLygwSHqKnYVDoTabzfukisCP,params=AjrmvpLygwSHqKnYVDoTabzfukishW)
  if AjrmvpLygwSHqKnYVDoTabzfukisCx(AjrmvpLygwSHqKnYVDoTabzfukishM)>0:xbmcplugin.endOfDirectory(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle,cacheToDisc=AjrmvpLygwSHqKnYVDoTabzfukisCP)
 def login_main(AjrmvpLygwSHqKnYVDoTabzfukisdN):
  (AjrmvpLygwSHqKnYVDoTabzfukisQJ,AjrmvpLygwSHqKnYVDoTabzfukisQG)=AjrmvpLygwSHqKnYVDoTabzfukisdN.get_settings_login_info()
  if not(AjrmvpLygwSHqKnYVDoTabzfukisQJ and AjrmvpLygwSHqKnYVDoTabzfukisQG):
   AjrmvpLygwSHqKnYVDoTabzfukisdI=xbmcgui.Dialog()
   AjrmvpLygwSHqKnYVDoTabzfukisQB=AjrmvpLygwSHqKnYVDoTabzfukisdI.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if AjrmvpLygwSHqKnYVDoTabzfukisQB==AjrmvpLygwSHqKnYVDoTabzfukisCM:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if AjrmvpLygwSHqKnYVDoTabzfukisdN.cookiefile_check():return
  AjrmvpLygwSHqKnYVDoTabzfukisQE =AjrmvpLygwSHqKnYVDoTabzfukisCO(AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  AjrmvpLygwSHqKnYVDoTabzfukisQt=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if AjrmvpLygwSHqKnYVDoTabzfukisQt==AjrmvpLygwSHqKnYVDoTabzfukisCN or AjrmvpLygwSHqKnYVDoTabzfukisQt=='':
   AjrmvpLygwSHqKnYVDoTabzfukisQt=AjrmvpLygwSHqKnYVDoTabzfukisCO('19000101')
  else:
   AjrmvpLygwSHqKnYVDoTabzfukisQt=AjrmvpLygwSHqKnYVDoTabzfukisCO(re.sub('-','',AjrmvpLygwSHqKnYVDoTabzfukisQt))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   AjrmvpLygwSHqKnYVDoTabzfukisQl=0
   while AjrmvpLygwSHqKnYVDoTabzfukisCM:
    AjrmvpLygwSHqKnYVDoTabzfukisQl+=1
    time.sleep(0.05)
    if AjrmvpLygwSHqKnYVDoTabzfukisQt>=AjrmvpLygwSHqKnYVDoTabzfukisQE:return
    if AjrmvpLygwSHqKnYVDoTabzfukisQl>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if AjrmvpLygwSHqKnYVDoTabzfukisQt>=AjrmvpLygwSHqKnYVDoTabzfukisQE:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.GetCredential(AjrmvpLygwSHqKnYVDoTabzfukisQJ,AjrmvpLygwSHqKnYVDoTabzfukisQG):
   AjrmvpLygwSHqKnYVDoTabzfukisdN.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  AjrmvpLygwSHqKnYVDoTabzfukisdN.set_winCredential(AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.LoadCredential())
  AjrmvpLygwSHqKnYVDoTabzfukisdN.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(AjrmvpLygwSHqKnYVDoTabzfukisdN,args):
  AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.SaveCredential(AjrmvpLygwSHqKnYVDoTabzfukisdN.get_winCredential())
  AjrmvpLygwSHqKnYVDoTabzfukisQc=AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.GetLiveChannelList()
  for AjrmvpLygwSHqKnYVDoTabzfukisQR in AjrmvpLygwSHqKnYVDoTabzfukisQc:
   AjrmvpLygwSHqKnYVDoTabzfukisdR =AjrmvpLygwSHqKnYVDoTabzfukisQR.get('name')
   AjrmvpLygwSHqKnYVDoTabzfukishN =AjrmvpLygwSHqKnYVDoTabzfukisQR.get('programName')
   AjrmvpLygwSHqKnYVDoTabzfukishP =AjrmvpLygwSHqKnYVDoTabzfukisQR.get('logo')
   AjrmvpLygwSHqKnYVDoTabzfukisQF=AjrmvpLygwSHqKnYVDoTabzfukisQR.get('channelepg')
   AjrmvpLygwSHqKnYVDoTabzfukisQe =AjrmvpLygwSHqKnYVDoTabzfukisQR.get('free')
   AjrmvpLygwSHqKnYVDoTabzfukishX=AjrmvpLygwSHqKnYVDoTabzfukisQR.get('info')
   AjrmvpLygwSHqKnYVDoTabzfukishX['plot']='%s'%(AjrmvpLygwSHqKnYVDoTabzfukisQF)
   AjrmvpLygwSHqKnYVDoTabzfukishW={'mode':'LIVE','mediaid':AjrmvpLygwSHqKnYVDoTabzfukisQR.get('id'),'mediacode':AjrmvpLygwSHqKnYVDoTabzfukisQR.get('videoId'),'free':AjrmvpLygwSHqKnYVDoTabzfukisQe,'mediatype':'live'}
   if AjrmvpLygwSHqKnYVDoTabzfukisQe:AjrmvpLygwSHqKnYVDoTabzfukisdR+=' [free]'
   AjrmvpLygwSHqKnYVDoTabzfukisdN.add_dir(AjrmvpLygwSHqKnYVDoTabzfukisdR,sublabel=AjrmvpLygwSHqKnYVDoTabzfukishN,img=AjrmvpLygwSHqKnYVDoTabzfukishP,infoLabels=AjrmvpLygwSHqKnYVDoTabzfukishX,isFolder=AjrmvpLygwSHqKnYVDoTabzfukisCP,params=AjrmvpLygwSHqKnYVDoTabzfukishW)
  if AjrmvpLygwSHqKnYVDoTabzfukisCx(AjrmvpLygwSHqKnYVDoTabzfukisQc)>0:xbmcplugin.endOfDirectory(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle,cacheToDisc=AjrmvpLygwSHqKnYVDoTabzfukisCP)
 def dp_EventLiveChannel_List(AjrmvpLygwSHqKnYVDoTabzfukisdN,args):
  AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.SaveCredential(AjrmvpLygwSHqKnYVDoTabzfukisdN.get_winCredential())
  AjrmvpLygwSHqKnYVDoTabzfukisQc,AjrmvpLygwSHqKnYVDoTabzfukisQU=AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.GetEventLiveList()
  if AjrmvpLygwSHqKnYVDoTabzfukisQU!=401 and AjrmvpLygwSHqKnYVDoTabzfukisCx(AjrmvpLygwSHqKnYVDoTabzfukisQc)==0:
   AjrmvpLygwSHqKnYVDoTabzfukisdN.addon_noti(__language__(30907).encode('utf8'))
  for AjrmvpLygwSHqKnYVDoTabzfukisQR in AjrmvpLygwSHqKnYVDoTabzfukisQc:
   AjrmvpLygwSHqKnYVDoTabzfukisdR =AjrmvpLygwSHqKnYVDoTabzfukisQR.get('title')
   AjrmvpLygwSHqKnYVDoTabzfukishN =AjrmvpLygwSHqKnYVDoTabzfukisQR.get('startTime')
   AjrmvpLygwSHqKnYVDoTabzfukishP =AjrmvpLygwSHqKnYVDoTabzfukisQR.get('logo')
   AjrmvpLygwSHqKnYVDoTabzfukisQe =AjrmvpLygwSHqKnYVDoTabzfukisQR.get('free')
   AjrmvpLygwSHqKnYVDoTabzfukishX=AjrmvpLygwSHqKnYVDoTabzfukisQR.get('info')
   AjrmvpLygwSHqKnYVDoTabzfukishX['plot']='%s\n\n%s'%(AjrmvpLygwSHqKnYVDoTabzfukisdR,AjrmvpLygwSHqKnYVDoTabzfukishN)
   AjrmvpLygwSHqKnYVDoTabzfukishW={'mode':'ELIVE','mediaid':AjrmvpLygwSHqKnYVDoTabzfukisQR.get('liveId'),'mediacode':'','free':AjrmvpLygwSHqKnYVDoTabzfukisQe,'mediatype':'live'}
   if AjrmvpLygwSHqKnYVDoTabzfukisQe:AjrmvpLygwSHqKnYVDoTabzfukisdR+=' [free]'
   AjrmvpLygwSHqKnYVDoTabzfukisdN.add_dir(AjrmvpLygwSHqKnYVDoTabzfukisdR,sublabel=AjrmvpLygwSHqKnYVDoTabzfukishN,img=AjrmvpLygwSHqKnYVDoTabzfukishP,infoLabels=AjrmvpLygwSHqKnYVDoTabzfukishX,isFolder=AjrmvpLygwSHqKnYVDoTabzfukisCP,params=AjrmvpLygwSHqKnYVDoTabzfukishW)
  if AjrmvpLygwSHqKnYVDoTabzfukisCx(AjrmvpLygwSHqKnYVDoTabzfukisQc)>0:xbmcplugin.endOfDirectory(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle,cacheToDisc=AjrmvpLygwSHqKnYVDoTabzfukisCM)
  return AjrmvpLygwSHqKnYVDoTabzfukisQU
 def play_VIDEO(AjrmvpLygwSHqKnYVDoTabzfukisdN,args):
  AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.SaveCredential(AjrmvpLygwSHqKnYVDoTabzfukisdN.get_winCredential())
  if args.get('free')=='False':
   if AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.CheckSubEnd()==AjrmvpLygwSHqKnYVDoTabzfukisCP:
    AjrmvpLygwSHqKnYVDoTabzfukisdN.addon_noti(__language__(30908).encode('utf8'))
    return
  AjrmvpLygwSHqKnYVDoTabzfukisWd =args.get('mode')
  AjrmvpLygwSHqKnYVDoTabzfukisWh =args.get('mediacode')
  AjrmvpLygwSHqKnYVDoTabzfukisWQ =args.get('mediatype')
  AjrmvpLygwSHqKnYVDoTabzfukishE =args.get('vtypeId')
  if args.get('mode')=='ELIVE':
   AjrmvpLygwSHqKnYVDoTabzfukisWh=AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if AjrmvpLygwSHqKnYVDoTabzfukisWh=='' or AjrmvpLygwSHqKnYVDoTabzfukisWh==AjrmvpLygwSHqKnYVDoTabzfukisCN:
   AjrmvpLygwSHqKnYVDoTabzfukisdN.addon_noti(__language__(30907).encode('utf8'))
   return
  AjrmvpLygwSHqKnYVDoTabzfukisWC=AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.GetBroadURL(AjrmvpLygwSHqKnYVDoTabzfukisWh,AjrmvpLygwSHqKnYVDoTabzfukisWQ,AjrmvpLygwSHqKnYVDoTabzfukishE)
  if AjrmvpLygwSHqKnYVDoTabzfukisWC=='':
   AjrmvpLygwSHqKnYVDoTabzfukisdN.addon_noti(__language__(30908).encode('utf8'))
   return
  AjrmvpLygwSHqKnYVDoTabzfukisWN=AjrmvpLygwSHqKnYVDoTabzfukisWC
  AjrmvpLygwSHqKnYVDoTabzfukisdN.addon_log(AjrmvpLygwSHqKnYVDoTabzfukisWN)
  AjrmvpLygwSHqKnYVDoTabzfukisWM=xbmcgui.ListItem(path=AjrmvpLygwSHqKnYVDoTabzfukisWN)
  xbmcplugin.setResolvedUrl(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle,AjrmvpLygwSHqKnYVDoTabzfukisCM,AjrmvpLygwSHqKnYVDoTabzfukisWM)
  try:
   if AjrmvpLygwSHqKnYVDoTabzfukisWQ=='vod' and AjrmvpLygwSHqKnYVDoTabzfukisWd!='POP_VOD':
    AjrmvpLygwSHqKnYVDoTabzfukishW={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    AjrmvpLygwSHqKnYVDoTabzfukisdN.Save_Watched_List(AjrmvpLygwSHqKnYVDoTabzfukisWQ,AjrmvpLygwSHqKnYVDoTabzfukishW)
  except:
   AjrmvpLygwSHqKnYVDoTabzfukisCN
 def logout(AjrmvpLygwSHqKnYVDoTabzfukisdN):
  AjrmvpLygwSHqKnYVDoTabzfukisdI=xbmcgui.Dialog()
  AjrmvpLygwSHqKnYVDoTabzfukisQB=AjrmvpLygwSHqKnYVDoTabzfukisdI.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if AjrmvpLygwSHqKnYVDoTabzfukisQB==AjrmvpLygwSHqKnYVDoTabzfukisCP:sys.exit()
  AjrmvpLygwSHqKnYVDoTabzfukisdN.wininfo_clear()
  if os.path.isfile(AjrmvpLygwSHqKnYVDoTabzfukisdC):os.remove(AjrmvpLygwSHqKnYVDoTabzfukisdC)
  AjrmvpLygwSHqKnYVDoTabzfukisdN.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(AjrmvpLygwSHqKnYVDoTabzfukisdN):
  AjrmvpLygwSHqKnYVDoTabzfukisdt=xbmcgui.Window(10000)
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_SESSIONID','')
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_SESSION','')
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_ACCOUNTID','')
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_POLICYKEY','')
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_SUBEND','')
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(AjrmvpLygwSHqKnYVDoTabzfukisdN):
  AjrmvpLygwSHqKnYVDoTabzfukisWO =AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.Get_Now_Datetime()
  AjrmvpLygwSHqKnYVDoTabzfukisWP=AjrmvpLygwSHqKnYVDoTabzfukisWO+datetime.timedelta(days=AjrmvpLygwSHqKnYVDoTabzfukisCO(__addon__.getSetting('cache_ttl')))
  AjrmvpLygwSHqKnYVDoTabzfukisdt=xbmcgui.Window(10000)
  AjrmvpLygwSHqKnYVDoTabzfukisWx={'spotv_sessionid':AjrmvpLygwSHqKnYVDoTabzfukisdt.getProperty('SPOTV_M_SESSIONID'),'spotv_session':AjrmvpLygwSHqKnYVDoTabzfukisdt.getProperty('SPOTV_M_SESSION'),'spotv_accountId':AjrmvpLygwSHqKnYVDoTabzfukisdt.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(AjrmvpLygwSHqKnYVDoTabzfukisdt.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.SPOTV_PMCODE+AjrmvpLygwSHqKnYVDoTabzfukisdt.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':AjrmvpLygwSHqKnYVDoTabzfukisWP.strftime('%Y-%m-%d')}
  try: 
   fp=AjrmvpLygwSHqKnYVDoTabzfukisCX(AjrmvpLygwSHqKnYVDoTabzfukisdC,'w',-1,'utf-8')
   json.dump(AjrmvpLygwSHqKnYVDoTabzfukisWx,fp)
   fp.close()
  except AjrmvpLygwSHqKnYVDoTabzfukisCJ as exception:
   AjrmvpLygwSHqKnYVDoTabzfukisCG(exception)
 def cookiefile_check(AjrmvpLygwSHqKnYVDoTabzfukisdN):
  AjrmvpLygwSHqKnYVDoTabzfukisWx={}
  try: 
   fp=AjrmvpLygwSHqKnYVDoTabzfukisCX(AjrmvpLygwSHqKnYVDoTabzfukisdC,'r',-1,'utf-8')
   AjrmvpLygwSHqKnYVDoTabzfukisWx= json.load(fp)
   fp.close()
  except AjrmvpLygwSHqKnYVDoTabzfukisCJ as exception:
   AjrmvpLygwSHqKnYVDoTabzfukisdN.wininfo_clear()
   return AjrmvpLygwSHqKnYVDoTabzfukisCP
  AjrmvpLygwSHqKnYVDoTabzfukisQJ =__addon__.getSetting('id')
  AjrmvpLygwSHqKnYVDoTabzfukisQG =__addon__.getSetting('pw')
  AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_id'] =base64.standard_b64decode(AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_id']).decode('utf-8')
  AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_pw'] =base64.standard_b64decode(AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_pw']).decode('utf-8')
  AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_policyKey']=base64.standard_b64decode(AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_policyKey']).decode('utf-8')
  AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_subend']=base64.standard_b64decode(AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_subend']).decode('utf-8')[AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.SPOTV_PMSIZE:]
  if AjrmvpLygwSHqKnYVDoTabzfukisQJ!=AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_id']or AjrmvpLygwSHqKnYVDoTabzfukisQG!=AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_pw']:
   AjrmvpLygwSHqKnYVDoTabzfukisdN.wininfo_clear()
   return AjrmvpLygwSHqKnYVDoTabzfukisCP
  AjrmvpLygwSHqKnYVDoTabzfukisQE =AjrmvpLygwSHqKnYVDoTabzfukisCO(AjrmvpLygwSHqKnYVDoTabzfukisdN.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  AjrmvpLygwSHqKnYVDoTabzfukisWI=AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_limitdate']
  AjrmvpLygwSHqKnYVDoTabzfukisQt =AjrmvpLygwSHqKnYVDoTabzfukisCO(re.sub('-','',AjrmvpLygwSHqKnYVDoTabzfukisWI))
  if AjrmvpLygwSHqKnYVDoTabzfukisQt<AjrmvpLygwSHqKnYVDoTabzfukisQE:
   AjrmvpLygwSHqKnYVDoTabzfukisdN.wininfo_clear()
   return AjrmvpLygwSHqKnYVDoTabzfukisCP
  AjrmvpLygwSHqKnYVDoTabzfukisdt=xbmcgui.Window(10000)
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_SESSIONID',AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_sessionid'])
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_SESSION',AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_session'])
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_ACCOUNTID',AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_accountId'])
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_POLICYKEY',AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_policyKey'])
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_SUBEND',AjrmvpLygwSHqKnYVDoTabzfukisWx['spotv_subend'])
  AjrmvpLygwSHqKnYVDoTabzfukisdt.setProperty('SPOTV_M_LOGINTIME',AjrmvpLygwSHqKnYVDoTabzfukisWI)
  return AjrmvpLygwSHqKnYVDoTabzfukisCM
 def dp_WatchList_Delete(AjrmvpLygwSHqKnYVDoTabzfukisdN,args):
  AjrmvpLygwSHqKnYVDoTabzfukisWQ=args.get('mediatype')
  AjrmvpLygwSHqKnYVDoTabzfukisdI=xbmcgui.Dialog()
  AjrmvpLygwSHqKnYVDoTabzfukisQB=AjrmvpLygwSHqKnYVDoTabzfukisdI.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if AjrmvpLygwSHqKnYVDoTabzfukisQB==AjrmvpLygwSHqKnYVDoTabzfukisCP:sys.exit()
  AjrmvpLygwSHqKnYVDoTabzfukisdN.Delete_Watched_List(AjrmvpLygwSHqKnYVDoTabzfukisWQ)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(AjrmvpLygwSHqKnYVDoTabzfukisdN,AjrmvpLygwSHqKnYVDoTabzfukisWQ):
  try:
   AjrmvpLygwSHqKnYVDoTabzfukisWX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AjrmvpLygwSHqKnYVDoTabzfukisWQ))
   fp=AjrmvpLygwSHqKnYVDoTabzfukisCX(AjrmvpLygwSHqKnYVDoTabzfukisWX,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   AjrmvpLygwSHqKnYVDoTabzfukisCN
 def Load_Watched_List(AjrmvpLygwSHqKnYVDoTabzfukisdN,AjrmvpLygwSHqKnYVDoTabzfukisWQ):
  try:
   AjrmvpLygwSHqKnYVDoTabzfukisWX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AjrmvpLygwSHqKnYVDoTabzfukisWQ))
   fp=AjrmvpLygwSHqKnYVDoTabzfukisCX(AjrmvpLygwSHqKnYVDoTabzfukisWX,'r',-1,'utf-8')
   AjrmvpLygwSHqKnYVDoTabzfukisWJ=fp.readlines()
   fp.close()
  except:
   AjrmvpLygwSHqKnYVDoTabzfukisWJ=[]
  return AjrmvpLygwSHqKnYVDoTabzfukisWJ
 def Save_Watched_List(AjrmvpLygwSHqKnYVDoTabzfukisdN,stype,AjrmvpLygwSHqKnYVDoTabzfukisdP):
  try:
   AjrmvpLygwSHqKnYVDoTabzfukisWX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   AjrmvpLygwSHqKnYVDoTabzfukisWG=AjrmvpLygwSHqKnYVDoTabzfukisdN.Load_Watched_List(stype) 
   fp=AjrmvpLygwSHqKnYVDoTabzfukisCX(AjrmvpLygwSHqKnYVDoTabzfukisWX,'w',-1,'utf-8')
   AjrmvpLygwSHqKnYVDoTabzfukisWB=urllib.parse.urlencode(AjrmvpLygwSHqKnYVDoTabzfukisdP)
   AjrmvpLygwSHqKnYVDoTabzfukisWB=AjrmvpLygwSHqKnYVDoTabzfukisWB+'\n'
   fp.write(AjrmvpLygwSHqKnYVDoTabzfukisWB)
   AjrmvpLygwSHqKnYVDoTabzfukisWE=0
   for AjrmvpLygwSHqKnYVDoTabzfukisWt in AjrmvpLygwSHqKnYVDoTabzfukisWG:
    AjrmvpLygwSHqKnYVDoTabzfukisWl=AjrmvpLygwSHqKnYVDoTabzfukisCB(urllib.parse.parse_qsl(AjrmvpLygwSHqKnYVDoTabzfukisWt))
    AjrmvpLygwSHqKnYVDoTabzfukisWc=AjrmvpLygwSHqKnYVDoTabzfukisdP.get('code')
    AjrmvpLygwSHqKnYVDoTabzfukisWR=AjrmvpLygwSHqKnYVDoTabzfukisWl.get('code')
    if AjrmvpLygwSHqKnYVDoTabzfukisWc!=AjrmvpLygwSHqKnYVDoTabzfukisWR:
     fp.write(AjrmvpLygwSHqKnYVDoTabzfukisWt)
     AjrmvpLygwSHqKnYVDoTabzfukisWE+=1
     if AjrmvpLygwSHqKnYVDoTabzfukisWE>=50:break
   fp.close()
  except:
   AjrmvpLygwSHqKnYVDoTabzfukisCN
 def dp_Watch_List(AjrmvpLygwSHqKnYVDoTabzfukisdN,args):
  AjrmvpLygwSHqKnYVDoTabzfukisWQ ='vod'
  if AjrmvpLygwSHqKnYVDoTabzfukisWQ=='vod':
   AjrmvpLygwSHqKnYVDoTabzfukisWF=AjrmvpLygwSHqKnYVDoTabzfukisdN.Load_Watched_List(AjrmvpLygwSHqKnYVDoTabzfukisWQ)
   for AjrmvpLygwSHqKnYVDoTabzfukisWe in AjrmvpLygwSHqKnYVDoTabzfukisWF:
    AjrmvpLygwSHqKnYVDoTabzfukisWU=AjrmvpLygwSHqKnYVDoTabzfukisCB(urllib.parse.parse_qsl(AjrmvpLygwSHqKnYVDoTabzfukisWe))
    AjrmvpLygwSHqKnYVDoTabzfukisdR =AjrmvpLygwSHqKnYVDoTabzfukisWU.get('title')
    AjrmvpLygwSHqKnYVDoTabzfukishP=AjrmvpLygwSHqKnYVDoTabzfukisWU.get('img')
    AjrmvpLygwSHqKnYVDoTabzfukisWh=AjrmvpLygwSHqKnYVDoTabzfukisWU.get('code')
    AjrmvpLygwSHqKnYVDoTabzfukisCd =AjrmvpLygwSHqKnYVDoTabzfukisWU.get('info')
    AjrmvpLygwSHqKnYVDoTabzfukishX={}
    AjrmvpLygwSHqKnYVDoTabzfukishX['plot']=AjrmvpLygwSHqKnYVDoTabzfukisCd
    AjrmvpLygwSHqKnYVDoTabzfukishW={'mode':'GAME_VOD_GROUP','gameid':AjrmvpLygwSHqKnYVDoTabzfukisWh,'saveTitle':AjrmvpLygwSHqKnYVDoTabzfukisdR,'saveImg':AjrmvpLygwSHqKnYVDoTabzfukishP,'saveInfo':AjrmvpLygwSHqKnYVDoTabzfukisCd,'mediatype':AjrmvpLygwSHqKnYVDoTabzfukisWQ}
    AjrmvpLygwSHqKnYVDoTabzfukisdN.add_dir(AjrmvpLygwSHqKnYVDoTabzfukisdR,sublabel='',img=AjrmvpLygwSHqKnYVDoTabzfukishP,infoLabels=AjrmvpLygwSHqKnYVDoTabzfukishX,isFolder=AjrmvpLygwSHqKnYVDoTabzfukisCM,params=AjrmvpLygwSHqKnYVDoTabzfukishW)
   AjrmvpLygwSHqKnYVDoTabzfukishX={'plot':'시청목록을 삭제합니다.'}
   AjrmvpLygwSHqKnYVDoTabzfukisdR='*** 시청목록 삭제 ***'
   AjrmvpLygwSHqKnYVDoTabzfukishW={'mode':'MYVIEW_REMOVE','mediatype':AjrmvpLygwSHqKnYVDoTabzfukisWQ}
   AjrmvpLygwSHqKnYVDoTabzfukisdN.add_dir(AjrmvpLygwSHqKnYVDoTabzfukisdR,sublabel='',img='',infoLabels=AjrmvpLygwSHqKnYVDoTabzfukishX,isFolder=AjrmvpLygwSHqKnYVDoTabzfukisCP,params=AjrmvpLygwSHqKnYVDoTabzfukishW)
   xbmcplugin.endOfDirectory(AjrmvpLygwSHqKnYVDoTabzfukisdN._addon_handle,cacheToDisc=AjrmvpLygwSHqKnYVDoTabzfukisCP)
 def spotv_main(AjrmvpLygwSHqKnYVDoTabzfukisdN):
  AjrmvpLygwSHqKnYVDoTabzfukisCQ=AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params.get('mode',AjrmvpLygwSHqKnYVDoTabzfukisCN)
  if AjrmvpLygwSHqKnYVDoTabzfukisCQ=='LOGOUT':
   AjrmvpLygwSHqKnYVDoTabzfukisdN.logout()
   return
  AjrmvpLygwSHqKnYVDoTabzfukisdN.login_main()
  if AjrmvpLygwSHqKnYVDoTabzfukisCQ is AjrmvpLygwSHqKnYVDoTabzfukisCN:
   AjrmvpLygwSHqKnYVDoTabzfukisdN.dp_Main_List()
  elif AjrmvpLygwSHqKnYVDoTabzfukisCQ=='LIVE_GROUP':
   AjrmvpLygwSHqKnYVDoTabzfukisdN.dp_LiveChannel_List(AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params)
  elif AjrmvpLygwSHqKnYVDoTabzfukisCQ=='ELIVE_GROUP':
   AjrmvpLygwSHqKnYVDoTabzfukisQU=AjrmvpLygwSHqKnYVDoTabzfukisdN.dp_EventLiveChannel_List(AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params)
   if AjrmvpLygwSHqKnYVDoTabzfukisQU==401:
    if os.path.isfile(AjrmvpLygwSHqKnYVDoTabzfukisdC):os.remove(AjrmvpLygwSHqKnYVDoTabzfukisdC)
    AjrmvpLygwSHqKnYVDoTabzfukisdN.login_main()
    AjrmvpLygwSHqKnYVDoTabzfukisdN.dp_EventLiveChannel_List(AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params)
  elif AjrmvpLygwSHqKnYVDoTabzfukisCQ in['LIVE','GAME_VOD','POP_VOD','ELIVE']:
   AjrmvpLygwSHqKnYVDoTabzfukisdN.play_VIDEO(AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params)
  elif AjrmvpLygwSHqKnYVDoTabzfukisCQ=='VOD_GROUP':
   AjrmvpLygwSHqKnYVDoTabzfukisdN.dp_MainLeague_List(AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params)
  elif AjrmvpLygwSHqKnYVDoTabzfukisCQ=='POP_GROUP':
   AjrmvpLygwSHqKnYVDoTabzfukisdN.dp_PopVod_GroupList(AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params)
  elif AjrmvpLygwSHqKnYVDoTabzfukisCQ=='LEAGUE_GROUP':
   AjrmvpLygwSHqKnYVDoTabzfukisdN.dp_Season_List(AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params)
  elif AjrmvpLygwSHqKnYVDoTabzfukisCQ=='SEASON_GROUP':
   AjrmvpLygwSHqKnYVDoTabzfukisdN.dp_Game_List(AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params)
  elif AjrmvpLygwSHqKnYVDoTabzfukisCQ=='GAME_VOD_GROUP':
   AjrmvpLygwSHqKnYVDoTabzfukisdN.dp_GameVod_List(AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params)
  elif AjrmvpLygwSHqKnYVDoTabzfukisCQ=='WATCH':
   AjrmvpLygwSHqKnYVDoTabzfukisdN.dp_Watch_List(AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params)
  elif AjrmvpLygwSHqKnYVDoTabzfukisCQ=='MYVIEW_REMOVE':
   AjrmvpLygwSHqKnYVDoTabzfukisdN.dp_WatchList_Delete(AjrmvpLygwSHqKnYVDoTabzfukisdN.main_params)
  else:
   AjrmvpLygwSHqKnYVDoTabzfukisCN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
