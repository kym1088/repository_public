__author__="NightRain"
KgRnduCXGceFTfbrkQpiljNymIaHVD=object
KgRnduCXGceFTfbrkQpiljNymIaHVw=None
KgRnduCXGceFTfbrkQpiljNymIaHVO=False
KgRnduCXGceFTfbrkQpiljNymIaHVt=print
KgRnduCXGceFTfbrkQpiljNymIaHVY=str
KgRnduCXGceFTfbrkQpiljNymIaHVq=True
KgRnduCXGceFTfbrkQpiljNymIaHVz=Exception
KgRnduCXGceFTfbrkQpiljNymIaHVW=range
KgRnduCXGceFTfbrkQpiljNymIaHVL=int
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
KgRnduCXGceFTfbrkQpiljNymIaHMh ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
KgRnduCXGceFTfbrkQpiljNymIaHMA={'stream50':1080,'stream40':720,'stream30':540}
class KgRnduCXGceFTfbrkQpiljNymIaHMo(KgRnduCXGceFTfbrkQpiljNymIaHVD):
 def __init__(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SESSIONID=''
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SESSION =''
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_ACCOUNTID=''
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_POLICYKEY=''
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SUBEND =''
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_PMCODE ='987'
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_PMSIZE =3
  KgRnduCXGceFTfbrkQpiljNymIaHMV.GAMELIST_LIMIT =10
  KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN ='https://www.spotvnow.co.kr'
  KgRnduCXGceFTfbrkQpiljNymIaHMV.BC_DOMAIN ='https://players.brightcove.net'
  KgRnduCXGceFTfbrkQpiljNymIaHMV.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  KgRnduCXGceFTfbrkQpiljNymIaHMV.DEFAULT_HEADER ={'user-agent':KgRnduCXGceFTfbrkQpiljNymIaHMh}
 def callRequestCookies(KgRnduCXGceFTfbrkQpiljNymIaHMV,jobtype,KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw,redirects=KgRnduCXGceFTfbrkQpiljNymIaHVO):
  KgRnduCXGceFTfbrkQpiljNymIaHMx=KgRnduCXGceFTfbrkQpiljNymIaHMV.DEFAULT_HEADER
  if headers:KgRnduCXGceFTfbrkQpiljNymIaHMx.update(headers)
  if jobtype=='Get':
   KgRnduCXGceFTfbrkQpiljNymIaHMD=requests.get(KgRnduCXGceFTfbrkQpiljNymIaHoA,params=params,headers=KgRnduCXGceFTfbrkQpiljNymIaHMx,cookies=cookies,allow_redirects=redirects)
  else:
   KgRnduCXGceFTfbrkQpiljNymIaHMD=requests.post(KgRnduCXGceFTfbrkQpiljNymIaHoA,data=payload,params=params,headers=KgRnduCXGceFTfbrkQpiljNymIaHMx,cookies=cookies,allow_redirects=redirects)
  return KgRnduCXGceFTfbrkQpiljNymIaHMD
 def makeDefaultCookies(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHMw={'SESSION':KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SESSION}
  return KgRnduCXGceFTfbrkQpiljNymIaHMw
 def GetCredential(KgRnduCXGceFTfbrkQpiljNymIaHMV,user_id,user_pw):
  KgRnduCXGceFTfbrkQpiljNymIaHMO=KgRnduCXGceFTfbrkQpiljNymIaHVO
  KgRnduCXGceFTfbrkQpiljNymIaHMt=KgRnduCXGceFTfbrkQpiljNymIaHME=KgRnduCXGceFTfbrkQpiljNymIaHMv=KgRnduCXGceFTfbrkQpiljNymIaHMP=KgRnduCXGceFTfbrkQpiljNymIaHMB=''
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHMY=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   KgRnduCXGceFTfbrkQpiljNymIaHMq=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   KgRnduCXGceFTfbrkQpiljNymIaHMz=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/login'
   KgRnduCXGceFTfbrkQpiljNymIaHMW={'username':KgRnduCXGceFTfbrkQpiljNymIaHMY,'password':KgRnduCXGceFTfbrkQpiljNymIaHMq}
   KgRnduCXGceFTfbrkQpiljNymIaHMW=json.dumps(KgRnduCXGceFTfbrkQpiljNymIaHMW)
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Post',KgRnduCXGceFTfbrkQpiljNymIaHMz,payload=KgRnduCXGceFTfbrkQpiljNymIaHMW,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHVt(KgRnduCXGceFTfbrkQpiljNymIaHML.status_code)
   for KgRnduCXGceFTfbrkQpiljNymIaHMJ in KgRnduCXGceFTfbrkQpiljNymIaHML.cookies:
    if KgRnduCXGceFTfbrkQpiljNymIaHMJ.name=='SESSION':
     KgRnduCXGceFTfbrkQpiljNymIaHME=KgRnduCXGceFTfbrkQpiljNymIaHMJ.value
     break
   if KgRnduCXGceFTfbrkQpiljNymIaHME=='':return KgRnduCXGceFTfbrkQpiljNymIaHMO
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   if not('userId' in KgRnduCXGceFTfbrkQpiljNymIaHMU):return KgRnduCXGceFTfbrkQpiljNymIaHMO
   KgRnduCXGceFTfbrkQpiljNymIaHMt=KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHMU['userId'])
   KgRnduCXGceFTfbrkQpiljNymIaHMB =KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHMU['subEndTime'])
   KgRnduCXGceFTfbrkQpiljNymIaHMv,KgRnduCXGceFTfbrkQpiljNymIaHMP=KgRnduCXGceFTfbrkQpiljNymIaHMV.GetPolicyKey()
   if KgRnduCXGceFTfbrkQpiljNymIaHMP=='':return KgRnduCXGceFTfbrkQpiljNymIaHMO
   KgRnduCXGceFTfbrkQpiljNymIaHMO=KgRnduCXGceFTfbrkQpiljNymIaHVq
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHMt=KgRnduCXGceFTfbrkQpiljNymIaHME='' 
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  KgRnduCXGceFTfbrkQpiljNymIaHMS={'spotv_sessionid':KgRnduCXGceFTfbrkQpiljNymIaHMt,'spotv_session':KgRnduCXGceFTfbrkQpiljNymIaHME,'spotv_accountId':KgRnduCXGceFTfbrkQpiljNymIaHMv,'spotv_policyKey':KgRnduCXGceFTfbrkQpiljNymIaHMP,'spotv_subend':KgRnduCXGceFTfbrkQpiljNymIaHMB}
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SaveCredential(KgRnduCXGceFTfbrkQpiljNymIaHMS)
  return KgRnduCXGceFTfbrkQpiljNymIaHMO
 def SaveCredential(KgRnduCXGceFTfbrkQpiljNymIaHMV,KgRnduCXGceFTfbrkQpiljNymIaHMS):
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SESSIONID=KgRnduCXGceFTfbrkQpiljNymIaHMS.get('spotv_sessionid')
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SESSION =KgRnduCXGceFTfbrkQpiljNymIaHMS.get('spotv_session')
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_ACCOUNTID=KgRnduCXGceFTfbrkQpiljNymIaHMS.get('spotv_accountId')
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_POLICYKEY=KgRnduCXGceFTfbrkQpiljNymIaHMS.get('spotv_policyKey')
  KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SUBEND =KgRnduCXGceFTfbrkQpiljNymIaHMS.get('spotv_subend')
 def LoadCredential(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHMS={'spotv_sessionid':KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SESSIONID,'spotv_session':KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SESSION,'spotv_accountId':KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_ACCOUNTID,'spotv_policyKey':KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_POLICYKEY,'spotv_subend':KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SUBEND}
  return KgRnduCXGceFTfbrkQpiljNymIaHMS
 def Get_Now_Datetime(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHoM=[]
  KgRnduCXGceFTfbrkQpiljNymIaHoh ={}
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/channel'
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   KgRnduCXGceFTfbrkQpiljNymIaHoh=KgRnduCXGceFTfbrkQpiljNymIaHMV.GetEPGList()
   for i in KgRnduCXGceFTfbrkQpiljNymIaHVW(2):
    for KgRnduCXGceFTfbrkQpiljNymIaHoV in KgRnduCXGceFTfbrkQpiljNymIaHMU:
     KgRnduCXGceFTfbrkQpiljNymIaHox={}
     KgRnduCXGceFTfbrkQpiljNymIaHox['mediatype']='video'
     KgRnduCXGceFTfbrkQpiljNymIaHox['title'] =KgRnduCXGceFTfbrkQpiljNymIaHoV['programName']
     KgRnduCXGceFTfbrkQpiljNymIaHox['studio'] =KgRnduCXGceFTfbrkQpiljNymIaHoV['name']
     KgRnduCXGceFTfbrkQpiljNymIaHoD={'id':KgRnduCXGceFTfbrkQpiljNymIaHoV['id'],'name':KgRnduCXGceFTfbrkQpiljNymIaHoV['name'],'logo':KgRnduCXGceFTfbrkQpiljNymIaHoV['logo'],'videoId':KgRnduCXGceFTfbrkQpiljNymIaHoV['videoId'].replace('ref:',''),'free':KgRnduCXGceFTfbrkQpiljNymIaHoV['free'],'programName':KgRnduCXGceFTfbrkQpiljNymIaHoV['programName'],'channelepg':KgRnduCXGceFTfbrkQpiljNymIaHoh.get(KgRnduCXGceFTfbrkQpiljNymIaHoV['id']),'info':KgRnduCXGceFTfbrkQpiljNymIaHox}
     if i==0:
      if KgRnduCXGceFTfbrkQpiljNymIaHoV['free']==KgRnduCXGceFTfbrkQpiljNymIaHVO:KgRnduCXGceFTfbrkQpiljNymIaHoM.append(KgRnduCXGceFTfbrkQpiljNymIaHoD)
     else:
      if KgRnduCXGceFTfbrkQpiljNymIaHoV['free']==KgRnduCXGceFTfbrkQpiljNymIaHVq:KgRnduCXGceFTfbrkQpiljNymIaHoM.append(KgRnduCXGceFTfbrkQpiljNymIaHoD)
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHoM
 def GetEPGList(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHow={}
  KgRnduCXGceFTfbrkQpiljNymIaHoO=KgRnduCXGceFTfbrkQpiljNymIaHMV.Get_Now_Datetime()
  KgRnduCXGceFTfbrkQpiljNymIaHot=KgRnduCXGceFTfbrkQpiljNymIaHoO.strftime('%Y%m%d%H%M')
  KgRnduCXGceFTfbrkQpiljNymIaHoY='%s-%s-%s'%(KgRnduCXGceFTfbrkQpiljNymIaHot[0:4],KgRnduCXGceFTfbrkQpiljNymIaHot[4:6],KgRnduCXGceFTfbrkQpiljNymIaHot[6:8])
  KgRnduCXGceFTfbrkQpiljNymIaHoq=(KgRnduCXGceFTfbrkQpiljNymIaHoO+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/program/'+KgRnduCXGceFTfbrkQpiljNymIaHoY
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   KgRnduCXGceFTfbrkQpiljNymIaHoz=-1 
   KgRnduCXGceFTfbrkQpiljNymIaHoW =''
   for KgRnduCXGceFTfbrkQpiljNymIaHoV in KgRnduCXGceFTfbrkQpiljNymIaHMU:
    KgRnduCXGceFTfbrkQpiljNymIaHoL=KgRnduCXGceFTfbrkQpiljNymIaHoV['channelId']
    KgRnduCXGceFTfbrkQpiljNymIaHoJ =KgRnduCXGceFTfbrkQpiljNymIaHoV['startTime'].replace('-','').replace(' ','').replace(':','')
    KgRnduCXGceFTfbrkQpiljNymIaHoE =KgRnduCXGceFTfbrkQpiljNymIaHoV['endTime'].replace('-','').replace(' ','').replace(':','')
    if KgRnduCXGceFTfbrkQpiljNymIaHVL(KgRnduCXGceFTfbrkQpiljNymIaHot)>KgRnduCXGceFTfbrkQpiljNymIaHVL(KgRnduCXGceFTfbrkQpiljNymIaHoE) :continue
    if KgRnduCXGceFTfbrkQpiljNymIaHVL(KgRnduCXGceFTfbrkQpiljNymIaHoq)<KgRnduCXGceFTfbrkQpiljNymIaHVL(KgRnduCXGceFTfbrkQpiljNymIaHoJ):continue
    if KgRnduCXGceFTfbrkQpiljNymIaHoz!=KgRnduCXGceFTfbrkQpiljNymIaHoL:
     if KgRnduCXGceFTfbrkQpiljNymIaHoW!='':KgRnduCXGceFTfbrkQpiljNymIaHow[KgRnduCXGceFTfbrkQpiljNymIaHoz]=KgRnduCXGceFTfbrkQpiljNymIaHoW
     KgRnduCXGceFTfbrkQpiljNymIaHoz=KgRnduCXGceFTfbrkQpiljNymIaHoL
     KgRnduCXGceFTfbrkQpiljNymIaHoW =''
    if KgRnduCXGceFTfbrkQpiljNymIaHoW:KgRnduCXGceFTfbrkQpiljNymIaHoW+='\n'
    KgRnduCXGceFTfbrkQpiljNymIaHoW+=KgRnduCXGceFTfbrkQpiljNymIaHoV['title']+'\n'
    KgRnduCXGceFTfbrkQpiljNymIaHoW+=' [%s ~ %s]'%(KgRnduCXGceFTfbrkQpiljNymIaHoV['startTime'][-5:],KgRnduCXGceFTfbrkQpiljNymIaHoV['endTime'][-5:])+'\n'
   if KgRnduCXGceFTfbrkQpiljNymIaHoW:KgRnduCXGceFTfbrkQpiljNymIaHow[KgRnduCXGceFTfbrkQpiljNymIaHoz]=KgRnduCXGceFTfbrkQpiljNymIaHoW
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHow
 def GetEventLiveList(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHoM=[]
  KgRnduCXGceFTfbrkQpiljNymIaHoU =0
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoB=KgRnduCXGceFTfbrkQpiljNymIaHMV.Get_Now_Datetime()
   KgRnduCXGceFTfbrkQpiljNymIaHov=KgRnduCXGceFTfbrkQpiljNymIaHoB.strftime('%Y-%m-%d')
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
   return KgRnduCXGceFTfbrkQpiljNymIaHoM,KgRnduCXGceFTfbrkQpiljNymIaHoU
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/player/lives/'+KgRnduCXGceFTfbrkQpiljNymIaHov 
   KgRnduCXGceFTfbrkQpiljNymIaHMw=KgRnduCXGceFTfbrkQpiljNymIaHMV.makeDefaultCookies()
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHMw)
   KgRnduCXGceFTfbrkQpiljNymIaHoU=KgRnduCXGceFTfbrkQpiljNymIaHML.status_code 
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   for KgRnduCXGceFTfbrkQpiljNymIaHoP in KgRnduCXGceFTfbrkQpiljNymIaHMU:
    for KgRnduCXGceFTfbrkQpiljNymIaHoV in KgRnduCXGceFTfbrkQpiljNymIaHoP['liveNowList']:
     KgRnduCXGceFTfbrkQpiljNymIaHox={}
     KgRnduCXGceFTfbrkQpiljNymIaHox['mediatype']='video'
     if KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['title']==KgRnduCXGceFTfbrkQpiljNymIaHVw or KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['title']=='':
      KgRnduCXGceFTfbrkQpiljNymIaHoS='%s ( %s : %s )'%(KgRnduCXGceFTfbrkQpiljNymIaHoV['leagueName'],KgRnduCXGceFTfbrkQpiljNymIaHoV['homeNameShort'],KgRnduCXGceFTfbrkQpiljNymIaHoV['awayNameShort'])
     else:
      KgRnduCXGceFTfbrkQpiljNymIaHoS=KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['title']
     KgRnduCXGceFTfbrkQpiljNymIaHoD={'liveId':KgRnduCXGceFTfbrkQpiljNymIaHoV['liveId'],'title':KgRnduCXGceFTfbrkQpiljNymIaHoS,'logo':KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['leagueLogo'],'free':KgRnduCXGceFTfbrkQpiljNymIaHoV['isFree'],'startTime':KgRnduCXGceFTfbrkQpiljNymIaHoV['startTime'],'info':KgRnduCXGceFTfbrkQpiljNymIaHox}
     KgRnduCXGceFTfbrkQpiljNymIaHoM.append(KgRnduCXGceFTfbrkQpiljNymIaHoD)
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHoM,KgRnduCXGceFTfbrkQpiljNymIaHoU
 def GetEventLiveList_sub(KgRnduCXGceFTfbrkQpiljNymIaHMV,tDate):
  KgRnduCXGceFTfbrkQpiljNymIaHoM=[]
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/player/lives/'+tDate
   KgRnduCXGceFTfbrkQpiljNymIaHMw=KgRnduCXGceFTfbrkQpiljNymIaHMV.makeDefaultCookies()
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHMw)
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   for KgRnduCXGceFTfbrkQpiljNymIaHoP in KgRnduCXGceFTfbrkQpiljNymIaHMU:
    for KgRnduCXGceFTfbrkQpiljNymIaHoV in KgRnduCXGceFTfbrkQpiljNymIaHoP['liveNowList']:
     KgRnduCXGceFTfbrkQpiljNymIaHox={}
     KgRnduCXGceFTfbrkQpiljNymIaHox['mediatype']='video'
     if KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['title']==KgRnduCXGceFTfbrkQpiljNymIaHVw or KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['title']=='':
      KgRnduCXGceFTfbrkQpiljNymIaHoS='%s ( %s : %s )'%(KgRnduCXGceFTfbrkQpiljNymIaHoV['leagueName'],KgRnduCXGceFTfbrkQpiljNymIaHoV['homeNameShort'],KgRnduCXGceFTfbrkQpiljNymIaHoV['awayNameShort'])
     else:
      KgRnduCXGceFTfbrkQpiljNymIaHoS=KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['title']
     KgRnduCXGceFTfbrkQpiljNymIaHoD={'liveId':KgRnduCXGceFTfbrkQpiljNymIaHoV['liveId'],'title':KgRnduCXGceFTfbrkQpiljNymIaHoS,'logo':KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['leagueLogo'],'free':KgRnduCXGceFTfbrkQpiljNymIaHoV['isFree'],'startTime':KgRnduCXGceFTfbrkQpiljNymIaHoV['startTime'],'info':KgRnduCXGceFTfbrkQpiljNymIaHox}
     KgRnduCXGceFTfbrkQpiljNymIaHoM.append(KgRnduCXGceFTfbrkQpiljNymIaHoD)
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHoM
 def GetEventLive_videoId(KgRnduCXGceFTfbrkQpiljNymIaHMV,liveId):
  KgRnduCXGceFTfbrkQpiljNymIaHos=''
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/live/'+liveId
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   KgRnduCXGceFTfbrkQpiljNymIaHhM=KgRnduCXGceFTfbrkQpiljNymIaHMU['videoId']
   KgRnduCXGceFTfbrkQpiljNymIaHos=KgRnduCXGceFTfbrkQpiljNymIaHhM.replace('ref:','')
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHos
 def CheckMainEnd(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHho=base64.standard_b64encode((KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_PMCODE+KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SESSIONID).encode()).decode('utf-8')
  if KgRnduCXGceFTfbrkQpiljNymIaHho=='OTg3MTgzMzM0Ng==' or KgRnduCXGceFTfbrkQpiljNymIaHho=='OTg3MTgzMzExNw==':return KgRnduCXGceFTfbrkQpiljNymIaHVq
  return KgRnduCXGceFTfbrkQpiljNymIaHVO
 def CheckSubEnd(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHhA=KgRnduCXGceFTfbrkQpiljNymIaHVO
  try:
   if KgRnduCXGceFTfbrkQpiljNymIaHMV.CheckMainEnd():return KgRnduCXGceFTfbrkQpiljNymIaHVq 
   if KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SUBEND=='0':return KgRnduCXGceFTfbrkQpiljNymIaHhA
   KgRnduCXGceFTfbrkQpiljNymIaHhV =KgRnduCXGceFTfbrkQpiljNymIaHVL(KgRnduCXGceFTfbrkQpiljNymIaHMV.Get_Now_Datetime().strftime('%Y%m%d'))
   KgRnduCXGceFTfbrkQpiljNymIaHhx =KgRnduCXGceFTfbrkQpiljNymIaHVL(KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_SUBEND)/1000
   KgRnduCXGceFTfbrkQpiljNymIaHhD =KgRnduCXGceFTfbrkQpiljNymIaHVL(datetime.datetime.fromtimestamp(KgRnduCXGceFTfbrkQpiljNymIaHhx,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if KgRnduCXGceFTfbrkQpiljNymIaHhV<=KgRnduCXGceFTfbrkQpiljNymIaHhD:KgRnduCXGceFTfbrkQpiljNymIaHhA=KgRnduCXGceFTfbrkQpiljNymIaHVq
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
   return KgRnduCXGceFTfbrkQpiljNymIaHhA
  return KgRnduCXGceFTfbrkQpiljNymIaHhA
 def GetMainJspath(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHhw=''
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHhO=KgRnduCXGceFTfbrkQpiljNymIaHML.text
   KgRnduCXGceFTfbrkQpiljNymIaHht =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',KgRnduCXGceFTfbrkQpiljNymIaHhO)[0]
   KgRnduCXGceFTfbrkQpiljNymIaHhw=KgRnduCXGceFTfbrkQpiljNymIaHht
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHhw
 def GetBcPlayerUrl(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHhY=''
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.GetMainJspath()
   if KgRnduCXGceFTfbrkQpiljNymIaHoA=='':return KgRnduCXGceFTfbrkQpiljNymIaHhY
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHhO=KgRnduCXGceFTfbrkQpiljNymIaHML.text
   KgRnduCXGceFTfbrkQpiljNymIaHhq =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',KgRnduCXGceFTfbrkQpiljNymIaHhO)[0]
   KgRnduCXGceFTfbrkQpiljNymIaHhq =KgRnduCXGceFTfbrkQpiljNymIaHhq.replace('bc','"bc"')
   KgRnduCXGceFTfbrkQpiljNymIaHhq =KgRnduCXGceFTfbrkQpiljNymIaHhq.replace('player','"player"')
   KgRnduCXGceFTfbrkQpiljNymIaHhq ='{'+KgRnduCXGceFTfbrkQpiljNymIaHhq+'}'
   KgRnduCXGceFTfbrkQpiljNymIaHhq =json.loads(KgRnduCXGceFTfbrkQpiljNymIaHhq)
   bc =KgRnduCXGceFTfbrkQpiljNymIaHhq['bc']
   KgRnduCXGceFTfbrkQpiljNymIaHhz =KgRnduCXGceFTfbrkQpiljNymIaHhq['player']
   KgRnduCXGceFTfbrkQpiljNymIaHhY="%s/%s/%s_default/index.min.js"%(KgRnduCXGceFTfbrkQpiljNymIaHMV.BC_DOMAIN,bc,KgRnduCXGceFTfbrkQpiljNymIaHhz)
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHhY
 def GetPolicyKey(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHhW=policykey=''
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.GetBcPlayerUrl()
   if KgRnduCXGceFTfbrkQpiljNymIaHoA=='':return KgRnduCXGceFTfbrkQpiljNymIaHhW,KgRnduCXGceFTfbrkQpiljNymIaHhJ
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHhO=KgRnduCXGceFTfbrkQpiljNymIaHML.text
   KgRnduCXGceFTfbrkQpiljNymIaHht =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',KgRnduCXGceFTfbrkQpiljNymIaHhO)[0]
   KgRnduCXGceFTfbrkQpiljNymIaHht =KgRnduCXGceFTfbrkQpiljNymIaHht.replace('accountId','"accountId"')
   KgRnduCXGceFTfbrkQpiljNymIaHht =KgRnduCXGceFTfbrkQpiljNymIaHht.replace('policyKey','"policyKey"')
   KgRnduCXGceFTfbrkQpiljNymIaHht ='{'+KgRnduCXGceFTfbrkQpiljNymIaHht+'}'
   KgRnduCXGceFTfbrkQpiljNymIaHhL=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHht)
   KgRnduCXGceFTfbrkQpiljNymIaHhW =KgRnduCXGceFTfbrkQpiljNymIaHhL['accountId']
   KgRnduCXGceFTfbrkQpiljNymIaHhJ =KgRnduCXGceFTfbrkQpiljNymIaHhL['policyKey']
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHhW,KgRnduCXGceFTfbrkQpiljNymIaHhJ
 def GetBroadURL(KgRnduCXGceFTfbrkQpiljNymIaHMV,KgRnduCXGceFTfbrkQpiljNymIaHos,mediatype,KgRnduCXGceFTfbrkQpiljNymIaHAx):
  KgRnduCXGceFTfbrkQpiljNymIaHhE=''
  try:
   if mediatype=='live':
    KgRnduCXGceFTfbrkQpiljNymIaHos='ref%3A'+KgRnduCXGceFTfbrkQpiljNymIaHos
   else:
    KgRnduCXGceFTfbrkQpiljNymIaHos=KgRnduCXGceFTfbrkQpiljNymIaHMV.GetReplay_UrlId(KgRnduCXGceFTfbrkQpiljNymIaHos,KgRnduCXGceFTfbrkQpiljNymIaHAx)
    if KgRnduCXGceFTfbrkQpiljNymIaHos=='':return KgRnduCXGceFTfbrkQpiljNymIaHhE
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.PLAYER_DOMAIN+'/playback/v1/accounts/'+KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_ACCOUNTID+'/videos/'+KgRnduCXGceFTfbrkQpiljNymIaHos
   KgRnduCXGceFTfbrkQpiljNymIaHhU={'accept':'application/json;pk='+KgRnduCXGceFTfbrkQpiljNymIaHMV.SPOTV_POLICYKEY}
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHhU,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHhB=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   KgRnduCXGceFTfbrkQpiljNymIaHhE=KgRnduCXGceFTfbrkQpiljNymIaHhB['sources'][0]['src']
   if mediatype=='live':
    KgRnduCXGceFTfbrkQpiljNymIaHhE=KgRnduCXGceFTfbrkQpiljNymIaHhE.replace('playlist.m3u8','playlist_dvr.m3u8')
   KgRnduCXGceFTfbrkQpiljNymIaHhE=KgRnduCXGceFTfbrkQpiljNymIaHhE.replace('http://','https://')
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHhE
 def GetTitleGroupList(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHoM=[]
  KgRnduCXGceFTfbrkQpiljNymIaHhv=KgRnduCXGceFTfbrkQpiljNymIaHVO
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/home/web'
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   for KgRnduCXGceFTfbrkQpiljNymIaHoV in KgRnduCXGceFTfbrkQpiljNymIaHMU:
    KgRnduCXGceFTfbrkQpiljNymIaHox={}
    KgRnduCXGceFTfbrkQpiljNymIaHox['mediatype']='episode'
    if KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHoV['type'])=='3':
     KgRnduCXGceFTfbrkQpiljNymIaHhP=''
     for KgRnduCXGceFTfbrkQpiljNymIaHhS in KgRnduCXGceFTfbrkQpiljNymIaHoV['data']['list']:
      KgRnduCXGceFTfbrkQpiljNymIaHhs='[%s] %s vs %s\n<%s>\n\n'%(KgRnduCXGceFTfbrkQpiljNymIaHhS['gameDesc']['roundName'],KgRnduCXGceFTfbrkQpiljNymIaHhS['gameDesc']['homeNameShort'],KgRnduCXGceFTfbrkQpiljNymIaHhS['gameDesc']['awayNameShort'],KgRnduCXGceFTfbrkQpiljNymIaHhS['gameDesc']['beginDate'])
      KgRnduCXGceFTfbrkQpiljNymIaHhP+=KgRnduCXGceFTfbrkQpiljNymIaHhs
     KgRnduCXGceFTfbrkQpiljNymIaHoD={'title':KgRnduCXGceFTfbrkQpiljNymIaHoV['title'],'logo':KgRnduCXGceFTfbrkQpiljNymIaHoV['logo'],'reagueId':KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHoV['destId']),'subGame':KgRnduCXGceFTfbrkQpiljNymIaHhP,'info':KgRnduCXGceFTfbrkQpiljNymIaHox}
     KgRnduCXGceFTfbrkQpiljNymIaHoM.append(KgRnduCXGceFTfbrkQpiljNymIaHoD)
     if KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHoV['destId'])=='13':KgRnduCXGceFTfbrkQpiljNymIaHhv=KgRnduCXGceFTfbrkQpiljNymIaHVq
   if KgRnduCXGceFTfbrkQpiljNymIaHhv==KgRnduCXGceFTfbrkQpiljNymIaHVO:
    KgRnduCXGceFTfbrkQpiljNymIaHox={'mediatype':'episode'}
    KgRnduCXGceFTfbrkQpiljNymIaHoD={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':'','info':KgRnduCXGceFTfbrkQpiljNymIaHox}
    KgRnduCXGceFTfbrkQpiljNymIaHoM.append(KgRnduCXGceFTfbrkQpiljNymIaHoD)
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHoM
 def GetPopularGroupList(KgRnduCXGceFTfbrkQpiljNymIaHMV):
  KgRnduCXGceFTfbrkQpiljNymIaHoM=[]
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/home/web'
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   for KgRnduCXGceFTfbrkQpiljNymIaHoV in KgRnduCXGceFTfbrkQpiljNymIaHMU:
    KgRnduCXGceFTfbrkQpiljNymIaHox={}
    KgRnduCXGceFTfbrkQpiljNymIaHox['mediatype']='episode'
    if KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHoV['type'])=='1' and KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHoV['destId'])=='4':
     for KgRnduCXGceFTfbrkQpiljNymIaHhS in KgRnduCXGceFTfbrkQpiljNymIaHoV['data']['list']:
      KgRnduCXGceFTfbrkQpiljNymIaHox={}
      KgRnduCXGceFTfbrkQpiljNymIaHox['mediatype']='video'
      KgRnduCXGceFTfbrkQpiljNymIaHAM =KgRnduCXGceFTfbrkQpiljNymIaHhS['title']
      KgRnduCXGceFTfbrkQpiljNymIaHAo =KgRnduCXGceFTfbrkQpiljNymIaHhS['id']
      KgRnduCXGceFTfbrkQpiljNymIaHAh =KgRnduCXGceFTfbrkQpiljNymIaHhS['vtype']
      KgRnduCXGceFTfbrkQpiljNymIaHAV =KgRnduCXGceFTfbrkQpiljNymIaHhS['imgUrl']
      KgRnduCXGceFTfbrkQpiljNymIaHAx =KgRnduCXGceFTfbrkQpiljNymIaHhS['vtypeId']
      KgRnduCXGceFTfbrkQpiljNymIaHox['duration'] =KgRnduCXGceFTfbrkQpiljNymIaHVL(KgRnduCXGceFTfbrkQpiljNymIaHhS['duration']/1000)
      KgRnduCXGceFTfbrkQpiljNymIaHoD={'vodTitle':KgRnduCXGceFTfbrkQpiljNymIaHAM,'vodId':KgRnduCXGceFTfbrkQpiljNymIaHAo,'vodType':KgRnduCXGceFTfbrkQpiljNymIaHAh,'thumbnail':KgRnduCXGceFTfbrkQpiljNymIaHAV,'info':KgRnduCXGceFTfbrkQpiljNymIaHox,'vtypeId':KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHAx)}
      KgRnduCXGceFTfbrkQpiljNymIaHoM.append(KgRnduCXGceFTfbrkQpiljNymIaHoD)
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHoM
 def GetSeasonList(KgRnduCXGceFTfbrkQpiljNymIaHMV,leagueId):
  KgRnduCXGceFTfbrkQpiljNymIaHoM=[]
  KgRnduCXGceFTfbrkQpiljNymIaHAD=KgRnduCXGceFTfbrkQpiljNymIaHAw=''
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/game/league/'+leagueId
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   KgRnduCXGceFTfbrkQpiljNymIaHAD=KgRnduCXGceFTfbrkQpiljNymIaHMU['name']
   KgRnduCXGceFTfbrkQpiljNymIaHAw=KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHMU['gameTypeId'])
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
   return KgRnduCXGceFTfbrkQpiljNymIaHoM
  if KgRnduCXGceFTfbrkQpiljNymIaHAw=='2':
   try:
    KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/year/'+leagueId
    KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
    KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
    for KgRnduCXGceFTfbrkQpiljNymIaHoV in KgRnduCXGceFTfbrkQpiljNymIaHMU:
     KgRnduCXGceFTfbrkQpiljNymIaHox={}
     KgRnduCXGceFTfbrkQpiljNymIaHox['mediatype']='episode'
     KgRnduCXGceFTfbrkQpiljNymIaHoD={'reagueName':KgRnduCXGceFTfbrkQpiljNymIaHAD,'gameTypeId':KgRnduCXGceFTfbrkQpiljNymIaHAw,'seasonName':KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHoV),'seasonId':KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHoV),'info':KgRnduCXGceFTfbrkQpiljNymIaHox}
     KgRnduCXGceFTfbrkQpiljNymIaHoM.append(KgRnduCXGceFTfbrkQpiljNymIaHoD)
   except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
    KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
    return[]
  else:
   try:
    KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/season/'+leagueId
    KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
    KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
    for KgRnduCXGceFTfbrkQpiljNymIaHoV in KgRnduCXGceFTfbrkQpiljNymIaHMU:
     KgRnduCXGceFTfbrkQpiljNymIaHox={}
     KgRnduCXGceFTfbrkQpiljNymIaHox['mediatype']='episode'
     KgRnduCXGceFTfbrkQpiljNymIaHoD={'reagueName':KgRnduCXGceFTfbrkQpiljNymIaHAD,'gameTypeId':KgRnduCXGceFTfbrkQpiljNymIaHAw,'seasonName':KgRnduCXGceFTfbrkQpiljNymIaHoV['name'],'seasonId':KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHoV['id']),'info':KgRnduCXGceFTfbrkQpiljNymIaHox}
     KgRnduCXGceFTfbrkQpiljNymIaHoM.append(KgRnduCXGceFTfbrkQpiljNymIaHoD)
   except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
    KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
    return[]
  return KgRnduCXGceFTfbrkQpiljNymIaHoM
 def GetGameList(KgRnduCXGceFTfbrkQpiljNymIaHMV,KgRnduCXGceFTfbrkQpiljNymIaHAw,leagueId,seasonId,page_int):
  KgRnduCXGceFTfbrkQpiljNymIaHoM=[]
  KgRnduCXGceFTfbrkQpiljNymIaHAO=KgRnduCXGceFTfbrkQpiljNymIaHVO
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/vod/league/detail'
   KgRnduCXGceFTfbrkQpiljNymIaHAt={'gameType':KgRnduCXGceFTfbrkQpiljNymIaHAw,'leagueId':leagueId,'seasonId':seasonId if KgRnduCXGceFTfbrkQpiljNymIaHAw!='2' else '','teamId':'','roundId':'','year':'' if KgRnduCXGceFTfbrkQpiljNymIaHAw!='2' else seasonId,'pageNo':KgRnduCXGceFTfbrkQpiljNymIaHVY(page_int)}
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHAt,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   KgRnduCXGceFTfbrkQpiljNymIaHoP=KgRnduCXGceFTfbrkQpiljNymIaHMU['list']
   for KgRnduCXGceFTfbrkQpiljNymIaHAY in KgRnduCXGceFTfbrkQpiljNymIaHoP:
    for KgRnduCXGceFTfbrkQpiljNymIaHoV in KgRnduCXGceFTfbrkQpiljNymIaHAY['list']:
     KgRnduCXGceFTfbrkQpiljNymIaHox={}
     KgRnduCXGceFTfbrkQpiljNymIaHox['mediatype']='video'
     if KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['title']==KgRnduCXGceFTfbrkQpiljNymIaHVw or KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['title']=='':
      KgRnduCXGceFTfbrkQpiljNymIaHoS ='%s vs %s'%(KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['homeNameShort'],KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['awayNameShort'])
     else:
      KgRnduCXGceFTfbrkQpiljNymIaHoS =KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['title']
     KgRnduCXGceFTfbrkQpiljNymIaHAq =KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['beginDate']
     KgRnduCXGceFTfbrkQpiljNymIaHAz =KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['id']
     KgRnduCXGceFTfbrkQpiljNymIaHAW =KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['leagueNameFull']
     KgRnduCXGceFTfbrkQpiljNymIaHAL =KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['seasonName']
     KgRnduCXGceFTfbrkQpiljNymIaHAJ =KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['roundName']
     KgRnduCXGceFTfbrkQpiljNymIaHAE =KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['homeName']
     KgRnduCXGceFTfbrkQpiljNymIaHAU =KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['awayName']
     KgRnduCXGceFTfbrkQpiljNymIaHAB =KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['homeScore']
     KgRnduCXGceFTfbrkQpiljNymIaHAv =KgRnduCXGceFTfbrkQpiljNymIaHoV['gameDesc']['awayScore']
     KgRnduCXGceFTfbrkQpiljNymIaHAP ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(KgRnduCXGceFTfbrkQpiljNymIaHAW,KgRnduCXGceFTfbrkQpiljNymIaHAL,KgRnduCXGceFTfbrkQpiljNymIaHAJ,KgRnduCXGceFTfbrkQpiljNymIaHAq,KgRnduCXGceFTfbrkQpiljNymIaHAE,KgRnduCXGceFTfbrkQpiljNymIaHAB,KgRnduCXGceFTfbrkQpiljNymIaHAU,KgRnduCXGceFTfbrkQpiljNymIaHAv)
     KgRnduCXGceFTfbrkQpiljNymIaHox['plot']=KgRnduCXGceFTfbrkQpiljNymIaHAP
     KgRnduCXGceFTfbrkQpiljNymIaHAS =KgRnduCXGceFTfbrkQpiljNymIaHoV['replayVod']['count']
     KgRnduCXGceFTfbrkQpiljNymIaHAs=KgRnduCXGceFTfbrkQpiljNymIaHoV['highlightVod']['count']
     KgRnduCXGceFTfbrkQpiljNymIaHVM =KgRnduCXGceFTfbrkQpiljNymIaHoV['vods']['count']
     KgRnduCXGceFTfbrkQpiljNymIaHAV='' 
     KgRnduCXGceFTfbrkQpiljNymIaHVo=KgRnduCXGceFTfbrkQpiljNymIaHAS+KgRnduCXGceFTfbrkQpiljNymIaHAs+KgRnduCXGceFTfbrkQpiljNymIaHVM
     if KgRnduCXGceFTfbrkQpiljNymIaHVo==0:
      if KgRnduCXGceFTfbrkQpiljNymIaHAw=='2':
       KgRnduCXGceFTfbrkQpiljNymIaHoS='----- %s -----'%(KgRnduCXGceFTfbrkQpiljNymIaHAL)
       KgRnduCXGceFTfbrkQpiljNymIaHAq=''
      else:
       KgRnduCXGceFTfbrkQpiljNymIaHoS+=' - 관련영상 없음'
       KgRnduCXGceFTfbrkQpiljNymIaHox['plot']+='\n\n ** 관련영상 없음 **'
     else:
      if KgRnduCXGceFTfbrkQpiljNymIaHAS!=0:
       KgRnduCXGceFTfbrkQpiljNymIaHAV =KgRnduCXGceFTfbrkQpiljNymIaHoV['replayVod']['list'][0]['imgUrl']
      elif KgRnduCXGceFTfbrkQpiljNymIaHAs!=0:
       KgRnduCXGceFTfbrkQpiljNymIaHAV =KgRnduCXGceFTfbrkQpiljNymIaHoV['highlightVod']['list'][0]['imgUrl']
      else:
       KgRnduCXGceFTfbrkQpiljNymIaHAV =KgRnduCXGceFTfbrkQpiljNymIaHoV['vods']['list'][0]['imgUrl']
     KgRnduCXGceFTfbrkQpiljNymIaHoD={'gameTitle':KgRnduCXGceFTfbrkQpiljNymIaHoS,'gameId':KgRnduCXGceFTfbrkQpiljNymIaHAz,'beginDate':KgRnduCXGceFTfbrkQpiljNymIaHAq[:11],'thumbnail':KgRnduCXGceFTfbrkQpiljNymIaHAV,'info':KgRnduCXGceFTfbrkQpiljNymIaHox,'leaguenm':KgRnduCXGceFTfbrkQpiljNymIaHAW,'seasonnm':KgRnduCXGceFTfbrkQpiljNymIaHAL,'roundnm':KgRnduCXGceFTfbrkQpiljNymIaHAJ,'totVodCnt':KgRnduCXGceFTfbrkQpiljNymIaHVo}
     KgRnduCXGceFTfbrkQpiljNymIaHoM.append(KgRnduCXGceFTfbrkQpiljNymIaHoD)
   if KgRnduCXGceFTfbrkQpiljNymIaHAw=='2':
    if KgRnduCXGceFTfbrkQpiljNymIaHMU['count']>page_int*KgRnduCXGceFTfbrkQpiljNymIaHMV.GAMELIST_LIMIT:KgRnduCXGceFTfbrkQpiljNymIaHAO=KgRnduCXGceFTfbrkQpiljNymIaHVq
   else:
    if KgRnduCXGceFTfbrkQpiljNymIaHMU['list'][0]['count']>page_int*KgRnduCXGceFTfbrkQpiljNymIaHMV.GAMELIST_LIMIT:KgRnduCXGceFTfbrkQpiljNymIaHAO=KgRnduCXGceFTfbrkQpiljNymIaHVq
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHoM,KgRnduCXGceFTfbrkQpiljNymIaHAO
 def GetGameVodList(KgRnduCXGceFTfbrkQpiljNymIaHMV,KgRnduCXGceFTfbrkQpiljNymIaHAz):
  KgRnduCXGceFTfbrkQpiljNymIaHoM=[]
  KgRnduCXGceFTfbrkQpiljNymIaHVh=''
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/vod/game'
   KgRnduCXGceFTfbrkQpiljNymIaHAt={'gameId':KgRnduCXGceFTfbrkQpiljNymIaHAz,'pageItem':'1000'}
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHAt,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   KgRnduCXGceFTfbrkQpiljNymIaHAY=KgRnduCXGceFTfbrkQpiljNymIaHMU['list']
   for KgRnduCXGceFTfbrkQpiljNymIaHoV in KgRnduCXGceFTfbrkQpiljNymIaHAY:
    KgRnduCXGceFTfbrkQpiljNymIaHox={}
    KgRnduCXGceFTfbrkQpiljNymIaHox['mediatype']='video'
    KgRnduCXGceFTfbrkQpiljNymIaHAM =KgRnduCXGceFTfbrkQpiljNymIaHoV['title']
    KgRnduCXGceFTfbrkQpiljNymIaHAo =KgRnduCXGceFTfbrkQpiljNymIaHoV['id']
    KgRnduCXGceFTfbrkQpiljNymIaHAh =KgRnduCXGceFTfbrkQpiljNymIaHoV['vtype']
    KgRnduCXGceFTfbrkQpiljNymIaHAV =KgRnduCXGceFTfbrkQpiljNymIaHoV['imgUrl']
    KgRnduCXGceFTfbrkQpiljNymIaHAx =KgRnduCXGceFTfbrkQpiljNymIaHoV['vtypeId']
    KgRnduCXGceFTfbrkQpiljNymIaHox['duration'] =KgRnduCXGceFTfbrkQpiljNymIaHVL(KgRnduCXGceFTfbrkQpiljNymIaHoV['duration']/1000)
    KgRnduCXGceFTfbrkQpiljNymIaHoD={'vodTitle':KgRnduCXGceFTfbrkQpiljNymIaHAM,'vodId':KgRnduCXGceFTfbrkQpiljNymIaHAo,'vodType':KgRnduCXGceFTfbrkQpiljNymIaHAh,'thumbnail':KgRnduCXGceFTfbrkQpiljNymIaHAV,'info':KgRnduCXGceFTfbrkQpiljNymIaHox,'vtypeId':KgRnduCXGceFTfbrkQpiljNymIaHVY(KgRnduCXGceFTfbrkQpiljNymIaHAx)}
    KgRnduCXGceFTfbrkQpiljNymIaHoM.append(KgRnduCXGceFTfbrkQpiljNymIaHoD)
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHoM
 def GetReplay_UrlId(KgRnduCXGceFTfbrkQpiljNymIaHMV,KgRnduCXGceFTfbrkQpiljNymIaHVh,KgRnduCXGceFTfbrkQpiljNymIaHAx):
  KgRnduCXGceFTfbrkQpiljNymIaHVA=KgRnduCXGceFTfbrkQpiljNymIaHos=''
  KgRnduCXGceFTfbrkQpiljNymIaHVx=''
  try:
   KgRnduCXGceFTfbrkQpiljNymIaHoA=KgRnduCXGceFTfbrkQpiljNymIaHMV.API_DOMAIN+'/api/v2/vod/'+KgRnduCXGceFTfbrkQpiljNymIaHVh
   KgRnduCXGceFTfbrkQpiljNymIaHML=KgRnduCXGceFTfbrkQpiljNymIaHMV.callRequestCookies('Get',KgRnduCXGceFTfbrkQpiljNymIaHoA,payload=KgRnduCXGceFTfbrkQpiljNymIaHVw,params=KgRnduCXGceFTfbrkQpiljNymIaHVw,headers=KgRnduCXGceFTfbrkQpiljNymIaHVw,cookies=KgRnduCXGceFTfbrkQpiljNymIaHVw)
   KgRnduCXGceFTfbrkQpiljNymIaHMU=json.loads(KgRnduCXGceFTfbrkQpiljNymIaHML.text)
   KgRnduCXGceFTfbrkQpiljNymIaHVA =KgRnduCXGceFTfbrkQpiljNymIaHMU['clipId']
   KgRnduCXGceFTfbrkQpiljNymIaHos=KgRnduCXGceFTfbrkQpiljNymIaHMU['videoId']
   KgRnduCXGceFTfbrkQpiljNymIaHVx=KgRnduCXGceFTfbrkQpiljNymIaHVA
   if KgRnduCXGceFTfbrkQpiljNymIaHMV.CheckSubEnd()or KgRnduCXGceFTfbrkQpiljNymIaHAx!='1':KgRnduCXGceFTfbrkQpiljNymIaHVx=KgRnduCXGceFTfbrkQpiljNymIaHos 
  except KgRnduCXGceFTfbrkQpiljNymIaHVz as exception:
   KgRnduCXGceFTfbrkQpiljNymIaHVt(exception)
  return KgRnduCXGceFTfbrkQpiljNymIaHVx
# Created by pyminifier (https://github.com/liftoff/pyminifier)
