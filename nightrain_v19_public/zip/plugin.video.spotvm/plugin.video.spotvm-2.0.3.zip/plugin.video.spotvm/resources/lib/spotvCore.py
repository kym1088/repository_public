__author__="NightRain"
AqILuvcwOVzsriXQkTFWDJCyKmSBNo=object
AqILuvcwOVzsriXQkTFWDJCyKmSBNh=None
AqILuvcwOVzsriXQkTFWDJCyKmSBNx=False
AqILuvcwOVzsriXQkTFWDJCyKmSBNR=print
AqILuvcwOVzsriXQkTFWDJCyKmSBNH=str
AqILuvcwOVzsriXQkTFWDJCyKmSBNl=True
AqILuvcwOVzsriXQkTFWDJCyKmSBNb=Exception
AqILuvcwOVzsriXQkTFWDJCyKmSBNg=int
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import base64
AqILuvcwOVzsriXQkTFWDJCyKmSBox ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
AqILuvcwOVzsriXQkTFWDJCyKmSBoR={'stream50':1080,'stream40':720,'stream30':540}
class AqILuvcwOVzsriXQkTFWDJCyKmSBoh(AqILuvcwOVzsriXQkTFWDJCyKmSBNo):
 def __init__(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SESSIONID=''
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SESSION =''
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_ACCOUNTID=''
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_POLICYKEY=''
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SUBEND =''
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_PMCODE ='987'
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_PMSIZE =3
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.GAMELIST_LIMIT =10
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN ='https://www.spotvnow.co.kr'
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.BC_DOMAIN ='https://players.brightcove.net'
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.DEFAULT_HEADER ={'user-agent':AqILuvcwOVzsriXQkTFWDJCyKmSBox}
 def callRequestCookies(AqILuvcwOVzsriXQkTFWDJCyKmSBoN,jobtype,AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,redirects=AqILuvcwOVzsriXQkTFWDJCyKmSBNx):
  AqILuvcwOVzsriXQkTFWDJCyKmSBoH=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.DEFAULT_HEADER
  if headers:AqILuvcwOVzsriXQkTFWDJCyKmSBoH.update(headers)
  if jobtype=='Get':
   AqILuvcwOVzsriXQkTFWDJCyKmSBol=requests.get(AqILuvcwOVzsriXQkTFWDJCyKmSBhR,params=params,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBoH,cookies=cookies,allow_redirects=redirects)
  else:
   AqILuvcwOVzsriXQkTFWDJCyKmSBol=requests.post(AqILuvcwOVzsriXQkTFWDJCyKmSBhR,data=payload,params=params,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBoH,cookies=cookies,allow_redirects=redirects)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBol
 def makeDefaultCookies(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBob={'SESSION':AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SESSION}
  return AqILuvcwOVzsriXQkTFWDJCyKmSBob
 def GetCredential(AqILuvcwOVzsriXQkTFWDJCyKmSBoN,user_id,user_pw):
  AqILuvcwOVzsriXQkTFWDJCyKmSBog=AqILuvcwOVzsriXQkTFWDJCyKmSBNx
  AqILuvcwOVzsriXQkTFWDJCyKmSBoe=AqILuvcwOVzsriXQkTFWDJCyKmSBoa=AqILuvcwOVzsriXQkTFWDJCyKmSBoU=AqILuvcwOVzsriXQkTFWDJCyKmSBoj=AqILuvcwOVzsriXQkTFWDJCyKmSBoE=''
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBod=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   AqILuvcwOVzsriXQkTFWDJCyKmSBon=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   AqILuvcwOVzsriXQkTFWDJCyKmSBoM=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN+'/api/v2/login'
   AqILuvcwOVzsriXQkTFWDJCyKmSBoG={'username':AqILuvcwOVzsriXQkTFWDJCyKmSBod,'password':AqILuvcwOVzsriXQkTFWDJCyKmSBon}
   AqILuvcwOVzsriXQkTFWDJCyKmSBoG=json.dumps(AqILuvcwOVzsriXQkTFWDJCyKmSBoG)
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Post',AqILuvcwOVzsriXQkTFWDJCyKmSBoM,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBoG,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.status_code)
   for AqILuvcwOVzsriXQkTFWDJCyKmSBot in AqILuvcwOVzsriXQkTFWDJCyKmSBoY.cookies:
    if AqILuvcwOVzsriXQkTFWDJCyKmSBot.name=='SESSION':
     AqILuvcwOVzsriXQkTFWDJCyKmSBoa=AqILuvcwOVzsriXQkTFWDJCyKmSBot.value
     break
   if AqILuvcwOVzsriXQkTFWDJCyKmSBoa=='':return AqILuvcwOVzsriXQkTFWDJCyKmSBog
   AqILuvcwOVzsriXQkTFWDJCyKmSBoP=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
   if not('userId' in AqILuvcwOVzsriXQkTFWDJCyKmSBoP):return AqILuvcwOVzsriXQkTFWDJCyKmSBog
   AqILuvcwOVzsriXQkTFWDJCyKmSBoe=AqILuvcwOVzsriXQkTFWDJCyKmSBNH(AqILuvcwOVzsriXQkTFWDJCyKmSBoP['userId'])
   AqILuvcwOVzsriXQkTFWDJCyKmSBoE =AqILuvcwOVzsriXQkTFWDJCyKmSBNH(AqILuvcwOVzsriXQkTFWDJCyKmSBoP['subEndTime'])
   AqILuvcwOVzsriXQkTFWDJCyKmSBoU,AqILuvcwOVzsriXQkTFWDJCyKmSBoj=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.GetPolicyKey()
   if AqILuvcwOVzsriXQkTFWDJCyKmSBoj=='':return AqILuvcwOVzsriXQkTFWDJCyKmSBog
   AqILuvcwOVzsriXQkTFWDJCyKmSBog=AqILuvcwOVzsriXQkTFWDJCyKmSBNl
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBoe=AqILuvcwOVzsriXQkTFWDJCyKmSBoa='' 
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  AqILuvcwOVzsriXQkTFWDJCyKmSBof={'spotv_sessionid':AqILuvcwOVzsriXQkTFWDJCyKmSBoe,'spotv_session':AqILuvcwOVzsriXQkTFWDJCyKmSBoa,'spotv_accountId':AqILuvcwOVzsriXQkTFWDJCyKmSBoU,'spotv_policyKey':AqILuvcwOVzsriXQkTFWDJCyKmSBoj,'spotv_subend':AqILuvcwOVzsriXQkTFWDJCyKmSBoE}
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SaveCredential(AqILuvcwOVzsriXQkTFWDJCyKmSBof)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBog
 def SaveCredential(AqILuvcwOVzsriXQkTFWDJCyKmSBoN,AqILuvcwOVzsriXQkTFWDJCyKmSBof):
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SESSIONID=AqILuvcwOVzsriXQkTFWDJCyKmSBof.get('spotv_sessionid')
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SESSION =AqILuvcwOVzsriXQkTFWDJCyKmSBof.get('spotv_session')
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_ACCOUNTID=AqILuvcwOVzsriXQkTFWDJCyKmSBof.get('spotv_accountId')
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_POLICYKEY=AqILuvcwOVzsriXQkTFWDJCyKmSBof.get('spotv_policyKey')
  AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SUBEND =AqILuvcwOVzsriXQkTFWDJCyKmSBof.get('spotv_subend')
 def LoadCredential(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBof={'spotv_sessionid':AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SESSIONID,'spotv_session':AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SESSION,'spotv_accountId':AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_ACCOUNTID,'spotv_policyKey':AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_POLICYKEY,'spotv_subend':AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SUBEND}
  return AqILuvcwOVzsriXQkTFWDJCyKmSBof
 def Get_Now_Datetime(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetLiveChannelList(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBho=[]
  AqILuvcwOVzsriXQkTFWDJCyKmSBhx ={}
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN+'/api/v2/channel'
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBoP=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
   AqILuvcwOVzsriXQkTFWDJCyKmSBhx=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.GetEPGList()
   for AqILuvcwOVzsriXQkTFWDJCyKmSBhN in AqILuvcwOVzsriXQkTFWDJCyKmSBoP:
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH={}
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH['mediatype']='video'
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH['title'] =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['programName']
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH['studio'] =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['name']
    AqILuvcwOVzsriXQkTFWDJCyKmSBhl={'id':AqILuvcwOVzsriXQkTFWDJCyKmSBhN['id'],'name':AqILuvcwOVzsriXQkTFWDJCyKmSBhN['name'],'logo':AqILuvcwOVzsriXQkTFWDJCyKmSBhN['logo'],'videoId':AqILuvcwOVzsriXQkTFWDJCyKmSBhN['videoId'].replace('ref:',''),'free':AqILuvcwOVzsriXQkTFWDJCyKmSBhN['free'],'programName':AqILuvcwOVzsriXQkTFWDJCyKmSBhN['programName'],'channelepg':AqILuvcwOVzsriXQkTFWDJCyKmSBhx.get(AqILuvcwOVzsriXQkTFWDJCyKmSBhN['id']),'info':AqILuvcwOVzsriXQkTFWDJCyKmSBhH}
    AqILuvcwOVzsriXQkTFWDJCyKmSBho.append(AqILuvcwOVzsriXQkTFWDJCyKmSBhl)
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBho
 def GetEPGList(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBhb={}
  AqILuvcwOVzsriXQkTFWDJCyKmSBhg=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.Get_Now_Datetime()
  AqILuvcwOVzsriXQkTFWDJCyKmSBhe=AqILuvcwOVzsriXQkTFWDJCyKmSBhg.strftime('%Y%m%d%H%M')
  AqILuvcwOVzsriXQkTFWDJCyKmSBhd='%s-%s-%s'%(AqILuvcwOVzsriXQkTFWDJCyKmSBhe[0:4],AqILuvcwOVzsriXQkTFWDJCyKmSBhe[4:6],AqILuvcwOVzsriXQkTFWDJCyKmSBhe[6:8])
  AqILuvcwOVzsriXQkTFWDJCyKmSBhn=(AqILuvcwOVzsriXQkTFWDJCyKmSBhg+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN+'/api/v2/program/'+AqILuvcwOVzsriXQkTFWDJCyKmSBhd
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBoP=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
   AqILuvcwOVzsriXQkTFWDJCyKmSBhM=-1 
   AqILuvcwOVzsriXQkTFWDJCyKmSBhG =''
   for AqILuvcwOVzsriXQkTFWDJCyKmSBhN in AqILuvcwOVzsriXQkTFWDJCyKmSBoP:
    AqILuvcwOVzsriXQkTFWDJCyKmSBhY=AqILuvcwOVzsriXQkTFWDJCyKmSBhN['channelId']
    AqILuvcwOVzsriXQkTFWDJCyKmSBht =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['startTime'].replace('-','').replace(' ','').replace(':','')
    AqILuvcwOVzsriXQkTFWDJCyKmSBha =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['endTime'].replace('-','').replace(' ','').replace(':','')
    if AqILuvcwOVzsriXQkTFWDJCyKmSBNg(AqILuvcwOVzsriXQkTFWDJCyKmSBhe)>AqILuvcwOVzsriXQkTFWDJCyKmSBNg(AqILuvcwOVzsriXQkTFWDJCyKmSBha) :continue
    if AqILuvcwOVzsriXQkTFWDJCyKmSBNg(AqILuvcwOVzsriXQkTFWDJCyKmSBhn)<AqILuvcwOVzsriXQkTFWDJCyKmSBNg(AqILuvcwOVzsriXQkTFWDJCyKmSBht):continue
    if AqILuvcwOVzsriXQkTFWDJCyKmSBhM!=AqILuvcwOVzsriXQkTFWDJCyKmSBhY:
     if AqILuvcwOVzsriXQkTFWDJCyKmSBhG!='':AqILuvcwOVzsriXQkTFWDJCyKmSBhb[AqILuvcwOVzsriXQkTFWDJCyKmSBhM]=AqILuvcwOVzsriXQkTFWDJCyKmSBhG
     AqILuvcwOVzsriXQkTFWDJCyKmSBhM=AqILuvcwOVzsriXQkTFWDJCyKmSBhY
     AqILuvcwOVzsriXQkTFWDJCyKmSBhG =''
    if AqILuvcwOVzsriXQkTFWDJCyKmSBhG:AqILuvcwOVzsriXQkTFWDJCyKmSBhG+='\n'
    AqILuvcwOVzsriXQkTFWDJCyKmSBhG+=AqILuvcwOVzsriXQkTFWDJCyKmSBhN['title']+'\n'
    AqILuvcwOVzsriXQkTFWDJCyKmSBhG+=' [%s ~ %s]'%(AqILuvcwOVzsriXQkTFWDJCyKmSBhN['startTime'][-5:],AqILuvcwOVzsriXQkTFWDJCyKmSBhN['endTime'][-5:])+'\n'
   if AqILuvcwOVzsriXQkTFWDJCyKmSBhG:AqILuvcwOVzsriXQkTFWDJCyKmSBhb[AqILuvcwOVzsriXQkTFWDJCyKmSBhM]=AqILuvcwOVzsriXQkTFWDJCyKmSBhG
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBhb
 def CheckMainEnd(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBhP=base64.standard_b64encode((AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_PMCODE+AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SESSIONID).encode()).decode('utf-8')
  if AqILuvcwOVzsriXQkTFWDJCyKmSBhP=='OTg3MTgzMzM0Ng==' or AqILuvcwOVzsriXQkTFWDJCyKmSBhP=='OTg3MTgzMzExNw==':return AqILuvcwOVzsriXQkTFWDJCyKmSBNl
  return AqILuvcwOVzsriXQkTFWDJCyKmSBNx
 def CheckSubEnd(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBhE=AqILuvcwOVzsriXQkTFWDJCyKmSBNx
  try:
   if AqILuvcwOVzsriXQkTFWDJCyKmSBoN.CheckMainEnd():return AqILuvcwOVzsriXQkTFWDJCyKmSBNl 
   if AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SUBEND=='0':return AqILuvcwOVzsriXQkTFWDJCyKmSBhE
   AqILuvcwOVzsriXQkTFWDJCyKmSBhU =AqILuvcwOVzsriXQkTFWDJCyKmSBNg(AqILuvcwOVzsriXQkTFWDJCyKmSBoN.Get_Now_Datetime().strftime('%Y%m%d'))
   AqILuvcwOVzsriXQkTFWDJCyKmSBhj =AqILuvcwOVzsriXQkTFWDJCyKmSBNg(AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_SUBEND)/1000
   AqILuvcwOVzsriXQkTFWDJCyKmSBhf =AqILuvcwOVzsriXQkTFWDJCyKmSBNg(datetime.datetime.fromtimestamp(AqILuvcwOVzsriXQkTFWDJCyKmSBhj,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if AqILuvcwOVzsriXQkTFWDJCyKmSBhU<=AqILuvcwOVzsriXQkTFWDJCyKmSBhf:AqILuvcwOVzsriXQkTFWDJCyKmSBhE=AqILuvcwOVzsriXQkTFWDJCyKmSBNl
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
   return AqILuvcwOVzsriXQkTFWDJCyKmSBhE
  return AqILuvcwOVzsriXQkTFWDJCyKmSBhE
 def GetMainJspath(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBhp=''
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBxo=AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text
   AqILuvcwOVzsriXQkTFWDJCyKmSBxh =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',AqILuvcwOVzsriXQkTFWDJCyKmSBxo)[0]
   AqILuvcwOVzsriXQkTFWDJCyKmSBhp=AqILuvcwOVzsriXQkTFWDJCyKmSBxh
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBhp
 def GetBcPlayerUrl(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBxR=''
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.GetMainJspath()
   if AqILuvcwOVzsriXQkTFWDJCyKmSBhR=='':return AqILuvcwOVzsriXQkTFWDJCyKmSBxR
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBxo=AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text
   AqILuvcwOVzsriXQkTFWDJCyKmSBxN =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',AqILuvcwOVzsriXQkTFWDJCyKmSBxo)[0]
   AqILuvcwOVzsriXQkTFWDJCyKmSBxN =AqILuvcwOVzsriXQkTFWDJCyKmSBxN.replace('bc','"bc"')
   AqILuvcwOVzsriXQkTFWDJCyKmSBxN =AqILuvcwOVzsriXQkTFWDJCyKmSBxN.replace('player','"player"')
   AqILuvcwOVzsriXQkTFWDJCyKmSBxN ='{'+AqILuvcwOVzsriXQkTFWDJCyKmSBxN+'}'
   AqILuvcwOVzsriXQkTFWDJCyKmSBxN =json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBxN)
   bc =AqILuvcwOVzsriXQkTFWDJCyKmSBxN['bc']
   AqILuvcwOVzsriXQkTFWDJCyKmSBxH =AqILuvcwOVzsriXQkTFWDJCyKmSBxN['player']
   AqILuvcwOVzsriXQkTFWDJCyKmSBxR="%s/%s/%s_default/index.min.js"%(AqILuvcwOVzsriXQkTFWDJCyKmSBoN.BC_DOMAIN,bc,AqILuvcwOVzsriXQkTFWDJCyKmSBxH)
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBxR
 def GetPolicyKey(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBxl=policykey=''
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.GetBcPlayerUrl()
   if AqILuvcwOVzsriXQkTFWDJCyKmSBhR=='':return AqILuvcwOVzsriXQkTFWDJCyKmSBxl,AqILuvcwOVzsriXQkTFWDJCyKmSBxg
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBxo=AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text
   AqILuvcwOVzsriXQkTFWDJCyKmSBxh =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',AqILuvcwOVzsriXQkTFWDJCyKmSBxo)[0]
   AqILuvcwOVzsriXQkTFWDJCyKmSBxh =AqILuvcwOVzsriXQkTFWDJCyKmSBxh.replace('accountId','"accountId"')
   AqILuvcwOVzsriXQkTFWDJCyKmSBxh =AqILuvcwOVzsriXQkTFWDJCyKmSBxh.replace('policyKey','"policyKey"')
   AqILuvcwOVzsriXQkTFWDJCyKmSBxh ='{'+AqILuvcwOVzsriXQkTFWDJCyKmSBxh+'}'
   AqILuvcwOVzsriXQkTFWDJCyKmSBxb=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBxh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBxl =AqILuvcwOVzsriXQkTFWDJCyKmSBxb['accountId']
   AqILuvcwOVzsriXQkTFWDJCyKmSBxg =AqILuvcwOVzsriXQkTFWDJCyKmSBxb['policyKey']
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBxl,AqILuvcwOVzsriXQkTFWDJCyKmSBxg
 def GetBroadURL(AqILuvcwOVzsriXQkTFWDJCyKmSBoN,AqILuvcwOVzsriXQkTFWDJCyKmSBxd,mediatype):
  AqILuvcwOVzsriXQkTFWDJCyKmSBxe=''
  try:
   if mediatype=='live':
    AqILuvcwOVzsriXQkTFWDJCyKmSBxd='ref%3A'+AqILuvcwOVzsriXQkTFWDJCyKmSBxd
   else:
    AqILuvcwOVzsriXQkTFWDJCyKmSBxd=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.GetReplay_UrlId(AqILuvcwOVzsriXQkTFWDJCyKmSBxd)
    if AqILuvcwOVzsriXQkTFWDJCyKmSBxd=='':return AqILuvcwOVzsriXQkTFWDJCyKmSBxe
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.PLAYER_DOMAIN+'/playback/v1/accounts/'+AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_ACCOUNTID+'/videos/'+AqILuvcwOVzsriXQkTFWDJCyKmSBxd
   AqILuvcwOVzsriXQkTFWDJCyKmSBxn={'accept':'application/json;pk='+AqILuvcwOVzsriXQkTFWDJCyKmSBoN.SPOTV_POLICYKEY}
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBxn,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBxM=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
   AqILuvcwOVzsriXQkTFWDJCyKmSBxe=AqILuvcwOVzsriXQkTFWDJCyKmSBxM['sources'][0]['src']
   if mediatype=='live':
    AqILuvcwOVzsriXQkTFWDJCyKmSBxe=AqILuvcwOVzsriXQkTFWDJCyKmSBxe.replace('playlist.m3u8','playlist_dvr.m3u8')
   AqILuvcwOVzsriXQkTFWDJCyKmSBxe=AqILuvcwOVzsriXQkTFWDJCyKmSBxe.replace('http://','https://')
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBxe
 def GetTitleGroupList(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBho=[]
  AqILuvcwOVzsriXQkTFWDJCyKmSBxG=AqILuvcwOVzsriXQkTFWDJCyKmSBNx
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN+'/api/v2/home/web'
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBoP=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
   for AqILuvcwOVzsriXQkTFWDJCyKmSBhN in AqILuvcwOVzsriXQkTFWDJCyKmSBoP:
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH={}
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH['mediatype']='episode'
    if AqILuvcwOVzsriXQkTFWDJCyKmSBNH(AqILuvcwOVzsriXQkTFWDJCyKmSBhN['type'])=='3':
     AqILuvcwOVzsriXQkTFWDJCyKmSBxY=''
     for AqILuvcwOVzsriXQkTFWDJCyKmSBxt in AqILuvcwOVzsriXQkTFWDJCyKmSBhN['data']['list']:
      AqILuvcwOVzsriXQkTFWDJCyKmSBxa='[%s] %s vs %s\n<%s>\n\n'%(AqILuvcwOVzsriXQkTFWDJCyKmSBxt['gameDesc']['roundName'],AqILuvcwOVzsriXQkTFWDJCyKmSBxt['gameDesc']['homeNameShort'],AqILuvcwOVzsriXQkTFWDJCyKmSBxt['gameDesc']['awayNameShort'],AqILuvcwOVzsriXQkTFWDJCyKmSBxt['gameDesc']['beginDate'])
      AqILuvcwOVzsriXQkTFWDJCyKmSBxY+=AqILuvcwOVzsriXQkTFWDJCyKmSBxa
     AqILuvcwOVzsriXQkTFWDJCyKmSBhl={'title':AqILuvcwOVzsriXQkTFWDJCyKmSBhN['title'],'logo':AqILuvcwOVzsriXQkTFWDJCyKmSBhN['logo'],'reagueId':AqILuvcwOVzsriXQkTFWDJCyKmSBNH(AqILuvcwOVzsriXQkTFWDJCyKmSBhN['destId']),'subGame':AqILuvcwOVzsriXQkTFWDJCyKmSBxY,'info':AqILuvcwOVzsriXQkTFWDJCyKmSBhH}
     AqILuvcwOVzsriXQkTFWDJCyKmSBho.append(AqILuvcwOVzsriXQkTFWDJCyKmSBhl)
     if AqILuvcwOVzsriXQkTFWDJCyKmSBNH(AqILuvcwOVzsriXQkTFWDJCyKmSBhN['destId'])=='13':AqILuvcwOVzsriXQkTFWDJCyKmSBxG=AqILuvcwOVzsriXQkTFWDJCyKmSBNl
     AqILuvcwOVzsriXQkTFWDJCyKmSBxG=AqILuvcwOVzsriXQkTFWDJCyKmSBNl 
   if AqILuvcwOVzsriXQkTFWDJCyKmSBxG==AqILuvcwOVzsriXQkTFWDJCyKmSBNx:
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH={'mediatype':'episode'}
    AqILuvcwOVzsriXQkTFWDJCyKmSBhl={'title':'UFC','logo':'','reagueId':'13','subGame':'','info':AqILuvcwOVzsriXQkTFWDJCyKmSBhH}
    AqILuvcwOVzsriXQkTFWDJCyKmSBho.append(AqILuvcwOVzsriXQkTFWDJCyKmSBhl)
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBho
 def GetPopularGroupList(AqILuvcwOVzsriXQkTFWDJCyKmSBoN):
  AqILuvcwOVzsriXQkTFWDJCyKmSBho=[]
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN+'/api/v2/home/web'
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBoP=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
   for AqILuvcwOVzsriXQkTFWDJCyKmSBhN in AqILuvcwOVzsriXQkTFWDJCyKmSBoP:
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH={}
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH['mediatype']='episode'
    if AqILuvcwOVzsriXQkTFWDJCyKmSBNH(AqILuvcwOVzsriXQkTFWDJCyKmSBhN['type'])=='1' and AqILuvcwOVzsriXQkTFWDJCyKmSBNH(AqILuvcwOVzsriXQkTFWDJCyKmSBhN['destId'])=='4':
     for AqILuvcwOVzsriXQkTFWDJCyKmSBxt in AqILuvcwOVzsriXQkTFWDJCyKmSBhN['data']['list']:
      AqILuvcwOVzsriXQkTFWDJCyKmSBhH={}
      AqILuvcwOVzsriXQkTFWDJCyKmSBhH['mediatype']='video'
      AqILuvcwOVzsriXQkTFWDJCyKmSBxP =AqILuvcwOVzsriXQkTFWDJCyKmSBxt['title']
      AqILuvcwOVzsriXQkTFWDJCyKmSBxE =AqILuvcwOVzsriXQkTFWDJCyKmSBxt['id']
      AqILuvcwOVzsriXQkTFWDJCyKmSBxU =AqILuvcwOVzsriXQkTFWDJCyKmSBxt['vtype']
      AqILuvcwOVzsriXQkTFWDJCyKmSBxj =AqILuvcwOVzsriXQkTFWDJCyKmSBxt['imgUrl']
      AqILuvcwOVzsriXQkTFWDJCyKmSBhH['duration'] =AqILuvcwOVzsriXQkTFWDJCyKmSBNg(AqILuvcwOVzsriXQkTFWDJCyKmSBxt['duration']/1000)
      AqILuvcwOVzsriXQkTFWDJCyKmSBhl={'vodTitle':AqILuvcwOVzsriXQkTFWDJCyKmSBxP,'vodId':AqILuvcwOVzsriXQkTFWDJCyKmSBxE,'vodType':AqILuvcwOVzsriXQkTFWDJCyKmSBxU,'thumbnail':AqILuvcwOVzsriXQkTFWDJCyKmSBxj,'info':AqILuvcwOVzsriXQkTFWDJCyKmSBhH}
      AqILuvcwOVzsriXQkTFWDJCyKmSBho.append(AqILuvcwOVzsriXQkTFWDJCyKmSBhl)
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBho
 def GetSeasonList(AqILuvcwOVzsriXQkTFWDJCyKmSBoN,leagueId):
  AqILuvcwOVzsriXQkTFWDJCyKmSBho=[]
  AqILuvcwOVzsriXQkTFWDJCyKmSBxf=AqILuvcwOVzsriXQkTFWDJCyKmSBxp=''
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN+'/api/v2/game/league/'+leagueId
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBoP=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
   AqILuvcwOVzsriXQkTFWDJCyKmSBxf=AqILuvcwOVzsriXQkTFWDJCyKmSBoP['name']
   AqILuvcwOVzsriXQkTFWDJCyKmSBxp=AqILuvcwOVzsriXQkTFWDJCyKmSBNH(AqILuvcwOVzsriXQkTFWDJCyKmSBoP['gameTypeId'])
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
   return AqILuvcwOVzsriXQkTFWDJCyKmSBho
  if AqILuvcwOVzsriXQkTFWDJCyKmSBxp=='2':
   try:
    AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN+'/api/v2/year/'+leagueId
    AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
    AqILuvcwOVzsriXQkTFWDJCyKmSBoP=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
    for AqILuvcwOVzsriXQkTFWDJCyKmSBhN in AqILuvcwOVzsriXQkTFWDJCyKmSBoP:
     AqILuvcwOVzsriXQkTFWDJCyKmSBhH={}
     AqILuvcwOVzsriXQkTFWDJCyKmSBhH['mediatype']='episode'
     AqILuvcwOVzsriXQkTFWDJCyKmSBhl={'reagueName':AqILuvcwOVzsriXQkTFWDJCyKmSBxf,'gameTypeId':AqILuvcwOVzsriXQkTFWDJCyKmSBxp,'seasonName':AqILuvcwOVzsriXQkTFWDJCyKmSBNH(AqILuvcwOVzsriXQkTFWDJCyKmSBhN),'seasonId':AqILuvcwOVzsriXQkTFWDJCyKmSBNH(AqILuvcwOVzsriXQkTFWDJCyKmSBhN),'info':AqILuvcwOVzsriXQkTFWDJCyKmSBhH}
     AqILuvcwOVzsriXQkTFWDJCyKmSBho.append(AqILuvcwOVzsriXQkTFWDJCyKmSBhl)
   except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
    AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
    return[]
  else:
   try:
    AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN+'/api/v2/season/'+leagueId
    AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
    AqILuvcwOVzsriXQkTFWDJCyKmSBoP=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
    for AqILuvcwOVzsriXQkTFWDJCyKmSBhN in AqILuvcwOVzsriXQkTFWDJCyKmSBoP:
     AqILuvcwOVzsriXQkTFWDJCyKmSBhH={}
     AqILuvcwOVzsriXQkTFWDJCyKmSBhH['mediatype']='episode'
     AqILuvcwOVzsriXQkTFWDJCyKmSBhl={'reagueName':AqILuvcwOVzsriXQkTFWDJCyKmSBxf,'gameTypeId':AqILuvcwOVzsriXQkTFWDJCyKmSBxp,'seasonName':AqILuvcwOVzsriXQkTFWDJCyKmSBhN['name'],'seasonId':AqILuvcwOVzsriXQkTFWDJCyKmSBNH(AqILuvcwOVzsriXQkTFWDJCyKmSBhN['id']),'info':AqILuvcwOVzsriXQkTFWDJCyKmSBhH}
     AqILuvcwOVzsriXQkTFWDJCyKmSBho.append(AqILuvcwOVzsriXQkTFWDJCyKmSBhl)
   except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
    AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
    return[]
  return AqILuvcwOVzsriXQkTFWDJCyKmSBho
 def GetGameList(AqILuvcwOVzsriXQkTFWDJCyKmSBoN,AqILuvcwOVzsriXQkTFWDJCyKmSBxp,leagueId,seasonId,page_int):
  AqILuvcwOVzsriXQkTFWDJCyKmSBho=[]
  AqILuvcwOVzsriXQkTFWDJCyKmSBRo=AqILuvcwOVzsriXQkTFWDJCyKmSBNx
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN+'/api/v2/vod/league/detail'
   AqILuvcwOVzsriXQkTFWDJCyKmSBRh={'gameType':AqILuvcwOVzsriXQkTFWDJCyKmSBxp,'leagueId':leagueId,'seasonId':seasonId if AqILuvcwOVzsriXQkTFWDJCyKmSBxp!='2' else '','teamId':'','roundId':'','year':'' if AqILuvcwOVzsriXQkTFWDJCyKmSBxp!='2' else seasonId,'pageNo':AqILuvcwOVzsriXQkTFWDJCyKmSBNH(page_int)}
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBRh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBoP=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
   AqILuvcwOVzsriXQkTFWDJCyKmSBRx=AqILuvcwOVzsriXQkTFWDJCyKmSBoP['list']
   for AqILuvcwOVzsriXQkTFWDJCyKmSBRN in AqILuvcwOVzsriXQkTFWDJCyKmSBRx:
    for AqILuvcwOVzsriXQkTFWDJCyKmSBhN in AqILuvcwOVzsriXQkTFWDJCyKmSBRN['list']:
     AqILuvcwOVzsriXQkTFWDJCyKmSBhH={}
     AqILuvcwOVzsriXQkTFWDJCyKmSBhH['mediatype']='video'
     if AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['title']==AqILuvcwOVzsriXQkTFWDJCyKmSBNh or AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['title']=='':
      AqILuvcwOVzsriXQkTFWDJCyKmSBRH ='%s vs %s'%(AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['homeNameShort'],AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['awayNameShort'])
     else:
      AqILuvcwOVzsriXQkTFWDJCyKmSBRH =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['title']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRl =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['beginDate']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRb =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['id']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRg =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['leagueNameFull']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRe =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['seasonName']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRd =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['roundName']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRn =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['homeName']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRM =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['awayName']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRG =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['homeScore']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRY =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['gameDesc']['awayScore']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRt ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(AqILuvcwOVzsriXQkTFWDJCyKmSBRg,AqILuvcwOVzsriXQkTFWDJCyKmSBRe,AqILuvcwOVzsriXQkTFWDJCyKmSBRd,AqILuvcwOVzsriXQkTFWDJCyKmSBRl,AqILuvcwOVzsriXQkTFWDJCyKmSBRn,AqILuvcwOVzsriXQkTFWDJCyKmSBRG,AqILuvcwOVzsriXQkTFWDJCyKmSBRM,AqILuvcwOVzsriXQkTFWDJCyKmSBRY)
     AqILuvcwOVzsriXQkTFWDJCyKmSBhH['plot']=AqILuvcwOVzsriXQkTFWDJCyKmSBRt
     AqILuvcwOVzsriXQkTFWDJCyKmSBRa =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['replayVod']['count']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRP=AqILuvcwOVzsriXQkTFWDJCyKmSBhN['highlightVod']['count']
     AqILuvcwOVzsriXQkTFWDJCyKmSBRE =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['vods']['count']
     AqILuvcwOVzsriXQkTFWDJCyKmSBxj='' 
     AqILuvcwOVzsriXQkTFWDJCyKmSBRU=AqILuvcwOVzsriXQkTFWDJCyKmSBRa+AqILuvcwOVzsriXQkTFWDJCyKmSBRP+AqILuvcwOVzsriXQkTFWDJCyKmSBRE
     if AqILuvcwOVzsriXQkTFWDJCyKmSBRU==0:
      if AqILuvcwOVzsriXQkTFWDJCyKmSBxp=='2':
       AqILuvcwOVzsriXQkTFWDJCyKmSBRH='----- %s -----'%(AqILuvcwOVzsriXQkTFWDJCyKmSBRe)
       AqILuvcwOVzsriXQkTFWDJCyKmSBRl=''
      else:
       AqILuvcwOVzsriXQkTFWDJCyKmSBRH+=' - 관련영상 없음'
       AqILuvcwOVzsriXQkTFWDJCyKmSBhH['plot']+='\n\n ** 관련영상 없음 **'
     else:
      if AqILuvcwOVzsriXQkTFWDJCyKmSBRa!=0:
       AqILuvcwOVzsriXQkTFWDJCyKmSBxj =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['replayVod']['list'][0]['imgUrl']
      elif AqILuvcwOVzsriXQkTFWDJCyKmSBRP!=0:
       AqILuvcwOVzsriXQkTFWDJCyKmSBxj =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['highlightVod']['list'][0]['imgUrl']
      else:
       AqILuvcwOVzsriXQkTFWDJCyKmSBxj =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['vods']['list'][0]['imgUrl']
     AqILuvcwOVzsriXQkTFWDJCyKmSBhl={'gameTitle':AqILuvcwOVzsriXQkTFWDJCyKmSBRH,'gameId':AqILuvcwOVzsriXQkTFWDJCyKmSBRb,'beginDate':AqILuvcwOVzsriXQkTFWDJCyKmSBRl[:11],'thumbnail':AqILuvcwOVzsriXQkTFWDJCyKmSBxj,'info':AqILuvcwOVzsriXQkTFWDJCyKmSBhH,'leaguenm':AqILuvcwOVzsriXQkTFWDJCyKmSBRg,'seasonnm':AqILuvcwOVzsriXQkTFWDJCyKmSBRe,'roundnm':AqILuvcwOVzsriXQkTFWDJCyKmSBRd,'totVodCnt':AqILuvcwOVzsriXQkTFWDJCyKmSBRU}
     AqILuvcwOVzsriXQkTFWDJCyKmSBho.append(AqILuvcwOVzsriXQkTFWDJCyKmSBhl)
   if AqILuvcwOVzsriXQkTFWDJCyKmSBxp=='2':
    if AqILuvcwOVzsriXQkTFWDJCyKmSBoP['count']>page_int*AqILuvcwOVzsriXQkTFWDJCyKmSBoN.GAMELIST_LIMIT:AqILuvcwOVzsriXQkTFWDJCyKmSBRo=AqILuvcwOVzsriXQkTFWDJCyKmSBNl
   else:
    if AqILuvcwOVzsriXQkTFWDJCyKmSBoP['list'][0]['count']>page_int*AqILuvcwOVzsriXQkTFWDJCyKmSBoN.GAMELIST_LIMIT:AqILuvcwOVzsriXQkTFWDJCyKmSBRo=AqILuvcwOVzsriXQkTFWDJCyKmSBNl
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBho,AqILuvcwOVzsriXQkTFWDJCyKmSBRo
 def GetGameVodList(AqILuvcwOVzsriXQkTFWDJCyKmSBoN,AqILuvcwOVzsriXQkTFWDJCyKmSBRb):
  AqILuvcwOVzsriXQkTFWDJCyKmSBho=[]
  AqILuvcwOVzsriXQkTFWDJCyKmSBRj=''
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN+'/api/v2/vod/game'
   AqILuvcwOVzsriXQkTFWDJCyKmSBRh={'gameId':AqILuvcwOVzsriXQkTFWDJCyKmSBRb,'pageItem':'1000'}
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBRh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBoP=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
   AqILuvcwOVzsriXQkTFWDJCyKmSBRN=AqILuvcwOVzsriXQkTFWDJCyKmSBoP['list']
   for AqILuvcwOVzsriXQkTFWDJCyKmSBhN in AqILuvcwOVzsriXQkTFWDJCyKmSBRN:
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH={}
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH['mediatype']='video'
    AqILuvcwOVzsriXQkTFWDJCyKmSBxP =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['title']
    AqILuvcwOVzsriXQkTFWDJCyKmSBxE =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['id']
    AqILuvcwOVzsriXQkTFWDJCyKmSBxU =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['vtype']
    AqILuvcwOVzsriXQkTFWDJCyKmSBxj =AqILuvcwOVzsriXQkTFWDJCyKmSBhN['imgUrl']
    AqILuvcwOVzsriXQkTFWDJCyKmSBhH['duration'] =AqILuvcwOVzsriXQkTFWDJCyKmSBNg(AqILuvcwOVzsriXQkTFWDJCyKmSBhN['duration']/1000)
    AqILuvcwOVzsriXQkTFWDJCyKmSBhl={'vodTitle':AqILuvcwOVzsriXQkTFWDJCyKmSBxP,'vodId':AqILuvcwOVzsriXQkTFWDJCyKmSBxE,'vodType':AqILuvcwOVzsriXQkTFWDJCyKmSBxU,'thumbnail':AqILuvcwOVzsriXQkTFWDJCyKmSBxj,'info':AqILuvcwOVzsriXQkTFWDJCyKmSBhH}
    AqILuvcwOVzsriXQkTFWDJCyKmSBho.append(AqILuvcwOVzsriXQkTFWDJCyKmSBhl)
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBho
 def GetReplay_UrlId(AqILuvcwOVzsriXQkTFWDJCyKmSBoN,AqILuvcwOVzsriXQkTFWDJCyKmSBRj):
  AqILuvcwOVzsriXQkTFWDJCyKmSBRf=AqILuvcwOVzsriXQkTFWDJCyKmSBxd=''
  AqILuvcwOVzsriXQkTFWDJCyKmSBRp=''
  try:
   AqILuvcwOVzsriXQkTFWDJCyKmSBhR=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.API_DOMAIN+'/api/v2/vod/'+AqILuvcwOVzsriXQkTFWDJCyKmSBRj
   AqILuvcwOVzsriXQkTFWDJCyKmSBoY=AqILuvcwOVzsriXQkTFWDJCyKmSBoN.callRequestCookies('Get',AqILuvcwOVzsriXQkTFWDJCyKmSBhR,payload=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,params=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,headers=AqILuvcwOVzsriXQkTFWDJCyKmSBNh,cookies=AqILuvcwOVzsriXQkTFWDJCyKmSBNh)
   AqILuvcwOVzsriXQkTFWDJCyKmSBoP=json.loads(AqILuvcwOVzsriXQkTFWDJCyKmSBoY.text)
   AqILuvcwOVzsriXQkTFWDJCyKmSBRf =AqILuvcwOVzsriXQkTFWDJCyKmSBoP['clipId']
   AqILuvcwOVzsriXQkTFWDJCyKmSBxd=AqILuvcwOVzsriXQkTFWDJCyKmSBoP['videoId']
   AqILuvcwOVzsriXQkTFWDJCyKmSBRp=AqILuvcwOVzsriXQkTFWDJCyKmSBRf
   if AqILuvcwOVzsriXQkTFWDJCyKmSBoN.CheckSubEnd():AqILuvcwOVzsriXQkTFWDJCyKmSBRp=AqILuvcwOVzsriXQkTFWDJCyKmSBxd
  except AqILuvcwOVzsriXQkTFWDJCyKmSBNb as exception:
   AqILuvcwOVzsriXQkTFWDJCyKmSBNR(exception)
  return AqILuvcwOVzsriXQkTFWDJCyKmSBRp
# Created by pyminifier (https://github.com/liftoff/pyminifier)
