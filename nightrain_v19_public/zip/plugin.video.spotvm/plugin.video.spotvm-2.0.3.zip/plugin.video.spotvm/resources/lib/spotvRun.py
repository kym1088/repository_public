__author__="NightRain"
VDfJINXqYrFlyjkpohnCmMBtAHcgTW=object
VDfJINXqYrFlyjkpohnCmMBtAHcgTb=None
VDfJINXqYrFlyjkpohnCmMBtAHcgTa=False
VDfJINXqYrFlyjkpohnCmMBtAHcgTi=True
VDfJINXqYrFlyjkpohnCmMBtAHcgTU=int
VDfJINXqYrFlyjkpohnCmMBtAHcgTL=len
VDfJINXqYrFlyjkpohnCmMBtAHcgTw=str
VDfJINXqYrFlyjkpohnCmMBtAHcgTv=open
VDfJINXqYrFlyjkpohnCmMBtAHcgTK=Exception
VDfJINXqYrFlyjkpohnCmMBtAHcgTx=print
VDfJINXqYrFlyjkpohnCmMBtAHcgTd=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
VDfJINXqYrFlyjkpohnCmMBtAHcgQb=[{'title':'LIVE 채널','mode':'LIVE_GROUP'},{'title':'인기영상','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH'}]
VDfJINXqYrFlyjkpohnCmMBtAHcgQa ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
VDfJINXqYrFlyjkpohnCmMBtAHcgQT=xbmc.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class VDfJINXqYrFlyjkpohnCmMBtAHcgQW(VDfJINXqYrFlyjkpohnCmMBtAHcgTW):
 def __init__(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,VDfJINXqYrFlyjkpohnCmMBtAHcgQU,VDfJINXqYrFlyjkpohnCmMBtAHcgQL,VDfJINXqYrFlyjkpohnCmMBtAHcgQw):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_url =VDfJINXqYrFlyjkpohnCmMBtAHcgQU
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_handle=VDfJINXqYrFlyjkpohnCmMBtAHcgQL
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.main_params =VDfJINXqYrFlyjkpohnCmMBtAHcgQw
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj =AqILuvcwOVzsriXQkTFWDJCyKmSBoh() 
 def addon_noti(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,sting):
  try:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQK=xbmcgui.Dialog()
   VDfJINXqYrFlyjkpohnCmMBtAHcgQK.notification(__addonname__,sting)
  except:
   VDfJINXqYrFlyjkpohnCmMBtAHcgTb
 def addon_log(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,string,isDebug=VDfJINXqYrFlyjkpohnCmMBtAHcgTa):
  try:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQx=string.encode('utf-8','ignore')
  except:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQx='addonException: addon_log'
  if isDebug:VDfJINXqYrFlyjkpohnCmMBtAHcgQd=xbmc.LOGDEBUG
  else:VDfJINXqYrFlyjkpohnCmMBtAHcgQd=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,VDfJINXqYrFlyjkpohnCmMBtAHcgQx),level=VDfJINXqYrFlyjkpohnCmMBtAHcgQd)
 def get_keyboard_input(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,VDfJINXqYrFlyjkpohnCmMBtAHcgQz):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQe=VDfJINXqYrFlyjkpohnCmMBtAHcgTb
  kb=xbmc.Keyboard()
  kb.setHeading(VDfJINXqYrFlyjkpohnCmMBtAHcgQz)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   VDfJINXqYrFlyjkpohnCmMBtAHcgQe=kb.getText()
  return VDfJINXqYrFlyjkpohnCmMBtAHcgQe
 def get_settings_login_info(VDfJINXqYrFlyjkpohnCmMBtAHcgQi):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQP =__addon__.getSetting('id')
  VDfJINXqYrFlyjkpohnCmMBtAHcgQR =__addon__.getSetting('pw')
  return(VDfJINXqYrFlyjkpohnCmMBtAHcgQP,VDfJINXqYrFlyjkpohnCmMBtAHcgQR)
 def set_winCredential(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,credential):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS=xbmcgui.Window(10000)
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_LOGINTIME',VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(VDfJINXqYrFlyjkpohnCmMBtAHcgQi):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS=xbmcgui.Window(10000)
  VDfJINXqYrFlyjkpohnCmMBtAHcgQE={'spotv_sessionid':VDfJINXqYrFlyjkpohnCmMBtAHcgQS.getProperty('SPOTV_M_SESSIONID'),'spotv_session':VDfJINXqYrFlyjkpohnCmMBtAHcgQS.getProperty('SPOTV_M_SESSION'),'spotv_accountId':VDfJINXqYrFlyjkpohnCmMBtAHcgQS.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':VDfJINXqYrFlyjkpohnCmMBtAHcgQS.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':VDfJINXqYrFlyjkpohnCmMBtAHcgQS.getProperty('SPOTV_M_SUBEND')}
  return VDfJINXqYrFlyjkpohnCmMBtAHcgQE
 def add_dir(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,label,sublabel='',img='',infoLabels=VDfJINXqYrFlyjkpohnCmMBtAHcgTb,isFolder=VDfJINXqYrFlyjkpohnCmMBtAHcgTi,params=''):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQG='%s?%s'%(VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_url,urllib.parse.urlencode(params))
  if sublabel:VDfJINXqYrFlyjkpohnCmMBtAHcgQz='%s < %s >'%(label,sublabel)
  else: VDfJINXqYrFlyjkpohnCmMBtAHcgQz=label
  if not img:img='DefaultFolder.png'
  VDfJINXqYrFlyjkpohnCmMBtAHcgQu=xbmcgui.ListItem(VDfJINXqYrFlyjkpohnCmMBtAHcgQz)
  VDfJINXqYrFlyjkpohnCmMBtAHcgQu.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:VDfJINXqYrFlyjkpohnCmMBtAHcgQu.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:VDfJINXqYrFlyjkpohnCmMBtAHcgQu.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_handle,VDfJINXqYrFlyjkpohnCmMBtAHcgQG,VDfJINXqYrFlyjkpohnCmMBtAHcgQu,isFolder)
 def get_selQuality(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,etype):
  try:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQO='selected_quality'
   VDfJINXqYrFlyjkpohnCmMBtAHcgQs=[1080,720,540]
   VDfJINXqYrFlyjkpohnCmMBtAHcgWQ=VDfJINXqYrFlyjkpohnCmMBtAHcgTU(__addon__.getSetting(VDfJINXqYrFlyjkpohnCmMBtAHcgQO))
   return VDfJINXqYrFlyjkpohnCmMBtAHcgQs[VDfJINXqYrFlyjkpohnCmMBtAHcgWQ]
  except:
   VDfJINXqYrFlyjkpohnCmMBtAHcgTb
  return 1080 
 def dp_Main_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi):
  for VDfJINXqYrFlyjkpohnCmMBtAHcgWb in VDfJINXqYrFlyjkpohnCmMBtAHcgQb:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQz=VDfJINXqYrFlyjkpohnCmMBtAHcgWb.get('title')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa={'mode':VDfJINXqYrFlyjkpohnCmMBtAHcgWb.get('mode')}
   if VDfJINXqYrFlyjkpohnCmMBtAHcgWb.get('mode')=='XXX':
    VDfJINXqYrFlyjkpohnCmMBtAHcgWT=VDfJINXqYrFlyjkpohnCmMBtAHcgTa
   else:
    VDfJINXqYrFlyjkpohnCmMBtAHcgWT=VDfJINXqYrFlyjkpohnCmMBtAHcgTi
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.add_dir(VDfJINXqYrFlyjkpohnCmMBtAHcgQz,sublabel='',img='',infoLabels=VDfJINXqYrFlyjkpohnCmMBtAHcgTb,isFolder=VDfJINXqYrFlyjkpohnCmMBtAHcgWT,params=VDfJINXqYrFlyjkpohnCmMBtAHcgWa)
  if VDfJINXqYrFlyjkpohnCmMBtAHcgTL(VDfJINXqYrFlyjkpohnCmMBtAHcgQb)>0:xbmcplugin.endOfDirectory(VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_handle)
 def dp_MainLeague_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,args):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.SaveCredential(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.get_winCredential())
  VDfJINXqYrFlyjkpohnCmMBtAHcgWU=VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.GetTitleGroupList()
  for VDfJINXqYrFlyjkpohnCmMBtAHcgWL in VDfJINXqYrFlyjkpohnCmMBtAHcgWU:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQz =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('title')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWw =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('logo')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWv =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('reagueId')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWK =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('subGame')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx=VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('info')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx['plot']='%s\n\n%s'%(VDfJINXqYrFlyjkpohnCmMBtAHcgQz,VDfJINXqYrFlyjkpohnCmMBtAHcgWK)
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa={'mode':'LEAGUE_GROUP','reagueId':VDfJINXqYrFlyjkpohnCmMBtAHcgWv}
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.add_dir(VDfJINXqYrFlyjkpohnCmMBtAHcgQz,sublabel=VDfJINXqYrFlyjkpohnCmMBtAHcgTb,img=VDfJINXqYrFlyjkpohnCmMBtAHcgWw,infoLabels=VDfJINXqYrFlyjkpohnCmMBtAHcgWx,isFolder=VDfJINXqYrFlyjkpohnCmMBtAHcgTi,params=VDfJINXqYrFlyjkpohnCmMBtAHcgWa)
  if VDfJINXqYrFlyjkpohnCmMBtAHcgTL(VDfJINXqYrFlyjkpohnCmMBtAHcgWU)>0:xbmcplugin.endOfDirectory(VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_handle,cacheToDisc=VDfJINXqYrFlyjkpohnCmMBtAHcgTa)
 def dp_PopVod_GroupList(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,args):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.SaveCredential(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.get_winCredential())
  VDfJINXqYrFlyjkpohnCmMBtAHcgWU=VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.GetPopularGroupList()
  for VDfJINXqYrFlyjkpohnCmMBtAHcgWL in VDfJINXqYrFlyjkpohnCmMBtAHcgWU:
   VDfJINXqYrFlyjkpohnCmMBtAHcgWd =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('vodTitle')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWe =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('vodId')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWP =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('vodType')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWw=VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('thumbnail')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx=VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('info')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx['plot']=VDfJINXqYrFlyjkpohnCmMBtAHcgWd
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa={'mode':'POP_VOD','mediacode':VDfJINXqYrFlyjkpohnCmMBtAHcgWe,'mediatype':'vod'}
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.add_dir(VDfJINXqYrFlyjkpohnCmMBtAHcgWd,sublabel=VDfJINXqYrFlyjkpohnCmMBtAHcgWP,img=VDfJINXqYrFlyjkpohnCmMBtAHcgWw,infoLabels=VDfJINXqYrFlyjkpohnCmMBtAHcgWx,isFolder=VDfJINXqYrFlyjkpohnCmMBtAHcgTa,params=VDfJINXqYrFlyjkpohnCmMBtAHcgWa)
  if VDfJINXqYrFlyjkpohnCmMBtAHcgTL(VDfJINXqYrFlyjkpohnCmMBtAHcgWU)>0:xbmcplugin.endOfDirectory(VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_handle,cacheToDisc=VDfJINXqYrFlyjkpohnCmMBtAHcgTa)
 def dp_Season_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,args):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.SaveCredential(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.get_winCredential())
  VDfJINXqYrFlyjkpohnCmMBtAHcgWv=args.get('reagueId')
  VDfJINXqYrFlyjkpohnCmMBtAHcgWU=VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.GetSeasonList(VDfJINXqYrFlyjkpohnCmMBtAHcgWv)
  for VDfJINXqYrFlyjkpohnCmMBtAHcgWL in VDfJINXqYrFlyjkpohnCmMBtAHcgWU:
   VDfJINXqYrFlyjkpohnCmMBtAHcgWR =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('reagueName')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWS =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('gameTypeId')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWE =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('seasonName')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWG =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('seasonId')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx=VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('info')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx['plot']='%s - %s'%(VDfJINXqYrFlyjkpohnCmMBtAHcgWR,VDfJINXqYrFlyjkpohnCmMBtAHcgWE)
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa={'mode':'SEASON_GROUP','reagueId':VDfJINXqYrFlyjkpohnCmMBtAHcgWv,'seasonId':VDfJINXqYrFlyjkpohnCmMBtAHcgWG,'gameTypeId':VDfJINXqYrFlyjkpohnCmMBtAHcgWS,'page':'1'}
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.add_dir(VDfJINXqYrFlyjkpohnCmMBtAHcgWR,sublabel=VDfJINXqYrFlyjkpohnCmMBtAHcgWE,img='',infoLabels=VDfJINXqYrFlyjkpohnCmMBtAHcgWx,isFolder=VDfJINXqYrFlyjkpohnCmMBtAHcgTi,params=VDfJINXqYrFlyjkpohnCmMBtAHcgWa)
  if VDfJINXqYrFlyjkpohnCmMBtAHcgTL(VDfJINXqYrFlyjkpohnCmMBtAHcgWU)>0:xbmcplugin.endOfDirectory(VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_handle,cacheToDisc=VDfJINXqYrFlyjkpohnCmMBtAHcgTi)
 def dp_Game_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,args):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.SaveCredential(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.get_winCredential())
  VDfJINXqYrFlyjkpohnCmMBtAHcgWS=args.get('gameTypeId')
  VDfJINXqYrFlyjkpohnCmMBtAHcgWv =args.get('reagueId')
  VDfJINXqYrFlyjkpohnCmMBtAHcgWG =args.get('seasonId')
  VDfJINXqYrFlyjkpohnCmMBtAHcgWz =VDfJINXqYrFlyjkpohnCmMBtAHcgTU(args.get('page'))
  VDfJINXqYrFlyjkpohnCmMBtAHcgWU,VDfJINXqYrFlyjkpohnCmMBtAHcgWu=VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.GetGameList(VDfJINXqYrFlyjkpohnCmMBtAHcgWS,VDfJINXqYrFlyjkpohnCmMBtAHcgWv,VDfJINXqYrFlyjkpohnCmMBtAHcgWG,VDfJINXqYrFlyjkpohnCmMBtAHcgWz)
  for VDfJINXqYrFlyjkpohnCmMBtAHcgWL in VDfJINXqYrFlyjkpohnCmMBtAHcgWU:
   VDfJINXqYrFlyjkpohnCmMBtAHcgWO =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('gameTitle')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWs =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('beginDate')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWw =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('thumbnail')
   VDfJINXqYrFlyjkpohnCmMBtAHcgbQ =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('gameId')
   VDfJINXqYrFlyjkpohnCmMBtAHcgbW =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('totVodCnt')
   VDfJINXqYrFlyjkpohnCmMBtAHcgba =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('leaguenm')
   VDfJINXqYrFlyjkpohnCmMBtAHcgbT =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('seasonnm')
   VDfJINXqYrFlyjkpohnCmMBtAHcgbi =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('roundnm')
   VDfJINXqYrFlyjkpohnCmMBtAHcgbU ='%s < %s >'%(VDfJINXqYrFlyjkpohnCmMBtAHcgWO,VDfJINXqYrFlyjkpohnCmMBtAHcgWs)
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx=VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('info')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa={'mode':'GAME_VOD_GROUP' if VDfJINXqYrFlyjkpohnCmMBtAHcgbW!=0 else 'XXX','saveTitle':VDfJINXqYrFlyjkpohnCmMBtAHcgbU,'saveImg':VDfJINXqYrFlyjkpohnCmMBtAHcgWw,'saveInfo':VDfJINXqYrFlyjkpohnCmMBtAHcgWx['plot'],'gameid':VDfJINXqYrFlyjkpohnCmMBtAHcgbQ}
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.add_dir(VDfJINXqYrFlyjkpohnCmMBtAHcgWO,sublabel=VDfJINXqYrFlyjkpohnCmMBtAHcgWs,img=VDfJINXqYrFlyjkpohnCmMBtAHcgWw,infoLabels=VDfJINXqYrFlyjkpohnCmMBtAHcgWx,isFolder=VDfJINXqYrFlyjkpohnCmMBtAHcgTi,params=VDfJINXqYrFlyjkpohnCmMBtAHcgWa)
  if VDfJINXqYrFlyjkpohnCmMBtAHcgWu:
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa['mode'] ='SEASON_GROUP' 
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa['reagueId'] =VDfJINXqYrFlyjkpohnCmMBtAHcgWv
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa['seasonId'] =VDfJINXqYrFlyjkpohnCmMBtAHcgWG
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa['gameTypeId']=VDfJINXqYrFlyjkpohnCmMBtAHcgWS
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa['page'] =VDfJINXqYrFlyjkpohnCmMBtAHcgTw(VDfJINXqYrFlyjkpohnCmMBtAHcgWz+1)
   VDfJINXqYrFlyjkpohnCmMBtAHcgQz='[B]%s >>[/B]'%'다음 페이지'
   VDfJINXqYrFlyjkpohnCmMBtAHcgbL=VDfJINXqYrFlyjkpohnCmMBtAHcgTw(VDfJINXqYrFlyjkpohnCmMBtAHcgWz+1)
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.add_dir(VDfJINXqYrFlyjkpohnCmMBtAHcgQz,sublabel=VDfJINXqYrFlyjkpohnCmMBtAHcgbL,img='',infoLabels=VDfJINXqYrFlyjkpohnCmMBtAHcgTb,isFolder=VDfJINXqYrFlyjkpohnCmMBtAHcgTi,params=VDfJINXqYrFlyjkpohnCmMBtAHcgWa)
  if VDfJINXqYrFlyjkpohnCmMBtAHcgTL(VDfJINXqYrFlyjkpohnCmMBtAHcgWU)>0:xbmcplugin.endOfDirectory(VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_handle,cacheToDisc=VDfJINXqYrFlyjkpohnCmMBtAHcgTa)
 def dp_GameVod_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,args):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.SaveCredential(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.get_winCredential())
  VDfJINXqYrFlyjkpohnCmMBtAHcgbw =args.get('gameid')
  VDfJINXqYrFlyjkpohnCmMBtAHcgbU=args.get('saveTitle')
  VDfJINXqYrFlyjkpohnCmMBtAHcgbv =args.get('saveImg')
  VDfJINXqYrFlyjkpohnCmMBtAHcgbK =args.get('saveInfo')
  VDfJINXqYrFlyjkpohnCmMBtAHcgWU=VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.GetGameVodList(VDfJINXqYrFlyjkpohnCmMBtAHcgbw)
  for VDfJINXqYrFlyjkpohnCmMBtAHcgWL in VDfJINXqYrFlyjkpohnCmMBtAHcgWU:
   VDfJINXqYrFlyjkpohnCmMBtAHcgWd =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('vodTitle')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWe =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('vodId')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWP =VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('vodType')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWw=VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('thumbnail')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx=VDfJINXqYrFlyjkpohnCmMBtAHcgWL.get('info')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx['plot']='%s \n\n %s'%(VDfJINXqYrFlyjkpohnCmMBtAHcgWd,VDfJINXqYrFlyjkpohnCmMBtAHcgbK)
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa={'mode':'GAME_VOD','saveTitle':VDfJINXqYrFlyjkpohnCmMBtAHcgbU,'saveImg':VDfJINXqYrFlyjkpohnCmMBtAHcgbv,'saveId':VDfJINXqYrFlyjkpohnCmMBtAHcgbw,'saveInfo':VDfJINXqYrFlyjkpohnCmMBtAHcgbK,'mediacode':VDfJINXqYrFlyjkpohnCmMBtAHcgWe,'mediatype':'vod'}
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.add_dir(VDfJINXqYrFlyjkpohnCmMBtAHcgWd,sublabel=VDfJINXqYrFlyjkpohnCmMBtAHcgWP,img=VDfJINXqYrFlyjkpohnCmMBtAHcgWw,infoLabels=VDfJINXqYrFlyjkpohnCmMBtAHcgWx,isFolder=VDfJINXqYrFlyjkpohnCmMBtAHcgTa,params=VDfJINXqYrFlyjkpohnCmMBtAHcgWa)
  if VDfJINXqYrFlyjkpohnCmMBtAHcgTL(VDfJINXqYrFlyjkpohnCmMBtAHcgWU)>0:xbmcplugin.endOfDirectory(VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_handle,cacheToDisc=VDfJINXqYrFlyjkpohnCmMBtAHcgTa)
 def login_main(VDfJINXqYrFlyjkpohnCmMBtAHcgQi):
  (VDfJINXqYrFlyjkpohnCmMBtAHcgbx,VDfJINXqYrFlyjkpohnCmMBtAHcgbd)=VDfJINXqYrFlyjkpohnCmMBtAHcgQi.get_settings_login_info()
  if not(VDfJINXqYrFlyjkpohnCmMBtAHcgbx and VDfJINXqYrFlyjkpohnCmMBtAHcgbd):
   VDfJINXqYrFlyjkpohnCmMBtAHcgQK=xbmcgui.Dialog()
   VDfJINXqYrFlyjkpohnCmMBtAHcgbe=VDfJINXqYrFlyjkpohnCmMBtAHcgQK.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if VDfJINXqYrFlyjkpohnCmMBtAHcgbe==VDfJINXqYrFlyjkpohnCmMBtAHcgTi:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if VDfJINXqYrFlyjkpohnCmMBtAHcgQi.cookiefile_check():return
  VDfJINXqYrFlyjkpohnCmMBtAHcgbP =VDfJINXqYrFlyjkpohnCmMBtAHcgTU(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  VDfJINXqYrFlyjkpohnCmMBtAHcgbR=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if VDfJINXqYrFlyjkpohnCmMBtAHcgbR==VDfJINXqYrFlyjkpohnCmMBtAHcgTb or VDfJINXqYrFlyjkpohnCmMBtAHcgbR=='':VDfJINXqYrFlyjkpohnCmMBtAHcgbR=VDfJINXqYrFlyjkpohnCmMBtAHcgTU('19000101')
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   VDfJINXqYrFlyjkpohnCmMBtAHcgbS=0
   while VDfJINXqYrFlyjkpohnCmMBtAHcgTi:
    VDfJINXqYrFlyjkpohnCmMBtAHcgbS+=1
    time.sleep(0.05)
    if VDfJINXqYrFlyjkpohnCmMBtAHcgbR>=VDfJINXqYrFlyjkpohnCmMBtAHcgbP:return
    if VDfJINXqYrFlyjkpohnCmMBtAHcgbS>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if VDfJINXqYrFlyjkpohnCmMBtAHcgbR>=VDfJINXqYrFlyjkpohnCmMBtAHcgbP:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.GetCredential(VDfJINXqYrFlyjkpohnCmMBtAHcgbx,VDfJINXqYrFlyjkpohnCmMBtAHcgbd):
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.set_winCredential(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.LoadCredential())
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,args):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.SaveCredential(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.get_winCredential())
  VDfJINXqYrFlyjkpohnCmMBtAHcgbE=VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.GetLiveChannelList()
  for VDfJINXqYrFlyjkpohnCmMBtAHcgbG in VDfJINXqYrFlyjkpohnCmMBtAHcgbE:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQz =VDfJINXqYrFlyjkpohnCmMBtAHcgbG.get('name')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWi =VDfJINXqYrFlyjkpohnCmMBtAHcgbG.get('programName')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWw =VDfJINXqYrFlyjkpohnCmMBtAHcgbG.get('logo')
   VDfJINXqYrFlyjkpohnCmMBtAHcgbz=VDfJINXqYrFlyjkpohnCmMBtAHcgbG.get('channelepg')
   VDfJINXqYrFlyjkpohnCmMBtAHcgbu =VDfJINXqYrFlyjkpohnCmMBtAHcgbG.get('free')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx=VDfJINXqYrFlyjkpohnCmMBtAHcgbG.get('info')
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx['plot']='%s'%(VDfJINXqYrFlyjkpohnCmMBtAHcgbz)
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa={'mode':'LIVE','mediaid':VDfJINXqYrFlyjkpohnCmMBtAHcgbG.get('id'),'mediacode':VDfJINXqYrFlyjkpohnCmMBtAHcgbG.get('videoId'),'free':VDfJINXqYrFlyjkpohnCmMBtAHcgbu,'mediatype':'live'}
   if VDfJINXqYrFlyjkpohnCmMBtAHcgbu:VDfJINXqYrFlyjkpohnCmMBtAHcgQz+=' [free]'
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.add_dir(VDfJINXqYrFlyjkpohnCmMBtAHcgQz,sublabel=VDfJINXqYrFlyjkpohnCmMBtAHcgWi,img=VDfJINXqYrFlyjkpohnCmMBtAHcgWw,infoLabels=VDfJINXqYrFlyjkpohnCmMBtAHcgWx,isFolder=VDfJINXqYrFlyjkpohnCmMBtAHcgTa,params=VDfJINXqYrFlyjkpohnCmMBtAHcgWa)
  if VDfJINXqYrFlyjkpohnCmMBtAHcgTL(VDfJINXqYrFlyjkpohnCmMBtAHcgbE)>0:xbmcplugin.endOfDirectory(VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_handle,cacheToDisc=VDfJINXqYrFlyjkpohnCmMBtAHcgTa)
 def play_VIDEO(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,args):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.SaveCredential(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.get_winCredential())
  if args.get('free')=='False':
   if VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.CheckSubEnd()==VDfJINXqYrFlyjkpohnCmMBtAHcgTa:
    VDfJINXqYrFlyjkpohnCmMBtAHcgQi.addon_noti(__language__(30908).encode('utf8'))
    return
  VDfJINXqYrFlyjkpohnCmMBtAHcgbO =args.get('mode')
  VDfJINXqYrFlyjkpohnCmMBtAHcgbs =args.get('mediacode')
  VDfJINXqYrFlyjkpohnCmMBtAHcgaQ =args.get('mediatype')
  if VDfJINXqYrFlyjkpohnCmMBtAHcgbs=='' or VDfJINXqYrFlyjkpohnCmMBtAHcgbs==VDfJINXqYrFlyjkpohnCmMBtAHcgTb:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.addon_noti(__language__(30907).encode('utf8'))
   return
  VDfJINXqYrFlyjkpohnCmMBtAHcgaW=VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.GetBroadURL(VDfJINXqYrFlyjkpohnCmMBtAHcgbs,VDfJINXqYrFlyjkpohnCmMBtAHcgaQ)
  if VDfJINXqYrFlyjkpohnCmMBtAHcgaW=='':
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.addon_noti(__language__(30908).encode('utf8'))
   return
  VDfJINXqYrFlyjkpohnCmMBtAHcgab=VDfJINXqYrFlyjkpohnCmMBtAHcgaW
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.addon_log(VDfJINXqYrFlyjkpohnCmMBtAHcgab,VDfJINXqYrFlyjkpohnCmMBtAHcgTa)
  VDfJINXqYrFlyjkpohnCmMBtAHcgaT=xbmcgui.ListItem(path=VDfJINXqYrFlyjkpohnCmMBtAHcgab)
  xbmcplugin.setResolvedUrl(VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_handle,VDfJINXqYrFlyjkpohnCmMBtAHcgTi,VDfJINXqYrFlyjkpohnCmMBtAHcgaT)
  try:
   if VDfJINXqYrFlyjkpohnCmMBtAHcgaQ=='vod' and VDfJINXqYrFlyjkpohnCmMBtAHcgbO!='POP_VOD':
    VDfJINXqYrFlyjkpohnCmMBtAHcgWa={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    VDfJINXqYrFlyjkpohnCmMBtAHcgQi.Save_Watched_List(VDfJINXqYrFlyjkpohnCmMBtAHcgaQ,VDfJINXqYrFlyjkpohnCmMBtAHcgWa)
  except:
   VDfJINXqYrFlyjkpohnCmMBtAHcgTb
 def logout(VDfJINXqYrFlyjkpohnCmMBtAHcgQi):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQK=xbmcgui.Dialog()
  VDfJINXqYrFlyjkpohnCmMBtAHcgbe=VDfJINXqYrFlyjkpohnCmMBtAHcgQK.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if VDfJINXqYrFlyjkpohnCmMBtAHcgbe==VDfJINXqYrFlyjkpohnCmMBtAHcgTa:sys.exit()
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.wininfo_clear()
  if os.path.isfile(VDfJINXqYrFlyjkpohnCmMBtAHcgQT):os.remove(VDfJINXqYrFlyjkpohnCmMBtAHcgQT)
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(VDfJINXqYrFlyjkpohnCmMBtAHcgQi):
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS=xbmcgui.Window(10000)
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_SESSIONID','')
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_SESSION','')
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_ACCOUNTID','')
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_POLICYKEY','')
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_SUBEND','')
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(VDfJINXqYrFlyjkpohnCmMBtAHcgQi):
  VDfJINXqYrFlyjkpohnCmMBtAHcgai =VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.Get_Now_Datetime()
  VDfJINXqYrFlyjkpohnCmMBtAHcgaU=VDfJINXqYrFlyjkpohnCmMBtAHcgai+datetime.timedelta(days=VDfJINXqYrFlyjkpohnCmMBtAHcgTU(__addon__.getSetting('cache_ttl')))
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS=xbmcgui.Window(10000)
  VDfJINXqYrFlyjkpohnCmMBtAHcgaL={'spotv_sessionid':VDfJINXqYrFlyjkpohnCmMBtAHcgQS.getProperty('SPOTV_M_SESSIONID'),'spotv_session':VDfJINXqYrFlyjkpohnCmMBtAHcgQS.getProperty('SPOTV_M_SESSION'),'spotv_accountId':VDfJINXqYrFlyjkpohnCmMBtAHcgQS.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(VDfJINXqYrFlyjkpohnCmMBtAHcgQS.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.SPOTV_PMCODE+VDfJINXqYrFlyjkpohnCmMBtAHcgQS.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':VDfJINXqYrFlyjkpohnCmMBtAHcgaU.strftime('%Y-%m-%d')}
  try: 
   fp=VDfJINXqYrFlyjkpohnCmMBtAHcgTv(VDfJINXqYrFlyjkpohnCmMBtAHcgQT,'w',-1,'utf-8')
   json.dump(VDfJINXqYrFlyjkpohnCmMBtAHcgaL,fp)
   fp.close()
  except VDfJINXqYrFlyjkpohnCmMBtAHcgTK as exception:
   VDfJINXqYrFlyjkpohnCmMBtAHcgTx(exception)
 def cookiefile_check(VDfJINXqYrFlyjkpohnCmMBtAHcgQi):
  VDfJINXqYrFlyjkpohnCmMBtAHcgaL={}
  try: 
   fp=VDfJINXqYrFlyjkpohnCmMBtAHcgTv(VDfJINXqYrFlyjkpohnCmMBtAHcgQT,'r',-1,'utf-8')
   VDfJINXqYrFlyjkpohnCmMBtAHcgaL= json.load(fp)
   fp.close()
  except VDfJINXqYrFlyjkpohnCmMBtAHcgTK as exception:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.wininfo_clear()
   return VDfJINXqYrFlyjkpohnCmMBtAHcgTa
  VDfJINXqYrFlyjkpohnCmMBtAHcgbx =__addon__.getSetting('id')
  VDfJINXqYrFlyjkpohnCmMBtAHcgbd =__addon__.getSetting('pw')
  VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_id'] =base64.standard_b64decode(VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_id']).decode('utf-8')
  VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_pw'] =base64.standard_b64decode(VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_pw']).decode('utf-8')
  VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_policyKey']=base64.standard_b64decode(VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_policyKey']).decode('utf-8')
  VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_subend']=base64.standard_b64decode(VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_subend']).decode('utf-8')[VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.SPOTV_PMSIZE:]
  if VDfJINXqYrFlyjkpohnCmMBtAHcgbx!=VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_id']or VDfJINXqYrFlyjkpohnCmMBtAHcgbd!=VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_pw']:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.wininfo_clear()
   return VDfJINXqYrFlyjkpohnCmMBtAHcgTa
  VDfJINXqYrFlyjkpohnCmMBtAHcgbP =VDfJINXqYrFlyjkpohnCmMBtAHcgTU(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  VDfJINXqYrFlyjkpohnCmMBtAHcgaw=VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_limitdate']
  VDfJINXqYrFlyjkpohnCmMBtAHcgbR =VDfJINXqYrFlyjkpohnCmMBtAHcgTU(re.sub('-','',VDfJINXqYrFlyjkpohnCmMBtAHcgaw))
  if VDfJINXqYrFlyjkpohnCmMBtAHcgbR<VDfJINXqYrFlyjkpohnCmMBtAHcgbP:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.wininfo_clear()
   return VDfJINXqYrFlyjkpohnCmMBtAHcgTa
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS=xbmcgui.Window(10000)
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_SESSIONID',VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_sessionid'])
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_SESSION',VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_session'])
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_ACCOUNTID',VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_accountId'])
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_POLICYKEY',VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_policyKey'])
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_SUBEND',VDfJINXqYrFlyjkpohnCmMBtAHcgaL['spotv_subend'])
  VDfJINXqYrFlyjkpohnCmMBtAHcgQS.setProperty('SPOTV_M_LOGINTIME',VDfJINXqYrFlyjkpohnCmMBtAHcgaw)
  return VDfJINXqYrFlyjkpohnCmMBtAHcgTi
 def dp_WatchList_Delete(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,args):
  VDfJINXqYrFlyjkpohnCmMBtAHcgaQ=args.get('mediatype')
  VDfJINXqYrFlyjkpohnCmMBtAHcgQK=xbmcgui.Dialog()
  VDfJINXqYrFlyjkpohnCmMBtAHcgbe=VDfJINXqYrFlyjkpohnCmMBtAHcgQK.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if VDfJINXqYrFlyjkpohnCmMBtAHcgbe==VDfJINXqYrFlyjkpohnCmMBtAHcgTa:sys.exit()
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.Delete_Watched_List(VDfJINXqYrFlyjkpohnCmMBtAHcgaQ)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,VDfJINXqYrFlyjkpohnCmMBtAHcgaQ):
  try:
   VDfJINXqYrFlyjkpohnCmMBtAHcgav=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VDfJINXqYrFlyjkpohnCmMBtAHcgaQ))
   fp=VDfJINXqYrFlyjkpohnCmMBtAHcgTv(VDfJINXqYrFlyjkpohnCmMBtAHcgav,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   VDfJINXqYrFlyjkpohnCmMBtAHcgTb
 def Load_Watched_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,VDfJINXqYrFlyjkpohnCmMBtAHcgaQ):
  try:
   VDfJINXqYrFlyjkpohnCmMBtAHcgav=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%VDfJINXqYrFlyjkpohnCmMBtAHcgaQ))
   fp=VDfJINXqYrFlyjkpohnCmMBtAHcgTv(VDfJINXqYrFlyjkpohnCmMBtAHcgav,'r',-1,'utf-8')
   VDfJINXqYrFlyjkpohnCmMBtAHcgaK=fp.readlines()
   fp.close()
  except:
   VDfJINXqYrFlyjkpohnCmMBtAHcgaK=[]
  return VDfJINXqYrFlyjkpohnCmMBtAHcgaK
 def Save_Watched_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,stype,VDfJINXqYrFlyjkpohnCmMBtAHcgQw):
  try:
   VDfJINXqYrFlyjkpohnCmMBtAHcgav=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   VDfJINXqYrFlyjkpohnCmMBtAHcgax=VDfJINXqYrFlyjkpohnCmMBtAHcgQi.Load_Watched_List(stype) 
   fp=VDfJINXqYrFlyjkpohnCmMBtAHcgTv(VDfJINXqYrFlyjkpohnCmMBtAHcgav,'w',-1,'utf-8')
   VDfJINXqYrFlyjkpohnCmMBtAHcgad=urllib.parse.urlencode(VDfJINXqYrFlyjkpohnCmMBtAHcgQw)
   VDfJINXqYrFlyjkpohnCmMBtAHcgad=VDfJINXqYrFlyjkpohnCmMBtAHcgad+'\n'
   fp.write(VDfJINXqYrFlyjkpohnCmMBtAHcgad)
   VDfJINXqYrFlyjkpohnCmMBtAHcgae=0
   for VDfJINXqYrFlyjkpohnCmMBtAHcgaP in VDfJINXqYrFlyjkpohnCmMBtAHcgax:
    VDfJINXqYrFlyjkpohnCmMBtAHcgaR=VDfJINXqYrFlyjkpohnCmMBtAHcgTd(urllib.parse.parse_qsl(VDfJINXqYrFlyjkpohnCmMBtAHcgaP))
    VDfJINXqYrFlyjkpohnCmMBtAHcgaS=VDfJINXqYrFlyjkpohnCmMBtAHcgQw.get('code')
    VDfJINXqYrFlyjkpohnCmMBtAHcgaE=VDfJINXqYrFlyjkpohnCmMBtAHcgaR.get('code')
    if VDfJINXqYrFlyjkpohnCmMBtAHcgaS!=VDfJINXqYrFlyjkpohnCmMBtAHcgaE:
     fp.write(VDfJINXqYrFlyjkpohnCmMBtAHcgaP)
     VDfJINXqYrFlyjkpohnCmMBtAHcgae+=1
     if VDfJINXqYrFlyjkpohnCmMBtAHcgae>=50:break
   fp.close()
  except:
   VDfJINXqYrFlyjkpohnCmMBtAHcgTb
 def dp_Watch_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi,args):
  VDfJINXqYrFlyjkpohnCmMBtAHcgaQ ='vod'
  if VDfJINXqYrFlyjkpohnCmMBtAHcgaQ=='vod':
   VDfJINXqYrFlyjkpohnCmMBtAHcgaG=VDfJINXqYrFlyjkpohnCmMBtAHcgQi.Load_Watched_List(VDfJINXqYrFlyjkpohnCmMBtAHcgaQ)
   for VDfJINXqYrFlyjkpohnCmMBtAHcgaz in VDfJINXqYrFlyjkpohnCmMBtAHcgaG:
    VDfJINXqYrFlyjkpohnCmMBtAHcgau=VDfJINXqYrFlyjkpohnCmMBtAHcgTd(urllib.parse.parse_qsl(VDfJINXqYrFlyjkpohnCmMBtAHcgaz))
    VDfJINXqYrFlyjkpohnCmMBtAHcgQz =VDfJINXqYrFlyjkpohnCmMBtAHcgau.get('title')
    VDfJINXqYrFlyjkpohnCmMBtAHcgWw=VDfJINXqYrFlyjkpohnCmMBtAHcgau.get('img')
    VDfJINXqYrFlyjkpohnCmMBtAHcgbs=VDfJINXqYrFlyjkpohnCmMBtAHcgau.get('code')
    VDfJINXqYrFlyjkpohnCmMBtAHcgaO =VDfJINXqYrFlyjkpohnCmMBtAHcgau.get('info')
    VDfJINXqYrFlyjkpohnCmMBtAHcgWx={}
    VDfJINXqYrFlyjkpohnCmMBtAHcgWx['plot']=VDfJINXqYrFlyjkpohnCmMBtAHcgaO
    VDfJINXqYrFlyjkpohnCmMBtAHcgWa={'mode':'GAME_VOD_GROUP','gameid':VDfJINXqYrFlyjkpohnCmMBtAHcgbs,'saveTitle':VDfJINXqYrFlyjkpohnCmMBtAHcgQz,'saveImg':VDfJINXqYrFlyjkpohnCmMBtAHcgWw,'saveInfo':VDfJINXqYrFlyjkpohnCmMBtAHcgaO,'mediatype':VDfJINXqYrFlyjkpohnCmMBtAHcgaQ}
    VDfJINXqYrFlyjkpohnCmMBtAHcgQi.add_dir(VDfJINXqYrFlyjkpohnCmMBtAHcgQz,sublabel='',img=VDfJINXqYrFlyjkpohnCmMBtAHcgWw,infoLabels=VDfJINXqYrFlyjkpohnCmMBtAHcgWx,isFolder=VDfJINXqYrFlyjkpohnCmMBtAHcgTi,params=VDfJINXqYrFlyjkpohnCmMBtAHcgWa)
   VDfJINXqYrFlyjkpohnCmMBtAHcgWx={'plot':'시청목록을 삭제합니다.'}
   VDfJINXqYrFlyjkpohnCmMBtAHcgQz='*** 시청목록 삭제 ***'
   VDfJINXqYrFlyjkpohnCmMBtAHcgWa={'mode':'MYVIEW_REMOVE','mediatype':VDfJINXqYrFlyjkpohnCmMBtAHcgaQ}
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.add_dir(VDfJINXqYrFlyjkpohnCmMBtAHcgQz,sublabel='',img='',infoLabels=VDfJINXqYrFlyjkpohnCmMBtAHcgWx,isFolder=VDfJINXqYrFlyjkpohnCmMBtAHcgTa,params=VDfJINXqYrFlyjkpohnCmMBtAHcgWa)
   xbmcplugin.endOfDirectory(VDfJINXqYrFlyjkpohnCmMBtAHcgQi._addon_handle,cacheToDisc=VDfJINXqYrFlyjkpohnCmMBtAHcgTa)
 def spotv_main(VDfJINXqYrFlyjkpohnCmMBtAHcgQi):
  VDfJINXqYrFlyjkpohnCmMBtAHcgTQ=VDfJINXqYrFlyjkpohnCmMBtAHcgQi.main_params.get('mode',VDfJINXqYrFlyjkpohnCmMBtAHcgTb)
  if VDfJINXqYrFlyjkpohnCmMBtAHcgTQ=='LOGOUT':
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.logout()
   return
  VDfJINXqYrFlyjkpohnCmMBtAHcgQi.login_main()
  if VDfJINXqYrFlyjkpohnCmMBtAHcgTQ is VDfJINXqYrFlyjkpohnCmMBtAHcgTb:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.dp_Main_List()
  elif VDfJINXqYrFlyjkpohnCmMBtAHcgTQ=='LIVE_GROUP':
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.dp_LiveChannel_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.main_params)
  elif VDfJINXqYrFlyjkpohnCmMBtAHcgTQ in['LIVE','GAME_VOD','POP_VOD']:
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.play_VIDEO(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.main_params)
  elif VDfJINXqYrFlyjkpohnCmMBtAHcgTQ=='VOD_GROUP':
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.dp_MainLeague_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.main_params)
  elif VDfJINXqYrFlyjkpohnCmMBtAHcgTQ=='POP_GROUP':
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.dp_PopVod_GroupList(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.main_params)
  elif VDfJINXqYrFlyjkpohnCmMBtAHcgTQ=='LEAGUE_GROUP':
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.dp_Season_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.main_params)
  elif VDfJINXqYrFlyjkpohnCmMBtAHcgTQ=='SEASON_GROUP':
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.dp_Game_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.main_params)
  elif VDfJINXqYrFlyjkpohnCmMBtAHcgTQ=='GAME_VOD_GROUP':
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.dp_GameVod_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.main_params)
  elif VDfJINXqYrFlyjkpohnCmMBtAHcgTQ=='WATCH':
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.dp_Watch_List(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.main_params)
  elif VDfJINXqYrFlyjkpohnCmMBtAHcgTQ=='MYVIEW_REMOVE':
   VDfJINXqYrFlyjkpohnCmMBtAHcgQi.dp_WatchList_Delete(VDfJINXqYrFlyjkpohnCmMBtAHcgQi.main_params)
  else:
   VDfJINXqYrFlyjkpohnCmMBtAHcgTb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
