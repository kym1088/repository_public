__author__="NightRain"
TskuOEBNlzofiMGpXjtAYxbSQUHqrF=object
TskuOEBNlzofiMGpXjtAYxbSQUHqry=None
TskuOEBNlzofiMGpXjtAYxbSQUHqrL=False
TskuOEBNlzofiMGpXjtAYxbSQUHqrI=True
TskuOEBNlzofiMGpXjtAYxbSQUHqrn=int
TskuOEBNlzofiMGpXjtAYxbSQUHqrD=len
TskuOEBNlzofiMGpXjtAYxbSQUHqrJ=str
TskuOEBNlzofiMGpXjtAYxbSQUHqrd=open
TskuOEBNlzofiMGpXjtAYxbSQUHqrg=Exception
TskuOEBNlzofiMGpXjtAYxbSQUHqrR=print
TskuOEBNlzofiMGpXjtAYxbSQUHqra=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
TskuOEBNlzofiMGpXjtAYxbSQUHqmw=[{'title':'TV 채널 (유료사용자만 지원)','mode':'LIVE_GROUP','icon':'live.png'},{'title':'Live중계 (독점,현지)','mode':'ELIVE_GROUP','icon':'live.png'},{'title':'-----------------','mode':'XXX'},{'title':'인기영상5','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH','icon':'history.png'}]
TskuOEBNlzofiMGpXjtAYxbSQUHqmC=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class TskuOEBNlzofiMGpXjtAYxbSQUHqmh(TskuOEBNlzofiMGpXjtAYxbSQUHqrF):
 def __init__(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,TskuOEBNlzofiMGpXjtAYxbSQUHqmc,TskuOEBNlzofiMGpXjtAYxbSQUHqmV,TskuOEBNlzofiMGpXjtAYxbSQUHqmP):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_url =TskuOEBNlzofiMGpXjtAYxbSQUHqmc
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle=TskuOEBNlzofiMGpXjtAYxbSQUHqmV
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params =TskuOEBNlzofiMGpXjtAYxbSQUHqmP
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj =lLfxFONBTgeEHympoUwGCPkIqbVndv() 
 def addon_noti(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,sting):
  try:
   TskuOEBNlzofiMGpXjtAYxbSQUHqme=xbmcgui.Dialog()
   TskuOEBNlzofiMGpXjtAYxbSQUHqme.notification(__addonname__,sting)
  except:
   TskuOEBNlzofiMGpXjtAYxbSQUHqry
 def addon_log(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,string):
  try:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmF=string.encode('utf-8','ignore')
  except:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmF='addonException: addon_log'
  TskuOEBNlzofiMGpXjtAYxbSQUHqmy=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,TskuOEBNlzofiMGpXjtAYxbSQUHqmF),level=TskuOEBNlzofiMGpXjtAYxbSQUHqmy)
 def get_keyboard_input(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,TskuOEBNlzofiMGpXjtAYxbSQUHqmR):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmL=TskuOEBNlzofiMGpXjtAYxbSQUHqry
  kb=xbmc.Keyboard()
  kb.setHeading(TskuOEBNlzofiMGpXjtAYxbSQUHqmR)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   TskuOEBNlzofiMGpXjtAYxbSQUHqmL=kb.getText()
  return TskuOEBNlzofiMGpXjtAYxbSQUHqmL
 def get_settings_login_info(TskuOEBNlzofiMGpXjtAYxbSQUHqmr):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmI =__addon__.getSetting('id')
  TskuOEBNlzofiMGpXjtAYxbSQUHqmn =__addon__.getSetting('pw')
  return(TskuOEBNlzofiMGpXjtAYxbSQUHqmI,TskuOEBNlzofiMGpXjtAYxbSQUHqmn)
 def get_settings_hidescoreyn(TskuOEBNlzofiMGpXjtAYxbSQUHqmr):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmD =__addon__.getSetting('hidescore')
  if TskuOEBNlzofiMGpXjtAYxbSQUHqmD=='false':
   return TskuOEBNlzofiMGpXjtAYxbSQUHqrL
  else:
   return TskuOEBNlzofiMGpXjtAYxbSQUHqrI
 def set_winCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,credential):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ=xbmcgui.Window(10000)
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_LOGINTIME',TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqmr):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ=xbmcgui.Window(10000)
  TskuOEBNlzofiMGpXjtAYxbSQUHqmd={'spotv_sessionid':TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.getProperty('SPOTV_M_SESSIONID'),'spotv_session':TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.getProperty('SPOTV_M_SESSION'),'spotv_accountId':TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.getProperty('SPOTV_M_SUBEND')}
  return TskuOEBNlzofiMGpXjtAYxbSQUHqmd
 def add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,label,sublabel='',img='',infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqry,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqrI,params='',isLink=TskuOEBNlzofiMGpXjtAYxbSQUHqrL,ContextMenu=TskuOEBNlzofiMGpXjtAYxbSQUHqry):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmg='%s?%s'%(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_url,urllib.parse.urlencode(params))
  if sublabel:TskuOEBNlzofiMGpXjtAYxbSQUHqmR='%s < %s >'%(label,sublabel)
  else: TskuOEBNlzofiMGpXjtAYxbSQUHqmR=label
  if not img:img='DefaultFolder.png'
  TskuOEBNlzofiMGpXjtAYxbSQUHqma=xbmcgui.ListItem(TskuOEBNlzofiMGpXjtAYxbSQUHqmR)
  TskuOEBNlzofiMGpXjtAYxbSQUHqma.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:TskuOEBNlzofiMGpXjtAYxbSQUHqma.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder and not isLink:
   TskuOEBNlzofiMGpXjtAYxbSQUHqma.setProperty('IsPlayable','true')
  if ContextMenu:TskuOEBNlzofiMGpXjtAYxbSQUHqma.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle,TskuOEBNlzofiMGpXjtAYxbSQUHqmg,TskuOEBNlzofiMGpXjtAYxbSQUHqma,isFolder)
 def get_selQuality(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,etype):
  try:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmv='selected_quality'
   TskuOEBNlzofiMGpXjtAYxbSQUHqmW=[1080,720,540]
   TskuOEBNlzofiMGpXjtAYxbSQUHqhm=TskuOEBNlzofiMGpXjtAYxbSQUHqrn(__addon__.getSetting(TskuOEBNlzofiMGpXjtAYxbSQUHqmv))
   return TskuOEBNlzofiMGpXjtAYxbSQUHqmW[TskuOEBNlzofiMGpXjtAYxbSQUHqhm]
  except:
   TskuOEBNlzofiMGpXjtAYxbSQUHqry
  return 1080 
 def dp_Main_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr):
  for TskuOEBNlzofiMGpXjtAYxbSQUHqhw in TskuOEBNlzofiMGpXjtAYxbSQUHqmw:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmR=TskuOEBNlzofiMGpXjtAYxbSQUHqhw.get('title')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhC=''
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr={'mode':TskuOEBNlzofiMGpXjtAYxbSQUHqhw.get('mode')}
   if TskuOEBNlzofiMGpXjtAYxbSQUHqhw.get('mode')=='XXX':
    TskuOEBNlzofiMGpXjtAYxbSQUHqhc=TskuOEBNlzofiMGpXjtAYxbSQUHqrL
    TskuOEBNlzofiMGpXjtAYxbSQUHqhV =TskuOEBNlzofiMGpXjtAYxbSQUHqrI
   else:
    TskuOEBNlzofiMGpXjtAYxbSQUHqhc=TskuOEBNlzofiMGpXjtAYxbSQUHqrI
    TskuOEBNlzofiMGpXjtAYxbSQUHqhV =TskuOEBNlzofiMGpXjtAYxbSQUHqrL
   if 'icon' in TskuOEBNlzofiMGpXjtAYxbSQUHqhw:TskuOEBNlzofiMGpXjtAYxbSQUHqhC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',TskuOEBNlzofiMGpXjtAYxbSQUHqhw.get('icon')) 
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqmR,sublabel='',img=TskuOEBNlzofiMGpXjtAYxbSQUHqhC,infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqry,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqhc,params=TskuOEBNlzofiMGpXjtAYxbSQUHqhr,isLink=TskuOEBNlzofiMGpXjtAYxbSQUHqhV)
  if TskuOEBNlzofiMGpXjtAYxbSQUHqrD(TskuOEBNlzofiMGpXjtAYxbSQUHqmw)>0:xbmcplugin.endOfDirectory(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle)
 def dp_MainLeague_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,args):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.SaveCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.get_winCredential())
  TskuOEBNlzofiMGpXjtAYxbSQUHqhK=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.GetTitleGroupList()
  for TskuOEBNlzofiMGpXjtAYxbSQUHqhe in TskuOEBNlzofiMGpXjtAYxbSQUHqhK:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmR =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('title')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhF =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('logo')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhy =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('reagueId')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhL =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('subGame')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhI={'mediatype':'episode','plot':'%s\n\n%s'%(TskuOEBNlzofiMGpXjtAYxbSQUHqmR,TskuOEBNlzofiMGpXjtAYxbSQUHqhL)}
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr={'mode':'LEAGUE_GROUP','reagueId':TskuOEBNlzofiMGpXjtAYxbSQUHqhy}
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqmR,sublabel=TskuOEBNlzofiMGpXjtAYxbSQUHqry,img=TskuOEBNlzofiMGpXjtAYxbSQUHqhF,infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqhI,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqrI,params=TskuOEBNlzofiMGpXjtAYxbSQUHqhr)
  if TskuOEBNlzofiMGpXjtAYxbSQUHqrD(TskuOEBNlzofiMGpXjtAYxbSQUHqhK)>0:xbmcplugin.endOfDirectory(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle,cacheToDisc=TskuOEBNlzofiMGpXjtAYxbSQUHqrL)
 def dp_PopVod_GroupList(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,args):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.SaveCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.get_winCredential())
  TskuOEBNlzofiMGpXjtAYxbSQUHqhK=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.GetPopularGroupList()
  for TskuOEBNlzofiMGpXjtAYxbSQUHqhe in TskuOEBNlzofiMGpXjtAYxbSQUHqhK:
   TskuOEBNlzofiMGpXjtAYxbSQUHqhn =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('vodTitle')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhD =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('vodId')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhJ =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('vodType')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhF=TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('thumbnail')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhd =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('vtypeId')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhg =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('duration')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhI={'mediatype':'video','duration':TskuOEBNlzofiMGpXjtAYxbSQUHqhg,'plot':TskuOEBNlzofiMGpXjtAYxbSQUHqhn}
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr={'mode':'POP_VOD','mediacode':TskuOEBNlzofiMGpXjtAYxbSQUHqhD,'mediatype':'vod','vtypeId':TskuOEBNlzofiMGpXjtAYxbSQUHqhd}
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqhn,sublabel=TskuOEBNlzofiMGpXjtAYxbSQUHqhJ,img=TskuOEBNlzofiMGpXjtAYxbSQUHqhF,infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqhI,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqrL,params=TskuOEBNlzofiMGpXjtAYxbSQUHqhr)
  if TskuOEBNlzofiMGpXjtAYxbSQUHqrD(TskuOEBNlzofiMGpXjtAYxbSQUHqhK)>0:xbmcplugin.endOfDirectory(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle,cacheToDisc=TskuOEBNlzofiMGpXjtAYxbSQUHqrL)
 def dp_Season_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,args):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.SaveCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.get_winCredential())
  TskuOEBNlzofiMGpXjtAYxbSQUHqhy=args.get('reagueId')
  TskuOEBNlzofiMGpXjtAYxbSQUHqhK=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.GetSeasonList(TskuOEBNlzofiMGpXjtAYxbSQUHqhy)
  for TskuOEBNlzofiMGpXjtAYxbSQUHqhe in TskuOEBNlzofiMGpXjtAYxbSQUHqhK:
   TskuOEBNlzofiMGpXjtAYxbSQUHqhR =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('reagueName')
   TskuOEBNlzofiMGpXjtAYxbSQUHqha =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('gameTypeId')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhv =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('seasonName')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhW =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('seasonId')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhI={'mediatype':'episode','plot':'%s - %s'%(TskuOEBNlzofiMGpXjtAYxbSQUHqhR,TskuOEBNlzofiMGpXjtAYxbSQUHqhv)}
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr={'mode':'SEASON_GROUP','reagueId':TskuOEBNlzofiMGpXjtAYxbSQUHqhy,'seasonId':TskuOEBNlzofiMGpXjtAYxbSQUHqhW,'gameTypeId':TskuOEBNlzofiMGpXjtAYxbSQUHqha,'page':'1'}
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqhR,sublabel=TskuOEBNlzofiMGpXjtAYxbSQUHqhv,img='',infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqhI,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqrI,params=TskuOEBNlzofiMGpXjtAYxbSQUHqhr)
  if TskuOEBNlzofiMGpXjtAYxbSQUHqrD(TskuOEBNlzofiMGpXjtAYxbSQUHqhK)>0:xbmcplugin.endOfDirectory(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle,cacheToDisc=TskuOEBNlzofiMGpXjtAYxbSQUHqrI)
 def dp_Game_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,args):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.SaveCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.get_winCredential())
  TskuOEBNlzofiMGpXjtAYxbSQUHqha=args.get('gameTypeId')
  TskuOEBNlzofiMGpXjtAYxbSQUHqhy =args.get('reagueId')
  TskuOEBNlzofiMGpXjtAYxbSQUHqhW =args.get('seasonId')
  TskuOEBNlzofiMGpXjtAYxbSQUHqwm =TskuOEBNlzofiMGpXjtAYxbSQUHqrn(args.get('page'))
  TskuOEBNlzofiMGpXjtAYxbSQUHqhK,TskuOEBNlzofiMGpXjtAYxbSQUHqwh=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.GetGameList(TskuOEBNlzofiMGpXjtAYxbSQUHqha,TskuOEBNlzofiMGpXjtAYxbSQUHqhy,TskuOEBNlzofiMGpXjtAYxbSQUHqhW,TskuOEBNlzofiMGpXjtAYxbSQUHqwm,hidescore=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.get_settings_hidescoreyn())
  for TskuOEBNlzofiMGpXjtAYxbSQUHqhe in TskuOEBNlzofiMGpXjtAYxbSQUHqhK:
   TskuOEBNlzofiMGpXjtAYxbSQUHqwC =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('gameTitle')
   TskuOEBNlzofiMGpXjtAYxbSQUHqwr =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('beginDate')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhF =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('thumbnail')
   TskuOEBNlzofiMGpXjtAYxbSQUHqwc =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('gameId')
   TskuOEBNlzofiMGpXjtAYxbSQUHqwV =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('totVodCnt')
   TskuOEBNlzofiMGpXjtAYxbSQUHqwP =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('leaguenm')
   TskuOEBNlzofiMGpXjtAYxbSQUHqwK =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('seasonnm')
   TskuOEBNlzofiMGpXjtAYxbSQUHqwe =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('roundnm')
   TskuOEBNlzofiMGpXjtAYxbSQUHqwF =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('info_plot')
   TskuOEBNlzofiMGpXjtAYxbSQUHqwy ='%s < %s >'%(TskuOEBNlzofiMGpXjtAYxbSQUHqwC,TskuOEBNlzofiMGpXjtAYxbSQUHqwr)
   TskuOEBNlzofiMGpXjtAYxbSQUHqhI={'mediatype':'video','plot':TskuOEBNlzofiMGpXjtAYxbSQUHqwF}
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr={'mode':'GAME_VOD_GROUP' if TskuOEBNlzofiMGpXjtAYxbSQUHqwV!=0 else 'XXX','saveTitle':TskuOEBNlzofiMGpXjtAYxbSQUHqwy,'saveImg':TskuOEBNlzofiMGpXjtAYxbSQUHqhF,'saveInfo':TskuOEBNlzofiMGpXjtAYxbSQUHqhI['plot'],'gameid':TskuOEBNlzofiMGpXjtAYxbSQUHqwc}
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqwC,sublabel=TskuOEBNlzofiMGpXjtAYxbSQUHqwr,img=TskuOEBNlzofiMGpXjtAYxbSQUHqhF,infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqhI,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqrI,params=TskuOEBNlzofiMGpXjtAYxbSQUHqhr)
  if TskuOEBNlzofiMGpXjtAYxbSQUHqwh:
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr['mode'] ='SEASON_GROUP' 
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr['reagueId'] =TskuOEBNlzofiMGpXjtAYxbSQUHqhy
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr['seasonId'] =TskuOEBNlzofiMGpXjtAYxbSQUHqhW
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr['gameTypeId']=TskuOEBNlzofiMGpXjtAYxbSQUHqha
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr['page'] =TskuOEBNlzofiMGpXjtAYxbSQUHqrJ(TskuOEBNlzofiMGpXjtAYxbSQUHqwm+1)
   TskuOEBNlzofiMGpXjtAYxbSQUHqmR='[B]%s >>[/B]'%'다음 페이지'
   TskuOEBNlzofiMGpXjtAYxbSQUHqwL=TskuOEBNlzofiMGpXjtAYxbSQUHqrJ(TskuOEBNlzofiMGpXjtAYxbSQUHqwm+1)
   TskuOEBNlzofiMGpXjtAYxbSQUHqhC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqmR,sublabel=TskuOEBNlzofiMGpXjtAYxbSQUHqwL,img=TskuOEBNlzofiMGpXjtAYxbSQUHqhC,infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqry,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqrI,params=TskuOEBNlzofiMGpXjtAYxbSQUHqhr)
  if TskuOEBNlzofiMGpXjtAYxbSQUHqrD(TskuOEBNlzofiMGpXjtAYxbSQUHqhK)>0:xbmcplugin.endOfDirectory(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle,cacheToDisc=TskuOEBNlzofiMGpXjtAYxbSQUHqrL)
 def dp_GameVod_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,args):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.SaveCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.get_winCredential())
  TskuOEBNlzofiMGpXjtAYxbSQUHqwI =args.get('gameid')
  TskuOEBNlzofiMGpXjtAYxbSQUHqwy=args.get('saveTitle')
  TskuOEBNlzofiMGpXjtAYxbSQUHqwn =args.get('saveImg')
  TskuOEBNlzofiMGpXjtAYxbSQUHqwD =args.get('saveInfo')
  TskuOEBNlzofiMGpXjtAYxbSQUHqhK=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.GetGameVodList(TskuOEBNlzofiMGpXjtAYxbSQUHqwI)
  for TskuOEBNlzofiMGpXjtAYxbSQUHqhe in TskuOEBNlzofiMGpXjtAYxbSQUHqhK:
   TskuOEBNlzofiMGpXjtAYxbSQUHqhn =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('vodTitle')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhD =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('vodId')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhJ =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('vodType')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhF=TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('thumbnail')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhd =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('vtypeId')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhg =TskuOEBNlzofiMGpXjtAYxbSQUHqhe.get('duration')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhI={'mediatype':'video','duration':TskuOEBNlzofiMGpXjtAYxbSQUHqhg,'plot':'%s \n\n %s'%(TskuOEBNlzofiMGpXjtAYxbSQUHqhn,TskuOEBNlzofiMGpXjtAYxbSQUHqwD)}
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr={'mode':'GAME_VOD','saveTitle':TskuOEBNlzofiMGpXjtAYxbSQUHqwy,'saveImg':TskuOEBNlzofiMGpXjtAYxbSQUHqwn,'saveId':TskuOEBNlzofiMGpXjtAYxbSQUHqwI,'saveInfo':TskuOEBNlzofiMGpXjtAYxbSQUHqwD,'mediacode':TskuOEBNlzofiMGpXjtAYxbSQUHqhD,'mediatype':'vod','vtypeId':TskuOEBNlzofiMGpXjtAYxbSQUHqhd}
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqhn,sublabel=TskuOEBNlzofiMGpXjtAYxbSQUHqhJ,img=TskuOEBNlzofiMGpXjtAYxbSQUHqhF,infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqhI,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqrL,params=TskuOEBNlzofiMGpXjtAYxbSQUHqhr)
  if TskuOEBNlzofiMGpXjtAYxbSQUHqrD(TskuOEBNlzofiMGpXjtAYxbSQUHqhK)>0:xbmcplugin.endOfDirectory(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle,cacheToDisc=TskuOEBNlzofiMGpXjtAYxbSQUHqrL)
 def login_main(TskuOEBNlzofiMGpXjtAYxbSQUHqmr):
  (TskuOEBNlzofiMGpXjtAYxbSQUHqwJ,TskuOEBNlzofiMGpXjtAYxbSQUHqwd)=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.get_settings_login_info()
  if not(TskuOEBNlzofiMGpXjtAYxbSQUHqwJ and TskuOEBNlzofiMGpXjtAYxbSQUHqwd):
   TskuOEBNlzofiMGpXjtAYxbSQUHqme=xbmcgui.Dialog()
   TskuOEBNlzofiMGpXjtAYxbSQUHqwg=TskuOEBNlzofiMGpXjtAYxbSQUHqme.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if TskuOEBNlzofiMGpXjtAYxbSQUHqwg==TskuOEBNlzofiMGpXjtAYxbSQUHqrI:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if TskuOEBNlzofiMGpXjtAYxbSQUHqmr.cookiefile_check():return
  TskuOEBNlzofiMGpXjtAYxbSQUHqwR =TskuOEBNlzofiMGpXjtAYxbSQUHqrn(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  TskuOEBNlzofiMGpXjtAYxbSQUHqwa=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if TskuOEBNlzofiMGpXjtAYxbSQUHqwa==TskuOEBNlzofiMGpXjtAYxbSQUHqry or TskuOEBNlzofiMGpXjtAYxbSQUHqwa=='':
   TskuOEBNlzofiMGpXjtAYxbSQUHqwa=TskuOEBNlzofiMGpXjtAYxbSQUHqrn('19000101')
  else:
   TskuOEBNlzofiMGpXjtAYxbSQUHqwa=TskuOEBNlzofiMGpXjtAYxbSQUHqrn(re.sub('-','',TskuOEBNlzofiMGpXjtAYxbSQUHqwa))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   TskuOEBNlzofiMGpXjtAYxbSQUHqwv=0
   while TskuOEBNlzofiMGpXjtAYxbSQUHqrI:
    TskuOEBNlzofiMGpXjtAYxbSQUHqwv+=1
    time.sleep(0.05)
    if TskuOEBNlzofiMGpXjtAYxbSQUHqwa>=TskuOEBNlzofiMGpXjtAYxbSQUHqwR:return
    if TskuOEBNlzofiMGpXjtAYxbSQUHqwv>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if TskuOEBNlzofiMGpXjtAYxbSQUHqwa>=TskuOEBNlzofiMGpXjtAYxbSQUHqwR:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.GetCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqwJ,TskuOEBNlzofiMGpXjtAYxbSQUHqwd):
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.set_winCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.LoadCredential())
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,args):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.SaveCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.get_winCredential())
  TskuOEBNlzofiMGpXjtAYxbSQUHqwW=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.GetLiveChannelList()
  for TskuOEBNlzofiMGpXjtAYxbSQUHqCm in TskuOEBNlzofiMGpXjtAYxbSQUHqwW:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmR =TskuOEBNlzofiMGpXjtAYxbSQUHqCm.get('name')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhF =TskuOEBNlzofiMGpXjtAYxbSQUHqCm.get('logo')
   TskuOEBNlzofiMGpXjtAYxbSQUHqCh=TskuOEBNlzofiMGpXjtAYxbSQUHqCm.get('channelepg')
   TskuOEBNlzofiMGpXjtAYxbSQUHqCw =TskuOEBNlzofiMGpXjtAYxbSQUHqCm.get('free')
   if TskuOEBNlzofiMGpXjtAYxbSQUHqCh:
    TskuOEBNlzofiMGpXjtAYxbSQUHqCr =TskuOEBNlzofiMGpXjtAYxbSQUHqCh['epg']
    TskuOEBNlzofiMGpXjtAYxbSQUHqCc=TskuOEBNlzofiMGpXjtAYxbSQUHqCh['title']
   else:
    TskuOEBNlzofiMGpXjtAYxbSQUHqCr =''
    TskuOEBNlzofiMGpXjtAYxbSQUHqCc=''
   TskuOEBNlzofiMGpXjtAYxbSQUHqhI={'plot':'%s\n\n%s'%(TskuOEBNlzofiMGpXjtAYxbSQUHqmR,TskuOEBNlzofiMGpXjtAYxbSQUHqCr),'mediatype':'video'}
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr={'mode':'LIVE','mediacode':TskuOEBNlzofiMGpXjtAYxbSQUHqCm.get('videoId'),'free':TskuOEBNlzofiMGpXjtAYxbSQUHqCw,'mediatype':'live'}
   if TskuOEBNlzofiMGpXjtAYxbSQUHqCw:TskuOEBNlzofiMGpXjtAYxbSQUHqmR+=' [free]'
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqmR,sublabel=TskuOEBNlzofiMGpXjtAYxbSQUHqCc,img=TskuOEBNlzofiMGpXjtAYxbSQUHqhF,infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqhI,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqrL,params=TskuOEBNlzofiMGpXjtAYxbSQUHqhr)
  if TskuOEBNlzofiMGpXjtAYxbSQUHqrD(TskuOEBNlzofiMGpXjtAYxbSQUHqwW)>0:xbmcplugin.endOfDirectory(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle,cacheToDisc=TskuOEBNlzofiMGpXjtAYxbSQUHqrL)
 def dp_EventLiveChannel_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,args):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.SaveCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.get_winCredential())
  TskuOEBNlzofiMGpXjtAYxbSQUHqwW,TskuOEBNlzofiMGpXjtAYxbSQUHqCV=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.GetEventLiveList()
  if TskuOEBNlzofiMGpXjtAYxbSQUHqCV!=401 and TskuOEBNlzofiMGpXjtAYxbSQUHqrD(TskuOEBNlzofiMGpXjtAYxbSQUHqwW)==0:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.addon_noti(__language__(30907).encode('utf8'))
  for TskuOEBNlzofiMGpXjtAYxbSQUHqCm in TskuOEBNlzofiMGpXjtAYxbSQUHqwW:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmR =TskuOEBNlzofiMGpXjtAYxbSQUHqCm.get('title')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhP =TskuOEBNlzofiMGpXjtAYxbSQUHqCm.get('startTime')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhF =TskuOEBNlzofiMGpXjtAYxbSQUHqCm.get('logo')
   TskuOEBNlzofiMGpXjtAYxbSQUHqCw =TskuOEBNlzofiMGpXjtAYxbSQUHqCm.get('free')
   TskuOEBNlzofiMGpXjtAYxbSQUHqhI={'mediatype':'video','plot':'%s\n\n%s'%(TskuOEBNlzofiMGpXjtAYxbSQUHqmR,TskuOEBNlzofiMGpXjtAYxbSQUHqhP)}
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr={'mode':'ELIVE','mediaid':TskuOEBNlzofiMGpXjtAYxbSQUHqCm.get('liveId'),'mediacode':'','free':TskuOEBNlzofiMGpXjtAYxbSQUHqCw,'mediatype':'live'}
   if TskuOEBNlzofiMGpXjtAYxbSQUHqCw:TskuOEBNlzofiMGpXjtAYxbSQUHqmR+=' [free]'
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqmR,sublabel=TskuOEBNlzofiMGpXjtAYxbSQUHqhP,img=TskuOEBNlzofiMGpXjtAYxbSQUHqhF,infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqhI,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqrL,params=TskuOEBNlzofiMGpXjtAYxbSQUHqhr)
  if TskuOEBNlzofiMGpXjtAYxbSQUHqrD(TskuOEBNlzofiMGpXjtAYxbSQUHqwW)>0:xbmcplugin.endOfDirectory(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle,cacheToDisc=TskuOEBNlzofiMGpXjtAYxbSQUHqrI)
  return TskuOEBNlzofiMGpXjtAYxbSQUHqCV
 def play_VIDEO(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,args):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.SaveCredential(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.get_winCredential())
  TskuOEBNlzofiMGpXjtAYxbSQUHqCP =args.get('mode')
  TskuOEBNlzofiMGpXjtAYxbSQUHqCK =args.get('mediacode')
  TskuOEBNlzofiMGpXjtAYxbSQUHqCe =args.get('mediatype')
  TskuOEBNlzofiMGpXjtAYxbSQUHqhd =args.get('vtypeId')
  if TskuOEBNlzofiMGpXjtAYxbSQUHqCP=='LIVE':
   if args.get('free')=='False':
    if TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.CheckSubEnd()==TskuOEBNlzofiMGpXjtAYxbSQUHqrL:
     TskuOEBNlzofiMGpXjtAYxbSQUHqmr.addon_noti(__language__(30908).encode('utf8'))
     return
  elif TskuOEBNlzofiMGpXjtAYxbSQUHqCP=='ELIVE':
   if args.get('free')=='False':
    if TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.CheckSubEnd()==TskuOEBNlzofiMGpXjtAYxbSQUHqrL:
     TskuOEBNlzofiMGpXjtAYxbSQUHqmr.addon_noti(__language__(30908).encode('utf8'))
     return
   TskuOEBNlzofiMGpXjtAYxbSQUHqCK=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if TskuOEBNlzofiMGpXjtAYxbSQUHqCK=='' or TskuOEBNlzofiMGpXjtAYxbSQUHqCK==TskuOEBNlzofiMGpXjtAYxbSQUHqry:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.addon_noti(__language__(30907).encode('utf8'))
   return
  if TskuOEBNlzofiMGpXjtAYxbSQUHqCP=='LIVE':
   TskuOEBNlzofiMGpXjtAYxbSQUHqCF=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.Get_Streamurl_Make(args.get('mediacode'))
  else:
   TskuOEBNlzofiMGpXjtAYxbSQUHqCF=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.GetBroadURL(TskuOEBNlzofiMGpXjtAYxbSQUHqCK,TskuOEBNlzofiMGpXjtAYxbSQUHqCe,TskuOEBNlzofiMGpXjtAYxbSQUHqhd)
  if TskuOEBNlzofiMGpXjtAYxbSQUHqCF=='':
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.addon_noti(__language__(30908).encode('utf8'))
   return
  TskuOEBNlzofiMGpXjtAYxbSQUHqCy=TskuOEBNlzofiMGpXjtAYxbSQUHqCF
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.addon_log(TskuOEBNlzofiMGpXjtAYxbSQUHqCy)
  TskuOEBNlzofiMGpXjtAYxbSQUHqCL=xbmcgui.ListItem(path=TskuOEBNlzofiMGpXjtAYxbSQUHqCy)
  xbmcplugin.setResolvedUrl(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle,TskuOEBNlzofiMGpXjtAYxbSQUHqrI,TskuOEBNlzofiMGpXjtAYxbSQUHqCL)
  try:
   if TskuOEBNlzofiMGpXjtAYxbSQUHqCe=='vod' and TskuOEBNlzofiMGpXjtAYxbSQUHqCP!='POP_VOD':
    TskuOEBNlzofiMGpXjtAYxbSQUHqhr={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    TskuOEBNlzofiMGpXjtAYxbSQUHqmr.Save_Watched_List(TskuOEBNlzofiMGpXjtAYxbSQUHqCe,TskuOEBNlzofiMGpXjtAYxbSQUHqhr)
  except:
   TskuOEBNlzofiMGpXjtAYxbSQUHqry
 def logout(TskuOEBNlzofiMGpXjtAYxbSQUHqmr):
  TskuOEBNlzofiMGpXjtAYxbSQUHqme=xbmcgui.Dialog()
  TskuOEBNlzofiMGpXjtAYxbSQUHqwg=TskuOEBNlzofiMGpXjtAYxbSQUHqme.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if TskuOEBNlzofiMGpXjtAYxbSQUHqwg==TskuOEBNlzofiMGpXjtAYxbSQUHqrL:sys.exit()
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.wininfo_clear()
  if os.path.isfile(TskuOEBNlzofiMGpXjtAYxbSQUHqmC):os.remove(TskuOEBNlzofiMGpXjtAYxbSQUHqmC)
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(TskuOEBNlzofiMGpXjtAYxbSQUHqmr):
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ=xbmcgui.Window(10000)
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_SESSIONID','')
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_SESSION','')
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_ACCOUNTID','')
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_POLICYKEY','')
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_SUBEND','')
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(TskuOEBNlzofiMGpXjtAYxbSQUHqmr):
  TskuOEBNlzofiMGpXjtAYxbSQUHqCI =TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.Get_Now_Datetime()
  TskuOEBNlzofiMGpXjtAYxbSQUHqCn=TskuOEBNlzofiMGpXjtAYxbSQUHqCI+datetime.timedelta(days=TskuOEBNlzofiMGpXjtAYxbSQUHqrn(__addon__.getSetting('cache_ttl')))
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ=xbmcgui.Window(10000)
  TskuOEBNlzofiMGpXjtAYxbSQUHqCD={'spotv_sessionid':TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.getProperty('SPOTV_M_SESSIONID'),'spotv_session':TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.getProperty('SPOTV_M_SESSION'),'spotv_accountId':TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.SPOTV_PMCODE+TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':TskuOEBNlzofiMGpXjtAYxbSQUHqCn.strftime('%Y-%m-%d')}
  try: 
   fp=TskuOEBNlzofiMGpXjtAYxbSQUHqrd(TskuOEBNlzofiMGpXjtAYxbSQUHqmC,'w',-1,'utf-8')
   json.dump(TskuOEBNlzofiMGpXjtAYxbSQUHqCD,fp)
   fp.close()
  except TskuOEBNlzofiMGpXjtAYxbSQUHqrg as exception:
   TskuOEBNlzofiMGpXjtAYxbSQUHqrR(exception)
 def cookiefile_check(TskuOEBNlzofiMGpXjtAYxbSQUHqmr):
  TskuOEBNlzofiMGpXjtAYxbSQUHqCD={}
  try: 
   fp=TskuOEBNlzofiMGpXjtAYxbSQUHqrd(TskuOEBNlzofiMGpXjtAYxbSQUHqmC,'r',-1,'utf-8')
   TskuOEBNlzofiMGpXjtAYxbSQUHqCD= json.load(fp)
   fp.close()
  except TskuOEBNlzofiMGpXjtAYxbSQUHqrg as exception:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.wininfo_clear()
   return TskuOEBNlzofiMGpXjtAYxbSQUHqrL
  TskuOEBNlzofiMGpXjtAYxbSQUHqwJ =__addon__.getSetting('id')
  TskuOEBNlzofiMGpXjtAYxbSQUHqwd =__addon__.getSetting('pw')
  TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_id'] =base64.standard_b64decode(TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_id']).decode('utf-8')
  TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_pw'] =base64.standard_b64decode(TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_pw']).decode('utf-8')
  TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_policyKey']=base64.standard_b64decode(TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_policyKey']).decode('utf-8')
  TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_subend']=base64.standard_b64decode(TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_subend']).decode('utf-8')[TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.SPOTV_PMSIZE:]
  if TskuOEBNlzofiMGpXjtAYxbSQUHqwJ!=TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_id']or TskuOEBNlzofiMGpXjtAYxbSQUHqwd!=TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_pw']:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.wininfo_clear()
   return TskuOEBNlzofiMGpXjtAYxbSQUHqrL
  TskuOEBNlzofiMGpXjtAYxbSQUHqwR =TskuOEBNlzofiMGpXjtAYxbSQUHqrn(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  TskuOEBNlzofiMGpXjtAYxbSQUHqCJ=TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_limitdate']
  TskuOEBNlzofiMGpXjtAYxbSQUHqwa =TskuOEBNlzofiMGpXjtAYxbSQUHqrn(re.sub('-','',TskuOEBNlzofiMGpXjtAYxbSQUHqCJ))
  if TskuOEBNlzofiMGpXjtAYxbSQUHqwa<TskuOEBNlzofiMGpXjtAYxbSQUHqwR:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.wininfo_clear()
   return TskuOEBNlzofiMGpXjtAYxbSQUHqrL
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ=xbmcgui.Window(10000)
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_SESSIONID',TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_sessionid'])
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_SESSION',TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_session'])
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_ACCOUNTID',TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_accountId'])
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_POLICYKEY',TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_policyKey'])
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_SUBEND',TskuOEBNlzofiMGpXjtAYxbSQUHqCD['spotv_subend'])
  TskuOEBNlzofiMGpXjtAYxbSQUHqmJ.setProperty('SPOTV_M_LOGINTIME',TskuOEBNlzofiMGpXjtAYxbSQUHqCJ)
  return TskuOEBNlzofiMGpXjtAYxbSQUHqrI
 def dp_WatchList_Delete(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,args):
  TskuOEBNlzofiMGpXjtAYxbSQUHqCe=args.get('mediatype')
  TskuOEBNlzofiMGpXjtAYxbSQUHqme=xbmcgui.Dialog()
  TskuOEBNlzofiMGpXjtAYxbSQUHqwg=TskuOEBNlzofiMGpXjtAYxbSQUHqme.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if TskuOEBNlzofiMGpXjtAYxbSQUHqwg==TskuOEBNlzofiMGpXjtAYxbSQUHqrL:sys.exit()
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.Delete_Watched_List(TskuOEBNlzofiMGpXjtAYxbSQUHqCe)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,TskuOEBNlzofiMGpXjtAYxbSQUHqCe):
  try:
   TskuOEBNlzofiMGpXjtAYxbSQUHqCd=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TskuOEBNlzofiMGpXjtAYxbSQUHqCe))
   fp=TskuOEBNlzofiMGpXjtAYxbSQUHqrd(TskuOEBNlzofiMGpXjtAYxbSQUHqCd,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   TskuOEBNlzofiMGpXjtAYxbSQUHqry
 def Load_Watched_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,TskuOEBNlzofiMGpXjtAYxbSQUHqCe):
  try:
   TskuOEBNlzofiMGpXjtAYxbSQUHqCd=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TskuOEBNlzofiMGpXjtAYxbSQUHqCe))
   fp=TskuOEBNlzofiMGpXjtAYxbSQUHqrd(TskuOEBNlzofiMGpXjtAYxbSQUHqCd,'r',-1,'utf-8')
   TskuOEBNlzofiMGpXjtAYxbSQUHqCg=fp.readlines()
   fp.close()
  except:
   TskuOEBNlzofiMGpXjtAYxbSQUHqCg=[]
  return TskuOEBNlzofiMGpXjtAYxbSQUHqCg
 def Save_Watched_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,stype,TskuOEBNlzofiMGpXjtAYxbSQUHqmP):
  try:
   TskuOEBNlzofiMGpXjtAYxbSQUHqCd=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   TskuOEBNlzofiMGpXjtAYxbSQUHqCR=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.Load_Watched_List(stype) 
   fp=TskuOEBNlzofiMGpXjtAYxbSQUHqrd(TskuOEBNlzofiMGpXjtAYxbSQUHqCd,'w',-1,'utf-8')
   TskuOEBNlzofiMGpXjtAYxbSQUHqCa=urllib.parse.urlencode(TskuOEBNlzofiMGpXjtAYxbSQUHqmP)
   TskuOEBNlzofiMGpXjtAYxbSQUHqCa=TskuOEBNlzofiMGpXjtAYxbSQUHqCa+'\n'
   fp.write(TskuOEBNlzofiMGpXjtAYxbSQUHqCa)
   TskuOEBNlzofiMGpXjtAYxbSQUHqCv=0
   for TskuOEBNlzofiMGpXjtAYxbSQUHqCW in TskuOEBNlzofiMGpXjtAYxbSQUHqCR:
    TskuOEBNlzofiMGpXjtAYxbSQUHqrm=TskuOEBNlzofiMGpXjtAYxbSQUHqra(urllib.parse.parse_qsl(TskuOEBNlzofiMGpXjtAYxbSQUHqCW))
    TskuOEBNlzofiMGpXjtAYxbSQUHqrh=TskuOEBNlzofiMGpXjtAYxbSQUHqmP.get('code')
    TskuOEBNlzofiMGpXjtAYxbSQUHqrw=TskuOEBNlzofiMGpXjtAYxbSQUHqrm.get('code')
    if TskuOEBNlzofiMGpXjtAYxbSQUHqrh!=TskuOEBNlzofiMGpXjtAYxbSQUHqrw:
     fp.write(TskuOEBNlzofiMGpXjtAYxbSQUHqCW)
     TskuOEBNlzofiMGpXjtAYxbSQUHqCv+=1
     if TskuOEBNlzofiMGpXjtAYxbSQUHqCv>=50:break
   fp.close()
  except:
   TskuOEBNlzofiMGpXjtAYxbSQUHqry
 def dp_Watch_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr,args):
  TskuOEBNlzofiMGpXjtAYxbSQUHqCe ='vod'
  if TskuOEBNlzofiMGpXjtAYxbSQUHqCe=='vod':
   TskuOEBNlzofiMGpXjtAYxbSQUHqrC=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.Load_Watched_List(TskuOEBNlzofiMGpXjtAYxbSQUHqCe)
   for TskuOEBNlzofiMGpXjtAYxbSQUHqrc in TskuOEBNlzofiMGpXjtAYxbSQUHqrC:
    TskuOEBNlzofiMGpXjtAYxbSQUHqrV=TskuOEBNlzofiMGpXjtAYxbSQUHqra(urllib.parse.parse_qsl(TskuOEBNlzofiMGpXjtAYxbSQUHqrc))
    TskuOEBNlzofiMGpXjtAYxbSQUHqmR =TskuOEBNlzofiMGpXjtAYxbSQUHqrV.get('title')
    TskuOEBNlzofiMGpXjtAYxbSQUHqhF=TskuOEBNlzofiMGpXjtAYxbSQUHqrV.get('img')
    TskuOEBNlzofiMGpXjtAYxbSQUHqCK=TskuOEBNlzofiMGpXjtAYxbSQUHqrV.get('code')
    TskuOEBNlzofiMGpXjtAYxbSQUHqrP =TskuOEBNlzofiMGpXjtAYxbSQUHqrV.get('info')
    TskuOEBNlzofiMGpXjtAYxbSQUHqhI={}
    TskuOEBNlzofiMGpXjtAYxbSQUHqhI['plot']=TskuOEBNlzofiMGpXjtAYxbSQUHqrP
    TskuOEBNlzofiMGpXjtAYxbSQUHqhr={'mode':'GAME_VOD_GROUP','gameid':TskuOEBNlzofiMGpXjtAYxbSQUHqCK,'saveTitle':TskuOEBNlzofiMGpXjtAYxbSQUHqmR,'saveImg':TskuOEBNlzofiMGpXjtAYxbSQUHqhF,'saveInfo':TskuOEBNlzofiMGpXjtAYxbSQUHqrP,'mediatype':TskuOEBNlzofiMGpXjtAYxbSQUHqCe}
    TskuOEBNlzofiMGpXjtAYxbSQUHqmr.add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqmR,sublabel='',img=TskuOEBNlzofiMGpXjtAYxbSQUHqhF,infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqhI,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqrI,params=TskuOEBNlzofiMGpXjtAYxbSQUHqhr)
   TskuOEBNlzofiMGpXjtAYxbSQUHqhI={'plot':'시청목록을 삭제합니다.'}
   TskuOEBNlzofiMGpXjtAYxbSQUHqmR='*** 시청목록 삭제 ***'
   TskuOEBNlzofiMGpXjtAYxbSQUHqhr={'mode':'MYVIEW_REMOVE','mediatype':TskuOEBNlzofiMGpXjtAYxbSQUHqCe}
   TskuOEBNlzofiMGpXjtAYxbSQUHqhC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.add_dir(TskuOEBNlzofiMGpXjtAYxbSQUHqmR,sublabel='',img=TskuOEBNlzofiMGpXjtAYxbSQUHqhC,infoLabels=TskuOEBNlzofiMGpXjtAYxbSQUHqhI,isFolder=TskuOEBNlzofiMGpXjtAYxbSQUHqrL,params=TskuOEBNlzofiMGpXjtAYxbSQUHqhr,isLink=TskuOEBNlzofiMGpXjtAYxbSQUHqrI)
   xbmcplugin.endOfDirectory(TskuOEBNlzofiMGpXjtAYxbSQUHqmr._addon_handle,cacheToDisc=TskuOEBNlzofiMGpXjtAYxbSQUHqrL)
 def spotv_main(TskuOEBNlzofiMGpXjtAYxbSQUHqmr):
  TskuOEBNlzofiMGpXjtAYxbSQUHqre=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params.get('mode',TskuOEBNlzofiMGpXjtAYxbSQUHqry)
  if TskuOEBNlzofiMGpXjtAYxbSQUHqre=='LOGOUT':
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.logout()
   return
  TskuOEBNlzofiMGpXjtAYxbSQUHqmr.login_main()
  if TskuOEBNlzofiMGpXjtAYxbSQUHqre is TskuOEBNlzofiMGpXjtAYxbSQUHqry:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.dp_Main_List()
  elif TskuOEBNlzofiMGpXjtAYxbSQUHqre=='LIVE_GROUP':
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.dp_LiveChannel_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params)
  elif TskuOEBNlzofiMGpXjtAYxbSQUHqre=='ELIVE_GROUP':
   TskuOEBNlzofiMGpXjtAYxbSQUHqCV=TskuOEBNlzofiMGpXjtAYxbSQUHqmr.dp_EventLiveChannel_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params)
   if TskuOEBNlzofiMGpXjtAYxbSQUHqCV==401:
    if os.path.isfile(TskuOEBNlzofiMGpXjtAYxbSQUHqmC):os.remove(TskuOEBNlzofiMGpXjtAYxbSQUHqmC)
    TskuOEBNlzofiMGpXjtAYxbSQUHqmr.login_main()
    TskuOEBNlzofiMGpXjtAYxbSQUHqmr.dp_EventLiveChannel_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params)
  elif TskuOEBNlzofiMGpXjtAYxbSQUHqre in['LIVE','GAME_VOD','POP_VOD','ELIVE']:
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.play_VIDEO(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params)
  elif TskuOEBNlzofiMGpXjtAYxbSQUHqre=='VOD_GROUP':
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.dp_MainLeague_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params)
  elif TskuOEBNlzofiMGpXjtAYxbSQUHqre=='POP_GROUP':
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.dp_PopVod_GroupList(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params)
  elif TskuOEBNlzofiMGpXjtAYxbSQUHqre=='LEAGUE_GROUP':
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.dp_Season_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params)
  elif TskuOEBNlzofiMGpXjtAYxbSQUHqre=='SEASON_GROUP':
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.dp_Game_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params)
  elif TskuOEBNlzofiMGpXjtAYxbSQUHqre=='GAME_VOD_GROUP':
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.dp_GameVod_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params)
  elif TskuOEBNlzofiMGpXjtAYxbSQUHqre=='WATCH':
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.dp_Watch_List(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params)
  elif TskuOEBNlzofiMGpXjtAYxbSQUHqre=='MYVIEW_REMOVE':
   TskuOEBNlzofiMGpXjtAYxbSQUHqmr.dp_WatchList_Delete(TskuOEBNlzofiMGpXjtAYxbSQUHqmr.main_params)
  else:
   TskuOEBNlzofiMGpXjtAYxbSQUHqry
# Created by pyminifier (https://github.com/liftoff/pyminifier)
