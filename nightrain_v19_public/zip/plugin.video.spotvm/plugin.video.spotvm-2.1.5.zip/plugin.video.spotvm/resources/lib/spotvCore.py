__author__="NightRain"
lLfxFONBTgeEHympoUwGCPkIqbVnDz=False
lLfxFONBTgeEHympoUwGCPkIqbVnDh=object
lLfxFONBTgeEHympoUwGCPkIqbVnDR=None
lLfxFONBTgeEHympoUwGCPkIqbVnDK=print
lLfxFONBTgeEHympoUwGCPkIqbVnDM=str
lLfxFONBTgeEHympoUwGCPkIqbVnDW=True
lLfxFONBTgeEHympoUwGCPkIqbVnDS=Exception
lLfxFONBTgeEHympoUwGCPkIqbVnDr=int
lLfxFONBTgeEHympoUwGCPkIqbVnDX=len
lLfxFONBTgeEHympoUwGCPkIqbVnDt=range
import urllib
import re
import json
import sys
import time
import requests
import datetime
import base64
lLfxFONBTgeEHympoUwGCPkIqbVndY={'stream50':1080,'stream40':720,'stream30':540}
lLfxFONBTgeEHympoUwGCPkIqbVndQ=[{'name':'NOW','videoId':'ch_spotvnow1','epgtype':'spotvon','epgnm':'spotvon','free':lLfxFONBTgeEHympoUwGCPkIqbVnDz,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/ccdb36ce757afc1ca15fc38357d498e4.png'},{'name':'NOW2','videoId':'ch_spotvnow2','epgtype':'spotvon','epgnm':'spotvon2','free':lLfxFONBTgeEHympoUwGCPkIqbVnDz,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/8b6bdf6213a715eeba719b2cb9b2c747.png'},{'name':'NBA TV','videoId':'ch_nbatv','epgtype':'-','epgnm':'-','free':lLfxFONBTgeEHympoUwGCPkIqbVnDz,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/5036e56d5c6594ea606f7159f59779fe.png'},{'name':'SPOTV','videoId':'ch_spotv','epgtype':'spotvnet','epgnm':'SPOTV','free':lLfxFONBTgeEHympoUwGCPkIqbVnDz,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/56688c2e527c6e1b8d68e338057a7dfc.png'},{'name':'SPOTV2','videoId':'ch_spotv2','epgtype':'spotvnet','epgnm':'SPOTV2','free':lLfxFONBTgeEHympoUwGCPkIqbVnDz,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20201209/ca6e7a213c84e629985e609ddcda6b17.png'},{'name':'SPOTV Golf & Health','videoId':'ch_spotvplus','epgtype':'spotvnet','epgnm':'SPOTVP','free':lLfxFONBTgeEHympoUwGCPkIqbVnDz,'logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200824/7aa87953f1211313c3e110cace2628ff.png'},]
lLfxFONBTgeEHympoUwGCPkIqbVndD={'ch_spotvnow1':{'lv':'abf18bbf3b3f4a0db4a41dd2af7f75c6','rv':'__nn__=5981484117001&hdnea=st=1609407000~exp=1609410600~acl=/abf18bbf3b3f4a0db4a41dd2af7f75c6/ap-northeast-1/5764318566001/*~hmac=e28a244d1b6b77d4e0101010816d4cd6ca89d9d31fe6a5290039d2395d81bc03'},'ch_spotvnow2':{'lv':'3054522000fc4d60aabe23d6e5911275','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/3054522000fc4d60aabe23d6e5911275/ap-northeast-1/5764318566001/*~hmac=323b2deea8e3455fa77405f37b19231c6f0b48a5690b7218df875171ac2d6be6'},'ch_nbatv':{'lv':'31f99a0a6067413ea1b390c41a5c12be','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/31f99a0a6067413ea1b390c41a5c12be/ap-northeast-1/5764318566001/*~hmac=b7ac24bc4772e3ad2669000919058bba64a6f001c69c8846341c326b089c306c'},'ch_spotv':{'lv':'1f2651c2fea34be9850bfdedf8d9cfdb','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/1f2651c2fea34be9850bfdedf8d9cfdb/ap-northeast-1/5764318566001/*~hmac=e1f6c44d1be5459cfc40af1e1b204ac9b513bb7405e070da2bff8f115f298133'},'ch_spotv2':{'lv':'7bf3fb8685854892b01e1fc897e7e9b0','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/7bf3fb8685854892b01e1fc897e7e9b0/ap-northeast-1/5764318566001/*~hmac=e9bb30991cfab98b1976aacabafcd51b63769ede40148f7cc289ffed15398e81'},'ch_spotvplus':{'lv':'242b2b6c0c654f47a07f4e2420f9c184','rv':'__nn__=5981484117001&hdnea=st=1609408800~exp=1609412400~acl=/242b2b6c0c654f47a07f4e2420f9c184/ap-northeast-1/5764318566001/*~hmac=5e4ce0553e709eb60d880bf37bc2e99661767b0a38ecee037fb4d7dce757b922'},}
class lLfxFONBTgeEHympoUwGCPkIqbVndv(lLfxFONBTgeEHympoUwGCPkIqbVnDh):
 def __init__(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SESSIONID=''
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SESSION =''
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_ACCOUNTID=''
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_POLICYKEY=''
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SUBEND =''
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_PMCODE ='987'
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_PMSIZE =3
  lLfxFONBTgeEHympoUwGCPkIqbVnda.GAMELIST_LIMIT =10
  lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN ='https://www.spotvnow.co.kr'
  lLfxFONBTgeEHympoUwGCPkIqbVnda.BC_DOMAIN ='https://players.brightcove.net'
  lLfxFONBTgeEHympoUwGCPkIqbVnda.PLAYER_DOMAIN ='https://edge.api.brightcove.com'
  lLfxFONBTgeEHympoUwGCPkIqbVnda.STREAM_DOMAIN ='https://gtm-spotv.brightcovecdn.com'
  lLfxFONBTgeEHympoUwGCPkIqbVnda.STREAM_M3U8 ='ap-northeast-1/5764318566001/playlist_dvr'
  lLfxFONBTgeEHympoUwGCPkIqbVnda.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  lLfxFONBTgeEHympoUwGCPkIqbVnda.DEFAULT_HEADER ={'user-agent':lLfxFONBTgeEHympoUwGCPkIqbVnda.USER_AGENT}
 def callRequestCookies(lLfxFONBTgeEHympoUwGCPkIqbVnda,jobtype,lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR,redirects=lLfxFONBTgeEHympoUwGCPkIqbVnDz):
  lLfxFONBTgeEHympoUwGCPkIqbVndu=lLfxFONBTgeEHympoUwGCPkIqbVnda.DEFAULT_HEADER
  if headers:lLfxFONBTgeEHympoUwGCPkIqbVndu.update(headers)
  if jobtype=='Get':
   lLfxFONBTgeEHympoUwGCPkIqbVndJ=requests.get(lLfxFONBTgeEHympoUwGCPkIqbVnvA,params=params,headers=lLfxFONBTgeEHympoUwGCPkIqbVndu,cookies=cookies,allow_redirects=redirects)
  else:
   lLfxFONBTgeEHympoUwGCPkIqbVndJ=requests.post(lLfxFONBTgeEHympoUwGCPkIqbVnvA,data=payload,params=params,headers=lLfxFONBTgeEHympoUwGCPkIqbVndu,cookies=cookies,allow_redirects=redirects)
  return lLfxFONBTgeEHympoUwGCPkIqbVndJ
 def makeDefaultCookies(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVndA={'SESSION':lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SESSION}
  return lLfxFONBTgeEHympoUwGCPkIqbVndA
 def xmlText(lLfxFONBTgeEHympoUwGCPkIqbVnda,in_text):
  lLfxFONBTgeEHympoUwGCPkIqbVndi=in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
  return lLfxFONBTgeEHympoUwGCPkIqbVndi
 def GetCredential(lLfxFONBTgeEHympoUwGCPkIqbVnda,user_id,user_pw):
  lLfxFONBTgeEHympoUwGCPkIqbVndj=lLfxFONBTgeEHympoUwGCPkIqbVnDz
  lLfxFONBTgeEHympoUwGCPkIqbVnds=lLfxFONBTgeEHympoUwGCPkIqbVndW=lLfxFONBTgeEHympoUwGCPkIqbVndX=lLfxFONBTgeEHympoUwGCPkIqbVndt=lLfxFONBTgeEHympoUwGCPkIqbVndr=''
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVndc=base64.standard_b64encode(user_id.encode("UTF-8")).decode('utf-8')
   lLfxFONBTgeEHympoUwGCPkIqbVndz=base64.standard_b64encode(user_pw.encode("UTF-8")).decode('utf-8')
   lLfxFONBTgeEHympoUwGCPkIqbVndh=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/login'
   lLfxFONBTgeEHympoUwGCPkIqbVndR={'username':lLfxFONBTgeEHympoUwGCPkIqbVndc,'password':lLfxFONBTgeEHympoUwGCPkIqbVndz}
   lLfxFONBTgeEHympoUwGCPkIqbVndR=json.dumps(lLfxFONBTgeEHympoUwGCPkIqbVndR)
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Post',lLfxFONBTgeEHympoUwGCPkIqbVndh,payload=lLfxFONBTgeEHympoUwGCPkIqbVndR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(lLfxFONBTgeEHympoUwGCPkIqbVndK.status_code)
   for lLfxFONBTgeEHympoUwGCPkIqbVndM in lLfxFONBTgeEHympoUwGCPkIqbVndK.cookies:
    if lLfxFONBTgeEHympoUwGCPkIqbVndM.name=='SESSION':
     lLfxFONBTgeEHympoUwGCPkIqbVndW=lLfxFONBTgeEHympoUwGCPkIqbVndM.value
     break
   if lLfxFONBTgeEHympoUwGCPkIqbVndW=='':return lLfxFONBTgeEHympoUwGCPkIqbVndj
   lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   if not('userId' in lLfxFONBTgeEHympoUwGCPkIqbVndS):return lLfxFONBTgeEHympoUwGCPkIqbVndj
   lLfxFONBTgeEHympoUwGCPkIqbVnds=lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVndS['userId'])
   lLfxFONBTgeEHympoUwGCPkIqbVndr =lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVndS['subEndTime'])
   lLfxFONBTgeEHympoUwGCPkIqbVndX,lLfxFONBTgeEHympoUwGCPkIqbVndt=lLfxFONBTgeEHympoUwGCPkIqbVnda.GetPolicyKey()
   if lLfxFONBTgeEHympoUwGCPkIqbVndt=='':return lLfxFONBTgeEHympoUwGCPkIqbVndj
   lLfxFONBTgeEHympoUwGCPkIqbVndj=lLfxFONBTgeEHympoUwGCPkIqbVnDW
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnds=lLfxFONBTgeEHympoUwGCPkIqbVndW='' 
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  lLfxFONBTgeEHympoUwGCPkIqbVnvd={'spotv_sessionid':lLfxFONBTgeEHympoUwGCPkIqbVnds,'spotv_session':lLfxFONBTgeEHympoUwGCPkIqbVndW,'spotv_accountId':lLfxFONBTgeEHympoUwGCPkIqbVndX,'spotv_policyKey':lLfxFONBTgeEHympoUwGCPkIqbVndt,'spotv_subend':lLfxFONBTgeEHympoUwGCPkIqbVndr}
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SaveCredential(lLfxFONBTgeEHympoUwGCPkIqbVnvd)
  return lLfxFONBTgeEHympoUwGCPkIqbVndj
 def SaveCredential(lLfxFONBTgeEHympoUwGCPkIqbVnda,lLfxFONBTgeEHympoUwGCPkIqbVnvd):
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SESSIONID=lLfxFONBTgeEHympoUwGCPkIqbVnvd.get('spotv_sessionid')
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SESSION =lLfxFONBTgeEHympoUwGCPkIqbVnvd.get('spotv_session')
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_ACCOUNTID=lLfxFONBTgeEHympoUwGCPkIqbVnvd.get('spotv_accountId')
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_POLICYKEY=lLfxFONBTgeEHympoUwGCPkIqbVnvd.get('spotv_policyKey')
  lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SUBEND =lLfxFONBTgeEHympoUwGCPkIqbVnvd.get('spotv_subend')
 def LoadCredential(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnvd={'spotv_sessionid':lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SESSIONID,'spotv_session':lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SESSION,'spotv_accountId':lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_ACCOUNTID,'spotv_policyKey':lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_POLICYKEY,'spotv_subend':lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SUBEND}
  return lLfxFONBTgeEHympoUwGCPkIqbVnvd
 def Get_Now_Datetime(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def Get_Streamurl_Make(lLfxFONBTgeEHympoUwGCPkIqbVnda,lLfxFONBTgeEHympoUwGCPkIqbVnYJ):
  lLfxFONBTgeEHympoUwGCPkIqbVnvQ='%s/%s/%s.m3u8?%s'%(lLfxFONBTgeEHympoUwGCPkIqbVnda.STREAM_DOMAIN,lLfxFONBTgeEHympoUwGCPkIqbVndD.get(lLfxFONBTgeEHympoUwGCPkIqbVnYJ).get('lv'),lLfxFONBTgeEHympoUwGCPkIqbVnda.STREAM_M3U8,lLfxFONBTgeEHympoUwGCPkIqbVndD.get(lLfxFONBTgeEHympoUwGCPkIqbVnYJ).get('rv'))
  return lLfxFONBTgeEHympoUwGCPkIqbVnvQ
 def GetLiveChannelList(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnvD=[]
  lLfxFONBTgeEHympoUwGCPkIqbVnva ={}
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnva=lLfxFONBTgeEHympoUwGCPkIqbVnda.GetEPGList_new()
   for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVndQ:
    lLfxFONBTgeEHympoUwGCPkIqbVnvJ={'name':lLfxFONBTgeEHympoUwGCPkIqbVnvu['name'],'logo':lLfxFONBTgeEHympoUwGCPkIqbVnvu['logo'],'videoId':lLfxFONBTgeEHympoUwGCPkIqbVnvu['videoId'],'free':lLfxFONBTgeEHympoUwGCPkIqbVnvu['free'],'channelepg':lLfxFONBTgeEHympoUwGCPkIqbVnva.get(lLfxFONBTgeEHympoUwGCPkIqbVnvu['videoId'])}
    lLfxFONBTgeEHympoUwGCPkIqbVnvD.append(lLfxFONBTgeEHympoUwGCPkIqbVnvJ)
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnvD
 def CheckLiveChannel(lLfxFONBTgeEHympoUwGCPkIqbVnda,lLfxFONBTgeEHympoUwGCPkIqbVnvS):
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/channel'
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVndS:
    if lLfxFONBTgeEHympoUwGCPkIqbVnvu['videoId'].replace('ref:','')==lLfxFONBTgeEHympoUwGCPkIqbVnvS:
     return lLfxFONBTgeEHympoUwGCPkIqbVnvu['free']
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnDz
 def GetEPGList(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnvi={}
  lLfxFONBTgeEHympoUwGCPkIqbVnvj=lLfxFONBTgeEHympoUwGCPkIqbVnda.Get_Now_Datetime()
  lLfxFONBTgeEHympoUwGCPkIqbVnvs=lLfxFONBTgeEHympoUwGCPkIqbVnvj.strftime('%Y%m%d%H%M')
  lLfxFONBTgeEHympoUwGCPkIqbVnvc='%s-%s-%s'%(lLfxFONBTgeEHympoUwGCPkIqbVnvs[0:4],lLfxFONBTgeEHympoUwGCPkIqbVnvs[4:6],lLfxFONBTgeEHympoUwGCPkIqbVnvs[6:8])
  lLfxFONBTgeEHympoUwGCPkIqbVnvz=(lLfxFONBTgeEHympoUwGCPkIqbVnvj+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M')
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/program/'+lLfxFONBTgeEHympoUwGCPkIqbVnvc
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   lLfxFONBTgeEHympoUwGCPkIqbVnvh=-1 
   lLfxFONBTgeEHympoUwGCPkIqbVnvR =''
   for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVndS:
    lLfxFONBTgeEHympoUwGCPkIqbVnvK=lLfxFONBTgeEHympoUwGCPkIqbVnvu['channelId']
    lLfxFONBTgeEHympoUwGCPkIqbVnvM =lLfxFONBTgeEHympoUwGCPkIqbVnvu['startTime'].replace('-','').replace(' ','').replace(':','')
    lLfxFONBTgeEHympoUwGCPkIqbVnvW =lLfxFONBTgeEHympoUwGCPkIqbVnvu['endTime'].replace('-','').replace(' ','').replace(':','')
    if lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvs)>lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvW) :continue
    if lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvz)<lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvM):continue
    if lLfxFONBTgeEHympoUwGCPkIqbVnvh!=lLfxFONBTgeEHympoUwGCPkIqbVnvK:
     if lLfxFONBTgeEHympoUwGCPkIqbVnvR!='':lLfxFONBTgeEHympoUwGCPkIqbVnvi[lLfxFONBTgeEHympoUwGCPkIqbVnvh]=lLfxFONBTgeEHympoUwGCPkIqbVnvR
     lLfxFONBTgeEHympoUwGCPkIqbVnvh=lLfxFONBTgeEHympoUwGCPkIqbVnvK
     lLfxFONBTgeEHympoUwGCPkIqbVnvR =''
    if lLfxFONBTgeEHympoUwGCPkIqbVnvR:lLfxFONBTgeEHympoUwGCPkIqbVnvR+='\n'
    lLfxFONBTgeEHympoUwGCPkIqbVnvR+=lLfxFONBTgeEHympoUwGCPkIqbVnvu['title']+'\n'
    lLfxFONBTgeEHympoUwGCPkIqbVnvR+=' [%s ~ %s]'%(lLfxFONBTgeEHympoUwGCPkIqbVnvu['startTime'][-5:],lLfxFONBTgeEHympoUwGCPkIqbVnvu['endTime'][-5:])+'\n'
   if lLfxFONBTgeEHympoUwGCPkIqbVnvR:lLfxFONBTgeEHympoUwGCPkIqbVnvi[lLfxFONBTgeEHympoUwGCPkIqbVnvh]=lLfxFONBTgeEHympoUwGCPkIqbVnvR
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnvi
 def GetEPGList_new(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnvi={}
  lLfxFONBTgeEHympoUwGCPkIqbVnvj=lLfxFONBTgeEHympoUwGCPkIqbVnda.Get_Now_Datetime()
  lLfxFONBTgeEHympoUwGCPkIqbVnvs=lLfxFONBTgeEHympoUwGCPkIqbVnvj.strftime('%Y%m%d%H%M00')
  lLfxFONBTgeEHympoUwGCPkIqbVnvc='%s%s%s'%(lLfxFONBTgeEHympoUwGCPkIqbVnvs[0:4],lLfxFONBTgeEHympoUwGCPkIqbVnvs[4:6],lLfxFONBTgeEHympoUwGCPkIqbVnvs[6:8])
  lLfxFONBTgeEHympoUwGCPkIqbVnvz=(lLfxFONBTgeEHympoUwGCPkIqbVnvj+datetime.timedelta(hours=4)).strftime('%Y%m%d%H%M00')
  try:
   for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVndQ:
    lLfxFONBTgeEHympoUwGCPkIqbVnvS =lLfxFONBTgeEHympoUwGCPkIqbVnvu['videoId']
    if lLfxFONBTgeEHympoUwGCPkIqbVnvu['epgtype']=='spotvon':
     lLfxFONBTgeEHympoUwGCPkIqbVnvR=lLfxFONBTgeEHympoUwGCPkIqbVnda.Get_EpgInfo_Spotv_spotvon(lLfxFONBTgeEHympoUwGCPkIqbVnvS,lLfxFONBTgeEHympoUwGCPkIqbVnvu['epgnm'],lLfxFONBTgeEHympoUwGCPkIqbVnvc)
     lLfxFONBTgeEHympoUwGCPkIqbVnvi[lLfxFONBTgeEHympoUwGCPkIqbVnvS]=lLfxFONBTgeEHympoUwGCPkIqbVnvR
    if lLfxFONBTgeEHympoUwGCPkIqbVnvu['epgtype']=='spotvnet':
     lLfxFONBTgeEHympoUwGCPkIqbVnvR=lLfxFONBTgeEHympoUwGCPkIqbVnda.Get_EpgInfo_Spotv_spotvnet(lLfxFONBTgeEHympoUwGCPkIqbVnvS,lLfxFONBTgeEHympoUwGCPkIqbVnvu['epgnm'],lLfxFONBTgeEHympoUwGCPkIqbVnvc)
     lLfxFONBTgeEHympoUwGCPkIqbVnvi[lLfxFONBTgeEHympoUwGCPkIqbVnvS]=lLfxFONBTgeEHympoUwGCPkIqbVnvR
   for lLfxFONBTgeEHympoUwGCPkIqbVnvr in lLfxFONBTgeEHympoUwGCPkIqbVnvi.keys():
    if lLfxFONBTgeEHympoUwGCPkIqbVnDX(lLfxFONBTgeEHympoUwGCPkIqbVnvi.get(lLfxFONBTgeEHympoUwGCPkIqbVnvr))==0:continue
    lLfxFONBTgeEHympoUwGCPkIqbVnvR =''
    lLfxFONBTgeEHympoUwGCPkIqbVnvX=''
    for lLfxFONBTgeEHympoUwGCPkIqbVnvt in lLfxFONBTgeEHympoUwGCPkIqbVnvi.get(lLfxFONBTgeEHympoUwGCPkIqbVnvr):
     lLfxFONBTgeEHympoUwGCPkIqbVnvM =lLfxFONBTgeEHympoUwGCPkIqbVnvt['startTime']
     lLfxFONBTgeEHympoUwGCPkIqbVnvW =lLfxFONBTgeEHympoUwGCPkIqbVnvt['endTime']
     if lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvs)>lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvW) :continue
     if lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvz)<lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvM):continue
     if lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvs)>=lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvM)and lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvs)<lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvW):lLfxFONBTgeEHympoUwGCPkIqbVnvX=lLfxFONBTgeEHympoUwGCPkIqbVnda.xmlText(lLfxFONBTgeEHympoUwGCPkIqbVnvt['title'])
     if lLfxFONBTgeEHympoUwGCPkIqbVnvR:lLfxFONBTgeEHympoUwGCPkIqbVnvR+='\n'
     lLfxFONBTgeEHympoUwGCPkIqbVnvR+=lLfxFONBTgeEHympoUwGCPkIqbVnda.xmlText(lLfxFONBTgeEHympoUwGCPkIqbVnvt['title'])+'\n'
     lLfxFONBTgeEHympoUwGCPkIqbVnvR+=' [%s:%s ~ %s:%s]'%(lLfxFONBTgeEHympoUwGCPkIqbVnvt['startTime'][8:10],lLfxFONBTgeEHympoUwGCPkIqbVnvt['startTime'][10:12],lLfxFONBTgeEHympoUwGCPkIqbVnvt['endTime'][8:10],lLfxFONBTgeEHympoUwGCPkIqbVnvt['endTime'][10:12])+'\n'
    lLfxFONBTgeEHympoUwGCPkIqbVnvi[lLfxFONBTgeEHympoUwGCPkIqbVnvr]={'epg':lLfxFONBTgeEHympoUwGCPkIqbVnvR,'title':lLfxFONBTgeEHympoUwGCPkIqbVnvX}
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnvi
 def Get_EpgInfo_Spotv_spotvon(lLfxFONBTgeEHympoUwGCPkIqbVnda,lLfxFONBTgeEHympoUwGCPkIqbVnvS,epgnm,now_day):
  lLfxFONBTgeEHympoUwGCPkIqbVnvi =[]
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA='https://www.spotvon.co.kr/data/onAir/%s/Daily/D%s.asp'%(epgnm,now_day)
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVnYd=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVnYd:
    lLfxFONBTgeEHympoUwGCPkIqbVnvJ={'title':lLfxFONBTgeEHympoUwGCPkIqbVnvu['title'],'startTime':lLfxFONBTgeEHympoUwGCPkIqbVnvu['sch_date'].replace('-','')+lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnvu['sch_hour']).zfill(2)+lLfxFONBTgeEHympoUwGCPkIqbVnvu['sch_min']+'00'}
    lLfxFONBTgeEHympoUwGCPkIqbVnvi.append(lLfxFONBTgeEHympoUwGCPkIqbVnvJ)
   for i in lLfxFONBTgeEHympoUwGCPkIqbVnDt(lLfxFONBTgeEHympoUwGCPkIqbVnDX(lLfxFONBTgeEHympoUwGCPkIqbVnvi)):
    if i>0:lLfxFONBTgeEHympoUwGCPkIqbVnvi[i-1]['endTime']=lLfxFONBTgeEHympoUwGCPkIqbVnvi[i]['startTime']
    if i==lLfxFONBTgeEHympoUwGCPkIqbVnDX(lLfxFONBTgeEHympoUwGCPkIqbVnvi)-1: lLfxFONBTgeEHympoUwGCPkIqbVnvi[i]['endTime']=now_day+'240000'
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
   return[]
  return lLfxFONBTgeEHympoUwGCPkIqbVnvi
 def Get_EpgInfo_Spotv_spotvnet(lLfxFONBTgeEHympoUwGCPkIqbVnda,lLfxFONBTgeEHympoUwGCPkIqbVnvS,epgnm,now_day):
  lLfxFONBTgeEHympoUwGCPkIqbVnvi =[]
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA='https://www.spotv.net/data/json/schedule/%s/Daily/D%s.json'%(epgnm,now_day)
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVnYd=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVnYd:
    lLfxFONBTgeEHympoUwGCPkIqbVnvJ={'title':lLfxFONBTgeEHympoUwGCPkIqbVnvu['title'],'startTime':lLfxFONBTgeEHympoUwGCPkIqbVnvu['sch_date'].replace('-','')+lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnvu['sch_hour']).zfill(2)+lLfxFONBTgeEHympoUwGCPkIqbVnvu['sch_min']+'00'}
    lLfxFONBTgeEHympoUwGCPkIqbVnvi.append(lLfxFONBTgeEHympoUwGCPkIqbVnvJ)
   for i in lLfxFONBTgeEHympoUwGCPkIqbVnDt(lLfxFONBTgeEHympoUwGCPkIqbVnDX(lLfxFONBTgeEHympoUwGCPkIqbVnvi)):
    if i>0:lLfxFONBTgeEHympoUwGCPkIqbVnvi[i-1]['endTime']=lLfxFONBTgeEHympoUwGCPkIqbVnvi[i]['startTime']
    if i==lLfxFONBTgeEHympoUwGCPkIqbVnDX(lLfxFONBTgeEHympoUwGCPkIqbVnvi)-1: lLfxFONBTgeEHympoUwGCPkIqbVnvi[i]['endTime']=now_day+'240000'
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
   return[]
  return lLfxFONBTgeEHympoUwGCPkIqbVnvi
 def GetEventLiveList(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnvD=[]
  lLfxFONBTgeEHympoUwGCPkIqbVnYv =0
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnYQ=lLfxFONBTgeEHympoUwGCPkIqbVnda.Get_Now_Datetime()
   lLfxFONBTgeEHympoUwGCPkIqbVnYD=lLfxFONBTgeEHympoUwGCPkIqbVnYQ.strftime('%Y-%m-%d')
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
   return lLfxFONBTgeEHympoUwGCPkIqbVnvD,lLfxFONBTgeEHympoUwGCPkIqbVnYv
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/player/lives/'+lLfxFONBTgeEHympoUwGCPkIqbVnYD 
   lLfxFONBTgeEHympoUwGCPkIqbVndA=lLfxFONBTgeEHympoUwGCPkIqbVnda.makeDefaultCookies()
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVndA)
   lLfxFONBTgeEHympoUwGCPkIqbVnYv=lLfxFONBTgeEHympoUwGCPkIqbVndK.status_code 
   lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   for lLfxFONBTgeEHympoUwGCPkIqbVnYa in lLfxFONBTgeEHympoUwGCPkIqbVndS:
    for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVnYa['liveNowList']:
     if lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['title']==lLfxFONBTgeEHympoUwGCPkIqbVnDR or lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['title']=='':
      lLfxFONBTgeEHympoUwGCPkIqbVnYu='%s ( %s : %s )'%(lLfxFONBTgeEHympoUwGCPkIqbVnvu['leagueName'],lLfxFONBTgeEHympoUwGCPkIqbVnvu['homeNameShort'],lLfxFONBTgeEHympoUwGCPkIqbVnvu['awayNameShort'])
     else:
      lLfxFONBTgeEHympoUwGCPkIqbVnYu=lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['title']
     lLfxFONBTgeEHympoUwGCPkIqbVnvJ={'liveId':lLfxFONBTgeEHympoUwGCPkIqbVnvu['liveId'],'title':lLfxFONBTgeEHympoUwGCPkIqbVnYu,'logo':lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['leagueLogo'],'free':lLfxFONBTgeEHympoUwGCPkIqbVnvu['isFree'],'startTime':lLfxFONBTgeEHympoUwGCPkIqbVnvu['startTime']}
     lLfxFONBTgeEHympoUwGCPkIqbVnvD.append(lLfxFONBTgeEHympoUwGCPkIqbVnvJ)
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnvD,lLfxFONBTgeEHympoUwGCPkIqbVnYv
 def GetEventLive_videoId(lLfxFONBTgeEHympoUwGCPkIqbVnda,liveId):
  lLfxFONBTgeEHympoUwGCPkIqbVnYJ=''
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/live/'+liveId
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   lLfxFONBTgeEHympoUwGCPkIqbVnYA=lLfxFONBTgeEHympoUwGCPkIqbVndS['videoId']
   lLfxFONBTgeEHympoUwGCPkIqbVnYJ=lLfxFONBTgeEHympoUwGCPkIqbVnYA.replace('ref:','')
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnYJ
 def CheckMainEnd(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnYi=base64.standard_b64encode((lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_PMCODE+lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SESSIONID).encode()).decode('utf-8')
  if lLfxFONBTgeEHympoUwGCPkIqbVnYi=='OTg3MTgzMzM0Ng==' or lLfxFONBTgeEHympoUwGCPkIqbVnYi=='OTg3MTgzMzExNw==':return lLfxFONBTgeEHympoUwGCPkIqbVnDW
  return lLfxFONBTgeEHympoUwGCPkIqbVnDz
 def CheckSubEnd(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnYj=lLfxFONBTgeEHympoUwGCPkIqbVnDz
  try:
   if lLfxFONBTgeEHympoUwGCPkIqbVnda.CheckMainEnd():return lLfxFONBTgeEHympoUwGCPkIqbVnDW 
   if lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SUBEND=='0':return lLfxFONBTgeEHympoUwGCPkIqbVnYj
   lLfxFONBTgeEHympoUwGCPkIqbVnYs =lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnda.Get_Now_Datetime().strftime('%Y%m%d'))
   lLfxFONBTgeEHympoUwGCPkIqbVnYc =lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_SUBEND)/1000
   lLfxFONBTgeEHympoUwGCPkIqbVnYz =lLfxFONBTgeEHympoUwGCPkIqbVnDr(datetime.datetime.fromtimestamp(lLfxFONBTgeEHympoUwGCPkIqbVnYc,datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y%m%d'))
   if lLfxFONBTgeEHympoUwGCPkIqbVnYs<=lLfxFONBTgeEHympoUwGCPkIqbVnYz:lLfxFONBTgeEHympoUwGCPkIqbVnYj=lLfxFONBTgeEHympoUwGCPkIqbVnDW
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
   return lLfxFONBTgeEHympoUwGCPkIqbVnYj
  return lLfxFONBTgeEHympoUwGCPkIqbVnYj
 def GetMainJspath(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnYh=''
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVnYR=lLfxFONBTgeEHympoUwGCPkIqbVndK.text
   lLfxFONBTgeEHympoUwGCPkIqbVnYK =re.findall('https://cdn.spotvnow.co.kr/dist/js/.{20}\.js',lLfxFONBTgeEHympoUwGCPkIqbVnYR)[0]
   lLfxFONBTgeEHympoUwGCPkIqbVnYh=lLfxFONBTgeEHympoUwGCPkIqbVnYK
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnYh
 def GetBcPlayerUrl(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnYM=''
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.GetMainJspath()
   if lLfxFONBTgeEHympoUwGCPkIqbVnvA=='':return lLfxFONBTgeEHympoUwGCPkIqbVnYM
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVnYR=lLfxFONBTgeEHympoUwGCPkIqbVndK.text
   lLfxFONBTgeEHympoUwGCPkIqbVnYW =re.findall('bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"',lLfxFONBTgeEHympoUwGCPkIqbVnYR)[0]
   lLfxFONBTgeEHympoUwGCPkIqbVnYW =lLfxFONBTgeEHympoUwGCPkIqbVnYW.replace('bc','"bc"')
   lLfxFONBTgeEHympoUwGCPkIqbVnYW =lLfxFONBTgeEHympoUwGCPkIqbVnYW.replace('player','"player"')
   lLfxFONBTgeEHympoUwGCPkIqbVnYW ='{'+lLfxFONBTgeEHympoUwGCPkIqbVnYW+'}'
   lLfxFONBTgeEHympoUwGCPkIqbVnYW =json.loads(lLfxFONBTgeEHympoUwGCPkIqbVnYW)
   bc =lLfxFONBTgeEHympoUwGCPkIqbVnYW['bc']
   lLfxFONBTgeEHympoUwGCPkIqbVnYS =lLfxFONBTgeEHympoUwGCPkIqbVnYW['player']
   lLfxFONBTgeEHympoUwGCPkIqbVnYM="%s/%s/%s_default/index.min.js"%(lLfxFONBTgeEHympoUwGCPkIqbVnda.BC_DOMAIN,bc,lLfxFONBTgeEHympoUwGCPkIqbVnYS)
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnYM
 def GetPolicyKey(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnYr=policykey=''
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.GetBcPlayerUrl()
   if lLfxFONBTgeEHympoUwGCPkIqbVnvA=='':return lLfxFONBTgeEHympoUwGCPkIqbVnYr,lLfxFONBTgeEHympoUwGCPkIqbVnYt
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVnYR=lLfxFONBTgeEHympoUwGCPkIqbVndK.text
   lLfxFONBTgeEHympoUwGCPkIqbVnYK =re.findall('accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"',lLfxFONBTgeEHympoUwGCPkIqbVnYR)[0]
   lLfxFONBTgeEHympoUwGCPkIqbVnYK =lLfxFONBTgeEHympoUwGCPkIqbVnYK.replace('accountId','"accountId"')
   lLfxFONBTgeEHympoUwGCPkIqbVnYK =lLfxFONBTgeEHympoUwGCPkIqbVnYK.replace('policyKey','"policyKey"')
   lLfxFONBTgeEHympoUwGCPkIqbVnYK ='{'+lLfxFONBTgeEHympoUwGCPkIqbVnYK+'}'
   lLfxFONBTgeEHympoUwGCPkIqbVnYX=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVnYK)
   lLfxFONBTgeEHympoUwGCPkIqbVnYr =lLfxFONBTgeEHympoUwGCPkIqbVnYX['accountId']
   lLfxFONBTgeEHympoUwGCPkIqbVnYt =lLfxFONBTgeEHympoUwGCPkIqbVnYX['policyKey']
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnYr,lLfxFONBTgeEHympoUwGCPkIqbVnYt
 def GetBroadURL(lLfxFONBTgeEHympoUwGCPkIqbVnda,lLfxFONBTgeEHympoUwGCPkIqbVnYJ,mediatype,lLfxFONBTgeEHympoUwGCPkIqbVnQs):
  lLfxFONBTgeEHympoUwGCPkIqbVnQd=''
  try:
   if mediatype=='live':
    lLfxFONBTgeEHympoUwGCPkIqbVnYJ='ref%3A'+lLfxFONBTgeEHympoUwGCPkIqbVnYJ
   else:
    lLfxFONBTgeEHympoUwGCPkIqbVnYJ=lLfxFONBTgeEHympoUwGCPkIqbVnda.GetReplay_UrlId(lLfxFONBTgeEHympoUwGCPkIqbVnYJ,lLfxFONBTgeEHympoUwGCPkIqbVnQs)
    if lLfxFONBTgeEHympoUwGCPkIqbVnYJ=='':return lLfxFONBTgeEHympoUwGCPkIqbVnQd
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.PLAYER_DOMAIN+'/playback/v1/accounts/'+lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_ACCOUNTID+'/videos/'+lLfxFONBTgeEHympoUwGCPkIqbVnYJ
   lLfxFONBTgeEHympoUwGCPkIqbVnQv={'accept':'application/json;pk='+lLfxFONBTgeEHympoUwGCPkIqbVnda.SPOTV_POLICYKEY}
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnQv,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVnYd=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   lLfxFONBTgeEHympoUwGCPkIqbVnQd=lLfxFONBTgeEHympoUwGCPkIqbVnYd['sources'][0]['src']
   if mediatype=='live':
    lLfxFONBTgeEHympoUwGCPkIqbVnQd=lLfxFONBTgeEHympoUwGCPkIqbVnQd.replace('playlist.m3u8','playlist_dvr.m3u8')
   lLfxFONBTgeEHympoUwGCPkIqbVnQd=lLfxFONBTgeEHympoUwGCPkIqbVnQd.replace('http://','https://')
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnQd
 def GetTitleGroupList(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnvD=[]
  lLfxFONBTgeEHympoUwGCPkIqbVnQY=lLfxFONBTgeEHympoUwGCPkIqbVnDz
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/home/web'
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVndS:
    if lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnvu['type'])=='3':
     lLfxFONBTgeEHympoUwGCPkIqbVnQD=''
     for lLfxFONBTgeEHympoUwGCPkIqbVnQa in lLfxFONBTgeEHympoUwGCPkIqbVnvu['data']['list']:
      lLfxFONBTgeEHympoUwGCPkIqbVnQu='[%s] %s vs %s\n<%s>\n\n'%(lLfxFONBTgeEHympoUwGCPkIqbVnQa['gameDesc']['roundName'],lLfxFONBTgeEHympoUwGCPkIqbVnQa['gameDesc']['homeNameShort'],lLfxFONBTgeEHympoUwGCPkIqbVnQa['gameDesc']['awayNameShort'],lLfxFONBTgeEHympoUwGCPkIqbVnQa['gameDesc']['beginDate'])
      lLfxFONBTgeEHympoUwGCPkIqbVnQD+=lLfxFONBTgeEHympoUwGCPkIqbVnQu
     lLfxFONBTgeEHympoUwGCPkIqbVnvJ={'title':lLfxFONBTgeEHympoUwGCPkIqbVnvu['title'],'logo':lLfxFONBTgeEHympoUwGCPkIqbVnvu['logo'],'reagueId':lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnvu['destId']),'subGame':lLfxFONBTgeEHympoUwGCPkIqbVnQD}
     lLfxFONBTgeEHympoUwGCPkIqbVnvD.append(lLfxFONBTgeEHympoUwGCPkIqbVnvJ)
     if lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnvu['destId'])=='13':lLfxFONBTgeEHympoUwGCPkIqbVnQY=lLfxFONBTgeEHympoUwGCPkIqbVnDW
   if lLfxFONBTgeEHympoUwGCPkIqbVnQY==lLfxFONBTgeEHympoUwGCPkIqbVnDz:
    lLfxFONBTgeEHympoUwGCPkIqbVnvJ={'title':'UFC','logo':'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png','reagueId':'13','subGame':''}
    lLfxFONBTgeEHympoUwGCPkIqbVnvD.append(lLfxFONBTgeEHympoUwGCPkIqbVnvJ)
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnvD
 def GetPopularGroupList(lLfxFONBTgeEHympoUwGCPkIqbVnda):
  lLfxFONBTgeEHympoUwGCPkIqbVnvD=[]
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/home/web'
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVndS:
    if lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnvu['type'])=='1' and lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnvu['destId'])=='4':
     for lLfxFONBTgeEHympoUwGCPkIqbVnQa in lLfxFONBTgeEHympoUwGCPkIqbVnvu['data']['list']:
      lLfxFONBTgeEHympoUwGCPkIqbVnQJ =lLfxFONBTgeEHympoUwGCPkIqbVnQa['title']
      lLfxFONBTgeEHympoUwGCPkIqbVnQA =lLfxFONBTgeEHympoUwGCPkIqbVnQa['id']
      lLfxFONBTgeEHympoUwGCPkIqbVnQi =lLfxFONBTgeEHympoUwGCPkIqbVnQa['vtype']
      lLfxFONBTgeEHympoUwGCPkIqbVnQj =lLfxFONBTgeEHympoUwGCPkIqbVnQa['imgUrl']
      lLfxFONBTgeEHympoUwGCPkIqbVnQs =lLfxFONBTgeEHympoUwGCPkIqbVnQa['vtypeId']
      lLfxFONBTgeEHympoUwGCPkIqbVnvJ={'vodTitle':lLfxFONBTgeEHympoUwGCPkIqbVnQJ,'vodId':lLfxFONBTgeEHympoUwGCPkIqbVnQA,'vodType':lLfxFONBTgeEHympoUwGCPkIqbVnQi,'thumbnail':lLfxFONBTgeEHympoUwGCPkIqbVnQj,'vtypeId':lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnQs),'duration':lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnQa['duration']/1000)}
      lLfxFONBTgeEHympoUwGCPkIqbVnvD.append(lLfxFONBTgeEHympoUwGCPkIqbVnvJ)
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnvD
 def GetSeasonList(lLfxFONBTgeEHympoUwGCPkIqbVnda,leagueId):
  lLfxFONBTgeEHympoUwGCPkIqbVnvD=[]
  lLfxFONBTgeEHympoUwGCPkIqbVnQc=lLfxFONBTgeEHympoUwGCPkIqbVnQz=''
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/game/league/'+leagueId
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   lLfxFONBTgeEHympoUwGCPkIqbVnQc=lLfxFONBTgeEHympoUwGCPkIqbVndS['name']
   lLfxFONBTgeEHympoUwGCPkIqbVnQz=lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVndS['gameTypeId'])
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
   return lLfxFONBTgeEHympoUwGCPkIqbVnvD
  if lLfxFONBTgeEHympoUwGCPkIqbVnQz=='2':
   try:
    lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/year/'+leagueId
    lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
    lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
    for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVndS:
     lLfxFONBTgeEHympoUwGCPkIqbVnvJ={'reagueName':lLfxFONBTgeEHympoUwGCPkIqbVnQc,'gameTypeId':lLfxFONBTgeEHympoUwGCPkIqbVnQz,'seasonName':lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnvu),'seasonId':lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnvu)}
     lLfxFONBTgeEHympoUwGCPkIqbVnvD.append(lLfxFONBTgeEHympoUwGCPkIqbVnvJ)
   except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
    lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
    return[]
  else:
   try:
    lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/season/'+leagueId
    lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
    lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
    for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVndS:
     lLfxFONBTgeEHympoUwGCPkIqbVnvJ={'reagueName':lLfxFONBTgeEHympoUwGCPkIqbVnQc,'gameTypeId':lLfxFONBTgeEHympoUwGCPkIqbVnQz,'seasonName':lLfxFONBTgeEHympoUwGCPkIqbVnvu['name'],'seasonId':lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnvu['id'])}
     lLfxFONBTgeEHympoUwGCPkIqbVnvD.append(lLfxFONBTgeEHympoUwGCPkIqbVnvJ)
   except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
    lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
    return[]
  return lLfxFONBTgeEHympoUwGCPkIqbVnvD
 def GetGameList(lLfxFONBTgeEHympoUwGCPkIqbVnda,lLfxFONBTgeEHympoUwGCPkIqbVnQz,leagueId,seasonId,page_int,hidescore=lLfxFONBTgeEHympoUwGCPkIqbVnDW):
  lLfxFONBTgeEHympoUwGCPkIqbVnvD=[]
  lLfxFONBTgeEHympoUwGCPkIqbVnQh=lLfxFONBTgeEHympoUwGCPkIqbVnDz
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/vod/league/detail'
   lLfxFONBTgeEHympoUwGCPkIqbVnQR={'gameType':lLfxFONBTgeEHympoUwGCPkIqbVnQz,'leagueId':leagueId,'seasonId':seasonId if lLfxFONBTgeEHympoUwGCPkIqbVnQz!='2' else '','teamId':'','roundId':'','year':'' if lLfxFONBTgeEHympoUwGCPkIqbVnQz!='2' else seasonId,'pageNo':lLfxFONBTgeEHympoUwGCPkIqbVnDM(page_int)}
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnQR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   lLfxFONBTgeEHympoUwGCPkIqbVnYa=lLfxFONBTgeEHympoUwGCPkIqbVndS['list']
   for lLfxFONBTgeEHympoUwGCPkIqbVnQK in lLfxFONBTgeEHympoUwGCPkIqbVnYa:
    for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVnQK['list']:
     if lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['title']==lLfxFONBTgeEHympoUwGCPkIqbVnDR or lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['title']=='':
      lLfxFONBTgeEHympoUwGCPkIqbVnYu ='%s vs %s'%(lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['homeNameShort'],lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['awayNameShort'])
     else:
      lLfxFONBTgeEHympoUwGCPkIqbVnYu =lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['title']
     lLfxFONBTgeEHympoUwGCPkIqbVnQM =lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['beginDate']
     lLfxFONBTgeEHympoUwGCPkIqbVnQW =lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['id']
     lLfxFONBTgeEHympoUwGCPkIqbVnQS =lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['leagueNameFull']
     lLfxFONBTgeEHympoUwGCPkIqbVnQr =lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['seasonName']
     lLfxFONBTgeEHympoUwGCPkIqbVnQX =lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['roundName']
     lLfxFONBTgeEHympoUwGCPkIqbVnQt =lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['homeName']
     lLfxFONBTgeEHympoUwGCPkIqbVnDd =lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['awayName']
     lLfxFONBTgeEHympoUwGCPkIqbVnDv =lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['homeScore']
     lLfxFONBTgeEHympoUwGCPkIqbVnDY =lLfxFONBTgeEHympoUwGCPkIqbVnvu['gameDesc']['awayScore']
     if hidescore==lLfxFONBTgeEHympoUwGCPkIqbVnDW:
      lLfxFONBTgeEHympoUwGCPkIqbVnDQ ='%s\n - %s (%s)\n - %s\n\nhome : %s\n\naway : %s'%(lLfxFONBTgeEHympoUwGCPkIqbVnQS,lLfxFONBTgeEHympoUwGCPkIqbVnQr,lLfxFONBTgeEHympoUwGCPkIqbVnQX,lLfxFONBTgeEHympoUwGCPkIqbVnQM,lLfxFONBTgeEHympoUwGCPkIqbVnQt,lLfxFONBTgeEHympoUwGCPkIqbVnDd)
     else:
      lLfxFONBTgeEHympoUwGCPkIqbVnDQ ='%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)'%(lLfxFONBTgeEHympoUwGCPkIqbVnQS,lLfxFONBTgeEHympoUwGCPkIqbVnQr,lLfxFONBTgeEHympoUwGCPkIqbVnQX,lLfxFONBTgeEHympoUwGCPkIqbVnQM,lLfxFONBTgeEHympoUwGCPkIqbVnQt,lLfxFONBTgeEHympoUwGCPkIqbVnDv,lLfxFONBTgeEHympoUwGCPkIqbVnDd,lLfxFONBTgeEHympoUwGCPkIqbVnDY)
     lLfxFONBTgeEHympoUwGCPkIqbVnDa=lLfxFONBTgeEHympoUwGCPkIqbVnDQ
     lLfxFONBTgeEHympoUwGCPkIqbVnDu =lLfxFONBTgeEHympoUwGCPkIqbVnvu['replayVod']['count']
     lLfxFONBTgeEHympoUwGCPkIqbVnDJ=lLfxFONBTgeEHympoUwGCPkIqbVnvu['highlightVod']['count']
     lLfxFONBTgeEHympoUwGCPkIqbVnDA =lLfxFONBTgeEHympoUwGCPkIqbVnvu['vods']['count']
     lLfxFONBTgeEHympoUwGCPkIqbVnQj='' 
     lLfxFONBTgeEHympoUwGCPkIqbVnDi=lLfxFONBTgeEHympoUwGCPkIqbVnDu+lLfxFONBTgeEHympoUwGCPkIqbVnDJ+lLfxFONBTgeEHympoUwGCPkIqbVnDA
     if lLfxFONBTgeEHympoUwGCPkIqbVnDi==0:
      if lLfxFONBTgeEHympoUwGCPkIqbVnQz=='2':
       lLfxFONBTgeEHympoUwGCPkIqbVnYu='----- %s -----'%(lLfxFONBTgeEHympoUwGCPkIqbVnQr)
       lLfxFONBTgeEHympoUwGCPkIqbVnQM=''
      else:
       lLfxFONBTgeEHympoUwGCPkIqbVnYu+=' - 관련영상 없음'
       lLfxFONBTgeEHympoUwGCPkIqbVnDa+='\n\n ** 관련영상 없음 **'
     else:
      if lLfxFONBTgeEHympoUwGCPkIqbVnDu!=0:
       lLfxFONBTgeEHympoUwGCPkIqbVnQj =lLfxFONBTgeEHympoUwGCPkIqbVnvu['replayVod']['list'][0]['imgUrl']
      elif lLfxFONBTgeEHympoUwGCPkIqbVnDJ!=0:
       lLfxFONBTgeEHympoUwGCPkIqbVnQj =lLfxFONBTgeEHympoUwGCPkIqbVnvu['highlightVod']['list'][0]['imgUrl']
      else:
       lLfxFONBTgeEHympoUwGCPkIqbVnQj =lLfxFONBTgeEHympoUwGCPkIqbVnvu['vods']['list'][0]['imgUrl']
     lLfxFONBTgeEHympoUwGCPkIqbVnvJ={'gameTitle':lLfxFONBTgeEHympoUwGCPkIqbVnYu,'gameId':lLfxFONBTgeEHympoUwGCPkIqbVnQW,'beginDate':lLfxFONBTgeEHympoUwGCPkIqbVnQM[:11],'thumbnail':lLfxFONBTgeEHympoUwGCPkIqbVnQj,'info_plot':lLfxFONBTgeEHympoUwGCPkIqbVnDa,'leaguenm':lLfxFONBTgeEHympoUwGCPkIqbVnQS,'seasonnm':lLfxFONBTgeEHympoUwGCPkIqbVnQr,'roundnm':lLfxFONBTgeEHympoUwGCPkIqbVnQX,'totVodCnt':lLfxFONBTgeEHympoUwGCPkIqbVnDi}
     lLfxFONBTgeEHympoUwGCPkIqbVnvD.append(lLfxFONBTgeEHympoUwGCPkIqbVnvJ)
   if lLfxFONBTgeEHympoUwGCPkIqbVnQz=='2':
    if lLfxFONBTgeEHympoUwGCPkIqbVndS['count']>page_int*lLfxFONBTgeEHympoUwGCPkIqbVnda.GAMELIST_LIMIT:lLfxFONBTgeEHympoUwGCPkIqbVnQh=lLfxFONBTgeEHympoUwGCPkIqbVnDW
   else:
    if lLfxFONBTgeEHympoUwGCPkIqbVndS['list'][0]['count']>page_int*lLfxFONBTgeEHympoUwGCPkIqbVnda.GAMELIST_LIMIT:lLfxFONBTgeEHympoUwGCPkIqbVnQh=lLfxFONBTgeEHympoUwGCPkIqbVnDW
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnvD,lLfxFONBTgeEHympoUwGCPkIqbVnQh
 def GetGameVodList(lLfxFONBTgeEHympoUwGCPkIqbVnda,lLfxFONBTgeEHympoUwGCPkIqbVnQW):
  lLfxFONBTgeEHympoUwGCPkIqbVnvD=[]
  lLfxFONBTgeEHympoUwGCPkIqbVnDj=''
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/vod/game'
   lLfxFONBTgeEHympoUwGCPkIqbVnQR={'gameId':lLfxFONBTgeEHympoUwGCPkIqbVnQW,'pageItem':'1000'}
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnQR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   lLfxFONBTgeEHympoUwGCPkIqbVnQK=lLfxFONBTgeEHympoUwGCPkIqbVndS['list']
   for lLfxFONBTgeEHympoUwGCPkIqbVnvu in lLfxFONBTgeEHympoUwGCPkIqbVnQK:
    lLfxFONBTgeEHympoUwGCPkIqbVnQJ =lLfxFONBTgeEHympoUwGCPkIqbVnvu['title']
    lLfxFONBTgeEHympoUwGCPkIqbVnQA =lLfxFONBTgeEHympoUwGCPkIqbVnvu['id']
    lLfxFONBTgeEHympoUwGCPkIqbVnQi =lLfxFONBTgeEHympoUwGCPkIqbVnvu['vtype']
    lLfxFONBTgeEHympoUwGCPkIqbVnQj =lLfxFONBTgeEHympoUwGCPkIqbVnvu['imgUrl']
    lLfxFONBTgeEHympoUwGCPkIqbVnQs =lLfxFONBTgeEHympoUwGCPkIqbVnvu['vtypeId']
    lLfxFONBTgeEHympoUwGCPkIqbVnvJ={'vodTitle':lLfxFONBTgeEHympoUwGCPkIqbVnQJ,'vodId':lLfxFONBTgeEHympoUwGCPkIqbVnQA,'vodType':lLfxFONBTgeEHympoUwGCPkIqbVnQi,'thumbnail':lLfxFONBTgeEHympoUwGCPkIqbVnQj,'vtypeId':lLfxFONBTgeEHympoUwGCPkIqbVnDM(lLfxFONBTgeEHympoUwGCPkIqbVnQs),'duration':lLfxFONBTgeEHympoUwGCPkIqbVnDr(lLfxFONBTgeEHympoUwGCPkIqbVnvu['duration']/1000)}
    lLfxFONBTgeEHympoUwGCPkIqbVnvD.append(lLfxFONBTgeEHympoUwGCPkIqbVnvJ)
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnvD
 def GetReplay_UrlId(lLfxFONBTgeEHympoUwGCPkIqbVnda,lLfxFONBTgeEHympoUwGCPkIqbVnDj,lLfxFONBTgeEHympoUwGCPkIqbVnQs):
  lLfxFONBTgeEHympoUwGCPkIqbVnDs=lLfxFONBTgeEHympoUwGCPkIqbVnYJ=''
  lLfxFONBTgeEHympoUwGCPkIqbVnDc=''
  try:
   lLfxFONBTgeEHympoUwGCPkIqbVnvA=lLfxFONBTgeEHympoUwGCPkIqbVnda.API_DOMAIN+'/api/v2/vod/'+lLfxFONBTgeEHympoUwGCPkIqbVnDj
   lLfxFONBTgeEHympoUwGCPkIqbVndK=lLfxFONBTgeEHympoUwGCPkIqbVnda.callRequestCookies('Get',lLfxFONBTgeEHympoUwGCPkIqbVnvA,payload=lLfxFONBTgeEHympoUwGCPkIqbVnDR,params=lLfxFONBTgeEHympoUwGCPkIqbVnDR,headers=lLfxFONBTgeEHympoUwGCPkIqbVnDR,cookies=lLfxFONBTgeEHympoUwGCPkIqbVnDR)
   lLfxFONBTgeEHympoUwGCPkIqbVndS=json.loads(lLfxFONBTgeEHympoUwGCPkIqbVndK.text)
   lLfxFONBTgeEHympoUwGCPkIqbVnDs =lLfxFONBTgeEHympoUwGCPkIqbVndS['clipId']
   lLfxFONBTgeEHympoUwGCPkIqbVnYJ=lLfxFONBTgeEHympoUwGCPkIqbVndS['videoId']
   lLfxFONBTgeEHympoUwGCPkIqbVnDc=lLfxFONBTgeEHympoUwGCPkIqbVnDs
   if lLfxFONBTgeEHympoUwGCPkIqbVnda.CheckSubEnd()or lLfxFONBTgeEHympoUwGCPkIqbVnQs!='1':lLfxFONBTgeEHympoUwGCPkIqbVnDc=lLfxFONBTgeEHympoUwGCPkIqbVnYJ 
  except lLfxFONBTgeEHympoUwGCPkIqbVnDS as exception:
   lLfxFONBTgeEHympoUwGCPkIqbVnDK(exception)
  return lLfxFONBTgeEHympoUwGCPkIqbVnDc
# Created by pyminifier (https://github.com/liftoff/pyminifier)
