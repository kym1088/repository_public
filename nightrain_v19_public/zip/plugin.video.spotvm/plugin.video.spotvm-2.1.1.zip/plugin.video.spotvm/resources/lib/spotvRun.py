__author__="NightRain"
BmPKupLfAyHWzvItxcYXdUsRQgwDTS=object
BmPKupLfAyHWzvItxcYXdUsRQgwDTa=None
BmPKupLfAyHWzvItxcYXdUsRQgwDTM=True
BmPKupLfAyHWzvItxcYXdUsRQgwDTr=int
BmPKupLfAyHWzvItxcYXdUsRQgwDTN=False
BmPKupLfAyHWzvItxcYXdUsRQgwDTF=len
BmPKupLfAyHWzvItxcYXdUsRQgwDTJ=str
BmPKupLfAyHWzvItxcYXdUsRQgwDTl=open
BmPKupLfAyHWzvItxcYXdUsRQgwDTe=Exception
BmPKupLfAyHWzvItxcYXdUsRQgwDTE=print
BmPKupLfAyHWzvItxcYXdUsRQgwDTj=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
BmPKupLfAyHWzvItxcYXdUsRQgwDob=[{'title':'TV 채널','mode':'LIVE_GROUP'},{'title':'Live중계 (독점,현지)','mode':'ELIVE_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'인기영상5','mode':'POP_GROUP'},{'title':'VOD 영상','mode':'VOD_GROUP'},{'title':'-----------------','mode':'XXX'},{'title':'Watched (시청목록)','mode':'WATCH'}]
BmPKupLfAyHWzvItxcYXdUsRQgwDon=xbmcvfs.translatePath(os.path.join(__profile__,'spotv_cookies.json'))
from spotvCore import*
class BmPKupLfAyHWzvItxcYXdUsRQgwDoh(BmPKupLfAyHWzvItxcYXdUsRQgwDTS):
 def __init__(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,BmPKupLfAyHWzvItxcYXdUsRQgwDoV,BmPKupLfAyHWzvItxcYXdUsRQgwDoS,BmPKupLfAyHWzvItxcYXdUsRQgwDoa):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_url =BmPKupLfAyHWzvItxcYXdUsRQgwDoV
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle=BmPKupLfAyHWzvItxcYXdUsRQgwDoS
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params =BmPKupLfAyHWzvItxcYXdUsRQgwDoa
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj =yciXKmBOIkPJsbTrRwWFjxQHEYLVUA() 
 def addon_noti(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,sting):
  try:
   BmPKupLfAyHWzvItxcYXdUsRQgwDor=xbmcgui.Dialog()
   BmPKupLfAyHWzvItxcYXdUsRQgwDor.notification(__addonname__,sting)
  except:
   BmPKupLfAyHWzvItxcYXdUsRQgwDTa
 def addon_log(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,string):
  try:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoN=string.encode('utf-8','ignore')
  except:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoN='addonException: addon_log'
  BmPKupLfAyHWzvItxcYXdUsRQgwDoF=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,BmPKupLfAyHWzvItxcYXdUsRQgwDoN),level=BmPKupLfAyHWzvItxcYXdUsRQgwDoF)
 def get_keyboard_input(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,BmPKupLfAyHWzvItxcYXdUsRQgwDoO):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoJ=BmPKupLfAyHWzvItxcYXdUsRQgwDTa
  kb=xbmc.Keyboard()
  kb.setHeading(BmPKupLfAyHWzvItxcYXdUsRQgwDoO)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   BmPKupLfAyHWzvItxcYXdUsRQgwDoJ=kb.getText()
  return BmPKupLfAyHWzvItxcYXdUsRQgwDoJ
 def get_settings_login_info(BmPKupLfAyHWzvItxcYXdUsRQgwDoT):
  BmPKupLfAyHWzvItxcYXdUsRQgwDol =__addon__.getSetting('id')
  BmPKupLfAyHWzvItxcYXdUsRQgwDoe =__addon__.getSetting('pw')
  return(BmPKupLfAyHWzvItxcYXdUsRQgwDol,BmPKupLfAyHWzvItxcYXdUsRQgwDoe)
 def set_winCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,credential):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE=xbmcgui.Window(10000)
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_SESSIONID',credential.get('spotv_sessionid'))
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_SESSION',credential.get('spotv_session'))
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_ACCOUNTID',credential.get('spotv_accountId'))
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_POLICYKEY',credential.get('spotv_policyKey'))
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_SUBEND',credential.get('spotv_subend'))
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_LOGINTIME',BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDoT):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE=xbmcgui.Window(10000)
  BmPKupLfAyHWzvItxcYXdUsRQgwDoj={'spotv_sessionid':BmPKupLfAyHWzvItxcYXdUsRQgwDoE.getProperty('SPOTV_M_SESSIONID'),'spotv_session':BmPKupLfAyHWzvItxcYXdUsRQgwDoE.getProperty('SPOTV_M_SESSION'),'spotv_accountId':BmPKupLfAyHWzvItxcYXdUsRQgwDoE.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':BmPKupLfAyHWzvItxcYXdUsRQgwDoE.getProperty('SPOTV_M_POLICYKEY'),'spotv_subend':BmPKupLfAyHWzvItxcYXdUsRQgwDoE.getProperty('SPOTV_M_SUBEND')}
  return BmPKupLfAyHWzvItxcYXdUsRQgwDoj
 def add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,label,sublabel='',img='',infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDTa,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDTM,params=''):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoC='%s?%s'%(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_url,urllib.parse.urlencode(params))
  if sublabel:BmPKupLfAyHWzvItxcYXdUsRQgwDoO='%s < %s >'%(label,sublabel)
  else: BmPKupLfAyHWzvItxcYXdUsRQgwDoO=label
  if not img:img='DefaultFolder.png'
  BmPKupLfAyHWzvItxcYXdUsRQgwDoq=xbmcgui.ListItem(BmPKupLfAyHWzvItxcYXdUsRQgwDoO)
  BmPKupLfAyHWzvItxcYXdUsRQgwDoq.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:BmPKupLfAyHWzvItxcYXdUsRQgwDoq.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:BmPKupLfAyHWzvItxcYXdUsRQgwDoq.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle,BmPKupLfAyHWzvItxcYXdUsRQgwDoC,BmPKupLfAyHWzvItxcYXdUsRQgwDoq,isFolder)
 def get_selQuality(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,etype):
  try:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoi='selected_quality'
   BmPKupLfAyHWzvItxcYXdUsRQgwDoG=[1080,720,540]
   BmPKupLfAyHWzvItxcYXdUsRQgwDok=BmPKupLfAyHWzvItxcYXdUsRQgwDTr(__addon__.getSetting(BmPKupLfAyHWzvItxcYXdUsRQgwDoi))
   return BmPKupLfAyHWzvItxcYXdUsRQgwDoG[BmPKupLfAyHWzvItxcYXdUsRQgwDok]
  except:
   BmPKupLfAyHWzvItxcYXdUsRQgwDTa
  return 1080 
 def dp_Main_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT):
  for BmPKupLfAyHWzvItxcYXdUsRQgwDho in BmPKupLfAyHWzvItxcYXdUsRQgwDob:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoO=BmPKupLfAyHWzvItxcYXdUsRQgwDho.get('title')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb={'mode':BmPKupLfAyHWzvItxcYXdUsRQgwDho.get('mode')}
   if BmPKupLfAyHWzvItxcYXdUsRQgwDho.get('mode')=='XXX':
    BmPKupLfAyHWzvItxcYXdUsRQgwDhn=BmPKupLfAyHWzvItxcYXdUsRQgwDTN
   else:
    BmPKupLfAyHWzvItxcYXdUsRQgwDhn=BmPKupLfAyHWzvItxcYXdUsRQgwDTM
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDoO,sublabel='',img='',infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDTa,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDhn,params=BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
  if BmPKupLfAyHWzvItxcYXdUsRQgwDTF(BmPKupLfAyHWzvItxcYXdUsRQgwDob)>0:xbmcplugin.endOfDirectory(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle)
 def dp_MainLeague_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,args):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.SaveCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.get_winCredential())
  BmPKupLfAyHWzvItxcYXdUsRQgwDhV=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.GetTitleGroupList()
  for BmPKupLfAyHWzvItxcYXdUsRQgwDhS in BmPKupLfAyHWzvItxcYXdUsRQgwDhV:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoO =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('title')
   BmPKupLfAyHWzvItxcYXdUsRQgwDha =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('logo')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhM =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('reagueId')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhr =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('subGame')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhN={'mediatype':'episode','plot':'%s\n\n%s'%(BmPKupLfAyHWzvItxcYXdUsRQgwDoO,BmPKupLfAyHWzvItxcYXdUsRQgwDhr)}
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb={'mode':'LEAGUE_GROUP','reagueId':BmPKupLfAyHWzvItxcYXdUsRQgwDhM}
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDoO,sublabel=BmPKupLfAyHWzvItxcYXdUsRQgwDTa,img=BmPKupLfAyHWzvItxcYXdUsRQgwDha,infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDhN,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDTM,params=BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
  if BmPKupLfAyHWzvItxcYXdUsRQgwDTF(BmPKupLfAyHWzvItxcYXdUsRQgwDhV)>0:xbmcplugin.endOfDirectory(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle,cacheToDisc=BmPKupLfAyHWzvItxcYXdUsRQgwDTN)
 def dp_PopVod_GroupList(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,args):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.SaveCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.get_winCredential())
  BmPKupLfAyHWzvItxcYXdUsRQgwDhV=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.GetPopularGroupList()
  for BmPKupLfAyHWzvItxcYXdUsRQgwDhS in BmPKupLfAyHWzvItxcYXdUsRQgwDhV:
   BmPKupLfAyHWzvItxcYXdUsRQgwDhF =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('vodTitle')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhJ =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('vodId')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhl =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('vodType')
   BmPKupLfAyHWzvItxcYXdUsRQgwDha=BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('thumbnail')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhe =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('vtypeId')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhE =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('duration')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhN={'mediatype':'video','duration':BmPKupLfAyHWzvItxcYXdUsRQgwDhE,'plot':BmPKupLfAyHWzvItxcYXdUsRQgwDhF}
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb={'mode':'POP_VOD','mediacode':BmPKupLfAyHWzvItxcYXdUsRQgwDhJ,'mediatype':'vod','vtypeId':BmPKupLfAyHWzvItxcYXdUsRQgwDhe}
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDhF,sublabel=BmPKupLfAyHWzvItxcYXdUsRQgwDhl,img=BmPKupLfAyHWzvItxcYXdUsRQgwDha,infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDhN,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDTN,params=BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
  if BmPKupLfAyHWzvItxcYXdUsRQgwDTF(BmPKupLfAyHWzvItxcYXdUsRQgwDhV)>0:xbmcplugin.endOfDirectory(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle,cacheToDisc=BmPKupLfAyHWzvItxcYXdUsRQgwDTN)
 def dp_Season_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,args):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.SaveCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.get_winCredential())
  BmPKupLfAyHWzvItxcYXdUsRQgwDhM=args.get('reagueId')
  BmPKupLfAyHWzvItxcYXdUsRQgwDhV=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.GetSeasonList(BmPKupLfAyHWzvItxcYXdUsRQgwDhM)
  for BmPKupLfAyHWzvItxcYXdUsRQgwDhS in BmPKupLfAyHWzvItxcYXdUsRQgwDhV:
   BmPKupLfAyHWzvItxcYXdUsRQgwDhj =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('reagueName')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhC =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('gameTypeId')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhO =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('seasonName')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhq =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('seasonId')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhN={'mediatype':'episode','plot':'%s - %s'%(BmPKupLfAyHWzvItxcYXdUsRQgwDhj,BmPKupLfAyHWzvItxcYXdUsRQgwDhO)}
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb={'mode':'SEASON_GROUP','reagueId':BmPKupLfAyHWzvItxcYXdUsRQgwDhM,'seasonId':BmPKupLfAyHWzvItxcYXdUsRQgwDhq,'gameTypeId':BmPKupLfAyHWzvItxcYXdUsRQgwDhC,'page':'1'}
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDhj,sublabel=BmPKupLfAyHWzvItxcYXdUsRQgwDhO,img='',infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDhN,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDTM,params=BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
  if BmPKupLfAyHWzvItxcYXdUsRQgwDTF(BmPKupLfAyHWzvItxcYXdUsRQgwDhV)>0:xbmcplugin.endOfDirectory(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle,cacheToDisc=BmPKupLfAyHWzvItxcYXdUsRQgwDTM)
 def dp_Game_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,args):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.SaveCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.get_winCredential())
  BmPKupLfAyHWzvItxcYXdUsRQgwDhC=args.get('gameTypeId')
  BmPKupLfAyHWzvItxcYXdUsRQgwDhM =args.get('reagueId')
  BmPKupLfAyHWzvItxcYXdUsRQgwDhq =args.get('seasonId')
  BmPKupLfAyHWzvItxcYXdUsRQgwDhi =BmPKupLfAyHWzvItxcYXdUsRQgwDTr(args.get('page'))
  BmPKupLfAyHWzvItxcYXdUsRQgwDhV,BmPKupLfAyHWzvItxcYXdUsRQgwDhG=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.GetGameList(BmPKupLfAyHWzvItxcYXdUsRQgwDhC,BmPKupLfAyHWzvItxcYXdUsRQgwDhM,BmPKupLfAyHWzvItxcYXdUsRQgwDhq,BmPKupLfAyHWzvItxcYXdUsRQgwDhi)
  for BmPKupLfAyHWzvItxcYXdUsRQgwDhS in BmPKupLfAyHWzvItxcYXdUsRQgwDhV:
   BmPKupLfAyHWzvItxcYXdUsRQgwDhk =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('gameTitle')
   BmPKupLfAyHWzvItxcYXdUsRQgwDbo =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('beginDate')
   BmPKupLfAyHWzvItxcYXdUsRQgwDha =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('thumbnail')
   BmPKupLfAyHWzvItxcYXdUsRQgwDbh =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('gameId')
   BmPKupLfAyHWzvItxcYXdUsRQgwDbn =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('totVodCnt')
   BmPKupLfAyHWzvItxcYXdUsRQgwDbT =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('leaguenm')
   BmPKupLfAyHWzvItxcYXdUsRQgwDbV =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('seasonnm')
   BmPKupLfAyHWzvItxcYXdUsRQgwDbS =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('roundnm')
   BmPKupLfAyHWzvItxcYXdUsRQgwDba =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('info_plot')
   BmPKupLfAyHWzvItxcYXdUsRQgwDbM ='%s < %s >'%(BmPKupLfAyHWzvItxcYXdUsRQgwDhk,BmPKupLfAyHWzvItxcYXdUsRQgwDbo)
   BmPKupLfAyHWzvItxcYXdUsRQgwDhN={'mediatype':'video','plot':BmPKupLfAyHWzvItxcYXdUsRQgwDba}
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb={'mode':'GAME_VOD_GROUP' if BmPKupLfAyHWzvItxcYXdUsRQgwDbn!=0 else 'XXX','saveTitle':BmPKupLfAyHWzvItxcYXdUsRQgwDbM,'saveImg':BmPKupLfAyHWzvItxcYXdUsRQgwDha,'saveInfo':BmPKupLfAyHWzvItxcYXdUsRQgwDhN['plot'],'gameid':BmPKupLfAyHWzvItxcYXdUsRQgwDbh}
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDhk,sublabel=BmPKupLfAyHWzvItxcYXdUsRQgwDbo,img=BmPKupLfAyHWzvItxcYXdUsRQgwDha,infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDhN,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDTM,params=BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
  if BmPKupLfAyHWzvItxcYXdUsRQgwDhG:
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb['mode'] ='SEASON_GROUP' 
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb['reagueId'] =BmPKupLfAyHWzvItxcYXdUsRQgwDhM
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb['seasonId'] =BmPKupLfAyHWzvItxcYXdUsRQgwDhq
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb['gameTypeId']=BmPKupLfAyHWzvItxcYXdUsRQgwDhC
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb['page'] =BmPKupLfAyHWzvItxcYXdUsRQgwDTJ(BmPKupLfAyHWzvItxcYXdUsRQgwDhi+1)
   BmPKupLfAyHWzvItxcYXdUsRQgwDoO='[B]%s >>[/B]'%'다음 페이지'
   BmPKupLfAyHWzvItxcYXdUsRQgwDbr=BmPKupLfAyHWzvItxcYXdUsRQgwDTJ(BmPKupLfAyHWzvItxcYXdUsRQgwDhi+1)
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDoO,sublabel=BmPKupLfAyHWzvItxcYXdUsRQgwDbr,img='',infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDTa,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDTM,params=BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
  if BmPKupLfAyHWzvItxcYXdUsRQgwDTF(BmPKupLfAyHWzvItxcYXdUsRQgwDhV)>0:xbmcplugin.endOfDirectory(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle,cacheToDisc=BmPKupLfAyHWzvItxcYXdUsRQgwDTN)
 def dp_GameVod_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,args):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.SaveCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.get_winCredential())
  BmPKupLfAyHWzvItxcYXdUsRQgwDbN =args.get('gameid')
  BmPKupLfAyHWzvItxcYXdUsRQgwDbM=args.get('saveTitle')
  BmPKupLfAyHWzvItxcYXdUsRQgwDbF =args.get('saveImg')
  BmPKupLfAyHWzvItxcYXdUsRQgwDbJ =args.get('saveInfo')
  BmPKupLfAyHWzvItxcYXdUsRQgwDhV=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.GetGameVodList(BmPKupLfAyHWzvItxcYXdUsRQgwDbN)
  for BmPKupLfAyHWzvItxcYXdUsRQgwDhS in BmPKupLfAyHWzvItxcYXdUsRQgwDhV:
   BmPKupLfAyHWzvItxcYXdUsRQgwDhF =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('vodTitle')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhJ =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('vodId')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhl =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('vodType')
   BmPKupLfAyHWzvItxcYXdUsRQgwDha=BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('thumbnail')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhe =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('vtypeId')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhE =BmPKupLfAyHWzvItxcYXdUsRQgwDhS.get('duration')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhN={'mediatype':'video','duration':BmPKupLfAyHWzvItxcYXdUsRQgwDhE,'plot':'%s \n\n %s'%(BmPKupLfAyHWzvItxcYXdUsRQgwDhF,BmPKupLfAyHWzvItxcYXdUsRQgwDbJ)}
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb={'mode':'GAME_VOD','saveTitle':BmPKupLfAyHWzvItxcYXdUsRQgwDbM,'saveImg':BmPKupLfAyHWzvItxcYXdUsRQgwDbF,'saveId':BmPKupLfAyHWzvItxcYXdUsRQgwDbN,'saveInfo':BmPKupLfAyHWzvItxcYXdUsRQgwDbJ,'mediacode':BmPKupLfAyHWzvItxcYXdUsRQgwDhJ,'mediatype':'vod','vtypeId':BmPKupLfAyHWzvItxcYXdUsRQgwDhe}
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDhF,sublabel=BmPKupLfAyHWzvItxcYXdUsRQgwDhl,img=BmPKupLfAyHWzvItxcYXdUsRQgwDha,infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDhN,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDTN,params=BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
  if BmPKupLfAyHWzvItxcYXdUsRQgwDTF(BmPKupLfAyHWzvItxcYXdUsRQgwDhV)>0:xbmcplugin.endOfDirectory(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle,cacheToDisc=BmPKupLfAyHWzvItxcYXdUsRQgwDTN)
 def login_main(BmPKupLfAyHWzvItxcYXdUsRQgwDoT):
  (BmPKupLfAyHWzvItxcYXdUsRQgwDbl,BmPKupLfAyHWzvItxcYXdUsRQgwDbe)=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.get_settings_login_info()
  if not(BmPKupLfAyHWzvItxcYXdUsRQgwDbl and BmPKupLfAyHWzvItxcYXdUsRQgwDbe):
   BmPKupLfAyHWzvItxcYXdUsRQgwDor=xbmcgui.Dialog()
   BmPKupLfAyHWzvItxcYXdUsRQgwDbE=BmPKupLfAyHWzvItxcYXdUsRQgwDor.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if BmPKupLfAyHWzvItxcYXdUsRQgwDbE==BmPKupLfAyHWzvItxcYXdUsRQgwDTM:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if BmPKupLfAyHWzvItxcYXdUsRQgwDoT.cookiefile_check():return
  BmPKupLfAyHWzvItxcYXdUsRQgwDbj =BmPKupLfAyHWzvItxcYXdUsRQgwDTr(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  BmPKupLfAyHWzvItxcYXdUsRQgwDbC=xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINTIME')
  if BmPKupLfAyHWzvItxcYXdUsRQgwDbC==BmPKupLfAyHWzvItxcYXdUsRQgwDTa or BmPKupLfAyHWzvItxcYXdUsRQgwDbC=='':
   BmPKupLfAyHWzvItxcYXdUsRQgwDbC=BmPKupLfAyHWzvItxcYXdUsRQgwDTr('19000101')
  else:
   BmPKupLfAyHWzvItxcYXdUsRQgwDbC=BmPKupLfAyHWzvItxcYXdUsRQgwDTr(re.sub('-','',BmPKupLfAyHWzvItxcYXdUsRQgwDbC))
  if xbmcgui.Window(10000).getProperty('SPOTV_M_LOGINWAIT')=='TRUE':
   BmPKupLfAyHWzvItxcYXdUsRQgwDbO=0
   while BmPKupLfAyHWzvItxcYXdUsRQgwDTM:
    BmPKupLfAyHWzvItxcYXdUsRQgwDbO+=1
    time.sleep(0.05)
    if BmPKupLfAyHWzvItxcYXdUsRQgwDbC>=BmPKupLfAyHWzvItxcYXdUsRQgwDbj:return
    if BmPKupLfAyHWzvItxcYXdUsRQgwDbO>600:return
  else:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','TRUE')
  if BmPKupLfAyHWzvItxcYXdUsRQgwDbC>=BmPKupLfAyHWzvItxcYXdUsRQgwDbj:
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   return
  if not BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.GetCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDbl,BmPKupLfAyHWzvItxcYXdUsRQgwDbe):
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
   sys.exit()
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.set_winCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.LoadCredential())
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.cookiefile_save()
  xbmcgui.Window(10000).setProperty('SPOTV_M_LOGINWAIT','FALSE')
 def dp_LiveChannel_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,args):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.SaveCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.get_winCredential())
  BmPKupLfAyHWzvItxcYXdUsRQgwDbq=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.GetLiveChannelList()
  for BmPKupLfAyHWzvItxcYXdUsRQgwDbi in BmPKupLfAyHWzvItxcYXdUsRQgwDbq:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoO =BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('name')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhT =BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('programName')
   BmPKupLfAyHWzvItxcYXdUsRQgwDha =BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('logo')
   BmPKupLfAyHWzvItxcYXdUsRQgwDbG=BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('channelepg')
   BmPKupLfAyHWzvItxcYXdUsRQgwDbk =BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('free')
   BmPKupLfAyHWzvItxcYXdUsRQgwDno =BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('studio')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhN={'plot':'%s'%(BmPKupLfAyHWzvItxcYXdUsRQgwDbG),'title':BmPKupLfAyHWzvItxcYXdUsRQgwDhT,'studio':BmPKupLfAyHWzvItxcYXdUsRQgwDno,'mediatype':'video'}
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb={'mode':'LIVE','mediaid':BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('id'),'mediacode':BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('videoId'),'free':BmPKupLfAyHWzvItxcYXdUsRQgwDbk,'mediatype':'live'}
   if BmPKupLfAyHWzvItxcYXdUsRQgwDbk:BmPKupLfAyHWzvItxcYXdUsRQgwDoO+=' [free]'
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDoO,sublabel=BmPKupLfAyHWzvItxcYXdUsRQgwDhT,img=BmPKupLfAyHWzvItxcYXdUsRQgwDha,infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDhN,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDTN,params=BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
  if BmPKupLfAyHWzvItxcYXdUsRQgwDTF(BmPKupLfAyHWzvItxcYXdUsRQgwDbq)>0:xbmcplugin.endOfDirectory(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle,cacheToDisc=BmPKupLfAyHWzvItxcYXdUsRQgwDTN)
 def dp_EventLiveChannel_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,args):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.SaveCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.get_winCredential())
  BmPKupLfAyHWzvItxcYXdUsRQgwDbq,BmPKupLfAyHWzvItxcYXdUsRQgwDnh=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.GetEventLiveList()
  if BmPKupLfAyHWzvItxcYXdUsRQgwDnh!=401 and BmPKupLfAyHWzvItxcYXdUsRQgwDTF(BmPKupLfAyHWzvItxcYXdUsRQgwDbq)==0:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.addon_noti(__language__(30907).encode('utf8'))
  for BmPKupLfAyHWzvItxcYXdUsRQgwDbi in BmPKupLfAyHWzvItxcYXdUsRQgwDbq:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoO =BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('title')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhT =BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('startTime')
   BmPKupLfAyHWzvItxcYXdUsRQgwDha =BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('logo')
   BmPKupLfAyHWzvItxcYXdUsRQgwDbk =BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('free')
   BmPKupLfAyHWzvItxcYXdUsRQgwDhN={'mediatype':'video','plot':'%s\n\n%s'%(BmPKupLfAyHWzvItxcYXdUsRQgwDoO,BmPKupLfAyHWzvItxcYXdUsRQgwDhT)}
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb={'mode':'ELIVE','mediaid':BmPKupLfAyHWzvItxcYXdUsRQgwDbi.get('liveId'),'mediacode':'','free':BmPKupLfAyHWzvItxcYXdUsRQgwDbk,'mediatype':'live'}
   if BmPKupLfAyHWzvItxcYXdUsRQgwDbk:BmPKupLfAyHWzvItxcYXdUsRQgwDoO+=' [free]'
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDoO,sublabel=BmPKupLfAyHWzvItxcYXdUsRQgwDhT,img=BmPKupLfAyHWzvItxcYXdUsRQgwDha,infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDhN,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDTN,params=BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
  if BmPKupLfAyHWzvItxcYXdUsRQgwDTF(BmPKupLfAyHWzvItxcYXdUsRQgwDbq)>0:xbmcplugin.endOfDirectory(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle,cacheToDisc=BmPKupLfAyHWzvItxcYXdUsRQgwDTM)
  return BmPKupLfAyHWzvItxcYXdUsRQgwDnh
 def play_VIDEO(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,args):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.SaveCredential(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.get_winCredential())
  BmPKupLfAyHWzvItxcYXdUsRQgwDnb =args.get('mode')
  BmPKupLfAyHWzvItxcYXdUsRQgwDnT =args.get('mediacode')
  BmPKupLfAyHWzvItxcYXdUsRQgwDnV =args.get('mediatype')
  BmPKupLfAyHWzvItxcYXdUsRQgwDhe =args.get('vtypeId')
  if BmPKupLfAyHWzvItxcYXdUsRQgwDnb=='LIVE':
   if BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.CheckLiveChannel(BmPKupLfAyHWzvItxcYXdUsRQgwDnT)==BmPKupLfAyHWzvItxcYXdUsRQgwDTN:
    if BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.CheckSubEnd()==BmPKupLfAyHWzvItxcYXdUsRQgwDTN:
     BmPKupLfAyHWzvItxcYXdUsRQgwDoT.addon_noti(__language__(30908).encode('utf8'))
     return
  elif BmPKupLfAyHWzvItxcYXdUsRQgwDnb=='ELIVE':
   if args.get('free')=='False':
    if BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.CheckSubEnd()==BmPKupLfAyHWzvItxcYXdUsRQgwDTN:
     BmPKupLfAyHWzvItxcYXdUsRQgwDoT.addon_noti(__language__(30908).encode('utf8'))
     return
   BmPKupLfAyHWzvItxcYXdUsRQgwDnT=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.GetEventLive_videoId(args.get('mediaid'))
  if BmPKupLfAyHWzvItxcYXdUsRQgwDnT=='' or BmPKupLfAyHWzvItxcYXdUsRQgwDnT==BmPKupLfAyHWzvItxcYXdUsRQgwDTa:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.addon_noti(__language__(30907).encode('utf8'))
   return
  BmPKupLfAyHWzvItxcYXdUsRQgwDnS=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.GetBroadURL(BmPKupLfAyHWzvItxcYXdUsRQgwDnT,BmPKupLfAyHWzvItxcYXdUsRQgwDnV,BmPKupLfAyHWzvItxcYXdUsRQgwDhe)
  if BmPKupLfAyHWzvItxcYXdUsRQgwDnS=='':
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.addon_noti(__language__(30908).encode('utf8'))
   return
  BmPKupLfAyHWzvItxcYXdUsRQgwDna=BmPKupLfAyHWzvItxcYXdUsRQgwDnS
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.addon_log(BmPKupLfAyHWzvItxcYXdUsRQgwDna)
  BmPKupLfAyHWzvItxcYXdUsRQgwDnM=xbmcgui.ListItem(path=BmPKupLfAyHWzvItxcYXdUsRQgwDna)
  xbmcplugin.setResolvedUrl(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle,BmPKupLfAyHWzvItxcYXdUsRQgwDTM,BmPKupLfAyHWzvItxcYXdUsRQgwDnM)
  try:
   if BmPKupLfAyHWzvItxcYXdUsRQgwDnV=='vod' and BmPKupLfAyHWzvItxcYXdUsRQgwDnb!='POP_VOD':
    BmPKupLfAyHWzvItxcYXdUsRQgwDhb={'code':args.get('saveId'),'img':args.get('saveImg'),'title':args.get('saveTitle'),'info':args.get('saveInfo')}
    BmPKupLfAyHWzvItxcYXdUsRQgwDoT.Save_Watched_List(BmPKupLfAyHWzvItxcYXdUsRQgwDnV,BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
  except:
   BmPKupLfAyHWzvItxcYXdUsRQgwDTa
 def logout(BmPKupLfAyHWzvItxcYXdUsRQgwDoT):
  BmPKupLfAyHWzvItxcYXdUsRQgwDor=xbmcgui.Dialog()
  BmPKupLfAyHWzvItxcYXdUsRQgwDbE=BmPKupLfAyHWzvItxcYXdUsRQgwDor.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if BmPKupLfAyHWzvItxcYXdUsRQgwDbE==BmPKupLfAyHWzvItxcYXdUsRQgwDTN:sys.exit()
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.wininfo_clear()
  if os.path.isfile(BmPKupLfAyHWzvItxcYXdUsRQgwDon):os.remove(BmPKupLfAyHWzvItxcYXdUsRQgwDon)
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(BmPKupLfAyHWzvItxcYXdUsRQgwDoT):
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE=xbmcgui.Window(10000)
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_SESSIONID','')
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_SESSION','')
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_ACCOUNTID','')
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_POLICYKEY','')
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_SUBEND','')
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_LOGINTIME','')
 def cookiefile_save(BmPKupLfAyHWzvItxcYXdUsRQgwDoT):
  BmPKupLfAyHWzvItxcYXdUsRQgwDnr =BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.Get_Now_Datetime()
  BmPKupLfAyHWzvItxcYXdUsRQgwDnN=BmPKupLfAyHWzvItxcYXdUsRQgwDnr+datetime.timedelta(days=BmPKupLfAyHWzvItxcYXdUsRQgwDTr(__addon__.getSetting('cache_ttl')))
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE=xbmcgui.Window(10000)
  BmPKupLfAyHWzvItxcYXdUsRQgwDnF={'spotv_sessionid':BmPKupLfAyHWzvItxcYXdUsRQgwDoE.getProperty('SPOTV_M_SESSIONID'),'spotv_session':BmPKupLfAyHWzvItxcYXdUsRQgwDoE.getProperty('SPOTV_M_SESSION'),'spotv_accountId':BmPKupLfAyHWzvItxcYXdUsRQgwDoE.getProperty('SPOTV_M_ACCOUNTID'),'spotv_policyKey':base64.standard_b64encode(BmPKupLfAyHWzvItxcYXdUsRQgwDoE.getProperty('SPOTV_M_POLICYKEY').encode()).decode('utf-8'),'spotv_subend':base64.standard_b64encode((BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.SPOTV_PMCODE+BmPKupLfAyHWzvItxcYXdUsRQgwDoE.getProperty('SPOTV_M_SUBEND')).encode()).decode('utf-8'),'spotv_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'spotv_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'spotv_limitdate':BmPKupLfAyHWzvItxcYXdUsRQgwDnN.strftime('%Y-%m-%d')}
  try: 
   fp=BmPKupLfAyHWzvItxcYXdUsRQgwDTl(BmPKupLfAyHWzvItxcYXdUsRQgwDon,'w',-1,'utf-8')
   json.dump(BmPKupLfAyHWzvItxcYXdUsRQgwDnF,fp)
   fp.close()
  except BmPKupLfAyHWzvItxcYXdUsRQgwDTe as exception:
   BmPKupLfAyHWzvItxcYXdUsRQgwDTE(exception)
 def cookiefile_check(BmPKupLfAyHWzvItxcYXdUsRQgwDoT):
  BmPKupLfAyHWzvItxcYXdUsRQgwDnF={}
  try: 
   fp=BmPKupLfAyHWzvItxcYXdUsRQgwDTl(BmPKupLfAyHWzvItxcYXdUsRQgwDon,'r',-1,'utf-8')
   BmPKupLfAyHWzvItxcYXdUsRQgwDnF= json.load(fp)
   fp.close()
  except BmPKupLfAyHWzvItxcYXdUsRQgwDTe as exception:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.wininfo_clear()
   return BmPKupLfAyHWzvItxcYXdUsRQgwDTN
  BmPKupLfAyHWzvItxcYXdUsRQgwDbl =__addon__.getSetting('id')
  BmPKupLfAyHWzvItxcYXdUsRQgwDbe =__addon__.getSetting('pw')
  BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_id'] =base64.standard_b64decode(BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_id']).decode('utf-8')
  BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_pw'] =base64.standard_b64decode(BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_pw']).decode('utf-8')
  BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_policyKey']=base64.standard_b64decode(BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_policyKey']).decode('utf-8')
  BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_subend']=base64.standard_b64decode(BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_subend']).decode('utf-8')[BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.SPOTV_PMSIZE:]
  if BmPKupLfAyHWzvItxcYXdUsRQgwDbl!=BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_id']or BmPKupLfAyHWzvItxcYXdUsRQgwDbe!=BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_pw']:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.wininfo_clear()
   return BmPKupLfAyHWzvItxcYXdUsRQgwDTN
  BmPKupLfAyHWzvItxcYXdUsRQgwDbj =BmPKupLfAyHWzvItxcYXdUsRQgwDTr(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.SpotvObj.Get_Now_Datetime().strftime('%Y%m%d'))
  BmPKupLfAyHWzvItxcYXdUsRQgwDnJ=BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_limitdate']
  BmPKupLfAyHWzvItxcYXdUsRQgwDbC =BmPKupLfAyHWzvItxcYXdUsRQgwDTr(re.sub('-','',BmPKupLfAyHWzvItxcYXdUsRQgwDnJ))
  if BmPKupLfAyHWzvItxcYXdUsRQgwDbC<BmPKupLfAyHWzvItxcYXdUsRQgwDbj:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.wininfo_clear()
   return BmPKupLfAyHWzvItxcYXdUsRQgwDTN
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE=xbmcgui.Window(10000)
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_SESSIONID',BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_sessionid'])
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_SESSION',BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_session'])
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_ACCOUNTID',BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_accountId'])
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_POLICYKEY',BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_policyKey'])
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_SUBEND',BmPKupLfAyHWzvItxcYXdUsRQgwDnF['spotv_subend'])
  BmPKupLfAyHWzvItxcYXdUsRQgwDoE.setProperty('SPOTV_M_LOGINTIME',BmPKupLfAyHWzvItxcYXdUsRQgwDnJ)
  return BmPKupLfAyHWzvItxcYXdUsRQgwDTM
 def dp_WatchList_Delete(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,args):
  BmPKupLfAyHWzvItxcYXdUsRQgwDnV=args.get('mediatype')
  BmPKupLfAyHWzvItxcYXdUsRQgwDor=xbmcgui.Dialog()
  BmPKupLfAyHWzvItxcYXdUsRQgwDbE=BmPKupLfAyHWzvItxcYXdUsRQgwDor.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if BmPKupLfAyHWzvItxcYXdUsRQgwDbE==BmPKupLfAyHWzvItxcYXdUsRQgwDTN:sys.exit()
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.Delete_Watched_List(BmPKupLfAyHWzvItxcYXdUsRQgwDnV)
  xbmc.executebuiltin("Container.Refresh")
 def Delete_Watched_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,BmPKupLfAyHWzvItxcYXdUsRQgwDnV):
  try:
   BmPKupLfAyHWzvItxcYXdUsRQgwDnl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BmPKupLfAyHWzvItxcYXdUsRQgwDnV))
   fp=BmPKupLfAyHWzvItxcYXdUsRQgwDTl(BmPKupLfAyHWzvItxcYXdUsRQgwDnl,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   BmPKupLfAyHWzvItxcYXdUsRQgwDTa
 def Load_Watched_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,BmPKupLfAyHWzvItxcYXdUsRQgwDnV):
  try:
   BmPKupLfAyHWzvItxcYXdUsRQgwDnl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BmPKupLfAyHWzvItxcYXdUsRQgwDnV))
   fp=BmPKupLfAyHWzvItxcYXdUsRQgwDTl(BmPKupLfAyHWzvItxcYXdUsRQgwDnl,'r',-1,'utf-8')
   BmPKupLfAyHWzvItxcYXdUsRQgwDne=fp.readlines()
   fp.close()
  except:
   BmPKupLfAyHWzvItxcYXdUsRQgwDne=[]
  return BmPKupLfAyHWzvItxcYXdUsRQgwDne
 def Save_Watched_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,stype,BmPKupLfAyHWzvItxcYXdUsRQgwDoa):
  try:
   BmPKupLfAyHWzvItxcYXdUsRQgwDnl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%stype))
   BmPKupLfAyHWzvItxcYXdUsRQgwDnE=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.Load_Watched_List(stype) 
   fp=BmPKupLfAyHWzvItxcYXdUsRQgwDTl(BmPKupLfAyHWzvItxcYXdUsRQgwDnl,'w',-1,'utf-8')
   BmPKupLfAyHWzvItxcYXdUsRQgwDnj=urllib.parse.urlencode(BmPKupLfAyHWzvItxcYXdUsRQgwDoa)
   BmPKupLfAyHWzvItxcYXdUsRQgwDnj=BmPKupLfAyHWzvItxcYXdUsRQgwDnj+'\n'
   fp.write(BmPKupLfAyHWzvItxcYXdUsRQgwDnj)
   BmPKupLfAyHWzvItxcYXdUsRQgwDnC=0
   for BmPKupLfAyHWzvItxcYXdUsRQgwDnO in BmPKupLfAyHWzvItxcYXdUsRQgwDnE:
    BmPKupLfAyHWzvItxcYXdUsRQgwDnq=BmPKupLfAyHWzvItxcYXdUsRQgwDTj(urllib.parse.parse_qsl(BmPKupLfAyHWzvItxcYXdUsRQgwDnO))
    BmPKupLfAyHWzvItxcYXdUsRQgwDni=BmPKupLfAyHWzvItxcYXdUsRQgwDoa.get('code')
    BmPKupLfAyHWzvItxcYXdUsRQgwDnG=BmPKupLfAyHWzvItxcYXdUsRQgwDnq.get('code')
    if BmPKupLfAyHWzvItxcYXdUsRQgwDni!=BmPKupLfAyHWzvItxcYXdUsRQgwDnG:
     fp.write(BmPKupLfAyHWzvItxcYXdUsRQgwDnO)
     BmPKupLfAyHWzvItxcYXdUsRQgwDnC+=1
     if BmPKupLfAyHWzvItxcYXdUsRQgwDnC>=50:break
   fp.close()
  except:
   BmPKupLfAyHWzvItxcYXdUsRQgwDTa
 def dp_Watch_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT,args):
  BmPKupLfAyHWzvItxcYXdUsRQgwDnV ='vod'
  if BmPKupLfAyHWzvItxcYXdUsRQgwDnV=='vod':
   BmPKupLfAyHWzvItxcYXdUsRQgwDnk=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.Load_Watched_List(BmPKupLfAyHWzvItxcYXdUsRQgwDnV)
   for BmPKupLfAyHWzvItxcYXdUsRQgwDTo in BmPKupLfAyHWzvItxcYXdUsRQgwDnk:
    BmPKupLfAyHWzvItxcYXdUsRQgwDTh=BmPKupLfAyHWzvItxcYXdUsRQgwDTj(urllib.parse.parse_qsl(BmPKupLfAyHWzvItxcYXdUsRQgwDTo))
    BmPKupLfAyHWzvItxcYXdUsRQgwDoO =BmPKupLfAyHWzvItxcYXdUsRQgwDTh.get('title')
    BmPKupLfAyHWzvItxcYXdUsRQgwDha=BmPKupLfAyHWzvItxcYXdUsRQgwDTh.get('img')
    BmPKupLfAyHWzvItxcYXdUsRQgwDnT=BmPKupLfAyHWzvItxcYXdUsRQgwDTh.get('code')
    BmPKupLfAyHWzvItxcYXdUsRQgwDTb =BmPKupLfAyHWzvItxcYXdUsRQgwDTh.get('info')
    BmPKupLfAyHWzvItxcYXdUsRQgwDhN={}
    BmPKupLfAyHWzvItxcYXdUsRQgwDhN['plot']=BmPKupLfAyHWzvItxcYXdUsRQgwDTb
    BmPKupLfAyHWzvItxcYXdUsRQgwDhb={'mode':'GAME_VOD_GROUP','gameid':BmPKupLfAyHWzvItxcYXdUsRQgwDnT,'saveTitle':BmPKupLfAyHWzvItxcYXdUsRQgwDoO,'saveImg':BmPKupLfAyHWzvItxcYXdUsRQgwDha,'saveInfo':BmPKupLfAyHWzvItxcYXdUsRQgwDTb,'mediatype':BmPKupLfAyHWzvItxcYXdUsRQgwDnV}
    BmPKupLfAyHWzvItxcYXdUsRQgwDoT.add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDoO,sublabel='',img=BmPKupLfAyHWzvItxcYXdUsRQgwDha,infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDhN,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDTM,params=BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
   BmPKupLfAyHWzvItxcYXdUsRQgwDhN={'plot':'시청목록을 삭제합니다.'}
   BmPKupLfAyHWzvItxcYXdUsRQgwDoO='*** 시청목록 삭제 ***'
   BmPKupLfAyHWzvItxcYXdUsRQgwDhb={'mode':'MYVIEW_REMOVE','mediatype':BmPKupLfAyHWzvItxcYXdUsRQgwDnV}
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.add_dir(BmPKupLfAyHWzvItxcYXdUsRQgwDoO,sublabel='',img='',infoLabels=BmPKupLfAyHWzvItxcYXdUsRQgwDhN,isFolder=BmPKupLfAyHWzvItxcYXdUsRQgwDTN,params=BmPKupLfAyHWzvItxcYXdUsRQgwDhb)
   xbmcplugin.endOfDirectory(BmPKupLfAyHWzvItxcYXdUsRQgwDoT._addon_handle,cacheToDisc=BmPKupLfAyHWzvItxcYXdUsRQgwDTN)
 def spotv_main(BmPKupLfAyHWzvItxcYXdUsRQgwDoT):
  BmPKupLfAyHWzvItxcYXdUsRQgwDTV=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params.get('mode',BmPKupLfAyHWzvItxcYXdUsRQgwDTa)
  if BmPKupLfAyHWzvItxcYXdUsRQgwDTV=='LOGOUT':
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.logout()
   return
  BmPKupLfAyHWzvItxcYXdUsRQgwDoT.login_main()
  if BmPKupLfAyHWzvItxcYXdUsRQgwDTV is BmPKupLfAyHWzvItxcYXdUsRQgwDTa:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.dp_Main_List()
  elif BmPKupLfAyHWzvItxcYXdUsRQgwDTV=='LIVE_GROUP':
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.dp_LiveChannel_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params)
  elif BmPKupLfAyHWzvItxcYXdUsRQgwDTV=='ELIVE_GROUP':
   BmPKupLfAyHWzvItxcYXdUsRQgwDnh=BmPKupLfAyHWzvItxcYXdUsRQgwDoT.dp_EventLiveChannel_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params)
   if BmPKupLfAyHWzvItxcYXdUsRQgwDnh==401:
    if os.path.isfile(BmPKupLfAyHWzvItxcYXdUsRQgwDon):os.remove(BmPKupLfAyHWzvItxcYXdUsRQgwDon)
    BmPKupLfAyHWzvItxcYXdUsRQgwDoT.login_main()
    BmPKupLfAyHWzvItxcYXdUsRQgwDoT.dp_EventLiveChannel_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params)
  elif BmPKupLfAyHWzvItxcYXdUsRQgwDTV in['LIVE','GAME_VOD','POP_VOD','ELIVE']:
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.play_VIDEO(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params)
  elif BmPKupLfAyHWzvItxcYXdUsRQgwDTV=='VOD_GROUP':
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.dp_MainLeague_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params)
  elif BmPKupLfAyHWzvItxcYXdUsRQgwDTV=='POP_GROUP':
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.dp_PopVod_GroupList(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params)
  elif BmPKupLfAyHWzvItxcYXdUsRQgwDTV=='LEAGUE_GROUP':
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.dp_Season_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params)
  elif BmPKupLfAyHWzvItxcYXdUsRQgwDTV=='SEASON_GROUP':
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.dp_Game_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params)
  elif BmPKupLfAyHWzvItxcYXdUsRQgwDTV=='GAME_VOD_GROUP':
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.dp_GameVod_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params)
  elif BmPKupLfAyHWzvItxcYXdUsRQgwDTV=='WATCH':
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.dp_Watch_List(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params)
  elif BmPKupLfAyHWzvItxcYXdUsRQgwDTV=='MYVIEW_REMOVE':
   BmPKupLfAyHWzvItxcYXdUsRQgwDoT.dp_WatchList_Delete(BmPKupLfAyHWzvItxcYXdUsRQgwDoT.main_params)
  else:
   BmPKupLfAyHWzvItxcYXdUsRQgwDTa
# Created by pyminifier (https://github.com/liftoff/pyminifier)
